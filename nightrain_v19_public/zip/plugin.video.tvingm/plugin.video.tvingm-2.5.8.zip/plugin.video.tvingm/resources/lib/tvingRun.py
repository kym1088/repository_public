__author__="NightRain"
nOCvrwJihTtRPylKbxYVgHAcmWSapU=object
nOCvrwJihTtRPylKbxYVgHAcmWSapI=None
nOCvrwJihTtRPylKbxYVgHAcmWSapB=int
nOCvrwJihTtRPylKbxYVgHAcmWSape=True
nOCvrwJihTtRPylKbxYVgHAcmWSaps=False
nOCvrwJihTtRPylKbxYVgHAcmWSaLG=type
nOCvrwJihTtRPylKbxYVgHAcmWSaLN=dict
nOCvrwJihTtRPylKbxYVgHAcmWSaLM=getattr
nOCvrwJihTtRPylKbxYVgHAcmWSaLz=list
nOCvrwJihTtRPylKbxYVgHAcmWSaLq=len
nOCvrwJihTtRPylKbxYVgHAcmWSaLj=str
nOCvrwJihTtRPylKbxYVgHAcmWSaLX=range
nOCvrwJihTtRPylKbxYVgHAcmWSaLp=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
nOCvrwJihTtRPylKbxYVgHAcmWSaGM=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'오직 티빙에만','mode':'ORI_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'VOD 방송 - 4K','mode':'4K_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 4K','mode':'4K_MOVIE','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
nOCvrwJihTtRPylKbxYVgHAcmWSaGz=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
nOCvrwJihTtRPylKbxYVgHAcmWSaGq=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
nOCvrwJihTtRPylKbxYVgHAcmWSaGj=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
nOCvrwJihTtRPylKbxYVgHAcmWSaGX=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'로맨스','mode':'PROGRAM','stype':'PCO'},{'title':'코미디','mode':'PROGRAM','stype':'PCP'},{'title':'스릴러','mode':'PROGRAM','stype':'PCQ'},{'title':'미스터리(추리)','mode':'PROGRAM','stype':'PCAA'},{'title':'모험','mode':'PROGRAM','stype':'PCX'},{'title':'액션','mode':'PROGRAM','stype':'PCY'},{'title':'판타지','mode':'PROGRAM','stype':'PCR'},{'title':'무협','mode':'PROGRAM','stype':'PCAB'},{'title':'공포','mode':'PROGRAM','stype':'PCAD'},{'title':'리얼리티','mode':'PROGRAM','stype':'PCV'},{'title':'토크쇼','mode':'PROGRAM','stype':'PCU'},{'title':'다큐멘터리','mode':'PROGRAM','stype':'PCT'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'스포츠','mode':'PROGRAM','stype':'PCF'},{'title':'음악','mode':'PROGRAM','stype':'PCAC'},{'title':'공연','mode':'PROGRAM','stype':'PCW'},{'title':'사극(시대극)','mode':'PROGRAM','stype':'PCS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'Paramount+','mode':'PROGRAM','stype':'PARAMOUNT'}]
nOCvrwJihTtRPylKbxYVgHAcmWSaGp=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG23'},{'title':'로맨스','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'스릴러','mode':'MOVIE_SUB','stype':'MG140'},{'title':'미스터리','mode':'MOVIE_SUB','stype':'MG150'},{'title':'모험','mode':'MOVIE_SUB','stype':'MG170'},{'title':'액션','mode':'MOVIE_SUB','stype':'MG120'},{'title':'판타지','mode':'MOVIE_SUB','stype':'MG200'},{'title':'SF','mode':'MOVIE_SUB','stype':'MG210'},{'title':'공포','mode':'MOVIE_SUB','stype':'MG160'},{'title':'다큐멘터리','mode':'MOVIE_SUB','stype':'MG250'},{'title':'다양성 영화','mode':'MOVIE_SUB','stype':'diversityYn'},{'title':'Paramount+','mode':'MOVIE_SUB','stype':'PARAMOUNT'}]
nOCvrwJihTtRPylKbxYVgHAcmWSaGL=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
nOCvrwJihTtRPylKbxYVgHAcmWSaGD={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
from tvingCore import*
nOCvrwJihTtRPylKbxYVgHAcmWSaGE =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
nOCvrwJihTtRPylKbxYVgHAcmWSaGk=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
class nOCvrwJihTtRPylKbxYVgHAcmWSaGN(nOCvrwJihTtRPylKbxYVgHAcmWSapU):
 def __init__(nOCvrwJihTtRPylKbxYVgHAcmWSaGd,nOCvrwJihTtRPylKbxYVgHAcmWSaGu,nOCvrwJihTtRPylKbxYVgHAcmWSaGF,nOCvrwJihTtRPylKbxYVgHAcmWSaGf):
  nOCvrwJihTtRPylKbxYVgHAcmWSaGd._addon_url =nOCvrwJihTtRPylKbxYVgHAcmWSaGu
  nOCvrwJihTtRPylKbxYVgHAcmWSaGd._addon_handle=nOCvrwJihTtRPylKbxYVgHAcmWSaGF
  nOCvrwJihTtRPylKbxYVgHAcmWSaGd.main_params =nOCvrwJihTtRPylKbxYVgHAcmWSaGf
  nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj =qxdaJLSMjgcHOBKyzRlYXUusEeCvbt() 
  nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.TV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_stream(mpd,m3u8)'))
 def addon_noti(nOCvrwJihTtRPylKbxYVgHAcmWSaGd,sting):
  try:
   nOCvrwJihTtRPylKbxYVgHAcmWSaGQ=xbmcgui.Dialog()
   nOCvrwJihTtRPylKbxYVgHAcmWSaGQ.notification(__addonname__,sting)
  except:
   nOCvrwJihTtRPylKbxYVgHAcmWSapI
 def addon_log(nOCvrwJihTtRPylKbxYVgHAcmWSaGd,string):
  try:
   nOCvrwJihTtRPylKbxYVgHAcmWSaGU=string.encode('utf-8','ignore')
  except:
   nOCvrwJihTtRPylKbxYVgHAcmWSaGU='addonException: addon_log'
  nOCvrwJihTtRPylKbxYVgHAcmWSaGI=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,nOCvrwJihTtRPylKbxYVgHAcmWSaGU),level=nOCvrwJihTtRPylKbxYVgHAcmWSaGI)
 def get_keyboard_input(nOCvrwJihTtRPylKbxYVgHAcmWSaGd,nOCvrwJihTtRPylKbxYVgHAcmWSaNf):
  nOCvrwJihTtRPylKbxYVgHAcmWSaGB=nOCvrwJihTtRPylKbxYVgHAcmWSapI
  kb=xbmc.Keyboard()
  kb.setHeading(nOCvrwJihTtRPylKbxYVgHAcmWSaNf)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   nOCvrwJihTtRPylKbxYVgHAcmWSaGB=kb.getText()
  return nOCvrwJihTtRPylKbxYVgHAcmWSaGB
 def get_settings_account(nOCvrwJihTtRPylKbxYVgHAcmWSaGd):
  nOCvrwJihTtRPylKbxYVgHAcmWSaGe =__addon__.getSetting('id')
  nOCvrwJihTtRPylKbxYVgHAcmWSaGs =__addon__.getSetting('pw')
  nOCvrwJihTtRPylKbxYVgHAcmWSaNG =__addon__.getSetting('login_type')
  nOCvrwJihTtRPylKbxYVgHAcmWSaNM=nOCvrwJihTtRPylKbxYVgHAcmWSapB(__addon__.getSetting('selected_profile'))
  return(nOCvrwJihTtRPylKbxYVgHAcmWSaGe,nOCvrwJihTtRPylKbxYVgHAcmWSaGs,nOCvrwJihTtRPylKbxYVgHAcmWSaNG,nOCvrwJihTtRPylKbxYVgHAcmWSaNM)
 def get_settings_uhd(nOCvrwJihTtRPylKbxYVgHAcmWSaGd):
  return nOCvrwJihTtRPylKbxYVgHAcmWSape if __addon__.getSetting('active_uhd')=='true' else nOCvrwJihTtRPylKbxYVgHAcmWSaps
 def get_settings_playback(nOCvrwJihTtRPylKbxYVgHAcmWSaGd):
  nOCvrwJihTtRPylKbxYVgHAcmWSaNz={'active_uhd':nOCvrwJihTtRPylKbxYVgHAcmWSape if __addon__.getSetting('active_uhd')=='true' else nOCvrwJihTtRPylKbxYVgHAcmWSaps,'streamFilename':nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.TV_STREAM_FILENAME,}
  return nOCvrwJihTtRPylKbxYVgHAcmWSaNz
 def get_settings_proxyport(nOCvrwJihTtRPylKbxYVgHAcmWSaGd):
  nOCvrwJihTtRPylKbxYVgHAcmWSaNq =nOCvrwJihTtRPylKbxYVgHAcmWSape if __addon__.getSetting('proxyYn')=='true' else nOCvrwJihTtRPylKbxYVgHAcmWSaps
  nOCvrwJihTtRPylKbxYVgHAcmWSaNj=nOCvrwJihTtRPylKbxYVgHAcmWSapB(__addon__.getSetting('proxyPort'))
  return nOCvrwJihTtRPylKbxYVgHAcmWSaNq,nOCvrwJihTtRPylKbxYVgHAcmWSaNj
 def get_settings_totalsearch(nOCvrwJihTtRPylKbxYVgHAcmWSaGd):
  nOCvrwJihTtRPylKbxYVgHAcmWSaNX =nOCvrwJihTtRPylKbxYVgHAcmWSape if __addon__.getSetting('local_search')=='true' else nOCvrwJihTtRPylKbxYVgHAcmWSaps
  nOCvrwJihTtRPylKbxYVgHAcmWSaNp=nOCvrwJihTtRPylKbxYVgHAcmWSape if __addon__.getSetting('local_history')=='true' else nOCvrwJihTtRPylKbxYVgHAcmWSaps
  nOCvrwJihTtRPylKbxYVgHAcmWSaNL =nOCvrwJihTtRPylKbxYVgHAcmWSape if __addon__.getSetting('total_search')=='true' else nOCvrwJihTtRPylKbxYVgHAcmWSaps
  nOCvrwJihTtRPylKbxYVgHAcmWSaND=nOCvrwJihTtRPylKbxYVgHAcmWSape if __addon__.getSetting('total_history')=='true' else nOCvrwJihTtRPylKbxYVgHAcmWSaps
  nOCvrwJihTtRPylKbxYVgHAcmWSaNE=nOCvrwJihTtRPylKbxYVgHAcmWSape if __addon__.getSetting('menu_bookmark')=='true' else nOCvrwJihTtRPylKbxYVgHAcmWSaps
  return(nOCvrwJihTtRPylKbxYVgHAcmWSaNX,nOCvrwJihTtRPylKbxYVgHAcmWSaNp,nOCvrwJihTtRPylKbxYVgHAcmWSaNL,nOCvrwJihTtRPylKbxYVgHAcmWSaND,nOCvrwJihTtRPylKbxYVgHAcmWSaNE)
 def get_settings_makebookmark(nOCvrwJihTtRPylKbxYVgHAcmWSaGd):
  return nOCvrwJihTtRPylKbxYVgHAcmWSape if __addon__.getSetting('make_bookmark')=='true' else nOCvrwJihTtRPylKbxYVgHAcmWSaps
 def get_settings_direct_replay(nOCvrwJihTtRPylKbxYVgHAcmWSaGd):
  nOCvrwJihTtRPylKbxYVgHAcmWSaNk=nOCvrwJihTtRPylKbxYVgHAcmWSapB(__addon__.getSetting('direct_replay'))
  if nOCvrwJihTtRPylKbxYVgHAcmWSaNk==0:
   return nOCvrwJihTtRPylKbxYVgHAcmWSaps
  else:
   return nOCvrwJihTtRPylKbxYVgHAcmWSape
 def set_winEpisodeOrderby(nOCvrwJihTtRPylKbxYVgHAcmWSaGd,nOCvrwJihTtRPylKbxYVgHAcmWSaNu):
  __addon__.setSetting('tving_orderby',nOCvrwJihTtRPylKbxYVgHAcmWSaNu)
  nOCvrwJihTtRPylKbxYVgHAcmWSaNd=xbmcgui.Window(10000)
  nOCvrwJihTtRPylKbxYVgHAcmWSaNd.setProperty('TVING_M_ORDERBY',nOCvrwJihTtRPylKbxYVgHAcmWSaNu)
 def get_winEpisodeOrderby(nOCvrwJihTtRPylKbxYVgHAcmWSaGd):
  nOCvrwJihTtRPylKbxYVgHAcmWSaNu=__addon__.getSetting('tving_orderby')
  if nOCvrwJihTtRPylKbxYVgHAcmWSaNu in['',nOCvrwJihTtRPylKbxYVgHAcmWSapI]:nOCvrwJihTtRPylKbxYVgHAcmWSaNu='desc'
  return nOCvrwJihTtRPylKbxYVgHAcmWSaNu
 def add_dir(nOCvrwJihTtRPylKbxYVgHAcmWSaGd,label,sublabel='',img='',infoLabels=nOCvrwJihTtRPylKbxYVgHAcmWSapI,isFolder=nOCvrwJihTtRPylKbxYVgHAcmWSape,params='',isLink=nOCvrwJihTtRPylKbxYVgHAcmWSaps,ContextMenu=nOCvrwJihTtRPylKbxYVgHAcmWSapI):
  nOCvrwJihTtRPylKbxYVgHAcmWSaNF='%s?%s'%(nOCvrwJihTtRPylKbxYVgHAcmWSaGd._addon_url,urllib.parse.urlencode(params))
  if sublabel:nOCvrwJihTtRPylKbxYVgHAcmWSaNf='%s < %s >'%(label,sublabel)
  else: nOCvrwJihTtRPylKbxYVgHAcmWSaNf=label
  if not img:img='DefaultFolder.png'
  nOCvrwJihTtRPylKbxYVgHAcmWSaNo=xbmcgui.ListItem(nOCvrwJihTtRPylKbxYVgHAcmWSaNf)
  if nOCvrwJihTtRPylKbxYVgHAcmWSaLG(img)==nOCvrwJihTtRPylKbxYVgHAcmWSaLN:
   nOCvrwJihTtRPylKbxYVgHAcmWSaNo.setArt(img)
  else:
   nOCvrwJihTtRPylKbxYVgHAcmWSaNo.setArt({'thumb':img,'poster':img})
  if nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.KodiVersion>=20:
   if infoLabels:nOCvrwJihTtRPylKbxYVgHAcmWSaGd.Set_InfoTag(nOCvrwJihTtRPylKbxYVgHAcmWSaNo.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:nOCvrwJihTtRPylKbxYVgHAcmWSaNo.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   nOCvrwJihTtRPylKbxYVgHAcmWSaNo.setProperty('IsPlayable','true')
  if ContextMenu:nOCvrwJihTtRPylKbxYVgHAcmWSaNo.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(nOCvrwJihTtRPylKbxYVgHAcmWSaGd._addon_handle,nOCvrwJihTtRPylKbxYVgHAcmWSaNF,nOCvrwJihTtRPylKbxYVgHAcmWSaNo,isFolder)
 def get_selQuality(nOCvrwJihTtRPylKbxYVgHAcmWSaGd,etype):
  try:
   nOCvrwJihTtRPylKbxYVgHAcmWSaNQ='selected_quality'
   nOCvrwJihTtRPylKbxYVgHAcmWSaNU=[1080,720,480,360]
   nOCvrwJihTtRPylKbxYVgHAcmWSaNI=nOCvrwJihTtRPylKbxYVgHAcmWSapB(__addon__.getSetting(nOCvrwJihTtRPylKbxYVgHAcmWSaNQ))
   return nOCvrwJihTtRPylKbxYVgHAcmWSaNU[nOCvrwJihTtRPylKbxYVgHAcmWSaNI]
  except:
   nOCvrwJihTtRPylKbxYVgHAcmWSapI
  return 720 
 def Set_InfoTag(nOCvrwJihTtRPylKbxYVgHAcmWSaGd,video_InfoTag:xbmc.InfoTagVideo,nOCvrwJihTtRPylKbxYVgHAcmWSaMj):
  for nOCvrwJihTtRPylKbxYVgHAcmWSaNB,value in nOCvrwJihTtRPylKbxYVgHAcmWSaMj.items():
   if nOCvrwJihTtRPylKbxYVgHAcmWSaGD[nOCvrwJihTtRPylKbxYVgHAcmWSaNB]['type']=='string':
    nOCvrwJihTtRPylKbxYVgHAcmWSaLM(video_InfoTag,nOCvrwJihTtRPylKbxYVgHAcmWSaGD[nOCvrwJihTtRPylKbxYVgHAcmWSaNB]['func'])(value)
   elif nOCvrwJihTtRPylKbxYVgHAcmWSaGD[nOCvrwJihTtRPylKbxYVgHAcmWSaNB]['type']=='int':
    if nOCvrwJihTtRPylKbxYVgHAcmWSaLG(value)==nOCvrwJihTtRPylKbxYVgHAcmWSapB:
     nOCvrwJihTtRPylKbxYVgHAcmWSaNe=nOCvrwJihTtRPylKbxYVgHAcmWSapB(value)
    else:
     nOCvrwJihTtRPylKbxYVgHAcmWSaNe=0
    nOCvrwJihTtRPylKbxYVgHAcmWSaLM(video_InfoTag,nOCvrwJihTtRPylKbxYVgHAcmWSaGD[nOCvrwJihTtRPylKbxYVgHAcmWSaNB]['func'])(nOCvrwJihTtRPylKbxYVgHAcmWSaNe)
   elif nOCvrwJihTtRPylKbxYVgHAcmWSaGD[nOCvrwJihTtRPylKbxYVgHAcmWSaNB]['type']=='actor':
    if value!=[]:
     nOCvrwJihTtRPylKbxYVgHAcmWSaLM(video_InfoTag,nOCvrwJihTtRPylKbxYVgHAcmWSaGD[nOCvrwJihTtRPylKbxYVgHAcmWSaNB]['func'])([xbmc.Actor(name)for name in value])
   elif nOCvrwJihTtRPylKbxYVgHAcmWSaGD[nOCvrwJihTtRPylKbxYVgHAcmWSaNB]['type']=='list':
    if nOCvrwJihTtRPylKbxYVgHAcmWSaLG(value)==nOCvrwJihTtRPylKbxYVgHAcmWSaLz:
     nOCvrwJihTtRPylKbxYVgHAcmWSaLM(video_InfoTag,nOCvrwJihTtRPylKbxYVgHAcmWSaGD[nOCvrwJihTtRPylKbxYVgHAcmWSaNB]['func'])(value)
    else:
     nOCvrwJihTtRPylKbxYVgHAcmWSaLM(video_InfoTag,nOCvrwJihTtRPylKbxYVgHAcmWSaGD[nOCvrwJihTtRPylKbxYVgHAcmWSaNB]['func'])([value])
 def dp_Main_List(nOCvrwJihTtRPylKbxYVgHAcmWSaGd):
  (nOCvrwJihTtRPylKbxYVgHAcmWSaNX,nOCvrwJihTtRPylKbxYVgHAcmWSaNp,nOCvrwJihTtRPylKbxYVgHAcmWSaNL,nOCvrwJihTtRPylKbxYVgHAcmWSaND,nOCvrwJihTtRPylKbxYVgHAcmWSaNE)=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.get_settings_totalsearch()
  for nOCvrwJihTtRPylKbxYVgHAcmWSaNs in nOCvrwJihTtRPylKbxYVgHAcmWSaGM:
   nOCvrwJihTtRPylKbxYVgHAcmWSaNf=nOCvrwJihTtRPylKbxYVgHAcmWSaNs.get('title')
   nOCvrwJihTtRPylKbxYVgHAcmWSaMG=''
   if nOCvrwJihTtRPylKbxYVgHAcmWSaNs.get('mode')=='SEARCH_GROUP' and nOCvrwJihTtRPylKbxYVgHAcmWSaNX ==nOCvrwJihTtRPylKbxYVgHAcmWSaps:continue
   elif nOCvrwJihTtRPylKbxYVgHAcmWSaNs.get('mode')=='SEARCH_HISTORY' and nOCvrwJihTtRPylKbxYVgHAcmWSaNp==nOCvrwJihTtRPylKbxYVgHAcmWSaps:continue
   elif nOCvrwJihTtRPylKbxYVgHAcmWSaNs.get('mode')=='TOTAL_SEARCH' and nOCvrwJihTtRPylKbxYVgHAcmWSaNL ==nOCvrwJihTtRPylKbxYVgHAcmWSaps:continue
   elif nOCvrwJihTtRPylKbxYVgHAcmWSaNs.get('mode')=='TOTAL_HISTORY' and nOCvrwJihTtRPylKbxYVgHAcmWSaND==nOCvrwJihTtRPylKbxYVgHAcmWSaps:continue
   elif nOCvrwJihTtRPylKbxYVgHAcmWSaNs.get('mode')=='MENU_BOOKMARK' and nOCvrwJihTtRPylKbxYVgHAcmWSaNE==nOCvrwJihTtRPylKbxYVgHAcmWSaps:continue
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN={'mode':nOCvrwJihTtRPylKbxYVgHAcmWSaNs.get('mode'),'stype':nOCvrwJihTtRPylKbxYVgHAcmWSaNs.get('stype'),'orderby':nOCvrwJihTtRPylKbxYVgHAcmWSaNs.get('orderby'),'ordernm':nOCvrwJihTtRPylKbxYVgHAcmWSaNs.get('ordernm'),'page':'1'}
   if nOCvrwJihTtRPylKbxYVgHAcmWSaNs.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    nOCvrwJihTtRPylKbxYVgHAcmWSaMz=nOCvrwJihTtRPylKbxYVgHAcmWSaps
    nOCvrwJihTtRPylKbxYVgHAcmWSaMq =nOCvrwJihTtRPylKbxYVgHAcmWSape
   else:
    nOCvrwJihTtRPylKbxYVgHAcmWSaMz=nOCvrwJihTtRPylKbxYVgHAcmWSape
    nOCvrwJihTtRPylKbxYVgHAcmWSaMq =nOCvrwJihTtRPylKbxYVgHAcmWSaps
   nOCvrwJihTtRPylKbxYVgHAcmWSaMj={'title':nOCvrwJihTtRPylKbxYVgHAcmWSaNf,'plot':nOCvrwJihTtRPylKbxYVgHAcmWSaNf}
   if nOCvrwJihTtRPylKbxYVgHAcmWSaNs.get('mode')=='XXX':nOCvrwJihTtRPylKbxYVgHAcmWSaMj=nOCvrwJihTtRPylKbxYVgHAcmWSapI
   if 'icon' in nOCvrwJihTtRPylKbxYVgHAcmWSaNs:nOCvrwJihTtRPylKbxYVgHAcmWSaMG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',nOCvrwJihTtRPylKbxYVgHAcmWSaNs.get('icon')) 
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.add_dir(nOCvrwJihTtRPylKbxYVgHAcmWSaNf,sublabel='',img=nOCvrwJihTtRPylKbxYVgHAcmWSaMG,infoLabels=nOCvrwJihTtRPylKbxYVgHAcmWSaMj,isFolder=nOCvrwJihTtRPylKbxYVgHAcmWSaMz,params=nOCvrwJihTtRPylKbxYVgHAcmWSaMN,isLink=nOCvrwJihTtRPylKbxYVgHAcmWSaMq)
  xbmcplugin.endOfDirectory(nOCvrwJihTtRPylKbxYVgHAcmWSaGd._addon_handle)
 def login_main(nOCvrwJihTtRPylKbxYVgHAcmWSaGd):
  (nOCvrwJihTtRPylKbxYVgHAcmWSaMp,nOCvrwJihTtRPylKbxYVgHAcmWSaML,nOCvrwJihTtRPylKbxYVgHAcmWSaMD,nOCvrwJihTtRPylKbxYVgHAcmWSaME)=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.get_settings_account()
  if not(nOCvrwJihTtRPylKbxYVgHAcmWSaMp and nOCvrwJihTtRPylKbxYVgHAcmWSaML):
   nOCvrwJihTtRPylKbxYVgHAcmWSaGQ=xbmcgui.Dialog()
   nOCvrwJihTtRPylKbxYVgHAcmWSaMk=nOCvrwJihTtRPylKbxYVgHAcmWSaGQ.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if nOCvrwJihTtRPylKbxYVgHAcmWSaMk==nOCvrwJihTtRPylKbxYVgHAcmWSape:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if nOCvrwJihTtRPylKbxYVgHAcmWSaGd.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   nOCvrwJihTtRPylKbxYVgHAcmWSaMd=0
   while nOCvrwJihTtRPylKbxYVgHAcmWSape:
    nOCvrwJihTtRPylKbxYVgHAcmWSaMd+=1
    time.sleep(0.05)
    if nOCvrwJihTtRPylKbxYVgHAcmWSaMd>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  nOCvrwJihTtRPylKbxYVgHAcmWSaMu=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.GetCredential(nOCvrwJihTtRPylKbxYVgHAcmWSaMp,nOCvrwJihTtRPylKbxYVgHAcmWSaML,nOCvrwJihTtRPylKbxYVgHAcmWSaMD,nOCvrwJihTtRPylKbxYVgHAcmWSaME)
  if nOCvrwJihTtRPylKbxYVgHAcmWSaMu:nOCvrwJihTtRPylKbxYVgHAcmWSaGd.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
  if nOCvrwJihTtRPylKbxYVgHAcmWSaMu==nOCvrwJihTtRPylKbxYVgHAcmWSaps:
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(nOCvrwJihTtRPylKbxYVgHAcmWSaGd,nOCvrwJihTtRPylKbxYVgHAcmWSaMQ):
  nOCvrwJihTtRPylKbxYVgHAcmWSaMF=nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('stype')
  if nOCvrwJihTtRPylKbxYVgHAcmWSaMF=='live':
   nOCvrwJihTtRPylKbxYVgHAcmWSaMf=nOCvrwJihTtRPylKbxYVgHAcmWSaGz
  elif nOCvrwJihTtRPylKbxYVgHAcmWSaMF=='vod':
   nOCvrwJihTtRPylKbxYVgHAcmWSaMf=nOCvrwJihTtRPylKbxYVgHAcmWSaGX
  else:
   nOCvrwJihTtRPylKbxYVgHAcmWSaMf=nOCvrwJihTtRPylKbxYVgHAcmWSaGp
  for nOCvrwJihTtRPylKbxYVgHAcmWSaMo in nOCvrwJihTtRPylKbxYVgHAcmWSaMf:
   nOCvrwJihTtRPylKbxYVgHAcmWSaNf=nOCvrwJihTtRPylKbxYVgHAcmWSaMo.get('title')
   if nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('ordernm')!='-':
    nOCvrwJihTtRPylKbxYVgHAcmWSaNf+='  ('+nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('ordernm')+')'
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN={'mode':nOCvrwJihTtRPylKbxYVgHAcmWSaMo.get('mode'),'stype':nOCvrwJihTtRPylKbxYVgHAcmWSaMo.get('stype'),'orderby':nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('orderby'),'ordernm':nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('ordernm'),'page':'1'}
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.add_dir(nOCvrwJihTtRPylKbxYVgHAcmWSaNf,sublabel='',img='',infoLabels=nOCvrwJihTtRPylKbxYVgHAcmWSapI,isFolder=nOCvrwJihTtRPylKbxYVgHAcmWSape,params=nOCvrwJihTtRPylKbxYVgHAcmWSaMN)
  if nOCvrwJihTtRPylKbxYVgHAcmWSaLq(nOCvrwJihTtRPylKbxYVgHAcmWSaMf)>0:xbmcplugin.endOfDirectory(nOCvrwJihTtRPylKbxYVgHAcmWSaGd._addon_handle)
 def dp_SubTitle_Group(nOCvrwJihTtRPylKbxYVgHAcmWSaGd,nOCvrwJihTtRPylKbxYVgHAcmWSaMQ): 
  for nOCvrwJihTtRPylKbxYVgHAcmWSaMo in nOCvrwJihTtRPylKbxYVgHAcmWSaGL:
   nOCvrwJihTtRPylKbxYVgHAcmWSaNf=nOCvrwJihTtRPylKbxYVgHAcmWSaMo.get('title')
   if nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('ordernm')!='-':
    nOCvrwJihTtRPylKbxYVgHAcmWSaNf+='  ('+nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('ordernm')+')'
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN={'mode':nOCvrwJihTtRPylKbxYVgHAcmWSaMo.get('mode'),'genreCode':nOCvrwJihTtRPylKbxYVgHAcmWSaMo.get('genreCode'),'stype':nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('stype'),'orderby':nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('orderby'),'page':'1'}
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.add_dir(nOCvrwJihTtRPylKbxYVgHAcmWSaNf,sublabel='',img='',infoLabels=nOCvrwJihTtRPylKbxYVgHAcmWSapI,isFolder=nOCvrwJihTtRPylKbxYVgHAcmWSape,params=nOCvrwJihTtRPylKbxYVgHAcmWSaMN)
  if nOCvrwJihTtRPylKbxYVgHAcmWSaLq(nOCvrwJihTtRPylKbxYVgHAcmWSaGL)>0:xbmcplugin.endOfDirectory(nOCvrwJihTtRPylKbxYVgHAcmWSaGd._addon_handle)
 def dp_LiveChannel_List(nOCvrwJihTtRPylKbxYVgHAcmWSaGd,nOCvrwJihTtRPylKbxYVgHAcmWSaMQ):
  nOCvrwJihTtRPylKbxYVgHAcmWSaMF =nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('stype')
  nOCvrwJihTtRPylKbxYVgHAcmWSaMU =nOCvrwJihTtRPylKbxYVgHAcmWSapB(nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('page'))
  nOCvrwJihTtRPylKbxYVgHAcmWSaMI,nOCvrwJihTtRPylKbxYVgHAcmWSaMB=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.GetLiveChannelList(nOCvrwJihTtRPylKbxYVgHAcmWSaMF,nOCvrwJihTtRPylKbxYVgHAcmWSaMU)
  for nOCvrwJihTtRPylKbxYVgHAcmWSaMe in nOCvrwJihTtRPylKbxYVgHAcmWSaMI:
   nOCvrwJihTtRPylKbxYVgHAcmWSaNf =nOCvrwJihTtRPylKbxYVgHAcmWSaMe.get('title')
   nOCvrwJihTtRPylKbxYVgHAcmWSaMX =nOCvrwJihTtRPylKbxYVgHAcmWSaMe.get('channel')
   nOCvrwJihTtRPylKbxYVgHAcmWSaMs =nOCvrwJihTtRPylKbxYVgHAcmWSaMe.get('thumbnail')
   nOCvrwJihTtRPylKbxYVgHAcmWSazG =nOCvrwJihTtRPylKbxYVgHAcmWSaMe.get('synopsis')
   nOCvrwJihTtRPylKbxYVgHAcmWSazN =nOCvrwJihTtRPylKbxYVgHAcmWSaMe.get('channelepg')
   nOCvrwJihTtRPylKbxYVgHAcmWSazM =nOCvrwJihTtRPylKbxYVgHAcmWSaMe.get('cast')
   nOCvrwJihTtRPylKbxYVgHAcmWSazq =nOCvrwJihTtRPylKbxYVgHAcmWSaMe.get('director')
   nOCvrwJihTtRPylKbxYVgHAcmWSazj =nOCvrwJihTtRPylKbxYVgHAcmWSaMe.get('info_genre')
   nOCvrwJihTtRPylKbxYVgHAcmWSazX =nOCvrwJihTtRPylKbxYVgHAcmWSaMe.get('year')
   nOCvrwJihTtRPylKbxYVgHAcmWSazp =nOCvrwJihTtRPylKbxYVgHAcmWSaMe.get('mpaa')
   nOCvrwJihTtRPylKbxYVgHAcmWSazL =nOCvrwJihTtRPylKbxYVgHAcmWSaMe.get('premiered')
   nOCvrwJihTtRPylKbxYVgHAcmWSazD={'mediatype':'episode','title':nOCvrwJihTtRPylKbxYVgHAcmWSaNf,'studio':nOCvrwJihTtRPylKbxYVgHAcmWSaMX,'cast':nOCvrwJihTtRPylKbxYVgHAcmWSazM,'director':nOCvrwJihTtRPylKbxYVgHAcmWSazq,'genre':nOCvrwJihTtRPylKbxYVgHAcmWSazj,'plot':'%s\n%s\n%s\n\n%s'%(nOCvrwJihTtRPylKbxYVgHAcmWSaMX,nOCvrwJihTtRPylKbxYVgHAcmWSaNf,nOCvrwJihTtRPylKbxYVgHAcmWSazN,nOCvrwJihTtRPylKbxYVgHAcmWSazG),'year':nOCvrwJihTtRPylKbxYVgHAcmWSazX,'mpaa':nOCvrwJihTtRPylKbxYVgHAcmWSazp,'premiered':nOCvrwJihTtRPylKbxYVgHAcmWSazL}
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN={'mode':'LIVE','mediacode':nOCvrwJihTtRPylKbxYVgHAcmWSaMe.get('mediacode'),'stype':nOCvrwJihTtRPylKbxYVgHAcmWSaMF}
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.add_dir(nOCvrwJihTtRPylKbxYVgHAcmWSaMX,sublabel=nOCvrwJihTtRPylKbxYVgHAcmWSaNf,img=nOCvrwJihTtRPylKbxYVgHAcmWSaMs,infoLabels=nOCvrwJihTtRPylKbxYVgHAcmWSazD,isFolder=nOCvrwJihTtRPylKbxYVgHAcmWSaps,params=nOCvrwJihTtRPylKbxYVgHAcmWSaMN)
  if nOCvrwJihTtRPylKbxYVgHAcmWSaMB:
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN['mode']='CHANNEL' 
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN['stype']=nOCvrwJihTtRPylKbxYVgHAcmWSaMF 
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN['page']=nOCvrwJihTtRPylKbxYVgHAcmWSaLj(nOCvrwJihTtRPylKbxYVgHAcmWSaMU+1)
   nOCvrwJihTtRPylKbxYVgHAcmWSaNf='[B]%s >>[/B]'%'다음 페이지'
   nOCvrwJihTtRPylKbxYVgHAcmWSazE=nOCvrwJihTtRPylKbxYVgHAcmWSaLj(nOCvrwJihTtRPylKbxYVgHAcmWSaMU+1)
   nOCvrwJihTtRPylKbxYVgHAcmWSaMG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.add_dir(nOCvrwJihTtRPylKbxYVgHAcmWSaNf,sublabel=nOCvrwJihTtRPylKbxYVgHAcmWSazE,img=nOCvrwJihTtRPylKbxYVgHAcmWSaMG,infoLabels=nOCvrwJihTtRPylKbxYVgHAcmWSapI,isFolder=nOCvrwJihTtRPylKbxYVgHAcmWSape,params=nOCvrwJihTtRPylKbxYVgHAcmWSaMN)
  if nOCvrwJihTtRPylKbxYVgHAcmWSaLq(nOCvrwJihTtRPylKbxYVgHAcmWSaMI)>0:xbmcplugin.endOfDirectory(nOCvrwJihTtRPylKbxYVgHAcmWSaGd._addon_handle,cacheToDisc=nOCvrwJihTtRPylKbxYVgHAcmWSaps)
 def dp_Program_List(nOCvrwJihTtRPylKbxYVgHAcmWSaGd,nOCvrwJihTtRPylKbxYVgHAcmWSaMQ):
  nOCvrwJihTtRPylKbxYVgHAcmWSazk =nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('stype')
  nOCvrwJihTtRPylKbxYVgHAcmWSaNu =nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('orderby')
  nOCvrwJihTtRPylKbxYVgHAcmWSaMU =nOCvrwJihTtRPylKbxYVgHAcmWSapB(nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('page'))
  nOCvrwJihTtRPylKbxYVgHAcmWSazd=nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('genreCode')
  if nOCvrwJihTtRPylKbxYVgHAcmWSazd==nOCvrwJihTtRPylKbxYVgHAcmWSapI:nOCvrwJihTtRPylKbxYVgHAcmWSazd='all'
  nOCvrwJihTtRPylKbxYVgHAcmWSazu,nOCvrwJihTtRPylKbxYVgHAcmWSaMB=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.GetProgramList(nOCvrwJihTtRPylKbxYVgHAcmWSazk,nOCvrwJihTtRPylKbxYVgHAcmWSaNu,nOCvrwJihTtRPylKbxYVgHAcmWSaMU,nOCvrwJihTtRPylKbxYVgHAcmWSazd)
  for nOCvrwJihTtRPylKbxYVgHAcmWSazF in nOCvrwJihTtRPylKbxYVgHAcmWSazu:
   nOCvrwJihTtRPylKbxYVgHAcmWSaNf =nOCvrwJihTtRPylKbxYVgHAcmWSazF.get('title')
   nOCvrwJihTtRPylKbxYVgHAcmWSaMs =nOCvrwJihTtRPylKbxYVgHAcmWSazF.get('thumbnail')
   nOCvrwJihTtRPylKbxYVgHAcmWSazG =nOCvrwJihTtRPylKbxYVgHAcmWSazF.get('synopsis')
   nOCvrwJihTtRPylKbxYVgHAcmWSazf =nOCvrwJihTtRPylKbxYVgHAcmWSazF.get('channel')
   nOCvrwJihTtRPylKbxYVgHAcmWSazM =nOCvrwJihTtRPylKbxYVgHAcmWSazF.get('cast')
   nOCvrwJihTtRPylKbxYVgHAcmWSazq =nOCvrwJihTtRPylKbxYVgHAcmWSazF.get('director')
   nOCvrwJihTtRPylKbxYVgHAcmWSazj=nOCvrwJihTtRPylKbxYVgHAcmWSazF.get('info_genre')
   nOCvrwJihTtRPylKbxYVgHAcmWSazX =nOCvrwJihTtRPylKbxYVgHAcmWSazF.get('year')
   nOCvrwJihTtRPylKbxYVgHAcmWSazL =nOCvrwJihTtRPylKbxYVgHAcmWSazF.get('premiered')
   nOCvrwJihTtRPylKbxYVgHAcmWSazp =nOCvrwJihTtRPylKbxYVgHAcmWSazF.get('mpaa')
   nOCvrwJihTtRPylKbxYVgHAcmWSazD={'mediatype':'tvshow','title':nOCvrwJihTtRPylKbxYVgHAcmWSaNf,'studio':nOCvrwJihTtRPylKbxYVgHAcmWSazf,'cast':nOCvrwJihTtRPylKbxYVgHAcmWSazM,'director':nOCvrwJihTtRPylKbxYVgHAcmWSazq,'genre':nOCvrwJihTtRPylKbxYVgHAcmWSazj,'year':nOCvrwJihTtRPylKbxYVgHAcmWSazX,'premiered':nOCvrwJihTtRPylKbxYVgHAcmWSazL,'mpaa':nOCvrwJihTtRPylKbxYVgHAcmWSazp,'plot':nOCvrwJihTtRPylKbxYVgHAcmWSazG}
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN={'mode':'EPISODE','programcode':nOCvrwJihTtRPylKbxYVgHAcmWSazF.get('program'),'page':'1'}
   if nOCvrwJihTtRPylKbxYVgHAcmWSaGd.get_settings_makebookmark():
    nOCvrwJihTtRPylKbxYVgHAcmWSazo={'videoid':nOCvrwJihTtRPylKbxYVgHAcmWSazF.get('program'),'vidtype':'tvshow','vtitle':nOCvrwJihTtRPylKbxYVgHAcmWSaNf,'vsubtitle':nOCvrwJihTtRPylKbxYVgHAcmWSazf,}
    nOCvrwJihTtRPylKbxYVgHAcmWSazQ=json.dumps(nOCvrwJihTtRPylKbxYVgHAcmWSazo)
    nOCvrwJihTtRPylKbxYVgHAcmWSazQ=urllib.parse.quote(nOCvrwJihTtRPylKbxYVgHAcmWSazQ)
    nOCvrwJihTtRPylKbxYVgHAcmWSazU='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(nOCvrwJihTtRPylKbxYVgHAcmWSazQ)
    nOCvrwJihTtRPylKbxYVgHAcmWSazI=[('(통합) 찜 영상에 추가',nOCvrwJihTtRPylKbxYVgHAcmWSazU)]
   else:
    nOCvrwJihTtRPylKbxYVgHAcmWSazI=nOCvrwJihTtRPylKbxYVgHAcmWSapI
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.add_dir(nOCvrwJihTtRPylKbxYVgHAcmWSaNf,sublabel=nOCvrwJihTtRPylKbxYVgHAcmWSazf,img=nOCvrwJihTtRPylKbxYVgHAcmWSaMs,infoLabels=nOCvrwJihTtRPylKbxYVgHAcmWSazD,isFolder=nOCvrwJihTtRPylKbxYVgHAcmWSape,params=nOCvrwJihTtRPylKbxYVgHAcmWSaMN,ContextMenu=nOCvrwJihTtRPylKbxYVgHAcmWSazI)
  if nOCvrwJihTtRPylKbxYVgHAcmWSaMB:
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN['mode'] ='PROGRAM' 
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN['stype'] =nOCvrwJihTtRPylKbxYVgHAcmWSazk
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN['orderby'] =nOCvrwJihTtRPylKbxYVgHAcmWSaNu
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN['page'] =nOCvrwJihTtRPylKbxYVgHAcmWSaLj(nOCvrwJihTtRPylKbxYVgHAcmWSaMU+1)
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN['genreCode']=nOCvrwJihTtRPylKbxYVgHAcmWSazd 
   nOCvrwJihTtRPylKbxYVgHAcmWSaNf='[B]%s >>[/B]'%'다음 페이지'
   nOCvrwJihTtRPylKbxYVgHAcmWSazE=nOCvrwJihTtRPylKbxYVgHAcmWSaLj(nOCvrwJihTtRPylKbxYVgHAcmWSaMU+1)
   nOCvrwJihTtRPylKbxYVgHAcmWSaMG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.add_dir(nOCvrwJihTtRPylKbxYVgHAcmWSaNf,sublabel=nOCvrwJihTtRPylKbxYVgHAcmWSazE,img=nOCvrwJihTtRPylKbxYVgHAcmWSaMG,infoLabels=nOCvrwJihTtRPylKbxYVgHAcmWSapI,isFolder=nOCvrwJihTtRPylKbxYVgHAcmWSape,params=nOCvrwJihTtRPylKbxYVgHAcmWSaMN)
  xbmcplugin.setContent(nOCvrwJihTtRPylKbxYVgHAcmWSaGd._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(nOCvrwJihTtRPylKbxYVgHAcmWSaGd._addon_handle,cacheToDisc=nOCvrwJihTtRPylKbxYVgHAcmWSaps)
 def dp_4K_Program_List(nOCvrwJihTtRPylKbxYVgHAcmWSaGd,nOCvrwJihTtRPylKbxYVgHAcmWSaMQ):
  nOCvrwJihTtRPylKbxYVgHAcmWSaMU =nOCvrwJihTtRPylKbxYVgHAcmWSapB(nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('page'))
  nOCvrwJihTtRPylKbxYVgHAcmWSazu,nOCvrwJihTtRPylKbxYVgHAcmWSaMB=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.Get_UHD_ProgramList(nOCvrwJihTtRPylKbxYVgHAcmWSaMU)
  for nOCvrwJihTtRPylKbxYVgHAcmWSazF in nOCvrwJihTtRPylKbxYVgHAcmWSazu:
   nOCvrwJihTtRPylKbxYVgHAcmWSaNf =nOCvrwJihTtRPylKbxYVgHAcmWSazF.get('title')
   nOCvrwJihTtRPylKbxYVgHAcmWSaMs =nOCvrwJihTtRPylKbxYVgHAcmWSazF.get('thumbnail')
   nOCvrwJihTtRPylKbxYVgHAcmWSazG =nOCvrwJihTtRPylKbxYVgHAcmWSazF.get('synopsis')
   nOCvrwJihTtRPylKbxYVgHAcmWSazf =nOCvrwJihTtRPylKbxYVgHAcmWSazF.get('channel')
   nOCvrwJihTtRPylKbxYVgHAcmWSazM =nOCvrwJihTtRPylKbxYVgHAcmWSazF.get('cast')
   nOCvrwJihTtRPylKbxYVgHAcmWSazq =nOCvrwJihTtRPylKbxYVgHAcmWSazF.get('director')
   nOCvrwJihTtRPylKbxYVgHAcmWSazj=nOCvrwJihTtRPylKbxYVgHAcmWSazF.get('info_genre')
   nOCvrwJihTtRPylKbxYVgHAcmWSazX =nOCvrwJihTtRPylKbxYVgHAcmWSazF.get('year')
   nOCvrwJihTtRPylKbxYVgHAcmWSazL =nOCvrwJihTtRPylKbxYVgHAcmWSazF.get('premiered')
   nOCvrwJihTtRPylKbxYVgHAcmWSazp =nOCvrwJihTtRPylKbxYVgHAcmWSazF.get('mpaa')
   nOCvrwJihTtRPylKbxYVgHAcmWSazD={'mediatype':'tvshow','title':nOCvrwJihTtRPylKbxYVgHAcmWSaNf,'studio':nOCvrwJihTtRPylKbxYVgHAcmWSazf,'cast':nOCvrwJihTtRPylKbxYVgHAcmWSazM,'director':nOCvrwJihTtRPylKbxYVgHAcmWSazq,'genre':nOCvrwJihTtRPylKbxYVgHAcmWSazj,'year':nOCvrwJihTtRPylKbxYVgHAcmWSazX,'premiered':nOCvrwJihTtRPylKbxYVgHAcmWSazL,'mpaa':nOCvrwJihTtRPylKbxYVgHAcmWSazp,'plot':nOCvrwJihTtRPylKbxYVgHAcmWSazG}
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN={'mode':'EPISODE','programcode':nOCvrwJihTtRPylKbxYVgHAcmWSazF.get('program'),'page':'1'}
   if nOCvrwJihTtRPylKbxYVgHAcmWSaGd.get_settings_makebookmark():
    nOCvrwJihTtRPylKbxYVgHAcmWSazo={'videoid':nOCvrwJihTtRPylKbxYVgHAcmWSazF.get('program'),'vidtype':'tvshow','vtitle':nOCvrwJihTtRPylKbxYVgHAcmWSaNf,'vsubtitle':nOCvrwJihTtRPylKbxYVgHAcmWSazf,}
    nOCvrwJihTtRPylKbxYVgHAcmWSazQ=json.dumps(nOCvrwJihTtRPylKbxYVgHAcmWSazo)
    nOCvrwJihTtRPylKbxYVgHAcmWSazQ=urllib.parse.quote(nOCvrwJihTtRPylKbxYVgHAcmWSazQ)
    nOCvrwJihTtRPylKbxYVgHAcmWSazU='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(nOCvrwJihTtRPylKbxYVgHAcmWSazQ)
    nOCvrwJihTtRPylKbxYVgHAcmWSazI=[('(통합) 찜 영상에 추가',nOCvrwJihTtRPylKbxYVgHAcmWSazU)]
   else:
    nOCvrwJihTtRPylKbxYVgHAcmWSazI=nOCvrwJihTtRPylKbxYVgHAcmWSapI
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.add_dir(nOCvrwJihTtRPylKbxYVgHAcmWSaNf,sublabel=nOCvrwJihTtRPylKbxYVgHAcmWSazf,img=nOCvrwJihTtRPylKbxYVgHAcmWSaMs,infoLabels=nOCvrwJihTtRPylKbxYVgHAcmWSazD,isFolder=nOCvrwJihTtRPylKbxYVgHAcmWSape,params=nOCvrwJihTtRPylKbxYVgHAcmWSaMN,ContextMenu=nOCvrwJihTtRPylKbxYVgHAcmWSazI)
  if nOCvrwJihTtRPylKbxYVgHAcmWSaMB:
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN['mode'] ='4K_PROGRAM' 
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN['page'] =nOCvrwJihTtRPylKbxYVgHAcmWSaLj(nOCvrwJihTtRPylKbxYVgHAcmWSaMU+1)
   nOCvrwJihTtRPylKbxYVgHAcmWSaNf='[B]%s >>[/B]'%'다음 페이지'
   nOCvrwJihTtRPylKbxYVgHAcmWSazE=nOCvrwJihTtRPylKbxYVgHAcmWSaLj(nOCvrwJihTtRPylKbxYVgHAcmWSaMU+1)
   nOCvrwJihTtRPylKbxYVgHAcmWSaMG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.add_dir(nOCvrwJihTtRPylKbxYVgHAcmWSaNf,sublabel=nOCvrwJihTtRPylKbxYVgHAcmWSazE,img=nOCvrwJihTtRPylKbxYVgHAcmWSaMG,infoLabels=nOCvrwJihTtRPylKbxYVgHAcmWSapI,isFolder=nOCvrwJihTtRPylKbxYVgHAcmWSape,params=nOCvrwJihTtRPylKbxYVgHAcmWSaMN)
  xbmcplugin.setContent(nOCvrwJihTtRPylKbxYVgHAcmWSaGd._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(nOCvrwJihTtRPylKbxYVgHAcmWSaGd._addon_handle,cacheToDisc=nOCvrwJihTtRPylKbxYVgHAcmWSaps)
 def dp_Ori_Program_List(nOCvrwJihTtRPylKbxYVgHAcmWSaGd,nOCvrwJihTtRPylKbxYVgHAcmWSaMQ):
  nOCvrwJihTtRPylKbxYVgHAcmWSaMU =nOCvrwJihTtRPylKbxYVgHAcmWSapB(nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('page'))
  nOCvrwJihTtRPylKbxYVgHAcmWSazu,nOCvrwJihTtRPylKbxYVgHAcmWSaMB=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.Get_Origianl_ProgramList(nOCvrwJihTtRPylKbxYVgHAcmWSaMU)
  for nOCvrwJihTtRPylKbxYVgHAcmWSazF in nOCvrwJihTtRPylKbxYVgHAcmWSazu:
   nOCvrwJihTtRPylKbxYVgHAcmWSaNf =nOCvrwJihTtRPylKbxYVgHAcmWSazF.get('title')
   nOCvrwJihTtRPylKbxYVgHAcmWSaMs =nOCvrwJihTtRPylKbxYVgHAcmWSazF.get('thumbnail')
   nOCvrwJihTtRPylKbxYVgHAcmWSazD={'mediatype':'tvshow','title':nOCvrwJihTtRPylKbxYVgHAcmWSaNf,}
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN={'mode':'EPISODE','programcode':nOCvrwJihTtRPylKbxYVgHAcmWSazF.get('program'),'page':'1',}
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.add_dir(nOCvrwJihTtRPylKbxYVgHAcmWSaNf,sublabel=nOCvrwJihTtRPylKbxYVgHAcmWSapI,img=nOCvrwJihTtRPylKbxYVgHAcmWSaMs,infoLabels=nOCvrwJihTtRPylKbxYVgHAcmWSazD,isFolder=nOCvrwJihTtRPylKbxYVgHAcmWSape,params=nOCvrwJihTtRPylKbxYVgHAcmWSaMN,ContextMenu=nOCvrwJihTtRPylKbxYVgHAcmWSapI)
  if nOCvrwJihTtRPylKbxYVgHAcmWSaMB:
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN['mode'] ='ORI_PROGRAM' 
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN['page'] =nOCvrwJihTtRPylKbxYVgHAcmWSaLj(nOCvrwJihTtRPylKbxYVgHAcmWSaMU+1)
   nOCvrwJihTtRPylKbxYVgHAcmWSaNf='[B]%s >>[/B]'%'다음 페이지'
   nOCvrwJihTtRPylKbxYVgHAcmWSazE=nOCvrwJihTtRPylKbxYVgHAcmWSaLj(nOCvrwJihTtRPylKbxYVgHAcmWSaMU+1)
   nOCvrwJihTtRPylKbxYVgHAcmWSaMG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.add_dir(nOCvrwJihTtRPylKbxYVgHAcmWSaNf,sublabel=nOCvrwJihTtRPylKbxYVgHAcmWSazE,img=nOCvrwJihTtRPylKbxYVgHAcmWSaMG,infoLabels=nOCvrwJihTtRPylKbxYVgHAcmWSapI,isFolder=nOCvrwJihTtRPylKbxYVgHAcmWSape,params=nOCvrwJihTtRPylKbxYVgHAcmWSaMN)
  xbmcplugin.setContent(nOCvrwJihTtRPylKbxYVgHAcmWSaGd._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(nOCvrwJihTtRPylKbxYVgHAcmWSaGd._addon_handle,cacheToDisc=nOCvrwJihTtRPylKbxYVgHAcmWSaps)
 def dp_Episode_List(nOCvrwJihTtRPylKbxYVgHAcmWSaGd,nOCvrwJihTtRPylKbxYVgHAcmWSaMQ):
  nOCvrwJihTtRPylKbxYVgHAcmWSaze=nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('programcode')
  nOCvrwJihTtRPylKbxYVgHAcmWSaMU =nOCvrwJihTtRPylKbxYVgHAcmWSapB(nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('page'))
  nOCvrwJihTtRPylKbxYVgHAcmWSazs,nOCvrwJihTtRPylKbxYVgHAcmWSaMB,nOCvrwJihTtRPylKbxYVgHAcmWSaqG=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.GetEpisodeList(nOCvrwJihTtRPylKbxYVgHAcmWSaze,nOCvrwJihTtRPylKbxYVgHAcmWSaMU,orderby=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.get_winEpisodeOrderby())
  for nOCvrwJihTtRPylKbxYVgHAcmWSaqN in nOCvrwJihTtRPylKbxYVgHAcmWSazs:
   nOCvrwJihTtRPylKbxYVgHAcmWSaNf =nOCvrwJihTtRPylKbxYVgHAcmWSaqN.get('title')
   nOCvrwJihTtRPylKbxYVgHAcmWSazE =nOCvrwJihTtRPylKbxYVgHAcmWSaqN.get('subtitle')
   nOCvrwJihTtRPylKbxYVgHAcmWSaMs =nOCvrwJihTtRPylKbxYVgHAcmWSaqN.get('thumbnail')
   nOCvrwJihTtRPylKbxYVgHAcmWSazG =nOCvrwJihTtRPylKbxYVgHAcmWSaqN.get('synopsis')
   nOCvrwJihTtRPylKbxYVgHAcmWSaqM=nOCvrwJihTtRPylKbxYVgHAcmWSaqN.get('info_title')
   nOCvrwJihTtRPylKbxYVgHAcmWSaqz =nOCvrwJihTtRPylKbxYVgHAcmWSaqN.get('aired')
   nOCvrwJihTtRPylKbxYVgHAcmWSaqj =nOCvrwJihTtRPylKbxYVgHAcmWSaqN.get('studio')
   nOCvrwJihTtRPylKbxYVgHAcmWSaqX =nOCvrwJihTtRPylKbxYVgHAcmWSaqN.get('frequency')
   nOCvrwJihTtRPylKbxYVgHAcmWSazD={'mediatype':'episode','title':nOCvrwJihTtRPylKbxYVgHAcmWSaqM,'aired':nOCvrwJihTtRPylKbxYVgHAcmWSaqz,'studio':nOCvrwJihTtRPylKbxYVgHAcmWSaqj,'episode':nOCvrwJihTtRPylKbxYVgHAcmWSaqX,'plot':nOCvrwJihTtRPylKbxYVgHAcmWSazG}
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN={'mode':'VOD','mediacode':nOCvrwJihTtRPylKbxYVgHAcmWSaqN.get('episode'),'stype':'vod','programcode':nOCvrwJihTtRPylKbxYVgHAcmWSaze,'title':nOCvrwJihTtRPylKbxYVgHAcmWSaNf,'thumbnail':nOCvrwJihTtRPylKbxYVgHAcmWSaMs}
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.add_dir(nOCvrwJihTtRPylKbxYVgHAcmWSaNf,sublabel=nOCvrwJihTtRPylKbxYVgHAcmWSazE,img=nOCvrwJihTtRPylKbxYVgHAcmWSaMs,infoLabels=nOCvrwJihTtRPylKbxYVgHAcmWSazD,isFolder=nOCvrwJihTtRPylKbxYVgHAcmWSaps,params=nOCvrwJihTtRPylKbxYVgHAcmWSaMN)
  if nOCvrwJihTtRPylKbxYVgHAcmWSaMU==1:
   nOCvrwJihTtRPylKbxYVgHAcmWSazD={'plot':'정렬순서를 변경합니다.'}
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN={}
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN['mode'] ='ORDER_BY' 
   if nOCvrwJihTtRPylKbxYVgHAcmWSaGd.get_winEpisodeOrderby()=='desc':
    nOCvrwJihTtRPylKbxYVgHAcmWSaNf='정렬순서변경 : 최신화부터 -> 1회부터'
    nOCvrwJihTtRPylKbxYVgHAcmWSaMN['orderby']='asc'
   else:
    nOCvrwJihTtRPylKbxYVgHAcmWSaNf='정렬순서변경 : 1회부터 -> 최신화부터'
    nOCvrwJihTtRPylKbxYVgHAcmWSaMN['orderby']='desc'
   nOCvrwJihTtRPylKbxYVgHAcmWSaMG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.add_dir(nOCvrwJihTtRPylKbxYVgHAcmWSaNf,sublabel='',img=nOCvrwJihTtRPylKbxYVgHAcmWSaMG,infoLabels=nOCvrwJihTtRPylKbxYVgHAcmWSazD,isFolder=nOCvrwJihTtRPylKbxYVgHAcmWSaps,params=nOCvrwJihTtRPylKbxYVgHAcmWSaMN,isLink=nOCvrwJihTtRPylKbxYVgHAcmWSape)
  if nOCvrwJihTtRPylKbxYVgHAcmWSaMB:
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN['mode'] ='EPISODE' 
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN['programcode']=nOCvrwJihTtRPylKbxYVgHAcmWSaze
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN['page'] =nOCvrwJihTtRPylKbxYVgHAcmWSaLj(nOCvrwJihTtRPylKbxYVgHAcmWSaMU+1)
   nOCvrwJihTtRPylKbxYVgHAcmWSaNf='[B]%s >>[/B]'%'다음 페이지'
   nOCvrwJihTtRPylKbxYVgHAcmWSazE=nOCvrwJihTtRPylKbxYVgHAcmWSaLj(nOCvrwJihTtRPylKbxYVgHAcmWSaMU+1)
   nOCvrwJihTtRPylKbxYVgHAcmWSaMG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.add_dir(nOCvrwJihTtRPylKbxYVgHAcmWSaNf,sublabel=nOCvrwJihTtRPylKbxYVgHAcmWSazE,img=nOCvrwJihTtRPylKbxYVgHAcmWSaMG,infoLabels=nOCvrwJihTtRPylKbxYVgHAcmWSapI,isFolder=nOCvrwJihTtRPylKbxYVgHAcmWSape,params=nOCvrwJihTtRPylKbxYVgHAcmWSaMN)
  xbmcplugin.setContent(nOCvrwJihTtRPylKbxYVgHAcmWSaGd._addon_handle,'episodes')
  if nOCvrwJihTtRPylKbxYVgHAcmWSaLq(nOCvrwJihTtRPylKbxYVgHAcmWSazs)>0:xbmcplugin.endOfDirectory(nOCvrwJihTtRPylKbxYVgHAcmWSaGd._addon_handle,cacheToDisc=nOCvrwJihTtRPylKbxYVgHAcmWSape)
 def dp_setEpOrderby(nOCvrwJihTtRPylKbxYVgHAcmWSaGd,nOCvrwJihTtRPylKbxYVgHAcmWSaMQ):
  nOCvrwJihTtRPylKbxYVgHAcmWSaNu =nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('orderby')
  nOCvrwJihTtRPylKbxYVgHAcmWSaGd.set_winEpisodeOrderby(nOCvrwJihTtRPylKbxYVgHAcmWSaNu)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(nOCvrwJihTtRPylKbxYVgHAcmWSaGd,nOCvrwJihTtRPylKbxYVgHAcmWSaMQ):
  nOCvrwJihTtRPylKbxYVgHAcmWSazk =nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('stype')
  nOCvrwJihTtRPylKbxYVgHAcmWSaNu =nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('orderby')
  nOCvrwJihTtRPylKbxYVgHAcmWSaMU=nOCvrwJihTtRPylKbxYVgHAcmWSapB(nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('page'))
  nOCvrwJihTtRPylKbxYVgHAcmWSaqp,nOCvrwJihTtRPylKbxYVgHAcmWSaMB=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.GetMovieList(nOCvrwJihTtRPylKbxYVgHAcmWSazk,nOCvrwJihTtRPylKbxYVgHAcmWSaNu,nOCvrwJihTtRPylKbxYVgHAcmWSaMU)
  for nOCvrwJihTtRPylKbxYVgHAcmWSaqL in nOCvrwJihTtRPylKbxYVgHAcmWSaqp:
   nOCvrwJihTtRPylKbxYVgHAcmWSaNf =nOCvrwJihTtRPylKbxYVgHAcmWSaqL.get('title')
   nOCvrwJihTtRPylKbxYVgHAcmWSaMs =nOCvrwJihTtRPylKbxYVgHAcmWSaqL.get('thumbnail')
   nOCvrwJihTtRPylKbxYVgHAcmWSazG =nOCvrwJihTtRPylKbxYVgHAcmWSaqL.get('synopsis')
   nOCvrwJihTtRPylKbxYVgHAcmWSaqM =nOCvrwJihTtRPylKbxYVgHAcmWSaqL.get('info_title')
   nOCvrwJihTtRPylKbxYVgHAcmWSazX =nOCvrwJihTtRPylKbxYVgHAcmWSaqL.get('year')
   nOCvrwJihTtRPylKbxYVgHAcmWSazM =nOCvrwJihTtRPylKbxYVgHAcmWSaqL.get('cast')
   nOCvrwJihTtRPylKbxYVgHAcmWSazq =nOCvrwJihTtRPylKbxYVgHAcmWSaqL.get('director')
   nOCvrwJihTtRPylKbxYVgHAcmWSazj =nOCvrwJihTtRPylKbxYVgHAcmWSaqL.get('info_genre')
   nOCvrwJihTtRPylKbxYVgHAcmWSaqD =nOCvrwJihTtRPylKbxYVgHAcmWSaqL.get('duration')
   nOCvrwJihTtRPylKbxYVgHAcmWSazL =nOCvrwJihTtRPylKbxYVgHAcmWSaqL.get('premiered')
   nOCvrwJihTtRPylKbxYVgHAcmWSaqj =nOCvrwJihTtRPylKbxYVgHAcmWSaqL.get('studio')
   nOCvrwJihTtRPylKbxYVgHAcmWSazp =nOCvrwJihTtRPylKbxYVgHAcmWSaqL.get('mpaa')
   nOCvrwJihTtRPylKbxYVgHAcmWSazD={'mediatype':'movie','title':nOCvrwJihTtRPylKbxYVgHAcmWSaqM,'year':nOCvrwJihTtRPylKbxYVgHAcmWSazX,'cast':nOCvrwJihTtRPylKbxYVgHAcmWSazM,'director':nOCvrwJihTtRPylKbxYVgHAcmWSazq,'genre':nOCvrwJihTtRPylKbxYVgHAcmWSazj,'duration':nOCvrwJihTtRPylKbxYVgHAcmWSaqD,'premiered':nOCvrwJihTtRPylKbxYVgHAcmWSazL,'studio':nOCvrwJihTtRPylKbxYVgHAcmWSaqj,'mpaa':nOCvrwJihTtRPylKbxYVgHAcmWSazp,'plot':nOCvrwJihTtRPylKbxYVgHAcmWSazG}
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN={'mode':'MOVIE','mediacode':nOCvrwJihTtRPylKbxYVgHAcmWSaqL.get('moviecode'),'stype':'movie','title':nOCvrwJihTtRPylKbxYVgHAcmWSaNf,'thumbnail':nOCvrwJihTtRPylKbxYVgHAcmWSaMs}
   if nOCvrwJihTtRPylKbxYVgHAcmWSaGd.get_settings_makebookmark():
    nOCvrwJihTtRPylKbxYVgHAcmWSazo={'videoid':nOCvrwJihTtRPylKbxYVgHAcmWSaqL.get('moviecode'),'vidtype':'movie','vtitle':nOCvrwJihTtRPylKbxYVgHAcmWSaqM,'vsubtitle':'',}
    nOCvrwJihTtRPylKbxYVgHAcmWSazQ=json.dumps(nOCvrwJihTtRPylKbxYVgHAcmWSazo)
    nOCvrwJihTtRPylKbxYVgHAcmWSazQ=urllib.parse.quote(nOCvrwJihTtRPylKbxYVgHAcmWSazQ)
    nOCvrwJihTtRPylKbxYVgHAcmWSazU='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(nOCvrwJihTtRPylKbxYVgHAcmWSazQ)
    nOCvrwJihTtRPylKbxYVgHAcmWSazI=[('(통합) 찜 영상에 추가',nOCvrwJihTtRPylKbxYVgHAcmWSazU)]
   else:
    nOCvrwJihTtRPylKbxYVgHAcmWSazI=nOCvrwJihTtRPylKbxYVgHAcmWSapI
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.add_dir(nOCvrwJihTtRPylKbxYVgHAcmWSaNf,sublabel='',img=nOCvrwJihTtRPylKbxYVgHAcmWSaMs,infoLabels=nOCvrwJihTtRPylKbxYVgHAcmWSazD,isFolder=nOCvrwJihTtRPylKbxYVgHAcmWSaps,params=nOCvrwJihTtRPylKbxYVgHAcmWSaMN,ContextMenu=nOCvrwJihTtRPylKbxYVgHAcmWSazI)
  if nOCvrwJihTtRPylKbxYVgHAcmWSaMB:
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN={}
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN['mode'] ='MOVIE_SUB' 
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN['orderby']=nOCvrwJihTtRPylKbxYVgHAcmWSaNu
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN['stype'] =nOCvrwJihTtRPylKbxYVgHAcmWSazk
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN['page'] =nOCvrwJihTtRPylKbxYVgHAcmWSaLj(nOCvrwJihTtRPylKbxYVgHAcmWSaMU+1)
   nOCvrwJihTtRPylKbxYVgHAcmWSaNf='[B]%s >>[/B]'%'다음 페이지'
   nOCvrwJihTtRPylKbxYVgHAcmWSazE=nOCvrwJihTtRPylKbxYVgHAcmWSaLj(nOCvrwJihTtRPylKbxYVgHAcmWSaMU+1)
   nOCvrwJihTtRPylKbxYVgHAcmWSaMG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.add_dir(nOCvrwJihTtRPylKbxYVgHAcmWSaNf,sublabel=nOCvrwJihTtRPylKbxYVgHAcmWSazE,img=nOCvrwJihTtRPylKbxYVgHAcmWSaMG,infoLabels=nOCvrwJihTtRPylKbxYVgHAcmWSapI,isFolder=nOCvrwJihTtRPylKbxYVgHAcmWSape,params=nOCvrwJihTtRPylKbxYVgHAcmWSaMN)
  xbmcplugin.setContent(nOCvrwJihTtRPylKbxYVgHAcmWSaGd._addon_handle,'movies')
  xbmcplugin.endOfDirectory(nOCvrwJihTtRPylKbxYVgHAcmWSaGd._addon_handle,cacheToDisc=nOCvrwJihTtRPylKbxYVgHAcmWSaps)
 def dp_4K_Movie_List(nOCvrwJihTtRPylKbxYVgHAcmWSaGd,nOCvrwJihTtRPylKbxYVgHAcmWSaMQ):
  nOCvrwJihTtRPylKbxYVgHAcmWSaMU=nOCvrwJihTtRPylKbxYVgHAcmWSapB(nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('page'))
  nOCvrwJihTtRPylKbxYVgHAcmWSaqp,nOCvrwJihTtRPylKbxYVgHAcmWSaMB=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.Get_UHD_MovieList(nOCvrwJihTtRPylKbxYVgHAcmWSaMU)
  for nOCvrwJihTtRPylKbxYVgHAcmWSaqL in nOCvrwJihTtRPylKbxYVgHAcmWSaqp:
   nOCvrwJihTtRPylKbxYVgHAcmWSaNf =nOCvrwJihTtRPylKbxYVgHAcmWSaqL.get('title')
   nOCvrwJihTtRPylKbxYVgHAcmWSaMs =nOCvrwJihTtRPylKbxYVgHAcmWSaqL.get('thumbnail')
   nOCvrwJihTtRPylKbxYVgHAcmWSazG =nOCvrwJihTtRPylKbxYVgHAcmWSaqL.get('synopsis')
   nOCvrwJihTtRPylKbxYVgHAcmWSaqM =nOCvrwJihTtRPylKbxYVgHAcmWSaqL.get('info_title')
   nOCvrwJihTtRPylKbxYVgHAcmWSazX =nOCvrwJihTtRPylKbxYVgHAcmWSaqL.get('year')
   nOCvrwJihTtRPylKbxYVgHAcmWSazM =nOCvrwJihTtRPylKbxYVgHAcmWSaqL.get('cast')
   nOCvrwJihTtRPylKbxYVgHAcmWSazq =nOCvrwJihTtRPylKbxYVgHAcmWSaqL.get('director')
   nOCvrwJihTtRPylKbxYVgHAcmWSazj =nOCvrwJihTtRPylKbxYVgHAcmWSaqL.get('info_genre')
   nOCvrwJihTtRPylKbxYVgHAcmWSaqD =nOCvrwJihTtRPylKbxYVgHAcmWSaqL.get('duration')
   nOCvrwJihTtRPylKbxYVgHAcmWSazL =nOCvrwJihTtRPylKbxYVgHAcmWSaqL.get('premiered')
   nOCvrwJihTtRPylKbxYVgHAcmWSaqj =nOCvrwJihTtRPylKbxYVgHAcmWSaqL.get('studio')
   nOCvrwJihTtRPylKbxYVgHAcmWSazp =nOCvrwJihTtRPylKbxYVgHAcmWSaqL.get('mpaa')
   nOCvrwJihTtRPylKbxYVgHAcmWSazD={'mediatype':'movie','title':nOCvrwJihTtRPylKbxYVgHAcmWSaqM,'year':nOCvrwJihTtRPylKbxYVgHAcmWSazX,'cast':nOCvrwJihTtRPylKbxYVgHAcmWSazM,'director':nOCvrwJihTtRPylKbxYVgHAcmWSazq,'genre':nOCvrwJihTtRPylKbxYVgHAcmWSazj,'duration':nOCvrwJihTtRPylKbxYVgHAcmWSaqD,'premiered':nOCvrwJihTtRPylKbxYVgHAcmWSazL,'studio':nOCvrwJihTtRPylKbxYVgHAcmWSaqj,'mpaa':nOCvrwJihTtRPylKbxYVgHAcmWSazp,'plot':nOCvrwJihTtRPylKbxYVgHAcmWSazG}
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN={'mode':'MOVIE','mediacode':nOCvrwJihTtRPylKbxYVgHAcmWSaqL.get('moviecode'),'stype':'movie','title':nOCvrwJihTtRPylKbxYVgHAcmWSaNf,'thumbnail':nOCvrwJihTtRPylKbxYVgHAcmWSaMs}
   if nOCvrwJihTtRPylKbxYVgHAcmWSaGd.get_settings_makebookmark():
    nOCvrwJihTtRPylKbxYVgHAcmWSazo={'videoid':nOCvrwJihTtRPylKbxYVgHAcmWSaqL.get('moviecode'),'vidtype':'movie','vtitle':nOCvrwJihTtRPylKbxYVgHAcmWSaqM,'vsubtitle':'',}
    nOCvrwJihTtRPylKbxYVgHAcmWSazQ=json.dumps(nOCvrwJihTtRPylKbxYVgHAcmWSazo)
    nOCvrwJihTtRPylKbxYVgHAcmWSazQ=urllib.parse.quote(nOCvrwJihTtRPylKbxYVgHAcmWSazQ)
    nOCvrwJihTtRPylKbxYVgHAcmWSazU='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(nOCvrwJihTtRPylKbxYVgHAcmWSazQ)
    nOCvrwJihTtRPylKbxYVgHAcmWSazI=[('(통합) 찜 영상에 추가',nOCvrwJihTtRPylKbxYVgHAcmWSazU)]
   else:
    nOCvrwJihTtRPylKbxYVgHAcmWSazI=nOCvrwJihTtRPylKbxYVgHAcmWSapI
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.add_dir(nOCvrwJihTtRPylKbxYVgHAcmWSaNf,sublabel='',img=nOCvrwJihTtRPylKbxYVgHAcmWSaMs,infoLabels=nOCvrwJihTtRPylKbxYVgHAcmWSazD,isFolder=nOCvrwJihTtRPylKbxYVgHAcmWSaps,params=nOCvrwJihTtRPylKbxYVgHAcmWSaMN,ContextMenu=nOCvrwJihTtRPylKbxYVgHAcmWSazI)
  if nOCvrwJihTtRPylKbxYVgHAcmWSaMB:
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN={}
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN['mode'] ='4K_MOVIE' 
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN['page'] =nOCvrwJihTtRPylKbxYVgHAcmWSaLj(nOCvrwJihTtRPylKbxYVgHAcmWSaMU+1)
   nOCvrwJihTtRPylKbxYVgHAcmWSaNf='[B]%s >>[/B]'%'다음 페이지'
   nOCvrwJihTtRPylKbxYVgHAcmWSazE=nOCvrwJihTtRPylKbxYVgHAcmWSaLj(nOCvrwJihTtRPylKbxYVgHAcmWSaMU+1)
   nOCvrwJihTtRPylKbxYVgHAcmWSaMG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.add_dir(nOCvrwJihTtRPylKbxYVgHAcmWSaNf,sublabel=nOCvrwJihTtRPylKbxYVgHAcmWSazE,img=nOCvrwJihTtRPylKbxYVgHAcmWSaMG,infoLabels=nOCvrwJihTtRPylKbxYVgHAcmWSapI,isFolder=nOCvrwJihTtRPylKbxYVgHAcmWSape,params=nOCvrwJihTtRPylKbxYVgHAcmWSaMN)
  xbmcplugin.setContent(nOCvrwJihTtRPylKbxYVgHAcmWSaGd._addon_handle,'movies')
  xbmcplugin.endOfDirectory(nOCvrwJihTtRPylKbxYVgHAcmWSaGd._addon_handle,cacheToDisc=nOCvrwJihTtRPylKbxYVgHAcmWSaps)
 def dp_Set_Bookmark(nOCvrwJihTtRPylKbxYVgHAcmWSaGd,nOCvrwJihTtRPylKbxYVgHAcmWSaMQ):
  nOCvrwJihTtRPylKbxYVgHAcmWSaqE=urllib.parse.unquote(nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('bm_param'))
  nOCvrwJihTtRPylKbxYVgHAcmWSaqE=json.loads(nOCvrwJihTtRPylKbxYVgHAcmWSaqE)
  nOCvrwJihTtRPylKbxYVgHAcmWSaqk =nOCvrwJihTtRPylKbxYVgHAcmWSaqE.get('videoid')
  nOCvrwJihTtRPylKbxYVgHAcmWSaqd =nOCvrwJihTtRPylKbxYVgHAcmWSaqE.get('vidtype')
  nOCvrwJihTtRPylKbxYVgHAcmWSaqu =nOCvrwJihTtRPylKbxYVgHAcmWSaqE.get('vtitle')
  nOCvrwJihTtRPylKbxYVgHAcmWSaqF =nOCvrwJihTtRPylKbxYVgHAcmWSaqE.get('vsubtitle')
  nOCvrwJihTtRPylKbxYVgHAcmWSaGQ=xbmcgui.Dialog()
  nOCvrwJihTtRPylKbxYVgHAcmWSaMk=nOCvrwJihTtRPylKbxYVgHAcmWSaGQ.yesno(__language__(30913).encode('utf8'),nOCvrwJihTtRPylKbxYVgHAcmWSaqu+' \n\n'+__language__(30914))
  if nOCvrwJihTtRPylKbxYVgHAcmWSaMk==nOCvrwJihTtRPylKbxYVgHAcmWSaps:return
  nOCvrwJihTtRPylKbxYVgHAcmWSaqf=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.GetBookmarkInfo(nOCvrwJihTtRPylKbxYVgHAcmWSaqk,nOCvrwJihTtRPylKbxYVgHAcmWSaqd)
  if nOCvrwJihTtRPylKbxYVgHAcmWSaqF!='':
   nOCvrwJihTtRPylKbxYVgHAcmWSaqf['saveinfo']['subtitle']=nOCvrwJihTtRPylKbxYVgHAcmWSaqF 
   if nOCvrwJihTtRPylKbxYVgHAcmWSaqd=='tvshow':nOCvrwJihTtRPylKbxYVgHAcmWSaqf['saveinfo']['infoLabels']['studio']=nOCvrwJihTtRPylKbxYVgHAcmWSaqF 
  nOCvrwJihTtRPylKbxYVgHAcmWSaqo=json.dumps(nOCvrwJihTtRPylKbxYVgHAcmWSaqf)
  nOCvrwJihTtRPylKbxYVgHAcmWSaqo=urllib.parse.quote(nOCvrwJihTtRPylKbxYVgHAcmWSaqo)
  nOCvrwJihTtRPylKbxYVgHAcmWSazU ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(nOCvrwJihTtRPylKbxYVgHAcmWSaqo)
  xbmc.executebuiltin(nOCvrwJihTtRPylKbxYVgHAcmWSazU)
 def dp_Search_Group(nOCvrwJihTtRPylKbxYVgHAcmWSaGd,nOCvrwJihTtRPylKbxYVgHAcmWSaMQ):
  if 'search_key' in nOCvrwJihTtRPylKbxYVgHAcmWSaMQ:
   nOCvrwJihTtRPylKbxYVgHAcmWSaqQ=nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('search_key')
  else:
   nOCvrwJihTtRPylKbxYVgHAcmWSaqQ=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not nOCvrwJihTtRPylKbxYVgHAcmWSaqQ:
    return
  for nOCvrwJihTtRPylKbxYVgHAcmWSaMo in nOCvrwJihTtRPylKbxYVgHAcmWSaGj:
   nOCvrwJihTtRPylKbxYVgHAcmWSaqU =nOCvrwJihTtRPylKbxYVgHAcmWSaMo.get('mode')
   nOCvrwJihTtRPylKbxYVgHAcmWSaMF=nOCvrwJihTtRPylKbxYVgHAcmWSaMo.get('stype')
   nOCvrwJihTtRPylKbxYVgHAcmWSaNf=nOCvrwJihTtRPylKbxYVgHAcmWSaMo.get('title')
   (nOCvrwJihTtRPylKbxYVgHAcmWSaqI,nOCvrwJihTtRPylKbxYVgHAcmWSaMB)=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.GetSearchList(nOCvrwJihTtRPylKbxYVgHAcmWSaqQ,1,nOCvrwJihTtRPylKbxYVgHAcmWSaMF)
   nOCvrwJihTtRPylKbxYVgHAcmWSaMj={'plot':'검색어 : '+nOCvrwJihTtRPylKbxYVgHAcmWSaqQ+'\n\n'+nOCvrwJihTtRPylKbxYVgHAcmWSaGd.Search_FreeList(nOCvrwJihTtRPylKbxYVgHAcmWSaqI)}
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN={'mode':nOCvrwJihTtRPylKbxYVgHAcmWSaqU,'stype':nOCvrwJihTtRPylKbxYVgHAcmWSaMF,'search_key':nOCvrwJihTtRPylKbxYVgHAcmWSaqQ,'page':'1',}
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.add_dir(nOCvrwJihTtRPylKbxYVgHAcmWSaNf,sublabel='',img='',infoLabels=nOCvrwJihTtRPylKbxYVgHAcmWSaMj,isFolder=nOCvrwJihTtRPylKbxYVgHAcmWSape,params=nOCvrwJihTtRPylKbxYVgHAcmWSaMN)
  if nOCvrwJihTtRPylKbxYVgHAcmWSaLq(nOCvrwJihTtRPylKbxYVgHAcmWSaGj)>0:xbmcplugin.endOfDirectory(nOCvrwJihTtRPylKbxYVgHAcmWSaGd._addon_handle,cacheToDisc=nOCvrwJihTtRPylKbxYVgHAcmWSape)
  nOCvrwJihTtRPylKbxYVgHAcmWSaGd.Save_Searched_List(nOCvrwJihTtRPylKbxYVgHAcmWSaqQ)
 def Search_FreeList(nOCvrwJihTtRPylKbxYVgHAcmWSaGd,nOCvrwJihTtRPylKbxYVgHAcmWSajX):
  nOCvrwJihTtRPylKbxYVgHAcmWSaqB=''
  nOCvrwJihTtRPylKbxYVgHAcmWSaqe=7
  try:
   if nOCvrwJihTtRPylKbxYVgHAcmWSaLq(nOCvrwJihTtRPylKbxYVgHAcmWSajX)==0:return '검색결과 없음'
   for i in nOCvrwJihTtRPylKbxYVgHAcmWSaLX(nOCvrwJihTtRPylKbxYVgHAcmWSaLq(nOCvrwJihTtRPylKbxYVgHAcmWSajX)):
    if i>=nOCvrwJihTtRPylKbxYVgHAcmWSaqe:
     nOCvrwJihTtRPylKbxYVgHAcmWSaqB=nOCvrwJihTtRPylKbxYVgHAcmWSaqB+'...'
     break
    nOCvrwJihTtRPylKbxYVgHAcmWSaqB=nOCvrwJihTtRPylKbxYVgHAcmWSaqB+nOCvrwJihTtRPylKbxYVgHAcmWSajX[i]['title']+'\n'
  except:
   return ''
  return nOCvrwJihTtRPylKbxYVgHAcmWSaqB
 def dp_Search_History(nOCvrwJihTtRPylKbxYVgHAcmWSaGd,nOCvrwJihTtRPylKbxYVgHAcmWSaMQ):
  nOCvrwJihTtRPylKbxYVgHAcmWSaqs=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.Load_List_File('search')
  for nOCvrwJihTtRPylKbxYVgHAcmWSajG in nOCvrwJihTtRPylKbxYVgHAcmWSaqs:
   nOCvrwJihTtRPylKbxYVgHAcmWSajN=nOCvrwJihTtRPylKbxYVgHAcmWSaLN(urllib.parse.parse_qsl(nOCvrwJihTtRPylKbxYVgHAcmWSajG))
   nOCvrwJihTtRPylKbxYVgHAcmWSajM=nOCvrwJihTtRPylKbxYVgHAcmWSajN.get('skey').strip()
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN={'mode':'SEARCH_GROUP','search_key':nOCvrwJihTtRPylKbxYVgHAcmWSajM,}
   nOCvrwJihTtRPylKbxYVgHAcmWSajz={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':nOCvrwJihTtRPylKbxYVgHAcmWSajM,'vType':'-',}
   nOCvrwJihTtRPylKbxYVgHAcmWSajq=urllib.parse.urlencode(nOCvrwJihTtRPylKbxYVgHAcmWSajz)
   nOCvrwJihTtRPylKbxYVgHAcmWSazI=[('선택된 검색어 ( %s ) 삭제'%(nOCvrwJihTtRPylKbxYVgHAcmWSajM),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(nOCvrwJihTtRPylKbxYVgHAcmWSajq))]
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.add_dir(nOCvrwJihTtRPylKbxYVgHAcmWSajM,sublabel='',img=nOCvrwJihTtRPylKbxYVgHAcmWSapI,infoLabels=nOCvrwJihTtRPylKbxYVgHAcmWSapI,isFolder=nOCvrwJihTtRPylKbxYVgHAcmWSape,params=nOCvrwJihTtRPylKbxYVgHAcmWSaMN,ContextMenu=nOCvrwJihTtRPylKbxYVgHAcmWSazI)
  nOCvrwJihTtRPylKbxYVgHAcmWSazD={'plot':'검색목록 전체를 삭제합니다.'}
  nOCvrwJihTtRPylKbxYVgHAcmWSaNf='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  nOCvrwJihTtRPylKbxYVgHAcmWSaMN={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  nOCvrwJihTtRPylKbxYVgHAcmWSaMG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  nOCvrwJihTtRPylKbxYVgHAcmWSaGd.add_dir(nOCvrwJihTtRPylKbxYVgHAcmWSaNf,sublabel='',img=nOCvrwJihTtRPylKbxYVgHAcmWSaMG,infoLabels=nOCvrwJihTtRPylKbxYVgHAcmWSazD,isFolder=nOCvrwJihTtRPylKbxYVgHAcmWSaps,params=nOCvrwJihTtRPylKbxYVgHAcmWSaMN,isLink=nOCvrwJihTtRPylKbxYVgHAcmWSape)
  xbmcplugin.endOfDirectory(nOCvrwJihTtRPylKbxYVgHAcmWSaGd._addon_handle,cacheToDisc=nOCvrwJihTtRPylKbxYVgHAcmWSaps)
 def dp_Search_List(nOCvrwJihTtRPylKbxYVgHAcmWSaGd,nOCvrwJihTtRPylKbxYVgHAcmWSaMQ):
  nOCvrwJihTtRPylKbxYVgHAcmWSaMU =nOCvrwJihTtRPylKbxYVgHAcmWSapB(nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('page'))
  nOCvrwJihTtRPylKbxYVgHAcmWSaMF =nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('stype')
  if 'search_key' in nOCvrwJihTtRPylKbxYVgHAcmWSaMQ:
   nOCvrwJihTtRPylKbxYVgHAcmWSaqQ=nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('search_key')
  else:
   nOCvrwJihTtRPylKbxYVgHAcmWSaqQ=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not nOCvrwJihTtRPylKbxYVgHAcmWSaqQ:
    xbmcplugin.endOfDirectory(nOCvrwJihTtRPylKbxYVgHAcmWSaGd._addon_handle)
    return
  nOCvrwJihTtRPylKbxYVgHAcmWSaqI,nOCvrwJihTtRPylKbxYVgHAcmWSaMB=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.GetSearchList(nOCvrwJihTtRPylKbxYVgHAcmWSaqQ,nOCvrwJihTtRPylKbxYVgHAcmWSaMU,nOCvrwJihTtRPylKbxYVgHAcmWSaMF)
  for nOCvrwJihTtRPylKbxYVgHAcmWSajX in nOCvrwJihTtRPylKbxYVgHAcmWSaqI:
   nOCvrwJihTtRPylKbxYVgHAcmWSaNf =nOCvrwJihTtRPylKbxYVgHAcmWSajX.get('title')
   nOCvrwJihTtRPylKbxYVgHAcmWSaMs =nOCvrwJihTtRPylKbxYVgHAcmWSajX.get('thumbnail')
   nOCvrwJihTtRPylKbxYVgHAcmWSazG =nOCvrwJihTtRPylKbxYVgHAcmWSajX.get('synopsis')
   nOCvrwJihTtRPylKbxYVgHAcmWSajp =nOCvrwJihTtRPylKbxYVgHAcmWSajX.get('program')
   nOCvrwJihTtRPylKbxYVgHAcmWSazM =nOCvrwJihTtRPylKbxYVgHAcmWSajX.get('cast')
   nOCvrwJihTtRPylKbxYVgHAcmWSazq =nOCvrwJihTtRPylKbxYVgHAcmWSajX.get('director')
   nOCvrwJihTtRPylKbxYVgHAcmWSazj=nOCvrwJihTtRPylKbxYVgHAcmWSajX.get('info_genre')
   nOCvrwJihTtRPylKbxYVgHAcmWSaqD =nOCvrwJihTtRPylKbxYVgHAcmWSajX.get('duration')
   nOCvrwJihTtRPylKbxYVgHAcmWSazp =nOCvrwJihTtRPylKbxYVgHAcmWSajX.get('mpaa')
   nOCvrwJihTtRPylKbxYVgHAcmWSazX =nOCvrwJihTtRPylKbxYVgHAcmWSajX.get('year')
   nOCvrwJihTtRPylKbxYVgHAcmWSaqz =nOCvrwJihTtRPylKbxYVgHAcmWSajX.get('aired')
   nOCvrwJihTtRPylKbxYVgHAcmWSazD={'mediatype':'tvshow' if nOCvrwJihTtRPylKbxYVgHAcmWSaMF=='vod' else 'movie','title':nOCvrwJihTtRPylKbxYVgHAcmWSaNf,'cast':nOCvrwJihTtRPylKbxYVgHAcmWSazM,'director':nOCvrwJihTtRPylKbxYVgHAcmWSazq,'genre':nOCvrwJihTtRPylKbxYVgHAcmWSazj,'duration':nOCvrwJihTtRPylKbxYVgHAcmWSaqD,'mpaa':nOCvrwJihTtRPylKbxYVgHAcmWSazp,'year':nOCvrwJihTtRPylKbxYVgHAcmWSazX,'aired':nOCvrwJihTtRPylKbxYVgHAcmWSaqz,'plot':'%s\n\n%s'%(nOCvrwJihTtRPylKbxYVgHAcmWSaNf,nOCvrwJihTtRPylKbxYVgHAcmWSazG)}
   if nOCvrwJihTtRPylKbxYVgHAcmWSaMF=='vod':
    nOCvrwJihTtRPylKbxYVgHAcmWSaqk=nOCvrwJihTtRPylKbxYVgHAcmWSajX.get('program')
    nOCvrwJihTtRPylKbxYVgHAcmWSaqd='tvshow'
    nOCvrwJihTtRPylKbxYVgHAcmWSaMN={'mode':'EPISODE','programcode':nOCvrwJihTtRPylKbxYVgHAcmWSaqk,'page':'1',}
    nOCvrwJihTtRPylKbxYVgHAcmWSaMz=nOCvrwJihTtRPylKbxYVgHAcmWSape
   else:
    nOCvrwJihTtRPylKbxYVgHAcmWSaqk=nOCvrwJihTtRPylKbxYVgHAcmWSajX.get('movie')
    nOCvrwJihTtRPylKbxYVgHAcmWSaqd='movie'
    nOCvrwJihTtRPylKbxYVgHAcmWSaMN={'mode':'MOVIE','mediacode':nOCvrwJihTtRPylKbxYVgHAcmWSaqk,'stype':'movie','title':nOCvrwJihTtRPylKbxYVgHAcmWSaNf,'thumbnail':nOCvrwJihTtRPylKbxYVgHAcmWSaMs,}
    nOCvrwJihTtRPylKbxYVgHAcmWSaMz=nOCvrwJihTtRPylKbxYVgHAcmWSaps
   if nOCvrwJihTtRPylKbxYVgHAcmWSaGd.get_settings_makebookmark():
    nOCvrwJihTtRPylKbxYVgHAcmWSazo={'videoid':nOCvrwJihTtRPylKbxYVgHAcmWSaqk,'vidtype':nOCvrwJihTtRPylKbxYVgHAcmWSaqd,'vtitle':nOCvrwJihTtRPylKbxYVgHAcmWSaNf,'vsubtitle':'',}
    nOCvrwJihTtRPylKbxYVgHAcmWSazQ=json.dumps(nOCvrwJihTtRPylKbxYVgHAcmWSazo)
    nOCvrwJihTtRPylKbxYVgHAcmWSazQ=urllib.parse.quote(nOCvrwJihTtRPylKbxYVgHAcmWSazQ)
    nOCvrwJihTtRPylKbxYVgHAcmWSazU='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(nOCvrwJihTtRPylKbxYVgHAcmWSazQ)
    nOCvrwJihTtRPylKbxYVgHAcmWSazI=[('(통합) 찜 영상에 추가',nOCvrwJihTtRPylKbxYVgHAcmWSazU)]
   else:
    nOCvrwJihTtRPylKbxYVgHAcmWSazI=nOCvrwJihTtRPylKbxYVgHAcmWSapI
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.add_dir(nOCvrwJihTtRPylKbxYVgHAcmWSaNf,sublabel='',img=nOCvrwJihTtRPylKbxYVgHAcmWSaMs,infoLabels=nOCvrwJihTtRPylKbxYVgHAcmWSazD,isFolder=nOCvrwJihTtRPylKbxYVgHAcmWSaMz,params=nOCvrwJihTtRPylKbxYVgHAcmWSaMN,isLink=nOCvrwJihTtRPylKbxYVgHAcmWSaps,ContextMenu=nOCvrwJihTtRPylKbxYVgHAcmWSazI)
  if nOCvrwJihTtRPylKbxYVgHAcmWSaMB:
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN['mode'] ='SEARCH' 
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN['search_key']=nOCvrwJihTtRPylKbxYVgHAcmWSaqQ
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN['page'] =nOCvrwJihTtRPylKbxYVgHAcmWSaLj(nOCvrwJihTtRPylKbxYVgHAcmWSaMU+1)
   nOCvrwJihTtRPylKbxYVgHAcmWSaNf='[B]%s >>[/B]'%'다음 페이지'
   nOCvrwJihTtRPylKbxYVgHAcmWSazE=nOCvrwJihTtRPylKbxYVgHAcmWSaLj(nOCvrwJihTtRPylKbxYVgHAcmWSaMU+1)
   nOCvrwJihTtRPylKbxYVgHAcmWSaMG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.add_dir(nOCvrwJihTtRPylKbxYVgHAcmWSaNf,sublabel=nOCvrwJihTtRPylKbxYVgHAcmWSazE,img=nOCvrwJihTtRPylKbxYVgHAcmWSaMG,infoLabels=nOCvrwJihTtRPylKbxYVgHAcmWSapI,isFolder=nOCvrwJihTtRPylKbxYVgHAcmWSape,params=nOCvrwJihTtRPylKbxYVgHAcmWSaMN)
  if nOCvrwJihTtRPylKbxYVgHAcmWSaMF=='movie':xbmcplugin.setContent(nOCvrwJihTtRPylKbxYVgHAcmWSaGd._addon_handle,'movies')
  else:xbmcplugin.setContent(nOCvrwJihTtRPylKbxYVgHAcmWSaGd._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(nOCvrwJihTtRPylKbxYVgHAcmWSaGd._addon_handle,cacheToDisc=nOCvrwJihTtRPylKbxYVgHAcmWSaps)
 def dp_History_Remove(nOCvrwJihTtRPylKbxYVgHAcmWSaGd,nOCvrwJihTtRPylKbxYVgHAcmWSaMQ):
  nOCvrwJihTtRPylKbxYVgHAcmWSajL=nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('delType')
  nOCvrwJihTtRPylKbxYVgHAcmWSajD =nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('sKey')
  nOCvrwJihTtRPylKbxYVgHAcmWSajE =nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('vType')
  nOCvrwJihTtRPylKbxYVgHAcmWSaGQ=xbmcgui.Dialog()
  if nOCvrwJihTtRPylKbxYVgHAcmWSajL=='SEARCH_ALL':
   nOCvrwJihTtRPylKbxYVgHAcmWSaMk=nOCvrwJihTtRPylKbxYVgHAcmWSaGQ.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif nOCvrwJihTtRPylKbxYVgHAcmWSajL=='SEARCH_ONE':
   nOCvrwJihTtRPylKbxYVgHAcmWSaMk=nOCvrwJihTtRPylKbxYVgHAcmWSaGQ.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif nOCvrwJihTtRPylKbxYVgHAcmWSajL=='WATCH_ALL':
   nOCvrwJihTtRPylKbxYVgHAcmWSaMk=nOCvrwJihTtRPylKbxYVgHAcmWSaGQ.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif nOCvrwJihTtRPylKbxYVgHAcmWSajL=='WATCH_ONE':
   nOCvrwJihTtRPylKbxYVgHAcmWSaMk=nOCvrwJihTtRPylKbxYVgHAcmWSaGQ.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if nOCvrwJihTtRPylKbxYVgHAcmWSaMk==nOCvrwJihTtRPylKbxYVgHAcmWSaps:sys.exit()
  if nOCvrwJihTtRPylKbxYVgHAcmWSajL=='SEARCH_ALL':
   if os.path.isfile(nOCvrwJihTtRPylKbxYVgHAcmWSaGk):os.remove(nOCvrwJihTtRPylKbxYVgHAcmWSaGk)
  elif nOCvrwJihTtRPylKbxYVgHAcmWSajL=='SEARCH_ONE':
   try:
    nOCvrwJihTtRPylKbxYVgHAcmWSajk=nOCvrwJihTtRPylKbxYVgHAcmWSaGk
    nOCvrwJihTtRPylKbxYVgHAcmWSajd=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.Load_List_File('search') 
    fp=nOCvrwJihTtRPylKbxYVgHAcmWSaLp(nOCvrwJihTtRPylKbxYVgHAcmWSajk,'w',-1,'utf-8')
    for nOCvrwJihTtRPylKbxYVgHAcmWSaju in nOCvrwJihTtRPylKbxYVgHAcmWSajd:
     nOCvrwJihTtRPylKbxYVgHAcmWSajF=nOCvrwJihTtRPylKbxYVgHAcmWSaLN(urllib.parse.parse_qsl(nOCvrwJihTtRPylKbxYVgHAcmWSaju))
     nOCvrwJihTtRPylKbxYVgHAcmWSajf=nOCvrwJihTtRPylKbxYVgHAcmWSajF.get('skey').strip()
     if nOCvrwJihTtRPylKbxYVgHAcmWSajD!=nOCvrwJihTtRPylKbxYVgHAcmWSajf:
      fp.write(nOCvrwJihTtRPylKbxYVgHAcmWSaju)
    fp.close()
   except:
    nOCvrwJihTtRPylKbxYVgHAcmWSapI
  elif nOCvrwJihTtRPylKbxYVgHAcmWSajL=='WATCH_ALL':
   nOCvrwJihTtRPylKbxYVgHAcmWSajk=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%nOCvrwJihTtRPylKbxYVgHAcmWSajE))
   if os.path.isfile(nOCvrwJihTtRPylKbxYVgHAcmWSajk):os.remove(nOCvrwJihTtRPylKbxYVgHAcmWSajk)
  elif nOCvrwJihTtRPylKbxYVgHAcmWSajL=='WATCH_ONE':
   nOCvrwJihTtRPylKbxYVgHAcmWSajk=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%nOCvrwJihTtRPylKbxYVgHAcmWSajE))
   try:
    nOCvrwJihTtRPylKbxYVgHAcmWSajd=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.Load_List_File(nOCvrwJihTtRPylKbxYVgHAcmWSajE) 
    fp=nOCvrwJihTtRPylKbxYVgHAcmWSaLp(nOCvrwJihTtRPylKbxYVgHAcmWSajk,'w',-1,'utf-8')
    for nOCvrwJihTtRPylKbxYVgHAcmWSaju in nOCvrwJihTtRPylKbxYVgHAcmWSajd:
     nOCvrwJihTtRPylKbxYVgHAcmWSajF=nOCvrwJihTtRPylKbxYVgHAcmWSaLN(urllib.parse.parse_qsl(nOCvrwJihTtRPylKbxYVgHAcmWSaju))
     nOCvrwJihTtRPylKbxYVgHAcmWSajf=nOCvrwJihTtRPylKbxYVgHAcmWSajF.get('code').strip()
     if nOCvrwJihTtRPylKbxYVgHAcmWSajD!=nOCvrwJihTtRPylKbxYVgHAcmWSajf:
      fp.write(nOCvrwJihTtRPylKbxYVgHAcmWSaju)
    fp.close()
   except:
    nOCvrwJihTtRPylKbxYVgHAcmWSapI
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(nOCvrwJihTtRPylKbxYVgHAcmWSaGd,nOCvrwJihTtRPylKbxYVgHAcmWSaMF): 
  try:
   if nOCvrwJihTtRPylKbxYVgHAcmWSaMF=='search':
    nOCvrwJihTtRPylKbxYVgHAcmWSajk=nOCvrwJihTtRPylKbxYVgHAcmWSaGk
   elif nOCvrwJihTtRPylKbxYVgHAcmWSaMF in['vod','movie']:
    nOCvrwJihTtRPylKbxYVgHAcmWSajk=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%nOCvrwJihTtRPylKbxYVgHAcmWSaMF))
   else:
    return[]
   fp=nOCvrwJihTtRPylKbxYVgHAcmWSaLp(nOCvrwJihTtRPylKbxYVgHAcmWSajk,'r',-1,'utf-8')
   nOCvrwJihTtRPylKbxYVgHAcmWSajo=fp.readlines()
   fp.close()
  except:
   nOCvrwJihTtRPylKbxYVgHAcmWSajo=[]
  return nOCvrwJihTtRPylKbxYVgHAcmWSajo
 def Save_Watched_List(nOCvrwJihTtRPylKbxYVgHAcmWSaGd,nOCvrwJihTtRPylKbxYVgHAcmWSaMF,nOCvrwJihTtRPylKbxYVgHAcmWSaGf):
  try:
   nOCvrwJihTtRPylKbxYVgHAcmWSajQ=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%nOCvrwJihTtRPylKbxYVgHAcmWSaMF))
   nOCvrwJihTtRPylKbxYVgHAcmWSajd=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.Load_List_File(nOCvrwJihTtRPylKbxYVgHAcmWSaMF) 
   fp=nOCvrwJihTtRPylKbxYVgHAcmWSaLp(nOCvrwJihTtRPylKbxYVgHAcmWSajQ,'w',-1,'utf-8')
   nOCvrwJihTtRPylKbxYVgHAcmWSajU=urllib.parse.urlencode(nOCvrwJihTtRPylKbxYVgHAcmWSaGf)
   nOCvrwJihTtRPylKbxYVgHAcmWSajU=nOCvrwJihTtRPylKbxYVgHAcmWSajU+'\n'
   fp.write(nOCvrwJihTtRPylKbxYVgHAcmWSajU)
   nOCvrwJihTtRPylKbxYVgHAcmWSajI=0
   for nOCvrwJihTtRPylKbxYVgHAcmWSaju in nOCvrwJihTtRPylKbxYVgHAcmWSajd:
    nOCvrwJihTtRPylKbxYVgHAcmWSajF=nOCvrwJihTtRPylKbxYVgHAcmWSaLN(urllib.parse.parse_qsl(nOCvrwJihTtRPylKbxYVgHAcmWSaju))
    nOCvrwJihTtRPylKbxYVgHAcmWSajB=nOCvrwJihTtRPylKbxYVgHAcmWSaGf.get('code').strip()
    nOCvrwJihTtRPylKbxYVgHAcmWSaje=nOCvrwJihTtRPylKbxYVgHAcmWSajF.get('code').strip()
    if nOCvrwJihTtRPylKbxYVgHAcmWSaMF=='vod' and nOCvrwJihTtRPylKbxYVgHAcmWSaGd.get_settings_direct_replay()==nOCvrwJihTtRPylKbxYVgHAcmWSape:
     nOCvrwJihTtRPylKbxYVgHAcmWSajB=nOCvrwJihTtRPylKbxYVgHAcmWSaGf.get('videoid').strip()
     nOCvrwJihTtRPylKbxYVgHAcmWSaje=nOCvrwJihTtRPylKbxYVgHAcmWSajF.get('videoid').strip()if nOCvrwJihTtRPylKbxYVgHAcmWSaje!=nOCvrwJihTtRPylKbxYVgHAcmWSapI else '-'
    if nOCvrwJihTtRPylKbxYVgHAcmWSajB!=nOCvrwJihTtRPylKbxYVgHAcmWSaje:
     fp.write(nOCvrwJihTtRPylKbxYVgHAcmWSaju)
     nOCvrwJihTtRPylKbxYVgHAcmWSajI+=1
     if nOCvrwJihTtRPylKbxYVgHAcmWSajI>=50:break
   fp.close()
  except:
   nOCvrwJihTtRPylKbxYVgHAcmWSapI
 def dp_Watch_List(nOCvrwJihTtRPylKbxYVgHAcmWSaGd,nOCvrwJihTtRPylKbxYVgHAcmWSaMQ):
  nOCvrwJihTtRPylKbxYVgHAcmWSaMF =nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('stype')
  nOCvrwJihTtRPylKbxYVgHAcmWSaNk=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.get_settings_direct_replay()
  if nOCvrwJihTtRPylKbxYVgHAcmWSaMF=='-':
   for nOCvrwJihTtRPylKbxYVgHAcmWSaMo in nOCvrwJihTtRPylKbxYVgHAcmWSaGq:
    nOCvrwJihTtRPylKbxYVgHAcmWSaNf=nOCvrwJihTtRPylKbxYVgHAcmWSaMo.get('title')
    nOCvrwJihTtRPylKbxYVgHAcmWSaMN={'mode':nOCvrwJihTtRPylKbxYVgHAcmWSaMo.get('mode'),'stype':nOCvrwJihTtRPylKbxYVgHAcmWSaMo.get('stype')}
    nOCvrwJihTtRPylKbxYVgHAcmWSaGd.add_dir(nOCvrwJihTtRPylKbxYVgHAcmWSaNf,sublabel='',img='',infoLabels=nOCvrwJihTtRPylKbxYVgHAcmWSapI,isFolder=nOCvrwJihTtRPylKbxYVgHAcmWSape,params=nOCvrwJihTtRPylKbxYVgHAcmWSaMN)
   if nOCvrwJihTtRPylKbxYVgHAcmWSaLq(nOCvrwJihTtRPylKbxYVgHAcmWSaGq)>0:xbmcplugin.endOfDirectory(nOCvrwJihTtRPylKbxYVgHAcmWSaGd._addon_handle)
  else:
   nOCvrwJihTtRPylKbxYVgHAcmWSajs=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.Load_List_File(nOCvrwJihTtRPylKbxYVgHAcmWSaMF)
   for nOCvrwJihTtRPylKbxYVgHAcmWSaXG in nOCvrwJihTtRPylKbxYVgHAcmWSajs:
    nOCvrwJihTtRPylKbxYVgHAcmWSajN=nOCvrwJihTtRPylKbxYVgHAcmWSaLN(urllib.parse.parse_qsl(nOCvrwJihTtRPylKbxYVgHAcmWSaXG))
    nOCvrwJihTtRPylKbxYVgHAcmWSaXN =nOCvrwJihTtRPylKbxYVgHAcmWSajN.get('code').strip()
    nOCvrwJihTtRPylKbxYVgHAcmWSaNf =nOCvrwJihTtRPylKbxYVgHAcmWSajN.get('title').strip()
    nOCvrwJihTtRPylKbxYVgHAcmWSaMs=nOCvrwJihTtRPylKbxYVgHAcmWSajN.get('img').strip()
    nOCvrwJihTtRPylKbxYVgHAcmWSaqk =nOCvrwJihTtRPylKbxYVgHAcmWSajN.get('videoid').strip()
    try:
     nOCvrwJihTtRPylKbxYVgHAcmWSaMs=nOCvrwJihTtRPylKbxYVgHAcmWSaMs.replace('\'','\"')
     nOCvrwJihTtRPylKbxYVgHAcmWSaMs=json.loads(nOCvrwJihTtRPylKbxYVgHAcmWSaMs)
    except:
     nOCvrwJihTtRPylKbxYVgHAcmWSapI
    nOCvrwJihTtRPylKbxYVgHAcmWSazD={}
    nOCvrwJihTtRPylKbxYVgHAcmWSazD['plot']=nOCvrwJihTtRPylKbxYVgHAcmWSaNf
    if nOCvrwJihTtRPylKbxYVgHAcmWSaMF=='vod':
     if nOCvrwJihTtRPylKbxYVgHAcmWSaNk==nOCvrwJihTtRPylKbxYVgHAcmWSaps or nOCvrwJihTtRPylKbxYVgHAcmWSaqk==nOCvrwJihTtRPylKbxYVgHAcmWSapI:
      nOCvrwJihTtRPylKbxYVgHAcmWSazD['mediatype']='tvshow'
      nOCvrwJihTtRPylKbxYVgHAcmWSaMN={'mode':'EPISODE','programcode':nOCvrwJihTtRPylKbxYVgHAcmWSaXN,'page':'1'}
      nOCvrwJihTtRPylKbxYVgHAcmWSaMz=nOCvrwJihTtRPylKbxYVgHAcmWSape
     else:
      nOCvrwJihTtRPylKbxYVgHAcmWSazD['mediatype']='episode'
      nOCvrwJihTtRPylKbxYVgHAcmWSaMN={'mode':'VOD','mediacode':nOCvrwJihTtRPylKbxYVgHAcmWSaqk,'stype':'vod','programcode':nOCvrwJihTtRPylKbxYVgHAcmWSaXN,'title':nOCvrwJihTtRPylKbxYVgHAcmWSaNf,'thumbnail':nOCvrwJihTtRPylKbxYVgHAcmWSaMs}
      nOCvrwJihTtRPylKbxYVgHAcmWSaMz=nOCvrwJihTtRPylKbxYVgHAcmWSaps
    else:
     nOCvrwJihTtRPylKbxYVgHAcmWSazD['mediatype']='movie'
     nOCvrwJihTtRPylKbxYVgHAcmWSaMN={'mode':'MOVIE','mediacode':nOCvrwJihTtRPylKbxYVgHAcmWSaXN,'stype':'movie','title':nOCvrwJihTtRPylKbxYVgHAcmWSaNf,'thumbnail':nOCvrwJihTtRPylKbxYVgHAcmWSaMs}
     nOCvrwJihTtRPylKbxYVgHAcmWSaMz=nOCvrwJihTtRPylKbxYVgHAcmWSaps
    nOCvrwJihTtRPylKbxYVgHAcmWSajz={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':nOCvrwJihTtRPylKbxYVgHAcmWSaXN,'vType':nOCvrwJihTtRPylKbxYVgHAcmWSaMF,}
    nOCvrwJihTtRPylKbxYVgHAcmWSajq=urllib.parse.urlencode(nOCvrwJihTtRPylKbxYVgHAcmWSajz)
    nOCvrwJihTtRPylKbxYVgHAcmWSazI=[('선택된 시청이력 ( %s ) 삭제'%(nOCvrwJihTtRPylKbxYVgHAcmWSaNf),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(nOCvrwJihTtRPylKbxYVgHAcmWSajq))]
    nOCvrwJihTtRPylKbxYVgHAcmWSaGd.add_dir(nOCvrwJihTtRPylKbxYVgHAcmWSaNf,sublabel='',img=nOCvrwJihTtRPylKbxYVgHAcmWSaMs,infoLabels=nOCvrwJihTtRPylKbxYVgHAcmWSazD,isFolder=nOCvrwJihTtRPylKbxYVgHAcmWSaMz,params=nOCvrwJihTtRPylKbxYVgHAcmWSaMN,ContextMenu=nOCvrwJihTtRPylKbxYVgHAcmWSazI)
   nOCvrwJihTtRPylKbxYVgHAcmWSazD={'plot':'시청목록을 삭제합니다.'}
   nOCvrwJihTtRPylKbxYVgHAcmWSaNf='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':nOCvrwJihTtRPylKbxYVgHAcmWSaMF,}
   nOCvrwJihTtRPylKbxYVgHAcmWSaMG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.add_dir(nOCvrwJihTtRPylKbxYVgHAcmWSaNf,sublabel='',img=nOCvrwJihTtRPylKbxYVgHAcmWSaMG,infoLabels=nOCvrwJihTtRPylKbxYVgHAcmWSazD,isFolder=nOCvrwJihTtRPylKbxYVgHAcmWSaps,params=nOCvrwJihTtRPylKbxYVgHAcmWSaMN,isLink=nOCvrwJihTtRPylKbxYVgHAcmWSape)
   if nOCvrwJihTtRPylKbxYVgHAcmWSaMF=='movie':xbmcplugin.setContent(nOCvrwJihTtRPylKbxYVgHAcmWSaGd._addon_handle,'movies')
   else:xbmcplugin.setContent(nOCvrwJihTtRPylKbxYVgHAcmWSaGd._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(nOCvrwJihTtRPylKbxYVgHAcmWSaGd._addon_handle,cacheToDisc=nOCvrwJihTtRPylKbxYVgHAcmWSaps)
 def Save_Searched_List(nOCvrwJihTtRPylKbxYVgHAcmWSaGd,nOCvrwJihTtRPylKbxYVgHAcmWSaqQ):
  try:
   nOCvrwJihTtRPylKbxYVgHAcmWSaXM=nOCvrwJihTtRPylKbxYVgHAcmWSaGk
   nOCvrwJihTtRPylKbxYVgHAcmWSajd=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.Load_List_File('search') 
   nOCvrwJihTtRPylKbxYVgHAcmWSaXz={'skey':nOCvrwJihTtRPylKbxYVgHAcmWSaqQ.strip()}
   fp=nOCvrwJihTtRPylKbxYVgHAcmWSaLp(nOCvrwJihTtRPylKbxYVgHAcmWSaXM,'w',-1,'utf-8')
   nOCvrwJihTtRPylKbxYVgHAcmWSajU=urllib.parse.urlencode(nOCvrwJihTtRPylKbxYVgHAcmWSaXz)
   nOCvrwJihTtRPylKbxYVgHAcmWSajU=nOCvrwJihTtRPylKbxYVgHAcmWSajU+'\n'
   fp.write(nOCvrwJihTtRPylKbxYVgHAcmWSajU)
   nOCvrwJihTtRPylKbxYVgHAcmWSajI=0
   for nOCvrwJihTtRPylKbxYVgHAcmWSaju in nOCvrwJihTtRPylKbxYVgHAcmWSajd:
    nOCvrwJihTtRPylKbxYVgHAcmWSajF=nOCvrwJihTtRPylKbxYVgHAcmWSaLN(urllib.parse.parse_qsl(nOCvrwJihTtRPylKbxYVgHAcmWSaju))
    nOCvrwJihTtRPylKbxYVgHAcmWSajB=nOCvrwJihTtRPylKbxYVgHAcmWSaXz.get('skey').strip()
    nOCvrwJihTtRPylKbxYVgHAcmWSaje=nOCvrwJihTtRPylKbxYVgHAcmWSajF.get('skey').strip()
    if nOCvrwJihTtRPylKbxYVgHAcmWSajB!=nOCvrwJihTtRPylKbxYVgHAcmWSaje:
     fp.write(nOCvrwJihTtRPylKbxYVgHAcmWSaju)
     nOCvrwJihTtRPylKbxYVgHAcmWSajI+=1
     if nOCvrwJihTtRPylKbxYVgHAcmWSajI>=50:break
   fp.close()
  except:
   nOCvrwJihTtRPylKbxYVgHAcmWSapI
 def play_VIDEO(nOCvrwJihTtRPylKbxYVgHAcmWSaGd,nOCvrwJihTtRPylKbxYVgHAcmWSaMQ):
  nOCvrwJihTtRPylKbxYVgHAcmWSaXq =nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('mediacode')
  nOCvrwJihTtRPylKbxYVgHAcmWSaMF =nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('stype')
  nOCvrwJihTtRPylKbxYVgHAcmWSaXj =nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('pvrmode')
  nOCvrwJihTtRPylKbxYVgHAcmWSaXp=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.get_selQuality(nOCvrwJihTtRPylKbxYVgHAcmWSaMF)
  nOCvrwJihTtRPylKbxYVgHAcmWSaGd.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(nOCvrwJihTtRPylKbxYVgHAcmWSaXq,nOCvrwJihTtRPylKbxYVgHAcmWSaLj(nOCvrwJihTtRPylKbxYVgHAcmWSaXp),nOCvrwJihTtRPylKbxYVgHAcmWSaMF,nOCvrwJihTtRPylKbxYVgHAcmWSaXj))
  nOCvrwJihTtRPylKbxYVgHAcmWSaXL=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.GetBroadURL(nOCvrwJihTtRPylKbxYVgHAcmWSaXq,nOCvrwJihTtRPylKbxYVgHAcmWSaXp,nOCvrwJihTtRPylKbxYVgHAcmWSaMF,nOCvrwJihTtRPylKbxYVgHAcmWSaXj,optUHD=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.get_settings_uhd())
  nOCvrwJihTtRPylKbxYVgHAcmWSaGd.addon_log('qt, stype, url : %s - %s - %s'%(nOCvrwJihTtRPylKbxYVgHAcmWSaLj(nOCvrwJihTtRPylKbxYVgHAcmWSaXp),nOCvrwJihTtRPylKbxYVgHAcmWSaMF,nOCvrwJihTtRPylKbxYVgHAcmWSaXL['streaming_url']))
  if nOCvrwJihTtRPylKbxYVgHAcmWSaXL['streaming_url']=='':
   if nOCvrwJihTtRPylKbxYVgHAcmWSaXL['error_msg']=='':
    nOCvrwJihTtRPylKbxYVgHAcmWSaGd.addon_noti(__language__(30908).encode('utf8'))
   else:
    nOCvrwJihTtRPylKbxYVgHAcmWSaGd.addon_noti(nOCvrwJihTtRPylKbxYVgHAcmWSaXL['error_msg'].encode('utf8'))
   return
  nOCvrwJihTtRPylKbxYVgHAcmWSaXD={'user-agent':nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.USER_AGENT}
  nOCvrwJihTtRPylKbxYVgHAcmWSaXE=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.makeDefaultCookies() 
  if nOCvrwJihTtRPylKbxYVgHAcmWSaXL['watermark'] !='':
   nOCvrwJihTtRPylKbxYVgHAcmWSaXD['x-tving-param1']=nOCvrwJihTtRPylKbxYVgHAcmWSaXL['watermarkKey']
   nOCvrwJihTtRPylKbxYVgHAcmWSaXD['x-tving-param2']=nOCvrwJihTtRPylKbxYVgHAcmWSaXL['watermark'] 
  nOCvrwJihTtRPylKbxYVgHAcmWSaGd.addon_log('streaming_url = {}'.format(nOCvrwJihTtRPylKbxYVgHAcmWSaXL['streaming_url']))
  nOCvrwJihTtRPylKbxYVgHAcmWSaGd.addon_log('drm_license   = {}'.format(nOCvrwJihTtRPylKbxYVgHAcmWSaXL['drm_license']))
  nOCvrwJihTtRPylKbxYVgHAcmWSaGd.addon_log('watermark     = {}'.format(nOCvrwJihTtRPylKbxYVgHAcmWSaXL['watermark']))
  nOCvrwJihTtRPylKbxYVgHAcmWSaGd.addon_log('watermarkKey  = {}'.format(nOCvrwJihTtRPylKbxYVgHAcmWSaXL['watermarkKey']))
  nOCvrwJihTtRPylKbxYVgHAcmWSaXk =nOCvrwJihTtRPylKbxYVgHAcmWSaps
  nOCvrwJihTtRPylKbxYVgHAcmWSaXd =nOCvrwJihTtRPylKbxYVgHAcmWSaXL['streaming_url'].find('Policy=')
  if nOCvrwJihTtRPylKbxYVgHAcmWSaXd!=-1:
   nOCvrwJihTtRPylKbxYVgHAcmWSaXu =nOCvrwJihTtRPylKbxYVgHAcmWSaXL['streaming_url'].split('?')[0]
   nOCvrwJihTtRPylKbxYVgHAcmWSaXF=nOCvrwJihTtRPylKbxYVgHAcmWSaLN(urllib.parse.parse_qsl(urllib.parse.urlsplit(nOCvrwJihTtRPylKbxYVgHAcmWSaXL['streaming_url']).query))
   nOCvrwJihTtRPylKbxYVgHAcmWSaXE['CloudFront-Policy'] =nOCvrwJihTtRPylKbxYVgHAcmWSaXF['Policy'] 
   nOCvrwJihTtRPylKbxYVgHAcmWSaXE['CloudFront-Signature'] =nOCvrwJihTtRPylKbxYVgHAcmWSaXF['Signature'] 
   nOCvrwJihTtRPylKbxYVgHAcmWSaXE['CloudFront-Key-Pair-Id']=nOCvrwJihTtRPylKbxYVgHAcmWSaXF['Key-Pair-Id'] 
   if 'quickvod-mcdn.tving.com' in nOCvrwJihTtRPylKbxYVgHAcmWSaXu and 1==2:
    nOCvrwJihTtRPylKbxYVgHAcmWSaXk=nOCvrwJihTtRPylKbxYVgHAcmWSape
    nOCvrwJihTtRPylKbxYVgHAcmWSaXf =nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    nOCvrwJihTtRPylKbxYVgHAcmWSaXo=nOCvrwJihTtRPylKbxYVgHAcmWSaXf.strftime('%Y-%m-%d-%H:%M:%S')
    if nOCvrwJihTtRPylKbxYVgHAcmWSapB(nOCvrwJihTtRPylKbxYVgHAcmWSaXo.replace('-','').replace(':',''))<nOCvrwJihTtRPylKbxYVgHAcmWSapB(nOCvrwJihTtRPylKbxYVgHAcmWSaXF['end'].replace('-','').replace(':','')):
     nOCvrwJihTtRPylKbxYVgHAcmWSaXF['end']=nOCvrwJihTtRPylKbxYVgHAcmWSaXo
     nOCvrwJihTtRPylKbxYVgHAcmWSaGd.addon_noti(__language__(30915).encode('utf8'))
    nOCvrwJihTtRPylKbxYVgHAcmWSaXu ='%s?%s'%(nOCvrwJihTtRPylKbxYVgHAcmWSaXu,urllib.parse.urlencode(nOCvrwJihTtRPylKbxYVgHAcmWSaXF,doseq=nOCvrwJihTtRPylKbxYVgHAcmWSape))
    nOCvrwJihTtRPylKbxYVgHAcmWSaXQ='{}|{}'.format(nOCvrwJihTtRPylKbxYVgHAcmWSaXu,nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.make_stream_header(nOCvrwJihTtRPylKbxYVgHAcmWSaXD,nOCvrwJihTtRPylKbxYVgHAcmWSaXE))
   else:
    nOCvrwJihTtRPylKbxYVgHAcmWSaXQ='{}|{}'.format(nOCvrwJihTtRPylKbxYVgHAcmWSaXL['streaming_url'],nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.make_stream_header(nOCvrwJihTtRPylKbxYVgHAcmWSaXD,nOCvrwJihTtRPylKbxYVgHAcmWSaXE))
  else:
   nOCvrwJihTtRPylKbxYVgHAcmWSaXQ='{}|{}'.format(nOCvrwJihTtRPylKbxYVgHAcmWSaXL['streaming_url'],nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.make_stream_header(nOCvrwJihTtRPylKbxYVgHAcmWSaXD,nOCvrwJihTtRPylKbxYVgHAcmWSaXE))
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.addon_log('if tmp_pos == -1')
  nOCvrwJihTtRPylKbxYVgHAcmWSaNq,nOCvrwJihTtRPylKbxYVgHAcmWSaNj=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.get_settings_proxyport()
  nOCvrwJihTtRPylKbxYVgHAcmWSaNz=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.get_settings_playback()
  nOCvrwJihTtRPylKbxYVgHAcmWSaXU=urllib.parse.urlparse(nOCvrwJihTtRPylKbxYVgHAcmWSaXL['streaming_url'])
  nOCvrwJihTtRPylKbxYVgHAcmWSaXU=nOCvrwJihTtRPylKbxYVgHAcmWSaXU.path.strip('/').split('/')
  nOCvrwJihTtRPylKbxYVgHAcmWSaXU=nOCvrwJihTtRPylKbxYVgHAcmWSaXU[nOCvrwJihTtRPylKbxYVgHAcmWSaLq(nOCvrwJihTtRPylKbxYVgHAcmWSaXU)-1] 
  if(nOCvrwJihTtRPylKbxYVgHAcmWSaNq and nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('mode')in['VOD','MOVIE']and nOCvrwJihTtRPylKbxYVgHAcmWSaXk==nOCvrwJihTtRPylKbxYVgHAcmWSaps and nOCvrwJihTtRPylKbxYVgHAcmWSaXL['drm_license']!=''):
   if nOCvrwJihTtRPylKbxYVgHAcmWSaXU.split('.')[1]=='mpd':
    nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.Tving_Parse_mpd(nOCvrwJihTtRPylKbxYVgHAcmWSaXL['streaming_url'],nOCvrwJihTtRPylKbxYVgHAcmWSaXL['watermarkKey'],nOCvrwJihTtRPylKbxYVgHAcmWSaXL['watermark'])
   else:
    nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.Tving_Parse_m3u8(nOCvrwJihTtRPylKbxYVgHAcmWSaXL['streaming_url'])
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.addon_log('xxx '+nOCvrwJihTtRPylKbxYVgHAcmWSaXL['streaming_url'])
   nOCvrwJihTtRPylKbxYVgHAcmWSaXI={'addon':'tvingm','playOption':nOCvrwJihTtRPylKbxYVgHAcmWSaNz,}
   nOCvrwJihTtRPylKbxYVgHAcmWSaXI=json.dumps(nOCvrwJihTtRPylKbxYVgHAcmWSaXI,separators=(',',':'))
   nOCvrwJihTtRPylKbxYVgHAcmWSaXI=base64.standard_b64encode(nOCvrwJihTtRPylKbxYVgHAcmWSaXI.encode()).decode('utf-8')
   nOCvrwJihTtRPylKbxYVgHAcmWSaXQ ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(nOCvrwJihTtRPylKbxYVgHAcmWSaNj,nOCvrwJihTtRPylKbxYVgHAcmWSaXQ,nOCvrwJihTtRPylKbxYVgHAcmWSaXI)
   nOCvrwJihTtRPylKbxYVgHAcmWSaXD['proxy-mini']=nOCvrwJihTtRPylKbxYVgHAcmWSaXI 
  nOCvrwJihTtRPylKbxYVgHAcmWSaGd.addon_log('surl(2) : {}'.format(nOCvrwJihTtRPylKbxYVgHAcmWSaXQ))
  nOCvrwJihTtRPylKbxYVgHAcmWSaXB=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.make_stream_header(nOCvrwJihTtRPylKbxYVgHAcmWSaXD,nOCvrwJihTtRPylKbxYVgHAcmWSaXE)
  nOCvrwJihTtRPylKbxYVgHAcmWSaXe=xbmcgui.ListItem(path=nOCvrwJihTtRPylKbxYVgHAcmWSaXQ)
  if nOCvrwJihTtRPylKbxYVgHAcmWSaXL['drm_license']!='':
   nOCvrwJihTtRPylKbxYVgHAcmWSaXs=nOCvrwJihTtRPylKbxYVgHAcmWSaXL['drm_license']
   nOCvrwJihTtRPylKbxYVgHAcmWSapG ='https://cj.drmkeyserver.com/widevine_license'
   nOCvrwJihTtRPylKbxYVgHAcmWSapN ='mpd'
   nOCvrwJihTtRPylKbxYVgHAcmWSapM ='com.widevine.alpha'
   nOCvrwJihTtRPylKbxYVgHAcmWSapz =inputstreamhelper.Helper(nOCvrwJihTtRPylKbxYVgHAcmWSapN,drm='widevine')
   if nOCvrwJihTtRPylKbxYVgHAcmWSapz.check_inputstream():
    nOCvrwJihTtRPylKbxYVgHAcmWSapq={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.USER_AGENT,'AcquireLicenseAssertion':nOCvrwJihTtRPylKbxYVgHAcmWSaXs,'Host':'cj.drmkeyserver.com',}
    nOCvrwJihTtRPylKbxYVgHAcmWSapj=nOCvrwJihTtRPylKbxYVgHAcmWSapG+'|'+urllib.parse.urlencode(nOCvrwJihTtRPylKbxYVgHAcmWSapq)+'|R{SSM}|'
    nOCvrwJihTtRPylKbxYVgHAcmWSaXe.setProperty('inputstream',nOCvrwJihTtRPylKbxYVgHAcmWSapz.inputstream_addon)
    nOCvrwJihTtRPylKbxYVgHAcmWSaXe.setProperty('inputstream.adaptive.manifest_type',nOCvrwJihTtRPylKbxYVgHAcmWSapN)
    nOCvrwJihTtRPylKbxYVgHAcmWSaXe.setProperty('inputstream.adaptive.license_type',nOCvrwJihTtRPylKbxYVgHAcmWSapM)
    nOCvrwJihTtRPylKbxYVgHAcmWSaXe.setProperty('inputstream.adaptive.license_key',nOCvrwJihTtRPylKbxYVgHAcmWSapj)
    nOCvrwJihTtRPylKbxYVgHAcmWSaXe.setProperty('inputstream.adaptive.stream_headers',nOCvrwJihTtRPylKbxYVgHAcmWSaXB)
  elif nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('mode')in['VOD','MOVIE']:
   nOCvrwJihTtRPylKbxYVgHAcmWSaXe.setContentLookup(nOCvrwJihTtRPylKbxYVgHAcmWSaps)
   nOCvrwJihTtRPylKbxYVgHAcmWSaXe.setMimeType('application/x-mpegURL')
   nOCvrwJihTtRPylKbxYVgHAcmWSaXe.setProperty('inputstream','inputstream.adaptive')
   nOCvrwJihTtRPylKbxYVgHAcmWSaXe.setProperty('inputstream.adaptive.manifest_type','hls')
   nOCvrwJihTtRPylKbxYVgHAcmWSaXe.setProperty('inputstream.adaptive.stream_headers',nOCvrwJihTtRPylKbxYVgHAcmWSaXB)
  elif nOCvrwJihTtRPylKbxYVgHAcmWSaXk==nOCvrwJihTtRPylKbxYVgHAcmWSape:
   nOCvrwJihTtRPylKbxYVgHAcmWSaXe.setContentLookup(nOCvrwJihTtRPylKbxYVgHAcmWSaps)
   nOCvrwJihTtRPylKbxYVgHAcmWSaXe.setMimeType('application/x-mpegURL')
   nOCvrwJihTtRPylKbxYVgHAcmWSaXe.setProperty('inputstream','inputstream.ffmpegdirect')
   nOCvrwJihTtRPylKbxYVgHAcmWSaXe.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   nOCvrwJihTtRPylKbxYVgHAcmWSaXe.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   nOCvrwJihTtRPylKbxYVgHAcmWSaXe.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   nOCvrwJihTtRPylKbxYVgHAcmWSaXe.setProperty('ResumeTime','0')
   nOCvrwJihTtRPylKbxYVgHAcmWSaXe.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(nOCvrwJihTtRPylKbxYVgHAcmWSaGd._addon_handle,nOCvrwJihTtRPylKbxYVgHAcmWSape,nOCvrwJihTtRPylKbxYVgHAcmWSaXe)
  try:
   if nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('mode')in['VOD','MOVIE']and nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('title'):
    nOCvrwJihTtRPylKbxYVgHAcmWSaMN={'code':nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('programcode')if nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('mode')=='VOD' else nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('mediacode'),'img':nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('thumbnail'),'title':nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('title'),'videoid':nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('mediacode')}
    nOCvrwJihTtRPylKbxYVgHAcmWSaGd.Save_Watched_List(nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('stype'),nOCvrwJihTtRPylKbxYVgHAcmWSaMN)
  except:
   nOCvrwJihTtRPylKbxYVgHAcmWSapI
 def logout(nOCvrwJihTtRPylKbxYVgHAcmWSaGd):
  nOCvrwJihTtRPylKbxYVgHAcmWSaGQ=xbmcgui.Dialog()
  nOCvrwJihTtRPylKbxYVgHAcmWSaMk=nOCvrwJihTtRPylKbxYVgHAcmWSaGQ.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if nOCvrwJihTtRPylKbxYVgHAcmWSaMk==nOCvrwJihTtRPylKbxYVgHAcmWSaps:sys.exit()
  nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.Init_TV_Total()
  if os.path.isfile(nOCvrwJihTtRPylKbxYVgHAcmWSaGE):os.remove(nOCvrwJihTtRPylKbxYVgHAcmWSaGE)
  nOCvrwJihTtRPylKbxYVgHAcmWSaGd.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(nOCvrwJihTtRPylKbxYVgHAcmWSaGd):
  nOCvrwJihTtRPylKbxYVgHAcmWSapX =nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.Get_Now_Datetime()
  nOCvrwJihTtRPylKbxYVgHAcmWSapL=nOCvrwJihTtRPylKbxYVgHAcmWSapX+datetime.timedelta(days=nOCvrwJihTtRPylKbxYVgHAcmWSapB(__addon__.getSetting('cache_ttl')))
  (nOCvrwJihTtRPylKbxYVgHAcmWSaMp,nOCvrwJihTtRPylKbxYVgHAcmWSaML,nOCvrwJihTtRPylKbxYVgHAcmWSaMD,nOCvrwJihTtRPylKbxYVgHAcmWSaME)=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.get_settings_account()
  nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.Save_session_acount(nOCvrwJihTtRPylKbxYVgHAcmWSaMp,nOCvrwJihTtRPylKbxYVgHAcmWSaML,nOCvrwJihTtRPylKbxYVgHAcmWSaMD,nOCvrwJihTtRPylKbxYVgHAcmWSaME)
  nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.TV['account']['token_limit']=nOCvrwJihTtRPylKbxYVgHAcmWSapL.strftime('%Y%m%d')
  nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.JsonFile_Save(nOCvrwJihTtRPylKbxYVgHAcmWSaGE,nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.TV)
 def cookiefile_check(nOCvrwJihTtRPylKbxYVgHAcmWSaGd):
  nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.TV=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.JsonFile_Load(nOCvrwJihTtRPylKbxYVgHAcmWSaGE)
  if nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.TV=={}:
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.Init_TV_Total()
   return nOCvrwJihTtRPylKbxYVgHAcmWSaps
  if '_tving_token' not in nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.TV.get('cookies'):
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.Init_TV_Total()
   return nOCvrwJihTtRPylKbxYVgHAcmWSaps
  (nOCvrwJihTtRPylKbxYVgHAcmWSapD,nOCvrwJihTtRPylKbxYVgHAcmWSapE,nOCvrwJihTtRPylKbxYVgHAcmWSapk,nOCvrwJihTtRPylKbxYVgHAcmWSapd)=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.get_settings_account()
  (nOCvrwJihTtRPylKbxYVgHAcmWSapu,nOCvrwJihTtRPylKbxYVgHAcmWSapF,nOCvrwJihTtRPylKbxYVgHAcmWSapf,nOCvrwJihTtRPylKbxYVgHAcmWSapo)=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.Load_session_acount()
  if nOCvrwJihTtRPylKbxYVgHAcmWSapD!=nOCvrwJihTtRPylKbxYVgHAcmWSapu or nOCvrwJihTtRPylKbxYVgHAcmWSapE!=nOCvrwJihTtRPylKbxYVgHAcmWSapF or nOCvrwJihTtRPylKbxYVgHAcmWSapk!=nOCvrwJihTtRPylKbxYVgHAcmWSapf or nOCvrwJihTtRPylKbxYVgHAcmWSapd!=nOCvrwJihTtRPylKbxYVgHAcmWSapo:
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.Init_TV_Total()
   return nOCvrwJihTtRPylKbxYVgHAcmWSaps
  if nOCvrwJihTtRPylKbxYVgHAcmWSapB(nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>nOCvrwJihTtRPylKbxYVgHAcmWSapB(nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.TV['account']['token_limit']):
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.Init_TV_Total()
   return nOCvrwJihTtRPylKbxYVgHAcmWSaps
  return nOCvrwJihTtRPylKbxYVgHAcmWSape
 def dp_Global_Search(nOCvrwJihTtRPylKbxYVgHAcmWSaGd,nOCvrwJihTtRPylKbxYVgHAcmWSaMQ):
  nOCvrwJihTtRPylKbxYVgHAcmWSaqU=nOCvrwJihTtRPylKbxYVgHAcmWSaMQ.get('mode')
  if nOCvrwJihTtRPylKbxYVgHAcmWSaqU=='TOTAL_SEARCH':
   nOCvrwJihTtRPylKbxYVgHAcmWSapQ='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   nOCvrwJihTtRPylKbxYVgHAcmWSapQ='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(nOCvrwJihTtRPylKbxYVgHAcmWSapQ)
 def dp_Bookmark_Menu(nOCvrwJihTtRPylKbxYVgHAcmWSaGd,nOCvrwJihTtRPylKbxYVgHAcmWSaMQ):
  nOCvrwJihTtRPylKbxYVgHAcmWSapQ='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(nOCvrwJihTtRPylKbxYVgHAcmWSapQ)
 def dp_EuroLive_List(nOCvrwJihTtRPylKbxYVgHAcmWSaGd,nOCvrwJihTtRPylKbxYVgHAcmWSaMQ):
  nOCvrwJihTtRPylKbxYVgHAcmWSaMI=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.GetEuroChannelList()
  for nOCvrwJihTtRPylKbxYVgHAcmWSaMe in nOCvrwJihTtRPylKbxYVgHAcmWSaMI:
   nOCvrwJihTtRPylKbxYVgHAcmWSazf =nOCvrwJihTtRPylKbxYVgHAcmWSaMe.get('channel')
   nOCvrwJihTtRPylKbxYVgHAcmWSaNf =nOCvrwJihTtRPylKbxYVgHAcmWSaMe.get('title')
   nOCvrwJihTtRPylKbxYVgHAcmWSazE =nOCvrwJihTtRPylKbxYVgHAcmWSaMe.get('subtitle')
   nOCvrwJihTtRPylKbxYVgHAcmWSazD={'mediatype':'episode','title':nOCvrwJihTtRPylKbxYVgHAcmWSaNf,'plot':'%s\n%s'%(nOCvrwJihTtRPylKbxYVgHAcmWSaNf,nOCvrwJihTtRPylKbxYVgHAcmWSazE)}
   nOCvrwJihTtRPylKbxYVgHAcmWSaMN={'mode':'LIVE','mediacode':nOCvrwJihTtRPylKbxYVgHAcmWSazf,'stype':'onair',}
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.add_dir(nOCvrwJihTtRPylKbxYVgHAcmWSaNf,sublabel=nOCvrwJihTtRPylKbxYVgHAcmWSazE,img='',infoLabels=nOCvrwJihTtRPylKbxYVgHAcmWSazD,isFolder=nOCvrwJihTtRPylKbxYVgHAcmWSaps,params=nOCvrwJihTtRPylKbxYVgHAcmWSaMN)
  if nOCvrwJihTtRPylKbxYVgHAcmWSaLq(nOCvrwJihTtRPylKbxYVgHAcmWSaMI)>0:xbmcplugin.endOfDirectory(nOCvrwJihTtRPylKbxYVgHAcmWSaGd._addon_handle,cacheToDisc=nOCvrwJihTtRPylKbxYVgHAcmWSaps)
 def tving_main(nOCvrwJihTtRPylKbxYVgHAcmWSaGd):
  nOCvrwJihTtRPylKbxYVgHAcmWSaGd.TvingObj.KodiVersion=nOCvrwJihTtRPylKbxYVgHAcmWSapB(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  nOCvrwJihTtRPylKbxYVgHAcmWSaqU=nOCvrwJihTtRPylKbxYVgHAcmWSaGd.main_params.get('mode',nOCvrwJihTtRPylKbxYVgHAcmWSapI)
  if nOCvrwJihTtRPylKbxYVgHAcmWSaqU=='LOGOUT':
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.logout()
   return
  nOCvrwJihTtRPylKbxYVgHAcmWSaGd.login_main()
  if nOCvrwJihTtRPylKbxYVgHAcmWSaqU is nOCvrwJihTtRPylKbxYVgHAcmWSapI:
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.dp_Main_List()
  elif nOCvrwJihTtRPylKbxYVgHAcmWSaqU in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.dp_Title_Group(nOCvrwJihTtRPylKbxYVgHAcmWSaGd.main_params)
  elif nOCvrwJihTtRPylKbxYVgHAcmWSaqU in['GLOBAL_GROUP']:
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.dp_SubTitle_Group(nOCvrwJihTtRPylKbxYVgHAcmWSaGd.main_params)
  elif nOCvrwJihTtRPylKbxYVgHAcmWSaqU=='CHANNEL':
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.dp_LiveChannel_List(nOCvrwJihTtRPylKbxYVgHAcmWSaGd.main_params)
  elif nOCvrwJihTtRPylKbxYVgHAcmWSaqU in['LIVE','VOD','MOVIE']:
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.play_VIDEO(nOCvrwJihTtRPylKbxYVgHAcmWSaGd.main_params)
  elif nOCvrwJihTtRPylKbxYVgHAcmWSaqU=='PROGRAM':
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.dp_Program_List(nOCvrwJihTtRPylKbxYVgHAcmWSaGd.main_params)
  elif nOCvrwJihTtRPylKbxYVgHAcmWSaqU=='4K_PROGRAM':
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.dp_4K_Program_List(nOCvrwJihTtRPylKbxYVgHAcmWSaGd.main_params)
  elif nOCvrwJihTtRPylKbxYVgHAcmWSaqU=='ORI_PROGRAM':
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.dp_Ori_Program_List(nOCvrwJihTtRPylKbxYVgHAcmWSaGd.main_params)
  elif nOCvrwJihTtRPylKbxYVgHAcmWSaqU=='EPISODE':
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.dp_Episode_List(nOCvrwJihTtRPylKbxYVgHAcmWSaGd.main_params)
  elif nOCvrwJihTtRPylKbxYVgHAcmWSaqU=='MOVIE_SUB':
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.dp_Movie_List(nOCvrwJihTtRPylKbxYVgHAcmWSaGd.main_params)
  elif nOCvrwJihTtRPylKbxYVgHAcmWSaqU=='4K_MOVIE':
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.dp_4K_Movie_List(nOCvrwJihTtRPylKbxYVgHAcmWSaGd.main_params)
  elif nOCvrwJihTtRPylKbxYVgHAcmWSaqU=='SEARCH_GROUP':
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.dp_Search_Group(nOCvrwJihTtRPylKbxYVgHAcmWSaGd.main_params)
  elif nOCvrwJihTtRPylKbxYVgHAcmWSaqU in['SEARCH','LOCAL_SEARCH']:
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.dp_Search_List(nOCvrwJihTtRPylKbxYVgHAcmWSaGd.main_params)
  elif nOCvrwJihTtRPylKbxYVgHAcmWSaqU=='WATCH':
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.dp_Watch_List(nOCvrwJihTtRPylKbxYVgHAcmWSaGd.main_params)
  elif nOCvrwJihTtRPylKbxYVgHAcmWSaqU in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.dp_History_Remove(nOCvrwJihTtRPylKbxYVgHAcmWSaGd.main_params)
  elif nOCvrwJihTtRPylKbxYVgHAcmWSaqU=='ORDER_BY':
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.dp_setEpOrderby(nOCvrwJihTtRPylKbxYVgHAcmWSaGd.main_params)
  elif nOCvrwJihTtRPylKbxYVgHAcmWSaqU=='SET_BOOKMARK':
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.dp_Set_Bookmark(nOCvrwJihTtRPylKbxYVgHAcmWSaGd.main_params)
  elif nOCvrwJihTtRPylKbxYVgHAcmWSaqU in['TOTAL_SEARCH','TOTAL_HISTORY']:
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.dp_Global_Search(nOCvrwJihTtRPylKbxYVgHAcmWSaGd.main_params)
  elif nOCvrwJihTtRPylKbxYVgHAcmWSaqU=='SEARCH_HISTORY':
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.dp_Search_History(nOCvrwJihTtRPylKbxYVgHAcmWSaGd.main_params)
  elif nOCvrwJihTtRPylKbxYVgHAcmWSaqU=='MENU_BOOKMARK':
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.dp_Bookmark_Menu(nOCvrwJihTtRPylKbxYVgHAcmWSaGd.main_params)
  elif nOCvrwJihTtRPylKbxYVgHAcmWSaqU=='EURO_GROUP':
   nOCvrwJihTtRPylKbxYVgHAcmWSaGd.dp_EuroLive_List(nOCvrwJihTtRPylKbxYVgHAcmWSaGd.main_params)
  else:
   nOCvrwJihTtRPylKbxYVgHAcmWSapI
# Created by pyminifier (https://github.com/liftoff/pyminifier)
