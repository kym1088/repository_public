__author__="NightRain"
oCjQYpWJVRNFylmIhPBeiAMDfLukzc=print
oCjQYpWJVRNFylmIhPBeiAMDfLukzS=ImportError
oCjQYpWJVRNFylmIhPBeiAMDfLukzq=object
oCjQYpWJVRNFylmIhPBeiAMDfLukzE=None
oCjQYpWJVRNFylmIhPBeiAMDfLukzb=False
oCjQYpWJVRNFylmIhPBeiAMDfLuktO=str
oCjQYpWJVRNFylmIhPBeiAMDfLuktT=open
oCjQYpWJVRNFylmIhPBeiAMDfLuktv=True
oCjQYpWJVRNFylmIhPBeiAMDfLuktU=len
oCjQYpWJVRNFylmIhPBeiAMDfLuktn=int
oCjQYpWJVRNFylmIhPBeiAMDfLuktg=range
oCjQYpWJVRNFylmIhPBeiAMDfLuktX=bytes
oCjQYpWJVRNFylmIhPBeiAMDfLuktz=Exception
oCjQYpWJVRNFylmIhPBeiAMDfLuktw=dict
oCjQYpWJVRNFylmIhPBeiAMDfLuktd=list
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
import os
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
try:
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
 oCjQYpWJVRNFylmIhPBeiAMDfLukzc('Cryptodome')
except oCjQYpWJVRNFylmIhPBeiAMDfLukzS:
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
 oCjQYpWJVRNFylmIhPBeiAMDfLukzc('Crypto')
oCjQYpWJVRNFylmIhPBeiAMDfLukOv={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
oCjQYpWJVRNFylmIhPBeiAMDfLukOU ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
oCjQYpWJVRNFylmIhPBeiAMDfLukOn =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
oCjQYpWJVRNFylmIhPBeiAMDfLukOg=['TP2wgas1K9Q8F7B359108383','TPLYFLt9NxVcJjQhn7Ee0069','_tutB3583','authToken','cs','TSID','accessToken','refreshToken','_tving_token','GA360_USERTYPE_JSON','ADULT_CONFIRM_YN','LEGAL_CONFIRM_YN','TLPUDB35Qhn7',]
class oCjQYpWJVRNFylmIhPBeiAMDfLukOT(oCjQYpWJVRNFylmIhPBeiAMDfLukzq):
 def __init__(oCjQYpWJVRNFylmIhPBeiAMDfLukOX):
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.NETWORKCODE ='CSND0900'
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.OSCODE ='CSOD0900' 
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TELECODE ='CSCD0900'
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.SCREENCODE ='CSSD0100'
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.APIKEY_ATV ='f0f74595d2f123ffc362362e334aeb52' 
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.SCREENCODE_ATV ='CSSD1300' 
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.LIVE_LIMIT =20 
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.VOD_LIMIT =24 
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.EPISODE_LIMIT =30 
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.SEARCH_LIMIT =30 
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.MOVIE_LIMIT =24 
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.API_DOMAIN ='https://api.tving.com'
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN ='https://image.tving.com'
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.SEARCH_DOMAIN ='https://search-api.tving.com'
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.LOGIN_DOMAIN ='https://user.tving.com'
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.URL_DOMAIN ='https://www.tving.com'
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.MOVIE_LITE =['2610061','2610161','261062']
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.MODEL ='chrome_128.0.0.0' 
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.DEFAULT_HEADER ={'user-agent':oCjQYpWJVRNFylmIhPBeiAMDfLukOX.USER_AGENT}
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.COOKIE_FILE_NAME =''
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TV_SESSION_COOKIES1=''
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TV_SESSION_COOKIES2=''
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TV_STREAM_FILENAME =''
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TV_SESSION_TEXT1 =''
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TV_SESSION_TEXT2 =''
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.KodiVersion=20
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TV ={}
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.Init_TV_Total()
 def Init_TV_Total(oCjQYpWJVRNFylmIhPBeiAMDfLukOX):
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TV={'account':{},'cookies':{},}
 def callRequestCookies(oCjQYpWJVRNFylmIhPBeiAMDfLukOX,jobtype,oCjQYpWJVRNFylmIhPBeiAMDfLukTS,payload=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,json=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,params=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,headers=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,cookies=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,redirects=oCjQYpWJVRNFylmIhPBeiAMDfLukzb):
  oCjQYpWJVRNFylmIhPBeiAMDfLukOz=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.DEFAULT_HEADER
  if headers:oCjQYpWJVRNFylmIhPBeiAMDfLukOz.update(headers)
  if jobtype=='Get':
   oCjQYpWJVRNFylmIhPBeiAMDfLukOt=requests.get(oCjQYpWJVRNFylmIhPBeiAMDfLukTS,params=params,headers=oCjQYpWJVRNFylmIhPBeiAMDfLukOz,cookies=cookies,allow_redirects=redirects)
  else:
   oCjQYpWJVRNFylmIhPBeiAMDfLukOt=requests.post(oCjQYpWJVRNFylmIhPBeiAMDfLukTS,data=payload,json=json,params=params,headers=oCjQYpWJVRNFylmIhPBeiAMDfLukOz,cookies=cookies,allow_redirects=redirects)
  oCjQYpWJVRNFylmIhPBeiAMDfLukzc(oCjQYpWJVRNFylmIhPBeiAMDfLuktO(oCjQYpWJVRNFylmIhPBeiAMDfLukOt.status_code)+' - '+oCjQYpWJVRNFylmIhPBeiAMDfLukOt.url)
  return oCjQYpWJVRNFylmIhPBeiAMDfLukOt
 def JsonFile_Save(oCjQYpWJVRNFylmIhPBeiAMDfLukOX,filename,oCjQYpWJVRNFylmIhPBeiAMDfLukOw):
  if filename=='':return oCjQYpWJVRNFylmIhPBeiAMDfLukzb
  try:
   fp=oCjQYpWJVRNFylmIhPBeiAMDfLuktT(filename,'w',-1,'utf-8')
   json.dump(oCjQYpWJVRNFylmIhPBeiAMDfLukOw,fp,indent=4,ensure_ascii=oCjQYpWJVRNFylmIhPBeiAMDfLukzb)
   fp.close()
  except:
   return oCjQYpWJVRNFylmIhPBeiAMDfLukzb
  return oCjQYpWJVRNFylmIhPBeiAMDfLuktv
 def JsonFile_Load(oCjQYpWJVRNFylmIhPBeiAMDfLukOX,filename):
  if filename=='':return{}
  try:
   fp=oCjQYpWJVRNFylmIhPBeiAMDfLuktT(filename,'r',-1,'utf-8')
   oCjQYpWJVRNFylmIhPBeiAMDfLukOH=json.load(fp)
   fp.close()
  except:
   return{}
  return oCjQYpWJVRNFylmIhPBeiAMDfLukOH
 def TextFile_Save(oCjQYpWJVRNFylmIhPBeiAMDfLukOX,filename,resText):
  if filename=='':return oCjQYpWJVRNFylmIhPBeiAMDfLukzb
  try:
   fp=oCjQYpWJVRNFylmIhPBeiAMDfLuktT(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return oCjQYpWJVRNFylmIhPBeiAMDfLukzb
  return oCjQYpWJVRNFylmIhPBeiAMDfLuktv
 def Save_session_acount(oCjQYpWJVRNFylmIhPBeiAMDfLukOX,oCjQYpWJVRNFylmIhPBeiAMDfLukOK,oCjQYpWJVRNFylmIhPBeiAMDfLukOG,oCjQYpWJVRNFylmIhPBeiAMDfLukOa,oCjQYpWJVRNFylmIhPBeiAMDfLukOx):
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TV['account']['tvid'] =base64.standard_b64encode(oCjQYpWJVRNFylmIhPBeiAMDfLukOK.encode()).decode('utf-8')
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TV['account']['tvpw'] =base64.standard_b64encode(oCjQYpWJVRNFylmIhPBeiAMDfLukOG.encode()).decode('utf-8')
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TV['account']['tvtype']=oCjQYpWJVRNFylmIhPBeiAMDfLukOa 
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TV['account']['tvpf'] =oCjQYpWJVRNFylmIhPBeiAMDfLukOx 
 def Load_session_acount(oCjQYpWJVRNFylmIhPBeiAMDfLukOX):
  try:
   oCjQYpWJVRNFylmIhPBeiAMDfLukOK =base64.standard_b64decode(oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TV['account']['tvid']).decode('utf-8')
   oCjQYpWJVRNFylmIhPBeiAMDfLukOG =base64.standard_b64decode(oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TV['account']['tvpw']).decode('utf-8')
   oCjQYpWJVRNFylmIhPBeiAMDfLukOa=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TV['account']['tvtype']
   oCjQYpWJVRNFylmIhPBeiAMDfLukOx =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TV['account']['tvpf'] 
  except:
   return '','','0',0
  return oCjQYpWJVRNFylmIhPBeiAMDfLukOK,oCjQYpWJVRNFylmIhPBeiAMDfLukOG,oCjQYpWJVRNFylmIhPBeiAMDfLukOa,oCjQYpWJVRNFylmIhPBeiAMDfLukOx
 def make_stream_header(oCjQYpWJVRNFylmIhPBeiAMDfLukOX,oCjQYpWJVRNFylmIhPBeiAMDfLukOq,oCjQYpWJVRNFylmIhPBeiAMDfLukOb):
  oCjQYpWJVRNFylmIhPBeiAMDfLukOr=''
  if oCjQYpWJVRNFylmIhPBeiAMDfLukOb not in[{},oCjQYpWJVRNFylmIhPBeiAMDfLukzE,'']:
   oCjQYpWJVRNFylmIhPBeiAMDfLukOs=oCjQYpWJVRNFylmIhPBeiAMDfLuktU(oCjQYpWJVRNFylmIhPBeiAMDfLukOb)
   for oCjQYpWJVRNFylmIhPBeiAMDfLukOc,oCjQYpWJVRNFylmIhPBeiAMDfLukOS in oCjQYpWJVRNFylmIhPBeiAMDfLukOb.items():
    oCjQYpWJVRNFylmIhPBeiAMDfLukOr+='{}={}'.format(oCjQYpWJVRNFylmIhPBeiAMDfLukOc,oCjQYpWJVRNFylmIhPBeiAMDfLukOS)
    oCjQYpWJVRNFylmIhPBeiAMDfLukOs+=-1
    if oCjQYpWJVRNFylmIhPBeiAMDfLukOs>0:oCjQYpWJVRNFylmIhPBeiAMDfLukOr+='; '
   oCjQYpWJVRNFylmIhPBeiAMDfLukOq['cookie']=oCjQYpWJVRNFylmIhPBeiAMDfLukOr
  oCjQYpWJVRNFylmIhPBeiAMDfLukOE=''
  i=0
  for oCjQYpWJVRNFylmIhPBeiAMDfLukOc,oCjQYpWJVRNFylmIhPBeiAMDfLukOS in oCjQYpWJVRNFylmIhPBeiAMDfLukOq.items():
   i=i+1
   if i>1:oCjQYpWJVRNFylmIhPBeiAMDfLukOE+='&'
   oCjQYpWJVRNFylmIhPBeiAMDfLukOE+='{}={}'.format(oCjQYpWJVRNFylmIhPBeiAMDfLukOc,urllib.parse.quote(oCjQYpWJVRNFylmIhPBeiAMDfLukOS))
  return oCjQYpWJVRNFylmIhPBeiAMDfLukOE
 def makeDefaultCookies(oCjQYpWJVRNFylmIhPBeiAMDfLukOX):
  oCjQYpWJVRNFylmIhPBeiAMDfLukOb={}
  for oCjQYpWJVRNFylmIhPBeiAMDfLukOc,oCjQYpWJVRNFylmIhPBeiAMDfLukOS in oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TV['cookies'].items():
   oCjQYpWJVRNFylmIhPBeiAMDfLukOb[oCjQYpWJVRNFylmIhPBeiAMDfLukOc]=oCjQYpWJVRNFylmIhPBeiAMDfLukOS
  return oCjQYpWJVRNFylmIhPBeiAMDfLukOb
 def getDeviceStr(oCjQYpWJVRNFylmIhPBeiAMDfLukOX):
  oCjQYpWJVRNFylmIhPBeiAMDfLukTO=[]
  oCjQYpWJVRNFylmIhPBeiAMDfLukTO.append('Windows') 
  oCjQYpWJVRNFylmIhPBeiAMDfLukTO.append('Chrome') 
  oCjQYpWJVRNFylmIhPBeiAMDfLukTO.append('ko-KR') 
  oCjQYpWJVRNFylmIhPBeiAMDfLukTO.append('undefined') 
  oCjQYpWJVRNFylmIhPBeiAMDfLukTO.append('24') 
  oCjQYpWJVRNFylmIhPBeiAMDfLukTO.append(u'한국 표준시')
  oCjQYpWJVRNFylmIhPBeiAMDfLukTO.append('undefined') 
  oCjQYpWJVRNFylmIhPBeiAMDfLukTO.append('undefined') 
  oCjQYpWJVRNFylmIhPBeiAMDfLukTO.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  oCjQYpWJVRNFylmIhPBeiAMDfLukTv=''
  for oCjQYpWJVRNFylmIhPBeiAMDfLukTU in oCjQYpWJVRNFylmIhPBeiAMDfLukTO:
   oCjQYpWJVRNFylmIhPBeiAMDfLukTv+=oCjQYpWJVRNFylmIhPBeiAMDfLukTU+'|'
  return oCjQYpWJVRNFylmIhPBeiAMDfLukTv
 def GetDefaultParams(oCjQYpWJVRNFylmIhPBeiAMDfLukOX,uhd=oCjQYpWJVRNFylmIhPBeiAMDfLukzb):
  if uhd==oCjQYpWJVRNFylmIhPBeiAMDfLukzb:
   oCjQYpWJVRNFylmIhPBeiAMDfLukTn={'apiKey':oCjQYpWJVRNFylmIhPBeiAMDfLukOX.APIKEY,'networkCode':oCjQYpWJVRNFylmIhPBeiAMDfLukOX.NETWORKCODE,'osCode':oCjQYpWJVRNFylmIhPBeiAMDfLukOX.OSCODE,'teleCode':oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TELECODE,'screenCode':oCjQYpWJVRNFylmIhPBeiAMDfLukOX.SCREENCODE,}
  else:
   oCjQYpWJVRNFylmIhPBeiAMDfLukTn={'apiKey':oCjQYpWJVRNFylmIhPBeiAMDfLukOX.APIKEY_ATV,'networkCode':oCjQYpWJVRNFylmIhPBeiAMDfLukOX.NETWORKCODE,'osCode':oCjQYpWJVRNFylmIhPBeiAMDfLukOX.OSCODE,'teleCode':oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TELECODE,'screenCode':oCjQYpWJVRNFylmIhPBeiAMDfLukOX.SCREENCODE_ATV,}
  return oCjQYpWJVRNFylmIhPBeiAMDfLukTn
 def GetNoCache(oCjQYpWJVRNFylmIhPBeiAMDfLukOX,timetype=1):
  if timetype==1:
   return oCjQYpWJVRNFylmIhPBeiAMDfLuktn(time.time())
  else:
   return oCjQYpWJVRNFylmIhPBeiAMDfLuktn(time.time()*1000)
 def GetUniqueid(oCjQYpWJVRNFylmIhPBeiAMDfLukOX,hValue=oCjQYpWJVRNFylmIhPBeiAMDfLukzE):
  if hValue:
   import hashlib
   oCjQYpWJVRNFylmIhPBeiAMDfLukTg=hashlib.sha1()
   oCjQYpWJVRNFylmIhPBeiAMDfLukTg.update(hValue.encode())
   oCjQYpWJVRNFylmIhPBeiAMDfLukTX=oCjQYpWJVRNFylmIhPBeiAMDfLukTg.hexdigest()[:8]
  else:
   oCjQYpWJVRNFylmIhPBeiAMDfLukTz=[0 for i in oCjQYpWJVRNFylmIhPBeiAMDfLuktg(256)]
   for i in oCjQYpWJVRNFylmIhPBeiAMDfLuktg(256):
    oCjQYpWJVRNFylmIhPBeiAMDfLukTz[i]='%02x'%(i)
   oCjQYpWJVRNFylmIhPBeiAMDfLukTt=oCjQYpWJVRNFylmIhPBeiAMDfLuktn(4294967295*random.random())|0
   oCjQYpWJVRNFylmIhPBeiAMDfLukTX=oCjQYpWJVRNFylmIhPBeiAMDfLukTz[255&oCjQYpWJVRNFylmIhPBeiAMDfLukTt]+oCjQYpWJVRNFylmIhPBeiAMDfLukTz[oCjQYpWJVRNFylmIhPBeiAMDfLukTt>>8&255]+oCjQYpWJVRNFylmIhPBeiAMDfLukTz[oCjQYpWJVRNFylmIhPBeiAMDfLukTt>>16&255]+oCjQYpWJVRNFylmIhPBeiAMDfLukTz[oCjQYpWJVRNFylmIhPBeiAMDfLukTt>>24&255]
  return oCjQYpWJVRNFylmIhPBeiAMDfLukTX
 def Web_DecryptKey(oCjQYpWJVRNFylmIhPBeiAMDfLukOX):
  oCjQYpWJVRNFylmIhPBeiAMDfLukTw=oCjQYpWJVRNFylmIhPBeiAMDfLuktX('kss2lym0kdw1lks3','utf-8')
  oCjQYpWJVRNFylmIhPBeiAMDfLukTd=oCjQYpWJVRNFylmIhPBeiAMDfLuktX('6yhlJ4WF9ZIj6I8n','utf-8')
  return oCjQYpWJVRNFylmIhPBeiAMDfLukTw,oCjQYpWJVRNFylmIhPBeiAMDfLukTd
 def Web_EncryptCiphertext(oCjQYpWJVRNFylmIhPBeiAMDfLukOX,oCjQYpWJVRNFylmIhPBeiAMDfLukTx):
  oCjQYpWJVRNFylmIhPBeiAMDfLukTH,oCjQYpWJVRNFylmIhPBeiAMDfLukTK=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.Web_DecryptKey()
  oCjQYpWJVRNFylmIhPBeiAMDfLukTG=AES.new(oCjQYpWJVRNFylmIhPBeiAMDfLukTH,AES.MODE_CBC,oCjQYpWJVRNFylmIhPBeiAMDfLukTK,)
  oCjQYpWJVRNFylmIhPBeiAMDfLukTa=oCjQYpWJVRNFylmIhPBeiAMDfLukTG.encrypt(Padding.pad(oCjQYpWJVRNFylmIhPBeiAMDfLukTx.encode('utf-8'),16))
  return base64.standard_b64encode(oCjQYpWJVRNFylmIhPBeiAMDfLukTa).decode('utf-8')
 def Web_DecryptPlaintext(oCjQYpWJVRNFylmIhPBeiAMDfLukOX,oCjQYpWJVRNFylmIhPBeiAMDfLukTa):
  oCjQYpWJVRNFylmIhPBeiAMDfLukTH,oCjQYpWJVRNFylmIhPBeiAMDfLukTK=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.Web_DecryptKey()
  oCjQYpWJVRNFylmIhPBeiAMDfLukTG=AES.new(oCjQYpWJVRNFylmIhPBeiAMDfLukTH,AES.MODE_CBC,oCjQYpWJVRNFylmIhPBeiAMDfLukTK,)
  oCjQYpWJVRNFylmIhPBeiAMDfLukTx=Padding.unpad(oCjQYpWJVRNFylmIhPBeiAMDfLukTG.decrypt(base64.standard_b64decode(oCjQYpWJVRNFylmIhPBeiAMDfLukTa)),16)
  return oCjQYpWJVRNFylmIhPBeiAMDfLukTx.decode('utf-8')
 def WebCookies_Load(oCjQYpWJVRNFylmIhPBeiAMDfLukOX,wc_file):
  try:
   fp=oCjQYpWJVRNFylmIhPBeiAMDfLuktT(wc_file,'r',-1,'utf-8')
   oCjQYpWJVRNFylmIhPBeiAMDfLukTr=fp.read()
   fp.close()
   oCjQYpWJVRNFylmIhPBeiAMDfLukTs=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.Web_DecryptPlaintext(oCjQYpWJVRNFylmIhPBeiAMDfLukTr)
   oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TV=json.loads(oCjQYpWJVRNFylmIhPBeiAMDfLukTs)
   oCjQYpWJVRNFylmIhPBeiAMDfLukTc =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.GetDeviceList()
   if oCjQYpWJVRNFylmIhPBeiAMDfLukTc not in['','-']:
    oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TV['cookies']['tving_uuid']=oCjQYpWJVRNFylmIhPBeiAMDfLukTc+'-'+oCjQYpWJVRNFylmIhPBeiAMDfLukOX.GetUniqueid(oCjQYpWJVRNFylmIhPBeiAMDfLukTc)
  except:
   return oCjQYpWJVRNFylmIhPBeiAMDfLukzb
  return oCjQYpWJVRNFylmIhPBeiAMDfLuktv
 def GetCredential2(oCjQYpWJVRNFylmIhPBeiAMDfLukOX,user_id,user_pw,login_type,user_pf):
  try:
   if base64.standard_b64encode(user_id.encode()).decode('utf-8')=='a3ltOTUxMDg4':
    oCjQYpWJVRNFylmIhPBeiAMDfLukTS='aHR0cDovL21pbmk5NTEwODguYXN1c2NvbW0uY29tOjE2NTcx'
   else:
    oCjQYpWJVRNFylmIhPBeiAMDfLukTS='aHR0cDovLzEzMS4xODYuMjAuMTE0OjE2NTcx'
   oCjQYpWJVRNFylmIhPBeiAMDfLukTq={'addon':'tvingm','method':'LOGIN','data':{'type':login_type,'id':user_id,'pw':user_pw,'pf':user_pf,}}
   oCjQYpWJVRNFylmIhPBeiAMDfLukTq=json.dumps(oCjQYpWJVRNFylmIhPBeiAMDfLukTq,separators=(',',':'))
   oCjQYpWJVRNFylmIhPBeiAMDfLukTq=base64.standard_b64encode(oCjQYpWJVRNFylmIhPBeiAMDfLukTq.encode()).decode('utf-8')
   oCjQYpWJVRNFylmIhPBeiAMDfLukOq={'proxy-mini':oCjQYpWJVRNFylmIhPBeiAMDfLukTq}
   oCjQYpWJVRNFylmIhPBeiAMDfLukTE=requests.get(base64.standard_b64decode(oCjQYpWJVRNFylmIhPBeiAMDfLukTS).decode('utf-8'),headers=oCjQYpWJVRNFylmIhPBeiAMDfLukOq)
   if oCjQYpWJVRNFylmIhPBeiAMDfLukTE.status_code!=200:
    oCjQYpWJVRNFylmIhPBeiAMDfLukOX.Init_TV_Total()
    return oCjQYpWJVRNFylmIhPBeiAMDfLukzb
   oCjQYpWJVRNFylmIhPBeiAMDfLukTb=base64.standard_b64decode(oCjQYpWJVRNFylmIhPBeiAMDfLukTE.text).decode('utf-8')
   oCjQYpWJVRNFylmIhPBeiAMDfLukTb=json.loads(oCjQYpWJVRNFylmIhPBeiAMDfLukTb)
   oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TV['cookies']=oCjQYpWJVRNFylmIhPBeiAMDfLukTb
  except oCjQYpWJVRNFylmIhPBeiAMDfLuktz as exception:
   oCjQYpWJVRNFylmIhPBeiAMDfLukzc(exception)
   oCjQYpWJVRNFylmIhPBeiAMDfLukOX.Init_TV_Total()
   return oCjQYpWJVRNFylmIhPBeiAMDfLukzb
  return oCjQYpWJVRNFylmIhPBeiAMDfLuktv
 def GetCredential(oCjQYpWJVRNFylmIhPBeiAMDfLukOX,user_id,user_pw,login_type,user_pf):
  from curl_cffi import requests
  oCjQYpWJVRNFylmIhPBeiAMDfLukvO='chrome' 
  oCjQYpWJVRNFylmIhPBeiAMDfLukvT=requests.Session()
  try:
   if login_type=='0':
    oCjQYpWJVRNFylmIhPBeiAMDfLukvU='https://user.tving.com/pc/user/otherLogin.tving?loginType=10&from=pc&csite=&isAuto=false&rtUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   else:
    oCjQYpWJVRNFylmIhPBeiAMDfLukvU='https://www.tving.com/account/login/tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   oCjQYpWJVRNFylmIhPBeiAMDfLukOq={'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7','accept-language':'ko-KR,ko;q=0.9','cache-control':'no-cache','pragma':'no-cache','priority':'u=0, i','referer':'https://www.tving.com/',}
   oCjQYpWJVRNFylmIhPBeiAMDfLukTE=oCjQYpWJVRNFylmIhPBeiAMDfLukvT.get(oCjQYpWJVRNFylmIhPBeiAMDfLukvU,headers=oCjQYpWJVRNFylmIhPBeiAMDfLukOq,impersonate=oCjQYpWJVRNFylmIhPBeiAMDfLukvO)
   oCjQYpWJVRNFylmIhPBeiAMDfLukzc('{} - {}'.format(oCjQYpWJVRNFylmIhPBeiAMDfLukTE.status_code,oCjQYpWJVRNFylmIhPBeiAMDfLukTE.url))
   for oCjQYpWJVRNFylmIhPBeiAMDfLukvn in oCjQYpWJVRNFylmIhPBeiAMDfLukTE.cookies.jar:
    oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TV['cookies'][oCjQYpWJVRNFylmIhPBeiAMDfLukvn.name]=oCjQYpWJVRNFylmIhPBeiAMDfLukvn.value
  except oCjQYpWJVRNFylmIhPBeiAMDfLuktz as exception:
   oCjQYpWJVRNFylmIhPBeiAMDfLukzc(exception)
   oCjQYpWJVRNFylmIhPBeiAMDfLukOX.Init_TV_Total()
   return oCjQYpWJVRNFylmIhPBeiAMDfLukzb
  try:
   oCjQYpWJVRNFylmIhPBeiAMDfLukvg=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   oCjQYpWJVRNFylmIhPBeiAMDfLukvX={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':oCjQYpWJVRNFylmIhPBeiAMDfLukzb,'cjOneCookie':'','kaptcha':'','returnUrl':'https://www.tving.com/onboarding','csite':'','rtUrl':'https%3A%2F%2Fwww.tving.com%2Fonboarding',}
   oCjQYpWJVRNFylmIhPBeiAMDfLukOq['referer']=oCjQYpWJVRNFylmIhPBeiAMDfLukvU
   oCjQYpWJVRNFylmIhPBeiAMDfLukTE=oCjQYpWJVRNFylmIhPBeiAMDfLukvT.post(url=oCjQYpWJVRNFylmIhPBeiAMDfLukvg,data=oCjQYpWJVRNFylmIhPBeiAMDfLukvX,headers=oCjQYpWJVRNFylmIhPBeiAMDfLukOq,impersonate=oCjQYpWJVRNFylmIhPBeiAMDfLukvO)
   oCjQYpWJVRNFylmIhPBeiAMDfLukzc('{} - {}'.format(oCjQYpWJVRNFylmIhPBeiAMDfLukTE.status_code,oCjQYpWJVRNFylmIhPBeiAMDfLukTE.url))
   for oCjQYpWJVRNFylmIhPBeiAMDfLukvn in oCjQYpWJVRNFylmIhPBeiAMDfLukTE.cookies.jar:
    oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TV['cookies'][oCjQYpWJVRNFylmIhPBeiAMDfLukvn.name]=oCjQYpWJVRNFylmIhPBeiAMDfLukvn.value
  except oCjQYpWJVRNFylmIhPBeiAMDfLuktz as exception:
   oCjQYpWJVRNFylmIhPBeiAMDfLukzc(exception)
   oCjQYpWJVRNFylmIhPBeiAMDfLukOX.Init_TV_Total()
   return oCjQYpWJVRNFylmIhPBeiAMDfLukzb
  oCjQYpWJVRNFylmIhPBeiAMDfLukvz=[]
  oCjQYpWJVRNFylmIhPBeiAMDfLukvt =''
  try:
   oCjQYpWJVRNFylmIhPBeiAMDfLukvw ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   oCjQYpWJVRNFylmIhPBeiAMDfLukOq['referer']=oCjQYpWJVRNFylmIhPBeiAMDfLukvg
   oCjQYpWJVRNFylmIhPBeiAMDfLukTE=oCjQYpWJVRNFylmIhPBeiAMDfLukvT.get(url=oCjQYpWJVRNFylmIhPBeiAMDfLukvw,data=oCjQYpWJVRNFylmIhPBeiAMDfLukvX,headers=oCjQYpWJVRNFylmIhPBeiAMDfLukOq,impersonate=oCjQYpWJVRNFylmIhPBeiAMDfLukvO)
   oCjQYpWJVRNFylmIhPBeiAMDfLukzc('{} - {}'.format(oCjQYpWJVRNFylmIhPBeiAMDfLukTE.status_code,oCjQYpWJVRNFylmIhPBeiAMDfLukTE.url))
   for oCjQYpWJVRNFylmIhPBeiAMDfLukvn in oCjQYpWJVRNFylmIhPBeiAMDfLukTE.cookies.jar:
    oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TV['cookies'][oCjQYpWJVRNFylmIhPBeiAMDfLukvn.name]=oCjQYpWJVRNFylmIhPBeiAMDfLukvn.value
   oCjQYpWJVRNFylmIhPBeiAMDfLukvz =re.findall('data-profile-no="\d+"',oCjQYpWJVRNFylmIhPBeiAMDfLukTE.text)
   for i in oCjQYpWJVRNFylmIhPBeiAMDfLuktg(oCjQYpWJVRNFylmIhPBeiAMDfLuktU(oCjQYpWJVRNFylmIhPBeiAMDfLukvz)):
    oCjQYpWJVRNFylmIhPBeiAMDfLukvd =oCjQYpWJVRNFylmIhPBeiAMDfLukvz[i].replace('data-profile-no=','').replace('"','')
    oCjQYpWJVRNFylmIhPBeiAMDfLukvz[i]=oCjQYpWJVRNFylmIhPBeiAMDfLukvd
   oCjQYpWJVRNFylmIhPBeiAMDfLukvt=oCjQYpWJVRNFylmIhPBeiAMDfLukvz[user_pf]
  except oCjQYpWJVRNFylmIhPBeiAMDfLuktz as exception:
   oCjQYpWJVRNFylmIhPBeiAMDfLukzc(exception)
   oCjQYpWJVRNFylmIhPBeiAMDfLukOX.Init_TV_Total()
   return oCjQYpWJVRNFylmIhPBeiAMDfLukzb
  try:
   oCjQYpWJVRNFylmIhPBeiAMDfLukvH ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   oCjQYpWJVRNFylmIhPBeiAMDfLukOq['referer']=oCjQYpWJVRNFylmIhPBeiAMDfLukvw
   oCjQYpWJVRNFylmIhPBeiAMDfLukvX={'profileNo':oCjQYpWJVRNFylmIhPBeiAMDfLukvt}
   oCjQYpWJVRNFylmIhPBeiAMDfLukTE=oCjQYpWJVRNFylmIhPBeiAMDfLukvT.post(url=oCjQYpWJVRNFylmIhPBeiAMDfLukvH,data=oCjQYpWJVRNFylmIhPBeiAMDfLukvX,headers=oCjQYpWJVRNFylmIhPBeiAMDfLukOq,impersonate=oCjQYpWJVRNFylmIhPBeiAMDfLukvO)
   oCjQYpWJVRNFylmIhPBeiAMDfLukzc('{} - {}'.format(oCjQYpWJVRNFylmIhPBeiAMDfLukTE.status_code,oCjQYpWJVRNFylmIhPBeiAMDfLukTE.url))
   for oCjQYpWJVRNFylmIhPBeiAMDfLukvn in oCjQYpWJVRNFylmIhPBeiAMDfLukTE.cookies.jar:
    oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TV['cookies'][oCjQYpWJVRNFylmIhPBeiAMDfLukvn.name]=oCjQYpWJVRNFylmIhPBeiAMDfLukvn.value
  except oCjQYpWJVRNFylmIhPBeiAMDfLuktz as exception:
   oCjQYpWJVRNFylmIhPBeiAMDfLukzc(exception)
   oCjQYpWJVRNFylmIhPBeiAMDfLukOX.Init_TV_Total()
   return oCjQYpWJVRNFylmIhPBeiAMDfLukzb
  oCjQYpWJVRNFylmIhPBeiAMDfLukTc =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.GetDeviceList()
  if oCjQYpWJVRNFylmIhPBeiAMDfLukTc not in['','-']:
   oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TV['cookies']['tving_uuid']=oCjQYpWJVRNFylmIhPBeiAMDfLukTc+'-'+oCjQYpWJVRNFylmIhPBeiAMDfLukOX.GetUniqueid(oCjQYpWJVRNFylmIhPBeiAMDfLukTc)
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.JsonFile_Save(oCjQYpWJVRNFylmIhPBeiAMDfLukOX.COOKIE_FILE_NAME,oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TV)
  return oCjQYpWJVRNFylmIhPBeiAMDfLuktv
 def GetDeviceList(oCjQYpWJVRNFylmIhPBeiAMDfLukOX):
  oCjQYpWJVRNFylmIhPBeiAMDfLukvK=[]
  oCjQYpWJVRNFylmIhPBeiAMDfLukvG='-'
  try:
   oCjQYpWJVRNFylmIhPBeiAMDfLukvw ='/v1/user/device/list'
   oCjQYpWJVRNFylmIhPBeiAMDfLukva=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.API_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukvw
   oCjQYpWJVRNFylmIhPBeiAMDfLukvx=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.GetDefaultParams()
   oCjQYpWJVRNFylmIhPBeiAMDfLukOb=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.makeDefaultCookies()
   oCjQYpWJVRNFylmIhPBeiAMDfLukTE=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.callRequestCookies('Get',oCjQYpWJVRNFylmIhPBeiAMDfLukva,payload=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,params=oCjQYpWJVRNFylmIhPBeiAMDfLukvx,headers=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,cookies=oCjQYpWJVRNFylmIhPBeiAMDfLukOb)
   oCjQYpWJVRNFylmIhPBeiAMDfLukvr=json.loads(oCjQYpWJVRNFylmIhPBeiAMDfLukTE.text)
   oCjQYpWJVRNFylmIhPBeiAMDfLukvK=oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']
   oCjQYpWJVRNFylmIhPBeiAMDfLukzc(oCjQYpWJVRNFylmIhPBeiAMDfLukvK)
   for oCjQYpWJVRNFylmIhPBeiAMDfLukvs in oCjQYpWJVRNFylmIhPBeiAMDfLukvK:
    if oCjQYpWJVRNFylmIhPBeiAMDfLukvs['model'].lower().startswith('pc'):
     oCjQYpWJVRNFylmIhPBeiAMDfLukvG=oCjQYpWJVRNFylmIhPBeiAMDfLukvs['uuid']
     break
   if oCjQYpWJVRNFylmIhPBeiAMDfLukvG=='-':
    oCjQYpWJVRNFylmIhPBeiAMDfLukvG=oCjQYpWJVRNFylmIhPBeiAMDfLuktO(oCjQYpWJVRNFylmIhPBeiAMDfLukOX.GetNoCache(timetype=1))
  except oCjQYpWJVRNFylmIhPBeiAMDfLuktz as exception:
   oCjQYpWJVRNFylmIhPBeiAMDfLukzc(exception)
  return oCjQYpWJVRNFylmIhPBeiAMDfLukvG
 def Get_Now_Datetime(oCjQYpWJVRNFylmIhPBeiAMDfLukOX):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(oCjQYpWJVRNFylmIhPBeiAMDfLukOX,mediacode,sel_quality,stype,pvrmode='-',optUHD=oCjQYpWJVRNFylmIhPBeiAMDfLukzb):
  oCjQYpWJVRNFylmIhPBeiAMDfLukvS ={'streaming_url':'','subtitleYn':oCjQYpWJVRNFylmIhPBeiAMDfLukzb,'error_msg':'','drm_server_url':'','drm_header_key':'','drm_header_value':'','url_filename':'','watermark':'','watermarkKey':'','qt_stream':'',}
  oCjQYpWJVRNFylmIhPBeiAMDfLukvG =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TV['cookies']['tving_uuid'].split('-')[0] 
  oCjQYpWJVRNFylmIhPBeiAMDfLukvq =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TV['cookies']['tving_uuid'] 
  try:
   oCjQYpWJVRNFylmIhPBeiAMDfLukvE=oCjQYpWJVRNFylmIhPBeiAMDfLuktO(oCjQYpWJVRNFylmIhPBeiAMDfLukOX.GetNoCache(1))
   if stype!='tvingtv':
    oCjQYpWJVRNFylmIhPBeiAMDfLukvw ='/v2/media/stream/info'
    oCjQYpWJVRNFylmIhPBeiAMDfLukvb=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.GetDefaultParams()
    oCjQYpWJVRNFylmIhPBeiAMDfLukvx={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':oCjQYpWJVRNFylmIhPBeiAMDfLukvq,'deviceInfo':'PC','noCache':oCjQYpWJVRNFylmIhPBeiAMDfLukvE,}
    oCjQYpWJVRNFylmIhPBeiAMDfLukvb.update(oCjQYpWJVRNFylmIhPBeiAMDfLukvx)
    oCjQYpWJVRNFylmIhPBeiAMDfLukTS=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.API_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukvw
    oCjQYpWJVRNFylmIhPBeiAMDfLukOb=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.makeDefaultCookies()
    oCjQYpWJVRNFylmIhPBeiAMDfLukTE=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.callRequestCookies('Get',oCjQYpWJVRNFylmIhPBeiAMDfLukTS,payload=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,params=oCjQYpWJVRNFylmIhPBeiAMDfLukvb,headers=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,cookies=oCjQYpWJVRNFylmIhPBeiAMDfLukOb)
    if oCjQYpWJVRNFylmIhPBeiAMDfLukTE.status_code!=200:
     oCjQYpWJVRNFylmIhPBeiAMDfLukvS['error_msg']='First Step - {} error'.format(oCjQYpWJVRNFylmIhPBeiAMDfLukTE.status_code)
     return oCjQYpWJVRNFylmIhPBeiAMDfLukvS
    oCjQYpWJVRNFylmIhPBeiAMDfLukvr=json.loads(oCjQYpWJVRNFylmIhPBeiAMDfLukTE.text)
    if oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']['result']['code']=='060':
     for oCjQYpWJVRNFylmIhPBeiAMDfLukOc,oCjQYpWJVRNFylmIhPBeiAMDfLukOS in oCjQYpWJVRNFylmIhPBeiAMDfLukOv.items():
      if oCjQYpWJVRNFylmIhPBeiAMDfLukOS==sel_quality:
       oCjQYpWJVRNFylmIhPBeiAMDfLukUO=oCjQYpWJVRNFylmIhPBeiAMDfLukOc
    elif oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']['result']['code']!='000':
     oCjQYpWJVRNFylmIhPBeiAMDfLukvS['error_msg']=oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']['result']['message']
     return oCjQYpWJVRNFylmIhPBeiAMDfLukvS
    else: 
     if not('stream' in oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']):return oCjQYpWJVRNFylmIhPBeiAMDfLukvS
     oCjQYpWJVRNFylmIhPBeiAMDfLukUT=[]
     for oCjQYpWJVRNFylmIhPBeiAMDfLukOc,oCjQYpWJVRNFylmIhPBeiAMDfLukOS in oCjQYpWJVRNFylmIhPBeiAMDfLukOv.items():
      for oCjQYpWJVRNFylmIhPBeiAMDfLukvs in oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']['stream']['quality']:
       if oCjQYpWJVRNFylmIhPBeiAMDfLukvs['active']=='Y' and oCjQYpWJVRNFylmIhPBeiAMDfLukvs['code']==oCjQYpWJVRNFylmIhPBeiAMDfLukOc:
        oCjQYpWJVRNFylmIhPBeiAMDfLukUT.append({oCjQYpWJVRNFylmIhPBeiAMDfLukOv.get(oCjQYpWJVRNFylmIhPBeiAMDfLukvs['code']):oCjQYpWJVRNFylmIhPBeiAMDfLukvs['code']})
     oCjQYpWJVRNFylmIhPBeiAMDfLukUO=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.CheckQuality(sel_quality,oCjQYpWJVRNFylmIhPBeiAMDfLukUT)
     try:
      if optUHD==oCjQYpWJVRNFylmIhPBeiAMDfLuktv and oCjQYpWJVRNFylmIhPBeiAMDfLukUO=='stream50' and 'stream_support_info' in oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']['content']['info']:
       if oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']['content']['info']['stream_support_info']!=oCjQYpWJVRNFylmIhPBeiAMDfLukzE:
        if 'stream70' in oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']['content']['info']['stream_support_info']:
         oCjQYpWJVRNFylmIhPBeiAMDfLukUO='stream70'
         oCjQYpWJVRNFylmIhPBeiAMDfLukvS['qt_stream']='stream70'
     except:
      pass
     try:
      if optUHD==oCjQYpWJVRNFylmIhPBeiAMDfLuktv and oCjQYpWJVRNFylmIhPBeiAMDfLukUO=='stream50' and 'stream' in oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']['content']['info']:
       if oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']['content']['info']['stream']!=oCjQYpWJVRNFylmIhPBeiAMDfLukzE:
        for oCjQYpWJVRNFylmIhPBeiAMDfLukvs in oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']['content']['info']['stream']:
         if oCjQYpWJVRNFylmIhPBeiAMDfLukvs['code']=='stream70':
          oCjQYpWJVRNFylmIhPBeiAMDfLukUO='stream70'
          break
     except:
      pass
   else:
    oCjQYpWJVRNFylmIhPBeiAMDfLukUO='stream40'
  except oCjQYpWJVRNFylmIhPBeiAMDfLuktz as exception:
   oCjQYpWJVRNFylmIhPBeiAMDfLukzc(exception)
   oCjQYpWJVRNFylmIhPBeiAMDfLukvS['error_msg']='First Step - except error'
   return oCjQYpWJVRNFylmIhPBeiAMDfLukvS
  oCjQYpWJVRNFylmIhPBeiAMDfLukvS['qt_stream']=oCjQYpWJVRNFylmIhPBeiAMDfLukUO
  oCjQYpWJVRNFylmIhPBeiAMDfLukzc(oCjQYpWJVRNFylmIhPBeiAMDfLukUO)
  try:
   oCjQYpWJVRNFylmIhPBeiAMDfLukvE=oCjQYpWJVRNFylmIhPBeiAMDfLuktO(oCjQYpWJVRNFylmIhPBeiAMDfLukOX.GetNoCache(1))
   oCjQYpWJVRNFylmIhPBeiAMDfLukvw ='/v3/media/stream/info'
   if oCjQYpWJVRNFylmIhPBeiAMDfLukvS['qt_stream']=='stream70':
    oCjQYpWJVRNFylmIhPBeiAMDfLukvb=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.GetDefaultParams(uhd=oCjQYpWJVRNFylmIhPBeiAMDfLuktv)
    oCjQYpWJVRNFylmIhPBeiAMDfLukvx={'mediaCode':mediacode,'deviceId':oCjQYpWJVRNFylmIhPBeiAMDfLukvG,'uuid':oCjQYpWJVRNFylmIhPBeiAMDfLukvq,'deviceInfo':'PC_Chrome WebView','streamCode':oCjQYpWJVRNFylmIhPBeiAMDfLukUO,'noCache':oCjQYpWJVRNFylmIhPBeiAMDfLukvE,'callingFrom':'HTML5','model':'chrome webview_96.0.4664.104','videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   else:
    oCjQYpWJVRNFylmIhPBeiAMDfLukvb=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.GetDefaultParams()
    oCjQYpWJVRNFylmIhPBeiAMDfLukvx={'mediaCode':mediacode,'deviceId':oCjQYpWJVRNFylmIhPBeiAMDfLukvG,'uuid':oCjQYpWJVRNFylmIhPBeiAMDfLukvq,'deviceInfo':'PC_Chrome','streamCode':oCjQYpWJVRNFylmIhPBeiAMDfLukUO,'noCache':oCjQYpWJVRNFylmIhPBeiAMDfLukvE,'callingFrom':'HTML5','model':oCjQYpWJVRNFylmIhPBeiAMDfLukOX.MODEL,'videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   oCjQYpWJVRNFylmIhPBeiAMDfLukvb.update(oCjQYpWJVRNFylmIhPBeiAMDfLukvx)
   oCjQYpWJVRNFylmIhPBeiAMDfLukTS=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.API_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukvw
   oCjQYpWJVRNFylmIhPBeiAMDfLukOb=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.makeDefaultCookies()
   oCjQYpWJVRNFylmIhPBeiAMDfLukTE=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.callRequestCookies('Post',oCjQYpWJVRNFylmIhPBeiAMDfLukTS,payload=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,params=oCjQYpWJVRNFylmIhPBeiAMDfLukvb,headers=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,cookies=oCjQYpWJVRNFylmIhPBeiAMDfLukOb,redirects=oCjQYpWJVRNFylmIhPBeiAMDfLuktv)
   oCjQYpWJVRNFylmIhPBeiAMDfLukvr=json.loads(oCjQYpWJVRNFylmIhPBeiAMDfLukTE.text)
   if oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']['result']['code']!='000':
    oCjQYpWJVRNFylmIhPBeiAMDfLukvS['error_msg']=oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']['result']['message']
    return oCjQYpWJVRNFylmIhPBeiAMDfLukvS
   oCjQYpWJVRNFylmIhPBeiAMDfLukUv=oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']['stream']
   if oCjQYpWJVRNFylmIhPBeiAMDfLukUv['drm_yn']=='Y':
    oCjQYpWJVRNFylmIhPBeiAMDfLukUn=oCjQYpWJVRNFylmIhPBeiAMDfLukUv['playback']['drm']['widevine']
    for oCjQYpWJVRNFylmIhPBeiAMDfLukUg in oCjQYpWJVRNFylmIhPBeiAMDfLukUv['playback']['drm']['license']['drm_license_data']:
     if oCjQYpWJVRNFylmIhPBeiAMDfLukUg['drm_type']=='Widevine':
      oCjQYpWJVRNFylmIhPBeiAMDfLukvS['drm_server_url'] =oCjQYpWJVRNFylmIhPBeiAMDfLukUg['drm_server_url']
      oCjQYpWJVRNFylmIhPBeiAMDfLukvS['drm_header_key'] =oCjQYpWJVRNFylmIhPBeiAMDfLukUg['drm_header_key']
      oCjQYpWJVRNFylmIhPBeiAMDfLukvS['drm_header_value']=oCjQYpWJVRNFylmIhPBeiAMDfLukUg['drm_header_value']
      break
   else:
    oCjQYpWJVRNFylmIhPBeiAMDfLukUn=oCjQYpWJVRNFylmIhPBeiAMDfLukUv['playback']['non_drm']
  except oCjQYpWJVRNFylmIhPBeiAMDfLuktz as exception:
   oCjQYpWJVRNFylmIhPBeiAMDfLukzc(exception)
   oCjQYpWJVRNFylmIhPBeiAMDfLukvS['error_msg']='Second Step - except error'
   return oCjQYpWJVRNFylmIhPBeiAMDfLukvS
  oCjQYpWJVRNFylmIhPBeiAMDfLukUX=oCjQYpWJVRNFylmIhPBeiAMDfLukvE
  oCjQYpWJVRNFylmIhPBeiAMDfLukUn=oCjQYpWJVRNFylmIhPBeiAMDfLukUn.split('|')[1]
  oCjQYpWJVRNFylmIhPBeiAMDfLukUn,oCjQYpWJVRNFylmIhPBeiAMDfLukUz,oCjQYpWJVRNFylmIhPBeiAMDfLukUt=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.Decrypt_Url(oCjQYpWJVRNFylmIhPBeiAMDfLukUn,mediacode,oCjQYpWJVRNFylmIhPBeiAMDfLukUX)
  oCjQYpWJVRNFylmIhPBeiAMDfLukvS['streaming_url']=oCjQYpWJVRNFylmIhPBeiAMDfLukUn
  oCjQYpWJVRNFylmIhPBeiAMDfLukvS['watermark'] =oCjQYpWJVRNFylmIhPBeiAMDfLukUz
  oCjQYpWJVRNFylmIhPBeiAMDfLukvS['watermarkKey']=oCjQYpWJVRNFylmIhPBeiAMDfLukUt
  if 'subtitles' in oCjQYpWJVRNFylmIhPBeiAMDfLukUv:
   for oCjQYpWJVRNFylmIhPBeiAMDfLukUw in oCjQYpWJVRNFylmIhPBeiAMDfLukUv.get('subtitles'):
    if oCjQYpWJVRNFylmIhPBeiAMDfLukUw.get('code')in['KO','KO_CC']:
     oCjQYpWJVRNFylmIhPBeiAMDfLukvS['subtitleYn']=oCjQYpWJVRNFylmIhPBeiAMDfLuktv
     break
  oCjQYpWJVRNFylmIhPBeiAMDfLukUd=urllib.parse.urlparse(oCjQYpWJVRNFylmIhPBeiAMDfLukvS['streaming_url'])
  oCjQYpWJVRNFylmIhPBeiAMDfLukUH =oCjQYpWJVRNFylmIhPBeiAMDfLukUd.path.strip('/').split('/')
  oCjQYpWJVRNFylmIhPBeiAMDfLukvS['url_filename']=oCjQYpWJVRNFylmIhPBeiAMDfLukUH[oCjQYpWJVRNFylmIhPBeiAMDfLuktU(oCjQYpWJVRNFylmIhPBeiAMDfLukUH)-1]
  return oCjQYpWJVRNFylmIhPBeiAMDfLukvS
 def Tving_Parse_mpd(oCjQYpWJVRNFylmIhPBeiAMDfLukOX,stream_url,watermarkKey=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,watermark=oCjQYpWJVRNFylmIhPBeiAMDfLukzE):
  if watermarkKey not in['',oCjQYpWJVRNFylmIhPBeiAMDfLukzE]:
   oCjQYpWJVRNFylmIhPBeiAMDfLukOq={'X-Tving-Param1':watermarkKey,'X-Tving-Param2':watermark,}
   oCjQYpWJVRNFylmIhPBeiAMDfLukTE=requests.get(url=stream_url,headers=oCjQYpWJVRNFylmIhPBeiAMDfLukOq,allow_redirects=oCjQYpWJVRNFylmIhPBeiAMDfLukzb)
  else:
   oCjQYpWJVRNFylmIhPBeiAMDfLukTE=requests.get(url=stream_url)
  oCjQYpWJVRNFylmIhPBeiAMDfLukUK=oCjQYpWJVRNFylmIhPBeiAMDfLukTE.content.decode('utf-8')
  oCjQYpWJVRNFylmIhPBeiAMDfLukUG=0
  oCjQYpWJVRNFylmIhPBeiAMDfLukUa =ET.ElementTree(ET.fromstring(oCjQYpWJVRNFylmIhPBeiAMDfLukUK))
  oCjQYpWJVRNFylmIhPBeiAMDfLukUx =oCjQYpWJVRNFylmIhPBeiAMDfLukUa.getroot()
  oCjQYpWJVRNFylmIhPBeiAMDfLukUr=re.match(r'\{.*\}',oCjQYpWJVRNFylmIhPBeiAMDfLukUx.tag)[0] 
  oCjQYpWJVRNFylmIhPBeiAMDfLukUs=oCjQYpWJVRNFylmIhPBeiAMDfLuktw([node for _,node in ET.iterparse(io.StringIO(oCjQYpWJVRNFylmIhPBeiAMDfLukUK),events=['start-ns'])])
  for oCjQYpWJVRNFylmIhPBeiAMDfLukOc,oCjQYpWJVRNFylmIhPBeiAMDfLuknH in oCjQYpWJVRNFylmIhPBeiAMDfLukUs.items():
   if oCjQYpWJVRNFylmIhPBeiAMDfLukOc!='ns2':
    ET.register_namespace(oCjQYpWJVRNFylmIhPBeiAMDfLukOc,oCjQYpWJVRNFylmIhPBeiAMDfLuknH)
  oCjQYpWJVRNFylmIhPBeiAMDfLukUc=oCjQYpWJVRNFylmIhPBeiAMDfLukUx.find(oCjQYpWJVRNFylmIhPBeiAMDfLukUr+'Period')
  for oCjQYpWJVRNFylmIhPBeiAMDfLukUS in oCjQYpWJVRNFylmIhPBeiAMDfLukUc.findall(oCjQYpWJVRNFylmIhPBeiAMDfLukUr+'AdaptationSet'):
   if(oCjQYpWJVRNFylmIhPBeiAMDfLukUS.attrib.get('mimeType')=='video/mp4' or oCjQYpWJVRNFylmIhPBeiAMDfLukUS.attrib.get('contentType')=='video'):
    for oCjQYpWJVRNFylmIhPBeiAMDfLukUq in oCjQYpWJVRNFylmIhPBeiAMDfLukUS.findall(oCjQYpWJVRNFylmIhPBeiAMDfLukUr+'Representation'):
     oCjQYpWJVRNFylmIhPBeiAMDfLukUE=oCjQYpWJVRNFylmIhPBeiAMDfLuktn(oCjQYpWJVRNFylmIhPBeiAMDfLukUq.attrib.get('bandwidth'))
     if oCjQYpWJVRNFylmIhPBeiAMDfLukUG<oCjQYpWJVRNFylmIhPBeiAMDfLukUE:oCjQYpWJVRNFylmIhPBeiAMDfLukUG=oCjQYpWJVRNFylmIhPBeiAMDfLukUE
    for oCjQYpWJVRNFylmIhPBeiAMDfLukUq in oCjQYpWJVRNFylmIhPBeiAMDfLukUS.findall(oCjQYpWJVRNFylmIhPBeiAMDfLukUr+'Representation'):
     if oCjQYpWJVRNFylmIhPBeiAMDfLukUG>oCjQYpWJVRNFylmIhPBeiAMDfLuktn(oCjQYpWJVRNFylmIhPBeiAMDfLukUq.attrib.get('bandwidth')):
      oCjQYpWJVRNFylmIhPBeiAMDfLukUS.remove(oCjQYpWJVRNFylmIhPBeiAMDfLukUq)
   else:
    continue
  oCjQYpWJVRNFylmIhPBeiAMDfLukUb=ET.tostring(oCjQYpWJVRNFylmIhPBeiAMDfLukUx).decode('utf-8')
  oCjQYpWJVRNFylmIhPBeiAMDfLuknO='<?xml version="1.0" encoding="UTF-8"?>\n'
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TextFile_Save(oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TV_STREAM_FILENAME,oCjQYpWJVRNFylmIhPBeiAMDfLuknO+oCjQYpWJVRNFylmIhPBeiAMDfLukUb)
  return oCjQYpWJVRNFylmIhPBeiAMDfLuktv
 def Tving_Parse_m3u8(oCjQYpWJVRNFylmIhPBeiAMDfLukOX,stream_url):
  try:
   oCjQYpWJVRNFylmIhPBeiAMDfLukTE=requests.get(url=stream_url,headers=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,stream=oCjQYpWJVRNFylmIhPBeiAMDfLuktv)
   oCjQYpWJVRNFylmIhPBeiAMDfLuknT=oCjQYpWJVRNFylmIhPBeiAMDfLukTE.content.decode('utf-8')
   if '#EXTM3U' not in oCjQYpWJVRNFylmIhPBeiAMDfLuknT:
    return oCjQYpWJVRNFylmIhPBeiAMDfLukzb
   if '#EXT-X-STREAM-INF' not in oCjQYpWJVRNFylmIhPBeiAMDfLuknT: 
    return oCjQYpWJVRNFylmIhPBeiAMDfLukzb
   oCjQYpWJVRNFylmIhPBeiAMDfLuknv=0
   for oCjQYpWJVRNFylmIhPBeiAMDfLuknU in oCjQYpWJVRNFylmIhPBeiAMDfLuknT.splitlines():
    if oCjQYpWJVRNFylmIhPBeiAMDfLuknU.startswith('#EXT-X-STREAM-INF'):
     oCjQYpWJVRNFylmIhPBeiAMDfLukng=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.MediaLine_Parse(oCjQYpWJVRNFylmIhPBeiAMDfLuknU,'#EXT-X-STREAM-INF')
     if oCjQYpWJVRNFylmIhPBeiAMDfLuknv<oCjQYpWJVRNFylmIhPBeiAMDfLuktn(oCjQYpWJVRNFylmIhPBeiAMDfLukng.get('BANDWIDTH')):
      oCjQYpWJVRNFylmIhPBeiAMDfLuknv=oCjQYpWJVRNFylmIhPBeiAMDfLuktn(oCjQYpWJVRNFylmIhPBeiAMDfLukng.get('BANDWIDTH'))
   oCjQYpWJVRNFylmIhPBeiAMDfLuknX=[]
   oCjQYpWJVRNFylmIhPBeiAMDfLuknz=oCjQYpWJVRNFylmIhPBeiAMDfLukzb
   for oCjQYpWJVRNFylmIhPBeiAMDfLuknU in oCjQYpWJVRNFylmIhPBeiAMDfLuknT.splitlines():
    if oCjQYpWJVRNFylmIhPBeiAMDfLuknz==oCjQYpWJVRNFylmIhPBeiAMDfLuktv:
     oCjQYpWJVRNFylmIhPBeiAMDfLuknz=oCjQYpWJVRNFylmIhPBeiAMDfLukzb
     continue
    if oCjQYpWJVRNFylmIhPBeiAMDfLuknU.startswith('#EXT-X-STREAM-INF'):
     oCjQYpWJVRNFylmIhPBeiAMDfLukng=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.MediaLine_Parse(oCjQYpWJVRNFylmIhPBeiAMDfLuknU,'#EXT-X-STREAM-INF')
     if oCjQYpWJVRNFylmIhPBeiAMDfLuknv!=oCjQYpWJVRNFylmIhPBeiAMDfLuktn(oCjQYpWJVRNFylmIhPBeiAMDfLukng.get('BANDWIDTH')):
      oCjQYpWJVRNFylmIhPBeiAMDfLuknz=oCjQYpWJVRNFylmIhPBeiAMDfLuktv
      continue
    oCjQYpWJVRNFylmIhPBeiAMDfLuknX.append(oCjQYpWJVRNFylmIhPBeiAMDfLuknU)
  except oCjQYpWJVRNFylmIhPBeiAMDfLuktz as exception:
   oCjQYpWJVRNFylmIhPBeiAMDfLukzc(exception)
   return oCjQYpWJVRNFylmIhPBeiAMDfLukzb
  oCjQYpWJVRNFylmIhPBeiAMDfLuknt='\n'.join(oCjQYpWJVRNFylmIhPBeiAMDfLuknX)
  oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TextFile_Save(oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TV_STREAM_FILENAME,oCjQYpWJVRNFylmIhPBeiAMDfLuknt)
  return oCjQYpWJVRNFylmIhPBeiAMDfLuktv
 def MediaLine_Parse(oCjQYpWJVRNFylmIhPBeiAMDfLukOX,oCjQYpWJVRNFylmIhPBeiAMDfLuknU,prefix):
  oCjQYpWJVRNFylmIhPBeiAMDfLukng={}
  for oCjQYpWJVRNFylmIhPBeiAMDfLuknw in oCjQYpWJVRNFylmIhPBeiAMDfLukOn.split(oCjQYpWJVRNFylmIhPBeiAMDfLuknU.replace(prefix+':',''))[1::2]:
   oCjQYpWJVRNFylmIhPBeiAMDfLuknd,oCjQYpWJVRNFylmIhPBeiAMDfLuknH=oCjQYpWJVRNFylmIhPBeiAMDfLuknw.split('=',1)
   oCjQYpWJVRNFylmIhPBeiAMDfLukng[oCjQYpWJVRNFylmIhPBeiAMDfLuknd.upper()]=oCjQYpWJVRNFylmIhPBeiAMDfLuknH.replace('"','').strip()
  return oCjQYpWJVRNFylmIhPBeiAMDfLukng
 def CheckQuality(oCjQYpWJVRNFylmIhPBeiAMDfLukOX,sel_qt,oCjQYpWJVRNFylmIhPBeiAMDfLukUT):
  for oCjQYpWJVRNFylmIhPBeiAMDfLuknK in oCjQYpWJVRNFylmIhPBeiAMDfLukUT:
   if sel_qt>=oCjQYpWJVRNFylmIhPBeiAMDfLuktd(oCjQYpWJVRNFylmIhPBeiAMDfLuknK)[0]:return oCjQYpWJVRNFylmIhPBeiAMDfLuknK.get(oCjQYpWJVRNFylmIhPBeiAMDfLuktd(oCjQYpWJVRNFylmIhPBeiAMDfLuknK)[0])
   oCjQYpWJVRNFylmIhPBeiAMDfLuknG=oCjQYpWJVRNFylmIhPBeiAMDfLuknK.get(oCjQYpWJVRNFylmIhPBeiAMDfLuktd(oCjQYpWJVRNFylmIhPBeiAMDfLuknK)[0])
  return oCjQYpWJVRNFylmIhPBeiAMDfLuknG
 def makeOocUrl(oCjQYpWJVRNFylmIhPBeiAMDfLukOX,ooc_params):
  oCjQYpWJVRNFylmIhPBeiAMDfLukTS=''
  for oCjQYpWJVRNFylmIhPBeiAMDfLukOc,oCjQYpWJVRNFylmIhPBeiAMDfLukOS in ooc_params.items():
   oCjQYpWJVRNFylmIhPBeiAMDfLukTS+="%s=%s^"%(oCjQYpWJVRNFylmIhPBeiAMDfLukOc,oCjQYpWJVRNFylmIhPBeiAMDfLukOS)
  return oCjQYpWJVRNFylmIhPBeiAMDfLukTS
 def GetLiveChannelList(oCjQYpWJVRNFylmIhPBeiAMDfLukOX,stype,page_int):
  oCjQYpWJVRNFylmIhPBeiAMDfLukvK=[]
  oCjQYpWJVRNFylmIhPBeiAMDfLukna=oCjQYpWJVRNFylmIhPBeiAMDfLukzb
  try:
   oCjQYpWJVRNFylmIhPBeiAMDfLukvw ='/v2/media/lives'
   if stype=='onair': 
    oCjQYpWJVRNFylmIhPBeiAMDfLuknx='CPCS0100,CPCS0400'
   else:
    oCjQYpWJVRNFylmIhPBeiAMDfLuknx='CPCS0300'
   oCjQYpWJVRNFylmIhPBeiAMDfLukvb=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.GetDefaultParams()
   oCjQYpWJVRNFylmIhPBeiAMDfLukvx={'cacheType':'main','pageNo':oCjQYpWJVRNFylmIhPBeiAMDfLuktO(page_int),'pageSize':oCjQYpWJVRNFylmIhPBeiAMDfLuktO(oCjQYpWJVRNFylmIhPBeiAMDfLukOX.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':oCjQYpWJVRNFylmIhPBeiAMDfLuknx,}
   oCjQYpWJVRNFylmIhPBeiAMDfLukvb.update(oCjQYpWJVRNFylmIhPBeiAMDfLukvx)
   oCjQYpWJVRNFylmIhPBeiAMDfLukTS=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.API_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukvw
   oCjQYpWJVRNFylmIhPBeiAMDfLukTE=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.callRequestCookies('Get',oCjQYpWJVRNFylmIhPBeiAMDfLukTS,payload=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,params=oCjQYpWJVRNFylmIhPBeiAMDfLukvb,headers=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,cookies=oCjQYpWJVRNFylmIhPBeiAMDfLukzE)
   oCjQYpWJVRNFylmIhPBeiAMDfLukvr=json.loads(oCjQYpWJVRNFylmIhPBeiAMDfLukTE.text)
   if not('result' in oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']):return oCjQYpWJVRNFylmIhPBeiAMDfLukvK,oCjQYpWJVRNFylmIhPBeiAMDfLukna
   oCjQYpWJVRNFylmIhPBeiAMDfLuknr=oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']['result']
   for oCjQYpWJVRNFylmIhPBeiAMDfLukvs in oCjQYpWJVRNFylmIhPBeiAMDfLuknr:
    oCjQYpWJVRNFylmIhPBeiAMDfLukns=oCjQYpWJVRNFylmIhPBeiAMDfLuknq=oCjQYpWJVRNFylmIhPBeiAMDfLuknE=''
    oCjQYpWJVRNFylmIhPBeiAMDfLuknc=oCjQYpWJVRNFylmIhPBeiAMDfLukgr=''
    oCjQYpWJVRNFylmIhPBeiAMDfLuknS=oCjQYpWJVRNFylmIhPBeiAMDfLukvs['live_code']
    oCjQYpWJVRNFylmIhPBeiAMDfLukns =oCjQYpWJVRNFylmIhPBeiAMDfLukvs['schedule']['channel']['name']['ko']
    if oCjQYpWJVRNFylmIhPBeiAMDfLukvs['schedule']['episode']!=oCjQYpWJVRNFylmIhPBeiAMDfLukzE:
     oCjQYpWJVRNFylmIhPBeiAMDfLuknq =oCjQYpWJVRNFylmIhPBeiAMDfLukvs['schedule']['program']['name']['ko']
     oCjQYpWJVRNFylmIhPBeiAMDfLuknq =oCjQYpWJVRNFylmIhPBeiAMDfLuknq+', '+oCjQYpWJVRNFylmIhPBeiAMDfLuktO(oCjQYpWJVRNFylmIhPBeiAMDfLukvs['schedule']['episode']['frequency'])+'회'
     oCjQYpWJVRNFylmIhPBeiAMDfLuknE=oCjQYpWJVRNFylmIhPBeiAMDfLukvs['schedule']['episode']['synopsis']['ko']
    else:
     oCjQYpWJVRNFylmIhPBeiAMDfLuknq =oCjQYpWJVRNFylmIhPBeiAMDfLukvs['schedule']['program']['name']['ko']
     oCjQYpWJVRNFylmIhPBeiAMDfLuknE=oCjQYpWJVRNFylmIhPBeiAMDfLukvs['schedule']['program']['synopsis']['ko']
    try: 
     oCjQYpWJVRNFylmIhPBeiAMDfLuknb =''
     oCjQYpWJVRNFylmIhPBeiAMDfLukgO =''
     oCjQYpWJVRNFylmIhPBeiAMDfLukgT=''
     oCjQYpWJVRNFylmIhPBeiAMDfLukgv =''
     oCjQYpWJVRNFylmIhPBeiAMDfLukgU =''
     oCjQYpWJVRNFylmIhPBeiAMDfLukgn =''
     for oCjQYpWJVRNFylmIhPBeiAMDfLukgX in oCjQYpWJVRNFylmIhPBeiAMDfLukvs['schedule']['program']['image']:
      if oCjQYpWJVRNFylmIhPBeiAMDfLukgX['code']=='CAIP0900':oCjQYpWJVRNFylmIhPBeiAMDfLukgO =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX['url']
      elif oCjQYpWJVRNFylmIhPBeiAMDfLukgX['code']=='CAIP1800':oCjQYpWJVRNFylmIhPBeiAMDfLukgT=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX['url']
      elif oCjQYpWJVRNFylmIhPBeiAMDfLukgX['code']=='CAIP2000':oCjQYpWJVRNFylmIhPBeiAMDfLukgv =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX['url']
      elif oCjQYpWJVRNFylmIhPBeiAMDfLukgX['code']=='CAIP1900':oCjQYpWJVRNFylmIhPBeiAMDfLukgU =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX['url']
      elif oCjQYpWJVRNFylmIhPBeiAMDfLukgX['code']=='CAIP0200':oCjQYpWJVRNFylmIhPBeiAMDfLukgn =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX['url']
      elif oCjQYpWJVRNFylmIhPBeiAMDfLukgX['code']=='CAIP0500':oCjQYpWJVRNFylmIhPBeiAMDfLuknb =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX['url']
      elif oCjQYpWJVRNFylmIhPBeiAMDfLukgX['code']=='CAIP0800':oCjQYpWJVRNFylmIhPBeiAMDfLuknb =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX['url']
     if oCjQYpWJVRNFylmIhPBeiAMDfLuknb=='':
      for oCjQYpWJVRNFylmIhPBeiAMDfLukgX in oCjQYpWJVRNFylmIhPBeiAMDfLukvs['schedule']['channel']['image']:
       if oCjQYpWJVRNFylmIhPBeiAMDfLukgX['code']=='CAIC0400':oCjQYpWJVRNFylmIhPBeiAMDfLuknb =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX['url']
       elif oCjQYpWJVRNFylmIhPBeiAMDfLukgX['code']=='CAIC1400':oCjQYpWJVRNFylmIhPBeiAMDfLuknb =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX['url']
       elif oCjQYpWJVRNFylmIhPBeiAMDfLukgX['code']=='CAIC1900':oCjQYpWJVRNFylmIhPBeiAMDfLuknb =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX['url']
    except:
     oCjQYpWJVRNFylmIhPBeiAMDfLukzE
    try:
     oCjQYpWJVRNFylmIhPBeiAMDfLukgz =[]
     oCjQYpWJVRNFylmIhPBeiAMDfLukgt=[]
     oCjQYpWJVRNFylmIhPBeiAMDfLukgw =[]
     oCjQYpWJVRNFylmIhPBeiAMDfLukgd=''
     oCjQYpWJVRNFylmIhPBeiAMDfLukgH=''
     oCjQYpWJVRNFylmIhPBeiAMDfLukgK=''
     for oCjQYpWJVRNFylmIhPBeiAMDfLukgG in oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('schedule').get('program').get('actor'):
      if oCjQYpWJVRNFylmIhPBeiAMDfLukgG!='' and oCjQYpWJVRNFylmIhPBeiAMDfLukgG!=u'없음':oCjQYpWJVRNFylmIhPBeiAMDfLukgz.append(oCjQYpWJVRNFylmIhPBeiAMDfLukgG)
     for oCjQYpWJVRNFylmIhPBeiAMDfLukga in oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('schedule').get('program').get('director'):
      if oCjQYpWJVRNFylmIhPBeiAMDfLukga!='' and oCjQYpWJVRNFylmIhPBeiAMDfLukga!='-' and oCjQYpWJVRNFylmIhPBeiAMDfLukga!=u'없음':oCjQYpWJVRNFylmIhPBeiAMDfLukgt.append(oCjQYpWJVRNFylmIhPBeiAMDfLukga)
     if oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('schedule').get('program').get('category1_name').get('ko')!='':
      oCjQYpWJVRNFylmIhPBeiAMDfLukgw.append(oCjQYpWJVRNFylmIhPBeiAMDfLukvs['schedule']['program']['category1_name']['ko'])
     if oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('schedule').get('program').get('category2_name').get('ko')!='':
      oCjQYpWJVRNFylmIhPBeiAMDfLukgw.append(oCjQYpWJVRNFylmIhPBeiAMDfLukvs['schedule']['program']['category2_name']['ko'])
     if oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('schedule').get('program').get('product_year'):oCjQYpWJVRNFylmIhPBeiAMDfLukgd=oCjQYpWJVRNFylmIhPBeiAMDfLukvs['schedule']['program']['product_year']
     if oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('schedule').get('program').get('grade_code') :oCjQYpWJVRNFylmIhPBeiAMDfLukgH= oCjQYpWJVRNFylmIhPBeiAMDfLukOU.get(oCjQYpWJVRNFylmIhPBeiAMDfLukvs['schedule']['program']['grade_code'])
     if 'broad_dt' in oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('schedule').get('program'):
      oCjQYpWJVRNFylmIhPBeiAMDfLukgx =oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('schedule').get('program').get('broad_dt')
      oCjQYpWJVRNFylmIhPBeiAMDfLukgK='%s-%s-%s'%(oCjQYpWJVRNFylmIhPBeiAMDfLukgx[:4],oCjQYpWJVRNFylmIhPBeiAMDfLukgx[4:6],oCjQYpWJVRNFylmIhPBeiAMDfLukgx[6:])
    except:
     oCjQYpWJVRNFylmIhPBeiAMDfLukzE
    oCjQYpWJVRNFylmIhPBeiAMDfLuknc=oCjQYpWJVRNFylmIhPBeiAMDfLuktO(oCjQYpWJVRNFylmIhPBeiAMDfLukvs['schedule']['broadcast_start_time'])[8:12]
    oCjQYpWJVRNFylmIhPBeiAMDfLukgr =oCjQYpWJVRNFylmIhPBeiAMDfLuktO(oCjQYpWJVRNFylmIhPBeiAMDfLukvs['schedule']['broadcast_end_time'])[8:12]
    oCjQYpWJVRNFylmIhPBeiAMDfLukgs={'channel':oCjQYpWJVRNFylmIhPBeiAMDfLukns,'title':oCjQYpWJVRNFylmIhPBeiAMDfLuknq,'mediacode':oCjQYpWJVRNFylmIhPBeiAMDfLuknS,'thumbnail':{'poster':oCjQYpWJVRNFylmIhPBeiAMDfLukgO,'thumb':oCjQYpWJVRNFylmIhPBeiAMDfLuknb,'clearlogo':oCjQYpWJVRNFylmIhPBeiAMDfLukgT,'icon':oCjQYpWJVRNFylmIhPBeiAMDfLukgv,'fanart':oCjQYpWJVRNFylmIhPBeiAMDfLukgn},'synopsis':oCjQYpWJVRNFylmIhPBeiAMDfLuknE,'channelepg':' [%s:%s ~ %s:%s]'%(oCjQYpWJVRNFylmIhPBeiAMDfLuknc[0:2],oCjQYpWJVRNFylmIhPBeiAMDfLuknc[2:],oCjQYpWJVRNFylmIhPBeiAMDfLukgr[0:2],oCjQYpWJVRNFylmIhPBeiAMDfLukgr[2:]),'cast':oCjQYpWJVRNFylmIhPBeiAMDfLukgz,'director':oCjQYpWJVRNFylmIhPBeiAMDfLukgt,'info_genre':oCjQYpWJVRNFylmIhPBeiAMDfLukgw,'year':oCjQYpWJVRNFylmIhPBeiAMDfLukgd,'mpaa':oCjQYpWJVRNFylmIhPBeiAMDfLukgH,'premiered':oCjQYpWJVRNFylmIhPBeiAMDfLukgK}
    oCjQYpWJVRNFylmIhPBeiAMDfLukvK.append(oCjQYpWJVRNFylmIhPBeiAMDfLukgs)
   if oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']['has_more']=='Y':
    oCjQYpWJVRNFylmIhPBeiAMDfLukna=oCjQYpWJVRNFylmIhPBeiAMDfLuktv
  except oCjQYpWJVRNFylmIhPBeiAMDfLuktz as exception:
   oCjQYpWJVRNFylmIhPBeiAMDfLukzc(exception)
  return oCjQYpWJVRNFylmIhPBeiAMDfLukvK,oCjQYpWJVRNFylmIhPBeiAMDfLukna
 def GetProgramList(oCjQYpWJVRNFylmIhPBeiAMDfLukOX,genre,orderby,page_int,genreCode='all'):
  oCjQYpWJVRNFylmIhPBeiAMDfLukvK=[]
  oCjQYpWJVRNFylmIhPBeiAMDfLukna=oCjQYpWJVRNFylmIhPBeiAMDfLukzb
  try:
   oCjQYpWJVRNFylmIhPBeiAMDfLukvw ='/v2/media/episodes'
   oCjQYpWJVRNFylmIhPBeiAMDfLukvb=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.GetDefaultParams()
   oCjQYpWJVRNFylmIhPBeiAMDfLukvx={'cacheType':'main','pageSize':oCjQYpWJVRNFylmIhPBeiAMDfLuktO(oCjQYpWJVRNFylmIhPBeiAMDfLukOX.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':oCjQYpWJVRNFylmIhPBeiAMDfLuktO(page_int),}
   if genre not in['all','PARAMOUNT']:oCjQYpWJVRNFylmIhPBeiAMDfLukvx['categoryCode']=genre
   if genreCode!='all' :oCjQYpWJVRNFylmIhPBeiAMDfLukvx['genreCode'] =genreCode 
   oCjQYpWJVRNFylmIhPBeiAMDfLukvb.update(oCjQYpWJVRNFylmIhPBeiAMDfLukvx)
   oCjQYpWJVRNFylmIhPBeiAMDfLukTS=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.API_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukvw
   oCjQYpWJVRNFylmIhPBeiAMDfLukTE=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.callRequestCookies('Get',oCjQYpWJVRNFylmIhPBeiAMDfLukTS,payload=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,params=oCjQYpWJVRNFylmIhPBeiAMDfLukvb,headers=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,cookies=oCjQYpWJVRNFylmIhPBeiAMDfLukzE)
   oCjQYpWJVRNFylmIhPBeiAMDfLukvr=json.loads(oCjQYpWJVRNFylmIhPBeiAMDfLukTE.text)
   if not('result' in oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']):return oCjQYpWJVRNFylmIhPBeiAMDfLukvK,oCjQYpWJVRNFylmIhPBeiAMDfLukna
   oCjQYpWJVRNFylmIhPBeiAMDfLuknr=oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']['result']
   for oCjQYpWJVRNFylmIhPBeiAMDfLukvs in oCjQYpWJVRNFylmIhPBeiAMDfLuknr:
    oCjQYpWJVRNFylmIhPBeiAMDfLukgc=oCjQYpWJVRNFylmIhPBeiAMDfLukvs['program']['code']
    oCjQYpWJVRNFylmIhPBeiAMDfLuknq =oCjQYpWJVRNFylmIhPBeiAMDfLukvs['program']['name']['ko']
    oCjQYpWJVRNFylmIhPBeiAMDfLukgH =oCjQYpWJVRNFylmIhPBeiAMDfLukOU.get(oCjQYpWJVRNFylmIhPBeiAMDfLukvs['program'].get('grade_code'))
    oCjQYpWJVRNFylmIhPBeiAMDfLukgO =''
    oCjQYpWJVRNFylmIhPBeiAMDfLuknb =''
    oCjQYpWJVRNFylmIhPBeiAMDfLukgT=''
    oCjQYpWJVRNFylmIhPBeiAMDfLukgv =''
    oCjQYpWJVRNFylmIhPBeiAMDfLukgU =''
    for oCjQYpWJVRNFylmIhPBeiAMDfLukgX in oCjQYpWJVRNFylmIhPBeiAMDfLukvs['program']['image']:
     if oCjQYpWJVRNFylmIhPBeiAMDfLukgX['code']=='CAIP0900':oCjQYpWJVRNFylmIhPBeiAMDfLukgO =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX['url']
     elif oCjQYpWJVRNFylmIhPBeiAMDfLukgX['code']=='CAIP0200':oCjQYpWJVRNFylmIhPBeiAMDfLuknb =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX['url']
     elif oCjQYpWJVRNFylmIhPBeiAMDfLukgX['code']=='CAIP1800':oCjQYpWJVRNFylmIhPBeiAMDfLukgT=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX['url']
     elif oCjQYpWJVRNFylmIhPBeiAMDfLukgX['code']=='CAIP2000':oCjQYpWJVRNFylmIhPBeiAMDfLukgv =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX['url']
     elif oCjQYpWJVRNFylmIhPBeiAMDfLukgX['code']=='CAIP1900':oCjQYpWJVRNFylmIhPBeiAMDfLukgU =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX['url']
    oCjQYpWJVRNFylmIhPBeiAMDfLuknE =oCjQYpWJVRNFylmIhPBeiAMDfLukvs['program']['synopsis']['ko']
    try:
     oCjQYpWJVRNFylmIhPBeiAMDfLukgS=oCjQYpWJVRNFylmIhPBeiAMDfLukvs['channel']['name']['ko']
    except:
     oCjQYpWJVRNFylmIhPBeiAMDfLukgS=''
    try:
     oCjQYpWJVRNFylmIhPBeiAMDfLukgz =[]
     oCjQYpWJVRNFylmIhPBeiAMDfLukgt=[]
     oCjQYpWJVRNFylmIhPBeiAMDfLukgw =[]
     oCjQYpWJVRNFylmIhPBeiAMDfLukgd =''
     oCjQYpWJVRNFylmIhPBeiAMDfLukgK=''
     for oCjQYpWJVRNFylmIhPBeiAMDfLukgG in oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('program').get('actor'):
      if oCjQYpWJVRNFylmIhPBeiAMDfLukgG!='' and oCjQYpWJVRNFylmIhPBeiAMDfLukgG!='-' and oCjQYpWJVRNFylmIhPBeiAMDfLukgG!=u'없음':oCjQYpWJVRNFylmIhPBeiAMDfLukgz.append(oCjQYpWJVRNFylmIhPBeiAMDfLukgG)
     for oCjQYpWJVRNFylmIhPBeiAMDfLukga in oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('program').get('director'):
      if oCjQYpWJVRNFylmIhPBeiAMDfLukga!='' and oCjQYpWJVRNFylmIhPBeiAMDfLukga!='-' and oCjQYpWJVRNFylmIhPBeiAMDfLukga!=u'없음':oCjQYpWJVRNFylmIhPBeiAMDfLukgt.append(oCjQYpWJVRNFylmIhPBeiAMDfLukga)
     if oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('program').get('category1_name').get('ko')!='':
      oCjQYpWJVRNFylmIhPBeiAMDfLukgw.append(oCjQYpWJVRNFylmIhPBeiAMDfLukvs['program']['category1_name']['ko'])
     if oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('program').get('category2_name').get('ko')!='':
      oCjQYpWJVRNFylmIhPBeiAMDfLukgw.append(oCjQYpWJVRNFylmIhPBeiAMDfLukvs['program']['category2_name']['ko'])
     if oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('program').get('product_year'):oCjQYpWJVRNFylmIhPBeiAMDfLukgd=oCjQYpWJVRNFylmIhPBeiAMDfLukvs['program']['product_year']
     if 'broad_dt' in oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('program'):
      oCjQYpWJVRNFylmIhPBeiAMDfLukgx =oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('program').get('broad_dt')
      oCjQYpWJVRNFylmIhPBeiAMDfLukgK='%s-%s-%s'%(oCjQYpWJVRNFylmIhPBeiAMDfLukgx[:4],oCjQYpWJVRNFylmIhPBeiAMDfLukgx[4:6],oCjQYpWJVRNFylmIhPBeiAMDfLukgx[6:])
    except:
     oCjQYpWJVRNFylmIhPBeiAMDfLukzE
    oCjQYpWJVRNFylmIhPBeiAMDfLukgs={'program':oCjQYpWJVRNFylmIhPBeiAMDfLukgc,'title':oCjQYpWJVRNFylmIhPBeiAMDfLuknq,'thumbnail':{'poster':oCjQYpWJVRNFylmIhPBeiAMDfLukgO,'thumb':oCjQYpWJVRNFylmIhPBeiAMDfLuknb,'clearlogo':oCjQYpWJVRNFylmIhPBeiAMDfLukgT,'icon':oCjQYpWJVRNFylmIhPBeiAMDfLukgv,'banner':oCjQYpWJVRNFylmIhPBeiAMDfLukgU,'fanart':oCjQYpWJVRNFylmIhPBeiAMDfLuknb},'synopsis':oCjQYpWJVRNFylmIhPBeiAMDfLuknE,'channel':oCjQYpWJVRNFylmIhPBeiAMDfLukgS,'cast':oCjQYpWJVRNFylmIhPBeiAMDfLukgz,'director':oCjQYpWJVRNFylmIhPBeiAMDfLukgt,'info_genre':oCjQYpWJVRNFylmIhPBeiAMDfLukgw,'year':oCjQYpWJVRNFylmIhPBeiAMDfLukgd,'premiered':oCjQYpWJVRNFylmIhPBeiAMDfLukgK,'mpaa':oCjQYpWJVRNFylmIhPBeiAMDfLukgH}
    oCjQYpWJVRNFylmIhPBeiAMDfLukvK.append(oCjQYpWJVRNFylmIhPBeiAMDfLukgs)
   if oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']['has_more']=='Y':oCjQYpWJVRNFylmIhPBeiAMDfLukna=oCjQYpWJVRNFylmIhPBeiAMDfLuktv
  except oCjQYpWJVRNFylmIhPBeiAMDfLuktz as exception:
   oCjQYpWJVRNFylmIhPBeiAMDfLukzc(exception)
  return oCjQYpWJVRNFylmIhPBeiAMDfLukvK,oCjQYpWJVRNFylmIhPBeiAMDfLukna
 def Get_UHD_ProgramList(oCjQYpWJVRNFylmIhPBeiAMDfLukOX,page_int):
  oCjQYpWJVRNFylmIhPBeiAMDfLukvK=[]
  oCjQYpWJVRNFylmIhPBeiAMDfLukna=oCjQYpWJVRNFylmIhPBeiAMDfLukzb
  try:
   oCjQYpWJVRNFylmIhPBeiAMDfLukvw ='/v2/operator/highlights'
   oCjQYpWJVRNFylmIhPBeiAMDfLukvb=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.GetDefaultParams(uhd=oCjQYpWJVRNFylmIhPBeiAMDfLuktv)
   oCjQYpWJVRNFylmIhPBeiAMDfLukvx={'positionKey':'SMTV_PROG_4K','pageSize':'20','page_int':oCjQYpWJVRNFylmIhPBeiAMDfLuktO(page_int),'pocType':'APP_X_TVING_4.0.0',}
   oCjQYpWJVRNFylmIhPBeiAMDfLukvb.update(oCjQYpWJVRNFylmIhPBeiAMDfLukvx)
   oCjQYpWJVRNFylmIhPBeiAMDfLukTS=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.API_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukvw
   oCjQYpWJVRNFylmIhPBeiAMDfLukTE=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.callRequestCookies('Get',oCjQYpWJVRNFylmIhPBeiAMDfLukTS,payload=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,params=oCjQYpWJVRNFylmIhPBeiAMDfLukvb,headers=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,cookies=oCjQYpWJVRNFylmIhPBeiAMDfLukzE)
   oCjQYpWJVRNFylmIhPBeiAMDfLukvr=json.loads(oCjQYpWJVRNFylmIhPBeiAMDfLukTE.text)
   if not('result' in oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']):return oCjQYpWJVRNFylmIhPBeiAMDfLukvK,oCjQYpWJVRNFylmIhPBeiAMDfLukna
   oCjQYpWJVRNFylmIhPBeiAMDfLuknr=oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']['result']
   for oCjQYpWJVRNFylmIhPBeiAMDfLukvs in oCjQYpWJVRNFylmIhPBeiAMDfLuknr:
    oCjQYpWJVRNFylmIhPBeiAMDfLukgq=oCjQYpWJVRNFylmIhPBeiAMDfLukvs['content']['program']
    oCjQYpWJVRNFylmIhPBeiAMDfLukgE =oCjQYpWJVRNFylmIhPBeiAMDfLukgq['code']
    oCjQYpWJVRNFylmIhPBeiAMDfLuknq =oCjQYpWJVRNFylmIhPBeiAMDfLukgq['name']['ko'].strip()
    oCjQYpWJVRNFylmIhPBeiAMDfLukgH =oCjQYpWJVRNFylmIhPBeiAMDfLukOU.get(oCjQYpWJVRNFylmIhPBeiAMDfLukgq.get('grade_code'))
    oCjQYpWJVRNFylmIhPBeiAMDfLuknE =oCjQYpWJVRNFylmIhPBeiAMDfLukgq['synopsis']['ko']
    oCjQYpWJVRNFylmIhPBeiAMDfLukgS =oCjQYpWJVRNFylmIhPBeiAMDfLukvs['content']['channel']['name']['ko']
    oCjQYpWJVRNFylmIhPBeiAMDfLukgd =oCjQYpWJVRNFylmIhPBeiAMDfLukgq['product_year']
    oCjQYpWJVRNFylmIhPBeiAMDfLukgO =''
    oCjQYpWJVRNFylmIhPBeiAMDfLuknb =''
    oCjQYpWJVRNFylmIhPBeiAMDfLukgT=''
    oCjQYpWJVRNFylmIhPBeiAMDfLukgv =''
    oCjQYpWJVRNFylmIhPBeiAMDfLukgU =''
    for oCjQYpWJVRNFylmIhPBeiAMDfLukgX in oCjQYpWJVRNFylmIhPBeiAMDfLukgq['image']:
     if oCjQYpWJVRNFylmIhPBeiAMDfLukgX['code']=='CAIP0900':oCjQYpWJVRNFylmIhPBeiAMDfLukgO =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX['url']
     elif oCjQYpWJVRNFylmIhPBeiAMDfLukgX['code']=='CAIP0200':oCjQYpWJVRNFylmIhPBeiAMDfLuknb =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX['url']
     elif oCjQYpWJVRNFylmIhPBeiAMDfLukgX['code']=='CAIP1800':oCjQYpWJVRNFylmIhPBeiAMDfLukgT=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX['url']
     elif oCjQYpWJVRNFylmIhPBeiAMDfLukgX['code']=='CAIP2000':oCjQYpWJVRNFylmIhPBeiAMDfLukgv =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX['url']
     elif oCjQYpWJVRNFylmIhPBeiAMDfLukgX['code']=='CAIP1900':oCjQYpWJVRNFylmIhPBeiAMDfLukgU =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX['url']
    oCjQYpWJVRNFylmIhPBeiAMDfLukgw =[]
    oCjQYpWJVRNFylmIhPBeiAMDfLukgz =[]
    oCjQYpWJVRNFylmIhPBeiAMDfLukgt=[]
    oCjQYpWJVRNFylmIhPBeiAMDfLukgK =''
    if oCjQYpWJVRNFylmIhPBeiAMDfLukgq.get('category1_name').get('ko')!='':
     oCjQYpWJVRNFylmIhPBeiAMDfLukgw.append(oCjQYpWJVRNFylmIhPBeiAMDfLukgq['category1_name']['ko'])
    if oCjQYpWJVRNFylmIhPBeiAMDfLukgq.get('category2_name').get('ko')!='':
     oCjQYpWJVRNFylmIhPBeiAMDfLukgw.append(oCjQYpWJVRNFylmIhPBeiAMDfLukgq['category2_name']['ko'])
    for oCjQYpWJVRNFylmIhPBeiAMDfLukgG in oCjQYpWJVRNFylmIhPBeiAMDfLukgq.get('actor'):
     if oCjQYpWJVRNFylmIhPBeiAMDfLukgG!='' and oCjQYpWJVRNFylmIhPBeiAMDfLukgG!='-' and oCjQYpWJVRNFylmIhPBeiAMDfLukgG!=u'없음':oCjQYpWJVRNFylmIhPBeiAMDfLukgz.append(oCjQYpWJVRNFylmIhPBeiAMDfLukgG)
    for oCjQYpWJVRNFylmIhPBeiAMDfLukga in oCjQYpWJVRNFylmIhPBeiAMDfLukgq.get('director'):
     if oCjQYpWJVRNFylmIhPBeiAMDfLukga!='' and oCjQYpWJVRNFylmIhPBeiAMDfLukga!='-' and oCjQYpWJVRNFylmIhPBeiAMDfLukga!=u'없음':oCjQYpWJVRNFylmIhPBeiAMDfLukgt.append(oCjQYpWJVRNFylmIhPBeiAMDfLukga)
    if oCjQYpWJVRNFylmIhPBeiAMDfLukgq.get('broad_dt')not in[oCjQYpWJVRNFylmIhPBeiAMDfLukzE,'']:
     oCjQYpWJVRNFylmIhPBeiAMDfLukgx =oCjQYpWJVRNFylmIhPBeiAMDfLukgq.get('broad_dt')
     oCjQYpWJVRNFylmIhPBeiAMDfLukgK='%s-%s-%s'%(oCjQYpWJVRNFylmIhPBeiAMDfLukgx[:4],oCjQYpWJVRNFylmIhPBeiAMDfLukgx[4:6],oCjQYpWJVRNFylmIhPBeiAMDfLukgx[6:])
    oCjQYpWJVRNFylmIhPBeiAMDfLukgs={'program':oCjQYpWJVRNFylmIhPBeiAMDfLukgE,'title':oCjQYpWJVRNFylmIhPBeiAMDfLuknq,'mpaa':oCjQYpWJVRNFylmIhPBeiAMDfLukgH,'thumbnail':{'poster':oCjQYpWJVRNFylmIhPBeiAMDfLukgO,'thumb':oCjQYpWJVRNFylmIhPBeiAMDfLuknb,'clearlogo':oCjQYpWJVRNFylmIhPBeiAMDfLukgT,'icon':oCjQYpWJVRNFylmIhPBeiAMDfLukgv,'banner':oCjQYpWJVRNFylmIhPBeiAMDfLukgU,'fanart':oCjQYpWJVRNFylmIhPBeiAMDfLuknb},'channel':oCjQYpWJVRNFylmIhPBeiAMDfLukgS,'synopsis':oCjQYpWJVRNFylmIhPBeiAMDfLuknE,'year':oCjQYpWJVRNFylmIhPBeiAMDfLukgd,'info_genre':oCjQYpWJVRNFylmIhPBeiAMDfLukgw,'cast':oCjQYpWJVRNFylmIhPBeiAMDfLukgz,'director':oCjQYpWJVRNFylmIhPBeiAMDfLukgt,'premiered':oCjQYpWJVRNFylmIhPBeiAMDfLukgK,}
    oCjQYpWJVRNFylmIhPBeiAMDfLukvK.append(oCjQYpWJVRNFylmIhPBeiAMDfLukgs)
  except oCjQYpWJVRNFylmIhPBeiAMDfLuktz as exception:
   oCjQYpWJVRNFylmIhPBeiAMDfLukzc(exception)
  return oCjQYpWJVRNFylmIhPBeiAMDfLukvK,oCjQYpWJVRNFylmIhPBeiAMDfLukna
 def Get_Origianl_ProgramList(oCjQYpWJVRNFylmIhPBeiAMDfLukOX,page_int):
  oCjQYpWJVRNFylmIhPBeiAMDfLukvK=[]
  oCjQYpWJVRNFylmIhPBeiAMDfLukna=oCjQYpWJVRNFylmIhPBeiAMDfLukzb
  try:
   oCjQYpWJVRNFylmIhPBeiAMDfLukvw ='/v2/media/band/originals'
   oCjQYpWJVRNFylmIhPBeiAMDfLukvb=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.GetDefaultParams()
   oCjQYpWJVRNFylmIhPBeiAMDfLukvx={'pageSize':oCjQYpWJVRNFylmIhPBeiAMDfLuktO(oCjQYpWJVRNFylmIhPBeiAMDfLukOX.VOD_LIMIT),'adult':'all','order':'viewHour','originalYn':'Y','exclusiveYn':'Y','pageNo':oCjQYpWJVRNFylmIhPBeiAMDfLuktO(page_int),}
   oCjQYpWJVRNFylmIhPBeiAMDfLukvb.update(oCjQYpWJVRNFylmIhPBeiAMDfLukvx)
   oCjQYpWJVRNFylmIhPBeiAMDfLukTS=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.API_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukvw
   oCjQYpWJVRNFylmIhPBeiAMDfLukTE=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.callRequestCookies('Get',oCjQYpWJVRNFylmIhPBeiAMDfLukTS,payload=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,params=oCjQYpWJVRNFylmIhPBeiAMDfLukvb,headers=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,cookies=oCjQYpWJVRNFylmIhPBeiAMDfLukzE)
   oCjQYpWJVRNFylmIhPBeiAMDfLukgb=json.loads(oCjQYpWJVRNFylmIhPBeiAMDfLukTE.text)
   oCjQYpWJVRNFylmIhPBeiAMDfLukOX.JsonFile_Save(oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TV_SESSION_COOKIES2,oCjQYpWJVRNFylmIhPBeiAMDfLukgb)
   if not('contents' in oCjQYpWJVRNFylmIhPBeiAMDfLukgb['body']):return oCjQYpWJVRNFylmIhPBeiAMDfLukvK,oCjQYpWJVRNFylmIhPBeiAMDfLukna
   oCjQYpWJVRNFylmIhPBeiAMDfLuknr=oCjQYpWJVRNFylmIhPBeiAMDfLukgb['body']['contents']
   for oCjQYpWJVRNFylmIhPBeiAMDfLukvs in oCjQYpWJVRNFylmIhPBeiAMDfLuknr:
    oCjQYpWJVRNFylmIhPBeiAMDfLukXO =oCjQYpWJVRNFylmIhPBeiAMDfLukvs['vod_code']
    oCjQYpWJVRNFylmIhPBeiAMDfLuknq =oCjQYpWJVRNFylmIhPBeiAMDfLukvs['vod_name']
    oCjQYpWJVRNFylmIhPBeiAMDfLukgO =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukvs['image']
    oCjQYpWJVRNFylmIhPBeiAMDfLukXT ='movie' if oCjQYpWJVRNFylmIhPBeiAMDfLukXO.startswith('M')else 'vod'
    oCjQYpWJVRNFylmIhPBeiAMDfLukgs={'vod_code':oCjQYpWJVRNFylmIhPBeiAMDfLukXO,'title':oCjQYpWJVRNFylmIhPBeiAMDfLuknq,'thumbnail':{'poster':oCjQYpWJVRNFylmIhPBeiAMDfLukgO,'thumb':oCjQYpWJVRNFylmIhPBeiAMDfLukgO},'vod_type':oCjQYpWJVRNFylmIhPBeiAMDfLukXT,}
    oCjQYpWJVRNFylmIhPBeiAMDfLukvK.append(oCjQYpWJVRNFylmIhPBeiAMDfLukgs)
   if oCjQYpWJVRNFylmIhPBeiAMDfLukgb['body']['has_more']=='Y':oCjQYpWJVRNFylmIhPBeiAMDfLukna=oCjQYpWJVRNFylmIhPBeiAMDfLuktv
  except oCjQYpWJVRNFylmIhPBeiAMDfLuktz as exception:
   oCjQYpWJVRNFylmIhPBeiAMDfLukzc(exception)
  return oCjQYpWJVRNFylmIhPBeiAMDfLukvK,oCjQYpWJVRNFylmIhPBeiAMDfLukna
 def GetEpisodeList(oCjQYpWJVRNFylmIhPBeiAMDfLukOX,program_code,page_int,orderby='desc'):
  oCjQYpWJVRNFylmIhPBeiAMDfLukvK=[]
  oCjQYpWJVRNFylmIhPBeiAMDfLukna=oCjQYpWJVRNFylmIhPBeiAMDfLukzb
  try:
   oCjQYpWJVRNFylmIhPBeiAMDfLukvw ='/v2/media/frequency/program/'+program_code
   oCjQYpWJVRNFylmIhPBeiAMDfLukvb=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.GetDefaultParams()
   oCjQYpWJVRNFylmIhPBeiAMDfLukvx={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   oCjQYpWJVRNFylmIhPBeiAMDfLukvb.update(oCjQYpWJVRNFylmIhPBeiAMDfLukvx)
   oCjQYpWJVRNFylmIhPBeiAMDfLukTS=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.API_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukvw
   oCjQYpWJVRNFylmIhPBeiAMDfLukTE=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.callRequestCookies('Get',oCjQYpWJVRNFylmIhPBeiAMDfLukTS,payload=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,params=oCjQYpWJVRNFylmIhPBeiAMDfLukvb,headers=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,cookies=oCjQYpWJVRNFylmIhPBeiAMDfLukzE)
   oCjQYpWJVRNFylmIhPBeiAMDfLukvr=json.loads(oCjQYpWJVRNFylmIhPBeiAMDfLukTE.text)
   if not('result' in oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']):return oCjQYpWJVRNFylmIhPBeiAMDfLukvK,oCjQYpWJVRNFylmIhPBeiAMDfLukna
   oCjQYpWJVRNFylmIhPBeiAMDfLuknr=oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']['result']
   oCjQYpWJVRNFylmIhPBeiAMDfLukXv=oCjQYpWJVRNFylmIhPBeiAMDfLuktn(oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']['total_count'])
   oCjQYpWJVRNFylmIhPBeiAMDfLukXU =oCjQYpWJVRNFylmIhPBeiAMDfLuktn(oCjQYpWJVRNFylmIhPBeiAMDfLukXv//(oCjQYpWJVRNFylmIhPBeiAMDfLukOX.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    oCjQYpWJVRNFylmIhPBeiAMDfLukXn =(oCjQYpWJVRNFylmIhPBeiAMDfLukXv-1)-((page_int-1)*oCjQYpWJVRNFylmIhPBeiAMDfLukOX.EPISODE_LIMIT)
   else:
    oCjQYpWJVRNFylmIhPBeiAMDfLukXn =(page_int-1)*oCjQYpWJVRNFylmIhPBeiAMDfLukOX.EPISODE_LIMIT
   for i in oCjQYpWJVRNFylmIhPBeiAMDfLuktg(oCjQYpWJVRNFylmIhPBeiAMDfLukOX.EPISODE_LIMIT):
    if orderby=='desc':
     oCjQYpWJVRNFylmIhPBeiAMDfLukXg=oCjQYpWJVRNFylmIhPBeiAMDfLukXn-i
     if oCjQYpWJVRNFylmIhPBeiAMDfLukXg<0:break
    else:
     oCjQYpWJVRNFylmIhPBeiAMDfLukXg=oCjQYpWJVRNFylmIhPBeiAMDfLukXn+i
     if oCjQYpWJVRNFylmIhPBeiAMDfLukXg>=oCjQYpWJVRNFylmIhPBeiAMDfLukXv:break
    oCjQYpWJVRNFylmIhPBeiAMDfLukXz=oCjQYpWJVRNFylmIhPBeiAMDfLuknr[oCjQYpWJVRNFylmIhPBeiAMDfLukXg]['episode']['code']
    oCjQYpWJVRNFylmIhPBeiAMDfLuknq =oCjQYpWJVRNFylmIhPBeiAMDfLuknr[oCjQYpWJVRNFylmIhPBeiAMDfLukXg]['vod_name']['ko']
    oCjQYpWJVRNFylmIhPBeiAMDfLukXt =''
    try:
     oCjQYpWJVRNFylmIhPBeiAMDfLukgx=oCjQYpWJVRNFylmIhPBeiAMDfLuktO(oCjQYpWJVRNFylmIhPBeiAMDfLuknr[oCjQYpWJVRNFylmIhPBeiAMDfLukXg]['episode']['broadcast_date'])
     oCjQYpWJVRNFylmIhPBeiAMDfLukXt='%s-%s-%s'%(oCjQYpWJVRNFylmIhPBeiAMDfLukgx[:4],oCjQYpWJVRNFylmIhPBeiAMDfLukgx[4:6],oCjQYpWJVRNFylmIhPBeiAMDfLukgx[6:])
    except:
     oCjQYpWJVRNFylmIhPBeiAMDfLukzE
    try:
     if oCjQYpWJVRNFylmIhPBeiAMDfLuknr[oCjQYpWJVRNFylmIhPBeiAMDfLukXg]['episode']['pip_cliptype']=='C012':
      oCjQYpWJVRNFylmIhPBeiAMDfLukXt+=' - Quick VOD'
    except:
     oCjQYpWJVRNFylmIhPBeiAMDfLukzE
    oCjQYpWJVRNFylmIhPBeiAMDfLuknE =oCjQYpWJVRNFylmIhPBeiAMDfLuknr[oCjQYpWJVRNFylmIhPBeiAMDfLukXg]['episode']['synopsis']['ko']
    oCjQYpWJVRNFylmIhPBeiAMDfLukgO =''
    oCjQYpWJVRNFylmIhPBeiAMDfLuknb =''
    oCjQYpWJVRNFylmIhPBeiAMDfLukgT=''
    oCjQYpWJVRNFylmIhPBeiAMDfLukgv =''
    oCjQYpWJVRNFylmIhPBeiAMDfLukgU =''
    oCjQYpWJVRNFylmIhPBeiAMDfLukgn =''
    for oCjQYpWJVRNFylmIhPBeiAMDfLukgX in oCjQYpWJVRNFylmIhPBeiAMDfLuknr[oCjQYpWJVRNFylmIhPBeiAMDfLukXg]['program']['image']:
     if oCjQYpWJVRNFylmIhPBeiAMDfLukgX['code']=='CAIP0900':oCjQYpWJVRNFylmIhPBeiAMDfLukgO =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX['url']
     elif oCjQYpWJVRNFylmIhPBeiAMDfLukgX['code']=='CAIP1800':oCjQYpWJVRNFylmIhPBeiAMDfLukgT=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX['url']
     elif oCjQYpWJVRNFylmIhPBeiAMDfLukgX['code']=='CAIP2000':oCjQYpWJVRNFylmIhPBeiAMDfLukgv =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX['url']
     elif oCjQYpWJVRNFylmIhPBeiAMDfLukgX['code']=='CAIP1900':oCjQYpWJVRNFylmIhPBeiAMDfLukgU =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX['url']
     elif oCjQYpWJVRNFylmIhPBeiAMDfLukgX['code']=='CAIP0200':oCjQYpWJVRNFylmIhPBeiAMDfLukgn =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX['url']
    for oCjQYpWJVRNFylmIhPBeiAMDfLukgX in oCjQYpWJVRNFylmIhPBeiAMDfLuknr[oCjQYpWJVRNFylmIhPBeiAMDfLukXg]['episode']['image']:
     if oCjQYpWJVRNFylmIhPBeiAMDfLukgX['code']=='CAIE0400':oCjQYpWJVRNFylmIhPBeiAMDfLuknb =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX['url']
    try:
     oCjQYpWJVRNFylmIhPBeiAMDfLukXw=oCjQYpWJVRNFylmIhPBeiAMDfLukXH=oCjQYpWJVRNFylmIhPBeiAMDfLukXK=''
     oCjQYpWJVRNFylmIhPBeiAMDfLukXd=0
     oCjQYpWJVRNFylmIhPBeiAMDfLukXw =oCjQYpWJVRNFylmIhPBeiAMDfLuknr[oCjQYpWJVRNFylmIhPBeiAMDfLukXg]['program']['name']['ko']
     oCjQYpWJVRNFylmIhPBeiAMDfLukXH =oCjQYpWJVRNFylmIhPBeiAMDfLukXt
     oCjQYpWJVRNFylmIhPBeiAMDfLukXK =oCjQYpWJVRNFylmIhPBeiAMDfLuknr[oCjQYpWJVRNFylmIhPBeiAMDfLukXg]['channel']['name']['ko']
     if 'frequency' in oCjQYpWJVRNFylmIhPBeiAMDfLuknr[oCjQYpWJVRNFylmIhPBeiAMDfLukXg]['episode']:oCjQYpWJVRNFylmIhPBeiAMDfLukXd=oCjQYpWJVRNFylmIhPBeiAMDfLuknr[oCjQYpWJVRNFylmIhPBeiAMDfLukXg]['episode']['frequency']
    except:
     oCjQYpWJVRNFylmIhPBeiAMDfLukzE
    oCjQYpWJVRNFylmIhPBeiAMDfLukgs={'episode':oCjQYpWJVRNFylmIhPBeiAMDfLukXz,'title':oCjQYpWJVRNFylmIhPBeiAMDfLuknq,'subtitle':oCjQYpWJVRNFylmIhPBeiAMDfLukXt,'thumbnail':{'poster':oCjQYpWJVRNFylmIhPBeiAMDfLukgO,'thumb':oCjQYpWJVRNFylmIhPBeiAMDfLuknb,'clearlogo':oCjQYpWJVRNFylmIhPBeiAMDfLukgT,'icon':oCjQYpWJVRNFylmIhPBeiAMDfLukgv,'banner':oCjQYpWJVRNFylmIhPBeiAMDfLukgU,'fanart':oCjQYpWJVRNFylmIhPBeiAMDfLukgn},'synopsis':oCjQYpWJVRNFylmIhPBeiAMDfLuknE,'info_title':oCjQYpWJVRNFylmIhPBeiAMDfLukXw,'aired':oCjQYpWJVRNFylmIhPBeiAMDfLukXH,'studio':oCjQYpWJVRNFylmIhPBeiAMDfLukXK,'frequency':oCjQYpWJVRNFylmIhPBeiAMDfLukXd}
    oCjQYpWJVRNFylmIhPBeiAMDfLukvK.append(oCjQYpWJVRNFylmIhPBeiAMDfLukgs)
   if oCjQYpWJVRNFylmIhPBeiAMDfLukXU>page_int:oCjQYpWJVRNFylmIhPBeiAMDfLukna=oCjQYpWJVRNFylmIhPBeiAMDfLuktv
  except oCjQYpWJVRNFylmIhPBeiAMDfLuktz as exception:
   oCjQYpWJVRNFylmIhPBeiAMDfLukzc(exception)
  return oCjQYpWJVRNFylmIhPBeiAMDfLukvK,oCjQYpWJVRNFylmIhPBeiAMDfLukna,oCjQYpWJVRNFylmIhPBeiAMDfLukXU
 def GetMovieList(oCjQYpWJVRNFylmIhPBeiAMDfLukOX,genre,orderby,page_int):
  oCjQYpWJVRNFylmIhPBeiAMDfLukvK=[]
  oCjQYpWJVRNFylmIhPBeiAMDfLukna=oCjQYpWJVRNFylmIhPBeiAMDfLukzb
  try:
   oCjQYpWJVRNFylmIhPBeiAMDfLukvw ='/v2/media/movies'
   oCjQYpWJVRNFylmIhPBeiAMDfLukvb=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.GetDefaultParams()
   oCjQYpWJVRNFylmIhPBeiAMDfLukvx={'pageSize':oCjQYpWJVRNFylmIhPBeiAMDfLuktO(oCjQYpWJVRNFylmIhPBeiAMDfLukOX.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N' if genre!='diversityYn' else 'Y','pageNo':oCjQYpWJVRNFylmIhPBeiAMDfLuktO(page_int),}
   if genre not in['all','PARAMOUNT','diversityYn']:oCjQYpWJVRNFylmIhPBeiAMDfLukvx['categoryCode']=genre
   oCjQYpWJVRNFylmIhPBeiAMDfLukvx['productPackageCode']=','.join(oCjQYpWJVRNFylmIhPBeiAMDfLukOX.MOVIE_LITE)
   oCjQYpWJVRNFylmIhPBeiAMDfLukvb.update(oCjQYpWJVRNFylmIhPBeiAMDfLukvx)
   oCjQYpWJVRNFylmIhPBeiAMDfLukTS=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.API_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukvw
   oCjQYpWJVRNFylmIhPBeiAMDfLukTE=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.callRequestCookies('Get',oCjQYpWJVRNFylmIhPBeiAMDfLukTS,payload=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,params=oCjQYpWJVRNFylmIhPBeiAMDfLukvb,headers=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,cookies=oCjQYpWJVRNFylmIhPBeiAMDfLukzE)
   oCjQYpWJVRNFylmIhPBeiAMDfLukvr=json.loads(oCjQYpWJVRNFylmIhPBeiAMDfLukTE.text)
   if not('result' in oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']):return oCjQYpWJVRNFylmIhPBeiAMDfLukvK,oCjQYpWJVRNFylmIhPBeiAMDfLukna
   oCjQYpWJVRNFylmIhPBeiAMDfLuknr=oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']['result']
   for oCjQYpWJVRNFylmIhPBeiAMDfLukvs in oCjQYpWJVRNFylmIhPBeiAMDfLuknr:
    if 'release_date' in oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('movie'):
     oCjQYpWJVRNFylmIhPBeiAMDfLukgd=oCjQYpWJVRNFylmIhPBeiAMDfLuktO(oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('movie').get('release_date'))[:4]
    else:
     oCjQYpWJVRNFylmIhPBeiAMDfLukgd=oCjQYpWJVRNFylmIhPBeiAMDfLukzE
    oCjQYpWJVRNFylmIhPBeiAMDfLukXG =oCjQYpWJVRNFylmIhPBeiAMDfLukvs['movie']['code']
    oCjQYpWJVRNFylmIhPBeiAMDfLuknq =oCjQYpWJVRNFylmIhPBeiAMDfLukvs['movie']['name']['ko'].strip()
    if oCjQYpWJVRNFylmIhPBeiAMDfLukgd not in[oCjQYpWJVRNFylmIhPBeiAMDfLukzE,'0','']:oCjQYpWJVRNFylmIhPBeiAMDfLuknq+=u' (%s)'%(oCjQYpWJVRNFylmIhPBeiAMDfLukgd)
    oCjQYpWJVRNFylmIhPBeiAMDfLukgO=''
    oCjQYpWJVRNFylmIhPBeiAMDfLuknb =''
    oCjQYpWJVRNFylmIhPBeiAMDfLukgT=''
    for oCjQYpWJVRNFylmIhPBeiAMDfLukgX in oCjQYpWJVRNFylmIhPBeiAMDfLukvs['movie']['image']:
     if oCjQYpWJVRNFylmIhPBeiAMDfLukgX['code']=='CAIM2100':oCjQYpWJVRNFylmIhPBeiAMDfLukgO =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX['url']
     elif oCjQYpWJVRNFylmIhPBeiAMDfLukgX['code']=='CAIM0400':oCjQYpWJVRNFylmIhPBeiAMDfLuknb =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX['url']
     elif oCjQYpWJVRNFylmIhPBeiAMDfLukgX['code']=='CAIM1800':oCjQYpWJVRNFylmIhPBeiAMDfLukgT=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX['url']
    oCjQYpWJVRNFylmIhPBeiAMDfLuknE =oCjQYpWJVRNFylmIhPBeiAMDfLukvs['movie']['story']['ko']
    try:
     oCjQYpWJVRNFylmIhPBeiAMDfLukXw =oCjQYpWJVRNFylmIhPBeiAMDfLukvs['movie']['name']['ko'].strip()
     oCjQYpWJVRNFylmIhPBeiAMDfLukgH =oCjQYpWJVRNFylmIhPBeiAMDfLukOU.get(oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('grade_code'))
     oCjQYpWJVRNFylmIhPBeiAMDfLukgz=[]
     oCjQYpWJVRNFylmIhPBeiAMDfLukgt=[]
     oCjQYpWJVRNFylmIhPBeiAMDfLukgw=[]
     oCjQYpWJVRNFylmIhPBeiAMDfLukXa=0
     oCjQYpWJVRNFylmIhPBeiAMDfLukgK=''
     oCjQYpWJVRNFylmIhPBeiAMDfLukXK =''
     for oCjQYpWJVRNFylmIhPBeiAMDfLukgG in oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('movie').get('actor'):
      if oCjQYpWJVRNFylmIhPBeiAMDfLukgG!='':oCjQYpWJVRNFylmIhPBeiAMDfLukgz.append(oCjQYpWJVRNFylmIhPBeiAMDfLukgG)
     for oCjQYpWJVRNFylmIhPBeiAMDfLukga in oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('movie').get('director'):
      if oCjQYpWJVRNFylmIhPBeiAMDfLukga!='':oCjQYpWJVRNFylmIhPBeiAMDfLukgt.append(oCjQYpWJVRNFylmIhPBeiAMDfLukga)
     if oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('movie').get('category1_name').get('ko')!='':
      oCjQYpWJVRNFylmIhPBeiAMDfLukgw.append(oCjQYpWJVRNFylmIhPBeiAMDfLukvs['movie']['category1_name']['ko'])
     if oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('movie').get('category2_name').get('ko')!='':
      oCjQYpWJVRNFylmIhPBeiAMDfLukgw.append(oCjQYpWJVRNFylmIhPBeiAMDfLukvs['movie']['category2_name']['ko'])
     if 'duration' in oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('movie'):oCjQYpWJVRNFylmIhPBeiAMDfLukXa=oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('movie').get('duration')
     if 'release_date' in oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('movie'):
      oCjQYpWJVRNFylmIhPBeiAMDfLukgx=oCjQYpWJVRNFylmIhPBeiAMDfLuktO(oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('movie').get('release_date'))
      if oCjQYpWJVRNFylmIhPBeiAMDfLukgx!='0':oCjQYpWJVRNFylmIhPBeiAMDfLukgK='%s-%s-%s'%(oCjQYpWJVRNFylmIhPBeiAMDfLukgx[:4],oCjQYpWJVRNFylmIhPBeiAMDfLukgx[4:6],oCjQYpWJVRNFylmIhPBeiAMDfLukgx[6:])
     if 'production' in oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('movie'):oCjQYpWJVRNFylmIhPBeiAMDfLukXK=oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('movie').get('production')
    except:
     oCjQYpWJVRNFylmIhPBeiAMDfLukzE
    oCjQYpWJVRNFylmIhPBeiAMDfLukgs={'moviecode':oCjQYpWJVRNFylmIhPBeiAMDfLukXG,'title':oCjQYpWJVRNFylmIhPBeiAMDfLuknq,'thumbnail':{'poster':oCjQYpWJVRNFylmIhPBeiAMDfLukgO,'thumb':oCjQYpWJVRNFylmIhPBeiAMDfLuknb,'clearlogo':oCjQYpWJVRNFylmIhPBeiAMDfLukgT,'fanart':oCjQYpWJVRNFylmIhPBeiAMDfLuknb},'synopsis':oCjQYpWJVRNFylmIhPBeiAMDfLuknE,'info_title':oCjQYpWJVRNFylmIhPBeiAMDfLukXw,'year':oCjQYpWJVRNFylmIhPBeiAMDfLukgd,'cast':oCjQYpWJVRNFylmIhPBeiAMDfLukgz,'director':oCjQYpWJVRNFylmIhPBeiAMDfLukgt,'info_genre':oCjQYpWJVRNFylmIhPBeiAMDfLukgw,'duration':oCjQYpWJVRNFylmIhPBeiAMDfLukXa,'premiered':oCjQYpWJVRNFylmIhPBeiAMDfLukgK,'studio':oCjQYpWJVRNFylmIhPBeiAMDfLukXK,'mpaa':oCjQYpWJVRNFylmIhPBeiAMDfLukgH}
    oCjQYpWJVRNFylmIhPBeiAMDfLukXx=oCjQYpWJVRNFylmIhPBeiAMDfLukzb
    for oCjQYpWJVRNFylmIhPBeiAMDfLukXr in oCjQYpWJVRNFylmIhPBeiAMDfLukvs['billing_package_id']:
     if oCjQYpWJVRNFylmIhPBeiAMDfLukXr in oCjQYpWJVRNFylmIhPBeiAMDfLukOX.MOVIE_LITE:
      oCjQYpWJVRNFylmIhPBeiAMDfLukXx=oCjQYpWJVRNFylmIhPBeiAMDfLuktv
      break
    if oCjQYpWJVRNFylmIhPBeiAMDfLukXx==oCjQYpWJVRNFylmIhPBeiAMDfLukzb: 
     oCjQYpWJVRNFylmIhPBeiAMDfLukgs['title']=oCjQYpWJVRNFylmIhPBeiAMDfLukgs['title']+' [개별구매]'
    oCjQYpWJVRNFylmIhPBeiAMDfLukvK.append(oCjQYpWJVRNFylmIhPBeiAMDfLukgs)
   if oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']['has_more']=='Y':oCjQYpWJVRNFylmIhPBeiAMDfLukna=oCjQYpWJVRNFylmIhPBeiAMDfLuktv
  except oCjQYpWJVRNFylmIhPBeiAMDfLuktz as exception:
   oCjQYpWJVRNFylmIhPBeiAMDfLukzc(exception)
  return oCjQYpWJVRNFylmIhPBeiAMDfLukvK,oCjQYpWJVRNFylmIhPBeiAMDfLukna
 def Get_UHD_MovieList(oCjQYpWJVRNFylmIhPBeiAMDfLukOX,page_int):
  oCjQYpWJVRNFylmIhPBeiAMDfLukvK=[]
  oCjQYpWJVRNFylmIhPBeiAMDfLukna=oCjQYpWJVRNFylmIhPBeiAMDfLukzb
  try:
   oCjQYpWJVRNFylmIhPBeiAMDfLukvw ='/v2/operator/highlights'
   oCjQYpWJVRNFylmIhPBeiAMDfLukvb=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.GetDefaultParams(uhd=oCjQYpWJVRNFylmIhPBeiAMDfLuktv)
   oCjQYpWJVRNFylmIhPBeiAMDfLukvx={'positionKey':'SMTV_MV_4K','pageSize':'20','page_int':oCjQYpWJVRNFylmIhPBeiAMDfLuktO(page_int),'pocType':'APP_X_TVING_4.0.0',}
   oCjQYpWJVRNFylmIhPBeiAMDfLukvb.update(oCjQYpWJVRNFylmIhPBeiAMDfLukvx)
   oCjQYpWJVRNFylmIhPBeiAMDfLukTS=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.API_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukvw
   oCjQYpWJVRNFylmIhPBeiAMDfLukTE=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.callRequestCookies('Get',oCjQYpWJVRNFylmIhPBeiAMDfLukTS,payload=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,params=oCjQYpWJVRNFylmIhPBeiAMDfLukvb,headers=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,cookies=oCjQYpWJVRNFylmIhPBeiAMDfLukzE)
   oCjQYpWJVRNFylmIhPBeiAMDfLukvr=json.loads(oCjQYpWJVRNFylmIhPBeiAMDfLukTE.text)
   if not('result' in oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']):return oCjQYpWJVRNFylmIhPBeiAMDfLukvK,oCjQYpWJVRNFylmIhPBeiAMDfLukna
   oCjQYpWJVRNFylmIhPBeiAMDfLuknr=oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']['result']
   for oCjQYpWJVRNFylmIhPBeiAMDfLukvs in oCjQYpWJVRNFylmIhPBeiAMDfLuknr:
    oCjQYpWJVRNFylmIhPBeiAMDfLukgq=oCjQYpWJVRNFylmIhPBeiAMDfLukvs['content']['movie']
    oCjQYpWJVRNFylmIhPBeiAMDfLukgE =oCjQYpWJVRNFylmIhPBeiAMDfLukgq['code']
    oCjQYpWJVRNFylmIhPBeiAMDfLuknq =oCjQYpWJVRNFylmIhPBeiAMDfLukgq['name']['ko'].strip()
    oCjQYpWJVRNFylmIhPBeiAMDfLukXw =oCjQYpWJVRNFylmIhPBeiAMDfLukgq['name']['ko'].strip()
    oCjQYpWJVRNFylmIhPBeiAMDfLukgd =oCjQYpWJVRNFylmIhPBeiAMDfLukgq['product_year']
    if oCjQYpWJVRNFylmIhPBeiAMDfLukgd:oCjQYpWJVRNFylmIhPBeiAMDfLuknq+=u' (%s)'%(oCjQYpWJVRNFylmIhPBeiAMDfLukgq['product_year'])
    oCjQYpWJVRNFylmIhPBeiAMDfLuknE =oCjQYpWJVRNFylmIhPBeiAMDfLukgq['story']['ko']
    oCjQYpWJVRNFylmIhPBeiAMDfLukXa =oCjQYpWJVRNFylmIhPBeiAMDfLukgq['duration']
    oCjQYpWJVRNFylmIhPBeiAMDfLukgH =oCjQYpWJVRNFylmIhPBeiAMDfLukOU.get(oCjQYpWJVRNFylmIhPBeiAMDfLukgq.get('grade_code'))
    oCjQYpWJVRNFylmIhPBeiAMDfLukXK =oCjQYpWJVRNFylmIhPBeiAMDfLukgq['production']
    oCjQYpWJVRNFylmIhPBeiAMDfLukgO=''
    oCjQYpWJVRNFylmIhPBeiAMDfLuknb =''
    oCjQYpWJVRNFylmIhPBeiAMDfLukgT=''
    oCjQYpWJVRNFylmIhPBeiAMDfLukgw =[]
    oCjQYpWJVRNFylmIhPBeiAMDfLukgz =[]
    oCjQYpWJVRNFylmIhPBeiAMDfLukgt=[]
    oCjQYpWJVRNFylmIhPBeiAMDfLukgK =''
    for oCjQYpWJVRNFylmIhPBeiAMDfLukgX in oCjQYpWJVRNFylmIhPBeiAMDfLukgq['image']:
     if oCjQYpWJVRNFylmIhPBeiAMDfLukgX['code']=='CAIM2100':oCjQYpWJVRNFylmIhPBeiAMDfLukgO =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX['url']
     elif oCjQYpWJVRNFylmIhPBeiAMDfLukgX['code']=='CAIM0400':oCjQYpWJVRNFylmIhPBeiAMDfLuknb =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX['url']
     elif oCjQYpWJVRNFylmIhPBeiAMDfLukgX['code']=='CAIM1800':oCjQYpWJVRNFylmIhPBeiAMDfLukgT=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX['url']
    if oCjQYpWJVRNFylmIhPBeiAMDfLukgq['release_date']not in[oCjQYpWJVRNFylmIhPBeiAMDfLukzE,0]:
     oCjQYpWJVRNFylmIhPBeiAMDfLukgx=oCjQYpWJVRNFylmIhPBeiAMDfLuktO(oCjQYpWJVRNFylmIhPBeiAMDfLukgq['release_date'])
     if oCjQYpWJVRNFylmIhPBeiAMDfLukgx!='0':oCjQYpWJVRNFylmIhPBeiAMDfLukgK='%s-%s-%s'%(oCjQYpWJVRNFylmIhPBeiAMDfLukgx[:4],oCjQYpWJVRNFylmIhPBeiAMDfLukgx[4:6],oCjQYpWJVRNFylmIhPBeiAMDfLukgx[6:])
    if oCjQYpWJVRNFylmIhPBeiAMDfLukgq.get('category1_name').get('ko')!='':
     oCjQYpWJVRNFylmIhPBeiAMDfLukgw.append(oCjQYpWJVRNFylmIhPBeiAMDfLukgq['category1_name']['ko'])
    if oCjQYpWJVRNFylmIhPBeiAMDfLukgq.get('category2_name').get('ko')!='':
     oCjQYpWJVRNFylmIhPBeiAMDfLukgw.append(oCjQYpWJVRNFylmIhPBeiAMDfLukgq['category2_name']['ko'])
    for oCjQYpWJVRNFylmIhPBeiAMDfLukgG in oCjQYpWJVRNFylmIhPBeiAMDfLukgq.get('actor'):
     if oCjQYpWJVRNFylmIhPBeiAMDfLukgG!='':oCjQYpWJVRNFylmIhPBeiAMDfLukgz.append(oCjQYpWJVRNFylmIhPBeiAMDfLukgG)
    for oCjQYpWJVRNFylmIhPBeiAMDfLukga in oCjQYpWJVRNFylmIhPBeiAMDfLukgq.get('director'):
     if oCjQYpWJVRNFylmIhPBeiAMDfLukga!='':oCjQYpWJVRNFylmIhPBeiAMDfLukgt.append(oCjQYpWJVRNFylmIhPBeiAMDfLukga)
    oCjQYpWJVRNFylmIhPBeiAMDfLukgs={'moviecode':oCjQYpWJVRNFylmIhPBeiAMDfLukgE,'title':oCjQYpWJVRNFylmIhPBeiAMDfLuknq,'thumbnail':{'poster':oCjQYpWJVRNFylmIhPBeiAMDfLukgO,'thumb':oCjQYpWJVRNFylmIhPBeiAMDfLuknb,'clearlogo':oCjQYpWJVRNFylmIhPBeiAMDfLukgT,'fanart':oCjQYpWJVRNFylmIhPBeiAMDfLuknb},'year':oCjQYpWJVRNFylmIhPBeiAMDfLukgd,'info_title':oCjQYpWJVRNFylmIhPBeiAMDfLukXw,'synopsis':oCjQYpWJVRNFylmIhPBeiAMDfLuknE,'mpaa':oCjQYpWJVRNFylmIhPBeiAMDfLukgH,'duration':oCjQYpWJVRNFylmIhPBeiAMDfLukXa,'premiered':oCjQYpWJVRNFylmIhPBeiAMDfLukgK,'studio':oCjQYpWJVRNFylmIhPBeiAMDfLukXK,'info_genre':oCjQYpWJVRNFylmIhPBeiAMDfLukgw,'cast':oCjQYpWJVRNFylmIhPBeiAMDfLukgz,'director':oCjQYpWJVRNFylmIhPBeiAMDfLukgt,}
    oCjQYpWJVRNFylmIhPBeiAMDfLukvK.append(oCjQYpWJVRNFylmIhPBeiAMDfLukgs)
  except oCjQYpWJVRNFylmIhPBeiAMDfLuktz as exception:
   oCjQYpWJVRNFylmIhPBeiAMDfLukzc(exception)
  return oCjQYpWJVRNFylmIhPBeiAMDfLukvK,oCjQYpWJVRNFylmIhPBeiAMDfLukna
 def GetMovieGenre(oCjQYpWJVRNFylmIhPBeiAMDfLukOX):
  oCjQYpWJVRNFylmIhPBeiAMDfLukvK=[]
  oCjQYpWJVRNFylmIhPBeiAMDfLukna=oCjQYpWJVRNFylmIhPBeiAMDfLukzb
  try:
   oCjQYpWJVRNFylmIhPBeiAMDfLukvw ='/v2/media/movie/curations'
   oCjQYpWJVRNFylmIhPBeiAMDfLukvb=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.GetDefaultParams()
   oCjQYpWJVRNFylmIhPBeiAMDfLukvx={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   oCjQYpWJVRNFylmIhPBeiAMDfLukvb.update(oCjQYpWJVRNFylmIhPBeiAMDfLukvx)
   oCjQYpWJVRNFylmIhPBeiAMDfLukTS=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.API_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukvw
   oCjQYpWJVRNFylmIhPBeiAMDfLukTE=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.callRequestCookies('Get',oCjQYpWJVRNFylmIhPBeiAMDfLukTS,payload=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,params=oCjQYpWJVRNFylmIhPBeiAMDfLukvb,headers=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,cookies=oCjQYpWJVRNFylmIhPBeiAMDfLukzE)
   oCjQYpWJVRNFylmIhPBeiAMDfLukvr=json.loads(oCjQYpWJVRNFylmIhPBeiAMDfLukTE.text)
   if not('result' in oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']):return oCjQYpWJVRNFylmIhPBeiAMDfLukvK,oCjQYpWJVRNFylmIhPBeiAMDfLukna
   oCjQYpWJVRNFylmIhPBeiAMDfLuknr=oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']['result']
   for oCjQYpWJVRNFylmIhPBeiAMDfLukvs in oCjQYpWJVRNFylmIhPBeiAMDfLuknr:
    oCjQYpWJVRNFylmIhPBeiAMDfLukXs =oCjQYpWJVRNFylmIhPBeiAMDfLukvs['curation_code']
    oCjQYpWJVRNFylmIhPBeiAMDfLukXc =oCjQYpWJVRNFylmIhPBeiAMDfLukvs['curation_name']
    oCjQYpWJVRNFylmIhPBeiAMDfLukgs={'curation_code':oCjQYpWJVRNFylmIhPBeiAMDfLukXs,'curation_name':oCjQYpWJVRNFylmIhPBeiAMDfLukXc}
    oCjQYpWJVRNFylmIhPBeiAMDfLukvK.append(oCjQYpWJVRNFylmIhPBeiAMDfLukgs)
  except oCjQYpWJVRNFylmIhPBeiAMDfLuktz as exception:
   oCjQYpWJVRNFylmIhPBeiAMDfLukzc(exception)
  return oCjQYpWJVRNFylmIhPBeiAMDfLukvK,oCjQYpWJVRNFylmIhPBeiAMDfLukna
 def GetSearchList(oCjQYpWJVRNFylmIhPBeiAMDfLukOX,search_key,page_int,stype):
  oCjQYpWJVRNFylmIhPBeiAMDfLukXS=[]
  oCjQYpWJVRNFylmIhPBeiAMDfLukna=oCjQYpWJVRNFylmIhPBeiAMDfLukzb
  try:
   oCjQYpWJVRNFylmIhPBeiAMDfLukvw ='/search/getSearch.jsp'
   oCjQYpWJVRNFylmIhPBeiAMDfLukvb=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.GetDefaultParams()
   oCjQYpWJVRNFylmIhPBeiAMDfLukvx={'kwd':search_key,'category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':oCjQYpWJVRNFylmIhPBeiAMDfLuktO(page_int),'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','pageSize':oCjQYpWJVRNFylmIhPBeiAMDfLuktO(oCjQYpWJVRNFylmIhPBeiAMDfLukOX.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':oCjQYpWJVRNFylmIhPBeiAMDfLukOX.SCREENCODE,'os':oCjQYpWJVRNFylmIhPBeiAMDfLukOX.OSCODE,'network':oCjQYpWJVRNFylmIhPBeiAMDfLukOX.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':oCjQYpWJVRNFylmIhPBeiAMDfLuktO(oCjQYpWJVRNFylmIhPBeiAMDfLukOX.SEARCH_LIMIT)if stype=='vod' else '0','vodMVReqCnt':oCjQYpWJVRNFylmIhPBeiAMDfLuktO(oCjQYpWJVRNFylmIhPBeiAMDfLukOX.SEARCH_LIMIT)if stype=='movie' else '0','aloneReqCnt':'0','smrclipReqCnt':'0','pickClipReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','apiKey':oCjQYpWJVRNFylmIhPBeiAMDfLukOX.APIKEY,'networkCode':oCjQYpWJVRNFylmIhPBeiAMDfLukOX.NETWORKCODE,'osCode ':oCjQYpWJVRNFylmIhPBeiAMDfLukOX.OSCODE,'teleCode ':oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TELECODE,'screenCode ':oCjQYpWJVRNFylmIhPBeiAMDfLukOX.SCREENCODE}
   oCjQYpWJVRNFylmIhPBeiAMDfLukTS=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.SEARCH_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukvw
   oCjQYpWJVRNFylmIhPBeiAMDfLukTE=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.callRequestCookies('Get',oCjQYpWJVRNFylmIhPBeiAMDfLukTS,payload=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,params=oCjQYpWJVRNFylmIhPBeiAMDfLukvx,headers=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,cookies=oCjQYpWJVRNFylmIhPBeiAMDfLukzE)
   oCjQYpWJVRNFylmIhPBeiAMDfLukvr=json.loads(oCjQYpWJVRNFylmIhPBeiAMDfLukTE.text)
   if stype=='vod':
    if not('programRsb' in oCjQYpWJVRNFylmIhPBeiAMDfLukvr):return oCjQYpWJVRNFylmIhPBeiAMDfLukXS,oCjQYpWJVRNFylmIhPBeiAMDfLukna
    oCjQYpWJVRNFylmIhPBeiAMDfLukXq=oCjQYpWJVRNFylmIhPBeiAMDfLukvr['programRsb']['dataList']
    oCjQYpWJVRNFylmIhPBeiAMDfLukXE =oCjQYpWJVRNFylmIhPBeiAMDfLuktn(oCjQYpWJVRNFylmIhPBeiAMDfLukvr['programRsb']['count'])
    for oCjQYpWJVRNFylmIhPBeiAMDfLukvs in oCjQYpWJVRNFylmIhPBeiAMDfLukXq:
     oCjQYpWJVRNFylmIhPBeiAMDfLukgc=oCjQYpWJVRNFylmIhPBeiAMDfLukvs['mast_cd']
     oCjQYpWJVRNFylmIhPBeiAMDfLuknq =oCjQYpWJVRNFylmIhPBeiAMDfLukvs['mast_nm']
     oCjQYpWJVRNFylmIhPBeiAMDfLukgO=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukvs['web_url4']
     oCjQYpWJVRNFylmIhPBeiAMDfLuknb =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukvs['web_url']
     try:
      oCjQYpWJVRNFylmIhPBeiAMDfLukgz =[]
      oCjQYpWJVRNFylmIhPBeiAMDfLukgt=[]
      oCjQYpWJVRNFylmIhPBeiAMDfLukgw =[]
      oCjQYpWJVRNFylmIhPBeiAMDfLukXa =0
      oCjQYpWJVRNFylmIhPBeiAMDfLukgH =''
      oCjQYpWJVRNFylmIhPBeiAMDfLukgd =''
      oCjQYpWJVRNFylmIhPBeiAMDfLukXH =''
      if oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('actor') !='' and oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('actor') !='-':oCjQYpWJVRNFylmIhPBeiAMDfLukgz =oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('actor').split(',')
      if oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('director')!='' and oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('director')!='-':oCjQYpWJVRNFylmIhPBeiAMDfLukgt=oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('director').split(',')
      if oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('cate_nm')!='' and oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('cate_nm')!='-':oCjQYpWJVRNFylmIhPBeiAMDfLukgw =oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('cate_nm').split('/')
      if 'targetage' in oCjQYpWJVRNFylmIhPBeiAMDfLukvs:oCjQYpWJVRNFylmIhPBeiAMDfLukgH=oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('targetage')
      if 'broad_dt' in oCjQYpWJVRNFylmIhPBeiAMDfLukvs:
       oCjQYpWJVRNFylmIhPBeiAMDfLukgx=oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('broad_dt')
       oCjQYpWJVRNFylmIhPBeiAMDfLukXH='%s-%s-%s'%(oCjQYpWJVRNFylmIhPBeiAMDfLukgx[:4],oCjQYpWJVRNFylmIhPBeiAMDfLukgx[4:6],oCjQYpWJVRNFylmIhPBeiAMDfLukgx[6:])
       oCjQYpWJVRNFylmIhPBeiAMDfLukgd =oCjQYpWJVRNFylmIhPBeiAMDfLukgx[:4]
     except:
      oCjQYpWJVRNFylmIhPBeiAMDfLukzE
     oCjQYpWJVRNFylmIhPBeiAMDfLukgs={'program':oCjQYpWJVRNFylmIhPBeiAMDfLukgc,'title':oCjQYpWJVRNFylmIhPBeiAMDfLuknq,'thumbnail':{'poster':oCjQYpWJVRNFylmIhPBeiAMDfLukgO,'thumb':oCjQYpWJVRNFylmIhPBeiAMDfLuknb,'fanart':oCjQYpWJVRNFylmIhPBeiAMDfLuknb},'synopsis':'','cast':oCjQYpWJVRNFylmIhPBeiAMDfLukgz,'director':oCjQYpWJVRNFylmIhPBeiAMDfLukgt,'info_genre':oCjQYpWJVRNFylmIhPBeiAMDfLukgw,'duration':oCjQYpWJVRNFylmIhPBeiAMDfLukXa,'mpaa':oCjQYpWJVRNFylmIhPBeiAMDfLukgH,'year':oCjQYpWJVRNFylmIhPBeiAMDfLukgd,'aired':oCjQYpWJVRNFylmIhPBeiAMDfLukXH}
     oCjQYpWJVRNFylmIhPBeiAMDfLukXS.append(oCjQYpWJVRNFylmIhPBeiAMDfLukgs)
   else:
    if not('vodMVRsb' in oCjQYpWJVRNFylmIhPBeiAMDfLukvr):return oCjQYpWJVRNFylmIhPBeiAMDfLukXS,oCjQYpWJVRNFylmIhPBeiAMDfLukna
    oCjQYpWJVRNFylmIhPBeiAMDfLukXb=oCjQYpWJVRNFylmIhPBeiAMDfLukvr['vodMVRsb']['dataList']
    oCjQYpWJVRNFylmIhPBeiAMDfLukXE =oCjQYpWJVRNFylmIhPBeiAMDfLuktn(oCjQYpWJVRNFylmIhPBeiAMDfLukvr['vodMVRsb']['count'])
    for oCjQYpWJVRNFylmIhPBeiAMDfLukvs in oCjQYpWJVRNFylmIhPBeiAMDfLukXb:
     oCjQYpWJVRNFylmIhPBeiAMDfLukgc=oCjQYpWJVRNFylmIhPBeiAMDfLukvs['mast_cd']
     oCjQYpWJVRNFylmIhPBeiAMDfLuknq =oCjQYpWJVRNFylmIhPBeiAMDfLukvs['mast_nm'].strip()
     oCjQYpWJVRNFylmIhPBeiAMDfLukgO =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukvs['web_url']
     oCjQYpWJVRNFylmIhPBeiAMDfLuknb =oCjQYpWJVRNFylmIhPBeiAMDfLukgO
     oCjQYpWJVRNFylmIhPBeiAMDfLukgT=''
     try:
      oCjQYpWJVRNFylmIhPBeiAMDfLukgz =[]
      oCjQYpWJVRNFylmIhPBeiAMDfLukgt=[]
      oCjQYpWJVRNFylmIhPBeiAMDfLukgw =[]
      oCjQYpWJVRNFylmIhPBeiAMDfLukXa =0
      oCjQYpWJVRNFylmIhPBeiAMDfLukgH =''
      oCjQYpWJVRNFylmIhPBeiAMDfLukgd =''
      oCjQYpWJVRNFylmIhPBeiAMDfLukXH =''
      if oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('actor') !='' and oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('actor') !='-':oCjQYpWJVRNFylmIhPBeiAMDfLukgz =oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('actor').split(',')
      if oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('director')!='' and oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('director')!='-':oCjQYpWJVRNFylmIhPBeiAMDfLukgt=oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('director').split(',')
      if oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('cate_nm')!='' and oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('cate_nm')!='-':oCjQYpWJVRNFylmIhPBeiAMDfLukgw =oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('cate_nm').split('/')
      if oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('runtime_sec')!='':oCjQYpWJVRNFylmIhPBeiAMDfLukXa=oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('runtime_sec')
      if 'grade_nm' in oCjQYpWJVRNFylmIhPBeiAMDfLukvs:oCjQYpWJVRNFylmIhPBeiAMDfLukgH=oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('grade_nm')
      oCjQYpWJVRNFylmIhPBeiAMDfLukgx=oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('broad_dt')
      if data_str!='':
       oCjQYpWJVRNFylmIhPBeiAMDfLukXH='%s-%s-%s'%(oCjQYpWJVRNFylmIhPBeiAMDfLukgx[:4],oCjQYpWJVRNFylmIhPBeiAMDfLukgx[4:6],oCjQYpWJVRNFylmIhPBeiAMDfLukgx[6:])
       oCjQYpWJVRNFylmIhPBeiAMDfLukgd =oCjQYpWJVRNFylmIhPBeiAMDfLukgx[:4]
     except:
      oCjQYpWJVRNFylmIhPBeiAMDfLukzE
     oCjQYpWJVRNFylmIhPBeiAMDfLukgs={'movie':oCjQYpWJVRNFylmIhPBeiAMDfLukgc,'title':oCjQYpWJVRNFylmIhPBeiAMDfLuknq,'thumbnail':{'poster':oCjQYpWJVRNFylmIhPBeiAMDfLukgO,'thumb':oCjQYpWJVRNFylmIhPBeiAMDfLuknb,'fanart':oCjQYpWJVRNFylmIhPBeiAMDfLuknb,'clearlogo':oCjQYpWJVRNFylmIhPBeiAMDfLukgT},'synopsis':'','cast':oCjQYpWJVRNFylmIhPBeiAMDfLukgz,'director':oCjQYpWJVRNFylmIhPBeiAMDfLukgt,'info_genre':oCjQYpWJVRNFylmIhPBeiAMDfLukgw,'duration':oCjQYpWJVRNFylmIhPBeiAMDfLukXa,'mpaa':oCjQYpWJVRNFylmIhPBeiAMDfLukgH,'year':oCjQYpWJVRNFylmIhPBeiAMDfLukgd,'aired':oCjQYpWJVRNFylmIhPBeiAMDfLukXH}
     oCjQYpWJVRNFylmIhPBeiAMDfLukXS.append(oCjQYpWJVRNFylmIhPBeiAMDfLukgs)
   if oCjQYpWJVRNFylmIhPBeiAMDfLukXE>(page_int*oCjQYpWJVRNFylmIhPBeiAMDfLukOX.SEARCH_LIMIT):oCjQYpWJVRNFylmIhPBeiAMDfLukna=oCjQYpWJVRNFylmIhPBeiAMDfLuktv
  except oCjQYpWJVRNFylmIhPBeiAMDfLuktz as exception:
   oCjQYpWJVRNFylmIhPBeiAMDfLukzc(exception)
  return oCjQYpWJVRNFylmIhPBeiAMDfLukXS,oCjQYpWJVRNFylmIhPBeiAMDfLukna
 def GetBookmarkInfo(oCjQYpWJVRNFylmIhPBeiAMDfLukOX,videoid,vidtype):
  oCjQYpWJVRNFylmIhPBeiAMDfLukzO={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   oCjQYpWJVRNFylmIhPBeiAMDfLukTS=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.API_DOMAIN+'/v2/media/program/'+videoid
   oCjQYpWJVRNFylmIhPBeiAMDfLukvb=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.GetDefaultParams()
   oCjQYpWJVRNFylmIhPBeiAMDfLukvx={'pageNo':'1','pageSize':'10','order':'name',}
   oCjQYpWJVRNFylmIhPBeiAMDfLukvb.update(oCjQYpWJVRNFylmIhPBeiAMDfLukvx)
   oCjQYpWJVRNFylmIhPBeiAMDfLukTE=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.callRequestCookies('Get',oCjQYpWJVRNFylmIhPBeiAMDfLukTS,payload=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,params=oCjQYpWJVRNFylmIhPBeiAMDfLukvb,headers=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,cookies=oCjQYpWJVRNFylmIhPBeiAMDfLukzE)
   oCjQYpWJVRNFylmIhPBeiAMDfLukgb=json.loads(oCjQYpWJVRNFylmIhPBeiAMDfLukTE.text)
   if not('body' in oCjQYpWJVRNFylmIhPBeiAMDfLukgb):return{}
   oCjQYpWJVRNFylmIhPBeiAMDfLukzT=oCjQYpWJVRNFylmIhPBeiAMDfLukgb['body']
   oCjQYpWJVRNFylmIhPBeiAMDfLuknq=oCjQYpWJVRNFylmIhPBeiAMDfLukzT.get('name').get('ko').strip()
   oCjQYpWJVRNFylmIhPBeiAMDfLukzO['saveinfo']['title'] =oCjQYpWJVRNFylmIhPBeiAMDfLuknq
   oCjQYpWJVRNFylmIhPBeiAMDfLukzO['saveinfo']['infoLabels']['title']=oCjQYpWJVRNFylmIhPBeiAMDfLuknq
   oCjQYpWJVRNFylmIhPBeiAMDfLukzO['saveinfo']['infoLabels']['mpaa'] =oCjQYpWJVRNFylmIhPBeiAMDfLukOU.get(oCjQYpWJVRNFylmIhPBeiAMDfLukzT.get('grade_code'))
   oCjQYpWJVRNFylmIhPBeiAMDfLukzO['saveinfo']['infoLabels']['plot'] =oCjQYpWJVRNFylmIhPBeiAMDfLukzT.get('synopsis').get('ko')
   oCjQYpWJVRNFylmIhPBeiAMDfLukzO['saveinfo']['infoLabels']['year'] =oCjQYpWJVRNFylmIhPBeiAMDfLukzT.get('product_year')
   oCjQYpWJVRNFylmIhPBeiAMDfLukzO['saveinfo']['infoLabels']['cast'] =oCjQYpWJVRNFylmIhPBeiAMDfLukzT.get('actor')
   oCjQYpWJVRNFylmIhPBeiAMDfLukzO['saveinfo']['infoLabels']['director']=oCjQYpWJVRNFylmIhPBeiAMDfLukzT.get('director')
   if oCjQYpWJVRNFylmIhPBeiAMDfLukzT.get('category1_name').get('ko')!='':
    oCjQYpWJVRNFylmIhPBeiAMDfLukzO['saveinfo']['infoLabels']['genre'].append(oCjQYpWJVRNFylmIhPBeiAMDfLukzT.get('category1_name').get('ko'))
   if oCjQYpWJVRNFylmIhPBeiAMDfLukzT.get('category2_name').get('ko')!='':
    oCjQYpWJVRNFylmIhPBeiAMDfLukzO['saveinfo']['infoLabels']['genre'].append(oCjQYpWJVRNFylmIhPBeiAMDfLukzT.get('category2_name').get('ko'))
   oCjQYpWJVRNFylmIhPBeiAMDfLukgx=oCjQYpWJVRNFylmIhPBeiAMDfLuktO(oCjQYpWJVRNFylmIhPBeiAMDfLukzT.get('broad_dt'))
   if oCjQYpWJVRNFylmIhPBeiAMDfLukgx!='0':oCjQYpWJVRNFylmIhPBeiAMDfLukzO['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(oCjQYpWJVRNFylmIhPBeiAMDfLukgx[:4],oCjQYpWJVRNFylmIhPBeiAMDfLukgx[4:6],oCjQYpWJVRNFylmIhPBeiAMDfLukgx[6:])
   oCjQYpWJVRNFylmIhPBeiAMDfLukgO =''
   oCjQYpWJVRNFylmIhPBeiAMDfLuknb =''
   oCjQYpWJVRNFylmIhPBeiAMDfLukgT=''
   oCjQYpWJVRNFylmIhPBeiAMDfLukgv =''
   oCjQYpWJVRNFylmIhPBeiAMDfLukgU =''
   for oCjQYpWJVRNFylmIhPBeiAMDfLukgX in oCjQYpWJVRNFylmIhPBeiAMDfLukzT.get('image'):
    if oCjQYpWJVRNFylmIhPBeiAMDfLukgX.get('code')=='CAIP0900':oCjQYpWJVRNFylmIhPBeiAMDfLukgO =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX.get('url')
    elif oCjQYpWJVRNFylmIhPBeiAMDfLukgX.get('code')=='CAIP0200':oCjQYpWJVRNFylmIhPBeiAMDfLuknb =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX.get('url')
    elif oCjQYpWJVRNFylmIhPBeiAMDfLukgX.get('code')=='CAIP1800':oCjQYpWJVRNFylmIhPBeiAMDfLukgT=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX.get('url')
    elif oCjQYpWJVRNFylmIhPBeiAMDfLukgX.get('code')=='CAIP2000':oCjQYpWJVRNFylmIhPBeiAMDfLukgv =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX.get('url')
    elif oCjQYpWJVRNFylmIhPBeiAMDfLukgX.get('code')=='CAIP1900':oCjQYpWJVRNFylmIhPBeiAMDfLukgU =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX.get('url')
   oCjQYpWJVRNFylmIhPBeiAMDfLukzO['saveinfo']['thumbnail']['poster']=oCjQYpWJVRNFylmIhPBeiAMDfLukgO
   oCjQYpWJVRNFylmIhPBeiAMDfLukzO['saveinfo']['thumbnail']['thumb']=oCjQYpWJVRNFylmIhPBeiAMDfLuknb
   oCjQYpWJVRNFylmIhPBeiAMDfLukzO['saveinfo']['thumbnail']['clearlogo']=oCjQYpWJVRNFylmIhPBeiAMDfLukgT
   oCjQYpWJVRNFylmIhPBeiAMDfLukzO['saveinfo']['thumbnail']['icon']=oCjQYpWJVRNFylmIhPBeiAMDfLukgv
   oCjQYpWJVRNFylmIhPBeiAMDfLukzO['saveinfo']['thumbnail']['banner']=oCjQYpWJVRNFylmIhPBeiAMDfLukgU
   oCjQYpWJVRNFylmIhPBeiAMDfLukzO['saveinfo']['thumbnail']['fanart']=oCjQYpWJVRNFylmIhPBeiAMDfLuknb
  else:
   oCjQYpWJVRNFylmIhPBeiAMDfLukTS=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.API_DOMAIN+'/v2a/media/stream/info'
   oCjQYpWJVRNFylmIhPBeiAMDfLukvb=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.GetDefaultParams()
   oCjQYpWJVRNFylmIhPBeiAMDfLukvx={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TV['cookies']['tving_uuid'].split('-')[0],'uuid':oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TV['cookies']['tving_uuid'],'deviceInfo':'PC_Chrome','noCache':oCjQYpWJVRNFylmIhPBeiAMDfLuktO(oCjQYpWJVRNFylmIhPBeiAMDfLukOX.GetNoCache(1)),'wm':'Y',}
   oCjQYpWJVRNFylmIhPBeiAMDfLukvb.update(oCjQYpWJVRNFylmIhPBeiAMDfLukvx)
   oCjQYpWJVRNFylmIhPBeiAMDfLukTE=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.callRequestCookies('Get',oCjQYpWJVRNFylmIhPBeiAMDfLukTS,payload=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,params=oCjQYpWJVRNFylmIhPBeiAMDfLukvb,headers=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,cookies=oCjQYpWJVRNFylmIhPBeiAMDfLukzE)
   oCjQYpWJVRNFylmIhPBeiAMDfLukgb=json.loads(oCjQYpWJVRNFylmIhPBeiAMDfLukTE.text)
   if not('content' in oCjQYpWJVRNFylmIhPBeiAMDfLukgb['body']):return{}
   oCjQYpWJVRNFylmIhPBeiAMDfLukzT=oCjQYpWJVRNFylmIhPBeiAMDfLukgb['body']['content']['info']['movie']
   oCjQYpWJVRNFylmIhPBeiAMDfLuknq =oCjQYpWJVRNFylmIhPBeiAMDfLukzT.get('name').get('ko').strip()
   oCjQYpWJVRNFylmIhPBeiAMDfLukzO['saveinfo']['infoLabels']['title']=oCjQYpWJVRNFylmIhPBeiAMDfLuknq
   oCjQYpWJVRNFylmIhPBeiAMDfLuknq +=u' (%s)'%(oCjQYpWJVRNFylmIhPBeiAMDfLukzT.get('product_year'))
   oCjQYpWJVRNFylmIhPBeiAMDfLukzO['saveinfo']['title'] =oCjQYpWJVRNFylmIhPBeiAMDfLuknq
   oCjQYpWJVRNFylmIhPBeiAMDfLukzO['saveinfo']['infoLabels']['mpaa'] =oCjQYpWJVRNFylmIhPBeiAMDfLukOU.get(oCjQYpWJVRNFylmIhPBeiAMDfLukzT.get('grade_code'))
   oCjQYpWJVRNFylmIhPBeiAMDfLukzO['saveinfo']['infoLabels']['plot'] =oCjQYpWJVRNFylmIhPBeiAMDfLukzT.get('story').get('ko')
   oCjQYpWJVRNFylmIhPBeiAMDfLukzO['saveinfo']['infoLabels']['year'] =oCjQYpWJVRNFylmIhPBeiAMDfLukzT.get('product_year')
   oCjQYpWJVRNFylmIhPBeiAMDfLukzO['saveinfo']['infoLabels']['studio'] =oCjQYpWJVRNFylmIhPBeiAMDfLukzT.get('production')
   oCjQYpWJVRNFylmIhPBeiAMDfLukzO['saveinfo']['infoLabels']['duration']=oCjQYpWJVRNFylmIhPBeiAMDfLukzT.get('duration')
   oCjQYpWJVRNFylmIhPBeiAMDfLukzO['saveinfo']['infoLabels']['cast'] =oCjQYpWJVRNFylmIhPBeiAMDfLukzT.get('actor')
   oCjQYpWJVRNFylmIhPBeiAMDfLukzO['saveinfo']['infoLabels']['director']=oCjQYpWJVRNFylmIhPBeiAMDfLukzT.get('director')
   if oCjQYpWJVRNFylmIhPBeiAMDfLukzT.get('category1_name').get('ko')!='':
    oCjQYpWJVRNFylmIhPBeiAMDfLukzO['saveinfo']['infoLabels']['genre'].append(oCjQYpWJVRNFylmIhPBeiAMDfLukzT.get('category1_name').get('ko'))
   if oCjQYpWJVRNFylmIhPBeiAMDfLukzT.get('category2_name').get('ko')!='':
    oCjQYpWJVRNFylmIhPBeiAMDfLukzO['saveinfo']['infoLabels']['genre'].append(oCjQYpWJVRNFylmIhPBeiAMDfLukzT.get('category2_name').get('ko'))
   oCjQYpWJVRNFylmIhPBeiAMDfLukgx=oCjQYpWJVRNFylmIhPBeiAMDfLuktO(oCjQYpWJVRNFylmIhPBeiAMDfLukzT.get('release_date'))
   if oCjQYpWJVRNFylmIhPBeiAMDfLukgx!='0':oCjQYpWJVRNFylmIhPBeiAMDfLukzO['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(oCjQYpWJVRNFylmIhPBeiAMDfLukgx[:4],oCjQYpWJVRNFylmIhPBeiAMDfLukgx[4:6],oCjQYpWJVRNFylmIhPBeiAMDfLukgx[6:])
   oCjQYpWJVRNFylmIhPBeiAMDfLukgO=''
   oCjQYpWJVRNFylmIhPBeiAMDfLuknb =''
   oCjQYpWJVRNFylmIhPBeiAMDfLukgT=''
   for oCjQYpWJVRNFylmIhPBeiAMDfLukgX in oCjQYpWJVRNFylmIhPBeiAMDfLukzT.get('image'):
    if oCjQYpWJVRNFylmIhPBeiAMDfLukgX.get('code')=='CAIM2100':oCjQYpWJVRNFylmIhPBeiAMDfLukgO =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX.get('url')
    elif oCjQYpWJVRNFylmIhPBeiAMDfLukgX.get('code')=='CAIM0400':oCjQYpWJVRNFylmIhPBeiAMDfLuknb =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX.get('url')
    elif oCjQYpWJVRNFylmIhPBeiAMDfLukgX.get('code')=='CAIM1800':oCjQYpWJVRNFylmIhPBeiAMDfLukgT=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.IMG_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukgX.get('url')
   oCjQYpWJVRNFylmIhPBeiAMDfLukzO['saveinfo']['thumbnail']['poster']=oCjQYpWJVRNFylmIhPBeiAMDfLukgO
   oCjQYpWJVRNFylmIhPBeiAMDfLukzO['saveinfo']['thumbnail']['thumb']=oCjQYpWJVRNFylmIhPBeiAMDfLukgO 
   oCjQYpWJVRNFylmIhPBeiAMDfLukzO['saveinfo']['thumbnail']['clearlogo']=oCjQYpWJVRNFylmIhPBeiAMDfLukgT
   oCjQYpWJVRNFylmIhPBeiAMDfLukzO['saveinfo']['thumbnail']['fanart']=oCjQYpWJVRNFylmIhPBeiAMDfLuknb
  return oCjQYpWJVRNFylmIhPBeiAMDfLukzO
 def GetEuroChannelList(oCjQYpWJVRNFylmIhPBeiAMDfLukOX):
  oCjQYpWJVRNFylmIhPBeiAMDfLukvK=[]
  try:
   oCjQYpWJVRNFylmIhPBeiAMDfLukvw ='/v2/operator/highlights'
   oCjQYpWJVRNFylmIhPBeiAMDfLukvb=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.GetDefaultParams()
   oCjQYpWJVRNFylmIhPBeiAMDfLukvx={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':oCjQYpWJVRNFylmIhPBeiAMDfLuktO(oCjQYpWJVRNFylmIhPBeiAMDfLukOX.GetNoCache(2))}
   oCjQYpWJVRNFylmIhPBeiAMDfLukvb.update(oCjQYpWJVRNFylmIhPBeiAMDfLukvx)
   oCjQYpWJVRNFylmIhPBeiAMDfLukTS=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.API_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukvw
   oCjQYpWJVRNFylmIhPBeiAMDfLukTE=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.callRequestCookies('Get',oCjQYpWJVRNFylmIhPBeiAMDfLukTS,payload=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,params=oCjQYpWJVRNFylmIhPBeiAMDfLukvb,headers=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,cookies=oCjQYpWJVRNFylmIhPBeiAMDfLukzE)
   oCjQYpWJVRNFylmIhPBeiAMDfLukvr=json.loads(oCjQYpWJVRNFylmIhPBeiAMDfLukTE.text)
   if not('result' in oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']):return oCjQYpWJVRNFylmIhPBeiAMDfLukvK,oCjQYpWJVRNFylmIhPBeiAMDfLukna
   oCjQYpWJVRNFylmIhPBeiAMDfLuknr=oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']['result']
   oCjQYpWJVRNFylmIhPBeiAMDfLukzv =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.Get_Now_Datetime()
   oCjQYpWJVRNFylmIhPBeiAMDfLukzU=oCjQYpWJVRNFylmIhPBeiAMDfLukzv+datetime.timedelta(days=-1)
   oCjQYpWJVRNFylmIhPBeiAMDfLukzU=oCjQYpWJVRNFylmIhPBeiAMDfLuktn(oCjQYpWJVRNFylmIhPBeiAMDfLukzU.strftime('%Y%m%d'))
   for oCjQYpWJVRNFylmIhPBeiAMDfLukvs in oCjQYpWJVRNFylmIhPBeiAMDfLuknr:
    oCjQYpWJVRNFylmIhPBeiAMDfLukzn=oCjQYpWJVRNFylmIhPBeiAMDfLuktn(oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('content').get('banner_title2')[:8])
    if oCjQYpWJVRNFylmIhPBeiAMDfLukzU<=oCjQYpWJVRNFylmIhPBeiAMDfLukzn:
     oCjQYpWJVRNFylmIhPBeiAMDfLukgs={'channel':oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('content').get('banner_sub_title3'),'title':oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('content').get('banner_title'),'subtitle':oCjQYpWJVRNFylmIhPBeiAMDfLukvs.get('content').get('banner_sub_title2'),}
     oCjQYpWJVRNFylmIhPBeiAMDfLukvK.append(oCjQYpWJVRNFylmIhPBeiAMDfLukgs)
  except oCjQYpWJVRNFylmIhPBeiAMDfLuktz as exception:
   oCjQYpWJVRNFylmIhPBeiAMDfLukzc(exception)
  return oCjQYpWJVRNFylmIhPBeiAMDfLukvK
 def Make_DecryptKey(oCjQYpWJVRNFylmIhPBeiAMDfLukOX,step,mediacode='000',timecode='000'):
  if step=='1':
   oCjQYpWJVRNFylmIhPBeiAMDfLukTw=oCjQYpWJVRNFylmIhPBeiAMDfLuktX('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   oCjQYpWJVRNFylmIhPBeiAMDfLukTd=oCjQYpWJVRNFylmIhPBeiAMDfLuktX('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   oCjQYpWJVRNFylmIhPBeiAMDfLukTw=oCjQYpWJVRNFylmIhPBeiAMDfLuktX('kss2lym0kdw1lks3','utf-8')
   oCjQYpWJVRNFylmIhPBeiAMDfLukTd=oCjQYpWJVRNFylmIhPBeiAMDfLuktX([42,7,114,59,55,5,30,1,110,68,2,51,42,97,38,60])
  return oCjQYpWJVRNFylmIhPBeiAMDfLukTw,oCjQYpWJVRNFylmIhPBeiAMDfLukTd
 def DecryptPlaintext(oCjQYpWJVRNFylmIhPBeiAMDfLukOX,oCjQYpWJVRNFylmIhPBeiAMDfLukTa,oCjQYpWJVRNFylmIhPBeiAMDfLukTH,oCjQYpWJVRNFylmIhPBeiAMDfLukTK):
  oCjQYpWJVRNFylmIhPBeiAMDfLukTG=AES.new(oCjQYpWJVRNFylmIhPBeiAMDfLukTH,AES.MODE_CBC,oCjQYpWJVRNFylmIhPBeiAMDfLukTK,)
  oCjQYpWJVRNFylmIhPBeiAMDfLukTx=Padding.unpad(oCjQYpWJVRNFylmIhPBeiAMDfLukTG.decrypt(base64.standard_b64decode(oCjQYpWJVRNFylmIhPBeiAMDfLukTa)),16)
  return oCjQYpWJVRNFylmIhPBeiAMDfLukTx.decode('utf-8')
 def Decrypt_Url(oCjQYpWJVRNFylmIhPBeiAMDfLukOX,oCjQYpWJVRNFylmIhPBeiAMDfLukTa,mediacode,oCjQYpWJVRNFylmIhPBeiAMDfLukUX):
  oCjQYpWJVRNFylmIhPBeiAMDfLukzg=''
  oCjQYpWJVRNFylmIhPBeiAMDfLukUz=''
  oCjQYpWJVRNFylmIhPBeiAMDfLukUt=''
  try:
   oCjQYpWJVRNFylmIhPBeiAMDfLukTw,oCjQYpWJVRNFylmIhPBeiAMDfLukTd=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.Make_DecryptKey('1',mediacode=mediacode,timecode=oCjQYpWJVRNFylmIhPBeiAMDfLukUX)
   oCjQYpWJVRNFylmIhPBeiAMDfLukzX=json.loads(oCjQYpWJVRNFylmIhPBeiAMDfLukOX.DecryptPlaintext(oCjQYpWJVRNFylmIhPBeiAMDfLukTa,oCjQYpWJVRNFylmIhPBeiAMDfLukTw,oCjQYpWJVRNFylmIhPBeiAMDfLukTd))
   oCjQYpWJVRNFylmIhPBeiAMDfLukzc(oCjQYpWJVRNFylmIhPBeiAMDfLukzX)
   oCjQYpWJVRNFylmIhPBeiAMDfLukzt =oCjQYpWJVRNFylmIhPBeiAMDfLukzX.get('url')
   oCjQYpWJVRNFylmIhPBeiAMDfLukUz =oCjQYpWJVRNFylmIhPBeiAMDfLukzX.get('watermark') if 'watermark' in oCjQYpWJVRNFylmIhPBeiAMDfLukzX else ''
   oCjQYpWJVRNFylmIhPBeiAMDfLukUt=oCjQYpWJVRNFylmIhPBeiAMDfLukzX.get('watermark_key')if 'watermark_key' in oCjQYpWJVRNFylmIhPBeiAMDfLukzX else ''
   oCjQYpWJVRNFylmIhPBeiAMDfLukTw,oCjQYpWJVRNFylmIhPBeiAMDfLukTd=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.Make_DecryptKey('2',mediacode=mediacode,timecode=oCjQYpWJVRNFylmIhPBeiAMDfLukUX)
   oCjQYpWJVRNFylmIhPBeiAMDfLukzg=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.DecryptPlaintext(oCjQYpWJVRNFylmIhPBeiAMDfLukzt,oCjQYpWJVRNFylmIhPBeiAMDfLukTw,oCjQYpWJVRNFylmIhPBeiAMDfLukTd)
  except oCjQYpWJVRNFylmIhPBeiAMDfLuktz as exception:
   oCjQYpWJVRNFylmIhPBeiAMDfLukzc(exception)
  return oCjQYpWJVRNFylmIhPBeiAMDfLukzg,oCjQYpWJVRNFylmIhPBeiAMDfLukUz,oCjQYpWJVRNFylmIhPBeiAMDfLukUt
 def Get_AppleGroup_List(oCjQYpWJVRNFylmIhPBeiAMDfLukOX):
  oCjQYpWJVRNFylmIhPBeiAMDfLukzw=[]
  try:
   oCjQYpWJVRNFylmIhPBeiAMDfLukvw ='/_next/data/DoF0_C0zHu6QDFRwifhZy/ko/more/special/SP0071.json'
   oCjQYpWJVRNFylmIhPBeiAMDfLukvx={'key':'SP0071'}
   oCjQYpWJVRNFylmIhPBeiAMDfLukTS=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.URL_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukvw
   oCjQYpWJVRNFylmIhPBeiAMDfLukTE=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.callRequestCookies('Get',oCjQYpWJVRNFylmIhPBeiAMDfLukTS,payload=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,params=oCjQYpWJVRNFylmIhPBeiAMDfLukvx,headers=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,cookies=oCjQYpWJVRNFylmIhPBeiAMDfLukzE)
   oCjQYpWJVRNFylmIhPBeiAMDfLukgb=json.loads(oCjQYpWJVRNFylmIhPBeiAMDfLukTE.text)
   if not('pageProps' in oCjQYpWJVRNFylmIhPBeiAMDfLukgb):return oCjQYpWJVRNFylmIhPBeiAMDfLukzw
   oCjQYpWJVRNFylmIhPBeiAMDfLuknr=oCjQYpWJVRNFylmIhPBeiAMDfLukgb['pageProps']['dehydratedState']['queries'][0]['state']['data']['pages'][0]['data']['bands']
   for oCjQYpWJVRNFylmIhPBeiAMDfLukzd in oCjQYpWJVRNFylmIhPBeiAMDfLuknr:
    if oCjQYpWJVRNFylmIhPBeiAMDfLukzd['bandType']not in['VOD_BASIC']:continue
    oCjQYpWJVRNFylmIhPBeiAMDfLukzH =re.findall('/band/\w+|/curation/\w+',oCjQYpWJVRNFylmIhPBeiAMDfLukzd['moreUrl'])[0]
    oCjQYpWJVRNFylmIhPBeiAMDfLukgs={'bandName':oCjQYpWJVRNFylmIhPBeiAMDfLukzd['bandName'],'bandKey':oCjQYpWJVRNFylmIhPBeiAMDfLukzH.split('/')[2],'moreUrl':oCjQYpWJVRNFylmIhPBeiAMDfLukzH,}
    oCjQYpWJVRNFylmIhPBeiAMDfLukzw.append(oCjQYpWJVRNFylmIhPBeiAMDfLukgs)
  except oCjQYpWJVRNFylmIhPBeiAMDfLuktz as exception:
   oCjQYpWJVRNFylmIhPBeiAMDfLukzc(exception)
  return oCjQYpWJVRNFylmIhPBeiAMDfLukzw
 def Get_Band_VodList(oCjQYpWJVRNFylmIhPBeiAMDfLukOX,bandKey,oCjQYpWJVRNFylmIhPBeiAMDfLukzH):
  oCjQYpWJVRNFylmIhPBeiAMDfLukzK=[]
  try:
   oCjQYpWJVRNFylmIhPBeiAMDfLukvw ='/_next/data/DoF0_C0zHu6QDFRwifhZy/ko/more{}.json'.format(oCjQYpWJVRNFylmIhPBeiAMDfLukzH)
   oCjQYpWJVRNFylmIhPBeiAMDfLukvx={'key':bandKey}
   oCjQYpWJVRNFylmIhPBeiAMDfLukTS=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.URL_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukvw
   oCjQYpWJVRNFylmIhPBeiAMDfLukTE=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.callRequestCookies('Get',oCjQYpWJVRNFylmIhPBeiAMDfLukTS,payload=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,params=oCjQYpWJVRNFylmIhPBeiAMDfLukvx,headers=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,cookies=oCjQYpWJVRNFylmIhPBeiAMDfLukzE)
   oCjQYpWJVRNFylmIhPBeiAMDfLukgb=json.loads(oCjQYpWJVRNFylmIhPBeiAMDfLukTE.text)
   if not('pageProps' in oCjQYpWJVRNFylmIhPBeiAMDfLukgb):return oCjQYpWJVRNFylmIhPBeiAMDfLukzK
   if 'band' in oCjQYpWJVRNFylmIhPBeiAMDfLukzH:
    oCjQYpWJVRNFylmIhPBeiAMDfLuknr=oCjQYpWJVRNFylmIhPBeiAMDfLukgb['pageProps']['dehydratedState']['queries'][0]['state']['data']['pages'][0]['data']['band']['items']
   else:
    oCjQYpWJVRNFylmIhPBeiAMDfLuknr=oCjQYpWJVRNFylmIhPBeiAMDfLukgb['pageProps']['dehydratedState']['queries'][0]['state']['data']['data']['bands'][0]['items']
   for oCjQYpWJVRNFylmIhPBeiAMDfLukzd in oCjQYpWJVRNFylmIhPBeiAMDfLuknr:
    oCjQYpWJVRNFylmIhPBeiAMDfLukzG=oCjQYpWJVRNFylmIhPBeiAMDfLukzd['imageUrl']
    oCjQYpWJVRNFylmIhPBeiAMDfLukgs={'program':oCjQYpWJVRNFylmIhPBeiAMDfLukzd['code'],'title':oCjQYpWJVRNFylmIhPBeiAMDfLukzd['title'],'thumbnail':{'poster':oCjQYpWJVRNFylmIhPBeiAMDfLukzG,'thumb':oCjQYpWJVRNFylmIhPBeiAMDfLukzG,'fanart':oCjQYpWJVRNFylmIhPBeiAMDfLukzG},}
    oCjQYpWJVRNFylmIhPBeiAMDfLukzK.append(oCjQYpWJVRNFylmIhPBeiAMDfLukgs)
  except oCjQYpWJVRNFylmIhPBeiAMDfLuktz as exception:
   oCjQYpWJVRNFylmIhPBeiAMDfLukzc(exception)
  return oCjQYpWJVRNFylmIhPBeiAMDfLukzK
 def GetLiveURL_Test(oCjQYpWJVRNFylmIhPBeiAMDfLukOX,mediacode,sel_quality):
  oCjQYpWJVRNFylmIhPBeiAMDfLukvS ={'streaming_url':'','subtitleYn':oCjQYpWJVRNFylmIhPBeiAMDfLukzb,'error_msg':'','drm_server_url':'','drm_header_key':'','drm_header_value':'','url_filename':'',}
  oCjQYpWJVRNFylmIhPBeiAMDfLukvG =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TV['cookies']['tving_uuid'].split('-')[0] 
  oCjQYpWJVRNFylmIhPBeiAMDfLukvq =oCjQYpWJVRNFylmIhPBeiAMDfLukOX.TV['cookies']['tving_uuid'] 
  try:
   oCjQYpWJVRNFylmIhPBeiAMDfLukvE=oCjQYpWJVRNFylmIhPBeiAMDfLuktO(oCjQYpWJVRNFylmIhPBeiAMDfLukOX.GetNoCache(1))
   oCjQYpWJVRNFylmIhPBeiAMDfLukvw ='/v2/media/stream/info' 
   oCjQYpWJVRNFylmIhPBeiAMDfLukvb=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.GetDefaultParams()
   oCjQYpWJVRNFylmIhPBeiAMDfLukvx={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':oCjQYpWJVRNFylmIhPBeiAMDfLukvq,'deviceInfo':'PC','noCache':oCjQYpWJVRNFylmIhPBeiAMDfLukvE,}
   oCjQYpWJVRNFylmIhPBeiAMDfLukvb.update(oCjQYpWJVRNFylmIhPBeiAMDfLukvx)
   oCjQYpWJVRNFylmIhPBeiAMDfLukTS=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.API_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukvw
   oCjQYpWJVRNFylmIhPBeiAMDfLukOb=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.makeDefaultCookies()
   oCjQYpWJVRNFylmIhPBeiAMDfLukTE=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.callRequestCookies('Get',oCjQYpWJVRNFylmIhPBeiAMDfLukTS,payload=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,params=oCjQYpWJVRNFylmIhPBeiAMDfLukvb,headers=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,cookies=oCjQYpWJVRNFylmIhPBeiAMDfLukOb)
   if oCjQYpWJVRNFylmIhPBeiAMDfLukTE.status_code!=200:
    oCjQYpWJVRNFylmIhPBeiAMDfLukvS['error_msg']='First Step - {} error'.format(oCjQYpWJVRNFylmIhPBeiAMDfLukTE.status_code)
    return oCjQYpWJVRNFylmIhPBeiAMDfLukvS
   oCjQYpWJVRNFylmIhPBeiAMDfLukvr=json.loads(oCjQYpWJVRNFylmIhPBeiAMDfLukTE.text)
   if oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']['result']['code']=='060':
    for oCjQYpWJVRNFylmIhPBeiAMDfLukOc,oCjQYpWJVRNFylmIhPBeiAMDfLukOS in oCjQYpWJVRNFylmIhPBeiAMDfLukOv.items():
     if oCjQYpWJVRNFylmIhPBeiAMDfLukOS==sel_quality:
      oCjQYpWJVRNFylmIhPBeiAMDfLukUO=oCjQYpWJVRNFylmIhPBeiAMDfLukOc
   elif oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']['result']['code']!='000':
    oCjQYpWJVRNFylmIhPBeiAMDfLukvS['error_msg']=oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']['result']['message']
    return oCjQYpWJVRNFylmIhPBeiAMDfLukvS
   else: 
    if not('stream' in oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']):return oCjQYpWJVRNFylmIhPBeiAMDfLukvS
    oCjQYpWJVRNFylmIhPBeiAMDfLukUT=[]
    for oCjQYpWJVRNFylmIhPBeiAMDfLukOc,oCjQYpWJVRNFylmIhPBeiAMDfLukOS in oCjQYpWJVRNFylmIhPBeiAMDfLukOv.items():
     for oCjQYpWJVRNFylmIhPBeiAMDfLukvs in oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']['stream']['quality']:
      if oCjQYpWJVRNFylmIhPBeiAMDfLukvs['active']=='Y' and oCjQYpWJVRNFylmIhPBeiAMDfLukvs['code']==oCjQYpWJVRNFylmIhPBeiAMDfLukOc:
       oCjQYpWJVRNFylmIhPBeiAMDfLukUT.append({oCjQYpWJVRNFylmIhPBeiAMDfLukOv.get(oCjQYpWJVRNFylmIhPBeiAMDfLukvs['code']):oCjQYpWJVRNFylmIhPBeiAMDfLukvs['code']})
    oCjQYpWJVRNFylmIhPBeiAMDfLukUO=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.CheckQuality(sel_quality,oCjQYpWJVRNFylmIhPBeiAMDfLukUT)
  except oCjQYpWJVRNFylmIhPBeiAMDfLuktz as exception:
   oCjQYpWJVRNFylmIhPBeiAMDfLukzc(exception)
   oCjQYpWJVRNFylmIhPBeiAMDfLukvS['error_msg']='First Step - except error'
   return oCjQYpWJVRNFylmIhPBeiAMDfLukvS
  try:
   oCjQYpWJVRNFylmIhPBeiAMDfLukvE=oCjQYpWJVRNFylmIhPBeiAMDfLuktO(oCjQYpWJVRNFylmIhPBeiAMDfLukOX.GetNoCache(1))
   oCjQYpWJVRNFylmIhPBeiAMDfLukvw ='/v3/media/stream/info'
   oCjQYpWJVRNFylmIhPBeiAMDfLukvb=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.GetDefaultParams()
   oCjQYpWJVRNFylmIhPBeiAMDfLukvx={'mediaCode':mediacode,'deviceId':oCjQYpWJVRNFylmIhPBeiAMDfLukvG,'uuid':oCjQYpWJVRNFylmIhPBeiAMDfLukvq,'deviceInfo':'PC_Chrome','streamCode':oCjQYpWJVRNFylmIhPBeiAMDfLukUO,'noCache':oCjQYpWJVRNFylmIhPBeiAMDfLukvE,'callingFrom':'HTML5','model':oCjQYpWJVRNFylmIhPBeiAMDfLukOX.MODEL,'videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   oCjQYpWJVRNFylmIhPBeiAMDfLukvb.update(oCjQYpWJVRNFylmIhPBeiAMDfLukvx)
   oCjQYpWJVRNFylmIhPBeiAMDfLukTS=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.API_DOMAIN+oCjQYpWJVRNFylmIhPBeiAMDfLukvw
   oCjQYpWJVRNFylmIhPBeiAMDfLukOb=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.makeDefaultCookies()
   oCjQYpWJVRNFylmIhPBeiAMDfLukTE=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.callRequestCookies('Post',oCjQYpWJVRNFylmIhPBeiAMDfLukTS,payload=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,params=oCjQYpWJVRNFylmIhPBeiAMDfLukvb,headers=oCjQYpWJVRNFylmIhPBeiAMDfLukzE,cookies=oCjQYpWJVRNFylmIhPBeiAMDfLukOb,redirects=oCjQYpWJVRNFylmIhPBeiAMDfLuktv)
   oCjQYpWJVRNFylmIhPBeiAMDfLukvr=json.loads(oCjQYpWJVRNFylmIhPBeiAMDfLukTE.text)
   if oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']['result']['code']!='000':
    oCjQYpWJVRNFylmIhPBeiAMDfLukvS['error_msg']=oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']['result']['message']
    return oCjQYpWJVRNFylmIhPBeiAMDfLukvS
   oCjQYpWJVRNFylmIhPBeiAMDfLukUv=oCjQYpWJVRNFylmIhPBeiAMDfLukvr['body']['stream']
   if oCjQYpWJVRNFylmIhPBeiAMDfLukUv['drm_yn']=='Y':
    oCjQYpWJVRNFylmIhPBeiAMDfLukUn=oCjQYpWJVRNFylmIhPBeiAMDfLukUv['playback']['drm']['widevine']
    for oCjQYpWJVRNFylmIhPBeiAMDfLukUg in oCjQYpWJVRNFylmIhPBeiAMDfLukUv['playback']['drm']['license']['drm_license_data']:
     if oCjQYpWJVRNFylmIhPBeiAMDfLukUg['drm_type']=='Widevine':
      oCjQYpWJVRNFylmIhPBeiAMDfLukvS['drm_server_url'] =oCjQYpWJVRNFylmIhPBeiAMDfLukUg['drm_server_url']
      oCjQYpWJVRNFylmIhPBeiAMDfLukvS['drm_header_key'] =oCjQYpWJVRNFylmIhPBeiAMDfLukUg['drm_header_key']
      oCjQYpWJVRNFylmIhPBeiAMDfLukvS['drm_header_value']=oCjQYpWJVRNFylmIhPBeiAMDfLukUg['drm_header_value']
      break
   else:
    oCjQYpWJVRNFylmIhPBeiAMDfLukUn=oCjQYpWJVRNFylmIhPBeiAMDfLukUv['playback']['non_drm']
  except oCjQYpWJVRNFylmIhPBeiAMDfLuktz as exception:
   oCjQYpWJVRNFylmIhPBeiAMDfLukzc(exception)
   oCjQYpWJVRNFylmIhPBeiAMDfLukvS['error_msg']='Second Step - except error'
   return oCjQYpWJVRNFylmIhPBeiAMDfLukvS
  oCjQYpWJVRNFylmIhPBeiAMDfLukUX=oCjQYpWJVRNFylmIhPBeiAMDfLukvE
  oCjQYpWJVRNFylmIhPBeiAMDfLukUn=oCjQYpWJVRNFylmIhPBeiAMDfLukUn.split('|')[1]
  oCjQYpWJVRNFylmIhPBeiAMDfLukUn,oCjQYpWJVRNFylmIhPBeiAMDfLukUz,oCjQYpWJVRNFylmIhPBeiAMDfLukUt=oCjQYpWJVRNFylmIhPBeiAMDfLukOX.Decrypt_Url(oCjQYpWJVRNFylmIhPBeiAMDfLukUn,mediacode,oCjQYpWJVRNFylmIhPBeiAMDfLukUX)
  oCjQYpWJVRNFylmIhPBeiAMDfLukvS['streaming_url']=oCjQYpWJVRNFylmIhPBeiAMDfLukUn
  oCjQYpWJVRNFylmIhPBeiAMDfLukza =oCjQYpWJVRNFylmIhPBeiAMDfLukvS['streaming_url'].find('Policy=')
  if oCjQYpWJVRNFylmIhPBeiAMDfLukza!=-1:
   oCjQYpWJVRNFylmIhPBeiAMDfLukzx =oCjQYpWJVRNFylmIhPBeiAMDfLukvS['streaming_url'].split('?')[0]
   oCjQYpWJVRNFylmIhPBeiAMDfLukzr=oCjQYpWJVRNFylmIhPBeiAMDfLuktw(urllib.parse.parse_qsl(urllib.parse.urlsplit(oCjQYpWJVRNFylmIhPBeiAMDfLukvS['streaming_url']).query))
   oCjQYpWJVRNFylmIhPBeiAMDfLukvS['streaming_url']='{}&CloudFront-Policy={}'.format(oCjQYpWJVRNFylmIhPBeiAMDfLukvS['streaming_url'],oCjQYpWJVRNFylmIhPBeiAMDfLukzr['Policy'])
   oCjQYpWJVRNFylmIhPBeiAMDfLukvS['streaming_url']='{}&CloudFront-Signature={}'.format(oCjQYpWJVRNFylmIhPBeiAMDfLukvS['streaming_url'],oCjQYpWJVRNFylmIhPBeiAMDfLukzr['Signature'])
   oCjQYpWJVRNFylmIhPBeiAMDfLukvS['streaming_url']='{}&CloudFront-Key-Pair-Id={}'.format(oCjQYpWJVRNFylmIhPBeiAMDfLukvS['streaming_url'],oCjQYpWJVRNFylmIhPBeiAMDfLukzr['Key-Pair-Id'])
  oCjQYpWJVRNFylmIhPBeiAMDfLukzs=['_tving_token','accessToken','authToken',]
  for oCjQYpWJVRNFylmIhPBeiAMDfLukOc,oCjQYpWJVRNFylmIhPBeiAMDfLukOS in oCjQYpWJVRNFylmIhPBeiAMDfLukOb.items():
   if oCjQYpWJVRNFylmIhPBeiAMDfLukOc in oCjQYpWJVRNFylmIhPBeiAMDfLukzs:
    oCjQYpWJVRNFylmIhPBeiAMDfLukvS['streaming_url']='{}&{}={}'.format(oCjQYpWJVRNFylmIhPBeiAMDfLukvS['streaming_url'],oCjQYpWJVRNFylmIhPBeiAMDfLukOc,oCjQYpWJVRNFylmIhPBeiAMDfLukOS)
  oCjQYpWJVRNFylmIhPBeiAMDfLukzc(oCjQYpWJVRNFylmIhPBeiAMDfLukvS['streaming_url'])
  return oCjQYpWJVRNFylmIhPBeiAMDfLukvS
# Created by pyminifier (https://github.com/liftoff/pyminifier)
