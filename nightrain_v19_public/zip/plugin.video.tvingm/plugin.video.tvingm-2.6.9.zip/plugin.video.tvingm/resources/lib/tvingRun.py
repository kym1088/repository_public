__author__="NightRain"
VAtFyBPDjrRQsLMofgKeHSJxTOCWGi=object
VAtFyBPDjrRQsLMofgKeHSJxTOCWGz=None
VAtFyBPDjrRQsLMofgKeHSJxTOCWGw=int
VAtFyBPDjrRQsLMofgKeHSJxTOCWGm=True
VAtFyBPDjrRQsLMofgKeHSJxTOCWGc=False
VAtFyBPDjrRQsLMofgKeHSJxTOCWGp=type
VAtFyBPDjrRQsLMofgKeHSJxTOCWGb=dict
VAtFyBPDjrRQsLMofgKeHSJxTOCWGv=getattr
VAtFyBPDjrRQsLMofgKeHSJxTOCWGE=list
VAtFyBPDjrRQsLMofgKeHSJxTOCWGh=len
VAtFyBPDjrRQsLMofgKeHSJxTOCWGY=str
VAtFyBPDjrRQsLMofgKeHSJxTOCWGI=range
VAtFyBPDjrRQsLMofgKeHSJxTOCWGd=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
VAtFyBPDjrRQsLMofgKeHSJxTOCWkU=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'오직 티빙에만','mode':'ORI_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'VOD 방송 - 4K','mode':'4K_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 4K','mode':'4K_MOVIE','stype':'-','orderby':'-','ordernm':'-'},{'title':'Apple TV+','mode':'APPLE_GROUP','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
VAtFyBPDjrRQsLMofgKeHSJxTOCWki=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
VAtFyBPDjrRQsLMofgKeHSJxTOCWkz=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
VAtFyBPDjrRQsLMofgKeHSJxTOCWkw=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
VAtFyBPDjrRQsLMofgKeHSJxTOCWkm=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'로맨스','mode':'PROGRAM','stype':'PCO'},{'title':'코미디','mode':'PROGRAM','stype':'PCP'},{'title':'스릴러','mode':'PROGRAM','stype':'PCQ'},{'title':'미스터리(추리)','mode':'PROGRAM','stype':'PCAA'},{'title':'모험','mode':'PROGRAM','stype':'PCX'},{'title':'액션','mode':'PROGRAM','stype':'PCY'},{'title':'판타지','mode':'PROGRAM','stype':'PCR'},{'title':'무협','mode':'PROGRAM','stype':'PCAB'},{'title':'공포','mode':'PROGRAM','stype':'PCAD'},{'title':'리얼리티','mode':'PROGRAM','stype':'PCV'},{'title':'토크쇼','mode':'PROGRAM','stype':'PCU'},{'title':'다큐멘터리','mode':'PROGRAM','stype':'PCT'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'스포츠','mode':'PROGRAM','stype':'PCF'},{'title':'음악','mode':'PROGRAM','stype':'PCAC'},{'title':'공연','mode':'PROGRAM','stype':'PCW'},{'title':'사극(시대극)','mode':'PROGRAM','stype':'PCS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'}]
VAtFyBPDjrRQsLMofgKeHSJxTOCWkc=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG23'},{'title':'로맨스','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'스릴러','mode':'MOVIE_SUB','stype':'MG140'},{'title':'미스터리','mode':'MOVIE_SUB','stype':'MG150'},{'title':'모험','mode':'MOVIE_SUB','stype':'MG170'},{'title':'액션','mode':'MOVIE_SUB','stype':'MG120'},{'title':'판타지','mode':'MOVIE_SUB','stype':'MG200'},{'title':'SF','mode':'MOVIE_SUB','stype':'MG210'},{'title':'공포','mode':'MOVIE_SUB','stype':'MG160'},{'title':'다큐멘터리','mode':'MOVIE_SUB','stype':'MG250'},{'title':'다양성 영화','mode':'MOVIE_SUB','stype':'diversityYn'}]
VAtFyBPDjrRQsLMofgKeHSJxTOCWkG=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
VAtFyBPDjrRQsLMofgKeHSJxTOCWkp={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
from tvingCore import*
VAtFyBPDjrRQsLMofgKeHSJxTOCWkb =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
VAtFyBPDjrRQsLMofgKeHSJxTOCWkv=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
class VAtFyBPDjrRQsLMofgKeHSJxTOCWkX(VAtFyBPDjrRQsLMofgKeHSJxTOCWGi):
 def __init__(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE,VAtFyBPDjrRQsLMofgKeHSJxTOCWkh,VAtFyBPDjrRQsLMofgKeHSJxTOCWkY,VAtFyBPDjrRQsLMofgKeHSJxTOCWkI):
  VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_url =VAtFyBPDjrRQsLMofgKeHSJxTOCWkh
  VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_handle=VAtFyBPDjrRQsLMofgKeHSJxTOCWkY
  VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.main_params =VAtFyBPDjrRQsLMofgKeHSJxTOCWkI
  VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj =oCjQYpWJVRNFylmIhPBeiAMDfLukOT() 
  VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.TV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_stream(mpd,m3u8)'))
 def addon_noti(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE,sting):
  try:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWka=xbmcgui.Dialog()
   VAtFyBPDjrRQsLMofgKeHSJxTOCWka.notification(__addonname__,sting)
  except:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWGz
 def addon_log(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE,string):
  try:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkq=string.encode('utf-8','ignore')
  except:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkq='addonException: addon_log'
  VAtFyBPDjrRQsLMofgKeHSJxTOCWku=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,VAtFyBPDjrRQsLMofgKeHSJxTOCWkq),level=VAtFyBPDjrRQsLMofgKeHSJxTOCWku)
 def get_keyboard_input(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE,VAtFyBPDjrRQsLMofgKeHSJxTOCWXI):
  VAtFyBPDjrRQsLMofgKeHSJxTOCWkN=VAtFyBPDjrRQsLMofgKeHSJxTOCWGz
  kb=xbmc.Keyboard()
  kb.setHeading(VAtFyBPDjrRQsLMofgKeHSJxTOCWXI)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkN=kb.getText()
  return VAtFyBPDjrRQsLMofgKeHSJxTOCWkN
 def get_settings_account(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE):
  VAtFyBPDjrRQsLMofgKeHSJxTOCWkl =__addon__.getSetting('id')
  VAtFyBPDjrRQsLMofgKeHSJxTOCWkn =__addon__.getSetting('pw')
  VAtFyBPDjrRQsLMofgKeHSJxTOCWXk =__addon__.getSetting('login_type')
  VAtFyBPDjrRQsLMofgKeHSJxTOCWXU=VAtFyBPDjrRQsLMofgKeHSJxTOCWGw(__addon__.getSetting('selected_profile'))
  return(VAtFyBPDjrRQsLMofgKeHSJxTOCWkl,VAtFyBPDjrRQsLMofgKeHSJxTOCWkn,VAtFyBPDjrRQsLMofgKeHSJxTOCWXk,VAtFyBPDjrRQsLMofgKeHSJxTOCWXU)
 def get_settings_uhd(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE):
  return VAtFyBPDjrRQsLMofgKeHSJxTOCWGm if __addon__.getSetting('active_uhd')=='true' else VAtFyBPDjrRQsLMofgKeHSJxTOCWGc
 def get_settings_playback(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE):
  VAtFyBPDjrRQsLMofgKeHSJxTOCWXi={'active_uhd':VAtFyBPDjrRQsLMofgKeHSJxTOCWGm if __addon__.getSetting('active_uhd')=='true' else VAtFyBPDjrRQsLMofgKeHSJxTOCWGc,'streamFilename':VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.TV_STREAM_FILENAME,}
  return VAtFyBPDjrRQsLMofgKeHSJxTOCWXi
 def get_settings_proxyport(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE):
  VAtFyBPDjrRQsLMofgKeHSJxTOCWXz =VAtFyBPDjrRQsLMofgKeHSJxTOCWGm if __addon__.getSetting('proxyYn')=='true' else VAtFyBPDjrRQsLMofgKeHSJxTOCWGc
  VAtFyBPDjrRQsLMofgKeHSJxTOCWXw=VAtFyBPDjrRQsLMofgKeHSJxTOCWGw(__addon__.getSetting('proxyPort'))
  return VAtFyBPDjrRQsLMofgKeHSJxTOCWXz,VAtFyBPDjrRQsLMofgKeHSJxTOCWXw
 def get_settings_totalsearch(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE):
  VAtFyBPDjrRQsLMofgKeHSJxTOCWXm =VAtFyBPDjrRQsLMofgKeHSJxTOCWGm if __addon__.getSetting('local_search')=='true' else VAtFyBPDjrRQsLMofgKeHSJxTOCWGc
  VAtFyBPDjrRQsLMofgKeHSJxTOCWXc=VAtFyBPDjrRQsLMofgKeHSJxTOCWGm if __addon__.getSetting('local_history')=='true' else VAtFyBPDjrRQsLMofgKeHSJxTOCWGc
  VAtFyBPDjrRQsLMofgKeHSJxTOCWXG =VAtFyBPDjrRQsLMofgKeHSJxTOCWGm if __addon__.getSetting('total_search')=='true' else VAtFyBPDjrRQsLMofgKeHSJxTOCWGc
  VAtFyBPDjrRQsLMofgKeHSJxTOCWXp=VAtFyBPDjrRQsLMofgKeHSJxTOCWGm if __addon__.getSetting('total_history')=='true' else VAtFyBPDjrRQsLMofgKeHSJxTOCWGc
  VAtFyBPDjrRQsLMofgKeHSJxTOCWXb=VAtFyBPDjrRQsLMofgKeHSJxTOCWGm if __addon__.getSetting('menu_bookmark')=='true' else VAtFyBPDjrRQsLMofgKeHSJxTOCWGc
  return(VAtFyBPDjrRQsLMofgKeHSJxTOCWXm,VAtFyBPDjrRQsLMofgKeHSJxTOCWXc,VAtFyBPDjrRQsLMofgKeHSJxTOCWXG,VAtFyBPDjrRQsLMofgKeHSJxTOCWXp,VAtFyBPDjrRQsLMofgKeHSJxTOCWXb)
 def get_settings_makebookmark(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE):
  return VAtFyBPDjrRQsLMofgKeHSJxTOCWGm if __addon__.getSetting('make_bookmark')=='true' else VAtFyBPDjrRQsLMofgKeHSJxTOCWGc
 def get_settings_direct_replay(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE):
  VAtFyBPDjrRQsLMofgKeHSJxTOCWXv=VAtFyBPDjrRQsLMofgKeHSJxTOCWGw(__addon__.getSetting('direct_replay'))
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWXv==0:
   return VAtFyBPDjrRQsLMofgKeHSJxTOCWGc
  else:
   return VAtFyBPDjrRQsLMofgKeHSJxTOCWGm
 def set_winEpisodeOrderby(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE,VAtFyBPDjrRQsLMofgKeHSJxTOCWXh):
  __addon__.setSetting('tving_orderby',VAtFyBPDjrRQsLMofgKeHSJxTOCWXh)
  VAtFyBPDjrRQsLMofgKeHSJxTOCWXE=xbmcgui.Window(10000)
  VAtFyBPDjrRQsLMofgKeHSJxTOCWXE.setProperty('TVING_M_ORDERBY',VAtFyBPDjrRQsLMofgKeHSJxTOCWXh)
 def get_winEpisodeOrderby(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE):
  VAtFyBPDjrRQsLMofgKeHSJxTOCWXh=__addon__.getSetting('tving_orderby')
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWXh in['',VAtFyBPDjrRQsLMofgKeHSJxTOCWGz]:VAtFyBPDjrRQsLMofgKeHSJxTOCWXh='desc'
  return VAtFyBPDjrRQsLMofgKeHSJxTOCWXh
 def add_dir(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE,label,sublabel='',img='',infoLabels=VAtFyBPDjrRQsLMofgKeHSJxTOCWGz,isFolder=VAtFyBPDjrRQsLMofgKeHSJxTOCWGm,params='',isLink=VAtFyBPDjrRQsLMofgKeHSJxTOCWGc,ContextMenu=VAtFyBPDjrRQsLMofgKeHSJxTOCWGz):
  VAtFyBPDjrRQsLMofgKeHSJxTOCWXY='%s?%s'%(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_url,urllib.parse.urlencode(params))
  if sublabel:VAtFyBPDjrRQsLMofgKeHSJxTOCWXI='%s < %s >'%(label,sublabel)
  else: VAtFyBPDjrRQsLMofgKeHSJxTOCWXI=label
  if not img:img='DefaultFolder.png'
  VAtFyBPDjrRQsLMofgKeHSJxTOCWXd=xbmcgui.ListItem(VAtFyBPDjrRQsLMofgKeHSJxTOCWXI)
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWGp(img)==VAtFyBPDjrRQsLMofgKeHSJxTOCWGb:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWXd.setArt(img)
  else:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWXd.setArt({'thumb':img,'poster':img})
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.KodiVersion>=20:
   if infoLabels:VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.Set_InfoTag(VAtFyBPDjrRQsLMofgKeHSJxTOCWXd.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:VAtFyBPDjrRQsLMofgKeHSJxTOCWXd.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWXd.setProperty('IsPlayable','true')
  if ContextMenu:VAtFyBPDjrRQsLMofgKeHSJxTOCWXd.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_handle,VAtFyBPDjrRQsLMofgKeHSJxTOCWXY,VAtFyBPDjrRQsLMofgKeHSJxTOCWXd,isFolder)
 def get_selQuality(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE,etype):
  try:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWXa='selected_quality'
   VAtFyBPDjrRQsLMofgKeHSJxTOCWXq=[1080,720,480,360]
   VAtFyBPDjrRQsLMofgKeHSJxTOCWXu=VAtFyBPDjrRQsLMofgKeHSJxTOCWGw(__addon__.getSetting(VAtFyBPDjrRQsLMofgKeHSJxTOCWXa))
   return VAtFyBPDjrRQsLMofgKeHSJxTOCWXq[VAtFyBPDjrRQsLMofgKeHSJxTOCWXu]
  except:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWGz
  return 720 
 def Set_InfoTag(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE,video_InfoTag:xbmc.InfoTagVideo,VAtFyBPDjrRQsLMofgKeHSJxTOCWUw):
  for VAtFyBPDjrRQsLMofgKeHSJxTOCWXN,value in VAtFyBPDjrRQsLMofgKeHSJxTOCWUw.items():
   if VAtFyBPDjrRQsLMofgKeHSJxTOCWkp[VAtFyBPDjrRQsLMofgKeHSJxTOCWXN]['type']=='string':
    VAtFyBPDjrRQsLMofgKeHSJxTOCWGv(video_InfoTag,VAtFyBPDjrRQsLMofgKeHSJxTOCWkp[VAtFyBPDjrRQsLMofgKeHSJxTOCWXN]['func'])(value)
   elif VAtFyBPDjrRQsLMofgKeHSJxTOCWkp[VAtFyBPDjrRQsLMofgKeHSJxTOCWXN]['type']=='int':
    if VAtFyBPDjrRQsLMofgKeHSJxTOCWGp(value)==VAtFyBPDjrRQsLMofgKeHSJxTOCWGw:
     VAtFyBPDjrRQsLMofgKeHSJxTOCWXl=VAtFyBPDjrRQsLMofgKeHSJxTOCWGw(value)
    else:
     VAtFyBPDjrRQsLMofgKeHSJxTOCWXl=0
    VAtFyBPDjrRQsLMofgKeHSJxTOCWGv(video_InfoTag,VAtFyBPDjrRQsLMofgKeHSJxTOCWkp[VAtFyBPDjrRQsLMofgKeHSJxTOCWXN]['func'])(VAtFyBPDjrRQsLMofgKeHSJxTOCWXl)
   elif VAtFyBPDjrRQsLMofgKeHSJxTOCWkp[VAtFyBPDjrRQsLMofgKeHSJxTOCWXN]['type']=='actor':
    if value!=[]:
     VAtFyBPDjrRQsLMofgKeHSJxTOCWGv(video_InfoTag,VAtFyBPDjrRQsLMofgKeHSJxTOCWkp[VAtFyBPDjrRQsLMofgKeHSJxTOCWXN]['func'])([xbmc.Actor(name)for name in value])
   elif VAtFyBPDjrRQsLMofgKeHSJxTOCWkp[VAtFyBPDjrRQsLMofgKeHSJxTOCWXN]['type']=='list':
    if VAtFyBPDjrRQsLMofgKeHSJxTOCWGp(value)==VAtFyBPDjrRQsLMofgKeHSJxTOCWGE:
     VAtFyBPDjrRQsLMofgKeHSJxTOCWGv(video_InfoTag,VAtFyBPDjrRQsLMofgKeHSJxTOCWkp[VAtFyBPDjrRQsLMofgKeHSJxTOCWXN]['func'])(value)
    else:
     VAtFyBPDjrRQsLMofgKeHSJxTOCWGv(video_InfoTag,VAtFyBPDjrRQsLMofgKeHSJxTOCWkp[VAtFyBPDjrRQsLMofgKeHSJxTOCWXN]['func'])([value])
 def dp_Main_List(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE):
  (VAtFyBPDjrRQsLMofgKeHSJxTOCWXm,VAtFyBPDjrRQsLMofgKeHSJxTOCWXc,VAtFyBPDjrRQsLMofgKeHSJxTOCWXG,VAtFyBPDjrRQsLMofgKeHSJxTOCWXp,VAtFyBPDjrRQsLMofgKeHSJxTOCWXb)=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.get_settings_totalsearch()
  for VAtFyBPDjrRQsLMofgKeHSJxTOCWXn in VAtFyBPDjrRQsLMofgKeHSJxTOCWkU:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWXI=VAtFyBPDjrRQsLMofgKeHSJxTOCWXn.get('title')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUk=''
   if VAtFyBPDjrRQsLMofgKeHSJxTOCWXn.get('mode')=='SEARCH_GROUP' and VAtFyBPDjrRQsLMofgKeHSJxTOCWXm ==VAtFyBPDjrRQsLMofgKeHSJxTOCWGc:continue
   elif VAtFyBPDjrRQsLMofgKeHSJxTOCWXn.get('mode')=='SEARCH_HISTORY' and VAtFyBPDjrRQsLMofgKeHSJxTOCWXc==VAtFyBPDjrRQsLMofgKeHSJxTOCWGc:continue
   elif VAtFyBPDjrRQsLMofgKeHSJxTOCWXn.get('mode')=='TOTAL_SEARCH' and VAtFyBPDjrRQsLMofgKeHSJxTOCWXG ==VAtFyBPDjrRQsLMofgKeHSJxTOCWGc:continue
   elif VAtFyBPDjrRQsLMofgKeHSJxTOCWXn.get('mode')=='TOTAL_HISTORY' and VAtFyBPDjrRQsLMofgKeHSJxTOCWXp==VAtFyBPDjrRQsLMofgKeHSJxTOCWGc:continue
   elif VAtFyBPDjrRQsLMofgKeHSJxTOCWXn.get('mode')=='MENU_BOOKMARK' and VAtFyBPDjrRQsLMofgKeHSJxTOCWXb==VAtFyBPDjrRQsLMofgKeHSJxTOCWGc:continue
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX={'mode':VAtFyBPDjrRQsLMofgKeHSJxTOCWXn.get('mode'),'stype':VAtFyBPDjrRQsLMofgKeHSJxTOCWXn.get('stype'),'orderby':VAtFyBPDjrRQsLMofgKeHSJxTOCWXn.get('orderby'),'ordernm':VAtFyBPDjrRQsLMofgKeHSJxTOCWXn.get('ordernm'),'page':'1'}
   if VAtFyBPDjrRQsLMofgKeHSJxTOCWXn.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    VAtFyBPDjrRQsLMofgKeHSJxTOCWUi=VAtFyBPDjrRQsLMofgKeHSJxTOCWGc
    VAtFyBPDjrRQsLMofgKeHSJxTOCWUz =VAtFyBPDjrRQsLMofgKeHSJxTOCWGm
   else:
    VAtFyBPDjrRQsLMofgKeHSJxTOCWUi=VAtFyBPDjrRQsLMofgKeHSJxTOCWGm
    VAtFyBPDjrRQsLMofgKeHSJxTOCWUz =VAtFyBPDjrRQsLMofgKeHSJxTOCWGc
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUw={'title':VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,'plot':VAtFyBPDjrRQsLMofgKeHSJxTOCWXI}
   if VAtFyBPDjrRQsLMofgKeHSJxTOCWXn.get('mode')=='XXX':VAtFyBPDjrRQsLMofgKeHSJxTOCWUw=VAtFyBPDjrRQsLMofgKeHSJxTOCWGz
   if 'icon' in VAtFyBPDjrRQsLMofgKeHSJxTOCWXn:VAtFyBPDjrRQsLMofgKeHSJxTOCWUk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',VAtFyBPDjrRQsLMofgKeHSJxTOCWXn.get('icon')) 
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.add_dir(VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,sublabel='',img=VAtFyBPDjrRQsLMofgKeHSJxTOCWUk,infoLabels=VAtFyBPDjrRQsLMofgKeHSJxTOCWUw,isFolder=VAtFyBPDjrRQsLMofgKeHSJxTOCWUi,params=VAtFyBPDjrRQsLMofgKeHSJxTOCWUX,isLink=VAtFyBPDjrRQsLMofgKeHSJxTOCWUz)
  xbmcplugin.endOfDirectory(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_handle)
 def login_main(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE):
  (VAtFyBPDjrRQsLMofgKeHSJxTOCWUc,VAtFyBPDjrRQsLMofgKeHSJxTOCWUG,VAtFyBPDjrRQsLMofgKeHSJxTOCWUp,VAtFyBPDjrRQsLMofgKeHSJxTOCWUb)=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.get_settings_account()
  if not(VAtFyBPDjrRQsLMofgKeHSJxTOCWUc and VAtFyBPDjrRQsLMofgKeHSJxTOCWUG):
   VAtFyBPDjrRQsLMofgKeHSJxTOCWka=xbmcgui.Dialog()
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUv=VAtFyBPDjrRQsLMofgKeHSJxTOCWka.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if VAtFyBPDjrRQsLMofgKeHSJxTOCWUv==VAtFyBPDjrRQsLMofgKeHSJxTOCWGm:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.cookiefile_check():return
  if base64.standard_b64encode(VAtFyBPDjrRQsLMofgKeHSJxTOCWUc.encode()).decode('utf-8')=='a3ltOTUxMDg4':
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUE=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.GetCredential2(VAtFyBPDjrRQsLMofgKeHSJxTOCWUc,VAtFyBPDjrRQsLMofgKeHSJxTOCWUG,VAtFyBPDjrRQsLMofgKeHSJxTOCWUp,VAtFyBPDjrRQsLMofgKeHSJxTOCWUb)
  else:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWka=xbmcgui.Dialog()
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUh=VAtFyBPDjrRQsLMofgKeHSJxTOCWka.browse(1,__language__(30917).encode('utf8'),'','.twc',VAtFyBPDjrRQsLMofgKeHSJxTOCWGc,VAtFyBPDjrRQsLMofgKeHSJxTOCWGc,'',VAtFyBPDjrRQsLMofgKeHSJxTOCWGc)
   if VAtFyBPDjrRQsLMofgKeHSJxTOCWUh!='':
    VAtFyBPDjrRQsLMofgKeHSJxTOCWUY=xbmcvfs.translatePath(os.path.join(__profile__,'tvinginfo-temp.twc'))
    xbmcvfs.copy(VAtFyBPDjrRQsLMofgKeHSJxTOCWUh,VAtFyBPDjrRQsLMofgKeHSJxTOCWUY)
    VAtFyBPDjrRQsLMofgKeHSJxTOCWUE=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.WebCookies_Load(VAtFyBPDjrRQsLMofgKeHSJxTOCWUY)
    xbmcvfs.delete(VAtFyBPDjrRQsLMofgKeHSJxTOCWUY)
    if VAtFyBPDjrRQsLMofgKeHSJxTOCWUE:
     VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.JsonFile_Save(VAtFyBPDjrRQsLMofgKeHSJxTOCWkb,VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.TV)
     VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.addon_noti(__language__(30918).encode('utf8'))
     return
   else:
    VAtFyBPDjrRQsLMofgKeHSJxTOCWUE=VAtFyBPDjrRQsLMofgKeHSJxTOCWGc
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWUE==VAtFyBPDjrRQsLMofgKeHSJxTOCWGm:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.cookiefile_save()
  else:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE,VAtFyBPDjrRQsLMofgKeHSJxTOCWUq):
  VAtFyBPDjrRQsLMofgKeHSJxTOCWUI=VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('stype')
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWUI=='live':
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUd=VAtFyBPDjrRQsLMofgKeHSJxTOCWki
  elif VAtFyBPDjrRQsLMofgKeHSJxTOCWUI=='vod':
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUd=VAtFyBPDjrRQsLMofgKeHSJxTOCWkm
  else:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUd=VAtFyBPDjrRQsLMofgKeHSJxTOCWkc
  for VAtFyBPDjrRQsLMofgKeHSJxTOCWUa in VAtFyBPDjrRQsLMofgKeHSJxTOCWUd:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWXI=VAtFyBPDjrRQsLMofgKeHSJxTOCWUa.get('title')
   if VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('ordernm')!='-':
    VAtFyBPDjrRQsLMofgKeHSJxTOCWXI+='  ('+VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('ordernm')+')'
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX={'mode':VAtFyBPDjrRQsLMofgKeHSJxTOCWUa.get('mode'),'stype':VAtFyBPDjrRQsLMofgKeHSJxTOCWUa.get('stype'),'orderby':VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('orderby'),'ordernm':VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('ordernm'),'page':'1'}
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.add_dir(VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,sublabel='',img='',infoLabels=VAtFyBPDjrRQsLMofgKeHSJxTOCWGz,isFolder=VAtFyBPDjrRQsLMofgKeHSJxTOCWGm,params=VAtFyBPDjrRQsLMofgKeHSJxTOCWUX)
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWGh(VAtFyBPDjrRQsLMofgKeHSJxTOCWUd)>0:xbmcplugin.endOfDirectory(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_handle)
 def dp_SubTitle_Group(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE,VAtFyBPDjrRQsLMofgKeHSJxTOCWUq): 
  for VAtFyBPDjrRQsLMofgKeHSJxTOCWUa in VAtFyBPDjrRQsLMofgKeHSJxTOCWkG:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWXI=VAtFyBPDjrRQsLMofgKeHSJxTOCWUa.get('title')
   if VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('ordernm')!='-':
    VAtFyBPDjrRQsLMofgKeHSJxTOCWXI+='  ('+VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('ordernm')+')'
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX={'mode':VAtFyBPDjrRQsLMofgKeHSJxTOCWUa.get('mode'),'genreCode':VAtFyBPDjrRQsLMofgKeHSJxTOCWUa.get('genreCode'),'stype':VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('stype'),'orderby':VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('orderby'),'page':'1'}
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.add_dir(VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,sublabel='',img='',infoLabels=VAtFyBPDjrRQsLMofgKeHSJxTOCWGz,isFolder=VAtFyBPDjrRQsLMofgKeHSJxTOCWGm,params=VAtFyBPDjrRQsLMofgKeHSJxTOCWUX)
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWGh(VAtFyBPDjrRQsLMofgKeHSJxTOCWkG)>0:xbmcplugin.endOfDirectory(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_handle)
 def dp_LiveChannel_List(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE,VAtFyBPDjrRQsLMofgKeHSJxTOCWUq):
  VAtFyBPDjrRQsLMofgKeHSJxTOCWUI =VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('stype')
  VAtFyBPDjrRQsLMofgKeHSJxTOCWUu =VAtFyBPDjrRQsLMofgKeHSJxTOCWGw(VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('page'))
  VAtFyBPDjrRQsLMofgKeHSJxTOCWUN,VAtFyBPDjrRQsLMofgKeHSJxTOCWUl=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.GetLiveChannelList(VAtFyBPDjrRQsLMofgKeHSJxTOCWUI,VAtFyBPDjrRQsLMofgKeHSJxTOCWUu)
  for VAtFyBPDjrRQsLMofgKeHSJxTOCWUn in VAtFyBPDjrRQsLMofgKeHSJxTOCWUN:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWXI =VAtFyBPDjrRQsLMofgKeHSJxTOCWUn.get('title')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUm =VAtFyBPDjrRQsLMofgKeHSJxTOCWUn.get('channel')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWik =VAtFyBPDjrRQsLMofgKeHSJxTOCWUn.get('thumbnail')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiX =VAtFyBPDjrRQsLMofgKeHSJxTOCWUn.get('synopsis')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiU =VAtFyBPDjrRQsLMofgKeHSJxTOCWUn.get('channelepg')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiz =VAtFyBPDjrRQsLMofgKeHSJxTOCWUn.get('cast')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiw =VAtFyBPDjrRQsLMofgKeHSJxTOCWUn.get('director')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWim =VAtFyBPDjrRQsLMofgKeHSJxTOCWUn.get('info_genre')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWic =VAtFyBPDjrRQsLMofgKeHSJxTOCWUn.get('year')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiG =VAtFyBPDjrRQsLMofgKeHSJxTOCWUn.get('mpaa')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWip =VAtFyBPDjrRQsLMofgKeHSJxTOCWUn.get('premiered')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWib={'mediatype':'episode','title':VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,'studio':VAtFyBPDjrRQsLMofgKeHSJxTOCWUm,'cast':VAtFyBPDjrRQsLMofgKeHSJxTOCWiz,'director':VAtFyBPDjrRQsLMofgKeHSJxTOCWiw,'genre':VAtFyBPDjrRQsLMofgKeHSJxTOCWim,'plot':'%s\n%s\n%s\n\n%s'%(VAtFyBPDjrRQsLMofgKeHSJxTOCWUm,VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,VAtFyBPDjrRQsLMofgKeHSJxTOCWiU,VAtFyBPDjrRQsLMofgKeHSJxTOCWiX),'year':VAtFyBPDjrRQsLMofgKeHSJxTOCWic,'mpaa':VAtFyBPDjrRQsLMofgKeHSJxTOCWiG,'premiered':VAtFyBPDjrRQsLMofgKeHSJxTOCWip}
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX={'mode':'LIVE','mediacode':VAtFyBPDjrRQsLMofgKeHSJxTOCWUn.get('mediacode'),'stype':VAtFyBPDjrRQsLMofgKeHSJxTOCWUI}
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.add_dir(VAtFyBPDjrRQsLMofgKeHSJxTOCWUm,sublabel=VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,img=VAtFyBPDjrRQsLMofgKeHSJxTOCWik,infoLabels=VAtFyBPDjrRQsLMofgKeHSJxTOCWib,isFolder=VAtFyBPDjrRQsLMofgKeHSJxTOCWGc,params=VAtFyBPDjrRQsLMofgKeHSJxTOCWUX)
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWUl:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX['mode']='CHANNEL' 
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX['stype']=VAtFyBPDjrRQsLMofgKeHSJxTOCWUI 
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX['page']=VAtFyBPDjrRQsLMofgKeHSJxTOCWGY(VAtFyBPDjrRQsLMofgKeHSJxTOCWUu+1)
   VAtFyBPDjrRQsLMofgKeHSJxTOCWXI='[B]%s >>[/B]'%'다음 페이지'
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiv=VAtFyBPDjrRQsLMofgKeHSJxTOCWGY(VAtFyBPDjrRQsLMofgKeHSJxTOCWUu+1)
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.add_dir(VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,sublabel=VAtFyBPDjrRQsLMofgKeHSJxTOCWiv,img=VAtFyBPDjrRQsLMofgKeHSJxTOCWUk,infoLabels=VAtFyBPDjrRQsLMofgKeHSJxTOCWGz,isFolder=VAtFyBPDjrRQsLMofgKeHSJxTOCWGm,params=VAtFyBPDjrRQsLMofgKeHSJxTOCWUX)
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWGh(VAtFyBPDjrRQsLMofgKeHSJxTOCWUN)>0:xbmcplugin.endOfDirectory(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_handle,cacheToDisc=VAtFyBPDjrRQsLMofgKeHSJxTOCWGc)
 def dp_Program_List(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE,VAtFyBPDjrRQsLMofgKeHSJxTOCWUq):
  VAtFyBPDjrRQsLMofgKeHSJxTOCWiE =VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('stype')
  VAtFyBPDjrRQsLMofgKeHSJxTOCWXh =VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('orderby')
  VAtFyBPDjrRQsLMofgKeHSJxTOCWUu =VAtFyBPDjrRQsLMofgKeHSJxTOCWGw(VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('page'))
  VAtFyBPDjrRQsLMofgKeHSJxTOCWih=VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('genreCode')
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWih==VAtFyBPDjrRQsLMofgKeHSJxTOCWGz:VAtFyBPDjrRQsLMofgKeHSJxTOCWih='all'
  VAtFyBPDjrRQsLMofgKeHSJxTOCWiY,VAtFyBPDjrRQsLMofgKeHSJxTOCWUl=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.GetProgramList(VAtFyBPDjrRQsLMofgKeHSJxTOCWiE,VAtFyBPDjrRQsLMofgKeHSJxTOCWXh,VAtFyBPDjrRQsLMofgKeHSJxTOCWUu,VAtFyBPDjrRQsLMofgKeHSJxTOCWih)
  for VAtFyBPDjrRQsLMofgKeHSJxTOCWiI in VAtFyBPDjrRQsLMofgKeHSJxTOCWiY:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWXI =VAtFyBPDjrRQsLMofgKeHSJxTOCWiI.get('title')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWik =VAtFyBPDjrRQsLMofgKeHSJxTOCWiI.get('thumbnail')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiX =VAtFyBPDjrRQsLMofgKeHSJxTOCWiI.get('synopsis')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWid =VAtFyBPDjrRQsLMofgKeHSJxTOCWiI.get('channel')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiz =VAtFyBPDjrRQsLMofgKeHSJxTOCWiI.get('cast')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiw =VAtFyBPDjrRQsLMofgKeHSJxTOCWiI.get('director')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWim=VAtFyBPDjrRQsLMofgKeHSJxTOCWiI.get('info_genre')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWic =VAtFyBPDjrRQsLMofgKeHSJxTOCWiI.get('year')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWip =VAtFyBPDjrRQsLMofgKeHSJxTOCWiI.get('premiered')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiG =VAtFyBPDjrRQsLMofgKeHSJxTOCWiI.get('mpaa')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWib={'mediatype':'tvshow','title':VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,'studio':VAtFyBPDjrRQsLMofgKeHSJxTOCWid,'cast':VAtFyBPDjrRQsLMofgKeHSJxTOCWiz,'director':VAtFyBPDjrRQsLMofgKeHSJxTOCWiw,'genre':VAtFyBPDjrRQsLMofgKeHSJxTOCWim,'year':VAtFyBPDjrRQsLMofgKeHSJxTOCWic,'premiered':VAtFyBPDjrRQsLMofgKeHSJxTOCWip,'mpaa':VAtFyBPDjrRQsLMofgKeHSJxTOCWiG,'plot':VAtFyBPDjrRQsLMofgKeHSJxTOCWiX}
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX={'mode':'EPISODE','programcode':VAtFyBPDjrRQsLMofgKeHSJxTOCWiI.get('program'),'page':'1'}
   if VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.get_settings_makebookmark():
    VAtFyBPDjrRQsLMofgKeHSJxTOCWia={'videoid':VAtFyBPDjrRQsLMofgKeHSJxTOCWiI.get('program'),'vidtype':'tvshow','vtitle':VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,'vsubtitle':VAtFyBPDjrRQsLMofgKeHSJxTOCWid,}
    VAtFyBPDjrRQsLMofgKeHSJxTOCWiq=json.dumps(VAtFyBPDjrRQsLMofgKeHSJxTOCWia)
    VAtFyBPDjrRQsLMofgKeHSJxTOCWiq=urllib.parse.quote(VAtFyBPDjrRQsLMofgKeHSJxTOCWiq)
    VAtFyBPDjrRQsLMofgKeHSJxTOCWiu='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(VAtFyBPDjrRQsLMofgKeHSJxTOCWiq)
    VAtFyBPDjrRQsLMofgKeHSJxTOCWiN=[('(통합) 찜 영상에 추가',VAtFyBPDjrRQsLMofgKeHSJxTOCWiu)]
   else:
    VAtFyBPDjrRQsLMofgKeHSJxTOCWiN=VAtFyBPDjrRQsLMofgKeHSJxTOCWGz
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.add_dir(VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,sublabel=VAtFyBPDjrRQsLMofgKeHSJxTOCWid,img=VAtFyBPDjrRQsLMofgKeHSJxTOCWik,infoLabels=VAtFyBPDjrRQsLMofgKeHSJxTOCWib,isFolder=VAtFyBPDjrRQsLMofgKeHSJxTOCWGm,params=VAtFyBPDjrRQsLMofgKeHSJxTOCWUX,ContextMenu=VAtFyBPDjrRQsLMofgKeHSJxTOCWiN)
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWUl:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX['mode'] ='PROGRAM' 
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX['stype'] =VAtFyBPDjrRQsLMofgKeHSJxTOCWiE
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX['orderby'] =VAtFyBPDjrRQsLMofgKeHSJxTOCWXh
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX['page'] =VAtFyBPDjrRQsLMofgKeHSJxTOCWGY(VAtFyBPDjrRQsLMofgKeHSJxTOCWUu+1)
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX['genreCode']=VAtFyBPDjrRQsLMofgKeHSJxTOCWih 
   VAtFyBPDjrRQsLMofgKeHSJxTOCWXI='[B]%s >>[/B]'%'다음 페이지'
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiv=VAtFyBPDjrRQsLMofgKeHSJxTOCWGY(VAtFyBPDjrRQsLMofgKeHSJxTOCWUu+1)
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.add_dir(VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,sublabel=VAtFyBPDjrRQsLMofgKeHSJxTOCWiv,img=VAtFyBPDjrRQsLMofgKeHSJxTOCWUk,infoLabels=VAtFyBPDjrRQsLMofgKeHSJxTOCWGz,isFolder=VAtFyBPDjrRQsLMofgKeHSJxTOCWGm,params=VAtFyBPDjrRQsLMofgKeHSJxTOCWUX)
  xbmcplugin.setContent(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_handle,cacheToDisc=VAtFyBPDjrRQsLMofgKeHSJxTOCWGc)
 def dp_4K_Program_List(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE,VAtFyBPDjrRQsLMofgKeHSJxTOCWUq):
  VAtFyBPDjrRQsLMofgKeHSJxTOCWUu =VAtFyBPDjrRQsLMofgKeHSJxTOCWGw(VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('page'))
  VAtFyBPDjrRQsLMofgKeHSJxTOCWiY,VAtFyBPDjrRQsLMofgKeHSJxTOCWUl=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.Get_UHD_ProgramList(VAtFyBPDjrRQsLMofgKeHSJxTOCWUu)
  for VAtFyBPDjrRQsLMofgKeHSJxTOCWiI in VAtFyBPDjrRQsLMofgKeHSJxTOCWiY:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWXI =VAtFyBPDjrRQsLMofgKeHSJxTOCWiI.get('title')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWik =VAtFyBPDjrRQsLMofgKeHSJxTOCWiI.get('thumbnail')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiX =VAtFyBPDjrRQsLMofgKeHSJxTOCWiI.get('synopsis')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWid =VAtFyBPDjrRQsLMofgKeHSJxTOCWiI.get('channel')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiz =VAtFyBPDjrRQsLMofgKeHSJxTOCWiI.get('cast')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiw =VAtFyBPDjrRQsLMofgKeHSJxTOCWiI.get('director')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWim=VAtFyBPDjrRQsLMofgKeHSJxTOCWiI.get('info_genre')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWic =VAtFyBPDjrRQsLMofgKeHSJxTOCWiI.get('year')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWip =VAtFyBPDjrRQsLMofgKeHSJxTOCWiI.get('premiered')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiG =VAtFyBPDjrRQsLMofgKeHSJxTOCWiI.get('mpaa')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWib={'mediatype':'tvshow','title':VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,'studio':VAtFyBPDjrRQsLMofgKeHSJxTOCWid,'cast':VAtFyBPDjrRQsLMofgKeHSJxTOCWiz,'director':VAtFyBPDjrRQsLMofgKeHSJxTOCWiw,'genre':VAtFyBPDjrRQsLMofgKeHSJxTOCWim,'year':VAtFyBPDjrRQsLMofgKeHSJxTOCWic,'premiered':VAtFyBPDjrRQsLMofgKeHSJxTOCWip,'mpaa':VAtFyBPDjrRQsLMofgKeHSJxTOCWiG,'plot':VAtFyBPDjrRQsLMofgKeHSJxTOCWiX}
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX={'mode':'EPISODE','programcode':VAtFyBPDjrRQsLMofgKeHSJxTOCWiI.get('program'),'page':'1'}
   if VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.get_settings_makebookmark():
    VAtFyBPDjrRQsLMofgKeHSJxTOCWia={'videoid':VAtFyBPDjrRQsLMofgKeHSJxTOCWiI.get('program'),'vidtype':'tvshow','vtitle':VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,'vsubtitle':VAtFyBPDjrRQsLMofgKeHSJxTOCWid,}
    VAtFyBPDjrRQsLMofgKeHSJxTOCWiq=json.dumps(VAtFyBPDjrRQsLMofgKeHSJxTOCWia)
    VAtFyBPDjrRQsLMofgKeHSJxTOCWiq=urllib.parse.quote(VAtFyBPDjrRQsLMofgKeHSJxTOCWiq)
    VAtFyBPDjrRQsLMofgKeHSJxTOCWiu='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(VAtFyBPDjrRQsLMofgKeHSJxTOCWiq)
    VAtFyBPDjrRQsLMofgKeHSJxTOCWiN=[('(통합) 찜 영상에 추가',VAtFyBPDjrRQsLMofgKeHSJxTOCWiu)]
   else:
    VAtFyBPDjrRQsLMofgKeHSJxTOCWiN=VAtFyBPDjrRQsLMofgKeHSJxTOCWGz
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.add_dir(VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,sublabel=VAtFyBPDjrRQsLMofgKeHSJxTOCWid,img=VAtFyBPDjrRQsLMofgKeHSJxTOCWik,infoLabels=VAtFyBPDjrRQsLMofgKeHSJxTOCWib,isFolder=VAtFyBPDjrRQsLMofgKeHSJxTOCWGm,params=VAtFyBPDjrRQsLMofgKeHSJxTOCWUX,ContextMenu=VAtFyBPDjrRQsLMofgKeHSJxTOCWiN)
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWUl:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX['mode'] ='4K_PROGRAM' 
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX['page'] =VAtFyBPDjrRQsLMofgKeHSJxTOCWGY(VAtFyBPDjrRQsLMofgKeHSJxTOCWUu+1)
   VAtFyBPDjrRQsLMofgKeHSJxTOCWXI='[B]%s >>[/B]'%'다음 페이지'
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiv=VAtFyBPDjrRQsLMofgKeHSJxTOCWGY(VAtFyBPDjrRQsLMofgKeHSJxTOCWUu+1)
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.add_dir(VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,sublabel=VAtFyBPDjrRQsLMofgKeHSJxTOCWiv,img=VAtFyBPDjrRQsLMofgKeHSJxTOCWUk,infoLabels=VAtFyBPDjrRQsLMofgKeHSJxTOCWGz,isFolder=VAtFyBPDjrRQsLMofgKeHSJxTOCWGm,params=VAtFyBPDjrRQsLMofgKeHSJxTOCWUX)
  xbmcplugin.setContent(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_handle,cacheToDisc=VAtFyBPDjrRQsLMofgKeHSJxTOCWGc)
 def dp_Ori_Program_List(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE,VAtFyBPDjrRQsLMofgKeHSJxTOCWUq):
  VAtFyBPDjrRQsLMofgKeHSJxTOCWUu =VAtFyBPDjrRQsLMofgKeHSJxTOCWGw(VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('page'))
  VAtFyBPDjrRQsLMofgKeHSJxTOCWiY,VAtFyBPDjrRQsLMofgKeHSJxTOCWUl=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.Get_Origianl_ProgramList(VAtFyBPDjrRQsLMofgKeHSJxTOCWUu)
  for VAtFyBPDjrRQsLMofgKeHSJxTOCWiI in VAtFyBPDjrRQsLMofgKeHSJxTOCWiY:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWXI =VAtFyBPDjrRQsLMofgKeHSJxTOCWiI.get('title')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWik =VAtFyBPDjrRQsLMofgKeHSJxTOCWiI.get('thumbnail')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWin =VAtFyBPDjrRQsLMofgKeHSJxTOCWiI.get('vod_type')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWzk =VAtFyBPDjrRQsLMofgKeHSJxTOCWiI.get('vod_code')
   if VAtFyBPDjrRQsLMofgKeHSJxTOCWin=='vod':
    VAtFyBPDjrRQsLMofgKeHSJxTOCWib={'mediatype':'tvshow','title':VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,}
    VAtFyBPDjrRQsLMofgKeHSJxTOCWUX={'mode':'EPISODE','programcode':VAtFyBPDjrRQsLMofgKeHSJxTOCWzk,'page':'1',}
    VAtFyBPDjrRQsLMofgKeHSJxTOCWUi=VAtFyBPDjrRQsLMofgKeHSJxTOCWGm
   else:
    VAtFyBPDjrRQsLMofgKeHSJxTOCWib={'mediatype':'movie','title':VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,'plot':'movie',}
    VAtFyBPDjrRQsLMofgKeHSJxTOCWUX={'mode':'MOVIE','mediacode':VAtFyBPDjrRQsLMofgKeHSJxTOCWzk,'stype':'movie','title':VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,'thumbnail':VAtFyBPDjrRQsLMofgKeHSJxTOCWik,}
    VAtFyBPDjrRQsLMofgKeHSJxTOCWUi=VAtFyBPDjrRQsLMofgKeHSJxTOCWGc
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.add_dir(VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,sublabel=VAtFyBPDjrRQsLMofgKeHSJxTOCWGz,img=VAtFyBPDjrRQsLMofgKeHSJxTOCWik,infoLabels=VAtFyBPDjrRQsLMofgKeHSJxTOCWib,isFolder=VAtFyBPDjrRQsLMofgKeHSJxTOCWUi,params=VAtFyBPDjrRQsLMofgKeHSJxTOCWUX,ContextMenu=VAtFyBPDjrRQsLMofgKeHSJxTOCWGz)
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWUl:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX['mode'] ='ORI_PROGRAM' 
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX['page'] =VAtFyBPDjrRQsLMofgKeHSJxTOCWGY(VAtFyBPDjrRQsLMofgKeHSJxTOCWUu+1)
   VAtFyBPDjrRQsLMofgKeHSJxTOCWXI='[B]%s >>[/B]'%'다음 페이지'
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiv=VAtFyBPDjrRQsLMofgKeHSJxTOCWGY(VAtFyBPDjrRQsLMofgKeHSJxTOCWUu+1)
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.add_dir(VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,sublabel=VAtFyBPDjrRQsLMofgKeHSJxTOCWiv,img=VAtFyBPDjrRQsLMofgKeHSJxTOCWUk,infoLabels=VAtFyBPDjrRQsLMofgKeHSJxTOCWGz,isFolder=VAtFyBPDjrRQsLMofgKeHSJxTOCWGm,params=VAtFyBPDjrRQsLMofgKeHSJxTOCWUX)
  xbmcplugin.setContent(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_handle,cacheToDisc=VAtFyBPDjrRQsLMofgKeHSJxTOCWGc)
 def dp_Episode_List(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE,VAtFyBPDjrRQsLMofgKeHSJxTOCWUq):
  VAtFyBPDjrRQsLMofgKeHSJxTOCWzX=VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('programcode')
  VAtFyBPDjrRQsLMofgKeHSJxTOCWUu =VAtFyBPDjrRQsLMofgKeHSJxTOCWGw(VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('page'))
  VAtFyBPDjrRQsLMofgKeHSJxTOCWzU,VAtFyBPDjrRQsLMofgKeHSJxTOCWUl,VAtFyBPDjrRQsLMofgKeHSJxTOCWzi=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.GetEpisodeList(VAtFyBPDjrRQsLMofgKeHSJxTOCWzX,VAtFyBPDjrRQsLMofgKeHSJxTOCWUu,orderby=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.get_winEpisodeOrderby())
  for VAtFyBPDjrRQsLMofgKeHSJxTOCWzw in VAtFyBPDjrRQsLMofgKeHSJxTOCWzU:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWXI =VAtFyBPDjrRQsLMofgKeHSJxTOCWzw.get('title')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiv =VAtFyBPDjrRQsLMofgKeHSJxTOCWzw.get('subtitle')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWik =VAtFyBPDjrRQsLMofgKeHSJxTOCWzw.get('thumbnail')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiX =VAtFyBPDjrRQsLMofgKeHSJxTOCWzw.get('synopsis')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWzm=VAtFyBPDjrRQsLMofgKeHSJxTOCWzw.get('info_title')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWzc =VAtFyBPDjrRQsLMofgKeHSJxTOCWzw.get('aired')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWzG =VAtFyBPDjrRQsLMofgKeHSJxTOCWzw.get('studio')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWzp =VAtFyBPDjrRQsLMofgKeHSJxTOCWzw.get('frequency')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWib={'mediatype':'episode','title':VAtFyBPDjrRQsLMofgKeHSJxTOCWzm,'aired':VAtFyBPDjrRQsLMofgKeHSJxTOCWzc,'studio':VAtFyBPDjrRQsLMofgKeHSJxTOCWzG,'episode':VAtFyBPDjrRQsLMofgKeHSJxTOCWzp,'plot':VAtFyBPDjrRQsLMofgKeHSJxTOCWiX}
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX={'mode':'VOD','mediacode':VAtFyBPDjrRQsLMofgKeHSJxTOCWzw.get('episode'),'stype':'vod','programcode':VAtFyBPDjrRQsLMofgKeHSJxTOCWzX,'title':VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,'thumbnail':VAtFyBPDjrRQsLMofgKeHSJxTOCWik}
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.add_dir(VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,sublabel=VAtFyBPDjrRQsLMofgKeHSJxTOCWiv,img=VAtFyBPDjrRQsLMofgKeHSJxTOCWik,infoLabels=VAtFyBPDjrRQsLMofgKeHSJxTOCWib,isFolder=VAtFyBPDjrRQsLMofgKeHSJxTOCWGc,params=VAtFyBPDjrRQsLMofgKeHSJxTOCWUX)
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWUu==1:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWib={'plot':'정렬순서를 변경합니다.'}
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX={}
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX['mode'] ='ORDER_BY' 
   if VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.get_winEpisodeOrderby()=='desc':
    VAtFyBPDjrRQsLMofgKeHSJxTOCWXI='정렬순서변경 : 최신화부터 -> 1회부터'
    VAtFyBPDjrRQsLMofgKeHSJxTOCWUX['orderby']='asc'
   else:
    VAtFyBPDjrRQsLMofgKeHSJxTOCWXI='정렬순서변경 : 1회부터 -> 최신화부터'
    VAtFyBPDjrRQsLMofgKeHSJxTOCWUX['orderby']='desc'
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.add_dir(VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,sublabel='',img=VAtFyBPDjrRQsLMofgKeHSJxTOCWUk,infoLabels=VAtFyBPDjrRQsLMofgKeHSJxTOCWib,isFolder=VAtFyBPDjrRQsLMofgKeHSJxTOCWGc,params=VAtFyBPDjrRQsLMofgKeHSJxTOCWUX,isLink=VAtFyBPDjrRQsLMofgKeHSJxTOCWGm)
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWUl:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX['mode'] ='EPISODE' 
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX['programcode']=VAtFyBPDjrRQsLMofgKeHSJxTOCWzX
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX['page'] =VAtFyBPDjrRQsLMofgKeHSJxTOCWGY(VAtFyBPDjrRQsLMofgKeHSJxTOCWUu+1)
   VAtFyBPDjrRQsLMofgKeHSJxTOCWXI='[B]%s >>[/B]'%'다음 페이지'
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiv=VAtFyBPDjrRQsLMofgKeHSJxTOCWGY(VAtFyBPDjrRQsLMofgKeHSJxTOCWUu+1)
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.add_dir(VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,sublabel=VAtFyBPDjrRQsLMofgKeHSJxTOCWiv,img=VAtFyBPDjrRQsLMofgKeHSJxTOCWUk,infoLabels=VAtFyBPDjrRQsLMofgKeHSJxTOCWGz,isFolder=VAtFyBPDjrRQsLMofgKeHSJxTOCWGm,params=VAtFyBPDjrRQsLMofgKeHSJxTOCWUX)
  xbmcplugin.setContent(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_handle,'episodes')
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWGh(VAtFyBPDjrRQsLMofgKeHSJxTOCWzU)>0:xbmcplugin.endOfDirectory(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_handle,cacheToDisc=VAtFyBPDjrRQsLMofgKeHSJxTOCWGm)
 def dp_setEpOrderby(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE,VAtFyBPDjrRQsLMofgKeHSJxTOCWUq):
  VAtFyBPDjrRQsLMofgKeHSJxTOCWXh =VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('orderby')
  VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.set_winEpisodeOrderby(VAtFyBPDjrRQsLMofgKeHSJxTOCWXh)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE,VAtFyBPDjrRQsLMofgKeHSJxTOCWUq):
  VAtFyBPDjrRQsLMofgKeHSJxTOCWiE =VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('stype')
  VAtFyBPDjrRQsLMofgKeHSJxTOCWXh =VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('orderby')
  VAtFyBPDjrRQsLMofgKeHSJxTOCWUu=VAtFyBPDjrRQsLMofgKeHSJxTOCWGw(VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('page'))
  VAtFyBPDjrRQsLMofgKeHSJxTOCWzb,VAtFyBPDjrRQsLMofgKeHSJxTOCWUl=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.GetMovieList(VAtFyBPDjrRQsLMofgKeHSJxTOCWiE,VAtFyBPDjrRQsLMofgKeHSJxTOCWXh,VAtFyBPDjrRQsLMofgKeHSJxTOCWUu)
  for VAtFyBPDjrRQsLMofgKeHSJxTOCWzv in VAtFyBPDjrRQsLMofgKeHSJxTOCWzb:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWXI =VAtFyBPDjrRQsLMofgKeHSJxTOCWzv.get('title')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWik =VAtFyBPDjrRQsLMofgKeHSJxTOCWzv.get('thumbnail')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiX =VAtFyBPDjrRQsLMofgKeHSJxTOCWzv.get('synopsis')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWzm =VAtFyBPDjrRQsLMofgKeHSJxTOCWzv.get('info_title')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWic =VAtFyBPDjrRQsLMofgKeHSJxTOCWzv.get('year')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiz =VAtFyBPDjrRQsLMofgKeHSJxTOCWzv.get('cast')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiw =VAtFyBPDjrRQsLMofgKeHSJxTOCWzv.get('director')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWim =VAtFyBPDjrRQsLMofgKeHSJxTOCWzv.get('info_genre')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWzE =VAtFyBPDjrRQsLMofgKeHSJxTOCWzv.get('duration')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWip =VAtFyBPDjrRQsLMofgKeHSJxTOCWzv.get('premiered')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWzG =VAtFyBPDjrRQsLMofgKeHSJxTOCWzv.get('studio')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiG =VAtFyBPDjrRQsLMofgKeHSJxTOCWzv.get('mpaa')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWib={'mediatype':'movie','title':VAtFyBPDjrRQsLMofgKeHSJxTOCWzm,'year':VAtFyBPDjrRQsLMofgKeHSJxTOCWic,'cast':VAtFyBPDjrRQsLMofgKeHSJxTOCWiz,'director':VAtFyBPDjrRQsLMofgKeHSJxTOCWiw,'genre':VAtFyBPDjrRQsLMofgKeHSJxTOCWim,'duration':VAtFyBPDjrRQsLMofgKeHSJxTOCWzE,'premiered':VAtFyBPDjrRQsLMofgKeHSJxTOCWip,'studio':VAtFyBPDjrRQsLMofgKeHSJxTOCWzG,'mpaa':VAtFyBPDjrRQsLMofgKeHSJxTOCWiG,'plot':VAtFyBPDjrRQsLMofgKeHSJxTOCWiX}
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX={'mode':'MOVIE','mediacode':VAtFyBPDjrRQsLMofgKeHSJxTOCWzv.get('moviecode'),'stype':'movie','title':VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,'thumbnail':VAtFyBPDjrRQsLMofgKeHSJxTOCWik}
   if VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.get_settings_makebookmark():
    VAtFyBPDjrRQsLMofgKeHSJxTOCWia={'videoid':VAtFyBPDjrRQsLMofgKeHSJxTOCWzv.get('moviecode'),'vidtype':'movie','vtitle':VAtFyBPDjrRQsLMofgKeHSJxTOCWzm,'vsubtitle':'',}
    VAtFyBPDjrRQsLMofgKeHSJxTOCWiq=json.dumps(VAtFyBPDjrRQsLMofgKeHSJxTOCWia)
    VAtFyBPDjrRQsLMofgKeHSJxTOCWiq=urllib.parse.quote(VAtFyBPDjrRQsLMofgKeHSJxTOCWiq)
    VAtFyBPDjrRQsLMofgKeHSJxTOCWiu='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(VAtFyBPDjrRQsLMofgKeHSJxTOCWiq)
    VAtFyBPDjrRQsLMofgKeHSJxTOCWiN=[('(통합) 찜 영상에 추가',VAtFyBPDjrRQsLMofgKeHSJxTOCWiu)]
   else:
    VAtFyBPDjrRQsLMofgKeHSJxTOCWiN=VAtFyBPDjrRQsLMofgKeHSJxTOCWGz
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.add_dir(VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,sublabel='',img=VAtFyBPDjrRQsLMofgKeHSJxTOCWik,infoLabels=VAtFyBPDjrRQsLMofgKeHSJxTOCWib,isFolder=VAtFyBPDjrRQsLMofgKeHSJxTOCWGc,params=VAtFyBPDjrRQsLMofgKeHSJxTOCWUX,ContextMenu=VAtFyBPDjrRQsLMofgKeHSJxTOCWiN)
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWUl:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX={}
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX['mode'] ='MOVIE_SUB' 
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX['orderby']=VAtFyBPDjrRQsLMofgKeHSJxTOCWXh
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX['stype'] =VAtFyBPDjrRQsLMofgKeHSJxTOCWiE
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX['page'] =VAtFyBPDjrRQsLMofgKeHSJxTOCWGY(VAtFyBPDjrRQsLMofgKeHSJxTOCWUu+1)
   VAtFyBPDjrRQsLMofgKeHSJxTOCWXI='[B]%s >>[/B]'%'다음 페이지'
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiv=VAtFyBPDjrRQsLMofgKeHSJxTOCWGY(VAtFyBPDjrRQsLMofgKeHSJxTOCWUu+1)
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.add_dir(VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,sublabel=VAtFyBPDjrRQsLMofgKeHSJxTOCWiv,img=VAtFyBPDjrRQsLMofgKeHSJxTOCWUk,infoLabels=VAtFyBPDjrRQsLMofgKeHSJxTOCWGz,isFolder=VAtFyBPDjrRQsLMofgKeHSJxTOCWGm,params=VAtFyBPDjrRQsLMofgKeHSJxTOCWUX)
  xbmcplugin.setContent(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_handle,'movies')
  xbmcplugin.endOfDirectory(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_handle,cacheToDisc=VAtFyBPDjrRQsLMofgKeHSJxTOCWGc)
 def dp_4K_Movie_List(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE,VAtFyBPDjrRQsLMofgKeHSJxTOCWUq):
  VAtFyBPDjrRQsLMofgKeHSJxTOCWUu=VAtFyBPDjrRQsLMofgKeHSJxTOCWGw(VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('page'))
  VAtFyBPDjrRQsLMofgKeHSJxTOCWzb,VAtFyBPDjrRQsLMofgKeHSJxTOCWUl=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.Get_UHD_MovieList(VAtFyBPDjrRQsLMofgKeHSJxTOCWUu)
  for VAtFyBPDjrRQsLMofgKeHSJxTOCWzv in VAtFyBPDjrRQsLMofgKeHSJxTOCWzb:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWXI =VAtFyBPDjrRQsLMofgKeHSJxTOCWzv.get('title')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWik =VAtFyBPDjrRQsLMofgKeHSJxTOCWzv.get('thumbnail')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiX =VAtFyBPDjrRQsLMofgKeHSJxTOCWzv.get('synopsis')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWzm =VAtFyBPDjrRQsLMofgKeHSJxTOCWzv.get('info_title')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWic =VAtFyBPDjrRQsLMofgKeHSJxTOCWzv.get('year')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiz =VAtFyBPDjrRQsLMofgKeHSJxTOCWzv.get('cast')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiw =VAtFyBPDjrRQsLMofgKeHSJxTOCWzv.get('director')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWim =VAtFyBPDjrRQsLMofgKeHSJxTOCWzv.get('info_genre')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWzE =VAtFyBPDjrRQsLMofgKeHSJxTOCWzv.get('duration')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWip =VAtFyBPDjrRQsLMofgKeHSJxTOCWzv.get('premiered')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWzG =VAtFyBPDjrRQsLMofgKeHSJxTOCWzv.get('studio')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiG =VAtFyBPDjrRQsLMofgKeHSJxTOCWzv.get('mpaa')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWib={'mediatype':'movie','title':VAtFyBPDjrRQsLMofgKeHSJxTOCWzm,'year':VAtFyBPDjrRQsLMofgKeHSJxTOCWic,'cast':VAtFyBPDjrRQsLMofgKeHSJxTOCWiz,'director':VAtFyBPDjrRQsLMofgKeHSJxTOCWiw,'genre':VAtFyBPDjrRQsLMofgKeHSJxTOCWim,'duration':VAtFyBPDjrRQsLMofgKeHSJxTOCWzE,'premiered':VAtFyBPDjrRQsLMofgKeHSJxTOCWip,'studio':VAtFyBPDjrRQsLMofgKeHSJxTOCWzG,'mpaa':VAtFyBPDjrRQsLMofgKeHSJxTOCWiG,'plot':VAtFyBPDjrRQsLMofgKeHSJxTOCWiX}
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX={'mode':'MOVIE','mediacode':VAtFyBPDjrRQsLMofgKeHSJxTOCWzv.get('moviecode'),'stype':'movie','title':VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,'thumbnail':VAtFyBPDjrRQsLMofgKeHSJxTOCWik}
   if VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.get_settings_makebookmark():
    VAtFyBPDjrRQsLMofgKeHSJxTOCWia={'videoid':VAtFyBPDjrRQsLMofgKeHSJxTOCWzv.get('moviecode'),'vidtype':'movie','vtitle':VAtFyBPDjrRQsLMofgKeHSJxTOCWzm,'vsubtitle':'',}
    VAtFyBPDjrRQsLMofgKeHSJxTOCWiq=json.dumps(VAtFyBPDjrRQsLMofgKeHSJxTOCWia)
    VAtFyBPDjrRQsLMofgKeHSJxTOCWiq=urllib.parse.quote(VAtFyBPDjrRQsLMofgKeHSJxTOCWiq)
    VAtFyBPDjrRQsLMofgKeHSJxTOCWiu='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(VAtFyBPDjrRQsLMofgKeHSJxTOCWiq)
    VAtFyBPDjrRQsLMofgKeHSJxTOCWiN=[('(통합) 찜 영상에 추가',VAtFyBPDjrRQsLMofgKeHSJxTOCWiu)]
   else:
    VAtFyBPDjrRQsLMofgKeHSJxTOCWiN=VAtFyBPDjrRQsLMofgKeHSJxTOCWGz
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.add_dir(VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,sublabel='',img=VAtFyBPDjrRQsLMofgKeHSJxTOCWik,infoLabels=VAtFyBPDjrRQsLMofgKeHSJxTOCWib,isFolder=VAtFyBPDjrRQsLMofgKeHSJxTOCWGc,params=VAtFyBPDjrRQsLMofgKeHSJxTOCWUX,ContextMenu=VAtFyBPDjrRQsLMofgKeHSJxTOCWiN)
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWUl:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX={}
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX['mode'] ='4K_MOVIE' 
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX['page'] =VAtFyBPDjrRQsLMofgKeHSJxTOCWGY(VAtFyBPDjrRQsLMofgKeHSJxTOCWUu+1)
   VAtFyBPDjrRQsLMofgKeHSJxTOCWXI='[B]%s >>[/B]'%'다음 페이지'
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiv=VAtFyBPDjrRQsLMofgKeHSJxTOCWGY(VAtFyBPDjrRQsLMofgKeHSJxTOCWUu+1)
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.add_dir(VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,sublabel=VAtFyBPDjrRQsLMofgKeHSJxTOCWiv,img=VAtFyBPDjrRQsLMofgKeHSJxTOCWUk,infoLabels=VAtFyBPDjrRQsLMofgKeHSJxTOCWGz,isFolder=VAtFyBPDjrRQsLMofgKeHSJxTOCWGm,params=VAtFyBPDjrRQsLMofgKeHSJxTOCWUX)
  xbmcplugin.setContent(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_handle,'movies')
  xbmcplugin.endOfDirectory(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_handle,cacheToDisc=VAtFyBPDjrRQsLMofgKeHSJxTOCWGc)
 def dp_Set_Bookmark(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE,VAtFyBPDjrRQsLMofgKeHSJxTOCWUq):
  VAtFyBPDjrRQsLMofgKeHSJxTOCWzh=urllib.parse.unquote(VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('bm_param'))
  VAtFyBPDjrRQsLMofgKeHSJxTOCWzh=json.loads(VAtFyBPDjrRQsLMofgKeHSJxTOCWzh)
  VAtFyBPDjrRQsLMofgKeHSJxTOCWzY =VAtFyBPDjrRQsLMofgKeHSJxTOCWzh.get('videoid')
  VAtFyBPDjrRQsLMofgKeHSJxTOCWzI =VAtFyBPDjrRQsLMofgKeHSJxTOCWzh.get('vidtype')
  VAtFyBPDjrRQsLMofgKeHSJxTOCWzd =VAtFyBPDjrRQsLMofgKeHSJxTOCWzh.get('vtitle')
  VAtFyBPDjrRQsLMofgKeHSJxTOCWza =VAtFyBPDjrRQsLMofgKeHSJxTOCWzh.get('vsubtitle')
  VAtFyBPDjrRQsLMofgKeHSJxTOCWka=xbmcgui.Dialog()
  VAtFyBPDjrRQsLMofgKeHSJxTOCWUv=VAtFyBPDjrRQsLMofgKeHSJxTOCWka.yesno(__language__(30913).encode('utf8'),VAtFyBPDjrRQsLMofgKeHSJxTOCWzd+' \n\n'+__language__(30914))
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWUv==VAtFyBPDjrRQsLMofgKeHSJxTOCWGc:return
  VAtFyBPDjrRQsLMofgKeHSJxTOCWzq=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.GetBookmarkInfo(VAtFyBPDjrRQsLMofgKeHSJxTOCWzY,VAtFyBPDjrRQsLMofgKeHSJxTOCWzI)
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWza!='':
   VAtFyBPDjrRQsLMofgKeHSJxTOCWzq['saveinfo']['subtitle']=VAtFyBPDjrRQsLMofgKeHSJxTOCWza 
   if VAtFyBPDjrRQsLMofgKeHSJxTOCWzI=='tvshow':VAtFyBPDjrRQsLMofgKeHSJxTOCWzq['saveinfo']['infoLabels']['studio']=VAtFyBPDjrRQsLMofgKeHSJxTOCWza 
  VAtFyBPDjrRQsLMofgKeHSJxTOCWzu=json.dumps(VAtFyBPDjrRQsLMofgKeHSJxTOCWzq)
  VAtFyBPDjrRQsLMofgKeHSJxTOCWzu=urllib.parse.quote(VAtFyBPDjrRQsLMofgKeHSJxTOCWzu)
  VAtFyBPDjrRQsLMofgKeHSJxTOCWiu ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(VAtFyBPDjrRQsLMofgKeHSJxTOCWzu)
  xbmc.executebuiltin(VAtFyBPDjrRQsLMofgKeHSJxTOCWiu)
 def dp_Search_Group(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE,VAtFyBPDjrRQsLMofgKeHSJxTOCWUq):
  if 'search_key' in VAtFyBPDjrRQsLMofgKeHSJxTOCWUq:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWzN=VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('search_key')
  else:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWzN=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not VAtFyBPDjrRQsLMofgKeHSJxTOCWzN:
    return
  for VAtFyBPDjrRQsLMofgKeHSJxTOCWUa in VAtFyBPDjrRQsLMofgKeHSJxTOCWkw:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWzl =VAtFyBPDjrRQsLMofgKeHSJxTOCWUa.get('mode')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUI=VAtFyBPDjrRQsLMofgKeHSJxTOCWUa.get('stype')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWXI=VAtFyBPDjrRQsLMofgKeHSJxTOCWUa.get('title')
   (VAtFyBPDjrRQsLMofgKeHSJxTOCWzn,VAtFyBPDjrRQsLMofgKeHSJxTOCWUl)=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.GetSearchList(VAtFyBPDjrRQsLMofgKeHSJxTOCWzN,1,VAtFyBPDjrRQsLMofgKeHSJxTOCWUI)
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUw={'plot':'검색어 : '+VAtFyBPDjrRQsLMofgKeHSJxTOCWzN+'\n\n'+VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.Search_FreeList(VAtFyBPDjrRQsLMofgKeHSJxTOCWzn)}
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX={'mode':VAtFyBPDjrRQsLMofgKeHSJxTOCWzl,'stype':VAtFyBPDjrRQsLMofgKeHSJxTOCWUI,'search_key':VAtFyBPDjrRQsLMofgKeHSJxTOCWzN,'page':'1',}
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.add_dir(VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,sublabel='',img='',infoLabels=VAtFyBPDjrRQsLMofgKeHSJxTOCWUw,isFolder=VAtFyBPDjrRQsLMofgKeHSJxTOCWGm,params=VAtFyBPDjrRQsLMofgKeHSJxTOCWUX)
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWGh(VAtFyBPDjrRQsLMofgKeHSJxTOCWkw)>0:xbmcplugin.endOfDirectory(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_handle,cacheToDisc=VAtFyBPDjrRQsLMofgKeHSJxTOCWGm)
  VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.Save_Searched_List(VAtFyBPDjrRQsLMofgKeHSJxTOCWzN)
 def Search_FreeList(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE,VAtFyBPDjrRQsLMofgKeHSJxTOCWwp):
  VAtFyBPDjrRQsLMofgKeHSJxTOCWwk=''
  VAtFyBPDjrRQsLMofgKeHSJxTOCWwX=7
  try:
   if VAtFyBPDjrRQsLMofgKeHSJxTOCWGh(VAtFyBPDjrRQsLMofgKeHSJxTOCWwp)==0:return '검색결과 없음'
   for i in VAtFyBPDjrRQsLMofgKeHSJxTOCWGI(VAtFyBPDjrRQsLMofgKeHSJxTOCWGh(VAtFyBPDjrRQsLMofgKeHSJxTOCWwp)):
    if i>=VAtFyBPDjrRQsLMofgKeHSJxTOCWwX:
     VAtFyBPDjrRQsLMofgKeHSJxTOCWwk=VAtFyBPDjrRQsLMofgKeHSJxTOCWwk+'...'
     break
    VAtFyBPDjrRQsLMofgKeHSJxTOCWwk=VAtFyBPDjrRQsLMofgKeHSJxTOCWwk+VAtFyBPDjrRQsLMofgKeHSJxTOCWwp[i]['title']+'\n'
  except:
   return ''
  return VAtFyBPDjrRQsLMofgKeHSJxTOCWwk
 def dp_Search_History(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE,VAtFyBPDjrRQsLMofgKeHSJxTOCWUq):
  VAtFyBPDjrRQsLMofgKeHSJxTOCWwU=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.Load_List_File('search')
  for VAtFyBPDjrRQsLMofgKeHSJxTOCWwi in VAtFyBPDjrRQsLMofgKeHSJxTOCWwU:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWwz=VAtFyBPDjrRQsLMofgKeHSJxTOCWGb(urllib.parse.parse_qsl(VAtFyBPDjrRQsLMofgKeHSJxTOCWwi))
   VAtFyBPDjrRQsLMofgKeHSJxTOCWwm=VAtFyBPDjrRQsLMofgKeHSJxTOCWwz.get('skey').strip()
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX={'mode':'SEARCH_GROUP','search_key':VAtFyBPDjrRQsLMofgKeHSJxTOCWwm,}
   VAtFyBPDjrRQsLMofgKeHSJxTOCWwc={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':VAtFyBPDjrRQsLMofgKeHSJxTOCWwm,'vType':'-',}
   VAtFyBPDjrRQsLMofgKeHSJxTOCWwG=urllib.parse.urlencode(VAtFyBPDjrRQsLMofgKeHSJxTOCWwc)
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiN=[('선택된 검색어 ( %s ) 삭제'%(VAtFyBPDjrRQsLMofgKeHSJxTOCWwm),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(VAtFyBPDjrRQsLMofgKeHSJxTOCWwG))]
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.add_dir(VAtFyBPDjrRQsLMofgKeHSJxTOCWwm,sublabel='',img=VAtFyBPDjrRQsLMofgKeHSJxTOCWGz,infoLabels=VAtFyBPDjrRQsLMofgKeHSJxTOCWGz,isFolder=VAtFyBPDjrRQsLMofgKeHSJxTOCWGm,params=VAtFyBPDjrRQsLMofgKeHSJxTOCWUX,ContextMenu=VAtFyBPDjrRQsLMofgKeHSJxTOCWiN)
  VAtFyBPDjrRQsLMofgKeHSJxTOCWib={'plot':'검색목록 전체를 삭제합니다.'}
  VAtFyBPDjrRQsLMofgKeHSJxTOCWXI='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  VAtFyBPDjrRQsLMofgKeHSJxTOCWUX={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  VAtFyBPDjrRQsLMofgKeHSJxTOCWUk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.add_dir(VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,sublabel='',img=VAtFyBPDjrRQsLMofgKeHSJxTOCWUk,infoLabels=VAtFyBPDjrRQsLMofgKeHSJxTOCWib,isFolder=VAtFyBPDjrRQsLMofgKeHSJxTOCWGc,params=VAtFyBPDjrRQsLMofgKeHSJxTOCWUX,isLink=VAtFyBPDjrRQsLMofgKeHSJxTOCWGm)
  xbmcplugin.endOfDirectory(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_handle,cacheToDisc=VAtFyBPDjrRQsLMofgKeHSJxTOCWGc)
 def dp_Search_List(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE,VAtFyBPDjrRQsLMofgKeHSJxTOCWUq):
  VAtFyBPDjrRQsLMofgKeHSJxTOCWUu =VAtFyBPDjrRQsLMofgKeHSJxTOCWGw(VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('page'))
  VAtFyBPDjrRQsLMofgKeHSJxTOCWUI =VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('stype')
  if 'search_key' in VAtFyBPDjrRQsLMofgKeHSJxTOCWUq:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWzN=VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('search_key')
  else:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWzN=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not VAtFyBPDjrRQsLMofgKeHSJxTOCWzN:
    xbmcplugin.endOfDirectory(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_handle)
    return
  VAtFyBPDjrRQsLMofgKeHSJxTOCWzn,VAtFyBPDjrRQsLMofgKeHSJxTOCWUl=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.GetSearchList(VAtFyBPDjrRQsLMofgKeHSJxTOCWzN,VAtFyBPDjrRQsLMofgKeHSJxTOCWUu,VAtFyBPDjrRQsLMofgKeHSJxTOCWUI)
  for VAtFyBPDjrRQsLMofgKeHSJxTOCWwp in VAtFyBPDjrRQsLMofgKeHSJxTOCWzn:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWXI =VAtFyBPDjrRQsLMofgKeHSJxTOCWwp.get('title')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWik =VAtFyBPDjrRQsLMofgKeHSJxTOCWwp.get('thumbnail')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiX =VAtFyBPDjrRQsLMofgKeHSJxTOCWwp.get('synopsis')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWwb =VAtFyBPDjrRQsLMofgKeHSJxTOCWwp.get('program')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiz =VAtFyBPDjrRQsLMofgKeHSJxTOCWwp.get('cast')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiw =VAtFyBPDjrRQsLMofgKeHSJxTOCWwp.get('director')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWim=VAtFyBPDjrRQsLMofgKeHSJxTOCWwp.get('info_genre')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWzE =VAtFyBPDjrRQsLMofgKeHSJxTOCWwp.get('duration')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiG =VAtFyBPDjrRQsLMofgKeHSJxTOCWwp.get('mpaa')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWic =VAtFyBPDjrRQsLMofgKeHSJxTOCWwp.get('year')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWzc =VAtFyBPDjrRQsLMofgKeHSJxTOCWwp.get('aired')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWib={'mediatype':'tvshow' if VAtFyBPDjrRQsLMofgKeHSJxTOCWUI=='vod' else 'movie','title':VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,'cast':VAtFyBPDjrRQsLMofgKeHSJxTOCWiz,'director':VAtFyBPDjrRQsLMofgKeHSJxTOCWiw,'genre':VAtFyBPDjrRQsLMofgKeHSJxTOCWim,'duration':VAtFyBPDjrRQsLMofgKeHSJxTOCWzE,'mpaa':VAtFyBPDjrRQsLMofgKeHSJxTOCWiG,'year':VAtFyBPDjrRQsLMofgKeHSJxTOCWic,'aired':VAtFyBPDjrRQsLMofgKeHSJxTOCWzc,'plot':'%s\n\n%s'%(VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,VAtFyBPDjrRQsLMofgKeHSJxTOCWiX)}
   if VAtFyBPDjrRQsLMofgKeHSJxTOCWUI=='vod':
    VAtFyBPDjrRQsLMofgKeHSJxTOCWzY=VAtFyBPDjrRQsLMofgKeHSJxTOCWwp.get('program')
    VAtFyBPDjrRQsLMofgKeHSJxTOCWzI='tvshow'
    VAtFyBPDjrRQsLMofgKeHSJxTOCWUX={'mode':'EPISODE','programcode':VAtFyBPDjrRQsLMofgKeHSJxTOCWzY,'page':'1',}
    VAtFyBPDjrRQsLMofgKeHSJxTOCWUi=VAtFyBPDjrRQsLMofgKeHSJxTOCWGm
   else:
    VAtFyBPDjrRQsLMofgKeHSJxTOCWzY=VAtFyBPDjrRQsLMofgKeHSJxTOCWwp.get('movie')
    VAtFyBPDjrRQsLMofgKeHSJxTOCWzI='movie'
    VAtFyBPDjrRQsLMofgKeHSJxTOCWUX={'mode':'MOVIE','mediacode':VAtFyBPDjrRQsLMofgKeHSJxTOCWzY,'stype':'movie','title':VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,'thumbnail':VAtFyBPDjrRQsLMofgKeHSJxTOCWik,}
    VAtFyBPDjrRQsLMofgKeHSJxTOCWUi=VAtFyBPDjrRQsLMofgKeHSJxTOCWGc
   if VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.get_settings_makebookmark():
    VAtFyBPDjrRQsLMofgKeHSJxTOCWia={'videoid':VAtFyBPDjrRQsLMofgKeHSJxTOCWzY,'vidtype':VAtFyBPDjrRQsLMofgKeHSJxTOCWzI,'vtitle':VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,'vsubtitle':'',}
    VAtFyBPDjrRQsLMofgKeHSJxTOCWiq=json.dumps(VAtFyBPDjrRQsLMofgKeHSJxTOCWia)
    VAtFyBPDjrRQsLMofgKeHSJxTOCWiq=urllib.parse.quote(VAtFyBPDjrRQsLMofgKeHSJxTOCWiq)
    VAtFyBPDjrRQsLMofgKeHSJxTOCWiu='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(VAtFyBPDjrRQsLMofgKeHSJxTOCWiq)
    VAtFyBPDjrRQsLMofgKeHSJxTOCWiN=[('(통합) 찜 영상에 추가',VAtFyBPDjrRQsLMofgKeHSJxTOCWiu)]
   else:
    VAtFyBPDjrRQsLMofgKeHSJxTOCWiN=VAtFyBPDjrRQsLMofgKeHSJxTOCWGz
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.add_dir(VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,sublabel='',img=VAtFyBPDjrRQsLMofgKeHSJxTOCWik,infoLabels=VAtFyBPDjrRQsLMofgKeHSJxTOCWib,isFolder=VAtFyBPDjrRQsLMofgKeHSJxTOCWUi,params=VAtFyBPDjrRQsLMofgKeHSJxTOCWUX,isLink=VAtFyBPDjrRQsLMofgKeHSJxTOCWGc,ContextMenu=VAtFyBPDjrRQsLMofgKeHSJxTOCWiN)
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWUl:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX['mode'] ='SEARCH' 
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX['search_key']=VAtFyBPDjrRQsLMofgKeHSJxTOCWzN
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX['page'] =VAtFyBPDjrRQsLMofgKeHSJxTOCWGY(VAtFyBPDjrRQsLMofgKeHSJxTOCWUu+1)
   VAtFyBPDjrRQsLMofgKeHSJxTOCWXI='[B]%s >>[/B]'%'다음 페이지'
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiv=VAtFyBPDjrRQsLMofgKeHSJxTOCWGY(VAtFyBPDjrRQsLMofgKeHSJxTOCWUu+1)
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.add_dir(VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,sublabel=VAtFyBPDjrRQsLMofgKeHSJxTOCWiv,img=VAtFyBPDjrRQsLMofgKeHSJxTOCWUk,infoLabels=VAtFyBPDjrRQsLMofgKeHSJxTOCWGz,isFolder=VAtFyBPDjrRQsLMofgKeHSJxTOCWGm,params=VAtFyBPDjrRQsLMofgKeHSJxTOCWUX)
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWUI=='movie':xbmcplugin.setContent(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_handle,'movies')
  else:xbmcplugin.setContent(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_handle,cacheToDisc=VAtFyBPDjrRQsLMofgKeHSJxTOCWGc)
 def dp_History_Remove(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE,VAtFyBPDjrRQsLMofgKeHSJxTOCWUq):
  VAtFyBPDjrRQsLMofgKeHSJxTOCWwv=VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('delType')
  VAtFyBPDjrRQsLMofgKeHSJxTOCWwE =VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('sKey')
  VAtFyBPDjrRQsLMofgKeHSJxTOCWwh =VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('vType')
  VAtFyBPDjrRQsLMofgKeHSJxTOCWka=xbmcgui.Dialog()
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWwv=='SEARCH_ALL':
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUv=VAtFyBPDjrRQsLMofgKeHSJxTOCWka.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif VAtFyBPDjrRQsLMofgKeHSJxTOCWwv=='SEARCH_ONE':
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUv=VAtFyBPDjrRQsLMofgKeHSJxTOCWka.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif VAtFyBPDjrRQsLMofgKeHSJxTOCWwv=='WATCH_ALL':
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUv=VAtFyBPDjrRQsLMofgKeHSJxTOCWka.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif VAtFyBPDjrRQsLMofgKeHSJxTOCWwv=='WATCH_ONE':
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUv=VAtFyBPDjrRQsLMofgKeHSJxTOCWka.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWUv==VAtFyBPDjrRQsLMofgKeHSJxTOCWGc:sys.exit()
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWwv=='SEARCH_ALL':
   if os.path.isfile(VAtFyBPDjrRQsLMofgKeHSJxTOCWkv):os.remove(VAtFyBPDjrRQsLMofgKeHSJxTOCWkv)
  elif VAtFyBPDjrRQsLMofgKeHSJxTOCWwv=='SEARCH_ONE':
   try:
    VAtFyBPDjrRQsLMofgKeHSJxTOCWwY=VAtFyBPDjrRQsLMofgKeHSJxTOCWkv
    VAtFyBPDjrRQsLMofgKeHSJxTOCWwI=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.Load_List_File('search') 
    fp=VAtFyBPDjrRQsLMofgKeHSJxTOCWGd(VAtFyBPDjrRQsLMofgKeHSJxTOCWwY,'w',-1,'utf-8')
    for VAtFyBPDjrRQsLMofgKeHSJxTOCWwd in VAtFyBPDjrRQsLMofgKeHSJxTOCWwI:
     VAtFyBPDjrRQsLMofgKeHSJxTOCWwa=VAtFyBPDjrRQsLMofgKeHSJxTOCWGb(urllib.parse.parse_qsl(VAtFyBPDjrRQsLMofgKeHSJxTOCWwd))
     VAtFyBPDjrRQsLMofgKeHSJxTOCWwq=VAtFyBPDjrRQsLMofgKeHSJxTOCWwa.get('skey').strip()
     if VAtFyBPDjrRQsLMofgKeHSJxTOCWwE!=VAtFyBPDjrRQsLMofgKeHSJxTOCWwq:
      fp.write(VAtFyBPDjrRQsLMofgKeHSJxTOCWwd)
    fp.close()
   except:
    VAtFyBPDjrRQsLMofgKeHSJxTOCWGz
  elif VAtFyBPDjrRQsLMofgKeHSJxTOCWwv=='WATCH_ALL':
   VAtFyBPDjrRQsLMofgKeHSJxTOCWwY=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%VAtFyBPDjrRQsLMofgKeHSJxTOCWwh))
   if os.path.isfile(VAtFyBPDjrRQsLMofgKeHSJxTOCWwY):os.remove(VAtFyBPDjrRQsLMofgKeHSJxTOCWwY)
  elif VAtFyBPDjrRQsLMofgKeHSJxTOCWwv=='WATCH_ONE':
   VAtFyBPDjrRQsLMofgKeHSJxTOCWwY=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%VAtFyBPDjrRQsLMofgKeHSJxTOCWwh))
   try:
    VAtFyBPDjrRQsLMofgKeHSJxTOCWwI=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.Load_List_File(VAtFyBPDjrRQsLMofgKeHSJxTOCWwh) 
    fp=VAtFyBPDjrRQsLMofgKeHSJxTOCWGd(VAtFyBPDjrRQsLMofgKeHSJxTOCWwY,'w',-1,'utf-8')
    for VAtFyBPDjrRQsLMofgKeHSJxTOCWwd in VAtFyBPDjrRQsLMofgKeHSJxTOCWwI:
     VAtFyBPDjrRQsLMofgKeHSJxTOCWwa=VAtFyBPDjrRQsLMofgKeHSJxTOCWGb(urllib.parse.parse_qsl(VAtFyBPDjrRQsLMofgKeHSJxTOCWwd))
     VAtFyBPDjrRQsLMofgKeHSJxTOCWwq=VAtFyBPDjrRQsLMofgKeHSJxTOCWwa.get('code').strip()
     if VAtFyBPDjrRQsLMofgKeHSJxTOCWwE!=VAtFyBPDjrRQsLMofgKeHSJxTOCWwq:
      fp.write(VAtFyBPDjrRQsLMofgKeHSJxTOCWwd)
    fp.close()
   except:
    VAtFyBPDjrRQsLMofgKeHSJxTOCWGz
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE,VAtFyBPDjrRQsLMofgKeHSJxTOCWUI): 
  try:
   if VAtFyBPDjrRQsLMofgKeHSJxTOCWUI=='search':
    VAtFyBPDjrRQsLMofgKeHSJxTOCWwY=VAtFyBPDjrRQsLMofgKeHSJxTOCWkv
   elif VAtFyBPDjrRQsLMofgKeHSJxTOCWUI in['vod','movie']:
    VAtFyBPDjrRQsLMofgKeHSJxTOCWwY=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%VAtFyBPDjrRQsLMofgKeHSJxTOCWUI))
   else:
    return[]
   fp=VAtFyBPDjrRQsLMofgKeHSJxTOCWGd(VAtFyBPDjrRQsLMofgKeHSJxTOCWwY,'r',-1,'utf-8')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWwu=fp.readlines()
   fp.close()
  except:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWwu=[]
  return VAtFyBPDjrRQsLMofgKeHSJxTOCWwu
 def Save_Watched_List(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE,VAtFyBPDjrRQsLMofgKeHSJxTOCWUI,VAtFyBPDjrRQsLMofgKeHSJxTOCWkI):
  try:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWwN=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%VAtFyBPDjrRQsLMofgKeHSJxTOCWUI))
   VAtFyBPDjrRQsLMofgKeHSJxTOCWwI=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.Load_List_File(VAtFyBPDjrRQsLMofgKeHSJxTOCWUI) 
   fp=VAtFyBPDjrRQsLMofgKeHSJxTOCWGd(VAtFyBPDjrRQsLMofgKeHSJxTOCWwN,'w',-1,'utf-8')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWwl=urllib.parse.urlencode(VAtFyBPDjrRQsLMofgKeHSJxTOCWkI)
   VAtFyBPDjrRQsLMofgKeHSJxTOCWwl=VAtFyBPDjrRQsLMofgKeHSJxTOCWwl+'\n'
   fp.write(VAtFyBPDjrRQsLMofgKeHSJxTOCWwl)
   VAtFyBPDjrRQsLMofgKeHSJxTOCWwn=0
   for VAtFyBPDjrRQsLMofgKeHSJxTOCWwd in VAtFyBPDjrRQsLMofgKeHSJxTOCWwI:
    VAtFyBPDjrRQsLMofgKeHSJxTOCWwa=VAtFyBPDjrRQsLMofgKeHSJxTOCWGb(urllib.parse.parse_qsl(VAtFyBPDjrRQsLMofgKeHSJxTOCWwd))
    VAtFyBPDjrRQsLMofgKeHSJxTOCWmk=VAtFyBPDjrRQsLMofgKeHSJxTOCWkI.get('code').strip()
    VAtFyBPDjrRQsLMofgKeHSJxTOCWmX=VAtFyBPDjrRQsLMofgKeHSJxTOCWwa.get('code').strip()
    if VAtFyBPDjrRQsLMofgKeHSJxTOCWUI=='vod' and VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.get_settings_direct_replay()==VAtFyBPDjrRQsLMofgKeHSJxTOCWGm:
     VAtFyBPDjrRQsLMofgKeHSJxTOCWmk=VAtFyBPDjrRQsLMofgKeHSJxTOCWkI.get('videoid').strip()
     VAtFyBPDjrRQsLMofgKeHSJxTOCWmX=VAtFyBPDjrRQsLMofgKeHSJxTOCWwa.get('videoid').strip()if VAtFyBPDjrRQsLMofgKeHSJxTOCWmX!=VAtFyBPDjrRQsLMofgKeHSJxTOCWGz else '-'
    if VAtFyBPDjrRQsLMofgKeHSJxTOCWmk!=VAtFyBPDjrRQsLMofgKeHSJxTOCWmX:
     fp.write(VAtFyBPDjrRQsLMofgKeHSJxTOCWwd)
     VAtFyBPDjrRQsLMofgKeHSJxTOCWwn+=1
     if VAtFyBPDjrRQsLMofgKeHSJxTOCWwn>=50:break
   fp.close()
  except:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWGz
 def dp_Watch_List(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE,VAtFyBPDjrRQsLMofgKeHSJxTOCWUq):
  VAtFyBPDjrRQsLMofgKeHSJxTOCWUI =VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('stype')
  VAtFyBPDjrRQsLMofgKeHSJxTOCWXv=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.get_settings_direct_replay()
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWUI=='-':
   for VAtFyBPDjrRQsLMofgKeHSJxTOCWUa in VAtFyBPDjrRQsLMofgKeHSJxTOCWkz:
    VAtFyBPDjrRQsLMofgKeHSJxTOCWXI=VAtFyBPDjrRQsLMofgKeHSJxTOCWUa.get('title')
    VAtFyBPDjrRQsLMofgKeHSJxTOCWUX={'mode':VAtFyBPDjrRQsLMofgKeHSJxTOCWUa.get('mode'),'stype':VAtFyBPDjrRQsLMofgKeHSJxTOCWUa.get('stype')}
    VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.add_dir(VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,sublabel='',img='',infoLabels=VAtFyBPDjrRQsLMofgKeHSJxTOCWGz,isFolder=VAtFyBPDjrRQsLMofgKeHSJxTOCWGm,params=VAtFyBPDjrRQsLMofgKeHSJxTOCWUX)
   if VAtFyBPDjrRQsLMofgKeHSJxTOCWGh(VAtFyBPDjrRQsLMofgKeHSJxTOCWkz)>0:xbmcplugin.endOfDirectory(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_handle)
  else:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWmU=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.Load_List_File(VAtFyBPDjrRQsLMofgKeHSJxTOCWUI)
   for VAtFyBPDjrRQsLMofgKeHSJxTOCWmi in VAtFyBPDjrRQsLMofgKeHSJxTOCWmU:
    VAtFyBPDjrRQsLMofgKeHSJxTOCWwz=VAtFyBPDjrRQsLMofgKeHSJxTOCWGb(urllib.parse.parse_qsl(VAtFyBPDjrRQsLMofgKeHSJxTOCWmi))
    VAtFyBPDjrRQsLMofgKeHSJxTOCWmz =VAtFyBPDjrRQsLMofgKeHSJxTOCWwz.get('code').strip()
    VAtFyBPDjrRQsLMofgKeHSJxTOCWXI =VAtFyBPDjrRQsLMofgKeHSJxTOCWwz.get('title').strip()
    VAtFyBPDjrRQsLMofgKeHSJxTOCWik=VAtFyBPDjrRQsLMofgKeHSJxTOCWwz.get('img').strip()
    VAtFyBPDjrRQsLMofgKeHSJxTOCWzY =VAtFyBPDjrRQsLMofgKeHSJxTOCWwz.get('videoid').strip()
    try:
     VAtFyBPDjrRQsLMofgKeHSJxTOCWik=VAtFyBPDjrRQsLMofgKeHSJxTOCWik.replace('\'','\"')
     VAtFyBPDjrRQsLMofgKeHSJxTOCWik=json.loads(VAtFyBPDjrRQsLMofgKeHSJxTOCWik)
    except:
     VAtFyBPDjrRQsLMofgKeHSJxTOCWGz
    VAtFyBPDjrRQsLMofgKeHSJxTOCWib={}
    VAtFyBPDjrRQsLMofgKeHSJxTOCWib['plot']=VAtFyBPDjrRQsLMofgKeHSJxTOCWXI
    if VAtFyBPDjrRQsLMofgKeHSJxTOCWUI=='vod':
     if VAtFyBPDjrRQsLMofgKeHSJxTOCWXv==VAtFyBPDjrRQsLMofgKeHSJxTOCWGc or VAtFyBPDjrRQsLMofgKeHSJxTOCWzY==VAtFyBPDjrRQsLMofgKeHSJxTOCWGz:
      VAtFyBPDjrRQsLMofgKeHSJxTOCWib['mediatype']='tvshow'
      VAtFyBPDjrRQsLMofgKeHSJxTOCWUX={'mode':'EPISODE','programcode':VAtFyBPDjrRQsLMofgKeHSJxTOCWmz,'page':'1'}
      VAtFyBPDjrRQsLMofgKeHSJxTOCWUi=VAtFyBPDjrRQsLMofgKeHSJxTOCWGm
     else:
      VAtFyBPDjrRQsLMofgKeHSJxTOCWib['mediatype']='episode'
      VAtFyBPDjrRQsLMofgKeHSJxTOCWUX={'mode':'VOD','mediacode':VAtFyBPDjrRQsLMofgKeHSJxTOCWzY,'stype':'vod','programcode':VAtFyBPDjrRQsLMofgKeHSJxTOCWmz,'title':VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,'thumbnail':VAtFyBPDjrRQsLMofgKeHSJxTOCWik}
      VAtFyBPDjrRQsLMofgKeHSJxTOCWUi=VAtFyBPDjrRQsLMofgKeHSJxTOCWGc
    else:
     VAtFyBPDjrRQsLMofgKeHSJxTOCWib['mediatype']='movie'
     VAtFyBPDjrRQsLMofgKeHSJxTOCWUX={'mode':'MOVIE','mediacode':VAtFyBPDjrRQsLMofgKeHSJxTOCWmz,'stype':'movie','title':VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,'thumbnail':VAtFyBPDjrRQsLMofgKeHSJxTOCWik}
     VAtFyBPDjrRQsLMofgKeHSJxTOCWUi=VAtFyBPDjrRQsLMofgKeHSJxTOCWGc
    VAtFyBPDjrRQsLMofgKeHSJxTOCWwc={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':VAtFyBPDjrRQsLMofgKeHSJxTOCWmz,'vType':VAtFyBPDjrRQsLMofgKeHSJxTOCWUI,}
    VAtFyBPDjrRQsLMofgKeHSJxTOCWwG=urllib.parse.urlencode(VAtFyBPDjrRQsLMofgKeHSJxTOCWwc)
    VAtFyBPDjrRQsLMofgKeHSJxTOCWiN=[('선택된 시청이력 ( %s ) 삭제'%(VAtFyBPDjrRQsLMofgKeHSJxTOCWXI),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(VAtFyBPDjrRQsLMofgKeHSJxTOCWwG))]
    VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.add_dir(VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,sublabel='',img=VAtFyBPDjrRQsLMofgKeHSJxTOCWik,infoLabels=VAtFyBPDjrRQsLMofgKeHSJxTOCWib,isFolder=VAtFyBPDjrRQsLMofgKeHSJxTOCWUi,params=VAtFyBPDjrRQsLMofgKeHSJxTOCWUX,ContextMenu=VAtFyBPDjrRQsLMofgKeHSJxTOCWiN)
   VAtFyBPDjrRQsLMofgKeHSJxTOCWib={'plot':'시청목록을 삭제합니다.'}
   VAtFyBPDjrRQsLMofgKeHSJxTOCWXI='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':VAtFyBPDjrRQsLMofgKeHSJxTOCWUI,}
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.add_dir(VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,sublabel='',img=VAtFyBPDjrRQsLMofgKeHSJxTOCWUk,infoLabels=VAtFyBPDjrRQsLMofgKeHSJxTOCWib,isFolder=VAtFyBPDjrRQsLMofgKeHSJxTOCWGc,params=VAtFyBPDjrRQsLMofgKeHSJxTOCWUX,isLink=VAtFyBPDjrRQsLMofgKeHSJxTOCWGm)
   if VAtFyBPDjrRQsLMofgKeHSJxTOCWUI=='movie':xbmcplugin.setContent(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_handle,'movies')
   else:xbmcplugin.setContent(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_handle,cacheToDisc=VAtFyBPDjrRQsLMofgKeHSJxTOCWGc)
 def Save_Searched_List(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE,VAtFyBPDjrRQsLMofgKeHSJxTOCWzN):
  try:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWmw=VAtFyBPDjrRQsLMofgKeHSJxTOCWkv
   VAtFyBPDjrRQsLMofgKeHSJxTOCWwI=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.Load_List_File('search') 
   VAtFyBPDjrRQsLMofgKeHSJxTOCWmc={'skey':VAtFyBPDjrRQsLMofgKeHSJxTOCWzN.strip()}
   fp=VAtFyBPDjrRQsLMofgKeHSJxTOCWGd(VAtFyBPDjrRQsLMofgKeHSJxTOCWmw,'w',-1,'utf-8')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWwl=urllib.parse.urlencode(VAtFyBPDjrRQsLMofgKeHSJxTOCWmc)
   VAtFyBPDjrRQsLMofgKeHSJxTOCWwl=VAtFyBPDjrRQsLMofgKeHSJxTOCWwl+'\n'
   fp.write(VAtFyBPDjrRQsLMofgKeHSJxTOCWwl)
   VAtFyBPDjrRQsLMofgKeHSJxTOCWwn=0
   for VAtFyBPDjrRQsLMofgKeHSJxTOCWwd in VAtFyBPDjrRQsLMofgKeHSJxTOCWwI:
    VAtFyBPDjrRQsLMofgKeHSJxTOCWwa=VAtFyBPDjrRQsLMofgKeHSJxTOCWGb(urllib.parse.parse_qsl(VAtFyBPDjrRQsLMofgKeHSJxTOCWwd))
    VAtFyBPDjrRQsLMofgKeHSJxTOCWmk=VAtFyBPDjrRQsLMofgKeHSJxTOCWmc.get('skey').strip()
    VAtFyBPDjrRQsLMofgKeHSJxTOCWmX=VAtFyBPDjrRQsLMofgKeHSJxTOCWwa.get('skey').strip()
    if VAtFyBPDjrRQsLMofgKeHSJxTOCWmk!=VAtFyBPDjrRQsLMofgKeHSJxTOCWmX:
     fp.write(VAtFyBPDjrRQsLMofgKeHSJxTOCWwd)
     VAtFyBPDjrRQsLMofgKeHSJxTOCWwn+=1
     if VAtFyBPDjrRQsLMofgKeHSJxTOCWwn>=50:break
   fp.close()
  except:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWGz
 def play_VIDEO(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE,VAtFyBPDjrRQsLMofgKeHSJxTOCWUq):
  VAtFyBPDjrRQsLMofgKeHSJxTOCWmG =VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('mediacode')
  VAtFyBPDjrRQsLMofgKeHSJxTOCWUI =VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('stype')
  VAtFyBPDjrRQsLMofgKeHSJxTOCWmp =VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('pvrmode')
  VAtFyBPDjrRQsLMofgKeHSJxTOCWmb=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.get_selQuality(VAtFyBPDjrRQsLMofgKeHSJxTOCWUI)
  VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(VAtFyBPDjrRQsLMofgKeHSJxTOCWmG,VAtFyBPDjrRQsLMofgKeHSJxTOCWGY(VAtFyBPDjrRQsLMofgKeHSJxTOCWmb),VAtFyBPDjrRQsLMofgKeHSJxTOCWUI,VAtFyBPDjrRQsLMofgKeHSJxTOCWmp))
  VAtFyBPDjrRQsLMofgKeHSJxTOCWmv=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.GetBroadURL(VAtFyBPDjrRQsLMofgKeHSJxTOCWmG,VAtFyBPDjrRQsLMofgKeHSJxTOCWmb,VAtFyBPDjrRQsLMofgKeHSJxTOCWUI,VAtFyBPDjrRQsLMofgKeHSJxTOCWmp,optUHD=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.get_settings_uhd())
  VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.addon_log('qt, stype, url : %s - %s - %s'%(VAtFyBPDjrRQsLMofgKeHSJxTOCWGY(VAtFyBPDjrRQsLMofgKeHSJxTOCWmb),VAtFyBPDjrRQsLMofgKeHSJxTOCWUI,VAtFyBPDjrRQsLMofgKeHSJxTOCWmv['streaming_url']))
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWmv['streaming_url']=='':
   if VAtFyBPDjrRQsLMofgKeHSJxTOCWmv['error_msg']=='':
    VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.addon_noti(__language__(30908).encode('utf8'))
   else:
    VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.addon_noti(VAtFyBPDjrRQsLMofgKeHSJxTOCWmv['error_msg'].encode('utf8'))
   return
  VAtFyBPDjrRQsLMofgKeHSJxTOCWmE={'user-agent':VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.USER_AGENT}
  VAtFyBPDjrRQsLMofgKeHSJxTOCWmh=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.makeDefaultCookies() 
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWmv['watermark'] !='':
   VAtFyBPDjrRQsLMofgKeHSJxTOCWmE['x-tving-param1']=VAtFyBPDjrRQsLMofgKeHSJxTOCWmv['watermarkKey']
   VAtFyBPDjrRQsLMofgKeHSJxTOCWmE['x-tving-param2']=VAtFyBPDjrRQsLMofgKeHSJxTOCWmv['watermark'] 
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWmv['drm_server_url'] !='':
   VAtFyBPDjrRQsLMofgKeHSJxTOCWmE[VAtFyBPDjrRQsLMofgKeHSJxTOCWmv['drm_header_key']]=VAtFyBPDjrRQsLMofgKeHSJxTOCWmv['drm_header_value']
  VAtFyBPDjrRQsLMofgKeHSJxTOCWmY =VAtFyBPDjrRQsLMofgKeHSJxTOCWGc
  VAtFyBPDjrRQsLMofgKeHSJxTOCWmI =VAtFyBPDjrRQsLMofgKeHSJxTOCWmv['streaming_url'].find('Policy=')
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWmI!=-1:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWmd =VAtFyBPDjrRQsLMofgKeHSJxTOCWmv['streaming_url'].split('?')[0]
   VAtFyBPDjrRQsLMofgKeHSJxTOCWma=VAtFyBPDjrRQsLMofgKeHSJxTOCWGb(urllib.parse.parse_qsl(urllib.parse.urlsplit(VAtFyBPDjrRQsLMofgKeHSJxTOCWmv['streaming_url']).query))
   VAtFyBPDjrRQsLMofgKeHSJxTOCWmh['CloudFront-Policy'] =VAtFyBPDjrRQsLMofgKeHSJxTOCWma['Policy'] 
   VAtFyBPDjrRQsLMofgKeHSJxTOCWmh['CloudFront-Signature'] =VAtFyBPDjrRQsLMofgKeHSJxTOCWma['Signature'] 
   VAtFyBPDjrRQsLMofgKeHSJxTOCWmh['CloudFront-Key-Pair-Id']=VAtFyBPDjrRQsLMofgKeHSJxTOCWma['Key-Pair-Id'] 
   VAtFyBPDjrRQsLMofgKeHSJxTOCWmq=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.make_stream_header(VAtFyBPDjrRQsLMofgKeHSJxTOCWmE,VAtFyBPDjrRQsLMofgKeHSJxTOCWmh)
   if 'quickvod-mcdn.tving.com' in VAtFyBPDjrRQsLMofgKeHSJxTOCWmd:
    VAtFyBPDjrRQsLMofgKeHSJxTOCWmY=VAtFyBPDjrRQsLMofgKeHSJxTOCWGm
    VAtFyBPDjrRQsLMofgKeHSJxTOCWmu =VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    VAtFyBPDjrRQsLMofgKeHSJxTOCWmN=VAtFyBPDjrRQsLMofgKeHSJxTOCWmu.strftime('%Y-%m-%d-%H:%M:%S')
    if VAtFyBPDjrRQsLMofgKeHSJxTOCWGw(VAtFyBPDjrRQsLMofgKeHSJxTOCWmN.replace('-','').replace(':',''))<VAtFyBPDjrRQsLMofgKeHSJxTOCWGw(VAtFyBPDjrRQsLMofgKeHSJxTOCWma['end'].replace('-','').replace(':','')):
     VAtFyBPDjrRQsLMofgKeHSJxTOCWma['end']=VAtFyBPDjrRQsLMofgKeHSJxTOCWmN
     VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.addon_noti(__language__(30915).encode('utf8'))
    VAtFyBPDjrRQsLMofgKeHSJxTOCWmd ='%s?%s'%(VAtFyBPDjrRQsLMofgKeHSJxTOCWmd,urllib.parse.urlencode(VAtFyBPDjrRQsLMofgKeHSJxTOCWma,doseq=VAtFyBPDjrRQsLMofgKeHSJxTOCWGm))
    VAtFyBPDjrRQsLMofgKeHSJxTOCWml='{}|{}'.format(VAtFyBPDjrRQsLMofgKeHSJxTOCWmd,VAtFyBPDjrRQsLMofgKeHSJxTOCWmq)
   else:
    VAtFyBPDjrRQsLMofgKeHSJxTOCWml='{}|{}'.format(VAtFyBPDjrRQsLMofgKeHSJxTOCWmv['streaming_url'],VAtFyBPDjrRQsLMofgKeHSJxTOCWmq)
  else:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWmq=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.make_stream_header(VAtFyBPDjrRQsLMofgKeHSJxTOCWmE,VAtFyBPDjrRQsLMofgKeHSJxTOCWmh)
   VAtFyBPDjrRQsLMofgKeHSJxTOCWml='{}|{}'.format(VAtFyBPDjrRQsLMofgKeHSJxTOCWmv['streaming_url'],VAtFyBPDjrRQsLMofgKeHSJxTOCWmq)
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.addon_log('if tmp_pos == -1')
  VAtFyBPDjrRQsLMofgKeHSJxTOCWXz,VAtFyBPDjrRQsLMofgKeHSJxTOCWXw=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.get_settings_proxyport()
  VAtFyBPDjrRQsLMofgKeHSJxTOCWXi=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.get_settings_playback()
  if(VAtFyBPDjrRQsLMofgKeHSJxTOCWXz and VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('mode')in['VOD','MOVIE']and VAtFyBPDjrRQsLMofgKeHSJxTOCWmY==VAtFyBPDjrRQsLMofgKeHSJxTOCWGc and(VAtFyBPDjrRQsLMofgKeHSJxTOCWmv['drm_server_url']!='' or(VAtFyBPDjrRQsLMofgKeHSJxTOCWmv['url_filename'].split('.')[1]=='mpd')or(VAtFyBPDjrRQsLMofgKeHSJxTOCWmv['url_filename'].split('.')[1]!='mpd' and VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.KodiVersion>=21 and VAtFyBPDjrRQsLMofgKeHSJxTOCWmv['qt_stream']=='stream70'))):
   if VAtFyBPDjrRQsLMofgKeHSJxTOCWmv['url_filename'].split('.')[1]=='mpd':
    VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.Tving_Parse_mpd(VAtFyBPDjrRQsLMofgKeHSJxTOCWmv['streaming_url'],VAtFyBPDjrRQsLMofgKeHSJxTOCWmv['watermarkKey'],VAtFyBPDjrRQsLMofgKeHSJxTOCWmv['watermark'])
   else:
    VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.Tving_Parse_m3u8(VAtFyBPDjrRQsLMofgKeHSJxTOCWmv['streaming_url'])
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.addon_log('xxx '+VAtFyBPDjrRQsLMofgKeHSJxTOCWmv['streaming_url'])
   VAtFyBPDjrRQsLMofgKeHSJxTOCWmn={'addon':'tvingm','playOption':VAtFyBPDjrRQsLMofgKeHSJxTOCWXi,'url_filename':VAtFyBPDjrRQsLMofgKeHSJxTOCWmv['url_filename'],}
   VAtFyBPDjrRQsLMofgKeHSJxTOCWmn=json.dumps(VAtFyBPDjrRQsLMofgKeHSJxTOCWmn,separators=(',',':'))
   VAtFyBPDjrRQsLMofgKeHSJxTOCWmn=base64.standard_b64encode(VAtFyBPDjrRQsLMofgKeHSJxTOCWmn.encode()).decode('utf-8')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWml ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(VAtFyBPDjrRQsLMofgKeHSJxTOCWXw,VAtFyBPDjrRQsLMofgKeHSJxTOCWml,VAtFyBPDjrRQsLMofgKeHSJxTOCWmn)
   VAtFyBPDjrRQsLMofgKeHSJxTOCWmE['proxy-mini']=VAtFyBPDjrRQsLMofgKeHSJxTOCWmn 
  VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.addon_log('surl(2) : {}'.format(VAtFyBPDjrRQsLMofgKeHSJxTOCWml))
  VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.addon_log('drm     : {}'.format(VAtFyBPDjrRQsLMofgKeHSJxTOCWmv['drm_server_url']))
  VAtFyBPDjrRQsLMofgKeHSJxTOCWmq=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.make_stream_header(VAtFyBPDjrRQsLMofgKeHSJxTOCWmE,VAtFyBPDjrRQsLMofgKeHSJxTOCWmh)
  VAtFyBPDjrRQsLMofgKeHSJxTOCWck=xbmcgui.ListItem(path=VAtFyBPDjrRQsLMofgKeHSJxTOCWml)
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWmv['drm_server_url']!='':
   VAtFyBPDjrRQsLMofgKeHSJxTOCWcX=VAtFyBPDjrRQsLMofgKeHSJxTOCWmv['drm_server_url']
   VAtFyBPDjrRQsLMofgKeHSJxTOCWcU ='https://license-global.pallycon.com/ri/licenseManager.do' 
   VAtFyBPDjrRQsLMofgKeHSJxTOCWci ='mpd'
   VAtFyBPDjrRQsLMofgKeHSJxTOCWcz ='com.widevine.alpha'
   inputstreamhelper.Helper('mpd',drm='com.widevine.alpha').check_inputstream()
   VAtFyBPDjrRQsLMofgKeHSJxTOCWcm={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.USER_AGENT,VAtFyBPDjrRQsLMofgKeHSJxTOCWmv['drm_header_key']:VAtFyBPDjrRQsLMofgKeHSJxTOCWmv['drm_header_value'],}
   VAtFyBPDjrRQsLMofgKeHSJxTOCWcG=VAtFyBPDjrRQsLMofgKeHSJxTOCWcU+'|'+urllib.parse.urlencode(VAtFyBPDjrRQsLMofgKeHSJxTOCWcm)+'|R{SSM}|'
   VAtFyBPDjrRQsLMofgKeHSJxTOCWck.setProperty('inputstream','inputstream.adaptive')
   if VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.KodiVersion<=20:
    VAtFyBPDjrRQsLMofgKeHSJxTOCWck.setProperty('inputstream.adaptive.manifest_type',VAtFyBPDjrRQsLMofgKeHSJxTOCWci)
   VAtFyBPDjrRQsLMofgKeHSJxTOCWck.setProperty('inputstream.adaptive.license_type',VAtFyBPDjrRQsLMofgKeHSJxTOCWcz)
   VAtFyBPDjrRQsLMofgKeHSJxTOCWck.setProperty('inputstream.adaptive.license_key',VAtFyBPDjrRQsLMofgKeHSJxTOCWcG)
   VAtFyBPDjrRQsLMofgKeHSJxTOCWck.setProperty('inputstream.adaptive.stream_headers',VAtFyBPDjrRQsLMofgKeHSJxTOCWmq)
   VAtFyBPDjrRQsLMofgKeHSJxTOCWck.setProperty('inputstream.adaptive.manifest_headers',VAtFyBPDjrRQsLMofgKeHSJxTOCWmq)
  elif VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('mode')in['VOD','MOVIE']:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWck.setContentLookup(VAtFyBPDjrRQsLMofgKeHSJxTOCWGc)
   VAtFyBPDjrRQsLMofgKeHSJxTOCWck.setMimeType('application/x-mpegURL')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWck.setProperty('inputstream','inputstream.adaptive')
   if VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.KodiVersion<=20:
    VAtFyBPDjrRQsLMofgKeHSJxTOCWck.setProperty('inputstream.adaptive.manifest_type','hls')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWck.setProperty('inputstream.adaptive.stream_headers',VAtFyBPDjrRQsLMofgKeHSJxTOCWmq)
   VAtFyBPDjrRQsLMofgKeHSJxTOCWck.setProperty('inputstream.adaptive.manifest_headers',VAtFyBPDjrRQsLMofgKeHSJxTOCWmq)
  elif VAtFyBPDjrRQsLMofgKeHSJxTOCWmY==VAtFyBPDjrRQsLMofgKeHSJxTOCWGm:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWck.setContentLookup(VAtFyBPDjrRQsLMofgKeHSJxTOCWGc)
   VAtFyBPDjrRQsLMofgKeHSJxTOCWck.setMimeType('application/x-mpegURL')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWck.setProperty('inputstream','inputstream.ffmpegdirect')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWck.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWck.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWck.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWck.setProperty('ResumeTime','0')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWck.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_handle,VAtFyBPDjrRQsLMofgKeHSJxTOCWGm,VAtFyBPDjrRQsLMofgKeHSJxTOCWck)
  try:
   if VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('mode')in['VOD','MOVIE']and VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('title'):
    VAtFyBPDjrRQsLMofgKeHSJxTOCWUX={'code':VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('programcode')if VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('mode')=='VOD' else VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('mediacode'),'img':VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('thumbnail'),'title':VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('title'),'videoid':VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('mediacode')}
    VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.Save_Watched_List(VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('stype'),VAtFyBPDjrRQsLMofgKeHSJxTOCWUX)
  except:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWGz
 def logout(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE):
  VAtFyBPDjrRQsLMofgKeHSJxTOCWka=xbmcgui.Dialog()
  VAtFyBPDjrRQsLMofgKeHSJxTOCWUv=VAtFyBPDjrRQsLMofgKeHSJxTOCWka.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWUv==VAtFyBPDjrRQsLMofgKeHSJxTOCWGc:sys.exit()
  VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.Init_TV_Total()
  if os.path.isfile(VAtFyBPDjrRQsLMofgKeHSJxTOCWkb):os.remove(VAtFyBPDjrRQsLMofgKeHSJxTOCWkb)
  VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE):
  VAtFyBPDjrRQsLMofgKeHSJxTOCWcp =VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.Get_Now_Datetime()
  VAtFyBPDjrRQsLMofgKeHSJxTOCWcb=VAtFyBPDjrRQsLMofgKeHSJxTOCWcp+datetime.timedelta(days=30) 
  (VAtFyBPDjrRQsLMofgKeHSJxTOCWUc,VAtFyBPDjrRQsLMofgKeHSJxTOCWUG,VAtFyBPDjrRQsLMofgKeHSJxTOCWUp,VAtFyBPDjrRQsLMofgKeHSJxTOCWUb)=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.get_settings_account()
  VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.Save_session_acount(VAtFyBPDjrRQsLMofgKeHSJxTOCWUc,VAtFyBPDjrRQsLMofgKeHSJxTOCWUG,VAtFyBPDjrRQsLMofgKeHSJxTOCWUp,VAtFyBPDjrRQsLMofgKeHSJxTOCWUb)
  VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.TV['account']['token_limit']=VAtFyBPDjrRQsLMofgKeHSJxTOCWcb.strftime('%Y%m%d')
  VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.JsonFile_Save(VAtFyBPDjrRQsLMofgKeHSJxTOCWkb,VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.TV)
 def cookiefile_check(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE):
  VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.TV=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.JsonFile_Load(VAtFyBPDjrRQsLMofgKeHSJxTOCWkb)
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.TV=={}:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.Init_TV_Total()
   return VAtFyBPDjrRQsLMofgKeHSJxTOCWGc
  (VAtFyBPDjrRQsLMofgKeHSJxTOCWcv,VAtFyBPDjrRQsLMofgKeHSJxTOCWcE,VAtFyBPDjrRQsLMofgKeHSJxTOCWch,VAtFyBPDjrRQsLMofgKeHSJxTOCWcY)=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.get_settings_account()
  (VAtFyBPDjrRQsLMofgKeHSJxTOCWcI,VAtFyBPDjrRQsLMofgKeHSJxTOCWcd,VAtFyBPDjrRQsLMofgKeHSJxTOCWca,VAtFyBPDjrRQsLMofgKeHSJxTOCWcq)=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.Load_session_acount()
  if(VAtFyBPDjrRQsLMofgKeHSJxTOCWcv!=VAtFyBPDjrRQsLMofgKeHSJxTOCWcI or VAtFyBPDjrRQsLMofgKeHSJxTOCWcE!=VAtFyBPDjrRQsLMofgKeHSJxTOCWcd or VAtFyBPDjrRQsLMofgKeHSJxTOCWch!=VAtFyBPDjrRQsLMofgKeHSJxTOCWca or VAtFyBPDjrRQsLMofgKeHSJxTOCWcY!=VAtFyBPDjrRQsLMofgKeHSJxTOCWcq)and VAtFyBPDjrRQsLMofgKeHSJxTOCWcI!='xxxxx':
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.Init_TV_Total()
   return VAtFyBPDjrRQsLMofgKeHSJxTOCWGc
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWGw(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>VAtFyBPDjrRQsLMofgKeHSJxTOCWGw(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.TV['account']['token_limit']):
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.Init_TV_Total()
   return VAtFyBPDjrRQsLMofgKeHSJxTOCWGc
  return VAtFyBPDjrRQsLMofgKeHSJxTOCWGm
 def dp_Global_Search(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE,VAtFyBPDjrRQsLMofgKeHSJxTOCWUq):
  VAtFyBPDjrRQsLMofgKeHSJxTOCWzl=VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('mode')
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWzl=='TOTAL_SEARCH':
   VAtFyBPDjrRQsLMofgKeHSJxTOCWcu='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWcu='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(VAtFyBPDjrRQsLMofgKeHSJxTOCWcu)
 def dp_Bookmark_Menu(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE,VAtFyBPDjrRQsLMofgKeHSJxTOCWUq):
  VAtFyBPDjrRQsLMofgKeHSJxTOCWcu='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(VAtFyBPDjrRQsLMofgKeHSJxTOCWcu)
 def dp_EuroLive_List(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE,VAtFyBPDjrRQsLMofgKeHSJxTOCWUq):
  VAtFyBPDjrRQsLMofgKeHSJxTOCWUN=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.GetEuroChannelList()
  for VAtFyBPDjrRQsLMofgKeHSJxTOCWUn in VAtFyBPDjrRQsLMofgKeHSJxTOCWUN:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWid =VAtFyBPDjrRQsLMofgKeHSJxTOCWUn.get('channel')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWXI =VAtFyBPDjrRQsLMofgKeHSJxTOCWUn.get('title')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWiv =VAtFyBPDjrRQsLMofgKeHSJxTOCWUn.get('subtitle')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWib={'mediatype':'episode','title':VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,'plot':'%s\n%s'%(VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,VAtFyBPDjrRQsLMofgKeHSJxTOCWiv)}
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX={'mode':'LIVE','mediacode':VAtFyBPDjrRQsLMofgKeHSJxTOCWid,'stype':'onair',}
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.add_dir(VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,sublabel=VAtFyBPDjrRQsLMofgKeHSJxTOCWiv,img='',infoLabels=VAtFyBPDjrRQsLMofgKeHSJxTOCWib,isFolder=VAtFyBPDjrRQsLMofgKeHSJxTOCWGc,params=VAtFyBPDjrRQsLMofgKeHSJxTOCWUX)
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWGh(VAtFyBPDjrRQsLMofgKeHSJxTOCWUN)>0:xbmcplugin.endOfDirectory(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_handle,cacheToDisc=VAtFyBPDjrRQsLMofgKeHSJxTOCWGc)
 def dp_Apple_Group(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE,VAtFyBPDjrRQsLMofgKeHSJxTOCWUq):
  VAtFyBPDjrRQsLMofgKeHSJxTOCWcN=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.Get_AppleGroup_List()
  for VAtFyBPDjrRQsLMofgKeHSJxTOCWcl in VAtFyBPDjrRQsLMofgKeHSJxTOCWcN:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWcn =VAtFyBPDjrRQsLMofgKeHSJxTOCWcl.get('bandName')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWGk =VAtFyBPDjrRQsLMofgKeHSJxTOCWcl.get('bandKey')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWGX =VAtFyBPDjrRQsLMofgKeHSJxTOCWcl.get('moreUrl')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWib={'mediatype':'tvshow','title':VAtFyBPDjrRQsLMofgKeHSJxTOCWcn,'plot':'%s'%(VAtFyBPDjrRQsLMofgKeHSJxTOCWGk),}
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX={'mode':'BAND_VODLIST','bandKey':VAtFyBPDjrRQsLMofgKeHSJxTOCWGk,'moreUrl':VAtFyBPDjrRQsLMofgKeHSJxTOCWGX,}
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.add_dir(VAtFyBPDjrRQsLMofgKeHSJxTOCWcn,sublabel=VAtFyBPDjrRQsLMofgKeHSJxTOCWGz,img='',infoLabels=VAtFyBPDjrRQsLMofgKeHSJxTOCWib,isFolder=VAtFyBPDjrRQsLMofgKeHSJxTOCWGm,params=VAtFyBPDjrRQsLMofgKeHSJxTOCWUX)
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWGh(VAtFyBPDjrRQsLMofgKeHSJxTOCWcN)>0:xbmcplugin.endOfDirectory(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_handle,cacheToDisc=VAtFyBPDjrRQsLMofgKeHSJxTOCWGc)
 def dp_Band_VodList(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE,VAtFyBPDjrRQsLMofgKeHSJxTOCWUq):
  VAtFyBPDjrRQsLMofgKeHSJxTOCWGk =VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('bandKey')
  VAtFyBPDjrRQsLMofgKeHSJxTOCWGX =VAtFyBPDjrRQsLMofgKeHSJxTOCWUq.get('moreUrl')
  VAtFyBPDjrRQsLMofgKeHSJxTOCWGU ='Apple TV+'
  VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.addon_log('bandCode : '+VAtFyBPDjrRQsLMofgKeHSJxTOCWGk)
  VAtFyBPDjrRQsLMofgKeHSJxTOCWiY=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.Get_Band_VodList(VAtFyBPDjrRQsLMofgKeHSJxTOCWGk,VAtFyBPDjrRQsLMofgKeHSJxTOCWGX)
  for VAtFyBPDjrRQsLMofgKeHSJxTOCWiI in VAtFyBPDjrRQsLMofgKeHSJxTOCWiY:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWXI =VAtFyBPDjrRQsLMofgKeHSJxTOCWiI.get('title')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWik =VAtFyBPDjrRQsLMofgKeHSJxTOCWiI.get('thumbnail')
   VAtFyBPDjrRQsLMofgKeHSJxTOCWib={'mediatype':'tvshow','title':VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,'plot':VAtFyBPDjrRQsLMofgKeHSJxTOCWXI}
   VAtFyBPDjrRQsLMofgKeHSJxTOCWUX={'mode':'EPISODE','programcode':VAtFyBPDjrRQsLMofgKeHSJxTOCWiI.get('program'),'page':'1'}
   if VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.get_settings_makebookmark():
    VAtFyBPDjrRQsLMofgKeHSJxTOCWia={'videoid':VAtFyBPDjrRQsLMofgKeHSJxTOCWiI.get('program'),'vidtype':'tvshow','vtitle':VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,'vsubtitle':VAtFyBPDjrRQsLMofgKeHSJxTOCWGU,}
    VAtFyBPDjrRQsLMofgKeHSJxTOCWiq=json.dumps(VAtFyBPDjrRQsLMofgKeHSJxTOCWia)
    VAtFyBPDjrRQsLMofgKeHSJxTOCWiq=urllib.parse.quote(VAtFyBPDjrRQsLMofgKeHSJxTOCWiq)
    VAtFyBPDjrRQsLMofgKeHSJxTOCWiu='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(VAtFyBPDjrRQsLMofgKeHSJxTOCWiq)
    VAtFyBPDjrRQsLMofgKeHSJxTOCWiN=[('(통합) 찜 영상에 추가',VAtFyBPDjrRQsLMofgKeHSJxTOCWiu)]
   else:
    VAtFyBPDjrRQsLMofgKeHSJxTOCWiN=VAtFyBPDjrRQsLMofgKeHSJxTOCWGz
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.add_dir(VAtFyBPDjrRQsLMofgKeHSJxTOCWXI,sublabel=VAtFyBPDjrRQsLMofgKeHSJxTOCWGU,img=VAtFyBPDjrRQsLMofgKeHSJxTOCWik,infoLabels=VAtFyBPDjrRQsLMofgKeHSJxTOCWib,isFolder=VAtFyBPDjrRQsLMofgKeHSJxTOCWGm,params=VAtFyBPDjrRQsLMofgKeHSJxTOCWUX,ContextMenu=VAtFyBPDjrRQsLMofgKeHSJxTOCWiN)
  xbmcplugin.setContent(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE._addon_handle,cacheToDisc=VAtFyBPDjrRQsLMofgKeHSJxTOCWGc)
 def tving_main(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE):
  VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.TvingObj.KodiVersion=VAtFyBPDjrRQsLMofgKeHSJxTOCWGw(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  VAtFyBPDjrRQsLMofgKeHSJxTOCWzl=VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.main_params.get('mode',VAtFyBPDjrRQsLMofgKeHSJxTOCWGz)
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWzl=='LOGOUT':
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.logout()
   return
  VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.login_main()
  if VAtFyBPDjrRQsLMofgKeHSJxTOCWzl is VAtFyBPDjrRQsLMofgKeHSJxTOCWGz:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.dp_Main_List()
  elif VAtFyBPDjrRQsLMofgKeHSJxTOCWzl in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.dp_Title_Group(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.main_params)
  elif VAtFyBPDjrRQsLMofgKeHSJxTOCWzl in['GLOBAL_GROUP']:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.dp_SubTitle_Group(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.main_params)
  elif VAtFyBPDjrRQsLMofgKeHSJxTOCWzl=='CHANNEL':
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.dp_LiveChannel_List(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.main_params)
  elif VAtFyBPDjrRQsLMofgKeHSJxTOCWzl in['LIVE','VOD','MOVIE']:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.play_VIDEO(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.main_params)
  elif VAtFyBPDjrRQsLMofgKeHSJxTOCWzl=='PROGRAM':
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.dp_Program_List(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.main_params)
  elif VAtFyBPDjrRQsLMofgKeHSJxTOCWzl=='4K_PROGRAM':
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.dp_4K_Program_List(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.main_params)
  elif VAtFyBPDjrRQsLMofgKeHSJxTOCWzl=='ORI_PROGRAM':
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.dp_Ori_Program_List(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.main_params)
  elif VAtFyBPDjrRQsLMofgKeHSJxTOCWzl=='EPISODE':
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.dp_Episode_List(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.main_params)
  elif VAtFyBPDjrRQsLMofgKeHSJxTOCWzl=='MOVIE_SUB':
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.dp_Movie_List(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.main_params)
  elif VAtFyBPDjrRQsLMofgKeHSJxTOCWzl=='4K_MOVIE':
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.dp_4K_Movie_List(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.main_params)
  elif VAtFyBPDjrRQsLMofgKeHSJxTOCWzl=='SEARCH_GROUP':
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.dp_Search_Group(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.main_params)
  elif VAtFyBPDjrRQsLMofgKeHSJxTOCWzl in['SEARCH','LOCAL_SEARCH']:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.dp_Search_List(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.main_params)
  elif VAtFyBPDjrRQsLMofgKeHSJxTOCWzl=='WATCH':
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.dp_Watch_List(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.main_params)
  elif VAtFyBPDjrRQsLMofgKeHSJxTOCWzl in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.dp_History_Remove(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.main_params)
  elif VAtFyBPDjrRQsLMofgKeHSJxTOCWzl=='ORDER_BY':
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.dp_setEpOrderby(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.main_params)
  elif VAtFyBPDjrRQsLMofgKeHSJxTOCWzl=='SET_BOOKMARK':
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.dp_Set_Bookmark(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.main_params)
  elif VAtFyBPDjrRQsLMofgKeHSJxTOCWzl in['TOTAL_SEARCH','TOTAL_HISTORY']:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.dp_Global_Search(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.main_params)
  elif VAtFyBPDjrRQsLMofgKeHSJxTOCWzl=='SEARCH_HISTORY':
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.dp_Search_History(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.main_params)
  elif VAtFyBPDjrRQsLMofgKeHSJxTOCWzl=='MENU_BOOKMARK':
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.dp_Bookmark_Menu(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.main_params)
  elif VAtFyBPDjrRQsLMofgKeHSJxTOCWzl=='EURO_GROUP':
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.dp_EuroLive_List(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.main_params)
  elif VAtFyBPDjrRQsLMofgKeHSJxTOCWzl=='APPLE_GROUP':
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.dp_Apple_Group(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.main_params)
  elif VAtFyBPDjrRQsLMofgKeHSJxTOCWzl=='BAND_VODLIST':
   VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.dp_Band_VodList(VAtFyBPDjrRQsLMofgKeHSJxTOCWkE.main_params)
  else:
   VAtFyBPDjrRQsLMofgKeHSJxTOCWGz
# Created by pyminifier (https://github.com/liftoff/pyminifier)
