__author__="NightRain"
NwaritGpdjWXDlBuzVsfRFQgIUTKMS=object
NwaritGpdjWXDlBuzVsfRFQgIUTKMq=None
NwaritGpdjWXDlBuzVsfRFQgIUTKyb=False
NwaritGpdjWXDlBuzVsfRFQgIUTKyC=int
NwaritGpdjWXDlBuzVsfRFQgIUTKye=range
NwaritGpdjWXDlBuzVsfRFQgIUTKym=True
NwaritGpdjWXDlBuzVsfRFQgIUTKyM=Exception
NwaritGpdjWXDlBuzVsfRFQgIUTKyP=print
NwaritGpdjWXDlBuzVsfRFQgIUTKyL=str
NwaritGpdjWXDlBuzVsfRFQgIUTKyv=list
NwaritGpdjWXDlBuzVsfRFQgIUTKyJ=len
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import requests
import datetime
import random
NwaritGpdjWXDlBuzVsfRFQgIUTKbe={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
NwaritGpdjWXDlBuzVsfRFQgIUTKbm ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
class NwaritGpdjWXDlBuzVsfRFQgIUTKbC(NwaritGpdjWXDlBuzVsfRFQgIUTKMS):
 def __init__(NwaritGpdjWXDlBuzVsfRFQgIUTKbM):
  NwaritGpdjWXDlBuzVsfRFQgIUTKbM.TVING_TOKEN =''
  NwaritGpdjWXDlBuzVsfRFQgIUTKbM.POC_USERINFO =''
  NwaritGpdjWXDlBuzVsfRFQgIUTKbM.TVING_UUID ='-'
  NwaritGpdjWXDlBuzVsfRFQgIUTKbM.TVING_MAINTOKEN=''
  NwaritGpdjWXDlBuzVsfRFQgIUTKbM.TVIGN_COOKIEKEY=''
  NwaritGpdjWXDlBuzVsfRFQgIUTKbM.TVING_LOCKKEY =''
  NwaritGpdjWXDlBuzVsfRFQgIUTKbM.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  NwaritGpdjWXDlBuzVsfRFQgIUTKbM.NETWORKCODE ='CSND0900'
  NwaritGpdjWXDlBuzVsfRFQgIUTKbM.OSCODE ='CSOD0900' 
  NwaritGpdjWXDlBuzVsfRFQgIUTKbM.TELECODE ='CSCD0900'
  NwaritGpdjWXDlBuzVsfRFQgIUTKbM.SCREENCODE ='CSSD0100'
  NwaritGpdjWXDlBuzVsfRFQgIUTKbM.LIVE_LIMIT =23
  NwaritGpdjWXDlBuzVsfRFQgIUTKbM.VOD_LIMIT =20
  NwaritGpdjWXDlBuzVsfRFQgIUTKbM.EPISODE_LIMIT =30 
  NwaritGpdjWXDlBuzVsfRFQgIUTKbM.SEARCH_LIMIT =80 
  NwaritGpdjWXDlBuzVsfRFQgIUTKbM.MOVIE_LIMIT =18
  NwaritGpdjWXDlBuzVsfRFQgIUTKbM.API_DOMAIN ='https://api.tving.com'
  NwaritGpdjWXDlBuzVsfRFQgIUTKbM.IMG_DOMAIN ='https://image.tving.com'
  NwaritGpdjWXDlBuzVsfRFQgIUTKbM.SEARCH_DOMAIN ='https://search.tving.com'
  NwaritGpdjWXDlBuzVsfRFQgIUTKbM.LOGIN_DOMAIN ='https://user.tving.com'
  NwaritGpdjWXDlBuzVsfRFQgIUTKbM.URL_DOMAIN ='https://www.tving.com'
  NwaritGpdjWXDlBuzVsfRFQgIUTKbM.MOVIE_LITE =['2610061','2610161','261062']
  NwaritGpdjWXDlBuzVsfRFQgIUTKbM.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
  NwaritGpdjWXDlBuzVsfRFQgIUTKbM.DEFAULT_HEADER ={'user-agent':NwaritGpdjWXDlBuzVsfRFQgIUTKbM.USER_AGENT}
  NwaritGpdjWXDlBuzVsfRFQgIUTKbM.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
 def callRequestCookies(NwaritGpdjWXDlBuzVsfRFQgIUTKbM,jobtype,NwaritGpdjWXDlBuzVsfRFQgIUTKCx,payload=NwaritGpdjWXDlBuzVsfRFQgIUTKMq,params=NwaritGpdjWXDlBuzVsfRFQgIUTKMq,headers=NwaritGpdjWXDlBuzVsfRFQgIUTKMq,cookies=NwaritGpdjWXDlBuzVsfRFQgIUTKMq,redirects=NwaritGpdjWXDlBuzVsfRFQgIUTKyb):
  NwaritGpdjWXDlBuzVsfRFQgIUTKby=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.DEFAULT_HEADER
  if headers:NwaritGpdjWXDlBuzVsfRFQgIUTKby.update(headers)
  if jobtype=='Get':
   NwaritGpdjWXDlBuzVsfRFQgIUTKbP=requests.get(NwaritGpdjWXDlBuzVsfRFQgIUTKCx,params=params,headers=NwaritGpdjWXDlBuzVsfRFQgIUTKby,cookies=cookies,allow_redirects=redirects)
  else:
   NwaritGpdjWXDlBuzVsfRFQgIUTKbP=requests.post(NwaritGpdjWXDlBuzVsfRFQgIUTKCx,data=payload,params=params,headers=NwaritGpdjWXDlBuzVsfRFQgIUTKby,cookies=cookies,allow_redirects=redirects)
  return NwaritGpdjWXDlBuzVsfRFQgIUTKbP
 def makeDefaultCookies(NwaritGpdjWXDlBuzVsfRFQgIUTKbM,vToken=NwaritGpdjWXDlBuzVsfRFQgIUTKMq,vUserinfo=NwaritGpdjWXDlBuzVsfRFQgIUTKMq):
  NwaritGpdjWXDlBuzVsfRFQgIUTKbL={}
  NwaritGpdjWXDlBuzVsfRFQgIUTKbL['_tving_token']=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.TVING_TOKEN if vToken==NwaritGpdjWXDlBuzVsfRFQgIUTKMq else vToken
  NwaritGpdjWXDlBuzVsfRFQgIUTKbL['POC_USERINFO']=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.POC_USERINFO if vToken==NwaritGpdjWXDlBuzVsfRFQgIUTKMq else vUserinfo
  if NwaritGpdjWXDlBuzVsfRFQgIUTKbM.TVING_MAINTOKEN!='':NwaritGpdjWXDlBuzVsfRFQgIUTKbL[NwaritGpdjWXDlBuzVsfRFQgIUTKbM.GLOBAL_COOKIENM['tv_maintoken']]=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.TVING_MAINTOKEN
  if NwaritGpdjWXDlBuzVsfRFQgIUTKbM.TVIGN_COOKIEKEY!='':NwaritGpdjWXDlBuzVsfRFQgIUTKbL[NwaritGpdjWXDlBuzVsfRFQgIUTKbM.GLOBAL_COOKIENM['tv_cookiekey']]=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.TVIGN_COOKIEKEY
  if NwaritGpdjWXDlBuzVsfRFQgIUTKbM.TVING_LOCKKEY !='':NwaritGpdjWXDlBuzVsfRFQgIUTKbL[NwaritGpdjWXDlBuzVsfRFQgIUTKbM.GLOBAL_COOKIENM['tv_lockkey']] =NwaritGpdjWXDlBuzVsfRFQgIUTKbM.TVING_LOCKKEY
  return NwaritGpdjWXDlBuzVsfRFQgIUTKbL
 def getDeviceStr(NwaritGpdjWXDlBuzVsfRFQgIUTKbM):
  NwaritGpdjWXDlBuzVsfRFQgIUTKbv=[]
  NwaritGpdjWXDlBuzVsfRFQgIUTKbv.append('Windows') 
  NwaritGpdjWXDlBuzVsfRFQgIUTKbv.append('Chrome') 
  NwaritGpdjWXDlBuzVsfRFQgIUTKbv.append('ko-KR') 
  NwaritGpdjWXDlBuzVsfRFQgIUTKbv.append('undefined') 
  NwaritGpdjWXDlBuzVsfRFQgIUTKbv.append('24') 
  NwaritGpdjWXDlBuzVsfRFQgIUTKbv.append(u'한국 표준시')
  NwaritGpdjWXDlBuzVsfRFQgIUTKbv.append('undefined') 
  NwaritGpdjWXDlBuzVsfRFQgIUTKbv.append('undefined') 
  NwaritGpdjWXDlBuzVsfRFQgIUTKbv.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  NwaritGpdjWXDlBuzVsfRFQgIUTKbJ=''
  for NwaritGpdjWXDlBuzVsfRFQgIUTKbA in NwaritGpdjWXDlBuzVsfRFQgIUTKbv:
   NwaritGpdjWXDlBuzVsfRFQgIUTKbJ+=NwaritGpdjWXDlBuzVsfRFQgIUTKbA+'|'
  return NwaritGpdjWXDlBuzVsfRFQgIUTKbJ
 def SaveCredential(NwaritGpdjWXDlBuzVsfRFQgIUTKbM,NwaritGpdjWXDlBuzVsfRFQgIUTKbH):
  NwaritGpdjWXDlBuzVsfRFQgIUTKbM.TVING_TOKEN =NwaritGpdjWXDlBuzVsfRFQgIUTKbH.get('tving_token')
  NwaritGpdjWXDlBuzVsfRFQgIUTKbM.POC_USERINFO =NwaritGpdjWXDlBuzVsfRFQgIUTKbH.get('poc_userinfo')
  NwaritGpdjWXDlBuzVsfRFQgIUTKbM.TVING_UUID =NwaritGpdjWXDlBuzVsfRFQgIUTKbH.get('tving_uuid')
  NwaritGpdjWXDlBuzVsfRFQgIUTKbM.TVING_MAINTOKEN=NwaritGpdjWXDlBuzVsfRFQgIUTKbH.get('tving_maintoken')
  NwaritGpdjWXDlBuzVsfRFQgIUTKbM.TVIGN_COOKIEKEY=NwaritGpdjWXDlBuzVsfRFQgIUTKbH.get('tving_cookiekey')
  NwaritGpdjWXDlBuzVsfRFQgIUTKbM.TVING_LOCKKEY =NwaritGpdjWXDlBuzVsfRFQgIUTKbH.get('tving_lockkey')
 def LoadCredential(NwaritGpdjWXDlBuzVsfRFQgIUTKbM):
  NwaritGpdjWXDlBuzVsfRFQgIUTKbH={'tving_token':NwaritGpdjWXDlBuzVsfRFQgIUTKbM.TVING_TOKEN,'poc_userinfo':NwaritGpdjWXDlBuzVsfRFQgIUTKbM.POC_USERINFO,'tving_uuid':NwaritGpdjWXDlBuzVsfRFQgIUTKbM.TVING_UUID,'tving_maintoken':NwaritGpdjWXDlBuzVsfRFQgIUTKbM.TVING_MAINTOKEN,'tving_cookiekey':NwaritGpdjWXDlBuzVsfRFQgIUTKbM.TVIGN_COOKIEKEY,'tving_lockkey':NwaritGpdjWXDlBuzVsfRFQgIUTKbM.TVING_LOCKKEY}
  return NwaritGpdjWXDlBuzVsfRFQgIUTKbH
 def GetDefaultParams(NwaritGpdjWXDlBuzVsfRFQgIUTKbM):
  NwaritGpdjWXDlBuzVsfRFQgIUTKbn={'apiKey':NwaritGpdjWXDlBuzVsfRFQgIUTKbM.APIKEY,'networkCode':NwaritGpdjWXDlBuzVsfRFQgIUTKbM.NETWORKCODE,'osCode':NwaritGpdjWXDlBuzVsfRFQgIUTKbM.OSCODE,'teleCode':NwaritGpdjWXDlBuzVsfRFQgIUTKbM.TELECODE,'screenCode':NwaritGpdjWXDlBuzVsfRFQgIUTKbM.SCREENCODE}
  return NwaritGpdjWXDlBuzVsfRFQgIUTKbn
 def GetNoCache(NwaritGpdjWXDlBuzVsfRFQgIUTKbM,timetype=1):
  if timetype==1:
   return NwaritGpdjWXDlBuzVsfRFQgIUTKyC(time.time())
  else:
   return NwaritGpdjWXDlBuzVsfRFQgIUTKyC(time.time()*1000)
 def GetUniqueid(NwaritGpdjWXDlBuzVsfRFQgIUTKbM):
  NwaritGpdjWXDlBuzVsfRFQgIUTKbx=[0 for i in NwaritGpdjWXDlBuzVsfRFQgIUTKye(256)]
  for i in NwaritGpdjWXDlBuzVsfRFQgIUTKye(256):
   NwaritGpdjWXDlBuzVsfRFQgIUTKbx[i]='%02x'%(i)
  NwaritGpdjWXDlBuzVsfRFQgIUTKbk=NwaritGpdjWXDlBuzVsfRFQgIUTKyC(4294967295*random.random())|0
  NwaritGpdjWXDlBuzVsfRFQgIUTKbh=NwaritGpdjWXDlBuzVsfRFQgIUTKbx[255&NwaritGpdjWXDlBuzVsfRFQgIUTKbk]+NwaritGpdjWXDlBuzVsfRFQgIUTKbx[NwaritGpdjWXDlBuzVsfRFQgIUTKbk>>8&255]+NwaritGpdjWXDlBuzVsfRFQgIUTKbx[NwaritGpdjWXDlBuzVsfRFQgIUTKbk>>16&255]+NwaritGpdjWXDlBuzVsfRFQgIUTKbx[NwaritGpdjWXDlBuzVsfRFQgIUTKbk>>24&255]
  return NwaritGpdjWXDlBuzVsfRFQgIUTKbh
 def GetCredential(NwaritGpdjWXDlBuzVsfRFQgIUTKbM,user_id,user_pw,login_type,user_pf):
  NwaritGpdjWXDlBuzVsfRFQgIUTKbO=NwaritGpdjWXDlBuzVsfRFQgIUTKyb
  NwaritGpdjWXDlBuzVsfRFQgIUTKbY=NwaritGpdjWXDlBuzVsfRFQgIUTKCb=NwaritGpdjWXDlBuzVsfRFQgIUTKCe=NwaritGpdjWXDlBuzVsfRFQgIUTKCm=NwaritGpdjWXDlBuzVsfRFQgIUTKCM='' 
  NwaritGpdjWXDlBuzVsfRFQgIUTKbE ='-'
  try:
   NwaritGpdjWXDlBuzVsfRFQgIUTKbo=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   NwaritGpdjWXDlBuzVsfRFQgIUTKbc={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com/main.do','csite':''}
   NwaritGpdjWXDlBuzVsfRFQgIUTKbS=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.callRequestCookies('Post',NwaritGpdjWXDlBuzVsfRFQgIUTKbo,payload=NwaritGpdjWXDlBuzVsfRFQgIUTKbc,params=NwaritGpdjWXDlBuzVsfRFQgIUTKMq,headers=NwaritGpdjWXDlBuzVsfRFQgIUTKMq,cookies=NwaritGpdjWXDlBuzVsfRFQgIUTKMq)
   for NwaritGpdjWXDlBuzVsfRFQgIUTKbq in NwaritGpdjWXDlBuzVsfRFQgIUTKbS.cookies:
    if NwaritGpdjWXDlBuzVsfRFQgIUTKbq.name=='_tving_token':
     NwaritGpdjWXDlBuzVsfRFQgIUTKCb=NwaritGpdjWXDlBuzVsfRFQgIUTKbq.value
    elif NwaritGpdjWXDlBuzVsfRFQgIUTKbq.name=='POC_USERINFO':
     NwaritGpdjWXDlBuzVsfRFQgIUTKCe=NwaritGpdjWXDlBuzVsfRFQgIUTKbq.value
   if NwaritGpdjWXDlBuzVsfRFQgIUTKCb=='':return NwaritGpdjWXDlBuzVsfRFQgIUTKbO
   NwaritGpdjWXDlBuzVsfRFQgIUTKbY=NwaritGpdjWXDlBuzVsfRFQgIUTKCb
   NwaritGpdjWXDlBuzVsfRFQgIUTKCb,NwaritGpdjWXDlBuzVsfRFQgIUTKCm,NwaritGpdjWXDlBuzVsfRFQgIUTKCM=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.GetProfileToken(NwaritGpdjWXDlBuzVsfRFQgIUTKCb,NwaritGpdjWXDlBuzVsfRFQgIUTKCe,user_pf)
   NwaritGpdjWXDlBuzVsfRFQgIUTKbO=NwaritGpdjWXDlBuzVsfRFQgIUTKym
   NwaritGpdjWXDlBuzVsfRFQgIUTKbE =NwaritGpdjWXDlBuzVsfRFQgIUTKbM.GetDeviceList(NwaritGpdjWXDlBuzVsfRFQgIUTKCb,NwaritGpdjWXDlBuzVsfRFQgIUTKCe)
   NwaritGpdjWXDlBuzVsfRFQgIUTKbE =NwaritGpdjWXDlBuzVsfRFQgIUTKbE+'-'+NwaritGpdjWXDlBuzVsfRFQgIUTKbM.GetUniqueid()
  except NwaritGpdjWXDlBuzVsfRFQgIUTKyM as exception:
   NwaritGpdjWXDlBuzVsfRFQgIUTKbY=NwaritGpdjWXDlBuzVsfRFQgIUTKCb=NwaritGpdjWXDlBuzVsfRFQgIUTKCe=NwaritGpdjWXDlBuzVsfRFQgIUTKCm=NwaritGpdjWXDlBuzVsfRFQgIUTKCM=''
   NwaritGpdjWXDlBuzVsfRFQgIUTKbE='-'
   NwaritGpdjWXDlBuzVsfRFQgIUTKyP(exception)
  NwaritGpdjWXDlBuzVsfRFQgIUTKbH={'tving_token':NwaritGpdjWXDlBuzVsfRFQgIUTKCb,'poc_userinfo':NwaritGpdjWXDlBuzVsfRFQgIUTKCe,'tving_uuid':NwaritGpdjWXDlBuzVsfRFQgIUTKbE,'tving_maintoken':NwaritGpdjWXDlBuzVsfRFQgIUTKbY,'tving_cookiekey':NwaritGpdjWXDlBuzVsfRFQgIUTKCm,'tving_lockkey':NwaritGpdjWXDlBuzVsfRFQgIUTKCM}
  NwaritGpdjWXDlBuzVsfRFQgIUTKbM.SaveCredential(NwaritGpdjWXDlBuzVsfRFQgIUTKbH)
  return NwaritGpdjWXDlBuzVsfRFQgIUTKbO
 def Get_Now_Datetime(NwaritGpdjWXDlBuzVsfRFQgIUTKbM):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(NwaritGpdjWXDlBuzVsfRFQgIUTKbM,mediacode,sel_quality,stype,pvrmode='-'):
  NwaritGpdjWXDlBuzVsfRFQgIUTKCP=''
  NwaritGpdjWXDlBuzVsfRFQgIUTKCL=''
  NwaritGpdjWXDlBuzVsfRFQgIUTKCv =NwaritGpdjWXDlBuzVsfRFQgIUTKbM.TVING_UUID.split('-')[0] 
  NwaritGpdjWXDlBuzVsfRFQgIUTKCJ =NwaritGpdjWXDlBuzVsfRFQgIUTKbM.TVING_UUID 
  try:
   if stype!='tvingtv' and(pvrmode=='-' or stype!='onair'):
    NwaritGpdjWXDlBuzVsfRFQgIUTKCA ='/v2a/media/stream/info' 
    NwaritGpdjWXDlBuzVsfRFQgIUTKCH=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.GetDefaultParams()
    NwaritGpdjWXDlBuzVsfRFQgIUTKCn={'info':'N','mediaCode':mediacode,'noCache':NwaritGpdjWXDlBuzVsfRFQgIUTKyL(NwaritGpdjWXDlBuzVsfRFQgIUTKbM.GetNoCache(1)),'callingFrom':'HTML5','adReq':'adproxy','ooc':'','deviceId':NwaritGpdjWXDlBuzVsfRFQgIUTKCv,'uuid':NwaritGpdjWXDlBuzVsfRFQgIUTKCJ,'deviceInfo':'PC','wm':'Y'}
    NwaritGpdjWXDlBuzVsfRFQgIUTKCH.update(NwaritGpdjWXDlBuzVsfRFQgIUTKCn)
    NwaritGpdjWXDlBuzVsfRFQgIUTKCx=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.API_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKCA
    NwaritGpdjWXDlBuzVsfRFQgIUTKbL=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.makeDefaultCookies()
    NwaritGpdjWXDlBuzVsfRFQgIUTKbS=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.callRequestCookies('Get',NwaritGpdjWXDlBuzVsfRFQgIUTKCx,payload=NwaritGpdjWXDlBuzVsfRFQgIUTKMq,params=NwaritGpdjWXDlBuzVsfRFQgIUTKCH,headers=NwaritGpdjWXDlBuzVsfRFQgIUTKMq,cookies=NwaritGpdjWXDlBuzVsfRFQgIUTKbL)
    NwaritGpdjWXDlBuzVsfRFQgIUTKCk=json.loads(NwaritGpdjWXDlBuzVsfRFQgIUTKbS.text)
    if not('stream' in NwaritGpdjWXDlBuzVsfRFQgIUTKCk['body']):return NwaritGpdjWXDlBuzVsfRFQgIUTKCP,NwaritGpdjWXDlBuzVsfRFQgIUTKCL 
    NwaritGpdjWXDlBuzVsfRFQgIUTKCh=NwaritGpdjWXDlBuzVsfRFQgIUTKCk['body']['stream']
    NwaritGpdjWXDlBuzVsfRFQgIUTKyP(NwaritGpdjWXDlBuzVsfRFQgIUTKCh)
    NwaritGpdjWXDlBuzVsfRFQgIUTKCO=NwaritGpdjWXDlBuzVsfRFQgIUTKCh['quality']
    NwaritGpdjWXDlBuzVsfRFQgIUTKCY=[]
    for NwaritGpdjWXDlBuzVsfRFQgIUTKCE in NwaritGpdjWXDlBuzVsfRFQgIUTKCO:
     if NwaritGpdjWXDlBuzVsfRFQgIUTKCE['active']=='Y':
      NwaritGpdjWXDlBuzVsfRFQgIUTKCY.append({NwaritGpdjWXDlBuzVsfRFQgIUTKbe.get(NwaritGpdjWXDlBuzVsfRFQgIUTKCE['code']):NwaritGpdjWXDlBuzVsfRFQgIUTKCE['code']})
    NwaritGpdjWXDlBuzVsfRFQgIUTKCo=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.CheckQuality(sel_quality,NwaritGpdjWXDlBuzVsfRFQgIUTKCY)
   else:
    for NwaritGpdjWXDlBuzVsfRFQgIUTKCc,NwaritGpdjWXDlBuzVsfRFQgIUTKeP in NwaritGpdjWXDlBuzVsfRFQgIUTKbe.items():
     if NwaritGpdjWXDlBuzVsfRFQgIUTKeP==sel_quality:
      NwaritGpdjWXDlBuzVsfRFQgIUTKCo=NwaritGpdjWXDlBuzVsfRFQgIUTKCc
  except NwaritGpdjWXDlBuzVsfRFQgIUTKyM as exception:
   NwaritGpdjWXDlBuzVsfRFQgIUTKyP(exception)
   for NwaritGpdjWXDlBuzVsfRFQgIUTKCc,NwaritGpdjWXDlBuzVsfRFQgIUTKeP in NwaritGpdjWXDlBuzVsfRFQgIUTKbe.items():
    if NwaritGpdjWXDlBuzVsfRFQgIUTKeP==sel_quality:
     NwaritGpdjWXDlBuzVsfRFQgIUTKCo=NwaritGpdjWXDlBuzVsfRFQgIUTKCc
   return NwaritGpdjWXDlBuzVsfRFQgIUTKCP,NwaritGpdjWXDlBuzVsfRFQgIUTKCL
  NwaritGpdjWXDlBuzVsfRFQgIUTKyP(NwaritGpdjWXDlBuzVsfRFQgIUTKCo)
  try:
   NwaritGpdjWXDlBuzVsfRFQgIUTKCA ='/streaming/info'
   NwaritGpdjWXDlBuzVsfRFQgIUTKCH=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.GetDefaultParams()
   if stype=='onair':NwaritGpdjWXDlBuzVsfRFQgIUTKCH['osCode']='CSOD0400' 
   NwaritGpdjWXDlBuzVsfRFQgIUTKCS={'isTrusted':'false','NONE':'0','CAPTURING_PHASE':'1','AT_TARGET':'2','BUBBLING_PHASE':'3','type':'oocCreate','eventPhase':'0','bubbles':'false','cancelable':'false','defaultPrevented':'false','composed':'false','timeStamp':'2785.9800000005635','returnValue':'true','cancelBubble':'false'}
   NwaritGpdjWXDlBuzVsfRFQgIUTKCq=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.makeOocUrl(NwaritGpdjWXDlBuzVsfRFQgIUTKCS)
   NwaritGpdjWXDlBuzVsfRFQgIUTKeb=urllib.parse.quote(NwaritGpdjWXDlBuzVsfRFQgIUTKCq)
   NwaritGpdjWXDlBuzVsfRFQgIUTKCn={'info':'N','mediaCode':mediacode,'callingFrom':'HTML5','streamCode':NwaritGpdjWXDlBuzVsfRFQgIUTKCo,'adReq':'adproxy','ooc':NwaritGpdjWXDlBuzVsfRFQgIUTKCq,'deviceId':NwaritGpdjWXDlBuzVsfRFQgIUTKCv,'uuid':NwaritGpdjWXDlBuzVsfRFQgIUTKCJ,'deviceInfo':'PC'}
   NwaritGpdjWXDlBuzVsfRFQgIUTKeC =NwaritGpdjWXDlBuzVsfRFQgIUTKCH
   NwaritGpdjWXDlBuzVsfRFQgIUTKeC.update(NwaritGpdjWXDlBuzVsfRFQgIUTKCn)
   NwaritGpdjWXDlBuzVsfRFQgIUTKCx=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.URL_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKCA
   NwaritGpdjWXDlBuzVsfRFQgIUTKem={'origin':'https://www.tving.com'}
   if stype=='onair':NwaritGpdjWXDlBuzVsfRFQgIUTKem['Referer']='https://www.tving.com/live/player/'+mediacode
   else: NwaritGpdjWXDlBuzVsfRFQgIUTKem['Referer']='https://www.tving.com/vod/player/'+mediacode
   NwaritGpdjWXDlBuzVsfRFQgIUTKbL=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.makeDefaultCookies()
   NwaritGpdjWXDlBuzVsfRFQgIUTKbL['onClickEvent2']=NwaritGpdjWXDlBuzVsfRFQgIUTKeb
   NwaritGpdjWXDlBuzVsfRFQgIUTKbS=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.callRequestCookies('Post',NwaritGpdjWXDlBuzVsfRFQgIUTKCx,payload=NwaritGpdjWXDlBuzVsfRFQgIUTKeC,params=NwaritGpdjWXDlBuzVsfRFQgIUTKMq,headers=NwaritGpdjWXDlBuzVsfRFQgIUTKem,cookies=NwaritGpdjWXDlBuzVsfRFQgIUTKbL,redirects=NwaritGpdjWXDlBuzVsfRFQgIUTKyb)
   NwaritGpdjWXDlBuzVsfRFQgIUTKCk=json.loads(NwaritGpdjWXDlBuzVsfRFQgIUTKbS.text)
   if 'drm_license_assertion' in NwaritGpdjWXDlBuzVsfRFQgIUTKCk['stream']:
    NwaritGpdjWXDlBuzVsfRFQgIUTKCL =NwaritGpdjWXDlBuzVsfRFQgIUTKCk['stream']['drm_license_assertion']
    NwaritGpdjWXDlBuzVsfRFQgIUTKCP=NwaritGpdjWXDlBuzVsfRFQgIUTKCk['stream']['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in NwaritGpdjWXDlBuzVsfRFQgIUTKCk['stream']['broadcast']):return NwaritGpdjWXDlBuzVsfRFQgIUTKCP,NwaritGpdjWXDlBuzVsfRFQgIUTKCL
    NwaritGpdjWXDlBuzVsfRFQgIUTKCP=NwaritGpdjWXDlBuzVsfRFQgIUTKCk['stream']['broadcast']['broad_url']
  except NwaritGpdjWXDlBuzVsfRFQgIUTKyM as exception:
   NwaritGpdjWXDlBuzVsfRFQgIUTKyP(exception)
  return NwaritGpdjWXDlBuzVsfRFQgIUTKCP,NwaritGpdjWXDlBuzVsfRFQgIUTKCL
 def CheckQuality(NwaritGpdjWXDlBuzVsfRFQgIUTKbM,sel_qt,NwaritGpdjWXDlBuzVsfRFQgIUTKCY):
  for NwaritGpdjWXDlBuzVsfRFQgIUTKeM in NwaritGpdjWXDlBuzVsfRFQgIUTKCY:
   if sel_qt>=NwaritGpdjWXDlBuzVsfRFQgIUTKyv(NwaritGpdjWXDlBuzVsfRFQgIUTKeM)[0]:return NwaritGpdjWXDlBuzVsfRFQgIUTKeM.get(NwaritGpdjWXDlBuzVsfRFQgIUTKyv(NwaritGpdjWXDlBuzVsfRFQgIUTKeM)[0])
   NwaritGpdjWXDlBuzVsfRFQgIUTKey=NwaritGpdjWXDlBuzVsfRFQgIUTKeM.get(NwaritGpdjWXDlBuzVsfRFQgIUTKyv(NwaritGpdjWXDlBuzVsfRFQgIUTKeM)[0])
  return NwaritGpdjWXDlBuzVsfRFQgIUTKey
 def makeOocUrl(NwaritGpdjWXDlBuzVsfRFQgIUTKbM,NwaritGpdjWXDlBuzVsfRFQgIUTKCS):
  NwaritGpdjWXDlBuzVsfRFQgIUTKCx=''
  for NwaritGpdjWXDlBuzVsfRFQgIUTKCc,NwaritGpdjWXDlBuzVsfRFQgIUTKeP in NwaritGpdjWXDlBuzVsfRFQgIUTKCS.items():
   NwaritGpdjWXDlBuzVsfRFQgIUTKCx+="%s=%s^"%(NwaritGpdjWXDlBuzVsfRFQgIUTKCc,NwaritGpdjWXDlBuzVsfRFQgIUTKeP)
  return NwaritGpdjWXDlBuzVsfRFQgIUTKCx
 def GetLiveChannelList(NwaritGpdjWXDlBuzVsfRFQgIUTKbM,stype,page_int):
  NwaritGpdjWXDlBuzVsfRFQgIUTKeL=[]
  NwaritGpdjWXDlBuzVsfRFQgIUTKev=NwaritGpdjWXDlBuzVsfRFQgIUTKyb
  try:
   NwaritGpdjWXDlBuzVsfRFQgIUTKCA ='/v2/media/lives'
   if stype=='onair': 
    NwaritGpdjWXDlBuzVsfRFQgIUTKeJ='CPCS0100,CPCS0400'
   else:
    NwaritGpdjWXDlBuzVsfRFQgIUTKeJ='CPCS0300'
   NwaritGpdjWXDlBuzVsfRFQgIUTKCH=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.GetDefaultParams()
   NwaritGpdjWXDlBuzVsfRFQgIUTKCn={'pageNo':NwaritGpdjWXDlBuzVsfRFQgIUTKyL(page_int),'pageSize':NwaritGpdjWXDlBuzVsfRFQgIUTKyL(NwaritGpdjWXDlBuzVsfRFQgIUTKbM.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':NwaritGpdjWXDlBuzVsfRFQgIUTKeJ,'_':NwaritGpdjWXDlBuzVsfRFQgIUTKyL(NwaritGpdjWXDlBuzVsfRFQgIUTKbM.GetNoCache(2))}
   NwaritGpdjWXDlBuzVsfRFQgIUTKCH.update(NwaritGpdjWXDlBuzVsfRFQgIUTKCn)
   NwaritGpdjWXDlBuzVsfRFQgIUTKCx=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.API_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKCA
   NwaritGpdjWXDlBuzVsfRFQgIUTKbS=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.callRequestCookies('Get',NwaritGpdjWXDlBuzVsfRFQgIUTKCx,payload=NwaritGpdjWXDlBuzVsfRFQgIUTKMq,params=NwaritGpdjWXDlBuzVsfRFQgIUTKCH,headers=NwaritGpdjWXDlBuzVsfRFQgIUTKMq,cookies=NwaritGpdjWXDlBuzVsfRFQgIUTKMq)
   NwaritGpdjWXDlBuzVsfRFQgIUTKCk=json.loads(NwaritGpdjWXDlBuzVsfRFQgIUTKbS.text)
   if not('result' in NwaritGpdjWXDlBuzVsfRFQgIUTKCk['body']):return NwaritGpdjWXDlBuzVsfRFQgIUTKeL,NwaritGpdjWXDlBuzVsfRFQgIUTKev
   NwaritGpdjWXDlBuzVsfRFQgIUTKeA=NwaritGpdjWXDlBuzVsfRFQgIUTKCk['body']['result']
   NwaritGpdjWXDlBuzVsfRFQgIUTKeH=random.randint(0,4)
   for NwaritGpdjWXDlBuzVsfRFQgIUTKCE in NwaritGpdjWXDlBuzVsfRFQgIUTKeA:
    NwaritGpdjWXDlBuzVsfRFQgIUTKen=NwaritGpdjWXDlBuzVsfRFQgIUTKeh=NwaritGpdjWXDlBuzVsfRFQgIUTKeO=''
    NwaritGpdjWXDlBuzVsfRFQgIUTKex=NwaritGpdjWXDlBuzVsfRFQgIUTKmH=''
    NwaritGpdjWXDlBuzVsfRFQgIUTKek=NwaritGpdjWXDlBuzVsfRFQgIUTKCE['live_code']
    NwaritGpdjWXDlBuzVsfRFQgIUTKen =NwaritGpdjWXDlBuzVsfRFQgIUTKCE['schedule']['channel']['name']['ko']
    if NwaritGpdjWXDlBuzVsfRFQgIUTKCE['schedule']['episode']!=NwaritGpdjWXDlBuzVsfRFQgIUTKMq:
     NwaritGpdjWXDlBuzVsfRFQgIUTKeh =NwaritGpdjWXDlBuzVsfRFQgIUTKCE['schedule']['program']['name']['ko']
     NwaritGpdjWXDlBuzVsfRFQgIUTKeh =NwaritGpdjWXDlBuzVsfRFQgIUTKeh+', '+NwaritGpdjWXDlBuzVsfRFQgIUTKyL(NwaritGpdjWXDlBuzVsfRFQgIUTKCE['schedule']['episode']['frequency'])+'회'
     NwaritGpdjWXDlBuzVsfRFQgIUTKeO=NwaritGpdjWXDlBuzVsfRFQgIUTKCE['schedule']['episode']['synopsis']['ko']
    else:
     NwaritGpdjWXDlBuzVsfRFQgIUTKeh =NwaritGpdjWXDlBuzVsfRFQgIUTKCE['schedule']['program']['name']['ko']
     NwaritGpdjWXDlBuzVsfRFQgIUTKeO=NwaritGpdjWXDlBuzVsfRFQgIUTKCE['schedule']['program']['synopsis']['ko']
    try: 
     NwaritGpdjWXDlBuzVsfRFQgIUTKeY =''
     NwaritGpdjWXDlBuzVsfRFQgIUTKeE =''
     NwaritGpdjWXDlBuzVsfRFQgIUTKeo=''
     NwaritGpdjWXDlBuzVsfRFQgIUTKec =''
     NwaritGpdjWXDlBuzVsfRFQgIUTKeS =''
     NwaritGpdjWXDlBuzVsfRFQgIUTKeq =''
     for NwaritGpdjWXDlBuzVsfRFQgIUTKmb in NwaritGpdjWXDlBuzVsfRFQgIUTKCE['schedule']['program']['image']:
      if NwaritGpdjWXDlBuzVsfRFQgIUTKmb['code']=='CAIP0900':NwaritGpdjWXDlBuzVsfRFQgIUTKeE =NwaritGpdjWXDlBuzVsfRFQgIUTKbM.IMG_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKmb['url']
      elif NwaritGpdjWXDlBuzVsfRFQgIUTKmb['code']=='CAIP1800':NwaritGpdjWXDlBuzVsfRFQgIUTKeo=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.IMG_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKmb['url']
      elif NwaritGpdjWXDlBuzVsfRFQgIUTKmb['code']=='CAIP2000':NwaritGpdjWXDlBuzVsfRFQgIUTKec =NwaritGpdjWXDlBuzVsfRFQgIUTKbM.IMG_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKmb['url']
      elif NwaritGpdjWXDlBuzVsfRFQgIUTKmb['code']=='CAIP1900':NwaritGpdjWXDlBuzVsfRFQgIUTKeS =NwaritGpdjWXDlBuzVsfRFQgIUTKbM.IMG_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKmb['url']
      elif NwaritGpdjWXDlBuzVsfRFQgIUTKmb['code']=='CAIP0200':NwaritGpdjWXDlBuzVsfRFQgIUTKeq =NwaritGpdjWXDlBuzVsfRFQgIUTKbM.IMG_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKmb['url']
      elif NwaritGpdjWXDlBuzVsfRFQgIUTKmb['code']=='CAIP0500':NwaritGpdjWXDlBuzVsfRFQgIUTKeY =NwaritGpdjWXDlBuzVsfRFQgIUTKbM.IMG_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKmb['url']
      elif NwaritGpdjWXDlBuzVsfRFQgIUTKmb['code']=='CAIP0800':NwaritGpdjWXDlBuzVsfRFQgIUTKeY =NwaritGpdjWXDlBuzVsfRFQgIUTKbM.IMG_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKmb['url']
     if NwaritGpdjWXDlBuzVsfRFQgIUTKeY=='':
      for NwaritGpdjWXDlBuzVsfRFQgIUTKmb in NwaritGpdjWXDlBuzVsfRFQgIUTKCE['schedule']['channel']['image']:
       if NwaritGpdjWXDlBuzVsfRFQgIUTKmb['code']=='CAIC0400':NwaritGpdjWXDlBuzVsfRFQgIUTKeY =NwaritGpdjWXDlBuzVsfRFQgIUTKbM.IMG_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKmb['url']
       elif NwaritGpdjWXDlBuzVsfRFQgIUTKmb['code']=='CAIC1400':NwaritGpdjWXDlBuzVsfRFQgIUTKeY =NwaritGpdjWXDlBuzVsfRFQgIUTKbM.IMG_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKmb['url']
       elif NwaritGpdjWXDlBuzVsfRFQgIUTKmb['code']=='CAIC1900':NwaritGpdjWXDlBuzVsfRFQgIUTKeY =NwaritGpdjWXDlBuzVsfRFQgIUTKbM.IMG_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKmb['url']
    except:
     NwaritGpdjWXDlBuzVsfRFQgIUTKMq
    try:
     NwaritGpdjWXDlBuzVsfRFQgIUTKmC =[]
     NwaritGpdjWXDlBuzVsfRFQgIUTKme=[]
     NwaritGpdjWXDlBuzVsfRFQgIUTKmM =[]
     NwaritGpdjWXDlBuzVsfRFQgIUTKmy=''
     NwaritGpdjWXDlBuzVsfRFQgIUTKmP=''
     NwaritGpdjWXDlBuzVsfRFQgIUTKmL=''
     for NwaritGpdjWXDlBuzVsfRFQgIUTKmv in NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('schedule').get('program').get('actor'):
      if NwaritGpdjWXDlBuzVsfRFQgIUTKmv!='' and NwaritGpdjWXDlBuzVsfRFQgIUTKmv!=u'없음':NwaritGpdjWXDlBuzVsfRFQgIUTKmC.append(NwaritGpdjWXDlBuzVsfRFQgIUTKmv)
     for NwaritGpdjWXDlBuzVsfRFQgIUTKmJ in NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('schedule').get('program').get('director'):
      if NwaritGpdjWXDlBuzVsfRFQgIUTKmJ!='' and NwaritGpdjWXDlBuzVsfRFQgIUTKmJ!='-' and NwaritGpdjWXDlBuzVsfRFQgIUTKmJ!=u'없음':NwaritGpdjWXDlBuzVsfRFQgIUTKme.append(NwaritGpdjWXDlBuzVsfRFQgIUTKmJ)
     if NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('schedule').get('program').get('category1_name').get('ko')!='':
      NwaritGpdjWXDlBuzVsfRFQgIUTKmM.append(NwaritGpdjWXDlBuzVsfRFQgIUTKCE['schedule']['program']['category1_name']['ko'])
     if NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('schedule').get('program').get('category2_name').get('ko')!='':
      NwaritGpdjWXDlBuzVsfRFQgIUTKmM.append(NwaritGpdjWXDlBuzVsfRFQgIUTKCE['schedule']['program']['category2_name']['ko'])
     if NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('schedule').get('program').get('product_year'):NwaritGpdjWXDlBuzVsfRFQgIUTKmy=NwaritGpdjWXDlBuzVsfRFQgIUTKCE['schedule']['program']['product_year']
     if NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('schedule').get('program').get('grade_code') :NwaritGpdjWXDlBuzVsfRFQgIUTKmP= NwaritGpdjWXDlBuzVsfRFQgIUTKbm.get(NwaritGpdjWXDlBuzVsfRFQgIUTKCE['schedule']['program']['grade_code'])
     if 'broad_dt' in NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('schedule').get('program'):
      NwaritGpdjWXDlBuzVsfRFQgIUTKmA =NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('schedule').get('program').get('broad_dt')
      NwaritGpdjWXDlBuzVsfRFQgIUTKmL='%s-%s-%s'%(NwaritGpdjWXDlBuzVsfRFQgIUTKmA[:4],NwaritGpdjWXDlBuzVsfRFQgIUTKmA[4:6],NwaritGpdjWXDlBuzVsfRFQgIUTKmA[6:])
    except:
     NwaritGpdjWXDlBuzVsfRFQgIUTKMq
    NwaritGpdjWXDlBuzVsfRFQgIUTKex=NwaritGpdjWXDlBuzVsfRFQgIUTKyL(NwaritGpdjWXDlBuzVsfRFQgIUTKCE['schedule']['broadcast_start_time'])[8:12]
    NwaritGpdjWXDlBuzVsfRFQgIUTKmH =NwaritGpdjWXDlBuzVsfRFQgIUTKyL(NwaritGpdjWXDlBuzVsfRFQgIUTKCE['schedule']['broadcast_end_time'])[8:12]
    NwaritGpdjWXDlBuzVsfRFQgIUTKmn={'channel':NwaritGpdjWXDlBuzVsfRFQgIUTKen,'title':NwaritGpdjWXDlBuzVsfRFQgIUTKeh,'mediacode':NwaritGpdjWXDlBuzVsfRFQgIUTKek,'thumbnail':{'poster':NwaritGpdjWXDlBuzVsfRFQgIUTKeE,'thumb':NwaritGpdjWXDlBuzVsfRFQgIUTKeY,'clearlogo':NwaritGpdjWXDlBuzVsfRFQgIUTKeo,'icon':NwaritGpdjWXDlBuzVsfRFQgIUTKec,'fanart':NwaritGpdjWXDlBuzVsfRFQgIUTKeq},'synopsis':NwaritGpdjWXDlBuzVsfRFQgIUTKeO,'channelepg':' [%s:%s ~ %s:%s]'%(NwaritGpdjWXDlBuzVsfRFQgIUTKex[0:2],NwaritGpdjWXDlBuzVsfRFQgIUTKex[2:],NwaritGpdjWXDlBuzVsfRFQgIUTKmH[0:2],NwaritGpdjWXDlBuzVsfRFQgIUTKmH[2:]),'cast':NwaritGpdjWXDlBuzVsfRFQgIUTKmC,'director':NwaritGpdjWXDlBuzVsfRFQgIUTKme,'info_genre':NwaritGpdjWXDlBuzVsfRFQgIUTKmM,'year':NwaritGpdjWXDlBuzVsfRFQgIUTKmy,'mpaa':NwaritGpdjWXDlBuzVsfRFQgIUTKmP,'premiered':NwaritGpdjWXDlBuzVsfRFQgIUTKmL}
    NwaritGpdjWXDlBuzVsfRFQgIUTKeL.append(NwaritGpdjWXDlBuzVsfRFQgIUTKmn)
   if NwaritGpdjWXDlBuzVsfRFQgIUTKCk['body']['has_more']=='Y':NwaritGpdjWXDlBuzVsfRFQgIUTKev=NwaritGpdjWXDlBuzVsfRFQgIUTKym
  except NwaritGpdjWXDlBuzVsfRFQgIUTKyM as exception:
   NwaritGpdjWXDlBuzVsfRFQgIUTKyP(exception)
  return NwaritGpdjWXDlBuzVsfRFQgIUTKeL,NwaritGpdjWXDlBuzVsfRFQgIUTKev
 def GetProgramList(NwaritGpdjWXDlBuzVsfRFQgIUTKbM,genre,orderby,page_int,genreCode='all'):
  NwaritGpdjWXDlBuzVsfRFQgIUTKeL=[]
  NwaritGpdjWXDlBuzVsfRFQgIUTKev=NwaritGpdjWXDlBuzVsfRFQgIUTKyb
  try:
   NwaritGpdjWXDlBuzVsfRFQgIUTKCA ='/v2/media/episodes'
   NwaritGpdjWXDlBuzVsfRFQgIUTKCH=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.GetDefaultParams()
   NwaritGpdjWXDlBuzVsfRFQgIUTKCn={'pageNo':NwaritGpdjWXDlBuzVsfRFQgIUTKyL(page_int),'pageSize':NwaritGpdjWXDlBuzVsfRFQgIUTKyL(NwaritGpdjWXDlBuzVsfRFQgIUTKbM.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','_':NwaritGpdjWXDlBuzVsfRFQgIUTKyL(NwaritGpdjWXDlBuzVsfRFQgIUTKbM.GetNoCache(2))}
   if genre !='all':NwaritGpdjWXDlBuzVsfRFQgIUTKCn['categoryCode']=genre
   if genreCode!='all':NwaritGpdjWXDlBuzVsfRFQgIUTKCn['genreCode'] =genreCode 
   NwaritGpdjWXDlBuzVsfRFQgIUTKCH.update(NwaritGpdjWXDlBuzVsfRFQgIUTKCn)
   NwaritGpdjWXDlBuzVsfRFQgIUTKCx=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.API_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKCA
   NwaritGpdjWXDlBuzVsfRFQgIUTKbS=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.callRequestCookies('Get',NwaritGpdjWXDlBuzVsfRFQgIUTKCx,payload=NwaritGpdjWXDlBuzVsfRFQgIUTKMq,params=NwaritGpdjWXDlBuzVsfRFQgIUTKCH,headers=NwaritGpdjWXDlBuzVsfRFQgIUTKMq,cookies=NwaritGpdjWXDlBuzVsfRFQgIUTKMq)
   NwaritGpdjWXDlBuzVsfRFQgIUTKCk=json.loads(NwaritGpdjWXDlBuzVsfRFQgIUTKbS.text)
   if not('result' in NwaritGpdjWXDlBuzVsfRFQgIUTKCk['body']):return NwaritGpdjWXDlBuzVsfRFQgIUTKeL,NwaritGpdjWXDlBuzVsfRFQgIUTKev
   NwaritGpdjWXDlBuzVsfRFQgIUTKeA=NwaritGpdjWXDlBuzVsfRFQgIUTKCk['body']['result']
   for NwaritGpdjWXDlBuzVsfRFQgIUTKCE in NwaritGpdjWXDlBuzVsfRFQgIUTKeA:
    NwaritGpdjWXDlBuzVsfRFQgIUTKmx=NwaritGpdjWXDlBuzVsfRFQgIUTKCE['program']['code']
    NwaritGpdjWXDlBuzVsfRFQgIUTKeh =NwaritGpdjWXDlBuzVsfRFQgIUTKCE['program']['name']['ko']
    NwaritGpdjWXDlBuzVsfRFQgIUTKmP =NwaritGpdjWXDlBuzVsfRFQgIUTKbm.get(NwaritGpdjWXDlBuzVsfRFQgIUTKCE['program'].get('grade_code'))
    NwaritGpdjWXDlBuzVsfRFQgIUTKeE =''
    NwaritGpdjWXDlBuzVsfRFQgIUTKeY =''
    NwaritGpdjWXDlBuzVsfRFQgIUTKeo=''
    NwaritGpdjWXDlBuzVsfRFQgIUTKec =''
    NwaritGpdjWXDlBuzVsfRFQgIUTKeS =''
    for NwaritGpdjWXDlBuzVsfRFQgIUTKmb in NwaritGpdjWXDlBuzVsfRFQgIUTKCE['program']['image']:
     if NwaritGpdjWXDlBuzVsfRFQgIUTKmb['code']=='CAIP0900':NwaritGpdjWXDlBuzVsfRFQgIUTKeE =NwaritGpdjWXDlBuzVsfRFQgIUTKbM.IMG_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKmb['url']
     elif NwaritGpdjWXDlBuzVsfRFQgIUTKmb['code']=='CAIP0200':NwaritGpdjWXDlBuzVsfRFQgIUTKeY =NwaritGpdjWXDlBuzVsfRFQgIUTKbM.IMG_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKmb['url']
     elif NwaritGpdjWXDlBuzVsfRFQgIUTKmb['code']=='CAIP1800':NwaritGpdjWXDlBuzVsfRFQgIUTKeo=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.IMG_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKmb['url']
     elif NwaritGpdjWXDlBuzVsfRFQgIUTKmb['code']=='CAIP2000':NwaritGpdjWXDlBuzVsfRFQgIUTKec =NwaritGpdjWXDlBuzVsfRFQgIUTKbM.IMG_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKmb['url']
     elif NwaritGpdjWXDlBuzVsfRFQgIUTKmb['code']=='CAIP1900':NwaritGpdjWXDlBuzVsfRFQgIUTKeS =NwaritGpdjWXDlBuzVsfRFQgIUTKbM.IMG_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKmb['url']
    NwaritGpdjWXDlBuzVsfRFQgIUTKeO =NwaritGpdjWXDlBuzVsfRFQgIUTKCE['program']['synopsis']['ko']
    try:
     NwaritGpdjWXDlBuzVsfRFQgIUTKmk=NwaritGpdjWXDlBuzVsfRFQgIUTKCE['channel']['name']['ko']
    except:
     NwaritGpdjWXDlBuzVsfRFQgIUTKmk=''
    try:
     NwaritGpdjWXDlBuzVsfRFQgIUTKmC =[]
     NwaritGpdjWXDlBuzVsfRFQgIUTKme=[]
     NwaritGpdjWXDlBuzVsfRFQgIUTKmM =[]
     NwaritGpdjWXDlBuzVsfRFQgIUTKmy =''
     NwaritGpdjWXDlBuzVsfRFQgIUTKmL=''
     for NwaritGpdjWXDlBuzVsfRFQgIUTKmv in NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('program').get('actor'):
      if NwaritGpdjWXDlBuzVsfRFQgIUTKmv!='' and NwaritGpdjWXDlBuzVsfRFQgIUTKmv!='-' and NwaritGpdjWXDlBuzVsfRFQgIUTKmv!=u'없음':NwaritGpdjWXDlBuzVsfRFQgIUTKmC.append(NwaritGpdjWXDlBuzVsfRFQgIUTKmv)
     for NwaritGpdjWXDlBuzVsfRFQgIUTKmJ in NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('program').get('director'):
      if NwaritGpdjWXDlBuzVsfRFQgIUTKmJ!='' and NwaritGpdjWXDlBuzVsfRFQgIUTKmJ!='-' and NwaritGpdjWXDlBuzVsfRFQgIUTKmJ!=u'없음':NwaritGpdjWXDlBuzVsfRFQgIUTKme.append(NwaritGpdjWXDlBuzVsfRFQgIUTKmJ)
     if NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('program').get('category1_name').get('ko')!='':
      NwaritGpdjWXDlBuzVsfRFQgIUTKmM.append(NwaritGpdjWXDlBuzVsfRFQgIUTKCE['program']['category1_name']['ko'])
     if NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('program').get('category2_name').get('ko')!='':
      NwaritGpdjWXDlBuzVsfRFQgIUTKmM.append(NwaritGpdjWXDlBuzVsfRFQgIUTKCE['program']['category2_name']['ko'])
     if NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('program').get('product_year'):NwaritGpdjWXDlBuzVsfRFQgIUTKmy=NwaritGpdjWXDlBuzVsfRFQgIUTKCE['program']['product_year']
     if 'broad_dt' in NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('program'):
      NwaritGpdjWXDlBuzVsfRFQgIUTKmA =NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('program').get('broad_dt')
      NwaritGpdjWXDlBuzVsfRFQgIUTKmL='%s-%s-%s'%(NwaritGpdjWXDlBuzVsfRFQgIUTKmA[:4],NwaritGpdjWXDlBuzVsfRFQgIUTKmA[4:6],NwaritGpdjWXDlBuzVsfRFQgIUTKmA[6:])
    except:
     NwaritGpdjWXDlBuzVsfRFQgIUTKMq
    NwaritGpdjWXDlBuzVsfRFQgIUTKmn={'program':NwaritGpdjWXDlBuzVsfRFQgIUTKmx,'title':NwaritGpdjWXDlBuzVsfRFQgIUTKeh,'thumbnail':{'poster':NwaritGpdjWXDlBuzVsfRFQgIUTKeE,'thumb':NwaritGpdjWXDlBuzVsfRFQgIUTKeY,'clearlogo':NwaritGpdjWXDlBuzVsfRFQgIUTKeo,'icon':NwaritGpdjWXDlBuzVsfRFQgIUTKec,'banner':NwaritGpdjWXDlBuzVsfRFQgIUTKeS,'fanart':NwaritGpdjWXDlBuzVsfRFQgIUTKeY},'synopsis':NwaritGpdjWXDlBuzVsfRFQgIUTKeO,'channel':NwaritGpdjWXDlBuzVsfRFQgIUTKmk,'cast':NwaritGpdjWXDlBuzVsfRFQgIUTKmC,'director':NwaritGpdjWXDlBuzVsfRFQgIUTKme,'info_genre':NwaritGpdjWXDlBuzVsfRFQgIUTKmM,'year':NwaritGpdjWXDlBuzVsfRFQgIUTKmy,'premiered':NwaritGpdjWXDlBuzVsfRFQgIUTKmL,'mpaa':NwaritGpdjWXDlBuzVsfRFQgIUTKmP}
    NwaritGpdjWXDlBuzVsfRFQgIUTKeL.append(NwaritGpdjWXDlBuzVsfRFQgIUTKmn)
   if NwaritGpdjWXDlBuzVsfRFQgIUTKCk['body']['has_more']=='Y':NwaritGpdjWXDlBuzVsfRFQgIUTKev=NwaritGpdjWXDlBuzVsfRFQgIUTKym
  except NwaritGpdjWXDlBuzVsfRFQgIUTKyM as exception:
   NwaritGpdjWXDlBuzVsfRFQgIUTKyP(exception)
  return NwaritGpdjWXDlBuzVsfRFQgIUTKeL,NwaritGpdjWXDlBuzVsfRFQgIUTKev
 def GetEpisodeList(NwaritGpdjWXDlBuzVsfRFQgIUTKbM,program_code,page_int,orderby='desc'):
  NwaritGpdjWXDlBuzVsfRFQgIUTKeL=[]
  NwaritGpdjWXDlBuzVsfRFQgIUTKev=NwaritGpdjWXDlBuzVsfRFQgIUTKyb
  try:
   NwaritGpdjWXDlBuzVsfRFQgIUTKCA ='/v2/media/frequency/program/'+program_code
   NwaritGpdjWXDlBuzVsfRFQgIUTKCH=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.GetDefaultParams()
   NwaritGpdjWXDlBuzVsfRFQgIUTKCn={'pageNo':'1','pageSize':'10','order':'new','free':'all','adult':'all','scope':'all','_':NwaritGpdjWXDlBuzVsfRFQgIUTKyL(NwaritGpdjWXDlBuzVsfRFQgIUTKbM.GetNoCache(2))}
   NwaritGpdjWXDlBuzVsfRFQgIUTKCH.update(NwaritGpdjWXDlBuzVsfRFQgIUTKCn)
   NwaritGpdjWXDlBuzVsfRFQgIUTKCx=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.API_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKCA
   NwaritGpdjWXDlBuzVsfRFQgIUTKbS=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.callRequestCookies('Get',NwaritGpdjWXDlBuzVsfRFQgIUTKCx,payload=NwaritGpdjWXDlBuzVsfRFQgIUTKMq,params=NwaritGpdjWXDlBuzVsfRFQgIUTKCH,headers=NwaritGpdjWXDlBuzVsfRFQgIUTKMq,cookies=NwaritGpdjWXDlBuzVsfRFQgIUTKMq)
   NwaritGpdjWXDlBuzVsfRFQgIUTKCk=json.loads(NwaritGpdjWXDlBuzVsfRFQgIUTKbS.text)
   if not('result' in NwaritGpdjWXDlBuzVsfRFQgIUTKCk['body']):return NwaritGpdjWXDlBuzVsfRFQgIUTKeL,NwaritGpdjWXDlBuzVsfRFQgIUTKev
   NwaritGpdjWXDlBuzVsfRFQgIUTKeA=NwaritGpdjWXDlBuzVsfRFQgIUTKCk['body']['result']
   NwaritGpdjWXDlBuzVsfRFQgIUTKmh=NwaritGpdjWXDlBuzVsfRFQgIUTKyC(NwaritGpdjWXDlBuzVsfRFQgIUTKCk['body']['total_count'])
   NwaritGpdjWXDlBuzVsfRFQgIUTKmO =NwaritGpdjWXDlBuzVsfRFQgIUTKyC(NwaritGpdjWXDlBuzVsfRFQgIUTKmh//(NwaritGpdjWXDlBuzVsfRFQgIUTKbM.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    NwaritGpdjWXDlBuzVsfRFQgIUTKmY =(NwaritGpdjWXDlBuzVsfRFQgIUTKmh-1)-((page_int-1)*NwaritGpdjWXDlBuzVsfRFQgIUTKbM.EPISODE_LIMIT)
   else:
    NwaritGpdjWXDlBuzVsfRFQgIUTKmY =(page_int-1)*NwaritGpdjWXDlBuzVsfRFQgIUTKbM.EPISODE_LIMIT
   for i in NwaritGpdjWXDlBuzVsfRFQgIUTKye(NwaritGpdjWXDlBuzVsfRFQgIUTKbM.EPISODE_LIMIT):
    if orderby=='desc':
     NwaritGpdjWXDlBuzVsfRFQgIUTKmE=NwaritGpdjWXDlBuzVsfRFQgIUTKmY-i
     if NwaritGpdjWXDlBuzVsfRFQgIUTKmE<0:break
    else:
     NwaritGpdjWXDlBuzVsfRFQgIUTKmE=NwaritGpdjWXDlBuzVsfRFQgIUTKmY+i
     if NwaritGpdjWXDlBuzVsfRFQgIUTKmE>=NwaritGpdjWXDlBuzVsfRFQgIUTKmh:break
    NwaritGpdjWXDlBuzVsfRFQgIUTKmo=NwaritGpdjWXDlBuzVsfRFQgIUTKeA[NwaritGpdjWXDlBuzVsfRFQgIUTKmE]['episode']['code']
    NwaritGpdjWXDlBuzVsfRFQgIUTKeh =NwaritGpdjWXDlBuzVsfRFQgIUTKeA[NwaritGpdjWXDlBuzVsfRFQgIUTKmE]['vod_name']['ko']
    NwaritGpdjWXDlBuzVsfRFQgIUTKmc =''
    try:
     NwaritGpdjWXDlBuzVsfRFQgIUTKmA=NwaritGpdjWXDlBuzVsfRFQgIUTKyL(NwaritGpdjWXDlBuzVsfRFQgIUTKeA[NwaritGpdjWXDlBuzVsfRFQgIUTKmE]['episode']['broadcast_date'])
     NwaritGpdjWXDlBuzVsfRFQgIUTKmc='%s-%s-%s'%(NwaritGpdjWXDlBuzVsfRFQgIUTKmA[:4],NwaritGpdjWXDlBuzVsfRFQgIUTKmA[4:6],NwaritGpdjWXDlBuzVsfRFQgIUTKmA[6:])
    except:
     NwaritGpdjWXDlBuzVsfRFQgIUTKMq
    NwaritGpdjWXDlBuzVsfRFQgIUTKeO =NwaritGpdjWXDlBuzVsfRFQgIUTKeA[NwaritGpdjWXDlBuzVsfRFQgIUTKmE]['episode']['synopsis']['ko']
    NwaritGpdjWXDlBuzVsfRFQgIUTKeE =''
    NwaritGpdjWXDlBuzVsfRFQgIUTKeY =''
    NwaritGpdjWXDlBuzVsfRFQgIUTKeo=''
    NwaritGpdjWXDlBuzVsfRFQgIUTKec =''
    NwaritGpdjWXDlBuzVsfRFQgIUTKeS =''
    NwaritGpdjWXDlBuzVsfRFQgIUTKeq =''
    for NwaritGpdjWXDlBuzVsfRFQgIUTKmb in NwaritGpdjWXDlBuzVsfRFQgIUTKeA[NwaritGpdjWXDlBuzVsfRFQgIUTKmE]['program']['image']:
     if NwaritGpdjWXDlBuzVsfRFQgIUTKmb['code']=='CAIP0900':NwaritGpdjWXDlBuzVsfRFQgIUTKeE =NwaritGpdjWXDlBuzVsfRFQgIUTKbM.IMG_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKmb['url']
     elif NwaritGpdjWXDlBuzVsfRFQgIUTKmb['code']=='CAIP1800':NwaritGpdjWXDlBuzVsfRFQgIUTKeo=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.IMG_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKmb['url']
     elif NwaritGpdjWXDlBuzVsfRFQgIUTKmb['code']=='CAIP2000':NwaritGpdjWXDlBuzVsfRFQgIUTKec =NwaritGpdjWXDlBuzVsfRFQgIUTKbM.IMG_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKmb['url']
     elif NwaritGpdjWXDlBuzVsfRFQgIUTKmb['code']=='CAIP1900':NwaritGpdjWXDlBuzVsfRFQgIUTKeS =NwaritGpdjWXDlBuzVsfRFQgIUTKbM.IMG_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKmb['url']
     elif NwaritGpdjWXDlBuzVsfRFQgIUTKmb['code']=='CAIP0200':NwaritGpdjWXDlBuzVsfRFQgIUTKeq =NwaritGpdjWXDlBuzVsfRFQgIUTKbM.IMG_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKmb['url']
    for NwaritGpdjWXDlBuzVsfRFQgIUTKmb in NwaritGpdjWXDlBuzVsfRFQgIUTKeA[NwaritGpdjWXDlBuzVsfRFQgIUTKmE]['episode']['image']:
     if NwaritGpdjWXDlBuzVsfRFQgIUTKmb['code']=='CAIE0400':NwaritGpdjWXDlBuzVsfRFQgIUTKeY =NwaritGpdjWXDlBuzVsfRFQgIUTKbM.IMG_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKmb['url']
    try:
     NwaritGpdjWXDlBuzVsfRFQgIUTKmS=NwaritGpdjWXDlBuzVsfRFQgIUTKMb=NwaritGpdjWXDlBuzVsfRFQgIUTKMC=''
     NwaritGpdjWXDlBuzVsfRFQgIUTKmq=0
     NwaritGpdjWXDlBuzVsfRFQgIUTKmS =NwaritGpdjWXDlBuzVsfRFQgIUTKeA[NwaritGpdjWXDlBuzVsfRFQgIUTKmE]['program']['name']['ko']
     NwaritGpdjWXDlBuzVsfRFQgIUTKMb =NwaritGpdjWXDlBuzVsfRFQgIUTKmc
     NwaritGpdjWXDlBuzVsfRFQgIUTKMC =NwaritGpdjWXDlBuzVsfRFQgIUTKeA[NwaritGpdjWXDlBuzVsfRFQgIUTKmE]['channel']['name']['ko']
     if 'frequency' in NwaritGpdjWXDlBuzVsfRFQgIUTKeA[NwaritGpdjWXDlBuzVsfRFQgIUTKmE]['episode']:NwaritGpdjWXDlBuzVsfRFQgIUTKmq=NwaritGpdjWXDlBuzVsfRFQgIUTKeA[NwaritGpdjWXDlBuzVsfRFQgIUTKmE]['episode']['frequency']
    except:
     NwaritGpdjWXDlBuzVsfRFQgIUTKMq
    NwaritGpdjWXDlBuzVsfRFQgIUTKmn={'episode':NwaritGpdjWXDlBuzVsfRFQgIUTKmo,'title':NwaritGpdjWXDlBuzVsfRFQgIUTKeh,'subtitle':NwaritGpdjWXDlBuzVsfRFQgIUTKmc,'thumbnail':{'poster':NwaritGpdjWXDlBuzVsfRFQgIUTKeE,'thumb':NwaritGpdjWXDlBuzVsfRFQgIUTKeY,'clearlogo':NwaritGpdjWXDlBuzVsfRFQgIUTKeo,'icon':NwaritGpdjWXDlBuzVsfRFQgIUTKec,'banner':NwaritGpdjWXDlBuzVsfRFQgIUTKeS,'fanart':NwaritGpdjWXDlBuzVsfRFQgIUTKeq},'synopsis':NwaritGpdjWXDlBuzVsfRFQgIUTKeO,'info_title':NwaritGpdjWXDlBuzVsfRFQgIUTKmS,'aired':NwaritGpdjWXDlBuzVsfRFQgIUTKMb,'studio':NwaritGpdjWXDlBuzVsfRFQgIUTKMC,'frequency':NwaritGpdjWXDlBuzVsfRFQgIUTKmq}
    NwaritGpdjWXDlBuzVsfRFQgIUTKeL.append(NwaritGpdjWXDlBuzVsfRFQgIUTKmn)
   if NwaritGpdjWXDlBuzVsfRFQgIUTKmO>page_int:NwaritGpdjWXDlBuzVsfRFQgIUTKev=NwaritGpdjWXDlBuzVsfRFQgIUTKym
  except NwaritGpdjWXDlBuzVsfRFQgIUTKyM as exception:
   NwaritGpdjWXDlBuzVsfRFQgIUTKyP(exception)
  return NwaritGpdjWXDlBuzVsfRFQgIUTKeL,NwaritGpdjWXDlBuzVsfRFQgIUTKev,NwaritGpdjWXDlBuzVsfRFQgIUTKmO
 def GetMovieList(NwaritGpdjWXDlBuzVsfRFQgIUTKbM,genre,orderby,page_int):
  NwaritGpdjWXDlBuzVsfRFQgIUTKeL=[]
  NwaritGpdjWXDlBuzVsfRFQgIUTKev=NwaritGpdjWXDlBuzVsfRFQgIUTKyb
  try:
   NwaritGpdjWXDlBuzVsfRFQgIUTKCA ='/v2/media/movies'
   NwaritGpdjWXDlBuzVsfRFQgIUTKCH=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.GetDefaultParams()
   NwaritGpdjWXDlBuzVsfRFQgIUTKCn={'pageNo':NwaritGpdjWXDlBuzVsfRFQgIUTKyL(page_int),'pageSize':NwaritGpdjWXDlBuzVsfRFQgIUTKyL(NwaritGpdjWXDlBuzVsfRFQgIUTKbM.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','_':NwaritGpdjWXDlBuzVsfRFQgIUTKyL(NwaritGpdjWXDlBuzVsfRFQgIUTKbM.GetNoCache(2))}
   if genre!='all' :NwaritGpdjWXDlBuzVsfRFQgIUTKCn['multiCategoryCode']=genre
   if orderby=='new':NwaritGpdjWXDlBuzVsfRFQgIUTKCn['productPackageCode']=','.join(NwaritGpdjWXDlBuzVsfRFQgIUTKbM.MOVIE_LITE)
   NwaritGpdjWXDlBuzVsfRFQgIUTKCH.update(NwaritGpdjWXDlBuzVsfRFQgIUTKCn)
   NwaritGpdjWXDlBuzVsfRFQgIUTKCx=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.API_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKCA
   NwaritGpdjWXDlBuzVsfRFQgIUTKbS=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.callRequestCookies('Get',NwaritGpdjWXDlBuzVsfRFQgIUTKCx,payload=NwaritGpdjWXDlBuzVsfRFQgIUTKMq,params=NwaritGpdjWXDlBuzVsfRFQgIUTKCH,headers=NwaritGpdjWXDlBuzVsfRFQgIUTKMq,cookies=NwaritGpdjWXDlBuzVsfRFQgIUTKMq)
   NwaritGpdjWXDlBuzVsfRFQgIUTKCk=json.loads(NwaritGpdjWXDlBuzVsfRFQgIUTKbS.text)
   if not('result' in NwaritGpdjWXDlBuzVsfRFQgIUTKCk['body']):return NwaritGpdjWXDlBuzVsfRFQgIUTKeL,NwaritGpdjWXDlBuzVsfRFQgIUTKev
   NwaritGpdjWXDlBuzVsfRFQgIUTKeA=NwaritGpdjWXDlBuzVsfRFQgIUTKCk['body']['result']
   for NwaritGpdjWXDlBuzVsfRFQgIUTKCE in NwaritGpdjWXDlBuzVsfRFQgIUTKeA:
    NwaritGpdjWXDlBuzVsfRFQgIUTKMe =NwaritGpdjWXDlBuzVsfRFQgIUTKCE['movie']['code']
    NwaritGpdjWXDlBuzVsfRFQgIUTKeh =NwaritGpdjWXDlBuzVsfRFQgIUTKCE['movie']['name']['ko'].strip()
    NwaritGpdjWXDlBuzVsfRFQgIUTKeh +=u' (%s년)'%(NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('movie').get('product_year'))
    NwaritGpdjWXDlBuzVsfRFQgIUTKeE=''
    NwaritGpdjWXDlBuzVsfRFQgIUTKeY =''
    NwaritGpdjWXDlBuzVsfRFQgIUTKeo=''
    for NwaritGpdjWXDlBuzVsfRFQgIUTKmb in NwaritGpdjWXDlBuzVsfRFQgIUTKCE['movie']['image']:
     if NwaritGpdjWXDlBuzVsfRFQgIUTKmb['code']=='CAIM2100':NwaritGpdjWXDlBuzVsfRFQgIUTKeE =NwaritGpdjWXDlBuzVsfRFQgIUTKbM.IMG_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKmb['url']
     elif NwaritGpdjWXDlBuzVsfRFQgIUTKmb['code']=='CAIM0400':NwaritGpdjWXDlBuzVsfRFQgIUTKeY =NwaritGpdjWXDlBuzVsfRFQgIUTKbM.IMG_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKmb['url']
     elif NwaritGpdjWXDlBuzVsfRFQgIUTKmb['code']=='CAIM1800':NwaritGpdjWXDlBuzVsfRFQgIUTKeo=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.IMG_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKmb['url']
    NwaritGpdjWXDlBuzVsfRFQgIUTKeO =NwaritGpdjWXDlBuzVsfRFQgIUTKCE['movie']['story']['ko']
    try:
     NwaritGpdjWXDlBuzVsfRFQgIUTKmS =NwaritGpdjWXDlBuzVsfRFQgIUTKCE['movie']['name']['ko'].strip()
     NwaritGpdjWXDlBuzVsfRFQgIUTKmy =NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('movie').get('product_year')
     NwaritGpdjWXDlBuzVsfRFQgIUTKmP =NwaritGpdjWXDlBuzVsfRFQgIUTKbm.get(NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('grade_code'))
     NwaritGpdjWXDlBuzVsfRFQgIUTKmC=[]
     NwaritGpdjWXDlBuzVsfRFQgIUTKme=[]
     NwaritGpdjWXDlBuzVsfRFQgIUTKmM=[]
     NwaritGpdjWXDlBuzVsfRFQgIUTKMm=0
     NwaritGpdjWXDlBuzVsfRFQgIUTKmL=''
     NwaritGpdjWXDlBuzVsfRFQgIUTKMC =''
     for NwaritGpdjWXDlBuzVsfRFQgIUTKmv in NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('movie').get('actor'):
      if NwaritGpdjWXDlBuzVsfRFQgIUTKmv!='':NwaritGpdjWXDlBuzVsfRFQgIUTKmC.append(NwaritGpdjWXDlBuzVsfRFQgIUTKmv)
     for NwaritGpdjWXDlBuzVsfRFQgIUTKmJ in NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('movie').get('director'):
      if NwaritGpdjWXDlBuzVsfRFQgIUTKmJ!='':NwaritGpdjWXDlBuzVsfRFQgIUTKme.append(NwaritGpdjWXDlBuzVsfRFQgIUTKmJ)
     if NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('movie').get('category1_name').get('ko')!='':
      NwaritGpdjWXDlBuzVsfRFQgIUTKmM.append(NwaritGpdjWXDlBuzVsfRFQgIUTKCE['movie']['category1_name']['ko'])
     if NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('movie').get('category2_name').get('ko')!='':
      NwaritGpdjWXDlBuzVsfRFQgIUTKmM.append(NwaritGpdjWXDlBuzVsfRFQgIUTKCE['movie']['category2_name']['ko'])
     if 'duration' in NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('movie'):NwaritGpdjWXDlBuzVsfRFQgIUTKMm=NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('movie').get('duration')
     if 'release_date' in NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('movie'):
      NwaritGpdjWXDlBuzVsfRFQgIUTKmA=NwaritGpdjWXDlBuzVsfRFQgIUTKyL(NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('movie').get('release_date'))
      if NwaritGpdjWXDlBuzVsfRFQgIUTKmA!='0':NwaritGpdjWXDlBuzVsfRFQgIUTKmL='%s-%s-%s'%(NwaritGpdjWXDlBuzVsfRFQgIUTKmA[:4],NwaritGpdjWXDlBuzVsfRFQgIUTKmA[4:6],NwaritGpdjWXDlBuzVsfRFQgIUTKmA[6:])
     if 'production' in NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('movie'):NwaritGpdjWXDlBuzVsfRFQgIUTKMC=NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('movie').get('production')
    except:
     NwaritGpdjWXDlBuzVsfRFQgIUTKMq
    NwaritGpdjWXDlBuzVsfRFQgIUTKmn={'moviecode':NwaritGpdjWXDlBuzVsfRFQgIUTKMe,'title':NwaritGpdjWXDlBuzVsfRFQgIUTKeh,'thumbnail':{'poster':NwaritGpdjWXDlBuzVsfRFQgIUTKeE,'thumb':NwaritGpdjWXDlBuzVsfRFQgIUTKeY,'clearlogo':NwaritGpdjWXDlBuzVsfRFQgIUTKeo,'fanart':NwaritGpdjWXDlBuzVsfRFQgIUTKeY},'synopsis':NwaritGpdjWXDlBuzVsfRFQgIUTKeO,'info_title':NwaritGpdjWXDlBuzVsfRFQgIUTKmS,'year':NwaritGpdjWXDlBuzVsfRFQgIUTKmy,'cast':NwaritGpdjWXDlBuzVsfRFQgIUTKmC,'director':NwaritGpdjWXDlBuzVsfRFQgIUTKme,'info_genre':NwaritGpdjWXDlBuzVsfRFQgIUTKmM,'duration':NwaritGpdjWXDlBuzVsfRFQgIUTKMm,'premiered':NwaritGpdjWXDlBuzVsfRFQgIUTKmL,'studio':NwaritGpdjWXDlBuzVsfRFQgIUTKMC,'mpaa':NwaritGpdjWXDlBuzVsfRFQgIUTKmP}
    NwaritGpdjWXDlBuzVsfRFQgIUTKMy=NwaritGpdjWXDlBuzVsfRFQgIUTKyb
    for NwaritGpdjWXDlBuzVsfRFQgIUTKMP in NwaritGpdjWXDlBuzVsfRFQgIUTKCE['billing_package_id']:
     if NwaritGpdjWXDlBuzVsfRFQgIUTKMP in NwaritGpdjWXDlBuzVsfRFQgIUTKbM.MOVIE_LITE:
      NwaritGpdjWXDlBuzVsfRFQgIUTKMy=NwaritGpdjWXDlBuzVsfRFQgIUTKym
      break
    if NwaritGpdjWXDlBuzVsfRFQgIUTKMy==NwaritGpdjWXDlBuzVsfRFQgIUTKyb: 
     NwaritGpdjWXDlBuzVsfRFQgIUTKmn['title']=NwaritGpdjWXDlBuzVsfRFQgIUTKmn['title']+' [개별구매]'
    NwaritGpdjWXDlBuzVsfRFQgIUTKeL.append(NwaritGpdjWXDlBuzVsfRFQgIUTKmn)
   if NwaritGpdjWXDlBuzVsfRFQgIUTKCk['body']['has_more']=='Y':NwaritGpdjWXDlBuzVsfRFQgIUTKev=NwaritGpdjWXDlBuzVsfRFQgIUTKym
  except NwaritGpdjWXDlBuzVsfRFQgIUTKyM as exception:
   NwaritGpdjWXDlBuzVsfRFQgIUTKyP(exception)
  return NwaritGpdjWXDlBuzVsfRFQgIUTKeL,NwaritGpdjWXDlBuzVsfRFQgIUTKev
 def GetMovieListGenre(NwaritGpdjWXDlBuzVsfRFQgIUTKbM,genre,page_int):
  NwaritGpdjWXDlBuzVsfRFQgIUTKeL=[]
  NwaritGpdjWXDlBuzVsfRFQgIUTKev=NwaritGpdjWXDlBuzVsfRFQgIUTKyb
  try:
   NwaritGpdjWXDlBuzVsfRFQgIUTKCA ='/v2/media/movie/curation/'+genre
   NwaritGpdjWXDlBuzVsfRFQgIUTKCH=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.GetDefaultParams()
   NwaritGpdjWXDlBuzVsfRFQgIUTKCn={'pageNo':NwaritGpdjWXDlBuzVsfRFQgIUTKyL(page_int),'pageSize':NwaritGpdjWXDlBuzVsfRFQgIUTKyL(NwaritGpdjWXDlBuzVsfRFQgIUTKbM.MOVIE_LIMIT),'_':NwaritGpdjWXDlBuzVsfRFQgIUTKyL(NwaritGpdjWXDlBuzVsfRFQgIUTKbM.GetNoCache(2))}
   NwaritGpdjWXDlBuzVsfRFQgIUTKCH.update(NwaritGpdjWXDlBuzVsfRFQgIUTKCn)
   NwaritGpdjWXDlBuzVsfRFQgIUTKCx=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.API_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKCA
   NwaritGpdjWXDlBuzVsfRFQgIUTKbS=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.callRequestCookies('Get',NwaritGpdjWXDlBuzVsfRFQgIUTKCx,payload=NwaritGpdjWXDlBuzVsfRFQgIUTKMq,params=NwaritGpdjWXDlBuzVsfRFQgIUTKCH,headers=NwaritGpdjWXDlBuzVsfRFQgIUTKMq,cookies=NwaritGpdjWXDlBuzVsfRFQgIUTKMq)
   NwaritGpdjWXDlBuzVsfRFQgIUTKCk=json.loads(NwaritGpdjWXDlBuzVsfRFQgIUTKbS.text)
   if not('movies' in NwaritGpdjWXDlBuzVsfRFQgIUTKCk['body']):return NwaritGpdjWXDlBuzVsfRFQgIUTKeL,NwaritGpdjWXDlBuzVsfRFQgIUTKev
   NwaritGpdjWXDlBuzVsfRFQgIUTKeA=NwaritGpdjWXDlBuzVsfRFQgIUTKCk['body']['movies']
   for NwaritGpdjWXDlBuzVsfRFQgIUTKCE in NwaritGpdjWXDlBuzVsfRFQgIUTKeA:
    NwaritGpdjWXDlBuzVsfRFQgIUTKMe =NwaritGpdjWXDlBuzVsfRFQgIUTKCE['code']
    NwaritGpdjWXDlBuzVsfRFQgIUTKeh =NwaritGpdjWXDlBuzVsfRFQgIUTKCE['name']['ko']
    NwaritGpdjWXDlBuzVsfRFQgIUTKML =NwaritGpdjWXDlBuzVsfRFQgIUTKbM.IMG_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKCE['image'][0]['url']
    for NwaritGpdjWXDlBuzVsfRFQgIUTKmb in NwaritGpdjWXDlBuzVsfRFQgIUTKCE['image']:
     if NwaritGpdjWXDlBuzVsfRFQgIUTKmb['code']=='CAIM2100':
      NwaritGpdjWXDlBuzVsfRFQgIUTKML =NwaritGpdjWXDlBuzVsfRFQgIUTKbM.IMG_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKmb['url']
    NwaritGpdjWXDlBuzVsfRFQgIUTKeO =NwaritGpdjWXDlBuzVsfRFQgIUTKCE['story']['ko']
    NwaritGpdjWXDlBuzVsfRFQgIUTKmn={'moviecode':NwaritGpdjWXDlBuzVsfRFQgIUTKMe,'title':NwaritGpdjWXDlBuzVsfRFQgIUTKeh.strip(),'thumbnail':NwaritGpdjWXDlBuzVsfRFQgIUTKML,'synopsis':NwaritGpdjWXDlBuzVsfRFQgIUTKeO}
    NwaritGpdjWXDlBuzVsfRFQgIUTKeL.append(NwaritGpdjWXDlBuzVsfRFQgIUTKmn)
  except NwaritGpdjWXDlBuzVsfRFQgIUTKyM as exception:
   NwaritGpdjWXDlBuzVsfRFQgIUTKyP(exception)
  return NwaritGpdjWXDlBuzVsfRFQgIUTKeL,NwaritGpdjWXDlBuzVsfRFQgIUTKev
 def GetMovieGenre(NwaritGpdjWXDlBuzVsfRFQgIUTKbM):
  NwaritGpdjWXDlBuzVsfRFQgIUTKeL=[]
  NwaritGpdjWXDlBuzVsfRFQgIUTKev=NwaritGpdjWXDlBuzVsfRFQgIUTKyb
  try:
   NwaritGpdjWXDlBuzVsfRFQgIUTKCA ='/v2/media/movie/curations'
   NwaritGpdjWXDlBuzVsfRFQgIUTKCH=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.GetDefaultParams()
   NwaritGpdjWXDlBuzVsfRFQgIUTKCn={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code','_':NwaritGpdjWXDlBuzVsfRFQgIUTKyL(NwaritGpdjWXDlBuzVsfRFQgIUTKbM.GetNoCache(2))}
   NwaritGpdjWXDlBuzVsfRFQgIUTKCH.update(NwaritGpdjWXDlBuzVsfRFQgIUTKCn)
   NwaritGpdjWXDlBuzVsfRFQgIUTKCx=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.API_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKCA
   NwaritGpdjWXDlBuzVsfRFQgIUTKbS=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.callRequestCookies('Get',NwaritGpdjWXDlBuzVsfRFQgIUTKCx,payload=NwaritGpdjWXDlBuzVsfRFQgIUTKMq,params=NwaritGpdjWXDlBuzVsfRFQgIUTKCH,headers=NwaritGpdjWXDlBuzVsfRFQgIUTKMq,cookies=NwaritGpdjWXDlBuzVsfRFQgIUTKMq)
   NwaritGpdjWXDlBuzVsfRFQgIUTKCk=json.loads(NwaritGpdjWXDlBuzVsfRFQgIUTKbS.text)
   if not('result' in NwaritGpdjWXDlBuzVsfRFQgIUTKCk['body']):return NwaritGpdjWXDlBuzVsfRFQgIUTKeL,NwaritGpdjWXDlBuzVsfRFQgIUTKev
   NwaritGpdjWXDlBuzVsfRFQgIUTKeA=NwaritGpdjWXDlBuzVsfRFQgIUTKCk['body']['result']
   for NwaritGpdjWXDlBuzVsfRFQgIUTKCE in NwaritGpdjWXDlBuzVsfRFQgIUTKeA:
    NwaritGpdjWXDlBuzVsfRFQgIUTKMv =NwaritGpdjWXDlBuzVsfRFQgIUTKCE['curation_code']
    NwaritGpdjWXDlBuzVsfRFQgIUTKMJ =NwaritGpdjWXDlBuzVsfRFQgIUTKCE['curation_name']
    NwaritGpdjWXDlBuzVsfRFQgIUTKmn={'curation_code':NwaritGpdjWXDlBuzVsfRFQgIUTKMv,'curation_name':NwaritGpdjWXDlBuzVsfRFQgIUTKMJ}
    NwaritGpdjWXDlBuzVsfRFQgIUTKeL.append(NwaritGpdjWXDlBuzVsfRFQgIUTKmn)
  except NwaritGpdjWXDlBuzVsfRFQgIUTKyM as exception:
   NwaritGpdjWXDlBuzVsfRFQgIUTKyP(exception)
  return NwaritGpdjWXDlBuzVsfRFQgIUTKeL,NwaritGpdjWXDlBuzVsfRFQgIUTKev
 def GetSearchList(NwaritGpdjWXDlBuzVsfRFQgIUTKbM,search_key,userid,page_int,stype):
  NwaritGpdjWXDlBuzVsfRFQgIUTKMA=[]
  NwaritGpdjWXDlBuzVsfRFQgIUTKev=NwaritGpdjWXDlBuzVsfRFQgIUTKyb
  try:
   NwaritGpdjWXDlBuzVsfRFQgIUTKCA ='/search/getSearch.jsp'
   NwaritGpdjWXDlBuzVsfRFQgIUTKCn={'kwd':search_key,'notFoundText':search_key,'userid':userid,'siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':NwaritGpdjWXDlBuzVsfRFQgIUTKyL(page_int),'pageSize':NwaritGpdjWXDlBuzVsfRFQgIUTKyL(NwaritGpdjWXDlBuzVsfRFQgIUTKbM.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':NwaritGpdjWXDlBuzVsfRFQgIUTKbM.SCREENCODE,'os':NwaritGpdjWXDlBuzVsfRFQgIUTKbM.OSCODE,'network':NwaritGpdjWXDlBuzVsfRFQgIUTKbM.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':NwaritGpdjWXDlBuzVsfRFQgIUTKyL(NwaritGpdjWXDlBuzVsfRFQgIUTKbM.SEARCH_LIMIT),'vodMVReqCnt':NwaritGpdjWXDlBuzVsfRFQgIUTKyL(NwaritGpdjWXDlBuzVsfRFQgIUTKbM.SEARCH_LIMIT),'smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':NwaritGpdjWXDlBuzVsfRFQgIUTKyL(NwaritGpdjWXDlBuzVsfRFQgIUTKbM.GetNoCache(2))}
   NwaritGpdjWXDlBuzVsfRFQgIUTKCx=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.SEARCH_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKCA
   NwaritGpdjWXDlBuzVsfRFQgIUTKbS=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.callRequestCookies('Get',NwaritGpdjWXDlBuzVsfRFQgIUTKCx,payload=NwaritGpdjWXDlBuzVsfRFQgIUTKMq,params=NwaritGpdjWXDlBuzVsfRFQgIUTKCn,headers=NwaritGpdjWXDlBuzVsfRFQgIUTKMq,cookies=NwaritGpdjWXDlBuzVsfRFQgIUTKMq)
   NwaritGpdjWXDlBuzVsfRFQgIUTKCk=json.loads(NwaritGpdjWXDlBuzVsfRFQgIUTKbS.text)
   if stype=='vod':
    if not('programRsb' in NwaritGpdjWXDlBuzVsfRFQgIUTKCk):return NwaritGpdjWXDlBuzVsfRFQgIUTKMA,NwaritGpdjWXDlBuzVsfRFQgIUTKev
    NwaritGpdjWXDlBuzVsfRFQgIUTKMH=NwaritGpdjWXDlBuzVsfRFQgIUTKCk['programRsb']['dataList']
    NwaritGpdjWXDlBuzVsfRFQgIUTKMn =NwaritGpdjWXDlBuzVsfRFQgIUTKyC(NwaritGpdjWXDlBuzVsfRFQgIUTKCk['programRsb']['count'])
    for NwaritGpdjWXDlBuzVsfRFQgIUTKCE in NwaritGpdjWXDlBuzVsfRFQgIUTKMH:
     NwaritGpdjWXDlBuzVsfRFQgIUTKmx=NwaritGpdjWXDlBuzVsfRFQgIUTKCE['mast_cd']
     NwaritGpdjWXDlBuzVsfRFQgIUTKeh =NwaritGpdjWXDlBuzVsfRFQgIUTKCE['mast_nm']
     NwaritGpdjWXDlBuzVsfRFQgIUTKeE=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.IMG_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKCE['web_url4']
     NwaritGpdjWXDlBuzVsfRFQgIUTKeY =NwaritGpdjWXDlBuzVsfRFQgIUTKbM.IMG_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKCE['web_url']
     try:
      NwaritGpdjWXDlBuzVsfRFQgIUTKmC =[]
      NwaritGpdjWXDlBuzVsfRFQgIUTKme=[]
      NwaritGpdjWXDlBuzVsfRFQgIUTKmM =[]
      NwaritGpdjWXDlBuzVsfRFQgIUTKMm =0
      NwaritGpdjWXDlBuzVsfRFQgIUTKmP =''
      NwaritGpdjWXDlBuzVsfRFQgIUTKmy =''
      NwaritGpdjWXDlBuzVsfRFQgIUTKMb =''
      if NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('actor') !='' and NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('actor') !='-':NwaritGpdjWXDlBuzVsfRFQgIUTKmC =NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('actor').split(',')
      if NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('director')!='' and NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('director')!='-':NwaritGpdjWXDlBuzVsfRFQgIUTKme=NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('director').split(',')
      if NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('cate_nm')!='' and NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('cate_nm')!='-':NwaritGpdjWXDlBuzVsfRFQgIUTKmM =NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('cate_nm').split('/')
      if 'targetage' in NwaritGpdjWXDlBuzVsfRFQgIUTKCE:NwaritGpdjWXDlBuzVsfRFQgIUTKmP=NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('targetage')
      if 'broad_dt' in NwaritGpdjWXDlBuzVsfRFQgIUTKCE:
       NwaritGpdjWXDlBuzVsfRFQgIUTKmA=NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('broad_dt')
       NwaritGpdjWXDlBuzVsfRFQgIUTKMb='%s-%s-%s'%(NwaritGpdjWXDlBuzVsfRFQgIUTKmA[:4],NwaritGpdjWXDlBuzVsfRFQgIUTKmA[4:6],NwaritGpdjWXDlBuzVsfRFQgIUTKmA[6:])
       NwaritGpdjWXDlBuzVsfRFQgIUTKmy =NwaritGpdjWXDlBuzVsfRFQgIUTKmA[:4]
     except:
      NwaritGpdjWXDlBuzVsfRFQgIUTKMq
     NwaritGpdjWXDlBuzVsfRFQgIUTKmn={'program':NwaritGpdjWXDlBuzVsfRFQgIUTKmx,'title':NwaritGpdjWXDlBuzVsfRFQgIUTKeh,'thumbnail':{'poster':NwaritGpdjWXDlBuzVsfRFQgIUTKeE,'thumb':NwaritGpdjWXDlBuzVsfRFQgIUTKeY,'fanart':NwaritGpdjWXDlBuzVsfRFQgIUTKeY},'synopsis':'','cast':NwaritGpdjWXDlBuzVsfRFQgIUTKmC,'director':NwaritGpdjWXDlBuzVsfRFQgIUTKme,'info_genre':NwaritGpdjWXDlBuzVsfRFQgIUTKmM,'duration':NwaritGpdjWXDlBuzVsfRFQgIUTKMm,'mpaa':NwaritGpdjWXDlBuzVsfRFQgIUTKmP,'year':NwaritGpdjWXDlBuzVsfRFQgIUTKmy,'aired':NwaritGpdjWXDlBuzVsfRFQgIUTKMb}
     NwaritGpdjWXDlBuzVsfRFQgIUTKMA.append(NwaritGpdjWXDlBuzVsfRFQgIUTKmn)
   else:
    if not('vodMVRsb' in NwaritGpdjWXDlBuzVsfRFQgIUTKCk):return NwaritGpdjWXDlBuzVsfRFQgIUTKMA,NwaritGpdjWXDlBuzVsfRFQgIUTKev
    NwaritGpdjWXDlBuzVsfRFQgIUTKMx=NwaritGpdjWXDlBuzVsfRFQgIUTKCk['vodMVRsb']['dataList']
    NwaritGpdjWXDlBuzVsfRFQgIUTKMn =NwaritGpdjWXDlBuzVsfRFQgIUTKyC(NwaritGpdjWXDlBuzVsfRFQgIUTKCk['vodMVRsb']['count'])
    for NwaritGpdjWXDlBuzVsfRFQgIUTKCE in NwaritGpdjWXDlBuzVsfRFQgIUTKMx:
     NwaritGpdjWXDlBuzVsfRFQgIUTKmx=NwaritGpdjWXDlBuzVsfRFQgIUTKCE['mast_cd']
     NwaritGpdjWXDlBuzVsfRFQgIUTKeh =NwaritGpdjWXDlBuzVsfRFQgIUTKCE['mast_nm'].strip()
     NwaritGpdjWXDlBuzVsfRFQgIUTKeE =NwaritGpdjWXDlBuzVsfRFQgIUTKbM.IMG_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKCE['web_url']
     NwaritGpdjWXDlBuzVsfRFQgIUTKeY =NwaritGpdjWXDlBuzVsfRFQgIUTKeE.replace('CAIM2100','CAIM0400')
     NwaritGpdjWXDlBuzVsfRFQgIUTKeo=NwaritGpdjWXDlBuzVsfRFQgIUTKeE.replace('CAIM2100','CAIM1800')
     try:
      NwaritGpdjWXDlBuzVsfRFQgIUTKmC =[]
      NwaritGpdjWXDlBuzVsfRFQgIUTKme=[]
      NwaritGpdjWXDlBuzVsfRFQgIUTKmM =[]
      NwaritGpdjWXDlBuzVsfRFQgIUTKMm =0
      NwaritGpdjWXDlBuzVsfRFQgIUTKmP =''
      NwaritGpdjWXDlBuzVsfRFQgIUTKmy =''
      NwaritGpdjWXDlBuzVsfRFQgIUTKMb =''
      if NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('actor') !='' and NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('actor') !='-':NwaritGpdjWXDlBuzVsfRFQgIUTKmC =NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('actor').split(',')
      if NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('director')!='' and NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('director')!='-':NwaritGpdjWXDlBuzVsfRFQgIUTKme=NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('director').split(',')
      if NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('cate_nm')!='' and NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('cate_nm')!='-':NwaritGpdjWXDlBuzVsfRFQgIUTKmM =NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('cate_nm').split('/')
      if NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('runtime_sec')!='':NwaritGpdjWXDlBuzVsfRFQgIUTKMm=NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('runtime_sec')
      if 'grade_nm' in NwaritGpdjWXDlBuzVsfRFQgIUTKCE:NwaritGpdjWXDlBuzVsfRFQgIUTKmP=NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('grade_nm')
      NwaritGpdjWXDlBuzVsfRFQgIUTKmA=NwaritGpdjWXDlBuzVsfRFQgIUTKCE.get('broad_dt')
      if data_str!='':
       NwaritGpdjWXDlBuzVsfRFQgIUTKMb='%s-%s-%s'%(NwaritGpdjWXDlBuzVsfRFQgIUTKmA[:4],NwaritGpdjWXDlBuzVsfRFQgIUTKmA[4:6],NwaritGpdjWXDlBuzVsfRFQgIUTKmA[6:])
       NwaritGpdjWXDlBuzVsfRFQgIUTKmy =NwaritGpdjWXDlBuzVsfRFQgIUTKmA[:4]
     except:
      NwaritGpdjWXDlBuzVsfRFQgIUTKMq
     NwaritGpdjWXDlBuzVsfRFQgIUTKmn={'movie':NwaritGpdjWXDlBuzVsfRFQgIUTKmx,'title':NwaritGpdjWXDlBuzVsfRFQgIUTKeh,'thumbnail':{'poster':NwaritGpdjWXDlBuzVsfRFQgIUTKeE,'thumb':NwaritGpdjWXDlBuzVsfRFQgIUTKeY,'fanart':NwaritGpdjWXDlBuzVsfRFQgIUTKeY,'clearlogo':NwaritGpdjWXDlBuzVsfRFQgIUTKeo},'synopsis':'','cast':NwaritGpdjWXDlBuzVsfRFQgIUTKmC,'director':NwaritGpdjWXDlBuzVsfRFQgIUTKme,'info_genre':NwaritGpdjWXDlBuzVsfRFQgIUTKmM,'duration':NwaritGpdjWXDlBuzVsfRFQgIUTKMm,'mpaa':NwaritGpdjWXDlBuzVsfRFQgIUTKmP,'year':NwaritGpdjWXDlBuzVsfRFQgIUTKmy,'aired':NwaritGpdjWXDlBuzVsfRFQgIUTKMb}
     NwaritGpdjWXDlBuzVsfRFQgIUTKMy=NwaritGpdjWXDlBuzVsfRFQgIUTKyb
     for NwaritGpdjWXDlBuzVsfRFQgIUTKMP in NwaritGpdjWXDlBuzVsfRFQgIUTKCE['bill']:
      if NwaritGpdjWXDlBuzVsfRFQgIUTKMP in NwaritGpdjWXDlBuzVsfRFQgIUTKbM.MOVIE_LITE:
       NwaritGpdjWXDlBuzVsfRFQgIUTKMy=NwaritGpdjWXDlBuzVsfRFQgIUTKym
       break
     if NwaritGpdjWXDlBuzVsfRFQgIUTKMy==NwaritGpdjWXDlBuzVsfRFQgIUTKyb: 
      NwaritGpdjWXDlBuzVsfRFQgIUTKmn['title']=NwaritGpdjWXDlBuzVsfRFQgIUTKmn['title']+' [개별구매]'
     NwaritGpdjWXDlBuzVsfRFQgIUTKMA.append(NwaritGpdjWXDlBuzVsfRFQgIUTKmn)
  except NwaritGpdjWXDlBuzVsfRFQgIUTKyM as exception:
   NwaritGpdjWXDlBuzVsfRFQgIUTKyP(exception)
  return NwaritGpdjWXDlBuzVsfRFQgIUTKMA,NwaritGpdjWXDlBuzVsfRFQgIUTKev
 def GetDeviceList(NwaritGpdjWXDlBuzVsfRFQgIUTKbM,NwaritGpdjWXDlBuzVsfRFQgIUTKCb,NwaritGpdjWXDlBuzVsfRFQgIUTKCe):
  NwaritGpdjWXDlBuzVsfRFQgIUTKeL=[]
  NwaritGpdjWXDlBuzVsfRFQgIUTKCv='-'
  try:
   NwaritGpdjWXDlBuzVsfRFQgIUTKCA ='/v1/user/device/list'
   NwaritGpdjWXDlBuzVsfRFQgIUTKMk=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.API_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKCA
   NwaritGpdjWXDlBuzVsfRFQgIUTKCn={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   NwaritGpdjWXDlBuzVsfRFQgIUTKbL=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.makeDefaultCookies(vToken=NwaritGpdjWXDlBuzVsfRFQgIUTKCb,vUserinfo=NwaritGpdjWXDlBuzVsfRFQgIUTKCe)
   NwaritGpdjWXDlBuzVsfRFQgIUTKbS=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.callRequestCookies('Get',NwaritGpdjWXDlBuzVsfRFQgIUTKMk,payload=NwaritGpdjWXDlBuzVsfRFQgIUTKMq,params=NwaritGpdjWXDlBuzVsfRFQgIUTKCn,headers=NwaritGpdjWXDlBuzVsfRFQgIUTKMq,cookies=NwaritGpdjWXDlBuzVsfRFQgIUTKbL)
   NwaritGpdjWXDlBuzVsfRFQgIUTKCk=json.loads(NwaritGpdjWXDlBuzVsfRFQgIUTKbS.text)
   NwaritGpdjWXDlBuzVsfRFQgIUTKeL=NwaritGpdjWXDlBuzVsfRFQgIUTKCk['body']
   for NwaritGpdjWXDlBuzVsfRFQgIUTKCE in NwaritGpdjWXDlBuzVsfRFQgIUTKeL:
    if NwaritGpdjWXDlBuzVsfRFQgIUTKCE['model']=='PC':
     NwaritGpdjWXDlBuzVsfRFQgIUTKCv=NwaritGpdjWXDlBuzVsfRFQgIUTKCE['uuid']
  except NwaritGpdjWXDlBuzVsfRFQgIUTKyM as exception:
   NwaritGpdjWXDlBuzVsfRFQgIUTKyP(exception)
  return NwaritGpdjWXDlBuzVsfRFQgIUTKCv
 def GetProfileToken(NwaritGpdjWXDlBuzVsfRFQgIUTKbM,NwaritGpdjWXDlBuzVsfRFQgIUTKCb,NwaritGpdjWXDlBuzVsfRFQgIUTKCe,user_pf):
  NwaritGpdjWXDlBuzVsfRFQgIUTKMh=[]
  NwaritGpdjWXDlBuzVsfRFQgIUTKMO =''
  NwaritGpdjWXDlBuzVsfRFQgIUTKMY =''
  NwaritGpdjWXDlBuzVsfRFQgIUTKME='Y'
  NwaritGpdjWXDlBuzVsfRFQgIUTKMo ='N'
  try:
   NwaritGpdjWXDlBuzVsfRFQgIUTKCA ='/profile/select.do'
   NwaritGpdjWXDlBuzVsfRFQgIUTKMk=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.URL_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKCA
   NwaritGpdjWXDlBuzVsfRFQgIUTKbL=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.makeDefaultCookies(vToken=NwaritGpdjWXDlBuzVsfRFQgIUTKCb,vUserinfo=NwaritGpdjWXDlBuzVsfRFQgIUTKCe)
   NwaritGpdjWXDlBuzVsfRFQgIUTKbS=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.callRequestCookies('Get',NwaritGpdjWXDlBuzVsfRFQgIUTKMk,payload=NwaritGpdjWXDlBuzVsfRFQgIUTKMq,params=NwaritGpdjWXDlBuzVsfRFQgIUTKMq,headers=NwaritGpdjWXDlBuzVsfRFQgIUTKMq,cookies=NwaritGpdjWXDlBuzVsfRFQgIUTKbL)
   NwaritGpdjWXDlBuzVsfRFQgIUTKMh =re.findall('data-profile-no="\d+"',NwaritGpdjWXDlBuzVsfRFQgIUTKbS.text)
   for i in NwaritGpdjWXDlBuzVsfRFQgIUTKye(NwaritGpdjWXDlBuzVsfRFQgIUTKyJ(NwaritGpdjWXDlBuzVsfRFQgIUTKMh)):
    NwaritGpdjWXDlBuzVsfRFQgIUTKMc =NwaritGpdjWXDlBuzVsfRFQgIUTKMh[i].replace('data-profile-no=','').replace('"','')
    NwaritGpdjWXDlBuzVsfRFQgIUTKMh[i]=NwaritGpdjWXDlBuzVsfRFQgIUTKMc
   NwaritGpdjWXDlBuzVsfRFQgIUTKMO=NwaritGpdjWXDlBuzVsfRFQgIUTKMh[user_pf]
  except NwaritGpdjWXDlBuzVsfRFQgIUTKyM as exception:
   NwaritGpdjWXDlBuzVsfRFQgIUTKyP(exception)
   return NwaritGpdjWXDlBuzVsfRFQgIUTKMY,NwaritGpdjWXDlBuzVsfRFQgIUTKME,NwaritGpdjWXDlBuzVsfRFQgIUTKMo
  try:
   NwaritGpdjWXDlBuzVsfRFQgIUTKCA ='/profile/api/select.do'
   NwaritGpdjWXDlBuzVsfRFQgIUTKMk=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.URL_DOMAIN+NwaritGpdjWXDlBuzVsfRFQgIUTKCA
   NwaritGpdjWXDlBuzVsfRFQgIUTKbL=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.makeDefaultCookies(vToken=NwaritGpdjWXDlBuzVsfRFQgIUTKCb,vUserinfo=NwaritGpdjWXDlBuzVsfRFQgIUTKCe)
   NwaritGpdjWXDlBuzVsfRFQgIUTKbc={'profileNo':NwaritGpdjWXDlBuzVsfRFQgIUTKMO}
   NwaritGpdjWXDlBuzVsfRFQgIUTKbS=NwaritGpdjWXDlBuzVsfRFQgIUTKbM.callRequestCookies('Post',NwaritGpdjWXDlBuzVsfRFQgIUTKMk,payload=NwaritGpdjWXDlBuzVsfRFQgIUTKbc,params=NwaritGpdjWXDlBuzVsfRFQgIUTKMq,headers=NwaritGpdjWXDlBuzVsfRFQgIUTKMq,cookies=NwaritGpdjWXDlBuzVsfRFQgIUTKbL)
   for NwaritGpdjWXDlBuzVsfRFQgIUTKbq in NwaritGpdjWXDlBuzVsfRFQgIUTKbS.cookies:
    if NwaritGpdjWXDlBuzVsfRFQgIUTKbq.name=='_tving_token':
     NwaritGpdjWXDlBuzVsfRFQgIUTKMY=NwaritGpdjWXDlBuzVsfRFQgIUTKbq.value
    elif NwaritGpdjWXDlBuzVsfRFQgIUTKbq.name==NwaritGpdjWXDlBuzVsfRFQgIUTKbM.GLOBAL_COOKIENM['tv_cookiekey']:
     NwaritGpdjWXDlBuzVsfRFQgIUTKME=NwaritGpdjWXDlBuzVsfRFQgIUTKbq.value
    elif NwaritGpdjWXDlBuzVsfRFQgIUTKbq.name==NwaritGpdjWXDlBuzVsfRFQgIUTKbM.GLOBAL_COOKIENM['tv_lockkey']:
     NwaritGpdjWXDlBuzVsfRFQgIUTKMo=NwaritGpdjWXDlBuzVsfRFQgIUTKbq.value
  except NwaritGpdjWXDlBuzVsfRFQgIUTKyM as exception:
   NwaritGpdjWXDlBuzVsfRFQgIUTKyP(exception)
  return NwaritGpdjWXDlBuzVsfRFQgIUTKMY,NwaritGpdjWXDlBuzVsfRFQgIUTKME,NwaritGpdjWXDlBuzVsfRFQgIUTKMo
# Created by pyminifier (https://github.com/liftoff/pyminifier)
