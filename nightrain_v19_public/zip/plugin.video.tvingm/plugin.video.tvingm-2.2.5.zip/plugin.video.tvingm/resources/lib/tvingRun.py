__author__="NightRain"
EOUiJmnDLxaHIzSrQwspgWNGhTcRlX=object
EOUiJmnDLxaHIzSrQwspgWNGhTcRle=None
EOUiJmnDLxaHIzSrQwspgWNGhTcRlb=int
EOUiJmnDLxaHIzSrQwspgWNGhTcRlt=False
EOUiJmnDLxaHIzSrQwspgWNGhTcRlB=True
EOUiJmnDLxaHIzSrQwspgWNGhTcRlC=len
EOUiJmnDLxaHIzSrQwspgWNGhTcRlu=str
EOUiJmnDLxaHIzSrQwspgWNGhTcRlK=open
EOUiJmnDLxaHIzSrQwspgWNGhTcRvy=dict
EOUiJmnDLxaHIzSrQwspgWNGhTcRvk=Exception
EOUiJmnDLxaHIzSrQwspgWNGhTcRvo=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
EOUiJmnDLxaHIzSrQwspgWNGhTcRyo=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 인기순','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewWeek','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'검색 (search)','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-'}]
EOUiJmnDLxaHIzSrQwspgWNGhTcRyj=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
EOUiJmnDLxaHIzSrQwspgWNGhTcRyV=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
EOUiJmnDLxaHIzSrQwspgWNGhTcRyl=[{'title':'VOD 검색','mode':'SEARCH','stype':'vod'},{'title':'영화 검색','mode':'SEARCH','stype':'movie'}]
EOUiJmnDLxaHIzSrQwspgWNGhTcRyv=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'키즈/애니','mode':'PROGRAM','stype':'PCC,PCAN'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'뮤직','mode':'PROGRAM','stype':'PCG'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'}]
EOUiJmnDLxaHIzSrQwspgWNGhTcRyY=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG190,MG230,MG270,MG290'},{'title':'로맨스/멜로','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'액션/SF','mode':'MOVIE_SUB','stype':'MG120,MG170,MG180,MG220,MG260,MG200,MG210'},{'title':'공포/스릴러','mode':'MOVIE_SUB','stype':'MG140,MG150,MG160'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'다큐','mode':'MOVIE_SUB','stype':'MG250,MG330'}]
EOUiJmnDLxaHIzSrQwspgWNGhTcRyM=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
EOUiJmnDLxaHIzSrQwspgWNGhTcRyP=xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
from tvingCore import*
class EOUiJmnDLxaHIzSrQwspgWNGhTcRyk(EOUiJmnDLxaHIzSrQwspgWNGhTcRlX):
 def __init__(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd,EOUiJmnDLxaHIzSrQwspgWNGhTcRyF,EOUiJmnDLxaHIzSrQwspgWNGhTcRyf,EOUiJmnDLxaHIzSrQwspgWNGhTcRyq):
  EOUiJmnDLxaHIzSrQwspgWNGhTcRyd._addon_url =EOUiJmnDLxaHIzSrQwspgWNGhTcRyF
  EOUiJmnDLxaHIzSrQwspgWNGhTcRyd._addon_handle=EOUiJmnDLxaHIzSrQwspgWNGhTcRyf
  EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.main_params =EOUiJmnDLxaHIzSrQwspgWNGhTcRyq
  EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.TvingObj =NwaritGpdjWXDlBuzVsfRFQgIUTKbC() 
 def addon_noti(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd,sting):
  try:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyX=xbmcgui.Dialog()
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyX.notification(__addonname__,sting)
  except:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRle
 def addon_log(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd,string):
  try:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRye=string.encode('utf-8','ignore')
  except:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRye='addonException: addon_log'
  EOUiJmnDLxaHIzSrQwspgWNGhTcRyb=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,EOUiJmnDLxaHIzSrQwspgWNGhTcRye),level=EOUiJmnDLxaHIzSrQwspgWNGhTcRyb)
 def get_keyboard_input(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd,EOUiJmnDLxaHIzSrQwspgWNGhTcRkv):
  EOUiJmnDLxaHIzSrQwspgWNGhTcRyt=EOUiJmnDLxaHIzSrQwspgWNGhTcRle
  kb=xbmc.Keyboard()
  kb.setHeading(EOUiJmnDLxaHIzSrQwspgWNGhTcRkv)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyt=kb.getText()
  return EOUiJmnDLxaHIzSrQwspgWNGhTcRyt
 def get_settings_login_info(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd):
  EOUiJmnDLxaHIzSrQwspgWNGhTcRyB =__addon__.getSetting('id')
  EOUiJmnDLxaHIzSrQwspgWNGhTcRyC =__addon__.getSetting('pw')
  EOUiJmnDLxaHIzSrQwspgWNGhTcRyu =__addon__.getSetting('login_type')
  EOUiJmnDLxaHIzSrQwspgWNGhTcRyK=EOUiJmnDLxaHIzSrQwspgWNGhTcRlb(__addon__.getSetting('selected_profile'))
  return(EOUiJmnDLxaHIzSrQwspgWNGhTcRyB,EOUiJmnDLxaHIzSrQwspgWNGhTcRyC,EOUiJmnDLxaHIzSrQwspgWNGhTcRyu,EOUiJmnDLxaHIzSrQwspgWNGhTcRyK)
 def get_settings_premiumyn(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd):
  EOUiJmnDLxaHIzSrQwspgWNGhTcRky =__addon__.getSetting('premium_movieyn')
  if EOUiJmnDLxaHIzSrQwspgWNGhTcRky=='false':
   return EOUiJmnDLxaHIzSrQwspgWNGhTcRlt
  else:
   return EOUiJmnDLxaHIzSrQwspgWNGhTcRlB
 def get_settings_direct_replay(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd):
  EOUiJmnDLxaHIzSrQwspgWNGhTcRko=EOUiJmnDLxaHIzSrQwspgWNGhTcRlb(__addon__.getSetting('direct_replay'))
  if EOUiJmnDLxaHIzSrQwspgWNGhTcRko==0:
   return EOUiJmnDLxaHIzSrQwspgWNGhTcRlt
  else:
   return EOUiJmnDLxaHIzSrQwspgWNGhTcRlB
 def set_winCredential(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd,credential):
  EOUiJmnDLxaHIzSrQwspgWNGhTcRkj=xbmcgui.Window(10000)
  EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.setProperty('TVING_M_TOKEN',credential.get('tving_token'))
  EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.setProperty('TVING_M_USERINFO',credential.get('poc_userinfo'))
  EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.setProperty('TVING_M_UUID',credential.get('tving_uuid'))
  EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.setProperty('TVING_M_LOGINTIME',EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.TvingObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
  EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.setProperty('TVING_M_MAINTOKEN',credential.get('tving_maintoken'))
  EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.setProperty('TVING_M_COOKIEKEY',credential.get('tving_cookiekey'))
  EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.setProperty('TVING_M_LOCKKEY',credential.get('tving_lockkey'))
 def get_winCredential(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd):
  EOUiJmnDLxaHIzSrQwspgWNGhTcRkj=xbmcgui.Window(10000)
  EOUiJmnDLxaHIzSrQwspgWNGhTcRkV={'tving_token':EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.getProperty('TVING_M_TOKEN'),'poc_userinfo':EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.getProperty('TVING_M_USERINFO'),'tving_uuid':EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.getProperty('TVING_M_UUID'),'tving_maintoken':EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.getProperty('TVING_M_LOCKKEY')}
  return EOUiJmnDLxaHIzSrQwspgWNGhTcRkV
 def set_winEpisodeOrderby(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd,EOUiJmnDLxaHIzSrQwspgWNGhTcRou):
  EOUiJmnDLxaHIzSrQwspgWNGhTcRkj=xbmcgui.Window(10000)
  EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.setProperty('TVING_M_ORDERBY',EOUiJmnDLxaHIzSrQwspgWNGhTcRou)
 def get_winEpisodeOrderby(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd):
  EOUiJmnDLxaHIzSrQwspgWNGhTcRkj=xbmcgui.Window(10000)
  return EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.getProperty('TVING_M_ORDERBY')
 def add_dir(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd,label,sublabel='',img='',infoLabels=EOUiJmnDLxaHIzSrQwspgWNGhTcRle,isFolder=EOUiJmnDLxaHIzSrQwspgWNGhTcRlB,params='',ContextMenu=EOUiJmnDLxaHIzSrQwspgWNGhTcRle):
  EOUiJmnDLxaHIzSrQwspgWNGhTcRkl='%s?%s'%(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd._addon_url,urllib.parse.urlencode(params))
  if sublabel:EOUiJmnDLxaHIzSrQwspgWNGhTcRkv='%s < %s >'%(label,sublabel)
  else: EOUiJmnDLxaHIzSrQwspgWNGhTcRkv=label
  if not img:img='DefaultFolder.png'
  EOUiJmnDLxaHIzSrQwspgWNGhTcRkY=xbmcgui.ListItem(EOUiJmnDLxaHIzSrQwspgWNGhTcRkv)
  if 'thumb' in img or 'poster' in img:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkY.setArt(img)
  else:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkY.setArt({'thumb':img,'poster':img})
  if infoLabels:EOUiJmnDLxaHIzSrQwspgWNGhTcRkY.setInfo(type='Video',infoLabels=infoLabels)
  if not isFolder:EOUiJmnDLxaHIzSrQwspgWNGhTcRkY.setProperty('IsPlayable','true')
  if ContextMenu:EOUiJmnDLxaHIzSrQwspgWNGhTcRkY.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd._addon_handle,EOUiJmnDLxaHIzSrQwspgWNGhTcRkl,EOUiJmnDLxaHIzSrQwspgWNGhTcRkY,isFolder)
 def get_selQuality(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd,etype):
  try:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkM='selected_quality'
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkP=[1080,720,480,360]
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkd=EOUiJmnDLxaHIzSrQwspgWNGhTcRlb(__addon__.getSetting(EOUiJmnDLxaHIzSrQwspgWNGhTcRkM))
   return EOUiJmnDLxaHIzSrQwspgWNGhTcRkP[EOUiJmnDLxaHIzSrQwspgWNGhTcRkd]
  except:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRle
  return 720 
 def dp_Main_List(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd):
  for EOUiJmnDLxaHIzSrQwspgWNGhTcRkF in EOUiJmnDLxaHIzSrQwspgWNGhTcRyo:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkv=EOUiJmnDLxaHIzSrQwspgWNGhTcRkF.get('title')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkf={'mode':EOUiJmnDLxaHIzSrQwspgWNGhTcRkF.get('mode'),'stype':EOUiJmnDLxaHIzSrQwspgWNGhTcRkF.get('stype'),'orderby':EOUiJmnDLxaHIzSrQwspgWNGhTcRkF.get('orderby'),'ordernm':EOUiJmnDLxaHIzSrQwspgWNGhTcRkF.get('ordernm'),'page':'1'}
   if EOUiJmnDLxaHIzSrQwspgWNGhTcRkF.get('mode')=='XXX':
    EOUiJmnDLxaHIzSrQwspgWNGhTcRkf['mode']='XXX'
    EOUiJmnDLxaHIzSrQwspgWNGhTcRkq=EOUiJmnDLxaHIzSrQwspgWNGhTcRlt
   else:
    EOUiJmnDLxaHIzSrQwspgWNGhTcRkq=EOUiJmnDLxaHIzSrQwspgWNGhTcRlB
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.add_dir(EOUiJmnDLxaHIzSrQwspgWNGhTcRkv,sublabel='',img='',infoLabels=EOUiJmnDLxaHIzSrQwspgWNGhTcRle,isFolder=EOUiJmnDLxaHIzSrQwspgWNGhTcRkq,params=EOUiJmnDLxaHIzSrQwspgWNGhTcRkf,ContextMenu=EOUiJmnDLxaHIzSrQwspgWNGhTcRle)
  if EOUiJmnDLxaHIzSrQwspgWNGhTcRlC(EOUiJmnDLxaHIzSrQwspgWNGhTcRyo)>0:xbmcplugin.endOfDirectory(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd._addon_handle)
 def login_main(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd):
  (EOUiJmnDLxaHIzSrQwspgWNGhTcRkX,EOUiJmnDLxaHIzSrQwspgWNGhTcRke,EOUiJmnDLxaHIzSrQwspgWNGhTcRkb,EOUiJmnDLxaHIzSrQwspgWNGhTcRkt)=EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.get_settings_login_info()
  if not(EOUiJmnDLxaHIzSrQwspgWNGhTcRkX and EOUiJmnDLxaHIzSrQwspgWNGhTcRke):
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyX=xbmcgui.Dialog()
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkB=EOUiJmnDLxaHIzSrQwspgWNGhTcRyX.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if EOUiJmnDLxaHIzSrQwspgWNGhTcRkB==EOUiJmnDLxaHIzSrQwspgWNGhTcRlB:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.get_winEpisodeOrderby()=='':
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.set_winEpisodeOrderby('desc')
  if EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.cookiefile_check():return
  EOUiJmnDLxaHIzSrQwspgWNGhTcRkC =EOUiJmnDLxaHIzSrQwspgWNGhTcRlb(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  EOUiJmnDLxaHIzSrQwspgWNGhTcRku=xbmcgui.Window(10000).getProperty('TVING_M_LOGINTIME')
  if EOUiJmnDLxaHIzSrQwspgWNGhTcRku==EOUiJmnDLxaHIzSrQwspgWNGhTcRle or EOUiJmnDLxaHIzSrQwspgWNGhTcRku=='':
   EOUiJmnDLxaHIzSrQwspgWNGhTcRku=EOUiJmnDLxaHIzSrQwspgWNGhTcRlb('19000101')
  else:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRku=EOUiJmnDLxaHIzSrQwspgWNGhTcRlb(re.sub('-','',EOUiJmnDLxaHIzSrQwspgWNGhTcRku))
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkK=0
   while EOUiJmnDLxaHIzSrQwspgWNGhTcRlB:
    EOUiJmnDLxaHIzSrQwspgWNGhTcRkK+=1
    time.sleep(0.05)
    if EOUiJmnDLxaHIzSrQwspgWNGhTcRku>=EOUiJmnDLxaHIzSrQwspgWNGhTcRkC:return
    if EOUiJmnDLxaHIzSrQwspgWNGhTcRkK>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  if EOUiJmnDLxaHIzSrQwspgWNGhTcRku>=EOUiJmnDLxaHIzSrQwspgWNGhTcRkC:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   return
  if not EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.TvingObj.GetCredential(EOUiJmnDLxaHIzSrQwspgWNGhTcRkX,EOUiJmnDLxaHIzSrQwspgWNGhTcRke,EOUiJmnDLxaHIzSrQwspgWNGhTcRkb,EOUiJmnDLxaHIzSrQwspgWNGhTcRkt):
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   sys.exit()
  EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.set_winCredential(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.TvingObj.LoadCredential())
  EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
 def dp_Title_Group(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd,EOUiJmnDLxaHIzSrQwspgWNGhTcRoV):
  EOUiJmnDLxaHIzSrQwspgWNGhTcRoy=EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('stype')
  if EOUiJmnDLxaHIzSrQwspgWNGhTcRoy=='live':
   EOUiJmnDLxaHIzSrQwspgWNGhTcRok=EOUiJmnDLxaHIzSrQwspgWNGhTcRyj
  elif EOUiJmnDLxaHIzSrQwspgWNGhTcRoy=='vod':
   EOUiJmnDLxaHIzSrQwspgWNGhTcRok=EOUiJmnDLxaHIzSrQwspgWNGhTcRyv
  else:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRok=EOUiJmnDLxaHIzSrQwspgWNGhTcRyY
  for EOUiJmnDLxaHIzSrQwspgWNGhTcRoj in EOUiJmnDLxaHIzSrQwspgWNGhTcRok:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkv=EOUiJmnDLxaHIzSrQwspgWNGhTcRoj.get('title')
   if EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('ordernm')!='-':
    EOUiJmnDLxaHIzSrQwspgWNGhTcRkv+='  ('+EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('ordernm')+')'
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkf={'mode':EOUiJmnDLxaHIzSrQwspgWNGhTcRoj.get('mode'),'stype':EOUiJmnDLxaHIzSrQwspgWNGhTcRoj.get('stype'),'orderby':EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('orderby'),'ordernm':EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('ordernm'),'page':'1'}
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.add_dir(EOUiJmnDLxaHIzSrQwspgWNGhTcRkv,sublabel='',img='',infoLabels=EOUiJmnDLxaHIzSrQwspgWNGhTcRle,isFolder=EOUiJmnDLxaHIzSrQwspgWNGhTcRlB,params=EOUiJmnDLxaHIzSrQwspgWNGhTcRkf,ContextMenu=EOUiJmnDLxaHIzSrQwspgWNGhTcRle)
  if EOUiJmnDLxaHIzSrQwspgWNGhTcRlC(EOUiJmnDLxaHIzSrQwspgWNGhTcRok)>0:xbmcplugin.endOfDirectory(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd._addon_handle)
 def dp_SubTitle_Group(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd,EOUiJmnDLxaHIzSrQwspgWNGhTcRoV): 
  for EOUiJmnDLxaHIzSrQwspgWNGhTcRoj in EOUiJmnDLxaHIzSrQwspgWNGhTcRyM:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkv=EOUiJmnDLxaHIzSrQwspgWNGhTcRoj.get('title')
   if EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('ordernm')!='-':
    EOUiJmnDLxaHIzSrQwspgWNGhTcRkv+='  ('+EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('ordernm')+')'
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkf={'mode':EOUiJmnDLxaHIzSrQwspgWNGhTcRoj.get('mode'),'genreCode':EOUiJmnDLxaHIzSrQwspgWNGhTcRoj.get('genreCode'),'stype':EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('stype'),'orderby':EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('orderby'),'page':'1'}
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.add_dir(EOUiJmnDLxaHIzSrQwspgWNGhTcRkv,sublabel='',img='',infoLabels=EOUiJmnDLxaHIzSrQwspgWNGhTcRle,isFolder=EOUiJmnDLxaHIzSrQwspgWNGhTcRlB,params=EOUiJmnDLxaHIzSrQwspgWNGhTcRkf,ContextMenu=EOUiJmnDLxaHIzSrQwspgWNGhTcRle)
  if EOUiJmnDLxaHIzSrQwspgWNGhTcRlC(EOUiJmnDLxaHIzSrQwspgWNGhTcRyM)>0:xbmcplugin.endOfDirectory(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd._addon_handle)
 def dp_LiveChannel_List(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd,EOUiJmnDLxaHIzSrQwspgWNGhTcRoV):
  EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.TvingObj.SaveCredential(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.get_winCredential())
  EOUiJmnDLxaHIzSrQwspgWNGhTcRoy =EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('stype')
  EOUiJmnDLxaHIzSrQwspgWNGhTcRol =EOUiJmnDLxaHIzSrQwspgWNGhTcRlb(EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('page'))
  EOUiJmnDLxaHIzSrQwspgWNGhTcRov,EOUiJmnDLxaHIzSrQwspgWNGhTcRoY=EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.TvingObj.GetLiveChannelList(EOUiJmnDLxaHIzSrQwspgWNGhTcRoy,EOUiJmnDLxaHIzSrQwspgWNGhTcRol)
  for EOUiJmnDLxaHIzSrQwspgWNGhTcRoM in EOUiJmnDLxaHIzSrQwspgWNGhTcRov:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkv =EOUiJmnDLxaHIzSrQwspgWNGhTcRoM.get('title')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkA =EOUiJmnDLxaHIzSrQwspgWNGhTcRoM.get('channel')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRoP =EOUiJmnDLxaHIzSrQwspgWNGhTcRoM.get('thumbnail')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRod =EOUiJmnDLxaHIzSrQwspgWNGhTcRoM.get('synopsis')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRoF =EOUiJmnDLxaHIzSrQwspgWNGhTcRoM.get('channelepg')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRof =EOUiJmnDLxaHIzSrQwspgWNGhTcRoM.get('cast')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRoq =EOUiJmnDLxaHIzSrQwspgWNGhTcRoM.get('director')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRoA =EOUiJmnDLxaHIzSrQwspgWNGhTcRoM.get('info_genre')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRoX =EOUiJmnDLxaHIzSrQwspgWNGhTcRoM.get('year')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRoe =EOUiJmnDLxaHIzSrQwspgWNGhTcRoM.get('mpaa')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRob =EOUiJmnDLxaHIzSrQwspgWNGhTcRoM.get('premiered')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRot={'mediatype':'episode','title':EOUiJmnDLxaHIzSrQwspgWNGhTcRkv,'studio':EOUiJmnDLxaHIzSrQwspgWNGhTcRkA,'cast':EOUiJmnDLxaHIzSrQwspgWNGhTcRof,'director':EOUiJmnDLxaHIzSrQwspgWNGhTcRoq,'genre':EOUiJmnDLxaHIzSrQwspgWNGhTcRoA,'plot':'%s\n%s\n%s\n\n%s'%(EOUiJmnDLxaHIzSrQwspgWNGhTcRkA,EOUiJmnDLxaHIzSrQwspgWNGhTcRkv,EOUiJmnDLxaHIzSrQwspgWNGhTcRoF,EOUiJmnDLxaHIzSrQwspgWNGhTcRod),'year':EOUiJmnDLxaHIzSrQwspgWNGhTcRoX,'mpaa':EOUiJmnDLxaHIzSrQwspgWNGhTcRoe,'premiered':EOUiJmnDLxaHIzSrQwspgWNGhTcRob}
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkf={'mode':'LIVE','mediacode':EOUiJmnDLxaHIzSrQwspgWNGhTcRoM.get('mediacode'),'stype':EOUiJmnDLxaHIzSrQwspgWNGhTcRoy}
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.add_dir(EOUiJmnDLxaHIzSrQwspgWNGhTcRkA,sublabel=EOUiJmnDLxaHIzSrQwspgWNGhTcRkv,img=EOUiJmnDLxaHIzSrQwspgWNGhTcRoP,infoLabels=EOUiJmnDLxaHIzSrQwspgWNGhTcRot,isFolder=EOUiJmnDLxaHIzSrQwspgWNGhTcRlt,params=EOUiJmnDLxaHIzSrQwspgWNGhTcRkf,ContextMenu=EOUiJmnDLxaHIzSrQwspgWNGhTcRle)
  if EOUiJmnDLxaHIzSrQwspgWNGhTcRoY:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkf['mode']='CHANNEL' 
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkf['stype']=EOUiJmnDLxaHIzSrQwspgWNGhTcRoy 
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkf['page']=EOUiJmnDLxaHIzSrQwspgWNGhTcRlu(EOUiJmnDLxaHIzSrQwspgWNGhTcRol+1)
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkv='[B]%s >>[/B]'%'다음 페이지'
   EOUiJmnDLxaHIzSrQwspgWNGhTcRoB=EOUiJmnDLxaHIzSrQwspgWNGhTcRlu(EOUiJmnDLxaHIzSrQwspgWNGhTcRol+1)
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.add_dir(EOUiJmnDLxaHIzSrQwspgWNGhTcRkv,sublabel=EOUiJmnDLxaHIzSrQwspgWNGhTcRoB,img='',infoLabels=EOUiJmnDLxaHIzSrQwspgWNGhTcRle,isFolder=EOUiJmnDLxaHIzSrQwspgWNGhTcRlB,params=EOUiJmnDLxaHIzSrQwspgWNGhTcRkf,ContextMenu=EOUiJmnDLxaHIzSrQwspgWNGhTcRle)
  if EOUiJmnDLxaHIzSrQwspgWNGhTcRlC(EOUiJmnDLxaHIzSrQwspgWNGhTcRov)>0:xbmcplugin.endOfDirectory(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd._addon_handle,cacheToDisc=EOUiJmnDLxaHIzSrQwspgWNGhTcRlt)
 def dp_Program_List(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd,EOUiJmnDLxaHIzSrQwspgWNGhTcRoV):
  EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.TvingObj.SaveCredential(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.get_winCredential())
  EOUiJmnDLxaHIzSrQwspgWNGhTcRoC =EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('stype')
  EOUiJmnDLxaHIzSrQwspgWNGhTcRou =EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('orderby')
  EOUiJmnDLxaHIzSrQwspgWNGhTcRol =EOUiJmnDLxaHIzSrQwspgWNGhTcRlb(EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('page'))
  EOUiJmnDLxaHIzSrQwspgWNGhTcRoK=EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('genreCode')
  if EOUiJmnDLxaHIzSrQwspgWNGhTcRoK==EOUiJmnDLxaHIzSrQwspgWNGhTcRle:EOUiJmnDLxaHIzSrQwspgWNGhTcRoK='all'
  EOUiJmnDLxaHIzSrQwspgWNGhTcRjy,EOUiJmnDLxaHIzSrQwspgWNGhTcRoY=EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.TvingObj.GetProgramList(EOUiJmnDLxaHIzSrQwspgWNGhTcRoC,EOUiJmnDLxaHIzSrQwspgWNGhTcRou,EOUiJmnDLxaHIzSrQwspgWNGhTcRol,EOUiJmnDLxaHIzSrQwspgWNGhTcRoK)
  for EOUiJmnDLxaHIzSrQwspgWNGhTcRjk in EOUiJmnDLxaHIzSrQwspgWNGhTcRjy:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkv =EOUiJmnDLxaHIzSrQwspgWNGhTcRjk.get('title')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRoP =EOUiJmnDLxaHIzSrQwspgWNGhTcRjk.get('thumbnail')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRod =EOUiJmnDLxaHIzSrQwspgWNGhTcRjk.get('synopsis')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRjo =EOUiJmnDLxaHIzSrQwspgWNGhTcRjk.get('channel')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRof =EOUiJmnDLxaHIzSrQwspgWNGhTcRjk.get('cast')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRoq =EOUiJmnDLxaHIzSrQwspgWNGhTcRjk.get('director')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRoA=EOUiJmnDLxaHIzSrQwspgWNGhTcRjk.get('info_genre')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRoX =EOUiJmnDLxaHIzSrQwspgWNGhTcRjk.get('year')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRob =EOUiJmnDLxaHIzSrQwspgWNGhTcRjk.get('premiered')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRoe =EOUiJmnDLxaHIzSrQwspgWNGhTcRjk.get('mpaa')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRot={'mediatype':'tvshow','title':EOUiJmnDLxaHIzSrQwspgWNGhTcRkv,'studio':EOUiJmnDLxaHIzSrQwspgWNGhTcRjo,'cast':EOUiJmnDLxaHIzSrQwspgWNGhTcRof,'director':EOUiJmnDLxaHIzSrQwspgWNGhTcRoq,'genre':EOUiJmnDLxaHIzSrQwspgWNGhTcRoA,'year':EOUiJmnDLxaHIzSrQwspgWNGhTcRoX,'premiered':EOUiJmnDLxaHIzSrQwspgWNGhTcRob,'mpaa':EOUiJmnDLxaHIzSrQwspgWNGhTcRoe,'plot':'%s <%s>\n\n%s'%(EOUiJmnDLxaHIzSrQwspgWNGhTcRkv,EOUiJmnDLxaHIzSrQwspgWNGhTcRjo,EOUiJmnDLxaHIzSrQwspgWNGhTcRod)}
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkf={'mode':'EPISODE','programcode':EOUiJmnDLxaHIzSrQwspgWNGhTcRjk.get('program'),'page':'1'}
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.add_dir(EOUiJmnDLxaHIzSrQwspgWNGhTcRkv,sublabel=EOUiJmnDLxaHIzSrQwspgWNGhTcRjo,img=EOUiJmnDLxaHIzSrQwspgWNGhTcRoP,infoLabels=EOUiJmnDLxaHIzSrQwspgWNGhTcRot,isFolder=EOUiJmnDLxaHIzSrQwspgWNGhTcRlB,params=EOUiJmnDLxaHIzSrQwspgWNGhTcRkf,ContextMenu=EOUiJmnDLxaHIzSrQwspgWNGhTcRle)
  if EOUiJmnDLxaHIzSrQwspgWNGhTcRoY:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkf['mode'] ='PROGRAM' 
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkf['stype'] =EOUiJmnDLxaHIzSrQwspgWNGhTcRoC
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkf['orderby'] =EOUiJmnDLxaHIzSrQwspgWNGhTcRou
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkf['page'] =EOUiJmnDLxaHIzSrQwspgWNGhTcRlu(EOUiJmnDLxaHIzSrQwspgWNGhTcRol+1)
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkf['genreCode']=EOUiJmnDLxaHIzSrQwspgWNGhTcRoK 
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkv='[B]%s >>[/B]'%'다음 페이지'
   EOUiJmnDLxaHIzSrQwspgWNGhTcRoB=EOUiJmnDLxaHIzSrQwspgWNGhTcRlu(EOUiJmnDLxaHIzSrQwspgWNGhTcRol+1)
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.add_dir(EOUiJmnDLxaHIzSrQwspgWNGhTcRkv,sublabel=EOUiJmnDLxaHIzSrQwspgWNGhTcRoB,img='',infoLabels=EOUiJmnDLxaHIzSrQwspgWNGhTcRle,isFolder=EOUiJmnDLxaHIzSrQwspgWNGhTcRlB,params=EOUiJmnDLxaHIzSrQwspgWNGhTcRkf,ContextMenu=EOUiJmnDLxaHIzSrQwspgWNGhTcRle)
  if EOUiJmnDLxaHIzSrQwspgWNGhTcRlC(EOUiJmnDLxaHIzSrQwspgWNGhTcRjy)>0:xbmcplugin.endOfDirectory(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd._addon_handle,cacheToDisc=EOUiJmnDLxaHIzSrQwspgWNGhTcRlt)
 def dp_Episode_List(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd,EOUiJmnDLxaHIzSrQwspgWNGhTcRoV):
  EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.TvingObj.SaveCredential(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.get_winCredential())
  EOUiJmnDLxaHIzSrQwspgWNGhTcRjV=EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('programcode')
  EOUiJmnDLxaHIzSrQwspgWNGhTcRol =EOUiJmnDLxaHIzSrQwspgWNGhTcRlb(EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('page'))
  EOUiJmnDLxaHIzSrQwspgWNGhTcRjl,EOUiJmnDLxaHIzSrQwspgWNGhTcRoY,EOUiJmnDLxaHIzSrQwspgWNGhTcRjv=EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.TvingObj.GetEpisodeList(EOUiJmnDLxaHIzSrQwspgWNGhTcRjV,EOUiJmnDLxaHIzSrQwspgWNGhTcRol,orderby=EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.get_winEpisodeOrderby())
  for EOUiJmnDLxaHIzSrQwspgWNGhTcRjY in EOUiJmnDLxaHIzSrQwspgWNGhTcRjl:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkv =EOUiJmnDLxaHIzSrQwspgWNGhTcRjY.get('title')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRoB =EOUiJmnDLxaHIzSrQwspgWNGhTcRjY.get('subtitle')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRoP =EOUiJmnDLxaHIzSrQwspgWNGhTcRjY.get('thumbnail')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRod =EOUiJmnDLxaHIzSrQwspgWNGhTcRjY.get('synopsis')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRjM=EOUiJmnDLxaHIzSrQwspgWNGhTcRjY.get('info_title')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRjP =EOUiJmnDLxaHIzSrQwspgWNGhTcRjY.get('aired')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRjd =EOUiJmnDLxaHIzSrQwspgWNGhTcRjY.get('studio')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRjF =EOUiJmnDLxaHIzSrQwspgWNGhTcRjY.get('frequency')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRot={'mediatype':'episode','title':EOUiJmnDLxaHIzSrQwspgWNGhTcRjM,'aired':EOUiJmnDLxaHIzSrQwspgWNGhTcRjP,'studio':EOUiJmnDLxaHIzSrQwspgWNGhTcRjd,'episode':EOUiJmnDLxaHIzSrQwspgWNGhTcRjF,'plot':'%s\n\n%s'%(EOUiJmnDLxaHIzSrQwspgWNGhTcRkv,EOUiJmnDLxaHIzSrQwspgWNGhTcRod)}
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkf={'mode':'VOD','mediacode':EOUiJmnDLxaHIzSrQwspgWNGhTcRjY.get('episode'),'stype':'vod','programcode':EOUiJmnDLxaHIzSrQwspgWNGhTcRjV,'title':EOUiJmnDLxaHIzSrQwspgWNGhTcRkv,'thumbnail':EOUiJmnDLxaHIzSrQwspgWNGhTcRoP}
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.add_dir(EOUiJmnDLxaHIzSrQwspgWNGhTcRkv,sublabel=EOUiJmnDLxaHIzSrQwspgWNGhTcRoB,img=EOUiJmnDLxaHIzSrQwspgWNGhTcRoP,infoLabels=EOUiJmnDLxaHIzSrQwspgWNGhTcRot,isFolder=EOUiJmnDLxaHIzSrQwspgWNGhTcRlt,params=EOUiJmnDLxaHIzSrQwspgWNGhTcRkf,ContextMenu=EOUiJmnDLxaHIzSrQwspgWNGhTcRle)
  if EOUiJmnDLxaHIzSrQwspgWNGhTcRol==1:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRot={'plot':'정렬순서를 변경합니다.'}
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkf={}
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkf['mode'] ='ORDER_BY' 
   if EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.get_winEpisodeOrderby()=='desc':
    EOUiJmnDLxaHIzSrQwspgWNGhTcRkv='정렬순서변경 : 최신화부터 -> 1회부터'
    EOUiJmnDLxaHIzSrQwspgWNGhTcRkf['orderby']='asc'
   else:
    EOUiJmnDLxaHIzSrQwspgWNGhTcRkv='정렬순서변경 : 1회부터 -> 최신화부터'
    EOUiJmnDLxaHIzSrQwspgWNGhTcRkf['orderby']='desc'
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.add_dir(EOUiJmnDLxaHIzSrQwspgWNGhTcRkv,sublabel='',img='',infoLabels=EOUiJmnDLxaHIzSrQwspgWNGhTcRot,isFolder=EOUiJmnDLxaHIzSrQwspgWNGhTcRlt,params=EOUiJmnDLxaHIzSrQwspgWNGhTcRkf,ContextMenu=EOUiJmnDLxaHIzSrQwspgWNGhTcRle)
  if EOUiJmnDLxaHIzSrQwspgWNGhTcRoY:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkf['mode'] ='EPISODE' 
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkf['programcode']=EOUiJmnDLxaHIzSrQwspgWNGhTcRjV
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkf['page'] =EOUiJmnDLxaHIzSrQwspgWNGhTcRlu(EOUiJmnDLxaHIzSrQwspgWNGhTcRol+1)
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkv='[B]%s >>[/B]'%'다음 페이지'
   EOUiJmnDLxaHIzSrQwspgWNGhTcRoB=EOUiJmnDLxaHIzSrQwspgWNGhTcRlu(EOUiJmnDLxaHIzSrQwspgWNGhTcRol+1)
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.add_dir(EOUiJmnDLxaHIzSrQwspgWNGhTcRkv,sublabel=EOUiJmnDLxaHIzSrQwspgWNGhTcRoB,img='',infoLabels=EOUiJmnDLxaHIzSrQwspgWNGhTcRle,isFolder=EOUiJmnDLxaHIzSrQwspgWNGhTcRlB,params=EOUiJmnDLxaHIzSrQwspgWNGhTcRkf,ContextMenu=EOUiJmnDLxaHIzSrQwspgWNGhTcRle)
  if EOUiJmnDLxaHIzSrQwspgWNGhTcRlC(EOUiJmnDLxaHIzSrQwspgWNGhTcRjl)>0:xbmcplugin.endOfDirectory(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd._addon_handle,cacheToDisc=EOUiJmnDLxaHIzSrQwspgWNGhTcRlB)
 def dp_setEpOrderby(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd,EOUiJmnDLxaHIzSrQwspgWNGhTcRoV):
  EOUiJmnDLxaHIzSrQwspgWNGhTcRou =EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('orderby')
  EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.set_winEpisodeOrderby(EOUiJmnDLxaHIzSrQwspgWNGhTcRou)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd,EOUiJmnDLxaHIzSrQwspgWNGhTcRoV):
  EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.TvingObj.SaveCredential(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.get_winCredential())
  EOUiJmnDLxaHIzSrQwspgWNGhTcRoC =EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('stype')
  EOUiJmnDLxaHIzSrQwspgWNGhTcRou =EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('orderby')
  EOUiJmnDLxaHIzSrQwspgWNGhTcRol=EOUiJmnDLxaHIzSrQwspgWNGhTcRlb(EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('page'))
  EOUiJmnDLxaHIzSrQwspgWNGhTcRjf,EOUiJmnDLxaHIzSrQwspgWNGhTcRoY=EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.TvingObj.GetMovieList(EOUiJmnDLxaHIzSrQwspgWNGhTcRoC,EOUiJmnDLxaHIzSrQwspgWNGhTcRou,EOUiJmnDLxaHIzSrQwspgWNGhTcRol)
  for EOUiJmnDLxaHIzSrQwspgWNGhTcRjq in EOUiJmnDLxaHIzSrQwspgWNGhTcRjf:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkv =EOUiJmnDLxaHIzSrQwspgWNGhTcRjq.get('title')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRoP =EOUiJmnDLxaHIzSrQwspgWNGhTcRjq.get('thumbnail')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRod =EOUiJmnDLxaHIzSrQwspgWNGhTcRjq.get('synopsis')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRjM =EOUiJmnDLxaHIzSrQwspgWNGhTcRjq.get('info_title')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRoX =EOUiJmnDLxaHIzSrQwspgWNGhTcRjq.get('year')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRof =EOUiJmnDLxaHIzSrQwspgWNGhTcRjq.get('cast')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRoq =EOUiJmnDLxaHIzSrQwspgWNGhTcRjq.get('director')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRoA =EOUiJmnDLxaHIzSrQwspgWNGhTcRjq.get('info_genre')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRjA =EOUiJmnDLxaHIzSrQwspgWNGhTcRjq.get('duration')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRob =EOUiJmnDLxaHIzSrQwspgWNGhTcRjq.get('premiered')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRjd =EOUiJmnDLxaHIzSrQwspgWNGhTcRjq.get('studio')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRoe =EOUiJmnDLxaHIzSrQwspgWNGhTcRjq.get('mpaa')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRot={'mediatype':'movie','title':EOUiJmnDLxaHIzSrQwspgWNGhTcRjM,'year':EOUiJmnDLxaHIzSrQwspgWNGhTcRoX,'cast':EOUiJmnDLxaHIzSrQwspgWNGhTcRof,'director':EOUiJmnDLxaHIzSrQwspgWNGhTcRoq,'genre':EOUiJmnDLxaHIzSrQwspgWNGhTcRoA,'duration':EOUiJmnDLxaHIzSrQwspgWNGhTcRjA,'premiered':EOUiJmnDLxaHIzSrQwspgWNGhTcRob,'studio':EOUiJmnDLxaHIzSrQwspgWNGhTcRjd,'mpaa':EOUiJmnDLxaHIzSrQwspgWNGhTcRoe,'plot':'%s\n\n%s'%(EOUiJmnDLxaHIzSrQwspgWNGhTcRkv,EOUiJmnDLxaHIzSrQwspgWNGhTcRod)}
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkf={'mode':'MOVIE','mediacode':EOUiJmnDLxaHIzSrQwspgWNGhTcRjq.get('moviecode'),'stype':'movie','title':EOUiJmnDLxaHIzSrQwspgWNGhTcRkv,'thumbnail':EOUiJmnDLxaHIzSrQwspgWNGhTcRoP}
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.add_dir(EOUiJmnDLxaHIzSrQwspgWNGhTcRkv,sublabel='',img=EOUiJmnDLxaHIzSrQwspgWNGhTcRoP,infoLabels=EOUiJmnDLxaHIzSrQwspgWNGhTcRot,isFolder=EOUiJmnDLxaHIzSrQwspgWNGhTcRlt,params=EOUiJmnDLxaHIzSrQwspgWNGhTcRkf,ContextMenu=EOUiJmnDLxaHIzSrQwspgWNGhTcRle)
  if EOUiJmnDLxaHIzSrQwspgWNGhTcRoY:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkf={}
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkf['mode'] ='MOVIE_SUB' 
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkf['orderby']=EOUiJmnDLxaHIzSrQwspgWNGhTcRou
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkf['stype'] =EOUiJmnDLxaHIzSrQwspgWNGhTcRoC
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkf['page'] =EOUiJmnDLxaHIzSrQwspgWNGhTcRlu(EOUiJmnDLxaHIzSrQwspgWNGhTcRol+1)
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkv='[B]%s >>[/B]'%'다음 페이지'
   EOUiJmnDLxaHIzSrQwspgWNGhTcRoB=EOUiJmnDLxaHIzSrQwspgWNGhTcRlu(EOUiJmnDLxaHIzSrQwspgWNGhTcRol+1)
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.add_dir(EOUiJmnDLxaHIzSrQwspgWNGhTcRkv,sublabel=EOUiJmnDLxaHIzSrQwspgWNGhTcRoB,img='',infoLabels=EOUiJmnDLxaHIzSrQwspgWNGhTcRle,isFolder=EOUiJmnDLxaHIzSrQwspgWNGhTcRlB,params=EOUiJmnDLxaHIzSrQwspgWNGhTcRkf,ContextMenu=EOUiJmnDLxaHIzSrQwspgWNGhTcRle)
  if EOUiJmnDLxaHIzSrQwspgWNGhTcRlC(EOUiJmnDLxaHIzSrQwspgWNGhTcRjf)>0:xbmcplugin.endOfDirectory(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd._addon_handle,cacheToDisc=EOUiJmnDLxaHIzSrQwspgWNGhTcRlt)
 def dp_Strm_Make(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd,EOUiJmnDLxaHIzSrQwspgWNGhTcRoV):
  EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.addon_noti('aa')
 def dp_Search_Group(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd,EOUiJmnDLxaHIzSrQwspgWNGhTcRoV):
  for EOUiJmnDLxaHIzSrQwspgWNGhTcRoj in EOUiJmnDLxaHIzSrQwspgWNGhTcRyl:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkv=EOUiJmnDLxaHIzSrQwspgWNGhTcRoj.get('title')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkf={'mode':EOUiJmnDLxaHIzSrQwspgWNGhTcRoj.get('mode'),'stype':EOUiJmnDLxaHIzSrQwspgWNGhTcRoj.get('stype'),'page':'1'}
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.add_dir(EOUiJmnDLxaHIzSrQwspgWNGhTcRkv,sublabel='',img='',infoLabels=EOUiJmnDLxaHIzSrQwspgWNGhTcRle,isFolder=EOUiJmnDLxaHIzSrQwspgWNGhTcRlB,params=EOUiJmnDLxaHIzSrQwspgWNGhTcRkf,ContextMenu=EOUiJmnDLxaHIzSrQwspgWNGhTcRle)
  if EOUiJmnDLxaHIzSrQwspgWNGhTcRlC(EOUiJmnDLxaHIzSrQwspgWNGhTcRyl)>0:xbmcplugin.endOfDirectory(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd._addon_handle)
 def dp_Search_List(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd,EOUiJmnDLxaHIzSrQwspgWNGhTcRoV):
  EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.TvingObj.SaveCredential(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.get_winCredential())
  EOUiJmnDLxaHIzSrQwspgWNGhTcRjX =__addon__.getSetting('id')
  EOUiJmnDLxaHIzSrQwspgWNGhTcRol =EOUiJmnDLxaHIzSrQwspgWNGhTcRlb(EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('page'))
  EOUiJmnDLxaHIzSrQwspgWNGhTcRoy =EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('stype')
  if 'search_key' in EOUiJmnDLxaHIzSrQwspgWNGhTcRoV:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRje=EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('search_key')
  else:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRje=EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not EOUiJmnDLxaHIzSrQwspgWNGhTcRje:return
  EOUiJmnDLxaHIzSrQwspgWNGhTcRjb,EOUiJmnDLxaHIzSrQwspgWNGhTcRoY=EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.TvingObj.GetSearchList(EOUiJmnDLxaHIzSrQwspgWNGhTcRje,EOUiJmnDLxaHIzSrQwspgWNGhTcRjX,EOUiJmnDLxaHIzSrQwspgWNGhTcRol,EOUiJmnDLxaHIzSrQwspgWNGhTcRoy)
  if EOUiJmnDLxaHIzSrQwspgWNGhTcRlC(EOUiJmnDLxaHIzSrQwspgWNGhTcRjb)==0:return
  for EOUiJmnDLxaHIzSrQwspgWNGhTcRjt in EOUiJmnDLxaHIzSrQwspgWNGhTcRjb:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkv =EOUiJmnDLxaHIzSrQwspgWNGhTcRjt.get('title')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRoP =EOUiJmnDLxaHIzSrQwspgWNGhTcRjt.get('thumbnail')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRod =EOUiJmnDLxaHIzSrQwspgWNGhTcRjt.get('synopsis')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRjB =EOUiJmnDLxaHIzSrQwspgWNGhTcRjt.get('program')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRof =EOUiJmnDLxaHIzSrQwspgWNGhTcRjt.get('cast')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRoq =EOUiJmnDLxaHIzSrQwspgWNGhTcRjt.get('director')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRoA=EOUiJmnDLxaHIzSrQwspgWNGhTcRjt.get('info_genre')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRjA =EOUiJmnDLxaHIzSrQwspgWNGhTcRjt.get('duration')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRoe =EOUiJmnDLxaHIzSrQwspgWNGhTcRjt.get('mpaa')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRoX =EOUiJmnDLxaHIzSrQwspgWNGhTcRjt.get('year')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRjP =EOUiJmnDLxaHIzSrQwspgWNGhTcRjt.get('aired')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRot={'mediatype':'tvshow' if EOUiJmnDLxaHIzSrQwspgWNGhTcRoy=='vod' else 'movie','title':EOUiJmnDLxaHIzSrQwspgWNGhTcRkv,'cast':EOUiJmnDLxaHIzSrQwspgWNGhTcRof,'director':EOUiJmnDLxaHIzSrQwspgWNGhTcRoq,'genre':EOUiJmnDLxaHIzSrQwspgWNGhTcRoA,'duration':EOUiJmnDLxaHIzSrQwspgWNGhTcRjA,'mpaa':EOUiJmnDLxaHIzSrQwspgWNGhTcRoe,'year':EOUiJmnDLxaHIzSrQwspgWNGhTcRoX,'aired':EOUiJmnDLxaHIzSrQwspgWNGhTcRjP,'plot':'%s\n\n%s'%(EOUiJmnDLxaHIzSrQwspgWNGhTcRkv,EOUiJmnDLxaHIzSrQwspgWNGhTcRod)}
   if EOUiJmnDLxaHIzSrQwspgWNGhTcRoy=='vod':
    EOUiJmnDLxaHIzSrQwspgWNGhTcRkf={'mode':'EPISODE','programcode':EOUiJmnDLxaHIzSrQwspgWNGhTcRjt.get('program'),'page':'1'}
    EOUiJmnDLxaHIzSrQwspgWNGhTcRkq=EOUiJmnDLxaHIzSrQwspgWNGhTcRlB
   else:
    EOUiJmnDLxaHIzSrQwspgWNGhTcRkf={'mode':'MOVIE','mediacode':EOUiJmnDLxaHIzSrQwspgWNGhTcRjt.get('movie'),'stype':'movie','title':EOUiJmnDLxaHIzSrQwspgWNGhTcRkv,'thumbnail':EOUiJmnDLxaHIzSrQwspgWNGhTcRoP}
    EOUiJmnDLxaHIzSrQwspgWNGhTcRkq=EOUiJmnDLxaHIzSrQwspgWNGhTcRlt
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.add_dir(EOUiJmnDLxaHIzSrQwspgWNGhTcRkv,sublabel='',img=EOUiJmnDLxaHIzSrQwspgWNGhTcRoP,infoLabels=EOUiJmnDLxaHIzSrQwspgWNGhTcRot,isFolder=EOUiJmnDLxaHIzSrQwspgWNGhTcRkq,params=EOUiJmnDLxaHIzSrQwspgWNGhTcRkf,ContextMenu=EOUiJmnDLxaHIzSrQwspgWNGhTcRle)
  if EOUiJmnDLxaHIzSrQwspgWNGhTcRoY:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkf['mode'] ='SEARCH' 
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkf['search_key']=EOUiJmnDLxaHIzSrQwspgWNGhTcRje
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkf['page'] =EOUiJmnDLxaHIzSrQwspgWNGhTcRlu(EOUiJmnDLxaHIzSrQwspgWNGhTcRol+1)
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkv='[B]%s >>[/B]'%'다음 페이지'
   EOUiJmnDLxaHIzSrQwspgWNGhTcRoB=EOUiJmnDLxaHIzSrQwspgWNGhTcRlu(EOUiJmnDLxaHIzSrQwspgWNGhTcRol+1)
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.add_dir(EOUiJmnDLxaHIzSrQwspgWNGhTcRkv,sublabel=EOUiJmnDLxaHIzSrQwspgWNGhTcRoB,img='',infoLabels=EOUiJmnDLxaHIzSrQwspgWNGhTcRle,isFolder=EOUiJmnDLxaHIzSrQwspgWNGhTcRlB,params=EOUiJmnDLxaHIzSrQwspgWNGhTcRkf,ContextMenu=EOUiJmnDLxaHIzSrQwspgWNGhTcRle)
  if EOUiJmnDLxaHIzSrQwspgWNGhTcRlC(EOUiJmnDLxaHIzSrQwspgWNGhTcRjb)>0:xbmcplugin.endOfDirectory(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd._addon_handle)
 def Delete_Watched_List(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd,EOUiJmnDLxaHIzSrQwspgWNGhTcRoy):
  try:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRjC=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%EOUiJmnDLxaHIzSrQwspgWNGhTcRoy))
   fp=EOUiJmnDLxaHIzSrQwspgWNGhTcRlK(EOUiJmnDLxaHIzSrQwspgWNGhTcRjC,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRle
 def dp_WatchList_Delete(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd,EOUiJmnDLxaHIzSrQwspgWNGhTcRoV):
  EOUiJmnDLxaHIzSrQwspgWNGhTcRoy=EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('stype')
  EOUiJmnDLxaHIzSrQwspgWNGhTcRyX=xbmcgui.Dialog()
  EOUiJmnDLxaHIzSrQwspgWNGhTcRkB=EOUiJmnDLxaHIzSrQwspgWNGhTcRyX.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if EOUiJmnDLxaHIzSrQwspgWNGhTcRkB==EOUiJmnDLxaHIzSrQwspgWNGhTcRlt:sys.exit()
  EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.Delete_Watched_List(EOUiJmnDLxaHIzSrQwspgWNGhTcRoy)
  xbmc.executebuiltin("Container.Refresh")
 def Load_Watched_List(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd,EOUiJmnDLxaHIzSrQwspgWNGhTcRoy):
  try:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRjC=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%EOUiJmnDLxaHIzSrQwspgWNGhTcRoy))
   fp=EOUiJmnDLxaHIzSrQwspgWNGhTcRlK(EOUiJmnDLxaHIzSrQwspgWNGhTcRjC,'r',-1,'utf-8')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRju=fp.readlines()
   fp.close()
  except:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRju=[]
  return EOUiJmnDLxaHIzSrQwspgWNGhTcRju
 def Save_Watched_List(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd,EOUiJmnDLxaHIzSrQwspgWNGhTcRoy,EOUiJmnDLxaHIzSrQwspgWNGhTcRyq):
  try:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRjC=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%EOUiJmnDLxaHIzSrQwspgWNGhTcRoy))
   EOUiJmnDLxaHIzSrQwspgWNGhTcRjK=EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.Load_Watched_List(EOUiJmnDLxaHIzSrQwspgWNGhTcRoy) 
   fp=EOUiJmnDLxaHIzSrQwspgWNGhTcRlK(EOUiJmnDLxaHIzSrQwspgWNGhTcRjC,'w',-1,'utf-8')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRVy=urllib.parse.urlencode(EOUiJmnDLxaHIzSrQwspgWNGhTcRyq)
   EOUiJmnDLxaHIzSrQwspgWNGhTcRVy=EOUiJmnDLxaHIzSrQwspgWNGhTcRVy+'\n'
   fp.write(EOUiJmnDLxaHIzSrQwspgWNGhTcRVy)
   EOUiJmnDLxaHIzSrQwspgWNGhTcRVk=0
   for EOUiJmnDLxaHIzSrQwspgWNGhTcRVo in EOUiJmnDLxaHIzSrQwspgWNGhTcRjK:
    EOUiJmnDLxaHIzSrQwspgWNGhTcRVj=EOUiJmnDLxaHIzSrQwspgWNGhTcRvy(urllib.parse.parse_qsl(EOUiJmnDLxaHIzSrQwspgWNGhTcRVo))
    EOUiJmnDLxaHIzSrQwspgWNGhTcRVl=EOUiJmnDLxaHIzSrQwspgWNGhTcRyq.get('code').strip()
    EOUiJmnDLxaHIzSrQwspgWNGhTcRVv=EOUiJmnDLxaHIzSrQwspgWNGhTcRVj.get('code').strip()
    if EOUiJmnDLxaHIzSrQwspgWNGhTcRoy=='vod' and EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.get_settings_direct_replay()==EOUiJmnDLxaHIzSrQwspgWNGhTcRlB:
     EOUiJmnDLxaHIzSrQwspgWNGhTcRVl=EOUiJmnDLxaHIzSrQwspgWNGhTcRyq.get('videoid').strip()
     EOUiJmnDLxaHIzSrQwspgWNGhTcRVv=EOUiJmnDLxaHIzSrQwspgWNGhTcRVj.get('videoid').strip()if EOUiJmnDLxaHIzSrQwspgWNGhTcRVv!=EOUiJmnDLxaHIzSrQwspgWNGhTcRle else '-'
    if EOUiJmnDLxaHIzSrQwspgWNGhTcRVl!=EOUiJmnDLxaHIzSrQwspgWNGhTcRVv:
     fp.write(EOUiJmnDLxaHIzSrQwspgWNGhTcRVo)
     EOUiJmnDLxaHIzSrQwspgWNGhTcRVk+=1
     if EOUiJmnDLxaHIzSrQwspgWNGhTcRVk>=50:break
   fp.close()
  except:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRle
 def dp_Watch_List(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd,EOUiJmnDLxaHIzSrQwspgWNGhTcRoV):
  EOUiJmnDLxaHIzSrQwspgWNGhTcRoy =EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('stype')
  EOUiJmnDLxaHIzSrQwspgWNGhTcRko=EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.get_settings_direct_replay()
  if EOUiJmnDLxaHIzSrQwspgWNGhTcRoy=='-':
   for EOUiJmnDLxaHIzSrQwspgWNGhTcRoj in EOUiJmnDLxaHIzSrQwspgWNGhTcRyV:
    EOUiJmnDLxaHIzSrQwspgWNGhTcRkv=EOUiJmnDLxaHIzSrQwspgWNGhTcRoj.get('title')
    EOUiJmnDLxaHIzSrQwspgWNGhTcRkf={'mode':EOUiJmnDLxaHIzSrQwspgWNGhTcRoj.get('mode'),'stype':EOUiJmnDLxaHIzSrQwspgWNGhTcRoj.get('stype')}
    EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.add_dir(EOUiJmnDLxaHIzSrQwspgWNGhTcRkv,sublabel='',img='',infoLabels=EOUiJmnDLxaHIzSrQwspgWNGhTcRle,isFolder=EOUiJmnDLxaHIzSrQwspgWNGhTcRlB,params=EOUiJmnDLxaHIzSrQwspgWNGhTcRkf,ContextMenu=EOUiJmnDLxaHIzSrQwspgWNGhTcRle)
   if EOUiJmnDLxaHIzSrQwspgWNGhTcRlC(EOUiJmnDLxaHIzSrQwspgWNGhTcRyV)>0:xbmcplugin.endOfDirectory(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd._addon_handle)
  else:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRVY=EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.Load_Watched_List(EOUiJmnDLxaHIzSrQwspgWNGhTcRoy)
   for EOUiJmnDLxaHIzSrQwspgWNGhTcRVM in EOUiJmnDLxaHIzSrQwspgWNGhTcRVY:
    EOUiJmnDLxaHIzSrQwspgWNGhTcRVP=EOUiJmnDLxaHIzSrQwspgWNGhTcRvy(urllib.parse.parse_qsl(EOUiJmnDLxaHIzSrQwspgWNGhTcRVM))
    EOUiJmnDLxaHIzSrQwspgWNGhTcRVd =EOUiJmnDLxaHIzSrQwspgWNGhTcRVP.get('code').strip()
    EOUiJmnDLxaHIzSrQwspgWNGhTcRkv =EOUiJmnDLxaHIzSrQwspgWNGhTcRVP.get('title').strip()
    EOUiJmnDLxaHIzSrQwspgWNGhTcRoP=EOUiJmnDLxaHIzSrQwspgWNGhTcRVP.get('img').strip()
    EOUiJmnDLxaHIzSrQwspgWNGhTcRVF =EOUiJmnDLxaHIzSrQwspgWNGhTcRVP.get('videoid').strip()
    try:
     EOUiJmnDLxaHIzSrQwspgWNGhTcRoP=EOUiJmnDLxaHIzSrQwspgWNGhTcRoP.replace('\'','\"')
     EOUiJmnDLxaHIzSrQwspgWNGhTcRoP=json.loads(EOUiJmnDLxaHIzSrQwspgWNGhTcRoP)
    except:
     EOUiJmnDLxaHIzSrQwspgWNGhTcRle
    EOUiJmnDLxaHIzSrQwspgWNGhTcRot={}
    EOUiJmnDLxaHIzSrQwspgWNGhTcRot['plot']=EOUiJmnDLxaHIzSrQwspgWNGhTcRkv
    if EOUiJmnDLxaHIzSrQwspgWNGhTcRoy=='vod':
     if EOUiJmnDLxaHIzSrQwspgWNGhTcRko==EOUiJmnDLxaHIzSrQwspgWNGhTcRlt or EOUiJmnDLxaHIzSrQwspgWNGhTcRVF==EOUiJmnDLxaHIzSrQwspgWNGhTcRle:
      EOUiJmnDLxaHIzSrQwspgWNGhTcRkf={'mode':'EPISODE','programcode':EOUiJmnDLxaHIzSrQwspgWNGhTcRVd,'page':'1'}
      EOUiJmnDLxaHIzSrQwspgWNGhTcRkq=EOUiJmnDLxaHIzSrQwspgWNGhTcRlB
     else:
      EOUiJmnDLxaHIzSrQwspgWNGhTcRkf={'mode':'VOD','mediacode':EOUiJmnDLxaHIzSrQwspgWNGhTcRVF,'stype':'vod','programcode':EOUiJmnDLxaHIzSrQwspgWNGhTcRVd,'title':EOUiJmnDLxaHIzSrQwspgWNGhTcRkv,'thumbnail':EOUiJmnDLxaHIzSrQwspgWNGhTcRoP}
      EOUiJmnDLxaHIzSrQwspgWNGhTcRkq=EOUiJmnDLxaHIzSrQwspgWNGhTcRlt
    else:
     EOUiJmnDLxaHIzSrQwspgWNGhTcRkf={'mode':'MOVIE','mediacode':EOUiJmnDLxaHIzSrQwspgWNGhTcRVd,'stype':'movie','title':EOUiJmnDLxaHIzSrQwspgWNGhTcRkv,'thumbnail':EOUiJmnDLxaHIzSrQwspgWNGhTcRoP}
     EOUiJmnDLxaHIzSrQwspgWNGhTcRkq=EOUiJmnDLxaHIzSrQwspgWNGhTcRlt
    EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.add_dir(EOUiJmnDLxaHIzSrQwspgWNGhTcRkv,sublabel='',img=EOUiJmnDLxaHIzSrQwspgWNGhTcRoP,infoLabels=EOUiJmnDLxaHIzSrQwspgWNGhTcRot,isFolder=EOUiJmnDLxaHIzSrQwspgWNGhTcRkq,params=EOUiJmnDLxaHIzSrQwspgWNGhTcRkf,ContextMenu=EOUiJmnDLxaHIzSrQwspgWNGhTcRle)
   EOUiJmnDLxaHIzSrQwspgWNGhTcRot={'plot':'시청목록을 삭제합니다.'}
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkv='*** 시청목록 삭제 ***'
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkf={'mode':'MYVIEW_REMOVE','stype':EOUiJmnDLxaHIzSrQwspgWNGhTcRoy}
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.add_dir(EOUiJmnDLxaHIzSrQwspgWNGhTcRkv,sublabel='',img='',infoLabels=EOUiJmnDLxaHIzSrQwspgWNGhTcRot,isFolder=EOUiJmnDLxaHIzSrQwspgWNGhTcRlt,params=EOUiJmnDLxaHIzSrQwspgWNGhTcRkf,ContextMenu=EOUiJmnDLxaHIzSrQwspgWNGhTcRle)
   xbmcplugin.endOfDirectory(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd._addon_handle,cacheToDisc=EOUiJmnDLxaHIzSrQwspgWNGhTcRlt)
 def play_VIDEO(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd,EOUiJmnDLxaHIzSrQwspgWNGhTcRoV):
  EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.TvingObj.SaveCredential(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.get_winCredential())
  EOUiJmnDLxaHIzSrQwspgWNGhTcRVq =EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('mediacode')
  EOUiJmnDLxaHIzSrQwspgWNGhTcRoy =EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('stype')
  EOUiJmnDLxaHIzSrQwspgWNGhTcRVA =EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('pvrmode')
  EOUiJmnDLxaHIzSrQwspgWNGhTcRVX=EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.get_selQuality(EOUiJmnDLxaHIzSrQwspgWNGhTcRoy)
  EOUiJmnDLxaHIzSrQwspgWNGhTcRVe,EOUiJmnDLxaHIzSrQwspgWNGhTcRVb=EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.TvingObj.GetBroadURL(EOUiJmnDLxaHIzSrQwspgWNGhTcRVq,EOUiJmnDLxaHIzSrQwspgWNGhTcRVX,EOUiJmnDLxaHIzSrQwspgWNGhTcRoy,EOUiJmnDLxaHIzSrQwspgWNGhTcRVA)
  EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.addon_log('qt, stype, url : %s - %s - %s'%(EOUiJmnDLxaHIzSrQwspgWNGhTcRlu(EOUiJmnDLxaHIzSrQwspgWNGhTcRVX),EOUiJmnDLxaHIzSrQwspgWNGhTcRoy,EOUiJmnDLxaHIzSrQwspgWNGhTcRVe))
  if EOUiJmnDLxaHIzSrQwspgWNGhTcRVe=='':
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.addon_noti(__language__(30908).encode('utf8'))
   return
  EOUiJmnDLxaHIzSrQwspgWNGhTcRVt =EOUiJmnDLxaHIzSrQwspgWNGhTcRVe.find('Policy=')
  if EOUiJmnDLxaHIzSrQwspgWNGhTcRVt!=-1:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRVB =EOUiJmnDLxaHIzSrQwspgWNGhTcRVe.split('?')[0]
   EOUiJmnDLxaHIzSrQwspgWNGhTcRVC=EOUiJmnDLxaHIzSrQwspgWNGhTcRvy(urllib.parse.parse_qsl(urllib.parse.urlsplit(EOUiJmnDLxaHIzSrQwspgWNGhTcRVe).query))
   EOUiJmnDLxaHIzSrQwspgWNGhTcRVC=urllib.parse.urlencode(EOUiJmnDLxaHIzSrQwspgWNGhTcRVC)
   EOUiJmnDLxaHIzSrQwspgWNGhTcRVC=EOUiJmnDLxaHIzSrQwspgWNGhTcRVC.replace('&',';')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRVC=EOUiJmnDLxaHIzSrQwspgWNGhTcRVC.replace('Policy','CloudFront-Policy')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRVC=EOUiJmnDLxaHIzSrQwspgWNGhTcRVC.replace('Signature','CloudFront-Signature')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRVC=EOUiJmnDLxaHIzSrQwspgWNGhTcRVC.replace('Key-Pair-Id','CloudFront-Key-Pair-Id')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRVu='%s|Cookie=%s'%(EOUiJmnDLxaHIzSrQwspgWNGhTcRVB,EOUiJmnDLxaHIzSrQwspgWNGhTcRVC)
  else:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRVu=EOUiJmnDLxaHIzSrQwspgWNGhTcRVe
  EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.addon_log(EOUiJmnDLxaHIzSrQwspgWNGhTcRVu)
  EOUiJmnDLxaHIzSrQwspgWNGhTcRVK=xbmcgui.ListItem(path=EOUiJmnDLxaHIzSrQwspgWNGhTcRVu)
  if EOUiJmnDLxaHIzSrQwspgWNGhTcRVb!='':
   EOUiJmnDLxaHIzSrQwspgWNGhTcRly=EOUiJmnDLxaHIzSrQwspgWNGhTcRVb
   EOUiJmnDLxaHIzSrQwspgWNGhTcRlk ='https://cj.drmkeyserver.com/widevine_license'
   EOUiJmnDLxaHIzSrQwspgWNGhTcRlo ='mpd'
   EOUiJmnDLxaHIzSrQwspgWNGhTcRlj ='com.widevine.alpha'
   EOUiJmnDLxaHIzSrQwspgWNGhTcRlV =inputstreamhelper.Helper(EOUiJmnDLxaHIzSrQwspgWNGhTcRlo,drm='widevine')
   if EOUiJmnDLxaHIzSrQwspgWNGhTcRlV.check_inputstream():
    EOUiJmnDLxaHIzSrQwspgWNGhTcRlv={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/live/player/%s'%EOUiJmnDLxaHIzSrQwspgWNGhTcRVq,'sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.TvingObj.USER_AGENT,'AcquireLicenseAssertion':EOUiJmnDLxaHIzSrQwspgWNGhTcRly,'Host':'cj.drmkeyserver.com'}
    EOUiJmnDLxaHIzSrQwspgWNGhTcRlY=EOUiJmnDLxaHIzSrQwspgWNGhTcRlk+'|'+urllib.parse.urlencode(EOUiJmnDLxaHIzSrQwspgWNGhTcRlv)+'|R{SSM}|'
    EOUiJmnDLxaHIzSrQwspgWNGhTcRVK.setProperty('inputstream',EOUiJmnDLxaHIzSrQwspgWNGhTcRlV.inputstream_addon)
    EOUiJmnDLxaHIzSrQwspgWNGhTcRVK.setProperty('inputstream.adaptive.manifest_type',EOUiJmnDLxaHIzSrQwspgWNGhTcRlo)
    EOUiJmnDLxaHIzSrQwspgWNGhTcRVK.setProperty('inputstream.adaptive.license_type',EOUiJmnDLxaHIzSrQwspgWNGhTcRlj)
    EOUiJmnDLxaHIzSrQwspgWNGhTcRVK.setProperty('inputstream.adaptive.license_key',EOUiJmnDLxaHIzSrQwspgWNGhTcRlY)
    EOUiJmnDLxaHIzSrQwspgWNGhTcRVK.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.TvingObj.USER_AGENT))
  xbmcplugin.setResolvedUrl(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd._addon_handle,EOUiJmnDLxaHIzSrQwspgWNGhTcRlB,EOUiJmnDLxaHIzSrQwspgWNGhTcRVK)
  try:
   if EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('mode')in['VOD','MOVIE']and EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('title'):
    EOUiJmnDLxaHIzSrQwspgWNGhTcRkf={'code':EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('programcode')if EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('mode')=='VOD' else EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('mediacode'),'img':EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('thumbnail'),'title':EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('title'),'videoid':EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('mediacode')}
    EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.Save_Watched_List(EOUiJmnDLxaHIzSrQwspgWNGhTcRoV.get('stype'),EOUiJmnDLxaHIzSrQwspgWNGhTcRkf)
  except:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRle
 def logout(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd):
  EOUiJmnDLxaHIzSrQwspgWNGhTcRyX=xbmcgui.Dialog()
  EOUiJmnDLxaHIzSrQwspgWNGhTcRkB=EOUiJmnDLxaHIzSrQwspgWNGhTcRyX.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if EOUiJmnDLxaHIzSrQwspgWNGhTcRkB==EOUiJmnDLxaHIzSrQwspgWNGhTcRlt:sys.exit()
  EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.wininfo_clear()
  if os.path.isfile(EOUiJmnDLxaHIzSrQwspgWNGhTcRyP):os.remove(EOUiJmnDLxaHIzSrQwspgWNGhTcRyP)
  EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd):
  EOUiJmnDLxaHIzSrQwspgWNGhTcRkj=xbmcgui.Window(10000)
  EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.setProperty('TVING_M_TOKEN','')
  EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.setProperty('TVING_M_USERINFO','')
  EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.setProperty('TVING_M_UUID','')
  EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.setProperty('TVING_M_LOGINTIME','')
  EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.setProperty('TVING_M_MAINTOKEN','')
  EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.setProperty('TVING_M_COOKIEKEY','')
  EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.setProperty('TVING_M_LOCKKEY','')
 def cookiefile_save(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd):
  EOUiJmnDLxaHIzSrQwspgWNGhTcRlM =EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.TvingObj.Get_Now_Datetime()
  EOUiJmnDLxaHIzSrQwspgWNGhTcRlP=EOUiJmnDLxaHIzSrQwspgWNGhTcRlM+datetime.timedelta(days=EOUiJmnDLxaHIzSrQwspgWNGhTcRlb(__addon__.getSetting('cache_ttl')))
  EOUiJmnDLxaHIzSrQwspgWNGhTcRkj=xbmcgui.Window(10000)
  EOUiJmnDLxaHIzSrQwspgWNGhTcRld={'tving_token':EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.getProperty('TVING_M_TOKEN'),'tving_userinfo':EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.getProperty('TVING_M_USERINFO'),'tving_uuid':EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.getProperty('TVING_M_UUID'),'tving_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'tving_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'tving_logintype':__addon__.getSetting('login_type'),'tving_profile':__addon__.getSetting('selected_profile'),'tving_limitdate':EOUiJmnDLxaHIzSrQwspgWNGhTcRlP.strftime('%Y-%m-%d'),'tving_maintoken':EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.getProperty('TVING_M_LOCKKEY')}
  try: 
   fp=EOUiJmnDLxaHIzSrQwspgWNGhTcRlK(EOUiJmnDLxaHIzSrQwspgWNGhTcRyP,'w',-1,'utf-8')
   json.dump(EOUiJmnDLxaHIzSrQwspgWNGhTcRld,fp)
   fp.close()
  except EOUiJmnDLxaHIzSrQwspgWNGhTcRvk as exception:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRvo(exception)
 def cookiefile_check(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd):
  EOUiJmnDLxaHIzSrQwspgWNGhTcRld={}
  try: 
   fp=EOUiJmnDLxaHIzSrQwspgWNGhTcRlK(EOUiJmnDLxaHIzSrQwspgWNGhTcRyP,'r',-1,'utf-8')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRld= json.load(fp)
   fp.close()
  except EOUiJmnDLxaHIzSrQwspgWNGhTcRvk as exception:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.wininfo_clear()
   return EOUiJmnDLxaHIzSrQwspgWNGhTcRlt
  EOUiJmnDLxaHIzSrQwspgWNGhTcRkX =__addon__.getSetting('id')
  EOUiJmnDLxaHIzSrQwspgWNGhTcRke =__addon__.getSetting('pw')
  EOUiJmnDLxaHIzSrQwspgWNGhTcRlF=__addon__.getSetting('login_type')
  EOUiJmnDLxaHIzSrQwspgWNGhTcRlf =__addon__.getSetting('selected_profile')
  EOUiJmnDLxaHIzSrQwspgWNGhTcRld['tving_id']=base64.standard_b64decode(EOUiJmnDLxaHIzSrQwspgWNGhTcRld['tving_id']).decode('utf-8')
  EOUiJmnDLxaHIzSrQwspgWNGhTcRld['tving_pw']=base64.standard_b64decode(EOUiJmnDLxaHIzSrQwspgWNGhTcRld['tving_pw']).decode('utf-8')
  try:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRld['tving_profile']
  except:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRld['tving_profile']='0'
  if EOUiJmnDLxaHIzSrQwspgWNGhTcRkX!=EOUiJmnDLxaHIzSrQwspgWNGhTcRld['tving_id']or EOUiJmnDLxaHIzSrQwspgWNGhTcRke!=EOUiJmnDLxaHIzSrQwspgWNGhTcRld['tving_pw']or EOUiJmnDLxaHIzSrQwspgWNGhTcRlF!=EOUiJmnDLxaHIzSrQwspgWNGhTcRld['tving_logintype']or EOUiJmnDLxaHIzSrQwspgWNGhTcRlf!=EOUiJmnDLxaHIzSrQwspgWNGhTcRld['tving_profile']:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.wininfo_clear()
   return EOUiJmnDLxaHIzSrQwspgWNGhTcRlt
  EOUiJmnDLxaHIzSrQwspgWNGhTcRkC =EOUiJmnDLxaHIzSrQwspgWNGhTcRlb(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  EOUiJmnDLxaHIzSrQwspgWNGhTcRlq=EOUiJmnDLxaHIzSrQwspgWNGhTcRld['tving_limitdate']
  EOUiJmnDLxaHIzSrQwspgWNGhTcRku =EOUiJmnDLxaHIzSrQwspgWNGhTcRlb(re.sub('-','',EOUiJmnDLxaHIzSrQwspgWNGhTcRlq))
  if EOUiJmnDLxaHIzSrQwspgWNGhTcRku<EOUiJmnDLxaHIzSrQwspgWNGhTcRkC:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.wininfo_clear()
   return EOUiJmnDLxaHIzSrQwspgWNGhTcRlt
  EOUiJmnDLxaHIzSrQwspgWNGhTcRkj=xbmcgui.Window(10000)
  EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.setProperty('TVING_M_TOKEN',EOUiJmnDLxaHIzSrQwspgWNGhTcRld['tving_token'])
  EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.setProperty('TVING_M_USERINFO',EOUiJmnDLxaHIzSrQwspgWNGhTcRld['tving_userinfo'])
  EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.setProperty('TVING_M_UUID',EOUiJmnDLxaHIzSrQwspgWNGhTcRld['tving_uuid'])
  EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.setProperty('TVING_M_LOGINTIME',EOUiJmnDLxaHIzSrQwspgWNGhTcRlq)
  try:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.setProperty('TVING_M_MAINTOKEN',EOUiJmnDLxaHIzSrQwspgWNGhTcRld['tving_maintoken'])
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.setProperty('TVING_M_COOKIEKEY',EOUiJmnDLxaHIzSrQwspgWNGhTcRld['tving_cookiekey'])
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.setProperty('TVING_M_LOCKKEY',EOUiJmnDLxaHIzSrQwspgWNGhTcRld['tving_lockkey'])
  except:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.setProperty('TVING_M_MAINTOKEN',EOUiJmnDLxaHIzSrQwspgWNGhTcRld['tving_token'])
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.setProperty('TVING_M_COOKIEKEY','Y')
   EOUiJmnDLxaHIzSrQwspgWNGhTcRkj.setProperty('TVING_M_LOCKKEY','N')
  return EOUiJmnDLxaHIzSrQwspgWNGhTcRlB
 def tving_main(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd):
  EOUiJmnDLxaHIzSrQwspgWNGhTcRlA=EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.main_params.get('mode',EOUiJmnDLxaHIzSrQwspgWNGhTcRle)
  if EOUiJmnDLxaHIzSrQwspgWNGhTcRlA=='LOGOUT':
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.logout()
   return
  EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.login_main()
  if EOUiJmnDLxaHIzSrQwspgWNGhTcRlA is EOUiJmnDLxaHIzSrQwspgWNGhTcRle:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.dp_Main_List()
  elif EOUiJmnDLxaHIzSrQwspgWNGhTcRlA in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.dp_Title_Group(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.main_params)
  elif EOUiJmnDLxaHIzSrQwspgWNGhTcRlA in['GLOBAL_GROUP']:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.dp_SubTitle_Group(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.main_params)
  elif EOUiJmnDLxaHIzSrQwspgWNGhTcRlA=='CHANNEL':
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.dp_LiveChannel_List(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.main_params)
  elif EOUiJmnDLxaHIzSrQwspgWNGhTcRlA in['LIVE','VOD','MOVIE']:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.play_VIDEO(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.main_params)
  elif EOUiJmnDLxaHIzSrQwspgWNGhTcRlA=='PROGRAM':
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.dp_Program_List(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.main_params)
  elif EOUiJmnDLxaHIzSrQwspgWNGhTcRlA=='EPISODE':
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.dp_Episode_List(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.main_params)
  elif EOUiJmnDLxaHIzSrQwspgWNGhTcRlA=='MOVIE_SUB':
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.dp_Movie_List(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.main_params)
  elif EOUiJmnDLxaHIzSrQwspgWNGhTcRlA=='SEARCH_GROUP':
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.dp_Search_Group(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.main_params)
  elif EOUiJmnDLxaHIzSrQwspgWNGhTcRlA=='SEARCH':
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.dp_Search_List(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.main_params)
  elif EOUiJmnDLxaHIzSrQwspgWNGhTcRlA=='WATCH':
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.dp_Watch_List(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.main_params)
  elif EOUiJmnDLxaHIzSrQwspgWNGhTcRlA=='MYVIEW_REMOVE':
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.dp_WatchList_Delete(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.main_params)
  elif EOUiJmnDLxaHIzSrQwspgWNGhTcRlA=='ORDER_BY':
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.dp_setEpOrderby(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.main_params)
  elif EOUiJmnDLxaHIzSrQwspgWNGhTcRlA=='MAKE_STRM':
   EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.dp_Strm_Make(EOUiJmnDLxaHIzSrQwspgWNGhTcRyd.main_params)
  else:
   EOUiJmnDLxaHIzSrQwspgWNGhTcRle
# Created by pyminifier (https://github.com/liftoff/pyminifier)
