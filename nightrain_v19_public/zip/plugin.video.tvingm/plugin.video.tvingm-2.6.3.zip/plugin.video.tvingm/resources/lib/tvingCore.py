__author__="NightRain"
PQVMvWJgSYfomasqNiDypthFTzCncU=print
PQVMvWJgSYfomasqNiDypthFTzCncd=ImportError
PQVMvWJgSYfomasqNiDypthFTzCncK=object
PQVMvWJgSYfomasqNiDypthFTzCnck=None
PQVMvWJgSYfomasqNiDypthFTzCncO=False
PQVMvWJgSYfomasqNiDypthFTzCncX=open
PQVMvWJgSYfomasqNiDypthFTzCncH=True
PQVMvWJgSYfomasqNiDypthFTzCncR=len
PQVMvWJgSYfomasqNiDypthFTzCncw=int
PQVMvWJgSYfomasqNiDypthFTzCncA=range
PQVMvWJgSYfomasqNiDypthFTzCnce=Exception
PQVMvWJgSYfomasqNiDypthFTzCncB=str
PQVMvWJgSYfomasqNiDypthFTzCncG=dict
PQVMvWJgSYfomasqNiDypthFTzCncr=list
PQVMvWJgSYfomasqNiDypthFTzCncL=bytes
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
import os
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
try:
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
 PQVMvWJgSYfomasqNiDypthFTzCncU('Cryptodome')
except PQVMvWJgSYfomasqNiDypthFTzCncd:
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
 PQVMvWJgSYfomasqNiDypthFTzCncU('Crypto')
PQVMvWJgSYfomasqNiDypthFTzCnUK={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
PQVMvWJgSYfomasqNiDypthFTzCnUk ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
PQVMvWJgSYfomasqNiDypthFTzCnUO =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
PQVMvWJgSYfomasqNiDypthFTzCnUX=['TP2wgas1K9Q8F7B359108383','TPLYFLt9NxVcJjQhn7Ee0069','_tutB3583','authToken','cs','TSID','accessToken','refreshToken','_tving_token','GA360_USERTYPE_JSON','ADULT_CONFIRM_YN','LEGAL_CONFIRM_YN','TLPUDB35Qhn7',]
class PQVMvWJgSYfomasqNiDypthFTzCnUd(PQVMvWJgSYfomasqNiDypthFTzCncK):
 def __init__(PQVMvWJgSYfomasqNiDypthFTzCnUH):
  PQVMvWJgSYfomasqNiDypthFTzCnUH.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  PQVMvWJgSYfomasqNiDypthFTzCnUH.NETWORKCODE ='CSND0900'
  PQVMvWJgSYfomasqNiDypthFTzCnUH.OSCODE ='CSOD0900' 
  PQVMvWJgSYfomasqNiDypthFTzCnUH.TELECODE ='CSCD0900'
  PQVMvWJgSYfomasqNiDypthFTzCnUH.SCREENCODE ='CSSD0100'
  PQVMvWJgSYfomasqNiDypthFTzCnUH.APIKEY_ATV ='f0f74595d2f123ffc362362e334aeb52' 
  PQVMvWJgSYfomasqNiDypthFTzCnUH.SCREENCODE_ATV ='CSSD1300' 
  PQVMvWJgSYfomasqNiDypthFTzCnUH.LIVE_LIMIT =20 
  PQVMvWJgSYfomasqNiDypthFTzCnUH.VOD_LIMIT =24 
  PQVMvWJgSYfomasqNiDypthFTzCnUH.EPISODE_LIMIT =30 
  PQVMvWJgSYfomasqNiDypthFTzCnUH.SEARCH_LIMIT =30 
  PQVMvWJgSYfomasqNiDypthFTzCnUH.MOVIE_LIMIT =24 
  PQVMvWJgSYfomasqNiDypthFTzCnUH.API_DOMAIN ='https://api.tving.com'
  PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN ='https://image.tving.com'
  PQVMvWJgSYfomasqNiDypthFTzCnUH.SEARCH_DOMAIN ='https://search-api.tving.com'
  PQVMvWJgSYfomasqNiDypthFTzCnUH.LOGIN_DOMAIN ='https://user.tving.com'
  PQVMvWJgSYfomasqNiDypthFTzCnUH.URL_DOMAIN ='https://www.tving.com'
  PQVMvWJgSYfomasqNiDypthFTzCnUH.MOVIE_LITE =['2610061','2610161','261062']
  PQVMvWJgSYfomasqNiDypthFTzCnUH.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
  PQVMvWJgSYfomasqNiDypthFTzCnUH.MODEL ='chrome_126.0.0.0' 
  PQVMvWJgSYfomasqNiDypthFTzCnUH.DEFAULT_HEADER ={'user-agent':PQVMvWJgSYfomasqNiDypthFTzCnUH.USER_AGENT}
  PQVMvWJgSYfomasqNiDypthFTzCnUH.COOKIE_FILE_NAME =''
  PQVMvWJgSYfomasqNiDypthFTzCnUH.TV_SESSION_COOKIES1=''
  PQVMvWJgSYfomasqNiDypthFTzCnUH.TV_SESSION_COOKIES2=''
  PQVMvWJgSYfomasqNiDypthFTzCnUH.TV_STREAM_FILENAME =''
  PQVMvWJgSYfomasqNiDypthFTzCnUH.TV_SESSION_TEXT1 =''
  PQVMvWJgSYfomasqNiDypthFTzCnUH.TV_SESSION_TEXT2 =''
  PQVMvWJgSYfomasqNiDypthFTzCnUH.KodiVersion=20
  PQVMvWJgSYfomasqNiDypthFTzCnUH.TV ={}
  PQVMvWJgSYfomasqNiDypthFTzCnUH.Init_TV_Total()
 def Init_TV_Total(PQVMvWJgSYfomasqNiDypthFTzCnUH):
  PQVMvWJgSYfomasqNiDypthFTzCnUH.TV={'account':{},'cookies':{},}
 def callRequestCookies(PQVMvWJgSYfomasqNiDypthFTzCnUH,jobtype,PQVMvWJgSYfomasqNiDypthFTzCnKR,payload=PQVMvWJgSYfomasqNiDypthFTzCnck,params=PQVMvWJgSYfomasqNiDypthFTzCnck,headers=PQVMvWJgSYfomasqNiDypthFTzCnck,cookies=PQVMvWJgSYfomasqNiDypthFTzCnck,redirects=PQVMvWJgSYfomasqNiDypthFTzCncO):
  PQVMvWJgSYfomasqNiDypthFTzCnUc=PQVMvWJgSYfomasqNiDypthFTzCnUH.DEFAULT_HEADER
  if headers:PQVMvWJgSYfomasqNiDypthFTzCnUc.update(headers)
  if jobtype=='Get':
   PQVMvWJgSYfomasqNiDypthFTzCnUR=requests.get(PQVMvWJgSYfomasqNiDypthFTzCnKR,params=params,headers=PQVMvWJgSYfomasqNiDypthFTzCnUc,cookies=cookies,allow_redirects=redirects)
  else:
   PQVMvWJgSYfomasqNiDypthFTzCnUR=requests.post(PQVMvWJgSYfomasqNiDypthFTzCnKR,data=payload,params=params,headers=PQVMvWJgSYfomasqNiDypthFTzCnUc,cookies=cookies,allow_redirects=redirects)
  PQVMvWJgSYfomasqNiDypthFTzCncU(PQVMvWJgSYfomasqNiDypthFTzCnUR.url)
  return PQVMvWJgSYfomasqNiDypthFTzCnUR
 def JsonFile_Save(PQVMvWJgSYfomasqNiDypthFTzCnUH,filename,PQVMvWJgSYfomasqNiDypthFTzCnUw):
  if filename=='':return PQVMvWJgSYfomasqNiDypthFTzCncO
  try:
   fp=PQVMvWJgSYfomasqNiDypthFTzCncX(filename,'w',-1,'utf-8')
   json.dump(PQVMvWJgSYfomasqNiDypthFTzCnUw,fp,indent=4,ensure_ascii=PQVMvWJgSYfomasqNiDypthFTzCncO)
   fp.close()
  except:
   return PQVMvWJgSYfomasqNiDypthFTzCncO
  return PQVMvWJgSYfomasqNiDypthFTzCncH
 def JsonFile_Load(PQVMvWJgSYfomasqNiDypthFTzCnUH,filename):
  if filename=='':return{}
  try:
   fp=PQVMvWJgSYfomasqNiDypthFTzCncX(filename,'r',-1,'utf-8')
   PQVMvWJgSYfomasqNiDypthFTzCnUe=json.load(fp)
   fp.close()
  except:
   return{}
  return PQVMvWJgSYfomasqNiDypthFTzCnUe
 def TextFile_Save(PQVMvWJgSYfomasqNiDypthFTzCnUH,filename,resText):
  if filename=='':return PQVMvWJgSYfomasqNiDypthFTzCncO
  try:
   fp=PQVMvWJgSYfomasqNiDypthFTzCncX(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return PQVMvWJgSYfomasqNiDypthFTzCncO
  return PQVMvWJgSYfomasqNiDypthFTzCncH
 def Save_session_acount(PQVMvWJgSYfomasqNiDypthFTzCnUH,PQVMvWJgSYfomasqNiDypthFTzCnUB,PQVMvWJgSYfomasqNiDypthFTzCnUG,PQVMvWJgSYfomasqNiDypthFTzCnUr,PQVMvWJgSYfomasqNiDypthFTzCnUL):
  PQVMvWJgSYfomasqNiDypthFTzCnUH.TV['account']['tvid'] =base64.standard_b64encode(PQVMvWJgSYfomasqNiDypthFTzCnUB.encode()).decode('utf-8')
  PQVMvWJgSYfomasqNiDypthFTzCnUH.TV['account']['tvpw'] =base64.standard_b64encode(PQVMvWJgSYfomasqNiDypthFTzCnUG.encode()).decode('utf-8')
  PQVMvWJgSYfomasqNiDypthFTzCnUH.TV['account']['tvtype']=PQVMvWJgSYfomasqNiDypthFTzCnUr 
  PQVMvWJgSYfomasqNiDypthFTzCnUH.TV['account']['tvpf'] =PQVMvWJgSYfomasqNiDypthFTzCnUL 
 def Load_session_acount(PQVMvWJgSYfomasqNiDypthFTzCnUH):
  try:
   PQVMvWJgSYfomasqNiDypthFTzCnUB =base64.standard_b64decode(PQVMvWJgSYfomasqNiDypthFTzCnUH.TV['account']['tvid']).decode('utf-8')
   PQVMvWJgSYfomasqNiDypthFTzCnUG =base64.standard_b64decode(PQVMvWJgSYfomasqNiDypthFTzCnUH.TV['account']['tvpw']).decode('utf-8')
   PQVMvWJgSYfomasqNiDypthFTzCnUr=PQVMvWJgSYfomasqNiDypthFTzCnUH.TV['account']['tvtype']
   PQVMvWJgSYfomasqNiDypthFTzCnUL =PQVMvWJgSYfomasqNiDypthFTzCnUH.TV['account']['tvpf'] 
  except:
   return '','','0',0
  return PQVMvWJgSYfomasqNiDypthFTzCnUB,PQVMvWJgSYfomasqNiDypthFTzCnUG,PQVMvWJgSYfomasqNiDypthFTzCnUr,PQVMvWJgSYfomasqNiDypthFTzCnUL
 def make_stream_header(PQVMvWJgSYfomasqNiDypthFTzCnUH,PQVMvWJgSYfomasqNiDypthFTzCnUx,PQVMvWJgSYfomasqNiDypthFTzCnUI):
  PQVMvWJgSYfomasqNiDypthFTzCnUu=''
  if PQVMvWJgSYfomasqNiDypthFTzCnUI not in[{},PQVMvWJgSYfomasqNiDypthFTzCnck,'']:
   PQVMvWJgSYfomasqNiDypthFTzCnUj=PQVMvWJgSYfomasqNiDypthFTzCncR(PQVMvWJgSYfomasqNiDypthFTzCnUI)
   for PQVMvWJgSYfomasqNiDypthFTzCnUb,PQVMvWJgSYfomasqNiDypthFTzCnUl in PQVMvWJgSYfomasqNiDypthFTzCnUI.items():
    PQVMvWJgSYfomasqNiDypthFTzCnUu+='{}={}'.format(PQVMvWJgSYfomasqNiDypthFTzCnUb,PQVMvWJgSYfomasqNiDypthFTzCnUl)
    PQVMvWJgSYfomasqNiDypthFTzCnUj+=-1
    if PQVMvWJgSYfomasqNiDypthFTzCnUj>0:PQVMvWJgSYfomasqNiDypthFTzCnUu+='; '
   PQVMvWJgSYfomasqNiDypthFTzCnUx['cookie']=PQVMvWJgSYfomasqNiDypthFTzCnUu
  PQVMvWJgSYfomasqNiDypthFTzCnUE=''
  i=0
  for PQVMvWJgSYfomasqNiDypthFTzCnUb,PQVMvWJgSYfomasqNiDypthFTzCnUl in PQVMvWJgSYfomasqNiDypthFTzCnUx.items():
   i=i+1
   if i>1:PQVMvWJgSYfomasqNiDypthFTzCnUE+='&'
   PQVMvWJgSYfomasqNiDypthFTzCnUE+='{}={}'.format(PQVMvWJgSYfomasqNiDypthFTzCnUb,urllib.parse.quote(PQVMvWJgSYfomasqNiDypthFTzCnUl))
  return PQVMvWJgSYfomasqNiDypthFTzCnUE
 def makeDefaultCookies(PQVMvWJgSYfomasqNiDypthFTzCnUH):
  PQVMvWJgSYfomasqNiDypthFTzCnUI={}
  for PQVMvWJgSYfomasqNiDypthFTzCnUb,PQVMvWJgSYfomasqNiDypthFTzCnUl in PQVMvWJgSYfomasqNiDypthFTzCnUH.TV['cookies'].items():
   PQVMvWJgSYfomasqNiDypthFTzCnUI[PQVMvWJgSYfomasqNiDypthFTzCnUb]=PQVMvWJgSYfomasqNiDypthFTzCnUl
  return PQVMvWJgSYfomasqNiDypthFTzCnUI
 def getDeviceStr(PQVMvWJgSYfomasqNiDypthFTzCnUH):
  PQVMvWJgSYfomasqNiDypthFTzCndU=[]
  PQVMvWJgSYfomasqNiDypthFTzCndU.append('Windows') 
  PQVMvWJgSYfomasqNiDypthFTzCndU.append('Chrome') 
  PQVMvWJgSYfomasqNiDypthFTzCndU.append('ko-KR') 
  PQVMvWJgSYfomasqNiDypthFTzCndU.append('undefined') 
  PQVMvWJgSYfomasqNiDypthFTzCndU.append('24') 
  PQVMvWJgSYfomasqNiDypthFTzCndU.append(u'한국 표준시')
  PQVMvWJgSYfomasqNiDypthFTzCndU.append('undefined') 
  PQVMvWJgSYfomasqNiDypthFTzCndU.append('undefined') 
  PQVMvWJgSYfomasqNiDypthFTzCndU.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  PQVMvWJgSYfomasqNiDypthFTzCndK=''
  for PQVMvWJgSYfomasqNiDypthFTzCndk in PQVMvWJgSYfomasqNiDypthFTzCndU:
   PQVMvWJgSYfomasqNiDypthFTzCndK+=PQVMvWJgSYfomasqNiDypthFTzCndk+'|'
  return PQVMvWJgSYfomasqNiDypthFTzCndK
 def GetDefaultParams(PQVMvWJgSYfomasqNiDypthFTzCnUH,uhd=PQVMvWJgSYfomasqNiDypthFTzCncO):
  if uhd==PQVMvWJgSYfomasqNiDypthFTzCncO:
   PQVMvWJgSYfomasqNiDypthFTzCndO={'apiKey':PQVMvWJgSYfomasqNiDypthFTzCnUH.APIKEY,'networkCode':PQVMvWJgSYfomasqNiDypthFTzCnUH.NETWORKCODE,'osCode':PQVMvWJgSYfomasqNiDypthFTzCnUH.OSCODE,'teleCode':PQVMvWJgSYfomasqNiDypthFTzCnUH.TELECODE,'screenCode':PQVMvWJgSYfomasqNiDypthFTzCnUH.SCREENCODE,}
  else:
   PQVMvWJgSYfomasqNiDypthFTzCndO={'apiKey':PQVMvWJgSYfomasqNiDypthFTzCnUH.APIKEY_ATV,'networkCode':PQVMvWJgSYfomasqNiDypthFTzCnUH.NETWORKCODE,'osCode':PQVMvWJgSYfomasqNiDypthFTzCnUH.OSCODE,'teleCode':PQVMvWJgSYfomasqNiDypthFTzCnUH.TELECODE,'screenCode':PQVMvWJgSYfomasqNiDypthFTzCnUH.SCREENCODE_ATV,}
  return PQVMvWJgSYfomasqNiDypthFTzCndO
 def GetNoCache(PQVMvWJgSYfomasqNiDypthFTzCnUH,timetype=1):
  if timetype==1:
   return PQVMvWJgSYfomasqNiDypthFTzCncw(time.time())
  else:
   return PQVMvWJgSYfomasqNiDypthFTzCncw(time.time()*1000)
 def GetUniqueid(PQVMvWJgSYfomasqNiDypthFTzCnUH,hValue=PQVMvWJgSYfomasqNiDypthFTzCnck):
  if hValue:
   import hashlib
   PQVMvWJgSYfomasqNiDypthFTzCndX=hashlib.sha1()
   PQVMvWJgSYfomasqNiDypthFTzCndX.update(hValue.encode())
   PQVMvWJgSYfomasqNiDypthFTzCndH=PQVMvWJgSYfomasqNiDypthFTzCndX.hexdigest()[:8]
  else:
   PQVMvWJgSYfomasqNiDypthFTzCndc=[0 for i in PQVMvWJgSYfomasqNiDypthFTzCncA(256)]
   for i in PQVMvWJgSYfomasqNiDypthFTzCncA(256):
    PQVMvWJgSYfomasqNiDypthFTzCndc[i]='%02x'%(i)
   PQVMvWJgSYfomasqNiDypthFTzCndR=PQVMvWJgSYfomasqNiDypthFTzCncw(4294967295*random.random())|0
   PQVMvWJgSYfomasqNiDypthFTzCndH=PQVMvWJgSYfomasqNiDypthFTzCndc[255&PQVMvWJgSYfomasqNiDypthFTzCndR]+PQVMvWJgSYfomasqNiDypthFTzCndc[PQVMvWJgSYfomasqNiDypthFTzCndR>>8&255]+PQVMvWJgSYfomasqNiDypthFTzCndc[PQVMvWJgSYfomasqNiDypthFTzCndR>>16&255]+PQVMvWJgSYfomasqNiDypthFTzCndc[PQVMvWJgSYfomasqNiDypthFTzCndR>>24&255]
  return PQVMvWJgSYfomasqNiDypthFTzCndH
 def GetCredential(PQVMvWJgSYfomasqNiDypthFTzCnUH,user_id,user_pw,login_type,user_pf):
  try:
   PQVMvWJgSYfomasqNiDypthFTzCndw=PQVMvWJgSYfomasqNiDypthFTzCnUH.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   PQVMvWJgSYfomasqNiDypthFTzCndA={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'https://www.tving.com/onboarding','csite':'','rtUrl':'https%3A%2F%2Fwww.tving.com%2Fonboarding',}
   PQVMvWJgSYfomasqNiDypthFTzCnde=PQVMvWJgSYfomasqNiDypthFTzCnUH.callRequestCookies('Post',PQVMvWJgSYfomasqNiDypthFTzCndw,payload=PQVMvWJgSYfomasqNiDypthFTzCndA,params=PQVMvWJgSYfomasqNiDypthFTzCnck,headers=PQVMvWJgSYfomasqNiDypthFTzCnck,cookies=PQVMvWJgSYfomasqNiDypthFTzCnck)
   for PQVMvWJgSYfomasqNiDypthFTzCndB in PQVMvWJgSYfomasqNiDypthFTzCnde.cookies:
    PQVMvWJgSYfomasqNiDypthFTzCnUH.TV['cookies'][PQVMvWJgSYfomasqNiDypthFTzCndB.name]=PQVMvWJgSYfomasqNiDypthFTzCndB.value
  except PQVMvWJgSYfomasqNiDypthFTzCnce as exception:
   PQVMvWJgSYfomasqNiDypthFTzCncU(exception)
   PQVMvWJgSYfomasqNiDypthFTzCnUH.Init_TV_Total()
   return PQVMvWJgSYfomasqNiDypthFTzCncO
  PQVMvWJgSYfomasqNiDypthFTzCndG=[]
  PQVMvWJgSYfomasqNiDypthFTzCndr =''
  try:
   PQVMvWJgSYfomasqNiDypthFTzCndL ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   PQVMvWJgSYfomasqNiDypthFTzCnUI=PQVMvWJgSYfomasqNiDypthFTzCnUH.makeDefaultCookies()
   PQVMvWJgSYfomasqNiDypthFTzCnde=PQVMvWJgSYfomasqNiDypthFTzCnUH.callRequestCookies('Get',PQVMvWJgSYfomasqNiDypthFTzCndL,payload=PQVMvWJgSYfomasqNiDypthFTzCnck,params=PQVMvWJgSYfomasqNiDypthFTzCnck,headers=PQVMvWJgSYfomasqNiDypthFTzCnck,cookies=PQVMvWJgSYfomasqNiDypthFTzCnUI)
   for PQVMvWJgSYfomasqNiDypthFTzCndB in PQVMvWJgSYfomasqNiDypthFTzCnde.cookies:
    PQVMvWJgSYfomasqNiDypthFTzCnUH.TV['cookies'][PQVMvWJgSYfomasqNiDypthFTzCndB.name]=PQVMvWJgSYfomasqNiDypthFTzCndB.value
   PQVMvWJgSYfomasqNiDypthFTzCndG =re.findall('data-profile-no="\d+"',PQVMvWJgSYfomasqNiDypthFTzCnde.text)
   for i in PQVMvWJgSYfomasqNiDypthFTzCncA(PQVMvWJgSYfomasqNiDypthFTzCncR(PQVMvWJgSYfomasqNiDypthFTzCndG)):
    PQVMvWJgSYfomasqNiDypthFTzCndu =PQVMvWJgSYfomasqNiDypthFTzCndG[i].replace('data-profile-no=','').replace('"','')
    PQVMvWJgSYfomasqNiDypthFTzCndG[i]=PQVMvWJgSYfomasqNiDypthFTzCndu
   PQVMvWJgSYfomasqNiDypthFTzCndr=PQVMvWJgSYfomasqNiDypthFTzCndG[user_pf]
  except PQVMvWJgSYfomasqNiDypthFTzCnce as exception:
   PQVMvWJgSYfomasqNiDypthFTzCncU(exception)
   PQVMvWJgSYfomasqNiDypthFTzCnUH.Init_TV_Total()
   return PQVMvWJgSYfomasqNiDypthFTzCncO
  try:
   PQVMvWJgSYfomasqNiDypthFTzCndL ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   PQVMvWJgSYfomasqNiDypthFTzCnUI=PQVMvWJgSYfomasqNiDypthFTzCnUH.makeDefaultCookies()
   PQVMvWJgSYfomasqNiDypthFTzCndA={'profileNo':PQVMvWJgSYfomasqNiDypthFTzCndr}
   PQVMvWJgSYfomasqNiDypthFTzCnde=PQVMvWJgSYfomasqNiDypthFTzCnUH.callRequestCookies('Post',PQVMvWJgSYfomasqNiDypthFTzCndL,payload=PQVMvWJgSYfomasqNiDypthFTzCndA,params=PQVMvWJgSYfomasqNiDypthFTzCnck,headers=PQVMvWJgSYfomasqNiDypthFTzCnck,cookies=PQVMvWJgSYfomasqNiDypthFTzCnUI)
   for PQVMvWJgSYfomasqNiDypthFTzCndB in PQVMvWJgSYfomasqNiDypthFTzCnde.cookies:
    PQVMvWJgSYfomasqNiDypthFTzCnUH.TV['cookies'][PQVMvWJgSYfomasqNiDypthFTzCndB.name]=PQVMvWJgSYfomasqNiDypthFTzCndB.value
  except PQVMvWJgSYfomasqNiDypthFTzCnce as exception:
   PQVMvWJgSYfomasqNiDypthFTzCncU(exception)
   PQVMvWJgSYfomasqNiDypthFTzCnUH.Init_TV_Total()
   return PQVMvWJgSYfomasqNiDypthFTzCncO
  PQVMvWJgSYfomasqNiDypthFTzCndj =PQVMvWJgSYfomasqNiDypthFTzCnUH.GetDeviceList()
  if PQVMvWJgSYfomasqNiDypthFTzCndj not in['','-']:
   PQVMvWJgSYfomasqNiDypthFTzCnUH.TV['cookies']['tving_uuid']=PQVMvWJgSYfomasqNiDypthFTzCndj+'-'+PQVMvWJgSYfomasqNiDypthFTzCnUH.GetUniqueid(PQVMvWJgSYfomasqNiDypthFTzCndj)
  PQVMvWJgSYfomasqNiDypthFTzCnUH.JsonFile_Save(PQVMvWJgSYfomasqNiDypthFTzCnUH.COOKIE_FILE_NAME,PQVMvWJgSYfomasqNiDypthFTzCnUH.TV)
  return PQVMvWJgSYfomasqNiDypthFTzCncH
 def GetCredential_old(PQVMvWJgSYfomasqNiDypthFTzCnUH,user_id,user_pw,login_type,user_pf):
  try:
   PQVMvWJgSYfomasqNiDypthFTzCndw=PQVMvWJgSYfomasqNiDypthFTzCnUH.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   PQVMvWJgSYfomasqNiDypthFTzCndA={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com','csite':'',}
   PQVMvWJgSYfomasqNiDypthFTzCnde=PQVMvWJgSYfomasqNiDypthFTzCnUH.callRequestCookies('Post',PQVMvWJgSYfomasqNiDypthFTzCndw,payload=PQVMvWJgSYfomasqNiDypthFTzCndA,params=PQVMvWJgSYfomasqNiDypthFTzCnck,headers=PQVMvWJgSYfomasqNiDypthFTzCnck,cookies=PQVMvWJgSYfomasqNiDypthFTzCnck)
   for PQVMvWJgSYfomasqNiDypthFTzCndB in PQVMvWJgSYfomasqNiDypthFTzCnde.cookies:
    if PQVMvWJgSYfomasqNiDypthFTzCndB.name=='_tving_token':
     PQVMvWJgSYfomasqNiDypthFTzCnUH.TV['cookies']['tving_token']=PQVMvWJgSYfomasqNiDypthFTzCndB.value
    elif PQVMvWJgSYfomasqNiDypthFTzCndB.name=='POC_USERINFO':
     PQVMvWJgSYfomasqNiDypthFTzCnUH.TV['cookies']['tving_userinfo']=PQVMvWJgSYfomasqNiDypthFTzCndB.value
    elif PQVMvWJgSYfomasqNiDypthFTzCndB.name=='authToken':
     PQVMvWJgSYfomasqNiDypthFTzCnUH.TV['cookies']['tving_authToken']=PQVMvWJgSYfomasqNiDypthFTzCndB.value
   if not PQVMvWJgSYfomasqNiDypthFTzCnUH.TV['cookies']['tving_token']:
    PQVMvWJgSYfomasqNiDypthFTzCnUH.Init_TV_Total()
    return PQVMvWJgSYfomasqNiDypthFTzCncO
   PQVMvWJgSYfomasqNiDypthFTzCnUH.TV['cookies']['tving_maintoken']=PQVMvWJgSYfomasqNiDypthFTzCnUH.TV['cookies']['tving_token']
   if PQVMvWJgSYfomasqNiDypthFTzCnUH.GetProfileToken(user_pf)==PQVMvWJgSYfomasqNiDypthFTzCncO:
    PQVMvWJgSYfomasqNiDypthFTzCnUH.Init_TV_Total()
    return PQVMvWJgSYfomasqNiDypthFTzCncO
   PQVMvWJgSYfomasqNiDypthFTzCncU(PQVMvWJgSYfomasqNiDypthFTzCnUH.TV['cookies'])
   PQVMvWJgSYfomasqNiDypthFTzCndj =PQVMvWJgSYfomasqNiDypthFTzCnUH.GetDeviceList()
   if PQVMvWJgSYfomasqNiDypthFTzCndj not in['','-']:
    PQVMvWJgSYfomasqNiDypthFTzCnUH.TV['cookies']['tving_uuid']=PQVMvWJgSYfomasqNiDypthFTzCndj+'-'+PQVMvWJgSYfomasqNiDypthFTzCnUH.GetUniqueid(PQVMvWJgSYfomasqNiDypthFTzCndj)
  except PQVMvWJgSYfomasqNiDypthFTzCnce as exception:
   PQVMvWJgSYfomasqNiDypthFTzCncU(exception)
   PQVMvWJgSYfomasqNiDypthFTzCnUH.Init_TV_Total()
   return PQVMvWJgSYfomasqNiDypthFTzCncO
  return PQVMvWJgSYfomasqNiDypthFTzCncH
 def GetProfileToken(PQVMvWJgSYfomasqNiDypthFTzCnUH,user_pf):
  PQVMvWJgSYfomasqNiDypthFTzCndG=[]
  PQVMvWJgSYfomasqNiDypthFTzCndr =''
  try:
   PQVMvWJgSYfomasqNiDypthFTzCndL ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com'
   PQVMvWJgSYfomasqNiDypthFTzCnUI=PQVMvWJgSYfomasqNiDypthFTzCnUH.makeDefaultCookies()
   PQVMvWJgSYfomasqNiDypthFTzCnde=PQVMvWJgSYfomasqNiDypthFTzCnUH.callRequestCookies('Get',PQVMvWJgSYfomasqNiDypthFTzCndL,payload=PQVMvWJgSYfomasqNiDypthFTzCnck,params=PQVMvWJgSYfomasqNiDypthFTzCnck,headers=PQVMvWJgSYfomasqNiDypthFTzCnck,cookies=PQVMvWJgSYfomasqNiDypthFTzCnUI)
   PQVMvWJgSYfomasqNiDypthFTzCncU(PQVMvWJgSYfomasqNiDypthFTzCnde.text)
   PQVMvWJgSYfomasqNiDypthFTzCndG =re.findall('data-profile-no="\d+"',PQVMvWJgSYfomasqNiDypthFTzCnde.text)
   PQVMvWJgSYfomasqNiDypthFTzCncU(PQVMvWJgSYfomasqNiDypthFTzCndG)
   for i in PQVMvWJgSYfomasqNiDypthFTzCncA(PQVMvWJgSYfomasqNiDypthFTzCncR(PQVMvWJgSYfomasqNiDypthFTzCndG)):
    PQVMvWJgSYfomasqNiDypthFTzCndu =PQVMvWJgSYfomasqNiDypthFTzCndG[i].replace('data-profile-no=','').replace('"','')
    PQVMvWJgSYfomasqNiDypthFTzCndG[i]=PQVMvWJgSYfomasqNiDypthFTzCndu
   PQVMvWJgSYfomasqNiDypthFTzCndr=PQVMvWJgSYfomasqNiDypthFTzCndG[user_pf]
  except PQVMvWJgSYfomasqNiDypthFTzCnce as exception:
   PQVMvWJgSYfomasqNiDypthFTzCncU(exception)
   PQVMvWJgSYfomasqNiDypthFTzCnUH.Init_TV_Total()
   return PQVMvWJgSYfomasqNiDypthFTzCncO
  try:
   PQVMvWJgSYfomasqNiDypthFTzCndL ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   PQVMvWJgSYfomasqNiDypthFTzCnUI=PQVMvWJgSYfomasqNiDypthFTzCnUH.makeDefaultCookies()
   PQVMvWJgSYfomasqNiDypthFTzCndA={'profileNo':PQVMvWJgSYfomasqNiDypthFTzCndr}
   PQVMvWJgSYfomasqNiDypthFTzCnde=PQVMvWJgSYfomasqNiDypthFTzCnUH.callRequestCookies('Post',PQVMvWJgSYfomasqNiDypthFTzCndL,payload=PQVMvWJgSYfomasqNiDypthFTzCndA,params=PQVMvWJgSYfomasqNiDypthFTzCnck,headers=PQVMvWJgSYfomasqNiDypthFTzCnck,cookies=PQVMvWJgSYfomasqNiDypthFTzCnUI)
   for PQVMvWJgSYfomasqNiDypthFTzCndB in PQVMvWJgSYfomasqNiDypthFTzCnde.cookies:
    if PQVMvWJgSYfomasqNiDypthFTzCndB.name=='_tving_token':
     PQVMvWJgSYfomasqNiDypthFTzCnUH.TV['cookies']['tving_token']=PQVMvWJgSYfomasqNiDypthFTzCndB.value
    elif PQVMvWJgSYfomasqNiDypthFTzCndB.name==PQVMvWJgSYfomasqNiDypthFTzCnUH.GLOBAL_COOKIENM['tv_cookiekey']:
     PQVMvWJgSYfomasqNiDypthFTzCnUH.TV['cookies']['tving_cookiekey']=PQVMvWJgSYfomasqNiDypthFTzCndB.value
    elif PQVMvWJgSYfomasqNiDypthFTzCndB.name==PQVMvWJgSYfomasqNiDypthFTzCnUH.GLOBAL_COOKIENM['tv_lockkey']:
     PQVMvWJgSYfomasqNiDypthFTzCnUH.TV['cookies']['tving_lockkey']=PQVMvWJgSYfomasqNiDypthFTzCndB.value
  except PQVMvWJgSYfomasqNiDypthFTzCnce as exception:
   PQVMvWJgSYfomasqNiDypthFTzCncU(exception)
   PQVMvWJgSYfomasqNiDypthFTzCnUH.Init_TV_Total()
   return PQVMvWJgSYfomasqNiDypthFTzCncO
  return PQVMvWJgSYfomasqNiDypthFTzCncH
 def GetDeviceList(PQVMvWJgSYfomasqNiDypthFTzCnUH):
  PQVMvWJgSYfomasqNiDypthFTzCndb=[]
  PQVMvWJgSYfomasqNiDypthFTzCndl='-'
  try:
   PQVMvWJgSYfomasqNiDypthFTzCndL ='/v1/user/device/list'
   PQVMvWJgSYfomasqNiDypthFTzCndx=PQVMvWJgSYfomasqNiDypthFTzCnUH.API_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCndL
   PQVMvWJgSYfomasqNiDypthFTzCndE=PQVMvWJgSYfomasqNiDypthFTzCnUH.GetDefaultParams()
   PQVMvWJgSYfomasqNiDypthFTzCnUI=PQVMvWJgSYfomasqNiDypthFTzCnUH.makeDefaultCookies()
   PQVMvWJgSYfomasqNiDypthFTzCnde=PQVMvWJgSYfomasqNiDypthFTzCnUH.callRequestCookies('Get',PQVMvWJgSYfomasqNiDypthFTzCndx,payload=PQVMvWJgSYfomasqNiDypthFTzCnck,params=PQVMvWJgSYfomasqNiDypthFTzCndE,headers=PQVMvWJgSYfomasqNiDypthFTzCnck,cookies=PQVMvWJgSYfomasqNiDypthFTzCnUI)
   PQVMvWJgSYfomasqNiDypthFTzCndI=json.loads(PQVMvWJgSYfomasqNiDypthFTzCnde.text)
   PQVMvWJgSYfomasqNiDypthFTzCndb=PQVMvWJgSYfomasqNiDypthFTzCndI['body']
   for PQVMvWJgSYfomasqNiDypthFTzCnKU in PQVMvWJgSYfomasqNiDypthFTzCndb:
    if PQVMvWJgSYfomasqNiDypthFTzCnKU['model'].lower().startswith('pc'):
     PQVMvWJgSYfomasqNiDypthFTzCndl=PQVMvWJgSYfomasqNiDypthFTzCnKU['uuid']
     break
   if PQVMvWJgSYfomasqNiDypthFTzCndl=='-':
    PQVMvWJgSYfomasqNiDypthFTzCndl=PQVMvWJgSYfomasqNiDypthFTzCncB(PQVMvWJgSYfomasqNiDypthFTzCnUH.GetNoCache(timetype=1))
  except PQVMvWJgSYfomasqNiDypthFTzCnce as exception:
   PQVMvWJgSYfomasqNiDypthFTzCncU(exception)
  return PQVMvWJgSYfomasqNiDypthFTzCndl
 def Get_Now_Datetime(PQVMvWJgSYfomasqNiDypthFTzCnUH):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(PQVMvWJgSYfomasqNiDypthFTzCnUH,mediacode,sel_quality,stype,pvrmode='-',optUHD=PQVMvWJgSYfomasqNiDypthFTzCncO):
  PQVMvWJgSYfomasqNiDypthFTzCnKk ={'streaming_url':'','subtitleYn':PQVMvWJgSYfomasqNiDypthFTzCncO,'error_msg':'','drm_server_url':'','drm_header_key':'','drm_header_value':'','url_filename':'',}
  PQVMvWJgSYfomasqNiDypthFTzCndl =PQVMvWJgSYfomasqNiDypthFTzCnUH.TV['cookies']['tving_uuid'].split('-')[0] 
  PQVMvWJgSYfomasqNiDypthFTzCnKO =PQVMvWJgSYfomasqNiDypthFTzCnUH.TV['cookies']['tving_uuid'] 
  PQVMvWJgSYfomasqNiDypthFTzCnKX=PQVMvWJgSYfomasqNiDypthFTzCncO 
  try:
   PQVMvWJgSYfomasqNiDypthFTzCnKH=PQVMvWJgSYfomasqNiDypthFTzCncB(PQVMvWJgSYfomasqNiDypthFTzCnUH.GetNoCache(1))
   if stype!='tvingtv':
    PQVMvWJgSYfomasqNiDypthFTzCndL ='/v2/media/stream/info'
    PQVMvWJgSYfomasqNiDypthFTzCnKc=PQVMvWJgSYfomasqNiDypthFTzCnUH.GetDefaultParams()
    PQVMvWJgSYfomasqNiDypthFTzCndE={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':PQVMvWJgSYfomasqNiDypthFTzCnKO,'deviceInfo':'PC','noCache':PQVMvWJgSYfomasqNiDypthFTzCnKH,}
    PQVMvWJgSYfomasqNiDypthFTzCnKc.update(PQVMvWJgSYfomasqNiDypthFTzCndE)
    PQVMvWJgSYfomasqNiDypthFTzCnKR=PQVMvWJgSYfomasqNiDypthFTzCnUH.API_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCndL
    PQVMvWJgSYfomasqNiDypthFTzCnUI=PQVMvWJgSYfomasqNiDypthFTzCnUH.makeDefaultCookies()
    PQVMvWJgSYfomasqNiDypthFTzCnde=PQVMvWJgSYfomasqNiDypthFTzCnUH.callRequestCookies('Get',PQVMvWJgSYfomasqNiDypthFTzCnKR,payload=PQVMvWJgSYfomasqNiDypthFTzCnck,params=PQVMvWJgSYfomasqNiDypthFTzCnKc,headers=PQVMvWJgSYfomasqNiDypthFTzCnck,cookies=PQVMvWJgSYfomasqNiDypthFTzCnUI)
    if PQVMvWJgSYfomasqNiDypthFTzCnde.status_code!=200:
     PQVMvWJgSYfomasqNiDypthFTzCnKk['error_msg']='First Step - {} error'.format(PQVMvWJgSYfomasqNiDypthFTzCnde.status_code)
     return PQVMvWJgSYfomasqNiDypthFTzCnKk
    PQVMvWJgSYfomasqNiDypthFTzCndI=json.loads(PQVMvWJgSYfomasqNiDypthFTzCnde.text)
    if PQVMvWJgSYfomasqNiDypthFTzCndI['body']['result']['code']=='060':
     for PQVMvWJgSYfomasqNiDypthFTzCnUb,PQVMvWJgSYfomasqNiDypthFTzCnUl in PQVMvWJgSYfomasqNiDypthFTzCnUK.items():
      if PQVMvWJgSYfomasqNiDypthFTzCnUl==sel_quality:
       PQVMvWJgSYfomasqNiDypthFTzCnKw=PQVMvWJgSYfomasqNiDypthFTzCnUb
    elif PQVMvWJgSYfomasqNiDypthFTzCndI['body']['result']['code']!='000':
     PQVMvWJgSYfomasqNiDypthFTzCnKk['error_msg']=PQVMvWJgSYfomasqNiDypthFTzCndI['body']['result']['message']
     return PQVMvWJgSYfomasqNiDypthFTzCnKk
    else: 
     if not('stream' in PQVMvWJgSYfomasqNiDypthFTzCndI['body']):return PQVMvWJgSYfomasqNiDypthFTzCnKk
     PQVMvWJgSYfomasqNiDypthFTzCnKA=[]
     for PQVMvWJgSYfomasqNiDypthFTzCnUb,PQVMvWJgSYfomasqNiDypthFTzCnUl in PQVMvWJgSYfomasqNiDypthFTzCnUK.items():
      for PQVMvWJgSYfomasqNiDypthFTzCnKU in PQVMvWJgSYfomasqNiDypthFTzCndI['body']['stream']['quality']:
       if PQVMvWJgSYfomasqNiDypthFTzCnKU['active']=='Y' and PQVMvWJgSYfomasqNiDypthFTzCnKU['code']==PQVMvWJgSYfomasqNiDypthFTzCnUb:
        PQVMvWJgSYfomasqNiDypthFTzCnKA.append({PQVMvWJgSYfomasqNiDypthFTzCnUK.get(PQVMvWJgSYfomasqNiDypthFTzCnKU['code']):PQVMvWJgSYfomasqNiDypthFTzCnKU['code']})
     PQVMvWJgSYfomasqNiDypthFTzCnKw=PQVMvWJgSYfomasqNiDypthFTzCnUH.CheckQuality(sel_quality,PQVMvWJgSYfomasqNiDypthFTzCnKA)
     try:
      if optUHD==PQVMvWJgSYfomasqNiDypthFTzCncH and PQVMvWJgSYfomasqNiDypthFTzCnKw=='stream50' and 'stream_support_info' in PQVMvWJgSYfomasqNiDypthFTzCndI['body']['content']['info']:
       if PQVMvWJgSYfomasqNiDypthFTzCndI['body']['content']['info']['stream_support_info']!=PQVMvWJgSYfomasqNiDypthFTzCnck:
        if 'stream70' in PQVMvWJgSYfomasqNiDypthFTzCndI['body']['content']['info']['stream_support_info']:
         PQVMvWJgSYfomasqNiDypthFTzCnKw='stream70'
         PQVMvWJgSYfomasqNiDypthFTzCnKX =PQVMvWJgSYfomasqNiDypthFTzCncH
     except:
      pass
     try:
      if optUHD==PQVMvWJgSYfomasqNiDypthFTzCncH and PQVMvWJgSYfomasqNiDypthFTzCnKw=='stream50' and 'stream' in PQVMvWJgSYfomasqNiDypthFTzCndI['body']['content']['info']:
       if PQVMvWJgSYfomasqNiDypthFTzCndI['body']['content']['info']['stream']!=PQVMvWJgSYfomasqNiDypthFTzCnck:
        for PQVMvWJgSYfomasqNiDypthFTzCnKU in PQVMvWJgSYfomasqNiDypthFTzCndI['body']['content']['info']['stream']:
         if PQVMvWJgSYfomasqNiDypthFTzCnKU['code']=='stream70':
          PQVMvWJgSYfomasqNiDypthFTzCnKw='stream70'
          PQVMvWJgSYfomasqNiDypthFTzCnKX =PQVMvWJgSYfomasqNiDypthFTzCncH
          break
     except:
      pass
   else:
    PQVMvWJgSYfomasqNiDypthFTzCnKw='stream40'
  except PQVMvWJgSYfomasqNiDypthFTzCnce as exception:
   PQVMvWJgSYfomasqNiDypthFTzCncU(exception)
   PQVMvWJgSYfomasqNiDypthFTzCnKk['error_msg']='First Step - except error'
   return PQVMvWJgSYfomasqNiDypthFTzCnKk
  PQVMvWJgSYfomasqNiDypthFTzCncU(PQVMvWJgSYfomasqNiDypthFTzCnKw)
  try:
   PQVMvWJgSYfomasqNiDypthFTzCnKH=PQVMvWJgSYfomasqNiDypthFTzCncB(PQVMvWJgSYfomasqNiDypthFTzCnUH.GetNoCache(1))
   PQVMvWJgSYfomasqNiDypthFTzCndL ='/v3/media/stream/info'
   if PQVMvWJgSYfomasqNiDypthFTzCnKX==PQVMvWJgSYfomasqNiDypthFTzCncH:
    PQVMvWJgSYfomasqNiDypthFTzCnKc=PQVMvWJgSYfomasqNiDypthFTzCnUH.GetDefaultParams(uhd=PQVMvWJgSYfomasqNiDypthFTzCncH)
    PQVMvWJgSYfomasqNiDypthFTzCndE={'mediaCode':mediacode,'deviceId':PQVMvWJgSYfomasqNiDypthFTzCndl,'uuid':PQVMvWJgSYfomasqNiDypthFTzCnKO,'deviceInfo':'PC_Chrome WebView','streamCode':PQVMvWJgSYfomasqNiDypthFTzCnKw,'noCache':PQVMvWJgSYfomasqNiDypthFTzCnKH,'callingFrom':'HTML5','model':'chrome webview_96.0.4664.104','videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   else:
    PQVMvWJgSYfomasqNiDypthFTzCnKc=PQVMvWJgSYfomasqNiDypthFTzCnUH.GetDefaultParams()
    PQVMvWJgSYfomasqNiDypthFTzCndE={'mediaCode':mediacode,'deviceId':PQVMvWJgSYfomasqNiDypthFTzCndl,'uuid':PQVMvWJgSYfomasqNiDypthFTzCnKO,'deviceInfo':'PC_Chrome','streamCode':PQVMvWJgSYfomasqNiDypthFTzCnKw,'noCache':PQVMvWJgSYfomasqNiDypthFTzCnKH,'callingFrom':'HTML5','model':PQVMvWJgSYfomasqNiDypthFTzCnUH.MODEL,'videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   PQVMvWJgSYfomasqNiDypthFTzCnKc.update(PQVMvWJgSYfomasqNiDypthFTzCndE)
   PQVMvWJgSYfomasqNiDypthFTzCnKR=PQVMvWJgSYfomasqNiDypthFTzCnUH.API_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCndL
   PQVMvWJgSYfomasqNiDypthFTzCnUI=PQVMvWJgSYfomasqNiDypthFTzCnUH.makeDefaultCookies()
   PQVMvWJgSYfomasqNiDypthFTzCnde=PQVMvWJgSYfomasqNiDypthFTzCnUH.callRequestCookies('Post',PQVMvWJgSYfomasqNiDypthFTzCnKR,payload=PQVMvWJgSYfomasqNiDypthFTzCnck,params=PQVMvWJgSYfomasqNiDypthFTzCnKc,headers=PQVMvWJgSYfomasqNiDypthFTzCnck,cookies=PQVMvWJgSYfomasqNiDypthFTzCnUI,redirects=PQVMvWJgSYfomasqNiDypthFTzCncH)
   PQVMvWJgSYfomasqNiDypthFTzCndI=json.loads(PQVMvWJgSYfomasqNiDypthFTzCnde.text)
   if PQVMvWJgSYfomasqNiDypthFTzCndI['body']['result']['code']!='000':
    PQVMvWJgSYfomasqNiDypthFTzCnKk['error_msg']=PQVMvWJgSYfomasqNiDypthFTzCndI['body']['result']['message']
    return PQVMvWJgSYfomasqNiDypthFTzCnKk
   PQVMvWJgSYfomasqNiDypthFTzCnKe=PQVMvWJgSYfomasqNiDypthFTzCndI['body']['stream']
   if PQVMvWJgSYfomasqNiDypthFTzCnKe['drm_yn']=='Y':
    PQVMvWJgSYfomasqNiDypthFTzCnKB=PQVMvWJgSYfomasqNiDypthFTzCnKe['playback']['drm']['widevine']
    for PQVMvWJgSYfomasqNiDypthFTzCnKG in PQVMvWJgSYfomasqNiDypthFTzCnKe['playback']['drm']['license']['drm_license_data']:
     if PQVMvWJgSYfomasqNiDypthFTzCnKG['drm_type']=='Widevine':
      PQVMvWJgSYfomasqNiDypthFTzCnKk['drm_server_url'] =PQVMvWJgSYfomasqNiDypthFTzCnKG['drm_server_url']
      PQVMvWJgSYfomasqNiDypthFTzCnKk['drm_header_key'] =PQVMvWJgSYfomasqNiDypthFTzCnKG['drm_header_key']
      PQVMvWJgSYfomasqNiDypthFTzCnKk['drm_header_value']=PQVMvWJgSYfomasqNiDypthFTzCnKG['drm_header_value']
      break
   else:
    PQVMvWJgSYfomasqNiDypthFTzCnKB=PQVMvWJgSYfomasqNiDypthFTzCnKe['playback']['non_drm']
  except PQVMvWJgSYfomasqNiDypthFTzCnce as exception:
   PQVMvWJgSYfomasqNiDypthFTzCncU(exception)
   PQVMvWJgSYfomasqNiDypthFTzCnKk['error_msg']='Second Step - except error'
   return PQVMvWJgSYfomasqNiDypthFTzCnKk
  PQVMvWJgSYfomasqNiDypthFTzCnKr=PQVMvWJgSYfomasqNiDypthFTzCnKH
  PQVMvWJgSYfomasqNiDypthFTzCnKB=PQVMvWJgSYfomasqNiDypthFTzCnKB.split('|')[1]
  PQVMvWJgSYfomasqNiDypthFTzCnKB=PQVMvWJgSYfomasqNiDypthFTzCnUH.Decrypt_Url(PQVMvWJgSYfomasqNiDypthFTzCnKB,mediacode,PQVMvWJgSYfomasqNiDypthFTzCnKr)
  PQVMvWJgSYfomasqNiDypthFTzCnKk['streaming_url']=PQVMvWJgSYfomasqNiDypthFTzCnKB
  if 'subtitles' in PQVMvWJgSYfomasqNiDypthFTzCnKe:
   for PQVMvWJgSYfomasqNiDypthFTzCnKL in PQVMvWJgSYfomasqNiDypthFTzCnKe.get('subtitles'):
    if PQVMvWJgSYfomasqNiDypthFTzCnKL.get('code')in['KO','KO_CC']:
     PQVMvWJgSYfomasqNiDypthFTzCnKk['subtitleYn']=PQVMvWJgSYfomasqNiDypthFTzCncH
     break
  PQVMvWJgSYfomasqNiDypthFTzCnKu=urllib.parse.urlparse(PQVMvWJgSYfomasqNiDypthFTzCnKk['streaming_url'])
  PQVMvWJgSYfomasqNiDypthFTzCnKj =PQVMvWJgSYfomasqNiDypthFTzCnKu.path.strip('/').split('/')
  PQVMvWJgSYfomasqNiDypthFTzCnKk['url_filename']=PQVMvWJgSYfomasqNiDypthFTzCnKj[PQVMvWJgSYfomasqNiDypthFTzCncR(PQVMvWJgSYfomasqNiDypthFTzCnKj)-1]
  return PQVMvWJgSYfomasqNiDypthFTzCnKk
 def Tving_Parse_mpd(PQVMvWJgSYfomasqNiDypthFTzCnUH,stream_url):
  PQVMvWJgSYfomasqNiDypthFTzCnde=requests.get(url=stream_url)
  PQVMvWJgSYfomasqNiDypthFTzCnKb=PQVMvWJgSYfomasqNiDypthFTzCnde.content.decode('utf-8')
  PQVMvWJgSYfomasqNiDypthFTzCnKl=0
  PQVMvWJgSYfomasqNiDypthFTzCnKx =ET.ElementTree(ET.fromstring(PQVMvWJgSYfomasqNiDypthFTzCnKb))
  PQVMvWJgSYfomasqNiDypthFTzCnKE =PQVMvWJgSYfomasqNiDypthFTzCnKx.getroot()
  PQVMvWJgSYfomasqNiDypthFTzCnKI=re.match(r'\{.*\}',PQVMvWJgSYfomasqNiDypthFTzCnKE.tag)[0] 
  PQVMvWJgSYfomasqNiDypthFTzCnkU=PQVMvWJgSYfomasqNiDypthFTzCncG([node for _,node in ET.iterparse(io.StringIO(PQVMvWJgSYfomasqNiDypthFTzCnKb),events=['start-ns'])])
  for PQVMvWJgSYfomasqNiDypthFTzCnUb,PQVMvWJgSYfomasqNiDypthFTzCnkj in PQVMvWJgSYfomasqNiDypthFTzCnkU.items():
   if PQVMvWJgSYfomasqNiDypthFTzCnUb!='ns2':
    ET.register_namespace(PQVMvWJgSYfomasqNiDypthFTzCnUb,PQVMvWJgSYfomasqNiDypthFTzCnkj)
  PQVMvWJgSYfomasqNiDypthFTzCnkd=PQVMvWJgSYfomasqNiDypthFTzCnKE.find(PQVMvWJgSYfomasqNiDypthFTzCnKI+'Period')
  for PQVMvWJgSYfomasqNiDypthFTzCnkK in PQVMvWJgSYfomasqNiDypthFTzCnkd.findall(PQVMvWJgSYfomasqNiDypthFTzCnKI+'AdaptationSet'):
   if PQVMvWJgSYfomasqNiDypthFTzCnkK.attrib.get('mimeType')=='video/mp4':
    for PQVMvWJgSYfomasqNiDypthFTzCnkO in PQVMvWJgSYfomasqNiDypthFTzCnkK.findall(PQVMvWJgSYfomasqNiDypthFTzCnKI+'Representation'):
     PQVMvWJgSYfomasqNiDypthFTzCnkX=PQVMvWJgSYfomasqNiDypthFTzCncw(PQVMvWJgSYfomasqNiDypthFTzCnkO.attrib.get('bandwidth'))
     if PQVMvWJgSYfomasqNiDypthFTzCnKl<PQVMvWJgSYfomasqNiDypthFTzCnkX:PQVMvWJgSYfomasqNiDypthFTzCnKl=PQVMvWJgSYfomasqNiDypthFTzCnkX
    for PQVMvWJgSYfomasqNiDypthFTzCnkO in PQVMvWJgSYfomasqNiDypthFTzCnkK.findall(PQVMvWJgSYfomasqNiDypthFTzCnKI+'Representation'):
     if PQVMvWJgSYfomasqNiDypthFTzCnKl>PQVMvWJgSYfomasqNiDypthFTzCncw(PQVMvWJgSYfomasqNiDypthFTzCnkO.attrib.get('bandwidth')):
      PQVMvWJgSYfomasqNiDypthFTzCnkK.remove(PQVMvWJgSYfomasqNiDypthFTzCnkO)
   else:
    continue
  PQVMvWJgSYfomasqNiDypthFTzCnkH=ET.tostring(PQVMvWJgSYfomasqNiDypthFTzCnKE).decode('utf-8')
  PQVMvWJgSYfomasqNiDypthFTzCnkc='<?xml version="1.0" encoding="UTF-8"?>\n'
  PQVMvWJgSYfomasqNiDypthFTzCnUH.TextFile_Save(PQVMvWJgSYfomasqNiDypthFTzCnUH.TV_STREAM_FILENAME,PQVMvWJgSYfomasqNiDypthFTzCnkc+PQVMvWJgSYfomasqNiDypthFTzCnkH)
  return PQVMvWJgSYfomasqNiDypthFTzCncH
 def Tving_Parse_m3u8(PQVMvWJgSYfomasqNiDypthFTzCnUH,stream_url):
  try:
   PQVMvWJgSYfomasqNiDypthFTzCnde=requests.get(url=stream_url,headers=PQVMvWJgSYfomasqNiDypthFTzCnck,stream=PQVMvWJgSYfomasqNiDypthFTzCncH)
   PQVMvWJgSYfomasqNiDypthFTzCnkR=PQVMvWJgSYfomasqNiDypthFTzCnde.content.decode('utf-8')
   if '#EXTM3U' not in PQVMvWJgSYfomasqNiDypthFTzCnkR:
    return PQVMvWJgSYfomasqNiDypthFTzCncO
   if '#EXT-X-STREAM-INF' not in PQVMvWJgSYfomasqNiDypthFTzCnkR: 
    return PQVMvWJgSYfomasqNiDypthFTzCncO
   PQVMvWJgSYfomasqNiDypthFTzCnkw=0
   for PQVMvWJgSYfomasqNiDypthFTzCnkA in PQVMvWJgSYfomasqNiDypthFTzCnkR.splitlines():
    if PQVMvWJgSYfomasqNiDypthFTzCnkA.startswith('#EXT-X-STREAM-INF'):
     PQVMvWJgSYfomasqNiDypthFTzCnke=PQVMvWJgSYfomasqNiDypthFTzCnUH.MediaLine_Parse(PQVMvWJgSYfomasqNiDypthFTzCnkA,'#EXT-X-STREAM-INF')
     if PQVMvWJgSYfomasqNiDypthFTzCnkw<PQVMvWJgSYfomasqNiDypthFTzCncw(PQVMvWJgSYfomasqNiDypthFTzCnke.get('BANDWIDTH')):
      PQVMvWJgSYfomasqNiDypthFTzCnkw=PQVMvWJgSYfomasqNiDypthFTzCncw(PQVMvWJgSYfomasqNiDypthFTzCnke.get('BANDWIDTH'))
   PQVMvWJgSYfomasqNiDypthFTzCnkB=[]
   PQVMvWJgSYfomasqNiDypthFTzCnkG=PQVMvWJgSYfomasqNiDypthFTzCncO
   for PQVMvWJgSYfomasqNiDypthFTzCnkA in PQVMvWJgSYfomasqNiDypthFTzCnkR.splitlines():
    if PQVMvWJgSYfomasqNiDypthFTzCnkG==PQVMvWJgSYfomasqNiDypthFTzCncH:
     PQVMvWJgSYfomasqNiDypthFTzCnkG=PQVMvWJgSYfomasqNiDypthFTzCncO
     continue
    if PQVMvWJgSYfomasqNiDypthFTzCnkA.startswith('#EXT-X-STREAM-INF'):
     PQVMvWJgSYfomasqNiDypthFTzCnke=PQVMvWJgSYfomasqNiDypthFTzCnUH.MediaLine_Parse(PQVMvWJgSYfomasqNiDypthFTzCnkA,'#EXT-X-STREAM-INF')
     if PQVMvWJgSYfomasqNiDypthFTzCnkw!=PQVMvWJgSYfomasqNiDypthFTzCncw(PQVMvWJgSYfomasqNiDypthFTzCnke.get('BANDWIDTH')):
      PQVMvWJgSYfomasqNiDypthFTzCnkG=PQVMvWJgSYfomasqNiDypthFTzCncH
      continue
    PQVMvWJgSYfomasqNiDypthFTzCnkB.append(PQVMvWJgSYfomasqNiDypthFTzCnkA)
  except PQVMvWJgSYfomasqNiDypthFTzCnce as exception:
   PQVMvWJgSYfomasqNiDypthFTzCncU(exception)
   return PQVMvWJgSYfomasqNiDypthFTzCncO
  PQVMvWJgSYfomasqNiDypthFTzCnkr='\n'.join(PQVMvWJgSYfomasqNiDypthFTzCnkB)
  PQVMvWJgSYfomasqNiDypthFTzCnUH.TextFile_Save(PQVMvWJgSYfomasqNiDypthFTzCnUH.TV_STREAM_FILENAME,PQVMvWJgSYfomasqNiDypthFTzCnkr)
  return PQVMvWJgSYfomasqNiDypthFTzCncH
 def MediaLine_Parse(PQVMvWJgSYfomasqNiDypthFTzCnUH,PQVMvWJgSYfomasqNiDypthFTzCnkA,prefix):
  PQVMvWJgSYfomasqNiDypthFTzCnke={}
  for PQVMvWJgSYfomasqNiDypthFTzCnkL in PQVMvWJgSYfomasqNiDypthFTzCnUO.split(PQVMvWJgSYfomasqNiDypthFTzCnkA.replace(prefix+':',''))[1::2]:
   PQVMvWJgSYfomasqNiDypthFTzCnku,PQVMvWJgSYfomasqNiDypthFTzCnkj=PQVMvWJgSYfomasqNiDypthFTzCnkL.split('=',1)
   PQVMvWJgSYfomasqNiDypthFTzCnke[PQVMvWJgSYfomasqNiDypthFTzCnku.upper()]=PQVMvWJgSYfomasqNiDypthFTzCnkj.replace('"','').strip()
  return PQVMvWJgSYfomasqNiDypthFTzCnke
 def CheckQuality(PQVMvWJgSYfomasqNiDypthFTzCnUH,sel_qt,PQVMvWJgSYfomasqNiDypthFTzCnKA):
  for PQVMvWJgSYfomasqNiDypthFTzCnkb in PQVMvWJgSYfomasqNiDypthFTzCnKA:
   if sel_qt>=PQVMvWJgSYfomasqNiDypthFTzCncr(PQVMvWJgSYfomasqNiDypthFTzCnkb)[0]:return PQVMvWJgSYfomasqNiDypthFTzCnkb.get(PQVMvWJgSYfomasqNiDypthFTzCncr(PQVMvWJgSYfomasqNiDypthFTzCnkb)[0])
   PQVMvWJgSYfomasqNiDypthFTzCnkl=PQVMvWJgSYfomasqNiDypthFTzCnkb.get(PQVMvWJgSYfomasqNiDypthFTzCncr(PQVMvWJgSYfomasqNiDypthFTzCnkb)[0])
  return PQVMvWJgSYfomasqNiDypthFTzCnkl
 def makeOocUrl(PQVMvWJgSYfomasqNiDypthFTzCnUH,ooc_params):
  PQVMvWJgSYfomasqNiDypthFTzCnKR=''
  for PQVMvWJgSYfomasqNiDypthFTzCnUb,PQVMvWJgSYfomasqNiDypthFTzCnUl in ooc_params.items():
   PQVMvWJgSYfomasqNiDypthFTzCnKR+="%s=%s^"%(PQVMvWJgSYfomasqNiDypthFTzCnUb,PQVMvWJgSYfomasqNiDypthFTzCnUl)
  return PQVMvWJgSYfomasqNiDypthFTzCnKR
 def GetLiveChannelList(PQVMvWJgSYfomasqNiDypthFTzCnUH,stype,page_int):
  PQVMvWJgSYfomasqNiDypthFTzCndb=[]
  PQVMvWJgSYfomasqNiDypthFTzCnkx=PQVMvWJgSYfomasqNiDypthFTzCncO
  try:
   PQVMvWJgSYfomasqNiDypthFTzCndL ='/v2/media/lives'
   if stype=='onair': 
    PQVMvWJgSYfomasqNiDypthFTzCnkE='CPCS0100,CPCS0400'
   else:
    PQVMvWJgSYfomasqNiDypthFTzCnkE='CPCS0300'
   PQVMvWJgSYfomasqNiDypthFTzCnKc=PQVMvWJgSYfomasqNiDypthFTzCnUH.GetDefaultParams()
   PQVMvWJgSYfomasqNiDypthFTzCndE={'cacheType':'main','pageNo':PQVMvWJgSYfomasqNiDypthFTzCncB(page_int),'pageSize':PQVMvWJgSYfomasqNiDypthFTzCncB(PQVMvWJgSYfomasqNiDypthFTzCnUH.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':PQVMvWJgSYfomasqNiDypthFTzCnkE,}
   PQVMvWJgSYfomasqNiDypthFTzCnKc.update(PQVMvWJgSYfomasqNiDypthFTzCndE)
   PQVMvWJgSYfomasqNiDypthFTzCnKR=PQVMvWJgSYfomasqNiDypthFTzCnUH.API_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCndL
   PQVMvWJgSYfomasqNiDypthFTzCnde=PQVMvWJgSYfomasqNiDypthFTzCnUH.callRequestCookies('Get',PQVMvWJgSYfomasqNiDypthFTzCnKR,payload=PQVMvWJgSYfomasqNiDypthFTzCnck,params=PQVMvWJgSYfomasqNiDypthFTzCnKc,headers=PQVMvWJgSYfomasqNiDypthFTzCnck,cookies=PQVMvWJgSYfomasqNiDypthFTzCnck)
   PQVMvWJgSYfomasqNiDypthFTzCndI=json.loads(PQVMvWJgSYfomasqNiDypthFTzCnde.text)
   if not('result' in PQVMvWJgSYfomasqNiDypthFTzCndI['body']):return PQVMvWJgSYfomasqNiDypthFTzCndb,PQVMvWJgSYfomasqNiDypthFTzCnkx
   PQVMvWJgSYfomasqNiDypthFTzCnkI=PQVMvWJgSYfomasqNiDypthFTzCndI['body']['result']
   for PQVMvWJgSYfomasqNiDypthFTzCnKU in PQVMvWJgSYfomasqNiDypthFTzCnkI:
    PQVMvWJgSYfomasqNiDypthFTzCnOU=PQVMvWJgSYfomasqNiDypthFTzCnOk=PQVMvWJgSYfomasqNiDypthFTzCnOX=''
    PQVMvWJgSYfomasqNiDypthFTzCnOd=PQVMvWJgSYfomasqNiDypthFTzCnOI=''
    PQVMvWJgSYfomasqNiDypthFTzCnOK=PQVMvWJgSYfomasqNiDypthFTzCnKU['live_code']
    PQVMvWJgSYfomasqNiDypthFTzCnOU =PQVMvWJgSYfomasqNiDypthFTzCnKU['schedule']['channel']['name']['ko']
    if PQVMvWJgSYfomasqNiDypthFTzCnKU['schedule']['episode']!=PQVMvWJgSYfomasqNiDypthFTzCnck:
     PQVMvWJgSYfomasqNiDypthFTzCnOk =PQVMvWJgSYfomasqNiDypthFTzCnKU['schedule']['program']['name']['ko']
     PQVMvWJgSYfomasqNiDypthFTzCnOk =PQVMvWJgSYfomasqNiDypthFTzCnOk+', '+PQVMvWJgSYfomasqNiDypthFTzCncB(PQVMvWJgSYfomasqNiDypthFTzCnKU['schedule']['episode']['frequency'])+'회'
     PQVMvWJgSYfomasqNiDypthFTzCnOX=PQVMvWJgSYfomasqNiDypthFTzCnKU['schedule']['episode']['synopsis']['ko']
    else:
     PQVMvWJgSYfomasqNiDypthFTzCnOk =PQVMvWJgSYfomasqNiDypthFTzCnKU['schedule']['program']['name']['ko']
     PQVMvWJgSYfomasqNiDypthFTzCnOX=PQVMvWJgSYfomasqNiDypthFTzCnKU['schedule']['program']['synopsis']['ko']
    try: 
     PQVMvWJgSYfomasqNiDypthFTzCnOH =''
     PQVMvWJgSYfomasqNiDypthFTzCnOc =''
     PQVMvWJgSYfomasqNiDypthFTzCnOR=''
     PQVMvWJgSYfomasqNiDypthFTzCnOw =''
     PQVMvWJgSYfomasqNiDypthFTzCnOA =''
     PQVMvWJgSYfomasqNiDypthFTzCnOe =''
     for PQVMvWJgSYfomasqNiDypthFTzCnOB in PQVMvWJgSYfomasqNiDypthFTzCnKU['schedule']['program']['image']:
      if PQVMvWJgSYfomasqNiDypthFTzCnOB['code']=='CAIP0900':PQVMvWJgSYfomasqNiDypthFTzCnOc =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB['url']
      elif PQVMvWJgSYfomasqNiDypthFTzCnOB['code']=='CAIP1800':PQVMvWJgSYfomasqNiDypthFTzCnOR=PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB['url']
      elif PQVMvWJgSYfomasqNiDypthFTzCnOB['code']=='CAIP2000':PQVMvWJgSYfomasqNiDypthFTzCnOw =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB['url']
      elif PQVMvWJgSYfomasqNiDypthFTzCnOB['code']=='CAIP1900':PQVMvWJgSYfomasqNiDypthFTzCnOA =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB['url']
      elif PQVMvWJgSYfomasqNiDypthFTzCnOB['code']=='CAIP0200':PQVMvWJgSYfomasqNiDypthFTzCnOe =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB['url']
      elif PQVMvWJgSYfomasqNiDypthFTzCnOB['code']=='CAIP0500':PQVMvWJgSYfomasqNiDypthFTzCnOH =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB['url']
      elif PQVMvWJgSYfomasqNiDypthFTzCnOB['code']=='CAIP0800':PQVMvWJgSYfomasqNiDypthFTzCnOH =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB['url']
     if PQVMvWJgSYfomasqNiDypthFTzCnOH=='':
      for PQVMvWJgSYfomasqNiDypthFTzCnOB in PQVMvWJgSYfomasqNiDypthFTzCnKU['schedule']['channel']['image']:
       if PQVMvWJgSYfomasqNiDypthFTzCnOB['code']=='CAIC0400':PQVMvWJgSYfomasqNiDypthFTzCnOH =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB['url']
       elif PQVMvWJgSYfomasqNiDypthFTzCnOB['code']=='CAIC1400':PQVMvWJgSYfomasqNiDypthFTzCnOH =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB['url']
       elif PQVMvWJgSYfomasqNiDypthFTzCnOB['code']=='CAIC1900':PQVMvWJgSYfomasqNiDypthFTzCnOH =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB['url']
    except:
     PQVMvWJgSYfomasqNiDypthFTzCnck
    try:
     PQVMvWJgSYfomasqNiDypthFTzCnOG =[]
     PQVMvWJgSYfomasqNiDypthFTzCnOr=[]
     PQVMvWJgSYfomasqNiDypthFTzCnOL =[]
     PQVMvWJgSYfomasqNiDypthFTzCnOu=''
     PQVMvWJgSYfomasqNiDypthFTzCnOj=''
     PQVMvWJgSYfomasqNiDypthFTzCnOb=''
     for PQVMvWJgSYfomasqNiDypthFTzCnOl in PQVMvWJgSYfomasqNiDypthFTzCnKU.get('schedule').get('program').get('actor'):
      if PQVMvWJgSYfomasqNiDypthFTzCnOl!='' and PQVMvWJgSYfomasqNiDypthFTzCnOl!=u'없음':PQVMvWJgSYfomasqNiDypthFTzCnOG.append(PQVMvWJgSYfomasqNiDypthFTzCnOl)
     for PQVMvWJgSYfomasqNiDypthFTzCnOx in PQVMvWJgSYfomasqNiDypthFTzCnKU.get('schedule').get('program').get('director'):
      if PQVMvWJgSYfomasqNiDypthFTzCnOx!='' and PQVMvWJgSYfomasqNiDypthFTzCnOx!='-' and PQVMvWJgSYfomasqNiDypthFTzCnOx!=u'없음':PQVMvWJgSYfomasqNiDypthFTzCnOr.append(PQVMvWJgSYfomasqNiDypthFTzCnOx)
     if PQVMvWJgSYfomasqNiDypthFTzCnKU.get('schedule').get('program').get('category1_name').get('ko')!='':
      PQVMvWJgSYfomasqNiDypthFTzCnOL.append(PQVMvWJgSYfomasqNiDypthFTzCnKU['schedule']['program']['category1_name']['ko'])
     if PQVMvWJgSYfomasqNiDypthFTzCnKU.get('schedule').get('program').get('category2_name').get('ko')!='':
      PQVMvWJgSYfomasqNiDypthFTzCnOL.append(PQVMvWJgSYfomasqNiDypthFTzCnKU['schedule']['program']['category2_name']['ko'])
     if PQVMvWJgSYfomasqNiDypthFTzCnKU.get('schedule').get('program').get('product_year'):PQVMvWJgSYfomasqNiDypthFTzCnOu=PQVMvWJgSYfomasqNiDypthFTzCnKU['schedule']['program']['product_year']
     if PQVMvWJgSYfomasqNiDypthFTzCnKU.get('schedule').get('program').get('grade_code') :PQVMvWJgSYfomasqNiDypthFTzCnOj= PQVMvWJgSYfomasqNiDypthFTzCnUk.get(PQVMvWJgSYfomasqNiDypthFTzCnKU['schedule']['program']['grade_code'])
     if 'broad_dt' in PQVMvWJgSYfomasqNiDypthFTzCnKU.get('schedule').get('program'):
      PQVMvWJgSYfomasqNiDypthFTzCnOE =PQVMvWJgSYfomasqNiDypthFTzCnKU.get('schedule').get('program').get('broad_dt')
      PQVMvWJgSYfomasqNiDypthFTzCnOb='%s-%s-%s'%(PQVMvWJgSYfomasqNiDypthFTzCnOE[:4],PQVMvWJgSYfomasqNiDypthFTzCnOE[4:6],PQVMvWJgSYfomasqNiDypthFTzCnOE[6:])
    except:
     PQVMvWJgSYfomasqNiDypthFTzCnck
    PQVMvWJgSYfomasqNiDypthFTzCnOd=PQVMvWJgSYfomasqNiDypthFTzCncB(PQVMvWJgSYfomasqNiDypthFTzCnKU['schedule']['broadcast_start_time'])[8:12]
    PQVMvWJgSYfomasqNiDypthFTzCnOI =PQVMvWJgSYfomasqNiDypthFTzCncB(PQVMvWJgSYfomasqNiDypthFTzCnKU['schedule']['broadcast_end_time'])[8:12]
    PQVMvWJgSYfomasqNiDypthFTzCnXU={'channel':PQVMvWJgSYfomasqNiDypthFTzCnOU,'title':PQVMvWJgSYfomasqNiDypthFTzCnOk,'mediacode':PQVMvWJgSYfomasqNiDypthFTzCnOK,'thumbnail':{'poster':PQVMvWJgSYfomasqNiDypthFTzCnOc,'thumb':PQVMvWJgSYfomasqNiDypthFTzCnOH,'clearlogo':PQVMvWJgSYfomasqNiDypthFTzCnOR,'icon':PQVMvWJgSYfomasqNiDypthFTzCnOw,'fanart':PQVMvWJgSYfomasqNiDypthFTzCnOe},'synopsis':PQVMvWJgSYfomasqNiDypthFTzCnOX,'channelepg':' [%s:%s ~ %s:%s]'%(PQVMvWJgSYfomasqNiDypthFTzCnOd[0:2],PQVMvWJgSYfomasqNiDypthFTzCnOd[2:],PQVMvWJgSYfomasqNiDypthFTzCnOI[0:2],PQVMvWJgSYfomasqNiDypthFTzCnOI[2:]),'cast':PQVMvWJgSYfomasqNiDypthFTzCnOG,'director':PQVMvWJgSYfomasqNiDypthFTzCnOr,'info_genre':PQVMvWJgSYfomasqNiDypthFTzCnOL,'year':PQVMvWJgSYfomasqNiDypthFTzCnOu,'mpaa':PQVMvWJgSYfomasqNiDypthFTzCnOj,'premiered':PQVMvWJgSYfomasqNiDypthFTzCnOb}
    PQVMvWJgSYfomasqNiDypthFTzCndb.append(PQVMvWJgSYfomasqNiDypthFTzCnXU)
   if PQVMvWJgSYfomasqNiDypthFTzCndI['body']['has_more']=='Y':
    PQVMvWJgSYfomasqNiDypthFTzCnkx=PQVMvWJgSYfomasqNiDypthFTzCncH
  except PQVMvWJgSYfomasqNiDypthFTzCnce as exception:
   PQVMvWJgSYfomasqNiDypthFTzCncU(exception)
  return PQVMvWJgSYfomasqNiDypthFTzCndb,PQVMvWJgSYfomasqNiDypthFTzCnkx
 def GetProgramList(PQVMvWJgSYfomasqNiDypthFTzCnUH,genre,orderby,page_int,genreCode='all'):
  PQVMvWJgSYfomasqNiDypthFTzCndb=[]
  PQVMvWJgSYfomasqNiDypthFTzCnkx=PQVMvWJgSYfomasqNiDypthFTzCncO
  try:
   if genre=='PARAMOUNT':
    PQVMvWJgSYfomasqNiDypthFTzCndL ='/v2/media/paramount/episodes'
   else:
    PQVMvWJgSYfomasqNiDypthFTzCndL ='/v2/media/episodes'
   PQVMvWJgSYfomasqNiDypthFTzCnKc=PQVMvWJgSYfomasqNiDypthFTzCnUH.GetDefaultParams()
   PQVMvWJgSYfomasqNiDypthFTzCndE={'cacheType':'main','pageSize':PQVMvWJgSYfomasqNiDypthFTzCncB(PQVMvWJgSYfomasqNiDypthFTzCnUH.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':PQVMvWJgSYfomasqNiDypthFTzCncB(page_int),}
   if genre not in['all','PARAMOUNT']:PQVMvWJgSYfomasqNiDypthFTzCndE['categoryCode']=genre
   if genreCode!='all' :PQVMvWJgSYfomasqNiDypthFTzCndE['genreCode'] =genreCode 
   PQVMvWJgSYfomasqNiDypthFTzCnKc.update(PQVMvWJgSYfomasqNiDypthFTzCndE)
   PQVMvWJgSYfomasqNiDypthFTzCnKR=PQVMvWJgSYfomasqNiDypthFTzCnUH.API_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCndL
   PQVMvWJgSYfomasqNiDypthFTzCnde=PQVMvWJgSYfomasqNiDypthFTzCnUH.callRequestCookies('Get',PQVMvWJgSYfomasqNiDypthFTzCnKR,payload=PQVMvWJgSYfomasqNiDypthFTzCnck,params=PQVMvWJgSYfomasqNiDypthFTzCnKc,headers=PQVMvWJgSYfomasqNiDypthFTzCnck,cookies=PQVMvWJgSYfomasqNiDypthFTzCnck)
   PQVMvWJgSYfomasqNiDypthFTzCndI=json.loads(PQVMvWJgSYfomasqNiDypthFTzCnde.text)
   if not('result' in PQVMvWJgSYfomasqNiDypthFTzCndI['body']):return PQVMvWJgSYfomasqNiDypthFTzCndb,PQVMvWJgSYfomasqNiDypthFTzCnkx
   PQVMvWJgSYfomasqNiDypthFTzCnkI=PQVMvWJgSYfomasqNiDypthFTzCndI['body']['result']
   for PQVMvWJgSYfomasqNiDypthFTzCnKU in PQVMvWJgSYfomasqNiDypthFTzCnkI:
    PQVMvWJgSYfomasqNiDypthFTzCnXd=PQVMvWJgSYfomasqNiDypthFTzCnKU['program']['code']
    PQVMvWJgSYfomasqNiDypthFTzCnOk =PQVMvWJgSYfomasqNiDypthFTzCnKU['program']['name']['ko']
    PQVMvWJgSYfomasqNiDypthFTzCnOj =PQVMvWJgSYfomasqNiDypthFTzCnUk.get(PQVMvWJgSYfomasqNiDypthFTzCnKU['program'].get('grade_code'))
    PQVMvWJgSYfomasqNiDypthFTzCnOc =''
    PQVMvWJgSYfomasqNiDypthFTzCnOH =''
    PQVMvWJgSYfomasqNiDypthFTzCnOR=''
    PQVMvWJgSYfomasqNiDypthFTzCnOw =''
    PQVMvWJgSYfomasqNiDypthFTzCnOA =''
    for PQVMvWJgSYfomasqNiDypthFTzCnOB in PQVMvWJgSYfomasqNiDypthFTzCnKU['program']['image']:
     if PQVMvWJgSYfomasqNiDypthFTzCnOB['code']=='CAIP0900':PQVMvWJgSYfomasqNiDypthFTzCnOc =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB['url']
     elif PQVMvWJgSYfomasqNiDypthFTzCnOB['code']=='CAIP0200':PQVMvWJgSYfomasqNiDypthFTzCnOH =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB['url']
     elif PQVMvWJgSYfomasqNiDypthFTzCnOB['code']=='CAIP1800':PQVMvWJgSYfomasqNiDypthFTzCnOR=PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB['url']
     elif PQVMvWJgSYfomasqNiDypthFTzCnOB['code']=='CAIP2000':PQVMvWJgSYfomasqNiDypthFTzCnOw =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB['url']
     elif PQVMvWJgSYfomasqNiDypthFTzCnOB['code']=='CAIP1900':PQVMvWJgSYfomasqNiDypthFTzCnOA =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB['url']
    PQVMvWJgSYfomasqNiDypthFTzCnOX =PQVMvWJgSYfomasqNiDypthFTzCnKU['program']['synopsis']['ko']
    try:
     PQVMvWJgSYfomasqNiDypthFTzCnXK=PQVMvWJgSYfomasqNiDypthFTzCnKU['channel']['name']['ko']
    except:
     PQVMvWJgSYfomasqNiDypthFTzCnXK=''
    try:
     PQVMvWJgSYfomasqNiDypthFTzCnOG =[]
     PQVMvWJgSYfomasqNiDypthFTzCnOr=[]
     PQVMvWJgSYfomasqNiDypthFTzCnOL =[]
     PQVMvWJgSYfomasqNiDypthFTzCnOu =''
     PQVMvWJgSYfomasqNiDypthFTzCnOb=''
     for PQVMvWJgSYfomasqNiDypthFTzCnOl in PQVMvWJgSYfomasqNiDypthFTzCnKU.get('program').get('actor'):
      if PQVMvWJgSYfomasqNiDypthFTzCnOl!='' and PQVMvWJgSYfomasqNiDypthFTzCnOl!='-' and PQVMvWJgSYfomasqNiDypthFTzCnOl!=u'없음':PQVMvWJgSYfomasqNiDypthFTzCnOG.append(PQVMvWJgSYfomasqNiDypthFTzCnOl)
     for PQVMvWJgSYfomasqNiDypthFTzCnOx in PQVMvWJgSYfomasqNiDypthFTzCnKU.get('program').get('director'):
      if PQVMvWJgSYfomasqNiDypthFTzCnOx!='' and PQVMvWJgSYfomasqNiDypthFTzCnOx!='-' and PQVMvWJgSYfomasqNiDypthFTzCnOx!=u'없음':PQVMvWJgSYfomasqNiDypthFTzCnOr.append(PQVMvWJgSYfomasqNiDypthFTzCnOx)
     if PQVMvWJgSYfomasqNiDypthFTzCnKU.get('program').get('category1_name').get('ko')!='':
      PQVMvWJgSYfomasqNiDypthFTzCnOL.append(PQVMvWJgSYfomasqNiDypthFTzCnKU['program']['category1_name']['ko'])
     if PQVMvWJgSYfomasqNiDypthFTzCnKU.get('program').get('category2_name').get('ko')!='':
      PQVMvWJgSYfomasqNiDypthFTzCnOL.append(PQVMvWJgSYfomasqNiDypthFTzCnKU['program']['category2_name']['ko'])
     if PQVMvWJgSYfomasqNiDypthFTzCnKU.get('program').get('product_year'):PQVMvWJgSYfomasqNiDypthFTzCnOu=PQVMvWJgSYfomasqNiDypthFTzCnKU['program']['product_year']
     if 'broad_dt' in PQVMvWJgSYfomasqNiDypthFTzCnKU.get('program'):
      PQVMvWJgSYfomasqNiDypthFTzCnOE =PQVMvWJgSYfomasqNiDypthFTzCnKU.get('program').get('broad_dt')
      PQVMvWJgSYfomasqNiDypthFTzCnOb='%s-%s-%s'%(PQVMvWJgSYfomasqNiDypthFTzCnOE[:4],PQVMvWJgSYfomasqNiDypthFTzCnOE[4:6],PQVMvWJgSYfomasqNiDypthFTzCnOE[6:])
    except:
     PQVMvWJgSYfomasqNiDypthFTzCnck
    PQVMvWJgSYfomasqNiDypthFTzCnXU={'program':PQVMvWJgSYfomasqNiDypthFTzCnXd,'title':PQVMvWJgSYfomasqNiDypthFTzCnOk,'thumbnail':{'poster':PQVMvWJgSYfomasqNiDypthFTzCnOc,'thumb':PQVMvWJgSYfomasqNiDypthFTzCnOH,'clearlogo':PQVMvWJgSYfomasqNiDypthFTzCnOR,'icon':PQVMvWJgSYfomasqNiDypthFTzCnOw,'banner':PQVMvWJgSYfomasqNiDypthFTzCnOA,'fanart':PQVMvWJgSYfomasqNiDypthFTzCnOH},'synopsis':PQVMvWJgSYfomasqNiDypthFTzCnOX,'channel':PQVMvWJgSYfomasqNiDypthFTzCnXK,'cast':PQVMvWJgSYfomasqNiDypthFTzCnOG,'director':PQVMvWJgSYfomasqNiDypthFTzCnOr,'info_genre':PQVMvWJgSYfomasqNiDypthFTzCnOL,'year':PQVMvWJgSYfomasqNiDypthFTzCnOu,'premiered':PQVMvWJgSYfomasqNiDypthFTzCnOb,'mpaa':PQVMvWJgSYfomasqNiDypthFTzCnOj}
    PQVMvWJgSYfomasqNiDypthFTzCndb.append(PQVMvWJgSYfomasqNiDypthFTzCnXU)
   if PQVMvWJgSYfomasqNiDypthFTzCndI['body']['has_more']=='Y':PQVMvWJgSYfomasqNiDypthFTzCnkx=PQVMvWJgSYfomasqNiDypthFTzCncH
  except PQVMvWJgSYfomasqNiDypthFTzCnce as exception:
   PQVMvWJgSYfomasqNiDypthFTzCncU(exception)
  return PQVMvWJgSYfomasqNiDypthFTzCndb,PQVMvWJgSYfomasqNiDypthFTzCnkx
 def Get_UHD_ProgramList(PQVMvWJgSYfomasqNiDypthFTzCnUH,page_int):
  PQVMvWJgSYfomasqNiDypthFTzCndb=[]
  PQVMvWJgSYfomasqNiDypthFTzCnkx=PQVMvWJgSYfomasqNiDypthFTzCncO
  try:
   PQVMvWJgSYfomasqNiDypthFTzCndL ='/v2/operator/highlights'
   PQVMvWJgSYfomasqNiDypthFTzCnKc=PQVMvWJgSYfomasqNiDypthFTzCnUH.GetDefaultParams(uhd=PQVMvWJgSYfomasqNiDypthFTzCncH)
   PQVMvWJgSYfomasqNiDypthFTzCndE={'positionKey':'SMTV_PROG_4K','pageSize':'20','page_int':PQVMvWJgSYfomasqNiDypthFTzCncB(page_int),'pocType':'APP_X_TVING_4.0.0',}
   PQVMvWJgSYfomasqNiDypthFTzCnKc.update(PQVMvWJgSYfomasqNiDypthFTzCndE)
   PQVMvWJgSYfomasqNiDypthFTzCnKR=PQVMvWJgSYfomasqNiDypthFTzCnUH.API_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCndL
   PQVMvWJgSYfomasqNiDypthFTzCnde=PQVMvWJgSYfomasqNiDypthFTzCnUH.callRequestCookies('Get',PQVMvWJgSYfomasqNiDypthFTzCnKR,payload=PQVMvWJgSYfomasqNiDypthFTzCnck,params=PQVMvWJgSYfomasqNiDypthFTzCnKc,headers=PQVMvWJgSYfomasqNiDypthFTzCnck,cookies=PQVMvWJgSYfomasqNiDypthFTzCnck)
   PQVMvWJgSYfomasqNiDypthFTzCndI=json.loads(PQVMvWJgSYfomasqNiDypthFTzCnde.text)
   if not('result' in PQVMvWJgSYfomasqNiDypthFTzCndI['body']):return PQVMvWJgSYfomasqNiDypthFTzCndb,PQVMvWJgSYfomasqNiDypthFTzCnkx
   PQVMvWJgSYfomasqNiDypthFTzCnkI=PQVMvWJgSYfomasqNiDypthFTzCndI['body']['result']
   for PQVMvWJgSYfomasqNiDypthFTzCnKU in PQVMvWJgSYfomasqNiDypthFTzCnkI:
    PQVMvWJgSYfomasqNiDypthFTzCnXk=PQVMvWJgSYfomasqNiDypthFTzCnKU['content']['program']
    PQVMvWJgSYfomasqNiDypthFTzCnXO =PQVMvWJgSYfomasqNiDypthFTzCnXk['code']
    PQVMvWJgSYfomasqNiDypthFTzCnOk =PQVMvWJgSYfomasqNiDypthFTzCnXk['name']['ko'].strip()
    PQVMvWJgSYfomasqNiDypthFTzCnOj =PQVMvWJgSYfomasqNiDypthFTzCnUk.get(PQVMvWJgSYfomasqNiDypthFTzCnXk.get('grade_code'))
    PQVMvWJgSYfomasqNiDypthFTzCnOX =PQVMvWJgSYfomasqNiDypthFTzCnXk['synopsis']['ko']
    PQVMvWJgSYfomasqNiDypthFTzCnXK =PQVMvWJgSYfomasqNiDypthFTzCnKU['content']['channel']['name']['ko']
    PQVMvWJgSYfomasqNiDypthFTzCnOu =PQVMvWJgSYfomasqNiDypthFTzCnXk['product_year']
    PQVMvWJgSYfomasqNiDypthFTzCnOc =''
    PQVMvWJgSYfomasqNiDypthFTzCnOH =''
    PQVMvWJgSYfomasqNiDypthFTzCnOR=''
    PQVMvWJgSYfomasqNiDypthFTzCnOw =''
    PQVMvWJgSYfomasqNiDypthFTzCnOA =''
    for PQVMvWJgSYfomasqNiDypthFTzCnOB in PQVMvWJgSYfomasqNiDypthFTzCnXk['image']:
     if PQVMvWJgSYfomasqNiDypthFTzCnOB['code']=='CAIP0900':PQVMvWJgSYfomasqNiDypthFTzCnOc =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB['url']
     elif PQVMvWJgSYfomasqNiDypthFTzCnOB['code']=='CAIP0200':PQVMvWJgSYfomasqNiDypthFTzCnOH =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB['url']
     elif PQVMvWJgSYfomasqNiDypthFTzCnOB['code']=='CAIP1800':PQVMvWJgSYfomasqNiDypthFTzCnOR=PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB['url']
     elif PQVMvWJgSYfomasqNiDypthFTzCnOB['code']=='CAIP2000':PQVMvWJgSYfomasqNiDypthFTzCnOw =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB['url']
     elif PQVMvWJgSYfomasqNiDypthFTzCnOB['code']=='CAIP1900':PQVMvWJgSYfomasqNiDypthFTzCnOA =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB['url']
    PQVMvWJgSYfomasqNiDypthFTzCnOL =[]
    PQVMvWJgSYfomasqNiDypthFTzCnOG =[]
    PQVMvWJgSYfomasqNiDypthFTzCnOr=[]
    PQVMvWJgSYfomasqNiDypthFTzCnOb =''
    if PQVMvWJgSYfomasqNiDypthFTzCnXk.get('category1_name').get('ko')!='':
     PQVMvWJgSYfomasqNiDypthFTzCnOL.append(PQVMvWJgSYfomasqNiDypthFTzCnXk['category1_name']['ko'])
    if PQVMvWJgSYfomasqNiDypthFTzCnXk.get('category2_name').get('ko')!='':
     PQVMvWJgSYfomasqNiDypthFTzCnOL.append(PQVMvWJgSYfomasqNiDypthFTzCnXk['category2_name']['ko'])
    for PQVMvWJgSYfomasqNiDypthFTzCnOl in PQVMvWJgSYfomasqNiDypthFTzCnXk.get('actor'):
     if PQVMvWJgSYfomasqNiDypthFTzCnOl!='' and PQVMvWJgSYfomasqNiDypthFTzCnOl!='-' and PQVMvWJgSYfomasqNiDypthFTzCnOl!=u'없음':PQVMvWJgSYfomasqNiDypthFTzCnOG.append(PQVMvWJgSYfomasqNiDypthFTzCnOl)
    for PQVMvWJgSYfomasqNiDypthFTzCnOx in PQVMvWJgSYfomasqNiDypthFTzCnXk.get('director'):
     if PQVMvWJgSYfomasqNiDypthFTzCnOx!='' and PQVMvWJgSYfomasqNiDypthFTzCnOx!='-' and PQVMvWJgSYfomasqNiDypthFTzCnOx!=u'없음':PQVMvWJgSYfomasqNiDypthFTzCnOr.append(PQVMvWJgSYfomasqNiDypthFTzCnOx)
    if PQVMvWJgSYfomasqNiDypthFTzCnXk.get('broad_dt')not in[PQVMvWJgSYfomasqNiDypthFTzCnck,'']:
     PQVMvWJgSYfomasqNiDypthFTzCnOE =PQVMvWJgSYfomasqNiDypthFTzCnXk.get('broad_dt')
     PQVMvWJgSYfomasqNiDypthFTzCnOb='%s-%s-%s'%(PQVMvWJgSYfomasqNiDypthFTzCnOE[:4],PQVMvWJgSYfomasqNiDypthFTzCnOE[4:6],PQVMvWJgSYfomasqNiDypthFTzCnOE[6:])
    PQVMvWJgSYfomasqNiDypthFTzCnXU={'program':PQVMvWJgSYfomasqNiDypthFTzCnXO,'title':PQVMvWJgSYfomasqNiDypthFTzCnOk,'mpaa':PQVMvWJgSYfomasqNiDypthFTzCnOj,'thumbnail':{'poster':PQVMvWJgSYfomasqNiDypthFTzCnOc,'thumb':PQVMvWJgSYfomasqNiDypthFTzCnOH,'clearlogo':PQVMvWJgSYfomasqNiDypthFTzCnOR,'icon':PQVMvWJgSYfomasqNiDypthFTzCnOw,'banner':PQVMvWJgSYfomasqNiDypthFTzCnOA,'fanart':PQVMvWJgSYfomasqNiDypthFTzCnOH},'channel':PQVMvWJgSYfomasqNiDypthFTzCnXK,'synopsis':PQVMvWJgSYfomasqNiDypthFTzCnOX,'year':PQVMvWJgSYfomasqNiDypthFTzCnOu,'info_genre':PQVMvWJgSYfomasqNiDypthFTzCnOL,'cast':PQVMvWJgSYfomasqNiDypthFTzCnOG,'director':PQVMvWJgSYfomasqNiDypthFTzCnOr,'premiered':PQVMvWJgSYfomasqNiDypthFTzCnOb,}
    PQVMvWJgSYfomasqNiDypthFTzCndb.append(PQVMvWJgSYfomasqNiDypthFTzCnXU)
  except PQVMvWJgSYfomasqNiDypthFTzCnce as exception:
   PQVMvWJgSYfomasqNiDypthFTzCncU(exception)
  return PQVMvWJgSYfomasqNiDypthFTzCndb,PQVMvWJgSYfomasqNiDypthFTzCnkx
 def Get_Origianl_ProgramList(PQVMvWJgSYfomasqNiDypthFTzCnUH,page_int):
  PQVMvWJgSYfomasqNiDypthFTzCndb=[]
  PQVMvWJgSYfomasqNiDypthFTzCnkx=PQVMvWJgSYfomasqNiDypthFTzCncO
  try:
   PQVMvWJgSYfomasqNiDypthFTzCndL ='/v2/media/band/originals'
   PQVMvWJgSYfomasqNiDypthFTzCnKc=PQVMvWJgSYfomasqNiDypthFTzCnUH.GetDefaultParams()
   PQVMvWJgSYfomasqNiDypthFTzCndE={'pageSize':PQVMvWJgSYfomasqNiDypthFTzCncB(PQVMvWJgSYfomasqNiDypthFTzCnUH.VOD_LIMIT),'adult':'all','order':'viewHour','originalYn':'Y','exclusiveYn':'Y','pageNo':PQVMvWJgSYfomasqNiDypthFTzCncB(page_int),}
   PQVMvWJgSYfomasqNiDypthFTzCnKc.update(PQVMvWJgSYfomasqNiDypthFTzCndE)
   PQVMvWJgSYfomasqNiDypthFTzCnKR=PQVMvWJgSYfomasqNiDypthFTzCnUH.API_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCndL
   PQVMvWJgSYfomasqNiDypthFTzCnde=PQVMvWJgSYfomasqNiDypthFTzCnUH.callRequestCookies('Get',PQVMvWJgSYfomasqNiDypthFTzCnKR,payload=PQVMvWJgSYfomasqNiDypthFTzCnck,params=PQVMvWJgSYfomasqNiDypthFTzCnKc,headers=PQVMvWJgSYfomasqNiDypthFTzCnck,cookies=PQVMvWJgSYfomasqNiDypthFTzCnck)
   PQVMvWJgSYfomasqNiDypthFTzCnXH=json.loads(PQVMvWJgSYfomasqNiDypthFTzCnde.text)
   PQVMvWJgSYfomasqNiDypthFTzCnUH.JsonFile_Save(PQVMvWJgSYfomasqNiDypthFTzCnUH.TV_SESSION_COOKIES2,PQVMvWJgSYfomasqNiDypthFTzCnXH)
   if not('contents' in PQVMvWJgSYfomasqNiDypthFTzCnXH['body']):return PQVMvWJgSYfomasqNiDypthFTzCndb,PQVMvWJgSYfomasqNiDypthFTzCnkx
   PQVMvWJgSYfomasqNiDypthFTzCnkI=PQVMvWJgSYfomasqNiDypthFTzCnXH['body']['contents']
   for PQVMvWJgSYfomasqNiDypthFTzCnKU in PQVMvWJgSYfomasqNiDypthFTzCnkI:
    PQVMvWJgSYfomasqNiDypthFTzCnXc =PQVMvWJgSYfomasqNiDypthFTzCnKU['vod_code']
    PQVMvWJgSYfomasqNiDypthFTzCnOk =PQVMvWJgSYfomasqNiDypthFTzCnKU['vod_name']
    PQVMvWJgSYfomasqNiDypthFTzCnOc =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnKU['image']
    PQVMvWJgSYfomasqNiDypthFTzCnXR ='movie' if PQVMvWJgSYfomasqNiDypthFTzCnXc.startswith('M')else 'vod'
    PQVMvWJgSYfomasqNiDypthFTzCnXU={'vod_code':PQVMvWJgSYfomasqNiDypthFTzCnXc,'title':PQVMvWJgSYfomasqNiDypthFTzCnOk,'thumbnail':{'poster':PQVMvWJgSYfomasqNiDypthFTzCnOc,'thumb':PQVMvWJgSYfomasqNiDypthFTzCnOc},'vod_type':PQVMvWJgSYfomasqNiDypthFTzCnXR,}
    PQVMvWJgSYfomasqNiDypthFTzCndb.append(PQVMvWJgSYfomasqNiDypthFTzCnXU)
   if PQVMvWJgSYfomasqNiDypthFTzCnXH['body']['has_more']=='Y':PQVMvWJgSYfomasqNiDypthFTzCnkx=PQVMvWJgSYfomasqNiDypthFTzCncH
  except PQVMvWJgSYfomasqNiDypthFTzCnce as exception:
   PQVMvWJgSYfomasqNiDypthFTzCncU(exception)
  return PQVMvWJgSYfomasqNiDypthFTzCndb,PQVMvWJgSYfomasqNiDypthFTzCnkx
 def GetEpisodeList(PQVMvWJgSYfomasqNiDypthFTzCnUH,program_code,page_int,orderby='desc'):
  PQVMvWJgSYfomasqNiDypthFTzCndb=[]
  PQVMvWJgSYfomasqNiDypthFTzCnkx=PQVMvWJgSYfomasqNiDypthFTzCncO
  try:
   PQVMvWJgSYfomasqNiDypthFTzCndL ='/v2/media/frequency/program/'+program_code
   PQVMvWJgSYfomasqNiDypthFTzCnKc=PQVMvWJgSYfomasqNiDypthFTzCnUH.GetDefaultParams()
   PQVMvWJgSYfomasqNiDypthFTzCndE={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   PQVMvWJgSYfomasqNiDypthFTzCnKc.update(PQVMvWJgSYfomasqNiDypthFTzCndE)
   PQVMvWJgSYfomasqNiDypthFTzCnKR=PQVMvWJgSYfomasqNiDypthFTzCnUH.API_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCndL
   PQVMvWJgSYfomasqNiDypthFTzCnde=PQVMvWJgSYfomasqNiDypthFTzCnUH.callRequestCookies('Get',PQVMvWJgSYfomasqNiDypthFTzCnKR,payload=PQVMvWJgSYfomasqNiDypthFTzCnck,params=PQVMvWJgSYfomasqNiDypthFTzCnKc,headers=PQVMvWJgSYfomasqNiDypthFTzCnck,cookies=PQVMvWJgSYfomasqNiDypthFTzCnck)
   PQVMvWJgSYfomasqNiDypthFTzCndI=json.loads(PQVMvWJgSYfomasqNiDypthFTzCnde.text)
   if not('result' in PQVMvWJgSYfomasqNiDypthFTzCndI['body']):return PQVMvWJgSYfomasqNiDypthFTzCndb,PQVMvWJgSYfomasqNiDypthFTzCnkx
   PQVMvWJgSYfomasqNiDypthFTzCnkI=PQVMvWJgSYfomasqNiDypthFTzCndI['body']['result']
   PQVMvWJgSYfomasqNiDypthFTzCnXw=PQVMvWJgSYfomasqNiDypthFTzCncw(PQVMvWJgSYfomasqNiDypthFTzCndI['body']['total_count'])
   PQVMvWJgSYfomasqNiDypthFTzCnXA =PQVMvWJgSYfomasqNiDypthFTzCncw(PQVMvWJgSYfomasqNiDypthFTzCnXw//(PQVMvWJgSYfomasqNiDypthFTzCnUH.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    PQVMvWJgSYfomasqNiDypthFTzCnXe =(PQVMvWJgSYfomasqNiDypthFTzCnXw-1)-((page_int-1)*PQVMvWJgSYfomasqNiDypthFTzCnUH.EPISODE_LIMIT)
   else:
    PQVMvWJgSYfomasqNiDypthFTzCnXe =(page_int-1)*PQVMvWJgSYfomasqNiDypthFTzCnUH.EPISODE_LIMIT
   for i in PQVMvWJgSYfomasqNiDypthFTzCncA(PQVMvWJgSYfomasqNiDypthFTzCnUH.EPISODE_LIMIT):
    if orderby=='desc':
     PQVMvWJgSYfomasqNiDypthFTzCnXB=PQVMvWJgSYfomasqNiDypthFTzCnXe-i
     if PQVMvWJgSYfomasqNiDypthFTzCnXB<0:break
    else:
     PQVMvWJgSYfomasqNiDypthFTzCnXB=PQVMvWJgSYfomasqNiDypthFTzCnXe+i
     if PQVMvWJgSYfomasqNiDypthFTzCnXB>=PQVMvWJgSYfomasqNiDypthFTzCnXw:break
    PQVMvWJgSYfomasqNiDypthFTzCnXG=PQVMvWJgSYfomasqNiDypthFTzCnkI[PQVMvWJgSYfomasqNiDypthFTzCnXB]['episode']['code']
    PQVMvWJgSYfomasqNiDypthFTzCnOk =PQVMvWJgSYfomasqNiDypthFTzCnkI[PQVMvWJgSYfomasqNiDypthFTzCnXB]['vod_name']['ko']
    PQVMvWJgSYfomasqNiDypthFTzCnXr =''
    try:
     PQVMvWJgSYfomasqNiDypthFTzCnOE=PQVMvWJgSYfomasqNiDypthFTzCncB(PQVMvWJgSYfomasqNiDypthFTzCnkI[PQVMvWJgSYfomasqNiDypthFTzCnXB]['episode']['broadcast_date'])
     PQVMvWJgSYfomasqNiDypthFTzCnXr='%s-%s-%s'%(PQVMvWJgSYfomasqNiDypthFTzCnOE[:4],PQVMvWJgSYfomasqNiDypthFTzCnOE[4:6],PQVMvWJgSYfomasqNiDypthFTzCnOE[6:])
    except:
     PQVMvWJgSYfomasqNiDypthFTzCnck
    try:
     if PQVMvWJgSYfomasqNiDypthFTzCnkI[PQVMvWJgSYfomasqNiDypthFTzCnXB]['episode']['pip_cliptype']=='C012':
      PQVMvWJgSYfomasqNiDypthFTzCnXr+=' - Quick VOD'
    except:
     PQVMvWJgSYfomasqNiDypthFTzCnck
    PQVMvWJgSYfomasqNiDypthFTzCnOX =PQVMvWJgSYfomasqNiDypthFTzCnkI[PQVMvWJgSYfomasqNiDypthFTzCnXB]['episode']['synopsis']['ko']
    PQVMvWJgSYfomasqNiDypthFTzCnOc =''
    PQVMvWJgSYfomasqNiDypthFTzCnOH =''
    PQVMvWJgSYfomasqNiDypthFTzCnOR=''
    PQVMvWJgSYfomasqNiDypthFTzCnOw =''
    PQVMvWJgSYfomasqNiDypthFTzCnOA =''
    PQVMvWJgSYfomasqNiDypthFTzCnOe =''
    for PQVMvWJgSYfomasqNiDypthFTzCnOB in PQVMvWJgSYfomasqNiDypthFTzCnkI[PQVMvWJgSYfomasqNiDypthFTzCnXB]['program']['image']:
     if PQVMvWJgSYfomasqNiDypthFTzCnOB['code']=='CAIP0900':PQVMvWJgSYfomasqNiDypthFTzCnOc =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB['url']
     elif PQVMvWJgSYfomasqNiDypthFTzCnOB['code']=='CAIP1800':PQVMvWJgSYfomasqNiDypthFTzCnOR=PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB['url']
     elif PQVMvWJgSYfomasqNiDypthFTzCnOB['code']=='CAIP2000':PQVMvWJgSYfomasqNiDypthFTzCnOw =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB['url']
     elif PQVMvWJgSYfomasqNiDypthFTzCnOB['code']=='CAIP1900':PQVMvWJgSYfomasqNiDypthFTzCnOA =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB['url']
     elif PQVMvWJgSYfomasqNiDypthFTzCnOB['code']=='CAIP0200':PQVMvWJgSYfomasqNiDypthFTzCnOe =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB['url']
    for PQVMvWJgSYfomasqNiDypthFTzCnOB in PQVMvWJgSYfomasqNiDypthFTzCnkI[PQVMvWJgSYfomasqNiDypthFTzCnXB]['episode']['image']:
     if PQVMvWJgSYfomasqNiDypthFTzCnOB['code']=='CAIE0400':PQVMvWJgSYfomasqNiDypthFTzCnOH =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB['url']
    try:
     PQVMvWJgSYfomasqNiDypthFTzCnXL=PQVMvWJgSYfomasqNiDypthFTzCnXj=PQVMvWJgSYfomasqNiDypthFTzCnXb=''
     PQVMvWJgSYfomasqNiDypthFTzCnXu=0
     PQVMvWJgSYfomasqNiDypthFTzCnXL =PQVMvWJgSYfomasqNiDypthFTzCnkI[PQVMvWJgSYfomasqNiDypthFTzCnXB]['program']['name']['ko']
     PQVMvWJgSYfomasqNiDypthFTzCnXj =PQVMvWJgSYfomasqNiDypthFTzCnXr
     PQVMvWJgSYfomasqNiDypthFTzCnXb =PQVMvWJgSYfomasqNiDypthFTzCnkI[PQVMvWJgSYfomasqNiDypthFTzCnXB]['channel']['name']['ko']
     if 'frequency' in PQVMvWJgSYfomasqNiDypthFTzCnkI[PQVMvWJgSYfomasqNiDypthFTzCnXB]['episode']:PQVMvWJgSYfomasqNiDypthFTzCnXu=PQVMvWJgSYfomasqNiDypthFTzCnkI[PQVMvWJgSYfomasqNiDypthFTzCnXB]['episode']['frequency']
    except:
     PQVMvWJgSYfomasqNiDypthFTzCnck
    PQVMvWJgSYfomasqNiDypthFTzCnXU={'episode':PQVMvWJgSYfomasqNiDypthFTzCnXG,'title':PQVMvWJgSYfomasqNiDypthFTzCnOk,'subtitle':PQVMvWJgSYfomasqNiDypthFTzCnXr,'thumbnail':{'poster':PQVMvWJgSYfomasqNiDypthFTzCnOc,'thumb':PQVMvWJgSYfomasqNiDypthFTzCnOH,'clearlogo':PQVMvWJgSYfomasqNiDypthFTzCnOR,'icon':PQVMvWJgSYfomasqNiDypthFTzCnOw,'banner':PQVMvWJgSYfomasqNiDypthFTzCnOA,'fanart':PQVMvWJgSYfomasqNiDypthFTzCnOe},'synopsis':PQVMvWJgSYfomasqNiDypthFTzCnOX,'info_title':PQVMvWJgSYfomasqNiDypthFTzCnXL,'aired':PQVMvWJgSYfomasqNiDypthFTzCnXj,'studio':PQVMvWJgSYfomasqNiDypthFTzCnXb,'frequency':PQVMvWJgSYfomasqNiDypthFTzCnXu}
    PQVMvWJgSYfomasqNiDypthFTzCndb.append(PQVMvWJgSYfomasqNiDypthFTzCnXU)
   if PQVMvWJgSYfomasqNiDypthFTzCnXA>page_int:PQVMvWJgSYfomasqNiDypthFTzCnkx=PQVMvWJgSYfomasqNiDypthFTzCncH
  except PQVMvWJgSYfomasqNiDypthFTzCnce as exception:
   PQVMvWJgSYfomasqNiDypthFTzCncU(exception)
  return PQVMvWJgSYfomasqNiDypthFTzCndb,PQVMvWJgSYfomasqNiDypthFTzCnkx,PQVMvWJgSYfomasqNiDypthFTzCnXA
 def GetMovieList(PQVMvWJgSYfomasqNiDypthFTzCnUH,genre,orderby,page_int):
  PQVMvWJgSYfomasqNiDypthFTzCndb=[]
  PQVMvWJgSYfomasqNiDypthFTzCnkx=PQVMvWJgSYfomasqNiDypthFTzCncO
  try:
   if genre=='PARAMOUNT':
    PQVMvWJgSYfomasqNiDypthFTzCndL ='/v2/media/paramount/movies'
   else:
    PQVMvWJgSYfomasqNiDypthFTzCndL ='/v2/media/movies'
   PQVMvWJgSYfomasqNiDypthFTzCnKc=PQVMvWJgSYfomasqNiDypthFTzCnUH.GetDefaultParams()
   PQVMvWJgSYfomasqNiDypthFTzCndE={'pageSize':PQVMvWJgSYfomasqNiDypthFTzCncB(PQVMvWJgSYfomasqNiDypthFTzCnUH.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N' if genre!='diversityYn' else 'Y','pageNo':PQVMvWJgSYfomasqNiDypthFTzCncB(page_int),}
   if genre not in['all','PARAMOUNT','diversityYn']:PQVMvWJgSYfomasqNiDypthFTzCndE['categoryCode']=genre
   PQVMvWJgSYfomasqNiDypthFTzCndE['productPackageCode']=','.join(PQVMvWJgSYfomasqNiDypthFTzCnUH.MOVIE_LITE)
   PQVMvWJgSYfomasqNiDypthFTzCnKc.update(PQVMvWJgSYfomasqNiDypthFTzCndE)
   PQVMvWJgSYfomasqNiDypthFTzCnKR=PQVMvWJgSYfomasqNiDypthFTzCnUH.API_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCndL
   PQVMvWJgSYfomasqNiDypthFTzCnde=PQVMvWJgSYfomasqNiDypthFTzCnUH.callRequestCookies('Get',PQVMvWJgSYfomasqNiDypthFTzCnKR,payload=PQVMvWJgSYfomasqNiDypthFTzCnck,params=PQVMvWJgSYfomasqNiDypthFTzCnKc,headers=PQVMvWJgSYfomasqNiDypthFTzCnck,cookies=PQVMvWJgSYfomasqNiDypthFTzCnck)
   PQVMvWJgSYfomasqNiDypthFTzCndI=json.loads(PQVMvWJgSYfomasqNiDypthFTzCnde.text)
   if not('result' in PQVMvWJgSYfomasqNiDypthFTzCndI['body']):return PQVMvWJgSYfomasqNiDypthFTzCndb,PQVMvWJgSYfomasqNiDypthFTzCnkx
   PQVMvWJgSYfomasqNiDypthFTzCnkI=PQVMvWJgSYfomasqNiDypthFTzCndI['body']['result']
   for PQVMvWJgSYfomasqNiDypthFTzCnKU in PQVMvWJgSYfomasqNiDypthFTzCnkI:
    if 'release_date' in PQVMvWJgSYfomasqNiDypthFTzCnKU.get('movie'):
     PQVMvWJgSYfomasqNiDypthFTzCnOu=PQVMvWJgSYfomasqNiDypthFTzCncB(PQVMvWJgSYfomasqNiDypthFTzCnKU.get('movie').get('release_date'))[:4]
    else:
     PQVMvWJgSYfomasqNiDypthFTzCnOu=PQVMvWJgSYfomasqNiDypthFTzCnck
    PQVMvWJgSYfomasqNiDypthFTzCnXl =PQVMvWJgSYfomasqNiDypthFTzCnKU['movie']['code']
    PQVMvWJgSYfomasqNiDypthFTzCnOk =PQVMvWJgSYfomasqNiDypthFTzCnKU['movie']['name']['ko'].strip()
    if PQVMvWJgSYfomasqNiDypthFTzCnOu not in[PQVMvWJgSYfomasqNiDypthFTzCnck,'0','']:PQVMvWJgSYfomasqNiDypthFTzCnOk+=u' (%s)'%(PQVMvWJgSYfomasqNiDypthFTzCnOu)
    PQVMvWJgSYfomasqNiDypthFTzCnOc=''
    PQVMvWJgSYfomasqNiDypthFTzCnOH =''
    PQVMvWJgSYfomasqNiDypthFTzCnOR=''
    for PQVMvWJgSYfomasqNiDypthFTzCnOB in PQVMvWJgSYfomasqNiDypthFTzCnKU['movie']['image']:
     if PQVMvWJgSYfomasqNiDypthFTzCnOB['code']=='CAIM2100':PQVMvWJgSYfomasqNiDypthFTzCnOc =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB['url']
     elif PQVMvWJgSYfomasqNiDypthFTzCnOB['code']=='CAIM0400':PQVMvWJgSYfomasqNiDypthFTzCnOH =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB['url']
     elif PQVMvWJgSYfomasqNiDypthFTzCnOB['code']=='CAIM1800':PQVMvWJgSYfomasqNiDypthFTzCnOR=PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB['url']
    PQVMvWJgSYfomasqNiDypthFTzCnOX =PQVMvWJgSYfomasqNiDypthFTzCnKU['movie']['story']['ko']
    try:
     PQVMvWJgSYfomasqNiDypthFTzCnXL =PQVMvWJgSYfomasqNiDypthFTzCnKU['movie']['name']['ko'].strip()
     PQVMvWJgSYfomasqNiDypthFTzCnOj =PQVMvWJgSYfomasqNiDypthFTzCnUk.get(PQVMvWJgSYfomasqNiDypthFTzCnKU.get('grade_code'))
     PQVMvWJgSYfomasqNiDypthFTzCnOG=[]
     PQVMvWJgSYfomasqNiDypthFTzCnOr=[]
     PQVMvWJgSYfomasqNiDypthFTzCnOL=[]
     PQVMvWJgSYfomasqNiDypthFTzCnXx=0
     PQVMvWJgSYfomasqNiDypthFTzCnOb=''
     PQVMvWJgSYfomasqNiDypthFTzCnXb =''
     for PQVMvWJgSYfomasqNiDypthFTzCnOl in PQVMvWJgSYfomasqNiDypthFTzCnKU.get('movie').get('actor'):
      if PQVMvWJgSYfomasqNiDypthFTzCnOl!='':PQVMvWJgSYfomasqNiDypthFTzCnOG.append(PQVMvWJgSYfomasqNiDypthFTzCnOl)
     for PQVMvWJgSYfomasqNiDypthFTzCnOx in PQVMvWJgSYfomasqNiDypthFTzCnKU.get('movie').get('director'):
      if PQVMvWJgSYfomasqNiDypthFTzCnOx!='':PQVMvWJgSYfomasqNiDypthFTzCnOr.append(PQVMvWJgSYfomasqNiDypthFTzCnOx)
     if PQVMvWJgSYfomasqNiDypthFTzCnKU.get('movie').get('category1_name').get('ko')!='':
      PQVMvWJgSYfomasqNiDypthFTzCnOL.append(PQVMvWJgSYfomasqNiDypthFTzCnKU['movie']['category1_name']['ko'])
     if PQVMvWJgSYfomasqNiDypthFTzCnKU.get('movie').get('category2_name').get('ko')!='':
      PQVMvWJgSYfomasqNiDypthFTzCnOL.append(PQVMvWJgSYfomasqNiDypthFTzCnKU['movie']['category2_name']['ko'])
     if 'duration' in PQVMvWJgSYfomasqNiDypthFTzCnKU.get('movie'):PQVMvWJgSYfomasqNiDypthFTzCnXx=PQVMvWJgSYfomasqNiDypthFTzCnKU.get('movie').get('duration')
     if 'release_date' in PQVMvWJgSYfomasqNiDypthFTzCnKU.get('movie'):
      PQVMvWJgSYfomasqNiDypthFTzCnOE=PQVMvWJgSYfomasqNiDypthFTzCncB(PQVMvWJgSYfomasqNiDypthFTzCnKU.get('movie').get('release_date'))
      if PQVMvWJgSYfomasqNiDypthFTzCnOE!='0':PQVMvWJgSYfomasqNiDypthFTzCnOb='%s-%s-%s'%(PQVMvWJgSYfomasqNiDypthFTzCnOE[:4],PQVMvWJgSYfomasqNiDypthFTzCnOE[4:6],PQVMvWJgSYfomasqNiDypthFTzCnOE[6:])
     if 'production' in PQVMvWJgSYfomasqNiDypthFTzCnKU.get('movie'):PQVMvWJgSYfomasqNiDypthFTzCnXb=PQVMvWJgSYfomasqNiDypthFTzCnKU.get('movie').get('production')
    except:
     PQVMvWJgSYfomasqNiDypthFTzCnck
    PQVMvWJgSYfomasqNiDypthFTzCnXU={'moviecode':PQVMvWJgSYfomasqNiDypthFTzCnXl,'title':PQVMvWJgSYfomasqNiDypthFTzCnOk,'thumbnail':{'poster':PQVMvWJgSYfomasqNiDypthFTzCnOc,'thumb':PQVMvWJgSYfomasqNiDypthFTzCnOH,'clearlogo':PQVMvWJgSYfomasqNiDypthFTzCnOR,'fanart':PQVMvWJgSYfomasqNiDypthFTzCnOH},'synopsis':PQVMvWJgSYfomasqNiDypthFTzCnOX,'info_title':PQVMvWJgSYfomasqNiDypthFTzCnXL,'year':PQVMvWJgSYfomasqNiDypthFTzCnOu,'cast':PQVMvWJgSYfomasqNiDypthFTzCnOG,'director':PQVMvWJgSYfomasqNiDypthFTzCnOr,'info_genre':PQVMvWJgSYfomasqNiDypthFTzCnOL,'duration':PQVMvWJgSYfomasqNiDypthFTzCnXx,'premiered':PQVMvWJgSYfomasqNiDypthFTzCnOb,'studio':PQVMvWJgSYfomasqNiDypthFTzCnXb,'mpaa':PQVMvWJgSYfomasqNiDypthFTzCnOj}
    PQVMvWJgSYfomasqNiDypthFTzCnXE=PQVMvWJgSYfomasqNiDypthFTzCncO
    for PQVMvWJgSYfomasqNiDypthFTzCnXI in PQVMvWJgSYfomasqNiDypthFTzCnKU['billing_package_id']:
     if PQVMvWJgSYfomasqNiDypthFTzCnXI in PQVMvWJgSYfomasqNiDypthFTzCnUH.MOVIE_LITE:
      PQVMvWJgSYfomasqNiDypthFTzCnXE=PQVMvWJgSYfomasqNiDypthFTzCncH
      break
    if PQVMvWJgSYfomasqNiDypthFTzCnXE==PQVMvWJgSYfomasqNiDypthFTzCncO: 
     PQVMvWJgSYfomasqNiDypthFTzCnXU['title']=PQVMvWJgSYfomasqNiDypthFTzCnXU['title']+' [개별구매]'
    PQVMvWJgSYfomasqNiDypthFTzCndb.append(PQVMvWJgSYfomasqNiDypthFTzCnXU)
   if PQVMvWJgSYfomasqNiDypthFTzCndI['body']['has_more']=='Y':PQVMvWJgSYfomasqNiDypthFTzCnkx=PQVMvWJgSYfomasqNiDypthFTzCncH
  except PQVMvWJgSYfomasqNiDypthFTzCnce as exception:
   PQVMvWJgSYfomasqNiDypthFTzCncU(exception)
  return PQVMvWJgSYfomasqNiDypthFTzCndb,PQVMvWJgSYfomasqNiDypthFTzCnkx
 def Get_UHD_MovieList(PQVMvWJgSYfomasqNiDypthFTzCnUH,page_int):
  PQVMvWJgSYfomasqNiDypthFTzCndb=[]
  PQVMvWJgSYfomasqNiDypthFTzCnkx=PQVMvWJgSYfomasqNiDypthFTzCncO
  try:
   PQVMvWJgSYfomasqNiDypthFTzCndL ='/v2/operator/highlights'
   PQVMvWJgSYfomasqNiDypthFTzCnKc=PQVMvWJgSYfomasqNiDypthFTzCnUH.GetDefaultParams(uhd=PQVMvWJgSYfomasqNiDypthFTzCncH)
   PQVMvWJgSYfomasqNiDypthFTzCndE={'positionKey':'SMTV_MV_4K','pageSize':'20','page_int':PQVMvWJgSYfomasqNiDypthFTzCncB(page_int),'pocType':'APP_X_TVING_4.0.0',}
   PQVMvWJgSYfomasqNiDypthFTzCnKc.update(PQVMvWJgSYfomasqNiDypthFTzCndE)
   PQVMvWJgSYfomasqNiDypthFTzCnKR=PQVMvWJgSYfomasqNiDypthFTzCnUH.API_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCndL
   PQVMvWJgSYfomasqNiDypthFTzCnde=PQVMvWJgSYfomasqNiDypthFTzCnUH.callRequestCookies('Get',PQVMvWJgSYfomasqNiDypthFTzCnKR,payload=PQVMvWJgSYfomasqNiDypthFTzCnck,params=PQVMvWJgSYfomasqNiDypthFTzCnKc,headers=PQVMvWJgSYfomasqNiDypthFTzCnck,cookies=PQVMvWJgSYfomasqNiDypthFTzCnck)
   PQVMvWJgSYfomasqNiDypthFTzCndI=json.loads(PQVMvWJgSYfomasqNiDypthFTzCnde.text)
   if not('result' in PQVMvWJgSYfomasqNiDypthFTzCndI['body']):return PQVMvWJgSYfomasqNiDypthFTzCndb,PQVMvWJgSYfomasqNiDypthFTzCnkx
   PQVMvWJgSYfomasqNiDypthFTzCnkI=PQVMvWJgSYfomasqNiDypthFTzCndI['body']['result']
   for PQVMvWJgSYfomasqNiDypthFTzCnKU in PQVMvWJgSYfomasqNiDypthFTzCnkI:
    PQVMvWJgSYfomasqNiDypthFTzCnXk=PQVMvWJgSYfomasqNiDypthFTzCnKU['content']['movie']
    PQVMvWJgSYfomasqNiDypthFTzCnXO =PQVMvWJgSYfomasqNiDypthFTzCnXk['code']
    PQVMvWJgSYfomasqNiDypthFTzCnOk =PQVMvWJgSYfomasqNiDypthFTzCnXk['name']['ko'].strip()
    PQVMvWJgSYfomasqNiDypthFTzCnXL =PQVMvWJgSYfomasqNiDypthFTzCnXk['name']['ko'].strip()
    PQVMvWJgSYfomasqNiDypthFTzCnOu =PQVMvWJgSYfomasqNiDypthFTzCnXk['product_year']
    if PQVMvWJgSYfomasqNiDypthFTzCnOu:PQVMvWJgSYfomasqNiDypthFTzCnOk+=u' (%s)'%(PQVMvWJgSYfomasqNiDypthFTzCnXk['product_year'])
    PQVMvWJgSYfomasqNiDypthFTzCnOX =PQVMvWJgSYfomasqNiDypthFTzCnXk['story']['ko']
    PQVMvWJgSYfomasqNiDypthFTzCnXx =PQVMvWJgSYfomasqNiDypthFTzCnXk['duration']
    PQVMvWJgSYfomasqNiDypthFTzCnOj =PQVMvWJgSYfomasqNiDypthFTzCnUk.get(PQVMvWJgSYfomasqNiDypthFTzCnXk.get('grade_code'))
    PQVMvWJgSYfomasqNiDypthFTzCnXb =PQVMvWJgSYfomasqNiDypthFTzCnXk['production']
    PQVMvWJgSYfomasqNiDypthFTzCnOc=''
    PQVMvWJgSYfomasqNiDypthFTzCnOH =''
    PQVMvWJgSYfomasqNiDypthFTzCnOR=''
    PQVMvWJgSYfomasqNiDypthFTzCnOL =[]
    PQVMvWJgSYfomasqNiDypthFTzCnOG =[]
    PQVMvWJgSYfomasqNiDypthFTzCnOr=[]
    PQVMvWJgSYfomasqNiDypthFTzCnOb =''
    for PQVMvWJgSYfomasqNiDypthFTzCnOB in PQVMvWJgSYfomasqNiDypthFTzCnXk['image']:
     if PQVMvWJgSYfomasqNiDypthFTzCnOB['code']=='CAIM2100':PQVMvWJgSYfomasqNiDypthFTzCnOc =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB['url']
     elif PQVMvWJgSYfomasqNiDypthFTzCnOB['code']=='CAIM0400':PQVMvWJgSYfomasqNiDypthFTzCnOH =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB['url']
     elif PQVMvWJgSYfomasqNiDypthFTzCnOB['code']=='CAIM1800':PQVMvWJgSYfomasqNiDypthFTzCnOR=PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB['url']
    if PQVMvWJgSYfomasqNiDypthFTzCnXk['release_date']not in[PQVMvWJgSYfomasqNiDypthFTzCnck,0]:
     PQVMvWJgSYfomasqNiDypthFTzCnOE=PQVMvWJgSYfomasqNiDypthFTzCncB(PQVMvWJgSYfomasqNiDypthFTzCnXk['release_date'])
     if PQVMvWJgSYfomasqNiDypthFTzCnOE!='0':PQVMvWJgSYfomasqNiDypthFTzCnOb='%s-%s-%s'%(PQVMvWJgSYfomasqNiDypthFTzCnOE[:4],PQVMvWJgSYfomasqNiDypthFTzCnOE[4:6],PQVMvWJgSYfomasqNiDypthFTzCnOE[6:])
    if PQVMvWJgSYfomasqNiDypthFTzCnXk.get('category1_name').get('ko')!='':
     PQVMvWJgSYfomasqNiDypthFTzCnOL.append(PQVMvWJgSYfomasqNiDypthFTzCnXk['category1_name']['ko'])
    if PQVMvWJgSYfomasqNiDypthFTzCnXk.get('category2_name').get('ko')!='':
     PQVMvWJgSYfomasqNiDypthFTzCnOL.append(PQVMvWJgSYfomasqNiDypthFTzCnXk['category2_name']['ko'])
    for PQVMvWJgSYfomasqNiDypthFTzCnOl in PQVMvWJgSYfomasqNiDypthFTzCnXk.get('actor'):
     if PQVMvWJgSYfomasqNiDypthFTzCnOl!='':PQVMvWJgSYfomasqNiDypthFTzCnOG.append(PQVMvWJgSYfomasqNiDypthFTzCnOl)
    for PQVMvWJgSYfomasqNiDypthFTzCnOx in PQVMvWJgSYfomasqNiDypthFTzCnXk.get('director'):
     if PQVMvWJgSYfomasqNiDypthFTzCnOx!='':PQVMvWJgSYfomasqNiDypthFTzCnOr.append(PQVMvWJgSYfomasqNiDypthFTzCnOx)
    PQVMvWJgSYfomasqNiDypthFTzCnXU={'moviecode':PQVMvWJgSYfomasqNiDypthFTzCnXO,'title':PQVMvWJgSYfomasqNiDypthFTzCnOk,'thumbnail':{'poster':PQVMvWJgSYfomasqNiDypthFTzCnOc,'thumb':PQVMvWJgSYfomasqNiDypthFTzCnOH,'clearlogo':PQVMvWJgSYfomasqNiDypthFTzCnOR,'fanart':PQVMvWJgSYfomasqNiDypthFTzCnOH},'year':PQVMvWJgSYfomasqNiDypthFTzCnOu,'info_title':PQVMvWJgSYfomasqNiDypthFTzCnXL,'synopsis':PQVMvWJgSYfomasqNiDypthFTzCnOX,'mpaa':PQVMvWJgSYfomasqNiDypthFTzCnOj,'duration':PQVMvWJgSYfomasqNiDypthFTzCnXx,'premiered':PQVMvWJgSYfomasqNiDypthFTzCnOb,'studio':PQVMvWJgSYfomasqNiDypthFTzCnXb,'info_genre':PQVMvWJgSYfomasqNiDypthFTzCnOL,'cast':PQVMvWJgSYfomasqNiDypthFTzCnOG,'director':PQVMvWJgSYfomasqNiDypthFTzCnOr,}
    PQVMvWJgSYfomasqNiDypthFTzCndb.append(PQVMvWJgSYfomasqNiDypthFTzCnXU)
  except PQVMvWJgSYfomasqNiDypthFTzCnce as exception:
   PQVMvWJgSYfomasqNiDypthFTzCncU(exception)
  return PQVMvWJgSYfomasqNiDypthFTzCndb,PQVMvWJgSYfomasqNiDypthFTzCnkx
 def GetMovieGenre(PQVMvWJgSYfomasqNiDypthFTzCnUH):
  PQVMvWJgSYfomasqNiDypthFTzCndb=[]
  PQVMvWJgSYfomasqNiDypthFTzCnkx=PQVMvWJgSYfomasqNiDypthFTzCncO
  try:
   PQVMvWJgSYfomasqNiDypthFTzCndL ='/v2/media/movie/curations'
   PQVMvWJgSYfomasqNiDypthFTzCnKc=PQVMvWJgSYfomasqNiDypthFTzCnUH.GetDefaultParams()
   PQVMvWJgSYfomasqNiDypthFTzCndE={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   PQVMvWJgSYfomasqNiDypthFTzCnKc.update(PQVMvWJgSYfomasqNiDypthFTzCndE)
   PQVMvWJgSYfomasqNiDypthFTzCnKR=PQVMvWJgSYfomasqNiDypthFTzCnUH.API_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCndL
   PQVMvWJgSYfomasqNiDypthFTzCnde=PQVMvWJgSYfomasqNiDypthFTzCnUH.callRequestCookies('Get',PQVMvWJgSYfomasqNiDypthFTzCnKR,payload=PQVMvWJgSYfomasqNiDypthFTzCnck,params=PQVMvWJgSYfomasqNiDypthFTzCnKc,headers=PQVMvWJgSYfomasqNiDypthFTzCnck,cookies=PQVMvWJgSYfomasqNiDypthFTzCnck)
   PQVMvWJgSYfomasqNiDypthFTzCndI=json.loads(PQVMvWJgSYfomasqNiDypthFTzCnde.text)
   if not('result' in PQVMvWJgSYfomasqNiDypthFTzCndI['body']):return PQVMvWJgSYfomasqNiDypthFTzCndb,PQVMvWJgSYfomasqNiDypthFTzCnkx
   PQVMvWJgSYfomasqNiDypthFTzCnkI=PQVMvWJgSYfomasqNiDypthFTzCndI['body']['result']
   for PQVMvWJgSYfomasqNiDypthFTzCnKU in PQVMvWJgSYfomasqNiDypthFTzCnkI:
    PQVMvWJgSYfomasqNiDypthFTzCnHU =PQVMvWJgSYfomasqNiDypthFTzCnKU['curation_code']
    PQVMvWJgSYfomasqNiDypthFTzCnHd =PQVMvWJgSYfomasqNiDypthFTzCnKU['curation_name']
    PQVMvWJgSYfomasqNiDypthFTzCnXU={'curation_code':PQVMvWJgSYfomasqNiDypthFTzCnHU,'curation_name':PQVMvWJgSYfomasqNiDypthFTzCnHd}
    PQVMvWJgSYfomasqNiDypthFTzCndb.append(PQVMvWJgSYfomasqNiDypthFTzCnXU)
  except PQVMvWJgSYfomasqNiDypthFTzCnce as exception:
   PQVMvWJgSYfomasqNiDypthFTzCncU(exception)
  return PQVMvWJgSYfomasqNiDypthFTzCndb,PQVMvWJgSYfomasqNiDypthFTzCnkx
 def GetSearchList(PQVMvWJgSYfomasqNiDypthFTzCnUH,search_key,page_int,stype):
  PQVMvWJgSYfomasqNiDypthFTzCnHK=[]
  PQVMvWJgSYfomasqNiDypthFTzCnkx=PQVMvWJgSYfomasqNiDypthFTzCncO
  try:
   PQVMvWJgSYfomasqNiDypthFTzCndL ='/search/getSearch.jsp'
   PQVMvWJgSYfomasqNiDypthFTzCnKc=PQVMvWJgSYfomasqNiDypthFTzCnUH.GetDefaultParams()
   PQVMvWJgSYfomasqNiDypthFTzCndE={'kwd':search_key,'category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':PQVMvWJgSYfomasqNiDypthFTzCncB(page_int),'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','pageSize':PQVMvWJgSYfomasqNiDypthFTzCncB(PQVMvWJgSYfomasqNiDypthFTzCnUH.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':PQVMvWJgSYfomasqNiDypthFTzCnUH.SCREENCODE,'os':PQVMvWJgSYfomasqNiDypthFTzCnUH.OSCODE,'network':PQVMvWJgSYfomasqNiDypthFTzCnUH.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':PQVMvWJgSYfomasqNiDypthFTzCncB(PQVMvWJgSYfomasqNiDypthFTzCnUH.SEARCH_LIMIT)if stype=='vod' else '0','vodMVReqCnt':PQVMvWJgSYfomasqNiDypthFTzCncB(PQVMvWJgSYfomasqNiDypthFTzCnUH.SEARCH_LIMIT)if stype=='movie' else '0','aloneReqCnt':'0','smrclipReqCnt':'0','pickClipReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','apiKey':PQVMvWJgSYfomasqNiDypthFTzCnUH.APIKEY,'networkCode':PQVMvWJgSYfomasqNiDypthFTzCnUH.NETWORKCODE,'osCode ':PQVMvWJgSYfomasqNiDypthFTzCnUH.OSCODE,'teleCode ':PQVMvWJgSYfomasqNiDypthFTzCnUH.TELECODE,'screenCode ':PQVMvWJgSYfomasqNiDypthFTzCnUH.SCREENCODE}
   PQVMvWJgSYfomasqNiDypthFTzCnKR=PQVMvWJgSYfomasqNiDypthFTzCnUH.SEARCH_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCndL
   PQVMvWJgSYfomasqNiDypthFTzCnde=PQVMvWJgSYfomasqNiDypthFTzCnUH.callRequestCookies('Get',PQVMvWJgSYfomasqNiDypthFTzCnKR,payload=PQVMvWJgSYfomasqNiDypthFTzCnck,params=PQVMvWJgSYfomasqNiDypthFTzCndE,headers=PQVMvWJgSYfomasqNiDypthFTzCnck,cookies=PQVMvWJgSYfomasqNiDypthFTzCnck)
   PQVMvWJgSYfomasqNiDypthFTzCndI=json.loads(PQVMvWJgSYfomasqNiDypthFTzCnde.text)
   if stype=='vod':
    if not('programRsb' in PQVMvWJgSYfomasqNiDypthFTzCndI):return PQVMvWJgSYfomasqNiDypthFTzCnHK,PQVMvWJgSYfomasqNiDypthFTzCnkx
    PQVMvWJgSYfomasqNiDypthFTzCnHk=PQVMvWJgSYfomasqNiDypthFTzCndI['programRsb']['dataList']
    PQVMvWJgSYfomasqNiDypthFTzCnHO =PQVMvWJgSYfomasqNiDypthFTzCncw(PQVMvWJgSYfomasqNiDypthFTzCndI['programRsb']['count'])
    for PQVMvWJgSYfomasqNiDypthFTzCnKU in PQVMvWJgSYfomasqNiDypthFTzCnHk:
     PQVMvWJgSYfomasqNiDypthFTzCnXd=PQVMvWJgSYfomasqNiDypthFTzCnKU['mast_cd']
     PQVMvWJgSYfomasqNiDypthFTzCnOk =PQVMvWJgSYfomasqNiDypthFTzCnKU['mast_nm']
     PQVMvWJgSYfomasqNiDypthFTzCnOc=PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnKU['web_url4']
     PQVMvWJgSYfomasqNiDypthFTzCnOH =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnKU['web_url']
     try:
      PQVMvWJgSYfomasqNiDypthFTzCnOG =[]
      PQVMvWJgSYfomasqNiDypthFTzCnOr=[]
      PQVMvWJgSYfomasqNiDypthFTzCnOL =[]
      PQVMvWJgSYfomasqNiDypthFTzCnXx =0
      PQVMvWJgSYfomasqNiDypthFTzCnOj =''
      PQVMvWJgSYfomasqNiDypthFTzCnOu =''
      PQVMvWJgSYfomasqNiDypthFTzCnXj =''
      if PQVMvWJgSYfomasqNiDypthFTzCnKU.get('actor') !='' and PQVMvWJgSYfomasqNiDypthFTzCnKU.get('actor') !='-':PQVMvWJgSYfomasqNiDypthFTzCnOG =PQVMvWJgSYfomasqNiDypthFTzCnKU.get('actor').split(',')
      if PQVMvWJgSYfomasqNiDypthFTzCnKU.get('director')!='' and PQVMvWJgSYfomasqNiDypthFTzCnKU.get('director')!='-':PQVMvWJgSYfomasqNiDypthFTzCnOr=PQVMvWJgSYfomasqNiDypthFTzCnKU.get('director').split(',')
      if PQVMvWJgSYfomasqNiDypthFTzCnKU.get('cate_nm')!='' and PQVMvWJgSYfomasqNiDypthFTzCnKU.get('cate_nm')!='-':PQVMvWJgSYfomasqNiDypthFTzCnOL =PQVMvWJgSYfomasqNiDypthFTzCnKU.get('cate_nm').split('/')
      if 'targetage' in PQVMvWJgSYfomasqNiDypthFTzCnKU:PQVMvWJgSYfomasqNiDypthFTzCnOj=PQVMvWJgSYfomasqNiDypthFTzCnKU.get('targetage')
      if 'broad_dt' in PQVMvWJgSYfomasqNiDypthFTzCnKU:
       PQVMvWJgSYfomasqNiDypthFTzCnOE=PQVMvWJgSYfomasqNiDypthFTzCnKU.get('broad_dt')
       PQVMvWJgSYfomasqNiDypthFTzCnXj='%s-%s-%s'%(PQVMvWJgSYfomasqNiDypthFTzCnOE[:4],PQVMvWJgSYfomasqNiDypthFTzCnOE[4:6],PQVMvWJgSYfomasqNiDypthFTzCnOE[6:])
       PQVMvWJgSYfomasqNiDypthFTzCnOu =PQVMvWJgSYfomasqNiDypthFTzCnOE[:4]
     except:
      PQVMvWJgSYfomasqNiDypthFTzCnck
     PQVMvWJgSYfomasqNiDypthFTzCnXU={'program':PQVMvWJgSYfomasqNiDypthFTzCnXd,'title':PQVMvWJgSYfomasqNiDypthFTzCnOk,'thumbnail':{'poster':PQVMvWJgSYfomasqNiDypthFTzCnOc,'thumb':PQVMvWJgSYfomasqNiDypthFTzCnOH,'fanart':PQVMvWJgSYfomasqNiDypthFTzCnOH},'synopsis':'','cast':PQVMvWJgSYfomasqNiDypthFTzCnOG,'director':PQVMvWJgSYfomasqNiDypthFTzCnOr,'info_genre':PQVMvWJgSYfomasqNiDypthFTzCnOL,'duration':PQVMvWJgSYfomasqNiDypthFTzCnXx,'mpaa':PQVMvWJgSYfomasqNiDypthFTzCnOj,'year':PQVMvWJgSYfomasqNiDypthFTzCnOu,'aired':PQVMvWJgSYfomasqNiDypthFTzCnXj}
     PQVMvWJgSYfomasqNiDypthFTzCnHK.append(PQVMvWJgSYfomasqNiDypthFTzCnXU)
   else:
    if not('vodMVRsb' in PQVMvWJgSYfomasqNiDypthFTzCndI):return PQVMvWJgSYfomasqNiDypthFTzCnHK,PQVMvWJgSYfomasqNiDypthFTzCnkx
    PQVMvWJgSYfomasqNiDypthFTzCnHX=PQVMvWJgSYfomasqNiDypthFTzCndI['vodMVRsb']['dataList']
    PQVMvWJgSYfomasqNiDypthFTzCnHO =PQVMvWJgSYfomasqNiDypthFTzCncw(PQVMvWJgSYfomasqNiDypthFTzCndI['vodMVRsb']['count'])
    for PQVMvWJgSYfomasqNiDypthFTzCnKU in PQVMvWJgSYfomasqNiDypthFTzCnHX:
     PQVMvWJgSYfomasqNiDypthFTzCnXd=PQVMvWJgSYfomasqNiDypthFTzCnKU['mast_cd']
     PQVMvWJgSYfomasqNiDypthFTzCnOk =PQVMvWJgSYfomasqNiDypthFTzCnKU['mast_nm'].strip()
     PQVMvWJgSYfomasqNiDypthFTzCnOc =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnKU['web_url']
     PQVMvWJgSYfomasqNiDypthFTzCnOH =PQVMvWJgSYfomasqNiDypthFTzCnOc
     PQVMvWJgSYfomasqNiDypthFTzCnOR=''
     try:
      PQVMvWJgSYfomasqNiDypthFTzCnOG =[]
      PQVMvWJgSYfomasqNiDypthFTzCnOr=[]
      PQVMvWJgSYfomasqNiDypthFTzCnOL =[]
      PQVMvWJgSYfomasqNiDypthFTzCnXx =0
      PQVMvWJgSYfomasqNiDypthFTzCnOj =''
      PQVMvWJgSYfomasqNiDypthFTzCnOu =''
      PQVMvWJgSYfomasqNiDypthFTzCnXj =''
      if PQVMvWJgSYfomasqNiDypthFTzCnKU.get('actor') !='' and PQVMvWJgSYfomasqNiDypthFTzCnKU.get('actor') !='-':PQVMvWJgSYfomasqNiDypthFTzCnOG =PQVMvWJgSYfomasqNiDypthFTzCnKU.get('actor').split(',')
      if PQVMvWJgSYfomasqNiDypthFTzCnKU.get('director')!='' and PQVMvWJgSYfomasqNiDypthFTzCnKU.get('director')!='-':PQVMvWJgSYfomasqNiDypthFTzCnOr=PQVMvWJgSYfomasqNiDypthFTzCnKU.get('director').split(',')
      if PQVMvWJgSYfomasqNiDypthFTzCnKU.get('cate_nm')!='' and PQVMvWJgSYfomasqNiDypthFTzCnKU.get('cate_nm')!='-':PQVMvWJgSYfomasqNiDypthFTzCnOL =PQVMvWJgSYfomasqNiDypthFTzCnKU.get('cate_nm').split('/')
      if PQVMvWJgSYfomasqNiDypthFTzCnKU.get('runtime_sec')!='':PQVMvWJgSYfomasqNiDypthFTzCnXx=PQVMvWJgSYfomasqNiDypthFTzCnKU.get('runtime_sec')
      if 'grade_nm' in PQVMvWJgSYfomasqNiDypthFTzCnKU:PQVMvWJgSYfomasqNiDypthFTzCnOj=PQVMvWJgSYfomasqNiDypthFTzCnKU.get('grade_nm')
      PQVMvWJgSYfomasqNiDypthFTzCnOE=PQVMvWJgSYfomasqNiDypthFTzCnKU.get('broad_dt')
      if data_str!='':
       PQVMvWJgSYfomasqNiDypthFTzCnXj='%s-%s-%s'%(PQVMvWJgSYfomasqNiDypthFTzCnOE[:4],PQVMvWJgSYfomasqNiDypthFTzCnOE[4:6],PQVMvWJgSYfomasqNiDypthFTzCnOE[6:])
       PQVMvWJgSYfomasqNiDypthFTzCnOu =PQVMvWJgSYfomasqNiDypthFTzCnOE[:4]
     except:
      PQVMvWJgSYfomasqNiDypthFTzCnck
     PQVMvWJgSYfomasqNiDypthFTzCnXU={'movie':PQVMvWJgSYfomasqNiDypthFTzCnXd,'title':PQVMvWJgSYfomasqNiDypthFTzCnOk,'thumbnail':{'poster':PQVMvWJgSYfomasqNiDypthFTzCnOc,'thumb':PQVMvWJgSYfomasqNiDypthFTzCnOH,'fanart':PQVMvWJgSYfomasqNiDypthFTzCnOH,'clearlogo':PQVMvWJgSYfomasqNiDypthFTzCnOR},'synopsis':'','cast':PQVMvWJgSYfomasqNiDypthFTzCnOG,'director':PQVMvWJgSYfomasqNiDypthFTzCnOr,'info_genre':PQVMvWJgSYfomasqNiDypthFTzCnOL,'duration':PQVMvWJgSYfomasqNiDypthFTzCnXx,'mpaa':PQVMvWJgSYfomasqNiDypthFTzCnOj,'year':PQVMvWJgSYfomasqNiDypthFTzCnOu,'aired':PQVMvWJgSYfomasqNiDypthFTzCnXj}
     PQVMvWJgSYfomasqNiDypthFTzCnHK.append(PQVMvWJgSYfomasqNiDypthFTzCnXU)
   if PQVMvWJgSYfomasqNiDypthFTzCnHO>(page_int*PQVMvWJgSYfomasqNiDypthFTzCnUH.SEARCH_LIMIT):PQVMvWJgSYfomasqNiDypthFTzCnkx=PQVMvWJgSYfomasqNiDypthFTzCncH
  except PQVMvWJgSYfomasqNiDypthFTzCnce as exception:
   PQVMvWJgSYfomasqNiDypthFTzCncU(exception)
  return PQVMvWJgSYfomasqNiDypthFTzCnHK,PQVMvWJgSYfomasqNiDypthFTzCnkx
 def GetBookmarkInfo(PQVMvWJgSYfomasqNiDypthFTzCnUH,videoid,vidtype):
  PQVMvWJgSYfomasqNiDypthFTzCnHc={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   PQVMvWJgSYfomasqNiDypthFTzCnKR=PQVMvWJgSYfomasqNiDypthFTzCnUH.API_DOMAIN+'/v2/media/program/'+videoid
   PQVMvWJgSYfomasqNiDypthFTzCnKc=PQVMvWJgSYfomasqNiDypthFTzCnUH.GetDefaultParams()
   PQVMvWJgSYfomasqNiDypthFTzCndE={'pageNo':'1','pageSize':'10','order':'name',}
   PQVMvWJgSYfomasqNiDypthFTzCnKc.update(PQVMvWJgSYfomasqNiDypthFTzCndE)
   PQVMvWJgSYfomasqNiDypthFTzCnde=PQVMvWJgSYfomasqNiDypthFTzCnUH.callRequestCookies('Get',PQVMvWJgSYfomasqNiDypthFTzCnKR,payload=PQVMvWJgSYfomasqNiDypthFTzCnck,params=PQVMvWJgSYfomasqNiDypthFTzCnKc,headers=PQVMvWJgSYfomasqNiDypthFTzCnck,cookies=PQVMvWJgSYfomasqNiDypthFTzCnck)
   PQVMvWJgSYfomasqNiDypthFTzCnXH=json.loads(PQVMvWJgSYfomasqNiDypthFTzCnde.text)
   if not('body' in PQVMvWJgSYfomasqNiDypthFTzCnXH):return{}
   PQVMvWJgSYfomasqNiDypthFTzCnHR=PQVMvWJgSYfomasqNiDypthFTzCnXH['body']
   PQVMvWJgSYfomasqNiDypthFTzCnOk=PQVMvWJgSYfomasqNiDypthFTzCnHR.get('name').get('ko').strip()
   PQVMvWJgSYfomasqNiDypthFTzCnHc['saveinfo']['title'] =PQVMvWJgSYfomasqNiDypthFTzCnOk
   PQVMvWJgSYfomasqNiDypthFTzCnHc['saveinfo']['infoLabels']['title']=PQVMvWJgSYfomasqNiDypthFTzCnOk
   PQVMvWJgSYfomasqNiDypthFTzCnHc['saveinfo']['infoLabels']['mpaa'] =PQVMvWJgSYfomasqNiDypthFTzCnUk.get(PQVMvWJgSYfomasqNiDypthFTzCnHR.get('grade_code'))
   PQVMvWJgSYfomasqNiDypthFTzCnHc['saveinfo']['infoLabels']['plot'] =PQVMvWJgSYfomasqNiDypthFTzCnHR.get('synopsis').get('ko')
   PQVMvWJgSYfomasqNiDypthFTzCnHc['saveinfo']['infoLabels']['year'] =PQVMvWJgSYfomasqNiDypthFTzCnHR.get('product_year')
   PQVMvWJgSYfomasqNiDypthFTzCnHc['saveinfo']['infoLabels']['cast'] =PQVMvWJgSYfomasqNiDypthFTzCnHR.get('actor')
   PQVMvWJgSYfomasqNiDypthFTzCnHc['saveinfo']['infoLabels']['director']=PQVMvWJgSYfomasqNiDypthFTzCnHR.get('director')
   if PQVMvWJgSYfomasqNiDypthFTzCnHR.get('category1_name').get('ko')!='':
    PQVMvWJgSYfomasqNiDypthFTzCnHc['saveinfo']['infoLabels']['genre'].append(PQVMvWJgSYfomasqNiDypthFTzCnHR.get('category1_name').get('ko'))
   if PQVMvWJgSYfomasqNiDypthFTzCnHR.get('category2_name').get('ko')!='':
    PQVMvWJgSYfomasqNiDypthFTzCnHc['saveinfo']['infoLabels']['genre'].append(PQVMvWJgSYfomasqNiDypthFTzCnHR.get('category2_name').get('ko'))
   PQVMvWJgSYfomasqNiDypthFTzCnOE=PQVMvWJgSYfomasqNiDypthFTzCncB(PQVMvWJgSYfomasqNiDypthFTzCnHR.get('broad_dt'))
   if PQVMvWJgSYfomasqNiDypthFTzCnOE!='0':PQVMvWJgSYfomasqNiDypthFTzCnHc['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(PQVMvWJgSYfomasqNiDypthFTzCnOE[:4],PQVMvWJgSYfomasqNiDypthFTzCnOE[4:6],PQVMvWJgSYfomasqNiDypthFTzCnOE[6:])
   PQVMvWJgSYfomasqNiDypthFTzCnOc =''
   PQVMvWJgSYfomasqNiDypthFTzCnOH =''
   PQVMvWJgSYfomasqNiDypthFTzCnOR=''
   PQVMvWJgSYfomasqNiDypthFTzCnOw =''
   PQVMvWJgSYfomasqNiDypthFTzCnOA =''
   for PQVMvWJgSYfomasqNiDypthFTzCnOB in PQVMvWJgSYfomasqNiDypthFTzCnHR.get('image'):
    if PQVMvWJgSYfomasqNiDypthFTzCnOB.get('code')=='CAIP0900':PQVMvWJgSYfomasqNiDypthFTzCnOc =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB.get('url')
    elif PQVMvWJgSYfomasqNiDypthFTzCnOB.get('code')=='CAIP0200':PQVMvWJgSYfomasqNiDypthFTzCnOH =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB.get('url')
    elif PQVMvWJgSYfomasqNiDypthFTzCnOB.get('code')=='CAIP1800':PQVMvWJgSYfomasqNiDypthFTzCnOR=PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB.get('url')
    elif PQVMvWJgSYfomasqNiDypthFTzCnOB.get('code')=='CAIP2000':PQVMvWJgSYfomasqNiDypthFTzCnOw =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB.get('url')
    elif PQVMvWJgSYfomasqNiDypthFTzCnOB.get('code')=='CAIP1900':PQVMvWJgSYfomasqNiDypthFTzCnOA =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB.get('url')
   PQVMvWJgSYfomasqNiDypthFTzCnHc['saveinfo']['thumbnail']['poster']=PQVMvWJgSYfomasqNiDypthFTzCnOc
   PQVMvWJgSYfomasqNiDypthFTzCnHc['saveinfo']['thumbnail']['thumb']=PQVMvWJgSYfomasqNiDypthFTzCnOH
   PQVMvWJgSYfomasqNiDypthFTzCnHc['saveinfo']['thumbnail']['clearlogo']=PQVMvWJgSYfomasqNiDypthFTzCnOR
   PQVMvWJgSYfomasqNiDypthFTzCnHc['saveinfo']['thumbnail']['icon']=PQVMvWJgSYfomasqNiDypthFTzCnOw
   PQVMvWJgSYfomasqNiDypthFTzCnHc['saveinfo']['thumbnail']['banner']=PQVMvWJgSYfomasqNiDypthFTzCnOA
   PQVMvWJgSYfomasqNiDypthFTzCnHc['saveinfo']['thumbnail']['fanart']=PQVMvWJgSYfomasqNiDypthFTzCnOH
  else:
   PQVMvWJgSYfomasqNiDypthFTzCnKR=PQVMvWJgSYfomasqNiDypthFTzCnUH.API_DOMAIN+'/v2a/media/stream/info'
   PQVMvWJgSYfomasqNiDypthFTzCnKc=PQVMvWJgSYfomasqNiDypthFTzCnUH.GetDefaultParams()
   PQVMvWJgSYfomasqNiDypthFTzCndE={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':PQVMvWJgSYfomasqNiDypthFTzCnUH.TV['cookies']['tving_uuid'].split('-')[0],'uuid':PQVMvWJgSYfomasqNiDypthFTzCnUH.TV['cookies']['tving_uuid'],'deviceInfo':'PC_Chrome','noCache':PQVMvWJgSYfomasqNiDypthFTzCncB(PQVMvWJgSYfomasqNiDypthFTzCnUH.GetNoCache(1)),'wm':'Y',}
   PQVMvWJgSYfomasqNiDypthFTzCnKc.update(PQVMvWJgSYfomasqNiDypthFTzCndE)
   PQVMvWJgSYfomasqNiDypthFTzCnde=PQVMvWJgSYfomasqNiDypthFTzCnUH.callRequestCookies('Get',PQVMvWJgSYfomasqNiDypthFTzCnKR,payload=PQVMvWJgSYfomasqNiDypthFTzCnck,params=PQVMvWJgSYfomasqNiDypthFTzCnKc,headers=PQVMvWJgSYfomasqNiDypthFTzCnck,cookies=PQVMvWJgSYfomasqNiDypthFTzCnck)
   PQVMvWJgSYfomasqNiDypthFTzCnXH=json.loads(PQVMvWJgSYfomasqNiDypthFTzCnde.text)
   if not('content' in PQVMvWJgSYfomasqNiDypthFTzCnXH['body']):return{}
   PQVMvWJgSYfomasqNiDypthFTzCnHR=PQVMvWJgSYfomasqNiDypthFTzCnXH['body']['content']['info']['movie']
   PQVMvWJgSYfomasqNiDypthFTzCnOk =PQVMvWJgSYfomasqNiDypthFTzCnHR.get('name').get('ko').strip()
   PQVMvWJgSYfomasqNiDypthFTzCnHc['saveinfo']['infoLabels']['title']=PQVMvWJgSYfomasqNiDypthFTzCnOk
   PQVMvWJgSYfomasqNiDypthFTzCnOk +=u' (%s)'%(PQVMvWJgSYfomasqNiDypthFTzCnHR.get('product_year'))
   PQVMvWJgSYfomasqNiDypthFTzCnHc['saveinfo']['title'] =PQVMvWJgSYfomasqNiDypthFTzCnOk
   PQVMvWJgSYfomasqNiDypthFTzCnHc['saveinfo']['infoLabels']['mpaa'] =PQVMvWJgSYfomasqNiDypthFTzCnUk.get(PQVMvWJgSYfomasqNiDypthFTzCnHR.get('grade_code'))
   PQVMvWJgSYfomasqNiDypthFTzCnHc['saveinfo']['infoLabels']['plot'] =PQVMvWJgSYfomasqNiDypthFTzCnHR.get('story').get('ko')
   PQVMvWJgSYfomasqNiDypthFTzCnHc['saveinfo']['infoLabels']['year'] =PQVMvWJgSYfomasqNiDypthFTzCnHR.get('product_year')
   PQVMvWJgSYfomasqNiDypthFTzCnHc['saveinfo']['infoLabels']['studio'] =PQVMvWJgSYfomasqNiDypthFTzCnHR.get('production')
   PQVMvWJgSYfomasqNiDypthFTzCnHc['saveinfo']['infoLabels']['duration']=PQVMvWJgSYfomasqNiDypthFTzCnHR.get('duration')
   PQVMvWJgSYfomasqNiDypthFTzCnHc['saveinfo']['infoLabels']['cast'] =PQVMvWJgSYfomasqNiDypthFTzCnHR.get('actor')
   PQVMvWJgSYfomasqNiDypthFTzCnHc['saveinfo']['infoLabels']['director']=PQVMvWJgSYfomasqNiDypthFTzCnHR.get('director')
   if PQVMvWJgSYfomasqNiDypthFTzCnHR.get('category1_name').get('ko')!='':
    PQVMvWJgSYfomasqNiDypthFTzCnHc['saveinfo']['infoLabels']['genre'].append(PQVMvWJgSYfomasqNiDypthFTzCnHR.get('category1_name').get('ko'))
   if PQVMvWJgSYfomasqNiDypthFTzCnHR.get('category2_name').get('ko')!='':
    PQVMvWJgSYfomasqNiDypthFTzCnHc['saveinfo']['infoLabels']['genre'].append(PQVMvWJgSYfomasqNiDypthFTzCnHR.get('category2_name').get('ko'))
   PQVMvWJgSYfomasqNiDypthFTzCnOE=PQVMvWJgSYfomasqNiDypthFTzCncB(PQVMvWJgSYfomasqNiDypthFTzCnHR.get('release_date'))
   if PQVMvWJgSYfomasqNiDypthFTzCnOE!='0':PQVMvWJgSYfomasqNiDypthFTzCnHc['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(PQVMvWJgSYfomasqNiDypthFTzCnOE[:4],PQVMvWJgSYfomasqNiDypthFTzCnOE[4:6],PQVMvWJgSYfomasqNiDypthFTzCnOE[6:])
   PQVMvWJgSYfomasqNiDypthFTzCnOc=''
   PQVMvWJgSYfomasqNiDypthFTzCnOH =''
   PQVMvWJgSYfomasqNiDypthFTzCnOR=''
   for PQVMvWJgSYfomasqNiDypthFTzCnOB in PQVMvWJgSYfomasqNiDypthFTzCnHR.get('image'):
    if PQVMvWJgSYfomasqNiDypthFTzCnOB.get('code')=='CAIM2100':PQVMvWJgSYfomasqNiDypthFTzCnOc =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB.get('url')
    elif PQVMvWJgSYfomasqNiDypthFTzCnOB.get('code')=='CAIM0400':PQVMvWJgSYfomasqNiDypthFTzCnOH =PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB.get('url')
    elif PQVMvWJgSYfomasqNiDypthFTzCnOB.get('code')=='CAIM1800':PQVMvWJgSYfomasqNiDypthFTzCnOR=PQVMvWJgSYfomasqNiDypthFTzCnUH.IMG_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCnOB.get('url')
   PQVMvWJgSYfomasqNiDypthFTzCnHc['saveinfo']['thumbnail']['poster']=PQVMvWJgSYfomasqNiDypthFTzCnOc
   PQVMvWJgSYfomasqNiDypthFTzCnHc['saveinfo']['thumbnail']['thumb']=PQVMvWJgSYfomasqNiDypthFTzCnOc 
   PQVMvWJgSYfomasqNiDypthFTzCnHc['saveinfo']['thumbnail']['clearlogo']=PQVMvWJgSYfomasqNiDypthFTzCnOR
   PQVMvWJgSYfomasqNiDypthFTzCnHc['saveinfo']['thumbnail']['fanart']=PQVMvWJgSYfomasqNiDypthFTzCnOH
  return PQVMvWJgSYfomasqNiDypthFTzCnHc
 def GetEuroChannelList(PQVMvWJgSYfomasqNiDypthFTzCnUH):
  PQVMvWJgSYfomasqNiDypthFTzCndb=[]
  try:
   PQVMvWJgSYfomasqNiDypthFTzCndL ='/v2/operator/highlights'
   PQVMvWJgSYfomasqNiDypthFTzCnKc=PQVMvWJgSYfomasqNiDypthFTzCnUH.GetDefaultParams()
   PQVMvWJgSYfomasqNiDypthFTzCndE={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':PQVMvWJgSYfomasqNiDypthFTzCncB(PQVMvWJgSYfomasqNiDypthFTzCnUH.GetNoCache(2))}
   PQVMvWJgSYfomasqNiDypthFTzCnKc.update(PQVMvWJgSYfomasqNiDypthFTzCndE)
   PQVMvWJgSYfomasqNiDypthFTzCnKR=PQVMvWJgSYfomasqNiDypthFTzCnUH.API_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCndL
   PQVMvWJgSYfomasqNiDypthFTzCnde=PQVMvWJgSYfomasqNiDypthFTzCnUH.callRequestCookies('Get',PQVMvWJgSYfomasqNiDypthFTzCnKR,payload=PQVMvWJgSYfomasqNiDypthFTzCnck,params=PQVMvWJgSYfomasqNiDypthFTzCnKc,headers=PQVMvWJgSYfomasqNiDypthFTzCnck,cookies=PQVMvWJgSYfomasqNiDypthFTzCnck)
   PQVMvWJgSYfomasqNiDypthFTzCndI=json.loads(PQVMvWJgSYfomasqNiDypthFTzCnde.text)
   if not('result' in PQVMvWJgSYfomasqNiDypthFTzCndI['body']):return PQVMvWJgSYfomasqNiDypthFTzCndb,PQVMvWJgSYfomasqNiDypthFTzCnkx
   PQVMvWJgSYfomasqNiDypthFTzCnkI=PQVMvWJgSYfomasqNiDypthFTzCndI['body']['result']
   PQVMvWJgSYfomasqNiDypthFTzCnHw =PQVMvWJgSYfomasqNiDypthFTzCnUH.Get_Now_Datetime()
   PQVMvWJgSYfomasqNiDypthFTzCnHA=PQVMvWJgSYfomasqNiDypthFTzCnHw+datetime.timedelta(days=-1)
   PQVMvWJgSYfomasqNiDypthFTzCnHA=PQVMvWJgSYfomasqNiDypthFTzCncw(PQVMvWJgSYfomasqNiDypthFTzCnHA.strftime('%Y%m%d'))
   for PQVMvWJgSYfomasqNiDypthFTzCnKU in PQVMvWJgSYfomasqNiDypthFTzCnkI:
    PQVMvWJgSYfomasqNiDypthFTzCnHe=PQVMvWJgSYfomasqNiDypthFTzCncw(PQVMvWJgSYfomasqNiDypthFTzCnKU.get('content').get('banner_title2')[:8])
    if PQVMvWJgSYfomasqNiDypthFTzCnHA<=PQVMvWJgSYfomasqNiDypthFTzCnHe:
     PQVMvWJgSYfomasqNiDypthFTzCnXU={'channel':PQVMvWJgSYfomasqNiDypthFTzCnKU.get('content').get('banner_sub_title3'),'title':PQVMvWJgSYfomasqNiDypthFTzCnKU.get('content').get('banner_title'),'subtitle':PQVMvWJgSYfomasqNiDypthFTzCnKU.get('content').get('banner_sub_title2'),}
     PQVMvWJgSYfomasqNiDypthFTzCndb.append(PQVMvWJgSYfomasqNiDypthFTzCnXU)
  except PQVMvWJgSYfomasqNiDypthFTzCnce as exception:
   PQVMvWJgSYfomasqNiDypthFTzCncU(exception)
  return PQVMvWJgSYfomasqNiDypthFTzCndb
 def Make_DecryptKey(PQVMvWJgSYfomasqNiDypthFTzCnUH,step,mediacode='000',timecode='000'):
  if step=='1':
   PQVMvWJgSYfomasqNiDypthFTzCnHB=PQVMvWJgSYfomasqNiDypthFTzCncL('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   PQVMvWJgSYfomasqNiDypthFTzCnHG=PQVMvWJgSYfomasqNiDypthFTzCncL('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   PQVMvWJgSYfomasqNiDypthFTzCnHB=PQVMvWJgSYfomasqNiDypthFTzCncL('kss2lym0kdw1lks3','utf-8')
   PQVMvWJgSYfomasqNiDypthFTzCnHG=PQVMvWJgSYfomasqNiDypthFTzCncL([42,7,114,59,55,5,30,1,110,68,2,51,42,97,38,60])
  return PQVMvWJgSYfomasqNiDypthFTzCnHB,PQVMvWJgSYfomasqNiDypthFTzCnHG
 def DecryptPlaintext(PQVMvWJgSYfomasqNiDypthFTzCnUH,ciphertext,encryption_key,init_vector):
  PQVMvWJgSYfomasqNiDypthFTzCnHr=AES.new(encryption_key,AES.MODE_CBC,init_vector,)
  PQVMvWJgSYfomasqNiDypthFTzCnHL=Padding.unpad(PQVMvWJgSYfomasqNiDypthFTzCnHr.decrypt(base64.standard_b64decode(ciphertext)),16)
  return PQVMvWJgSYfomasqNiDypthFTzCnHL.decode('utf-8')
 def Decrypt_Url(PQVMvWJgSYfomasqNiDypthFTzCnUH,ciphertext,mediacode,PQVMvWJgSYfomasqNiDypthFTzCnKr):
  PQVMvWJgSYfomasqNiDypthFTzCnHu=''
  try:
   PQVMvWJgSYfomasqNiDypthFTzCnHB,PQVMvWJgSYfomasqNiDypthFTzCnHG=PQVMvWJgSYfomasqNiDypthFTzCnUH.Make_DecryptKey('1',mediacode=mediacode,timecode=PQVMvWJgSYfomasqNiDypthFTzCnKr)
   PQVMvWJgSYfomasqNiDypthFTzCnHj=json.loads(PQVMvWJgSYfomasqNiDypthFTzCnUH.DecryptPlaintext(ciphertext,PQVMvWJgSYfomasqNiDypthFTzCnHB,PQVMvWJgSYfomasqNiDypthFTzCnHG))
   PQVMvWJgSYfomasqNiDypthFTzCnHb =PQVMvWJgSYfomasqNiDypthFTzCnHj.get('url')
   PQVMvWJgSYfomasqNiDypthFTzCnHB,PQVMvWJgSYfomasqNiDypthFTzCnHG=PQVMvWJgSYfomasqNiDypthFTzCnUH.Make_DecryptKey('2',mediacode=mediacode,timecode=PQVMvWJgSYfomasqNiDypthFTzCnKr)
   PQVMvWJgSYfomasqNiDypthFTzCnHu=PQVMvWJgSYfomasqNiDypthFTzCnUH.DecryptPlaintext(PQVMvWJgSYfomasqNiDypthFTzCnHb,PQVMvWJgSYfomasqNiDypthFTzCnHB,PQVMvWJgSYfomasqNiDypthFTzCnHG)
  except PQVMvWJgSYfomasqNiDypthFTzCnce as exception:
   PQVMvWJgSYfomasqNiDypthFTzCncU(exception)
  return PQVMvWJgSYfomasqNiDypthFTzCnHu
 def GetLiveURL_Test(PQVMvWJgSYfomasqNiDypthFTzCnUH,mediacode,sel_quality):
  PQVMvWJgSYfomasqNiDypthFTzCnKk ={'streaming_url':'','subtitleYn':PQVMvWJgSYfomasqNiDypthFTzCncO,'error_msg':'','drm_server_url':'','drm_header_key':'','drm_header_value':'','url_filename':'',}
  PQVMvWJgSYfomasqNiDypthFTzCndl =PQVMvWJgSYfomasqNiDypthFTzCnUH.TV['cookies']['tving_uuid'].split('-')[0] 
  PQVMvWJgSYfomasqNiDypthFTzCnKO =PQVMvWJgSYfomasqNiDypthFTzCnUH.TV['cookies']['tving_uuid'] 
  try:
   PQVMvWJgSYfomasqNiDypthFTzCnKH=PQVMvWJgSYfomasqNiDypthFTzCncB(PQVMvWJgSYfomasqNiDypthFTzCnUH.GetNoCache(1))
   PQVMvWJgSYfomasqNiDypthFTzCndL ='/v2/media/stream/info' 
   PQVMvWJgSYfomasqNiDypthFTzCnKc=PQVMvWJgSYfomasqNiDypthFTzCnUH.GetDefaultParams()
   PQVMvWJgSYfomasqNiDypthFTzCndE={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':PQVMvWJgSYfomasqNiDypthFTzCnKO,'deviceInfo':'PC','noCache':PQVMvWJgSYfomasqNiDypthFTzCnKH,}
   PQVMvWJgSYfomasqNiDypthFTzCnKc.update(PQVMvWJgSYfomasqNiDypthFTzCndE)
   PQVMvWJgSYfomasqNiDypthFTzCnKR=PQVMvWJgSYfomasqNiDypthFTzCnUH.API_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCndL
   PQVMvWJgSYfomasqNiDypthFTzCnUI=PQVMvWJgSYfomasqNiDypthFTzCnUH.makeDefaultCookies()
   PQVMvWJgSYfomasqNiDypthFTzCnde=PQVMvWJgSYfomasqNiDypthFTzCnUH.callRequestCookies('Get',PQVMvWJgSYfomasqNiDypthFTzCnKR,payload=PQVMvWJgSYfomasqNiDypthFTzCnck,params=PQVMvWJgSYfomasqNiDypthFTzCnKc,headers=PQVMvWJgSYfomasqNiDypthFTzCnck,cookies=PQVMvWJgSYfomasqNiDypthFTzCnUI)
   if PQVMvWJgSYfomasqNiDypthFTzCnde.status_code!=200:
    PQVMvWJgSYfomasqNiDypthFTzCnKk['error_msg']='First Step - {} error'.format(PQVMvWJgSYfomasqNiDypthFTzCnde.status_code)
    return PQVMvWJgSYfomasqNiDypthFTzCnKk
   PQVMvWJgSYfomasqNiDypthFTzCndI=json.loads(PQVMvWJgSYfomasqNiDypthFTzCnde.text)
   if PQVMvWJgSYfomasqNiDypthFTzCndI['body']['result']['code']=='060':
    for PQVMvWJgSYfomasqNiDypthFTzCnUb,PQVMvWJgSYfomasqNiDypthFTzCnUl in PQVMvWJgSYfomasqNiDypthFTzCnUK.items():
     if PQVMvWJgSYfomasqNiDypthFTzCnUl==sel_quality:
      PQVMvWJgSYfomasqNiDypthFTzCnKw=PQVMvWJgSYfomasqNiDypthFTzCnUb
   elif PQVMvWJgSYfomasqNiDypthFTzCndI['body']['result']['code']!='000':
    PQVMvWJgSYfomasqNiDypthFTzCnKk['error_msg']=PQVMvWJgSYfomasqNiDypthFTzCndI['body']['result']['message']
    return PQVMvWJgSYfomasqNiDypthFTzCnKk
   else: 
    if not('stream' in PQVMvWJgSYfomasqNiDypthFTzCndI['body']):return PQVMvWJgSYfomasqNiDypthFTzCnKk
    PQVMvWJgSYfomasqNiDypthFTzCnKA=[]
    for PQVMvWJgSYfomasqNiDypthFTzCnUb,PQVMvWJgSYfomasqNiDypthFTzCnUl in PQVMvWJgSYfomasqNiDypthFTzCnUK.items():
     for PQVMvWJgSYfomasqNiDypthFTzCnKU in PQVMvWJgSYfomasqNiDypthFTzCndI['body']['stream']['quality']:
      if PQVMvWJgSYfomasqNiDypthFTzCnKU['active']=='Y' and PQVMvWJgSYfomasqNiDypthFTzCnKU['code']==PQVMvWJgSYfomasqNiDypthFTzCnUb:
       PQVMvWJgSYfomasqNiDypthFTzCnKA.append({PQVMvWJgSYfomasqNiDypthFTzCnUK.get(PQVMvWJgSYfomasqNiDypthFTzCnKU['code']):PQVMvWJgSYfomasqNiDypthFTzCnKU['code']})
    PQVMvWJgSYfomasqNiDypthFTzCnKw=PQVMvWJgSYfomasqNiDypthFTzCnUH.CheckQuality(sel_quality,PQVMvWJgSYfomasqNiDypthFTzCnKA)
  except PQVMvWJgSYfomasqNiDypthFTzCnce as exception:
   PQVMvWJgSYfomasqNiDypthFTzCncU(exception)
   PQVMvWJgSYfomasqNiDypthFTzCnKk['error_msg']='First Step - except error'
   return PQVMvWJgSYfomasqNiDypthFTzCnKk
  try:
   PQVMvWJgSYfomasqNiDypthFTzCnKH=PQVMvWJgSYfomasqNiDypthFTzCncB(PQVMvWJgSYfomasqNiDypthFTzCnUH.GetNoCache(1))
   PQVMvWJgSYfomasqNiDypthFTzCndL ='/v3/media/stream/info'
   PQVMvWJgSYfomasqNiDypthFTzCnKc=PQVMvWJgSYfomasqNiDypthFTzCnUH.GetDefaultParams()
   PQVMvWJgSYfomasqNiDypthFTzCndE={'mediaCode':mediacode,'deviceId':PQVMvWJgSYfomasqNiDypthFTzCndl,'uuid':PQVMvWJgSYfomasqNiDypthFTzCnKO,'deviceInfo':'PC_Chrome','streamCode':PQVMvWJgSYfomasqNiDypthFTzCnKw,'noCache':PQVMvWJgSYfomasqNiDypthFTzCnKH,'callingFrom':'HTML5','model':PQVMvWJgSYfomasqNiDypthFTzCnUH.MODEL,'videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   PQVMvWJgSYfomasqNiDypthFTzCnKc.update(PQVMvWJgSYfomasqNiDypthFTzCndE)
   PQVMvWJgSYfomasqNiDypthFTzCnKR=PQVMvWJgSYfomasqNiDypthFTzCnUH.API_DOMAIN+PQVMvWJgSYfomasqNiDypthFTzCndL
   PQVMvWJgSYfomasqNiDypthFTzCnUI=PQVMvWJgSYfomasqNiDypthFTzCnUH.makeDefaultCookies()
   PQVMvWJgSYfomasqNiDypthFTzCnde=PQVMvWJgSYfomasqNiDypthFTzCnUH.callRequestCookies('Post',PQVMvWJgSYfomasqNiDypthFTzCnKR,payload=PQVMvWJgSYfomasqNiDypthFTzCnck,params=PQVMvWJgSYfomasqNiDypthFTzCnKc,headers=PQVMvWJgSYfomasqNiDypthFTzCnck,cookies=PQVMvWJgSYfomasqNiDypthFTzCnUI,redirects=PQVMvWJgSYfomasqNiDypthFTzCncH)
   PQVMvWJgSYfomasqNiDypthFTzCndI=json.loads(PQVMvWJgSYfomasqNiDypthFTzCnde.text)
   if PQVMvWJgSYfomasqNiDypthFTzCndI['body']['result']['code']!='000':
    PQVMvWJgSYfomasqNiDypthFTzCnKk['error_msg']=PQVMvWJgSYfomasqNiDypthFTzCndI['body']['result']['message']
    return PQVMvWJgSYfomasqNiDypthFTzCnKk
   PQVMvWJgSYfomasqNiDypthFTzCnKe=PQVMvWJgSYfomasqNiDypthFTzCndI['body']['stream']
   if PQVMvWJgSYfomasqNiDypthFTzCnKe['drm_yn']=='Y':
    PQVMvWJgSYfomasqNiDypthFTzCnKB=PQVMvWJgSYfomasqNiDypthFTzCnKe['playback']['drm']['widevine']
    for PQVMvWJgSYfomasqNiDypthFTzCnKG in PQVMvWJgSYfomasqNiDypthFTzCnKe['playback']['drm']['license']['drm_license_data']:
     if PQVMvWJgSYfomasqNiDypthFTzCnKG['drm_type']=='Widevine':
      PQVMvWJgSYfomasqNiDypthFTzCnKk['drm_server_url'] =PQVMvWJgSYfomasqNiDypthFTzCnKG['drm_server_url']
      PQVMvWJgSYfomasqNiDypthFTzCnKk['drm_header_key'] =PQVMvWJgSYfomasqNiDypthFTzCnKG['drm_header_key']
      PQVMvWJgSYfomasqNiDypthFTzCnKk['drm_header_value']=PQVMvWJgSYfomasqNiDypthFTzCnKG['drm_header_value']
      break
   else:
    PQVMvWJgSYfomasqNiDypthFTzCnKB=PQVMvWJgSYfomasqNiDypthFTzCnKe['playback']['non_drm']
  except PQVMvWJgSYfomasqNiDypthFTzCnce as exception:
   PQVMvWJgSYfomasqNiDypthFTzCncU(exception)
   PQVMvWJgSYfomasqNiDypthFTzCnKk['error_msg']='Second Step - except error'
   return PQVMvWJgSYfomasqNiDypthFTzCnKk
  PQVMvWJgSYfomasqNiDypthFTzCnKr=PQVMvWJgSYfomasqNiDypthFTzCnKH
  PQVMvWJgSYfomasqNiDypthFTzCnKB=PQVMvWJgSYfomasqNiDypthFTzCnKB.split('|')[1]
  PQVMvWJgSYfomasqNiDypthFTzCnKB=PQVMvWJgSYfomasqNiDypthFTzCnUH.Decrypt_Url(PQVMvWJgSYfomasqNiDypthFTzCnKB,mediacode,PQVMvWJgSYfomasqNiDypthFTzCnKr)
  PQVMvWJgSYfomasqNiDypthFTzCnKk['streaming_url']=PQVMvWJgSYfomasqNiDypthFTzCnKB
  PQVMvWJgSYfomasqNiDypthFTzCnHl =PQVMvWJgSYfomasqNiDypthFTzCnKk['streaming_url'].find('Policy=')
  if PQVMvWJgSYfomasqNiDypthFTzCnHl!=-1:
   PQVMvWJgSYfomasqNiDypthFTzCnHx =PQVMvWJgSYfomasqNiDypthFTzCnKk['streaming_url'].split('?')[0]
   PQVMvWJgSYfomasqNiDypthFTzCnHE=PQVMvWJgSYfomasqNiDypthFTzCncG(urllib.parse.parse_qsl(urllib.parse.urlsplit(PQVMvWJgSYfomasqNiDypthFTzCnKk['streaming_url']).query))
   PQVMvWJgSYfomasqNiDypthFTzCnKk['streaming_url']='{}&CloudFront-Policy={}'.format(PQVMvWJgSYfomasqNiDypthFTzCnKk['streaming_url'],PQVMvWJgSYfomasqNiDypthFTzCnHE['Policy'])
   PQVMvWJgSYfomasqNiDypthFTzCnKk['streaming_url']='{}&CloudFront-Signature={}'.format(PQVMvWJgSYfomasqNiDypthFTzCnKk['streaming_url'],PQVMvWJgSYfomasqNiDypthFTzCnHE['Signature'])
   PQVMvWJgSYfomasqNiDypthFTzCnKk['streaming_url']='{}&CloudFront-Key-Pair-Id={}'.format(PQVMvWJgSYfomasqNiDypthFTzCnKk['streaming_url'],PQVMvWJgSYfomasqNiDypthFTzCnHE['Key-Pair-Id'])
  PQVMvWJgSYfomasqNiDypthFTzCnHI=['_tving_token','accessToken','authToken',]
  for PQVMvWJgSYfomasqNiDypthFTzCnUb,PQVMvWJgSYfomasqNiDypthFTzCnUl in PQVMvWJgSYfomasqNiDypthFTzCnUI.items():
   if PQVMvWJgSYfomasqNiDypthFTzCnUb in PQVMvWJgSYfomasqNiDypthFTzCnHI:
    PQVMvWJgSYfomasqNiDypthFTzCnKk['streaming_url']='{}&{}={}'.format(PQVMvWJgSYfomasqNiDypthFTzCnKk['streaming_url'],PQVMvWJgSYfomasqNiDypthFTzCnUb,PQVMvWJgSYfomasqNiDypthFTzCnUl)
  PQVMvWJgSYfomasqNiDypthFTzCncU(PQVMvWJgSYfomasqNiDypthFTzCnKk['streaming_url'])
  return PQVMvWJgSYfomasqNiDypthFTzCnKk
# Created by pyminifier (https://github.com/liftoff/pyminifier)
