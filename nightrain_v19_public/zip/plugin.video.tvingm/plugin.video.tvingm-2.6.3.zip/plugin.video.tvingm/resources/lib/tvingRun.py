__author__="NightRain"
XkPfJNjGArFpagmCTDnKzWBYItEsvb=object
XkPfJNjGArFpagmCTDnKzWBYItEsvy=None
XkPfJNjGArFpagmCTDnKzWBYItEsvO=int
XkPfJNjGArFpagmCTDnKzWBYItEsvc=True
XkPfJNjGArFpagmCTDnKzWBYItEsvU=False
XkPfJNjGArFpagmCTDnKzWBYItEsqQ=type
XkPfJNjGArFpagmCTDnKzWBYItEsqi=dict
XkPfJNjGArFpagmCTDnKzWBYItEsqV=getattr
XkPfJNjGArFpagmCTDnKzWBYItEsqL=list
XkPfJNjGArFpagmCTDnKzWBYItEsqw=len
XkPfJNjGArFpagmCTDnKzWBYItEsqR=str
XkPfJNjGArFpagmCTDnKzWBYItEsqo=range
XkPfJNjGArFpagmCTDnKzWBYItEsqv=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
XkPfJNjGArFpagmCTDnKzWBYItEsQV=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'오직 티빙에만','mode':'ORI_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'VOD 방송 - 4K','mode':'4K_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 4K','mode':'4K_MOVIE','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
XkPfJNjGArFpagmCTDnKzWBYItEsQL=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
XkPfJNjGArFpagmCTDnKzWBYItEsQw=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
XkPfJNjGArFpagmCTDnKzWBYItEsQR=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
XkPfJNjGArFpagmCTDnKzWBYItEsQo=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'로맨스','mode':'PROGRAM','stype':'PCO'},{'title':'코미디','mode':'PROGRAM','stype':'PCP'},{'title':'스릴러','mode':'PROGRAM','stype':'PCQ'},{'title':'미스터리(추리)','mode':'PROGRAM','stype':'PCAA'},{'title':'모험','mode':'PROGRAM','stype':'PCX'},{'title':'액션','mode':'PROGRAM','stype':'PCY'},{'title':'판타지','mode':'PROGRAM','stype':'PCR'},{'title':'무협','mode':'PROGRAM','stype':'PCAB'},{'title':'공포','mode':'PROGRAM','stype':'PCAD'},{'title':'리얼리티','mode':'PROGRAM','stype':'PCV'},{'title':'토크쇼','mode':'PROGRAM','stype':'PCU'},{'title':'다큐멘터리','mode':'PROGRAM','stype':'PCT'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'스포츠','mode':'PROGRAM','stype':'PCF'},{'title':'음악','mode':'PROGRAM','stype':'PCAC'},{'title':'공연','mode':'PROGRAM','stype':'PCW'},{'title':'사극(시대극)','mode':'PROGRAM','stype':'PCS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'}]
XkPfJNjGArFpagmCTDnKzWBYItEsQv=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG23'},{'title':'로맨스','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'스릴러','mode':'MOVIE_SUB','stype':'MG140'},{'title':'미스터리','mode':'MOVIE_SUB','stype':'MG150'},{'title':'모험','mode':'MOVIE_SUB','stype':'MG170'},{'title':'액션','mode':'MOVIE_SUB','stype':'MG120'},{'title':'판타지','mode':'MOVIE_SUB','stype':'MG200'},{'title':'SF','mode':'MOVIE_SUB','stype':'MG210'},{'title':'공포','mode':'MOVIE_SUB','stype':'MG160'},{'title':'다큐멘터리','mode':'MOVIE_SUB','stype':'MG250'},{'title':'다양성 영화','mode':'MOVIE_SUB','stype':'diversityYn'}]
XkPfJNjGArFpagmCTDnKzWBYItEsQq=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
XkPfJNjGArFpagmCTDnKzWBYItEsQh={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
from tvingCore import*
XkPfJNjGArFpagmCTDnKzWBYItEsQM =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
XkPfJNjGArFpagmCTDnKzWBYItEsQx=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
class XkPfJNjGArFpagmCTDnKzWBYItEsQi(XkPfJNjGArFpagmCTDnKzWBYItEsvb):
 def __init__(XkPfJNjGArFpagmCTDnKzWBYItEsQl,XkPfJNjGArFpagmCTDnKzWBYItEsQS,XkPfJNjGArFpagmCTDnKzWBYItEsQu,XkPfJNjGArFpagmCTDnKzWBYItEsQe):
  XkPfJNjGArFpagmCTDnKzWBYItEsQl._addon_url =XkPfJNjGArFpagmCTDnKzWBYItEsQS
  XkPfJNjGArFpagmCTDnKzWBYItEsQl._addon_handle=XkPfJNjGArFpagmCTDnKzWBYItEsQu
  XkPfJNjGArFpagmCTDnKzWBYItEsQl.main_params =XkPfJNjGArFpagmCTDnKzWBYItEsQe
  XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj =PQVMvWJgSYfomasqNiDypthFTzCnUd() 
  XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.TV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_stream(mpd,m3u8)'))
 def addon_noti(XkPfJNjGArFpagmCTDnKzWBYItEsQl,sting):
  try:
   XkPfJNjGArFpagmCTDnKzWBYItEsQd=xbmcgui.Dialog()
   XkPfJNjGArFpagmCTDnKzWBYItEsQd.notification(__addonname__,sting)
  except:
   XkPfJNjGArFpagmCTDnKzWBYItEsvy
 def addon_log(XkPfJNjGArFpagmCTDnKzWBYItEsQl,string):
  try:
   XkPfJNjGArFpagmCTDnKzWBYItEsQb=string.encode('utf-8','ignore')
  except:
   XkPfJNjGArFpagmCTDnKzWBYItEsQb='addonException: addon_log'
  XkPfJNjGArFpagmCTDnKzWBYItEsQy=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,XkPfJNjGArFpagmCTDnKzWBYItEsQb),level=XkPfJNjGArFpagmCTDnKzWBYItEsQy)
 def get_keyboard_input(XkPfJNjGArFpagmCTDnKzWBYItEsQl,XkPfJNjGArFpagmCTDnKzWBYItEsie):
  XkPfJNjGArFpagmCTDnKzWBYItEsQO=XkPfJNjGArFpagmCTDnKzWBYItEsvy
  kb=xbmc.Keyboard()
  kb.setHeading(XkPfJNjGArFpagmCTDnKzWBYItEsie)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   XkPfJNjGArFpagmCTDnKzWBYItEsQO=kb.getText()
  return XkPfJNjGArFpagmCTDnKzWBYItEsQO
 def get_settings_account(XkPfJNjGArFpagmCTDnKzWBYItEsQl):
  XkPfJNjGArFpagmCTDnKzWBYItEsQc =__addon__.getSetting('id')
  XkPfJNjGArFpagmCTDnKzWBYItEsQU =__addon__.getSetting('pw')
  XkPfJNjGArFpagmCTDnKzWBYItEsiQ =__addon__.getSetting('login_type')
  XkPfJNjGArFpagmCTDnKzWBYItEsiV=XkPfJNjGArFpagmCTDnKzWBYItEsvO(__addon__.getSetting('selected_profile'))
  return(XkPfJNjGArFpagmCTDnKzWBYItEsQc,XkPfJNjGArFpagmCTDnKzWBYItEsQU,XkPfJNjGArFpagmCTDnKzWBYItEsiQ,XkPfJNjGArFpagmCTDnKzWBYItEsiV)
 def get_settings_uhd(XkPfJNjGArFpagmCTDnKzWBYItEsQl):
  return XkPfJNjGArFpagmCTDnKzWBYItEsvc if __addon__.getSetting('active_uhd')=='true' else XkPfJNjGArFpagmCTDnKzWBYItEsvU
 def get_settings_playback(XkPfJNjGArFpagmCTDnKzWBYItEsQl):
  XkPfJNjGArFpagmCTDnKzWBYItEsiL={'active_uhd':XkPfJNjGArFpagmCTDnKzWBYItEsvc if __addon__.getSetting('active_uhd')=='true' else XkPfJNjGArFpagmCTDnKzWBYItEsvU,'streamFilename':XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.TV_STREAM_FILENAME,}
  return XkPfJNjGArFpagmCTDnKzWBYItEsiL
 def get_settings_proxyport(XkPfJNjGArFpagmCTDnKzWBYItEsQl):
  XkPfJNjGArFpagmCTDnKzWBYItEsiw =XkPfJNjGArFpagmCTDnKzWBYItEsvc if __addon__.getSetting('proxyYn')=='true' else XkPfJNjGArFpagmCTDnKzWBYItEsvU
  XkPfJNjGArFpagmCTDnKzWBYItEsiR=XkPfJNjGArFpagmCTDnKzWBYItEsvO(__addon__.getSetting('proxyPort'))
  return XkPfJNjGArFpagmCTDnKzWBYItEsiw,XkPfJNjGArFpagmCTDnKzWBYItEsiR
 def get_settings_totalsearch(XkPfJNjGArFpagmCTDnKzWBYItEsQl):
  XkPfJNjGArFpagmCTDnKzWBYItEsio =XkPfJNjGArFpagmCTDnKzWBYItEsvc if __addon__.getSetting('local_search')=='true' else XkPfJNjGArFpagmCTDnKzWBYItEsvU
  XkPfJNjGArFpagmCTDnKzWBYItEsiv=XkPfJNjGArFpagmCTDnKzWBYItEsvc if __addon__.getSetting('local_history')=='true' else XkPfJNjGArFpagmCTDnKzWBYItEsvU
  XkPfJNjGArFpagmCTDnKzWBYItEsiq =XkPfJNjGArFpagmCTDnKzWBYItEsvc if __addon__.getSetting('total_search')=='true' else XkPfJNjGArFpagmCTDnKzWBYItEsvU
  XkPfJNjGArFpagmCTDnKzWBYItEsih=XkPfJNjGArFpagmCTDnKzWBYItEsvc if __addon__.getSetting('total_history')=='true' else XkPfJNjGArFpagmCTDnKzWBYItEsvU
  XkPfJNjGArFpagmCTDnKzWBYItEsiM=XkPfJNjGArFpagmCTDnKzWBYItEsvc if __addon__.getSetting('menu_bookmark')=='true' else XkPfJNjGArFpagmCTDnKzWBYItEsvU
  return(XkPfJNjGArFpagmCTDnKzWBYItEsio,XkPfJNjGArFpagmCTDnKzWBYItEsiv,XkPfJNjGArFpagmCTDnKzWBYItEsiq,XkPfJNjGArFpagmCTDnKzWBYItEsih,XkPfJNjGArFpagmCTDnKzWBYItEsiM)
 def get_settings_makebookmark(XkPfJNjGArFpagmCTDnKzWBYItEsQl):
  return XkPfJNjGArFpagmCTDnKzWBYItEsvc if __addon__.getSetting('make_bookmark')=='true' else XkPfJNjGArFpagmCTDnKzWBYItEsvU
 def get_settings_direct_replay(XkPfJNjGArFpagmCTDnKzWBYItEsQl):
  XkPfJNjGArFpagmCTDnKzWBYItEsix=XkPfJNjGArFpagmCTDnKzWBYItEsvO(__addon__.getSetting('direct_replay'))
  if XkPfJNjGArFpagmCTDnKzWBYItEsix==0:
   return XkPfJNjGArFpagmCTDnKzWBYItEsvU
  else:
   return XkPfJNjGArFpagmCTDnKzWBYItEsvc
 def set_winEpisodeOrderby(XkPfJNjGArFpagmCTDnKzWBYItEsQl,XkPfJNjGArFpagmCTDnKzWBYItEsiS):
  __addon__.setSetting('tving_orderby',XkPfJNjGArFpagmCTDnKzWBYItEsiS)
  XkPfJNjGArFpagmCTDnKzWBYItEsil=xbmcgui.Window(10000)
  XkPfJNjGArFpagmCTDnKzWBYItEsil.setProperty('TVING_M_ORDERBY',XkPfJNjGArFpagmCTDnKzWBYItEsiS)
 def get_winEpisodeOrderby(XkPfJNjGArFpagmCTDnKzWBYItEsQl):
  XkPfJNjGArFpagmCTDnKzWBYItEsiS=__addon__.getSetting('tving_orderby')
  if XkPfJNjGArFpagmCTDnKzWBYItEsiS in['',XkPfJNjGArFpagmCTDnKzWBYItEsvy]:XkPfJNjGArFpagmCTDnKzWBYItEsiS='desc'
  return XkPfJNjGArFpagmCTDnKzWBYItEsiS
 def add_dir(XkPfJNjGArFpagmCTDnKzWBYItEsQl,label,sublabel='',img='',infoLabels=XkPfJNjGArFpagmCTDnKzWBYItEsvy,isFolder=XkPfJNjGArFpagmCTDnKzWBYItEsvc,params='',isLink=XkPfJNjGArFpagmCTDnKzWBYItEsvU,ContextMenu=XkPfJNjGArFpagmCTDnKzWBYItEsvy):
  XkPfJNjGArFpagmCTDnKzWBYItEsiu='%s?%s'%(XkPfJNjGArFpagmCTDnKzWBYItEsQl._addon_url,urllib.parse.urlencode(params))
  if sublabel:XkPfJNjGArFpagmCTDnKzWBYItEsie='%s < %s >'%(label,sublabel)
  else: XkPfJNjGArFpagmCTDnKzWBYItEsie=label
  if not img:img='DefaultFolder.png'
  XkPfJNjGArFpagmCTDnKzWBYItEsiH=xbmcgui.ListItem(XkPfJNjGArFpagmCTDnKzWBYItEsie)
  if XkPfJNjGArFpagmCTDnKzWBYItEsqQ(img)==XkPfJNjGArFpagmCTDnKzWBYItEsqi:
   XkPfJNjGArFpagmCTDnKzWBYItEsiH.setArt(img)
  else:
   XkPfJNjGArFpagmCTDnKzWBYItEsiH.setArt({'thumb':img,'poster':img})
  if XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.KodiVersion>=20:
   if infoLabels:XkPfJNjGArFpagmCTDnKzWBYItEsQl.Set_InfoTag(XkPfJNjGArFpagmCTDnKzWBYItEsiH.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:XkPfJNjGArFpagmCTDnKzWBYItEsiH.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   XkPfJNjGArFpagmCTDnKzWBYItEsiH.setProperty('IsPlayable','true')
  if ContextMenu:XkPfJNjGArFpagmCTDnKzWBYItEsiH.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(XkPfJNjGArFpagmCTDnKzWBYItEsQl._addon_handle,XkPfJNjGArFpagmCTDnKzWBYItEsiu,XkPfJNjGArFpagmCTDnKzWBYItEsiH,isFolder)
 def get_selQuality(XkPfJNjGArFpagmCTDnKzWBYItEsQl,etype):
  try:
   XkPfJNjGArFpagmCTDnKzWBYItEsid='selected_quality'
   XkPfJNjGArFpagmCTDnKzWBYItEsib=[1080,720,480,360]
   XkPfJNjGArFpagmCTDnKzWBYItEsiy=XkPfJNjGArFpagmCTDnKzWBYItEsvO(__addon__.getSetting(XkPfJNjGArFpagmCTDnKzWBYItEsid))
   return XkPfJNjGArFpagmCTDnKzWBYItEsib[XkPfJNjGArFpagmCTDnKzWBYItEsiy]
  except:
   XkPfJNjGArFpagmCTDnKzWBYItEsvy
  return 720 
 def Set_InfoTag(XkPfJNjGArFpagmCTDnKzWBYItEsQl,video_InfoTag:xbmc.InfoTagVideo,XkPfJNjGArFpagmCTDnKzWBYItEsVR):
  for XkPfJNjGArFpagmCTDnKzWBYItEsiO,value in XkPfJNjGArFpagmCTDnKzWBYItEsVR.items():
   if XkPfJNjGArFpagmCTDnKzWBYItEsQh[XkPfJNjGArFpagmCTDnKzWBYItEsiO]['type']=='string':
    XkPfJNjGArFpagmCTDnKzWBYItEsqV(video_InfoTag,XkPfJNjGArFpagmCTDnKzWBYItEsQh[XkPfJNjGArFpagmCTDnKzWBYItEsiO]['func'])(value)
   elif XkPfJNjGArFpagmCTDnKzWBYItEsQh[XkPfJNjGArFpagmCTDnKzWBYItEsiO]['type']=='int':
    if XkPfJNjGArFpagmCTDnKzWBYItEsqQ(value)==XkPfJNjGArFpagmCTDnKzWBYItEsvO:
     XkPfJNjGArFpagmCTDnKzWBYItEsic=XkPfJNjGArFpagmCTDnKzWBYItEsvO(value)
    else:
     XkPfJNjGArFpagmCTDnKzWBYItEsic=0
    XkPfJNjGArFpagmCTDnKzWBYItEsqV(video_InfoTag,XkPfJNjGArFpagmCTDnKzWBYItEsQh[XkPfJNjGArFpagmCTDnKzWBYItEsiO]['func'])(XkPfJNjGArFpagmCTDnKzWBYItEsic)
   elif XkPfJNjGArFpagmCTDnKzWBYItEsQh[XkPfJNjGArFpagmCTDnKzWBYItEsiO]['type']=='actor':
    if value!=[]:
     XkPfJNjGArFpagmCTDnKzWBYItEsqV(video_InfoTag,XkPfJNjGArFpagmCTDnKzWBYItEsQh[XkPfJNjGArFpagmCTDnKzWBYItEsiO]['func'])([xbmc.Actor(name)for name in value])
   elif XkPfJNjGArFpagmCTDnKzWBYItEsQh[XkPfJNjGArFpagmCTDnKzWBYItEsiO]['type']=='list':
    if XkPfJNjGArFpagmCTDnKzWBYItEsqQ(value)==XkPfJNjGArFpagmCTDnKzWBYItEsqL:
     XkPfJNjGArFpagmCTDnKzWBYItEsqV(video_InfoTag,XkPfJNjGArFpagmCTDnKzWBYItEsQh[XkPfJNjGArFpagmCTDnKzWBYItEsiO]['func'])(value)
    else:
     XkPfJNjGArFpagmCTDnKzWBYItEsqV(video_InfoTag,XkPfJNjGArFpagmCTDnKzWBYItEsQh[XkPfJNjGArFpagmCTDnKzWBYItEsiO]['func'])([value])
 def dp_Main_List(XkPfJNjGArFpagmCTDnKzWBYItEsQl):
  (XkPfJNjGArFpagmCTDnKzWBYItEsio,XkPfJNjGArFpagmCTDnKzWBYItEsiv,XkPfJNjGArFpagmCTDnKzWBYItEsiq,XkPfJNjGArFpagmCTDnKzWBYItEsih,XkPfJNjGArFpagmCTDnKzWBYItEsiM)=XkPfJNjGArFpagmCTDnKzWBYItEsQl.get_settings_totalsearch()
  for XkPfJNjGArFpagmCTDnKzWBYItEsiU in XkPfJNjGArFpagmCTDnKzWBYItEsQV:
   XkPfJNjGArFpagmCTDnKzWBYItEsie=XkPfJNjGArFpagmCTDnKzWBYItEsiU.get('title')
   XkPfJNjGArFpagmCTDnKzWBYItEsVQ=''
   if XkPfJNjGArFpagmCTDnKzWBYItEsiU.get('mode')=='SEARCH_GROUP' and XkPfJNjGArFpagmCTDnKzWBYItEsio ==XkPfJNjGArFpagmCTDnKzWBYItEsvU:continue
   elif XkPfJNjGArFpagmCTDnKzWBYItEsiU.get('mode')=='SEARCH_HISTORY' and XkPfJNjGArFpagmCTDnKzWBYItEsiv==XkPfJNjGArFpagmCTDnKzWBYItEsvU:continue
   elif XkPfJNjGArFpagmCTDnKzWBYItEsiU.get('mode')=='TOTAL_SEARCH' and XkPfJNjGArFpagmCTDnKzWBYItEsiq ==XkPfJNjGArFpagmCTDnKzWBYItEsvU:continue
   elif XkPfJNjGArFpagmCTDnKzWBYItEsiU.get('mode')=='TOTAL_HISTORY' and XkPfJNjGArFpagmCTDnKzWBYItEsih==XkPfJNjGArFpagmCTDnKzWBYItEsvU:continue
   elif XkPfJNjGArFpagmCTDnKzWBYItEsiU.get('mode')=='MENU_BOOKMARK' and XkPfJNjGArFpagmCTDnKzWBYItEsiM==XkPfJNjGArFpagmCTDnKzWBYItEsvU:continue
   XkPfJNjGArFpagmCTDnKzWBYItEsVi={'mode':XkPfJNjGArFpagmCTDnKzWBYItEsiU.get('mode'),'stype':XkPfJNjGArFpagmCTDnKzWBYItEsiU.get('stype'),'orderby':XkPfJNjGArFpagmCTDnKzWBYItEsiU.get('orderby'),'ordernm':XkPfJNjGArFpagmCTDnKzWBYItEsiU.get('ordernm'),'page':'1'}
   if XkPfJNjGArFpagmCTDnKzWBYItEsiU.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    XkPfJNjGArFpagmCTDnKzWBYItEsVL=XkPfJNjGArFpagmCTDnKzWBYItEsvU
    XkPfJNjGArFpagmCTDnKzWBYItEsVw =XkPfJNjGArFpagmCTDnKzWBYItEsvc
   else:
    XkPfJNjGArFpagmCTDnKzWBYItEsVL=XkPfJNjGArFpagmCTDnKzWBYItEsvc
    XkPfJNjGArFpagmCTDnKzWBYItEsVw =XkPfJNjGArFpagmCTDnKzWBYItEsvU
   XkPfJNjGArFpagmCTDnKzWBYItEsVR={'title':XkPfJNjGArFpagmCTDnKzWBYItEsie,'plot':XkPfJNjGArFpagmCTDnKzWBYItEsie}
   if XkPfJNjGArFpagmCTDnKzWBYItEsiU.get('mode')=='XXX':XkPfJNjGArFpagmCTDnKzWBYItEsVR=XkPfJNjGArFpagmCTDnKzWBYItEsvy
   if 'icon' in XkPfJNjGArFpagmCTDnKzWBYItEsiU:XkPfJNjGArFpagmCTDnKzWBYItEsVQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',XkPfJNjGArFpagmCTDnKzWBYItEsiU.get('icon')) 
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.add_dir(XkPfJNjGArFpagmCTDnKzWBYItEsie,sublabel='',img=XkPfJNjGArFpagmCTDnKzWBYItEsVQ,infoLabels=XkPfJNjGArFpagmCTDnKzWBYItEsVR,isFolder=XkPfJNjGArFpagmCTDnKzWBYItEsVL,params=XkPfJNjGArFpagmCTDnKzWBYItEsVi,isLink=XkPfJNjGArFpagmCTDnKzWBYItEsVw)
  xbmcplugin.endOfDirectory(XkPfJNjGArFpagmCTDnKzWBYItEsQl._addon_handle)
 def login_main(XkPfJNjGArFpagmCTDnKzWBYItEsQl):
  (XkPfJNjGArFpagmCTDnKzWBYItEsVv,XkPfJNjGArFpagmCTDnKzWBYItEsVq,XkPfJNjGArFpagmCTDnKzWBYItEsVh,XkPfJNjGArFpagmCTDnKzWBYItEsVM)=XkPfJNjGArFpagmCTDnKzWBYItEsQl.get_settings_account()
  if not(XkPfJNjGArFpagmCTDnKzWBYItEsVv and XkPfJNjGArFpagmCTDnKzWBYItEsVq):
   XkPfJNjGArFpagmCTDnKzWBYItEsQd=xbmcgui.Dialog()
   XkPfJNjGArFpagmCTDnKzWBYItEsVx=XkPfJNjGArFpagmCTDnKzWBYItEsQd.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if XkPfJNjGArFpagmCTDnKzWBYItEsVx==XkPfJNjGArFpagmCTDnKzWBYItEsvc:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if XkPfJNjGArFpagmCTDnKzWBYItEsQl.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   XkPfJNjGArFpagmCTDnKzWBYItEsVl=0
   while XkPfJNjGArFpagmCTDnKzWBYItEsvc:
    XkPfJNjGArFpagmCTDnKzWBYItEsVl+=1
    time.sleep(0.05)
    if XkPfJNjGArFpagmCTDnKzWBYItEsVl>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  XkPfJNjGArFpagmCTDnKzWBYItEsVS=XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.GetCredential(XkPfJNjGArFpagmCTDnKzWBYItEsVv,XkPfJNjGArFpagmCTDnKzWBYItEsVq,XkPfJNjGArFpagmCTDnKzWBYItEsVh,XkPfJNjGArFpagmCTDnKzWBYItEsVM)
  if XkPfJNjGArFpagmCTDnKzWBYItEsVS:XkPfJNjGArFpagmCTDnKzWBYItEsQl.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
  if XkPfJNjGArFpagmCTDnKzWBYItEsVS==XkPfJNjGArFpagmCTDnKzWBYItEsvU:
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(XkPfJNjGArFpagmCTDnKzWBYItEsQl,XkPfJNjGArFpagmCTDnKzWBYItEsVd):
  XkPfJNjGArFpagmCTDnKzWBYItEsVu=XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('stype')
  if XkPfJNjGArFpagmCTDnKzWBYItEsVu=='live':
   XkPfJNjGArFpagmCTDnKzWBYItEsVe=XkPfJNjGArFpagmCTDnKzWBYItEsQL
  elif XkPfJNjGArFpagmCTDnKzWBYItEsVu=='vod':
   XkPfJNjGArFpagmCTDnKzWBYItEsVe=XkPfJNjGArFpagmCTDnKzWBYItEsQo
  else:
   XkPfJNjGArFpagmCTDnKzWBYItEsVe=XkPfJNjGArFpagmCTDnKzWBYItEsQv
  for XkPfJNjGArFpagmCTDnKzWBYItEsVH in XkPfJNjGArFpagmCTDnKzWBYItEsVe:
   XkPfJNjGArFpagmCTDnKzWBYItEsie=XkPfJNjGArFpagmCTDnKzWBYItEsVH.get('title')
   if XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('ordernm')!='-':
    XkPfJNjGArFpagmCTDnKzWBYItEsie+='  ('+XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('ordernm')+')'
   XkPfJNjGArFpagmCTDnKzWBYItEsVi={'mode':XkPfJNjGArFpagmCTDnKzWBYItEsVH.get('mode'),'stype':XkPfJNjGArFpagmCTDnKzWBYItEsVH.get('stype'),'orderby':XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('orderby'),'ordernm':XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('ordernm'),'page':'1'}
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.add_dir(XkPfJNjGArFpagmCTDnKzWBYItEsie,sublabel='',img='',infoLabels=XkPfJNjGArFpagmCTDnKzWBYItEsvy,isFolder=XkPfJNjGArFpagmCTDnKzWBYItEsvc,params=XkPfJNjGArFpagmCTDnKzWBYItEsVi)
  if XkPfJNjGArFpagmCTDnKzWBYItEsqw(XkPfJNjGArFpagmCTDnKzWBYItEsVe)>0:xbmcplugin.endOfDirectory(XkPfJNjGArFpagmCTDnKzWBYItEsQl._addon_handle)
 def dp_SubTitle_Group(XkPfJNjGArFpagmCTDnKzWBYItEsQl,XkPfJNjGArFpagmCTDnKzWBYItEsVd): 
  for XkPfJNjGArFpagmCTDnKzWBYItEsVH in XkPfJNjGArFpagmCTDnKzWBYItEsQq:
   XkPfJNjGArFpagmCTDnKzWBYItEsie=XkPfJNjGArFpagmCTDnKzWBYItEsVH.get('title')
   if XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('ordernm')!='-':
    XkPfJNjGArFpagmCTDnKzWBYItEsie+='  ('+XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('ordernm')+')'
   XkPfJNjGArFpagmCTDnKzWBYItEsVi={'mode':XkPfJNjGArFpagmCTDnKzWBYItEsVH.get('mode'),'genreCode':XkPfJNjGArFpagmCTDnKzWBYItEsVH.get('genreCode'),'stype':XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('stype'),'orderby':XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('orderby'),'page':'1'}
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.add_dir(XkPfJNjGArFpagmCTDnKzWBYItEsie,sublabel='',img='',infoLabels=XkPfJNjGArFpagmCTDnKzWBYItEsvy,isFolder=XkPfJNjGArFpagmCTDnKzWBYItEsvc,params=XkPfJNjGArFpagmCTDnKzWBYItEsVi)
  if XkPfJNjGArFpagmCTDnKzWBYItEsqw(XkPfJNjGArFpagmCTDnKzWBYItEsQq)>0:xbmcplugin.endOfDirectory(XkPfJNjGArFpagmCTDnKzWBYItEsQl._addon_handle)
 def dp_LiveChannel_List(XkPfJNjGArFpagmCTDnKzWBYItEsQl,XkPfJNjGArFpagmCTDnKzWBYItEsVd):
  XkPfJNjGArFpagmCTDnKzWBYItEsVu =XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('stype')
  XkPfJNjGArFpagmCTDnKzWBYItEsVb =XkPfJNjGArFpagmCTDnKzWBYItEsvO(XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('page'))
  XkPfJNjGArFpagmCTDnKzWBYItEsVy,XkPfJNjGArFpagmCTDnKzWBYItEsVO=XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.GetLiveChannelList(XkPfJNjGArFpagmCTDnKzWBYItEsVu,XkPfJNjGArFpagmCTDnKzWBYItEsVb)
  for XkPfJNjGArFpagmCTDnKzWBYItEsVc in XkPfJNjGArFpagmCTDnKzWBYItEsVy:
   XkPfJNjGArFpagmCTDnKzWBYItEsie =XkPfJNjGArFpagmCTDnKzWBYItEsVc.get('title')
   XkPfJNjGArFpagmCTDnKzWBYItEsVo =XkPfJNjGArFpagmCTDnKzWBYItEsVc.get('channel')
   XkPfJNjGArFpagmCTDnKzWBYItEsVU =XkPfJNjGArFpagmCTDnKzWBYItEsVc.get('thumbnail')
   XkPfJNjGArFpagmCTDnKzWBYItEsLQ =XkPfJNjGArFpagmCTDnKzWBYItEsVc.get('synopsis')
   XkPfJNjGArFpagmCTDnKzWBYItEsLi =XkPfJNjGArFpagmCTDnKzWBYItEsVc.get('channelepg')
   XkPfJNjGArFpagmCTDnKzWBYItEsLV =XkPfJNjGArFpagmCTDnKzWBYItEsVc.get('cast')
   XkPfJNjGArFpagmCTDnKzWBYItEsLw =XkPfJNjGArFpagmCTDnKzWBYItEsVc.get('director')
   XkPfJNjGArFpagmCTDnKzWBYItEsLR =XkPfJNjGArFpagmCTDnKzWBYItEsVc.get('info_genre')
   XkPfJNjGArFpagmCTDnKzWBYItEsLo =XkPfJNjGArFpagmCTDnKzWBYItEsVc.get('year')
   XkPfJNjGArFpagmCTDnKzWBYItEsLv =XkPfJNjGArFpagmCTDnKzWBYItEsVc.get('mpaa')
   XkPfJNjGArFpagmCTDnKzWBYItEsLq =XkPfJNjGArFpagmCTDnKzWBYItEsVc.get('premiered')
   XkPfJNjGArFpagmCTDnKzWBYItEsLh={'mediatype':'episode','title':XkPfJNjGArFpagmCTDnKzWBYItEsie,'studio':XkPfJNjGArFpagmCTDnKzWBYItEsVo,'cast':XkPfJNjGArFpagmCTDnKzWBYItEsLV,'director':XkPfJNjGArFpagmCTDnKzWBYItEsLw,'genre':XkPfJNjGArFpagmCTDnKzWBYItEsLR,'plot':'%s\n%s\n%s\n\n%s'%(XkPfJNjGArFpagmCTDnKzWBYItEsVo,XkPfJNjGArFpagmCTDnKzWBYItEsie,XkPfJNjGArFpagmCTDnKzWBYItEsLi,XkPfJNjGArFpagmCTDnKzWBYItEsLQ),'year':XkPfJNjGArFpagmCTDnKzWBYItEsLo,'mpaa':XkPfJNjGArFpagmCTDnKzWBYItEsLv,'premiered':XkPfJNjGArFpagmCTDnKzWBYItEsLq}
   XkPfJNjGArFpagmCTDnKzWBYItEsVi={'mode':'LIVE','mediacode':XkPfJNjGArFpagmCTDnKzWBYItEsVc.get('mediacode'),'stype':XkPfJNjGArFpagmCTDnKzWBYItEsVu}
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.add_dir(XkPfJNjGArFpagmCTDnKzWBYItEsVo,sublabel=XkPfJNjGArFpagmCTDnKzWBYItEsie,img=XkPfJNjGArFpagmCTDnKzWBYItEsVU,infoLabels=XkPfJNjGArFpagmCTDnKzWBYItEsLh,isFolder=XkPfJNjGArFpagmCTDnKzWBYItEsvU,params=XkPfJNjGArFpagmCTDnKzWBYItEsVi)
  if XkPfJNjGArFpagmCTDnKzWBYItEsVO:
   XkPfJNjGArFpagmCTDnKzWBYItEsVi['mode']='CHANNEL' 
   XkPfJNjGArFpagmCTDnKzWBYItEsVi['stype']=XkPfJNjGArFpagmCTDnKzWBYItEsVu 
   XkPfJNjGArFpagmCTDnKzWBYItEsVi['page']=XkPfJNjGArFpagmCTDnKzWBYItEsqR(XkPfJNjGArFpagmCTDnKzWBYItEsVb+1)
   XkPfJNjGArFpagmCTDnKzWBYItEsie='[B]%s >>[/B]'%'다음 페이지'
   XkPfJNjGArFpagmCTDnKzWBYItEsLM=XkPfJNjGArFpagmCTDnKzWBYItEsqR(XkPfJNjGArFpagmCTDnKzWBYItEsVb+1)
   XkPfJNjGArFpagmCTDnKzWBYItEsVQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.add_dir(XkPfJNjGArFpagmCTDnKzWBYItEsie,sublabel=XkPfJNjGArFpagmCTDnKzWBYItEsLM,img=XkPfJNjGArFpagmCTDnKzWBYItEsVQ,infoLabels=XkPfJNjGArFpagmCTDnKzWBYItEsvy,isFolder=XkPfJNjGArFpagmCTDnKzWBYItEsvc,params=XkPfJNjGArFpagmCTDnKzWBYItEsVi)
  if XkPfJNjGArFpagmCTDnKzWBYItEsqw(XkPfJNjGArFpagmCTDnKzWBYItEsVy)>0:xbmcplugin.endOfDirectory(XkPfJNjGArFpagmCTDnKzWBYItEsQl._addon_handle,cacheToDisc=XkPfJNjGArFpagmCTDnKzWBYItEsvU)
 def dp_Program_List(XkPfJNjGArFpagmCTDnKzWBYItEsQl,XkPfJNjGArFpagmCTDnKzWBYItEsVd):
  XkPfJNjGArFpagmCTDnKzWBYItEsLx =XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('stype')
  XkPfJNjGArFpagmCTDnKzWBYItEsiS =XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('orderby')
  XkPfJNjGArFpagmCTDnKzWBYItEsVb =XkPfJNjGArFpagmCTDnKzWBYItEsvO(XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('page'))
  XkPfJNjGArFpagmCTDnKzWBYItEsLl=XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('genreCode')
  if XkPfJNjGArFpagmCTDnKzWBYItEsLl==XkPfJNjGArFpagmCTDnKzWBYItEsvy:XkPfJNjGArFpagmCTDnKzWBYItEsLl='all'
  XkPfJNjGArFpagmCTDnKzWBYItEsLS,XkPfJNjGArFpagmCTDnKzWBYItEsVO=XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.GetProgramList(XkPfJNjGArFpagmCTDnKzWBYItEsLx,XkPfJNjGArFpagmCTDnKzWBYItEsiS,XkPfJNjGArFpagmCTDnKzWBYItEsVb,XkPfJNjGArFpagmCTDnKzWBYItEsLl)
  for XkPfJNjGArFpagmCTDnKzWBYItEsLu in XkPfJNjGArFpagmCTDnKzWBYItEsLS:
   XkPfJNjGArFpagmCTDnKzWBYItEsie =XkPfJNjGArFpagmCTDnKzWBYItEsLu.get('title')
   XkPfJNjGArFpagmCTDnKzWBYItEsVU =XkPfJNjGArFpagmCTDnKzWBYItEsLu.get('thumbnail')
   XkPfJNjGArFpagmCTDnKzWBYItEsLQ =XkPfJNjGArFpagmCTDnKzWBYItEsLu.get('synopsis')
   XkPfJNjGArFpagmCTDnKzWBYItEsLe =XkPfJNjGArFpagmCTDnKzWBYItEsLu.get('channel')
   XkPfJNjGArFpagmCTDnKzWBYItEsLV =XkPfJNjGArFpagmCTDnKzWBYItEsLu.get('cast')
   XkPfJNjGArFpagmCTDnKzWBYItEsLw =XkPfJNjGArFpagmCTDnKzWBYItEsLu.get('director')
   XkPfJNjGArFpagmCTDnKzWBYItEsLR=XkPfJNjGArFpagmCTDnKzWBYItEsLu.get('info_genre')
   XkPfJNjGArFpagmCTDnKzWBYItEsLo =XkPfJNjGArFpagmCTDnKzWBYItEsLu.get('year')
   XkPfJNjGArFpagmCTDnKzWBYItEsLq =XkPfJNjGArFpagmCTDnKzWBYItEsLu.get('premiered')
   XkPfJNjGArFpagmCTDnKzWBYItEsLv =XkPfJNjGArFpagmCTDnKzWBYItEsLu.get('mpaa')
   XkPfJNjGArFpagmCTDnKzWBYItEsLh={'mediatype':'tvshow','title':XkPfJNjGArFpagmCTDnKzWBYItEsie,'studio':XkPfJNjGArFpagmCTDnKzWBYItEsLe,'cast':XkPfJNjGArFpagmCTDnKzWBYItEsLV,'director':XkPfJNjGArFpagmCTDnKzWBYItEsLw,'genre':XkPfJNjGArFpagmCTDnKzWBYItEsLR,'year':XkPfJNjGArFpagmCTDnKzWBYItEsLo,'premiered':XkPfJNjGArFpagmCTDnKzWBYItEsLq,'mpaa':XkPfJNjGArFpagmCTDnKzWBYItEsLv,'plot':XkPfJNjGArFpagmCTDnKzWBYItEsLQ}
   XkPfJNjGArFpagmCTDnKzWBYItEsVi={'mode':'EPISODE','programcode':XkPfJNjGArFpagmCTDnKzWBYItEsLu.get('program'),'page':'1'}
   if XkPfJNjGArFpagmCTDnKzWBYItEsQl.get_settings_makebookmark():
    XkPfJNjGArFpagmCTDnKzWBYItEsLH={'videoid':XkPfJNjGArFpagmCTDnKzWBYItEsLu.get('program'),'vidtype':'tvshow','vtitle':XkPfJNjGArFpagmCTDnKzWBYItEsie,'vsubtitle':XkPfJNjGArFpagmCTDnKzWBYItEsLe,}
    XkPfJNjGArFpagmCTDnKzWBYItEsLd=json.dumps(XkPfJNjGArFpagmCTDnKzWBYItEsLH)
    XkPfJNjGArFpagmCTDnKzWBYItEsLd=urllib.parse.quote(XkPfJNjGArFpagmCTDnKzWBYItEsLd)
    XkPfJNjGArFpagmCTDnKzWBYItEsLb='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(XkPfJNjGArFpagmCTDnKzWBYItEsLd)
    XkPfJNjGArFpagmCTDnKzWBYItEsLy=[('(통합) 찜 영상에 추가',XkPfJNjGArFpagmCTDnKzWBYItEsLb)]
   else:
    XkPfJNjGArFpagmCTDnKzWBYItEsLy=XkPfJNjGArFpagmCTDnKzWBYItEsvy
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.add_dir(XkPfJNjGArFpagmCTDnKzWBYItEsie,sublabel=XkPfJNjGArFpagmCTDnKzWBYItEsLe,img=XkPfJNjGArFpagmCTDnKzWBYItEsVU,infoLabels=XkPfJNjGArFpagmCTDnKzWBYItEsLh,isFolder=XkPfJNjGArFpagmCTDnKzWBYItEsvc,params=XkPfJNjGArFpagmCTDnKzWBYItEsVi,ContextMenu=XkPfJNjGArFpagmCTDnKzWBYItEsLy)
  if XkPfJNjGArFpagmCTDnKzWBYItEsVO:
   XkPfJNjGArFpagmCTDnKzWBYItEsVi['mode'] ='PROGRAM' 
   XkPfJNjGArFpagmCTDnKzWBYItEsVi['stype'] =XkPfJNjGArFpagmCTDnKzWBYItEsLx
   XkPfJNjGArFpagmCTDnKzWBYItEsVi['orderby'] =XkPfJNjGArFpagmCTDnKzWBYItEsiS
   XkPfJNjGArFpagmCTDnKzWBYItEsVi['page'] =XkPfJNjGArFpagmCTDnKzWBYItEsqR(XkPfJNjGArFpagmCTDnKzWBYItEsVb+1)
   XkPfJNjGArFpagmCTDnKzWBYItEsVi['genreCode']=XkPfJNjGArFpagmCTDnKzWBYItEsLl 
   XkPfJNjGArFpagmCTDnKzWBYItEsie='[B]%s >>[/B]'%'다음 페이지'
   XkPfJNjGArFpagmCTDnKzWBYItEsLM=XkPfJNjGArFpagmCTDnKzWBYItEsqR(XkPfJNjGArFpagmCTDnKzWBYItEsVb+1)
   XkPfJNjGArFpagmCTDnKzWBYItEsVQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.add_dir(XkPfJNjGArFpagmCTDnKzWBYItEsie,sublabel=XkPfJNjGArFpagmCTDnKzWBYItEsLM,img=XkPfJNjGArFpagmCTDnKzWBYItEsVQ,infoLabels=XkPfJNjGArFpagmCTDnKzWBYItEsvy,isFolder=XkPfJNjGArFpagmCTDnKzWBYItEsvc,params=XkPfJNjGArFpagmCTDnKzWBYItEsVi)
  xbmcplugin.setContent(XkPfJNjGArFpagmCTDnKzWBYItEsQl._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(XkPfJNjGArFpagmCTDnKzWBYItEsQl._addon_handle,cacheToDisc=XkPfJNjGArFpagmCTDnKzWBYItEsvU)
 def dp_4K_Program_List(XkPfJNjGArFpagmCTDnKzWBYItEsQl,XkPfJNjGArFpagmCTDnKzWBYItEsVd):
  XkPfJNjGArFpagmCTDnKzWBYItEsVb =XkPfJNjGArFpagmCTDnKzWBYItEsvO(XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('page'))
  XkPfJNjGArFpagmCTDnKzWBYItEsLS,XkPfJNjGArFpagmCTDnKzWBYItEsVO=XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.Get_UHD_ProgramList(XkPfJNjGArFpagmCTDnKzWBYItEsVb)
  for XkPfJNjGArFpagmCTDnKzWBYItEsLu in XkPfJNjGArFpagmCTDnKzWBYItEsLS:
   XkPfJNjGArFpagmCTDnKzWBYItEsie =XkPfJNjGArFpagmCTDnKzWBYItEsLu.get('title')
   XkPfJNjGArFpagmCTDnKzWBYItEsVU =XkPfJNjGArFpagmCTDnKzWBYItEsLu.get('thumbnail')
   XkPfJNjGArFpagmCTDnKzWBYItEsLQ =XkPfJNjGArFpagmCTDnKzWBYItEsLu.get('synopsis')
   XkPfJNjGArFpagmCTDnKzWBYItEsLe =XkPfJNjGArFpagmCTDnKzWBYItEsLu.get('channel')
   XkPfJNjGArFpagmCTDnKzWBYItEsLV =XkPfJNjGArFpagmCTDnKzWBYItEsLu.get('cast')
   XkPfJNjGArFpagmCTDnKzWBYItEsLw =XkPfJNjGArFpagmCTDnKzWBYItEsLu.get('director')
   XkPfJNjGArFpagmCTDnKzWBYItEsLR=XkPfJNjGArFpagmCTDnKzWBYItEsLu.get('info_genre')
   XkPfJNjGArFpagmCTDnKzWBYItEsLo =XkPfJNjGArFpagmCTDnKzWBYItEsLu.get('year')
   XkPfJNjGArFpagmCTDnKzWBYItEsLq =XkPfJNjGArFpagmCTDnKzWBYItEsLu.get('premiered')
   XkPfJNjGArFpagmCTDnKzWBYItEsLv =XkPfJNjGArFpagmCTDnKzWBYItEsLu.get('mpaa')
   XkPfJNjGArFpagmCTDnKzWBYItEsLh={'mediatype':'tvshow','title':XkPfJNjGArFpagmCTDnKzWBYItEsie,'studio':XkPfJNjGArFpagmCTDnKzWBYItEsLe,'cast':XkPfJNjGArFpagmCTDnKzWBYItEsLV,'director':XkPfJNjGArFpagmCTDnKzWBYItEsLw,'genre':XkPfJNjGArFpagmCTDnKzWBYItEsLR,'year':XkPfJNjGArFpagmCTDnKzWBYItEsLo,'premiered':XkPfJNjGArFpagmCTDnKzWBYItEsLq,'mpaa':XkPfJNjGArFpagmCTDnKzWBYItEsLv,'plot':XkPfJNjGArFpagmCTDnKzWBYItEsLQ}
   XkPfJNjGArFpagmCTDnKzWBYItEsVi={'mode':'EPISODE','programcode':XkPfJNjGArFpagmCTDnKzWBYItEsLu.get('program'),'page':'1'}
   if XkPfJNjGArFpagmCTDnKzWBYItEsQl.get_settings_makebookmark():
    XkPfJNjGArFpagmCTDnKzWBYItEsLH={'videoid':XkPfJNjGArFpagmCTDnKzWBYItEsLu.get('program'),'vidtype':'tvshow','vtitle':XkPfJNjGArFpagmCTDnKzWBYItEsie,'vsubtitle':XkPfJNjGArFpagmCTDnKzWBYItEsLe,}
    XkPfJNjGArFpagmCTDnKzWBYItEsLd=json.dumps(XkPfJNjGArFpagmCTDnKzWBYItEsLH)
    XkPfJNjGArFpagmCTDnKzWBYItEsLd=urllib.parse.quote(XkPfJNjGArFpagmCTDnKzWBYItEsLd)
    XkPfJNjGArFpagmCTDnKzWBYItEsLb='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(XkPfJNjGArFpagmCTDnKzWBYItEsLd)
    XkPfJNjGArFpagmCTDnKzWBYItEsLy=[('(통합) 찜 영상에 추가',XkPfJNjGArFpagmCTDnKzWBYItEsLb)]
   else:
    XkPfJNjGArFpagmCTDnKzWBYItEsLy=XkPfJNjGArFpagmCTDnKzWBYItEsvy
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.add_dir(XkPfJNjGArFpagmCTDnKzWBYItEsie,sublabel=XkPfJNjGArFpagmCTDnKzWBYItEsLe,img=XkPfJNjGArFpagmCTDnKzWBYItEsVU,infoLabels=XkPfJNjGArFpagmCTDnKzWBYItEsLh,isFolder=XkPfJNjGArFpagmCTDnKzWBYItEsvc,params=XkPfJNjGArFpagmCTDnKzWBYItEsVi,ContextMenu=XkPfJNjGArFpagmCTDnKzWBYItEsLy)
  if XkPfJNjGArFpagmCTDnKzWBYItEsVO:
   XkPfJNjGArFpagmCTDnKzWBYItEsVi['mode'] ='4K_PROGRAM' 
   XkPfJNjGArFpagmCTDnKzWBYItEsVi['page'] =XkPfJNjGArFpagmCTDnKzWBYItEsqR(XkPfJNjGArFpagmCTDnKzWBYItEsVb+1)
   XkPfJNjGArFpagmCTDnKzWBYItEsie='[B]%s >>[/B]'%'다음 페이지'
   XkPfJNjGArFpagmCTDnKzWBYItEsLM=XkPfJNjGArFpagmCTDnKzWBYItEsqR(XkPfJNjGArFpagmCTDnKzWBYItEsVb+1)
   XkPfJNjGArFpagmCTDnKzWBYItEsVQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.add_dir(XkPfJNjGArFpagmCTDnKzWBYItEsie,sublabel=XkPfJNjGArFpagmCTDnKzWBYItEsLM,img=XkPfJNjGArFpagmCTDnKzWBYItEsVQ,infoLabels=XkPfJNjGArFpagmCTDnKzWBYItEsvy,isFolder=XkPfJNjGArFpagmCTDnKzWBYItEsvc,params=XkPfJNjGArFpagmCTDnKzWBYItEsVi)
  xbmcplugin.setContent(XkPfJNjGArFpagmCTDnKzWBYItEsQl._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(XkPfJNjGArFpagmCTDnKzWBYItEsQl._addon_handle,cacheToDisc=XkPfJNjGArFpagmCTDnKzWBYItEsvU)
 def dp_Ori_Program_List(XkPfJNjGArFpagmCTDnKzWBYItEsQl,XkPfJNjGArFpagmCTDnKzWBYItEsVd):
  XkPfJNjGArFpagmCTDnKzWBYItEsVb =XkPfJNjGArFpagmCTDnKzWBYItEsvO(XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('page'))
  XkPfJNjGArFpagmCTDnKzWBYItEsLS,XkPfJNjGArFpagmCTDnKzWBYItEsVO=XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.Get_Origianl_ProgramList(XkPfJNjGArFpagmCTDnKzWBYItEsVb)
  for XkPfJNjGArFpagmCTDnKzWBYItEsLu in XkPfJNjGArFpagmCTDnKzWBYItEsLS:
   XkPfJNjGArFpagmCTDnKzWBYItEsie =XkPfJNjGArFpagmCTDnKzWBYItEsLu.get('title')
   XkPfJNjGArFpagmCTDnKzWBYItEsVU =XkPfJNjGArFpagmCTDnKzWBYItEsLu.get('thumbnail')
   XkPfJNjGArFpagmCTDnKzWBYItEsLc =XkPfJNjGArFpagmCTDnKzWBYItEsLu.get('vod_type')
   XkPfJNjGArFpagmCTDnKzWBYItEsLU =XkPfJNjGArFpagmCTDnKzWBYItEsLu.get('vod_code')
   if XkPfJNjGArFpagmCTDnKzWBYItEsLc=='vod':
    XkPfJNjGArFpagmCTDnKzWBYItEsLh={'mediatype':'tvshow','title':XkPfJNjGArFpagmCTDnKzWBYItEsie,}
    XkPfJNjGArFpagmCTDnKzWBYItEsVi={'mode':'EPISODE','programcode':XkPfJNjGArFpagmCTDnKzWBYItEsLU,'page':'1',}
    XkPfJNjGArFpagmCTDnKzWBYItEsVL=XkPfJNjGArFpagmCTDnKzWBYItEsvc
   else:
    XkPfJNjGArFpagmCTDnKzWBYItEsLh={'mediatype':'movie','title':XkPfJNjGArFpagmCTDnKzWBYItEsie,'plot':'movie',}
    XkPfJNjGArFpagmCTDnKzWBYItEsVi={'mode':'MOVIE','mediacode':XkPfJNjGArFpagmCTDnKzWBYItEsLU,'stype':'movie','title':XkPfJNjGArFpagmCTDnKzWBYItEsie,'thumbnail':XkPfJNjGArFpagmCTDnKzWBYItEsVU,}
    XkPfJNjGArFpagmCTDnKzWBYItEsVL=XkPfJNjGArFpagmCTDnKzWBYItEsvU
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.add_dir(XkPfJNjGArFpagmCTDnKzWBYItEsie,sublabel=XkPfJNjGArFpagmCTDnKzWBYItEsvy,img=XkPfJNjGArFpagmCTDnKzWBYItEsVU,infoLabels=XkPfJNjGArFpagmCTDnKzWBYItEsLh,isFolder=XkPfJNjGArFpagmCTDnKzWBYItEsVL,params=XkPfJNjGArFpagmCTDnKzWBYItEsVi,ContextMenu=XkPfJNjGArFpagmCTDnKzWBYItEsvy)
  if XkPfJNjGArFpagmCTDnKzWBYItEsVO:
   XkPfJNjGArFpagmCTDnKzWBYItEsVi['mode'] ='ORI_PROGRAM' 
   XkPfJNjGArFpagmCTDnKzWBYItEsVi['page'] =XkPfJNjGArFpagmCTDnKzWBYItEsqR(XkPfJNjGArFpagmCTDnKzWBYItEsVb+1)
   XkPfJNjGArFpagmCTDnKzWBYItEsie='[B]%s >>[/B]'%'다음 페이지'
   XkPfJNjGArFpagmCTDnKzWBYItEsLM=XkPfJNjGArFpagmCTDnKzWBYItEsqR(XkPfJNjGArFpagmCTDnKzWBYItEsVb+1)
   XkPfJNjGArFpagmCTDnKzWBYItEsVQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.add_dir(XkPfJNjGArFpagmCTDnKzWBYItEsie,sublabel=XkPfJNjGArFpagmCTDnKzWBYItEsLM,img=XkPfJNjGArFpagmCTDnKzWBYItEsVQ,infoLabels=XkPfJNjGArFpagmCTDnKzWBYItEsvy,isFolder=XkPfJNjGArFpagmCTDnKzWBYItEsvc,params=XkPfJNjGArFpagmCTDnKzWBYItEsVi)
  xbmcplugin.setContent(XkPfJNjGArFpagmCTDnKzWBYItEsQl._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(XkPfJNjGArFpagmCTDnKzWBYItEsQl._addon_handle,cacheToDisc=XkPfJNjGArFpagmCTDnKzWBYItEsvU)
 def dp_Episode_List(XkPfJNjGArFpagmCTDnKzWBYItEsQl,XkPfJNjGArFpagmCTDnKzWBYItEsVd):
  XkPfJNjGArFpagmCTDnKzWBYItEswQ=XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('programcode')
  XkPfJNjGArFpagmCTDnKzWBYItEsVb =XkPfJNjGArFpagmCTDnKzWBYItEsvO(XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('page'))
  XkPfJNjGArFpagmCTDnKzWBYItEswi,XkPfJNjGArFpagmCTDnKzWBYItEsVO,XkPfJNjGArFpagmCTDnKzWBYItEswV=XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.GetEpisodeList(XkPfJNjGArFpagmCTDnKzWBYItEswQ,XkPfJNjGArFpagmCTDnKzWBYItEsVb,orderby=XkPfJNjGArFpagmCTDnKzWBYItEsQl.get_winEpisodeOrderby())
  for XkPfJNjGArFpagmCTDnKzWBYItEswL in XkPfJNjGArFpagmCTDnKzWBYItEswi:
   XkPfJNjGArFpagmCTDnKzWBYItEsie =XkPfJNjGArFpagmCTDnKzWBYItEswL.get('title')
   XkPfJNjGArFpagmCTDnKzWBYItEsLM =XkPfJNjGArFpagmCTDnKzWBYItEswL.get('subtitle')
   XkPfJNjGArFpagmCTDnKzWBYItEsVU =XkPfJNjGArFpagmCTDnKzWBYItEswL.get('thumbnail')
   XkPfJNjGArFpagmCTDnKzWBYItEsLQ =XkPfJNjGArFpagmCTDnKzWBYItEswL.get('synopsis')
   XkPfJNjGArFpagmCTDnKzWBYItEswR=XkPfJNjGArFpagmCTDnKzWBYItEswL.get('info_title')
   XkPfJNjGArFpagmCTDnKzWBYItEswo =XkPfJNjGArFpagmCTDnKzWBYItEswL.get('aired')
   XkPfJNjGArFpagmCTDnKzWBYItEswv =XkPfJNjGArFpagmCTDnKzWBYItEswL.get('studio')
   XkPfJNjGArFpagmCTDnKzWBYItEswq =XkPfJNjGArFpagmCTDnKzWBYItEswL.get('frequency')
   XkPfJNjGArFpagmCTDnKzWBYItEsLh={'mediatype':'episode','title':XkPfJNjGArFpagmCTDnKzWBYItEswR,'aired':XkPfJNjGArFpagmCTDnKzWBYItEswo,'studio':XkPfJNjGArFpagmCTDnKzWBYItEswv,'episode':XkPfJNjGArFpagmCTDnKzWBYItEswq,'plot':XkPfJNjGArFpagmCTDnKzWBYItEsLQ}
   XkPfJNjGArFpagmCTDnKzWBYItEsVi={'mode':'VOD','mediacode':XkPfJNjGArFpagmCTDnKzWBYItEswL.get('episode'),'stype':'vod','programcode':XkPfJNjGArFpagmCTDnKzWBYItEswQ,'title':XkPfJNjGArFpagmCTDnKzWBYItEsie,'thumbnail':XkPfJNjGArFpagmCTDnKzWBYItEsVU}
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.add_dir(XkPfJNjGArFpagmCTDnKzWBYItEsie,sublabel=XkPfJNjGArFpagmCTDnKzWBYItEsLM,img=XkPfJNjGArFpagmCTDnKzWBYItEsVU,infoLabels=XkPfJNjGArFpagmCTDnKzWBYItEsLh,isFolder=XkPfJNjGArFpagmCTDnKzWBYItEsvU,params=XkPfJNjGArFpagmCTDnKzWBYItEsVi)
  if XkPfJNjGArFpagmCTDnKzWBYItEsVb==1:
   XkPfJNjGArFpagmCTDnKzWBYItEsLh={'plot':'정렬순서를 변경합니다.'}
   XkPfJNjGArFpagmCTDnKzWBYItEsVi={}
   XkPfJNjGArFpagmCTDnKzWBYItEsVi['mode'] ='ORDER_BY' 
   if XkPfJNjGArFpagmCTDnKzWBYItEsQl.get_winEpisodeOrderby()=='desc':
    XkPfJNjGArFpagmCTDnKzWBYItEsie='정렬순서변경 : 최신화부터 -> 1회부터'
    XkPfJNjGArFpagmCTDnKzWBYItEsVi['orderby']='asc'
   else:
    XkPfJNjGArFpagmCTDnKzWBYItEsie='정렬순서변경 : 1회부터 -> 최신화부터'
    XkPfJNjGArFpagmCTDnKzWBYItEsVi['orderby']='desc'
   XkPfJNjGArFpagmCTDnKzWBYItEsVQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.add_dir(XkPfJNjGArFpagmCTDnKzWBYItEsie,sublabel='',img=XkPfJNjGArFpagmCTDnKzWBYItEsVQ,infoLabels=XkPfJNjGArFpagmCTDnKzWBYItEsLh,isFolder=XkPfJNjGArFpagmCTDnKzWBYItEsvU,params=XkPfJNjGArFpagmCTDnKzWBYItEsVi,isLink=XkPfJNjGArFpagmCTDnKzWBYItEsvc)
  if XkPfJNjGArFpagmCTDnKzWBYItEsVO:
   XkPfJNjGArFpagmCTDnKzWBYItEsVi['mode'] ='EPISODE' 
   XkPfJNjGArFpagmCTDnKzWBYItEsVi['programcode']=XkPfJNjGArFpagmCTDnKzWBYItEswQ
   XkPfJNjGArFpagmCTDnKzWBYItEsVi['page'] =XkPfJNjGArFpagmCTDnKzWBYItEsqR(XkPfJNjGArFpagmCTDnKzWBYItEsVb+1)
   XkPfJNjGArFpagmCTDnKzWBYItEsie='[B]%s >>[/B]'%'다음 페이지'
   XkPfJNjGArFpagmCTDnKzWBYItEsLM=XkPfJNjGArFpagmCTDnKzWBYItEsqR(XkPfJNjGArFpagmCTDnKzWBYItEsVb+1)
   XkPfJNjGArFpagmCTDnKzWBYItEsVQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.add_dir(XkPfJNjGArFpagmCTDnKzWBYItEsie,sublabel=XkPfJNjGArFpagmCTDnKzWBYItEsLM,img=XkPfJNjGArFpagmCTDnKzWBYItEsVQ,infoLabels=XkPfJNjGArFpagmCTDnKzWBYItEsvy,isFolder=XkPfJNjGArFpagmCTDnKzWBYItEsvc,params=XkPfJNjGArFpagmCTDnKzWBYItEsVi)
  xbmcplugin.setContent(XkPfJNjGArFpagmCTDnKzWBYItEsQl._addon_handle,'episodes')
  if XkPfJNjGArFpagmCTDnKzWBYItEsqw(XkPfJNjGArFpagmCTDnKzWBYItEswi)>0:xbmcplugin.endOfDirectory(XkPfJNjGArFpagmCTDnKzWBYItEsQl._addon_handle,cacheToDisc=XkPfJNjGArFpagmCTDnKzWBYItEsvc)
 def dp_setEpOrderby(XkPfJNjGArFpagmCTDnKzWBYItEsQl,XkPfJNjGArFpagmCTDnKzWBYItEsVd):
  XkPfJNjGArFpagmCTDnKzWBYItEsiS =XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('orderby')
  XkPfJNjGArFpagmCTDnKzWBYItEsQl.set_winEpisodeOrderby(XkPfJNjGArFpagmCTDnKzWBYItEsiS)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(XkPfJNjGArFpagmCTDnKzWBYItEsQl,XkPfJNjGArFpagmCTDnKzWBYItEsVd):
  XkPfJNjGArFpagmCTDnKzWBYItEsLx =XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('stype')
  XkPfJNjGArFpagmCTDnKzWBYItEsiS =XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('orderby')
  XkPfJNjGArFpagmCTDnKzWBYItEsVb=XkPfJNjGArFpagmCTDnKzWBYItEsvO(XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('page'))
  XkPfJNjGArFpagmCTDnKzWBYItEswh,XkPfJNjGArFpagmCTDnKzWBYItEsVO=XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.GetMovieList(XkPfJNjGArFpagmCTDnKzWBYItEsLx,XkPfJNjGArFpagmCTDnKzWBYItEsiS,XkPfJNjGArFpagmCTDnKzWBYItEsVb)
  for XkPfJNjGArFpagmCTDnKzWBYItEswM in XkPfJNjGArFpagmCTDnKzWBYItEswh:
   XkPfJNjGArFpagmCTDnKzWBYItEsie =XkPfJNjGArFpagmCTDnKzWBYItEswM.get('title')
   XkPfJNjGArFpagmCTDnKzWBYItEsVU =XkPfJNjGArFpagmCTDnKzWBYItEswM.get('thumbnail')
   XkPfJNjGArFpagmCTDnKzWBYItEsLQ =XkPfJNjGArFpagmCTDnKzWBYItEswM.get('synopsis')
   XkPfJNjGArFpagmCTDnKzWBYItEswR =XkPfJNjGArFpagmCTDnKzWBYItEswM.get('info_title')
   XkPfJNjGArFpagmCTDnKzWBYItEsLo =XkPfJNjGArFpagmCTDnKzWBYItEswM.get('year')
   XkPfJNjGArFpagmCTDnKzWBYItEsLV =XkPfJNjGArFpagmCTDnKzWBYItEswM.get('cast')
   XkPfJNjGArFpagmCTDnKzWBYItEsLw =XkPfJNjGArFpagmCTDnKzWBYItEswM.get('director')
   XkPfJNjGArFpagmCTDnKzWBYItEsLR =XkPfJNjGArFpagmCTDnKzWBYItEswM.get('info_genre')
   XkPfJNjGArFpagmCTDnKzWBYItEswx =XkPfJNjGArFpagmCTDnKzWBYItEswM.get('duration')
   XkPfJNjGArFpagmCTDnKzWBYItEsLq =XkPfJNjGArFpagmCTDnKzWBYItEswM.get('premiered')
   XkPfJNjGArFpagmCTDnKzWBYItEswv =XkPfJNjGArFpagmCTDnKzWBYItEswM.get('studio')
   XkPfJNjGArFpagmCTDnKzWBYItEsLv =XkPfJNjGArFpagmCTDnKzWBYItEswM.get('mpaa')
   XkPfJNjGArFpagmCTDnKzWBYItEsLh={'mediatype':'movie','title':XkPfJNjGArFpagmCTDnKzWBYItEswR,'year':XkPfJNjGArFpagmCTDnKzWBYItEsLo,'cast':XkPfJNjGArFpagmCTDnKzWBYItEsLV,'director':XkPfJNjGArFpagmCTDnKzWBYItEsLw,'genre':XkPfJNjGArFpagmCTDnKzWBYItEsLR,'duration':XkPfJNjGArFpagmCTDnKzWBYItEswx,'premiered':XkPfJNjGArFpagmCTDnKzWBYItEsLq,'studio':XkPfJNjGArFpagmCTDnKzWBYItEswv,'mpaa':XkPfJNjGArFpagmCTDnKzWBYItEsLv,'plot':XkPfJNjGArFpagmCTDnKzWBYItEsLQ}
   XkPfJNjGArFpagmCTDnKzWBYItEsVi={'mode':'MOVIE','mediacode':XkPfJNjGArFpagmCTDnKzWBYItEswM.get('moviecode'),'stype':'movie','title':XkPfJNjGArFpagmCTDnKzWBYItEsie,'thumbnail':XkPfJNjGArFpagmCTDnKzWBYItEsVU}
   if XkPfJNjGArFpagmCTDnKzWBYItEsQl.get_settings_makebookmark():
    XkPfJNjGArFpagmCTDnKzWBYItEsLH={'videoid':XkPfJNjGArFpagmCTDnKzWBYItEswM.get('moviecode'),'vidtype':'movie','vtitle':XkPfJNjGArFpagmCTDnKzWBYItEswR,'vsubtitle':'',}
    XkPfJNjGArFpagmCTDnKzWBYItEsLd=json.dumps(XkPfJNjGArFpagmCTDnKzWBYItEsLH)
    XkPfJNjGArFpagmCTDnKzWBYItEsLd=urllib.parse.quote(XkPfJNjGArFpagmCTDnKzWBYItEsLd)
    XkPfJNjGArFpagmCTDnKzWBYItEsLb='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(XkPfJNjGArFpagmCTDnKzWBYItEsLd)
    XkPfJNjGArFpagmCTDnKzWBYItEsLy=[('(통합) 찜 영상에 추가',XkPfJNjGArFpagmCTDnKzWBYItEsLb)]
   else:
    XkPfJNjGArFpagmCTDnKzWBYItEsLy=XkPfJNjGArFpagmCTDnKzWBYItEsvy
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.add_dir(XkPfJNjGArFpagmCTDnKzWBYItEsie,sublabel='',img=XkPfJNjGArFpagmCTDnKzWBYItEsVU,infoLabels=XkPfJNjGArFpagmCTDnKzWBYItEsLh,isFolder=XkPfJNjGArFpagmCTDnKzWBYItEsvU,params=XkPfJNjGArFpagmCTDnKzWBYItEsVi,ContextMenu=XkPfJNjGArFpagmCTDnKzWBYItEsLy)
  if XkPfJNjGArFpagmCTDnKzWBYItEsVO:
   XkPfJNjGArFpagmCTDnKzWBYItEsVi={}
   XkPfJNjGArFpagmCTDnKzWBYItEsVi['mode'] ='MOVIE_SUB' 
   XkPfJNjGArFpagmCTDnKzWBYItEsVi['orderby']=XkPfJNjGArFpagmCTDnKzWBYItEsiS
   XkPfJNjGArFpagmCTDnKzWBYItEsVi['stype'] =XkPfJNjGArFpagmCTDnKzWBYItEsLx
   XkPfJNjGArFpagmCTDnKzWBYItEsVi['page'] =XkPfJNjGArFpagmCTDnKzWBYItEsqR(XkPfJNjGArFpagmCTDnKzWBYItEsVb+1)
   XkPfJNjGArFpagmCTDnKzWBYItEsie='[B]%s >>[/B]'%'다음 페이지'
   XkPfJNjGArFpagmCTDnKzWBYItEsLM=XkPfJNjGArFpagmCTDnKzWBYItEsqR(XkPfJNjGArFpagmCTDnKzWBYItEsVb+1)
   XkPfJNjGArFpagmCTDnKzWBYItEsVQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.add_dir(XkPfJNjGArFpagmCTDnKzWBYItEsie,sublabel=XkPfJNjGArFpagmCTDnKzWBYItEsLM,img=XkPfJNjGArFpagmCTDnKzWBYItEsVQ,infoLabels=XkPfJNjGArFpagmCTDnKzWBYItEsvy,isFolder=XkPfJNjGArFpagmCTDnKzWBYItEsvc,params=XkPfJNjGArFpagmCTDnKzWBYItEsVi)
  xbmcplugin.setContent(XkPfJNjGArFpagmCTDnKzWBYItEsQl._addon_handle,'movies')
  xbmcplugin.endOfDirectory(XkPfJNjGArFpagmCTDnKzWBYItEsQl._addon_handle,cacheToDisc=XkPfJNjGArFpagmCTDnKzWBYItEsvU)
 def dp_4K_Movie_List(XkPfJNjGArFpagmCTDnKzWBYItEsQl,XkPfJNjGArFpagmCTDnKzWBYItEsVd):
  XkPfJNjGArFpagmCTDnKzWBYItEsVb=XkPfJNjGArFpagmCTDnKzWBYItEsvO(XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('page'))
  XkPfJNjGArFpagmCTDnKzWBYItEswh,XkPfJNjGArFpagmCTDnKzWBYItEsVO=XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.Get_UHD_MovieList(XkPfJNjGArFpagmCTDnKzWBYItEsVb)
  for XkPfJNjGArFpagmCTDnKzWBYItEswM in XkPfJNjGArFpagmCTDnKzWBYItEswh:
   XkPfJNjGArFpagmCTDnKzWBYItEsie =XkPfJNjGArFpagmCTDnKzWBYItEswM.get('title')
   XkPfJNjGArFpagmCTDnKzWBYItEsVU =XkPfJNjGArFpagmCTDnKzWBYItEswM.get('thumbnail')
   XkPfJNjGArFpagmCTDnKzWBYItEsLQ =XkPfJNjGArFpagmCTDnKzWBYItEswM.get('synopsis')
   XkPfJNjGArFpagmCTDnKzWBYItEswR =XkPfJNjGArFpagmCTDnKzWBYItEswM.get('info_title')
   XkPfJNjGArFpagmCTDnKzWBYItEsLo =XkPfJNjGArFpagmCTDnKzWBYItEswM.get('year')
   XkPfJNjGArFpagmCTDnKzWBYItEsLV =XkPfJNjGArFpagmCTDnKzWBYItEswM.get('cast')
   XkPfJNjGArFpagmCTDnKzWBYItEsLw =XkPfJNjGArFpagmCTDnKzWBYItEswM.get('director')
   XkPfJNjGArFpagmCTDnKzWBYItEsLR =XkPfJNjGArFpagmCTDnKzWBYItEswM.get('info_genre')
   XkPfJNjGArFpagmCTDnKzWBYItEswx =XkPfJNjGArFpagmCTDnKzWBYItEswM.get('duration')
   XkPfJNjGArFpagmCTDnKzWBYItEsLq =XkPfJNjGArFpagmCTDnKzWBYItEswM.get('premiered')
   XkPfJNjGArFpagmCTDnKzWBYItEswv =XkPfJNjGArFpagmCTDnKzWBYItEswM.get('studio')
   XkPfJNjGArFpagmCTDnKzWBYItEsLv =XkPfJNjGArFpagmCTDnKzWBYItEswM.get('mpaa')
   XkPfJNjGArFpagmCTDnKzWBYItEsLh={'mediatype':'movie','title':XkPfJNjGArFpagmCTDnKzWBYItEswR,'year':XkPfJNjGArFpagmCTDnKzWBYItEsLo,'cast':XkPfJNjGArFpagmCTDnKzWBYItEsLV,'director':XkPfJNjGArFpagmCTDnKzWBYItEsLw,'genre':XkPfJNjGArFpagmCTDnKzWBYItEsLR,'duration':XkPfJNjGArFpagmCTDnKzWBYItEswx,'premiered':XkPfJNjGArFpagmCTDnKzWBYItEsLq,'studio':XkPfJNjGArFpagmCTDnKzWBYItEswv,'mpaa':XkPfJNjGArFpagmCTDnKzWBYItEsLv,'plot':XkPfJNjGArFpagmCTDnKzWBYItEsLQ}
   XkPfJNjGArFpagmCTDnKzWBYItEsVi={'mode':'MOVIE','mediacode':XkPfJNjGArFpagmCTDnKzWBYItEswM.get('moviecode'),'stype':'movie','title':XkPfJNjGArFpagmCTDnKzWBYItEsie,'thumbnail':XkPfJNjGArFpagmCTDnKzWBYItEsVU}
   if XkPfJNjGArFpagmCTDnKzWBYItEsQl.get_settings_makebookmark():
    XkPfJNjGArFpagmCTDnKzWBYItEsLH={'videoid':XkPfJNjGArFpagmCTDnKzWBYItEswM.get('moviecode'),'vidtype':'movie','vtitle':XkPfJNjGArFpagmCTDnKzWBYItEswR,'vsubtitle':'',}
    XkPfJNjGArFpagmCTDnKzWBYItEsLd=json.dumps(XkPfJNjGArFpagmCTDnKzWBYItEsLH)
    XkPfJNjGArFpagmCTDnKzWBYItEsLd=urllib.parse.quote(XkPfJNjGArFpagmCTDnKzWBYItEsLd)
    XkPfJNjGArFpagmCTDnKzWBYItEsLb='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(XkPfJNjGArFpagmCTDnKzWBYItEsLd)
    XkPfJNjGArFpagmCTDnKzWBYItEsLy=[('(통합) 찜 영상에 추가',XkPfJNjGArFpagmCTDnKzWBYItEsLb)]
   else:
    XkPfJNjGArFpagmCTDnKzWBYItEsLy=XkPfJNjGArFpagmCTDnKzWBYItEsvy
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.add_dir(XkPfJNjGArFpagmCTDnKzWBYItEsie,sublabel='',img=XkPfJNjGArFpagmCTDnKzWBYItEsVU,infoLabels=XkPfJNjGArFpagmCTDnKzWBYItEsLh,isFolder=XkPfJNjGArFpagmCTDnKzWBYItEsvU,params=XkPfJNjGArFpagmCTDnKzWBYItEsVi,ContextMenu=XkPfJNjGArFpagmCTDnKzWBYItEsLy)
  if XkPfJNjGArFpagmCTDnKzWBYItEsVO:
   XkPfJNjGArFpagmCTDnKzWBYItEsVi={}
   XkPfJNjGArFpagmCTDnKzWBYItEsVi['mode'] ='4K_MOVIE' 
   XkPfJNjGArFpagmCTDnKzWBYItEsVi['page'] =XkPfJNjGArFpagmCTDnKzWBYItEsqR(XkPfJNjGArFpagmCTDnKzWBYItEsVb+1)
   XkPfJNjGArFpagmCTDnKzWBYItEsie='[B]%s >>[/B]'%'다음 페이지'
   XkPfJNjGArFpagmCTDnKzWBYItEsLM=XkPfJNjGArFpagmCTDnKzWBYItEsqR(XkPfJNjGArFpagmCTDnKzWBYItEsVb+1)
   XkPfJNjGArFpagmCTDnKzWBYItEsVQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.add_dir(XkPfJNjGArFpagmCTDnKzWBYItEsie,sublabel=XkPfJNjGArFpagmCTDnKzWBYItEsLM,img=XkPfJNjGArFpagmCTDnKzWBYItEsVQ,infoLabels=XkPfJNjGArFpagmCTDnKzWBYItEsvy,isFolder=XkPfJNjGArFpagmCTDnKzWBYItEsvc,params=XkPfJNjGArFpagmCTDnKzWBYItEsVi)
  xbmcplugin.setContent(XkPfJNjGArFpagmCTDnKzWBYItEsQl._addon_handle,'movies')
  xbmcplugin.endOfDirectory(XkPfJNjGArFpagmCTDnKzWBYItEsQl._addon_handle,cacheToDisc=XkPfJNjGArFpagmCTDnKzWBYItEsvU)
 def dp_Set_Bookmark(XkPfJNjGArFpagmCTDnKzWBYItEsQl,XkPfJNjGArFpagmCTDnKzWBYItEsVd):
  XkPfJNjGArFpagmCTDnKzWBYItEswl=urllib.parse.unquote(XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('bm_param'))
  XkPfJNjGArFpagmCTDnKzWBYItEswl=json.loads(XkPfJNjGArFpagmCTDnKzWBYItEswl)
  XkPfJNjGArFpagmCTDnKzWBYItEswS =XkPfJNjGArFpagmCTDnKzWBYItEswl.get('videoid')
  XkPfJNjGArFpagmCTDnKzWBYItEswu =XkPfJNjGArFpagmCTDnKzWBYItEswl.get('vidtype')
  XkPfJNjGArFpagmCTDnKzWBYItEswe =XkPfJNjGArFpagmCTDnKzWBYItEswl.get('vtitle')
  XkPfJNjGArFpagmCTDnKzWBYItEswH =XkPfJNjGArFpagmCTDnKzWBYItEswl.get('vsubtitle')
  XkPfJNjGArFpagmCTDnKzWBYItEsQd=xbmcgui.Dialog()
  XkPfJNjGArFpagmCTDnKzWBYItEsVx=XkPfJNjGArFpagmCTDnKzWBYItEsQd.yesno(__language__(30913).encode('utf8'),XkPfJNjGArFpagmCTDnKzWBYItEswe+' \n\n'+__language__(30914))
  if XkPfJNjGArFpagmCTDnKzWBYItEsVx==XkPfJNjGArFpagmCTDnKzWBYItEsvU:return
  XkPfJNjGArFpagmCTDnKzWBYItEswd=XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.GetBookmarkInfo(XkPfJNjGArFpagmCTDnKzWBYItEswS,XkPfJNjGArFpagmCTDnKzWBYItEswu)
  if XkPfJNjGArFpagmCTDnKzWBYItEswH!='':
   XkPfJNjGArFpagmCTDnKzWBYItEswd['saveinfo']['subtitle']=XkPfJNjGArFpagmCTDnKzWBYItEswH 
   if XkPfJNjGArFpagmCTDnKzWBYItEswu=='tvshow':XkPfJNjGArFpagmCTDnKzWBYItEswd['saveinfo']['infoLabels']['studio']=XkPfJNjGArFpagmCTDnKzWBYItEswH 
  XkPfJNjGArFpagmCTDnKzWBYItEswb=json.dumps(XkPfJNjGArFpagmCTDnKzWBYItEswd)
  XkPfJNjGArFpagmCTDnKzWBYItEswb=urllib.parse.quote(XkPfJNjGArFpagmCTDnKzWBYItEswb)
  XkPfJNjGArFpagmCTDnKzWBYItEsLb ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(XkPfJNjGArFpagmCTDnKzWBYItEswb)
  xbmc.executebuiltin(XkPfJNjGArFpagmCTDnKzWBYItEsLb)
 def dp_Search_Group(XkPfJNjGArFpagmCTDnKzWBYItEsQl,XkPfJNjGArFpagmCTDnKzWBYItEsVd):
  if 'search_key' in XkPfJNjGArFpagmCTDnKzWBYItEsVd:
   XkPfJNjGArFpagmCTDnKzWBYItEswy=XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('search_key')
  else:
   XkPfJNjGArFpagmCTDnKzWBYItEswy=XkPfJNjGArFpagmCTDnKzWBYItEsQl.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not XkPfJNjGArFpagmCTDnKzWBYItEswy:
    return
  for XkPfJNjGArFpagmCTDnKzWBYItEsVH in XkPfJNjGArFpagmCTDnKzWBYItEsQR:
   XkPfJNjGArFpagmCTDnKzWBYItEswO =XkPfJNjGArFpagmCTDnKzWBYItEsVH.get('mode')
   XkPfJNjGArFpagmCTDnKzWBYItEsVu=XkPfJNjGArFpagmCTDnKzWBYItEsVH.get('stype')
   XkPfJNjGArFpagmCTDnKzWBYItEsie=XkPfJNjGArFpagmCTDnKzWBYItEsVH.get('title')
   (XkPfJNjGArFpagmCTDnKzWBYItEswc,XkPfJNjGArFpagmCTDnKzWBYItEsVO)=XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.GetSearchList(XkPfJNjGArFpagmCTDnKzWBYItEswy,1,XkPfJNjGArFpagmCTDnKzWBYItEsVu)
   XkPfJNjGArFpagmCTDnKzWBYItEsVR={'plot':'검색어 : '+XkPfJNjGArFpagmCTDnKzWBYItEswy+'\n\n'+XkPfJNjGArFpagmCTDnKzWBYItEsQl.Search_FreeList(XkPfJNjGArFpagmCTDnKzWBYItEswc)}
   XkPfJNjGArFpagmCTDnKzWBYItEsVi={'mode':XkPfJNjGArFpagmCTDnKzWBYItEswO,'stype':XkPfJNjGArFpagmCTDnKzWBYItEsVu,'search_key':XkPfJNjGArFpagmCTDnKzWBYItEswy,'page':'1',}
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.add_dir(XkPfJNjGArFpagmCTDnKzWBYItEsie,sublabel='',img='',infoLabels=XkPfJNjGArFpagmCTDnKzWBYItEsVR,isFolder=XkPfJNjGArFpagmCTDnKzWBYItEsvc,params=XkPfJNjGArFpagmCTDnKzWBYItEsVi)
  if XkPfJNjGArFpagmCTDnKzWBYItEsqw(XkPfJNjGArFpagmCTDnKzWBYItEsQR)>0:xbmcplugin.endOfDirectory(XkPfJNjGArFpagmCTDnKzWBYItEsQl._addon_handle,cacheToDisc=XkPfJNjGArFpagmCTDnKzWBYItEsvc)
  XkPfJNjGArFpagmCTDnKzWBYItEsQl.Save_Searched_List(XkPfJNjGArFpagmCTDnKzWBYItEswy)
 def Search_FreeList(XkPfJNjGArFpagmCTDnKzWBYItEsQl,XkPfJNjGArFpagmCTDnKzWBYItEsRq):
  XkPfJNjGArFpagmCTDnKzWBYItEswU=''
  XkPfJNjGArFpagmCTDnKzWBYItEsRQ=7
  try:
   if XkPfJNjGArFpagmCTDnKzWBYItEsqw(XkPfJNjGArFpagmCTDnKzWBYItEsRq)==0:return '검색결과 없음'
   for i in XkPfJNjGArFpagmCTDnKzWBYItEsqo(XkPfJNjGArFpagmCTDnKzWBYItEsqw(XkPfJNjGArFpagmCTDnKzWBYItEsRq)):
    if i>=XkPfJNjGArFpagmCTDnKzWBYItEsRQ:
     XkPfJNjGArFpagmCTDnKzWBYItEswU=XkPfJNjGArFpagmCTDnKzWBYItEswU+'...'
     break
    XkPfJNjGArFpagmCTDnKzWBYItEswU=XkPfJNjGArFpagmCTDnKzWBYItEswU+XkPfJNjGArFpagmCTDnKzWBYItEsRq[i]['title']+'\n'
  except:
   return ''
  return XkPfJNjGArFpagmCTDnKzWBYItEswU
 def dp_Search_History(XkPfJNjGArFpagmCTDnKzWBYItEsQl,XkPfJNjGArFpagmCTDnKzWBYItEsVd):
  XkPfJNjGArFpagmCTDnKzWBYItEsRi=XkPfJNjGArFpagmCTDnKzWBYItEsQl.Load_List_File('search')
  for XkPfJNjGArFpagmCTDnKzWBYItEsRV in XkPfJNjGArFpagmCTDnKzWBYItEsRi:
   XkPfJNjGArFpagmCTDnKzWBYItEsRL=XkPfJNjGArFpagmCTDnKzWBYItEsqi(urllib.parse.parse_qsl(XkPfJNjGArFpagmCTDnKzWBYItEsRV))
   XkPfJNjGArFpagmCTDnKzWBYItEsRw=XkPfJNjGArFpagmCTDnKzWBYItEsRL.get('skey').strip()
   XkPfJNjGArFpagmCTDnKzWBYItEsVi={'mode':'SEARCH_GROUP','search_key':XkPfJNjGArFpagmCTDnKzWBYItEsRw,}
   XkPfJNjGArFpagmCTDnKzWBYItEsRo={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':XkPfJNjGArFpagmCTDnKzWBYItEsRw,'vType':'-',}
   XkPfJNjGArFpagmCTDnKzWBYItEsRv=urllib.parse.urlencode(XkPfJNjGArFpagmCTDnKzWBYItEsRo)
   XkPfJNjGArFpagmCTDnKzWBYItEsLy=[('선택된 검색어 ( %s ) 삭제'%(XkPfJNjGArFpagmCTDnKzWBYItEsRw),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(XkPfJNjGArFpagmCTDnKzWBYItEsRv))]
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.add_dir(XkPfJNjGArFpagmCTDnKzWBYItEsRw,sublabel='',img=XkPfJNjGArFpagmCTDnKzWBYItEsvy,infoLabels=XkPfJNjGArFpagmCTDnKzWBYItEsvy,isFolder=XkPfJNjGArFpagmCTDnKzWBYItEsvc,params=XkPfJNjGArFpagmCTDnKzWBYItEsVi,ContextMenu=XkPfJNjGArFpagmCTDnKzWBYItEsLy)
  XkPfJNjGArFpagmCTDnKzWBYItEsLh={'plot':'검색목록 전체를 삭제합니다.'}
  XkPfJNjGArFpagmCTDnKzWBYItEsie='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  XkPfJNjGArFpagmCTDnKzWBYItEsVi={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  XkPfJNjGArFpagmCTDnKzWBYItEsVQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  XkPfJNjGArFpagmCTDnKzWBYItEsQl.add_dir(XkPfJNjGArFpagmCTDnKzWBYItEsie,sublabel='',img=XkPfJNjGArFpagmCTDnKzWBYItEsVQ,infoLabels=XkPfJNjGArFpagmCTDnKzWBYItEsLh,isFolder=XkPfJNjGArFpagmCTDnKzWBYItEsvU,params=XkPfJNjGArFpagmCTDnKzWBYItEsVi,isLink=XkPfJNjGArFpagmCTDnKzWBYItEsvc)
  xbmcplugin.endOfDirectory(XkPfJNjGArFpagmCTDnKzWBYItEsQl._addon_handle,cacheToDisc=XkPfJNjGArFpagmCTDnKzWBYItEsvU)
 def dp_Search_List(XkPfJNjGArFpagmCTDnKzWBYItEsQl,XkPfJNjGArFpagmCTDnKzWBYItEsVd):
  XkPfJNjGArFpagmCTDnKzWBYItEsVb =XkPfJNjGArFpagmCTDnKzWBYItEsvO(XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('page'))
  XkPfJNjGArFpagmCTDnKzWBYItEsVu =XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('stype')
  if 'search_key' in XkPfJNjGArFpagmCTDnKzWBYItEsVd:
   XkPfJNjGArFpagmCTDnKzWBYItEswy=XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('search_key')
  else:
   XkPfJNjGArFpagmCTDnKzWBYItEswy=XkPfJNjGArFpagmCTDnKzWBYItEsQl.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not XkPfJNjGArFpagmCTDnKzWBYItEswy:
    xbmcplugin.endOfDirectory(XkPfJNjGArFpagmCTDnKzWBYItEsQl._addon_handle)
    return
  XkPfJNjGArFpagmCTDnKzWBYItEswc,XkPfJNjGArFpagmCTDnKzWBYItEsVO=XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.GetSearchList(XkPfJNjGArFpagmCTDnKzWBYItEswy,XkPfJNjGArFpagmCTDnKzWBYItEsVb,XkPfJNjGArFpagmCTDnKzWBYItEsVu)
  for XkPfJNjGArFpagmCTDnKzWBYItEsRq in XkPfJNjGArFpagmCTDnKzWBYItEswc:
   XkPfJNjGArFpagmCTDnKzWBYItEsie =XkPfJNjGArFpagmCTDnKzWBYItEsRq.get('title')
   XkPfJNjGArFpagmCTDnKzWBYItEsVU =XkPfJNjGArFpagmCTDnKzWBYItEsRq.get('thumbnail')
   XkPfJNjGArFpagmCTDnKzWBYItEsLQ =XkPfJNjGArFpagmCTDnKzWBYItEsRq.get('synopsis')
   XkPfJNjGArFpagmCTDnKzWBYItEsRh =XkPfJNjGArFpagmCTDnKzWBYItEsRq.get('program')
   XkPfJNjGArFpagmCTDnKzWBYItEsLV =XkPfJNjGArFpagmCTDnKzWBYItEsRq.get('cast')
   XkPfJNjGArFpagmCTDnKzWBYItEsLw =XkPfJNjGArFpagmCTDnKzWBYItEsRq.get('director')
   XkPfJNjGArFpagmCTDnKzWBYItEsLR=XkPfJNjGArFpagmCTDnKzWBYItEsRq.get('info_genre')
   XkPfJNjGArFpagmCTDnKzWBYItEswx =XkPfJNjGArFpagmCTDnKzWBYItEsRq.get('duration')
   XkPfJNjGArFpagmCTDnKzWBYItEsLv =XkPfJNjGArFpagmCTDnKzWBYItEsRq.get('mpaa')
   XkPfJNjGArFpagmCTDnKzWBYItEsLo =XkPfJNjGArFpagmCTDnKzWBYItEsRq.get('year')
   XkPfJNjGArFpagmCTDnKzWBYItEswo =XkPfJNjGArFpagmCTDnKzWBYItEsRq.get('aired')
   XkPfJNjGArFpagmCTDnKzWBYItEsLh={'mediatype':'tvshow' if XkPfJNjGArFpagmCTDnKzWBYItEsVu=='vod' else 'movie','title':XkPfJNjGArFpagmCTDnKzWBYItEsie,'cast':XkPfJNjGArFpagmCTDnKzWBYItEsLV,'director':XkPfJNjGArFpagmCTDnKzWBYItEsLw,'genre':XkPfJNjGArFpagmCTDnKzWBYItEsLR,'duration':XkPfJNjGArFpagmCTDnKzWBYItEswx,'mpaa':XkPfJNjGArFpagmCTDnKzWBYItEsLv,'year':XkPfJNjGArFpagmCTDnKzWBYItEsLo,'aired':XkPfJNjGArFpagmCTDnKzWBYItEswo,'plot':'%s\n\n%s'%(XkPfJNjGArFpagmCTDnKzWBYItEsie,XkPfJNjGArFpagmCTDnKzWBYItEsLQ)}
   if XkPfJNjGArFpagmCTDnKzWBYItEsVu=='vod':
    XkPfJNjGArFpagmCTDnKzWBYItEswS=XkPfJNjGArFpagmCTDnKzWBYItEsRq.get('program')
    XkPfJNjGArFpagmCTDnKzWBYItEswu='tvshow'
    XkPfJNjGArFpagmCTDnKzWBYItEsVi={'mode':'EPISODE','programcode':XkPfJNjGArFpagmCTDnKzWBYItEswS,'page':'1',}
    XkPfJNjGArFpagmCTDnKzWBYItEsVL=XkPfJNjGArFpagmCTDnKzWBYItEsvc
   else:
    XkPfJNjGArFpagmCTDnKzWBYItEswS=XkPfJNjGArFpagmCTDnKzWBYItEsRq.get('movie')
    XkPfJNjGArFpagmCTDnKzWBYItEswu='movie'
    XkPfJNjGArFpagmCTDnKzWBYItEsVi={'mode':'MOVIE','mediacode':XkPfJNjGArFpagmCTDnKzWBYItEswS,'stype':'movie','title':XkPfJNjGArFpagmCTDnKzWBYItEsie,'thumbnail':XkPfJNjGArFpagmCTDnKzWBYItEsVU,}
    XkPfJNjGArFpagmCTDnKzWBYItEsVL=XkPfJNjGArFpagmCTDnKzWBYItEsvU
   if XkPfJNjGArFpagmCTDnKzWBYItEsQl.get_settings_makebookmark():
    XkPfJNjGArFpagmCTDnKzWBYItEsLH={'videoid':XkPfJNjGArFpagmCTDnKzWBYItEswS,'vidtype':XkPfJNjGArFpagmCTDnKzWBYItEswu,'vtitle':XkPfJNjGArFpagmCTDnKzWBYItEsie,'vsubtitle':'',}
    XkPfJNjGArFpagmCTDnKzWBYItEsLd=json.dumps(XkPfJNjGArFpagmCTDnKzWBYItEsLH)
    XkPfJNjGArFpagmCTDnKzWBYItEsLd=urllib.parse.quote(XkPfJNjGArFpagmCTDnKzWBYItEsLd)
    XkPfJNjGArFpagmCTDnKzWBYItEsLb='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(XkPfJNjGArFpagmCTDnKzWBYItEsLd)
    XkPfJNjGArFpagmCTDnKzWBYItEsLy=[('(통합) 찜 영상에 추가',XkPfJNjGArFpagmCTDnKzWBYItEsLb)]
   else:
    XkPfJNjGArFpagmCTDnKzWBYItEsLy=XkPfJNjGArFpagmCTDnKzWBYItEsvy
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.add_dir(XkPfJNjGArFpagmCTDnKzWBYItEsie,sublabel='',img=XkPfJNjGArFpagmCTDnKzWBYItEsVU,infoLabels=XkPfJNjGArFpagmCTDnKzWBYItEsLh,isFolder=XkPfJNjGArFpagmCTDnKzWBYItEsVL,params=XkPfJNjGArFpagmCTDnKzWBYItEsVi,isLink=XkPfJNjGArFpagmCTDnKzWBYItEsvU,ContextMenu=XkPfJNjGArFpagmCTDnKzWBYItEsLy)
  if XkPfJNjGArFpagmCTDnKzWBYItEsVO:
   XkPfJNjGArFpagmCTDnKzWBYItEsVi['mode'] ='SEARCH' 
   XkPfJNjGArFpagmCTDnKzWBYItEsVi['search_key']=XkPfJNjGArFpagmCTDnKzWBYItEswy
   XkPfJNjGArFpagmCTDnKzWBYItEsVi['page'] =XkPfJNjGArFpagmCTDnKzWBYItEsqR(XkPfJNjGArFpagmCTDnKzWBYItEsVb+1)
   XkPfJNjGArFpagmCTDnKzWBYItEsie='[B]%s >>[/B]'%'다음 페이지'
   XkPfJNjGArFpagmCTDnKzWBYItEsLM=XkPfJNjGArFpagmCTDnKzWBYItEsqR(XkPfJNjGArFpagmCTDnKzWBYItEsVb+1)
   XkPfJNjGArFpagmCTDnKzWBYItEsVQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.add_dir(XkPfJNjGArFpagmCTDnKzWBYItEsie,sublabel=XkPfJNjGArFpagmCTDnKzWBYItEsLM,img=XkPfJNjGArFpagmCTDnKzWBYItEsVQ,infoLabels=XkPfJNjGArFpagmCTDnKzWBYItEsvy,isFolder=XkPfJNjGArFpagmCTDnKzWBYItEsvc,params=XkPfJNjGArFpagmCTDnKzWBYItEsVi)
  if XkPfJNjGArFpagmCTDnKzWBYItEsVu=='movie':xbmcplugin.setContent(XkPfJNjGArFpagmCTDnKzWBYItEsQl._addon_handle,'movies')
  else:xbmcplugin.setContent(XkPfJNjGArFpagmCTDnKzWBYItEsQl._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(XkPfJNjGArFpagmCTDnKzWBYItEsQl._addon_handle,cacheToDisc=XkPfJNjGArFpagmCTDnKzWBYItEsvU)
 def dp_History_Remove(XkPfJNjGArFpagmCTDnKzWBYItEsQl,XkPfJNjGArFpagmCTDnKzWBYItEsVd):
  XkPfJNjGArFpagmCTDnKzWBYItEsRM=XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('delType')
  XkPfJNjGArFpagmCTDnKzWBYItEsRx =XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('sKey')
  XkPfJNjGArFpagmCTDnKzWBYItEsRl =XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('vType')
  XkPfJNjGArFpagmCTDnKzWBYItEsQd=xbmcgui.Dialog()
  if XkPfJNjGArFpagmCTDnKzWBYItEsRM=='SEARCH_ALL':
   XkPfJNjGArFpagmCTDnKzWBYItEsVx=XkPfJNjGArFpagmCTDnKzWBYItEsQd.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif XkPfJNjGArFpagmCTDnKzWBYItEsRM=='SEARCH_ONE':
   XkPfJNjGArFpagmCTDnKzWBYItEsVx=XkPfJNjGArFpagmCTDnKzWBYItEsQd.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif XkPfJNjGArFpagmCTDnKzWBYItEsRM=='WATCH_ALL':
   XkPfJNjGArFpagmCTDnKzWBYItEsVx=XkPfJNjGArFpagmCTDnKzWBYItEsQd.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif XkPfJNjGArFpagmCTDnKzWBYItEsRM=='WATCH_ONE':
   XkPfJNjGArFpagmCTDnKzWBYItEsVx=XkPfJNjGArFpagmCTDnKzWBYItEsQd.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if XkPfJNjGArFpagmCTDnKzWBYItEsVx==XkPfJNjGArFpagmCTDnKzWBYItEsvU:sys.exit()
  if XkPfJNjGArFpagmCTDnKzWBYItEsRM=='SEARCH_ALL':
   if os.path.isfile(XkPfJNjGArFpagmCTDnKzWBYItEsQx):os.remove(XkPfJNjGArFpagmCTDnKzWBYItEsQx)
  elif XkPfJNjGArFpagmCTDnKzWBYItEsRM=='SEARCH_ONE':
   try:
    XkPfJNjGArFpagmCTDnKzWBYItEsRS=XkPfJNjGArFpagmCTDnKzWBYItEsQx
    XkPfJNjGArFpagmCTDnKzWBYItEsRu=XkPfJNjGArFpagmCTDnKzWBYItEsQl.Load_List_File('search') 
    fp=XkPfJNjGArFpagmCTDnKzWBYItEsqv(XkPfJNjGArFpagmCTDnKzWBYItEsRS,'w',-1,'utf-8')
    for XkPfJNjGArFpagmCTDnKzWBYItEsRe in XkPfJNjGArFpagmCTDnKzWBYItEsRu:
     XkPfJNjGArFpagmCTDnKzWBYItEsRH=XkPfJNjGArFpagmCTDnKzWBYItEsqi(urllib.parse.parse_qsl(XkPfJNjGArFpagmCTDnKzWBYItEsRe))
     XkPfJNjGArFpagmCTDnKzWBYItEsRd=XkPfJNjGArFpagmCTDnKzWBYItEsRH.get('skey').strip()
     if XkPfJNjGArFpagmCTDnKzWBYItEsRx!=XkPfJNjGArFpagmCTDnKzWBYItEsRd:
      fp.write(XkPfJNjGArFpagmCTDnKzWBYItEsRe)
    fp.close()
   except:
    XkPfJNjGArFpagmCTDnKzWBYItEsvy
  elif XkPfJNjGArFpagmCTDnKzWBYItEsRM=='WATCH_ALL':
   XkPfJNjGArFpagmCTDnKzWBYItEsRS=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%XkPfJNjGArFpagmCTDnKzWBYItEsRl))
   if os.path.isfile(XkPfJNjGArFpagmCTDnKzWBYItEsRS):os.remove(XkPfJNjGArFpagmCTDnKzWBYItEsRS)
  elif XkPfJNjGArFpagmCTDnKzWBYItEsRM=='WATCH_ONE':
   XkPfJNjGArFpagmCTDnKzWBYItEsRS=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%XkPfJNjGArFpagmCTDnKzWBYItEsRl))
   try:
    XkPfJNjGArFpagmCTDnKzWBYItEsRu=XkPfJNjGArFpagmCTDnKzWBYItEsQl.Load_List_File(XkPfJNjGArFpagmCTDnKzWBYItEsRl) 
    fp=XkPfJNjGArFpagmCTDnKzWBYItEsqv(XkPfJNjGArFpagmCTDnKzWBYItEsRS,'w',-1,'utf-8')
    for XkPfJNjGArFpagmCTDnKzWBYItEsRe in XkPfJNjGArFpagmCTDnKzWBYItEsRu:
     XkPfJNjGArFpagmCTDnKzWBYItEsRH=XkPfJNjGArFpagmCTDnKzWBYItEsqi(urllib.parse.parse_qsl(XkPfJNjGArFpagmCTDnKzWBYItEsRe))
     XkPfJNjGArFpagmCTDnKzWBYItEsRd=XkPfJNjGArFpagmCTDnKzWBYItEsRH.get('code').strip()
     if XkPfJNjGArFpagmCTDnKzWBYItEsRx!=XkPfJNjGArFpagmCTDnKzWBYItEsRd:
      fp.write(XkPfJNjGArFpagmCTDnKzWBYItEsRe)
    fp.close()
   except:
    XkPfJNjGArFpagmCTDnKzWBYItEsvy
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(XkPfJNjGArFpagmCTDnKzWBYItEsQl,XkPfJNjGArFpagmCTDnKzWBYItEsVu): 
  try:
   if XkPfJNjGArFpagmCTDnKzWBYItEsVu=='search':
    XkPfJNjGArFpagmCTDnKzWBYItEsRS=XkPfJNjGArFpagmCTDnKzWBYItEsQx
   elif XkPfJNjGArFpagmCTDnKzWBYItEsVu in['vod','movie']:
    XkPfJNjGArFpagmCTDnKzWBYItEsRS=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%XkPfJNjGArFpagmCTDnKzWBYItEsVu))
   else:
    return[]
   fp=XkPfJNjGArFpagmCTDnKzWBYItEsqv(XkPfJNjGArFpagmCTDnKzWBYItEsRS,'r',-1,'utf-8')
   XkPfJNjGArFpagmCTDnKzWBYItEsRb=fp.readlines()
   fp.close()
  except:
   XkPfJNjGArFpagmCTDnKzWBYItEsRb=[]
  return XkPfJNjGArFpagmCTDnKzWBYItEsRb
 def Save_Watched_List(XkPfJNjGArFpagmCTDnKzWBYItEsQl,XkPfJNjGArFpagmCTDnKzWBYItEsVu,XkPfJNjGArFpagmCTDnKzWBYItEsQe):
  try:
   XkPfJNjGArFpagmCTDnKzWBYItEsRy=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%XkPfJNjGArFpagmCTDnKzWBYItEsVu))
   XkPfJNjGArFpagmCTDnKzWBYItEsRu=XkPfJNjGArFpagmCTDnKzWBYItEsQl.Load_List_File(XkPfJNjGArFpagmCTDnKzWBYItEsVu) 
   fp=XkPfJNjGArFpagmCTDnKzWBYItEsqv(XkPfJNjGArFpagmCTDnKzWBYItEsRy,'w',-1,'utf-8')
   XkPfJNjGArFpagmCTDnKzWBYItEsRO=urllib.parse.urlencode(XkPfJNjGArFpagmCTDnKzWBYItEsQe)
   XkPfJNjGArFpagmCTDnKzWBYItEsRO=XkPfJNjGArFpagmCTDnKzWBYItEsRO+'\n'
   fp.write(XkPfJNjGArFpagmCTDnKzWBYItEsRO)
   XkPfJNjGArFpagmCTDnKzWBYItEsRc=0
   for XkPfJNjGArFpagmCTDnKzWBYItEsRe in XkPfJNjGArFpagmCTDnKzWBYItEsRu:
    XkPfJNjGArFpagmCTDnKzWBYItEsRH=XkPfJNjGArFpagmCTDnKzWBYItEsqi(urllib.parse.parse_qsl(XkPfJNjGArFpagmCTDnKzWBYItEsRe))
    XkPfJNjGArFpagmCTDnKzWBYItEsRU=XkPfJNjGArFpagmCTDnKzWBYItEsQe.get('code').strip()
    XkPfJNjGArFpagmCTDnKzWBYItEsoQ=XkPfJNjGArFpagmCTDnKzWBYItEsRH.get('code').strip()
    if XkPfJNjGArFpagmCTDnKzWBYItEsVu=='vod' and XkPfJNjGArFpagmCTDnKzWBYItEsQl.get_settings_direct_replay()==XkPfJNjGArFpagmCTDnKzWBYItEsvc:
     XkPfJNjGArFpagmCTDnKzWBYItEsRU=XkPfJNjGArFpagmCTDnKzWBYItEsQe.get('videoid').strip()
     XkPfJNjGArFpagmCTDnKzWBYItEsoQ=XkPfJNjGArFpagmCTDnKzWBYItEsRH.get('videoid').strip()if XkPfJNjGArFpagmCTDnKzWBYItEsoQ!=XkPfJNjGArFpagmCTDnKzWBYItEsvy else '-'
    if XkPfJNjGArFpagmCTDnKzWBYItEsRU!=XkPfJNjGArFpagmCTDnKzWBYItEsoQ:
     fp.write(XkPfJNjGArFpagmCTDnKzWBYItEsRe)
     XkPfJNjGArFpagmCTDnKzWBYItEsRc+=1
     if XkPfJNjGArFpagmCTDnKzWBYItEsRc>=50:break
   fp.close()
  except:
   XkPfJNjGArFpagmCTDnKzWBYItEsvy
 def dp_Watch_List(XkPfJNjGArFpagmCTDnKzWBYItEsQl,XkPfJNjGArFpagmCTDnKzWBYItEsVd):
  XkPfJNjGArFpagmCTDnKzWBYItEsVu =XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('stype')
  XkPfJNjGArFpagmCTDnKzWBYItEsix=XkPfJNjGArFpagmCTDnKzWBYItEsQl.get_settings_direct_replay()
  if XkPfJNjGArFpagmCTDnKzWBYItEsVu=='-':
   for XkPfJNjGArFpagmCTDnKzWBYItEsVH in XkPfJNjGArFpagmCTDnKzWBYItEsQw:
    XkPfJNjGArFpagmCTDnKzWBYItEsie=XkPfJNjGArFpagmCTDnKzWBYItEsVH.get('title')
    XkPfJNjGArFpagmCTDnKzWBYItEsVi={'mode':XkPfJNjGArFpagmCTDnKzWBYItEsVH.get('mode'),'stype':XkPfJNjGArFpagmCTDnKzWBYItEsVH.get('stype')}
    XkPfJNjGArFpagmCTDnKzWBYItEsQl.add_dir(XkPfJNjGArFpagmCTDnKzWBYItEsie,sublabel='',img='',infoLabels=XkPfJNjGArFpagmCTDnKzWBYItEsvy,isFolder=XkPfJNjGArFpagmCTDnKzWBYItEsvc,params=XkPfJNjGArFpagmCTDnKzWBYItEsVi)
   if XkPfJNjGArFpagmCTDnKzWBYItEsqw(XkPfJNjGArFpagmCTDnKzWBYItEsQw)>0:xbmcplugin.endOfDirectory(XkPfJNjGArFpagmCTDnKzWBYItEsQl._addon_handle)
  else:
   XkPfJNjGArFpagmCTDnKzWBYItEsoi=XkPfJNjGArFpagmCTDnKzWBYItEsQl.Load_List_File(XkPfJNjGArFpagmCTDnKzWBYItEsVu)
   for XkPfJNjGArFpagmCTDnKzWBYItEsoV in XkPfJNjGArFpagmCTDnKzWBYItEsoi:
    XkPfJNjGArFpagmCTDnKzWBYItEsRL=XkPfJNjGArFpagmCTDnKzWBYItEsqi(urllib.parse.parse_qsl(XkPfJNjGArFpagmCTDnKzWBYItEsoV))
    XkPfJNjGArFpagmCTDnKzWBYItEsoL =XkPfJNjGArFpagmCTDnKzWBYItEsRL.get('code').strip()
    XkPfJNjGArFpagmCTDnKzWBYItEsie =XkPfJNjGArFpagmCTDnKzWBYItEsRL.get('title').strip()
    XkPfJNjGArFpagmCTDnKzWBYItEsVU=XkPfJNjGArFpagmCTDnKzWBYItEsRL.get('img').strip()
    XkPfJNjGArFpagmCTDnKzWBYItEswS =XkPfJNjGArFpagmCTDnKzWBYItEsRL.get('videoid').strip()
    try:
     XkPfJNjGArFpagmCTDnKzWBYItEsVU=XkPfJNjGArFpagmCTDnKzWBYItEsVU.replace('\'','\"')
     XkPfJNjGArFpagmCTDnKzWBYItEsVU=json.loads(XkPfJNjGArFpagmCTDnKzWBYItEsVU)
    except:
     XkPfJNjGArFpagmCTDnKzWBYItEsvy
    XkPfJNjGArFpagmCTDnKzWBYItEsLh={}
    XkPfJNjGArFpagmCTDnKzWBYItEsLh['plot']=XkPfJNjGArFpagmCTDnKzWBYItEsie
    if XkPfJNjGArFpagmCTDnKzWBYItEsVu=='vod':
     if XkPfJNjGArFpagmCTDnKzWBYItEsix==XkPfJNjGArFpagmCTDnKzWBYItEsvU or XkPfJNjGArFpagmCTDnKzWBYItEswS==XkPfJNjGArFpagmCTDnKzWBYItEsvy:
      XkPfJNjGArFpagmCTDnKzWBYItEsLh['mediatype']='tvshow'
      XkPfJNjGArFpagmCTDnKzWBYItEsVi={'mode':'EPISODE','programcode':XkPfJNjGArFpagmCTDnKzWBYItEsoL,'page':'1'}
      XkPfJNjGArFpagmCTDnKzWBYItEsVL=XkPfJNjGArFpagmCTDnKzWBYItEsvc
     else:
      XkPfJNjGArFpagmCTDnKzWBYItEsLh['mediatype']='episode'
      XkPfJNjGArFpagmCTDnKzWBYItEsVi={'mode':'VOD','mediacode':XkPfJNjGArFpagmCTDnKzWBYItEswS,'stype':'vod','programcode':XkPfJNjGArFpagmCTDnKzWBYItEsoL,'title':XkPfJNjGArFpagmCTDnKzWBYItEsie,'thumbnail':XkPfJNjGArFpagmCTDnKzWBYItEsVU}
      XkPfJNjGArFpagmCTDnKzWBYItEsVL=XkPfJNjGArFpagmCTDnKzWBYItEsvU
    else:
     XkPfJNjGArFpagmCTDnKzWBYItEsLh['mediatype']='movie'
     XkPfJNjGArFpagmCTDnKzWBYItEsVi={'mode':'MOVIE','mediacode':XkPfJNjGArFpagmCTDnKzWBYItEsoL,'stype':'movie','title':XkPfJNjGArFpagmCTDnKzWBYItEsie,'thumbnail':XkPfJNjGArFpagmCTDnKzWBYItEsVU}
     XkPfJNjGArFpagmCTDnKzWBYItEsVL=XkPfJNjGArFpagmCTDnKzWBYItEsvU
    XkPfJNjGArFpagmCTDnKzWBYItEsRo={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':XkPfJNjGArFpagmCTDnKzWBYItEsoL,'vType':XkPfJNjGArFpagmCTDnKzWBYItEsVu,}
    XkPfJNjGArFpagmCTDnKzWBYItEsRv=urllib.parse.urlencode(XkPfJNjGArFpagmCTDnKzWBYItEsRo)
    XkPfJNjGArFpagmCTDnKzWBYItEsLy=[('선택된 시청이력 ( %s ) 삭제'%(XkPfJNjGArFpagmCTDnKzWBYItEsie),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(XkPfJNjGArFpagmCTDnKzWBYItEsRv))]
    XkPfJNjGArFpagmCTDnKzWBYItEsQl.add_dir(XkPfJNjGArFpagmCTDnKzWBYItEsie,sublabel='',img=XkPfJNjGArFpagmCTDnKzWBYItEsVU,infoLabels=XkPfJNjGArFpagmCTDnKzWBYItEsLh,isFolder=XkPfJNjGArFpagmCTDnKzWBYItEsVL,params=XkPfJNjGArFpagmCTDnKzWBYItEsVi,ContextMenu=XkPfJNjGArFpagmCTDnKzWBYItEsLy)
   XkPfJNjGArFpagmCTDnKzWBYItEsLh={'plot':'시청목록을 삭제합니다.'}
   XkPfJNjGArFpagmCTDnKzWBYItEsie='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   XkPfJNjGArFpagmCTDnKzWBYItEsVi={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':XkPfJNjGArFpagmCTDnKzWBYItEsVu,}
   XkPfJNjGArFpagmCTDnKzWBYItEsVQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.add_dir(XkPfJNjGArFpagmCTDnKzWBYItEsie,sublabel='',img=XkPfJNjGArFpagmCTDnKzWBYItEsVQ,infoLabels=XkPfJNjGArFpagmCTDnKzWBYItEsLh,isFolder=XkPfJNjGArFpagmCTDnKzWBYItEsvU,params=XkPfJNjGArFpagmCTDnKzWBYItEsVi,isLink=XkPfJNjGArFpagmCTDnKzWBYItEsvc)
   if XkPfJNjGArFpagmCTDnKzWBYItEsVu=='movie':xbmcplugin.setContent(XkPfJNjGArFpagmCTDnKzWBYItEsQl._addon_handle,'movies')
   else:xbmcplugin.setContent(XkPfJNjGArFpagmCTDnKzWBYItEsQl._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(XkPfJNjGArFpagmCTDnKzWBYItEsQl._addon_handle,cacheToDisc=XkPfJNjGArFpagmCTDnKzWBYItEsvU)
 def Save_Searched_List(XkPfJNjGArFpagmCTDnKzWBYItEsQl,XkPfJNjGArFpagmCTDnKzWBYItEswy):
  try:
   XkPfJNjGArFpagmCTDnKzWBYItEsow=XkPfJNjGArFpagmCTDnKzWBYItEsQx
   XkPfJNjGArFpagmCTDnKzWBYItEsRu=XkPfJNjGArFpagmCTDnKzWBYItEsQl.Load_List_File('search') 
   XkPfJNjGArFpagmCTDnKzWBYItEsoR={'skey':XkPfJNjGArFpagmCTDnKzWBYItEswy.strip()}
   fp=XkPfJNjGArFpagmCTDnKzWBYItEsqv(XkPfJNjGArFpagmCTDnKzWBYItEsow,'w',-1,'utf-8')
   XkPfJNjGArFpagmCTDnKzWBYItEsRO=urllib.parse.urlencode(XkPfJNjGArFpagmCTDnKzWBYItEsoR)
   XkPfJNjGArFpagmCTDnKzWBYItEsRO=XkPfJNjGArFpagmCTDnKzWBYItEsRO+'\n'
   fp.write(XkPfJNjGArFpagmCTDnKzWBYItEsRO)
   XkPfJNjGArFpagmCTDnKzWBYItEsRc=0
   for XkPfJNjGArFpagmCTDnKzWBYItEsRe in XkPfJNjGArFpagmCTDnKzWBYItEsRu:
    XkPfJNjGArFpagmCTDnKzWBYItEsRH=XkPfJNjGArFpagmCTDnKzWBYItEsqi(urllib.parse.parse_qsl(XkPfJNjGArFpagmCTDnKzWBYItEsRe))
    XkPfJNjGArFpagmCTDnKzWBYItEsRU=XkPfJNjGArFpagmCTDnKzWBYItEsoR.get('skey').strip()
    XkPfJNjGArFpagmCTDnKzWBYItEsoQ=XkPfJNjGArFpagmCTDnKzWBYItEsRH.get('skey').strip()
    if XkPfJNjGArFpagmCTDnKzWBYItEsRU!=XkPfJNjGArFpagmCTDnKzWBYItEsoQ:
     fp.write(XkPfJNjGArFpagmCTDnKzWBYItEsRe)
     XkPfJNjGArFpagmCTDnKzWBYItEsRc+=1
     if XkPfJNjGArFpagmCTDnKzWBYItEsRc>=50:break
   fp.close()
  except:
   XkPfJNjGArFpagmCTDnKzWBYItEsvy
 def play_VIDEO(XkPfJNjGArFpagmCTDnKzWBYItEsQl,XkPfJNjGArFpagmCTDnKzWBYItEsVd):
  XkPfJNjGArFpagmCTDnKzWBYItEsov =XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('mediacode')
  XkPfJNjGArFpagmCTDnKzWBYItEsVu =XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('stype')
  XkPfJNjGArFpagmCTDnKzWBYItEsoq =XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('pvrmode')
  XkPfJNjGArFpagmCTDnKzWBYItEsoh=XkPfJNjGArFpagmCTDnKzWBYItEsQl.get_selQuality(XkPfJNjGArFpagmCTDnKzWBYItEsVu)
  XkPfJNjGArFpagmCTDnKzWBYItEsQl.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(XkPfJNjGArFpagmCTDnKzWBYItEsov,XkPfJNjGArFpagmCTDnKzWBYItEsqR(XkPfJNjGArFpagmCTDnKzWBYItEsoh),XkPfJNjGArFpagmCTDnKzWBYItEsVu,XkPfJNjGArFpagmCTDnKzWBYItEsoq))
  XkPfJNjGArFpagmCTDnKzWBYItEsoM=XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.GetBroadURL(XkPfJNjGArFpagmCTDnKzWBYItEsov,XkPfJNjGArFpagmCTDnKzWBYItEsoh,XkPfJNjGArFpagmCTDnKzWBYItEsVu,XkPfJNjGArFpagmCTDnKzWBYItEsoq,optUHD=XkPfJNjGArFpagmCTDnKzWBYItEsQl.get_settings_uhd())
  XkPfJNjGArFpagmCTDnKzWBYItEsQl.addon_log('qt, stype, url : %s - %s - %s'%(XkPfJNjGArFpagmCTDnKzWBYItEsqR(XkPfJNjGArFpagmCTDnKzWBYItEsoh),XkPfJNjGArFpagmCTDnKzWBYItEsVu,XkPfJNjGArFpagmCTDnKzWBYItEsoM['streaming_url']))
  if XkPfJNjGArFpagmCTDnKzWBYItEsoM['streaming_url']=='':
   if XkPfJNjGArFpagmCTDnKzWBYItEsoM['error_msg']=='':
    XkPfJNjGArFpagmCTDnKzWBYItEsQl.addon_noti(__language__(30908).encode('utf8'))
   else:
    XkPfJNjGArFpagmCTDnKzWBYItEsQl.addon_noti(XkPfJNjGArFpagmCTDnKzWBYItEsoM['error_msg'].encode('utf8'))
   return
  XkPfJNjGArFpagmCTDnKzWBYItEsox={'user-agent':XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.USER_AGENT}
  XkPfJNjGArFpagmCTDnKzWBYItEsol=XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.makeDefaultCookies() 
  if XkPfJNjGArFpagmCTDnKzWBYItEsoM['drm_server_url'] !='':
   XkPfJNjGArFpagmCTDnKzWBYItEsox[XkPfJNjGArFpagmCTDnKzWBYItEsoM['drm_header_key']]=XkPfJNjGArFpagmCTDnKzWBYItEsoM['drm_header_value']
  XkPfJNjGArFpagmCTDnKzWBYItEsoS =XkPfJNjGArFpagmCTDnKzWBYItEsvU
  XkPfJNjGArFpagmCTDnKzWBYItEsou =XkPfJNjGArFpagmCTDnKzWBYItEsoM['streaming_url'].find('Policy=')
  if XkPfJNjGArFpagmCTDnKzWBYItEsou!=-1:
   XkPfJNjGArFpagmCTDnKzWBYItEsoe =XkPfJNjGArFpagmCTDnKzWBYItEsoM['streaming_url'].split('?')[0]
   XkPfJNjGArFpagmCTDnKzWBYItEsoH=XkPfJNjGArFpagmCTDnKzWBYItEsqi(urllib.parse.parse_qsl(urllib.parse.urlsplit(XkPfJNjGArFpagmCTDnKzWBYItEsoM['streaming_url']).query))
   XkPfJNjGArFpagmCTDnKzWBYItEsol['CloudFront-Policy'] =XkPfJNjGArFpagmCTDnKzWBYItEsoH['Policy'] 
   XkPfJNjGArFpagmCTDnKzWBYItEsol['CloudFront-Signature'] =XkPfJNjGArFpagmCTDnKzWBYItEsoH['Signature'] 
   XkPfJNjGArFpagmCTDnKzWBYItEsol['CloudFront-Key-Pair-Id']=XkPfJNjGArFpagmCTDnKzWBYItEsoH['Key-Pair-Id'] 
   XkPfJNjGArFpagmCTDnKzWBYItEsod=XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.make_stream_header(XkPfJNjGArFpagmCTDnKzWBYItEsox,XkPfJNjGArFpagmCTDnKzWBYItEsol)
   if 'quickvod-mcdn.tving.com' in XkPfJNjGArFpagmCTDnKzWBYItEsoe:
    XkPfJNjGArFpagmCTDnKzWBYItEsoS=XkPfJNjGArFpagmCTDnKzWBYItEsvc
    XkPfJNjGArFpagmCTDnKzWBYItEsob =XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    XkPfJNjGArFpagmCTDnKzWBYItEsoy=XkPfJNjGArFpagmCTDnKzWBYItEsob.strftime('%Y-%m-%d-%H:%M:%S')
    if XkPfJNjGArFpagmCTDnKzWBYItEsvO(XkPfJNjGArFpagmCTDnKzWBYItEsoy.replace('-','').replace(':',''))<XkPfJNjGArFpagmCTDnKzWBYItEsvO(XkPfJNjGArFpagmCTDnKzWBYItEsoH['end'].replace('-','').replace(':','')):
     XkPfJNjGArFpagmCTDnKzWBYItEsoH['end']=XkPfJNjGArFpagmCTDnKzWBYItEsoy
     XkPfJNjGArFpagmCTDnKzWBYItEsQl.addon_noti(__language__(30915).encode('utf8'))
    XkPfJNjGArFpagmCTDnKzWBYItEsoe ='%s?%s'%(XkPfJNjGArFpagmCTDnKzWBYItEsoe,urllib.parse.urlencode(XkPfJNjGArFpagmCTDnKzWBYItEsoH,doseq=XkPfJNjGArFpagmCTDnKzWBYItEsvc))
    XkPfJNjGArFpagmCTDnKzWBYItEsoO='{}|{}'.format(XkPfJNjGArFpagmCTDnKzWBYItEsoe,XkPfJNjGArFpagmCTDnKzWBYItEsod)
   else:
    XkPfJNjGArFpagmCTDnKzWBYItEsoO='{}|{}'.format(XkPfJNjGArFpagmCTDnKzWBYItEsoM['streaming_url'],XkPfJNjGArFpagmCTDnKzWBYItEsod)
  else:
   XkPfJNjGArFpagmCTDnKzWBYItEsod=XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.make_stream_header(XkPfJNjGArFpagmCTDnKzWBYItEsox,XkPfJNjGArFpagmCTDnKzWBYItEsol)
   XkPfJNjGArFpagmCTDnKzWBYItEsoO='{}|{}'.format(XkPfJNjGArFpagmCTDnKzWBYItEsoM['streaming_url'],XkPfJNjGArFpagmCTDnKzWBYItEsod)
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.addon_log('if tmp_pos == -1')
  XkPfJNjGArFpagmCTDnKzWBYItEsiw,XkPfJNjGArFpagmCTDnKzWBYItEsiR=XkPfJNjGArFpagmCTDnKzWBYItEsQl.get_settings_proxyport()
  XkPfJNjGArFpagmCTDnKzWBYItEsiL=XkPfJNjGArFpagmCTDnKzWBYItEsQl.get_settings_playback()
  if(XkPfJNjGArFpagmCTDnKzWBYItEsiw and XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('mode')in['VOD','MOVIE']and XkPfJNjGArFpagmCTDnKzWBYItEsoS==XkPfJNjGArFpagmCTDnKzWBYItEsvU and(XkPfJNjGArFpagmCTDnKzWBYItEsoM['drm_server_url']!='' or XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.KodiVersion>=21)):
   if XkPfJNjGArFpagmCTDnKzWBYItEsoM['url_filename'].split('.')[1]=='mpd':
    XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.Tving_Parse_mpd(XkPfJNjGArFpagmCTDnKzWBYItEsoM['streaming_url'])
   else:
    XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.Tving_Parse_m3u8(XkPfJNjGArFpagmCTDnKzWBYItEsoM['streaming_url'])
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.addon_log('xxx '+XkPfJNjGArFpagmCTDnKzWBYItEsoM['streaming_url'])
   XkPfJNjGArFpagmCTDnKzWBYItEsoc={'addon':'tvingm','playOption':XkPfJNjGArFpagmCTDnKzWBYItEsiL,'url_filename':XkPfJNjGArFpagmCTDnKzWBYItEsoM['url_filename'],}
   XkPfJNjGArFpagmCTDnKzWBYItEsoc=json.dumps(XkPfJNjGArFpagmCTDnKzWBYItEsoc,separators=(',',':'))
   XkPfJNjGArFpagmCTDnKzWBYItEsoc=base64.standard_b64encode(XkPfJNjGArFpagmCTDnKzWBYItEsoc.encode()).decode('utf-8')
   XkPfJNjGArFpagmCTDnKzWBYItEsoO ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(XkPfJNjGArFpagmCTDnKzWBYItEsiR,XkPfJNjGArFpagmCTDnKzWBYItEsoO,XkPfJNjGArFpagmCTDnKzWBYItEsoc)
   XkPfJNjGArFpagmCTDnKzWBYItEsox['proxy-mini']=XkPfJNjGArFpagmCTDnKzWBYItEsoc 
  XkPfJNjGArFpagmCTDnKzWBYItEsQl.addon_log('surl(2) : {}'.format(XkPfJNjGArFpagmCTDnKzWBYItEsoO))
  XkPfJNjGArFpagmCTDnKzWBYItEsod=XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.make_stream_header(XkPfJNjGArFpagmCTDnKzWBYItEsox,XkPfJNjGArFpagmCTDnKzWBYItEsol)
  XkPfJNjGArFpagmCTDnKzWBYItEsoU=xbmcgui.ListItem(path=XkPfJNjGArFpagmCTDnKzWBYItEsoO)
  if XkPfJNjGArFpagmCTDnKzWBYItEsoM['drm_server_url']!='':
   XkPfJNjGArFpagmCTDnKzWBYItEsvQ=XkPfJNjGArFpagmCTDnKzWBYItEsoM['drm_server_url']
   XkPfJNjGArFpagmCTDnKzWBYItEsvi ='https://license-global.pallycon.com/ri/licenseManager.do' 
   XkPfJNjGArFpagmCTDnKzWBYItEsvV ='mpd'
   XkPfJNjGArFpagmCTDnKzWBYItEsvL ='com.widevine.alpha'
   XkPfJNjGArFpagmCTDnKzWBYItEsvw={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.USER_AGENT,XkPfJNjGArFpagmCTDnKzWBYItEsoM['drm_header_key']:XkPfJNjGArFpagmCTDnKzWBYItEsoM['drm_header_value'],}
   XkPfJNjGArFpagmCTDnKzWBYItEsvR=XkPfJNjGArFpagmCTDnKzWBYItEsvi+'|'+urllib.parse.urlencode(XkPfJNjGArFpagmCTDnKzWBYItEsvw)+'|R{SSM}|'
   XkPfJNjGArFpagmCTDnKzWBYItEsoU.setProperty('inputstream','inputstream.adaptive')
   if XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.KodiVersion<=20:
    XkPfJNjGArFpagmCTDnKzWBYItEsoU.setProperty('inputstream.adaptive.manifest_type',XkPfJNjGArFpagmCTDnKzWBYItEsvV)
   XkPfJNjGArFpagmCTDnKzWBYItEsoU.setProperty('inputstream.adaptive.license_type',XkPfJNjGArFpagmCTDnKzWBYItEsvL)
   XkPfJNjGArFpagmCTDnKzWBYItEsoU.setProperty('inputstream.adaptive.license_key',XkPfJNjGArFpagmCTDnKzWBYItEsvR)
   XkPfJNjGArFpagmCTDnKzWBYItEsoU.setProperty('inputstream.adaptive.stream_headers',XkPfJNjGArFpagmCTDnKzWBYItEsod)
   XkPfJNjGArFpagmCTDnKzWBYItEsoU.setProperty('inputstream.adaptive.manifest_headers',XkPfJNjGArFpagmCTDnKzWBYItEsod)
  elif XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('mode')in['VOD','MOVIE']:
   XkPfJNjGArFpagmCTDnKzWBYItEsoU.setContentLookup(XkPfJNjGArFpagmCTDnKzWBYItEsvU)
   XkPfJNjGArFpagmCTDnKzWBYItEsoU.setMimeType('application/x-mpegURL')
   XkPfJNjGArFpagmCTDnKzWBYItEsoU.setProperty('inputstream','inputstream.adaptive')
   if XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.KodiVersion<=20:
    XkPfJNjGArFpagmCTDnKzWBYItEsoU.setProperty('inputstream.adaptive.manifest_type','hls')
   XkPfJNjGArFpagmCTDnKzWBYItEsoU.setProperty('inputstream.adaptive.stream_headers',XkPfJNjGArFpagmCTDnKzWBYItEsod)
   XkPfJNjGArFpagmCTDnKzWBYItEsoU.setProperty('inputstream.adaptive.manifest_headers',XkPfJNjGArFpagmCTDnKzWBYItEsod)
  elif XkPfJNjGArFpagmCTDnKzWBYItEsoS==XkPfJNjGArFpagmCTDnKzWBYItEsvc:
   XkPfJNjGArFpagmCTDnKzWBYItEsoU.setContentLookup(XkPfJNjGArFpagmCTDnKzWBYItEsvU)
   XkPfJNjGArFpagmCTDnKzWBYItEsoU.setMimeType('application/x-mpegURL')
   XkPfJNjGArFpagmCTDnKzWBYItEsoU.setProperty('inputstream','inputstream.ffmpegdirect')
   XkPfJNjGArFpagmCTDnKzWBYItEsoU.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   XkPfJNjGArFpagmCTDnKzWBYItEsoU.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   XkPfJNjGArFpagmCTDnKzWBYItEsoU.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   XkPfJNjGArFpagmCTDnKzWBYItEsoU.setProperty('ResumeTime','0')
   XkPfJNjGArFpagmCTDnKzWBYItEsoU.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(XkPfJNjGArFpagmCTDnKzWBYItEsQl._addon_handle,XkPfJNjGArFpagmCTDnKzWBYItEsvc,XkPfJNjGArFpagmCTDnKzWBYItEsoU)
  try:
   if XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('mode')in['VOD','MOVIE']and XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('title'):
    XkPfJNjGArFpagmCTDnKzWBYItEsVi={'code':XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('programcode')if XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('mode')=='VOD' else XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('mediacode'),'img':XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('thumbnail'),'title':XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('title'),'videoid':XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('mediacode')}
    XkPfJNjGArFpagmCTDnKzWBYItEsQl.Save_Watched_List(XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('stype'),XkPfJNjGArFpagmCTDnKzWBYItEsVi)
  except:
   XkPfJNjGArFpagmCTDnKzWBYItEsvy
 def logout(XkPfJNjGArFpagmCTDnKzWBYItEsQl):
  XkPfJNjGArFpagmCTDnKzWBYItEsQd=xbmcgui.Dialog()
  XkPfJNjGArFpagmCTDnKzWBYItEsVx=XkPfJNjGArFpagmCTDnKzWBYItEsQd.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if XkPfJNjGArFpagmCTDnKzWBYItEsVx==XkPfJNjGArFpagmCTDnKzWBYItEsvU:sys.exit()
  XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.Init_TV_Total()
  if os.path.isfile(XkPfJNjGArFpagmCTDnKzWBYItEsQM):os.remove(XkPfJNjGArFpagmCTDnKzWBYItEsQM)
  XkPfJNjGArFpagmCTDnKzWBYItEsQl.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(XkPfJNjGArFpagmCTDnKzWBYItEsQl):
  XkPfJNjGArFpagmCTDnKzWBYItEsvo =XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.Get_Now_Datetime()
  XkPfJNjGArFpagmCTDnKzWBYItEsvq=XkPfJNjGArFpagmCTDnKzWBYItEsvo+datetime.timedelta(days=XkPfJNjGArFpagmCTDnKzWBYItEsvO(__addon__.getSetting('cache_ttl')))
  (XkPfJNjGArFpagmCTDnKzWBYItEsVv,XkPfJNjGArFpagmCTDnKzWBYItEsVq,XkPfJNjGArFpagmCTDnKzWBYItEsVh,XkPfJNjGArFpagmCTDnKzWBYItEsVM)=XkPfJNjGArFpagmCTDnKzWBYItEsQl.get_settings_account()
  XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.Save_session_acount(XkPfJNjGArFpagmCTDnKzWBYItEsVv,XkPfJNjGArFpagmCTDnKzWBYItEsVq,XkPfJNjGArFpagmCTDnKzWBYItEsVh,XkPfJNjGArFpagmCTDnKzWBYItEsVM)
  XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.TV['account']['token_limit']=XkPfJNjGArFpagmCTDnKzWBYItEsvq.strftime('%Y%m%d')
  XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.JsonFile_Save(XkPfJNjGArFpagmCTDnKzWBYItEsQM,XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.TV)
 def cookiefile_check(XkPfJNjGArFpagmCTDnKzWBYItEsQl):
  XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.TV=XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.JsonFile_Load(XkPfJNjGArFpagmCTDnKzWBYItEsQM)
  if XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.TV=={}:
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.Init_TV_Total()
   return XkPfJNjGArFpagmCTDnKzWBYItEsvU
  if '_tving_token' not in XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.TV.get('cookies'):
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.Init_TV_Total()
   return XkPfJNjGArFpagmCTDnKzWBYItEsvU
  (XkPfJNjGArFpagmCTDnKzWBYItEsvh,XkPfJNjGArFpagmCTDnKzWBYItEsvM,XkPfJNjGArFpagmCTDnKzWBYItEsvx,XkPfJNjGArFpagmCTDnKzWBYItEsvl)=XkPfJNjGArFpagmCTDnKzWBYItEsQl.get_settings_account()
  (XkPfJNjGArFpagmCTDnKzWBYItEsvS,XkPfJNjGArFpagmCTDnKzWBYItEsvu,XkPfJNjGArFpagmCTDnKzWBYItEsve,XkPfJNjGArFpagmCTDnKzWBYItEsvH)=XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.Load_session_acount()
  if XkPfJNjGArFpagmCTDnKzWBYItEsvh!=XkPfJNjGArFpagmCTDnKzWBYItEsvS or XkPfJNjGArFpagmCTDnKzWBYItEsvM!=XkPfJNjGArFpagmCTDnKzWBYItEsvu or XkPfJNjGArFpagmCTDnKzWBYItEsvx!=XkPfJNjGArFpagmCTDnKzWBYItEsve or XkPfJNjGArFpagmCTDnKzWBYItEsvl!=XkPfJNjGArFpagmCTDnKzWBYItEsvH:
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.Init_TV_Total()
   return XkPfJNjGArFpagmCTDnKzWBYItEsvU
  if XkPfJNjGArFpagmCTDnKzWBYItEsvO(XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>XkPfJNjGArFpagmCTDnKzWBYItEsvO(XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.TV['account']['token_limit']):
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.Init_TV_Total()
   return XkPfJNjGArFpagmCTDnKzWBYItEsvU
  return XkPfJNjGArFpagmCTDnKzWBYItEsvc
 def dp_Global_Search(XkPfJNjGArFpagmCTDnKzWBYItEsQl,XkPfJNjGArFpagmCTDnKzWBYItEsVd):
  XkPfJNjGArFpagmCTDnKzWBYItEswO=XkPfJNjGArFpagmCTDnKzWBYItEsVd.get('mode')
  if XkPfJNjGArFpagmCTDnKzWBYItEswO=='TOTAL_SEARCH':
   XkPfJNjGArFpagmCTDnKzWBYItEsvd='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   XkPfJNjGArFpagmCTDnKzWBYItEsvd='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(XkPfJNjGArFpagmCTDnKzWBYItEsvd)
 def dp_Bookmark_Menu(XkPfJNjGArFpagmCTDnKzWBYItEsQl,XkPfJNjGArFpagmCTDnKzWBYItEsVd):
  XkPfJNjGArFpagmCTDnKzWBYItEsvd='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(XkPfJNjGArFpagmCTDnKzWBYItEsvd)
 def dp_EuroLive_List(XkPfJNjGArFpagmCTDnKzWBYItEsQl,XkPfJNjGArFpagmCTDnKzWBYItEsVd):
  XkPfJNjGArFpagmCTDnKzWBYItEsVy=XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.GetEuroChannelList()
  for XkPfJNjGArFpagmCTDnKzWBYItEsVc in XkPfJNjGArFpagmCTDnKzWBYItEsVy:
   XkPfJNjGArFpagmCTDnKzWBYItEsLe =XkPfJNjGArFpagmCTDnKzWBYItEsVc.get('channel')
   XkPfJNjGArFpagmCTDnKzWBYItEsie =XkPfJNjGArFpagmCTDnKzWBYItEsVc.get('title')
   XkPfJNjGArFpagmCTDnKzWBYItEsLM =XkPfJNjGArFpagmCTDnKzWBYItEsVc.get('subtitle')
   XkPfJNjGArFpagmCTDnKzWBYItEsLh={'mediatype':'episode','title':XkPfJNjGArFpagmCTDnKzWBYItEsie,'plot':'%s\n%s'%(XkPfJNjGArFpagmCTDnKzWBYItEsie,XkPfJNjGArFpagmCTDnKzWBYItEsLM)}
   XkPfJNjGArFpagmCTDnKzWBYItEsVi={'mode':'LIVE','mediacode':XkPfJNjGArFpagmCTDnKzWBYItEsLe,'stype':'onair',}
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.add_dir(XkPfJNjGArFpagmCTDnKzWBYItEsie,sublabel=XkPfJNjGArFpagmCTDnKzWBYItEsLM,img='',infoLabels=XkPfJNjGArFpagmCTDnKzWBYItEsLh,isFolder=XkPfJNjGArFpagmCTDnKzWBYItEsvU,params=XkPfJNjGArFpagmCTDnKzWBYItEsVi)
  if XkPfJNjGArFpagmCTDnKzWBYItEsqw(XkPfJNjGArFpagmCTDnKzWBYItEsVy)>0:xbmcplugin.endOfDirectory(XkPfJNjGArFpagmCTDnKzWBYItEsQl._addon_handle,cacheToDisc=XkPfJNjGArFpagmCTDnKzWBYItEsvU)
 def tving_main(XkPfJNjGArFpagmCTDnKzWBYItEsQl):
  XkPfJNjGArFpagmCTDnKzWBYItEsQl.TvingObj.KodiVersion=XkPfJNjGArFpagmCTDnKzWBYItEsvO(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  XkPfJNjGArFpagmCTDnKzWBYItEswO=XkPfJNjGArFpagmCTDnKzWBYItEsQl.main_params.get('mode',XkPfJNjGArFpagmCTDnKzWBYItEsvy)
  if XkPfJNjGArFpagmCTDnKzWBYItEswO=='LOGOUT':
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.logout()
   return
  XkPfJNjGArFpagmCTDnKzWBYItEsQl.login_main()
  if XkPfJNjGArFpagmCTDnKzWBYItEswO is XkPfJNjGArFpagmCTDnKzWBYItEsvy:
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.dp_Main_List()
  elif XkPfJNjGArFpagmCTDnKzWBYItEswO in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.dp_Title_Group(XkPfJNjGArFpagmCTDnKzWBYItEsQl.main_params)
  elif XkPfJNjGArFpagmCTDnKzWBYItEswO in['GLOBAL_GROUP']:
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.dp_SubTitle_Group(XkPfJNjGArFpagmCTDnKzWBYItEsQl.main_params)
  elif XkPfJNjGArFpagmCTDnKzWBYItEswO=='CHANNEL':
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.dp_LiveChannel_List(XkPfJNjGArFpagmCTDnKzWBYItEsQl.main_params)
  elif XkPfJNjGArFpagmCTDnKzWBYItEswO in['LIVE','VOD','MOVIE']:
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.play_VIDEO(XkPfJNjGArFpagmCTDnKzWBYItEsQl.main_params)
  elif XkPfJNjGArFpagmCTDnKzWBYItEswO=='PROGRAM':
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.dp_Program_List(XkPfJNjGArFpagmCTDnKzWBYItEsQl.main_params)
  elif XkPfJNjGArFpagmCTDnKzWBYItEswO=='4K_PROGRAM':
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.dp_4K_Program_List(XkPfJNjGArFpagmCTDnKzWBYItEsQl.main_params)
  elif XkPfJNjGArFpagmCTDnKzWBYItEswO=='ORI_PROGRAM':
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.dp_Ori_Program_List(XkPfJNjGArFpagmCTDnKzWBYItEsQl.main_params)
  elif XkPfJNjGArFpagmCTDnKzWBYItEswO=='EPISODE':
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.dp_Episode_List(XkPfJNjGArFpagmCTDnKzWBYItEsQl.main_params)
  elif XkPfJNjGArFpagmCTDnKzWBYItEswO=='MOVIE_SUB':
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.dp_Movie_List(XkPfJNjGArFpagmCTDnKzWBYItEsQl.main_params)
  elif XkPfJNjGArFpagmCTDnKzWBYItEswO=='4K_MOVIE':
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.dp_4K_Movie_List(XkPfJNjGArFpagmCTDnKzWBYItEsQl.main_params)
  elif XkPfJNjGArFpagmCTDnKzWBYItEswO=='SEARCH_GROUP':
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.dp_Search_Group(XkPfJNjGArFpagmCTDnKzWBYItEsQl.main_params)
  elif XkPfJNjGArFpagmCTDnKzWBYItEswO in['SEARCH','LOCAL_SEARCH']:
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.dp_Search_List(XkPfJNjGArFpagmCTDnKzWBYItEsQl.main_params)
  elif XkPfJNjGArFpagmCTDnKzWBYItEswO=='WATCH':
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.dp_Watch_List(XkPfJNjGArFpagmCTDnKzWBYItEsQl.main_params)
  elif XkPfJNjGArFpagmCTDnKzWBYItEswO in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.dp_History_Remove(XkPfJNjGArFpagmCTDnKzWBYItEsQl.main_params)
  elif XkPfJNjGArFpagmCTDnKzWBYItEswO=='ORDER_BY':
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.dp_setEpOrderby(XkPfJNjGArFpagmCTDnKzWBYItEsQl.main_params)
  elif XkPfJNjGArFpagmCTDnKzWBYItEswO=='SET_BOOKMARK':
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.dp_Set_Bookmark(XkPfJNjGArFpagmCTDnKzWBYItEsQl.main_params)
  elif XkPfJNjGArFpagmCTDnKzWBYItEswO in['TOTAL_SEARCH','TOTAL_HISTORY']:
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.dp_Global_Search(XkPfJNjGArFpagmCTDnKzWBYItEsQl.main_params)
  elif XkPfJNjGArFpagmCTDnKzWBYItEswO=='SEARCH_HISTORY':
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.dp_Search_History(XkPfJNjGArFpagmCTDnKzWBYItEsQl.main_params)
  elif XkPfJNjGArFpagmCTDnKzWBYItEswO=='MENU_BOOKMARK':
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.dp_Bookmark_Menu(XkPfJNjGArFpagmCTDnKzWBYItEsQl.main_params)
  elif XkPfJNjGArFpagmCTDnKzWBYItEswO=='EURO_GROUP':
   XkPfJNjGArFpagmCTDnKzWBYItEsQl.dp_EuroLive_List(XkPfJNjGArFpagmCTDnKzWBYItEsQl.main_params)
  else:
   XkPfJNjGArFpagmCTDnKzWBYItEsvy
# Created by pyminifier (https://github.com/liftoff/pyminifier)
