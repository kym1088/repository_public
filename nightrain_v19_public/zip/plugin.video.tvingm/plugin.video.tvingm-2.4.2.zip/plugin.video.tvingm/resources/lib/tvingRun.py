__author__="NightRain"
FOSGtujkgwiKbUEdVoNHhzBJqmLcpX=object
FOSGtujkgwiKbUEdVoNHhzBJqmLcpr=None
FOSGtujkgwiKbUEdVoNHhzBJqmLcpf=int
FOSGtujkgwiKbUEdVoNHhzBJqmLcps=True
FOSGtujkgwiKbUEdVoNHhzBJqmLcpR=False
FOSGtujkgwiKbUEdVoNHhzBJqmLcpy=type
FOSGtujkgwiKbUEdVoNHhzBJqmLcpM=dict
FOSGtujkgwiKbUEdVoNHhzBJqmLcpa=len
FOSGtujkgwiKbUEdVoNHhzBJqmLcpY=str
FOSGtujkgwiKbUEdVoNHhzBJqmLcpQ=range
FOSGtujkgwiKbUEdVoNHhzBJqmLcpC=open
FOSGtujkgwiKbUEdVoNHhzBJqmLcpe=Exception
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
FOSGtujkgwiKbUEdVoNHhzBJqmLcxW=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
FOSGtujkgwiKbUEdVoNHhzBJqmLcxA=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
FOSGtujkgwiKbUEdVoNHhzBJqmLcxX=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
FOSGtujkgwiKbUEdVoNHhzBJqmLcxr=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
FOSGtujkgwiKbUEdVoNHhzBJqmLcxf=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'공연','mode':'PROGRAM','stype':'PCM'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'}]
FOSGtujkgwiKbUEdVoNHhzBJqmLcxp=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG190,MG230,MG270,MG290'},{'title':'로맨스/멜로','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'액션/SF','mode':'MOVIE_SUB','stype':'MG120,MG170,MG180,MG220,MG260,MG200,MG210'},{'title':'공포/스릴러','mode':'MOVIE_SUB','stype':'MG160,MG140,MG150'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'다큐/클래식','mode':'MOVIE_SUB','stype':'MG250,MG330'}]
FOSGtujkgwiKbUEdVoNHhzBJqmLcxs=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
FOSGtujkgwiKbUEdVoNHhzBJqmLcxR =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
FOSGtujkgwiKbUEdVoNHhzBJqmLcxy=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
from tvingCore import*
class FOSGtujkgwiKbUEdVoNHhzBJqmLcxl(FOSGtujkgwiKbUEdVoNHhzBJqmLcpX):
 def __init__(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM,FOSGtujkgwiKbUEdVoNHhzBJqmLcxa,FOSGtujkgwiKbUEdVoNHhzBJqmLcxY,FOSGtujkgwiKbUEdVoNHhzBJqmLcxQ):
  FOSGtujkgwiKbUEdVoNHhzBJqmLcxM._addon_url =FOSGtujkgwiKbUEdVoNHhzBJqmLcxa
  FOSGtujkgwiKbUEdVoNHhzBJqmLcxM._addon_handle=FOSGtujkgwiKbUEdVoNHhzBJqmLcxY
  FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.main_params =FOSGtujkgwiKbUEdVoNHhzBJqmLcxQ
  FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.TvingObj =WfajURorOkbXnQBAvTstFJlNpKGhdC() 
 def addon_noti(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM,sting):
  try:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxe=xbmcgui.Dialog()
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxe.notification(__addonname__,sting)
  except:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcpr
 def addon_log(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM,string):
  try:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxP=string.encode('utf-8','ignore')
  except:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxP='addonException: addon_log'
  FOSGtujkgwiKbUEdVoNHhzBJqmLcxD=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,FOSGtujkgwiKbUEdVoNHhzBJqmLcxP),level=FOSGtujkgwiKbUEdVoNHhzBJqmLcxD)
 def get_keyboard_input(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM,FOSGtujkgwiKbUEdVoNHhzBJqmLclM):
  FOSGtujkgwiKbUEdVoNHhzBJqmLcxn=FOSGtujkgwiKbUEdVoNHhzBJqmLcpr
  kb=xbmc.Keyboard()
  kb.setHeading(FOSGtujkgwiKbUEdVoNHhzBJqmLclM)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxn=kb.getText()
  return FOSGtujkgwiKbUEdVoNHhzBJqmLcxn
 def get_settings_login_info(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM):
  FOSGtujkgwiKbUEdVoNHhzBJqmLcxI =__addon__.getSetting('id')
  FOSGtujkgwiKbUEdVoNHhzBJqmLcxT =__addon__.getSetting('pw')
  FOSGtujkgwiKbUEdVoNHhzBJqmLcxv =__addon__.getSetting('login_type')
  FOSGtujkgwiKbUEdVoNHhzBJqmLclx=FOSGtujkgwiKbUEdVoNHhzBJqmLcpf(__addon__.getSetting('selected_profile'))
  return(FOSGtujkgwiKbUEdVoNHhzBJqmLcxI,FOSGtujkgwiKbUEdVoNHhzBJqmLcxT,FOSGtujkgwiKbUEdVoNHhzBJqmLcxv,FOSGtujkgwiKbUEdVoNHhzBJqmLclx)
 def get_settings_totalsearch(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM):
  FOSGtujkgwiKbUEdVoNHhzBJqmLclW =FOSGtujkgwiKbUEdVoNHhzBJqmLcps if __addon__.getSetting('local_search')=='true' else FOSGtujkgwiKbUEdVoNHhzBJqmLcpR
  FOSGtujkgwiKbUEdVoNHhzBJqmLclA=FOSGtujkgwiKbUEdVoNHhzBJqmLcps if __addon__.getSetting('local_history')=='true' else FOSGtujkgwiKbUEdVoNHhzBJqmLcpR
  FOSGtujkgwiKbUEdVoNHhzBJqmLclX =FOSGtujkgwiKbUEdVoNHhzBJqmLcps if __addon__.getSetting('total_search')=='true' else FOSGtujkgwiKbUEdVoNHhzBJqmLcpR
  FOSGtujkgwiKbUEdVoNHhzBJqmLclr=FOSGtujkgwiKbUEdVoNHhzBJqmLcps if __addon__.getSetting('total_history')=='true' else FOSGtujkgwiKbUEdVoNHhzBJqmLcpR
  FOSGtujkgwiKbUEdVoNHhzBJqmLclf=FOSGtujkgwiKbUEdVoNHhzBJqmLcps if __addon__.getSetting('menu_bookmark')=='true' else FOSGtujkgwiKbUEdVoNHhzBJqmLcpR
  return(FOSGtujkgwiKbUEdVoNHhzBJqmLclW,FOSGtujkgwiKbUEdVoNHhzBJqmLclA,FOSGtujkgwiKbUEdVoNHhzBJqmLclX,FOSGtujkgwiKbUEdVoNHhzBJqmLclr,FOSGtujkgwiKbUEdVoNHhzBJqmLclf)
 def get_settings_makebookmark(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM):
  return FOSGtujkgwiKbUEdVoNHhzBJqmLcps if __addon__.getSetting('make_bookmark')=='true' else FOSGtujkgwiKbUEdVoNHhzBJqmLcpR
 def get_settings_direct_replay(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM):
  FOSGtujkgwiKbUEdVoNHhzBJqmLclp=FOSGtujkgwiKbUEdVoNHhzBJqmLcpf(__addon__.getSetting('direct_replay'))
  if FOSGtujkgwiKbUEdVoNHhzBJqmLclp==0:
   return FOSGtujkgwiKbUEdVoNHhzBJqmLcpR
  else:
   return FOSGtujkgwiKbUEdVoNHhzBJqmLcps
 def set_winCredential(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM,credential):
  FOSGtujkgwiKbUEdVoNHhzBJqmLcls=xbmcgui.Window(10000)
  FOSGtujkgwiKbUEdVoNHhzBJqmLcls.setProperty('TVING_M_TOKEN',credential.get('tving_token'))
  FOSGtujkgwiKbUEdVoNHhzBJqmLcls.setProperty('TVING_M_USERINFO',credential.get('poc_userinfo'))
  FOSGtujkgwiKbUEdVoNHhzBJqmLcls.setProperty('TVING_M_UUID',credential.get('tving_uuid'))
  FOSGtujkgwiKbUEdVoNHhzBJqmLcls.setProperty('TVING_M_LOGINTIME',FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.TvingObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
  FOSGtujkgwiKbUEdVoNHhzBJqmLcls.setProperty('TVING_M_MAINTOKEN',credential.get('tving_maintoken'))
  FOSGtujkgwiKbUEdVoNHhzBJqmLcls.setProperty('TVING_M_COOKIEKEY',credential.get('tving_cookiekey'))
  FOSGtujkgwiKbUEdVoNHhzBJqmLcls.setProperty('TVING_M_LOCKKEY',credential.get('tving_lockkey'))
 def get_winCredential(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM):
  FOSGtujkgwiKbUEdVoNHhzBJqmLcls=xbmcgui.Window(10000)
  FOSGtujkgwiKbUEdVoNHhzBJqmLclR={'tving_token':FOSGtujkgwiKbUEdVoNHhzBJqmLcls.getProperty('TVING_M_TOKEN'),'poc_userinfo':FOSGtujkgwiKbUEdVoNHhzBJqmLcls.getProperty('TVING_M_USERINFO'),'tving_uuid':FOSGtujkgwiKbUEdVoNHhzBJqmLcls.getProperty('TVING_M_UUID'),'tving_maintoken':FOSGtujkgwiKbUEdVoNHhzBJqmLcls.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':FOSGtujkgwiKbUEdVoNHhzBJqmLcls.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':FOSGtujkgwiKbUEdVoNHhzBJqmLcls.getProperty('TVING_M_LOCKKEY')}
  return FOSGtujkgwiKbUEdVoNHhzBJqmLclR
 def set_winEpisodeOrderby(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM,FOSGtujkgwiKbUEdVoNHhzBJqmLcAf):
  FOSGtujkgwiKbUEdVoNHhzBJqmLcls=xbmcgui.Window(10000)
  FOSGtujkgwiKbUEdVoNHhzBJqmLcls.setProperty('TVING_M_ORDERBY',FOSGtujkgwiKbUEdVoNHhzBJqmLcAf)
 def get_winEpisodeOrderby(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM):
  FOSGtujkgwiKbUEdVoNHhzBJqmLcls=xbmcgui.Window(10000)
  return FOSGtujkgwiKbUEdVoNHhzBJqmLcls.getProperty('TVING_M_ORDERBY')
 def add_dir(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM,label,sublabel='',img='',infoLabels=FOSGtujkgwiKbUEdVoNHhzBJqmLcpr,isFolder=FOSGtujkgwiKbUEdVoNHhzBJqmLcps,params='',isLink=FOSGtujkgwiKbUEdVoNHhzBJqmLcpR,ContextMenu=FOSGtujkgwiKbUEdVoNHhzBJqmLcpr):
  FOSGtujkgwiKbUEdVoNHhzBJqmLcly='%s?%s'%(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM._addon_url,urllib.parse.urlencode(params))
  if sublabel:FOSGtujkgwiKbUEdVoNHhzBJqmLclM='%s < %s >'%(label,sublabel)
  else: FOSGtujkgwiKbUEdVoNHhzBJqmLclM=label
  if not img:img='DefaultFolder.png'
  FOSGtujkgwiKbUEdVoNHhzBJqmLcla=xbmcgui.ListItem(FOSGtujkgwiKbUEdVoNHhzBJqmLclM)
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcpy(img)==FOSGtujkgwiKbUEdVoNHhzBJqmLcpM:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcla.setArt(img)
  else:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcla.setArt({'thumb':img,'poster':img})
  if infoLabels:FOSGtujkgwiKbUEdVoNHhzBJqmLcla.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcla.setProperty('IsPlayable','true')
  if ContextMenu:FOSGtujkgwiKbUEdVoNHhzBJqmLcla.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM._addon_handle,FOSGtujkgwiKbUEdVoNHhzBJqmLcly,FOSGtujkgwiKbUEdVoNHhzBJqmLcla,isFolder)
 def get_selQuality(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM,etype):
  try:
   FOSGtujkgwiKbUEdVoNHhzBJqmLclY='selected_quality'
   FOSGtujkgwiKbUEdVoNHhzBJqmLclQ=[1080,720,480,360]
   FOSGtujkgwiKbUEdVoNHhzBJqmLclC=FOSGtujkgwiKbUEdVoNHhzBJqmLcpf(__addon__.getSetting(FOSGtujkgwiKbUEdVoNHhzBJqmLclY))
   return FOSGtujkgwiKbUEdVoNHhzBJqmLclQ[FOSGtujkgwiKbUEdVoNHhzBJqmLclC]
  except:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcpr
  return 720 
 def dp_Main_List(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM):
  (FOSGtujkgwiKbUEdVoNHhzBJqmLclW,FOSGtujkgwiKbUEdVoNHhzBJqmLclA,FOSGtujkgwiKbUEdVoNHhzBJqmLclX,FOSGtujkgwiKbUEdVoNHhzBJqmLclr,FOSGtujkgwiKbUEdVoNHhzBJqmLclf)=FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.get_settings_totalsearch()
  for FOSGtujkgwiKbUEdVoNHhzBJqmLcle in FOSGtujkgwiKbUEdVoNHhzBJqmLcxW:
   FOSGtujkgwiKbUEdVoNHhzBJqmLclM=FOSGtujkgwiKbUEdVoNHhzBJqmLcle.get('title')
   FOSGtujkgwiKbUEdVoNHhzBJqmLclP=''
   if FOSGtujkgwiKbUEdVoNHhzBJqmLcle.get('mode')=='SEARCH_GROUP' and FOSGtujkgwiKbUEdVoNHhzBJqmLclW ==FOSGtujkgwiKbUEdVoNHhzBJqmLcpR:continue
   elif FOSGtujkgwiKbUEdVoNHhzBJqmLcle.get('mode')=='SEARCH_HISTORY' and FOSGtujkgwiKbUEdVoNHhzBJqmLclA==FOSGtujkgwiKbUEdVoNHhzBJqmLcpR:continue
   elif FOSGtujkgwiKbUEdVoNHhzBJqmLcle.get('mode')=='TOTAL_SEARCH' and FOSGtujkgwiKbUEdVoNHhzBJqmLclX ==FOSGtujkgwiKbUEdVoNHhzBJqmLcpR:continue
   elif FOSGtujkgwiKbUEdVoNHhzBJqmLcle.get('mode')=='TOTAL_HISTORY' and FOSGtujkgwiKbUEdVoNHhzBJqmLclr==FOSGtujkgwiKbUEdVoNHhzBJqmLcpR:continue
   elif FOSGtujkgwiKbUEdVoNHhzBJqmLcle.get('mode')=='MENU_BOOKMARK' and FOSGtujkgwiKbUEdVoNHhzBJqmLclf==FOSGtujkgwiKbUEdVoNHhzBJqmLcpR:continue
   FOSGtujkgwiKbUEdVoNHhzBJqmLclD={'mode':FOSGtujkgwiKbUEdVoNHhzBJqmLcle.get('mode'),'stype':FOSGtujkgwiKbUEdVoNHhzBJqmLcle.get('stype'),'orderby':FOSGtujkgwiKbUEdVoNHhzBJqmLcle.get('orderby'),'ordernm':FOSGtujkgwiKbUEdVoNHhzBJqmLcle.get('ordernm'),'page':'1'}
   if FOSGtujkgwiKbUEdVoNHhzBJqmLcle.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    FOSGtujkgwiKbUEdVoNHhzBJqmLcln=FOSGtujkgwiKbUEdVoNHhzBJqmLcpR
    FOSGtujkgwiKbUEdVoNHhzBJqmLclI =FOSGtujkgwiKbUEdVoNHhzBJqmLcps
   else:
    FOSGtujkgwiKbUEdVoNHhzBJqmLcln=FOSGtujkgwiKbUEdVoNHhzBJqmLcps
    FOSGtujkgwiKbUEdVoNHhzBJqmLclI =FOSGtujkgwiKbUEdVoNHhzBJqmLcpR
   if 'icon' in FOSGtujkgwiKbUEdVoNHhzBJqmLcle:FOSGtujkgwiKbUEdVoNHhzBJqmLclP=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',FOSGtujkgwiKbUEdVoNHhzBJqmLcle.get('icon')) 
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.add_dir(FOSGtujkgwiKbUEdVoNHhzBJqmLclM,sublabel='',img=FOSGtujkgwiKbUEdVoNHhzBJqmLclP,infoLabels=FOSGtujkgwiKbUEdVoNHhzBJqmLcpr,isFolder=FOSGtujkgwiKbUEdVoNHhzBJqmLcln,params=FOSGtujkgwiKbUEdVoNHhzBJqmLclD,isLink=FOSGtujkgwiKbUEdVoNHhzBJqmLclI)
  xbmcplugin.endOfDirectory(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM._addon_handle)
 def login_main(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM):
  (FOSGtujkgwiKbUEdVoNHhzBJqmLclv,FOSGtujkgwiKbUEdVoNHhzBJqmLcWx,FOSGtujkgwiKbUEdVoNHhzBJqmLcWl,FOSGtujkgwiKbUEdVoNHhzBJqmLcWA)=FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.get_settings_login_info()
  if not(FOSGtujkgwiKbUEdVoNHhzBJqmLclv and FOSGtujkgwiKbUEdVoNHhzBJqmLcWx):
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxe=xbmcgui.Dialog()
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWX=FOSGtujkgwiKbUEdVoNHhzBJqmLcxe.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if FOSGtujkgwiKbUEdVoNHhzBJqmLcWX==FOSGtujkgwiKbUEdVoNHhzBJqmLcps:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.get_winEpisodeOrderby()=='':
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.set_winEpisodeOrderby('desc')
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.cookiefile_check():return
  FOSGtujkgwiKbUEdVoNHhzBJqmLcWr =FOSGtujkgwiKbUEdVoNHhzBJqmLcpf(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  FOSGtujkgwiKbUEdVoNHhzBJqmLcWf=xbmcgui.Window(10000).getProperty('TVING_M_LOGINTIME')
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcWf==FOSGtujkgwiKbUEdVoNHhzBJqmLcpr or FOSGtujkgwiKbUEdVoNHhzBJqmLcWf=='':
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWf=FOSGtujkgwiKbUEdVoNHhzBJqmLcpf('19000101')
  else:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWf=FOSGtujkgwiKbUEdVoNHhzBJqmLcpf(re.sub('-','',FOSGtujkgwiKbUEdVoNHhzBJqmLcWf))
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWp=0
   while FOSGtujkgwiKbUEdVoNHhzBJqmLcps:
    FOSGtujkgwiKbUEdVoNHhzBJqmLcWp+=1
    time.sleep(0.05)
    if FOSGtujkgwiKbUEdVoNHhzBJqmLcWf>=FOSGtujkgwiKbUEdVoNHhzBJqmLcWr:return
    if FOSGtujkgwiKbUEdVoNHhzBJqmLcWp>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcWf>=FOSGtujkgwiKbUEdVoNHhzBJqmLcWr:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   return
  if not FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.TvingObj.GetCredential(FOSGtujkgwiKbUEdVoNHhzBJqmLclv,FOSGtujkgwiKbUEdVoNHhzBJqmLcWx,FOSGtujkgwiKbUEdVoNHhzBJqmLcWl,FOSGtujkgwiKbUEdVoNHhzBJqmLcWA):
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   sys.exit()
  FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.set_winCredential(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.TvingObj.LoadCredential())
  FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
 def dp_Title_Group(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM,FOSGtujkgwiKbUEdVoNHhzBJqmLcWM):
  FOSGtujkgwiKbUEdVoNHhzBJqmLcWs=FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('stype')
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcWs=='live':
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWR=FOSGtujkgwiKbUEdVoNHhzBJqmLcxA
  elif FOSGtujkgwiKbUEdVoNHhzBJqmLcWs=='vod':
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWR=FOSGtujkgwiKbUEdVoNHhzBJqmLcxf
  else:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWR=FOSGtujkgwiKbUEdVoNHhzBJqmLcxp
  for FOSGtujkgwiKbUEdVoNHhzBJqmLcWy in FOSGtujkgwiKbUEdVoNHhzBJqmLcWR:
   FOSGtujkgwiKbUEdVoNHhzBJqmLclM=FOSGtujkgwiKbUEdVoNHhzBJqmLcWy.get('title')
   if FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('ordernm')!='-':
    FOSGtujkgwiKbUEdVoNHhzBJqmLclM+='  ('+FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('ordernm')+')'
   FOSGtujkgwiKbUEdVoNHhzBJqmLclD={'mode':FOSGtujkgwiKbUEdVoNHhzBJqmLcWy.get('mode'),'stype':FOSGtujkgwiKbUEdVoNHhzBJqmLcWy.get('stype'),'orderby':FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('orderby'),'ordernm':FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('ordernm'),'page':'1'}
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.add_dir(FOSGtujkgwiKbUEdVoNHhzBJqmLclM,sublabel='',img='',infoLabels=FOSGtujkgwiKbUEdVoNHhzBJqmLcpr,isFolder=FOSGtujkgwiKbUEdVoNHhzBJqmLcps,params=FOSGtujkgwiKbUEdVoNHhzBJqmLclD)
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcpa(FOSGtujkgwiKbUEdVoNHhzBJqmLcWR)>0:xbmcplugin.endOfDirectory(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM._addon_handle)
 def dp_SubTitle_Group(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM,FOSGtujkgwiKbUEdVoNHhzBJqmLcWM): 
  for FOSGtujkgwiKbUEdVoNHhzBJqmLcWy in FOSGtujkgwiKbUEdVoNHhzBJqmLcxs:
   FOSGtujkgwiKbUEdVoNHhzBJqmLclM=FOSGtujkgwiKbUEdVoNHhzBJqmLcWy.get('title')
   if FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('ordernm')!='-':
    FOSGtujkgwiKbUEdVoNHhzBJqmLclM+='  ('+FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('ordernm')+')'
   FOSGtujkgwiKbUEdVoNHhzBJqmLclD={'mode':FOSGtujkgwiKbUEdVoNHhzBJqmLcWy.get('mode'),'genreCode':FOSGtujkgwiKbUEdVoNHhzBJqmLcWy.get('genreCode'),'stype':FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('stype'),'orderby':FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('orderby'),'page':'1'}
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.add_dir(FOSGtujkgwiKbUEdVoNHhzBJqmLclM,sublabel='',img='',infoLabels=FOSGtujkgwiKbUEdVoNHhzBJqmLcpr,isFolder=FOSGtujkgwiKbUEdVoNHhzBJqmLcps,params=FOSGtujkgwiKbUEdVoNHhzBJqmLclD)
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcpa(FOSGtujkgwiKbUEdVoNHhzBJqmLcxs)>0:xbmcplugin.endOfDirectory(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM._addon_handle)
 def dp_LiveChannel_List(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM,FOSGtujkgwiKbUEdVoNHhzBJqmLcWM):
  FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.TvingObj.SaveCredential(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.get_winCredential())
  FOSGtujkgwiKbUEdVoNHhzBJqmLcWs =FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('stype')
  FOSGtujkgwiKbUEdVoNHhzBJqmLcWa =FOSGtujkgwiKbUEdVoNHhzBJqmLcpf(FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('page'))
  FOSGtujkgwiKbUEdVoNHhzBJqmLcWY,FOSGtujkgwiKbUEdVoNHhzBJqmLcWQ=FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.TvingObj.GetLiveChannelList(FOSGtujkgwiKbUEdVoNHhzBJqmLcWs,FOSGtujkgwiKbUEdVoNHhzBJqmLcWa)
  for FOSGtujkgwiKbUEdVoNHhzBJqmLcWC in FOSGtujkgwiKbUEdVoNHhzBJqmLcWY:
   FOSGtujkgwiKbUEdVoNHhzBJqmLclM =FOSGtujkgwiKbUEdVoNHhzBJqmLcWC.get('title')
   FOSGtujkgwiKbUEdVoNHhzBJqmLclT =FOSGtujkgwiKbUEdVoNHhzBJqmLcWC.get('channel')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWe =FOSGtujkgwiKbUEdVoNHhzBJqmLcWC.get('thumbnail')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWP =FOSGtujkgwiKbUEdVoNHhzBJqmLcWC.get('synopsis')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWD =FOSGtujkgwiKbUEdVoNHhzBJqmLcWC.get('channelepg')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWn =FOSGtujkgwiKbUEdVoNHhzBJqmLcWC.get('cast')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWI =FOSGtujkgwiKbUEdVoNHhzBJqmLcWC.get('director')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWT =FOSGtujkgwiKbUEdVoNHhzBJqmLcWC.get('info_genre')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWv =FOSGtujkgwiKbUEdVoNHhzBJqmLcWC.get('year')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcAx =FOSGtujkgwiKbUEdVoNHhzBJqmLcWC.get('mpaa')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcAl =FOSGtujkgwiKbUEdVoNHhzBJqmLcWC.get('premiered')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcAW={'mediatype':'episode','title':FOSGtujkgwiKbUEdVoNHhzBJqmLclM,'studio':FOSGtujkgwiKbUEdVoNHhzBJqmLclT,'cast':FOSGtujkgwiKbUEdVoNHhzBJqmLcWn,'director':FOSGtujkgwiKbUEdVoNHhzBJqmLcWI,'genre':FOSGtujkgwiKbUEdVoNHhzBJqmLcWT,'plot':'%s\n%s\n%s\n\n%s'%(FOSGtujkgwiKbUEdVoNHhzBJqmLclT,FOSGtujkgwiKbUEdVoNHhzBJqmLclM,FOSGtujkgwiKbUEdVoNHhzBJqmLcWD,FOSGtujkgwiKbUEdVoNHhzBJqmLcWP),'year':FOSGtujkgwiKbUEdVoNHhzBJqmLcWv,'mpaa':FOSGtujkgwiKbUEdVoNHhzBJqmLcAx,'premiered':FOSGtujkgwiKbUEdVoNHhzBJqmLcAl}
   FOSGtujkgwiKbUEdVoNHhzBJqmLclD={'mode':'LIVE','mediacode':FOSGtujkgwiKbUEdVoNHhzBJqmLcWC.get('mediacode'),'stype':FOSGtujkgwiKbUEdVoNHhzBJqmLcWs}
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.add_dir(FOSGtujkgwiKbUEdVoNHhzBJqmLclT,sublabel=FOSGtujkgwiKbUEdVoNHhzBJqmLclM,img=FOSGtujkgwiKbUEdVoNHhzBJqmLcWe,infoLabels=FOSGtujkgwiKbUEdVoNHhzBJqmLcAW,isFolder=FOSGtujkgwiKbUEdVoNHhzBJqmLcpR,params=FOSGtujkgwiKbUEdVoNHhzBJqmLclD)
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcWQ:
   FOSGtujkgwiKbUEdVoNHhzBJqmLclD['mode']='CHANNEL' 
   FOSGtujkgwiKbUEdVoNHhzBJqmLclD['stype']=FOSGtujkgwiKbUEdVoNHhzBJqmLcWs 
   FOSGtujkgwiKbUEdVoNHhzBJqmLclD['page']=FOSGtujkgwiKbUEdVoNHhzBJqmLcpY(FOSGtujkgwiKbUEdVoNHhzBJqmLcWa+1)
   FOSGtujkgwiKbUEdVoNHhzBJqmLclM='[B]%s >>[/B]'%'다음 페이지'
   FOSGtujkgwiKbUEdVoNHhzBJqmLcAX=FOSGtujkgwiKbUEdVoNHhzBJqmLcpY(FOSGtujkgwiKbUEdVoNHhzBJqmLcWa+1)
   FOSGtujkgwiKbUEdVoNHhzBJqmLclP=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.add_dir(FOSGtujkgwiKbUEdVoNHhzBJqmLclM,sublabel=FOSGtujkgwiKbUEdVoNHhzBJqmLcAX,img=FOSGtujkgwiKbUEdVoNHhzBJqmLclP,infoLabels=FOSGtujkgwiKbUEdVoNHhzBJqmLcpr,isFolder=FOSGtujkgwiKbUEdVoNHhzBJqmLcps,params=FOSGtujkgwiKbUEdVoNHhzBJqmLclD)
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcpa(FOSGtujkgwiKbUEdVoNHhzBJqmLcWY)>0:xbmcplugin.endOfDirectory(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM._addon_handle,cacheToDisc=FOSGtujkgwiKbUEdVoNHhzBJqmLcpR)
 def dp_Program_List(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM,FOSGtujkgwiKbUEdVoNHhzBJqmLcWM):
  FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.TvingObj.SaveCredential(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.get_winCredential())
  FOSGtujkgwiKbUEdVoNHhzBJqmLcAr =FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('stype')
  FOSGtujkgwiKbUEdVoNHhzBJqmLcAf =FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('orderby')
  FOSGtujkgwiKbUEdVoNHhzBJqmLcWa =FOSGtujkgwiKbUEdVoNHhzBJqmLcpf(FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('page'))
  FOSGtujkgwiKbUEdVoNHhzBJqmLcAp=FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('genreCode')
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcAp==FOSGtujkgwiKbUEdVoNHhzBJqmLcpr:FOSGtujkgwiKbUEdVoNHhzBJqmLcAp='all'
  FOSGtujkgwiKbUEdVoNHhzBJqmLcAs,FOSGtujkgwiKbUEdVoNHhzBJqmLcWQ=FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.TvingObj.GetProgramList(FOSGtujkgwiKbUEdVoNHhzBJqmLcAr,FOSGtujkgwiKbUEdVoNHhzBJqmLcAf,FOSGtujkgwiKbUEdVoNHhzBJqmLcWa,FOSGtujkgwiKbUEdVoNHhzBJqmLcAp)
  for FOSGtujkgwiKbUEdVoNHhzBJqmLcAR in FOSGtujkgwiKbUEdVoNHhzBJqmLcAs:
   FOSGtujkgwiKbUEdVoNHhzBJqmLclM =FOSGtujkgwiKbUEdVoNHhzBJqmLcAR.get('title')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWe =FOSGtujkgwiKbUEdVoNHhzBJqmLcAR.get('thumbnail')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWP =FOSGtujkgwiKbUEdVoNHhzBJqmLcAR.get('synopsis')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcAy =FOSGtujkgwiKbUEdVoNHhzBJqmLcAR.get('channel')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWn =FOSGtujkgwiKbUEdVoNHhzBJqmLcAR.get('cast')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWI =FOSGtujkgwiKbUEdVoNHhzBJqmLcAR.get('director')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWT=FOSGtujkgwiKbUEdVoNHhzBJqmLcAR.get('info_genre')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWv =FOSGtujkgwiKbUEdVoNHhzBJqmLcAR.get('year')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcAl =FOSGtujkgwiKbUEdVoNHhzBJqmLcAR.get('premiered')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcAx =FOSGtujkgwiKbUEdVoNHhzBJqmLcAR.get('mpaa')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcAW={'mediatype':'tvshow','title':FOSGtujkgwiKbUEdVoNHhzBJqmLclM,'studio':FOSGtujkgwiKbUEdVoNHhzBJqmLcAy,'cast':FOSGtujkgwiKbUEdVoNHhzBJqmLcWn,'director':FOSGtujkgwiKbUEdVoNHhzBJqmLcWI,'genre':FOSGtujkgwiKbUEdVoNHhzBJqmLcWT,'year':FOSGtujkgwiKbUEdVoNHhzBJqmLcWv,'premiered':FOSGtujkgwiKbUEdVoNHhzBJqmLcAl,'mpaa':FOSGtujkgwiKbUEdVoNHhzBJqmLcAx,'plot':FOSGtujkgwiKbUEdVoNHhzBJqmLcWP}
   FOSGtujkgwiKbUEdVoNHhzBJqmLclD={'mode':'EPISODE','programcode':FOSGtujkgwiKbUEdVoNHhzBJqmLcAR.get('program'),'page':'1'}
   if FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.get_settings_makebookmark():
    FOSGtujkgwiKbUEdVoNHhzBJqmLcAM={'videoid':FOSGtujkgwiKbUEdVoNHhzBJqmLcAR.get('program'),'vidtype':'tvshow','vtitle':FOSGtujkgwiKbUEdVoNHhzBJqmLclM,'vsubtitle':FOSGtujkgwiKbUEdVoNHhzBJqmLcAy,}
    FOSGtujkgwiKbUEdVoNHhzBJqmLcAa=json.dumps(FOSGtujkgwiKbUEdVoNHhzBJqmLcAM)
    FOSGtujkgwiKbUEdVoNHhzBJqmLcAa=urllib.parse.quote(FOSGtujkgwiKbUEdVoNHhzBJqmLcAa)
    FOSGtujkgwiKbUEdVoNHhzBJqmLcAY='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(FOSGtujkgwiKbUEdVoNHhzBJqmLcAa)
    FOSGtujkgwiKbUEdVoNHhzBJqmLcAQ=[('(통합) 찜 영상에 추가',FOSGtujkgwiKbUEdVoNHhzBJqmLcAY)]
   else:
    FOSGtujkgwiKbUEdVoNHhzBJqmLcAQ=FOSGtujkgwiKbUEdVoNHhzBJqmLcpr
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.add_dir(FOSGtujkgwiKbUEdVoNHhzBJqmLclM,sublabel=FOSGtujkgwiKbUEdVoNHhzBJqmLcAy,img=FOSGtujkgwiKbUEdVoNHhzBJqmLcWe,infoLabels=FOSGtujkgwiKbUEdVoNHhzBJqmLcAW,isFolder=FOSGtujkgwiKbUEdVoNHhzBJqmLcps,params=FOSGtujkgwiKbUEdVoNHhzBJqmLclD,ContextMenu=FOSGtujkgwiKbUEdVoNHhzBJqmLcAQ)
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcWQ:
   FOSGtujkgwiKbUEdVoNHhzBJqmLclD['mode'] ='PROGRAM' 
   FOSGtujkgwiKbUEdVoNHhzBJqmLclD['stype'] =FOSGtujkgwiKbUEdVoNHhzBJqmLcAr
   FOSGtujkgwiKbUEdVoNHhzBJqmLclD['orderby'] =FOSGtujkgwiKbUEdVoNHhzBJqmLcAf
   FOSGtujkgwiKbUEdVoNHhzBJqmLclD['page'] =FOSGtujkgwiKbUEdVoNHhzBJqmLcpY(FOSGtujkgwiKbUEdVoNHhzBJqmLcWa+1)
   FOSGtujkgwiKbUEdVoNHhzBJqmLclD['genreCode']=FOSGtujkgwiKbUEdVoNHhzBJqmLcAp 
   FOSGtujkgwiKbUEdVoNHhzBJqmLclM='[B]%s >>[/B]'%'다음 페이지'
   FOSGtujkgwiKbUEdVoNHhzBJqmLcAX=FOSGtujkgwiKbUEdVoNHhzBJqmLcpY(FOSGtujkgwiKbUEdVoNHhzBJqmLcWa+1)
   FOSGtujkgwiKbUEdVoNHhzBJqmLclP=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.add_dir(FOSGtujkgwiKbUEdVoNHhzBJqmLclM,sublabel=FOSGtujkgwiKbUEdVoNHhzBJqmLcAX,img=FOSGtujkgwiKbUEdVoNHhzBJqmLclP,infoLabels=FOSGtujkgwiKbUEdVoNHhzBJqmLcpr,isFolder=FOSGtujkgwiKbUEdVoNHhzBJqmLcps,params=FOSGtujkgwiKbUEdVoNHhzBJqmLclD)
  xbmcplugin.setContent(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM._addon_handle,cacheToDisc=FOSGtujkgwiKbUEdVoNHhzBJqmLcpR)
 def dp_Episode_List(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM,FOSGtujkgwiKbUEdVoNHhzBJqmLcWM):
  FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.TvingObj.SaveCredential(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.get_winCredential())
  FOSGtujkgwiKbUEdVoNHhzBJqmLcAe=FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('programcode')
  FOSGtujkgwiKbUEdVoNHhzBJqmLcWa =FOSGtujkgwiKbUEdVoNHhzBJqmLcpf(FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('page'))
  FOSGtujkgwiKbUEdVoNHhzBJqmLcAP,FOSGtujkgwiKbUEdVoNHhzBJqmLcWQ,FOSGtujkgwiKbUEdVoNHhzBJqmLcAD=FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.TvingObj.GetEpisodeList(FOSGtujkgwiKbUEdVoNHhzBJqmLcAe,FOSGtujkgwiKbUEdVoNHhzBJqmLcWa,orderby=FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.get_winEpisodeOrderby())
  for FOSGtujkgwiKbUEdVoNHhzBJqmLcAn in FOSGtujkgwiKbUEdVoNHhzBJqmLcAP:
   FOSGtujkgwiKbUEdVoNHhzBJqmLclM =FOSGtujkgwiKbUEdVoNHhzBJqmLcAn.get('title')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcAX =FOSGtujkgwiKbUEdVoNHhzBJqmLcAn.get('subtitle')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWe =FOSGtujkgwiKbUEdVoNHhzBJqmLcAn.get('thumbnail')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWP =FOSGtujkgwiKbUEdVoNHhzBJqmLcAn.get('synopsis')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcAI=FOSGtujkgwiKbUEdVoNHhzBJqmLcAn.get('info_title')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcAT =FOSGtujkgwiKbUEdVoNHhzBJqmLcAn.get('aired')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcAv =FOSGtujkgwiKbUEdVoNHhzBJqmLcAn.get('studio')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcXx =FOSGtujkgwiKbUEdVoNHhzBJqmLcAn.get('frequency')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcAW={'mediatype':'episode','title':FOSGtujkgwiKbUEdVoNHhzBJqmLcAI,'aired':FOSGtujkgwiKbUEdVoNHhzBJqmLcAT,'studio':FOSGtujkgwiKbUEdVoNHhzBJqmLcAv,'episode':FOSGtujkgwiKbUEdVoNHhzBJqmLcXx,'plot':FOSGtujkgwiKbUEdVoNHhzBJqmLcWP}
   FOSGtujkgwiKbUEdVoNHhzBJqmLclD={'mode':'VOD','mediacode':FOSGtujkgwiKbUEdVoNHhzBJqmLcAn.get('episode'),'stype':'vod','programcode':FOSGtujkgwiKbUEdVoNHhzBJqmLcAe,'title':FOSGtujkgwiKbUEdVoNHhzBJqmLclM,'thumbnail':FOSGtujkgwiKbUEdVoNHhzBJqmLcWe}
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.add_dir(FOSGtujkgwiKbUEdVoNHhzBJqmLclM,sublabel=FOSGtujkgwiKbUEdVoNHhzBJqmLcAX,img=FOSGtujkgwiKbUEdVoNHhzBJqmLcWe,infoLabels=FOSGtujkgwiKbUEdVoNHhzBJqmLcAW,isFolder=FOSGtujkgwiKbUEdVoNHhzBJqmLcpR,params=FOSGtujkgwiKbUEdVoNHhzBJqmLclD)
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcWa==1:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcAW={'plot':'정렬순서를 변경합니다.'}
   FOSGtujkgwiKbUEdVoNHhzBJqmLclD={}
   FOSGtujkgwiKbUEdVoNHhzBJqmLclD['mode'] ='ORDER_BY' 
   if FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.get_winEpisodeOrderby()=='desc':
    FOSGtujkgwiKbUEdVoNHhzBJqmLclM='정렬순서변경 : 최신화부터 -> 1회부터'
    FOSGtujkgwiKbUEdVoNHhzBJqmLclD['orderby']='asc'
   else:
    FOSGtujkgwiKbUEdVoNHhzBJqmLclM='정렬순서변경 : 1회부터 -> 최신화부터'
    FOSGtujkgwiKbUEdVoNHhzBJqmLclD['orderby']='desc'
   FOSGtujkgwiKbUEdVoNHhzBJqmLclP=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.add_dir(FOSGtujkgwiKbUEdVoNHhzBJqmLclM,sublabel='',img=FOSGtujkgwiKbUEdVoNHhzBJqmLclP,infoLabels=FOSGtujkgwiKbUEdVoNHhzBJqmLcAW,isFolder=FOSGtujkgwiKbUEdVoNHhzBJqmLcpR,params=FOSGtujkgwiKbUEdVoNHhzBJqmLclD,isLink=FOSGtujkgwiKbUEdVoNHhzBJqmLcps)
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcWQ:
   FOSGtujkgwiKbUEdVoNHhzBJqmLclD['mode'] ='EPISODE' 
   FOSGtujkgwiKbUEdVoNHhzBJqmLclD['programcode']=FOSGtujkgwiKbUEdVoNHhzBJqmLcAe
   FOSGtujkgwiKbUEdVoNHhzBJqmLclD['page'] =FOSGtujkgwiKbUEdVoNHhzBJqmLcpY(FOSGtujkgwiKbUEdVoNHhzBJqmLcWa+1)
   FOSGtujkgwiKbUEdVoNHhzBJqmLclM='[B]%s >>[/B]'%'다음 페이지'
   FOSGtujkgwiKbUEdVoNHhzBJqmLcAX=FOSGtujkgwiKbUEdVoNHhzBJqmLcpY(FOSGtujkgwiKbUEdVoNHhzBJqmLcWa+1)
   FOSGtujkgwiKbUEdVoNHhzBJqmLclP=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.add_dir(FOSGtujkgwiKbUEdVoNHhzBJqmLclM,sublabel=FOSGtujkgwiKbUEdVoNHhzBJqmLcAX,img=FOSGtujkgwiKbUEdVoNHhzBJqmLclP,infoLabels=FOSGtujkgwiKbUEdVoNHhzBJqmLcpr,isFolder=FOSGtujkgwiKbUEdVoNHhzBJqmLcps,params=FOSGtujkgwiKbUEdVoNHhzBJqmLclD)
  xbmcplugin.setContent(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM._addon_handle,'episodes')
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcpa(FOSGtujkgwiKbUEdVoNHhzBJqmLcAP)>0:xbmcplugin.endOfDirectory(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM._addon_handle,cacheToDisc=FOSGtujkgwiKbUEdVoNHhzBJqmLcps)
 def dp_setEpOrderby(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM,FOSGtujkgwiKbUEdVoNHhzBJqmLcWM):
  FOSGtujkgwiKbUEdVoNHhzBJqmLcAf =FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('orderby')
  FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.set_winEpisodeOrderby(FOSGtujkgwiKbUEdVoNHhzBJqmLcAf)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM,FOSGtujkgwiKbUEdVoNHhzBJqmLcWM):
  FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.TvingObj.SaveCredential(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.get_winCredential())
  FOSGtujkgwiKbUEdVoNHhzBJqmLcAr =FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('stype')
  FOSGtujkgwiKbUEdVoNHhzBJqmLcAf =FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('orderby')
  FOSGtujkgwiKbUEdVoNHhzBJqmLcWa=FOSGtujkgwiKbUEdVoNHhzBJqmLcpf(FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('page'))
  FOSGtujkgwiKbUEdVoNHhzBJqmLcXl,FOSGtujkgwiKbUEdVoNHhzBJqmLcWQ=FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.TvingObj.GetMovieList(FOSGtujkgwiKbUEdVoNHhzBJqmLcAr,FOSGtujkgwiKbUEdVoNHhzBJqmLcAf,FOSGtujkgwiKbUEdVoNHhzBJqmLcWa)
  for FOSGtujkgwiKbUEdVoNHhzBJqmLcXW in FOSGtujkgwiKbUEdVoNHhzBJqmLcXl:
   FOSGtujkgwiKbUEdVoNHhzBJqmLclM =FOSGtujkgwiKbUEdVoNHhzBJqmLcXW.get('title')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWe =FOSGtujkgwiKbUEdVoNHhzBJqmLcXW.get('thumbnail')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWP =FOSGtujkgwiKbUEdVoNHhzBJqmLcXW.get('synopsis')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcAI =FOSGtujkgwiKbUEdVoNHhzBJqmLcXW.get('info_title')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWv =FOSGtujkgwiKbUEdVoNHhzBJqmLcXW.get('year')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWn =FOSGtujkgwiKbUEdVoNHhzBJqmLcXW.get('cast')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWI =FOSGtujkgwiKbUEdVoNHhzBJqmLcXW.get('director')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWT =FOSGtujkgwiKbUEdVoNHhzBJqmLcXW.get('info_genre')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcXA =FOSGtujkgwiKbUEdVoNHhzBJqmLcXW.get('duration')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcAl =FOSGtujkgwiKbUEdVoNHhzBJqmLcXW.get('premiered')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcAv =FOSGtujkgwiKbUEdVoNHhzBJqmLcXW.get('studio')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcAx =FOSGtujkgwiKbUEdVoNHhzBJqmLcXW.get('mpaa')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcAW={'mediatype':'movie','title':FOSGtujkgwiKbUEdVoNHhzBJqmLcAI,'year':FOSGtujkgwiKbUEdVoNHhzBJqmLcWv,'cast':FOSGtujkgwiKbUEdVoNHhzBJqmLcWn,'director':FOSGtujkgwiKbUEdVoNHhzBJqmLcWI,'genre':FOSGtujkgwiKbUEdVoNHhzBJqmLcWT,'duration':FOSGtujkgwiKbUEdVoNHhzBJqmLcXA,'premiered':FOSGtujkgwiKbUEdVoNHhzBJqmLcAl,'studio':FOSGtujkgwiKbUEdVoNHhzBJqmLcAv,'mpaa':FOSGtujkgwiKbUEdVoNHhzBJqmLcAx,'plot':FOSGtujkgwiKbUEdVoNHhzBJqmLcWP}
   FOSGtujkgwiKbUEdVoNHhzBJqmLclD={'mode':'MOVIE','mediacode':FOSGtujkgwiKbUEdVoNHhzBJqmLcXW.get('moviecode'),'stype':'movie','title':FOSGtujkgwiKbUEdVoNHhzBJqmLclM,'thumbnail':FOSGtujkgwiKbUEdVoNHhzBJqmLcWe}
   if FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.get_settings_makebookmark():
    FOSGtujkgwiKbUEdVoNHhzBJqmLcAM={'videoid':FOSGtujkgwiKbUEdVoNHhzBJqmLcXW.get('moviecode'),'vidtype':'movie','vtitle':FOSGtujkgwiKbUEdVoNHhzBJqmLcAI,'vsubtitle':'',}
    FOSGtujkgwiKbUEdVoNHhzBJqmLcAa=json.dumps(FOSGtujkgwiKbUEdVoNHhzBJqmLcAM)
    FOSGtujkgwiKbUEdVoNHhzBJqmLcAa=urllib.parse.quote(FOSGtujkgwiKbUEdVoNHhzBJqmLcAa)
    FOSGtujkgwiKbUEdVoNHhzBJqmLcAY='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(FOSGtujkgwiKbUEdVoNHhzBJqmLcAa)
    FOSGtujkgwiKbUEdVoNHhzBJqmLcAQ=[('(통합) 찜 영상에 추가',FOSGtujkgwiKbUEdVoNHhzBJqmLcAY)]
   else:
    FOSGtujkgwiKbUEdVoNHhzBJqmLcAQ=FOSGtujkgwiKbUEdVoNHhzBJqmLcpr
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.add_dir(FOSGtujkgwiKbUEdVoNHhzBJqmLclM,sublabel='',img=FOSGtujkgwiKbUEdVoNHhzBJqmLcWe,infoLabels=FOSGtujkgwiKbUEdVoNHhzBJqmLcAW,isFolder=FOSGtujkgwiKbUEdVoNHhzBJqmLcpR,params=FOSGtujkgwiKbUEdVoNHhzBJqmLclD,ContextMenu=FOSGtujkgwiKbUEdVoNHhzBJqmLcAQ)
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcWQ:
   FOSGtujkgwiKbUEdVoNHhzBJqmLclD={}
   FOSGtujkgwiKbUEdVoNHhzBJqmLclD['mode'] ='MOVIE_SUB' 
   FOSGtujkgwiKbUEdVoNHhzBJqmLclD['orderby']=FOSGtujkgwiKbUEdVoNHhzBJqmLcAf
   FOSGtujkgwiKbUEdVoNHhzBJqmLclD['stype'] =FOSGtujkgwiKbUEdVoNHhzBJqmLcAr
   FOSGtujkgwiKbUEdVoNHhzBJqmLclD['page'] =FOSGtujkgwiKbUEdVoNHhzBJqmLcpY(FOSGtujkgwiKbUEdVoNHhzBJqmLcWa+1)
   FOSGtujkgwiKbUEdVoNHhzBJqmLclM='[B]%s >>[/B]'%'다음 페이지'
   FOSGtujkgwiKbUEdVoNHhzBJqmLcAX=FOSGtujkgwiKbUEdVoNHhzBJqmLcpY(FOSGtujkgwiKbUEdVoNHhzBJqmLcWa+1)
   FOSGtujkgwiKbUEdVoNHhzBJqmLclP=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.add_dir(FOSGtujkgwiKbUEdVoNHhzBJqmLclM,sublabel=FOSGtujkgwiKbUEdVoNHhzBJqmLcAX,img=FOSGtujkgwiKbUEdVoNHhzBJqmLclP,infoLabels=FOSGtujkgwiKbUEdVoNHhzBJqmLcpr,isFolder=FOSGtujkgwiKbUEdVoNHhzBJqmLcps,params=FOSGtujkgwiKbUEdVoNHhzBJqmLclD)
  xbmcplugin.setContent(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM._addon_handle,'movies')
  xbmcplugin.endOfDirectory(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM._addon_handle,cacheToDisc=FOSGtujkgwiKbUEdVoNHhzBJqmLcpR)
 def dp_Set_Bookmark(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM,FOSGtujkgwiKbUEdVoNHhzBJqmLcWM):
  FOSGtujkgwiKbUEdVoNHhzBJqmLcXr=urllib.parse.unquote(FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('bm_param'))
  FOSGtujkgwiKbUEdVoNHhzBJqmLcXr=json.loads(FOSGtujkgwiKbUEdVoNHhzBJqmLcXr)
  FOSGtujkgwiKbUEdVoNHhzBJqmLcXf =FOSGtujkgwiKbUEdVoNHhzBJqmLcXr.get('videoid')
  FOSGtujkgwiKbUEdVoNHhzBJqmLcXp =FOSGtujkgwiKbUEdVoNHhzBJqmLcXr.get('vidtype')
  FOSGtujkgwiKbUEdVoNHhzBJqmLcXs =FOSGtujkgwiKbUEdVoNHhzBJqmLcXr.get('vtitle')
  FOSGtujkgwiKbUEdVoNHhzBJqmLcXR =FOSGtujkgwiKbUEdVoNHhzBJqmLcXr.get('vsubtitle')
  FOSGtujkgwiKbUEdVoNHhzBJqmLcxe=xbmcgui.Dialog()
  FOSGtujkgwiKbUEdVoNHhzBJqmLcWX=FOSGtujkgwiKbUEdVoNHhzBJqmLcxe.yesno(__language__(30913).encode('utf8'),FOSGtujkgwiKbUEdVoNHhzBJqmLcXs+' \n\n'+__language__(30914))
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcWX==FOSGtujkgwiKbUEdVoNHhzBJqmLcpR:return
  FOSGtujkgwiKbUEdVoNHhzBJqmLcXy=FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.TvingObj.GetBookmarkInfo(FOSGtujkgwiKbUEdVoNHhzBJqmLcXf,FOSGtujkgwiKbUEdVoNHhzBJqmLcXp)
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcXR!='':
   FOSGtujkgwiKbUEdVoNHhzBJqmLcXy['saveinfo']['subtitle']=FOSGtujkgwiKbUEdVoNHhzBJqmLcXR 
   if FOSGtujkgwiKbUEdVoNHhzBJqmLcXp=='tvshow':FOSGtujkgwiKbUEdVoNHhzBJqmLcXy['saveinfo']['infoLabels']['studio']=FOSGtujkgwiKbUEdVoNHhzBJqmLcXR 
  FOSGtujkgwiKbUEdVoNHhzBJqmLcXM=json.dumps(FOSGtujkgwiKbUEdVoNHhzBJqmLcXy)
  FOSGtujkgwiKbUEdVoNHhzBJqmLcXM=urllib.parse.quote(FOSGtujkgwiKbUEdVoNHhzBJqmLcXM)
  FOSGtujkgwiKbUEdVoNHhzBJqmLcAY ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(FOSGtujkgwiKbUEdVoNHhzBJqmLcXM)
  xbmc.executebuiltin(FOSGtujkgwiKbUEdVoNHhzBJqmLcAY)
 def dp_Search_Group(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM,FOSGtujkgwiKbUEdVoNHhzBJqmLcWM):
  if 'search_key' in FOSGtujkgwiKbUEdVoNHhzBJqmLcWM:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcXa=FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('search_key')
  else:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcXa=FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not FOSGtujkgwiKbUEdVoNHhzBJqmLcXa:
    return
  for FOSGtujkgwiKbUEdVoNHhzBJqmLcWy in FOSGtujkgwiKbUEdVoNHhzBJqmLcxr:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcXY =FOSGtujkgwiKbUEdVoNHhzBJqmLcWy.get('mode')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWs=FOSGtujkgwiKbUEdVoNHhzBJqmLcWy.get('stype')
   FOSGtujkgwiKbUEdVoNHhzBJqmLclM=FOSGtujkgwiKbUEdVoNHhzBJqmLcWy.get('title')
   (FOSGtujkgwiKbUEdVoNHhzBJqmLcXQ,FOSGtujkgwiKbUEdVoNHhzBJqmLcWQ)=FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.TvingObj.GetSearchList(FOSGtujkgwiKbUEdVoNHhzBJqmLcXa,1,FOSGtujkgwiKbUEdVoNHhzBJqmLcWs)
   FOSGtujkgwiKbUEdVoNHhzBJqmLcXC={'plot':'검색어 : '+FOSGtujkgwiKbUEdVoNHhzBJqmLcXa+'\n\n'+FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.Search_FreeList(FOSGtujkgwiKbUEdVoNHhzBJqmLcXQ)}
   FOSGtujkgwiKbUEdVoNHhzBJqmLclD={'mode':FOSGtujkgwiKbUEdVoNHhzBJqmLcXY,'stype':FOSGtujkgwiKbUEdVoNHhzBJqmLcWs,'search_key':FOSGtujkgwiKbUEdVoNHhzBJqmLcXa,'page':'1',}
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.add_dir(FOSGtujkgwiKbUEdVoNHhzBJqmLclM,sublabel='',img='',infoLabels=FOSGtujkgwiKbUEdVoNHhzBJqmLcXC,isFolder=FOSGtujkgwiKbUEdVoNHhzBJqmLcps,params=FOSGtujkgwiKbUEdVoNHhzBJqmLclD)
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcpa(FOSGtujkgwiKbUEdVoNHhzBJqmLcxr)>0:xbmcplugin.endOfDirectory(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM._addon_handle,cacheToDisc=FOSGtujkgwiKbUEdVoNHhzBJqmLcps)
  FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.Save_Searched_List(FOSGtujkgwiKbUEdVoNHhzBJqmLcXa)
 def Search_FreeList(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM,FOSGtujkgwiKbUEdVoNHhzBJqmLcrl):
  FOSGtujkgwiKbUEdVoNHhzBJqmLcXe=''
  FOSGtujkgwiKbUEdVoNHhzBJqmLcXP=7
  try:
   if FOSGtujkgwiKbUEdVoNHhzBJqmLcpa(FOSGtujkgwiKbUEdVoNHhzBJqmLcrl)==0:return '검색결과 없음'
   for i in FOSGtujkgwiKbUEdVoNHhzBJqmLcpQ(FOSGtujkgwiKbUEdVoNHhzBJqmLcpa(FOSGtujkgwiKbUEdVoNHhzBJqmLcrl)):
    if i>=FOSGtujkgwiKbUEdVoNHhzBJqmLcXP:
     FOSGtujkgwiKbUEdVoNHhzBJqmLcXe=FOSGtujkgwiKbUEdVoNHhzBJqmLcXe+'...'
     break
    FOSGtujkgwiKbUEdVoNHhzBJqmLcXe=FOSGtujkgwiKbUEdVoNHhzBJqmLcXe+FOSGtujkgwiKbUEdVoNHhzBJqmLcrl[i]['title']+'\n'
  except:
   return ''
  return FOSGtujkgwiKbUEdVoNHhzBJqmLcXe
 def dp_Search_History(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM,FOSGtujkgwiKbUEdVoNHhzBJqmLcWM):
  FOSGtujkgwiKbUEdVoNHhzBJqmLcXD=FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.Load_List_File('search')
  for FOSGtujkgwiKbUEdVoNHhzBJqmLcXn in FOSGtujkgwiKbUEdVoNHhzBJqmLcXD:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcXI=FOSGtujkgwiKbUEdVoNHhzBJqmLcpM(urllib.parse.parse_qsl(FOSGtujkgwiKbUEdVoNHhzBJqmLcXn))
   FOSGtujkgwiKbUEdVoNHhzBJqmLcXT=FOSGtujkgwiKbUEdVoNHhzBJqmLcXI.get('skey').strip()
   FOSGtujkgwiKbUEdVoNHhzBJqmLclD={'mode':'SEARCH_GROUP','search_key':FOSGtujkgwiKbUEdVoNHhzBJqmLcXT,}
   FOSGtujkgwiKbUEdVoNHhzBJqmLcXv={'mode':'SEARCH_REMOVE','stype':'ONE','skey':FOSGtujkgwiKbUEdVoNHhzBJqmLcXT,}
   FOSGtujkgwiKbUEdVoNHhzBJqmLcrx=urllib.parse.urlencode(FOSGtujkgwiKbUEdVoNHhzBJqmLcXv)
   FOSGtujkgwiKbUEdVoNHhzBJqmLcAQ=[('선택된 검색어 ( %s ) 삭제'%(FOSGtujkgwiKbUEdVoNHhzBJqmLcXT),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(FOSGtujkgwiKbUEdVoNHhzBJqmLcrx))]
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.add_dir(FOSGtujkgwiKbUEdVoNHhzBJqmLcXT,sublabel='',img=FOSGtujkgwiKbUEdVoNHhzBJqmLcpr,infoLabels=FOSGtujkgwiKbUEdVoNHhzBJqmLcpr,isFolder=FOSGtujkgwiKbUEdVoNHhzBJqmLcps,params=FOSGtujkgwiKbUEdVoNHhzBJqmLclD,ContextMenu=FOSGtujkgwiKbUEdVoNHhzBJqmLcAQ)
  FOSGtujkgwiKbUEdVoNHhzBJqmLcAW={'plot':'검색목록 전체를 삭제합니다.'}
  FOSGtujkgwiKbUEdVoNHhzBJqmLclM='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  FOSGtujkgwiKbUEdVoNHhzBJqmLclD={'mode':'SEARCH_REMOVE','stype':'ALL','skey':'-',}
  FOSGtujkgwiKbUEdVoNHhzBJqmLclP=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.add_dir(FOSGtujkgwiKbUEdVoNHhzBJqmLclM,sublabel='',img=FOSGtujkgwiKbUEdVoNHhzBJqmLclP,infoLabels=FOSGtujkgwiKbUEdVoNHhzBJqmLcAW,isFolder=FOSGtujkgwiKbUEdVoNHhzBJqmLcpR,params=FOSGtujkgwiKbUEdVoNHhzBJqmLclD,isLink=FOSGtujkgwiKbUEdVoNHhzBJqmLcps)
  xbmcplugin.endOfDirectory(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM._addon_handle,cacheToDisc=FOSGtujkgwiKbUEdVoNHhzBJqmLcpR)
 def dp_Search_List(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM,FOSGtujkgwiKbUEdVoNHhzBJqmLcWM):
  FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.TvingObj.SaveCredential(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.get_winCredential())
  FOSGtujkgwiKbUEdVoNHhzBJqmLcWa =FOSGtujkgwiKbUEdVoNHhzBJqmLcpf(FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('page'))
  FOSGtujkgwiKbUEdVoNHhzBJqmLcWs =FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('stype')
  if 'search_key' in FOSGtujkgwiKbUEdVoNHhzBJqmLcWM:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcXa=FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('search_key')
  else:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcXa=FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not FOSGtujkgwiKbUEdVoNHhzBJqmLcXa:
    xbmcplugin.endOfDirectory(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM._addon_handle)
    return
  FOSGtujkgwiKbUEdVoNHhzBJqmLcXQ,FOSGtujkgwiKbUEdVoNHhzBJqmLcWQ=FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.TvingObj.GetSearchList(FOSGtujkgwiKbUEdVoNHhzBJqmLcXa,FOSGtujkgwiKbUEdVoNHhzBJqmLcWa,FOSGtujkgwiKbUEdVoNHhzBJqmLcWs)
  for FOSGtujkgwiKbUEdVoNHhzBJqmLcrl in FOSGtujkgwiKbUEdVoNHhzBJqmLcXQ:
   FOSGtujkgwiKbUEdVoNHhzBJqmLclM =FOSGtujkgwiKbUEdVoNHhzBJqmLcrl.get('title')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWe =FOSGtujkgwiKbUEdVoNHhzBJqmLcrl.get('thumbnail')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWP =FOSGtujkgwiKbUEdVoNHhzBJqmLcrl.get('synopsis')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcrW =FOSGtujkgwiKbUEdVoNHhzBJqmLcrl.get('program')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWn =FOSGtujkgwiKbUEdVoNHhzBJqmLcrl.get('cast')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWI =FOSGtujkgwiKbUEdVoNHhzBJqmLcrl.get('director')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWT=FOSGtujkgwiKbUEdVoNHhzBJqmLcrl.get('info_genre')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcXA =FOSGtujkgwiKbUEdVoNHhzBJqmLcrl.get('duration')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcAx =FOSGtujkgwiKbUEdVoNHhzBJqmLcrl.get('mpaa')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWv =FOSGtujkgwiKbUEdVoNHhzBJqmLcrl.get('year')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcAT =FOSGtujkgwiKbUEdVoNHhzBJqmLcrl.get('aired')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcAW={'mediatype':'tvshow' if FOSGtujkgwiKbUEdVoNHhzBJqmLcWs=='vod' else 'movie','title':FOSGtujkgwiKbUEdVoNHhzBJqmLclM,'cast':FOSGtujkgwiKbUEdVoNHhzBJqmLcWn,'director':FOSGtujkgwiKbUEdVoNHhzBJqmLcWI,'genre':FOSGtujkgwiKbUEdVoNHhzBJqmLcWT,'duration':FOSGtujkgwiKbUEdVoNHhzBJqmLcXA,'mpaa':FOSGtujkgwiKbUEdVoNHhzBJqmLcAx,'year':FOSGtujkgwiKbUEdVoNHhzBJqmLcWv,'aired':FOSGtujkgwiKbUEdVoNHhzBJqmLcAT,'plot':'%s\n\n%s'%(FOSGtujkgwiKbUEdVoNHhzBJqmLclM,FOSGtujkgwiKbUEdVoNHhzBJqmLcWP)}
   if FOSGtujkgwiKbUEdVoNHhzBJqmLcWs=='vod':
    FOSGtujkgwiKbUEdVoNHhzBJqmLcXf=FOSGtujkgwiKbUEdVoNHhzBJqmLcrl.get('program')
    FOSGtujkgwiKbUEdVoNHhzBJqmLcXp='tvshow'
    FOSGtujkgwiKbUEdVoNHhzBJqmLclD={'mode':'EPISODE','programcode':FOSGtujkgwiKbUEdVoNHhzBJqmLcXf,'page':'1',}
    FOSGtujkgwiKbUEdVoNHhzBJqmLcln=FOSGtujkgwiKbUEdVoNHhzBJqmLcps
   else:
    FOSGtujkgwiKbUEdVoNHhzBJqmLcXf=FOSGtujkgwiKbUEdVoNHhzBJqmLcrl.get('movie')
    FOSGtujkgwiKbUEdVoNHhzBJqmLcXp='movie'
    FOSGtujkgwiKbUEdVoNHhzBJqmLclD={'mode':'MOVIE','mediacode':FOSGtujkgwiKbUEdVoNHhzBJqmLcXf,'stype':'movie','title':FOSGtujkgwiKbUEdVoNHhzBJqmLclM,'thumbnail':FOSGtujkgwiKbUEdVoNHhzBJqmLcWe,}
    FOSGtujkgwiKbUEdVoNHhzBJqmLcln=FOSGtujkgwiKbUEdVoNHhzBJqmLcpR
   if FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.get_settings_makebookmark():
    FOSGtujkgwiKbUEdVoNHhzBJqmLcAM={'videoid':FOSGtujkgwiKbUEdVoNHhzBJqmLcXf,'vidtype':FOSGtujkgwiKbUEdVoNHhzBJqmLcXp,'vtitle':FOSGtujkgwiKbUEdVoNHhzBJqmLclM,'vsubtitle':'',}
    FOSGtujkgwiKbUEdVoNHhzBJqmLcAa=json.dumps(FOSGtujkgwiKbUEdVoNHhzBJqmLcAM)
    FOSGtujkgwiKbUEdVoNHhzBJqmLcAa=urllib.parse.quote(FOSGtujkgwiKbUEdVoNHhzBJqmLcAa)
    FOSGtujkgwiKbUEdVoNHhzBJqmLcAY='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(FOSGtujkgwiKbUEdVoNHhzBJqmLcAa)
    FOSGtujkgwiKbUEdVoNHhzBJqmLcAQ=[('(통합) 찜 영상에 추가',FOSGtujkgwiKbUEdVoNHhzBJqmLcAY)]
   else:
    FOSGtujkgwiKbUEdVoNHhzBJqmLcAQ=FOSGtujkgwiKbUEdVoNHhzBJqmLcpr
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.add_dir(FOSGtujkgwiKbUEdVoNHhzBJqmLclM,sublabel='',img=FOSGtujkgwiKbUEdVoNHhzBJqmLcWe,infoLabels=FOSGtujkgwiKbUEdVoNHhzBJqmLcAW,isFolder=FOSGtujkgwiKbUEdVoNHhzBJqmLcln,params=FOSGtujkgwiKbUEdVoNHhzBJqmLclD,isLink=FOSGtujkgwiKbUEdVoNHhzBJqmLcpR,ContextMenu=FOSGtujkgwiKbUEdVoNHhzBJqmLcAQ)
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcWQ:
   FOSGtujkgwiKbUEdVoNHhzBJqmLclD['mode'] ='SEARCH' 
   FOSGtujkgwiKbUEdVoNHhzBJqmLclD['search_key']=FOSGtujkgwiKbUEdVoNHhzBJqmLcXa
   FOSGtujkgwiKbUEdVoNHhzBJqmLclD['page'] =FOSGtujkgwiKbUEdVoNHhzBJqmLcpY(FOSGtujkgwiKbUEdVoNHhzBJqmLcWa+1)
   FOSGtujkgwiKbUEdVoNHhzBJqmLclM='[B]%s >>[/B]'%'다음 페이지'
   FOSGtujkgwiKbUEdVoNHhzBJqmLcAX=FOSGtujkgwiKbUEdVoNHhzBJqmLcpY(FOSGtujkgwiKbUEdVoNHhzBJqmLcWa+1)
   FOSGtujkgwiKbUEdVoNHhzBJqmLclP=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.add_dir(FOSGtujkgwiKbUEdVoNHhzBJqmLclM,sublabel=FOSGtujkgwiKbUEdVoNHhzBJqmLcAX,img=FOSGtujkgwiKbUEdVoNHhzBJqmLclP,infoLabels=FOSGtujkgwiKbUEdVoNHhzBJqmLcpr,isFolder=FOSGtujkgwiKbUEdVoNHhzBJqmLcps,params=FOSGtujkgwiKbUEdVoNHhzBJqmLclD)
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcWs=='movie':xbmcplugin.setContent(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM._addon_handle,'movies')
  else:xbmcplugin.setContent(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM._addon_handle,cacheToDisc=FOSGtujkgwiKbUEdVoNHhzBJqmLcpR)
 def Delete_List_File(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM,FOSGtujkgwiKbUEdVoNHhzBJqmLcWs,skey='-'):
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcWs=='ALL':
   try:
    FOSGtujkgwiKbUEdVoNHhzBJqmLcrA=FOSGtujkgwiKbUEdVoNHhzBJqmLcxy
    fp=FOSGtujkgwiKbUEdVoNHhzBJqmLcpC(FOSGtujkgwiKbUEdVoNHhzBJqmLcrA,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    FOSGtujkgwiKbUEdVoNHhzBJqmLcpr
  elif FOSGtujkgwiKbUEdVoNHhzBJqmLcWs=='ONE':
   try:
    FOSGtujkgwiKbUEdVoNHhzBJqmLcrA=FOSGtujkgwiKbUEdVoNHhzBJqmLcxy
    FOSGtujkgwiKbUEdVoNHhzBJqmLcrX=FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.Load_List_File('search') 
    fp=FOSGtujkgwiKbUEdVoNHhzBJqmLcpC(FOSGtujkgwiKbUEdVoNHhzBJqmLcrA,'w',-1,'utf-8')
    for FOSGtujkgwiKbUEdVoNHhzBJqmLcrf in FOSGtujkgwiKbUEdVoNHhzBJqmLcrX:
     FOSGtujkgwiKbUEdVoNHhzBJqmLcrp=FOSGtujkgwiKbUEdVoNHhzBJqmLcpM(urllib.parse.parse_qsl(FOSGtujkgwiKbUEdVoNHhzBJqmLcrf))
     FOSGtujkgwiKbUEdVoNHhzBJqmLcrs=FOSGtujkgwiKbUEdVoNHhzBJqmLcrp.get('skey').strip()
     if skey!=FOSGtujkgwiKbUEdVoNHhzBJqmLcrs:
      fp.write(FOSGtujkgwiKbUEdVoNHhzBJqmLcrf)
    fp.close()
   except:
    FOSGtujkgwiKbUEdVoNHhzBJqmLcpr
  elif FOSGtujkgwiKbUEdVoNHhzBJqmLcWs in['vod','movie']:
   try:
    FOSGtujkgwiKbUEdVoNHhzBJqmLcrA=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%FOSGtujkgwiKbUEdVoNHhzBJqmLcWs))
    fp=FOSGtujkgwiKbUEdVoNHhzBJqmLcpC(FOSGtujkgwiKbUEdVoNHhzBJqmLcrA,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    FOSGtujkgwiKbUEdVoNHhzBJqmLcpr
 def dp_Listfile_Delete(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM,FOSGtujkgwiKbUEdVoNHhzBJqmLcWM):
  FOSGtujkgwiKbUEdVoNHhzBJqmLcWs=FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('stype')
  FOSGtujkgwiKbUEdVoNHhzBJqmLcXT =FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('skey')
  FOSGtujkgwiKbUEdVoNHhzBJqmLcxe=xbmcgui.Dialog()
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcWs=='ALL':
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWX=FOSGtujkgwiKbUEdVoNHhzBJqmLcxe.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif FOSGtujkgwiKbUEdVoNHhzBJqmLcWs=='ONE':
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWX=FOSGtujkgwiKbUEdVoNHhzBJqmLcxe.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif FOSGtujkgwiKbUEdVoNHhzBJqmLcWs in['vod','movie']:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcWX=FOSGtujkgwiKbUEdVoNHhzBJqmLcxe.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcWX==FOSGtujkgwiKbUEdVoNHhzBJqmLcpR:sys.exit()
  FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.Delete_List_File(FOSGtujkgwiKbUEdVoNHhzBJqmLcWs,skey=FOSGtujkgwiKbUEdVoNHhzBJqmLcXT)
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM,FOSGtujkgwiKbUEdVoNHhzBJqmLcWs): 
  try:
   if FOSGtujkgwiKbUEdVoNHhzBJqmLcWs=='search':
    FOSGtujkgwiKbUEdVoNHhzBJqmLcrA=FOSGtujkgwiKbUEdVoNHhzBJqmLcxy
   elif FOSGtujkgwiKbUEdVoNHhzBJqmLcWs in['vod','movie']:
    FOSGtujkgwiKbUEdVoNHhzBJqmLcrA=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%FOSGtujkgwiKbUEdVoNHhzBJqmLcWs))
   else:
    return[]
   fp=FOSGtujkgwiKbUEdVoNHhzBJqmLcpC(FOSGtujkgwiKbUEdVoNHhzBJqmLcrA,'r',-1,'utf-8')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcrR=fp.readlines()
   fp.close()
  except:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcrR=[]
  return FOSGtujkgwiKbUEdVoNHhzBJqmLcrR
 def Save_Watched_List(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM,FOSGtujkgwiKbUEdVoNHhzBJqmLcWs,FOSGtujkgwiKbUEdVoNHhzBJqmLcxQ):
  try:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcry=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%FOSGtujkgwiKbUEdVoNHhzBJqmLcWs))
   FOSGtujkgwiKbUEdVoNHhzBJqmLcrX=FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.Load_List_File(FOSGtujkgwiKbUEdVoNHhzBJqmLcWs) 
   fp=FOSGtujkgwiKbUEdVoNHhzBJqmLcpC(FOSGtujkgwiKbUEdVoNHhzBJqmLcry,'w',-1,'utf-8')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcrM=urllib.parse.urlencode(FOSGtujkgwiKbUEdVoNHhzBJqmLcxQ)
   FOSGtujkgwiKbUEdVoNHhzBJqmLcrM=FOSGtujkgwiKbUEdVoNHhzBJqmLcrM+'\n'
   fp.write(FOSGtujkgwiKbUEdVoNHhzBJqmLcrM)
   FOSGtujkgwiKbUEdVoNHhzBJqmLcra=0
   for FOSGtujkgwiKbUEdVoNHhzBJqmLcrf in FOSGtujkgwiKbUEdVoNHhzBJqmLcrX:
    FOSGtujkgwiKbUEdVoNHhzBJqmLcrp=FOSGtujkgwiKbUEdVoNHhzBJqmLcpM(urllib.parse.parse_qsl(FOSGtujkgwiKbUEdVoNHhzBJqmLcrf))
    FOSGtujkgwiKbUEdVoNHhzBJqmLcrY=FOSGtujkgwiKbUEdVoNHhzBJqmLcxQ.get('code').strip()
    FOSGtujkgwiKbUEdVoNHhzBJqmLcrQ=FOSGtujkgwiKbUEdVoNHhzBJqmLcrp.get('code').strip()
    if FOSGtujkgwiKbUEdVoNHhzBJqmLcWs=='vod' and FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.get_settings_direct_replay()==FOSGtujkgwiKbUEdVoNHhzBJqmLcps:
     FOSGtujkgwiKbUEdVoNHhzBJqmLcrY=FOSGtujkgwiKbUEdVoNHhzBJqmLcxQ.get('videoid').strip()
     FOSGtujkgwiKbUEdVoNHhzBJqmLcrQ=FOSGtujkgwiKbUEdVoNHhzBJqmLcrp.get('videoid').strip()if FOSGtujkgwiKbUEdVoNHhzBJqmLcrQ!=FOSGtujkgwiKbUEdVoNHhzBJqmLcpr else '-'
    if FOSGtujkgwiKbUEdVoNHhzBJqmLcrY!=FOSGtujkgwiKbUEdVoNHhzBJqmLcrQ:
     fp.write(FOSGtujkgwiKbUEdVoNHhzBJqmLcrf)
     FOSGtujkgwiKbUEdVoNHhzBJqmLcra+=1
     if FOSGtujkgwiKbUEdVoNHhzBJqmLcra>=50:break
   fp.close()
  except:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcpr
 def dp_Watch_List(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM,FOSGtujkgwiKbUEdVoNHhzBJqmLcWM):
  FOSGtujkgwiKbUEdVoNHhzBJqmLcWs =FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('stype')
  FOSGtujkgwiKbUEdVoNHhzBJqmLclp=FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.get_settings_direct_replay()
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcWs=='-':
   for FOSGtujkgwiKbUEdVoNHhzBJqmLcWy in FOSGtujkgwiKbUEdVoNHhzBJqmLcxX:
    FOSGtujkgwiKbUEdVoNHhzBJqmLclM=FOSGtujkgwiKbUEdVoNHhzBJqmLcWy.get('title')
    FOSGtujkgwiKbUEdVoNHhzBJqmLclD={'mode':FOSGtujkgwiKbUEdVoNHhzBJqmLcWy.get('mode'),'stype':FOSGtujkgwiKbUEdVoNHhzBJqmLcWy.get('stype')}
    FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.add_dir(FOSGtujkgwiKbUEdVoNHhzBJqmLclM,sublabel='',img='',infoLabels=FOSGtujkgwiKbUEdVoNHhzBJqmLcpr,isFolder=FOSGtujkgwiKbUEdVoNHhzBJqmLcps,params=FOSGtujkgwiKbUEdVoNHhzBJqmLclD)
   if FOSGtujkgwiKbUEdVoNHhzBJqmLcpa(FOSGtujkgwiKbUEdVoNHhzBJqmLcxX)>0:xbmcplugin.endOfDirectory(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM._addon_handle)
  else:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcrC=FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.Load_List_File(FOSGtujkgwiKbUEdVoNHhzBJqmLcWs)
   for FOSGtujkgwiKbUEdVoNHhzBJqmLcre in FOSGtujkgwiKbUEdVoNHhzBJqmLcrC:
    FOSGtujkgwiKbUEdVoNHhzBJqmLcXI=FOSGtujkgwiKbUEdVoNHhzBJqmLcpM(urllib.parse.parse_qsl(FOSGtujkgwiKbUEdVoNHhzBJqmLcre))
    FOSGtujkgwiKbUEdVoNHhzBJqmLcrP =FOSGtujkgwiKbUEdVoNHhzBJqmLcXI.get('code').strip()
    FOSGtujkgwiKbUEdVoNHhzBJqmLclM =FOSGtujkgwiKbUEdVoNHhzBJqmLcXI.get('title').strip()
    FOSGtujkgwiKbUEdVoNHhzBJqmLcWe=FOSGtujkgwiKbUEdVoNHhzBJqmLcXI.get('img').strip()
    FOSGtujkgwiKbUEdVoNHhzBJqmLcXf =FOSGtujkgwiKbUEdVoNHhzBJqmLcXI.get('videoid').strip()
    try:
     FOSGtujkgwiKbUEdVoNHhzBJqmLcWe=FOSGtujkgwiKbUEdVoNHhzBJqmLcWe.replace('\'','\"')
     FOSGtujkgwiKbUEdVoNHhzBJqmLcWe=json.loads(FOSGtujkgwiKbUEdVoNHhzBJqmLcWe)
    except:
     FOSGtujkgwiKbUEdVoNHhzBJqmLcpr
    FOSGtujkgwiKbUEdVoNHhzBJqmLcAW={}
    FOSGtujkgwiKbUEdVoNHhzBJqmLcAW['plot']=FOSGtujkgwiKbUEdVoNHhzBJqmLclM
    if FOSGtujkgwiKbUEdVoNHhzBJqmLcWs=='vod':
     if FOSGtujkgwiKbUEdVoNHhzBJqmLclp==FOSGtujkgwiKbUEdVoNHhzBJqmLcpR or FOSGtujkgwiKbUEdVoNHhzBJqmLcXf==FOSGtujkgwiKbUEdVoNHhzBJqmLcpr:
      FOSGtujkgwiKbUEdVoNHhzBJqmLclD={'mode':'EPISODE','programcode':FOSGtujkgwiKbUEdVoNHhzBJqmLcrP,'page':'1'}
      FOSGtujkgwiKbUEdVoNHhzBJqmLcln=FOSGtujkgwiKbUEdVoNHhzBJqmLcps
     else:
      FOSGtujkgwiKbUEdVoNHhzBJqmLclD={'mode':'VOD','mediacode':FOSGtujkgwiKbUEdVoNHhzBJqmLcXf,'stype':'vod','programcode':FOSGtujkgwiKbUEdVoNHhzBJqmLcrP,'title':FOSGtujkgwiKbUEdVoNHhzBJqmLclM,'thumbnail':FOSGtujkgwiKbUEdVoNHhzBJqmLcWe}
      FOSGtujkgwiKbUEdVoNHhzBJqmLcln=FOSGtujkgwiKbUEdVoNHhzBJqmLcpR
    else:
     FOSGtujkgwiKbUEdVoNHhzBJqmLclD={'mode':'MOVIE','mediacode':FOSGtujkgwiKbUEdVoNHhzBJqmLcrP,'stype':'movie','title':FOSGtujkgwiKbUEdVoNHhzBJqmLclM,'thumbnail':FOSGtujkgwiKbUEdVoNHhzBJqmLcWe}
     FOSGtujkgwiKbUEdVoNHhzBJqmLcln=FOSGtujkgwiKbUEdVoNHhzBJqmLcpR
    FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.add_dir(FOSGtujkgwiKbUEdVoNHhzBJqmLclM,sublabel='',img=FOSGtujkgwiKbUEdVoNHhzBJqmLcWe,infoLabels=FOSGtujkgwiKbUEdVoNHhzBJqmLcAW,isFolder=FOSGtujkgwiKbUEdVoNHhzBJqmLcln,params=FOSGtujkgwiKbUEdVoNHhzBJqmLclD)
   FOSGtujkgwiKbUEdVoNHhzBJqmLcAW={'plot':'시청목록을 삭제합니다.'}
   FOSGtujkgwiKbUEdVoNHhzBJqmLclM='*** 시청목록 삭제 ***'
   FOSGtujkgwiKbUEdVoNHhzBJqmLclD={'mode':'MYVIEW_REMOVE','stype':FOSGtujkgwiKbUEdVoNHhzBJqmLcWs,'skey':'-',}
   FOSGtujkgwiKbUEdVoNHhzBJqmLclP=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.add_dir(FOSGtujkgwiKbUEdVoNHhzBJqmLclM,sublabel='',img=FOSGtujkgwiKbUEdVoNHhzBJqmLclP,infoLabels=FOSGtujkgwiKbUEdVoNHhzBJqmLcAW,isFolder=FOSGtujkgwiKbUEdVoNHhzBJqmLcpR,params=FOSGtujkgwiKbUEdVoNHhzBJqmLclD,isLink=FOSGtujkgwiKbUEdVoNHhzBJqmLcps)
   if FOSGtujkgwiKbUEdVoNHhzBJqmLcWs=='movie':xbmcplugin.setContent(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM._addon_handle,'movies')
   else:xbmcplugin.setContent(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM._addon_handle,cacheToDisc=FOSGtujkgwiKbUEdVoNHhzBJqmLcpR)
 def Save_Searched_List(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM,FOSGtujkgwiKbUEdVoNHhzBJqmLcXa):
  try:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcrD=FOSGtujkgwiKbUEdVoNHhzBJqmLcxy
   FOSGtujkgwiKbUEdVoNHhzBJqmLcrX=FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.Load_List_File('search') 
   FOSGtujkgwiKbUEdVoNHhzBJqmLcrn={'skey':FOSGtujkgwiKbUEdVoNHhzBJqmLcXa.strip()}
   fp=FOSGtujkgwiKbUEdVoNHhzBJqmLcpC(FOSGtujkgwiKbUEdVoNHhzBJqmLcrD,'w',-1,'utf-8')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcrM=urllib.parse.urlencode(FOSGtujkgwiKbUEdVoNHhzBJqmLcrn)
   FOSGtujkgwiKbUEdVoNHhzBJqmLcrM=FOSGtujkgwiKbUEdVoNHhzBJqmLcrM+'\n'
   fp.write(FOSGtujkgwiKbUEdVoNHhzBJqmLcrM)
   FOSGtujkgwiKbUEdVoNHhzBJqmLcra=0
   for FOSGtujkgwiKbUEdVoNHhzBJqmLcrf in FOSGtujkgwiKbUEdVoNHhzBJqmLcrX:
    FOSGtujkgwiKbUEdVoNHhzBJqmLcrp=FOSGtujkgwiKbUEdVoNHhzBJqmLcpM(urllib.parse.parse_qsl(FOSGtujkgwiKbUEdVoNHhzBJqmLcrf))
    FOSGtujkgwiKbUEdVoNHhzBJqmLcrY=FOSGtujkgwiKbUEdVoNHhzBJqmLcrn.get('skey').strip()
    FOSGtujkgwiKbUEdVoNHhzBJqmLcrQ=FOSGtujkgwiKbUEdVoNHhzBJqmLcrp.get('skey').strip()
    if FOSGtujkgwiKbUEdVoNHhzBJqmLcrY!=FOSGtujkgwiKbUEdVoNHhzBJqmLcrQ:
     fp.write(FOSGtujkgwiKbUEdVoNHhzBJqmLcrf)
     FOSGtujkgwiKbUEdVoNHhzBJqmLcra+=1
     if FOSGtujkgwiKbUEdVoNHhzBJqmLcra>=50:break
   fp.close()
  except:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcpr
 def play_VIDEO(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM,FOSGtujkgwiKbUEdVoNHhzBJqmLcWM):
  FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.TvingObj.SaveCredential(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.get_winCredential())
  FOSGtujkgwiKbUEdVoNHhzBJqmLcrI =FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('mediacode')
  FOSGtujkgwiKbUEdVoNHhzBJqmLcWs =FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('stype')
  FOSGtujkgwiKbUEdVoNHhzBJqmLcrT =FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('pvrmode')
  FOSGtujkgwiKbUEdVoNHhzBJqmLcrv=FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.get_selQuality(FOSGtujkgwiKbUEdVoNHhzBJqmLcWs)
  FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(FOSGtujkgwiKbUEdVoNHhzBJqmLcrI,FOSGtujkgwiKbUEdVoNHhzBJqmLcpY(FOSGtujkgwiKbUEdVoNHhzBJqmLcrv),FOSGtujkgwiKbUEdVoNHhzBJqmLcWs,FOSGtujkgwiKbUEdVoNHhzBJqmLcrT))
  FOSGtujkgwiKbUEdVoNHhzBJqmLcfx=FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.TvingObj.GetBroadURL(FOSGtujkgwiKbUEdVoNHhzBJqmLcrI,FOSGtujkgwiKbUEdVoNHhzBJqmLcrv,FOSGtujkgwiKbUEdVoNHhzBJqmLcWs,FOSGtujkgwiKbUEdVoNHhzBJqmLcrT)
  FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.addon_log('qt, stype, url : %s - %s - %s'%(FOSGtujkgwiKbUEdVoNHhzBJqmLcpY(FOSGtujkgwiKbUEdVoNHhzBJqmLcrv),FOSGtujkgwiKbUEdVoNHhzBJqmLcWs,FOSGtujkgwiKbUEdVoNHhzBJqmLcfx['streaming_url']))
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcfx['streaming_url']=='':
   if FOSGtujkgwiKbUEdVoNHhzBJqmLcfx['error_msg']=='':
    FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.addon_noti(__language__(30908).encode('utf8'))
   else:
    FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.addon_noti(FOSGtujkgwiKbUEdVoNHhzBJqmLcfx['error_msg'].encode('utf8'))
   return
  FOSGtujkgwiKbUEdVoNHhzBJqmLcfl='user-agent={}'.format(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.TvingObj.USER_AGENT)
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcfx['watermark'] !='':
   FOSGtujkgwiKbUEdVoNHhzBJqmLcfl='{}&x-tving-param1={}&x-tving-param2={}'.format(FOSGtujkgwiKbUEdVoNHhzBJqmLcfl,FOSGtujkgwiKbUEdVoNHhzBJqmLcfx['watermarkKey'],FOSGtujkgwiKbUEdVoNHhzBJqmLcfx['watermark'])
  FOSGtujkgwiKbUEdVoNHhzBJqmLcfW =FOSGtujkgwiKbUEdVoNHhzBJqmLcpR
  FOSGtujkgwiKbUEdVoNHhzBJqmLcfA =FOSGtujkgwiKbUEdVoNHhzBJqmLcfx['streaming_url'].find('Policy=')
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcfA!=-1:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcfX =FOSGtujkgwiKbUEdVoNHhzBJqmLcfx['streaming_url'].split('?')[0]
   FOSGtujkgwiKbUEdVoNHhzBJqmLcfr=FOSGtujkgwiKbUEdVoNHhzBJqmLcpM(urllib.parse.parse_qsl(urllib.parse.urlsplit(FOSGtujkgwiKbUEdVoNHhzBJqmLcfx['streaming_url']).query))
   FOSGtujkgwiKbUEdVoNHhzBJqmLcfp='CloudFront-Policy=%s;CloudFront-Signature=%s;CloudFront-Key-Pair-Id=%s'%(FOSGtujkgwiKbUEdVoNHhzBJqmLcfr['Policy'],FOSGtujkgwiKbUEdVoNHhzBJqmLcfr['Signature'],FOSGtujkgwiKbUEdVoNHhzBJqmLcfr['Key-Pair-Id'])
   if 'quickvod-mcdn.tving.com' in FOSGtujkgwiKbUEdVoNHhzBJqmLcfX:
    FOSGtujkgwiKbUEdVoNHhzBJqmLcfW=FOSGtujkgwiKbUEdVoNHhzBJqmLcps
    FOSGtujkgwiKbUEdVoNHhzBJqmLcfs =FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    FOSGtujkgwiKbUEdVoNHhzBJqmLcfR=FOSGtujkgwiKbUEdVoNHhzBJqmLcfs.strftime('%Y-%m-%d-%H:%M:%S')
    if FOSGtujkgwiKbUEdVoNHhzBJqmLcpf(FOSGtujkgwiKbUEdVoNHhzBJqmLcfR.replace('-','').replace(':',''))<FOSGtujkgwiKbUEdVoNHhzBJqmLcpf(FOSGtujkgwiKbUEdVoNHhzBJqmLcfr['end'].replace('-','').replace(':','')):
     FOSGtujkgwiKbUEdVoNHhzBJqmLcfr['end']=FOSGtujkgwiKbUEdVoNHhzBJqmLcfR
     FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.addon_noti(__language__(30915).encode('utf8'))
    FOSGtujkgwiKbUEdVoNHhzBJqmLcfX ='%s?%s'%(FOSGtujkgwiKbUEdVoNHhzBJqmLcfX,urllib.parse.urlencode(FOSGtujkgwiKbUEdVoNHhzBJqmLcfr,doseq=FOSGtujkgwiKbUEdVoNHhzBJqmLcps))
   FOSGtujkgwiKbUEdVoNHhzBJqmLcfy='{}|{}&Cookie={}'.format(FOSGtujkgwiKbUEdVoNHhzBJqmLcfX,FOSGtujkgwiKbUEdVoNHhzBJqmLcfl,FOSGtujkgwiKbUEdVoNHhzBJqmLcfp)
  else:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcfy=FOSGtujkgwiKbUEdVoNHhzBJqmLcfx['streaming_url']+'|'+FOSGtujkgwiKbUEdVoNHhzBJqmLcfl
  FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.addon_log(FOSGtujkgwiKbUEdVoNHhzBJqmLcfy)
  FOSGtujkgwiKbUEdVoNHhzBJqmLcfM=xbmcgui.ListItem(path=FOSGtujkgwiKbUEdVoNHhzBJqmLcfy)
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcfx['drm_license']!='':
   FOSGtujkgwiKbUEdVoNHhzBJqmLcfa=FOSGtujkgwiKbUEdVoNHhzBJqmLcfx['drm_license']
   FOSGtujkgwiKbUEdVoNHhzBJqmLcfY ='https://cj.drmkeyserver.com/widevine_license'
   FOSGtujkgwiKbUEdVoNHhzBJqmLcfQ ='mpd'
   FOSGtujkgwiKbUEdVoNHhzBJqmLcfC ='com.widevine.alpha'
   FOSGtujkgwiKbUEdVoNHhzBJqmLcfe =inputstreamhelper.Helper(FOSGtujkgwiKbUEdVoNHhzBJqmLcfQ,drm='widevine')
   if FOSGtujkgwiKbUEdVoNHhzBJqmLcfe.check_inputstream():
    FOSGtujkgwiKbUEdVoNHhzBJqmLcfP={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.TvingObj.USER_AGENT,'AcquireLicenseAssertion':FOSGtujkgwiKbUEdVoNHhzBJqmLcfa,'Host':'cj.drmkeyserver.com',}
    FOSGtujkgwiKbUEdVoNHhzBJqmLcfD=FOSGtujkgwiKbUEdVoNHhzBJqmLcfY+'|'+urllib.parse.urlencode(FOSGtujkgwiKbUEdVoNHhzBJqmLcfP)+'|R{SSM}|'
    FOSGtujkgwiKbUEdVoNHhzBJqmLcfM.setProperty('inputstream',FOSGtujkgwiKbUEdVoNHhzBJqmLcfe.inputstream_addon)
    FOSGtujkgwiKbUEdVoNHhzBJqmLcfM.setProperty('inputstream.adaptive.manifest_type',FOSGtujkgwiKbUEdVoNHhzBJqmLcfQ)
    FOSGtujkgwiKbUEdVoNHhzBJqmLcfM.setProperty('inputstream.adaptive.license_type',FOSGtujkgwiKbUEdVoNHhzBJqmLcfC)
    FOSGtujkgwiKbUEdVoNHhzBJqmLcfM.setProperty('inputstream.adaptive.license_key',FOSGtujkgwiKbUEdVoNHhzBJqmLcfD)
    FOSGtujkgwiKbUEdVoNHhzBJqmLcfM.setProperty('inputstream.adaptive.stream_headers',FOSGtujkgwiKbUEdVoNHhzBJqmLcfl)
  elif FOSGtujkgwiKbUEdVoNHhzBJqmLcfW==FOSGtujkgwiKbUEdVoNHhzBJqmLcps:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcfM.setContentLookup(FOSGtujkgwiKbUEdVoNHhzBJqmLcpR)
   FOSGtujkgwiKbUEdVoNHhzBJqmLcfM.setMimeType('application/x-mpegURL')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcfM.setProperty('inputstream','inputstream.ffmpegdirect')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcfM.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcfM.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcfM.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcfM.setProperty('ResumeTime','0')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcfM.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM._addon_handle,FOSGtujkgwiKbUEdVoNHhzBJqmLcps,FOSGtujkgwiKbUEdVoNHhzBJqmLcfM)
  try:
   if FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('mode')in['VOD','MOVIE']and FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('title'):
    FOSGtujkgwiKbUEdVoNHhzBJqmLclD={'code':FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('programcode')if FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('mode')=='VOD' else FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('mediacode'),'img':FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('thumbnail'),'title':FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('title'),'videoid':FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('mediacode')}
    FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.Save_Watched_List(FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('stype'),FOSGtujkgwiKbUEdVoNHhzBJqmLclD)
  except:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcpr
 def logout(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM):
  FOSGtujkgwiKbUEdVoNHhzBJqmLcxe=xbmcgui.Dialog()
  FOSGtujkgwiKbUEdVoNHhzBJqmLcWX=FOSGtujkgwiKbUEdVoNHhzBJqmLcxe.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcWX==FOSGtujkgwiKbUEdVoNHhzBJqmLcpR:sys.exit()
  FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.wininfo_clear()
  if os.path.isfile(FOSGtujkgwiKbUEdVoNHhzBJqmLcxR):os.remove(FOSGtujkgwiKbUEdVoNHhzBJqmLcxR)
  FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM):
  FOSGtujkgwiKbUEdVoNHhzBJqmLcls=xbmcgui.Window(10000)
  FOSGtujkgwiKbUEdVoNHhzBJqmLcls.setProperty('TVING_M_TOKEN','')
  FOSGtujkgwiKbUEdVoNHhzBJqmLcls.setProperty('TVING_M_USERINFO','')
  FOSGtujkgwiKbUEdVoNHhzBJqmLcls.setProperty('TVING_M_UUID','')
  FOSGtujkgwiKbUEdVoNHhzBJqmLcls.setProperty('TVING_M_LOGINTIME','')
  FOSGtujkgwiKbUEdVoNHhzBJqmLcls.setProperty('TVING_M_MAINTOKEN','')
  FOSGtujkgwiKbUEdVoNHhzBJqmLcls.setProperty('TVING_M_COOKIEKEY','')
  FOSGtujkgwiKbUEdVoNHhzBJqmLcls.setProperty('TVING_M_LOCKKEY','')
 def cookiefile_save(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM):
  FOSGtujkgwiKbUEdVoNHhzBJqmLcfn =FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.TvingObj.Get_Now_Datetime()
  FOSGtujkgwiKbUEdVoNHhzBJqmLcfI=FOSGtujkgwiKbUEdVoNHhzBJqmLcfn+datetime.timedelta(days=FOSGtujkgwiKbUEdVoNHhzBJqmLcpf(__addon__.getSetting('cache_ttl')))
  FOSGtujkgwiKbUEdVoNHhzBJqmLcls=xbmcgui.Window(10000)
  FOSGtujkgwiKbUEdVoNHhzBJqmLcfT={'tving_token':FOSGtujkgwiKbUEdVoNHhzBJqmLcls.getProperty('TVING_M_TOKEN'),'tving_userinfo':FOSGtujkgwiKbUEdVoNHhzBJqmLcls.getProperty('TVING_M_USERINFO'),'tving_uuid':FOSGtujkgwiKbUEdVoNHhzBJqmLcls.getProperty('TVING_M_UUID'),'tving_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'tving_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'tving_logintype':__addon__.getSetting('login_type'),'tving_profile':__addon__.getSetting('selected_profile'),'tving_limitdate':FOSGtujkgwiKbUEdVoNHhzBJqmLcfI.strftime('%Y-%m-%d'),'tving_maintoken':FOSGtujkgwiKbUEdVoNHhzBJqmLcls.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':FOSGtujkgwiKbUEdVoNHhzBJqmLcls.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':FOSGtujkgwiKbUEdVoNHhzBJqmLcls.getProperty('TVING_M_LOCKKEY')}
  fp=FOSGtujkgwiKbUEdVoNHhzBJqmLcpC(FOSGtujkgwiKbUEdVoNHhzBJqmLcxR,'w',-1,'utf-8')
  json.dump(FOSGtujkgwiKbUEdVoNHhzBJqmLcfT,fp,indent=4,ensure_ascii=FOSGtujkgwiKbUEdVoNHhzBJqmLcpR)
  fp.close()
 def cookiefile_check(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM):
  FOSGtujkgwiKbUEdVoNHhzBJqmLcfT={}
  try: 
   fp=FOSGtujkgwiKbUEdVoNHhzBJqmLcpC(FOSGtujkgwiKbUEdVoNHhzBJqmLcxR,'r',-1,'utf-8')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcfT= json.load(fp)
   fp.close()
  except FOSGtujkgwiKbUEdVoNHhzBJqmLcpe as exception:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.wininfo_clear()
   return FOSGtujkgwiKbUEdVoNHhzBJqmLcpR
  FOSGtujkgwiKbUEdVoNHhzBJqmLclv =__addon__.getSetting('id')
  FOSGtujkgwiKbUEdVoNHhzBJqmLcWx =__addon__.getSetting('pw')
  FOSGtujkgwiKbUEdVoNHhzBJqmLcpx=__addon__.getSetting('login_type')
  FOSGtujkgwiKbUEdVoNHhzBJqmLcpl =__addon__.getSetting('selected_profile')
  FOSGtujkgwiKbUEdVoNHhzBJqmLcfT['tving_id']=base64.standard_b64decode(FOSGtujkgwiKbUEdVoNHhzBJqmLcfT['tving_id']).decode('utf-8')
  FOSGtujkgwiKbUEdVoNHhzBJqmLcfT['tving_pw']=base64.standard_b64decode(FOSGtujkgwiKbUEdVoNHhzBJqmLcfT['tving_pw']).decode('utf-8')
  try:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcfT['tving_profile']
  except:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcfT['tving_profile']='0'
  if FOSGtujkgwiKbUEdVoNHhzBJqmLclv!=FOSGtujkgwiKbUEdVoNHhzBJqmLcfT['tving_id']or FOSGtujkgwiKbUEdVoNHhzBJqmLcWx!=FOSGtujkgwiKbUEdVoNHhzBJqmLcfT['tving_pw']or FOSGtujkgwiKbUEdVoNHhzBJqmLcpx!=FOSGtujkgwiKbUEdVoNHhzBJqmLcfT['tving_logintype']or FOSGtujkgwiKbUEdVoNHhzBJqmLcpl!=FOSGtujkgwiKbUEdVoNHhzBJqmLcfT['tving_profile']or FOSGtujkgwiKbUEdVoNHhzBJqmLcfT['tving_token']=='':
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.wininfo_clear()
   return FOSGtujkgwiKbUEdVoNHhzBJqmLcpR
  FOSGtujkgwiKbUEdVoNHhzBJqmLcWr =FOSGtujkgwiKbUEdVoNHhzBJqmLcpf(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  FOSGtujkgwiKbUEdVoNHhzBJqmLcpW=FOSGtujkgwiKbUEdVoNHhzBJqmLcfT['tving_limitdate']
  FOSGtujkgwiKbUEdVoNHhzBJqmLcWf =FOSGtujkgwiKbUEdVoNHhzBJqmLcpf(re.sub('-','',FOSGtujkgwiKbUEdVoNHhzBJqmLcpW))
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcWf<FOSGtujkgwiKbUEdVoNHhzBJqmLcWr:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.wininfo_clear()
   return FOSGtujkgwiKbUEdVoNHhzBJqmLcpR
  FOSGtujkgwiKbUEdVoNHhzBJqmLcls=xbmcgui.Window(10000)
  FOSGtujkgwiKbUEdVoNHhzBJqmLcls.setProperty('TVING_M_TOKEN',FOSGtujkgwiKbUEdVoNHhzBJqmLcfT['tving_token'])
  FOSGtujkgwiKbUEdVoNHhzBJqmLcls.setProperty('TVING_M_USERINFO',FOSGtujkgwiKbUEdVoNHhzBJqmLcfT['tving_userinfo'])
  FOSGtujkgwiKbUEdVoNHhzBJqmLcls.setProperty('TVING_M_UUID',FOSGtujkgwiKbUEdVoNHhzBJqmLcfT['tving_uuid'])
  FOSGtujkgwiKbUEdVoNHhzBJqmLcls.setProperty('TVING_M_LOGINTIME',FOSGtujkgwiKbUEdVoNHhzBJqmLcpW)
  try:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcls.setProperty('TVING_M_MAINTOKEN',FOSGtujkgwiKbUEdVoNHhzBJqmLcfT['tving_maintoken'])
   FOSGtujkgwiKbUEdVoNHhzBJqmLcls.setProperty('TVING_M_COOKIEKEY',FOSGtujkgwiKbUEdVoNHhzBJqmLcfT['tving_cookiekey'])
   FOSGtujkgwiKbUEdVoNHhzBJqmLcls.setProperty('TVING_M_LOCKKEY',FOSGtujkgwiKbUEdVoNHhzBJqmLcfT['tving_lockkey'])
  except:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcls.setProperty('TVING_M_MAINTOKEN',FOSGtujkgwiKbUEdVoNHhzBJqmLcfT['tving_token'])
   FOSGtujkgwiKbUEdVoNHhzBJqmLcls.setProperty('TVING_M_COOKIEKEY','Y')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcls.setProperty('TVING_M_LOCKKEY','N')
  return FOSGtujkgwiKbUEdVoNHhzBJqmLcps
 def dp_Global_Search(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM,FOSGtujkgwiKbUEdVoNHhzBJqmLcWM):
  FOSGtujkgwiKbUEdVoNHhzBJqmLcXY=FOSGtujkgwiKbUEdVoNHhzBJqmLcWM.get('mode')
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcXY=='TOTAL_SEARCH':
   FOSGtujkgwiKbUEdVoNHhzBJqmLcpA='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcpA='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(FOSGtujkgwiKbUEdVoNHhzBJqmLcpA)
 def dp_Bookmark_Menu(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM,FOSGtujkgwiKbUEdVoNHhzBJqmLcWM):
  FOSGtujkgwiKbUEdVoNHhzBJqmLcpA='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(FOSGtujkgwiKbUEdVoNHhzBJqmLcpA)
 def dp_EuroLive_List(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM,FOSGtujkgwiKbUEdVoNHhzBJqmLcWM):
  FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.TvingObj.SaveCredential(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.get_winCredential())
  FOSGtujkgwiKbUEdVoNHhzBJqmLcWY=FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.TvingObj.GetEuroChannelList()
  for FOSGtujkgwiKbUEdVoNHhzBJqmLcWC in FOSGtujkgwiKbUEdVoNHhzBJqmLcWY:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcAy =FOSGtujkgwiKbUEdVoNHhzBJqmLcWC.get('channel')
   FOSGtujkgwiKbUEdVoNHhzBJqmLclM =FOSGtujkgwiKbUEdVoNHhzBJqmLcWC.get('title')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcAX =FOSGtujkgwiKbUEdVoNHhzBJqmLcWC.get('subtitle')
   FOSGtujkgwiKbUEdVoNHhzBJqmLcAW={'mediatype':'episode','title':FOSGtujkgwiKbUEdVoNHhzBJqmLclM,'plot':'%s\n%s'%(FOSGtujkgwiKbUEdVoNHhzBJqmLclM,FOSGtujkgwiKbUEdVoNHhzBJqmLcAX)}
   FOSGtujkgwiKbUEdVoNHhzBJqmLclD={'mode':'LIVE','mediacode':FOSGtujkgwiKbUEdVoNHhzBJqmLcWC.get('channel'),'stype':'onair',}
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.add_dir(FOSGtujkgwiKbUEdVoNHhzBJqmLclM,sublabel=FOSGtujkgwiKbUEdVoNHhzBJqmLcAX,img='',infoLabels=FOSGtujkgwiKbUEdVoNHhzBJqmLcAW,isFolder=FOSGtujkgwiKbUEdVoNHhzBJqmLcpR,params=FOSGtujkgwiKbUEdVoNHhzBJqmLclD)
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcpa(FOSGtujkgwiKbUEdVoNHhzBJqmLcWY)>0:xbmcplugin.endOfDirectory(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM._addon_handle,cacheToDisc=FOSGtujkgwiKbUEdVoNHhzBJqmLcpR)
 def tving_main(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM):
  FOSGtujkgwiKbUEdVoNHhzBJqmLcXY=FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.main_params.get('mode',FOSGtujkgwiKbUEdVoNHhzBJqmLcpr)
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcXY=='LOGOUT':
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.logout()
   return
  FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.login_main()
  if FOSGtujkgwiKbUEdVoNHhzBJqmLcXY is FOSGtujkgwiKbUEdVoNHhzBJqmLcpr:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.dp_Main_List()
  elif FOSGtujkgwiKbUEdVoNHhzBJqmLcXY in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.dp_Title_Group(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.main_params)
  elif FOSGtujkgwiKbUEdVoNHhzBJqmLcXY in['GLOBAL_GROUP']:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.dp_SubTitle_Group(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.main_params)
  elif FOSGtujkgwiKbUEdVoNHhzBJqmLcXY=='CHANNEL':
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.dp_LiveChannel_List(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.main_params)
  elif FOSGtujkgwiKbUEdVoNHhzBJqmLcXY in['LIVE','VOD','MOVIE']:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.play_VIDEO(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.main_params)
  elif FOSGtujkgwiKbUEdVoNHhzBJqmLcXY=='PROGRAM':
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.dp_Program_List(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.main_params)
  elif FOSGtujkgwiKbUEdVoNHhzBJqmLcXY=='EPISODE':
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.dp_Episode_List(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.main_params)
  elif FOSGtujkgwiKbUEdVoNHhzBJqmLcXY=='MOVIE_SUB':
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.dp_Movie_List(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.main_params)
  elif FOSGtujkgwiKbUEdVoNHhzBJqmLcXY=='SEARCH_GROUP':
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.dp_Search_Group(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.main_params)
  elif FOSGtujkgwiKbUEdVoNHhzBJqmLcXY in['SEARCH','LOCAL_SEARCH']:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.dp_Search_List(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.main_params)
  elif FOSGtujkgwiKbUEdVoNHhzBJqmLcXY=='WATCH':
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.dp_Watch_List(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.main_params)
  elif FOSGtujkgwiKbUEdVoNHhzBJqmLcXY in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.dp_Listfile_Delete(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.main_params)
  elif FOSGtujkgwiKbUEdVoNHhzBJqmLcXY=='ORDER_BY':
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.dp_setEpOrderby(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.main_params)
  elif FOSGtujkgwiKbUEdVoNHhzBJqmLcXY=='SET_BOOKMARK':
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.dp_Set_Bookmark(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.main_params)
  elif FOSGtujkgwiKbUEdVoNHhzBJqmLcXY in['TOTAL_SEARCH','TOTAL_HISTORY']:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.dp_Global_Search(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.main_params)
  elif FOSGtujkgwiKbUEdVoNHhzBJqmLcXY=='SEARCH_HISTORY':
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.dp_Search_History(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.main_params)
  elif FOSGtujkgwiKbUEdVoNHhzBJqmLcXY=='MENU_BOOKMARK':
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.dp_Bookmark_Menu(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.main_params)
  elif FOSGtujkgwiKbUEdVoNHhzBJqmLcXY=='EURO_GROUP':
   FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.dp_EuroLive_List(FOSGtujkgwiKbUEdVoNHhzBJqmLcxM.main_params)
  else:
   FOSGtujkgwiKbUEdVoNHhzBJqmLcpr
# Created by pyminifier (https://github.com/liftoff/pyminifier)
