__author__="NightRain"
WfajURorOkbXnQBAvTstFJlNpKGhez=ImportError
WfajURorOkbXnQBAvTstFJlNpKGheE=object
WfajURorOkbXnQBAvTstFJlNpKGheD=None
WfajURorOkbXnQBAvTstFJlNpKGheH=False
WfajURorOkbXnQBAvTstFJlNpKGheq=int
WfajURorOkbXnQBAvTstFJlNpKGheL=range
WfajURorOkbXnQBAvTstFJlNpKGheI=True
WfajURorOkbXnQBAvTstFJlNpKGhec=print
WfajURorOkbXnQBAvTstFJlNpKGheu=Exception
WfajURorOkbXnQBAvTstFJlNpKGheY=str
WfajURorOkbXnQBAvTstFJlNpKGhew=list
WfajURorOkbXnQBAvTstFJlNpKGhei=len
WfajURorOkbXnQBAvTstFJlNpKGhey=bytes
WfajURorOkbXnQBAvTstFJlNpKGhPd=ord
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
try:
 from Cryptodome.PublicKey import RSA
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
except WfajURorOkbXnQBAvTstFJlNpKGhez:
 from Crypto.PublicKey import RSA
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
WfajURorOkbXnQBAvTstFJlNpKGhdg={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
WfajURorOkbXnQBAvTstFJlNpKGhdV ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
class WfajURorOkbXnQBAvTstFJlNpKGhdC(WfajURorOkbXnQBAvTstFJlNpKGheE):
 def __init__(WfajURorOkbXnQBAvTstFJlNpKGhdM):
  WfajURorOkbXnQBAvTstFJlNpKGhdM.TVING_TOKEN =''
  WfajURorOkbXnQBAvTstFJlNpKGhdM.POC_USERINFO =''
  WfajURorOkbXnQBAvTstFJlNpKGhdM.TVING_UUID ='-'
  WfajURorOkbXnQBAvTstFJlNpKGhdM.TVING_MAINTOKEN=''
  WfajURorOkbXnQBAvTstFJlNpKGhdM.TVIGN_COOKIEKEY=''
  WfajURorOkbXnQBAvTstFJlNpKGhdM.TVING_LOCKKEY =''
  WfajURorOkbXnQBAvTstFJlNpKGhdM.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  WfajURorOkbXnQBAvTstFJlNpKGhdM.NETWORKCODE ='CSND0900'
  WfajURorOkbXnQBAvTstFJlNpKGhdM.OSCODE ='CSOD0900' 
  WfajURorOkbXnQBAvTstFJlNpKGhdM.TELECODE ='CSCD0900'
  WfajURorOkbXnQBAvTstFJlNpKGhdM.SCREENCODE ='CSSD0100'
  WfajURorOkbXnQBAvTstFJlNpKGhdM.LIVE_LIMIT =20 
  WfajURorOkbXnQBAvTstFJlNpKGhdM.VOD_LIMIT =24 
  WfajURorOkbXnQBAvTstFJlNpKGhdM.EPISODE_LIMIT =30 
  WfajURorOkbXnQBAvTstFJlNpKGhdM.SEARCH_LIMIT =30 
  WfajURorOkbXnQBAvTstFJlNpKGhdM.MOVIE_LIMIT =24 
  WfajURorOkbXnQBAvTstFJlNpKGhdM.API_DOMAIN ='https://api.tving.com'
  WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN ='https://image.tving.com'
  WfajURorOkbXnQBAvTstFJlNpKGhdM.SEARCH_DOMAIN ='https://search.tving.com'
  WfajURorOkbXnQBAvTstFJlNpKGhdM.LOGIN_DOMAIN ='https://user.tving.com'
  WfajURorOkbXnQBAvTstFJlNpKGhdM.URL_DOMAIN ='https://www.tving.com'
  WfajURorOkbXnQBAvTstFJlNpKGhdM.MOVIE_LITE =['2610061','2610161','261062']
  WfajURorOkbXnQBAvTstFJlNpKGhdM.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.99 Safari/537.36'
  WfajURorOkbXnQBAvTstFJlNpKGhdM.DEFAULT_HEADER ={'user-agent':WfajURorOkbXnQBAvTstFJlNpKGhdM.USER_AGENT}
  WfajURorOkbXnQBAvTstFJlNpKGhdM.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
  WfajURorOkbXnQBAvTstFJlNpKGhdM.TV_SESSION_COOKIES1=''
  WfajURorOkbXnQBAvTstFJlNpKGhdM.TV_SESSION_COOKIES2=''
 def callRequestCookies(WfajURorOkbXnQBAvTstFJlNpKGhdM,jobtype,WfajURorOkbXnQBAvTstFJlNpKGhCH,payload=WfajURorOkbXnQBAvTstFJlNpKGheD,params=WfajURorOkbXnQBAvTstFJlNpKGheD,headers=WfajURorOkbXnQBAvTstFJlNpKGheD,cookies=WfajURorOkbXnQBAvTstFJlNpKGheD,redirects=WfajURorOkbXnQBAvTstFJlNpKGheH):
  WfajURorOkbXnQBAvTstFJlNpKGhde=WfajURorOkbXnQBAvTstFJlNpKGhdM.DEFAULT_HEADER
  if headers:WfajURorOkbXnQBAvTstFJlNpKGhde.update(headers)
  if jobtype=='Get':
   WfajURorOkbXnQBAvTstFJlNpKGhdP=requests.get(WfajURorOkbXnQBAvTstFJlNpKGhCH,params=params,headers=WfajURorOkbXnQBAvTstFJlNpKGhde,cookies=cookies,allow_redirects=redirects)
  else:
   WfajURorOkbXnQBAvTstFJlNpKGhdP=requests.post(WfajURorOkbXnQBAvTstFJlNpKGhCH,data=payload,params=params,headers=WfajURorOkbXnQBAvTstFJlNpKGhde,cookies=cookies,allow_redirects=redirects)
  return WfajURorOkbXnQBAvTstFJlNpKGhdP
 def makeDefaultCookies(WfajURorOkbXnQBAvTstFJlNpKGhdM,vToken=WfajURorOkbXnQBAvTstFJlNpKGheD,vUserinfo=WfajURorOkbXnQBAvTstFJlNpKGheD):
  WfajURorOkbXnQBAvTstFJlNpKGhdS={}
  WfajURorOkbXnQBAvTstFJlNpKGhdS['_tving_token']=WfajURorOkbXnQBAvTstFJlNpKGhdM.TVING_TOKEN if vToken==WfajURorOkbXnQBAvTstFJlNpKGheD else vToken
  WfajURorOkbXnQBAvTstFJlNpKGhdS['POC_USERINFO']=WfajURorOkbXnQBAvTstFJlNpKGhdM.POC_USERINFO if vToken==WfajURorOkbXnQBAvTstFJlNpKGheD else vUserinfo
  if WfajURorOkbXnQBAvTstFJlNpKGhdM.TVING_MAINTOKEN!='':WfajURorOkbXnQBAvTstFJlNpKGhdS[WfajURorOkbXnQBAvTstFJlNpKGhdM.GLOBAL_COOKIENM['tv_maintoken']]=WfajURorOkbXnQBAvTstFJlNpKGhdM.TVING_MAINTOKEN
  if WfajURorOkbXnQBAvTstFJlNpKGhdM.TVIGN_COOKIEKEY!='':WfajURorOkbXnQBAvTstFJlNpKGhdS[WfajURorOkbXnQBAvTstFJlNpKGhdM.GLOBAL_COOKIENM['tv_cookiekey']]=WfajURorOkbXnQBAvTstFJlNpKGhdM.TVIGN_COOKIEKEY
  if WfajURorOkbXnQBAvTstFJlNpKGhdM.TVING_LOCKKEY !='':WfajURorOkbXnQBAvTstFJlNpKGhdS[WfajURorOkbXnQBAvTstFJlNpKGhdM.GLOBAL_COOKIENM['tv_lockkey']] =WfajURorOkbXnQBAvTstFJlNpKGhdM.TVING_LOCKKEY
  return WfajURorOkbXnQBAvTstFJlNpKGhdS
 def getDeviceStr(WfajURorOkbXnQBAvTstFJlNpKGhdM):
  WfajURorOkbXnQBAvTstFJlNpKGhdm=[]
  WfajURorOkbXnQBAvTstFJlNpKGhdm.append('Windows') 
  WfajURorOkbXnQBAvTstFJlNpKGhdm.append('Chrome') 
  WfajURorOkbXnQBAvTstFJlNpKGhdm.append('ko-KR') 
  WfajURorOkbXnQBAvTstFJlNpKGhdm.append('undefined') 
  WfajURorOkbXnQBAvTstFJlNpKGhdm.append('24') 
  WfajURorOkbXnQBAvTstFJlNpKGhdm.append(u'한국 표준시')
  WfajURorOkbXnQBAvTstFJlNpKGhdm.append('undefined') 
  WfajURorOkbXnQBAvTstFJlNpKGhdm.append('undefined') 
  WfajURorOkbXnQBAvTstFJlNpKGhdm.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  WfajURorOkbXnQBAvTstFJlNpKGhdx=''
  for WfajURorOkbXnQBAvTstFJlNpKGhdz in WfajURorOkbXnQBAvTstFJlNpKGhdm:
   WfajURorOkbXnQBAvTstFJlNpKGhdx+=WfajURorOkbXnQBAvTstFJlNpKGhdz+'|'
  return WfajURorOkbXnQBAvTstFJlNpKGhdx
 def SaveCredential(WfajURorOkbXnQBAvTstFJlNpKGhdM,WfajURorOkbXnQBAvTstFJlNpKGhdE):
  WfajURorOkbXnQBAvTstFJlNpKGhdM.TVING_TOKEN =WfajURorOkbXnQBAvTstFJlNpKGhdE.get('tving_token')
  WfajURorOkbXnQBAvTstFJlNpKGhdM.POC_USERINFO =WfajURorOkbXnQBAvTstFJlNpKGhdE.get('poc_userinfo')
  WfajURorOkbXnQBAvTstFJlNpKGhdM.TVING_UUID =WfajURorOkbXnQBAvTstFJlNpKGhdE.get('tving_uuid')
  WfajURorOkbXnQBAvTstFJlNpKGhdM.TVING_MAINTOKEN=WfajURorOkbXnQBAvTstFJlNpKGhdE.get('tving_maintoken')
  WfajURorOkbXnQBAvTstFJlNpKGhdM.TVIGN_COOKIEKEY=WfajURorOkbXnQBAvTstFJlNpKGhdE.get('tving_cookiekey')
  WfajURorOkbXnQBAvTstFJlNpKGhdM.TVING_LOCKKEY =WfajURorOkbXnQBAvTstFJlNpKGhdE.get('tving_lockkey')
 def LoadCredential(WfajURorOkbXnQBAvTstFJlNpKGhdM):
  WfajURorOkbXnQBAvTstFJlNpKGhdE={'tving_token':WfajURorOkbXnQBAvTstFJlNpKGhdM.TVING_TOKEN,'poc_userinfo':WfajURorOkbXnQBAvTstFJlNpKGhdM.POC_USERINFO,'tving_uuid':WfajURorOkbXnQBAvTstFJlNpKGhdM.TVING_UUID,'tving_maintoken':WfajURorOkbXnQBAvTstFJlNpKGhdM.TVING_MAINTOKEN,'tving_cookiekey':WfajURorOkbXnQBAvTstFJlNpKGhdM.TVIGN_COOKIEKEY,'tving_lockkey':WfajURorOkbXnQBAvTstFJlNpKGhdM.TVING_LOCKKEY}
  return WfajURorOkbXnQBAvTstFJlNpKGhdE
 def GetDefaultParams(WfajURorOkbXnQBAvTstFJlNpKGhdM):
  WfajURorOkbXnQBAvTstFJlNpKGhdD={'apiKey':WfajURorOkbXnQBAvTstFJlNpKGhdM.APIKEY,'networkCode':WfajURorOkbXnQBAvTstFJlNpKGhdM.NETWORKCODE,'osCode':WfajURorOkbXnQBAvTstFJlNpKGhdM.OSCODE,'teleCode':WfajURorOkbXnQBAvTstFJlNpKGhdM.TELECODE,'screenCode':WfajURorOkbXnQBAvTstFJlNpKGhdM.SCREENCODE}
  return WfajURorOkbXnQBAvTstFJlNpKGhdD
 def GetNoCache(WfajURorOkbXnQBAvTstFJlNpKGhdM,timetype=1):
  if timetype==1:
   return WfajURorOkbXnQBAvTstFJlNpKGheq(time.time())
  else:
   return WfajURorOkbXnQBAvTstFJlNpKGheq(time.time()*1000)
 def GetUniqueid(WfajURorOkbXnQBAvTstFJlNpKGhdM):
  WfajURorOkbXnQBAvTstFJlNpKGhdH=[0 for i in WfajURorOkbXnQBAvTstFJlNpKGheL(256)]
  for i in WfajURorOkbXnQBAvTstFJlNpKGheL(256):
   WfajURorOkbXnQBAvTstFJlNpKGhdH[i]='%02x'%(i)
  WfajURorOkbXnQBAvTstFJlNpKGhdq=WfajURorOkbXnQBAvTstFJlNpKGheq(4294967295*random.random())|0
  WfajURorOkbXnQBAvTstFJlNpKGhdL=WfajURorOkbXnQBAvTstFJlNpKGhdH[255&WfajURorOkbXnQBAvTstFJlNpKGhdq]+WfajURorOkbXnQBAvTstFJlNpKGhdH[WfajURorOkbXnQBAvTstFJlNpKGhdq>>8&255]+WfajURorOkbXnQBAvTstFJlNpKGhdH[WfajURorOkbXnQBAvTstFJlNpKGhdq>>16&255]+WfajURorOkbXnQBAvTstFJlNpKGhdH[WfajURorOkbXnQBAvTstFJlNpKGhdq>>24&255]
  return WfajURorOkbXnQBAvTstFJlNpKGhdL
 def GetCredential(WfajURorOkbXnQBAvTstFJlNpKGhdM,user_id,user_pw,login_type,user_pf):
  WfajURorOkbXnQBAvTstFJlNpKGhdI=WfajURorOkbXnQBAvTstFJlNpKGheH
  WfajURorOkbXnQBAvTstFJlNpKGhdc=WfajURorOkbXnQBAvTstFJlNpKGhCd=WfajURorOkbXnQBAvTstFJlNpKGhCg=WfajURorOkbXnQBAvTstFJlNpKGhCV=WfajURorOkbXnQBAvTstFJlNpKGhCM='' 
  WfajURorOkbXnQBAvTstFJlNpKGhdu ='-'
  try:
   WfajURorOkbXnQBAvTstFJlNpKGhdY=WfajURorOkbXnQBAvTstFJlNpKGhdM.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   WfajURorOkbXnQBAvTstFJlNpKGhdw={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com','csite':'',}
   WfajURorOkbXnQBAvTstFJlNpKGhdi=WfajURorOkbXnQBAvTstFJlNpKGhdM.callRequestCookies('Post',WfajURorOkbXnQBAvTstFJlNpKGhdY,payload=WfajURorOkbXnQBAvTstFJlNpKGhdw,params=WfajURorOkbXnQBAvTstFJlNpKGheD,headers=WfajURorOkbXnQBAvTstFJlNpKGheD,cookies=WfajURorOkbXnQBAvTstFJlNpKGheD)
   for WfajURorOkbXnQBAvTstFJlNpKGhdy in WfajURorOkbXnQBAvTstFJlNpKGhdi.cookies:
    if WfajURorOkbXnQBAvTstFJlNpKGhdy.name=='_tving_token':
     WfajURorOkbXnQBAvTstFJlNpKGhCd=WfajURorOkbXnQBAvTstFJlNpKGhdy.value
    elif WfajURorOkbXnQBAvTstFJlNpKGhdy.name=='POC_USERINFO':
     WfajURorOkbXnQBAvTstFJlNpKGhCg=WfajURorOkbXnQBAvTstFJlNpKGhdy.value
   if WfajURorOkbXnQBAvTstFJlNpKGhCd=='':return WfajURorOkbXnQBAvTstFJlNpKGhdI
   WfajURorOkbXnQBAvTstFJlNpKGhdc=WfajURorOkbXnQBAvTstFJlNpKGhCd
   WfajURorOkbXnQBAvTstFJlNpKGhCd,WfajURorOkbXnQBAvTstFJlNpKGhCV,WfajURorOkbXnQBAvTstFJlNpKGhCM=WfajURorOkbXnQBAvTstFJlNpKGhdM.GetProfileToken(WfajURorOkbXnQBAvTstFJlNpKGhCd,WfajURorOkbXnQBAvTstFJlNpKGhCg,user_pf)
   WfajURorOkbXnQBAvTstFJlNpKGhdI=WfajURorOkbXnQBAvTstFJlNpKGheI
   WfajURorOkbXnQBAvTstFJlNpKGhdu =WfajURorOkbXnQBAvTstFJlNpKGhdM.GetDeviceList(WfajURorOkbXnQBAvTstFJlNpKGhCd,WfajURorOkbXnQBAvTstFJlNpKGhCg)
   WfajURorOkbXnQBAvTstFJlNpKGhdu =WfajURorOkbXnQBAvTstFJlNpKGhdu+'-'+WfajURorOkbXnQBAvTstFJlNpKGhdM.GetUniqueid()
   WfajURorOkbXnQBAvTstFJlNpKGhec(WfajURorOkbXnQBAvTstFJlNpKGhdu)
  except WfajURorOkbXnQBAvTstFJlNpKGheu as exception:
   WfajURorOkbXnQBAvTstFJlNpKGhdc=WfajURorOkbXnQBAvTstFJlNpKGhCd=WfajURorOkbXnQBAvTstFJlNpKGhCg=WfajURorOkbXnQBAvTstFJlNpKGhCV=WfajURorOkbXnQBAvTstFJlNpKGhCM=''
   WfajURorOkbXnQBAvTstFJlNpKGhdu='-'
   WfajURorOkbXnQBAvTstFJlNpKGhec(exception)
  WfajURorOkbXnQBAvTstFJlNpKGhdE={'tving_token':WfajURorOkbXnQBAvTstFJlNpKGhCd,'poc_userinfo':WfajURorOkbXnQBAvTstFJlNpKGhCg,'tving_uuid':WfajURorOkbXnQBAvTstFJlNpKGhdu,'tving_maintoken':WfajURorOkbXnQBAvTstFJlNpKGhdc,'tving_cookiekey':WfajURorOkbXnQBAvTstFJlNpKGhCV,'tving_lockkey':WfajURorOkbXnQBAvTstFJlNpKGhCM}
  WfajURorOkbXnQBAvTstFJlNpKGhdM.SaveCredential(WfajURorOkbXnQBAvTstFJlNpKGhdE)
  return WfajURorOkbXnQBAvTstFJlNpKGhdI
 def Get_Now_Datetime(WfajURorOkbXnQBAvTstFJlNpKGhdM):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(WfajURorOkbXnQBAvTstFJlNpKGhdM,mediacode,sel_quality,stype,pvrmode='-'):
  WfajURorOkbXnQBAvTstFJlNpKGhCP ={'streaming_url':'','drm_license':'','watermark':'','watermarkKey':'','error_msg':'',}
  WfajURorOkbXnQBAvTstFJlNpKGhCS =WfajURorOkbXnQBAvTstFJlNpKGhdM.TVING_UUID.split('-')[0] 
  WfajURorOkbXnQBAvTstFJlNpKGhCm =WfajURorOkbXnQBAvTstFJlNpKGhdM.TVING_UUID 
  try:
   WfajURorOkbXnQBAvTstFJlNpKGhCx=WfajURorOkbXnQBAvTstFJlNpKGheY(WfajURorOkbXnQBAvTstFJlNpKGhdM.GetNoCache(1))
   if stype!='tvingtv':
    WfajURorOkbXnQBAvTstFJlNpKGhCz ='/v2/media/stream/info' 
    WfajURorOkbXnQBAvTstFJlNpKGhCE=WfajURorOkbXnQBAvTstFJlNpKGhdM.GetDefaultParams()
    WfajURorOkbXnQBAvTstFJlNpKGhCD={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':WfajURorOkbXnQBAvTstFJlNpKGhCm,'deviceInfo':'PC','noCache':WfajURorOkbXnQBAvTstFJlNpKGhCx,}
    WfajURorOkbXnQBAvTstFJlNpKGhCE.update(WfajURorOkbXnQBAvTstFJlNpKGhCD)
    WfajURorOkbXnQBAvTstFJlNpKGhCH=WfajURorOkbXnQBAvTstFJlNpKGhdM.API_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhCz
    WfajURorOkbXnQBAvTstFJlNpKGhdS=WfajURorOkbXnQBAvTstFJlNpKGhdM.makeDefaultCookies()
    WfajURorOkbXnQBAvTstFJlNpKGhdi=WfajURorOkbXnQBAvTstFJlNpKGhdM.callRequestCookies('Get',WfajURorOkbXnQBAvTstFJlNpKGhCH,payload=WfajURorOkbXnQBAvTstFJlNpKGheD,params=WfajURorOkbXnQBAvTstFJlNpKGhCE,headers=WfajURorOkbXnQBAvTstFJlNpKGheD,cookies=WfajURorOkbXnQBAvTstFJlNpKGhdS)
    if WfajURorOkbXnQBAvTstFJlNpKGhdi.status_code!=200:
     WfajURorOkbXnQBAvTstFJlNpKGhCP['error_msg']='First Step - {} error'.format(WfajURorOkbXnQBAvTstFJlNpKGhdi.status_code)
     return WfajURorOkbXnQBAvTstFJlNpKGhCP
    WfajURorOkbXnQBAvTstFJlNpKGhCq=json.loads(WfajURorOkbXnQBAvTstFJlNpKGhdi.text)
    if WfajURorOkbXnQBAvTstFJlNpKGhCq['body']['result']['code']=='060':
     for WfajURorOkbXnQBAvTstFJlNpKGhCL,WfajURorOkbXnQBAvTstFJlNpKGhgM in WfajURorOkbXnQBAvTstFJlNpKGhdg.items():
      if WfajURorOkbXnQBAvTstFJlNpKGhgM==sel_quality:
       WfajURorOkbXnQBAvTstFJlNpKGhCI=WfajURorOkbXnQBAvTstFJlNpKGhCL
    elif WfajURorOkbXnQBAvTstFJlNpKGhCq['body']['result']['code']!='000':
     WfajURorOkbXnQBAvTstFJlNpKGhCP['error_msg']=WfajURorOkbXnQBAvTstFJlNpKGhCq['body']['result']['message']
     return WfajURorOkbXnQBAvTstFJlNpKGhCP
    else: 
     if not('stream' in WfajURorOkbXnQBAvTstFJlNpKGhCq['body']):return WfajURorOkbXnQBAvTstFJlNpKGhCP
     WfajURorOkbXnQBAvTstFJlNpKGhCc=[]
     for WfajURorOkbXnQBAvTstFJlNpKGhCu in WfajURorOkbXnQBAvTstFJlNpKGhCq['body']['stream']['quality']:
      if WfajURorOkbXnQBAvTstFJlNpKGhCu['active']=='Y':
       WfajURorOkbXnQBAvTstFJlNpKGhCc.append({WfajURorOkbXnQBAvTstFJlNpKGhdg.get(WfajURorOkbXnQBAvTstFJlNpKGhCu['code']):WfajURorOkbXnQBAvTstFJlNpKGhCu['code']})
     WfajURorOkbXnQBAvTstFJlNpKGhCI=WfajURorOkbXnQBAvTstFJlNpKGhdM.CheckQuality(sel_quality,WfajURorOkbXnQBAvTstFJlNpKGhCc)
   else:
    WfajURorOkbXnQBAvTstFJlNpKGhCI='stream40'
  except WfajURorOkbXnQBAvTstFJlNpKGheu as exception:
   WfajURorOkbXnQBAvTstFJlNpKGhec(exception)
   WfajURorOkbXnQBAvTstFJlNpKGhCP['error_msg']='First Step - except error'
   return WfajURorOkbXnQBAvTstFJlNpKGhCP
  WfajURorOkbXnQBAvTstFJlNpKGhec(WfajURorOkbXnQBAvTstFJlNpKGhCI)
  try:
   WfajURorOkbXnQBAvTstFJlNpKGhCx=WfajURorOkbXnQBAvTstFJlNpKGheY(WfajURorOkbXnQBAvTstFJlNpKGhdM.GetNoCache(1))
   WfajURorOkbXnQBAvTstFJlNpKGhCz ='/v2a/media/stream/info'
   WfajURorOkbXnQBAvTstFJlNpKGhCE=WfajURorOkbXnQBAvTstFJlNpKGhdM.GetDefaultParams()
   WfajURorOkbXnQBAvTstFJlNpKGhCD={'callingFrom':'HTML5','mediaCode':mediacode,'info':'Y','adReq':'adproxy','streamCode':WfajURorOkbXnQBAvTstFJlNpKGhCI,'deviceId':WfajURorOkbXnQBAvTstFJlNpKGhCS,'uuid':WfajURorOkbXnQBAvTstFJlNpKGhCm,'deviceInfo':'PC_Chrome','noCache':WfajURorOkbXnQBAvTstFJlNpKGhCx,'wm':'Y'}
   WfajURorOkbXnQBAvTstFJlNpKGhCE.update(WfajURorOkbXnQBAvTstFJlNpKGhCD)
   WfajURorOkbXnQBAvTstFJlNpKGhCH=WfajURorOkbXnQBAvTstFJlNpKGhdM.API_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhCz
   WfajURorOkbXnQBAvTstFJlNpKGhdS=WfajURorOkbXnQBAvTstFJlNpKGhdM.makeDefaultCookies()
   WfajURorOkbXnQBAvTstFJlNpKGhdi=WfajURorOkbXnQBAvTstFJlNpKGhdM.callRequestCookies('Get',WfajURorOkbXnQBAvTstFJlNpKGhCH,payload=WfajURorOkbXnQBAvTstFJlNpKGheD,params=WfajURorOkbXnQBAvTstFJlNpKGhCE,headers=WfajURorOkbXnQBAvTstFJlNpKGheD,cookies=WfajURorOkbXnQBAvTstFJlNpKGhdS,redirects=WfajURorOkbXnQBAvTstFJlNpKGheH)
   WfajURorOkbXnQBAvTstFJlNpKGhCq=json.loads(WfajURorOkbXnQBAvTstFJlNpKGhdi.text)
   if WfajURorOkbXnQBAvTstFJlNpKGhCq['body']['result']['code']!='000':
    WfajURorOkbXnQBAvTstFJlNpKGhCP['error_msg']=WfajURorOkbXnQBAvTstFJlNpKGhCq['body']['result']['message']
    return WfajURorOkbXnQBAvTstFJlNpKGhCP
   WfajURorOkbXnQBAvTstFJlNpKGhCY=WfajURorOkbXnQBAvTstFJlNpKGhCq['body']['stream']
   if 'drm_license_assertion' in WfajURorOkbXnQBAvTstFJlNpKGhCY:
    WfajURorOkbXnQBAvTstFJlNpKGhCP['drm_license']=WfajURorOkbXnQBAvTstFJlNpKGhCY['drm_license_assertion']
    WfajURorOkbXnQBAvTstFJlNpKGhCw =WfajURorOkbXnQBAvTstFJlNpKGhCY['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in WfajURorOkbXnQBAvTstFJlNpKGhCY['broadcast']):return WfajURorOkbXnQBAvTstFJlNpKGhCP
    WfajURorOkbXnQBAvTstFJlNpKGhCw=WfajURorOkbXnQBAvTstFJlNpKGhCY['broadcast']['broad_url']
  except WfajURorOkbXnQBAvTstFJlNpKGheu as exception:
   WfajURorOkbXnQBAvTstFJlNpKGhec(exception)
   WfajURorOkbXnQBAvTstFJlNpKGhCP['error_msg']='Second Step - except error'
   return WfajURorOkbXnQBAvTstFJlNpKGhCP
  WfajURorOkbXnQBAvTstFJlNpKGhCi=WfajURorOkbXnQBAvTstFJlNpKGhCx
  WfajURorOkbXnQBAvTstFJlNpKGhCw=WfajURorOkbXnQBAvTstFJlNpKGhCw.split('|')[1]
  WfajURorOkbXnQBAvTstFJlNpKGhCw,WfajURorOkbXnQBAvTstFJlNpKGhCy,WfajURorOkbXnQBAvTstFJlNpKGhgd=WfajURorOkbXnQBAvTstFJlNpKGhdM.Decrypt_Url(WfajURorOkbXnQBAvTstFJlNpKGhCw,mediacode,WfajURorOkbXnQBAvTstFJlNpKGhCi)
  WfajURorOkbXnQBAvTstFJlNpKGhCP['streaming_url']=WfajURorOkbXnQBAvTstFJlNpKGhCw
  WfajURorOkbXnQBAvTstFJlNpKGhCP['watermark'] =WfajURorOkbXnQBAvTstFJlNpKGhCy
  WfajURorOkbXnQBAvTstFJlNpKGhCP['watermarkKey']=WfajURorOkbXnQBAvTstFJlNpKGhgd
  return WfajURorOkbXnQBAvTstFJlNpKGhCP
 def CheckQuality(WfajURorOkbXnQBAvTstFJlNpKGhdM,sel_qt,WfajURorOkbXnQBAvTstFJlNpKGhCc):
  for WfajURorOkbXnQBAvTstFJlNpKGhgC in WfajURorOkbXnQBAvTstFJlNpKGhCc:
   if sel_qt>=WfajURorOkbXnQBAvTstFJlNpKGhew(WfajURorOkbXnQBAvTstFJlNpKGhgC)[0]:return WfajURorOkbXnQBAvTstFJlNpKGhgC.get(WfajURorOkbXnQBAvTstFJlNpKGhew(WfajURorOkbXnQBAvTstFJlNpKGhgC)[0])
   WfajURorOkbXnQBAvTstFJlNpKGhgV=WfajURorOkbXnQBAvTstFJlNpKGhgC.get(WfajURorOkbXnQBAvTstFJlNpKGhew(WfajURorOkbXnQBAvTstFJlNpKGhgC)[0])
  return WfajURorOkbXnQBAvTstFJlNpKGhgV
 def makeOocUrl(WfajURorOkbXnQBAvTstFJlNpKGhdM,ooc_params):
  WfajURorOkbXnQBAvTstFJlNpKGhCH=''
  for WfajURorOkbXnQBAvTstFJlNpKGhCL,WfajURorOkbXnQBAvTstFJlNpKGhgM in ooc_params.items():
   WfajURorOkbXnQBAvTstFJlNpKGhCH+="%s=%s^"%(WfajURorOkbXnQBAvTstFJlNpKGhCL,WfajURorOkbXnQBAvTstFJlNpKGhgM)
  return WfajURorOkbXnQBAvTstFJlNpKGhCH
 def GetLiveChannelList(WfajURorOkbXnQBAvTstFJlNpKGhdM,stype,page_int):
  WfajURorOkbXnQBAvTstFJlNpKGhge=[]
  WfajURorOkbXnQBAvTstFJlNpKGhgP=WfajURorOkbXnQBAvTstFJlNpKGheH
  try:
   WfajURorOkbXnQBAvTstFJlNpKGhCz ='/v2/media/lives'
   if stype=='onair': 
    WfajURorOkbXnQBAvTstFJlNpKGhgS='CPCS0100,CPCS0400'
   else:
    WfajURorOkbXnQBAvTstFJlNpKGhgS='CPCS0300'
   WfajURorOkbXnQBAvTstFJlNpKGhCE=WfajURorOkbXnQBAvTstFJlNpKGhdM.GetDefaultParams()
   WfajURorOkbXnQBAvTstFJlNpKGhCD={'cacheType':'main','pageNo':WfajURorOkbXnQBAvTstFJlNpKGheY(page_int),'pageSize':WfajURorOkbXnQBAvTstFJlNpKGheY(WfajURorOkbXnQBAvTstFJlNpKGhdM.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':WfajURorOkbXnQBAvTstFJlNpKGhgS,}
   WfajURorOkbXnQBAvTstFJlNpKGhCE.update(WfajURorOkbXnQBAvTstFJlNpKGhCD)
   WfajURorOkbXnQBAvTstFJlNpKGhCH=WfajURorOkbXnQBAvTstFJlNpKGhdM.API_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhCz
   WfajURorOkbXnQBAvTstFJlNpKGhdi=WfajURorOkbXnQBAvTstFJlNpKGhdM.callRequestCookies('Get',WfajURorOkbXnQBAvTstFJlNpKGhCH,payload=WfajURorOkbXnQBAvTstFJlNpKGheD,params=WfajURorOkbXnQBAvTstFJlNpKGhCE,headers=WfajURorOkbXnQBAvTstFJlNpKGheD,cookies=WfajURorOkbXnQBAvTstFJlNpKGheD)
   WfajURorOkbXnQBAvTstFJlNpKGhCq=json.loads(WfajURorOkbXnQBAvTstFJlNpKGhdi.text)
   if not('result' in WfajURorOkbXnQBAvTstFJlNpKGhCq['body']):return WfajURorOkbXnQBAvTstFJlNpKGhge,WfajURorOkbXnQBAvTstFJlNpKGhgP
   WfajURorOkbXnQBAvTstFJlNpKGhgm=WfajURorOkbXnQBAvTstFJlNpKGhCq['body']['result']
   for WfajURorOkbXnQBAvTstFJlNpKGhCu in WfajURorOkbXnQBAvTstFJlNpKGhgm:
    WfajURorOkbXnQBAvTstFJlNpKGhgx=WfajURorOkbXnQBAvTstFJlNpKGhgD=WfajURorOkbXnQBAvTstFJlNpKGhgH=''
    WfajURorOkbXnQBAvTstFJlNpKGhgz=WfajURorOkbXnQBAvTstFJlNpKGhVm=''
    WfajURorOkbXnQBAvTstFJlNpKGhgE=WfajURorOkbXnQBAvTstFJlNpKGhCu['live_code']
    WfajURorOkbXnQBAvTstFJlNpKGhgx =WfajURorOkbXnQBAvTstFJlNpKGhCu['schedule']['channel']['name']['ko']
    if WfajURorOkbXnQBAvTstFJlNpKGhCu['schedule']['episode']!=WfajURorOkbXnQBAvTstFJlNpKGheD:
     WfajURorOkbXnQBAvTstFJlNpKGhgD =WfajURorOkbXnQBAvTstFJlNpKGhCu['schedule']['program']['name']['ko']
     WfajURorOkbXnQBAvTstFJlNpKGhgD =WfajURorOkbXnQBAvTstFJlNpKGhgD+', '+WfajURorOkbXnQBAvTstFJlNpKGheY(WfajURorOkbXnQBAvTstFJlNpKGhCu['schedule']['episode']['frequency'])+'회'
     WfajURorOkbXnQBAvTstFJlNpKGhgH=WfajURorOkbXnQBAvTstFJlNpKGhCu['schedule']['episode']['synopsis']['ko']
    else:
     WfajURorOkbXnQBAvTstFJlNpKGhgD =WfajURorOkbXnQBAvTstFJlNpKGhCu['schedule']['program']['name']['ko']
     WfajURorOkbXnQBAvTstFJlNpKGhgH=WfajURorOkbXnQBAvTstFJlNpKGhCu['schedule']['program']['synopsis']['ko']
    try: 
     WfajURorOkbXnQBAvTstFJlNpKGhgq =''
     WfajURorOkbXnQBAvTstFJlNpKGhgL =''
     WfajURorOkbXnQBAvTstFJlNpKGhgI=''
     WfajURorOkbXnQBAvTstFJlNpKGhgc =''
     WfajURorOkbXnQBAvTstFJlNpKGhgu =''
     WfajURorOkbXnQBAvTstFJlNpKGhgY =''
     for WfajURorOkbXnQBAvTstFJlNpKGhgw in WfajURorOkbXnQBAvTstFJlNpKGhCu['schedule']['program']['image']:
      if WfajURorOkbXnQBAvTstFJlNpKGhgw['code']=='CAIP0900':WfajURorOkbXnQBAvTstFJlNpKGhgL =WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhgw['url']
      elif WfajURorOkbXnQBAvTstFJlNpKGhgw['code']=='CAIP1800':WfajURorOkbXnQBAvTstFJlNpKGhgI=WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhgw['url']
      elif WfajURorOkbXnQBAvTstFJlNpKGhgw['code']=='CAIP2000':WfajURorOkbXnQBAvTstFJlNpKGhgc =WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhgw['url']
      elif WfajURorOkbXnQBAvTstFJlNpKGhgw['code']=='CAIP1900':WfajURorOkbXnQBAvTstFJlNpKGhgu =WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhgw['url']
      elif WfajURorOkbXnQBAvTstFJlNpKGhgw['code']=='CAIP0200':WfajURorOkbXnQBAvTstFJlNpKGhgY =WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhgw['url']
      elif WfajURorOkbXnQBAvTstFJlNpKGhgw['code']=='CAIP0500':WfajURorOkbXnQBAvTstFJlNpKGhgq =WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhgw['url']
      elif WfajURorOkbXnQBAvTstFJlNpKGhgw['code']=='CAIP0800':WfajURorOkbXnQBAvTstFJlNpKGhgq =WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhgw['url']
     if WfajURorOkbXnQBAvTstFJlNpKGhgq=='':
      for WfajURorOkbXnQBAvTstFJlNpKGhgw in WfajURorOkbXnQBAvTstFJlNpKGhCu['schedule']['channel']['image']:
       if WfajURorOkbXnQBAvTstFJlNpKGhgw['code']=='CAIC0400':WfajURorOkbXnQBAvTstFJlNpKGhgq =WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhgw['url']
       elif WfajURorOkbXnQBAvTstFJlNpKGhgw['code']=='CAIC1400':WfajURorOkbXnQBAvTstFJlNpKGhgq =WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhgw['url']
       elif WfajURorOkbXnQBAvTstFJlNpKGhgw['code']=='CAIC1900':WfajURorOkbXnQBAvTstFJlNpKGhgq =WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhgw['url']
    except:
     WfajURorOkbXnQBAvTstFJlNpKGheD
    try:
     WfajURorOkbXnQBAvTstFJlNpKGhgi =[]
     WfajURorOkbXnQBAvTstFJlNpKGhgy=[]
     WfajURorOkbXnQBAvTstFJlNpKGhVd =[]
     WfajURorOkbXnQBAvTstFJlNpKGhVC=''
     WfajURorOkbXnQBAvTstFJlNpKGhVg=''
     WfajURorOkbXnQBAvTstFJlNpKGhVM=''
     for WfajURorOkbXnQBAvTstFJlNpKGhVe in WfajURorOkbXnQBAvTstFJlNpKGhCu.get('schedule').get('program').get('actor'):
      if WfajURorOkbXnQBAvTstFJlNpKGhVe!='' and WfajURorOkbXnQBAvTstFJlNpKGhVe!=u'없음':WfajURorOkbXnQBAvTstFJlNpKGhgi.append(WfajURorOkbXnQBAvTstFJlNpKGhVe)
     for WfajURorOkbXnQBAvTstFJlNpKGhVP in WfajURorOkbXnQBAvTstFJlNpKGhCu.get('schedule').get('program').get('director'):
      if WfajURorOkbXnQBAvTstFJlNpKGhVP!='' and WfajURorOkbXnQBAvTstFJlNpKGhVP!='-' and WfajURorOkbXnQBAvTstFJlNpKGhVP!=u'없음':WfajURorOkbXnQBAvTstFJlNpKGhgy.append(WfajURorOkbXnQBAvTstFJlNpKGhVP)
     if WfajURorOkbXnQBAvTstFJlNpKGhCu.get('schedule').get('program').get('category1_name').get('ko')!='':
      WfajURorOkbXnQBAvTstFJlNpKGhVd.append(WfajURorOkbXnQBAvTstFJlNpKGhCu['schedule']['program']['category1_name']['ko'])
     if WfajURorOkbXnQBAvTstFJlNpKGhCu.get('schedule').get('program').get('category2_name').get('ko')!='':
      WfajURorOkbXnQBAvTstFJlNpKGhVd.append(WfajURorOkbXnQBAvTstFJlNpKGhCu['schedule']['program']['category2_name']['ko'])
     if WfajURorOkbXnQBAvTstFJlNpKGhCu.get('schedule').get('program').get('product_year'):WfajURorOkbXnQBAvTstFJlNpKGhVC=WfajURorOkbXnQBAvTstFJlNpKGhCu['schedule']['program']['product_year']
     if WfajURorOkbXnQBAvTstFJlNpKGhCu.get('schedule').get('program').get('grade_code') :WfajURorOkbXnQBAvTstFJlNpKGhVg= WfajURorOkbXnQBAvTstFJlNpKGhdV.get(WfajURorOkbXnQBAvTstFJlNpKGhCu['schedule']['program']['grade_code'])
     if 'broad_dt' in WfajURorOkbXnQBAvTstFJlNpKGhCu.get('schedule').get('program'):
      WfajURorOkbXnQBAvTstFJlNpKGhVS =WfajURorOkbXnQBAvTstFJlNpKGhCu.get('schedule').get('program').get('broad_dt')
      WfajURorOkbXnQBAvTstFJlNpKGhVM='%s-%s-%s'%(WfajURorOkbXnQBAvTstFJlNpKGhVS[:4],WfajURorOkbXnQBAvTstFJlNpKGhVS[4:6],WfajURorOkbXnQBAvTstFJlNpKGhVS[6:])
    except:
     WfajURorOkbXnQBAvTstFJlNpKGheD
    WfajURorOkbXnQBAvTstFJlNpKGhgz=WfajURorOkbXnQBAvTstFJlNpKGheY(WfajURorOkbXnQBAvTstFJlNpKGhCu['schedule']['broadcast_start_time'])[8:12]
    WfajURorOkbXnQBAvTstFJlNpKGhVm =WfajURorOkbXnQBAvTstFJlNpKGheY(WfajURorOkbXnQBAvTstFJlNpKGhCu['schedule']['broadcast_end_time'])[8:12]
    WfajURorOkbXnQBAvTstFJlNpKGhVx={'channel':WfajURorOkbXnQBAvTstFJlNpKGhgx,'title':WfajURorOkbXnQBAvTstFJlNpKGhgD,'mediacode':WfajURorOkbXnQBAvTstFJlNpKGhgE,'thumbnail':{'poster':WfajURorOkbXnQBAvTstFJlNpKGhgL,'thumb':WfajURorOkbXnQBAvTstFJlNpKGhgq,'clearlogo':WfajURorOkbXnQBAvTstFJlNpKGhgI,'icon':WfajURorOkbXnQBAvTstFJlNpKGhgc,'fanart':WfajURorOkbXnQBAvTstFJlNpKGhgY},'synopsis':WfajURorOkbXnQBAvTstFJlNpKGhgH,'channelepg':' [%s:%s ~ %s:%s]'%(WfajURorOkbXnQBAvTstFJlNpKGhgz[0:2],WfajURorOkbXnQBAvTstFJlNpKGhgz[2:],WfajURorOkbXnQBAvTstFJlNpKGhVm[0:2],WfajURorOkbXnQBAvTstFJlNpKGhVm[2:]),'cast':WfajURorOkbXnQBAvTstFJlNpKGhgi,'director':WfajURorOkbXnQBAvTstFJlNpKGhgy,'info_genre':WfajURorOkbXnQBAvTstFJlNpKGhVd,'year':WfajURorOkbXnQBAvTstFJlNpKGhVC,'mpaa':WfajURorOkbXnQBAvTstFJlNpKGhVg,'premiered':WfajURorOkbXnQBAvTstFJlNpKGhVM}
    WfajURorOkbXnQBAvTstFJlNpKGhge.append(WfajURorOkbXnQBAvTstFJlNpKGhVx)
   if WfajURorOkbXnQBAvTstFJlNpKGhCq['body']['has_more']=='Y':
    WfajURorOkbXnQBAvTstFJlNpKGhgP=WfajURorOkbXnQBAvTstFJlNpKGheI
  except WfajURorOkbXnQBAvTstFJlNpKGheu as exception:
   WfajURorOkbXnQBAvTstFJlNpKGhec(exception)
  return WfajURorOkbXnQBAvTstFJlNpKGhge,WfajURorOkbXnQBAvTstFJlNpKGhgP
 def GetProgramList(WfajURorOkbXnQBAvTstFJlNpKGhdM,genre,orderby,page_int,genreCode='all'):
  WfajURorOkbXnQBAvTstFJlNpKGhge=[]
  WfajURorOkbXnQBAvTstFJlNpKGhgP=WfajURorOkbXnQBAvTstFJlNpKGheH
  try:
   WfajURorOkbXnQBAvTstFJlNpKGhCz ='/v2/media/episodes'
   WfajURorOkbXnQBAvTstFJlNpKGhCE=WfajURorOkbXnQBAvTstFJlNpKGhdM.GetDefaultParams()
   WfajURorOkbXnQBAvTstFJlNpKGhCD={'cacheType':'main','pageSize':WfajURorOkbXnQBAvTstFJlNpKGheY(WfajURorOkbXnQBAvTstFJlNpKGhdM.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':WfajURorOkbXnQBAvTstFJlNpKGheY(page_int),}
   if genre !='all':WfajURorOkbXnQBAvTstFJlNpKGhCD['categoryCode']=genre
   if genreCode!='all':WfajURorOkbXnQBAvTstFJlNpKGhCD['genreCode'] =genreCode 
   WfajURorOkbXnQBAvTstFJlNpKGhCE.update(WfajURorOkbXnQBAvTstFJlNpKGhCD)
   WfajURorOkbXnQBAvTstFJlNpKGhCH=WfajURorOkbXnQBAvTstFJlNpKGhdM.API_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhCz
   WfajURorOkbXnQBAvTstFJlNpKGhdi=WfajURorOkbXnQBAvTstFJlNpKGhdM.callRequestCookies('Get',WfajURorOkbXnQBAvTstFJlNpKGhCH,payload=WfajURorOkbXnQBAvTstFJlNpKGheD,params=WfajURorOkbXnQBAvTstFJlNpKGhCE,headers=WfajURorOkbXnQBAvTstFJlNpKGheD,cookies=WfajURorOkbXnQBAvTstFJlNpKGheD)
   WfajURorOkbXnQBAvTstFJlNpKGhCq=json.loads(WfajURorOkbXnQBAvTstFJlNpKGhdi.text)
   if not('result' in WfajURorOkbXnQBAvTstFJlNpKGhCq['body']):return WfajURorOkbXnQBAvTstFJlNpKGhge,WfajURorOkbXnQBAvTstFJlNpKGhgP
   WfajURorOkbXnQBAvTstFJlNpKGhgm=WfajURorOkbXnQBAvTstFJlNpKGhCq['body']['result']
   for WfajURorOkbXnQBAvTstFJlNpKGhCu in WfajURorOkbXnQBAvTstFJlNpKGhgm:
    WfajURorOkbXnQBAvTstFJlNpKGhVz=WfajURorOkbXnQBAvTstFJlNpKGhCu['program']['code']
    WfajURorOkbXnQBAvTstFJlNpKGhgD =WfajURorOkbXnQBAvTstFJlNpKGhCu['program']['name']['ko']
    WfajURorOkbXnQBAvTstFJlNpKGhVg =WfajURorOkbXnQBAvTstFJlNpKGhdV.get(WfajURorOkbXnQBAvTstFJlNpKGhCu['program'].get('grade_code'))
    WfajURorOkbXnQBAvTstFJlNpKGhgL =''
    WfajURorOkbXnQBAvTstFJlNpKGhgq =''
    WfajURorOkbXnQBAvTstFJlNpKGhgI=''
    WfajURorOkbXnQBAvTstFJlNpKGhgc =''
    WfajURorOkbXnQBAvTstFJlNpKGhgu =''
    for WfajURorOkbXnQBAvTstFJlNpKGhgw in WfajURorOkbXnQBAvTstFJlNpKGhCu['program']['image']:
     if WfajURorOkbXnQBAvTstFJlNpKGhgw['code']=='CAIP0900':WfajURorOkbXnQBAvTstFJlNpKGhgL =WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhgw['url']
     elif WfajURorOkbXnQBAvTstFJlNpKGhgw['code']=='CAIP0200':WfajURorOkbXnQBAvTstFJlNpKGhgq =WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhgw['url']
     elif WfajURorOkbXnQBAvTstFJlNpKGhgw['code']=='CAIP1800':WfajURorOkbXnQBAvTstFJlNpKGhgI=WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhgw['url']
     elif WfajURorOkbXnQBAvTstFJlNpKGhgw['code']=='CAIP2000':WfajURorOkbXnQBAvTstFJlNpKGhgc =WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhgw['url']
     elif WfajURorOkbXnQBAvTstFJlNpKGhgw['code']=='CAIP1900':WfajURorOkbXnQBAvTstFJlNpKGhgu =WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhgw['url']
    WfajURorOkbXnQBAvTstFJlNpKGhgH =WfajURorOkbXnQBAvTstFJlNpKGhCu['program']['synopsis']['ko']
    try:
     WfajURorOkbXnQBAvTstFJlNpKGhVE=WfajURorOkbXnQBAvTstFJlNpKGhCu['channel']['name']['ko']
    except:
     WfajURorOkbXnQBAvTstFJlNpKGhVE=''
    try:
     WfajURorOkbXnQBAvTstFJlNpKGhgi =[]
     WfajURorOkbXnQBAvTstFJlNpKGhgy=[]
     WfajURorOkbXnQBAvTstFJlNpKGhVd =[]
     WfajURorOkbXnQBAvTstFJlNpKGhVC =''
     WfajURorOkbXnQBAvTstFJlNpKGhVM=''
     for WfajURorOkbXnQBAvTstFJlNpKGhVe in WfajURorOkbXnQBAvTstFJlNpKGhCu.get('program').get('actor'):
      if WfajURorOkbXnQBAvTstFJlNpKGhVe!='' and WfajURorOkbXnQBAvTstFJlNpKGhVe!='-' and WfajURorOkbXnQBAvTstFJlNpKGhVe!=u'없음':WfajURorOkbXnQBAvTstFJlNpKGhgi.append(WfajURorOkbXnQBAvTstFJlNpKGhVe)
     for WfajURorOkbXnQBAvTstFJlNpKGhVP in WfajURorOkbXnQBAvTstFJlNpKGhCu.get('program').get('director'):
      if WfajURorOkbXnQBAvTstFJlNpKGhVP!='' and WfajURorOkbXnQBAvTstFJlNpKGhVP!='-' and WfajURorOkbXnQBAvTstFJlNpKGhVP!=u'없음':WfajURorOkbXnQBAvTstFJlNpKGhgy.append(WfajURorOkbXnQBAvTstFJlNpKGhVP)
     if WfajURorOkbXnQBAvTstFJlNpKGhCu.get('program').get('category1_name').get('ko')!='':
      WfajURorOkbXnQBAvTstFJlNpKGhVd.append(WfajURorOkbXnQBAvTstFJlNpKGhCu['program']['category1_name']['ko'])
     if WfajURorOkbXnQBAvTstFJlNpKGhCu.get('program').get('category2_name').get('ko')!='':
      WfajURorOkbXnQBAvTstFJlNpKGhVd.append(WfajURorOkbXnQBAvTstFJlNpKGhCu['program']['category2_name']['ko'])
     if WfajURorOkbXnQBAvTstFJlNpKGhCu.get('program').get('product_year'):WfajURorOkbXnQBAvTstFJlNpKGhVC=WfajURorOkbXnQBAvTstFJlNpKGhCu['program']['product_year']
     if 'broad_dt' in WfajURorOkbXnQBAvTstFJlNpKGhCu.get('program'):
      WfajURorOkbXnQBAvTstFJlNpKGhVS =WfajURorOkbXnQBAvTstFJlNpKGhCu.get('program').get('broad_dt')
      WfajURorOkbXnQBAvTstFJlNpKGhVM='%s-%s-%s'%(WfajURorOkbXnQBAvTstFJlNpKGhVS[:4],WfajURorOkbXnQBAvTstFJlNpKGhVS[4:6],WfajURorOkbXnQBAvTstFJlNpKGhVS[6:])
    except:
     WfajURorOkbXnQBAvTstFJlNpKGheD
    WfajURorOkbXnQBAvTstFJlNpKGhVx={'program':WfajURorOkbXnQBAvTstFJlNpKGhVz,'title':WfajURorOkbXnQBAvTstFJlNpKGhgD,'thumbnail':{'poster':WfajURorOkbXnQBAvTstFJlNpKGhgL,'thumb':WfajURorOkbXnQBAvTstFJlNpKGhgq,'clearlogo':WfajURorOkbXnQBAvTstFJlNpKGhgI,'icon':WfajURorOkbXnQBAvTstFJlNpKGhgc,'banner':WfajURorOkbXnQBAvTstFJlNpKGhgu,'fanart':WfajURorOkbXnQBAvTstFJlNpKGhgq},'synopsis':WfajURorOkbXnQBAvTstFJlNpKGhgH,'channel':WfajURorOkbXnQBAvTstFJlNpKGhVE,'cast':WfajURorOkbXnQBAvTstFJlNpKGhgi,'director':WfajURorOkbXnQBAvTstFJlNpKGhgy,'info_genre':WfajURorOkbXnQBAvTstFJlNpKGhVd,'year':WfajURorOkbXnQBAvTstFJlNpKGhVC,'premiered':WfajURorOkbXnQBAvTstFJlNpKGhVM,'mpaa':WfajURorOkbXnQBAvTstFJlNpKGhVg}
    WfajURorOkbXnQBAvTstFJlNpKGhge.append(WfajURorOkbXnQBAvTstFJlNpKGhVx)
   if WfajURorOkbXnQBAvTstFJlNpKGhCq['body']['has_more']=='Y':WfajURorOkbXnQBAvTstFJlNpKGhgP=WfajURorOkbXnQBAvTstFJlNpKGheI
  except WfajURorOkbXnQBAvTstFJlNpKGheu as exception:
   WfajURorOkbXnQBAvTstFJlNpKGhec(exception)
  return WfajURorOkbXnQBAvTstFJlNpKGhge,WfajURorOkbXnQBAvTstFJlNpKGhgP
 def GetEpisodeList(WfajURorOkbXnQBAvTstFJlNpKGhdM,program_code,page_int,orderby='desc'):
  WfajURorOkbXnQBAvTstFJlNpKGhge=[]
  WfajURorOkbXnQBAvTstFJlNpKGhgP=WfajURorOkbXnQBAvTstFJlNpKGheH
  try:
   WfajURorOkbXnQBAvTstFJlNpKGhCz ='/v2/media/frequency/program/'+program_code
   WfajURorOkbXnQBAvTstFJlNpKGhCE=WfajURorOkbXnQBAvTstFJlNpKGhdM.GetDefaultParams()
   WfajURorOkbXnQBAvTstFJlNpKGhCD={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   WfajURorOkbXnQBAvTstFJlNpKGhCE.update(WfajURorOkbXnQBAvTstFJlNpKGhCD)
   WfajURorOkbXnQBAvTstFJlNpKGhCH=WfajURorOkbXnQBAvTstFJlNpKGhdM.API_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhCz
   WfajURorOkbXnQBAvTstFJlNpKGhdi=WfajURorOkbXnQBAvTstFJlNpKGhdM.callRequestCookies('Get',WfajURorOkbXnQBAvTstFJlNpKGhCH,payload=WfajURorOkbXnQBAvTstFJlNpKGheD,params=WfajURorOkbXnQBAvTstFJlNpKGhCE,headers=WfajURorOkbXnQBAvTstFJlNpKGheD,cookies=WfajURorOkbXnQBAvTstFJlNpKGheD)
   WfajURorOkbXnQBAvTstFJlNpKGhCq=json.loads(WfajURorOkbXnQBAvTstFJlNpKGhdi.text)
   if not('result' in WfajURorOkbXnQBAvTstFJlNpKGhCq['body']):return WfajURorOkbXnQBAvTstFJlNpKGhge,WfajURorOkbXnQBAvTstFJlNpKGhgP
   WfajURorOkbXnQBAvTstFJlNpKGhgm=WfajURorOkbXnQBAvTstFJlNpKGhCq['body']['result']
   WfajURorOkbXnQBAvTstFJlNpKGhVD=WfajURorOkbXnQBAvTstFJlNpKGheq(WfajURorOkbXnQBAvTstFJlNpKGhCq['body']['total_count'])
   WfajURorOkbXnQBAvTstFJlNpKGhVH =WfajURorOkbXnQBAvTstFJlNpKGheq(WfajURorOkbXnQBAvTstFJlNpKGhVD//(WfajURorOkbXnQBAvTstFJlNpKGhdM.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    WfajURorOkbXnQBAvTstFJlNpKGhVq =(WfajURorOkbXnQBAvTstFJlNpKGhVD-1)-((page_int-1)*WfajURorOkbXnQBAvTstFJlNpKGhdM.EPISODE_LIMIT)
   else:
    WfajURorOkbXnQBAvTstFJlNpKGhVq =(page_int-1)*WfajURorOkbXnQBAvTstFJlNpKGhdM.EPISODE_LIMIT
   for i in WfajURorOkbXnQBAvTstFJlNpKGheL(WfajURorOkbXnQBAvTstFJlNpKGhdM.EPISODE_LIMIT):
    if orderby=='desc':
     WfajURorOkbXnQBAvTstFJlNpKGhVL=WfajURorOkbXnQBAvTstFJlNpKGhVq-i
     if WfajURorOkbXnQBAvTstFJlNpKGhVL<0:break
    else:
     WfajURorOkbXnQBAvTstFJlNpKGhVL=WfajURorOkbXnQBAvTstFJlNpKGhVq+i
     if WfajURorOkbXnQBAvTstFJlNpKGhVL>=WfajURorOkbXnQBAvTstFJlNpKGhVD:break
    WfajURorOkbXnQBAvTstFJlNpKGhVI=WfajURorOkbXnQBAvTstFJlNpKGhgm[WfajURorOkbXnQBAvTstFJlNpKGhVL]['episode']['code']
    WfajURorOkbXnQBAvTstFJlNpKGhgD =WfajURorOkbXnQBAvTstFJlNpKGhgm[WfajURorOkbXnQBAvTstFJlNpKGhVL]['vod_name']['ko']
    WfajURorOkbXnQBAvTstFJlNpKGhVc =''
    try:
     WfajURorOkbXnQBAvTstFJlNpKGhVS=WfajURorOkbXnQBAvTstFJlNpKGheY(WfajURorOkbXnQBAvTstFJlNpKGhgm[WfajURorOkbXnQBAvTstFJlNpKGhVL]['episode']['broadcast_date'])
     WfajURorOkbXnQBAvTstFJlNpKGhVc='%s-%s-%s'%(WfajURorOkbXnQBAvTstFJlNpKGhVS[:4],WfajURorOkbXnQBAvTstFJlNpKGhVS[4:6],WfajURorOkbXnQBAvTstFJlNpKGhVS[6:])
    except:
     WfajURorOkbXnQBAvTstFJlNpKGheD
    try:
     if WfajURorOkbXnQBAvTstFJlNpKGhgm[WfajURorOkbXnQBAvTstFJlNpKGhVL]['episode']['pip_cliptype']=='C012':
      WfajURorOkbXnQBAvTstFJlNpKGhVc+=' - Quick VOD'
    except:
     WfajURorOkbXnQBAvTstFJlNpKGheD
    WfajURorOkbXnQBAvTstFJlNpKGhgH =WfajURorOkbXnQBAvTstFJlNpKGhgm[WfajURorOkbXnQBAvTstFJlNpKGhVL]['episode']['synopsis']['ko']
    WfajURorOkbXnQBAvTstFJlNpKGhgL =''
    WfajURorOkbXnQBAvTstFJlNpKGhgq =''
    WfajURorOkbXnQBAvTstFJlNpKGhgI=''
    WfajURorOkbXnQBAvTstFJlNpKGhgc =''
    WfajURorOkbXnQBAvTstFJlNpKGhgu =''
    WfajURorOkbXnQBAvTstFJlNpKGhgY =''
    for WfajURorOkbXnQBAvTstFJlNpKGhgw in WfajURorOkbXnQBAvTstFJlNpKGhgm[WfajURorOkbXnQBAvTstFJlNpKGhVL]['program']['image']:
     if WfajURorOkbXnQBAvTstFJlNpKGhgw['code']=='CAIP0900':WfajURorOkbXnQBAvTstFJlNpKGhgL =WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhgw['url']
     elif WfajURorOkbXnQBAvTstFJlNpKGhgw['code']=='CAIP1800':WfajURorOkbXnQBAvTstFJlNpKGhgI=WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhgw['url']
     elif WfajURorOkbXnQBAvTstFJlNpKGhgw['code']=='CAIP2000':WfajURorOkbXnQBAvTstFJlNpKGhgc =WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhgw['url']
     elif WfajURorOkbXnQBAvTstFJlNpKGhgw['code']=='CAIP1900':WfajURorOkbXnQBAvTstFJlNpKGhgu =WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhgw['url']
     elif WfajURorOkbXnQBAvTstFJlNpKGhgw['code']=='CAIP0200':WfajURorOkbXnQBAvTstFJlNpKGhgY =WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhgw['url']
    for WfajURorOkbXnQBAvTstFJlNpKGhgw in WfajURorOkbXnQBAvTstFJlNpKGhgm[WfajURorOkbXnQBAvTstFJlNpKGhVL]['episode']['image']:
     if WfajURorOkbXnQBAvTstFJlNpKGhgw['code']=='CAIE0400':WfajURorOkbXnQBAvTstFJlNpKGhgq =WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhgw['url']
    try:
     WfajURorOkbXnQBAvTstFJlNpKGhVu=WfajURorOkbXnQBAvTstFJlNpKGhVw=WfajURorOkbXnQBAvTstFJlNpKGhVi=''
     WfajURorOkbXnQBAvTstFJlNpKGhVY=0
     WfajURorOkbXnQBAvTstFJlNpKGhVu =WfajURorOkbXnQBAvTstFJlNpKGhgm[WfajURorOkbXnQBAvTstFJlNpKGhVL]['program']['name']['ko']
     WfajURorOkbXnQBAvTstFJlNpKGhVw =WfajURorOkbXnQBAvTstFJlNpKGhVc
     WfajURorOkbXnQBAvTstFJlNpKGhVi =WfajURorOkbXnQBAvTstFJlNpKGhgm[WfajURorOkbXnQBAvTstFJlNpKGhVL]['channel']['name']['ko']
     if 'frequency' in WfajURorOkbXnQBAvTstFJlNpKGhgm[WfajURorOkbXnQBAvTstFJlNpKGhVL]['episode']:WfajURorOkbXnQBAvTstFJlNpKGhVY=WfajURorOkbXnQBAvTstFJlNpKGhgm[WfajURorOkbXnQBAvTstFJlNpKGhVL]['episode']['frequency']
    except:
     WfajURorOkbXnQBAvTstFJlNpKGheD
    WfajURorOkbXnQBAvTstFJlNpKGhVx={'episode':WfajURorOkbXnQBAvTstFJlNpKGhVI,'title':WfajURorOkbXnQBAvTstFJlNpKGhgD,'subtitle':WfajURorOkbXnQBAvTstFJlNpKGhVc,'thumbnail':{'poster':WfajURorOkbXnQBAvTstFJlNpKGhgL,'thumb':WfajURorOkbXnQBAvTstFJlNpKGhgq,'clearlogo':WfajURorOkbXnQBAvTstFJlNpKGhgI,'icon':WfajURorOkbXnQBAvTstFJlNpKGhgc,'banner':WfajURorOkbXnQBAvTstFJlNpKGhgu,'fanart':WfajURorOkbXnQBAvTstFJlNpKGhgY},'synopsis':WfajURorOkbXnQBAvTstFJlNpKGhgH,'info_title':WfajURorOkbXnQBAvTstFJlNpKGhVu,'aired':WfajURorOkbXnQBAvTstFJlNpKGhVw,'studio':WfajURorOkbXnQBAvTstFJlNpKGhVi,'frequency':WfajURorOkbXnQBAvTstFJlNpKGhVY}
    WfajURorOkbXnQBAvTstFJlNpKGhge.append(WfajURorOkbXnQBAvTstFJlNpKGhVx)
   if WfajURorOkbXnQBAvTstFJlNpKGhVH>page_int:WfajURorOkbXnQBAvTstFJlNpKGhgP=WfajURorOkbXnQBAvTstFJlNpKGheI
  except WfajURorOkbXnQBAvTstFJlNpKGheu as exception:
   WfajURorOkbXnQBAvTstFJlNpKGhec(exception)
  return WfajURorOkbXnQBAvTstFJlNpKGhge,WfajURorOkbXnQBAvTstFJlNpKGhgP,WfajURorOkbXnQBAvTstFJlNpKGhVH
 def GetMovieList(WfajURorOkbXnQBAvTstFJlNpKGhdM,genre,orderby,page_int):
  WfajURorOkbXnQBAvTstFJlNpKGhge=[]
  WfajURorOkbXnQBAvTstFJlNpKGhgP=WfajURorOkbXnQBAvTstFJlNpKGheH
  try:
   WfajURorOkbXnQBAvTstFJlNpKGhCz ='/v2/media/movies'
   WfajURorOkbXnQBAvTstFJlNpKGhCE=WfajURorOkbXnQBAvTstFJlNpKGhdM.GetDefaultParams()
   WfajURorOkbXnQBAvTstFJlNpKGhCD={'pageSize':WfajURorOkbXnQBAvTstFJlNpKGheY(WfajURorOkbXnQBAvTstFJlNpKGhdM.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N','pageNo':WfajURorOkbXnQBAvTstFJlNpKGheY(page_int),}
   if genre!='all' :WfajURorOkbXnQBAvTstFJlNpKGhCD['categoryCode']=genre
   WfajURorOkbXnQBAvTstFJlNpKGhCD['productPackageCode']=','.join(WfajURorOkbXnQBAvTstFJlNpKGhdM.MOVIE_LITE)
   WfajURorOkbXnQBAvTstFJlNpKGhCE.update(WfajURorOkbXnQBAvTstFJlNpKGhCD)
   WfajURorOkbXnQBAvTstFJlNpKGhCH=WfajURorOkbXnQBAvTstFJlNpKGhdM.API_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhCz
   for i in WfajURorOkbXnQBAvTstFJlNpKGheL(6):
    WfajURorOkbXnQBAvTstFJlNpKGhdi=WfajURorOkbXnQBAvTstFJlNpKGhdM.callRequestCookies('Get',WfajURorOkbXnQBAvTstFJlNpKGhCH,payload=WfajURorOkbXnQBAvTstFJlNpKGheD,params=WfajURorOkbXnQBAvTstFJlNpKGhCE,headers=WfajURorOkbXnQBAvTstFJlNpKGheD,cookies=WfajURorOkbXnQBAvTstFJlNpKGheD)
    WfajURorOkbXnQBAvTstFJlNpKGhCq=json.loads(WfajURorOkbXnQBAvTstFJlNpKGhdi.text)
    if 'product_year' in WfajURorOkbXnQBAvTstFJlNpKGhCq['body']['result'][0]['movie']:break
    time.sleep(0.1)
   if not('result' in WfajURorOkbXnQBAvTstFJlNpKGhCq['body']):return WfajURorOkbXnQBAvTstFJlNpKGhge,WfajURorOkbXnQBAvTstFJlNpKGhgP
   WfajURorOkbXnQBAvTstFJlNpKGhgm=WfajURorOkbXnQBAvTstFJlNpKGhCq['body']['result']
   for WfajURorOkbXnQBAvTstFJlNpKGhCu in WfajURorOkbXnQBAvTstFJlNpKGhgm:
    WfajURorOkbXnQBAvTstFJlNpKGhVy =WfajURorOkbXnQBAvTstFJlNpKGhCu['movie']['code']
    WfajURorOkbXnQBAvTstFJlNpKGhgD =WfajURorOkbXnQBAvTstFJlNpKGhCu['movie']['name']['ko'].strip()
    WfajURorOkbXnQBAvTstFJlNpKGhgD +=u' (%s)'%(WfajURorOkbXnQBAvTstFJlNpKGhCu.get('movie').get('product_year'))
    WfajURorOkbXnQBAvTstFJlNpKGhgL=''
    WfajURorOkbXnQBAvTstFJlNpKGhgq =''
    WfajURorOkbXnQBAvTstFJlNpKGhgI=''
    for WfajURorOkbXnQBAvTstFJlNpKGhgw in WfajURorOkbXnQBAvTstFJlNpKGhCu['movie']['image']:
     if WfajURorOkbXnQBAvTstFJlNpKGhgw['code']=='CAIM2100':WfajURorOkbXnQBAvTstFJlNpKGhgL =WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhgw['url']
     elif WfajURorOkbXnQBAvTstFJlNpKGhgw['code']=='CAIM0400':WfajURorOkbXnQBAvTstFJlNpKGhgq =WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhgw['url']
     elif WfajURorOkbXnQBAvTstFJlNpKGhgw['code']=='CAIM1800':WfajURorOkbXnQBAvTstFJlNpKGhgI=WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhgw['url']
    WfajURorOkbXnQBAvTstFJlNpKGhgH =WfajURorOkbXnQBAvTstFJlNpKGhCu['movie']['story']['ko']
    try:
     WfajURorOkbXnQBAvTstFJlNpKGhVu =WfajURorOkbXnQBAvTstFJlNpKGhCu['movie']['name']['ko'].strip()
     WfajURorOkbXnQBAvTstFJlNpKGhVC =WfajURorOkbXnQBAvTstFJlNpKGhCu.get('movie').get('product_year')
     WfajURorOkbXnQBAvTstFJlNpKGhVg =WfajURorOkbXnQBAvTstFJlNpKGhdV.get(WfajURorOkbXnQBAvTstFJlNpKGhCu.get('grade_code'))
     WfajURorOkbXnQBAvTstFJlNpKGhgi=[]
     WfajURorOkbXnQBAvTstFJlNpKGhgy=[]
     WfajURorOkbXnQBAvTstFJlNpKGhVd=[]
     WfajURorOkbXnQBAvTstFJlNpKGhMd=0
     WfajURorOkbXnQBAvTstFJlNpKGhVM=''
     WfajURorOkbXnQBAvTstFJlNpKGhVi =''
     for WfajURorOkbXnQBAvTstFJlNpKGhVe in WfajURorOkbXnQBAvTstFJlNpKGhCu.get('movie').get('actor'):
      if WfajURorOkbXnQBAvTstFJlNpKGhVe!='':WfajURorOkbXnQBAvTstFJlNpKGhgi.append(WfajURorOkbXnQBAvTstFJlNpKGhVe)
     for WfajURorOkbXnQBAvTstFJlNpKGhVP in WfajURorOkbXnQBAvTstFJlNpKGhCu.get('movie').get('director'):
      if WfajURorOkbXnQBAvTstFJlNpKGhVP!='':WfajURorOkbXnQBAvTstFJlNpKGhgy.append(WfajURorOkbXnQBAvTstFJlNpKGhVP)
     if WfajURorOkbXnQBAvTstFJlNpKGhCu.get('movie').get('category1_name').get('ko')!='':
      WfajURorOkbXnQBAvTstFJlNpKGhVd.append(WfajURorOkbXnQBAvTstFJlNpKGhCu['movie']['category1_name']['ko'])
     if WfajURorOkbXnQBAvTstFJlNpKGhCu.get('movie').get('category2_name').get('ko')!='':
      WfajURorOkbXnQBAvTstFJlNpKGhVd.append(WfajURorOkbXnQBAvTstFJlNpKGhCu['movie']['category2_name']['ko'])
     if 'duration' in WfajURorOkbXnQBAvTstFJlNpKGhCu.get('movie'):WfajURorOkbXnQBAvTstFJlNpKGhMd=WfajURorOkbXnQBAvTstFJlNpKGhCu.get('movie').get('duration')
     if 'release_date' in WfajURorOkbXnQBAvTstFJlNpKGhCu.get('movie'):
      WfajURorOkbXnQBAvTstFJlNpKGhVS=WfajURorOkbXnQBAvTstFJlNpKGheY(WfajURorOkbXnQBAvTstFJlNpKGhCu.get('movie').get('release_date'))
      if WfajURorOkbXnQBAvTstFJlNpKGhVS!='0':WfajURorOkbXnQBAvTstFJlNpKGhVM='%s-%s-%s'%(WfajURorOkbXnQBAvTstFJlNpKGhVS[:4],WfajURorOkbXnQBAvTstFJlNpKGhVS[4:6],WfajURorOkbXnQBAvTstFJlNpKGhVS[6:])
     if 'production' in WfajURorOkbXnQBAvTstFJlNpKGhCu.get('movie'):WfajURorOkbXnQBAvTstFJlNpKGhVi=WfajURorOkbXnQBAvTstFJlNpKGhCu.get('movie').get('production')
    except:
     WfajURorOkbXnQBAvTstFJlNpKGheD
    WfajURorOkbXnQBAvTstFJlNpKGhVx={'moviecode':WfajURorOkbXnQBAvTstFJlNpKGhVy,'title':WfajURorOkbXnQBAvTstFJlNpKGhgD,'thumbnail':{'poster':WfajURorOkbXnQBAvTstFJlNpKGhgL,'thumb':WfajURorOkbXnQBAvTstFJlNpKGhgq,'clearlogo':WfajURorOkbXnQBAvTstFJlNpKGhgI,'fanart':WfajURorOkbXnQBAvTstFJlNpKGhgq},'synopsis':WfajURorOkbXnQBAvTstFJlNpKGhgH,'info_title':WfajURorOkbXnQBAvTstFJlNpKGhVu,'year':WfajURorOkbXnQBAvTstFJlNpKGhVC,'cast':WfajURorOkbXnQBAvTstFJlNpKGhgi,'director':WfajURorOkbXnQBAvTstFJlNpKGhgy,'info_genre':WfajURorOkbXnQBAvTstFJlNpKGhVd,'duration':WfajURorOkbXnQBAvTstFJlNpKGhMd,'premiered':WfajURorOkbXnQBAvTstFJlNpKGhVM,'studio':WfajURorOkbXnQBAvTstFJlNpKGhVi,'mpaa':WfajURorOkbXnQBAvTstFJlNpKGhVg}
    WfajURorOkbXnQBAvTstFJlNpKGhMC=WfajURorOkbXnQBAvTstFJlNpKGheH
    for WfajURorOkbXnQBAvTstFJlNpKGhMg in WfajURorOkbXnQBAvTstFJlNpKGhCu['billing_package_id']:
     if WfajURorOkbXnQBAvTstFJlNpKGhMg in WfajURorOkbXnQBAvTstFJlNpKGhdM.MOVIE_LITE:
      WfajURorOkbXnQBAvTstFJlNpKGhMC=WfajURorOkbXnQBAvTstFJlNpKGheI
      break
    if WfajURorOkbXnQBAvTstFJlNpKGhMC==WfajURorOkbXnQBAvTstFJlNpKGheH: 
     WfajURorOkbXnQBAvTstFJlNpKGhVx['title']=WfajURorOkbXnQBAvTstFJlNpKGhVx['title']+' [개별구매]'
    WfajURorOkbXnQBAvTstFJlNpKGhge.append(WfajURorOkbXnQBAvTstFJlNpKGhVx)
   if WfajURorOkbXnQBAvTstFJlNpKGhCq['body']['has_more']=='Y':WfajURorOkbXnQBAvTstFJlNpKGhgP=WfajURorOkbXnQBAvTstFJlNpKGheI
  except WfajURorOkbXnQBAvTstFJlNpKGheu as exception:
   WfajURorOkbXnQBAvTstFJlNpKGhec(exception)
  return WfajURorOkbXnQBAvTstFJlNpKGhge,WfajURorOkbXnQBAvTstFJlNpKGhgP
 def GetMovieGenre(WfajURorOkbXnQBAvTstFJlNpKGhdM):
  WfajURorOkbXnQBAvTstFJlNpKGhge=[]
  WfajURorOkbXnQBAvTstFJlNpKGhgP=WfajURorOkbXnQBAvTstFJlNpKGheH
  try:
   WfajURorOkbXnQBAvTstFJlNpKGhCz ='/v2/media/movie/curations'
   WfajURorOkbXnQBAvTstFJlNpKGhCE=WfajURorOkbXnQBAvTstFJlNpKGhdM.GetDefaultParams()
   WfajURorOkbXnQBAvTstFJlNpKGhCD={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   WfajURorOkbXnQBAvTstFJlNpKGhCE.update(WfajURorOkbXnQBAvTstFJlNpKGhCD)
   WfajURorOkbXnQBAvTstFJlNpKGhCH=WfajURorOkbXnQBAvTstFJlNpKGhdM.API_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhCz
   WfajURorOkbXnQBAvTstFJlNpKGhdi=WfajURorOkbXnQBAvTstFJlNpKGhdM.callRequestCookies('Get',WfajURorOkbXnQBAvTstFJlNpKGhCH,payload=WfajURorOkbXnQBAvTstFJlNpKGheD,params=WfajURorOkbXnQBAvTstFJlNpKGhCE,headers=WfajURorOkbXnQBAvTstFJlNpKGheD,cookies=WfajURorOkbXnQBAvTstFJlNpKGheD)
   WfajURorOkbXnQBAvTstFJlNpKGhCq=json.loads(WfajURorOkbXnQBAvTstFJlNpKGhdi.text)
   if not('result' in WfajURorOkbXnQBAvTstFJlNpKGhCq['body']):return WfajURorOkbXnQBAvTstFJlNpKGhge,WfajURorOkbXnQBAvTstFJlNpKGhgP
   WfajURorOkbXnQBAvTstFJlNpKGhgm=WfajURorOkbXnQBAvTstFJlNpKGhCq['body']['result']
   for WfajURorOkbXnQBAvTstFJlNpKGhCu in WfajURorOkbXnQBAvTstFJlNpKGhgm:
    WfajURorOkbXnQBAvTstFJlNpKGhMV =WfajURorOkbXnQBAvTstFJlNpKGhCu['curation_code']
    WfajURorOkbXnQBAvTstFJlNpKGhMe =WfajURorOkbXnQBAvTstFJlNpKGhCu['curation_name']
    WfajURorOkbXnQBAvTstFJlNpKGhVx={'curation_code':WfajURorOkbXnQBAvTstFJlNpKGhMV,'curation_name':WfajURorOkbXnQBAvTstFJlNpKGhMe}
    WfajURorOkbXnQBAvTstFJlNpKGhge.append(WfajURorOkbXnQBAvTstFJlNpKGhVx)
  except WfajURorOkbXnQBAvTstFJlNpKGheu as exception:
   WfajURorOkbXnQBAvTstFJlNpKGhec(exception)
  return WfajURorOkbXnQBAvTstFJlNpKGhge,WfajURorOkbXnQBAvTstFJlNpKGhgP
 def GetSearchList(WfajURorOkbXnQBAvTstFJlNpKGhdM,search_key,page_int,stype):
  WfajURorOkbXnQBAvTstFJlNpKGhMP=[]
  WfajURorOkbXnQBAvTstFJlNpKGhgP=WfajURorOkbXnQBAvTstFJlNpKGheH
  try:
   WfajURorOkbXnQBAvTstFJlNpKGhCz ='/search/getSearch.jsp'
   WfajURorOkbXnQBAvTstFJlNpKGhCD={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':WfajURorOkbXnQBAvTstFJlNpKGheY(page_int),'pageSize':WfajURorOkbXnQBAvTstFJlNpKGheY(WfajURorOkbXnQBAvTstFJlNpKGhdM.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':WfajURorOkbXnQBAvTstFJlNpKGhdM.SCREENCODE,'os':WfajURorOkbXnQBAvTstFJlNpKGhdM.OSCODE,'network':WfajURorOkbXnQBAvTstFJlNpKGhdM.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':WfajURorOkbXnQBAvTstFJlNpKGheY(WfajURorOkbXnQBAvTstFJlNpKGhdM.SEARCH_LIMIT)if stype=='vod' else '','vodMVReqCnt':WfajURorOkbXnQBAvTstFJlNpKGheY(WfajURorOkbXnQBAvTstFJlNpKGhdM.SEARCH_LIMIT)if stype=='movie' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':''}
   WfajURorOkbXnQBAvTstFJlNpKGhCH=WfajURorOkbXnQBAvTstFJlNpKGhdM.SEARCH_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhCz
   WfajURorOkbXnQBAvTstFJlNpKGhdi=WfajURorOkbXnQBAvTstFJlNpKGhdM.callRequestCookies('Get',WfajURorOkbXnQBAvTstFJlNpKGhCH,payload=WfajURorOkbXnQBAvTstFJlNpKGheD,params=WfajURorOkbXnQBAvTstFJlNpKGhCD,headers=WfajURorOkbXnQBAvTstFJlNpKGheD,cookies=WfajURorOkbXnQBAvTstFJlNpKGheD)
   WfajURorOkbXnQBAvTstFJlNpKGhCq=json.loads(WfajURorOkbXnQBAvTstFJlNpKGhdi.text)
   if stype=='vod':
    if not('programRsb' in WfajURorOkbXnQBAvTstFJlNpKGhCq):return WfajURorOkbXnQBAvTstFJlNpKGhMP,WfajURorOkbXnQBAvTstFJlNpKGhgP
    WfajURorOkbXnQBAvTstFJlNpKGhMS=WfajURorOkbXnQBAvTstFJlNpKGhCq['programRsb']['dataList']
    WfajURorOkbXnQBAvTstFJlNpKGhMm =WfajURorOkbXnQBAvTstFJlNpKGheq(WfajURorOkbXnQBAvTstFJlNpKGhCq['programRsb']['count'])
    for WfajURorOkbXnQBAvTstFJlNpKGhCu in WfajURorOkbXnQBAvTstFJlNpKGhMS:
     WfajURorOkbXnQBAvTstFJlNpKGhVz=WfajURorOkbXnQBAvTstFJlNpKGhCu['mast_cd']
     WfajURorOkbXnQBAvTstFJlNpKGhgD =WfajURorOkbXnQBAvTstFJlNpKGhCu['mast_nm']
     WfajURorOkbXnQBAvTstFJlNpKGhgL=WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhCu['web_url4']
     WfajURorOkbXnQBAvTstFJlNpKGhgq =WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhCu['web_url']
     try:
      WfajURorOkbXnQBAvTstFJlNpKGhgi =[]
      WfajURorOkbXnQBAvTstFJlNpKGhgy=[]
      WfajURorOkbXnQBAvTstFJlNpKGhVd =[]
      WfajURorOkbXnQBAvTstFJlNpKGhMd =0
      WfajURorOkbXnQBAvTstFJlNpKGhVg =''
      WfajURorOkbXnQBAvTstFJlNpKGhVC =''
      WfajURorOkbXnQBAvTstFJlNpKGhVw =''
      if WfajURorOkbXnQBAvTstFJlNpKGhCu.get('actor') !='' and WfajURorOkbXnQBAvTstFJlNpKGhCu.get('actor') !='-':WfajURorOkbXnQBAvTstFJlNpKGhgi =WfajURorOkbXnQBAvTstFJlNpKGhCu.get('actor').split(',')
      if WfajURorOkbXnQBAvTstFJlNpKGhCu.get('director')!='' and WfajURorOkbXnQBAvTstFJlNpKGhCu.get('director')!='-':WfajURorOkbXnQBAvTstFJlNpKGhgy=WfajURorOkbXnQBAvTstFJlNpKGhCu.get('director').split(',')
      if WfajURorOkbXnQBAvTstFJlNpKGhCu.get('cate_nm')!='' and WfajURorOkbXnQBAvTstFJlNpKGhCu.get('cate_nm')!='-':WfajURorOkbXnQBAvTstFJlNpKGhVd =WfajURorOkbXnQBAvTstFJlNpKGhCu.get('cate_nm').split('/')
      if 'targetage' in WfajURorOkbXnQBAvTstFJlNpKGhCu:WfajURorOkbXnQBAvTstFJlNpKGhVg=WfajURorOkbXnQBAvTstFJlNpKGhCu.get('targetage')
      if 'broad_dt' in WfajURorOkbXnQBAvTstFJlNpKGhCu:
       WfajURorOkbXnQBAvTstFJlNpKGhVS=WfajURorOkbXnQBAvTstFJlNpKGhCu.get('broad_dt')
       WfajURorOkbXnQBAvTstFJlNpKGhVw='%s-%s-%s'%(WfajURorOkbXnQBAvTstFJlNpKGhVS[:4],WfajURorOkbXnQBAvTstFJlNpKGhVS[4:6],WfajURorOkbXnQBAvTstFJlNpKGhVS[6:])
       WfajURorOkbXnQBAvTstFJlNpKGhVC =WfajURorOkbXnQBAvTstFJlNpKGhVS[:4]
     except:
      WfajURorOkbXnQBAvTstFJlNpKGheD
     WfajURorOkbXnQBAvTstFJlNpKGhVx={'program':WfajURorOkbXnQBAvTstFJlNpKGhVz,'title':WfajURorOkbXnQBAvTstFJlNpKGhgD,'thumbnail':{'poster':WfajURorOkbXnQBAvTstFJlNpKGhgL,'thumb':WfajURorOkbXnQBAvTstFJlNpKGhgq,'fanart':WfajURorOkbXnQBAvTstFJlNpKGhgq},'synopsis':'','cast':WfajURorOkbXnQBAvTstFJlNpKGhgi,'director':WfajURorOkbXnQBAvTstFJlNpKGhgy,'info_genre':WfajURorOkbXnQBAvTstFJlNpKGhVd,'duration':WfajURorOkbXnQBAvTstFJlNpKGhMd,'mpaa':WfajURorOkbXnQBAvTstFJlNpKGhVg,'year':WfajURorOkbXnQBAvTstFJlNpKGhVC,'aired':WfajURorOkbXnQBAvTstFJlNpKGhVw}
     WfajURorOkbXnQBAvTstFJlNpKGhMP.append(WfajURorOkbXnQBAvTstFJlNpKGhVx)
   else:
    if not('vodMVRsb' in WfajURorOkbXnQBAvTstFJlNpKGhCq):return WfajURorOkbXnQBAvTstFJlNpKGhMP,WfajURorOkbXnQBAvTstFJlNpKGhgP
    WfajURorOkbXnQBAvTstFJlNpKGhMx=WfajURorOkbXnQBAvTstFJlNpKGhCq['vodMVRsb']['dataList']
    WfajURorOkbXnQBAvTstFJlNpKGhMm =WfajURorOkbXnQBAvTstFJlNpKGheq(WfajURorOkbXnQBAvTstFJlNpKGhCq['vodMVRsb']['count'])
    for WfajURorOkbXnQBAvTstFJlNpKGhCu in WfajURorOkbXnQBAvTstFJlNpKGhMx:
     WfajURorOkbXnQBAvTstFJlNpKGhVz=WfajURorOkbXnQBAvTstFJlNpKGhCu['mast_cd']
     WfajURorOkbXnQBAvTstFJlNpKGhgD =WfajURorOkbXnQBAvTstFJlNpKGhCu['mast_nm'].strip()
     WfajURorOkbXnQBAvTstFJlNpKGhgL =WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhCu['web_url']
     WfajURorOkbXnQBAvTstFJlNpKGhgq =WfajURorOkbXnQBAvTstFJlNpKGhgL
     WfajURorOkbXnQBAvTstFJlNpKGhgI=''
     try:
      WfajURorOkbXnQBAvTstFJlNpKGhgi =[]
      WfajURorOkbXnQBAvTstFJlNpKGhgy=[]
      WfajURorOkbXnQBAvTstFJlNpKGhVd =[]
      WfajURorOkbXnQBAvTstFJlNpKGhMd =0
      WfajURorOkbXnQBAvTstFJlNpKGhVg =''
      WfajURorOkbXnQBAvTstFJlNpKGhVC =''
      WfajURorOkbXnQBAvTstFJlNpKGhVw =''
      if WfajURorOkbXnQBAvTstFJlNpKGhCu.get('actor') !='' and WfajURorOkbXnQBAvTstFJlNpKGhCu.get('actor') !='-':WfajURorOkbXnQBAvTstFJlNpKGhgi =WfajURorOkbXnQBAvTstFJlNpKGhCu.get('actor').split(',')
      if WfajURorOkbXnQBAvTstFJlNpKGhCu.get('director')!='' and WfajURorOkbXnQBAvTstFJlNpKGhCu.get('director')!='-':WfajURorOkbXnQBAvTstFJlNpKGhgy=WfajURorOkbXnQBAvTstFJlNpKGhCu.get('director').split(',')
      if WfajURorOkbXnQBAvTstFJlNpKGhCu.get('cate_nm')!='' and WfajURorOkbXnQBAvTstFJlNpKGhCu.get('cate_nm')!='-':WfajURorOkbXnQBAvTstFJlNpKGhVd =WfajURorOkbXnQBAvTstFJlNpKGhCu.get('cate_nm').split('/')
      if WfajURorOkbXnQBAvTstFJlNpKGhCu.get('runtime_sec')!='':WfajURorOkbXnQBAvTstFJlNpKGhMd=WfajURorOkbXnQBAvTstFJlNpKGhCu.get('runtime_sec')
      if 'grade_nm' in WfajURorOkbXnQBAvTstFJlNpKGhCu:WfajURorOkbXnQBAvTstFJlNpKGhVg=WfajURorOkbXnQBAvTstFJlNpKGhCu.get('grade_nm')
      WfajURorOkbXnQBAvTstFJlNpKGhVS=WfajURorOkbXnQBAvTstFJlNpKGhCu.get('broad_dt')
      if data_str!='':
       WfajURorOkbXnQBAvTstFJlNpKGhVw='%s-%s-%s'%(WfajURorOkbXnQBAvTstFJlNpKGhVS[:4],WfajURorOkbXnQBAvTstFJlNpKGhVS[4:6],WfajURorOkbXnQBAvTstFJlNpKGhVS[6:])
       WfajURorOkbXnQBAvTstFJlNpKGhVC =WfajURorOkbXnQBAvTstFJlNpKGhVS[:4]
     except:
      WfajURorOkbXnQBAvTstFJlNpKGheD
     WfajURorOkbXnQBAvTstFJlNpKGhVx={'movie':WfajURorOkbXnQBAvTstFJlNpKGhVz,'title':WfajURorOkbXnQBAvTstFJlNpKGhgD,'thumbnail':{'poster':WfajURorOkbXnQBAvTstFJlNpKGhgL,'thumb':WfajURorOkbXnQBAvTstFJlNpKGhgq,'fanart':WfajURorOkbXnQBAvTstFJlNpKGhgq,'clearlogo':WfajURorOkbXnQBAvTstFJlNpKGhgI},'synopsis':'','cast':WfajURorOkbXnQBAvTstFJlNpKGhgi,'director':WfajURorOkbXnQBAvTstFJlNpKGhgy,'info_genre':WfajURorOkbXnQBAvTstFJlNpKGhVd,'duration':WfajURorOkbXnQBAvTstFJlNpKGhMd,'mpaa':WfajURorOkbXnQBAvTstFJlNpKGhVg,'year':WfajURorOkbXnQBAvTstFJlNpKGhVC,'aired':WfajURorOkbXnQBAvTstFJlNpKGhVw}
     WfajURorOkbXnQBAvTstFJlNpKGhMC=WfajURorOkbXnQBAvTstFJlNpKGheH
     for WfajURorOkbXnQBAvTstFJlNpKGhMg in WfajURorOkbXnQBAvTstFJlNpKGhCu['bill']:
      if WfajURorOkbXnQBAvTstFJlNpKGhMg in WfajURorOkbXnQBAvTstFJlNpKGhdM.MOVIE_LITE:
       WfajURorOkbXnQBAvTstFJlNpKGhMC=WfajURorOkbXnQBAvTstFJlNpKGheI
       break
     if WfajURorOkbXnQBAvTstFJlNpKGhMC==WfajURorOkbXnQBAvTstFJlNpKGheH: 
      WfajURorOkbXnQBAvTstFJlNpKGhVx['title']=WfajURorOkbXnQBAvTstFJlNpKGhVx['title']+' [개별구매]'
     WfajURorOkbXnQBAvTstFJlNpKGhMP.append(WfajURorOkbXnQBAvTstFJlNpKGhVx)
   if WfajURorOkbXnQBAvTstFJlNpKGhMm>(page_int*WfajURorOkbXnQBAvTstFJlNpKGhdM.SEARCH_LIMIT):WfajURorOkbXnQBAvTstFJlNpKGhgP=WfajURorOkbXnQBAvTstFJlNpKGheI
  except WfajURorOkbXnQBAvTstFJlNpKGheu as exception:
   WfajURorOkbXnQBAvTstFJlNpKGhec(exception)
  return WfajURorOkbXnQBAvTstFJlNpKGhMP,WfajURorOkbXnQBAvTstFJlNpKGhgP
 def GetDeviceList(WfajURorOkbXnQBAvTstFJlNpKGhdM,WfajURorOkbXnQBAvTstFJlNpKGhCd,WfajURorOkbXnQBAvTstFJlNpKGhCg):
  WfajURorOkbXnQBAvTstFJlNpKGhge=[]
  WfajURorOkbXnQBAvTstFJlNpKGhCS='-'
  try:
   WfajURorOkbXnQBAvTstFJlNpKGhCz ='/v1/user/device/list'
   WfajURorOkbXnQBAvTstFJlNpKGhMz=WfajURorOkbXnQBAvTstFJlNpKGhdM.API_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhCz
   WfajURorOkbXnQBAvTstFJlNpKGhCD={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   WfajURorOkbXnQBAvTstFJlNpKGhdS=WfajURorOkbXnQBAvTstFJlNpKGhdM.makeDefaultCookies(vToken=WfajURorOkbXnQBAvTstFJlNpKGhCd,vUserinfo=WfajURorOkbXnQBAvTstFJlNpKGhCg)
   WfajURorOkbXnQBAvTstFJlNpKGhdi=WfajURorOkbXnQBAvTstFJlNpKGhdM.callRequestCookies('Get',WfajURorOkbXnQBAvTstFJlNpKGhMz,payload=WfajURorOkbXnQBAvTstFJlNpKGheD,params=WfajURorOkbXnQBAvTstFJlNpKGhCD,headers=WfajURorOkbXnQBAvTstFJlNpKGheD,cookies=WfajURorOkbXnQBAvTstFJlNpKGhdS)
   WfajURorOkbXnQBAvTstFJlNpKGhCq=json.loads(WfajURorOkbXnQBAvTstFJlNpKGhdi.text)
   WfajURorOkbXnQBAvTstFJlNpKGhec(WfajURorOkbXnQBAvTstFJlNpKGhCq)
   WfajURorOkbXnQBAvTstFJlNpKGhge=WfajURorOkbXnQBAvTstFJlNpKGhCq['body']
   for WfajURorOkbXnQBAvTstFJlNpKGhCu in WfajURorOkbXnQBAvTstFJlNpKGhge:
    if WfajURorOkbXnQBAvTstFJlNpKGhCu['model']=='PC' or WfajURorOkbXnQBAvTstFJlNpKGhCu['model']=='PC-Chrome':
     WfajURorOkbXnQBAvTstFJlNpKGhCS=WfajURorOkbXnQBAvTstFJlNpKGhCu['uuid']
  except WfajURorOkbXnQBAvTstFJlNpKGheu as exception:
   WfajURorOkbXnQBAvTstFJlNpKGhec(exception)
  return WfajURorOkbXnQBAvTstFJlNpKGhCS
 def GetProfileToken(WfajURorOkbXnQBAvTstFJlNpKGhdM,WfajURorOkbXnQBAvTstFJlNpKGhCd,WfajURorOkbXnQBAvTstFJlNpKGhCg,user_pf):
  WfajURorOkbXnQBAvTstFJlNpKGhME=[]
  WfajURorOkbXnQBAvTstFJlNpKGhMD =''
  WfajURorOkbXnQBAvTstFJlNpKGhMH =''
  WfajURorOkbXnQBAvTstFJlNpKGhMq='Y'
  WfajURorOkbXnQBAvTstFJlNpKGhML ='N'
  try:
   WfajURorOkbXnQBAvTstFJlNpKGhCz ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com'
   WfajURorOkbXnQBAvTstFJlNpKGhdS=WfajURorOkbXnQBAvTstFJlNpKGhdM.makeDefaultCookies(vToken=WfajURorOkbXnQBAvTstFJlNpKGhCd,vUserinfo=WfajURorOkbXnQBAvTstFJlNpKGhCg)
   WfajURorOkbXnQBAvTstFJlNpKGhdi=WfajURorOkbXnQBAvTstFJlNpKGhdM.callRequestCookies('Get',WfajURorOkbXnQBAvTstFJlNpKGhCz,payload=WfajURorOkbXnQBAvTstFJlNpKGheD,params=WfajURorOkbXnQBAvTstFJlNpKGheD,headers=WfajURorOkbXnQBAvTstFJlNpKGheD,cookies=WfajURorOkbXnQBAvTstFJlNpKGhdS)
   WfajURorOkbXnQBAvTstFJlNpKGhME =re.findall('data-profile-no="\d+"',WfajURorOkbXnQBAvTstFJlNpKGhdi.text)
   for i in WfajURorOkbXnQBAvTstFJlNpKGheL(WfajURorOkbXnQBAvTstFJlNpKGhei(WfajURorOkbXnQBAvTstFJlNpKGhME)):
    WfajURorOkbXnQBAvTstFJlNpKGhMI =WfajURorOkbXnQBAvTstFJlNpKGhME[i].replace('data-profile-no=','').replace('"','')
    WfajURorOkbXnQBAvTstFJlNpKGhME[i]=WfajURorOkbXnQBAvTstFJlNpKGhMI
   WfajURorOkbXnQBAvTstFJlNpKGhMD=WfajURorOkbXnQBAvTstFJlNpKGhME[user_pf]
  except WfajURorOkbXnQBAvTstFJlNpKGheu as exception:
   WfajURorOkbXnQBAvTstFJlNpKGhec(exception)
   return WfajURorOkbXnQBAvTstFJlNpKGhMH,WfajURorOkbXnQBAvTstFJlNpKGhMq,WfajURorOkbXnQBAvTstFJlNpKGhML
  try:
   WfajURorOkbXnQBAvTstFJlNpKGhCz ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   WfajURorOkbXnQBAvTstFJlNpKGhdS=WfajURorOkbXnQBAvTstFJlNpKGhdM.makeDefaultCookies(vToken=WfajURorOkbXnQBAvTstFJlNpKGhCd,vUserinfo=WfajURorOkbXnQBAvTstFJlNpKGhCg)
   WfajURorOkbXnQBAvTstFJlNpKGhdw={'profileNo':WfajURorOkbXnQBAvTstFJlNpKGhMD}
   WfajURorOkbXnQBAvTstFJlNpKGhdi=WfajURorOkbXnQBAvTstFJlNpKGhdM.callRequestCookies('Post',WfajURorOkbXnQBAvTstFJlNpKGhCz,payload=WfajURorOkbXnQBAvTstFJlNpKGhdw,params=WfajURorOkbXnQBAvTstFJlNpKGheD,headers=WfajURorOkbXnQBAvTstFJlNpKGheD,cookies=WfajURorOkbXnQBAvTstFJlNpKGhdS)
   for WfajURorOkbXnQBAvTstFJlNpKGhdy in WfajURorOkbXnQBAvTstFJlNpKGhdi.cookies:
    if WfajURorOkbXnQBAvTstFJlNpKGhdy.name=='_tving_token':
     WfajURorOkbXnQBAvTstFJlNpKGhMH=WfajURorOkbXnQBAvTstFJlNpKGhdy.value
    elif WfajURorOkbXnQBAvTstFJlNpKGhdy.name==WfajURorOkbXnQBAvTstFJlNpKGhdM.GLOBAL_COOKIENM['tv_cookiekey']:
     WfajURorOkbXnQBAvTstFJlNpKGhMq=WfajURorOkbXnQBAvTstFJlNpKGhdy.value
    elif WfajURorOkbXnQBAvTstFJlNpKGhdy.name==WfajURorOkbXnQBAvTstFJlNpKGhdM.GLOBAL_COOKIENM['tv_lockkey']:
     WfajURorOkbXnQBAvTstFJlNpKGhML=WfajURorOkbXnQBAvTstFJlNpKGhdy.value
  except WfajURorOkbXnQBAvTstFJlNpKGheu as exception:
   WfajURorOkbXnQBAvTstFJlNpKGhec(exception)
  return WfajURorOkbXnQBAvTstFJlNpKGhMH,WfajURorOkbXnQBAvTstFJlNpKGhMq,WfajURorOkbXnQBAvTstFJlNpKGhML
 def GetProfileLockYN(WfajURorOkbXnQBAvTstFJlNpKGhdM,WfajURorOkbXnQBAvTstFJlNpKGhCd,WfajURorOkbXnQBAvTstFJlNpKGhCg):
  WfajURorOkbXnQBAvTstFJlNpKGhME=[]
  WfajURorOkbXnQBAvTstFJlNpKGhML ='N'
  try:
   WfajURorOkbXnQBAvTstFJlNpKGhCz ='/profile/select.do'
   WfajURorOkbXnQBAvTstFJlNpKGhMz=WfajURorOkbXnQBAvTstFJlNpKGhdM.URL_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhCz
   WfajURorOkbXnQBAvTstFJlNpKGhdS=WfajURorOkbXnQBAvTstFJlNpKGhdM.makeDefaultCookies(vToken=WfajURorOkbXnQBAvTstFJlNpKGhCd,vUserinfo=WfajURorOkbXnQBAvTstFJlNpKGhCg)
   WfajURorOkbXnQBAvTstFJlNpKGhdi=WfajURorOkbXnQBAvTstFJlNpKGhdM.callRequestCookies('Get',WfajURorOkbXnQBAvTstFJlNpKGhMz,payload=WfajURorOkbXnQBAvTstFJlNpKGheD,params=WfajURorOkbXnQBAvTstFJlNpKGheD,headers=WfajURorOkbXnQBAvTstFJlNpKGheD,cookies=WfajURorOkbXnQBAvTstFJlNpKGhdS)
   WfajURorOkbXnQBAvTstFJlNpKGhME =re.findall('data-profile-no="\d+"',WfajURorOkbXnQBAvTstFJlNpKGhdi.text)
   for i in WfajURorOkbXnQBAvTstFJlNpKGheL(WfajURorOkbXnQBAvTstFJlNpKGhei(WfajURorOkbXnQBAvTstFJlNpKGhME)):
    WfajURorOkbXnQBAvTstFJlNpKGhMI =WfajURorOkbXnQBAvTstFJlNpKGhME[i].replace('data-profile-no=','').replace('"','')
    WfajURorOkbXnQBAvTstFJlNpKGhME[i]=WfajURorOkbXnQBAvTstFJlNpKGhMI
  except WfajURorOkbXnQBAvTstFJlNpKGheu as exception:
   WfajURorOkbXnQBAvTstFJlNpKGhec(exception)
   return WfajURorOkbXnQBAvTstFJlNpKGhML
  try:
   WfajURorOkbXnQBAvTstFJlNpKGhCz ='/profile/api/select.do'
   WfajURorOkbXnQBAvTstFJlNpKGhMz=WfajURorOkbXnQBAvTstFJlNpKGhdM.URL_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhCz
   WfajURorOkbXnQBAvTstFJlNpKGhdS=WfajURorOkbXnQBAvTstFJlNpKGhdM.makeDefaultCookies(vToken=WfajURorOkbXnQBAvTstFJlNpKGhCd,vUserinfo=WfajURorOkbXnQBAvTstFJlNpKGhCg)
   for i in WfajURorOkbXnQBAvTstFJlNpKGheL(WfajURorOkbXnQBAvTstFJlNpKGhei(WfajURorOkbXnQBAvTstFJlNpKGhME)):
    WfajURorOkbXnQBAvTstFJlNpKGhdw={'profileNo':WfajURorOkbXnQBAvTstFJlNpKGhME[i]}
    WfajURorOkbXnQBAvTstFJlNpKGhdi=WfajURorOkbXnQBAvTstFJlNpKGhdM.callRequestCookies('Post',WfajURorOkbXnQBAvTstFJlNpKGhMz,payload=WfajURorOkbXnQBAvTstFJlNpKGhdw,params=WfajURorOkbXnQBAvTstFJlNpKGheD,headers=WfajURorOkbXnQBAvTstFJlNpKGheD,cookies=WfajURorOkbXnQBAvTstFJlNpKGhdS)
    for WfajURorOkbXnQBAvTstFJlNpKGhdy in WfajURorOkbXnQBAvTstFJlNpKGhdi.cookies:
     if WfajURorOkbXnQBAvTstFJlNpKGhdy.name=='_tving_token':
      WfajURorOkbXnQBAvTstFJlNpKGhMc=WfajURorOkbXnQBAvTstFJlNpKGhdy.value
     elif WfajURorOkbXnQBAvTstFJlNpKGhdy.name==WfajURorOkbXnQBAvTstFJlNpKGhdM.GLOBAL_COOKIENM['tv_lockkey']:
      WfajURorOkbXnQBAvTstFJlNpKGhMu=WfajURorOkbXnQBAvTstFJlNpKGhdy.value
    if WfajURorOkbXnQBAvTstFJlNpKGhMc==WfajURorOkbXnQBAvTstFJlNpKGhCd:
     WfajURorOkbXnQBAvTstFJlNpKGhML=WfajURorOkbXnQBAvTstFJlNpKGhMu
     WfajURorOkbXnQBAvTstFJlNpKGhec(WfajURorOkbXnQBAvTstFJlNpKGhCd)
     break
  except WfajURorOkbXnQBAvTstFJlNpKGheu as exception:
   WfajURorOkbXnQBAvTstFJlNpKGhec(exception)
  return WfajURorOkbXnQBAvTstFJlNpKGhML
 def GetBookmarkInfo(WfajURorOkbXnQBAvTstFJlNpKGhdM,videoid,vidtype):
  WfajURorOkbXnQBAvTstFJlNpKGhMY={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   WfajURorOkbXnQBAvTstFJlNpKGhCH=WfajURorOkbXnQBAvTstFJlNpKGhdM.API_DOMAIN+'/v2/media/program/'+videoid
   WfajURorOkbXnQBAvTstFJlNpKGhCE=WfajURorOkbXnQBAvTstFJlNpKGhdM.GetDefaultParams()
   WfajURorOkbXnQBAvTstFJlNpKGhCD={'pageNo':'1','pageSize':'10','order':'name',}
   WfajURorOkbXnQBAvTstFJlNpKGhCE.update(WfajURorOkbXnQBAvTstFJlNpKGhCD)
   WfajURorOkbXnQBAvTstFJlNpKGhdi=WfajURorOkbXnQBAvTstFJlNpKGhdM.callRequestCookies('Get',WfajURorOkbXnQBAvTstFJlNpKGhCH,payload=WfajURorOkbXnQBAvTstFJlNpKGheD,params=WfajURorOkbXnQBAvTstFJlNpKGhCE,headers=WfajURorOkbXnQBAvTstFJlNpKGheD,cookies=WfajURorOkbXnQBAvTstFJlNpKGheD)
   WfajURorOkbXnQBAvTstFJlNpKGhMw=json.loads(WfajURorOkbXnQBAvTstFJlNpKGhdi.text)
   if not('body' in WfajURorOkbXnQBAvTstFJlNpKGhMw):return{}
   WfajURorOkbXnQBAvTstFJlNpKGhMi=WfajURorOkbXnQBAvTstFJlNpKGhMw['body']
   WfajURorOkbXnQBAvTstFJlNpKGhgD=WfajURorOkbXnQBAvTstFJlNpKGhMi.get('name').get('ko').strip()
   WfajURorOkbXnQBAvTstFJlNpKGhMY['saveinfo']['title'] =WfajURorOkbXnQBAvTstFJlNpKGhgD
   WfajURorOkbXnQBAvTstFJlNpKGhMY['saveinfo']['infoLabels']['title']=WfajURorOkbXnQBAvTstFJlNpKGhgD
   WfajURorOkbXnQBAvTstFJlNpKGhMY['saveinfo']['infoLabels']['mpaa'] =WfajURorOkbXnQBAvTstFJlNpKGhdV.get(WfajURorOkbXnQBAvTstFJlNpKGhMi.get('grade_code'))
   WfajURorOkbXnQBAvTstFJlNpKGhMY['saveinfo']['infoLabels']['plot'] =WfajURorOkbXnQBAvTstFJlNpKGhMi.get('synopsis').get('ko')
   WfajURorOkbXnQBAvTstFJlNpKGhMY['saveinfo']['infoLabels']['year'] =WfajURorOkbXnQBAvTstFJlNpKGhMi.get('product_year')
   WfajURorOkbXnQBAvTstFJlNpKGhMY['saveinfo']['infoLabels']['cast'] =WfajURorOkbXnQBAvTstFJlNpKGhMi.get('actor')
   WfajURorOkbXnQBAvTstFJlNpKGhMY['saveinfo']['infoLabels']['director']=WfajURorOkbXnQBAvTstFJlNpKGhMi.get('director')
   if WfajURorOkbXnQBAvTstFJlNpKGhMi.get('category1_name').get('ko')!='':
    WfajURorOkbXnQBAvTstFJlNpKGhMY['saveinfo']['infoLabels']['genre'].append(WfajURorOkbXnQBAvTstFJlNpKGhMi.get('category1_name').get('ko'))
   if WfajURorOkbXnQBAvTstFJlNpKGhMi.get('category2_name').get('ko')!='':
    WfajURorOkbXnQBAvTstFJlNpKGhMY['saveinfo']['infoLabels']['genre'].append(WfajURorOkbXnQBAvTstFJlNpKGhMi.get('category2_name').get('ko'))
   WfajURorOkbXnQBAvTstFJlNpKGhVS=WfajURorOkbXnQBAvTstFJlNpKGheY(WfajURorOkbXnQBAvTstFJlNpKGhMi.get('broad_dt'))
   if WfajURorOkbXnQBAvTstFJlNpKGhVS!='0':WfajURorOkbXnQBAvTstFJlNpKGhMY['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(WfajURorOkbXnQBAvTstFJlNpKGhVS[:4],WfajURorOkbXnQBAvTstFJlNpKGhVS[4:6],WfajURorOkbXnQBAvTstFJlNpKGhVS[6:])
   WfajURorOkbXnQBAvTstFJlNpKGhgL =''
   WfajURorOkbXnQBAvTstFJlNpKGhgq =''
   WfajURorOkbXnQBAvTstFJlNpKGhgI=''
   WfajURorOkbXnQBAvTstFJlNpKGhgc =''
   WfajURorOkbXnQBAvTstFJlNpKGhgu =''
   for WfajURorOkbXnQBAvTstFJlNpKGhgw in WfajURorOkbXnQBAvTstFJlNpKGhMi.get('image'):
    if WfajURorOkbXnQBAvTstFJlNpKGhgw.get('code')=='CAIP0900':WfajURorOkbXnQBAvTstFJlNpKGhgL =WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhgw.get('url')
    elif WfajURorOkbXnQBAvTstFJlNpKGhgw.get('code')=='CAIP0200':WfajURorOkbXnQBAvTstFJlNpKGhgq =WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhgw.get('url')
    elif WfajURorOkbXnQBAvTstFJlNpKGhgw.get('code')=='CAIP1800':WfajURorOkbXnQBAvTstFJlNpKGhgI=WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhgw.get('url')
    elif WfajURorOkbXnQBAvTstFJlNpKGhgw.get('code')=='CAIP2000':WfajURorOkbXnQBAvTstFJlNpKGhgc =WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhgw.get('url')
    elif WfajURorOkbXnQBAvTstFJlNpKGhgw.get('code')=='CAIP1900':WfajURorOkbXnQBAvTstFJlNpKGhgu =WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhgw.get('url')
   WfajURorOkbXnQBAvTstFJlNpKGhMY['saveinfo']['thumbnail']['poster']=WfajURorOkbXnQBAvTstFJlNpKGhgL
   WfajURorOkbXnQBAvTstFJlNpKGhMY['saveinfo']['thumbnail']['thumb']=WfajURorOkbXnQBAvTstFJlNpKGhgq
   WfajURorOkbXnQBAvTstFJlNpKGhMY['saveinfo']['thumbnail']['clearlogo']=WfajURorOkbXnQBAvTstFJlNpKGhgI
   WfajURorOkbXnQBAvTstFJlNpKGhMY['saveinfo']['thumbnail']['icon']=WfajURorOkbXnQBAvTstFJlNpKGhgc
   WfajURorOkbXnQBAvTstFJlNpKGhMY['saveinfo']['thumbnail']['banner']=WfajURorOkbXnQBAvTstFJlNpKGhgu
   WfajURorOkbXnQBAvTstFJlNpKGhMY['saveinfo']['thumbnail']['fanart']=WfajURorOkbXnQBAvTstFJlNpKGhgq
  else:
   WfajURorOkbXnQBAvTstFJlNpKGhCH=WfajURorOkbXnQBAvTstFJlNpKGhdM.API_DOMAIN+'/v2a/media/stream/info'
   WfajURorOkbXnQBAvTstFJlNpKGhCE=WfajURorOkbXnQBAvTstFJlNpKGhdM.GetDefaultParams()
   WfajURorOkbXnQBAvTstFJlNpKGhCD={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':WfajURorOkbXnQBAvTstFJlNpKGhdM.TVING_UUID.split('-')[0],'uuid':WfajURorOkbXnQBAvTstFJlNpKGhdM.TVING_UUID,'deviceInfo':'PC_Chrome','noCache':WfajURorOkbXnQBAvTstFJlNpKGheY(WfajURorOkbXnQBAvTstFJlNpKGhdM.GetNoCache(1)),'wm':'Y',}
   WfajURorOkbXnQBAvTstFJlNpKGhCE.update(WfajURorOkbXnQBAvTstFJlNpKGhCD)
   WfajURorOkbXnQBAvTstFJlNpKGhdi=WfajURorOkbXnQBAvTstFJlNpKGhdM.callRequestCookies('Get',WfajURorOkbXnQBAvTstFJlNpKGhCH,payload=WfajURorOkbXnQBAvTstFJlNpKGheD,params=WfajURorOkbXnQBAvTstFJlNpKGhCE,headers=WfajURorOkbXnQBAvTstFJlNpKGheD,cookies=WfajURorOkbXnQBAvTstFJlNpKGheD)
   WfajURorOkbXnQBAvTstFJlNpKGhMw=json.loads(WfajURorOkbXnQBAvTstFJlNpKGhdi.text)
   if not('content' in WfajURorOkbXnQBAvTstFJlNpKGhMw['body']):return{}
   WfajURorOkbXnQBAvTstFJlNpKGhMi=WfajURorOkbXnQBAvTstFJlNpKGhMw['body']['content']['info']['movie']
   WfajURorOkbXnQBAvTstFJlNpKGhgD =WfajURorOkbXnQBAvTstFJlNpKGhMi.get('name').get('ko').strip()
   WfajURorOkbXnQBAvTstFJlNpKGhMY['saveinfo']['infoLabels']['title']=WfajURorOkbXnQBAvTstFJlNpKGhgD
   WfajURorOkbXnQBAvTstFJlNpKGhgD +=u' (%s)'%(WfajURorOkbXnQBAvTstFJlNpKGhMi.get('product_year'))
   WfajURorOkbXnQBAvTstFJlNpKGhMY['saveinfo']['title'] =WfajURorOkbXnQBAvTstFJlNpKGhgD
   WfajURorOkbXnQBAvTstFJlNpKGhMY['saveinfo']['infoLabels']['mpaa'] =WfajURorOkbXnQBAvTstFJlNpKGhdV.get(WfajURorOkbXnQBAvTstFJlNpKGhMi.get('grade_code'))
   WfajURorOkbXnQBAvTstFJlNpKGhMY['saveinfo']['infoLabels']['plot'] =WfajURorOkbXnQBAvTstFJlNpKGhMi.get('story').get('ko')
   WfajURorOkbXnQBAvTstFJlNpKGhMY['saveinfo']['infoLabels']['year'] =WfajURorOkbXnQBAvTstFJlNpKGhMi.get('product_year')
   WfajURorOkbXnQBAvTstFJlNpKGhMY['saveinfo']['infoLabels']['studio'] =WfajURorOkbXnQBAvTstFJlNpKGhMi.get('production')
   WfajURorOkbXnQBAvTstFJlNpKGhMY['saveinfo']['infoLabels']['duration']=WfajURorOkbXnQBAvTstFJlNpKGhMi.get('duration')
   WfajURorOkbXnQBAvTstFJlNpKGhMY['saveinfo']['infoLabels']['cast'] =WfajURorOkbXnQBAvTstFJlNpKGhMi.get('actor')
   WfajURorOkbXnQBAvTstFJlNpKGhMY['saveinfo']['infoLabels']['director']=WfajURorOkbXnQBAvTstFJlNpKGhMi.get('director')
   if WfajURorOkbXnQBAvTstFJlNpKGhMi.get('category1_name').get('ko')!='':
    WfajURorOkbXnQBAvTstFJlNpKGhMY['saveinfo']['infoLabels']['genre'].append(WfajURorOkbXnQBAvTstFJlNpKGhMi.get('category1_name').get('ko'))
   if WfajURorOkbXnQBAvTstFJlNpKGhMi.get('category2_name').get('ko')!='':
    WfajURorOkbXnQBAvTstFJlNpKGhMY['saveinfo']['infoLabels']['genre'].append(WfajURorOkbXnQBAvTstFJlNpKGhMi.get('category2_name').get('ko'))
   WfajURorOkbXnQBAvTstFJlNpKGhVS=WfajURorOkbXnQBAvTstFJlNpKGheY(WfajURorOkbXnQBAvTstFJlNpKGhMi.get('release_date'))
   if WfajURorOkbXnQBAvTstFJlNpKGhVS!='0':WfajURorOkbXnQBAvTstFJlNpKGhMY['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(WfajURorOkbXnQBAvTstFJlNpKGhVS[:4],WfajURorOkbXnQBAvTstFJlNpKGhVS[4:6],WfajURorOkbXnQBAvTstFJlNpKGhVS[6:])
   WfajURorOkbXnQBAvTstFJlNpKGhgL=''
   WfajURorOkbXnQBAvTstFJlNpKGhgq =''
   WfajURorOkbXnQBAvTstFJlNpKGhgI=''
   for WfajURorOkbXnQBAvTstFJlNpKGhgw in WfajURorOkbXnQBAvTstFJlNpKGhMi.get('image'):
    if WfajURorOkbXnQBAvTstFJlNpKGhgw.get('code')=='CAIM2100':WfajURorOkbXnQBAvTstFJlNpKGhgL =WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhgw.get('url')
    elif WfajURorOkbXnQBAvTstFJlNpKGhgw.get('code')=='CAIM0400':WfajURorOkbXnQBAvTstFJlNpKGhgq =WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhgw.get('url')
    elif WfajURorOkbXnQBAvTstFJlNpKGhgw.get('code')=='CAIM1800':WfajURorOkbXnQBAvTstFJlNpKGhgI=WfajURorOkbXnQBAvTstFJlNpKGhdM.IMG_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhgw.get('url')
   WfajURorOkbXnQBAvTstFJlNpKGhMY['saveinfo']['thumbnail']['poster']=WfajURorOkbXnQBAvTstFJlNpKGhgL
   WfajURorOkbXnQBAvTstFJlNpKGhMY['saveinfo']['thumbnail']['thumb']=WfajURorOkbXnQBAvTstFJlNpKGhgL 
   WfajURorOkbXnQBAvTstFJlNpKGhMY['saveinfo']['thumbnail']['clearlogo']=WfajURorOkbXnQBAvTstFJlNpKGhgI
   WfajURorOkbXnQBAvTstFJlNpKGhMY['saveinfo']['thumbnail']['fanart']=WfajURorOkbXnQBAvTstFJlNpKGhgq
  return WfajURorOkbXnQBAvTstFJlNpKGhMY
 def GetEuroChannelList(WfajURorOkbXnQBAvTstFJlNpKGhdM):
  WfajURorOkbXnQBAvTstFJlNpKGhge=[]
  try:
   WfajURorOkbXnQBAvTstFJlNpKGhCz ='/v2/operator/highlights'
   WfajURorOkbXnQBAvTstFJlNpKGhCE=WfajURorOkbXnQBAvTstFJlNpKGhdM.GetDefaultParams()
   WfajURorOkbXnQBAvTstFJlNpKGhCD={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':WfajURorOkbXnQBAvTstFJlNpKGheY(WfajURorOkbXnQBAvTstFJlNpKGhdM.GetNoCache(2))}
   WfajURorOkbXnQBAvTstFJlNpKGhCE.update(WfajURorOkbXnQBAvTstFJlNpKGhCD)
   WfajURorOkbXnQBAvTstFJlNpKGhCH=WfajURorOkbXnQBAvTstFJlNpKGhdM.API_DOMAIN+WfajURorOkbXnQBAvTstFJlNpKGhCz
   WfajURorOkbXnQBAvTstFJlNpKGhdi=WfajURorOkbXnQBAvTstFJlNpKGhdM.callRequestCookies('Get',WfajURorOkbXnQBAvTstFJlNpKGhCH,payload=WfajURorOkbXnQBAvTstFJlNpKGheD,params=WfajURorOkbXnQBAvTstFJlNpKGhCE,headers=WfajURorOkbXnQBAvTstFJlNpKGheD,cookies=WfajURorOkbXnQBAvTstFJlNpKGheD)
   WfajURorOkbXnQBAvTstFJlNpKGhCq=json.loads(WfajURorOkbXnQBAvTstFJlNpKGhdi.text)
   if not('result' in WfajURorOkbXnQBAvTstFJlNpKGhCq['body']):return WfajURorOkbXnQBAvTstFJlNpKGhge,WfajURorOkbXnQBAvTstFJlNpKGhgP
   WfajURorOkbXnQBAvTstFJlNpKGhgm=WfajURorOkbXnQBAvTstFJlNpKGhCq['body']['result']
   WfajURorOkbXnQBAvTstFJlNpKGhMy =WfajURorOkbXnQBAvTstFJlNpKGhdM.Get_Now_Datetime()
   WfajURorOkbXnQBAvTstFJlNpKGhed=WfajURorOkbXnQBAvTstFJlNpKGhMy+datetime.timedelta(days=-1)
   WfajURorOkbXnQBAvTstFJlNpKGhed=WfajURorOkbXnQBAvTstFJlNpKGheq(WfajURorOkbXnQBAvTstFJlNpKGhed.strftime('%Y%m%d'))
   for WfajURorOkbXnQBAvTstFJlNpKGhCu in WfajURorOkbXnQBAvTstFJlNpKGhgm:
    WfajURorOkbXnQBAvTstFJlNpKGheC=WfajURorOkbXnQBAvTstFJlNpKGheq(WfajURorOkbXnQBAvTstFJlNpKGhCu.get('content').get('banner_title2')[:8])
    if WfajURorOkbXnQBAvTstFJlNpKGhed<=WfajURorOkbXnQBAvTstFJlNpKGheC:
     WfajURorOkbXnQBAvTstFJlNpKGhVx={'channel':WfajURorOkbXnQBAvTstFJlNpKGhCu.get('content').get('banner_sub_title3'),'title':WfajURorOkbXnQBAvTstFJlNpKGhCu.get('content').get('banner_title'),'subtitle':WfajURorOkbXnQBAvTstFJlNpKGhCu.get('content').get('banner_sub_title2'),}
     WfajURorOkbXnQBAvTstFJlNpKGhge.append(WfajURorOkbXnQBAvTstFJlNpKGhVx)
  except WfajURorOkbXnQBAvTstFJlNpKGheu as exception:
   WfajURorOkbXnQBAvTstFJlNpKGhec(exception)
  return WfajURorOkbXnQBAvTstFJlNpKGhge
 def Make_DecryptKey(WfajURorOkbXnQBAvTstFJlNpKGhdM,step,mediacode='000',timecode='000'):
  if step=='1':
   WfajURorOkbXnQBAvTstFJlNpKGheg=WfajURorOkbXnQBAvTstFJlNpKGhey('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   WfajURorOkbXnQBAvTstFJlNpKGheV=WfajURorOkbXnQBAvTstFJlNpKGhey('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   WfajURorOkbXnQBAvTstFJlNpKGheg=WfajURorOkbXnQBAvTstFJlNpKGhey('kss2lym0kdw1lks3','utf-8')
   WfajURorOkbXnQBAvTstFJlNpKGheV=WfajURorOkbXnQBAvTstFJlNpKGhey([WfajURorOkbXnQBAvTstFJlNpKGhPd('*'),0x07,WfajURorOkbXnQBAvTstFJlNpKGhPd('r'),WfajURorOkbXnQBAvTstFJlNpKGhPd(';'),WfajURorOkbXnQBAvTstFJlNpKGhPd('7'),0x05,0x1e,0x01,WfajURorOkbXnQBAvTstFJlNpKGhPd('n'),WfajURorOkbXnQBAvTstFJlNpKGhPd('D'),0x02,WfajURorOkbXnQBAvTstFJlNpKGhPd('3'),WfajURorOkbXnQBAvTstFJlNpKGhPd('*'),WfajURorOkbXnQBAvTstFJlNpKGhPd('a'),WfajURorOkbXnQBAvTstFJlNpKGhPd('&'),WfajURorOkbXnQBAvTstFJlNpKGhPd('<')])
  return WfajURorOkbXnQBAvTstFJlNpKGheg,WfajURorOkbXnQBAvTstFJlNpKGheV
 def DecryptPlaintext(WfajURorOkbXnQBAvTstFJlNpKGhdM,ciphertext,encryption_key,init_vector):
  WfajURorOkbXnQBAvTstFJlNpKGheM=AES.new(encryption_key,AES.MODE_CBC,init_vector,)
  WfajURorOkbXnQBAvTstFJlNpKGheP=Padding.unpad(WfajURorOkbXnQBAvTstFJlNpKGheM.decrypt(base64.standard_b64decode(ciphertext)),16)
  return WfajURorOkbXnQBAvTstFJlNpKGheP.decode('utf-8')
 def Decrypt_Url(WfajURorOkbXnQBAvTstFJlNpKGhdM,ciphertext,mediacode,WfajURorOkbXnQBAvTstFJlNpKGhCi):
  WfajURorOkbXnQBAvTstFJlNpKGheS=''
  try:
   WfajURorOkbXnQBAvTstFJlNpKGheg,WfajURorOkbXnQBAvTstFJlNpKGheV=WfajURorOkbXnQBAvTstFJlNpKGhdM.Make_DecryptKey('1',mediacode=mediacode,timecode=WfajURorOkbXnQBAvTstFJlNpKGhCi)
   WfajURorOkbXnQBAvTstFJlNpKGhem=json.loads(WfajURorOkbXnQBAvTstFJlNpKGhdM.DecryptPlaintext(ciphertext,WfajURorOkbXnQBAvTstFJlNpKGheg,WfajURorOkbXnQBAvTstFJlNpKGheV))
   WfajURorOkbXnQBAvTstFJlNpKGhex =WfajURorOkbXnQBAvTstFJlNpKGhem.get('broad_url')
   WfajURorOkbXnQBAvTstFJlNpKGhCy =WfajURorOkbXnQBAvTstFJlNpKGhem.get('watermark') if 'watermark' in WfajURorOkbXnQBAvTstFJlNpKGhem else ''
   WfajURorOkbXnQBAvTstFJlNpKGhgd=WfajURorOkbXnQBAvTstFJlNpKGhem.get('watermarkKey')if 'watermarkKey' in WfajURorOkbXnQBAvTstFJlNpKGhem else ''
   WfajURorOkbXnQBAvTstFJlNpKGheg,WfajURorOkbXnQBAvTstFJlNpKGheV=WfajURorOkbXnQBAvTstFJlNpKGhdM.Make_DecryptKey('2',mediacode=mediacode,timecode=WfajURorOkbXnQBAvTstFJlNpKGhCi)
   WfajURorOkbXnQBAvTstFJlNpKGheS=WfajURorOkbXnQBAvTstFJlNpKGhdM.DecryptPlaintext(WfajURorOkbXnQBAvTstFJlNpKGhex,WfajURorOkbXnQBAvTstFJlNpKGheg,WfajURorOkbXnQBAvTstFJlNpKGheV)
  except WfajURorOkbXnQBAvTstFJlNpKGheu as exception:
   WfajURorOkbXnQBAvTstFJlNpKGhec(exception)
  return WfajURorOkbXnQBAvTstFJlNpKGheS,WfajURorOkbXnQBAvTstFJlNpKGhCy,WfajURorOkbXnQBAvTstFJlNpKGhgd
# Created by pyminifier (https://github.com/liftoff/pyminifier)
