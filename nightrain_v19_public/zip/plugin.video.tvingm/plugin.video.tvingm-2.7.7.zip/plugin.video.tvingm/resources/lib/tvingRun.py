__author__="NightRain"
FbEVcUzgwsBvqpXGkrHyPJWijSACLe=object
FbEVcUzgwsBvqpXGkrHyPJWijSACLN=None
FbEVcUzgwsBvqpXGkrHyPJWijSACLt=int
FbEVcUzgwsBvqpXGkrHyPJWijSACLI=False
FbEVcUzgwsBvqpXGkrHyPJWijSACLY=True
FbEVcUzgwsBvqpXGkrHyPJWijSACLD=type
FbEVcUzgwsBvqpXGkrHyPJWijSACLa=dict
FbEVcUzgwsBvqpXGkrHyPJWijSACLQ=getattr
FbEVcUzgwsBvqpXGkrHyPJWijSACLM=list
FbEVcUzgwsBvqpXGkrHyPJWijSACLh=len
FbEVcUzgwsBvqpXGkrHyPJWijSACLx=str
FbEVcUzgwsBvqpXGkrHyPJWijSACLl=range
FbEVcUzgwsBvqpXGkrHyPJWijSACLo=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
FbEVcUzgwsBvqpXGkrHyPJWijSACet=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'실시간 인기 드라마','mode':'BAND_VODLIST','bandKey':'HM218820','bandGroup':''},{'title':'실시간 인기 예능','mode':'BAND_VODLIST','bandKey':'HM156521','bandGroup':''},{'title':'Apple TV+ 실시간 인기','mode':'BAND_VODLIST','bandKey':'-','bandGroup':'TVING_APPLE_HOUR'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'드라마 - 인기순','mode':'DRAMA_GROUP','stype':'drama','orderby':'hit','ordernm':'인기'},{'title':'드라마 - 업데이트','mode':'DRAMA_GROUP','stype':'drama','orderby':'update','ordernm':'업데이트'},{'title':'예능   - 인기순','mode':'ENTER_GROUP','stype':'enter','orderby':'hit','ordernm':'인기'},{'title':'예능   - 업데이트','mode':'ENTER_GROUP','stype':'enter','orderby':'update','ordernm':'업데이트'},{'title':'영화 - 인기순','mode':'MOVIE_GROUP','stype':'movie','orderby':'hit','ordernm':'인기'},{'title':'영화 - 업데이트','mode':'MOVIE_GROUP','stype':'movie','orderby':'update','ordernm':'업데이트'},{'title':'Apple TV+','mode':'APPLE_GROUP','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'},]
FbEVcUzgwsBvqpXGkrHyPJWijSACeI=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
FbEVcUzgwsBvqpXGkrHyPJWijSACeY=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
FbEVcUzgwsBvqpXGkrHyPJWijSACeD=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
FbEVcUzgwsBvqpXGkrHyPJWijSACea=[{'title':'전체','mode':'GN2_LIST','genre':'PCA','stype':'tvshow'},{'title':'로맨스','mode':'GN2_LIST','genre':'PCA007','stype':'tvshow'},{'title':'코미디','mode':'GN2_LIST','genre':'PCA020','stype':'tvshow'},{'title':'판타지','mode':'GN2_LIST','genre':'PCA023','stype':'tvshow'},{'title':'무협','mode':'GN2_LIST','genre':'PCAB','stype':'tvshow'},{'title':'공포','mode':'GN2_LIST','genre':'PCAD','stype':'tvshow'},{'title':'복수','mode':'GN2_LIST','genre':'PCA030','stype':'tvshow'},{'title':'휴먼','mode':'GN2_LIST','genre':'PCA024','stype':'tvshow'},{'title':'범죄 스릴러','mode':'GN2_LIST','genre':'PCA015','stype':'tvshow'},{'title':'의학','mode':'GN2_LIST','genre':'PCA025','stype':'tvshow'},{'title':'웹튠/소설 원작','mode':'GN2_LIST','genre':'PCA028','stype':'tvshow'},{'title':'정치/권력','mode':'GN2_LIST','genre':'PCA034','stype':'tvshow'},{'title':'법정','mode':'GN2_LIST','genre':'PCA036','stype':'tvshow'},{'title':'청춘(성장)','mode':'GN2_LIST','genre':'PCA029','stype':'tvshow'},{'title':'오피스 드라마','mode':'GN2_LIST','genre':'PCA040','stype':'tvshow'},{'title':'사극/시대극','mode':'GN2_LIST','genre':'PCA017','stype':'tvshow'},{'title':'타임슬립','mode':'GN2_LIST','genre':'PCA026','stype':'tvshow'},{'title':'단막극','mode':'GN2_LIST','genre':'PCA038','stype':'tvshow'},{'title':'해외드라마','mode':'GN2_LIST','genre':'PCPOS','stype':'tvshow'},{'title':'미국드라마','mode':'GN2_LIST','genre':'POS007','stype':'tvshow'},{'title':'영국드라마','mode':'GN2_LIST','genre':'POS008','stype':'tvshow'},{'title':'중국드라마','mode':'GN2_LIST','genre':'POS005','stype':'tvshow'},{'title':'일본드라마','mode':'GN2_LIST','genre':'POS006','stype':'tvshow'}]
FbEVcUzgwsBvqpXGkrHyPJWijSACeQ=[{'title':'버라이어티','mode':'GN2_LIST','genre':'PCD005','stype':'tvshow'},{'title':'다큐멘터리','mode':'GN2_LIST','genre':'PCT','stype':'tvshow'},{'title':'여행','mode':'GN2_LIST','genre':'PCD003','stype':'tvshow'},{'title':'쿡방/먹방','mode':'GN2_LIST','genre':'PCD023','stype':'tvshow'},{'title':'연애 리얼리티','mode':'GN2_LIST','genre':'PCAB','stype':'PCD010'},{'title':'나영석 예능','mode':'GN2_LIST','genre':'PCD032','stype':'tvshow'},{'title':'게임/퀴즈쇼','mode':'GN2_LIST','genre':'PCD029','stype':'tvshow'},{'title':'토크쇼','mode':'GN2_LIST','genre':'PCD011','stype':'tvshow'},{'title':'서바이벌','mode':'GN2_LIST','genre':'PCD025','stype':'tvshow'},{'title':'관찰리얼리티','mode':'GN2_LIST','genre':'PCD024','stype':'tvshow'},{'title':'스포츠','mode':'GN2_LIST','genre':'PCD037','stype':'tvshow'},{'title':'교육&독서','mode':'GN2_LIST','genre':'PCD038','stype':'tvshow'},{'title':'힐링 예능','mode':'GN2_LIST','genre':'PCD034','stype':'tvshow'},{'title':'아이돌','mode':'GN2_LIST','genre':'PCD01','stype':'tvshow'},{'title':'음악 서바이벌','mode':'GN2_LIST','genre':'PCD027','stype':'tvshow'},{'title':'음악예능','mode':'GN2_LIST','genre':'PCD021','stype':'tvshow'},{'title':'코미디','mode':'GN2_LIST','genre':'PCD017','stype':'tvshow'},{'title':'가족예능','mode':'GN2_LIST','genre':'PCD035','stype':'tvshow'},{'title':'뷰티/스타일','mode':'GN2_LIST','genre':'PCD022','stype':'tvshow'},{'title':'펫/애니멀','mode':'GN2_LIST','genre':'PCD026','stype':'tvshow'},{'title':'콘서트/시상식','mode':'GN2_LIST','genre':'PCD009','stype':'tvshow'},{'title':'예능 스페셜','mode':'GN2_LIST','genre':'PCD042','stype':'tvshow'}]
FbEVcUzgwsBvqpXGkrHyPJWijSACeL=[{'title':'드라마','mode':'GN2_LIST','genre':'MG100','stype':'movie'},{'title':'로맨스','mode':'GN2_LIST','genre':'MG130','stype':'movie'},{'title':'코미디','mode':'GN2_LIST','genre':'MG110','stype':'movie'},{'title':'애니메이션','mode':'GN2_LIST','genre':'MG240','stype':'movie'},{'title':'스릴러','mode':'GN2_LIST','genre':'MG140','stype':'movie'},{'title':'미스터리','mode':'GN2_LIST','genre':'MG150','stype':'movie'},{'title':'모험','mode':'GN2_LIST','genre':'MG170','stype':'movie'},{'title':'액션','mode':'GN2_LIST','genre':'MG120','stype':'movie'},{'title':'판타지','mode':'GN2_LIST','genre':'MG200','stype':'movie'},{'title':'SF','mode':'GN2_LIST','genre':'MG210','stype':'movie'},{'title':'공포','mode':'GN2_LIST','genre':'MG160','stype':'movie'},{'title':'다큐멘터리','mode':'GN2_LIST','genre':'MG250','stype':'movie'}]
FbEVcUzgwsBvqpXGkrHyPJWijSACeM={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
from tvingCore import*
class FbEVcUzgwsBvqpXGkrHyPJWijSACeN(FbEVcUzgwsBvqpXGkrHyPJWijSACLe):
 def __init__(FbEVcUzgwsBvqpXGkrHyPJWijSACeh,FbEVcUzgwsBvqpXGkrHyPJWijSACex,FbEVcUzgwsBvqpXGkrHyPJWijSACel,FbEVcUzgwsBvqpXGkrHyPJWijSACeo):
  FbEVcUzgwsBvqpXGkrHyPJWijSACeh._addon_url =FbEVcUzgwsBvqpXGkrHyPJWijSACex
  FbEVcUzgwsBvqpXGkrHyPJWijSACeh._addon_handle=FbEVcUzgwsBvqpXGkrHyPJWijSACel
  FbEVcUzgwsBvqpXGkrHyPJWijSACeh.main_params =FbEVcUzgwsBvqpXGkrHyPJWijSACeo
  FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj =qCjrweBzoROcYWnDLIvNpTtJlgGhMs() 
  FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.TV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_stream(mpd,m3u8)'))
  FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.TV_COOKIE_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
  FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.TV_TOKEN_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_token.json'))
  FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.SEARCHED_FILE_NAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
 def addon_noti(FbEVcUzgwsBvqpXGkrHyPJWijSACeh,sting):
  try:
   FbEVcUzgwsBvqpXGkrHyPJWijSACeu=xbmcgui.Dialog()
   FbEVcUzgwsBvqpXGkrHyPJWijSACeu.notification(__addonname__,sting)
  except:
   FbEVcUzgwsBvqpXGkrHyPJWijSACLN
 def addon_log(FbEVcUzgwsBvqpXGkrHyPJWijSACeh,string):
  try:
   FbEVcUzgwsBvqpXGkrHyPJWijSACeK=string.encode('utf-8','ignore')
  except:
   FbEVcUzgwsBvqpXGkrHyPJWijSACeK='addonException: addon_log'
  FbEVcUzgwsBvqpXGkrHyPJWijSACem=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,FbEVcUzgwsBvqpXGkrHyPJWijSACeK),level=FbEVcUzgwsBvqpXGkrHyPJWijSACem)
 def get_keyboard_input(FbEVcUzgwsBvqpXGkrHyPJWijSACeh,FbEVcUzgwsBvqpXGkrHyPJWijSACNo):
  FbEVcUzgwsBvqpXGkrHyPJWijSACed=FbEVcUzgwsBvqpXGkrHyPJWijSACLN
  kb=xbmc.Keyboard()
  kb.setHeading(FbEVcUzgwsBvqpXGkrHyPJWijSACNo)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   FbEVcUzgwsBvqpXGkrHyPJWijSACed=kb.getText()
  return FbEVcUzgwsBvqpXGkrHyPJWijSACed
 def get_settings_account(FbEVcUzgwsBvqpXGkrHyPJWijSACeh):
  FbEVcUzgwsBvqpXGkrHyPJWijSACeO =__addon__.getSetting('id')
  FbEVcUzgwsBvqpXGkrHyPJWijSACen =__addon__.getSetting('pw')
  FbEVcUzgwsBvqpXGkrHyPJWijSACeT =__addon__.getSetting('login_type')
  FbEVcUzgwsBvqpXGkrHyPJWijSACef=FbEVcUzgwsBvqpXGkrHyPJWijSACLt(__addon__.getSetting('selected_profile'))
  return(FbEVcUzgwsBvqpXGkrHyPJWijSACeO,FbEVcUzgwsBvqpXGkrHyPJWijSACen,FbEVcUzgwsBvqpXGkrHyPJWijSACeT,FbEVcUzgwsBvqpXGkrHyPJWijSACef)
 def get_settings_uhd(FbEVcUzgwsBvqpXGkrHyPJWijSACeh):
  return FbEVcUzgwsBvqpXGkrHyPJWijSACLI
 def get_settings_playback(FbEVcUzgwsBvqpXGkrHyPJWijSACeh):
  FbEVcUzgwsBvqpXGkrHyPJWijSACNe={'active_uhd':FbEVcUzgwsBvqpXGkrHyPJWijSACLY if __addon__.getSetting('active_uhd')=='true' else FbEVcUzgwsBvqpXGkrHyPJWijSACLI,'streamFilename':FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.TV_STREAM_FILENAME,}
  return FbEVcUzgwsBvqpXGkrHyPJWijSACNe
 def get_settings_proxyport(FbEVcUzgwsBvqpXGkrHyPJWijSACeh):
  FbEVcUzgwsBvqpXGkrHyPJWijSACNt =FbEVcUzgwsBvqpXGkrHyPJWijSACLY if __addon__.getSetting('proxyYn')=='true' else FbEVcUzgwsBvqpXGkrHyPJWijSACLI
  FbEVcUzgwsBvqpXGkrHyPJWijSACNI=FbEVcUzgwsBvqpXGkrHyPJWijSACLt(__addon__.getSetting('proxyPort'))
  return FbEVcUzgwsBvqpXGkrHyPJWijSACNt,FbEVcUzgwsBvqpXGkrHyPJWijSACNI
 def get_settings_totalsearch(FbEVcUzgwsBvqpXGkrHyPJWijSACeh):
  FbEVcUzgwsBvqpXGkrHyPJWijSACNY =FbEVcUzgwsBvqpXGkrHyPJWijSACLY if __addon__.getSetting('local_search')=='true' else FbEVcUzgwsBvqpXGkrHyPJWijSACLI
  FbEVcUzgwsBvqpXGkrHyPJWijSACND=FbEVcUzgwsBvqpXGkrHyPJWijSACLY if __addon__.getSetting('local_history')=='true' else FbEVcUzgwsBvqpXGkrHyPJWijSACLI
  FbEVcUzgwsBvqpXGkrHyPJWijSACNa =FbEVcUzgwsBvqpXGkrHyPJWijSACLY if __addon__.getSetting('total_search')=='true' else FbEVcUzgwsBvqpXGkrHyPJWijSACLI
  FbEVcUzgwsBvqpXGkrHyPJWijSACNQ=FbEVcUzgwsBvqpXGkrHyPJWijSACLY if __addon__.getSetting('total_history')=='true' else FbEVcUzgwsBvqpXGkrHyPJWijSACLI
  FbEVcUzgwsBvqpXGkrHyPJWijSACNL=FbEVcUzgwsBvqpXGkrHyPJWijSACLY if __addon__.getSetting('menu_bookmark')=='true' else FbEVcUzgwsBvqpXGkrHyPJWijSACLI
  return(FbEVcUzgwsBvqpXGkrHyPJWijSACNY,FbEVcUzgwsBvqpXGkrHyPJWijSACND,FbEVcUzgwsBvqpXGkrHyPJWijSACNa,FbEVcUzgwsBvqpXGkrHyPJWijSACNQ,FbEVcUzgwsBvqpXGkrHyPJWijSACNL)
 def get_settings_makebookmark(FbEVcUzgwsBvqpXGkrHyPJWijSACeh):
  return FbEVcUzgwsBvqpXGkrHyPJWijSACLY if __addon__.getSetting('make_bookmark')=='true' else FbEVcUzgwsBvqpXGkrHyPJWijSACLI
 def get_settings_direct_replay(FbEVcUzgwsBvqpXGkrHyPJWijSACeh):
  FbEVcUzgwsBvqpXGkrHyPJWijSACNM=FbEVcUzgwsBvqpXGkrHyPJWijSACLt(__addon__.getSetting('direct_replay'))
  if FbEVcUzgwsBvqpXGkrHyPJWijSACNM==0:
   return FbEVcUzgwsBvqpXGkrHyPJWijSACLI
  else:
   return FbEVcUzgwsBvqpXGkrHyPJWijSACLY
 def set_winEpisodeOrderby(FbEVcUzgwsBvqpXGkrHyPJWijSACeh,FbEVcUzgwsBvqpXGkrHyPJWijSACNx):
  __addon__.setSetting('tving_orderby',FbEVcUzgwsBvqpXGkrHyPJWijSACNx)
  FbEVcUzgwsBvqpXGkrHyPJWijSACNh=xbmcgui.Window(10000)
  FbEVcUzgwsBvqpXGkrHyPJWijSACNh.setProperty('TVING_M_ORDERBY',FbEVcUzgwsBvqpXGkrHyPJWijSACNx)
 def get_winEpisodeOrderby(FbEVcUzgwsBvqpXGkrHyPJWijSACeh):
  FbEVcUzgwsBvqpXGkrHyPJWijSACNx=__addon__.getSetting('tving_orderby')
  if FbEVcUzgwsBvqpXGkrHyPJWijSACNx in['',FbEVcUzgwsBvqpXGkrHyPJWijSACLN]:FbEVcUzgwsBvqpXGkrHyPJWijSACNx='desc'
  return FbEVcUzgwsBvqpXGkrHyPJWijSACNx
 def add_dir(FbEVcUzgwsBvqpXGkrHyPJWijSACeh,label,sublabel='',img='',infoLabels=FbEVcUzgwsBvqpXGkrHyPJWijSACLN,isFolder=FbEVcUzgwsBvqpXGkrHyPJWijSACLY,params='',isLink=FbEVcUzgwsBvqpXGkrHyPJWijSACLI,ContextMenu=FbEVcUzgwsBvqpXGkrHyPJWijSACLN):
  FbEVcUzgwsBvqpXGkrHyPJWijSACNl='%s?%s'%(FbEVcUzgwsBvqpXGkrHyPJWijSACeh._addon_url,urllib.parse.urlencode(params))
  if sublabel:FbEVcUzgwsBvqpXGkrHyPJWijSACNo='%s < %s >'%(label,sublabel)
  else: FbEVcUzgwsBvqpXGkrHyPJWijSACNo=label
  if not img:img='DefaultFolder.png'
  FbEVcUzgwsBvqpXGkrHyPJWijSACNR=xbmcgui.ListItem(FbEVcUzgwsBvqpXGkrHyPJWijSACNo)
  if FbEVcUzgwsBvqpXGkrHyPJWijSACLD(img)==FbEVcUzgwsBvqpXGkrHyPJWijSACLa:
   FbEVcUzgwsBvqpXGkrHyPJWijSACNR.setArt(img)
  else:
   FbEVcUzgwsBvqpXGkrHyPJWijSACNR.setArt({'thumb':img,'poster':img})
  if FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.KodiVersion>=20:
   if infoLabels:FbEVcUzgwsBvqpXGkrHyPJWijSACeh.Set_InfoTag(FbEVcUzgwsBvqpXGkrHyPJWijSACNR.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:FbEVcUzgwsBvqpXGkrHyPJWijSACNR.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   FbEVcUzgwsBvqpXGkrHyPJWijSACNR.setProperty('IsPlayable','true')
  if ContextMenu:FbEVcUzgwsBvqpXGkrHyPJWijSACNR.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(FbEVcUzgwsBvqpXGkrHyPJWijSACeh._addon_handle,FbEVcUzgwsBvqpXGkrHyPJWijSACNl,FbEVcUzgwsBvqpXGkrHyPJWijSACNR,isFolder)
 def get_selQuality(FbEVcUzgwsBvqpXGkrHyPJWijSACeh,etype):
  try:
   FbEVcUzgwsBvqpXGkrHyPJWijSACNu='selected_quality'
   FbEVcUzgwsBvqpXGkrHyPJWijSACNK=[1080,720,480,360]
   FbEVcUzgwsBvqpXGkrHyPJWijSACNm=FbEVcUzgwsBvqpXGkrHyPJWijSACLt(__addon__.getSetting(FbEVcUzgwsBvqpXGkrHyPJWijSACNu))
   return FbEVcUzgwsBvqpXGkrHyPJWijSACNK[FbEVcUzgwsBvqpXGkrHyPJWijSACNm]
  except:
   FbEVcUzgwsBvqpXGkrHyPJWijSACLN
  return 720 
 def Set_InfoTag(FbEVcUzgwsBvqpXGkrHyPJWijSACeh,video_InfoTag:xbmc.InfoTagVideo,FbEVcUzgwsBvqpXGkrHyPJWijSACtI):
  for FbEVcUzgwsBvqpXGkrHyPJWijSACNd,value in FbEVcUzgwsBvqpXGkrHyPJWijSACtI.items():
   if FbEVcUzgwsBvqpXGkrHyPJWijSACeM[FbEVcUzgwsBvqpXGkrHyPJWijSACNd]['type']=='string':
    FbEVcUzgwsBvqpXGkrHyPJWijSACLQ(video_InfoTag,FbEVcUzgwsBvqpXGkrHyPJWijSACeM[FbEVcUzgwsBvqpXGkrHyPJWijSACNd]['func'])(value)
   elif FbEVcUzgwsBvqpXGkrHyPJWijSACeM[FbEVcUzgwsBvqpXGkrHyPJWijSACNd]['type']=='int':
    if FbEVcUzgwsBvqpXGkrHyPJWijSACLD(value)==FbEVcUzgwsBvqpXGkrHyPJWijSACLt:
     FbEVcUzgwsBvqpXGkrHyPJWijSACNO=FbEVcUzgwsBvqpXGkrHyPJWijSACLt(value)
    else:
     FbEVcUzgwsBvqpXGkrHyPJWijSACNO=0
    FbEVcUzgwsBvqpXGkrHyPJWijSACLQ(video_InfoTag,FbEVcUzgwsBvqpXGkrHyPJWijSACeM[FbEVcUzgwsBvqpXGkrHyPJWijSACNd]['func'])(FbEVcUzgwsBvqpXGkrHyPJWijSACNO)
   elif FbEVcUzgwsBvqpXGkrHyPJWijSACeM[FbEVcUzgwsBvqpXGkrHyPJWijSACNd]['type']=='actor':
    if value!=[]:
     FbEVcUzgwsBvqpXGkrHyPJWijSACLQ(video_InfoTag,FbEVcUzgwsBvqpXGkrHyPJWijSACeM[FbEVcUzgwsBvqpXGkrHyPJWijSACNd]['func'])([xbmc.Actor(name)for name in value])
   elif FbEVcUzgwsBvqpXGkrHyPJWijSACeM[FbEVcUzgwsBvqpXGkrHyPJWijSACNd]['type']=='list':
    if FbEVcUzgwsBvqpXGkrHyPJWijSACLD(value)==FbEVcUzgwsBvqpXGkrHyPJWijSACLM:
     FbEVcUzgwsBvqpXGkrHyPJWijSACLQ(video_InfoTag,FbEVcUzgwsBvqpXGkrHyPJWijSACeM[FbEVcUzgwsBvqpXGkrHyPJWijSACNd]['func'])(value)
    else:
     FbEVcUzgwsBvqpXGkrHyPJWijSACLQ(video_InfoTag,FbEVcUzgwsBvqpXGkrHyPJWijSACeM[FbEVcUzgwsBvqpXGkrHyPJWijSACNd]['func'])([value])
 def dp_Main_List(FbEVcUzgwsBvqpXGkrHyPJWijSACeh):
  (FbEVcUzgwsBvqpXGkrHyPJWijSACNY,FbEVcUzgwsBvqpXGkrHyPJWijSACND,FbEVcUzgwsBvqpXGkrHyPJWijSACNa,FbEVcUzgwsBvqpXGkrHyPJWijSACNQ,FbEVcUzgwsBvqpXGkrHyPJWijSACNL)=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.get_settings_totalsearch()
  for FbEVcUzgwsBvqpXGkrHyPJWijSACNn in FbEVcUzgwsBvqpXGkrHyPJWijSACet:
   FbEVcUzgwsBvqpXGkrHyPJWijSACNo=FbEVcUzgwsBvqpXGkrHyPJWijSACNn.get('title')
   FbEVcUzgwsBvqpXGkrHyPJWijSACNT=''
   if FbEVcUzgwsBvqpXGkrHyPJWijSACNn.get('mode')=='SEARCH_GROUP' and FbEVcUzgwsBvqpXGkrHyPJWijSACNY ==FbEVcUzgwsBvqpXGkrHyPJWijSACLI:continue
   elif FbEVcUzgwsBvqpXGkrHyPJWijSACNn.get('mode')=='SEARCH_HISTORY' and FbEVcUzgwsBvqpXGkrHyPJWijSACND==FbEVcUzgwsBvqpXGkrHyPJWijSACLI:continue
   elif FbEVcUzgwsBvqpXGkrHyPJWijSACNn.get('mode')=='TOTAL_SEARCH' and FbEVcUzgwsBvqpXGkrHyPJWijSACNa ==FbEVcUzgwsBvqpXGkrHyPJWijSACLI:continue
   elif FbEVcUzgwsBvqpXGkrHyPJWijSACNn.get('mode')=='TOTAL_HISTORY' and FbEVcUzgwsBvqpXGkrHyPJWijSACNQ==FbEVcUzgwsBvqpXGkrHyPJWijSACLI:continue
   elif FbEVcUzgwsBvqpXGkrHyPJWijSACNn.get('mode')=='MENU_BOOKMARK' and FbEVcUzgwsBvqpXGkrHyPJWijSACNL==FbEVcUzgwsBvqpXGkrHyPJWijSACLI:continue
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf={'mode':FbEVcUzgwsBvqpXGkrHyPJWijSACNn.get('mode'),'stype':FbEVcUzgwsBvqpXGkrHyPJWijSACNn.get('stype'),'orderby':FbEVcUzgwsBvqpXGkrHyPJWijSACNn.get('orderby'),'ordernm':FbEVcUzgwsBvqpXGkrHyPJWijSACNn.get('ordernm'),'page':'1','bandKey':FbEVcUzgwsBvqpXGkrHyPJWijSACNn.get('bandKey'),'bandGroup':FbEVcUzgwsBvqpXGkrHyPJWijSACNn.get('bandGroup'),'nextApiUrl':'-',}
   if FbEVcUzgwsBvqpXGkrHyPJWijSACNn.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    FbEVcUzgwsBvqpXGkrHyPJWijSACte=FbEVcUzgwsBvqpXGkrHyPJWijSACLI
    FbEVcUzgwsBvqpXGkrHyPJWijSACtN =FbEVcUzgwsBvqpXGkrHyPJWijSACLY
   else:
    FbEVcUzgwsBvqpXGkrHyPJWijSACte=FbEVcUzgwsBvqpXGkrHyPJWijSACLY
    FbEVcUzgwsBvqpXGkrHyPJWijSACtN =FbEVcUzgwsBvqpXGkrHyPJWijSACLI
   FbEVcUzgwsBvqpXGkrHyPJWijSACtI={'title':FbEVcUzgwsBvqpXGkrHyPJWijSACNo,'plot':FbEVcUzgwsBvqpXGkrHyPJWijSACNo}
   if FbEVcUzgwsBvqpXGkrHyPJWijSACNn.get('mode')=='XXX':FbEVcUzgwsBvqpXGkrHyPJWijSACtI=FbEVcUzgwsBvqpXGkrHyPJWijSACLN
   if 'icon' in FbEVcUzgwsBvqpXGkrHyPJWijSACNn:FbEVcUzgwsBvqpXGkrHyPJWijSACNT=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',FbEVcUzgwsBvqpXGkrHyPJWijSACNn.get('icon')) 
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.add_dir(FbEVcUzgwsBvqpXGkrHyPJWijSACNo,sublabel='',img=FbEVcUzgwsBvqpXGkrHyPJWijSACNT,infoLabels=FbEVcUzgwsBvqpXGkrHyPJWijSACtI,isFolder=FbEVcUzgwsBvqpXGkrHyPJWijSACte,params=FbEVcUzgwsBvqpXGkrHyPJWijSACNf,isLink=FbEVcUzgwsBvqpXGkrHyPJWijSACtN)
  xbmcplugin.endOfDirectory(FbEVcUzgwsBvqpXGkrHyPJWijSACeh._addon_handle)
 def login_main(FbEVcUzgwsBvqpXGkrHyPJWijSACeh):
  (FbEVcUzgwsBvqpXGkrHyPJWijSACtD,FbEVcUzgwsBvqpXGkrHyPJWijSACta,FbEVcUzgwsBvqpXGkrHyPJWijSACtQ,FbEVcUzgwsBvqpXGkrHyPJWijSACtL)=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.get_settings_account()
  if not(FbEVcUzgwsBvqpXGkrHyPJWijSACtD and FbEVcUzgwsBvqpXGkrHyPJWijSACta):
   FbEVcUzgwsBvqpXGkrHyPJWijSACeu=xbmcgui.Dialog()
   FbEVcUzgwsBvqpXGkrHyPJWijSACtM=FbEVcUzgwsBvqpXGkrHyPJWijSACeu.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if FbEVcUzgwsBvqpXGkrHyPJWijSACtM==FbEVcUzgwsBvqpXGkrHyPJWijSACLY:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if FbEVcUzgwsBvqpXGkrHyPJWijSACeh.cookiefile_check():return
  if base64.standard_b64encode(FbEVcUzgwsBvqpXGkrHyPJWijSACtD.encode()).decode('utf-8')in['a3ltOTUxMDg4','a3ltMTA4OA==']:
   FbEVcUzgwsBvqpXGkrHyPJWijSACth=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.GetCredential2(FbEVcUzgwsBvqpXGkrHyPJWijSACtD,FbEVcUzgwsBvqpXGkrHyPJWijSACta,FbEVcUzgwsBvqpXGkrHyPJWijSACtQ,FbEVcUzgwsBvqpXGkrHyPJWijSACtL)
  else:
   FbEVcUzgwsBvqpXGkrHyPJWijSACeu=xbmcgui.Dialog()
   FbEVcUzgwsBvqpXGkrHyPJWijSACtx=FbEVcUzgwsBvqpXGkrHyPJWijSACeu.browse(1,__language__(30917).encode('utf8'),'','.twc',FbEVcUzgwsBvqpXGkrHyPJWijSACLI,FbEVcUzgwsBvqpXGkrHyPJWijSACLI,'',FbEVcUzgwsBvqpXGkrHyPJWijSACLI)
   if FbEVcUzgwsBvqpXGkrHyPJWijSACtx!='':
    FbEVcUzgwsBvqpXGkrHyPJWijSACtl=xbmcvfs.translatePath(os.path.join(__profile__,'tvinginfo-temp.twc'))
    xbmcvfs.copy(FbEVcUzgwsBvqpXGkrHyPJWijSACtx,FbEVcUzgwsBvqpXGkrHyPJWijSACtl)
    FbEVcUzgwsBvqpXGkrHyPJWijSACth=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.WebCookies_Load(FbEVcUzgwsBvqpXGkrHyPJWijSACtl)
    xbmcvfs.delete(FbEVcUzgwsBvqpXGkrHyPJWijSACtl)
    if FbEVcUzgwsBvqpXGkrHyPJWijSACth:
     FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.JsonFile_Save(FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.TV_COOKIE_FILENAME,FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.TV)
     FbEVcUzgwsBvqpXGkrHyPJWijSACeh.addon_noti(__language__(30918).encode('utf8'))
     return
   else:
    FbEVcUzgwsBvqpXGkrHyPJWijSACth=FbEVcUzgwsBvqpXGkrHyPJWijSACLI
  if FbEVcUzgwsBvqpXGkrHyPJWijSACth==FbEVcUzgwsBvqpXGkrHyPJWijSACLY:
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.cookiefile_save()
  else:
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(FbEVcUzgwsBvqpXGkrHyPJWijSACeh,FbEVcUzgwsBvqpXGkrHyPJWijSACtK):
  FbEVcUzgwsBvqpXGkrHyPJWijSACto=FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('stype')
  if FbEVcUzgwsBvqpXGkrHyPJWijSACto=='live':
   FbEVcUzgwsBvqpXGkrHyPJWijSACtR=FbEVcUzgwsBvqpXGkrHyPJWijSACeI
  elif FbEVcUzgwsBvqpXGkrHyPJWijSACto=='drama':
   FbEVcUzgwsBvqpXGkrHyPJWijSACtR=FbEVcUzgwsBvqpXGkrHyPJWijSACea
  elif FbEVcUzgwsBvqpXGkrHyPJWijSACto=='enter':
   FbEVcUzgwsBvqpXGkrHyPJWijSACtR=FbEVcUzgwsBvqpXGkrHyPJWijSACeQ
  else:
   FbEVcUzgwsBvqpXGkrHyPJWijSACtR=FbEVcUzgwsBvqpXGkrHyPJWijSACeL
  for FbEVcUzgwsBvqpXGkrHyPJWijSACtu in FbEVcUzgwsBvqpXGkrHyPJWijSACtR:
   FbEVcUzgwsBvqpXGkrHyPJWijSACNo=FbEVcUzgwsBvqpXGkrHyPJWijSACtu.get('title')
   if FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('ordernm')!='-':
    FbEVcUzgwsBvqpXGkrHyPJWijSACNo+='  ('+FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('ordernm')+')'
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf={'mode':FbEVcUzgwsBvqpXGkrHyPJWijSACtu.get('mode'),'stype':FbEVcUzgwsBvqpXGkrHyPJWijSACtu.get('stype'),'genre':FbEVcUzgwsBvqpXGkrHyPJWijSACtu.get('genre'),'orderby':FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('orderby'),'ordernm':FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('ordernm'),'page':'1',}
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.add_dir(FbEVcUzgwsBvqpXGkrHyPJWijSACNo,sublabel='',img='',infoLabels=FbEVcUzgwsBvqpXGkrHyPJWijSACLN,isFolder=FbEVcUzgwsBvqpXGkrHyPJWijSACLY,params=FbEVcUzgwsBvqpXGkrHyPJWijSACNf)
  if FbEVcUzgwsBvqpXGkrHyPJWijSACLh(FbEVcUzgwsBvqpXGkrHyPJWijSACtR)>0:xbmcplugin.endOfDirectory(FbEVcUzgwsBvqpXGkrHyPJWijSACeh._addon_handle)
 def dp_LiveChannel_List(FbEVcUzgwsBvqpXGkrHyPJWijSACeh,FbEVcUzgwsBvqpXGkrHyPJWijSACtK):
  FbEVcUzgwsBvqpXGkrHyPJWijSACto =FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('stype')
  FbEVcUzgwsBvqpXGkrHyPJWijSACtm =FbEVcUzgwsBvqpXGkrHyPJWijSACLt(FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('page'))
  FbEVcUzgwsBvqpXGkrHyPJWijSACtd,FbEVcUzgwsBvqpXGkrHyPJWijSACtO=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.GetLiveChannelList(FbEVcUzgwsBvqpXGkrHyPJWijSACto,FbEVcUzgwsBvqpXGkrHyPJWijSACtm)
  for FbEVcUzgwsBvqpXGkrHyPJWijSACtn in FbEVcUzgwsBvqpXGkrHyPJWijSACtd:
   FbEVcUzgwsBvqpXGkrHyPJWijSACNo =FbEVcUzgwsBvqpXGkrHyPJWijSACtn.get('title')
   FbEVcUzgwsBvqpXGkrHyPJWijSACtY =FbEVcUzgwsBvqpXGkrHyPJWijSACtn.get('channel')
   FbEVcUzgwsBvqpXGkrHyPJWijSACtT =FbEVcUzgwsBvqpXGkrHyPJWijSACtn.get('thumbnail')
   FbEVcUzgwsBvqpXGkrHyPJWijSACtf =FbEVcUzgwsBvqpXGkrHyPJWijSACtn.get('synopsis')
   FbEVcUzgwsBvqpXGkrHyPJWijSACIe =FbEVcUzgwsBvqpXGkrHyPJWijSACtn.get('channelepg')
   FbEVcUzgwsBvqpXGkrHyPJWijSACIN =FbEVcUzgwsBvqpXGkrHyPJWijSACtn.get('cast')
   FbEVcUzgwsBvqpXGkrHyPJWijSACIt =FbEVcUzgwsBvqpXGkrHyPJWijSACtn.get('director')
   FbEVcUzgwsBvqpXGkrHyPJWijSACIY =FbEVcUzgwsBvqpXGkrHyPJWijSACtn.get('info_genre')
   FbEVcUzgwsBvqpXGkrHyPJWijSACID =FbEVcUzgwsBvqpXGkrHyPJWijSACtn.get('year')
   FbEVcUzgwsBvqpXGkrHyPJWijSACIa =FbEVcUzgwsBvqpXGkrHyPJWijSACtn.get('mpaa')
   FbEVcUzgwsBvqpXGkrHyPJWijSACIQ =FbEVcUzgwsBvqpXGkrHyPJWijSACtn.get('premiered')
   FbEVcUzgwsBvqpXGkrHyPJWijSACIL={'mediatype':'episode','title':FbEVcUzgwsBvqpXGkrHyPJWijSACNo,'studio':FbEVcUzgwsBvqpXGkrHyPJWijSACtY,'cast':FbEVcUzgwsBvqpXGkrHyPJWijSACIN,'director':FbEVcUzgwsBvqpXGkrHyPJWijSACIt,'genre':FbEVcUzgwsBvqpXGkrHyPJWijSACIY,'plot':'%s\n%s\n%s\n\n%s'%(FbEVcUzgwsBvqpXGkrHyPJWijSACtY,FbEVcUzgwsBvqpXGkrHyPJWijSACNo,FbEVcUzgwsBvqpXGkrHyPJWijSACIe,FbEVcUzgwsBvqpXGkrHyPJWijSACtf),'year':FbEVcUzgwsBvqpXGkrHyPJWijSACID,'mpaa':FbEVcUzgwsBvqpXGkrHyPJWijSACIa,'premiered':FbEVcUzgwsBvqpXGkrHyPJWijSACIQ}
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf={'mode':'LIVE','mediacode':FbEVcUzgwsBvqpXGkrHyPJWijSACtn.get('mediacode'),'stype':FbEVcUzgwsBvqpXGkrHyPJWijSACto}
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.add_dir(FbEVcUzgwsBvqpXGkrHyPJWijSACtY,sublabel=FbEVcUzgwsBvqpXGkrHyPJWijSACNo,img=FbEVcUzgwsBvqpXGkrHyPJWijSACtT,infoLabels=FbEVcUzgwsBvqpXGkrHyPJWijSACIL,isFolder=FbEVcUzgwsBvqpXGkrHyPJWijSACLI,params=FbEVcUzgwsBvqpXGkrHyPJWijSACNf)
  if FbEVcUzgwsBvqpXGkrHyPJWijSACtO:
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf['mode']='CHANNEL' 
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf['stype']=FbEVcUzgwsBvqpXGkrHyPJWijSACto 
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf['page']=FbEVcUzgwsBvqpXGkrHyPJWijSACLx(FbEVcUzgwsBvqpXGkrHyPJWijSACtm+1)
   FbEVcUzgwsBvqpXGkrHyPJWijSACNo='[B]%s >>[/B]'%'다음 페이지'
   FbEVcUzgwsBvqpXGkrHyPJWijSACIM=FbEVcUzgwsBvqpXGkrHyPJWijSACLx(FbEVcUzgwsBvqpXGkrHyPJWijSACtm+1)
   FbEVcUzgwsBvqpXGkrHyPJWijSACNT=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.add_dir(FbEVcUzgwsBvqpXGkrHyPJWijSACNo,sublabel=FbEVcUzgwsBvqpXGkrHyPJWijSACIM,img=FbEVcUzgwsBvqpXGkrHyPJWijSACNT,infoLabels=FbEVcUzgwsBvqpXGkrHyPJWijSACLN,isFolder=FbEVcUzgwsBvqpXGkrHyPJWijSACLY,params=FbEVcUzgwsBvqpXGkrHyPJWijSACNf)
  if FbEVcUzgwsBvqpXGkrHyPJWijSACLh(FbEVcUzgwsBvqpXGkrHyPJWijSACtd)>0:xbmcplugin.endOfDirectory(FbEVcUzgwsBvqpXGkrHyPJWijSACeh._addon_handle,cacheToDisc=FbEVcUzgwsBvqpXGkrHyPJWijSACLI)
 def dp_Program_List(FbEVcUzgwsBvqpXGkrHyPJWijSACeh,FbEVcUzgwsBvqpXGkrHyPJWijSACtK):
  FbEVcUzgwsBvqpXGkrHyPJWijSACIh =FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('stype')
  FbEVcUzgwsBvqpXGkrHyPJWijSACNx =FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('orderby')
  FbEVcUzgwsBvqpXGkrHyPJWijSACtm =FbEVcUzgwsBvqpXGkrHyPJWijSACLt(FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('page'))
  FbEVcUzgwsBvqpXGkrHyPJWijSACIx=FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('genreCode')
  if FbEVcUzgwsBvqpXGkrHyPJWijSACIx==FbEVcUzgwsBvqpXGkrHyPJWijSACLN:FbEVcUzgwsBvqpXGkrHyPJWijSACIx='all'
  FbEVcUzgwsBvqpXGkrHyPJWijSACIl,FbEVcUzgwsBvqpXGkrHyPJWijSACtO=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.GetProgramList(FbEVcUzgwsBvqpXGkrHyPJWijSACIh,FbEVcUzgwsBvqpXGkrHyPJWijSACNx,FbEVcUzgwsBvqpXGkrHyPJWijSACtm,FbEVcUzgwsBvqpXGkrHyPJWijSACIx)
  for FbEVcUzgwsBvqpXGkrHyPJWijSACIo in FbEVcUzgwsBvqpXGkrHyPJWijSACIl:
   FbEVcUzgwsBvqpXGkrHyPJWijSACNo =FbEVcUzgwsBvqpXGkrHyPJWijSACIo.get('title')
   FbEVcUzgwsBvqpXGkrHyPJWijSACtT =FbEVcUzgwsBvqpXGkrHyPJWijSACIo.get('thumbnail')
   FbEVcUzgwsBvqpXGkrHyPJWijSACtf =FbEVcUzgwsBvqpXGkrHyPJWijSACIo.get('synopsis')
   FbEVcUzgwsBvqpXGkrHyPJWijSACIR =FbEVcUzgwsBvqpXGkrHyPJWijSACIo.get('channel')
   FbEVcUzgwsBvqpXGkrHyPJWijSACIN =FbEVcUzgwsBvqpXGkrHyPJWijSACIo.get('cast')
   FbEVcUzgwsBvqpXGkrHyPJWijSACIt =FbEVcUzgwsBvqpXGkrHyPJWijSACIo.get('director')
   FbEVcUzgwsBvqpXGkrHyPJWijSACIY=FbEVcUzgwsBvqpXGkrHyPJWijSACIo.get('info_genre')
   FbEVcUzgwsBvqpXGkrHyPJWijSACID =FbEVcUzgwsBvqpXGkrHyPJWijSACIo.get('year')
   FbEVcUzgwsBvqpXGkrHyPJWijSACIQ =FbEVcUzgwsBvqpXGkrHyPJWijSACIo.get('premiered')
   FbEVcUzgwsBvqpXGkrHyPJWijSACIa =FbEVcUzgwsBvqpXGkrHyPJWijSACIo.get('mpaa')
   FbEVcUzgwsBvqpXGkrHyPJWijSACIL={'mediatype':'tvshow','title':FbEVcUzgwsBvqpXGkrHyPJWijSACNo,'studio':FbEVcUzgwsBvqpXGkrHyPJWijSACIR,'cast':FbEVcUzgwsBvqpXGkrHyPJWijSACIN,'director':FbEVcUzgwsBvqpXGkrHyPJWijSACIt,'genre':FbEVcUzgwsBvqpXGkrHyPJWijSACIY,'year':FbEVcUzgwsBvqpXGkrHyPJWijSACID,'premiered':FbEVcUzgwsBvqpXGkrHyPJWijSACIQ,'mpaa':FbEVcUzgwsBvqpXGkrHyPJWijSACIa,'plot':FbEVcUzgwsBvqpXGkrHyPJWijSACtf}
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf={'mode':'EPISODE','programcode':FbEVcUzgwsBvqpXGkrHyPJWijSACIo.get('program'),'page':'1'}
   if FbEVcUzgwsBvqpXGkrHyPJWijSACeh.get_settings_makebookmark():
    FbEVcUzgwsBvqpXGkrHyPJWijSACIu={'videoid':FbEVcUzgwsBvqpXGkrHyPJWijSACIo.get('program'),'vidtype':'tvshow','vtitle':FbEVcUzgwsBvqpXGkrHyPJWijSACNo,'vsubtitle':FbEVcUzgwsBvqpXGkrHyPJWijSACIR,}
    FbEVcUzgwsBvqpXGkrHyPJWijSACIK=json.dumps(FbEVcUzgwsBvqpXGkrHyPJWijSACIu)
    FbEVcUzgwsBvqpXGkrHyPJWijSACIK=urllib.parse.quote(FbEVcUzgwsBvqpXGkrHyPJWijSACIK)
    FbEVcUzgwsBvqpXGkrHyPJWijSACIm='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(FbEVcUzgwsBvqpXGkrHyPJWijSACIK)
    FbEVcUzgwsBvqpXGkrHyPJWijSACId=[('(통합) 찜 영상에 추가',FbEVcUzgwsBvqpXGkrHyPJWijSACIm)]
   else:
    FbEVcUzgwsBvqpXGkrHyPJWijSACId=FbEVcUzgwsBvqpXGkrHyPJWijSACLN
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.add_dir(FbEVcUzgwsBvqpXGkrHyPJWijSACNo,sublabel=FbEVcUzgwsBvqpXGkrHyPJWijSACIR,img=FbEVcUzgwsBvqpXGkrHyPJWijSACtT,infoLabels=FbEVcUzgwsBvqpXGkrHyPJWijSACIL,isFolder=FbEVcUzgwsBvqpXGkrHyPJWijSACLY,params=FbEVcUzgwsBvqpXGkrHyPJWijSACNf,ContextMenu=FbEVcUzgwsBvqpXGkrHyPJWijSACId)
  if FbEVcUzgwsBvqpXGkrHyPJWijSACtO:
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf['mode'] ='PROGRAM' 
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf['stype'] =FbEVcUzgwsBvqpXGkrHyPJWijSACIh
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf['orderby'] =FbEVcUzgwsBvqpXGkrHyPJWijSACNx
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf['page'] =FbEVcUzgwsBvqpXGkrHyPJWijSACLx(FbEVcUzgwsBvqpXGkrHyPJWijSACtm+1)
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf['genreCode']=FbEVcUzgwsBvqpXGkrHyPJWijSACIx 
   FbEVcUzgwsBvqpXGkrHyPJWijSACNo='[B]%s >>[/B]'%'다음 페이지'
   FbEVcUzgwsBvqpXGkrHyPJWijSACIM=FbEVcUzgwsBvqpXGkrHyPJWijSACLx(FbEVcUzgwsBvqpXGkrHyPJWijSACtm+1)
   FbEVcUzgwsBvqpXGkrHyPJWijSACNT=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.add_dir(FbEVcUzgwsBvqpXGkrHyPJWijSACNo,sublabel=FbEVcUzgwsBvqpXGkrHyPJWijSACIM,img=FbEVcUzgwsBvqpXGkrHyPJWijSACNT,infoLabels=FbEVcUzgwsBvqpXGkrHyPJWijSACLN,isFolder=FbEVcUzgwsBvqpXGkrHyPJWijSACLY,params=FbEVcUzgwsBvqpXGkrHyPJWijSACNf)
  xbmcplugin.setContent(FbEVcUzgwsBvqpXGkrHyPJWijSACeh._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(FbEVcUzgwsBvqpXGkrHyPJWijSACeh._addon_handle,cacheToDisc=FbEVcUzgwsBvqpXGkrHyPJWijSACLI)
 def dp_Episode_List(FbEVcUzgwsBvqpXGkrHyPJWijSACeh,FbEVcUzgwsBvqpXGkrHyPJWijSACtK):
  FbEVcUzgwsBvqpXGkrHyPJWijSACIn=FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('programcode')
  FbEVcUzgwsBvqpXGkrHyPJWijSACtm =FbEVcUzgwsBvqpXGkrHyPJWijSACLt(FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('page'))
  FbEVcUzgwsBvqpXGkrHyPJWijSACeh.addon_log('programcode : {}'.format(FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('programcode')))
  FbEVcUzgwsBvqpXGkrHyPJWijSACeh.addon_log('page        : {}'.format(FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('page')))
  FbEVcUzgwsBvqpXGkrHyPJWijSACIT,FbEVcUzgwsBvqpXGkrHyPJWijSACtO,FbEVcUzgwsBvqpXGkrHyPJWijSACIf=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.GetEpisodeList(FbEVcUzgwsBvqpXGkrHyPJWijSACIn,FbEVcUzgwsBvqpXGkrHyPJWijSACtm,orderby=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.get_winEpisodeOrderby())
  FbEVcUzgwsBvqpXGkrHyPJWijSACeh.addon_log('count       : {}'.format(FbEVcUzgwsBvqpXGkrHyPJWijSACLh(FbEVcUzgwsBvqpXGkrHyPJWijSACIT)))
  for FbEVcUzgwsBvqpXGkrHyPJWijSACYe in FbEVcUzgwsBvqpXGkrHyPJWijSACIT:
   FbEVcUzgwsBvqpXGkrHyPJWijSACNo =FbEVcUzgwsBvqpXGkrHyPJWijSACYe.get('title')
   FbEVcUzgwsBvqpXGkrHyPJWijSACIM =FbEVcUzgwsBvqpXGkrHyPJWijSACYe.get('subtitle')
   FbEVcUzgwsBvqpXGkrHyPJWijSACtT =FbEVcUzgwsBvqpXGkrHyPJWijSACYe.get('thumbnail')
   FbEVcUzgwsBvqpXGkrHyPJWijSACtf =FbEVcUzgwsBvqpXGkrHyPJWijSACYe.get('synopsis')
   FbEVcUzgwsBvqpXGkrHyPJWijSACYN=FbEVcUzgwsBvqpXGkrHyPJWijSACYe.get('info_title')
   FbEVcUzgwsBvqpXGkrHyPJWijSACYt =FbEVcUzgwsBvqpXGkrHyPJWijSACYe.get('aired')
   FbEVcUzgwsBvqpXGkrHyPJWijSACYI =FbEVcUzgwsBvqpXGkrHyPJWijSACYe.get('studio')
   FbEVcUzgwsBvqpXGkrHyPJWijSACYD =FbEVcUzgwsBvqpXGkrHyPJWijSACYe.get('frequency')
   FbEVcUzgwsBvqpXGkrHyPJWijSACIL={'mediatype':'episode','title':FbEVcUzgwsBvqpXGkrHyPJWijSACYN,'aired':FbEVcUzgwsBvqpXGkrHyPJWijSACYt,'studio':FbEVcUzgwsBvqpXGkrHyPJWijSACYI,'episode':FbEVcUzgwsBvqpXGkrHyPJWijSACYD,'plot':FbEVcUzgwsBvqpXGkrHyPJWijSACtf}
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf={'mode':'VOD','mediacode':FbEVcUzgwsBvqpXGkrHyPJWijSACYe.get('episode'),'stype':'vod','programcode':FbEVcUzgwsBvqpXGkrHyPJWijSACIn,'title':FbEVcUzgwsBvqpXGkrHyPJWijSACNo,'thumbnail':FbEVcUzgwsBvqpXGkrHyPJWijSACtT}
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.add_dir(FbEVcUzgwsBvqpXGkrHyPJWijSACNo,sublabel=FbEVcUzgwsBvqpXGkrHyPJWijSACIM,img=FbEVcUzgwsBvqpXGkrHyPJWijSACtT,infoLabels=FbEVcUzgwsBvqpXGkrHyPJWijSACIL,isFolder=FbEVcUzgwsBvqpXGkrHyPJWijSACLI,params=FbEVcUzgwsBvqpXGkrHyPJWijSACNf)
  if FbEVcUzgwsBvqpXGkrHyPJWijSACtm==1:
   FbEVcUzgwsBvqpXGkrHyPJWijSACIL={'plot':'정렬순서를 변경합니다.'}
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf={}
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf['mode'] ='ORDER_BY' 
   if FbEVcUzgwsBvqpXGkrHyPJWijSACeh.get_winEpisodeOrderby()=='desc':
    FbEVcUzgwsBvqpXGkrHyPJWijSACNo='정렬순서변경 : 최신화부터 -> 1회부터'
    FbEVcUzgwsBvqpXGkrHyPJWijSACNf['orderby']='asc'
   else:
    FbEVcUzgwsBvqpXGkrHyPJWijSACNo='정렬순서변경 : 1회부터 -> 최신화부터'
    FbEVcUzgwsBvqpXGkrHyPJWijSACNf['orderby']='desc'
   FbEVcUzgwsBvqpXGkrHyPJWijSACNT=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.add_dir(FbEVcUzgwsBvqpXGkrHyPJWijSACNo,sublabel='',img=FbEVcUzgwsBvqpXGkrHyPJWijSACNT,infoLabels=FbEVcUzgwsBvqpXGkrHyPJWijSACIL,isFolder=FbEVcUzgwsBvqpXGkrHyPJWijSACLI,params=FbEVcUzgwsBvqpXGkrHyPJWijSACNf,isLink=FbEVcUzgwsBvqpXGkrHyPJWijSACLY)
  if FbEVcUzgwsBvqpXGkrHyPJWijSACtO:
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf['mode'] ='EPISODE' 
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf['programcode']=FbEVcUzgwsBvqpXGkrHyPJWijSACIn
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf['page'] =FbEVcUzgwsBvqpXGkrHyPJWijSACLx(FbEVcUzgwsBvqpXGkrHyPJWijSACtm+1)
   FbEVcUzgwsBvqpXGkrHyPJWijSACNo='[B]%s >>[/B]'%'다음 페이지'
   FbEVcUzgwsBvqpXGkrHyPJWijSACIM=FbEVcUzgwsBvqpXGkrHyPJWijSACLx(FbEVcUzgwsBvqpXGkrHyPJWijSACtm+1)
   FbEVcUzgwsBvqpXGkrHyPJWijSACNT=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.add_dir(FbEVcUzgwsBvqpXGkrHyPJWijSACNo,sublabel=FbEVcUzgwsBvqpXGkrHyPJWijSACIM,img=FbEVcUzgwsBvqpXGkrHyPJWijSACNT,infoLabels=FbEVcUzgwsBvqpXGkrHyPJWijSACLN,isFolder=FbEVcUzgwsBvqpXGkrHyPJWijSACLY,params=FbEVcUzgwsBvqpXGkrHyPJWijSACNf)
  xbmcplugin.setContent(FbEVcUzgwsBvqpXGkrHyPJWijSACeh._addon_handle,'episodes')
  if FbEVcUzgwsBvqpXGkrHyPJWijSACLh(FbEVcUzgwsBvqpXGkrHyPJWijSACIT)>0:xbmcplugin.endOfDirectory(FbEVcUzgwsBvqpXGkrHyPJWijSACeh._addon_handle,cacheToDisc=FbEVcUzgwsBvqpXGkrHyPJWijSACLI)
 def dp_setEpOrderby(FbEVcUzgwsBvqpXGkrHyPJWijSACeh,FbEVcUzgwsBvqpXGkrHyPJWijSACtK):
  FbEVcUzgwsBvqpXGkrHyPJWijSACNx =FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('orderby')
  FbEVcUzgwsBvqpXGkrHyPJWijSACeh.set_winEpisodeOrderby(FbEVcUzgwsBvqpXGkrHyPJWijSACNx)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(FbEVcUzgwsBvqpXGkrHyPJWijSACeh,FbEVcUzgwsBvqpXGkrHyPJWijSACtK):
  FbEVcUzgwsBvqpXGkrHyPJWijSACIh =FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('stype')
  FbEVcUzgwsBvqpXGkrHyPJWijSACNx =FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('orderby')
  FbEVcUzgwsBvqpXGkrHyPJWijSACtm=FbEVcUzgwsBvqpXGkrHyPJWijSACLt(FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('page'))
  FbEVcUzgwsBvqpXGkrHyPJWijSACYa,FbEVcUzgwsBvqpXGkrHyPJWijSACtO=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.GetMovieList(FbEVcUzgwsBvqpXGkrHyPJWijSACIh,FbEVcUzgwsBvqpXGkrHyPJWijSACNx,FbEVcUzgwsBvqpXGkrHyPJWijSACtm)
  for FbEVcUzgwsBvqpXGkrHyPJWijSACYQ in FbEVcUzgwsBvqpXGkrHyPJWijSACYa:
   FbEVcUzgwsBvqpXGkrHyPJWijSACNo =FbEVcUzgwsBvqpXGkrHyPJWijSACYQ.get('title')
   FbEVcUzgwsBvqpXGkrHyPJWijSACtT =FbEVcUzgwsBvqpXGkrHyPJWijSACYQ.get('thumbnail')
   FbEVcUzgwsBvqpXGkrHyPJWijSACtf =FbEVcUzgwsBvqpXGkrHyPJWijSACYQ.get('synopsis')
   FbEVcUzgwsBvqpXGkrHyPJWijSACYN =FbEVcUzgwsBvqpXGkrHyPJWijSACYQ.get('info_title')
   FbEVcUzgwsBvqpXGkrHyPJWijSACID =FbEVcUzgwsBvqpXGkrHyPJWijSACYQ.get('year')
   FbEVcUzgwsBvqpXGkrHyPJWijSACIN =FbEVcUzgwsBvqpXGkrHyPJWijSACYQ.get('cast')
   FbEVcUzgwsBvqpXGkrHyPJWijSACIt =FbEVcUzgwsBvqpXGkrHyPJWijSACYQ.get('director')
   FbEVcUzgwsBvqpXGkrHyPJWijSACIY =FbEVcUzgwsBvqpXGkrHyPJWijSACYQ.get('info_genre')
   FbEVcUzgwsBvqpXGkrHyPJWijSACYL =FbEVcUzgwsBvqpXGkrHyPJWijSACYQ.get('duration')
   FbEVcUzgwsBvqpXGkrHyPJWijSACIQ =FbEVcUzgwsBvqpXGkrHyPJWijSACYQ.get('premiered')
   FbEVcUzgwsBvqpXGkrHyPJWijSACYI =FbEVcUzgwsBvqpXGkrHyPJWijSACYQ.get('studio')
   FbEVcUzgwsBvqpXGkrHyPJWijSACIa =FbEVcUzgwsBvqpXGkrHyPJWijSACYQ.get('mpaa')
   FbEVcUzgwsBvqpXGkrHyPJWijSACIL={'mediatype':'movie','title':FbEVcUzgwsBvqpXGkrHyPJWijSACYN,'year':FbEVcUzgwsBvqpXGkrHyPJWijSACID,'cast':FbEVcUzgwsBvqpXGkrHyPJWijSACIN,'director':FbEVcUzgwsBvqpXGkrHyPJWijSACIt,'genre':FbEVcUzgwsBvqpXGkrHyPJWijSACIY,'duration':FbEVcUzgwsBvqpXGkrHyPJWijSACYL,'premiered':FbEVcUzgwsBvqpXGkrHyPJWijSACIQ,'studio':FbEVcUzgwsBvqpXGkrHyPJWijSACYI,'mpaa':FbEVcUzgwsBvqpXGkrHyPJWijSACIa,'plot':FbEVcUzgwsBvqpXGkrHyPJWijSACtf}
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf={'mode':'MOVIE','mediacode':FbEVcUzgwsBvqpXGkrHyPJWijSACYQ.get('moviecode'),'stype':'movie','title':FbEVcUzgwsBvqpXGkrHyPJWijSACNo,'thumbnail':FbEVcUzgwsBvqpXGkrHyPJWijSACtT}
   if FbEVcUzgwsBvqpXGkrHyPJWijSACeh.get_settings_makebookmark():
    FbEVcUzgwsBvqpXGkrHyPJWijSACIu={'videoid':FbEVcUzgwsBvqpXGkrHyPJWijSACYQ.get('moviecode'),'vidtype':'movie','vtitle':FbEVcUzgwsBvqpXGkrHyPJWijSACYN,'vsubtitle':'',}
    FbEVcUzgwsBvqpXGkrHyPJWijSACIK=json.dumps(FbEVcUzgwsBvqpXGkrHyPJWijSACIu)
    FbEVcUzgwsBvqpXGkrHyPJWijSACIK=urllib.parse.quote(FbEVcUzgwsBvqpXGkrHyPJWijSACIK)
    FbEVcUzgwsBvqpXGkrHyPJWijSACIm='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(FbEVcUzgwsBvqpXGkrHyPJWijSACIK)
    FbEVcUzgwsBvqpXGkrHyPJWijSACId=[('(통합) 찜 영상에 추가',FbEVcUzgwsBvqpXGkrHyPJWijSACIm)]
   else:
    FbEVcUzgwsBvqpXGkrHyPJWijSACId=FbEVcUzgwsBvqpXGkrHyPJWijSACLN
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.add_dir(FbEVcUzgwsBvqpXGkrHyPJWijSACNo,sublabel='',img=FbEVcUzgwsBvqpXGkrHyPJWijSACtT,infoLabels=FbEVcUzgwsBvqpXGkrHyPJWijSACIL,isFolder=FbEVcUzgwsBvqpXGkrHyPJWijSACLI,params=FbEVcUzgwsBvqpXGkrHyPJWijSACNf,ContextMenu=FbEVcUzgwsBvqpXGkrHyPJWijSACId)
  if FbEVcUzgwsBvqpXGkrHyPJWijSACtO:
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf={}
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf['mode'] ='MOVIE_SUB' 
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf['orderby']=FbEVcUzgwsBvqpXGkrHyPJWijSACNx
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf['stype'] =FbEVcUzgwsBvqpXGkrHyPJWijSACIh
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf['page'] =FbEVcUzgwsBvqpXGkrHyPJWijSACLx(FbEVcUzgwsBvqpXGkrHyPJWijSACtm+1)
   FbEVcUzgwsBvqpXGkrHyPJWijSACNo='[B]%s >>[/B]'%'다음 페이지'
   FbEVcUzgwsBvqpXGkrHyPJWijSACIM=FbEVcUzgwsBvqpXGkrHyPJWijSACLx(FbEVcUzgwsBvqpXGkrHyPJWijSACtm+1)
   FbEVcUzgwsBvqpXGkrHyPJWijSACNT=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.add_dir(FbEVcUzgwsBvqpXGkrHyPJWijSACNo,sublabel=FbEVcUzgwsBvqpXGkrHyPJWijSACIM,img=FbEVcUzgwsBvqpXGkrHyPJWijSACNT,infoLabels=FbEVcUzgwsBvqpXGkrHyPJWijSACLN,isFolder=FbEVcUzgwsBvqpXGkrHyPJWijSACLY,params=FbEVcUzgwsBvqpXGkrHyPJWijSACNf)
  xbmcplugin.setContent(FbEVcUzgwsBvqpXGkrHyPJWijSACeh._addon_handle,'movies')
  xbmcplugin.endOfDirectory(FbEVcUzgwsBvqpXGkrHyPJWijSACeh._addon_handle,cacheToDisc=FbEVcUzgwsBvqpXGkrHyPJWijSACLI)
 def dp_Set_Bookmark(FbEVcUzgwsBvqpXGkrHyPJWijSACeh,FbEVcUzgwsBvqpXGkrHyPJWijSACtK):
  FbEVcUzgwsBvqpXGkrHyPJWijSACYM=urllib.parse.unquote(FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('bm_param'))
  FbEVcUzgwsBvqpXGkrHyPJWijSACYM=json.loads(FbEVcUzgwsBvqpXGkrHyPJWijSACYM)
  FbEVcUzgwsBvqpXGkrHyPJWijSACYh =FbEVcUzgwsBvqpXGkrHyPJWijSACYM.get('videoid')
  FbEVcUzgwsBvqpXGkrHyPJWijSACYx =FbEVcUzgwsBvqpXGkrHyPJWijSACYM.get('vidtype')
  FbEVcUzgwsBvqpXGkrHyPJWijSACYl =FbEVcUzgwsBvqpXGkrHyPJWijSACYM.get('vtitle')
  FbEVcUzgwsBvqpXGkrHyPJWijSACYo =FbEVcUzgwsBvqpXGkrHyPJWijSACYM.get('vsubtitle')
  FbEVcUzgwsBvqpXGkrHyPJWijSACeu=xbmcgui.Dialog()
  FbEVcUzgwsBvqpXGkrHyPJWijSACtM=FbEVcUzgwsBvqpXGkrHyPJWijSACeu.yesno(__language__(30913).encode('utf8'),FbEVcUzgwsBvqpXGkrHyPJWijSACYl+' \n\n'+__language__(30914))
  if FbEVcUzgwsBvqpXGkrHyPJWijSACtM==FbEVcUzgwsBvqpXGkrHyPJWijSACLI:return
  FbEVcUzgwsBvqpXGkrHyPJWijSACYR=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.GetBookmarkInfo(FbEVcUzgwsBvqpXGkrHyPJWijSACYh,FbEVcUzgwsBvqpXGkrHyPJWijSACYx)
  if FbEVcUzgwsBvqpXGkrHyPJWijSACYo!='':
   FbEVcUzgwsBvqpXGkrHyPJWijSACYR['saveinfo']['subtitle']=FbEVcUzgwsBvqpXGkrHyPJWijSACYo 
   if FbEVcUzgwsBvqpXGkrHyPJWijSACYx=='tvshow':FbEVcUzgwsBvqpXGkrHyPJWijSACYR['saveinfo']['infoLabels']['studio']=FbEVcUzgwsBvqpXGkrHyPJWijSACYo 
  FbEVcUzgwsBvqpXGkrHyPJWijSACYu=json.dumps(FbEVcUzgwsBvqpXGkrHyPJWijSACYR)
  FbEVcUzgwsBvqpXGkrHyPJWijSACYu=urllib.parse.quote(FbEVcUzgwsBvqpXGkrHyPJWijSACYu)
  FbEVcUzgwsBvqpXGkrHyPJWijSACIm ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(FbEVcUzgwsBvqpXGkrHyPJWijSACYu)
  xbmc.executebuiltin(FbEVcUzgwsBvqpXGkrHyPJWijSACIm)
 def dp_Search_Group(FbEVcUzgwsBvqpXGkrHyPJWijSACeh,FbEVcUzgwsBvqpXGkrHyPJWijSACtK):
  if 'search_key' in FbEVcUzgwsBvqpXGkrHyPJWijSACtK:
   FbEVcUzgwsBvqpXGkrHyPJWijSACYK=FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('search_key')
  else:
   FbEVcUzgwsBvqpXGkrHyPJWijSACYK=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not FbEVcUzgwsBvqpXGkrHyPJWijSACYK:
    return
  for FbEVcUzgwsBvqpXGkrHyPJWijSACtu in FbEVcUzgwsBvqpXGkrHyPJWijSACeD:
   FbEVcUzgwsBvqpXGkrHyPJWijSACYm =FbEVcUzgwsBvqpXGkrHyPJWijSACtu.get('mode')
   FbEVcUzgwsBvqpXGkrHyPJWijSACto=FbEVcUzgwsBvqpXGkrHyPJWijSACtu.get('stype')
   FbEVcUzgwsBvqpXGkrHyPJWijSACNo=FbEVcUzgwsBvqpXGkrHyPJWijSACtu.get('title')
   (FbEVcUzgwsBvqpXGkrHyPJWijSACYd,FbEVcUzgwsBvqpXGkrHyPJWijSACtO)=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.Gn2_Search_List(FbEVcUzgwsBvqpXGkrHyPJWijSACYK,1,FbEVcUzgwsBvqpXGkrHyPJWijSACto)
   FbEVcUzgwsBvqpXGkrHyPJWijSACtI={'plot':'검색어 : '+FbEVcUzgwsBvqpXGkrHyPJWijSACYK+'\n\n'+FbEVcUzgwsBvqpXGkrHyPJWijSACeh.Search_FreeList(FbEVcUzgwsBvqpXGkrHyPJWijSACYd)}
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf={'mode':FbEVcUzgwsBvqpXGkrHyPJWijSACYm,'stype':FbEVcUzgwsBvqpXGkrHyPJWijSACto,'search_key':FbEVcUzgwsBvqpXGkrHyPJWijSACYK,'page':'1',}
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.add_dir(FbEVcUzgwsBvqpXGkrHyPJWijSACNo,sublabel='',img='',infoLabels=FbEVcUzgwsBvqpXGkrHyPJWijSACtI,isFolder=FbEVcUzgwsBvqpXGkrHyPJWijSACLY,params=FbEVcUzgwsBvqpXGkrHyPJWijSACNf)
  if FbEVcUzgwsBvqpXGkrHyPJWijSACLh(FbEVcUzgwsBvqpXGkrHyPJWijSACeD)>0:xbmcplugin.endOfDirectory(FbEVcUzgwsBvqpXGkrHyPJWijSACeh._addon_handle,cacheToDisc=FbEVcUzgwsBvqpXGkrHyPJWijSACLY)
  FbEVcUzgwsBvqpXGkrHyPJWijSACeh.Save_Searched_List(FbEVcUzgwsBvqpXGkrHyPJWijSACYK)
 def Search_FreeList(FbEVcUzgwsBvqpXGkrHyPJWijSACeh,FbEVcUzgwsBvqpXGkrHyPJWijSACDY):
  FbEVcUzgwsBvqpXGkrHyPJWijSACYO=''
  FbEVcUzgwsBvqpXGkrHyPJWijSACYn=7
  try:
   if FbEVcUzgwsBvqpXGkrHyPJWijSACLh(FbEVcUzgwsBvqpXGkrHyPJWijSACDY)==0:return '검색결과 없음'
   for i in FbEVcUzgwsBvqpXGkrHyPJWijSACLl(FbEVcUzgwsBvqpXGkrHyPJWijSACLh(FbEVcUzgwsBvqpXGkrHyPJWijSACDY)):
    if i>=FbEVcUzgwsBvqpXGkrHyPJWijSACYn:
     FbEVcUzgwsBvqpXGkrHyPJWijSACYO=FbEVcUzgwsBvqpXGkrHyPJWijSACYO+'...'
     break
    FbEVcUzgwsBvqpXGkrHyPJWijSACYO=FbEVcUzgwsBvqpXGkrHyPJWijSACYO+FbEVcUzgwsBvqpXGkrHyPJWijSACDY[i]['title']+'\n'
  except:
   return ''
  return FbEVcUzgwsBvqpXGkrHyPJWijSACYO
 def dp_Search_History(FbEVcUzgwsBvqpXGkrHyPJWijSACeh,FbEVcUzgwsBvqpXGkrHyPJWijSACtK):
  FbEVcUzgwsBvqpXGkrHyPJWijSACYT=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.Load_List_File('search')
  for FbEVcUzgwsBvqpXGkrHyPJWijSACYf in FbEVcUzgwsBvqpXGkrHyPJWijSACYT:
   FbEVcUzgwsBvqpXGkrHyPJWijSACDe=FbEVcUzgwsBvqpXGkrHyPJWijSACLa(urllib.parse.parse_qsl(FbEVcUzgwsBvqpXGkrHyPJWijSACYf))
   FbEVcUzgwsBvqpXGkrHyPJWijSACDN=FbEVcUzgwsBvqpXGkrHyPJWijSACDe.get('skey').strip()
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf={'mode':'SEARCH_GROUP','search_key':FbEVcUzgwsBvqpXGkrHyPJWijSACDN,}
   FbEVcUzgwsBvqpXGkrHyPJWijSACDt={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':FbEVcUzgwsBvqpXGkrHyPJWijSACDN,'vType':'-',}
   FbEVcUzgwsBvqpXGkrHyPJWijSACDI=urllib.parse.urlencode(FbEVcUzgwsBvqpXGkrHyPJWijSACDt)
   FbEVcUzgwsBvqpXGkrHyPJWijSACId=[('선택된 검색어 ( %s ) 삭제'%(FbEVcUzgwsBvqpXGkrHyPJWijSACDN),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(FbEVcUzgwsBvqpXGkrHyPJWijSACDI))]
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.add_dir(FbEVcUzgwsBvqpXGkrHyPJWijSACDN,sublabel='',img=FbEVcUzgwsBvqpXGkrHyPJWijSACLN,infoLabels=FbEVcUzgwsBvqpXGkrHyPJWijSACLN,isFolder=FbEVcUzgwsBvqpXGkrHyPJWijSACLY,params=FbEVcUzgwsBvqpXGkrHyPJWijSACNf,ContextMenu=FbEVcUzgwsBvqpXGkrHyPJWijSACId)
  FbEVcUzgwsBvqpXGkrHyPJWijSACIL={'plot':'검색목록 전체를 삭제합니다.'}
  FbEVcUzgwsBvqpXGkrHyPJWijSACNo='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  FbEVcUzgwsBvqpXGkrHyPJWijSACNf={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  FbEVcUzgwsBvqpXGkrHyPJWijSACNT=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  FbEVcUzgwsBvqpXGkrHyPJWijSACeh.add_dir(FbEVcUzgwsBvqpXGkrHyPJWijSACNo,sublabel='',img=FbEVcUzgwsBvqpXGkrHyPJWijSACNT,infoLabels=FbEVcUzgwsBvqpXGkrHyPJWijSACIL,isFolder=FbEVcUzgwsBvqpXGkrHyPJWijSACLI,params=FbEVcUzgwsBvqpXGkrHyPJWijSACNf,isLink=FbEVcUzgwsBvqpXGkrHyPJWijSACLY)
  xbmcplugin.endOfDirectory(FbEVcUzgwsBvqpXGkrHyPJWijSACeh._addon_handle,cacheToDisc=FbEVcUzgwsBvqpXGkrHyPJWijSACLI)
 def dp_Search_List(FbEVcUzgwsBvqpXGkrHyPJWijSACeh,FbEVcUzgwsBvqpXGkrHyPJWijSACtK):
  FbEVcUzgwsBvqpXGkrHyPJWijSACtm =FbEVcUzgwsBvqpXGkrHyPJWijSACLt(FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('page'))
  FbEVcUzgwsBvqpXGkrHyPJWijSACto =FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('stype')
  if 'search_key' in FbEVcUzgwsBvqpXGkrHyPJWijSACtK:
   FbEVcUzgwsBvqpXGkrHyPJWijSACYK=FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('search_key')
  else:
   FbEVcUzgwsBvqpXGkrHyPJWijSACYK=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not FbEVcUzgwsBvqpXGkrHyPJWijSACYK:
    xbmcplugin.endOfDirectory(FbEVcUzgwsBvqpXGkrHyPJWijSACeh._addon_handle)
    return
  FbEVcUzgwsBvqpXGkrHyPJWijSACYd,FbEVcUzgwsBvqpXGkrHyPJWijSACtO=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.Gn2_Search_List(FbEVcUzgwsBvqpXGkrHyPJWijSACYK,FbEVcUzgwsBvqpXGkrHyPJWijSACtm,FbEVcUzgwsBvqpXGkrHyPJWijSACto)
  for FbEVcUzgwsBvqpXGkrHyPJWijSACDY in FbEVcUzgwsBvqpXGkrHyPJWijSACYd:
   FbEVcUzgwsBvqpXGkrHyPJWijSACNo =FbEVcUzgwsBvqpXGkrHyPJWijSACDY.get('title')
   FbEVcUzgwsBvqpXGkrHyPJWijSACtT =FbEVcUzgwsBvqpXGkrHyPJWijSACDY.get('thumbnail')
   FbEVcUzgwsBvqpXGkrHyPJWijSACIL={'mediatype':'tvshow' if FbEVcUzgwsBvqpXGkrHyPJWijSACto=='vod' else 'movie','title':FbEVcUzgwsBvqpXGkrHyPJWijSACNo,'plot':'%s'%(FbEVcUzgwsBvqpXGkrHyPJWijSACNo)}
   if FbEVcUzgwsBvqpXGkrHyPJWijSACto=='vod':
    FbEVcUzgwsBvqpXGkrHyPJWijSACYh=FbEVcUzgwsBvqpXGkrHyPJWijSACDY.get('program')
    FbEVcUzgwsBvqpXGkrHyPJWijSACYx='tvshow'
    FbEVcUzgwsBvqpXGkrHyPJWijSACNf={'mode':'EPISODE','programcode':FbEVcUzgwsBvqpXGkrHyPJWijSACYh,'page':'1',}
    FbEVcUzgwsBvqpXGkrHyPJWijSACte=FbEVcUzgwsBvqpXGkrHyPJWijSACLY
   else:
    FbEVcUzgwsBvqpXGkrHyPJWijSACYh=FbEVcUzgwsBvqpXGkrHyPJWijSACDY.get('movie')
    FbEVcUzgwsBvqpXGkrHyPJWijSACYx='movie'
    FbEVcUzgwsBvqpXGkrHyPJWijSACNf={'mode':'MOVIE','mediacode':FbEVcUzgwsBvqpXGkrHyPJWijSACYh,'stype':'movie','title':FbEVcUzgwsBvqpXGkrHyPJWijSACNo,'thumbnail':FbEVcUzgwsBvqpXGkrHyPJWijSACtT,}
    FbEVcUzgwsBvqpXGkrHyPJWijSACte=FbEVcUzgwsBvqpXGkrHyPJWijSACLI
   if FbEVcUzgwsBvqpXGkrHyPJWijSACeh.get_settings_makebookmark():
    FbEVcUzgwsBvqpXGkrHyPJWijSACIu={'videoid':FbEVcUzgwsBvqpXGkrHyPJWijSACYh,'vidtype':FbEVcUzgwsBvqpXGkrHyPJWijSACYx,'vtitle':FbEVcUzgwsBvqpXGkrHyPJWijSACNo,'vsubtitle':'',}
    FbEVcUzgwsBvqpXGkrHyPJWijSACIK=json.dumps(FbEVcUzgwsBvqpXGkrHyPJWijSACIu)
    FbEVcUzgwsBvqpXGkrHyPJWijSACIK=urllib.parse.quote(FbEVcUzgwsBvqpXGkrHyPJWijSACIK)
    FbEVcUzgwsBvqpXGkrHyPJWijSACIm='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(FbEVcUzgwsBvqpXGkrHyPJWijSACIK)
    FbEVcUzgwsBvqpXGkrHyPJWijSACId=[('(통합) 찜 영상에 추가',FbEVcUzgwsBvqpXGkrHyPJWijSACIm)]
   else:
    FbEVcUzgwsBvqpXGkrHyPJWijSACId=FbEVcUzgwsBvqpXGkrHyPJWijSACLN
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.add_dir(FbEVcUzgwsBvqpXGkrHyPJWijSACNo,sublabel='',img=FbEVcUzgwsBvqpXGkrHyPJWijSACtT,infoLabels=FbEVcUzgwsBvqpXGkrHyPJWijSACIL,isFolder=FbEVcUzgwsBvqpXGkrHyPJWijSACte,params=FbEVcUzgwsBvqpXGkrHyPJWijSACNf,isLink=FbEVcUzgwsBvqpXGkrHyPJWijSACLI,ContextMenu=FbEVcUzgwsBvqpXGkrHyPJWijSACId)
  if FbEVcUzgwsBvqpXGkrHyPJWijSACtO:
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf['mode'] ='SEARCH' 
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf['search_key']=FbEVcUzgwsBvqpXGkrHyPJWijSACYK
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf['page'] =FbEVcUzgwsBvqpXGkrHyPJWijSACLx(FbEVcUzgwsBvqpXGkrHyPJWijSACtm+1)
   FbEVcUzgwsBvqpXGkrHyPJWijSACNo='[B]%s >>[/B]'%'다음 페이지'
   FbEVcUzgwsBvqpXGkrHyPJWijSACIM=FbEVcUzgwsBvqpXGkrHyPJWijSACLx(FbEVcUzgwsBvqpXGkrHyPJWijSACtm+1)
   FbEVcUzgwsBvqpXGkrHyPJWijSACNT=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.add_dir(FbEVcUzgwsBvqpXGkrHyPJWijSACNo,sublabel=FbEVcUzgwsBvqpXGkrHyPJWijSACIM,img=FbEVcUzgwsBvqpXGkrHyPJWijSACNT,infoLabels=FbEVcUzgwsBvqpXGkrHyPJWijSACLN,isFolder=FbEVcUzgwsBvqpXGkrHyPJWijSACLY,params=FbEVcUzgwsBvqpXGkrHyPJWijSACNf)
  if FbEVcUzgwsBvqpXGkrHyPJWijSACto=='movie':xbmcplugin.setContent(FbEVcUzgwsBvqpXGkrHyPJWijSACeh._addon_handle,'movies')
  else:xbmcplugin.setContent(FbEVcUzgwsBvqpXGkrHyPJWijSACeh._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(FbEVcUzgwsBvqpXGkrHyPJWijSACeh._addon_handle,cacheToDisc=FbEVcUzgwsBvqpXGkrHyPJWijSACLI)
 def dp_History_Remove(FbEVcUzgwsBvqpXGkrHyPJWijSACeh,FbEVcUzgwsBvqpXGkrHyPJWijSACtK):
  FbEVcUzgwsBvqpXGkrHyPJWijSACDa=FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('delType')
  FbEVcUzgwsBvqpXGkrHyPJWijSACDQ =FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('sKey')
  FbEVcUzgwsBvqpXGkrHyPJWijSACDL =FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('vType')
  FbEVcUzgwsBvqpXGkrHyPJWijSACeu=xbmcgui.Dialog()
  if FbEVcUzgwsBvqpXGkrHyPJWijSACDa=='SEARCH_ALL':
   FbEVcUzgwsBvqpXGkrHyPJWijSACtM=FbEVcUzgwsBvqpXGkrHyPJWijSACeu.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif FbEVcUzgwsBvqpXGkrHyPJWijSACDa=='SEARCH_ONE':
   FbEVcUzgwsBvqpXGkrHyPJWijSACtM=FbEVcUzgwsBvqpXGkrHyPJWijSACeu.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif FbEVcUzgwsBvqpXGkrHyPJWijSACDa=='WATCH_ALL':
   FbEVcUzgwsBvqpXGkrHyPJWijSACtM=FbEVcUzgwsBvqpXGkrHyPJWijSACeu.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif FbEVcUzgwsBvqpXGkrHyPJWijSACDa=='WATCH_ONE':
   FbEVcUzgwsBvqpXGkrHyPJWijSACtM=FbEVcUzgwsBvqpXGkrHyPJWijSACeu.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if FbEVcUzgwsBvqpXGkrHyPJWijSACtM==FbEVcUzgwsBvqpXGkrHyPJWijSACLI:sys.exit()
  if FbEVcUzgwsBvqpXGkrHyPJWijSACDa=='SEARCH_ALL':
   if os.path.isfile(FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.SEARCHED_FILE_NAME):os.remove(FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.SEARCHED_FILE_NAME)
  elif FbEVcUzgwsBvqpXGkrHyPJWijSACDa=='SEARCH_ONE':
   try:
    FbEVcUzgwsBvqpXGkrHyPJWijSACDM=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.SEARCHED_FILE_NAME
    FbEVcUzgwsBvqpXGkrHyPJWijSACDh=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.Load_List_File('search') 
    fp=FbEVcUzgwsBvqpXGkrHyPJWijSACLo(FbEVcUzgwsBvqpXGkrHyPJWijSACDM,'w',-1,'utf-8')
    for FbEVcUzgwsBvqpXGkrHyPJWijSACDx in FbEVcUzgwsBvqpXGkrHyPJWijSACDh:
     FbEVcUzgwsBvqpXGkrHyPJWijSACDl=FbEVcUzgwsBvqpXGkrHyPJWijSACLa(urllib.parse.parse_qsl(FbEVcUzgwsBvqpXGkrHyPJWijSACDx))
     FbEVcUzgwsBvqpXGkrHyPJWijSACDo=FbEVcUzgwsBvqpXGkrHyPJWijSACDl.get('skey').strip()
     if FbEVcUzgwsBvqpXGkrHyPJWijSACDQ!=FbEVcUzgwsBvqpXGkrHyPJWijSACDo:
      fp.write(FbEVcUzgwsBvqpXGkrHyPJWijSACDx)
    fp.close()
   except:
    FbEVcUzgwsBvqpXGkrHyPJWijSACLN
  elif FbEVcUzgwsBvqpXGkrHyPJWijSACDa=='WATCH_ALL':
   FbEVcUzgwsBvqpXGkrHyPJWijSACDM=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%FbEVcUzgwsBvqpXGkrHyPJWijSACDL))
   if os.path.isfile(FbEVcUzgwsBvqpXGkrHyPJWijSACDM):os.remove(FbEVcUzgwsBvqpXGkrHyPJWijSACDM)
  elif FbEVcUzgwsBvqpXGkrHyPJWijSACDa=='WATCH_ONE':
   FbEVcUzgwsBvqpXGkrHyPJWijSACDM=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%FbEVcUzgwsBvqpXGkrHyPJWijSACDL))
   try:
    FbEVcUzgwsBvqpXGkrHyPJWijSACDh=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.Load_List_File(FbEVcUzgwsBvqpXGkrHyPJWijSACDL) 
    fp=FbEVcUzgwsBvqpXGkrHyPJWijSACLo(FbEVcUzgwsBvqpXGkrHyPJWijSACDM,'w',-1,'utf-8')
    for FbEVcUzgwsBvqpXGkrHyPJWijSACDx in FbEVcUzgwsBvqpXGkrHyPJWijSACDh:
     FbEVcUzgwsBvqpXGkrHyPJWijSACDl=FbEVcUzgwsBvqpXGkrHyPJWijSACLa(urllib.parse.parse_qsl(FbEVcUzgwsBvqpXGkrHyPJWijSACDx))
     FbEVcUzgwsBvqpXGkrHyPJWijSACDo=FbEVcUzgwsBvqpXGkrHyPJWijSACDl.get('code').strip()
     if FbEVcUzgwsBvqpXGkrHyPJWijSACDQ!=FbEVcUzgwsBvqpXGkrHyPJWijSACDo:
      fp.write(FbEVcUzgwsBvqpXGkrHyPJWijSACDx)
    fp.close()
   except:
    FbEVcUzgwsBvqpXGkrHyPJWijSACLN
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(FbEVcUzgwsBvqpXGkrHyPJWijSACeh,FbEVcUzgwsBvqpXGkrHyPJWijSACto): 
  try:
   if FbEVcUzgwsBvqpXGkrHyPJWijSACto=='search':
    FbEVcUzgwsBvqpXGkrHyPJWijSACDM=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.SEARCHED_FILE_NAME
   elif FbEVcUzgwsBvqpXGkrHyPJWijSACto in['vod','movie']:
    FbEVcUzgwsBvqpXGkrHyPJWijSACDM=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%FbEVcUzgwsBvqpXGkrHyPJWijSACto))
   else:
    return[]
   fp=FbEVcUzgwsBvqpXGkrHyPJWijSACLo(FbEVcUzgwsBvqpXGkrHyPJWijSACDM,'r',-1,'utf-8')
   FbEVcUzgwsBvqpXGkrHyPJWijSACDR=fp.readlines()
   fp.close()
  except:
   FbEVcUzgwsBvqpXGkrHyPJWijSACDR=[]
  return FbEVcUzgwsBvqpXGkrHyPJWijSACDR
 def Save_Watched_List(FbEVcUzgwsBvqpXGkrHyPJWijSACeh,FbEVcUzgwsBvqpXGkrHyPJWijSACto,FbEVcUzgwsBvqpXGkrHyPJWijSACeo):
  try:
   FbEVcUzgwsBvqpXGkrHyPJWijSACDu=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%FbEVcUzgwsBvqpXGkrHyPJWijSACto))
   FbEVcUzgwsBvqpXGkrHyPJWijSACDh=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.Load_List_File(FbEVcUzgwsBvqpXGkrHyPJWijSACto) 
   fp=FbEVcUzgwsBvqpXGkrHyPJWijSACLo(FbEVcUzgwsBvqpXGkrHyPJWijSACDu,'w',-1,'utf-8')
   FbEVcUzgwsBvqpXGkrHyPJWijSACDK=urllib.parse.urlencode(FbEVcUzgwsBvqpXGkrHyPJWijSACeo)
   FbEVcUzgwsBvqpXGkrHyPJWijSACDK=FbEVcUzgwsBvqpXGkrHyPJWijSACDK+'\n'
   fp.write(FbEVcUzgwsBvqpXGkrHyPJWijSACDK)
   FbEVcUzgwsBvqpXGkrHyPJWijSACDm=0
   for FbEVcUzgwsBvqpXGkrHyPJWijSACDx in FbEVcUzgwsBvqpXGkrHyPJWijSACDh:
    FbEVcUzgwsBvqpXGkrHyPJWijSACDl=FbEVcUzgwsBvqpXGkrHyPJWijSACLa(urllib.parse.parse_qsl(FbEVcUzgwsBvqpXGkrHyPJWijSACDx))
    FbEVcUzgwsBvqpXGkrHyPJWijSACDd=FbEVcUzgwsBvqpXGkrHyPJWijSACeo.get('code').strip()
    FbEVcUzgwsBvqpXGkrHyPJWijSACDO=FbEVcUzgwsBvqpXGkrHyPJWijSACDl.get('code').strip()
    if FbEVcUzgwsBvqpXGkrHyPJWijSACto=='vod' and FbEVcUzgwsBvqpXGkrHyPJWijSACeh.get_settings_direct_replay()==FbEVcUzgwsBvqpXGkrHyPJWijSACLY:
     FbEVcUzgwsBvqpXGkrHyPJWijSACDd=FbEVcUzgwsBvqpXGkrHyPJWijSACeo.get('videoid').strip()
     FbEVcUzgwsBvqpXGkrHyPJWijSACDO=FbEVcUzgwsBvqpXGkrHyPJWijSACDl.get('videoid').strip()if FbEVcUzgwsBvqpXGkrHyPJWijSACDO!=FbEVcUzgwsBvqpXGkrHyPJWijSACLN else '-'
    if FbEVcUzgwsBvqpXGkrHyPJWijSACDd!=FbEVcUzgwsBvqpXGkrHyPJWijSACDO:
     fp.write(FbEVcUzgwsBvqpXGkrHyPJWijSACDx)
     FbEVcUzgwsBvqpXGkrHyPJWijSACDm+=1
     if FbEVcUzgwsBvqpXGkrHyPJWijSACDm>=50:break
   fp.close()
  except:
   FbEVcUzgwsBvqpXGkrHyPJWijSACLN
 def dp_Watch_List(FbEVcUzgwsBvqpXGkrHyPJWijSACeh,FbEVcUzgwsBvqpXGkrHyPJWijSACtK):
  FbEVcUzgwsBvqpXGkrHyPJWijSACto =FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('stype')
  FbEVcUzgwsBvqpXGkrHyPJWijSACNM=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.get_settings_direct_replay()
  if FbEVcUzgwsBvqpXGkrHyPJWijSACto=='-':
   for FbEVcUzgwsBvqpXGkrHyPJWijSACtu in FbEVcUzgwsBvqpXGkrHyPJWijSACeY:
    FbEVcUzgwsBvqpXGkrHyPJWijSACNo=FbEVcUzgwsBvqpXGkrHyPJWijSACtu.get('title')
    FbEVcUzgwsBvqpXGkrHyPJWijSACNf={'mode':FbEVcUzgwsBvqpXGkrHyPJWijSACtu.get('mode'),'stype':FbEVcUzgwsBvqpXGkrHyPJWijSACtu.get('stype')}
    FbEVcUzgwsBvqpXGkrHyPJWijSACeh.add_dir(FbEVcUzgwsBvqpXGkrHyPJWijSACNo,sublabel='',img='',infoLabels=FbEVcUzgwsBvqpXGkrHyPJWijSACLN,isFolder=FbEVcUzgwsBvqpXGkrHyPJWijSACLY,params=FbEVcUzgwsBvqpXGkrHyPJWijSACNf)
   if FbEVcUzgwsBvqpXGkrHyPJWijSACLh(FbEVcUzgwsBvqpXGkrHyPJWijSACeY)>0:xbmcplugin.endOfDirectory(FbEVcUzgwsBvqpXGkrHyPJWijSACeh._addon_handle)
  else:
   FbEVcUzgwsBvqpXGkrHyPJWijSACDn=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.Load_List_File(FbEVcUzgwsBvqpXGkrHyPJWijSACto)
   for FbEVcUzgwsBvqpXGkrHyPJWijSACDT in FbEVcUzgwsBvqpXGkrHyPJWijSACDn:
    FbEVcUzgwsBvqpXGkrHyPJWijSACDe=FbEVcUzgwsBvqpXGkrHyPJWijSACLa(urllib.parse.parse_qsl(FbEVcUzgwsBvqpXGkrHyPJWijSACDT))
    FbEVcUzgwsBvqpXGkrHyPJWijSACDf =FbEVcUzgwsBvqpXGkrHyPJWijSACDe.get('code').strip()
    FbEVcUzgwsBvqpXGkrHyPJWijSACNo =FbEVcUzgwsBvqpXGkrHyPJWijSACDe.get('title').strip()
    FbEVcUzgwsBvqpXGkrHyPJWijSACtT=FbEVcUzgwsBvqpXGkrHyPJWijSACDe.get('img').strip()
    FbEVcUzgwsBvqpXGkrHyPJWijSACYh =FbEVcUzgwsBvqpXGkrHyPJWijSACDe.get('videoid').strip()
    try:
     FbEVcUzgwsBvqpXGkrHyPJWijSACtT=FbEVcUzgwsBvqpXGkrHyPJWijSACtT.replace('\'','\"')
     FbEVcUzgwsBvqpXGkrHyPJWijSACtT=json.loads(FbEVcUzgwsBvqpXGkrHyPJWijSACtT)
    except:
     FbEVcUzgwsBvqpXGkrHyPJWijSACLN
    FbEVcUzgwsBvqpXGkrHyPJWijSACIL={}
    FbEVcUzgwsBvqpXGkrHyPJWijSACIL['plot']=FbEVcUzgwsBvqpXGkrHyPJWijSACNo
    if FbEVcUzgwsBvqpXGkrHyPJWijSACto=='vod':
     if FbEVcUzgwsBvqpXGkrHyPJWijSACNM==FbEVcUzgwsBvqpXGkrHyPJWijSACLI or FbEVcUzgwsBvqpXGkrHyPJWijSACYh==FbEVcUzgwsBvqpXGkrHyPJWijSACLN:
      FbEVcUzgwsBvqpXGkrHyPJWijSACIL['mediatype']='tvshow'
      FbEVcUzgwsBvqpXGkrHyPJWijSACNf={'mode':'EPISODE','programcode':FbEVcUzgwsBvqpXGkrHyPJWijSACDf,'page':'1'}
      FbEVcUzgwsBvqpXGkrHyPJWijSACte=FbEVcUzgwsBvqpXGkrHyPJWijSACLY
     else:
      FbEVcUzgwsBvqpXGkrHyPJWijSACIL['mediatype']='episode'
      FbEVcUzgwsBvqpXGkrHyPJWijSACNf={'mode':'VOD','mediacode':FbEVcUzgwsBvqpXGkrHyPJWijSACYh,'stype':'vod','programcode':FbEVcUzgwsBvqpXGkrHyPJWijSACDf,'title':FbEVcUzgwsBvqpXGkrHyPJWijSACNo,'thumbnail':FbEVcUzgwsBvqpXGkrHyPJWijSACtT}
      FbEVcUzgwsBvqpXGkrHyPJWijSACte=FbEVcUzgwsBvqpXGkrHyPJWijSACLI
    else:
     FbEVcUzgwsBvqpXGkrHyPJWijSACIL['mediatype']='movie'
     FbEVcUzgwsBvqpXGkrHyPJWijSACNf={'mode':'MOVIE','mediacode':FbEVcUzgwsBvqpXGkrHyPJWijSACDf,'stype':'movie','title':FbEVcUzgwsBvqpXGkrHyPJWijSACNo,'thumbnail':FbEVcUzgwsBvqpXGkrHyPJWijSACtT}
     FbEVcUzgwsBvqpXGkrHyPJWijSACte=FbEVcUzgwsBvqpXGkrHyPJWijSACLI
    FbEVcUzgwsBvqpXGkrHyPJWijSACDt={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':FbEVcUzgwsBvqpXGkrHyPJWijSACDf,'vType':FbEVcUzgwsBvqpXGkrHyPJWijSACto,}
    FbEVcUzgwsBvqpXGkrHyPJWijSACDI=urllib.parse.urlencode(FbEVcUzgwsBvqpXGkrHyPJWijSACDt)
    FbEVcUzgwsBvqpXGkrHyPJWijSACId=[('선택된 시청이력 ( %s ) 삭제'%(FbEVcUzgwsBvqpXGkrHyPJWijSACNo),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(FbEVcUzgwsBvqpXGkrHyPJWijSACDI))]
    FbEVcUzgwsBvqpXGkrHyPJWijSACeh.add_dir(FbEVcUzgwsBvqpXGkrHyPJWijSACNo,sublabel='',img=FbEVcUzgwsBvqpXGkrHyPJWijSACtT,infoLabels=FbEVcUzgwsBvqpXGkrHyPJWijSACIL,isFolder=FbEVcUzgwsBvqpXGkrHyPJWijSACte,params=FbEVcUzgwsBvqpXGkrHyPJWijSACNf,ContextMenu=FbEVcUzgwsBvqpXGkrHyPJWijSACId)
   FbEVcUzgwsBvqpXGkrHyPJWijSACIL={'plot':'시청목록을 삭제합니다.'}
   FbEVcUzgwsBvqpXGkrHyPJWijSACNo='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':FbEVcUzgwsBvqpXGkrHyPJWijSACto,}
   FbEVcUzgwsBvqpXGkrHyPJWijSACNT=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.add_dir(FbEVcUzgwsBvqpXGkrHyPJWijSACNo,sublabel='',img=FbEVcUzgwsBvqpXGkrHyPJWijSACNT,infoLabels=FbEVcUzgwsBvqpXGkrHyPJWijSACIL,isFolder=FbEVcUzgwsBvqpXGkrHyPJWijSACLI,params=FbEVcUzgwsBvqpXGkrHyPJWijSACNf,isLink=FbEVcUzgwsBvqpXGkrHyPJWijSACLY)
   if FbEVcUzgwsBvqpXGkrHyPJWijSACto=='movie':xbmcplugin.setContent(FbEVcUzgwsBvqpXGkrHyPJWijSACeh._addon_handle,'movies')
   else:xbmcplugin.setContent(FbEVcUzgwsBvqpXGkrHyPJWijSACeh._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(FbEVcUzgwsBvqpXGkrHyPJWijSACeh._addon_handle,cacheToDisc=FbEVcUzgwsBvqpXGkrHyPJWijSACLI)
 def Save_Searched_List(FbEVcUzgwsBvqpXGkrHyPJWijSACeh,FbEVcUzgwsBvqpXGkrHyPJWijSACYK):
  try:
   FbEVcUzgwsBvqpXGkrHyPJWijSACae=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.SEARCHED_FILE_NAME
   FbEVcUzgwsBvqpXGkrHyPJWijSACDh=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.Load_List_File('search') 
   FbEVcUzgwsBvqpXGkrHyPJWijSACaN={'skey':FbEVcUzgwsBvqpXGkrHyPJWijSACYK.strip()}
   fp=FbEVcUzgwsBvqpXGkrHyPJWijSACLo(FbEVcUzgwsBvqpXGkrHyPJWijSACae,'w',-1,'utf-8')
   FbEVcUzgwsBvqpXGkrHyPJWijSACDK=urllib.parse.urlencode(FbEVcUzgwsBvqpXGkrHyPJWijSACaN)
   FbEVcUzgwsBvqpXGkrHyPJWijSACDK=FbEVcUzgwsBvqpXGkrHyPJWijSACDK+'\n'
   fp.write(FbEVcUzgwsBvqpXGkrHyPJWijSACDK)
   FbEVcUzgwsBvqpXGkrHyPJWijSACDm=0
   for FbEVcUzgwsBvqpXGkrHyPJWijSACDx in FbEVcUzgwsBvqpXGkrHyPJWijSACDh:
    FbEVcUzgwsBvqpXGkrHyPJWijSACDl=FbEVcUzgwsBvqpXGkrHyPJWijSACLa(urllib.parse.parse_qsl(FbEVcUzgwsBvqpXGkrHyPJWijSACDx))
    FbEVcUzgwsBvqpXGkrHyPJWijSACDd=FbEVcUzgwsBvqpXGkrHyPJWijSACaN.get('skey').strip()
    FbEVcUzgwsBvqpXGkrHyPJWijSACDO=FbEVcUzgwsBvqpXGkrHyPJWijSACDl.get('skey').strip()
    if FbEVcUzgwsBvqpXGkrHyPJWijSACDd!=FbEVcUzgwsBvqpXGkrHyPJWijSACDO:
     fp.write(FbEVcUzgwsBvqpXGkrHyPJWijSACDx)
     FbEVcUzgwsBvqpXGkrHyPJWijSACDm+=1
     if FbEVcUzgwsBvqpXGkrHyPJWijSACDm>=50:break
   fp.close()
  except:
   FbEVcUzgwsBvqpXGkrHyPJWijSACLN
 def play_VIDEO(FbEVcUzgwsBvqpXGkrHyPJWijSACeh,FbEVcUzgwsBvqpXGkrHyPJWijSACtK):
  FbEVcUzgwsBvqpXGkrHyPJWijSACat =FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('mediacode')
  FbEVcUzgwsBvqpXGkrHyPJWijSACto =FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('stype')
  FbEVcUzgwsBvqpXGkrHyPJWijSACaI =FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('pvrmode')
  FbEVcUzgwsBvqpXGkrHyPJWijSACaY=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.get_selQuality(FbEVcUzgwsBvqpXGkrHyPJWijSACto)
  FbEVcUzgwsBvqpXGkrHyPJWijSACeh.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(FbEVcUzgwsBvqpXGkrHyPJWijSACat,FbEVcUzgwsBvqpXGkrHyPJWijSACLx(FbEVcUzgwsBvqpXGkrHyPJWijSACaY),FbEVcUzgwsBvqpXGkrHyPJWijSACto,FbEVcUzgwsBvqpXGkrHyPJWijSACaI))
  FbEVcUzgwsBvqpXGkrHyPJWijSACaD=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.GetBroadURL(FbEVcUzgwsBvqpXGkrHyPJWijSACat,FbEVcUzgwsBvqpXGkrHyPJWijSACaY,FbEVcUzgwsBvqpXGkrHyPJWijSACto,FbEVcUzgwsBvqpXGkrHyPJWijSACaI,optUHD=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.get_settings_uhd())
  FbEVcUzgwsBvqpXGkrHyPJWijSACeh.addon_log('qt, stype, url : %s - %s - %s'%(FbEVcUzgwsBvqpXGkrHyPJWijSACLx(FbEVcUzgwsBvqpXGkrHyPJWijSACaY),FbEVcUzgwsBvqpXGkrHyPJWijSACto,FbEVcUzgwsBvqpXGkrHyPJWijSACaD['streaming_url']))
  if FbEVcUzgwsBvqpXGkrHyPJWijSACaD['streaming_url']=='':
   if FbEVcUzgwsBvqpXGkrHyPJWijSACaD['error_msg']=='':
    FbEVcUzgwsBvqpXGkrHyPJWijSACeh.addon_noti(__language__(30908).encode('utf8'))
   else:
    FbEVcUzgwsBvqpXGkrHyPJWijSACeh.addon_noti(FbEVcUzgwsBvqpXGkrHyPJWijSACaD['error_msg'].encode('utf8'))
   return
  if FbEVcUzgwsBvqpXGkrHyPJWijSACaD['qt_stream']=='stream70':
   FbEVcUzgwsBvqpXGkrHyPJWijSACaQ={'user-agent':FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.USER_AGENT_ATV}
  else:
   FbEVcUzgwsBvqpXGkrHyPJWijSACaQ={'user-agent':FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.USER_AGENT}
  FbEVcUzgwsBvqpXGkrHyPJWijSACaL=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.makeDefaultCookies() 
  if FbEVcUzgwsBvqpXGkrHyPJWijSACaD['watermark'] !='':
   FbEVcUzgwsBvqpXGkrHyPJWijSACaQ['x-tving-param1']=FbEVcUzgwsBvqpXGkrHyPJWijSACaD['watermarkKey']
   FbEVcUzgwsBvqpXGkrHyPJWijSACaQ['x-tving-param2']=FbEVcUzgwsBvqpXGkrHyPJWijSACaD['watermark'] 
  if FbEVcUzgwsBvqpXGkrHyPJWijSACaD['drm_server_url'] !='':
   FbEVcUzgwsBvqpXGkrHyPJWijSACaQ[FbEVcUzgwsBvqpXGkrHyPJWijSACaD['drm_header_key']]=FbEVcUzgwsBvqpXGkrHyPJWijSACaD['drm_header_value']
  FbEVcUzgwsBvqpXGkrHyPJWijSACaM =FbEVcUzgwsBvqpXGkrHyPJWijSACLI
  FbEVcUzgwsBvqpXGkrHyPJWijSACah =FbEVcUzgwsBvqpXGkrHyPJWijSACaD['streaming_url'].find('Policy=')
  if FbEVcUzgwsBvqpXGkrHyPJWijSACah!=-1:
   FbEVcUzgwsBvqpXGkrHyPJWijSACax =FbEVcUzgwsBvqpXGkrHyPJWijSACaD['streaming_url'].split('?')[0]
   FbEVcUzgwsBvqpXGkrHyPJWijSACal=FbEVcUzgwsBvqpXGkrHyPJWijSACLa(urllib.parse.parse_qsl(urllib.parse.urlsplit(FbEVcUzgwsBvqpXGkrHyPJWijSACaD['streaming_url']).query))
   FbEVcUzgwsBvqpXGkrHyPJWijSACaL['CloudFront-Policy'] =FbEVcUzgwsBvqpXGkrHyPJWijSACal['Policy'] 
   FbEVcUzgwsBvqpXGkrHyPJWijSACaL['CloudFront-Signature'] =FbEVcUzgwsBvqpXGkrHyPJWijSACal['Signature'] 
   FbEVcUzgwsBvqpXGkrHyPJWijSACaL['CloudFront-Key-Pair-Id']=FbEVcUzgwsBvqpXGkrHyPJWijSACal['Key-Pair-Id'] 
   FbEVcUzgwsBvqpXGkrHyPJWijSACao=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.make_stream_header(FbEVcUzgwsBvqpXGkrHyPJWijSACaQ,FbEVcUzgwsBvqpXGkrHyPJWijSACaL)
   if 'quickvod-mcdn.tving.com' in FbEVcUzgwsBvqpXGkrHyPJWijSACax:
    FbEVcUzgwsBvqpXGkrHyPJWijSACaM=FbEVcUzgwsBvqpXGkrHyPJWijSACLY
    FbEVcUzgwsBvqpXGkrHyPJWijSACaR =FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    FbEVcUzgwsBvqpXGkrHyPJWijSACau=FbEVcUzgwsBvqpXGkrHyPJWijSACaR.strftime('%Y-%m-%d-%H:%M:%S')
    if FbEVcUzgwsBvqpXGkrHyPJWijSACLt(FbEVcUzgwsBvqpXGkrHyPJWijSACau.replace('-','').replace(':',''))<FbEVcUzgwsBvqpXGkrHyPJWijSACLt(FbEVcUzgwsBvqpXGkrHyPJWijSACal['end'].replace('-','').replace(':','')):
     FbEVcUzgwsBvqpXGkrHyPJWijSACal['end']=FbEVcUzgwsBvqpXGkrHyPJWijSACau
     FbEVcUzgwsBvqpXGkrHyPJWijSACeh.addon_noti(__language__(30915).encode('utf8'))
    FbEVcUzgwsBvqpXGkrHyPJWijSACax ='%s?%s'%(FbEVcUzgwsBvqpXGkrHyPJWijSACax,urllib.parse.urlencode(FbEVcUzgwsBvqpXGkrHyPJWijSACal,doseq=FbEVcUzgwsBvqpXGkrHyPJWijSACLY))
    FbEVcUzgwsBvqpXGkrHyPJWijSACaK='{}|{}'.format(FbEVcUzgwsBvqpXGkrHyPJWijSACax,FbEVcUzgwsBvqpXGkrHyPJWijSACao)
   else:
    FbEVcUzgwsBvqpXGkrHyPJWijSACaK='{}|{}'.format(FbEVcUzgwsBvqpXGkrHyPJWijSACaD['streaming_url'],FbEVcUzgwsBvqpXGkrHyPJWijSACao)
  else:
   FbEVcUzgwsBvqpXGkrHyPJWijSACao=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.make_stream_header(FbEVcUzgwsBvqpXGkrHyPJWijSACaQ,FbEVcUzgwsBvqpXGkrHyPJWijSACaL)
   FbEVcUzgwsBvqpXGkrHyPJWijSACaK='{}|{}'.format(FbEVcUzgwsBvqpXGkrHyPJWijSACaD['streaming_url'],FbEVcUzgwsBvqpXGkrHyPJWijSACao)
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.addon_log('if tmp_pos == -1')
  FbEVcUzgwsBvqpXGkrHyPJWijSACNt,FbEVcUzgwsBvqpXGkrHyPJWijSACNI=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.get_settings_proxyport()
  FbEVcUzgwsBvqpXGkrHyPJWijSACNe=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.get_settings_playback()
  if(FbEVcUzgwsBvqpXGkrHyPJWijSACNt and FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('mode')in['VOD','MOVIE']and FbEVcUzgwsBvqpXGkrHyPJWijSACaM==FbEVcUzgwsBvqpXGkrHyPJWijSACLI and(FbEVcUzgwsBvqpXGkrHyPJWijSACaD['drm_server_url']!='' or(FbEVcUzgwsBvqpXGkrHyPJWijSACaD['url_filename'].split('.')[1]=='mpd')or(FbEVcUzgwsBvqpXGkrHyPJWijSACaD['url_filename'].split('.')[1]!='mpd' and FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.KodiVersion>=21 and FbEVcUzgwsBvqpXGkrHyPJWijSACaD['qt_stream']=='stream70'))):
   if FbEVcUzgwsBvqpXGkrHyPJWijSACaD['url_filename'].split('.')[1]=='mpd':
    FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.Tving_Parse_mpd(FbEVcUzgwsBvqpXGkrHyPJWijSACaD['streaming_url'],FbEVcUzgwsBvqpXGkrHyPJWijSACaD['watermarkKey'],FbEVcUzgwsBvqpXGkrHyPJWijSACaD['watermark'])
   else:
    FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.Tving_Parse_m3u8(FbEVcUzgwsBvqpXGkrHyPJWijSACaD['streaming_url'])
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.addon_log('xxx '+FbEVcUzgwsBvqpXGkrHyPJWijSACaD['streaming_url'])
   FbEVcUzgwsBvqpXGkrHyPJWijSACam={'addon':'tvingm','playOption':FbEVcUzgwsBvqpXGkrHyPJWijSACNe,'url_filename':FbEVcUzgwsBvqpXGkrHyPJWijSACaD['url_filename'],}
   FbEVcUzgwsBvqpXGkrHyPJWijSACam=json.dumps(FbEVcUzgwsBvqpXGkrHyPJWijSACam,separators=(',',':'))
   FbEVcUzgwsBvqpXGkrHyPJWijSACam=base64.standard_b64encode(FbEVcUzgwsBvqpXGkrHyPJWijSACam.encode()).decode('utf-8')
   FbEVcUzgwsBvqpXGkrHyPJWijSACaK ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(FbEVcUzgwsBvqpXGkrHyPJWijSACNI,FbEVcUzgwsBvqpXGkrHyPJWijSACaK,FbEVcUzgwsBvqpXGkrHyPJWijSACam)
   FbEVcUzgwsBvqpXGkrHyPJWijSACaQ['proxy-mini']=FbEVcUzgwsBvqpXGkrHyPJWijSACam 
  FbEVcUzgwsBvqpXGkrHyPJWijSACeh.addon_log('surl(2) : {}'.format(FbEVcUzgwsBvqpXGkrHyPJWijSACaK))
  FbEVcUzgwsBvqpXGkrHyPJWijSACeh.addon_log('drm     : {}'.format(FbEVcUzgwsBvqpXGkrHyPJWijSACaD['drm_server_url']))
  FbEVcUzgwsBvqpXGkrHyPJWijSACao=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.make_stream_header(FbEVcUzgwsBvqpXGkrHyPJWijSACaQ,FbEVcUzgwsBvqpXGkrHyPJWijSACaL)
  FbEVcUzgwsBvqpXGkrHyPJWijSACad=xbmcgui.ListItem(path=FbEVcUzgwsBvqpXGkrHyPJWijSACaK)
  if FbEVcUzgwsBvqpXGkrHyPJWijSACaD['drm_server_url']!='':
   FbEVcUzgwsBvqpXGkrHyPJWijSACaO=FbEVcUzgwsBvqpXGkrHyPJWijSACaD['drm_server_url']
   FbEVcUzgwsBvqpXGkrHyPJWijSACan ='https://license-global.pallycon.com/ri/licenseManager.do' 
   FbEVcUzgwsBvqpXGkrHyPJWijSACaT ='mpd'
   FbEVcUzgwsBvqpXGkrHyPJWijSACaf ='com.widevine.alpha'
   inputstreamhelper.Helper('mpd',drm='com.widevine.alpha').check_inputstream()
   FbEVcUzgwsBvqpXGkrHyPJWijSACQN={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.USER_AGENT,FbEVcUzgwsBvqpXGkrHyPJWijSACaD['drm_header_key']:FbEVcUzgwsBvqpXGkrHyPJWijSACaD['drm_header_value'],}
   FbEVcUzgwsBvqpXGkrHyPJWijSACQt=FbEVcUzgwsBvqpXGkrHyPJWijSACan+'|'+urllib.parse.urlencode(FbEVcUzgwsBvqpXGkrHyPJWijSACQN)+'|R{SSM}|'
   FbEVcUzgwsBvqpXGkrHyPJWijSACad.setProperty('inputstream','inputstream.adaptive')
   if FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.KodiVersion<=20:
    FbEVcUzgwsBvqpXGkrHyPJWijSACad.setProperty('inputstream.adaptive.manifest_type',FbEVcUzgwsBvqpXGkrHyPJWijSACaT)
   FbEVcUzgwsBvqpXGkrHyPJWijSACad.setProperty('inputstream.adaptive.license_type',FbEVcUzgwsBvqpXGkrHyPJWijSACaf)
   FbEVcUzgwsBvqpXGkrHyPJWijSACad.setProperty('inputstream.adaptive.license_key',FbEVcUzgwsBvqpXGkrHyPJWijSACQt)
   FbEVcUzgwsBvqpXGkrHyPJWijSACad.setProperty('inputstream.adaptive.stream_headers',FbEVcUzgwsBvqpXGkrHyPJWijSACao)
   FbEVcUzgwsBvqpXGkrHyPJWijSACad.setProperty('inputstream.adaptive.manifest_headers',FbEVcUzgwsBvqpXGkrHyPJWijSACao)
  elif FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('mode')in['VOD','MOVIE']:
   FbEVcUzgwsBvqpXGkrHyPJWijSACad.setContentLookup(FbEVcUzgwsBvqpXGkrHyPJWijSACLI)
   FbEVcUzgwsBvqpXGkrHyPJWijSACad.setMimeType('application/x-mpegURL')
   FbEVcUzgwsBvqpXGkrHyPJWijSACad.setProperty('inputstream','inputstream.adaptive')
   if FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.KodiVersion<=20:
    FbEVcUzgwsBvqpXGkrHyPJWijSACad.setProperty('inputstream.adaptive.manifest_type','hls')
   FbEVcUzgwsBvqpXGkrHyPJWijSACad.setProperty('inputstream.adaptive.stream_headers',FbEVcUzgwsBvqpXGkrHyPJWijSACao)
   FbEVcUzgwsBvqpXGkrHyPJWijSACad.setProperty('inputstream.adaptive.manifest_headers',FbEVcUzgwsBvqpXGkrHyPJWijSACao)
  elif FbEVcUzgwsBvqpXGkrHyPJWijSACaM==FbEVcUzgwsBvqpXGkrHyPJWijSACLY:
   FbEVcUzgwsBvqpXGkrHyPJWijSACad.setContentLookup(FbEVcUzgwsBvqpXGkrHyPJWijSACLI)
   FbEVcUzgwsBvqpXGkrHyPJWijSACad.setMimeType('application/x-mpegURL')
   FbEVcUzgwsBvqpXGkrHyPJWijSACad.setProperty('inputstream','inputstream.ffmpegdirect')
   FbEVcUzgwsBvqpXGkrHyPJWijSACad.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   FbEVcUzgwsBvqpXGkrHyPJWijSACad.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   FbEVcUzgwsBvqpXGkrHyPJWijSACad.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   FbEVcUzgwsBvqpXGkrHyPJWijSACad.setProperty('ResumeTime','0')
   FbEVcUzgwsBvqpXGkrHyPJWijSACad.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(FbEVcUzgwsBvqpXGkrHyPJWijSACeh._addon_handle,FbEVcUzgwsBvqpXGkrHyPJWijSACLY,FbEVcUzgwsBvqpXGkrHyPJWijSACad)
  try:
   if FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('mode')in['VOD','MOVIE']and FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('title'):
    FbEVcUzgwsBvqpXGkrHyPJWijSACNf={'code':FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('programcode')if FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('mode')=='VOD' else FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('mediacode'),'img':FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('thumbnail'),'title':FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('title'),'videoid':FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('mediacode')}
    FbEVcUzgwsBvqpXGkrHyPJWijSACeh.Save_Watched_List(FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('stype'),FbEVcUzgwsBvqpXGkrHyPJWijSACNf)
  except:
   FbEVcUzgwsBvqpXGkrHyPJWijSACLN
 def logout(FbEVcUzgwsBvqpXGkrHyPJWijSACeh):
  FbEVcUzgwsBvqpXGkrHyPJWijSACeu=xbmcgui.Dialog()
  FbEVcUzgwsBvqpXGkrHyPJWijSACtM=FbEVcUzgwsBvqpXGkrHyPJWijSACeu.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if FbEVcUzgwsBvqpXGkrHyPJWijSACtM==FbEVcUzgwsBvqpXGkrHyPJWijSACLI:sys.exit()
  FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.Init_TV_Total()
  if os.path.isfile(FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.TV_COOKIE_FILENAME):os.remove(FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.TV_COOKIE_FILENAME)
  if os.path.isfile(FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.TV_TOKEN_FILENAME): os.remove(FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.TV_TOKEN_FILENAME)
  FbEVcUzgwsBvqpXGkrHyPJWijSACeh.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(FbEVcUzgwsBvqpXGkrHyPJWijSACeh):
  FbEVcUzgwsBvqpXGkrHyPJWijSACQI =FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.Get_Now_Datetime()
  FbEVcUzgwsBvqpXGkrHyPJWijSACQY=FbEVcUzgwsBvqpXGkrHyPJWijSACQI+datetime.timedelta(days=30) 
  (FbEVcUzgwsBvqpXGkrHyPJWijSACtD,FbEVcUzgwsBvqpXGkrHyPJWijSACta,FbEVcUzgwsBvqpXGkrHyPJWijSACtQ,FbEVcUzgwsBvqpXGkrHyPJWijSACtL)=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.get_settings_account()
  FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.Save_session_acount(FbEVcUzgwsBvqpXGkrHyPJWijSACtD,FbEVcUzgwsBvqpXGkrHyPJWijSACta,FbEVcUzgwsBvqpXGkrHyPJWijSACtQ,FbEVcUzgwsBvqpXGkrHyPJWijSACtL)
  FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.TV['account']['token_limit']=FbEVcUzgwsBvqpXGkrHyPJWijSACQY.strftime('%Y%m%d')
  FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.JsonFile_Save(FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.TV_COOKIE_FILENAME,FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.TV)
 def cookiefile_check(FbEVcUzgwsBvqpXGkrHyPJWijSACeh):
  FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.TV=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.JsonFile_Load(FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.TV_COOKIE_FILENAME)
  if FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.TV=={}:
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.Init_TV_Total()
   return FbEVcUzgwsBvqpXGkrHyPJWijSACLI
  (FbEVcUzgwsBvqpXGkrHyPJWijSACQD,FbEVcUzgwsBvqpXGkrHyPJWijSACQa,FbEVcUzgwsBvqpXGkrHyPJWijSACQL,FbEVcUzgwsBvqpXGkrHyPJWijSACQM)=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.get_settings_account()
  (FbEVcUzgwsBvqpXGkrHyPJWijSACQh,FbEVcUzgwsBvqpXGkrHyPJWijSACQx,FbEVcUzgwsBvqpXGkrHyPJWijSACQl,FbEVcUzgwsBvqpXGkrHyPJWijSACQo)=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.Load_session_acount()
  if(FbEVcUzgwsBvqpXGkrHyPJWijSACQD!=FbEVcUzgwsBvqpXGkrHyPJWijSACQh or FbEVcUzgwsBvqpXGkrHyPJWijSACQa!=FbEVcUzgwsBvqpXGkrHyPJWijSACQx or FbEVcUzgwsBvqpXGkrHyPJWijSACQL!=FbEVcUzgwsBvqpXGkrHyPJWijSACQl or FbEVcUzgwsBvqpXGkrHyPJWijSACQM!=FbEVcUzgwsBvqpXGkrHyPJWijSACQo)and FbEVcUzgwsBvqpXGkrHyPJWijSACQh!='xxxxx':
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.Init_TV_Total()
   return FbEVcUzgwsBvqpXGkrHyPJWijSACLI
  if FbEVcUzgwsBvqpXGkrHyPJWijSACLt(FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>FbEVcUzgwsBvqpXGkrHyPJWijSACLt(FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.TV['account']['token_limit']):
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.Init_TV_Total()
   return FbEVcUzgwsBvqpXGkrHyPJWijSACLI
  return FbEVcUzgwsBvqpXGkrHyPJWijSACLY
 def tokenfile_check(FbEVcUzgwsBvqpXGkrHyPJWijSACeh):
  FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.TV_TOKEN=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.JsonFile_Load(FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.TV_TOKEN_FILENAME)
  if FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.TV_TOKEN=={}:
   return FbEVcUzgwsBvqpXGkrHyPJWijSACLI
  if FbEVcUzgwsBvqpXGkrHyPJWijSACLt(FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>FbEVcUzgwsBvqpXGkrHyPJWijSACLt(FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.TV_TOKEN['token_date']):
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.TV_TOKEN={}
   return FbEVcUzgwsBvqpXGkrHyPJWijSACLI
  return FbEVcUzgwsBvqpXGkrHyPJWijSACLY
 def get_reToken(FbEVcUzgwsBvqpXGkrHyPJWijSACeh):
  if FbEVcUzgwsBvqpXGkrHyPJWijSACeh.tokenfile_check()==FbEVcUzgwsBvqpXGkrHyPJWijSACLI:
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.Get_AccessToken()
 def dp_Global_Search(FbEVcUzgwsBvqpXGkrHyPJWijSACeh,FbEVcUzgwsBvqpXGkrHyPJWijSACtK):
  FbEVcUzgwsBvqpXGkrHyPJWijSACYm=FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('mode')
  if FbEVcUzgwsBvqpXGkrHyPJWijSACYm=='TOTAL_SEARCH':
   FbEVcUzgwsBvqpXGkrHyPJWijSACQR='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   FbEVcUzgwsBvqpXGkrHyPJWijSACQR='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(FbEVcUzgwsBvqpXGkrHyPJWijSACQR)
 def dp_Bookmark_Menu(FbEVcUzgwsBvqpXGkrHyPJWijSACeh,FbEVcUzgwsBvqpXGkrHyPJWijSACtK):
  FbEVcUzgwsBvqpXGkrHyPJWijSACQR='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(FbEVcUzgwsBvqpXGkrHyPJWijSACQR)
 def dp_Apple_Group(FbEVcUzgwsBvqpXGkrHyPJWijSACeh,FbEVcUzgwsBvqpXGkrHyPJWijSACtK):
  FbEVcUzgwsBvqpXGkrHyPJWijSACQu=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.Get_AppleGroup_List()
  for FbEVcUzgwsBvqpXGkrHyPJWijSACQK in FbEVcUzgwsBvqpXGkrHyPJWijSACQu:
   FbEVcUzgwsBvqpXGkrHyPJWijSACQm =FbEVcUzgwsBvqpXGkrHyPJWijSACQK.get('bandName')
   FbEVcUzgwsBvqpXGkrHyPJWijSACQd =FbEVcUzgwsBvqpXGkrHyPJWijSACQK.get('bandKey')
   FbEVcUzgwsBvqpXGkrHyPJWijSACIL={'mediatype':'tvshow','title':FbEVcUzgwsBvqpXGkrHyPJWijSACQm,'plot':'%s'%(FbEVcUzgwsBvqpXGkrHyPJWijSACQd),}
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf={'mode':'BAND_VODLIST','bandKey':FbEVcUzgwsBvqpXGkrHyPJWijSACQd,'page':'1','nextApiUrl':'-',}
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.add_dir(FbEVcUzgwsBvqpXGkrHyPJWijSACQm,sublabel=FbEVcUzgwsBvqpXGkrHyPJWijSACLN,img='',infoLabels=FbEVcUzgwsBvqpXGkrHyPJWijSACIL,isFolder=FbEVcUzgwsBvqpXGkrHyPJWijSACLY,params=FbEVcUzgwsBvqpXGkrHyPJWijSACNf)
  if FbEVcUzgwsBvqpXGkrHyPJWijSACLh(FbEVcUzgwsBvqpXGkrHyPJWijSACQu)>0:xbmcplugin.endOfDirectory(FbEVcUzgwsBvqpXGkrHyPJWijSACeh._addon_handle,cacheToDisc=FbEVcUzgwsBvqpXGkrHyPJWijSACLI)
 def dp_Band_VodList(FbEVcUzgwsBvqpXGkrHyPJWijSACeh,FbEVcUzgwsBvqpXGkrHyPJWijSACtK):
  FbEVcUzgwsBvqpXGkrHyPJWijSACQd =FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('bandKey') 
  FbEVcUzgwsBvqpXGkrHyPJWijSACQO =FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('bandGroup') 
  FbEVcUzgwsBvqpXGkrHyPJWijSACQn =FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('nextApiUrl')
  FbEVcUzgwsBvqpXGkrHyPJWijSACQT =''
  FbEVcUzgwsBvqpXGkrHyPJWijSACtm =FbEVcUzgwsBvqpXGkrHyPJWijSACLt(FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('page'))
  FbEVcUzgwsBvqpXGkrHyPJWijSACeh.addon_log('bandKey    : {}'.format(FbEVcUzgwsBvqpXGkrHyPJWijSACQd))
  FbEVcUzgwsBvqpXGkrHyPJWijSACeh.addon_log('bandGroup  : {}'.format(FbEVcUzgwsBvqpXGkrHyPJWijSACQO))
  FbEVcUzgwsBvqpXGkrHyPJWijSACeh.addon_log('nextApiUrl : {}'.format(FbEVcUzgwsBvqpXGkrHyPJWijSACQn))
  if FbEVcUzgwsBvqpXGkrHyPJWijSACQO=='TVING_APPLE_HOUR':
   FbEVcUzgwsBvqpXGkrHyPJWijSACIl,FbEVcUzgwsBvqpXGkrHyPJWijSACQn=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.Get_Apple_NowList()
  else:
   if FbEVcUzgwsBvqpXGkrHyPJWijSACQO not in['',FbEVcUzgwsBvqpXGkrHyPJWijSACLN]:
    FbEVcUzgwsBvqpXGkrHyPJWijSACQd=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.Get_bandCode_GroupCode(FbEVcUzgwsBvqpXGkrHyPJWijSACQO)
    FbEVcUzgwsBvqpXGkrHyPJWijSACeh.addon_log('new bandKey    : {}'.format(FbEVcUzgwsBvqpXGkrHyPJWijSACQd))
   FbEVcUzgwsBvqpXGkrHyPJWijSACIl,FbEVcUzgwsBvqpXGkrHyPJWijSACQn=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.Get_Band_VodList(FbEVcUzgwsBvqpXGkrHyPJWijSACQd,FbEVcUzgwsBvqpXGkrHyPJWijSACQn)
  for FbEVcUzgwsBvqpXGkrHyPJWijSACIo in FbEVcUzgwsBvqpXGkrHyPJWijSACIl:
   FbEVcUzgwsBvqpXGkrHyPJWijSACNo =FbEVcUzgwsBvqpXGkrHyPJWijSACIo.get('title')
   FbEVcUzgwsBvqpXGkrHyPJWijSACtT =FbEVcUzgwsBvqpXGkrHyPJWijSACIo.get('thumbnail')
   FbEVcUzgwsBvqpXGkrHyPJWijSACYh =FbEVcUzgwsBvqpXGkrHyPJWijSACIo.get('program')
   FbEVcUzgwsBvqpXGkrHyPJWijSACIL={'mediatype':'tvshow' if not FbEVcUzgwsBvqpXGkrHyPJWijSACYh.startswith('M')else 'movie','title':FbEVcUzgwsBvqpXGkrHyPJWijSACNo,'plot':FbEVcUzgwsBvqpXGkrHyPJWijSACNo+'\n'+'tvshow' if not FbEVcUzgwsBvqpXGkrHyPJWijSACYh.startswith('M')else 'movie',}
   if not FbEVcUzgwsBvqpXGkrHyPJWijSACYh.startswith('M'):
    FbEVcUzgwsBvqpXGkrHyPJWijSACNf={'mode':'EPISODE','programcode':FbEVcUzgwsBvqpXGkrHyPJWijSACYh,'page':'1',}
    FbEVcUzgwsBvqpXGkrHyPJWijSACte=FbEVcUzgwsBvqpXGkrHyPJWijSACLY
   else:
    FbEVcUzgwsBvqpXGkrHyPJWijSACNf={'mode':'MOVIE','mediacode':FbEVcUzgwsBvqpXGkrHyPJWijSACYh,'stype':'movie','title':FbEVcUzgwsBvqpXGkrHyPJWijSACNo,'thumbnail':FbEVcUzgwsBvqpXGkrHyPJWijSACtT,}
    FbEVcUzgwsBvqpXGkrHyPJWijSACte=FbEVcUzgwsBvqpXGkrHyPJWijSACLI
   if FbEVcUzgwsBvqpXGkrHyPJWijSACeh.get_settings_makebookmark():
    FbEVcUzgwsBvqpXGkrHyPJWijSACIu={'videoid':FbEVcUzgwsBvqpXGkrHyPJWijSACYh,'vidtype':'tvshow','vtitle':FbEVcUzgwsBvqpXGkrHyPJWijSACNo,'vsubtitle':FbEVcUzgwsBvqpXGkrHyPJWijSACQT,}
    FbEVcUzgwsBvqpXGkrHyPJWijSACIK=json.dumps(FbEVcUzgwsBvqpXGkrHyPJWijSACIu)
    FbEVcUzgwsBvqpXGkrHyPJWijSACIK=urllib.parse.quote(FbEVcUzgwsBvqpXGkrHyPJWijSACIK)
    FbEVcUzgwsBvqpXGkrHyPJWijSACIm='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(FbEVcUzgwsBvqpXGkrHyPJWijSACIK)
    FbEVcUzgwsBvqpXGkrHyPJWijSACId=[('(통합) 찜 영상에 추가',FbEVcUzgwsBvqpXGkrHyPJWijSACIm)]
   else:
    FbEVcUzgwsBvqpXGkrHyPJWijSACId=FbEVcUzgwsBvqpXGkrHyPJWijSACLN
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.add_dir(FbEVcUzgwsBvqpXGkrHyPJWijSACNo,sublabel=FbEVcUzgwsBvqpXGkrHyPJWijSACQT,img=FbEVcUzgwsBvqpXGkrHyPJWijSACtT,infoLabels=FbEVcUzgwsBvqpXGkrHyPJWijSACIL,isFolder=FbEVcUzgwsBvqpXGkrHyPJWijSACte,params=FbEVcUzgwsBvqpXGkrHyPJWijSACNf,ContextMenu=FbEVcUzgwsBvqpXGkrHyPJWijSACId)
  if FbEVcUzgwsBvqpXGkrHyPJWijSACQn not in[FbEVcUzgwsBvqpXGkrHyPJWijSACLN,'','-']:
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf['mode'] ='BAND_VODLIST' 
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf['bandKey'] =FbEVcUzgwsBvqpXGkrHyPJWijSACQd
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf['nextApiUrl']=FbEVcUzgwsBvqpXGkrHyPJWijSACQn
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf['page'] =FbEVcUzgwsBvqpXGkrHyPJWijSACLx(FbEVcUzgwsBvqpXGkrHyPJWijSACtm+1)
   FbEVcUzgwsBvqpXGkrHyPJWijSACNo='[B]%s >>[/B]'%'다음 페이지'
   FbEVcUzgwsBvqpXGkrHyPJWijSACIM=FbEVcUzgwsBvqpXGkrHyPJWijSACLx(FbEVcUzgwsBvqpXGkrHyPJWijSACtm+1)
   FbEVcUzgwsBvqpXGkrHyPJWijSACNT=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.add_dir(FbEVcUzgwsBvqpXGkrHyPJWijSACNo,sublabel=FbEVcUzgwsBvqpXGkrHyPJWijSACIM,img=FbEVcUzgwsBvqpXGkrHyPJWijSACNT,infoLabels=FbEVcUzgwsBvqpXGkrHyPJWijSACLN,isFolder=FbEVcUzgwsBvqpXGkrHyPJWijSACLY,params=FbEVcUzgwsBvqpXGkrHyPJWijSACNf)
  xbmcplugin.setContent(FbEVcUzgwsBvqpXGkrHyPJWijSACeh._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(FbEVcUzgwsBvqpXGkrHyPJWijSACeh._addon_handle,cacheToDisc=FbEVcUzgwsBvqpXGkrHyPJWijSACLI)
 def dp_Gn2_Program(FbEVcUzgwsBvqpXGkrHyPJWijSACeh,FbEVcUzgwsBvqpXGkrHyPJWijSACtK):
  FbEVcUzgwsBvqpXGkrHyPJWijSACIh =FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('genre')
  FbEVcUzgwsBvqpXGkrHyPJWijSACto =FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('stype')
  FbEVcUzgwsBvqpXGkrHyPJWijSACNx =FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('orderby')
  FbEVcUzgwsBvqpXGkrHyPJWijSACtm=FbEVcUzgwsBvqpXGkrHyPJWijSACLt(FbEVcUzgwsBvqpXGkrHyPJWijSACtK.get('page'))
  FbEVcUzgwsBvqpXGkrHyPJWijSACIl,FbEVcUzgwsBvqpXGkrHyPJWijSACtO=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.Gn2_Program_List(FbEVcUzgwsBvqpXGkrHyPJWijSACIh,FbEVcUzgwsBvqpXGkrHyPJWijSACNx,FbEVcUzgwsBvqpXGkrHyPJWijSACtm)
  for FbEVcUzgwsBvqpXGkrHyPJWijSACQf in FbEVcUzgwsBvqpXGkrHyPJWijSACIl:
   FbEVcUzgwsBvqpXGkrHyPJWijSACNo =FbEVcUzgwsBvqpXGkrHyPJWijSACQf.get('title')
   FbEVcUzgwsBvqpXGkrHyPJWijSACtT =FbEVcUzgwsBvqpXGkrHyPJWijSACQf.get('thumbnail')
   FbEVcUzgwsBvqpXGkrHyPJWijSACIL={'mediatype':FbEVcUzgwsBvqpXGkrHyPJWijSACto,'title':FbEVcUzgwsBvqpXGkrHyPJWijSACNo,'plot':FbEVcUzgwsBvqpXGkrHyPJWijSACNo,}
   if FbEVcUzgwsBvqpXGkrHyPJWijSACto=='movie':
    FbEVcUzgwsBvqpXGkrHyPJWijSACNf={'mode':'MOVIE','mediacode':FbEVcUzgwsBvqpXGkrHyPJWijSACQf.get('code'),'stype':FbEVcUzgwsBvqpXGkrHyPJWijSACto,'title':FbEVcUzgwsBvqpXGkrHyPJWijSACNo,'thumbnail':FbEVcUzgwsBvqpXGkrHyPJWijSACtT,}
    FbEVcUzgwsBvqpXGkrHyPJWijSACte=FbEVcUzgwsBvqpXGkrHyPJWijSACLI
   else:
    FbEVcUzgwsBvqpXGkrHyPJWijSACNf={'mode':'EPISODE','programcode':FbEVcUzgwsBvqpXGkrHyPJWijSACQf.get('code'),'stype':FbEVcUzgwsBvqpXGkrHyPJWijSACto,'title':FbEVcUzgwsBvqpXGkrHyPJWijSACNo,'thumbnail':FbEVcUzgwsBvqpXGkrHyPJWijSACtT,'page':'1',}
    FbEVcUzgwsBvqpXGkrHyPJWijSACte=FbEVcUzgwsBvqpXGkrHyPJWijSACLY
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.add_dir(FbEVcUzgwsBvqpXGkrHyPJWijSACNo,sublabel='',img=FbEVcUzgwsBvqpXGkrHyPJWijSACtT,infoLabels=FbEVcUzgwsBvqpXGkrHyPJWijSACIL,isFolder=FbEVcUzgwsBvqpXGkrHyPJWijSACte,params=FbEVcUzgwsBvqpXGkrHyPJWijSACNf,ContextMenu=FbEVcUzgwsBvqpXGkrHyPJWijSACLN)
  if FbEVcUzgwsBvqpXGkrHyPJWijSACtO:
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf={}
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf['mode'] ='GN2_LIST' 
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf['orderby']=FbEVcUzgwsBvqpXGkrHyPJWijSACNx
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf['stype'] =FbEVcUzgwsBvqpXGkrHyPJWijSACto
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf['genre'] =FbEVcUzgwsBvqpXGkrHyPJWijSACIh
   FbEVcUzgwsBvqpXGkrHyPJWijSACNf['page'] =FbEVcUzgwsBvqpXGkrHyPJWijSACLx(FbEVcUzgwsBvqpXGkrHyPJWijSACtm+1)
   FbEVcUzgwsBvqpXGkrHyPJWijSACNo='[B]%s >>[/B]'%'다음 페이지'
   FbEVcUzgwsBvqpXGkrHyPJWijSACIM=FbEVcUzgwsBvqpXGkrHyPJWijSACLx(FbEVcUzgwsBvqpXGkrHyPJWijSACtm+1)
   FbEVcUzgwsBvqpXGkrHyPJWijSACNT=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.add_dir(FbEVcUzgwsBvqpXGkrHyPJWijSACNo,sublabel=FbEVcUzgwsBvqpXGkrHyPJWijSACIM,img=FbEVcUzgwsBvqpXGkrHyPJWijSACNT,infoLabels=FbEVcUzgwsBvqpXGkrHyPJWijSACLN,isFolder=FbEVcUzgwsBvqpXGkrHyPJWijSACLY,params=FbEVcUzgwsBvqpXGkrHyPJWijSACNf)
  if FbEVcUzgwsBvqpXGkrHyPJWijSACto=='movie':
   xbmcplugin.setContent(FbEVcUzgwsBvqpXGkrHyPJWijSACeh._addon_handle,'movies')
  else:
   xbmcplugin.setContent(FbEVcUzgwsBvqpXGkrHyPJWijSACeh._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(FbEVcUzgwsBvqpXGkrHyPJWijSACeh._addon_handle,cacheToDisc=FbEVcUzgwsBvqpXGkrHyPJWijSACLI)
 def tving_main(FbEVcUzgwsBvqpXGkrHyPJWijSACeh):
  FbEVcUzgwsBvqpXGkrHyPJWijSACeh.TvingObj.KodiVersion=FbEVcUzgwsBvqpXGkrHyPJWijSACLt(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  FbEVcUzgwsBvqpXGkrHyPJWijSACYm=FbEVcUzgwsBvqpXGkrHyPJWijSACeh.main_params.get('mode',FbEVcUzgwsBvqpXGkrHyPJWijSACLN)
  if FbEVcUzgwsBvqpXGkrHyPJWijSACYm=='LOGOUT':
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.logout()
   return
  FbEVcUzgwsBvqpXGkrHyPJWijSACeh.login_main()
  FbEVcUzgwsBvqpXGkrHyPJWijSACeh.get_reToken()
  if FbEVcUzgwsBvqpXGkrHyPJWijSACYm is FbEVcUzgwsBvqpXGkrHyPJWijSACLN:
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.dp_Main_List()
  elif FbEVcUzgwsBvqpXGkrHyPJWijSACYm in['LIVE_GROUP','DRAMA_GROUP','ENTER_GROUP','MOVIE_GROUP']:
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.dp_Title_Group(FbEVcUzgwsBvqpXGkrHyPJWijSACeh.main_params)
  elif FbEVcUzgwsBvqpXGkrHyPJWijSACYm=='CHANNEL':
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.dp_LiveChannel_List(FbEVcUzgwsBvqpXGkrHyPJWijSACeh.main_params)
  elif FbEVcUzgwsBvqpXGkrHyPJWijSACYm in['LIVE','VOD','MOVIE']:
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.play_VIDEO(FbEVcUzgwsBvqpXGkrHyPJWijSACeh.main_params)
  elif FbEVcUzgwsBvqpXGkrHyPJWijSACYm=='PROGRAM':
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.dp_Program_List(FbEVcUzgwsBvqpXGkrHyPJWijSACeh.main_params)
  elif FbEVcUzgwsBvqpXGkrHyPJWijSACYm=='EPISODE':
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.dp_Episode_List(FbEVcUzgwsBvqpXGkrHyPJWijSACeh.main_params)
  elif FbEVcUzgwsBvqpXGkrHyPJWijSACYm=='SEARCH_GROUP':
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.dp_Search_Group(FbEVcUzgwsBvqpXGkrHyPJWijSACeh.main_params)
  elif FbEVcUzgwsBvqpXGkrHyPJWijSACYm in['SEARCH','LOCAL_SEARCH']:
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.dp_Search_List(FbEVcUzgwsBvqpXGkrHyPJWijSACeh.main_params)
  elif FbEVcUzgwsBvqpXGkrHyPJWijSACYm=='WATCH':
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.dp_Watch_List(FbEVcUzgwsBvqpXGkrHyPJWijSACeh.main_params)
  elif FbEVcUzgwsBvqpXGkrHyPJWijSACYm in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.dp_History_Remove(FbEVcUzgwsBvqpXGkrHyPJWijSACeh.main_params)
  elif FbEVcUzgwsBvqpXGkrHyPJWijSACYm=='ORDER_BY':
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.dp_setEpOrderby(FbEVcUzgwsBvqpXGkrHyPJWijSACeh.main_params)
  elif FbEVcUzgwsBvqpXGkrHyPJWijSACYm=='SET_BOOKMARK':
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.dp_Set_Bookmark(FbEVcUzgwsBvqpXGkrHyPJWijSACeh.main_params)
  elif FbEVcUzgwsBvqpXGkrHyPJWijSACYm in['TOTAL_SEARCH','TOTAL_HISTORY']:
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.dp_Global_Search(FbEVcUzgwsBvqpXGkrHyPJWijSACeh.main_params)
  elif FbEVcUzgwsBvqpXGkrHyPJWijSACYm=='SEARCH_HISTORY':
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.dp_Search_History(FbEVcUzgwsBvqpXGkrHyPJWijSACeh.main_params)
  elif FbEVcUzgwsBvqpXGkrHyPJWijSACYm=='MENU_BOOKMARK':
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.dp_Bookmark_Menu(FbEVcUzgwsBvqpXGkrHyPJWijSACeh.main_params)
  elif FbEVcUzgwsBvqpXGkrHyPJWijSACYm=='APPLE_GROUP':
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.dp_Apple_Group(FbEVcUzgwsBvqpXGkrHyPJWijSACeh.main_params)
  elif FbEVcUzgwsBvqpXGkrHyPJWijSACYm=='BAND_VODLIST':
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.dp_Band_VodList(FbEVcUzgwsBvqpXGkrHyPJWijSACeh.main_params)
  elif FbEVcUzgwsBvqpXGkrHyPJWijSACYm=='GN2_LIST':
   FbEVcUzgwsBvqpXGkrHyPJWijSACeh.dp_Gn2_Program(FbEVcUzgwsBvqpXGkrHyPJWijSACeh.main_params)
  else:
   FbEVcUzgwsBvqpXGkrHyPJWijSACLN
# Created by pyminifier (https://github.com/liftoff/pyminifier)
