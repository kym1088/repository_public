__author__="NightRain"
xRifPJdSGAUnsNTzbamVkwvWEhjruQ=object
xRifPJdSGAUnsNTzbamVkwvWEhjruL=None
xRifPJdSGAUnsNTzbamVkwvWEhjruB=False
xRifPJdSGAUnsNTzbamVkwvWEhjrtF=True
xRifPJdSGAUnsNTzbamVkwvWEhjrtp=int
xRifPJdSGAUnsNTzbamVkwvWEhjrtO=len
xRifPJdSGAUnsNTzbamVkwvWEhjrtD=str
xRifPJdSGAUnsNTzbamVkwvWEhjrtu=open
xRifPJdSGAUnsNTzbamVkwvWEhjrtg=dict
xRifPJdSGAUnsNTzbamVkwvWEhjrte=Exception
xRifPJdSGAUnsNTzbamVkwvWEhjrtK=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
xRifPJdSGAUnsNTzbamVkwvWEhjrFO=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-'},{'title':'VOD 방송 (인기순)','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 (최신순)','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'월정액 영화관 (인기)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewWeek','ordernm':'-'},{'title':'월정액 영화관 (최신)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'검색 (search)','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-'}]
xRifPJdSGAUnsNTzbamVkwvWEhjrFD=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
xRifPJdSGAUnsNTzbamVkwvWEhjrFu=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
xRifPJdSGAUnsNTzbamVkwvWEhjrFt=[{'title':'VOD 검색','mode':'SEARCH','stype':'vod'},{'title':'영화 검색','mode':'SEARCH','stype':'movie'}]
xRifPJdSGAUnsNTzbamVkwvWEhjrFg=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'PROGRAM','stype':'PCPOS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'키즈/애니','mode':'PROGRAM','stype':'PCC,PCAN'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'뮤직','mode':'PROGRAM','stype':'PCG'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'}]
xRifPJdSGAUnsNTzbamVkwvWEhjrFe={'C00551':'tvN','C00544':'중화TV','C00575':'Olive','C00579':'Mnet','C00590':'OGN','C01141':'XtvN','C01142':'ONSTYLE','C01143':'OtvN','C04601':'CGV','C06941':'tooniverse','C07381':'OCN','C07382':'SUPER ACTION','C15251':'OGN x LOL','C15252':'OGN x 오버워치','C15042':'티빙라이브','C01581':'TV CHOSUN','C01583':'채널A','C00708':'MBN','C00593':'YTN','C01101':'YTN Life','C15347':'YTN science','C01723':'연합뉴스TV','C15152':'DIA TV','C01582':'JTBC','C00588':'JTBC Golf','C15741':'JTBC2','C00805':'JTBC3 FOX Sports','C05661':'디즈니채널','C18641':'IHQ','C22041':'JTBC4','C23343':'t.cast','C23441':'E channel','C17341':'히스토리','C00585':'TV CHOSUN2','C17141':'채널A 플러스','C00611':'LIFETIME','C08041':'tvN go','C05901':'채널W','C23442':"D'LIVE",'C27441':'KBS N'}
xRifPJdSGAUnsNTzbamVkwvWEhjrFK ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
xRifPJdSGAUnsNTzbamVkwvWEhjrFI=xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
from tvingCore import*
class xRifPJdSGAUnsNTzbamVkwvWEhjrFp(xRifPJdSGAUnsNTzbamVkwvWEhjruQ):
 def __init__(xRifPJdSGAUnsNTzbamVkwvWEhjrFq,xRifPJdSGAUnsNTzbamVkwvWEhjrFM,xRifPJdSGAUnsNTzbamVkwvWEhjrFC,xRifPJdSGAUnsNTzbamVkwvWEhjrFl):
  xRifPJdSGAUnsNTzbamVkwvWEhjrFq._addon_url =xRifPJdSGAUnsNTzbamVkwvWEhjrFM
  xRifPJdSGAUnsNTzbamVkwvWEhjrFq._addon_handle=xRifPJdSGAUnsNTzbamVkwvWEhjrFC
  xRifPJdSGAUnsNTzbamVkwvWEhjrFq.main_params =xRifPJdSGAUnsNTzbamVkwvWEhjrFl
  xRifPJdSGAUnsNTzbamVkwvWEhjrFq.TvingObj =xdfVWcPiUhOINtmavXDGzjABLKTbYq() 
 def addon_noti(xRifPJdSGAUnsNTzbamVkwvWEhjrFq,sting):
  try:
   xRifPJdSGAUnsNTzbamVkwvWEhjrFy=xbmcgui.Dialog()
   xRifPJdSGAUnsNTzbamVkwvWEhjrFy.notification(__addonname__,sting)
  except:
   xRifPJdSGAUnsNTzbamVkwvWEhjruL
 def addon_log(xRifPJdSGAUnsNTzbamVkwvWEhjrFq,string):
  try:
   xRifPJdSGAUnsNTzbamVkwvWEhjrFH=string.encode('utf-8','ignore')
  except:
   xRifPJdSGAUnsNTzbamVkwvWEhjrFH='addonException: addon_log'
  xRifPJdSGAUnsNTzbamVkwvWEhjrFc=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,xRifPJdSGAUnsNTzbamVkwvWEhjrFH),level=xRifPJdSGAUnsNTzbamVkwvWEhjrFc)
 def get_keyboard_input(xRifPJdSGAUnsNTzbamVkwvWEhjrFq,xRifPJdSGAUnsNTzbamVkwvWEhjrpg):
  xRifPJdSGAUnsNTzbamVkwvWEhjrFY=xRifPJdSGAUnsNTzbamVkwvWEhjruL
  kb=xbmc.Keyboard()
  kb.setHeading(xRifPJdSGAUnsNTzbamVkwvWEhjrpg)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   xRifPJdSGAUnsNTzbamVkwvWEhjrFY=kb.getText()
  return xRifPJdSGAUnsNTzbamVkwvWEhjrFY
 def get_settings_login_info(xRifPJdSGAUnsNTzbamVkwvWEhjrFq):
  xRifPJdSGAUnsNTzbamVkwvWEhjrFX =__addon__.getSetting('id')
  xRifPJdSGAUnsNTzbamVkwvWEhjrFQ =__addon__.getSetting('pw')
  xRifPJdSGAUnsNTzbamVkwvWEhjrFL =__addon__.getSetting('login_type')
  return(xRifPJdSGAUnsNTzbamVkwvWEhjrFX,xRifPJdSGAUnsNTzbamVkwvWEhjrFQ,xRifPJdSGAUnsNTzbamVkwvWEhjrFL)
 def get_settings_premiumyn(xRifPJdSGAUnsNTzbamVkwvWEhjrFq):
  xRifPJdSGAUnsNTzbamVkwvWEhjrFB =__addon__.getSetting('premium_movieyn')
  if xRifPJdSGAUnsNTzbamVkwvWEhjrFB=='false':
   return xRifPJdSGAUnsNTzbamVkwvWEhjruB
  else:
   return xRifPJdSGAUnsNTzbamVkwvWEhjrtF
 def get_settings_direct_replay(xRifPJdSGAUnsNTzbamVkwvWEhjrFq):
  xRifPJdSGAUnsNTzbamVkwvWEhjrpF=xRifPJdSGAUnsNTzbamVkwvWEhjrtp(__addon__.getSetting('direct_replay'))
  if xRifPJdSGAUnsNTzbamVkwvWEhjrpF==0:
   return xRifPJdSGAUnsNTzbamVkwvWEhjruB
  else:
   return xRifPJdSGAUnsNTzbamVkwvWEhjrtF
 def get_settings_thumbnail_landyn(xRifPJdSGAUnsNTzbamVkwvWEhjrFq):
  xRifPJdSGAUnsNTzbamVkwvWEhjrpO =xRifPJdSGAUnsNTzbamVkwvWEhjrtp(__addon__.getSetting('thumbnail_way'))
  if xRifPJdSGAUnsNTzbamVkwvWEhjrpO==0:
   return xRifPJdSGAUnsNTzbamVkwvWEhjrtF
  else:
   return xRifPJdSGAUnsNTzbamVkwvWEhjruB
 def set_winCredential(xRifPJdSGAUnsNTzbamVkwvWEhjrFq,credential):
  xRifPJdSGAUnsNTzbamVkwvWEhjrpD=xbmcgui.Window(10000)
  xRifPJdSGAUnsNTzbamVkwvWEhjrpD.setProperty('TVING_M_TOKEN',credential.get('tving_token'))
  xRifPJdSGAUnsNTzbamVkwvWEhjrpD.setProperty('TVING_M_USERINFO',credential.get('poc_userinfo'))
  xRifPJdSGAUnsNTzbamVkwvWEhjrpD.setProperty('TVING_M_UUID',credential.get('tving_uuid'))
  xRifPJdSGAUnsNTzbamVkwvWEhjrpD.setProperty('TVING_M_LOGINTIME',xRifPJdSGAUnsNTzbamVkwvWEhjrFq.TvingObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(xRifPJdSGAUnsNTzbamVkwvWEhjrFq):
  xRifPJdSGAUnsNTzbamVkwvWEhjrpD=xbmcgui.Window(10000)
  xRifPJdSGAUnsNTzbamVkwvWEhjrpu={'tving_token':xRifPJdSGAUnsNTzbamVkwvWEhjrpD.getProperty('TVING_M_TOKEN'),'poc_userinfo':xRifPJdSGAUnsNTzbamVkwvWEhjrpD.getProperty('TVING_M_USERINFO'),'tving_uuid':xRifPJdSGAUnsNTzbamVkwvWEhjrpD.getProperty('TVING_M_UUID')}
  return xRifPJdSGAUnsNTzbamVkwvWEhjrpu
 def set_winEpisodeOrderby(xRifPJdSGAUnsNTzbamVkwvWEhjrFq,xRifPJdSGAUnsNTzbamVkwvWEhjrOl):
  xRifPJdSGAUnsNTzbamVkwvWEhjrpD=xbmcgui.Window(10000)
  xRifPJdSGAUnsNTzbamVkwvWEhjrpD.setProperty('TVING_M_ORDERBY',xRifPJdSGAUnsNTzbamVkwvWEhjrOl)
 def get_winEpisodeOrderby(xRifPJdSGAUnsNTzbamVkwvWEhjrFq):
  xRifPJdSGAUnsNTzbamVkwvWEhjrpD=xbmcgui.Window(10000)
  return xRifPJdSGAUnsNTzbamVkwvWEhjrpD.getProperty('TVING_M_ORDERBY')
 def add_dir(xRifPJdSGAUnsNTzbamVkwvWEhjrFq,label,sublabel='',img='',infoLabels=xRifPJdSGAUnsNTzbamVkwvWEhjruL,isFolder=xRifPJdSGAUnsNTzbamVkwvWEhjrtF,params=''):
  xRifPJdSGAUnsNTzbamVkwvWEhjrpt='%s?%s'%(xRifPJdSGAUnsNTzbamVkwvWEhjrFq._addon_url,urllib.parse.urlencode(params))
  if sublabel:xRifPJdSGAUnsNTzbamVkwvWEhjrpg='%s < %s >'%(label,sublabel)
  else: xRifPJdSGAUnsNTzbamVkwvWEhjrpg=label
  if not img:img='DefaultFolder.png'
  xRifPJdSGAUnsNTzbamVkwvWEhjrpe=xbmcgui.ListItem(xRifPJdSGAUnsNTzbamVkwvWEhjrpg)
  xRifPJdSGAUnsNTzbamVkwvWEhjrpe.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:xRifPJdSGAUnsNTzbamVkwvWEhjrpe.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:xRifPJdSGAUnsNTzbamVkwvWEhjrpe.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(xRifPJdSGAUnsNTzbamVkwvWEhjrFq._addon_handle,xRifPJdSGAUnsNTzbamVkwvWEhjrpt,xRifPJdSGAUnsNTzbamVkwvWEhjrpe,isFolder)
 def get_selQuality(xRifPJdSGAUnsNTzbamVkwvWEhjrFq,etype):
  try:
   xRifPJdSGAUnsNTzbamVkwvWEhjrpK='selected_quality'
   xRifPJdSGAUnsNTzbamVkwvWEhjrpI=[1080,720,480,360]
   xRifPJdSGAUnsNTzbamVkwvWEhjrpq=xRifPJdSGAUnsNTzbamVkwvWEhjrtp(__addon__.getSetting(xRifPJdSGAUnsNTzbamVkwvWEhjrpK))
   return xRifPJdSGAUnsNTzbamVkwvWEhjrpI[xRifPJdSGAUnsNTzbamVkwvWEhjrpq]
  except:
   xRifPJdSGAUnsNTzbamVkwvWEhjruL
  return 720 
 def dp_Main_List(xRifPJdSGAUnsNTzbamVkwvWEhjrFq):
  for xRifPJdSGAUnsNTzbamVkwvWEhjrpM in xRifPJdSGAUnsNTzbamVkwvWEhjrFO:
   xRifPJdSGAUnsNTzbamVkwvWEhjrpg=xRifPJdSGAUnsNTzbamVkwvWEhjrpM.get('title')
   xRifPJdSGAUnsNTzbamVkwvWEhjrpC={'mode':xRifPJdSGAUnsNTzbamVkwvWEhjrpM.get('mode'),'stype':xRifPJdSGAUnsNTzbamVkwvWEhjrpM.get('stype'),'orderby':xRifPJdSGAUnsNTzbamVkwvWEhjrpM.get('orderby'),'ordernm':xRifPJdSGAUnsNTzbamVkwvWEhjrpM.get('ordernm'),'page':'1'}
   if xRifPJdSGAUnsNTzbamVkwvWEhjrpM.get('mode')=='XXX':
    xRifPJdSGAUnsNTzbamVkwvWEhjrpC['mode']='XXX'
    xRifPJdSGAUnsNTzbamVkwvWEhjrpl=xRifPJdSGAUnsNTzbamVkwvWEhjruB
   else:
    xRifPJdSGAUnsNTzbamVkwvWEhjrpl=xRifPJdSGAUnsNTzbamVkwvWEhjrtF
   xRifPJdSGAUnsNTzbamVkwvWEhjrFq.add_dir(xRifPJdSGAUnsNTzbamVkwvWEhjrpg,sublabel='',img='',infoLabels=xRifPJdSGAUnsNTzbamVkwvWEhjruL,isFolder=xRifPJdSGAUnsNTzbamVkwvWEhjrpl,params=xRifPJdSGAUnsNTzbamVkwvWEhjrpC)
  if xRifPJdSGAUnsNTzbamVkwvWEhjrtO(xRifPJdSGAUnsNTzbamVkwvWEhjrFO)>0:xbmcplugin.endOfDirectory(xRifPJdSGAUnsNTzbamVkwvWEhjrFq._addon_handle)
 def login_main(xRifPJdSGAUnsNTzbamVkwvWEhjrFq):
  (xRifPJdSGAUnsNTzbamVkwvWEhjrpy,xRifPJdSGAUnsNTzbamVkwvWEhjrpH,xRifPJdSGAUnsNTzbamVkwvWEhjrpc)=xRifPJdSGAUnsNTzbamVkwvWEhjrFq.get_settings_login_info()
  if not(xRifPJdSGAUnsNTzbamVkwvWEhjrpy and xRifPJdSGAUnsNTzbamVkwvWEhjrpH):
   xRifPJdSGAUnsNTzbamVkwvWEhjrFy=xbmcgui.Dialog()
   xRifPJdSGAUnsNTzbamVkwvWEhjrpY=xRifPJdSGAUnsNTzbamVkwvWEhjrFy.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if xRifPJdSGAUnsNTzbamVkwvWEhjrpY==xRifPJdSGAUnsNTzbamVkwvWEhjrtF:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if xRifPJdSGAUnsNTzbamVkwvWEhjrFq.get_winEpisodeOrderby()=='':
   xRifPJdSGAUnsNTzbamVkwvWEhjrFq.set_winEpisodeOrderby('desc')
  if xRifPJdSGAUnsNTzbamVkwvWEhjrFq.cookiefile_check():return
  xRifPJdSGAUnsNTzbamVkwvWEhjrpX =xRifPJdSGAUnsNTzbamVkwvWEhjrtp(xRifPJdSGAUnsNTzbamVkwvWEhjrFq.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  xRifPJdSGAUnsNTzbamVkwvWEhjrpQ=xbmcgui.Window(10000).getProperty('TVING_M_LOGINTIME')
  if xRifPJdSGAUnsNTzbamVkwvWEhjrpQ==xRifPJdSGAUnsNTzbamVkwvWEhjruL or xRifPJdSGAUnsNTzbamVkwvWEhjrpQ=='':
   xRifPJdSGAUnsNTzbamVkwvWEhjrpQ=xRifPJdSGAUnsNTzbamVkwvWEhjrtp('19000101')
  else:
   xRifPJdSGAUnsNTzbamVkwvWEhjrpQ=xRifPJdSGAUnsNTzbamVkwvWEhjrtp(re.sub('-','',xRifPJdSGAUnsNTzbamVkwvWEhjrpQ))
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   xRifPJdSGAUnsNTzbamVkwvWEhjrpL=0
   while xRifPJdSGAUnsNTzbamVkwvWEhjrtF:
    xRifPJdSGAUnsNTzbamVkwvWEhjrpL+=1
    time.sleep(0.05)
    if xRifPJdSGAUnsNTzbamVkwvWEhjrpQ>=xRifPJdSGAUnsNTzbamVkwvWEhjrpX:return
    if xRifPJdSGAUnsNTzbamVkwvWEhjrpL>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  if xRifPJdSGAUnsNTzbamVkwvWEhjrpQ>=xRifPJdSGAUnsNTzbamVkwvWEhjrpX:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   return
  if not xRifPJdSGAUnsNTzbamVkwvWEhjrFq.TvingObj.GetCredential(xRifPJdSGAUnsNTzbamVkwvWEhjrpy,xRifPJdSGAUnsNTzbamVkwvWEhjrpH,xRifPJdSGAUnsNTzbamVkwvWEhjrpc):
   xRifPJdSGAUnsNTzbamVkwvWEhjrFq.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   sys.exit()
  xRifPJdSGAUnsNTzbamVkwvWEhjrFq.set_winCredential(xRifPJdSGAUnsNTzbamVkwvWEhjrFq.TvingObj.LoadCredential())
  xRifPJdSGAUnsNTzbamVkwvWEhjrFq.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
 def dp_Title_Group(xRifPJdSGAUnsNTzbamVkwvWEhjrFq,xRifPJdSGAUnsNTzbamVkwvWEhjrOD):
  xRifPJdSGAUnsNTzbamVkwvWEhjrpB=xRifPJdSGAUnsNTzbamVkwvWEhjrOD.get('stype')
  if xRifPJdSGAUnsNTzbamVkwvWEhjrpB=='live':
   xRifPJdSGAUnsNTzbamVkwvWEhjrOF=xRifPJdSGAUnsNTzbamVkwvWEhjrFD
  else:
   xRifPJdSGAUnsNTzbamVkwvWEhjrOF=xRifPJdSGAUnsNTzbamVkwvWEhjrFg
  for xRifPJdSGAUnsNTzbamVkwvWEhjrOp in xRifPJdSGAUnsNTzbamVkwvWEhjrOF:
   xRifPJdSGAUnsNTzbamVkwvWEhjrpg=xRifPJdSGAUnsNTzbamVkwvWEhjrOp.get('title')
   if xRifPJdSGAUnsNTzbamVkwvWEhjrOD.get('ordernm')!='-':
    xRifPJdSGAUnsNTzbamVkwvWEhjrpg+='  ('+xRifPJdSGAUnsNTzbamVkwvWEhjrOD.get('ordernm')+')'
   xRifPJdSGAUnsNTzbamVkwvWEhjrpC={'mode':xRifPJdSGAUnsNTzbamVkwvWEhjrOp.get('mode'),'stype':xRifPJdSGAUnsNTzbamVkwvWEhjrOp.get('stype'),'orderby':xRifPJdSGAUnsNTzbamVkwvWEhjrOD.get('orderby'),'page':'1'}
   xRifPJdSGAUnsNTzbamVkwvWEhjrFq.add_dir(xRifPJdSGAUnsNTzbamVkwvWEhjrpg,sublabel='',img='',infoLabels=xRifPJdSGAUnsNTzbamVkwvWEhjruL,isFolder=xRifPJdSGAUnsNTzbamVkwvWEhjrtF,params=xRifPJdSGAUnsNTzbamVkwvWEhjrpC)
  if xRifPJdSGAUnsNTzbamVkwvWEhjrtO(xRifPJdSGAUnsNTzbamVkwvWEhjrOF)>0:xbmcplugin.endOfDirectory(xRifPJdSGAUnsNTzbamVkwvWEhjrFq._addon_handle)
 def dp_LiveChannel_List(xRifPJdSGAUnsNTzbamVkwvWEhjrFq,xRifPJdSGAUnsNTzbamVkwvWEhjrOD):
  xRifPJdSGAUnsNTzbamVkwvWEhjrFq.TvingObj.SaveCredential(xRifPJdSGAUnsNTzbamVkwvWEhjrFq.get_winCredential())
  xRifPJdSGAUnsNTzbamVkwvWEhjrpB =xRifPJdSGAUnsNTzbamVkwvWEhjrOD.get('stype')
  xRifPJdSGAUnsNTzbamVkwvWEhjrOu =xRifPJdSGAUnsNTzbamVkwvWEhjrtp(xRifPJdSGAUnsNTzbamVkwvWEhjrOD.get('page'))
  xRifPJdSGAUnsNTzbamVkwvWEhjrOt,xRifPJdSGAUnsNTzbamVkwvWEhjrOg=xRifPJdSGAUnsNTzbamVkwvWEhjrFq.TvingObj.GetLiveChannelList(xRifPJdSGAUnsNTzbamVkwvWEhjrpB,xRifPJdSGAUnsNTzbamVkwvWEhjrOu)
  for xRifPJdSGAUnsNTzbamVkwvWEhjrOe in xRifPJdSGAUnsNTzbamVkwvWEhjrOt:
   xRifPJdSGAUnsNTzbamVkwvWEhjrpg =xRifPJdSGAUnsNTzbamVkwvWEhjrOe.get('title')
   xRifPJdSGAUnsNTzbamVkwvWEhjrpo =xRifPJdSGAUnsNTzbamVkwvWEhjrOe.get('channel')
   xRifPJdSGAUnsNTzbamVkwvWEhjrOK =xRifPJdSGAUnsNTzbamVkwvWEhjrOe.get('thumbnail')
   xRifPJdSGAUnsNTzbamVkwvWEhjrOI =xRifPJdSGAUnsNTzbamVkwvWEhjrOe.get('synopsis')
   xRifPJdSGAUnsNTzbamVkwvWEhjrOq=xRifPJdSGAUnsNTzbamVkwvWEhjrOe.get('channelepg')
   xRifPJdSGAUnsNTzbamVkwvWEhjrOM=xRifPJdSGAUnsNTzbamVkwvWEhjrOe.get('info')
   xRifPJdSGAUnsNTzbamVkwvWEhjrOM['plot']='%s\n%s\n%s\n\n%s'%(xRifPJdSGAUnsNTzbamVkwvWEhjrpo,xRifPJdSGAUnsNTzbamVkwvWEhjrpg,xRifPJdSGAUnsNTzbamVkwvWEhjrOq,xRifPJdSGAUnsNTzbamVkwvWEhjrOI)
   xRifPJdSGAUnsNTzbamVkwvWEhjrpC={'mode':'LIVE','mediacode':xRifPJdSGAUnsNTzbamVkwvWEhjrOe.get('mediacode'),'stype':xRifPJdSGAUnsNTzbamVkwvWEhjrpB}
   xRifPJdSGAUnsNTzbamVkwvWEhjrFq.add_dir(xRifPJdSGAUnsNTzbamVkwvWEhjrpo,sublabel=xRifPJdSGAUnsNTzbamVkwvWEhjrpg,img=xRifPJdSGAUnsNTzbamVkwvWEhjrOK,infoLabels=xRifPJdSGAUnsNTzbamVkwvWEhjrOM,isFolder=xRifPJdSGAUnsNTzbamVkwvWEhjruB,params=xRifPJdSGAUnsNTzbamVkwvWEhjrpC)
  if xRifPJdSGAUnsNTzbamVkwvWEhjrOg:
   xRifPJdSGAUnsNTzbamVkwvWEhjrpC['mode']='CHANNEL' 
   xRifPJdSGAUnsNTzbamVkwvWEhjrpC['stype']=xRifPJdSGAUnsNTzbamVkwvWEhjrpB 
   xRifPJdSGAUnsNTzbamVkwvWEhjrpC['page']=xRifPJdSGAUnsNTzbamVkwvWEhjrtD(xRifPJdSGAUnsNTzbamVkwvWEhjrOu+1)
   xRifPJdSGAUnsNTzbamVkwvWEhjrpg='[B]%s >>[/B]'%'다음 페이지'
   xRifPJdSGAUnsNTzbamVkwvWEhjrOC=xRifPJdSGAUnsNTzbamVkwvWEhjrtD(xRifPJdSGAUnsNTzbamVkwvWEhjrOu+1)
   xRifPJdSGAUnsNTzbamVkwvWEhjrFq.add_dir(xRifPJdSGAUnsNTzbamVkwvWEhjrpg,sublabel=xRifPJdSGAUnsNTzbamVkwvWEhjrOC,img='',infoLabels=xRifPJdSGAUnsNTzbamVkwvWEhjruL,isFolder=xRifPJdSGAUnsNTzbamVkwvWEhjrtF,params=xRifPJdSGAUnsNTzbamVkwvWEhjrpC)
  if xRifPJdSGAUnsNTzbamVkwvWEhjrtO(xRifPJdSGAUnsNTzbamVkwvWEhjrOt)>0:xbmcplugin.endOfDirectory(xRifPJdSGAUnsNTzbamVkwvWEhjrFq._addon_handle,cacheToDisc=xRifPJdSGAUnsNTzbamVkwvWEhjruB)
 def dp_Program_List(xRifPJdSGAUnsNTzbamVkwvWEhjrFq,xRifPJdSGAUnsNTzbamVkwvWEhjrOD):
  xRifPJdSGAUnsNTzbamVkwvWEhjrFq.TvingObj.SaveCredential(xRifPJdSGAUnsNTzbamVkwvWEhjrFq.get_winCredential())
  xRifPJdSGAUnsNTzbamVkwvWEhjrpB =xRifPJdSGAUnsNTzbamVkwvWEhjrOD.get('stype')
  xRifPJdSGAUnsNTzbamVkwvWEhjrOl =xRifPJdSGAUnsNTzbamVkwvWEhjrOD.get('orderby')
  xRifPJdSGAUnsNTzbamVkwvWEhjrOu =xRifPJdSGAUnsNTzbamVkwvWEhjrtp(xRifPJdSGAUnsNTzbamVkwvWEhjrOD.get('page'))
  xRifPJdSGAUnsNTzbamVkwvWEhjrOo,xRifPJdSGAUnsNTzbamVkwvWEhjrOg=xRifPJdSGAUnsNTzbamVkwvWEhjrFq.TvingObj.GetProgramList(xRifPJdSGAUnsNTzbamVkwvWEhjrpB,xRifPJdSGAUnsNTzbamVkwvWEhjrOl,xRifPJdSGAUnsNTzbamVkwvWEhjrOu,landyn=xRifPJdSGAUnsNTzbamVkwvWEhjrFq.get_settings_thumbnail_landyn())
  for xRifPJdSGAUnsNTzbamVkwvWEhjrOy in xRifPJdSGAUnsNTzbamVkwvWEhjrOo:
   xRifPJdSGAUnsNTzbamVkwvWEhjrpg =xRifPJdSGAUnsNTzbamVkwvWEhjrOy.get('title')
   xRifPJdSGAUnsNTzbamVkwvWEhjrOK=xRifPJdSGAUnsNTzbamVkwvWEhjrOy.get('thumbnail')
   xRifPJdSGAUnsNTzbamVkwvWEhjrOI =xRifPJdSGAUnsNTzbamVkwvWEhjrOy.get('synopsis')
   xRifPJdSGAUnsNTzbamVkwvWEhjrOH =xRifPJdSGAUnsNTzbamVkwvWEhjrFe.get(xRifPJdSGAUnsNTzbamVkwvWEhjrOy.get('channel'))
   xRifPJdSGAUnsNTzbamVkwvWEhjrOM=xRifPJdSGAUnsNTzbamVkwvWEhjrOy.get('info')
   xRifPJdSGAUnsNTzbamVkwvWEhjrOM['studio']=xRifPJdSGAUnsNTzbamVkwvWEhjrOH
   xRifPJdSGAUnsNTzbamVkwvWEhjrOM['plot']='%s <%s>\n\n%s'%(xRifPJdSGAUnsNTzbamVkwvWEhjrpg,xRifPJdSGAUnsNTzbamVkwvWEhjrOH,xRifPJdSGAUnsNTzbamVkwvWEhjrOI)
   xRifPJdSGAUnsNTzbamVkwvWEhjrpC={'mode':'EPISODE','programcode':xRifPJdSGAUnsNTzbamVkwvWEhjrOy.get('program'),'page':'1'}
   xRifPJdSGAUnsNTzbamVkwvWEhjrFq.add_dir(xRifPJdSGAUnsNTzbamVkwvWEhjrpg,sublabel=xRifPJdSGAUnsNTzbamVkwvWEhjrOH,img=xRifPJdSGAUnsNTzbamVkwvWEhjrOK,infoLabels=xRifPJdSGAUnsNTzbamVkwvWEhjrOM,isFolder=xRifPJdSGAUnsNTzbamVkwvWEhjrtF,params=xRifPJdSGAUnsNTzbamVkwvWEhjrpC)
  if xRifPJdSGAUnsNTzbamVkwvWEhjrOg:
   xRifPJdSGAUnsNTzbamVkwvWEhjrpC['mode'] ='PROGRAM' 
   xRifPJdSGAUnsNTzbamVkwvWEhjrpC['stype'] =xRifPJdSGAUnsNTzbamVkwvWEhjrpB
   xRifPJdSGAUnsNTzbamVkwvWEhjrpC['orderby']=xRifPJdSGAUnsNTzbamVkwvWEhjrOl
   xRifPJdSGAUnsNTzbamVkwvWEhjrpC['page'] =xRifPJdSGAUnsNTzbamVkwvWEhjrtD(xRifPJdSGAUnsNTzbamVkwvWEhjrOu+1)
   xRifPJdSGAUnsNTzbamVkwvWEhjrpg='[B]%s >>[/B]'%'다음 페이지'
   xRifPJdSGAUnsNTzbamVkwvWEhjrOC=xRifPJdSGAUnsNTzbamVkwvWEhjrtD(xRifPJdSGAUnsNTzbamVkwvWEhjrOu+1)
   xRifPJdSGAUnsNTzbamVkwvWEhjrFq.add_dir(xRifPJdSGAUnsNTzbamVkwvWEhjrpg,sublabel=xRifPJdSGAUnsNTzbamVkwvWEhjrOC,img='',infoLabels=xRifPJdSGAUnsNTzbamVkwvWEhjruL,isFolder=xRifPJdSGAUnsNTzbamVkwvWEhjrtF,params=xRifPJdSGAUnsNTzbamVkwvWEhjrpC)
  if xRifPJdSGAUnsNTzbamVkwvWEhjrtO(xRifPJdSGAUnsNTzbamVkwvWEhjrOo)>0:xbmcplugin.endOfDirectory(xRifPJdSGAUnsNTzbamVkwvWEhjrFq._addon_handle,cacheToDisc=xRifPJdSGAUnsNTzbamVkwvWEhjruB)
 def dp_Episode_List(xRifPJdSGAUnsNTzbamVkwvWEhjrFq,xRifPJdSGAUnsNTzbamVkwvWEhjrOD):
  xRifPJdSGAUnsNTzbamVkwvWEhjrFq.TvingObj.SaveCredential(xRifPJdSGAUnsNTzbamVkwvWEhjrFq.get_winCredential())
  xRifPJdSGAUnsNTzbamVkwvWEhjrOc=xRifPJdSGAUnsNTzbamVkwvWEhjrOD.get('programcode')
  xRifPJdSGAUnsNTzbamVkwvWEhjrOu =xRifPJdSGAUnsNTzbamVkwvWEhjrtp(xRifPJdSGAUnsNTzbamVkwvWEhjrOD.get('page'))
  xRifPJdSGAUnsNTzbamVkwvWEhjrOY,xRifPJdSGAUnsNTzbamVkwvWEhjrOg,xRifPJdSGAUnsNTzbamVkwvWEhjrOX=xRifPJdSGAUnsNTzbamVkwvWEhjrFq.TvingObj.GetEpisodoList(xRifPJdSGAUnsNTzbamVkwvWEhjrOc,xRifPJdSGAUnsNTzbamVkwvWEhjrOu,orderby=xRifPJdSGAUnsNTzbamVkwvWEhjrFq.get_winEpisodeOrderby())
  for xRifPJdSGAUnsNTzbamVkwvWEhjrOQ in xRifPJdSGAUnsNTzbamVkwvWEhjrOY:
   xRifPJdSGAUnsNTzbamVkwvWEhjrpg =xRifPJdSGAUnsNTzbamVkwvWEhjrOQ.get('title')
   xRifPJdSGAUnsNTzbamVkwvWEhjrOC =xRifPJdSGAUnsNTzbamVkwvWEhjrOQ.get('subtitle')
   xRifPJdSGAUnsNTzbamVkwvWEhjrOK=xRifPJdSGAUnsNTzbamVkwvWEhjrOQ.get('thumbnail')
   xRifPJdSGAUnsNTzbamVkwvWEhjrOI =xRifPJdSGAUnsNTzbamVkwvWEhjrOQ.get('synopsis')
   xRifPJdSGAUnsNTzbamVkwvWEhjrOM=xRifPJdSGAUnsNTzbamVkwvWEhjrOQ.get('info')
   xRifPJdSGAUnsNTzbamVkwvWEhjrOM['plot']='%s\n\n%s'%(xRifPJdSGAUnsNTzbamVkwvWEhjrpg,xRifPJdSGAUnsNTzbamVkwvWEhjrOI)
   xRifPJdSGAUnsNTzbamVkwvWEhjrpC={'mode':'VOD','mediacode':xRifPJdSGAUnsNTzbamVkwvWEhjrOQ.get('episode'),'stype':'vod','programcode':xRifPJdSGAUnsNTzbamVkwvWEhjrOc,'title':xRifPJdSGAUnsNTzbamVkwvWEhjrpg,'thumbnail':xRifPJdSGAUnsNTzbamVkwvWEhjrOK}
   xRifPJdSGAUnsNTzbamVkwvWEhjrFq.add_dir(xRifPJdSGAUnsNTzbamVkwvWEhjrpg,sublabel=xRifPJdSGAUnsNTzbamVkwvWEhjrOC,img=xRifPJdSGAUnsNTzbamVkwvWEhjrOK,infoLabels=xRifPJdSGAUnsNTzbamVkwvWEhjrOM,isFolder=xRifPJdSGAUnsNTzbamVkwvWEhjruB,params=xRifPJdSGAUnsNTzbamVkwvWEhjrpC)
  if xRifPJdSGAUnsNTzbamVkwvWEhjrOu==1:
   xRifPJdSGAUnsNTzbamVkwvWEhjrOM={'plot':'정렬순서를 변경합니다.'}
   xRifPJdSGAUnsNTzbamVkwvWEhjrpC={}
   xRifPJdSGAUnsNTzbamVkwvWEhjrpC['mode'] ='ORDER_BY' 
   if xRifPJdSGAUnsNTzbamVkwvWEhjrFq.get_winEpisodeOrderby()=='desc':
    xRifPJdSGAUnsNTzbamVkwvWEhjrpg='정렬순서변경 : 최신화부터 -> 1회부터'
    xRifPJdSGAUnsNTzbamVkwvWEhjrpC['orderby']='asc'
   else:
    xRifPJdSGAUnsNTzbamVkwvWEhjrpg='정렬순서변경 : 1회부터 -> 최신화부터'
    xRifPJdSGAUnsNTzbamVkwvWEhjrpC['orderby']='desc'
   xRifPJdSGAUnsNTzbamVkwvWEhjrFq.add_dir(xRifPJdSGAUnsNTzbamVkwvWEhjrpg,sublabel='',img='',infoLabels=xRifPJdSGAUnsNTzbamVkwvWEhjrOM,isFolder=xRifPJdSGAUnsNTzbamVkwvWEhjruB,params=xRifPJdSGAUnsNTzbamVkwvWEhjrpC)
  if xRifPJdSGAUnsNTzbamVkwvWEhjrOg:
   xRifPJdSGAUnsNTzbamVkwvWEhjrpC['mode'] ='EPISODE' 
   xRifPJdSGAUnsNTzbamVkwvWEhjrpC['programcode']=xRifPJdSGAUnsNTzbamVkwvWEhjrOc
   xRifPJdSGAUnsNTzbamVkwvWEhjrpC['page'] =xRifPJdSGAUnsNTzbamVkwvWEhjrtD(xRifPJdSGAUnsNTzbamVkwvWEhjrOu+1)
   xRifPJdSGAUnsNTzbamVkwvWEhjrpg='[B]%s >>[/B]'%'다음 페이지'
   xRifPJdSGAUnsNTzbamVkwvWEhjrOC=xRifPJdSGAUnsNTzbamVkwvWEhjrtD(xRifPJdSGAUnsNTzbamVkwvWEhjrOu+1)
   xRifPJdSGAUnsNTzbamVkwvWEhjrFq.add_dir(xRifPJdSGAUnsNTzbamVkwvWEhjrpg,sublabel=xRifPJdSGAUnsNTzbamVkwvWEhjrOC,img='',infoLabels=xRifPJdSGAUnsNTzbamVkwvWEhjruL,isFolder=xRifPJdSGAUnsNTzbamVkwvWEhjrtF,params=xRifPJdSGAUnsNTzbamVkwvWEhjrpC)
  if xRifPJdSGAUnsNTzbamVkwvWEhjrtO(xRifPJdSGAUnsNTzbamVkwvWEhjrOY)>0:xbmcplugin.endOfDirectory(xRifPJdSGAUnsNTzbamVkwvWEhjrFq._addon_handle,cacheToDisc=xRifPJdSGAUnsNTzbamVkwvWEhjrtF)
 def dp_setEpOrderby(xRifPJdSGAUnsNTzbamVkwvWEhjrFq,xRifPJdSGAUnsNTzbamVkwvWEhjrOD):
  xRifPJdSGAUnsNTzbamVkwvWEhjrOl =xRifPJdSGAUnsNTzbamVkwvWEhjrOD.get('orderby')
  xRifPJdSGAUnsNTzbamVkwvWEhjrFq.set_winEpisodeOrderby(xRifPJdSGAUnsNTzbamVkwvWEhjrOl)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(xRifPJdSGAUnsNTzbamVkwvWEhjrFq,xRifPJdSGAUnsNTzbamVkwvWEhjrOD):
  xRifPJdSGAUnsNTzbamVkwvWEhjrFq.TvingObj.SaveCredential(xRifPJdSGAUnsNTzbamVkwvWEhjrFq.get_winCredential())
  xRifPJdSGAUnsNTzbamVkwvWEhjrOl =xRifPJdSGAUnsNTzbamVkwvWEhjrOD.get('orderby')
  xRifPJdSGAUnsNTzbamVkwvWEhjrOu=xRifPJdSGAUnsNTzbamVkwvWEhjrtp(xRifPJdSGAUnsNTzbamVkwvWEhjrOD.get('page'))
  xRifPJdSGAUnsNTzbamVkwvWEhjrOL,xRifPJdSGAUnsNTzbamVkwvWEhjrOg=xRifPJdSGAUnsNTzbamVkwvWEhjrFq.TvingObj.GetMovieList(xRifPJdSGAUnsNTzbamVkwvWEhjrOl,xRifPJdSGAUnsNTzbamVkwvWEhjrOu,premiumyn=xRifPJdSGAUnsNTzbamVkwvWEhjrFq.get_settings_premiumyn(),landyn=xRifPJdSGAUnsNTzbamVkwvWEhjrFq.get_settings_thumbnail_landyn())
  for xRifPJdSGAUnsNTzbamVkwvWEhjrOB in xRifPJdSGAUnsNTzbamVkwvWEhjrOL:
   xRifPJdSGAUnsNTzbamVkwvWEhjrpg =xRifPJdSGAUnsNTzbamVkwvWEhjrOB.get('title')
   xRifPJdSGAUnsNTzbamVkwvWEhjrOK=xRifPJdSGAUnsNTzbamVkwvWEhjrOB.get('thumbnail')
   xRifPJdSGAUnsNTzbamVkwvWEhjrOI =xRifPJdSGAUnsNTzbamVkwvWEhjrOB.get('synopsis')
   xRifPJdSGAUnsNTzbamVkwvWEhjrOM=xRifPJdSGAUnsNTzbamVkwvWEhjrOB.get('info')
   xRifPJdSGAUnsNTzbamVkwvWEhjrOM['plot']='%s\n\n%s'%(xRifPJdSGAUnsNTzbamVkwvWEhjrpg,xRifPJdSGAUnsNTzbamVkwvWEhjrOI)
   xRifPJdSGAUnsNTzbamVkwvWEhjrpC={'mode':'MOVIE','mediacode':xRifPJdSGAUnsNTzbamVkwvWEhjrOB.get('moviecode'),'stype':'movie','title':xRifPJdSGAUnsNTzbamVkwvWEhjrpg,'thumbnail':xRifPJdSGAUnsNTzbamVkwvWEhjrOK}
   xRifPJdSGAUnsNTzbamVkwvWEhjrFq.add_dir(xRifPJdSGAUnsNTzbamVkwvWEhjrpg,sublabel='',img=xRifPJdSGAUnsNTzbamVkwvWEhjrOK,infoLabels=xRifPJdSGAUnsNTzbamVkwvWEhjrOM,isFolder=xRifPJdSGAUnsNTzbamVkwvWEhjruB,params=xRifPJdSGAUnsNTzbamVkwvWEhjrpC)
  if xRifPJdSGAUnsNTzbamVkwvWEhjrOg:
   xRifPJdSGAUnsNTzbamVkwvWEhjrpC['mode'] ='MOVIE_GROUP' 
   xRifPJdSGAUnsNTzbamVkwvWEhjrpC['orderby']=xRifPJdSGAUnsNTzbamVkwvWEhjrOl
   xRifPJdSGAUnsNTzbamVkwvWEhjrpC['page'] =xRifPJdSGAUnsNTzbamVkwvWEhjrtD(xRifPJdSGAUnsNTzbamVkwvWEhjrOu+1)
   xRifPJdSGAUnsNTzbamVkwvWEhjrpg='[B]%s >>[/B]'%'다음 페이지'
   xRifPJdSGAUnsNTzbamVkwvWEhjrOC=xRifPJdSGAUnsNTzbamVkwvWEhjrtD(xRifPJdSGAUnsNTzbamVkwvWEhjrOu+1)
   xRifPJdSGAUnsNTzbamVkwvWEhjrFq.add_dir(xRifPJdSGAUnsNTzbamVkwvWEhjrpg,sublabel=xRifPJdSGAUnsNTzbamVkwvWEhjrOC,img='',infoLabels=xRifPJdSGAUnsNTzbamVkwvWEhjruL,isFolder=xRifPJdSGAUnsNTzbamVkwvWEhjrtF,params=xRifPJdSGAUnsNTzbamVkwvWEhjrpC)
  if xRifPJdSGAUnsNTzbamVkwvWEhjrtO(xRifPJdSGAUnsNTzbamVkwvWEhjrOL)>0:xbmcplugin.endOfDirectory(xRifPJdSGAUnsNTzbamVkwvWEhjrFq._addon_handle,cacheToDisc=xRifPJdSGAUnsNTzbamVkwvWEhjruB)
 def dp_Search_Group(xRifPJdSGAUnsNTzbamVkwvWEhjrFq,xRifPJdSGAUnsNTzbamVkwvWEhjrOD):
  for xRifPJdSGAUnsNTzbamVkwvWEhjrOp in xRifPJdSGAUnsNTzbamVkwvWEhjrFt:
   xRifPJdSGAUnsNTzbamVkwvWEhjrpg=xRifPJdSGAUnsNTzbamVkwvWEhjrOp.get('title')
   xRifPJdSGAUnsNTzbamVkwvWEhjrpC={'mode':xRifPJdSGAUnsNTzbamVkwvWEhjrOp.get('mode'),'stype':xRifPJdSGAUnsNTzbamVkwvWEhjrOp.get('stype'),'page':'1'}
   xRifPJdSGAUnsNTzbamVkwvWEhjrFq.add_dir(xRifPJdSGAUnsNTzbamVkwvWEhjrpg,sublabel='',img='',infoLabels=xRifPJdSGAUnsNTzbamVkwvWEhjruL,isFolder=xRifPJdSGAUnsNTzbamVkwvWEhjrtF,params=xRifPJdSGAUnsNTzbamVkwvWEhjrpC)
  if xRifPJdSGAUnsNTzbamVkwvWEhjrtO(xRifPJdSGAUnsNTzbamVkwvWEhjrFt)>0:xbmcplugin.endOfDirectory(xRifPJdSGAUnsNTzbamVkwvWEhjrFq._addon_handle)
 def dp_Search_List(xRifPJdSGAUnsNTzbamVkwvWEhjrFq,xRifPJdSGAUnsNTzbamVkwvWEhjrOD):
  xRifPJdSGAUnsNTzbamVkwvWEhjrFq.TvingObj.SaveCredential(xRifPJdSGAUnsNTzbamVkwvWEhjrFq.get_winCredential())
  xRifPJdSGAUnsNTzbamVkwvWEhjrDF =__addon__.getSetting('id')
  xRifPJdSGAUnsNTzbamVkwvWEhjrOu =xRifPJdSGAUnsNTzbamVkwvWEhjrtp(xRifPJdSGAUnsNTzbamVkwvWEhjrOD.get('page'))
  xRifPJdSGAUnsNTzbamVkwvWEhjrpB =xRifPJdSGAUnsNTzbamVkwvWEhjrOD.get('stype')
  if 'search_key' in xRifPJdSGAUnsNTzbamVkwvWEhjrOD:
   xRifPJdSGAUnsNTzbamVkwvWEhjrDp=xRifPJdSGAUnsNTzbamVkwvWEhjrOD.get('search_key')
  else:
   xRifPJdSGAUnsNTzbamVkwvWEhjrDp=xRifPJdSGAUnsNTzbamVkwvWEhjrFq.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not xRifPJdSGAUnsNTzbamVkwvWEhjrDp:return
  xRifPJdSGAUnsNTzbamVkwvWEhjrDO,xRifPJdSGAUnsNTzbamVkwvWEhjrOg=xRifPJdSGAUnsNTzbamVkwvWEhjrFq.TvingObj.GetSearchList(xRifPJdSGAUnsNTzbamVkwvWEhjrDp,xRifPJdSGAUnsNTzbamVkwvWEhjrDF,xRifPJdSGAUnsNTzbamVkwvWEhjrOu,xRifPJdSGAUnsNTzbamVkwvWEhjrpB,premiumyn=xRifPJdSGAUnsNTzbamVkwvWEhjrFq.get_settings_premiumyn(),landyn=xRifPJdSGAUnsNTzbamVkwvWEhjrFq.get_settings_thumbnail_landyn())
  if xRifPJdSGAUnsNTzbamVkwvWEhjrtO(xRifPJdSGAUnsNTzbamVkwvWEhjrDO)==0:return
  for xRifPJdSGAUnsNTzbamVkwvWEhjrDu in xRifPJdSGAUnsNTzbamVkwvWEhjrDO:
   xRifPJdSGAUnsNTzbamVkwvWEhjrpg =xRifPJdSGAUnsNTzbamVkwvWEhjrDu.get('title')
   xRifPJdSGAUnsNTzbamVkwvWEhjrOK=xRifPJdSGAUnsNTzbamVkwvWEhjrDu.get('thumbnail')
   xRifPJdSGAUnsNTzbamVkwvWEhjrOI =xRifPJdSGAUnsNTzbamVkwvWEhjrDu.get('synopsis')
   xRifPJdSGAUnsNTzbamVkwvWEhjrDt =xRifPJdSGAUnsNTzbamVkwvWEhjrDu.get('program')
   xRifPJdSGAUnsNTzbamVkwvWEhjrOM=xRifPJdSGAUnsNTzbamVkwvWEhjrDu.get('info')
   xRifPJdSGAUnsNTzbamVkwvWEhjrOM['plot']='%s\n\n%s'%(xRifPJdSGAUnsNTzbamVkwvWEhjrpg,xRifPJdSGAUnsNTzbamVkwvWEhjrOI)
   if xRifPJdSGAUnsNTzbamVkwvWEhjrpB=='vod':
    xRifPJdSGAUnsNTzbamVkwvWEhjrpC={'mode':'EPISODE','programcode':xRifPJdSGAUnsNTzbamVkwvWEhjrDu.get('program'),'page':'1'}
    xRifPJdSGAUnsNTzbamVkwvWEhjrpl=xRifPJdSGAUnsNTzbamVkwvWEhjrtF
   else:
    xRifPJdSGAUnsNTzbamVkwvWEhjrpC={'mode':'MOVIE','mediacode':xRifPJdSGAUnsNTzbamVkwvWEhjrDu.get('movie'),'stype':'movie','title':xRifPJdSGAUnsNTzbamVkwvWEhjrpg,'thumbnail':xRifPJdSGAUnsNTzbamVkwvWEhjrOK}
    xRifPJdSGAUnsNTzbamVkwvWEhjrpl=xRifPJdSGAUnsNTzbamVkwvWEhjruB
   xRifPJdSGAUnsNTzbamVkwvWEhjrFq.add_dir(xRifPJdSGAUnsNTzbamVkwvWEhjrpg,sublabel='',img=xRifPJdSGAUnsNTzbamVkwvWEhjrOK,infoLabels=xRifPJdSGAUnsNTzbamVkwvWEhjrOM,isFolder=xRifPJdSGAUnsNTzbamVkwvWEhjrpl,params=xRifPJdSGAUnsNTzbamVkwvWEhjrpC)
  if xRifPJdSGAUnsNTzbamVkwvWEhjrOg:
   xRifPJdSGAUnsNTzbamVkwvWEhjrpC['mode'] ='SEARCH' 
   xRifPJdSGAUnsNTzbamVkwvWEhjrpC['search_key']=xRifPJdSGAUnsNTzbamVkwvWEhjrDp
   xRifPJdSGAUnsNTzbamVkwvWEhjrpC['page'] =xRifPJdSGAUnsNTzbamVkwvWEhjrtD(xRifPJdSGAUnsNTzbamVkwvWEhjrOu+1)
   xRifPJdSGAUnsNTzbamVkwvWEhjrpg='[B]%s >>[/B]'%'다음 페이지'
   xRifPJdSGAUnsNTzbamVkwvWEhjrOC=xRifPJdSGAUnsNTzbamVkwvWEhjrtD(xRifPJdSGAUnsNTzbamVkwvWEhjrOu+1)
   xRifPJdSGAUnsNTzbamVkwvWEhjrFq.add_dir(xRifPJdSGAUnsNTzbamVkwvWEhjrpg,sublabel=xRifPJdSGAUnsNTzbamVkwvWEhjrOC,img='',infoLabels=xRifPJdSGAUnsNTzbamVkwvWEhjruL,isFolder=xRifPJdSGAUnsNTzbamVkwvWEhjrtF,params=xRifPJdSGAUnsNTzbamVkwvWEhjrpC)
  if xRifPJdSGAUnsNTzbamVkwvWEhjrtO(xRifPJdSGAUnsNTzbamVkwvWEhjrDO)>0:xbmcplugin.endOfDirectory(xRifPJdSGAUnsNTzbamVkwvWEhjrFq._addon_handle)
 def Delete_Watched_List(xRifPJdSGAUnsNTzbamVkwvWEhjrFq,xRifPJdSGAUnsNTzbamVkwvWEhjrpB):
  try:
   xRifPJdSGAUnsNTzbamVkwvWEhjrDg=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%xRifPJdSGAUnsNTzbamVkwvWEhjrpB))
   fp=xRifPJdSGAUnsNTzbamVkwvWEhjrtu(xRifPJdSGAUnsNTzbamVkwvWEhjrDg,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   xRifPJdSGAUnsNTzbamVkwvWEhjruL
 def dp_WatchList_Delete(xRifPJdSGAUnsNTzbamVkwvWEhjrFq,xRifPJdSGAUnsNTzbamVkwvWEhjrOD):
  xRifPJdSGAUnsNTzbamVkwvWEhjrpB=xRifPJdSGAUnsNTzbamVkwvWEhjrOD.get('stype')
  xRifPJdSGAUnsNTzbamVkwvWEhjrFy=xbmcgui.Dialog()
  xRifPJdSGAUnsNTzbamVkwvWEhjrpY=xRifPJdSGAUnsNTzbamVkwvWEhjrFy.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if xRifPJdSGAUnsNTzbamVkwvWEhjrpY==xRifPJdSGAUnsNTzbamVkwvWEhjruB:sys.exit()
  xRifPJdSGAUnsNTzbamVkwvWEhjrFq.Delete_Watched_List(xRifPJdSGAUnsNTzbamVkwvWEhjrpB)
  xbmc.executebuiltin("Container.Refresh")
 def Load_Watched_List(xRifPJdSGAUnsNTzbamVkwvWEhjrFq,xRifPJdSGAUnsNTzbamVkwvWEhjrpB):
  try:
   xRifPJdSGAUnsNTzbamVkwvWEhjrDg=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%xRifPJdSGAUnsNTzbamVkwvWEhjrpB))
   fp=xRifPJdSGAUnsNTzbamVkwvWEhjrtu(xRifPJdSGAUnsNTzbamVkwvWEhjrDg,'r',-1,'utf-8')
   xRifPJdSGAUnsNTzbamVkwvWEhjrDe=fp.readlines()
   fp.close()
  except:
   xRifPJdSGAUnsNTzbamVkwvWEhjrDe=[]
  return xRifPJdSGAUnsNTzbamVkwvWEhjrDe
 def Save_Watched_List(xRifPJdSGAUnsNTzbamVkwvWEhjrFq,xRifPJdSGAUnsNTzbamVkwvWEhjrpB,xRifPJdSGAUnsNTzbamVkwvWEhjrFl):
  try:
   xRifPJdSGAUnsNTzbamVkwvWEhjrDg=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%xRifPJdSGAUnsNTzbamVkwvWEhjrpB))
   xRifPJdSGAUnsNTzbamVkwvWEhjrDK=xRifPJdSGAUnsNTzbamVkwvWEhjrFq.Load_Watched_List(xRifPJdSGAUnsNTzbamVkwvWEhjrpB) 
   fp=xRifPJdSGAUnsNTzbamVkwvWEhjrtu(xRifPJdSGAUnsNTzbamVkwvWEhjrDg,'w',-1,'utf-8')
   xRifPJdSGAUnsNTzbamVkwvWEhjrDI=urllib.parse.urlencode(xRifPJdSGAUnsNTzbamVkwvWEhjrFl)
   xRifPJdSGAUnsNTzbamVkwvWEhjrDI=xRifPJdSGAUnsNTzbamVkwvWEhjrDI+'\n'
   fp.write(xRifPJdSGAUnsNTzbamVkwvWEhjrDI)
   xRifPJdSGAUnsNTzbamVkwvWEhjrDq=0
   for xRifPJdSGAUnsNTzbamVkwvWEhjrDM in xRifPJdSGAUnsNTzbamVkwvWEhjrDK:
    xRifPJdSGAUnsNTzbamVkwvWEhjrDC=xRifPJdSGAUnsNTzbamVkwvWEhjrtg(urllib.parse.parse_qsl(xRifPJdSGAUnsNTzbamVkwvWEhjrDM))
    xRifPJdSGAUnsNTzbamVkwvWEhjrDl=xRifPJdSGAUnsNTzbamVkwvWEhjrFl.get('code')
    xRifPJdSGAUnsNTzbamVkwvWEhjrDo=xRifPJdSGAUnsNTzbamVkwvWEhjrDC.get('code')
    if xRifPJdSGAUnsNTzbamVkwvWEhjrpB=='vod' and xRifPJdSGAUnsNTzbamVkwvWEhjrFq.get_settings_direct_replay()==xRifPJdSGAUnsNTzbamVkwvWEhjrtF:
     xRifPJdSGAUnsNTzbamVkwvWEhjrDl=xRifPJdSGAUnsNTzbamVkwvWEhjrFl.get('videoid')
     xRifPJdSGAUnsNTzbamVkwvWEhjrDo=xRifPJdSGAUnsNTzbamVkwvWEhjrDC.get('videoid')if xRifPJdSGAUnsNTzbamVkwvWEhjrDo!=xRifPJdSGAUnsNTzbamVkwvWEhjruL else '-'
    if xRifPJdSGAUnsNTzbamVkwvWEhjrDl!=xRifPJdSGAUnsNTzbamVkwvWEhjrDo:
     fp.write(xRifPJdSGAUnsNTzbamVkwvWEhjrDM)
     xRifPJdSGAUnsNTzbamVkwvWEhjrDq+=1
     if xRifPJdSGAUnsNTzbamVkwvWEhjrDq>=50:break
   fp.close()
  except:
   xRifPJdSGAUnsNTzbamVkwvWEhjruL
 def dp_Watch_List(xRifPJdSGAUnsNTzbamVkwvWEhjrFq,xRifPJdSGAUnsNTzbamVkwvWEhjrOD):
  xRifPJdSGAUnsNTzbamVkwvWEhjrpB =xRifPJdSGAUnsNTzbamVkwvWEhjrOD.get('stype')
  xRifPJdSGAUnsNTzbamVkwvWEhjrpF=xRifPJdSGAUnsNTzbamVkwvWEhjrFq.get_settings_direct_replay()
  if xRifPJdSGAUnsNTzbamVkwvWEhjrpB=='-':
   for xRifPJdSGAUnsNTzbamVkwvWEhjrOp in xRifPJdSGAUnsNTzbamVkwvWEhjrFu:
    xRifPJdSGAUnsNTzbamVkwvWEhjrpg=xRifPJdSGAUnsNTzbamVkwvWEhjrOp.get('title')
    xRifPJdSGAUnsNTzbamVkwvWEhjrpC={'mode':xRifPJdSGAUnsNTzbamVkwvWEhjrOp.get('mode'),'stype':xRifPJdSGAUnsNTzbamVkwvWEhjrOp.get('stype')}
    xRifPJdSGAUnsNTzbamVkwvWEhjrFq.add_dir(xRifPJdSGAUnsNTzbamVkwvWEhjrpg,sublabel='',img='',infoLabels=xRifPJdSGAUnsNTzbamVkwvWEhjruL,isFolder=xRifPJdSGAUnsNTzbamVkwvWEhjrtF,params=xRifPJdSGAUnsNTzbamVkwvWEhjrpC)
   if xRifPJdSGAUnsNTzbamVkwvWEhjrtO(xRifPJdSGAUnsNTzbamVkwvWEhjrFu)>0:xbmcplugin.endOfDirectory(xRifPJdSGAUnsNTzbamVkwvWEhjrFq._addon_handle)
  else:
   xRifPJdSGAUnsNTzbamVkwvWEhjrDy=xRifPJdSGAUnsNTzbamVkwvWEhjrFq.Load_Watched_List(xRifPJdSGAUnsNTzbamVkwvWEhjrpB)
   for xRifPJdSGAUnsNTzbamVkwvWEhjrDH in xRifPJdSGAUnsNTzbamVkwvWEhjrDy:
    xRifPJdSGAUnsNTzbamVkwvWEhjrDc=xRifPJdSGAUnsNTzbamVkwvWEhjrtg(urllib.parse.parse_qsl(xRifPJdSGAUnsNTzbamVkwvWEhjrDH))
    xRifPJdSGAUnsNTzbamVkwvWEhjrpg =xRifPJdSGAUnsNTzbamVkwvWEhjrDc.get('title')
    xRifPJdSGAUnsNTzbamVkwvWEhjrOK=xRifPJdSGAUnsNTzbamVkwvWEhjrDc.get('img')
    xRifPJdSGAUnsNTzbamVkwvWEhjrDY =xRifPJdSGAUnsNTzbamVkwvWEhjrDc.get('videoid')
    xRifPJdSGAUnsNTzbamVkwvWEhjrOM={}
    xRifPJdSGAUnsNTzbamVkwvWEhjrOM['plot']=xRifPJdSGAUnsNTzbamVkwvWEhjrpg
    if xRifPJdSGAUnsNTzbamVkwvWEhjrpB=='vod':
     if xRifPJdSGAUnsNTzbamVkwvWEhjrpF==xRifPJdSGAUnsNTzbamVkwvWEhjruB or xRifPJdSGAUnsNTzbamVkwvWEhjrDY==xRifPJdSGAUnsNTzbamVkwvWEhjruL:
      xRifPJdSGAUnsNTzbamVkwvWEhjrpC={'mode':'EPISODE','programcode':xRifPJdSGAUnsNTzbamVkwvWEhjrDc.get('code'),'page':'1'}
      xRifPJdSGAUnsNTzbamVkwvWEhjrpl=xRifPJdSGAUnsNTzbamVkwvWEhjrtF
     else:
      xRifPJdSGAUnsNTzbamVkwvWEhjrpC={'mode':'VOD','mediacode':xRifPJdSGAUnsNTzbamVkwvWEhjrDY,'stype':'vod','programcode':xRifPJdSGAUnsNTzbamVkwvWEhjrDc.get('code'),'title':xRifPJdSGAUnsNTzbamVkwvWEhjrpg,'thumbnail':xRifPJdSGAUnsNTzbamVkwvWEhjrOK}
      xRifPJdSGAUnsNTzbamVkwvWEhjrpl=xRifPJdSGAUnsNTzbamVkwvWEhjruB
    else:
     xRifPJdSGAUnsNTzbamVkwvWEhjrpC={'mode':'MOVIE','mediacode':xRifPJdSGAUnsNTzbamVkwvWEhjrDc.get('code'),'stype':'movie','title':xRifPJdSGAUnsNTzbamVkwvWEhjrpg,'thumbnail':xRifPJdSGAUnsNTzbamVkwvWEhjrOK}
     xRifPJdSGAUnsNTzbamVkwvWEhjrpl=xRifPJdSGAUnsNTzbamVkwvWEhjruB
    xRifPJdSGAUnsNTzbamVkwvWEhjrFq.add_dir(xRifPJdSGAUnsNTzbamVkwvWEhjrpg,sublabel='',img=xRifPJdSGAUnsNTzbamVkwvWEhjrOK,infoLabels=xRifPJdSGAUnsNTzbamVkwvWEhjrOM,isFolder=xRifPJdSGAUnsNTzbamVkwvWEhjrpl,params=xRifPJdSGAUnsNTzbamVkwvWEhjrpC)
   xRifPJdSGAUnsNTzbamVkwvWEhjrOM={'plot':'시청목록을 삭제합니다.'}
   xRifPJdSGAUnsNTzbamVkwvWEhjrpg='*** 시청목록 삭제 ***'
   xRifPJdSGAUnsNTzbamVkwvWEhjrpC={'mode':'MYVIEW_REMOVE','stype':xRifPJdSGAUnsNTzbamVkwvWEhjrpB}
   xRifPJdSGAUnsNTzbamVkwvWEhjrFq.add_dir(xRifPJdSGAUnsNTzbamVkwvWEhjrpg,sublabel='',img='',infoLabels=xRifPJdSGAUnsNTzbamVkwvWEhjrOM,isFolder=xRifPJdSGAUnsNTzbamVkwvWEhjruB,params=xRifPJdSGAUnsNTzbamVkwvWEhjrpC)
   xbmcplugin.endOfDirectory(xRifPJdSGAUnsNTzbamVkwvWEhjrFq._addon_handle,cacheToDisc=xRifPJdSGAUnsNTzbamVkwvWEhjruB)
 def play_VIDEO(xRifPJdSGAUnsNTzbamVkwvWEhjrFq,xRifPJdSGAUnsNTzbamVkwvWEhjrOD):
  xRifPJdSGAUnsNTzbamVkwvWEhjrFq.TvingObj.SaveCredential(xRifPJdSGAUnsNTzbamVkwvWEhjrFq.get_winCredential())
  xRifPJdSGAUnsNTzbamVkwvWEhjrDQ =xRifPJdSGAUnsNTzbamVkwvWEhjrOD.get('mediacode')
  xRifPJdSGAUnsNTzbamVkwvWEhjrpB =xRifPJdSGAUnsNTzbamVkwvWEhjrOD.get('stype')
  xRifPJdSGAUnsNTzbamVkwvWEhjrDL=xRifPJdSGAUnsNTzbamVkwvWEhjrFq.get_selQuality(xRifPJdSGAUnsNTzbamVkwvWEhjrpB)
  xRifPJdSGAUnsNTzbamVkwvWEhjrDB,xRifPJdSGAUnsNTzbamVkwvWEhjruF=xRifPJdSGAUnsNTzbamVkwvWEhjrFq.TvingObj.GetBroadURL(xRifPJdSGAUnsNTzbamVkwvWEhjrDQ,xRifPJdSGAUnsNTzbamVkwvWEhjrDL,xRifPJdSGAUnsNTzbamVkwvWEhjrpB)
  xRifPJdSGAUnsNTzbamVkwvWEhjrFq.addon_log('qt, stype, url : %s - %s - %s'%(xRifPJdSGAUnsNTzbamVkwvWEhjrtD(xRifPJdSGAUnsNTzbamVkwvWEhjrDL),xRifPJdSGAUnsNTzbamVkwvWEhjrpB,xRifPJdSGAUnsNTzbamVkwvWEhjrDB))
  if xRifPJdSGAUnsNTzbamVkwvWEhjrDB=='':
   xRifPJdSGAUnsNTzbamVkwvWEhjrFq.addon_noti(__language__(30908).encode('utf8'))
   return
  xRifPJdSGAUnsNTzbamVkwvWEhjrup =xRifPJdSGAUnsNTzbamVkwvWEhjrDB.find('Policy=')
  if xRifPJdSGAUnsNTzbamVkwvWEhjrup!=-1:
   xRifPJdSGAUnsNTzbamVkwvWEhjruO =xRifPJdSGAUnsNTzbamVkwvWEhjrDB.split('?')[0]
   xRifPJdSGAUnsNTzbamVkwvWEhjruD=xRifPJdSGAUnsNTzbamVkwvWEhjrtg(urllib.parse.parse_qsl(urllib.parse.urlsplit(xRifPJdSGAUnsNTzbamVkwvWEhjrDB).query))
   xRifPJdSGAUnsNTzbamVkwvWEhjruD=urllib.parse.urlencode(xRifPJdSGAUnsNTzbamVkwvWEhjruD)
   xRifPJdSGAUnsNTzbamVkwvWEhjruD=xRifPJdSGAUnsNTzbamVkwvWEhjruD.replace('&',';')
   xRifPJdSGAUnsNTzbamVkwvWEhjruD=xRifPJdSGAUnsNTzbamVkwvWEhjruD.replace('Policy','CloudFront-Policy')
   xRifPJdSGAUnsNTzbamVkwvWEhjruD=xRifPJdSGAUnsNTzbamVkwvWEhjruD.replace('Signature','CloudFront-Signature')
   xRifPJdSGAUnsNTzbamVkwvWEhjruD=xRifPJdSGAUnsNTzbamVkwvWEhjruD.replace('Key-Pair-Id','CloudFront-Key-Pair-Id')
   xRifPJdSGAUnsNTzbamVkwvWEhjrut='%s|Cookie=%s'%(xRifPJdSGAUnsNTzbamVkwvWEhjruO,xRifPJdSGAUnsNTzbamVkwvWEhjruD)
  else:
   xRifPJdSGAUnsNTzbamVkwvWEhjrut=xRifPJdSGAUnsNTzbamVkwvWEhjrDB
  xRifPJdSGAUnsNTzbamVkwvWEhjrFq.addon_log(xRifPJdSGAUnsNTzbamVkwvWEhjrut)
  xRifPJdSGAUnsNTzbamVkwvWEhjrug=xbmcgui.ListItem(path=xRifPJdSGAUnsNTzbamVkwvWEhjrut)
  if xRifPJdSGAUnsNTzbamVkwvWEhjruF!='':
   xRifPJdSGAUnsNTzbamVkwvWEhjrue=xRifPJdSGAUnsNTzbamVkwvWEhjruF
   xRifPJdSGAUnsNTzbamVkwvWEhjruK ='https://cj.drmkeyserver.com/widevine_license'
   xRifPJdSGAUnsNTzbamVkwvWEhjruI ='mpd'
   xRifPJdSGAUnsNTzbamVkwvWEhjruq ='com.widevine.alpha'
   xRifPJdSGAUnsNTzbamVkwvWEhjruM =inputstreamhelper.Helper(xRifPJdSGAUnsNTzbamVkwvWEhjruI,drm='widevine')
   if xRifPJdSGAUnsNTzbamVkwvWEhjruM.check_inputstream():
    xRifPJdSGAUnsNTzbamVkwvWEhjruC={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/live/player/%s'%xRifPJdSGAUnsNTzbamVkwvWEhjrDQ,'sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':xRifPJdSGAUnsNTzbamVkwvWEhjrFK,'AcquireLicenseAssertion':xRifPJdSGAUnsNTzbamVkwvWEhjrue,'Host':'cj.drmkeyserver.com'}
    xRifPJdSGAUnsNTzbamVkwvWEhjrul=xRifPJdSGAUnsNTzbamVkwvWEhjruK+'|'+urllib.parse.urlencode(xRifPJdSGAUnsNTzbamVkwvWEhjruC)+'|R{SSM}|'
    xRifPJdSGAUnsNTzbamVkwvWEhjrug.setProperty('inputstream',xRifPJdSGAUnsNTzbamVkwvWEhjruM.inputstream_addon)
    xRifPJdSGAUnsNTzbamVkwvWEhjrug.setProperty('inputstream.adaptive.manifest_type',xRifPJdSGAUnsNTzbamVkwvWEhjruI)
    xRifPJdSGAUnsNTzbamVkwvWEhjrug.setProperty('inputstream.adaptive.license_type',xRifPJdSGAUnsNTzbamVkwvWEhjruq)
    xRifPJdSGAUnsNTzbamVkwvWEhjrug.setProperty('inputstream.adaptive.license_key',xRifPJdSGAUnsNTzbamVkwvWEhjrul)
    xRifPJdSGAUnsNTzbamVkwvWEhjrug.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(xRifPJdSGAUnsNTzbamVkwvWEhjrFK))
  xbmcplugin.setResolvedUrl(xRifPJdSGAUnsNTzbamVkwvWEhjrFq._addon_handle,xRifPJdSGAUnsNTzbamVkwvWEhjrtF,xRifPJdSGAUnsNTzbamVkwvWEhjrug)
  try:
   if xRifPJdSGAUnsNTzbamVkwvWEhjrOD.get('mode')in['VOD','MOVIE']and xRifPJdSGAUnsNTzbamVkwvWEhjrOD.get('title'):
    xRifPJdSGAUnsNTzbamVkwvWEhjrpC={'code':xRifPJdSGAUnsNTzbamVkwvWEhjrOD.get('programcode')if xRifPJdSGAUnsNTzbamVkwvWEhjrOD.get('mode')=='VOD' else xRifPJdSGAUnsNTzbamVkwvWEhjrOD.get('mediacode'),'img':xRifPJdSGAUnsNTzbamVkwvWEhjrOD.get('thumbnail'),'title':xRifPJdSGAUnsNTzbamVkwvWEhjrOD.get('title'),'videoid':xRifPJdSGAUnsNTzbamVkwvWEhjrOD.get('mediacode')}
    xRifPJdSGAUnsNTzbamVkwvWEhjrFq.Save_Watched_List(xRifPJdSGAUnsNTzbamVkwvWEhjrOD.get('stype'),xRifPJdSGAUnsNTzbamVkwvWEhjrpC)
  except:
   xRifPJdSGAUnsNTzbamVkwvWEhjruL
 def logout(xRifPJdSGAUnsNTzbamVkwvWEhjrFq):
  xRifPJdSGAUnsNTzbamVkwvWEhjrFy=xbmcgui.Dialog()
  xRifPJdSGAUnsNTzbamVkwvWEhjrpY=xRifPJdSGAUnsNTzbamVkwvWEhjrFy.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if xRifPJdSGAUnsNTzbamVkwvWEhjrpY==xRifPJdSGAUnsNTzbamVkwvWEhjruB:sys.exit()
  xRifPJdSGAUnsNTzbamVkwvWEhjrFq.wininfo_clear()
  if os.path.isfile(xRifPJdSGAUnsNTzbamVkwvWEhjrFI):os.remove(xRifPJdSGAUnsNTzbamVkwvWEhjrFI)
  xRifPJdSGAUnsNTzbamVkwvWEhjrFq.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(xRifPJdSGAUnsNTzbamVkwvWEhjrFq):
  xRifPJdSGAUnsNTzbamVkwvWEhjrpD=xbmcgui.Window(10000)
  xRifPJdSGAUnsNTzbamVkwvWEhjrpD.setProperty('TVING_M_TOKEN','')
  xRifPJdSGAUnsNTzbamVkwvWEhjrpD.setProperty('TVING_M_USERINFO','')
  xRifPJdSGAUnsNTzbamVkwvWEhjrpD.setProperty('TVING_M_UUID','')
  xRifPJdSGAUnsNTzbamVkwvWEhjrpD.setProperty('TVING_M_LOGINTIME','')
 def cookiefile_save(xRifPJdSGAUnsNTzbamVkwvWEhjrFq):
  xRifPJdSGAUnsNTzbamVkwvWEhjruo =xRifPJdSGAUnsNTzbamVkwvWEhjrFq.TvingObj.Get_Now_Datetime()
  xRifPJdSGAUnsNTzbamVkwvWEhjruy=xRifPJdSGAUnsNTzbamVkwvWEhjruo+datetime.timedelta(days=xRifPJdSGAUnsNTzbamVkwvWEhjrtp(__addon__.getSetting('cache_ttl')))
  xRifPJdSGAUnsNTzbamVkwvWEhjrpD=xbmcgui.Window(10000)
  xRifPJdSGAUnsNTzbamVkwvWEhjruH={'tving_token':xRifPJdSGAUnsNTzbamVkwvWEhjrpD.getProperty('TVING_M_TOKEN'),'tving_userinfo':xRifPJdSGAUnsNTzbamVkwvWEhjrpD.getProperty('TVING_M_USERINFO'),'tving_uuid':xRifPJdSGAUnsNTzbamVkwvWEhjrpD.getProperty('TVING_M_UUID'),'tving_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'tving_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'tving_logintype':__addon__.getSetting('login_type'),'tving_limitdate':xRifPJdSGAUnsNTzbamVkwvWEhjruy.strftime('%Y-%m-%d')}
  try: 
   fp=xRifPJdSGAUnsNTzbamVkwvWEhjrtu(xRifPJdSGAUnsNTzbamVkwvWEhjrFI,'w',-1,'utf-8')
   json.dump(xRifPJdSGAUnsNTzbamVkwvWEhjruH,fp)
   fp.close()
  except xRifPJdSGAUnsNTzbamVkwvWEhjrte as exception:
   xRifPJdSGAUnsNTzbamVkwvWEhjrtK(exception)
 def cookiefile_check(xRifPJdSGAUnsNTzbamVkwvWEhjrFq):
  xRifPJdSGAUnsNTzbamVkwvWEhjruH={}
  try: 
   fp=xRifPJdSGAUnsNTzbamVkwvWEhjrtu(xRifPJdSGAUnsNTzbamVkwvWEhjrFI,'r',-1,'utf-8')
   xRifPJdSGAUnsNTzbamVkwvWEhjruH= json.load(fp)
   fp.close()
  except xRifPJdSGAUnsNTzbamVkwvWEhjrte as exception:
   xRifPJdSGAUnsNTzbamVkwvWEhjrFq.wininfo_clear()
   return xRifPJdSGAUnsNTzbamVkwvWEhjruB
  xRifPJdSGAUnsNTzbamVkwvWEhjrpy =__addon__.getSetting('id')
  xRifPJdSGAUnsNTzbamVkwvWEhjrpH =__addon__.getSetting('pw')
  xRifPJdSGAUnsNTzbamVkwvWEhjruc=__addon__.getSetting('login_type')
  xRifPJdSGAUnsNTzbamVkwvWEhjruH['tving_id']=base64.standard_b64decode(xRifPJdSGAUnsNTzbamVkwvWEhjruH['tving_id']).decode('utf-8')
  xRifPJdSGAUnsNTzbamVkwvWEhjruH['tving_pw']=base64.standard_b64decode(xRifPJdSGAUnsNTzbamVkwvWEhjruH['tving_pw']).decode('utf-8')
  if xRifPJdSGAUnsNTzbamVkwvWEhjrpy!=xRifPJdSGAUnsNTzbamVkwvWEhjruH['tving_id']or xRifPJdSGAUnsNTzbamVkwvWEhjrpH!=xRifPJdSGAUnsNTzbamVkwvWEhjruH['tving_pw']or xRifPJdSGAUnsNTzbamVkwvWEhjruc!=xRifPJdSGAUnsNTzbamVkwvWEhjruH['tving_logintype']:
   xRifPJdSGAUnsNTzbamVkwvWEhjrFq.wininfo_clear()
   return xRifPJdSGAUnsNTzbamVkwvWEhjruB
  xRifPJdSGAUnsNTzbamVkwvWEhjrpX =xRifPJdSGAUnsNTzbamVkwvWEhjrtp(xRifPJdSGAUnsNTzbamVkwvWEhjrFq.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  xRifPJdSGAUnsNTzbamVkwvWEhjruY=xRifPJdSGAUnsNTzbamVkwvWEhjruH['tving_limitdate']
  xRifPJdSGAUnsNTzbamVkwvWEhjrpQ =xRifPJdSGAUnsNTzbamVkwvWEhjrtp(re.sub('-','',xRifPJdSGAUnsNTzbamVkwvWEhjruY))
  if xRifPJdSGAUnsNTzbamVkwvWEhjrpQ<xRifPJdSGAUnsNTzbamVkwvWEhjrpX:
   xRifPJdSGAUnsNTzbamVkwvWEhjrFq.wininfo_clear()
   return xRifPJdSGAUnsNTzbamVkwvWEhjruB
  xRifPJdSGAUnsNTzbamVkwvWEhjrpD=xbmcgui.Window(10000)
  xRifPJdSGAUnsNTzbamVkwvWEhjrpD.setProperty('TVING_M_TOKEN',xRifPJdSGAUnsNTzbamVkwvWEhjruH['tving_token'])
  xRifPJdSGAUnsNTzbamVkwvWEhjrpD.setProperty('TVING_M_USERINFO',xRifPJdSGAUnsNTzbamVkwvWEhjruH['tving_userinfo'])
  xRifPJdSGAUnsNTzbamVkwvWEhjrpD.setProperty('TVING_M_UUID',xRifPJdSGAUnsNTzbamVkwvWEhjruH['tving_uuid'])
  xRifPJdSGAUnsNTzbamVkwvWEhjrpD.setProperty('TVING_M_LOGINTIME',xRifPJdSGAUnsNTzbamVkwvWEhjruY)
  return xRifPJdSGAUnsNTzbamVkwvWEhjrtF
 def tving_main(xRifPJdSGAUnsNTzbamVkwvWEhjrFq):
  xRifPJdSGAUnsNTzbamVkwvWEhjruX=xRifPJdSGAUnsNTzbamVkwvWEhjrFq.main_params.get('mode',xRifPJdSGAUnsNTzbamVkwvWEhjruL)
  if xRifPJdSGAUnsNTzbamVkwvWEhjruX=='LOGOUT':
   xRifPJdSGAUnsNTzbamVkwvWEhjrFq.logout()
   return
  xRifPJdSGAUnsNTzbamVkwvWEhjrFq.login_main()
  if xRifPJdSGAUnsNTzbamVkwvWEhjruX is xRifPJdSGAUnsNTzbamVkwvWEhjruL:
   xRifPJdSGAUnsNTzbamVkwvWEhjrFq.dp_Main_List()
  elif xRifPJdSGAUnsNTzbamVkwvWEhjruX in['LIVE_GROUP','VOD_GROUP']:
   xRifPJdSGAUnsNTzbamVkwvWEhjrFq.dp_Title_Group(xRifPJdSGAUnsNTzbamVkwvWEhjrFq.main_params)
  elif xRifPJdSGAUnsNTzbamVkwvWEhjruX=='CHANNEL':
   xRifPJdSGAUnsNTzbamVkwvWEhjrFq.dp_LiveChannel_List(xRifPJdSGAUnsNTzbamVkwvWEhjrFq.main_params)
  elif xRifPJdSGAUnsNTzbamVkwvWEhjruX in['LIVE','VOD','MOVIE']:
   xRifPJdSGAUnsNTzbamVkwvWEhjrFq.play_VIDEO(xRifPJdSGAUnsNTzbamVkwvWEhjrFq.main_params)
  elif xRifPJdSGAUnsNTzbamVkwvWEhjruX=='PROGRAM':
   xRifPJdSGAUnsNTzbamVkwvWEhjrFq.dp_Program_List(xRifPJdSGAUnsNTzbamVkwvWEhjrFq.main_params)
  elif xRifPJdSGAUnsNTzbamVkwvWEhjruX=='EPISODE':
   xRifPJdSGAUnsNTzbamVkwvWEhjrFq.dp_Episode_List(xRifPJdSGAUnsNTzbamVkwvWEhjrFq.main_params)
  elif xRifPJdSGAUnsNTzbamVkwvWEhjruX=='MOVIE_GROUP':
   xRifPJdSGAUnsNTzbamVkwvWEhjrFq.dp_Movie_List(xRifPJdSGAUnsNTzbamVkwvWEhjrFq.main_params)
  elif xRifPJdSGAUnsNTzbamVkwvWEhjruX=='SEARCH_GROUP':
   xRifPJdSGAUnsNTzbamVkwvWEhjrFq.dp_Search_Group(xRifPJdSGAUnsNTzbamVkwvWEhjrFq.main_params)
  elif xRifPJdSGAUnsNTzbamVkwvWEhjruX=='SEARCH':
   xRifPJdSGAUnsNTzbamVkwvWEhjrFq.dp_Search_List(xRifPJdSGAUnsNTzbamVkwvWEhjrFq.main_params)
  elif xRifPJdSGAUnsNTzbamVkwvWEhjruX=='WATCH':
   xRifPJdSGAUnsNTzbamVkwvWEhjrFq.dp_Watch_List(xRifPJdSGAUnsNTzbamVkwvWEhjrFq.main_params)
  elif xRifPJdSGAUnsNTzbamVkwvWEhjruX=='MYVIEW_REMOVE':
   xRifPJdSGAUnsNTzbamVkwvWEhjrFq.dp_WatchList_Delete(xRifPJdSGAUnsNTzbamVkwvWEhjrFq.main_params)
  elif xRifPJdSGAUnsNTzbamVkwvWEhjruX=='ORDER_BY':
   xRifPJdSGAUnsNTzbamVkwvWEhjrFq.dp_setEpOrderby(xRifPJdSGAUnsNTzbamVkwvWEhjrFq.main_params)
  else:
   xRifPJdSGAUnsNTzbamVkwvWEhjruL
# Created by pyminifier (https://github.com/liftoff/pyminifier)
