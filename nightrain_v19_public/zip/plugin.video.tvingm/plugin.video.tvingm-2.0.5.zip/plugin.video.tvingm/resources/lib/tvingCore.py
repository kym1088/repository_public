__author__="NightRain"
xdfVWcPiUhOINtmavXDGzjABLKTbMJ=object
xdfVWcPiUhOINtmavXDGzjABLKTbMn=None
xdfVWcPiUhOINtmavXDGzjABLKTbMo=False
xdfVWcPiUhOINtmavXDGzjABLKTbCY=int
xdfVWcPiUhOINtmavXDGzjABLKTbCq=True
xdfVWcPiUhOINtmavXDGzjABLKTbCg=Exception
xdfVWcPiUhOINtmavXDGzjABLKTbCM=print
xdfVWcPiUhOINtmavXDGzjABLKTbCS=str
xdfVWcPiUhOINtmavXDGzjABLKTbCF=list
xdfVWcPiUhOINtmavXDGzjABLKTbCr=range
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import requests
import datetime
xdfVWcPiUhOINtmavXDGzjABLKTbYg ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
xdfVWcPiUhOINtmavXDGzjABLKTbYM={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
class xdfVWcPiUhOINtmavXDGzjABLKTbYq(xdfVWcPiUhOINtmavXDGzjABLKTbMJ):
 def __init__(xdfVWcPiUhOINtmavXDGzjABLKTbYC):
  xdfVWcPiUhOINtmavXDGzjABLKTbYC.TVING_TOKEN =''
  xdfVWcPiUhOINtmavXDGzjABLKTbYC.POC_USERINFO =''
  xdfVWcPiUhOINtmavXDGzjABLKTbYC.TVING_UUID ='-'
  xdfVWcPiUhOINtmavXDGzjABLKTbYC.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  xdfVWcPiUhOINtmavXDGzjABLKTbYC.NETWORKCODE ='CSND0900'
  xdfVWcPiUhOINtmavXDGzjABLKTbYC.OSCODE ='CSOD0900' 
  xdfVWcPiUhOINtmavXDGzjABLKTbYC.TELECODE ='CSCD0900'
  xdfVWcPiUhOINtmavXDGzjABLKTbYC.SCREENCODE ='CSSD0100'
  xdfVWcPiUhOINtmavXDGzjABLKTbYC.LIVE_LIMIT =23
  xdfVWcPiUhOINtmavXDGzjABLKTbYC.VOD_LIMIT =20
  xdfVWcPiUhOINtmavXDGzjABLKTbYC.EPISODE_LIMIT=30 
  xdfVWcPiUhOINtmavXDGzjABLKTbYC.SEARCH_LIMIT =80 
  xdfVWcPiUhOINtmavXDGzjABLKTbYC.MOVIE_LIMIT =18
  xdfVWcPiUhOINtmavXDGzjABLKTbYC.API_DOMAIN ='https://api.tving.com'
  xdfVWcPiUhOINtmavXDGzjABLKTbYC.IMG_DOMAIN ='https://image.tving.com'
  xdfVWcPiUhOINtmavXDGzjABLKTbYC.SEARCH_DOMAIN='https://search.tving.com'
  xdfVWcPiUhOINtmavXDGzjABLKTbYC.LOGIN_DOMAIN ='https://user.tving.com'
  xdfVWcPiUhOINtmavXDGzjABLKTbYC.URL_DOMAIN ='https://www.tving.com'
  xdfVWcPiUhOINtmavXDGzjABLKTbYC.MOVIE_LITE ='338723'
  xdfVWcPiUhOINtmavXDGzjABLKTbYC.MOVIE_PREMIUM='1513561'
  xdfVWcPiUhOINtmavXDGzjABLKTbYC.DEFAULT_HEADER={'user-agent':xdfVWcPiUhOINtmavXDGzjABLKTbYg}
 def callRequestCookies(xdfVWcPiUhOINtmavXDGzjABLKTbYC,jobtype,xdfVWcPiUhOINtmavXDGzjABLKTbYp,payload=xdfVWcPiUhOINtmavXDGzjABLKTbMn,params=xdfVWcPiUhOINtmavXDGzjABLKTbMn,headers=xdfVWcPiUhOINtmavXDGzjABLKTbMn,cookies=xdfVWcPiUhOINtmavXDGzjABLKTbMn,redirects=xdfVWcPiUhOINtmavXDGzjABLKTbMo):
  xdfVWcPiUhOINtmavXDGzjABLKTbYS=xdfVWcPiUhOINtmavXDGzjABLKTbYC.DEFAULT_HEADER
  if headers:xdfVWcPiUhOINtmavXDGzjABLKTbYS.update(headers)
  if jobtype=='Get':
   xdfVWcPiUhOINtmavXDGzjABLKTbYF=requests.get(xdfVWcPiUhOINtmavXDGzjABLKTbYp,params=params,headers=xdfVWcPiUhOINtmavXDGzjABLKTbYS,cookies=cookies,allow_redirects=redirects)
  else:
   xdfVWcPiUhOINtmavXDGzjABLKTbYF=requests.post(xdfVWcPiUhOINtmavXDGzjABLKTbYp,data=payload,params=params,headers=xdfVWcPiUhOINtmavXDGzjABLKTbYS,cookies=cookies,allow_redirects=redirects)
  return xdfVWcPiUhOINtmavXDGzjABLKTbYF
 def makeDefaultCookies(xdfVWcPiUhOINtmavXDGzjABLKTbYC,vToken=xdfVWcPiUhOINtmavXDGzjABLKTbMn,vUserinfo=xdfVWcPiUhOINtmavXDGzjABLKTbMn):
  xdfVWcPiUhOINtmavXDGzjABLKTbYr={}
  xdfVWcPiUhOINtmavXDGzjABLKTbYr['_tving_token']=xdfVWcPiUhOINtmavXDGzjABLKTbYC.TVING_TOKEN if vToken==xdfVWcPiUhOINtmavXDGzjABLKTbMn else vToken
  xdfVWcPiUhOINtmavXDGzjABLKTbYr['POC_USERINFO']=xdfVWcPiUhOINtmavXDGzjABLKTbYC.POC_USERINFO if vToken==xdfVWcPiUhOINtmavXDGzjABLKTbMn else vUserinfo
  return xdfVWcPiUhOINtmavXDGzjABLKTbYr
 def getDeviceStr(xdfVWcPiUhOINtmavXDGzjABLKTbYC):
  xdfVWcPiUhOINtmavXDGzjABLKTbYE=[]
  xdfVWcPiUhOINtmavXDGzjABLKTbYE.append('Windows') 
  xdfVWcPiUhOINtmavXDGzjABLKTbYE.append('Chrome') 
  xdfVWcPiUhOINtmavXDGzjABLKTbYE.append('ko-KR') 
  xdfVWcPiUhOINtmavXDGzjABLKTbYE.append('undefined') 
  xdfVWcPiUhOINtmavXDGzjABLKTbYE.append('24') 
  xdfVWcPiUhOINtmavXDGzjABLKTbYE.append(u'한국 표준시')
  xdfVWcPiUhOINtmavXDGzjABLKTbYE.append('undefined') 
  xdfVWcPiUhOINtmavXDGzjABLKTbYE.append('undefined') 
  xdfVWcPiUhOINtmavXDGzjABLKTbYE.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  xdfVWcPiUhOINtmavXDGzjABLKTbYw=''
  for xdfVWcPiUhOINtmavXDGzjABLKTbYy in xdfVWcPiUhOINtmavXDGzjABLKTbYE:
   xdfVWcPiUhOINtmavXDGzjABLKTbYw+=xdfVWcPiUhOINtmavXDGzjABLKTbYy+'|'
  return xdfVWcPiUhOINtmavXDGzjABLKTbYw
 def SaveCredential(xdfVWcPiUhOINtmavXDGzjABLKTbYC,xdfVWcPiUhOINtmavXDGzjABLKTbYe):
  xdfVWcPiUhOINtmavXDGzjABLKTbYC.TVING_TOKEN =xdfVWcPiUhOINtmavXDGzjABLKTbYe.get('tving_token')
  xdfVWcPiUhOINtmavXDGzjABLKTbYC.POC_USERINFO=xdfVWcPiUhOINtmavXDGzjABLKTbYe.get('poc_userinfo')
  xdfVWcPiUhOINtmavXDGzjABLKTbYC.TVING_UUID =xdfVWcPiUhOINtmavXDGzjABLKTbYe.get('tving_uuid')
 def LoadCredential(xdfVWcPiUhOINtmavXDGzjABLKTbYC):
  xdfVWcPiUhOINtmavXDGzjABLKTbYe={'tving_token':xdfVWcPiUhOINtmavXDGzjABLKTbYC.TVING_TOKEN,'poc_userinfo':xdfVWcPiUhOINtmavXDGzjABLKTbYC.POC_USERINFO,'tving_uuid':xdfVWcPiUhOINtmavXDGzjABLKTbYC.TVING_UUID}
  return xdfVWcPiUhOINtmavXDGzjABLKTbYe
 def GetDefaultParams(xdfVWcPiUhOINtmavXDGzjABLKTbYC):
  xdfVWcPiUhOINtmavXDGzjABLKTbYR={'apiKey':xdfVWcPiUhOINtmavXDGzjABLKTbYC.APIKEY,'networkCode':xdfVWcPiUhOINtmavXDGzjABLKTbYC.NETWORKCODE,'osCode':xdfVWcPiUhOINtmavXDGzjABLKTbYC.OSCODE,'teleCode':xdfVWcPiUhOINtmavXDGzjABLKTbYC.TELECODE,'screenCode':xdfVWcPiUhOINtmavXDGzjABLKTbYC.SCREENCODE}
  return xdfVWcPiUhOINtmavXDGzjABLKTbYR
 def GetNoCache(xdfVWcPiUhOINtmavXDGzjABLKTbYC,timetype=1):
  if timetype==1:
   return xdfVWcPiUhOINtmavXDGzjABLKTbCY(time.time())
  else:
   return xdfVWcPiUhOINtmavXDGzjABLKTbCY(time.time()*1000)
 def makeurl(xdfVWcPiUhOINtmavXDGzjABLKTbYC,domain,path,query1=xdfVWcPiUhOINtmavXDGzjABLKTbMn,query2=xdfVWcPiUhOINtmavXDGzjABLKTbMn):
  xdfVWcPiUhOINtmavXDGzjABLKTbYp=domain+path
  if query1:
   xdfVWcPiUhOINtmavXDGzjABLKTbYp+='?%s'%urllib.parse.urlencode(query1)
  if query2:
   xdfVWcPiUhOINtmavXDGzjABLKTbYp+='&%s'%urllib.parse.urlencode(query2)
  return xdfVWcPiUhOINtmavXDGzjABLKTbYp
 def GetCredential(xdfVWcPiUhOINtmavXDGzjABLKTbYC,user_id,user_pw,login_type):
  xdfVWcPiUhOINtmavXDGzjABLKTbYl=xdfVWcPiUhOINtmavXDGzjABLKTbMo
  xdfVWcPiUhOINtmavXDGzjABLKTbYH=xdfVWcPiUhOINtmavXDGzjABLKTbqY='' 
  xdfVWcPiUhOINtmavXDGzjABLKTbYu='-'
  try:
   xdfVWcPiUhOINtmavXDGzjABLKTbYQ=xdfVWcPiUhOINtmavXDGzjABLKTbYC.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   xdfVWcPiUhOINtmavXDGzjABLKTbYJ={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'','csite':''}
   xdfVWcPiUhOINtmavXDGzjABLKTbYn=xdfVWcPiUhOINtmavXDGzjABLKTbYC.callRequestCookies('Post',xdfVWcPiUhOINtmavXDGzjABLKTbYQ,payload=xdfVWcPiUhOINtmavXDGzjABLKTbYJ,params=xdfVWcPiUhOINtmavXDGzjABLKTbMn,headers=xdfVWcPiUhOINtmavXDGzjABLKTbMn,cookies=xdfVWcPiUhOINtmavXDGzjABLKTbMn)
   for xdfVWcPiUhOINtmavXDGzjABLKTbYo in xdfVWcPiUhOINtmavXDGzjABLKTbYn.cookies:
    if xdfVWcPiUhOINtmavXDGzjABLKTbYo.name=='_tving_token':
     xdfVWcPiUhOINtmavXDGzjABLKTbYH=xdfVWcPiUhOINtmavXDGzjABLKTbYo.value
    elif xdfVWcPiUhOINtmavXDGzjABLKTbYo.name=='POC_USERINFO':
     xdfVWcPiUhOINtmavXDGzjABLKTbqY=xdfVWcPiUhOINtmavXDGzjABLKTbYo.value
   if xdfVWcPiUhOINtmavXDGzjABLKTbYH:xdfVWcPiUhOINtmavXDGzjABLKTbYl=xdfVWcPiUhOINtmavXDGzjABLKTbCq
   xdfVWcPiUhOINtmavXDGzjABLKTbYu=xdfVWcPiUhOINtmavXDGzjABLKTbYC.GetDeviceList(xdfVWcPiUhOINtmavXDGzjABLKTbYH,xdfVWcPiUhOINtmavXDGzjABLKTbqY)
  except xdfVWcPiUhOINtmavXDGzjABLKTbCg as exception:
   xdfVWcPiUhOINtmavXDGzjABLKTbYH=xdfVWcPiUhOINtmavXDGzjABLKTbqY='' 
   xdfVWcPiUhOINtmavXDGzjABLKTbYu='-'
   xdfVWcPiUhOINtmavXDGzjABLKTbCM(exception)
  xdfVWcPiUhOINtmavXDGzjABLKTbYe={'tving_token':xdfVWcPiUhOINtmavXDGzjABLKTbYH,'poc_userinfo':xdfVWcPiUhOINtmavXDGzjABLKTbqY,'tving_uuid':xdfVWcPiUhOINtmavXDGzjABLKTbYu}
  xdfVWcPiUhOINtmavXDGzjABLKTbYC.SaveCredential(xdfVWcPiUhOINtmavXDGzjABLKTbYe)
  return xdfVWcPiUhOINtmavXDGzjABLKTbYl
 def Get_Now_Datetime(xdfVWcPiUhOINtmavXDGzjABLKTbYC):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(xdfVWcPiUhOINtmavXDGzjABLKTbYC,mediacode,sel_quality,stype):
  xdfVWcPiUhOINtmavXDGzjABLKTbqM=''
  xdfVWcPiUhOINtmavXDGzjABLKTbqC=''
  xdfVWcPiUhOINtmavXDGzjABLKTbqS=xdfVWcPiUhOINtmavXDGzjABLKTbYC.TVING_UUID 
  try:
   if stype!='tvingtv':
    xdfVWcPiUhOINtmavXDGzjABLKTbqF ='/v2/media/stream/info'
    xdfVWcPiUhOINtmavXDGzjABLKTbqr=xdfVWcPiUhOINtmavXDGzjABLKTbYC.GetDefaultParams()
    xdfVWcPiUhOINtmavXDGzjABLKTbqE={'info':'Y','mediaCode':mediacode,'noCache':xdfVWcPiUhOINtmavXDGzjABLKTbCS(xdfVWcPiUhOINtmavXDGzjABLKTbYC.GetNoCache(1)),'callingFrom':'HTML5','adReq':'none','ooc':'','deviceId':xdfVWcPiUhOINtmavXDGzjABLKTbqS,'wm':'Y'}
    xdfVWcPiUhOINtmavXDGzjABLKTbqr.update(xdfVWcPiUhOINtmavXDGzjABLKTbqE)
    xdfVWcPiUhOINtmavXDGzjABLKTbYp=xdfVWcPiUhOINtmavXDGzjABLKTbYC.makeurl(xdfVWcPiUhOINtmavXDGzjABLKTbYC.API_DOMAIN,xdfVWcPiUhOINtmavXDGzjABLKTbqF)
    xdfVWcPiUhOINtmavXDGzjABLKTbYr=xdfVWcPiUhOINtmavXDGzjABLKTbYC.makeDefaultCookies()
    xdfVWcPiUhOINtmavXDGzjABLKTbYn=xdfVWcPiUhOINtmavXDGzjABLKTbYC.callRequestCookies('Get',xdfVWcPiUhOINtmavXDGzjABLKTbYp,payload=xdfVWcPiUhOINtmavXDGzjABLKTbMn,params=xdfVWcPiUhOINtmavXDGzjABLKTbqr,headers=xdfVWcPiUhOINtmavXDGzjABLKTbMn,cookies=xdfVWcPiUhOINtmavXDGzjABLKTbYr)
    xdfVWcPiUhOINtmavXDGzjABLKTbqw=json.loads(xdfVWcPiUhOINtmavXDGzjABLKTbYn.text)
    if not('stream' in xdfVWcPiUhOINtmavXDGzjABLKTbqw['body']):return xdfVWcPiUhOINtmavXDGzjABLKTbqM,xdfVWcPiUhOINtmavXDGzjABLKTbqC 
    xdfVWcPiUhOINtmavXDGzjABLKTbqy=xdfVWcPiUhOINtmavXDGzjABLKTbqw['body']['stream']
    if 'drm_license_assertion' in xdfVWcPiUhOINtmavXDGzjABLKTbqy:
     xdfVWcPiUhOINtmavXDGzjABLKTbqC=xdfVWcPiUhOINtmavXDGzjABLKTbqy['drm_license_assertion']
    xdfVWcPiUhOINtmavXDGzjABLKTbqe=xdfVWcPiUhOINtmavXDGzjABLKTbqy['quality']
    xdfVWcPiUhOINtmavXDGzjABLKTbqR=[]
    for xdfVWcPiUhOINtmavXDGzjABLKTbqp in xdfVWcPiUhOINtmavXDGzjABLKTbqe:
     if xdfVWcPiUhOINtmavXDGzjABLKTbqp['active']=='Y':
      xdfVWcPiUhOINtmavXDGzjABLKTbqR.append({xdfVWcPiUhOINtmavXDGzjABLKTbYM.get(xdfVWcPiUhOINtmavXDGzjABLKTbqp['code']):xdfVWcPiUhOINtmavXDGzjABLKTbqp['code']})
    xdfVWcPiUhOINtmavXDGzjABLKTbqs=xdfVWcPiUhOINtmavXDGzjABLKTbYC.CheckQuality(sel_quality,xdfVWcPiUhOINtmavXDGzjABLKTbqR)
   else:
    for xdfVWcPiUhOINtmavXDGzjABLKTbqk,xdfVWcPiUhOINtmavXDGzjABLKTbgY in xdfVWcPiUhOINtmavXDGzjABLKTbYM.items():
     if xdfVWcPiUhOINtmavXDGzjABLKTbgY==sel_quality:
      xdfVWcPiUhOINtmavXDGzjABLKTbqs=xdfVWcPiUhOINtmavXDGzjABLKTbqk
  except xdfVWcPiUhOINtmavXDGzjABLKTbCg as exception:
   xdfVWcPiUhOINtmavXDGzjABLKTbCM(exception)
   for xdfVWcPiUhOINtmavXDGzjABLKTbqk,xdfVWcPiUhOINtmavXDGzjABLKTbgY in xdfVWcPiUhOINtmavXDGzjABLKTbYM.items():
    if xdfVWcPiUhOINtmavXDGzjABLKTbgY==sel_quality:
     xdfVWcPiUhOINtmavXDGzjABLKTbqs=xdfVWcPiUhOINtmavXDGzjABLKTbqk
   return xdfVWcPiUhOINtmavXDGzjABLKTbqM,xdfVWcPiUhOINtmavXDGzjABLKTbqC
  try:
   xdfVWcPiUhOINtmavXDGzjABLKTbqF ='/streaming/info'
   xdfVWcPiUhOINtmavXDGzjABLKTbqr=xdfVWcPiUhOINtmavXDGzjABLKTbYC.GetDefaultParams()
   if stype=='onair':xdfVWcPiUhOINtmavXDGzjABLKTbqr['osCode']='CSOD0400' 
   xdfVWcPiUhOINtmavXDGzjABLKTbql={'isTrusted':'false','NONE':'0','CAPTURING_PHASE':'1','AT_TARGET':'2','BUBBLING_PHASE':'3','type':'oocCreate','eventPhase':'0','bubbles':'false','cancelable':'false','defaultPrevented':'false','composed':'false','timeStamp':'2158.7350000045262','returnValue':'true','cancelBubble':'false'}
   xdfVWcPiUhOINtmavXDGzjABLKTbqH=xdfVWcPiUhOINtmavXDGzjABLKTbYC.makeOocUrl(xdfVWcPiUhOINtmavXDGzjABLKTbql)
   xdfVWcPiUhOINtmavXDGzjABLKTbqu=urllib.parse.quote(xdfVWcPiUhOINtmavXDGzjABLKTbqH)
   xdfVWcPiUhOINtmavXDGzjABLKTbqE={'info':'Y','mediaCode':mediacode,'callingFrom':'HTML5','streamCode':xdfVWcPiUhOINtmavXDGzjABLKTbqs,'adReq':'none','ooc':xdfVWcPiUhOINtmavXDGzjABLKTbqH,'deviceId':xdfVWcPiUhOINtmavXDGzjABLKTbqS}
   xdfVWcPiUhOINtmavXDGzjABLKTbqQ =xdfVWcPiUhOINtmavXDGzjABLKTbqr
   xdfVWcPiUhOINtmavXDGzjABLKTbqQ.update(xdfVWcPiUhOINtmavXDGzjABLKTbqE)
   xdfVWcPiUhOINtmavXDGzjABLKTbYp=xdfVWcPiUhOINtmavXDGzjABLKTbYC.URL_DOMAIN+xdfVWcPiUhOINtmavXDGzjABLKTbqF
   xdfVWcPiUhOINtmavXDGzjABLKTbqJ={'origin':'https://www.tving.com','Referer':'https://www.tving.com/vod/player/'+mediacode}
   xdfVWcPiUhOINtmavXDGzjABLKTbYr=xdfVWcPiUhOINtmavXDGzjABLKTbYC.makeDefaultCookies()
   xdfVWcPiUhOINtmavXDGzjABLKTbYr['onClickEvent2']=xdfVWcPiUhOINtmavXDGzjABLKTbqu
   xdfVWcPiUhOINtmavXDGzjABLKTbYn=xdfVWcPiUhOINtmavXDGzjABLKTbYC.callRequestCookies('Post',xdfVWcPiUhOINtmavXDGzjABLKTbYp,payload=xdfVWcPiUhOINtmavXDGzjABLKTbqQ,params=xdfVWcPiUhOINtmavXDGzjABLKTbMn,headers=xdfVWcPiUhOINtmavXDGzjABLKTbqJ,cookies=xdfVWcPiUhOINtmavXDGzjABLKTbYr)
   xdfVWcPiUhOINtmavXDGzjABLKTbqw=json.loads(xdfVWcPiUhOINtmavXDGzjABLKTbYn.text)
   if xdfVWcPiUhOINtmavXDGzjABLKTbqC!='':
    xdfVWcPiUhOINtmavXDGzjABLKTbqC =xdfVWcPiUhOINtmavXDGzjABLKTbqw['stream']['drm_license_assertion']
    xdfVWcPiUhOINtmavXDGzjABLKTbqM=xdfVWcPiUhOINtmavXDGzjABLKTbqw['stream']['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in xdfVWcPiUhOINtmavXDGzjABLKTbqw['stream']['broadcast']):return xdfVWcPiUhOINtmavXDGzjABLKTbqM,xdfVWcPiUhOINtmavXDGzjABLKTbqC
    xdfVWcPiUhOINtmavXDGzjABLKTbqM=xdfVWcPiUhOINtmavXDGzjABLKTbqw['stream']['broadcast']['broad_url']
  except xdfVWcPiUhOINtmavXDGzjABLKTbCg as exception:
   xdfVWcPiUhOINtmavXDGzjABLKTbCM(exception)
  return xdfVWcPiUhOINtmavXDGzjABLKTbqM,xdfVWcPiUhOINtmavXDGzjABLKTbqC
 def CheckQuality(xdfVWcPiUhOINtmavXDGzjABLKTbYC,sel_qt,xdfVWcPiUhOINtmavXDGzjABLKTbqR):
  for xdfVWcPiUhOINtmavXDGzjABLKTbqn in xdfVWcPiUhOINtmavXDGzjABLKTbqR:
   if sel_qt>=xdfVWcPiUhOINtmavXDGzjABLKTbCF(xdfVWcPiUhOINtmavXDGzjABLKTbqn)[0]:return xdfVWcPiUhOINtmavXDGzjABLKTbqn.get(xdfVWcPiUhOINtmavXDGzjABLKTbCF(xdfVWcPiUhOINtmavXDGzjABLKTbqn)[0])
   xdfVWcPiUhOINtmavXDGzjABLKTbqo=xdfVWcPiUhOINtmavXDGzjABLKTbqn.get(xdfVWcPiUhOINtmavXDGzjABLKTbCF(xdfVWcPiUhOINtmavXDGzjABLKTbqn)[0])
  return xdfVWcPiUhOINtmavXDGzjABLKTbqo
 def makeOocUrl(xdfVWcPiUhOINtmavXDGzjABLKTbYC,xdfVWcPiUhOINtmavXDGzjABLKTbql):
  xdfVWcPiUhOINtmavXDGzjABLKTbYp=''
  for xdfVWcPiUhOINtmavXDGzjABLKTbqk,xdfVWcPiUhOINtmavXDGzjABLKTbgY in xdfVWcPiUhOINtmavXDGzjABLKTbql.items():
   xdfVWcPiUhOINtmavXDGzjABLKTbYp+="%s=%s^"%(xdfVWcPiUhOINtmavXDGzjABLKTbqk,xdfVWcPiUhOINtmavXDGzjABLKTbgY)
  return xdfVWcPiUhOINtmavXDGzjABLKTbYp
 def GetLiveChannelList(xdfVWcPiUhOINtmavXDGzjABLKTbYC,stype,page_int):
  xdfVWcPiUhOINtmavXDGzjABLKTbgq=[]
  xdfVWcPiUhOINtmavXDGzjABLKTbgM=xdfVWcPiUhOINtmavXDGzjABLKTbMo
  try:
   xdfVWcPiUhOINtmavXDGzjABLKTbqF ='/v2/media/lives'
   if stype=='onair':
    xdfVWcPiUhOINtmavXDGzjABLKTbgC='CPCS0100,CPCS0400'
   else:
    xdfVWcPiUhOINtmavXDGzjABLKTbgC='CPCS0300'
   xdfVWcPiUhOINtmavXDGzjABLKTbqr=xdfVWcPiUhOINtmavXDGzjABLKTbYC.GetDefaultParams()
   xdfVWcPiUhOINtmavXDGzjABLKTbqE={'pageNo':xdfVWcPiUhOINtmavXDGzjABLKTbCS(page_int),'pageSize':xdfVWcPiUhOINtmavXDGzjABLKTbCS(xdfVWcPiUhOINtmavXDGzjABLKTbYC.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':xdfVWcPiUhOINtmavXDGzjABLKTbgC,'_':xdfVWcPiUhOINtmavXDGzjABLKTbCS(xdfVWcPiUhOINtmavXDGzjABLKTbYC.GetNoCache(2))}
   xdfVWcPiUhOINtmavXDGzjABLKTbqr.update(xdfVWcPiUhOINtmavXDGzjABLKTbqE)
   xdfVWcPiUhOINtmavXDGzjABLKTbYp=xdfVWcPiUhOINtmavXDGzjABLKTbYC.makeurl(xdfVWcPiUhOINtmavXDGzjABLKTbYC.API_DOMAIN,xdfVWcPiUhOINtmavXDGzjABLKTbqF)
   xdfVWcPiUhOINtmavXDGzjABLKTbYr=xdfVWcPiUhOINtmavXDGzjABLKTbYC.makeDefaultCookies()
   xdfVWcPiUhOINtmavXDGzjABLKTbYn=xdfVWcPiUhOINtmavXDGzjABLKTbYC.callRequestCookies('Get',xdfVWcPiUhOINtmavXDGzjABLKTbYp,payload=xdfVWcPiUhOINtmavXDGzjABLKTbMn,params=xdfVWcPiUhOINtmavXDGzjABLKTbqr,headers=xdfVWcPiUhOINtmavXDGzjABLKTbMn,cookies=xdfVWcPiUhOINtmavXDGzjABLKTbYr)
   xdfVWcPiUhOINtmavXDGzjABLKTbqw=json.loads(xdfVWcPiUhOINtmavXDGzjABLKTbYn.text)
   if not('result' in xdfVWcPiUhOINtmavXDGzjABLKTbqw['body']):return xdfVWcPiUhOINtmavXDGzjABLKTbgq,xdfVWcPiUhOINtmavXDGzjABLKTbgM
   xdfVWcPiUhOINtmavXDGzjABLKTbgS=xdfVWcPiUhOINtmavXDGzjABLKTbqw['body']['result']
   for xdfVWcPiUhOINtmavXDGzjABLKTbqp in xdfVWcPiUhOINtmavXDGzjABLKTbgS:
    xdfVWcPiUhOINtmavXDGzjABLKTbgF={}
    xdfVWcPiUhOINtmavXDGzjABLKTbgF['mediatype']='video'
    xdfVWcPiUhOINtmavXDGzjABLKTbgr=xdfVWcPiUhOINtmavXDGzjABLKTbgy=xdfVWcPiUhOINtmavXDGzjABLKTbge=xdfVWcPiUhOINtmavXDGzjABLKTbgR=''
    xdfVWcPiUhOINtmavXDGzjABLKTbgE=xdfVWcPiUhOINtmavXDGzjABLKTbgl=''
    xdfVWcPiUhOINtmavXDGzjABLKTbgw=xdfVWcPiUhOINtmavXDGzjABLKTbqp['live_code']
    xdfVWcPiUhOINtmavXDGzjABLKTbgr =xdfVWcPiUhOINtmavXDGzjABLKTbqp['schedule']['channel']['name']['ko']
    if xdfVWcPiUhOINtmavXDGzjABLKTbqp['schedule']['episode']!=xdfVWcPiUhOINtmavXDGzjABLKTbMn:
     xdfVWcPiUhOINtmavXDGzjABLKTbgy =xdfVWcPiUhOINtmavXDGzjABLKTbqp['schedule']['program']['name']['ko']
     xdfVWcPiUhOINtmavXDGzjABLKTbgy =xdfVWcPiUhOINtmavXDGzjABLKTbgy+', '+xdfVWcPiUhOINtmavXDGzjABLKTbCS(xdfVWcPiUhOINtmavXDGzjABLKTbqp['schedule']['episode']['frequency'])+'회'
     if xdfVWcPiUhOINtmavXDGzjABLKTbqp['schedule']['episode']['image']!=[]:
      xdfVWcPiUhOINtmavXDGzjABLKTbge=xdfVWcPiUhOINtmavXDGzjABLKTbqp['schedule']['episode']['image'][0]['url']
     xdfVWcPiUhOINtmavXDGzjABLKTbgR=xdfVWcPiUhOINtmavXDGzjABLKTbqp['schedule']['episode']['synopsis']['ko']
    else:
     xdfVWcPiUhOINtmavXDGzjABLKTbgy =xdfVWcPiUhOINtmavXDGzjABLKTbqp['schedule']['program']['name']['ko']
     if xdfVWcPiUhOINtmavXDGzjABLKTbqp['schedule']['program']['image']!=[]:
      xdfVWcPiUhOINtmavXDGzjABLKTbge=xdfVWcPiUhOINtmavXDGzjABLKTbqp['schedule']['program']['image'][0]['url']
     xdfVWcPiUhOINtmavXDGzjABLKTbgR=xdfVWcPiUhOINtmavXDGzjABLKTbqp['schedule']['program']['synopsis']['ko']
    xdfVWcPiUhOINtmavXDGzjABLKTbgF['title'] =xdfVWcPiUhOINtmavXDGzjABLKTbqp['schedule']['program']['name']['ko']
    xdfVWcPiUhOINtmavXDGzjABLKTbgF['studio'] =xdfVWcPiUhOINtmavXDGzjABLKTbgr
    try:
     xdfVWcPiUhOINtmavXDGzjABLKTbgp=[]
     for xdfVWcPiUhOINtmavXDGzjABLKTbgs in xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('schedule').get('program').get('actor'):xdfVWcPiUhOINtmavXDGzjABLKTbgp.append(xdfVWcPiUhOINtmavXDGzjABLKTbgs)
     if xdfVWcPiUhOINtmavXDGzjABLKTbgp[0]!='' and xdfVWcPiUhOINtmavXDGzjABLKTbgp[0]!=u'없음':xdfVWcPiUhOINtmavXDGzjABLKTbgF['cast']=xdfVWcPiUhOINtmavXDGzjABLKTbgp
    except:
     xdfVWcPiUhOINtmavXDGzjABLKTbMn
    try:
     xdfVWcPiUhOINtmavXDGzjABLKTbgk=[]
     if xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('schedule').get('program').get('category1_name').get('ko')!='':
      xdfVWcPiUhOINtmavXDGzjABLKTbgk.append(xdfVWcPiUhOINtmavXDGzjABLKTbqp['schedule']['program']['category1_name']['ko'])
     if xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('schedule').get('program').get('category2_name').get('ko')!='':
      xdfVWcPiUhOINtmavXDGzjABLKTbgk.append(xdfVWcPiUhOINtmavXDGzjABLKTbqp['schedule']['program']['category2_name']['ko'])
     if xdfVWcPiUhOINtmavXDGzjABLKTbgk[0]!='':xdfVWcPiUhOINtmavXDGzjABLKTbgF['genre']=xdfVWcPiUhOINtmavXDGzjABLKTbgk
    except:
     xdfVWcPiUhOINtmavXDGzjABLKTbMn
    if xdfVWcPiUhOINtmavXDGzjABLKTbge=='':
     xdfVWcPiUhOINtmavXDGzjABLKTbge=xdfVWcPiUhOINtmavXDGzjABLKTbqp['schedule']['channel']['image'][0]['url']
    if xdfVWcPiUhOINtmavXDGzjABLKTbge!='':xdfVWcPiUhOINtmavXDGzjABLKTbge=xdfVWcPiUhOINtmavXDGzjABLKTbYC.IMG_DOMAIN+xdfVWcPiUhOINtmavXDGzjABLKTbge
    xdfVWcPiUhOINtmavXDGzjABLKTbgE=xdfVWcPiUhOINtmavXDGzjABLKTbCS(xdfVWcPiUhOINtmavXDGzjABLKTbqp['schedule']['broadcast_start_time'])[8:12]
    xdfVWcPiUhOINtmavXDGzjABLKTbgl =xdfVWcPiUhOINtmavXDGzjABLKTbCS(xdfVWcPiUhOINtmavXDGzjABLKTbqp['schedule']['broadcast_end_time'])[8:12]
    xdfVWcPiUhOINtmavXDGzjABLKTbgH={'channel':xdfVWcPiUhOINtmavXDGzjABLKTbgr,'title':xdfVWcPiUhOINtmavXDGzjABLKTbgy,'mediacode':xdfVWcPiUhOINtmavXDGzjABLKTbgw,'thumbnail':xdfVWcPiUhOINtmavXDGzjABLKTbge,'synopsis':xdfVWcPiUhOINtmavXDGzjABLKTbgR,'channelepg':' [%s:%s ~ %s:%s]'%(xdfVWcPiUhOINtmavXDGzjABLKTbgE[0:2],xdfVWcPiUhOINtmavXDGzjABLKTbgE[2:],xdfVWcPiUhOINtmavXDGzjABLKTbgl[0:2],xdfVWcPiUhOINtmavXDGzjABLKTbgl[2:]),'info':xdfVWcPiUhOINtmavXDGzjABLKTbgF}
    xdfVWcPiUhOINtmavXDGzjABLKTbgq.append(xdfVWcPiUhOINtmavXDGzjABLKTbgH)
   if xdfVWcPiUhOINtmavXDGzjABLKTbqw['body']['has_more']=='Y':xdfVWcPiUhOINtmavXDGzjABLKTbgM=xdfVWcPiUhOINtmavXDGzjABLKTbCq
  except xdfVWcPiUhOINtmavXDGzjABLKTbCg as exception:
   xdfVWcPiUhOINtmavXDGzjABLKTbCM(exception)
  return xdfVWcPiUhOINtmavXDGzjABLKTbgq,xdfVWcPiUhOINtmavXDGzjABLKTbgM
 def GetProgramList(xdfVWcPiUhOINtmavXDGzjABLKTbYC,stype,orderby,page_int,landyn=xdfVWcPiUhOINtmavXDGzjABLKTbMo):
  xdfVWcPiUhOINtmavXDGzjABLKTbgq=[]
  xdfVWcPiUhOINtmavXDGzjABLKTbgM=xdfVWcPiUhOINtmavXDGzjABLKTbMo
  try:
   xdfVWcPiUhOINtmavXDGzjABLKTbqF ='/v2/media/episodes'
   xdfVWcPiUhOINtmavXDGzjABLKTbqr=xdfVWcPiUhOINtmavXDGzjABLKTbYC.GetDefaultParams()
   xdfVWcPiUhOINtmavXDGzjABLKTbqE={'pageNo':xdfVWcPiUhOINtmavXDGzjABLKTbCS(page_int),'pageSize':xdfVWcPiUhOINtmavXDGzjABLKTbCS(xdfVWcPiUhOINtmavXDGzjABLKTbYC.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','_':xdfVWcPiUhOINtmavXDGzjABLKTbCS(xdfVWcPiUhOINtmavXDGzjABLKTbYC.GetNoCache(2))}
   if stype!='all':xdfVWcPiUhOINtmavXDGzjABLKTbqE['multiCategoryCode']=stype
   xdfVWcPiUhOINtmavXDGzjABLKTbqr.update(xdfVWcPiUhOINtmavXDGzjABLKTbqE)
   xdfVWcPiUhOINtmavXDGzjABLKTbYp=xdfVWcPiUhOINtmavXDGzjABLKTbYC.makeurl(xdfVWcPiUhOINtmavXDGzjABLKTbYC.API_DOMAIN,xdfVWcPiUhOINtmavXDGzjABLKTbqF)
   xdfVWcPiUhOINtmavXDGzjABLKTbYr=xdfVWcPiUhOINtmavXDGzjABLKTbYC.makeDefaultCookies()
   xdfVWcPiUhOINtmavXDGzjABLKTbYn=xdfVWcPiUhOINtmavXDGzjABLKTbYC.callRequestCookies('Get',xdfVWcPiUhOINtmavXDGzjABLKTbYp,payload=xdfVWcPiUhOINtmavXDGzjABLKTbMn,params=xdfVWcPiUhOINtmavXDGzjABLKTbqr,headers=xdfVWcPiUhOINtmavXDGzjABLKTbMn,cookies=xdfVWcPiUhOINtmavXDGzjABLKTbYr)
   xdfVWcPiUhOINtmavXDGzjABLKTbqw=json.loads(xdfVWcPiUhOINtmavXDGzjABLKTbYn.text)
   if not('result' in xdfVWcPiUhOINtmavXDGzjABLKTbqw['body']):return xdfVWcPiUhOINtmavXDGzjABLKTbgq,xdfVWcPiUhOINtmavXDGzjABLKTbgM
   xdfVWcPiUhOINtmavXDGzjABLKTbgS=xdfVWcPiUhOINtmavXDGzjABLKTbqw['body']['result']
   for xdfVWcPiUhOINtmavXDGzjABLKTbqp in xdfVWcPiUhOINtmavXDGzjABLKTbgS:
    xdfVWcPiUhOINtmavXDGzjABLKTbgu=xdfVWcPiUhOINtmavXDGzjABLKTbqp['program']['code']
    xdfVWcPiUhOINtmavXDGzjABLKTbgy =xdfVWcPiUhOINtmavXDGzjABLKTbqp['program']['name']['ko']
    xdfVWcPiUhOINtmavXDGzjABLKTbge =xdfVWcPiUhOINtmavXDGzjABLKTbYC.IMG_DOMAIN+xdfVWcPiUhOINtmavXDGzjABLKTbqp['program']['image'][0]['url']
    xdfVWcPiUhOINtmavXDGzjABLKTbgQ='CAIP0200' if landyn else 'CAIP0900' 
    for xdfVWcPiUhOINtmavXDGzjABLKTbgJ in xdfVWcPiUhOINtmavXDGzjABLKTbqp['program']['image']:
     if xdfVWcPiUhOINtmavXDGzjABLKTbgJ['code']==xdfVWcPiUhOINtmavXDGzjABLKTbgQ:
      xdfVWcPiUhOINtmavXDGzjABLKTbge =xdfVWcPiUhOINtmavXDGzjABLKTbYC.IMG_DOMAIN+xdfVWcPiUhOINtmavXDGzjABLKTbgJ['url']
      break
    xdfVWcPiUhOINtmavXDGzjABLKTbgR =xdfVWcPiUhOINtmavXDGzjABLKTbqp['program']['synopsis']['ko']
    xdfVWcPiUhOINtmavXDGzjABLKTbgn=xdfVWcPiUhOINtmavXDGzjABLKTbqp['program']['channel_code']
    xdfVWcPiUhOINtmavXDGzjABLKTbgF={}
    xdfVWcPiUhOINtmavXDGzjABLKTbgF['title'] =xdfVWcPiUhOINtmavXDGzjABLKTbgy 
    xdfVWcPiUhOINtmavXDGzjABLKTbgF['mediatype']='episode' 
    try:
     xdfVWcPiUhOINtmavXDGzjABLKTbgp=[]
     for xdfVWcPiUhOINtmavXDGzjABLKTbgs in xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('program').get('actor'):xdfVWcPiUhOINtmavXDGzjABLKTbgp.append(xdfVWcPiUhOINtmavXDGzjABLKTbgs)
     if xdfVWcPiUhOINtmavXDGzjABLKTbgp[0]!='' and xdfVWcPiUhOINtmavXDGzjABLKTbgp[0]!='-':xdfVWcPiUhOINtmavXDGzjABLKTbgF['cast']=xdfVWcPiUhOINtmavXDGzjABLKTbgp
    except:
     xdfVWcPiUhOINtmavXDGzjABLKTbMn
    try:
     xdfVWcPiUhOINtmavXDGzjABLKTbgo=[]
     for xdfVWcPiUhOINtmavXDGzjABLKTbMY in xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('program').get('director'):xdfVWcPiUhOINtmavXDGzjABLKTbgo.append(xdfVWcPiUhOINtmavXDGzjABLKTbMY)
     if xdfVWcPiUhOINtmavXDGzjABLKTbgo[0]!='' and xdfVWcPiUhOINtmavXDGzjABLKTbgo[0]!='-':xdfVWcPiUhOINtmavXDGzjABLKTbgF['director']=xdfVWcPiUhOINtmavXDGzjABLKTbgo
    except:
     xdfVWcPiUhOINtmavXDGzjABLKTbMn
    xdfVWcPiUhOINtmavXDGzjABLKTbgk=[]
    if xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('program').get('category1_name').get('ko')!='':
     xdfVWcPiUhOINtmavXDGzjABLKTbgk.append(xdfVWcPiUhOINtmavXDGzjABLKTbqp['program']['category1_name']['ko'])
    if xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('program').get('category2_name').get('ko')!='':
     xdfVWcPiUhOINtmavXDGzjABLKTbgk.append(xdfVWcPiUhOINtmavXDGzjABLKTbqp['program']['category2_name']['ko'])
    if xdfVWcPiUhOINtmavXDGzjABLKTbgk[0]!='':xdfVWcPiUhOINtmavXDGzjABLKTbgF['genre']=xdfVWcPiUhOINtmavXDGzjABLKTbgk
    try:
     if xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('program').get('product_year'):xdfVWcPiUhOINtmavXDGzjABLKTbgF['year']=xdfVWcPiUhOINtmavXDGzjABLKTbqp['program']['product_year']
     if 'broad_dt' in xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('program'):
      xdfVWcPiUhOINtmavXDGzjABLKTbMq=xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('program').get('broad_dt')
      xdfVWcPiUhOINtmavXDGzjABLKTbgF['aired']='%s-%s-%s'%(xdfVWcPiUhOINtmavXDGzjABLKTbMq[:4],xdfVWcPiUhOINtmavXDGzjABLKTbMq[4:6],xdfVWcPiUhOINtmavXDGzjABLKTbMq[6:])
    except:
     xdfVWcPiUhOINtmavXDGzjABLKTbMn
    xdfVWcPiUhOINtmavXDGzjABLKTbgH={'program':xdfVWcPiUhOINtmavXDGzjABLKTbgu,'title':xdfVWcPiUhOINtmavXDGzjABLKTbgy,'thumbnail':xdfVWcPiUhOINtmavXDGzjABLKTbge,'synopsis':xdfVWcPiUhOINtmavXDGzjABLKTbgR,'channel':xdfVWcPiUhOINtmavXDGzjABLKTbgn,'info':xdfVWcPiUhOINtmavXDGzjABLKTbgF}
    xdfVWcPiUhOINtmavXDGzjABLKTbgq.append(xdfVWcPiUhOINtmavXDGzjABLKTbgH)
   if xdfVWcPiUhOINtmavXDGzjABLKTbqw['body']['has_more']=='Y':xdfVWcPiUhOINtmavXDGzjABLKTbgM=xdfVWcPiUhOINtmavXDGzjABLKTbCq
  except xdfVWcPiUhOINtmavXDGzjABLKTbCg as exception:
   xdfVWcPiUhOINtmavXDGzjABLKTbCM(exception)
  return xdfVWcPiUhOINtmavXDGzjABLKTbgq,xdfVWcPiUhOINtmavXDGzjABLKTbgM
 def GetEpisodoList(xdfVWcPiUhOINtmavXDGzjABLKTbYC,program_code,page_int,orderby='desc'):
  xdfVWcPiUhOINtmavXDGzjABLKTbgq=[]
  xdfVWcPiUhOINtmavXDGzjABLKTbgM=xdfVWcPiUhOINtmavXDGzjABLKTbMo
  try:
   xdfVWcPiUhOINtmavXDGzjABLKTbqF ='/v2/media/frequency/program/'+program_code
   xdfVWcPiUhOINtmavXDGzjABLKTbqr=xdfVWcPiUhOINtmavXDGzjABLKTbYC.GetDefaultParams()
   xdfVWcPiUhOINtmavXDGzjABLKTbqE={'pageNo':'1','pageSize':'10','order':'new','free':'all','adult':'all','scope':'all','_':xdfVWcPiUhOINtmavXDGzjABLKTbCS(xdfVWcPiUhOINtmavXDGzjABLKTbYC.GetNoCache(2))}
   xdfVWcPiUhOINtmavXDGzjABLKTbqr.update(xdfVWcPiUhOINtmavXDGzjABLKTbqE)
   xdfVWcPiUhOINtmavXDGzjABLKTbYp=xdfVWcPiUhOINtmavXDGzjABLKTbYC.makeurl(xdfVWcPiUhOINtmavXDGzjABLKTbYC.API_DOMAIN,xdfVWcPiUhOINtmavXDGzjABLKTbqF)
   xdfVWcPiUhOINtmavXDGzjABLKTbYr=xdfVWcPiUhOINtmavXDGzjABLKTbYC.makeDefaultCookies()
   xdfVWcPiUhOINtmavXDGzjABLKTbYn=xdfVWcPiUhOINtmavXDGzjABLKTbYC.callRequestCookies('Get',xdfVWcPiUhOINtmavXDGzjABLKTbYp,payload=xdfVWcPiUhOINtmavXDGzjABLKTbMn,params=xdfVWcPiUhOINtmavXDGzjABLKTbqr,headers=xdfVWcPiUhOINtmavXDGzjABLKTbMn,cookies=xdfVWcPiUhOINtmavXDGzjABLKTbYr)
   xdfVWcPiUhOINtmavXDGzjABLKTbqw=json.loads(xdfVWcPiUhOINtmavXDGzjABLKTbYn.text)
   if not('result' in xdfVWcPiUhOINtmavXDGzjABLKTbqw['body']):return xdfVWcPiUhOINtmavXDGzjABLKTbgq,xdfVWcPiUhOINtmavXDGzjABLKTbgM
   xdfVWcPiUhOINtmavXDGzjABLKTbgS=xdfVWcPiUhOINtmavXDGzjABLKTbqw['body']['result']
   xdfVWcPiUhOINtmavXDGzjABLKTbMg=xdfVWcPiUhOINtmavXDGzjABLKTbCY(xdfVWcPiUhOINtmavXDGzjABLKTbqw['body']['total_count'])
   xdfVWcPiUhOINtmavXDGzjABLKTbMC =xdfVWcPiUhOINtmavXDGzjABLKTbCY(xdfVWcPiUhOINtmavXDGzjABLKTbMg//(xdfVWcPiUhOINtmavXDGzjABLKTbYC.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    xdfVWcPiUhOINtmavXDGzjABLKTbMS =(xdfVWcPiUhOINtmavXDGzjABLKTbMg-1)-((page_int-1)*xdfVWcPiUhOINtmavXDGzjABLKTbYC.EPISODE_LIMIT)
   else:
    xdfVWcPiUhOINtmavXDGzjABLKTbMS =(page_int-1)*xdfVWcPiUhOINtmavXDGzjABLKTbYC.EPISODE_LIMIT
   for i in xdfVWcPiUhOINtmavXDGzjABLKTbCr(xdfVWcPiUhOINtmavXDGzjABLKTbYC.EPISODE_LIMIT):
    if orderby=='desc':
     xdfVWcPiUhOINtmavXDGzjABLKTbMF=xdfVWcPiUhOINtmavXDGzjABLKTbMS-i
     if xdfVWcPiUhOINtmavXDGzjABLKTbMF<0:break
    else:
     xdfVWcPiUhOINtmavXDGzjABLKTbMF=xdfVWcPiUhOINtmavXDGzjABLKTbMS+i
     if xdfVWcPiUhOINtmavXDGzjABLKTbMF>=xdfVWcPiUhOINtmavXDGzjABLKTbMg:break
    xdfVWcPiUhOINtmavXDGzjABLKTbMr=xdfVWcPiUhOINtmavXDGzjABLKTbgS[xdfVWcPiUhOINtmavXDGzjABLKTbMF]['episode']['code']
    xdfVWcPiUhOINtmavXDGzjABLKTbgy =xdfVWcPiUhOINtmavXDGzjABLKTbgS[xdfVWcPiUhOINtmavXDGzjABLKTbMF]['vod_name']['ko']
    xdfVWcPiUhOINtmavXDGzjABLKTbME =''
    try:
     xdfVWcPiUhOINtmavXDGzjABLKTbMq=xdfVWcPiUhOINtmavXDGzjABLKTbCS(xdfVWcPiUhOINtmavXDGzjABLKTbgS[xdfVWcPiUhOINtmavXDGzjABLKTbMF]['episode']['broadcast_date'])
     xdfVWcPiUhOINtmavXDGzjABLKTbME='%s-%s-%s'%(xdfVWcPiUhOINtmavXDGzjABLKTbMq[:4],xdfVWcPiUhOINtmavXDGzjABLKTbMq[4:6],xdfVWcPiUhOINtmavXDGzjABLKTbMq[6:])
    except:
     xdfVWcPiUhOINtmavXDGzjABLKTbMn
    if xdfVWcPiUhOINtmavXDGzjABLKTbgS[xdfVWcPiUhOINtmavXDGzjABLKTbMF]['episode']['image']!=[]:
     xdfVWcPiUhOINtmavXDGzjABLKTbge=xdfVWcPiUhOINtmavXDGzjABLKTbYC.IMG_DOMAIN+xdfVWcPiUhOINtmavXDGzjABLKTbgS[xdfVWcPiUhOINtmavXDGzjABLKTbMF]['episode']['image'][0]['url']
    else:
     xdfVWcPiUhOINtmavXDGzjABLKTbge=xdfVWcPiUhOINtmavXDGzjABLKTbYC.IMG_DOMAIN+xdfVWcPiUhOINtmavXDGzjABLKTbgS[xdfVWcPiUhOINtmavXDGzjABLKTbMF]['program']['image'][0]['url']
    xdfVWcPiUhOINtmavXDGzjABLKTbgR =xdfVWcPiUhOINtmavXDGzjABLKTbgS[xdfVWcPiUhOINtmavXDGzjABLKTbMF]['episode']['synopsis']['ko']
    xdfVWcPiUhOINtmavXDGzjABLKTbgF={}
    xdfVWcPiUhOINtmavXDGzjABLKTbgF['mediatype']='episode' 
    try:
     xdfVWcPiUhOINtmavXDGzjABLKTbgF['title'] =xdfVWcPiUhOINtmavXDGzjABLKTbgS[xdfVWcPiUhOINtmavXDGzjABLKTbMF]['program']['name']['ko']
     xdfVWcPiUhOINtmavXDGzjABLKTbgF['aired'] =xdfVWcPiUhOINtmavXDGzjABLKTbME
     xdfVWcPiUhOINtmavXDGzjABLKTbgF['studio'] =xdfVWcPiUhOINtmavXDGzjABLKTbgS[xdfVWcPiUhOINtmavXDGzjABLKTbMF]['channel']['name']['ko']
     if 'frequency' in xdfVWcPiUhOINtmavXDGzjABLKTbgS[xdfVWcPiUhOINtmavXDGzjABLKTbMF]['episode']:xdfVWcPiUhOINtmavXDGzjABLKTbgF['episode']=xdfVWcPiUhOINtmavXDGzjABLKTbgS[xdfVWcPiUhOINtmavXDGzjABLKTbMF]['episode']['frequency']
    except:
     xdfVWcPiUhOINtmavXDGzjABLKTbMn
    xdfVWcPiUhOINtmavXDGzjABLKTbgH={'episode':xdfVWcPiUhOINtmavXDGzjABLKTbMr,'title':xdfVWcPiUhOINtmavXDGzjABLKTbgy,'subtitle':xdfVWcPiUhOINtmavXDGzjABLKTbME,'thumbnail':xdfVWcPiUhOINtmavXDGzjABLKTbge,'synopsis':xdfVWcPiUhOINtmavXDGzjABLKTbgR,'info':xdfVWcPiUhOINtmavXDGzjABLKTbgF}
    xdfVWcPiUhOINtmavXDGzjABLKTbgq.append(xdfVWcPiUhOINtmavXDGzjABLKTbgH)
   if xdfVWcPiUhOINtmavXDGzjABLKTbMC>page_int:xdfVWcPiUhOINtmavXDGzjABLKTbgM=xdfVWcPiUhOINtmavXDGzjABLKTbCq
  except xdfVWcPiUhOINtmavXDGzjABLKTbCg as exception:
   xdfVWcPiUhOINtmavXDGzjABLKTbCM(exception)
  return xdfVWcPiUhOINtmavXDGzjABLKTbgq,xdfVWcPiUhOINtmavXDGzjABLKTbgM,xdfVWcPiUhOINtmavXDGzjABLKTbMC
 def GetMovieList(xdfVWcPiUhOINtmavXDGzjABLKTbYC,orderby,page_int,premiumyn=xdfVWcPiUhOINtmavXDGzjABLKTbMo,landyn=xdfVWcPiUhOINtmavXDGzjABLKTbMo):
  xdfVWcPiUhOINtmavXDGzjABLKTbgq=[]
  xdfVWcPiUhOINtmavXDGzjABLKTbgM=xdfVWcPiUhOINtmavXDGzjABLKTbMo
  if premiumyn==xdfVWcPiUhOINtmavXDGzjABLKTbCq:
   xdfVWcPiUhOINtmavXDGzjABLKTbMw=xdfVWcPiUhOINtmavXDGzjABLKTbYC.MOVIE_LITE+','+xdfVWcPiUhOINtmavXDGzjABLKTbYC.MOVIE_PREMIUM
  else:
   xdfVWcPiUhOINtmavXDGzjABLKTbMw=xdfVWcPiUhOINtmavXDGzjABLKTbYC.MOVIE_LITE
  try:
   xdfVWcPiUhOINtmavXDGzjABLKTbqF ='/v2/media/movies'
   xdfVWcPiUhOINtmavXDGzjABLKTbqr=xdfVWcPiUhOINtmavXDGzjABLKTbYC.GetDefaultParams()
   xdfVWcPiUhOINtmavXDGzjABLKTbqE={'pageNo':xdfVWcPiUhOINtmavXDGzjABLKTbCS(page_int),'pageSize':xdfVWcPiUhOINtmavXDGzjABLKTbCS(xdfVWcPiUhOINtmavXDGzjABLKTbYC.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','productPackageCode':xdfVWcPiUhOINtmavXDGzjABLKTbMw,'_':xdfVWcPiUhOINtmavXDGzjABLKTbCS(xdfVWcPiUhOINtmavXDGzjABLKTbYC.GetNoCache(2))}
   xdfVWcPiUhOINtmavXDGzjABLKTbqr.update(xdfVWcPiUhOINtmavXDGzjABLKTbqE)
   xdfVWcPiUhOINtmavXDGzjABLKTbYp=xdfVWcPiUhOINtmavXDGzjABLKTbYC.makeurl(xdfVWcPiUhOINtmavXDGzjABLKTbYC.API_DOMAIN,xdfVWcPiUhOINtmavXDGzjABLKTbqF)
   xdfVWcPiUhOINtmavXDGzjABLKTbYr=xdfVWcPiUhOINtmavXDGzjABLKTbYC.makeDefaultCookies()
   xdfVWcPiUhOINtmavXDGzjABLKTbYn=xdfVWcPiUhOINtmavXDGzjABLKTbYC.callRequestCookies('Get',xdfVWcPiUhOINtmavXDGzjABLKTbYp,payload=xdfVWcPiUhOINtmavXDGzjABLKTbMn,params=xdfVWcPiUhOINtmavXDGzjABLKTbqr,headers=xdfVWcPiUhOINtmavXDGzjABLKTbMn,cookies=xdfVWcPiUhOINtmavXDGzjABLKTbYr)
   xdfVWcPiUhOINtmavXDGzjABLKTbqw=json.loads(xdfVWcPiUhOINtmavXDGzjABLKTbYn.text)
   if not('result' in xdfVWcPiUhOINtmavXDGzjABLKTbqw['body']):return xdfVWcPiUhOINtmavXDGzjABLKTbgq,xdfVWcPiUhOINtmavXDGzjABLKTbgM
   xdfVWcPiUhOINtmavXDGzjABLKTbgS=xdfVWcPiUhOINtmavXDGzjABLKTbqw['body']['result']
   for xdfVWcPiUhOINtmavXDGzjABLKTbqp in xdfVWcPiUhOINtmavXDGzjABLKTbgS:
    xdfVWcPiUhOINtmavXDGzjABLKTbMy =xdfVWcPiUhOINtmavXDGzjABLKTbqp['movie']['code']
    xdfVWcPiUhOINtmavXDGzjABLKTbgy =xdfVWcPiUhOINtmavXDGzjABLKTbqp['movie']['name']['ko'].strip()
    xdfVWcPiUhOINtmavXDGzjABLKTbgy +=u' (%s년)'%(xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('movie').get('product_year'))
    xdfVWcPiUhOINtmavXDGzjABLKTbge =xdfVWcPiUhOINtmavXDGzjABLKTbYC.IMG_DOMAIN+xdfVWcPiUhOINtmavXDGzjABLKTbqp['movie']['image'][0]['url']
    xdfVWcPiUhOINtmavXDGzjABLKTbgQ='CAIM0400' if landyn else 'CAIM2100' 
    for xdfVWcPiUhOINtmavXDGzjABLKTbgJ in xdfVWcPiUhOINtmavXDGzjABLKTbqp['movie']['image']:
     if xdfVWcPiUhOINtmavXDGzjABLKTbgJ['code']==xdfVWcPiUhOINtmavXDGzjABLKTbgQ:
      xdfVWcPiUhOINtmavXDGzjABLKTbge =xdfVWcPiUhOINtmavXDGzjABLKTbYC.IMG_DOMAIN+xdfVWcPiUhOINtmavXDGzjABLKTbgJ['url']
      break
    xdfVWcPiUhOINtmavXDGzjABLKTbgR =xdfVWcPiUhOINtmavXDGzjABLKTbqp['movie']['story']['ko']
    xdfVWcPiUhOINtmavXDGzjABLKTbgF={}
    xdfVWcPiUhOINtmavXDGzjABLKTbgF['mediatype']='movie' 
    xdfVWcPiUhOINtmavXDGzjABLKTbgF['title'] = xdfVWcPiUhOINtmavXDGzjABLKTbqp['movie']['name']['ko'].strip()
    xdfVWcPiUhOINtmavXDGzjABLKTbgF['year'] =xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('movie').get('product_year')
    try:
     xdfVWcPiUhOINtmavXDGzjABLKTbgp=[]
     for xdfVWcPiUhOINtmavXDGzjABLKTbgs in xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('movie').get('actor'):xdfVWcPiUhOINtmavXDGzjABLKTbgp.append(xdfVWcPiUhOINtmavXDGzjABLKTbgs)
     if xdfVWcPiUhOINtmavXDGzjABLKTbgp[0]!='':xdfVWcPiUhOINtmavXDGzjABLKTbgF['cast']=xdfVWcPiUhOINtmavXDGzjABLKTbgp
    except:
     xdfVWcPiUhOINtmavXDGzjABLKTbMn
    try:
     xdfVWcPiUhOINtmavXDGzjABLKTbgo=[]
     for xdfVWcPiUhOINtmavXDGzjABLKTbMY in xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('movie').get('director'):xdfVWcPiUhOINtmavXDGzjABLKTbgo.append(xdfVWcPiUhOINtmavXDGzjABLKTbMY)
     if xdfVWcPiUhOINtmavXDGzjABLKTbgo[0]!='':xdfVWcPiUhOINtmavXDGzjABLKTbgF['director']=xdfVWcPiUhOINtmavXDGzjABLKTbgo
    except:
     xdfVWcPiUhOINtmavXDGzjABLKTbMn
    try:
     xdfVWcPiUhOINtmavXDGzjABLKTbgk=[]
     if xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('movie').get('category1_name').get('ko')!='':
      xdfVWcPiUhOINtmavXDGzjABLKTbgk.append(xdfVWcPiUhOINtmavXDGzjABLKTbqp['movie']['category1_name']['ko'])
     if xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('movie').get('category2_name').get('ko')!='':
      xdfVWcPiUhOINtmavXDGzjABLKTbgk.append(xdfVWcPiUhOINtmavXDGzjABLKTbqp['movie']['category2_name']['ko'])
     if xdfVWcPiUhOINtmavXDGzjABLKTbgk[0]!='':xdfVWcPiUhOINtmavXDGzjABLKTbgF['genre']=xdfVWcPiUhOINtmavXDGzjABLKTbgk
    except:
     xdfVWcPiUhOINtmavXDGzjABLKTbMn
    try:
     if 'release_date' in xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('movie'):
      xdfVWcPiUhOINtmavXDGzjABLKTbMq=xdfVWcPiUhOINtmavXDGzjABLKTbCS(xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('movie').get('release_date'))
      xdfVWcPiUhOINtmavXDGzjABLKTbgF['aired']='%s-%s-%s'%(xdfVWcPiUhOINtmavXDGzjABLKTbMq[:4],xdfVWcPiUhOINtmavXDGzjABLKTbMq[4:6],xdfVWcPiUhOINtmavXDGzjABLKTbMq[6:])
    except:
     xdfVWcPiUhOINtmavXDGzjABLKTbMn
    try:
     if 'duration' in xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('movie'):xdfVWcPiUhOINtmavXDGzjABLKTbgF['duration']=xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('movie').get('duration')
    except:
     xdfVWcPiUhOINtmavXDGzjABLKTbMn
    xdfVWcPiUhOINtmavXDGzjABLKTbgH={'moviecode':xdfVWcPiUhOINtmavXDGzjABLKTbMy,'title':xdfVWcPiUhOINtmavXDGzjABLKTbgy,'thumbnail':xdfVWcPiUhOINtmavXDGzjABLKTbge,'synopsis':xdfVWcPiUhOINtmavXDGzjABLKTbgR,'info':xdfVWcPiUhOINtmavXDGzjABLKTbgF}
    if premiumyn==xdfVWcPiUhOINtmavXDGzjABLKTbCq:
     xdfVWcPiUhOINtmavXDGzjABLKTbMe=xdfVWcPiUhOINtmavXDGzjABLKTbMo
     for xdfVWcPiUhOINtmavXDGzjABLKTbMR in xdfVWcPiUhOINtmavXDGzjABLKTbqp['billing_package_id']:
      if xdfVWcPiUhOINtmavXDGzjABLKTbMR==xdfVWcPiUhOINtmavXDGzjABLKTbYC.MOVIE_LITE:
       xdfVWcPiUhOINtmavXDGzjABLKTbMe=xdfVWcPiUhOINtmavXDGzjABLKTbCq
       break
     if xdfVWcPiUhOINtmavXDGzjABLKTbMe==xdfVWcPiUhOINtmavXDGzjABLKTbMo:
      xdfVWcPiUhOINtmavXDGzjABLKTbgH['title']=xdfVWcPiUhOINtmavXDGzjABLKTbgH['title']+' [Premium]'
    xdfVWcPiUhOINtmavXDGzjABLKTbgq.append(xdfVWcPiUhOINtmavXDGzjABLKTbgH)
   if xdfVWcPiUhOINtmavXDGzjABLKTbqw['body']['has_more']=='Y':xdfVWcPiUhOINtmavXDGzjABLKTbgM=xdfVWcPiUhOINtmavXDGzjABLKTbCq
  except xdfVWcPiUhOINtmavXDGzjABLKTbCg as exception:
   xdfVWcPiUhOINtmavXDGzjABLKTbCM(exception)
  return xdfVWcPiUhOINtmavXDGzjABLKTbgq,xdfVWcPiUhOINtmavXDGzjABLKTbgM
 def GetMovieListGenre(xdfVWcPiUhOINtmavXDGzjABLKTbYC,genre,page_int,premiumyn=xdfVWcPiUhOINtmavXDGzjABLKTbMo):
  xdfVWcPiUhOINtmavXDGzjABLKTbgq=[]
  xdfVWcPiUhOINtmavXDGzjABLKTbgM=xdfVWcPiUhOINtmavXDGzjABLKTbMo
  if premiumyn==xdfVWcPiUhOINtmavXDGzjABLKTbCq:
   xdfVWcPiUhOINtmavXDGzjABLKTbMw=xdfVWcPiUhOINtmavXDGzjABLKTbYC.MOVIE_LITE+','+xdfVWcPiUhOINtmavXDGzjABLKTbYC.MOVIE_PREMIUM
  else:
   xdfVWcPiUhOINtmavXDGzjABLKTbMw=xdfVWcPiUhOINtmavXDGzjABLKTbYC.MOVIE_LITE
  try:
   xdfVWcPiUhOINtmavXDGzjABLKTbqF ='/v2/media/movie/curation/'+genre
   xdfVWcPiUhOINtmavXDGzjABLKTbqr=xdfVWcPiUhOINtmavXDGzjABLKTbYC.GetDefaultParams()
   xdfVWcPiUhOINtmavXDGzjABLKTbqE={'pageNo':xdfVWcPiUhOINtmavXDGzjABLKTbCS(page_int),'pageSize':xdfVWcPiUhOINtmavXDGzjABLKTbCS(xdfVWcPiUhOINtmavXDGzjABLKTbYC.MOVIE_LIMIT),'productPackageCode':xdfVWcPiUhOINtmavXDGzjABLKTbMw,'_':xdfVWcPiUhOINtmavXDGzjABLKTbCS(xdfVWcPiUhOINtmavXDGzjABLKTbYC.GetNoCache(2))}
   xdfVWcPiUhOINtmavXDGzjABLKTbqr.update(xdfVWcPiUhOINtmavXDGzjABLKTbqE)
   xdfVWcPiUhOINtmavXDGzjABLKTbYp=xdfVWcPiUhOINtmavXDGzjABLKTbYC.makeurl(xdfVWcPiUhOINtmavXDGzjABLKTbYC.API_DOMAIN,xdfVWcPiUhOINtmavXDGzjABLKTbqF)
   xdfVWcPiUhOINtmavXDGzjABLKTbYr=xdfVWcPiUhOINtmavXDGzjABLKTbYC.makeDefaultCookies()
   xdfVWcPiUhOINtmavXDGzjABLKTbYn=xdfVWcPiUhOINtmavXDGzjABLKTbYC.callRequestCookies('Get',xdfVWcPiUhOINtmavXDGzjABLKTbYp,payload=xdfVWcPiUhOINtmavXDGzjABLKTbMn,params=xdfVWcPiUhOINtmavXDGzjABLKTbqr,headers=xdfVWcPiUhOINtmavXDGzjABLKTbMn,cookies=xdfVWcPiUhOINtmavXDGzjABLKTbYr)
   xdfVWcPiUhOINtmavXDGzjABLKTbqw=json.loads(xdfVWcPiUhOINtmavXDGzjABLKTbYn.text)
   if not('movies' in xdfVWcPiUhOINtmavXDGzjABLKTbqw['body']):return xdfVWcPiUhOINtmavXDGzjABLKTbgq,xdfVWcPiUhOINtmavXDGzjABLKTbgM
   xdfVWcPiUhOINtmavXDGzjABLKTbgS=xdfVWcPiUhOINtmavXDGzjABLKTbqw['body']['movies']
   for xdfVWcPiUhOINtmavXDGzjABLKTbqp in xdfVWcPiUhOINtmavXDGzjABLKTbgS:
    xdfVWcPiUhOINtmavXDGzjABLKTbMy =xdfVWcPiUhOINtmavXDGzjABLKTbqp['code']
    xdfVWcPiUhOINtmavXDGzjABLKTbgy =xdfVWcPiUhOINtmavXDGzjABLKTbqp['name']['ko']
    xdfVWcPiUhOINtmavXDGzjABLKTbge =xdfVWcPiUhOINtmavXDGzjABLKTbYC.IMG_DOMAIN+xdfVWcPiUhOINtmavXDGzjABLKTbqp['image'][0]['url']
    for xdfVWcPiUhOINtmavXDGzjABLKTbgJ in xdfVWcPiUhOINtmavXDGzjABLKTbqp['image']:
     if xdfVWcPiUhOINtmavXDGzjABLKTbgJ['code']=='CAIM2100':
      xdfVWcPiUhOINtmavXDGzjABLKTbge =xdfVWcPiUhOINtmavXDGzjABLKTbYC.IMG_DOMAIN+xdfVWcPiUhOINtmavXDGzjABLKTbgJ['url']
    xdfVWcPiUhOINtmavXDGzjABLKTbgR =xdfVWcPiUhOINtmavXDGzjABLKTbqp['story']['ko']
    xdfVWcPiUhOINtmavXDGzjABLKTbgH={'moviecode':xdfVWcPiUhOINtmavXDGzjABLKTbMy,'title':xdfVWcPiUhOINtmavXDGzjABLKTbgy.strip(),'thumbnail':xdfVWcPiUhOINtmavXDGzjABLKTbge,'synopsis':xdfVWcPiUhOINtmavXDGzjABLKTbgR}
    if premiumyn==xdfVWcPiUhOINtmavXDGzjABLKTbCq:
     xdfVWcPiUhOINtmavXDGzjABLKTbMe=xdfVWcPiUhOINtmavXDGzjABLKTbMo
     for xdfVWcPiUhOINtmavXDGzjABLKTbMR in xdfVWcPiUhOINtmavXDGzjABLKTbqp['billing_package_id']:
      if xdfVWcPiUhOINtmavXDGzjABLKTbMR==xdfVWcPiUhOINtmavXDGzjABLKTbYC.MOVIE_LITE:
       xdfVWcPiUhOINtmavXDGzjABLKTbMe=xdfVWcPiUhOINtmavXDGzjABLKTbCq
       break
     if xdfVWcPiUhOINtmavXDGzjABLKTbMe==xdfVWcPiUhOINtmavXDGzjABLKTbMo:
      xdfVWcPiUhOINtmavXDGzjABLKTbgH['title']=xdfVWcPiUhOINtmavXDGzjABLKTbgH['title']+' [Premium]'
    xdfVWcPiUhOINtmavXDGzjABLKTbgq.append(xdfVWcPiUhOINtmavXDGzjABLKTbgH)
  except xdfVWcPiUhOINtmavXDGzjABLKTbCg as exception:
   xdfVWcPiUhOINtmavXDGzjABLKTbCM(exception)
  return xdfVWcPiUhOINtmavXDGzjABLKTbgq,xdfVWcPiUhOINtmavXDGzjABLKTbgM
 def GetMovieGenre(xdfVWcPiUhOINtmavXDGzjABLKTbYC):
  xdfVWcPiUhOINtmavXDGzjABLKTbgq=[]
  xdfVWcPiUhOINtmavXDGzjABLKTbgM=xdfVWcPiUhOINtmavXDGzjABLKTbMo
  try:
   xdfVWcPiUhOINtmavXDGzjABLKTbqF ='/v2/media/movie/curations'
   xdfVWcPiUhOINtmavXDGzjABLKTbqr=xdfVWcPiUhOINtmavXDGzjABLKTbYC.GetDefaultParams()
   xdfVWcPiUhOINtmavXDGzjABLKTbqE={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code','_':xdfVWcPiUhOINtmavXDGzjABLKTbCS(xdfVWcPiUhOINtmavXDGzjABLKTbYC.GetNoCache(2))}
   xdfVWcPiUhOINtmavXDGzjABLKTbqr.update(xdfVWcPiUhOINtmavXDGzjABLKTbqE)
   xdfVWcPiUhOINtmavXDGzjABLKTbYp=xdfVWcPiUhOINtmavXDGzjABLKTbYC.makeurl(xdfVWcPiUhOINtmavXDGzjABLKTbYC.API_DOMAIN,xdfVWcPiUhOINtmavXDGzjABLKTbqF)
   xdfVWcPiUhOINtmavXDGzjABLKTbYr=xdfVWcPiUhOINtmavXDGzjABLKTbYC.makeDefaultCookies()
   xdfVWcPiUhOINtmavXDGzjABLKTbYn=xdfVWcPiUhOINtmavXDGzjABLKTbYC.callRequestCookies('Get',xdfVWcPiUhOINtmavXDGzjABLKTbYp,payload=xdfVWcPiUhOINtmavXDGzjABLKTbMn,params=xdfVWcPiUhOINtmavXDGzjABLKTbqr,headers=xdfVWcPiUhOINtmavXDGzjABLKTbMn,cookies=xdfVWcPiUhOINtmavXDGzjABLKTbYr)
   xdfVWcPiUhOINtmavXDGzjABLKTbqw=json.loads(xdfVWcPiUhOINtmavXDGzjABLKTbYn.text)
   if not('result' in xdfVWcPiUhOINtmavXDGzjABLKTbqw['body']):return xdfVWcPiUhOINtmavXDGzjABLKTbgq,xdfVWcPiUhOINtmavXDGzjABLKTbgM
   xdfVWcPiUhOINtmavXDGzjABLKTbgS=xdfVWcPiUhOINtmavXDGzjABLKTbqw['body']['result']
   for xdfVWcPiUhOINtmavXDGzjABLKTbqp in xdfVWcPiUhOINtmavXDGzjABLKTbgS:
    xdfVWcPiUhOINtmavXDGzjABLKTbMp =xdfVWcPiUhOINtmavXDGzjABLKTbqp['curation_code']
    xdfVWcPiUhOINtmavXDGzjABLKTbMs =xdfVWcPiUhOINtmavXDGzjABLKTbqp['curation_name']
    xdfVWcPiUhOINtmavXDGzjABLKTbgH={'curation_code':xdfVWcPiUhOINtmavXDGzjABLKTbMp,'curation_name':xdfVWcPiUhOINtmavXDGzjABLKTbMs}
    xdfVWcPiUhOINtmavXDGzjABLKTbgq.append(xdfVWcPiUhOINtmavXDGzjABLKTbgH)
  except xdfVWcPiUhOINtmavXDGzjABLKTbCg as exception:
   xdfVWcPiUhOINtmavXDGzjABLKTbCM(exception)
  return xdfVWcPiUhOINtmavXDGzjABLKTbgq,xdfVWcPiUhOINtmavXDGzjABLKTbgM
 def GetSearchList(xdfVWcPiUhOINtmavXDGzjABLKTbYC,search_key,userid,page_int,stype,premiumyn=xdfVWcPiUhOINtmavXDGzjABLKTbMo,landyn=xdfVWcPiUhOINtmavXDGzjABLKTbMo):
  xdfVWcPiUhOINtmavXDGzjABLKTbMk=[]
  xdfVWcPiUhOINtmavXDGzjABLKTbgM=xdfVWcPiUhOINtmavXDGzjABLKTbMo
  try:
   xdfVWcPiUhOINtmavXDGzjABLKTbqF ='/search/getSearch.jsp'
   xdfVWcPiUhOINtmavXDGzjABLKTbqE={'kwd':search_key,'notFoundText':search_key,'userid':userid,'siteName':'TVING_WEB','category':'TOTAL','pageNum':xdfVWcPiUhOINtmavXDGzjABLKTbCS(page_int),'pageSize':xdfVWcPiUhOINtmavXDGzjABLKTbCS(xdfVWcPiUhOINtmavXDGzjABLKTbYC.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':xdfVWcPiUhOINtmavXDGzjABLKTbYC.SCREENCODE,'os':xdfVWcPiUhOINtmavXDGzjABLKTbYC.OSCODE,'network':xdfVWcPiUhOINtmavXDGzjABLKTbYC.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':xdfVWcPiUhOINtmavXDGzjABLKTbCS(xdfVWcPiUhOINtmavXDGzjABLKTbYC.SEARCH_LIMIT),'vodMVReqCnt':xdfVWcPiUhOINtmavXDGzjABLKTbCS(xdfVWcPiUhOINtmavXDGzjABLKTbYC.SEARCH_LIMIT),'smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':xdfVWcPiUhOINtmavXDGzjABLKTbCS(xdfVWcPiUhOINtmavXDGzjABLKTbYC.GetNoCache(2))}
   xdfVWcPiUhOINtmavXDGzjABLKTbYp=xdfVWcPiUhOINtmavXDGzjABLKTbYC.makeurl(xdfVWcPiUhOINtmavXDGzjABLKTbYC.SEARCH_DOMAIN,xdfVWcPiUhOINtmavXDGzjABLKTbqF)
   xdfVWcPiUhOINtmavXDGzjABLKTbYr=xdfVWcPiUhOINtmavXDGzjABLKTbYC.makeDefaultCookies()
   xdfVWcPiUhOINtmavXDGzjABLKTbYn=xdfVWcPiUhOINtmavXDGzjABLKTbYC.callRequestCookies('Get',xdfVWcPiUhOINtmavXDGzjABLKTbYp,payload=xdfVWcPiUhOINtmavXDGzjABLKTbMn,params=xdfVWcPiUhOINtmavXDGzjABLKTbqE,headers=xdfVWcPiUhOINtmavXDGzjABLKTbMn,cookies=xdfVWcPiUhOINtmavXDGzjABLKTbYr)
   xdfVWcPiUhOINtmavXDGzjABLKTbqw=json.loads(xdfVWcPiUhOINtmavXDGzjABLKTbYn.text)
   if stype=='vod':
    if not('programRsb' in xdfVWcPiUhOINtmavXDGzjABLKTbqw):return xdfVWcPiUhOINtmavXDGzjABLKTbMk,xdfVWcPiUhOINtmavXDGzjABLKTbgM
    xdfVWcPiUhOINtmavXDGzjABLKTbMl=xdfVWcPiUhOINtmavXDGzjABLKTbqw['programRsb']['dataList']
    xdfVWcPiUhOINtmavXDGzjABLKTbMH =xdfVWcPiUhOINtmavXDGzjABLKTbCY(xdfVWcPiUhOINtmavXDGzjABLKTbqw['programRsb']['count'])
    for xdfVWcPiUhOINtmavXDGzjABLKTbqp in xdfVWcPiUhOINtmavXDGzjABLKTbMl:
     xdfVWcPiUhOINtmavXDGzjABLKTbgu=xdfVWcPiUhOINtmavXDGzjABLKTbqp['mast_cd']
     xdfVWcPiUhOINtmavXDGzjABLKTbgy =xdfVWcPiUhOINtmavXDGzjABLKTbqp['mast_nm']
     xdfVWcPiUhOINtmavXDGzjABLKTbge =xdfVWcPiUhOINtmavXDGzjABLKTbYC.IMG_DOMAIN+xdfVWcPiUhOINtmavXDGzjABLKTbqp['web_url']
     if landyn==xdfVWcPiUhOINtmavXDGzjABLKTbMo:
      xdfVWcPiUhOINtmavXDGzjABLKTbge =xdfVWcPiUhOINtmavXDGzjABLKTbYC.IMG_DOMAIN+xdfVWcPiUhOINtmavXDGzjABLKTbqp['web_url4']
     xdfVWcPiUhOINtmavXDGzjABLKTbgF={}
     xdfVWcPiUhOINtmavXDGzjABLKTbgF['title']=xdfVWcPiUhOINtmavXDGzjABLKTbqp['mast_nm']
     xdfVWcPiUhOINtmavXDGzjABLKTbgF['mediatype']='episode' 
     try:
      if xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('actor')!='' and xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('actor')!='-':xdfVWcPiUhOINtmavXDGzjABLKTbgF['cast'] =xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('actor').split(',')
      if xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('director')!='' and xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('director')!='-':xdfVWcPiUhOINtmavXDGzjABLKTbgF['director']=xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('director').split(',')
      if xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('cate_nm')!='':xdfVWcPiUhOINtmavXDGzjABLKTbgF['genre'] =xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('cate_nm').split('/')
      if 'targetage' in xdfVWcPiUhOINtmavXDGzjABLKTbqp:xdfVWcPiUhOINtmavXDGzjABLKTbgF['mpaa']=xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('targetage')
     except:
      xdfVWcPiUhOINtmavXDGzjABLKTbMn
     try:
      if 'broad_dt' in xdfVWcPiUhOINtmavXDGzjABLKTbqp:
       xdfVWcPiUhOINtmavXDGzjABLKTbMq=xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('broad_dt')
       xdfVWcPiUhOINtmavXDGzjABLKTbgF['aired']='%s-%s-%s'%(xdfVWcPiUhOINtmavXDGzjABLKTbMq[:4],xdfVWcPiUhOINtmavXDGzjABLKTbMq[4:6],xdfVWcPiUhOINtmavXDGzjABLKTbMq[6:])
     except:
      xdfVWcPiUhOINtmavXDGzjABLKTbMn
     xdfVWcPiUhOINtmavXDGzjABLKTbgH={'program':xdfVWcPiUhOINtmavXDGzjABLKTbgu,'title':xdfVWcPiUhOINtmavXDGzjABLKTbgy,'thumbnail':xdfVWcPiUhOINtmavXDGzjABLKTbge,'synopsis':'','info':xdfVWcPiUhOINtmavXDGzjABLKTbgF}
     xdfVWcPiUhOINtmavXDGzjABLKTbMk.append(xdfVWcPiUhOINtmavXDGzjABLKTbgH)
   else:
    if not('vodMVRsb' in xdfVWcPiUhOINtmavXDGzjABLKTbqw):return xdfVWcPiUhOINtmavXDGzjABLKTbMk,xdfVWcPiUhOINtmavXDGzjABLKTbgM
    xdfVWcPiUhOINtmavXDGzjABLKTbMu=xdfVWcPiUhOINtmavXDGzjABLKTbqw['vodMVRsb']['dataList']
    xdfVWcPiUhOINtmavXDGzjABLKTbMH =xdfVWcPiUhOINtmavXDGzjABLKTbCY(xdfVWcPiUhOINtmavXDGzjABLKTbqw['vodMVRsb']['count'])
    for xdfVWcPiUhOINtmavXDGzjABLKTbqp in xdfVWcPiUhOINtmavXDGzjABLKTbMu:
     xdfVWcPiUhOINtmavXDGzjABLKTbgu=xdfVWcPiUhOINtmavXDGzjABLKTbqp['mast_cd']
     xdfVWcPiUhOINtmavXDGzjABLKTbgy =xdfVWcPiUhOINtmavXDGzjABLKTbqp['mast_nm'].strip()
     xdfVWcPiUhOINtmavXDGzjABLKTbge =xdfVWcPiUhOINtmavXDGzjABLKTbYC.IMG_DOMAIN+xdfVWcPiUhOINtmavXDGzjABLKTbqp['web_url']
     if landyn==xdfVWcPiUhOINtmavXDGzjABLKTbMo:
      xdfVWcPiUhOINtmavXDGzjABLKTbge =xdfVWcPiUhOINtmavXDGzjABLKTbYC.IMG_DOMAIN+xdfVWcPiUhOINtmavXDGzjABLKTbqp['web_url5']
     xdfVWcPiUhOINtmavXDGzjABLKTbgF={}
     xdfVWcPiUhOINtmavXDGzjABLKTbgF['title'] =xdfVWcPiUhOINtmavXDGzjABLKTbgy
     xdfVWcPiUhOINtmavXDGzjABLKTbgF['mediatype']='movie' 
     try:
      if xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('actor') !='':xdfVWcPiUhOINtmavXDGzjABLKTbgF['cast'] =xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('actor').split(',')
      if xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('cate_nm')!='':xdfVWcPiUhOINtmavXDGzjABLKTbgF['genre'] =xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('cate_nm').split('/')
      if xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('runtime_sec')!='':xdfVWcPiUhOINtmavXDGzjABLKTbgF['duration']=xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('runtime_sec')
      if 'grade_nm' in xdfVWcPiUhOINtmavXDGzjABLKTbqp:xdfVWcPiUhOINtmavXDGzjABLKTbgF['mpaa']=xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('grade_nm')
     except:
      xdfVWcPiUhOINtmavXDGzjABLKTbMn
     try:
      xdfVWcPiUhOINtmavXDGzjABLKTbMq=xdfVWcPiUhOINtmavXDGzjABLKTbqp.get('broad_dt')
      if data_str!='':
       xdfVWcPiUhOINtmavXDGzjABLKTbgF['aired']='%s-%s-%s'%(xdfVWcPiUhOINtmavXDGzjABLKTbMq[:4],xdfVWcPiUhOINtmavXDGzjABLKTbMq[4:6],xdfVWcPiUhOINtmavXDGzjABLKTbMq[6:])
       xdfVWcPiUhOINtmavXDGzjABLKTbgF['year']=xdfVWcPiUhOINtmavXDGzjABLKTbMq[:4]
     except:
      xdfVWcPiUhOINtmavXDGzjABLKTbMn
     if xdfVWcPiUhOINtmavXDGzjABLKTbCq:
      xdfVWcPiUhOINtmavXDGzjABLKTbgH={'movie':xdfVWcPiUhOINtmavXDGzjABLKTbgu,'title':xdfVWcPiUhOINtmavXDGzjABLKTbgy,'thumbnail':xdfVWcPiUhOINtmavXDGzjABLKTbge,'synopsis':'','info':xdfVWcPiUhOINtmavXDGzjABLKTbgF}
      xdfVWcPiUhOINtmavXDGzjABLKTbMk.append(xdfVWcPiUhOINtmavXDGzjABLKTbgH)
  except xdfVWcPiUhOINtmavXDGzjABLKTbCg as exception:
   xdfVWcPiUhOINtmavXDGzjABLKTbCM(exception)
  return xdfVWcPiUhOINtmavXDGzjABLKTbMk,xdfVWcPiUhOINtmavXDGzjABLKTbgM
 def GetDeviceList(xdfVWcPiUhOINtmavXDGzjABLKTbYC,xdfVWcPiUhOINtmavXDGzjABLKTbYH,xdfVWcPiUhOINtmavXDGzjABLKTbqY):
  xdfVWcPiUhOINtmavXDGzjABLKTbgq=[]
  xdfVWcPiUhOINtmavXDGzjABLKTbqS='-'
  try:
   xdfVWcPiUhOINtmavXDGzjABLKTbqF ='/v1/user/device/list'
   xdfVWcPiUhOINtmavXDGzjABLKTbMQ=xdfVWcPiUhOINtmavXDGzjABLKTbYC.makeurl(xdfVWcPiUhOINtmavXDGzjABLKTbYC.API_DOMAIN,xdfVWcPiUhOINtmavXDGzjABLKTbqF)
   xdfVWcPiUhOINtmavXDGzjABLKTbqE={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   xdfVWcPiUhOINtmavXDGzjABLKTbYr=xdfVWcPiUhOINtmavXDGzjABLKTbYC.makeDefaultCookies(vToken=xdfVWcPiUhOINtmavXDGzjABLKTbYH,vUserinfo=xdfVWcPiUhOINtmavXDGzjABLKTbqY)
   xdfVWcPiUhOINtmavXDGzjABLKTbYn=xdfVWcPiUhOINtmavXDGzjABLKTbYC.callRequestCookies('Get',xdfVWcPiUhOINtmavXDGzjABLKTbMQ,payload=xdfVWcPiUhOINtmavXDGzjABLKTbMn,params=xdfVWcPiUhOINtmavXDGzjABLKTbqE,headers=xdfVWcPiUhOINtmavXDGzjABLKTbMn,cookies=xdfVWcPiUhOINtmavXDGzjABLKTbYr)
   xdfVWcPiUhOINtmavXDGzjABLKTbqw=json.loads(xdfVWcPiUhOINtmavXDGzjABLKTbYn.text)
   xdfVWcPiUhOINtmavXDGzjABLKTbgq=xdfVWcPiUhOINtmavXDGzjABLKTbqw['body']
   for xdfVWcPiUhOINtmavXDGzjABLKTbqp in xdfVWcPiUhOINtmavXDGzjABLKTbgq:
    if xdfVWcPiUhOINtmavXDGzjABLKTbqp['model']=='PC':
     xdfVWcPiUhOINtmavXDGzjABLKTbqS=xdfVWcPiUhOINtmavXDGzjABLKTbqp['uuid']
  except xdfVWcPiUhOINtmavXDGzjABLKTbCg as exception:
   xdfVWcPiUhOINtmavXDGzjABLKTbCM(exception)
  return xdfVWcPiUhOINtmavXDGzjABLKTbqS
# Created by pyminifier (https://github.com/liftoff/pyminifier)
