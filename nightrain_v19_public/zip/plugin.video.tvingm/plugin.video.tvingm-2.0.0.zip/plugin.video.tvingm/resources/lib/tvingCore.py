__author__="NightRain"
rxyiLuwDGqJFNkOstvPlHEoAVBInRf=object
rxyiLuwDGqJFNkOstvPlHEoAVBInRQ=None
rxyiLuwDGqJFNkOstvPlHEoAVBInRX=False
rxyiLuwDGqJFNkOstvPlHEoAVBInRT=int
rxyiLuwDGqJFNkOstvPlHEoAVBIndp=True
rxyiLuwDGqJFNkOstvPlHEoAVBIndz=Exception
rxyiLuwDGqJFNkOstvPlHEoAVBIndY=print
rxyiLuwDGqJFNkOstvPlHEoAVBIndR=str
rxyiLuwDGqJFNkOstvPlHEoAVBIndS=list
rxyiLuwDGqJFNkOstvPlHEoAVBIndb=range
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import requests
rxyiLuwDGqJFNkOstvPlHEoAVBInpY ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'
rxyiLuwDGqJFNkOstvPlHEoAVBInpR={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
class rxyiLuwDGqJFNkOstvPlHEoAVBInpz(rxyiLuwDGqJFNkOstvPlHEoAVBInRf):
 def __init__(rxyiLuwDGqJFNkOstvPlHEoAVBInpd):
  rxyiLuwDGqJFNkOstvPlHEoAVBInpd.TVING_TOKEN =''
  rxyiLuwDGqJFNkOstvPlHEoAVBInpd.POC_USERINFO =''
  rxyiLuwDGqJFNkOstvPlHEoAVBInpd.TVING_UUID ='-'
  rxyiLuwDGqJFNkOstvPlHEoAVBInpd.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  rxyiLuwDGqJFNkOstvPlHEoAVBInpd.NETWORKCODE ='CSND0900'
  rxyiLuwDGqJFNkOstvPlHEoAVBInpd.OSCODE ='CSOD0900' 
  rxyiLuwDGqJFNkOstvPlHEoAVBInpd.TELECODE ='CSCD0900'
  rxyiLuwDGqJFNkOstvPlHEoAVBInpd.SCREENCODE ='CSSD0100'
  rxyiLuwDGqJFNkOstvPlHEoAVBInpd.LIVE_LIMIT =23
  rxyiLuwDGqJFNkOstvPlHEoAVBInpd.VOD_LIMIT =20
  rxyiLuwDGqJFNkOstvPlHEoAVBInpd.EPISODE_LIMIT=30 
  rxyiLuwDGqJFNkOstvPlHEoAVBInpd.SEARCH_LIMIT =80 
  rxyiLuwDGqJFNkOstvPlHEoAVBInpd.MOVIE_LIMIT =18
  rxyiLuwDGqJFNkOstvPlHEoAVBInpd.API_DOMAIN ='https://api.tving.com'
  rxyiLuwDGqJFNkOstvPlHEoAVBInpd.IMG_DOMAIN ='https://image.tving.com'
  rxyiLuwDGqJFNkOstvPlHEoAVBInpd.SEARCH_DOMAIN='https://search.tving.com'
  rxyiLuwDGqJFNkOstvPlHEoAVBInpd.LOGIN_DOMAIN ='https://user.tving.com'
  rxyiLuwDGqJFNkOstvPlHEoAVBInpd.URL_DOMAIN ='https://www.tving.com'
  rxyiLuwDGqJFNkOstvPlHEoAVBInpd.MOVIE_LITE ='338723'
  rxyiLuwDGqJFNkOstvPlHEoAVBInpd.MOVIE_PREMIUM='1513561'
  rxyiLuwDGqJFNkOstvPlHEoAVBInpd.DEFAULT_HEADER={'user-agent':rxyiLuwDGqJFNkOstvPlHEoAVBInpY}
 def callRequestCookies(rxyiLuwDGqJFNkOstvPlHEoAVBInpd,jobtype,rxyiLuwDGqJFNkOstvPlHEoAVBInpm,payload=rxyiLuwDGqJFNkOstvPlHEoAVBInRQ,params=rxyiLuwDGqJFNkOstvPlHEoAVBInRQ,headers=rxyiLuwDGqJFNkOstvPlHEoAVBInRQ,cookies=rxyiLuwDGqJFNkOstvPlHEoAVBInRQ,redirects=rxyiLuwDGqJFNkOstvPlHEoAVBInRX):
  rxyiLuwDGqJFNkOstvPlHEoAVBInpS=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.DEFAULT_HEADER
  if headers:rxyiLuwDGqJFNkOstvPlHEoAVBInpS.update(headers)
  if jobtype=='Get':
   rxyiLuwDGqJFNkOstvPlHEoAVBInpb=requests.get(rxyiLuwDGqJFNkOstvPlHEoAVBInpm,params=params,headers=rxyiLuwDGqJFNkOstvPlHEoAVBInpS,cookies=cookies,allow_redirects=redirects)
  else:
   rxyiLuwDGqJFNkOstvPlHEoAVBInpb=requests.post(rxyiLuwDGqJFNkOstvPlHEoAVBInpm,data=payload,params=params,headers=rxyiLuwDGqJFNkOstvPlHEoAVBInpS,cookies=cookies,allow_redirects=redirects)
  return rxyiLuwDGqJFNkOstvPlHEoAVBInpb
 def makeDefaultCookies(rxyiLuwDGqJFNkOstvPlHEoAVBInpd,vToken=rxyiLuwDGqJFNkOstvPlHEoAVBInRQ,vUserinfo=rxyiLuwDGqJFNkOstvPlHEoAVBInRQ):
  rxyiLuwDGqJFNkOstvPlHEoAVBInpW={}
  rxyiLuwDGqJFNkOstvPlHEoAVBInpW['_tving_token']=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.TVING_TOKEN if vToken==rxyiLuwDGqJFNkOstvPlHEoAVBInRQ else vToken
  rxyiLuwDGqJFNkOstvPlHEoAVBInpW['POC_USERINFO']=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.POC_USERINFO if vToken==rxyiLuwDGqJFNkOstvPlHEoAVBInRQ else vUserinfo
  return rxyiLuwDGqJFNkOstvPlHEoAVBInpW
 def getDeviceStr(rxyiLuwDGqJFNkOstvPlHEoAVBInpd):
  rxyiLuwDGqJFNkOstvPlHEoAVBInpg=[]
  rxyiLuwDGqJFNkOstvPlHEoAVBInpg.append('Windows') 
  rxyiLuwDGqJFNkOstvPlHEoAVBInpg.append('Chrome') 
  rxyiLuwDGqJFNkOstvPlHEoAVBInpg.append('ko-KR') 
  rxyiLuwDGqJFNkOstvPlHEoAVBInpg.append('undefined') 
  rxyiLuwDGqJFNkOstvPlHEoAVBInpg.append('24') 
  rxyiLuwDGqJFNkOstvPlHEoAVBInpg.append(u'한국 표준시')
  rxyiLuwDGqJFNkOstvPlHEoAVBInpg.append('undefined') 
  rxyiLuwDGqJFNkOstvPlHEoAVBInpg.append('undefined') 
  rxyiLuwDGqJFNkOstvPlHEoAVBInpg.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  rxyiLuwDGqJFNkOstvPlHEoAVBInph=''
  for rxyiLuwDGqJFNkOstvPlHEoAVBInpe in rxyiLuwDGqJFNkOstvPlHEoAVBInpg:
   rxyiLuwDGqJFNkOstvPlHEoAVBInph+=rxyiLuwDGqJFNkOstvPlHEoAVBInpe+'|'
  return rxyiLuwDGqJFNkOstvPlHEoAVBInph
 def SaveCredential(rxyiLuwDGqJFNkOstvPlHEoAVBInpd,rxyiLuwDGqJFNkOstvPlHEoAVBInpK):
  rxyiLuwDGqJFNkOstvPlHEoAVBInpd.TVING_TOKEN =rxyiLuwDGqJFNkOstvPlHEoAVBInpK.get('tving_token')
  rxyiLuwDGqJFNkOstvPlHEoAVBInpd.POC_USERINFO=rxyiLuwDGqJFNkOstvPlHEoAVBInpK.get('poc_userinfo')
  rxyiLuwDGqJFNkOstvPlHEoAVBInpd.TVING_UUID =rxyiLuwDGqJFNkOstvPlHEoAVBInpK.get('tving_uuid')
 def LoadCredential(rxyiLuwDGqJFNkOstvPlHEoAVBInpd):
  rxyiLuwDGqJFNkOstvPlHEoAVBInpK={'tving_token':rxyiLuwDGqJFNkOstvPlHEoAVBInpd.TVING_TOKEN,'poc_userinfo':rxyiLuwDGqJFNkOstvPlHEoAVBInpd.POC_USERINFO,'tving_uuid':rxyiLuwDGqJFNkOstvPlHEoAVBInpd.TVING_UUID}
  return rxyiLuwDGqJFNkOstvPlHEoAVBInpK
 def GetDefaultParams(rxyiLuwDGqJFNkOstvPlHEoAVBInpd):
  rxyiLuwDGqJFNkOstvPlHEoAVBInpU={'apiKey':rxyiLuwDGqJFNkOstvPlHEoAVBInpd.APIKEY,'networkCode':rxyiLuwDGqJFNkOstvPlHEoAVBInpd.NETWORKCODE,'osCode':rxyiLuwDGqJFNkOstvPlHEoAVBInpd.OSCODE,'teleCode':rxyiLuwDGqJFNkOstvPlHEoAVBInpd.TELECODE,'screenCode':rxyiLuwDGqJFNkOstvPlHEoAVBInpd.SCREENCODE}
  return rxyiLuwDGqJFNkOstvPlHEoAVBInpU
 def GetNoCache(rxyiLuwDGqJFNkOstvPlHEoAVBInpd,timetype=1):
  if timetype==1:
   return rxyiLuwDGqJFNkOstvPlHEoAVBInRT(time.time())
  else:
   return rxyiLuwDGqJFNkOstvPlHEoAVBInRT(time.time()*1000)
 def makeurl(rxyiLuwDGqJFNkOstvPlHEoAVBInpd,domain,path,query1=rxyiLuwDGqJFNkOstvPlHEoAVBInRQ,query2=rxyiLuwDGqJFNkOstvPlHEoAVBInRQ):
  rxyiLuwDGqJFNkOstvPlHEoAVBInpm=domain+path
  if query1:
   rxyiLuwDGqJFNkOstvPlHEoAVBInpm+='?%s'%urllib.parse.urlencode(query1)
  if query2:
   rxyiLuwDGqJFNkOstvPlHEoAVBInpm+='&%s'%urllib.parse.urlencode(query2)
  return rxyiLuwDGqJFNkOstvPlHEoAVBInpm
 def GetCredential(rxyiLuwDGqJFNkOstvPlHEoAVBInpd,user_id,user_pw,login_type):
  rxyiLuwDGqJFNkOstvPlHEoAVBInpa=rxyiLuwDGqJFNkOstvPlHEoAVBInRX
  rxyiLuwDGqJFNkOstvPlHEoAVBInpM=rxyiLuwDGqJFNkOstvPlHEoAVBInzp='' 
  rxyiLuwDGqJFNkOstvPlHEoAVBInpc='-'
  try:
   rxyiLuwDGqJFNkOstvPlHEoAVBInpf=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   rxyiLuwDGqJFNkOstvPlHEoAVBInpQ={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'','csite':''}
   rxyiLuwDGqJFNkOstvPlHEoAVBInpX=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.callRequestCookies('Post',rxyiLuwDGqJFNkOstvPlHEoAVBInpf,payload=rxyiLuwDGqJFNkOstvPlHEoAVBInpQ,params=rxyiLuwDGqJFNkOstvPlHEoAVBInRQ,headers=rxyiLuwDGqJFNkOstvPlHEoAVBInRQ,cookies=rxyiLuwDGqJFNkOstvPlHEoAVBInRQ)
   for rxyiLuwDGqJFNkOstvPlHEoAVBInpT in rxyiLuwDGqJFNkOstvPlHEoAVBInpX.cookies:
    if rxyiLuwDGqJFNkOstvPlHEoAVBInpT.name=='_tving_token':
     rxyiLuwDGqJFNkOstvPlHEoAVBInpM=rxyiLuwDGqJFNkOstvPlHEoAVBInpT.value
    elif rxyiLuwDGqJFNkOstvPlHEoAVBInpT.name=='POC_USERINFO':
     rxyiLuwDGqJFNkOstvPlHEoAVBInzp=rxyiLuwDGqJFNkOstvPlHEoAVBInpT.value
   if rxyiLuwDGqJFNkOstvPlHEoAVBInpM:rxyiLuwDGqJFNkOstvPlHEoAVBInpa=rxyiLuwDGqJFNkOstvPlHEoAVBIndp
   rxyiLuwDGqJFNkOstvPlHEoAVBInpc=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.GetDeviceList(rxyiLuwDGqJFNkOstvPlHEoAVBInpM,rxyiLuwDGqJFNkOstvPlHEoAVBInzp)
  except rxyiLuwDGqJFNkOstvPlHEoAVBIndz as exception:
   rxyiLuwDGqJFNkOstvPlHEoAVBInpM=rxyiLuwDGqJFNkOstvPlHEoAVBInzp='' 
   rxyiLuwDGqJFNkOstvPlHEoAVBInpc='-'
   rxyiLuwDGqJFNkOstvPlHEoAVBIndY(exception)
  rxyiLuwDGqJFNkOstvPlHEoAVBInpK={'tving_token':rxyiLuwDGqJFNkOstvPlHEoAVBInpM,'poc_userinfo':rxyiLuwDGqJFNkOstvPlHEoAVBInzp,'tving_uuid':rxyiLuwDGqJFNkOstvPlHEoAVBInpc}
  rxyiLuwDGqJFNkOstvPlHEoAVBInpd.SaveCredential(rxyiLuwDGqJFNkOstvPlHEoAVBInpK)
  return rxyiLuwDGqJFNkOstvPlHEoAVBInpa
 def GetBroadURL(rxyiLuwDGqJFNkOstvPlHEoAVBInpd,mediacode,sel_quality,stype):
  rxyiLuwDGqJFNkOstvPlHEoAVBInzY=''
  rxyiLuwDGqJFNkOstvPlHEoAVBInzR=''
  rxyiLuwDGqJFNkOstvPlHEoAVBInzd=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.TVING_UUID 
  try:
   if stype!='tvingtv':
    rxyiLuwDGqJFNkOstvPlHEoAVBInzS ='/v2/media/stream/info'
    rxyiLuwDGqJFNkOstvPlHEoAVBInzb=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.GetDefaultParams()
    rxyiLuwDGqJFNkOstvPlHEoAVBInzW={'info':'Y','mediaCode':mediacode,'noCache':rxyiLuwDGqJFNkOstvPlHEoAVBIndR(rxyiLuwDGqJFNkOstvPlHEoAVBInpd.GetNoCache(1)),'callingFrom':'HTML5','adReq':'none','ooc':'','deviceId':rxyiLuwDGqJFNkOstvPlHEoAVBInzd,'wm':'Y'}
    rxyiLuwDGqJFNkOstvPlHEoAVBInzb.update(rxyiLuwDGqJFNkOstvPlHEoAVBInzW)
    rxyiLuwDGqJFNkOstvPlHEoAVBInpm=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.makeurl(rxyiLuwDGqJFNkOstvPlHEoAVBInpd.API_DOMAIN,rxyiLuwDGqJFNkOstvPlHEoAVBInzS)
    rxyiLuwDGqJFNkOstvPlHEoAVBInpW=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.makeDefaultCookies()
    rxyiLuwDGqJFNkOstvPlHEoAVBInpX=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.callRequestCookies('Get',rxyiLuwDGqJFNkOstvPlHEoAVBInpm,payload=rxyiLuwDGqJFNkOstvPlHEoAVBInRQ,params=rxyiLuwDGqJFNkOstvPlHEoAVBInzb,headers=rxyiLuwDGqJFNkOstvPlHEoAVBInRQ,cookies=rxyiLuwDGqJFNkOstvPlHEoAVBInpW)
    rxyiLuwDGqJFNkOstvPlHEoAVBInzg=json.loads(rxyiLuwDGqJFNkOstvPlHEoAVBInpX.text)
    if not('stream' in rxyiLuwDGqJFNkOstvPlHEoAVBInzg['body']):return rxyiLuwDGqJFNkOstvPlHEoAVBInzY,rxyiLuwDGqJFNkOstvPlHEoAVBInzR 
    rxyiLuwDGqJFNkOstvPlHEoAVBInzh=rxyiLuwDGqJFNkOstvPlHEoAVBInzg['body']['stream']
    if 'drm_license_assertion' in rxyiLuwDGqJFNkOstvPlHEoAVBInzh:
     rxyiLuwDGqJFNkOstvPlHEoAVBInzR=rxyiLuwDGqJFNkOstvPlHEoAVBInzh['drm_license_assertion']
    rxyiLuwDGqJFNkOstvPlHEoAVBInze=rxyiLuwDGqJFNkOstvPlHEoAVBInzh['quality']
    rxyiLuwDGqJFNkOstvPlHEoAVBInzK=[]
    for rxyiLuwDGqJFNkOstvPlHEoAVBInzU in rxyiLuwDGqJFNkOstvPlHEoAVBInze:
     if rxyiLuwDGqJFNkOstvPlHEoAVBInzU['active']=='Y':
      rxyiLuwDGqJFNkOstvPlHEoAVBInzK.append({rxyiLuwDGqJFNkOstvPlHEoAVBInpR.get(rxyiLuwDGqJFNkOstvPlHEoAVBInzU['code']):rxyiLuwDGqJFNkOstvPlHEoAVBInzU['code']})
    rxyiLuwDGqJFNkOstvPlHEoAVBInzm=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.CheckQuality(sel_quality,rxyiLuwDGqJFNkOstvPlHEoAVBInzK)
   else:
    for rxyiLuwDGqJFNkOstvPlHEoAVBInzC,rxyiLuwDGqJFNkOstvPlHEoAVBInzT in rxyiLuwDGqJFNkOstvPlHEoAVBInpR.items():
     if rxyiLuwDGqJFNkOstvPlHEoAVBInzT==sel_quality:
      rxyiLuwDGqJFNkOstvPlHEoAVBInzm=rxyiLuwDGqJFNkOstvPlHEoAVBInzC
  except rxyiLuwDGqJFNkOstvPlHEoAVBIndz as exception:
   rxyiLuwDGqJFNkOstvPlHEoAVBIndY(exception)
   for rxyiLuwDGqJFNkOstvPlHEoAVBInzC,rxyiLuwDGqJFNkOstvPlHEoAVBInzT in rxyiLuwDGqJFNkOstvPlHEoAVBInpR.items():
    if rxyiLuwDGqJFNkOstvPlHEoAVBInzT==sel_quality:
     rxyiLuwDGqJFNkOstvPlHEoAVBInzm=rxyiLuwDGqJFNkOstvPlHEoAVBInzC
   return rxyiLuwDGqJFNkOstvPlHEoAVBInzY,rxyiLuwDGqJFNkOstvPlHEoAVBInzR
  try:
   rxyiLuwDGqJFNkOstvPlHEoAVBInzS ='/streaming/info'
   rxyiLuwDGqJFNkOstvPlHEoAVBInzb=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.GetDefaultParams()
   if stype=='onair':rxyiLuwDGqJFNkOstvPlHEoAVBInzb['osCode']='CSOD0400' 
   rxyiLuwDGqJFNkOstvPlHEoAVBInzj={'isTrusted':'false','NONE':'0','CAPTURING_PHASE':'1','AT_TARGET':'2','BUBBLING_PHASE':'3','type':'oocCreate','eventPhase':'0','bubbles':'false','cancelable':'false','defaultPrevented':'false','composed':'false','timeStamp':'2158.7350000045262','returnValue':'true','cancelBubble':'false'}
   rxyiLuwDGqJFNkOstvPlHEoAVBInza=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.makeOocUrl(rxyiLuwDGqJFNkOstvPlHEoAVBInzj)
   rxyiLuwDGqJFNkOstvPlHEoAVBInzM=urllib.parse.quote(rxyiLuwDGqJFNkOstvPlHEoAVBInza)
   rxyiLuwDGqJFNkOstvPlHEoAVBInzW={'info':'Y','mediaCode':mediacode,'callingFrom':'HTML5','streamCode':rxyiLuwDGqJFNkOstvPlHEoAVBInzm,'adReq':'none','ooc':rxyiLuwDGqJFNkOstvPlHEoAVBInza,'deviceId':rxyiLuwDGqJFNkOstvPlHEoAVBInzd}
   rxyiLuwDGqJFNkOstvPlHEoAVBInzc =rxyiLuwDGqJFNkOstvPlHEoAVBInzb
   rxyiLuwDGqJFNkOstvPlHEoAVBInzc.update(rxyiLuwDGqJFNkOstvPlHEoAVBInzW)
   rxyiLuwDGqJFNkOstvPlHEoAVBInpm=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.URL_DOMAIN+rxyiLuwDGqJFNkOstvPlHEoAVBInzS
   rxyiLuwDGqJFNkOstvPlHEoAVBInzf={'origin':'https://www.tving.com','Referer':'https://www.tving.com/vod/player/'+mediacode}
   rxyiLuwDGqJFNkOstvPlHEoAVBInpW=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.makeDefaultCookies()
   rxyiLuwDGqJFNkOstvPlHEoAVBInpW['onClickEvent2']=rxyiLuwDGqJFNkOstvPlHEoAVBInzM
   rxyiLuwDGqJFNkOstvPlHEoAVBInpX=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.callRequestCookies('Post',rxyiLuwDGqJFNkOstvPlHEoAVBInpm,payload=rxyiLuwDGqJFNkOstvPlHEoAVBInzc,params=rxyiLuwDGqJFNkOstvPlHEoAVBInRQ,headers=rxyiLuwDGqJFNkOstvPlHEoAVBInzf,cookies=rxyiLuwDGqJFNkOstvPlHEoAVBInpW)
   rxyiLuwDGqJFNkOstvPlHEoAVBInzg=json.loads(rxyiLuwDGqJFNkOstvPlHEoAVBInpX.text)
   if rxyiLuwDGqJFNkOstvPlHEoAVBInzR!='':
    rxyiLuwDGqJFNkOstvPlHEoAVBInzR =rxyiLuwDGqJFNkOstvPlHEoAVBInzg['stream']['drm_license_assertion']
    rxyiLuwDGqJFNkOstvPlHEoAVBInzY=rxyiLuwDGqJFNkOstvPlHEoAVBInzg['stream']['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in rxyiLuwDGqJFNkOstvPlHEoAVBInzg['stream']['broadcast']):return rxyiLuwDGqJFNkOstvPlHEoAVBInzY,rxyiLuwDGqJFNkOstvPlHEoAVBInzR
    rxyiLuwDGqJFNkOstvPlHEoAVBInzY=rxyiLuwDGqJFNkOstvPlHEoAVBInzg['stream']['broadcast']['broad_url']
  except rxyiLuwDGqJFNkOstvPlHEoAVBIndz as exception:
   rxyiLuwDGqJFNkOstvPlHEoAVBIndY(exception)
  return rxyiLuwDGqJFNkOstvPlHEoAVBInzY,rxyiLuwDGqJFNkOstvPlHEoAVBInzR
 def CheckQuality(rxyiLuwDGqJFNkOstvPlHEoAVBInpd,sel_qt,rxyiLuwDGqJFNkOstvPlHEoAVBInzK):
  for rxyiLuwDGqJFNkOstvPlHEoAVBInzQ in rxyiLuwDGqJFNkOstvPlHEoAVBInzK:
   if sel_qt>=rxyiLuwDGqJFNkOstvPlHEoAVBIndS(rxyiLuwDGqJFNkOstvPlHEoAVBInzQ)[0]:return rxyiLuwDGqJFNkOstvPlHEoAVBInzQ.get(rxyiLuwDGqJFNkOstvPlHEoAVBIndS(rxyiLuwDGqJFNkOstvPlHEoAVBInzQ)[0])
   rxyiLuwDGqJFNkOstvPlHEoAVBInzX=rxyiLuwDGqJFNkOstvPlHEoAVBInzQ.get(rxyiLuwDGqJFNkOstvPlHEoAVBIndS(rxyiLuwDGqJFNkOstvPlHEoAVBInzQ)[0])
  return rxyiLuwDGqJFNkOstvPlHEoAVBInzX
 def makeOocUrl(rxyiLuwDGqJFNkOstvPlHEoAVBInpd,rxyiLuwDGqJFNkOstvPlHEoAVBInzj):
  rxyiLuwDGqJFNkOstvPlHEoAVBInpm=''
  for rxyiLuwDGqJFNkOstvPlHEoAVBInzC,rxyiLuwDGqJFNkOstvPlHEoAVBInzT in rxyiLuwDGqJFNkOstvPlHEoAVBInzj.items():
   rxyiLuwDGqJFNkOstvPlHEoAVBInpm+="%s=%s^"%(rxyiLuwDGqJFNkOstvPlHEoAVBInzC,rxyiLuwDGqJFNkOstvPlHEoAVBInzT)
  return rxyiLuwDGqJFNkOstvPlHEoAVBInpm
 def GetLiveChannelList(rxyiLuwDGqJFNkOstvPlHEoAVBInpd,stype,page_int):
  rxyiLuwDGqJFNkOstvPlHEoAVBInYp=[]
  rxyiLuwDGqJFNkOstvPlHEoAVBInYz=rxyiLuwDGqJFNkOstvPlHEoAVBInRX
  try:
   rxyiLuwDGqJFNkOstvPlHEoAVBInzS ='/v2/media/lives'
   if stype=='onair':
    rxyiLuwDGqJFNkOstvPlHEoAVBInYR='CPCS0100,CPCS0400'
   else:
    rxyiLuwDGqJFNkOstvPlHEoAVBInYR='CPCS0300'
   rxyiLuwDGqJFNkOstvPlHEoAVBInzb=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.GetDefaultParams()
   rxyiLuwDGqJFNkOstvPlHEoAVBInzW={'pageNo':rxyiLuwDGqJFNkOstvPlHEoAVBIndR(page_int),'pageSize':rxyiLuwDGqJFNkOstvPlHEoAVBIndR(rxyiLuwDGqJFNkOstvPlHEoAVBInpd.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':rxyiLuwDGqJFNkOstvPlHEoAVBInYR,'_':rxyiLuwDGqJFNkOstvPlHEoAVBIndR(rxyiLuwDGqJFNkOstvPlHEoAVBInpd.GetNoCache(2))}
   rxyiLuwDGqJFNkOstvPlHEoAVBInzb.update(rxyiLuwDGqJFNkOstvPlHEoAVBInzW)
   rxyiLuwDGqJFNkOstvPlHEoAVBInpm=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.makeurl(rxyiLuwDGqJFNkOstvPlHEoAVBInpd.API_DOMAIN,rxyiLuwDGqJFNkOstvPlHEoAVBInzS)
   rxyiLuwDGqJFNkOstvPlHEoAVBInpW=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.makeDefaultCookies()
   rxyiLuwDGqJFNkOstvPlHEoAVBInpX=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.callRequestCookies('Get',rxyiLuwDGqJFNkOstvPlHEoAVBInpm,payload=rxyiLuwDGqJFNkOstvPlHEoAVBInRQ,params=rxyiLuwDGqJFNkOstvPlHEoAVBInzb,headers=rxyiLuwDGqJFNkOstvPlHEoAVBInRQ,cookies=rxyiLuwDGqJFNkOstvPlHEoAVBInpW)
   rxyiLuwDGqJFNkOstvPlHEoAVBInzg=json.loads(rxyiLuwDGqJFNkOstvPlHEoAVBInpX.text)
   if not('result' in rxyiLuwDGqJFNkOstvPlHEoAVBInzg['body']):return rxyiLuwDGqJFNkOstvPlHEoAVBInYp,rxyiLuwDGqJFNkOstvPlHEoAVBInYz
   rxyiLuwDGqJFNkOstvPlHEoAVBInYd=rxyiLuwDGqJFNkOstvPlHEoAVBInzg['body']['result']
   for rxyiLuwDGqJFNkOstvPlHEoAVBInzU in rxyiLuwDGqJFNkOstvPlHEoAVBInYd:
    rxyiLuwDGqJFNkOstvPlHEoAVBInYS={}
    rxyiLuwDGqJFNkOstvPlHEoAVBInYS['mediatype']='video'
    rxyiLuwDGqJFNkOstvPlHEoAVBInYb=rxyiLuwDGqJFNkOstvPlHEoAVBInYh=rxyiLuwDGqJFNkOstvPlHEoAVBInYe=rxyiLuwDGqJFNkOstvPlHEoAVBInYK=''
    rxyiLuwDGqJFNkOstvPlHEoAVBInYW=rxyiLuwDGqJFNkOstvPlHEoAVBInYj=''
    rxyiLuwDGqJFNkOstvPlHEoAVBInYg=rxyiLuwDGqJFNkOstvPlHEoAVBInzU['live_code']
    rxyiLuwDGqJFNkOstvPlHEoAVBInYb =rxyiLuwDGqJFNkOstvPlHEoAVBInzU['schedule']['channel']['name']['ko']
    if rxyiLuwDGqJFNkOstvPlHEoAVBInzU['schedule']['episode']!=rxyiLuwDGqJFNkOstvPlHEoAVBInRQ:
     rxyiLuwDGqJFNkOstvPlHEoAVBInYh =rxyiLuwDGqJFNkOstvPlHEoAVBInzU['schedule']['program']['name']['ko']
     rxyiLuwDGqJFNkOstvPlHEoAVBInYh =rxyiLuwDGqJFNkOstvPlHEoAVBInYh+', '+rxyiLuwDGqJFNkOstvPlHEoAVBIndR(rxyiLuwDGqJFNkOstvPlHEoAVBInzU['schedule']['episode']['frequency'])+'회'
     if rxyiLuwDGqJFNkOstvPlHEoAVBInzU['schedule']['episode']['image']!=[]:
      rxyiLuwDGqJFNkOstvPlHEoAVBInYe=rxyiLuwDGqJFNkOstvPlHEoAVBInzU['schedule']['episode']['image'][0]['url']
     rxyiLuwDGqJFNkOstvPlHEoAVBInYK=rxyiLuwDGqJFNkOstvPlHEoAVBInzU['schedule']['episode']['synopsis']['ko']
    else:
     rxyiLuwDGqJFNkOstvPlHEoAVBInYh =rxyiLuwDGqJFNkOstvPlHEoAVBInzU['schedule']['program']['name']['ko']
     if rxyiLuwDGqJFNkOstvPlHEoAVBInzU['schedule']['program']['image']!=[]:
      rxyiLuwDGqJFNkOstvPlHEoAVBInYe=rxyiLuwDGqJFNkOstvPlHEoAVBInzU['schedule']['program']['image'][0]['url']
     rxyiLuwDGqJFNkOstvPlHEoAVBInYK=rxyiLuwDGqJFNkOstvPlHEoAVBInzU['schedule']['program']['synopsis']['ko']
    rxyiLuwDGqJFNkOstvPlHEoAVBInYS['title'] =rxyiLuwDGqJFNkOstvPlHEoAVBInzU['schedule']['program']['name']['ko']
    rxyiLuwDGqJFNkOstvPlHEoAVBInYS['studio'] =rxyiLuwDGqJFNkOstvPlHEoAVBInYb
    try:
     rxyiLuwDGqJFNkOstvPlHEoAVBInYU=[]
     for rxyiLuwDGqJFNkOstvPlHEoAVBInYm in rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('schedule').get('program').get('actor'):rxyiLuwDGqJFNkOstvPlHEoAVBInYU.append(rxyiLuwDGqJFNkOstvPlHEoAVBInYm)
     if rxyiLuwDGqJFNkOstvPlHEoAVBInYU[0]!='' and rxyiLuwDGqJFNkOstvPlHEoAVBInYU[0]!=u'없음':rxyiLuwDGqJFNkOstvPlHEoAVBInYS['cast']=rxyiLuwDGqJFNkOstvPlHEoAVBInYU
    except:
     rxyiLuwDGqJFNkOstvPlHEoAVBInRQ
    try:
     rxyiLuwDGqJFNkOstvPlHEoAVBInYC=[]
     if rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('schedule').get('program').get('category1_name').get('ko')!='':
      rxyiLuwDGqJFNkOstvPlHEoAVBInYC.append(rxyiLuwDGqJFNkOstvPlHEoAVBInzU['schedule']['program']['category1_name']['ko'])
     if rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('schedule').get('program').get('category2_name').get('ko')!='':
      rxyiLuwDGqJFNkOstvPlHEoAVBInYC.append(rxyiLuwDGqJFNkOstvPlHEoAVBInzU['schedule']['program']['category2_name']['ko'])
     if rxyiLuwDGqJFNkOstvPlHEoAVBInYC[0]!='':rxyiLuwDGqJFNkOstvPlHEoAVBInYS['genre']=rxyiLuwDGqJFNkOstvPlHEoAVBInYC
    except:
     rxyiLuwDGqJFNkOstvPlHEoAVBInRQ
    if rxyiLuwDGqJFNkOstvPlHEoAVBInYe=='':
     rxyiLuwDGqJFNkOstvPlHEoAVBInYe=rxyiLuwDGqJFNkOstvPlHEoAVBInzU['schedule']['channel']['image'][0]['url']
    if rxyiLuwDGqJFNkOstvPlHEoAVBInYe!='':rxyiLuwDGqJFNkOstvPlHEoAVBInYe=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.IMG_DOMAIN+rxyiLuwDGqJFNkOstvPlHEoAVBInYe
    rxyiLuwDGqJFNkOstvPlHEoAVBInYW=rxyiLuwDGqJFNkOstvPlHEoAVBIndR(rxyiLuwDGqJFNkOstvPlHEoAVBInzU['schedule']['broadcast_start_time'])[8:12]
    rxyiLuwDGqJFNkOstvPlHEoAVBInYj =rxyiLuwDGqJFNkOstvPlHEoAVBIndR(rxyiLuwDGqJFNkOstvPlHEoAVBInzU['schedule']['broadcast_end_time'])[8:12]
    rxyiLuwDGqJFNkOstvPlHEoAVBInYa={'channel':rxyiLuwDGqJFNkOstvPlHEoAVBInYb,'title':rxyiLuwDGqJFNkOstvPlHEoAVBInYh,'mediacode':rxyiLuwDGqJFNkOstvPlHEoAVBInYg,'thumbnail':rxyiLuwDGqJFNkOstvPlHEoAVBInYe,'synopsis':rxyiLuwDGqJFNkOstvPlHEoAVBInYK,'channelepg':' [%s:%s ~ %s:%s]'%(rxyiLuwDGqJFNkOstvPlHEoAVBInYW[0:2],rxyiLuwDGqJFNkOstvPlHEoAVBInYW[2:],rxyiLuwDGqJFNkOstvPlHEoAVBInYj[0:2],rxyiLuwDGqJFNkOstvPlHEoAVBInYj[2:]),'info':rxyiLuwDGqJFNkOstvPlHEoAVBInYS}
    rxyiLuwDGqJFNkOstvPlHEoAVBInYp.append(rxyiLuwDGqJFNkOstvPlHEoAVBInYa)
   if rxyiLuwDGqJFNkOstvPlHEoAVBInzg['body']['has_more']=='Y':rxyiLuwDGqJFNkOstvPlHEoAVBInYz=rxyiLuwDGqJFNkOstvPlHEoAVBIndp
  except rxyiLuwDGqJFNkOstvPlHEoAVBIndz as exception:
   rxyiLuwDGqJFNkOstvPlHEoAVBIndY(exception)
  return rxyiLuwDGqJFNkOstvPlHEoAVBInYp,rxyiLuwDGqJFNkOstvPlHEoAVBInYz
 def GetProgramList(rxyiLuwDGqJFNkOstvPlHEoAVBInpd,stype,orderby,page_int,landyn=rxyiLuwDGqJFNkOstvPlHEoAVBInRX):
  rxyiLuwDGqJFNkOstvPlHEoAVBInYp=[]
  rxyiLuwDGqJFNkOstvPlHEoAVBInYz=rxyiLuwDGqJFNkOstvPlHEoAVBInRX
  try:
   rxyiLuwDGqJFNkOstvPlHEoAVBInzS ='/v2/media/episodes'
   rxyiLuwDGqJFNkOstvPlHEoAVBInzb=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.GetDefaultParams()
   rxyiLuwDGqJFNkOstvPlHEoAVBInzW={'pageNo':rxyiLuwDGqJFNkOstvPlHEoAVBIndR(page_int),'pageSize':rxyiLuwDGqJFNkOstvPlHEoAVBIndR(rxyiLuwDGqJFNkOstvPlHEoAVBInpd.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','_':rxyiLuwDGqJFNkOstvPlHEoAVBIndR(rxyiLuwDGqJFNkOstvPlHEoAVBInpd.GetNoCache(2))}
   if stype!='all':rxyiLuwDGqJFNkOstvPlHEoAVBInzW['multiCategoryCode']=stype
   rxyiLuwDGqJFNkOstvPlHEoAVBInzb.update(rxyiLuwDGqJFNkOstvPlHEoAVBInzW)
   rxyiLuwDGqJFNkOstvPlHEoAVBInpm=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.makeurl(rxyiLuwDGqJFNkOstvPlHEoAVBInpd.API_DOMAIN,rxyiLuwDGqJFNkOstvPlHEoAVBInzS)
   rxyiLuwDGqJFNkOstvPlHEoAVBInpW=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.makeDefaultCookies()
   rxyiLuwDGqJFNkOstvPlHEoAVBInpX=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.callRequestCookies('Get',rxyiLuwDGqJFNkOstvPlHEoAVBInpm,payload=rxyiLuwDGqJFNkOstvPlHEoAVBInRQ,params=rxyiLuwDGqJFNkOstvPlHEoAVBInzb,headers=rxyiLuwDGqJFNkOstvPlHEoAVBInRQ,cookies=rxyiLuwDGqJFNkOstvPlHEoAVBInpW)
   rxyiLuwDGqJFNkOstvPlHEoAVBInzg=json.loads(rxyiLuwDGqJFNkOstvPlHEoAVBInpX.text)
   if not('result' in rxyiLuwDGqJFNkOstvPlHEoAVBInzg['body']):return rxyiLuwDGqJFNkOstvPlHEoAVBInYp,rxyiLuwDGqJFNkOstvPlHEoAVBInYz
   rxyiLuwDGqJFNkOstvPlHEoAVBInYd=rxyiLuwDGqJFNkOstvPlHEoAVBInzg['body']['result']
   for rxyiLuwDGqJFNkOstvPlHEoAVBInzU in rxyiLuwDGqJFNkOstvPlHEoAVBInYd:
    rxyiLuwDGqJFNkOstvPlHEoAVBInYM=rxyiLuwDGqJFNkOstvPlHEoAVBInzU['program']['code']
    rxyiLuwDGqJFNkOstvPlHEoAVBInYh =rxyiLuwDGqJFNkOstvPlHEoAVBInzU['program']['name']['ko']
    rxyiLuwDGqJFNkOstvPlHEoAVBInYe =rxyiLuwDGqJFNkOstvPlHEoAVBInpd.IMG_DOMAIN+rxyiLuwDGqJFNkOstvPlHEoAVBInzU['program']['image'][0]['url']
    rxyiLuwDGqJFNkOstvPlHEoAVBInYc='CAIP0200' if landyn else 'CAIP0900' 
    for rxyiLuwDGqJFNkOstvPlHEoAVBInYf in rxyiLuwDGqJFNkOstvPlHEoAVBInzU['program']['image']:
     if rxyiLuwDGqJFNkOstvPlHEoAVBInYf['code']==rxyiLuwDGqJFNkOstvPlHEoAVBInYc:
      rxyiLuwDGqJFNkOstvPlHEoAVBInYe =rxyiLuwDGqJFNkOstvPlHEoAVBInpd.IMG_DOMAIN+rxyiLuwDGqJFNkOstvPlHEoAVBInYf['url']
      break
    rxyiLuwDGqJFNkOstvPlHEoAVBInYK =rxyiLuwDGqJFNkOstvPlHEoAVBInzU['program']['synopsis']['ko']
    rxyiLuwDGqJFNkOstvPlHEoAVBInYQ=rxyiLuwDGqJFNkOstvPlHEoAVBInzU['program']['channel_code']
    rxyiLuwDGqJFNkOstvPlHEoAVBInYS={}
    rxyiLuwDGqJFNkOstvPlHEoAVBInYS['title'] =rxyiLuwDGqJFNkOstvPlHEoAVBInYh 
    rxyiLuwDGqJFNkOstvPlHEoAVBInYS['mediatype']='episode' 
    try:
     rxyiLuwDGqJFNkOstvPlHEoAVBInYU=[]
     for rxyiLuwDGqJFNkOstvPlHEoAVBInYm in rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('program').get('actor'):rxyiLuwDGqJFNkOstvPlHEoAVBInYU.append(rxyiLuwDGqJFNkOstvPlHEoAVBInYm)
     if rxyiLuwDGqJFNkOstvPlHEoAVBInYU[0]!='' and rxyiLuwDGqJFNkOstvPlHEoAVBInYU[0]!='-':rxyiLuwDGqJFNkOstvPlHEoAVBInYS['cast']=rxyiLuwDGqJFNkOstvPlHEoAVBInYU
    except:
     rxyiLuwDGqJFNkOstvPlHEoAVBInRQ
    try:
     rxyiLuwDGqJFNkOstvPlHEoAVBInYX=[]
     for rxyiLuwDGqJFNkOstvPlHEoAVBInYT in rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('program').get('director'):rxyiLuwDGqJFNkOstvPlHEoAVBInYX.append(rxyiLuwDGqJFNkOstvPlHEoAVBInYT)
     if rxyiLuwDGqJFNkOstvPlHEoAVBInYX[0]!='' and rxyiLuwDGqJFNkOstvPlHEoAVBInYX[0]!='-':rxyiLuwDGqJFNkOstvPlHEoAVBInYS['director']=rxyiLuwDGqJFNkOstvPlHEoAVBInYX
    except:
     rxyiLuwDGqJFNkOstvPlHEoAVBInRQ
    rxyiLuwDGqJFNkOstvPlHEoAVBInYC=[]
    if rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('program').get('category1_name').get('ko')!='':
     rxyiLuwDGqJFNkOstvPlHEoAVBInYC.append(rxyiLuwDGqJFNkOstvPlHEoAVBInzU['program']['category1_name']['ko'])
    if rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('program').get('category2_name').get('ko')!='':
     rxyiLuwDGqJFNkOstvPlHEoAVBInYC.append(rxyiLuwDGqJFNkOstvPlHEoAVBInzU['program']['category2_name']['ko'])
    if rxyiLuwDGqJFNkOstvPlHEoAVBInYC[0]!='':rxyiLuwDGqJFNkOstvPlHEoAVBInYS['genre']=rxyiLuwDGqJFNkOstvPlHEoAVBInYC
    try:
     if rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('program').get('product_year'):rxyiLuwDGqJFNkOstvPlHEoAVBInYS['year']=rxyiLuwDGqJFNkOstvPlHEoAVBInzU['program']['product_year']
     if 'broad_dt' in rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('program'):
      rxyiLuwDGqJFNkOstvPlHEoAVBInRp=rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('program').get('broad_dt')
      rxyiLuwDGqJFNkOstvPlHEoAVBInYS['aired']='%s-%s-%s'%(rxyiLuwDGqJFNkOstvPlHEoAVBInRp[:4],rxyiLuwDGqJFNkOstvPlHEoAVBInRp[4:6],rxyiLuwDGqJFNkOstvPlHEoAVBInRp[6:])
    except:
     rxyiLuwDGqJFNkOstvPlHEoAVBInRQ
    rxyiLuwDGqJFNkOstvPlHEoAVBInYa={'program':rxyiLuwDGqJFNkOstvPlHEoAVBInYM,'title':rxyiLuwDGqJFNkOstvPlHEoAVBInYh,'thumbnail':rxyiLuwDGqJFNkOstvPlHEoAVBInYe,'synopsis':rxyiLuwDGqJFNkOstvPlHEoAVBInYK,'channel':rxyiLuwDGqJFNkOstvPlHEoAVBInYQ,'info':rxyiLuwDGqJFNkOstvPlHEoAVBInYS}
    rxyiLuwDGqJFNkOstvPlHEoAVBInYp.append(rxyiLuwDGqJFNkOstvPlHEoAVBInYa)
   if rxyiLuwDGqJFNkOstvPlHEoAVBInzg['body']['has_more']=='Y':rxyiLuwDGqJFNkOstvPlHEoAVBInYz=rxyiLuwDGqJFNkOstvPlHEoAVBIndp
  except rxyiLuwDGqJFNkOstvPlHEoAVBIndz as exception:
   rxyiLuwDGqJFNkOstvPlHEoAVBIndY(exception)
  return rxyiLuwDGqJFNkOstvPlHEoAVBInYp,rxyiLuwDGqJFNkOstvPlHEoAVBInYz
 def GetEpisodoList(rxyiLuwDGqJFNkOstvPlHEoAVBInpd,program_code,page_int,orderby='desc'):
  rxyiLuwDGqJFNkOstvPlHEoAVBInYp=[]
  rxyiLuwDGqJFNkOstvPlHEoAVBInYz=rxyiLuwDGqJFNkOstvPlHEoAVBInRX
  '''
  if desc_orderby == True:
   orderby = 'desc'
  else:
   orderby = 'asc'
  '''  
  try:
   rxyiLuwDGqJFNkOstvPlHEoAVBInzS ='/v2/media/frequency/program/'+program_code
   rxyiLuwDGqJFNkOstvPlHEoAVBInzb=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.GetDefaultParams()
   rxyiLuwDGqJFNkOstvPlHEoAVBInzW={'pageNo':'1','pageSize':'10','order':'new','free':'all','adult':'all','scope':'all','_':rxyiLuwDGqJFNkOstvPlHEoAVBIndR(rxyiLuwDGqJFNkOstvPlHEoAVBInpd.GetNoCache(2))}
   rxyiLuwDGqJFNkOstvPlHEoAVBInzb.update(rxyiLuwDGqJFNkOstvPlHEoAVBInzW)
   rxyiLuwDGqJFNkOstvPlHEoAVBInpm=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.makeurl(rxyiLuwDGqJFNkOstvPlHEoAVBInpd.API_DOMAIN,rxyiLuwDGqJFNkOstvPlHEoAVBInzS)
   rxyiLuwDGqJFNkOstvPlHEoAVBInpW=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.makeDefaultCookies()
   rxyiLuwDGqJFNkOstvPlHEoAVBInpX=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.callRequestCookies('Get',rxyiLuwDGqJFNkOstvPlHEoAVBInpm,payload=rxyiLuwDGqJFNkOstvPlHEoAVBInRQ,params=rxyiLuwDGqJFNkOstvPlHEoAVBInzb,headers=rxyiLuwDGqJFNkOstvPlHEoAVBInRQ,cookies=rxyiLuwDGqJFNkOstvPlHEoAVBInpW)
   rxyiLuwDGqJFNkOstvPlHEoAVBInzg=json.loads(rxyiLuwDGqJFNkOstvPlHEoAVBInpX.text)
   if not('result' in rxyiLuwDGqJFNkOstvPlHEoAVBInzg['body']):return rxyiLuwDGqJFNkOstvPlHEoAVBInYp,rxyiLuwDGqJFNkOstvPlHEoAVBInYz
   rxyiLuwDGqJFNkOstvPlHEoAVBInYd=rxyiLuwDGqJFNkOstvPlHEoAVBInzg['body']['result']
   rxyiLuwDGqJFNkOstvPlHEoAVBInRz=rxyiLuwDGqJFNkOstvPlHEoAVBInRT(rxyiLuwDGqJFNkOstvPlHEoAVBInzg['body']['total_count'])
   rxyiLuwDGqJFNkOstvPlHEoAVBInRY =rxyiLuwDGqJFNkOstvPlHEoAVBInRT(rxyiLuwDGqJFNkOstvPlHEoAVBInRz//(rxyiLuwDGqJFNkOstvPlHEoAVBInpd.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    rxyiLuwDGqJFNkOstvPlHEoAVBInRd =(rxyiLuwDGqJFNkOstvPlHEoAVBInRz-1)-((page_int-1)*rxyiLuwDGqJFNkOstvPlHEoAVBInpd.EPISODE_LIMIT)
   else:
    rxyiLuwDGqJFNkOstvPlHEoAVBInRd =(page_int-1)*rxyiLuwDGqJFNkOstvPlHEoAVBInpd.EPISODE_LIMIT
   for i in rxyiLuwDGqJFNkOstvPlHEoAVBIndb(rxyiLuwDGqJFNkOstvPlHEoAVBInpd.EPISODE_LIMIT):
    if orderby=='desc':
     rxyiLuwDGqJFNkOstvPlHEoAVBInRS=rxyiLuwDGqJFNkOstvPlHEoAVBInRd-i
     if rxyiLuwDGqJFNkOstvPlHEoAVBInRS<0:break
    else:
     rxyiLuwDGqJFNkOstvPlHEoAVBInRS=rxyiLuwDGqJFNkOstvPlHEoAVBInRd+i
     if rxyiLuwDGqJFNkOstvPlHEoAVBInRS>=rxyiLuwDGqJFNkOstvPlHEoAVBInRz:break
    rxyiLuwDGqJFNkOstvPlHEoAVBInRb=rxyiLuwDGqJFNkOstvPlHEoAVBInYd[rxyiLuwDGqJFNkOstvPlHEoAVBInRS]['episode']['code']
    rxyiLuwDGqJFNkOstvPlHEoAVBInYh =rxyiLuwDGqJFNkOstvPlHEoAVBInYd[rxyiLuwDGqJFNkOstvPlHEoAVBInRS]['vod_name']['ko']
    rxyiLuwDGqJFNkOstvPlHEoAVBInRW =''
    try:
     rxyiLuwDGqJFNkOstvPlHEoAVBInRp=rxyiLuwDGqJFNkOstvPlHEoAVBIndR(rxyiLuwDGqJFNkOstvPlHEoAVBInYd[rxyiLuwDGqJFNkOstvPlHEoAVBInRS]['episode']['broadcast_date'])
     rxyiLuwDGqJFNkOstvPlHEoAVBInRW='%s-%s-%s'%(rxyiLuwDGqJFNkOstvPlHEoAVBInRp[:4],rxyiLuwDGqJFNkOstvPlHEoAVBInRp[4:6],rxyiLuwDGqJFNkOstvPlHEoAVBInRp[6:])
    except:
     rxyiLuwDGqJFNkOstvPlHEoAVBInRQ
    if rxyiLuwDGqJFNkOstvPlHEoAVBInYd[rxyiLuwDGqJFNkOstvPlHEoAVBInRS]['episode']['image']!=[]:
     rxyiLuwDGqJFNkOstvPlHEoAVBInYe=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.IMG_DOMAIN+rxyiLuwDGqJFNkOstvPlHEoAVBInYd[rxyiLuwDGqJFNkOstvPlHEoAVBInRS]['episode']['image'][0]['url']
    else:
     rxyiLuwDGqJFNkOstvPlHEoAVBInYe=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.IMG_DOMAIN+rxyiLuwDGqJFNkOstvPlHEoAVBInYd[rxyiLuwDGqJFNkOstvPlHEoAVBInRS]['program']['image'][0]['url']
    rxyiLuwDGqJFNkOstvPlHEoAVBInYK =rxyiLuwDGqJFNkOstvPlHEoAVBInYd[rxyiLuwDGqJFNkOstvPlHEoAVBInRS]['episode']['synopsis']['ko']
    rxyiLuwDGqJFNkOstvPlHEoAVBInYS={}
    rxyiLuwDGqJFNkOstvPlHEoAVBInYS['mediatype']='episode' 
    try:
     rxyiLuwDGqJFNkOstvPlHEoAVBInYS['title'] =rxyiLuwDGqJFNkOstvPlHEoAVBInYd[rxyiLuwDGqJFNkOstvPlHEoAVBInRS]['program']['name']['ko']
     rxyiLuwDGqJFNkOstvPlHEoAVBInYS['aired'] =rxyiLuwDGqJFNkOstvPlHEoAVBInRW
     rxyiLuwDGqJFNkOstvPlHEoAVBInYS['studio'] =rxyiLuwDGqJFNkOstvPlHEoAVBInYd[rxyiLuwDGqJFNkOstvPlHEoAVBInRS]['channel']['name']['ko']
     if 'frequency' in rxyiLuwDGqJFNkOstvPlHEoAVBInYd[rxyiLuwDGqJFNkOstvPlHEoAVBInRS]['episode']:rxyiLuwDGqJFNkOstvPlHEoAVBInYS['episode']=rxyiLuwDGqJFNkOstvPlHEoAVBInYd[rxyiLuwDGqJFNkOstvPlHEoAVBInRS]['episode']['frequency']
    except:
     rxyiLuwDGqJFNkOstvPlHEoAVBInRQ
    rxyiLuwDGqJFNkOstvPlHEoAVBInYa={'episode':rxyiLuwDGqJFNkOstvPlHEoAVBInRb,'title':rxyiLuwDGqJFNkOstvPlHEoAVBInYh,'subtitle':rxyiLuwDGqJFNkOstvPlHEoAVBInRW,'thumbnail':rxyiLuwDGqJFNkOstvPlHEoAVBInYe,'synopsis':rxyiLuwDGqJFNkOstvPlHEoAVBInYK,'info':rxyiLuwDGqJFNkOstvPlHEoAVBInYS}
    rxyiLuwDGqJFNkOstvPlHEoAVBInYp.append(rxyiLuwDGqJFNkOstvPlHEoAVBInYa)
   if rxyiLuwDGqJFNkOstvPlHEoAVBInRY>page_int:rxyiLuwDGqJFNkOstvPlHEoAVBInYz=rxyiLuwDGqJFNkOstvPlHEoAVBIndp
  except rxyiLuwDGqJFNkOstvPlHEoAVBIndz as exception:
   rxyiLuwDGqJFNkOstvPlHEoAVBIndY(exception)
  return rxyiLuwDGqJFNkOstvPlHEoAVBInYp,rxyiLuwDGqJFNkOstvPlHEoAVBInYz,rxyiLuwDGqJFNkOstvPlHEoAVBInRY
 def GetMovieList(rxyiLuwDGqJFNkOstvPlHEoAVBInpd,orderby,page_int,premiumyn=rxyiLuwDGqJFNkOstvPlHEoAVBInRX,landyn=rxyiLuwDGqJFNkOstvPlHEoAVBInRX):
  rxyiLuwDGqJFNkOstvPlHEoAVBInYp=[]
  rxyiLuwDGqJFNkOstvPlHEoAVBInYz=rxyiLuwDGqJFNkOstvPlHEoAVBInRX
  if premiumyn==rxyiLuwDGqJFNkOstvPlHEoAVBIndp:
   rxyiLuwDGqJFNkOstvPlHEoAVBInRg=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.MOVIE_LITE+','+rxyiLuwDGqJFNkOstvPlHEoAVBInpd.MOVIE_PREMIUM
  else:
   rxyiLuwDGqJFNkOstvPlHEoAVBInRg=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.MOVIE_LITE
  try:
   rxyiLuwDGqJFNkOstvPlHEoAVBInzS ='/v2/media/movies'
   rxyiLuwDGqJFNkOstvPlHEoAVBInzb=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.GetDefaultParams()
   rxyiLuwDGqJFNkOstvPlHEoAVBInzW={'pageNo':rxyiLuwDGqJFNkOstvPlHEoAVBIndR(page_int),'pageSize':rxyiLuwDGqJFNkOstvPlHEoAVBIndR(rxyiLuwDGqJFNkOstvPlHEoAVBInpd.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','productPackageCode':rxyiLuwDGqJFNkOstvPlHEoAVBInRg,'_':rxyiLuwDGqJFNkOstvPlHEoAVBIndR(rxyiLuwDGqJFNkOstvPlHEoAVBInpd.GetNoCache(2))}
   rxyiLuwDGqJFNkOstvPlHEoAVBInzb.update(rxyiLuwDGqJFNkOstvPlHEoAVBInzW)
   rxyiLuwDGqJFNkOstvPlHEoAVBInpm=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.makeurl(rxyiLuwDGqJFNkOstvPlHEoAVBInpd.API_DOMAIN,rxyiLuwDGqJFNkOstvPlHEoAVBInzS)
   rxyiLuwDGqJFNkOstvPlHEoAVBInpW=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.makeDefaultCookies()
   rxyiLuwDGqJFNkOstvPlHEoAVBInpX=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.callRequestCookies('Get',rxyiLuwDGqJFNkOstvPlHEoAVBInpm,payload=rxyiLuwDGqJFNkOstvPlHEoAVBInRQ,params=rxyiLuwDGqJFNkOstvPlHEoAVBInzb,headers=rxyiLuwDGqJFNkOstvPlHEoAVBInRQ,cookies=rxyiLuwDGqJFNkOstvPlHEoAVBInpW)
   rxyiLuwDGqJFNkOstvPlHEoAVBInzg=json.loads(rxyiLuwDGqJFNkOstvPlHEoAVBInpX.text)
   if not('result' in rxyiLuwDGqJFNkOstvPlHEoAVBInzg['body']):return rxyiLuwDGqJFNkOstvPlHEoAVBInYp,rxyiLuwDGqJFNkOstvPlHEoAVBInYz
   rxyiLuwDGqJFNkOstvPlHEoAVBInYd=rxyiLuwDGqJFNkOstvPlHEoAVBInzg['body']['result']
   for rxyiLuwDGqJFNkOstvPlHEoAVBInzU in rxyiLuwDGqJFNkOstvPlHEoAVBInYd:
    rxyiLuwDGqJFNkOstvPlHEoAVBInRh =rxyiLuwDGqJFNkOstvPlHEoAVBInzU['movie']['code']
    rxyiLuwDGqJFNkOstvPlHEoAVBInYh =rxyiLuwDGqJFNkOstvPlHEoAVBInzU['movie']['name']['ko'].strip()
    rxyiLuwDGqJFNkOstvPlHEoAVBInYh +=u' (%s년)'%(rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('movie').get('product_year'))
    rxyiLuwDGqJFNkOstvPlHEoAVBInYe =rxyiLuwDGqJFNkOstvPlHEoAVBInpd.IMG_DOMAIN+rxyiLuwDGqJFNkOstvPlHEoAVBInzU['movie']['image'][0]['url']
    rxyiLuwDGqJFNkOstvPlHEoAVBInYc='CAIM0400' if landyn else 'CAIM2100' 
    for rxyiLuwDGqJFNkOstvPlHEoAVBInYf in rxyiLuwDGqJFNkOstvPlHEoAVBInzU['movie']['image']:
     if rxyiLuwDGqJFNkOstvPlHEoAVBInYf['code']==rxyiLuwDGqJFNkOstvPlHEoAVBInYc:
      rxyiLuwDGqJFNkOstvPlHEoAVBInYe =rxyiLuwDGqJFNkOstvPlHEoAVBInpd.IMG_DOMAIN+rxyiLuwDGqJFNkOstvPlHEoAVBInYf['url']
      break
    rxyiLuwDGqJFNkOstvPlHEoAVBInYK =rxyiLuwDGqJFNkOstvPlHEoAVBInzU['movie']['story']['ko']
    rxyiLuwDGqJFNkOstvPlHEoAVBInYS={}
    rxyiLuwDGqJFNkOstvPlHEoAVBInYS['mediatype']='movie' 
    rxyiLuwDGqJFNkOstvPlHEoAVBInYS['title'] = rxyiLuwDGqJFNkOstvPlHEoAVBInzU['movie']['name']['ko'].strip()
    rxyiLuwDGqJFNkOstvPlHEoAVBInYS['year'] =rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('movie').get('product_year')
    try:
     rxyiLuwDGqJFNkOstvPlHEoAVBInYU=[]
     for rxyiLuwDGqJFNkOstvPlHEoAVBInYm in rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('movie').get('actor'):rxyiLuwDGqJFNkOstvPlHEoAVBInYU.append(rxyiLuwDGqJFNkOstvPlHEoAVBInYm)
     if rxyiLuwDGqJFNkOstvPlHEoAVBInYU[0]!='':rxyiLuwDGqJFNkOstvPlHEoAVBInYS['cast']=rxyiLuwDGqJFNkOstvPlHEoAVBInYU
    except:
     rxyiLuwDGqJFNkOstvPlHEoAVBInRQ
    try:
     rxyiLuwDGqJFNkOstvPlHEoAVBInYX=[]
     for rxyiLuwDGqJFNkOstvPlHEoAVBInYT in rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('movie').get('director'):rxyiLuwDGqJFNkOstvPlHEoAVBInYX.append(rxyiLuwDGqJFNkOstvPlHEoAVBInYT)
     if rxyiLuwDGqJFNkOstvPlHEoAVBInYX[0]!='':rxyiLuwDGqJFNkOstvPlHEoAVBInYS['director']=rxyiLuwDGqJFNkOstvPlHEoAVBInYX
    except:
     rxyiLuwDGqJFNkOstvPlHEoAVBInRQ
    try:
     rxyiLuwDGqJFNkOstvPlHEoAVBInYC=[]
     if rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('movie').get('category1_name').get('ko')!='':
      rxyiLuwDGqJFNkOstvPlHEoAVBInYC.append(rxyiLuwDGqJFNkOstvPlHEoAVBInzU['movie']['category1_name']['ko'])
     if rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('movie').get('category2_name').get('ko')!='':
      rxyiLuwDGqJFNkOstvPlHEoAVBInYC.append(rxyiLuwDGqJFNkOstvPlHEoAVBInzU['movie']['category2_name']['ko'])
     if rxyiLuwDGqJFNkOstvPlHEoAVBInYC[0]!='':rxyiLuwDGqJFNkOstvPlHEoAVBInYS['genre']=rxyiLuwDGqJFNkOstvPlHEoAVBInYC
    except:
     rxyiLuwDGqJFNkOstvPlHEoAVBInRQ
    try:
     if 'release_date' in rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('movie'):
      rxyiLuwDGqJFNkOstvPlHEoAVBInRp=rxyiLuwDGqJFNkOstvPlHEoAVBIndR(rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('movie').get('release_date'))
      rxyiLuwDGqJFNkOstvPlHEoAVBInYS['aired']='%s-%s-%s'%(rxyiLuwDGqJFNkOstvPlHEoAVBInRp[:4],rxyiLuwDGqJFNkOstvPlHEoAVBInRp[4:6],rxyiLuwDGqJFNkOstvPlHEoAVBInRp[6:])
    except:
     rxyiLuwDGqJFNkOstvPlHEoAVBInRQ
    try:
     if 'duration' in rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('movie'):rxyiLuwDGqJFNkOstvPlHEoAVBInYS['duration']=rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('movie').get('duration')
    except:
     rxyiLuwDGqJFNkOstvPlHEoAVBInRQ
    rxyiLuwDGqJFNkOstvPlHEoAVBInYa={'moviecode':rxyiLuwDGqJFNkOstvPlHEoAVBInRh,'title':rxyiLuwDGqJFNkOstvPlHEoAVBInYh,'thumbnail':rxyiLuwDGqJFNkOstvPlHEoAVBInYe,'synopsis':rxyiLuwDGqJFNkOstvPlHEoAVBInYK,'info':rxyiLuwDGqJFNkOstvPlHEoAVBInYS}
    if premiumyn==rxyiLuwDGqJFNkOstvPlHEoAVBIndp:
     rxyiLuwDGqJFNkOstvPlHEoAVBInRe=rxyiLuwDGqJFNkOstvPlHEoAVBInRX
     for rxyiLuwDGqJFNkOstvPlHEoAVBInRK in rxyiLuwDGqJFNkOstvPlHEoAVBInzU['billing_package_id']:
      if rxyiLuwDGqJFNkOstvPlHEoAVBInRK==rxyiLuwDGqJFNkOstvPlHEoAVBInpd.MOVIE_LITE:
       rxyiLuwDGqJFNkOstvPlHEoAVBInRe=rxyiLuwDGqJFNkOstvPlHEoAVBIndp
       break
     if rxyiLuwDGqJFNkOstvPlHEoAVBInRe==rxyiLuwDGqJFNkOstvPlHEoAVBInRX:
      rxyiLuwDGqJFNkOstvPlHEoAVBInYa['title']=rxyiLuwDGqJFNkOstvPlHEoAVBInYa['title']+' [Premium]'
    rxyiLuwDGqJFNkOstvPlHEoAVBInYp.append(rxyiLuwDGqJFNkOstvPlHEoAVBInYa)
   if rxyiLuwDGqJFNkOstvPlHEoAVBInzg['body']['has_more']=='Y':rxyiLuwDGqJFNkOstvPlHEoAVBInYz=rxyiLuwDGqJFNkOstvPlHEoAVBIndp
  except rxyiLuwDGqJFNkOstvPlHEoAVBIndz as exception:
   rxyiLuwDGqJFNkOstvPlHEoAVBIndY(exception)
  return rxyiLuwDGqJFNkOstvPlHEoAVBInYp,rxyiLuwDGqJFNkOstvPlHEoAVBInYz
 def GetMovieListGenre(rxyiLuwDGqJFNkOstvPlHEoAVBInpd,genre,page_int,premiumyn=rxyiLuwDGqJFNkOstvPlHEoAVBInRX):
  rxyiLuwDGqJFNkOstvPlHEoAVBInYp=[]
  rxyiLuwDGqJFNkOstvPlHEoAVBInYz=rxyiLuwDGqJFNkOstvPlHEoAVBInRX
  if premiumyn==rxyiLuwDGqJFNkOstvPlHEoAVBIndp:
   rxyiLuwDGqJFNkOstvPlHEoAVBInRg=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.MOVIE_LITE+','+rxyiLuwDGqJFNkOstvPlHEoAVBInpd.MOVIE_PREMIUM
  else:
   rxyiLuwDGqJFNkOstvPlHEoAVBInRg=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.MOVIE_LITE
  try:
   rxyiLuwDGqJFNkOstvPlHEoAVBInzS ='/v2/media/movie/curation/'+genre
   rxyiLuwDGqJFNkOstvPlHEoAVBInzb=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.GetDefaultParams()
   rxyiLuwDGqJFNkOstvPlHEoAVBInzW={'pageNo':rxyiLuwDGqJFNkOstvPlHEoAVBIndR(page_int),'pageSize':rxyiLuwDGqJFNkOstvPlHEoAVBIndR(rxyiLuwDGqJFNkOstvPlHEoAVBInpd.MOVIE_LIMIT),'productPackageCode':rxyiLuwDGqJFNkOstvPlHEoAVBInRg,'_':rxyiLuwDGqJFNkOstvPlHEoAVBIndR(rxyiLuwDGqJFNkOstvPlHEoAVBInpd.GetNoCache(2))}
   rxyiLuwDGqJFNkOstvPlHEoAVBInzb.update(rxyiLuwDGqJFNkOstvPlHEoAVBInzW)
   rxyiLuwDGqJFNkOstvPlHEoAVBInpm=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.makeurl(rxyiLuwDGqJFNkOstvPlHEoAVBInpd.API_DOMAIN,rxyiLuwDGqJFNkOstvPlHEoAVBInzS)
   rxyiLuwDGqJFNkOstvPlHEoAVBInpW=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.makeDefaultCookies()
   rxyiLuwDGqJFNkOstvPlHEoAVBInpX=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.callRequestCookies('Get',rxyiLuwDGqJFNkOstvPlHEoAVBInpm,payload=rxyiLuwDGqJFNkOstvPlHEoAVBInRQ,params=rxyiLuwDGqJFNkOstvPlHEoAVBInzb,headers=rxyiLuwDGqJFNkOstvPlHEoAVBInRQ,cookies=rxyiLuwDGqJFNkOstvPlHEoAVBInpW)
   rxyiLuwDGqJFNkOstvPlHEoAVBInzg=json.loads(rxyiLuwDGqJFNkOstvPlHEoAVBInpX.text)
   if not('movies' in rxyiLuwDGqJFNkOstvPlHEoAVBInzg['body']):return rxyiLuwDGqJFNkOstvPlHEoAVBInYp,rxyiLuwDGqJFNkOstvPlHEoAVBInYz
   rxyiLuwDGqJFNkOstvPlHEoAVBInYd=rxyiLuwDGqJFNkOstvPlHEoAVBInzg['body']['movies']
   for rxyiLuwDGqJFNkOstvPlHEoAVBInzU in rxyiLuwDGqJFNkOstvPlHEoAVBInYd:
    rxyiLuwDGqJFNkOstvPlHEoAVBInRh =rxyiLuwDGqJFNkOstvPlHEoAVBInzU['code']
    rxyiLuwDGqJFNkOstvPlHEoAVBInYh =rxyiLuwDGqJFNkOstvPlHEoAVBInzU['name']['ko']
    rxyiLuwDGqJFNkOstvPlHEoAVBInYe =rxyiLuwDGqJFNkOstvPlHEoAVBInpd.IMG_DOMAIN+rxyiLuwDGqJFNkOstvPlHEoAVBInzU['image'][0]['url']
    for rxyiLuwDGqJFNkOstvPlHEoAVBInYf in rxyiLuwDGqJFNkOstvPlHEoAVBInzU['image']:
     if rxyiLuwDGqJFNkOstvPlHEoAVBInYf['code']=='CAIM2100':
      rxyiLuwDGqJFNkOstvPlHEoAVBInYe =rxyiLuwDGqJFNkOstvPlHEoAVBInpd.IMG_DOMAIN+rxyiLuwDGqJFNkOstvPlHEoAVBInYf['url']
    rxyiLuwDGqJFNkOstvPlHEoAVBInYK =rxyiLuwDGqJFNkOstvPlHEoAVBInzU['story']['ko']
    rxyiLuwDGqJFNkOstvPlHEoAVBInYa={'moviecode':rxyiLuwDGqJFNkOstvPlHEoAVBInRh,'title':rxyiLuwDGqJFNkOstvPlHEoAVBInYh.strip(),'thumbnail':rxyiLuwDGqJFNkOstvPlHEoAVBInYe,'synopsis':rxyiLuwDGqJFNkOstvPlHEoAVBInYK}
    if premiumyn==rxyiLuwDGqJFNkOstvPlHEoAVBIndp:
     rxyiLuwDGqJFNkOstvPlHEoAVBInRe=rxyiLuwDGqJFNkOstvPlHEoAVBInRX
     for rxyiLuwDGqJFNkOstvPlHEoAVBInRK in rxyiLuwDGqJFNkOstvPlHEoAVBInzU['billing_package_id']:
      if rxyiLuwDGqJFNkOstvPlHEoAVBInRK==rxyiLuwDGqJFNkOstvPlHEoAVBInpd.MOVIE_LITE:
       rxyiLuwDGqJFNkOstvPlHEoAVBInRe=rxyiLuwDGqJFNkOstvPlHEoAVBIndp
       break
     if rxyiLuwDGqJFNkOstvPlHEoAVBInRe==rxyiLuwDGqJFNkOstvPlHEoAVBInRX:
      rxyiLuwDGqJFNkOstvPlHEoAVBInYa['title']=rxyiLuwDGqJFNkOstvPlHEoAVBInYa['title']+' [Premium]'
    rxyiLuwDGqJFNkOstvPlHEoAVBInYp.append(rxyiLuwDGqJFNkOstvPlHEoAVBInYa)
  except rxyiLuwDGqJFNkOstvPlHEoAVBIndz as exception:
   rxyiLuwDGqJFNkOstvPlHEoAVBIndY(exception)
  return rxyiLuwDGqJFNkOstvPlHEoAVBInYp,rxyiLuwDGqJFNkOstvPlHEoAVBInYz
 def GetMovieGenre(rxyiLuwDGqJFNkOstvPlHEoAVBInpd):
  rxyiLuwDGqJFNkOstvPlHEoAVBInYp=[]
  rxyiLuwDGqJFNkOstvPlHEoAVBInYz=rxyiLuwDGqJFNkOstvPlHEoAVBInRX
  try:
   rxyiLuwDGqJFNkOstvPlHEoAVBInzS ='/v2/media/movie/curations'
   rxyiLuwDGqJFNkOstvPlHEoAVBInzb=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.GetDefaultParams()
   rxyiLuwDGqJFNkOstvPlHEoAVBInzW={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code','_':rxyiLuwDGqJFNkOstvPlHEoAVBIndR(rxyiLuwDGqJFNkOstvPlHEoAVBInpd.GetNoCache(2))}
   rxyiLuwDGqJFNkOstvPlHEoAVBInzb.update(rxyiLuwDGqJFNkOstvPlHEoAVBInzW)
   rxyiLuwDGqJFNkOstvPlHEoAVBInpm=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.makeurl(rxyiLuwDGqJFNkOstvPlHEoAVBInpd.API_DOMAIN,rxyiLuwDGqJFNkOstvPlHEoAVBInzS)
   rxyiLuwDGqJFNkOstvPlHEoAVBInpW=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.makeDefaultCookies()
   rxyiLuwDGqJFNkOstvPlHEoAVBInpX=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.callRequestCookies('Get',rxyiLuwDGqJFNkOstvPlHEoAVBInpm,payload=rxyiLuwDGqJFNkOstvPlHEoAVBInRQ,params=rxyiLuwDGqJFNkOstvPlHEoAVBInzb,headers=rxyiLuwDGqJFNkOstvPlHEoAVBInRQ,cookies=rxyiLuwDGqJFNkOstvPlHEoAVBInpW)
   rxyiLuwDGqJFNkOstvPlHEoAVBInzg=json.loads(rxyiLuwDGqJFNkOstvPlHEoAVBInpX.text)
   if not('result' in rxyiLuwDGqJFNkOstvPlHEoAVBInzg['body']):return rxyiLuwDGqJFNkOstvPlHEoAVBInYp,rxyiLuwDGqJFNkOstvPlHEoAVBInYz
   rxyiLuwDGqJFNkOstvPlHEoAVBInYd=rxyiLuwDGqJFNkOstvPlHEoAVBInzg['body']['result']
   for rxyiLuwDGqJFNkOstvPlHEoAVBInzU in rxyiLuwDGqJFNkOstvPlHEoAVBInYd:
    rxyiLuwDGqJFNkOstvPlHEoAVBInRU =rxyiLuwDGqJFNkOstvPlHEoAVBInzU['curation_code']
    rxyiLuwDGqJFNkOstvPlHEoAVBInRm =rxyiLuwDGqJFNkOstvPlHEoAVBInzU['curation_name']
    rxyiLuwDGqJFNkOstvPlHEoAVBInYa={'curation_code':rxyiLuwDGqJFNkOstvPlHEoAVBInRU,'curation_name':rxyiLuwDGqJFNkOstvPlHEoAVBInRm}
    rxyiLuwDGqJFNkOstvPlHEoAVBInYp.append(rxyiLuwDGqJFNkOstvPlHEoAVBInYa)
  except rxyiLuwDGqJFNkOstvPlHEoAVBIndz as exception:
   rxyiLuwDGqJFNkOstvPlHEoAVBIndY(exception)
  return rxyiLuwDGqJFNkOstvPlHEoAVBInYp,rxyiLuwDGqJFNkOstvPlHEoAVBInYz
 def GetSearchList(rxyiLuwDGqJFNkOstvPlHEoAVBInpd,search_key,userid,page_int,stype,premiumyn=rxyiLuwDGqJFNkOstvPlHEoAVBInRX,landyn=rxyiLuwDGqJFNkOstvPlHEoAVBInRX):
  rxyiLuwDGqJFNkOstvPlHEoAVBInRC=[]
  rxyiLuwDGqJFNkOstvPlHEoAVBInYz=rxyiLuwDGqJFNkOstvPlHEoAVBInRX
  try:
   rxyiLuwDGqJFNkOstvPlHEoAVBInzS ='/search/getSearch.jsp'
   rxyiLuwDGqJFNkOstvPlHEoAVBInzW={'kwd':search_key,'notFoundText':search_key,'userid':userid,'siteName':'TVING_WEB','category':'TOTAL','pageNum':rxyiLuwDGqJFNkOstvPlHEoAVBIndR(page_int),'pageSize':rxyiLuwDGqJFNkOstvPlHEoAVBIndR(rxyiLuwDGqJFNkOstvPlHEoAVBInpd.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':rxyiLuwDGqJFNkOstvPlHEoAVBInpd.SCREENCODE,'os':rxyiLuwDGqJFNkOstvPlHEoAVBInpd.OSCODE,'network':rxyiLuwDGqJFNkOstvPlHEoAVBInpd.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':rxyiLuwDGqJFNkOstvPlHEoAVBIndR(rxyiLuwDGqJFNkOstvPlHEoAVBInpd.SEARCH_LIMIT),'vodMVReqCnt':rxyiLuwDGqJFNkOstvPlHEoAVBIndR(rxyiLuwDGqJFNkOstvPlHEoAVBInpd.SEARCH_LIMIT),'smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':rxyiLuwDGqJFNkOstvPlHEoAVBIndR(rxyiLuwDGqJFNkOstvPlHEoAVBInpd.GetNoCache(2))}
   rxyiLuwDGqJFNkOstvPlHEoAVBInpm=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.makeurl(rxyiLuwDGqJFNkOstvPlHEoAVBInpd.SEARCH_DOMAIN,rxyiLuwDGqJFNkOstvPlHEoAVBInzS)
   rxyiLuwDGqJFNkOstvPlHEoAVBInpW=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.makeDefaultCookies()
   rxyiLuwDGqJFNkOstvPlHEoAVBInpX=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.callRequestCookies('Get',rxyiLuwDGqJFNkOstvPlHEoAVBInpm,payload=rxyiLuwDGqJFNkOstvPlHEoAVBInRQ,params=rxyiLuwDGqJFNkOstvPlHEoAVBInzW,headers=rxyiLuwDGqJFNkOstvPlHEoAVBInRQ,cookies=rxyiLuwDGqJFNkOstvPlHEoAVBInpW)
   rxyiLuwDGqJFNkOstvPlHEoAVBInzg=json.loads(rxyiLuwDGqJFNkOstvPlHEoAVBInpX.text)
   if stype=='vod':
    if not('programRsb' in rxyiLuwDGqJFNkOstvPlHEoAVBInzg):return rxyiLuwDGqJFNkOstvPlHEoAVBInRC,rxyiLuwDGqJFNkOstvPlHEoAVBInYz
    rxyiLuwDGqJFNkOstvPlHEoAVBInRj=rxyiLuwDGqJFNkOstvPlHEoAVBInzg['programRsb']['dataList']
    rxyiLuwDGqJFNkOstvPlHEoAVBInRa =rxyiLuwDGqJFNkOstvPlHEoAVBInRT(rxyiLuwDGqJFNkOstvPlHEoAVBInzg['programRsb']['count'])
    for rxyiLuwDGqJFNkOstvPlHEoAVBInzU in rxyiLuwDGqJFNkOstvPlHEoAVBInRj:
     rxyiLuwDGqJFNkOstvPlHEoAVBInYM=rxyiLuwDGqJFNkOstvPlHEoAVBInzU['mast_cd']
     rxyiLuwDGqJFNkOstvPlHEoAVBInYh =rxyiLuwDGqJFNkOstvPlHEoAVBInzU['mast_nm']
     rxyiLuwDGqJFNkOstvPlHEoAVBInYe =rxyiLuwDGqJFNkOstvPlHEoAVBInpd.IMG_DOMAIN+rxyiLuwDGqJFNkOstvPlHEoAVBInzU['web_url']
     if landyn==rxyiLuwDGqJFNkOstvPlHEoAVBInRX:
      rxyiLuwDGqJFNkOstvPlHEoAVBInYe =rxyiLuwDGqJFNkOstvPlHEoAVBInpd.IMG_DOMAIN+rxyiLuwDGqJFNkOstvPlHEoAVBInzU['web_url4']
     rxyiLuwDGqJFNkOstvPlHEoAVBInYS={}
     rxyiLuwDGqJFNkOstvPlHEoAVBInYS['title']=rxyiLuwDGqJFNkOstvPlHEoAVBInzU['mast_nm']
     rxyiLuwDGqJFNkOstvPlHEoAVBInYS['mediatype']='episode' 
     try:
      if rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('actor')!='' and rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('actor')!='-':rxyiLuwDGqJFNkOstvPlHEoAVBInYS['cast'] =rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('actor').split(',')
      if rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('director')!='' and rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('director')!='-':rxyiLuwDGqJFNkOstvPlHEoAVBInYS['director']=rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('director').split(',')
      if rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('cate_nm')!='':rxyiLuwDGqJFNkOstvPlHEoAVBInYS['genre'] =rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('cate_nm').split('/')
      if 'targetage' in rxyiLuwDGqJFNkOstvPlHEoAVBInzU:rxyiLuwDGqJFNkOstvPlHEoAVBInYS['mpaa']=rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('targetage')
     except:
      rxyiLuwDGqJFNkOstvPlHEoAVBInRQ
     try:
      if 'broad_dt' in rxyiLuwDGqJFNkOstvPlHEoAVBInzU:
       rxyiLuwDGqJFNkOstvPlHEoAVBInRp=rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('broad_dt')
       rxyiLuwDGqJFNkOstvPlHEoAVBInYS['aired']='%s-%s-%s'%(rxyiLuwDGqJFNkOstvPlHEoAVBInRp[:4],rxyiLuwDGqJFNkOstvPlHEoAVBInRp[4:6],rxyiLuwDGqJFNkOstvPlHEoAVBInRp[6:])
     except:
      rxyiLuwDGqJFNkOstvPlHEoAVBInRQ
     rxyiLuwDGqJFNkOstvPlHEoAVBInYa={'program':rxyiLuwDGqJFNkOstvPlHEoAVBInYM,'title':rxyiLuwDGqJFNkOstvPlHEoAVBInYh,'thumbnail':rxyiLuwDGqJFNkOstvPlHEoAVBInYe,'synopsis':'','info':rxyiLuwDGqJFNkOstvPlHEoAVBInYS}
     rxyiLuwDGqJFNkOstvPlHEoAVBInRC.append(rxyiLuwDGqJFNkOstvPlHEoAVBInYa)
   else:
    if not('vodMVRsb' in rxyiLuwDGqJFNkOstvPlHEoAVBInzg):return rxyiLuwDGqJFNkOstvPlHEoAVBInRC,rxyiLuwDGqJFNkOstvPlHEoAVBInYz
    rxyiLuwDGqJFNkOstvPlHEoAVBInRM=rxyiLuwDGqJFNkOstvPlHEoAVBInzg['vodMVRsb']['dataList']
    rxyiLuwDGqJFNkOstvPlHEoAVBInRa =rxyiLuwDGqJFNkOstvPlHEoAVBInRT(rxyiLuwDGqJFNkOstvPlHEoAVBInzg['vodMVRsb']['count'])
    for rxyiLuwDGqJFNkOstvPlHEoAVBInzU in rxyiLuwDGqJFNkOstvPlHEoAVBInRM:
     rxyiLuwDGqJFNkOstvPlHEoAVBInYM=rxyiLuwDGqJFNkOstvPlHEoAVBInzU['mast_cd']
     rxyiLuwDGqJFNkOstvPlHEoAVBInYh =rxyiLuwDGqJFNkOstvPlHEoAVBInzU['mast_nm'].strip()
     rxyiLuwDGqJFNkOstvPlHEoAVBInYe =rxyiLuwDGqJFNkOstvPlHEoAVBInpd.IMG_DOMAIN+rxyiLuwDGqJFNkOstvPlHEoAVBInzU['web_url']
     if landyn==rxyiLuwDGqJFNkOstvPlHEoAVBInRX:
      rxyiLuwDGqJFNkOstvPlHEoAVBInYe =rxyiLuwDGqJFNkOstvPlHEoAVBInpd.IMG_DOMAIN+rxyiLuwDGqJFNkOstvPlHEoAVBInzU['web_url5']
     '''
     premiumMovie = False
     liteMovie    = False
     for bill_now in i_section['bill']:
      if bill_now == self.MOVIE_LITE: liteMovie = True
      elif bill_now == self.MOVIE_PREMIUM: premiumMovie = True
     '''     
     rxyiLuwDGqJFNkOstvPlHEoAVBInYS={}
     rxyiLuwDGqJFNkOstvPlHEoAVBInYS['title'] =rxyiLuwDGqJFNkOstvPlHEoAVBInYh
     rxyiLuwDGqJFNkOstvPlHEoAVBInYS['mediatype']='movie' 
     try:
      if rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('actor') !='':rxyiLuwDGqJFNkOstvPlHEoAVBInYS['cast'] =rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('actor').split(',')
      if rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('cate_nm')!='':rxyiLuwDGqJFNkOstvPlHEoAVBInYS['genre'] =rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('cate_nm').split('/')
      if rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('runtime_sec')!='':rxyiLuwDGqJFNkOstvPlHEoAVBInYS['duration']=rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('runtime_sec')
      if 'grade_nm' in rxyiLuwDGqJFNkOstvPlHEoAVBInzU:rxyiLuwDGqJFNkOstvPlHEoAVBInYS['mpaa']=rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('grade_nm')
     except:
      rxyiLuwDGqJFNkOstvPlHEoAVBInRQ
     try:
      rxyiLuwDGqJFNkOstvPlHEoAVBInRp=rxyiLuwDGqJFNkOstvPlHEoAVBInzU.get('broad_dt')
      if data_str!='':
       rxyiLuwDGqJFNkOstvPlHEoAVBInYS['aired']='%s-%s-%s'%(rxyiLuwDGqJFNkOstvPlHEoAVBInRp[:4],rxyiLuwDGqJFNkOstvPlHEoAVBInRp[4:6],rxyiLuwDGqJFNkOstvPlHEoAVBInRp[6:])
       rxyiLuwDGqJFNkOstvPlHEoAVBInYS['year']=rxyiLuwDGqJFNkOstvPlHEoAVBInRp[:4]
     except:
      rxyiLuwDGqJFNkOstvPlHEoAVBInRQ
     if rxyiLuwDGqJFNkOstvPlHEoAVBIndp:
      rxyiLuwDGqJFNkOstvPlHEoAVBInYa={'movie':rxyiLuwDGqJFNkOstvPlHEoAVBInYM,'title':rxyiLuwDGqJFNkOstvPlHEoAVBInYh,'thumbnail':rxyiLuwDGqJFNkOstvPlHEoAVBInYe,'synopsis':'','info':rxyiLuwDGqJFNkOstvPlHEoAVBInYS}
      rxyiLuwDGqJFNkOstvPlHEoAVBInRC.append(rxyiLuwDGqJFNkOstvPlHEoAVBInYa)
  except rxyiLuwDGqJFNkOstvPlHEoAVBIndz as exception:
   rxyiLuwDGqJFNkOstvPlHEoAVBIndY(exception)
  return rxyiLuwDGqJFNkOstvPlHEoAVBInRC,rxyiLuwDGqJFNkOstvPlHEoAVBInYz
 def GetDeviceList(rxyiLuwDGqJFNkOstvPlHEoAVBInpd,rxyiLuwDGqJFNkOstvPlHEoAVBInpM,rxyiLuwDGqJFNkOstvPlHEoAVBInzp):
  rxyiLuwDGqJFNkOstvPlHEoAVBInYp=[]
  rxyiLuwDGqJFNkOstvPlHEoAVBInzd='-'
  try:
   rxyiLuwDGqJFNkOstvPlHEoAVBInzS ='/v1/user/device/list'
   rxyiLuwDGqJFNkOstvPlHEoAVBInRc=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.makeurl(rxyiLuwDGqJFNkOstvPlHEoAVBInpd.API_DOMAIN,rxyiLuwDGqJFNkOstvPlHEoAVBInzS)
   rxyiLuwDGqJFNkOstvPlHEoAVBInzW={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   rxyiLuwDGqJFNkOstvPlHEoAVBInpW=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.makeDefaultCookies(vToken=rxyiLuwDGqJFNkOstvPlHEoAVBInpM,vUserinfo=rxyiLuwDGqJFNkOstvPlHEoAVBInzp)
   rxyiLuwDGqJFNkOstvPlHEoAVBInpX=rxyiLuwDGqJFNkOstvPlHEoAVBInpd.callRequestCookies('Get',rxyiLuwDGqJFNkOstvPlHEoAVBInRc,payload=rxyiLuwDGqJFNkOstvPlHEoAVBInRQ,params=rxyiLuwDGqJFNkOstvPlHEoAVBInzW,headers=rxyiLuwDGqJFNkOstvPlHEoAVBInRQ,cookies=rxyiLuwDGqJFNkOstvPlHEoAVBInpW)
   rxyiLuwDGqJFNkOstvPlHEoAVBInzg=json.loads(rxyiLuwDGqJFNkOstvPlHEoAVBInpX.text)
   rxyiLuwDGqJFNkOstvPlHEoAVBInYp=rxyiLuwDGqJFNkOstvPlHEoAVBInzg['body']
   for rxyiLuwDGqJFNkOstvPlHEoAVBInzU in rxyiLuwDGqJFNkOstvPlHEoAVBInYp:
    if rxyiLuwDGqJFNkOstvPlHEoAVBInzU['model']=='PC':
     rxyiLuwDGqJFNkOstvPlHEoAVBInzd=rxyiLuwDGqJFNkOstvPlHEoAVBInzU['uuid']
  except rxyiLuwDGqJFNkOstvPlHEoAVBIndz as exception:
   rxyiLuwDGqJFNkOstvPlHEoAVBIndY(exception)
  return rxyiLuwDGqJFNkOstvPlHEoAVBInzd
# Created by pyminifier (https://github.com/liftoff/pyminifier)
