__author__="NightRain"
GaJRBIutYoAHPkxKphCnQUfOrvdWqF=object
GaJRBIutYoAHPkxKphCnQUfOrvdWqE=None
GaJRBIutYoAHPkxKphCnQUfOrvdWwc=False
GaJRBIutYoAHPkxKphCnQUfOrvdWwy=True
GaJRBIutYoAHPkxKphCnQUfOrvdWwL=int
GaJRBIutYoAHPkxKphCnQUfOrvdWwz=len
GaJRBIutYoAHPkxKphCnQUfOrvdWwq=TypeError
GaJRBIutYoAHPkxKphCnQUfOrvdWwi=str
GaJRBIutYoAHPkxKphCnQUfOrvdWwe=open
GaJRBIutYoAHPkxKphCnQUfOrvdWwM=dict
GaJRBIutYoAHPkxKphCnQUfOrvdWwN=Exception
GaJRBIutYoAHPkxKphCnQUfOrvdWws=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmc.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
GaJRBIutYoAHPkxKphCnQUfOrvdWcL=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-'},{'title':'VOD 방송 (인기순)','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 (최신순)','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'월정액 영화관 (인기)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewWeek','ordernm':'-'},{'title':'월정액 영화관 (최신)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'검색 (search)','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-'}]
GaJRBIutYoAHPkxKphCnQUfOrvdWcz=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
GaJRBIutYoAHPkxKphCnQUfOrvdWcq=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
GaJRBIutYoAHPkxKphCnQUfOrvdWcw=[{'title':'VOD 검색','mode':'SEARCH','stype':'vod'},{'title':'영화 검색','mode':'SEARCH','stype':'movie'}]
GaJRBIutYoAHPkxKphCnQUfOrvdWci=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'PROGRAM','stype':'PCPOS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'키즈/애니','mode':'PROGRAM','stype':'PCC,PCAN'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'뮤직','mode':'PROGRAM','stype':'PCG'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'}]
GaJRBIutYoAHPkxKphCnQUfOrvdWce={'C00551':'tvN','C00544':'중화TV','C00575':'Olive','C00579':'Mnet','C00590':'OGN','C01141':'XtvN','C01142':'ONSTYLE','C01143':'OtvN','C04601':'CGV','C06941':'tooniverse','C07381':'OCN','C07382':'SUPER ACTION','C15251':'OGN x LOL','C15252':'OGN x 오버워치','C15042':'티빙라이브','C01581':'TV CHOSUN','C01583':'채널A','C00708':'MBN','C00593':'YTN','C01101':'YTN Life','C15347':'YTN science','C01723':'연합뉴스TV','C15152':'DIA TV','C01582':'JTBC','C00588':'JTBC Golf','C15741':'JTBC2','C00805':'JTBC3 FOX Sports','C05661':'디즈니채널','C18641':'IHQ','C22041':'JTBC4','C23343':'t.cast','C23441':'E channel','C17341':'히스토리','C00585':'TV CHOSUN2','C17141':'채널A 플러스','C00611':'LIFETIME','C08041':'tvN go','C05901':'채널W','C23442':"D'LIVE",'C27441':'KBS N'}
GaJRBIutYoAHPkxKphCnQUfOrvdWcM ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'
GaJRBIutYoAHPkxKphCnQUfOrvdWcN=xbmc.translatePath(os.path.join(__profile__,'tving_cookies.json'))
from tvingCore import*
class GaJRBIutYoAHPkxKphCnQUfOrvdWcy(GaJRBIutYoAHPkxKphCnQUfOrvdWqF):
 def __init__(GaJRBIutYoAHPkxKphCnQUfOrvdWcs,GaJRBIutYoAHPkxKphCnQUfOrvdWcm,GaJRBIutYoAHPkxKphCnQUfOrvdWcl,GaJRBIutYoAHPkxKphCnQUfOrvdWcD):
  GaJRBIutYoAHPkxKphCnQUfOrvdWcs._addon_url =GaJRBIutYoAHPkxKphCnQUfOrvdWcm
  GaJRBIutYoAHPkxKphCnQUfOrvdWcs._addon_handle=GaJRBIutYoAHPkxKphCnQUfOrvdWcl
  GaJRBIutYoAHPkxKphCnQUfOrvdWcs.main_params =GaJRBIutYoAHPkxKphCnQUfOrvdWcD
  GaJRBIutYoAHPkxKphCnQUfOrvdWcs.TvingObj =rxyiLuwDGqJFNkOstvPlHEoAVBInpz() 
 def addon_noti(GaJRBIutYoAHPkxKphCnQUfOrvdWcs,sting):
  try:
   GaJRBIutYoAHPkxKphCnQUfOrvdWcg=xbmcgui.Dialog()
   GaJRBIutYoAHPkxKphCnQUfOrvdWcg.notification(__addonname__,sting)
  except:
   GaJRBIutYoAHPkxKphCnQUfOrvdWqE
 def addon_log(GaJRBIutYoAHPkxKphCnQUfOrvdWcs,string,isDebug=GaJRBIutYoAHPkxKphCnQUfOrvdWwc):
  try:
   GaJRBIutYoAHPkxKphCnQUfOrvdWcX=string.encode('utf-8','ignore')
  except:
   GaJRBIutYoAHPkxKphCnQUfOrvdWcX='addonException: addon_log'
  if isDebug:GaJRBIutYoAHPkxKphCnQUfOrvdWcV=xbmc.LOGDEBUG
  else:GaJRBIutYoAHPkxKphCnQUfOrvdWcV=xbmc.LOGNOTICE
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,GaJRBIutYoAHPkxKphCnQUfOrvdWcX),level=GaJRBIutYoAHPkxKphCnQUfOrvdWcV)
 def get_keyboard_input(GaJRBIutYoAHPkxKphCnQUfOrvdWcs,GaJRBIutYoAHPkxKphCnQUfOrvdWyi):
  GaJRBIutYoAHPkxKphCnQUfOrvdWcT=GaJRBIutYoAHPkxKphCnQUfOrvdWqE
  kb=xbmc.Keyboard()
  kb.setHeading(GaJRBIutYoAHPkxKphCnQUfOrvdWyi)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   GaJRBIutYoAHPkxKphCnQUfOrvdWcT=kb.getText()
  return GaJRBIutYoAHPkxKphCnQUfOrvdWcT
 def get_settings_login_info(GaJRBIutYoAHPkxKphCnQUfOrvdWcs):
  GaJRBIutYoAHPkxKphCnQUfOrvdWcb =__addon__.getSetting('id')
  GaJRBIutYoAHPkxKphCnQUfOrvdWcS =__addon__.getSetting('pw')
  GaJRBIutYoAHPkxKphCnQUfOrvdWcF =__addon__.getSetting('login_type')
  return(GaJRBIutYoAHPkxKphCnQUfOrvdWcb,GaJRBIutYoAHPkxKphCnQUfOrvdWcS,GaJRBIutYoAHPkxKphCnQUfOrvdWcF)
 def get_settings_premiumyn(GaJRBIutYoAHPkxKphCnQUfOrvdWcs):
  GaJRBIutYoAHPkxKphCnQUfOrvdWcE =__addon__.getSetting('premium_movieyn')
  if GaJRBIutYoAHPkxKphCnQUfOrvdWcE=='false':
   return GaJRBIutYoAHPkxKphCnQUfOrvdWwc
  else:
   return GaJRBIutYoAHPkxKphCnQUfOrvdWwy
 def get_settings_direct_replay(GaJRBIutYoAHPkxKphCnQUfOrvdWcs):
  GaJRBIutYoAHPkxKphCnQUfOrvdWyc=GaJRBIutYoAHPkxKphCnQUfOrvdWwL(__addon__.getSetting('direct_replay'))
  if GaJRBIutYoAHPkxKphCnQUfOrvdWyc==0:
   return GaJRBIutYoAHPkxKphCnQUfOrvdWwc
  else:
   return GaJRBIutYoAHPkxKphCnQUfOrvdWwy
 def get_settings_thumbnail_landyn(GaJRBIutYoAHPkxKphCnQUfOrvdWcs):
  GaJRBIutYoAHPkxKphCnQUfOrvdWyL =GaJRBIutYoAHPkxKphCnQUfOrvdWwL(__addon__.getSetting('thumbnail_way'))
  if GaJRBIutYoAHPkxKphCnQUfOrvdWyL==0:
   return GaJRBIutYoAHPkxKphCnQUfOrvdWwy
  else:
   return GaJRBIutYoAHPkxKphCnQUfOrvdWwc
 def set_winCredential(GaJRBIutYoAHPkxKphCnQUfOrvdWcs,credential):
  GaJRBIutYoAHPkxKphCnQUfOrvdWyz=xbmcgui.Window(10000)
  GaJRBIutYoAHPkxKphCnQUfOrvdWyz.setProperty('TVING_M_TOKEN',credential.get('tving_token'))
  GaJRBIutYoAHPkxKphCnQUfOrvdWyz.setProperty('TVING_M_USERINFO',credential.get('poc_userinfo'))
  GaJRBIutYoAHPkxKphCnQUfOrvdWyz.setProperty('TVING_M_UUID',credential.get('tving_uuid'))
  GaJRBIutYoAHPkxKphCnQUfOrvdWyz.setProperty('TVING_M_LOGINTIME',datetime.datetime.now().strftime('%Y-%m-%d'))
 def get_winCredential(GaJRBIutYoAHPkxKphCnQUfOrvdWcs):
  GaJRBIutYoAHPkxKphCnQUfOrvdWyz=xbmcgui.Window(10000)
  GaJRBIutYoAHPkxKphCnQUfOrvdWyq={'tving_token':GaJRBIutYoAHPkxKphCnQUfOrvdWyz.getProperty('TVING_M_TOKEN'),'poc_userinfo':GaJRBIutYoAHPkxKphCnQUfOrvdWyz.getProperty('TVING_M_USERINFO'),'tving_uuid':GaJRBIutYoAHPkxKphCnQUfOrvdWyz.getProperty('TVING_M_UUID')}
  return GaJRBIutYoAHPkxKphCnQUfOrvdWyq
 def set_winEpisodeOrderby(GaJRBIutYoAHPkxKphCnQUfOrvdWcs,GaJRBIutYoAHPkxKphCnQUfOrvdWLD):
  GaJRBIutYoAHPkxKphCnQUfOrvdWyz=xbmcgui.Window(10000)
  GaJRBIutYoAHPkxKphCnQUfOrvdWyz.setProperty('TVING_M_ORDERBY',GaJRBIutYoAHPkxKphCnQUfOrvdWLD)
 def get_winEpisodeOrderby(GaJRBIutYoAHPkxKphCnQUfOrvdWcs):
  GaJRBIutYoAHPkxKphCnQUfOrvdWyz=xbmcgui.Window(10000)
  return GaJRBIutYoAHPkxKphCnQUfOrvdWyz.getProperty('TVING_M_ORDERBY')
 def add_dir(GaJRBIutYoAHPkxKphCnQUfOrvdWcs,label,sublabel='',img='',infoLabels=GaJRBIutYoAHPkxKphCnQUfOrvdWqE,isFolder=GaJRBIutYoAHPkxKphCnQUfOrvdWwy,params=''):
  GaJRBIutYoAHPkxKphCnQUfOrvdWyw='%s?%s'%(GaJRBIutYoAHPkxKphCnQUfOrvdWcs._addon_url,urllib.parse.urlencode(params))
  if sublabel:GaJRBIutYoAHPkxKphCnQUfOrvdWyi='%s < %s >'%(label,sublabel)
  else: GaJRBIutYoAHPkxKphCnQUfOrvdWyi=label
  if not img:img='DefaultFolder.png'
  GaJRBIutYoAHPkxKphCnQUfOrvdWye=xbmcgui.ListItem(GaJRBIutYoAHPkxKphCnQUfOrvdWyi)
  GaJRBIutYoAHPkxKphCnQUfOrvdWye.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:GaJRBIutYoAHPkxKphCnQUfOrvdWye.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:GaJRBIutYoAHPkxKphCnQUfOrvdWye.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(GaJRBIutYoAHPkxKphCnQUfOrvdWcs._addon_handle,GaJRBIutYoAHPkxKphCnQUfOrvdWyw,GaJRBIutYoAHPkxKphCnQUfOrvdWye,isFolder)
 def get_selQuality(GaJRBIutYoAHPkxKphCnQUfOrvdWcs,etype):
  try:
   GaJRBIutYoAHPkxKphCnQUfOrvdWyM='selected_quality'
   GaJRBIutYoAHPkxKphCnQUfOrvdWyN=[1080,720,480,360]
   GaJRBIutYoAHPkxKphCnQUfOrvdWys=GaJRBIutYoAHPkxKphCnQUfOrvdWwL(__addon__.getSetting(GaJRBIutYoAHPkxKphCnQUfOrvdWyM))
   return GaJRBIutYoAHPkxKphCnQUfOrvdWyN[GaJRBIutYoAHPkxKphCnQUfOrvdWys]
  except:
   GaJRBIutYoAHPkxKphCnQUfOrvdWqE
  return 720 
 def dp_Main_List(GaJRBIutYoAHPkxKphCnQUfOrvdWcs):
  for GaJRBIutYoAHPkxKphCnQUfOrvdWym in GaJRBIutYoAHPkxKphCnQUfOrvdWcL:
   GaJRBIutYoAHPkxKphCnQUfOrvdWyi=GaJRBIutYoAHPkxKphCnQUfOrvdWym.get('title')
   GaJRBIutYoAHPkxKphCnQUfOrvdWyl={'mode':GaJRBIutYoAHPkxKphCnQUfOrvdWym.get('mode'),'stype':GaJRBIutYoAHPkxKphCnQUfOrvdWym.get('stype'),'orderby':GaJRBIutYoAHPkxKphCnQUfOrvdWym.get('orderby'),'ordernm':GaJRBIutYoAHPkxKphCnQUfOrvdWym.get('ordernm'),'page':'1'}
   if GaJRBIutYoAHPkxKphCnQUfOrvdWym.get('mode')=='XXX':
    GaJRBIutYoAHPkxKphCnQUfOrvdWyl['mode']='XXX'
    GaJRBIutYoAHPkxKphCnQUfOrvdWyD=GaJRBIutYoAHPkxKphCnQUfOrvdWwc
   else:
    GaJRBIutYoAHPkxKphCnQUfOrvdWyD=GaJRBIutYoAHPkxKphCnQUfOrvdWwy
   GaJRBIutYoAHPkxKphCnQUfOrvdWcs.add_dir(GaJRBIutYoAHPkxKphCnQUfOrvdWyi,sublabel='',img='',infoLabels=GaJRBIutYoAHPkxKphCnQUfOrvdWqE,isFolder=GaJRBIutYoAHPkxKphCnQUfOrvdWyD,params=GaJRBIutYoAHPkxKphCnQUfOrvdWyl)
  if GaJRBIutYoAHPkxKphCnQUfOrvdWwz(GaJRBIutYoAHPkxKphCnQUfOrvdWcL)>0:xbmcplugin.endOfDirectory(GaJRBIutYoAHPkxKphCnQUfOrvdWcs._addon_handle)
 def login_main(GaJRBIutYoAHPkxKphCnQUfOrvdWcs):
  (GaJRBIutYoAHPkxKphCnQUfOrvdWyg,GaJRBIutYoAHPkxKphCnQUfOrvdWyX,GaJRBIutYoAHPkxKphCnQUfOrvdWyV)=GaJRBIutYoAHPkxKphCnQUfOrvdWcs.get_settings_login_info()
  if not(GaJRBIutYoAHPkxKphCnQUfOrvdWyg and GaJRBIutYoAHPkxKphCnQUfOrvdWyX):
   GaJRBIutYoAHPkxKphCnQUfOrvdWcg=xbmcgui.Dialog()
   GaJRBIutYoAHPkxKphCnQUfOrvdWyT=GaJRBIutYoAHPkxKphCnQUfOrvdWcg.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if GaJRBIutYoAHPkxKphCnQUfOrvdWyT==GaJRBIutYoAHPkxKphCnQUfOrvdWwy:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if GaJRBIutYoAHPkxKphCnQUfOrvdWcs.get_winEpisodeOrderby()=='':
   GaJRBIutYoAHPkxKphCnQUfOrvdWcs.set_winEpisodeOrderby('desc')
  if GaJRBIutYoAHPkxKphCnQUfOrvdWcs.cookiefile_check():return
  GaJRBIutYoAHPkxKphCnQUfOrvdWyb =datetime.datetime.now().date()
  GaJRBIutYoAHPkxKphCnQUfOrvdWyS=xbmcgui.Window(10000).getProperty('TVING_M_LOGINTIME')
  if GaJRBIutYoAHPkxKphCnQUfOrvdWyS==GaJRBIutYoAHPkxKphCnQUfOrvdWqE or GaJRBIutYoAHPkxKphCnQUfOrvdWyS=='':GaJRBIutYoAHPkxKphCnQUfOrvdWyS='1900-01-01'
  try:
   GaJRBIutYoAHPkxKphCnQUfOrvdWyS=datetime.datetime.strptime(GaJRBIutYoAHPkxKphCnQUfOrvdWyS,'%Y-%m-%d').date()
  except GaJRBIutYoAHPkxKphCnQUfOrvdWwq:
   GaJRBIutYoAHPkxKphCnQUfOrvdWyS=datetime.datetime(*(time.strptime(GaJRBIutYoAHPkxKphCnQUfOrvdWyS,'%Y-%m-%d')[0:6])).date()
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   GaJRBIutYoAHPkxKphCnQUfOrvdWyF=0
   while GaJRBIutYoAHPkxKphCnQUfOrvdWwy:
    GaJRBIutYoAHPkxKphCnQUfOrvdWyF+=1
    time.sleep(0.05)
    if GaJRBIutYoAHPkxKphCnQUfOrvdWyS>=GaJRBIutYoAHPkxKphCnQUfOrvdWyb:return
    if GaJRBIutYoAHPkxKphCnQUfOrvdWyF>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  if GaJRBIutYoAHPkxKphCnQUfOrvdWyS>=GaJRBIutYoAHPkxKphCnQUfOrvdWyb:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   return
  if not GaJRBIutYoAHPkxKphCnQUfOrvdWcs.TvingObj.GetCredential(GaJRBIutYoAHPkxKphCnQUfOrvdWyg,GaJRBIutYoAHPkxKphCnQUfOrvdWyX,GaJRBIutYoAHPkxKphCnQUfOrvdWyV):
   GaJRBIutYoAHPkxKphCnQUfOrvdWcs.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   sys.exit()
  GaJRBIutYoAHPkxKphCnQUfOrvdWcs.set_winCredential(GaJRBIutYoAHPkxKphCnQUfOrvdWcs.TvingObj.LoadCredential())
  GaJRBIutYoAHPkxKphCnQUfOrvdWcs.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
 def dp_Title_Group(GaJRBIutYoAHPkxKphCnQUfOrvdWcs,GaJRBIutYoAHPkxKphCnQUfOrvdWLz):
  GaJRBIutYoAHPkxKphCnQUfOrvdWyE=GaJRBIutYoAHPkxKphCnQUfOrvdWLz.get('stype')
  if GaJRBIutYoAHPkxKphCnQUfOrvdWyE=='live':
   GaJRBIutYoAHPkxKphCnQUfOrvdWLc=GaJRBIutYoAHPkxKphCnQUfOrvdWcz
  else:
   GaJRBIutYoAHPkxKphCnQUfOrvdWLc=GaJRBIutYoAHPkxKphCnQUfOrvdWci
  for GaJRBIutYoAHPkxKphCnQUfOrvdWLy in GaJRBIutYoAHPkxKphCnQUfOrvdWLc:
   GaJRBIutYoAHPkxKphCnQUfOrvdWyi=GaJRBIutYoAHPkxKphCnQUfOrvdWLy.get('title')
   if GaJRBIutYoAHPkxKphCnQUfOrvdWLz.get('ordernm')!='-':
    GaJRBIutYoAHPkxKphCnQUfOrvdWyi+='  ('+GaJRBIutYoAHPkxKphCnQUfOrvdWLz.get('ordernm')+')'
   GaJRBIutYoAHPkxKphCnQUfOrvdWyl={'mode':GaJRBIutYoAHPkxKphCnQUfOrvdWLy.get('mode'),'stype':GaJRBIutYoAHPkxKphCnQUfOrvdWLy.get('stype'),'orderby':GaJRBIutYoAHPkxKphCnQUfOrvdWLz.get('orderby'),'page':'1'}
   GaJRBIutYoAHPkxKphCnQUfOrvdWcs.add_dir(GaJRBIutYoAHPkxKphCnQUfOrvdWyi,sublabel='',img='',infoLabels=GaJRBIutYoAHPkxKphCnQUfOrvdWqE,isFolder=GaJRBIutYoAHPkxKphCnQUfOrvdWwy,params=GaJRBIutYoAHPkxKphCnQUfOrvdWyl)
  if GaJRBIutYoAHPkxKphCnQUfOrvdWwz(GaJRBIutYoAHPkxKphCnQUfOrvdWLc)>0:xbmcplugin.endOfDirectory(GaJRBIutYoAHPkxKphCnQUfOrvdWcs._addon_handle)
 def dp_LiveChannel_List(GaJRBIutYoAHPkxKphCnQUfOrvdWcs,GaJRBIutYoAHPkxKphCnQUfOrvdWLz):
  GaJRBIutYoAHPkxKphCnQUfOrvdWcs.TvingObj.SaveCredential(GaJRBIutYoAHPkxKphCnQUfOrvdWcs.get_winCredential())
  GaJRBIutYoAHPkxKphCnQUfOrvdWyE =GaJRBIutYoAHPkxKphCnQUfOrvdWLz.get('stype')
  GaJRBIutYoAHPkxKphCnQUfOrvdWLq =GaJRBIutYoAHPkxKphCnQUfOrvdWwL(GaJRBIutYoAHPkxKphCnQUfOrvdWLz.get('page'))
  GaJRBIutYoAHPkxKphCnQUfOrvdWLw,GaJRBIutYoAHPkxKphCnQUfOrvdWLi=GaJRBIutYoAHPkxKphCnQUfOrvdWcs.TvingObj.GetLiveChannelList(GaJRBIutYoAHPkxKphCnQUfOrvdWyE,GaJRBIutYoAHPkxKphCnQUfOrvdWLq)
  for GaJRBIutYoAHPkxKphCnQUfOrvdWLe in GaJRBIutYoAHPkxKphCnQUfOrvdWLw:
   GaJRBIutYoAHPkxKphCnQUfOrvdWyi =GaJRBIutYoAHPkxKphCnQUfOrvdWLe.get('title')
   GaJRBIutYoAHPkxKphCnQUfOrvdWyj =GaJRBIutYoAHPkxKphCnQUfOrvdWLe.get('channel')
   GaJRBIutYoAHPkxKphCnQUfOrvdWLM =GaJRBIutYoAHPkxKphCnQUfOrvdWLe.get('thumbnail')
   GaJRBIutYoAHPkxKphCnQUfOrvdWLN =GaJRBIutYoAHPkxKphCnQUfOrvdWLe.get('synopsis')
   GaJRBIutYoAHPkxKphCnQUfOrvdWLs=GaJRBIutYoAHPkxKphCnQUfOrvdWLe.get('channelepg')
   GaJRBIutYoAHPkxKphCnQUfOrvdWLm=GaJRBIutYoAHPkxKphCnQUfOrvdWLe.get('info')
   GaJRBIutYoAHPkxKphCnQUfOrvdWLm['plot']='%s\n%s\n%s\n\n%s'%(GaJRBIutYoAHPkxKphCnQUfOrvdWyj,GaJRBIutYoAHPkxKphCnQUfOrvdWyi,GaJRBIutYoAHPkxKphCnQUfOrvdWLs,GaJRBIutYoAHPkxKphCnQUfOrvdWLN)
   GaJRBIutYoAHPkxKphCnQUfOrvdWyl={'mode':'LIVE','mediacode':GaJRBIutYoAHPkxKphCnQUfOrvdWLe.get('mediacode'),'stype':GaJRBIutYoAHPkxKphCnQUfOrvdWyE}
   GaJRBIutYoAHPkxKphCnQUfOrvdWcs.add_dir(GaJRBIutYoAHPkxKphCnQUfOrvdWyj,sublabel=GaJRBIutYoAHPkxKphCnQUfOrvdWyi,img=GaJRBIutYoAHPkxKphCnQUfOrvdWLM,infoLabels=GaJRBIutYoAHPkxKphCnQUfOrvdWLm,isFolder=GaJRBIutYoAHPkxKphCnQUfOrvdWwc,params=GaJRBIutYoAHPkxKphCnQUfOrvdWyl)
  if GaJRBIutYoAHPkxKphCnQUfOrvdWLi:
   GaJRBIutYoAHPkxKphCnQUfOrvdWyl['mode']='CHANNEL' 
   GaJRBIutYoAHPkxKphCnQUfOrvdWyl['stype']=GaJRBIutYoAHPkxKphCnQUfOrvdWyE 
   GaJRBIutYoAHPkxKphCnQUfOrvdWyl['page']=GaJRBIutYoAHPkxKphCnQUfOrvdWwi(GaJRBIutYoAHPkxKphCnQUfOrvdWLq+1)
   GaJRBIutYoAHPkxKphCnQUfOrvdWyi='[B]%s >>[/B]'%'다음 페이지'
   GaJRBIutYoAHPkxKphCnQUfOrvdWLl=GaJRBIutYoAHPkxKphCnQUfOrvdWwi(GaJRBIutYoAHPkxKphCnQUfOrvdWLq+1)
   GaJRBIutYoAHPkxKphCnQUfOrvdWcs.add_dir(GaJRBIutYoAHPkxKphCnQUfOrvdWyi,sublabel=GaJRBIutYoAHPkxKphCnQUfOrvdWLl,img='',infoLabels=GaJRBIutYoAHPkxKphCnQUfOrvdWqE,isFolder=GaJRBIutYoAHPkxKphCnQUfOrvdWwy,params=GaJRBIutYoAHPkxKphCnQUfOrvdWyl)
  if GaJRBIutYoAHPkxKphCnQUfOrvdWwz(GaJRBIutYoAHPkxKphCnQUfOrvdWLw)>0:xbmcplugin.endOfDirectory(GaJRBIutYoAHPkxKphCnQUfOrvdWcs._addon_handle,cacheToDisc=GaJRBIutYoAHPkxKphCnQUfOrvdWwc)
 def dp_Program_List(GaJRBIutYoAHPkxKphCnQUfOrvdWcs,GaJRBIutYoAHPkxKphCnQUfOrvdWLz):
  GaJRBIutYoAHPkxKphCnQUfOrvdWcs.TvingObj.SaveCredential(GaJRBIutYoAHPkxKphCnQUfOrvdWcs.get_winCredential())
  GaJRBIutYoAHPkxKphCnQUfOrvdWyE =GaJRBIutYoAHPkxKphCnQUfOrvdWLz.get('stype')
  GaJRBIutYoAHPkxKphCnQUfOrvdWLD =GaJRBIutYoAHPkxKphCnQUfOrvdWLz.get('orderby')
  GaJRBIutYoAHPkxKphCnQUfOrvdWLq =GaJRBIutYoAHPkxKphCnQUfOrvdWwL(GaJRBIutYoAHPkxKphCnQUfOrvdWLz.get('page'))
  GaJRBIutYoAHPkxKphCnQUfOrvdWLj,GaJRBIutYoAHPkxKphCnQUfOrvdWLi=GaJRBIutYoAHPkxKphCnQUfOrvdWcs.TvingObj.GetProgramList(GaJRBIutYoAHPkxKphCnQUfOrvdWyE,GaJRBIutYoAHPkxKphCnQUfOrvdWLD,GaJRBIutYoAHPkxKphCnQUfOrvdWLq,landyn=GaJRBIutYoAHPkxKphCnQUfOrvdWcs.get_settings_thumbnail_landyn())
  for GaJRBIutYoAHPkxKphCnQUfOrvdWLg in GaJRBIutYoAHPkxKphCnQUfOrvdWLj:
   GaJRBIutYoAHPkxKphCnQUfOrvdWyi =GaJRBIutYoAHPkxKphCnQUfOrvdWLg.get('title')
   GaJRBIutYoAHPkxKphCnQUfOrvdWLM=GaJRBIutYoAHPkxKphCnQUfOrvdWLg.get('thumbnail')
   GaJRBIutYoAHPkxKphCnQUfOrvdWLN =GaJRBIutYoAHPkxKphCnQUfOrvdWLg.get('synopsis')
   GaJRBIutYoAHPkxKphCnQUfOrvdWLX =GaJRBIutYoAHPkxKphCnQUfOrvdWce.get(GaJRBIutYoAHPkxKphCnQUfOrvdWLg.get('channel'))
   GaJRBIutYoAHPkxKphCnQUfOrvdWLm=GaJRBIutYoAHPkxKphCnQUfOrvdWLg.get('info')
   GaJRBIutYoAHPkxKphCnQUfOrvdWLm['studio']=GaJRBIutYoAHPkxKphCnQUfOrvdWLX
   GaJRBIutYoAHPkxKphCnQUfOrvdWLm['plot']='%s <%s>\n\n%s'%(GaJRBIutYoAHPkxKphCnQUfOrvdWyi,GaJRBIutYoAHPkxKphCnQUfOrvdWLX,GaJRBIutYoAHPkxKphCnQUfOrvdWLN)
   GaJRBIutYoAHPkxKphCnQUfOrvdWyl={'mode':'EPISODE','programcode':GaJRBIutYoAHPkxKphCnQUfOrvdWLg.get('program'),'page':'1'}
   GaJRBIutYoAHPkxKphCnQUfOrvdWcs.add_dir(GaJRBIutYoAHPkxKphCnQUfOrvdWyi,sublabel=GaJRBIutYoAHPkxKphCnQUfOrvdWLX,img=GaJRBIutYoAHPkxKphCnQUfOrvdWLM,infoLabels=GaJRBIutYoAHPkxKphCnQUfOrvdWLm,isFolder=GaJRBIutYoAHPkxKphCnQUfOrvdWwy,params=GaJRBIutYoAHPkxKphCnQUfOrvdWyl)
  if GaJRBIutYoAHPkxKphCnQUfOrvdWLi:
   GaJRBIutYoAHPkxKphCnQUfOrvdWyl['mode'] ='PROGRAM' 
   GaJRBIutYoAHPkxKphCnQUfOrvdWyl['stype'] =GaJRBIutYoAHPkxKphCnQUfOrvdWyE
   GaJRBIutYoAHPkxKphCnQUfOrvdWyl['orderby']=GaJRBIutYoAHPkxKphCnQUfOrvdWLD
   GaJRBIutYoAHPkxKphCnQUfOrvdWyl['page'] =GaJRBIutYoAHPkxKphCnQUfOrvdWwi(GaJRBIutYoAHPkxKphCnQUfOrvdWLq+1)
   GaJRBIutYoAHPkxKphCnQUfOrvdWyi='[B]%s >>[/B]'%'다음 페이지'
   GaJRBIutYoAHPkxKphCnQUfOrvdWLl=GaJRBIutYoAHPkxKphCnQUfOrvdWwi(GaJRBIutYoAHPkxKphCnQUfOrvdWLq+1)
   GaJRBIutYoAHPkxKphCnQUfOrvdWcs.add_dir(GaJRBIutYoAHPkxKphCnQUfOrvdWyi,sublabel=GaJRBIutYoAHPkxKphCnQUfOrvdWLl,img='',infoLabels=GaJRBIutYoAHPkxKphCnQUfOrvdWqE,isFolder=GaJRBIutYoAHPkxKphCnQUfOrvdWwy,params=GaJRBIutYoAHPkxKphCnQUfOrvdWyl)
  if GaJRBIutYoAHPkxKphCnQUfOrvdWwz(GaJRBIutYoAHPkxKphCnQUfOrvdWLj)>0:xbmcplugin.endOfDirectory(GaJRBIutYoAHPkxKphCnQUfOrvdWcs._addon_handle,cacheToDisc=GaJRBIutYoAHPkxKphCnQUfOrvdWwc)
 def dp_Episode_List(GaJRBIutYoAHPkxKphCnQUfOrvdWcs,GaJRBIutYoAHPkxKphCnQUfOrvdWLz):
  GaJRBIutYoAHPkxKphCnQUfOrvdWcs.TvingObj.SaveCredential(GaJRBIutYoAHPkxKphCnQUfOrvdWcs.get_winCredential())
  GaJRBIutYoAHPkxKphCnQUfOrvdWLV=GaJRBIutYoAHPkxKphCnQUfOrvdWLz.get('programcode')
  GaJRBIutYoAHPkxKphCnQUfOrvdWLq =GaJRBIutYoAHPkxKphCnQUfOrvdWwL(GaJRBIutYoAHPkxKphCnQUfOrvdWLz.get('page'))
  GaJRBIutYoAHPkxKphCnQUfOrvdWLT,GaJRBIutYoAHPkxKphCnQUfOrvdWLi,GaJRBIutYoAHPkxKphCnQUfOrvdWLb=GaJRBIutYoAHPkxKphCnQUfOrvdWcs.TvingObj.GetEpisodoList(GaJRBIutYoAHPkxKphCnQUfOrvdWLV,GaJRBIutYoAHPkxKphCnQUfOrvdWLq,orderby=GaJRBIutYoAHPkxKphCnQUfOrvdWcs.get_winEpisodeOrderby())
  for GaJRBIutYoAHPkxKphCnQUfOrvdWLS in GaJRBIutYoAHPkxKphCnQUfOrvdWLT:
   GaJRBIutYoAHPkxKphCnQUfOrvdWyi =GaJRBIutYoAHPkxKphCnQUfOrvdWLS.get('title')
   GaJRBIutYoAHPkxKphCnQUfOrvdWLl =GaJRBIutYoAHPkxKphCnQUfOrvdWLS.get('subtitle')
   GaJRBIutYoAHPkxKphCnQUfOrvdWLM=GaJRBIutYoAHPkxKphCnQUfOrvdWLS.get('thumbnail')
   GaJRBIutYoAHPkxKphCnQUfOrvdWLN =GaJRBIutYoAHPkxKphCnQUfOrvdWLS.get('synopsis')
   GaJRBIutYoAHPkxKphCnQUfOrvdWLm=GaJRBIutYoAHPkxKphCnQUfOrvdWLS.get('info')
   GaJRBIutYoAHPkxKphCnQUfOrvdWLm['plot']='%s\n\n%s'%(GaJRBIutYoAHPkxKphCnQUfOrvdWyi,GaJRBIutYoAHPkxKphCnQUfOrvdWLN)
   GaJRBIutYoAHPkxKphCnQUfOrvdWyl={'mode':'VOD','mediacode':GaJRBIutYoAHPkxKphCnQUfOrvdWLS.get('episode'),'stype':'vod','programcode':GaJRBIutYoAHPkxKphCnQUfOrvdWLV,'title':GaJRBIutYoAHPkxKphCnQUfOrvdWyi,'thumbnail':GaJRBIutYoAHPkxKphCnQUfOrvdWLM}
   GaJRBIutYoAHPkxKphCnQUfOrvdWcs.add_dir(GaJRBIutYoAHPkxKphCnQUfOrvdWyi,sublabel=GaJRBIutYoAHPkxKphCnQUfOrvdWLl,img=GaJRBIutYoAHPkxKphCnQUfOrvdWLM,infoLabels=GaJRBIutYoAHPkxKphCnQUfOrvdWLm,isFolder=GaJRBIutYoAHPkxKphCnQUfOrvdWwc,params=GaJRBIutYoAHPkxKphCnQUfOrvdWyl)
  if GaJRBIutYoAHPkxKphCnQUfOrvdWLq==1:
   GaJRBIutYoAHPkxKphCnQUfOrvdWLm={'plot':'정렬순서를 변경합니다.'}
   GaJRBIutYoAHPkxKphCnQUfOrvdWyl={}
   GaJRBIutYoAHPkxKphCnQUfOrvdWyl['mode'] ='ORDER_BY' 
   if GaJRBIutYoAHPkxKphCnQUfOrvdWcs.get_winEpisodeOrderby()=='desc':
    GaJRBIutYoAHPkxKphCnQUfOrvdWyi='정렬순서변경 : 최신화부터 -> 1회부터'
    GaJRBIutYoAHPkxKphCnQUfOrvdWyl['orderby']='asc'
   else:
    GaJRBIutYoAHPkxKphCnQUfOrvdWyi='정렬순서변경 : 1회부터 -> 최신화부터'
    GaJRBIutYoAHPkxKphCnQUfOrvdWyl['orderby']='desc'
   GaJRBIutYoAHPkxKphCnQUfOrvdWcs.add_dir(GaJRBIutYoAHPkxKphCnQUfOrvdWyi,sublabel='',img='',infoLabels=GaJRBIutYoAHPkxKphCnQUfOrvdWLm,isFolder=GaJRBIutYoAHPkxKphCnQUfOrvdWwc,params=GaJRBIutYoAHPkxKphCnQUfOrvdWyl)
  if GaJRBIutYoAHPkxKphCnQUfOrvdWLi:
   GaJRBIutYoAHPkxKphCnQUfOrvdWyl['mode'] ='EPISODE' 
   GaJRBIutYoAHPkxKphCnQUfOrvdWyl['programcode']=GaJRBIutYoAHPkxKphCnQUfOrvdWLV
   GaJRBIutYoAHPkxKphCnQUfOrvdWyl['page'] =GaJRBIutYoAHPkxKphCnQUfOrvdWwi(GaJRBIutYoAHPkxKphCnQUfOrvdWLq+1)
   GaJRBIutYoAHPkxKphCnQUfOrvdWyi='[B]%s >>[/B]'%'다음 페이지'
   GaJRBIutYoAHPkxKphCnQUfOrvdWLl=GaJRBIutYoAHPkxKphCnQUfOrvdWwi(GaJRBIutYoAHPkxKphCnQUfOrvdWLq+1)
   GaJRBIutYoAHPkxKphCnQUfOrvdWcs.add_dir(GaJRBIutYoAHPkxKphCnQUfOrvdWyi,sublabel=GaJRBIutYoAHPkxKphCnQUfOrvdWLl,img='',infoLabels=GaJRBIutYoAHPkxKphCnQUfOrvdWqE,isFolder=GaJRBIutYoAHPkxKphCnQUfOrvdWwy,params=GaJRBIutYoAHPkxKphCnQUfOrvdWyl)
  if GaJRBIutYoAHPkxKphCnQUfOrvdWwz(GaJRBIutYoAHPkxKphCnQUfOrvdWLT)>0:xbmcplugin.endOfDirectory(GaJRBIutYoAHPkxKphCnQUfOrvdWcs._addon_handle,cacheToDisc=GaJRBIutYoAHPkxKphCnQUfOrvdWwy)
 def dp_setEpOrderby(GaJRBIutYoAHPkxKphCnQUfOrvdWcs,GaJRBIutYoAHPkxKphCnQUfOrvdWLz):
  GaJRBIutYoAHPkxKphCnQUfOrvdWLD =GaJRBIutYoAHPkxKphCnQUfOrvdWLz.get('orderby')
  GaJRBIutYoAHPkxKphCnQUfOrvdWcs.set_winEpisodeOrderby(GaJRBIutYoAHPkxKphCnQUfOrvdWLD)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(GaJRBIutYoAHPkxKphCnQUfOrvdWcs,GaJRBIutYoAHPkxKphCnQUfOrvdWLz):
  GaJRBIutYoAHPkxKphCnQUfOrvdWcs.TvingObj.SaveCredential(GaJRBIutYoAHPkxKphCnQUfOrvdWcs.get_winCredential())
  GaJRBIutYoAHPkxKphCnQUfOrvdWLD =GaJRBIutYoAHPkxKphCnQUfOrvdWLz.get('orderby')
  GaJRBIutYoAHPkxKphCnQUfOrvdWLq=GaJRBIutYoAHPkxKphCnQUfOrvdWwL(GaJRBIutYoAHPkxKphCnQUfOrvdWLz.get('page'))
  GaJRBIutYoAHPkxKphCnQUfOrvdWLF,GaJRBIutYoAHPkxKphCnQUfOrvdWLi=GaJRBIutYoAHPkxKphCnQUfOrvdWcs.TvingObj.GetMovieList(GaJRBIutYoAHPkxKphCnQUfOrvdWLD,GaJRBIutYoAHPkxKphCnQUfOrvdWLq,premiumyn=GaJRBIutYoAHPkxKphCnQUfOrvdWcs.get_settings_premiumyn(),landyn=GaJRBIutYoAHPkxKphCnQUfOrvdWcs.get_settings_thumbnail_landyn())
  for GaJRBIutYoAHPkxKphCnQUfOrvdWLE in GaJRBIutYoAHPkxKphCnQUfOrvdWLF:
   GaJRBIutYoAHPkxKphCnQUfOrvdWyi =GaJRBIutYoAHPkxKphCnQUfOrvdWLE.get('title')
   GaJRBIutYoAHPkxKphCnQUfOrvdWLM=GaJRBIutYoAHPkxKphCnQUfOrvdWLE.get('thumbnail')
   GaJRBIutYoAHPkxKphCnQUfOrvdWLN =GaJRBIutYoAHPkxKphCnQUfOrvdWLE.get('synopsis')
   GaJRBIutYoAHPkxKphCnQUfOrvdWLm=GaJRBIutYoAHPkxKphCnQUfOrvdWLE.get('info')
   GaJRBIutYoAHPkxKphCnQUfOrvdWLm['plot']='%s\n\n%s'%(GaJRBIutYoAHPkxKphCnQUfOrvdWyi,GaJRBIutYoAHPkxKphCnQUfOrvdWLN)
   GaJRBIutYoAHPkxKphCnQUfOrvdWyl={'mode':'MOVIE','mediacode':GaJRBIutYoAHPkxKphCnQUfOrvdWLE.get('moviecode'),'stype':'movie','title':GaJRBIutYoAHPkxKphCnQUfOrvdWyi,'thumbnail':GaJRBIutYoAHPkxKphCnQUfOrvdWLM}
   GaJRBIutYoAHPkxKphCnQUfOrvdWcs.add_dir(GaJRBIutYoAHPkxKphCnQUfOrvdWyi,sublabel='',img=GaJRBIutYoAHPkxKphCnQUfOrvdWLM,infoLabels=GaJRBIutYoAHPkxKphCnQUfOrvdWLm,isFolder=GaJRBIutYoAHPkxKphCnQUfOrvdWwc,params=GaJRBIutYoAHPkxKphCnQUfOrvdWyl)
  if GaJRBIutYoAHPkxKphCnQUfOrvdWLi:
   GaJRBIutYoAHPkxKphCnQUfOrvdWyl['mode'] ='MOVIE_GROUP' 
   GaJRBIutYoAHPkxKphCnQUfOrvdWyl['orderby']=GaJRBIutYoAHPkxKphCnQUfOrvdWLD
   GaJRBIutYoAHPkxKphCnQUfOrvdWyl['page'] =GaJRBIutYoAHPkxKphCnQUfOrvdWwi(GaJRBIutYoAHPkxKphCnQUfOrvdWLq+1)
   GaJRBIutYoAHPkxKphCnQUfOrvdWyi='[B]%s >>[/B]'%'다음 페이지'
   GaJRBIutYoAHPkxKphCnQUfOrvdWLl=GaJRBIutYoAHPkxKphCnQUfOrvdWwi(GaJRBIutYoAHPkxKphCnQUfOrvdWLq+1)
   GaJRBIutYoAHPkxKphCnQUfOrvdWcs.add_dir(GaJRBIutYoAHPkxKphCnQUfOrvdWyi,sublabel=GaJRBIutYoAHPkxKphCnQUfOrvdWLl,img='',infoLabels=GaJRBIutYoAHPkxKphCnQUfOrvdWqE,isFolder=GaJRBIutYoAHPkxKphCnQUfOrvdWwy,params=GaJRBIutYoAHPkxKphCnQUfOrvdWyl)
  if GaJRBIutYoAHPkxKphCnQUfOrvdWwz(GaJRBIutYoAHPkxKphCnQUfOrvdWLF)>0:xbmcplugin.endOfDirectory(GaJRBIutYoAHPkxKphCnQUfOrvdWcs._addon_handle,cacheToDisc=GaJRBIutYoAHPkxKphCnQUfOrvdWwc)
 def dp_Search_Group(GaJRBIutYoAHPkxKphCnQUfOrvdWcs,GaJRBIutYoAHPkxKphCnQUfOrvdWLz):
  for GaJRBIutYoAHPkxKphCnQUfOrvdWLy in GaJRBIutYoAHPkxKphCnQUfOrvdWcw:
   GaJRBIutYoAHPkxKphCnQUfOrvdWyi=GaJRBIutYoAHPkxKphCnQUfOrvdWLy.get('title')
   GaJRBIutYoAHPkxKphCnQUfOrvdWyl={'mode':GaJRBIutYoAHPkxKphCnQUfOrvdWLy.get('mode'),'stype':GaJRBIutYoAHPkxKphCnQUfOrvdWLy.get('stype'),'page':'1'}
   GaJRBIutYoAHPkxKphCnQUfOrvdWcs.add_dir(GaJRBIutYoAHPkxKphCnQUfOrvdWyi,sublabel='',img='',infoLabels=GaJRBIutYoAHPkxKphCnQUfOrvdWqE,isFolder=GaJRBIutYoAHPkxKphCnQUfOrvdWwy,params=GaJRBIutYoAHPkxKphCnQUfOrvdWyl)
  if GaJRBIutYoAHPkxKphCnQUfOrvdWwz(GaJRBIutYoAHPkxKphCnQUfOrvdWcw)>0:xbmcplugin.endOfDirectory(GaJRBIutYoAHPkxKphCnQUfOrvdWcs._addon_handle)
 def dp_Search_List(GaJRBIutYoAHPkxKphCnQUfOrvdWcs,GaJRBIutYoAHPkxKphCnQUfOrvdWLz):
  GaJRBIutYoAHPkxKphCnQUfOrvdWcs.TvingObj.SaveCredential(GaJRBIutYoAHPkxKphCnQUfOrvdWcs.get_winCredential())
  GaJRBIutYoAHPkxKphCnQUfOrvdWzc =__addon__.getSetting('id')
  GaJRBIutYoAHPkxKphCnQUfOrvdWLq =GaJRBIutYoAHPkxKphCnQUfOrvdWwL(GaJRBIutYoAHPkxKphCnQUfOrvdWLz.get('page'))
  GaJRBIutYoAHPkxKphCnQUfOrvdWyE =GaJRBIutYoAHPkxKphCnQUfOrvdWLz.get('stype')
  if 'search_key' in GaJRBIutYoAHPkxKphCnQUfOrvdWLz:
   GaJRBIutYoAHPkxKphCnQUfOrvdWzy=GaJRBIutYoAHPkxKphCnQUfOrvdWLz.get('search_key')
  else:
   GaJRBIutYoAHPkxKphCnQUfOrvdWzy=GaJRBIutYoAHPkxKphCnQUfOrvdWcs.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not GaJRBIutYoAHPkxKphCnQUfOrvdWzy:return
  GaJRBIutYoAHPkxKphCnQUfOrvdWzL,GaJRBIutYoAHPkxKphCnQUfOrvdWLi=GaJRBIutYoAHPkxKphCnQUfOrvdWcs.TvingObj.GetSearchList(GaJRBIutYoAHPkxKphCnQUfOrvdWzy,GaJRBIutYoAHPkxKphCnQUfOrvdWzc,GaJRBIutYoAHPkxKphCnQUfOrvdWLq,GaJRBIutYoAHPkxKphCnQUfOrvdWyE,premiumyn=GaJRBIutYoAHPkxKphCnQUfOrvdWcs.get_settings_premiumyn(),landyn=GaJRBIutYoAHPkxKphCnQUfOrvdWcs.get_settings_thumbnail_landyn())
  if GaJRBIutYoAHPkxKphCnQUfOrvdWwz(GaJRBIutYoAHPkxKphCnQUfOrvdWzL)==0:return
  for GaJRBIutYoAHPkxKphCnQUfOrvdWzq in GaJRBIutYoAHPkxKphCnQUfOrvdWzL:
   GaJRBIutYoAHPkxKphCnQUfOrvdWyi =GaJRBIutYoAHPkxKphCnQUfOrvdWzq.get('title')
   GaJRBIutYoAHPkxKphCnQUfOrvdWLM=GaJRBIutYoAHPkxKphCnQUfOrvdWzq.get('thumbnail')
   GaJRBIutYoAHPkxKphCnQUfOrvdWLN =GaJRBIutYoAHPkxKphCnQUfOrvdWzq.get('synopsis')
   GaJRBIutYoAHPkxKphCnQUfOrvdWzw =GaJRBIutYoAHPkxKphCnQUfOrvdWzq.get('program')
   GaJRBIutYoAHPkxKphCnQUfOrvdWLm=GaJRBIutYoAHPkxKphCnQUfOrvdWzq.get('info')
   GaJRBIutYoAHPkxKphCnQUfOrvdWLm['plot']='%s\n\n%s'%(GaJRBIutYoAHPkxKphCnQUfOrvdWyi,GaJRBIutYoAHPkxKphCnQUfOrvdWLN)
   if GaJRBIutYoAHPkxKphCnQUfOrvdWyE=='vod':
    GaJRBIutYoAHPkxKphCnQUfOrvdWyl={'mode':'EPISODE','programcode':GaJRBIutYoAHPkxKphCnQUfOrvdWzq.get('program'),'page':'1'}
    GaJRBIutYoAHPkxKphCnQUfOrvdWyD=GaJRBIutYoAHPkxKphCnQUfOrvdWwy
   else:
    GaJRBIutYoAHPkxKphCnQUfOrvdWyl={'mode':'MOVIE','mediacode':GaJRBIutYoAHPkxKphCnQUfOrvdWzq.get('movie'),'stype':'movie','title':GaJRBIutYoAHPkxKphCnQUfOrvdWyi,'thumbnail':GaJRBIutYoAHPkxKphCnQUfOrvdWLM}
    GaJRBIutYoAHPkxKphCnQUfOrvdWyD=GaJRBIutYoAHPkxKphCnQUfOrvdWwc
   GaJRBIutYoAHPkxKphCnQUfOrvdWcs.add_dir(GaJRBIutYoAHPkxKphCnQUfOrvdWyi,sublabel='',img=GaJRBIutYoAHPkxKphCnQUfOrvdWLM,infoLabels=GaJRBIutYoAHPkxKphCnQUfOrvdWLm,isFolder=GaJRBIutYoAHPkxKphCnQUfOrvdWyD,params=GaJRBIutYoAHPkxKphCnQUfOrvdWyl)
  if GaJRBIutYoAHPkxKphCnQUfOrvdWLi:
   GaJRBIutYoAHPkxKphCnQUfOrvdWyl['mode'] ='SEARCH' 
   GaJRBIutYoAHPkxKphCnQUfOrvdWyl['search_key']=GaJRBIutYoAHPkxKphCnQUfOrvdWzy
   GaJRBIutYoAHPkxKphCnQUfOrvdWyl['page'] =GaJRBIutYoAHPkxKphCnQUfOrvdWwi(GaJRBIutYoAHPkxKphCnQUfOrvdWLq+1)
   GaJRBIutYoAHPkxKphCnQUfOrvdWyi='[B]%s >>[/B]'%'다음 페이지'
   GaJRBIutYoAHPkxKphCnQUfOrvdWLl=GaJRBIutYoAHPkxKphCnQUfOrvdWwi(GaJRBIutYoAHPkxKphCnQUfOrvdWLq+1)
   GaJRBIutYoAHPkxKphCnQUfOrvdWcs.add_dir(GaJRBIutYoAHPkxKphCnQUfOrvdWyi,sublabel=GaJRBIutYoAHPkxKphCnQUfOrvdWLl,img='',infoLabels=GaJRBIutYoAHPkxKphCnQUfOrvdWqE,isFolder=GaJRBIutYoAHPkxKphCnQUfOrvdWwy,params=GaJRBIutYoAHPkxKphCnQUfOrvdWyl)
  if GaJRBIutYoAHPkxKphCnQUfOrvdWwz(GaJRBIutYoAHPkxKphCnQUfOrvdWzL)>0:xbmcplugin.endOfDirectory(GaJRBIutYoAHPkxKphCnQUfOrvdWcs._addon_handle)
 def Delete_Watched_List(GaJRBIutYoAHPkxKphCnQUfOrvdWcs,GaJRBIutYoAHPkxKphCnQUfOrvdWyE):
  try:
   GaJRBIutYoAHPkxKphCnQUfOrvdWzi=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%GaJRBIutYoAHPkxKphCnQUfOrvdWyE))
   with GaJRBIutYoAHPkxKphCnQUfOrvdWwe(GaJRBIutYoAHPkxKphCnQUfOrvdWzi,'w',-1,'utf-8')as fp:
    fp.write('')
  except:
   GaJRBIutYoAHPkxKphCnQUfOrvdWqE
 def dp_WatchList_Delete(GaJRBIutYoAHPkxKphCnQUfOrvdWcs,GaJRBIutYoAHPkxKphCnQUfOrvdWLz):
  GaJRBIutYoAHPkxKphCnQUfOrvdWyE=GaJRBIutYoAHPkxKphCnQUfOrvdWLz.get('stype')
  GaJRBIutYoAHPkxKphCnQUfOrvdWcg=xbmcgui.Dialog()
  GaJRBIutYoAHPkxKphCnQUfOrvdWyT=GaJRBIutYoAHPkxKphCnQUfOrvdWcg.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if GaJRBIutYoAHPkxKphCnQUfOrvdWyT==GaJRBIutYoAHPkxKphCnQUfOrvdWwc:sys.exit()
  GaJRBIutYoAHPkxKphCnQUfOrvdWcs.Delete_Watched_List(GaJRBIutYoAHPkxKphCnQUfOrvdWyE)
  xbmc.executebuiltin("Container.Refresh")
 def Load_Watched_List(GaJRBIutYoAHPkxKphCnQUfOrvdWcs,GaJRBIutYoAHPkxKphCnQUfOrvdWyE):
  try:
   GaJRBIutYoAHPkxKphCnQUfOrvdWzi=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%GaJRBIutYoAHPkxKphCnQUfOrvdWyE))
   with GaJRBIutYoAHPkxKphCnQUfOrvdWwe(GaJRBIutYoAHPkxKphCnQUfOrvdWzi,'r',-1,'utf-8')as fp:
    GaJRBIutYoAHPkxKphCnQUfOrvdWze=fp.readlines()
  except:
   GaJRBIutYoAHPkxKphCnQUfOrvdWze=[]
  return GaJRBIutYoAHPkxKphCnQUfOrvdWze
 def Save_Watched_List(GaJRBIutYoAHPkxKphCnQUfOrvdWcs,GaJRBIutYoAHPkxKphCnQUfOrvdWyE,GaJRBIutYoAHPkxKphCnQUfOrvdWcD):
  try:
   GaJRBIutYoAHPkxKphCnQUfOrvdWzi=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%GaJRBIutYoAHPkxKphCnQUfOrvdWyE))
   GaJRBIutYoAHPkxKphCnQUfOrvdWzM=GaJRBIutYoAHPkxKphCnQUfOrvdWcs.Load_Watched_List(GaJRBIutYoAHPkxKphCnQUfOrvdWyE) 
   with GaJRBIutYoAHPkxKphCnQUfOrvdWwe(GaJRBIutYoAHPkxKphCnQUfOrvdWzi,'w',-1,'utf-8')as fp:
    GaJRBIutYoAHPkxKphCnQUfOrvdWzN=urllib.parse.urlencode(GaJRBIutYoAHPkxKphCnQUfOrvdWcD)
    GaJRBIutYoAHPkxKphCnQUfOrvdWzN=GaJRBIutYoAHPkxKphCnQUfOrvdWzN+'\n'
    fp.write(GaJRBIutYoAHPkxKphCnQUfOrvdWzN)
    GaJRBIutYoAHPkxKphCnQUfOrvdWzs=0
    for GaJRBIutYoAHPkxKphCnQUfOrvdWzm in GaJRBIutYoAHPkxKphCnQUfOrvdWzM:
     GaJRBIutYoAHPkxKphCnQUfOrvdWzl=GaJRBIutYoAHPkxKphCnQUfOrvdWwM(urllib.parse.parse_qsl(GaJRBIutYoAHPkxKphCnQUfOrvdWzm))
     GaJRBIutYoAHPkxKphCnQUfOrvdWzD=GaJRBIutYoAHPkxKphCnQUfOrvdWcD.get('code')
     GaJRBIutYoAHPkxKphCnQUfOrvdWzj=GaJRBIutYoAHPkxKphCnQUfOrvdWzl.get('code')
     if GaJRBIutYoAHPkxKphCnQUfOrvdWyE=='vod' and GaJRBIutYoAHPkxKphCnQUfOrvdWcs.get_settings_direct_replay()==GaJRBIutYoAHPkxKphCnQUfOrvdWwy:
      GaJRBIutYoAHPkxKphCnQUfOrvdWzD=GaJRBIutYoAHPkxKphCnQUfOrvdWcD.get('videoid')
      GaJRBIutYoAHPkxKphCnQUfOrvdWzj=GaJRBIutYoAHPkxKphCnQUfOrvdWzl.get('videoid')if GaJRBIutYoAHPkxKphCnQUfOrvdWzj!=GaJRBIutYoAHPkxKphCnQUfOrvdWqE else '-'
     if GaJRBIutYoAHPkxKphCnQUfOrvdWzD!=GaJRBIutYoAHPkxKphCnQUfOrvdWzj:
      fp.write(GaJRBIutYoAHPkxKphCnQUfOrvdWzm)
      GaJRBIutYoAHPkxKphCnQUfOrvdWzs+=1
      if GaJRBIutYoAHPkxKphCnQUfOrvdWzs>=50:break
  except:
   GaJRBIutYoAHPkxKphCnQUfOrvdWqE
 def dp_Watch_List(GaJRBIutYoAHPkxKphCnQUfOrvdWcs,GaJRBIutYoAHPkxKphCnQUfOrvdWLz):
  GaJRBIutYoAHPkxKphCnQUfOrvdWyE =GaJRBIutYoAHPkxKphCnQUfOrvdWLz.get('stype')
  GaJRBIutYoAHPkxKphCnQUfOrvdWyc=GaJRBIutYoAHPkxKphCnQUfOrvdWcs.get_settings_direct_replay()
  if GaJRBIutYoAHPkxKphCnQUfOrvdWyE=='-':
   for GaJRBIutYoAHPkxKphCnQUfOrvdWLy in GaJRBIutYoAHPkxKphCnQUfOrvdWcq:
    GaJRBIutYoAHPkxKphCnQUfOrvdWyi=GaJRBIutYoAHPkxKphCnQUfOrvdWLy.get('title')
    GaJRBIutYoAHPkxKphCnQUfOrvdWyl={'mode':GaJRBIutYoAHPkxKphCnQUfOrvdWLy.get('mode'),'stype':GaJRBIutYoAHPkxKphCnQUfOrvdWLy.get('stype')}
    GaJRBIutYoAHPkxKphCnQUfOrvdWcs.add_dir(GaJRBIutYoAHPkxKphCnQUfOrvdWyi,sublabel='',img='',infoLabels=GaJRBIutYoAHPkxKphCnQUfOrvdWqE,isFolder=GaJRBIutYoAHPkxKphCnQUfOrvdWwy,params=GaJRBIutYoAHPkxKphCnQUfOrvdWyl)
   if GaJRBIutYoAHPkxKphCnQUfOrvdWwz(GaJRBIutYoAHPkxKphCnQUfOrvdWcq)>0:xbmcplugin.endOfDirectory(GaJRBIutYoAHPkxKphCnQUfOrvdWcs._addon_handle)
  else:
   GaJRBIutYoAHPkxKphCnQUfOrvdWzg=GaJRBIutYoAHPkxKphCnQUfOrvdWcs.Load_Watched_List(GaJRBIutYoAHPkxKphCnQUfOrvdWyE)
   for GaJRBIutYoAHPkxKphCnQUfOrvdWzX in GaJRBIutYoAHPkxKphCnQUfOrvdWzg:
    GaJRBIutYoAHPkxKphCnQUfOrvdWzV=GaJRBIutYoAHPkxKphCnQUfOrvdWwM(urllib.parse.parse_qsl(GaJRBIutYoAHPkxKphCnQUfOrvdWzX))
    GaJRBIutYoAHPkxKphCnQUfOrvdWyi =GaJRBIutYoAHPkxKphCnQUfOrvdWzV.get('title')
    GaJRBIutYoAHPkxKphCnQUfOrvdWLM=GaJRBIutYoAHPkxKphCnQUfOrvdWzV.get('img')
    GaJRBIutYoAHPkxKphCnQUfOrvdWzT =GaJRBIutYoAHPkxKphCnQUfOrvdWzV.get('videoid')
    GaJRBIutYoAHPkxKphCnQUfOrvdWLm={}
    GaJRBIutYoAHPkxKphCnQUfOrvdWLm['plot']=GaJRBIutYoAHPkxKphCnQUfOrvdWyi
    if GaJRBIutYoAHPkxKphCnQUfOrvdWyE=='vod':
     if GaJRBIutYoAHPkxKphCnQUfOrvdWyc==GaJRBIutYoAHPkxKphCnQUfOrvdWwc or GaJRBIutYoAHPkxKphCnQUfOrvdWzT==GaJRBIutYoAHPkxKphCnQUfOrvdWqE:
      GaJRBIutYoAHPkxKphCnQUfOrvdWyl={'mode':'EPISODE','programcode':GaJRBIutYoAHPkxKphCnQUfOrvdWzV.get('code'),'page':'1'}
      GaJRBIutYoAHPkxKphCnQUfOrvdWyD=GaJRBIutYoAHPkxKphCnQUfOrvdWwy
     else:
      GaJRBIutYoAHPkxKphCnQUfOrvdWyl={'mode':'VOD','mediacode':GaJRBIutYoAHPkxKphCnQUfOrvdWzT,'stype':'vod','programcode':GaJRBIutYoAHPkxKphCnQUfOrvdWzV.get('code'),'title':GaJRBIutYoAHPkxKphCnQUfOrvdWyi,'thumbnail':GaJRBIutYoAHPkxKphCnQUfOrvdWLM}
      GaJRBIutYoAHPkxKphCnQUfOrvdWyD=GaJRBIutYoAHPkxKphCnQUfOrvdWwc
    else:
     GaJRBIutYoAHPkxKphCnQUfOrvdWyl={'mode':'MOVIE','mediacode':GaJRBIutYoAHPkxKphCnQUfOrvdWzV.get('code'),'stype':'movie','title':GaJRBIutYoAHPkxKphCnQUfOrvdWyi,'thumbnail':GaJRBIutYoAHPkxKphCnQUfOrvdWLM}
     GaJRBIutYoAHPkxKphCnQUfOrvdWyD=GaJRBIutYoAHPkxKphCnQUfOrvdWwc
    GaJRBIutYoAHPkxKphCnQUfOrvdWcs.add_dir(GaJRBIutYoAHPkxKphCnQUfOrvdWyi,sublabel='',img=GaJRBIutYoAHPkxKphCnQUfOrvdWLM,infoLabels=GaJRBIutYoAHPkxKphCnQUfOrvdWLm,isFolder=GaJRBIutYoAHPkxKphCnQUfOrvdWyD,params=GaJRBIutYoAHPkxKphCnQUfOrvdWyl)
   GaJRBIutYoAHPkxKphCnQUfOrvdWLm={'plot':'시청목록을 삭제합니다.'}
   GaJRBIutYoAHPkxKphCnQUfOrvdWyi='*** 시청목록 삭제 ***'
   GaJRBIutYoAHPkxKphCnQUfOrvdWyl={'mode':'MYVIEW_REMOVE','stype':GaJRBIutYoAHPkxKphCnQUfOrvdWyE}
   GaJRBIutYoAHPkxKphCnQUfOrvdWcs.add_dir(GaJRBIutYoAHPkxKphCnQUfOrvdWyi,sublabel='',img='',infoLabels=GaJRBIutYoAHPkxKphCnQUfOrvdWLm,isFolder=GaJRBIutYoAHPkxKphCnQUfOrvdWwc,params=GaJRBIutYoAHPkxKphCnQUfOrvdWyl)
   xbmcplugin.endOfDirectory(GaJRBIutYoAHPkxKphCnQUfOrvdWcs._addon_handle,cacheToDisc=GaJRBIutYoAHPkxKphCnQUfOrvdWwc)
 def play_VIDEO(GaJRBIutYoAHPkxKphCnQUfOrvdWcs,GaJRBIutYoAHPkxKphCnQUfOrvdWLz):
  GaJRBIutYoAHPkxKphCnQUfOrvdWcs.TvingObj.SaveCredential(GaJRBIutYoAHPkxKphCnQUfOrvdWcs.get_winCredential())
  GaJRBIutYoAHPkxKphCnQUfOrvdWzS =GaJRBIutYoAHPkxKphCnQUfOrvdWLz.get('mediacode')
  GaJRBIutYoAHPkxKphCnQUfOrvdWyE =GaJRBIutYoAHPkxKphCnQUfOrvdWLz.get('stype')
  GaJRBIutYoAHPkxKphCnQUfOrvdWzF=GaJRBIutYoAHPkxKphCnQUfOrvdWcs.get_selQuality(GaJRBIutYoAHPkxKphCnQUfOrvdWyE)
  GaJRBIutYoAHPkxKphCnQUfOrvdWzE,GaJRBIutYoAHPkxKphCnQUfOrvdWqc=GaJRBIutYoAHPkxKphCnQUfOrvdWcs.TvingObj.GetBroadURL(GaJRBIutYoAHPkxKphCnQUfOrvdWzS,GaJRBIutYoAHPkxKphCnQUfOrvdWzF,GaJRBIutYoAHPkxKphCnQUfOrvdWyE)
  GaJRBIutYoAHPkxKphCnQUfOrvdWcs.addon_log('qt, stype, url : %s - %s - %s'%(GaJRBIutYoAHPkxKphCnQUfOrvdWwi(GaJRBIutYoAHPkxKphCnQUfOrvdWzF),GaJRBIutYoAHPkxKphCnQUfOrvdWyE,GaJRBIutYoAHPkxKphCnQUfOrvdWzE))
  if GaJRBIutYoAHPkxKphCnQUfOrvdWzE=='':
   GaJRBIutYoAHPkxKphCnQUfOrvdWcs.addon_noti(__language__(30908).encode('utf8'))
   return
  GaJRBIutYoAHPkxKphCnQUfOrvdWqy =GaJRBIutYoAHPkxKphCnQUfOrvdWzE.find('Policy=')
  if GaJRBIutYoAHPkxKphCnQUfOrvdWqy!=-1:
   GaJRBIutYoAHPkxKphCnQUfOrvdWqL =GaJRBIutYoAHPkxKphCnQUfOrvdWzE.split('?')[0]
   GaJRBIutYoAHPkxKphCnQUfOrvdWqz=GaJRBIutYoAHPkxKphCnQUfOrvdWwM(urllib.parse.parse_qsl(urllib.parse.urlsplit(GaJRBIutYoAHPkxKphCnQUfOrvdWzE).query))
   GaJRBIutYoAHPkxKphCnQUfOrvdWqz=urllib.parse.urlencode(GaJRBIutYoAHPkxKphCnQUfOrvdWqz)
   GaJRBIutYoAHPkxKphCnQUfOrvdWqz=GaJRBIutYoAHPkxKphCnQUfOrvdWqz.replace('&',';')
   GaJRBIutYoAHPkxKphCnQUfOrvdWqz=GaJRBIutYoAHPkxKphCnQUfOrvdWqz.replace('Policy','CloudFront-Policy')
   GaJRBIutYoAHPkxKphCnQUfOrvdWqz=GaJRBIutYoAHPkxKphCnQUfOrvdWqz.replace('Signature','CloudFront-Signature')
   GaJRBIutYoAHPkxKphCnQUfOrvdWqz=GaJRBIutYoAHPkxKphCnQUfOrvdWqz.replace('Key-Pair-Id','CloudFront-Key-Pair-Id')
   GaJRBIutYoAHPkxKphCnQUfOrvdWqw='%s|Cookie=%s'%(GaJRBIutYoAHPkxKphCnQUfOrvdWqL,GaJRBIutYoAHPkxKphCnQUfOrvdWqz)
  else:
   GaJRBIutYoAHPkxKphCnQUfOrvdWqw=GaJRBIutYoAHPkxKphCnQUfOrvdWzE
  GaJRBIutYoAHPkxKphCnQUfOrvdWcs.addon_log(GaJRBIutYoAHPkxKphCnQUfOrvdWqw,GaJRBIutYoAHPkxKphCnQUfOrvdWwc)
  GaJRBIutYoAHPkxKphCnQUfOrvdWqi=xbmcgui.ListItem(path=GaJRBIutYoAHPkxKphCnQUfOrvdWqw)
  if GaJRBIutYoAHPkxKphCnQUfOrvdWqc!='':
   GaJRBIutYoAHPkxKphCnQUfOrvdWqe=GaJRBIutYoAHPkxKphCnQUfOrvdWqc
   GaJRBIutYoAHPkxKphCnQUfOrvdWqM ='https://cj.drmkeyserver.com/widevine_license'
   GaJRBIutYoAHPkxKphCnQUfOrvdWqN ='mpd'
   GaJRBIutYoAHPkxKphCnQUfOrvdWqs ='com.widevine.alpha'
   GaJRBIutYoAHPkxKphCnQUfOrvdWqm =inputstreamhelper.Helper(GaJRBIutYoAHPkxKphCnQUfOrvdWqN,drm='widevine')
   if GaJRBIutYoAHPkxKphCnQUfOrvdWqm.check_inputstream():
    GaJRBIutYoAHPkxKphCnQUfOrvdWql={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/live/player/%s'%GaJRBIutYoAHPkxKphCnQUfOrvdWzS,'sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':GaJRBIutYoAHPkxKphCnQUfOrvdWcM,'AcquireLicenseAssertion':GaJRBIutYoAHPkxKphCnQUfOrvdWqe,'Host':'cj.drmkeyserver.com'}
    GaJRBIutYoAHPkxKphCnQUfOrvdWqD=GaJRBIutYoAHPkxKphCnQUfOrvdWqM+'|'+urllib.parse.urlencode(GaJRBIutYoAHPkxKphCnQUfOrvdWql)+'|R{SSM}|'
    GaJRBIutYoAHPkxKphCnQUfOrvdWqi.setProperty('inputstream',GaJRBIutYoAHPkxKphCnQUfOrvdWqm.inputstream_addon)
    GaJRBIutYoAHPkxKphCnQUfOrvdWqi.setProperty('inputstream.adaptive.manifest_type',GaJRBIutYoAHPkxKphCnQUfOrvdWqN)
    GaJRBIutYoAHPkxKphCnQUfOrvdWqi.setProperty('inputstream.adaptive.license_type',GaJRBIutYoAHPkxKphCnQUfOrvdWqs)
    GaJRBIutYoAHPkxKphCnQUfOrvdWqi.setProperty('inputstream.adaptive.license_key',GaJRBIutYoAHPkxKphCnQUfOrvdWqD)
    GaJRBIutYoAHPkxKphCnQUfOrvdWqi.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(GaJRBIutYoAHPkxKphCnQUfOrvdWcM))
  xbmcplugin.setResolvedUrl(GaJRBIutYoAHPkxKphCnQUfOrvdWcs._addon_handle,GaJRBIutYoAHPkxKphCnQUfOrvdWwy,GaJRBIutYoAHPkxKphCnQUfOrvdWqi)
  try:
   if GaJRBIutYoAHPkxKphCnQUfOrvdWLz.get('mode')in['VOD','MOVIE']and GaJRBIutYoAHPkxKphCnQUfOrvdWLz.get('title'):
    GaJRBIutYoAHPkxKphCnQUfOrvdWyl={'code':GaJRBIutYoAHPkxKphCnQUfOrvdWLz.get('programcode')if GaJRBIutYoAHPkxKphCnQUfOrvdWLz.get('mode')=='VOD' else GaJRBIutYoAHPkxKphCnQUfOrvdWLz.get('mediacode'),'img':GaJRBIutYoAHPkxKphCnQUfOrvdWLz.get('thumbnail'),'title':GaJRBIutYoAHPkxKphCnQUfOrvdWLz.get('title'),'videoid':GaJRBIutYoAHPkxKphCnQUfOrvdWLz.get('mediacode')}
    GaJRBIutYoAHPkxKphCnQUfOrvdWcs.Save_Watched_List(GaJRBIutYoAHPkxKphCnQUfOrvdWLz.get('stype'),GaJRBIutYoAHPkxKphCnQUfOrvdWyl)
  except:
   GaJRBIutYoAHPkxKphCnQUfOrvdWqE
 def logout(GaJRBIutYoAHPkxKphCnQUfOrvdWcs):
  GaJRBIutYoAHPkxKphCnQUfOrvdWcg=xbmcgui.Dialog()
  GaJRBIutYoAHPkxKphCnQUfOrvdWyT=GaJRBIutYoAHPkxKphCnQUfOrvdWcg.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if GaJRBIutYoAHPkxKphCnQUfOrvdWyT==GaJRBIutYoAHPkxKphCnQUfOrvdWwc:sys.exit()
  GaJRBIutYoAHPkxKphCnQUfOrvdWcs.wininfo_clear()
  if os.path.isfile(GaJRBIutYoAHPkxKphCnQUfOrvdWcN):os.remove(GaJRBIutYoAHPkxKphCnQUfOrvdWcN)
  GaJRBIutYoAHPkxKphCnQUfOrvdWcs.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(GaJRBIutYoAHPkxKphCnQUfOrvdWcs):
  GaJRBIutYoAHPkxKphCnQUfOrvdWyz=xbmcgui.Window(10000)
  GaJRBIutYoAHPkxKphCnQUfOrvdWyz.setProperty('TVING_M_TOKEN','')
  GaJRBIutYoAHPkxKphCnQUfOrvdWyz.setProperty('TVING_M_USERINFO','')
  GaJRBIutYoAHPkxKphCnQUfOrvdWyz.setProperty('TVING_M_UUID','')
  GaJRBIutYoAHPkxKphCnQUfOrvdWyz.setProperty('TVING_M_LOGINTIME','')
 def cookiefile_save(GaJRBIutYoAHPkxKphCnQUfOrvdWcs):
  GaJRBIutYoAHPkxKphCnQUfOrvdWqj =datetime.datetime.now()
  GaJRBIutYoAHPkxKphCnQUfOrvdWqg=GaJRBIutYoAHPkxKphCnQUfOrvdWqj+datetime.timedelta(days=GaJRBIutYoAHPkxKphCnQUfOrvdWwL(__addon__.getSetting('cache_ttl')))
  GaJRBIutYoAHPkxKphCnQUfOrvdWyz=xbmcgui.Window(10000)
  GaJRBIutYoAHPkxKphCnQUfOrvdWqX={'tving_token':GaJRBIutYoAHPkxKphCnQUfOrvdWyz.getProperty('TVING_M_TOKEN'),'tving_userinfo':GaJRBIutYoAHPkxKphCnQUfOrvdWyz.getProperty('TVING_M_USERINFO'),'tving_uuid':GaJRBIutYoAHPkxKphCnQUfOrvdWyz.getProperty('TVING_M_UUID'),'tving_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'tving_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'tving_logintype':__addon__.getSetting('login_type'),'tving_limitdate':GaJRBIutYoAHPkxKphCnQUfOrvdWqg.strftime('%Y-%m-%d')}
  try: 
   with GaJRBIutYoAHPkxKphCnQUfOrvdWwe(GaJRBIutYoAHPkxKphCnQUfOrvdWcN,'w',-1,'utf-8')as fp:
    GaJRBIutYoAHPkxKphCnQUfOrvdWqV.dump(GaJRBIutYoAHPkxKphCnQUfOrvdWqX,fp)
  except GaJRBIutYoAHPkxKphCnQUfOrvdWwN as exception:
   GaJRBIutYoAHPkxKphCnQUfOrvdWws(exception)
 def cookiefile_check(GaJRBIutYoAHPkxKphCnQUfOrvdWcs):
  GaJRBIutYoAHPkxKphCnQUfOrvdWqX={}
  try: 
   with GaJRBIutYoAHPkxKphCnQUfOrvdWwe(GaJRBIutYoAHPkxKphCnQUfOrvdWcN,'r',-1,'utf-8')as fp:
    GaJRBIutYoAHPkxKphCnQUfOrvdWqX= GaJRBIutYoAHPkxKphCnQUfOrvdWqV.load(fp)
  except GaJRBIutYoAHPkxKphCnQUfOrvdWwN as exception:
   GaJRBIutYoAHPkxKphCnQUfOrvdWcs.wininfo_clear()
   return GaJRBIutYoAHPkxKphCnQUfOrvdWwc
  GaJRBIutYoAHPkxKphCnQUfOrvdWyg =__addon__.getSetting('id')
  GaJRBIutYoAHPkxKphCnQUfOrvdWyX =__addon__.getSetting('pw')
  GaJRBIutYoAHPkxKphCnQUfOrvdWqT=__addon__.getSetting('login_type')
  GaJRBIutYoAHPkxKphCnQUfOrvdWqX['tving_id']=base64.standard_b64decode(GaJRBIutYoAHPkxKphCnQUfOrvdWqX['tving_id']).decode('utf-8')
  GaJRBIutYoAHPkxKphCnQUfOrvdWqX['tving_pw']=base64.standard_b64decode(GaJRBIutYoAHPkxKphCnQUfOrvdWqX['tving_pw']).decode('utf-8')
  if GaJRBIutYoAHPkxKphCnQUfOrvdWyg!=GaJRBIutYoAHPkxKphCnQUfOrvdWqX['tving_id']or GaJRBIutYoAHPkxKphCnQUfOrvdWyX!=GaJRBIutYoAHPkxKphCnQUfOrvdWqX['tving_pw']or GaJRBIutYoAHPkxKphCnQUfOrvdWqT!=GaJRBIutYoAHPkxKphCnQUfOrvdWqX['tving_logintype']:
   GaJRBIutYoAHPkxKphCnQUfOrvdWcs.wininfo_clear()
   return GaJRBIutYoAHPkxKphCnQUfOrvdWwc
  GaJRBIutYoAHPkxKphCnQUfOrvdWyb =datetime.datetime.now().date()
  GaJRBIutYoAHPkxKphCnQUfOrvdWqb =GaJRBIutYoAHPkxKphCnQUfOrvdWqX['tving_limitdate']
  try:
   GaJRBIutYoAHPkxKphCnQUfOrvdWyS=datetime.datetime.strptime(GaJRBIutYoAHPkxKphCnQUfOrvdWqb,'%Y-%m-%d').date()
  except GaJRBIutYoAHPkxKphCnQUfOrvdWwq:
   GaJRBIutYoAHPkxKphCnQUfOrvdWyS=datetime.datetime(*(time.strptime(GaJRBIutYoAHPkxKphCnQUfOrvdWqb,'%Y-%m-%d')[0:6])).date()
  if GaJRBIutYoAHPkxKphCnQUfOrvdWyS<GaJRBIutYoAHPkxKphCnQUfOrvdWyb:
   GaJRBIutYoAHPkxKphCnQUfOrvdWcs.wininfo_clear()
   return GaJRBIutYoAHPkxKphCnQUfOrvdWwc
  GaJRBIutYoAHPkxKphCnQUfOrvdWyz=xbmcgui.Window(10000)
  GaJRBIutYoAHPkxKphCnQUfOrvdWyz.setProperty('TVING_M_TOKEN',GaJRBIutYoAHPkxKphCnQUfOrvdWqX['tving_token'])
  GaJRBIutYoAHPkxKphCnQUfOrvdWyz.setProperty('TVING_M_USERINFO',GaJRBIutYoAHPkxKphCnQUfOrvdWqX['tving_userinfo'])
  GaJRBIutYoAHPkxKphCnQUfOrvdWyz.setProperty('TVING_M_UUID',GaJRBIutYoAHPkxKphCnQUfOrvdWqX['tving_uuid'])
  GaJRBIutYoAHPkxKphCnQUfOrvdWyz.setProperty('TVING_M_LOGINTIME',GaJRBIutYoAHPkxKphCnQUfOrvdWqb)
  return GaJRBIutYoAHPkxKphCnQUfOrvdWwy
 def tving_main(GaJRBIutYoAHPkxKphCnQUfOrvdWcs):
  GaJRBIutYoAHPkxKphCnQUfOrvdWqS=GaJRBIutYoAHPkxKphCnQUfOrvdWcs.main_params.get('mode',GaJRBIutYoAHPkxKphCnQUfOrvdWqE)
  GaJRBIutYoAHPkxKphCnQUfOrvdWcs.login_main()
  if GaJRBIutYoAHPkxKphCnQUfOrvdWqS is GaJRBIutYoAHPkxKphCnQUfOrvdWqE:
   GaJRBIutYoAHPkxKphCnQUfOrvdWcs.dp_Main_List()
  elif GaJRBIutYoAHPkxKphCnQUfOrvdWqS in['LIVE_GROUP','VOD_GROUP']:
   GaJRBIutYoAHPkxKphCnQUfOrvdWcs.dp_Title_Group(GaJRBIutYoAHPkxKphCnQUfOrvdWcs.main_params)
  elif GaJRBIutYoAHPkxKphCnQUfOrvdWqS=='CHANNEL':
   GaJRBIutYoAHPkxKphCnQUfOrvdWcs.dp_LiveChannel_List(GaJRBIutYoAHPkxKphCnQUfOrvdWcs.main_params)
  elif GaJRBIutYoAHPkxKphCnQUfOrvdWqS in['LIVE','VOD','MOVIE']:
   GaJRBIutYoAHPkxKphCnQUfOrvdWcs.play_VIDEO(GaJRBIutYoAHPkxKphCnQUfOrvdWcs.main_params)
   time.sleep(0.1)
  elif GaJRBIutYoAHPkxKphCnQUfOrvdWqS=='PROGRAM':
   GaJRBIutYoAHPkxKphCnQUfOrvdWcs.dp_Program_List(GaJRBIutYoAHPkxKphCnQUfOrvdWcs.main_params)
  elif GaJRBIutYoAHPkxKphCnQUfOrvdWqS=='EPISODE':
   GaJRBIutYoAHPkxKphCnQUfOrvdWcs.dp_Episode_List(GaJRBIutYoAHPkxKphCnQUfOrvdWcs.main_params)
  elif GaJRBIutYoAHPkxKphCnQUfOrvdWqS=='MOVIE_GROUP':
   GaJRBIutYoAHPkxKphCnQUfOrvdWcs.dp_Movie_List(GaJRBIutYoAHPkxKphCnQUfOrvdWcs.main_params)
  elif GaJRBIutYoAHPkxKphCnQUfOrvdWqS=='SEARCH_GROUP':
   GaJRBIutYoAHPkxKphCnQUfOrvdWcs.dp_Search_Group(GaJRBIutYoAHPkxKphCnQUfOrvdWcs.main_params)
  elif GaJRBIutYoAHPkxKphCnQUfOrvdWqS=='SEARCH':
   GaJRBIutYoAHPkxKphCnQUfOrvdWcs.dp_Search_List(GaJRBIutYoAHPkxKphCnQUfOrvdWcs.main_params)
  elif GaJRBIutYoAHPkxKphCnQUfOrvdWqS=='WATCH':
   GaJRBIutYoAHPkxKphCnQUfOrvdWcs.dp_Watch_List(GaJRBIutYoAHPkxKphCnQUfOrvdWcs.main_params)
  elif GaJRBIutYoAHPkxKphCnQUfOrvdWqS=='MYVIEW_REMOVE':
   GaJRBIutYoAHPkxKphCnQUfOrvdWcs.dp_WatchList_Delete(GaJRBIutYoAHPkxKphCnQUfOrvdWcs.main_params)
  elif GaJRBIutYoAHPkxKphCnQUfOrvdWqS=='ORDER_BY':
   GaJRBIutYoAHPkxKphCnQUfOrvdWcs.dp_setEpOrderby(GaJRBIutYoAHPkxKphCnQUfOrvdWcs.main_params)
  elif GaJRBIutYoAHPkxKphCnQUfOrvdWqS=='LOGOUT':
   GaJRBIutYoAHPkxKphCnQUfOrvdWcs.logout()
  else:
   GaJRBIutYoAHPkxKphCnQUfOrvdWqE
# Created by pyminifier (https://github.com/liftoff/pyminifier)
