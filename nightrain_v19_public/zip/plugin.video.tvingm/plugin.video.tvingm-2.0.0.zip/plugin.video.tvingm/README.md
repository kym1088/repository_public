# tvingM-v19
 티빙 애드온 for Kodi19

- DRM 실시간 채널(ocn, super action 등)이 설정한 화질보다 낮게 재생될때
  InputStream Adaptive 애드온 설정에서
  Ignore Display Resolution 활성화
  또는 스트림수동 선택후 재생화면 옵션에서 수동변경해볼것
- (필수) Tving 홈페이지 기기등록 화면에서 PC로 등록된 기기 필요 (1회)



## Version 2.0.0 (2020.10.01)
- python3(kodi 19) 전환
