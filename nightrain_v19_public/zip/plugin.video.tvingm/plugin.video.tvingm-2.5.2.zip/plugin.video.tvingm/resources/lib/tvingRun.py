__author__="NightRain"
wxIMWXkevDPcjlrFaSdhnETGURuCBz=object
wxIMWXkevDPcjlrFaSdhnETGURuCBK=None
wxIMWXkevDPcjlrFaSdhnETGURuCBg=int
wxIMWXkevDPcjlrFaSdhnETGURuCBq=True
wxIMWXkevDPcjlrFaSdhnETGURuCBp=False
wxIMWXkevDPcjlrFaSdhnETGURuCBL=type
wxIMWXkevDPcjlrFaSdhnETGURuCBm=dict
wxIMWXkevDPcjlrFaSdhnETGURuCBY=len
wxIMWXkevDPcjlrFaSdhnETGURuCBs=str
wxIMWXkevDPcjlrFaSdhnETGURuCBy=range
wxIMWXkevDPcjlrFaSdhnETGURuCHQ=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
wxIMWXkevDPcjlrFaSdhnETGURuCQt=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'오직 티빙에만','mode':'ORI_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'VOD 방송 - 4K','mode':'4K_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 4K','mode':'4K_MOVIE','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
wxIMWXkevDPcjlrFaSdhnETGURuCQV=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
wxIMWXkevDPcjlrFaSdhnETGURuCQb=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
wxIMWXkevDPcjlrFaSdhnETGURuCQJ=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
wxIMWXkevDPcjlrFaSdhnETGURuCQN=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'로맨스','mode':'PROGRAM','stype':'PCO'},{'title':'코미디','mode':'PROGRAM','stype':'PCP'},{'title':'스릴러','mode':'PROGRAM','stype':'PCQ'},{'title':'미스터리(추리)','mode':'PROGRAM','stype':'PCAA'},{'title':'모험','mode':'PROGRAM','stype':'PCX'},{'title':'액션','mode':'PROGRAM','stype':'PCY'},{'title':'판타지','mode':'PROGRAM','stype':'PCR'},{'title':'무협','mode':'PROGRAM','stype':'PCAB'},{'title':'공포','mode':'PROGRAM','stype':'PCAD'},{'title':'리얼리티','mode':'PROGRAM','stype':'PCV'},{'title':'토크쇼','mode':'PROGRAM','stype':'PCU'},{'title':'다큐멘터리','mode':'PROGRAM','stype':'PCT'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'스포츠','mode':'PROGRAM','stype':'PCF'},{'title':'음악','mode':'PROGRAM','stype':'PCAC'},{'title':'공연','mode':'PROGRAM','stype':'PCW'},{'title':'사극(시대극)','mode':'PROGRAM','stype':'PCS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'Paramount+','mode':'PROGRAM','stype':'PARAMOUNT'}]
wxIMWXkevDPcjlrFaSdhnETGURuCQB=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG23'},{'title':'로맨스','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'스릴러','mode':'MOVIE_SUB','stype':'MG140'},{'title':'미스터리','mode':'MOVIE_SUB','stype':'MG150'},{'title':'모험','mode':'MOVIE_SUB','stype':'MG170'},{'title':'액션','mode':'MOVIE_SUB','stype':'MG120'},{'title':'판타지','mode':'MOVIE_SUB','stype':'MG200'},{'title':'SF','mode':'MOVIE_SUB','stype':'MG210'},{'title':'공포','mode':'MOVIE_SUB','stype':'MG160'},{'title':'다큐멘터리','mode':'MOVIE_SUB','stype':'MG250'},{'title':'다양성 영화','mode':'MOVIE_SUB','stype':'diversityYn'},{'title':'Paramount+','mode':'MOVIE_SUB','stype':'PARAMOUNT'}]
wxIMWXkevDPcjlrFaSdhnETGURuCQH=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
wxIMWXkevDPcjlrFaSdhnETGURuCQi =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
wxIMWXkevDPcjlrFaSdhnETGURuCQO=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
from tvingCore import*
class wxIMWXkevDPcjlrFaSdhnETGURuCQo(wxIMWXkevDPcjlrFaSdhnETGURuCBz):
 def __init__(wxIMWXkevDPcjlrFaSdhnETGURuCQA,wxIMWXkevDPcjlrFaSdhnETGURuCQf,wxIMWXkevDPcjlrFaSdhnETGURuCQz,wxIMWXkevDPcjlrFaSdhnETGURuCQK):
  wxIMWXkevDPcjlrFaSdhnETGURuCQA._addon_url =wxIMWXkevDPcjlrFaSdhnETGURuCQf
  wxIMWXkevDPcjlrFaSdhnETGURuCQA._addon_handle=wxIMWXkevDPcjlrFaSdhnETGURuCQz
  wxIMWXkevDPcjlrFaSdhnETGURuCQA.main_params =wxIMWXkevDPcjlrFaSdhnETGURuCQK
  wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj =qocTtyJDvIAmBaXfQLhFzuwnWkdjrV() 
  wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj.TV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_stream.mpd'))
 def addon_noti(wxIMWXkevDPcjlrFaSdhnETGURuCQA,sting):
  try:
   wxIMWXkevDPcjlrFaSdhnETGURuCQq=xbmcgui.Dialog()
   wxIMWXkevDPcjlrFaSdhnETGURuCQq.notification(__addonname__,sting)
  except:
   wxIMWXkevDPcjlrFaSdhnETGURuCBK
 def addon_log(wxIMWXkevDPcjlrFaSdhnETGURuCQA,string):
  try:
   wxIMWXkevDPcjlrFaSdhnETGURuCQp=string.encode('utf-8','ignore')
  except:
   wxIMWXkevDPcjlrFaSdhnETGURuCQp='addonException: addon_log'
  wxIMWXkevDPcjlrFaSdhnETGURuCQL=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,wxIMWXkevDPcjlrFaSdhnETGURuCQp),level=wxIMWXkevDPcjlrFaSdhnETGURuCQL)
 def get_keyboard_input(wxIMWXkevDPcjlrFaSdhnETGURuCQA,wxIMWXkevDPcjlrFaSdhnETGURuCoK):
  wxIMWXkevDPcjlrFaSdhnETGURuCQm=wxIMWXkevDPcjlrFaSdhnETGURuCBK
  kb=xbmc.Keyboard()
  kb.setHeading(wxIMWXkevDPcjlrFaSdhnETGURuCoK)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   wxIMWXkevDPcjlrFaSdhnETGURuCQm=kb.getText()
  return wxIMWXkevDPcjlrFaSdhnETGURuCQm
 def get_settings_account(wxIMWXkevDPcjlrFaSdhnETGURuCQA):
  wxIMWXkevDPcjlrFaSdhnETGURuCQY =__addon__.getSetting('id')
  wxIMWXkevDPcjlrFaSdhnETGURuCQs =__addon__.getSetting('pw')
  wxIMWXkevDPcjlrFaSdhnETGURuCQy =__addon__.getSetting('login_type')
  wxIMWXkevDPcjlrFaSdhnETGURuCoQ=wxIMWXkevDPcjlrFaSdhnETGURuCBg(__addon__.getSetting('selected_profile'))
  return(wxIMWXkevDPcjlrFaSdhnETGURuCQY,wxIMWXkevDPcjlrFaSdhnETGURuCQs,wxIMWXkevDPcjlrFaSdhnETGURuCQy,wxIMWXkevDPcjlrFaSdhnETGURuCoQ)
 def get_settings_uhd(wxIMWXkevDPcjlrFaSdhnETGURuCQA):
  return wxIMWXkevDPcjlrFaSdhnETGURuCBq if __addon__.getSetting('active_uhd')=='true' else wxIMWXkevDPcjlrFaSdhnETGURuCBp
 def get_settings_playback(wxIMWXkevDPcjlrFaSdhnETGURuCQA):
  wxIMWXkevDPcjlrFaSdhnETGURuCot={'active_uhd':wxIMWXkevDPcjlrFaSdhnETGURuCBq if __addon__.getSetting('active_uhd')=='true' else wxIMWXkevDPcjlrFaSdhnETGURuCBp,'streamFilename':wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj.TV_STREAM_FILENAME,}
  return wxIMWXkevDPcjlrFaSdhnETGURuCot
 def get_settings_proxyport(wxIMWXkevDPcjlrFaSdhnETGURuCQA):
  wxIMWXkevDPcjlrFaSdhnETGURuCoV =wxIMWXkevDPcjlrFaSdhnETGURuCBq if __addon__.getSetting('proxyYn')=='true' else wxIMWXkevDPcjlrFaSdhnETGURuCBp
  wxIMWXkevDPcjlrFaSdhnETGURuCob=wxIMWXkevDPcjlrFaSdhnETGURuCBg(__addon__.getSetting('proxyPort'))
  return wxIMWXkevDPcjlrFaSdhnETGURuCoV,wxIMWXkevDPcjlrFaSdhnETGURuCob
 def get_settings_totalsearch(wxIMWXkevDPcjlrFaSdhnETGURuCQA):
  wxIMWXkevDPcjlrFaSdhnETGURuCoJ =wxIMWXkevDPcjlrFaSdhnETGURuCBq if __addon__.getSetting('local_search')=='true' else wxIMWXkevDPcjlrFaSdhnETGURuCBp
  wxIMWXkevDPcjlrFaSdhnETGURuCoN=wxIMWXkevDPcjlrFaSdhnETGURuCBq if __addon__.getSetting('local_history')=='true' else wxIMWXkevDPcjlrFaSdhnETGURuCBp
  wxIMWXkevDPcjlrFaSdhnETGURuCoB =wxIMWXkevDPcjlrFaSdhnETGURuCBq if __addon__.getSetting('total_search')=='true' else wxIMWXkevDPcjlrFaSdhnETGURuCBp
  wxIMWXkevDPcjlrFaSdhnETGURuCoH=wxIMWXkevDPcjlrFaSdhnETGURuCBq if __addon__.getSetting('total_history')=='true' else wxIMWXkevDPcjlrFaSdhnETGURuCBp
  wxIMWXkevDPcjlrFaSdhnETGURuCoi=wxIMWXkevDPcjlrFaSdhnETGURuCBq if __addon__.getSetting('menu_bookmark')=='true' else wxIMWXkevDPcjlrFaSdhnETGURuCBp
  return(wxIMWXkevDPcjlrFaSdhnETGURuCoJ,wxIMWXkevDPcjlrFaSdhnETGURuCoN,wxIMWXkevDPcjlrFaSdhnETGURuCoB,wxIMWXkevDPcjlrFaSdhnETGURuCoH,wxIMWXkevDPcjlrFaSdhnETGURuCoi)
 def get_settings_makebookmark(wxIMWXkevDPcjlrFaSdhnETGURuCQA):
  return wxIMWXkevDPcjlrFaSdhnETGURuCBq if __addon__.getSetting('make_bookmark')=='true' else wxIMWXkevDPcjlrFaSdhnETGURuCBp
 def get_settings_direct_replay(wxIMWXkevDPcjlrFaSdhnETGURuCQA):
  wxIMWXkevDPcjlrFaSdhnETGURuCoO=wxIMWXkevDPcjlrFaSdhnETGURuCBg(__addon__.getSetting('direct_replay'))
  if wxIMWXkevDPcjlrFaSdhnETGURuCoO==0:
   return wxIMWXkevDPcjlrFaSdhnETGURuCBp
  else:
   return wxIMWXkevDPcjlrFaSdhnETGURuCBq
 def set_winEpisodeOrderby(wxIMWXkevDPcjlrFaSdhnETGURuCQA,wxIMWXkevDPcjlrFaSdhnETGURuCof):
  __addon__.setSetting('tving_orderby',wxIMWXkevDPcjlrFaSdhnETGURuCof)
  wxIMWXkevDPcjlrFaSdhnETGURuCoA=xbmcgui.Window(10000)
  wxIMWXkevDPcjlrFaSdhnETGURuCoA.setProperty('TVING_M_ORDERBY',wxIMWXkevDPcjlrFaSdhnETGURuCof)
 def get_winEpisodeOrderby(wxIMWXkevDPcjlrFaSdhnETGURuCQA):
  wxIMWXkevDPcjlrFaSdhnETGURuCof=__addon__.getSetting('tving_orderby')
  if wxIMWXkevDPcjlrFaSdhnETGURuCof in['',wxIMWXkevDPcjlrFaSdhnETGURuCBK]:wxIMWXkevDPcjlrFaSdhnETGURuCof='desc'
  return wxIMWXkevDPcjlrFaSdhnETGURuCof
 def add_dir(wxIMWXkevDPcjlrFaSdhnETGURuCQA,label,sublabel='',img='',infoLabels=wxIMWXkevDPcjlrFaSdhnETGURuCBK,isFolder=wxIMWXkevDPcjlrFaSdhnETGURuCBq,params='',isLink=wxIMWXkevDPcjlrFaSdhnETGURuCBp,ContextMenu=wxIMWXkevDPcjlrFaSdhnETGURuCBK):
  wxIMWXkevDPcjlrFaSdhnETGURuCoz='%s?%s'%(wxIMWXkevDPcjlrFaSdhnETGURuCQA._addon_url,urllib.parse.urlencode(params))
  if sublabel:wxIMWXkevDPcjlrFaSdhnETGURuCoK='%s < %s >'%(label,sublabel)
  else: wxIMWXkevDPcjlrFaSdhnETGURuCoK=label
  if not img:img='DefaultFolder.png'
  wxIMWXkevDPcjlrFaSdhnETGURuCog=xbmcgui.ListItem(wxIMWXkevDPcjlrFaSdhnETGURuCoK)
  if wxIMWXkevDPcjlrFaSdhnETGURuCBL(img)==wxIMWXkevDPcjlrFaSdhnETGURuCBm:
   wxIMWXkevDPcjlrFaSdhnETGURuCog.setArt(img)
  else:
   wxIMWXkevDPcjlrFaSdhnETGURuCog.setArt({'thumb':img,'poster':img})
  if infoLabels:wxIMWXkevDPcjlrFaSdhnETGURuCog.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   wxIMWXkevDPcjlrFaSdhnETGURuCog.setProperty('IsPlayable','true')
  if ContextMenu:wxIMWXkevDPcjlrFaSdhnETGURuCog.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(wxIMWXkevDPcjlrFaSdhnETGURuCQA._addon_handle,wxIMWXkevDPcjlrFaSdhnETGURuCoz,wxIMWXkevDPcjlrFaSdhnETGURuCog,isFolder)
 def get_selQuality(wxIMWXkevDPcjlrFaSdhnETGURuCQA,etype):
  try:
   wxIMWXkevDPcjlrFaSdhnETGURuCoq='selected_quality'
   wxIMWXkevDPcjlrFaSdhnETGURuCop=[1080,720,480,360]
   wxIMWXkevDPcjlrFaSdhnETGURuCoL=wxIMWXkevDPcjlrFaSdhnETGURuCBg(__addon__.getSetting(wxIMWXkevDPcjlrFaSdhnETGURuCoq))
   return wxIMWXkevDPcjlrFaSdhnETGURuCop[wxIMWXkevDPcjlrFaSdhnETGURuCoL]
  except:
   wxIMWXkevDPcjlrFaSdhnETGURuCBK
  return 720 
 def dp_Main_List(wxIMWXkevDPcjlrFaSdhnETGURuCQA):
  (wxIMWXkevDPcjlrFaSdhnETGURuCoJ,wxIMWXkevDPcjlrFaSdhnETGURuCoN,wxIMWXkevDPcjlrFaSdhnETGURuCoB,wxIMWXkevDPcjlrFaSdhnETGURuCoH,wxIMWXkevDPcjlrFaSdhnETGURuCoi)=wxIMWXkevDPcjlrFaSdhnETGURuCQA.get_settings_totalsearch()
  for wxIMWXkevDPcjlrFaSdhnETGURuCom in wxIMWXkevDPcjlrFaSdhnETGURuCQt:
   wxIMWXkevDPcjlrFaSdhnETGURuCoK=wxIMWXkevDPcjlrFaSdhnETGURuCom.get('title')
   wxIMWXkevDPcjlrFaSdhnETGURuCoY=''
   if wxIMWXkevDPcjlrFaSdhnETGURuCom.get('mode')=='SEARCH_GROUP' and wxIMWXkevDPcjlrFaSdhnETGURuCoJ ==wxIMWXkevDPcjlrFaSdhnETGURuCBp:continue
   elif wxIMWXkevDPcjlrFaSdhnETGURuCom.get('mode')=='SEARCH_HISTORY' and wxIMWXkevDPcjlrFaSdhnETGURuCoN==wxIMWXkevDPcjlrFaSdhnETGURuCBp:continue
   elif wxIMWXkevDPcjlrFaSdhnETGURuCom.get('mode')=='TOTAL_SEARCH' and wxIMWXkevDPcjlrFaSdhnETGURuCoB ==wxIMWXkevDPcjlrFaSdhnETGURuCBp:continue
   elif wxIMWXkevDPcjlrFaSdhnETGURuCom.get('mode')=='TOTAL_HISTORY' and wxIMWXkevDPcjlrFaSdhnETGURuCoH==wxIMWXkevDPcjlrFaSdhnETGURuCBp:continue
   elif wxIMWXkevDPcjlrFaSdhnETGURuCom.get('mode')=='MENU_BOOKMARK' and wxIMWXkevDPcjlrFaSdhnETGURuCoi==wxIMWXkevDPcjlrFaSdhnETGURuCBp:continue
   wxIMWXkevDPcjlrFaSdhnETGURuCos={'mode':wxIMWXkevDPcjlrFaSdhnETGURuCom.get('mode'),'stype':wxIMWXkevDPcjlrFaSdhnETGURuCom.get('stype'),'orderby':wxIMWXkevDPcjlrFaSdhnETGURuCom.get('orderby'),'ordernm':wxIMWXkevDPcjlrFaSdhnETGURuCom.get('ordernm'),'page':'1'}
   if wxIMWXkevDPcjlrFaSdhnETGURuCom.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    wxIMWXkevDPcjlrFaSdhnETGURuCoy=wxIMWXkevDPcjlrFaSdhnETGURuCBp
    wxIMWXkevDPcjlrFaSdhnETGURuCtQ =wxIMWXkevDPcjlrFaSdhnETGURuCBq
   else:
    wxIMWXkevDPcjlrFaSdhnETGURuCoy=wxIMWXkevDPcjlrFaSdhnETGURuCBq
    wxIMWXkevDPcjlrFaSdhnETGURuCtQ =wxIMWXkevDPcjlrFaSdhnETGURuCBp
   if 'icon' in wxIMWXkevDPcjlrFaSdhnETGURuCom:wxIMWXkevDPcjlrFaSdhnETGURuCoY=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',wxIMWXkevDPcjlrFaSdhnETGURuCom.get('icon')) 
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.add_dir(wxIMWXkevDPcjlrFaSdhnETGURuCoK,sublabel='',img=wxIMWXkevDPcjlrFaSdhnETGURuCoY,infoLabels=wxIMWXkevDPcjlrFaSdhnETGURuCBK,isFolder=wxIMWXkevDPcjlrFaSdhnETGURuCoy,params=wxIMWXkevDPcjlrFaSdhnETGURuCos,isLink=wxIMWXkevDPcjlrFaSdhnETGURuCtQ)
  xbmcplugin.endOfDirectory(wxIMWXkevDPcjlrFaSdhnETGURuCQA._addon_handle)
 def login_main(wxIMWXkevDPcjlrFaSdhnETGURuCQA):
  (wxIMWXkevDPcjlrFaSdhnETGURuCtV,wxIMWXkevDPcjlrFaSdhnETGURuCtb,wxIMWXkevDPcjlrFaSdhnETGURuCtJ,wxIMWXkevDPcjlrFaSdhnETGURuCtN)=wxIMWXkevDPcjlrFaSdhnETGURuCQA.get_settings_account()
  if not(wxIMWXkevDPcjlrFaSdhnETGURuCtV and wxIMWXkevDPcjlrFaSdhnETGURuCtb):
   wxIMWXkevDPcjlrFaSdhnETGURuCQq=xbmcgui.Dialog()
   wxIMWXkevDPcjlrFaSdhnETGURuCtB=wxIMWXkevDPcjlrFaSdhnETGURuCQq.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if wxIMWXkevDPcjlrFaSdhnETGURuCtB==wxIMWXkevDPcjlrFaSdhnETGURuCBq:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if wxIMWXkevDPcjlrFaSdhnETGURuCQA.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   wxIMWXkevDPcjlrFaSdhnETGURuCtH=0
   while wxIMWXkevDPcjlrFaSdhnETGURuCBq:
    wxIMWXkevDPcjlrFaSdhnETGURuCtH+=1
    time.sleep(0.05)
    if wxIMWXkevDPcjlrFaSdhnETGURuCtH>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  wxIMWXkevDPcjlrFaSdhnETGURuCti=wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj.GetCredential(wxIMWXkevDPcjlrFaSdhnETGURuCtV,wxIMWXkevDPcjlrFaSdhnETGURuCtb,wxIMWXkevDPcjlrFaSdhnETGURuCtJ,wxIMWXkevDPcjlrFaSdhnETGURuCtN)
  if wxIMWXkevDPcjlrFaSdhnETGURuCti:wxIMWXkevDPcjlrFaSdhnETGURuCQA.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
  if wxIMWXkevDPcjlrFaSdhnETGURuCti==wxIMWXkevDPcjlrFaSdhnETGURuCBp:
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(wxIMWXkevDPcjlrFaSdhnETGURuCQA,wxIMWXkevDPcjlrFaSdhnETGURuCtz):
  wxIMWXkevDPcjlrFaSdhnETGURuCtO=wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('stype')
  if wxIMWXkevDPcjlrFaSdhnETGURuCtO=='live':
   wxIMWXkevDPcjlrFaSdhnETGURuCtA=wxIMWXkevDPcjlrFaSdhnETGURuCQV
  elif wxIMWXkevDPcjlrFaSdhnETGURuCtO=='vod':
   wxIMWXkevDPcjlrFaSdhnETGURuCtA=wxIMWXkevDPcjlrFaSdhnETGURuCQN
  else:
   wxIMWXkevDPcjlrFaSdhnETGURuCtA=wxIMWXkevDPcjlrFaSdhnETGURuCQB
  for wxIMWXkevDPcjlrFaSdhnETGURuCtf in wxIMWXkevDPcjlrFaSdhnETGURuCtA:
   wxIMWXkevDPcjlrFaSdhnETGURuCoK=wxIMWXkevDPcjlrFaSdhnETGURuCtf.get('title')
   if wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('ordernm')!='-':
    wxIMWXkevDPcjlrFaSdhnETGURuCoK+='  ('+wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('ordernm')+')'
   wxIMWXkevDPcjlrFaSdhnETGURuCos={'mode':wxIMWXkevDPcjlrFaSdhnETGURuCtf.get('mode'),'stype':wxIMWXkevDPcjlrFaSdhnETGURuCtf.get('stype'),'orderby':wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('orderby'),'ordernm':wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('ordernm'),'page':'1'}
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.add_dir(wxIMWXkevDPcjlrFaSdhnETGURuCoK,sublabel='',img='',infoLabels=wxIMWXkevDPcjlrFaSdhnETGURuCBK,isFolder=wxIMWXkevDPcjlrFaSdhnETGURuCBq,params=wxIMWXkevDPcjlrFaSdhnETGURuCos)
  if wxIMWXkevDPcjlrFaSdhnETGURuCBY(wxIMWXkevDPcjlrFaSdhnETGURuCtA)>0:xbmcplugin.endOfDirectory(wxIMWXkevDPcjlrFaSdhnETGURuCQA._addon_handle)
 def dp_SubTitle_Group(wxIMWXkevDPcjlrFaSdhnETGURuCQA,wxIMWXkevDPcjlrFaSdhnETGURuCtz): 
  for wxIMWXkevDPcjlrFaSdhnETGURuCtf in wxIMWXkevDPcjlrFaSdhnETGURuCQH:
   wxIMWXkevDPcjlrFaSdhnETGURuCoK=wxIMWXkevDPcjlrFaSdhnETGURuCtf.get('title')
   if wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('ordernm')!='-':
    wxIMWXkevDPcjlrFaSdhnETGURuCoK+='  ('+wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('ordernm')+')'
   wxIMWXkevDPcjlrFaSdhnETGURuCos={'mode':wxIMWXkevDPcjlrFaSdhnETGURuCtf.get('mode'),'genreCode':wxIMWXkevDPcjlrFaSdhnETGURuCtf.get('genreCode'),'stype':wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('stype'),'orderby':wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('orderby'),'page':'1'}
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.add_dir(wxIMWXkevDPcjlrFaSdhnETGURuCoK,sublabel='',img='',infoLabels=wxIMWXkevDPcjlrFaSdhnETGURuCBK,isFolder=wxIMWXkevDPcjlrFaSdhnETGURuCBq,params=wxIMWXkevDPcjlrFaSdhnETGURuCos)
  if wxIMWXkevDPcjlrFaSdhnETGURuCBY(wxIMWXkevDPcjlrFaSdhnETGURuCQH)>0:xbmcplugin.endOfDirectory(wxIMWXkevDPcjlrFaSdhnETGURuCQA._addon_handle)
 def dp_LiveChannel_List(wxIMWXkevDPcjlrFaSdhnETGURuCQA,wxIMWXkevDPcjlrFaSdhnETGURuCtz):
  wxIMWXkevDPcjlrFaSdhnETGURuCtO =wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('stype')
  wxIMWXkevDPcjlrFaSdhnETGURuCtK =wxIMWXkevDPcjlrFaSdhnETGURuCBg(wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('page'))
  wxIMWXkevDPcjlrFaSdhnETGURuCtg,wxIMWXkevDPcjlrFaSdhnETGURuCtq=wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj.GetLiveChannelList(wxIMWXkevDPcjlrFaSdhnETGURuCtO,wxIMWXkevDPcjlrFaSdhnETGURuCtK)
  for wxIMWXkevDPcjlrFaSdhnETGURuCtp in wxIMWXkevDPcjlrFaSdhnETGURuCtg:
   wxIMWXkevDPcjlrFaSdhnETGURuCoK =wxIMWXkevDPcjlrFaSdhnETGURuCtp.get('title')
   wxIMWXkevDPcjlrFaSdhnETGURuCto =wxIMWXkevDPcjlrFaSdhnETGURuCtp.get('channel')
   wxIMWXkevDPcjlrFaSdhnETGURuCtL =wxIMWXkevDPcjlrFaSdhnETGURuCtp.get('thumbnail')
   wxIMWXkevDPcjlrFaSdhnETGURuCtm =wxIMWXkevDPcjlrFaSdhnETGURuCtp.get('synopsis')
   wxIMWXkevDPcjlrFaSdhnETGURuCtY =wxIMWXkevDPcjlrFaSdhnETGURuCtp.get('channelepg')
   wxIMWXkevDPcjlrFaSdhnETGURuCts =wxIMWXkevDPcjlrFaSdhnETGURuCtp.get('cast')
   wxIMWXkevDPcjlrFaSdhnETGURuCty =wxIMWXkevDPcjlrFaSdhnETGURuCtp.get('director')
   wxIMWXkevDPcjlrFaSdhnETGURuCVQ =wxIMWXkevDPcjlrFaSdhnETGURuCtp.get('info_genre')
   wxIMWXkevDPcjlrFaSdhnETGURuCVo =wxIMWXkevDPcjlrFaSdhnETGURuCtp.get('year')
   wxIMWXkevDPcjlrFaSdhnETGURuCVt =wxIMWXkevDPcjlrFaSdhnETGURuCtp.get('mpaa')
   wxIMWXkevDPcjlrFaSdhnETGURuCVb =wxIMWXkevDPcjlrFaSdhnETGURuCtp.get('premiered')
   wxIMWXkevDPcjlrFaSdhnETGURuCVJ={'mediatype':'episode','title':wxIMWXkevDPcjlrFaSdhnETGURuCoK,'studio':wxIMWXkevDPcjlrFaSdhnETGURuCto,'cast':wxIMWXkevDPcjlrFaSdhnETGURuCts,'director':wxIMWXkevDPcjlrFaSdhnETGURuCty,'genre':wxIMWXkevDPcjlrFaSdhnETGURuCVQ,'plot':'%s\n%s\n%s\n\n%s'%(wxIMWXkevDPcjlrFaSdhnETGURuCto,wxIMWXkevDPcjlrFaSdhnETGURuCoK,wxIMWXkevDPcjlrFaSdhnETGURuCtY,wxIMWXkevDPcjlrFaSdhnETGURuCtm),'year':wxIMWXkevDPcjlrFaSdhnETGURuCVo,'mpaa':wxIMWXkevDPcjlrFaSdhnETGURuCVt,'premiered':wxIMWXkevDPcjlrFaSdhnETGURuCVb}
   wxIMWXkevDPcjlrFaSdhnETGURuCos={'mode':'LIVE','mediacode':wxIMWXkevDPcjlrFaSdhnETGURuCtp.get('mediacode'),'stype':wxIMWXkevDPcjlrFaSdhnETGURuCtO}
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.add_dir(wxIMWXkevDPcjlrFaSdhnETGURuCto,sublabel=wxIMWXkevDPcjlrFaSdhnETGURuCoK,img=wxIMWXkevDPcjlrFaSdhnETGURuCtL,infoLabels=wxIMWXkevDPcjlrFaSdhnETGURuCVJ,isFolder=wxIMWXkevDPcjlrFaSdhnETGURuCBp,params=wxIMWXkevDPcjlrFaSdhnETGURuCos)
  if wxIMWXkevDPcjlrFaSdhnETGURuCtq:
   wxIMWXkevDPcjlrFaSdhnETGURuCos['mode']='CHANNEL' 
   wxIMWXkevDPcjlrFaSdhnETGURuCos['stype']=wxIMWXkevDPcjlrFaSdhnETGURuCtO 
   wxIMWXkevDPcjlrFaSdhnETGURuCos['page']=wxIMWXkevDPcjlrFaSdhnETGURuCBs(wxIMWXkevDPcjlrFaSdhnETGURuCtK+1)
   wxIMWXkevDPcjlrFaSdhnETGURuCoK='[B]%s >>[/B]'%'다음 페이지'
   wxIMWXkevDPcjlrFaSdhnETGURuCVN=wxIMWXkevDPcjlrFaSdhnETGURuCBs(wxIMWXkevDPcjlrFaSdhnETGURuCtK+1)
   wxIMWXkevDPcjlrFaSdhnETGURuCoY=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.add_dir(wxIMWXkevDPcjlrFaSdhnETGURuCoK,sublabel=wxIMWXkevDPcjlrFaSdhnETGURuCVN,img=wxIMWXkevDPcjlrFaSdhnETGURuCoY,infoLabels=wxIMWXkevDPcjlrFaSdhnETGURuCBK,isFolder=wxIMWXkevDPcjlrFaSdhnETGURuCBq,params=wxIMWXkevDPcjlrFaSdhnETGURuCos)
  if wxIMWXkevDPcjlrFaSdhnETGURuCBY(wxIMWXkevDPcjlrFaSdhnETGURuCtg)>0:xbmcplugin.endOfDirectory(wxIMWXkevDPcjlrFaSdhnETGURuCQA._addon_handle,cacheToDisc=wxIMWXkevDPcjlrFaSdhnETGURuCBp)
 def dp_Program_List(wxIMWXkevDPcjlrFaSdhnETGURuCQA,wxIMWXkevDPcjlrFaSdhnETGURuCtz):
  wxIMWXkevDPcjlrFaSdhnETGURuCVB =wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('stype')
  wxIMWXkevDPcjlrFaSdhnETGURuCof =wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('orderby')
  wxIMWXkevDPcjlrFaSdhnETGURuCtK =wxIMWXkevDPcjlrFaSdhnETGURuCBg(wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('page'))
  wxIMWXkevDPcjlrFaSdhnETGURuCVH=wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('genreCode')
  if wxIMWXkevDPcjlrFaSdhnETGURuCVH==wxIMWXkevDPcjlrFaSdhnETGURuCBK:wxIMWXkevDPcjlrFaSdhnETGURuCVH='all'
  wxIMWXkevDPcjlrFaSdhnETGURuCVi,wxIMWXkevDPcjlrFaSdhnETGURuCtq=wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj.GetProgramList(wxIMWXkevDPcjlrFaSdhnETGURuCVB,wxIMWXkevDPcjlrFaSdhnETGURuCof,wxIMWXkevDPcjlrFaSdhnETGURuCtK,wxIMWXkevDPcjlrFaSdhnETGURuCVH)
  for wxIMWXkevDPcjlrFaSdhnETGURuCVO in wxIMWXkevDPcjlrFaSdhnETGURuCVi:
   wxIMWXkevDPcjlrFaSdhnETGURuCoK =wxIMWXkevDPcjlrFaSdhnETGURuCVO.get('title')
   wxIMWXkevDPcjlrFaSdhnETGURuCtL =wxIMWXkevDPcjlrFaSdhnETGURuCVO.get('thumbnail')
   wxIMWXkevDPcjlrFaSdhnETGURuCtm =wxIMWXkevDPcjlrFaSdhnETGURuCVO.get('synopsis')
   wxIMWXkevDPcjlrFaSdhnETGURuCVA =wxIMWXkevDPcjlrFaSdhnETGURuCVO.get('channel')
   wxIMWXkevDPcjlrFaSdhnETGURuCts =wxIMWXkevDPcjlrFaSdhnETGURuCVO.get('cast')
   wxIMWXkevDPcjlrFaSdhnETGURuCty =wxIMWXkevDPcjlrFaSdhnETGURuCVO.get('director')
   wxIMWXkevDPcjlrFaSdhnETGURuCVQ=wxIMWXkevDPcjlrFaSdhnETGURuCVO.get('info_genre')
   wxIMWXkevDPcjlrFaSdhnETGURuCVo =wxIMWXkevDPcjlrFaSdhnETGURuCVO.get('year')
   wxIMWXkevDPcjlrFaSdhnETGURuCVb =wxIMWXkevDPcjlrFaSdhnETGURuCVO.get('premiered')
   wxIMWXkevDPcjlrFaSdhnETGURuCVt =wxIMWXkevDPcjlrFaSdhnETGURuCVO.get('mpaa')
   wxIMWXkevDPcjlrFaSdhnETGURuCVJ={'mediatype':'tvshow','title':wxIMWXkevDPcjlrFaSdhnETGURuCoK,'studio':wxIMWXkevDPcjlrFaSdhnETGURuCVA,'cast':wxIMWXkevDPcjlrFaSdhnETGURuCts,'director':wxIMWXkevDPcjlrFaSdhnETGURuCty,'genre':wxIMWXkevDPcjlrFaSdhnETGURuCVQ,'year':wxIMWXkevDPcjlrFaSdhnETGURuCVo,'premiered':wxIMWXkevDPcjlrFaSdhnETGURuCVb,'mpaa':wxIMWXkevDPcjlrFaSdhnETGURuCVt,'plot':wxIMWXkevDPcjlrFaSdhnETGURuCtm}
   wxIMWXkevDPcjlrFaSdhnETGURuCos={'mode':'EPISODE','programcode':wxIMWXkevDPcjlrFaSdhnETGURuCVO.get('program'),'page':'1'}
   if wxIMWXkevDPcjlrFaSdhnETGURuCQA.get_settings_makebookmark():
    wxIMWXkevDPcjlrFaSdhnETGURuCVf={'videoid':wxIMWXkevDPcjlrFaSdhnETGURuCVO.get('program'),'vidtype':'tvshow','vtitle':wxIMWXkevDPcjlrFaSdhnETGURuCoK,'vsubtitle':wxIMWXkevDPcjlrFaSdhnETGURuCVA,}
    wxIMWXkevDPcjlrFaSdhnETGURuCVz=json.dumps(wxIMWXkevDPcjlrFaSdhnETGURuCVf)
    wxIMWXkevDPcjlrFaSdhnETGURuCVz=urllib.parse.quote(wxIMWXkevDPcjlrFaSdhnETGURuCVz)
    wxIMWXkevDPcjlrFaSdhnETGURuCVK='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(wxIMWXkevDPcjlrFaSdhnETGURuCVz)
    wxIMWXkevDPcjlrFaSdhnETGURuCVg=[('(통합) 찜 영상에 추가',wxIMWXkevDPcjlrFaSdhnETGURuCVK)]
   else:
    wxIMWXkevDPcjlrFaSdhnETGURuCVg=wxIMWXkevDPcjlrFaSdhnETGURuCBK
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.add_dir(wxIMWXkevDPcjlrFaSdhnETGURuCoK,sublabel=wxIMWXkevDPcjlrFaSdhnETGURuCVA,img=wxIMWXkevDPcjlrFaSdhnETGURuCtL,infoLabels=wxIMWXkevDPcjlrFaSdhnETGURuCVJ,isFolder=wxIMWXkevDPcjlrFaSdhnETGURuCBq,params=wxIMWXkevDPcjlrFaSdhnETGURuCos,ContextMenu=wxIMWXkevDPcjlrFaSdhnETGURuCVg)
  if wxIMWXkevDPcjlrFaSdhnETGURuCtq:
   wxIMWXkevDPcjlrFaSdhnETGURuCos['mode'] ='PROGRAM' 
   wxIMWXkevDPcjlrFaSdhnETGURuCos['stype'] =wxIMWXkevDPcjlrFaSdhnETGURuCVB
   wxIMWXkevDPcjlrFaSdhnETGURuCos['orderby'] =wxIMWXkevDPcjlrFaSdhnETGURuCof
   wxIMWXkevDPcjlrFaSdhnETGURuCos['page'] =wxIMWXkevDPcjlrFaSdhnETGURuCBs(wxIMWXkevDPcjlrFaSdhnETGURuCtK+1)
   wxIMWXkevDPcjlrFaSdhnETGURuCos['genreCode']=wxIMWXkevDPcjlrFaSdhnETGURuCVH 
   wxIMWXkevDPcjlrFaSdhnETGURuCoK='[B]%s >>[/B]'%'다음 페이지'
   wxIMWXkevDPcjlrFaSdhnETGURuCVN=wxIMWXkevDPcjlrFaSdhnETGURuCBs(wxIMWXkevDPcjlrFaSdhnETGURuCtK+1)
   wxIMWXkevDPcjlrFaSdhnETGURuCoY=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.add_dir(wxIMWXkevDPcjlrFaSdhnETGURuCoK,sublabel=wxIMWXkevDPcjlrFaSdhnETGURuCVN,img=wxIMWXkevDPcjlrFaSdhnETGURuCoY,infoLabels=wxIMWXkevDPcjlrFaSdhnETGURuCBK,isFolder=wxIMWXkevDPcjlrFaSdhnETGURuCBq,params=wxIMWXkevDPcjlrFaSdhnETGURuCos)
  xbmcplugin.setContent(wxIMWXkevDPcjlrFaSdhnETGURuCQA._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(wxIMWXkevDPcjlrFaSdhnETGURuCQA._addon_handle,cacheToDisc=wxIMWXkevDPcjlrFaSdhnETGURuCBp)
 def dp_4K_Program_List(wxIMWXkevDPcjlrFaSdhnETGURuCQA,wxIMWXkevDPcjlrFaSdhnETGURuCtz):
  wxIMWXkevDPcjlrFaSdhnETGURuCtK =wxIMWXkevDPcjlrFaSdhnETGURuCBg(wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('page'))
  wxIMWXkevDPcjlrFaSdhnETGURuCVi,wxIMWXkevDPcjlrFaSdhnETGURuCtq=wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj.Get_UHD_ProgramList(wxIMWXkevDPcjlrFaSdhnETGURuCtK)
  for wxIMWXkevDPcjlrFaSdhnETGURuCVO in wxIMWXkevDPcjlrFaSdhnETGURuCVi:
   wxIMWXkevDPcjlrFaSdhnETGURuCoK =wxIMWXkevDPcjlrFaSdhnETGURuCVO.get('title')
   wxIMWXkevDPcjlrFaSdhnETGURuCtL =wxIMWXkevDPcjlrFaSdhnETGURuCVO.get('thumbnail')
   wxIMWXkevDPcjlrFaSdhnETGURuCtm =wxIMWXkevDPcjlrFaSdhnETGURuCVO.get('synopsis')
   wxIMWXkevDPcjlrFaSdhnETGURuCVA =wxIMWXkevDPcjlrFaSdhnETGURuCVO.get('channel')
   wxIMWXkevDPcjlrFaSdhnETGURuCts =wxIMWXkevDPcjlrFaSdhnETGURuCVO.get('cast')
   wxIMWXkevDPcjlrFaSdhnETGURuCty =wxIMWXkevDPcjlrFaSdhnETGURuCVO.get('director')
   wxIMWXkevDPcjlrFaSdhnETGURuCVQ=wxIMWXkevDPcjlrFaSdhnETGURuCVO.get('info_genre')
   wxIMWXkevDPcjlrFaSdhnETGURuCVo =wxIMWXkevDPcjlrFaSdhnETGURuCVO.get('year')
   wxIMWXkevDPcjlrFaSdhnETGURuCVb =wxIMWXkevDPcjlrFaSdhnETGURuCVO.get('premiered')
   wxIMWXkevDPcjlrFaSdhnETGURuCVt =wxIMWXkevDPcjlrFaSdhnETGURuCVO.get('mpaa')
   wxIMWXkevDPcjlrFaSdhnETGURuCVJ={'mediatype':'tvshow','title':wxIMWXkevDPcjlrFaSdhnETGURuCoK,'studio':wxIMWXkevDPcjlrFaSdhnETGURuCVA,'cast':wxIMWXkevDPcjlrFaSdhnETGURuCts,'director':wxIMWXkevDPcjlrFaSdhnETGURuCty,'genre':wxIMWXkevDPcjlrFaSdhnETGURuCVQ,'year':wxIMWXkevDPcjlrFaSdhnETGURuCVo,'premiered':wxIMWXkevDPcjlrFaSdhnETGURuCVb,'mpaa':wxIMWXkevDPcjlrFaSdhnETGURuCVt,'plot':wxIMWXkevDPcjlrFaSdhnETGURuCtm}
   wxIMWXkevDPcjlrFaSdhnETGURuCos={'mode':'EPISODE','programcode':wxIMWXkevDPcjlrFaSdhnETGURuCVO.get('program'),'page':'1'}
   if wxIMWXkevDPcjlrFaSdhnETGURuCQA.get_settings_makebookmark():
    wxIMWXkevDPcjlrFaSdhnETGURuCVf={'videoid':wxIMWXkevDPcjlrFaSdhnETGURuCVO.get('program'),'vidtype':'tvshow','vtitle':wxIMWXkevDPcjlrFaSdhnETGURuCoK,'vsubtitle':wxIMWXkevDPcjlrFaSdhnETGURuCVA,}
    wxIMWXkevDPcjlrFaSdhnETGURuCVz=json.dumps(wxIMWXkevDPcjlrFaSdhnETGURuCVf)
    wxIMWXkevDPcjlrFaSdhnETGURuCVz=urllib.parse.quote(wxIMWXkevDPcjlrFaSdhnETGURuCVz)
    wxIMWXkevDPcjlrFaSdhnETGURuCVK='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(wxIMWXkevDPcjlrFaSdhnETGURuCVz)
    wxIMWXkevDPcjlrFaSdhnETGURuCVg=[('(통합) 찜 영상에 추가',wxIMWXkevDPcjlrFaSdhnETGURuCVK)]
   else:
    wxIMWXkevDPcjlrFaSdhnETGURuCVg=wxIMWXkevDPcjlrFaSdhnETGURuCBK
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.add_dir(wxIMWXkevDPcjlrFaSdhnETGURuCoK,sublabel=wxIMWXkevDPcjlrFaSdhnETGURuCVA,img=wxIMWXkevDPcjlrFaSdhnETGURuCtL,infoLabels=wxIMWXkevDPcjlrFaSdhnETGURuCVJ,isFolder=wxIMWXkevDPcjlrFaSdhnETGURuCBq,params=wxIMWXkevDPcjlrFaSdhnETGURuCos,ContextMenu=wxIMWXkevDPcjlrFaSdhnETGURuCVg)
  if wxIMWXkevDPcjlrFaSdhnETGURuCtq:
   wxIMWXkevDPcjlrFaSdhnETGURuCos['mode'] ='4K_PROGRAM' 
   wxIMWXkevDPcjlrFaSdhnETGURuCos['page'] =wxIMWXkevDPcjlrFaSdhnETGURuCBs(wxIMWXkevDPcjlrFaSdhnETGURuCtK+1)
   wxIMWXkevDPcjlrFaSdhnETGURuCoK='[B]%s >>[/B]'%'다음 페이지'
   wxIMWXkevDPcjlrFaSdhnETGURuCVN=wxIMWXkevDPcjlrFaSdhnETGURuCBs(wxIMWXkevDPcjlrFaSdhnETGURuCtK+1)
   wxIMWXkevDPcjlrFaSdhnETGURuCoY=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.add_dir(wxIMWXkevDPcjlrFaSdhnETGURuCoK,sublabel=wxIMWXkevDPcjlrFaSdhnETGURuCVN,img=wxIMWXkevDPcjlrFaSdhnETGURuCoY,infoLabels=wxIMWXkevDPcjlrFaSdhnETGURuCBK,isFolder=wxIMWXkevDPcjlrFaSdhnETGURuCBq,params=wxIMWXkevDPcjlrFaSdhnETGURuCos)
  xbmcplugin.setContent(wxIMWXkevDPcjlrFaSdhnETGURuCQA._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(wxIMWXkevDPcjlrFaSdhnETGURuCQA._addon_handle,cacheToDisc=wxIMWXkevDPcjlrFaSdhnETGURuCBp)
 def dp_Ori_Program_List(wxIMWXkevDPcjlrFaSdhnETGURuCQA,wxIMWXkevDPcjlrFaSdhnETGURuCtz):
  wxIMWXkevDPcjlrFaSdhnETGURuCtK =wxIMWXkevDPcjlrFaSdhnETGURuCBg(wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('page'))
  wxIMWXkevDPcjlrFaSdhnETGURuCVi,wxIMWXkevDPcjlrFaSdhnETGURuCtq=wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj.Get_Origianl_ProgramList(wxIMWXkevDPcjlrFaSdhnETGURuCtK)
  for wxIMWXkevDPcjlrFaSdhnETGURuCVO in wxIMWXkevDPcjlrFaSdhnETGURuCVi:
   wxIMWXkevDPcjlrFaSdhnETGURuCoK =wxIMWXkevDPcjlrFaSdhnETGURuCVO.get('title')
   wxIMWXkevDPcjlrFaSdhnETGURuCtL =wxIMWXkevDPcjlrFaSdhnETGURuCVO.get('thumbnail')
   wxIMWXkevDPcjlrFaSdhnETGURuCVJ={'mediatype':'tvshow','title':wxIMWXkevDPcjlrFaSdhnETGURuCoK,}
   wxIMWXkevDPcjlrFaSdhnETGURuCos={'mode':'EPISODE','programcode':wxIMWXkevDPcjlrFaSdhnETGURuCVO.get('program'),'page':'1',}
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.add_dir(wxIMWXkevDPcjlrFaSdhnETGURuCoK,sublabel=wxIMWXkevDPcjlrFaSdhnETGURuCBK,img=wxIMWXkevDPcjlrFaSdhnETGURuCtL,infoLabels=wxIMWXkevDPcjlrFaSdhnETGURuCVJ,isFolder=wxIMWXkevDPcjlrFaSdhnETGURuCBq,params=wxIMWXkevDPcjlrFaSdhnETGURuCos,ContextMenu=wxIMWXkevDPcjlrFaSdhnETGURuCBK)
  if wxIMWXkevDPcjlrFaSdhnETGURuCtq:
   wxIMWXkevDPcjlrFaSdhnETGURuCos['mode'] ='ORI_PROGRAM' 
   wxIMWXkevDPcjlrFaSdhnETGURuCos['page'] =wxIMWXkevDPcjlrFaSdhnETGURuCBs(wxIMWXkevDPcjlrFaSdhnETGURuCtK+1)
   wxIMWXkevDPcjlrFaSdhnETGURuCoK='[B]%s >>[/B]'%'다음 페이지'
   wxIMWXkevDPcjlrFaSdhnETGURuCVN=wxIMWXkevDPcjlrFaSdhnETGURuCBs(wxIMWXkevDPcjlrFaSdhnETGURuCtK+1)
   wxIMWXkevDPcjlrFaSdhnETGURuCoY=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.add_dir(wxIMWXkevDPcjlrFaSdhnETGURuCoK,sublabel=wxIMWXkevDPcjlrFaSdhnETGURuCVN,img=wxIMWXkevDPcjlrFaSdhnETGURuCoY,infoLabels=wxIMWXkevDPcjlrFaSdhnETGURuCBK,isFolder=wxIMWXkevDPcjlrFaSdhnETGURuCBq,params=wxIMWXkevDPcjlrFaSdhnETGURuCos)
  xbmcplugin.setContent(wxIMWXkevDPcjlrFaSdhnETGURuCQA._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(wxIMWXkevDPcjlrFaSdhnETGURuCQA._addon_handle,cacheToDisc=wxIMWXkevDPcjlrFaSdhnETGURuCBp)
 def dp_Episode_List(wxIMWXkevDPcjlrFaSdhnETGURuCQA,wxIMWXkevDPcjlrFaSdhnETGURuCtz):
  wxIMWXkevDPcjlrFaSdhnETGURuCVp=wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('programcode')
  wxIMWXkevDPcjlrFaSdhnETGURuCtK =wxIMWXkevDPcjlrFaSdhnETGURuCBg(wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('page'))
  wxIMWXkevDPcjlrFaSdhnETGURuCVL,wxIMWXkevDPcjlrFaSdhnETGURuCtq,wxIMWXkevDPcjlrFaSdhnETGURuCVm=wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj.GetEpisodeList(wxIMWXkevDPcjlrFaSdhnETGURuCVp,wxIMWXkevDPcjlrFaSdhnETGURuCtK,orderby=wxIMWXkevDPcjlrFaSdhnETGURuCQA.get_winEpisodeOrderby())
  for wxIMWXkevDPcjlrFaSdhnETGURuCVY in wxIMWXkevDPcjlrFaSdhnETGURuCVL:
   wxIMWXkevDPcjlrFaSdhnETGURuCoK =wxIMWXkevDPcjlrFaSdhnETGURuCVY.get('title')
   wxIMWXkevDPcjlrFaSdhnETGURuCVN =wxIMWXkevDPcjlrFaSdhnETGURuCVY.get('subtitle')
   wxIMWXkevDPcjlrFaSdhnETGURuCtL =wxIMWXkevDPcjlrFaSdhnETGURuCVY.get('thumbnail')
   wxIMWXkevDPcjlrFaSdhnETGURuCtm =wxIMWXkevDPcjlrFaSdhnETGURuCVY.get('synopsis')
   wxIMWXkevDPcjlrFaSdhnETGURuCVs=wxIMWXkevDPcjlrFaSdhnETGURuCVY.get('info_title')
   wxIMWXkevDPcjlrFaSdhnETGURuCVy =wxIMWXkevDPcjlrFaSdhnETGURuCVY.get('aired')
   wxIMWXkevDPcjlrFaSdhnETGURuCbQ =wxIMWXkevDPcjlrFaSdhnETGURuCVY.get('studio')
   wxIMWXkevDPcjlrFaSdhnETGURuCbo =wxIMWXkevDPcjlrFaSdhnETGURuCVY.get('frequency')
   wxIMWXkevDPcjlrFaSdhnETGURuCVJ={'mediatype':'episode','title':wxIMWXkevDPcjlrFaSdhnETGURuCVs,'aired':wxIMWXkevDPcjlrFaSdhnETGURuCVy,'studio':wxIMWXkevDPcjlrFaSdhnETGURuCbQ,'episode':wxIMWXkevDPcjlrFaSdhnETGURuCbo,'plot':wxIMWXkevDPcjlrFaSdhnETGURuCtm}
   wxIMWXkevDPcjlrFaSdhnETGURuCos={'mode':'VOD','mediacode':wxIMWXkevDPcjlrFaSdhnETGURuCVY.get('episode'),'stype':'vod','programcode':wxIMWXkevDPcjlrFaSdhnETGURuCVp,'title':wxIMWXkevDPcjlrFaSdhnETGURuCoK,'thumbnail':wxIMWXkevDPcjlrFaSdhnETGURuCtL}
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.add_dir(wxIMWXkevDPcjlrFaSdhnETGURuCoK,sublabel=wxIMWXkevDPcjlrFaSdhnETGURuCVN,img=wxIMWXkevDPcjlrFaSdhnETGURuCtL,infoLabels=wxIMWXkevDPcjlrFaSdhnETGURuCVJ,isFolder=wxIMWXkevDPcjlrFaSdhnETGURuCBp,params=wxIMWXkevDPcjlrFaSdhnETGURuCos)
  if wxIMWXkevDPcjlrFaSdhnETGURuCtK==1:
   wxIMWXkevDPcjlrFaSdhnETGURuCVJ={'plot':'정렬순서를 변경합니다.'}
   wxIMWXkevDPcjlrFaSdhnETGURuCos={}
   wxIMWXkevDPcjlrFaSdhnETGURuCos['mode'] ='ORDER_BY' 
   if wxIMWXkevDPcjlrFaSdhnETGURuCQA.get_winEpisodeOrderby()=='desc':
    wxIMWXkevDPcjlrFaSdhnETGURuCoK='정렬순서변경 : 최신화부터 -> 1회부터'
    wxIMWXkevDPcjlrFaSdhnETGURuCos['orderby']='asc'
   else:
    wxIMWXkevDPcjlrFaSdhnETGURuCoK='정렬순서변경 : 1회부터 -> 최신화부터'
    wxIMWXkevDPcjlrFaSdhnETGURuCos['orderby']='desc'
   wxIMWXkevDPcjlrFaSdhnETGURuCoY=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.add_dir(wxIMWXkevDPcjlrFaSdhnETGURuCoK,sublabel='',img=wxIMWXkevDPcjlrFaSdhnETGURuCoY,infoLabels=wxIMWXkevDPcjlrFaSdhnETGURuCVJ,isFolder=wxIMWXkevDPcjlrFaSdhnETGURuCBp,params=wxIMWXkevDPcjlrFaSdhnETGURuCos,isLink=wxIMWXkevDPcjlrFaSdhnETGURuCBq)
  if wxIMWXkevDPcjlrFaSdhnETGURuCtq:
   wxIMWXkevDPcjlrFaSdhnETGURuCos['mode'] ='EPISODE' 
   wxIMWXkevDPcjlrFaSdhnETGURuCos['programcode']=wxIMWXkevDPcjlrFaSdhnETGURuCVp
   wxIMWXkevDPcjlrFaSdhnETGURuCos['page'] =wxIMWXkevDPcjlrFaSdhnETGURuCBs(wxIMWXkevDPcjlrFaSdhnETGURuCtK+1)
   wxIMWXkevDPcjlrFaSdhnETGURuCoK='[B]%s >>[/B]'%'다음 페이지'
   wxIMWXkevDPcjlrFaSdhnETGURuCVN=wxIMWXkevDPcjlrFaSdhnETGURuCBs(wxIMWXkevDPcjlrFaSdhnETGURuCtK+1)
   wxIMWXkevDPcjlrFaSdhnETGURuCoY=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.add_dir(wxIMWXkevDPcjlrFaSdhnETGURuCoK,sublabel=wxIMWXkevDPcjlrFaSdhnETGURuCVN,img=wxIMWXkevDPcjlrFaSdhnETGURuCoY,infoLabels=wxIMWXkevDPcjlrFaSdhnETGURuCBK,isFolder=wxIMWXkevDPcjlrFaSdhnETGURuCBq,params=wxIMWXkevDPcjlrFaSdhnETGURuCos)
  xbmcplugin.setContent(wxIMWXkevDPcjlrFaSdhnETGURuCQA._addon_handle,'episodes')
  if wxIMWXkevDPcjlrFaSdhnETGURuCBY(wxIMWXkevDPcjlrFaSdhnETGURuCVL)>0:xbmcplugin.endOfDirectory(wxIMWXkevDPcjlrFaSdhnETGURuCQA._addon_handle,cacheToDisc=wxIMWXkevDPcjlrFaSdhnETGURuCBq)
 def dp_setEpOrderby(wxIMWXkevDPcjlrFaSdhnETGURuCQA,wxIMWXkevDPcjlrFaSdhnETGURuCtz):
  wxIMWXkevDPcjlrFaSdhnETGURuCof =wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('orderby')
  wxIMWXkevDPcjlrFaSdhnETGURuCQA.set_winEpisodeOrderby(wxIMWXkevDPcjlrFaSdhnETGURuCof)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(wxIMWXkevDPcjlrFaSdhnETGURuCQA,wxIMWXkevDPcjlrFaSdhnETGURuCtz):
  wxIMWXkevDPcjlrFaSdhnETGURuCVB =wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('stype')
  wxIMWXkevDPcjlrFaSdhnETGURuCof =wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('orderby')
  wxIMWXkevDPcjlrFaSdhnETGURuCtK=wxIMWXkevDPcjlrFaSdhnETGURuCBg(wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('page'))
  wxIMWXkevDPcjlrFaSdhnETGURuCbt,wxIMWXkevDPcjlrFaSdhnETGURuCtq=wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj.GetMovieList(wxIMWXkevDPcjlrFaSdhnETGURuCVB,wxIMWXkevDPcjlrFaSdhnETGURuCof,wxIMWXkevDPcjlrFaSdhnETGURuCtK)
  for wxIMWXkevDPcjlrFaSdhnETGURuCbV in wxIMWXkevDPcjlrFaSdhnETGURuCbt:
   wxIMWXkevDPcjlrFaSdhnETGURuCoK =wxIMWXkevDPcjlrFaSdhnETGURuCbV.get('title')
   wxIMWXkevDPcjlrFaSdhnETGURuCtL =wxIMWXkevDPcjlrFaSdhnETGURuCbV.get('thumbnail')
   wxIMWXkevDPcjlrFaSdhnETGURuCtm =wxIMWXkevDPcjlrFaSdhnETGURuCbV.get('synopsis')
   wxIMWXkevDPcjlrFaSdhnETGURuCVs =wxIMWXkevDPcjlrFaSdhnETGURuCbV.get('info_title')
   wxIMWXkevDPcjlrFaSdhnETGURuCVo =wxIMWXkevDPcjlrFaSdhnETGURuCbV.get('year')
   wxIMWXkevDPcjlrFaSdhnETGURuCts =wxIMWXkevDPcjlrFaSdhnETGURuCbV.get('cast')
   wxIMWXkevDPcjlrFaSdhnETGURuCty =wxIMWXkevDPcjlrFaSdhnETGURuCbV.get('director')
   wxIMWXkevDPcjlrFaSdhnETGURuCVQ =wxIMWXkevDPcjlrFaSdhnETGURuCbV.get('info_genre')
   wxIMWXkevDPcjlrFaSdhnETGURuCbJ =wxIMWXkevDPcjlrFaSdhnETGURuCbV.get('duration')
   wxIMWXkevDPcjlrFaSdhnETGURuCVb =wxIMWXkevDPcjlrFaSdhnETGURuCbV.get('premiered')
   wxIMWXkevDPcjlrFaSdhnETGURuCbQ =wxIMWXkevDPcjlrFaSdhnETGURuCbV.get('studio')
   wxIMWXkevDPcjlrFaSdhnETGURuCVt =wxIMWXkevDPcjlrFaSdhnETGURuCbV.get('mpaa')
   wxIMWXkevDPcjlrFaSdhnETGURuCVJ={'mediatype':'movie','title':wxIMWXkevDPcjlrFaSdhnETGURuCVs,'year':wxIMWXkevDPcjlrFaSdhnETGURuCVo,'cast':wxIMWXkevDPcjlrFaSdhnETGURuCts,'director':wxIMWXkevDPcjlrFaSdhnETGURuCty,'genre':wxIMWXkevDPcjlrFaSdhnETGURuCVQ,'duration':wxIMWXkevDPcjlrFaSdhnETGURuCbJ,'premiered':wxIMWXkevDPcjlrFaSdhnETGURuCVb,'studio':wxIMWXkevDPcjlrFaSdhnETGURuCbQ,'mpaa':wxIMWXkevDPcjlrFaSdhnETGURuCVt,'plot':wxIMWXkevDPcjlrFaSdhnETGURuCtm}
   wxIMWXkevDPcjlrFaSdhnETGURuCos={'mode':'MOVIE','mediacode':wxIMWXkevDPcjlrFaSdhnETGURuCbV.get('moviecode'),'stype':'movie','title':wxIMWXkevDPcjlrFaSdhnETGURuCoK,'thumbnail':wxIMWXkevDPcjlrFaSdhnETGURuCtL}
   if wxIMWXkevDPcjlrFaSdhnETGURuCQA.get_settings_makebookmark():
    wxIMWXkevDPcjlrFaSdhnETGURuCVf={'videoid':wxIMWXkevDPcjlrFaSdhnETGURuCbV.get('moviecode'),'vidtype':'movie','vtitle':wxIMWXkevDPcjlrFaSdhnETGURuCVs,'vsubtitle':'',}
    wxIMWXkevDPcjlrFaSdhnETGURuCVz=json.dumps(wxIMWXkevDPcjlrFaSdhnETGURuCVf)
    wxIMWXkevDPcjlrFaSdhnETGURuCVz=urllib.parse.quote(wxIMWXkevDPcjlrFaSdhnETGURuCVz)
    wxIMWXkevDPcjlrFaSdhnETGURuCVK='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(wxIMWXkevDPcjlrFaSdhnETGURuCVz)
    wxIMWXkevDPcjlrFaSdhnETGURuCVg=[('(통합) 찜 영상에 추가',wxIMWXkevDPcjlrFaSdhnETGURuCVK)]
   else:
    wxIMWXkevDPcjlrFaSdhnETGURuCVg=wxIMWXkevDPcjlrFaSdhnETGURuCBK
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.add_dir(wxIMWXkevDPcjlrFaSdhnETGURuCoK,sublabel='',img=wxIMWXkevDPcjlrFaSdhnETGURuCtL,infoLabels=wxIMWXkevDPcjlrFaSdhnETGURuCVJ,isFolder=wxIMWXkevDPcjlrFaSdhnETGURuCBp,params=wxIMWXkevDPcjlrFaSdhnETGURuCos,ContextMenu=wxIMWXkevDPcjlrFaSdhnETGURuCVg)
  if wxIMWXkevDPcjlrFaSdhnETGURuCtq:
   wxIMWXkevDPcjlrFaSdhnETGURuCos={}
   wxIMWXkevDPcjlrFaSdhnETGURuCos['mode'] ='MOVIE_SUB' 
   wxIMWXkevDPcjlrFaSdhnETGURuCos['orderby']=wxIMWXkevDPcjlrFaSdhnETGURuCof
   wxIMWXkevDPcjlrFaSdhnETGURuCos['stype'] =wxIMWXkevDPcjlrFaSdhnETGURuCVB
   wxIMWXkevDPcjlrFaSdhnETGURuCos['page'] =wxIMWXkevDPcjlrFaSdhnETGURuCBs(wxIMWXkevDPcjlrFaSdhnETGURuCtK+1)
   wxIMWXkevDPcjlrFaSdhnETGURuCoK='[B]%s >>[/B]'%'다음 페이지'
   wxIMWXkevDPcjlrFaSdhnETGURuCVN=wxIMWXkevDPcjlrFaSdhnETGURuCBs(wxIMWXkevDPcjlrFaSdhnETGURuCtK+1)
   wxIMWXkevDPcjlrFaSdhnETGURuCoY=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.add_dir(wxIMWXkevDPcjlrFaSdhnETGURuCoK,sublabel=wxIMWXkevDPcjlrFaSdhnETGURuCVN,img=wxIMWXkevDPcjlrFaSdhnETGURuCoY,infoLabels=wxIMWXkevDPcjlrFaSdhnETGURuCBK,isFolder=wxIMWXkevDPcjlrFaSdhnETGURuCBq,params=wxIMWXkevDPcjlrFaSdhnETGURuCos)
  xbmcplugin.setContent(wxIMWXkevDPcjlrFaSdhnETGURuCQA._addon_handle,'movies')
  xbmcplugin.endOfDirectory(wxIMWXkevDPcjlrFaSdhnETGURuCQA._addon_handle,cacheToDisc=wxIMWXkevDPcjlrFaSdhnETGURuCBp)
 def dp_4K_Movie_List(wxIMWXkevDPcjlrFaSdhnETGURuCQA,wxIMWXkevDPcjlrFaSdhnETGURuCtz):
  wxIMWXkevDPcjlrFaSdhnETGURuCtK=wxIMWXkevDPcjlrFaSdhnETGURuCBg(wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('page'))
  wxIMWXkevDPcjlrFaSdhnETGURuCbt,wxIMWXkevDPcjlrFaSdhnETGURuCtq=wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj.Get_UHD_MovieList(wxIMWXkevDPcjlrFaSdhnETGURuCtK)
  for wxIMWXkevDPcjlrFaSdhnETGURuCbV in wxIMWXkevDPcjlrFaSdhnETGURuCbt:
   wxIMWXkevDPcjlrFaSdhnETGURuCoK =wxIMWXkevDPcjlrFaSdhnETGURuCbV.get('title')
   wxIMWXkevDPcjlrFaSdhnETGURuCtL =wxIMWXkevDPcjlrFaSdhnETGURuCbV.get('thumbnail')
   wxIMWXkevDPcjlrFaSdhnETGURuCtm =wxIMWXkevDPcjlrFaSdhnETGURuCbV.get('synopsis')
   wxIMWXkevDPcjlrFaSdhnETGURuCVs =wxIMWXkevDPcjlrFaSdhnETGURuCbV.get('info_title')
   wxIMWXkevDPcjlrFaSdhnETGURuCVo =wxIMWXkevDPcjlrFaSdhnETGURuCbV.get('year')
   wxIMWXkevDPcjlrFaSdhnETGURuCts =wxIMWXkevDPcjlrFaSdhnETGURuCbV.get('cast')
   wxIMWXkevDPcjlrFaSdhnETGURuCty =wxIMWXkevDPcjlrFaSdhnETGURuCbV.get('director')
   wxIMWXkevDPcjlrFaSdhnETGURuCVQ =wxIMWXkevDPcjlrFaSdhnETGURuCbV.get('info_genre')
   wxIMWXkevDPcjlrFaSdhnETGURuCbJ =wxIMWXkevDPcjlrFaSdhnETGURuCbV.get('duration')
   wxIMWXkevDPcjlrFaSdhnETGURuCVb =wxIMWXkevDPcjlrFaSdhnETGURuCbV.get('premiered')
   wxIMWXkevDPcjlrFaSdhnETGURuCbQ =wxIMWXkevDPcjlrFaSdhnETGURuCbV.get('studio')
   wxIMWXkevDPcjlrFaSdhnETGURuCVt =wxIMWXkevDPcjlrFaSdhnETGURuCbV.get('mpaa')
   wxIMWXkevDPcjlrFaSdhnETGURuCVJ={'mediatype':'movie','title':wxIMWXkevDPcjlrFaSdhnETGURuCVs,'year':wxIMWXkevDPcjlrFaSdhnETGURuCVo,'cast':wxIMWXkevDPcjlrFaSdhnETGURuCts,'director':wxIMWXkevDPcjlrFaSdhnETGURuCty,'genre':wxIMWXkevDPcjlrFaSdhnETGURuCVQ,'duration':wxIMWXkevDPcjlrFaSdhnETGURuCbJ,'premiered':wxIMWXkevDPcjlrFaSdhnETGURuCVb,'studio':wxIMWXkevDPcjlrFaSdhnETGURuCbQ,'mpaa':wxIMWXkevDPcjlrFaSdhnETGURuCVt,'plot':wxIMWXkevDPcjlrFaSdhnETGURuCtm}
   wxIMWXkevDPcjlrFaSdhnETGURuCos={'mode':'MOVIE','mediacode':wxIMWXkevDPcjlrFaSdhnETGURuCbV.get('moviecode'),'stype':'movie','title':wxIMWXkevDPcjlrFaSdhnETGURuCoK,'thumbnail':wxIMWXkevDPcjlrFaSdhnETGURuCtL}
   if wxIMWXkevDPcjlrFaSdhnETGURuCQA.get_settings_makebookmark():
    wxIMWXkevDPcjlrFaSdhnETGURuCVf={'videoid':wxIMWXkevDPcjlrFaSdhnETGURuCbV.get('moviecode'),'vidtype':'movie','vtitle':wxIMWXkevDPcjlrFaSdhnETGURuCVs,'vsubtitle':'',}
    wxIMWXkevDPcjlrFaSdhnETGURuCVz=json.dumps(wxIMWXkevDPcjlrFaSdhnETGURuCVf)
    wxIMWXkevDPcjlrFaSdhnETGURuCVz=urllib.parse.quote(wxIMWXkevDPcjlrFaSdhnETGURuCVz)
    wxIMWXkevDPcjlrFaSdhnETGURuCVK='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(wxIMWXkevDPcjlrFaSdhnETGURuCVz)
    wxIMWXkevDPcjlrFaSdhnETGURuCVg=[('(통합) 찜 영상에 추가',wxIMWXkevDPcjlrFaSdhnETGURuCVK)]
   else:
    wxIMWXkevDPcjlrFaSdhnETGURuCVg=wxIMWXkevDPcjlrFaSdhnETGURuCBK
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.add_dir(wxIMWXkevDPcjlrFaSdhnETGURuCoK,sublabel='',img=wxIMWXkevDPcjlrFaSdhnETGURuCtL,infoLabels=wxIMWXkevDPcjlrFaSdhnETGURuCVJ,isFolder=wxIMWXkevDPcjlrFaSdhnETGURuCBp,params=wxIMWXkevDPcjlrFaSdhnETGURuCos,ContextMenu=wxIMWXkevDPcjlrFaSdhnETGURuCVg)
  if wxIMWXkevDPcjlrFaSdhnETGURuCtq:
   wxIMWXkevDPcjlrFaSdhnETGURuCos={}
   wxIMWXkevDPcjlrFaSdhnETGURuCos['mode'] ='4K_MOVIE' 
   wxIMWXkevDPcjlrFaSdhnETGURuCos['page'] =wxIMWXkevDPcjlrFaSdhnETGURuCBs(wxIMWXkevDPcjlrFaSdhnETGURuCtK+1)
   wxIMWXkevDPcjlrFaSdhnETGURuCoK='[B]%s >>[/B]'%'다음 페이지'
   wxIMWXkevDPcjlrFaSdhnETGURuCVN=wxIMWXkevDPcjlrFaSdhnETGURuCBs(wxIMWXkevDPcjlrFaSdhnETGURuCtK+1)
   wxIMWXkevDPcjlrFaSdhnETGURuCoY=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.add_dir(wxIMWXkevDPcjlrFaSdhnETGURuCoK,sublabel=wxIMWXkevDPcjlrFaSdhnETGURuCVN,img=wxIMWXkevDPcjlrFaSdhnETGURuCoY,infoLabels=wxIMWXkevDPcjlrFaSdhnETGURuCBK,isFolder=wxIMWXkevDPcjlrFaSdhnETGURuCBq,params=wxIMWXkevDPcjlrFaSdhnETGURuCos)
  xbmcplugin.setContent(wxIMWXkevDPcjlrFaSdhnETGURuCQA._addon_handle,'movies')
  xbmcplugin.endOfDirectory(wxIMWXkevDPcjlrFaSdhnETGURuCQA._addon_handle,cacheToDisc=wxIMWXkevDPcjlrFaSdhnETGURuCBp)
 def dp_Set_Bookmark(wxIMWXkevDPcjlrFaSdhnETGURuCQA,wxIMWXkevDPcjlrFaSdhnETGURuCtz):
  wxIMWXkevDPcjlrFaSdhnETGURuCbN=urllib.parse.unquote(wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('bm_param'))
  wxIMWXkevDPcjlrFaSdhnETGURuCbN=json.loads(wxIMWXkevDPcjlrFaSdhnETGURuCbN)
  wxIMWXkevDPcjlrFaSdhnETGURuCbB =wxIMWXkevDPcjlrFaSdhnETGURuCbN.get('videoid')
  wxIMWXkevDPcjlrFaSdhnETGURuCbH =wxIMWXkevDPcjlrFaSdhnETGURuCbN.get('vidtype')
  wxIMWXkevDPcjlrFaSdhnETGURuCbi =wxIMWXkevDPcjlrFaSdhnETGURuCbN.get('vtitle')
  wxIMWXkevDPcjlrFaSdhnETGURuCbO =wxIMWXkevDPcjlrFaSdhnETGURuCbN.get('vsubtitle')
  wxIMWXkevDPcjlrFaSdhnETGURuCQq=xbmcgui.Dialog()
  wxIMWXkevDPcjlrFaSdhnETGURuCtB=wxIMWXkevDPcjlrFaSdhnETGURuCQq.yesno(__language__(30913).encode('utf8'),wxIMWXkevDPcjlrFaSdhnETGURuCbi+' \n\n'+__language__(30914))
  if wxIMWXkevDPcjlrFaSdhnETGURuCtB==wxIMWXkevDPcjlrFaSdhnETGURuCBp:return
  wxIMWXkevDPcjlrFaSdhnETGURuCbA=wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj.GetBookmarkInfo(wxIMWXkevDPcjlrFaSdhnETGURuCbB,wxIMWXkevDPcjlrFaSdhnETGURuCbH)
  if wxIMWXkevDPcjlrFaSdhnETGURuCbO!='':
   wxIMWXkevDPcjlrFaSdhnETGURuCbA['saveinfo']['subtitle']=wxIMWXkevDPcjlrFaSdhnETGURuCbO 
   if wxIMWXkevDPcjlrFaSdhnETGURuCbH=='tvshow':wxIMWXkevDPcjlrFaSdhnETGURuCbA['saveinfo']['infoLabels']['studio']=wxIMWXkevDPcjlrFaSdhnETGURuCbO 
  wxIMWXkevDPcjlrFaSdhnETGURuCbf=json.dumps(wxIMWXkevDPcjlrFaSdhnETGURuCbA)
  wxIMWXkevDPcjlrFaSdhnETGURuCbf=urllib.parse.quote(wxIMWXkevDPcjlrFaSdhnETGURuCbf)
  wxIMWXkevDPcjlrFaSdhnETGURuCVK ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(wxIMWXkevDPcjlrFaSdhnETGURuCbf)
  xbmc.executebuiltin(wxIMWXkevDPcjlrFaSdhnETGURuCVK)
 def dp_Search_Group(wxIMWXkevDPcjlrFaSdhnETGURuCQA,wxIMWXkevDPcjlrFaSdhnETGURuCtz):
  if 'search_key' in wxIMWXkevDPcjlrFaSdhnETGURuCtz:
   wxIMWXkevDPcjlrFaSdhnETGURuCbz=wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('search_key')
  else:
   wxIMWXkevDPcjlrFaSdhnETGURuCbz=wxIMWXkevDPcjlrFaSdhnETGURuCQA.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not wxIMWXkevDPcjlrFaSdhnETGURuCbz:
    return
  for wxIMWXkevDPcjlrFaSdhnETGURuCtf in wxIMWXkevDPcjlrFaSdhnETGURuCQJ:
   wxIMWXkevDPcjlrFaSdhnETGURuCbK =wxIMWXkevDPcjlrFaSdhnETGURuCtf.get('mode')
   wxIMWXkevDPcjlrFaSdhnETGURuCtO=wxIMWXkevDPcjlrFaSdhnETGURuCtf.get('stype')
   wxIMWXkevDPcjlrFaSdhnETGURuCoK=wxIMWXkevDPcjlrFaSdhnETGURuCtf.get('title')
   (wxIMWXkevDPcjlrFaSdhnETGURuCbg,wxIMWXkevDPcjlrFaSdhnETGURuCtq)=wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj.GetSearchList(wxIMWXkevDPcjlrFaSdhnETGURuCbz,1,wxIMWXkevDPcjlrFaSdhnETGURuCtO)
   wxIMWXkevDPcjlrFaSdhnETGURuCbq={'plot':'검색어 : '+wxIMWXkevDPcjlrFaSdhnETGURuCbz+'\n\n'+wxIMWXkevDPcjlrFaSdhnETGURuCQA.Search_FreeList(wxIMWXkevDPcjlrFaSdhnETGURuCbg)}
   wxIMWXkevDPcjlrFaSdhnETGURuCos={'mode':wxIMWXkevDPcjlrFaSdhnETGURuCbK,'stype':wxIMWXkevDPcjlrFaSdhnETGURuCtO,'search_key':wxIMWXkevDPcjlrFaSdhnETGURuCbz,'page':'1',}
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.add_dir(wxIMWXkevDPcjlrFaSdhnETGURuCoK,sublabel='',img='',infoLabels=wxIMWXkevDPcjlrFaSdhnETGURuCbq,isFolder=wxIMWXkevDPcjlrFaSdhnETGURuCBq,params=wxIMWXkevDPcjlrFaSdhnETGURuCos)
  if wxIMWXkevDPcjlrFaSdhnETGURuCBY(wxIMWXkevDPcjlrFaSdhnETGURuCQJ)>0:xbmcplugin.endOfDirectory(wxIMWXkevDPcjlrFaSdhnETGURuCQA._addon_handle,cacheToDisc=wxIMWXkevDPcjlrFaSdhnETGURuCBq)
  wxIMWXkevDPcjlrFaSdhnETGURuCQA.Save_Searched_List(wxIMWXkevDPcjlrFaSdhnETGURuCbz)
 def Search_FreeList(wxIMWXkevDPcjlrFaSdhnETGURuCQA,wxIMWXkevDPcjlrFaSdhnETGURuCJt):
  wxIMWXkevDPcjlrFaSdhnETGURuCbp=''
  wxIMWXkevDPcjlrFaSdhnETGURuCbL=7
  try:
   if wxIMWXkevDPcjlrFaSdhnETGURuCBY(wxIMWXkevDPcjlrFaSdhnETGURuCJt)==0:return '검색결과 없음'
   for i in wxIMWXkevDPcjlrFaSdhnETGURuCBy(wxIMWXkevDPcjlrFaSdhnETGURuCBY(wxIMWXkevDPcjlrFaSdhnETGURuCJt)):
    if i>=wxIMWXkevDPcjlrFaSdhnETGURuCbL:
     wxIMWXkevDPcjlrFaSdhnETGURuCbp=wxIMWXkevDPcjlrFaSdhnETGURuCbp+'...'
     break
    wxIMWXkevDPcjlrFaSdhnETGURuCbp=wxIMWXkevDPcjlrFaSdhnETGURuCbp+wxIMWXkevDPcjlrFaSdhnETGURuCJt[i]['title']+'\n'
  except:
   return ''
  return wxIMWXkevDPcjlrFaSdhnETGURuCbp
 def dp_Search_History(wxIMWXkevDPcjlrFaSdhnETGURuCQA,wxIMWXkevDPcjlrFaSdhnETGURuCtz):
  wxIMWXkevDPcjlrFaSdhnETGURuCbm=wxIMWXkevDPcjlrFaSdhnETGURuCQA.Load_List_File('search')
  for wxIMWXkevDPcjlrFaSdhnETGURuCbY in wxIMWXkevDPcjlrFaSdhnETGURuCbm:
   wxIMWXkevDPcjlrFaSdhnETGURuCbs=wxIMWXkevDPcjlrFaSdhnETGURuCBm(urllib.parse.parse_qsl(wxIMWXkevDPcjlrFaSdhnETGURuCbY))
   wxIMWXkevDPcjlrFaSdhnETGURuCby=wxIMWXkevDPcjlrFaSdhnETGURuCbs.get('skey').strip()
   wxIMWXkevDPcjlrFaSdhnETGURuCos={'mode':'SEARCH_GROUP','search_key':wxIMWXkevDPcjlrFaSdhnETGURuCby,}
   wxIMWXkevDPcjlrFaSdhnETGURuCJQ={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':wxIMWXkevDPcjlrFaSdhnETGURuCby,'vType':'-',}
   wxIMWXkevDPcjlrFaSdhnETGURuCJo=urllib.parse.urlencode(wxIMWXkevDPcjlrFaSdhnETGURuCJQ)
   wxIMWXkevDPcjlrFaSdhnETGURuCVg=[('선택된 검색어 ( %s ) 삭제'%(wxIMWXkevDPcjlrFaSdhnETGURuCby),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(wxIMWXkevDPcjlrFaSdhnETGURuCJo))]
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.add_dir(wxIMWXkevDPcjlrFaSdhnETGURuCby,sublabel='',img=wxIMWXkevDPcjlrFaSdhnETGURuCBK,infoLabels=wxIMWXkevDPcjlrFaSdhnETGURuCBK,isFolder=wxIMWXkevDPcjlrFaSdhnETGURuCBq,params=wxIMWXkevDPcjlrFaSdhnETGURuCos,ContextMenu=wxIMWXkevDPcjlrFaSdhnETGURuCVg)
  wxIMWXkevDPcjlrFaSdhnETGURuCVJ={'plot':'검색목록 전체를 삭제합니다.'}
  wxIMWXkevDPcjlrFaSdhnETGURuCoK='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  wxIMWXkevDPcjlrFaSdhnETGURuCos={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  wxIMWXkevDPcjlrFaSdhnETGURuCoY=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  wxIMWXkevDPcjlrFaSdhnETGURuCQA.add_dir(wxIMWXkevDPcjlrFaSdhnETGURuCoK,sublabel='',img=wxIMWXkevDPcjlrFaSdhnETGURuCoY,infoLabels=wxIMWXkevDPcjlrFaSdhnETGURuCVJ,isFolder=wxIMWXkevDPcjlrFaSdhnETGURuCBp,params=wxIMWXkevDPcjlrFaSdhnETGURuCos,isLink=wxIMWXkevDPcjlrFaSdhnETGURuCBq)
  xbmcplugin.endOfDirectory(wxIMWXkevDPcjlrFaSdhnETGURuCQA._addon_handle,cacheToDisc=wxIMWXkevDPcjlrFaSdhnETGURuCBp)
 def dp_Search_List(wxIMWXkevDPcjlrFaSdhnETGURuCQA,wxIMWXkevDPcjlrFaSdhnETGURuCtz):
  wxIMWXkevDPcjlrFaSdhnETGURuCtK =wxIMWXkevDPcjlrFaSdhnETGURuCBg(wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('page'))
  wxIMWXkevDPcjlrFaSdhnETGURuCtO =wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('stype')
  if 'search_key' in wxIMWXkevDPcjlrFaSdhnETGURuCtz:
   wxIMWXkevDPcjlrFaSdhnETGURuCbz=wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('search_key')
  else:
   wxIMWXkevDPcjlrFaSdhnETGURuCbz=wxIMWXkevDPcjlrFaSdhnETGURuCQA.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not wxIMWXkevDPcjlrFaSdhnETGURuCbz:
    xbmcplugin.endOfDirectory(wxIMWXkevDPcjlrFaSdhnETGURuCQA._addon_handle)
    return
  wxIMWXkevDPcjlrFaSdhnETGURuCbg,wxIMWXkevDPcjlrFaSdhnETGURuCtq=wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj.GetSearchList(wxIMWXkevDPcjlrFaSdhnETGURuCbz,wxIMWXkevDPcjlrFaSdhnETGURuCtK,wxIMWXkevDPcjlrFaSdhnETGURuCtO)
  for wxIMWXkevDPcjlrFaSdhnETGURuCJt in wxIMWXkevDPcjlrFaSdhnETGURuCbg:
   wxIMWXkevDPcjlrFaSdhnETGURuCoK =wxIMWXkevDPcjlrFaSdhnETGURuCJt.get('title')
   wxIMWXkevDPcjlrFaSdhnETGURuCtL =wxIMWXkevDPcjlrFaSdhnETGURuCJt.get('thumbnail')
   wxIMWXkevDPcjlrFaSdhnETGURuCtm =wxIMWXkevDPcjlrFaSdhnETGURuCJt.get('synopsis')
   wxIMWXkevDPcjlrFaSdhnETGURuCJV =wxIMWXkevDPcjlrFaSdhnETGURuCJt.get('program')
   wxIMWXkevDPcjlrFaSdhnETGURuCts =wxIMWXkevDPcjlrFaSdhnETGURuCJt.get('cast')
   wxIMWXkevDPcjlrFaSdhnETGURuCty =wxIMWXkevDPcjlrFaSdhnETGURuCJt.get('director')
   wxIMWXkevDPcjlrFaSdhnETGURuCVQ=wxIMWXkevDPcjlrFaSdhnETGURuCJt.get('info_genre')
   wxIMWXkevDPcjlrFaSdhnETGURuCbJ =wxIMWXkevDPcjlrFaSdhnETGURuCJt.get('duration')
   wxIMWXkevDPcjlrFaSdhnETGURuCVt =wxIMWXkevDPcjlrFaSdhnETGURuCJt.get('mpaa')
   wxIMWXkevDPcjlrFaSdhnETGURuCVo =wxIMWXkevDPcjlrFaSdhnETGURuCJt.get('year')
   wxIMWXkevDPcjlrFaSdhnETGURuCVy =wxIMWXkevDPcjlrFaSdhnETGURuCJt.get('aired')
   wxIMWXkevDPcjlrFaSdhnETGURuCVJ={'mediatype':'tvshow' if wxIMWXkevDPcjlrFaSdhnETGURuCtO=='vod' else 'movie','title':wxIMWXkevDPcjlrFaSdhnETGURuCoK,'cast':wxIMWXkevDPcjlrFaSdhnETGURuCts,'director':wxIMWXkevDPcjlrFaSdhnETGURuCty,'genre':wxIMWXkevDPcjlrFaSdhnETGURuCVQ,'duration':wxIMWXkevDPcjlrFaSdhnETGURuCbJ,'mpaa':wxIMWXkevDPcjlrFaSdhnETGURuCVt,'year':wxIMWXkevDPcjlrFaSdhnETGURuCVo,'aired':wxIMWXkevDPcjlrFaSdhnETGURuCVy,'plot':'%s\n\n%s'%(wxIMWXkevDPcjlrFaSdhnETGURuCoK,wxIMWXkevDPcjlrFaSdhnETGURuCtm)}
   if wxIMWXkevDPcjlrFaSdhnETGURuCtO=='vod':
    wxIMWXkevDPcjlrFaSdhnETGURuCbB=wxIMWXkevDPcjlrFaSdhnETGURuCJt.get('program')
    wxIMWXkevDPcjlrFaSdhnETGURuCbH='tvshow'
    wxIMWXkevDPcjlrFaSdhnETGURuCos={'mode':'EPISODE','programcode':wxIMWXkevDPcjlrFaSdhnETGURuCbB,'page':'1',}
    wxIMWXkevDPcjlrFaSdhnETGURuCoy=wxIMWXkevDPcjlrFaSdhnETGURuCBq
   else:
    wxIMWXkevDPcjlrFaSdhnETGURuCbB=wxIMWXkevDPcjlrFaSdhnETGURuCJt.get('movie')
    wxIMWXkevDPcjlrFaSdhnETGURuCbH='movie'
    wxIMWXkevDPcjlrFaSdhnETGURuCos={'mode':'MOVIE','mediacode':wxIMWXkevDPcjlrFaSdhnETGURuCbB,'stype':'movie','title':wxIMWXkevDPcjlrFaSdhnETGURuCoK,'thumbnail':wxIMWXkevDPcjlrFaSdhnETGURuCtL,}
    wxIMWXkevDPcjlrFaSdhnETGURuCoy=wxIMWXkevDPcjlrFaSdhnETGURuCBp
   if wxIMWXkevDPcjlrFaSdhnETGURuCQA.get_settings_makebookmark():
    wxIMWXkevDPcjlrFaSdhnETGURuCVf={'videoid':wxIMWXkevDPcjlrFaSdhnETGURuCbB,'vidtype':wxIMWXkevDPcjlrFaSdhnETGURuCbH,'vtitle':wxIMWXkevDPcjlrFaSdhnETGURuCoK,'vsubtitle':'',}
    wxIMWXkevDPcjlrFaSdhnETGURuCVz=json.dumps(wxIMWXkevDPcjlrFaSdhnETGURuCVf)
    wxIMWXkevDPcjlrFaSdhnETGURuCVz=urllib.parse.quote(wxIMWXkevDPcjlrFaSdhnETGURuCVz)
    wxIMWXkevDPcjlrFaSdhnETGURuCVK='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(wxIMWXkevDPcjlrFaSdhnETGURuCVz)
    wxIMWXkevDPcjlrFaSdhnETGURuCVg=[('(통합) 찜 영상에 추가',wxIMWXkevDPcjlrFaSdhnETGURuCVK)]
   else:
    wxIMWXkevDPcjlrFaSdhnETGURuCVg=wxIMWXkevDPcjlrFaSdhnETGURuCBK
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.add_dir(wxIMWXkevDPcjlrFaSdhnETGURuCoK,sublabel='',img=wxIMWXkevDPcjlrFaSdhnETGURuCtL,infoLabels=wxIMWXkevDPcjlrFaSdhnETGURuCVJ,isFolder=wxIMWXkevDPcjlrFaSdhnETGURuCoy,params=wxIMWXkevDPcjlrFaSdhnETGURuCos,isLink=wxIMWXkevDPcjlrFaSdhnETGURuCBp,ContextMenu=wxIMWXkevDPcjlrFaSdhnETGURuCVg)
  if wxIMWXkevDPcjlrFaSdhnETGURuCtq:
   wxIMWXkevDPcjlrFaSdhnETGURuCos['mode'] ='SEARCH' 
   wxIMWXkevDPcjlrFaSdhnETGURuCos['search_key']=wxIMWXkevDPcjlrFaSdhnETGURuCbz
   wxIMWXkevDPcjlrFaSdhnETGURuCos['page'] =wxIMWXkevDPcjlrFaSdhnETGURuCBs(wxIMWXkevDPcjlrFaSdhnETGURuCtK+1)
   wxIMWXkevDPcjlrFaSdhnETGURuCoK='[B]%s >>[/B]'%'다음 페이지'
   wxIMWXkevDPcjlrFaSdhnETGURuCVN=wxIMWXkevDPcjlrFaSdhnETGURuCBs(wxIMWXkevDPcjlrFaSdhnETGURuCtK+1)
   wxIMWXkevDPcjlrFaSdhnETGURuCoY=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.add_dir(wxIMWXkevDPcjlrFaSdhnETGURuCoK,sublabel=wxIMWXkevDPcjlrFaSdhnETGURuCVN,img=wxIMWXkevDPcjlrFaSdhnETGURuCoY,infoLabels=wxIMWXkevDPcjlrFaSdhnETGURuCBK,isFolder=wxIMWXkevDPcjlrFaSdhnETGURuCBq,params=wxIMWXkevDPcjlrFaSdhnETGURuCos)
  if wxIMWXkevDPcjlrFaSdhnETGURuCtO=='movie':xbmcplugin.setContent(wxIMWXkevDPcjlrFaSdhnETGURuCQA._addon_handle,'movies')
  else:xbmcplugin.setContent(wxIMWXkevDPcjlrFaSdhnETGURuCQA._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(wxIMWXkevDPcjlrFaSdhnETGURuCQA._addon_handle,cacheToDisc=wxIMWXkevDPcjlrFaSdhnETGURuCBp)
 def dp_History_Remove(wxIMWXkevDPcjlrFaSdhnETGURuCQA,wxIMWXkevDPcjlrFaSdhnETGURuCtz):
  wxIMWXkevDPcjlrFaSdhnETGURuCJb=wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('delType')
  wxIMWXkevDPcjlrFaSdhnETGURuCJN =wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('sKey')
  wxIMWXkevDPcjlrFaSdhnETGURuCJB =wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('vType')
  wxIMWXkevDPcjlrFaSdhnETGURuCQq=xbmcgui.Dialog()
  if wxIMWXkevDPcjlrFaSdhnETGURuCJb=='SEARCH_ALL':
   wxIMWXkevDPcjlrFaSdhnETGURuCtB=wxIMWXkevDPcjlrFaSdhnETGURuCQq.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif wxIMWXkevDPcjlrFaSdhnETGURuCJb=='SEARCH_ONE':
   wxIMWXkevDPcjlrFaSdhnETGURuCtB=wxIMWXkevDPcjlrFaSdhnETGURuCQq.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif wxIMWXkevDPcjlrFaSdhnETGURuCJb=='WATCH_ALL':
   wxIMWXkevDPcjlrFaSdhnETGURuCtB=wxIMWXkevDPcjlrFaSdhnETGURuCQq.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif wxIMWXkevDPcjlrFaSdhnETGURuCJb=='WATCH_ONE':
   wxIMWXkevDPcjlrFaSdhnETGURuCtB=wxIMWXkevDPcjlrFaSdhnETGURuCQq.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if wxIMWXkevDPcjlrFaSdhnETGURuCtB==wxIMWXkevDPcjlrFaSdhnETGURuCBp:sys.exit()
  if wxIMWXkevDPcjlrFaSdhnETGURuCJb=='SEARCH_ALL':
   if os.path.isfile(wxIMWXkevDPcjlrFaSdhnETGURuCQO):os.remove(wxIMWXkevDPcjlrFaSdhnETGURuCQO)
  elif wxIMWXkevDPcjlrFaSdhnETGURuCJb=='SEARCH_ONE':
   try:
    wxIMWXkevDPcjlrFaSdhnETGURuCJH=wxIMWXkevDPcjlrFaSdhnETGURuCQO
    wxIMWXkevDPcjlrFaSdhnETGURuCJi=wxIMWXkevDPcjlrFaSdhnETGURuCQA.Load_List_File('search') 
    fp=wxIMWXkevDPcjlrFaSdhnETGURuCHQ(wxIMWXkevDPcjlrFaSdhnETGURuCJH,'w',-1,'utf-8')
    for wxIMWXkevDPcjlrFaSdhnETGURuCJO in wxIMWXkevDPcjlrFaSdhnETGURuCJi:
     wxIMWXkevDPcjlrFaSdhnETGURuCJA=wxIMWXkevDPcjlrFaSdhnETGURuCBm(urllib.parse.parse_qsl(wxIMWXkevDPcjlrFaSdhnETGURuCJO))
     wxIMWXkevDPcjlrFaSdhnETGURuCJf=wxIMWXkevDPcjlrFaSdhnETGURuCJA.get('skey').strip()
     if wxIMWXkevDPcjlrFaSdhnETGURuCJN!=wxIMWXkevDPcjlrFaSdhnETGURuCJf:
      fp.write(wxIMWXkevDPcjlrFaSdhnETGURuCJO)
    fp.close()
   except:
    wxIMWXkevDPcjlrFaSdhnETGURuCBK
  elif wxIMWXkevDPcjlrFaSdhnETGURuCJb=='WATCH_ALL':
   wxIMWXkevDPcjlrFaSdhnETGURuCJH=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%wxIMWXkevDPcjlrFaSdhnETGURuCJB))
   if os.path.isfile(wxIMWXkevDPcjlrFaSdhnETGURuCJH):os.remove(wxIMWXkevDPcjlrFaSdhnETGURuCJH)
  elif wxIMWXkevDPcjlrFaSdhnETGURuCJb=='WATCH_ONE':
   wxIMWXkevDPcjlrFaSdhnETGURuCJH=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%wxIMWXkevDPcjlrFaSdhnETGURuCJB))
   try:
    wxIMWXkevDPcjlrFaSdhnETGURuCJi=wxIMWXkevDPcjlrFaSdhnETGURuCQA.Load_List_File(wxIMWXkevDPcjlrFaSdhnETGURuCJB) 
    fp=wxIMWXkevDPcjlrFaSdhnETGURuCHQ(wxIMWXkevDPcjlrFaSdhnETGURuCJH,'w',-1,'utf-8')
    for wxIMWXkevDPcjlrFaSdhnETGURuCJO in wxIMWXkevDPcjlrFaSdhnETGURuCJi:
     wxIMWXkevDPcjlrFaSdhnETGURuCJA=wxIMWXkevDPcjlrFaSdhnETGURuCBm(urllib.parse.parse_qsl(wxIMWXkevDPcjlrFaSdhnETGURuCJO))
     wxIMWXkevDPcjlrFaSdhnETGURuCJf=wxIMWXkevDPcjlrFaSdhnETGURuCJA.get('code').strip()
     if wxIMWXkevDPcjlrFaSdhnETGURuCJN!=wxIMWXkevDPcjlrFaSdhnETGURuCJf:
      fp.write(wxIMWXkevDPcjlrFaSdhnETGURuCJO)
    fp.close()
   except:
    wxIMWXkevDPcjlrFaSdhnETGURuCBK
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(wxIMWXkevDPcjlrFaSdhnETGURuCQA,wxIMWXkevDPcjlrFaSdhnETGURuCtO): 
  try:
   if wxIMWXkevDPcjlrFaSdhnETGURuCtO=='search':
    wxIMWXkevDPcjlrFaSdhnETGURuCJH=wxIMWXkevDPcjlrFaSdhnETGURuCQO
   elif wxIMWXkevDPcjlrFaSdhnETGURuCtO in['vod','movie']:
    wxIMWXkevDPcjlrFaSdhnETGURuCJH=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%wxIMWXkevDPcjlrFaSdhnETGURuCtO))
   else:
    return[]
   fp=wxIMWXkevDPcjlrFaSdhnETGURuCHQ(wxIMWXkevDPcjlrFaSdhnETGURuCJH,'r',-1,'utf-8')
   wxIMWXkevDPcjlrFaSdhnETGURuCJz=fp.readlines()
   fp.close()
  except:
   wxIMWXkevDPcjlrFaSdhnETGURuCJz=[]
  return wxIMWXkevDPcjlrFaSdhnETGURuCJz
 def Save_Watched_List(wxIMWXkevDPcjlrFaSdhnETGURuCQA,wxIMWXkevDPcjlrFaSdhnETGURuCtO,wxIMWXkevDPcjlrFaSdhnETGURuCQK):
  try:
   wxIMWXkevDPcjlrFaSdhnETGURuCJK=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%wxIMWXkevDPcjlrFaSdhnETGURuCtO))
   wxIMWXkevDPcjlrFaSdhnETGURuCJi=wxIMWXkevDPcjlrFaSdhnETGURuCQA.Load_List_File(wxIMWXkevDPcjlrFaSdhnETGURuCtO) 
   fp=wxIMWXkevDPcjlrFaSdhnETGURuCHQ(wxIMWXkevDPcjlrFaSdhnETGURuCJK,'w',-1,'utf-8')
   wxIMWXkevDPcjlrFaSdhnETGURuCJg=urllib.parse.urlencode(wxIMWXkevDPcjlrFaSdhnETGURuCQK)
   wxIMWXkevDPcjlrFaSdhnETGURuCJg=wxIMWXkevDPcjlrFaSdhnETGURuCJg+'\n'
   fp.write(wxIMWXkevDPcjlrFaSdhnETGURuCJg)
   wxIMWXkevDPcjlrFaSdhnETGURuCJq=0
   for wxIMWXkevDPcjlrFaSdhnETGURuCJO in wxIMWXkevDPcjlrFaSdhnETGURuCJi:
    wxIMWXkevDPcjlrFaSdhnETGURuCJA=wxIMWXkevDPcjlrFaSdhnETGURuCBm(urllib.parse.parse_qsl(wxIMWXkevDPcjlrFaSdhnETGURuCJO))
    wxIMWXkevDPcjlrFaSdhnETGURuCJp=wxIMWXkevDPcjlrFaSdhnETGURuCQK.get('code').strip()
    wxIMWXkevDPcjlrFaSdhnETGURuCJL=wxIMWXkevDPcjlrFaSdhnETGURuCJA.get('code').strip()
    if wxIMWXkevDPcjlrFaSdhnETGURuCtO=='vod' and wxIMWXkevDPcjlrFaSdhnETGURuCQA.get_settings_direct_replay()==wxIMWXkevDPcjlrFaSdhnETGURuCBq:
     wxIMWXkevDPcjlrFaSdhnETGURuCJp=wxIMWXkevDPcjlrFaSdhnETGURuCQK.get('videoid').strip()
     wxIMWXkevDPcjlrFaSdhnETGURuCJL=wxIMWXkevDPcjlrFaSdhnETGURuCJA.get('videoid').strip()if wxIMWXkevDPcjlrFaSdhnETGURuCJL!=wxIMWXkevDPcjlrFaSdhnETGURuCBK else '-'
    if wxIMWXkevDPcjlrFaSdhnETGURuCJp!=wxIMWXkevDPcjlrFaSdhnETGURuCJL:
     fp.write(wxIMWXkevDPcjlrFaSdhnETGURuCJO)
     wxIMWXkevDPcjlrFaSdhnETGURuCJq+=1
     if wxIMWXkevDPcjlrFaSdhnETGURuCJq>=50:break
   fp.close()
  except:
   wxIMWXkevDPcjlrFaSdhnETGURuCBK
 def dp_Watch_List(wxIMWXkevDPcjlrFaSdhnETGURuCQA,wxIMWXkevDPcjlrFaSdhnETGURuCtz):
  wxIMWXkevDPcjlrFaSdhnETGURuCtO =wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('stype')
  wxIMWXkevDPcjlrFaSdhnETGURuCoO=wxIMWXkevDPcjlrFaSdhnETGURuCQA.get_settings_direct_replay()
  if wxIMWXkevDPcjlrFaSdhnETGURuCtO=='-':
   for wxIMWXkevDPcjlrFaSdhnETGURuCtf in wxIMWXkevDPcjlrFaSdhnETGURuCQb:
    wxIMWXkevDPcjlrFaSdhnETGURuCoK=wxIMWXkevDPcjlrFaSdhnETGURuCtf.get('title')
    wxIMWXkevDPcjlrFaSdhnETGURuCos={'mode':wxIMWXkevDPcjlrFaSdhnETGURuCtf.get('mode'),'stype':wxIMWXkevDPcjlrFaSdhnETGURuCtf.get('stype')}
    wxIMWXkevDPcjlrFaSdhnETGURuCQA.add_dir(wxIMWXkevDPcjlrFaSdhnETGURuCoK,sublabel='',img='',infoLabels=wxIMWXkevDPcjlrFaSdhnETGURuCBK,isFolder=wxIMWXkevDPcjlrFaSdhnETGURuCBq,params=wxIMWXkevDPcjlrFaSdhnETGURuCos)
   if wxIMWXkevDPcjlrFaSdhnETGURuCBY(wxIMWXkevDPcjlrFaSdhnETGURuCQb)>0:xbmcplugin.endOfDirectory(wxIMWXkevDPcjlrFaSdhnETGURuCQA._addon_handle)
  else:
   wxIMWXkevDPcjlrFaSdhnETGURuCJm=wxIMWXkevDPcjlrFaSdhnETGURuCQA.Load_List_File(wxIMWXkevDPcjlrFaSdhnETGURuCtO)
   for wxIMWXkevDPcjlrFaSdhnETGURuCJY in wxIMWXkevDPcjlrFaSdhnETGURuCJm:
    wxIMWXkevDPcjlrFaSdhnETGURuCbs=wxIMWXkevDPcjlrFaSdhnETGURuCBm(urllib.parse.parse_qsl(wxIMWXkevDPcjlrFaSdhnETGURuCJY))
    wxIMWXkevDPcjlrFaSdhnETGURuCJs =wxIMWXkevDPcjlrFaSdhnETGURuCbs.get('code').strip()
    wxIMWXkevDPcjlrFaSdhnETGURuCoK =wxIMWXkevDPcjlrFaSdhnETGURuCbs.get('title').strip()
    wxIMWXkevDPcjlrFaSdhnETGURuCtL=wxIMWXkevDPcjlrFaSdhnETGURuCbs.get('img').strip()
    wxIMWXkevDPcjlrFaSdhnETGURuCbB =wxIMWXkevDPcjlrFaSdhnETGURuCbs.get('videoid').strip()
    try:
     wxIMWXkevDPcjlrFaSdhnETGURuCtL=wxIMWXkevDPcjlrFaSdhnETGURuCtL.replace('\'','\"')
     wxIMWXkevDPcjlrFaSdhnETGURuCtL=json.loads(wxIMWXkevDPcjlrFaSdhnETGURuCtL)
    except:
     wxIMWXkevDPcjlrFaSdhnETGURuCBK
    wxIMWXkevDPcjlrFaSdhnETGURuCVJ={}
    wxIMWXkevDPcjlrFaSdhnETGURuCVJ['plot']=wxIMWXkevDPcjlrFaSdhnETGURuCoK
    if wxIMWXkevDPcjlrFaSdhnETGURuCtO=='vod':
     if wxIMWXkevDPcjlrFaSdhnETGURuCoO==wxIMWXkevDPcjlrFaSdhnETGURuCBp or wxIMWXkevDPcjlrFaSdhnETGURuCbB==wxIMWXkevDPcjlrFaSdhnETGURuCBK:
      wxIMWXkevDPcjlrFaSdhnETGURuCVJ['mediatype']='tvshow'
      wxIMWXkevDPcjlrFaSdhnETGURuCos={'mode':'EPISODE','programcode':wxIMWXkevDPcjlrFaSdhnETGURuCJs,'page':'1'}
      wxIMWXkevDPcjlrFaSdhnETGURuCoy=wxIMWXkevDPcjlrFaSdhnETGURuCBq
     else:
      wxIMWXkevDPcjlrFaSdhnETGURuCVJ['mediatype']='episode'
      wxIMWXkevDPcjlrFaSdhnETGURuCos={'mode':'VOD','mediacode':wxIMWXkevDPcjlrFaSdhnETGURuCbB,'stype':'vod','programcode':wxIMWXkevDPcjlrFaSdhnETGURuCJs,'title':wxIMWXkevDPcjlrFaSdhnETGURuCoK,'thumbnail':wxIMWXkevDPcjlrFaSdhnETGURuCtL}
      wxIMWXkevDPcjlrFaSdhnETGURuCoy=wxIMWXkevDPcjlrFaSdhnETGURuCBp
    else:
     wxIMWXkevDPcjlrFaSdhnETGURuCVJ['mediatype']='movie'
     wxIMWXkevDPcjlrFaSdhnETGURuCos={'mode':'MOVIE','mediacode':wxIMWXkevDPcjlrFaSdhnETGURuCJs,'stype':'movie','title':wxIMWXkevDPcjlrFaSdhnETGURuCoK,'thumbnail':wxIMWXkevDPcjlrFaSdhnETGURuCtL}
     wxIMWXkevDPcjlrFaSdhnETGURuCoy=wxIMWXkevDPcjlrFaSdhnETGURuCBp
    wxIMWXkevDPcjlrFaSdhnETGURuCJQ={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':wxIMWXkevDPcjlrFaSdhnETGURuCJs,'vType':wxIMWXkevDPcjlrFaSdhnETGURuCtO,}
    wxIMWXkevDPcjlrFaSdhnETGURuCJo=urllib.parse.urlencode(wxIMWXkevDPcjlrFaSdhnETGURuCJQ)
    wxIMWXkevDPcjlrFaSdhnETGURuCVg=[('선택된 시청이력 ( %s ) 삭제'%(wxIMWXkevDPcjlrFaSdhnETGURuCoK),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(wxIMWXkevDPcjlrFaSdhnETGURuCJo))]
    wxIMWXkevDPcjlrFaSdhnETGURuCQA.add_dir(wxIMWXkevDPcjlrFaSdhnETGURuCoK,sublabel='',img=wxIMWXkevDPcjlrFaSdhnETGURuCtL,infoLabels=wxIMWXkevDPcjlrFaSdhnETGURuCVJ,isFolder=wxIMWXkevDPcjlrFaSdhnETGURuCoy,params=wxIMWXkevDPcjlrFaSdhnETGURuCos,ContextMenu=wxIMWXkevDPcjlrFaSdhnETGURuCVg)
   wxIMWXkevDPcjlrFaSdhnETGURuCVJ={'plot':'시청목록을 삭제합니다.'}
   wxIMWXkevDPcjlrFaSdhnETGURuCoK='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   wxIMWXkevDPcjlrFaSdhnETGURuCos={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':wxIMWXkevDPcjlrFaSdhnETGURuCtO,}
   wxIMWXkevDPcjlrFaSdhnETGURuCoY=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.add_dir(wxIMWXkevDPcjlrFaSdhnETGURuCoK,sublabel='',img=wxIMWXkevDPcjlrFaSdhnETGURuCoY,infoLabels=wxIMWXkevDPcjlrFaSdhnETGURuCVJ,isFolder=wxIMWXkevDPcjlrFaSdhnETGURuCBp,params=wxIMWXkevDPcjlrFaSdhnETGURuCos,isLink=wxIMWXkevDPcjlrFaSdhnETGURuCBq)
   if wxIMWXkevDPcjlrFaSdhnETGURuCtO=='movie':xbmcplugin.setContent(wxIMWXkevDPcjlrFaSdhnETGURuCQA._addon_handle,'movies')
   else:xbmcplugin.setContent(wxIMWXkevDPcjlrFaSdhnETGURuCQA._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(wxIMWXkevDPcjlrFaSdhnETGURuCQA._addon_handle,cacheToDisc=wxIMWXkevDPcjlrFaSdhnETGURuCBp)
 def Save_Searched_List(wxIMWXkevDPcjlrFaSdhnETGURuCQA,wxIMWXkevDPcjlrFaSdhnETGURuCbz):
  try:
   wxIMWXkevDPcjlrFaSdhnETGURuCJy=wxIMWXkevDPcjlrFaSdhnETGURuCQO
   wxIMWXkevDPcjlrFaSdhnETGURuCJi=wxIMWXkevDPcjlrFaSdhnETGURuCQA.Load_List_File('search') 
   wxIMWXkevDPcjlrFaSdhnETGURuCNQ={'skey':wxIMWXkevDPcjlrFaSdhnETGURuCbz.strip()}
   fp=wxIMWXkevDPcjlrFaSdhnETGURuCHQ(wxIMWXkevDPcjlrFaSdhnETGURuCJy,'w',-1,'utf-8')
   wxIMWXkevDPcjlrFaSdhnETGURuCJg=urllib.parse.urlencode(wxIMWXkevDPcjlrFaSdhnETGURuCNQ)
   wxIMWXkevDPcjlrFaSdhnETGURuCJg=wxIMWXkevDPcjlrFaSdhnETGURuCJg+'\n'
   fp.write(wxIMWXkevDPcjlrFaSdhnETGURuCJg)
   wxIMWXkevDPcjlrFaSdhnETGURuCJq=0
   for wxIMWXkevDPcjlrFaSdhnETGURuCJO in wxIMWXkevDPcjlrFaSdhnETGURuCJi:
    wxIMWXkevDPcjlrFaSdhnETGURuCJA=wxIMWXkevDPcjlrFaSdhnETGURuCBm(urllib.parse.parse_qsl(wxIMWXkevDPcjlrFaSdhnETGURuCJO))
    wxIMWXkevDPcjlrFaSdhnETGURuCJp=wxIMWXkevDPcjlrFaSdhnETGURuCNQ.get('skey').strip()
    wxIMWXkevDPcjlrFaSdhnETGURuCJL=wxIMWXkevDPcjlrFaSdhnETGURuCJA.get('skey').strip()
    if wxIMWXkevDPcjlrFaSdhnETGURuCJp!=wxIMWXkevDPcjlrFaSdhnETGURuCJL:
     fp.write(wxIMWXkevDPcjlrFaSdhnETGURuCJO)
     wxIMWXkevDPcjlrFaSdhnETGURuCJq+=1
     if wxIMWXkevDPcjlrFaSdhnETGURuCJq>=50:break
   fp.close()
  except:
   wxIMWXkevDPcjlrFaSdhnETGURuCBK
 def play_VIDEO(wxIMWXkevDPcjlrFaSdhnETGURuCQA,wxIMWXkevDPcjlrFaSdhnETGURuCtz):
  wxIMWXkevDPcjlrFaSdhnETGURuCNo =wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('mediacode')
  wxIMWXkevDPcjlrFaSdhnETGURuCtO =wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('stype')
  wxIMWXkevDPcjlrFaSdhnETGURuCNt =wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('pvrmode')
  wxIMWXkevDPcjlrFaSdhnETGURuCNV=wxIMWXkevDPcjlrFaSdhnETGURuCQA.get_selQuality(wxIMWXkevDPcjlrFaSdhnETGURuCtO)
  wxIMWXkevDPcjlrFaSdhnETGURuCQA.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(wxIMWXkevDPcjlrFaSdhnETGURuCNo,wxIMWXkevDPcjlrFaSdhnETGURuCBs(wxIMWXkevDPcjlrFaSdhnETGURuCNV),wxIMWXkevDPcjlrFaSdhnETGURuCtO,wxIMWXkevDPcjlrFaSdhnETGURuCNt))
  wxIMWXkevDPcjlrFaSdhnETGURuCNb=wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj.GetBroadURL(wxIMWXkevDPcjlrFaSdhnETGURuCNo,wxIMWXkevDPcjlrFaSdhnETGURuCNV,wxIMWXkevDPcjlrFaSdhnETGURuCtO,wxIMWXkevDPcjlrFaSdhnETGURuCNt,optUHD=wxIMWXkevDPcjlrFaSdhnETGURuCQA.get_settings_uhd())
  wxIMWXkevDPcjlrFaSdhnETGURuCQA.addon_log('qt, stype, url : %s - %s - %s'%(wxIMWXkevDPcjlrFaSdhnETGURuCBs(wxIMWXkevDPcjlrFaSdhnETGURuCNV),wxIMWXkevDPcjlrFaSdhnETGURuCtO,wxIMWXkevDPcjlrFaSdhnETGURuCNb['streaming_url']))
  if wxIMWXkevDPcjlrFaSdhnETGURuCNb['streaming_url']=='':
   if wxIMWXkevDPcjlrFaSdhnETGURuCNb['error_msg']=='':
    wxIMWXkevDPcjlrFaSdhnETGURuCQA.addon_noti(__language__(30908).encode('utf8'))
   else:
    wxIMWXkevDPcjlrFaSdhnETGURuCQA.addon_noti(wxIMWXkevDPcjlrFaSdhnETGURuCNb['error_msg'].encode('utf8'))
   return
  wxIMWXkevDPcjlrFaSdhnETGURuCNJ='user-agent={}'.format(wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj.USER_AGENT)
  if wxIMWXkevDPcjlrFaSdhnETGURuCNb['watermark'] !='':
   wxIMWXkevDPcjlrFaSdhnETGURuCNJ='{}&x-tving-param1={}&x-tving-param2={}'.format(wxIMWXkevDPcjlrFaSdhnETGURuCNJ,wxIMWXkevDPcjlrFaSdhnETGURuCNb['watermarkKey'],wxIMWXkevDPcjlrFaSdhnETGURuCNb['watermark'])
  wxIMWXkevDPcjlrFaSdhnETGURuCQA.addon_log('streaming_url = {}'.format(wxIMWXkevDPcjlrFaSdhnETGURuCNb['streaming_url']))
  wxIMWXkevDPcjlrFaSdhnETGURuCQA.addon_log('watermark     = {}'.format(wxIMWXkevDPcjlrFaSdhnETGURuCNb['watermark']))
  wxIMWXkevDPcjlrFaSdhnETGURuCQA.addon_log('watermarkKey  = {}'.format(wxIMWXkevDPcjlrFaSdhnETGURuCNb['watermarkKey']))
  wxIMWXkevDPcjlrFaSdhnETGURuCNB =wxIMWXkevDPcjlrFaSdhnETGURuCBp
  wxIMWXkevDPcjlrFaSdhnETGURuCNH =wxIMWXkevDPcjlrFaSdhnETGURuCNb['streaming_url'].find('Policy=')
  if wxIMWXkevDPcjlrFaSdhnETGURuCNH!=-1:
   wxIMWXkevDPcjlrFaSdhnETGURuCNi =wxIMWXkevDPcjlrFaSdhnETGURuCNb['streaming_url'].split('?')[0]
   wxIMWXkevDPcjlrFaSdhnETGURuCNO=wxIMWXkevDPcjlrFaSdhnETGURuCBm(urllib.parse.parse_qsl(urllib.parse.urlsplit(wxIMWXkevDPcjlrFaSdhnETGURuCNb['streaming_url']).query))
   wxIMWXkevDPcjlrFaSdhnETGURuCNA='CloudFront-Policy=%s;CloudFront-Signature=%s;CloudFront-Key-Pair-Id=%s'%(wxIMWXkevDPcjlrFaSdhnETGURuCNO['Policy'],wxIMWXkevDPcjlrFaSdhnETGURuCNO['Signature'],wxIMWXkevDPcjlrFaSdhnETGURuCNO['Key-Pair-Id'])
   if 'quickvod-mcdn.tving.com' in wxIMWXkevDPcjlrFaSdhnETGURuCNi:
    wxIMWXkevDPcjlrFaSdhnETGURuCNB=wxIMWXkevDPcjlrFaSdhnETGURuCBq
    wxIMWXkevDPcjlrFaSdhnETGURuCNf =wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    wxIMWXkevDPcjlrFaSdhnETGURuCNz=wxIMWXkevDPcjlrFaSdhnETGURuCNf.strftime('%Y-%m-%d-%H:%M:%S')
    if wxIMWXkevDPcjlrFaSdhnETGURuCBg(wxIMWXkevDPcjlrFaSdhnETGURuCNz.replace('-','').replace(':',''))<wxIMWXkevDPcjlrFaSdhnETGURuCBg(wxIMWXkevDPcjlrFaSdhnETGURuCNO['end'].replace('-','').replace(':','')):
     wxIMWXkevDPcjlrFaSdhnETGURuCNO['end']=wxIMWXkevDPcjlrFaSdhnETGURuCNz
     wxIMWXkevDPcjlrFaSdhnETGURuCQA.addon_noti(__language__(30915).encode('utf8'))
    wxIMWXkevDPcjlrFaSdhnETGURuCNi ='%s?%s'%(wxIMWXkevDPcjlrFaSdhnETGURuCNi,urllib.parse.urlencode(wxIMWXkevDPcjlrFaSdhnETGURuCNO,doseq=wxIMWXkevDPcjlrFaSdhnETGURuCBq))
    wxIMWXkevDPcjlrFaSdhnETGURuCNK='{}|{}&Cookie={}'.format(wxIMWXkevDPcjlrFaSdhnETGURuCNi,wxIMWXkevDPcjlrFaSdhnETGURuCNJ,wxIMWXkevDPcjlrFaSdhnETGURuCNA)
   else:
    wxIMWXkevDPcjlrFaSdhnETGURuCNK='{}|{}&Cookie={}'.format(wxIMWXkevDPcjlrFaSdhnETGURuCNb['streaming_url'],wxIMWXkevDPcjlrFaSdhnETGURuCNJ,wxIMWXkevDPcjlrFaSdhnETGURuCNA)
  else:
   wxIMWXkevDPcjlrFaSdhnETGURuCNK=wxIMWXkevDPcjlrFaSdhnETGURuCNb['streaming_url']+'|'+wxIMWXkevDPcjlrFaSdhnETGURuCNJ
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.addon_log('if tmp_pos == -1')
  wxIMWXkevDPcjlrFaSdhnETGURuCQA.addon_log(wxIMWXkevDPcjlrFaSdhnETGURuCNK)
  wxIMWXkevDPcjlrFaSdhnETGURuCoV,wxIMWXkevDPcjlrFaSdhnETGURuCob=wxIMWXkevDPcjlrFaSdhnETGURuCQA.get_settings_proxyport()
  wxIMWXkevDPcjlrFaSdhnETGURuCot=wxIMWXkevDPcjlrFaSdhnETGURuCQA.get_settings_playback()
  if wxIMWXkevDPcjlrFaSdhnETGURuCoV and wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('mode')in['VOD','MOVIE']and wxIMWXkevDPcjlrFaSdhnETGURuCNb['drm_license']!='':
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj.Tving_Parse_mpd(wxIMWXkevDPcjlrFaSdhnETGURuCNb['streaming_url'])
   wxIMWXkevDPcjlrFaSdhnETGURuCNg={'addon':'tvingm','playOption':wxIMWXkevDPcjlrFaSdhnETGURuCot,}
   wxIMWXkevDPcjlrFaSdhnETGURuCNg=json.dumps(wxIMWXkevDPcjlrFaSdhnETGURuCNg,separators=(',',':'))
   wxIMWXkevDPcjlrFaSdhnETGURuCNg=base64.standard_b64encode(wxIMWXkevDPcjlrFaSdhnETGURuCNg.encode()).decode('utf-8')
   wxIMWXkevDPcjlrFaSdhnETGURuCNK ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(wxIMWXkevDPcjlrFaSdhnETGURuCob,wxIMWXkevDPcjlrFaSdhnETGURuCNK,wxIMWXkevDPcjlrFaSdhnETGURuCNg)
   wxIMWXkevDPcjlrFaSdhnETGURuCNJ='{}&proxy-mini={}'.format(wxIMWXkevDPcjlrFaSdhnETGURuCNJ,wxIMWXkevDPcjlrFaSdhnETGURuCNg)
  wxIMWXkevDPcjlrFaSdhnETGURuCQA.addon_log(wxIMWXkevDPcjlrFaSdhnETGURuCNK)
  wxIMWXkevDPcjlrFaSdhnETGURuCNq=xbmcgui.ListItem(path=wxIMWXkevDPcjlrFaSdhnETGURuCNK)
  if wxIMWXkevDPcjlrFaSdhnETGURuCNb['drm_license']!='':
   wxIMWXkevDPcjlrFaSdhnETGURuCNp=wxIMWXkevDPcjlrFaSdhnETGURuCNb['drm_license']
   wxIMWXkevDPcjlrFaSdhnETGURuCNL ='https://cj.drmkeyserver.com/widevine_license'
   wxIMWXkevDPcjlrFaSdhnETGURuCNm ='mpd'
   wxIMWXkevDPcjlrFaSdhnETGURuCNY ='com.widevine.alpha'
   wxIMWXkevDPcjlrFaSdhnETGURuCNs =inputstreamhelper.Helper(wxIMWXkevDPcjlrFaSdhnETGURuCNm,drm='widevine')
   if wxIMWXkevDPcjlrFaSdhnETGURuCNs.check_inputstream():
    wxIMWXkevDPcjlrFaSdhnETGURuCNy={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj.USER_AGENT,'AcquireLicenseAssertion':wxIMWXkevDPcjlrFaSdhnETGURuCNp,'Host':'cj.drmkeyserver.com',}
    wxIMWXkevDPcjlrFaSdhnETGURuCBQ=wxIMWXkevDPcjlrFaSdhnETGURuCNL+'|'+urllib.parse.urlencode(wxIMWXkevDPcjlrFaSdhnETGURuCNy)+'|R{SSM}|'
    wxIMWXkevDPcjlrFaSdhnETGURuCNq.setProperty('inputstream',wxIMWXkevDPcjlrFaSdhnETGURuCNs.inputstream_addon)
    wxIMWXkevDPcjlrFaSdhnETGURuCNq.setProperty('inputstream.adaptive.manifest_type',wxIMWXkevDPcjlrFaSdhnETGURuCNm)
    wxIMWXkevDPcjlrFaSdhnETGURuCNq.setProperty('inputstream.adaptive.license_type',wxIMWXkevDPcjlrFaSdhnETGURuCNY)
    wxIMWXkevDPcjlrFaSdhnETGURuCNq.setProperty('inputstream.adaptive.license_key',wxIMWXkevDPcjlrFaSdhnETGURuCBQ)
    wxIMWXkevDPcjlrFaSdhnETGURuCNq.setProperty('inputstream.adaptive.stream_headers',wxIMWXkevDPcjlrFaSdhnETGURuCNJ)
  elif wxIMWXkevDPcjlrFaSdhnETGURuCNB==wxIMWXkevDPcjlrFaSdhnETGURuCBq:
   wxIMWXkevDPcjlrFaSdhnETGURuCNq.setContentLookup(wxIMWXkevDPcjlrFaSdhnETGURuCBp)
   wxIMWXkevDPcjlrFaSdhnETGURuCNq.setMimeType('application/x-mpegURL')
   wxIMWXkevDPcjlrFaSdhnETGURuCNq.setProperty('inputstream','inputstream.ffmpegdirect')
   wxIMWXkevDPcjlrFaSdhnETGURuCNq.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   wxIMWXkevDPcjlrFaSdhnETGURuCNq.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   wxIMWXkevDPcjlrFaSdhnETGURuCNq.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   wxIMWXkevDPcjlrFaSdhnETGURuCNq.setProperty('ResumeTime','0')
   wxIMWXkevDPcjlrFaSdhnETGURuCNq.setProperty('TotalTime','10000')
  elif wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('mode')in['VOD','MOVIE']:
   wxIMWXkevDPcjlrFaSdhnETGURuCNq.setContentLookup(wxIMWXkevDPcjlrFaSdhnETGURuCBp)
   wxIMWXkevDPcjlrFaSdhnETGURuCNq.setMimeType('application/x-mpegURL')
   wxIMWXkevDPcjlrFaSdhnETGURuCNq.setProperty('inputstream','inputstream.adaptive')
   wxIMWXkevDPcjlrFaSdhnETGURuCNq.setProperty('inputstream.adaptive.manifest_type','hls')
  xbmcplugin.setResolvedUrl(wxIMWXkevDPcjlrFaSdhnETGURuCQA._addon_handle,wxIMWXkevDPcjlrFaSdhnETGURuCBq,wxIMWXkevDPcjlrFaSdhnETGURuCNq)
  try:
   if wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('mode')in['VOD','MOVIE']and wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('title'):
    wxIMWXkevDPcjlrFaSdhnETGURuCos={'code':wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('programcode')if wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('mode')=='VOD' else wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('mediacode'),'img':wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('thumbnail'),'title':wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('title'),'videoid':wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('mediacode')}
    wxIMWXkevDPcjlrFaSdhnETGURuCQA.Save_Watched_List(wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('stype'),wxIMWXkevDPcjlrFaSdhnETGURuCos)
  except:
   wxIMWXkevDPcjlrFaSdhnETGURuCBK
 def logout(wxIMWXkevDPcjlrFaSdhnETGURuCQA):
  wxIMWXkevDPcjlrFaSdhnETGURuCQq=xbmcgui.Dialog()
  wxIMWXkevDPcjlrFaSdhnETGURuCtB=wxIMWXkevDPcjlrFaSdhnETGURuCQq.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if wxIMWXkevDPcjlrFaSdhnETGURuCtB==wxIMWXkevDPcjlrFaSdhnETGURuCBp:sys.exit()
  wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj.Init_TV_Total()
  if os.path.isfile(wxIMWXkevDPcjlrFaSdhnETGURuCQi):os.remove(wxIMWXkevDPcjlrFaSdhnETGURuCQi)
  wxIMWXkevDPcjlrFaSdhnETGURuCQA.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(wxIMWXkevDPcjlrFaSdhnETGURuCQA):
  wxIMWXkevDPcjlrFaSdhnETGURuCBo =wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj.Get_Now_Datetime()
  wxIMWXkevDPcjlrFaSdhnETGURuCBt=wxIMWXkevDPcjlrFaSdhnETGURuCBo+datetime.timedelta(days=wxIMWXkevDPcjlrFaSdhnETGURuCBg(__addon__.getSetting('cache_ttl')))
  (wxIMWXkevDPcjlrFaSdhnETGURuCtV,wxIMWXkevDPcjlrFaSdhnETGURuCtb,wxIMWXkevDPcjlrFaSdhnETGURuCtJ,wxIMWXkevDPcjlrFaSdhnETGURuCtN)=wxIMWXkevDPcjlrFaSdhnETGURuCQA.get_settings_account()
  wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj.Save_session_acount(wxIMWXkevDPcjlrFaSdhnETGURuCtV,wxIMWXkevDPcjlrFaSdhnETGURuCtb,wxIMWXkevDPcjlrFaSdhnETGURuCtJ,wxIMWXkevDPcjlrFaSdhnETGURuCtN)
  wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj.TV['account']['token_limit']=wxIMWXkevDPcjlrFaSdhnETGURuCBt.strftime('%Y%m%d')
  wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj.JsonFile_Save(wxIMWXkevDPcjlrFaSdhnETGURuCQi,wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj.TV)
 def cookiefile_check(wxIMWXkevDPcjlrFaSdhnETGURuCQA):
  wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj.TV=wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj.JsonFile_Load(wxIMWXkevDPcjlrFaSdhnETGURuCQi)
  if 'account' not in wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj.TV:
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj.Init_TV_Total()
   return wxIMWXkevDPcjlrFaSdhnETGURuCBp
  (wxIMWXkevDPcjlrFaSdhnETGURuCBV,wxIMWXkevDPcjlrFaSdhnETGURuCBb,wxIMWXkevDPcjlrFaSdhnETGURuCBJ,wxIMWXkevDPcjlrFaSdhnETGURuCBN)=wxIMWXkevDPcjlrFaSdhnETGURuCQA.get_settings_account()
  (wxIMWXkevDPcjlrFaSdhnETGURuCBH,wxIMWXkevDPcjlrFaSdhnETGURuCBi,wxIMWXkevDPcjlrFaSdhnETGURuCBO,wxIMWXkevDPcjlrFaSdhnETGURuCBA)=wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj.Load_session_acount()
  if wxIMWXkevDPcjlrFaSdhnETGURuCBV!=wxIMWXkevDPcjlrFaSdhnETGURuCBH or wxIMWXkevDPcjlrFaSdhnETGURuCBb!=wxIMWXkevDPcjlrFaSdhnETGURuCBi or wxIMWXkevDPcjlrFaSdhnETGURuCBJ!=wxIMWXkevDPcjlrFaSdhnETGURuCBO or wxIMWXkevDPcjlrFaSdhnETGURuCBN!=wxIMWXkevDPcjlrFaSdhnETGURuCBA:
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj.Init_TV_Total()
   return wxIMWXkevDPcjlrFaSdhnETGURuCBp
  if wxIMWXkevDPcjlrFaSdhnETGURuCBg(wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>wxIMWXkevDPcjlrFaSdhnETGURuCBg(wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj.TV['account']['token_limit']):
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj.Init_TV_Total()
   return wxIMWXkevDPcjlrFaSdhnETGURuCBp
  return wxIMWXkevDPcjlrFaSdhnETGURuCBq
 def dp_Global_Search(wxIMWXkevDPcjlrFaSdhnETGURuCQA,wxIMWXkevDPcjlrFaSdhnETGURuCtz):
  wxIMWXkevDPcjlrFaSdhnETGURuCbK=wxIMWXkevDPcjlrFaSdhnETGURuCtz.get('mode')
  if wxIMWXkevDPcjlrFaSdhnETGURuCbK=='TOTAL_SEARCH':
   wxIMWXkevDPcjlrFaSdhnETGURuCBf='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   wxIMWXkevDPcjlrFaSdhnETGURuCBf='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(wxIMWXkevDPcjlrFaSdhnETGURuCBf)
 def dp_Bookmark_Menu(wxIMWXkevDPcjlrFaSdhnETGURuCQA,wxIMWXkevDPcjlrFaSdhnETGURuCtz):
  wxIMWXkevDPcjlrFaSdhnETGURuCBf='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(wxIMWXkevDPcjlrFaSdhnETGURuCBf)
 def dp_EuroLive_List(wxIMWXkevDPcjlrFaSdhnETGURuCQA,wxIMWXkevDPcjlrFaSdhnETGURuCtz):
  wxIMWXkevDPcjlrFaSdhnETGURuCtg=wxIMWXkevDPcjlrFaSdhnETGURuCQA.TvingObj.GetEuroChannelList()
  for wxIMWXkevDPcjlrFaSdhnETGURuCtp in wxIMWXkevDPcjlrFaSdhnETGURuCtg:
   wxIMWXkevDPcjlrFaSdhnETGURuCVA =wxIMWXkevDPcjlrFaSdhnETGURuCtp.get('channel')
   wxIMWXkevDPcjlrFaSdhnETGURuCoK =wxIMWXkevDPcjlrFaSdhnETGURuCtp.get('title')
   wxIMWXkevDPcjlrFaSdhnETGURuCVN =wxIMWXkevDPcjlrFaSdhnETGURuCtp.get('subtitle')
   wxIMWXkevDPcjlrFaSdhnETGURuCVJ={'mediatype':'episode','title':wxIMWXkevDPcjlrFaSdhnETGURuCoK,'plot':'%s\n%s'%(wxIMWXkevDPcjlrFaSdhnETGURuCoK,wxIMWXkevDPcjlrFaSdhnETGURuCVN)}
   wxIMWXkevDPcjlrFaSdhnETGURuCos={'mode':'LIVE','mediacode':wxIMWXkevDPcjlrFaSdhnETGURuCVA,'stype':'onair',}
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.add_dir(wxIMWXkevDPcjlrFaSdhnETGURuCoK,sublabel=wxIMWXkevDPcjlrFaSdhnETGURuCVN,img='',infoLabels=wxIMWXkevDPcjlrFaSdhnETGURuCVJ,isFolder=wxIMWXkevDPcjlrFaSdhnETGURuCBp,params=wxIMWXkevDPcjlrFaSdhnETGURuCos)
  if wxIMWXkevDPcjlrFaSdhnETGURuCBY(wxIMWXkevDPcjlrFaSdhnETGURuCtg)>0:xbmcplugin.endOfDirectory(wxIMWXkevDPcjlrFaSdhnETGURuCQA._addon_handle,cacheToDisc=wxIMWXkevDPcjlrFaSdhnETGURuCBp)
 def tving_main(wxIMWXkevDPcjlrFaSdhnETGURuCQA):
  wxIMWXkevDPcjlrFaSdhnETGURuCbK=wxIMWXkevDPcjlrFaSdhnETGURuCQA.main_params.get('mode',wxIMWXkevDPcjlrFaSdhnETGURuCBK)
  if wxIMWXkevDPcjlrFaSdhnETGURuCbK=='LOGOUT':
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.logout()
   return
  wxIMWXkevDPcjlrFaSdhnETGURuCQA.login_main()
  if wxIMWXkevDPcjlrFaSdhnETGURuCbK is wxIMWXkevDPcjlrFaSdhnETGURuCBK:
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.dp_Main_List()
  elif wxIMWXkevDPcjlrFaSdhnETGURuCbK in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.dp_Title_Group(wxIMWXkevDPcjlrFaSdhnETGURuCQA.main_params)
  elif wxIMWXkevDPcjlrFaSdhnETGURuCbK in['GLOBAL_GROUP']:
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.dp_SubTitle_Group(wxIMWXkevDPcjlrFaSdhnETGURuCQA.main_params)
  elif wxIMWXkevDPcjlrFaSdhnETGURuCbK=='CHANNEL':
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.dp_LiveChannel_List(wxIMWXkevDPcjlrFaSdhnETGURuCQA.main_params)
  elif wxIMWXkevDPcjlrFaSdhnETGURuCbK in['LIVE','VOD','MOVIE']:
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.play_VIDEO(wxIMWXkevDPcjlrFaSdhnETGURuCQA.main_params)
  elif wxIMWXkevDPcjlrFaSdhnETGURuCbK=='PROGRAM':
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.dp_Program_List(wxIMWXkevDPcjlrFaSdhnETGURuCQA.main_params)
  elif wxIMWXkevDPcjlrFaSdhnETGURuCbK=='4K_PROGRAM':
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.dp_4K_Program_List(wxIMWXkevDPcjlrFaSdhnETGURuCQA.main_params)
  elif wxIMWXkevDPcjlrFaSdhnETGURuCbK=='ORI_PROGRAM':
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.dp_Ori_Program_List(wxIMWXkevDPcjlrFaSdhnETGURuCQA.main_params)
  elif wxIMWXkevDPcjlrFaSdhnETGURuCbK=='EPISODE':
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.dp_Episode_List(wxIMWXkevDPcjlrFaSdhnETGURuCQA.main_params)
  elif wxIMWXkevDPcjlrFaSdhnETGURuCbK=='MOVIE_SUB':
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.dp_Movie_List(wxIMWXkevDPcjlrFaSdhnETGURuCQA.main_params)
  elif wxIMWXkevDPcjlrFaSdhnETGURuCbK=='4K_MOVIE':
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.dp_4K_Movie_List(wxIMWXkevDPcjlrFaSdhnETGURuCQA.main_params)
  elif wxIMWXkevDPcjlrFaSdhnETGURuCbK=='SEARCH_GROUP':
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.dp_Search_Group(wxIMWXkevDPcjlrFaSdhnETGURuCQA.main_params)
  elif wxIMWXkevDPcjlrFaSdhnETGURuCbK in['SEARCH','LOCAL_SEARCH']:
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.dp_Search_List(wxIMWXkevDPcjlrFaSdhnETGURuCQA.main_params)
  elif wxIMWXkevDPcjlrFaSdhnETGURuCbK=='WATCH':
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.dp_Watch_List(wxIMWXkevDPcjlrFaSdhnETGURuCQA.main_params)
  elif wxIMWXkevDPcjlrFaSdhnETGURuCbK in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.dp_History_Remove(wxIMWXkevDPcjlrFaSdhnETGURuCQA.main_params)
  elif wxIMWXkevDPcjlrFaSdhnETGURuCbK=='ORDER_BY':
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.dp_setEpOrderby(wxIMWXkevDPcjlrFaSdhnETGURuCQA.main_params)
  elif wxIMWXkevDPcjlrFaSdhnETGURuCbK=='SET_BOOKMARK':
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.dp_Set_Bookmark(wxIMWXkevDPcjlrFaSdhnETGURuCQA.main_params)
  elif wxIMWXkevDPcjlrFaSdhnETGURuCbK in['TOTAL_SEARCH','TOTAL_HISTORY']:
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.dp_Global_Search(wxIMWXkevDPcjlrFaSdhnETGURuCQA.main_params)
  elif wxIMWXkevDPcjlrFaSdhnETGURuCbK=='SEARCH_HISTORY':
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.dp_Search_History(wxIMWXkevDPcjlrFaSdhnETGURuCQA.main_params)
  elif wxIMWXkevDPcjlrFaSdhnETGURuCbK=='MENU_BOOKMARK':
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.dp_Bookmark_Menu(wxIMWXkevDPcjlrFaSdhnETGURuCQA.main_params)
  elif wxIMWXkevDPcjlrFaSdhnETGURuCbK=='EURO_GROUP':
   wxIMWXkevDPcjlrFaSdhnETGURuCQA.dp_EuroLive_List(wxIMWXkevDPcjlrFaSdhnETGURuCQA.main_params)
  else:
   wxIMWXkevDPcjlrFaSdhnETGURuCBK
# Created by pyminifier (https://github.com/liftoff/pyminifier)
