__author__="NightRain"
qocTtyJDvIAmBaXfQLhFzuwnWkdjYb=print
qocTtyJDvIAmBaXfQLhFzuwnWkdjYO=ImportError
qocTtyJDvIAmBaXfQLhFzuwnWkdjsr=object
qocTtyJDvIAmBaXfQLhFzuwnWkdjsV=None
qocTtyJDvIAmBaXfQLhFzuwnWkdjsC=False
qocTtyJDvIAmBaXfQLhFzuwnWkdjsK=open
qocTtyJDvIAmBaXfQLhFzuwnWkdjsg=True
qocTtyJDvIAmBaXfQLhFzuwnWkdjsY=int
qocTtyJDvIAmBaXfQLhFzuwnWkdjsR=range
qocTtyJDvIAmBaXfQLhFzuwnWkdjsE=Exception
qocTtyJDvIAmBaXfQLhFzuwnWkdjsl=len
qocTtyJDvIAmBaXfQLhFzuwnWkdjse=str
qocTtyJDvIAmBaXfQLhFzuwnWkdjsM=dict
qocTtyJDvIAmBaXfQLhFzuwnWkdjsG=list
qocTtyJDvIAmBaXfQLhFzuwnWkdjsp=bytes
qocTtyJDvIAmBaXfQLhFzuwnWkdjsU=ord
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
import os
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
try:
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
 qocTtyJDvIAmBaXfQLhFzuwnWkdjYb('Cryptodome')
except qocTtyJDvIAmBaXfQLhFzuwnWkdjYO:
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
 qocTtyJDvIAmBaXfQLhFzuwnWkdjYb('Crypto')
qocTtyJDvIAmBaXfQLhFzuwnWkdjrC={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
qocTtyJDvIAmBaXfQLhFzuwnWkdjrK ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
class qocTtyJDvIAmBaXfQLhFzuwnWkdjrV(qocTtyJDvIAmBaXfQLhFzuwnWkdjsr):
 def __init__(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg):
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.NETWORKCODE ='CSND0900'
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.OSCODE ='CSOD0900' 
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TELECODE ='CSCD0900'
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.SCREENCODE ='CSSD0100'
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.APIKEY_ATV ='f0f74595d2f123ffc362362e334aeb52' 
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.SCREENCODE_ATV ='CSSD1300' 
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.LIVE_LIMIT =20 
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.VOD_LIMIT =24 
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.EPISODE_LIMIT =30 
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.SEARCH_LIMIT =30 
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.MOVIE_LIMIT =24 
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.API_DOMAIN ='https://api.tving.com'
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN ='https://image.tving.com'
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.SEARCH_DOMAIN ='https://search.tving.com'
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.LOGIN_DOMAIN ='https://user.tving.com'
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.URL_DOMAIN ='https://www.tving.com'
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.MOVIE_LITE =['2610061','2610161','261062']
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36'
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.DEFAULT_HEADER ={'user-agent':qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.USER_AGENT}
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV_SESSION_COOKIES1=''
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV_SESSION_COOKIES2=''
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV_STREAM_FILENAME =''
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV ={}
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.Init_TV_Total()
 def Init_TV_Total(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg):
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV={'account':{},'cookies':{'tving_token':'','tving_userinfo':'','tving_uuid':'-','tving_maintoken':'','tving_cookiekey':'Y','tving_lockkey':'N',},}
 def callRequestCookies(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg,jobtype,qocTtyJDvIAmBaXfQLhFzuwnWkdjVO,payload=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,params=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,headers=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,cookies=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,redirects=qocTtyJDvIAmBaXfQLhFzuwnWkdjsC):
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrY=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.DEFAULT_HEADER
  if headers:qocTtyJDvIAmBaXfQLhFzuwnWkdjrY.update(headers)
  if jobtype=='Get':
   qocTtyJDvIAmBaXfQLhFzuwnWkdjrs=requests.get(qocTtyJDvIAmBaXfQLhFzuwnWkdjVO,params=params,headers=qocTtyJDvIAmBaXfQLhFzuwnWkdjrY,cookies=cookies,allow_redirects=redirects)
  else:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjrs=requests.post(qocTtyJDvIAmBaXfQLhFzuwnWkdjVO,data=payload,params=params,headers=qocTtyJDvIAmBaXfQLhFzuwnWkdjrY,cookies=cookies,allow_redirects=redirects)
  return qocTtyJDvIAmBaXfQLhFzuwnWkdjrs
 def JsonFile_Save(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg,filename,qocTtyJDvIAmBaXfQLhFzuwnWkdjrR):
  if filename=='':return qocTtyJDvIAmBaXfQLhFzuwnWkdjsC
  try:
   fp=qocTtyJDvIAmBaXfQLhFzuwnWkdjsK(filename,'w',-1,'utf-8')
   json.dump(qocTtyJDvIAmBaXfQLhFzuwnWkdjrR,fp,indent=4,ensure_ascii=qocTtyJDvIAmBaXfQLhFzuwnWkdjsC)
   fp.close()
  except:
   return qocTtyJDvIAmBaXfQLhFzuwnWkdjsC
  return qocTtyJDvIAmBaXfQLhFzuwnWkdjsg
 def JsonFile_Load(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg,filename):
  if filename=='':return{}
  try:
   fp=qocTtyJDvIAmBaXfQLhFzuwnWkdjsK(filename,'r',-1,'utf-8')
   qocTtyJDvIAmBaXfQLhFzuwnWkdjrl=json.load(fp)
   fp.close()
  except:
   return{}
  return qocTtyJDvIAmBaXfQLhFzuwnWkdjrl
 def TextFile_Save(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg,filename,resText):
  if filename=='':return qocTtyJDvIAmBaXfQLhFzuwnWkdjsC
  try:
   fp=qocTtyJDvIAmBaXfQLhFzuwnWkdjsK(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return qocTtyJDvIAmBaXfQLhFzuwnWkdjsC
  return qocTtyJDvIAmBaXfQLhFzuwnWkdjsg
 def Save_session_acount(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg,qocTtyJDvIAmBaXfQLhFzuwnWkdjre,qocTtyJDvIAmBaXfQLhFzuwnWkdjrM,qocTtyJDvIAmBaXfQLhFzuwnWkdjrG,qocTtyJDvIAmBaXfQLhFzuwnWkdjrp):
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['account']['tvid'] =base64.standard_b64encode(qocTtyJDvIAmBaXfQLhFzuwnWkdjre.encode()).decode('utf-8')
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['account']['tvpw'] =base64.standard_b64encode(qocTtyJDvIAmBaXfQLhFzuwnWkdjrM.encode()).decode('utf-8')
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['account']['tvtype']=qocTtyJDvIAmBaXfQLhFzuwnWkdjrG 
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['account']['tvpf'] =qocTtyJDvIAmBaXfQLhFzuwnWkdjrp 
 def Load_session_acount(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg):
  try:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjre =base64.standard_b64decode(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['account']['tvid']).decode('utf-8')
   qocTtyJDvIAmBaXfQLhFzuwnWkdjrM =base64.standard_b64decode(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['account']['tvpw']).decode('utf-8')
   qocTtyJDvIAmBaXfQLhFzuwnWkdjrG=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['account']['tvtype']
   qocTtyJDvIAmBaXfQLhFzuwnWkdjrp =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['account']['tvpf'] 
  except:
   return '','','0',0
  return qocTtyJDvIAmBaXfQLhFzuwnWkdjre,qocTtyJDvIAmBaXfQLhFzuwnWkdjrM,qocTtyJDvIAmBaXfQLhFzuwnWkdjrG,qocTtyJDvIAmBaXfQLhFzuwnWkdjrp
 def makeDefaultCookies(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg):
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrU={}
  if qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['cookies']['tving_token']:qocTtyJDvIAmBaXfQLhFzuwnWkdjrU['_tving_token']=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['cookies']['tving_token']
  if qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['cookies']['tving_userinfo']:qocTtyJDvIAmBaXfQLhFzuwnWkdjrU['POC_USERINFO']=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['cookies']['tving_userinfo']
  if qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['cookies']['tving_maintoken']:qocTtyJDvIAmBaXfQLhFzuwnWkdjrU[qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.GLOBAL_COOKIENM['tv_maintoken']]=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['cookies']['tving_maintoken']
  if qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['cookies']['tving_cookiekey']:qocTtyJDvIAmBaXfQLhFzuwnWkdjrU[qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.GLOBAL_COOKIENM['tv_cookiekey']]=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['cookies']['tving_cookiekey']
  if qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['cookies']['tving_lockkey']:qocTtyJDvIAmBaXfQLhFzuwnWkdjrU[qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.GLOBAL_COOKIENM['tv_lockkey']]=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['cookies']['tving_lockkey']
  return qocTtyJDvIAmBaXfQLhFzuwnWkdjrU
 def makeCookiesStr(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg):
  return '_tving_token='+qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['cookies']['tving_token']+';'+ 'POC_USERINFO='+qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['cookies']['tving_userinfo']+';'+ qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.GLOBAL_COOKIENM['tv_maintoken']+'='+qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['cookies']['tving_maintoken']+';'+ qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.GLOBAL_COOKIENM['tv_cookiekey']+'='+qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['cookies']['tving_cookiekey']+';'+ qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.GLOBAL_COOKIENM['tv_lockkey']+'='+qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['cookies']['tving_lockkey']
 def getDeviceStr(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg):
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrS=[]
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrS.append('Windows') 
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrS.append('Chrome') 
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrS.append('ko-KR') 
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrS.append('undefined') 
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrS.append('24') 
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrS.append(u'한국 표준시')
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrS.append('undefined') 
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrS.append('undefined') 
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrS.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrN=''
  for qocTtyJDvIAmBaXfQLhFzuwnWkdjrx in qocTtyJDvIAmBaXfQLhFzuwnWkdjrS:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjrN+=qocTtyJDvIAmBaXfQLhFzuwnWkdjrx+'|'
  return qocTtyJDvIAmBaXfQLhFzuwnWkdjrN
 def GetDefaultParams(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg,uhd=qocTtyJDvIAmBaXfQLhFzuwnWkdjsC):
  if uhd==qocTtyJDvIAmBaXfQLhFzuwnWkdjsC:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjrH={'apiKey':qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.APIKEY,'networkCode':qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.NETWORKCODE,'osCode':qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.OSCODE,'teleCode':qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TELECODE,'screenCode':qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.SCREENCODE,}
  else:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjrH={'apiKey':qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.APIKEY_ATV,'networkCode':qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.NETWORKCODE,'osCode':qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.OSCODE,'teleCode':qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TELECODE,'screenCode':qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.SCREENCODE_ATV,}
  return qocTtyJDvIAmBaXfQLhFzuwnWkdjrH
 def GetNoCache(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg,timetype=1):
  if timetype==1:
   return qocTtyJDvIAmBaXfQLhFzuwnWkdjsY(time.time())
  else:
   return qocTtyJDvIAmBaXfQLhFzuwnWkdjsY(time.time()*1000)
 def GetUniqueid(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg,hValue=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV):
  if hValue:
   import hashlib
   qocTtyJDvIAmBaXfQLhFzuwnWkdjrP=hashlib.sha1()
   qocTtyJDvIAmBaXfQLhFzuwnWkdjrP.update(hValue.encode())
   qocTtyJDvIAmBaXfQLhFzuwnWkdjri=qocTtyJDvIAmBaXfQLhFzuwnWkdjrP.hexdigest()[:8]
  else:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjrb=[0 for i in qocTtyJDvIAmBaXfQLhFzuwnWkdjsR(256)]
   for i in qocTtyJDvIAmBaXfQLhFzuwnWkdjsR(256):
    qocTtyJDvIAmBaXfQLhFzuwnWkdjrb[i]='%02x'%(i)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjrO=qocTtyJDvIAmBaXfQLhFzuwnWkdjsY(4294967295*random.random())|0
   qocTtyJDvIAmBaXfQLhFzuwnWkdjri=qocTtyJDvIAmBaXfQLhFzuwnWkdjrb[255&qocTtyJDvIAmBaXfQLhFzuwnWkdjrO]+qocTtyJDvIAmBaXfQLhFzuwnWkdjrb[qocTtyJDvIAmBaXfQLhFzuwnWkdjrO>>8&255]+qocTtyJDvIAmBaXfQLhFzuwnWkdjrb[qocTtyJDvIAmBaXfQLhFzuwnWkdjrO>>16&255]+qocTtyJDvIAmBaXfQLhFzuwnWkdjrb[qocTtyJDvIAmBaXfQLhFzuwnWkdjrO>>24&255]
  return qocTtyJDvIAmBaXfQLhFzuwnWkdjri
 def GetCredential(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg,user_id,user_pw,login_type,user_pf):
  try:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVr=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVC={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com','csite':'',}
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVK=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.callRequestCookies('Post',qocTtyJDvIAmBaXfQLhFzuwnWkdjVr,payload=qocTtyJDvIAmBaXfQLhFzuwnWkdjVC,params=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,headers=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,cookies=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV)
   for qocTtyJDvIAmBaXfQLhFzuwnWkdjVg in qocTtyJDvIAmBaXfQLhFzuwnWkdjVK.cookies:
    if qocTtyJDvIAmBaXfQLhFzuwnWkdjVg.name=='_tving_token':
     qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['cookies']['tving_token']=qocTtyJDvIAmBaXfQLhFzuwnWkdjVg.value
    elif qocTtyJDvIAmBaXfQLhFzuwnWkdjVg.name=='POC_USERINFO':
     qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['cookies']['tving_userinfo']=qocTtyJDvIAmBaXfQLhFzuwnWkdjVg.value
   if not qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['cookies']['tving_token']:
    qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.Init_TV_Total()
    return qocTtyJDvIAmBaXfQLhFzuwnWkdjsC
   qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['cookies']['tving_maintoken']=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['cookies']['tving_token']
   if qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.GetProfileToken(user_pf)==qocTtyJDvIAmBaXfQLhFzuwnWkdjsC:
    qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.Init_TV_Total()
    return qocTtyJDvIAmBaXfQLhFzuwnWkdjsC
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVY =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.GetDeviceList()
   if qocTtyJDvIAmBaXfQLhFzuwnWkdjVY not in['','-']:
    qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['cookies']['tving_uuid']=qocTtyJDvIAmBaXfQLhFzuwnWkdjVY+'-'+qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.GetUniqueid(qocTtyJDvIAmBaXfQLhFzuwnWkdjVY)
  except qocTtyJDvIAmBaXfQLhFzuwnWkdjsE as exception:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYb(exception)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.Init_TV_Total()
   return qocTtyJDvIAmBaXfQLhFzuwnWkdjsC
  return qocTtyJDvIAmBaXfQLhFzuwnWkdjsg
 def GetProfileToken(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg,user_pf):
  qocTtyJDvIAmBaXfQLhFzuwnWkdjVs=[]
  qocTtyJDvIAmBaXfQLhFzuwnWkdjVR =''
  try:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVE ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com'
   qocTtyJDvIAmBaXfQLhFzuwnWkdjrU=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.makeDefaultCookies()
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVK=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.callRequestCookies('Get',qocTtyJDvIAmBaXfQLhFzuwnWkdjVE,payload=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,params=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,headers=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,cookies=qocTtyJDvIAmBaXfQLhFzuwnWkdjrU)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVs =re.findall('data-profile-no="\d+"',qocTtyJDvIAmBaXfQLhFzuwnWkdjVK.text)
   for i in qocTtyJDvIAmBaXfQLhFzuwnWkdjsR(qocTtyJDvIAmBaXfQLhFzuwnWkdjsl(qocTtyJDvIAmBaXfQLhFzuwnWkdjVs)):
    qocTtyJDvIAmBaXfQLhFzuwnWkdjVl =qocTtyJDvIAmBaXfQLhFzuwnWkdjVs[i].replace('data-profile-no=','').replace('"','')
    qocTtyJDvIAmBaXfQLhFzuwnWkdjVs[i]=qocTtyJDvIAmBaXfQLhFzuwnWkdjVl
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVR=qocTtyJDvIAmBaXfQLhFzuwnWkdjVs[user_pf]
  except qocTtyJDvIAmBaXfQLhFzuwnWkdjsE as exception:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYb(exception)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.Init_TV_Total()
   return qocTtyJDvIAmBaXfQLhFzuwnWkdjsC
  try:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVE ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   qocTtyJDvIAmBaXfQLhFzuwnWkdjrU=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.makeDefaultCookies()
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVC={'profileNo':qocTtyJDvIAmBaXfQLhFzuwnWkdjVR}
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVK=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.callRequestCookies('Post',qocTtyJDvIAmBaXfQLhFzuwnWkdjVE,payload=qocTtyJDvIAmBaXfQLhFzuwnWkdjVC,params=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,headers=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,cookies=qocTtyJDvIAmBaXfQLhFzuwnWkdjrU)
   for qocTtyJDvIAmBaXfQLhFzuwnWkdjVg in qocTtyJDvIAmBaXfQLhFzuwnWkdjVK.cookies:
    if qocTtyJDvIAmBaXfQLhFzuwnWkdjVg.name=='_tving_token':
     qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['cookies']['tving_token']=qocTtyJDvIAmBaXfQLhFzuwnWkdjVg.value
    elif qocTtyJDvIAmBaXfQLhFzuwnWkdjVg.name==qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.GLOBAL_COOKIENM['tv_cookiekey']:
     qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['cookies']['tving_cookiekey']=qocTtyJDvIAmBaXfQLhFzuwnWkdjVg.value
    elif qocTtyJDvIAmBaXfQLhFzuwnWkdjVg.name==qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.GLOBAL_COOKIENM['tv_lockkey']:
     qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['cookies']['tving_lockkey']=qocTtyJDvIAmBaXfQLhFzuwnWkdjVg.value
  except qocTtyJDvIAmBaXfQLhFzuwnWkdjsE as exception:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYb(exception)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.Init_TV_Total()
   return qocTtyJDvIAmBaXfQLhFzuwnWkdjsC
  return qocTtyJDvIAmBaXfQLhFzuwnWkdjsg
 def GetDeviceList(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg):
  qocTtyJDvIAmBaXfQLhFzuwnWkdjVe=[]
  qocTtyJDvIAmBaXfQLhFzuwnWkdjVM='-'
  try:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVE ='/v1/user/device/list'
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVG=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.API_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjVE
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVp={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   qocTtyJDvIAmBaXfQLhFzuwnWkdjrU=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.makeDefaultCookies()
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVK=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.callRequestCookies('Get',qocTtyJDvIAmBaXfQLhFzuwnWkdjVG,payload=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,params=qocTtyJDvIAmBaXfQLhFzuwnWkdjVp,headers=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,cookies=qocTtyJDvIAmBaXfQLhFzuwnWkdjrU)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVU=json.loads(qocTtyJDvIAmBaXfQLhFzuwnWkdjVK.text)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVe=qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']
   for qocTtyJDvIAmBaXfQLhFzuwnWkdjVS in qocTtyJDvIAmBaXfQLhFzuwnWkdjVe:
    if qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['model']=='PC' or qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['model']=='PC-Chrome':
     qocTtyJDvIAmBaXfQLhFzuwnWkdjVM=qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['uuid']
  except qocTtyJDvIAmBaXfQLhFzuwnWkdjsE as exception:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYb(exception)
  return qocTtyJDvIAmBaXfQLhFzuwnWkdjVM
 def Get_Now_Datetime(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg,mediacode,sel_quality,stype,pvrmode='-',optUHD=qocTtyJDvIAmBaXfQLhFzuwnWkdjsC):
  qocTtyJDvIAmBaXfQLhFzuwnWkdjVx ={'streaming_url':'','drm_license':'','watermark':'','watermarkKey':'','subtitleYn':qocTtyJDvIAmBaXfQLhFzuwnWkdjsC,'error_msg':'',}
  qocTtyJDvIAmBaXfQLhFzuwnWkdjVM =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['cookies']['tving_uuid'].split('-')[0] 
  qocTtyJDvIAmBaXfQLhFzuwnWkdjVH =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['cookies']['tving_uuid'] 
  qocTtyJDvIAmBaXfQLhFzuwnWkdjVP=qocTtyJDvIAmBaXfQLhFzuwnWkdjsC 
  try:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVi=qocTtyJDvIAmBaXfQLhFzuwnWkdjse(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.GetNoCache(1))
   if stype!='tvingtv':
    qocTtyJDvIAmBaXfQLhFzuwnWkdjVE ='/v2/media/stream/info' 
    qocTtyJDvIAmBaXfQLhFzuwnWkdjVb=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.GetDefaultParams()
    qocTtyJDvIAmBaXfQLhFzuwnWkdjVp={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':qocTtyJDvIAmBaXfQLhFzuwnWkdjVH,'deviceInfo':'PC','noCache':qocTtyJDvIAmBaXfQLhFzuwnWkdjVi,}
    qocTtyJDvIAmBaXfQLhFzuwnWkdjVb.update(qocTtyJDvIAmBaXfQLhFzuwnWkdjVp)
    qocTtyJDvIAmBaXfQLhFzuwnWkdjVO=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.API_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjVE
    qocTtyJDvIAmBaXfQLhFzuwnWkdjrU=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.makeDefaultCookies()
    qocTtyJDvIAmBaXfQLhFzuwnWkdjVK=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.callRequestCookies('Get',qocTtyJDvIAmBaXfQLhFzuwnWkdjVO,payload=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,params=qocTtyJDvIAmBaXfQLhFzuwnWkdjVb,headers=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,cookies=qocTtyJDvIAmBaXfQLhFzuwnWkdjrU)
    if qocTtyJDvIAmBaXfQLhFzuwnWkdjVK.status_code!=200:
     qocTtyJDvIAmBaXfQLhFzuwnWkdjVx['error_msg']='First Step - {} error'.format(qocTtyJDvIAmBaXfQLhFzuwnWkdjVK.status_code)
     return qocTtyJDvIAmBaXfQLhFzuwnWkdjVx
    qocTtyJDvIAmBaXfQLhFzuwnWkdjVU=json.loads(qocTtyJDvIAmBaXfQLhFzuwnWkdjVK.text)
    if qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']['result']['code']=='060':
     for qocTtyJDvIAmBaXfQLhFzuwnWkdjCr,qocTtyJDvIAmBaXfQLhFzuwnWkdjKr in qocTtyJDvIAmBaXfQLhFzuwnWkdjrC.items():
      if qocTtyJDvIAmBaXfQLhFzuwnWkdjKr==sel_quality:
       qocTtyJDvIAmBaXfQLhFzuwnWkdjCV=qocTtyJDvIAmBaXfQLhFzuwnWkdjCr
    elif qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']['result']['code']!='000':
     qocTtyJDvIAmBaXfQLhFzuwnWkdjVx['error_msg']=qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']['result']['message']
     return qocTtyJDvIAmBaXfQLhFzuwnWkdjVx
    else: 
     if not('stream' in qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']):return qocTtyJDvIAmBaXfQLhFzuwnWkdjVx
     qocTtyJDvIAmBaXfQLhFzuwnWkdjCK=[]
     for qocTtyJDvIAmBaXfQLhFzuwnWkdjCr,qocTtyJDvIAmBaXfQLhFzuwnWkdjKr in qocTtyJDvIAmBaXfQLhFzuwnWkdjrC.items():
      for qocTtyJDvIAmBaXfQLhFzuwnWkdjVS in qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']['stream']['quality']:
       if qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['active']=='Y' and qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['code']==qocTtyJDvIAmBaXfQLhFzuwnWkdjCr:
        qocTtyJDvIAmBaXfQLhFzuwnWkdjCK.append({qocTtyJDvIAmBaXfQLhFzuwnWkdjrC.get(qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['code']):qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['code']})
     qocTtyJDvIAmBaXfQLhFzuwnWkdjCV=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.CheckQuality(sel_quality,qocTtyJDvIAmBaXfQLhFzuwnWkdjCK)
     try:
      if optUHD==qocTtyJDvIAmBaXfQLhFzuwnWkdjsg and qocTtyJDvIAmBaXfQLhFzuwnWkdjCV=='stream50' and 'stream_support_info' in qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']['content']['info']:
       if qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']['content']['info']['stream_support_info']!=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV:
        if 'stream70' in qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']['content']['info']['stream_support_info']:
         qocTtyJDvIAmBaXfQLhFzuwnWkdjCV='stream70'
         qocTtyJDvIAmBaXfQLhFzuwnWkdjVP =qocTtyJDvIAmBaXfQLhFzuwnWkdjsg
     except:
      pass
     try:
      if optUHD==qocTtyJDvIAmBaXfQLhFzuwnWkdjsg and qocTtyJDvIAmBaXfQLhFzuwnWkdjCV=='stream50' and 'stream' in qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']['content']['info']:
       if qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']['content']['info']['stream']!=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV:
        for qocTtyJDvIAmBaXfQLhFzuwnWkdjVS in qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']['content']['info']['stream']:
         if qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['code']=='stream70':
          qocTtyJDvIAmBaXfQLhFzuwnWkdjCV='stream70'
          qocTtyJDvIAmBaXfQLhFzuwnWkdjVP =qocTtyJDvIAmBaXfQLhFzuwnWkdjsg
          break
     except:
      pass
   else:
    qocTtyJDvIAmBaXfQLhFzuwnWkdjCV='stream40'
  except qocTtyJDvIAmBaXfQLhFzuwnWkdjsE as exception:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYb(exception)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVx['error_msg']='First Step - except error'
   return qocTtyJDvIAmBaXfQLhFzuwnWkdjVx
  qocTtyJDvIAmBaXfQLhFzuwnWkdjYb(qocTtyJDvIAmBaXfQLhFzuwnWkdjCV)
  try:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVi=qocTtyJDvIAmBaXfQLhFzuwnWkdjse(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.GetNoCache(1))
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVE ='/v2a/media/stream/info'
   if qocTtyJDvIAmBaXfQLhFzuwnWkdjVP==qocTtyJDvIAmBaXfQLhFzuwnWkdjsg:
    qocTtyJDvIAmBaXfQLhFzuwnWkdjVb=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.GetDefaultParams(uhd=qocTtyJDvIAmBaXfQLhFzuwnWkdjsg)
    qocTtyJDvIAmBaXfQLhFzuwnWkdjVp={'mediaCode':mediacode,'noCache':qocTtyJDvIAmBaXfQLhFzuwnWkdjVi,'streamType':'hls','streamCode':qocTtyJDvIAmBaXfQLhFzuwnWkdjCV,'deviceId':qocTtyJDvIAmBaXfQLhFzuwnWkdjVM,'adReq':'none','wm':'Y','ad_device':'','uuid':qocTtyJDvIAmBaXfQLhFzuwnWkdjVH,'deviceInfo':'android_tv',}
   else:
    qocTtyJDvIAmBaXfQLhFzuwnWkdjVb=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.GetDefaultParams()
    qocTtyJDvIAmBaXfQLhFzuwnWkdjVp={'callingFrom':'HTML5','mediaCode':mediacode,'info':'Y','adReq':'adproxy','streamCode':qocTtyJDvIAmBaXfQLhFzuwnWkdjCV,'deviceId':qocTtyJDvIAmBaXfQLhFzuwnWkdjVM,'uuid':qocTtyJDvIAmBaXfQLhFzuwnWkdjVH,'deviceInfo':'PC_Chrome','noCache':qocTtyJDvIAmBaXfQLhFzuwnWkdjVi,'wm':'Y'}
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVb.update(qocTtyJDvIAmBaXfQLhFzuwnWkdjVp)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVO=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.API_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjVE
   qocTtyJDvIAmBaXfQLhFzuwnWkdjrU=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.makeDefaultCookies()
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVK=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.callRequestCookies('Get',qocTtyJDvIAmBaXfQLhFzuwnWkdjVO,payload=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,params=qocTtyJDvIAmBaXfQLhFzuwnWkdjVb,headers=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,cookies=qocTtyJDvIAmBaXfQLhFzuwnWkdjrU,redirects=qocTtyJDvIAmBaXfQLhFzuwnWkdjsC)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVU=json.loads(qocTtyJDvIAmBaXfQLhFzuwnWkdjVK.text)
   if qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']['result']['code']!='000':
    qocTtyJDvIAmBaXfQLhFzuwnWkdjVx['error_msg']=qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']['result']['message']
    return qocTtyJDvIAmBaXfQLhFzuwnWkdjVx
   qocTtyJDvIAmBaXfQLhFzuwnWkdjCg=qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']['stream']
   if 'drm_license_assertion' in qocTtyJDvIAmBaXfQLhFzuwnWkdjCg:
    qocTtyJDvIAmBaXfQLhFzuwnWkdjVx['drm_license']=qocTtyJDvIAmBaXfQLhFzuwnWkdjCg['drm_license_assertion']
    if '4k_nondrm_url' in qocTtyJDvIAmBaXfQLhFzuwnWkdjCg['broadcast']and qocTtyJDvIAmBaXfQLhFzuwnWkdjVP==qocTtyJDvIAmBaXfQLhFzuwnWkdjsg:
     qocTtyJDvIAmBaXfQLhFzuwnWkdjCY =qocTtyJDvIAmBaXfQLhFzuwnWkdjCg['broadcast']['4k_nondrm_url']
     qocTtyJDvIAmBaXfQLhFzuwnWkdjVx['drm_license']=''
    else:
     qocTtyJDvIAmBaXfQLhFzuwnWkdjCY =qocTtyJDvIAmBaXfQLhFzuwnWkdjCg['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in qocTtyJDvIAmBaXfQLhFzuwnWkdjCg['broadcast']):return qocTtyJDvIAmBaXfQLhFzuwnWkdjVx
    qocTtyJDvIAmBaXfQLhFzuwnWkdjCY=qocTtyJDvIAmBaXfQLhFzuwnWkdjCg['broadcast']['broad_url']
  except qocTtyJDvIAmBaXfQLhFzuwnWkdjsE as exception:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYb(exception)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVx['error_msg']='Second Step - except error'
   return qocTtyJDvIAmBaXfQLhFzuwnWkdjVx
  qocTtyJDvIAmBaXfQLhFzuwnWkdjCs=qocTtyJDvIAmBaXfQLhFzuwnWkdjVi
  qocTtyJDvIAmBaXfQLhFzuwnWkdjCY=qocTtyJDvIAmBaXfQLhFzuwnWkdjCY.split('|')[1]
  qocTtyJDvIAmBaXfQLhFzuwnWkdjCY,qocTtyJDvIAmBaXfQLhFzuwnWkdjCR,qocTtyJDvIAmBaXfQLhFzuwnWkdjCE=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.Decrypt_Url(qocTtyJDvIAmBaXfQLhFzuwnWkdjCY,mediacode,qocTtyJDvIAmBaXfQLhFzuwnWkdjCs)
  qocTtyJDvIAmBaXfQLhFzuwnWkdjVx['streaming_url']=qocTtyJDvIAmBaXfQLhFzuwnWkdjCY
  qocTtyJDvIAmBaXfQLhFzuwnWkdjVx['watermark'] =qocTtyJDvIAmBaXfQLhFzuwnWkdjCR
  qocTtyJDvIAmBaXfQLhFzuwnWkdjVx['watermarkKey']=qocTtyJDvIAmBaXfQLhFzuwnWkdjCE
  if 'subtitles' in qocTtyJDvIAmBaXfQLhFzuwnWkdjCg:
   for qocTtyJDvIAmBaXfQLhFzuwnWkdjCl in qocTtyJDvIAmBaXfQLhFzuwnWkdjCg.get('subtitles'):
    if qocTtyJDvIAmBaXfQLhFzuwnWkdjCl.get('code')in['KO','KO_CC']:
     qocTtyJDvIAmBaXfQLhFzuwnWkdjVx['subtitleYn']=qocTtyJDvIAmBaXfQLhFzuwnWkdjsg
     break
  return qocTtyJDvIAmBaXfQLhFzuwnWkdjVx
 def Tving_Parse_mpd(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg,stream_url):
  qocTtyJDvIAmBaXfQLhFzuwnWkdjVK=requests.get(url=stream_url)
  qocTtyJDvIAmBaXfQLhFzuwnWkdjCe=qocTtyJDvIAmBaXfQLhFzuwnWkdjVK.content.decode('utf-8')
  qocTtyJDvIAmBaXfQLhFzuwnWkdjCM=0
  qocTtyJDvIAmBaXfQLhFzuwnWkdjCG =ET.ElementTree(ET.fromstring(qocTtyJDvIAmBaXfQLhFzuwnWkdjCe))
  qocTtyJDvIAmBaXfQLhFzuwnWkdjCp =qocTtyJDvIAmBaXfQLhFzuwnWkdjCG.getroot()
  qocTtyJDvIAmBaXfQLhFzuwnWkdjCU=re.match(r'\{.*\}',qocTtyJDvIAmBaXfQLhFzuwnWkdjCp.tag)[0]
  qocTtyJDvIAmBaXfQLhFzuwnWkdjCS=qocTtyJDvIAmBaXfQLhFzuwnWkdjsM([node for _,node in ET.iterparse(io.StringIO(qocTtyJDvIAmBaXfQLhFzuwnWkdjCe),events=['start-ns'])])
  for qocTtyJDvIAmBaXfQLhFzuwnWkdjCr,value in qocTtyJDvIAmBaXfQLhFzuwnWkdjCS.items():
   ET.register_namespace(qocTtyJDvIAmBaXfQLhFzuwnWkdjCr,value)
  qocTtyJDvIAmBaXfQLhFzuwnWkdjCN=qocTtyJDvIAmBaXfQLhFzuwnWkdjCp.find(qocTtyJDvIAmBaXfQLhFzuwnWkdjCU+'Period')
  for qocTtyJDvIAmBaXfQLhFzuwnWkdjCx in qocTtyJDvIAmBaXfQLhFzuwnWkdjCN.findall(qocTtyJDvIAmBaXfQLhFzuwnWkdjCU+'AdaptationSet'):
   if qocTtyJDvIAmBaXfQLhFzuwnWkdjCx.attrib.get('mimeType')=='video/mp4':
    for qocTtyJDvIAmBaXfQLhFzuwnWkdjCH in qocTtyJDvIAmBaXfQLhFzuwnWkdjCx.findall(qocTtyJDvIAmBaXfQLhFzuwnWkdjCU+'Representation'):
     qocTtyJDvIAmBaXfQLhFzuwnWkdjCP=qocTtyJDvIAmBaXfQLhFzuwnWkdjsY(qocTtyJDvIAmBaXfQLhFzuwnWkdjCH.attrib.get('bandwidth'))
     if qocTtyJDvIAmBaXfQLhFzuwnWkdjCM<qocTtyJDvIAmBaXfQLhFzuwnWkdjCP:qocTtyJDvIAmBaXfQLhFzuwnWkdjCM=qocTtyJDvIAmBaXfQLhFzuwnWkdjCP
    for qocTtyJDvIAmBaXfQLhFzuwnWkdjCH in qocTtyJDvIAmBaXfQLhFzuwnWkdjCx.findall(qocTtyJDvIAmBaXfQLhFzuwnWkdjCU+'Representation'):
     if qocTtyJDvIAmBaXfQLhFzuwnWkdjCM>qocTtyJDvIAmBaXfQLhFzuwnWkdjsY(qocTtyJDvIAmBaXfQLhFzuwnWkdjCH.attrib.get('bandwidth')):
      qocTtyJDvIAmBaXfQLhFzuwnWkdjCx.remove(qocTtyJDvIAmBaXfQLhFzuwnWkdjCH)
   else:
    continue
  qocTtyJDvIAmBaXfQLhFzuwnWkdjCi=ET.tostring(qocTtyJDvIAmBaXfQLhFzuwnWkdjCp).decode('utf-8')
  qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TextFile_Save(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV_STREAM_FILENAME,qocTtyJDvIAmBaXfQLhFzuwnWkdjCi)
  return qocTtyJDvIAmBaXfQLhFzuwnWkdjsg
 def CheckQuality(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg,sel_qt,qocTtyJDvIAmBaXfQLhFzuwnWkdjCK):
  for qocTtyJDvIAmBaXfQLhFzuwnWkdjCb in qocTtyJDvIAmBaXfQLhFzuwnWkdjCK:
   if sel_qt>=qocTtyJDvIAmBaXfQLhFzuwnWkdjsG(qocTtyJDvIAmBaXfQLhFzuwnWkdjCb)[0]:return qocTtyJDvIAmBaXfQLhFzuwnWkdjCb.get(qocTtyJDvIAmBaXfQLhFzuwnWkdjsG(qocTtyJDvIAmBaXfQLhFzuwnWkdjCb)[0])
   qocTtyJDvIAmBaXfQLhFzuwnWkdjCO=qocTtyJDvIAmBaXfQLhFzuwnWkdjCb.get(qocTtyJDvIAmBaXfQLhFzuwnWkdjsG(qocTtyJDvIAmBaXfQLhFzuwnWkdjCb)[0])
  return qocTtyJDvIAmBaXfQLhFzuwnWkdjCO
 def makeOocUrl(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg,ooc_params):
  qocTtyJDvIAmBaXfQLhFzuwnWkdjVO=''
  for qocTtyJDvIAmBaXfQLhFzuwnWkdjCr,qocTtyJDvIAmBaXfQLhFzuwnWkdjKr in ooc_params.items():
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVO+="%s=%s^"%(qocTtyJDvIAmBaXfQLhFzuwnWkdjCr,qocTtyJDvIAmBaXfQLhFzuwnWkdjKr)
  return qocTtyJDvIAmBaXfQLhFzuwnWkdjVO
 def GetLiveChannelList(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg,stype,page_int):
  qocTtyJDvIAmBaXfQLhFzuwnWkdjVe=[]
  qocTtyJDvIAmBaXfQLhFzuwnWkdjKV=qocTtyJDvIAmBaXfQLhFzuwnWkdjsC
  try:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVE ='/v2/media/lives'
   if stype=='onair': 
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKC='CPCS0100,CPCS0400'
   else:
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKC='CPCS0300'
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVb=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.GetDefaultParams()
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVp={'cacheType':'main','pageNo':qocTtyJDvIAmBaXfQLhFzuwnWkdjse(page_int),'pageSize':qocTtyJDvIAmBaXfQLhFzuwnWkdjse(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':qocTtyJDvIAmBaXfQLhFzuwnWkdjKC,}
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVb.update(qocTtyJDvIAmBaXfQLhFzuwnWkdjVp)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVO=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.API_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjVE
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVK=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.callRequestCookies('Get',qocTtyJDvIAmBaXfQLhFzuwnWkdjVO,payload=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,params=qocTtyJDvIAmBaXfQLhFzuwnWkdjVb,headers=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,cookies=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVU=json.loads(qocTtyJDvIAmBaXfQLhFzuwnWkdjVK.text)
   if not('result' in qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']):return qocTtyJDvIAmBaXfQLhFzuwnWkdjVe,qocTtyJDvIAmBaXfQLhFzuwnWkdjKV
   qocTtyJDvIAmBaXfQLhFzuwnWkdjKg=qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']['result']
   for qocTtyJDvIAmBaXfQLhFzuwnWkdjVS in qocTtyJDvIAmBaXfQLhFzuwnWkdjKg:
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKY=qocTtyJDvIAmBaXfQLhFzuwnWkdjKE=qocTtyJDvIAmBaXfQLhFzuwnWkdjKl=''
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKs=qocTtyJDvIAmBaXfQLhFzuwnWkdjgK=''
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKR=qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['live_code']
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKY =qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['schedule']['channel']['name']['ko']
    if qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['schedule']['episode']!=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV:
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKE =qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['schedule']['program']['name']['ko']
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKE =qocTtyJDvIAmBaXfQLhFzuwnWkdjKE+', '+qocTtyJDvIAmBaXfQLhFzuwnWkdjse(qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['schedule']['episode']['frequency'])+'회'
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKl=qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['schedule']['episode']['synopsis']['ko']
    else:
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKE =qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['schedule']['program']['name']['ko']
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKl=qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['schedule']['program']['synopsis']['ko']
    try: 
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKe =''
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKM =''
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKG=''
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKp =''
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKU =''
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKS =''
     for qocTtyJDvIAmBaXfQLhFzuwnWkdjKN in qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['schedule']['program']['image']:
      if qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['code']=='CAIP0900':qocTtyJDvIAmBaXfQLhFzuwnWkdjKM =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['url']
      elif qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['code']=='CAIP1800':qocTtyJDvIAmBaXfQLhFzuwnWkdjKG=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['url']
      elif qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['code']=='CAIP2000':qocTtyJDvIAmBaXfQLhFzuwnWkdjKp =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['url']
      elif qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['code']=='CAIP1900':qocTtyJDvIAmBaXfQLhFzuwnWkdjKU =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['url']
      elif qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['code']=='CAIP0200':qocTtyJDvIAmBaXfQLhFzuwnWkdjKS =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['url']
      elif qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['code']=='CAIP0500':qocTtyJDvIAmBaXfQLhFzuwnWkdjKe =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['url']
      elif qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['code']=='CAIP0800':qocTtyJDvIAmBaXfQLhFzuwnWkdjKe =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['url']
     if qocTtyJDvIAmBaXfQLhFzuwnWkdjKe=='':
      for qocTtyJDvIAmBaXfQLhFzuwnWkdjKN in qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['schedule']['channel']['image']:
       if qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['code']=='CAIC0400':qocTtyJDvIAmBaXfQLhFzuwnWkdjKe =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['url']
       elif qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['code']=='CAIC1400':qocTtyJDvIAmBaXfQLhFzuwnWkdjKe =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['url']
       elif qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['code']=='CAIC1900':qocTtyJDvIAmBaXfQLhFzuwnWkdjKe =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['url']
    except:
     qocTtyJDvIAmBaXfQLhFzuwnWkdjsV
    try:
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKx =[]
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKH=[]
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKP =[]
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKi=''
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKb=''
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKO=''
     for qocTtyJDvIAmBaXfQLhFzuwnWkdjgr in qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('schedule').get('program').get('actor'):
      if qocTtyJDvIAmBaXfQLhFzuwnWkdjgr!='' and qocTtyJDvIAmBaXfQLhFzuwnWkdjgr!=u'없음':qocTtyJDvIAmBaXfQLhFzuwnWkdjKx.append(qocTtyJDvIAmBaXfQLhFzuwnWkdjgr)
     for qocTtyJDvIAmBaXfQLhFzuwnWkdjgV in qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('schedule').get('program').get('director'):
      if qocTtyJDvIAmBaXfQLhFzuwnWkdjgV!='' and qocTtyJDvIAmBaXfQLhFzuwnWkdjgV!='-' and qocTtyJDvIAmBaXfQLhFzuwnWkdjgV!=u'없음':qocTtyJDvIAmBaXfQLhFzuwnWkdjKH.append(qocTtyJDvIAmBaXfQLhFzuwnWkdjgV)
     if qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('schedule').get('program').get('category1_name').get('ko')!='':
      qocTtyJDvIAmBaXfQLhFzuwnWkdjKP.append(qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['schedule']['program']['category1_name']['ko'])
     if qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('schedule').get('program').get('category2_name').get('ko')!='':
      qocTtyJDvIAmBaXfQLhFzuwnWkdjKP.append(qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['schedule']['program']['category2_name']['ko'])
     if qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('schedule').get('program').get('product_year'):qocTtyJDvIAmBaXfQLhFzuwnWkdjKi=qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['schedule']['program']['product_year']
     if qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('schedule').get('program').get('grade_code') :qocTtyJDvIAmBaXfQLhFzuwnWkdjKb= qocTtyJDvIAmBaXfQLhFzuwnWkdjrK.get(qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['schedule']['program']['grade_code'])
     if 'broad_dt' in qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('schedule').get('program'):
      qocTtyJDvIAmBaXfQLhFzuwnWkdjgC =qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('schedule').get('program').get('broad_dt')
      qocTtyJDvIAmBaXfQLhFzuwnWkdjKO='%s-%s-%s'%(qocTtyJDvIAmBaXfQLhFzuwnWkdjgC[:4],qocTtyJDvIAmBaXfQLhFzuwnWkdjgC[4:6],qocTtyJDvIAmBaXfQLhFzuwnWkdjgC[6:])
    except:
     qocTtyJDvIAmBaXfQLhFzuwnWkdjsV
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKs=qocTtyJDvIAmBaXfQLhFzuwnWkdjse(qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['schedule']['broadcast_start_time'])[8:12]
    qocTtyJDvIAmBaXfQLhFzuwnWkdjgK =qocTtyJDvIAmBaXfQLhFzuwnWkdjse(qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['schedule']['broadcast_end_time'])[8:12]
    qocTtyJDvIAmBaXfQLhFzuwnWkdjgY={'channel':qocTtyJDvIAmBaXfQLhFzuwnWkdjKY,'title':qocTtyJDvIAmBaXfQLhFzuwnWkdjKE,'mediacode':qocTtyJDvIAmBaXfQLhFzuwnWkdjKR,'thumbnail':{'poster':qocTtyJDvIAmBaXfQLhFzuwnWkdjKM,'thumb':qocTtyJDvIAmBaXfQLhFzuwnWkdjKe,'clearlogo':qocTtyJDvIAmBaXfQLhFzuwnWkdjKG,'icon':qocTtyJDvIAmBaXfQLhFzuwnWkdjKp,'fanart':qocTtyJDvIAmBaXfQLhFzuwnWkdjKS},'synopsis':qocTtyJDvIAmBaXfQLhFzuwnWkdjKl,'channelepg':' [%s:%s ~ %s:%s]'%(qocTtyJDvIAmBaXfQLhFzuwnWkdjKs[0:2],qocTtyJDvIAmBaXfQLhFzuwnWkdjKs[2:],qocTtyJDvIAmBaXfQLhFzuwnWkdjgK[0:2],qocTtyJDvIAmBaXfQLhFzuwnWkdjgK[2:]),'cast':qocTtyJDvIAmBaXfQLhFzuwnWkdjKx,'director':qocTtyJDvIAmBaXfQLhFzuwnWkdjKH,'info_genre':qocTtyJDvIAmBaXfQLhFzuwnWkdjKP,'year':qocTtyJDvIAmBaXfQLhFzuwnWkdjKi,'mpaa':qocTtyJDvIAmBaXfQLhFzuwnWkdjKb,'premiered':qocTtyJDvIAmBaXfQLhFzuwnWkdjKO}
    qocTtyJDvIAmBaXfQLhFzuwnWkdjVe.append(qocTtyJDvIAmBaXfQLhFzuwnWkdjgY)
   if qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']['has_more']=='Y':
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKV=qocTtyJDvIAmBaXfQLhFzuwnWkdjsg
  except qocTtyJDvIAmBaXfQLhFzuwnWkdjsE as exception:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYb(exception)
  return qocTtyJDvIAmBaXfQLhFzuwnWkdjVe,qocTtyJDvIAmBaXfQLhFzuwnWkdjKV
 def GetProgramList(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg,genre,orderby,page_int,genreCode='all'):
  qocTtyJDvIAmBaXfQLhFzuwnWkdjVe=[]
  qocTtyJDvIAmBaXfQLhFzuwnWkdjKV=qocTtyJDvIAmBaXfQLhFzuwnWkdjsC
  try:
   if genre=='PARAMOUNT':
    qocTtyJDvIAmBaXfQLhFzuwnWkdjVE ='/v2/media/paramount/episodes'
   else:
    qocTtyJDvIAmBaXfQLhFzuwnWkdjVE ='/v2/media/episodes'
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVb=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.GetDefaultParams()
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVp={'cacheType':'main','pageSize':qocTtyJDvIAmBaXfQLhFzuwnWkdjse(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':qocTtyJDvIAmBaXfQLhFzuwnWkdjse(page_int),}
   if genre not in['all','PARAMOUNT']:qocTtyJDvIAmBaXfQLhFzuwnWkdjVp['categoryCode']=genre
   if genreCode!='all' :qocTtyJDvIAmBaXfQLhFzuwnWkdjVp['genreCode'] =genreCode 
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVb.update(qocTtyJDvIAmBaXfQLhFzuwnWkdjVp)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVO=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.API_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjVE
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVK=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.callRequestCookies('Get',qocTtyJDvIAmBaXfQLhFzuwnWkdjVO,payload=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,params=qocTtyJDvIAmBaXfQLhFzuwnWkdjVb,headers=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,cookies=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVU=json.loads(qocTtyJDvIAmBaXfQLhFzuwnWkdjVK.text)
   if not('result' in qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']):return qocTtyJDvIAmBaXfQLhFzuwnWkdjVe,qocTtyJDvIAmBaXfQLhFzuwnWkdjKV
   qocTtyJDvIAmBaXfQLhFzuwnWkdjKg=qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']['result']
   for qocTtyJDvIAmBaXfQLhFzuwnWkdjVS in qocTtyJDvIAmBaXfQLhFzuwnWkdjKg:
    qocTtyJDvIAmBaXfQLhFzuwnWkdjgs=qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['program']['code']
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKE =qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['program']['name']['ko']
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKb =qocTtyJDvIAmBaXfQLhFzuwnWkdjrK.get(qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['program'].get('grade_code'))
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKM =''
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKe =''
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKG=''
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKp =''
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKU =''
    for qocTtyJDvIAmBaXfQLhFzuwnWkdjKN in qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['program']['image']:
     if qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['code']=='CAIP0900':qocTtyJDvIAmBaXfQLhFzuwnWkdjKM =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['url']
     elif qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['code']=='CAIP0200':qocTtyJDvIAmBaXfQLhFzuwnWkdjKe =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['url']
     elif qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['code']=='CAIP1800':qocTtyJDvIAmBaXfQLhFzuwnWkdjKG=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['url']
     elif qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['code']=='CAIP2000':qocTtyJDvIAmBaXfQLhFzuwnWkdjKp =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['url']
     elif qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['code']=='CAIP1900':qocTtyJDvIAmBaXfQLhFzuwnWkdjKU =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['url']
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKl =qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['program']['synopsis']['ko']
    try:
     qocTtyJDvIAmBaXfQLhFzuwnWkdjgR=qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['channel']['name']['ko']
    except:
     qocTtyJDvIAmBaXfQLhFzuwnWkdjgR=''
    try:
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKx =[]
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKH=[]
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKP =[]
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKi =''
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKO=''
     for qocTtyJDvIAmBaXfQLhFzuwnWkdjgr in qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('program').get('actor'):
      if qocTtyJDvIAmBaXfQLhFzuwnWkdjgr!='' and qocTtyJDvIAmBaXfQLhFzuwnWkdjgr!='-' and qocTtyJDvIAmBaXfQLhFzuwnWkdjgr!=u'없음':qocTtyJDvIAmBaXfQLhFzuwnWkdjKx.append(qocTtyJDvIAmBaXfQLhFzuwnWkdjgr)
     for qocTtyJDvIAmBaXfQLhFzuwnWkdjgV in qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('program').get('director'):
      if qocTtyJDvIAmBaXfQLhFzuwnWkdjgV!='' and qocTtyJDvIAmBaXfQLhFzuwnWkdjgV!='-' and qocTtyJDvIAmBaXfQLhFzuwnWkdjgV!=u'없음':qocTtyJDvIAmBaXfQLhFzuwnWkdjKH.append(qocTtyJDvIAmBaXfQLhFzuwnWkdjgV)
     if qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('program').get('category1_name').get('ko')!='':
      qocTtyJDvIAmBaXfQLhFzuwnWkdjKP.append(qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['program']['category1_name']['ko'])
     if qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('program').get('category2_name').get('ko')!='':
      qocTtyJDvIAmBaXfQLhFzuwnWkdjKP.append(qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['program']['category2_name']['ko'])
     if qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('program').get('product_year'):qocTtyJDvIAmBaXfQLhFzuwnWkdjKi=qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['program']['product_year']
     if 'broad_dt' in qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('program'):
      qocTtyJDvIAmBaXfQLhFzuwnWkdjgC =qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('program').get('broad_dt')
      qocTtyJDvIAmBaXfQLhFzuwnWkdjKO='%s-%s-%s'%(qocTtyJDvIAmBaXfQLhFzuwnWkdjgC[:4],qocTtyJDvIAmBaXfQLhFzuwnWkdjgC[4:6],qocTtyJDvIAmBaXfQLhFzuwnWkdjgC[6:])
    except:
     qocTtyJDvIAmBaXfQLhFzuwnWkdjsV
    qocTtyJDvIAmBaXfQLhFzuwnWkdjgY={'program':qocTtyJDvIAmBaXfQLhFzuwnWkdjgs,'title':qocTtyJDvIAmBaXfQLhFzuwnWkdjKE,'thumbnail':{'poster':qocTtyJDvIAmBaXfQLhFzuwnWkdjKM,'thumb':qocTtyJDvIAmBaXfQLhFzuwnWkdjKe,'clearlogo':qocTtyJDvIAmBaXfQLhFzuwnWkdjKG,'icon':qocTtyJDvIAmBaXfQLhFzuwnWkdjKp,'banner':qocTtyJDvIAmBaXfQLhFzuwnWkdjKU,'fanart':qocTtyJDvIAmBaXfQLhFzuwnWkdjKe},'synopsis':qocTtyJDvIAmBaXfQLhFzuwnWkdjKl,'channel':qocTtyJDvIAmBaXfQLhFzuwnWkdjgR,'cast':qocTtyJDvIAmBaXfQLhFzuwnWkdjKx,'director':qocTtyJDvIAmBaXfQLhFzuwnWkdjKH,'info_genre':qocTtyJDvIAmBaXfQLhFzuwnWkdjKP,'year':qocTtyJDvIAmBaXfQLhFzuwnWkdjKi,'premiered':qocTtyJDvIAmBaXfQLhFzuwnWkdjKO,'mpaa':qocTtyJDvIAmBaXfQLhFzuwnWkdjKb}
    qocTtyJDvIAmBaXfQLhFzuwnWkdjVe.append(qocTtyJDvIAmBaXfQLhFzuwnWkdjgY)
   if qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']['has_more']=='Y':qocTtyJDvIAmBaXfQLhFzuwnWkdjKV=qocTtyJDvIAmBaXfQLhFzuwnWkdjsg
  except qocTtyJDvIAmBaXfQLhFzuwnWkdjsE as exception:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYb(exception)
  return qocTtyJDvIAmBaXfQLhFzuwnWkdjVe,qocTtyJDvIAmBaXfQLhFzuwnWkdjKV
 def Get_UHD_ProgramList(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg,page_int):
  qocTtyJDvIAmBaXfQLhFzuwnWkdjVe=[]
  qocTtyJDvIAmBaXfQLhFzuwnWkdjKV=qocTtyJDvIAmBaXfQLhFzuwnWkdjsC
  try:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVE ='/v2/operator/highlights'
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVb=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.GetDefaultParams(uhd=qocTtyJDvIAmBaXfQLhFzuwnWkdjsg)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVp={'positionKey':'SMTV_PROG_4K','pageSize':'20','page_int':qocTtyJDvIAmBaXfQLhFzuwnWkdjse(page_int),'pocType':'APP_X_TVING_4.0.0',}
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVb.update(qocTtyJDvIAmBaXfQLhFzuwnWkdjVp)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVO=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.API_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjVE
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVK=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.callRequestCookies('Get',qocTtyJDvIAmBaXfQLhFzuwnWkdjVO,payload=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,params=qocTtyJDvIAmBaXfQLhFzuwnWkdjVb,headers=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,cookies=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVU=json.loads(qocTtyJDvIAmBaXfQLhFzuwnWkdjVK.text)
   if not('result' in qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']):return qocTtyJDvIAmBaXfQLhFzuwnWkdjVe,qocTtyJDvIAmBaXfQLhFzuwnWkdjKV
   qocTtyJDvIAmBaXfQLhFzuwnWkdjKg=qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']['result']
   for qocTtyJDvIAmBaXfQLhFzuwnWkdjVS in qocTtyJDvIAmBaXfQLhFzuwnWkdjKg:
    qocTtyJDvIAmBaXfQLhFzuwnWkdjgE=qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['content']['program']
    qocTtyJDvIAmBaXfQLhFzuwnWkdjgl =qocTtyJDvIAmBaXfQLhFzuwnWkdjgE['code']
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKE =qocTtyJDvIAmBaXfQLhFzuwnWkdjgE['name']['ko'].strip()
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKb =qocTtyJDvIAmBaXfQLhFzuwnWkdjrK.get(qocTtyJDvIAmBaXfQLhFzuwnWkdjgE.get('grade_code'))
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKl =qocTtyJDvIAmBaXfQLhFzuwnWkdjgE['synopsis']['ko']
    qocTtyJDvIAmBaXfQLhFzuwnWkdjgR =qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['content']['channel']['name']['ko']
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKi =qocTtyJDvIAmBaXfQLhFzuwnWkdjgE['product_year']
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKM =''
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKe =''
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKG=''
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKp =''
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKU =''
    for qocTtyJDvIAmBaXfQLhFzuwnWkdjKN in qocTtyJDvIAmBaXfQLhFzuwnWkdjgE['image']:
     if qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['code']=='CAIP0900':qocTtyJDvIAmBaXfQLhFzuwnWkdjKM =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['url']
     elif qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['code']=='CAIP0200':qocTtyJDvIAmBaXfQLhFzuwnWkdjKe =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['url']
     elif qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['code']=='CAIP1800':qocTtyJDvIAmBaXfQLhFzuwnWkdjKG=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['url']
     elif qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['code']=='CAIP2000':qocTtyJDvIAmBaXfQLhFzuwnWkdjKp =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['url']
     elif qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['code']=='CAIP1900':qocTtyJDvIAmBaXfQLhFzuwnWkdjKU =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['url']
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKP =[]
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKx =[]
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKH=[]
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKO =''
    if qocTtyJDvIAmBaXfQLhFzuwnWkdjgE.get('category1_name').get('ko')!='':
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKP.append(qocTtyJDvIAmBaXfQLhFzuwnWkdjgE['category1_name']['ko'])
    if qocTtyJDvIAmBaXfQLhFzuwnWkdjgE.get('category2_name').get('ko')!='':
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKP.append(qocTtyJDvIAmBaXfQLhFzuwnWkdjgE['category2_name']['ko'])
    for qocTtyJDvIAmBaXfQLhFzuwnWkdjgr in qocTtyJDvIAmBaXfQLhFzuwnWkdjgE.get('actor'):
     if qocTtyJDvIAmBaXfQLhFzuwnWkdjgr!='' and qocTtyJDvIAmBaXfQLhFzuwnWkdjgr!='-' and qocTtyJDvIAmBaXfQLhFzuwnWkdjgr!=u'없음':qocTtyJDvIAmBaXfQLhFzuwnWkdjKx.append(qocTtyJDvIAmBaXfQLhFzuwnWkdjgr)
    for qocTtyJDvIAmBaXfQLhFzuwnWkdjgV in qocTtyJDvIAmBaXfQLhFzuwnWkdjgE.get('director'):
     if qocTtyJDvIAmBaXfQLhFzuwnWkdjgV!='' and qocTtyJDvIAmBaXfQLhFzuwnWkdjgV!='-' and qocTtyJDvIAmBaXfQLhFzuwnWkdjgV!=u'없음':qocTtyJDvIAmBaXfQLhFzuwnWkdjKH.append(qocTtyJDvIAmBaXfQLhFzuwnWkdjgV)
    if qocTtyJDvIAmBaXfQLhFzuwnWkdjgE.get('broad_dt')not in[qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,'']:
     qocTtyJDvIAmBaXfQLhFzuwnWkdjgC =qocTtyJDvIAmBaXfQLhFzuwnWkdjgE.get('broad_dt')
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKO='%s-%s-%s'%(qocTtyJDvIAmBaXfQLhFzuwnWkdjgC[:4],qocTtyJDvIAmBaXfQLhFzuwnWkdjgC[4:6],qocTtyJDvIAmBaXfQLhFzuwnWkdjgC[6:])
    qocTtyJDvIAmBaXfQLhFzuwnWkdjgY={'program':qocTtyJDvIAmBaXfQLhFzuwnWkdjgl,'title':qocTtyJDvIAmBaXfQLhFzuwnWkdjKE,'mpaa':qocTtyJDvIAmBaXfQLhFzuwnWkdjKb,'thumbnail':{'poster':qocTtyJDvIAmBaXfQLhFzuwnWkdjKM,'thumb':qocTtyJDvIAmBaXfQLhFzuwnWkdjKe,'clearlogo':qocTtyJDvIAmBaXfQLhFzuwnWkdjKG,'icon':qocTtyJDvIAmBaXfQLhFzuwnWkdjKp,'banner':qocTtyJDvIAmBaXfQLhFzuwnWkdjKU,'fanart':qocTtyJDvIAmBaXfQLhFzuwnWkdjKe},'channel':qocTtyJDvIAmBaXfQLhFzuwnWkdjgR,'synopsis':qocTtyJDvIAmBaXfQLhFzuwnWkdjKl,'year':qocTtyJDvIAmBaXfQLhFzuwnWkdjKi,'info_genre':qocTtyJDvIAmBaXfQLhFzuwnWkdjKP,'cast':qocTtyJDvIAmBaXfQLhFzuwnWkdjKx,'director':qocTtyJDvIAmBaXfQLhFzuwnWkdjKH,'premiered':qocTtyJDvIAmBaXfQLhFzuwnWkdjKO,}
    qocTtyJDvIAmBaXfQLhFzuwnWkdjVe.append(qocTtyJDvIAmBaXfQLhFzuwnWkdjgY)
  except qocTtyJDvIAmBaXfQLhFzuwnWkdjsE as exception:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYb(exception)
  return qocTtyJDvIAmBaXfQLhFzuwnWkdjVe,qocTtyJDvIAmBaXfQLhFzuwnWkdjKV
 def Get_Origianl_ProgramList(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg,page_int):
  qocTtyJDvIAmBaXfQLhFzuwnWkdjVe=[]
  qocTtyJDvIAmBaXfQLhFzuwnWkdjKV=qocTtyJDvIAmBaXfQLhFzuwnWkdjsC
  try:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVE ='/v2/media/band/originals'
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVb=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.GetDefaultParams()
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVp={'pageSize':qocTtyJDvIAmBaXfQLhFzuwnWkdjse(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.VOD_LIMIT),'adult':'all','order':'viewHour','originalYn':'Y','exclusiveYn':'Y','pageNo':qocTtyJDvIAmBaXfQLhFzuwnWkdjse(page_int),}
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVb.update(qocTtyJDvIAmBaXfQLhFzuwnWkdjVp)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVO=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.API_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjVE
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVK=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.callRequestCookies('Get',qocTtyJDvIAmBaXfQLhFzuwnWkdjVO,payload=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,params=qocTtyJDvIAmBaXfQLhFzuwnWkdjVb,headers=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,cookies=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVU=json.loads(qocTtyJDvIAmBaXfQLhFzuwnWkdjVK.text)
   if not('contents' in qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']):return qocTtyJDvIAmBaXfQLhFzuwnWkdjVe,qocTtyJDvIAmBaXfQLhFzuwnWkdjKV
   qocTtyJDvIAmBaXfQLhFzuwnWkdjKg=qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']['contents']
   for qocTtyJDvIAmBaXfQLhFzuwnWkdjVS in qocTtyJDvIAmBaXfQLhFzuwnWkdjKg:
    qocTtyJDvIAmBaXfQLhFzuwnWkdjgs=qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['vod_code']
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKE =qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['vod_name']
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKM =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['image']
    qocTtyJDvIAmBaXfQLhFzuwnWkdjgY={'program':qocTtyJDvIAmBaXfQLhFzuwnWkdjgs,'title':qocTtyJDvIAmBaXfQLhFzuwnWkdjKE,'thumbnail':{'poster':qocTtyJDvIAmBaXfQLhFzuwnWkdjKM,'thumb':qocTtyJDvIAmBaXfQLhFzuwnWkdjKM}}
    qocTtyJDvIAmBaXfQLhFzuwnWkdjVe.append(qocTtyJDvIAmBaXfQLhFzuwnWkdjgY)
   if qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']['has_more']=='Y':qocTtyJDvIAmBaXfQLhFzuwnWkdjKV=qocTtyJDvIAmBaXfQLhFzuwnWkdjsg
  except qocTtyJDvIAmBaXfQLhFzuwnWkdjsE as exception:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYb(exception)
  return qocTtyJDvIAmBaXfQLhFzuwnWkdjVe,qocTtyJDvIAmBaXfQLhFzuwnWkdjKV
 def GetEpisodeList(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg,program_code,page_int,orderby='desc'):
  qocTtyJDvIAmBaXfQLhFzuwnWkdjVe=[]
  qocTtyJDvIAmBaXfQLhFzuwnWkdjKV=qocTtyJDvIAmBaXfQLhFzuwnWkdjsC
  try:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVE ='/v2/media/frequency/program/'+program_code
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVb=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.GetDefaultParams()
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVp={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVb.update(qocTtyJDvIAmBaXfQLhFzuwnWkdjVp)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVO=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.API_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjVE
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVK=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.callRequestCookies('Get',qocTtyJDvIAmBaXfQLhFzuwnWkdjVO,payload=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,params=qocTtyJDvIAmBaXfQLhFzuwnWkdjVb,headers=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,cookies=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVU=json.loads(qocTtyJDvIAmBaXfQLhFzuwnWkdjVK.text)
   if not('result' in qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']):return qocTtyJDvIAmBaXfQLhFzuwnWkdjVe,qocTtyJDvIAmBaXfQLhFzuwnWkdjKV
   qocTtyJDvIAmBaXfQLhFzuwnWkdjKg=qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']['result']
   qocTtyJDvIAmBaXfQLhFzuwnWkdjge=qocTtyJDvIAmBaXfQLhFzuwnWkdjsY(qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']['total_count'])
   qocTtyJDvIAmBaXfQLhFzuwnWkdjgM =qocTtyJDvIAmBaXfQLhFzuwnWkdjsY(qocTtyJDvIAmBaXfQLhFzuwnWkdjge//(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    qocTtyJDvIAmBaXfQLhFzuwnWkdjgG =(qocTtyJDvIAmBaXfQLhFzuwnWkdjge-1)-((page_int-1)*qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.EPISODE_LIMIT)
   else:
    qocTtyJDvIAmBaXfQLhFzuwnWkdjgG =(page_int-1)*qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.EPISODE_LIMIT
   for i in qocTtyJDvIAmBaXfQLhFzuwnWkdjsR(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.EPISODE_LIMIT):
    if orderby=='desc':
     qocTtyJDvIAmBaXfQLhFzuwnWkdjgp=qocTtyJDvIAmBaXfQLhFzuwnWkdjgG-i
     if qocTtyJDvIAmBaXfQLhFzuwnWkdjgp<0:break
    else:
     qocTtyJDvIAmBaXfQLhFzuwnWkdjgp=qocTtyJDvIAmBaXfQLhFzuwnWkdjgG+i
     if qocTtyJDvIAmBaXfQLhFzuwnWkdjgp>=qocTtyJDvIAmBaXfQLhFzuwnWkdjge:break
    qocTtyJDvIAmBaXfQLhFzuwnWkdjgU=qocTtyJDvIAmBaXfQLhFzuwnWkdjKg[qocTtyJDvIAmBaXfQLhFzuwnWkdjgp]['episode']['code']
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKE =qocTtyJDvIAmBaXfQLhFzuwnWkdjKg[qocTtyJDvIAmBaXfQLhFzuwnWkdjgp]['vod_name']['ko']
    qocTtyJDvIAmBaXfQLhFzuwnWkdjgS =''
    try:
     qocTtyJDvIAmBaXfQLhFzuwnWkdjgC=qocTtyJDvIAmBaXfQLhFzuwnWkdjse(qocTtyJDvIAmBaXfQLhFzuwnWkdjKg[qocTtyJDvIAmBaXfQLhFzuwnWkdjgp]['episode']['broadcast_date'])
     qocTtyJDvIAmBaXfQLhFzuwnWkdjgS='%s-%s-%s'%(qocTtyJDvIAmBaXfQLhFzuwnWkdjgC[:4],qocTtyJDvIAmBaXfQLhFzuwnWkdjgC[4:6],qocTtyJDvIAmBaXfQLhFzuwnWkdjgC[6:])
    except:
     qocTtyJDvIAmBaXfQLhFzuwnWkdjsV
    try:
     if qocTtyJDvIAmBaXfQLhFzuwnWkdjKg[qocTtyJDvIAmBaXfQLhFzuwnWkdjgp]['episode']['pip_cliptype']=='C012':
      qocTtyJDvIAmBaXfQLhFzuwnWkdjgS+=' - Quick VOD'
    except:
     qocTtyJDvIAmBaXfQLhFzuwnWkdjsV
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKl =qocTtyJDvIAmBaXfQLhFzuwnWkdjKg[qocTtyJDvIAmBaXfQLhFzuwnWkdjgp]['episode']['synopsis']['ko']
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKM =''
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKe =''
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKG=''
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKp =''
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKU =''
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKS =''
    for qocTtyJDvIAmBaXfQLhFzuwnWkdjKN in qocTtyJDvIAmBaXfQLhFzuwnWkdjKg[qocTtyJDvIAmBaXfQLhFzuwnWkdjgp]['program']['image']:
     if qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['code']=='CAIP0900':qocTtyJDvIAmBaXfQLhFzuwnWkdjKM =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['url']
     elif qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['code']=='CAIP1800':qocTtyJDvIAmBaXfQLhFzuwnWkdjKG=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['url']
     elif qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['code']=='CAIP2000':qocTtyJDvIAmBaXfQLhFzuwnWkdjKp =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['url']
     elif qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['code']=='CAIP1900':qocTtyJDvIAmBaXfQLhFzuwnWkdjKU =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['url']
     elif qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['code']=='CAIP0200':qocTtyJDvIAmBaXfQLhFzuwnWkdjKS =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['url']
    for qocTtyJDvIAmBaXfQLhFzuwnWkdjKN in qocTtyJDvIAmBaXfQLhFzuwnWkdjKg[qocTtyJDvIAmBaXfQLhFzuwnWkdjgp]['episode']['image']:
     if qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['code']=='CAIE0400':qocTtyJDvIAmBaXfQLhFzuwnWkdjKe =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['url']
    try:
     qocTtyJDvIAmBaXfQLhFzuwnWkdjgN=qocTtyJDvIAmBaXfQLhFzuwnWkdjgH=qocTtyJDvIAmBaXfQLhFzuwnWkdjgP=''
     qocTtyJDvIAmBaXfQLhFzuwnWkdjgx=0
     qocTtyJDvIAmBaXfQLhFzuwnWkdjgN =qocTtyJDvIAmBaXfQLhFzuwnWkdjKg[qocTtyJDvIAmBaXfQLhFzuwnWkdjgp]['program']['name']['ko']
     qocTtyJDvIAmBaXfQLhFzuwnWkdjgH =qocTtyJDvIAmBaXfQLhFzuwnWkdjgS
     qocTtyJDvIAmBaXfQLhFzuwnWkdjgP =qocTtyJDvIAmBaXfQLhFzuwnWkdjKg[qocTtyJDvIAmBaXfQLhFzuwnWkdjgp]['channel']['name']['ko']
     if 'frequency' in qocTtyJDvIAmBaXfQLhFzuwnWkdjKg[qocTtyJDvIAmBaXfQLhFzuwnWkdjgp]['episode']:qocTtyJDvIAmBaXfQLhFzuwnWkdjgx=qocTtyJDvIAmBaXfQLhFzuwnWkdjKg[qocTtyJDvIAmBaXfQLhFzuwnWkdjgp]['episode']['frequency']
    except:
     qocTtyJDvIAmBaXfQLhFzuwnWkdjsV
    qocTtyJDvIAmBaXfQLhFzuwnWkdjgY={'episode':qocTtyJDvIAmBaXfQLhFzuwnWkdjgU,'title':qocTtyJDvIAmBaXfQLhFzuwnWkdjKE,'subtitle':qocTtyJDvIAmBaXfQLhFzuwnWkdjgS,'thumbnail':{'poster':qocTtyJDvIAmBaXfQLhFzuwnWkdjKM,'thumb':qocTtyJDvIAmBaXfQLhFzuwnWkdjKe,'clearlogo':qocTtyJDvIAmBaXfQLhFzuwnWkdjKG,'icon':qocTtyJDvIAmBaXfQLhFzuwnWkdjKp,'banner':qocTtyJDvIAmBaXfQLhFzuwnWkdjKU,'fanart':qocTtyJDvIAmBaXfQLhFzuwnWkdjKS},'synopsis':qocTtyJDvIAmBaXfQLhFzuwnWkdjKl,'info_title':qocTtyJDvIAmBaXfQLhFzuwnWkdjgN,'aired':qocTtyJDvIAmBaXfQLhFzuwnWkdjgH,'studio':qocTtyJDvIAmBaXfQLhFzuwnWkdjgP,'frequency':qocTtyJDvIAmBaXfQLhFzuwnWkdjgx}
    qocTtyJDvIAmBaXfQLhFzuwnWkdjVe.append(qocTtyJDvIAmBaXfQLhFzuwnWkdjgY)
   if qocTtyJDvIAmBaXfQLhFzuwnWkdjgM>page_int:qocTtyJDvIAmBaXfQLhFzuwnWkdjKV=qocTtyJDvIAmBaXfQLhFzuwnWkdjsg
  except qocTtyJDvIAmBaXfQLhFzuwnWkdjsE as exception:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYb(exception)
  return qocTtyJDvIAmBaXfQLhFzuwnWkdjVe,qocTtyJDvIAmBaXfQLhFzuwnWkdjKV,qocTtyJDvIAmBaXfQLhFzuwnWkdjgM
 def GetMovieList(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg,genre,orderby,page_int):
  qocTtyJDvIAmBaXfQLhFzuwnWkdjVe=[]
  qocTtyJDvIAmBaXfQLhFzuwnWkdjKV=qocTtyJDvIAmBaXfQLhFzuwnWkdjsC
  try:
   if genre=='PARAMOUNT':
    qocTtyJDvIAmBaXfQLhFzuwnWkdjVE ='/v2/media/paramount/movies'
   else:
    qocTtyJDvIAmBaXfQLhFzuwnWkdjVE ='/v2/media/movies'
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVb=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.GetDefaultParams()
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVp={'pageSize':qocTtyJDvIAmBaXfQLhFzuwnWkdjse(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N' if genre!='diversityYn' else 'Y','pageNo':qocTtyJDvIAmBaXfQLhFzuwnWkdjse(page_int),}
   if genre not in['all','PARAMOUNT','diversityYn']:qocTtyJDvIAmBaXfQLhFzuwnWkdjVp['categoryCode']=genre
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVp['productPackageCode']=','.join(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.MOVIE_LITE)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVb.update(qocTtyJDvIAmBaXfQLhFzuwnWkdjVp)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVO=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.API_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjVE
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVK=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.callRequestCookies('Get',qocTtyJDvIAmBaXfQLhFzuwnWkdjVO,payload=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,params=qocTtyJDvIAmBaXfQLhFzuwnWkdjVb,headers=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,cookies=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVU=json.loads(qocTtyJDvIAmBaXfQLhFzuwnWkdjVK.text)
   if not('result' in qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']):return qocTtyJDvIAmBaXfQLhFzuwnWkdjVe,qocTtyJDvIAmBaXfQLhFzuwnWkdjKV
   qocTtyJDvIAmBaXfQLhFzuwnWkdjKg=qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']['result']
   for qocTtyJDvIAmBaXfQLhFzuwnWkdjVS in qocTtyJDvIAmBaXfQLhFzuwnWkdjKg:
    if 'release_date' in qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('movie'):
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKi=qocTtyJDvIAmBaXfQLhFzuwnWkdjse(qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('movie').get('release_date'))[:4]
    else:
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKi=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV
    qocTtyJDvIAmBaXfQLhFzuwnWkdjgi =qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['movie']['code']
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKE =qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['movie']['name']['ko'].strip()
    if qocTtyJDvIAmBaXfQLhFzuwnWkdjKi not in[qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,'0','']:qocTtyJDvIAmBaXfQLhFzuwnWkdjKE+=u' (%s)'%(qocTtyJDvIAmBaXfQLhFzuwnWkdjKi)
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKM=''
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKe =''
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKG=''
    for qocTtyJDvIAmBaXfQLhFzuwnWkdjKN in qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['movie']['image']:
     if qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['code']=='CAIM2100':qocTtyJDvIAmBaXfQLhFzuwnWkdjKM =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['url']
     elif qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['code']=='CAIM0400':qocTtyJDvIAmBaXfQLhFzuwnWkdjKe =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['url']
     elif qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['code']=='CAIM1800':qocTtyJDvIAmBaXfQLhFzuwnWkdjKG=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['url']
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKl =qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['movie']['story']['ko']
    try:
     qocTtyJDvIAmBaXfQLhFzuwnWkdjgN =qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['movie']['name']['ko'].strip()
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKb =qocTtyJDvIAmBaXfQLhFzuwnWkdjrK.get(qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('grade_code'))
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKx=[]
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKH=[]
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKP=[]
     qocTtyJDvIAmBaXfQLhFzuwnWkdjgb=0
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKO=''
     qocTtyJDvIAmBaXfQLhFzuwnWkdjgP =''
     for qocTtyJDvIAmBaXfQLhFzuwnWkdjgr in qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('movie').get('actor'):
      if qocTtyJDvIAmBaXfQLhFzuwnWkdjgr!='':qocTtyJDvIAmBaXfQLhFzuwnWkdjKx.append(qocTtyJDvIAmBaXfQLhFzuwnWkdjgr)
     for qocTtyJDvIAmBaXfQLhFzuwnWkdjgV in qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('movie').get('director'):
      if qocTtyJDvIAmBaXfQLhFzuwnWkdjgV!='':qocTtyJDvIAmBaXfQLhFzuwnWkdjKH.append(qocTtyJDvIAmBaXfQLhFzuwnWkdjgV)
     if qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('movie').get('category1_name').get('ko')!='':
      qocTtyJDvIAmBaXfQLhFzuwnWkdjKP.append(qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['movie']['category1_name']['ko'])
     if qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('movie').get('category2_name').get('ko')!='':
      qocTtyJDvIAmBaXfQLhFzuwnWkdjKP.append(qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['movie']['category2_name']['ko'])
     if 'duration' in qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('movie'):qocTtyJDvIAmBaXfQLhFzuwnWkdjgb=qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('movie').get('duration')
     if 'release_date' in qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('movie'):
      qocTtyJDvIAmBaXfQLhFzuwnWkdjgC=qocTtyJDvIAmBaXfQLhFzuwnWkdjse(qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('movie').get('release_date'))
      if qocTtyJDvIAmBaXfQLhFzuwnWkdjgC!='0':qocTtyJDvIAmBaXfQLhFzuwnWkdjKO='%s-%s-%s'%(qocTtyJDvIAmBaXfQLhFzuwnWkdjgC[:4],qocTtyJDvIAmBaXfQLhFzuwnWkdjgC[4:6],qocTtyJDvIAmBaXfQLhFzuwnWkdjgC[6:])
     if 'production' in qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('movie'):qocTtyJDvIAmBaXfQLhFzuwnWkdjgP=qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('movie').get('production')
    except:
     qocTtyJDvIAmBaXfQLhFzuwnWkdjsV
    qocTtyJDvIAmBaXfQLhFzuwnWkdjgY={'moviecode':qocTtyJDvIAmBaXfQLhFzuwnWkdjgi,'title':qocTtyJDvIAmBaXfQLhFzuwnWkdjKE,'thumbnail':{'poster':qocTtyJDvIAmBaXfQLhFzuwnWkdjKM,'thumb':qocTtyJDvIAmBaXfQLhFzuwnWkdjKe,'clearlogo':qocTtyJDvIAmBaXfQLhFzuwnWkdjKG,'fanart':qocTtyJDvIAmBaXfQLhFzuwnWkdjKe},'synopsis':qocTtyJDvIAmBaXfQLhFzuwnWkdjKl,'info_title':qocTtyJDvIAmBaXfQLhFzuwnWkdjgN,'year':qocTtyJDvIAmBaXfQLhFzuwnWkdjKi,'cast':qocTtyJDvIAmBaXfQLhFzuwnWkdjKx,'director':qocTtyJDvIAmBaXfQLhFzuwnWkdjKH,'info_genre':qocTtyJDvIAmBaXfQLhFzuwnWkdjKP,'duration':qocTtyJDvIAmBaXfQLhFzuwnWkdjgb,'premiered':qocTtyJDvIAmBaXfQLhFzuwnWkdjKO,'studio':qocTtyJDvIAmBaXfQLhFzuwnWkdjgP,'mpaa':qocTtyJDvIAmBaXfQLhFzuwnWkdjKb}
    qocTtyJDvIAmBaXfQLhFzuwnWkdjgO=qocTtyJDvIAmBaXfQLhFzuwnWkdjsC
    for qocTtyJDvIAmBaXfQLhFzuwnWkdjYr in qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['billing_package_id']:
     if qocTtyJDvIAmBaXfQLhFzuwnWkdjYr in qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.MOVIE_LITE:
      qocTtyJDvIAmBaXfQLhFzuwnWkdjgO=qocTtyJDvIAmBaXfQLhFzuwnWkdjsg
      break
    if qocTtyJDvIAmBaXfQLhFzuwnWkdjgO==qocTtyJDvIAmBaXfQLhFzuwnWkdjsC: 
     qocTtyJDvIAmBaXfQLhFzuwnWkdjgY['title']=qocTtyJDvIAmBaXfQLhFzuwnWkdjgY['title']+' [개별구매]'
    qocTtyJDvIAmBaXfQLhFzuwnWkdjVe.append(qocTtyJDvIAmBaXfQLhFzuwnWkdjgY)
   if qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']['has_more']=='Y':qocTtyJDvIAmBaXfQLhFzuwnWkdjKV=qocTtyJDvIAmBaXfQLhFzuwnWkdjsg
  except qocTtyJDvIAmBaXfQLhFzuwnWkdjsE as exception:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYb(exception)
  return qocTtyJDvIAmBaXfQLhFzuwnWkdjVe,qocTtyJDvIAmBaXfQLhFzuwnWkdjKV
 def Get_UHD_MovieList(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg,page_int):
  qocTtyJDvIAmBaXfQLhFzuwnWkdjVe=[]
  qocTtyJDvIAmBaXfQLhFzuwnWkdjKV=qocTtyJDvIAmBaXfQLhFzuwnWkdjsC
  try:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVE ='/v2/operator/highlights'
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVb=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.GetDefaultParams(uhd=qocTtyJDvIAmBaXfQLhFzuwnWkdjsg)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVp={'positionKey':'SMTV_MV_4K','pageSize':'20','page_int':qocTtyJDvIAmBaXfQLhFzuwnWkdjse(page_int),'pocType':'APP_X_TVING_4.0.0',}
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVb.update(qocTtyJDvIAmBaXfQLhFzuwnWkdjVp)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVO=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.API_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjVE
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVK=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.callRequestCookies('Get',qocTtyJDvIAmBaXfQLhFzuwnWkdjVO,payload=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,params=qocTtyJDvIAmBaXfQLhFzuwnWkdjVb,headers=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,cookies=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVU=json.loads(qocTtyJDvIAmBaXfQLhFzuwnWkdjVK.text)
   if not('result' in qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']):return qocTtyJDvIAmBaXfQLhFzuwnWkdjVe,qocTtyJDvIAmBaXfQLhFzuwnWkdjKV
   qocTtyJDvIAmBaXfQLhFzuwnWkdjKg=qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']['result']
   for qocTtyJDvIAmBaXfQLhFzuwnWkdjVS in qocTtyJDvIAmBaXfQLhFzuwnWkdjKg:
    qocTtyJDvIAmBaXfQLhFzuwnWkdjgE=qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['content']['movie']
    qocTtyJDvIAmBaXfQLhFzuwnWkdjgl =qocTtyJDvIAmBaXfQLhFzuwnWkdjgE['code']
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKE =qocTtyJDvIAmBaXfQLhFzuwnWkdjgE['name']['ko'].strip()
    qocTtyJDvIAmBaXfQLhFzuwnWkdjgN =qocTtyJDvIAmBaXfQLhFzuwnWkdjgE['name']['ko'].strip()
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKi =qocTtyJDvIAmBaXfQLhFzuwnWkdjgE['product_year']
    if qocTtyJDvIAmBaXfQLhFzuwnWkdjKi:qocTtyJDvIAmBaXfQLhFzuwnWkdjKE+=u' (%s)'%(qocTtyJDvIAmBaXfQLhFzuwnWkdjgE['product_year'])
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKl =qocTtyJDvIAmBaXfQLhFzuwnWkdjgE['story']['ko']
    qocTtyJDvIAmBaXfQLhFzuwnWkdjgb =qocTtyJDvIAmBaXfQLhFzuwnWkdjgE['duration']
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKb =qocTtyJDvIAmBaXfQLhFzuwnWkdjrK.get(qocTtyJDvIAmBaXfQLhFzuwnWkdjgE.get('grade_code'))
    qocTtyJDvIAmBaXfQLhFzuwnWkdjgP =qocTtyJDvIAmBaXfQLhFzuwnWkdjgE['production']
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKM=''
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKe =''
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKG=''
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKP =[]
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKx =[]
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKH=[]
    qocTtyJDvIAmBaXfQLhFzuwnWkdjKO =''
    for qocTtyJDvIAmBaXfQLhFzuwnWkdjKN in qocTtyJDvIAmBaXfQLhFzuwnWkdjgE['image']:
     if qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['code']=='CAIM2100':qocTtyJDvIAmBaXfQLhFzuwnWkdjKM =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['url']
     elif qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['code']=='CAIM0400':qocTtyJDvIAmBaXfQLhFzuwnWkdjKe =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['url']
     elif qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['code']=='CAIM1800':qocTtyJDvIAmBaXfQLhFzuwnWkdjKG=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN['url']
    if qocTtyJDvIAmBaXfQLhFzuwnWkdjgE['release_date']not in[qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,0]:
     qocTtyJDvIAmBaXfQLhFzuwnWkdjgC=qocTtyJDvIAmBaXfQLhFzuwnWkdjse(qocTtyJDvIAmBaXfQLhFzuwnWkdjgE['release_date'])
     if qocTtyJDvIAmBaXfQLhFzuwnWkdjgC!='0':qocTtyJDvIAmBaXfQLhFzuwnWkdjKO='%s-%s-%s'%(qocTtyJDvIAmBaXfQLhFzuwnWkdjgC[:4],qocTtyJDvIAmBaXfQLhFzuwnWkdjgC[4:6],qocTtyJDvIAmBaXfQLhFzuwnWkdjgC[6:])
    if qocTtyJDvIAmBaXfQLhFzuwnWkdjgE.get('category1_name').get('ko')!='':
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKP.append(qocTtyJDvIAmBaXfQLhFzuwnWkdjgE['category1_name']['ko'])
    if qocTtyJDvIAmBaXfQLhFzuwnWkdjgE.get('category2_name').get('ko')!='':
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKP.append(qocTtyJDvIAmBaXfQLhFzuwnWkdjgE['category2_name']['ko'])
    for qocTtyJDvIAmBaXfQLhFzuwnWkdjgr in qocTtyJDvIAmBaXfQLhFzuwnWkdjgE.get('actor'):
     if qocTtyJDvIAmBaXfQLhFzuwnWkdjgr!='':qocTtyJDvIAmBaXfQLhFzuwnWkdjKx.append(qocTtyJDvIAmBaXfQLhFzuwnWkdjgr)
    for qocTtyJDvIAmBaXfQLhFzuwnWkdjgV in qocTtyJDvIAmBaXfQLhFzuwnWkdjgE.get('director'):
     if qocTtyJDvIAmBaXfQLhFzuwnWkdjgV!='':qocTtyJDvIAmBaXfQLhFzuwnWkdjKH.append(qocTtyJDvIAmBaXfQLhFzuwnWkdjgV)
    qocTtyJDvIAmBaXfQLhFzuwnWkdjgY={'moviecode':qocTtyJDvIAmBaXfQLhFzuwnWkdjgl,'title':qocTtyJDvIAmBaXfQLhFzuwnWkdjKE,'thumbnail':{'poster':qocTtyJDvIAmBaXfQLhFzuwnWkdjKM,'thumb':qocTtyJDvIAmBaXfQLhFzuwnWkdjKe,'clearlogo':qocTtyJDvIAmBaXfQLhFzuwnWkdjKG,'fanart':qocTtyJDvIAmBaXfQLhFzuwnWkdjKe},'year':qocTtyJDvIAmBaXfQLhFzuwnWkdjKi,'info_title':qocTtyJDvIAmBaXfQLhFzuwnWkdjgN,'synopsis':qocTtyJDvIAmBaXfQLhFzuwnWkdjKl,'mpaa':qocTtyJDvIAmBaXfQLhFzuwnWkdjKb,'duration':qocTtyJDvIAmBaXfQLhFzuwnWkdjgb,'premiered':qocTtyJDvIAmBaXfQLhFzuwnWkdjKO,'studio':qocTtyJDvIAmBaXfQLhFzuwnWkdjgP,'info_genre':qocTtyJDvIAmBaXfQLhFzuwnWkdjKP,'cast':qocTtyJDvIAmBaXfQLhFzuwnWkdjKx,'director':qocTtyJDvIAmBaXfQLhFzuwnWkdjKH,}
    qocTtyJDvIAmBaXfQLhFzuwnWkdjVe.append(qocTtyJDvIAmBaXfQLhFzuwnWkdjgY)
  except qocTtyJDvIAmBaXfQLhFzuwnWkdjsE as exception:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYb(exception)
  return qocTtyJDvIAmBaXfQLhFzuwnWkdjVe,qocTtyJDvIAmBaXfQLhFzuwnWkdjKV
 def GetMovieGenre(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg):
  qocTtyJDvIAmBaXfQLhFzuwnWkdjVe=[]
  qocTtyJDvIAmBaXfQLhFzuwnWkdjKV=qocTtyJDvIAmBaXfQLhFzuwnWkdjsC
  try:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVE ='/v2/media/movie/curations'
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVb=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.GetDefaultParams()
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVp={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVb.update(qocTtyJDvIAmBaXfQLhFzuwnWkdjVp)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVO=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.API_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjVE
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVK=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.callRequestCookies('Get',qocTtyJDvIAmBaXfQLhFzuwnWkdjVO,payload=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,params=qocTtyJDvIAmBaXfQLhFzuwnWkdjVb,headers=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,cookies=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVU=json.loads(qocTtyJDvIAmBaXfQLhFzuwnWkdjVK.text)
   if not('result' in qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']):return qocTtyJDvIAmBaXfQLhFzuwnWkdjVe,qocTtyJDvIAmBaXfQLhFzuwnWkdjKV
   qocTtyJDvIAmBaXfQLhFzuwnWkdjKg=qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']['result']
   for qocTtyJDvIAmBaXfQLhFzuwnWkdjVS in qocTtyJDvIAmBaXfQLhFzuwnWkdjKg:
    qocTtyJDvIAmBaXfQLhFzuwnWkdjYV =qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['curation_code']
    qocTtyJDvIAmBaXfQLhFzuwnWkdjYC =qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['curation_name']
    qocTtyJDvIAmBaXfQLhFzuwnWkdjgY={'curation_code':qocTtyJDvIAmBaXfQLhFzuwnWkdjYV,'curation_name':qocTtyJDvIAmBaXfQLhFzuwnWkdjYC}
    qocTtyJDvIAmBaXfQLhFzuwnWkdjVe.append(qocTtyJDvIAmBaXfQLhFzuwnWkdjgY)
  except qocTtyJDvIAmBaXfQLhFzuwnWkdjsE as exception:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYb(exception)
  return qocTtyJDvIAmBaXfQLhFzuwnWkdjVe,qocTtyJDvIAmBaXfQLhFzuwnWkdjKV
 def GetSearchList(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg,search_key,page_int,stype):
  qocTtyJDvIAmBaXfQLhFzuwnWkdjYK=[]
  qocTtyJDvIAmBaXfQLhFzuwnWkdjKV=qocTtyJDvIAmBaXfQLhFzuwnWkdjsC
  try:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVE ='/search/getSearch.jsp'
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVp={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':qocTtyJDvIAmBaXfQLhFzuwnWkdjse(page_int),'pageSize':qocTtyJDvIAmBaXfQLhFzuwnWkdjse(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.SCREENCODE,'os':qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.OSCODE,'network':qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':qocTtyJDvIAmBaXfQLhFzuwnWkdjse(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.SEARCH_LIMIT)if stype=='vod' else '','vodMVReqCnt':qocTtyJDvIAmBaXfQLhFzuwnWkdjse(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.SEARCH_LIMIT)if stype=='movie' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':''}
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVO=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.SEARCH_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjVE
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVK=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.callRequestCookies('Get',qocTtyJDvIAmBaXfQLhFzuwnWkdjVO,payload=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,params=qocTtyJDvIAmBaXfQLhFzuwnWkdjVp,headers=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,cookies=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVU=json.loads(qocTtyJDvIAmBaXfQLhFzuwnWkdjVK.text)
   if stype=='vod':
    if not('programRsb' in qocTtyJDvIAmBaXfQLhFzuwnWkdjVU):return qocTtyJDvIAmBaXfQLhFzuwnWkdjYK,qocTtyJDvIAmBaXfQLhFzuwnWkdjKV
    qocTtyJDvIAmBaXfQLhFzuwnWkdjYg=qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['programRsb']['dataList']
    qocTtyJDvIAmBaXfQLhFzuwnWkdjYs =qocTtyJDvIAmBaXfQLhFzuwnWkdjsY(qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['programRsb']['count'])
    for qocTtyJDvIAmBaXfQLhFzuwnWkdjVS in qocTtyJDvIAmBaXfQLhFzuwnWkdjYg:
     qocTtyJDvIAmBaXfQLhFzuwnWkdjgs=qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['mast_cd']
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKE =qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['mast_nm']
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKM=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['web_url4']
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKe =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['web_url']
     try:
      qocTtyJDvIAmBaXfQLhFzuwnWkdjKx =[]
      qocTtyJDvIAmBaXfQLhFzuwnWkdjKH=[]
      qocTtyJDvIAmBaXfQLhFzuwnWkdjKP =[]
      qocTtyJDvIAmBaXfQLhFzuwnWkdjgb =0
      qocTtyJDvIAmBaXfQLhFzuwnWkdjKb =''
      qocTtyJDvIAmBaXfQLhFzuwnWkdjKi =''
      qocTtyJDvIAmBaXfQLhFzuwnWkdjgH =''
      if qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('actor') !='' and qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('actor') !='-':qocTtyJDvIAmBaXfQLhFzuwnWkdjKx =qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('actor').split(',')
      if qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('director')!='' and qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('director')!='-':qocTtyJDvIAmBaXfQLhFzuwnWkdjKH=qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('director').split(',')
      if qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('cate_nm')!='' and qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('cate_nm')!='-':qocTtyJDvIAmBaXfQLhFzuwnWkdjKP =qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('cate_nm').split('/')
      if 'targetage' in qocTtyJDvIAmBaXfQLhFzuwnWkdjVS:qocTtyJDvIAmBaXfQLhFzuwnWkdjKb=qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('targetage')
      if 'broad_dt' in qocTtyJDvIAmBaXfQLhFzuwnWkdjVS:
       qocTtyJDvIAmBaXfQLhFzuwnWkdjgC=qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('broad_dt')
       qocTtyJDvIAmBaXfQLhFzuwnWkdjgH='%s-%s-%s'%(qocTtyJDvIAmBaXfQLhFzuwnWkdjgC[:4],qocTtyJDvIAmBaXfQLhFzuwnWkdjgC[4:6],qocTtyJDvIAmBaXfQLhFzuwnWkdjgC[6:])
       qocTtyJDvIAmBaXfQLhFzuwnWkdjKi =qocTtyJDvIAmBaXfQLhFzuwnWkdjgC[:4]
     except:
      qocTtyJDvIAmBaXfQLhFzuwnWkdjsV
     qocTtyJDvIAmBaXfQLhFzuwnWkdjgY={'program':qocTtyJDvIAmBaXfQLhFzuwnWkdjgs,'title':qocTtyJDvIAmBaXfQLhFzuwnWkdjKE,'thumbnail':{'poster':qocTtyJDvIAmBaXfQLhFzuwnWkdjKM,'thumb':qocTtyJDvIAmBaXfQLhFzuwnWkdjKe,'fanart':qocTtyJDvIAmBaXfQLhFzuwnWkdjKe},'synopsis':'','cast':qocTtyJDvIAmBaXfQLhFzuwnWkdjKx,'director':qocTtyJDvIAmBaXfQLhFzuwnWkdjKH,'info_genre':qocTtyJDvIAmBaXfQLhFzuwnWkdjKP,'duration':qocTtyJDvIAmBaXfQLhFzuwnWkdjgb,'mpaa':qocTtyJDvIAmBaXfQLhFzuwnWkdjKb,'year':qocTtyJDvIAmBaXfQLhFzuwnWkdjKi,'aired':qocTtyJDvIAmBaXfQLhFzuwnWkdjgH}
     qocTtyJDvIAmBaXfQLhFzuwnWkdjYK.append(qocTtyJDvIAmBaXfQLhFzuwnWkdjgY)
   else:
    if not('vodMVRsb' in qocTtyJDvIAmBaXfQLhFzuwnWkdjVU):return qocTtyJDvIAmBaXfQLhFzuwnWkdjYK,qocTtyJDvIAmBaXfQLhFzuwnWkdjKV
    qocTtyJDvIAmBaXfQLhFzuwnWkdjYR=qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['vodMVRsb']['dataList']
    qocTtyJDvIAmBaXfQLhFzuwnWkdjYs =qocTtyJDvIAmBaXfQLhFzuwnWkdjsY(qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['vodMVRsb']['count'])
    for qocTtyJDvIAmBaXfQLhFzuwnWkdjVS in qocTtyJDvIAmBaXfQLhFzuwnWkdjYR:
     qocTtyJDvIAmBaXfQLhFzuwnWkdjgs=qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['mast_cd']
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKE =qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['mast_nm'].strip()
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKM =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['web_url']
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKe =qocTtyJDvIAmBaXfQLhFzuwnWkdjKM
     qocTtyJDvIAmBaXfQLhFzuwnWkdjKG=''
     try:
      qocTtyJDvIAmBaXfQLhFzuwnWkdjKx =[]
      qocTtyJDvIAmBaXfQLhFzuwnWkdjKH=[]
      qocTtyJDvIAmBaXfQLhFzuwnWkdjKP =[]
      qocTtyJDvIAmBaXfQLhFzuwnWkdjgb =0
      qocTtyJDvIAmBaXfQLhFzuwnWkdjKb =''
      qocTtyJDvIAmBaXfQLhFzuwnWkdjKi =''
      qocTtyJDvIAmBaXfQLhFzuwnWkdjgH =''
      if qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('actor') !='' and qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('actor') !='-':qocTtyJDvIAmBaXfQLhFzuwnWkdjKx =qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('actor').split(',')
      if qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('director')!='' and qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('director')!='-':qocTtyJDvIAmBaXfQLhFzuwnWkdjKH=qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('director').split(',')
      if qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('cate_nm')!='' and qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('cate_nm')!='-':qocTtyJDvIAmBaXfQLhFzuwnWkdjKP =qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('cate_nm').split('/')
      if qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('runtime_sec')!='':qocTtyJDvIAmBaXfQLhFzuwnWkdjgb=qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('runtime_sec')
      if 'grade_nm' in qocTtyJDvIAmBaXfQLhFzuwnWkdjVS:qocTtyJDvIAmBaXfQLhFzuwnWkdjKb=qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('grade_nm')
      qocTtyJDvIAmBaXfQLhFzuwnWkdjgC=qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('broad_dt')
      if data_str!='':
       qocTtyJDvIAmBaXfQLhFzuwnWkdjgH='%s-%s-%s'%(qocTtyJDvIAmBaXfQLhFzuwnWkdjgC[:4],qocTtyJDvIAmBaXfQLhFzuwnWkdjgC[4:6],qocTtyJDvIAmBaXfQLhFzuwnWkdjgC[6:])
       qocTtyJDvIAmBaXfQLhFzuwnWkdjKi =qocTtyJDvIAmBaXfQLhFzuwnWkdjgC[:4]
     except:
      qocTtyJDvIAmBaXfQLhFzuwnWkdjsV
     qocTtyJDvIAmBaXfQLhFzuwnWkdjgY={'movie':qocTtyJDvIAmBaXfQLhFzuwnWkdjgs,'title':qocTtyJDvIAmBaXfQLhFzuwnWkdjKE,'thumbnail':{'poster':qocTtyJDvIAmBaXfQLhFzuwnWkdjKM,'thumb':qocTtyJDvIAmBaXfQLhFzuwnWkdjKe,'fanart':qocTtyJDvIAmBaXfQLhFzuwnWkdjKe,'clearlogo':qocTtyJDvIAmBaXfQLhFzuwnWkdjKG},'synopsis':'','cast':qocTtyJDvIAmBaXfQLhFzuwnWkdjKx,'director':qocTtyJDvIAmBaXfQLhFzuwnWkdjKH,'info_genre':qocTtyJDvIAmBaXfQLhFzuwnWkdjKP,'duration':qocTtyJDvIAmBaXfQLhFzuwnWkdjgb,'mpaa':qocTtyJDvIAmBaXfQLhFzuwnWkdjKb,'year':qocTtyJDvIAmBaXfQLhFzuwnWkdjKi,'aired':qocTtyJDvIAmBaXfQLhFzuwnWkdjgH}
     qocTtyJDvIAmBaXfQLhFzuwnWkdjgO=qocTtyJDvIAmBaXfQLhFzuwnWkdjsC
     for qocTtyJDvIAmBaXfQLhFzuwnWkdjYr in qocTtyJDvIAmBaXfQLhFzuwnWkdjVS['bill']:
      if qocTtyJDvIAmBaXfQLhFzuwnWkdjYr in qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.MOVIE_LITE:
       qocTtyJDvIAmBaXfQLhFzuwnWkdjgO=qocTtyJDvIAmBaXfQLhFzuwnWkdjsg
       break
     if qocTtyJDvIAmBaXfQLhFzuwnWkdjgO==qocTtyJDvIAmBaXfQLhFzuwnWkdjsC: 
      qocTtyJDvIAmBaXfQLhFzuwnWkdjgY['title']=qocTtyJDvIAmBaXfQLhFzuwnWkdjgY['title']+' [개별구매]'
     qocTtyJDvIAmBaXfQLhFzuwnWkdjYK.append(qocTtyJDvIAmBaXfQLhFzuwnWkdjgY)
   if qocTtyJDvIAmBaXfQLhFzuwnWkdjYs>(page_int*qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.SEARCH_LIMIT):qocTtyJDvIAmBaXfQLhFzuwnWkdjKV=qocTtyJDvIAmBaXfQLhFzuwnWkdjsg
  except qocTtyJDvIAmBaXfQLhFzuwnWkdjsE as exception:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYb(exception)
  return qocTtyJDvIAmBaXfQLhFzuwnWkdjYK,qocTtyJDvIAmBaXfQLhFzuwnWkdjKV
 def GetBookmarkInfo(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg,videoid,vidtype):
  qocTtyJDvIAmBaXfQLhFzuwnWkdjYE={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVO=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.API_DOMAIN+'/v2/media/program/'+videoid
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVb=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.GetDefaultParams()
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVp={'pageNo':'1','pageSize':'10','order':'name',}
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVb.update(qocTtyJDvIAmBaXfQLhFzuwnWkdjVp)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVK=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.callRequestCookies('Get',qocTtyJDvIAmBaXfQLhFzuwnWkdjVO,payload=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,params=qocTtyJDvIAmBaXfQLhFzuwnWkdjVb,headers=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,cookies=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYl=json.loads(qocTtyJDvIAmBaXfQLhFzuwnWkdjVK.text)
   if not('body' in qocTtyJDvIAmBaXfQLhFzuwnWkdjYl):return{}
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYe=qocTtyJDvIAmBaXfQLhFzuwnWkdjYl['body']
   qocTtyJDvIAmBaXfQLhFzuwnWkdjKE=qocTtyJDvIAmBaXfQLhFzuwnWkdjYe.get('name').get('ko').strip()
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYE['saveinfo']['title'] =qocTtyJDvIAmBaXfQLhFzuwnWkdjKE
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYE['saveinfo']['infoLabels']['title']=qocTtyJDvIAmBaXfQLhFzuwnWkdjKE
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYE['saveinfo']['infoLabels']['mpaa'] =qocTtyJDvIAmBaXfQLhFzuwnWkdjrK.get(qocTtyJDvIAmBaXfQLhFzuwnWkdjYe.get('grade_code'))
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYE['saveinfo']['infoLabels']['plot'] =qocTtyJDvIAmBaXfQLhFzuwnWkdjYe.get('synopsis').get('ko')
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYE['saveinfo']['infoLabels']['year'] =qocTtyJDvIAmBaXfQLhFzuwnWkdjYe.get('product_year')
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYE['saveinfo']['infoLabels']['cast'] =qocTtyJDvIAmBaXfQLhFzuwnWkdjYe.get('actor')
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYE['saveinfo']['infoLabels']['director']=qocTtyJDvIAmBaXfQLhFzuwnWkdjYe.get('director')
   if qocTtyJDvIAmBaXfQLhFzuwnWkdjYe.get('category1_name').get('ko')!='':
    qocTtyJDvIAmBaXfQLhFzuwnWkdjYE['saveinfo']['infoLabels']['genre'].append(qocTtyJDvIAmBaXfQLhFzuwnWkdjYe.get('category1_name').get('ko'))
   if qocTtyJDvIAmBaXfQLhFzuwnWkdjYe.get('category2_name').get('ko')!='':
    qocTtyJDvIAmBaXfQLhFzuwnWkdjYE['saveinfo']['infoLabels']['genre'].append(qocTtyJDvIAmBaXfQLhFzuwnWkdjYe.get('category2_name').get('ko'))
   qocTtyJDvIAmBaXfQLhFzuwnWkdjgC=qocTtyJDvIAmBaXfQLhFzuwnWkdjse(qocTtyJDvIAmBaXfQLhFzuwnWkdjYe.get('broad_dt'))
   if qocTtyJDvIAmBaXfQLhFzuwnWkdjgC!='0':qocTtyJDvIAmBaXfQLhFzuwnWkdjYE['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(qocTtyJDvIAmBaXfQLhFzuwnWkdjgC[:4],qocTtyJDvIAmBaXfQLhFzuwnWkdjgC[4:6],qocTtyJDvIAmBaXfQLhFzuwnWkdjgC[6:])
   qocTtyJDvIAmBaXfQLhFzuwnWkdjKM =''
   qocTtyJDvIAmBaXfQLhFzuwnWkdjKe =''
   qocTtyJDvIAmBaXfQLhFzuwnWkdjKG=''
   qocTtyJDvIAmBaXfQLhFzuwnWkdjKp =''
   qocTtyJDvIAmBaXfQLhFzuwnWkdjKU =''
   for qocTtyJDvIAmBaXfQLhFzuwnWkdjKN in qocTtyJDvIAmBaXfQLhFzuwnWkdjYe.get('image'):
    if qocTtyJDvIAmBaXfQLhFzuwnWkdjKN.get('code')=='CAIP0900':qocTtyJDvIAmBaXfQLhFzuwnWkdjKM =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN.get('url')
    elif qocTtyJDvIAmBaXfQLhFzuwnWkdjKN.get('code')=='CAIP0200':qocTtyJDvIAmBaXfQLhFzuwnWkdjKe =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN.get('url')
    elif qocTtyJDvIAmBaXfQLhFzuwnWkdjKN.get('code')=='CAIP1800':qocTtyJDvIAmBaXfQLhFzuwnWkdjKG=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN.get('url')
    elif qocTtyJDvIAmBaXfQLhFzuwnWkdjKN.get('code')=='CAIP2000':qocTtyJDvIAmBaXfQLhFzuwnWkdjKp =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN.get('url')
    elif qocTtyJDvIAmBaXfQLhFzuwnWkdjKN.get('code')=='CAIP1900':qocTtyJDvIAmBaXfQLhFzuwnWkdjKU =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN.get('url')
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYE['saveinfo']['thumbnail']['poster']=qocTtyJDvIAmBaXfQLhFzuwnWkdjKM
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYE['saveinfo']['thumbnail']['thumb']=qocTtyJDvIAmBaXfQLhFzuwnWkdjKe
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYE['saveinfo']['thumbnail']['clearlogo']=qocTtyJDvIAmBaXfQLhFzuwnWkdjKG
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYE['saveinfo']['thumbnail']['icon']=qocTtyJDvIAmBaXfQLhFzuwnWkdjKp
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYE['saveinfo']['thumbnail']['banner']=qocTtyJDvIAmBaXfQLhFzuwnWkdjKU
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYE['saveinfo']['thumbnail']['fanart']=qocTtyJDvIAmBaXfQLhFzuwnWkdjKe
  else:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVO=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.API_DOMAIN+'/v2a/media/stream/info'
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVb=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.GetDefaultParams()
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVp={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['cookies']['tving_uuid'].split('-')[0],'uuid':qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.TV['cookies']['tving_uuid'],'deviceInfo':'PC_Chrome','noCache':qocTtyJDvIAmBaXfQLhFzuwnWkdjse(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.GetNoCache(1)),'wm':'Y',}
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVb.update(qocTtyJDvIAmBaXfQLhFzuwnWkdjVp)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVK=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.callRequestCookies('Get',qocTtyJDvIAmBaXfQLhFzuwnWkdjVO,payload=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,params=qocTtyJDvIAmBaXfQLhFzuwnWkdjVb,headers=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,cookies=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYl=json.loads(qocTtyJDvIAmBaXfQLhFzuwnWkdjVK.text)
   if not('content' in qocTtyJDvIAmBaXfQLhFzuwnWkdjYl['body']):return{}
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYe=qocTtyJDvIAmBaXfQLhFzuwnWkdjYl['body']['content']['info']['movie']
   qocTtyJDvIAmBaXfQLhFzuwnWkdjKE =qocTtyJDvIAmBaXfQLhFzuwnWkdjYe.get('name').get('ko').strip()
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYE['saveinfo']['infoLabels']['title']=qocTtyJDvIAmBaXfQLhFzuwnWkdjKE
   qocTtyJDvIAmBaXfQLhFzuwnWkdjKE +=u' (%s)'%(qocTtyJDvIAmBaXfQLhFzuwnWkdjYe.get('product_year'))
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYE['saveinfo']['title'] =qocTtyJDvIAmBaXfQLhFzuwnWkdjKE
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYE['saveinfo']['infoLabels']['mpaa'] =qocTtyJDvIAmBaXfQLhFzuwnWkdjrK.get(qocTtyJDvIAmBaXfQLhFzuwnWkdjYe.get('grade_code'))
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYE['saveinfo']['infoLabels']['plot'] =qocTtyJDvIAmBaXfQLhFzuwnWkdjYe.get('story').get('ko')
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYE['saveinfo']['infoLabels']['year'] =qocTtyJDvIAmBaXfQLhFzuwnWkdjYe.get('product_year')
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYE['saveinfo']['infoLabels']['studio'] =qocTtyJDvIAmBaXfQLhFzuwnWkdjYe.get('production')
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYE['saveinfo']['infoLabels']['duration']=qocTtyJDvIAmBaXfQLhFzuwnWkdjYe.get('duration')
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYE['saveinfo']['infoLabels']['cast'] =qocTtyJDvIAmBaXfQLhFzuwnWkdjYe.get('actor')
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYE['saveinfo']['infoLabels']['director']=qocTtyJDvIAmBaXfQLhFzuwnWkdjYe.get('director')
   if qocTtyJDvIAmBaXfQLhFzuwnWkdjYe.get('category1_name').get('ko')!='':
    qocTtyJDvIAmBaXfQLhFzuwnWkdjYE['saveinfo']['infoLabels']['genre'].append(qocTtyJDvIAmBaXfQLhFzuwnWkdjYe.get('category1_name').get('ko'))
   if qocTtyJDvIAmBaXfQLhFzuwnWkdjYe.get('category2_name').get('ko')!='':
    qocTtyJDvIAmBaXfQLhFzuwnWkdjYE['saveinfo']['infoLabels']['genre'].append(qocTtyJDvIAmBaXfQLhFzuwnWkdjYe.get('category2_name').get('ko'))
   qocTtyJDvIAmBaXfQLhFzuwnWkdjgC=qocTtyJDvIAmBaXfQLhFzuwnWkdjse(qocTtyJDvIAmBaXfQLhFzuwnWkdjYe.get('release_date'))
   if qocTtyJDvIAmBaXfQLhFzuwnWkdjgC!='0':qocTtyJDvIAmBaXfQLhFzuwnWkdjYE['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(qocTtyJDvIAmBaXfQLhFzuwnWkdjgC[:4],qocTtyJDvIAmBaXfQLhFzuwnWkdjgC[4:6],qocTtyJDvIAmBaXfQLhFzuwnWkdjgC[6:])
   qocTtyJDvIAmBaXfQLhFzuwnWkdjKM=''
   qocTtyJDvIAmBaXfQLhFzuwnWkdjKe =''
   qocTtyJDvIAmBaXfQLhFzuwnWkdjKG=''
   for qocTtyJDvIAmBaXfQLhFzuwnWkdjKN in qocTtyJDvIAmBaXfQLhFzuwnWkdjYe.get('image'):
    if qocTtyJDvIAmBaXfQLhFzuwnWkdjKN.get('code')=='CAIM2100':qocTtyJDvIAmBaXfQLhFzuwnWkdjKM =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN.get('url')
    elif qocTtyJDvIAmBaXfQLhFzuwnWkdjKN.get('code')=='CAIM0400':qocTtyJDvIAmBaXfQLhFzuwnWkdjKe =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN.get('url')
    elif qocTtyJDvIAmBaXfQLhFzuwnWkdjKN.get('code')=='CAIM1800':qocTtyJDvIAmBaXfQLhFzuwnWkdjKG=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.IMG_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjKN.get('url')
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYE['saveinfo']['thumbnail']['poster']=qocTtyJDvIAmBaXfQLhFzuwnWkdjKM
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYE['saveinfo']['thumbnail']['thumb']=qocTtyJDvIAmBaXfQLhFzuwnWkdjKM 
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYE['saveinfo']['thumbnail']['clearlogo']=qocTtyJDvIAmBaXfQLhFzuwnWkdjKG
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYE['saveinfo']['thumbnail']['fanart']=qocTtyJDvIAmBaXfQLhFzuwnWkdjKe
  return qocTtyJDvIAmBaXfQLhFzuwnWkdjYE
 def GetEuroChannelList(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg):
  qocTtyJDvIAmBaXfQLhFzuwnWkdjVe=[]
  try:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVE ='/v2/operator/highlights'
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVb=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.GetDefaultParams()
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVp={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':qocTtyJDvIAmBaXfQLhFzuwnWkdjse(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.GetNoCache(2))}
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVb.update(qocTtyJDvIAmBaXfQLhFzuwnWkdjVp)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVO=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.API_DOMAIN+qocTtyJDvIAmBaXfQLhFzuwnWkdjVE
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVK=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.callRequestCookies('Get',qocTtyJDvIAmBaXfQLhFzuwnWkdjVO,payload=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,params=qocTtyJDvIAmBaXfQLhFzuwnWkdjVb,headers=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV,cookies=qocTtyJDvIAmBaXfQLhFzuwnWkdjsV)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjVU=json.loads(qocTtyJDvIAmBaXfQLhFzuwnWkdjVK.text)
   if not('result' in qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']):return qocTtyJDvIAmBaXfQLhFzuwnWkdjVe,qocTtyJDvIAmBaXfQLhFzuwnWkdjKV
   qocTtyJDvIAmBaXfQLhFzuwnWkdjKg=qocTtyJDvIAmBaXfQLhFzuwnWkdjVU['body']['result']
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYM =qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.Get_Now_Datetime()
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYG=qocTtyJDvIAmBaXfQLhFzuwnWkdjYM+datetime.timedelta(days=-1)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYG=qocTtyJDvIAmBaXfQLhFzuwnWkdjsY(qocTtyJDvIAmBaXfQLhFzuwnWkdjYG.strftime('%Y%m%d'))
   for qocTtyJDvIAmBaXfQLhFzuwnWkdjVS in qocTtyJDvIAmBaXfQLhFzuwnWkdjKg:
    qocTtyJDvIAmBaXfQLhFzuwnWkdjYp=qocTtyJDvIAmBaXfQLhFzuwnWkdjsY(qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('content').get('banner_title2')[:8])
    if qocTtyJDvIAmBaXfQLhFzuwnWkdjYG<=qocTtyJDvIAmBaXfQLhFzuwnWkdjYp:
     qocTtyJDvIAmBaXfQLhFzuwnWkdjgY={'channel':qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('content').get('banner_sub_title3'),'title':qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('content').get('banner_title'),'subtitle':qocTtyJDvIAmBaXfQLhFzuwnWkdjVS.get('content').get('banner_sub_title2'),}
     qocTtyJDvIAmBaXfQLhFzuwnWkdjVe.append(qocTtyJDvIAmBaXfQLhFzuwnWkdjgY)
  except qocTtyJDvIAmBaXfQLhFzuwnWkdjsE as exception:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYb(exception)
  return qocTtyJDvIAmBaXfQLhFzuwnWkdjVe
 def Make_DecryptKey(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg,step,mediacode='000',timecode='000'):
  if step=='1':
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYU=qocTtyJDvIAmBaXfQLhFzuwnWkdjsp('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYS=qocTtyJDvIAmBaXfQLhFzuwnWkdjsp('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYU=qocTtyJDvIAmBaXfQLhFzuwnWkdjsp('kss2lym0kdw1lks3','utf-8')
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYS=qocTtyJDvIAmBaXfQLhFzuwnWkdjsp([qocTtyJDvIAmBaXfQLhFzuwnWkdjsU('*'),0x07,qocTtyJDvIAmBaXfQLhFzuwnWkdjsU('r'),qocTtyJDvIAmBaXfQLhFzuwnWkdjsU(';'),qocTtyJDvIAmBaXfQLhFzuwnWkdjsU('7'),0x05,0x1e,0x01,qocTtyJDvIAmBaXfQLhFzuwnWkdjsU('n'),qocTtyJDvIAmBaXfQLhFzuwnWkdjsU('D'),0x02,qocTtyJDvIAmBaXfQLhFzuwnWkdjsU('3'),qocTtyJDvIAmBaXfQLhFzuwnWkdjsU('*'),qocTtyJDvIAmBaXfQLhFzuwnWkdjsU('a'),qocTtyJDvIAmBaXfQLhFzuwnWkdjsU('&'),qocTtyJDvIAmBaXfQLhFzuwnWkdjsU('<')])
  return qocTtyJDvIAmBaXfQLhFzuwnWkdjYU,qocTtyJDvIAmBaXfQLhFzuwnWkdjYS
 def DecryptPlaintext(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg,ciphertext,encryption_key,init_vector):
  qocTtyJDvIAmBaXfQLhFzuwnWkdjYN=AES.new(encryption_key,AES.MODE_CBC,init_vector,)
  qocTtyJDvIAmBaXfQLhFzuwnWkdjYx=Padding.unpad(qocTtyJDvIAmBaXfQLhFzuwnWkdjYN.decrypt(base64.standard_b64decode(ciphertext)),16)
  return qocTtyJDvIAmBaXfQLhFzuwnWkdjYx.decode('utf-8')
 def Decrypt_Url(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg,ciphertext,mediacode,qocTtyJDvIAmBaXfQLhFzuwnWkdjCs):
  qocTtyJDvIAmBaXfQLhFzuwnWkdjYH=''
  qocTtyJDvIAmBaXfQLhFzuwnWkdjCR=''
  qocTtyJDvIAmBaXfQLhFzuwnWkdjCE=''
  try:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYU,qocTtyJDvIAmBaXfQLhFzuwnWkdjYS=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.Make_DecryptKey('1',mediacode=mediacode,timecode=qocTtyJDvIAmBaXfQLhFzuwnWkdjCs)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYP=json.loads(qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.DecryptPlaintext(ciphertext,qocTtyJDvIAmBaXfQLhFzuwnWkdjYU,qocTtyJDvIAmBaXfQLhFzuwnWkdjYS))
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYi =qocTtyJDvIAmBaXfQLhFzuwnWkdjYP.get('broad_url')
   qocTtyJDvIAmBaXfQLhFzuwnWkdjCR =qocTtyJDvIAmBaXfQLhFzuwnWkdjYP.get('watermark') if 'watermark' in qocTtyJDvIAmBaXfQLhFzuwnWkdjYP else ''
   qocTtyJDvIAmBaXfQLhFzuwnWkdjCE=qocTtyJDvIAmBaXfQLhFzuwnWkdjYP.get('watermarkKey')if 'watermarkKey' in qocTtyJDvIAmBaXfQLhFzuwnWkdjYP else ''
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYU,qocTtyJDvIAmBaXfQLhFzuwnWkdjYS=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.Make_DecryptKey('2',mediacode=mediacode,timecode=qocTtyJDvIAmBaXfQLhFzuwnWkdjCs)
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYH=qocTtyJDvIAmBaXfQLhFzuwnWkdjrg.DecryptPlaintext(qocTtyJDvIAmBaXfQLhFzuwnWkdjYi,qocTtyJDvIAmBaXfQLhFzuwnWkdjYU,qocTtyJDvIAmBaXfQLhFzuwnWkdjYS)
  except qocTtyJDvIAmBaXfQLhFzuwnWkdjsE as exception:
   qocTtyJDvIAmBaXfQLhFzuwnWkdjYb(exception)
  return qocTtyJDvIAmBaXfQLhFzuwnWkdjYH,qocTtyJDvIAmBaXfQLhFzuwnWkdjCR,qocTtyJDvIAmBaXfQLhFzuwnWkdjCE
# Created by pyminifier (https://github.com/liftoff/pyminifier)
