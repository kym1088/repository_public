__author__="NightRain"
kJnEgsjGdAQWcwuolYrMqpSmfICvaV=object
kJnEgsjGdAQWcwuolYrMqpSmfICvaR=None
kJnEgsjGdAQWcwuolYrMqpSmfICvaT=False
kJnEgsjGdAQWcwuolYrMqpSmfICvax=int
kJnEgsjGdAQWcwuolYrMqpSmfICvaX=range
kJnEgsjGdAQWcwuolYrMqpSmfICvah=True
kJnEgsjGdAQWcwuolYrMqpSmfICvae=Exception
kJnEgsjGdAQWcwuolYrMqpSmfICvaO=print
kJnEgsjGdAQWcwuolYrMqpSmfICvaP=str
kJnEgsjGdAQWcwuolYrMqpSmfICvai=list
kJnEgsjGdAQWcwuolYrMqpSmfICvaH=len
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import requests
import datetime
import random
kJnEgsjGdAQWcwuolYrMqpSmfICvLz={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
class kJnEgsjGdAQWcwuolYrMqpSmfICvLK(kJnEgsjGdAQWcwuolYrMqpSmfICvaV):
 def __init__(kJnEgsjGdAQWcwuolYrMqpSmfICvLB):
  kJnEgsjGdAQWcwuolYrMqpSmfICvLB.TVING_TOKEN =''
  kJnEgsjGdAQWcwuolYrMqpSmfICvLB.POC_USERINFO =''
  kJnEgsjGdAQWcwuolYrMqpSmfICvLB.TVING_UUID ='-'
  kJnEgsjGdAQWcwuolYrMqpSmfICvLB.TVING_MAINTOKEN=''
  kJnEgsjGdAQWcwuolYrMqpSmfICvLB.TVIGN_COOKIEKEY=''
  kJnEgsjGdAQWcwuolYrMqpSmfICvLB.TVING_LOCKKEY =''
  kJnEgsjGdAQWcwuolYrMqpSmfICvLB.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  kJnEgsjGdAQWcwuolYrMqpSmfICvLB.NETWORKCODE ='CSND0900'
  kJnEgsjGdAQWcwuolYrMqpSmfICvLB.OSCODE ='CSOD0900' 
  kJnEgsjGdAQWcwuolYrMqpSmfICvLB.TELECODE ='CSCD0900'
  kJnEgsjGdAQWcwuolYrMqpSmfICvLB.SCREENCODE ='CSSD0100'
  kJnEgsjGdAQWcwuolYrMqpSmfICvLB.LIVE_LIMIT =23
  kJnEgsjGdAQWcwuolYrMqpSmfICvLB.VOD_LIMIT =20
  kJnEgsjGdAQWcwuolYrMqpSmfICvLB.EPISODE_LIMIT =30 
  kJnEgsjGdAQWcwuolYrMqpSmfICvLB.SEARCH_LIMIT =80 
  kJnEgsjGdAQWcwuolYrMqpSmfICvLB.MOVIE_LIMIT =18
  kJnEgsjGdAQWcwuolYrMqpSmfICvLB.API_DOMAIN ='https://api.tving.com'
  kJnEgsjGdAQWcwuolYrMqpSmfICvLB.IMG_DOMAIN ='https://image.tving.com'
  kJnEgsjGdAQWcwuolYrMqpSmfICvLB.SEARCH_DOMAIN ='https://search.tving.com'
  kJnEgsjGdAQWcwuolYrMqpSmfICvLB.LOGIN_DOMAIN ='https://user.tving.com'
  kJnEgsjGdAQWcwuolYrMqpSmfICvLB.URL_DOMAIN ='https://www.tving.com'
  kJnEgsjGdAQWcwuolYrMqpSmfICvLB.MOVIE_LITE =['2610061','2610161','261062']
  kJnEgsjGdAQWcwuolYrMqpSmfICvLB.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
  kJnEgsjGdAQWcwuolYrMqpSmfICvLB.DEFAULT_HEADER ={'user-agent':kJnEgsjGdAQWcwuolYrMqpSmfICvLB.USER_AGENT}
  kJnEgsjGdAQWcwuolYrMqpSmfICvLB.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
 def callRequestCookies(kJnEgsjGdAQWcwuolYrMqpSmfICvLB,jobtype,kJnEgsjGdAQWcwuolYrMqpSmfICvKh,payload=kJnEgsjGdAQWcwuolYrMqpSmfICvaR,params=kJnEgsjGdAQWcwuolYrMqpSmfICvaR,headers=kJnEgsjGdAQWcwuolYrMqpSmfICvaR,cookies=kJnEgsjGdAQWcwuolYrMqpSmfICvaR,redirects=kJnEgsjGdAQWcwuolYrMqpSmfICvaT):
  kJnEgsjGdAQWcwuolYrMqpSmfICvLa=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.DEFAULT_HEADER
  if headers:kJnEgsjGdAQWcwuolYrMqpSmfICvLa.update(headers)
  if jobtype=='Get':
   kJnEgsjGdAQWcwuolYrMqpSmfICvLt=requests.get(kJnEgsjGdAQWcwuolYrMqpSmfICvKh,params=params,headers=kJnEgsjGdAQWcwuolYrMqpSmfICvLa,cookies=cookies,allow_redirects=redirects)
  else:
   kJnEgsjGdAQWcwuolYrMqpSmfICvLt=requests.post(kJnEgsjGdAQWcwuolYrMqpSmfICvKh,data=payload,params=params,headers=kJnEgsjGdAQWcwuolYrMqpSmfICvLa,cookies=cookies,allow_redirects=redirects)
  return kJnEgsjGdAQWcwuolYrMqpSmfICvLt
 def makeDefaultCookies(kJnEgsjGdAQWcwuolYrMqpSmfICvLB,vToken=kJnEgsjGdAQWcwuolYrMqpSmfICvaR,vUserinfo=kJnEgsjGdAQWcwuolYrMqpSmfICvaR):
  kJnEgsjGdAQWcwuolYrMqpSmfICvLV={}
  kJnEgsjGdAQWcwuolYrMqpSmfICvLV['_tving_token']=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.TVING_TOKEN if vToken==kJnEgsjGdAQWcwuolYrMqpSmfICvaR else vToken
  kJnEgsjGdAQWcwuolYrMqpSmfICvLV['POC_USERINFO']=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.POC_USERINFO if vToken==kJnEgsjGdAQWcwuolYrMqpSmfICvaR else vUserinfo
  if kJnEgsjGdAQWcwuolYrMqpSmfICvLB.TVING_MAINTOKEN!='':kJnEgsjGdAQWcwuolYrMqpSmfICvLV[kJnEgsjGdAQWcwuolYrMqpSmfICvLB.GLOBAL_COOKIENM['tv_maintoken']]=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.TVING_MAINTOKEN
  if kJnEgsjGdAQWcwuolYrMqpSmfICvLB.TVIGN_COOKIEKEY!='':kJnEgsjGdAQWcwuolYrMqpSmfICvLV[kJnEgsjGdAQWcwuolYrMqpSmfICvLB.GLOBAL_COOKIENM['tv_cookiekey']]=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.TVIGN_COOKIEKEY
  if kJnEgsjGdAQWcwuolYrMqpSmfICvLB.TVING_LOCKKEY !='':kJnEgsjGdAQWcwuolYrMqpSmfICvLV[kJnEgsjGdAQWcwuolYrMqpSmfICvLB.GLOBAL_COOKIENM['tv_lockkey']] =kJnEgsjGdAQWcwuolYrMqpSmfICvLB.TVING_LOCKKEY
  return kJnEgsjGdAQWcwuolYrMqpSmfICvLV
 def getDeviceStr(kJnEgsjGdAQWcwuolYrMqpSmfICvLB):
  kJnEgsjGdAQWcwuolYrMqpSmfICvLR=[]
  kJnEgsjGdAQWcwuolYrMqpSmfICvLR.append('Windows') 
  kJnEgsjGdAQWcwuolYrMqpSmfICvLR.append('Chrome') 
  kJnEgsjGdAQWcwuolYrMqpSmfICvLR.append('ko-KR') 
  kJnEgsjGdAQWcwuolYrMqpSmfICvLR.append('undefined') 
  kJnEgsjGdAQWcwuolYrMqpSmfICvLR.append('24') 
  kJnEgsjGdAQWcwuolYrMqpSmfICvLR.append(u'한국 표준시')
  kJnEgsjGdAQWcwuolYrMqpSmfICvLR.append('undefined') 
  kJnEgsjGdAQWcwuolYrMqpSmfICvLR.append('undefined') 
  kJnEgsjGdAQWcwuolYrMqpSmfICvLR.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  kJnEgsjGdAQWcwuolYrMqpSmfICvLT=''
  for kJnEgsjGdAQWcwuolYrMqpSmfICvLx in kJnEgsjGdAQWcwuolYrMqpSmfICvLR:
   kJnEgsjGdAQWcwuolYrMqpSmfICvLT+=kJnEgsjGdAQWcwuolYrMqpSmfICvLx+'|'
  return kJnEgsjGdAQWcwuolYrMqpSmfICvLT
 def SaveCredential(kJnEgsjGdAQWcwuolYrMqpSmfICvLB,kJnEgsjGdAQWcwuolYrMqpSmfICvLX):
  kJnEgsjGdAQWcwuolYrMqpSmfICvLB.TVING_TOKEN =kJnEgsjGdAQWcwuolYrMqpSmfICvLX.get('tving_token')
  kJnEgsjGdAQWcwuolYrMqpSmfICvLB.POC_USERINFO =kJnEgsjGdAQWcwuolYrMqpSmfICvLX.get('poc_userinfo')
  kJnEgsjGdAQWcwuolYrMqpSmfICvLB.TVING_UUID =kJnEgsjGdAQWcwuolYrMqpSmfICvLX.get('tving_uuid')
  kJnEgsjGdAQWcwuolYrMqpSmfICvLB.TVING_MAINTOKEN=kJnEgsjGdAQWcwuolYrMqpSmfICvLX.get('tving_maintoken')
  kJnEgsjGdAQWcwuolYrMqpSmfICvLB.TVIGN_COOKIEKEY=kJnEgsjGdAQWcwuolYrMqpSmfICvLX.get('tving_cookiekey')
  kJnEgsjGdAQWcwuolYrMqpSmfICvLB.TVING_LOCKKEY =kJnEgsjGdAQWcwuolYrMqpSmfICvLX.get('tving_lockkey')
 def LoadCredential(kJnEgsjGdAQWcwuolYrMqpSmfICvLB):
  kJnEgsjGdAQWcwuolYrMqpSmfICvLX={'tving_token':kJnEgsjGdAQWcwuolYrMqpSmfICvLB.TVING_TOKEN,'poc_userinfo':kJnEgsjGdAQWcwuolYrMqpSmfICvLB.POC_USERINFO,'tving_uuid':kJnEgsjGdAQWcwuolYrMqpSmfICvLB.TVING_UUID,'tving_maintoken':kJnEgsjGdAQWcwuolYrMqpSmfICvLB.TVING_MAINTOKEN,'tving_cookiekey':kJnEgsjGdAQWcwuolYrMqpSmfICvLB.TVIGN_COOKIEKEY,'tving_lockkey':kJnEgsjGdAQWcwuolYrMqpSmfICvLB.TVING_LOCKKEY}
  return kJnEgsjGdAQWcwuolYrMqpSmfICvLX
 def GetDefaultParams(kJnEgsjGdAQWcwuolYrMqpSmfICvLB):
  kJnEgsjGdAQWcwuolYrMqpSmfICvLh={'apiKey':kJnEgsjGdAQWcwuolYrMqpSmfICvLB.APIKEY,'networkCode':kJnEgsjGdAQWcwuolYrMqpSmfICvLB.NETWORKCODE,'osCode':kJnEgsjGdAQWcwuolYrMqpSmfICvLB.OSCODE,'teleCode':kJnEgsjGdAQWcwuolYrMqpSmfICvLB.TELECODE,'screenCode':kJnEgsjGdAQWcwuolYrMqpSmfICvLB.SCREENCODE}
  return kJnEgsjGdAQWcwuolYrMqpSmfICvLh
 def GetNoCache(kJnEgsjGdAQWcwuolYrMqpSmfICvLB,timetype=1):
  if timetype==1:
   return kJnEgsjGdAQWcwuolYrMqpSmfICvax(time.time())
  else:
   return kJnEgsjGdAQWcwuolYrMqpSmfICvax(time.time()*1000)
 def GetUniqueid(kJnEgsjGdAQWcwuolYrMqpSmfICvLB):
  kJnEgsjGdAQWcwuolYrMqpSmfICvLe=[0 for i in kJnEgsjGdAQWcwuolYrMqpSmfICvaX(256)]
  for i in kJnEgsjGdAQWcwuolYrMqpSmfICvaX(256):
   kJnEgsjGdAQWcwuolYrMqpSmfICvLe[i]='%02x'%(i)
  kJnEgsjGdAQWcwuolYrMqpSmfICvLO=kJnEgsjGdAQWcwuolYrMqpSmfICvax(4294967295*random.random())|0
  kJnEgsjGdAQWcwuolYrMqpSmfICvLP=kJnEgsjGdAQWcwuolYrMqpSmfICvLe[255&kJnEgsjGdAQWcwuolYrMqpSmfICvLO]+kJnEgsjGdAQWcwuolYrMqpSmfICvLe[kJnEgsjGdAQWcwuolYrMqpSmfICvLO>>8&255]+kJnEgsjGdAQWcwuolYrMqpSmfICvLe[kJnEgsjGdAQWcwuolYrMqpSmfICvLO>>16&255]+kJnEgsjGdAQWcwuolYrMqpSmfICvLe[kJnEgsjGdAQWcwuolYrMqpSmfICvLO>>24&255]
  return kJnEgsjGdAQWcwuolYrMqpSmfICvLP
 def GetCredential(kJnEgsjGdAQWcwuolYrMqpSmfICvLB,user_id,user_pw,login_type,user_pf):
  kJnEgsjGdAQWcwuolYrMqpSmfICvLi=kJnEgsjGdAQWcwuolYrMqpSmfICvaT
  kJnEgsjGdAQWcwuolYrMqpSmfICvLH=kJnEgsjGdAQWcwuolYrMqpSmfICvLD=kJnEgsjGdAQWcwuolYrMqpSmfICvKL=kJnEgsjGdAQWcwuolYrMqpSmfICvKz=kJnEgsjGdAQWcwuolYrMqpSmfICvKB='' 
  kJnEgsjGdAQWcwuolYrMqpSmfICvLU ='-'
  try:
   kJnEgsjGdAQWcwuolYrMqpSmfICvLF=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   kJnEgsjGdAQWcwuolYrMqpSmfICvLy={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com/main.do','csite':''}
   kJnEgsjGdAQWcwuolYrMqpSmfICvLb=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.callRequestCookies('Post',kJnEgsjGdAQWcwuolYrMqpSmfICvLF,payload=kJnEgsjGdAQWcwuolYrMqpSmfICvLy,params=kJnEgsjGdAQWcwuolYrMqpSmfICvaR,headers=kJnEgsjGdAQWcwuolYrMqpSmfICvaR,cookies=kJnEgsjGdAQWcwuolYrMqpSmfICvaR)
   for kJnEgsjGdAQWcwuolYrMqpSmfICvLN in kJnEgsjGdAQWcwuolYrMqpSmfICvLb.cookies:
    if kJnEgsjGdAQWcwuolYrMqpSmfICvLN.name=='_tving_token':
     kJnEgsjGdAQWcwuolYrMqpSmfICvLD=kJnEgsjGdAQWcwuolYrMqpSmfICvLN.value
    elif kJnEgsjGdAQWcwuolYrMqpSmfICvLN.name=='POC_USERINFO':
     kJnEgsjGdAQWcwuolYrMqpSmfICvKL=kJnEgsjGdAQWcwuolYrMqpSmfICvLN.value
   if kJnEgsjGdAQWcwuolYrMqpSmfICvLD=='':return kJnEgsjGdAQWcwuolYrMqpSmfICvLi
   kJnEgsjGdAQWcwuolYrMqpSmfICvLH=kJnEgsjGdAQWcwuolYrMqpSmfICvLD
   kJnEgsjGdAQWcwuolYrMqpSmfICvLD,kJnEgsjGdAQWcwuolYrMqpSmfICvKz,kJnEgsjGdAQWcwuolYrMqpSmfICvKB=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.GetProfileToken(kJnEgsjGdAQWcwuolYrMqpSmfICvLD,kJnEgsjGdAQWcwuolYrMqpSmfICvKL,user_pf)
   kJnEgsjGdAQWcwuolYrMqpSmfICvLi=kJnEgsjGdAQWcwuolYrMqpSmfICvah
   kJnEgsjGdAQWcwuolYrMqpSmfICvLU =kJnEgsjGdAQWcwuolYrMqpSmfICvLB.GetDeviceList(kJnEgsjGdAQWcwuolYrMqpSmfICvLD,kJnEgsjGdAQWcwuolYrMqpSmfICvKL)
   kJnEgsjGdAQWcwuolYrMqpSmfICvLU =kJnEgsjGdAQWcwuolYrMqpSmfICvLU+'-'+kJnEgsjGdAQWcwuolYrMqpSmfICvLB.GetUniqueid()
  except kJnEgsjGdAQWcwuolYrMqpSmfICvae as exception:
   kJnEgsjGdAQWcwuolYrMqpSmfICvLH=kJnEgsjGdAQWcwuolYrMqpSmfICvLD=kJnEgsjGdAQWcwuolYrMqpSmfICvKL=kJnEgsjGdAQWcwuolYrMqpSmfICvKz=kJnEgsjGdAQWcwuolYrMqpSmfICvKB=''
   kJnEgsjGdAQWcwuolYrMqpSmfICvLU='-'
   kJnEgsjGdAQWcwuolYrMqpSmfICvaO(exception)
  kJnEgsjGdAQWcwuolYrMqpSmfICvLX={'tving_token':kJnEgsjGdAQWcwuolYrMqpSmfICvLD,'poc_userinfo':kJnEgsjGdAQWcwuolYrMqpSmfICvKL,'tving_uuid':kJnEgsjGdAQWcwuolYrMqpSmfICvLU,'tving_maintoken':kJnEgsjGdAQWcwuolYrMqpSmfICvLH,'tving_cookiekey':kJnEgsjGdAQWcwuolYrMqpSmfICvKz,'tving_lockkey':kJnEgsjGdAQWcwuolYrMqpSmfICvKB}
  kJnEgsjGdAQWcwuolYrMqpSmfICvLB.SaveCredential(kJnEgsjGdAQWcwuolYrMqpSmfICvLX)
  return kJnEgsjGdAQWcwuolYrMqpSmfICvLi
 def Get_Now_Datetime(kJnEgsjGdAQWcwuolYrMqpSmfICvLB):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(kJnEgsjGdAQWcwuolYrMqpSmfICvLB,mediacode,sel_quality,stype,pvrmode='-'):
  kJnEgsjGdAQWcwuolYrMqpSmfICvKt=''
  kJnEgsjGdAQWcwuolYrMqpSmfICvKV=''
  kJnEgsjGdAQWcwuolYrMqpSmfICvKR=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.TVING_UUID 
  try:
   if stype!='tvingtv' and(pvrmode=='-' or stype!='onair'):
    kJnEgsjGdAQWcwuolYrMqpSmfICvKT ='/v2a/media/stream/info' 
    kJnEgsjGdAQWcwuolYrMqpSmfICvKx=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.GetDefaultParams()
    kJnEgsjGdAQWcwuolYrMqpSmfICvKX={'info':'N','mediaCode':mediacode,'noCache':kJnEgsjGdAQWcwuolYrMqpSmfICvaP(kJnEgsjGdAQWcwuolYrMqpSmfICvLB.GetNoCache(1)),'callingFrom':'HTML5','adReq':'adproxy','ooc':'','uuid':kJnEgsjGdAQWcwuolYrMqpSmfICvKR,'deviceInfo':'PC','wm':'Y'}
    kJnEgsjGdAQWcwuolYrMqpSmfICvKx.update(kJnEgsjGdAQWcwuolYrMqpSmfICvKX)
    kJnEgsjGdAQWcwuolYrMqpSmfICvKh=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.API_DOMAIN+kJnEgsjGdAQWcwuolYrMqpSmfICvKT
    kJnEgsjGdAQWcwuolYrMqpSmfICvLV=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.makeDefaultCookies()
    kJnEgsjGdAQWcwuolYrMqpSmfICvLb=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.callRequestCookies('Get',kJnEgsjGdAQWcwuolYrMqpSmfICvKh,payload=kJnEgsjGdAQWcwuolYrMqpSmfICvaR,params=kJnEgsjGdAQWcwuolYrMqpSmfICvKx,headers=kJnEgsjGdAQWcwuolYrMqpSmfICvaR,cookies=kJnEgsjGdAQWcwuolYrMqpSmfICvLV)
    kJnEgsjGdAQWcwuolYrMqpSmfICvKe=json.loads(kJnEgsjGdAQWcwuolYrMqpSmfICvLb.text)
    if not('stream' in kJnEgsjGdAQWcwuolYrMqpSmfICvKe['body']):return kJnEgsjGdAQWcwuolYrMqpSmfICvKt,kJnEgsjGdAQWcwuolYrMqpSmfICvKV 
    kJnEgsjGdAQWcwuolYrMqpSmfICvKO=kJnEgsjGdAQWcwuolYrMqpSmfICvKe['body']['stream']
    kJnEgsjGdAQWcwuolYrMqpSmfICvKP=kJnEgsjGdAQWcwuolYrMqpSmfICvKO['quality']
    kJnEgsjGdAQWcwuolYrMqpSmfICvKi=[]
    for kJnEgsjGdAQWcwuolYrMqpSmfICvKH in kJnEgsjGdAQWcwuolYrMqpSmfICvKP:
     if kJnEgsjGdAQWcwuolYrMqpSmfICvKH['active']=='Y':
      kJnEgsjGdAQWcwuolYrMqpSmfICvKi.append({kJnEgsjGdAQWcwuolYrMqpSmfICvLz.get(kJnEgsjGdAQWcwuolYrMqpSmfICvKH['code']):kJnEgsjGdAQWcwuolYrMqpSmfICvKH['code']})
    kJnEgsjGdAQWcwuolYrMqpSmfICvKU=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.CheckQuality(sel_quality,kJnEgsjGdAQWcwuolYrMqpSmfICvKi)
   else:
    for kJnEgsjGdAQWcwuolYrMqpSmfICvKF,kJnEgsjGdAQWcwuolYrMqpSmfICvza in kJnEgsjGdAQWcwuolYrMqpSmfICvLz.items():
     if kJnEgsjGdAQWcwuolYrMqpSmfICvza==sel_quality:
      kJnEgsjGdAQWcwuolYrMqpSmfICvKU=kJnEgsjGdAQWcwuolYrMqpSmfICvKF
  except kJnEgsjGdAQWcwuolYrMqpSmfICvae as exception:
   kJnEgsjGdAQWcwuolYrMqpSmfICvaO(exception)
   for kJnEgsjGdAQWcwuolYrMqpSmfICvKF,kJnEgsjGdAQWcwuolYrMqpSmfICvza in kJnEgsjGdAQWcwuolYrMqpSmfICvLz.items():
    if kJnEgsjGdAQWcwuolYrMqpSmfICvza==sel_quality:
     kJnEgsjGdAQWcwuolYrMqpSmfICvKU=kJnEgsjGdAQWcwuolYrMqpSmfICvKF
   return kJnEgsjGdAQWcwuolYrMqpSmfICvKt,kJnEgsjGdAQWcwuolYrMqpSmfICvKV
  kJnEgsjGdAQWcwuolYrMqpSmfICvaO(kJnEgsjGdAQWcwuolYrMqpSmfICvKU)
  try:
   kJnEgsjGdAQWcwuolYrMqpSmfICvKT ='/streaming/info'
   kJnEgsjGdAQWcwuolYrMqpSmfICvKx=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.GetDefaultParams()
   if stype=='onair':kJnEgsjGdAQWcwuolYrMqpSmfICvKx['osCode']='CSOD0400' 
   kJnEgsjGdAQWcwuolYrMqpSmfICvKy={'isTrusted':'false','NONE':'0','CAPTURING_PHASE':'1','AT_TARGET':'2','BUBBLING_PHASE':'3','type':'oocCreate','eventPhase':'0','bubbles':'false','cancelable':'false','defaultPrevented':'false','composed':'false','timeStamp':'2785.9800000005635','returnValue':'true','cancelBubble':'false'}
   kJnEgsjGdAQWcwuolYrMqpSmfICvKb=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.makeOocUrl(kJnEgsjGdAQWcwuolYrMqpSmfICvKy)
   kJnEgsjGdAQWcwuolYrMqpSmfICvKN=urllib.parse.quote(kJnEgsjGdAQWcwuolYrMqpSmfICvKb)
   kJnEgsjGdAQWcwuolYrMqpSmfICvKX={'info':'N','mediaCode':mediacode,'callingFrom':'HTML5','streamCode':kJnEgsjGdAQWcwuolYrMqpSmfICvKU,'adReq':'adproxy','ooc':kJnEgsjGdAQWcwuolYrMqpSmfICvKb,'uuid':kJnEgsjGdAQWcwuolYrMqpSmfICvKR,'deviceInfo':'PC'}
   kJnEgsjGdAQWcwuolYrMqpSmfICvKD =kJnEgsjGdAQWcwuolYrMqpSmfICvKx
   kJnEgsjGdAQWcwuolYrMqpSmfICvKD.update(kJnEgsjGdAQWcwuolYrMqpSmfICvKX)
   kJnEgsjGdAQWcwuolYrMqpSmfICvKh=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.URL_DOMAIN+kJnEgsjGdAQWcwuolYrMqpSmfICvKT
   kJnEgsjGdAQWcwuolYrMqpSmfICvzL={'origin':'https://www.tving.com'}
   if stype=='onair':kJnEgsjGdAQWcwuolYrMqpSmfICvzL['Referer']='https://www.tving.com/live/player/'+mediacode
   else: kJnEgsjGdAQWcwuolYrMqpSmfICvzL['Referer']='https://www.tving.com/vod/player/'+mediacode
   kJnEgsjGdAQWcwuolYrMqpSmfICvLV=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.makeDefaultCookies()
   kJnEgsjGdAQWcwuolYrMqpSmfICvLV['onClickEvent2']=kJnEgsjGdAQWcwuolYrMqpSmfICvKN
   kJnEgsjGdAQWcwuolYrMqpSmfICvLb=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.callRequestCookies('Post',kJnEgsjGdAQWcwuolYrMqpSmfICvKh,payload=kJnEgsjGdAQWcwuolYrMqpSmfICvKD,params=kJnEgsjGdAQWcwuolYrMqpSmfICvaR,headers=kJnEgsjGdAQWcwuolYrMqpSmfICvzL,cookies=kJnEgsjGdAQWcwuolYrMqpSmfICvLV,redirects=kJnEgsjGdAQWcwuolYrMqpSmfICvaT)
   kJnEgsjGdAQWcwuolYrMqpSmfICvaO(kJnEgsjGdAQWcwuolYrMqpSmfICvLb.status_code)
   kJnEgsjGdAQWcwuolYrMqpSmfICvKe=json.loads(kJnEgsjGdAQWcwuolYrMqpSmfICvLb.text)
   if 'drm_license_assertion' in kJnEgsjGdAQWcwuolYrMqpSmfICvKe['stream']:
    kJnEgsjGdAQWcwuolYrMqpSmfICvKV =kJnEgsjGdAQWcwuolYrMqpSmfICvKe['stream']['drm_license_assertion']
    kJnEgsjGdAQWcwuolYrMqpSmfICvKt=kJnEgsjGdAQWcwuolYrMqpSmfICvKe['stream']['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in kJnEgsjGdAQWcwuolYrMqpSmfICvKe['stream']['broadcast']):return kJnEgsjGdAQWcwuolYrMqpSmfICvKt,kJnEgsjGdAQWcwuolYrMqpSmfICvKV
    kJnEgsjGdAQWcwuolYrMqpSmfICvKt=kJnEgsjGdAQWcwuolYrMqpSmfICvKe['stream']['broadcast']['broad_url']
  except kJnEgsjGdAQWcwuolYrMqpSmfICvae as exception:
   kJnEgsjGdAQWcwuolYrMqpSmfICvaO(exception)
  return kJnEgsjGdAQWcwuolYrMqpSmfICvKt,kJnEgsjGdAQWcwuolYrMqpSmfICvKV
 def CheckQuality(kJnEgsjGdAQWcwuolYrMqpSmfICvLB,sel_qt,kJnEgsjGdAQWcwuolYrMqpSmfICvKi):
  for kJnEgsjGdAQWcwuolYrMqpSmfICvzK in kJnEgsjGdAQWcwuolYrMqpSmfICvKi:
   if sel_qt>=kJnEgsjGdAQWcwuolYrMqpSmfICvai(kJnEgsjGdAQWcwuolYrMqpSmfICvzK)[0]:return kJnEgsjGdAQWcwuolYrMqpSmfICvzK.get(kJnEgsjGdAQWcwuolYrMqpSmfICvai(kJnEgsjGdAQWcwuolYrMqpSmfICvzK)[0])
   kJnEgsjGdAQWcwuolYrMqpSmfICvzB=kJnEgsjGdAQWcwuolYrMqpSmfICvzK.get(kJnEgsjGdAQWcwuolYrMqpSmfICvai(kJnEgsjGdAQWcwuolYrMqpSmfICvzK)[0])
  return kJnEgsjGdAQWcwuolYrMqpSmfICvzB
 def makeOocUrl(kJnEgsjGdAQWcwuolYrMqpSmfICvLB,kJnEgsjGdAQWcwuolYrMqpSmfICvKy):
  kJnEgsjGdAQWcwuolYrMqpSmfICvKh=''
  for kJnEgsjGdAQWcwuolYrMqpSmfICvKF,kJnEgsjGdAQWcwuolYrMqpSmfICvza in kJnEgsjGdAQWcwuolYrMqpSmfICvKy.items():
   kJnEgsjGdAQWcwuolYrMqpSmfICvKh+="%s=%s^"%(kJnEgsjGdAQWcwuolYrMqpSmfICvKF,kJnEgsjGdAQWcwuolYrMqpSmfICvza)
  return kJnEgsjGdAQWcwuolYrMqpSmfICvKh
 def GetLiveChannelList(kJnEgsjGdAQWcwuolYrMqpSmfICvLB,stype,page_int):
  kJnEgsjGdAQWcwuolYrMqpSmfICvzt=[]
  kJnEgsjGdAQWcwuolYrMqpSmfICvzV=kJnEgsjGdAQWcwuolYrMqpSmfICvaT
  try:
   kJnEgsjGdAQWcwuolYrMqpSmfICvKT ='/v2/media/lives'
   if stype=='onair':
    kJnEgsjGdAQWcwuolYrMqpSmfICvzR='CPCS0100,CPCS0400'
   else:
    kJnEgsjGdAQWcwuolYrMqpSmfICvzR='CPCS0300'
   kJnEgsjGdAQWcwuolYrMqpSmfICvKx=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.GetDefaultParams()
   kJnEgsjGdAQWcwuolYrMqpSmfICvKX={'pageNo':kJnEgsjGdAQWcwuolYrMqpSmfICvaP(page_int),'pageSize':kJnEgsjGdAQWcwuolYrMqpSmfICvaP(kJnEgsjGdAQWcwuolYrMqpSmfICvLB.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':kJnEgsjGdAQWcwuolYrMqpSmfICvzR,'_':kJnEgsjGdAQWcwuolYrMqpSmfICvaP(kJnEgsjGdAQWcwuolYrMqpSmfICvLB.GetNoCache(2))}
   kJnEgsjGdAQWcwuolYrMqpSmfICvKx.update(kJnEgsjGdAQWcwuolYrMqpSmfICvKX)
   kJnEgsjGdAQWcwuolYrMqpSmfICvKh=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.API_DOMAIN+kJnEgsjGdAQWcwuolYrMqpSmfICvKT
   kJnEgsjGdAQWcwuolYrMqpSmfICvLV=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.makeDefaultCookies()
   kJnEgsjGdAQWcwuolYrMqpSmfICvLb=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.callRequestCookies('Get',kJnEgsjGdAQWcwuolYrMqpSmfICvKh,payload=kJnEgsjGdAQWcwuolYrMqpSmfICvaR,params=kJnEgsjGdAQWcwuolYrMqpSmfICvKx,headers=kJnEgsjGdAQWcwuolYrMqpSmfICvaR,cookies=kJnEgsjGdAQWcwuolYrMqpSmfICvLV)
   kJnEgsjGdAQWcwuolYrMqpSmfICvKe=json.loads(kJnEgsjGdAQWcwuolYrMqpSmfICvLb.text)
   if not('result' in kJnEgsjGdAQWcwuolYrMqpSmfICvKe['body']):return kJnEgsjGdAQWcwuolYrMqpSmfICvzt,kJnEgsjGdAQWcwuolYrMqpSmfICvzV
   kJnEgsjGdAQWcwuolYrMqpSmfICvzT=kJnEgsjGdAQWcwuolYrMqpSmfICvKe['body']['result']
   for kJnEgsjGdAQWcwuolYrMqpSmfICvKH in kJnEgsjGdAQWcwuolYrMqpSmfICvzT:
    kJnEgsjGdAQWcwuolYrMqpSmfICvzx={}
    kJnEgsjGdAQWcwuolYrMqpSmfICvzx['mediatype']='video'
    kJnEgsjGdAQWcwuolYrMqpSmfICvzX=kJnEgsjGdAQWcwuolYrMqpSmfICvzO=kJnEgsjGdAQWcwuolYrMqpSmfICvzP=kJnEgsjGdAQWcwuolYrMqpSmfICvzi=''
    kJnEgsjGdAQWcwuolYrMqpSmfICvzh=kJnEgsjGdAQWcwuolYrMqpSmfICvzy=''
    kJnEgsjGdAQWcwuolYrMqpSmfICvze=kJnEgsjGdAQWcwuolYrMqpSmfICvKH['live_code']
    kJnEgsjGdAQWcwuolYrMqpSmfICvzX =kJnEgsjGdAQWcwuolYrMqpSmfICvKH['schedule']['channel']['name']['ko']
    if kJnEgsjGdAQWcwuolYrMqpSmfICvKH['schedule']['episode']!=kJnEgsjGdAQWcwuolYrMqpSmfICvaR:
     kJnEgsjGdAQWcwuolYrMqpSmfICvzO =kJnEgsjGdAQWcwuolYrMqpSmfICvKH['schedule']['program']['name']['ko']
     kJnEgsjGdAQWcwuolYrMqpSmfICvzO =kJnEgsjGdAQWcwuolYrMqpSmfICvzO+', '+kJnEgsjGdAQWcwuolYrMqpSmfICvaP(kJnEgsjGdAQWcwuolYrMqpSmfICvKH['schedule']['episode']['frequency'])+'회'
     if kJnEgsjGdAQWcwuolYrMqpSmfICvKH['schedule']['episode']['image']!=[]:
      kJnEgsjGdAQWcwuolYrMqpSmfICvzP=kJnEgsjGdAQWcwuolYrMqpSmfICvKH['schedule']['episode']['image'][0]['url']
     kJnEgsjGdAQWcwuolYrMqpSmfICvzi=kJnEgsjGdAQWcwuolYrMqpSmfICvKH['schedule']['episode']['synopsis']['ko']
    else:
     kJnEgsjGdAQWcwuolYrMqpSmfICvzO =kJnEgsjGdAQWcwuolYrMqpSmfICvKH['schedule']['program']['name']['ko']
     if kJnEgsjGdAQWcwuolYrMqpSmfICvKH['schedule']['program']['image']!=[]:
      kJnEgsjGdAQWcwuolYrMqpSmfICvzP=kJnEgsjGdAQWcwuolYrMqpSmfICvKH['schedule']['program']['image'][0]['url']
     kJnEgsjGdAQWcwuolYrMqpSmfICvzi=kJnEgsjGdAQWcwuolYrMqpSmfICvKH['schedule']['program']['synopsis']['ko']
    kJnEgsjGdAQWcwuolYrMqpSmfICvzx['title'] =kJnEgsjGdAQWcwuolYrMqpSmfICvKH['schedule']['program']['name']['ko']
    kJnEgsjGdAQWcwuolYrMqpSmfICvzx['studio'] =kJnEgsjGdAQWcwuolYrMqpSmfICvzX
    try:
     kJnEgsjGdAQWcwuolYrMqpSmfICvzH=[]
     for kJnEgsjGdAQWcwuolYrMqpSmfICvzU in kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('schedule').get('program').get('actor'):kJnEgsjGdAQWcwuolYrMqpSmfICvzH.append(kJnEgsjGdAQWcwuolYrMqpSmfICvzU)
     if kJnEgsjGdAQWcwuolYrMqpSmfICvzH[0]!='' and kJnEgsjGdAQWcwuolYrMqpSmfICvzH[0]!=u'없음':kJnEgsjGdAQWcwuolYrMqpSmfICvzx['cast']=kJnEgsjGdAQWcwuolYrMqpSmfICvzH
    except:
     kJnEgsjGdAQWcwuolYrMqpSmfICvaR
    try:
     kJnEgsjGdAQWcwuolYrMqpSmfICvzF=[]
     if kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('schedule').get('program').get('category1_name').get('ko')!='':
      kJnEgsjGdAQWcwuolYrMqpSmfICvzF.append(kJnEgsjGdAQWcwuolYrMqpSmfICvKH['schedule']['program']['category1_name']['ko'])
     if kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('schedule').get('program').get('category2_name').get('ko')!='':
      kJnEgsjGdAQWcwuolYrMqpSmfICvzF.append(kJnEgsjGdAQWcwuolYrMqpSmfICvKH['schedule']['program']['category2_name']['ko'])
     if kJnEgsjGdAQWcwuolYrMqpSmfICvzF[0]!='':kJnEgsjGdAQWcwuolYrMqpSmfICvzx['genre']=kJnEgsjGdAQWcwuolYrMqpSmfICvzF
    except:
     kJnEgsjGdAQWcwuolYrMqpSmfICvaR
    if kJnEgsjGdAQWcwuolYrMqpSmfICvzP=='':
     kJnEgsjGdAQWcwuolYrMqpSmfICvzP=kJnEgsjGdAQWcwuolYrMqpSmfICvKH['schedule']['channel']['image'][0]['url']
    if kJnEgsjGdAQWcwuolYrMqpSmfICvzP!='':kJnEgsjGdAQWcwuolYrMqpSmfICvzP=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.IMG_DOMAIN+kJnEgsjGdAQWcwuolYrMqpSmfICvzP
    kJnEgsjGdAQWcwuolYrMqpSmfICvzh=kJnEgsjGdAQWcwuolYrMqpSmfICvaP(kJnEgsjGdAQWcwuolYrMqpSmfICvKH['schedule']['broadcast_start_time'])[8:12]
    kJnEgsjGdAQWcwuolYrMqpSmfICvzy =kJnEgsjGdAQWcwuolYrMqpSmfICvaP(kJnEgsjGdAQWcwuolYrMqpSmfICvKH['schedule']['broadcast_end_time'])[8:12]
    kJnEgsjGdAQWcwuolYrMqpSmfICvzb={'channel':kJnEgsjGdAQWcwuolYrMqpSmfICvzX,'title':kJnEgsjGdAQWcwuolYrMqpSmfICvzO,'mediacode':kJnEgsjGdAQWcwuolYrMqpSmfICvze,'thumbnail':kJnEgsjGdAQWcwuolYrMqpSmfICvzP,'synopsis':kJnEgsjGdAQWcwuolYrMqpSmfICvzi,'channelepg':' [%s:%s ~ %s:%s]'%(kJnEgsjGdAQWcwuolYrMqpSmfICvzh[0:2],kJnEgsjGdAQWcwuolYrMqpSmfICvzh[2:],kJnEgsjGdAQWcwuolYrMqpSmfICvzy[0:2],kJnEgsjGdAQWcwuolYrMqpSmfICvzy[2:]),'info':kJnEgsjGdAQWcwuolYrMqpSmfICvzx}
    kJnEgsjGdAQWcwuolYrMqpSmfICvzt.append(kJnEgsjGdAQWcwuolYrMqpSmfICvzb)
   if kJnEgsjGdAQWcwuolYrMqpSmfICvKe['body']['has_more']=='Y':kJnEgsjGdAQWcwuolYrMqpSmfICvzV=kJnEgsjGdAQWcwuolYrMqpSmfICvah
  except kJnEgsjGdAQWcwuolYrMqpSmfICvae as exception:
   kJnEgsjGdAQWcwuolYrMqpSmfICvaO(exception)
  return kJnEgsjGdAQWcwuolYrMqpSmfICvzt,kJnEgsjGdAQWcwuolYrMqpSmfICvzV
 def GetProgramList(kJnEgsjGdAQWcwuolYrMqpSmfICvLB,genre,orderby,page_int,landyn=kJnEgsjGdAQWcwuolYrMqpSmfICvaT):
  kJnEgsjGdAQWcwuolYrMqpSmfICvzt=[]
  kJnEgsjGdAQWcwuolYrMqpSmfICvzV=kJnEgsjGdAQWcwuolYrMqpSmfICvaT
  try:
   kJnEgsjGdAQWcwuolYrMqpSmfICvKT ='/v2/media/episodes'
   kJnEgsjGdAQWcwuolYrMqpSmfICvKx=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.GetDefaultParams()
   kJnEgsjGdAQWcwuolYrMqpSmfICvKX={'pageNo':kJnEgsjGdAQWcwuolYrMqpSmfICvaP(page_int),'pageSize':kJnEgsjGdAQWcwuolYrMqpSmfICvaP(kJnEgsjGdAQWcwuolYrMqpSmfICvLB.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','_':kJnEgsjGdAQWcwuolYrMqpSmfICvaP(kJnEgsjGdAQWcwuolYrMqpSmfICvLB.GetNoCache(2))}
   if genre!='all':kJnEgsjGdAQWcwuolYrMqpSmfICvKX['multiCategoryCode']=genre
   kJnEgsjGdAQWcwuolYrMqpSmfICvKx.update(kJnEgsjGdAQWcwuolYrMqpSmfICvKX)
   kJnEgsjGdAQWcwuolYrMqpSmfICvKh=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.API_DOMAIN+kJnEgsjGdAQWcwuolYrMqpSmfICvKT
   kJnEgsjGdAQWcwuolYrMqpSmfICvLV=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.makeDefaultCookies()
   kJnEgsjGdAQWcwuolYrMqpSmfICvLb=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.callRequestCookies('Get',kJnEgsjGdAQWcwuolYrMqpSmfICvKh,payload=kJnEgsjGdAQWcwuolYrMqpSmfICvaR,params=kJnEgsjGdAQWcwuolYrMqpSmfICvKx,headers=kJnEgsjGdAQWcwuolYrMqpSmfICvaR,cookies=kJnEgsjGdAQWcwuolYrMqpSmfICvLV)
   kJnEgsjGdAQWcwuolYrMqpSmfICvKe=json.loads(kJnEgsjGdAQWcwuolYrMqpSmfICvLb.text)
   if not('result' in kJnEgsjGdAQWcwuolYrMqpSmfICvKe['body']):return kJnEgsjGdAQWcwuolYrMqpSmfICvzt,kJnEgsjGdAQWcwuolYrMqpSmfICvzV
   kJnEgsjGdAQWcwuolYrMqpSmfICvzT=kJnEgsjGdAQWcwuolYrMqpSmfICvKe['body']['result']
   for kJnEgsjGdAQWcwuolYrMqpSmfICvKH in kJnEgsjGdAQWcwuolYrMqpSmfICvzT:
    kJnEgsjGdAQWcwuolYrMqpSmfICvzN=kJnEgsjGdAQWcwuolYrMqpSmfICvKH['program']['code']
    kJnEgsjGdAQWcwuolYrMqpSmfICvzO =kJnEgsjGdAQWcwuolYrMqpSmfICvKH['program']['name']['ko']
    kJnEgsjGdAQWcwuolYrMqpSmfICvzP =kJnEgsjGdAQWcwuolYrMqpSmfICvLB.IMG_DOMAIN+kJnEgsjGdAQWcwuolYrMqpSmfICvKH['program']['image'][0]['url']
    kJnEgsjGdAQWcwuolYrMqpSmfICvzD='CAIP0200' if landyn else 'CAIP0900' 
    for kJnEgsjGdAQWcwuolYrMqpSmfICvBL in kJnEgsjGdAQWcwuolYrMqpSmfICvKH['program']['image']:
     if kJnEgsjGdAQWcwuolYrMqpSmfICvBL['code']==kJnEgsjGdAQWcwuolYrMqpSmfICvzD:
      kJnEgsjGdAQWcwuolYrMqpSmfICvzP =kJnEgsjGdAQWcwuolYrMqpSmfICvLB.IMG_DOMAIN+kJnEgsjGdAQWcwuolYrMqpSmfICvBL['url']
      break
    kJnEgsjGdAQWcwuolYrMqpSmfICvzi =kJnEgsjGdAQWcwuolYrMqpSmfICvKH['program']['synopsis']['ko']
    kJnEgsjGdAQWcwuolYrMqpSmfICvBK=kJnEgsjGdAQWcwuolYrMqpSmfICvKH['program']['channel_code']
    kJnEgsjGdAQWcwuolYrMqpSmfICvzx={}
    kJnEgsjGdAQWcwuolYrMqpSmfICvzx['title'] =kJnEgsjGdAQWcwuolYrMqpSmfICvzO 
    kJnEgsjGdAQWcwuolYrMqpSmfICvzx['mediatype']='episode' 
    try:
     kJnEgsjGdAQWcwuolYrMqpSmfICvzH=[]
     for kJnEgsjGdAQWcwuolYrMqpSmfICvzU in kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('program').get('actor'):kJnEgsjGdAQWcwuolYrMqpSmfICvzH.append(kJnEgsjGdAQWcwuolYrMqpSmfICvzU)
     if kJnEgsjGdAQWcwuolYrMqpSmfICvzH[0]!='' and kJnEgsjGdAQWcwuolYrMqpSmfICvzH[0]!='-':kJnEgsjGdAQWcwuolYrMqpSmfICvzx['cast']=kJnEgsjGdAQWcwuolYrMqpSmfICvzH
    except:
     kJnEgsjGdAQWcwuolYrMqpSmfICvaR
    try:
     kJnEgsjGdAQWcwuolYrMqpSmfICvBz=[]
     for kJnEgsjGdAQWcwuolYrMqpSmfICvBa in kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('program').get('director'):kJnEgsjGdAQWcwuolYrMqpSmfICvBz.append(kJnEgsjGdAQWcwuolYrMqpSmfICvBa)
     if kJnEgsjGdAQWcwuolYrMqpSmfICvBz[0]!='' and kJnEgsjGdAQWcwuolYrMqpSmfICvBz[0]!='-':kJnEgsjGdAQWcwuolYrMqpSmfICvzx['director']=kJnEgsjGdAQWcwuolYrMqpSmfICvBz
    except:
     kJnEgsjGdAQWcwuolYrMqpSmfICvaR
    kJnEgsjGdAQWcwuolYrMqpSmfICvzF=[]
    if kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('program').get('category1_name').get('ko')!='':
     kJnEgsjGdAQWcwuolYrMqpSmfICvzF.append(kJnEgsjGdAQWcwuolYrMqpSmfICvKH['program']['category1_name']['ko'])
    if kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('program').get('category2_name').get('ko')!='':
     kJnEgsjGdAQWcwuolYrMqpSmfICvzF.append(kJnEgsjGdAQWcwuolYrMqpSmfICvKH['program']['category2_name']['ko'])
    if kJnEgsjGdAQWcwuolYrMqpSmfICvzF[0]!='':kJnEgsjGdAQWcwuolYrMqpSmfICvzx['genre']=kJnEgsjGdAQWcwuolYrMqpSmfICvzF
    try:
     if kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('program').get('product_year'):kJnEgsjGdAQWcwuolYrMqpSmfICvzx['year']=kJnEgsjGdAQWcwuolYrMqpSmfICvKH['program']['product_year']
     if 'broad_dt' in kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('program'):
      kJnEgsjGdAQWcwuolYrMqpSmfICvBt=kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('program').get('broad_dt')
      kJnEgsjGdAQWcwuolYrMqpSmfICvzx['aired']='%s-%s-%s'%(kJnEgsjGdAQWcwuolYrMqpSmfICvBt[:4],kJnEgsjGdAQWcwuolYrMqpSmfICvBt[4:6],kJnEgsjGdAQWcwuolYrMqpSmfICvBt[6:])
    except:
     kJnEgsjGdAQWcwuolYrMqpSmfICvaR
    kJnEgsjGdAQWcwuolYrMqpSmfICvzb={'program':kJnEgsjGdAQWcwuolYrMqpSmfICvzN,'title':kJnEgsjGdAQWcwuolYrMqpSmfICvzO,'thumbnail':kJnEgsjGdAQWcwuolYrMqpSmfICvzP,'synopsis':kJnEgsjGdAQWcwuolYrMqpSmfICvzi,'channel':kJnEgsjGdAQWcwuolYrMqpSmfICvBK,'info':kJnEgsjGdAQWcwuolYrMqpSmfICvzx}
    kJnEgsjGdAQWcwuolYrMqpSmfICvzt.append(kJnEgsjGdAQWcwuolYrMqpSmfICvzb)
   if kJnEgsjGdAQWcwuolYrMqpSmfICvKe['body']['has_more']=='Y':kJnEgsjGdAQWcwuolYrMqpSmfICvzV=kJnEgsjGdAQWcwuolYrMqpSmfICvah
  except kJnEgsjGdAQWcwuolYrMqpSmfICvae as exception:
   kJnEgsjGdAQWcwuolYrMqpSmfICvaO(exception)
  return kJnEgsjGdAQWcwuolYrMqpSmfICvzt,kJnEgsjGdAQWcwuolYrMqpSmfICvzV
 def GetEpisodoList(kJnEgsjGdAQWcwuolYrMqpSmfICvLB,program_code,page_int,orderby='desc'):
  kJnEgsjGdAQWcwuolYrMqpSmfICvzt=[]
  kJnEgsjGdAQWcwuolYrMqpSmfICvzV=kJnEgsjGdAQWcwuolYrMqpSmfICvaT
  try:
   kJnEgsjGdAQWcwuolYrMqpSmfICvKT ='/v2/media/frequency/program/'+program_code
   kJnEgsjGdAQWcwuolYrMqpSmfICvKx=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.GetDefaultParams()
   kJnEgsjGdAQWcwuolYrMqpSmfICvKX={'pageNo':'1','pageSize':'10','order':'new','free':'all','adult':'all','scope':'all','_':kJnEgsjGdAQWcwuolYrMqpSmfICvaP(kJnEgsjGdAQWcwuolYrMqpSmfICvLB.GetNoCache(2))}
   kJnEgsjGdAQWcwuolYrMqpSmfICvKx.update(kJnEgsjGdAQWcwuolYrMqpSmfICvKX)
   kJnEgsjGdAQWcwuolYrMqpSmfICvKh=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.API_DOMAIN+kJnEgsjGdAQWcwuolYrMqpSmfICvKT
   kJnEgsjGdAQWcwuolYrMqpSmfICvLV=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.makeDefaultCookies()
   kJnEgsjGdAQWcwuolYrMqpSmfICvLb=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.callRequestCookies('Get',kJnEgsjGdAQWcwuolYrMqpSmfICvKh,payload=kJnEgsjGdAQWcwuolYrMqpSmfICvaR,params=kJnEgsjGdAQWcwuolYrMqpSmfICvKx,headers=kJnEgsjGdAQWcwuolYrMqpSmfICvaR,cookies=kJnEgsjGdAQWcwuolYrMqpSmfICvLV)
   kJnEgsjGdAQWcwuolYrMqpSmfICvKe=json.loads(kJnEgsjGdAQWcwuolYrMqpSmfICvLb.text)
   if not('result' in kJnEgsjGdAQWcwuolYrMqpSmfICvKe['body']):return kJnEgsjGdAQWcwuolYrMqpSmfICvzt,kJnEgsjGdAQWcwuolYrMqpSmfICvzV
   kJnEgsjGdAQWcwuolYrMqpSmfICvzT=kJnEgsjGdAQWcwuolYrMqpSmfICvKe['body']['result']
   kJnEgsjGdAQWcwuolYrMqpSmfICvBV=kJnEgsjGdAQWcwuolYrMqpSmfICvax(kJnEgsjGdAQWcwuolYrMqpSmfICvKe['body']['total_count'])
   kJnEgsjGdAQWcwuolYrMqpSmfICvBR =kJnEgsjGdAQWcwuolYrMqpSmfICvax(kJnEgsjGdAQWcwuolYrMqpSmfICvBV//(kJnEgsjGdAQWcwuolYrMqpSmfICvLB.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    kJnEgsjGdAQWcwuolYrMqpSmfICvBT =(kJnEgsjGdAQWcwuolYrMqpSmfICvBV-1)-((page_int-1)*kJnEgsjGdAQWcwuolYrMqpSmfICvLB.EPISODE_LIMIT)
   else:
    kJnEgsjGdAQWcwuolYrMqpSmfICvBT =(page_int-1)*kJnEgsjGdAQWcwuolYrMqpSmfICvLB.EPISODE_LIMIT
   for i in kJnEgsjGdAQWcwuolYrMqpSmfICvaX(kJnEgsjGdAQWcwuolYrMqpSmfICvLB.EPISODE_LIMIT):
    if orderby=='desc':
     kJnEgsjGdAQWcwuolYrMqpSmfICvBx=kJnEgsjGdAQWcwuolYrMqpSmfICvBT-i
     if kJnEgsjGdAQWcwuolYrMqpSmfICvBx<0:break
    else:
     kJnEgsjGdAQWcwuolYrMqpSmfICvBx=kJnEgsjGdAQWcwuolYrMqpSmfICvBT+i
     if kJnEgsjGdAQWcwuolYrMqpSmfICvBx>=kJnEgsjGdAQWcwuolYrMqpSmfICvBV:break
    kJnEgsjGdAQWcwuolYrMqpSmfICvBX=kJnEgsjGdAQWcwuolYrMqpSmfICvzT[kJnEgsjGdAQWcwuolYrMqpSmfICvBx]['episode']['code']
    kJnEgsjGdAQWcwuolYrMqpSmfICvzO =kJnEgsjGdAQWcwuolYrMqpSmfICvzT[kJnEgsjGdAQWcwuolYrMqpSmfICvBx]['vod_name']['ko']
    kJnEgsjGdAQWcwuolYrMqpSmfICvBh =''
    try:
     kJnEgsjGdAQWcwuolYrMqpSmfICvBt=kJnEgsjGdAQWcwuolYrMqpSmfICvaP(kJnEgsjGdAQWcwuolYrMqpSmfICvzT[kJnEgsjGdAQWcwuolYrMqpSmfICvBx]['episode']['broadcast_date'])
     kJnEgsjGdAQWcwuolYrMqpSmfICvBh='%s-%s-%s'%(kJnEgsjGdAQWcwuolYrMqpSmfICvBt[:4],kJnEgsjGdAQWcwuolYrMqpSmfICvBt[4:6],kJnEgsjGdAQWcwuolYrMqpSmfICvBt[6:])
    except:
     kJnEgsjGdAQWcwuolYrMqpSmfICvaR
    if kJnEgsjGdAQWcwuolYrMqpSmfICvzT[kJnEgsjGdAQWcwuolYrMqpSmfICvBx]['episode']['image']!=[]:
     kJnEgsjGdAQWcwuolYrMqpSmfICvzP=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.IMG_DOMAIN+kJnEgsjGdAQWcwuolYrMqpSmfICvzT[kJnEgsjGdAQWcwuolYrMqpSmfICvBx]['episode']['image'][0]['url']
    else:
     kJnEgsjGdAQWcwuolYrMqpSmfICvzP=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.IMG_DOMAIN+kJnEgsjGdAQWcwuolYrMqpSmfICvzT[kJnEgsjGdAQWcwuolYrMqpSmfICvBx]['program']['image'][0]['url']
    kJnEgsjGdAQWcwuolYrMqpSmfICvzi =kJnEgsjGdAQWcwuolYrMqpSmfICvzT[kJnEgsjGdAQWcwuolYrMqpSmfICvBx]['episode']['synopsis']['ko']
    kJnEgsjGdAQWcwuolYrMqpSmfICvzx={}
    kJnEgsjGdAQWcwuolYrMqpSmfICvzx['mediatype']='episode' 
    try:
     kJnEgsjGdAQWcwuolYrMqpSmfICvzx['title'] =kJnEgsjGdAQWcwuolYrMqpSmfICvzT[kJnEgsjGdAQWcwuolYrMqpSmfICvBx]['program']['name']['ko']
     kJnEgsjGdAQWcwuolYrMqpSmfICvzx['aired'] =kJnEgsjGdAQWcwuolYrMqpSmfICvBh
     kJnEgsjGdAQWcwuolYrMqpSmfICvzx['studio'] =kJnEgsjGdAQWcwuolYrMqpSmfICvzT[kJnEgsjGdAQWcwuolYrMqpSmfICvBx]['channel']['name']['ko']
     if 'frequency' in kJnEgsjGdAQWcwuolYrMqpSmfICvzT[kJnEgsjGdAQWcwuolYrMqpSmfICvBx]['episode']:kJnEgsjGdAQWcwuolYrMqpSmfICvzx['episode']=kJnEgsjGdAQWcwuolYrMqpSmfICvzT[kJnEgsjGdAQWcwuolYrMqpSmfICvBx]['episode']['frequency']
    except:
     kJnEgsjGdAQWcwuolYrMqpSmfICvaR
    kJnEgsjGdAQWcwuolYrMqpSmfICvzb={'episode':kJnEgsjGdAQWcwuolYrMqpSmfICvBX,'title':kJnEgsjGdAQWcwuolYrMqpSmfICvzO,'subtitle':kJnEgsjGdAQWcwuolYrMqpSmfICvBh,'thumbnail':kJnEgsjGdAQWcwuolYrMqpSmfICvzP,'synopsis':kJnEgsjGdAQWcwuolYrMqpSmfICvzi,'info':kJnEgsjGdAQWcwuolYrMqpSmfICvzx}
    kJnEgsjGdAQWcwuolYrMqpSmfICvzt.append(kJnEgsjGdAQWcwuolYrMqpSmfICvzb)
   if kJnEgsjGdAQWcwuolYrMqpSmfICvBR>page_int:kJnEgsjGdAQWcwuolYrMqpSmfICvzV=kJnEgsjGdAQWcwuolYrMqpSmfICvah
  except kJnEgsjGdAQWcwuolYrMqpSmfICvae as exception:
   kJnEgsjGdAQWcwuolYrMqpSmfICvaO(exception)
  return kJnEgsjGdAQWcwuolYrMqpSmfICvzt,kJnEgsjGdAQWcwuolYrMqpSmfICvzV,kJnEgsjGdAQWcwuolYrMqpSmfICvBR
 def GetMovieList(kJnEgsjGdAQWcwuolYrMqpSmfICvLB,genre,orderby,page_int,landyn=kJnEgsjGdAQWcwuolYrMqpSmfICvaT):
  kJnEgsjGdAQWcwuolYrMqpSmfICvzt=[]
  kJnEgsjGdAQWcwuolYrMqpSmfICvzV=kJnEgsjGdAQWcwuolYrMqpSmfICvaT
  try:
   kJnEgsjGdAQWcwuolYrMqpSmfICvKT ='/v2/media/movies'
   kJnEgsjGdAQWcwuolYrMqpSmfICvKx=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.GetDefaultParams()
   kJnEgsjGdAQWcwuolYrMqpSmfICvKX={'pageNo':kJnEgsjGdAQWcwuolYrMqpSmfICvaP(page_int),'pageSize':kJnEgsjGdAQWcwuolYrMqpSmfICvaP(kJnEgsjGdAQWcwuolYrMqpSmfICvLB.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','_':kJnEgsjGdAQWcwuolYrMqpSmfICvaP(kJnEgsjGdAQWcwuolYrMqpSmfICvLB.GetNoCache(2))}
   if genre!='all':kJnEgsjGdAQWcwuolYrMqpSmfICvKX['multiCategoryCode']=genre
   kJnEgsjGdAQWcwuolYrMqpSmfICvKx.update(kJnEgsjGdAQWcwuolYrMqpSmfICvKX)
   kJnEgsjGdAQWcwuolYrMqpSmfICvKh=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.API_DOMAIN+kJnEgsjGdAQWcwuolYrMqpSmfICvKT
   kJnEgsjGdAQWcwuolYrMqpSmfICvLV=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.makeDefaultCookies()
   kJnEgsjGdAQWcwuolYrMqpSmfICvLb=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.callRequestCookies('Get',kJnEgsjGdAQWcwuolYrMqpSmfICvKh,payload=kJnEgsjGdAQWcwuolYrMqpSmfICvaR,params=kJnEgsjGdAQWcwuolYrMqpSmfICvKx,headers=kJnEgsjGdAQWcwuolYrMqpSmfICvaR,cookies=kJnEgsjGdAQWcwuolYrMqpSmfICvLV)
   kJnEgsjGdAQWcwuolYrMqpSmfICvKe=json.loads(kJnEgsjGdAQWcwuolYrMqpSmfICvLb.text)
   if not('result' in kJnEgsjGdAQWcwuolYrMqpSmfICvKe['body']):return kJnEgsjGdAQWcwuolYrMqpSmfICvzt,kJnEgsjGdAQWcwuolYrMqpSmfICvzV
   kJnEgsjGdAQWcwuolYrMqpSmfICvzT=kJnEgsjGdAQWcwuolYrMqpSmfICvKe['body']['result']
   for kJnEgsjGdAQWcwuolYrMqpSmfICvKH in kJnEgsjGdAQWcwuolYrMqpSmfICvzT:
    kJnEgsjGdAQWcwuolYrMqpSmfICvBe =kJnEgsjGdAQWcwuolYrMqpSmfICvKH['movie']['code']
    kJnEgsjGdAQWcwuolYrMqpSmfICvzO =kJnEgsjGdAQWcwuolYrMqpSmfICvKH['movie']['name']['ko'].strip()
    kJnEgsjGdAQWcwuolYrMqpSmfICvzO +=u' (%s년)'%(kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('movie').get('product_year'))
    kJnEgsjGdAQWcwuolYrMqpSmfICvzP =kJnEgsjGdAQWcwuolYrMqpSmfICvLB.IMG_DOMAIN+kJnEgsjGdAQWcwuolYrMqpSmfICvKH['movie']['image'][0]['url']
    kJnEgsjGdAQWcwuolYrMqpSmfICvzD='CAIM0400' if landyn else 'CAIM2100' 
    for kJnEgsjGdAQWcwuolYrMqpSmfICvBL in kJnEgsjGdAQWcwuolYrMqpSmfICvKH['movie']['image']:
     if kJnEgsjGdAQWcwuolYrMqpSmfICvBL['code']==kJnEgsjGdAQWcwuolYrMqpSmfICvzD:
      kJnEgsjGdAQWcwuolYrMqpSmfICvzP =kJnEgsjGdAQWcwuolYrMqpSmfICvLB.IMG_DOMAIN+kJnEgsjGdAQWcwuolYrMqpSmfICvBL['url']
      break
    kJnEgsjGdAQWcwuolYrMqpSmfICvzi =kJnEgsjGdAQWcwuolYrMqpSmfICvKH['movie']['story']['ko']
    kJnEgsjGdAQWcwuolYrMqpSmfICvzx={}
    kJnEgsjGdAQWcwuolYrMqpSmfICvzx['mediatype']='movie' 
    kJnEgsjGdAQWcwuolYrMqpSmfICvzx['title'] = kJnEgsjGdAQWcwuolYrMqpSmfICvKH['movie']['name']['ko'].strip()
    kJnEgsjGdAQWcwuolYrMqpSmfICvzx['year'] =kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('movie').get('product_year')
    try:
     kJnEgsjGdAQWcwuolYrMqpSmfICvzH=[]
     for kJnEgsjGdAQWcwuolYrMqpSmfICvzU in kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('movie').get('actor'):kJnEgsjGdAQWcwuolYrMqpSmfICvzH.append(kJnEgsjGdAQWcwuolYrMqpSmfICvzU)
     if kJnEgsjGdAQWcwuolYrMqpSmfICvzH[0]!='':kJnEgsjGdAQWcwuolYrMqpSmfICvzx['cast']=kJnEgsjGdAQWcwuolYrMqpSmfICvzH
    except:
     kJnEgsjGdAQWcwuolYrMqpSmfICvaR
    try:
     kJnEgsjGdAQWcwuolYrMqpSmfICvBz=[]
     for kJnEgsjGdAQWcwuolYrMqpSmfICvBa in kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('movie').get('director'):kJnEgsjGdAQWcwuolYrMqpSmfICvBz.append(kJnEgsjGdAQWcwuolYrMqpSmfICvBa)
     if kJnEgsjGdAQWcwuolYrMqpSmfICvBz[0]!='':kJnEgsjGdAQWcwuolYrMqpSmfICvzx['director']=kJnEgsjGdAQWcwuolYrMqpSmfICvBz
    except:
     kJnEgsjGdAQWcwuolYrMqpSmfICvaR
    try:
     kJnEgsjGdAQWcwuolYrMqpSmfICvzF=[]
     if kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('movie').get('category1_name').get('ko')!='':
      kJnEgsjGdAQWcwuolYrMqpSmfICvzF.append(kJnEgsjGdAQWcwuolYrMqpSmfICvKH['movie']['category1_name']['ko'])
     if kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('movie').get('category2_name').get('ko')!='':
      kJnEgsjGdAQWcwuolYrMqpSmfICvzF.append(kJnEgsjGdAQWcwuolYrMqpSmfICvKH['movie']['category2_name']['ko'])
     if kJnEgsjGdAQWcwuolYrMqpSmfICvzF[0]!='':kJnEgsjGdAQWcwuolYrMqpSmfICvzx['genre']=kJnEgsjGdAQWcwuolYrMqpSmfICvzF
    except:
     kJnEgsjGdAQWcwuolYrMqpSmfICvaR
    try:
     if 'release_date' in kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('movie'):
      kJnEgsjGdAQWcwuolYrMqpSmfICvBt=kJnEgsjGdAQWcwuolYrMqpSmfICvaP(kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('movie').get('release_date'))
      kJnEgsjGdAQWcwuolYrMqpSmfICvzx['aired']='%s-%s-%s'%(kJnEgsjGdAQWcwuolYrMqpSmfICvBt[:4],kJnEgsjGdAQWcwuolYrMqpSmfICvBt[4:6],kJnEgsjGdAQWcwuolYrMqpSmfICvBt[6:])
    except:
     kJnEgsjGdAQWcwuolYrMqpSmfICvaR
    try:
     if 'duration' in kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('movie'):kJnEgsjGdAQWcwuolYrMqpSmfICvzx['duration']=kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('movie').get('duration')
    except:
     kJnEgsjGdAQWcwuolYrMqpSmfICvaR
    kJnEgsjGdAQWcwuolYrMqpSmfICvzb={'moviecode':kJnEgsjGdAQWcwuolYrMqpSmfICvBe,'title':kJnEgsjGdAQWcwuolYrMqpSmfICvzO,'thumbnail':kJnEgsjGdAQWcwuolYrMqpSmfICvzP,'synopsis':kJnEgsjGdAQWcwuolYrMqpSmfICvzi,'info':kJnEgsjGdAQWcwuolYrMqpSmfICvzx}
    kJnEgsjGdAQWcwuolYrMqpSmfICvBO=kJnEgsjGdAQWcwuolYrMqpSmfICvaT
    for kJnEgsjGdAQWcwuolYrMqpSmfICvBP in kJnEgsjGdAQWcwuolYrMqpSmfICvKH['billing_package_id']:
     if kJnEgsjGdAQWcwuolYrMqpSmfICvBP in kJnEgsjGdAQWcwuolYrMqpSmfICvLB.MOVIE_LITE:
      kJnEgsjGdAQWcwuolYrMqpSmfICvBO=kJnEgsjGdAQWcwuolYrMqpSmfICvah
      break
    if kJnEgsjGdAQWcwuolYrMqpSmfICvBO==kJnEgsjGdAQWcwuolYrMqpSmfICvaT: 
     kJnEgsjGdAQWcwuolYrMqpSmfICvzb['title']=kJnEgsjGdAQWcwuolYrMqpSmfICvzb['title']+' [개별구매]'
    kJnEgsjGdAQWcwuolYrMqpSmfICvzt.append(kJnEgsjGdAQWcwuolYrMqpSmfICvzb)
   if kJnEgsjGdAQWcwuolYrMqpSmfICvKe['body']['has_more']=='Y':kJnEgsjGdAQWcwuolYrMqpSmfICvzV=kJnEgsjGdAQWcwuolYrMqpSmfICvah
  except kJnEgsjGdAQWcwuolYrMqpSmfICvae as exception:
   kJnEgsjGdAQWcwuolYrMqpSmfICvaO(exception)
  return kJnEgsjGdAQWcwuolYrMqpSmfICvzt,kJnEgsjGdAQWcwuolYrMqpSmfICvzV
 def GetMovieListGenre(kJnEgsjGdAQWcwuolYrMqpSmfICvLB,genre,page_int):
  kJnEgsjGdAQWcwuolYrMqpSmfICvzt=[]
  kJnEgsjGdAQWcwuolYrMqpSmfICvzV=kJnEgsjGdAQWcwuolYrMqpSmfICvaT
  try:
   kJnEgsjGdAQWcwuolYrMqpSmfICvKT ='/v2/media/movie/curation/'+genre
   kJnEgsjGdAQWcwuolYrMqpSmfICvKx=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.GetDefaultParams()
   kJnEgsjGdAQWcwuolYrMqpSmfICvKX={'pageNo':kJnEgsjGdAQWcwuolYrMqpSmfICvaP(page_int),'pageSize':kJnEgsjGdAQWcwuolYrMqpSmfICvaP(kJnEgsjGdAQWcwuolYrMqpSmfICvLB.MOVIE_LIMIT),'_':kJnEgsjGdAQWcwuolYrMqpSmfICvaP(kJnEgsjGdAQWcwuolYrMqpSmfICvLB.GetNoCache(2))}
   kJnEgsjGdAQWcwuolYrMqpSmfICvKx.update(kJnEgsjGdAQWcwuolYrMqpSmfICvKX)
   kJnEgsjGdAQWcwuolYrMqpSmfICvKh=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.API_DOMAIN+kJnEgsjGdAQWcwuolYrMqpSmfICvKT
   kJnEgsjGdAQWcwuolYrMqpSmfICvLV=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.makeDefaultCookies()
   kJnEgsjGdAQWcwuolYrMqpSmfICvLb=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.callRequestCookies('Get',kJnEgsjGdAQWcwuolYrMqpSmfICvKh,payload=kJnEgsjGdAQWcwuolYrMqpSmfICvaR,params=kJnEgsjGdAQWcwuolYrMqpSmfICvKx,headers=kJnEgsjGdAQWcwuolYrMqpSmfICvaR,cookies=kJnEgsjGdAQWcwuolYrMqpSmfICvLV)
   kJnEgsjGdAQWcwuolYrMqpSmfICvKe=json.loads(kJnEgsjGdAQWcwuolYrMqpSmfICvLb.text)
   if not('movies' in kJnEgsjGdAQWcwuolYrMqpSmfICvKe['body']):return kJnEgsjGdAQWcwuolYrMqpSmfICvzt,kJnEgsjGdAQWcwuolYrMqpSmfICvzV
   kJnEgsjGdAQWcwuolYrMqpSmfICvzT=kJnEgsjGdAQWcwuolYrMqpSmfICvKe['body']['movies']
   for kJnEgsjGdAQWcwuolYrMqpSmfICvKH in kJnEgsjGdAQWcwuolYrMqpSmfICvzT:
    kJnEgsjGdAQWcwuolYrMqpSmfICvBe =kJnEgsjGdAQWcwuolYrMqpSmfICvKH['code']
    kJnEgsjGdAQWcwuolYrMqpSmfICvzO =kJnEgsjGdAQWcwuolYrMqpSmfICvKH['name']['ko']
    kJnEgsjGdAQWcwuolYrMqpSmfICvzP =kJnEgsjGdAQWcwuolYrMqpSmfICvLB.IMG_DOMAIN+kJnEgsjGdAQWcwuolYrMqpSmfICvKH['image'][0]['url']
    for kJnEgsjGdAQWcwuolYrMqpSmfICvBL in kJnEgsjGdAQWcwuolYrMqpSmfICvKH['image']:
     if kJnEgsjGdAQWcwuolYrMqpSmfICvBL['code']=='CAIM2100':
      kJnEgsjGdAQWcwuolYrMqpSmfICvzP =kJnEgsjGdAQWcwuolYrMqpSmfICvLB.IMG_DOMAIN+kJnEgsjGdAQWcwuolYrMqpSmfICvBL['url']
    kJnEgsjGdAQWcwuolYrMqpSmfICvzi =kJnEgsjGdAQWcwuolYrMqpSmfICvKH['story']['ko']
    kJnEgsjGdAQWcwuolYrMqpSmfICvzb={'moviecode':kJnEgsjGdAQWcwuolYrMqpSmfICvBe,'title':kJnEgsjGdAQWcwuolYrMqpSmfICvzO.strip(),'thumbnail':kJnEgsjGdAQWcwuolYrMqpSmfICvzP,'synopsis':kJnEgsjGdAQWcwuolYrMqpSmfICvzi}
    kJnEgsjGdAQWcwuolYrMqpSmfICvzt.append(kJnEgsjGdAQWcwuolYrMqpSmfICvzb)
  except kJnEgsjGdAQWcwuolYrMqpSmfICvae as exception:
   kJnEgsjGdAQWcwuolYrMqpSmfICvaO(exception)
  return kJnEgsjGdAQWcwuolYrMqpSmfICvzt,kJnEgsjGdAQWcwuolYrMqpSmfICvzV
 def GetMovieGenre(kJnEgsjGdAQWcwuolYrMqpSmfICvLB):
  kJnEgsjGdAQWcwuolYrMqpSmfICvzt=[]
  kJnEgsjGdAQWcwuolYrMqpSmfICvzV=kJnEgsjGdAQWcwuolYrMqpSmfICvaT
  try:
   kJnEgsjGdAQWcwuolYrMqpSmfICvKT ='/v2/media/movie/curations'
   kJnEgsjGdAQWcwuolYrMqpSmfICvKx=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.GetDefaultParams()
   kJnEgsjGdAQWcwuolYrMqpSmfICvKX={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code','_':kJnEgsjGdAQWcwuolYrMqpSmfICvaP(kJnEgsjGdAQWcwuolYrMqpSmfICvLB.GetNoCache(2))}
   kJnEgsjGdAQWcwuolYrMqpSmfICvKx.update(kJnEgsjGdAQWcwuolYrMqpSmfICvKX)
   kJnEgsjGdAQWcwuolYrMqpSmfICvKh=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.API_DOMAIN+kJnEgsjGdAQWcwuolYrMqpSmfICvKT
   kJnEgsjGdAQWcwuolYrMqpSmfICvLV=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.makeDefaultCookies()
   kJnEgsjGdAQWcwuolYrMqpSmfICvLb=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.callRequestCookies('Get',kJnEgsjGdAQWcwuolYrMqpSmfICvKh,payload=kJnEgsjGdAQWcwuolYrMqpSmfICvaR,params=kJnEgsjGdAQWcwuolYrMqpSmfICvKx,headers=kJnEgsjGdAQWcwuolYrMqpSmfICvaR,cookies=kJnEgsjGdAQWcwuolYrMqpSmfICvLV)
   kJnEgsjGdAQWcwuolYrMqpSmfICvKe=json.loads(kJnEgsjGdAQWcwuolYrMqpSmfICvLb.text)
   if not('result' in kJnEgsjGdAQWcwuolYrMqpSmfICvKe['body']):return kJnEgsjGdAQWcwuolYrMqpSmfICvzt,kJnEgsjGdAQWcwuolYrMqpSmfICvzV
   kJnEgsjGdAQWcwuolYrMqpSmfICvzT=kJnEgsjGdAQWcwuolYrMqpSmfICvKe['body']['result']
   for kJnEgsjGdAQWcwuolYrMqpSmfICvKH in kJnEgsjGdAQWcwuolYrMqpSmfICvzT:
    kJnEgsjGdAQWcwuolYrMqpSmfICvBi =kJnEgsjGdAQWcwuolYrMqpSmfICvKH['curation_code']
    kJnEgsjGdAQWcwuolYrMqpSmfICvBH =kJnEgsjGdAQWcwuolYrMqpSmfICvKH['curation_name']
    kJnEgsjGdAQWcwuolYrMqpSmfICvzb={'curation_code':kJnEgsjGdAQWcwuolYrMqpSmfICvBi,'curation_name':kJnEgsjGdAQWcwuolYrMqpSmfICvBH}
    kJnEgsjGdAQWcwuolYrMqpSmfICvzt.append(kJnEgsjGdAQWcwuolYrMqpSmfICvzb)
  except kJnEgsjGdAQWcwuolYrMqpSmfICvae as exception:
   kJnEgsjGdAQWcwuolYrMqpSmfICvaO(exception)
  return kJnEgsjGdAQWcwuolYrMqpSmfICvzt,kJnEgsjGdAQWcwuolYrMqpSmfICvzV
 def GetSearchList(kJnEgsjGdAQWcwuolYrMqpSmfICvLB,search_key,userid,page_int,stype,landyn=kJnEgsjGdAQWcwuolYrMqpSmfICvaT):
  kJnEgsjGdAQWcwuolYrMqpSmfICvBU=[]
  kJnEgsjGdAQWcwuolYrMqpSmfICvzV=kJnEgsjGdAQWcwuolYrMqpSmfICvaT
  try:
   kJnEgsjGdAQWcwuolYrMqpSmfICvKT ='/search/getSearch.jsp'
   kJnEgsjGdAQWcwuolYrMqpSmfICvKX={'kwd':search_key,'notFoundText':search_key,'userid':userid,'siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':kJnEgsjGdAQWcwuolYrMqpSmfICvaP(page_int),'pageSize':kJnEgsjGdAQWcwuolYrMqpSmfICvaP(kJnEgsjGdAQWcwuolYrMqpSmfICvLB.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':kJnEgsjGdAQWcwuolYrMqpSmfICvLB.SCREENCODE,'os':kJnEgsjGdAQWcwuolYrMqpSmfICvLB.OSCODE,'network':kJnEgsjGdAQWcwuolYrMqpSmfICvLB.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':kJnEgsjGdAQWcwuolYrMqpSmfICvaP(kJnEgsjGdAQWcwuolYrMqpSmfICvLB.SEARCH_LIMIT),'vodMVReqCnt':kJnEgsjGdAQWcwuolYrMqpSmfICvaP(kJnEgsjGdAQWcwuolYrMqpSmfICvLB.SEARCH_LIMIT),'smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':kJnEgsjGdAQWcwuolYrMqpSmfICvaP(kJnEgsjGdAQWcwuolYrMqpSmfICvLB.GetNoCache(2))}
   kJnEgsjGdAQWcwuolYrMqpSmfICvKh=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.SEARCH_DOMAIN+kJnEgsjGdAQWcwuolYrMqpSmfICvKT
   kJnEgsjGdAQWcwuolYrMqpSmfICvLV=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.makeDefaultCookies()
   kJnEgsjGdAQWcwuolYrMqpSmfICvLb=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.callRequestCookies('Get',kJnEgsjGdAQWcwuolYrMqpSmfICvKh,payload=kJnEgsjGdAQWcwuolYrMqpSmfICvaR,params=kJnEgsjGdAQWcwuolYrMqpSmfICvKX,headers=kJnEgsjGdAQWcwuolYrMqpSmfICvaR,cookies=kJnEgsjGdAQWcwuolYrMqpSmfICvLV)
   kJnEgsjGdAQWcwuolYrMqpSmfICvKe=json.loads(kJnEgsjGdAQWcwuolYrMqpSmfICvLb.text)
   if stype=='vod':
    if not('programRsb' in kJnEgsjGdAQWcwuolYrMqpSmfICvKe):return kJnEgsjGdAQWcwuolYrMqpSmfICvBU,kJnEgsjGdAQWcwuolYrMqpSmfICvzV
    kJnEgsjGdAQWcwuolYrMqpSmfICvBF=kJnEgsjGdAQWcwuolYrMqpSmfICvKe['programRsb']['dataList']
    kJnEgsjGdAQWcwuolYrMqpSmfICvBy =kJnEgsjGdAQWcwuolYrMqpSmfICvax(kJnEgsjGdAQWcwuolYrMqpSmfICvKe['programRsb']['count'])
    for kJnEgsjGdAQWcwuolYrMqpSmfICvKH in kJnEgsjGdAQWcwuolYrMqpSmfICvBF:
     kJnEgsjGdAQWcwuolYrMqpSmfICvzN=kJnEgsjGdAQWcwuolYrMqpSmfICvKH['mast_cd']
     kJnEgsjGdAQWcwuolYrMqpSmfICvzO =kJnEgsjGdAQWcwuolYrMqpSmfICvKH['mast_nm']
     kJnEgsjGdAQWcwuolYrMqpSmfICvzP =kJnEgsjGdAQWcwuolYrMqpSmfICvLB.IMG_DOMAIN+kJnEgsjGdAQWcwuolYrMqpSmfICvKH['web_url']
     if landyn==kJnEgsjGdAQWcwuolYrMqpSmfICvaT:
      kJnEgsjGdAQWcwuolYrMqpSmfICvzP =kJnEgsjGdAQWcwuolYrMqpSmfICvLB.IMG_DOMAIN+kJnEgsjGdAQWcwuolYrMqpSmfICvKH['web_url4']
     kJnEgsjGdAQWcwuolYrMqpSmfICvzx={}
     kJnEgsjGdAQWcwuolYrMqpSmfICvzx['title']=kJnEgsjGdAQWcwuolYrMqpSmfICvKH['mast_nm']
     kJnEgsjGdAQWcwuolYrMqpSmfICvzx['mediatype']='episode' 
     try:
      if kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('actor')!='' and kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('actor')!='-':kJnEgsjGdAQWcwuolYrMqpSmfICvzx['cast'] =kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('actor').split(',')
      if kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('director')!='' and kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('director')!='-':kJnEgsjGdAQWcwuolYrMqpSmfICvzx['director']=kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('director').split(',')
      if kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('cate_nm')!='':kJnEgsjGdAQWcwuolYrMqpSmfICvzx['genre'] =kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('cate_nm').split('/')
      if 'targetage' in kJnEgsjGdAQWcwuolYrMqpSmfICvKH:kJnEgsjGdAQWcwuolYrMqpSmfICvzx['mpaa']=kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('targetage')
     except:
      kJnEgsjGdAQWcwuolYrMqpSmfICvaR
     try:
      if 'broad_dt' in kJnEgsjGdAQWcwuolYrMqpSmfICvKH:
       kJnEgsjGdAQWcwuolYrMqpSmfICvBt=kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('broad_dt')
       kJnEgsjGdAQWcwuolYrMqpSmfICvzx['aired']='%s-%s-%s'%(kJnEgsjGdAQWcwuolYrMqpSmfICvBt[:4],kJnEgsjGdAQWcwuolYrMqpSmfICvBt[4:6],kJnEgsjGdAQWcwuolYrMqpSmfICvBt[6:])
     except:
      kJnEgsjGdAQWcwuolYrMqpSmfICvaR
     kJnEgsjGdAQWcwuolYrMqpSmfICvzb={'program':kJnEgsjGdAQWcwuolYrMqpSmfICvzN,'title':kJnEgsjGdAQWcwuolYrMqpSmfICvzO,'thumbnail':kJnEgsjGdAQWcwuolYrMqpSmfICvzP,'synopsis':'','info':kJnEgsjGdAQWcwuolYrMqpSmfICvzx}
     kJnEgsjGdAQWcwuolYrMqpSmfICvBU.append(kJnEgsjGdAQWcwuolYrMqpSmfICvzb)
   else:
    if not('vodMVRsb' in kJnEgsjGdAQWcwuolYrMqpSmfICvKe):return kJnEgsjGdAQWcwuolYrMqpSmfICvBU,kJnEgsjGdAQWcwuolYrMqpSmfICvzV
    kJnEgsjGdAQWcwuolYrMqpSmfICvBb=kJnEgsjGdAQWcwuolYrMqpSmfICvKe['vodMVRsb']['dataList']
    kJnEgsjGdAQWcwuolYrMqpSmfICvBy =kJnEgsjGdAQWcwuolYrMqpSmfICvax(kJnEgsjGdAQWcwuolYrMqpSmfICvKe['vodMVRsb']['count'])
    for kJnEgsjGdAQWcwuolYrMqpSmfICvKH in kJnEgsjGdAQWcwuolYrMqpSmfICvBb:
     kJnEgsjGdAQWcwuolYrMqpSmfICvzN=kJnEgsjGdAQWcwuolYrMqpSmfICvKH['mast_cd']
     kJnEgsjGdAQWcwuolYrMqpSmfICvzO =kJnEgsjGdAQWcwuolYrMqpSmfICvKH['mast_nm'].strip()
     kJnEgsjGdAQWcwuolYrMqpSmfICvzP =kJnEgsjGdAQWcwuolYrMqpSmfICvLB.IMG_DOMAIN+kJnEgsjGdAQWcwuolYrMqpSmfICvKH['web_url']
     if landyn==kJnEgsjGdAQWcwuolYrMqpSmfICvaT:
      kJnEgsjGdAQWcwuolYrMqpSmfICvzP =kJnEgsjGdAQWcwuolYrMqpSmfICvLB.IMG_DOMAIN+kJnEgsjGdAQWcwuolYrMqpSmfICvKH['web_url5']
     kJnEgsjGdAQWcwuolYrMqpSmfICvzx={}
     kJnEgsjGdAQWcwuolYrMqpSmfICvzx['title'] =kJnEgsjGdAQWcwuolYrMqpSmfICvzO
     kJnEgsjGdAQWcwuolYrMqpSmfICvzx['mediatype']='movie' 
     try:
      if kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('actor') !='':kJnEgsjGdAQWcwuolYrMqpSmfICvzx['cast'] =kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('actor').split(',')
      if kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('cate_nm')!='':kJnEgsjGdAQWcwuolYrMqpSmfICvzx['genre'] =kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('cate_nm').split('/')
      if kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('runtime_sec')!='':kJnEgsjGdAQWcwuolYrMqpSmfICvzx['duration']=kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('runtime_sec')
      if 'grade_nm' in kJnEgsjGdAQWcwuolYrMqpSmfICvKH:kJnEgsjGdAQWcwuolYrMqpSmfICvzx['mpaa']=kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('grade_nm')
     except:
      kJnEgsjGdAQWcwuolYrMqpSmfICvaR
     try:
      kJnEgsjGdAQWcwuolYrMqpSmfICvBt=kJnEgsjGdAQWcwuolYrMqpSmfICvKH.get('broad_dt')
      if data_str!='':
       kJnEgsjGdAQWcwuolYrMqpSmfICvzx['aired']='%s-%s-%s'%(kJnEgsjGdAQWcwuolYrMqpSmfICvBt[:4],kJnEgsjGdAQWcwuolYrMqpSmfICvBt[4:6],kJnEgsjGdAQWcwuolYrMqpSmfICvBt[6:])
       kJnEgsjGdAQWcwuolYrMqpSmfICvzx['year']=kJnEgsjGdAQWcwuolYrMqpSmfICvBt[:4]
     except:
      kJnEgsjGdAQWcwuolYrMqpSmfICvaR
     kJnEgsjGdAQWcwuolYrMqpSmfICvzb={'movie':kJnEgsjGdAQWcwuolYrMqpSmfICvzN,'title':kJnEgsjGdAQWcwuolYrMqpSmfICvzO,'thumbnail':kJnEgsjGdAQWcwuolYrMqpSmfICvzP,'synopsis':'','info':kJnEgsjGdAQWcwuolYrMqpSmfICvzx}
     kJnEgsjGdAQWcwuolYrMqpSmfICvBO=kJnEgsjGdAQWcwuolYrMqpSmfICvaT
     for kJnEgsjGdAQWcwuolYrMqpSmfICvBP in kJnEgsjGdAQWcwuolYrMqpSmfICvKH['bill']:
      if kJnEgsjGdAQWcwuolYrMqpSmfICvBP in kJnEgsjGdAQWcwuolYrMqpSmfICvLB.MOVIE_LITE:
       kJnEgsjGdAQWcwuolYrMqpSmfICvBO=kJnEgsjGdAQWcwuolYrMqpSmfICvah
       break
     if kJnEgsjGdAQWcwuolYrMqpSmfICvBO==kJnEgsjGdAQWcwuolYrMqpSmfICvaT: 
      kJnEgsjGdAQWcwuolYrMqpSmfICvzb['title']=kJnEgsjGdAQWcwuolYrMqpSmfICvzb['title']+' [개별구매]'
     kJnEgsjGdAQWcwuolYrMqpSmfICvBU.append(kJnEgsjGdAQWcwuolYrMqpSmfICvzb)
  except kJnEgsjGdAQWcwuolYrMqpSmfICvae as exception:
   kJnEgsjGdAQWcwuolYrMqpSmfICvaO(exception)
  return kJnEgsjGdAQWcwuolYrMqpSmfICvBU,kJnEgsjGdAQWcwuolYrMqpSmfICvzV
 def GetDeviceList(kJnEgsjGdAQWcwuolYrMqpSmfICvLB,kJnEgsjGdAQWcwuolYrMqpSmfICvLD,kJnEgsjGdAQWcwuolYrMqpSmfICvKL):
  kJnEgsjGdAQWcwuolYrMqpSmfICvzt=[]
  kJnEgsjGdAQWcwuolYrMqpSmfICvKR='-'
  try:
   kJnEgsjGdAQWcwuolYrMqpSmfICvKT ='/v1/user/device/list'
   kJnEgsjGdAQWcwuolYrMqpSmfICvBN=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.API_DOMAIN+kJnEgsjGdAQWcwuolYrMqpSmfICvKT
   kJnEgsjGdAQWcwuolYrMqpSmfICvKX={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   kJnEgsjGdAQWcwuolYrMqpSmfICvLV=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.makeDefaultCookies(vToken=kJnEgsjGdAQWcwuolYrMqpSmfICvLD,vUserinfo=kJnEgsjGdAQWcwuolYrMqpSmfICvKL)
   kJnEgsjGdAQWcwuolYrMqpSmfICvLb=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.callRequestCookies('Get',kJnEgsjGdAQWcwuolYrMqpSmfICvBN,payload=kJnEgsjGdAQWcwuolYrMqpSmfICvaR,params=kJnEgsjGdAQWcwuolYrMqpSmfICvKX,headers=kJnEgsjGdAQWcwuolYrMqpSmfICvaR,cookies=kJnEgsjGdAQWcwuolYrMqpSmfICvLV)
   kJnEgsjGdAQWcwuolYrMqpSmfICvKe=json.loads(kJnEgsjGdAQWcwuolYrMqpSmfICvLb.text)
   kJnEgsjGdAQWcwuolYrMqpSmfICvzt=kJnEgsjGdAQWcwuolYrMqpSmfICvKe['body']
   for kJnEgsjGdAQWcwuolYrMqpSmfICvKH in kJnEgsjGdAQWcwuolYrMqpSmfICvzt:
    if kJnEgsjGdAQWcwuolYrMqpSmfICvKH['model']=='PC':
     kJnEgsjGdAQWcwuolYrMqpSmfICvKR=kJnEgsjGdAQWcwuolYrMqpSmfICvKH['uuid']
  except kJnEgsjGdAQWcwuolYrMqpSmfICvae as exception:
   kJnEgsjGdAQWcwuolYrMqpSmfICvaO(exception)
  return kJnEgsjGdAQWcwuolYrMqpSmfICvKR
 def GetProfileToken(kJnEgsjGdAQWcwuolYrMqpSmfICvLB,kJnEgsjGdAQWcwuolYrMqpSmfICvLD,kJnEgsjGdAQWcwuolYrMqpSmfICvKL,user_pf):
  kJnEgsjGdAQWcwuolYrMqpSmfICvBD=[]
  kJnEgsjGdAQWcwuolYrMqpSmfICvaL =''
  kJnEgsjGdAQWcwuolYrMqpSmfICvaK =''
  kJnEgsjGdAQWcwuolYrMqpSmfICvaz='Y'
  kJnEgsjGdAQWcwuolYrMqpSmfICvaB ='N'
  try:
   kJnEgsjGdAQWcwuolYrMqpSmfICvKT ='/profile/select.do'
   kJnEgsjGdAQWcwuolYrMqpSmfICvBN=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.URL_DOMAIN+kJnEgsjGdAQWcwuolYrMqpSmfICvKT
   kJnEgsjGdAQWcwuolYrMqpSmfICvLV=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.makeDefaultCookies(vToken=kJnEgsjGdAQWcwuolYrMqpSmfICvLD,vUserinfo=kJnEgsjGdAQWcwuolYrMqpSmfICvKL)
   kJnEgsjGdAQWcwuolYrMqpSmfICvLb=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.callRequestCookies('Get',kJnEgsjGdAQWcwuolYrMqpSmfICvBN,payload=kJnEgsjGdAQWcwuolYrMqpSmfICvaR,params=kJnEgsjGdAQWcwuolYrMqpSmfICvaR,headers=kJnEgsjGdAQWcwuolYrMqpSmfICvaR,cookies=kJnEgsjGdAQWcwuolYrMqpSmfICvLV)
   kJnEgsjGdAQWcwuolYrMqpSmfICvBD =re.findall('data-profile-no="\d{9}"',kJnEgsjGdAQWcwuolYrMqpSmfICvLb.text)
   for i in kJnEgsjGdAQWcwuolYrMqpSmfICvaX(kJnEgsjGdAQWcwuolYrMqpSmfICvaH(kJnEgsjGdAQWcwuolYrMqpSmfICvBD)):
    kJnEgsjGdAQWcwuolYrMqpSmfICvat =kJnEgsjGdAQWcwuolYrMqpSmfICvBD[i].replace('data-profile-no=','').replace('"','')
    kJnEgsjGdAQWcwuolYrMqpSmfICvBD[i]=kJnEgsjGdAQWcwuolYrMqpSmfICvat
   kJnEgsjGdAQWcwuolYrMqpSmfICvaL=kJnEgsjGdAQWcwuolYrMqpSmfICvBD[user_pf]
  except kJnEgsjGdAQWcwuolYrMqpSmfICvae as exception:
   kJnEgsjGdAQWcwuolYrMqpSmfICvaO(exception)
   return kJnEgsjGdAQWcwuolYrMqpSmfICvaK,kJnEgsjGdAQWcwuolYrMqpSmfICvaz,kJnEgsjGdAQWcwuolYrMqpSmfICvaB
  try:
   kJnEgsjGdAQWcwuolYrMqpSmfICvKT ='/profile/api/select.do'
   kJnEgsjGdAQWcwuolYrMqpSmfICvBN=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.URL_DOMAIN+kJnEgsjGdAQWcwuolYrMqpSmfICvKT
   kJnEgsjGdAQWcwuolYrMqpSmfICvLV=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.makeDefaultCookies(vToken=kJnEgsjGdAQWcwuolYrMqpSmfICvLD,vUserinfo=kJnEgsjGdAQWcwuolYrMqpSmfICvKL)
   kJnEgsjGdAQWcwuolYrMqpSmfICvLy={'profileNo':kJnEgsjGdAQWcwuolYrMqpSmfICvaL}
   kJnEgsjGdAQWcwuolYrMqpSmfICvLb=kJnEgsjGdAQWcwuolYrMqpSmfICvLB.callRequestCookies('Post',kJnEgsjGdAQWcwuolYrMqpSmfICvBN,payload=kJnEgsjGdAQWcwuolYrMqpSmfICvLy,params=kJnEgsjGdAQWcwuolYrMqpSmfICvaR,headers=kJnEgsjGdAQWcwuolYrMqpSmfICvaR,cookies=kJnEgsjGdAQWcwuolYrMqpSmfICvLV)
   for kJnEgsjGdAQWcwuolYrMqpSmfICvLN in kJnEgsjGdAQWcwuolYrMqpSmfICvLb.cookies:
    if kJnEgsjGdAQWcwuolYrMqpSmfICvLN.name=='_tving_token':
     kJnEgsjGdAQWcwuolYrMqpSmfICvaK=kJnEgsjGdAQWcwuolYrMqpSmfICvLN.value
    elif kJnEgsjGdAQWcwuolYrMqpSmfICvLN.name==kJnEgsjGdAQWcwuolYrMqpSmfICvLB.GLOBAL_COOKIENM['tv_cookiekey']:
     kJnEgsjGdAQWcwuolYrMqpSmfICvaz=kJnEgsjGdAQWcwuolYrMqpSmfICvLN.value
    elif kJnEgsjGdAQWcwuolYrMqpSmfICvLN.name==kJnEgsjGdAQWcwuolYrMqpSmfICvLB.GLOBAL_COOKIENM['tv_lockkey']:
     kJnEgsjGdAQWcwuolYrMqpSmfICvaB=kJnEgsjGdAQWcwuolYrMqpSmfICvLN.value
  except kJnEgsjGdAQWcwuolYrMqpSmfICvae as exception:
   kJnEgsjGdAQWcwuolYrMqpSmfICvaO(exception)
  return kJnEgsjGdAQWcwuolYrMqpSmfICvaK,kJnEgsjGdAQWcwuolYrMqpSmfICvaz,kJnEgsjGdAQWcwuolYrMqpSmfICvaB
# Created by pyminifier (https://github.com/liftoff/pyminifier)
