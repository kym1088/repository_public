__author__="NightRain"
FEqvWBeVYKGwPxDHLlMXURCTptjfSb=object
FEqvWBeVYKGwPxDHLlMXURCTptjfSm=None
FEqvWBeVYKGwPxDHLlMXURCTptjfSO=int
FEqvWBeVYKGwPxDHLlMXURCTptjfSd=False
FEqvWBeVYKGwPxDHLlMXURCTptjfSQ=True
FEqvWBeVYKGwPxDHLlMXURCTptjfSo=len
FEqvWBeVYKGwPxDHLlMXURCTptjfSr=str
FEqvWBeVYKGwPxDHLlMXURCTptjfSi=open
FEqvWBeVYKGwPxDHLlMXURCTptjfSn=dict
FEqvWBeVYKGwPxDHLlMXURCTptjfSc=Exception
FEqvWBeVYKGwPxDHLlMXURCTptjfSu=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
FEqvWBeVYKGwPxDHLlMXURCTptjfhJ=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 인기순','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewWeek','ordernm':'인기'},{'title':'영화(Movie) - 최신순','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'검색 (search)','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-'}]
FEqvWBeVYKGwPxDHLlMXURCTptjfhb=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
FEqvWBeVYKGwPxDHLlMXURCTptjfhm=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
FEqvWBeVYKGwPxDHLlMXURCTptjfhS=[{'title':'VOD 검색','mode':'SEARCH','stype':'vod'},{'title':'영화 검색','mode':'SEARCH','stype':'movie'}]
FEqvWBeVYKGwPxDHLlMXURCTptjfhO=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'PROGRAM','stype':'PCPOS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'키즈/애니','mode':'PROGRAM','stype':'PCC,PCAN'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'뮤직','mode':'PROGRAM','stype':'PCG'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'}]
FEqvWBeVYKGwPxDHLlMXURCTptjfhd=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG190,MG230,MG270,MG290'},{'title':'로맨스/멜로','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'액션/SF','mode':'MOVIE_SUB','stype':'MG120,MG170,MG180,MG220,MG260,MG200,MG210'},{'title':'공포/스릴러','mode':'MOVIE_SUB','stype':'MG140,MG150,MG160'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'다큐','mode':'MOVIE_SUB','stype':'MG250,MG330'}]
FEqvWBeVYKGwPxDHLlMXURCTptjfhQ={'C00551':'tvN','C00544':'중화TV','C00575':'Olive','C00579':'Mnet','C00590':'OGN','C01141':'XtvN','C01142':'ONSTYLE','C01143':'OtvN','C04601':'OCN Movies','C06941':'tooniverse','C07381':'OCN','C07382':'OCN Thrills','C15251':'OGN x LOL','C15252':'OGN x 오버워치','C15042':'티빙라이브','C01581':'TV CHOSUN','C01583':'채널A','C00708':'MBN','C00593':'YTN','C01101':'YTN Life','C15347':'YTN science','C01723':'연합뉴스TV','C15152':'CH.DIA','C01582':'JTBC','C00588':'JTBC Golf','C15741':'JTBC2','C00805':'JTBC3 FOX Sports','C05661':'디즈니채널','C18641':'IHQ','C22041':'JTBC4','C23343':'t.cast','C23441':'E channel','C17341':'히스토리','C00585':'TV CHOSUN2','C17141':'채널A 플러스','C00611':'LIFETIME','C08041':'tvN go','C05901':'채널W','C23442':"D'LIVE",'C27441':'KBS N','C15846':'SBS CNBC','C43241':'Nickelodeon','C43242':'SBS MTV','C43341':'SBS FiL','C43342':'KPOP','C17142':'MBN+'}
FEqvWBeVYKGwPxDHLlMXURCTptjfho=xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
from tvingCore import*
class FEqvWBeVYKGwPxDHLlMXURCTptjfhN(FEqvWBeVYKGwPxDHLlMXURCTptjfSb):
 def __init__(FEqvWBeVYKGwPxDHLlMXURCTptjfhr,FEqvWBeVYKGwPxDHLlMXURCTptjfhi,FEqvWBeVYKGwPxDHLlMXURCTptjfhn,FEqvWBeVYKGwPxDHLlMXURCTptjfhc):
  FEqvWBeVYKGwPxDHLlMXURCTptjfhr._addon_url =FEqvWBeVYKGwPxDHLlMXURCTptjfhi
  FEqvWBeVYKGwPxDHLlMXURCTptjfhr._addon_handle=FEqvWBeVYKGwPxDHLlMXURCTptjfhn
  FEqvWBeVYKGwPxDHLlMXURCTptjfhr.main_params =FEqvWBeVYKGwPxDHLlMXURCTptjfhc
  FEqvWBeVYKGwPxDHLlMXURCTptjfhr.TvingObj =kJnEgsjGdAQWcwuolYrMqpSmfICvLK() 
 def addon_noti(FEqvWBeVYKGwPxDHLlMXURCTptjfhr,sting):
  try:
   FEqvWBeVYKGwPxDHLlMXURCTptjfhA=xbmcgui.Dialog()
   FEqvWBeVYKGwPxDHLlMXURCTptjfhA.notification(__addonname__,sting)
  except:
   FEqvWBeVYKGwPxDHLlMXURCTptjfSm
 def addon_log(FEqvWBeVYKGwPxDHLlMXURCTptjfhr,string):
  try:
   FEqvWBeVYKGwPxDHLlMXURCTptjfhy=string.encode('utf-8','ignore')
  except:
   FEqvWBeVYKGwPxDHLlMXURCTptjfhy='addonException: addon_log'
  FEqvWBeVYKGwPxDHLlMXURCTptjfhs=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,FEqvWBeVYKGwPxDHLlMXURCTptjfhy),level=FEqvWBeVYKGwPxDHLlMXURCTptjfhs)
 def get_keyboard_input(FEqvWBeVYKGwPxDHLlMXURCTptjfhr,FEqvWBeVYKGwPxDHLlMXURCTptjfNd):
  FEqvWBeVYKGwPxDHLlMXURCTptjfhI=FEqvWBeVYKGwPxDHLlMXURCTptjfSm
  kb=xbmc.Keyboard()
  kb.setHeading(FEqvWBeVYKGwPxDHLlMXURCTptjfNd)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   FEqvWBeVYKGwPxDHLlMXURCTptjfhI=kb.getText()
  return FEqvWBeVYKGwPxDHLlMXURCTptjfhI
 def get_settings_login_info(FEqvWBeVYKGwPxDHLlMXURCTptjfhr):
  FEqvWBeVYKGwPxDHLlMXURCTptjfhk =__addon__.getSetting('id')
  FEqvWBeVYKGwPxDHLlMXURCTptjfha =__addon__.getSetting('pw')
  FEqvWBeVYKGwPxDHLlMXURCTptjfhg =__addon__.getSetting('login_type')
  FEqvWBeVYKGwPxDHLlMXURCTptjfhz=FEqvWBeVYKGwPxDHLlMXURCTptjfSO(__addon__.getSetting('selected_profile'))
  return(FEqvWBeVYKGwPxDHLlMXURCTptjfhk,FEqvWBeVYKGwPxDHLlMXURCTptjfha,FEqvWBeVYKGwPxDHLlMXURCTptjfhg,FEqvWBeVYKGwPxDHLlMXURCTptjfhz)
 def get_settings_premiumyn(FEqvWBeVYKGwPxDHLlMXURCTptjfhr):
  FEqvWBeVYKGwPxDHLlMXURCTptjfNh =__addon__.getSetting('premium_movieyn')
  if FEqvWBeVYKGwPxDHLlMXURCTptjfNh=='false':
   return FEqvWBeVYKGwPxDHLlMXURCTptjfSd
  else:
   return FEqvWBeVYKGwPxDHLlMXURCTptjfSQ
 def get_settings_direct_replay(FEqvWBeVYKGwPxDHLlMXURCTptjfhr):
  FEqvWBeVYKGwPxDHLlMXURCTptjfNJ=FEqvWBeVYKGwPxDHLlMXURCTptjfSO(__addon__.getSetting('direct_replay'))
  if FEqvWBeVYKGwPxDHLlMXURCTptjfNJ==0:
   return FEqvWBeVYKGwPxDHLlMXURCTptjfSd
  else:
   return FEqvWBeVYKGwPxDHLlMXURCTptjfSQ
 def get_settings_thumbnail_landyn(FEqvWBeVYKGwPxDHLlMXURCTptjfhr):
  FEqvWBeVYKGwPxDHLlMXURCTptjfNb =FEqvWBeVYKGwPxDHLlMXURCTptjfSO(__addon__.getSetting('thumbnail_way'))
  if FEqvWBeVYKGwPxDHLlMXURCTptjfNb==0:
   return FEqvWBeVYKGwPxDHLlMXURCTptjfSQ
  else:
   return FEqvWBeVYKGwPxDHLlMXURCTptjfSd
 def set_winCredential(FEqvWBeVYKGwPxDHLlMXURCTptjfhr,credential):
  FEqvWBeVYKGwPxDHLlMXURCTptjfNm=xbmcgui.Window(10000)
  FEqvWBeVYKGwPxDHLlMXURCTptjfNm.setProperty('TVING_M_TOKEN',credential.get('tving_token'))
  FEqvWBeVYKGwPxDHLlMXURCTptjfNm.setProperty('TVING_M_USERINFO',credential.get('poc_userinfo'))
  FEqvWBeVYKGwPxDHLlMXURCTptjfNm.setProperty('TVING_M_UUID',credential.get('tving_uuid'))
  FEqvWBeVYKGwPxDHLlMXURCTptjfNm.setProperty('TVING_M_LOGINTIME',FEqvWBeVYKGwPxDHLlMXURCTptjfhr.TvingObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
  FEqvWBeVYKGwPxDHLlMXURCTptjfNm.setProperty('TVING_M_MAINTOKEN',credential.get('tving_maintoken'))
  FEqvWBeVYKGwPxDHLlMXURCTptjfNm.setProperty('TVING_M_COOKIEKEY',credential.get('tving_cookiekey'))
  FEqvWBeVYKGwPxDHLlMXURCTptjfNm.setProperty('TVING_M_LOCKKEY',credential.get('tving_lockkey'))
 def get_winCredential(FEqvWBeVYKGwPxDHLlMXURCTptjfhr):
  FEqvWBeVYKGwPxDHLlMXURCTptjfNm=xbmcgui.Window(10000)
  FEqvWBeVYKGwPxDHLlMXURCTptjfNS={'tving_token':FEqvWBeVYKGwPxDHLlMXURCTptjfNm.getProperty('TVING_M_TOKEN'),'poc_userinfo':FEqvWBeVYKGwPxDHLlMXURCTptjfNm.getProperty('TVING_M_USERINFO'),'tving_uuid':FEqvWBeVYKGwPxDHLlMXURCTptjfNm.getProperty('TVING_M_UUID'),'tving_maintoken':FEqvWBeVYKGwPxDHLlMXURCTptjfNm.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':FEqvWBeVYKGwPxDHLlMXURCTptjfNm.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':FEqvWBeVYKGwPxDHLlMXURCTptjfNm.getProperty('TVING_M_LOCKKEY')}
  return FEqvWBeVYKGwPxDHLlMXURCTptjfNS
 def set_winEpisodeOrderby(FEqvWBeVYKGwPxDHLlMXURCTptjfhr,FEqvWBeVYKGwPxDHLlMXURCTptjfJy):
  FEqvWBeVYKGwPxDHLlMXURCTptjfNm=xbmcgui.Window(10000)
  FEqvWBeVYKGwPxDHLlMXURCTptjfNm.setProperty('TVING_M_ORDERBY',FEqvWBeVYKGwPxDHLlMXURCTptjfJy)
 def get_winEpisodeOrderby(FEqvWBeVYKGwPxDHLlMXURCTptjfhr):
  FEqvWBeVYKGwPxDHLlMXURCTptjfNm=xbmcgui.Window(10000)
  return FEqvWBeVYKGwPxDHLlMXURCTptjfNm.getProperty('TVING_M_ORDERBY')
 def add_dir(FEqvWBeVYKGwPxDHLlMXURCTptjfhr,label,sublabel='',img='',infoLabels=FEqvWBeVYKGwPxDHLlMXURCTptjfSm,isFolder=FEqvWBeVYKGwPxDHLlMXURCTptjfSQ,params=''):
  FEqvWBeVYKGwPxDHLlMXURCTptjfNO='%s?%s'%(FEqvWBeVYKGwPxDHLlMXURCTptjfhr._addon_url,urllib.parse.urlencode(params))
  if sublabel:FEqvWBeVYKGwPxDHLlMXURCTptjfNd='%s < %s >'%(label,sublabel)
  else: FEqvWBeVYKGwPxDHLlMXURCTptjfNd=label
  if not img:img='DefaultFolder.png'
  FEqvWBeVYKGwPxDHLlMXURCTptjfNQ=xbmcgui.ListItem(FEqvWBeVYKGwPxDHLlMXURCTptjfNd)
  FEqvWBeVYKGwPxDHLlMXURCTptjfNQ.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:FEqvWBeVYKGwPxDHLlMXURCTptjfNQ.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:FEqvWBeVYKGwPxDHLlMXURCTptjfNQ.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(FEqvWBeVYKGwPxDHLlMXURCTptjfhr._addon_handle,FEqvWBeVYKGwPxDHLlMXURCTptjfNO,FEqvWBeVYKGwPxDHLlMXURCTptjfNQ,isFolder)
 def get_selQuality(FEqvWBeVYKGwPxDHLlMXURCTptjfhr,etype):
  try:
   FEqvWBeVYKGwPxDHLlMXURCTptjfNo='selected_quality'
   FEqvWBeVYKGwPxDHLlMXURCTptjfNr=[1080,720,480,360]
   FEqvWBeVYKGwPxDHLlMXURCTptjfNi=FEqvWBeVYKGwPxDHLlMXURCTptjfSO(__addon__.getSetting(FEqvWBeVYKGwPxDHLlMXURCTptjfNo))
   return FEqvWBeVYKGwPxDHLlMXURCTptjfNr[FEqvWBeVYKGwPxDHLlMXURCTptjfNi]
  except:
   FEqvWBeVYKGwPxDHLlMXURCTptjfSm
  return 720 
 def dp_Main_List(FEqvWBeVYKGwPxDHLlMXURCTptjfhr):
  for FEqvWBeVYKGwPxDHLlMXURCTptjfNn in FEqvWBeVYKGwPxDHLlMXURCTptjfhJ:
   FEqvWBeVYKGwPxDHLlMXURCTptjfNd=FEqvWBeVYKGwPxDHLlMXURCTptjfNn.get('title')
   FEqvWBeVYKGwPxDHLlMXURCTptjfNc={'mode':FEqvWBeVYKGwPxDHLlMXURCTptjfNn.get('mode'),'stype':FEqvWBeVYKGwPxDHLlMXURCTptjfNn.get('stype'),'orderby':FEqvWBeVYKGwPxDHLlMXURCTptjfNn.get('orderby'),'ordernm':FEqvWBeVYKGwPxDHLlMXURCTptjfNn.get('ordernm'),'page':'1'}
   if FEqvWBeVYKGwPxDHLlMXURCTptjfNn.get('mode')=='XXX':
    FEqvWBeVYKGwPxDHLlMXURCTptjfNc['mode']='XXX'
    FEqvWBeVYKGwPxDHLlMXURCTptjfNu=FEqvWBeVYKGwPxDHLlMXURCTptjfSd
   else:
    FEqvWBeVYKGwPxDHLlMXURCTptjfNu=FEqvWBeVYKGwPxDHLlMXURCTptjfSQ
   FEqvWBeVYKGwPxDHLlMXURCTptjfhr.add_dir(FEqvWBeVYKGwPxDHLlMXURCTptjfNd,sublabel='',img='',infoLabels=FEqvWBeVYKGwPxDHLlMXURCTptjfSm,isFolder=FEqvWBeVYKGwPxDHLlMXURCTptjfNu,params=FEqvWBeVYKGwPxDHLlMXURCTptjfNc)
  if FEqvWBeVYKGwPxDHLlMXURCTptjfSo(FEqvWBeVYKGwPxDHLlMXURCTptjfhJ)>0:xbmcplugin.endOfDirectory(FEqvWBeVYKGwPxDHLlMXURCTptjfhr._addon_handle)
 def login_main(FEqvWBeVYKGwPxDHLlMXURCTptjfhr):
  (FEqvWBeVYKGwPxDHLlMXURCTptjfNy,FEqvWBeVYKGwPxDHLlMXURCTptjfNs,FEqvWBeVYKGwPxDHLlMXURCTptjfNI,FEqvWBeVYKGwPxDHLlMXURCTptjfNk)=FEqvWBeVYKGwPxDHLlMXURCTptjfhr.get_settings_login_info()
  if not(FEqvWBeVYKGwPxDHLlMXURCTptjfNy and FEqvWBeVYKGwPxDHLlMXURCTptjfNs):
   FEqvWBeVYKGwPxDHLlMXURCTptjfhA=xbmcgui.Dialog()
   FEqvWBeVYKGwPxDHLlMXURCTptjfNa=FEqvWBeVYKGwPxDHLlMXURCTptjfhA.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if FEqvWBeVYKGwPxDHLlMXURCTptjfNa==FEqvWBeVYKGwPxDHLlMXURCTptjfSQ:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if FEqvWBeVYKGwPxDHLlMXURCTptjfhr.get_winEpisodeOrderby()=='':
   FEqvWBeVYKGwPxDHLlMXURCTptjfhr.set_winEpisodeOrderby('desc')
  if FEqvWBeVYKGwPxDHLlMXURCTptjfhr.cookiefile_check():return
  FEqvWBeVYKGwPxDHLlMXURCTptjfNg =FEqvWBeVYKGwPxDHLlMXURCTptjfSO(FEqvWBeVYKGwPxDHLlMXURCTptjfhr.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  FEqvWBeVYKGwPxDHLlMXURCTptjfNz=xbmcgui.Window(10000).getProperty('TVING_M_LOGINTIME')
  if FEqvWBeVYKGwPxDHLlMXURCTptjfNz==FEqvWBeVYKGwPxDHLlMXURCTptjfSm or FEqvWBeVYKGwPxDHLlMXURCTptjfNz=='':
   FEqvWBeVYKGwPxDHLlMXURCTptjfNz=FEqvWBeVYKGwPxDHLlMXURCTptjfSO('19000101')
  else:
   FEqvWBeVYKGwPxDHLlMXURCTptjfNz=FEqvWBeVYKGwPxDHLlMXURCTptjfSO(re.sub('-','',FEqvWBeVYKGwPxDHLlMXURCTptjfNz))
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   FEqvWBeVYKGwPxDHLlMXURCTptjfJh=0
   while FEqvWBeVYKGwPxDHLlMXURCTptjfSQ:
    FEqvWBeVYKGwPxDHLlMXURCTptjfJh+=1
    time.sleep(0.05)
    if FEqvWBeVYKGwPxDHLlMXURCTptjfNz>=FEqvWBeVYKGwPxDHLlMXURCTptjfNg:return
    if FEqvWBeVYKGwPxDHLlMXURCTptjfJh>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  if FEqvWBeVYKGwPxDHLlMXURCTptjfNz>=FEqvWBeVYKGwPxDHLlMXURCTptjfNg:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   return
  if not FEqvWBeVYKGwPxDHLlMXURCTptjfhr.TvingObj.GetCredential(FEqvWBeVYKGwPxDHLlMXURCTptjfNy,FEqvWBeVYKGwPxDHLlMXURCTptjfNs,FEqvWBeVYKGwPxDHLlMXURCTptjfNI,FEqvWBeVYKGwPxDHLlMXURCTptjfNk):
   FEqvWBeVYKGwPxDHLlMXURCTptjfhr.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   sys.exit()
  FEqvWBeVYKGwPxDHLlMXURCTptjfhr.set_winCredential(FEqvWBeVYKGwPxDHLlMXURCTptjfhr.TvingObj.LoadCredential())
  FEqvWBeVYKGwPxDHLlMXURCTptjfhr.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
 def dp_Title_Group(FEqvWBeVYKGwPxDHLlMXURCTptjfhr,FEqvWBeVYKGwPxDHLlMXURCTptjfJS):
  FEqvWBeVYKGwPxDHLlMXURCTptjfJN=FEqvWBeVYKGwPxDHLlMXURCTptjfJS.get('stype')
  if FEqvWBeVYKGwPxDHLlMXURCTptjfJN=='live':
   FEqvWBeVYKGwPxDHLlMXURCTptjfJb=FEqvWBeVYKGwPxDHLlMXURCTptjfhb
  elif FEqvWBeVYKGwPxDHLlMXURCTptjfJN=='vod':
   FEqvWBeVYKGwPxDHLlMXURCTptjfJb=FEqvWBeVYKGwPxDHLlMXURCTptjfhO
  else:
   FEqvWBeVYKGwPxDHLlMXURCTptjfJb=FEqvWBeVYKGwPxDHLlMXURCTptjfhd
  for FEqvWBeVYKGwPxDHLlMXURCTptjfJm in FEqvWBeVYKGwPxDHLlMXURCTptjfJb:
   FEqvWBeVYKGwPxDHLlMXURCTptjfNd=FEqvWBeVYKGwPxDHLlMXURCTptjfJm.get('title')
   if FEqvWBeVYKGwPxDHLlMXURCTptjfJS.get('ordernm')!='-':
    FEqvWBeVYKGwPxDHLlMXURCTptjfNd+='  ('+FEqvWBeVYKGwPxDHLlMXURCTptjfJS.get('ordernm')+')'
   FEqvWBeVYKGwPxDHLlMXURCTptjfNc={'mode':FEqvWBeVYKGwPxDHLlMXURCTptjfJm.get('mode'),'stype':FEqvWBeVYKGwPxDHLlMXURCTptjfJm.get('stype'),'orderby':FEqvWBeVYKGwPxDHLlMXURCTptjfJS.get('orderby'),'page':'1'}
   FEqvWBeVYKGwPxDHLlMXURCTptjfhr.add_dir(FEqvWBeVYKGwPxDHLlMXURCTptjfNd,sublabel='',img='',infoLabels=FEqvWBeVYKGwPxDHLlMXURCTptjfSm,isFolder=FEqvWBeVYKGwPxDHLlMXURCTptjfSQ,params=FEqvWBeVYKGwPxDHLlMXURCTptjfNc)
  if FEqvWBeVYKGwPxDHLlMXURCTptjfSo(FEqvWBeVYKGwPxDHLlMXURCTptjfJb)>0:xbmcplugin.endOfDirectory(FEqvWBeVYKGwPxDHLlMXURCTptjfhr._addon_handle)
 def dp_LiveChannel_List(FEqvWBeVYKGwPxDHLlMXURCTptjfhr,FEqvWBeVYKGwPxDHLlMXURCTptjfJS):
  FEqvWBeVYKGwPxDHLlMXURCTptjfhr.TvingObj.SaveCredential(FEqvWBeVYKGwPxDHLlMXURCTptjfhr.get_winCredential())
  FEqvWBeVYKGwPxDHLlMXURCTptjfJN =FEqvWBeVYKGwPxDHLlMXURCTptjfJS.get('stype')
  FEqvWBeVYKGwPxDHLlMXURCTptjfJO =FEqvWBeVYKGwPxDHLlMXURCTptjfSO(FEqvWBeVYKGwPxDHLlMXURCTptjfJS.get('page'))
  FEqvWBeVYKGwPxDHLlMXURCTptjfJd,FEqvWBeVYKGwPxDHLlMXURCTptjfJQ=FEqvWBeVYKGwPxDHLlMXURCTptjfhr.TvingObj.GetLiveChannelList(FEqvWBeVYKGwPxDHLlMXURCTptjfJN,FEqvWBeVYKGwPxDHLlMXURCTptjfJO)
  for FEqvWBeVYKGwPxDHLlMXURCTptjfJo in FEqvWBeVYKGwPxDHLlMXURCTptjfJd:
   FEqvWBeVYKGwPxDHLlMXURCTptjfNd =FEqvWBeVYKGwPxDHLlMXURCTptjfJo.get('title')
   FEqvWBeVYKGwPxDHLlMXURCTptjfNA =FEqvWBeVYKGwPxDHLlMXURCTptjfJo.get('channel')
   FEqvWBeVYKGwPxDHLlMXURCTptjfJr =FEqvWBeVYKGwPxDHLlMXURCTptjfJo.get('thumbnail')
   FEqvWBeVYKGwPxDHLlMXURCTptjfJi =FEqvWBeVYKGwPxDHLlMXURCTptjfJo.get('synopsis')
   FEqvWBeVYKGwPxDHLlMXURCTptjfJn=FEqvWBeVYKGwPxDHLlMXURCTptjfJo.get('channelepg')
   FEqvWBeVYKGwPxDHLlMXURCTptjfJc=FEqvWBeVYKGwPxDHLlMXURCTptjfJo.get('info')
   FEqvWBeVYKGwPxDHLlMXURCTptjfJc['plot']='%s\n%s\n%s\n\n%s'%(FEqvWBeVYKGwPxDHLlMXURCTptjfNA,FEqvWBeVYKGwPxDHLlMXURCTptjfNd,FEqvWBeVYKGwPxDHLlMXURCTptjfJn,FEqvWBeVYKGwPxDHLlMXURCTptjfJi)
   FEqvWBeVYKGwPxDHLlMXURCTptjfNc={'mode':'LIVE','mediacode':FEqvWBeVYKGwPxDHLlMXURCTptjfJo.get('mediacode'),'stype':FEqvWBeVYKGwPxDHLlMXURCTptjfJN}
   FEqvWBeVYKGwPxDHLlMXURCTptjfhr.add_dir(FEqvWBeVYKGwPxDHLlMXURCTptjfNA,sublabel=FEqvWBeVYKGwPxDHLlMXURCTptjfNd,img=FEqvWBeVYKGwPxDHLlMXURCTptjfJr,infoLabels=FEqvWBeVYKGwPxDHLlMXURCTptjfJc,isFolder=FEqvWBeVYKGwPxDHLlMXURCTptjfSd,params=FEqvWBeVYKGwPxDHLlMXURCTptjfNc)
  if FEqvWBeVYKGwPxDHLlMXURCTptjfJQ:
   FEqvWBeVYKGwPxDHLlMXURCTptjfNc['mode']='CHANNEL' 
   FEqvWBeVYKGwPxDHLlMXURCTptjfNc['stype']=FEqvWBeVYKGwPxDHLlMXURCTptjfJN 
   FEqvWBeVYKGwPxDHLlMXURCTptjfNc['page']=FEqvWBeVYKGwPxDHLlMXURCTptjfSr(FEqvWBeVYKGwPxDHLlMXURCTptjfJO+1)
   FEqvWBeVYKGwPxDHLlMXURCTptjfNd='[B]%s >>[/B]'%'다음 페이지'
   FEqvWBeVYKGwPxDHLlMXURCTptjfJu=FEqvWBeVYKGwPxDHLlMXURCTptjfSr(FEqvWBeVYKGwPxDHLlMXURCTptjfJO+1)
   FEqvWBeVYKGwPxDHLlMXURCTptjfhr.add_dir(FEqvWBeVYKGwPxDHLlMXURCTptjfNd,sublabel=FEqvWBeVYKGwPxDHLlMXURCTptjfJu,img='',infoLabels=FEqvWBeVYKGwPxDHLlMXURCTptjfSm,isFolder=FEqvWBeVYKGwPxDHLlMXURCTptjfSQ,params=FEqvWBeVYKGwPxDHLlMXURCTptjfNc)
  if FEqvWBeVYKGwPxDHLlMXURCTptjfSo(FEqvWBeVYKGwPxDHLlMXURCTptjfJd)>0:xbmcplugin.endOfDirectory(FEqvWBeVYKGwPxDHLlMXURCTptjfhr._addon_handle,cacheToDisc=FEqvWBeVYKGwPxDHLlMXURCTptjfSd)
 def dp_Program_List(FEqvWBeVYKGwPxDHLlMXURCTptjfhr,FEqvWBeVYKGwPxDHLlMXURCTptjfJS):
  FEqvWBeVYKGwPxDHLlMXURCTptjfhr.TvingObj.SaveCredential(FEqvWBeVYKGwPxDHLlMXURCTptjfhr.get_winCredential())
  FEqvWBeVYKGwPxDHLlMXURCTptjfJA =FEqvWBeVYKGwPxDHLlMXURCTptjfJS.get('stype')
  FEqvWBeVYKGwPxDHLlMXURCTptjfJy =FEqvWBeVYKGwPxDHLlMXURCTptjfJS.get('orderby')
  FEqvWBeVYKGwPxDHLlMXURCTptjfJO =FEqvWBeVYKGwPxDHLlMXURCTptjfSO(FEqvWBeVYKGwPxDHLlMXURCTptjfJS.get('page'))
  FEqvWBeVYKGwPxDHLlMXURCTptjfJs,FEqvWBeVYKGwPxDHLlMXURCTptjfJQ=FEqvWBeVYKGwPxDHLlMXURCTptjfhr.TvingObj.GetProgramList(FEqvWBeVYKGwPxDHLlMXURCTptjfJA,FEqvWBeVYKGwPxDHLlMXURCTptjfJy,FEqvWBeVYKGwPxDHLlMXURCTptjfJO,landyn=FEqvWBeVYKGwPxDHLlMXURCTptjfhr.get_settings_thumbnail_landyn())
  for FEqvWBeVYKGwPxDHLlMXURCTptjfJI in FEqvWBeVYKGwPxDHLlMXURCTptjfJs:
   FEqvWBeVYKGwPxDHLlMXURCTptjfNd =FEqvWBeVYKGwPxDHLlMXURCTptjfJI.get('title')
   FEqvWBeVYKGwPxDHLlMXURCTptjfJr=FEqvWBeVYKGwPxDHLlMXURCTptjfJI.get('thumbnail')
   FEqvWBeVYKGwPxDHLlMXURCTptjfJi =FEqvWBeVYKGwPxDHLlMXURCTptjfJI.get('synopsis')
   FEqvWBeVYKGwPxDHLlMXURCTptjfJk =FEqvWBeVYKGwPxDHLlMXURCTptjfhQ.get(FEqvWBeVYKGwPxDHLlMXURCTptjfJI.get('channel'))
   FEqvWBeVYKGwPxDHLlMXURCTptjfJc=FEqvWBeVYKGwPxDHLlMXURCTptjfJI.get('info')
   FEqvWBeVYKGwPxDHLlMXURCTptjfJc['studio']=FEqvWBeVYKGwPxDHLlMXURCTptjfJk
   FEqvWBeVYKGwPxDHLlMXURCTptjfJc['plot']='%s <%s>\n\n%s'%(FEqvWBeVYKGwPxDHLlMXURCTptjfNd,FEqvWBeVYKGwPxDHLlMXURCTptjfJk,FEqvWBeVYKGwPxDHLlMXURCTptjfJi)
   FEqvWBeVYKGwPxDHLlMXURCTptjfNc={'mode':'EPISODE','programcode':FEqvWBeVYKGwPxDHLlMXURCTptjfJI.get('program'),'page':'1'}
   FEqvWBeVYKGwPxDHLlMXURCTptjfhr.add_dir(FEqvWBeVYKGwPxDHLlMXURCTptjfNd,sublabel=FEqvWBeVYKGwPxDHLlMXURCTptjfJk,img=FEqvWBeVYKGwPxDHLlMXURCTptjfJr,infoLabels=FEqvWBeVYKGwPxDHLlMXURCTptjfJc,isFolder=FEqvWBeVYKGwPxDHLlMXURCTptjfSQ,params=FEqvWBeVYKGwPxDHLlMXURCTptjfNc)
  if FEqvWBeVYKGwPxDHLlMXURCTptjfJQ:
   FEqvWBeVYKGwPxDHLlMXURCTptjfNc['mode'] ='PROGRAM' 
   FEqvWBeVYKGwPxDHLlMXURCTptjfNc['stype'] =FEqvWBeVYKGwPxDHLlMXURCTptjfJA
   FEqvWBeVYKGwPxDHLlMXURCTptjfNc['orderby']=FEqvWBeVYKGwPxDHLlMXURCTptjfJy
   FEqvWBeVYKGwPxDHLlMXURCTptjfNc['page'] =FEqvWBeVYKGwPxDHLlMXURCTptjfSr(FEqvWBeVYKGwPxDHLlMXURCTptjfJO+1)
   FEqvWBeVYKGwPxDHLlMXURCTptjfNd='[B]%s >>[/B]'%'다음 페이지'
   FEqvWBeVYKGwPxDHLlMXURCTptjfJu=FEqvWBeVYKGwPxDHLlMXURCTptjfSr(FEqvWBeVYKGwPxDHLlMXURCTptjfJO+1)
   FEqvWBeVYKGwPxDHLlMXURCTptjfhr.add_dir(FEqvWBeVYKGwPxDHLlMXURCTptjfNd,sublabel=FEqvWBeVYKGwPxDHLlMXURCTptjfJu,img='',infoLabels=FEqvWBeVYKGwPxDHLlMXURCTptjfSm,isFolder=FEqvWBeVYKGwPxDHLlMXURCTptjfSQ,params=FEqvWBeVYKGwPxDHLlMXURCTptjfNc)
  if FEqvWBeVYKGwPxDHLlMXURCTptjfSo(FEqvWBeVYKGwPxDHLlMXURCTptjfJs)>0:xbmcplugin.endOfDirectory(FEqvWBeVYKGwPxDHLlMXURCTptjfhr._addon_handle,cacheToDisc=FEqvWBeVYKGwPxDHLlMXURCTptjfSd)
 def dp_Episode_List(FEqvWBeVYKGwPxDHLlMXURCTptjfhr,FEqvWBeVYKGwPxDHLlMXURCTptjfJS):
  FEqvWBeVYKGwPxDHLlMXURCTptjfhr.TvingObj.SaveCredential(FEqvWBeVYKGwPxDHLlMXURCTptjfhr.get_winCredential())
  FEqvWBeVYKGwPxDHLlMXURCTptjfJa=FEqvWBeVYKGwPxDHLlMXURCTptjfJS.get('programcode')
  FEqvWBeVYKGwPxDHLlMXURCTptjfJO =FEqvWBeVYKGwPxDHLlMXURCTptjfSO(FEqvWBeVYKGwPxDHLlMXURCTptjfJS.get('page'))
  FEqvWBeVYKGwPxDHLlMXURCTptjfJg,FEqvWBeVYKGwPxDHLlMXURCTptjfJQ,FEqvWBeVYKGwPxDHLlMXURCTptjfJz=FEqvWBeVYKGwPxDHLlMXURCTptjfhr.TvingObj.GetEpisodoList(FEqvWBeVYKGwPxDHLlMXURCTptjfJa,FEqvWBeVYKGwPxDHLlMXURCTptjfJO,orderby=FEqvWBeVYKGwPxDHLlMXURCTptjfhr.get_winEpisodeOrderby())
  for FEqvWBeVYKGwPxDHLlMXURCTptjfbh in FEqvWBeVYKGwPxDHLlMXURCTptjfJg:
   FEqvWBeVYKGwPxDHLlMXURCTptjfNd =FEqvWBeVYKGwPxDHLlMXURCTptjfbh.get('title')
   FEqvWBeVYKGwPxDHLlMXURCTptjfJu =FEqvWBeVYKGwPxDHLlMXURCTptjfbh.get('subtitle')
   FEqvWBeVYKGwPxDHLlMXURCTptjfJr=FEqvWBeVYKGwPxDHLlMXURCTptjfbh.get('thumbnail')
   FEqvWBeVYKGwPxDHLlMXURCTptjfJi =FEqvWBeVYKGwPxDHLlMXURCTptjfbh.get('synopsis')
   FEqvWBeVYKGwPxDHLlMXURCTptjfJc=FEqvWBeVYKGwPxDHLlMXURCTptjfbh.get('info')
   FEqvWBeVYKGwPxDHLlMXURCTptjfJc['plot']='%s\n\n%s'%(FEqvWBeVYKGwPxDHLlMXURCTptjfNd,FEqvWBeVYKGwPxDHLlMXURCTptjfJi)
   FEqvWBeVYKGwPxDHLlMXURCTptjfNc={'mode':'VOD','mediacode':FEqvWBeVYKGwPxDHLlMXURCTptjfbh.get('episode'),'stype':'vod','programcode':FEqvWBeVYKGwPxDHLlMXURCTptjfJa,'title':FEqvWBeVYKGwPxDHLlMXURCTptjfNd,'thumbnail':FEqvWBeVYKGwPxDHLlMXURCTptjfJr}
   FEqvWBeVYKGwPxDHLlMXURCTptjfhr.add_dir(FEqvWBeVYKGwPxDHLlMXURCTptjfNd,sublabel=FEqvWBeVYKGwPxDHLlMXURCTptjfJu,img=FEqvWBeVYKGwPxDHLlMXURCTptjfJr,infoLabels=FEqvWBeVYKGwPxDHLlMXURCTptjfJc,isFolder=FEqvWBeVYKGwPxDHLlMXURCTptjfSd,params=FEqvWBeVYKGwPxDHLlMXURCTptjfNc)
  if FEqvWBeVYKGwPxDHLlMXURCTptjfJO==1:
   FEqvWBeVYKGwPxDHLlMXURCTptjfJc={'plot':'정렬순서를 변경합니다.'}
   FEqvWBeVYKGwPxDHLlMXURCTptjfNc={}
   FEqvWBeVYKGwPxDHLlMXURCTptjfNc['mode'] ='ORDER_BY' 
   if FEqvWBeVYKGwPxDHLlMXURCTptjfhr.get_winEpisodeOrderby()=='desc':
    FEqvWBeVYKGwPxDHLlMXURCTptjfNd='정렬순서변경 : 최신화부터 -> 1회부터'
    FEqvWBeVYKGwPxDHLlMXURCTptjfNc['orderby']='asc'
   else:
    FEqvWBeVYKGwPxDHLlMXURCTptjfNd='정렬순서변경 : 1회부터 -> 최신화부터'
    FEqvWBeVYKGwPxDHLlMXURCTptjfNc['orderby']='desc'
   FEqvWBeVYKGwPxDHLlMXURCTptjfhr.add_dir(FEqvWBeVYKGwPxDHLlMXURCTptjfNd,sublabel='',img='',infoLabels=FEqvWBeVYKGwPxDHLlMXURCTptjfJc,isFolder=FEqvWBeVYKGwPxDHLlMXURCTptjfSd,params=FEqvWBeVYKGwPxDHLlMXURCTptjfNc)
  if FEqvWBeVYKGwPxDHLlMXURCTptjfJQ:
   FEqvWBeVYKGwPxDHLlMXURCTptjfNc['mode'] ='EPISODE' 
   FEqvWBeVYKGwPxDHLlMXURCTptjfNc['programcode']=FEqvWBeVYKGwPxDHLlMXURCTptjfJa
   FEqvWBeVYKGwPxDHLlMXURCTptjfNc['page'] =FEqvWBeVYKGwPxDHLlMXURCTptjfSr(FEqvWBeVYKGwPxDHLlMXURCTptjfJO+1)
   FEqvWBeVYKGwPxDHLlMXURCTptjfNd='[B]%s >>[/B]'%'다음 페이지'
   FEqvWBeVYKGwPxDHLlMXURCTptjfJu=FEqvWBeVYKGwPxDHLlMXURCTptjfSr(FEqvWBeVYKGwPxDHLlMXURCTptjfJO+1)
   FEqvWBeVYKGwPxDHLlMXURCTptjfhr.add_dir(FEqvWBeVYKGwPxDHLlMXURCTptjfNd,sublabel=FEqvWBeVYKGwPxDHLlMXURCTptjfJu,img='',infoLabels=FEqvWBeVYKGwPxDHLlMXURCTptjfSm,isFolder=FEqvWBeVYKGwPxDHLlMXURCTptjfSQ,params=FEqvWBeVYKGwPxDHLlMXURCTptjfNc)
  if FEqvWBeVYKGwPxDHLlMXURCTptjfSo(FEqvWBeVYKGwPxDHLlMXURCTptjfJg)>0:xbmcplugin.endOfDirectory(FEqvWBeVYKGwPxDHLlMXURCTptjfhr._addon_handle,cacheToDisc=FEqvWBeVYKGwPxDHLlMXURCTptjfSQ)
 def dp_setEpOrderby(FEqvWBeVYKGwPxDHLlMXURCTptjfhr,FEqvWBeVYKGwPxDHLlMXURCTptjfJS):
  FEqvWBeVYKGwPxDHLlMXURCTptjfJy =FEqvWBeVYKGwPxDHLlMXURCTptjfJS.get('orderby')
  FEqvWBeVYKGwPxDHLlMXURCTptjfhr.set_winEpisodeOrderby(FEqvWBeVYKGwPxDHLlMXURCTptjfJy)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(FEqvWBeVYKGwPxDHLlMXURCTptjfhr,FEqvWBeVYKGwPxDHLlMXURCTptjfJS):
  FEqvWBeVYKGwPxDHLlMXURCTptjfhr.TvingObj.SaveCredential(FEqvWBeVYKGwPxDHLlMXURCTptjfhr.get_winCredential())
  FEqvWBeVYKGwPxDHLlMXURCTptjfJA =FEqvWBeVYKGwPxDHLlMXURCTptjfJS.get('stype')
  FEqvWBeVYKGwPxDHLlMXURCTptjfJy =FEqvWBeVYKGwPxDHLlMXURCTptjfJS.get('orderby')
  FEqvWBeVYKGwPxDHLlMXURCTptjfJO=FEqvWBeVYKGwPxDHLlMXURCTptjfSO(FEqvWBeVYKGwPxDHLlMXURCTptjfJS.get('page'))
  FEqvWBeVYKGwPxDHLlMXURCTptjfbN,FEqvWBeVYKGwPxDHLlMXURCTptjfJQ=FEqvWBeVYKGwPxDHLlMXURCTptjfhr.TvingObj.GetMovieList(FEqvWBeVYKGwPxDHLlMXURCTptjfJA,FEqvWBeVYKGwPxDHLlMXURCTptjfJy,FEqvWBeVYKGwPxDHLlMXURCTptjfJO,landyn=FEqvWBeVYKGwPxDHLlMXURCTptjfhr.get_settings_thumbnail_landyn())
  for FEqvWBeVYKGwPxDHLlMXURCTptjfbJ in FEqvWBeVYKGwPxDHLlMXURCTptjfbN:
   FEqvWBeVYKGwPxDHLlMXURCTptjfNd =FEqvWBeVYKGwPxDHLlMXURCTptjfbJ.get('title')
   FEqvWBeVYKGwPxDHLlMXURCTptjfJr=FEqvWBeVYKGwPxDHLlMXURCTptjfbJ.get('thumbnail')
   FEqvWBeVYKGwPxDHLlMXURCTptjfJi =FEqvWBeVYKGwPxDHLlMXURCTptjfbJ.get('synopsis')
   FEqvWBeVYKGwPxDHLlMXURCTptjfJc=FEqvWBeVYKGwPxDHLlMXURCTptjfbJ.get('info')
   FEqvWBeVYKGwPxDHLlMXURCTptjfJc['plot']='%s\n\n%s'%(FEqvWBeVYKGwPxDHLlMXURCTptjfNd,FEqvWBeVYKGwPxDHLlMXURCTptjfJi)
   FEqvWBeVYKGwPxDHLlMXURCTptjfNc={'mode':'MOVIE','mediacode':FEqvWBeVYKGwPxDHLlMXURCTptjfbJ.get('moviecode'),'stype':'movie','title':FEqvWBeVYKGwPxDHLlMXURCTptjfNd,'thumbnail':FEqvWBeVYKGwPxDHLlMXURCTptjfJr}
   FEqvWBeVYKGwPxDHLlMXURCTptjfhr.add_dir(FEqvWBeVYKGwPxDHLlMXURCTptjfNd,sublabel='',img=FEqvWBeVYKGwPxDHLlMXURCTptjfJr,infoLabels=FEqvWBeVYKGwPxDHLlMXURCTptjfJc,isFolder=FEqvWBeVYKGwPxDHLlMXURCTptjfSd,params=FEqvWBeVYKGwPxDHLlMXURCTptjfNc)
  if FEqvWBeVYKGwPxDHLlMXURCTptjfJQ:
   FEqvWBeVYKGwPxDHLlMXURCTptjfNc={}
   FEqvWBeVYKGwPxDHLlMXURCTptjfNc['mode'] ='MOVIE_SUB' 
   FEqvWBeVYKGwPxDHLlMXURCTptjfNc['orderby']=FEqvWBeVYKGwPxDHLlMXURCTptjfJy
   FEqvWBeVYKGwPxDHLlMXURCTptjfNc['stype'] =FEqvWBeVYKGwPxDHLlMXURCTptjfJA
   FEqvWBeVYKGwPxDHLlMXURCTptjfNc['page'] =FEqvWBeVYKGwPxDHLlMXURCTptjfSr(FEqvWBeVYKGwPxDHLlMXURCTptjfJO+1)
   FEqvWBeVYKGwPxDHLlMXURCTptjfNd='[B]%s >>[/B]'%'다음 페이지'
   FEqvWBeVYKGwPxDHLlMXURCTptjfJu=FEqvWBeVYKGwPxDHLlMXURCTptjfSr(FEqvWBeVYKGwPxDHLlMXURCTptjfJO+1)
   FEqvWBeVYKGwPxDHLlMXURCTptjfhr.add_dir(FEqvWBeVYKGwPxDHLlMXURCTptjfNd,sublabel=FEqvWBeVYKGwPxDHLlMXURCTptjfJu,img='',infoLabels=FEqvWBeVYKGwPxDHLlMXURCTptjfSm,isFolder=FEqvWBeVYKGwPxDHLlMXURCTptjfSQ,params=FEqvWBeVYKGwPxDHLlMXURCTptjfNc)
  if FEqvWBeVYKGwPxDHLlMXURCTptjfSo(FEqvWBeVYKGwPxDHLlMXURCTptjfbN)>0:xbmcplugin.endOfDirectory(FEqvWBeVYKGwPxDHLlMXURCTptjfhr._addon_handle,cacheToDisc=FEqvWBeVYKGwPxDHLlMXURCTptjfSd)
 def dp_Search_Group(FEqvWBeVYKGwPxDHLlMXURCTptjfhr,FEqvWBeVYKGwPxDHLlMXURCTptjfJS):
  for FEqvWBeVYKGwPxDHLlMXURCTptjfJm in FEqvWBeVYKGwPxDHLlMXURCTptjfhS:
   FEqvWBeVYKGwPxDHLlMXURCTptjfNd=FEqvWBeVYKGwPxDHLlMXURCTptjfJm.get('title')
   FEqvWBeVYKGwPxDHLlMXURCTptjfNc={'mode':FEqvWBeVYKGwPxDHLlMXURCTptjfJm.get('mode'),'stype':FEqvWBeVYKGwPxDHLlMXURCTptjfJm.get('stype'),'page':'1'}
   FEqvWBeVYKGwPxDHLlMXURCTptjfhr.add_dir(FEqvWBeVYKGwPxDHLlMXURCTptjfNd,sublabel='',img='',infoLabels=FEqvWBeVYKGwPxDHLlMXURCTptjfSm,isFolder=FEqvWBeVYKGwPxDHLlMXURCTptjfSQ,params=FEqvWBeVYKGwPxDHLlMXURCTptjfNc)
  if FEqvWBeVYKGwPxDHLlMXURCTptjfSo(FEqvWBeVYKGwPxDHLlMXURCTptjfhS)>0:xbmcplugin.endOfDirectory(FEqvWBeVYKGwPxDHLlMXURCTptjfhr._addon_handle)
 def dp_Search_List(FEqvWBeVYKGwPxDHLlMXURCTptjfhr,FEqvWBeVYKGwPxDHLlMXURCTptjfJS):
  FEqvWBeVYKGwPxDHLlMXURCTptjfhr.TvingObj.SaveCredential(FEqvWBeVYKGwPxDHLlMXURCTptjfhr.get_winCredential())
  FEqvWBeVYKGwPxDHLlMXURCTptjfbm =__addon__.getSetting('id')
  FEqvWBeVYKGwPxDHLlMXURCTptjfJO =FEqvWBeVYKGwPxDHLlMXURCTptjfSO(FEqvWBeVYKGwPxDHLlMXURCTptjfJS.get('page'))
  FEqvWBeVYKGwPxDHLlMXURCTptjfJN =FEqvWBeVYKGwPxDHLlMXURCTptjfJS.get('stype')
  if 'search_key' in FEqvWBeVYKGwPxDHLlMXURCTptjfJS:
   FEqvWBeVYKGwPxDHLlMXURCTptjfbS=FEqvWBeVYKGwPxDHLlMXURCTptjfJS.get('search_key')
  else:
   FEqvWBeVYKGwPxDHLlMXURCTptjfbS=FEqvWBeVYKGwPxDHLlMXURCTptjfhr.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not FEqvWBeVYKGwPxDHLlMXURCTptjfbS:return
  FEqvWBeVYKGwPxDHLlMXURCTptjfbO,FEqvWBeVYKGwPxDHLlMXURCTptjfJQ=FEqvWBeVYKGwPxDHLlMXURCTptjfhr.TvingObj.GetSearchList(FEqvWBeVYKGwPxDHLlMXURCTptjfbS,FEqvWBeVYKGwPxDHLlMXURCTptjfbm,FEqvWBeVYKGwPxDHLlMXURCTptjfJO,FEqvWBeVYKGwPxDHLlMXURCTptjfJN,landyn=FEqvWBeVYKGwPxDHLlMXURCTptjfhr.get_settings_thumbnail_landyn())
  if FEqvWBeVYKGwPxDHLlMXURCTptjfSo(FEqvWBeVYKGwPxDHLlMXURCTptjfbO)==0:return
  for FEqvWBeVYKGwPxDHLlMXURCTptjfbd in FEqvWBeVYKGwPxDHLlMXURCTptjfbO:
   FEqvWBeVYKGwPxDHLlMXURCTptjfNd =FEqvWBeVYKGwPxDHLlMXURCTptjfbd.get('title')
   FEqvWBeVYKGwPxDHLlMXURCTptjfJr=FEqvWBeVYKGwPxDHLlMXURCTptjfbd.get('thumbnail')
   FEqvWBeVYKGwPxDHLlMXURCTptjfJi =FEqvWBeVYKGwPxDHLlMXURCTptjfbd.get('synopsis')
   FEqvWBeVYKGwPxDHLlMXURCTptjfbQ =FEqvWBeVYKGwPxDHLlMXURCTptjfbd.get('program')
   FEqvWBeVYKGwPxDHLlMXURCTptjfJc=FEqvWBeVYKGwPxDHLlMXURCTptjfbd.get('info')
   FEqvWBeVYKGwPxDHLlMXURCTptjfJc['plot']='%s\n\n%s'%(FEqvWBeVYKGwPxDHLlMXURCTptjfNd,FEqvWBeVYKGwPxDHLlMXURCTptjfJi)
   if FEqvWBeVYKGwPxDHLlMXURCTptjfJN=='vod':
    FEqvWBeVYKGwPxDHLlMXURCTptjfNc={'mode':'EPISODE','programcode':FEqvWBeVYKGwPxDHLlMXURCTptjfbd.get('program'),'page':'1'}
    FEqvWBeVYKGwPxDHLlMXURCTptjfNu=FEqvWBeVYKGwPxDHLlMXURCTptjfSQ
   else:
    FEqvWBeVYKGwPxDHLlMXURCTptjfNc={'mode':'MOVIE','mediacode':FEqvWBeVYKGwPxDHLlMXURCTptjfbd.get('movie'),'stype':'movie','title':FEqvWBeVYKGwPxDHLlMXURCTptjfNd,'thumbnail':FEqvWBeVYKGwPxDHLlMXURCTptjfJr}
    FEqvWBeVYKGwPxDHLlMXURCTptjfNu=FEqvWBeVYKGwPxDHLlMXURCTptjfSd
   FEqvWBeVYKGwPxDHLlMXURCTptjfhr.add_dir(FEqvWBeVYKGwPxDHLlMXURCTptjfNd,sublabel='',img=FEqvWBeVYKGwPxDHLlMXURCTptjfJr,infoLabels=FEqvWBeVYKGwPxDHLlMXURCTptjfJc,isFolder=FEqvWBeVYKGwPxDHLlMXURCTptjfNu,params=FEqvWBeVYKGwPxDHLlMXURCTptjfNc)
  if FEqvWBeVYKGwPxDHLlMXURCTptjfJQ:
   FEqvWBeVYKGwPxDHLlMXURCTptjfNc['mode'] ='SEARCH' 
   FEqvWBeVYKGwPxDHLlMXURCTptjfNc['search_key']=FEqvWBeVYKGwPxDHLlMXURCTptjfbS
   FEqvWBeVYKGwPxDHLlMXURCTptjfNc['page'] =FEqvWBeVYKGwPxDHLlMXURCTptjfSr(FEqvWBeVYKGwPxDHLlMXURCTptjfJO+1)
   FEqvWBeVYKGwPxDHLlMXURCTptjfNd='[B]%s >>[/B]'%'다음 페이지'
   FEqvWBeVYKGwPxDHLlMXURCTptjfJu=FEqvWBeVYKGwPxDHLlMXURCTptjfSr(FEqvWBeVYKGwPxDHLlMXURCTptjfJO+1)
   FEqvWBeVYKGwPxDHLlMXURCTptjfhr.add_dir(FEqvWBeVYKGwPxDHLlMXURCTptjfNd,sublabel=FEqvWBeVYKGwPxDHLlMXURCTptjfJu,img='',infoLabels=FEqvWBeVYKGwPxDHLlMXURCTptjfSm,isFolder=FEqvWBeVYKGwPxDHLlMXURCTptjfSQ,params=FEqvWBeVYKGwPxDHLlMXURCTptjfNc)
  if FEqvWBeVYKGwPxDHLlMXURCTptjfSo(FEqvWBeVYKGwPxDHLlMXURCTptjfbO)>0:xbmcplugin.endOfDirectory(FEqvWBeVYKGwPxDHLlMXURCTptjfhr._addon_handle)
 def Delete_Watched_List(FEqvWBeVYKGwPxDHLlMXURCTptjfhr,FEqvWBeVYKGwPxDHLlMXURCTptjfJN):
  try:
   FEqvWBeVYKGwPxDHLlMXURCTptjfbo=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%FEqvWBeVYKGwPxDHLlMXURCTptjfJN))
   fp=FEqvWBeVYKGwPxDHLlMXURCTptjfSi(FEqvWBeVYKGwPxDHLlMXURCTptjfbo,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   FEqvWBeVYKGwPxDHLlMXURCTptjfSm
 def dp_WatchList_Delete(FEqvWBeVYKGwPxDHLlMXURCTptjfhr,FEqvWBeVYKGwPxDHLlMXURCTptjfJS):
  FEqvWBeVYKGwPxDHLlMXURCTptjfJN=FEqvWBeVYKGwPxDHLlMXURCTptjfJS.get('stype')
  FEqvWBeVYKGwPxDHLlMXURCTptjfhA=xbmcgui.Dialog()
  FEqvWBeVYKGwPxDHLlMXURCTptjfNa=FEqvWBeVYKGwPxDHLlMXURCTptjfhA.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if FEqvWBeVYKGwPxDHLlMXURCTptjfNa==FEqvWBeVYKGwPxDHLlMXURCTptjfSd:sys.exit()
  FEqvWBeVYKGwPxDHLlMXURCTptjfhr.Delete_Watched_List(FEqvWBeVYKGwPxDHLlMXURCTptjfJN)
  xbmc.executebuiltin("Container.Refresh")
 def Load_Watched_List(FEqvWBeVYKGwPxDHLlMXURCTptjfhr,FEqvWBeVYKGwPxDHLlMXURCTptjfJN):
  try:
   FEqvWBeVYKGwPxDHLlMXURCTptjfbo=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%FEqvWBeVYKGwPxDHLlMXURCTptjfJN))
   fp=FEqvWBeVYKGwPxDHLlMXURCTptjfSi(FEqvWBeVYKGwPxDHLlMXURCTptjfbo,'r',-1,'utf-8')
   FEqvWBeVYKGwPxDHLlMXURCTptjfbr=fp.readlines()
   fp.close()
  except:
   FEqvWBeVYKGwPxDHLlMXURCTptjfbr=[]
  return FEqvWBeVYKGwPxDHLlMXURCTptjfbr
 def Save_Watched_List(FEqvWBeVYKGwPxDHLlMXURCTptjfhr,FEqvWBeVYKGwPxDHLlMXURCTptjfJN,FEqvWBeVYKGwPxDHLlMXURCTptjfhc):
  try:
   FEqvWBeVYKGwPxDHLlMXURCTptjfbo=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%FEqvWBeVYKGwPxDHLlMXURCTptjfJN))
   FEqvWBeVYKGwPxDHLlMXURCTptjfbi=FEqvWBeVYKGwPxDHLlMXURCTptjfhr.Load_Watched_List(FEqvWBeVYKGwPxDHLlMXURCTptjfJN) 
   fp=FEqvWBeVYKGwPxDHLlMXURCTptjfSi(FEqvWBeVYKGwPxDHLlMXURCTptjfbo,'w',-1,'utf-8')
   FEqvWBeVYKGwPxDHLlMXURCTptjfbn=urllib.parse.urlencode(FEqvWBeVYKGwPxDHLlMXURCTptjfhc)
   FEqvWBeVYKGwPxDHLlMXURCTptjfbn=FEqvWBeVYKGwPxDHLlMXURCTptjfbn+'\n'
   fp.write(FEqvWBeVYKGwPxDHLlMXURCTptjfbn)
   FEqvWBeVYKGwPxDHLlMXURCTptjfbc=0
   for FEqvWBeVYKGwPxDHLlMXURCTptjfbu in FEqvWBeVYKGwPxDHLlMXURCTptjfbi:
    FEqvWBeVYKGwPxDHLlMXURCTptjfbA=FEqvWBeVYKGwPxDHLlMXURCTptjfSn(urllib.parse.parse_qsl(FEqvWBeVYKGwPxDHLlMXURCTptjfbu))
    FEqvWBeVYKGwPxDHLlMXURCTptjfby=FEqvWBeVYKGwPxDHLlMXURCTptjfhc.get('code').strip()
    FEqvWBeVYKGwPxDHLlMXURCTptjfbs=FEqvWBeVYKGwPxDHLlMXURCTptjfbA.get('code').strip()
    if FEqvWBeVYKGwPxDHLlMXURCTptjfJN=='vod' and FEqvWBeVYKGwPxDHLlMXURCTptjfhr.get_settings_direct_replay()==FEqvWBeVYKGwPxDHLlMXURCTptjfSQ:
     FEqvWBeVYKGwPxDHLlMXURCTptjfby=FEqvWBeVYKGwPxDHLlMXURCTptjfhc.get('videoid').strip()
     FEqvWBeVYKGwPxDHLlMXURCTptjfbs=FEqvWBeVYKGwPxDHLlMXURCTptjfbA.get('videoid').strip()if FEqvWBeVYKGwPxDHLlMXURCTptjfbs!=FEqvWBeVYKGwPxDHLlMXURCTptjfSm else '-'
    if FEqvWBeVYKGwPxDHLlMXURCTptjfby!=FEqvWBeVYKGwPxDHLlMXURCTptjfbs:
     fp.write(FEqvWBeVYKGwPxDHLlMXURCTptjfbu)
     FEqvWBeVYKGwPxDHLlMXURCTptjfbc+=1
     if FEqvWBeVYKGwPxDHLlMXURCTptjfbc>=50:break
   fp.close()
  except:
   FEqvWBeVYKGwPxDHLlMXURCTptjfSm
 def dp_Watch_List(FEqvWBeVYKGwPxDHLlMXURCTptjfhr,FEqvWBeVYKGwPxDHLlMXURCTptjfJS):
  FEqvWBeVYKGwPxDHLlMXURCTptjfJN =FEqvWBeVYKGwPxDHLlMXURCTptjfJS.get('stype')
  FEqvWBeVYKGwPxDHLlMXURCTptjfNJ=FEqvWBeVYKGwPxDHLlMXURCTptjfhr.get_settings_direct_replay()
  if FEqvWBeVYKGwPxDHLlMXURCTptjfJN=='-':
   for FEqvWBeVYKGwPxDHLlMXURCTptjfJm in FEqvWBeVYKGwPxDHLlMXURCTptjfhm:
    FEqvWBeVYKGwPxDHLlMXURCTptjfNd=FEqvWBeVYKGwPxDHLlMXURCTptjfJm.get('title')
    FEqvWBeVYKGwPxDHLlMXURCTptjfNc={'mode':FEqvWBeVYKGwPxDHLlMXURCTptjfJm.get('mode'),'stype':FEqvWBeVYKGwPxDHLlMXURCTptjfJm.get('stype')}
    FEqvWBeVYKGwPxDHLlMXURCTptjfhr.add_dir(FEqvWBeVYKGwPxDHLlMXURCTptjfNd,sublabel='',img='',infoLabels=FEqvWBeVYKGwPxDHLlMXURCTptjfSm,isFolder=FEqvWBeVYKGwPxDHLlMXURCTptjfSQ,params=FEqvWBeVYKGwPxDHLlMXURCTptjfNc)
   if FEqvWBeVYKGwPxDHLlMXURCTptjfSo(FEqvWBeVYKGwPxDHLlMXURCTptjfhm)>0:xbmcplugin.endOfDirectory(FEqvWBeVYKGwPxDHLlMXURCTptjfhr._addon_handle)
  else:
   FEqvWBeVYKGwPxDHLlMXURCTptjfbI=FEqvWBeVYKGwPxDHLlMXURCTptjfhr.Load_Watched_List(FEqvWBeVYKGwPxDHLlMXURCTptjfJN)
   for FEqvWBeVYKGwPxDHLlMXURCTptjfbk in FEqvWBeVYKGwPxDHLlMXURCTptjfbI:
    FEqvWBeVYKGwPxDHLlMXURCTptjfba=FEqvWBeVYKGwPxDHLlMXURCTptjfSn(urllib.parse.parse_qsl(FEqvWBeVYKGwPxDHLlMXURCTptjfbk))
    FEqvWBeVYKGwPxDHLlMXURCTptjfbg =FEqvWBeVYKGwPxDHLlMXURCTptjfba.get('code').strip()
    FEqvWBeVYKGwPxDHLlMXURCTptjfNd =FEqvWBeVYKGwPxDHLlMXURCTptjfba.get('title').strip()
    FEqvWBeVYKGwPxDHLlMXURCTptjfJr=FEqvWBeVYKGwPxDHLlMXURCTptjfba.get('img').strip()
    FEqvWBeVYKGwPxDHLlMXURCTptjfbz =FEqvWBeVYKGwPxDHLlMXURCTptjfba.get('videoid').strip()
    FEqvWBeVYKGwPxDHLlMXURCTptjfJc={}
    FEqvWBeVYKGwPxDHLlMXURCTptjfJc['plot']=FEqvWBeVYKGwPxDHLlMXURCTptjfNd
    if FEqvWBeVYKGwPxDHLlMXURCTptjfJN=='vod':
     if FEqvWBeVYKGwPxDHLlMXURCTptjfNJ==FEqvWBeVYKGwPxDHLlMXURCTptjfSd or FEqvWBeVYKGwPxDHLlMXURCTptjfbz==FEqvWBeVYKGwPxDHLlMXURCTptjfSm:
      FEqvWBeVYKGwPxDHLlMXURCTptjfNc={'mode':'EPISODE','programcode':FEqvWBeVYKGwPxDHLlMXURCTptjfbg,'page':'1'}
      FEqvWBeVYKGwPxDHLlMXURCTptjfNu=FEqvWBeVYKGwPxDHLlMXURCTptjfSQ
     else:
      FEqvWBeVYKGwPxDHLlMXURCTptjfNc={'mode':'VOD','mediacode':FEqvWBeVYKGwPxDHLlMXURCTptjfbz,'stype':'vod','programcode':FEqvWBeVYKGwPxDHLlMXURCTptjfbg,'title':FEqvWBeVYKGwPxDHLlMXURCTptjfNd,'thumbnail':FEqvWBeVYKGwPxDHLlMXURCTptjfJr}
      FEqvWBeVYKGwPxDHLlMXURCTptjfNu=FEqvWBeVYKGwPxDHLlMXURCTptjfSd
    else:
     FEqvWBeVYKGwPxDHLlMXURCTptjfNc={'mode':'MOVIE','mediacode':FEqvWBeVYKGwPxDHLlMXURCTptjfbg,'stype':'movie','title':FEqvWBeVYKGwPxDHLlMXURCTptjfNd,'thumbnail':FEqvWBeVYKGwPxDHLlMXURCTptjfJr}
     FEqvWBeVYKGwPxDHLlMXURCTptjfNu=FEqvWBeVYKGwPxDHLlMXURCTptjfSd
    FEqvWBeVYKGwPxDHLlMXURCTptjfhr.add_dir(FEqvWBeVYKGwPxDHLlMXURCTptjfNd,sublabel='',img=FEqvWBeVYKGwPxDHLlMXURCTptjfJr,infoLabels=FEqvWBeVYKGwPxDHLlMXURCTptjfJc,isFolder=FEqvWBeVYKGwPxDHLlMXURCTptjfNu,params=FEqvWBeVYKGwPxDHLlMXURCTptjfNc)
   FEqvWBeVYKGwPxDHLlMXURCTptjfJc={'plot':'시청목록을 삭제합니다.'}
   FEqvWBeVYKGwPxDHLlMXURCTptjfNd='*** 시청목록 삭제 ***'
   FEqvWBeVYKGwPxDHLlMXURCTptjfNc={'mode':'MYVIEW_REMOVE','stype':FEqvWBeVYKGwPxDHLlMXURCTptjfJN}
   FEqvWBeVYKGwPxDHLlMXURCTptjfhr.add_dir(FEqvWBeVYKGwPxDHLlMXURCTptjfNd,sublabel='',img='',infoLabels=FEqvWBeVYKGwPxDHLlMXURCTptjfJc,isFolder=FEqvWBeVYKGwPxDHLlMXURCTptjfSd,params=FEqvWBeVYKGwPxDHLlMXURCTptjfNc)
   xbmcplugin.endOfDirectory(FEqvWBeVYKGwPxDHLlMXURCTptjfhr._addon_handle,cacheToDisc=FEqvWBeVYKGwPxDHLlMXURCTptjfSd)
 def play_VIDEO(FEqvWBeVYKGwPxDHLlMXURCTptjfhr,FEqvWBeVYKGwPxDHLlMXURCTptjfJS):
  FEqvWBeVYKGwPxDHLlMXURCTptjfhr.TvingObj.SaveCredential(FEqvWBeVYKGwPxDHLlMXURCTptjfhr.get_winCredential())
  FEqvWBeVYKGwPxDHLlMXURCTptjfmN =FEqvWBeVYKGwPxDHLlMXURCTptjfJS.get('mediacode')
  FEqvWBeVYKGwPxDHLlMXURCTptjfJN =FEqvWBeVYKGwPxDHLlMXURCTptjfJS.get('stype')
  FEqvWBeVYKGwPxDHLlMXURCTptjfmJ =FEqvWBeVYKGwPxDHLlMXURCTptjfJS.get('pvrmode')
  FEqvWBeVYKGwPxDHLlMXURCTptjfmb=FEqvWBeVYKGwPxDHLlMXURCTptjfhr.get_selQuality(FEqvWBeVYKGwPxDHLlMXURCTptjfJN)
  FEqvWBeVYKGwPxDHLlMXURCTptjfmS,FEqvWBeVYKGwPxDHLlMXURCTptjfmO=FEqvWBeVYKGwPxDHLlMXURCTptjfhr.TvingObj.GetBroadURL(FEqvWBeVYKGwPxDHLlMXURCTptjfmN,FEqvWBeVYKGwPxDHLlMXURCTptjfmb,FEqvWBeVYKGwPxDHLlMXURCTptjfJN,FEqvWBeVYKGwPxDHLlMXURCTptjfmJ)
  FEqvWBeVYKGwPxDHLlMXURCTptjfhr.addon_log('qt, stype, url : %s - %s - %s'%(FEqvWBeVYKGwPxDHLlMXURCTptjfSr(FEqvWBeVYKGwPxDHLlMXURCTptjfmb),FEqvWBeVYKGwPxDHLlMXURCTptjfJN,FEqvWBeVYKGwPxDHLlMXURCTptjfmS))
  if FEqvWBeVYKGwPxDHLlMXURCTptjfmS=='':
   FEqvWBeVYKGwPxDHLlMXURCTptjfhr.addon_noti(__language__(30908).encode('utf8'))
   return
  FEqvWBeVYKGwPxDHLlMXURCTptjfmd =FEqvWBeVYKGwPxDHLlMXURCTptjfmS.find('Policy=')
  if FEqvWBeVYKGwPxDHLlMXURCTptjfmd!=-1:
   FEqvWBeVYKGwPxDHLlMXURCTptjfmQ =FEqvWBeVYKGwPxDHLlMXURCTptjfmS.split('?')[0]
   FEqvWBeVYKGwPxDHLlMXURCTptjfmo=FEqvWBeVYKGwPxDHLlMXURCTptjfSn(urllib.parse.parse_qsl(urllib.parse.urlsplit(FEqvWBeVYKGwPxDHLlMXURCTptjfmS).query))
   FEqvWBeVYKGwPxDHLlMXURCTptjfmo=urllib.parse.urlencode(FEqvWBeVYKGwPxDHLlMXURCTptjfmo)
   FEqvWBeVYKGwPxDHLlMXURCTptjfmo=FEqvWBeVYKGwPxDHLlMXURCTptjfmo.replace('&',';')
   FEqvWBeVYKGwPxDHLlMXURCTptjfmo=FEqvWBeVYKGwPxDHLlMXURCTptjfmo.replace('Policy','CloudFront-Policy')
   FEqvWBeVYKGwPxDHLlMXURCTptjfmo=FEqvWBeVYKGwPxDHLlMXURCTptjfmo.replace('Signature','CloudFront-Signature')
   FEqvWBeVYKGwPxDHLlMXURCTptjfmo=FEqvWBeVYKGwPxDHLlMXURCTptjfmo.replace('Key-Pair-Id','CloudFront-Key-Pair-Id')
   FEqvWBeVYKGwPxDHLlMXURCTptjfmr='%s|Cookie=%s'%(FEqvWBeVYKGwPxDHLlMXURCTptjfmQ,FEqvWBeVYKGwPxDHLlMXURCTptjfmo)
  else:
   FEqvWBeVYKGwPxDHLlMXURCTptjfmr=FEqvWBeVYKGwPxDHLlMXURCTptjfmS
  FEqvWBeVYKGwPxDHLlMXURCTptjfhr.addon_log(FEqvWBeVYKGwPxDHLlMXURCTptjfmr)
  FEqvWBeVYKGwPxDHLlMXURCTptjfmi=xbmcgui.ListItem(path=FEqvWBeVYKGwPxDHLlMXURCTptjfmr)
  if FEqvWBeVYKGwPxDHLlMXURCTptjfmO!='':
   FEqvWBeVYKGwPxDHLlMXURCTptjfmn=FEqvWBeVYKGwPxDHLlMXURCTptjfmO
   FEqvWBeVYKGwPxDHLlMXURCTptjfmc ='https://cj.drmkeyserver.com/widevine_license'
   FEqvWBeVYKGwPxDHLlMXURCTptjfmu ='mpd'
   FEqvWBeVYKGwPxDHLlMXURCTptjfmA ='com.widevine.alpha'
   FEqvWBeVYKGwPxDHLlMXURCTptjfmy =inputstreamhelper.Helper(FEqvWBeVYKGwPxDHLlMXURCTptjfmu,drm='widevine')
   if FEqvWBeVYKGwPxDHLlMXURCTptjfmy.check_inputstream():
    FEqvWBeVYKGwPxDHLlMXURCTptjfms={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/live/player/%s'%FEqvWBeVYKGwPxDHLlMXURCTptjfmN,'sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':FEqvWBeVYKGwPxDHLlMXURCTptjfhr.TvingObj.USER_AGENT,'AcquireLicenseAssertion':FEqvWBeVYKGwPxDHLlMXURCTptjfmn,'Host':'cj.drmkeyserver.com'}
    FEqvWBeVYKGwPxDHLlMXURCTptjfmI=FEqvWBeVYKGwPxDHLlMXURCTptjfmc+'|'+urllib.parse.urlencode(FEqvWBeVYKGwPxDHLlMXURCTptjfms)+'|R{SSM}|'
    FEqvWBeVYKGwPxDHLlMXURCTptjfmi.setProperty('inputstream',FEqvWBeVYKGwPxDHLlMXURCTptjfmy.inputstream_addon)
    FEqvWBeVYKGwPxDHLlMXURCTptjfmi.setProperty('inputstream.adaptive.manifest_type',FEqvWBeVYKGwPxDHLlMXURCTptjfmu)
    FEqvWBeVYKGwPxDHLlMXURCTptjfmi.setProperty('inputstream.adaptive.license_type',FEqvWBeVYKGwPxDHLlMXURCTptjfmA)
    FEqvWBeVYKGwPxDHLlMXURCTptjfmi.setProperty('inputstream.adaptive.license_key',FEqvWBeVYKGwPxDHLlMXURCTptjfmI)
    FEqvWBeVYKGwPxDHLlMXURCTptjfmi.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(FEqvWBeVYKGwPxDHLlMXURCTptjfhr.TvingObj.USER_AGENT))
  xbmcplugin.setResolvedUrl(FEqvWBeVYKGwPxDHLlMXURCTptjfhr._addon_handle,FEqvWBeVYKGwPxDHLlMXURCTptjfSQ,FEqvWBeVYKGwPxDHLlMXURCTptjfmi)
  try:
   if FEqvWBeVYKGwPxDHLlMXURCTptjfJS.get('mode')in['VOD','MOVIE']and FEqvWBeVYKGwPxDHLlMXURCTptjfJS.get('title'):
    FEqvWBeVYKGwPxDHLlMXURCTptjfNc={'code':FEqvWBeVYKGwPxDHLlMXURCTptjfJS.get('programcode')if FEqvWBeVYKGwPxDHLlMXURCTptjfJS.get('mode')=='VOD' else FEqvWBeVYKGwPxDHLlMXURCTptjfJS.get('mediacode'),'img':FEqvWBeVYKGwPxDHLlMXURCTptjfJS.get('thumbnail'),'title':FEqvWBeVYKGwPxDHLlMXURCTptjfJS.get('title'),'videoid':FEqvWBeVYKGwPxDHLlMXURCTptjfJS.get('mediacode')}
    FEqvWBeVYKGwPxDHLlMXURCTptjfhr.Save_Watched_List(FEqvWBeVYKGwPxDHLlMXURCTptjfJS.get('stype'),FEqvWBeVYKGwPxDHLlMXURCTptjfNc)
  except:
   FEqvWBeVYKGwPxDHLlMXURCTptjfSm
 def logout(FEqvWBeVYKGwPxDHLlMXURCTptjfhr):
  FEqvWBeVYKGwPxDHLlMXURCTptjfhA=xbmcgui.Dialog()
  FEqvWBeVYKGwPxDHLlMXURCTptjfNa=FEqvWBeVYKGwPxDHLlMXURCTptjfhA.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if FEqvWBeVYKGwPxDHLlMXURCTptjfNa==FEqvWBeVYKGwPxDHLlMXURCTptjfSd:sys.exit()
  FEqvWBeVYKGwPxDHLlMXURCTptjfhr.wininfo_clear()
  if os.path.isfile(FEqvWBeVYKGwPxDHLlMXURCTptjfho):os.remove(FEqvWBeVYKGwPxDHLlMXURCTptjfho)
  FEqvWBeVYKGwPxDHLlMXURCTptjfhr.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(FEqvWBeVYKGwPxDHLlMXURCTptjfhr):
  FEqvWBeVYKGwPxDHLlMXURCTptjfNm=xbmcgui.Window(10000)
  FEqvWBeVYKGwPxDHLlMXURCTptjfNm.setProperty('TVING_M_TOKEN','')
  FEqvWBeVYKGwPxDHLlMXURCTptjfNm.setProperty('TVING_M_USERINFO','')
  FEqvWBeVYKGwPxDHLlMXURCTptjfNm.setProperty('TVING_M_UUID','')
  FEqvWBeVYKGwPxDHLlMXURCTptjfNm.setProperty('TVING_M_LOGINTIME','')
  FEqvWBeVYKGwPxDHLlMXURCTptjfNm.setProperty('TVING_M_MAINTOKEN','')
  FEqvWBeVYKGwPxDHLlMXURCTptjfNm.setProperty('TVING_M_COOKIEKEY','')
  FEqvWBeVYKGwPxDHLlMXURCTptjfNm.setProperty('TVING_M_LOCKKEY','')
 def cookiefile_save(FEqvWBeVYKGwPxDHLlMXURCTptjfhr):
  FEqvWBeVYKGwPxDHLlMXURCTptjfmk =FEqvWBeVYKGwPxDHLlMXURCTptjfhr.TvingObj.Get_Now_Datetime()
  FEqvWBeVYKGwPxDHLlMXURCTptjfma=FEqvWBeVYKGwPxDHLlMXURCTptjfmk+datetime.timedelta(days=FEqvWBeVYKGwPxDHLlMXURCTptjfSO(__addon__.getSetting('cache_ttl')))
  FEqvWBeVYKGwPxDHLlMXURCTptjfNm=xbmcgui.Window(10000)
  FEqvWBeVYKGwPxDHLlMXURCTptjfmg={'tving_token':FEqvWBeVYKGwPxDHLlMXURCTptjfNm.getProperty('TVING_M_TOKEN'),'tving_userinfo':FEqvWBeVYKGwPxDHLlMXURCTptjfNm.getProperty('TVING_M_USERINFO'),'tving_uuid':FEqvWBeVYKGwPxDHLlMXURCTptjfNm.getProperty('TVING_M_UUID'),'tving_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'tving_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'tving_logintype':__addon__.getSetting('login_type'),'tving_profile':__addon__.getSetting('selected_profile'),'tving_limitdate':FEqvWBeVYKGwPxDHLlMXURCTptjfma.strftime('%Y-%m-%d'),'tving_maintoken':FEqvWBeVYKGwPxDHLlMXURCTptjfNm.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':FEqvWBeVYKGwPxDHLlMXURCTptjfNm.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':FEqvWBeVYKGwPxDHLlMXURCTptjfNm.getProperty('TVING_M_LOCKKEY')}
  try: 
   fp=FEqvWBeVYKGwPxDHLlMXURCTptjfSi(FEqvWBeVYKGwPxDHLlMXURCTptjfho,'w',-1,'utf-8')
   json.dump(FEqvWBeVYKGwPxDHLlMXURCTptjfmg,fp)
   fp.close()
  except FEqvWBeVYKGwPxDHLlMXURCTptjfSc as exception:
   FEqvWBeVYKGwPxDHLlMXURCTptjfSu(exception)
 def cookiefile_check(FEqvWBeVYKGwPxDHLlMXURCTptjfhr):
  FEqvWBeVYKGwPxDHLlMXURCTptjfmg={}
  try: 
   fp=FEqvWBeVYKGwPxDHLlMXURCTptjfSi(FEqvWBeVYKGwPxDHLlMXURCTptjfho,'r',-1,'utf-8')
   FEqvWBeVYKGwPxDHLlMXURCTptjfmg= json.load(fp)
   fp.close()
  except FEqvWBeVYKGwPxDHLlMXURCTptjfSc as exception:
   FEqvWBeVYKGwPxDHLlMXURCTptjfhr.wininfo_clear()
   return FEqvWBeVYKGwPxDHLlMXURCTptjfSd
  FEqvWBeVYKGwPxDHLlMXURCTptjfNy =__addon__.getSetting('id')
  FEqvWBeVYKGwPxDHLlMXURCTptjfNs =__addon__.getSetting('pw')
  FEqvWBeVYKGwPxDHLlMXURCTptjfmz=__addon__.getSetting('login_type')
  FEqvWBeVYKGwPxDHLlMXURCTptjfSh =__addon__.getSetting('selected_profile')
  FEqvWBeVYKGwPxDHLlMXURCTptjfmg['tving_id']=base64.standard_b64decode(FEqvWBeVYKGwPxDHLlMXURCTptjfmg['tving_id']).decode('utf-8')
  FEqvWBeVYKGwPxDHLlMXURCTptjfmg['tving_pw']=base64.standard_b64decode(FEqvWBeVYKGwPxDHLlMXURCTptjfmg['tving_pw']).decode('utf-8')
  try:
   FEqvWBeVYKGwPxDHLlMXURCTptjfmg['tving_profile']
  except:
   FEqvWBeVYKGwPxDHLlMXURCTptjfmg['tving_profile']='0'
  if FEqvWBeVYKGwPxDHLlMXURCTptjfNy!=FEqvWBeVYKGwPxDHLlMXURCTptjfmg['tving_id']or FEqvWBeVYKGwPxDHLlMXURCTptjfNs!=FEqvWBeVYKGwPxDHLlMXURCTptjfmg['tving_pw']or FEqvWBeVYKGwPxDHLlMXURCTptjfmz!=FEqvWBeVYKGwPxDHLlMXURCTptjfmg['tving_logintype']or FEqvWBeVYKGwPxDHLlMXURCTptjfSh!=FEqvWBeVYKGwPxDHLlMXURCTptjfmg['tving_profile']:
   FEqvWBeVYKGwPxDHLlMXURCTptjfhr.wininfo_clear()
   return FEqvWBeVYKGwPxDHLlMXURCTptjfSd
  FEqvWBeVYKGwPxDHLlMXURCTptjfNg =FEqvWBeVYKGwPxDHLlMXURCTptjfSO(FEqvWBeVYKGwPxDHLlMXURCTptjfhr.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  FEqvWBeVYKGwPxDHLlMXURCTptjfSN=FEqvWBeVYKGwPxDHLlMXURCTptjfmg['tving_limitdate']
  FEqvWBeVYKGwPxDHLlMXURCTptjfNz =FEqvWBeVYKGwPxDHLlMXURCTptjfSO(re.sub('-','',FEqvWBeVYKGwPxDHLlMXURCTptjfSN))
  if FEqvWBeVYKGwPxDHLlMXURCTptjfNz<FEqvWBeVYKGwPxDHLlMXURCTptjfNg:
   FEqvWBeVYKGwPxDHLlMXURCTptjfhr.wininfo_clear()
   return FEqvWBeVYKGwPxDHLlMXURCTptjfSd
  FEqvWBeVYKGwPxDHLlMXURCTptjfNm=xbmcgui.Window(10000)
  FEqvWBeVYKGwPxDHLlMXURCTptjfNm.setProperty('TVING_M_TOKEN',FEqvWBeVYKGwPxDHLlMXURCTptjfmg['tving_token'])
  FEqvWBeVYKGwPxDHLlMXURCTptjfNm.setProperty('TVING_M_USERINFO',FEqvWBeVYKGwPxDHLlMXURCTptjfmg['tving_userinfo'])
  FEqvWBeVYKGwPxDHLlMXURCTptjfNm.setProperty('TVING_M_UUID',FEqvWBeVYKGwPxDHLlMXURCTptjfmg['tving_uuid'])
  FEqvWBeVYKGwPxDHLlMXURCTptjfNm.setProperty('TVING_M_LOGINTIME',FEqvWBeVYKGwPxDHLlMXURCTptjfSN)
  try:
   FEqvWBeVYKGwPxDHLlMXURCTptjfNm.setProperty('TVING_M_MAINTOKEN',FEqvWBeVYKGwPxDHLlMXURCTptjfmg['tving_maintoken'])
   FEqvWBeVYKGwPxDHLlMXURCTptjfNm.setProperty('TVING_M_COOKIEKEY',FEqvWBeVYKGwPxDHLlMXURCTptjfmg['tving_cookiekey'])
   FEqvWBeVYKGwPxDHLlMXURCTptjfNm.setProperty('TVING_M_LOCKKEY',FEqvWBeVYKGwPxDHLlMXURCTptjfmg['tving_lockkey'])
  except:
   FEqvWBeVYKGwPxDHLlMXURCTptjfNm.setProperty('TVING_M_MAINTOKEN',FEqvWBeVYKGwPxDHLlMXURCTptjfmg['tving_token'])
   FEqvWBeVYKGwPxDHLlMXURCTptjfNm.setProperty('TVING_M_COOKIEKEY','Y')
   FEqvWBeVYKGwPxDHLlMXURCTptjfNm.setProperty('TVING_M_LOCKKEY','N')
  return FEqvWBeVYKGwPxDHLlMXURCTptjfSQ
 def tving_main(FEqvWBeVYKGwPxDHLlMXURCTptjfhr):
  FEqvWBeVYKGwPxDHLlMXURCTptjfSJ=FEqvWBeVYKGwPxDHLlMXURCTptjfhr.main_params.get('mode',FEqvWBeVYKGwPxDHLlMXURCTptjfSm)
  if FEqvWBeVYKGwPxDHLlMXURCTptjfSJ=='LOGOUT':
   FEqvWBeVYKGwPxDHLlMXURCTptjfhr.logout()
   return
  FEqvWBeVYKGwPxDHLlMXURCTptjfhr.login_main()
  if FEqvWBeVYKGwPxDHLlMXURCTptjfSJ is FEqvWBeVYKGwPxDHLlMXURCTptjfSm:
   FEqvWBeVYKGwPxDHLlMXURCTptjfhr.dp_Main_List()
  elif FEqvWBeVYKGwPxDHLlMXURCTptjfSJ in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   FEqvWBeVYKGwPxDHLlMXURCTptjfhr.dp_Title_Group(FEqvWBeVYKGwPxDHLlMXURCTptjfhr.main_params)
  elif FEqvWBeVYKGwPxDHLlMXURCTptjfSJ=='CHANNEL':
   FEqvWBeVYKGwPxDHLlMXURCTptjfhr.dp_LiveChannel_List(FEqvWBeVYKGwPxDHLlMXURCTptjfhr.main_params)
  elif FEqvWBeVYKGwPxDHLlMXURCTptjfSJ in['LIVE','VOD','MOVIE']:
   FEqvWBeVYKGwPxDHLlMXURCTptjfhr.play_VIDEO(FEqvWBeVYKGwPxDHLlMXURCTptjfhr.main_params)
  elif FEqvWBeVYKGwPxDHLlMXURCTptjfSJ=='PROGRAM':
   FEqvWBeVYKGwPxDHLlMXURCTptjfhr.dp_Program_List(FEqvWBeVYKGwPxDHLlMXURCTptjfhr.main_params)
  elif FEqvWBeVYKGwPxDHLlMXURCTptjfSJ=='EPISODE':
   FEqvWBeVYKGwPxDHLlMXURCTptjfhr.dp_Episode_List(FEqvWBeVYKGwPxDHLlMXURCTptjfhr.main_params)
  elif FEqvWBeVYKGwPxDHLlMXURCTptjfSJ=='MOVIE_SUB':
   FEqvWBeVYKGwPxDHLlMXURCTptjfhr.dp_Movie_List(FEqvWBeVYKGwPxDHLlMXURCTptjfhr.main_params)
  elif FEqvWBeVYKGwPxDHLlMXURCTptjfSJ=='SEARCH_GROUP':
   FEqvWBeVYKGwPxDHLlMXURCTptjfhr.dp_Search_Group(FEqvWBeVYKGwPxDHLlMXURCTptjfhr.main_params)
  elif FEqvWBeVYKGwPxDHLlMXURCTptjfSJ=='SEARCH':
   FEqvWBeVYKGwPxDHLlMXURCTptjfhr.dp_Search_List(FEqvWBeVYKGwPxDHLlMXURCTptjfhr.main_params)
  elif FEqvWBeVYKGwPxDHLlMXURCTptjfSJ=='WATCH':
   FEqvWBeVYKGwPxDHLlMXURCTptjfhr.dp_Watch_List(FEqvWBeVYKGwPxDHLlMXURCTptjfhr.main_params)
  elif FEqvWBeVYKGwPxDHLlMXURCTptjfSJ=='MYVIEW_REMOVE':
   FEqvWBeVYKGwPxDHLlMXURCTptjfhr.dp_WatchList_Delete(FEqvWBeVYKGwPxDHLlMXURCTptjfhr.main_params)
  elif FEqvWBeVYKGwPxDHLlMXURCTptjfSJ=='ORDER_BY':
   FEqvWBeVYKGwPxDHLlMXURCTptjfhr.dp_setEpOrderby(FEqvWBeVYKGwPxDHLlMXURCTptjfhr.main_params)
  else:
   FEqvWBeVYKGwPxDHLlMXURCTptjfSm
# Created by pyminifier (https://github.com/liftoff/pyminifier)
