__author__="NightRain"
mNnWwAyEzrVKpavGdCSFIBLusDfHkt=object
mNnWwAyEzrVKpavGdCSFIBLusDfHkU=None
mNnWwAyEzrVKpavGdCSFIBLusDfHkJ=int
mNnWwAyEzrVKpavGdCSFIBLusDfHkq=True
mNnWwAyEzrVKpavGdCSFIBLusDfHkh=False
mNnWwAyEzrVKpavGdCSFIBLusDfHkY=type
mNnWwAyEzrVKpavGdCSFIBLusDfHki=dict
mNnWwAyEzrVKpavGdCSFIBLusDfHkQ=len
mNnWwAyEzrVKpavGdCSFIBLusDfHkj=str
mNnWwAyEzrVKpavGdCSFIBLusDfHkR=range
mNnWwAyEzrVKpavGdCSFIBLusDfHkP=open
mNnWwAyEzrVKpavGdCSFIBLusDfHko=Exception
mNnWwAyEzrVKpavGdCSFIBLusDfHkg=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
mNnWwAyEzrVKpavGdCSFIBLusDfHlM=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewWeek','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
mNnWwAyEzrVKpavGdCSFIBLusDfHlt=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
mNnWwAyEzrVKpavGdCSFIBLusDfHlU=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
mNnWwAyEzrVKpavGdCSFIBLusDfHlJ=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
mNnWwAyEzrVKpavGdCSFIBLusDfHlq=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'키즈/애니','mode':'PROGRAM','stype':'PCC,PCAN'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'뮤직','mode':'PROGRAM','stype':'PCG'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'}]
mNnWwAyEzrVKpavGdCSFIBLusDfHlk=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG190,MG230,MG270,MG290'},{'title':'로맨스/멜로','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'액션/SF','mode':'MOVIE_SUB','stype':'MG120,MG170,MG180,MG220,MG260,MG200,MG210'},{'title':'공포/스릴러','mode':'MOVIE_SUB','stype':'MG140,MG150,MG160'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'다큐','mode':'MOVIE_SUB','stype':'MG250,MG330'}]
mNnWwAyEzrVKpavGdCSFIBLusDfHlh=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
mNnWwAyEzrVKpavGdCSFIBLusDfHlY =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
mNnWwAyEzrVKpavGdCSFIBLusDfHli=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
from tvingCore import*
class mNnWwAyEzrVKpavGdCSFIBLusDfHlx(mNnWwAyEzrVKpavGdCSFIBLusDfHkt):
 def __init__(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ,mNnWwAyEzrVKpavGdCSFIBLusDfHlj,mNnWwAyEzrVKpavGdCSFIBLusDfHlR,mNnWwAyEzrVKpavGdCSFIBLusDfHlP):
  mNnWwAyEzrVKpavGdCSFIBLusDfHlQ._addon_url =mNnWwAyEzrVKpavGdCSFIBLusDfHlj
  mNnWwAyEzrVKpavGdCSFIBLusDfHlQ._addon_handle=mNnWwAyEzrVKpavGdCSFIBLusDfHlR
  mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.main_params =mNnWwAyEzrVKpavGdCSFIBLusDfHlP
  mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.TvingObj =rqEOkyTmjKVciBDNIQMRxuvhldtJUY() 
 def addon_noti(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ,sting):
  try:
   mNnWwAyEzrVKpavGdCSFIBLusDfHlg=xbmcgui.Dialog()
   mNnWwAyEzrVKpavGdCSFIBLusDfHlg.notification(__addonname__,sting)
  except:
   mNnWwAyEzrVKpavGdCSFIBLusDfHkU
 def addon_log(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ,string):
  try:
   mNnWwAyEzrVKpavGdCSFIBLusDfHlb=string.encode('utf-8','ignore')
  except:
   mNnWwAyEzrVKpavGdCSFIBLusDfHlb='addonException: addon_log'
  mNnWwAyEzrVKpavGdCSFIBLusDfHlO=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,mNnWwAyEzrVKpavGdCSFIBLusDfHlb),level=mNnWwAyEzrVKpavGdCSFIBLusDfHlO)
 def get_keyboard_input(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ,mNnWwAyEzrVKpavGdCSFIBLusDfHxQ):
  mNnWwAyEzrVKpavGdCSFIBLusDfHlX=mNnWwAyEzrVKpavGdCSFIBLusDfHkU
  kb=xbmc.Keyboard()
  kb.setHeading(mNnWwAyEzrVKpavGdCSFIBLusDfHxQ)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   mNnWwAyEzrVKpavGdCSFIBLusDfHlX=kb.getText()
  return mNnWwAyEzrVKpavGdCSFIBLusDfHlX
 def get_settings_login_info(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ):
  mNnWwAyEzrVKpavGdCSFIBLusDfHle =__addon__.getSetting('id')
  mNnWwAyEzrVKpavGdCSFIBLusDfHlT =__addon__.getSetting('pw')
  mNnWwAyEzrVKpavGdCSFIBLusDfHlc =__addon__.getSetting('login_type')
  mNnWwAyEzrVKpavGdCSFIBLusDfHxl=mNnWwAyEzrVKpavGdCSFIBLusDfHkJ(__addon__.getSetting('selected_profile'))
  return(mNnWwAyEzrVKpavGdCSFIBLusDfHle,mNnWwAyEzrVKpavGdCSFIBLusDfHlT,mNnWwAyEzrVKpavGdCSFIBLusDfHlc,mNnWwAyEzrVKpavGdCSFIBLusDfHxl)
 def get_settings_totalsearch(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ):
  mNnWwAyEzrVKpavGdCSFIBLusDfHxM =mNnWwAyEzrVKpavGdCSFIBLusDfHkq if __addon__.getSetting('local_search')=='true' else mNnWwAyEzrVKpavGdCSFIBLusDfHkh
  mNnWwAyEzrVKpavGdCSFIBLusDfHxt=mNnWwAyEzrVKpavGdCSFIBLusDfHkq if __addon__.getSetting('local_history')=='true' else mNnWwAyEzrVKpavGdCSFIBLusDfHkh
  mNnWwAyEzrVKpavGdCSFIBLusDfHxU =mNnWwAyEzrVKpavGdCSFIBLusDfHkq if __addon__.getSetting('total_search')=='true' else mNnWwAyEzrVKpavGdCSFIBLusDfHkh
  mNnWwAyEzrVKpavGdCSFIBLusDfHxJ=mNnWwAyEzrVKpavGdCSFIBLusDfHkq if __addon__.getSetting('total_history')=='true' else mNnWwAyEzrVKpavGdCSFIBLusDfHkh
  mNnWwAyEzrVKpavGdCSFIBLusDfHxq=mNnWwAyEzrVKpavGdCSFIBLusDfHkq if __addon__.getSetting('menu_bookmark')=='true' else mNnWwAyEzrVKpavGdCSFIBLusDfHkh
  return(mNnWwAyEzrVKpavGdCSFIBLusDfHxM,mNnWwAyEzrVKpavGdCSFIBLusDfHxt,mNnWwAyEzrVKpavGdCSFIBLusDfHxU,mNnWwAyEzrVKpavGdCSFIBLusDfHxJ,mNnWwAyEzrVKpavGdCSFIBLusDfHxq)
 def get_settings_makebookmark(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ):
  return mNnWwAyEzrVKpavGdCSFIBLusDfHkq if __addon__.getSetting('make_bookmark')=='true' else mNnWwAyEzrVKpavGdCSFIBLusDfHkh
 def get_settings_direct_replay(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ):
  mNnWwAyEzrVKpavGdCSFIBLusDfHxk=mNnWwAyEzrVKpavGdCSFIBLusDfHkJ(__addon__.getSetting('direct_replay'))
  if mNnWwAyEzrVKpavGdCSFIBLusDfHxk==0:
   return mNnWwAyEzrVKpavGdCSFIBLusDfHkh
  else:
   return mNnWwAyEzrVKpavGdCSFIBLusDfHkq
 def set_winCredential(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ,credential):
  mNnWwAyEzrVKpavGdCSFIBLusDfHxh=xbmcgui.Window(10000)
  mNnWwAyEzrVKpavGdCSFIBLusDfHxh.setProperty('TVING_M_TOKEN',credential.get('tving_token'))
  mNnWwAyEzrVKpavGdCSFIBLusDfHxh.setProperty('TVING_M_USERINFO',credential.get('poc_userinfo'))
  mNnWwAyEzrVKpavGdCSFIBLusDfHxh.setProperty('TVING_M_UUID',credential.get('tving_uuid'))
  mNnWwAyEzrVKpavGdCSFIBLusDfHxh.setProperty('TVING_M_LOGINTIME',mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.TvingObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
  mNnWwAyEzrVKpavGdCSFIBLusDfHxh.setProperty('TVING_M_MAINTOKEN',credential.get('tving_maintoken'))
  mNnWwAyEzrVKpavGdCSFIBLusDfHxh.setProperty('TVING_M_COOKIEKEY',credential.get('tving_cookiekey'))
  mNnWwAyEzrVKpavGdCSFIBLusDfHxh.setProperty('TVING_M_LOCKKEY',credential.get('tving_lockkey'))
 def get_winCredential(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ):
  mNnWwAyEzrVKpavGdCSFIBLusDfHxh=xbmcgui.Window(10000)
  mNnWwAyEzrVKpavGdCSFIBLusDfHxY={'tving_token':mNnWwAyEzrVKpavGdCSFIBLusDfHxh.getProperty('TVING_M_TOKEN'),'poc_userinfo':mNnWwAyEzrVKpavGdCSFIBLusDfHxh.getProperty('TVING_M_USERINFO'),'tving_uuid':mNnWwAyEzrVKpavGdCSFIBLusDfHxh.getProperty('TVING_M_UUID'),'tving_maintoken':mNnWwAyEzrVKpavGdCSFIBLusDfHxh.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':mNnWwAyEzrVKpavGdCSFIBLusDfHxh.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':mNnWwAyEzrVKpavGdCSFIBLusDfHxh.getProperty('TVING_M_LOCKKEY')}
  return mNnWwAyEzrVKpavGdCSFIBLusDfHxY
 def set_winEpisodeOrderby(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ,mNnWwAyEzrVKpavGdCSFIBLusDfHtq):
  mNnWwAyEzrVKpavGdCSFIBLusDfHxh=xbmcgui.Window(10000)
  mNnWwAyEzrVKpavGdCSFIBLusDfHxh.setProperty('TVING_M_ORDERBY',mNnWwAyEzrVKpavGdCSFIBLusDfHtq)
 def get_winEpisodeOrderby(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ):
  mNnWwAyEzrVKpavGdCSFIBLusDfHxh=xbmcgui.Window(10000)
  return mNnWwAyEzrVKpavGdCSFIBLusDfHxh.getProperty('TVING_M_ORDERBY')
 def add_dir(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ,label,sublabel='',img='',infoLabels=mNnWwAyEzrVKpavGdCSFIBLusDfHkU,isFolder=mNnWwAyEzrVKpavGdCSFIBLusDfHkq,params='',isLink=mNnWwAyEzrVKpavGdCSFIBLusDfHkh,ContextMenu=mNnWwAyEzrVKpavGdCSFIBLusDfHkU):
  mNnWwAyEzrVKpavGdCSFIBLusDfHxi='%s?%s'%(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ._addon_url,urllib.parse.urlencode(params))
  if sublabel:mNnWwAyEzrVKpavGdCSFIBLusDfHxQ='%s < %s >'%(label,sublabel)
  else: mNnWwAyEzrVKpavGdCSFIBLusDfHxQ=label
  if not img:img='DefaultFolder.png'
  mNnWwAyEzrVKpavGdCSFIBLusDfHxj=xbmcgui.ListItem(mNnWwAyEzrVKpavGdCSFIBLusDfHxQ)
  if mNnWwAyEzrVKpavGdCSFIBLusDfHkY(img)==mNnWwAyEzrVKpavGdCSFIBLusDfHki:
   mNnWwAyEzrVKpavGdCSFIBLusDfHxj.setArt(img)
  else:
   mNnWwAyEzrVKpavGdCSFIBLusDfHxj.setArt({'thumb':img,'poster':img})
  if infoLabels:mNnWwAyEzrVKpavGdCSFIBLusDfHxj.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   mNnWwAyEzrVKpavGdCSFIBLusDfHxj.setProperty('IsPlayable','true')
  if ContextMenu:mNnWwAyEzrVKpavGdCSFIBLusDfHxj.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ._addon_handle,mNnWwAyEzrVKpavGdCSFIBLusDfHxi,mNnWwAyEzrVKpavGdCSFIBLusDfHxj,isFolder)
 def get_selQuality(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ,etype):
  try:
   mNnWwAyEzrVKpavGdCSFIBLusDfHxR='selected_quality'
   mNnWwAyEzrVKpavGdCSFIBLusDfHxP=[1080,720,480,360]
   mNnWwAyEzrVKpavGdCSFIBLusDfHxo=mNnWwAyEzrVKpavGdCSFIBLusDfHkJ(__addon__.getSetting(mNnWwAyEzrVKpavGdCSFIBLusDfHxR))
   return mNnWwAyEzrVKpavGdCSFIBLusDfHxP[mNnWwAyEzrVKpavGdCSFIBLusDfHxo]
  except:
   mNnWwAyEzrVKpavGdCSFIBLusDfHkU
  return 720 
 def dp_Main_List(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ):
  (mNnWwAyEzrVKpavGdCSFIBLusDfHxM,mNnWwAyEzrVKpavGdCSFIBLusDfHxt,mNnWwAyEzrVKpavGdCSFIBLusDfHxU,mNnWwAyEzrVKpavGdCSFIBLusDfHxJ,mNnWwAyEzrVKpavGdCSFIBLusDfHxq)=mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.get_settings_totalsearch()
  for mNnWwAyEzrVKpavGdCSFIBLusDfHxg in mNnWwAyEzrVKpavGdCSFIBLusDfHlM:
   mNnWwAyEzrVKpavGdCSFIBLusDfHxQ=mNnWwAyEzrVKpavGdCSFIBLusDfHxg.get('title')
   mNnWwAyEzrVKpavGdCSFIBLusDfHxb=''
   if mNnWwAyEzrVKpavGdCSFIBLusDfHxg.get('mode')=='SEARCH_GROUP' and mNnWwAyEzrVKpavGdCSFIBLusDfHxM ==mNnWwAyEzrVKpavGdCSFIBLusDfHkh:continue
   elif mNnWwAyEzrVKpavGdCSFIBLusDfHxg.get('mode')=='SEARCH_HISTORY' and mNnWwAyEzrVKpavGdCSFIBLusDfHxt==mNnWwAyEzrVKpavGdCSFIBLusDfHkh:continue
   elif mNnWwAyEzrVKpavGdCSFIBLusDfHxg.get('mode')=='TOTAL_SEARCH' and mNnWwAyEzrVKpavGdCSFIBLusDfHxU ==mNnWwAyEzrVKpavGdCSFIBLusDfHkh:continue
   elif mNnWwAyEzrVKpavGdCSFIBLusDfHxg.get('mode')=='TOTAL_HISTORY' and mNnWwAyEzrVKpavGdCSFIBLusDfHxJ==mNnWwAyEzrVKpavGdCSFIBLusDfHkh:continue
   elif mNnWwAyEzrVKpavGdCSFIBLusDfHxg.get('mode')=='MENU_BOOKMARK' and mNnWwAyEzrVKpavGdCSFIBLusDfHxq==mNnWwAyEzrVKpavGdCSFIBLusDfHkh:continue
   mNnWwAyEzrVKpavGdCSFIBLusDfHxO={'mode':mNnWwAyEzrVKpavGdCSFIBLusDfHxg.get('mode'),'stype':mNnWwAyEzrVKpavGdCSFIBLusDfHxg.get('stype'),'orderby':mNnWwAyEzrVKpavGdCSFIBLusDfHxg.get('orderby'),'ordernm':mNnWwAyEzrVKpavGdCSFIBLusDfHxg.get('ordernm'),'page':'1'}
   if mNnWwAyEzrVKpavGdCSFIBLusDfHxg.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    mNnWwAyEzrVKpavGdCSFIBLusDfHxX=mNnWwAyEzrVKpavGdCSFIBLusDfHkh
    mNnWwAyEzrVKpavGdCSFIBLusDfHxe =mNnWwAyEzrVKpavGdCSFIBLusDfHkq
   else:
    mNnWwAyEzrVKpavGdCSFIBLusDfHxX=mNnWwAyEzrVKpavGdCSFIBLusDfHkq
    mNnWwAyEzrVKpavGdCSFIBLusDfHxe =mNnWwAyEzrVKpavGdCSFIBLusDfHkh
   if 'icon' in mNnWwAyEzrVKpavGdCSFIBLusDfHxg:mNnWwAyEzrVKpavGdCSFIBLusDfHxb=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',mNnWwAyEzrVKpavGdCSFIBLusDfHxg.get('icon')) 
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.add_dir(mNnWwAyEzrVKpavGdCSFIBLusDfHxQ,sublabel='',img=mNnWwAyEzrVKpavGdCSFIBLusDfHxb,infoLabels=mNnWwAyEzrVKpavGdCSFIBLusDfHkU,isFolder=mNnWwAyEzrVKpavGdCSFIBLusDfHxX,params=mNnWwAyEzrVKpavGdCSFIBLusDfHxO,isLink=mNnWwAyEzrVKpavGdCSFIBLusDfHxe)
  xbmcplugin.endOfDirectory(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ._addon_handle)
 def login_main(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ):
  (mNnWwAyEzrVKpavGdCSFIBLusDfHxc,mNnWwAyEzrVKpavGdCSFIBLusDfHMl,mNnWwAyEzrVKpavGdCSFIBLusDfHMx,mNnWwAyEzrVKpavGdCSFIBLusDfHMt)=mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.get_settings_login_info()
  if not(mNnWwAyEzrVKpavGdCSFIBLusDfHxc and mNnWwAyEzrVKpavGdCSFIBLusDfHMl):
   mNnWwAyEzrVKpavGdCSFIBLusDfHlg=xbmcgui.Dialog()
   mNnWwAyEzrVKpavGdCSFIBLusDfHMU=mNnWwAyEzrVKpavGdCSFIBLusDfHlg.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if mNnWwAyEzrVKpavGdCSFIBLusDfHMU==mNnWwAyEzrVKpavGdCSFIBLusDfHkq:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.get_winEpisodeOrderby()=='':
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.set_winEpisodeOrderby('desc')
  if mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.cookiefile_check():return
  mNnWwAyEzrVKpavGdCSFIBLusDfHMJ =mNnWwAyEzrVKpavGdCSFIBLusDfHkJ(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  mNnWwAyEzrVKpavGdCSFIBLusDfHMq=xbmcgui.Window(10000).getProperty('TVING_M_LOGINTIME')
  if mNnWwAyEzrVKpavGdCSFIBLusDfHMq==mNnWwAyEzrVKpavGdCSFIBLusDfHkU or mNnWwAyEzrVKpavGdCSFIBLusDfHMq=='':
   mNnWwAyEzrVKpavGdCSFIBLusDfHMq=mNnWwAyEzrVKpavGdCSFIBLusDfHkJ('19000101')
  else:
   mNnWwAyEzrVKpavGdCSFIBLusDfHMq=mNnWwAyEzrVKpavGdCSFIBLusDfHkJ(re.sub('-','',mNnWwAyEzrVKpavGdCSFIBLusDfHMq))
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   mNnWwAyEzrVKpavGdCSFIBLusDfHMk=0
   while mNnWwAyEzrVKpavGdCSFIBLusDfHkq:
    mNnWwAyEzrVKpavGdCSFIBLusDfHMk+=1
    time.sleep(0.05)
    if mNnWwAyEzrVKpavGdCSFIBLusDfHMq>=mNnWwAyEzrVKpavGdCSFIBLusDfHMJ:return
    if mNnWwAyEzrVKpavGdCSFIBLusDfHMk>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  if mNnWwAyEzrVKpavGdCSFIBLusDfHMq>=mNnWwAyEzrVKpavGdCSFIBLusDfHMJ:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   return
  if not mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.TvingObj.GetCredential(mNnWwAyEzrVKpavGdCSFIBLusDfHxc,mNnWwAyEzrVKpavGdCSFIBLusDfHMl,mNnWwAyEzrVKpavGdCSFIBLusDfHMx,mNnWwAyEzrVKpavGdCSFIBLusDfHMt):
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   sys.exit()
  mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.set_winCredential(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.TvingObj.LoadCredential())
  mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
 def dp_Title_Group(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ,mNnWwAyEzrVKpavGdCSFIBLusDfHMQ):
  mNnWwAyEzrVKpavGdCSFIBLusDfHMh=mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('stype')
  if mNnWwAyEzrVKpavGdCSFIBLusDfHMh=='live':
   mNnWwAyEzrVKpavGdCSFIBLusDfHMY=mNnWwAyEzrVKpavGdCSFIBLusDfHlt
  elif mNnWwAyEzrVKpavGdCSFIBLusDfHMh=='vod':
   mNnWwAyEzrVKpavGdCSFIBLusDfHMY=mNnWwAyEzrVKpavGdCSFIBLusDfHlq
  else:
   mNnWwAyEzrVKpavGdCSFIBLusDfHMY=mNnWwAyEzrVKpavGdCSFIBLusDfHlk
  for mNnWwAyEzrVKpavGdCSFIBLusDfHMi in mNnWwAyEzrVKpavGdCSFIBLusDfHMY:
   mNnWwAyEzrVKpavGdCSFIBLusDfHxQ=mNnWwAyEzrVKpavGdCSFIBLusDfHMi.get('title')
   if mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('ordernm')!='-':
    mNnWwAyEzrVKpavGdCSFIBLusDfHxQ+='  ('+mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('ordernm')+')'
   mNnWwAyEzrVKpavGdCSFIBLusDfHxO={'mode':mNnWwAyEzrVKpavGdCSFIBLusDfHMi.get('mode'),'stype':mNnWwAyEzrVKpavGdCSFIBLusDfHMi.get('stype'),'orderby':mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('orderby'),'ordernm':mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('ordernm'),'page':'1'}
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.add_dir(mNnWwAyEzrVKpavGdCSFIBLusDfHxQ,sublabel='',img='',infoLabels=mNnWwAyEzrVKpavGdCSFIBLusDfHkU,isFolder=mNnWwAyEzrVKpavGdCSFIBLusDfHkq,params=mNnWwAyEzrVKpavGdCSFIBLusDfHxO)
  if mNnWwAyEzrVKpavGdCSFIBLusDfHkQ(mNnWwAyEzrVKpavGdCSFIBLusDfHMY)>0:xbmcplugin.endOfDirectory(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ._addon_handle)
 def dp_SubTitle_Group(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ,mNnWwAyEzrVKpavGdCSFIBLusDfHMQ): 
  for mNnWwAyEzrVKpavGdCSFIBLusDfHMi in mNnWwAyEzrVKpavGdCSFIBLusDfHlh:
   mNnWwAyEzrVKpavGdCSFIBLusDfHxQ=mNnWwAyEzrVKpavGdCSFIBLusDfHMi.get('title')
   if mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('ordernm')!='-':
    mNnWwAyEzrVKpavGdCSFIBLusDfHxQ+='  ('+mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('ordernm')+')'
   mNnWwAyEzrVKpavGdCSFIBLusDfHxO={'mode':mNnWwAyEzrVKpavGdCSFIBLusDfHMi.get('mode'),'genreCode':mNnWwAyEzrVKpavGdCSFIBLusDfHMi.get('genreCode'),'stype':mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('stype'),'orderby':mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('orderby'),'page':'1'}
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.add_dir(mNnWwAyEzrVKpavGdCSFIBLusDfHxQ,sublabel='',img='',infoLabels=mNnWwAyEzrVKpavGdCSFIBLusDfHkU,isFolder=mNnWwAyEzrVKpavGdCSFIBLusDfHkq,params=mNnWwAyEzrVKpavGdCSFIBLusDfHxO)
  if mNnWwAyEzrVKpavGdCSFIBLusDfHkQ(mNnWwAyEzrVKpavGdCSFIBLusDfHlh)>0:xbmcplugin.endOfDirectory(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ._addon_handle)
 def dp_LiveChannel_List(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ,mNnWwAyEzrVKpavGdCSFIBLusDfHMQ):
  mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.TvingObj.SaveCredential(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.get_winCredential())
  mNnWwAyEzrVKpavGdCSFIBLusDfHMh =mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('stype')
  mNnWwAyEzrVKpavGdCSFIBLusDfHMj =mNnWwAyEzrVKpavGdCSFIBLusDfHkJ(mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('page'))
  mNnWwAyEzrVKpavGdCSFIBLusDfHMR,mNnWwAyEzrVKpavGdCSFIBLusDfHMP=mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.TvingObj.GetLiveChannelList(mNnWwAyEzrVKpavGdCSFIBLusDfHMh,mNnWwAyEzrVKpavGdCSFIBLusDfHMj)
  for mNnWwAyEzrVKpavGdCSFIBLusDfHMo in mNnWwAyEzrVKpavGdCSFIBLusDfHMR:
   mNnWwAyEzrVKpavGdCSFIBLusDfHxQ =mNnWwAyEzrVKpavGdCSFIBLusDfHMo.get('title')
   mNnWwAyEzrVKpavGdCSFIBLusDfHxT =mNnWwAyEzrVKpavGdCSFIBLusDfHMo.get('channel')
   mNnWwAyEzrVKpavGdCSFIBLusDfHMg =mNnWwAyEzrVKpavGdCSFIBLusDfHMo.get('thumbnail')
   mNnWwAyEzrVKpavGdCSFIBLusDfHMb =mNnWwAyEzrVKpavGdCSFIBLusDfHMo.get('synopsis')
   mNnWwAyEzrVKpavGdCSFIBLusDfHMO =mNnWwAyEzrVKpavGdCSFIBLusDfHMo.get('channelepg')
   mNnWwAyEzrVKpavGdCSFIBLusDfHMX =mNnWwAyEzrVKpavGdCSFIBLusDfHMo.get('cast')
   mNnWwAyEzrVKpavGdCSFIBLusDfHMe =mNnWwAyEzrVKpavGdCSFIBLusDfHMo.get('director')
   mNnWwAyEzrVKpavGdCSFIBLusDfHMT =mNnWwAyEzrVKpavGdCSFIBLusDfHMo.get('info_genre')
   mNnWwAyEzrVKpavGdCSFIBLusDfHMc =mNnWwAyEzrVKpavGdCSFIBLusDfHMo.get('year')
   mNnWwAyEzrVKpavGdCSFIBLusDfHtl =mNnWwAyEzrVKpavGdCSFIBLusDfHMo.get('mpaa')
   mNnWwAyEzrVKpavGdCSFIBLusDfHtx =mNnWwAyEzrVKpavGdCSFIBLusDfHMo.get('premiered')
   mNnWwAyEzrVKpavGdCSFIBLusDfHtM={'mediatype':'episode','title':mNnWwAyEzrVKpavGdCSFIBLusDfHxQ,'studio':mNnWwAyEzrVKpavGdCSFIBLusDfHxT,'cast':mNnWwAyEzrVKpavGdCSFIBLusDfHMX,'director':mNnWwAyEzrVKpavGdCSFIBLusDfHMe,'genre':mNnWwAyEzrVKpavGdCSFIBLusDfHMT,'plot':'%s\n%s\n%s\n\n%s'%(mNnWwAyEzrVKpavGdCSFIBLusDfHxT,mNnWwAyEzrVKpavGdCSFIBLusDfHxQ,mNnWwAyEzrVKpavGdCSFIBLusDfHMO,mNnWwAyEzrVKpavGdCSFIBLusDfHMb),'year':mNnWwAyEzrVKpavGdCSFIBLusDfHMc,'mpaa':mNnWwAyEzrVKpavGdCSFIBLusDfHtl,'premiered':mNnWwAyEzrVKpavGdCSFIBLusDfHtx}
   mNnWwAyEzrVKpavGdCSFIBLusDfHxO={'mode':'LIVE','mediacode':mNnWwAyEzrVKpavGdCSFIBLusDfHMo.get('mediacode'),'stype':mNnWwAyEzrVKpavGdCSFIBLusDfHMh}
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.add_dir(mNnWwAyEzrVKpavGdCSFIBLusDfHxT,sublabel=mNnWwAyEzrVKpavGdCSFIBLusDfHxQ,img=mNnWwAyEzrVKpavGdCSFIBLusDfHMg,infoLabels=mNnWwAyEzrVKpavGdCSFIBLusDfHtM,isFolder=mNnWwAyEzrVKpavGdCSFIBLusDfHkh,params=mNnWwAyEzrVKpavGdCSFIBLusDfHxO)
  if mNnWwAyEzrVKpavGdCSFIBLusDfHMP:
   mNnWwAyEzrVKpavGdCSFIBLusDfHxO['mode']='CHANNEL' 
   mNnWwAyEzrVKpavGdCSFIBLusDfHxO['stype']=mNnWwAyEzrVKpavGdCSFIBLusDfHMh 
   mNnWwAyEzrVKpavGdCSFIBLusDfHxO['page']=mNnWwAyEzrVKpavGdCSFIBLusDfHkj(mNnWwAyEzrVKpavGdCSFIBLusDfHMj+1)
   mNnWwAyEzrVKpavGdCSFIBLusDfHxQ='[B]%s >>[/B]'%'다음 페이지'
   mNnWwAyEzrVKpavGdCSFIBLusDfHtU=mNnWwAyEzrVKpavGdCSFIBLusDfHkj(mNnWwAyEzrVKpavGdCSFIBLusDfHMj+1)
   mNnWwAyEzrVKpavGdCSFIBLusDfHxb=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.add_dir(mNnWwAyEzrVKpavGdCSFIBLusDfHxQ,sublabel=mNnWwAyEzrVKpavGdCSFIBLusDfHtU,img=mNnWwAyEzrVKpavGdCSFIBLusDfHxb,infoLabels=mNnWwAyEzrVKpavGdCSFIBLusDfHkU,isFolder=mNnWwAyEzrVKpavGdCSFIBLusDfHkq,params=mNnWwAyEzrVKpavGdCSFIBLusDfHxO)
  if mNnWwAyEzrVKpavGdCSFIBLusDfHkQ(mNnWwAyEzrVKpavGdCSFIBLusDfHMR)>0:xbmcplugin.endOfDirectory(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ._addon_handle,cacheToDisc=mNnWwAyEzrVKpavGdCSFIBLusDfHkh)
 def dp_Program_List(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ,mNnWwAyEzrVKpavGdCSFIBLusDfHMQ):
  mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.TvingObj.SaveCredential(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.get_winCredential())
  mNnWwAyEzrVKpavGdCSFIBLusDfHtJ =mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('stype')
  mNnWwAyEzrVKpavGdCSFIBLusDfHtq =mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('orderby')
  mNnWwAyEzrVKpavGdCSFIBLusDfHMj =mNnWwAyEzrVKpavGdCSFIBLusDfHkJ(mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('page'))
  mNnWwAyEzrVKpavGdCSFIBLusDfHtk=mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('genreCode')
  if mNnWwAyEzrVKpavGdCSFIBLusDfHtk==mNnWwAyEzrVKpavGdCSFIBLusDfHkU:mNnWwAyEzrVKpavGdCSFIBLusDfHtk='all'
  mNnWwAyEzrVKpavGdCSFIBLusDfHth,mNnWwAyEzrVKpavGdCSFIBLusDfHMP=mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.TvingObj.GetProgramList(mNnWwAyEzrVKpavGdCSFIBLusDfHtJ,mNnWwAyEzrVKpavGdCSFIBLusDfHtq,mNnWwAyEzrVKpavGdCSFIBLusDfHMj,mNnWwAyEzrVKpavGdCSFIBLusDfHtk)
  for mNnWwAyEzrVKpavGdCSFIBLusDfHtY in mNnWwAyEzrVKpavGdCSFIBLusDfHth:
   mNnWwAyEzrVKpavGdCSFIBLusDfHxQ =mNnWwAyEzrVKpavGdCSFIBLusDfHtY.get('title')
   mNnWwAyEzrVKpavGdCSFIBLusDfHMg =mNnWwAyEzrVKpavGdCSFIBLusDfHtY.get('thumbnail')
   mNnWwAyEzrVKpavGdCSFIBLusDfHMb =mNnWwAyEzrVKpavGdCSFIBLusDfHtY.get('synopsis')
   mNnWwAyEzrVKpavGdCSFIBLusDfHti =mNnWwAyEzrVKpavGdCSFIBLusDfHtY.get('channel')
   mNnWwAyEzrVKpavGdCSFIBLusDfHMX =mNnWwAyEzrVKpavGdCSFIBLusDfHtY.get('cast')
   mNnWwAyEzrVKpavGdCSFIBLusDfHMe =mNnWwAyEzrVKpavGdCSFIBLusDfHtY.get('director')
   mNnWwAyEzrVKpavGdCSFIBLusDfHMT=mNnWwAyEzrVKpavGdCSFIBLusDfHtY.get('info_genre')
   mNnWwAyEzrVKpavGdCSFIBLusDfHMc =mNnWwAyEzrVKpavGdCSFIBLusDfHtY.get('year')
   mNnWwAyEzrVKpavGdCSFIBLusDfHtx =mNnWwAyEzrVKpavGdCSFIBLusDfHtY.get('premiered')
   mNnWwAyEzrVKpavGdCSFIBLusDfHtl =mNnWwAyEzrVKpavGdCSFIBLusDfHtY.get('mpaa')
   mNnWwAyEzrVKpavGdCSFIBLusDfHtM={'mediatype':'tvshow','title':mNnWwAyEzrVKpavGdCSFIBLusDfHxQ,'studio':mNnWwAyEzrVKpavGdCSFIBLusDfHti,'cast':mNnWwAyEzrVKpavGdCSFIBLusDfHMX,'director':mNnWwAyEzrVKpavGdCSFIBLusDfHMe,'genre':mNnWwAyEzrVKpavGdCSFIBLusDfHMT,'year':mNnWwAyEzrVKpavGdCSFIBLusDfHMc,'premiered':mNnWwAyEzrVKpavGdCSFIBLusDfHtx,'mpaa':mNnWwAyEzrVKpavGdCSFIBLusDfHtl,'plot':mNnWwAyEzrVKpavGdCSFIBLusDfHMb}
   mNnWwAyEzrVKpavGdCSFIBLusDfHxO={'mode':'EPISODE','programcode':mNnWwAyEzrVKpavGdCSFIBLusDfHtY.get('program'),'page':'1'}
   if mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.get_settings_makebookmark():
    mNnWwAyEzrVKpavGdCSFIBLusDfHtQ={'videoid':mNnWwAyEzrVKpavGdCSFIBLusDfHtY.get('program'),'vidtype':'tvshow','vtitle':mNnWwAyEzrVKpavGdCSFIBLusDfHxQ,'vsubtitle':mNnWwAyEzrVKpavGdCSFIBLusDfHti,}
    mNnWwAyEzrVKpavGdCSFIBLusDfHtj=json.dumps(mNnWwAyEzrVKpavGdCSFIBLusDfHtQ)
    mNnWwAyEzrVKpavGdCSFIBLusDfHtj=urllib.parse.quote(mNnWwAyEzrVKpavGdCSFIBLusDfHtj)
    mNnWwAyEzrVKpavGdCSFIBLusDfHtR='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(mNnWwAyEzrVKpavGdCSFIBLusDfHtj)
    mNnWwAyEzrVKpavGdCSFIBLusDfHtP=[('(통합) 찜 영상에 추가',mNnWwAyEzrVKpavGdCSFIBLusDfHtR)]
   else:
    mNnWwAyEzrVKpavGdCSFIBLusDfHtP=mNnWwAyEzrVKpavGdCSFIBLusDfHkU
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.add_dir(mNnWwAyEzrVKpavGdCSFIBLusDfHxQ,sublabel=mNnWwAyEzrVKpavGdCSFIBLusDfHti,img=mNnWwAyEzrVKpavGdCSFIBLusDfHMg,infoLabels=mNnWwAyEzrVKpavGdCSFIBLusDfHtM,isFolder=mNnWwAyEzrVKpavGdCSFIBLusDfHkq,params=mNnWwAyEzrVKpavGdCSFIBLusDfHxO,ContextMenu=mNnWwAyEzrVKpavGdCSFIBLusDfHtP)
  if mNnWwAyEzrVKpavGdCSFIBLusDfHMP:
   mNnWwAyEzrVKpavGdCSFIBLusDfHxO['mode'] ='PROGRAM' 
   mNnWwAyEzrVKpavGdCSFIBLusDfHxO['stype'] =mNnWwAyEzrVKpavGdCSFIBLusDfHtJ
   mNnWwAyEzrVKpavGdCSFIBLusDfHxO['orderby'] =mNnWwAyEzrVKpavGdCSFIBLusDfHtq
   mNnWwAyEzrVKpavGdCSFIBLusDfHxO['page'] =mNnWwAyEzrVKpavGdCSFIBLusDfHkj(mNnWwAyEzrVKpavGdCSFIBLusDfHMj+1)
   mNnWwAyEzrVKpavGdCSFIBLusDfHxO['genreCode']=mNnWwAyEzrVKpavGdCSFIBLusDfHtk 
   mNnWwAyEzrVKpavGdCSFIBLusDfHxQ='[B]%s >>[/B]'%'다음 페이지'
   mNnWwAyEzrVKpavGdCSFIBLusDfHtU=mNnWwAyEzrVKpavGdCSFIBLusDfHkj(mNnWwAyEzrVKpavGdCSFIBLusDfHMj+1)
   mNnWwAyEzrVKpavGdCSFIBLusDfHxb=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.add_dir(mNnWwAyEzrVKpavGdCSFIBLusDfHxQ,sublabel=mNnWwAyEzrVKpavGdCSFIBLusDfHtU,img=mNnWwAyEzrVKpavGdCSFIBLusDfHxb,infoLabels=mNnWwAyEzrVKpavGdCSFIBLusDfHkU,isFolder=mNnWwAyEzrVKpavGdCSFIBLusDfHkq,params=mNnWwAyEzrVKpavGdCSFIBLusDfHxO)
  xbmcplugin.setContent(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ._addon_handle,cacheToDisc=mNnWwAyEzrVKpavGdCSFIBLusDfHkh)
 def dp_Episode_List(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ,mNnWwAyEzrVKpavGdCSFIBLusDfHMQ):
  mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.TvingObj.SaveCredential(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.get_winCredential())
  mNnWwAyEzrVKpavGdCSFIBLusDfHtg=mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('programcode')
  mNnWwAyEzrVKpavGdCSFIBLusDfHMj =mNnWwAyEzrVKpavGdCSFIBLusDfHkJ(mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('page'))
  mNnWwAyEzrVKpavGdCSFIBLusDfHtb,mNnWwAyEzrVKpavGdCSFIBLusDfHMP,mNnWwAyEzrVKpavGdCSFIBLusDfHtO=mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.TvingObj.GetEpisodeList(mNnWwAyEzrVKpavGdCSFIBLusDfHtg,mNnWwAyEzrVKpavGdCSFIBLusDfHMj,orderby=mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.get_winEpisodeOrderby())
  for mNnWwAyEzrVKpavGdCSFIBLusDfHtX in mNnWwAyEzrVKpavGdCSFIBLusDfHtb:
   mNnWwAyEzrVKpavGdCSFIBLusDfHxQ =mNnWwAyEzrVKpavGdCSFIBLusDfHtX.get('title')
   mNnWwAyEzrVKpavGdCSFIBLusDfHtU =mNnWwAyEzrVKpavGdCSFIBLusDfHtX.get('subtitle')
   mNnWwAyEzrVKpavGdCSFIBLusDfHMg =mNnWwAyEzrVKpavGdCSFIBLusDfHtX.get('thumbnail')
   mNnWwAyEzrVKpavGdCSFIBLusDfHMb =mNnWwAyEzrVKpavGdCSFIBLusDfHtX.get('synopsis')
   mNnWwAyEzrVKpavGdCSFIBLusDfHte=mNnWwAyEzrVKpavGdCSFIBLusDfHtX.get('info_title')
   mNnWwAyEzrVKpavGdCSFIBLusDfHtT =mNnWwAyEzrVKpavGdCSFIBLusDfHtX.get('aired')
   mNnWwAyEzrVKpavGdCSFIBLusDfHtc =mNnWwAyEzrVKpavGdCSFIBLusDfHtX.get('studio')
   mNnWwAyEzrVKpavGdCSFIBLusDfHUl =mNnWwAyEzrVKpavGdCSFIBLusDfHtX.get('frequency')
   mNnWwAyEzrVKpavGdCSFIBLusDfHtM={'mediatype':'episode','title':mNnWwAyEzrVKpavGdCSFIBLusDfHte,'aired':mNnWwAyEzrVKpavGdCSFIBLusDfHtT,'studio':mNnWwAyEzrVKpavGdCSFIBLusDfHtc,'episode':mNnWwAyEzrVKpavGdCSFIBLusDfHUl,'plot':mNnWwAyEzrVKpavGdCSFIBLusDfHMb}
   mNnWwAyEzrVKpavGdCSFIBLusDfHxO={'mode':'VOD','mediacode':mNnWwAyEzrVKpavGdCSFIBLusDfHtX.get('episode'),'stype':'vod','programcode':mNnWwAyEzrVKpavGdCSFIBLusDfHtg,'title':mNnWwAyEzrVKpavGdCSFIBLusDfHxQ,'thumbnail':mNnWwAyEzrVKpavGdCSFIBLusDfHMg}
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.add_dir(mNnWwAyEzrVKpavGdCSFIBLusDfHxQ,sublabel=mNnWwAyEzrVKpavGdCSFIBLusDfHtU,img=mNnWwAyEzrVKpavGdCSFIBLusDfHMg,infoLabels=mNnWwAyEzrVKpavGdCSFIBLusDfHtM,isFolder=mNnWwAyEzrVKpavGdCSFIBLusDfHkh,params=mNnWwAyEzrVKpavGdCSFIBLusDfHxO)
  if mNnWwAyEzrVKpavGdCSFIBLusDfHMj==1:
   mNnWwAyEzrVKpavGdCSFIBLusDfHtM={'plot':'정렬순서를 변경합니다.'}
   mNnWwAyEzrVKpavGdCSFIBLusDfHxO={}
   mNnWwAyEzrVKpavGdCSFIBLusDfHxO['mode'] ='ORDER_BY' 
   if mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.get_winEpisodeOrderby()=='desc':
    mNnWwAyEzrVKpavGdCSFIBLusDfHxQ='정렬순서변경 : 최신화부터 -> 1회부터'
    mNnWwAyEzrVKpavGdCSFIBLusDfHxO['orderby']='asc'
   else:
    mNnWwAyEzrVKpavGdCSFIBLusDfHxQ='정렬순서변경 : 1회부터 -> 최신화부터'
    mNnWwAyEzrVKpavGdCSFIBLusDfHxO['orderby']='desc'
   mNnWwAyEzrVKpavGdCSFIBLusDfHxb=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.add_dir(mNnWwAyEzrVKpavGdCSFIBLusDfHxQ,sublabel='',img=mNnWwAyEzrVKpavGdCSFIBLusDfHxb,infoLabels=mNnWwAyEzrVKpavGdCSFIBLusDfHtM,isFolder=mNnWwAyEzrVKpavGdCSFIBLusDfHkh,params=mNnWwAyEzrVKpavGdCSFIBLusDfHxO,isLink=mNnWwAyEzrVKpavGdCSFIBLusDfHkq)
  if mNnWwAyEzrVKpavGdCSFIBLusDfHMP:
   mNnWwAyEzrVKpavGdCSFIBLusDfHxO['mode'] ='EPISODE' 
   mNnWwAyEzrVKpavGdCSFIBLusDfHxO['programcode']=mNnWwAyEzrVKpavGdCSFIBLusDfHtg
   mNnWwAyEzrVKpavGdCSFIBLusDfHxO['page'] =mNnWwAyEzrVKpavGdCSFIBLusDfHkj(mNnWwAyEzrVKpavGdCSFIBLusDfHMj+1)
   mNnWwAyEzrVKpavGdCSFIBLusDfHxQ='[B]%s >>[/B]'%'다음 페이지'
   mNnWwAyEzrVKpavGdCSFIBLusDfHtU=mNnWwAyEzrVKpavGdCSFIBLusDfHkj(mNnWwAyEzrVKpavGdCSFIBLusDfHMj+1)
   mNnWwAyEzrVKpavGdCSFIBLusDfHxb=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.add_dir(mNnWwAyEzrVKpavGdCSFIBLusDfHxQ,sublabel=mNnWwAyEzrVKpavGdCSFIBLusDfHtU,img=mNnWwAyEzrVKpavGdCSFIBLusDfHxb,infoLabels=mNnWwAyEzrVKpavGdCSFIBLusDfHkU,isFolder=mNnWwAyEzrVKpavGdCSFIBLusDfHkq,params=mNnWwAyEzrVKpavGdCSFIBLusDfHxO)
  xbmcplugin.setContent(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ._addon_handle,'episodes')
  if mNnWwAyEzrVKpavGdCSFIBLusDfHkQ(mNnWwAyEzrVKpavGdCSFIBLusDfHtb)>0:xbmcplugin.endOfDirectory(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ._addon_handle,cacheToDisc=mNnWwAyEzrVKpavGdCSFIBLusDfHkq)
 def dp_setEpOrderby(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ,mNnWwAyEzrVKpavGdCSFIBLusDfHMQ):
  mNnWwAyEzrVKpavGdCSFIBLusDfHtq =mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('orderby')
  mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.set_winEpisodeOrderby(mNnWwAyEzrVKpavGdCSFIBLusDfHtq)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ,mNnWwAyEzrVKpavGdCSFIBLusDfHMQ):
  mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.TvingObj.SaveCredential(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.get_winCredential())
  mNnWwAyEzrVKpavGdCSFIBLusDfHtJ =mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('stype')
  mNnWwAyEzrVKpavGdCSFIBLusDfHtq =mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('orderby')
  mNnWwAyEzrVKpavGdCSFIBLusDfHMj=mNnWwAyEzrVKpavGdCSFIBLusDfHkJ(mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('page'))
  mNnWwAyEzrVKpavGdCSFIBLusDfHUx,mNnWwAyEzrVKpavGdCSFIBLusDfHMP=mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.TvingObj.GetMovieList(mNnWwAyEzrVKpavGdCSFIBLusDfHtJ,mNnWwAyEzrVKpavGdCSFIBLusDfHtq,mNnWwAyEzrVKpavGdCSFIBLusDfHMj)
  for mNnWwAyEzrVKpavGdCSFIBLusDfHUM in mNnWwAyEzrVKpavGdCSFIBLusDfHUx:
   mNnWwAyEzrVKpavGdCSFIBLusDfHxQ =mNnWwAyEzrVKpavGdCSFIBLusDfHUM.get('title')
   mNnWwAyEzrVKpavGdCSFIBLusDfHMg =mNnWwAyEzrVKpavGdCSFIBLusDfHUM.get('thumbnail')
   mNnWwAyEzrVKpavGdCSFIBLusDfHMb =mNnWwAyEzrVKpavGdCSFIBLusDfHUM.get('synopsis')
   mNnWwAyEzrVKpavGdCSFIBLusDfHte =mNnWwAyEzrVKpavGdCSFIBLusDfHUM.get('info_title')
   mNnWwAyEzrVKpavGdCSFIBLusDfHMc =mNnWwAyEzrVKpavGdCSFIBLusDfHUM.get('year')
   mNnWwAyEzrVKpavGdCSFIBLusDfHMX =mNnWwAyEzrVKpavGdCSFIBLusDfHUM.get('cast')
   mNnWwAyEzrVKpavGdCSFIBLusDfHMe =mNnWwAyEzrVKpavGdCSFIBLusDfHUM.get('director')
   mNnWwAyEzrVKpavGdCSFIBLusDfHMT =mNnWwAyEzrVKpavGdCSFIBLusDfHUM.get('info_genre')
   mNnWwAyEzrVKpavGdCSFIBLusDfHUt =mNnWwAyEzrVKpavGdCSFIBLusDfHUM.get('duration')
   mNnWwAyEzrVKpavGdCSFIBLusDfHtx =mNnWwAyEzrVKpavGdCSFIBLusDfHUM.get('premiered')
   mNnWwAyEzrVKpavGdCSFIBLusDfHtc =mNnWwAyEzrVKpavGdCSFIBLusDfHUM.get('studio')
   mNnWwAyEzrVKpavGdCSFIBLusDfHtl =mNnWwAyEzrVKpavGdCSFIBLusDfHUM.get('mpaa')
   mNnWwAyEzrVKpavGdCSFIBLusDfHtM={'mediatype':'movie','title':mNnWwAyEzrVKpavGdCSFIBLusDfHte,'year':mNnWwAyEzrVKpavGdCSFIBLusDfHMc,'cast':mNnWwAyEzrVKpavGdCSFIBLusDfHMX,'director':mNnWwAyEzrVKpavGdCSFIBLusDfHMe,'genre':mNnWwAyEzrVKpavGdCSFIBLusDfHMT,'duration':mNnWwAyEzrVKpavGdCSFIBLusDfHUt,'premiered':mNnWwAyEzrVKpavGdCSFIBLusDfHtx,'studio':mNnWwAyEzrVKpavGdCSFIBLusDfHtc,'mpaa':mNnWwAyEzrVKpavGdCSFIBLusDfHtl,'plot':mNnWwAyEzrVKpavGdCSFIBLusDfHMb}
   mNnWwAyEzrVKpavGdCSFIBLusDfHxO={'mode':'MOVIE','mediacode':mNnWwAyEzrVKpavGdCSFIBLusDfHUM.get('moviecode'),'stype':'movie','title':mNnWwAyEzrVKpavGdCSFIBLusDfHxQ,'thumbnail':mNnWwAyEzrVKpavGdCSFIBLusDfHMg}
   if mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.get_settings_makebookmark():
    mNnWwAyEzrVKpavGdCSFIBLusDfHtQ={'videoid':mNnWwAyEzrVKpavGdCSFIBLusDfHUM.get('moviecode'),'vidtype':'movie','vtitle':mNnWwAyEzrVKpavGdCSFIBLusDfHte,'vsubtitle':'',}
    mNnWwAyEzrVKpavGdCSFIBLusDfHtj=json.dumps(mNnWwAyEzrVKpavGdCSFIBLusDfHtQ)
    mNnWwAyEzrVKpavGdCSFIBLusDfHtj=urllib.parse.quote(mNnWwAyEzrVKpavGdCSFIBLusDfHtj)
    mNnWwAyEzrVKpavGdCSFIBLusDfHtR='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(mNnWwAyEzrVKpavGdCSFIBLusDfHtj)
    mNnWwAyEzrVKpavGdCSFIBLusDfHtP=[('(통합) 찜 영상에 추가',mNnWwAyEzrVKpavGdCSFIBLusDfHtR)]
   else:
    mNnWwAyEzrVKpavGdCSFIBLusDfHtP=mNnWwAyEzrVKpavGdCSFIBLusDfHkU
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.add_dir(mNnWwAyEzrVKpavGdCSFIBLusDfHxQ,sublabel='',img=mNnWwAyEzrVKpavGdCSFIBLusDfHMg,infoLabels=mNnWwAyEzrVKpavGdCSFIBLusDfHtM,isFolder=mNnWwAyEzrVKpavGdCSFIBLusDfHkh,params=mNnWwAyEzrVKpavGdCSFIBLusDfHxO,ContextMenu=mNnWwAyEzrVKpavGdCSFIBLusDfHtP)
  if mNnWwAyEzrVKpavGdCSFIBLusDfHMP:
   mNnWwAyEzrVKpavGdCSFIBLusDfHxO={}
   mNnWwAyEzrVKpavGdCSFIBLusDfHxO['mode'] ='MOVIE_SUB' 
   mNnWwAyEzrVKpavGdCSFIBLusDfHxO['orderby']=mNnWwAyEzrVKpavGdCSFIBLusDfHtq
   mNnWwAyEzrVKpavGdCSFIBLusDfHxO['stype'] =mNnWwAyEzrVKpavGdCSFIBLusDfHtJ
   mNnWwAyEzrVKpavGdCSFIBLusDfHxO['page'] =mNnWwAyEzrVKpavGdCSFIBLusDfHkj(mNnWwAyEzrVKpavGdCSFIBLusDfHMj+1)
   mNnWwAyEzrVKpavGdCSFIBLusDfHxQ='[B]%s >>[/B]'%'다음 페이지'
   mNnWwAyEzrVKpavGdCSFIBLusDfHtU=mNnWwAyEzrVKpavGdCSFIBLusDfHkj(mNnWwAyEzrVKpavGdCSFIBLusDfHMj+1)
   mNnWwAyEzrVKpavGdCSFIBLusDfHxb=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.add_dir(mNnWwAyEzrVKpavGdCSFIBLusDfHxQ,sublabel=mNnWwAyEzrVKpavGdCSFIBLusDfHtU,img=mNnWwAyEzrVKpavGdCSFIBLusDfHxb,infoLabels=mNnWwAyEzrVKpavGdCSFIBLusDfHkU,isFolder=mNnWwAyEzrVKpavGdCSFIBLusDfHkq,params=mNnWwAyEzrVKpavGdCSFIBLusDfHxO)
  xbmcplugin.setContent(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ._addon_handle,'movies')
  xbmcplugin.endOfDirectory(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ._addon_handle,cacheToDisc=mNnWwAyEzrVKpavGdCSFIBLusDfHkh)
 def dp_Set_Bookmark(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ,mNnWwAyEzrVKpavGdCSFIBLusDfHMQ):
  mNnWwAyEzrVKpavGdCSFIBLusDfHUJ=urllib.parse.unquote(mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('bm_param'))
  mNnWwAyEzrVKpavGdCSFIBLusDfHUJ=json.loads(mNnWwAyEzrVKpavGdCSFIBLusDfHUJ)
  mNnWwAyEzrVKpavGdCSFIBLusDfHUq =mNnWwAyEzrVKpavGdCSFIBLusDfHUJ.get('videoid')
  mNnWwAyEzrVKpavGdCSFIBLusDfHUk =mNnWwAyEzrVKpavGdCSFIBLusDfHUJ.get('vidtype')
  mNnWwAyEzrVKpavGdCSFIBLusDfHUh =mNnWwAyEzrVKpavGdCSFIBLusDfHUJ.get('vtitle')
  mNnWwAyEzrVKpavGdCSFIBLusDfHUY =mNnWwAyEzrVKpavGdCSFIBLusDfHUJ.get('vsubtitle')
  mNnWwAyEzrVKpavGdCSFIBLusDfHlg=xbmcgui.Dialog()
  mNnWwAyEzrVKpavGdCSFIBLusDfHMU=mNnWwAyEzrVKpavGdCSFIBLusDfHlg.yesno(__language__(30913).encode('utf8'),mNnWwAyEzrVKpavGdCSFIBLusDfHUh+' \n\n'+__language__(30914))
  if mNnWwAyEzrVKpavGdCSFIBLusDfHMU==mNnWwAyEzrVKpavGdCSFIBLusDfHkh:return
  mNnWwAyEzrVKpavGdCSFIBLusDfHUi=mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.TvingObj.GetBookmarkInfo(mNnWwAyEzrVKpavGdCSFIBLusDfHUq,mNnWwAyEzrVKpavGdCSFIBLusDfHUk)
  if mNnWwAyEzrVKpavGdCSFIBLusDfHUY!='':
   mNnWwAyEzrVKpavGdCSFIBLusDfHUi['saveinfo']['subtitle']=mNnWwAyEzrVKpavGdCSFIBLusDfHUY 
   if mNnWwAyEzrVKpavGdCSFIBLusDfHUk=='tvshow':mNnWwAyEzrVKpavGdCSFIBLusDfHUi['saveinfo']['infoLabels']['studio']=mNnWwAyEzrVKpavGdCSFIBLusDfHUY 
  mNnWwAyEzrVKpavGdCSFIBLusDfHUQ=json.dumps(mNnWwAyEzrVKpavGdCSFIBLusDfHUi)
  mNnWwAyEzrVKpavGdCSFIBLusDfHUQ=urllib.parse.quote(mNnWwAyEzrVKpavGdCSFIBLusDfHUQ)
  mNnWwAyEzrVKpavGdCSFIBLusDfHtR ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(mNnWwAyEzrVKpavGdCSFIBLusDfHUQ)
  xbmc.executebuiltin(mNnWwAyEzrVKpavGdCSFIBLusDfHtR)
 def dp_Search_Group(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ,mNnWwAyEzrVKpavGdCSFIBLusDfHMQ):
  if 'search_key' in mNnWwAyEzrVKpavGdCSFIBLusDfHMQ:
   mNnWwAyEzrVKpavGdCSFIBLusDfHUj=mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('search_key')
  else:
   mNnWwAyEzrVKpavGdCSFIBLusDfHUj=mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not mNnWwAyEzrVKpavGdCSFIBLusDfHUj:
    return
  for mNnWwAyEzrVKpavGdCSFIBLusDfHMi in mNnWwAyEzrVKpavGdCSFIBLusDfHlJ:
   mNnWwAyEzrVKpavGdCSFIBLusDfHUR =mNnWwAyEzrVKpavGdCSFIBLusDfHMi.get('mode')
   mNnWwAyEzrVKpavGdCSFIBLusDfHMh=mNnWwAyEzrVKpavGdCSFIBLusDfHMi.get('stype')
   mNnWwAyEzrVKpavGdCSFIBLusDfHxQ=mNnWwAyEzrVKpavGdCSFIBLusDfHMi.get('title')
   (mNnWwAyEzrVKpavGdCSFIBLusDfHUP,mNnWwAyEzrVKpavGdCSFIBLusDfHMP)=mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.TvingObj.GetSearchList(mNnWwAyEzrVKpavGdCSFIBLusDfHUj,1,mNnWwAyEzrVKpavGdCSFIBLusDfHMh)
   mNnWwAyEzrVKpavGdCSFIBLusDfHUo={'plot':'검색어 : '+mNnWwAyEzrVKpavGdCSFIBLusDfHUj+'\n\n'+mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.Search_FreeList(mNnWwAyEzrVKpavGdCSFIBLusDfHUP)}
   mNnWwAyEzrVKpavGdCSFIBLusDfHxO={'mode':mNnWwAyEzrVKpavGdCSFIBLusDfHUR,'stype':mNnWwAyEzrVKpavGdCSFIBLusDfHMh,'search_key':mNnWwAyEzrVKpavGdCSFIBLusDfHUj,'page':'1',}
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.add_dir(mNnWwAyEzrVKpavGdCSFIBLusDfHxQ,sublabel='',img='',infoLabels=mNnWwAyEzrVKpavGdCSFIBLusDfHUo,isFolder=mNnWwAyEzrVKpavGdCSFIBLusDfHkq,params=mNnWwAyEzrVKpavGdCSFIBLusDfHxO)
  if mNnWwAyEzrVKpavGdCSFIBLusDfHkQ(mNnWwAyEzrVKpavGdCSFIBLusDfHlJ)>0:xbmcplugin.endOfDirectory(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ._addon_handle,cacheToDisc=mNnWwAyEzrVKpavGdCSFIBLusDfHkq)
  mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.Save_Searched_List(mNnWwAyEzrVKpavGdCSFIBLusDfHUj)
 def Search_FreeList(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ,mNnWwAyEzrVKpavGdCSFIBLusDfHJx):
  mNnWwAyEzrVKpavGdCSFIBLusDfHUg=''
  mNnWwAyEzrVKpavGdCSFIBLusDfHUb=7
  try:
   if mNnWwAyEzrVKpavGdCSFIBLusDfHkQ(mNnWwAyEzrVKpavGdCSFIBLusDfHJx)==0:return '검색결과 없음'
   for i in mNnWwAyEzrVKpavGdCSFIBLusDfHkR(mNnWwAyEzrVKpavGdCSFIBLusDfHkQ(mNnWwAyEzrVKpavGdCSFIBLusDfHJx)):
    if i>=mNnWwAyEzrVKpavGdCSFIBLusDfHUb:
     mNnWwAyEzrVKpavGdCSFIBLusDfHUg=mNnWwAyEzrVKpavGdCSFIBLusDfHUg+'...'
     break
    mNnWwAyEzrVKpavGdCSFIBLusDfHUg=mNnWwAyEzrVKpavGdCSFIBLusDfHUg+mNnWwAyEzrVKpavGdCSFIBLusDfHJx[i]['title']+'\n'
  except:
   return ''
  return mNnWwAyEzrVKpavGdCSFIBLusDfHUg
 def dp_Search_History(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ,mNnWwAyEzrVKpavGdCSFIBLusDfHMQ):
  mNnWwAyEzrVKpavGdCSFIBLusDfHUO=mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.Load_List_File('search')
  for mNnWwAyEzrVKpavGdCSFIBLusDfHUX in mNnWwAyEzrVKpavGdCSFIBLusDfHUO:
   mNnWwAyEzrVKpavGdCSFIBLusDfHUe=mNnWwAyEzrVKpavGdCSFIBLusDfHki(urllib.parse.parse_qsl(mNnWwAyEzrVKpavGdCSFIBLusDfHUX))
   mNnWwAyEzrVKpavGdCSFIBLusDfHUT=mNnWwAyEzrVKpavGdCSFIBLusDfHUe.get('skey').strip()
   mNnWwAyEzrVKpavGdCSFIBLusDfHxO={'mode':'SEARCH_GROUP','search_key':mNnWwAyEzrVKpavGdCSFIBLusDfHUT,}
   mNnWwAyEzrVKpavGdCSFIBLusDfHUc={'mode':'SEARCH_REMOVE','stype':'ONE','skey':mNnWwAyEzrVKpavGdCSFIBLusDfHUT,}
   mNnWwAyEzrVKpavGdCSFIBLusDfHJl=urllib.parse.urlencode(mNnWwAyEzrVKpavGdCSFIBLusDfHUc)
   mNnWwAyEzrVKpavGdCSFIBLusDfHtP=[('선택된 검색어 ( %s ) 삭제'%(mNnWwAyEzrVKpavGdCSFIBLusDfHUT),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(mNnWwAyEzrVKpavGdCSFIBLusDfHJl))]
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.add_dir(mNnWwAyEzrVKpavGdCSFIBLusDfHUT,sublabel='',img=mNnWwAyEzrVKpavGdCSFIBLusDfHkU,infoLabels=mNnWwAyEzrVKpavGdCSFIBLusDfHkU,isFolder=mNnWwAyEzrVKpavGdCSFIBLusDfHkq,params=mNnWwAyEzrVKpavGdCSFIBLusDfHxO,ContextMenu=mNnWwAyEzrVKpavGdCSFIBLusDfHtP)
  mNnWwAyEzrVKpavGdCSFIBLusDfHtM={'plot':'검색목록 전체를 삭제합니다.'}
  mNnWwAyEzrVKpavGdCSFIBLusDfHxQ='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  mNnWwAyEzrVKpavGdCSFIBLusDfHxO={'mode':'SEARCH_REMOVE','stype':'ALL','skey':'-',}
  mNnWwAyEzrVKpavGdCSFIBLusDfHxb=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.add_dir(mNnWwAyEzrVKpavGdCSFIBLusDfHxQ,sublabel='',img=mNnWwAyEzrVKpavGdCSFIBLusDfHxb,infoLabels=mNnWwAyEzrVKpavGdCSFIBLusDfHtM,isFolder=mNnWwAyEzrVKpavGdCSFIBLusDfHkh,params=mNnWwAyEzrVKpavGdCSFIBLusDfHxO,isLink=mNnWwAyEzrVKpavGdCSFIBLusDfHkq)
  xbmcplugin.endOfDirectory(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ._addon_handle,cacheToDisc=mNnWwAyEzrVKpavGdCSFIBLusDfHkh)
 def dp_Search_List(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ,mNnWwAyEzrVKpavGdCSFIBLusDfHMQ):
  mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.TvingObj.SaveCredential(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.get_winCredential())
  mNnWwAyEzrVKpavGdCSFIBLusDfHMj =mNnWwAyEzrVKpavGdCSFIBLusDfHkJ(mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('page'))
  mNnWwAyEzrVKpavGdCSFIBLusDfHMh =mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('stype')
  if 'search_key' in mNnWwAyEzrVKpavGdCSFIBLusDfHMQ:
   mNnWwAyEzrVKpavGdCSFIBLusDfHUj=mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('search_key')
  else:
   mNnWwAyEzrVKpavGdCSFIBLusDfHUj=mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not mNnWwAyEzrVKpavGdCSFIBLusDfHUj:
    xbmcplugin.endOfDirectory(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ._addon_handle)
    return
  mNnWwAyEzrVKpavGdCSFIBLusDfHUP,mNnWwAyEzrVKpavGdCSFIBLusDfHMP=mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.TvingObj.GetSearchList(mNnWwAyEzrVKpavGdCSFIBLusDfHUj,mNnWwAyEzrVKpavGdCSFIBLusDfHMj,mNnWwAyEzrVKpavGdCSFIBLusDfHMh)
  for mNnWwAyEzrVKpavGdCSFIBLusDfHJx in mNnWwAyEzrVKpavGdCSFIBLusDfHUP:
   mNnWwAyEzrVKpavGdCSFIBLusDfHxQ =mNnWwAyEzrVKpavGdCSFIBLusDfHJx.get('title')
   mNnWwAyEzrVKpavGdCSFIBLusDfHMg =mNnWwAyEzrVKpavGdCSFIBLusDfHJx.get('thumbnail')
   mNnWwAyEzrVKpavGdCSFIBLusDfHMb =mNnWwAyEzrVKpavGdCSFIBLusDfHJx.get('synopsis')
   mNnWwAyEzrVKpavGdCSFIBLusDfHJM =mNnWwAyEzrVKpavGdCSFIBLusDfHJx.get('program')
   mNnWwAyEzrVKpavGdCSFIBLusDfHMX =mNnWwAyEzrVKpavGdCSFIBLusDfHJx.get('cast')
   mNnWwAyEzrVKpavGdCSFIBLusDfHMe =mNnWwAyEzrVKpavGdCSFIBLusDfHJx.get('director')
   mNnWwAyEzrVKpavGdCSFIBLusDfHMT=mNnWwAyEzrVKpavGdCSFIBLusDfHJx.get('info_genre')
   mNnWwAyEzrVKpavGdCSFIBLusDfHUt =mNnWwAyEzrVKpavGdCSFIBLusDfHJx.get('duration')
   mNnWwAyEzrVKpavGdCSFIBLusDfHtl =mNnWwAyEzrVKpavGdCSFIBLusDfHJx.get('mpaa')
   mNnWwAyEzrVKpavGdCSFIBLusDfHMc =mNnWwAyEzrVKpavGdCSFIBLusDfHJx.get('year')
   mNnWwAyEzrVKpavGdCSFIBLusDfHtT =mNnWwAyEzrVKpavGdCSFIBLusDfHJx.get('aired')
   mNnWwAyEzrVKpavGdCSFIBLusDfHtM={'mediatype':'tvshow' if mNnWwAyEzrVKpavGdCSFIBLusDfHMh=='vod' else 'movie','title':mNnWwAyEzrVKpavGdCSFIBLusDfHxQ,'cast':mNnWwAyEzrVKpavGdCSFIBLusDfHMX,'director':mNnWwAyEzrVKpavGdCSFIBLusDfHMe,'genre':mNnWwAyEzrVKpavGdCSFIBLusDfHMT,'duration':mNnWwAyEzrVKpavGdCSFIBLusDfHUt,'mpaa':mNnWwAyEzrVKpavGdCSFIBLusDfHtl,'year':mNnWwAyEzrVKpavGdCSFIBLusDfHMc,'aired':mNnWwAyEzrVKpavGdCSFIBLusDfHtT,'plot':'%s\n\n%s'%(mNnWwAyEzrVKpavGdCSFIBLusDfHxQ,mNnWwAyEzrVKpavGdCSFIBLusDfHMb)}
   if mNnWwAyEzrVKpavGdCSFIBLusDfHMh=='vod':
    mNnWwAyEzrVKpavGdCSFIBLusDfHUq=mNnWwAyEzrVKpavGdCSFIBLusDfHJx.get('program')
    mNnWwAyEzrVKpavGdCSFIBLusDfHUk='tvshow'
    mNnWwAyEzrVKpavGdCSFIBLusDfHxO={'mode':'EPISODE','programcode':mNnWwAyEzrVKpavGdCSFIBLusDfHUq,'page':'1',}
    mNnWwAyEzrVKpavGdCSFIBLusDfHxX=mNnWwAyEzrVKpavGdCSFIBLusDfHkq
   else:
    mNnWwAyEzrVKpavGdCSFIBLusDfHUq=mNnWwAyEzrVKpavGdCSFIBLusDfHJx.get('movie')
    mNnWwAyEzrVKpavGdCSFIBLusDfHUk='movie'
    mNnWwAyEzrVKpavGdCSFIBLusDfHxO={'mode':'MOVIE','mediacode':mNnWwAyEzrVKpavGdCSFIBLusDfHUq,'stype':'movie','title':mNnWwAyEzrVKpavGdCSFIBLusDfHxQ,'thumbnail':mNnWwAyEzrVKpavGdCSFIBLusDfHMg,}
    mNnWwAyEzrVKpavGdCSFIBLusDfHxX=mNnWwAyEzrVKpavGdCSFIBLusDfHkh
   if mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.get_settings_makebookmark():
    mNnWwAyEzrVKpavGdCSFIBLusDfHtQ={'videoid':mNnWwAyEzrVKpavGdCSFIBLusDfHUq,'vidtype':mNnWwAyEzrVKpavGdCSFIBLusDfHUk,'vtitle':mNnWwAyEzrVKpavGdCSFIBLusDfHxQ,'vsubtitle':'',}
    mNnWwAyEzrVKpavGdCSFIBLusDfHtj=json.dumps(mNnWwAyEzrVKpavGdCSFIBLusDfHtQ)
    mNnWwAyEzrVKpavGdCSFIBLusDfHtj=urllib.parse.quote(mNnWwAyEzrVKpavGdCSFIBLusDfHtj)
    mNnWwAyEzrVKpavGdCSFIBLusDfHtR='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(mNnWwAyEzrVKpavGdCSFIBLusDfHtj)
    mNnWwAyEzrVKpavGdCSFIBLusDfHtP=[('(통합) 찜 영상에 추가',mNnWwAyEzrVKpavGdCSFIBLusDfHtR)]
   else:
    mNnWwAyEzrVKpavGdCSFIBLusDfHtP=mNnWwAyEzrVKpavGdCSFIBLusDfHkU
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.add_dir(mNnWwAyEzrVKpavGdCSFIBLusDfHxQ,sublabel='',img=mNnWwAyEzrVKpavGdCSFIBLusDfHMg,infoLabels=mNnWwAyEzrVKpavGdCSFIBLusDfHtM,isFolder=mNnWwAyEzrVKpavGdCSFIBLusDfHxX,params=mNnWwAyEzrVKpavGdCSFIBLusDfHxO,isLink=mNnWwAyEzrVKpavGdCSFIBLusDfHkh,ContextMenu=mNnWwAyEzrVKpavGdCSFIBLusDfHtP)
  if mNnWwAyEzrVKpavGdCSFIBLusDfHMP:
   mNnWwAyEzrVKpavGdCSFIBLusDfHxO['mode'] ='SEARCH' 
   mNnWwAyEzrVKpavGdCSFIBLusDfHxO['search_key']=mNnWwAyEzrVKpavGdCSFIBLusDfHUj
   mNnWwAyEzrVKpavGdCSFIBLusDfHxO['page'] =mNnWwAyEzrVKpavGdCSFIBLusDfHkj(mNnWwAyEzrVKpavGdCSFIBLusDfHMj+1)
   mNnWwAyEzrVKpavGdCSFIBLusDfHxQ='[B]%s >>[/B]'%'다음 페이지'
   mNnWwAyEzrVKpavGdCSFIBLusDfHtU=mNnWwAyEzrVKpavGdCSFIBLusDfHkj(mNnWwAyEzrVKpavGdCSFIBLusDfHMj+1)
   mNnWwAyEzrVKpavGdCSFIBLusDfHxb=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.add_dir(mNnWwAyEzrVKpavGdCSFIBLusDfHxQ,sublabel=mNnWwAyEzrVKpavGdCSFIBLusDfHtU,img=mNnWwAyEzrVKpavGdCSFIBLusDfHxb,infoLabels=mNnWwAyEzrVKpavGdCSFIBLusDfHkU,isFolder=mNnWwAyEzrVKpavGdCSFIBLusDfHkq,params=mNnWwAyEzrVKpavGdCSFIBLusDfHxO)
  if mNnWwAyEzrVKpavGdCSFIBLusDfHMh=='movie':xbmcplugin.setContent(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ._addon_handle,'movies')
  else:xbmcplugin.setContent(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ._addon_handle,cacheToDisc=mNnWwAyEzrVKpavGdCSFIBLusDfHkh)
 def Delete_List_File(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ,mNnWwAyEzrVKpavGdCSFIBLusDfHMh,skey='-'):
  if mNnWwAyEzrVKpavGdCSFIBLusDfHMh=='ALL':
   try:
    mNnWwAyEzrVKpavGdCSFIBLusDfHJt=mNnWwAyEzrVKpavGdCSFIBLusDfHli
    fp=mNnWwAyEzrVKpavGdCSFIBLusDfHkP(mNnWwAyEzrVKpavGdCSFIBLusDfHJt,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    mNnWwAyEzrVKpavGdCSFIBLusDfHkU
  elif mNnWwAyEzrVKpavGdCSFIBLusDfHMh=='ONE':
   try:
    mNnWwAyEzrVKpavGdCSFIBLusDfHJt=mNnWwAyEzrVKpavGdCSFIBLusDfHli
    mNnWwAyEzrVKpavGdCSFIBLusDfHJU=mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.Load_List_File('search') 
    fp=mNnWwAyEzrVKpavGdCSFIBLusDfHkP(mNnWwAyEzrVKpavGdCSFIBLusDfHJt,'w',-1,'utf-8')
    for mNnWwAyEzrVKpavGdCSFIBLusDfHJq in mNnWwAyEzrVKpavGdCSFIBLusDfHJU:
     mNnWwAyEzrVKpavGdCSFIBLusDfHJk=mNnWwAyEzrVKpavGdCSFIBLusDfHki(urllib.parse.parse_qsl(mNnWwAyEzrVKpavGdCSFIBLusDfHJq))
     mNnWwAyEzrVKpavGdCSFIBLusDfHJh=mNnWwAyEzrVKpavGdCSFIBLusDfHJk.get('skey').strip()
     if skey!=mNnWwAyEzrVKpavGdCSFIBLusDfHJh:
      fp.write(mNnWwAyEzrVKpavGdCSFIBLusDfHJq)
    fp.close()
   except:
    mNnWwAyEzrVKpavGdCSFIBLusDfHkU
  elif mNnWwAyEzrVKpavGdCSFIBLusDfHMh in['vod','movie']:
   try:
    mNnWwAyEzrVKpavGdCSFIBLusDfHJt=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%mNnWwAyEzrVKpavGdCSFIBLusDfHMh))
    fp=mNnWwAyEzrVKpavGdCSFIBLusDfHkP(mNnWwAyEzrVKpavGdCSFIBLusDfHJt,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    mNnWwAyEzrVKpavGdCSFIBLusDfHkU
 def dp_Listfile_Delete(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ,mNnWwAyEzrVKpavGdCSFIBLusDfHMQ):
  mNnWwAyEzrVKpavGdCSFIBLusDfHMh=mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('stype')
  mNnWwAyEzrVKpavGdCSFIBLusDfHUT =mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('skey')
  mNnWwAyEzrVKpavGdCSFIBLusDfHlg=xbmcgui.Dialog()
  if mNnWwAyEzrVKpavGdCSFIBLusDfHMh=='ALL':
   mNnWwAyEzrVKpavGdCSFIBLusDfHMU=mNnWwAyEzrVKpavGdCSFIBLusDfHlg.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif mNnWwAyEzrVKpavGdCSFIBLusDfHMh=='ONE':
   mNnWwAyEzrVKpavGdCSFIBLusDfHMU=mNnWwAyEzrVKpavGdCSFIBLusDfHlg.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif mNnWwAyEzrVKpavGdCSFIBLusDfHMh in['vod','movie']:
   mNnWwAyEzrVKpavGdCSFIBLusDfHMU=mNnWwAyEzrVKpavGdCSFIBLusDfHlg.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if mNnWwAyEzrVKpavGdCSFIBLusDfHMU==mNnWwAyEzrVKpavGdCSFIBLusDfHkh:sys.exit()
  mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.Delete_List_File(mNnWwAyEzrVKpavGdCSFIBLusDfHMh,skey=mNnWwAyEzrVKpavGdCSFIBLusDfHUT)
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ,mNnWwAyEzrVKpavGdCSFIBLusDfHMh): 
  try:
   if mNnWwAyEzrVKpavGdCSFIBLusDfHMh=='search':
    mNnWwAyEzrVKpavGdCSFIBLusDfHJt=mNnWwAyEzrVKpavGdCSFIBLusDfHli
   elif mNnWwAyEzrVKpavGdCSFIBLusDfHMh in['vod','movie']:
    mNnWwAyEzrVKpavGdCSFIBLusDfHJt=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%mNnWwAyEzrVKpavGdCSFIBLusDfHMh))
   else:
    return[]
   fp=mNnWwAyEzrVKpavGdCSFIBLusDfHkP(mNnWwAyEzrVKpavGdCSFIBLusDfHJt,'r',-1,'utf-8')
   mNnWwAyEzrVKpavGdCSFIBLusDfHJY=fp.readlines()
   fp.close()
  except:
   mNnWwAyEzrVKpavGdCSFIBLusDfHJY=[]
  return mNnWwAyEzrVKpavGdCSFIBLusDfHJY
 def Save_Watched_List(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ,mNnWwAyEzrVKpavGdCSFIBLusDfHMh,mNnWwAyEzrVKpavGdCSFIBLusDfHlP):
  try:
   mNnWwAyEzrVKpavGdCSFIBLusDfHJi=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%mNnWwAyEzrVKpavGdCSFIBLusDfHMh))
   mNnWwAyEzrVKpavGdCSFIBLusDfHJU=mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.Load_List_File(mNnWwAyEzrVKpavGdCSFIBLusDfHMh) 
   fp=mNnWwAyEzrVKpavGdCSFIBLusDfHkP(mNnWwAyEzrVKpavGdCSFIBLusDfHJi,'w',-1,'utf-8')
   mNnWwAyEzrVKpavGdCSFIBLusDfHJQ=urllib.parse.urlencode(mNnWwAyEzrVKpavGdCSFIBLusDfHlP)
   mNnWwAyEzrVKpavGdCSFIBLusDfHJQ=mNnWwAyEzrVKpavGdCSFIBLusDfHJQ+'\n'
   fp.write(mNnWwAyEzrVKpavGdCSFIBLusDfHJQ)
   mNnWwAyEzrVKpavGdCSFIBLusDfHJj=0
   for mNnWwAyEzrVKpavGdCSFIBLusDfHJq in mNnWwAyEzrVKpavGdCSFIBLusDfHJU:
    mNnWwAyEzrVKpavGdCSFIBLusDfHJk=mNnWwAyEzrVKpavGdCSFIBLusDfHki(urllib.parse.parse_qsl(mNnWwAyEzrVKpavGdCSFIBLusDfHJq))
    mNnWwAyEzrVKpavGdCSFIBLusDfHJR=mNnWwAyEzrVKpavGdCSFIBLusDfHlP.get('code').strip()
    mNnWwAyEzrVKpavGdCSFIBLusDfHJP=mNnWwAyEzrVKpavGdCSFIBLusDfHJk.get('code').strip()
    if mNnWwAyEzrVKpavGdCSFIBLusDfHMh=='vod' and mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.get_settings_direct_replay()==mNnWwAyEzrVKpavGdCSFIBLusDfHkq:
     mNnWwAyEzrVKpavGdCSFIBLusDfHJR=mNnWwAyEzrVKpavGdCSFIBLusDfHlP.get('videoid').strip()
     mNnWwAyEzrVKpavGdCSFIBLusDfHJP=mNnWwAyEzrVKpavGdCSFIBLusDfHJk.get('videoid').strip()if mNnWwAyEzrVKpavGdCSFIBLusDfHJP!=mNnWwAyEzrVKpavGdCSFIBLusDfHkU else '-'
    if mNnWwAyEzrVKpavGdCSFIBLusDfHJR!=mNnWwAyEzrVKpavGdCSFIBLusDfHJP:
     fp.write(mNnWwAyEzrVKpavGdCSFIBLusDfHJq)
     mNnWwAyEzrVKpavGdCSFIBLusDfHJj+=1
     if mNnWwAyEzrVKpavGdCSFIBLusDfHJj>=50:break
   fp.close()
  except:
   mNnWwAyEzrVKpavGdCSFIBLusDfHkU
 def dp_Watch_List(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ,mNnWwAyEzrVKpavGdCSFIBLusDfHMQ):
  mNnWwAyEzrVKpavGdCSFIBLusDfHMh =mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('stype')
  mNnWwAyEzrVKpavGdCSFIBLusDfHxk=mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.get_settings_direct_replay()
  if mNnWwAyEzrVKpavGdCSFIBLusDfHMh=='-':
   for mNnWwAyEzrVKpavGdCSFIBLusDfHMi in mNnWwAyEzrVKpavGdCSFIBLusDfHlU:
    mNnWwAyEzrVKpavGdCSFIBLusDfHxQ=mNnWwAyEzrVKpavGdCSFIBLusDfHMi.get('title')
    mNnWwAyEzrVKpavGdCSFIBLusDfHxO={'mode':mNnWwAyEzrVKpavGdCSFIBLusDfHMi.get('mode'),'stype':mNnWwAyEzrVKpavGdCSFIBLusDfHMi.get('stype')}
    mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.add_dir(mNnWwAyEzrVKpavGdCSFIBLusDfHxQ,sublabel='',img='',infoLabels=mNnWwAyEzrVKpavGdCSFIBLusDfHkU,isFolder=mNnWwAyEzrVKpavGdCSFIBLusDfHkq,params=mNnWwAyEzrVKpavGdCSFIBLusDfHxO)
   if mNnWwAyEzrVKpavGdCSFIBLusDfHkQ(mNnWwAyEzrVKpavGdCSFIBLusDfHlU)>0:xbmcplugin.endOfDirectory(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ._addon_handle)
  else:
   mNnWwAyEzrVKpavGdCSFIBLusDfHJo=mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.Load_List_File(mNnWwAyEzrVKpavGdCSFIBLusDfHMh)
   for mNnWwAyEzrVKpavGdCSFIBLusDfHJg in mNnWwAyEzrVKpavGdCSFIBLusDfHJo:
    mNnWwAyEzrVKpavGdCSFIBLusDfHUe=mNnWwAyEzrVKpavGdCSFIBLusDfHki(urllib.parse.parse_qsl(mNnWwAyEzrVKpavGdCSFIBLusDfHJg))
    mNnWwAyEzrVKpavGdCSFIBLusDfHJb =mNnWwAyEzrVKpavGdCSFIBLusDfHUe.get('code').strip()
    mNnWwAyEzrVKpavGdCSFIBLusDfHxQ =mNnWwAyEzrVKpavGdCSFIBLusDfHUe.get('title').strip()
    mNnWwAyEzrVKpavGdCSFIBLusDfHMg=mNnWwAyEzrVKpavGdCSFIBLusDfHUe.get('img').strip()
    mNnWwAyEzrVKpavGdCSFIBLusDfHUq =mNnWwAyEzrVKpavGdCSFIBLusDfHUe.get('videoid').strip()
    try:
     mNnWwAyEzrVKpavGdCSFIBLusDfHMg=mNnWwAyEzrVKpavGdCSFIBLusDfHMg.replace('\'','\"')
     mNnWwAyEzrVKpavGdCSFIBLusDfHMg=json.loads(mNnWwAyEzrVKpavGdCSFIBLusDfHMg)
    except:
     mNnWwAyEzrVKpavGdCSFIBLusDfHkU
    mNnWwAyEzrVKpavGdCSFIBLusDfHtM={}
    mNnWwAyEzrVKpavGdCSFIBLusDfHtM['plot']=mNnWwAyEzrVKpavGdCSFIBLusDfHxQ
    if mNnWwAyEzrVKpavGdCSFIBLusDfHMh=='vod':
     if mNnWwAyEzrVKpavGdCSFIBLusDfHxk==mNnWwAyEzrVKpavGdCSFIBLusDfHkh or mNnWwAyEzrVKpavGdCSFIBLusDfHUq==mNnWwAyEzrVKpavGdCSFIBLusDfHkU:
      mNnWwAyEzrVKpavGdCSFIBLusDfHxO={'mode':'EPISODE','programcode':mNnWwAyEzrVKpavGdCSFIBLusDfHJb,'page':'1'}
      mNnWwAyEzrVKpavGdCSFIBLusDfHxX=mNnWwAyEzrVKpavGdCSFIBLusDfHkq
     else:
      mNnWwAyEzrVKpavGdCSFIBLusDfHxO={'mode':'VOD','mediacode':mNnWwAyEzrVKpavGdCSFIBLusDfHUq,'stype':'vod','programcode':mNnWwAyEzrVKpavGdCSFIBLusDfHJb,'title':mNnWwAyEzrVKpavGdCSFIBLusDfHxQ,'thumbnail':mNnWwAyEzrVKpavGdCSFIBLusDfHMg}
      mNnWwAyEzrVKpavGdCSFIBLusDfHxX=mNnWwAyEzrVKpavGdCSFIBLusDfHkh
    else:
     mNnWwAyEzrVKpavGdCSFIBLusDfHxO={'mode':'MOVIE','mediacode':mNnWwAyEzrVKpavGdCSFIBLusDfHJb,'stype':'movie','title':mNnWwAyEzrVKpavGdCSFIBLusDfHxQ,'thumbnail':mNnWwAyEzrVKpavGdCSFIBLusDfHMg}
     mNnWwAyEzrVKpavGdCSFIBLusDfHxX=mNnWwAyEzrVKpavGdCSFIBLusDfHkh
    mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.add_dir(mNnWwAyEzrVKpavGdCSFIBLusDfHxQ,sublabel='',img=mNnWwAyEzrVKpavGdCSFIBLusDfHMg,infoLabels=mNnWwAyEzrVKpavGdCSFIBLusDfHtM,isFolder=mNnWwAyEzrVKpavGdCSFIBLusDfHxX,params=mNnWwAyEzrVKpavGdCSFIBLusDfHxO)
   mNnWwAyEzrVKpavGdCSFIBLusDfHtM={'plot':'시청목록을 삭제합니다.'}
   mNnWwAyEzrVKpavGdCSFIBLusDfHxQ='*** 시청목록 삭제 ***'
   mNnWwAyEzrVKpavGdCSFIBLusDfHxO={'mode':'MYVIEW_REMOVE','stype':mNnWwAyEzrVKpavGdCSFIBLusDfHMh,'skey':'-',}
   mNnWwAyEzrVKpavGdCSFIBLusDfHxb=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.add_dir(mNnWwAyEzrVKpavGdCSFIBLusDfHxQ,sublabel='',img=mNnWwAyEzrVKpavGdCSFIBLusDfHxb,infoLabels=mNnWwAyEzrVKpavGdCSFIBLusDfHtM,isFolder=mNnWwAyEzrVKpavGdCSFIBLusDfHkh,params=mNnWwAyEzrVKpavGdCSFIBLusDfHxO,isLink=mNnWwAyEzrVKpavGdCSFIBLusDfHkq)
   if mNnWwAyEzrVKpavGdCSFIBLusDfHMh=='movie':xbmcplugin.setContent(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ._addon_handle,'movies')
   else:xbmcplugin.setContent(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ._addon_handle,cacheToDisc=mNnWwAyEzrVKpavGdCSFIBLusDfHkh)
 def Save_Searched_List(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ,mNnWwAyEzrVKpavGdCSFIBLusDfHUj):
  try:
   mNnWwAyEzrVKpavGdCSFIBLusDfHJO=mNnWwAyEzrVKpavGdCSFIBLusDfHli
   mNnWwAyEzrVKpavGdCSFIBLusDfHJU=mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.Load_List_File('search') 
   mNnWwAyEzrVKpavGdCSFIBLusDfHJX={'skey':mNnWwAyEzrVKpavGdCSFIBLusDfHUj.strip()}
   fp=mNnWwAyEzrVKpavGdCSFIBLusDfHkP(mNnWwAyEzrVKpavGdCSFIBLusDfHJO,'w',-1,'utf-8')
   mNnWwAyEzrVKpavGdCSFIBLusDfHJQ=urllib.parse.urlencode(mNnWwAyEzrVKpavGdCSFIBLusDfHJX)
   mNnWwAyEzrVKpavGdCSFIBLusDfHJQ=mNnWwAyEzrVKpavGdCSFIBLusDfHJQ+'\n'
   fp.write(mNnWwAyEzrVKpavGdCSFIBLusDfHJQ)
   mNnWwAyEzrVKpavGdCSFIBLusDfHJj=0
   for mNnWwAyEzrVKpavGdCSFIBLusDfHJq in mNnWwAyEzrVKpavGdCSFIBLusDfHJU:
    mNnWwAyEzrVKpavGdCSFIBLusDfHJk=mNnWwAyEzrVKpavGdCSFIBLusDfHki(urllib.parse.parse_qsl(mNnWwAyEzrVKpavGdCSFIBLusDfHJq))
    mNnWwAyEzrVKpavGdCSFIBLusDfHJR=mNnWwAyEzrVKpavGdCSFIBLusDfHJX.get('skey').strip()
    mNnWwAyEzrVKpavGdCSFIBLusDfHJP=mNnWwAyEzrVKpavGdCSFIBLusDfHJk.get('skey').strip()
    if mNnWwAyEzrVKpavGdCSFIBLusDfHJR!=mNnWwAyEzrVKpavGdCSFIBLusDfHJP:
     fp.write(mNnWwAyEzrVKpavGdCSFIBLusDfHJq)
     mNnWwAyEzrVKpavGdCSFIBLusDfHJj+=1
     if mNnWwAyEzrVKpavGdCSFIBLusDfHJj>=50:break
   fp.close()
  except:
   mNnWwAyEzrVKpavGdCSFIBLusDfHkU
 def play_VIDEO(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ,mNnWwAyEzrVKpavGdCSFIBLusDfHMQ):
  mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.TvingObj.SaveCredential(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.get_winCredential())
  mNnWwAyEzrVKpavGdCSFIBLusDfHJe =mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('mediacode')
  mNnWwAyEzrVKpavGdCSFIBLusDfHMh =mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('stype')
  mNnWwAyEzrVKpavGdCSFIBLusDfHJT =mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('pvrmode')
  mNnWwAyEzrVKpavGdCSFIBLusDfHJc=mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.get_selQuality(mNnWwAyEzrVKpavGdCSFIBLusDfHMh)
  mNnWwAyEzrVKpavGdCSFIBLusDfHql,mNnWwAyEzrVKpavGdCSFIBLusDfHqx=mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.TvingObj.GetBroadURL(mNnWwAyEzrVKpavGdCSFIBLusDfHJe,mNnWwAyEzrVKpavGdCSFIBLusDfHJc,mNnWwAyEzrVKpavGdCSFIBLusDfHMh,mNnWwAyEzrVKpavGdCSFIBLusDfHJT)
  mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.addon_log('qt, stype, url : %s - %s - %s'%(mNnWwAyEzrVKpavGdCSFIBLusDfHkj(mNnWwAyEzrVKpavGdCSFIBLusDfHJc),mNnWwAyEzrVKpavGdCSFIBLusDfHMh,mNnWwAyEzrVKpavGdCSFIBLusDfHql))
  if mNnWwAyEzrVKpavGdCSFIBLusDfHql=='':
   if mNnWwAyEzrVKpavGdCSFIBLusDfHqx=='':
    mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.addon_noti(__language__(30908).encode('utf8'))
   else:
    mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.addon_noti(mNnWwAyEzrVKpavGdCSFIBLusDfHqx.encode('utf8'))
   return
  mNnWwAyEzrVKpavGdCSFIBLusDfHqM =mNnWwAyEzrVKpavGdCSFIBLusDfHkh
  mNnWwAyEzrVKpavGdCSFIBLusDfHqt =mNnWwAyEzrVKpavGdCSFIBLusDfHql.find('Policy=')
  if mNnWwAyEzrVKpavGdCSFIBLusDfHqt!=-1:
   mNnWwAyEzrVKpavGdCSFIBLusDfHqU =mNnWwAyEzrVKpavGdCSFIBLusDfHql.split('?')[0]
   mNnWwAyEzrVKpavGdCSFIBLusDfHqJ=mNnWwAyEzrVKpavGdCSFIBLusDfHki(urllib.parse.parse_qsl(urllib.parse.urlsplit(mNnWwAyEzrVKpavGdCSFIBLusDfHql).query))
   mNnWwAyEzrVKpavGdCSFIBLusDfHqk='CloudFront-Policy=%s;CloudFront-Signature=%s;CloudFront-Key-Pair-Id=%s'%(mNnWwAyEzrVKpavGdCSFIBLusDfHqJ['Policy'],mNnWwAyEzrVKpavGdCSFIBLusDfHqJ['Signature'],mNnWwAyEzrVKpavGdCSFIBLusDfHqJ['Key-Pair-Id'])
   if 'quickvod-mcdn.tving.com' in mNnWwAyEzrVKpavGdCSFIBLusDfHqU:
    mNnWwAyEzrVKpavGdCSFIBLusDfHqM=mNnWwAyEzrVKpavGdCSFIBLusDfHkq
    mNnWwAyEzrVKpavGdCSFIBLusDfHqh =mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    mNnWwAyEzrVKpavGdCSFIBLusDfHqY=mNnWwAyEzrVKpavGdCSFIBLusDfHqh.strftime('%Y-%m-%d-%H:%M:%S')
    if mNnWwAyEzrVKpavGdCSFIBLusDfHkJ(mNnWwAyEzrVKpavGdCSFIBLusDfHqY.replace('-','').replace(':',''))<mNnWwAyEzrVKpavGdCSFIBLusDfHkJ(mNnWwAyEzrVKpavGdCSFIBLusDfHqJ['end'].replace('-','').replace(':','')):
     mNnWwAyEzrVKpavGdCSFIBLusDfHqJ['end']=mNnWwAyEzrVKpavGdCSFIBLusDfHqY
     mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.addon_noti(__language__(30915).encode('utf8'))
    mNnWwAyEzrVKpavGdCSFIBLusDfHqU ='%s?%s'%(mNnWwAyEzrVKpavGdCSFIBLusDfHqU,urllib.parse.urlencode(mNnWwAyEzrVKpavGdCSFIBLusDfHqJ,doseq=mNnWwAyEzrVKpavGdCSFIBLusDfHkq))
   mNnWwAyEzrVKpavGdCSFIBLusDfHqi='%s|Cookie=%s'%(mNnWwAyEzrVKpavGdCSFIBLusDfHqU,mNnWwAyEzrVKpavGdCSFIBLusDfHqk)
  else:
   mNnWwAyEzrVKpavGdCSFIBLusDfHqi=mNnWwAyEzrVKpavGdCSFIBLusDfHql
  mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.addon_log(mNnWwAyEzrVKpavGdCSFIBLusDfHqi)
  mNnWwAyEzrVKpavGdCSFIBLusDfHqQ=xbmcgui.ListItem(path=mNnWwAyEzrVKpavGdCSFIBLusDfHqi)
  if mNnWwAyEzrVKpavGdCSFIBLusDfHqx!='':
   mNnWwAyEzrVKpavGdCSFIBLusDfHqj=mNnWwAyEzrVKpavGdCSFIBLusDfHqx
   mNnWwAyEzrVKpavGdCSFIBLusDfHqR ='https://cj.drmkeyserver.com/widevine_license'
   mNnWwAyEzrVKpavGdCSFIBLusDfHqP ='mpd'
   mNnWwAyEzrVKpavGdCSFIBLusDfHqo ='com.widevine.alpha'
   mNnWwAyEzrVKpavGdCSFIBLusDfHqg =inputstreamhelper.Helper(mNnWwAyEzrVKpavGdCSFIBLusDfHqP,drm='widevine')
   if mNnWwAyEzrVKpavGdCSFIBLusDfHqg.check_inputstream():
    mNnWwAyEzrVKpavGdCSFIBLusDfHqb={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/live/player/%s'%mNnWwAyEzrVKpavGdCSFIBLusDfHJe,'sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.TvingObj.USER_AGENT,'AcquireLicenseAssertion':mNnWwAyEzrVKpavGdCSFIBLusDfHqj,'Host':'cj.drmkeyserver.com'}
    mNnWwAyEzrVKpavGdCSFIBLusDfHqO=mNnWwAyEzrVKpavGdCSFIBLusDfHqR+'|'+urllib.parse.urlencode(mNnWwAyEzrVKpavGdCSFIBLusDfHqb)+'|R{SSM}|'
    mNnWwAyEzrVKpavGdCSFIBLusDfHqQ.setProperty('inputstream',mNnWwAyEzrVKpavGdCSFIBLusDfHqg.inputstream_addon)
    mNnWwAyEzrVKpavGdCSFIBLusDfHqQ.setProperty('inputstream.adaptive.manifest_type',mNnWwAyEzrVKpavGdCSFIBLusDfHqP)
    mNnWwAyEzrVKpavGdCSFIBLusDfHqQ.setProperty('inputstream.adaptive.license_type',mNnWwAyEzrVKpavGdCSFIBLusDfHqo)
    mNnWwAyEzrVKpavGdCSFIBLusDfHqQ.setProperty('inputstream.adaptive.license_key',mNnWwAyEzrVKpavGdCSFIBLusDfHqO)
    mNnWwAyEzrVKpavGdCSFIBLusDfHqQ.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.TvingObj.USER_AGENT))
  elif mNnWwAyEzrVKpavGdCSFIBLusDfHqM==mNnWwAyEzrVKpavGdCSFIBLusDfHkq:
   mNnWwAyEzrVKpavGdCSFIBLusDfHqQ.setContentLookup(mNnWwAyEzrVKpavGdCSFIBLusDfHkh)
   mNnWwAyEzrVKpavGdCSFIBLusDfHqQ.setMimeType('application/x-mpegURL')
   mNnWwAyEzrVKpavGdCSFIBLusDfHqQ.setProperty('inputstream','inputstream.ffmpegdirect')
   mNnWwAyEzrVKpavGdCSFIBLusDfHqQ.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   mNnWwAyEzrVKpavGdCSFIBLusDfHqQ.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   mNnWwAyEzrVKpavGdCSFIBLusDfHqQ.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   mNnWwAyEzrVKpavGdCSFIBLusDfHqQ.setProperty('ResumeTime','0')
   mNnWwAyEzrVKpavGdCSFIBLusDfHqQ.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ._addon_handle,mNnWwAyEzrVKpavGdCSFIBLusDfHkq,mNnWwAyEzrVKpavGdCSFIBLusDfHqQ)
  try:
   if mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('mode')in['VOD','MOVIE']and mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('title'):
    mNnWwAyEzrVKpavGdCSFIBLusDfHxO={'code':mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('programcode')if mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('mode')=='VOD' else mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('mediacode'),'img':mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('thumbnail'),'title':mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('title'),'videoid':mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('mediacode')}
    mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.Save_Watched_List(mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('stype'),mNnWwAyEzrVKpavGdCSFIBLusDfHxO)
  except:
   mNnWwAyEzrVKpavGdCSFIBLusDfHkU
 def logout(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ):
  mNnWwAyEzrVKpavGdCSFIBLusDfHlg=xbmcgui.Dialog()
  mNnWwAyEzrVKpavGdCSFIBLusDfHMU=mNnWwAyEzrVKpavGdCSFIBLusDfHlg.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if mNnWwAyEzrVKpavGdCSFIBLusDfHMU==mNnWwAyEzrVKpavGdCSFIBLusDfHkh:sys.exit()
  mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.wininfo_clear()
  if os.path.isfile(mNnWwAyEzrVKpavGdCSFIBLusDfHlY):os.remove(mNnWwAyEzrVKpavGdCSFIBLusDfHlY)
  mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ):
  mNnWwAyEzrVKpavGdCSFIBLusDfHxh=xbmcgui.Window(10000)
  mNnWwAyEzrVKpavGdCSFIBLusDfHxh.setProperty('TVING_M_TOKEN','')
  mNnWwAyEzrVKpavGdCSFIBLusDfHxh.setProperty('TVING_M_USERINFO','')
  mNnWwAyEzrVKpavGdCSFIBLusDfHxh.setProperty('TVING_M_UUID','')
  mNnWwAyEzrVKpavGdCSFIBLusDfHxh.setProperty('TVING_M_LOGINTIME','')
  mNnWwAyEzrVKpavGdCSFIBLusDfHxh.setProperty('TVING_M_MAINTOKEN','')
  mNnWwAyEzrVKpavGdCSFIBLusDfHxh.setProperty('TVING_M_COOKIEKEY','')
  mNnWwAyEzrVKpavGdCSFIBLusDfHxh.setProperty('TVING_M_LOCKKEY','')
 def cookiefile_save(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ):
  mNnWwAyEzrVKpavGdCSFIBLusDfHqX =mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.TvingObj.Get_Now_Datetime()
  mNnWwAyEzrVKpavGdCSFIBLusDfHqe=mNnWwAyEzrVKpavGdCSFIBLusDfHqX+datetime.timedelta(days=mNnWwAyEzrVKpavGdCSFIBLusDfHkJ(__addon__.getSetting('cache_ttl')))
  mNnWwAyEzrVKpavGdCSFIBLusDfHxh=xbmcgui.Window(10000)
  mNnWwAyEzrVKpavGdCSFIBLusDfHqT={'tving_token':mNnWwAyEzrVKpavGdCSFIBLusDfHxh.getProperty('TVING_M_TOKEN'),'tving_userinfo':mNnWwAyEzrVKpavGdCSFIBLusDfHxh.getProperty('TVING_M_USERINFO'),'tving_uuid':mNnWwAyEzrVKpavGdCSFIBLusDfHxh.getProperty('TVING_M_UUID'),'tving_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'tving_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'tving_logintype':__addon__.getSetting('login_type'),'tving_profile':__addon__.getSetting('selected_profile'),'tving_limitdate':mNnWwAyEzrVKpavGdCSFIBLusDfHqe.strftime('%Y-%m-%d'),'tving_maintoken':mNnWwAyEzrVKpavGdCSFIBLusDfHxh.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':mNnWwAyEzrVKpavGdCSFIBLusDfHxh.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':mNnWwAyEzrVKpavGdCSFIBLusDfHxh.getProperty('TVING_M_LOCKKEY')}
  try: 
   fp=mNnWwAyEzrVKpavGdCSFIBLusDfHkP(mNnWwAyEzrVKpavGdCSFIBLusDfHlY,'w',-1,'utf-8')
   json.dump(mNnWwAyEzrVKpavGdCSFIBLusDfHqT,fp)
   fp.close()
  except mNnWwAyEzrVKpavGdCSFIBLusDfHko as exception:
   mNnWwAyEzrVKpavGdCSFIBLusDfHkg(exception)
 def cookiefile_check(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ):
  mNnWwAyEzrVKpavGdCSFIBLusDfHqT={}
  try: 
   fp=mNnWwAyEzrVKpavGdCSFIBLusDfHkP(mNnWwAyEzrVKpavGdCSFIBLusDfHlY,'r',-1,'utf-8')
   mNnWwAyEzrVKpavGdCSFIBLusDfHqT= json.load(fp)
   fp.close()
  except mNnWwAyEzrVKpavGdCSFIBLusDfHko as exception:
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.wininfo_clear()
   return mNnWwAyEzrVKpavGdCSFIBLusDfHkh
  mNnWwAyEzrVKpavGdCSFIBLusDfHxc =__addon__.getSetting('id')
  mNnWwAyEzrVKpavGdCSFIBLusDfHMl =__addon__.getSetting('pw')
  mNnWwAyEzrVKpavGdCSFIBLusDfHqc=__addon__.getSetting('login_type')
  mNnWwAyEzrVKpavGdCSFIBLusDfHkl =__addon__.getSetting('selected_profile')
  mNnWwAyEzrVKpavGdCSFIBLusDfHqT['tving_id']=base64.standard_b64decode(mNnWwAyEzrVKpavGdCSFIBLusDfHqT['tving_id']).decode('utf-8')
  mNnWwAyEzrVKpavGdCSFIBLusDfHqT['tving_pw']=base64.standard_b64decode(mNnWwAyEzrVKpavGdCSFIBLusDfHqT['tving_pw']).decode('utf-8')
  try:
   mNnWwAyEzrVKpavGdCSFIBLusDfHqT['tving_profile']
  except:
   mNnWwAyEzrVKpavGdCSFIBLusDfHqT['tving_profile']='0'
  if mNnWwAyEzrVKpavGdCSFIBLusDfHxc!=mNnWwAyEzrVKpavGdCSFIBLusDfHqT['tving_id']or mNnWwAyEzrVKpavGdCSFIBLusDfHMl!=mNnWwAyEzrVKpavGdCSFIBLusDfHqT['tving_pw']or mNnWwAyEzrVKpavGdCSFIBLusDfHqc!=mNnWwAyEzrVKpavGdCSFIBLusDfHqT['tving_logintype']or mNnWwAyEzrVKpavGdCSFIBLusDfHkl!=mNnWwAyEzrVKpavGdCSFIBLusDfHqT['tving_profile']:
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.wininfo_clear()
   return mNnWwAyEzrVKpavGdCSFIBLusDfHkh
  mNnWwAyEzrVKpavGdCSFIBLusDfHMJ =mNnWwAyEzrVKpavGdCSFIBLusDfHkJ(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  mNnWwAyEzrVKpavGdCSFIBLusDfHkx=mNnWwAyEzrVKpavGdCSFIBLusDfHqT['tving_limitdate']
  mNnWwAyEzrVKpavGdCSFIBLusDfHMq =mNnWwAyEzrVKpavGdCSFIBLusDfHkJ(re.sub('-','',mNnWwAyEzrVKpavGdCSFIBLusDfHkx))
  if mNnWwAyEzrVKpavGdCSFIBLusDfHMq<mNnWwAyEzrVKpavGdCSFIBLusDfHMJ:
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.wininfo_clear()
   return mNnWwAyEzrVKpavGdCSFIBLusDfHkh
  mNnWwAyEzrVKpavGdCSFIBLusDfHxh=xbmcgui.Window(10000)
  mNnWwAyEzrVKpavGdCSFIBLusDfHxh.setProperty('TVING_M_TOKEN',mNnWwAyEzrVKpavGdCSFIBLusDfHqT['tving_token'])
  mNnWwAyEzrVKpavGdCSFIBLusDfHxh.setProperty('TVING_M_USERINFO',mNnWwAyEzrVKpavGdCSFIBLusDfHqT['tving_userinfo'])
  mNnWwAyEzrVKpavGdCSFIBLusDfHxh.setProperty('TVING_M_UUID',mNnWwAyEzrVKpavGdCSFIBLusDfHqT['tving_uuid'])
  mNnWwAyEzrVKpavGdCSFIBLusDfHxh.setProperty('TVING_M_LOGINTIME',mNnWwAyEzrVKpavGdCSFIBLusDfHkx)
  try:
   mNnWwAyEzrVKpavGdCSFIBLusDfHxh.setProperty('TVING_M_MAINTOKEN',mNnWwAyEzrVKpavGdCSFIBLusDfHqT['tving_maintoken'])
   mNnWwAyEzrVKpavGdCSFIBLusDfHxh.setProperty('TVING_M_COOKIEKEY',mNnWwAyEzrVKpavGdCSFIBLusDfHqT['tving_cookiekey'])
   mNnWwAyEzrVKpavGdCSFIBLusDfHxh.setProperty('TVING_M_LOCKKEY',mNnWwAyEzrVKpavGdCSFIBLusDfHqT['tving_lockkey'])
  except:
   mNnWwAyEzrVKpavGdCSFIBLusDfHxh.setProperty('TVING_M_MAINTOKEN',mNnWwAyEzrVKpavGdCSFIBLusDfHqT['tving_token'])
   mNnWwAyEzrVKpavGdCSFIBLusDfHxh.setProperty('TVING_M_COOKIEKEY','Y')
   mNnWwAyEzrVKpavGdCSFIBLusDfHxh.setProperty('TVING_M_LOCKKEY','N')
  return mNnWwAyEzrVKpavGdCSFIBLusDfHkq
 def dp_Global_Search(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ,mNnWwAyEzrVKpavGdCSFIBLusDfHMQ):
  mNnWwAyEzrVKpavGdCSFIBLusDfHUR=mNnWwAyEzrVKpavGdCSFIBLusDfHMQ.get('mode')
  if mNnWwAyEzrVKpavGdCSFIBLusDfHUR=='TOTAL_SEARCH':
   mNnWwAyEzrVKpavGdCSFIBLusDfHkM='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   mNnWwAyEzrVKpavGdCSFIBLusDfHkM='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(mNnWwAyEzrVKpavGdCSFIBLusDfHkM)
 def dp_Bookmark_Menu(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ,mNnWwAyEzrVKpavGdCSFIBLusDfHMQ):
  mNnWwAyEzrVKpavGdCSFIBLusDfHkM='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(mNnWwAyEzrVKpavGdCSFIBLusDfHkM)
 def dp_EuroLive_List(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ,mNnWwAyEzrVKpavGdCSFIBLusDfHMQ):
  mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.TvingObj.SaveCredential(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.get_winCredential())
  mNnWwAyEzrVKpavGdCSFIBLusDfHMR=mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.TvingObj.GetEuroChannelList()
  for mNnWwAyEzrVKpavGdCSFIBLusDfHMo in mNnWwAyEzrVKpavGdCSFIBLusDfHMR:
   mNnWwAyEzrVKpavGdCSFIBLusDfHti =mNnWwAyEzrVKpavGdCSFIBLusDfHMo.get('channel')
   mNnWwAyEzrVKpavGdCSFIBLusDfHxQ =mNnWwAyEzrVKpavGdCSFIBLusDfHMo.get('title')
   mNnWwAyEzrVKpavGdCSFIBLusDfHtU =mNnWwAyEzrVKpavGdCSFIBLusDfHMo.get('subtitle')
   mNnWwAyEzrVKpavGdCSFIBLusDfHtM={'mediatype':'episode','title':mNnWwAyEzrVKpavGdCSFIBLusDfHxQ,'plot':'%s\n%s'%(mNnWwAyEzrVKpavGdCSFIBLusDfHxQ,mNnWwAyEzrVKpavGdCSFIBLusDfHtU)}
   mNnWwAyEzrVKpavGdCSFIBLusDfHxO={'mode':'LIVE','mediacode':mNnWwAyEzrVKpavGdCSFIBLusDfHMo.get('channel'),'stype':'onair',}
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.add_dir(mNnWwAyEzrVKpavGdCSFIBLusDfHxQ,sublabel=mNnWwAyEzrVKpavGdCSFIBLusDfHtU,img='',infoLabels=mNnWwAyEzrVKpavGdCSFIBLusDfHtM,isFolder=mNnWwAyEzrVKpavGdCSFIBLusDfHkh,params=mNnWwAyEzrVKpavGdCSFIBLusDfHxO)
  if mNnWwAyEzrVKpavGdCSFIBLusDfHkQ(mNnWwAyEzrVKpavGdCSFIBLusDfHMR)>0:xbmcplugin.endOfDirectory(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ._addon_handle,cacheToDisc=mNnWwAyEzrVKpavGdCSFIBLusDfHkh)
 def tving_main(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ):
  mNnWwAyEzrVKpavGdCSFIBLusDfHUR=mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.main_params.get('mode',mNnWwAyEzrVKpavGdCSFIBLusDfHkU)
  if mNnWwAyEzrVKpavGdCSFIBLusDfHUR=='LOGOUT':
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.logout()
   return
  mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.login_main()
  if mNnWwAyEzrVKpavGdCSFIBLusDfHUR is mNnWwAyEzrVKpavGdCSFIBLusDfHkU:
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.dp_Main_List()
  elif mNnWwAyEzrVKpavGdCSFIBLusDfHUR in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.dp_Title_Group(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.main_params)
  elif mNnWwAyEzrVKpavGdCSFIBLusDfHUR in['GLOBAL_GROUP']:
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.dp_SubTitle_Group(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.main_params)
  elif mNnWwAyEzrVKpavGdCSFIBLusDfHUR=='CHANNEL':
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.dp_LiveChannel_List(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.main_params)
  elif mNnWwAyEzrVKpavGdCSFIBLusDfHUR in['LIVE','VOD','MOVIE']:
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.play_VIDEO(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.main_params)
  elif mNnWwAyEzrVKpavGdCSFIBLusDfHUR=='PROGRAM':
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.dp_Program_List(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.main_params)
  elif mNnWwAyEzrVKpavGdCSFIBLusDfHUR=='EPISODE':
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.dp_Episode_List(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.main_params)
  elif mNnWwAyEzrVKpavGdCSFIBLusDfHUR=='MOVIE_SUB':
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.dp_Movie_List(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.main_params)
  elif mNnWwAyEzrVKpavGdCSFIBLusDfHUR=='SEARCH_GROUP':
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.dp_Search_Group(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.main_params)
  elif mNnWwAyEzrVKpavGdCSFIBLusDfHUR in['SEARCH','LOCAL_SEARCH']:
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.dp_Search_List(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.main_params)
  elif mNnWwAyEzrVKpavGdCSFIBLusDfHUR=='WATCH':
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.dp_Watch_List(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.main_params)
  elif mNnWwAyEzrVKpavGdCSFIBLusDfHUR in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.dp_Listfile_Delete(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.main_params)
  elif mNnWwAyEzrVKpavGdCSFIBLusDfHUR=='ORDER_BY':
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.dp_setEpOrderby(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.main_params)
  elif mNnWwAyEzrVKpavGdCSFIBLusDfHUR=='SET_BOOKMARK':
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.dp_Set_Bookmark(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.main_params)
  elif mNnWwAyEzrVKpavGdCSFIBLusDfHUR in['TOTAL_SEARCH','TOTAL_HISTORY']:
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.dp_Global_Search(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.main_params)
  elif mNnWwAyEzrVKpavGdCSFIBLusDfHUR=='SEARCH_HISTORY':
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.dp_Search_History(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.main_params)
  elif mNnWwAyEzrVKpavGdCSFIBLusDfHUR=='MENU_BOOKMARK':
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.dp_Bookmark_Menu(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.main_params)
  elif mNnWwAyEzrVKpavGdCSFIBLusDfHUR=='EURO_GROUP':
   mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.dp_EuroLive_List(mNnWwAyEzrVKpavGdCSFIBLusDfHlQ.main_params)
  else:
   mNnWwAyEzrVKpavGdCSFIBLusDfHkU
# Created by pyminifier (https://github.com/liftoff/pyminifier)
