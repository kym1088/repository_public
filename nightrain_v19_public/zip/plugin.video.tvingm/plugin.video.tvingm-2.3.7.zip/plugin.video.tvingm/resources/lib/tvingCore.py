__author__="NightRain"
rqEOkyTmjKVciBDNIQMRxuvhldtJLa=object
rqEOkyTmjKVciBDNIQMRxuvhldtJLf=None
rqEOkyTmjKVciBDNIQMRxuvhldtJLP=False
rqEOkyTmjKVciBDNIQMRxuvhldtJLA=int
rqEOkyTmjKVciBDNIQMRxuvhldtJLS=range
rqEOkyTmjKVciBDNIQMRxuvhldtJLW=True
rqEOkyTmjKVciBDNIQMRxuvhldtJLC=Exception
rqEOkyTmjKVciBDNIQMRxuvhldtJLw=print
rqEOkyTmjKVciBDNIQMRxuvhldtJLs=str
rqEOkyTmjKVciBDNIQMRxuvhldtJLg=list
rqEOkyTmjKVciBDNIQMRxuvhldtJLF=len
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
rqEOkyTmjKVciBDNIQMRxuvhldtJUH={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
rqEOkyTmjKVciBDNIQMRxuvhldtJUo ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
class rqEOkyTmjKVciBDNIQMRxuvhldtJUY(rqEOkyTmjKVciBDNIQMRxuvhldtJLa):
 def __init__(rqEOkyTmjKVciBDNIQMRxuvhldtJUX):
  rqEOkyTmjKVciBDNIQMRxuvhldtJUX.TVING_TOKEN =''
  rqEOkyTmjKVciBDNIQMRxuvhldtJUX.POC_USERINFO =''
  rqEOkyTmjKVciBDNIQMRxuvhldtJUX.TVING_UUID ='-'
  rqEOkyTmjKVciBDNIQMRxuvhldtJUX.TVING_MAINTOKEN=''
  rqEOkyTmjKVciBDNIQMRxuvhldtJUX.TVIGN_COOKIEKEY=''
  rqEOkyTmjKVciBDNIQMRxuvhldtJUX.TVING_LOCKKEY =''
  rqEOkyTmjKVciBDNIQMRxuvhldtJUX.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  rqEOkyTmjKVciBDNIQMRxuvhldtJUX.NETWORKCODE ='CSND0900'
  rqEOkyTmjKVciBDNIQMRxuvhldtJUX.OSCODE ='CSOD0900' 
  rqEOkyTmjKVciBDNIQMRxuvhldtJUX.TELECODE ='CSCD0900'
  rqEOkyTmjKVciBDNIQMRxuvhldtJUX.SCREENCODE ='CSSD0100'
  rqEOkyTmjKVciBDNIQMRxuvhldtJUX.LIVE_LIMIT =23
  rqEOkyTmjKVciBDNIQMRxuvhldtJUX.VOD_LIMIT =20
  rqEOkyTmjKVciBDNIQMRxuvhldtJUX.EPISODE_LIMIT =30 
  rqEOkyTmjKVciBDNIQMRxuvhldtJUX.SEARCH_LIMIT =30 
  rqEOkyTmjKVciBDNIQMRxuvhldtJUX.MOVIE_LIMIT =18
  rqEOkyTmjKVciBDNIQMRxuvhldtJUX.API_DOMAIN ='https://api.tving.com'
  rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN ='https://image.tving.com'
  rqEOkyTmjKVciBDNIQMRxuvhldtJUX.SEARCH_DOMAIN ='https://search.tving.com'
  rqEOkyTmjKVciBDNIQMRxuvhldtJUX.LOGIN_DOMAIN ='https://user.tving.com'
  rqEOkyTmjKVciBDNIQMRxuvhldtJUX.URL_DOMAIN ='https://www.tving.com'
  rqEOkyTmjKVciBDNIQMRxuvhldtJUX.MOVIE_LITE =['2610061','2610161','261062']
  rqEOkyTmjKVciBDNIQMRxuvhldtJUX.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  rqEOkyTmjKVciBDNIQMRxuvhldtJUX.DEFAULT_HEADER ={'user-agent':rqEOkyTmjKVciBDNIQMRxuvhldtJUX.USER_AGENT}
  rqEOkyTmjKVciBDNIQMRxuvhldtJUX.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
 def callRequestCookies(rqEOkyTmjKVciBDNIQMRxuvhldtJUX,jobtype,rqEOkyTmjKVciBDNIQMRxuvhldtJYS,payload=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,params=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,headers=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,cookies=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,redirects=rqEOkyTmjKVciBDNIQMRxuvhldtJLP):
  rqEOkyTmjKVciBDNIQMRxuvhldtJUL=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.DEFAULT_HEADER
  if headers:rqEOkyTmjKVciBDNIQMRxuvhldtJUL.update(headers)
  if jobtype=='Get':
   rqEOkyTmjKVciBDNIQMRxuvhldtJUG=requests.get(rqEOkyTmjKVciBDNIQMRxuvhldtJYS,params=params,headers=rqEOkyTmjKVciBDNIQMRxuvhldtJUL,cookies=cookies,allow_redirects=redirects)
  else:
   rqEOkyTmjKVciBDNIQMRxuvhldtJUG=requests.post(rqEOkyTmjKVciBDNIQMRxuvhldtJYS,data=payload,params=params,headers=rqEOkyTmjKVciBDNIQMRxuvhldtJUL,cookies=cookies,allow_redirects=redirects)
  return rqEOkyTmjKVciBDNIQMRxuvhldtJUG
 def makeDefaultCookies(rqEOkyTmjKVciBDNIQMRxuvhldtJUX,vToken=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,vUserinfo=rqEOkyTmjKVciBDNIQMRxuvhldtJLf):
  rqEOkyTmjKVciBDNIQMRxuvhldtJUz={}
  rqEOkyTmjKVciBDNIQMRxuvhldtJUz['_tving_token']=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.TVING_TOKEN if vToken==rqEOkyTmjKVciBDNIQMRxuvhldtJLf else vToken
  rqEOkyTmjKVciBDNIQMRxuvhldtJUz['POC_USERINFO']=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.POC_USERINFO if vToken==rqEOkyTmjKVciBDNIQMRxuvhldtJLf else vUserinfo
  if rqEOkyTmjKVciBDNIQMRxuvhldtJUX.TVING_MAINTOKEN!='':rqEOkyTmjKVciBDNIQMRxuvhldtJUz[rqEOkyTmjKVciBDNIQMRxuvhldtJUX.GLOBAL_COOKIENM['tv_maintoken']]=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.TVING_MAINTOKEN
  if rqEOkyTmjKVciBDNIQMRxuvhldtJUX.TVIGN_COOKIEKEY!='':rqEOkyTmjKVciBDNIQMRxuvhldtJUz[rqEOkyTmjKVciBDNIQMRxuvhldtJUX.GLOBAL_COOKIENM['tv_cookiekey']]=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.TVIGN_COOKIEKEY
  if rqEOkyTmjKVciBDNIQMRxuvhldtJUX.TVING_LOCKKEY !='':rqEOkyTmjKVciBDNIQMRxuvhldtJUz[rqEOkyTmjKVciBDNIQMRxuvhldtJUX.GLOBAL_COOKIENM['tv_lockkey']] =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.TVING_LOCKKEY
  return rqEOkyTmjKVciBDNIQMRxuvhldtJUz
 def getDeviceStr(rqEOkyTmjKVciBDNIQMRxuvhldtJUX):
  rqEOkyTmjKVciBDNIQMRxuvhldtJUp=[]
  rqEOkyTmjKVciBDNIQMRxuvhldtJUp.append('Windows') 
  rqEOkyTmjKVciBDNIQMRxuvhldtJUp.append('Chrome') 
  rqEOkyTmjKVciBDNIQMRxuvhldtJUp.append('ko-KR') 
  rqEOkyTmjKVciBDNIQMRxuvhldtJUp.append('undefined') 
  rqEOkyTmjKVciBDNIQMRxuvhldtJUp.append('24') 
  rqEOkyTmjKVciBDNIQMRxuvhldtJUp.append(u'한국 표준시')
  rqEOkyTmjKVciBDNIQMRxuvhldtJUp.append('undefined') 
  rqEOkyTmjKVciBDNIQMRxuvhldtJUp.append('undefined') 
  rqEOkyTmjKVciBDNIQMRxuvhldtJUp.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  rqEOkyTmjKVciBDNIQMRxuvhldtJUa=''
  for rqEOkyTmjKVciBDNIQMRxuvhldtJUf in rqEOkyTmjKVciBDNIQMRxuvhldtJUp:
   rqEOkyTmjKVciBDNIQMRxuvhldtJUa+=rqEOkyTmjKVciBDNIQMRxuvhldtJUf+'|'
  return rqEOkyTmjKVciBDNIQMRxuvhldtJUa
 def SaveCredential(rqEOkyTmjKVciBDNIQMRxuvhldtJUX,rqEOkyTmjKVciBDNIQMRxuvhldtJUP):
  rqEOkyTmjKVciBDNIQMRxuvhldtJUX.TVING_TOKEN =rqEOkyTmjKVciBDNIQMRxuvhldtJUP.get('tving_token')
  rqEOkyTmjKVciBDNIQMRxuvhldtJUX.POC_USERINFO =rqEOkyTmjKVciBDNIQMRxuvhldtJUP.get('poc_userinfo')
  rqEOkyTmjKVciBDNIQMRxuvhldtJUX.TVING_UUID =rqEOkyTmjKVciBDNIQMRxuvhldtJUP.get('tving_uuid')
  rqEOkyTmjKVciBDNIQMRxuvhldtJUX.TVING_MAINTOKEN=rqEOkyTmjKVciBDNIQMRxuvhldtJUP.get('tving_maintoken')
  rqEOkyTmjKVciBDNIQMRxuvhldtJUX.TVIGN_COOKIEKEY=rqEOkyTmjKVciBDNIQMRxuvhldtJUP.get('tving_cookiekey')
  rqEOkyTmjKVciBDNIQMRxuvhldtJUX.TVING_LOCKKEY =rqEOkyTmjKVciBDNIQMRxuvhldtJUP.get('tving_lockkey')
 def LoadCredential(rqEOkyTmjKVciBDNIQMRxuvhldtJUX):
  rqEOkyTmjKVciBDNIQMRxuvhldtJUP={'tving_token':rqEOkyTmjKVciBDNIQMRxuvhldtJUX.TVING_TOKEN,'poc_userinfo':rqEOkyTmjKVciBDNIQMRxuvhldtJUX.POC_USERINFO,'tving_uuid':rqEOkyTmjKVciBDNIQMRxuvhldtJUX.TVING_UUID,'tving_maintoken':rqEOkyTmjKVciBDNIQMRxuvhldtJUX.TVING_MAINTOKEN,'tving_cookiekey':rqEOkyTmjKVciBDNIQMRxuvhldtJUX.TVIGN_COOKIEKEY,'tving_lockkey':rqEOkyTmjKVciBDNIQMRxuvhldtJUX.TVING_LOCKKEY}
  return rqEOkyTmjKVciBDNIQMRxuvhldtJUP
 def GetDefaultParams(rqEOkyTmjKVciBDNIQMRxuvhldtJUX):
  rqEOkyTmjKVciBDNIQMRxuvhldtJUA={'apiKey':rqEOkyTmjKVciBDNIQMRxuvhldtJUX.APIKEY,'networkCode':rqEOkyTmjKVciBDNIQMRxuvhldtJUX.NETWORKCODE,'osCode':rqEOkyTmjKVciBDNIQMRxuvhldtJUX.OSCODE,'teleCode':rqEOkyTmjKVciBDNIQMRxuvhldtJUX.TELECODE,'screenCode':rqEOkyTmjKVciBDNIQMRxuvhldtJUX.SCREENCODE}
  return rqEOkyTmjKVciBDNIQMRxuvhldtJUA
 def GetNoCache(rqEOkyTmjKVciBDNIQMRxuvhldtJUX,timetype=1):
  if timetype==1:
   return rqEOkyTmjKVciBDNIQMRxuvhldtJLA(time.time())
  else:
   return rqEOkyTmjKVciBDNIQMRxuvhldtJLA(time.time()*1000)
 def GetUniqueid(rqEOkyTmjKVciBDNIQMRxuvhldtJUX):
  rqEOkyTmjKVciBDNIQMRxuvhldtJUS=[0 for i in rqEOkyTmjKVciBDNIQMRxuvhldtJLS(256)]
  for i in rqEOkyTmjKVciBDNIQMRxuvhldtJLS(256):
   rqEOkyTmjKVciBDNIQMRxuvhldtJUS[i]='%02x'%(i)
  rqEOkyTmjKVciBDNIQMRxuvhldtJUW=rqEOkyTmjKVciBDNIQMRxuvhldtJLA(4294967295*random.random())|0
  rqEOkyTmjKVciBDNIQMRxuvhldtJUC=rqEOkyTmjKVciBDNIQMRxuvhldtJUS[255&rqEOkyTmjKVciBDNIQMRxuvhldtJUW]+rqEOkyTmjKVciBDNIQMRxuvhldtJUS[rqEOkyTmjKVciBDNIQMRxuvhldtJUW>>8&255]+rqEOkyTmjKVciBDNIQMRxuvhldtJUS[rqEOkyTmjKVciBDNIQMRxuvhldtJUW>>16&255]+rqEOkyTmjKVciBDNIQMRxuvhldtJUS[rqEOkyTmjKVciBDNIQMRxuvhldtJUW>>24&255]
  return rqEOkyTmjKVciBDNIQMRxuvhldtJUC
 def GetCredential(rqEOkyTmjKVciBDNIQMRxuvhldtJUX,user_id,user_pw,login_type,user_pf):
  rqEOkyTmjKVciBDNIQMRxuvhldtJUw=rqEOkyTmjKVciBDNIQMRxuvhldtJLP
  rqEOkyTmjKVciBDNIQMRxuvhldtJUs=rqEOkyTmjKVciBDNIQMRxuvhldtJYU=rqEOkyTmjKVciBDNIQMRxuvhldtJYH=rqEOkyTmjKVciBDNIQMRxuvhldtJYo=rqEOkyTmjKVciBDNIQMRxuvhldtJYX='' 
  rqEOkyTmjKVciBDNIQMRxuvhldtJUg ='-'
  try:
   rqEOkyTmjKVciBDNIQMRxuvhldtJUF=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   rqEOkyTmjKVciBDNIQMRxuvhldtJUb={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com/main.do','csite':''}
   rqEOkyTmjKVciBDNIQMRxuvhldtJUe=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.callRequestCookies('Post',rqEOkyTmjKVciBDNIQMRxuvhldtJUF,payload=rqEOkyTmjKVciBDNIQMRxuvhldtJUb,params=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,headers=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,cookies=rqEOkyTmjKVciBDNIQMRxuvhldtJLf)
   for rqEOkyTmjKVciBDNIQMRxuvhldtJUn in rqEOkyTmjKVciBDNIQMRxuvhldtJUe.cookies:
    if rqEOkyTmjKVciBDNIQMRxuvhldtJUn.name=='_tving_token':
     rqEOkyTmjKVciBDNIQMRxuvhldtJYU=rqEOkyTmjKVciBDNIQMRxuvhldtJUn.value
    elif rqEOkyTmjKVciBDNIQMRxuvhldtJUn.name=='POC_USERINFO':
     rqEOkyTmjKVciBDNIQMRxuvhldtJYH=rqEOkyTmjKVciBDNIQMRxuvhldtJUn.value
   if rqEOkyTmjKVciBDNIQMRxuvhldtJYU=='':return rqEOkyTmjKVciBDNIQMRxuvhldtJUw
   rqEOkyTmjKVciBDNIQMRxuvhldtJUs=rqEOkyTmjKVciBDNIQMRxuvhldtJYU
   rqEOkyTmjKVciBDNIQMRxuvhldtJYU,rqEOkyTmjKVciBDNIQMRxuvhldtJYo,rqEOkyTmjKVciBDNIQMRxuvhldtJYX=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.GetProfileToken(rqEOkyTmjKVciBDNIQMRxuvhldtJYU,rqEOkyTmjKVciBDNIQMRxuvhldtJYH,user_pf)
   rqEOkyTmjKVciBDNIQMRxuvhldtJUw=rqEOkyTmjKVciBDNIQMRxuvhldtJLW
   rqEOkyTmjKVciBDNIQMRxuvhldtJUg =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.GetDeviceList(rqEOkyTmjKVciBDNIQMRxuvhldtJYU,rqEOkyTmjKVciBDNIQMRxuvhldtJYH)
   rqEOkyTmjKVciBDNIQMRxuvhldtJUg =rqEOkyTmjKVciBDNIQMRxuvhldtJUg+'-'+rqEOkyTmjKVciBDNIQMRxuvhldtJUX.GetUniqueid()
  except rqEOkyTmjKVciBDNIQMRxuvhldtJLC as exception:
   rqEOkyTmjKVciBDNIQMRxuvhldtJUs=rqEOkyTmjKVciBDNIQMRxuvhldtJYU=rqEOkyTmjKVciBDNIQMRxuvhldtJYH=rqEOkyTmjKVciBDNIQMRxuvhldtJYo=rqEOkyTmjKVciBDNIQMRxuvhldtJYX=''
   rqEOkyTmjKVciBDNIQMRxuvhldtJUg='-'
   rqEOkyTmjKVciBDNIQMRxuvhldtJLw(exception)
  rqEOkyTmjKVciBDNIQMRxuvhldtJUP={'tving_token':rqEOkyTmjKVciBDNIQMRxuvhldtJYU,'poc_userinfo':rqEOkyTmjKVciBDNIQMRxuvhldtJYH,'tving_uuid':rqEOkyTmjKVciBDNIQMRxuvhldtJUg,'tving_maintoken':rqEOkyTmjKVciBDNIQMRxuvhldtJUs,'tving_cookiekey':rqEOkyTmjKVciBDNIQMRxuvhldtJYo,'tving_lockkey':rqEOkyTmjKVciBDNIQMRxuvhldtJYX}
  rqEOkyTmjKVciBDNIQMRxuvhldtJUX.SaveCredential(rqEOkyTmjKVciBDNIQMRxuvhldtJUP)
  return rqEOkyTmjKVciBDNIQMRxuvhldtJUw
 def Get_Now_Datetime(rqEOkyTmjKVciBDNIQMRxuvhldtJUX):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(rqEOkyTmjKVciBDNIQMRxuvhldtJUX,mediacode,sel_quality,stype,pvrmode='-'):
  rqEOkyTmjKVciBDNIQMRxuvhldtJYG=''
  rqEOkyTmjKVciBDNIQMRxuvhldtJYz=''
  rqEOkyTmjKVciBDNIQMRxuvhldtJYp =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.TVING_UUID.split('-')[0] 
  rqEOkyTmjKVciBDNIQMRxuvhldtJYa =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.TVING_UUID 
  try:
   if stype!='tvingtv' and(pvrmode=='-' or stype!='onair'):
    rqEOkyTmjKVciBDNIQMRxuvhldtJYf ='/v2a/media/stream/info' 
    rqEOkyTmjKVciBDNIQMRxuvhldtJYP=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.GetDefaultParams()
    rqEOkyTmjKVciBDNIQMRxuvhldtJYA={'info':'Y','mediaCode':mediacode,'noCache':rqEOkyTmjKVciBDNIQMRxuvhldtJLs(rqEOkyTmjKVciBDNIQMRxuvhldtJUX.GetNoCache(1)),'callingFrom':'HTML5','adReq':'adproxy','ooc':'','deviceId':rqEOkyTmjKVciBDNIQMRxuvhldtJYp,'uuid':rqEOkyTmjKVciBDNIQMRxuvhldtJYa,'deviceInfo':'PC','wm':'Y'}
    rqEOkyTmjKVciBDNIQMRxuvhldtJYP.update(rqEOkyTmjKVciBDNIQMRxuvhldtJYA)
    rqEOkyTmjKVciBDNIQMRxuvhldtJYS=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.API_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJYf
    rqEOkyTmjKVciBDNIQMRxuvhldtJUz=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.makeDefaultCookies()
    rqEOkyTmjKVciBDNIQMRxuvhldtJUe=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.callRequestCookies('Get',rqEOkyTmjKVciBDNIQMRxuvhldtJYS,payload=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,params=rqEOkyTmjKVciBDNIQMRxuvhldtJYP,headers=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,cookies=rqEOkyTmjKVciBDNIQMRxuvhldtJUz)
    if rqEOkyTmjKVciBDNIQMRxuvhldtJUe.status_code!=200:return rqEOkyTmjKVciBDNIQMRxuvhldtJYG,rqEOkyTmjKVciBDNIQMRxuvhldtJYz
    rqEOkyTmjKVciBDNIQMRxuvhldtJYW=json.loads(rqEOkyTmjKVciBDNIQMRxuvhldtJUe.text)
    if rqEOkyTmjKVciBDNIQMRxuvhldtJYW['body']['result']['code']!='000':
     rqEOkyTmjKVciBDNIQMRxuvhldtJYz=rqEOkyTmjKVciBDNIQMRxuvhldtJYW['body']['result']['message']
     return rqEOkyTmjKVciBDNIQMRxuvhldtJYG,rqEOkyTmjKVciBDNIQMRxuvhldtJYz
    if not('stream' in rqEOkyTmjKVciBDNIQMRxuvhldtJYW['body']):return rqEOkyTmjKVciBDNIQMRxuvhldtJYG,rqEOkyTmjKVciBDNIQMRxuvhldtJYz 
    rqEOkyTmjKVciBDNIQMRxuvhldtJYC=rqEOkyTmjKVciBDNIQMRxuvhldtJYW['body']['stream']
    rqEOkyTmjKVciBDNIQMRxuvhldtJYw=rqEOkyTmjKVciBDNIQMRxuvhldtJYC['quality']
    rqEOkyTmjKVciBDNIQMRxuvhldtJYs=[]
    for rqEOkyTmjKVciBDNIQMRxuvhldtJYg in rqEOkyTmjKVciBDNIQMRxuvhldtJYw:
     if rqEOkyTmjKVciBDNIQMRxuvhldtJYg['active']=='Y':
      rqEOkyTmjKVciBDNIQMRxuvhldtJYs.append({rqEOkyTmjKVciBDNIQMRxuvhldtJUH.get(rqEOkyTmjKVciBDNIQMRxuvhldtJYg['code']):rqEOkyTmjKVciBDNIQMRxuvhldtJYg['code']})
    rqEOkyTmjKVciBDNIQMRxuvhldtJYF=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.CheckQuality(sel_quality,rqEOkyTmjKVciBDNIQMRxuvhldtJYs)
   else:
    for rqEOkyTmjKVciBDNIQMRxuvhldtJYb,rqEOkyTmjKVciBDNIQMRxuvhldtJHG in rqEOkyTmjKVciBDNIQMRxuvhldtJUH.items():
     if rqEOkyTmjKVciBDNIQMRxuvhldtJHG==sel_quality:
      rqEOkyTmjKVciBDNIQMRxuvhldtJYF=rqEOkyTmjKVciBDNIQMRxuvhldtJYb
  except rqEOkyTmjKVciBDNIQMRxuvhldtJLC as exception:
   rqEOkyTmjKVciBDNIQMRxuvhldtJLw(exception)
   for rqEOkyTmjKVciBDNIQMRxuvhldtJYb,rqEOkyTmjKVciBDNIQMRxuvhldtJHG in rqEOkyTmjKVciBDNIQMRxuvhldtJUH.items():
    if rqEOkyTmjKVciBDNIQMRxuvhldtJHG==sel_quality:
     rqEOkyTmjKVciBDNIQMRxuvhldtJYF=rqEOkyTmjKVciBDNIQMRxuvhldtJYb
   return rqEOkyTmjKVciBDNIQMRxuvhldtJYG,rqEOkyTmjKVciBDNIQMRxuvhldtJYz
  rqEOkyTmjKVciBDNIQMRxuvhldtJLw(rqEOkyTmjKVciBDNIQMRxuvhldtJYF)
  try:
   rqEOkyTmjKVciBDNIQMRxuvhldtJYf ='/streaming/info'
   rqEOkyTmjKVciBDNIQMRxuvhldtJYP=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.GetDefaultParams()
   if stype=='onair':rqEOkyTmjKVciBDNIQMRxuvhldtJYP['osCode']='CSOD0400' 
   rqEOkyTmjKVciBDNIQMRxuvhldtJYe={'isTrusted':'false','NONE':'0','CAPTURING_PHASE':'1','AT_TARGET':'2','BUBBLING_PHASE':'3','type':'oocCreate','eventPhase':'0','bubbles':'false','cancelable':'false','defaultPrevented':'false','composed':'false','timeStamp':'2785.9800000005635','returnValue':'true','cancelBubble':'false'}
   rqEOkyTmjKVciBDNIQMRxuvhldtJYn=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.makeOocUrl(rqEOkyTmjKVciBDNIQMRxuvhldtJYe)
   rqEOkyTmjKVciBDNIQMRxuvhldtJHU=urllib.parse.quote(rqEOkyTmjKVciBDNIQMRxuvhldtJYn)
   rqEOkyTmjKVciBDNIQMRxuvhldtJYA={'info':'Y','mediaCode':mediacode,'callingFrom':'HTML5','streamCode':rqEOkyTmjKVciBDNIQMRxuvhldtJYF,'adReq':'adproxy','ooc':rqEOkyTmjKVciBDNIQMRxuvhldtJYn,'deviceId':rqEOkyTmjKVciBDNIQMRxuvhldtJYp,'uuid':rqEOkyTmjKVciBDNIQMRxuvhldtJYa,'deviceInfo':'PC'}
   rqEOkyTmjKVciBDNIQMRxuvhldtJHY =rqEOkyTmjKVciBDNIQMRxuvhldtJYP
   rqEOkyTmjKVciBDNIQMRxuvhldtJHY.update(rqEOkyTmjKVciBDNIQMRxuvhldtJYA)
   rqEOkyTmjKVciBDNIQMRxuvhldtJYS=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.URL_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJYf
   rqEOkyTmjKVciBDNIQMRxuvhldtJHo={'origin':'https://www.tving.com'}
   if stype=='onair':rqEOkyTmjKVciBDNIQMRxuvhldtJHo['Referer']='https://www.tving.com/live/player/'+mediacode
   else: rqEOkyTmjKVciBDNIQMRxuvhldtJHo['Referer']='https://www.tving.com/vod/player/'+mediacode
   rqEOkyTmjKVciBDNIQMRxuvhldtJUz=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.makeDefaultCookies()
   rqEOkyTmjKVciBDNIQMRxuvhldtJUz['onClickEvent2']=rqEOkyTmjKVciBDNIQMRxuvhldtJHU
   rqEOkyTmjKVciBDNIQMRxuvhldtJUe=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.callRequestCookies('Post',rqEOkyTmjKVciBDNIQMRxuvhldtJYS,payload=rqEOkyTmjKVciBDNIQMRxuvhldtJHY,params=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,headers=rqEOkyTmjKVciBDNIQMRxuvhldtJHo,cookies=rqEOkyTmjKVciBDNIQMRxuvhldtJUz,redirects=rqEOkyTmjKVciBDNIQMRxuvhldtJLP)
   rqEOkyTmjKVciBDNIQMRxuvhldtJYW=json.loads(rqEOkyTmjKVciBDNIQMRxuvhldtJUe.text)
   if 'drm_license_assertion' in rqEOkyTmjKVciBDNIQMRxuvhldtJYW['stream']:
    rqEOkyTmjKVciBDNIQMRxuvhldtJYz =rqEOkyTmjKVciBDNIQMRxuvhldtJYW['stream']['drm_license_assertion']
    rqEOkyTmjKVciBDNIQMRxuvhldtJYG=rqEOkyTmjKVciBDNIQMRxuvhldtJYW['stream']['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in rqEOkyTmjKVciBDNIQMRxuvhldtJYW['stream']['broadcast']):return rqEOkyTmjKVciBDNIQMRxuvhldtJYG,rqEOkyTmjKVciBDNIQMRxuvhldtJYz
    rqEOkyTmjKVciBDNIQMRxuvhldtJYG=rqEOkyTmjKVciBDNIQMRxuvhldtJYW['stream']['broadcast']['broad_url']
  except rqEOkyTmjKVciBDNIQMRxuvhldtJLC as exception:
   rqEOkyTmjKVciBDNIQMRxuvhldtJLw(exception)
  return rqEOkyTmjKVciBDNIQMRxuvhldtJYG,rqEOkyTmjKVciBDNIQMRxuvhldtJYz
 def CheckQuality(rqEOkyTmjKVciBDNIQMRxuvhldtJUX,sel_qt,rqEOkyTmjKVciBDNIQMRxuvhldtJYs):
  for rqEOkyTmjKVciBDNIQMRxuvhldtJHX in rqEOkyTmjKVciBDNIQMRxuvhldtJYs:
   if sel_qt>=rqEOkyTmjKVciBDNIQMRxuvhldtJLg(rqEOkyTmjKVciBDNIQMRxuvhldtJHX)[0]:return rqEOkyTmjKVciBDNIQMRxuvhldtJHX.get(rqEOkyTmjKVciBDNIQMRxuvhldtJLg(rqEOkyTmjKVciBDNIQMRxuvhldtJHX)[0])
   rqEOkyTmjKVciBDNIQMRxuvhldtJHL=rqEOkyTmjKVciBDNIQMRxuvhldtJHX.get(rqEOkyTmjKVciBDNIQMRxuvhldtJLg(rqEOkyTmjKVciBDNIQMRxuvhldtJHX)[0])
  return rqEOkyTmjKVciBDNIQMRxuvhldtJHL
 def makeOocUrl(rqEOkyTmjKVciBDNIQMRxuvhldtJUX,rqEOkyTmjKVciBDNIQMRxuvhldtJYe):
  rqEOkyTmjKVciBDNIQMRxuvhldtJYS=''
  for rqEOkyTmjKVciBDNIQMRxuvhldtJYb,rqEOkyTmjKVciBDNIQMRxuvhldtJHG in rqEOkyTmjKVciBDNIQMRxuvhldtJYe.items():
   rqEOkyTmjKVciBDNIQMRxuvhldtJYS+="%s=%s^"%(rqEOkyTmjKVciBDNIQMRxuvhldtJYb,rqEOkyTmjKVciBDNIQMRxuvhldtJHG)
  return rqEOkyTmjKVciBDNIQMRxuvhldtJYS
 def GetLiveChannelList(rqEOkyTmjKVciBDNIQMRxuvhldtJUX,stype,page_int):
  rqEOkyTmjKVciBDNIQMRxuvhldtJHz=[]
  rqEOkyTmjKVciBDNIQMRxuvhldtJHp=rqEOkyTmjKVciBDNIQMRxuvhldtJLP
  rqEOkyTmjKVciBDNIQMRxuvhldtJHa=rqEOkyTmjKVciBDNIQMRxuvhldtJLP
  try:
   rqEOkyTmjKVciBDNIQMRxuvhldtJYf ='/v2/media/lives'
   if stype=='onair': 
    rqEOkyTmjKVciBDNIQMRxuvhldtJHf='CPCS0100,CPCS0400'
   else:
    rqEOkyTmjKVciBDNIQMRxuvhldtJHf='CPCS0300'
   rqEOkyTmjKVciBDNIQMRxuvhldtJYP=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.GetDefaultParams()
   rqEOkyTmjKVciBDNIQMRxuvhldtJYA={'pageNo':rqEOkyTmjKVciBDNIQMRxuvhldtJLs(page_int),'pageSize':rqEOkyTmjKVciBDNIQMRxuvhldtJLs(rqEOkyTmjKVciBDNIQMRxuvhldtJUX.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':rqEOkyTmjKVciBDNIQMRxuvhldtJHf,'_':rqEOkyTmjKVciBDNIQMRxuvhldtJLs(rqEOkyTmjKVciBDNIQMRxuvhldtJUX.GetNoCache(2))}
   rqEOkyTmjKVciBDNIQMRxuvhldtJYP.update(rqEOkyTmjKVciBDNIQMRxuvhldtJYA)
   rqEOkyTmjKVciBDNIQMRxuvhldtJYS=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.API_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJYf
   rqEOkyTmjKVciBDNIQMRxuvhldtJUe=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.callRequestCookies('Get',rqEOkyTmjKVciBDNIQMRxuvhldtJYS,payload=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,params=rqEOkyTmjKVciBDNIQMRxuvhldtJYP,headers=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,cookies=rqEOkyTmjKVciBDNIQMRxuvhldtJLf)
   rqEOkyTmjKVciBDNIQMRxuvhldtJYW=json.loads(rqEOkyTmjKVciBDNIQMRxuvhldtJUe.text)
   if not('result' in rqEOkyTmjKVciBDNIQMRxuvhldtJYW['body']):return rqEOkyTmjKVciBDNIQMRxuvhldtJHz,rqEOkyTmjKVciBDNIQMRxuvhldtJHp
   rqEOkyTmjKVciBDNIQMRxuvhldtJHP=rqEOkyTmjKVciBDNIQMRxuvhldtJYW['body']['result']
   for rqEOkyTmjKVciBDNIQMRxuvhldtJYg in rqEOkyTmjKVciBDNIQMRxuvhldtJHP:
    rqEOkyTmjKVciBDNIQMRxuvhldtJHA=rqEOkyTmjKVciBDNIQMRxuvhldtJHC=rqEOkyTmjKVciBDNIQMRxuvhldtJHw=''
    rqEOkyTmjKVciBDNIQMRxuvhldtJHS=rqEOkyTmjKVciBDNIQMRxuvhldtJoP=''
    rqEOkyTmjKVciBDNIQMRxuvhldtJHW=rqEOkyTmjKVciBDNIQMRxuvhldtJYg['live_code']
    if rqEOkyTmjKVciBDNIQMRxuvhldtJHW=='C01345':rqEOkyTmjKVciBDNIQMRxuvhldtJHa=rqEOkyTmjKVciBDNIQMRxuvhldtJLW 
    rqEOkyTmjKVciBDNIQMRxuvhldtJHA =rqEOkyTmjKVciBDNIQMRxuvhldtJYg['schedule']['channel']['name']['ko']
    if rqEOkyTmjKVciBDNIQMRxuvhldtJYg['schedule']['episode']!=rqEOkyTmjKVciBDNIQMRxuvhldtJLf:
     rqEOkyTmjKVciBDNIQMRxuvhldtJHC =rqEOkyTmjKVciBDNIQMRxuvhldtJYg['schedule']['program']['name']['ko']
     rqEOkyTmjKVciBDNIQMRxuvhldtJHC =rqEOkyTmjKVciBDNIQMRxuvhldtJHC+', '+rqEOkyTmjKVciBDNIQMRxuvhldtJLs(rqEOkyTmjKVciBDNIQMRxuvhldtJYg['schedule']['episode']['frequency'])+'회'
     rqEOkyTmjKVciBDNIQMRxuvhldtJHw=rqEOkyTmjKVciBDNIQMRxuvhldtJYg['schedule']['episode']['synopsis']['ko']
    else:
     rqEOkyTmjKVciBDNIQMRxuvhldtJHC =rqEOkyTmjKVciBDNIQMRxuvhldtJYg['schedule']['program']['name']['ko']
     rqEOkyTmjKVciBDNIQMRxuvhldtJHw=rqEOkyTmjKVciBDNIQMRxuvhldtJYg['schedule']['program']['synopsis']['ko']
    try: 
     rqEOkyTmjKVciBDNIQMRxuvhldtJHs =''
     rqEOkyTmjKVciBDNIQMRxuvhldtJHg =''
     rqEOkyTmjKVciBDNIQMRxuvhldtJHF=''
     rqEOkyTmjKVciBDNIQMRxuvhldtJHb =''
     rqEOkyTmjKVciBDNIQMRxuvhldtJHe =''
     rqEOkyTmjKVciBDNIQMRxuvhldtJHn =''
     for rqEOkyTmjKVciBDNIQMRxuvhldtJoU in rqEOkyTmjKVciBDNIQMRxuvhldtJYg['schedule']['program']['image']:
      if rqEOkyTmjKVciBDNIQMRxuvhldtJoU['code']=='CAIP0900':rqEOkyTmjKVciBDNIQMRxuvhldtJHg =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJoU['url']
      elif rqEOkyTmjKVciBDNIQMRxuvhldtJoU['code']=='CAIP1800':rqEOkyTmjKVciBDNIQMRxuvhldtJHF=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJoU['url']
      elif rqEOkyTmjKVciBDNIQMRxuvhldtJoU['code']=='CAIP2000':rqEOkyTmjKVciBDNIQMRxuvhldtJHb =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJoU['url']
      elif rqEOkyTmjKVciBDNIQMRxuvhldtJoU['code']=='CAIP1900':rqEOkyTmjKVciBDNIQMRxuvhldtJHe =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJoU['url']
      elif rqEOkyTmjKVciBDNIQMRxuvhldtJoU['code']=='CAIP0200':rqEOkyTmjKVciBDNIQMRxuvhldtJHn =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJoU['url']
      elif rqEOkyTmjKVciBDNIQMRxuvhldtJoU['code']=='CAIP0500':rqEOkyTmjKVciBDNIQMRxuvhldtJHs =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJoU['url']
      elif rqEOkyTmjKVciBDNIQMRxuvhldtJoU['code']=='CAIP0800':rqEOkyTmjKVciBDNIQMRxuvhldtJHs =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJoU['url']
     if rqEOkyTmjKVciBDNIQMRxuvhldtJHs=='':
      for rqEOkyTmjKVciBDNIQMRxuvhldtJoU in rqEOkyTmjKVciBDNIQMRxuvhldtJYg['schedule']['channel']['image']:
       if rqEOkyTmjKVciBDNIQMRxuvhldtJoU['code']=='CAIC0400':rqEOkyTmjKVciBDNIQMRxuvhldtJHs =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJoU['url']
       elif rqEOkyTmjKVciBDNIQMRxuvhldtJoU['code']=='CAIC1400':rqEOkyTmjKVciBDNIQMRxuvhldtJHs =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJoU['url']
       elif rqEOkyTmjKVciBDNIQMRxuvhldtJoU['code']=='CAIC1900':rqEOkyTmjKVciBDNIQMRxuvhldtJHs =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJoU['url']
    except:
     rqEOkyTmjKVciBDNIQMRxuvhldtJLf
    try:
     rqEOkyTmjKVciBDNIQMRxuvhldtJoY =[]
     rqEOkyTmjKVciBDNIQMRxuvhldtJoH=[]
     rqEOkyTmjKVciBDNIQMRxuvhldtJoX =[]
     rqEOkyTmjKVciBDNIQMRxuvhldtJoL=''
     rqEOkyTmjKVciBDNIQMRxuvhldtJoG=''
     rqEOkyTmjKVciBDNIQMRxuvhldtJoz=''
     for rqEOkyTmjKVciBDNIQMRxuvhldtJop in rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('schedule').get('program').get('actor'):
      if rqEOkyTmjKVciBDNIQMRxuvhldtJop!='' and rqEOkyTmjKVciBDNIQMRxuvhldtJop!=u'없음':rqEOkyTmjKVciBDNIQMRxuvhldtJoY.append(rqEOkyTmjKVciBDNIQMRxuvhldtJop)
     for rqEOkyTmjKVciBDNIQMRxuvhldtJoa in rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('schedule').get('program').get('director'):
      if rqEOkyTmjKVciBDNIQMRxuvhldtJoa!='' and rqEOkyTmjKVciBDNIQMRxuvhldtJoa!='-' and rqEOkyTmjKVciBDNIQMRxuvhldtJoa!=u'없음':rqEOkyTmjKVciBDNIQMRxuvhldtJoH.append(rqEOkyTmjKVciBDNIQMRxuvhldtJoa)
     if rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('schedule').get('program').get('category1_name').get('ko')!='':
      rqEOkyTmjKVciBDNIQMRxuvhldtJoX.append(rqEOkyTmjKVciBDNIQMRxuvhldtJYg['schedule']['program']['category1_name']['ko'])
     if rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('schedule').get('program').get('category2_name').get('ko')!='':
      rqEOkyTmjKVciBDNIQMRxuvhldtJoX.append(rqEOkyTmjKVciBDNIQMRxuvhldtJYg['schedule']['program']['category2_name']['ko'])
     if rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('schedule').get('program').get('product_year'):rqEOkyTmjKVciBDNIQMRxuvhldtJoL=rqEOkyTmjKVciBDNIQMRxuvhldtJYg['schedule']['program']['product_year']
     if rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('schedule').get('program').get('grade_code') :rqEOkyTmjKVciBDNIQMRxuvhldtJoG= rqEOkyTmjKVciBDNIQMRxuvhldtJUo.get(rqEOkyTmjKVciBDNIQMRxuvhldtJYg['schedule']['program']['grade_code'])
     if 'broad_dt' in rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('schedule').get('program'):
      rqEOkyTmjKVciBDNIQMRxuvhldtJof =rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('schedule').get('program').get('broad_dt')
      rqEOkyTmjKVciBDNIQMRxuvhldtJoz='%s-%s-%s'%(rqEOkyTmjKVciBDNIQMRxuvhldtJof[:4],rqEOkyTmjKVciBDNIQMRxuvhldtJof[4:6],rqEOkyTmjKVciBDNIQMRxuvhldtJof[6:])
    except:
     rqEOkyTmjKVciBDNIQMRxuvhldtJLf
    rqEOkyTmjKVciBDNIQMRxuvhldtJHS=rqEOkyTmjKVciBDNIQMRxuvhldtJLs(rqEOkyTmjKVciBDNIQMRxuvhldtJYg['schedule']['broadcast_start_time'])[8:12]
    rqEOkyTmjKVciBDNIQMRxuvhldtJoP =rqEOkyTmjKVciBDNIQMRxuvhldtJLs(rqEOkyTmjKVciBDNIQMRxuvhldtJYg['schedule']['broadcast_end_time'])[8:12]
    rqEOkyTmjKVciBDNIQMRxuvhldtJoA={'channel':rqEOkyTmjKVciBDNIQMRxuvhldtJHA,'title':rqEOkyTmjKVciBDNIQMRxuvhldtJHC,'mediacode':rqEOkyTmjKVciBDNIQMRxuvhldtJHW,'thumbnail':{'poster':rqEOkyTmjKVciBDNIQMRxuvhldtJHg,'thumb':rqEOkyTmjKVciBDNIQMRxuvhldtJHs,'clearlogo':rqEOkyTmjKVciBDNIQMRxuvhldtJHF,'icon':rqEOkyTmjKVciBDNIQMRxuvhldtJHb,'fanart':rqEOkyTmjKVciBDNIQMRxuvhldtJHn},'synopsis':rqEOkyTmjKVciBDNIQMRxuvhldtJHw,'channelepg':' [%s:%s ~ %s:%s]'%(rqEOkyTmjKVciBDNIQMRxuvhldtJHS[0:2],rqEOkyTmjKVciBDNIQMRxuvhldtJHS[2:],rqEOkyTmjKVciBDNIQMRxuvhldtJoP[0:2],rqEOkyTmjKVciBDNIQMRxuvhldtJoP[2:]),'cast':rqEOkyTmjKVciBDNIQMRxuvhldtJoY,'director':rqEOkyTmjKVciBDNIQMRxuvhldtJoH,'info_genre':rqEOkyTmjKVciBDNIQMRxuvhldtJoX,'year':rqEOkyTmjKVciBDNIQMRxuvhldtJoL,'mpaa':rqEOkyTmjKVciBDNIQMRxuvhldtJoG,'premiered':rqEOkyTmjKVciBDNIQMRxuvhldtJoz}
    rqEOkyTmjKVciBDNIQMRxuvhldtJHz.append(rqEOkyTmjKVciBDNIQMRxuvhldtJoA)
   if rqEOkyTmjKVciBDNIQMRxuvhldtJYW['body']['has_more']=='Y':
    rqEOkyTmjKVciBDNIQMRxuvhldtJHp=rqEOkyTmjKVciBDNIQMRxuvhldtJLW
   else:
    rqEOkyTmjKVciBDNIQMRxuvhldtJoA={'channel':'OCN Original','title':'temp','mediacode':'C01345','thumbnail':'http://image.tving.com/upload/cms/caic/CAIC0400/C01345.png','cast':[],'director':[]}
  except rqEOkyTmjKVciBDNIQMRxuvhldtJLC as exception:
   rqEOkyTmjKVciBDNIQMRxuvhldtJLw(exception)
  return rqEOkyTmjKVciBDNIQMRxuvhldtJHz,rqEOkyTmjKVciBDNIQMRxuvhldtJHp
 def GetProgramList(rqEOkyTmjKVciBDNIQMRxuvhldtJUX,genre,orderby,page_int,genreCode='all'):
  rqEOkyTmjKVciBDNIQMRxuvhldtJHz=[]
  rqEOkyTmjKVciBDNIQMRxuvhldtJHp=rqEOkyTmjKVciBDNIQMRxuvhldtJLP
  try:
   rqEOkyTmjKVciBDNIQMRxuvhldtJYf ='/v2/media/episodes'
   rqEOkyTmjKVciBDNIQMRxuvhldtJYP=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.GetDefaultParams()
   rqEOkyTmjKVciBDNIQMRxuvhldtJYA={'pageNo':rqEOkyTmjKVciBDNIQMRxuvhldtJLs(page_int),'pageSize':rqEOkyTmjKVciBDNIQMRxuvhldtJLs(rqEOkyTmjKVciBDNIQMRxuvhldtJUX.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','_':rqEOkyTmjKVciBDNIQMRxuvhldtJLs(rqEOkyTmjKVciBDNIQMRxuvhldtJUX.GetNoCache(2))}
   if genre !='all':rqEOkyTmjKVciBDNIQMRxuvhldtJYA['categoryCode']=genre
   if genreCode!='all':rqEOkyTmjKVciBDNIQMRxuvhldtJYA['genreCode'] =genreCode 
   rqEOkyTmjKVciBDNIQMRxuvhldtJYP.update(rqEOkyTmjKVciBDNIQMRxuvhldtJYA)
   rqEOkyTmjKVciBDNIQMRxuvhldtJYS=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.API_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJYf
   rqEOkyTmjKVciBDNIQMRxuvhldtJUe=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.callRequestCookies('Get',rqEOkyTmjKVciBDNIQMRxuvhldtJYS,payload=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,params=rqEOkyTmjKVciBDNIQMRxuvhldtJYP,headers=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,cookies=rqEOkyTmjKVciBDNIQMRxuvhldtJLf)
   rqEOkyTmjKVciBDNIQMRxuvhldtJYW=json.loads(rqEOkyTmjKVciBDNIQMRxuvhldtJUe.text)
   if not('result' in rqEOkyTmjKVciBDNIQMRxuvhldtJYW['body']):return rqEOkyTmjKVciBDNIQMRxuvhldtJHz,rqEOkyTmjKVciBDNIQMRxuvhldtJHp
   rqEOkyTmjKVciBDNIQMRxuvhldtJHP=rqEOkyTmjKVciBDNIQMRxuvhldtJYW['body']['result']
   for rqEOkyTmjKVciBDNIQMRxuvhldtJYg in rqEOkyTmjKVciBDNIQMRxuvhldtJHP:
    rqEOkyTmjKVciBDNIQMRxuvhldtJoS=rqEOkyTmjKVciBDNIQMRxuvhldtJYg['program']['code']
    rqEOkyTmjKVciBDNIQMRxuvhldtJHC =rqEOkyTmjKVciBDNIQMRxuvhldtJYg['program']['name']['ko']
    rqEOkyTmjKVciBDNIQMRxuvhldtJoG =rqEOkyTmjKVciBDNIQMRxuvhldtJUo.get(rqEOkyTmjKVciBDNIQMRxuvhldtJYg['program'].get('grade_code'))
    rqEOkyTmjKVciBDNIQMRxuvhldtJHg =''
    rqEOkyTmjKVciBDNIQMRxuvhldtJHs =''
    rqEOkyTmjKVciBDNIQMRxuvhldtJHF=''
    rqEOkyTmjKVciBDNIQMRxuvhldtJHb =''
    rqEOkyTmjKVciBDNIQMRxuvhldtJHe =''
    for rqEOkyTmjKVciBDNIQMRxuvhldtJoU in rqEOkyTmjKVciBDNIQMRxuvhldtJYg['program']['image']:
     if rqEOkyTmjKVciBDNIQMRxuvhldtJoU['code']=='CAIP0900':rqEOkyTmjKVciBDNIQMRxuvhldtJHg =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJoU['url']
     elif rqEOkyTmjKVciBDNIQMRxuvhldtJoU['code']=='CAIP0200':rqEOkyTmjKVciBDNIQMRxuvhldtJHs =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJoU['url']
     elif rqEOkyTmjKVciBDNIQMRxuvhldtJoU['code']=='CAIP1800':rqEOkyTmjKVciBDNIQMRxuvhldtJHF=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJoU['url']
     elif rqEOkyTmjKVciBDNIQMRxuvhldtJoU['code']=='CAIP2000':rqEOkyTmjKVciBDNIQMRxuvhldtJHb =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJoU['url']
     elif rqEOkyTmjKVciBDNIQMRxuvhldtJoU['code']=='CAIP1900':rqEOkyTmjKVciBDNIQMRxuvhldtJHe =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJoU['url']
    rqEOkyTmjKVciBDNIQMRxuvhldtJHw =rqEOkyTmjKVciBDNIQMRxuvhldtJYg['program']['synopsis']['ko']
    try:
     rqEOkyTmjKVciBDNIQMRxuvhldtJoW=rqEOkyTmjKVciBDNIQMRxuvhldtJYg['channel']['name']['ko']
    except:
     rqEOkyTmjKVciBDNIQMRxuvhldtJoW=''
    try:
     rqEOkyTmjKVciBDNIQMRxuvhldtJoY =[]
     rqEOkyTmjKVciBDNIQMRxuvhldtJoH=[]
     rqEOkyTmjKVciBDNIQMRxuvhldtJoX =[]
     rqEOkyTmjKVciBDNIQMRxuvhldtJoL =''
     rqEOkyTmjKVciBDNIQMRxuvhldtJoz=''
     for rqEOkyTmjKVciBDNIQMRxuvhldtJop in rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('program').get('actor'):
      if rqEOkyTmjKVciBDNIQMRxuvhldtJop!='' and rqEOkyTmjKVciBDNIQMRxuvhldtJop!='-' and rqEOkyTmjKVciBDNIQMRxuvhldtJop!=u'없음':rqEOkyTmjKVciBDNIQMRxuvhldtJoY.append(rqEOkyTmjKVciBDNIQMRxuvhldtJop)
     for rqEOkyTmjKVciBDNIQMRxuvhldtJoa in rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('program').get('director'):
      if rqEOkyTmjKVciBDNIQMRxuvhldtJoa!='' and rqEOkyTmjKVciBDNIQMRxuvhldtJoa!='-' and rqEOkyTmjKVciBDNIQMRxuvhldtJoa!=u'없음':rqEOkyTmjKVciBDNIQMRxuvhldtJoH.append(rqEOkyTmjKVciBDNIQMRxuvhldtJoa)
     if rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('program').get('category1_name').get('ko')!='':
      rqEOkyTmjKVciBDNIQMRxuvhldtJoX.append(rqEOkyTmjKVciBDNIQMRxuvhldtJYg['program']['category1_name']['ko'])
     if rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('program').get('category2_name').get('ko')!='':
      rqEOkyTmjKVciBDNIQMRxuvhldtJoX.append(rqEOkyTmjKVciBDNIQMRxuvhldtJYg['program']['category2_name']['ko'])
     if rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('program').get('product_year'):rqEOkyTmjKVciBDNIQMRxuvhldtJoL=rqEOkyTmjKVciBDNIQMRxuvhldtJYg['program']['product_year']
     if 'broad_dt' in rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('program'):
      rqEOkyTmjKVciBDNIQMRxuvhldtJof =rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('program').get('broad_dt')
      rqEOkyTmjKVciBDNIQMRxuvhldtJoz='%s-%s-%s'%(rqEOkyTmjKVciBDNIQMRxuvhldtJof[:4],rqEOkyTmjKVciBDNIQMRxuvhldtJof[4:6],rqEOkyTmjKVciBDNIQMRxuvhldtJof[6:])
    except:
     rqEOkyTmjKVciBDNIQMRxuvhldtJLf
    rqEOkyTmjKVciBDNIQMRxuvhldtJoA={'program':rqEOkyTmjKVciBDNIQMRxuvhldtJoS,'title':rqEOkyTmjKVciBDNIQMRxuvhldtJHC,'thumbnail':{'poster':rqEOkyTmjKVciBDNIQMRxuvhldtJHg,'thumb':rqEOkyTmjKVciBDNIQMRxuvhldtJHs,'clearlogo':rqEOkyTmjKVciBDNIQMRxuvhldtJHF,'icon':rqEOkyTmjKVciBDNIQMRxuvhldtJHb,'banner':rqEOkyTmjKVciBDNIQMRxuvhldtJHe,'fanart':rqEOkyTmjKVciBDNIQMRxuvhldtJHs},'synopsis':rqEOkyTmjKVciBDNIQMRxuvhldtJHw,'channel':rqEOkyTmjKVciBDNIQMRxuvhldtJoW,'cast':rqEOkyTmjKVciBDNIQMRxuvhldtJoY,'director':rqEOkyTmjKVciBDNIQMRxuvhldtJoH,'info_genre':rqEOkyTmjKVciBDNIQMRxuvhldtJoX,'year':rqEOkyTmjKVciBDNIQMRxuvhldtJoL,'premiered':rqEOkyTmjKVciBDNIQMRxuvhldtJoz,'mpaa':rqEOkyTmjKVciBDNIQMRxuvhldtJoG}
    rqEOkyTmjKVciBDNIQMRxuvhldtJHz.append(rqEOkyTmjKVciBDNIQMRxuvhldtJoA)
   if rqEOkyTmjKVciBDNIQMRxuvhldtJYW['body']['has_more']=='Y':rqEOkyTmjKVciBDNIQMRxuvhldtJHp=rqEOkyTmjKVciBDNIQMRxuvhldtJLW
  except rqEOkyTmjKVciBDNIQMRxuvhldtJLC as exception:
   rqEOkyTmjKVciBDNIQMRxuvhldtJLw(exception)
  return rqEOkyTmjKVciBDNIQMRxuvhldtJHz,rqEOkyTmjKVciBDNIQMRxuvhldtJHp
 def GetEpisodeList(rqEOkyTmjKVciBDNIQMRxuvhldtJUX,program_code,page_int,orderby='desc'):
  rqEOkyTmjKVciBDNIQMRxuvhldtJHz=[]
  rqEOkyTmjKVciBDNIQMRxuvhldtJHp=rqEOkyTmjKVciBDNIQMRxuvhldtJLP
  try:
   rqEOkyTmjKVciBDNIQMRxuvhldtJYf ='/v2/media/frequency/program/'+program_code
   rqEOkyTmjKVciBDNIQMRxuvhldtJYP=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.GetDefaultParams()
   rqEOkyTmjKVciBDNIQMRxuvhldtJYA={'pageNo':'1','pageSize':'10','order':'new','free':'all','adult':'all','scope':'all','_':rqEOkyTmjKVciBDNIQMRxuvhldtJLs(rqEOkyTmjKVciBDNIQMRxuvhldtJUX.GetNoCache(2))}
   rqEOkyTmjKVciBDNIQMRxuvhldtJYP.update(rqEOkyTmjKVciBDNIQMRxuvhldtJYA)
   rqEOkyTmjKVciBDNIQMRxuvhldtJYS=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.API_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJYf
   rqEOkyTmjKVciBDNIQMRxuvhldtJUe=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.callRequestCookies('Get',rqEOkyTmjKVciBDNIQMRxuvhldtJYS,payload=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,params=rqEOkyTmjKVciBDNIQMRxuvhldtJYP,headers=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,cookies=rqEOkyTmjKVciBDNIQMRxuvhldtJLf)
   rqEOkyTmjKVciBDNIQMRxuvhldtJYW=json.loads(rqEOkyTmjKVciBDNIQMRxuvhldtJUe.text)
   if not('result' in rqEOkyTmjKVciBDNIQMRxuvhldtJYW['body']):return rqEOkyTmjKVciBDNIQMRxuvhldtJHz,rqEOkyTmjKVciBDNIQMRxuvhldtJHp
   rqEOkyTmjKVciBDNIQMRxuvhldtJHP=rqEOkyTmjKVciBDNIQMRxuvhldtJYW['body']['result']
   rqEOkyTmjKVciBDNIQMRxuvhldtJoC=rqEOkyTmjKVciBDNIQMRxuvhldtJLA(rqEOkyTmjKVciBDNIQMRxuvhldtJYW['body']['total_count'])
   rqEOkyTmjKVciBDNIQMRxuvhldtJow =rqEOkyTmjKVciBDNIQMRxuvhldtJLA(rqEOkyTmjKVciBDNIQMRxuvhldtJoC//(rqEOkyTmjKVciBDNIQMRxuvhldtJUX.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    rqEOkyTmjKVciBDNIQMRxuvhldtJos =(rqEOkyTmjKVciBDNIQMRxuvhldtJoC-1)-((page_int-1)*rqEOkyTmjKVciBDNIQMRxuvhldtJUX.EPISODE_LIMIT)
   else:
    rqEOkyTmjKVciBDNIQMRxuvhldtJos =(page_int-1)*rqEOkyTmjKVciBDNIQMRxuvhldtJUX.EPISODE_LIMIT
   for i in rqEOkyTmjKVciBDNIQMRxuvhldtJLS(rqEOkyTmjKVciBDNIQMRxuvhldtJUX.EPISODE_LIMIT):
    if orderby=='desc':
     rqEOkyTmjKVciBDNIQMRxuvhldtJog=rqEOkyTmjKVciBDNIQMRxuvhldtJos-i
     if rqEOkyTmjKVciBDNIQMRxuvhldtJog<0:break
    else:
     rqEOkyTmjKVciBDNIQMRxuvhldtJog=rqEOkyTmjKVciBDNIQMRxuvhldtJos+i
     if rqEOkyTmjKVciBDNIQMRxuvhldtJog>=rqEOkyTmjKVciBDNIQMRxuvhldtJoC:break
    rqEOkyTmjKVciBDNIQMRxuvhldtJoF=rqEOkyTmjKVciBDNIQMRxuvhldtJHP[rqEOkyTmjKVciBDNIQMRxuvhldtJog]['episode']['code']
    rqEOkyTmjKVciBDNIQMRxuvhldtJHC =rqEOkyTmjKVciBDNIQMRxuvhldtJHP[rqEOkyTmjKVciBDNIQMRxuvhldtJog]['vod_name']['ko']
    rqEOkyTmjKVciBDNIQMRxuvhldtJob =''
    try:
     rqEOkyTmjKVciBDNIQMRxuvhldtJof=rqEOkyTmjKVciBDNIQMRxuvhldtJLs(rqEOkyTmjKVciBDNIQMRxuvhldtJHP[rqEOkyTmjKVciBDNIQMRxuvhldtJog]['episode']['broadcast_date'])
     rqEOkyTmjKVciBDNIQMRxuvhldtJob='%s-%s-%s'%(rqEOkyTmjKVciBDNIQMRxuvhldtJof[:4],rqEOkyTmjKVciBDNIQMRxuvhldtJof[4:6],rqEOkyTmjKVciBDNIQMRxuvhldtJof[6:])
    except:
     rqEOkyTmjKVciBDNIQMRxuvhldtJLf
    try:
     if rqEOkyTmjKVciBDNIQMRxuvhldtJHP[rqEOkyTmjKVciBDNIQMRxuvhldtJog]['episode']['pip_cliptype']=='C012':
      rqEOkyTmjKVciBDNIQMRxuvhldtJob+=' - Quick VOD'
    except:
     rqEOkyTmjKVciBDNIQMRxuvhldtJLf
    rqEOkyTmjKVciBDNIQMRxuvhldtJHw =rqEOkyTmjKVciBDNIQMRxuvhldtJHP[rqEOkyTmjKVciBDNIQMRxuvhldtJog]['episode']['synopsis']['ko']
    rqEOkyTmjKVciBDNIQMRxuvhldtJHg =''
    rqEOkyTmjKVciBDNIQMRxuvhldtJHs =''
    rqEOkyTmjKVciBDNIQMRxuvhldtJHF=''
    rqEOkyTmjKVciBDNIQMRxuvhldtJHb =''
    rqEOkyTmjKVciBDNIQMRxuvhldtJHe =''
    rqEOkyTmjKVciBDNIQMRxuvhldtJHn =''
    for rqEOkyTmjKVciBDNIQMRxuvhldtJoU in rqEOkyTmjKVciBDNIQMRxuvhldtJHP[rqEOkyTmjKVciBDNIQMRxuvhldtJog]['program']['image']:
     if rqEOkyTmjKVciBDNIQMRxuvhldtJoU['code']=='CAIP0900':rqEOkyTmjKVciBDNIQMRxuvhldtJHg =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJoU['url']
     elif rqEOkyTmjKVciBDNIQMRxuvhldtJoU['code']=='CAIP1800':rqEOkyTmjKVciBDNIQMRxuvhldtJHF=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJoU['url']
     elif rqEOkyTmjKVciBDNIQMRxuvhldtJoU['code']=='CAIP2000':rqEOkyTmjKVciBDNIQMRxuvhldtJHb =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJoU['url']
     elif rqEOkyTmjKVciBDNIQMRxuvhldtJoU['code']=='CAIP1900':rqEOkyTmjKVciBDNIQMRxuvhldtJHe =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJoU['url']
     elif rqEOkyTmjKVciBDNIQMRxuvhldtJoU['code']=='CAIP0200':rqEOkyTmjKVciBDNIQMRxuvhldtJHn =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJoU['url']
    for rqEOkyTmjKVciBDNIQMRxuvhldtJoU in rqEOkyTmjKVciBDNIQMRxuvhldtJHP[rqEOkyTmjKVciBDNIQMRxuvhldtJog]['episode']['image']:
     if rqEOkyTmjKVciBDNIQMRxuvhldtJoU['code']=='CAIE0400':rqEOkyTmjKVciBDNIQMRxuvhldtJHs =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJoU['url']
    try:
     rqEOkyTmjKVciBDNIQMRxuvhldtJoe=rqEOkyTmjKVciBDNIQMRxuvhldtJXU=rqEOkyTmjKVciBDNIQMRxuvhldtJXY=''
     rqEOkyTmjKVciBDNIQMRxuvhldtJon=0
     rqEOkyTmjKVciBDNIQMRxuvhldtJoe =rqEOkyTmjKVciBDNIQMRxuvhldtJHP[rqEOkyTmjKVciBDNIQMRxuvhldtJog]['program']['name']['ko']
     rqEOkyTmjKVciBDNIQMRxuvhldtJXU =rqEOkyTmjKVciBDNIQMRxuvhldtJob
     rqEOkyTmjKVciBDNIQMRxuvhldtJXY =rqEOkyTmjKVciBDNIQMRxuvhldtJHP[rqEOkyTmjKVciBDNIQMRxuvhldtJog]['channel']['name']['ko']
     if 'frequency' in rqEOkyTmjKVciBDNIQMRxuvhldtJHP[rqEOkyTmjKVciBDNIQMRxuvhldtJog]['episode']:rqEOkyTmjKVciBDNIQMRxuvhldtJon=rqEOkyTmjKVciBDNIQMRxuvhldtJHP[rqEOkyTmjKVciBDNIQMRxuvhldtJog]['episode']['frequency']
    except:
     rqEOkyTmjKVciBDNIQMRxuvhldtJLf
    rqEOkyTmjKVciBDNIQMRxuvhldtJoA={'episode':rqEOkyTmjKVciBDNIQMRxuvhldtJoF,'title':rqEOkyTmjKVciBDNIQMRxuvhldtJHC,'subtitle':rqEOkyTmjKVciBDNIQMRxuvhldtJob,'thumbnail':{'poster':rqEOkyTmjKVciBDNIQMRxuvhldtJHg,'thumb':rqEOkyTmjKVciBDNIQMRxuvhldtJHs,'clearlogo':rqEOkyTmjKVciBDNIQMRxuvhldtJHF,'icon':rqEOkyTmjKVciBDNIQMRxuvhldtJHb,'banner':rqEOkyTmjKVciBDNIQMRxuvhldtJHe,'fanart':rqEOkyTmjKVciBDNIQMRxuvhldtJHn},'synopsis':rqEOkyTmjKVciBDNIQMRxuvhldtJHw,'info_title':rqEOkyTmjKVciBDNIQMRxuvhldtJoe,'aired':rqEOkyTmjKVciBDNIQMRxuvhldtJXU,'studio':rqEOkyTmjKVciBDNIQMRxuvhldtJXY,'frequency':rqEOkyTmjKVciBDNIQMRxuvhldtJon}
    rqEOkyTmjKVciBDNIQMRxuvhldtJHz.append(rqEOkyTmjKVciBDNIQMRxuvhldtJoA)
   if rqEOkyTmjKVciBDNIQMRxuvhldtJow>page_int:rqEOkyTmjKVciBDNIQMRxuvhldtJHp=rqEOkyTmjKVciBDNIQMRxuvhldtJLW
  except rqEOkyTmjKVciBDNIQMRxuvhldtJLC as exception:
   rqEOkyTmjKVciBDNIQMRxuvhldtJLw(exception)
  return rqEOkyTmjKVciBDNIQMRxuvhldtJHz,rqEOkyTmjKVciBDNIQMRxuvhldtJHp,rqEOkyTmjKVciBDNIQMRxuvhldtJow
 def GetMovieList(rqEOkyTmjKVciBDNIQMRxuvhldtJUX,genre,orderby,page_int):
  rqEOkyTmjKVciBDNIQMRxuvhldtJHz=[]
  rqEOkyTmjKVciBDNIQMRxuvhldtJHp=rqEOkyTmjKVciBDNIQMRxuvhldtJLP
  try:
   rqEOkyTmjKVciBDNIQMRxuvhldtJYf ='/v2/media/movies'
   rqEOkyTmjKVciBDNIQMRxuvhldtJYP=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.GetDefaultParams()
   rqEOkyTmjKVciBDNIQMRxuvhldtJYA={'pageNo':rqEOkyTmjKVciBDNIQMRxuvhldtJLs(page_int),'pageSize':rqEOkyTmjKVciBDNIQMRxuvhldtJLs(rqEOkyTmjKVciBDNIQMRxuvhldtJUX.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','_':rqEOkyTmjKVciBDNIQMRxuvhldtJLs(rqEOkyTmjKVciBDNIQMRxuvhldtJUX.GetNoCache(2))}
   if genre!='all' :rqEOkyTmjKVciBDNIQMRxuvhldtJYA['multiCategoryCode']=genre
   rqEOkyTmjKVciBDNIQMRxuvhldtJYA['productPackageCode']=','.join(rqEOkyTmjKVciBDNIQMRxuvhldtJUX.MOVIE_LITE)
   rqEOkyTmjKVciBDNIQMRxuvhldtJYP.update(rqEOkyTmjKVciBDNIQMRxuvhldtJYA)
   rqEOkyTmjKVciBDNIQMRxuvhldtJYS=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.API_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJYf
   rqEOkyTmjKVciBDNIQMRxuvhldtJUe=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.callRequestCookies('Get',rqEOkyTmjKVciBDNIQMRxuvhldtJYS,payload=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,params=rqEOkyTmjKVciBDNIQMRxuvhldtJYP,headers=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,cookies=rqEOkyTmjKVciBDNIQMRxuvhldtJLf)
   rqEOkyTmjKVciBDNIQMRxuvhldtJYW=json.loads(rqEOkyTmjKVciBDNIQMRxuvhldtJUe.text)
   if not('result' in rqEOkyTmjKVciBDNIQMRxuvhldtJYW['body']):return rqEOkyTmjKVciBDNIQMRxuvhldtJHz,rqEOkyTmjKVciBDNIQMRxuvhldtJHp
   rqEOkyTmjKVciBDNIQMRxuvhldtJHP=rqEOkyTmjKVciBDNIQMRxuvhldtJYW['body']['result']
   for rqEOkyTmjKVciBDNIQMRxuvhldtJYg in rqEOkyTmjKVciBDNIQMRxuvhldtJHP:
    rqEOkyTmjKVciBDNIQMRxuvhldtJXH =rqEOkyTmjKVciBDNIQMRxuvhldtJYg['movie']['code']
    rqEOkyTmjKVciBDNIQMRxuvhldtJHC =rqEOkyTmjKVciBDNIQMRxuvhldtJYg['movie']['name']['ko'].strip()
    rqEOkyTmjKVciBDNIQMRxuvhldtJHC +=u' (%s)'%(rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('movie').get('product_year'))
    rqEOkyTmjKVciBDNIQMRxuvhldtJHg=''
    rqEOkyTmjKVciBDNIQMRxuvhldtJHs =''
    rqEOkyTmjKVciBDNIQMRxuvhldtJHF=''
    for rqEOkyTmjKVciBDNIQMRxuvhldtJoU in rqEOkyTmjKVciBDNIQMRxuvhldtJYg['movie']['image']:
     if rqEOkyTmjKVciBDNIQMRxuvhldtJoU['code']=='CAIM2100':rqEOkyTmjKVciBDNIQMRxuvhldtJHg =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJoU['url']
     elif rqEOkyTmjKVciBDNIQMRxuvhldtJoU['code']=='CAIM0400':rqEOkyTmjKVciBDNIQMRxuvhldtJHs =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJoU['url']
     elif rqEOkyTmjKVciBDNIQMRxuvhldtJoU['code']=='CAIM1800':rqEOkyTmjKVciBDNIQMRxuvhldtJHF=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJoU['url']
    rqEOkyTmjKVciBDNIQMRxuvhldtJHw =rqEOkyTmjKVciBDNIQMRxuvhldtJYg['movie']['story']['ko']
    try:
     rqEOkyTmjKVciBDNIQMRxuvhldtJoe =rqEOkyTmjKVciBDNIQMRxuvhldtJYg['movie']['name']['ko'].strip()
     rqEOkyTmjKVciBDNIQMRxuvhldtJoL =rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('movie').get('product_year')
     rqEOkyTmjKVciBDNIQMRxuvhldtJoG =rqEOkyTmjKVciBDNIQMRxuvhldtJUo.get(rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('grade_code'))
     rqEOkyTmjKVciBDNIQMRxuvhldtJoY=[]
     rqEOkyTmjKVciBDNIQMRxuvhldtJoH=[]
     rqEOkyTmjKVciBDNIQMRxuvhldtJoX=[]
     rqEOkyTmjKVciBDNIQMRxuvhldtJXo=0
     rqEOkyTmjKVciBDNIQMRxuvhldtJoz=''
     rqEOkyTmjKVciBDNIQMRxuvhldtJXY =''
     for rqEOkyTmjKVciBDNIQMRxuvhldtJop in rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('movie').get('actor'):
      if rqEOkyTmjKVciBDNIQMRxuvhldtJop!='':rqEOkyTmjKVciBDNIQMRxuvhldtJoY.append(rqEOkyTmjKVciBDNIQMRxuvhldtJop)
     for rqEOkyTmjKVciBDNIQMRxuvhldtJoa in rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('movie').get('director'):
      if rqEOkyTmjKVciBDNIQMRxuvhldtJoa!='':rqEOkyTmjKVciBDNIQMRxuvhldtJoH.append(rqEOkyTmjKVciBDNIQMRxuvhldtJoa)
     if rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('movie').get('category1_name').get('ko')!='':
      rqEOkyTmjKVciBDNIQMRxuvhldtJoX.append(rqEOkyTmjKVciBDNIQMRxuvhldtJYg['movie']['category1_name']['ko'])
     if rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('movie').get('category2_name').get('ko')!='':
      rqEOkyTmjKVciBDNIQMRxuvhldtJoX.append(rqEOkyTmjKVciBDNIQMRxuvhldtJYg['movie']['category2_name']['ko'])
     if 'duration' in rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('movie'):rqEOkyTmjKVciBDNIQMRxuvhldtJXo=rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('movie').get('duration')
     if 'release_date' in rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('movie'):
      rqEOkyTmjKVciBDNIQMRxuvhldtJof=rqEOkyTmjKVciBDNIQMRxuvhldtJLs(rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('movie').get('release_date'))
      if rqEOkyTmjKVciBDNIQMRxuvhldtJof!='0':rqEOkyTmjKVciBDNIQMRxuvhldtJoz='%s-%s-%s'%(rqEOkyTmjKVciBDNIQMRxuvhldtJof[:4],rqEOkyTmjKVciBDNIQMRxuvhldtJof[4:6],rqEOkyTmjKVciBDNIQMRxuvhldtJof[6:])
     if 'production' in rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('movie'):rqEOkyTmjKVciBDNIQMRxuvhldtJXY=rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('movie').get('production')
    except:
     rqEOkyTmjKVciBDNIQMRxuvhldtJLf
    rqEOkyTmjKVciBDNIQMRxuvhldtJoA={'moviecode':rqEOkyTmjKVciBDNIQMRxuvhldtJXH,'title':rqEOkyTmjKVciBDNIQMRxuvhldtJHC,'thumbnail':{'poster':rqEOkyTmjKVciBDNIQMRxuvhldtJHg,'thumb':rqEOkyTmjKVciBDNIQMRxuvhldtJHs,'clearlogo':rqEOkyTmjKVciBDNIQMRxuvhldtJHF,'fanart':rqEOkyTmjKVciBDNIQMRxuvhldtJHs},'synopsis':rqEOkyTmjKVciBDNIQMRxuvhldtJHw,'info_title':rqEOkyTmjKVciBDNIQMRxuvhldtJoe,'year':rqEOkyTmjKVciBDNIQMRxuvhldtJoL,'cast':rqEOkyTmjKVciBDNIQMRxuvhldtJoY,'director':rqEOkyTmjKVciBDNIQMRxuvhldtJoH,'info_genre':rqEOkyTmjKVciBDNIQMRxuvhldtJoX,'duration':rqEOkyTmjKVciBDNIQMRxuvhldtJXo,'premiered':rqEOkyTmjKVciBDNIQMRxuvhldtJoz,'studio':rqEOkyTmjKVciBDNIQMRxuvhldtJXY,'mpaa':rqEOkyTmjKVciBDNIQMRxuvhldtJoG}
    rqEOkyTmjKVciBDNIQMRxuvhldtJXL=rqEOkyTmjKVciBDNIQMRxuvhldtJLP
    for rqEOkyTmjKVciBDNIQMRxuvhldtJXG in rqEOkyTmjKVciBDNIQMRxuvhldtJYg['billing_package_id']:
     if rqEOkyTmjKVciBDNIQMRxuvhldtJXG in rqEOkyTmjKVciBDNIQMRxuvhldtJUX.MOVIE_LITE:
      rqEOkyTmjKVciBDNIQMRxuvhldtJXL=rqEOkyTmjKVciBDNIQMRxuvhldtJLW
      break
    if rqEOkyTmjKVciBDNIQMRxuvhldtJXL==rqEOkyTmjKVciBDNIQMRxuvhldtJLP: 
     rqEOkyTmjKVciBDNIQMRxuvhldtJoA['title']=rqEOkyTmjKVciBDNIQMRxuvhldtJoA['title']+' [개별구매]'
    rqEOkyTmjKVciBDNIQMRxuvhldtJHz.append(rqEOkyTmjKVciBDNIQMRxuvhldtJoA)
   if rqEOkyTmjKVciBDNIQMRxuvhldtJYW['body']['has_more']=='Y':rqEOkyTmjKVciBDNIQMRxuvhldtJHp=rqEOkyTmjKVciBDNIQMRxuvhldtJLW
  except rqEOkyTmjKVciBDNIQMRxuvhldtJLC as exception:
   rqEOkyTmjKVciBDNIQMRxuvhldtJLw(exception)
  return rqEOkyTmjKVciBDNIQMRxuvhldtJHz,rqEOkyTmjKVciBDNIQMRxuvhldtJHp
 def GetMovieListGenre(rqEOkyTmjKVciBDNIQMRxuvhldtJUX,genre,page_int):
  rqEOkyTmjKVciBDNIQMRxuvhldtJHz=[]
  rqEOkyTmjKVciBDNIQMRxuvhldtJHp=rqEOkyTmjKVciBDNIQMRxuvhldtJLP
  try:
   rqEOkyTmjKVciBDNIQMRxuvhldtJYf ='/v2/media/movie/curation/'+genre
   rqEOkyTmjKVciBDNIQMRxuvhldtJYP=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.GetDefaultParams()
   rqEOkyTmjKVciBDNIQMRxuvhldtJYA={'pageNo':rqEOkyTmjKVciBDNIQMRxuvhldtJLs(page_int),'pageSize':rqEOkyTmjKVciBDNIQMRxuvhldtJLs(rqEOkyTmjKVciBDNIQMRxuvhldtJUX.MOVIE_LIMIT),'_':rqEOkyTmjKVciBDNIQMRxuvhldtJLs(rqEOkyTmjKVciBDNIQMRxuvhldtJUX.GetNoCache(2))}
   rqEOkyTmjKVciBDNIQMRxuvhldtJYP.update(rqEOkyTmjKVciBDNIQMRxuvhldtJYA)
   rqEOkyTmjKVciBDNIQMRxuvhldtJYS=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.API_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJYf
   rqEOkyTmjKVciBDNIQMRxuvhldtJUe=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.callRequestCookies('Get',rqEOkyTmjKVciBDNIQMRxuvhldtJYS,payload=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,params=rqEOkyTmjKVciBDNIQMRxuvhldtJYP,headers=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,cookies=rqEOkyTmjKVciBDNIQMRxuvhldtJLf)
   rqEOkyTmjKVciBDNIQMRxuvhldtJYW=json.loads(rqEOkyTmjKVciBDNIQMRxuvhldtJUe.text)
   if not('movies' in rqEOkyTmjKVciBDNIQMRxuvhldtJYW['body']):return rqEOkyTmjKVciBDNIQMRxuvhldtJHz,rqEOkyTmjKVciBDNIQMRxuvhldtJHp
   rqEOkyTmjKVciBDNIQMRxuvhldtJHP=rqEOkyTmjKVciBDNIQMRxuvhldtJYW['body']['movies']
   for rqEOkyTmjKVciBDNIQMRxuvhldtJYg in rqEOkyTmjKVciBDNIQMRxuvhldtJHP:
    rqEOkyTmjKVciBDNIQMRxuvhldtJXH =rqEOkyTmjKVciBDNIQMRxuvhldtJYg['code']
    rqEOkyTmjKVciBDNIQMRxuvhldtJHC =rqEOkyTmjKVciBDNIQMRxuvhldtJYg['name']['ko']
    rqEOkyTmjKVciBDNIQMRxuvhldtJXz =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJYg['image'][0]['url']
    for rqEOkyTmjKVciBDNIQMRxuvhldtJoU in rqEOkyTmjKVciBDNIQMRxuvhldtJYg['image']:
     if rqEOkyTmjKVciBDNIQMRxuvhldtJoU['code']=='CAIM2100':
      rqEOkyTmjKVciBDNIQMRxuvhldtJXz =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJoU['url']
    rqEOkyTmjKVciBDNIQMRxuvhldtJHw =rqEOkyTmjKVciBDNIQMRxuvhldtJYg['story']['ko']
    rqEOkyTmjKVciBDNIQMRxuvhldtJoA={'moviecode':rqEOkyTmjKVciBDNIQMRxuvhldtJXH,'title':rqEOkyTmjKVciBDNIQMRxuvhldtJHC.strip(),'thumbnail':rqEOkyTmjKVciBDNIQMRxuvhldtJXz,'synopsis':rqEOkyTmjKVciBDNIQMRxuvhldtJHw}
    rqEOkyTmjKVciBDNIQMRxuvhldtJHz.append(rqEOkyTmjKVciBDNIQMRxuvhldtJoA)
  except rqEOkyTmjKVciBDNIQMRxuvhldtJLC as exception:
   rqEOkyTmjKVciBDNIQMRxuvhldtJLw(exception)
  return rqEOkyTmjKVciBDNIQMRxuvhldtJHz,rqEOkyTmjKVciBDNIQMRxuvhldtJHp
 def GetMovieGenre(rqEOkyTmjKVciBDNIQMRxuvhldtJUX):
  rqEOkyTmjKVciBDNIQMRxuvhldtJHz=[]
  rqEOkyTmjKVciBDNIQMRxuvhldtJHp=rqEOkyTmjKVciBDNIQMRxuvhldtJLP
  try:
   rqEOkyTmjKVciBDNIQMRxuvhldtJYf ='/v2/media/movie/curations'
   rqEOkyTmjKVciBDNIQMRxuvhldtJYP=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.GetDefaultParams()
   rqEOkyTmjKVciBDNIQMRxuvhldtJYA={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code','_':rqEOkyTmjKVciBDNIQMRxuvhldtJLs(rqEOkyTmjKVciBDNIQMRxuvhldtJUX.GetNoCache(2))}
   rqEOkyTmjKVciBDNIQMRxuvhldtJYP.update(rqEOkyTmjKVciBDNIQMRxuvhldtJYA)
   rqEOkyTmjKVciBDNIQMRxuvhldtJYS=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.API_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJYf
   rqEOkyTmjKVciBDNIQMRxuvhldtJUe=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.callRequestCookies('Get',rqEOkyTmjKVciBDNIQMRxuvhldtJYS,payload=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,params=rqEOkyTmjKVciBDNIQMRxuvhldtJYP,headers=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,cookies=rqEOkyTmjKVciBDNIQMRxuvhldtJLf)
   rqEOkyTmjKVciBDNIQMRxuvhldtJYW=json.loads(rqEOkyTmjKVciBDNIQMRxuvhldtJUe.text)
   if not('result' in rqEOkyTmjKVciBDNIQMRxuvhldtJYW['body']):return rqEOkyTmjKVciBDNIQMRxuvhldtJHz,rqEOkyTmjKVciBDNIQMRxuvhldtJHp
   rqEOkyTmjKVciBDNIQMRxuvhldtJHP=rqEOkyTmjKVciBDNIQMRxuvhldtJYW['body']['result']
   for rqEOkyTmjKVciBDNIQMRxuvhldtJYg in rqEOkyTmjKVciBDNIQMRxuvhldtJHP:
    rqEOkyTmjKVciBDNIQMRxuvhldtJXp =rqEOkyTmjKVciBDNIQMRxuvhldtJYg['curation_code']
    rqEOkyTmjKVciBDNIQMRxuvhldtJXa =rqEOkyTmjKVciBDNIQMRxuvhldtJYg['curation_name']
    rqEOkyTmjKVciBDNIQMRxuvhldtJoA={'curation_code':rqEOkyTmjKVciBDNIQMRxuvhldtJXp,'curation_name':rqEOkyTmjKVciBDNIQMRxuvhldtJXa}
    rqEOkyTmjKVciBDNIQMRxuvhldtJHz.append(rqEOkyTmjKVciBDNIQMRxuvhldtJoA)
  except rqEOkyTmjKVciBDNIQMRxuvhldtJLC as exception:
   rqEOkyTmjKVciBDNIQMRxuvhldtJLw(exception)
  return rqEOkyTmjKVciBDNIQMRxuvhldtJHz,rqEOkyTmjKVciBDNIQMRxuvhldtJHp
 def GetSearchList(rqEOkyTmjKVciBDNIQMRxuvhldtJUX,search_key,page_int,stype):
  rqEOkyTmjKVciBDNIQMRxuvhldtJXf=[]
  rqEOkyTmjKVciBDNIQMRxuvhldtJHp=rqEOkyTmjKVciBDNIQMRxuvhldtJLP
  try:
   rqEOkyTmjKVciBDNIQMRxuvhldtJYf ='/search/getSearch.jsp'
   rqEOkyTmjKVciBDNIQMRxuvhldtJYA={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':rqEOkyTmjKVciBDNIQMRxuvhldtJLs(page_int),'pageSize':rqEOkyTmjKVciBDNIQMRxuvhldtJLs(rqEOkyTmjKVciBDNIQMRxuvhldtJUX.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':rqEOkyTmjKVciBDNIQMRxuvhldtJUX.SCREENCODE,'os':rqEOkyTmjKVciBDNIQMRxuvhldtJUX.OSCODE,'network':rqEOkyTmjKVciBDNIQMRxuvhldtJUX.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':rqEOkyTmjKVciBDNIQMRxuvhldtJLs(rqEOkyTmjKVciBDNIQMRxuvhldtJUX.SEARCH_LIMIT)if stype=='vod' else '','vodMVReqCnt':rqEOkyTmjKVciBDNIQMRxuvhldtJLs(rqEOkyTmjKVciBDNIQMRxuvhldtJUX.SEARCH_LIMIT)if stype=='movie' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':rqEOkyTmjKVciBDNIQMRxuvhldtJLs(rqEOkyTmjKVciBDNIQMRxuvhldtJUX.GetNoCache(2))}
   rqEOkyTmjKVciBDNIQMRxuvhldtJYS=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.SEARCH_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJYf
   rqEOkyTmjKVciBDNIQMRxuvhldtJUe=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.callRequestCookies('Get',rqEOkyTmjKVciBDNIQMRxuvhldtJYS,payload=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,params=rqEOkyTmjKVciBDNIQMRxuvhldtJYA,headers=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,cookies=rqEOkyTmjKVciBDNIQMRxuvhldtJLf)
   rqEOkyTmjKVciBDNIQMRxuvhldtJYW=json.loads(rqEOkyTmjKVciBDNIQMRxuvhldtJUe.text)
   if stype=='vod':
    if not('programRsb' in rqEOkyTmjKVciBDNIQMRxuvhldtJYW):return rqEOkyTmjKVciBDNIQMRxuvhldtJXf,rqEOkyTmjKVciBDNIQMRxuvhldtJHp
    rqEOkyTmjKVciBDNIQMRxuvhldtJXP=rqEOkyTmjKVciBDNIQMRxuvhldtJYW['programRsb']['dataList']
    rqEOkyTmjKVciBDNIQMRxuvhldtJXA =rqEOkyTmjKVciBDNIQMRxuvhldtJLA(rqEOkyTmjKVciBDNIQMRxuvhldtJYW['programRsb']['count'])
    for rqEOkyTmjKVciBDNIQMRxuvhldtJYg in rqEOkyTmjKVciBDNIQMRxuvhldtJXP:
     rqEOkyTmjKVciBDNIQMRxuvhldtJoS=rqEOkyTmjKVciBDNIQMRxuvhldtJYg['mast_cd']
     rqEOkyTmjKVciBDNIQMRxuvhldtJHC =rqEOkyTmjKVciBDNIQMRxuvhldtJYg['mast_nm']
     rqEOkyTmjKVciBDNIQMRxuvhldtJHg=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJYg['web_url4']
     rqEOkyTmjKVciBDNIQMRxuvhldtJHs =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJYg['web_url']
     try:
      rqEOkyTmjKVciBDNIQMRxuvhldtJoY =[]
      rqEOkyTmjKVciBDNIQMRxuvhldtJoH=[]
      rqEOkyTmjKVciBDNIQMRxuvhldtJoX =[]
      rqEOkyTmjKVciBDNIQMRxuvhldtJXo =0
      rqEOkyTmjKVciBDNIQMRxuvhldtJoG =''
      rqEOkyTmjKVciBDNIQMRxuvhldtJoL =''
      rqEOkyTmjKVciBDNIQMRxuvhldtJXU =''
      if rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('actor') !='' and rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('actor') !='-':rqEOkyTmjKVciBDNIQMRxuvhldtJoY =rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('actor').split(',')
      if rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('director')!='' and rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('director')!='-':rqEOkyTmjKVciBDNIQMRxuvhldtJoH=rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('director').split(',')
      if rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('cate_nm')!='' and rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('cate_nm')!='-':rqEOkyTmjKVciBDNIQMRxuvhldtJoX =rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('cate_nm').split('/')
      if 'targetage' in rqEOkyTmjKVciBDNIQMRxuvhldtJYg:rqEOkyTmjKVciBDNIQMRxuvhldtJoG=rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('targetage')
      if 'broad_dt' in rqEOkyTmjKVciBDNIQMRxuvhldtJYg:
       rqEOkyTmjKVciBDNIQMRxuvhldtJof=rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('broad_dt')
       rqEOkyTmjKVciBDNIQMRxuvhldtJXU='%s-%s-%s'%(rqEOkyTmjKVciBDNIQMRxuvhldtJof[:4],rqEOkyTmjKVciBDNIQMRxuvhldtJof[4:6],rqEOkyTmjKVciBDNIQMRxuvhldtJof[6:])
       rqEOkyTmjKVciBDNIQMRxuvhldtJoL =rqEOkyTmjKVciBDNIQMRxuvhldtJof[:4]
     except:
      rqEOkyTmjKVciBDNIQMRxuvhldtJLf
     rqEOkyTmjKVciBDNIQMRxuvhldtJoA={'program':rqEOkyTmjKVciBDNIQMRxuvhldtJoS,'title':rqEOkyTmjKVciBDNIQMRxuvhldtJHC,'thumbnail':{'poster':rqEOkyTmjKVciBDNIQMRxuvhldtJHg,'thumb':rqEOkyTmjKVciBDNIQMRxuvhldtJHs,'fanart':rqEOkyTmjKVciBDNIQMRxuvhldtJHs},'synopsis':'','cast':rqEOkyTmjKVciBDNIQMRxuvhldtJoY,'director':rqEOkyTmjKVciBDNIQMRxuvhldtJoH,'info_genre':rqEOkyTmjKVciBDNIQMRxuvhldtJoX,'duration':rqEOkyTmjKVciBDNIQMRxuvhldtJXo,'mpaa':rqEOkyTmjKVciBDNIQMRxuvhldtJoG,'year':rqEOkyTmjKVciBDNIQMRxuvhldtJoL,'aired':rqEOkyTmjKVciBDNIQMRxuvhldtJXU}
     rqEOkyTmjKVciBDNIQMRxuvhldtJXf.append(rqEOkyTmjKVciBDNIQMRxuvhldtJoA)
   else:
    if not('vodMVRsb' in rqEOkyTmjKVciBDNIQMRxuvhldtJYW):return rqEOkyTmjKVciBDNIQMRxuvhldtJXf,rqEOkyTmjKVciBDNIQMRxuvhldtJHp
    rqEOkyTmjKVciBDNIQMRxuvhldtJXS=rqEOkyTmjKVciBDNIQMRxuvhldtJYW['vodMVRsb']['dataList']
    rqEOkyTmjKVciBDNIQMRxuvhldtJXA =rqEOkyTmjKVciBDNIQMRxuvhldtJLA(rqEOkyTmjKVciBDNIQMRxuvhldtJYW['vodMVRsb']['count'])
    for rqEOkyTmjKVciBDNIQMRxuvhldtJYg in rqEOkyTmjKVciBDNIQMRxuvhldtJXS:
     rqEOkyTmjKVciBDNIQMRxuvhldtJoS=rqEOkyTmjKVciBDNIQMRxuvhldtJYg['mast_cd']
     rqEOkyTmjKVciBDNIQMRxuvhldtJHC =rqEOkyTmjKVciBDNIQMRxuvhldtJYg['mast_nm'].strip()
     rqEOkyTmjKVciBDNIQMRxuvhldtJHg =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJYg['web_url']
     rqEOkyTmjKVciBDNIQMRxuvhldtJHs =rqEOkyTmjKVciBDNIQMRxuvhldtJHg
     rqEOkyTmjKVciBDNIQMRxuvhldtJHF=''
     try:
      rqEOkyTmjKVciBDNIQMRxuvhldtJoY =[]
      rqEOkyTmjKVciBDNIQMRxuvhldtJoH=[]
      rqEOkyTmjKVciBDNIQMRxuvhldtJoX =[]
      rqEOkyTmjKVciBDNIQMRxuvhldtJXo =0
      rqEOkyTmjKVciBDNIQMRxuvhldtJoG =''
      rqEOkyTmjKVciBDNIQMRxuvhldtJoL =''
      rqEOkyTmjKVciBDNIQMRxuvhldtJXU =''
      if rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('actor') !='' and rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('actor') !='-':rqEOkyTmjKVciBDNIQMRxuvhldtJoY =rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('actor').split(',')
      if rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('director')!='' and rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('director')!='-':rqEOkyTmjKVciBDNIQMRxuvhldtJoH=rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('director').split(',')
      if rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('cate_nm')!='' and rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('cate_nm')!='-':rqEOkyTmjKVciBDNIQMRxuvhldtJoX =rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('cate_nm').split('/')
      if rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('runtime_sec')!='':rqEOkyTmjKVciBDNIQMRxuvhldtJXo=rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('runtime_sec')
      if 'grade_nm' in rqEOkyTmjKVciBDNIQMRxuvhldtJYg:rqEOkyTmjKVciBDNIQMRxuvhldtJoG=rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('grade_nm')
      rqEOkyTmjKVciBDNIQMRxuvhldtJof=rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('broad_dt')
      if data_str!='':
       rqEOkyTmjKVciBDNIQMRxuvhldtJXU='%s-%s-%s'%(rqEOkyTmjKVciBDNIQMRxuvhldtJof[:4],rqEOkyTmjKVciBDNIQMRxuvhldtJof[4:6],rqEOkyTmjKVciBDNIQMRxuvhldtJof[6:])
       rqEOkyTmjKVciBDNIQMRxuvhldtJoL =rqEOkyTmjKVciBDNIQMRxuvhldtJof[:4]
     except:
      rqEOkyTmjKVciBDNIQMRxuvhldtJLf
     rqEOkyTmjKVciBDNIQMRxuvhldtJoA={'movie':rqEOkyTmjKVciBDNIQMRxuvhldtJoS,'title':rqEOkyTmjKVciBDNIQMRxuvhldtJHC,'thumbnail':{'poster':rqEOkyTmjKVciBDNIQMRxuvhldtJHg,'thumb':rqEOkyTmjKVciBDNIQMRxuvhldtJHs,'fanart':rqEOkyTmjKVciBDNIQMRxuvhldtJHs,'clearlogo':rqEOkyTmjKVciBDNIQMRxuvhldtJHF},'synopsis':'','cast':rqEOkyTmjKVciBDNIQMRxuvhldtJoY,'director':rqEOkyTmjKVciBDNIQMRxuvhldtJoH,'info_genre':rqEOkyTmjKVciBDNIQMRxuvhldtJoX,'duration':rqEOkyTmjKVciBDNIQMRxuvhldtJXo,'mpaa':rqEOkyTmjKVciBDNIQMRxuvhldtJoG,'year':rqEOkyTmjKVciBDNIQMRxuvhldtJoL,'aired':rqEOkyTmjKVciBDNIQMRxuvhldtJXU}
     rqEOkyTmjKVciBDNIQMRxuvhldtJXL=rqEOkyTmjKVciBDNIQMRxuvhldtJLP
     for rqEOkyTmjKVciBDNIQMRxuvhldtJXG in rqEOkyTmjKVciBDNIQMRxuvhldtJYg['bill']:
      if rqEOkyTmjKVciBDNIQMRxuvhldtJXG in rqEOkyTmjKVciBDNIQMRxuvhldtJUX.MOVIE_LITE:
       rqEOkyTmjKVciBDNIQMRxuvhldtJXL=rqEOkyTmjKVciBDNIQMRxuvhldtJLW
       break
     if rqEOkyTmjKVciBDNIQMRxuvhldtJXL==rqEOkyTmjKVciBDNIQMRxuvhldtJLP: 
      rqEOkyTmjKVciBDNIQMRxuvhldtJoA['title']=rqEOkyTmjKVciBDNIQMRxuvhldtJoA['title']+' [개별구매]'
     rqEOkyTmjKVciBDNIQMRxuvhldtJXf.append(rqEOkyTmjKVciBDNIQMRxuvhldtJoA)
   if rqEOkyTmjKVciBDNIQMRxuvhldtJXA>(page_int*rqEOkyTmjKVciBDNIQMRxuvhldtJUX.SEARCH_LIMIT):rqEOkyTmjKVciBDNIQMRxuvhldtJHp=rqEOkyTmjKVciBDNIQMRxuvhldtJLW
  except rqEOkyTmjKVciBDNIQMRxuvhldtJLC as exception:
   rqEOkyTmjKVciBDNIQMRxuvhldtJLw(exception)
  return rqEOkyTmjKVciBDNIQMRxuvhldtJXf,rqEOkyTmjKVciBDNIQMRxuvhldtJHp
 def GetDeviceList(rqEOkyTmjKVciBDNIQMRxuvhldtJUX,rqEOkyTmjKVciBDNIQMRxuvhldtJYU,rqEOkyTmjKVciBDNIQMRxuvhldtJYH):
  rqEOkyTmjKVciBDNIQMRxuvhldtJHz=[]
  rqEOkyTmjKVciBDNIQMRxuvhldtJYp='-'
  try:
   rqEOkyTmjKVciBDNIQMRxuvhldtJYf ='/v1/user/device/list'
   rqEOkyTmjKVciBDNIQMRxuvhldtJXW=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.API_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJYf
   rqEOkyTmjKVciBDNIQMRxuvhldtJYA={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   rqEOkyTmjKVciBDNIQMRxuvhldtJUz=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.makeDefaultCookies(vToken=rqEOkyTmjKVciBDNIQMRxuvhldtJYU,vUserinfo=rqEOkyTmjKVciBDNIQMRxuvhldtJYH)
   rqEOkyTmjKVciBDNIQMRxuvhldtJUe=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.callRequestCookies('Get',rqEOkyTmjKVciBDNIQMRxuvhldtJXW,payload=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,params=rqEOkyTmjKVciBDNIQMRxuvhldtJYA,headers=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,cookies=rqEOkyTmjKVciBDNIQMRxuvhldtJUz)
   rqEOkyTmjKVciBDNIQMRxuvhldtJYW=json.loads(rqEOkyTmjKVciBDNIQMRxuvhldtJUe.text)
   rqEOkyTmjKVciBDNIQMRxuvhldtJHz=rqEOkyTmjKVciBDNIQMRxuvhldtJYW['body']
   for rqEOkyTmjKVciBDNIQMRxuvhldtJYg in rqEOkyTmjKVciBDNIQMRxuvhldtJHz:
    if rqEOkyTmjKVciBDNIQMRxuvhldtJYg['model']=='PC':
     rqEOkyTmjKVciBDNIQMRxuvhldtJYp=rqEOkyTmjKVciBDNIQMRxuvhldtJYg['uuid']
  except rqEOkyTmjKVciBDNIQMRxuvhldtJLC as exception:
   rqEOkyTmjKVciBDNIQMRxuvhldtJLw(exception)
  return rqEOkyTmjKVciBDNIQMRxuvhldtJYp
 def GetProfileToken(rqEOkyTmjKVciBDNIQMRxuvhldtJUX,rqEOkyTmjKVciBDNIQMRxuvhldtJYU,rqEOkyTmjKVciBDNIQMRxuvhldtJYH,user_pf):
  rqEOkyTmjKVciBDNIQMRxuvhldtJXC=[]
  rqEOkyTmjKVciBDNIQMRxuvhldtJXw =''
  rqEOkyTmjKVciBDNIQMRxuvhldtJXs =''
  rqEOkyTmjKVciBDNIQMRxuvhldtJXg='Y'
  rqEOkyTmjKVciBDNIQMRxuvhldtJXF ='N'
  try:
   rqEOkyTmjKVciBDNIQMRxuvhldtJYf ='/profile/select.do'
   rqEOkyTmjKVciBDNIQMRxuvhldtJXW=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.URL_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJYf
   rqEOkyTmjKVciBDNIQMRxuvhldtJUz=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.makeDefaultCookies(vToken=rqEOkyTmjKVciBDNIQMRxuvhldtJYU,vUserinfo=rqEOkyTmjKVciBDNIQMRxuvhldtJYH)
   rqEOkyTmjKVciBDNIQMRxuvhldtJUe=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.callRequestCookies('Get',rqEOkyTmjKVciBDNIQMRxuvhldtJXW,payload=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,params=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,headers=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,cookies=rqEOkyTmjKVciBDNIQMRxuvhldtJUz)
   rqEOkyTmjKVciBDNIQMRxuvhldtJXC =re.findall('data-profile-no="\d+"',rqEOkyTmjKVciBDNIQMRxuvhldtJUe.text)
   for i in rqEOkyTmjKVciBDNIQMRxuvhldtJLS(rqEOkyTmjKVciBDNIQMRxuvhldtJLF(rqEOkyTmjKVciBDNIQMRxuvhldtJXC)):
    rqEOkyTmjKVciBDNIQMRxuvhldtJXb =rqEOkyTmjKVciBDNIQMRxuvhldtJXC[i].replace('data-profile-no=','').replace('"','')
    rqEOkyTmjKVciBDNIQMRxuvhldtJXC[i]=rqEOkyTmjKVciBDNIQMRxuvhldtJXb
   rqEOkyTmjKVciBDNIQMRxuvhldtJXw=rqEOkyTmjKVciBDNIQMRxuvhldtJXC[user_pf]
  except rqEOkyTmjKVciBDNIQMRxuvhldtJLC as exception:
   rqEOkyTmjKVciBDNIQMRxuvhldtJLw(exception)
   return rqEOkyTmjKVciBDNIQMRxuvhldtJXs,rqEOkyTmjKVciBDNIQMRxuvhldtJXg,rqEOkyTmjKVciBDNIQMRxuvhldtJXF
  try:
   rqEOkyTmjKVciBDNIQMRxuvhldtJYf ='/profile/api/select.do'
   rqEOkyTmjKVciBDNIQMRxuvhldtJXW=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.URL_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJYf
   rqEOkyTmjKVciBDNIQMRxuvhldtJUz=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.makeDefaultCookies(vToken=rqEOkyTmjKVciBDNIQMRxuvhldtJYU,vUserinfo=rqEOkyTmjKVciBDNIQMRxuvhldtJYH)
   rqEOkyTmjKVciBDNIQMRxuvhldtJUb={'profileNo':rqEOkyTmjKVciBDNIQMRxuvhldtJXw}
   rqEOkyTmjKVciBDNIQMRxuvhldtJUe=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.callRequestCookies('Post',rqEOkyTmjKVciBDNIQMRxuvhldtJXW,payload=rqEOkyTmjKVciBDNIQMRxuvhldtJUb,params=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,headers=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,cookies=rqEOkyTmjKVciBDNIQMRxuvhldtJUz)
   for rqEOkyTmjKVciBDNIQMRxuvhldtJUn in rqEOkyTmjKVciBDNIQMRxuvhldtJUe.cookies:
    if rqEOkyTmjKVciBDNIQMRxuvhldtJUn.name=='_tving_token':
     rqEOkyTmjKVciBDNIQMRxuvhldtJXs=rqEOkyTmjKVciBDNIQMRxuvhldtJUn.value
    elif rqEOkyTmjKVciBDNIQMRxuvhldtJUn.name==rqEOkyTmjKVciBDNIQMRxuvhldtJUX.GLOBAL_COOKIENM['tv_cookiekey']:
     rqEOkyTmjKVciBDNIQMRxuvhldtJXg=rqEOkyTmjKVciBDNIQMRxuvhldtJUn.value
    elif rqEOkyTmjKVciBDNIQMRxuvhldtJUn.name==rqEOkyTmjKVciBDNIQMRxuvhldtJUX.GLOBAL_COOKIENM['tv_lockkey']:
     rqEOkyTmjKVciBDNIQMRxuvhldtJXF=rqEOkyTmjKVciBDNIQMRxuvhldtJUn.value
  except rqEOkyTmjKVciBDNIQMRxuvhldtJLC as exception:
   rqEOkyTmjKVciBDNIQMRxuvhldtJLw(exception)
  return rqEOkyTmjKVciBDNIQMRxuvhldtJXs,rqEOkyTmjKVciBDNIQMRxuvhldtJXg,rqEOkyTmjKVciBDNIQMRxuvhldtJXF
 def GetProfileLockYN(rqEOkyTmjKVciBDNIQMRxuvhldtJUX,rqEOkyTmjKVciBDNIQMRxuvhldtJYU,rqEOkyTmjKVciBDNIQMRxuvhldtJYH):
  rqEOkyTmjKVciBDNIQMRxuvhldtJXC=[]
  rqEOkyTmjKVciBDNIQMRxuvhldtJXF ='N'
  try:
   rqEOkyTmjKVciBDNIQMRxuvhldtJYf ='/profile/select.do'
   rqEOkyTmjKVciBDNIQMRxuvhldtJXW=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.URL_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJYf
   rqEOkyTmjKVciBDNIQMRxuvhldtJUz=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.makeDefaultCookies(vToken=rqEOkyTmjKVciBDNIQMRxuvhldtJYU,vUserinfo=rqEOkyTmjKVciBDNIQMRxuvhldtJYH)
   rqEOkyTmjKVciBDNIQMRxuvhldtJUe=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.callRequestCookies('Get',rqEOkyTmjKVciBDNIQMRxuvhldtJXW,payload=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,params=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,headers=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,cookies=rqEOkyTmjKVciBDNIQMRxuvhldtJUz)
   rqEOkyTmjKVciBDNIQMRxuvhldtJXC =re.findall('data-profile-no="\d+"',rqEOkyTmjKVciBDNIQMRxuvhldtJUe.text)
   for i in rqEOkyTmjKVciBDNIQMRxuvhldtJLS(rqEOkyTmjKVciBDNIQMRxuvhldtJLF(rqEOkyTmjKVciBDNIQMRxuvhldtJXC)):
    rqEOkyTmjKVciBDNIQMRxuvhldtJXb =rqEOkyTmjKVciBDNIQMRxuvhldtJXC[i].replace('data-profile-no=','').replace('"','')
    rqEOkyTmjKVciBDNIQMRxuvhldtJXC[i]=rqEOkyTmjKVciBDNIQMRxuvhldtJXb
  except rqEOkyTmjKVciBDNIQMRxuvhldtJLC as exception:
   rqEOkyTmjKVciBDNIQMRxuvhldtJLw(exception)
   return rqEOkyTmjKVciBDNIQMRxuvhldtJXF
  try:
   rqEOkyTmjKVciBDNIQMRxuvhldtJYf ='/profile/api/select.do'
   rqEOkyTmjKVciBDNIQMRxuvhldtJXW=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.URL_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJYf
   rqEOkyTmjKVciBDNIQMRxuvhldtJUz=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.makeDefaultCookies(vToken=rqEOkyTmjKVciBDNIQMRxuvhldtJYU,vUserinfo=rqEOkyTmjKVciBDNIQMRxuvhldtJYH)
   for i in rqEOkyTmjKVciBDNIQMRxuvhldtJLS(rqEOkyTmjKVciBDNIQMRxuvhldtJLF(rqEOkyTmjKVciBDNIQMRxuvhldtJXC)):
    rqEOkyTmjKVciBDNIQMRxuvhldtJUb={'profileNo':rqEOkyTmjKVciBDNIQMRxuvhldtJXC[i]}
    rqEOkyTmjKVciBDNIQMRxuvhldtJUe=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.callRequestCookies('Post',rqEOkyTmjKVciBDNIQMRxuvhldtJXW,payload=rqEOkyTmjKVciBDNIQMRxuvhldtJUb,params=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,headers=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,cookies=rqEOkyTmjKVciBDNIQMRxuvhldtJUz)
    for rqEOkyTmjKVciBDNIQMRxuvhldtJUn in rqEOkyTmjKVciBDNIQMRxuvhldtJUe.cookies:
     if rqEOkyTmjKVciBDNIQMRxuvhldtJUn.name=='_tving_token':
      rqEOkyTmjKVciBDNIQMRxuvhldtJXe=rqEOkyTmjKVciBDNIQMRxuvhldtJUn.value
     elif rqEOkyTmjKVciBDNIQMRxuvhldtJUn.name==rqEOkyTmjKVciBDNIQMRxuvhldtJUX.GLOBAL_COOKIENM['tv_lockkey']:
      rqEOkyTmjKVciBDNIQMRxuvhldtJXn=rqEOkyTmjKVciBDNIQMRxuvhldtJUn.value
    if rqEOkyTmjKVciBDNIQMRxuvhldtJXe==rqEOkyTmjKVciBDNIQMRxuvhldtJYU:
     rqEOkyTmjKVciBDNIQMRxuvhldtJXF=rqEOkyTmjKVciBDNIQMRxuvhldtJXn
     rqEOkyTmjKVciBDNIQMRxuvhldtJLw(rqEOkyTmjKVciBDNIQMRxuvhldtJYU)
     break
  except rqEOkyTmjKVciBDNIQMRxuvhldtJLC as exception:
   rqEOkyTmjKVciBDNIQMRxuvhldtJLw(exception)
  return rqEOkyTmjKVciBDNIQMRxuvhldtJXF
 def GetBookmarkInfo(rqEOkyTmjKVciBDNIQMRxuvhldtJUX,videoid,vidtype):
  rqEOkyTmjKVciBDNIQMRxuvhldtJLU={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   rqEOkyTmjKVciBDNIQMRxuvhldtJYS=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.API_DOMAIN+'/v2/media/program/'+videoid
   rqEOkyTmjKVciBDNIQMRxuvhldtJYP=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.GetDefaultParams()
   rqEOkyTmjKVciBDNIQMRxuvhldtJYA={'pageNo':'1','pageSize':'10','order':'name',}
   rqEOkyTmjKVciBDNIQMRxuvhldtJYP.update(rqEOkyTmjKVciBDNIQMRxuvhldtJYA)
   rqEOkyTmjKVciBDNIQMRxuvhldtJUe=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.callRequestCookies('Get',rqEOkyTmjKVciBDNIQMRxuvhldtJYS,payload=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,params=rqEOkyTmjKVciBDNIQMRxuvhldtJYP,headers=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,cookies=rqEOkyTmjKVciBDNIQMRxuvhldtJLf)
   rqEOkyTmjKVciBDNIQMRxuvhldtJLY=json.loads(rqEOkyTmjKVciBDNIQMRxuvhldtJUe.text)
   if not('body' in rqEOkyTmjKVciBDNIQMRxuvhldtJLY):return{}
   rqEOkyTmjKVciBDNIQMRxuvhldtJLH=rqEOkyTmjKVciBDNIQMRxuvhldtJLY['body']
   rqEOkyTmjKVciBDNIQMRxuvhldtJHC=rqEOkyTmjKVciBDNIQMRxuvhldtJLH.get('name').get('ko').strip()
   rqEOkyTmjKVciBDNIQMRxuvhldtJLU['saveinfo']['title'] =rqEOkyTmjKVciBDNIQMRxuvhldtJHC
   rqEOkyTmjKVciBDNIQMRxuvhldtJLU['saveinfo']['infoLabels']['title']=rqEOkyTmjKVciBDNIQMRxuvhldtJHC
   rqEOkyTmjKVciBDNIQMRxuvhldtJLU['saveinfo']['infoLabels']['mpaa'] =rqEOkyTmjKVciBDNIQMRxuvhldtJUo.get(rqEOkyTmjKVciBDNIQMRxuvhldtJLH.get('grade_code'))
   rqEOkyTmjKVciBDNIQMRxuvhldtJLU['saveinfo']['infoLabels']['plot'] =rqEOkyTmjKVciBDNIQMRxuvhldtJLH.get('synopsis').get('ko')
   rqEOkyTmjKVciBDNIQMRxuvhldtJLU['saveinfo']['infoLabels']['year'] =rqEOkyTmjKVciBDNIQMRxuvhldtJLH.get('product_year')
   rqEOkyTmjKVciBDNIQMRxuvhldtJLU['saveinfo']['infoLabels']['cast'] =rqEOkyTmjKVciBDNIQMRxuvhldtJLH.get('actor')
   rqEOkyTmjKVciBDNIQMRxuvhldtJLU['saveinfo']['infoLabels']['director']=rqEOkyTmjKVciBDNIQMRxuvhldtJLH.get('director')
   if rqEOkyTmjKVciBDNIQMRxuvhldtJLH.get('category1_name').get('ko')!='':
    rqEOkyTmjKVciBDNIQMRxuvhldtJLU['saveinfo']['infoLabels']['genre'].append(rqEOkyTmjKVciBDNIQMRxuvhldtJLH.get('category1_name').get('ko'))
   if rqEOkyTmjKVciBDNIQMRxuvhldtJLH.get('category2_name').get('ko')!='':
    rqEOkyTmjKVciBDNIQMRxuvhldtJLU['saveinfo']['infoLabels']['genre'].append(rqEOkyTmjKVciBDNIQMRxuvhldtJLH.get('category2_name').get('ko'))
   rqEOkyTmjKVciBDNIQMRxuvhldtJof=rqEOkyTmjKVciBDNIQMRxuvhldtJLs(rqEOkyTmjKVciBDNIQMRxuvhldtJLH.get('broad_dt'))
   if rqEOkyTmjKVciBDNIQMRxuvhldtJof!='0':rqEOkyTmjKVciBDNIQMRxuvhldtJLU['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(rqEOkyTmjKVciBDNIQMRxuvhldtJof[:4],rqEOkyTmjKVciBDNIQMRxuvhldtJof[4:6],rqEOkyTmjKVciBDNIQMRxuvhldtJof[6:])
   rqEOkyTmjKVciBDNIQMRxuvhldtJHg =''
   rqEOkyTmjKVciBDNIQMRxuvhldtJHs =''
   rqEOkyTmjKVciBDNIQMRxuvhldtJHF=''
   rqEOkyTmjKVciBDNIQMRxuvhldtJHb =''
   rqEOkyTmjKVciBDNIQMRxuvhldtJHe =''
   for rqEOkyTmjKVciBDNIQMRxuvhldtJoU in rqEOkyTmjKVciBDNIQMRxuvhldtJLH.get('image'):
    if rqEOkyTmjKVciBDNIQMRxuvhldtJoU.get('code')=='CAIP0900':rqEOkyTmjKVciBDNIQMRxuvhldtJHg =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJoU.get('url')
    elif rqEOkyTmjKVciBDNIQMRxuvhldtJoU.get('code')=='CAIP0200':rqEOkyTmjKVciBDNIQMRxuvhldtJHs =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJoU.get('url')
    elif rqEOkyTmjKVciBDNIQMRxuvhldtJoU.get('code')=='CAIP1800':rqEOkyTmjKVciBDNIQMRxuvhldtJHF=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJoU.get('url')
    elif rqEOkyTmjKVciBDNIQMRxuvhldtJoU.get('code')=='CAIP2000':rqEOkyTmjKVciBDNIQMRxuvhldtJHb =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJoU.get('url')
    elif rqEOkyTmjKVciBDNIQMRxuvhldtJoU.get('code')=='CAIP1900':rqEOkyTmjKVciBDNIQMRxuvhldtJHe =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJoU.get('url')
   rqEOkyTmjKVciBDNIQMRxuvhldtJLU['saveinfo']['thumbnail']['poster']=rqEOkyTmjKVciBDNIQMRxuvhldtJHg
   rqEOkyTmjKVciBDNIQMRxuvhldtJLU['saveinfo']['thumbnail']['thumb']=rqEOkyTmjKVciBDNIQMRxuvhldtJHs
   rqEOkyTmjKVciBDNIQMRxuvhldtJLU['saveinfo']['thumbnail']['clearlogo']=rqEOkyTmjKVciBDNIQMRxuvhldtJHF
   rqEOkyTmjKVciBDNIQMRxuvhldtJLU['saveinfo']['thumbnail']['icon']=rqEOkyTmjKVciBDNIQMRxuvhldtJHb
   rqEOkyTmjKVciBDNIQMRxuvhldtJLU['saveinfo']['thumbnail']['banner']=rqEOkyTmjKVciBDNIQMRxuvhldtJHe
   rqEOkyTmjKVciBDNIQMRxuvhldtJLU['saveinfo']['thumbnail']['fanart']=rqEOkyTmjKVciBDNIQMRxuvhldtJHs
  else:
   rqEOkyTmjKVciBDNIQMRxuvhldtJYS=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.API_DOMAIN+'/v2a/media/stream/info'
   rqEOkyTmjKVciBDNIQMRxuvhldtJYP=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.GetDefaultParams()
   rqEOkyTmjKVciBDNIQMRxuvhldtJYA={'info':'Y','mediaCode':videoid,'noCache':rqEOkyTmjKVciBDNIQMRxuvhldtJLs(rqEOkyTmjKVciBDNIQMRxuvhldtJUX.GetNoCache(1)),'callingFrom':'HTML5','adReq':'adproxy','ooc':'','deviceId':'','uuid':'','deviceInfo':'PC','wm':'Y',}
   rqEOkyTmjKVciBDNIQMRxuvhldtJYP.update(rqEOkyTmjKVciBDNIQMRxuvhldtJYA)
   rqEOkyTmjKVciBDNIQMRxuvhldtJUe=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.callRequestCookies('Get',rqEOkyTmjKVciBDNIQMRxuvhldtJYS,payload=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,params=rqEOkyTmjKVciBDNIQMRxuvhldtJYP,headers=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,cookies=rqEOkyTmjKVciBDNIQMRxuvhldtJLf)
   rqEOkyTmjKVciBDNIQMRxuvhldtJLY=json.loads(rqEOkyTmjKVciBDNIQMRxuvhldtJUe.text)
   if not('content' in rqEOkyTmjKVciBDNIQMRxuvhldtJLY['body']):return{}
   rqEOkyTmjKVciBDNIQMRxuvhldtJLH=rqEOkyTmjKVciBDNIQMRxuvhldtJLY['body']['content']['info']['movie']
   rqEOkyTmjKVciBDNIQMRxuvhldtJHC =rqEOkyTmjKVciBDNIQMRxuvhldtJLH.get('name').get('ko').strip()
   rqEOkyTmjKVciBDNIQMRxuvhldtJLU['saveinfo']['infoLabels']['title']=rqEOkyTmjKVciBDNIQMRxuvhldtJHC
   rqEOkyTmjKVciBDNIQMRxuvhldtJHC +=u' (%s)'%(rqEOkyTmjKVciBDNIQMRxuvhldtJLH.get('product_year'))
   rqEOkyTmjKVciBDNIQMRxuvhldtJLU['saveinfo']['title'] =rqEOkyTmjKVciBDNIQMRxuvhldtJHC
   rqEOkyTmjKVciBDNIQMRxuvhldtJLU['saveinfo']['infoLabels']['mpaa'] =rqEOkyTmjKVciBDNIQMRxuvhldtJUo.get(rqEOkyTmjKVciBDNIQMRxuvhldtJLH.get('grade_code'))
   rqEOkyTmjKVciBDNIQMRxuvhldtJLU['saveinfo']['infoLabels']['plot'] =rqEOkyTmjKVciBDNIQMRxuvhldtJLH.get('story').get('ko')
   rqEOkyTmjKVciBDNIQMRxuvhldtJLU['saveinfo']['infoLabels']['year'] =rqEOkyTmjKVciBDNIQMRxuvhldtJLH.get('product_year')
   rqEOkyTmjKVciBDNIQMRxuvhldtJLU['saveinfo']['infoLabels']['studio'] =rqEOkyTmjKVciBDNIQMRxuvhldtJLH.get('production')
   rqEOkyTmjKVciBDNIQMRxuvhldtJLU['saveinfo']['infoLabels']['duration']=rqEOkyTmjKVciBDNIQMRxuvhldtJLH.get('duration')
   rqEOkyTmjKVciBDNIQMRxuvhldtJLU['saveinfo']['infoLabels']['cast'] =rqEOkyTmjKVciBDNIQMRxuvhldtJLH.get('actor')
   rqEOkyTmjKVciBDNIQMRxuvhldtJLU['saveinfo']['infoLabels']['director']=rqEOkyTmjKVciBDNIQMRxuvhldtJLH.get('director')
   if rqEOkyTmjKVciBDNIQMRxuvhldtJLH.get('category1_name').get('ko')!='':
    rqEOkyTmjKVciBDNIQMRxuvhldtJLU['saveinfo']['infoLabels']['genre'].append(rqEOkyTmjKVciBDNIQMRxuvhldtJLH.get('category1_name').get('ko'))
   if rqEOkyTmjKVciBDNIQMRxuvhldtJLH.get('category2_name').get('ko')!='':
    rqEOkyTmjKVciBDNIQMRxuvhldtJLU['saveinfo']['infoLabels']['genre'].append(rqEOkyTmjKVciBDNIQMRxuvhldtJLH.get('category2_name').get('ko'))
   rqEOkyTmjKVciBDNIQMRxuvhldtJof=rqEOkyTmjKVciBDNIQMRxuvhldtJLs(rqEOkyTmjKVciBDNIQMRxuvhldtJLH.get('release_date'))
   if rqEOkyTmjKVciBDNIQMRxuvhldtJof!='0':rqEOkyTmjKVciBDNIQMRxuvhldtJLU['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(rqEOkyTmjKVciBDNIQMRxuvhldtJof[:4],rqEOkyTmjKVciBDNIQMRxuvhldtJof[4:6],rqEOkyTmjKVciBDNIQMRxuvhldtJof[6:])
   rqEOkyTmjKVciBDNIQMRxuvhldtJHg=''
   rqEOkyTmjKVciBDNIQMRxuvhldtJHs =''
   rqEOkyTmjKVciBDNIQMRxuvhldtJHF=''
   for rqEOkyTmjKVciBDNIQMRxuvhldtJoU in rqEOkyTmjKVciBDNIQMRxuvhldtJLH.get('image'):
    if rqEOkyTmjKVciBDNIQMRxuvhldtJoU.get('code')=='CAIM2100':rqEOkyTmjKVciBDNIQMRxuvhldtJHg =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJoU.get('url')
    elif rqEOkyTmjKVciBDNIQMRxuvhldtJoU.get('code')=='CAIM0400':rqEOkyTmjKVciBDNIQMRxuvhldtJHs =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJoU.get('url')
    elif rqEOkyTmjKVciBDNIQMRxuvhldtJoU.get('code')=='CAIM1800':rqEOkyTmjKVciBDNIQMRxuvhldtJHF=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.IMG_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJoU.get('url')
   rqEOkyTmjKVciBDNIQMRxuvhldtJLU['saveinfo']['thumbnail']['poster']=rqEOkyTmjKVciBDNIQMRxuvhldtJHg
   rqEOkyTmjKVciBDNIQMRxuvhldtJLU['saveinfo']['thumbnail']['thumb']=rqEOkyTmjKVciBDNIQMRxuvhldtJHg 
   rqEOkyTmjKVciBDNIQMRxuvhldtJLU['saveinfo']['thumbnail']['clearlogo']=rqEOkyTmjKVciBDNIQMRxuvhldtJHF
   rqEOkyTmjKVciBDNIQMRxuvhldtJLU['saveinfo']['thumbnail']['fanart']=rqEOkyTmjKVciBDNIQMRxuvhldtJHs
  return rqEOkyTmjKVciBDNIQMRxuvhldtJLU
 def GetEuroChannelList(rqEOkyTmjKVciBDNIQMRxuvhldtJUX):
  rqEOkyTmjKVciBDNIQMRxuvhldtJHz=[]
  try:
   rqEOkyTmjKVciBDNIQMRxuvhldtJYf ='/v2/operator/highlights'
   rqEOkyTmjKVciBDNIQMRxuvhldtJYP=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.GetDefaultParams()
   rqEOkyTmjKVciBDNIQMRxuvhldtJYA={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':rqEOkyTmjKVciBDNIQMRxuvhldtJLs(rqEOkyTmjKVciBDNIQMRxuvhldtJUX.GetNoCache(2))}
   rqEOkyTmjKVciBDNIQMRxuvhldtJYP.update(rqEOkyTmjKVciBDNIQMRxuvhldtJYA)
   rqEOkyTmjKVciBDNIQMRxuvhldtJYS=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.API_DOMAIN+rqEOkyTmjKVciBDNIQMRxuvhldtJYf
   rqEOkyTmjKVciBDNIQMRxuvhldtJUe=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.callRequestCookies('Get',rqEOkyTmjKVciBDNIQMRxuvhldtJYS,payload=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,params=rqEOkyTmjKVciBDNIQMRxuvhldtJYP,headers=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,cookies=rqEOkyTmjKVciBDNIQMRxuvhldtJLf)
   rqEOkyTmjKVciBDNIQMRxuvhldtJYW=json.loads(rqEOkyTmjKVciBDNIQMRxuvhldtJUe.text)
   if not('result' in rqEOkyTmjKVciBDNIQMRxuvhldtJYW['body']):return rqEOkyTmjKVciBDNIQMRxuvhldtJHz,rqEOkyTmjKVciBDNIQMRxuvhldtJHp
   rqEOkyTmjKVciBDNIQMRxuvhldtJHP=rqEOkyTmjKVciBDNIQMRxuvhldtJYW['body']['result']
   rqEOkyTmjKVciBDNIQMRxuvhldtJLo =rqEOkyTmjKVciBDNIQMRxuvhldtJUX.Get_Now_Datetime()
   rqEOkyTmjKVciBDNIQMRxuvhldtJLX=rqEOkyTmjKVciBDNIQMRxuvhldtJLo+datetime.timedelta(days=-1)
   rqEOkyTmjKVciBDNIQMRxuvhldtJLX=rqEOkyTmjKVciBDNIQMRxuvhldtJLA(rqEOkyTmjKVciBDNIQMRxuvhldtJLX.strftime('%Y%m%d'))
   for rqEOkyTmjKVciBDNIQMRxuvhldtJYg in rqEOkyTmjKVciBDNIQMRxuvhldtJHP:
    rqEOkyTmjKVciBDNIQMRxuvhldtJLG=rqEOkyTmjKVciBDNIQMRxuvhldtJLA(rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('content').get('banner_title2')[:8])
    if rqEOkyTmjKVciBDNIQMRxuvhldtJLX<=rqEOkyTmjKVciBDNIQMRxuvhldtJLG:
     rqEOkyTmjKVciBDNIQMRxuvhldtJoA={'channel':rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('content').get('banner_sub_title3'),'title':rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('content').get('banner_title'),'subtitle':rqEOkyTmjKVciBDNIQMRxuvhldtJYg.get('content').get('banner_sub_title2'),}
     rqEOkyTmjKVciBDNIQMRxuvhldtJHz.append(rqEOkyTmjKVciBDNIQMRxuvhldtJoA)
  except rqEOkyTmjKVciBDNIQMRxuvhldtJLC as exception:
   rqEOkyTmjKVciBDNIQMRxuvhldtJLw(exception)
  return rqEOkyTmjKVciBDNIQMRxuvhldtJHz
 def Get_Naver_Login(rqEOkyTmjKVciBDNIQMRxuvhldtJUX):
  try:
   rqEOkyTmjKVciBDNIQMRxuvhldtJYS='https://user.tving.com/oauth/oauthLogin.tving?target=naver&from=pc&rtUrl=https://user.tving.com/pc/user/login.tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fmain.do%3FretRef%3DY%26source%3Dhttps%3A%2F%2Fwww.google.com%2F&csite=&isAuto=false'
   rqEOkyTmjKVciBDNIQMRxuvhldtJUe=rqEOkyTmjKVciBDNIQMRxuvhldtJUX.callRequestCookies('Get',rqEOkyTmjKVciBDNIQMRxuvhldtJYS,payload=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,params=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,headers=rqEOkyTmjKVciBDNIQMRxuvhldtJLf,cookies=rqEOkyTmjKVciBDNIQMRxuvhldtJLf)
   if rqEOkyTmjKVciBDNIQMRxuvhldtJUe.status_code!=200:return rqEOkyTmjKVciBDNIQMRxuvhldtJLP
   rqEOkyTmjKVciBDNIQMRxuvhldtJLz=re.findall('\'https://nid.naver.com/(?:[a-zA-Z]|[0-9]|[$\-@\.&+:/?=_]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+\'',rqEOkyTmjKVciBDNIQMRxuvhldtJUe.text)
   rqEOkyTmjKVciBDNIQMRxuvhldtJLp=rqEOkyTmjKVciBDNIQMRxuvhldtJLz[0].replace('\'','')
   rqEOkyTmjKVciBDNIQMRxuvhldtJLw(rqEOkyTmjKVciBDNIQMRxuvhldtJLp)
  except rqEOkyTmjKVciBDNIQMRxuvhldtJLC as exception:
   rqEOkyTmjKVciBDNIQMRxuvhldtJLw('n login pass1 error')
   rqEOkyTmjKVciBDNIQMRxuvhldtJLw(exception)
  try:
   rqEOkyTmjKVciBDNIQMRxuvhldtJYS=rqEOkyTmjKVciBDNIQMRxuvhldtJLp
  except rqEOkyTmjKVciBDNIQMRxuvhldtJLC as exception:
   rqEOkyTmjKVciBDNIQMRxuvhldtJLw('n login pass1 error')
   rqEOkyTmjKVciBDNIQMRxuvhldtJLw(exception)
  return rqEOkyTmjKVciBDNIQMRxuvhldtJLW
# Created by pyminifier (https://github.com/liftoff/pyminifier)
