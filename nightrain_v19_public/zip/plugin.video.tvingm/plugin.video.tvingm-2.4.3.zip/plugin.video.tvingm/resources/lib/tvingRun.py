__author__="NightRain"
dVqTmhEDwvStsMuLkcxOUNrfIiPAWB=object
dVqTmhEDwvStsMuLkcxOUNrfIiPAWY=None
dVqTmhEDwvStsMuLkcxOUNrfIiPAWa=int
dVqTmhEDwvStsMuLkcxOUNrfIiPAWb=True
dVqTmhEDwvStsMuLkcxOUNrfIiPAWp=False
dVqTmhEDwvStsMuLkcxOUNrfIiPAWX=type
dVqTmhEDwvStsMuLkcxOUNrfIiPAWo=dict
dVqTmhEDwvStsMuLkcxOUNrfIiPAWe=len
dVqTmhEDwvStsMuLkcxOUNrfIiPAWj=str
dVqTmhEDwvStsMuLkcxOUNrfIiPAWl=range
dVqTmhEDwvStsMuLkcxOUNrfIiPAWH=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
dVqTmhEDwvStsMuLkcxOUNrfIiPAFR=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
dVqTmhEDwvStsMuLkcxOUNrfIiPAFg=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
dVqTmhEDwvStsMuLkcxOUNrfIiPAFy=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
dVqTmhEDwvStsMuLkcxOUNrfIiPAFC=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
dVqTmhEDwvStsMuLkcxOUNrfIiPAFn=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'공연','mode':'PROGRAM','stype':'PCM'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'}]
dVqTmhEDwvStsMuLkcxOUNrfIiPAFW=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG190,MG230,MG270,MG290'},{'title':'로맨스/멜로','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'액션/SF','mode':'MOVIE_SUB','stype':'MG120,MG170,MG180,MG220,MG260,MG200,MG210'},{'title':'공포/스릴러','mode':'MOVIE_SUB','stype':'MG160,MG140,MG150'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'다큐/클래식','mode':'MOVIE_SUB','stype':'MG250,MG330'}]
dVqTmhEDwvStsMuLkcxOUNrfIiPAFK=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
dVqTmhEDwvStsMuLkcxOUNrfIiPAFB =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
dVqTmhEDwvStsMuLkcxOUNrfIiPAFY=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
from tvingCore import*
class dVqTmhEDwvStsMuLkcxOUNrfIiPAFG(dVqTmhEDwvStsMuLkcxOUNrfIiPAWB):
 def __init__(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa,dVqTmhEDwvStsMuLkcxOUNrfIiPAFb,dVqTmhEDwvStsMuLkcxOUNrfIiPAFp,dVqTmhEDwvStsMuLkcxOUNrfIiPAFX):
  dVqTmhEDwvStsMuLkcxOUNrfIiPAFa._addon_url =dVqTmhEDwvStsMuLkcxOUNrfIiPAFb
  dVqTmhEDwvStsMuLkcxOUNrfIiPAFa._addon_handle=dVqTmhEDwvStsMuLkcxOUNrfIiPAFp
  dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.main_params =dVqTmhEDwvStsMuLkcxOUNrfIiPAFX
  dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.TvingObj =ctsidPMphTlQCaSVqAOxLrKHNwDReI() 
 def addon_noti(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa,sting):
  try:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFe=xbmcgui.Dialog()
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFe.notification(__addonname__,sting)
  except:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAWY
 def addon_log(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa,string):
  try:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFj=string.encode('utf-8','ignore')
  except:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFj='addonException: addon_log'
  dVqTmhEDwvStsMuLkcxOUNrfIiPAFl=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,dVqTmhEDwvStsMuLkcxOUNrfIiPAFj),level=dVqTmhEDwvStsMuLkcxOUNrfIiPAFl)
 def get_keyboard_input(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa,dVqTmhEDwvStsMuLkcxOUNrfIiPAGa):
  dVqTmhEDwvStsMuLkcxOUNrfIiPAFH=dVqTmhEDwvStsMuLkcxOUNrfIiPAWY
  kb=xbmc.Keyboard()
  kb.setHeading(dVqTmhEDwvStsMuLkcxOUNrfIiPAGa)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFH=kb.getText()
  return dVqTmhEDwvStsMuLkcxOUNrfIiPAFH
 def get_settings_account(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa):
  dVqTmhEDwvStsMuLkcxOUNrfIiPAFJ =__addon__.getSetting('id')
  dVqTmhEDwvStsMuLkcxOUNrfIiPAFz =__addon__.getSetting('pw')
  dVqTmhEDwvStsMuLkcxOUNrfIiPAFQ =__addon__.getSetting('login_type')
  dVqTmhEDwvStsMuLkcxOUNrfIiPAGF=dVqTmhEDwvStsMuLkcxOUNrfIiPAWa(__addon__.getSetting('selected_profile'))
  return(dVqTmhEDwvStsMuLkcxOUNrfIiPAFJ,dVqTmhEDwvStsMuLkcxOUNrfIiPAFz,dVqTmhEDwvStsMuLkcxOUNrfIiPAFQ,dVqTmhEDwvStsMuLkcxOUNrfIiPAGF)
 def get_settings_totalsearch(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa):
  dVqTmhEDwvStsMuLkcxOUNrfIiPAGR =dVqTmhEDwvStsMuLkcxOUNrfIiPAWb if __addon__.getSetting('local_search')=='true' else dVqTmhEDwvStsMuLkcxOUNrfIiPAWp
  dVqTmhEDwvStsMuLkcxOUNrfIiPAGg=dVqTmhEDwvStsMuLkcxOUNrfIiPAWb if __addon__.getSetting('local_history')=='true' else dVqTmhEDwvStsMuLkcxOUNrfIiPAWp
  dVqTmhEDwvStsMuLkcxOUNrfIiPAGy =dVqTmhEDwvStsMuLkcxOUNrfIiPAWb if __addon__.getSetting('total_search')=='true' else dVqTmhEDwvStsMuLkcxOUNrfIiPAWp
  dVqTmhEDwvStsMuLkcxOUNrfIiPAGC=dVqTmhEDwvStsMuLkcxOUNrfIiPAWb if __addon__.getSetting('total_history')=='true' else dVqTmhEDwvStsMuLkcxOUNrfIiPAWp
  dVqTmhEDwvStsMuLkcxOUNrfIiPAGn=dVqTmhEDwvStsMuLkcxOUNrfIiPAWb if __addon__.getSetting('menu_bookmark')=='true' else dVqTmhEDwvStsMuLkcxOUNrfIiPAWp
  return(dVqTmhEDwvStsMuLkcxOUNrfIiPAGR,dVqTmhEDwvStsMuLkcxOUNrfIiPAGg,dVqTmhEDwvStsMuLkcxOUNrfIiPAGy,dVqTmhEDwvStsMuLkcxOUNrfIiPAGC,dVqTmhEDwvStsMuLkcxOUNrfIiPAGn)
 def get_settings_makebookmark(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa):
  return dVqTmhEDwvStsMuLkcxOUNrfIiPAWb if __addon__.getSetting('make_bookmark')=='true' else dVqTmhEDwvStsMuLkcxOUNrfIiPAWp
 def get_settings_direct_replay(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa):
  dVqTmhEDwvStsMuLkcxOUNrfIiPAGW=dVqTmhEDwvStsMuLkcxOUNrfIiPAWa(__addon__.getSetting('direct_replay'))
  if dVqTmhEDwvStsMuLkcxOUNrfIiPAGW==0:
   return dVqTmhEDwvStsMuLkcxOUNrfIiPAWp
  else:
   return dVqTmhEDwvStsMuLkcxOUNrfIiPAWb
 def set_winEpisodeOrderby(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa,dVqTmhEDwvStsMuLkcxOUNrfIiPAGB):
  __addon__.setSetting('tving_orderby',dVqTmhEDwvStsMuLkcxOUNrfIiPAGB)
  dVqTmhEDwvStsMuLkcxOUNrfIiPAGK=xbmcgui.Window(10000)
  dVqTmhEDwvStsMuLkcxOUNrfIiPAGK.setProperty('TVING_M_ORDERBY',dVqTmhEDwvStsMuLkcxOUNrfIiPAGB)
 def get_winEpisodeOrderby(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa):
  dVqTmhEDwvStsMuLkcxOUNrfIiPAGB=__addon__.getSetting('tving_orderby')
  if dVqTmhEDwvStsMuLkcxOUNrfIiPAGB in['',dVqTmhEDwvStsMuLkcxOUNrfIiPAWY]:dVqTmhEDwvStsMuLkcxOUNrfIiPAGB='desc'
  return dVqTmhEDwvStsMuLkcxOUNrfIiPAGB
 def add_dir(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa,label,sublabel='',img='',infoLabels=dVqTmhEDwvStsMuLkcxOUNrfIiPAWY,isFolder=dVqTmhEDwvStsMuLkcxOUNrfIiPAWb,params='',isLink=dVqTmhEDwvStsMuLkcxOUNrfIiPAWp,ContextMenu=dVqTmhEDwvStsMuLkcxOUNrfIiPAWY):
  dVqTmhEDwvStsMuLkcxOUNrfIiPAGY='%s?%s'%(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa._addon_url,urllib.parse.urlencode(params))
  if sublabel:dVqTmhEDwvStsMuLkcxOUNrfIiPAGa='%s < %s >'%(label,sublabel)
  else: dVqTmhEDwvStsMuLkcxOUNrfIiPAGa=label
  if not img:img='DefaultFolder.png'
  dVqTmhEDwvStsMuLkcxOUNrfIiPAGb=xbmcgui.ListItem(dVqTmhEDwvStsMuLkcxOUNrfIiPAGa)
  if dVqTmhEDwvStsMuLkcxOUNrfIiPAWX(img)==dVqTmhEDwvStsMuLkcxOUNrfIiPAWo:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGb.setArt(img)
  else:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGb.setArt({'thumb':img,'poster':img})
  if infoLabels:dVqTmhEDwvStsMuLkcxOUNrfIiPAGb.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGb.setProperty('IsPlayable','true')
  if ContextMenu:dVqTmhEDwvStsMuLkcxOUNrfIiPAGb.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa._addon_handle,dVqTmhEDwvStsMuLkcxOUNrfIiPAGY,dVqTmhEDwvStsMuLkcxOUNrfIiPAGb,isFolder)
 def get_selQuality(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa,etype):
  try:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGp='selected_quality'
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGX=[1080,720,480,360]
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGo=dVqTmhEDwvStsMuLkcxOUNrfIiPAWa(__addon__.getSetting(dVqTmhEDwvStsMuLkcxOUNrfIiPAGp))
   return dVqTmhEDwvStsMuLkcxOUNrfIiPAGX[dVqTmhEDwvStsMuLkcxOUNrfIiPAGo]
  except:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAWY
  return 720 
 def dp_Main_List(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa):
  (dVqTmhEDwvStsMuLkcxOUNrfIiPAGR,dVqTmhEDwvStsMuLkcxOUNrfIiPAGg,dVqTmhEDwvStsMuLkcxOUNrfIiPAGy,dVqTmhEDwvStsMuLkcxOUNrfIiPAGC,dVqTmhEDwvStsMuLkcxOUNrfIiPAGn)=dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.get_settings_totalsearch()
  for dVqTmhEDwvStsMuLkcxOUNrfIiPAGe in dVqTmhEDwvStsMuLkcxOUNrfIiPAFR:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGa=dVqTmhEDwvStsMuLkcxOUNrfIiPAGe.get('title')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGj=''
   if dVqTmhEDwvStsMuLkcxOUNrfIiPAGe.get('mode')=='SEARCH_GROUP' and dVqTmhEDwvStsMuLkcxOUNrfIiPAGR ==dVqTmhEDwvStsMuLkcxOUNrfIiPAWp:continue
   elif dVqTmhEDwvStsMuLkcxOUNrfIiPAGe.get('mode')=='SEARCH_HISTORY' and dVqTmhEDwvStsMuLkcxOUNrfIiPAGg==dVqTmhEDwvStsMuLkcxOUNrfIiPAWp:continue
   elif dVqTmhEDwvStsMuLkcxOUNrfIiPAGe.get('mode')=='TOTAL_SEARCH' and dVqTmhEDwvStsMuLkcxOUNrfIiPAGy ==dVqTmhEDwvStsMuLkcxOUNrfIiPAWp:continue
   elif dVqTmhEDwvStsMuLkcxOUNrfIiPAGe.get('mode')=='TOTAL_HISTORY' and dVqTmhEDwvStsMuLkcxOUNrfIiPAGC==dVqTmhEDwvStsMuLkcxOUNrfIiPAWp:continue
   elif dVqTmhEDwvStsMuLkcxOUNrfIiPAGe.get('mode')=='MENU_BOOKMARK' and dVqTmhEDwvStsMuLkcxOUNrfIiPAGn==dVqTmhEDwvStsMuLkcxOUNrfIiPAWp:continue
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGl={'mode':dVqTmhEDwvStsMuLkcxOUNrfIiPAGe.get('mode'),'stype':dVqTmhEDwvStsMuLkcxOUNrfIiPAGe.get('stype'),'orderby':dVqTmhEDwvStsMuLkcxOUNrfIiPAGe.get('orderby'),'ordernm':dVqTmhEDwvStsMuLkcxOUNrfIiPAGe.get('ordernm'),'page':'1'}
   if dVqTmhEDwvStsMuLkcxOUNrfIiPAGe.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    dVqTmhEDwvStsMuLkcxOUNrfIiPAGH=dVqTmhEDwvStsMuLkcxOUNrfIiPAWp
    dVqTmhEDwvStsMuLkcxOUNrfIiPAGJ =dVqTmhEDwvStsMuLkcxOUNrfIiPAWb
   else:
    dVqTmhEDwvStsMuLkcxOUNrfIiPAGH=dVqTmhEDwvStsMuLkcxOUNrfIiPAWb
    dVqTmhEDwvStsMuLkcxOUNrfIiPAGJ =dVqTmhEDwvStsMuLkcxOUNrfIiPAWp
   if 'icon' in dVqTmhEDwvStsMuLkcxOUNrfIiPAGe:dVqTmhEDwvStsMuLkcxOUNrfIiPAGj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',dVqTmhEDwvStsMuLkcxOUNrfIiPAGe.get('icon')) 
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.add_dir(dVqTmhEDwvStsMuLkcxOUNrfIiPAGa,sublabel='',img=dVqTmhEDwvStsMuLkcxOUNrfIiPAGj,infoLabels=dVqTmhEDwvStsMuLkcxOUNrfIiPAWY,isFolder=dVqTmhEDwvStsMuLkcxOUNrfIiPAGH,params=dVqTmhEDwvStsMuLkcxOUNrfIiPAGl,isLink=dVqTmhEDwvStsMuLkcxOUNrfIiPAGJ)
  xbmcplugin.endOfDirectory(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa._addon_handle)
 def login_main(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa):
  (dVqTmhEDwvStsMuLkcxOUNrfIiPAGQ,dVqTmhEDwvStsMuLkcxOUNrfIiPARF,dVqTmhEDwvStsMuLkcxOUNrfIiPARG,dVqTmhEDwvStsMuLkcxOUNrfIiPARg)=dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.get_settings_account()
  if not(dVqTmhEDwvStsMuLkcxOUNrfIiPAGQ and dVqTmhEDwvStsMuLkcxOUNrfIiPARF):
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFe=xbmcgui.Dialog()
   dVqTmhEDwvStsMuLkcxOUNrfIiPARy=dVqTmhEDwvStsMuLkcxOUNrfIiPAFe.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if dVqTmhEDwvStsMuLkcxOUNrfIiPARy==dVqTmhEDwvStsMuLkcxOUNrfIiPAWb:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   dVqTmhEDwvStsMuLkcxOUNrfIiPARC=0
   while dVqTmhEDwvStsMuLkcxOUNrfIiPAWb:
    dVqTmhEDwvStsMuLkcxOUNrfIiPARC+=1
    time.sleep(0.05)
    if dVqTmhEDwvStsMuLkcxOUNrfIiPARC>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  dVqTmhEDwvStsMuLkcxOUNrfIiPARn=dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.TvingObj.GetCredential(dVqTmhEDwvStsMuLkcxOUNrfIiPAGQ,dVqTmhEDwvStsMuLkcxOUNrfIiPARF,dVqTmhEDwvStsMuLkcxOUNrfIiPARG,dVqTmhEDwvStsMuLkcxOUNrfIiPARg)
  if dVqTmhEDwvStsMuLkcxOUNrfIiPARn:dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
  if dVqTmhEDwvStsMuLkcxOUNrfIiPARn==dVqTmhEDwvStsMuLkcxOUNrfIiPAWp:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa,dVqTmhEDwvStsMuLkcxOUNrfIiPARY):
  dVqTmhEDwvStsMuLkcxOUNrfIiPARW=dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('stype')
  if dVqTmhEDwvStsMuLkcxOUNrfIiPARW=='live':
   dVqTmhEDwvStsMuLkcxOUNrfIiPARK=dVqTmhEDwvStsMuLkcxOUNrfIiPAFg
  elif dVqTmhEDwvStsMuLkcxOUNrfIiPARW=='vod':
   dVqTmhEDwvStsMuLkcxOUNrfIiPARK=dVqTmhEDwvStsMuLkcxOUNrfIiPAFn
  else:
   dVqTmhEDwvStsMuLkcxOUNrfIiPARK=dVqTmhEDwvStsMuLkcxOUNrfIiPAFW
  for dVqTmhEDwvStsMuLkcxOUNrfIiPARB in dVqTmhEDwvStsMuLkcxOUNrfIiPARK:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGa=dVqTmhEDwvStsMuLkcxOUNrfIiPARB.get('title')
   if dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('ordernm')!='-':
    dVqTmhEDwvStsMuLkcxOUNrfIiPAGa+='  ('+dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('ordernm')+')'
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGl={'mode':dVqTmhEDwvStsMuLkcxOUNrfIiPARB.get('mode'),'stype':dVqTmhEDwvStsMuLkcxOUNrfIiPARB.get('stype'),'orderby':dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('orderby'),'ordernm':dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('ordernm'),'page':'1'}
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.add_dir(dVqTmhEDwvStsMuLkcxOUNrfIiPAGa,sublabel='',img='',infoLabels=dVqTmhEDwvStsMuLkcxOUNrfIiPAWY,isFolder=dVqTmhEDwvStsMuLkcxOUNrfIiPAWb,params=dVqTmhEDwvStsMuLkcxOUNrfIiPAGl)
  if dVqTmhEDwvStsMuLkcxOUNrfIiPAWe(dVqTmhEDwvStsMuLkcxOUNrfIiPARK)>0:xbmcplugin.endOfDirectory(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa._addon_handle)
 def dp_SubTitle_Group(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa,dVqTmhEDwvStsMuLkcxOUNrfIiPARY): 
  for dVqTmhEDwvStsMuLkcxOUNrfIiPARB in dVqTmhEDwvStsMuLkcxOUNrfIiPAFK:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGa=dVqTmhEDwvStsMuLkcxOUNrfIiPARB.get('title')
   if dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('ordernm')!='-':
    dVqTmhEDwvStsMuLkcxOUNrfIiPAGa+='  ('+dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('ordernm')+')'
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGl={'mode':dVqTmhEDwvStsMuLkcxOUNrfIiPARB.get('mode'),'genreCode':dVqTmhEDwvStsMuLkcxOUNrfIiPARB.get('genreCode'),'stype':dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('stype'),'orderby':dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('orderby'),'page':'1'}
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.add_dir(dVqTmhEDwvStsMuLkcxOUNrfIiPAGa,sublabel='',img='',infoLabels=dVqTmhEDwvStsMuLkcxOUNrfIiPAWY,isFolder=dVqTmhEDwvStsMuLkcxOUNrfIiPAWb,params=dVqTmhEDwvStsMuLkcxOUNrfIiPAGl)
  if dVqTmhEDwvStsMuLkcxOUNrfIiPAWe(dVqTmhEDwvStsMuLkcxOUNrfIiPAFK)>0:xbmcplugin.endOfDirectory(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa._addon_handle)
 def dp_LiveChannel_List(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa,dVqTmhEDwvStsMuLkcxOUNrfIiPARY):
  dVqTmhEDwvStsMuLkcxOUNrfIiPARW =dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('stype')
  dVqTmhEDwvStsMuLkcxOUNrfIiPARa =dVqTmhEDwvStsMuLkcxOUNrfIiPAWa(dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('page'))
  dVqTmhEDwvStsMuLkcxOUNrfIiPARb,dVqTmhEDwvStsMuLkcxOUNrfIiPARp=dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.TvingObj.GetLiveChannelList(dVqTmhEDwvStsMuLkcxOUNrfIiPARW,dVqTmhEDwvStsMuLkcxOUNrfIiPARa)
  for dVqTmhEDwvStsMuLkcxOUNrfIiPARX in dVqTmhEDwvStsMuLkcxOUNrfIiPARb:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGa =dVqTmhEDwvStsMuLkcxOUNrfIiPARX.get('title')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGz =dVqTmhEDwvStsMuLkcxOUNrfIiPARX.get('channel')
   dVqTmhEDwvStsMuLkcxOUNrfIiPARo =dVqTmhEDwvStsMuLkcxOUNrfIiPARX.get('thumbnail')
   dVqTmhEDwvStsMuLkcxOUNrfIiPARe =dVqTmhEDwvStsMuLkcxOUNrfIiPARX.get('synopsis')
   dVqTmhEDwvStsMuLkcxOUNrfIiPARj =dVqTmhEDwvStsMuLkcxOUNrfIiPARX.get('channelepg')
   dVqTmhEDwvStsMuLkcxOUNrfIiPARl =dVqTmhEDwvStsMuLkcxOUNrfIiPARX.get('cast')
   dVqTmhEDwvStsMuLkcxOUNrfIiPARH =dVqTmhEDwvStsMuLkcxOUNrfIiPARX.get('director')
   dVqTmhEDwvStsMuLkcxOUNrfIiPARJ =dVqTmhEDwvStsMuLkcxOUNrfIiPARX.get('info_genre')
   dVqTmhEDwvStsMuLkcxOUNrfIiPARz =dVqTmhEDwvStsMuLkcxOUNrfIiPARX.get('year')
   dVqTmhEDwvStsMuLkcxOUNrfIiPARQ =dVqTmhEDwvStsMuLkcxOUNrfIiPARX.get('mpaa')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAgF =dVqTmhEDwvStsMuLkcxOUNrfIiPARX.get('premiered')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAgG={'mediatype':'episode','title':dVqTmhEDwvStsMuLkcxOUNrfIiPAGa,'studio':dVqTmhEDwvStsMuLkcxOUNrfIiPAGz,'cast':dVqTmhEDwvStsMuLkcxOUNrfIiPARl,'director':dVqTmhEDwvStsMuLkcxOUNrfIiPARH,'genre':dVqTmhEDwvStsMuLkcxOUNrfIiPARJ,'plot':'%s\n%s\n%s\n\n%s'%(dVqTmhEDwvStsMuLkcxOUNrfIiPAGz,dVqTmhEDwvStsMuLkcxOUNrfIiPAGa,dVqTmhEDwvStsMuLkcxOUNrfIiPARj,dVqTmhEDwvStsMuLkcxOUNrfIiPARe),'year':dVqTmhEDwvStsMuLkcxOUNrfIiPARz,'mpaa':dVqTmhEDwvStsMuLkcxOUNrfIiPARQ,'premiered':dVqTmhEDwvStsMuLkcxOUNrfIiPAgF}
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGl={'mode':'LIVE','mediacode':dVqTmhEDwvStsMuLkcxOUNrfIiPARX.get('mediacode'),'stype':dVqTmhEDwvStsMuLkcxOUNrfIiPARW}
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.add_dir(dVqTmhEDwvStsMuLkcxOUNrfIiPAGz,sublabel=dVqTmhEDwvStsMuLkcxOUNrfIiPAGa,img=dVqTmhEDwvStsMuLkcxOUNrfIiPARo,infoLabels=dVqTmhEDwvStsMuLkcxOUNrfIiPAgG,isFolder=dVqTmhEDwvStsMuLkcxOUNrfIiPAWp,params=dVqTmhEDwvStsMuLkcxOUNrfIiPAGl)
  if dVqTmhEDwvStsMuLkcxOUNrfIiPARp:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGl['mode']='CHANNEL' 
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGl['stype']=dVqTmhEDwvStsMuLkcxOUNrfIiPARW 
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGl['page']=dVqTmhEDwvStsMuLkcxOUNrfIiPAWj(dVqTmhEDwvStsMuLkcxOUNrfIiPARa+1)
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGa='[B]%s >>[/B]'%'다음 페이지'
   dVqTmhEDwvStsMuLkcxOUNrfIiPAgR=dVqTmhEDwvStsMuLkcxOUNrfIiPAWj(dVqTmhEDwvStsMuLkcxOUNrfIiPARa+1)
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.add_dir(dVqTmhEDwvStsMuLkcxOUNrfIiPAGa,sublabel=dVqTmhEDwvStsMuLkcxOUNrfIiPAgR,img=dVqTmhEDwvStsMuLkcxOUNrfIiPAGj,infoLabels=dVqTmhEDwvStsMuLkcxOUNrfIiPAWY,isFolder=dVqTmhEDwvStsMuLkcxOUNrfIiPAWb,params=dVqTmhEDwvStsMuLkcxOUNrfIiPAGl)
  if dVqTmhEDwvStsMuLkcxOUNrfIiPAWe(dVqTmhEDwvStsMuLkcxOUNrfIiPARb)>0:xbmcplugin.endOfDirectory(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa._addon_handle,cacheToDisc=dVqTmhEDwvStsMuLkcxOUNrfIiPAWp)
 def dp_Program_List(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa,dVqTmhEDwvStsMuLkcxOUNrfIiPARY):
  dVqTmhEDwvStsMuLkcxOUNrfIiPAgy =dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('stype')
  dVqTmhEDwvStsMuLkcxOUNrfIiPAGB =dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('orderby')
  dVqTmhEDwvStsMuLkcxOUNrfIiPARa =dVqTmhEDwvStsMuLkcxOUNrfIiPAWa(dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('page'))
  dVqTmhEDwvStsMuLkcxOUNrfIiPAgC=dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('genreCode')
  if dVqTmhEDwvStsMuLkcxOUNrfIiPAgC==dVqTmhEDwvStsMuLkcxOUNrfIiPAWY:dVqTmhEDwvStsMuLkcxOUNrfIiPAgC='all'
  dVqTmhEDwvStsMuLkcxOUNrfIiPAgn,dVqTmhEDwvStsMuLkcxOUNrfIiPARp=dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.TvingObj.GetProgramList(dVqTmhEDwvStsMuLkcxOUNrfIiPAgy,dVqTmhEDwvStsMuLkcxOUNrfIiPAGB,dVqTmhEDwvStsMuLkcxOUNrfIiPARa,dVqTmhEDwvStsMuLkcxOUNrfIiPAgC)
  for dVqTmhEDwvStsMuLkcxOUNrfIiPAgW in dVqTmhEDwvStsMuLkcxOUNrfIiPAgn:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGa =dVqTmhEDwvStsMuLkcxOUNrfIiPAgW.get('title')
   dVqTmhEDwvStsMuLkcxOUNrfIiPARo =dVqTmhEDwvStsMuLkcxOUNrfIiPAgW.get('thumbnail')
   dVqTmhEDwvStsMuLkcxOUNrfIiPARe =dVqTmhEDwvStsMuLkcxOUNrfIiPAgW.get('synopsis')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAgK =dVqTmhEDwvStsMuLkcxOUNrfIiPAgW.get('channel')
   dVqTmhEDwvStsMuLkcxOUNrfIiPARl =dVqTmhEDwvStsMuLkcxOUNrfIiPAgW.get('cast')
   dVqTmhEDwvStsMuLkcxOUNrfIiPARH =dVqTmhEDwvStsMuLkcxOUNrfIiPAgW.get('director')
   dVqTmhEDwvStsMuLkcxOUNrfIiPARJ=dVqTmhEDwvStsMuLkcxOUNrfIiPAgW.get('info_genre')
   dVqTmhEDwvStsMuLkcxOUNrfIiPARz =dVqTmhEDwvStsMuLkcxOUNrfIiPAgW.get('year')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAgF =dVqTmhEDwvStsMuLkcxOUNrfIiPAgW.get('premiered')
   dVqTmhEDwvStsMuLkcxOUNrfIiPARQ =dVqTmhEDwvStsMuLkcxOUNrfIiPAgW.get('mpaa')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAgG={'mediatype':'tvshow','title':dVqTmhEDwvStsMuLkcxOUNrfIiPAGa,'studio':dVqTmhEDwvStsMuLkcxOUNrfIiPAgK,'cast':dVqTmhEDwvStsMuLkcxOUNrfIiPARl,'director':dVqTmhEDwvStsMuLkcxOUNrfIiPARH,'genre':dVqTmhEDwvStsMuLkcxOUNrfIiPARJ,'year':dVqTmhEDwvStsMuLkcxOUNrfIiPARz,'premiered':dVqTmhEDwvStsMuLkcxOUNrfIiPAgF,'mpaa':dVqTmhEDwvStsMuLkcxOUNrfIiPARQ,'plot':dVqTmhEDwvStsMuLkcxOUNrfIiPARe}
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGl={'mode':'EPISODE','programcode':dVqTmhEDwvStsMuLkcxOUNrfIiPAgW.get('program'),'page':'1'}
   if dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.get_settings_makebookmark():
    dVqTmhEDwvStsMuLkcxOUNrfIiPAgB={'videoid':dVqTmhEDwvStsMuLkcxOUNrfIiPAgW.get('program'),'vidtype':'tvshow','vtitle':dVqTmhEDwvStsMuLkcxOUNrfIiPAGa,'vsubtitle':dVqTmhEDwvStsMuLkcxOUNrfIiPAgK,}
    dVqTmhEDwvStsMuLkcxOUNrfIiPAgY=json.dumps(dVqTmhEDwvStsMuLkcxOUNrfIiPAgB)
    dVqTmhEDwvStsMuLkcxOUNrfIiPAgY=urllib.parse.quote(dVqTmhEDwvStsMuLkcxOUNrfIiPAgY)
    dVqTmhEDwvStsMuLkcxOUNrfIiPAga='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(dVqTmhEDwvStsMuLkcxOUNrfIiPAgY)
    dVqTmhEDwvStsMuLkcxOUNrfIiPAgb=[('(통합) 찜 영상에 추가',dVqTmhEDwvStsMuLkcxOUNrfIiPAga)]
   else:
    dVqTmhEDwvStsMuLkcxOUNrfIiPAgb=dVqTmhEDwvStsMuLkcxOUNrfIiPAWY
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.add_dir(dVqTmhEDwvStsMuLkcxOUNrfIiPAGa,sublabel=dVqTmhEDwvStsMuLkcxOUNrfIiPAgK,img=dVqTmhEDwvStsMuLkcxOUNrfIiPARo,infoLabels=dVqTmhEDwvStsMuLkcxOUNrfIiPAgG,isFolder=dVqTmhEDwvStsMuLkcxOUNrfIiPAWb,params=dVqTmhEDwvStsMuLkcxOUNrfIiPAGl,ContextMenu=dVqTmhEDwvStsMuLkcxOUNrfIiPAgb)
  if dVqTmhEDwvStsMuLkcxOUNrfIiPARp:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGl['mode'] ='PROGRAM' 
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGl['stype'] =dVqTmhEDwvStsMuLkcxOUNrfIiPAgy
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGl['orderby'] =dVqTmhEDwvStsMuLkcxOUNrfIiPAGB
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGl['page'] =dVqTmhEDwvStsMuLkcxOUNrfIiPAWj(dVqTmhEDwvStsMuLkcxOUNrfIiPARa+1)
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGl['genreCode']=dVqTmhEDwvStsMuLkcxOUNrfIiPAgC 
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGa='[B]%s >>[/B]'%'다음 페이지'
   dVqTmhEDwvStsMuLkcxOUNrfIiPAgR=dVqTmhEDwvStsMuLkcxOUNrfIiPAWj(dVqTmhEDwvStsMuLkcxOUNrfIiPARa+1)
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.add_dir(dVqTmhEDwvStsMuLkcxOUNrfIiPAGa,sublabel=dVqTmhEDwvStsMuLkcxOUNrfIiPAgR,img=dVqTmhEDwvStsMuLkcxOUNrfIiPAGj,infoLabels=dVqTmhEDwvStsMuLkcxOUNrfIiPAWY,isFolder=dVqTmhEDwvStsMuLkcxOUNrfIiPAWb,params=dVqTmhEDwvStsMuLkcxOUNrfIiPAGl)
  xbmcplugin.setContent(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa._addon_handle,cacheToDisc=dVqTmhEDwvStsMuLkcxOUNrfIiPAWp)
 def dp_Episode_List(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa,dVqTmhEDwvStsMuLkcxOUNrfIiPARY):
  dVqTmhEDwvStsMuLkcxOUNrfIiPAgX=dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('programcode')
  dVqTmhEDwvStsMuLkcxOUNrfIiPARa =dVqTmhEDwvStsMuLkcxOUNrfIiPAWa(dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('page'))
  dVqTmhEDwvStsMuLkcxOUNrfIiPAgo,dVqTmhEDwvStsMuLkcxOUNrfIiPARp,dVqTmhEDwvStsMuLkcxOUNrfIiPAge=dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.TvingObj.GetEpisodeList(dVqTmhEDwvStsMuLkcxOUNrfIiPAgX,dVqTmhEDwvStsMuLkcxOUNrfIiPARa,orderby=dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.get_winEpisodeOrderby())
  for dVqTmhEDwvStsMuLkcxOUNrfIiPAgj in dVqTmhEDwvStsMuLkcxOUNrfIiPAgo:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGa =dVqTmhEDwvStsMuLkcxOUNrfIiPAgj.get('title')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAgR =dVqTmhEDwvStsMuLkcxOUNrfIiPAgj.get('subtitle')
   dVqTmhEDwvStsMuLkcxOUNrfIiPARo =dVqTmhEDwvStsMuLkcxOUNrfIiPAgj.get('thumbnail')
   dVqTmhEDwvStsMuLkcxOUNrfIiPARe =dVqTmhEDwvStsMuLkcxOUNrfIiPAgj.get('synopsis')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAgl=dVqTmhEDwvStsMuLkcxOUNrfIiPAgj.get('info_title')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAgH =dVqTmhEDwvStsMuLkcxOUNrfIiPAgj.get('aired')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAgJ =dVqTmhEDwvStsMuLkcxOUNrfIiPAgj.get('studio')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAgz =dVqTmhEDwvStsMuLkcxOUNrfIiPAgj.get('frequency')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAgG={'mediatype':'episode','title':dVqTmhEDwvStsMuLkcxOUNrfIiPAgl,'aired':dVqTmhEDwvStsMuLkcxOUNrfIiPAgH,'studio':dVqTmhEDwvStsMuLkcxOUNrfIiPAgJ,'episode':dVqTmhEDwvStsMuLkcxOUNrfIiPAgz,'plot':dVqTmhEDwvStsMuLkcxOUNrfIiPARe}
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGl={'mode':'VOD','mediacode':dVqTmhEDwvStsMuLkcxOUNrfIiPAgj.get('episode'),'stype':'vod','programcode':dVqTmhEDwvStsMuLkcxOUNrfIiPAgX,'title':dVqTmhEDwvStsMuLkcxOUNrfIiPAGa,'thumbnail':dVqTmhEDwvStsMuLkcxOUNrfIiPARo}
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.add_dir(dVqTmhEDwvStsMuLkcxOUNrfIiPAGa,sublabel=dVqTmhEDwvStsMuLkcxOUNrfIiPAgR,img=dVqTmhEDwvStsMuLkcxOUNrfIiPARo,infoLabels=dVqTmhEDwvStsMuLkcxOUNrfIiPAgG,isFolder=dVqTmhEDwvStsMuLkcxOUNrfIiPAWp,params=dVqTmhEDwvStsMuLkcxOUNrfIiPAGl)
  if dVqTmhEDwvStsMuLkcxOUNrfIiPARa==1:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAgG={'plot':'정렬순서를 변경합니다.'}
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGl={}
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGl['mode'] ='ORDER_BY' 
   if dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.get_winEpisodeOrderby()=='desc':
    dVqTmhEDwvStsMuLkcxOUNrfIiPAGa='정렬순서변경 : 최신화부터 -> 1회부터'
    dVqTmhEDwvStsMuLkcxOUNrfIiPAGl['orderby']='asc'
   else:
    dVqTmhEDwvStsMuLkcxOUNrfIiPAGa='정렬순서변경 : 1회부터 -> 최신화부터'
    dVqTmhEDwvStsMuLkcxOUNrfIiPAGl['orderby']='desc'
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.add_dir(dVqTmhEDwvStsMuLkcxOUNrfIiPAGa,sublabel='',img=dVqTmhEDwvStsMuLkcxOUNrfIiPAGj,infoLabels=dVqTmhEDwvStsMuLkcxOUNrfIiPAgG,isFolder=dVqTmhEDwvStsMuLkcxOUNrfIiPAWp,params=dVqTmhEDwvStsMuLkcxOUNrfIiPAGl,isLink=dVqTmhEDwvStsMuLkcxOUNrfIiPAWb)
  if dVqTmhEDwvStsMuLkcxOUNrfIiPARp:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGl['mode'] ='EPISODE' 
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGl['programcode']=dVqTmhEDwvStsMuLkcxOUNrfIiPAgX
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGl['page'] =dVqTmhEDwvStsMuLkcxOUNrfIiPAWj(dVqTmhEDwvStsMuLkcxOUNrfIiPARa+1)
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGa='[B]%s >>[/B]'%'다음 페이지'
   dVqTmhEDwvStsMuLkcxOUNrfIiPAgR=dVqTmhEDwvStsMuLkcxOUNrfIiPAWj(dVqTmhEDwvStsMuLkcxOUNrfIiPARa+1)
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.add_dir(dVqTmhEDwvStsMuLkcxOUNrfIiPAGa,sublabel=dVqTmhEDwvStsMuLkcxOUNrfIiPAgR,img=dVqTmhEDwvStsMuLkcxOUNrfIiPAGj,infoLabels=dVqTmhEDwvStsMuLkcxOUNrfIiPAWY,isFolder=dVqTmhEDwvStsMuLkcxOUNrfIiPAWb,params=dVqTmhEDwvStsMuLkcxOUNrfIiPAGl)
  xbmcplugin.setContent(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa._addon_handle,'episodes')
  if dVqTmhEDwvStsMuLkcxOUNrfIiPAWe(dVqTmhEDwvStsMuLkcxOUNrfIiPAgo)>0:xbmcplugin.endOfDirectory(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa._addon_handle,cacheToDisc=dVqTmhEDwvStsMuLkcxOUNrfIiPAWb)
 def dp_setEpOrderby(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa,dVqTmhEDwvStsMuLkcxOUNrfIiPARY):
  dVqTmhEDwvStsMuLkcxOUNrfIiPAGB =dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('orderby')
  dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.set_winEpisodeOrderby(dVqTmhEDwvStsMuLkcxOUNrfIiPAGB)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa,dVqTmhEDwvStsMuLkcxOUNrfIiPARY):
  dVqTmhEDwvStsMuLkcxOUNrfIiPAgy =dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('stype')
  dVqTmhEDwvStsMuLkcxOUNrfIiPAGB =dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('orderby')
  dVqTmhEDwvStsMuLkcxOUNrfIiPARa=dVqTmhEDwvStsMuLkcxOUNrfIiPAWa(dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('page'))
  dVqTmhEDwvStsMuLkcxOUNrfIiPAgQ,dVqTmhEDwvStsMuLkcxOUNrfIiPARp=dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.TvingObj.GetMovieList(dVqTmhEDwvStsMuLkcxOUNrfIiPAgy,dVqTmhEDwvStsMuLkcxOUNrfIiPAGB,dVqTmhEDwvStsMuLkcxOUNrfIiPARa)
  for dVqTmhEDwvStsMuLkcxOUNrfIiPAyF in dVqTmhEDwvStsMuLkcxOUNrfIiPAgQ:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGa =dVqTmhEDwvStsMuLkcxOUNrfIiPAyF.get('title')
   dVqTmhEDwvStsMuLkcxOUNrfIiPARo =dVqTmhEDwvStsMuLkcxOUNrfIiPAyF.get('thumbnail')
   dVqTmhEDwvStsMuLkcxOUNrfIiPARe =dVqTmhEDwvStsMuLkcxOUNrfIiPAyF.get('synopsis')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAgl =dVqTmhEDwvStsMuLkcxOUNrfIiPAyF.get('info_title')
   dVqTmhEDwvStsMuLkcxOUNrfIiPARz =dVqTmhEDwvStsMuLkcxOUNrfIiPAyF.get('year')
   dVqTmhEDwvStsMuLkcxOUNrfIiPARl =dVqTmhEDwvStsMuLkcxOUNrfIiPAyF.get('cast')
   dVqTmhEDwvStsMuLkcxOUNrfIiPARH =dVqTmhEDwvStsMuLkcxOUNrfIiPAyF.get('director')
   dVqTmhEDwvStsMuLkcxOUNrfIiPARJ =dVqTmhEDwvStsMuLkcxOUNrfIiPAyF.get('info_genre')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAyG =dVqTmhEDwvStsMuLkcxOUNrfIiPAyF.get('duration')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAgF =dVqTmhEDwvStsMuLkcxOUNrfIiPAyF.get('premiered')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAgJ =dVqTmhEDwvStsMuLkcxOUNrfIiPAyF.get('studio')
   dVqTmhEDwvStsMuLkcxOUNrfIiPARQ =dVqTmhEDwvStsMuLkcxOUNrfIiPAyF.get('mpaa')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAgG={'mediatype':'movie','title':dVqTmhEDwvStsMuLkcxOUNrfIiPAgl,'year':dVqTmhEDwvStsMuLkcxOUNrfIiPARz,'cast':dVqTmhEDwvStsMuLkcxOUNrfIiPARl,'director':dVqTmhEDwvStsMuLkcxOUNrfIiPARH,'genre':dVqTmhEDwvStsMuLkcxOUNrfIiPARJ,'duration':dVqTmhEDwvStsMuLkcxOUNrfIiPAyG,'premiered':dVqTmhEDwvStsMuLkcxOUNrfIiPAgF,'studio':dVqTmhEDwvStsMuLkcxOUNrfIiPAgJ,'mpaa':dVqTmhEDwvStsMuLkcxOUNrfIiPARQ,'plot':dVqTmhEDwvStsMuLkcxOUNrfIiPARe}
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGl={'mode':'MOVIE','mediacode':dVqTmhEDwvStsMuLkcxOUNrfIiPAyF.get('moviecode'),'stype':'movie','title':dVqTmhEDwvStsMuLkcxOUNrfIiPAGa,'thumbnail':dVqTmhEDwvStsMuLkcxOUNrfIiPARo}
   if dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.get_settings_makebookmark():
    dVqTmhEDwvStsMuLkcxOUNrfIiPAgB={'videoid':dVqTmhEDwvStsMuLkcxOUNrfIiPAyF.get('moviecode'),'vidtype':'movie','vtitle':dVqTmhEDwvStsMuLkcxOUNrfIiPAgl,'vsubtitle':'',}
    dVqTmhEDwvStsMuLkcxOUNrfIiPAgY=json.dumps(dVqTmhEDwvStsMuLkcxOUNrfIiPAgB)
    dVqTmhEDwvStsMuLkcxOUNrfIiPAgY=urllib.parse.quote(dVqTmhEDwvStsMuLkcxOUNrfIiPAgY)
    dVqTmhEDwvStsMuLkcxOUNrfIiPAga='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(dVqTmhEDwvStsMuLkcxOUNrfIiPAgY)
    dVqTmhEDwvStsMuLkcxOUNrfIiPAgb=[('(통합) 찜 영상에 추가',dVqTmhEDwvStsMuLkcxOUNrfIiPAga)]
   else:
    dVqTmhEDwvStsMuLkcxOUNrfIiPAgb=dVqTmhEDwvStsMuLkcxOUNrfIiPAWY
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.add_dir(dVqTmhEDwvStsMuLkcxOUNrfIiPAGa,sublabel='',img=dVqTmhEDwvStsMuLkcxOUNrfIiPARo,infoLabels=dVqTmhEDwvStsMuLkcxOUNrfIiPAgG,isFolder=dVqTmhEDwvStsMuLkcxOUNrfIiPAWp,params=dVqTmhEDwvStsMuLkcxOUNrfIiPAGl,ContextMenu=dVqTmhEDwvStsMuLkcxOUNrfIiPAgb)
  if dVqTmhEDwvStsMuLkcxOUNrfIiPARp:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGl={}
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGl['mode'] ='MOVIE_SUB' 
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGl['orderby']=dVqTmhEDwvStsMuLkcxOUNrfIiPAGB
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGl['stype'] =dVqTmhEDwvStsMuLkcxOUNrfIiPAgy
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGl['page'] =dVqTmhEDwvStsMuLkcxOUNrfIiPAWj(dVqTmhEDwvStsMuLkcxOUNrfIiPARa+1)
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGa='[B]%s >>[/B]'%'다음 페이지'
   dVqTmhEDwvStsMuLkcxOUNrfIiPAgR=dVqTmhEDwvStsMuLkcxOUNrfIiPAWj(dVqTmhEDwvStsMuLkcxOUNrfIiPARa+1)
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.add_dir(dVqTmhEDwvStsMuLkcxOUNrfIiPAGa,sublabel=dVqTmhEDwvStsMuLkcxOUNrfIiPAgR,img=dVqTmhEDwvStsMuLkcxOUNrfIiPAGj,infoLabels=dVqTmhEDwvStsMuLkcxOUNrfIiPAWY,isFolder=dVqTmhEDwvStsMuLkcxOUNrfIiPAWb,params=dVqTmhEDwvStsMuLkcxOUNrfIiPAGl)
  xbmcplugin.setContent(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa._addon_handle,'movies')
  xbmcplugin.endOfDirectory(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa._addon_handle,cacheToDisc=dVqTmhEDwvStsMuLkcxOUNrfIiPAWp)
 def dp_Set_Bookmark(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa,dVqTmhEDwvStsMuLkcxOUNrfIiPARY):
  dVqTmhEDwvStsMuLkcxOUNrfIiPAyR=urllib.parse.unquote(dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('bm_param'))
  dVqTmhEDwvStsMuLkcxOUNrfIiPAyR=json.loads(dVqTmhEDwvStsMuLkcxOUNrfIiPAyR)
  dVqTmhEDwvStsMuLkcxOUNrfIiPAyg =dVqTmhEDwvStsMuLkcxOUNrfIiPAyR.get('videoid')
  dVqTmhEDwvStsMuLkcxOUNrfIiPAyC =dVqTmhEDwvStsMuLkcxOUNrfIiPAyR.get('vidtype')
  dVqTmhEDwvStsMuLkcxOUNrfIiPAyn =dVqTmhEDwvStsMuLkcxOUNrfIiPAyR.get('vtitle')
  dVqTmhEDwvStsMuLkcxOUNrfIiPAyW =dVqTmhEDwvStsMuLkcxOUNrfIiPAyR.get('vsubtitle')
  dVqTmhEDwvStsMuLkcxOUNrfIiPAFe=xbmcgui.Dialog()
  dVqTmhEDwvStsMuLkcxOUNrfIiPARy=dVqTmhEDwvStsMuLkcxOUNrfIiPAFe.yesno(__language__(30913).encode('utf8'),dVqTmhEDwvStsMuLkcxOUNrfIiPAyn+' \n\n'+__language__(30914))
  if dVqTmhEDwvStsMuLkcxOUNrfIiPARy==dVqTmhEDwvStsMuLkcxOUNrfIiPAWp:return
  dVqTmhEDwvStsMuLkcxOUNrfIiPAyK=dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.TvingObj.GetBookmarkInfo(dVqTmhEDwvStsMuLkcxOUNrfIiPAyg,dVqTmhEDwvStsMuLkcxOUNrfIiPAyC)
  if dVqTmhEDwvStsMuLkcxOUNrfIiPAyW!='':
   dVqTmhEDwvStsMuLkcxOUNrfIiPAyK['saveinfo']['subtitle']=dVqTmhEDwvStsMuLkcxOUNrfIiPAyW 
   if dVqTmhEDwvStsMuLkcxOUNrfIiPAyC=='tvshow':dVqTmhEDwvStsMuLkcxOUNrfIiPAyK['saveinfo']['infoLabels']['studio']=dVqTmhEDwvStsMuLkcxOUNrfIiPAyW 
  dVqTmhEDwvStsMuLkcxOUNrfIiPAyB=json.dumps(dVqTmhEDwvStsMuLkcxOUNrfIiPAyK)
  dVqTmhEDwvStsMuLkcxOUNrfIiPAyB=urllib.parse.quote(dVqTmhEDwvStsMuLkcxOUNrfIiPAyB)
  dVqTmhEDwvStsMuLkcxOUNrfIiPAga ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(dVqTmhEDwvStsMuLkcxOUNrfIiPAyB)
  xbmc.executebuiltin(dVqTmhEDwvStsMuLkcxOUNrfIiPAga)
 def dp_Search_Group(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa,dVqTmhEDwvStsMuLkcxOUNrfIiPARY):
  if 'search_key' in dVqTmhEDwvStsMuLkcxOUNrfIiPARY:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAyY=dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('search_key')
  else:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAyY=dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not dVqTmhEDwvStsMuLkcxOUNrfIiPAyY:
    return
  for dVqTmhEDwvStsMuLkcxOUNrfIiPARB in dVqTmhEDwvStsMuLkcxOUNrfIiPAFC:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAya =dVqTmhEDwvStsMuLkcxOUNrfIiPARB.get('mode')
   dVqTmhEDwvStsMuLkcxOUNrfIiPARW=dVqTmhEDwvStsMuLkcxOUNrfIiPARB.get('stype')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGa=dVqTmhEDwvStsMuLkcxOUNrfIiPARB.get('title')
   (dVqTmhEDwvStsMuLkcxOUNrfIiPAyb,dVqTmhEDwvStsMuLkcxOUNrfIiPARp)=dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.TvingObj.GetSearchList(dVqTmhEDwvStsMuLkcxOUNrfIiPAyY,1,dVqTmhEDwvStsMuLkcxOUNrfIiPARW)
   dVqTmhEDwvStsMuLkcxOUNrfIiPAyp={'plot':'검색어 : '+dVqTmhEDwvStsMuLkcxOUNrfIiPAyY+'\n\n'+dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.Search_FreeList(dVqTmhEDwvStsMuLkcxOUNrfIiPAyb)}
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGl={'mode':dVqTmhEDwvStsMuLkcxOUNrfIiPAya,'stype':dVqTmhEDwvStsMuLkcxOUNrfIiPARW,'search_key':dVqTmhEDwvStsMuLkcxOUNrfIiPAyY,'page':'1',}
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.add_dir(dVqTmhEDwvStsMuLkcxOUNrfIiPAGa,sublabel='',img='',infoLabels=dVqTmhEDwvStsMuLkcxOUNrfIiPAyp,isFolder=dVqTmhEDwvStsMuLkcxOUNrfIiPAWb,params=dVqTmhEDwvStsMuLkcxOUNrfIiPAGl)
  if dVqTmhEDwvStsMuLkcxOUNrfIiPAWe(dVqTmhEDwvStsMuLkcxOUNrfIiPAFC)>0:xbmcplugin.endOfDirectory(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa._addon_handle,cacheToDisc=dVqTmhEDwvStsMuLkcxOUNrfIiPAWb)
  dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.Save_Searched_List(dVqTmhEDwvStsMuLkcxOUNrfIiPAyY)
 def Search_FreeList(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa,dVqTmhEDwvStsMuLkcxOUNrfIiPAyQ):
  dVqTmhEDwvStsMuLkcxOUNrfIiPAyX=''
  dVqTmhEDwvStsMuLkcxOUNrfIiPAyo=7
  try:
   if dVqTmhEDwvStsMuLkcxOUNrfIiPAWe(dVqTmhEDwvStsMuLkcxOUNrfIiPAyQ)==0:return '검색결과 없음'
   for i in dVqTmhEDwvStsMuLkcxOUNrfIiPAWl(dVqTmhEDwvStsMuLkcxOUNrfIiPAWe(dVqTmhEDwvStsMuLkcxOUNrfIiPAyQ)):
    if i>=dVqTmhEDwvStsMuLkcxOUNrfIiPAyo:
     dVqTmhEDwvStsMuLkcxOUNrfIiPAyX=dVqTmhEDwvStsMuLkcxOUNrfIiPAyX+'...'
     break
    dVqTmhEDwvStsMuLkcxOUNrfIiPAyX=dVqTmhEDwvStsMuLkcxOUNrfIiPAyX+dVqTmhEDwvStsMuLkcxOUNrfIiPAyQ[i]['title']+'\n'
  except:
   return ''
  return dVqTmhEDwvStsMuLkcxOUNrfIiPAyX
 def dp_Search_History(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa,dVqTmhEDwvStsMuLkcxOUNrfIiPARY):
  dVqTmhEDwvStsMuLkcxOUNrfIiPAye=dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.Load_List_File('search')
  for dVqTmhEDwvStsMuLkcxOUNrfIiPAyj in dVqTmhEDwvStsMuLkcxOUNrfIiPAye:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAyl=dVqTmhEDwvStsMuLkcxOUNrfIiPAWo(urllib.parse.parse_qsl(dVqTmhEDwvStsMuLkcxOUNrfIiPAyj))
   dVqTmhEDwvStsMuLkcxOUNrfIiPAyH=dVqTmhEDwvStsMuLkcxOUNrfIiPAyl.get('skey').strip()
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGl={'mode':'SEARCH_GROUP','search_key':dVqTmhEDwvStsMuLkcxOUNrfIiPAyH,}
   dVqTmhEDwvStsMuLkcxOUNrfIiPAyJ={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':dVqTmhEDwvStsMuLkcxOUNrfIiPAyH,'vType':'-',}
   dVqTmhEDwvStsMuLkcxOUNrfIiPAyz=urllib.parse.urlencode(dVqTmhEDwvStsMuLkcxOUNrfIiPAyJ)
   dVqTmhEDwvStsMuLkcxOUNrfIiPAgb=[('선택된 검색어 ( %s ) 삭제'%(dVqTmhEDwvStsMuLkcxOUNrfIiPAyH),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(dVqTmhEDwvStsMuLkcxOUNrfIiPAyz))]
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.add_dir(dVqTmhEDwvStsMuLkcxOUNrfIiPAyH,sublabel='',img=dVqTmhEDwvStsMuLkcxOUNrfIiPAWY,infoLabels=dVqTmhEDwvStsMuLkcxOUNrfIiPAWY,isFolder=dVqTmhEDwvStsMuLkcxOUNrfIiPAWb,params=dVqTmhEDwvStsMuLkcxOUNrfIiPAGl,ContextMenu=dVqTmhEDwvStsMuLkcxOUNrfIiPAgb)
  dVqTmhEDwvStsMuLkcxOUNrfIiPAgG={'plot':'검색목록 전체를 삭제합니다.'}
  dVqTmhEDwvStsMuLkcxOUNrfIiPAGa='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  dVqTmhEDwvStsMuLkcxOUNrfIiPAGl={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  dVqTmhEDwvStsMuLkcxOUNrfIiPAGj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.add_dir(dVqTmhEDwvStsMuLkcxOUNrfIiPAGa,sublabel='',img=dVqTmhEDwvStsMuLkcxOUNrfIiPAGj,infoLabels=dVqTmhEDwvStsMuLkcxOUNrfIiPAgG,isFolder=dVqTmhEDwvStsMuLkcxOUNrfIiPAWp,params=dVqTmhEDwvStsMuLkcxOUNrfIiPAGl,isLink=dVqTmhEDwvStsMuLkcxOUNrfIiPAWb)
  xbmcplugin.endOfDirectory(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa._addon_handle,cacheToDisc=dVqTmhEDwvStsMuLkcxOUNrfIiPAWp)
 def dp_Search_List(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa,dVqTmhEDwvStsMuLkcxOUNrfIiPARY):
  dVqTmhEDwvStsMuLkcxOUNrfIiPARa =dVqTmhEDwvStsMuLkcxOUNrfIiPAWa(dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('page'))
  dVqTmhEDwvStsMuLkcxOUNrfIiPARW =dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('stype')
  if 'search_key' in dVqTmhEDwvStsMuLkcxOUNrfIiPARY:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAyY=dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('search_key')
  else:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAyY=dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not dVqTmhEDwvStsMuLkcxOUNrfIiPAyY:
    xbmcplugin.endOfDirectory(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa._addon_handle)
    return
  dVqTmhEDwvStsMuLkcxOUNrfIiPAyb,dVqTmhEDwvStsMuLkcxOUNrfIiPARp=dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.TvingObj.GetSearchList(dVqTmhEDwvStsMuLkcxOUNrfIiPAyY,dVqTmhEDwvStsMuLkcxOUNrfIiPARa,dVqTmhEDwvStsMuLkcxOUNrfIiPARW)
  for dVqTmhEDwvStsMuLkcxOUNrfIiPAyQ in dVqTmhEDwvStsMuLkcxOUNrfIiPAyb:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGa =dVqTmhEDwvStsMuLkcxOUNrfIiPAyQ.get('title')
   dVqTmhEDwvStsMuLkcxOUNrfIiPARo =dVqTmhEDwvStsMuLkcxOUNrfIiPAyQ.get('thumbnail')
   dVqTmhEDwvStsMuLkcxOUNrfIiPARe =dVqTmhEDwvStsMuLkcxOUNrfIiPAyQ.get('synopsis')
   dVqTmhEDwvStsMuLkcxOUNrfIiPACF =dVqTmhEDwvStsMuLkcxOUNrfIiPAyQ.get('program')
   dVqTmhEDwvStsMuLkcxOUNrfIiPARl =dVqTmhEDwvStsMuLkcxOUNrfIiPAyQ.get('cast')
   dVqTmhEDwvStsMuLkcxOUNrfIiPARH =dVqTmhEDwvStsMuLkcxOUNrfIiPAyQ.get('director')
   dVqTmhEDwvStsMuLkcxOUNrfIiPARJ=dVqTmhEDwvStsMuLkcxOUNrfIiPAyQ.get('info_genre')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAyG =dVqTmhEDwvStsMuLkcxOUNrfIiPAyQ.get('duration')
   dVqTmhEDwvStsMuLkcxOUNrfIiPARQ =dVqTmhEDwvStsMuLkcxOUNrfIiPAyQ.get('mpaa')
   dVqTmhEDwvStsMuLkcxOUNrfIiPARz =dVqTmhEDwvStsMuLkcxOUNrfIiPAyQ.get('year')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAgH =dVqTmhEDwvStsMuLkcxOUNrfIiPAyQ.get('aired')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAgG={'mediatype':'tvshow' if dVqTmhEDwvStsMuLkcxOUNrfIiPARW=='vod' else 'movie','title':dVqTmhEDwvStsMuLkcxOUNrfIiPAGa,'cast':dVqTmhEDwvStsMuLkcxOUNrfIiPARl,'director':dVqTmhEDwvStsMuLkcxOUNrfIiPARH,'genre':dVqTmhEDwvStsMuLkcxOUNrfIiPARJ,'duration':dVqTmhEDwvStsMuLkcxOUNrfIiPAyG,'mpaa':dVqTmhEDwvStsMuLkcxOUNrfIiPARQ,'year':dVqTmhEDwvStsMuLkcxOUNrfIiPARz,'aired':dVqTmhEDwvStsMuLkcxOUNrfIiPAgH,'plot':'%s\n\n%s'%(dVqTmhEDwvStsMuLkcxOUNrfIiPAGa,dVqTmhEDwvStsMuLkcxOUNrfIiPARe)}
   if dVqTmhEDwvStsMuLkcxOUNrfIiPARW=='vod':
    dVqTmhEDwvStsMuLkcxOUNrfIiPAyg=dVqTmhEDwvStsMuLkcxOUNrfIiPAyQ.get('program')
    dVqTmhEDwvStsMuLkcxOUNrfIiPAyC='tvshow'
    dVqTmhEDwvStsMuLkcxOUNrfIiPAGl={'mode':'EPISODE','programcode':dVqTmhEDwvStsMuLkcxOUNrfIiPAyg,'page':'1',}
    dVqTmhEDwvStsMuLkcxOUNrfIiPAGH=dVqTmhEDwvStsMuLkcxOUNrfIiPAWb
   else:
    dVqTmhEDwvStsMuLkcxOUNrfIiPAyg=dVqTmhEDwvStsMuLkcxOUNrfIiPAyQ.get('movie')
    dVqTmhEDwvStsMuLkcxOUNrfIiPAyC='movie'
    dVqTmhEDwvStsMuLkcxOUNrfIiPAGl={'mode':'MOVIE','mediacode':dVqTmhEDwvStsMuLkcxOUNrfIiPAyg,'stype':'movie','title':dVqTmhEDwvStsMuLkcxOUNrfIiPAGa,'thumbnail':dVqTmhEDwvStsMuLkcxOUNrfIiPARo,}
    dVqTmhEDwvStsMuLkcxOUNrfIiPAGH=dVqTmhEDwvStsMuLkcxOUNrfIiPAWp
   if dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.get_settings_makebookmark():
    dVqTmhEDwvStsMuLkcxOUNrfIiPAgB={'videoid':dVqTmhEDwvStsMuLkcxOUNrfIiPAyg,'vidtype':dVqTmhEDwvStsMuLkcxOUNrfIiPAyC,'vtitle':dVqTmhEDwvStsMuLkcxOUNrfIiPAGa,'vsubtitle':'',}
    dVqTmhEDwvStsMuLkcxOUNrfIiPAgY=json.dumps(dVqTmhEDwvStsMuLkcxOUNrfIiPAgB)
    dVqTmhEDwvStsMuLkcxOUNrfIiPAgY=urllib.parse.quote(dVqTmhEDwvStsMuLkcxOUNrfIiPAgY)
    dVqTmhEDwvStsMuLkcxOUNrfIiPAga='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(dVqTmhEDwvStsMuLkcxOUNrfIiPAgY)
    dVqTmhEDwvStsMuLkcxOUNrfIiPAgb=[('(통합) 찜 영상에 추가',dVqTmhEDwvStsMuLkcxOUNrfIiPAga)]
   else:
    dVqTmhEDwvStsMuLkcxOUNrfIiPAgb=dVqTmhEDwvStsMuLkcxOUNrfIiPAWY
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.add_dir(dVqTmhEDwvStsMuLkcxOUNrfIiPAGa,sublabel='',img=dVqTmhEDwvStsMuLkcxOUNrfIiPARo,infoLabels=dVqTmhEDwvStsMuLkcxOUNrfIiPAgG,isFolder=dVqTmhEDwvStsMuLkcxOUNrfIiPAGH,params=dVqTmhEDwvStsMuLkcxOUNrfIiPAGl,isLink=dVqTmhEDwvStsMuLkcxOUNrfIiPAWp,ContextMenu=dVqTmhEDwvStsMuLkcxOUNrfIiPAgb)
  if dVqTmhEDwvStsMuLkcxOUNrfIiPARp:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGl['mode'] ='SEARCH' 
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGl['search_key']=dVqTmhEDwvStsMuLkcxOUNrfIiPAyY
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGl['page'] =dVqTmhEDwvStsMuLkcxOUNrfIiPAWj(dVqTmhEDwvStsMuLkcxOUNrfIiPARa+1)
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGa='[B]%s >>[/B]'%'다음 페이지'
   dVqTmhEDwvStsMuLkcxOUNrfIiPAgR=dVqTmhEDwvStsMuLkcxOUNrfIiPAWj(dVqTmhEDwvStsMuLkcxOUNrfIiPARa+1)
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.add_dir(dVqTmhEDwvStsMuLkcxOUNrfIiPAGa,sublabel=dVqTmhEDwvStsMuLkcxOUNrfIiPAgR,img=dVqTmhEDwvStsMuLkcxOUNrfIiPAGj,infoLabels=dVqTmhEDwvStsMuLkcxOUNrfIiPAWY,isFolder=dVqTmhEDwvStsMuLkcxOUNrfIiPAWb,params=dVqTmhEDwvStsMuLkcxOUNrfIiPAGl)
  if dVqTmhEDwvStsMuLkcxOUNrfIiPARW=='movie':xbmcplugin.setContent(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa._addon_handle,'movies')
  else:xbmcplugin.setContent(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa._addon_handle,cacheToDisc=dVqTmhEDwvStsMuLkcxOUNrfIiPAWp)
 def dp_History_Remove(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa,dVqTmhEDwvStsMuLkcxOUNrfIiPARY):
  dVqTmhEDwvStsMuLkcxOUNrfIiPACG=dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('delType')
  dVqTmhEDwvStsMuLkcxOUNrfIiPACR =dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('sKey')
  dVqTmhEDwvStsMuLkcxOUNrfIiPACg =dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('vType')
  dVqTmhEDwvStsMuLkcxOUNrfIiPAFe=xbmcgui.Dialog()
  if dVqTmhEDwvStsMuLkcxOUNrfIiPACG=='SEARCH_ALL':
   dVqTmhEDwvStsMuLkcxOUNrfIiPARy=dVqTmhEDwvStsMuLkcxOUNrfIiPAFe.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif dVqTmhEDwvStsMuLkcxOUNrfIiPACG=='SEARCH_ONE':
   dVqTmhEDwvStsMuLkcxOUNrfIiPARy=dVqTmhEDwvStsMuLkcxOUNrfIiPAFe.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif dVqTmhEDwvStsMuLkcxOUNrfIiPACG=='WATCH_ALL':
   dVqTmhEDwvStsMuLkcxOUNrfIiPARy=dVqTmhEDwvStsMuLkcxOUNrfIiPAFe.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif dVqTmhEDwvStsMuLkcxOUNrfIiPACG=='WATCH_ONE':
   dVqTmhEDwvStsMuLkcxOUNrfIiPARy=dVqTmhEDwvStsMuLkcxOUNrfIiPAFe.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if dVqTmhEDwvStsMuLkcxOUNrfIiPARy==dVqTmhEDwvStsMuLkcxOUNrfIiPAWp:sys.exit()
  if dVqTmhEDwvStsMuLkcxOUNrfIiPACG=='SEARCH_ALL':
   if os.path.isfile(dVqTmhEDwvStsMuLkcxOUNrfIiPAFY):os.remove(dVqTmhEDwvStsMuLkcxOUNrfIiPAFY)
  elif dVqTmhEDwvStsMuLkcxOUNrfIiPACG=='SEARCH_ONE':
   try:
    dVqTmhEDwvStsMuLkcxOUNrfIiPACy=dVqTmhEDwvStsMuLkcxOUNrfIiPAFY
    dVqTmhEDwvStsMuLkcxOUNrfIiPACn=dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.Load_List_File('search') 
    fp=dVqTmhEDwvStsMuLkcxOUNrfIiPAWH(dVqTmhEDwvStsMuLkcxOUNrfIiPACy,'w',-1,'utf-8')
    for dVqTmhEDwvStsMuLkcxOUNrfIiPACW in dVqTmhEDwvStsMuLkcxOUNrfIiPACn:
     dVqTmhEDwvStsMuLkcxOUNrfIiPACK=dVqTmhEDwvStsMuLkcxOUNrfIiPAWo(urllib.parse.parse_qsl(dVqTmhEDwvStsMuLkcxOUNrfIiPACW))
     dVqTmhEDwvStsMuLkcxOUNrfIiPACB=dVqTmhEDwvStsMuLkcxOUNrfIiPACK.get('skey').strip()
     if dVqTmhEDwvStsMuLkcxOUNrfIiPACR!=dVqTmhEDwvStsMuLkcxOUNrfIiPACB:
      fp.write(dVqTmhEDwvStsMuLkcxOUNrfIiPACW)
    fp.close()
   except:
    dVqTmhEDwvStsMuLkcxOUNrfIiPAWY
  elif dVqTmhEDwvStsMuLkcxOUNrfIiPACG=='WATCH_ALL':
   dVqTmhEDwvStsMuLkcxOUNrfIiPACy=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%dVqTmhEDwvStsMuLkcxOUNrfIiPACg))
   if os.path.isfile(dVqTmhEDwvStsMuLkcxOUNrfIiPACy):os.remove(dVqTmhEDwvStsMuLkcxOUNrfIiPACy)
  elif dVqTmhEDwvStsMuLkcxOUNrfIiPACG=='WATCH_ONE':
   dVqTmhEDwvStsMuLkcxOUNrfIiPACy=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%dVqTmhEDwvStsMuLkcxOUNrfIiPACg))
   try:
    dVqTmhEDwvStsMuLkcxOUNrfIiPACn=dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.Load_List_File(dVqTmhEDwvStsMuLkcxOUNrfIiPACg) 
    fp=dVqTmhEDwvStsMuLkcxOUNrfIiPAWH(dVqTmhEDwvStsMuLkcxOUNrfIiPACy,'w',-1,'utf-8')
    for dVqTmhEDwvStsMuLkcxOUNrfIiPACW in dVqTmhEDwvStsMuLkcxOUNrfIiPACn:
     dVqTmhEDwvStsMuLkcxOUNrfIiPACK=dVqTmhEDwvStsMuLkcxOUNrfIiPAWo(urllib.parse.parse_qsl(dVqTmhEDwvStsMuLkcxOUNrfIiPACW))
     dVqTmhEDwvStsMuLkcxOUNrfIiPACB=dVqTmhEDwvStsMuLkcxOUNrfIiPACK.get('code').strip()
     if dVqTmhEDwvStsMuLkcxOUNrfIiPACR!=dVqTmhEDwvStsMuLkcxOUNrfIiPACB:
      fp.write(dVqTmhEDwvStsMuLkcxOUNrfIiPACW)
    fp.close()
   except:
    dVqTmhEDwvStsMuLkcxOUNrfIiPAWY
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa,dVqTmhEDwvStsMuLkcxOUNrfIiPARW): 
  try:
   if dVqTmhEDwvStsMuLkcxOUNrfIiPARW=='search':
    dVqTmhEDwvStsMuLkcxOUNrfIiPACy=dVqTmhEDwvStsMuLkcxOUNrfIiPAFY
   elif dVqTmhEDwvStsMuLkcxOUNrfIiPARW in['vod','movie']:
    dVqTmhEDwvStsMuLkcxOUNrfIiPACy=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%dVqTmhEDwvStsMuLkcxOUNrfIiPARW))
   else:
    return[]
   fp=dVqTmhEDwvStsMuLkcxOUNrfIiPAWH(dVqTmhEDwvStsMuLkcxOUNrfIiPACy,'r',-1,'utf-8')
   dVqTmhEDwvStsMuLkcxOUNrfIiPACY=fp.readlines()
   fp.close()
  except:
   dVqTmhEDwvStsMuLkcxOUNrfIiPACY=[]
  return dVqTmhEDwvStsMuLkcxOUNrfIiPACY
 def Save_Watched_List(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa,dVqTmhEDwvStsMuLkcxOUNrfIiPARW,dVqTmhEDwvStsMuLkcxOUNrfIiPAFX):
  try:
   dVqTmhEDwvStsMuLkcxOUNrfIiPACa=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%dVqTmhEDwvStsMuLkcxOUNrfIiPARW))
   dVqTmhEDwvStsMuLkcxOUNrfIiPACn=dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.Load_List_File(dVqTmhEDwvStsMuLkcxOUNrfIiPARW) 
   fp=dVqTmhEDwvStsMuLkcxOUNrfIiPAWH(dVqTmhEDwvStsMuLkcxOUNrfIiPACa,'w',-1,'utf-8')
   dVqTmhEDwvStsMuLkcxOUNrfIiPACb=urllib.parse.urlencode(dVqTmhEDwvStsMuLkcxOUNrfIiPAFX)
   dVqTmhEDwvStsMuLkcxOUNrfIiPACb=dVqTmhEDwvStsMuLkcxOUNrfIiPACb+'\n'
   fp.write(dVqTmhEDwvStsMuLkcxOUNrfIiPACb)
   dVqTmhEDwvStsMuLkcxOUNrfIiPACp=0
   for dVqTmhEDwvStsMuLkcxOUNrfIiPACW in dVqTmhEDwvStsMuLkcxOUNrfIiPACn:
    dVqTmhEDwvStsMuLkcxOUNrfIiPACK=dVqTmhEDwvStsMuLkcxOUNrfIiPAWo(urllib.parse.parse_qsl(dVqTmhEDwvStsMuLkcxOUNrfIiPACW))
    dVqTmhEDwvStsMuLkcxOUNrfIiPACX=dVqTmhEDwvStsMuLkcxOUNrfIiPAFX.get('code').strip()
    dVqTmhEDwvStsMuLkcxOUNrfIiPACo=dVqTmhEDwvStsMuLkcxOUNrfIiPACK.get('code').strip()
    if dVqTmhEDwvStsMuLkcxOUNrfIiPARW=='vod' and dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.get_settings_direct_replay()==dVqTmhEDwvStsMuLkcxOUNrfIiPAWb:
     dVqTmhEDwvStsMuLkcxOUNrfIiPACX=dVqTmhEDwvStsMuLkcxOUNrfIiPAFX.get('videoid').strip()
     dVqTmhEDwvStsMuLkcxOUNrfIiPACo=dVqTmhEDwvStsMuLkcxOUNrfIiPACK.get('videoid').strip()if dVqTmhEDwvStsMuLkcxOUNrfIiPACo!=dVqTmhEDwvStsMuLkcxOUNrfIiPAWY else '-'
    if dVqTmhEDwvStsMuLkcxOUNrfIiPACX!=dVqTmhEDwvStsMuLkcxOUNrfIiPACo:
     fp.write(dVqTmhEDwvStsMuLkcxOUNrfIiPACW)
     dVqTmhEDwvStsMuLkcxOUNrfIiPACp+=1
     if dVqTmhEDwvStsMuLkcxOUNrfIiPACp>=50:break
   fp.close()
  except:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAWY
 def dp_Watch_List(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa,dVqTmhEDwvStsMuLkcxOUNrfIiPARY):
  dVqTmhEDwvStsMuLkcxOUNrfIiPARW =dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('stype')
  dVqTmhEDwvStsMuLkcxOUNrfIiPAGW=dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.get_settings_direct_replay()
  if dVqTmhEDwvStsMuLkcxOUNrfIiPARW=='-':
   for dVqTmhEDwvStsMuLkcxOUNrfIiPARB in dVqTmhEDwvStsMuLkcxOUNrfIiPAFy:
    dVqTmhEDwvStsMuLkcxOUNrfIiPAGa=dVqTmhEDwvStsMuLkcxOUNrfIiPARB.get('title')
    dVqTmhEDwvStsMuLkcxOUNrfIiPAGl={'mode':dVqTmhEDwvStsMuLkcxOUNrfIiPARB.get('mode'),'stype':dVqTmhEDwvStsMuLkcxOUNrfIiPARB.get('stype')}
    dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.add_dir(dVqTmhEDwvStsMuLkcxOUNrfIiPAGa,sublabel='',img='',infoLabels=dVqTmhEDwvStsMuLkcxOUNrfIiPAWY,isFolder=dVqTmhEDwvStsMuLkcxOUNrfIiPAWb,params=dVqTmhEDwvStsMuLkcxOUNrfIiPAGl)
   if dVqTmhEDwvStsMuLkcxOUNrfIiPAWe(dVqTmhEDwvStsMuLkcxOUNrfIiPAFy)>0:xbmcplugin.endOfDirectory(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa._addon_handle)
  else:
   dVqTmhEDwvStsMuLkcxOUNrfIiPACe=dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.Load_List_File(dVqTmhEDwvStsMuLkcxOUNrfIiPARW)
   for dVqTmhEDwvStsMuLkcxOUNrfIiPACj in dVqTmhEDwvStsMuLkcxOUNrfIiPACe:
    dVqTmhEDwvStsMuLkcxOUNrfIiPAyl=dVqTmhEDwvStsMuLkcxOUNrfIiPAWo(urllib.parse.parse_qsl(dVqTmhEDwvStsMuLkcxOUNrfIiPACj))
    dVqTmhEDwvStsMuLkcxOUNrfIiPACl =dVqTmhEDwvStsMuLkcxOUNrfIiPAyl.get('code').strip()
    dVqTmhEDwvStsMuLkcxOUNrfIiPAGa =dVqTmhEDwvStsMuLkcxOUNrfIiPAyl.get('title').strip()
    dVqTmhEDwvStsMuLkcxOUNrfIiPARo=dVqTmhEDwvStsMuLkcxOUNrfIiPAyl.get('img').strip()
    dVqTmhEDwvStsMuLkcxOUNrfIiPAyg =dVqTmhEDwvStsMuLkcxOUNrfIiPAyl.get('videoid').strip()
    try:
     dVqTmhEDwvStsMuLkcxOUNrfIiPARo=dVqTmhEDwvStsMuLkcxOUNrfIiPARo.replace('\'','\"')
     dVqTmhEDwvStsMuLkcxOUNrfIiPARo=json.loads(dVqTmhEDwvStsMuLkcxOUNrfIiPARo)
    except:
     dVqTmhEDwvStsMuLkcxOUNrfIiPAWY
    dVqTmhEDwvStsMuLkcxOUNrfIiPAgG={}
    dVqTmhEDwvStsMuLkcxOUNrfIiPAgG['plot']=dVqTmhEDwvStsMuLkcxOUNrfIiPAGa
    if dVqTmhEDwvStsMuLkcxOUNrfIiPARW=='vod':
     if dVqTmhEDwvStsMuLkcxOUNrfIiPAGW==dVqTmhEDwvStsMuLkcxOUNrfIiPAWp or dVqTmhEDwvStsMuLkcxOUNrfIiPAyg==dVqTmhEDwvStsMuLkcxOUNrfIiPAWY:
      dVqTmhEDwvStsMuLkcxOUNrfIiPAGl={'mode':'EPISODE','programcode':dVqTmhEDwvStsMuLkcxOUNrfIiPACl,'page':'1'}
      dVqTmhEDwvStsMuLkcxOUNrfIiPAGH=dVqTmhEDwvStsMuLkcxOUNrfIiPAWb
     else:
      dVqTmhEDwvStsMuLkcxOUNrfIiPAGl={'mode':'VOD','mediacode':dVqTmhEDwvStsMuLkcxOUNrfIiPAyg,'stype':'vod','programcode':dVqTmhEDwvStsMuLkcxOUNrfIiPACl,'title':dVqTmhEDwvStsMuLkcxOUNrfIiPAGa,'thumbnail':dVqTmhEDwvStsMuLkcxOUNrfIiPARo}
      dVqTmhEDwvStsMuLkcxOUNrfIiPAGH=dVqTmhEDwvStsMuLkcxOUNrfIiPAWp
    else:
     dVqTmhEDwvStsMuLkcxOUNrfIiPAGl={'mode':'MOVIE','mediacode':dVqTmhEDwvStsMuLkcxOUNrfIiPACl,'stype':'movie','title':dVqTmhEDwvStsMuLkcxOUNrfIiPAGa,'thumbnail':dVqTmhEDwvStsMuLkcxOUNrfIiPARo}
     dVqTmhEDwvStsMuLkcxOUNrfIiPAGH=dVqTmhEDwvStsMuLkcxOUNrfIiPAWp
    dVqTmhEDwvStsMuLkcxOUNrfIiPAyJ={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':dVqTmhEDwvStsMuLkcxOUNrfIiPACl,'vType':dVqTmhEDwvStsMuLkcxOUNrfIiPARW,}
    dVqTmhEDwvStsMuLkcxOUNrfIiPAyz=urllib.parse.urlencode(dVqTmhEDwvStsMuLkcxOUNrfIiPAyJ)
    dVqTmhEDwvStsMuLkcxOUNrfIiPAgb=[('선택된 시청이력 ( %s ) 삭제'%(dVqTmhEDwvStsMuLkcxOUNrfIiPAGa),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(dVqTmhEDwvStsMuLkcxOUNrfIiPAyz))]
    dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.add_dir(dVqTmhEDwvStsMuLkcxOUNrfIiPAGa,sublabel='',img=dVqTmhEDwvStsMuLkcxOUNrfIiPARo,infoLabels=dVqTmhEDwvStsMuLkcxOUNrfIiPAgG,isFolder=dVqTmhEDwvStsMuLkcxOUNrfIiPAGH,params=dVqTmhEDwvStsMuLkcxOUNrfIiPAGl,ContextMenu=dVqTmhEDwvStsMuLkcxOUNrfIiPAgb)
   dVqTmhEDwvStsMuLkcxOUNrfIiPAgG={'plot':'시청목록을 삭제합니다.'}
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGa='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGl={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':dVqTmhEDwvStsMuLkcxOUNrfIiPARW,}
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.add_dir(dVqTmhEDwvStsMuLkcxOUNrfIiPAGa,sublabel='',img=dVqTmhEDwvStsMuLkcxOUNrfIiPAGj,infoLabels=dVqTmhEDwvStsMuLkcxOUNrfIiPAgG,isFolder=dVqTmhEDwvStsMuLkcxOUNrfIiPAWp,params=dVqTmhEDwvStsMuLkcxOUNrfIiPAGl,isLink=dVqTmhEDwvStsMuLkcxOUNrfIiPAWb)
   if dVqTmhEDwvStsMuLkcxOUNrfIiPARW=='movie':xbmcplugin.setContent(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa._addon_handle,'movies')
   else:xbmcplugin.setContent(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa._addon_handle,cacheToDisc=dVqTmhEDwvStsMuLkcxOUNrfIiPAWp)
 def Save_Searched_List(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa,dVqTmhEDwvStsMuLkcxOUNrfIiPAyY):
  try:
   dVqTmhEDwvStsMuLkcxOUNrfIiPACH=dVqTmhEDwvStsMuLkcxOUNrfIiPAFY
   dVqTmhEDwvStsMuLkcxOUNrfIiPACn=dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.Load_List_File('search') 
   dVqTmhEDwvStsMuLkcxOUNrfIiPACJ={'skey':dVqTmhEDwvStsMuLkcxOUNrfIiPAyY.strip()}
   fp=dVqTmhEDwvStsMuLkcxOUNrfIiPAWH(dVqTmhEDwvStsMuLkcxOUNrfIiPACH,'w',-1,'utf-8')
   dVqTmhEDwvStsMuLkcxOUNrfIiPACb=urllib.parse.urlencode(dVqTmhEDwvStsMuLkcxOUNrfIiPACJ)
   dVqTmhEDwvStsMuLkcxOUNrfIiPACb=dVqTmhEDwvStsMuLkcxOUNrfIiPACb+'\n'
   fp.write(dVqTmhEDwvStsMuLkcxOUNrfIiPACb)
   dVqTmhEDwvStsMuLkcxOUNrfIiPACp=0
   for dVqTmhEDwvStsMuLkcxOUNrfIiPACW in dVqTmhEDwvStsMuLkcxOUNrfIiPACn:
    dVqTmhEDwvStsMuLkcxOUNrfIiPACK=dVqTmhEDwvStsMuLkcxOUNrfIiPAWo(urllib.parse.parse_qsl(dVqTmhEDwvStsMuLkcxOUNrfIiPACW))
    dVqTmhEDwvStsMuLkcxOUNrfIiPACX=dVqTmhEDwvStsMuLkcxOUNrfIiPACJ.get('skey').strip()
    dVqTmhEDwvStsMuLkcxOUNrfIiPACo=dVqTmhEDwvStsMuLkcxOUNrfIiPACK.get('skey').strip()
    if dVqTmhEDwvStsMuLkcxOUNrfIiPACX!=dVqTmhEDwvStsMuLkcxOUNrfIiPACo:
     fp.write(dVqTmhEDwvStsMuLkcxOUNrfIiPACW)
     dVqTmhEDwvStsMuLkcxOUNrfIiPACp+=1
     if dVqTmhEDwvStsMuLkcxOUNrfIiPACp>=50:break
   fp.close()
  except:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAWY
 def play_VIDEO(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa,dVqTmhEDwvStsMuLkcxOUNrfIiPARY):
  dVqTmhEDwvStsMuLkcxOUNrfIiPACz =dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('mediacode')
  dVqTmhEDwvStsMuLkcxOUNrfIiPARW =dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('stype')
  dVqTmhEDwvStsMuLkcxOUNrfIiPACQ =dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('pvrmode')
  dVqTmhEDwvStsMuLkcxOUNrfIiPAnF=dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.get_selQuality(dVqTmhEDwvStsMuLkcxOUNrfIiPARW)
  dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(dVqTmhEDwvStsMuLkcxOUNrfIiPACz,dVqTmhEDwvStsMuLkcxOUNrfIiPAWj(dVqTmhEDwvStsMuLkcxOUNrfIiPAnF),dVqTmhEDwvStsMuLkcxOUNrfIiPARW,dVqTmhEDwvStsMuLkcxOUNrfIiPACQ))
  dVqTmhEDwvStsMuLkcxOUNrfIiPAnG=dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.TvingObj.GetBroadURL(dVqTmhEDwvStsMuLkcxOUNrfIiPACz,dVqTmhEDwvStsMuLkcxOUNrfIiPAnF,dVqTmhEDwvStsMuLkcxOUNrfIiPARW,dVqTmhEDwvStsMuLkcxOUNrfIiPACQ)
  dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.addon_log('qt, stype, url : %s - %s - %s'%(dVqTmhEDwvStsMuLkcxOUNrfIiPAWj(dVqTmhEDwvStsMuLkcxOUNrfIiPAnF),dVqTmhEDwvStsMuLkcxOUNrfIiPARW,dVqTmhEDwvStsMuLkcxOUNrfIiPAnG['streaming_url']))
  if dVqTmhEDwvStsMuLkcxOUNrfIiPAnG['streaming_url']=='':
   if dVqTmhEDwvStsMuLkcxOUNrfIiPAnG['error_msg']=='':
    dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.addon_noti(__language__(30908).encode('utf8'))
   else:
    dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.addon_noti(dVqTmhEDwvStsMuLkcxOUNrfIiPAnG['error_msg'].encode('utf8'))
   return
  dVqTmhEDwvStsMuLkcxOUNrfIiPAnR='user-agent={}'.format(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.TvingObj.USER_AGENT)
  if dVqTmhEDwvStsMuLkcxOUNrfIiPAnG['watermark'] !='':
   dVqTmhEDwvStsMuLkcxOUNrfIiPAnR='{}&x-tving-param1={}&x-tving-param2={}'.format(dVqTmhEDwvStsMuLkcxOUNrfIiPAnR,dVqTmhEDwvStsMuLkcxOUNrfIiPAnG['watermarkKey'],dVqTmhEDwvStsMuLkcxOUNrfIiPAnG['watermark'])
  dVqTmhEDwvStsMuLkcxOUNrfIiPAng =dVqTmhEDwvStsMuLkcxOUNrfIiPAWp
  dVqTmhEDwvStsMuLkcxOUNrfIiPAny =dVqTmhEDwvStsMuLkcxOUNrfIiPAnG['streaming_url'].find('Policy=')
  if dVqTmhEDwvStsMuLkcxOUNrfIiPAny!=-1:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAnC =dVqTmhEDwvStsMuLkcxOUNrfIiPAnG['streaming_url'].split('?')[0]
   dVqTmhEDwvStsMuLkcxOUNrfIiPAnW=dVqTmhEDwvStsMuLkcxOUNrfIiPAWo(urllib.parse.parse_qsl(urllib.parse.urlsplit(dVqTmhEDwvStsMuLkcxOUNrfIiPAnG['streaming_url']).query))
   dVqTmhEDwvStsMuLkcxOUNrfIiPAnK='CloudFront-Policy=%s;CloudFront-Signature=%s;CloudFront-Key-Pair-Id=%s'%(dVqTmhEDwvStsMuLkcxOUNrfIiPAnW['Policy'],dVqTmhEDwvStsMuLkcxOUNrfIiPAnW['Signature'],dVqTmhEDwvStsMuLkcxOUNrfIiPAnW['Key-Pair-Id'])
   if 'quickvod-mcdn.tving.com' in dVqTmhEDwvStsMuLkcxOUNrfIiPAnC:
    dVqTmhEDwvStsMuLkcxOUNrfIiPAng=dVqTmhEDwvStsMuLkcxOUNrfIiPAWb
    dVqTmhEDwvStsMuLkcxOUNrfIiPAnB =dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    dVqTmhEDwvStsMuLkcxOUNrfIiPAnY=dVqTmhEDwvStsMuLkcxOUNrfIiPAnB.strftime('%Y-%m-%d-%H:%M:%S')
    if dVqTmhEDwvStsMuLkcxOUNrfIiPAWa(dVqTmhEDwvStsMuLkcxOUNrfIiPAnY.replace('-','').replace(':',''))<dVqTmhEDwvStsMuLkcxOUNrfIiPAWa(dVqTmhEDwvStsMuLkcxOUNrfIiPAnW['end'].replace('-','').replace(':','')):
     dVqTmhEDwvStsMuLkcxOUNrfIiPAnW['end']=dVqTmhEDwvStsMuLkcxOUNrfIiPAnY
     dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.addon_noti(__language__(30915).encode('utf8'))
    dVqTmhEDwvStsMuLkcxOUNrfIiPAnC ='%s?%s'%(dVqTmhEDwvStsMuLkcxOUNrfIiPAnC,urllib.parse.urlencode(dVqTmhEDwvStsMuLkcxOUNrfIiPAnW,doseq=dVqTmhEDwvStsMuLkcxOUNrfIiPAWb))
   dVqTmhEDwvStsMuLkcxOUNrfIiPAna='{}|{}&Cookie={}'.format(dVqTmhEDwvStsMuLkcxOUNrfIiPAnC,dVqTmhEDwvStsMuLkcxOUNrfIiPAnR,dVqTmhEDwvStsMuLkcxOUNrfIiPAnK)
  else:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAna=dVqTmhEDwvStsMuLkcxOUNrfIiPAnG['streaming_url']+'|'+dVqTmhEDwvStsMuLkcxOUNrfIiPAnR
  dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.addon_log(dVqTmhEDwvStsMuLkcxOUNrfIiPAna)
  dVqTmhEDwvStsMuLkcxOUNrfIiPAnb=xbmcgui.ListItem(path=dVqTmhEDwvStsMuLkcxOUNrfIiPAna)
  if dVqTmhEDwvStsMuLkcxOUNrfIiPAnG['drm_license']!='':
   dVqTmhEDwvStsMuLkcxOUNrfIiPAnp=dVqTmhEDwvStsMuLkcxOUNrfIiPAnG['drm_license']
   dVqTmhEDwvStsMuLkcxOUNrfIiPAnX ='https://cj.drmkeyserver.com/widevine_license'
   dVqTmhEDwvStsMuLkcxOUNrfIiPAno ='mpd'
   dVqTmhEDwvStsMuLkcxOUNrfIiPAne ='com.widevine.alpha'
   dVqTmhEDwvStsMuLkcxOUNrfIiPAnj =inputstreamhelper.Helper(dVqTmhEDwvStsMuLkcxOUNrfIiPAno,drm='widevine')
   if dVqTmhEDwvStsMuLkcxOUNrfIiPAnj.check_inputstream():
    dVqTmhEDwvStsMuLkcxOUNrfIiPAnl={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.TvingObj.USER_AGENT,'AcquireLicenseAssertion':dVqTmhEDwvStsMuLkcxOUNrfIiPAnp,'Host':'cj.drmkeyserver.com',}
    dVqTmhEDwvStsMuLkcxOUNrfIiPAnH=dVqTmhEDwvStsMuLkcxOUNrfIiPAnX+'|'+urllib.parse.urlencode(dVqTmhEDwvStsMuLkcxOUNrfIiPAnl)+'|R{SSM}|'
    dVqTmhEDwvStsMuLkcxOUNrfIiPAnb.setProperty('inputstream',dVqTmhEDwvStsMuLkcxOUNrfIiPAnj.inputstream_addon)
    dVqTmhEDwvStsMuLkcxOUNrfIiPAnb.setProperty('inputstream.adaptive.manifest_type',dVqTmhEDwvStsMuLkcxOUNrfIiPAno)
    dVqTmhEDwvStsMuLkcxOUNrfIiPAnb.setProperty('inputstream.adaptive.license_type',dVqTmhEDwvStsMuLkcxOUNrfIiPAne)
    dVqTmhEDwvStsMuLkcxOUNrfIiPAnb.setProperty('inputstream.adaptive.license_key',dVqTmhEDwvStsMuLkcxOUNrfIiPAnH)
    dVqTmhEDwvStsMuLkcxOUNrfIiPAnb.setProperty('inputstream.adaptive.stream_headers',dVqTmhEDwvStsMuLkcxOUNrfIiPAnR)
  elif dVqTmhEDwvStsMuLkcxOUNrfIiPAng==dVqTmhEDwvStsMuLkcxOUNrfIiPAWb:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAnb.setContentLookup(dVqTmhEDwvStsMuLkcxOUNrfIiPAWp)
   dVqTmhEDwvStsMuLkcxOUNrfIiPAnb.setMimeType('application/x-mpegURL')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAnb.setProperty('inputstream','inputstream.ffmpegdirect')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAnb.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAnb.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAnb.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAnb.setProperty('ResumeTime','0')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAnb.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa._addon_handle,dVqTmhEDwvStsMuLkcxOUNrfIiPAWb,dVqTmhEDwvStsMuLkcxOUNrfIiPAnb)
  try:
   if dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('mode')in['VOD','MOVIE']and dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('title'):
    dVqTmhEDwvStsMuLkcxOUNrfIiPAGl={'code':dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('programcode')if dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('mode')=='VOD' else dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('mediacode'),'img':dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('thumbnail'),'title':dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('title'),'videoid':dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('mediacode')}
    dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.Save_Watched_List(dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('stype'),dVqTmhEDwvStsMuLkcxOUNrfIiPAGl)
  except:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAWY
 def logout(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa):
  dVqTmhEDwvStsMuLkcxOUNrfIiPAFe=xbmcgui.Dialog()
  dVqTmhEDwvStsMuLkcxOUNrfIiPARy=dVqTmhEDwvStsMuLkcxOUNrfIiPAFe.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if dVqTmhEDwvStsMuLkcxOUNrfIiPARy==dVqTmhEDwvStsMuLkcxOUNrfIiPAWp:sys.exit()
  dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.TvingObj.Init_TV_Total()
  if os.path.isfile(dVqTmhEDwvStsMuLkcxOUNrfIiPAFB):os.remove(dVqTmhEDwvStsMuLkcxOUNrfIiPAFB)
  dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa):
  dVqTmhEDwvStsMuLkcxOUNrfIiPAnJ =dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.TvingObj.Get_Now_Datetime()
  dVqTmhEDwvStsMuLkcxOUNrfIiPAnz=dVqTmhEDwvStsMuLkcxOUNrfIiPAnJ+datetime.timedelta(days=dVqTmhEDwvStsMuLkcxOUNrfIiPAWa(__addon__.getSetting('cache_ttl')))
  (dVqTmhEDwvStsMuLkcxOUNrfIiPAGQ,dVqTmhEDwvStsMuLkcxOUNrfIiPARF,dVqTmhEDwvStsMuLkcxOUNrfIiPARG,dVqTmhEDwvStsMuLkcxOUNrfIiPARg)=dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.get_settings_account()
  dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.TvingObj.Save_session_acount(dVqTmhEDwvStsMuLkcxOUNrfIiPAGQ,dVqTmhEDwvStsMuLkcxOUNrfIiPARF,dVqTmhEDwvStsMuLkcxOUNrfIiPARG,dVqTmhEDwvStsMuLkcxOUNrfIiPARg)
  dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.TvingObj.TV['account']['token_limit']=dVqTmhEDwvStsMuLkcxOUNrfIiPAnz.strftime('%Y%m%d')
  dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.TvingObj.JsonFile_Save(dVqTmhEDwvStsMuLkcxOUNrfIiPAFB,dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.TvingObj.TV)
 def cookiefile_check(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa):
  dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.TvingObj.TV=dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.TvingObj.JsonFile_Load(dVqTmhEDwvStsMuLkcxOUNrfIiPAFB)
  if 'account' not in dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.TvingObj.TV:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.TvingObj.Init_TV_Total()
   return dVqTmhEDwvStsMuLkcxOUNrfIiPAWp
  (dVqTmhEDwvStsMuLkcxOUNrfIiPAnQ,dVqTmhEDwvStsMuLkcxOUNrfIiPAWF,dVqTmhEDwvStsMuLkcxOUNrfIiPAWG,dVqTmhEDwvStsMuLkcxOUNrfIiPAWR)=dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.get_settings_account()
  (dVqTmhEDwvStsMuLkcxOUNrfIiPAWg,dVqTmhEDwvStsMuLkcxOUNrfIiPAWy,dVqTmhEDwvStsMuLkcxOUNrfIiPAWC,dVqTmhEDwvStsMuLkcxOUNrfIiPAWn)=dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.TvingObj.Load_session_acount()
  if dVqTmhEDwvStsMuLkcxOUNrfIiPAnQ!=dVqTmhEDwvStsMuLkcxOUNrfIiPAWg or dVqTmhEDwvStsMuLkcxOUNrfIiPAWF!=dVqTmhEDwvStsMuLkcxOUNrfIiPAWy or dVqTmhEDwvStsMuLkcxOUNrfIiPAWG!=dVqTmhEDwvStsMuLkcxOUNrfIiPAWC or dVqTmhEDwvStsMuLkcxOUNrfIiPAWR!=dVqTmhEDwvStsMuLkcxOUNrfIiPAWn:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.TvingObj.Init_TV_Total()
   return dVqTmhEDwvStsMuLkcxOUNrfIiPAWp
  if dVqTmhEDwvStsMuLkcxOUNrfIiPAWa(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>dVqTmhEDwvStsMuLkcxOUNrfIiPAWa(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.TvingObj.TV['account']['token_limit']):
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.TvingObj.Init_TV_Total()
   return dVqTmhEDwvStsMuLkcxOUNrfIiPAWp
  return dVqTmhEDwvStsMuLkcxOUNrfIiPAWb
 def dp_Global_Search(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa,dVqTmhEDwvStsMuLkcxOUNrfIiPARY):
  dVqTmhEDwvStsMuLkcxOUNrfIiPAya=dVqTmhEDwvStsMuLkcxOUNrfIiPARY.get('mode')
  if dVqTmhEDwvStsMuLkcxOUNrfIiPAya=='TOTAL_SEARCH':
   dVqTmhEDwvStsMuLkcxOUNrfIiPAWK='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAWK='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(dVqTmhEDwvStsMuLkcxOUNrfIiPAWK)
 def dp_Bookmark_Menu(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa,dVqTmhEDwvStsMuLkcxOUNrfIiPARY):
  dVqTmhEDwvStsMuLkcxOUNrfIiPAWK='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(dVqTmhEDwvStsMuLkcxOUNrfIiPAWK)
 def dp_EuroLive_List(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa,dVqTmhEDwvStsMuLkcxOUNrfIiPARY):
  dVqTmhEDwvStsMuLkcxOUNrfIiPARb=dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.TvingObj.GetEuroChannelList()
  for dVqTmhEDwvStsMuLkcxOUNrfIiPARX in dVqTmhEDwvStsMuLkcxOUNrfIiPARb:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAgK =dVqTmhEDwvStsMuLkcxOUNrfIiPARX.get('channel')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGa =dVqTmhEDwvStsMuLkcxOUNrfIiPARX.get('title')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAgR =dVqTmhEDwvStsMuLkcxOUNrfIiPARX.get('subtitle')
   dVqTmhEDwvStsMuLkcxOUNrfIiPAgG={'mediatype':'episode','title':dVqTmhEDwvStsMuLkcxOUNrfIiPAGa,'plot':'%s\n%s'%(dVqTmhEDwvStsMuLkcxOUNrfIiPAGa,dVqTmhEDwvStsMuLkcxOUNrfIiPAgR)}
   dVqTmhEDwvStsMuLkcxOUNrfIiPAGl={'mode':'LIVE','mediacode':dVqTmhEDwvStsMuLkcxOUNrfIiPAgK,'stype':'onair',}
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.add_dir(dVqTmhEDwvStsMuLkcxOUNrfIiPAGa,sublabel=dVqTmhEDwvStsMuLkcxOUNrfIiPAgR,img='',infoLabels=dVqTmhEDwvStsMuLkcxOUNrfIiPAgG,isFolder=dVqTmhEDwvStsMuLkcxOUNrfIiPAWp,params=dVqTmhEDwvStsMuLkcxOUNrfIiPAGl)
  if dVqTmhEDwvStsMuLkcxOUNrfIiPAWe(dVqTmhEDwvStsMuLkcxOUNrfIiPARb)>0:xbmcplugin.endOfDirectory(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa._addon_handle,cacheToDisc=dVqTmhEDwvStsMuLkcxOUNrfIiPAWp)
 def tving_main(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa):
  dVqTmhEDwvStsMuLkcxOUNrfIiPAya=dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.main_params.get('mode',dVqTmhEDwvStsMuLkcxOUNrfIiPAWY)
  if dVqTmhEDwvStsMuLkcxOUNrfIiPAya=='LOGOUT':
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.logout()
   return
  dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.login_main()
  if dVqTmhEDwvStsMuLkcxOUNrfIiPAya is dVqTmhEDwvStsMuLkcxOUNrfIiPAWY:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.dp_Main_List()
  elif dVqTmhEDwvStsMuLkcxOUNrfIiPAya in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.dp_Title_Group(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.main_params)
  elif dVqTmhEDwvStsMuLkcxOUNrfIiPAya in['GLOBAL_GROUP']:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.dp_SubTitle_Group(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.main_params)
  elif dVqTmhEDwvStsMuLkcxOUNrfIiPAya=='CHANNEL':
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.dp_LiveChannel_List(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.main_params)
  elif dVqTmhEDwvStsMuLkcxOUNrfIiPAya in['LIVE','VOD','MOVIE']:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.play_VIDEO(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.main_params)
  elif dVqTmhEDwvStsMuLkcxOUNrfIiPAya=='PROGRAM':
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.dp_Program_List(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.main_params)
  elif dVqTmhEDwvStsMuLkcxOUNrfIiPAya=='EPISODE':
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.dp_Episode_List(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.main_params)
  elif dVqTmhEDwvStsMuLkcxOUNrfIiPAya=='MOVIE_SUB':
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.dp_Movie_List(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.main_params)
  elif dVqTmhEDwvStsMuLkcxOUNrfIiPAya=='SEARCH_GROUP':
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.dp_Search_Group(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.main_params)
  elif dVqTmhEDwvStsMuLkcxOUNrfIiPAya in['SEARCH','LOCAL_SEARCH']:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.dp_Search_List(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.main_params)
  elif dVqTmhEDwvStsMuLkcxOUNrfIiPAya=='WATCH':
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.dp_Watch_List(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.main_params)
  elif dVqTmhEDwvStsMuLkcxOUNrfIiPAya in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.dp_History_Remove(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.main_params)
  elif dVqTmhEDwvStsMuLkcxOUNrfIiPAya=='ORDER_BY':
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.dp_setEpOrderby(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.main_params)
  elif dVqTmhEDwvStsMuLkcxOUNrfIiPAya=='SET_BOOKMARK':
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.dp_Set_Bookmark(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.main_params)
  elif dVqTmhEDwvStsMuLkcxOUNrfIiPAya in['TOTAL_SEARCH','TOTAL_HISTORY']:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.dp_Global_Search(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.main_params)
  elif dVqTmhEDwvStsMuLkcxOUNrfIiPAya=='SEARCH_HISTORY':
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.dp_Search_History(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.main_params)
  elif dVqTmhEDwvStsMuLkcxOUNrfIiPAya=='MENU_BOOKMARK':
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.dp_Bookmark_Menu(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.main_params)
  elif dVqTmhEDwvStsMuLkcxOUNrfIiPAya=='EURO_GROUP':
   dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.dp_EuroLive_List(dVqTmhEDwvStsMuLkcxOUNrfIiPAFa.main_params)
  else:
   dVqTmhEDwvStsMuLkcxOUNrfIiPAWY
# Created by pyminifier (https://github.com/liftoff/pyminifier)
