__author__="NightRain"
ctsidPMphTlQCaSVqAOxLrKHNwDRUo=ImportError
ctsidPMphTlQCaSVqAOxLrKHNwDRUX=object
ctsidPMphTlQCaSVqAOxLrKHNwDRUk=None
ctsidPMphTlQCaSVqAOxLrKHNwDRUY=False
ctsidPMphTlQCaSVqAOxLrKHNwDRUf=open
ctsidPMphTlQCaSVqAOxLrKHNwDRUG=True
ctsidPMphTlQCaSVqAOxLrKHNwDRUJ=int
ctsidPMphTlQCaSVqAOxLrKHNwDRUm=range
ctsidPMphTlQCaSVqAOxLrKHNwDRUE=print
ctsidPMphTlQCaSVqAOxLrKHNwDRUW=Exception
ctsidPMphTlQCaSVqAOxLrKHNwDRUz=len
ctsidPMphTlQCaSVqAOxLrKHNwDRUv=str
ctsidPMphTlQCaSVqAOxLrKHNwDRUj=list
ctsidPMphTlQCaSVqAOxLrKHNwDRUB=bytes
ctsidPMphTlQCaSVqAOxLrKHNwDRUg=ord
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
try:
 from Cryptodome.PublicKey import RSA
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
except ctsidPMphTlQCaSVqAOxLrKHNwDRUo:
 from Crypto.PublicKey import RSA
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
ctsidPMphTlQCaSVqAOxLrKHNwDReb={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
ctsidPMphTlQCaSVqAOxLrKHNwDReF ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
class ctsidPMphTlQCaSVqAOxLrKHNwDReI(ctsidPMphTlQCaSVqAOxLrKHNwDRUX):
 def __init__(ctsidPMphTlQCaSVqAOxLrKHNwDRen):
  ctsidPMphTlQCaSVqAOxLrKHNwDRen.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  ctsidPMphTlQCaSVqAOxLrKHNwDRen.NETWORKCODE ='CSND0900'
  ctsidPMphTlQCaSVqAOxLrKHNwDRen.OSCODE ='CSOD0900' 
  ctsidPMphTlQCaSVqAOxLrKHNwDRen.TELECODE ='CSCD0900'
  ctsidPMphTlQCaSVqAOxLrKHNwDRen.SCREENCODE ='CSSD0100'
  ctsidPMphTlQCaSVqAOxLrKHNwDRen.LIVE_LIMIT =20 
  ctsidPMphTlQCaSVqAOxLrKHNwDRen.VOD_LIMIT =24 
  ctsidPMphTlQCaSVqAOxLrKHNwDRen.EPISODE_LIMIT =30 
  ctsidPMphTlQCaSVqAOxLrKHNwDRen.SEARCH_LIMIT =30 
  ctsidPMphTlQCaSVqAOxLrKHNwDRen.MOVIE_LIMIT =24 
  ctsidPMphTlQCaSVqAOxLrKHNwDRen.API_DOMAIN ='https://api.tving.com'
  ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN ='https://image.tving.com'
  ctsidPMphTlQCaSVqAOxLrKHNwDRen.SEARCH_DOMAIN ='https://search.tving.com'
  ctsidPMphTlQCaSVqAOxLrKHNwDRen.LOGIN_DOMAIN ='https://user.tving.com'
  ctsidPMphTlQCaSVqAOxLrKHNwDRen.URL_DOMAIN ='https://www.tving.com'
  ctsidPMphTlQCaSVqAOxLrKHNwDRen.MOVIE_LITE =['2610061','2610161','261062']
  ctsidPMphTlQCaSVqAOxLrKHNwDRen.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36'
  ctsidPMphTlQCaSVqAOxLrKHNwDRen.DEFAULT_HEADER ={'user-agent':ctsidPMphTlQCaSVqAOxLrKHNwDRen.USER_AGENT}
  ctsidPMphTlQCaSVqAOxLrKHNwDRen.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
  ctsidPMphTlQCaSVqAOxLrKHNwDRen.TV_SESSION_COOKIES1=''
  ctsidPMphTlQCaSVqAOxLrKHNwDRen.TV_SESSION_COOKIES2=''
  ctsidPMphTlQCaSVqAOxLrKHNwDRen.TV ={}
  ctsidPMphTlQCaSVqAOxLrKHNwDRen.Init_TV_Total()
 def Init_TV_Total(ctsidPMphTlQCaSVqAOxLrKHNwDRen):
  ctsidPMphTlQCaSVqAOxLrKHNwDRen.TV={'account':{},'cookies':{'tving_token':'','tving_userinfo':'','tving_uuid':'-','tving_maintoken':'','tving_cookiekey':'Y','tving_lockkey':'N',},}
 def callRequestCookies(ctsidPMphTlQCaSVqAOxLrKHNwDRen,jobtype,ctsidPMphTlQCaSVqAOxLrKHNwDRIy,payload=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,params=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,headers=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,cookies=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,redirects=ctsidPMphTlQCaSVqAOxLrKHNwDRUY):
  ctsidPMphTlQCaSVqAOxLrKHNwDReU=ctsidPMphTlQCaSVqAOxLrKHNwDRen.DEFAULT_HEADER
  if headers:ctsidPMphTlQCaSVqAOxLrKHNwDReU.update(headers)
  if jobtype=='Get':
   ctsidPMphTlQCaSVqAOxLrKHNwDReo=requests.get(ctsidPMphTlQCaSVqAOxLrKHNwDRIy,params=params,headers=ctsidPMphTlQCaSVqAOxLrKHNwDReU,cookies=cookies,allow_redirects=redirects)
  else:
   ctsidPMphTlQCaSVqAOxLrKHNwDReo=requests.post(ctsidPMphTlQCaSVqAOxLrKHNwDRIy,data=payload,params=params,headers=ctsidPMphTlQCaSVqAOxLrKHNwDReU,cookies=cookies,allow_redirects=redirects)
  return ctsidPMphTlQCaSVqAOxLrKHNwDReo
 def JsonFile_Save(ctsidPMphTlQCaSVqAOxLrKHNwDRen,filename,ctsidPMphTlQCaSVqAOxLrKHNwDReX):
  if filename=='':return ctsidPMphTlQCaSVqAOxLrKHNwDRUY
  try:
   fp=ctsidPMphTlQCaSVqAOxLrKHNwDRUf(filename,'w',-1,'utf-8')
   json.dump(ctsidPMphTlQCaSVqAOxLrKHNwDReX,fp,indent=4,ensure_ascii=ctsidPMphTlQCaSVqAOxLrKHNwDRUY)
   fp.close()
  except:
   return ctsidPMphTlQCaSVqAOxLrKHNwDRUY
  return ctsidPMphTlQCaSVqAOxLrKHNwDRUG
 def JsonFile_Load(ctsidPMphTlQCaSVqAOxLrKHNwDRen,filename):
  if filename=='':return{}
  try:
   fp=ctsidPMphTlQCaSVqAOxLrKHNwDRUf(filename,'r',-1,'utf-8')
   ctsidPMphTlQCaSVqAOxLrKHNwDReY=json.load(fp)
   fp.close()
  except:
   return{}
  return ctsidPMphTlQCaSVqAOxLrKHNwDReY
 def Save_session_acount(ctsidPMphTlQCaSVqAOxLrKHNwDRen,ctsidPMphTlQCaSVqAOxLrKHNwDRef,ctsidPMphTlQCaSVqAOxLrKHNwDReG,ctsidPMphTlQCaSVqAOxLrKHNwDReJ,ctsidPMphTlQCaSVqAOxLrKHNwDRem):
  ctsidPMphTlQCaSVqAOxLrKHNwDRen.TV['account']['tvid'] =base64.standard_b64encode(ctsidPMphTlQCaSVqAOxLrKHNwDRef.encode()).decode('utf-8')
  ctsidPMphTlQCaSVqAOxLrKHNwDRen.TV['account']['tvpw'] =base64.standard_b64encode(ctsidPMphTlQCaSVqAOxLrKHNwDReG.encode()).decode('utf-8')
  ctsidPMphTlQCaSVqAOxLrKHNwDRen.TV['account']['tvtype']=ctsidPMphTlQCaSVqAOxLrKHNwDReJ 
  ctsidPMphTlQCaSVqAOxLrKHNwDRen.TV['account']['tvpf'] =ctsidPMphTlQCaSVqAOxLrKHNwDRem 
 def Load_session_acount(ctsidPMphTlQCaSVqAOxLrKHNwDRen):
  try:
   ctsidPMphTlQCaSVqAOxLrKHNwDRef =base64.standard_b64decode(ctsidPMphTlQCaSVqAOxLrKHNwDRen.TV['account']['tvid']).decode('utf-8')
   ctsidPMphTlQCaSVqAOxLrKHNwDReG =base64.standard_b64decode(ctsidPMphTlQCaSVqAOxLrKHNwDRen.TV['account']['tvpw']).decode('utf-8')
   ctsidPMphTlQCaSVqAOxLrKHNwDReJ=ctsidPMphTlQCaSVqAOxLrKHNwDRen.TV['account']['tvtype']
   ctsidPMphTlQCaSVqAOxLrKHNwDRem =ctsidPMphTlQCaSVqAOxLrKHNwDRen.TV['account']['tvpf'] 
  except:
   return '','','0',0
  return ctsidPMphTlQCaSVqAOxLrKHNwDRef,ctsidPMphTlQCaSVqAOxLrKHNwDReG,ctsidPMphTlQCaSVqAOxLrKHNwDReJ,ctsidPMphTlQCaSVqAOxLrKHNwDRem
 def makeDefaultCookies(ctsidPMphTlQCaSVqAOxLrKHNwDRen):
  ctsidPMphTlQCaSVqAOxLrKHNwDReE={}
  if ctsidPMphTlQCaSVqAOxLrKHNwDRen.TV['cookies']['tving_token']:ctsidPMphTlQCaSVqAOxLrKHNwDReE['_tving_token']=ctsidPMphTlQCaSVqAOxLrKHNwDRen.TV['cookies']['tving_token']
  if ctsidPMphTlQCaSVqAOxLrKHNwDRen.TV['cookies']['tving_userinfo']:ctsidPMphTlQCaSVqAOxLrKHNwDReE['POC_USERINFO']=ctsidPMphTlQCaSVqAOxLrKHNwDRen.TV['cookies']['tving_userinfo']
  if ctsidPMphTlQCaSVqAOxLrKHNwDRen.TV['cookies']['tving_maintoken']:ctsidPMphTlQCaSVqAOxLrKHNwDReE[ctsidPMphTlQCaSVqAOxLrKHNwDRen.GLOBAL_COOKIENM['tv_maintoken']]=ctsidPMphTlQCaSVqAOxLrKHNwDRen.TV['cookies']['tving_maintoken']
  if ctsidPMphTlQCaSVqAOxLrKHNwDRen.TV['cookies']['tving_cookiekey']:ctsidPMphTlQCaSVqAOxLrKHNwDReE[ctsidPMphTlQCaSVqAOxLrKHNwDRen.GLOBAL_COOKIENM['tv_cookiekey']]=ctsidPMphTlQCaSVqAOxLrKHNwDRen.TV['cookies']['tving_cookiekey']
  if ctsidPMphTlQCaSVqAOxLrKHNwDRen.TV['cookies']['tving_lockkey']:ctsidPMphTlQCaSVqAOxLrKHNwDReE[ctsidPMphTlQCaSVqAOxLrKHNwDRen.GLOBAL_COOKIENM['tv_lockkey']]=ctsidPMphTlQCaSVqAOxLrKHNwDRen.TV['cookies']['tving_lockkey']
  return ctsidPMphTlQCaSVqAOxLrKHNwDReE
 def getDeviceStr(ctsidPMphTlQCaSVqAOxLrKHNwDRen):
  ctsidPMphTlQCaSVqAOxLrKHNwDReW=[]
  ctsidPMphTlQCaSVqAOxLrKHNwDReW.append('Windows') 
  ctsidPMphTlQCaSVqAOxLrKHNwDReW.append('Chrome') 
  ctsidPMphTlQCaSVqAOxLrKHNwDReW.append('ko-KR') 
  ctsidPMphTlQCaSVqAOxLrKHNwDReW.append('undefined') 
  ctsidPMphTlQCaSVqAOxLrKHNwDReW.append('24') 
  ctsidPMphTlQCaSVqAOxLrKHNwDReW.append(u'한국 표준시')
  ctsidPMphTlQCaSVqAOxLrKHNwDReW.append('undefined') 
  ctsidPMphTlQCaSVqAOxLrKHNwDReW.append('undefined') 
  ctsidPMphTlQCaSVqAOxLrKHNwDReW.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  ctsidPMphTlQCaSVqAOxLrKHNwDRez=''
  for ctsidPMphTlQCaSVqAOxLrKHNwDRev in ctsidPMphTlQCaSVqAOxLrKHNwDReW:
   ctsidPMphTlQCaSVqAOxLrKHNwDRez+=ctsidPMphTlQCaSVqAOxLrKHNwDRev+'|'
  return ctsidPMphTlQCaSVqAOxLrKHNwDRez
 def GetDefaultParams(ctsidPMphTlQCaSVqAOxLrKHNwDRen):
  ctsidPMphTlQCaSVqAOxLrKHNwDRej={'apiKey':ctsidPMphTlQCaSVqAOxLrKHNwDRen.APIKEY,'networkCode':ctsidPMphTlQCaSVqAOxLrKHNwDRen.NETWORKCODE,'osCode':ctsidPMphTlQCaSVqAOxLrKHNwDRen.OSCODE,'teleCode':ctsidPMphTlQCaSVqAOxLrKHNwDRen.TELECODE,'screenCode':ctsidPMphTlQCaSVqAOxLrKHNwDRen.SCREENCODE}
  return ctsidPMphTlQCaSVqAOxLrKHNwDRej
 def GetNoCache(ctsidPMphTlQCaSVqAOxLrKHNwDRen,timetype=1):
  if timetype==1:
   return ctsidPMphTlQCaSVqAOxLrKHNwDRUJ(time.time())
  else:
   return ctsidPMphTlQCaSVqAOxLrKHNwDRUJ(time.time()*1000)
 def GetUniqueid(ctsidPMphTlQCaSVqAOxLrKHNwDRen,hValue=ctsidPMphTlQCaSVqAOxLrKHNwDRUk):
  if hValue:
   import hashlib
   ctsidPMphTlQCaSVqAOxLrKHNwDReB=hashlib.sha1()
   ctsidPMphTlQCaSVqAOxLrKHNwDReB.update(hValue.encode())
   ctsidPMphTlQCaSVqAOxLrKHNwDReg=ctsidPMphTlQCaSVqAOxLrKHNwDReB.hexdigest()[:8]
  else:
   ctsidPMphTlQCaSVqAOxLrKHNwDRey=[0 for i in ctsidPMphTlQCaSVqAOxLrKHNwDRUm(256)]
   for i in ctsidPMphTlQCaSVqAOxLrKHNwDRUm(256):
    ctsidPMphTlQCaSVqAOxLrKHNwDRey[i]='%02x'%(i)
   ctsidPMphTlQCaSVqAOxLrKHNwDReu=ctsidPMphTlQCaSVqAOxLrKHNwDRUJ(4294967295*random.random())|0
   ctsidPMphTlQCaSVqAOxLrKHNwDReg=ctsidPMphTlQCaSVqAOxLrKHNwDRey[255&ctsidPMphTlQCaSVqAOxLrKHNwDReu]+ctsidPMphTlQCaSVqAOxLrKHNwDRey[ctsidPMphTlQCaSVqAOxLrKHNwDReu>>8&255]+ctsidPMphTlQCaSVqAOxLrKHNwDRey[ctsidPMphTlQCaSVqAOxLrKHNwDReu>>16&255]+ctsidPMphTlQCaSVqAOxLrKHNwDRey[ctsidPMphTlQCaSVqAOxLrKHNwDReu>>24&255]
  return ctsidPMphTlQCaSVqAOxLrKHNwDReg
 def GetCredential(ctsidPMphTlQCaSVqAOxLrKHNwDRen,user_id,user_pw,login_type,user_pf):
  try:
   ctsidPMphTlQCaSVqAOxLrKHNwDRIe=ctsidPMphTlQCaSVqAOxLrKHNwDRen.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   ctsidPMphTlQCaSVqAOxLrKHNwDRIb={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com','csite':'',}
   ctsidPMphTlQCaSVqAOxLrKHNwDRIF=ctsidPMphTlQCaSVqAOxLrKHNwDRen.callRequestCookies('Post',ctsidPMphTlQCaSVqAOxLrKHNwDRIe,payload=ctsidPMphTlQCaSVqAOxLrKHNwDRIb,params=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,headers=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,cookies=ctsidPMphTlQCaSVqAOxLrKHNwDRUk)
   for ctsidPMphTlQCaSVqAOxLrKHNwDRIn in ctsidPMphTlQCaSVqAOxLrKHNwDRIF.cookies:
    if ctsidPMphTlQCaSVqAOxLrKHNwDRIn.name=='_tving_token':
     ctsidPMphTlQCaSVqAOxLrKHNwDRen.TV['cookies']['tving_token']=ctsidPMphTlQCaSVqAOxLrKHNwDRIn.value
    elif ctsidPMphTlQCaSVqAOxLrKHNwDRIn.name=='POC_USERINFO':
     ctsidPMphTlQCaSVqAOxLrKHNwDRen.TV['cookies']['tving_userinfo']=ctsidPMphTlQCaSVqAOxLrKHNwDRIn.value
   if not ctsidPMphTlQCaSVqAOxLrKHNwDRen.TV['cookies']['tving_token']:
    ctsidPMphTlQCaSVqAOxLrKHNwDRen.Init_TV_Total()
    return ctsidPMphTlQCaSVqAOxLrKHNwDRUY
   ctsidPMphTlQCaSVqAOxLrKHNwDRen.TV['cookies']['tving_maintoken']=ctsidPMphTlQCaSVqAOxLrKHNwDRen.TV['cookies']['tving_token']
   if ctsidPMphTlQCaSVqAOxLrKHNwDRen.GetProfileToken(user_pf)==ctsidPMphTlQCaSVqAOxLrKHNwDRUY:
    ctsidPMphTlQCaSVqAOxLrKHNwDRen.Init_TV_Total()
    return ctsidPMphTlQCaSVqAOxLrKHNwDRUY
   ctsidPMphTlQCaSVqAOxLrKHNwDRIU =ctsidPMphTlQCaSVqAOxLrKHNwDRen.GetDeviceList()
   if ctsidPMphTlQCaSVqAOxLrKHNwDRIU not in['','-']:
    ctsidPMphTlQCaSVqAOxLrKHNwDRen.TV['cookies']['tving_uuid']=ctsidPMphTlQCaSVqAOxLrKHNwDRIU+'-'+ctsidPMphTlQCaSVqAOxLrKHNwDRen.GetUniqueid(ctsidPMphTlQCaSVqAOxLrKHNwDRIU)
    ctsidPMphTlQCaSVqAOxLrKHNwDRUE(ctsidPMphTlQCaSVqAOxLrKHNwDRIU)
  except ctsidPMphTlQCaSVqAOxLrKHNwDRUW as exception:
   ctsidPMphTlQCaSVqAOxLrKHNwDRUE(exception)
   ctsidPMphTlQCaSVqAOxLrKHNwDRen.Init_TV_Total()
   return ctsidPMphTlQCaSVqAOxLrKHNwDRUY
  return ctsidPMphTlQCaSVqAOxLrKHNwDRUG
 def GetProfileToken(ctsidPMphTlQCaSVqAOxLrKHNwDRen,user_pf):
  ctsidPMphTlQCaSVqAOxLrKHNwDRIo=[]
  ctsidPMphTlQCaSVqAOxLrKHNwDRIX =''
  try:
   ctsidPMphTlQCaSVqAOxLrKHNwDRIk ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com'
   ctsidPMphTlQCaSVqAOxLrKHNwDReE=ctsidPMphTlQCaSVqAOxLrKHNwDRen.makeDefaultCookies()
   ctsidPMphTlQCaSVqAOxLrKHNwDRIF=ctsidPMphTlQCaSVqAOxLrKHNwDRen.callRequestCookies('Get',ctsidPMphTlQCaSVqAOxLrKHNwDRIk,payload=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,params=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,headers=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,cookies=ctsidPMphTlQCaSVqAOxLrKHNwDReE)
   ctsidPMphTlQCaSVqAOxLrKHNwDRIo =re.findall('data-profile-no="\d+"',ctsidPMphTlQCaSVqAOxLrKHNwDRIF.text)
   for i in ctsidPMphTlQCaSVqAOxLrKHNwDRUm(ctsidPMphTlQCaSVqAOxLrKHNwDRUz(ctsidPMphTlQCaSVqAOxLrKHNwDRIo)):
    ctsidPMphTlQCaSVqAOxLrKHNwDRIY =ctsidPMphTlQCaSVqAOxLrKHNwDRIo[i].replace('data-profile-no=','').replace('"','')
    ctsidPMphTlQCaSVqAOxLrKHNwDRIo[i]=ctsidPMphTlQCaSVqAOxLrKHNwDRIY
   ctsidPMphTlQCaSVqAOxLrKHNwDRIX=ctsidPMphTlQCaSVqAOxLrKHNwDRIo[user_pf]
  except ctsidPMphTlQCaSVqAOxLrKHNwDRUW as exception:
   ctsidPMphTlQCaSVqAOxLrKHNwDRUE(exception)
   ctsidPMphTlQCaSVqAOxLrKHNwDRen.Init_TV_Total()
   return ctsidPMphTlQCaSVqAOxLrKHNwDRUY
  try:
   ctsidPMphTlQCaSVqAOxLrKHNwDRIk ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   ctsidPMphTlQCaSVqAOxLrKHNwDReE=ctsidPMphTlQCaSVqAOxLrKHNwDRen.makeDefaultCookies()
   ctsidPMphTlQCaSVqAOxLrKHNwDRIb={'profileNo':ctsidPMphTlQCaSVqAOxLrKHNwDRIX}
   ctsidPMphTlQCaSVqAOxLrKHNwDRIF=ctsidPMphTlQCaSVqAOxLrKHNwDRen.callRequestCookies('Post',ctsidPMphTlQCaSVqAOxLrKHNwDRIk,payload=ctsidPMphTlQCaSVqAOxLrKHNwDRIb,params=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,headers=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,cookies=ctsidPMphTlQCaSVqAOxLrKHNwDReE)
   for ctsidPMphTlQCaSVqAOxLrKHNwDRIn in ctsidPMphTlQCaSVqAOxLrKHNwDRIF.cookies:
    if ctsidPMphTlQCaSVqAOxLrKHNwDRIn.name=='_tving_token':
     ctsidPMphTlQCaSVqAOxLrKHNwDRen.TV['cookies']['tving_token']=ctsidPMphTlQCaSVqAOxLrKHNwDRIn.value
    elif ctsidPMphTlQCaSVqAOxLrKHNwDRIn.name==ctsidPMphTlQCaSVqAOxLrKHNwDRen.GLOBAL_COOKIENM['tv_cookiekey']:
     ctsidPMphTlQCaSVqAOxLrKHNwDRen.TV['cookies']['tving_cookiekey']=ctsidPMphTlQCaSVqAOxLrKHNwDRIn.value
    elif ctsidPMphTlQCaSVqAOxLrKHNwDRIn.name==ctsidPMphTlQCaSVqAOxLrKHNwDRen.GLOBAL_COOKIENM['tv_lockkey']:
     ctsidPMphTlQCaSVqAOxLrKHNwDRen.TV['cookies']['tving_lockkey']=ctsidPMphTlQCaSVqAOxLrKHNwDRIn.value
  except ctsidPMphTlQCaSVqAOxLrKHNwDRUW as exception:
   ctsidPMphTlQCaSVqAOxLrKHNwDRUE(exception)
   ctsidPMphTlQCaSVqAOxLrKHNwDRen.Init_TV_Total()
   return ctsidPMphTlQCaSVqAOxLrKHNwDRUY
  return ctsidPMphTlQCaSVqAOxLrKHNwDRUG
 def GetDeviceList(ctsidPMphTlQCaSVqAOxLrKHNwDRen):
  ctsidPMphTlQCaSVqAOxLrKHNwDRIf=[]
  ctsidPMphTlQCaSVqAOxLrKHNwDRIG='-'
  try:
   ctsidPMphTlQCaSVqAOxLrKHNwDRIk ='/v1/user/device/list'
   ctsidPMphTlQCaSVqAOxLrKHNwDRIJ=ctsidPMphTlQCaSVqAOxLrKHNwDRen.API_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRIk
   ctsidPMphTlQCaSVqAOxLrKHNwDRIm={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   ctsidPMphTlQCaSVqAOxLrKHNwDReE=ctsidPMphTlQCaSVqAOxLrKHNwDRen.makeDefaultCookies()
   ctsidPMphTlQCaSVqAOxLrKHNwDRIF=ctsidPMphTlQCaSVqAOxLrKHNwDRen.callRequestCookies('Get',ctsidPMphTlQCaSVqAOxLrKHNwDRIJ,payload=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,params=ctsidPMphTlQCaSVqAOxLrKHNwDRIm,headers=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,cookies=ctsidPMphTlQCaSVqAOxLrKHNwDReE)
   ctsidPMphTlQCaSVqAOxLrKHNwDRIE=json.loads(ctsidPMphTlQCaSVqAOxLrKHNwDRIF.text)
   ctsidPMphTlQCaSVqAOxLrKHNwDRIf=ctsidPMphTlQCaSVqAOxLrKHNwDRIE['body']
   for ctsidPMphTlQCaSVqAOxLrKHNwDRIW in ctsidPMphTlQCaSVqAOxLrKHNwDRIf:
    if ctsidPMphTlQCaSVqAOxLrKHNwDRIW['model']=='PC' or ctsidPMphTlQCaSVqAOxLrKHNwDRIW['model']=='PC-Chrome':
     ctsidPMphTlQCaSVqAOxLrKHNwDRIG=ctsidPMphTlQCaSVqAOxLrKHNwDRIW['uuid']
  except ctsidPMphTlQCaSVqAOxLrKHNwDRUW as exception:
   ctsidPMphTlQCaSVqAOxLrKHNwDRUE(exception)
  return ctsidPMphTlQCaSVqAOxLrKHNwDRIG
 def Get_Now_Datetime(ctsidPMphTlQCaSVqAOxLrKHNwDRen):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(ctsidPMphTlQCaSVqAOxLrKHNwDRen,mediacode,sel_quality,stype,pvrmode='-'):
  ctsidPMphTlQCaSVqAOxLrKHNwDRIv ={'streaming_url':'','drm_license':'','watermark':'','watermarkKey':'','error_msg':'',}
  ctsidPMphTlQCaSVqAOxLrKHNwDRIG =ctsidPMphTlQCaSVqAOxLrKHNwDRen.TV['cookies']['tving_uuid'].split('-')[0] 
  ctsidPMphTlQCaSVqAOxLrKHNwDRIj =ctsidPMphTlQCaSVqAOxLrKHNwDRen.TV['cookies']['tving_uuid'] 
  try:
   ctsidPMphTlQCaSVqAOxLrKHNwDRIB=ctsidPMphTlQCaSVqAOxLrKHNwDRUv(ctsidPMphTlQCaSVqAOxLrKHNwDRen.GetNoCache(1))
   if stype!='tvingtv':
    ctsidPMphTlQCaSVqAOxLrKHNwDRIk ='/v2/media/stream/info' 
    ctsidPMphTlQCaSVqAOxLrKHNwDRIg=ctsidPMphTlQCaSVqAOxLrKHNwDRen.GetDefaultParams()
    ctsidPMphTlQCaSVqAOxLrKHNwDRIm={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':ctsidPMphTlQCaSVqAOxLrKHNwDRIj,'deviceInfo':'PC','noCache':ctsidPMphTlQCaSVqAOxLrKHNwDRIB,}
    ctsidPMphTlQCaSVqAOxLrKHNwDRIg.update(ctsidPMphTlQCaSVqAOxLrKHNwDRIm)
    ctsidPMphTlQCaSVqAOxLrKHNwDRIy=ctsidPMphTlQCaSVqAOxLrKHNwDRen.API_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRIk
    ctsidPMphTlQCaSVqAOxLrKHNwDReE=ctsidPMphTlQCaSVqAOxLrKHNwDRen.makeDefaultCookies()
    ctsidPMphTlQCaSVqAOxLrKHNwDRIF=ctsidPMphTlQCaSVqAOxLrKHNwDRen.callRequestCookies('Get',ctsidPMphTlQCaSVqAOxLrKHNwDRIy,payload=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,params=ctsidPMphTlQCaSVqAOxLrKHNwDRIg,headers=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,cookies=ctsidPMphTlQCaSVqAOxLrKHNwDReE)
    if ctsidPMphTlQCaSVqAOxLrKHNwDRIF.status_code!=200:
     ctsidPMphTlQCaSVqAOxLrKHNwDRIv['error_msg']='First Step - {} error'.format(ctsidPMphTlQCaSVqAOxLrKHNwDRIF.status_code)
     return ctsidPMphTlQCaSVqAOxLrKHNwDRIv
    ctsidPMphTlQCaSVqAOxLrKHNwDRIE=json.loads(ctsidPMphTlQCaSVqAOxLrKHNwDRIF.text)
    if ctsidPMphTlQCaSVqAOxLrKHNwDRIE['body']['result']['code']=='060':
     for ctsidPMphTlQCaSVqAOxLrKHNwDRIu,ctsidPMphTlQCaSVqAOxLrKHNwDRbf in ctsidPMphTlQCaSVqAOxLrKHNwDReb.items():
      if ctsidPMphTlQCaSVqAOxLrKHNwDRbf==sel_quality:
       ctsidPMphTlQCaSVqAOxLrKHNwDRbe=ctsidPMphTlQCaSVqAOxLrKHNwDRIu
    elif ctsidPMphTlQCaSVqAOxLrKHNwDRIE['body']['result']['code']!='000':
     ctsidPMphTlQCaSVqAOxLrKHNwDRIv['error_msg']=ctsidPMphTlQCaSVqAOxLrKHNwDRIE['body']['result']['message']
     return ctsidPMphTlQCaSVqAOxLrKHNwDRIv
    else: 
     if not('stream' in ctsidPMphTlQCaSVqAOxLrKHNwDRIE['body']):return ctsidPMphTlQCaSVqAOxLrKHNwDRIv
     ctsidPMphTlQCaSVqAOxLrKHNwDRbI=[]
     for ctsidPMphTlQCaSVqAOxLrKHNwDRIW in ctsidPMphTlQCaSVqAOxLrKHNwDRIE['body']['stream']['quality']:
      if ctsidPMphTlQCaSVqAOxLrKHNwDRIW['active']=='Y':
       ctsidPMphTlQCaSVqAOxLrKHNwDRbI.append({ctsidPMphTlQCaSVqAOxLrKHNwDReb.get(ctsidPMphTlQCaSVqAOxLrKHNwDRIW['code']):ctsidPMphTlQCaSVqAOxLrKHNwDRIW['code']})
     ctsidPMphTlQCaSVqAOxLrKHNwDRbe=ctsidPMphTlQCaSVqAOxLrKHNwDRen.CheckQuality(sel_quality,ctsidPMphTlQCaSVqAOxLrKHNwDRbI)
   else:
    ctsidPMphTlQCaSVqAOxLrKHNwDRbe='stream40'
  except ctsidPMphTlQCaSVqAOxLrKHNwDRUW as exception:
   ctsidPMphTlQCaSVqAOxLrKHNwDRUE(exception)
   ctsidPMphTlQCaSVqAOxLrKHNwDRIv['error_msg']='First Step - except error'
   return ctsidPMphTlQCaSVqAOxLrKHNwDRIv
  ctsidPMphTlQCaSVqAOxLrKHNwDRUE(ctsidPMphTlQCaSVqAOxLrKHNwDRbe)
  try:
   ctsidPMphTlQCaSVqAOxLrKHNwDRIB=ctsidPMphTlQCaSVqAOxLrKHNwDRUv(ctsidPMphTlQCaSVqAOxLrKHNwDRen.GetNoCache(1))
   ctsidPMphTlQCaSVqAOxLrKHNwDRIk ='/v2a/media/stream/info'
   ctsidPMphTlQCaSVqAOxLrKHNwDRIg=ctsidPMphTlQCaSVqAOxLrKHNwDRen.GetDefaultParams()
   ctsidPMphTlQCaSVqAOxLrKHNwDRIm={'callingFrom':'HTML5','mediaCode':mediacode,'info':'Y','adReq':'adproxy','streamCode':ctsidPMphTlQCaSVqAOxLrKHNwDRbe,'deviceId':ctsidPMphTlQCaSVqAOxLrKHNwDRIG,'uuid':ctsidPMphTlQCaSVqAOxLrKHNwDRIj,'deviceInfo':'PC_Chrome','noCache':ctsidPMphTlQCaSVqAOxLrKHNwDRIB,'wm':'Y'}
   ctsidPMphTlQCaSVqAOxLrKHNwDRIg.update(ctsidPMphTlQCaSVqAOxLrKHNwDRIm)
   ctsidPMphTlQCaSVqAOxLrKHNwDRIy=ctsidPMphTlQCaSVqAOxLrKHNwDRen.API_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRIk
   ctsidPMphTlQCaSVqAOxLrKHNwDReE=ctsidPMphTlQCaSVqAOxLrKHNwDRen.makeDefaultCookies()
   ctsidPMphTlQCaSVqAOxLrKHNwDRIF=ctsidPMphTlQCaSVqAOxLrKHNwDRen.callRequestCookies('Get',ctsidPMphTlQCaSVqAOxLrKHNwDRIy,payload=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,params=ctsidPMphTlQCaSVqAOxLrKHNwDRIg,headers=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,cookies=ctsidPMphTlQCaSVqAOxLrKHNwDReE,redirects=ctsidPMphTlQCaSVqAOxLrKHNwDRUY)
   ctsidPMphTlQCaSVqAOxLrKHNwDRIE=json.loads(ctsidPMphTlQCaSVqAOxLrKHNwDRIF.text)
   if ctsidPMphTlQCaSVqAOxLrKHNwDRIE['body']['result']['code']!='000':
    ctsidPMphTlQCaSVqAOxLrKHNwDRIv['error_msg']=ctsidPMphTlQCaSVqAOxLrKHNwDRIE['body']['result']['message']
    return ctsidPMphTlQCaSVqAOxLrKHNwDRIv
   ctsidPMphTlQCaSVqAOxLrKHNwDRbF=ctsidPMphTlQCaSVqAOxLrKHNwDRIE['body']['stream']
   if 'drm_license_assertion' in ctsidPMphTlQCaSVqAOxLrKHNwDRbF:
    ctsidPMphTlQCaSVqAOxLrKHNwDRIv['drm_license']=ctsidPMphTlQCaSVqAOxLrKHNwDRbF['drm_license_assertion']
    ctsidPMphTlQCaSVqAOxLrKHNwDRbn =ctsidPMphTlQCaSVqAOxLrKHNwDRbF['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in ctsidPMphTlQCaSVqAOxLrKHNwDRbF['broadcast']):return ctsidPMphTlQCaSVqAOxLrKHNwDRIv
    ctsidPMphTlQCaSVqAOxLrKHNwDRbn=ctsidPMphTlQCaSVqAOxLrKHNwDRbF['broadcast']['broad_url']
  except ctsidPMphTlQCaSVqAOxLrKHNwDRUW as exception:
   ctsidPMphTlQCaSVqAOxLrKHNwDRUE(exception)
   ctsidPMphTlQCaSVqAOxLrKHNwDRIv['error_msg']='Second Step - except error'
   return ctsidPMphTlQCaSVqAOxLrKHNwDRIv
  ctsidPMphTlQCaSVqAOxLrKHNwDRbU=ctsidPMphTlQCaSVqAOxLrKHNwDRIB
  ctsidPMphTlQCaSVqAOxLrKHNwDRbn=ctsidPMphTlQCaSVqAOxLrKHNwDRbn.split('|')[1]
  ctsidPMphTlQCaSVqAOxLrKHNwDRbn,ctsidPMphTlQCaSVqAOxLrKHNwDRbo,ctsidPMphTlQCaSVqAOxLrKHNwDRbX=ctsidPMphTlQCaSVqAOxLrKHNwDRen.Decrypt_Url(ctsidPMphTlQCaSVqAOxLrKHNwDRbn,mediacode,ctsidPMphTlQCaSVqAOxLrKHNwDRbU)
  ctsidPMphTlQCaSVqAOxLrKHNwDRIv['streaming_url']=ctsidPMphTlQCaSVqAOxLrKHNwDRbn
  ctsidPMphTlQCaSVqAOxLrKHNwDRIv['watermark'] =ctsidPMphTlQCaSVqAOxLrKHNwDRbo
  ctsidPMphTlQCaSVqAOxLrKHNwDRIv['watermarkKey']=ctsidPMphTlQCaSVqAOxLrKHNwDRbX
  return ctsidPMphTlQCaSVqAOxLrKHNwDRIv
 def CheckQuality(ctsidPMphTlQCaSVqAOxLrKHNwDRen,sel_qt,ctsidPMphTlQCaSVqAOxLrKHNwDRbI):
  for ctsidPMphTlQCaSVqAOxLrKHNwDRbk in ctsidPMphTlQCaSVqAOxLrKHNwDRbI:
   if sel_qt>=ctsidPMphTlQCaSVqAOxLrKHNwDRUj(ctsidPMphTlQCaSVqAOxLrKHNwDRbk)[0]:return ctsidPMphTlQCaSVqAOxLrKHNwDRbk.get(ctsidPMphTlQCaSVqAOxLrKHNwDRUj(ctsidPMphTlQCaSVqAOxLrKHNwDRbk)[0])
   ctsidPMphTlQCaSVqAOxLrKHNwDRbY=ctsidPMphTlQCaSVqAOxLrKHNwDRbk.get(ctsidPMphTlQCaSVqAOxLrKHNwDRUj(ctsidPMphTlQCaSVqAOxLrKHNwDRbk)[0])
  return ctsidPMphTlQCaSVqAOxLrKHNwDRbY
 def makeOocUrl(ctsidPMphTlQCaSVqAOxLrKHNwDRen,ooc_params):
  ctsidPMphTlQCaSVqAOxLrKHNwDRIy=''
  for ctsidPMphTlQCaSVqAOxLrKHNwDRIu,ctsidPMphTlQCaSVqAOxLrKHNwDRbf in ooc_params.items():
   ctsidPMphTlQCaSVqAOxLrKHNwDRIy+="%s=%s^"%(ctsidPMphTlQCaSVqAOxLrKHNwDRIu,ctsidPMphTlQCaSVqAOxLrKHNwDRbf)
  return ctsidPMphTlQCaSVqAOxLrKHNwDRIy
 def GetLiveChannelList(ctsidPMphTlQCaSVqAOxLrKHNwDRen,stype,page_int):
  ctsidPMphTlQCaSVqAOxLrKHNwDRIf=[]
  ctsidPMphTlQCaSVqAOxLrKHNwDRbG=ctsidPMphTlQCaSVqAOxLrKHNwDRUY
  try:
   ctsidPMphTlQCaSVqAOxLrKHNwDRIk ='/v2/media/lives'
   if stype=='onair': 
    ctsidPMphTlQCaSVqAOxLrKHNwDRbJ='CPCS0100,CPCS0400'
   else:
    ctsidPMphTlQCaSVqAOxLrKHNwDRbJ='CPCS0300'
   ctsidPMphTlQCaSVqAOxLrKHNwDRIg=ctsidPMphTlQCaSVqAOxLrKHNwDRen.GetDefaultParams()
   ctsidPMphTlQCaSVqAOxLrKHNwDRIm={'cacheType':'main','pageNo':ctsidPMphTlQCaSVqAOxLrKHNwDRUv(page_int),'pageSize':ctsidPMphTlQCaSVqAOxLrKHNwDRUv(ctsidPMphTlQCaSVqAOxLrKHNwDRen.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':ctsidPMphTlQCaSVqAOxLrKHNwDRbJ,}
   ctsidPMphTlQCaSVqAOxLrKHNwDRIg.update(ctsidPMphTlQCaSVqAOxLrKHNwDRIm)
   ctsidPMphTlQCaSVqAOxLrKHNwDRIy=ctsidPMphTlQCaSVqAOxLrKHNwDRen.API_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRIk
   ctsidPMphTlQCaSVqAOxLrKHNwDRIF=ctsidPMphTlQCaSVqAOxLrKHNwDRen.callRequestCookies('Get',ctsidPMphTlQCaSVqAOxLrKHNwDRIy,payload=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,params=ctsidPMphTlQCaSVqAOxLrKHNwDRIg,headers=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,cookies=ctsidPMphTlQCaSVqAOxLrKHNwDRUk)
   ctsidPMphTlQCaSVqAOxLrKHNwDRIE=json.loads(ctsidPMphTlQCaSVqAOxLrKHNwDRIF.text)
   if not('result' in ctsidPMphTlQCaSVqAOxLrKHNwDRIE['body']):return ctsidPMphTlQCaSVqAOxLrKHNwDRIf,ctsidPMphTlQCaSVqAOxLrKHNwDRbG
   ctsidPMphTlQCaSVqAOxLrKHNwDRbm=ctsidPMphTlQCaSVqAOxLrKHNwDRIE['body']['result']
   for ctsidPMphTlQCaSVqAOxLrKHNwDRIW in ctsidPMphTlQCaSVqAOxLrKHNwDRbm:
    ctsidPMphTlQCaSVqAOxLrKHNwDRbE=ctsidPMphTlQCaSVqAOxLrKHNwDRbv=ctsidPMphTlQCaSVqAOxLrKHNwDRbj=''
    ctsidPMphTlQCaSVqAOxLrKHNwDRbW=ctsidPMphTlQCaSVqAOxLrKHNwDRFm=''
    ctsidPMphTlQCaSVqAOxLrKHNwDRbz=ctsidPMphTlQCaSVqAOxLrKHNwDRIW['live_code']
    ctsidPMphTlQCaSVqAOxLrKHNwDRbE =ctsidPMphTlQCaSVqAOxLrKHNwDRIW['schedule']['channel']['name']['ko']
    if ctsidPMphTlQCaSVqAOxLrKHNwDRIW['schedule']['episode']!=ctsidPMphTlQCaSVqAOxLrKHNwDRUk:
     ctsidPMphTlQCaSVqAOxLrKHNwDRbv =ctsidPMphTlQCaSVqAOxLrKHNwDRIW['schedule']['program']['name']['ko']
     ctsidPMphTlQCaSVqAOxLrKHNwDRbv =ctsidPMphTlQCaSVqAOxLrKHNwDRbv+', '+ctsidPMphTlQCaSVqAOxLrKHNwDRUv(ctsidPMphTlQCaSVqAOxLrKHNwDRIW['schedule']['episode']['frequency'])+'회'
     ctsidPMphTlQCaSVqAOxLrKHNwDRbj=ctsidPMphTlQCaSVqAOxLrKHNwDRIW['schedule']['episode']['synopsis']['ko']
    else:
     ctsidPMphTlQCaSVqAOxLrKHNwDRbv =ctsidPMphTlQCaSVqAOxLrKHNwDRIW['schedule']['program']['name']['ko']
     ctsidPMphTlQCaSVqAOxLrKHNwDRbj=ctsidPMphTlQCaSVqAOxLrKHNwDRIW['schedule']['program']['synopsis']['ko']
    try: 
     ctsidPMphTlQCaSVqAOxLrKHNwDRbB =''
     ctsidPMphTlQCaSVqAOxLrKHNwDRbg =''
     ctsidPMphTlQCaSVqAOxLrKHNwDRby=''
     ctsidPMphTlQCaSVqAOxLrKHNwDRbu =''
     ctsidPMphTlQCaSVqAOxLrKHNwDRFe =''
     ctsidPMphTlQCaSVqAOxLrKHNwDRFI =''
     for ctsidPMphTlQCaSVqAOxLrKHNwDRFb in ctsidPMphTlQCaSVqAOxLrKHNwDRIW['schedule']['program']['image']:
      if ctsidPMphTlQCaSVqAOxLrKHNwDRFb['code']=='CAIP0900':ctsidPMphTlQCaSVqAOxLrKHNwDRbg =ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRFb['url']
      elif ctsidPMphTlQCaSVqAOxLrKHNwDRFb['code']=='CAIP1800':ctsidPMphTlQCaSVqAOxLrKHNwDRby=ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRFb['url']
      elif ctsidPMphTlQCaSVqAOxLrKHNwDRFb['code']=='CAIP2000':ctsidPMphTlQCaSVqAOxLrKHNwDRbu =ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRFb['url']
      elif ctsidPMphTlQCaSVqAOxLrKHNwDRFb['code']=='CAIP1900':ctsidPMphTlQCaSVqAOxLrKHNwDRFe =ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRFb['url']
      elif ctsidPMphTlQCaSVqAOxLrKHNwDRFb['code']=='CAIP0200':ctsidPMphTlQCaSVqAOxLrKHNwDRFI =ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRFb['url']
      elif ctsidPMphTlQCaSVqAOxLrKHNwDRFb['code']=='CAIP0500':ctsidPMphTlQCaSVqAOxLrKHNwDRbB =ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRFb['url']
      elif ctsidPMphTlQCaSVqAOxLrKHNwDRFb['code']=='CAIP0800':ctsidPMphTlQCaSVqAOxLrKHNwDRbB =ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRFb['url']
     if ctsidPMphTlQCaSVqAOxLrKHNwDRbB=='':
      for ctsidPMphTlQCaSVqAOxLrKHNwDRFb in ctsidPMphTlQCaSVqAOxLrKHNwDRIW['schedule']['channel']['image']:
       if ctsidPMphTlQCaSVqAOxLrKHNwDRFb['code']=='CAIC0400':ctsidPMphTlQCaSVqAOxLrKHNwDRbB =ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRFb['url']
       elif ctsidPMphTlQCaSVqAOxLrKHNwDRFb['code']=='CAIC1400':ctsidPMphTlQCaSVqAOxLrKHNwDRbB =ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRFb['url']
       elif ctsidPMphTlQCaSVqAOxLrKHNwDRFb['code']=='CAIC1900':ctsidPMphTlQCaSVqAOxLrKHNwDRbB =ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRFb['url']
    except:
     ctsidPMphTlQCaSVqAOxLrKHNwDRUk
    try:
     ctsidPMphTlQCaSVqAOxLrKHNwDRFn =[]
     ctsidPMphTlQCaSVqAOxLrKHNwDRFU=[]
     ctsidPMphTlQCaSVqAOxLrKHNwDRFo =[]
     ctsidPMphTlQCaSVqAOxLrKHNwDRFX=''
     ctsidPMphTlQCaSVqAOxLrKHNwDRFk=''
     ctsidPMphTlQCaSVqAOxLrKHNwDRFY=''
     for ctsidPMphTlQCaSVqAOxLrKHNwDRFf in ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('schedule').get('program').get('actor'):
      if ctsidPMphTlQCaSVqAOxLrKHNwDRFf!='' and ctsidPMphTlQCaSVqAOxLrKHNwDRFf!=u'없음':ctsidPMphTlQCaSVqAOxLrKHNwDRFn.append(ctsidPMphTlQCaSVqAOxLrKHNwDRFf)
     for ctsidPMphTlQCaSVqAOxLrKHNwDRFG in ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('schedule').get('program').get('director'):
      if ctsidPMphTlQCaSVqAOxLrKHNwDRFG!='' and ctsidPMphTlQCaSVqAOxLrKHNwDRFG!='-' and ctsidPMphTlQCaSVqAOxLrKHNwDRFG!=u'없음':ctsidPMphTlQCaSVqAOxLrKHNwDRFU.append(ctsidPMphTlQCaSVqAOxLrKHNwDRFG)
     if ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('schedule').get('program').get('category1_name').get('ko')!='':
      ctsidPMphTlQCaSVqAOxLrKHNwDRFo.append(ctsidPMphTlQCaSVqAOxLrKHNwDRIW['schedule']['program']['category1_name']['ko'])
     if ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('schedule').get('program').get('category2_name').get('ko')!='':
      ctsidPMphTlQCaSVqAOxLrKHNwDRFo.append(ctsidPMphTlQCaSVqAOxLrKHNwDRIW['schedule']['program']['category2_name']['ko'])
     if ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('schedule').get('program').get('product_year'):ctsidPMphTlQCaSVqAOxLrKHNwDRFX=ctsidPMphTlQCaSVqAOxLrKHNwDRIW['schedule']['program']['product_year']
     if ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('schedule').get('program').get('grade_code') :ctsidPMphTlQCaSVqAOxLrKHNwDRFk= ctsidPMphTlQCaSVqAOxLrKHNwDReF.get(ctsidPMphTlQCaSVqAOxLrKHNwDRIW['schedule']['program']['grade_code'])
     if 'broad_dt' in ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('schedule').get('program'):
      ctsidPMphTlQCaSVqAOxLrKHNwDRFJ =ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('schedule').get('program').get('broad_dt')
      ctsidPMphTlQCaSVqAOxLrKHNwDRFY='%s-%s-%s'%(ctsidPMphTlQCaSVqAOxLrKHNwDRFJ[:4],ctsidPMphTlQCaSVqAOxLrKHNwDRFJ[4:6],ctsidPMphTlQCaSVqAOxLrKHNwDRFJ[6:])
    except:
     ctsidPMphTlQCaSVqAOxLrKHNwDRUk
    ctsidPMphTlQCaSVqAOxLrKHNwDRbW=ctsidPMphTlQCaSVqAOxLrKHNwDRUv(ctsidPMphTlQCaSVqAOxLrKHNwDRIW['schedule']['broadcast_start_time'])[8:12]
    ctsidPMphTlQCaSVqAOxLrKHNwDRFm =ctsidPMphTlQCaSVqAOxLrKHNwDRUv(ctsidPMphTlQCaSVqAOxLrKHNwDRIW['schedule']['broadcast_end_time'])[8:12]
    ctsidPMphTlQCaSVqAOxLrKHNwDRFE={'channel':ctsidPMphTlQCaSVqAOxLrKHNwDRbE,'title':ctsidPMphTlQCaSVqAOxLrKHNwDRbv,'mediacode':ctsidPMphTlQCaSVqAOxLrKHNwDRbz,'thumbnail':{'poster':ctsidPMphTlQCaSVqAOxLrKHNwDRbg,'thumb':ctsidPMphTlQCaSVqAOxLrKHNwDRbB,'clearlogo':ctsidPMphTlQCaSVqAOxLrKHNwDRby,'icon':ctsidPMphTlQCaSVqAOxLrKHNwDRbu,'fanart':ctsidPMphTlQCaSVqAOxLrKHNwDRFI},'synopsis':ctsidPMphTlQCaSVqAOxLrKHNwDRbj,'channelepg':' [%s:%s ~ %s:%s]'%(ctsidPMphTlQCaSVqAOxLrKHNwDRbW[0:2],ctsidPMphTlQCaSVqAOxLrKHNwDRbW[2:],ctsidPMphTlQCaSVqAOxLrKHNwDRFm[0:2],ctsidPMphTlQCaSVqAOxLrKHNwDRFm[2:]),'cast':ctsidPMphTlQCaSVqAOxLrKHNwDRFn,'director':ctsidPMphTlQCaSVqAOxLrKHNwDRFU,'info_genre':ctsidPMphTlQCaSVqAOxLrKHNwDRFo,'year':ctsidPMphTlQCaSVqAOxLrKHNwDRFX,'mpaa':ctsidPMphTlQCaSVqAOxLrKHNwDRFk,'premiered':ctsidPMphTlQCaSVqAOxLrKHNwDRFY}
    ctsidPMphTlQCaSVqAOxLrKHNwDRIf.append(ctsidPMphTlQCaSVqAOxLrKHNwDRFE)
   if ctsidPMphTlQCaSVqAOxLrKHNwDRIE['body']['has_more']=='Y':
    ctsidPMphTlQCaSVqAOxLrKHNwDRbG=ctsidPMphTlQCaSVqAOxLrKHNwDRUG
  except ctsidPMphTlQCaSVqAOxLrKHNwDRUW as exception:
   ctsidPMphTlQCaSVqAOxLrKHNwDRUE(exception)
  return ctsidPMphTlQCaSVqAOxLrKHNwDRIf,ctsidPMphTlQCaSVqAOxLrKHNwDRbG
 def GetProgramList(ctsidPMphTlQCaSVqAOxLrKHNwDRen,genre,orderby,page_int,genreCode='all'):
  ctsidPMphTlQCaSVqAOxLrKHNwDRIf=[]
  ctsidPMphTlQCaSVqAOxLrKHNwDRbG=ctsidPMphTlQCaSVqAOxLrKHNwDRUY
  try:
   ctsidPMphTlQCaSVqAOxLrKHNwDRIk ='/v2/media/episodes'
   ctsidPMphTlQCaSVqAOxLrKHNwDRIg=ctsidPMphTlQCaSVqAOxLrKHNwDRen.GetDefaultParams()
   ctsidPMphTlQCaSVqAOxLrKHNwDRIm={'cacheType':'main','pageSize':ctsidPMphTlQCaSVqAOxLrKHNwDRUv(ctsidPMphTlQCaSVqAOxLrKHNwDRen.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':ctsidPMphTlQCaSVqAOxLrKHNwDRUv(page_int),}
   if genre !='all':ctsidPMphTlQCaSVqAOxLrKHNwDRIm['categoryCode']=genre
   if genreCode!='all':ctsidPMphTlQCaSVqAOxLrKHNwDRIm['genreCode'] =genreCode 
   ctsidPMphTlQCaSVqAOxLrKHNwDRIg.update(ctsidPMphTlQCaSVqAOxLrKHNwDRIm)
   ctsidPMphTlQCaSVqAOxLrKHNwDRIy=ctsidPMphTlQCaSVqAOxLrKHNwDRen.API_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRIk
   ctsidPMphTlQCaSVqAOxLrKHNwDRIF=ctsidPMphTlQCaSVqAOxLrKHNwDRen.callRequestCookies('Get',ctsidPMphTlQCaSVqAOxLrKHNwDRIy,payload=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,params=ctsidPMphTlQCaSVqAOxLrKHNwDRIg,headers=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,cookies=ctsidPMphTlQCaSVqAOxLrKHNwDRUk)
   ctsidPMphTlQCaSVqAOxLrKHNwDRIE=json.loads(ctsidPMphTlQCaSVqAOxLrKHNwDRIF.text)
   if not('result' in ctsidPMphTlQCaSVqAOxLrKHNwDRIE['body']):return ctsidPMphTlQCaSVqAOxLrKHNwDRIf,ctsidPMphTlQCaSVqAOxLrKHNwDRbG
   ctsidPMphTlQCaSVqAOxLrKHNwDRbm=ctsidPMphTlQCaSVqAOxLrKHNwDRIE['body']['result']
   for ctsidPMphTlQCaSVqAOxLrKHNwDRIW in ctsidPMphTlQCaSVqAOxLrKHNwDRbm:
    ctsidPMphTlQCaSVqAOxLrKHNwDRFW=ctsidPMphTlQCaSVqAOxLrKHNwDRIW['program']['code']
    ctsidPMphTlQCaSVqAOxLrKHNwDRbv =ctsidPMphTlQCaSVqAOxLrKHNwDRIW['program']['name']['ko']
    ctsidPMphTlQCaSVqAOxLrKHNwDRFk =ctsidPMphTlQCaSVqAOxLrKHNwDReF.get(ctsidPMphTlQCaSVqAOxLrKHNwDRIW['program'].get('grade_code'))
    ctsidPMphTlQCaSVqAOxLrKHNwDRbg =''
    ctsidPMphTlQCaSVqAOxLrKHNwDRbB =''
    ctsidPMphTlQCaSVqAOxLrKHNwDRby=''
    ctsidPMphTlQCaSVqAOxLrKHNwDRbu =''
    ctsidPMphTlQCaSVqAOxLrKHNwDRFe =''
    for ctsidPMphTlQCaSVqAOxLrKHNwDRFb in ctsidPMphTlQCaSVqAOxLrKHNwDRIW['program']['image']:
     if ctsidPMphTlQCaSVqAOxLrKHNwDRFb['code']=='CAIP0900':ctsidPMphTlQCaSVqAOxLrKHNwDRbg =ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRFb['url']
     elif ctsidPMphTlQCaSVqAOxLrKHNwDRFb['code']=='CAIP0200':ctsidPMphTlQCaSVqAOxLrKHNwDRbB =ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRFb['url']
     elif ctsidPMphTlQCaSVqAOxLrKHNwDRFb['code']=='CAIP1800':ctsidPMphTlQCaSVqAOxLrKHNwDRby=ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRFb['url']
     elif ctsidPMphTlQCaSVqAOxLrKHNwDRFb['code']=='CAIP2000':ctsidPMphTlQCaSVqAOxLrKHNwDRbu =ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRFb['url']
     elif ctsidPMphTlQCaSVqAOxLrKHNwDRFb['code']=='CAIP1900':ctsidPMphTlQCaSVqAOxLrKHNwDRFe =ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRFb['url']
    ctsidPMphTlQCaSVqAOxLrKHNwDRbj =ctsidPMphTlQCaSVqAOxLrKHNwDRIW['program']['synopsis']['ko']
    try:
     ctsidPMphTlQCaSVqAOxLrKHNwDRFz=ctsidPMphTlQCaSVqAOxLrKHNwDRIW['channel']['name']['ko']
    except:
     ctsidPMphTlQCaSVqAOxLrKHNwDRFz=''
    try:
     ctsidPMphTlQCaSVqAOxLrKHNwDRFn =[]
     ctsidPMphTlQCaSVqAOxLrKHNwDRFU=[]
     ctsidPMphTlQCaSVqAOxLrKHNwDRFo =[]
     ctsidPMphTlQCaSVqAOxLrKHNwDRFX =''
     ctsidPMphTlQCaSVqAOxLrKHNwDRFY=''
     for ctsidPMphTlQCaSVqAOxLrKHNwDRFf in ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('program').get('actor'):
      if ctsidPMphTlQCaSVqAOxLrKHNwDRFf!='' and ctsidPMphTlQCaSVqAOxLrKHNwDRFf!='-' and ctsidPMphTlQCaSVqAOxLrKHNwDRFf!=u'없음':ctsidPMphTlQCaSVqAOxLrKHNwDRFn.append(ctsidPMphTlQCaSVqAOxLrKHNwDRFf)
     for ctsidPMphTlQCaSVqAOxLrKHNwDRFG in ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('program').get('director'):
      if ctsidPMphTlQCaSVqAOxLrKHNwDRFG!='' and ctsidPMphTlQCaSVqAOxLrKHNwDRFG!='-' and ctsidPMphTlQCaSVqAOxLrKHNwDRFG!=u'없음':ctsidPMphTlQCaSVqAOxLrKHNwDRFU.append(ctsidPMphTlQCaSVqAOxLrKHNwDRFG)
     if ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('program').get('category1_name').get('ko')!='':
      ctsidPMphTlQCaSVqAOxLrKHNwDRFo.append(ctsidPMphTlQCaSVqAOxLrKHNwDRIW['program']['category1_name']['ko'])
     if ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('program').get('category2_name').get('ko')!='':
      ctsidPMphTlQCaSVqAOxLrKHNwDRFo.append(ctsidPMphTlQCaSVqAOxLrKHNwDRIW['program']['category2_name']['ko'])
     if ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('program').get('product_year'):ctsidPMphTlQCaSVqAOxLrKHNwDRFX=ctsidPMphTlQCaSVqAOxLrKHNwDRIW['program']['product_year']
     if 'broad_dt' in ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('program'):
      ctsidPMphTlQCaSVqAOxLrKHNwDRFJ =ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('program').get('broad_dt')
      ctsidPMphTlQCaSVqAOxLrKHNwDRFY='%s-%s-%s'%(ctsidPMphTlQCaSVqAOxLrKHNwDRFJ[:4],ctsidPMphTlQCaSVqAOxLrKHNwDRFJ[4:6],ctsidPMphTlQCaSVqAOxLrKHNwDRFJ[6:])
    except:
     ctsidPMphTlQCaSVqAOxLrKHNwDRUk
    ctsidPMphTlQCaSVqAOxLrKHNwDRFE={'program':ctsidPMphTlQCaSVqAOxLrKHNwDRFW,'title':ctsidPMphTlQCaSVqAOxLrKHNwDRbv,'thumbnail':{'poster':ctsidPMphTlQCaSVqAOxLrKHNwDRbg,'thumb':ctsidPMphTlQCaSVqAOxLrKHNwDRbB,'clearlogo':ctsidPMphTlQCaSVqAOxLrKHNwDRby,'icon':ctsidPMphTlQCaSVqAOxLrKHNwDRbu,'banner':ctsidPMphTlQCaSVqAOxLrKHNwDRFe,'fanart':ctsidPMphTlQCaSVqAOxLrKHNwDRbB},'synopsis':ctsidPMphTlQCaSVqAOxLrKHNwDRbj,'channel':ctsidPMphTlQCaSVqAOxLrKHNwDRFz,'cast':ctsidPMphTlQCaSVqAOxLrKHNwDRFn,'director':ctsidPMphTlQCaSVqAOxLrKHNwDRFU,'info_genre':ctsidPMphTlQCaSVqAOxLrKHNwDRFo,'year':ctsidPMphTlQCaSVqAOxLrKHNwDRFX,'premiered':ctsidPMphTlQCaSVqAOxLrKHNwDRFY,'mpaa':ctsidPMphTlQCaSVqAOxLrKHNwDRFk}
    ctsidPMphTlQCaSVqAOxLrKHNwDRIf.append(ctsidPMphTlQCaSVqAOxLrKHNwDRFE)
   if ctsidPMphTlQCaSVqAOxLrKHNwDRIE['body']['has_more']=='Y':ctsidPMphTlQCaSVqAOxLrKHNwDRbG=ctsidPMphTlQCaSVqAOxLrKHNwDRUG
  except ctsidPMphTlQCaSVqAOxLrKHNwDRUW as exception:
   ctsidPMphTlQCaSVqAOxLrKHNwDRUE(exception)
  return ctsidPMphTlQCaSVqAOxLrKHNwDRIf,ctsidPMphTlQCaSVqAOxLrKHNwDRbG
 def GetEpisodeList(ctsidPMphTlQCaSVqAOxLrKHNwDRen,program_code,page_int,orderby='desc'):
  ctsidPMphTlQCaSVqAOxLrKHNwDRIf=[]
  ctsidPMphTlQCaSVqAOxLrKHNwDRbG=ctsidPMphTlQCaSVqAOxLrKHNwDRUY
  try:
   ctsidPMphTlQCaSVqAOxLrKHNwDRIk ='/v2/media/frequency/program/'+program_code
   ctsidPMphTlQCaSVqAOxLrKHNwDRIg=ctsidPMphTlQCaSVqAOxLrKHNwDRen.GetDefaultParams()
   ctsidPMphTlQCaSVqAOxLrKHNwDRIm={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   ctsidPMphTlQCaSVqAOxLrKHNwDRIg.update(ctsidPMphTlQCaSVqAOxLrKHNwDRIm)
   ctsidPMphTlQCaSVqAOxLrKHNwDRIy=ctsidPMphTlQCaSVqAOxLrKHNwDRen.API_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRIk
   ctsidPMphTlQCaSVqAOxLrKHNwDRIF=ctsidPMphTlQCaSVqAOxLrKHNwDRen.callRequestCookies('Get',ctsidPMphTlQCaSVqAOxLrKHNwDRIy,payload=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,params=ctsidPMphTlQCaSVqAOxLrKHNwDRIg,headers=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,cookies=ctsidPMphTlQCaSVqAOxLrKHNwDRUk)
   ctsidPMphTlQCaSVqAOxLrKHNwDRIE=json.loads(ctsidPMphTlQCaSVqAOxLrKHNwDRIF.text)
   if not('result' in ctsidPMphTlQCaSVqAOxLrKHNwDRIE['body']):return ctsidPMphTlQCaSVqAOxLrKHNwDRIf,ctsidPMphTlQCaSVqAOxLrKHNwDRbG
   ctsidPMphTlQCaSVqAOxLrKHNwDRbm=ctsidPMphTlQCaSVqAOxLrKHNwDRIE['body']['result']
   ctsidPMphTlQCaSVqAOxLrKHNwDRFv=ctsidPMphTlQCaSVqAOxLrKHNwDRUJ(ctsidPMphTlQCaSVqAOxLrKHNwDRIE['body']['total_count'])
   ctsidPMphTlQCaSVqAOxLrKHNwDRFj =ctsidPMphTlQCaSVqAOxLrKHNwDRUJ(ctsidPMphTlQCaSVqAOxLrKHNwDRFv//(ctsidPMphTlQCaSVqAOxLrKHNwDRen.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    ctsidPMphTlQCaSVqAOxLrKHNwDRFB =(ctsidPMphTlQCaSVqAOxLrKHNwDRFv-1)-((page_int-1)*ctsidPMphTlQCaSVqAOxLrKHNwDRen.EPISODE_LIMIT)
   else:
    ctsidPMphTlQCaSVqAOxLrKHNwDRFB =(page_int-1)*ctsidPMphTlQCaSVqAOxLrKHNwDRen.EPISODE_LIMIT
   for i in ctsidPMphTlQCaSVqAOxLrKHNwDRUm(ctsidPMphTlQCaSVqAOxLrKHNwDRen.EPISODE_LIMIT):
    if orderby=='desc':
     ctsidPMphTlQCaSVqAOxLrKHNwDRFg=ctsidPMphTlQCaSVqAOxLrKHNwDRFB-i
     if ctsidPMphTlQCaSVqAOxLrKHNwDRFg<0:break
    else:
     ctsidPMphTlQCaSVqAOxLrKHNwDRFg=ctsidPMphTlQCaSVqAOxLrKHNwDRFB+i
     if ctsidPMphTlQCaSVqAOxLrKHNwDRFg>=ctsidPMphTlQCaSVqAOxLrKHNwDRFv:break
    ctsidPMphTlQCaSVqAOxLrKHNwDRFy=ctsidPMphTlQCaSVqAOxLrKHNwDRbm[ctsidPMphTlQCaSVqAOxLrKHNwDRFg]['episode']['code']
    ctsidPMphTlQCaSVqAOxLrKHNwDRbv =ctsidPMphTlQCaSVqAOxLrKHNwDRbm[ctsidPMphTlQCaSVqAOxLrKHNwDRFg]['vod_name']['ko']
    ctsidPMphTlQCaSVqAOxLrKHNwDRFu =''
    try:
     ctsidPMphTlQCaSVqAOxLrKHNwDRFJ=ctsidPMphTlQCaSVqAOxLrKHNwDRUv(ctsidPMphTlQCaSVqAOxLrKHNwDRbm[ctsidPMphTlQCaSVqAOxLrKHNwDRFg]['episode']['broadcast_date'])
     ctsidPMphTlQCaSVqAOxLrKHNwDRFu='%s-%s-%s'%(ctsidPMphTlQCaSVqAOxLrKHNwDRFJ[:4],ctsidPMphTlQCaSVqAOxLrKHNwDRFJ[4:6],ctsidPMphTlQCaSVqAOxLrKHNwDRFJ[6:])
    except:
     ctsidPMphTlQCaSVqAOxLrKHNwDRUk
    try:
     if ctsidPMphTlQCaSVqAOxLrKHNwDRbm[ctsidPMphTlQCaSVqAOxLrKHNwDRFg]['episode']['pip_cliptype']=='C012':
      ctsidPMphTlQCaSVqAOxLrKHNwDRFu+=' - Quick VOD'
    except:
     ctsidPMphTlQCaSVqAOxLrKHNwDRUk
    ctsidPMphTlQCaSVqAOxLrKHNwDRbj =ctsidPMphTlQCaSVqAOxLrKHNwDRbm[ctsidPMphTlQCaSVqAOxLrKHNwDRFg]['episode']['synopsis']['ko']
    ctsidPMphTlQCaSVqAOxLrKHNwDRbg =''
    ctsidPMphTlQCaSVqAOxLrKHNwDRbB =''
    ctsidPMphTlQCaSVqAOxLrKHNwDRby=''
    ctsidPMphTlQCaSVqAOxLrKHNwDRbu =''
    ctsidPMphTlQCaSVqAOxLrKHNwDRFe =''
    ctsidPMphTlQCaSVqAOxLrKHNwDRFI =''
    for ctsidPMphTlQCaSVqAOxLrKHNwDRFb in ctsidPMphTlQCaSVqAOxLrKHNwDRbm[ctsidPMphTlQCaSVqAOxLrKHNwDRFg]['program']['image']:
     if ctsidPMphTlQCaSVqAOxLrKHNwDRFb['code']=='CAIP0900':ctsidPMphTlQCaSVqAOxLrKHNwDRbg =ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRFb['url']
     elif ctsidPMphTlQCaSVqAOxLrKHNwDRFb['code']=='CAIP1800':ctsidPMphTlQCaSVqAOxLrKHNwDRby=ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRFb['url']
     elif ctsidPMphTlQCaSVqAOxLrKHNwDRFb['code']=='CAIP2000':ctsidPMphTlQCaSVqAOxLrKHNwDRbu =ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRFb['url']
     elif ctsidPMphTlQCaSVqAOxLrKHNwDRFb['code']=='CAIP1900':ctsidPMphTlQCaSVqAOxLrKHNwDRFe =ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRFb['url']
     elif ctsidPMphTlQCaSVqAOxLrKHNwDRFb['code']=='CAIP0200':ctsidPMphTlQCaSVqAOxLrKHNwDRFI =ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRFb['url']
    for ctsidPMphTlQCaSVqAOxLrKHNwDRFb in ctsidPMphTlQCaSVqAOxLrKHNwDRbm[ctsidPMphTlQCaSVqAOxLrKHNwDRFg]['episode']['image']:
     if ctsidPMphTlQCaSVqAOxLrKHNwDRFb['code']=='CAIE0400':ctsidPMphTlQCaSVqAOxLrKHNwDRbB =ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRFb['url']
    try:
     ctsidPMphTlQCaSVqAOxLrKHNwDRne=ctsidPMphTlQCaSVqAOxLrKHNwDRnb=ctsidPMphTlQCaSVqAOxLrKHNwDRnF=''
     ctsidPMphTlQCaSVqAOxLrKHNwDRnI=0
     ctsidPMphTlQCaSVqAOxLrKHNwDRne =ctsidPMphTlQCaSVqAOxLrKHNwDRbm[ctsidPMphTlQCaSVqAOxLrKHNwDRFg]['program']['name']['ko']
     ctsidPMphTlQCaSVqAOxLrKHNwDRnb =ctsidPMphTlQCaSVqAOxLrKHNwDRFu
     ctsidPMphTlQCaSVqAOxLrKHNwDRnF =ctsidPMphTlQCaSVqAOxLrKHNwDRbm[ctsidPMphTlQCaSVqAOxLrKHNwDRFg]['channel']['name']['ko']
     if 'frequency' in ctsidPMphTlQCaSVqAOxLrKHNwDRbm[ctsidPMphTlQCaSVqAOxLrKHNwDRFg]['episode']:ctsidPMphTlQCaSVqAOxLrKHNwDRnI=ctsidPMphTlQCaSVqAOxLrKHNwDRbm[ctsidPMphTlQCaSVqAOxLrKHNwDRFg]['episode']['frequency']
    except:
     ctsidPMphTlQCaSVqAOxLrKHNwDRUk
    ctsidPMphTlQCaSVqAOxLrKHNwDRFE={'episode':ctsidPMphTlQCaSVqAOxLrKHNwDRFy,'title':ctsidPMphTlQCaSVqAOxLrKHNwDRbv,'subtitle':ctsidPMphTlQCaSVqAOxLrKHNwDRFu,'thumbnail':{'poster':ctsidPMphTlQCaSVqAOxLrKHNwDRbg,'thumb':ctsidPMphTlQCaSVqAOxLrKHNwDRbB,'clearlogo':ctsidPMphTlQCaSVqAOxLrKHNwDRby,'icon':ctsidPMphTlQCaSVqAOxLrKHNwDRbu,'banner':ctsidPMphTlQCaSVqAOxLrKHNwDRFe,'fanart':ctsidPMphTlQCaSVqAOxLrKHNwDRFI},'synopsis':ctsidPMphTlQCaSVqAOxLrKHNwDRbj,'info_title':ctsidPMphTlQCaSVqAOxLrKHNwDRne,'aired':ctsidPMphTlQCaSVqAOxLrKHNwDRnb,'studio':ctsidPMphTlQCaSVqAOxLrKHNwDRnF,'frequency':ctsidPMphTlQCaSVqAOxLrKHNwDRnI}
    ctsidPMphTlQCaSVqAOxLrKHNwDRIf.append(ctsidPMphTlQCaSVqAOxLrKHNwDRFE)
   if ctsidPMphTlQCaSVqAOxLrKHNwDRFj>page_int:ctsidPMphTlQCaSVqAOxLrKHNwDRbG=ctsidPMphTlQCaSVqAOxLrKHNwDRUG
  except ctsidPMphTlQCaSVqAOxLrKHNwDRUW as exception:
   ctsidPMphTlQCaSVqAOxLrKHNwDRUE(exception)
  return ctsidPMphTlQCaSVqAOxLrKHNwDRIf,ctsidPMphTlQCaSVqAOxLrKHNwDRbG,ctsidPMphTlQCaSVqAOxLrKHNwDRFj
 def GetMovieList(ctsidPMphTlQCaSVqAOxLrKHNwDRen,genre,orderby,page_int):
  ctsidPMphTlQCaSVqAOxLrKHNwDRIf=[]
  ctsidPMphTlQCaSVqAOxLrKHNwDRbG=ctsidPMphTlQCaSVqAOxLrKHNwDRUY
  try:
   ctsidPMphTlQCaSVqAOxLrKHNwDRIk ='/v2/media/movies'
   ctsidPMphTlQCaSVqAOxLrKHNwDRIg=ctsidPMphTlQCaSVqAOxLrKHNwDRen.GetDefaultParams()
   ctsidPMphTlQCaSVqAOxLrKHNwDRIm={'pageSize':ctsidPMphTlQCaSVqAOxLrKHNwDRUv(ctsidPMphTlQCaSVqAOxLrKHNwDRen.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N','pageNo':ctsidPMphTlQCaSVqAOxLrKHNwDRUv(page_int),}
   if genre!='all' :ctsidPMphTlQCaSVqAOxLrKHNwDRIm['categoryCode']=genre
   ctsidPMphTlQCaSVqAOxLrKHNwDRIm['productPackageCode']=','.join(ctsidPMphTlQCaSVqAOxLrKHNwDRen.MOVIE_LITE)
   ctsidPMphTlQCaSVqAOxLrKHNwDRIg.update(ctsidPMphTlQCaSVqAOxLrKHNwDRIm)
   ctsidPMphTlQCaSVqAOxLrKHNwDRIy=ctsidPMphTlQCaSVqAOxLrKHNwDRen.API_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRIk
   ctsidPMphTlQCaSVqAOxLrKHNwDRIF=ctsidPMphTlQCaSVqAOxLrKHNwDRen.callRequestCookies('Get',ctsidPMphTlQCaSVqAOxLrKHNwDRIy,payload=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,params=ctsidPMphTlQCaSVqAOxLrKHNwDRIg,headers=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,cookies=ctsidPMphTlQCaSVqAOxLrKHNwDRUk)
   ctsidPMphTlQCaSVqAOxLrKHNwDRIE=json.loads(ctsidPMphTlQCaSVqAOxLrKHNwDRIF.text)
   if not('result' in ctsidPMphTlQCaSVqAOxLrKHNwDRIE['body']):return ctsidPMphTlQCaSVqAOxLrKHNwDRIf,ctsidPMphTlQCaSVqAOxLrKHNwDRbG
   ctsidPMphTlQCaSVqAOxLrKHNwDRbm=ctsidPMphTlQCaSVqAOxLrKHNwDRIE['body']['result']
   for ctsidPMphTlQCaSVqAOxLrKHNwDRIW in ctsidPMphTlQCaSVqAOxLrKHNwDRbm:
    if 'release_date' in ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('movie'):
     ctsidPMphTlQCaSVqAOxLrKHNwDRFX=ctsidPMphTlQCaSVqAOxLrKHNwDRUv(ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('movie').get('release_date'))[:4]
    else:
     ctsidPMphTlQCaSVqAOxLrKHNwDRFX=ctsidPMphTlQCaSVqAOxLrKHNwDRUk
    ctsidPMphTlQCaSVqAOxLrKHNwDRnU =ctsidPMphTlQCaSVqAOxLrKHNwDRIW['movie']['code']
    ctsidPMphTlQCaSVqAOxLrKHNwDRbv =ctsidPMphTlQCaSVqAOxLrKHNwDRIW['movie']['name']['ko'].strip()
    if ctsidPMphTlQCaSVqAOxLrKHNwDRFX not in[ctsidPMphTlQCaSVqAOxLrKHNwDRUk,'0','']:ctsidPMphTlQCaSVqAOxLrKHNwDRbv+=u' (%s)'%(ctsidPMphTlQCaSVqAOxLrKHNwDRFX)
    ctsidPMphTlQCaSVqAOxLrKHNwDRbg=''
    ctsidPMphTlQCaSVqAOxLrKHNwDRbB =''
    ctsidPMphTlQCaSVqAOxLrKHNwDRby=''
    for ctsidPMphTlQCaSVqAOxLrKHNwDRFb in ctsidPMphTlQCaSVqAOxLrKHNwDRIW['movie']['image']:
     if ctsidPMphTlQCaSVqAOxLrKHNwDRFb['code']=='CAIM2100':ctsidPMphTlQCaSVqAOxLrKHNwDRbg =ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRFb['url']
     elif ctsidPMphTlQCaSVqAOxLrKHNwDRFb['code']=='CAIM0400':ctsidPMphTlQCaSVqAOxLrKHNwDRbB =ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRFb['url']
     elif ctsidPMphTlQCaSVqAOxLrKHNwDRFb['code']=='CAIM1800':ctsidPMphTlQCaSVqAOxLrKHNwDRby=ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRFb['url']
    ctsidPMphTlQCaSVqAOxLrKHNwDRbj =ctsidPMphTlQCaSVqAOxLrKHNwDRIW['movie']['story']['ko']
    try:
     ctsidPMphTlQCaSVqAOxLrKHNwDRne =ctsidPMphTlQCaSVqAOxLrKHNwDRIW['movie']['name']['ko'].strip()
     ctsidPMphTlQCaSVqAOxLrKHNwDRFk =ctsidPMphTlQCaSVqAOxLrKHNwDReF.get(ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('grade_code'))
     ctsidPMphTlQCaSVqAOxLrKHNwDRFn=[]
     ctsidPMphTlQCaSVqAOxLrKHNwDRFU=[]
     ctsidPMphTlQCaSVqAOxLrKHNwDRFo=[]
     ctsidPMphTlQCaSVqAOxLrKHNwDRno=0
     ctsidPMphTlQCaSVqAOxLrKHNwDRFY=''
     ctsidPMphTlQCaSVqAOxLrKHNwDRnF =''
     for ctsidPMphTlQCaSVqAOxLrKHNwDRFf in ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('movie').get('actor'):
      if ctsidPMphTlQCaSVqAOxLrKHNwDRFf!='':ctsidPMphTlQCaSVqAOxLrKHNwDRFn.append(ctsidPMphTlQCaSVqAOxLrKHNwDRFf)
     for ctsidPMphTlQCaSVqAOxLrKHNwDRFG in ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('movie').get('director'):
      if ctsidPMphTlQCaSVqAOxLrKHNwDRFG!='':ctsidPMphTlQCaSVqAOxLrKHNwDRFU.append(ctsidPMphTlQCaSVqAOxLrKHNwDRFG)
     if ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('movie').get('category1_name').get('ko')!='':
      ctsidPMphTlQCaSVqAOxLrKHNwDRFo.append(ctsidPMphTlQCaSVqAOxLrKHNwDRIW['movie']['category1_name']['ko'])
     if ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('movie').get('category2_name').get('ko')!='':
      ctsidPMphTlQCaSVqAOxLrKHNwDRFo.append(ctsidPMphTlQCaSVqAOxLrKHNwDRIW['movie']['category2_name']['ko'])
     if 'duration' in ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('movie'):ctsidPMphTlQCaSVqAOxLrKHNwDRno=ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('movie').get('duration')
     if 'release_date' in ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('movie'):
      ctsidPMphTlQCaSVqAOxLrKHNwDRFJ=ctsidPMphTlQCaSVqAOxLrKHNwDRUv(ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('movie').get('release_date'))
      if ctsidPMphTlQCaSVqAOxLrKHNwDRFJ!='0':ctsidPMphTlQCaSVqAOxLrKHNwDRFY='%s-%s-%s'%(ctsidPMphTlQCaSVqAOxLrKHNwDRFJ[:4],ctsidPMphTlQCaSVqAOxLrKHNwDRFJ[4:6],ctsidPMphTlQCaSVqAOxLrKHNwDRFJ[6:])
     if 'production' in ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('movie'):ctsidPMphTlQCaSVqAOxLrKHNwDRnF=ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('movie').get('production')
    except:
     ctsidPMphTlQCaSVqAOxLrKHNwDRUk
    ctsidPMphTlQCaSVqAOxLrKHNwDRFE={'moviecode':ctsidPMphTlQCaSVqAOxLrKHNwDRnU,'title':ctsidPMphTlQCaSVqAOxLrKHNwDRbv,'thumbnail':{'poster':ctsidPMphTlQCaSVqAOxLrKHNwDRbg,'thumb':ctsidPMphTlQCaSVqAOxLrKHNwDRbB,'clearlogo':ctsidPMphTlQCaSVqAOxLrKHNwDRby,'fanart':ctsidPMphTlQCaSVqAOxLrKHNwDRbB},'synopsis':ctsidPMphTlQCaSVqAOxLrKHNwDRbj,'info_title':ctsidPMphTlQCaSVqAOxLrKHNwDRne,'year':ctsidPMphTlQCaSVqAOxLrKHNwDRFX,'cast':ctsidPMphTlQCaSVqAOxLrKHNwDRFn,'director':ctsidPMphTlQCaSVqAOxLrKHNwDRFU,'info_genre':ctsidPMphTlQCaSVqAOxLrKHNwDRFo,'duration':ctsidPMphTlQCaSVqAOxLrKHNwDRno,'premiered':ctsidPMphTlQCaSVqAOxLrKHNwDRFY,'studio':ctsidPMphTlQCaSVqAOxLrKHNwDRnF,'mpaa':ctsidPMphTlQCaSVqAOxLrKHNwDRFk}
    ctsidPMphTlQCaSVqAOxLrKHNwDRnX=ctsidPMphTlQCaSVqAOxLrKHNwDRUY
    for ctsidPMphTlQCaSVqAOxLrKHNwDRnk in ctsidPMphTlQCaSVqAOxLrKHNwDRIW['billing_package_id']:
     if ctsidPMphTlQCaSVqAOxLrKHNwDRnk in ctsidPMphTlQCaSVqAOxLrKHNwDRen.MOVIE_LITE:
      ctsidPMphTlQCaSVqAOxLrKHNwDRnX=ctsidPMphTlQCaSVqAOxLrKHNwDRUG
      break
    if ctsidPMphTlQCaSVqAOxLrKHNwDRnX==ctsidPMphTlQCaSVqAOxLrKHNwDRUY: 
     ctsidPMphTlQCaSVqAOxLrKHNwDRFE['title']=ctsidPMphTlQCaSVqAOxLrKHNwDRFE['title']+' [개별구매]'
    ctsidPMphTlQCaSVqAOxLrKHNwDRIf.append(ctsidPMphTlQCaSVqAOxLrKHNwDRFE)
   if ctsidPMphTlQCaSVqAOxLrKHNwDRIE['body']['has_more']=='Y':ctsidPMphTlQCaSVqAOxLrKHNwDRbG=ctsidPMphTlQCaSVqAOxLrKHNwDRUG
  except ctsidPMphTlQCaSVqAOxLrKHNwDRUW as exception:
   ctsidPMphTlQCaSVqAOxLrKHNwDRUE(exception)
  return ctsidPMphTlQCaSVqAOxLrKHNwDRIf,ctsidPMphTlQCaSVqAOxLrKHNwDRbG
 def GetMovieGenre(ctsidPMphTlQCaSVqAOxLrKHNwDRen):
  ctsidPMphTlQCaSVqAOxLrKHNwDRIf=[]
  ctsidPMphTlQCaSVqAOxLrKHNwDRbG=ctsidPMphTlQCaSVqAOxLrKHNwDRUY
  try:
   ctsidPMphTlQCaSVqAOxLrKHNwDRIk ='/v2/media/movie/curations'
   ctsidPMphTlQCaSVqAOxLrKHNwDRIg=ctsidPMphTlQCaSVqAOxLrKHNwDRen.GetDefaultParams()
   ctsidPMphTlQCaSVqAOxLrKHNwDRIm={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   ctsidPMphTlQCaSVqAOxLrKHNwDRIg.update(ctsidPMphTlQCaSVqAOxLrKHNwDRIm)
   ctsidPMphTlQCaSVqAOxLrKHNwDRIy=ctsidPMphTlQCaSVqAOxLrKHNwDRen.API_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRIk
   ctsidPMphTlQCaSVqAOxLrKHNwDRIF=ctsidPMphTlQCaSVqAOxLrKHNwDRen.callRequestCookies('Get',ctsidPMphTlQCaSVqAOxLrKHNwDRIy,payload=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,params=ctsidPMphTlQCaSVqAOxLrKHNwDRIg,headers=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,cookies=ctsidPMphTlQCaSVqAOxLrKHNwDRUk)
   ctsidPMphTlQCaSVqAOxLrKHNwDRIE=json.loads(ctsidPMphTlQCaSVqAOxLrKHNwDRIF.text)
   if not('result' in ctsidPMphTlQCaSVqAOxLrKHNwDRIE['body']):return ctsidPMphTlQCaSVqAOxLrKHNwDRIf,ctsidPMphTlQCaSVqAOxLrKHNwDRbG
   ctsidPMphTlQCaSVqAOxLrKHNwDRbm=ctsidPMphTlQCaSVqAOxLrKHNwDRIE['body']['result']
   for ctsidPMphTlQCaSVqAOxLrKHNwDRIW in ctsidPMphTlQCaSVqAOxLrKHNwDRbm:
    ctsidPMphTlQCaSVqAOxLrKHNwDRnY =ctsidPMphTlQCaSVqAOxLrKHNwDRIW['curation_code']
    ctsidPMphTlQCaSVqAOxLrKHNwDRnf =ctsidPMphTlQCaSVqAOxLrKHNwDRIW['curation_name']
    ctsidPMphTlQCaSVqAOxLrKHNwDRFE={'curation_code':ctsidPMphTlQCaSVqAOxLrKHNwDRnY,'curation_name':ctsidPMphTlQCaSVqAOxLrKHNwDRnf}
    ctsidPMphTlQCaSVqAOxLrKHNwDRIf.append(ctsidPMphTlQCaSVqAOxLrKHNwDRFE)
  except ctsidPMphTlQCaSVqAOxLrKHNwDRUW as exception:
   ctsidPMphTlQCaSVqAOxLrKHNwDRUE(exception)
  return ctsidPMphTlQCaSVqAOxLrKHNwDRIf,ctsidPMphTlQCaSVqAOxLrKHNwDRbG
 def GetSearchList(ctsidPMphTlQCaSVqAOxLrKHNwDRen,search_key,page_int,stype):
  ctsidPMphTlQCaSVqAOxLrKHNwDRnG=[]
  ctsidPMphTlQCaSVqAOxLrKHNwDRbG=ctsidPMphTlQCaSVqAOxLrKHNwDRUY
  try:
   ctsidPMphTlQCaSVqAOxLrKHNwDRIk ='/search/getSearch.jsp'
   ctsidPMphTlQCaSVqAOxLrKHNwDRIm={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':ctsidPMphTlQCaSVqAOxLrKHNwDRUv(page_int),'pageSize':ctsidPMphTlQCaSVqAOxLrKHNwDRUv(ctsidPMphTlQCaSVqAOxLrKHNwDRen.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':ctsidPMphTlQCaSVqAOxLrKHNwDRen.SCREENCODE,'os':ctsidPMphTlQCaSVqAOxLrKHNwDRen.OSCODE,'network':ctsidPMphTlQCaSVqAOxLrKHNwDRen.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':ctsidPMphTlQCaSVqAOxLrKHNwDRUv(ctsidPMphTlQCaSVqAOxLrKHNwDRen.SEARCH_LIMIT)if stype=='vod' else '','vodMVReqCnt':ctsidPMphTlQCaSVqAOxLrKHNwDRUv(ctsidPMphTlQCaSVqAOxLrKHNwDRen.SEARCH_LIMIT)if stype=='movie' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':''}
   ctsidPMphTlQCaSVqAOxLrKHNwDRIy=ctsidPMphTlQCaSVqAOxLrKHNwDRen.SEARCH_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRIk
   ctsidPMphTlQCaSVqAOxLrKHNwDRIF=ctsidPMphTlQCaSVqAOxLrKHNwDRen.callRequestCookies('Get',ctsidPMphTlQCaSVqAOxLrKHNwDRIy,payload=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,params=ctsidPMphTlQCaSVqAOxLrKHNwDRIm,headers=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,cookies=ctsidPMphTlQCaSVqAOxLrKHNwDRUk)
   ctsidPMphTlQCaSVqAOxLrKHNwDRIE=json.loads(ctsidPMphTlQCaSVqAOxLrKHNwDRIF.text)
   if stype=='vod':
    if not('programRsb' in ctsidPMphTlQCaSVqAOxLrKHNwDRIE):return ctsidPMphTlQCaSVqAOxLrKHNwDRnG,ctsidPMphTlQCaSVqAOxLrKHNwDRbG
    ctsidPMphTlQCaSVqAOxLrKHNwDRnJ=ctsidPMphTlQCaSVqAOxLrKHNwDRIE['programRsb']['dataList']
    ctsidPMphTlQCaSVqAOxLrKHNwDRnm =ctsidPMphTlQCaSVqAOxLrKHNwDRUJ(ctsidPMphTlQCaSVqAOxLrKHNwDRIE['programRsb']['count'])
    for ctsidPMphTlQCaSVqAOxLrKHNwDRIW in ctsidPMphTlQCaSVqAOxLrKHNwDRnJ:
     ctsidPMphTlQCaSVqAOxLrKHNwDRFW=ctsidPMphTlQCaSVqAOxLrKHNwDRIW['mast_cd']
     ctsidPMphTlQCaSVqAOxLrKHNwDRbv =ctsidPMphTlQCaSVqAOxLrKHNwDRIW['mast_nm']
     ctsidPMphTlQCaSVqAOxLrKHNwDRbg=ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRIW['web_url4']
     ctsidPMphTlQCaSVqAOxLrKHNwDRbB =ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRIW['web_url']
     try:
      ctsidPMphTlQCaSVqAOxLrKHNwDRFn =[]
      ctsidPMphTlQCaSVqAOxLrKHNwDRFU=[]
      ctsidPMphTlQCaSVqAOxLrKHNwDRFo =[]
      ctsidPMphTlQCaSVqAOxLrKHNwDRno =0
      ctsidPMphTlQCaSVqAOxLrKHNwDRFk =''
      ctsidPMphTlQCaSVqAOxLrKHNwDRFX =''
      ctsidPMphTlQCaSVqAOxLrKHNwDRnb =''
      if ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('actor') !='' and ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('actor') !='-':ctsidPMphTlQCaSVqAOxLrKHNwDRFn =ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('actor').split(',')
      if ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('director')!='' and ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('director')!='-':ctsidPMphTlQCaSVqAOxLrKHNwDRFU=ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('director').split(',')
      if ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('cate_nm')!='' and ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('cate_nm')!='-':ctsidPMphTlQCaSVqAOxLrKHNwDRFo =ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('cate_nm').split('/')
      if 'targetage' in ctsidPMphTlQCaSVqAOxLrKHNwDRIW:ctsidPMphTlQCaSVqAOxLrKHNwDRFk=ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('targetage')
      if 'broad_dt' in ctsidPMphTlQCaSVqAOxLrKHNwDRIW:
       ctsidPMphTlQCaSVqAOxLrKHNwDRFJ=ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('broad_dt')
       ctsidPMphTlQCaSVqAOxLrKHNwDRnb='%s-%s-%s'%(ctsidPMphTlQCaSVqAOxLrKHNwDRFJ[:4],ctsidPMphTlQCaSVqAOxLrKHNwDRFJ[4:6],ctsidPMphTlQCaSVqAOxLrKHNwDRFJ[6:])
       ctsidPMphTlQCaSVqAOxLrKHNwDRFX =ctsidPMphTlQCaSVqAOxLrKHNwDRFJ[:4]
     except:
      ctsidPMphTlQCaSVqAOxLrKHNwDRUk
     ctsidPMphTlQCaSVqAOxLrKHNwDRFE={'program':ctsidPMphTlQCaSVqAOxLrKHNwDRFW,'title':ctsidPMphTlQCaSVqAOxLrKHNwDRbv,'thumbnail':{'poster':ctsidPMphTlQCaSVqAOxLrKHNwDRbg,'thumb':ctsidPMphTlQCaSVqAOxLrKHNwDRbB,'fanart':ctsidPMphTlQCaSVqAOxLrKHNwDRbB},'synopsis':'','cast':ctsidPMphTlQCaSVqAOxLrKHNwDRFn,'director':ctsidPMphTlQCaSVqAOxLrKHNwDRFU,'info_genre':ctsidPMphTlQCaSVqAOxLrKHNwDRFo,'duration':ctsidPMphTlQCaSVqAOxLrKHNwDRno,'mpaa':ctsidPMphTlQCaSVqAOxLrKHNwDRFk,'year':ctsidPMphTlQCaSVqAOxLrKHNwDRFX,'aired':ctsidPMphTlQCaSVqAOxLrKHNwDRnb}
     ctsidPMphTlQCaSVqAOxLrKHNwDRnG.append(ctsidPMphTlQCaSVqAOxLrKHNwDRFE)
   else:
    if not('vodMVRsb' in ctsidPMphTlQCaSVqAOxLrKHNwDRIE):return ctsidPMphTlQCaSVqAOxLrKHNwDRnG,ctsidPMphTlQCaSVqAOxLrKHNwDRbG
    ctsidPMphTlQCaSVqAOxLrKHNwDRnE=ctsidPMphTlQCaSVqAOxLrKHNwDRIE['vodMVRsb']['dataList']
    ctsidPMphTlQCaSVqAOxLrKHNwDRnm =ctsidPMphTlQCaSVqAOxLrKHNwDRUJ(ctsidPMphTlQCaSVqAOxLrKHNwDRIE['vodMVRsb']['count'])
    for ctsidPMphTlQCaSVqAOxLrKHNwDRIW in ctsidPMphTlQCaSVqAOxLrKHNwDRnE:
     ctsidPMphTlQCaSVqAOxLrKHNwDRFW=ctsidPMphTlQCaSVqAOxLrKHNwDRIW['mast_cd']
     ctsidPMphTlQCaSVqAOxLrKHNwDRbv =ctsidPMphTlQCaSVqAOxLrKHNwDRIW['mast_nm'].strip()
     ctsidPMphTlQCaSVqAOxLrKHNwDRbg =ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRIW['web_url']
     ctsidPMphTlQCaSVqAOxLrKHNwDRbB =ctsidPMphTlQCaSVqAOxLrKHNwDRbg
     ctsidPMphTlQCaSVqAOxLrKHNwDRby=''
     try:
      ctsidPMphTlQCaSVqAOxLrKHNwDRFn =[]
      ctsidPMphTlQCaSVqAOxLrKHNwDRFU=[]
      ctsidPMphTlQCaSVqAOxLrKHNwDRFo =[]
      ctsidPMphTlQCaSVqAOxLrKHNwDRno =0
      ctsidPMphTlQCaSVqAOxLrKHNwDRFk =''
      ctsidPMphTlQCaSVqAOxLrKHNwDRFX =''
      ctsidPMphTlQCaSVqAOxLrKHNwDRnb =''
      if ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('actor') !='' and ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('actor') !='-':ctsidPMphTlQCaSVqAOxLrKHNwDRFn =ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('actor').split(',')
      if ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('director')!='' and ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('director')!='-':ctsidPMphTlQCaSVqAOxLrKHNwDRFU=ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('director').split(',')
      if ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('cate_nm')!='' and ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('cate_nm')!='-':ctsidPMphTlQCaSVqAOxLrKHNwDRFo =ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('cate_nm').split('/')
      if ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('runtime_sec')!='':ctsidPMphTlQCaSVqAOxLrKHNwDRno=ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('runtime_sec')
      if 'grade_nm' in ctsidPMphTlQCaSVqAOxLrKHNwDRIW:ctsidPMphTlQCaSVqAOxLrKHNwDRFk=ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('grade_nm')
      ctsidPMphTlQCaSVqAOxLrKHNwDRFJ=ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('broad_dt')
      if data_str!='':
       ctsidPMphTlQCaSVqAOxLrKHNwDRnb='%s-%s-%s'%(ctsidPMphTlQCaSVqAOxLrKHNwDRFJ[:4],ctsidPMphTlQCaSVqAOxLrKHNwDRFJ[4:6],ctsidPMphTlQCaSVqAOxLrKHNwDRFJ[6:])
       ctsidPMphTlQCaSVqAOxLrKHNwDRFX =ctsidPMphTlQCaSVqAOxLrKHNwDRFJ[:4]
     except:
      ctsidPMphTlQCaSVqAOxLrKHNwDRUk
     ctsidPMphTlQCaSVqAOxLrKHNwDRFE={'movie':ctsidPMphTlQCaSVqAOxLrKHNwDRFW,'title':ctsidPMphTlQCaSVqAOxLrKHNwDRbv,'thumbnail':{'poster':ctsidPMphTlQCaSVqAOxLrKHNwDRbg,'thumb':ctsidPMphTlQCaSVqAOxLrKHNwDRbB,'fanart':ctsidPMphTlQCaSVqAOxLrKHNwDRbB,'clearlogo':ctsidPMphTlQCaSVqAOxLrKHNwDRby},'synopsis':'','cast':ctsidPMphTlQCaSVqAOxLrKHNwDRFn,'director':ctsidPMphTlQCaSVqAOxLrKHNwDRFU,'info_genre':ctsidPMphTlQCaSVqAOxLrKHNwDRFo,'duration':ctsidPMphTlQCaSVqAOxLrKHNwDRno,'mpaa':ctsidPMphTlQCaSVqAOxLrKHNwDRFk,'year':ctsidPMphTlQCaSVqAOxLrKHNwDRFX,'aired':ctsidPMphTlQCaSVqAOxLrKHNwDRnb}
     ctsidPMphTlQCaSVqAOxLrKHNwDRnX=ctsidPMphTlQCaSVqAOxLrKHNwDRUY
     for ctsidPMphTlQCaSVqAOxLrKHNwDRnk in ctsidPMphTlQCaSVqAOxLrKHNwDRIW['bill']:
      if ctsidPMphTlQCaSVqAOxLrKHNwDRnk in ctsidPMphTlQCaSVqAOxLrKHNwDRen.MOVIE_LITE:
       ctsidPMphTlQCaSVqAOxLrKHNwDRnX=ctsidPMphTlQCaSVqAOxLrKHNwDRUG
       break
     if ctsidPMphTlQCaSVqAOxLrKHNwDRnX==ctsidPMphTlQCaSVqAOxLrKHNwDRUY: 
      ctsidPMphTlQCaSVqAOxLrKHNwDRFE['title']=ctsidPMphTlQCaSVqAOxLrKHNwDRFE['title']+' [개별구매]'
     ctsidPMphTlQCaSVqAOxLrKHNwDRnG.append(ctsidPMphTlQCaSVqAOxLrKHNwDRFE)
   if ctsidPMphTlQCaSVqAOxLrKHNwDRnm>(page_int*ctsidPMphTlQCaSVqAOxLrKHNwDRen.SEARCH_LIMIT):ctsidPMphTlQCaSVqAOxLrKHNwDRbG=ctsidPMphTlQCaSVqAOxLrKHNwDRUG
  except ctsidPMphTlQCaSVqAOxLrKHNwDRUW as exception:
   ctsidPMphTlQCaSVqAOxLrKHNwDRUE(exception)
  return ctsidPMphTlQCaSVqAOxLrKHNwDRnG,ctsidPMphTlQCaSVqAOxLrKHNwDRbG
 def GetBookmarkInfo(ctsidPMphTlQCaSVqAOxLrKHNwDRen,videoid,vidtype):
  ctsidPMphTlQCaSVqAOxLrKHNwDRnW={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   ctsidPMphTlQCaSVqAOxLrKHNwDRIy=ctsidPMphTlQCaSVqAOxLrKHNwDRen.API_DOMAIN+'/v2/media/program/'+videoid
   ctsidPMphTlQCaSVqAOxLrKHNwDRIg=ctsidPMphTlQCaSVqAOxLrKHNwDRen.GetDefaultParams()
   ctsidPMphTlQCaSVqAOxLrKHNwDRIm={'pageNo':'1','pageSize':'10','order':'name',}
   ctsidPMphTlQCaSVqAOxLrKHNwDRIg.update(ctsidPMphTlQCaSVqAOxLrKHNwDRIm)
   ctsidPMphTlQCaSVqAOxLrKHNwDRIF=ctsidPMphTlQCaSVqAOxLrKHNwDRen.callRequestCookies('Get',ctsidPMphTlQCaSVqAOxLrKHNwDRIy,payload=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,params=ctsidPMphTlQCaSVqAOxLrKHNwDRIg,headers=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,cookies=ctsidPMphTlQCaSVqAOxLrKHNwDRUk)
   ctsidPMphTlQCaSVqAOxLrKHNwDRnz=json.loads(ctsidPMphTlQCaSVqAOxLrKHNwDRIF.text)
   if not('body' in ctsidPMphTlQCaSVqAOxLrKHNwDRnz):return{}
   ctsidPMphTlQCaSVqAOxLrKHNwDRnv=ctsidPMphTlQCaSVqAOxLrKHNwDRnz['body']
   ctsidPMphTlQCaSVqAOxLrKHNwDRbv=ctsidPMphTlQCaSVqAOxLrKHNwDRnv.get('name').get('ko').strip()
   ctsidPMphTlQCaSVqAOxLrKHNwDRnW['saveinfo']['title'] =ctsidPMphTlQCaSVqAOxLrKHNwDRbv
   ctsidPMphTlQCaSVqAOxLrKHNwDRnW['saveinfo']['infoLabels']['title']=ctsidPMphTlQCaSVqAOxLrKHNwDRbv
   ctsidPMphTlQCaSVqAOxLrKHNwDRnW['saveinfo']['infoLabels']['mpaa'] =ctsidPMphTlQCaSVqAOxLrKHNwDReF.get(ctsidPMphTlQCaSVqAOxLrKHNwDRnv.get('grade_code'))
   ctsidPMphTlQCaSVqAOxLrKHNwDRnW['saveinfo']['infoLabels']['plot'] =ctsidPMphTlQCaSVqAOxLrKHNwDRnv.get('synopsis').get('ko')
   ctsidPMphTlQCaSVqAOxLrKHNwDRnW['saveinfo']['infoLabels']['year'] =ctsidPMphTlQCaSVqAOxLrKHNwDRnv.get('product_year')
   ctsidPMphTlQCaSVqAOxLrKHNwDRnW['saveinfo']['infoLabels']['cast'] =ctsidPMphTlQCaSVqAOxLrKHNwDRnv.get('actor')
   ctsidPMphTlQCaSVqAOxLrKHNwDRnW['saveinfo']['infoLabels']['director']=ctsidPMphTlQCaSVqAOxLrKHNwDRnv.get('director')
   if ctsidPMphTlQCaSVqAOxLrKHNwDRnv.get('category1_name').get('ko')!='':
    ctsidPMphTlQCaSVqAOxLrKHNwDRnW['saveinfo']['infoLabels']['genre'].append(ctsidPMphTlQCaSVqAOxLrKHNwDRnv.get('category1_name').get('ko'))
   if ctsidPMphTlQCaSVqAOxLrKHNwDRnv.get('category2_name').get('ko')!='':
    ctsidPMphTlQCaSVqAOxLrKHNwDRnW['saveinfo']['infoLabels']['genre'].append(ctsidPMphTlQCaSVqAOxLrKHNwDRnv.get('category2_name').get('ko'))
   ctsidPMphTlQCaSVqAOxLrKHNwDRFJ=ctsidPMphTlQCaSVqAOxLrKHNwDRUv(ctsidPMphTlQCaSVqAOxLrKHNwDRnv.get('broad_dt'))
   if ctsidPMphTlQCaSVqAOxLrKHNwDRFJ!='0':ctsidPMphTlQCaSVqAOxLrKHNwDRnW['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(ctsidPMphTlQCaSVqAOxLrKHNwDRFJ[:4],ctsidPMphTlQCaSVqAOxLrKHNwDRFJ[4:6],ctsidPMphTlQCaSVqAOxLrKHNwDRFJ[6:])
   ctsidPMphTlQCaSVqAOxLrKHNwDRbg =''
   ctsidPMphTlQCaSVqAOxLrKHNwDRbB =''
   ctsidPMphTlQCaSVqAOxLrKHNwDRby=''
   ctsidPMphTlQCaSVqAOxLrKHNwDRbu =''
   ctsidPMphTlQCaSVqAOxLrKHNwDRFe =''
   for ctsidPMphTlQCaSVqAOxLrKHNwDRFb in ctsidPMphTlQCaSVqAOxLrKHNwDRnv.get('image'):
    if ctsidPMphTlQCaSVqAOxLrKHNwDRFb.get('code')=='CAIP0900':ctsidPMphTlQCaSVqAOxLrKHNwDRbg =ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRFb.get('url')
    elif ctsidPMphTlQCaSVqAOxLrKHNwDRFb.get('code')=='CAIP0200':ctsidPMphTlQCaSVqAOxLrKHNwDRbB =ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRFb.get('url')
    elif ctsidPMphTlQCaSVqAOxLrKHNwDRFb.get('code')=='CAIP1800':ctsidPMphTlQCaSVqAOxLrKHNwDRby=ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRFb.get('url')
    elif ctsidPMphTlQCaSVqAOxLrKHNwDRFb.get('code')=='CAIP2000':ctsidPMphTlQCaSVqAOxLrKHNwDRbu =ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRFb.get('url')
    elif ctsidPMphTlQCaSVqAOxLrKHNwDRFb.get('code')=='CAIP1900':ctsidPMphTlQCaSVqAOxLrKHNwDRFe =ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRFb.get('url')
   ctsidPMphTlQCaSVqAOxLrKHNwDRnW['saveinfo']['thumbnail']['poster']=ctsidPMphTlQCaSVqAOxLrKHNwDRbg
   ctsidPMphTlQCaSVqAOxLrKHNwDRnW['saveinfo']['thumbnail']['thumb']=ctsidPMphTlQCaSVqAOxLrKHNwDRbB
   ctsidPMphTlQCaSVqAOxLrKHNwDRnW['saveinfo']['thumbnail']['clearlogo']=ctsidPMphTlQCaSVqAOxLrKHNwDRby
   ctsidPMphTlQCaSVqAOxLrKHNwDRnW['saveinfo']['thumbnail']['icon']=ctsidPMphTlQCaSVqAOxLrKHNwDRbu
   ctsidPMphTlQCaSVqAOxLrKHNwDRnW['saveinfo']['thumbnail']['banner']=ctsidPMphTlQCaSVqAOxLrKHNwDRFe
   ctsidPMphTlQCaSVqAOxLrKHNwDRnW['saveinfo']['thumbnail']['fanart']=ctsidPMphTlQCaSVqAOxLrKHNwDRbB
  else:
   ctsidPMphTlQCaSVqAOxLrKHNwDRIy=ctsidPMphTlQCaSVqAOxLrKHNwDRen.API_DOMAIN+'/v2a/media/stream/info'
   ctsidPMphTlQCaSVqAOxLrKHNwDRIg=ctsidPMphTlQCaSVqAOxLrKHNwDRen.GetDefaultParams()
   ctsidPMphTlQCaSVqAOxLrKHNwDRIm={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':ctsidPMphTlQCaSVqAOxLrKHNwDRen.TVING_UUID.split('-')[0],'uuid':ctsidPMphTlQCaSVqAOxLrKHNwDRen.TVING_UUID,'deviceInfo':'PC_Chrome','noCache':ctsidPMphTlQCaSVqAOxLrKHNwDRUv(ctsidPMphTlQCaSVqAOxLrKHNwDRen.GetNoCache(1)),'wm':'Y',}
   ctsidPMphTlQCaSVqAOxLrKHNwDRIg.update(ctsidPMphTlQCaSVqAOxLrKHNwDRIm)
   ctsidPMphTlQCaSVqAOxLrKHNwDRIF=ctsidPMphTlQCaSVqAOxLrKHNwDRen.callRequestCookies('Get',ctsidPMphTlQCaSVqAOxLrKHNwDRIy,payload=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,params=ctsidPMphTlQCaSVqAOxLrKHNwDRIg,headers=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,cookies=ctsidPMphTlQCaSVqAOxLrKHNwDRUk)
   ctsidPMphTlQCaSVqAOxLrKHNwDRnz=json.loads(ctsidPMphTlQCaSVqAOxLrKHNwDRIF.text)
   if not('content' in ctsidPMphTlQCaSVqAOxLrKHNwDRnz['body']):return{}
   ctsidPMphTlQCaSVqAOxLrKHNwDRnv=ctsidPMphTlQCaSVqAOxLrKHNwDRnz['body']['content']['info']['movie']
   ctsidPMphTlQCaSVqAOxLrKHNwDRbv =ctsidPMphTlQCaSVqAOxLrKHNwDRnv.get('name').get('ko').strip()
   ctsidPMphTlQCaSVqAOxLrKHNwDRnW['saveinfo']['infoLabels']['title']=ctsidPMphTlQCaSVqAOxLrKHNwDRbv
   ctsidPMphTlQCaSVqAOxLrKHNwDRbv +=u' (%s)'%(ctsidPMphTlQCaSVqAOxLrKHNwDRnv.get('product_year'))
   ctsidPMphTlQCaSVqAOxLrKHNwDRnW['saveinfo']['title'] =ctsidPMphTlQCaSVqAOxLrKHNwDRbv
   ctsidPMphTlQCaSVqAOxLrKHNwDRnW['saveinfo']['infoLabels']['mpaa'] =ctsidPMphTlQCaSVqAOxLrKHNwDReF.get(ctsidPMphTlQCaSVqAOxLrKHNwDRnv.get('grade_code'))
   ctsidPMphTlQCaSVqAOxLrKHNwDRnW['saveinfo']['infoLabels']['plot'] =ctsidPMphTlQCaSVqAOxLrKHNwDRnv.get('story').get('ko')
   ctsidPMphTlQCaSVqAOxLrKHNwDRnW['saveinfo']['infoLabels']['year'] =ctsidPMphTlQCaSVqAOxLrKHNwDRnv.get('product_year')
   ctsidPMphTlQCaSVqAOxLrKHNwDRnW['saveinfo']['infoLabels']['studio'] =ctsidPMphTlQCaSVqAOxLrKHNwDRnv.get('production')
   ctsidPMphTlQCaSVqAOxLrKHNwDRnW['saveinfo']['infoLabels']['duration']=ctsidPMphTlQCaSVqAOxLrKHNwDRnv.get('duration')
   ctsidPMphTlQCaSVqAOxLrKHNwDRnW['saveinfo']['infoLabels']['cast'] =ctsidPMphTlQCaSVqAOxLrKHNwDRnv.get('actor')
   ctsidPMphTlQCaSVqAOxLrKHNwDRnW['saveinfo']['infoLabels']['director']=ctsidPMphTlQCaSVqAOxLrKHNwDRnv.get('director')
   if ctsidPMphTlQCaSVqAOxLrKHNwDRnv.get('category1_name').get('ko')!='':
    ctsidPMphTlQCaSVqAOxLrKHNwDRnW['saveinfo']['infoLabels']['genre'].append(ctsidPMphTlQCaSVqAOxLrKHNwDRnv.get('category1_name').get('ko'))
   if ctsidPMphTlQCaSVqAOxLrKHNwDRnv.get('category2_name').get('ko')!='':
    ctsidPMphTlQCaSVqAOxLrKHNwDRnW['saveinfo']['infoLabels']['genre'].append(ctsidPMphTlQCaSVqAOxLrKHNwDRnv.get('category2_name').get('ko'))
   ctsidPMphTlQCaSVqAOxLrKHNwDRFJ=ctsidPMphTlQCaSVqAOxLrKHNwDRUv(ctsidPMphTlQCaSVqAOxLrKHNwDRnv.get('release_date'))
   if ctsidPMphTlQCaSVqAOxLrKHNwDRFJ!='0':ctsidPMphTlQCaSVqAOxLrKHNwDRnW['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(ctsidPMphTlQCaSVqAOxLrKHNwDRFJ[:4],ctsidPMphTlQCaSVqAOxLrKHNwDRFJ[4:6],ctsidPMphTlQCaSVqAOxLrKHNwDRFJ[6:])
   ctsidPMphTlQCaSVqAOxLrKHNwDRbg=''
   ctsidPMphTlQCaSVqAOxLrKHNwDRbB =''
   ctsidPMphTlQCaSVqAOxLrKHNwDRby=''
   for ctsidPMphTlQCaSVqAOxLrKHNwDRFb in ctsidPMphTlQCaSVqAOxLrKHNwDRnv.get('image'):
    if ctsidPMphTlQCaSVqAOxLrKHNwDRFb.get('code')=='CAIM2100':ctsidPMphTlQCaSVqAOxLrKHNwDRbg =ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRFb.get('url')
    elif ctsidPMphTlQCaSVqAOxLrKHNwDRFb.get('code')=='CAIM0400':ctsidPMphTlQCaSVqAOxLrKHNwDRbB =ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRFb.get('url')
    elif ctsidPMphTlQCaSVqAOxLrKHNwDRFb.get('code')=='CAIM1800':ctsidPMphTlQCaSVqAOxLrKHNwDRby=ctsidPMphTlQCaSVqAOxLrKHNwDRen.IMG_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRFb.get('url')
   ctsidPMphTlQCaSVqAOxLrKHNwDRnW['saveinfo']['thumbnail']['poster']=ctsidPMphTlQCaSVqAOxLrKHNwDRbg
   ctsidPMphTlQCaSVqAOxLrKHNwDRnW['saveinfo']['thumbnail']['thumb']=ctsidPMphTlQCaSVqAOxLrKHNwDRbg 
   ctsidPMphTlQCaSVqAOxLrKHNwDRnW['saveinfo']['thumbnail']['clearlogo']=ctsidPMphTlQCaSVqAOxLrKHNwDRby
   ctsidPMphTlQCaSVqAOxLrKHNwDRnW['saveinfo']['thumbnail']['fanart']=ctsidPMphTlQCaSVqAOxLrKHNwDRbB
  return ctsidPMphTlQCaSVqAOxLrKHNwDRnW
 def GetEuroChannelList(ctsidPMphTlQCaSVqAOxLrKHNwDRen):
  ctsidPMphTlQCaSVqAOxLrKHNwDRIf=[]
  try:
   ctsidPMphTlQCaSVqAOxLrKHNwDRIk ='/v2/operator/highlights'
   ctsidPMphTlQCaSVqAOxLrKHNwDRIg=ctsidPMphTlQCaSVqAOxLrKHNwDRen.GetDefaultParams()
   ctsidPMphTlQCaSVqAOxLrKHNwDRIm={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':ctsidPMphTlQCaSVqAOxLrKHNwDRUv(ctsidPMphTlQCaSVqAOxLrKHNwDRen.GetNoCache(2))}
   ctsidPMphTlQCaSVqAOxLrKHNwDRIg.update(ctsidPMphTlQCaSVqAOxLrKHNwDRIm)
   ctsidPMphTlQCaSVqAOxLrKHNwDRIy=ctsidPMphTlQCaSVqAOxLrKHNwDRen.API_DOMAIN+ctsidPMphTlQCaSVqAOxLrKHNwDRIk
   ctsidPMphTlQCaSVqAOxLrKHNwDRIF=ctsidPMphTlQCaSVqAOxLrKHNwDRen.callRequestCookies('Get',ctsidPMphTlQCaSVqAOxLrKHNwDRIy,payload=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,params=ctsidPMphTlQCaSVqAOxLrKHNwDRIg,headers=ctsidPMphTlQCaSVqAOxLrKHNwDRUk,cookies=ctsidPMphTlQCaSVqAOxLrKHNwDRUk)
   ctsidPMphTlQCaSVqAOxLrKHNwDRIE=json.loads(ctsidPMphTlQCaSVqAOxLrKHNwDRIF.text)
   if not('result' in ctsidPMphTlQCaSVqAOxLrKHNwDRIE['body']):return ctsidPMphTlQCaSVqAOxLrKHNwDRIf,ctsidPMphTlQCaSVqAOxLrKHNwDRbG
   ctsidPMphTlQCaSVqAOxLrKHNwDRbm=ctsidPMphTlQCaSVqAOxLrKHNwDRIE['body']['result']
   ctsidPMphTlQCaSVqAOxLrKHNwDRnj =ctsidPMphTlQCaSVqAOxLrKHNwDRen.Get_Now_Datetime()
   ctsidPMphTlQCaSVqAOxLrKHNwDRnB=ctsidPMphTlQCaSVqAOxLrKHNwDRnj+datetime.timedelta(days=-1)
   ctsidPMphTlQCaSVqAOxLrKHNwDRnB=ctsidPMphTlQCaSVqAOxLrKHNwDRUJ(ctsidPMphTlQCaSVqAOxLrKHNwDRnB.strftime('%Y%m%d'))
   for ctsidPMphTlQCaSVqAOxLrKHNwDRIW in ctsidPMphTlQCaSVqAOxLrKHNwDRbm:
    ctsidPMphTlQCaSVqAOxLrKHNwDRng=ctsidPMphTlQCaSVqAOxLrKHNwDRUJ(ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('content').get('banner_title2')[:8])
    if ctsidPMphTlQCaSVqAOxLrKHNwDRnB<=ctsidPMphTlQCaSVqAOxLrKHNwDRng:
     ctsidPMphTlQCaSVqAOxLrKHNwDRFE={'channel':ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('content').get('banner_sub_title3'),'title':ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('content').get('banner_title'),'subtitle':ctsidPMphTlQCaSVqAOxLrKHNwDRIW.get('content').get('banner_sub_title2'),}
     ctsidPMphTlQCaSVqAOxLrKHNwDRIf.append(ctsidPMphTlQCaSVqAOxLrKHNwDRFE)
  except ctsidPMphTlQCaSVqAOxLrKHNwDRUW as exception:
   ctsidPMphTlQCaSVqAOxLrKHNwDRUE(exception)
  return ctsidPMphTlQCaSVqAOxLrKHNwDRIf
 def Make_DecryptKey(ctsidPMphTlQCaSVqAOxLrKHNwDRen,step,mediacode='000',timecode='000'):
  if step=='1':
   ctsidPMphTlQCaSVqAOxLrKHNwDRny=ctsidPMphTlQCaSVqAOxLrKHNwDRUB('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   ctsidPMphTlQCaSVqAOxLrKHNwDRnu=ctsidPMphTlQCaSVqAOxLrKHNwDRUB('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   ctsidPMphTlQCaSVqAOxLrKHNwDRny=ctsidPMphTlQCaSVqAOxLrKHNwDRUB('kss2lym0kdw1lks3','utf-8')
   ctsidPMphTlQCaSVqAOxLrKHNwDRnu=ctsidPMphTlQCaSVqAOxLrKHNwDRUB([ctsidPMphTlQCaSVqAOxLrKHNwDRUg('*'),0x07,ctsidPMphTlQCaSVqAOxLrKHNwDRUg('r'),ctsidPMphTlQCaSVqAOxLrKHNwDRUg(';'),ctsidPMphTlQCaSVqAOxLrKHNwDRUg('7'),0x05,0x1e,0x01,ctsidPMphTlQCaSVqAOxLrKHNwDRUg('n'),ctsidPMphTlQCaSVqAOxLrKHNwDRUg('D'),0x02,ctsidPMphTlQCaSVqAOxLrKHNwDRUg('3'),ctsidPMphTlQCaSVqAOxLrKHNwDRUg('*'),ctsidPMphTlQCaSVqAOxLrKHNwDRUg('a'),ctsidPMphTlQCaSVqAOxLrKHNwDRUg('&'),ctsidPMphTlQCaSVqAOxLrKHNwDRUg('<')])
  return ctsidPMphTlQCaSVqAOxLrKHNwDRny,ctsidPMphTlQCaSVqAOxLrKHNwDRnu
 def DecryptPlaintext(ctsidPMphTlQCaSVqAOxLrKHNwDRen,ciphertext,encryption_key,init_vector):
  ctsidPMphTlQCaSVqAOxLrKHNwDRUe=AES.new(encryption_key,AES.MODE_CBC,init_vector,)
  ctsidPMphTlQCaSVqAOxLrKHNwDRUI=Padding.unpad(ctsidPMphTlQCaSVqAOxLrKHNwDRUe.decrypt(base64.standard_b64decode(ciphertext)),16)
  return ctsidPMphTlQCaSVqAOxLrKHNwDRUI.decode('utf-8')
 def Decrypt_Url(ctsidPMphTlQCaSVqAOxLrKHNwDRen,ciphertext,mediacode,ctsidPMphTlQCaSVqAOxLrKHNwDRbU):
  ctsidPMphTlQCaSVqAOxLrKHNwDRUb=''
  try:
   ctsidPMphTlQCaSVqAOxLrKHNwDRny,ctsidPMphTlQCaSVqAOxLrKHNwDRnu=ctsidPMphTlQCaSVqAOxLrKHNwDRen.Make_DecryptKey('1',mediacode=mediacode,timecode=ctsidPMphTlQCaSVqAOxLrKHNwDRbU)
   ctsidPMphTlQCaSVqAOxLrKHNwDRUF=json.loads(ctsidPMphTlQCaSVqAOxLrKHNwDRen.DecryptPlaintext(ciphertext,ctsidPMphTlQCaSVqAOxLrKHNwDRny,ctsidPMphTlQCaSVqAOxLrKHNwDRnu))
   ctsidPMphTlQCaSVqAOxLrKHNwDRUn =ctsidPMphTlQCaSVqAOxLrKHNwDRUF.get('broad_url')
   ctsidPMphTlQCaSVqAOxLrKHNwDRbo =ctsidPMphTlQCaSVqAOxLrKHNwDRUF.get('watermark') if 'watermark' in ctsidPMphTlQCaSVqAOxLrKHNwDRUF else ''
   ctsidPMphTlQCaSVqAOxLrKHNwDRbX=ctsidPMphTlQCaSVqAOxLrKHNwDRUF.get('watermarkKey')if 'watermarkKey' in ctsidPMphTlQCaSVqAOxLrKHNwDRUF else ''
   ctsidPMphTlQCaSVqAOxLrKHNwDRny,ctsidPMphTlQCaSVqAOxLrKHNwDRnu=ctsidPMphTlQCaSVqAOxLrKHNwDRen.Make_DecryptKey('2',mediacode=mediacode,timecode=ctsidPMphTlQCaSVqAOxLrKHNwDRbU)
   ctsidPMphTlQCaSVqAOxLrKHNwDRUb=ctsidPMphTlQCaSVqAOxLrKHNwDRen.DecryptPlaintext(ctsidPMphTlQCaSVqAOxLrKHNwDRUn,ctsidPMphTlQCaSVqAOxLrKHNwDRny,ctsidPMphTlQCaSVqAOxLrKHNwDRnu)
  except ctsidPMphTlQCaSVqAOxLrKHNwDRUW as exception:
   ctsidPMphTlQCaSVqAOxLrKHNwDRUE(exception)
  return ctsidPMphTlQCaSVqAOxLrKHNwDRUb,ctsidPMphTlQCaSVqAOxLrKHNwDRbo,ctsidPMphTlQCaSVqAOxLrKHNwDRbX
# Created by pyminifier (https://github.com/liftoff/pyminifier)
