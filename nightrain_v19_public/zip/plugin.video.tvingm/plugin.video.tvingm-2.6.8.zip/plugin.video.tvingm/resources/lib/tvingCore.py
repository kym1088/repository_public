__author__="NightRain"
EBAPlwcokhGTSNdaUtuXJWVLFzKvrn=print
EBAPlwcokhGTSNdaUtuXJWVLFzKvri=ImportError
EBAPlwcokhGTSNdaUtuXJWVLFzKvrC=object
EBAPlwcokhGTSNdaUtuXJWVLFzKvrY=None
EBAPlwcokhGTSNdaUtuXJWVLFzKvrx=False
EBAPlwcokhGTSNdaUtuXJWVLFzKvrI=str
EBAPlwcokhGTSNdaUtuXJWVLFzKvrb=open
EBAPlwcokhGTSNdaUtuXJWVLFzKvre=True
EBAPlwcokhGTSNdaUtuXJWVLFzKvrj=len
EBAPlwcokhGTSNdaUtuXJWVLFzKvrs=int
EBAPlwcokhGTSNdaUtuXJWVLFzKvgm=range
EBAPlwcokhGTSNdaUtuXJWVLFzKvgp=bytes
EBAPlwcokhGTSNdaUtuXJWVLFzKvgD=Exception
EBAPlwcokhGTSNdaUtuXJWVLFzKvgy=dict
EBAPlwcokhGTSNdaUtuXJWVLFzKvgq=list
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
import os
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
try:
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
 EBAPlwcokhGTSNdaUtuXJWVLFzKvrn('Cryptodome')
except EBAPlwcokhGTSNdaUtuXJWVLFzKvri:
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
 EBAPlwcokhGTSNdaUtuXJWVLFzKvrn('Crypto')
EBAPlwcokhGTSNdaUtuXJWVLFzKvmD={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
EBAPlwcokhGTSNdaUtuXJWVLFzKvmy ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
EBAPlwcokhGTSNdaUtuXJWVLFzKvmq =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
EBAPlwcokhGTSNdaUtuXJWVLFzKvmO=['TP2wgas1K9Q8F7B359108383','TPLYFLt9NxVcJjQhn7Ee0069','_tutB3583','authToken','cs','TSID','accessToken','refreshToken','_tving_token','GA360_USERTYPE_JSON','ADULT_CONFIRM_YN','LEGAL_CONFIRM_YN','TLPUDB35Qhn7',]
class EBAPlwcokhGTSNdaUtuXJWVLFzKvmp(EBAPlwcokhGTSNdaUtuXJWVLFzKvrC):
 def __init__(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR):
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.NETWORKCODE ='CSND0900'
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.OSCODE ='CSOD0900' 
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TELECODE ='CSCD0900'
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.SCREENCODE ='CSSD0100'
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.APIKEY_ATV ='f0f74595d2f123ffc362362e334aeb52' 
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.SCREENCODE_ATV ='CSSD1300' 
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.LIVE_LIMIT =20 
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.VOD_LIMIT =24 
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.EPISODE_LIMIT =30 
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.SEARCH_LIMIT =30 
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.MOVIE_LIMIT =24 
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.API_DOMAIN ='https://api.tving.com'
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN ='https://image.tving.com'
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.SEARCH_DOMAIN ='https://search-api.tving.com'
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.LOGIN_DOMAIN ='https://user.tving.com'
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.URL_DOMAIN ='https://www.tving.com'
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.MOVIE_LITE =['2610061','2610161','261062']
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.MODEL ='chrome_128.0.0.0' 
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.DEFAULT_HEADER ={'user-agent':EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.USER_AGENT}
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.COOKIE_FILE_NAME =''
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TV_SESSION_COOKIES1=''
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TV_SESSION_COOKIES2=''
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TV_STREAM_FILENAME =''
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TV_SESSION_TEXT1 =''
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TV_SESSION_TEXT2 =''
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.KodiVersion=20
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TV ={}
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.Init_TV_Total()
 def Init_TV_Total(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR):
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TV={'account':{},'cookies':{},}
 def callRequestCookies(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR,jobtype,EBAPlwcokhGTSNdaUtuXJWVLFzKvpb,payload=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,json=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,params=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,headers=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,cookies=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,redirects=EBAPlwcokhGTSNdaUtuXJWVLFzKvrx):
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmr=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.DEFAULT_HEADER
  if headers:EBAPlwcokhGTSNdaUtuXJWVLFzKvmr.update(headers)
  if jobtype=='Get':
   EBAPlwcokhGTSNdaUtuXJWVLFzKvmg=requests.get(EBAPlwcokhGTSNdaUtuXJWVLFzKvpb,params=params,headers=EBAPlwcokhGTSNdaUtuXJWVLFzKvmr,cookies=cookies,allow_redirects=redirects)
  else:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvmg=requests.post(EBAPlwcokhGTSNdaUtuXJWVLFzKvpb,data=payload,json=json,params=params,headers=EBAPlwcokhGTSNdaUtuXJWVLFzKvmr,cookies=cookies,allow_redirects=redirects)
  EBAPlwcokhGTSNdaUtuXJWVLFzKvrn(EBAPlwcokhGTSNdaUtuXJWVLFzKvrI(EBAPlwcokhGTSNdaUtuXJWVLFzKvmg.status_code)+' - '+EBAPlwcokhGTSNdaUtuXJWVLFzKvmg.url)
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvmg
 def JsonFile_Save(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR,filename,EBAPlwcokhGTSNdaUtuXJWVLFzKvmH):
  if filename=='':return EBAPlwcokhGTSNdaUtuXJWVLFzKvrx
  try:
   fp=EBAPlwcokhGTSNdaUtuXJWVLFzKvrb(filename,'w',-1,'utf-8')
   json.dump(EBAPlwcokhGTSNdaUtuXJWVLFzKvmH,fp,indent=4,ensure_ascii=EBAPlwcokhGTSNdaUtuXJWVLFzKvrx)
   fp.close()
  except:
   return EBAPlwcokhGTSNdaUtuXJWVLFzKvrx
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvre
 def JsonFile_Load(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR,filename):
  if filename=='':return{}
  try:
   fp=EBAPlwcokhGTSNdaUtuXJWVLFzKvrb(filename,'r',-1,'utf-8')
   EBAPlwcokhGTSNdaUtuXJWVLFzKvmQ=json.load(fp)
   fp.close()
  except:
   return{}
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvmQ
 def TextFile_Save(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR,filename,resText):
  if filename=='':return EBAPlwcokhGTSNdaUtuXJWVLFzKvrx
  try:
   fp=EBAPlwcokhGTSNdaUtuXJWVLFzKvrb(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return EBAPlwcokhGTSNdaUtuXJWVLFzKvrx
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvre
 def Save_session_acount(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR,EBAPlwcokhGTSNdaUtuXJWVLFzKvmf,EBAPlwcokhGTSNdaUtuXJWVLFzKvmn,EBAPlwcokhGTSNdaUtuXJWVLFzKvmi,EBAPlwcokhGTSNdaUtuXJWVLFzKvmC):
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TV['account']['tvid'] =base64.standard_b64encode(EBAPlwcokhGTSNdaUtuXJWVLFzKvmf.encode()).decode('utf-8')
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TV['account']['tvpw'] =base64.standard_b64encode(EBAPlwcokhGTSNdaUtuXJWVLFzKvmn.encode()).decode('utf-8')
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TV['account']['tvtype']=EBAPlwcokhGTSNdaUtuXJWVLFzKvmi 
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TV['account']['tvpf'] =EBAPlwcokhGTSNdaUtuXJWVLFzKvmC 
 def Load_session_acount(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR):
  try:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvmf =base64.standard_b64decode(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TV['account']['tvid']).decode('utf-8')
   EBAPlwcokhGTSNdaUtuXJWVLFzKvmn =base64.standard_b64decode(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TV['account']['tvpw']).decode('utf-8')
   EBAPlwcokhGTSNdaUtuXJWVLFzKvmi=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TV['account']['tvtype']
   EBAPlwcokhGTSNdaUtuXJWVLFzKvmC =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TV['account']['tvpf'] 
  except:
   return '','','0',0
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvmf,EBAPlwcokhGTSNdaUtuXJWVLFzKvmn,EBAPlwcokhGTSNdaUtuXJWVLFzKvmi,EBAPlwcokhGTSNdaUtuXJWVLFzKvmC
 def make_stream_header(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR,EBAPlwcokhGTSNdaUtuXJWVLFzKvme,EBAPlwcokhGTSNdaUtuXJWVLFzKvms):
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmY=''
  if EBAPlwcokhGTSNdaUtuXJWVLFzKvms not in[{},EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,'']:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvmx=EBAPlwcokhGTSNdaUtuXJWVLFzKvrj(EBAPlwcokhGTSNdaUtuXJWVLFzKvms)
   for EBAPlwcokhGTSNdaUtuXJWVLFzKvmI,EBAPlwcokhGTSNdaUtuXJWVLFzKvmb in EBAPlwcokhGTSNdaUtuXJWVLFzKvms.items():
    EBAPlwcokhGTSNdaUtuXJWVLFzKvmY+='{}={}'.format(EBAPlwcokhGTSNdaUtuXJWVLFzKvmI,EBAPlwcokhGTSNdaUtuXJWVLFzKvmb)
    EBAPlwcokhGTSNdaUtuXJWVLFzKvmx+=-1
    if EBAPlwcokhGTSNdaUtuXJWVLFzKvmx>0:EBAPlwcokhGTSNdaUtuXJWVLFzKvmY+='; '
   EBAPlwcokhGTSNdaUtuXJWVLFzKvme['cookie']=EBAPlwcokhGTSNdaUtuXJWVLFzKvmY
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmj=''
  i=0
  for EBAPlwcokhGTSNdaUtuXJWVLFzKvmI,EBAPlwcokhGTSNdaUtuXJWVLFzKvmb in EBAPlwcokhGTSNdaUtuXJWVLFzKvme.items():
   i=i+1
   if i>1:EBAPlwcokhGTSNdaUtuXJWVLFzKvmj+='&'
   EBAPlwcokhGTSNdaUtuXJWVLFzKvmj+='{}={}'.format(EBAPlwcokhGTSNdaUtuXJWVLFzKvmI,urllib.parse.quote(EBAPlwcokhGTSNdaUtuXJWVLFzKvmb))
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvmj
 def makeDefaultCookies(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR):
  EBAPlwcokhGTSNdaUtuXJWVLFzKvms={}
  for EBAPlwcokhGTSNdaUtuXJWVLFzKvmI,EBAPlwcokhGTSNdaUtuXJWVLFzKvmb in EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TV['cookies'].items():
   EBAPlwcokhGTSNdaUtuXJWVLFzKvms[EBAPlwcokhGTSNdaUtuXJWVLFzKvmI]=EBAPlwcokhGTSNdaUtuXJWVLFzKvmb
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvms
 def getDeviceStr(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR):
  EBAPlwcokhGTSNdaUtuXJWVLFzKvpm=[]
  EBAPlwcokhGTSNdaUtuXJWVLFzKvpm.append('Windows') 
  EBAPlwcokhGTSNdaUtuXJWVLFzKvpm.append('Chrome') 
  EBAPlwcokhGTSNdaUtuXJWVLFzKvpm.append('ko-KR') 
  EBAPlwcokhGTSNdaUtuXJWVLFzKvpm.append('undefined') 
  EBAPlwcokhGTSNdaUtuXJWVLFzKvpm.append('24') 
  EBAPlwcokhGTSNdaUtuXJWVLFzKvpm.append(u'한국 표준시')
  EBAPlwcokhGTSNdaUtuXJWVLFzKvpm.append('undefined') 
  EBAPlwcokhGTSNdaUtuXJWVLFzKvpm.append('undefined') 
  EBAPlwcokhGTSNdaUtuXJWVLFzKvpm.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  EBAPlwcokhGTSNdaUtuXJWVLFzKvpD=''
  for EBAPlwcokhGTSNdaUtuXJWVLFzKvpy in EBAPlwcokhGTSNdaUtuXJWVLFzKvpm:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpD+=EBAPlwcokhGTSNdaUtuXJWVLFzKvpy+'|'
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvpD
 def GetDefaultParams(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR,uhd=EBAPlwcokhGTSNdaUtuXJWVLFzKvrx):
  if uhd==EBAPlwcokhGTSNdaUtuXJWVLFzKvrx:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpq={'apiKey':EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.APIKEY,'networkCode':EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.NETWORKCODE,'osCode':EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.OSCODE,'teleCode':EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TELECODE,'screenCode':EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.SCREENCODE,}
  else:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpq={'apiKey':EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.APIKEY_ATV,'networkCode':EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.NETWORKCODE,'osCode':EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.OSCODE,'teleCode':EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TELECODE,'screenCode':EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.SCREENCODE_ATV,}
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvpq
 def GetNoCache(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR,timetype=1):
  if timetype==1:
   return EBAPlwcokhGTSNdaUtuXJWVLFzKvrs(time.time())
  else:
   return EBAPlwcokhGTSNdaUtuXJWVLFzKvrs(time.time()*1000)
 def GetUniqueid(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR,hValue=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY):
  if hValue:
   import hashlib
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpO=hashlib.sha1()
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpO.update(hValue.encode())
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpR=EBAPlwcokhGTSNdaUtuXJWVLFzKvpO.hexdigest()[:8]
  else:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpr=[0 for i in EBAPlwcokhGTSNdaUtuXJWVLFzKvgm(256)]
   for i in EBAPlwcokhGTSNdaUtuXJWVLFzKvgm(256):
    EBAPlwcokhGTSNdaUtuXJWVLFzKvpr[i]='%02x'%(i)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpg=EBAPlwcokhGTSNdaUtuXJWVLFzKvrs(4294967295*random.random())|0
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpR=EBAPlwcokhGTSNdaUtuXJWVLFzKvpr[255&EBAPlwcokhGTSNdaUtuXJWVLFzKvpg]+EBAPlwcokhGTSNdaUtuXJWVLFzKvpr[EBAPlwcokhGTSNdaUtuXJWVLFzKvpg>>8&255]+EBAPlwcokhGTSNdaUtuXJWVLFzKvpr[EBAPlwcokhGTSNdaUtuXJWVLFzKvpg>>16&255]+EBAPlwcokhGTSNdaUtuXJWVLFzKvpr[EBAPlwcokhGTSNdaUtuXJWVLFzKvpg>>24&255]
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvpR
 def Web_DecryptKey(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR):
  EBAPlwcokhGTSNdaUtuXJWVLFzKvpH=EBAPlwcokhGTSNdaUtuXJWVLFzKvgp('kss2lym0kdw1lks3','utf-8')
  EBAPlwcokhGTSNdaUtuXJWVLFzKvpM=EBAPlwcokhGTSNdaUtuXJWVLFzKvgp('6yhlJ4WF9ZIj6I8n','utf-8')
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvpH,EBAPlwcokhGTSNdaUtuXJWVLFzKvpM
 def Web_EncryptCiphertext(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR,EBAPlwcokhGTSNdaUtuXJWVLFzKvpC):
  EBAPlwcokhGTSNdaUtuXJWVLFzKvpQ,EBAPlwcokhGTSNdaUtuXJWVLFzKvpf=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.Web_DecryptKey()
  EBAPlwcokhGTSNdaUtuXJWVLFzKvpn=AES.new(EBAPlwcokhGTSNdaUtuXJWVLFzKvpQ,AES.MODE_CBC,EBAPlwcokhGTSNdaUtuXJWVLFzKvpf,)
  EBAPlwcokhGTSNdaUtuXJWVLFzKvpi=EBAPlwcokhGTSNdaUtuXJWVLFzKvpn.encrypt(Padding.pad(EBAPlwcokhGTSNdaUtuXJWVLFzKvpC.encode('utf-8'),16))
  return base64.standard_b64encode(EBAPlwcokhGTSNdaUtuXJWVLFzKvpi).decode('utf-8')
 def Web_DecryptPlaintext(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR,EBAPlwcokhGTSNdaUtuXJWVLFzKvpi):
  EBAPlwcokhGTSNdaUtuXJWVLFzKvpQ,EBAPlwcokhGTSNdaUtuXJWVLFzKvpf=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.Web_DecryptKey()
  EBAPlwcokhGTSNdaUtuXJWVLFzKvpn=AES.new(EBAPlwcokhGTSNdaUtuXJWVLFzKvpQ,AES.MODE_CBC,EBAPlwcokhGTSNdaUtuXJWVLFzKvpf,)
  EBAPlwcokhGTSNdaUtuXJWVLFzKvpC=Padding.unpad(EBAPlwcokhGTSNdaUtuXJWVLFzKvpn.decrypt(base64.standard_b64decode(EBAPlwcokhGTSNdaUtuXJWVLFzKvpi)),16)
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvpC.decode('utf-8')
 def WebCookies_Load(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR,wc_file):
  try:
   fp=EBAPlwcokhGTSNdaUtuXJWVLFzKvrb(wc_file,'r',-1,'utf-8')
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpY=fp.read()
   fp.close()
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpx=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.Web_DecryptPlaintext(EBAPlwcokhGTSNdaUtuXJWVLFzKvpY)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TV=json.loads(EBAPlwcokhGTSNdaUtuXJWVLFzKvpx)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpI =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.GetDeviceList()
   if EBAPlwcokhGTSNdaUtuXJWVLFzKvpI not in['','-']:
    EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TV['cookies']['tving_uuid']=EBAPlwcokhGTSNdaUtuXJWVLFzKvpI+'-'+EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.GetUniqueid(EBAPlwcokhGTSNdaUtuXJWVLFzKvpI)
  except:
   return EBAPlwcokhGTSNdaUtuXJWVLFzKvrx
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvre
 def GetCredential2(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR,user_id,user_pw,login_type,user_pf):
  try:
   if base64.standard_b64encode(user_id.encode()).decode('utf-8')=='a3ltOTUxMDg4':
    EBAPlwcokhGTSNdaUtuXJWVLFzKvpb='aHR0cDovL21pbmk5NTEwODguYXN1c2NvbW0uY29tOjE2NTcx'
   else:
    EBAPlwcokhGTSNdaUtuXJWVLFzKvpb='aHR0cDovLzEzMS4xODYuMjAuMTE0OjE2NTcx'
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpe={'addon':'tvingm','method':'LOGIN','data':{'type':login_type,'id':user_id,'pw':user_pw,'pf':user_pf,}}
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpe=json.dumps(EBAPlwcokhGTSNdaUtuXJWVLFzKvpe,separators=(',',':'))
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpe=base64.standard_b64encode(EBAPlwcokhGTSNdaUtuXJWVLFzKvpe.encode()).decode('utf-8')
   EBAPlwcokhGTSNdaUtuXJWVLFzKvme={'proxy-mini':EBAPlwcokhGTSNdaUtuXJWVLFzKvpe}
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpj=requests.get(base64.standard_b64decode(EBAPlwcokhGTSNdaUtuXJWVLFzKvpb).decode('utf-8'),headers=EBAPlwcokhGTSNdaUtuXJWVLFzKvme)
   if EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.status_code!=200:
    EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.Init_TV_Total()
    return EBAPlwcokhGTSNdaUtuXJWVLFzKvrx
   EBAPlwcokhGTSNdaUtuXJWVLFzKvps=base64.standard_b64decode(EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.text).decode('utf-8')
   EBAPlwcokhGTSNdaUtuXJWVLFzKvps=json.loads(EBAPlwcokhGTSNdaUtuXJWVLFzKvps)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TV['cookies']=EBAPlwcokhGTSNdaUtuXJWVLFzKvps
  except EBAPlwcokhGTSNdaUtuXJWVLFzKvgD as exception:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrn(exception)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.Init_TV_Total()
   return EBAPlwcokhGTSNdaUtuXJWVLFzKvrx
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvre
 def GetCredential(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR,user_id,user_pw,login_type,user_pf):
  from curl_cffi import requests
  EBAPlwcokhGTSNdaUtuXJWVLFzKvDm='chrome' 
  EBAPlwcokhGTSNdaUtuXJWVLFzKvDp=requests.Session()
  try:
   if login_type=='0':
    EBAPlwcokhGTSNdaUtuXJWVLFzKvDy='https://user.tving.com/pc/user/otherLogin.tving?loginType=10&from=pc&csite=&isAuto=false&rtUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   else:
    EBAPlwcokhGTSNdaUtuXJWVLFzKvDy='https://www.tving.com/account/login/tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   EBAPlwcokhGTSNdaUtuXJWVLFzKvme={'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7','accept-language':'ko-KR,ko;q=0.9','cache-control':'no-cache','pragma':'no-cache','priority':'u=0, i','referer':'https://www.tving.com/',}
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpj=EBAPlwcokhGTSNdaUtuXJWVLFzKvDp.get(EBAPlwcokhGTSNdaUtuXJWVLFzKvDy,headers=EBAPlwcokhGTSNdaUtuXJWVLFzKvme,impersonate=EBAPlwcokhGTSNdaUtuXJWVLFzKvDm)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrn('{} - {}'.format(EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.status_code,EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.url))
   for EBAPlwcokhGTSNdaUtuXJWVLFzKvDq in EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.cookies.jar:
    EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TV['cookies'][EBAPlwcokhGTSNdaUtuXJWVLFzKvDq.name]=EBAPlwcokhGTSNdaUtuXJWVLFzKvDq.value
  except EBAPlwcokhGTSNdaUtuXJWVLFzKvgD as exception:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrn(exception)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.Init_TV_Total()
   return EBAPlwcokhGTSNdaUtuXJWVLFzKvrx
  try:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDO=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDR={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':EBAPlwcokhGTSNdaUtuXJWVLFzKvrx,'cjOneCookie':'','kaptcha':'','returnUrl':'https://www.tving.com/onboarding','csite':'','rtUrl':'https%3A%2F%2Fwww.tving.com%2Fonboarding',}
   EBAPlwcokhGTSNdaUtuXJWVLFzKvme['referer']=EBAPlwcokhGTSNdaUtuXJWVLFzKvDy
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpj=EBAPlwcokhGTSNdaUtuXJWVLFzKvDp.post(url=EBAPlwcokhGTSNdaUtuXJWVLFzKvDO,data=EBAPlwcokhGTSNdaUtuXJWVLFzKvDR,headers=EBAPlwcokhGTSNdaUtuXJWVLFzKvme,impersonate=EBAPlwcokhGTSNdaUtuXJWVLFzKvDm)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrn('{} - {}'.format(EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.status_code,EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.url))
   for EBAPlwcokhGTSNdaUtuXJWVLFzKvDq in EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.cookies.jar:
    EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TV['cookies'][EBAPlwcokhGTSNdaUtuXJWVLFzKvDq.name]=EBAPlwcokhGTSNdaUtuXJWVLFzKvDq.value
  except EBAPlwcokhGTSNdaUtuXJWVLFzKvgD as exception:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrn(exception)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.Init_TV_Total()
   return EBAPlwcokhGTSNdaUtuXJWVLFzKvrx
  EBAPlwcokhGTSNdaUtuXJWVLFzKvDr=[]
  EBAPlwcokhGTSNdaUtuXJWVLFzKvDg =''
  try:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDH ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   EBAPlwcokhGTSNdaUtuXJWVLFzKvme['referer']=EBAPlwcokhGTSNdaUtuXJWVLFzKvDO
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpj=EBAPlwcokhGTSNdaUtuXJWVLFzKvDp.get(url=EBAPlwcokhGTSNdaUtuXJWVLFzKvDH,data=EBAPlwcokhGTSNdaUtuXJWVLFzKvDR,headers=EBAPlwcokhGTSNdaUtuXJWVLFzKvme,impersonate=EBAPlwcokhGTSNdaUtuXJWVLFzKvDm)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrn('{} - {}'.format(EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.status_code,EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.url))
   for EBAPlwcokhGTSNdaUtuXJWVLFzKvDq in EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.cookies.jar:
    EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TV['cookies'][EBAPlwcokhGTSNdaUtuXJWVLFzKvDq.name]=EBAPlwcokhGTSNdaUtuXJWVLFzKvDq.value
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDr =re.findall('data-profile-no="\d+"',EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.text)
   for i in EBAPlwcokhGTSNdaUtuXJWVLFzKvgm(EBAPlwcokhGTSNdaUtuXJWVLFzKvrj(EBAPlwcokhGTSNdaUtuXJWVLFzKvDr)):
    EBAPlwcokhGTSNdaUtuXJWVLFzKvDM =EBAPlwcokhGTSNdaUtuXJWVLFzKvDr[i].replace('data-profile-no=','').replace('"','')
    EBAPlwcokhGTSNdaUtuXJWVLFzKvDr[i]=EBAPlwcokhGTSNdaUtuXJWVLFzKvDM
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDg=EBAPlwcokhGTSNdaUtuXJWVLFzKvDr[user_pf]
  except EBAPlwcokhGTSNdaUtuXJWVLFzKvgD as exception:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrn(exception)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.Init_TV_Total()
   return EBAPlwcokhGTSNdaUtuXJWVLFzKvrx
  try:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDQ ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   EBAPlwcokhGTSNdaUtuXJWVLFzKvme['referer']=EBAPlwcokhGTSNdaUtuXJWVLFzKvDH
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDR={'profileNo':EBAPlwcokhGTSNdaUtuXJWVLFzKvDg}
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpj=EBAPlwcokhGTSNdaUtuXJWVLFzKvDp.post(url=EBAPlwcokhGTSNdaUtuXJWVLFzKvDQ,data=EBAPlwcokhGTSNdaUtuXJWVLFzKvDR,headers=EBAPlwcokhGTSNdaUtuXJWVLFzKvme,impersonate=EBAPlwcokhGTSNdaUtuXJWVLFzKvDm)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrn('{} - {}'.format(EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.status_code,EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.url))
   for EBAPlwcokhGTSNdaUtuXJWVLFzKvDq in EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.cookies.jar:
    EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TV['cookies'][EBAPlwcokhGTSNdaUtuXJWVLFzKvDq.name]=EBAPlwcokhGTSNdaUtuXJWVLFzKvDq.value
  except EBAPlwcokhGTSNdaUtuXJWVLFzKvgD as exception:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrn(exception)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.Init_TV_Total()
   return EBAPlwcokhGTSNdaUtuXJWVLFzKvrx
  EBAPlwcokhGTSNdaUtuXJWVLFzKvpI =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.GetDeviceList()
  if EBAPlwcokhGTSNdaUtuXJWVLFzKvpI not in['','-']:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TV['cookies']['tving_uuid']=EBAPlwcokhGTSNdaUtuXJWVLFzKvpI+'-'+EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.GetUniqueid(EBAPlwcokhGTSNdaUtuXJWVLFzKvpI)
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.JsonFile_Save(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.COOKIE_FILE_NAME,EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TV)
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvre
 def GetDeviceList(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR):
  EBAPlwcokhGTSNdaUtuXJWVLFzKvDf=[]
  EBAPlwcokhGTSNdaUtuXJWVLFzKvDn='-'
  try:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDH ='/v1/user/device/list'
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDi=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.API_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvDH
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDC=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.GetDefaultParams()
   EBAPlwcokhGTSNdaUtuXJWVLFzKvms=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.makeDefaultCookies()
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpj=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.callRequestCookies('Get',EBAPlwcokhGTSNdaUtuXJWVLFzKvDi,payload=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,params=EBAPlwcokhGTSNdaUtuXJWVLFzKvDC,headers=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,cookies=EBAPlwcokhGTSNdaUtuXJWVLFzKvms)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDY=json.loads(EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.text)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDf=EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrn(EBAPlwcokhGTSNdaUtuXJWVLFzKvDf)
   for EBAPlwcokhGTSNdaUtuXJWVLFzKvDx in EBAPlwcokhGTSNdaUtuXJWVLFzKvDf:
    if EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['model'].lower().startswith('pc'):
     EBAPlwcokhGTSNdaUtuXJWVLFzKvDn=EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['uuid']
     break
   if EBAPlwcokhGTSNdaUtuXJWVLFzKvDn=='-':
    EBAPlwcokhGTSNdaUtuXJWVLFzKvDn=EBAPlwcokhGTSNdaUtuXJWVLFzKvrI(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.GetNoCache(timetype=1))
  except EBAPlwcokhGTSNdaUtuXJWVLFzKvgD as exception:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrn(exception)
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvDn
 def Get_Now_Datetime(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR,mediacode,sel_quality,stype,pvrmode='-',optUHD=EBAPlwcokhGTSNdaUtuXJWVLFzKvrx):
  EBAPlwcokhGTSNdaUtuXJWVLFzKvDb ={'streaming_url':'','subtitleYn':EBAPlwcokhGTSNdaUtuXJWVLFzKvrx,'error_msg':'','drm_server_url':'','drm_header_key':'','drm_header_value':'','url_filename':'','watermark':'','watermarkKey':'','qt_stream':'',}
  EBAPlwcokhGTSNdaUtuXJWVLFzKvDn =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TV['cookies']['tving_uuid'].split('-')[0] 
  EBAPlwcokhGTSNdaUtuXJWVLFzKvDe =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TV['cookies']['tving_uuid'] 
  try:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDj=EBAPlwcokhGTSNdaUtuXJWVLFzKvrI(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.GetNoCache(1))
   if stype!='tvingtv':
    EBAPlwcokhGTSNdaUtuXJWVLFzKvDH ='/v2/media/stream/info'
    EBAPlwcokhGTSNdaUtuXJWVLFzKvDs=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.GetDefaultParams()
    EBAPlwcokhGTSNdaUtuXJWVLFzKvDC={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':EBAPlwcokhGTSNdaUtuXJWVLFzKvDe,'deviceInfo':'PC','noCache':EBAPlwcokhGTSNdaUtuXJWVLFzKvDj,}
    EBAPlwcokhGTSNdaUtuXJWVLFzKvDs.update(EBAPlwcokhGTSNdaUtuXJWVLFzKvDC)
    EBAPlwcokhGTSNdaUtuXJWVLFzKvpb=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.API_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvDH
    EBAPlwcokhGTSNdaUtuXJWVLFzKvms=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.makeDefaultCookies()
    EBAPlwcokhGTSNdaUtuXJWVLFzKvpj=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.callRequestCookies('Get',EBAPlwcokhGTSNdaUtuXJWVLFzKvpb,payload=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,params=EBAPlwcokhGTSNdaUtuXJWVLFzKvDs,headers=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,cookies=EBAPlwcokhGTSNdaUtuXJWVLFzKvms)
    if EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.status_code!=200:
     EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['error_msg']='First Step - {} error'.format(EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.status_code)
     return EBAPlwcokhGTSNdaUtuXJWVLFzKvDb
    EBAPlwcokhGTSNdaUtuXJWVLFzKvDY=json.loads(EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.text)
    if EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']['result']['code']=='060':
     for EBAPlwcokhGTSNdaUtuXJWVLFzKvmI,EBAPlwcokhGTSNdaUtuXJWVLFzKvmb in EBAPlwcokhGTSNdaUtuXJWVLFzKvmD.items():
      if EBAPlwcokhGTSNdaUtuXJWVLFzKvmb==sel_quality:
       EBAPlwcokhGTSNdaUtuXJWVLFzKvym=EBAPlwcokhGTSNdaUtuXJWVLFzKvmI
    elif EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']['result']['code']!='000':
     EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['error_msg']=EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']['result']['message']
     return EBAPlwcokhGTSNdaUtuXJWVLFzKvDb
    else: 
     if not('stream' in EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']):return EBAPlwcokhGTSNdaUtuXJWVLFzKvDb
     EBAPlwcokhGTSNdaUtuXJWVLFzKvyp=[]
     for EBAPlwcokhGTSNdaUtuXJWVLFzKvmI,EBAPlwcokhGTSNdaUtuXJWVLFzKvmb in EBAPlwcokhGTSNdaUtuXJWVLFzKvmD.items():
      for EBAPlwcokhGTSNdaUtuXJWVLFzKvDx in EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']['stream']['quality']:
       if EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['active']=='Y' and EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['code']==EBAPlwcokhGTSNdaUtuXJWVLFzKvmI:
        EBAPlwcokhGTSNdaUtuXJWVLFzKvyp.append({EBAPlwcokhGTSNdaUtuXJWVLFzKvmD.get(EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['code']):EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['code']})
     EBAPlwcokhGTSNdaUtuXJWVLFzKvym=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.CheckQuality(sel_quality,EBAPlwcokhGTSNdaUtuXJWVLFzKvyp)
     try:
      if optUHD==EBAPlwcokhGTSNdaUtuXJWVLFzKvre and EBAPlwcokhGTSNdaUtuXJWVLFzKvym=='stream50' and 'stream_support_info' in EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']['content']['info']:
       if EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']['content']['info']['stream_support_info']!=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY:
        if 'stream70' in EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']['content']['info']['stream_support_info']:
         EBAPlwcokhGTSNdaUtuXJWVLFzKvym='stream70'
         EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['qt_stream']='stream70'
     except:
      pass
     try:
      if optUHD==EBAPlwcokhGTSNdaUtuXJWVLFzKvre and EBAPlwcokhGTSNdaUtuXJWVLFzKvym=='stream50' and 'stream' in EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']['content']['info']:
       if EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']['content']['info']['stream']!=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY:
        for EBAPlwcokhGTSNdaUtuXJWVLFzKvDx in EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']['content']['info']['stream']:
         if EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['code']=='stream70':
          EBAPlwcokhGTSNdaUtuXJWVLFzKvym='stream70'
          break
     except:
      pass
   else:
    EBAPlwcokhGTSNdaUtuXJWVLFzKvym='stream40'
  except EBAPlwcokhGTSNdaUtuXJWVLFzKvgD as exception:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrn(exception)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['error_msg']='First Step - except error'
   return EBAPlwcokhGTSNdaUtuXJWVLFzKvDb
  EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['qt_stream']=EBAPlwcokhGTSNdaUtuXJWVLFzKvym
  EBAPlwcokhGTSNdaUtuXJWVLFzKvrn(EBAPlwcokhGTSNdaUtuXJWVLFzKvym)
  try:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDj=EBAPlwcokhGTSNdaUtuXJWVLFzKvrI(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.GetNoCache(1))
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDH ='/v3/media/stream/info'
   if EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['qt_stream']=='stream70':
    EBAPlwcokhGTSNdaUtuXJWVLFzKvDs=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.GetDefaultParams(uhd=EBAPlwcokhGTSNdaUtuXJWVLFzKvre)
    EBAPlwcokhGTSNdaUtuXJWVLFzKvDC={'mediaCode':mediacode,'deviceId':EBAPlwcokhGTSNdaUtuXJWVLFzKvDn,'uuid':EBAPlwcokhGTSNdaUtuXJWVLFzKvDe,'deviceInfo':'PC_Chrome WebView','streamCode':EBAPlwcokhGTSNdaUtuXJWVLFzKvym,'noCache':EBAPlwcokhGTSNdaUtuXJWVLFzKvDj,'callingFrom':'HTML5','model':'chrome webview_96.0.4664.104','videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   else:
    EBAPlwcokhGTSNdaUtuXJWVLFzKvDs=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.GetDefaultParams()
    EBAPlwcokhGTSNdaUtuXJWVLFzKvDC={'mediaCode':mediacode,'deviceId':EBAPlwcokhGTSNdaUtuXJWVLFzKvDn,'uuid':EBAPlwcokhGTSNdaUtuXJWVLFzKvDe,'deviceInfo':'PC_Chrome','streamCode':EBAPlwcokhGTSNdaUtuXJWVLFzKvym,'noCache':EBAPlwcokhGTSNdaUtuXJWVLFzKvDj,'callingFrom':'HTML5','model':EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.MODEL,'videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDs.update(EBAPlwcokhGTSNdaUtuXJWVLFzKvDC)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpb=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.API_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvDH
   EBAPlwcokhGTSNdaUtuXJWVLFzKvms=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.makeDefaultCookies()
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpj=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.callRequestCookies('Post',EBAPlwcokhGTSNdaUtuXJWVLFzKvpb,payload=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,params=EBAPlwcokhGTSNdaUtuXJWVLFzKvDs,headers=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,cookies=EBAPlwcokhGTSNdaUtuXJWVLFzKvms,redirects=EBAPlwcokhGTSNdaUtuXJWVLFzKvre)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDY=json.loads(EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.text)
   if EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']['result']['code']!='000':
    EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['error_msg']=EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']['result']['message']
    return EBAPlwcokhGTSNdaUtuXJWVLFzKvDb
   EBAPlwcokhGTSNdaUtuXJWVLFzKvyD=EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']['stream']
   if EBAPlwcokhGTSNdaUtuXJWVLFzKvyD['drm_yn']=='Y':
    EBAPlwcokhGTSNdaUtuXJWVLFzKvyq=EBAPlwcokhGTSNdaUtuXJWVLFzKvyD['playback']['drm']['widevine']
    for EBAPlwcokhGTSNdaUtuXJWVLFzKvyO in EBAPlwcokhGTSNdaUtuXJWVLFzKvyD['playback']['drm']['license']['drm_license_data']:
     if EBAPlwcokhGTSNdaUtuXJWVLFzKvyO['drm_type']=='Widevine':
      EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['drm_server_url'] =EBAPlwcokhGTSNdaUtuXJWVLFzKvyO['drm_server_url']
      EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['drm_header_key'] =EBAPlwcokhGTSNdaUtuXJWVLFzKvyO['drm_header_key']
      EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['drm_header_value']=EBAPlwcokhGTSNdaUtuXJWVLFzKvyO['drm_header_value']
      break
   else:
    EBAPlwcokhGTSNdaUtuXJWVLFzKvyq=EBAPlwcokhGTSNdaUtuXJWVLFzKvyD['playback']['non_drm']
  except EBAPlwcokhGTSNdaUtuXJWVLFzKvgD as exception:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrn(exception)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['error_msg']='Second Step - except error'
   return EBAPlwcokhGTSNdaUtuXJWVLFzKvDb
  EBAPlwcokhGTSNdaUtuXJWVLFzKvyR=EBAPlwcokhGTSNdaUtuXJWVLFzKvDj
  EBAPlwcokhGTSNdaUtuXJWVLFzKvyq=EBAPlwcokhGTSNdaUtuXJWVLFzKvyq.split('|')[1]
  EBAPlwcokhGTSNdaUtuXJWVLFzKvyq,EBAPlwcokhGTSNdaUtuXJWVLFzKvyr,EBAPlwcokhGTSNdaUtuXJWVLFzKvyg=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.Decrypt_Url(EBAPlwcokhGTSNdaUtuXJWVLFzKvyq,mediacode,EBAPlwcokhGTSNdaUtuXJWVLFzKvyR)
  EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['streaming_url']=EBAPlwcokhGTSNdaUtuXJWVLFzKvyq
  EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['watermark'] =EBAPlwcokhGTSNdaUtuXJWVLFzKvyr
  EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['watermarkKey']=EBAPlwcokhGTSNdaUtuXJWVLFzKvyg
  if 'subtitles' in EBAPlwcokhGTSNdaUtuXJWVLFzKvyD:
   for EBAPlwcokhGTSNdaUtuXJWVLFzKvyH in EBAPlwcokhGTSNdaUtuXJWVLFzKvyD.get('subtitles'):
    if EBAPlwcokhGTSNdaUtuXJWVLFzKvyH.get('code')in['KO','KO_CC']:
     EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['subtitleYn']=EBAPlwcokhGTSNdaUtuXJWVLFzKvre
     break
  EBAPlwcokhGTSNdaUtuXJWVLFzKvyM=urllib.parse.urlparse(EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['streaming_url'])
  EBAPlwcokhGTSNdaUtuXJWVLFzKvyQ =EBAPlwcokhGTSNdaUtuXJWVLFzKvyM.path.strip('/').split('/')
  EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['url_filename']=EBAPlwcokhGTSNdaUtuXJWVLFzKvyQ[EBAPlwcokhGTSNdaUtuXJWVLFzKvrj(EBAPlwcokhGTSNdaUtuXJWVLFzKvyQ)-1]
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvDb
 def Tving_Parse_mpd(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR,stream_url,watermarkKey=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,watermark=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY):
  if watermarkKey not in['',EBAPlwcokhGTSNdaUtuXJWVLFzKvrY]:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvme={'X-Tving-Param1':watermarkKey,'X-Tving-Param2':watermark,}
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpj=requests.get(url=stream_url,headers=EBAPlwcokhGTSNdaUtuXJWVLFzKvme,allow_redirects=EBAPlwcokhGTSNdaUtuXJWVLFzKvrx)
  else:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpj=requests.get(url=stream_url)
  EBAPlwcokhGTSNdaUtuXJWVLFzKvyf=EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.content.decode('utf-8')
  EBAPlwcokhGTSNdaUtuXJWVLFzKvyn=0
  EBAPlwcokhGTSNdaUtuXJWVLFzKvyi =ET.ElementTree(ET.fromstring(EBAPlwcokhGTSNdaUtuXJWVLFzKvyf))
  EBAPlwcokhGTSNdaUtuXJWVLFzKvyC =EBAPlwcokhGTSNdaUtuXJWVLFzKvyi.getroot()
  EBAPlwcokhGTSNdaUtuXJWVLFzKvyY=re.match(r'\{.*\}',EBAPlwcokhGTSNdaUtuXJWVLFzKvyC.tag)[0] 
  EBAPlwcokhGTSNdaUtuXJWVLFzKvyx=EBAPlwcokhGTSNdaUtuXJWVLFzKvgy([node for _,node in ET.iterparse(io.StringIO(EBAPlwcokhGTSNdaUtuXJWVLFzKvyf),events=['start-ns'])])
  for EBAPlwcokhGTSNdaUtuXJWVLFzKvmI,EBAPlwcokhGTSNdaUtuXJWVLFzKvqQ in EBAPlwcokhGTSNdaUtuXJWVLFzKvyx.items():
   if EBAPlwcokhGTSNdaUtuXJWVLFzKvmI!='ns2':
    ET.register_namespace(EBAPlwcokhGTSNdaUtuXJWVLFzKvmI,EBAPlwcokhGTSNdaUtuXJWVLFzKvqQ)
  EBAPlwcokhGTSNdaUtuXJWVLFzKvyI=EBAPlwcokhGTSNdaUtuXJWVLFzKvyC.find(EBAPlwcokhGTSNdaUtuXJWVLFzKvyY+'Period')
  for EBAPlwcokhGTSNdaUtuXJWVLFzKvyb in EBAPlwcokhGTSNdaUtuXJWVLFzKvyI.findall(EBAPlwcokhGTSNdaUtuXJWVLFzKvyY+'AdaptationSet'):
   if(EBAPlwcokhGTSNdaUtuXJWVLFzKvyb.attrib.get('mimeType')=='video/mp4' or EBAPlwcokhGTSNdaUtuXJWVLFzKvyb.attrib.get('contentType')=='video'):
    for EBAPlwcokhGTSNdaUtuXJWVLFzKvye in EBAPlwcokhGTSNdaUtuXJWVLFzKvyb.findall(EBAPlwcokhGTSNdaUtuXJWVLFzKvyY+'Representation'):
     EBAPlwcokhGTSNdaUtuXJWVLFzKvyj=EBAPlwcokhGTSNdaUtuXJWVLFzKvrs(EBAPlwcokhGTSNdaUtuXJWVLFzKvye.attrib.get('bandwidth'))
     if EBAPlwcokhGTSNdaUtuXJWVLFzKvyn<EBAPlwcokhGTSNdaUtuXJWVLFzKvyj:EBAPlwcokhGTSNdaUtuXJWVLFzKvyn=EBAPlwcokhGTSNdaUtuXJWVLFzKvyj
    for EBAPlwcokhGTSNdaUtuXJWVLFzKvye in EBAPlwcokhGTSNdaUtuXJWVLFzKvyb.findall(EBAPlwcokhGTSNdaUtuXJWVLFzKvyY+'Representation'):
     if EBAPlwcokhGTSNdaUtuXJWVLFzKvyn>EBAPlwcokhGTSNdaUtuXJWVLFzKvrs(EBAPlwcokhGTSNdaUtuXJWVLFzKvye.attrib.get('bandwidth')):
      EBAPlwcokhGTSNdaUtuXJWVLFzKvyb.remove(EBAPlwcokhGTSNdaUtuXJWVLFzKvye)
   else:
    continue
  EBAPlwcokhGTSNdaUtuXJWVLFzKvys=ET.tostring(EBAPlwcokhGTSNdaUtuXJWVLFzKvyC).decode('utf-8')
  EBAPlwcokhGTSNdaUtuXJWVLFzKvqm='<?xml version="1.0" encoding="UTF-8"?>\n'
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TextFile_Save(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TV_STREAM_FILENAME,EBAPlwcokhGTSNdaUtuXJWVLFzKvqm+EBAPlwcokhGTSNdaUtuXJWVLFzKvys)
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvre
 def Tving_Parse_m3u8(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR,stream_url):
  try:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpj=requests.get(url=stream_url,headers=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,stream=EBAPlwcokhGTSNdaUtuXJWVLFzKvre)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvqp=EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.content.decode('utf-8')
   if '#EXTM3U' not in EBAPlwcokhGTSNdaUtuXJWVLFzKvqp:
    return EBAPlwcokhGTSNdaUtuXJWVLFzKvrx
   if '#EXT-X-STREAM-INF' not in EBAPlwcokhGTSNdaUtuXJWVLFzKvqp: 
    return EBAPlwcokhGTSNdaUtuXJWVLFzKvrx
   EBAPlwcokhGTSNdaUtuXJWVLFzKvqD=0
   for EBAPlwcokhGTSNdaUtuXJWVLFzKvqy in EBAPlwcokhGTSNdaUtuXJWVLFzKvqp.splitlines():
    if EBAPlwcokhGTSNdaUtuXJWVLFzKvqy.startswith('#EXT-X-STREAM-INF'):
     EBAPlwcokhGTSNdaUtuXJWVLFzKvqO=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.MediaLine_Parse(EBAPlwcokhGTSNdaUtuXJWVLFzKvqy,'#EXT-X-STREAM-INF')
     if EBAPlwcokhGTSNdaUtuXJWVLFzKvqD<EBAPlwcokhGTSNdaUtuXJWVLFzKvrs(EBAPlwcokhGTSNdaUtuXJWVLFzKvqO.get('BANDWIDTH')):
      EBAPlwcokhGTSNdaUtuXJWVLFzKvqD=EBAPlwcokhGTSNdaUtuXJWVLFzKvrs(EBAPlwcokhGTSNdaUtuXJWVLFzKvqO.get('BANDWIDTH'))
   EBAPlwcokhGTSNdaUtuXJWVLFzKvqR=[]
   EBAPlwcokhGTSNdaUtuXJWVLFzKvqr=EBAPlwcokhGTSNdaUtuXJWVLFzKvrx
   for EBAPlwcokhGTSNdaUtuXJWVLFzKvqy in EBAPlwcokhGTSNdaUtuXJWVLFzKvqp.splitlines():
    if EBAPlwcokhGTSNdaUtuXJWVLFzKvqr==EBAPlwcokhGTSNdaUtuXJWVLFzKvre:
     EBAPlwcokhGTSNdaUtuXJWVLFzKvqr=EBAPlwcokhGTSNdaUtuXJWVLFzKvrx
     continue
    if EBAPlwcokhGTSNdaUtuXJWVLFzKvqy.startswith('#EXT-X-STREAM-INF'):
     EBAPlwcokhGTSNdaUtuXJWVLFzKvqO=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.MediaLine_Parse(EBAPlwcokhGTSNdaUtuXJWVLFzKvqy,'#EXT-X-STREAM-INF')
     if EBAPlwcokhGTSNdaUtuXJWVLFzKvqD!=EBAPlwcokhGTSNdaUtuXJWVLFzKvrs(EBAPlwcokhGTSNdaUtuXJWVLFzKvqO.get('BANDWIDTH')):
      EBAPlwcokhGTSNdaUtuXJWVLFzKvqr=EBAPlwcokhGTSNdaUtuXJWVLFzKvre
      continue
    EBAPlwcokhGTSNdaUtuXJWVLFzKvqR.append(EBAPlwcokhGTSNdaUtuXJWVLFzKvqy)
  except EBAPlwcokhGTSNdaUtuXJWVLFzKvgD as exception:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrn(exception)
   return EBAPlwcokhGTSNdaUtuXJWVLFzKvrx
  EBAPlwcokhGTSNdaUtuXJWVLFzKvqg='\n'.join(EBAPlwcokhGTSNdaUtuXJWVLFzKvqR)
  EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TextFile_Save(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TV_STREAM_FILENAME,EBAPlwcokhGTSNdaUtuXJWVLFzKvqg)
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvre
 def MediaLine_Parse(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR,EBAPlwcokhGTSNdaUtuXJWVLFzKvqy,prefix):
  EBAPlwcokhGTSNdaUtuXJWVLFzKvqO={}
  for EBAPlwcokhGTSNdaUtuXJWVLFzKvqH in EBAPlwcokhGTSNdaUtuXJWVLFzKvmq.split(EBAPlwcokhGTSNdaUtuXJWVLFzKvqy.replace(prefix+':',''))[1::2]:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvqM,EBAPlwcokhGTSNdaUtuXJWVLFzKvqQ=EBAPlwcokhGTSNdaUtuXJWVLFzKvqH.split('=',1)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvqO[EBAPlwcokhGTSNdaUtuXJWVLFzKvqM.upper()]=EBAPlwcokhGTSNdaUtuXJWVLFzKvqQ.replace('"','').strip()
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvqO
 def CheckQuality(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR,sel_qt,EBAPlwcokhGTSNdaUtuXJWVLFzKvyp):
  for EBAPlwcokhGTSNdaUtuXJWVLFzKvqf in EBAPlwcokhGTSNdaUtuXJWVLFzKvyp:
   if sel_qt>=EBAPlwcokhGTSNdaUtuXJWVLFzKvgq(EBAPlwcokhGTSNdaUtuXJWVLFzKvqf)[0]:return EBAPlwcokhGTSNdaUtuXJWVLFzKvqf.get(EBAPlwcokhGTSNdaUtuXJWVLFzKvgq(EBAPlwcokhGTSNdaUtuXJWVLFzKvqf)[0])
   EBAPlwcokhGTSNdaUtuXJWVLFzKvqn=EBAPlwcokhGTSNdaUtuXJWVLFzKvqf.get(EBAPlwcokhGTSNdaUtuXJWVLFzKvgq(EBAPlwcokhGTSNdaUtuXJWVLFzKvqf)[0])
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvqn
 def makeOocUrl(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR,ooc_params):
  EBAPlwcokhGTSNdaUtuXJWVLFzKvpb=''
  for EBAPlwcokhGTSNdaUtuXJWVLFzKvmI,EBAPlwcokhGTSNdaUtuXJWVLFzKvmb in ooc_params.items():
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpb+="%s=%s^"%(EBAPlwcokhGTSNdaUtuXJWVLFzKvmI,EBAPlwcokhGTSNdaUtuXJWVLFzKvmb)
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvpb
 def GetLiveChannelList(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR,stype,page_int):
  EBAPlwcokhGTSNdaUtuXJWVLFzKvDf=[]
  EBAPlwcokhGTSNdaUtuXJWVLFzKvqi=EBAPlwcokhGTSNdaUtuXJWVLFzKvrx
  try:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDH ='/v2/media/lives'
   if stype=='onair': 
    EBAPlwcokhGTSNdaUtuXJWVLFzKvqC='CPCS0100,CPCS0400'
   else:
    EBAPlwcokhGTSNdaUtuXJWVLFzKvqC='CPCS0300'
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDs=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.GetDefaultParams()
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDC={'cacheType':'main','pageNo':EBAPlwcokhGTSNdaUtuXJWVLFzKvrI(page_int),'pageSize':EBAPlwcokhGTSNdaUtuXJWVLFzKvrI(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':EBAPlwcokhGTSNdaUtuXJWVLFzKvqC,}
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDs.update(EBAPlwcokhGTSNdaUtuXJWVLFzKvDC)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpb=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.API_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvDH
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpj=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.callRequestCookies('Get',EBAPlwcokhGTSNdaUtuXJWVLFzKvpb,payload=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,params=EBAPlwcokhGTSNdaUtuXJWVLFzKvDs,headers=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,cookies=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDY=json.loads(EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.text)
   if not('result' in EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']):return EBAPlwcokhGTSNdaUtuXJWVLFzKvDf,EBAPlwcokhGTSNdaUtuXJWVLFzKvqi
   EBAPlwcokhGTSNdaUtuXJWVLFzKvqY=EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']['result']
   for EBAPlwcokhGTSNdaUtuXJWVLFzKvDx in EBAPlwcokhGTSNdaUtuXJWVLFzKvqY:
    EBAPlwcokhGTSNdaUtuXJWVLFzKvqx=EBAPlwcokhGTSNdaUtuXJWVLFzKvqe=EBAPlwcokhGTSNdaUtuXJWVLFzKvqj=''
    EBAPlwcokhGTSNdaUtuXJWVLFzKvqI=EBAPlwcokhGTSNdaUtuXJWVLFzKvOY=''
    EBAPlwcokhGTSNdaUtuXJWVLFzKvqb=EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['live_code']
    EBAPlwcokhGTSNdaUtuXJWVLFzKvqx =EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['schedule']['channel']['name']['ko']
    if EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['schedule']['episode']!=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY:
     EBAPlwcokhGTSNdaUtuXJWVLFzKvqe =EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['schedule']['program']['name']['ko']
     EBAPlwcokhGTSNdaUtuXJWVLFzKvqe =EBAPlwcokhGTSNdaUtuXJWVLFzKvqe+', '+EBAPlwcokhGTSNdaUtuXJWVLFzKvrI(EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['schedule']['episode']['frequency'])+'회'
     EBAPlwcokhGTSNdaUtuXJWVLFzKvqj=EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['schedule']['episode']['synopsis']['ko']
    else:
     EBAPlwcokhGTSNdaUtuXJWVLFzKvqe =EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['schedule']['program']['name']['ko']
     EBAPlwcokhGTSNdaUtuXJWVLFzKvqj=EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['schedule']['program']['synopsis']['ko']
    try: 
     EBAPlwcokhGTSNdaUtuXJWVLFzKvqs =''
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOm =''
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOp=''
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOD =''
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOy =''
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOq =''
     for EBAPlwcokhGTSNdaUtuXJWVLFzKvOR in EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['schedule']['program']['image']:
      if EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['code']=='CAIP0900':EBAPlwcokhGTSNdaUtuXJWVLFzKvOm =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['url']
      elif EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['code']=='CAIP1800':EBAPlwcokhGTSNdaUtuXJWVLFzKvOp=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['url']
      elif EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['code']=='CAIP2000':EBAPlwcokhGTSNdaUtuXJWVLFzKvOD =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['url']
      elif EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['code']=='CAIP1900':EBAPlwcokhGTSNdaUtuXJWVLFzKvOy =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['url']
      elif EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['code']=='CAIP0200':EBAPlwcokhGTSNdaUtuXJWVLFzKvOq =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['url']
      elif EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['code']=='CAIP0500':EBAPlwcokhGTSNdaUtuXJWVLFzKvqs =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['url']
      elif EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['code']=='CAIP0800':EBAPlwcokhGTSNdaUtuXJWVLFzKvqs =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['url']
     if EBAPlwcokhGTSNdaUtuXJWVLFzKvqs=='':
      for EBAPlwcokhGTSNdaUtuXJWVLFzKvOR in EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['schedule']['channel']['image']:
       if EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['code']=='CAIC0400':EBAPlwcokhGTSNdaUtuXJWVLFzKvqs =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['url']
       elif EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['code']=='CAIC1400':EBAPlwcokhGTSNdaUtuXJWVLFzKvqs =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['url']
       elif EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['code']=='CAIC1900':EBAPlwcokhGTSNdaUtuXJWVLFzKvqs =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['url']
    except:
     EBAPlwcokhGTSNdaUtuXJWVLFzKvrY
    try:
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOr =[]
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOg=[]
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOH =[]
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOM=''
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOQ=''
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOf=''
     for EBAPlwcokhGTSNdaUtuXJWVLFzKvOn in EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('schedule').get('program').get('actor'):
      if EBAPlwcokhGTSNdaUtuXJWVLFzKvOn!='' and EBAPlwcokhGTSNdaUtuXJWVLFzKvOn!=u'없음':EBAPlwcokhGTSNdaUtuXJWVLFzKvOr.append(EBAPlwcokhGTSNdaUtuXJWVLFzKvOn)
     for EBAPlwcokhGTSNdaUtuXJWVLFzKvOi in EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('schedule').get('program').get('director'):
      if EBAPlwcokhGTSNdaUtuXJWVLFzKvOi!='' and EBAPlwcokhGTSNdaUtuXJWVLFzKvOi!='-' and EBAPlwcokhGTSNdaUtuXJWVLFzKvOi!=u'없음':EBAPlwcokhGTSNdaUtuXJWVLFzKvOg.append(EBAPlwcokhGTSNdaUtuXJWVLFzKvOi)
     if EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('schedule').get('program').get('category1_name').get('ko')!='':
      EBAPlwcokhGTSNdaUtuXJWVLFzKvOH.append(EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['schedule']['program']['category1_name']['ko'])
     if EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('schedule').get('program').get('category2_name').get('ko')!='':
      EBAPlwcokhGTSNdaUtuXJWVLFzKvOH.append(EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['schedule']['program']['category2_name']['ko'])
     if EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('schedule').get('program').get('product_year'):EBAPlwcokhGTSNdaUtuXJWVLFzKvOM=EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['schedule']['program']['product_year']
     if EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('schedule').get('program').get('grade_code') :EBAPlwcokhGTSNdaUtuXJWVLFzKvOQ= EBAPlwcokhGTSNdaUtuXJWVLFzKvmy.get(EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['schedule']['program']['grade_code'])
     if 'broad_dt' in EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('schedule').get('program'):
      EBAPlwcokhGTSNdaUtuXJWVLFzKvOC =EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('schedule').get('program').get('broad_dt')
      EBAPlwcokhGTSNdaUtuXJWVLFzKvOf='%s-%s-%s'%(EBAPlwcokhGTSNdaUtuXJWVLFzKvOC[:4],EBAPlwcokhGTSNdaUtuXJWVLFzKvOC[4:6],EBAPlwcokhGTSNdaUtuXJWVLFzKvOC[6:])
    except:
     EBAPlwcokhGTSNdaUtuXJWVLFzKvrY
    EBAPlwcokhGTSNdaUtuXJWVLFzKvqI=EBAPlwcokhGTSNdaUtuXJWVLFzKvrI(EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['schedule']['broadcast_start_time'])[8:12]
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOY =EBAPlwcokhGTSNdaUtuXJWVLFzKvrI(EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['schedule']['broadcast_end_time'])[8:12]
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOx={'channel':EBAPlwcokhGTSNdaUtuXJWVLFzKvqx,'title':EBAPlwcokhGTSNdaUtuXJWVLFzKvqe,'mediacode':EBAPlwcokhGTSNdaUtuXJWVLFzKvqb,'thumbnail':{'poster':EBAPlwcokhGTSNdaUtuXJWVLFzKvOm,'thumb':EBAPlwcokhGTSNdaUtuXJWVLFzKvqs,'clearlogo':EBAPlwcokhGTSNdaUtuXJWVLFzKvOp,'icon':EBAPlwcokhGTSNdaUtuXJWVLFzKvOD,'fanart':EBAPlwcokhGTSNdaUtuXJWVLFzKvOq},'synopsis':EBAPlwcokhGTSNdaUtuXJWVLFzKvqj,'channelepg':' [%s:%s ~ %s:%s]'%(EBAPlwcokhGTSNdaUtuXJWVLFzKvqI[0:2],EBAPlwcokhGTSNdaUtuXJWVLFzKvqI[2:],EBAPlwcokhGTSNdaUtuXJWVLFzKvOY[0:2],EBAPlwcokhGTSNdaUtuXJWVLFzKvOY[2:]),'cast':EBAPlwcokhGTSNdaUtuXJWVLFzKvOr,'director':EBAPlwcokhGTSNdaUtuXJWVLFzKvOg,'info_genre':EBAPlwcokhGTSNdaUtuXJWVLFzKvOH,'year':EBAPlwcokhGTSNdaUtuXJWVLFzKvOM,'mpaa':EBAPlwcokhGTSNdaUtuXJWVLFzKvOQ,'premiered':EBAPlwcokhGTSNdaUtuXJWVLFzKvOf}
    EBAPlwcokhGTSNdaUtuXJWVLFzKvDf.append(EBAPlwcokhGTSNdaUtuXJWVLFzKvOx)
   if EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']['has_more']=='Y':
    EBAPlwcokhGTSNdaUtuXJWVLFzKvqi=EBAPlwcokhGTSNdaUtuXJWVLFzKvre
  except EBAPlwcokhGTSNdaUtuXJWVLFzKvgD as exception:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrn(exception)
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvDf,EBAPlwcokhGTSNdaUtuXJWVLFzKvqi
 def GetProgramList(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR,genre,orderby,page_int,genreCode='all'):
  EBAPlwcokhGTSNdaUtuXJWVLFzKvDf=[]
  EBAPlwcokhGTSNdaUtuXJWVLFzKvqi=EBAPlwcokhGTSNdaUtuXJWVLFzKvrx
  try:
   if genre=='PARAMOUNT':
    EBAPlwcokhGTSNdaUtuXJWVLFzKvDH ='/v2/media/paramount/episodes'
   else:
    EBAPlwcokhGTSNdaUtuXJWVLFzKvDH ='/v2/media/episodes'
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDs=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.GetDefaultParams()
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDC={'cacheType':'main','pageSize':EBAPlwcokhGTSNdaUtuXJWVLFzKvrI(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':EBAPlwcokhGTSNdaUtuXJWVLFzKvrI(page_int),}
   if genre not in['all','PARAMOUNT']:EBAPlwcokhGTSNdaUtuXJWVLFzKvDC['categoryCode']=genre
   if genreCode!='all' :EBAPlwcokhGTSNdaUtuXJWVLFzKvDC['genreCode'] =genreCode 
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDs.update(EBAPlwcokhGTSNdaUtuXJWVLFzKvDC)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpb=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.API_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvDH
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpj=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.callRequestCookies('Get',EBAPlwcokhGTSNdaUtuXJWVLFzKvpb,payload=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,params=EBAPlwcokhGTSNdaUtuXJWVLFzKvDs,headers=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,cookies=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDY=json.loads(EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.text)
   if not('result' in EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']):return EBAPlwcokhGTSNdaUtuXJWVLFzKvDf,EBAPlwcokhGTSNdaUtuXJWVLFzKvqi
   EBAPlwcokhGTSNdaUtuXJWVLFzKvqY=EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']['result']
   for EBAPlwcokhGTSNdaUtuXJWVLFzKvDx in EBAPlwcokhGTSNdaUtuXJWVLFzKvqY:
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOI=EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['program']['code']
    EBAPlwcokhGTSNdaUtuXJWVLFzKvqe =EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['program']['name']['ko']
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOQ =EBAPlwcokhGTSNdaUtuXJWVLFzKvmy.get(EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['program'].get('grade_code'))
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOm =''
    EBAPlwcokhGTSNdaUtuXJWVLFzKvqs =''
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOp=''
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOD =''
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOy =''
    for EBAPlwcokhGTSNdaUtuXJWVLFzKvOR in EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['program']['image']:
     if EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['code']=='CAIP0900':EBAPlwcokhGTSNdaUtuXJWVLFzKvOm =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['url']
     elif EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['code']=='CAIP0200':EBAPlwcokhGTSNdaUtuXJWVLFzKvqs =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['url']
     elif EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['code']=='CAIP1800':EBAPlwcokhGTSNdaUtuXJWVLFzKvOp=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['url']
     elif EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['code']=='CAIP2000':EBAPlwcokhGTSNdaUtuXJWVLFzKvOD =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['url']
     elif EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['code']=='CAIP1900':EBAPlwcokhGTSNdaUtuXJWVLFzKvOy =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['url']
    EBAPlwcokhGTSNdaUtuXJWVLFzKvqj =EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['program']['synopsis']['ko']
    try:
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOb=EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['channel']['name']['ko']
    except:
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOb=''
    try:
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOr =[]
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOg=[]
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOH =[]
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOM =''
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOf=''
     for EBAPlwcokhGTSNdaUtuXJWVLFzKvOn in EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('program').get('actor'):
      if EBAPlwcokhGTSNdaUtuXJWVLFzKvOn!='' and EBAPlwcokhGTSNdaUtuXJWVLFzKvOn!='-' and EBAPlwcokhGTSNdaUtuXJWVLFzKvOn!=u'없음':EBAPlwcokhGTSNdaUtuXJWVLFzKvOr.append(EBAPlwcokhGTSNdaUtuXJWVLFzKvOn)
     for EBAPlwcokhGTSNdaUtuXJWVLFzKvOi in EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('program').get('director'):
      if EBAPlwcokhGTSNdaUtuXJWVLFzKvOi!='' and EBAPlwcokhGTSNdaUtuXJWVLFzKvOi!='-' and EBAPlwcokhGTSNdaUtuXJWVLFzKvOi!=u'없음':EBAPlwcokhGTSNdaUtuXJWVLFzKvOg.append(EBAPlwcokhGTSNdaUtuXJWVLFzKvOi)
     if EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('program').get('category1_name').get('ko')!='':
      EBAPlwcokhGTSNdaUtuXJWVLFzKvOH.append(EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['program']['category1_name']['ko'])
     if EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('program').get('category2_name').get('ko')!='':
      EBAPlwcokhGTSNdaUtuXJWVLFzKvOH.append(EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['program']['category2_name']['ko'])
     if EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('program').get('product_year'):EBAPlwcokhGTSNdaUtuXJWVLFzKvOM=EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['program']['product_year']
     if 'broad_dt' in EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('program'):
      EBAPlwcokhGTSNdaUtuXJWVLFzKvOC =EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('program').get('broad_dt')
      EBAPlwcokhGTSNdaUtuXJWVLFzKvOf='%s-%s-%s'%(EBAPlwcokhGTSNdaUtuXJWVLFzKvOC[:4],EBAPlwcokhGTSNdaUtuXJWVLFzKvOC[4:6],EBAPlwcokhGTSNdaUtuXJWVLFzKvOC[6:])
    except:
     EBAPlwcokhGTSNdaUtuXJWVLFzKvrY
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOx={'program':EBAPlwcokhGTSNdaUtuXJWVLFzKvOI,'title':EBAPlwcokhGTSNdaUtuXJWVLFzKvqe,'thumbnail':{'poster':EBAPlwcokhGTSNdaUtuXJWVLFzKvOm,'thumb':EBAPlwcokhGTSNdaUtuXJWVLFzKvqs,'clearlogo':EBAPlwcokhGTSNdaUtuXJWVLFzKvOp,'icon':EBAPlwcokhGTSNdaUtuXJWVLFzKvOD,'banner':EBAPlwcokhGTSNdaUtuXJWVLFzKvOy,'fanart':EBAPlwcokhGTSNdaUtuXJWVLFzKvqs},'synopsis':EBAPlwcokhGTSNdaUtuXJWVLFzKvqj,'channel':EBAPlwcokhGTSNdaUtuXJWVLFzKvOb,'cast':EBAPlwcokhGTSNdaUtuXJWVLFzKvOr,'director':EBAPlwcokhGTSNdaUtuXJWVLFzKvOg,'info_genre':EBAPlwcokhGTSNdaUtuXJWVLFzKvOH,'year':EBAPlwcokhGTSNdaUtuXJWVLFzKvOM,'premiered':EBAPlwcokhGTSNdaUtuXJWVLFzKvOf,'mpaa':EBAPlwcokhGTSNdaUtuXJWVLFzKvOQ}
    EBAPlwcokhGTSNdaUtuXJWVLFzKvDf.append(EBAPlwcokhGTSNdaUtuXJWVLFzKvOx)
   if EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']['has_more']=='Y':EBAPlwcokhGTSNdaUtuXJWVLFzKvqi=EBAPlwcokhGTSNdaUtuXJWVLFzKvre
  except EBAPlwcokhGTSNdaUtuXJWVLFzKvgD as exception:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrn(exception)
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvDf,EBAPlwcokhGTSNdaUtuXJWVLFzKvqi
 def Get_UHD_ProgramList(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR,page_int):
  EBAPlwcokhGTSNdaUtuXJWVLFzKvDf=[]
  EBAPlwcokhGTSNdaUtuXJWVLFzKvqi=EBAPlwcokhGTSNdaUtuXJWVLFzKvrx
  try:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDH ='/v2/operator/highlights'
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDs=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.GetDefaultParams(uhd=EBAPlwcokhGTSNdaUtuXJWVLFzKvre)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDC={'positionKey':'SMTV_PROG_4K','pageSize':'20','page_int':EBAPlwcokhGTSNdaUtuXJWVLFzKvrI(page_int),'pocType':'APP_X_TVING_4.0.0',}
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDs.update(EBAPlwcokhGTSNdaUtuXJWVLFzKvDC)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpb=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.API_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvDH
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpj=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.callRequestCookies('Get',EBAPlwcokhGTSNdaUtuXJWVLFzKvpb,payload=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,params=EBAPlwcokhGTSNdaUtuXJWVLFzKvDs,headers=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,cookies=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDY=json.loads(EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.text)
   if not('result' in EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']):return EBAPlwcokhGTSNdaUtuXJWVLFzKvDf,EBAPlwcokhGTSNdaUtuXJWVLFzKvqi
   EBAPlwcokhGTSNdaUtuXJWVLFzKvqY=EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']['result']
   for EBAPlwcokhGTSNdaUtuXJWVLFzKvDx in EBAPlwcokhGTSNdaUtuXJWVLFzKvqY:
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOe=EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['content']['program']
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOj =EBAPlwcokhGTSNdaUtuXJWVLFzKvOe['code']
    EBAPlwcokhGTSNdaUtuXJWVLFzKvqe =EBAPlwcokhGTSNdaUtuXJWVLFzKvOe['name']['ko'].strip()
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOQ =EBAPlwcokhGTSNdaUtuXJWVLFzKvmy.get(EBAPlwcokhGTSNdaUtuXJWVLFzKvOe.get('grade_code'))
    EBAPlwcokhGTSNdaUtuXJWVLFzKvqj =EBAPlwcokhGTSNdaUtuXJWVLFzKvOe['synopsis']['ko']
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOb =EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['content']['channel']['name']['ko']
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOM =EBAPlwcokhGTSNdaUtuXJWVLFzKvOe['product_year']
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOm =''
    EBAPlwcokhGTSNdaUtuXJWVLFzKvqs =''
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOp=''
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOD =''
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOy =''
    for EBAPlwcokhGTSNdaUtuXJWVLFzKvOR in EBAPlwcokhGTSNdaUtuXJWVLFzKvOe['image']:
     if EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['code']=='CAIP0900':EBAPlwcokhGTSNdaUtuXJWVLFzKvOm =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['url']
     elif EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['code']=='CAIP0200':EBAPlwcokhGTSNdaUtuXJWVLFzKvqs =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['url']
     elif EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['code']=='CAIP1800':EBAPlwcokhGTSNdaUtuXJWVLFzKvOp=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['url']
     elif EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['code']=='CAIP2000':EBAPlwcokhGTSNdaUtuXJWVLFzKvOD =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['url']
     elif EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['code']=='CAIP1900':EBAPlwcokhGTSNdaUtuXJWVLFzKvOy =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['url']
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOH =[]
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOr =[]
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOg=[]
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOf =''
    if EBAPlwcokhGTSNdaUtuXJWVLFzKvOe.get('category1_name').get('ko')!='':
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOH.append(EBAPlwcokhGTSNdaUtuXJWVLFzKvOe['category1_name']['ko'])
    if EBAPlwcokhGTSNdaUtuXJWVLFzKvOe.get('category2_name').get('ko')!='':
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOH.append(EBAPlwcokhGTSNdaUtuXJWVLFzKvOe['category2_name']['ko'])
    for EBAPlwcokhGTSNdaUtuXJWVLFzKvOn in EBAPlwcokhGTSNdaUtuXJWVLFzKvOe.get('actor'):
     if EBAPlwcokhGTSNdaUtuXJWVLFzKvOn!='' and EBAPlwcokhGTSNdaUtuXJWVLFzKvOn!='-' and EBAPlwcokhGTSNdaUtuXJWVLFzKvOn!=u'없음':EBAPlwcokhGTSNdaUtuXJWVLFzKvOr.append(EBAPlwcokhGTSNdaUtuXJWVLFzKvOn)
    for EBAPlwcokhGTSNdaUtuXJWVLFzKvOi in EBAPlwcokhGTSNdaUtuXJWVLFzKvOe.get('director'):
     if EBAPlwcokhGTSNdaUtuXJWVLFzKvOi!='' and EBAPlwcokhGTSNdaUtuXJWVLFzKvOi!='-' and EBAPlwcokhGTSNdaUtuXJWVLFzKvOi!=u'없음':EBAPlwcokhGTSNdaUtuXJWVLFzKvOg.append(EBAPlwcokhGTSNdaUtuXJWVLFzKvOi)
    if EBAPlwcokhGTSNdaUtuXJWVLFzKvOe.get('broad_dt')not in[EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,'']:
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOC =EBAPlwcokhGTSNdaUtuXJWVLFzKvOe.get('broad_dt')
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOf='%s-%s-%s'%(EBAPlwcokhGTSNdaUtuXJWVLFzKvOC[:4],EBAPlwcokhGTSNdaUtuXJWVLFzKvOC[4:6],EBAPlwcokhGTSNdaUtuXJWVLFzKvOC[6:])
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOx={'program':EBAPlwcokhGTSNdaUtuXJWVLFzKvOj,'title':EBAPlwcokhGTSNdaUtuXJWVLFzKvqe,'mpaa':EBAPlwcokhGTSNdaUtuXJWVLFzKvOQ,'thumbnail':{'poster':EBAPlwcokhGTSNdaUtuXJWVLFzKvOm,'thumb':EBAPlwcokhGTSNdaUtuXJWVLFzKvqs,'clearlogo':EBAPlwcokhGTSNdaUtuXJWVLFzKvOp,'icon':EBAPlwcokhGTSNdaUtuXJWVLFzKvOD,'banner':EBAPlwcokhGTSNdaUtuXJWVLFzKvOy,'fanart':EBAPlwcokhGTSNdaUtuXJWVLFzKvqs},'channel':EBAPlwcokhGTSNdaUtuXJWVLFzKvOb,'synopsis':EBAPlwcokhGTSNdaUtuXJWVLFzKvqj,'year':EBAPlwcokhGTSNdaUtuXJWVLFzKvOM,'info_genre':EBAPlwcokhGTSNdaUtuXJWVLFzKvOH,'cast':EBAPlwcokhGTSNdaUtuXJWVLFzKvOr,'director':EBAPlwcokhGTSNdaUtuXJWVLFzKvOg,'premiered':EBAPlwcokhGTSNdaUtuXJWVLFzKvOf,}
    EBAPlwcokhGTSNdaUtuXJWVLFzKvDf.append(EBAPlwcokhGTSNdaUtuXJWVLFzKvOx)
  except EBAPlwcokhGTSNdaUtuXJWVLFzKvgD as exception:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrn(exception)
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvDf,EBAPlwcokhGTSNdaUtuXJWVLFzKvqi
 def Get_Origianl_ProgramList(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR,page_int):
  EBAPlwcokhGTSNdaUtuXJWVLFzKvDf=[]
  EBAPlwcokhGTSNdaUtuXJWVLFzKvqi=EBAPlwcokhGTSNdaUtuXJWVLFzKvrx
  try:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDH ='/v2/media/band/originals'
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDs=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.GetDefaultParams()
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDC={'pageSize':EBAPlwcokhGTSNdaUtuXJWVLFzKvrI(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.VOD_LIMIT),'adult':'all','order':'viewHour','originalYn':'Y','exclusiveYn':'Y','pageNo':EBAPlwcokhGTSNdaUtuXJWVLFzKvrI(page_int),}
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDs.update(EBAPlwcokhGTSNdaUtuXJWVLFzKvDC)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpb=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.API_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvDH
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpj=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.callRequestCookies('Get',EBAPlwcokhGTSNdaUtuXJWVLFzKvpb,payload=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,params=EBAPlwcokhGTSNdaUtuXJWVLFzKvDs,headers=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,cookies=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvOs=json.loads(EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.text)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.JsonFile_Save(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TV_SESSION_COOKIES2,EBAPlwcokhGTSNdaUtuXJWVLFzKvOs)
   if not('contents' in EBAPlwcokhGTSNdaUtuXJWVLFzKvOs['body']):return EBAPlwcokhGTSNdaUtuXJWVLFzKvDf,EBAPlwcokhGTSNdaUtuXJWVLFzKvqi
   EBAPlwcokhGTSNdaUtuXJWVLFzKvqY=EBAPlwcokhGTSNdaUtuXJWVLFzKvOs['body']['contents']
   for EBAPlwcokhGTSNdaUtuXJWVLFzKvDx in EBAPlwcokhGTSNdaUtuXJWVLFzKvqY:
    EBAPlwcokhGTSNdaUtuXJWVLFzKvRm =EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['vod_code']
    EBAPlwcokhGTSNdaUtuXJWVLFzKvqe =EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['vod_name']
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOm =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['image']
    EBAPlwcokhGTSNdaUtuXJWVLFzKvRp ='movie' if EBAPlwcokhGTSNdaUtuXJWVLFzKvRm.startswith('M')else 'vod'
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOx={'vod_code':EBAPlwcokhGTSNdaUtuXJWVLFzKvRm,'title':EBAPlwcokhGTSNdaUtuXJWVLFzKvqe,'thumbnail':{'poster':EBAPlwcokhGTSNdaUtuXJWVLFzKvOm,'thumb':EBAPlwcokhGTSNdaUtuXJWVLFzKvOm},'vod_type':EBAPlwcokhGTSNdaUtuXJWVLFzKvRp,}
    EBAPlwcokhGTSNdaUtuXJWVLFzKvDf.append(EBAPlwcokhGTSNdaUtuXJWVLFzKvOx)
   if EBAPlwcokhGTSNdaUtuXJWVLFzKvOs['body']['has_more']=='Y':EBAPlwcokhGTSNdaUtuXJWVLFzKvqi=EBAPlwcokhGTSNdaUtuXJWVLFzKvre
  except EBAPlwcokhGTSNdaUtuXJWVLFzKvgD as exception:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrn(exception)
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvDf,EBAPlwcokhGTSNdaUtuXJWVLFzKvqi
 def GetEpisodeList(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR,program_code,page_int,orderby='desc'):
  EBAPlwcokhGTSNdaUtuXJWVLFzKvDf=[]
  EBAPlwcokhGTSNdaUtuXJWVLFzKvqi=EBAPlwcokhGTSNdaUtuXJWVLFzKvrx
  try:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDH ='/v2/media/frequency/program/'+program_code
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDs=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.GetDefaultParams()
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDC={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDs.update(EBAPlwcokhGTSNdaUtuXJWVLFzKvDC)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpb=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.API_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvDH
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpj=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.callRequestCookies('Get',EBAPlwcokhGTSNdaUtuXJWVLFzKvpb,payload=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,params=EBAPlwcokhGTSNdaUtuXJWVLFzKvDs,headers=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,cookies=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDY=json.loads(EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.text)
   if not('result' in EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']):return EBAPlwcokhGTSNdaUtuXJWVLFzKvDf,EBAPlwcokhGTSNdaUtuXJWVLFzKvqi
   EBAPlwcokhGTSNdaUtuXJWVLFzKvqY=EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']['result']
   EBAPlwcokhGTSNdaUtuXJWVLFzKvRD=EBAPlwcokhGTSNdaUtuXJWVLFzKvrs(EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']['total_count'])
   EBAPlwcokhGTSNdaUtuXJWVLFzKvRy =EBAPlwcokhGTSNdaUtuXJWVLFzKvrs(EBAPlwcokhGTSNdaUtuXJWVLFzKvRD//(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    EBAPlwcokhGTSNdaUtuXJWVLFzKvRq =(EBAPlwcokhGTSNdaUtuXJWVLFzKvRD-1)-((page_int-1)*EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.EPISODE_LIMIT)
   else:
    EBAPlwcokhGTSNdaUtuXJWVLFzKvRq =(page_int-1)*EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.EPISODE_LIMIT
   for i in EBAPlwcokhGTSNdaUtuXJWVLFzKvgm(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.EPISODE_LIMIT):
    if orderby=='desc':
     EBAPlwcokhGTSNdaUtuXJWVLFzKvRO=EBAPlwcokhGTSNdaUtuXJWVLFzKvRq-i
     if EBAPlwcokhGTSNdaUtuXJWVLFzKvRO<0:break
    else:
     EBAPlwcokhGTSNdaUtuXJWVLFzKvRO=EBAPlwcokhGTSNdaUtuXJWVLFzKvRq+i
     if EBAPlwcokhGTSNdaUtuXJWVLFzKvRO>=EBAPlwcokhGTSNdaUtuXJWVLFzKvRD:break
    EBAPlwcokhGTSNdaUtuXJWVLFzKvRr=EBAPlwcokhGTSNdaUtuXJWVLFzKvqY[EBAPlwcokhGTSNdaUtuXJWVLFzKvRO]['episode']['code']
    EBAPlwcokhGTSNdaUtuXJWVLFzKvqe =EBAPlwcokhGTSNdaUtuXJWVLFzKvqY[EBAPlwcokhGTSNdaUtuXJWVLFzKvRO]['vod_name']['ko']
    EBAPlwcokhGTSNdaUtuXJWVLFzKvRg =''
    try:
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOC=EBAPlwcokhGTSNdaUtuXJWVLFzKvrI(EBAPlwcokhGTSNdaUtuXJWVLFzKvqY[EBAPlwcokhGTSNdaUtuXJWVLFzKvRO]['episode']['broadcast_date'])
     EBAPlwcokhGTSNdaUtuXJWVLFzKvRg='%s-%s-%s'%(EBAPlwcokhGTSNdaUtuXJWVLFzKvOC[:4],EBAPlwcokhGTSNdaUtuXJWVLFzKvOC[4:6],EBAPlwcokhGTSNdaUtuXJWVLFzKvOC[6:])
    except:
     EBAPlwcokhGTSNdaUtuXJWVLFzKvrY
    try:
     if EBAPlwcokhGTSNdaUtuXJWVLFzKvqY[EBAPlwcokhGTSNdaUtuXJWVLFzKvRO]['episode']['pip_cliptype']=='C012':
      EBAPlwcokhGTSNdaUtuXJWVLFzKvRg+=' - Quick VOD'
    except:
     EBAPlwcokhGTSNdaUtuXJWVLFzKvrY
    EBAPlwcokhGTSNdaUtuXJWVLFzKvqj =EBAPlwcokhGTSNdaUtuXJWVLFzKvqY[EBAPlwcokhGTSNdaUtuXJWVLFzKvRO]['episode']['synopsis']['ko']
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOm =''
    EBAPlwcokhGTSNdaUtuXJWVLFzKvqs =''
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOp=''
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOD =''
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOy =''
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOq =''
    for EBAPlwcokhGTSNdaUtuXJWVLFzKvOR in EBAPlwcokhGTSNdaUtuXJWVLFzKvqY[EBAPlwcokhGTSNdaUtuXJWVLFzKvRO]['program']['image']:
     if EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['code']=='CAIP0900':EBAPlwcokhGTSNdaUtuXJWVLFzKvOm =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['url']
     elif EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['code']=='CAIP1800':EBAPlwcokhGTSNdaUtuXJWVLFzKvOp=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['url']
     elif EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['code']=='CAIP2000':EBAPlwcokhGTSNdaUtuXJWVLFzKvOD =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['url']
     elif EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['code']=='CAIP1900':EBAPlwcokhGTSNdaUtuXJWVLFzKvOy =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['url']
     elif EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['code']=='CAIP0200':EBAPlwcokhGTSNdaUtuXJWVLFzKvOq =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['url']
    for EBAPlwcokhGTSNdaUtuXJWVLFzKvOR in EBAPlwcokhGTSNdaUtuXJWVLFzKvqY[EBAPlwcokhGTSNdaUtuXJWVLFzKvRO]['episode']['image']:
     if EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['code']=='CAIE0400':EBAPlwcokhGTSNdaUtuXJWVLFzKvqs =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['url']
    try:
     EBAPlwcokhGTSNdaUtuXJWVLFzKvRH=EBAPlwcokhGTSNdaUtuXJWVLFzKvRQ=EBAPlwcokhGTSNdaUtuXJWVLFzKvRf=''
     EBAPlwcokhGTSNdaUtuXJWVLFzKvRM=0
     EBAPlwcokhGTSNdaUtuXJWVLFzKvRH =EBAPlwcokhGTSNdaUtuXJWVLFzKvqY[EBAPlwcokhGTSNdaUtuXJWVLFzKvRO]['program']['name']['ko']
     EBAPlwcokhGTSNdaUtuXJWVLFzKvRQ =EBAPlwcokhGTSNdaUtuXJWVLFzKvRg
     EBAPlwcokhGTSNdaUtuXJWVLFzKvRf =EBAPlwcokhGTSNdaUtuXJWVLFzKvqY[EBAPlwcokhGTSNdaUtuXJWVLFzKvRO]['channel']['name']['ko']
     if 'frequency' in EBAPlwcokhGTSNdaUtuXJWVLFzKvqY[EBAPlwcokhGTSNdaUtuXJWVLFzKvRO]['episode']:EBAPlwcokhGTSNdaUtuXJWVLFzKvRM=EBAPlwcokhGTSNdaUtuXJWVLFzKvqY[EBAPlwcokhGTSNdaUtuXJWVLFzKvRO]['episode']['frequency']
    except:
     EBAPlwcokhGTSNdaUtuXJWVLFzKvrY
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOx={'episode':EBAPlwcokhGTSNdaUtuXJWVLFzKvRr,'title':EBAPlwcokhGTSNdaUtuXJWVLFzKvqe,'subtitle':EBAPlwcokhGTSNdaUtuXJWVLFzKvRg,'thumbnail':{'poster':EBAPlwcokhGTSNdaUtuXJWVLFzKvOm,'thumb':EBAPlwcokhGTSNdaUtuXJWVLFzKvqs,'clearlogo':EBAPlwcokhGTSNdaUtuXJWVLFzKvOp,'icon':EBAPlwcokhGTSNdaUtuXJWVLFzKvOD,'banner':EBAPlwcokhGTSNdaUtuXJWVLFzKvOy,'fanart':EBAPlwcokhGTSNdaUtuXJWVLFzKvOq},'synopsis':EBAPlwcokhGTSNdaUtuXJWVLFzKvqj,'info_title':EBAPlwcokhGTSNdaUtuXJWVLFzKvRH,'aired':EBAPlwcokhGTSNdaUtuXJWVLFzKvRQ,'studio':EBAPlwcokhGTSNdaUtuXJWVLFzKvRf,'frequency':EBAPlwcokhGTSNdaUtuXJWVLFzKvRM}
    EBAPlwcokhGTSNdaUtuXJWVLFzKvDf.append(EBAPlwcokhGTSNdaUtuXJWVLFzKvOx)
   if EBAPlwcokhGTSNdaUtuXJWVLFzKvRy>page_int:EBAPlwcokhGTSNdaUtuXJWVLFzKvqi=EBAPlwcokhGTSNdaUtuXJWVLFzKvre
  except EBAPlwcokhGTSNdaUtuXJWVLFzKvgD as exception:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrn(exception)
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvDf,EBAPlwcokhGTSNdaUtuXJWVLFzKvqi,EBAPlwcokhGTSNdaUtuXJWVLFzKvRy
 def GetMovieList(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR,genre,orderby,page_int):
  EBAPlwcokhGTSNdaUtuXJWVLFzKvDf=[]
  EBAPlwcokhGTSNdaUtuXJWVLFzKvqi=EBAPlwcokhGTSNdaUtuXJWVLFzKvrx
  try:
   if genre=='PARAMOUNT':
    EBAPlwcokhGTSNdaUtuXJWVLFzKvDH ='/v2/media/paramount/movies'
   else:
    EBAPlwcokhGTSNdaUtuXJWVLFzKvDH ='/v2/media/movies'
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDs=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.GetDefaultParams()
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDC={'pageSize':EBAPlwcokhGTSNdaUtuXJWVLFzKvrI(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N' if genre!='diversityYn' else 'Y','pageNo':EBAPlwcokhGTSNdaUtuXJWVLFzKvrI(page_int),}
   if genre not in['all','PARAMOUNT','diversityYn']:EBAPlwcokhGTSNdaUtuXJWVLFzKvDC['categoryCode']=genre
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDC['productPackageCode']=','.join(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.MOVIE_LITE)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDs.update(EBAPlwcokhGTSNdaUtuXJWVLFzKvDC)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpb=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.API_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvDH
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpj=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.callRequestCookies('Get',EBAPlwcokhGTSNdaUtuXJWVLFzKvpb,payload=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,params=EBAPlwcokhGTSNdaUtuXJWVLFzKvDs,headers=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,cookies=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDY=json.loads(EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.text)
   if not('result' in EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']):return EBAPlwcokhGTSNdaUtuXJWVLFzKvDf,EBAPlwcokhGTSNdaUtuXJWVLFzKvqi
   EBAPlwcokhGTSNdaUtuXJWVLFzKvqY=EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']['result']
   for EBAPlwcokhGTSNdaUtuXJWVLFzKvDx in EBAPlwcokhGTSNdaUtuXJWVLFzKvqY:
    if 'release_date' in EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('movie'):
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOM=EBAPlwcokhGTSNdaUtuXJWVLFzKvrI(EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('movie').get('release_date'))[:4]
    else:
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOM=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY
    EBAPlwcokhGTSNdaUtuXJWVLFzKvRn =EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['movie']['code']
    EBAPlwcokhGTSNdaUtuXJWVLFzKvqe =EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['movie']['name']['ko'].strip()
    if EBAPlwcokhGTSNdaUtuXJWVLFzKvOM not in[EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,'0','']:EBAPlwcokhGTSNdaUtuXJWVLFzKvqe+=u' (%s)'%(EBAPlwcokhGTSNdaUtuXJWVLFzKvOM)
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOm=''
    EBAPlwcokhGTSNdaUtuXJWVLFzKvqs =''
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOp=''
    for EBAPlwcokhGTSNdaUtuXJWVLFzKvOR in EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['movie']['image']:
     if EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['code']=='CAIM2100':EBAPlwcokhGTSNdaUtuXJWVLFzKvOm =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['url']
     elif EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['code']=='CAIM0400':EBAPlwcokhGTSNdaUtuXJWVLFzKvqs =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['url']
     elif EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['code']=='CAIM1800':EBAPlwcokhGTSNdaUtuXJWVLFzKvOp=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['url']
    EBAPlwcokhGTSNdaUtuXJWVLFzKvqj =EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['movie']['story']['ko']
    try:
     EBAPlwcokhGTSNdaUtuXJWVLFzKvRH =EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['movie']['name']['ko'].strip()
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOQ =EBAPlwcokhGTSNdaUtuXJWVLFzKvmy.get(EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('grade_code'))
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOr=[]
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOg=[]
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOH=[]
     EBAPlwcokhGTSNdaUtuXJWVLFzKvRi=0
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOf=''
     EBAPlwcokhGTSNdaUtuXJWVLFzKvRf =''
     for EBAPlwcokhGTSNdaUtuXJWVLFzKvOn in EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('movie').get('actor'):
      if EBAPlwcokhGTSNdaUtuXJWVLFzKvOn!='':EBAPlwcokhGTSNdaUtuXJWVLFzKvOr.append(EBAPlwcokhGTSNdaUtuXJWVLFzKvOn)
     for EBAPlwcokhGTSNdaUtuXJWVLFzKvOi in EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('movie').get('director'):
      if EBAPlwcokhGTSNdaUtuXJWVLFzKvOi!='':EBAPlwcokhGTSNdaUtuXJWVLFzKvOg.append(EBAPlwcokhGTSNdaUtuXJWVLFzKvOi)
     if EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('movie').get('category1_name').get('ko')!='':
      EBAPlwcokhGTSNdaUtuXJWVLFzKvOH.append(EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['movie']['category1_name']['ko'])
     if EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('movie').get('category2_name').get('ko')!='':
      EBAPlwcokhGTSNdaUtuXJWVLFzKvOH.append(EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['movie']['category2_name']['ko'])
     if 'duration' in EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('movie'):EBAPlwcokhGTSNdaUtuXJWVLFzKvRi=EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('movie').get('duration')
     if 'release_date' in EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('movie'):
      EBAPlwcokhGTSNdaUtuXJWVLFzKvOC=EBAPlwcokhGTSNdaUtuXJWVLFzKvrI(EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('movie').get('release_date'))
      if EBAPlwcokhGTSNdaUtuXJWVLFzKvOC!='0':EBAPlwcokhGTSNdaUtuXJWVLFzKvOf='%s-%s-%s'%(EBAPlwcokhGTSNdaUtuXJWVLFzKvOC[:4],EBAPlwcokhGTSNdaUtuXJWVLFzKvOC[4:6],EBAPlwcokhGTSNdaUtuXJWVLFzKvOC[6:])
     if 'production' in EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('movie'):EBAPlwcokhGTSNdaUtuXJWVLFzKvRf=EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('movie').get('production')
    except:
     EBAPlwcokhGTSNdaUtuXJWVLFzKvrY
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOx={'moviecode':EBAPlwcokhGTSNdaUtuXJWVLFzKvRn,'title':EBAPlwcokhGTSNdaUtuXJWVLFzKvqe,'thumbnail':{'poster':EBAPlwcokhGTSNdaUtuXJWVLFzKvOm,'thumb':EBAPlwcokhGTSNdaUtuXJWVLFzKvqs,'clearlogo':EBAPlwcokhGTSNdaUtuXJWVLFzKvOp,'fanart':EBAPlwcokhGTSNdaUtuXJWVLFzKvqs},'synopsis':EBAPlwcokhGTSNdaUtuXJWVLFzKvqj,'info_title':EBAPlwcokhGTSNdaUtuXJWVLFzKvRH,'year':EBAPlwcokhGTSNdaUtuXJWVLFzKvOM,'cast':EBAPlwcokhGTSNdaUtuXJWVLFzKvOr,'director':EBAPlwcokhGTSNdaUtuXJWVLFzKvOg,'info_genre':EBAPlwcokhGTSNdaUtuXJWVLFzKvOH,'duration':EBAPlwcokhGTSNdaUtuXJWVLFzKvRi,'premiered':EBAPlwcokhGTSNdaUtuXJWVLFzKvOf,'studio':EBAPlwcokhGTSNdaUtuXJWVLFzKvRf,'mpaa':EBAPlwcokhGTSNdaUtuXJWVLFzKvOQ}
    EBAPlwcokhGTSNdaUtuXJWVLFzKvRC=EBAPlwcokhGTSNdaUtuXJWVLFzKvrx
    for EBAPlwcokhGTSNdaUtuXJWVLFzKvRY in EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['billing_package_id']:
     if EBAPlwcokhGTSNdaUtuXJWVLFzKvRY in EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.MOVIE_LITE:
      EBAPlwcokhGTSNdaUtuXJWVLFzKvRC=EBAPlwcokhGTSNdaUtuXJWVLFzKvre
      break
    if EBAPlwcokhGTSNdaUtuXJWVLFzKvRC==EBAPlwcokhGTSNdaUtuXJWVLFzKvrx: 
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOx['title']=EBAPlwcokhGTSNdaUtuXJWVLFzKvOx['title']+' [개별구매]'
    EBAPlwcokhGTSNdaUtuXJWVLFzKvDf.append(EBAPlwcokhGTSNdaUtuXJWVLFzKvOx)
   if EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']['has_more']=='Y':EBAPlwcokhGTSNdaUtuXJWVLFzKvqi=EBAPlwcokhGTSNdaUtuXJWVLFzKvre
  except EBAPlwcokhGTSNdaUtuXJWVLFzKvgD as exception:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrn(exception)
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvDf,EBAPlwcokhGTSNdaUtuXJWVLFzKvqi
 def Get_UHD_MovieList(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR,page_int):
  EBAPlwcokhGTSNdaUtuXJWVLFzKvDf=[]
  EBAPlwcokhGTSNdaUtuXJWVLFzKvqi=EBAPlwcokhGTSNdaUtuXJWVLFzKvrx
  try:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDH ='/v2/operator/highlights'
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDs=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.GetDefaultParams(uhd=EBAPlwcokhGTSNdaUtuXJWVLFzKvre)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDC={'positionKey':'SMTV_MV_4K','pageSize':'20','page_int':EBAPlwcokhGTSNdaUtuXJWVLFzKvrI(page_int),'pocType':'APP_X_TVING_4.0.0',}
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDs.update(EBAPlwcokhGTSNdaUtuXJWVLFzKvDC)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpb=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.API_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvDH
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpj=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.callRequestCookies('Get',EBAPlwcokhGTSNdaUtuXJWVLFzKvpb,payload=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,params=EBAPlwcokhGTSNdaUtuXJWVLFzKvDs,headers=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,cookies=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDY=json.loads(EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.text)
   if not('result' in EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']):return EBAPlwcokhGTSNdaUtuXJWVLFzKvDf,EBAPlwcokhGTSNdaUtuXJWVLFzKvqi
   EBAPlwcokhGTSNdaUtuXJWVLFzKvqY=EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']['result']
   for EBAPlwcokhGTSNdaUtuXJWVLFzKvDx in EBAPlwcokhGTSNdaUtuXJWVLFzKvqY:
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOe=EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['content']['movie']
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOj =EBAPlwcokhGTSNdaUtuXJWVLFzKvOe['code']
    EBAPlwcokhGTSNdaUtuXJWVLFzKvqe =EBAPlwcokhGTSNdaUtuXJWVLFzKvOe['name']['ko'].strip()
    EBAPlwcokhGTSNdaUtuXJWVLFzKvRH =EBAPlwcokhGTSNdaUtuXJWVLFzKvOe['name']['ko'].strip()
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOM =EBAPlwcokhGTSNdaUtuXJWVLFzKvOe['product_year']
    if EBAPlwcokhGTSNdaUtuXJWVLFzKvOM:EBAPlwcokhGTSNdaUtuXJWVLFzKvqe+=u' (%s)'%(EBAPlwcokhGTSNdaUtuXJWVLFzKvOe['product_year'])
    EBAPlwcokhGTSNdaUtuXJWVLFzKvqj =EBAPlwcokhGTSNdaUtuXJWVLFzKvOe['story']['ko']
    EBAPlwcokhGTSNdaUtuXJWVLFzKvRi =EBAPlwcokhGTSNdaUtuXJWVLFzKvOe['duration']
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOQ =EBAPlwcokhGTSNdaUtuXJWVLFzKvmy.get(EBAPlwcokhGTSNdaUtuXJWVLFzKvOe.get('grade_code'))
    EBAPlwcokhGTSNdaUtuXJWVLFzKvRf =EBAPlwcokhGTSNdaUtuXJWVLFzKvOe['production']
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOm=''
    EBAPlwcokhGTSNdaUtuXJWVLFzKvqs =''
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOp=''
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOH =[]
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOr =[]
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOg=[]
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOf =''
    for EBAPlwcokhGTSNdaUtuXJWVLFzKvOR in EBAPlwcokhGTSNdaUtuXJWVLFzKvOe['image']:
     if EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['code']=='CAIM2100':EBAPlwcokhGTSNdaUtuXJWVLFzKvOm =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['url']
     elif EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['code']=='CAIM0400':EBAPlwcokhGTSNdaUtuXJWVLFzKvqs =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['url']
     elif EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['code']=='CAIM1800':EBAPlwcokhGTSNdaUtuXJWVLFzKvOp=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR['url']
    if EBAPlwcokhGTSNdaUtuXJWVLFzKvOe['release_date']not in[EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,0]:
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOC=EBAPlwcokhGTSNdaUtuXJWVLFzKvrI(EBAPlwcokhGTSNdaUtuXJWVLFzKvOe['release_date'])
     if EBAPlwcokhGTSNdaUtuXJWVLFzKvOC!='0':EBAPlwcokhGTSNdaUtuXJWVLFzKvOf='%s-%s-%s'%(EBAPlwcokhGTSNdaUtuXJWVLFzKvOC[:4],EBAPlwcokhGTSNdaUtuXJWVLFzKvOC[4:6],EBAPlwcokhGTSNdaUtuXJWVLFzKvOC[6:])
    if EBAPlwcokhGTSNdaUtuXJWVLFzKvOe.get('category1_name').get('ko')!='':
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOH.append(EBAPlwcokhGTSNdaUtuXJWVLFzKvOe['category1_name']['ko'])
    if EBAPlwcokhGTSNdaUtuXJWVLFzKvOe.get('category2_name').get('ko')!='':
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOH.append(EBAPlwcokhGTSNdaUtuXJWVLFzKvOe['category2_name']['ko'])
    for EBAPlwcokhGTSNdaUtuXJWVLFzKvOn in EBAPlwcokhGTSNdaUtuXJWVLFzKvOe.get('actor'):
     if EBAPlwcokhGTSNdaUtuXJWVLFzKvOn!='':EBAPlwcokhGTSNdaUtuXJWVLFzKvOr.append(EBAPlwcokhGTSNdaUtuXJWVLFzKvOn)
    for EBAPlwcokhGTSNdaUtuXJWVLFzKvOi in EBAPlwcokhGTSNdaUtuXJWVLFzKvOe.get('director'):
     if EBAPlwcokhGTSNdaUtuXJWVLFzKvOi!='':EBAPlwcokhGTSNdaUtuXJWVLFzKvOg.append(EBAPlwcokhGTSNdaUtuXJWVLFzKvOi)
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOx={'moviecode':EBAPlwcokhGTSNdaUtuXJWVLFzKvOj,'title':EBAPlwcokhGTSNdaUtuXJWVLFzKvqe,'thumbnail':{'poster':EBAPlwcokhGTSNdaUtuXJWVLFzKvOm,'thumb':EBAPlwcokhGTSNdaUtuXJWVLFzKvqs,'clearlogo':EBAPlwcokhGTSNdaUtuXJWVLFzKvOp,'fanart':EBAPlwcokhGTSNdaUtuXJWVLFzKvqs},'year':EBAPlwcokhGTSNdaUtuXJWVLFzKvOM,'info_title':EBAPlwcokhGTSNdaUtuXJWVLFzKvRH,'synopsis':EBAPlwcokhGTSNdaUtuXJWVLFzKvqj,'mpaa':EBAPlwcokhGTSNdaUtuXJWVLFzKvOQ,'duration':EBAPlwcokhGTSNdaUtuXJWVLFzKvRi,'premiered':EBAPlwcokhGTSNdaUtuXJWVLFzKvOf,'studio':EBAPlwcokhGTSNdaUtuXJWVLFzKvRf,'info_genre':EBAPlwcokhGTSNdaUtuXJWVLFzKvOH,'cast':EBAPlwcokhGTSNdaUtuXJWVLFzKvOr,'director':EBAPlwcokhGTSNdaUtuXJWVLFzKvOg,}
    EBAPlwcokhGTSNdaUtuXJWVLFzKvDf.append(EBAPlwcokhGTSNdaUtuXJWVLFzKvOx)
  except EBAPlwcokhGTSNdaUtuXJWVLFzKvgD as exception:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrn(exception)
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvDf,EBAPlwcokhGTSNdaUtuXJWVLFzKvqi
 def GetMovieGenre(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR):
  EBAPlwcokhGTSNdaUtuXJWVLFzKvDf=[]
  EBAPlwcokhGTSNdaUtuXJWVLFzKvqi=EBAPlwcokhGTSNdaUtuXJWVLFzKvrx
  try:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDH ='/v2/media/movie/curations'
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDs=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.GetDefaultParams()
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDC={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDs.update(EBAPlwcokhGTSNdaUtuXJWVLFzKvDC)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpb=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.API_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvDH
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpj=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.callRequestCookies('Get',EBAPlwcokhGTSNdaUtuXJWVLFzKvpb,payload=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,params=EBAPlwcokhGTSNdaUtuXJWVLFzKvDs,headers=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,cookies=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDY=json.loads(EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.text)
   if not('result' in EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']):return EBAPlwcokhGTSNdaUtuXJWVLFzKvDf,EBAPlwcokhGTSNdaUtuXJWVLFzKvqi
   EBAPlwcokhGTSNdaUtuXJWVLFzKvqY=EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']['result']
   for EBAPlwcokhGTSNdaUtuXJWVLFzKvDx in EBAPlwcokhGTSNdaUtuXJWVLFzKvqY:
    EBAPlwcokhGTSNdaUtuXJWVLFzKvRx =EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['curation_code']
    EBAPlwcokhGTSNdaUtuXJWVLFzKvRI =EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['curation_name']
    EBAPlwcokhGTSNdaUtuXJWVLFzKvOx={'curation_code':EBAPlwcokhGTSNdaUtuXJWVLFzKvRx,'curation_name':EBAPlwcokhGTSNdaUtuXJWVLFzKvRI}
    EBAPlwcokhGTSNdaUtuXJWVLFzKvDf.append(EBAPlwcokhGTSNdaUtuXJWVLFzKvOx)
  except EBAPlwcokhGTSNdaUtuXJWVLFzKvgD as exception:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrn(exception)
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvDf,EBAPlwcokhGTSNdaUtuXJWVLFzKvqi
 def GetSearchList(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR,search_key,page_int,stype):
  EBAPlwcokhGTSNdaUtuXJWVLFzKvRb=[]
  EBAPlwcokhGTSNdaUtuXJWVLFzKvqi=EBAPlwcokhGTSNdaUtuXJWVLFzKvrx
  try:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDH ='/search/getSearch.jsp'
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDs=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.GetDefaultParams()
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDC={'kwd':search_key,'category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':EBAPlwcokhGTSNdaUtuXJWVLFzKvrI(page_int),'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','pageSize':EBAPlwcokhGTSNdaUtuXJWVLFzKvrI(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.SCREENCODE,'os':EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.OSCODE,'network':EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':EBAPlwcokhGTSNdaUtuXJWVLFzKvrI(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.SEARCH_LIMIT)if stype=='vod' else '0','vodMVReqCnt':EBAPlwcokhGTSNdaUtuXJWVLFzKvrI(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.SEARCH_LIMIT)if stype=='movie' else '0','aloneReqCnt':'0','smrclipReqCnt':'0','pickClipReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','apiKey':EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.APIKEY,'networkCode':EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.NETWORKCODE,'osCode ':EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.OSCODE,'teleCode ':EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TELECODE,'screenCode ':EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.SCREENCODE}
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpb=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.SEARCH_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvDH
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpj=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.callRequestCookies('Get',EBAPlwcokhGTSNdaUtuXJWVLFzKvpb,payload=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,params=EBAPlwcokhGTSNdaUtuXJWVLFzKvDC,headers=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,cookies=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDY=json.loads(EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.text)
   if stype=='vod':
    if not('programRsb' in EBAPlwcokhGTSNdaUtuXJWVLFzKvDY):return EBAPlwcokhGTSNdaUtuXJWVLFzKvRb,EBAPlwcokhGTSNdaUtuXJWVLFzKvqi
    EBAPlwcokhGTSNdaUtuXJWVLFzKvRe=EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['programRsb']['dataList']
    EBAPlwcokhGTSNdaUtuXJWVLFzKvRj =EBAPlwcokhGTSNdaUtuXJWVLFzKvrs(EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['programRsb']['count'])
    for EBAPlwcokhGTSNdaUtuXJWVLFzKvDx in EBAPlwcokhGTSNdaUtuXJWVLFzKvRe:
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOI=EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['mast_cd']
     EBAPlwcokhGTSNdaUtuXJWVLFzKvqe =EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['mast_nm']
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOm=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['web_url4']
     EBAPlwcokhGTSNdaUtuXJWVLFzKvqs =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['web_url']
     try:
      EBAPlwcokhGTSNdaUtuXJWVLFzKvOr =[]
      EBAPlwcokhGTSNdaUtuXJWVLFzKvOg=[]
      EBAPlwcokhGTSNdaUtuXJWVLFzKvOH =[]
      EBAPlwcokhGTSNdaUtuXJWVLFzKvRi =0
      EBAPlwcokhGTSNdaUtuXJWVLFzKvOQ =''
      EBAPlwcokhGTSNdaUtuXJWVLFzKvOM =''
      EBAPlwcokhGTSNdaUtuXJWVLFzKvRQ =''
      if EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('actor') !='' and EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('actor') !='-':EBAPlwcokhGTSNdaUtuXJWVLFzKvOr =EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('actor').split(',')
      if EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('director')!='' and EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('director')!='-':EBAPlwcokhGTSNdaUtuXJWVLFzKvOg=EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('director').split(',')
      if EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('cate_nm')!='' and EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('cate_nm')!='-':EBAPlwcokhGTSNdaUtuXJWVLFzKvOH =EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('cate_nm').split('/')
      if 'targetage' in EBAPlwcokhGTSNdaUtuXJWVLFzKvDx:EBAPlwcokhGTSNdaUtuXJWVLFzKvOQ=EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('targetage')
      if 'broad_dt' in EBAPlwcokhGTSNdaUtuXJWVLFzKvDx:
       EBAPlwcokhGTSNdaUtuXJWVLFzKvOC=EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('broad_dt')
       EBAPlwcokhGTSNdaUtuXJWVLFzKvRQ='%s-%s-%s'%(EBAPlwcokhGTSNdaUtuXJWVLFzKvOC[:4],EBAPlwcokhGTSNdaUtuXJWVLFzKvOC[4:6],EBAPlwcokhGTSNdaUtuXJWVLFzKvOC[6:])
       EBAPlwcokhGTSNdaUtuXJWVLFzKvOM =EBAPlwcokhGTSNdaUtuXJWVLFzKvOC[:4]
     except:
      EBAPlwcokhGTSNdaUtuXJWVLFzKvrY
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOx={'program':EBAPlwcokhGTSNdaUtuXJWVLFzKvOI,'title':EBAPlwcokhGTSNdaUtuXJWVLFzKvqe,'thumbnail':{'poster':EBAPlwcokhGTSNdaUtuXJWVLFzKvOm,'thumb':EBAPlwcokhGTSNdaUtuXJWVLFzKvqs,'fanart':EBAPlwcokhGTSNdaUtuXJWVLFzKvqs},'synopsis':'','cast':EBAPlwcokhGTSNdaUtuXJWVLFzKvOr,'director':EBAPlwcokhGTSNdaUtuXJWVLFzKvOg,'info_genre':EBAPlwcokhGTSNdaUtuXJWVLFzKvOH,'duration':EBAPlwcokhGTSNdaUtuXJWVLFzKvRi,'mpaa':EBAPlwcokhGTSNdaUtuXJWVLFzKvOQ,'year':EBAPlwcokhGTSNdaUtuXJWVLFzKvOM,'aired':EBAPlwcokhGTSNdaUtuXJWVLFzKvRQ}
     EBAPlwcokhGTSNdaUtuXJWVLFzKvRb.append(EBAPlwcokhGTSNdaUtuXJWVLFzKvOx)
   else:
    if not('vodMVRsb' in EBAPlwcokhGTSNdaUtuXJWVLFzKvDY):return EBAPlwcokhGTSNdaUtuXJWVLFzKvRb,EBAPlwcokhGTSNdaUtuXJWVLFzKvqi
    EBAPlwcokhGTSNdaUtuXJWVLFzKvRs=EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['vodMVRsb']['dataList']
    EBAPlwcokhGTSNdaUtuXJWVLFzKvRj =EBAPlwcokhGTSNdaUtuXJWVLFzKvrs(EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['vodMVRsb']['count'])
    for EBAPlwcokhGTSNdaUtuXJWVLFzKvDx in EBAPlwcokhGTSNdaUtuXJWVLFzKvRs:
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOI=EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['mast_cd']
     EBAPlwcokhGTSNdaUtuXJWVLFzKvqe =EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['mast_nm'].strip()
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOm =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['web_url']
     EBAPlwcokhGTSNdaUtuXJWVLFzKvqs =EBAPlwcokhGTSNdaUtuXJWVLFzKvOm
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOp=''
     try:
      EBAPlwcokhGTSNdaUtuXJWVLFzKvOr =[]
      EBAPlwcokhGTSNdaUtuXJWVLFzKvOg=[]
      EBAPlwcokhGTSNdaUtuXJWVLFzKvOH =[]
      EBAPlwcokhGTSNdaUtuXJWVLFzKvRi =0
      EBAPlwcokhGTSNdaUtuXJWVLFzKvOQ =''
      EBAPlwcokhGTSNdaUtuXJWVLFzKvOM =''
      EBAPlwcokhGTSNdaUtuXJWVLFzKvRQ =''
      if EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('actor') !='' and EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('actor') !='-':EBAPlwcokhGTSNdaUtuXJWVLFzKvOr =EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('actor').split(',')
      if EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('director')!='' and EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('director')!='-':EBAPlwcokhGTSNdaUtuXJWVLFzKvOg=EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('director').split(',')
      if EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('cate_nm')!='' and EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('cate_nm')!='-':EBAPlwcokhGTSNdaUtuXJWVLFzKvOH =EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('cate_nm').split('/')
      if EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('runtime_sec')!='':EBAPlwcokhGTSNdaUtuXJWVLFzKvRi=EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('runtime_sec')
      if 'grade_nm' in EBAPlwcokhGTSNdaUtuXJWVLFzKvDx:EBAPlwcokhGTSNdaUtuXJWVLFzKvOQ=EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('grade_nm')
      EBAPlwcokhGTSNdaUtuXJWVLFzKvOC=EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('broad_dt')
      if data_str!='':
       EBAPlwcokhGTSNdaUtuXJWVLFzKvRQ='%s-%s-%s'%(EBAPlwcokhGTSNdaUtuXJWVLFzKvOC[:4],EBAPlwcokhGTSNdaUtuXJWVLFzKvOC[4:6],EBAPlwcokhGTSNdaUtuXJWVLFzKvOC[6:])
       EBAPlwcokhGTSNdaUtuXJWVLFzKvOM =EBAPlwcokhGTSNdaUtuXJWVLFzKvOC[:4]
     except:
      EBAPlwcokhGTSNdaUtuXJWVLFzKvrY
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOx={'movie':EBAPlwcokhGTSNdaUtuXJWVLFzKvOI,'title':EBAPlwcokhGTSNdaUtuXJWVLFzKvqe,'thumbnail':{'poster':EBAPlwcokhGTSNdaUtuXJWVLFzKvOm,'thumb':EBAPlwcokhGTSNdaUtuXJWVLFzKvqs,'fanart':EBAPlwcokhGTSNdaUtuXJWVLFzKvqs,'clearlogo':EBAPlwcokhGTSNdaUtuXJWVLFzKvOp},'synopsis':'','cast':EBAPlwcokhGTSNdaUtuXJWVLFzKvOr,'director':EBAPlwcokhGTSNdaUtuXJWVLFzKvOg,'info_genre':EBAPlwcokhGTSNdaUtuXJWVLFzKvOH,'duration':EBAPlwcokhGTSNdaUtuXJWVLFzKvRi,'mpaa':EBAPlwcokhGTSNdaUtuXJWVLFzKvOQ,'year':EBAPlwcokhGTSNdaUtuXJWVLFzKvOM,'aired':EBAPlwcokhGTSNdaUtuXJWVLFzKvRQ}
     EBAPlwcokhGTSNdaUtuXJWVLFzKvRb.append(EBAPlwcokhGTSNdaUtuXJWVLFzKvOx)
   if EBAPlwcokhGTSNdaUtuXJWVLFzKvRj>(page_int*EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.SEARCH_LIMIT):EBAPlwcokhGTSNdaUtuXJWVLFzKvqi=EBAPlwcokhGTSNdaUtuXJWVLFzKvre
  except EBAPlwcokhGTSNdaUtuXJWVLFzKvgD as exception:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrn(exception)
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvRb,EBAPlwcokhGTSNdaUtuXJWVLFzKvqi
 def GetBookmarkInfo(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR,videoid,vidtype):
  EBAPlwcokhGTSNdaUtuXJWVLFzKvrm={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpb=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.API_DOMAIN+'/v2/media/program/'+videoid
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDs=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.GetDefaultParams()
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDC={'pageNo':'1','pageSize':'10','order':'name',}
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDs.update(EBAPlwcokhGTSNdaUtuXJWVLFzKvDC)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpj=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.callRequestCookies('Get',EBAPlwcokhGTSNdaUtuXJWVLFzKvpb,payload=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,params=EBAPlwcokhGTSNdaUtuXJWVLFzKvDs,headers=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,cookies=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvOs=json.loads(EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.text)
   if not('body' in EBAPlwcokhGTSNdaUtuXJWVLFzKvOs):return{}
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrp=EBAPlwcokhGTSNdaUtuXJWVLFzKvOs['body']
   EBAPlwcokhGTSNdaUtuXJWVLFzKvqe=EBAPlwcokhGTSNdaUtuXJWVLFzKvrp.get('name').get('ko').strip()
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrm['saveinfo']['title'] =EBAPlwcokhGTSNdaUtuXJWVLFzKvqe
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrm['saveinfo']['infoLabels']['title']=EBAPlwcokhGTSNdaUtuXJWVLFzKvqe
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrm['saveinfo']['infoLabels']['mpaa'] =EBAPlwcokhGTSNdaUtuXJWVLFzKvmy.get(EBAPlwcokhGTSNdaUtuXJWVLFzKvrp.get('grade_code'))
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrm['saveinfo']['infoLabels']['plot'] =EBAPlwcokhGTSNdaUtuXJWVLFzKvrp.get('synopsis').get('ko')
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrm['saveinfo']['infoLabels']['year'] =EBAPlwcokhGTSNdaUtuXJWVLFzKvrp.get('product_year')
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrm['saveinfo']['infoLabels']['cast'] =EBAPlwcokhGTSNdaUtuXJWVLFzKvrp.get('actor')
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrm['saveinfo']['infoLabels']['director']=EBAPlwcokhGTSNdaUtuXJWVLFzKvrp.get('director')
   if EBAPlwcokhGTSNdaUtuXJWVLFzKvrp.get('category1_name').get('ko')!='':
    EBAPlwcokhGTSNdaUtuXJWVLFzKvrm['saveinfo']['infoLabels']['genre'].append(EBAPlwcokhGTSNdaUtuXJWVLFzKvrp.get('category1_name').get('ko'))
   if EBAPlwcokhGTSNdaUtuXJWVLFzKvrp.get('category2_name').get('ko')!='':
    EBAPlwcokhGTSNdaUtuXJWVLFzKvrm['saveinfo']['infoLabels']['genre'].append(EBAPlwcokhGTSNdaUtuXJWVLFzKvrp.get('category2_name').get('ko'))
   EBAPlwcokhGTSNdaUtuXJWVLFzKvOC=EBAPlwcokhGTSNdaUtuXJWVLFzKvrI(EBAPlwcokhGTSNdaUtuXJWVLFzKvrp.get('broad_dt'))
   if EBAPlwcokhGTSNdaUtuXJWVLFzKvOC!='0':EBAPlwcokhGTSNdaUtuXJWVLFzKvrm['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(EBAPlwcokhGTSNdaUtuXJWVLFzKvOC[:4],EBAPlwcokhGTSNdaUtuXJWVLFzKvOC[4:6],EBAPlwcokhGTSNdaUtuXJWVLFzKvOC[6:])
   EBAPlwcokhGTSNdaUtuXJWVLFzKvOm =''
   EBAPlwcokhGTSNdaUtuXJWVLFzKvqs =''
   EBAPlwcokhGTSNdaUtuXJWVLFzKvOp=''
   EBAPlwcokhGTSNdaUtuXJWVLFzKvOD =''
   EBAPlwcokhGTSNdaUtuXJWVLFzKvOy =''
   for EBAPlwcokhGTSNdaUtuXJWVLFzKvOR in EBAPlwcokhGTSNdaUtuXJWVLFzKvrp.get('image'):
    if EBAPlwcokhGTSNdaUtuXJWVLFzKvOR.get('code')=='CAIP0900':EBAPlwcokhGTSNdaUtuXJWVLFzKvOm =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR.get('url')
    elif EBAPlwcokhGTSNdaUtuXJWVLFzKvOR.get('code')=='CAIP0200':EBAPlwcokhGTSNdaUtuXJWVLFzKvqs =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR.get('url')
    elif EBAPlwcokhGTSNdaUtuXJWVLFzKvOR.get('code')=='CAIP1800':EBAPlwcokhGTSNdaUtuXJWVLFzKvOp=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR.get('url')
    elif EBAPlwcokhGTSNdaUtuXJWVLFzKvOR.get('code')=='CAIP2000':EBAPlwcokhGTSNdaUtuXJWVLFzKvOD =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR.get('url')
    elif EBAPlwcokhGTSNdaUtuXJWVLFzKvOR.get('code')=='CAIP1900':EBAPlwcokhGTSNdaUtuXJWVLFzKvOy =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR.get('url')
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrm['saveinfo']['thumbnail']['poster']=EBAPlwcokhGTSNdaUtuXJWVLFzKvOm
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrm['saveinfo']['thumbnail']['thumb']=EBAPlwcokhGTSNdaUtuXJWVLFzKvqs
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrm['saveinfo']['thumbnail']['clearlogo']=EBAPlwcokhGTSNdaUtuXJWVLFzKvOp
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrm['saveinfo']['thumbnail']['icon']=EBAPlwcokhGTSNdaUtuXJWVLFzKvOD
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrm['saveinfo']['thumbnail']['banner']=EBAPlwcokhGTSNdaUtuXJWVLFzKvOy
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrm['saveinfo']['thumbnail']['fanart']=EBAPlwcokhGTSNdaUtuXJWVLFzKvqs
  else:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpb=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.API_DOMAIN+'/v2a/media/stream/info'
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDs=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.GetDefaultParams()
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDC={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TV['cookies']['tving_uuid'].split('-')[0],'uuid':EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TV['cookies']['tving_uuid'],'deviceInfo':'PC_Chrome','noCache':EBAPlwcokhGTSNdaUtuXJWVLFzKvrI(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.GetNoCache(1)),'wm':'Y',}
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDs.update(EBAPlwcokhGTSNdaUtuXJWVLFzKvDC)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpj=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.callRequestCookies('Get',EBAPlwcokhGTSNdaUtuXJWVLFzKvpb,payload=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,params=EBAPlwcokhGTSNdaUtuXJWVLFzKvDs,headers=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,cookies=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvOs=json.loads(EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.text)
   if not('content' in EBAPlwcokhGTSNdaUtuXJWVLFzKvOs['body']):return{}
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrp=EBAPlwcokhGTSNdaUtuXJWVLFzKvOs['body']['content']['info']['movie']
   EBAPlwcokhGTSNdaUtuXJWVLFzKvqe =EBAPlwcokhGTSNdaUtuXJWVLFzKvrp.get('name').get('ko').strip()
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrm['saveinfo']['infoLabels']['title']=EBAPlwcokhGTSNdaUtuXJWVLFzKvqe
   EBAPlwcokhGTSNdaUtuXJWVLFzKvqe +=u' (%s)'%(EBAPlwcokhGTSNdaUtuXJWVLFzKvrp.get('product_year'))
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrm['saveinfo']['title'] =EBAPlwcokhGTSNdaUtuXJWVLFzKvqe
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrm['saveinfo']['infoLabels']['mpaa'] =EBAPlwcokhGTSNdaUtuXJWVLFzKvmy.get(EBAPlwcokhGTSNdaUtuXJWVLFzKvrp.get('grade_code'))
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrm['saveinfo']['infoLabels']['plot'] =EBAPlwcokhGTSNdaUtuXJWVLFzKvrp.get('story').get('ko')
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrm['saveinfo']['infoLabels']['year'] =EBAPlwcokhGTSNdaUtuXJWVLFzKvrp.get('product_year')
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrm['saveinfo']['infoLabels']['studio'] =EBAPlwcokhGTSNdaUtuXJWVLFzKvrp.get('production')
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrm['saveinfo']['infoLabels']['duration']=EBAPlwcokhGTSNdaUtuXJWVLFzKvrp.get('duration')
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrm['saveinfo']['infoLabels']['cast'] =EBAPlwcokhGTSNdaUtuXJWVLFzKvrp.get('actor')
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrm['saveinfo']['infoLabels']['director']=EBAPlwcokhGTSNdaUtuXJWVLFzKvrp.get('director')
   if EBAPlwcokhGTSNdaUtuXJWVLFzKvrp.get('category1_name').get('ko')!='':
    EBAPlwcokhGTSNdaUtuXJWVLFzKvrm['saveinfo']['infoLabels']['genre'].append(EBAPlwcokhGTSNdaUtuXJWVLFzKvrp.get('category1_name').get('ko'))
   if EBAPlwcokhGTSNdaUtuXJWVLFzKvrp.get('category2_name').get('ko')!='':
    EBAPlwcokhGTSNdaUtuXJWVLFzKvrm['saveinfo']['infoLabels']['genre'].append(EBAPlwcokhGTSNdaUtuXJWVLFzKvrp.get('category2_name').get('ko'))
   EBAPlwcokhGTSNdaUtuXJWVLFzKvOC=EBAPlwcokhGTSNdaUtuXJWVLFzKvrI(EBAPlwcokhGTSNdaUtuXJWVLFzKvrp.get('release_date'))
   if EBAPlwcokhGTSNdaUtuXJWVLFzKvOC!='0':EBAPlwcokhGTSNdaUtuXJWVLFzKvrm['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(EBAPlwcokhGTSNdaUtuXJWVLFzKvOC[:4],EBAPlwcokhGTSNdaUtuXJWVLFzKvOC[4:6],EBAPlwcokhGTSNdaUtuXJWVLFzKvOC[6:])
   EBAPlwcokhGTSNdaUtuXJWVLFzKvOm=''
   EBAPlwcokhGTSNdaUtuXJWVLFzKvqs =''
   EBAPlwcokhGTSNdaUtuXJWVLFzKvOp=''
   for EBAPlwcokhGTSNdaUtuXJWVLFzKvOR in EBAPlwcokhGTSNdaUtuXJWVLFzKvrp.get('image'):
    if EBAPlwcokhGTSNdaUtuXJWVLFzKvOR.get('code')=='CAIM2100':EBAPlwcokhGTSNdaUtuXJWVLFzKvOm =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR.get('url')
    elif EBAPlwcokhGTSNdaUtuXJWVLFzKvOR.get('code')=='CAIM0400':EBAPlwcokhGTSNdaUtuXJWVLFzKvqs =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR.get('url')
    elif EBAPlwcokhGTSNdaUtuXJWVLFzKvOR.get('code')=='CAIM1800':EBAPlwcokhGTSNdaUtuXJWVLFzKvOp=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.IMG_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvOR.get('url')
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrm['saveinfo']['thumbnail']['poster']=EBAPlwcokhGTSNdaUtuXJWVLFzKvOm
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrm['saveinfo']['thumbnail']['thumb']=EBAPlwcokhGTSNdaUtuXJWVLFzKvOm 
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrm['saveinfo']['thumbnail']['clearlogo']=EBAPlwcokhGTSNdaUtuXJWVLFzKvOp
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrm['saveinfo']['thumbnail']['fanart']=EBAPlwcokhGTSNdaUtuXJWVLFzKvqs
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvrm
 def GetEuroChannelList(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR):
  EBAPlwcokhGTSNdaUtuXJWVLFzKvDf=[]
  try:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDH ='/v2/operator/highlights'
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDs=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.GetDefaultParams()
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDC={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':EBAPlwcokhGTSNdaUtuXJWVLFzKvrI(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.GetNoCache(2))}
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDs.update(EBAPlwcokhGTSNdaUtuXJWVLFzKvDC)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpb=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.API_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvDH
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpj=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.callRequestCookies('Get',EBAPlwcokhGTSNdaUtuXJWVLFzKvpb,payload=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,params=EBAPlwcokhGTSNdaUtuXJWVLFzKvDs,headers=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,cookies=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDY=json.loads(EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.text)
   if not('result' in EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']):return EBAPlwcokhGTSNdaUtuXJWVLFzKvDf,EBAPlwcokhGTSNdaUtuXJWVLFzKvqi
   EBAPlwcokhGTSNdaUtuXJWVLFzKvqY=EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']['result']
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrD =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.Get_Now_Datetime()
   EBAPlwcokhGTSNdaUtuXJWVLFzKvry=EBAPlwcokhGTSNdaUtuXJWVLFzKvrD+datetime.timedelta(days=-1)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvry=EBAPlwcokhGTSNdaUtuXJWVLFzKvrs(EBAPlwcokhGTSNdaUtuXJWVLFzKvry.strftime('%Y%m%d'))
   for EBAPlwcokhGTSNdaUtuXJWVLFzKvDx in EBAPlwcokhGTSNdaUtuXJWVLFzKvqY:
    EBAPlwcokhGTSNdaUtuXJWVLFzKvrq=EBAPlwcokhGTSNdaUtuXJWVLFzKvrs(EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('content').get('banner_title2')[:8])
    if EBAPlwcokhGTSNdaUtuXJWVLFzKvry<=EBAPlwcokhGTSNdaUtuXJWVLFzKvrq:
     EBAPlwcokhGTSNdaUtuXJWVLFzKvOx={'channel':EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('content').get('banner_sub_title3'),'title':EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('content').get('banner_title'),'subtitle':EBAPlwcokhGTSNdaUtuXJWVLFzKvDx.get('content').get('banner_sub_title2'),}
     EBAPlwcokhGTSNdaUtuXJWVLFzKvDf.append(EBAPlwcokhGTSNdaUtuXJWVLFzKvOx)
  except EBAPlwcokhGTSNdaUtuXJWVLFzKvgD as exception:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrn(exception)
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvDf
 def Make_DecryptKey(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR,step,mediacode='000',timecode='000'):
  if step=='1':
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpH=EBAPlwcokhGTSNdaUtuXJWVLFzKvgp('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpM=EBAPlwcokhGTSNdaUtuXJWVLFzKvgp('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpH=EBAPlwcokhGTSNdaUtuXJWVLFzKvgp('kss2lym0kdw1lks3','utf-8')
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpM=EBAPlwcokhGTSNdaUtuXJWVLFzKvgp([42,7,114,59,55,5,30,1,110,68,2,51,42,97,38,60])
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvpH,EBAPlwcokhGTSNdaUtuXJWVLFzKvpM
 def DecryptPlaintext(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR,EBAPlwcokhGTSNdaUtuXJWVLFzKvpi,EBAPlwcokhGTSNdaUtuXJWVLFzKvpQ,EBAPlwcokhGTSNdaUtuXJWVLFzKvpf):
  EBAPlwcokhGTSNdaUtuXJWVLFzKvpn=AES.new(EBAPlwcokhGTSNdaUtuXJWVLFzKvpQ,AES.MODE_CBC,EBAPlwcokhGTSNdaUtuXJWVLFzKvpf,)
  EBAPlwcokhGTSNdaUtuXJWVLFzKvpC=Padding.unpad(EBAPlwcokhGTSNdaUtuXJWVLFzKvpn.decrypt(base64.standard_b64decode(EBAPlwcokhGTSNdaUtuXJWVLFzKvpi)),16)
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvpC.decode('utf-8')
 def Decrypt_Url(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR,EBAPlwcokhGTSNdaUtuXJWVLFzKvpi,mediacode,EBAPlwcokhGTSNdaUtuXJWVLFzKvyR):
  EBAPlwcokhGTSNdaUtuXJWVLFzKvrO=''
  EBAPlwcokhGTSNdaUtuXJWVLFzKvyr=''
  EBAPlwcokhGTSNdaUtuXJWVLFzKvyg=''
  try:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpH,EBAPlwcokhGTSNdaUtuXJWVLFzKvpM=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.Make_DecryptKey('1',mediacode=mediacode,timecode=EBAPlwcokhGTSNdaUtuXJWVLFzKvyR)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrR=json.loads(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.DecryptPlaintext(EBAPlwcokhGTSNdaUtuXJWVLFzKvpi,EBAPlwcokhGTSNdaUtuXJWVLFzKvpH,EBAPlwcokhGTSNdaUtuXJWVLFzKvpM))
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrn(EBAPlwcokhGTSNdaUtuXJWVLFzKvrR)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrg =EBAPlwcokhGTSNdaUtuXJWVLFzKvrR.get('url')
   EBAPlwcokhGTSNdaUtuXJWVLFzKvyr =EBAPlwcokhGTSNdaUtuXJWVLFzKvrR.get('watermark') if 'watermark' in EBAPlwcokhGTSNdaUtuXJWVLFzKvrR else ''
   EBAPlwcokhGTSNdaUtuXJWVLFzKvyg=EBAPlwcokhGTSNdaUtuXJWVLFzKvrR.get('watermark_key')if 'watermark_key' in EBAPlwcokhGTSNdaUtuXJWVLFzKvrR else ''
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpH,EBAPlwcokhGTSNdaUtuXJWVLFzKvpM=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.Make_DecryptKey('2',mediacode=mediacode,timecode=EBAPlwcokhGTSNdaUtuXJWVLFzKvyR)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrO=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.DecryptPlaintext(EBAPlwcokhGTSNdaUtuXJWVLFzKvrg,EBAPlwcokhGTSNdaUtuXJWVLFzKvpH,EBAPlwcokhGTSNdaUtuXJWVLFzKvpM)
  except EBAPlwcokhGTSNdaUtuXJWVLFzKvgD as exception:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrn(exception)
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvrO,EBAPlwcokhGTSNdaUtuXJWVLFzKvyr,EBAPlwcokhGTSNdaUtuXJWVLFzKvyg
 def GetLiveURL_Test(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR,mediacode,sel_quality):
  EBAPlwcokhGTSNdaUtuXJWVLFzKvDb ={'streaming_url':'','subtitleYn':EBAPlwcokhGTSNdaUtuXJWVLFzKvrx,'error_msg':'','drm_server_url':'','drm_header_key':'','drm_header_value':'','url_filename':'',}
  EBAPlwcokhGTSNdaUtuXJWVLFzKvDn =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TV['cookies']['tving_uuid'].split('-')[0] 
  EBAPlwcokhGTSNdaUtuXJWVLFzKvDe =EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.TV['cookies']['tving_uuid'] 
  try:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDj=EBAPlwcokhGTSNdaUtuXJWVLFzKvrI(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.GetNoCache(1))
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDH ='/v2/media/stream/info' 
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDs=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.GetDefaultParams()
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDC={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':EBAPlwcokhGTSNdaUtuXJWVLFzKvDe,'deviceInfo':'PC','noCache':EBAPlwcokhGTSNdaUtuXJWVLFzKvDj,}
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDs.update(EBAPlwcokhGTSNdaUtuXJWVLFzKvDC)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpb=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.API_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvDH
   EBAPlwcokhGTSNdaUtuXJWVLFzKvms=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.makeDefaultCookies()
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpj=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.callRequestCookies('Get',EBAPlwcokhGTSNdaUtuXJWVLFzKvpb,payload=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,params=EBAPlwcokhGTSNdaUtuXJWVLFzKvDs,headers=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,cookies=EBAPlwcokhGTSNdaUtuXJWVLFzKvms)
   if EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.status_code!=200:
    EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['error_msg']='First Step - {} error'.format(EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.status_code)
    return EBAPlwcokhGTSNdaUtuXJWVLFzKvDb
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDY=json.loads(EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.text)
   if EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']['result']['code']=='060':
    for EBAPlwcokhGTSNdaUtuXJWVLFzKvmI,EBAPlwcokhGTSNdaUtuXJWVLFzKvmb in EBAPlwcokhGTSNdaUtuXJWVLFzKvmD.items():
     if EBAPlwcokhGTSNdaUtuXJWVLFzKvmb==sel_quality:
      EBAPlwcokhGTSNdaUtuXJWVLFzKvym=EBAPlwcokhGTSNdaUtuXJWVLFzKvmI
   elif EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']['result']['code']!='000':
    EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['error_msg']=EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']['result']['message']
    return EBAPlwcokhGTSNdaUtuXJWVLFzKvDb
   else: 
    if not('stream' in EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']):return EBAPlwcokhGTSNdaUtuXJWVLFzKvDb
    EBAPlwcokhGTSNdaUtuXJWVLFzKvyp=[]
    for EBAPlwcokhGTSNdaUtuXJWVLFzKvmI,EBAPlwcokhGTSNdaUtuXJWVLFzKvmb in EBAPlwcokhGTSNdaUtuXJWVLFzKvmD.items():
     for EBAPlwcokhGTSNdaUtuXJWVLFzKvDx in EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']['stream']['quality']:
      if EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['active']=='Y' and EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['code']==EBAPlwcokhGTSNdaUtuXJWVLFzKvmI:
       EBAPlwcokhGTSNdaUtuXJWVLFzKvyp.append({EBAPlwcokhGTSNdaUtuXJWVLFzKvmD.get(EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['code']):EBAPlwcokhGTSNdaUtuXJWVLFzKvDx['code']})
    EBAPlwcokhGTSNdaUtuXJWVLFzKvym=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.CheckQuality(sel_quality,EBAPlwcokhGTSNdaUtuXJWVLFzKvyp)
  except EBAPlwcokhGTSNdaUtuXJWVLFzKvgD as exception:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrn(exception)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['error_msg']='First Step - except error'
   return EBAPlwcokhGTSNdaUtuXJWVLFzKvDb
  try:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDj=EBAPlwcokhGTSNdaUtuXJWVLFzKvrI(EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.GetNoCache(1))
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDH ='/v3/media/stream/info'
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDs=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.GetDefaultParams()
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDC={'mediaCode':mediacode,'deviceId':EBAPlwcokhGTSNdaUtuXJWVLFzKvDn,'uuid':EBAPlwcokhGTSNdaUtuXJWVLFzKvDe,'deviceInfo':'PC_Chrome','streamCode':EBAPlwcokhGTSNdaUtuXJWVLFzKvym,'noCache':EBAPlwcokhGTSNdaUtuXJWVLFzKvDj,'callingFrom':'HTML5','model':EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.MODEL,'videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDs.update(EBAPlwcokhGTSNdaUtuXJWVLFzKvDC)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpb=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.API_DOMAIN+EBAPlwcokhGTSNdaUtuXJWVLFzKvDH
   EBAPlwcokhGTSNdaUtuXJWVLFzKvms=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.makeDefaultCookies()
   EBAPlwcokhGTSNdaUtuXJWVLFzKvpj=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.callRequestCookies('Post',EBAPlwcokhGTSNdaUtuXJWVLFzKvpb,payload=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,params=EBAPlwcokhGTSNdaUtuXJWVLFzKvDs,headers=EBAPlwcokhGTSNdaUtuXJWVLFzKvrY,cookies=EBAPlwcokhGTSNdaUtuXJWVLFzKvms,redirects=EBAPlwcokhGTSNdaUtuXJWVLFzKvre)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDY=json.loads(EBAPlwcokhGTSNdaUtuXJWVLFzKvpj.text)
   if EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']['result']['code']!='000':
    EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['error_msg']=EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']['result']['message']
    return EBAPlwcokhGTSNdaUtuXJWVLFzKvDb
   EBAPlwcokhGTSNdaUtuXJWVLFzKvyD=EBAPlwcokhGTSNdaUtuXJWVLFzKvDY['body']['stream']
   if EBAPlwcokhGTSNdaUtuXJWVLFzKvyD['drm_yn']=='Y':
    EBAPlwcokhGTSNdaUtuXJWVLFzKvyq=EBAPlwcokhGTSNdaUtuXJWVLFzKvyD['playback']['drm']['widevine']
    for EBAPlwcokhGTSNdaUtuXJWVLFzKvyO in EBAPlwcokhGTSNdaUtuXJWVLFzKvyD['playback']['drm']['license']['drm_license_data']:
     if EBAPlwcokhGTSNdaUtuXJWVLFzKvyO['drm_type']=='Widevine':
      EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['drm_server_url'] =EBAPlwcokhGTSNdaUtuXJWVLFzKvyO['drm_server_url']
      EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['drm_header_key'] =EBAPlwcokhGTSNdaUtuXJWVLFzKvyO['drm_header_key']
      EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['drm_header_value']=EBAPlwcokhGTSNdaUtuXJWVLFzKvyO['drm_header_value']
      break
   else:
    EBAPlwcokhGTSNdaUtuXJWVLFzKvyq=EBAPlwcokhGTSNdaUtuXJWVLFzKvyD['playback']['non_drm']
  except EBAPlwcokhGTSNdaUtuXJWVLFzKvgD as exception:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrn(exception)
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['error_msg']='Second Step - except error'
   return EBAPlwcokhGTSNdaUtuXJWVLFzKvDb
  EBAPlwcokhGTSNdaUtuXJWVLFzKvyR=EBAPlwcokhGTSNdaUtuXJWVLFzKvDj
  EBAPlwcokhGTSNdaUtuXJWVLFzKvyq=EBAPlwcokhGTSNdaUtuXJWVLFzKvyq.split('|')[1]
  EBAPlwcokhGTSNdaUtuXJWVLFzKvyq,EBAPlwcokhGTSNdaUtuXJWVLFzKvyr,EBAPlwcokhGTSNdaUtuXJWVLFzKvyg=EBAPlwcokhGTSNdaUtuXJWVLFzKvmR.Decrypt_Url(EBAPlwcokhGTSNdaUtuXJWVLFzKvyq,mediacode,EBAPlwcokhGTSNdaUtuXJWVLFzKvyR)
  EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['streaming_url']=EBAPlwcokhGTSNdaUtuXJWVLFzKvyq
  EBAPlwcokhGTSNdaUtuXJWVLFzKvrH =EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['streaming_url'].find('Policy=')
  if EBAPlwcokhGTSNdaUtuXJWVLFzKvrH!=-1:
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrM =EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['streaming_url'].split('?')[0]
   EBAPlwcokhGTSNdaUtuXJWVLFzKvrQ=EBAPlwcokhGTSNdaUtuXJWVLFzKvgy(urllib.parse.parse_qsl(urllib.parse.urlsplit(EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['streaming_url']).query))
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['streaming_url']='{}&CloudFront-Policy={}'.format(EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['streaming_url'],EBAPlwcokhGTSNdaUtuXJWVLFzKvrQ['Policy'])
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['streaming_url']='{}&CloudFront-Signature={}'.format(EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['streaming_url'],EBAPlwcokhGTSNdaUtuXJWVLFzKvrQ['Signature'])
   EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['streaming_url']='{}&CloudFront-Key-Pair-Id={}'.format(EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['streaming_url'],EBAPlwcokhGTSNdaUtuXJWVLFzKvrQ['Key-Pair-Id'])
  EBAPlwcokhGTSNdaUtuXJWVLFzKvrf=['_tving_token','accessToken','authToken',]
  for EBAPlwcokhGTSNdaUtuXJWVLFzKvmI,EBAPlwcokhGTSNdaUtuXJWVLFzKvmb in EBAPlwcokhGTSNdaUtuXJWVLFzKvms.items():
   if EBAPlwcokhGTSNdaUtuXJWVLFzKvmI in EBAPlwcokhGTSNdaUtuXJWVLFzKvrf:
    EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['streaming_url']='{}&{}={}'.format(EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['streaming_url'],EBAPlwcokhGTSNdaUtuXJWVLFzKvmI,EBAPlwcokhGTSNdaUtuXJWVLFzKvmb)
  EBAPlwcokhGTSNdaUtuXJWVLFzKvrn(EBAPlwcokhGTSNdaUtuXJWVLFzKvDb['streaming_url'])
  return EBAPlwcokhGTSNdaUtuXJWVLFzKvDb
# Created by pyminifier (https://github.com/liftoff/pyminifier)
