__author__="NightRain"
PTaYpHwtWAObDeSiolKCvNFVjRGJhs=object
PTaYpHwtWAObDeSiolKCvNFVjRGJhk=None
PTaYpHwtWAObDeSiolKCvNFVjRGJhM=int
PTaYpHwtWAObDeSiolKCvNFVjRGJUL=True
PTaYpHwtWAObDeSiolKCvNFVjRGJUd=False
PTaYpHwtWAObDeSiolKCvNFVjRGJUm=type
PTaYpHwtWAObDeSiolKCvNFVjRGJUq=dict
PTaYpHwtWAObDeSiolKCvNFVjRGJUE=getattr
PTaYpHwtWAObDeSiolKCvNFVjRGJUu=list
PTaYpHwtWAObDeSiolKCvNFVjRGJUr=len
PTaYpHwtWAObDeSiolKCvNFVjRGJUh=str
PTaYpHwtWAObDeSiolKCvNFVjRGJUc=range
PTaYpHwtWAObDeSiolKCvNFVjRGJUx=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
PTaYpHwtWAObDeSiolKCvNFVjRGJLm=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'오직 티빙에만','mode':'ORI_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'VOD 방송 - 4K','mode':'4K_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 4K','mode':'4K_MOVIE','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
PTaYpHwtWAObDeSiolKCvNFVjRGJLq=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
PTaYpHwtWAObDeSiolKCvNFVjRGJLE=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
PTaYpHwtWAObDeSiolKCvNFVjRGJLu=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
PTaYpHwtWAObDeSiolKCvNFVjRGJLr=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'로맨스','mode':'PROGRAM','stype':'PCO'},{'title':'코미디','mode':'PROGRAM','stype':'PCP'},{'title':'스릴러','mode':'PROGRAM','stype':'PCQ'},{'title':'미스터리(추리)','mode':'PROGRAM','stype':'PCAA'},{'title':'모험','mode':'PROGRAM','stype':'PCX'},{'title':'액션','mode':'PROGRAM','stype':'PCY'},{'title':'판타지','mode':'PROGRAM','stype':'PCR'},{'title':'무협','mode':'PROGRAM','stype':'PCAB'},{'title':'공포','mode':'PROGRAM','stype':'PCAD'},{'title':'리얼리티','mode':'PROGRAM','stype':'PCV'},{'title':'토크쇼','mode':'PROGRAM','stype':'PCU'},{'title':'다큐멘터리','mode':'PROGRAM','stype':'PCT'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'스포츠','mode':'PROGRAM','stype':'PCF'},{'title':'음악','mode':'PROGRAM','stype':'PCAC'},{'title':'공연','mode':'PROGRAM','stype':'PCW'},{'title':'사극(시대극)','mode':'PROGRAM','stype':'PCS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'}]
PTaYpHwtWAObDeSiolKCvNFVjRGJLh=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG23'},{'title':'로맨스','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'스릴러','mode':'MOVIE_SUB','stype':'MG140'},{'title':'미스터리','mode':'MOVIE_SUB','stype':'MG150'},{'title':'모험','mode':'MOVIE_SUB','stype':'MG170'},{'title':'액션','mode':'MOVIE_SUB','stype':'MG120'},{'title':'판타지','mode':'MOVIE_SUB','stype':'MG200'},{'title':'SF','mode':'MOVIE_SUB','stype':'MG210'},{'title':'공포','mode':'MOVIE_SUB','stype':'MG160'},{'title':'다큐멘터리','mode':'MOVIE_SUB','stype':'MG250'},{'title':'다양성 영화','mode':'MOVIE_SUB','stype':'diversityYn'}]
PTaYpHwtWAObDeSiolKCvNFVjRGJLU=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
PTaYpHwtWAObDeSiolKCvNFVjRGJLc={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
from tvingCore import*
PTaYpHwtWAObDeSiolKCvNFVjRGJLx =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
PTaYpHwtWAObDeSiolKCvNFVjRGJLB=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
class PTaYpHwtWAObDeSiolKCvNFVjRGJLd(PTaYpHwtWAObDeSiolKCvNFVjRGJhs):
 def __init__(PTaYpHwtWAObDeSiolKCvNFVjRGJLX,PTaYpHwtWAObDeSiolKCvNFVjRGJLy,PTaYpHwtWAObDeSiolKCvNFVjRGJLQ,PTaYpHwtWAObDeSiolKCvNFVjRGJLz):
  PTaYpHwtWAObDeSiolKCvNFVjRGJLX._addon_url =PTaYpHwtWAObDeSiolKCvNFVjRGJLy
  PTaYpHwtWAObDeSiolKCvNFVjRGJLX._addon_handle=PTaYpHwtWAObDeSiolKCvNFVjRGJLQ
  PTaYpHwtWAObDeSiolKCvNFVjRGJLX.main_params =PTaYpHwtWAObDeSiolKCvNFVjRGJLz
  PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj =EBAPlwcokhGTSNdaUtuXJWVLFzKvmp() 
  PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.TV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_stream(mpd,m3u8)'))
 def addon_noti(PTaYpHwtWAObDeSiolKCvNFVjRGJLX,sting):
  try:
   PTaYpHwtWAObDeSiolKCvNFVjRGJLn=xbmcgui.Dialog()
   PTaYpHwtWAObDeSiolKCvNFVjRGJLn.notification(__addonname__,sting)
  except:
   PTaYpHwtWAObDeSiolKCvNFVjRGJhk
 def addon_log(PTaYpHwtWAObDeSiolKCvNFVjRGJLX,string):
  try:
   PTaYpHwtWAObDeSiolKCvNFVjRGJLg=string.encode('utf-8','ignore')
  except:
   PTaYpHwtWAObDeSiolKCvNFVjRGJLg='addonException: addon_log'
  PTaYpHwtWAObDeSiolKCvNFVjRGJLI=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,PTaYpHwtWAObDeSiolKCvNFVjRGJLg),level=PTaYpHwtWAObDeSiolKCvNFVjRGJLI)
 def get_keyboard_input(PTaYpHwtWAObDeSiolKCvNFVjRGJLX,PTaYpHwtWAObDeSiolKCvNFVjRGJdz):
  PTaYpHwtWAObDeSiolKCvNFVjRGJLs=PTaYpHwtWAObDeSiolKCvNFVjRGJhk
  kb=xbmc.Keyboard()
  kb.setHeading(PTaYpHwtWAObDeSiolKCvNFVjRGJdz)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   PTaYpHwtWAObDeSiolKCvNFVjRGJLs=kb.getText()
  return PTaYpHwtWAObDeSiolKCvNFVjRGJLs
 def get_settings_account(PTaYpHwtWAObDeSiolKCvNFVjRGJLX):
  PTaYpHwtWAObDeSiolKCvNFVjRGJLk =__addon__.getSetting('id')
  PTaYpHwtWAObDeSiolKCvNFVjRGJLM =__addon__.getSetting('pw')
  PTaYpHwtWAObDeSiolKCvNFVjRGJdL =__addon__.getSetting('login_type')
  PTaYpHwtWAObDeSiolKCvNFVjRGJdm=PTaYpHwtWAObDeSiolKCvNFVjRGJhM(__addon__.getSetting('selected_profile'))
  return(PTaYpHwtWAObDeSiolKCvNFVjRGJLk,PTaYpHwtWAObDeSiolKCvNFVjRGJLM,PTaYpHwtWAObDeSiolKCvNFVjRGJdL,PTaYpHwtWAObDeSiolKCvNFVjRGJdm)
 def get_settings_uhd(PTaYpHwtWAObDeSiolKCvNFVjRGJLX):
  return PTaYpHwtWAObDeSiolKCvNFVjRGJUL if __addon__.getSetting('active_uhd')=='true' else PTaYpHwtWAObDeSiolKCvNFVjRGJUd
 def get_settings_playback(PTaYpHwtWAObDeSiolKCvNFVjRGJLX):
  PTaYpHwtWAObDeSiolKCvNFVjRGJdq={'active_uhd':PTaYpHwtWAObDeSiolKCvNFVjRGJUL if __addon__.getSetting('active_uhd')=='true' else PTaYpHwtWAObDeSiolKCvNFVjRGJUd,'streamFilename':PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.TV_STREAM_FILENAME,}
  return PTaYpHwtWAObDeSiolKCvNFVjRGJdq
 def get_settings_proxyport(PTaYpHwtWAObDeSiolKCvNFVjRGJLX):
  PTaYpHwtWAObDeSiolKCvNFVjRGJdE =PTaYpHwtWAObDeSiolKCvNFVjRGJUL if __addon__.getSetting('proxyYn')=='true' else PTaYpHwtWAObDeSiolKCvNFVjRGJUd
  PTaYpHwtWAObDeSiolKCvNFVjRGJdu=PTaYpHwtWAObDeSiolKCvNFVjRGJhM(__addon__.getSetting('proxyPort'))
  return PTaYpHwtWAObDeSiolKCvNFVjRGJdE,PTaYpHwtWAObDeSiolKCvNFVjRGJdu
 def get_settings_totalsearch(PTaYpHwtWAObDeSiolKCvNFVjRGJLX):
  PTaYpHwtWAObDeSiolKCvNFVjRGJdr =PTaYpHwtWAObDeSiolKCvNFVjRGJUL if __addon__.getSetting('local_search')=='true' else PTaYpHwtWAObDeSiolKCvNFVjRGJUd
  PTaYpHwtWAObDeSiolKCvNFVjRGJdh=PTaYpHwtWAObDeSiolKCvNFVjRGJUL if __addon__.getSetting('local_history')=='true' else PTaYpHwtWAObDeSiolKCvNFVjRGJUd
  PTaYpHwtWAObDeSiolKCvNFVjRGJdU =PTaYpHwtWAObDeSiolKCvNFVjRGJUL if __addon__.getSetting('total_search')=='true' else PTaYpHwtWAObDeSiolKCvNFVjRGJUd
  PTaYpHwtWAObDeSiolKCvNFVjRGJdc=PTaYpHwtWAObDeSiolKCvNFVjRGJUL if __addon__.getSetting('total_history')=='true' else PTaYpHwtWAObDeSiolKCvNFVjRGJUd
  PTaYpHwtWAObDeSiolKCvNFVjRGJdx=PTaYpHwtWAObDeSiolKCvNFVjRGJUL if __addon__.getSetting('menu_bookmark')=='true' else PTaYpHwtWAObDeSiolKCvNFVjRGJUd
  return(PTaYpHwtWAObDeSiolKCvNFVjRGJdr,PTaYpHwtWAObDeSiolKCvNFVjRGJdh,PTaYpHwtWAObDeSiolKCvNFVjRGJdU,PTaYpHwtWAObDeSiolKCvNFVjRGJdc,PTaYpHwtWAObDeSiolKCvNFVjRGJdx)
 def get_settings_makebookmark(PTaYpHwtWAObDeSiolKCvNFVjRGJLX):
  return PTaYpHwtWAObDeSiolKCvNFVjRGJUL if __addon__.getSetting('make_bookmark')=='true' else PTaYpHwtWAObDeSiolKCvNFVjRGJUd
 def get_settings_direct_replay(PTaYpHwtWAObDeSiolKCvNFVjRGJLX):
  PTaYpHwtWAObDeSiolKCvNFVjRGJdB=PTaYpHwtWAObDeSiolKCvNFVjRGJhM(__addon__.getSetting('direct_replay'))
  if PTaYpHwtWAObDeSiolKCvNFVjRGJdB==0:
   return PTaYpHwtWAObDeSiolKCvNFVjRGJUd
  else:
   return PTaYpHwtWAObDeSiolKCvNFVjRGJUL
 def set_winEpisodeOrderby(PTaYpHwtWAObDeSiolKCvNFVjRGJLX,PTaYpHwtWAObDeSiolKCvNFVjRGJdy):
  __addon__.setSetting('tving_orderby',PTaYpHwtWAObDeSiolKCvNFVjRGJdy)
  PTaYpHwtWAObDeSiolKCvNFVjRGJdX=xbmcgui.Window(10000)
  PTaYpHwtWAObDeSiolKCvNFVjRGJdX.setProperty('TVING_M_ORDERBY',PTaYpHwtWAObDeSiolKCvNFVjRGJdy)
 def get_winEpisodeOrderby(PTaYpHwtWAObDeSiolKCvNFVjRGJLX):
  PTaYpHwtWAObDeSiolKCvNFVjRGJdy=__addon__.getSetting('tving_orderby')
  if PTaYpHwtWAObDeSiolKCvNFVjRGJdy in['',PTaYpHwtWAObDeSiolKCvNFVjRGJhk]:PTaYpHwtWAObDeSiolKCvNFVjRGJdy='desc'
  return PTaYpHwtWAObDeSiolKCvNFVjRGJdy
 def add_dir(PTaYpHwtWAObDeSiolKCvNFVjRGJLX,label,sublabel='',img='',infoLabels=PTaYpHwtWAObDeSiolKCvNFVjRGJhk,isFolder=PTaYpHwtWAObDeSiolKCvNFVjRGJUL,params='',isLink=PTaYpHwtWAObDeSiolKCvNFVjRGJUd,ContextMenu=PTaYpHwtWAObDeSiolKCvNFVjRGJhk):
  PTaYpHwtWAObDeSiolKCvNFVjRGJdQ='%s?%s'%(PTaYpHwtWAObDeSiolKCvNFVjRGJLX._addon_url,urllib.parse.urlencode(params))
  if sublabel:PTaYpHwtWAObDeSiolKCvNFVjRGJdz='%s < %s >'%(label,sublabel)
  else: PTaYpHwtWAObDeSiolKCvNFVjRGJdz=label
  if not img:img='DefaultFolder.png'
  PTaYpHwtWAObDeSiolKCvNFVjRGJdf=xbmcgui.ListItem(PTaYpHwtWAObDeSiolKCvNFVjRGJdz)
  if PTaYpHwtWAObDeSiolKCvNFVjRGJUm(img)==PTaYpHwtWAObDeSiolKCvNFVjRGJUq:
   PTaYpHwtWAObDeSiolKCvNFVjRGJdf.setArt(img)
  else:
   PTaYpHwtWAObDeSiolKCvNFVjRGJdf.setArt({'thumb':img,'poster':img})
  if PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.KodiVersion>=20:
   if infoLabels:PTaYpHwtWAObDeSiolKCvNFVjRGJLX.Set_InfoTag(PTaYpHwtWAObDeSiolKCvNFVjRGJdf.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:PTaYpHwtWAObDeSiolKCvNFVjRGJdf.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   PTaYpHwtWAObDeSiolKCvNFVjRGJdf.setProperty('IsPlayable','true')
  if ContextMenu:PTaYpHwtWAObDeSiolKCvNFVjRGJdf.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(PTaYpHwtWAObDeSiolKCvNFVjRGJLX._addon_handle,PTaYpHwtWAObDeSiolKCvNFVjRGJdQ,PTaYpHwtWAObDeSiolKCvNFVjRGJdf,isFolder)
 def get_selQuality(PTaYpHwtWAObDeSiolKCvNFVjRGJLX,etype):
  try:
   PTaYpHwtWAObDeSiolKCvNFVjRGJdn='selected_quality'
   PTaYpHwtWAObDeSiolKCvNFVjRGJdg=[1080,720,480,360]
   PTaYpHwtWAObDeSiolKCvNFVjRGJdI=PTaYpHwtWAObDeSiolKCvNFVjRGJhM(__addon__.getSetting(PTaYpHwtWAObDeSiolKCvNFVjRGJdn))
   return PTaYpHwtWAObDeSiolKCvNFVjRGJdg[PTaYpHwtWAObDeSiolKCvNFVjRGJdI]
  except:
   PTaYpHwtWAObDeSiolKCvNFVjRGJhk
  return 720 
 def Set_InfoTag(PTaYpHwtWAObDeSiolKCvNFVjRGJLX,video_InfoTag:xbmc.InfoTagVideo,PTaYpHwtWAObDeSiolKCvNFVjRGJmu):
  for PTaYpHwtWAObDeSiolKCvNFVjRGJds,value in PTaYpHwtWAObDeSiolKCvNFVjRGJmu.items():
   if PTaYpHwtWAObDeSiolKCvNFVjRGJLc[PTaYpHwtWAObDeSiolKCvNFVjRGJds]['type']=='string':
    PTaYpHwtWAObDeSiolKCvNFVjRGJUE(video_InfoTag,PTaYpHwtWAObDeSiolKCvNFVjRGJLc[PTaYpHwtWAObDeSiolKCvNFVjRGJds]['func'])(value)
   elif PTaYpHwtWAObDeSiolKCvNFVjRGJLc[PTaYpHwtWAObDeSiolKCvNFVjRGJds]['type']=='int':
    if PTaYpHwtWAObDeSiolKCvNFVjRGJUm(value)==PTaYpHwtWAObDeSiolKCvNFVjRGJhM:
     PTaYpHwtWAObDeSiolKCvNFVjRGJdk=PTaYpHwtWAObDeSiolKCvNFVjRGJhM(value)
    else:
     PTaYpHwtWAObDeSiolKCvNFVjRGJdk=0
    PTaYpHwtWAObDeSiolKCvNFVjRGJUE(video_InfoTag,PTaYpHwtWAObDeSiolKCvNFVjRGJLc[PTaYpHwtWAObDeSiolKCvNFVjRGJds]['func'])(PTaYpHwtWAObDeSiolKCvNFVjRGJdk)
   elif PTaYpHwtWAObDeSiolKCvNFVjRGJLc[PTaYpHwtWAObDeSiolKCvNFVjRGJds]['type']=='actor':
    if value!=[]:
     PTaYpHwtWAObDeSiolKCvNFVjRGJUE(video_InfoTag,PTaYpHwtWAObDeSiolKCvNFVjRGJLc[PTaYpHwtWAObDeSiolKCvNFVjRGJds]['func'])([xbmc.Actor(name)for name in value])
   elif PTaYpHwtWAObDeSiolKCvNFVjRGJLc[PTaYpHwtWAObDeSiolKCvNFVjRGJds]['type']=='list':
    if PTaYpHwtWAObDeSiolKCvNFVjRGJUm(value)==PTaYpHwtWAObDeSiolKCvNFVjRGJUu:
     PTaYpHwtWAObDeSiolKCvNFVjRGJUE(video_InfoTag,PTaYpHwtWAObDeSiolKCvNFVjRGJLc[PTaYpHwtWAObDeSiolKCvNFVjRGJds]['func'])(value)
    else:
     PTaYpHwtWAObDeSiolKCvNFVjRGJUE(video_InfoTag,PTaYpHwtWAObDeSiolKCvNFVjRGJLc[PTaYpHwtWAObDeSiolKCvNFVjRGJds]['func'])([value])
 def dp_Main_List(PTaYpHwtWAObDeSiolKCvNFVjRGJLX):
  (PTaYpHwtWAObDeSiolKCvNFVjRGJdr,PTaYpHwtWAObDeSiolKCvNFVjRGJdh,PTaYpHwtWAObDeSiolKCvNFVjRGJdU,PTaYpHwtWAObDeSiolKCvNFVjRGJdc,PTaYpHwtWAObDeSiolKCvNFVjRGJdx)=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.get_settings_totalsearch()
  for PTaYpHwtWAObDeSiolKCvNFVjRGJdM in PTaYpHwtWAObDeSiolKCvNFVjRGJLm:
   PTaYpHwtWAObDeSiolKCvNFVjRGJdz=PTaYpHwtWAObDeSiolKCvNFVjRGJdM.get('title')
   PTaYpHwtWAObDeSiolKCvNFVjRGJmL=''
   if PTaYpHwtWAObDeSiolKCvNFVjRGJdM.get('mode')=='SEARCH_GROUP' and PTaYpHwtWAObDeSiolKCvNFVjRGJdr ==PTaYpHwtWAObDeSiolKCvNFVjRGJUd:continue
   elif PTaYpHwtWAObDeSiolKCvNFVjRGJdM.get('mode')=='SEARCH_HISTORY' and PTaYpHwtWAObDeSiolKCvNFVjRGJdh==PTaYpHwtWAObDeSiolKCvNFVjRGJUd:continue
   elif PTaYpHwtWAObDeSiolKCvNFVjRGJdM.get('mode')=='TOTAL_SEARCH' and PTaYpHwtWAObDeSiolKCvNFVjRGJdU ==PTaYpHwtWAObDeSiolKCvNFVjRGJUd:continue
   elif PTaYpHwtWAObDeSiolKCvNFVjRGJdM.get('mode')=='TOTAL_HISTORY' and PTaYpHwtWAObDeSiolKCvNFVjRGJdc==PTaYpHwtWAObDeSiolKCvNFVjRGJUd:continue
   elif PTaYpHwtWAObDeSiolKCvNFVjRGJdM.get('mode')=='MENU_BOOKMARK' and PTaYpHwtWAObDeSiolKCvNFVjRGJdx==PTaYpHwtWAObDeSiolKCvNFVjRGJUd:continue
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd={'mode':PTaYpHwtWAObDeSiolKCvNFVjRGJdM.get('mode'),'stype':PTaYpHwtWAObDeSiolKCvNFVjRGJdM.get('stype'),'orderby':PTaYpHwtWAObDeSiolKCvNFVjRGJdM.get('orderby'),'ordernm':PTaYpHwtWAObDeSiolKCvNFVjRGJdM.get('ordernm'),'page':'1'}
   if PTaYpHwtWAObDeSiolKCvNFVjRGJdM.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    PTaYpHwtWAObDeSiolKCvNFVjRGJmq=PTaYpHwtWAObDeSiolKCvNFVjRGJUd
    PTaYpHwtWAObDeSiolKCvNFVjRGJmE =PTaYpHwtWAObDeSiolKCvNFVjRGJUL
   else:
    PTaYpHwtWAObDeSiolKCvNFVjRGJmq=PTaYpHwtWAObDeSiolKCvNFVjRGJUL
    PTaYpHwtWAObDeSiolKCvNFVjRGJmE =PTaYpHwtWAObDeSiolKCvNFVjRGJUd
   PTaYpHwtWAObDeSiolKCvNFVjRGJmu={'title':PTaYpHwtWAObDeSiolKCvNFVjRGJdz,'plot':PTaYpHwtWAObDeSiolKCvNFVjRGJdz}
   if PTaYpHwtWAObDeSiolKCvNFVjRGJdM.get('mode')=='XXX':PTaYpHwtWAObDeSiolKCvNFVjRGJmu=PTaYpHwtWAObDeSiolKCvNFVjRGJhk
   if 'icon' in PTaYpHwtWAObDeSiolKCvNFVjRGJdM:PTaYpHwtWAObDeSiolKCvNFVjRGJmL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',PTaYpHwtWAObDeSiolKCvNFVjRGJdM.get('icon')) 
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.add_dir(PTaYpHwtWAObDeSiolKCvNFVjRGJdz,sublabel='',img=PTaYpHwtWAObDeSiolKCvNFVjRGJmL,infoLabels=PTaYpHwtWAObDeSiolKCvNFVjRGJmu,isFolder=PTaYpHwtWAObDeSiolKCvNFVjRGJmq,params=PTaYpHwtWAObDeSiolKCvNFVjRGJmd,isLink=PTaYpHwtWAObDeSiolKCvNFVjRGJmE)
  xbmcplugin.endOfDirectory(PTaYpHwtWAObDeSiolKCvNFVjRGJLX._addon_handle)
 def login_main(PTaYpHwtWAObDeSiolKCvNFVjRGJLX):
  (PTaYpHwtWAObDeSiolKCvNFVjRGJmh,PTaYpHwtWAObDeSiolKCvNFVjRGJmU,PTaYpHwtWAObDeSiolKCvNFVjRGJmc,PTaYpHwtWAObDeSiolKCvNFVjRGJmx)=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.get_settings_account()
  if not(PTaYpHwtWAObDeSiolKCvNFVjRGJmh and PTaYpHwtWAObDeSiolKCvNFVjRGJmU):
   PTaYpHwtWAObDeSiolKCvNFVjRGJLn=xbmcgui.Dialog()
   PTaYpHwtWAObDeSiolKCvNFVjRGJmB=PTaYpHwtWAObDeSiolKCvNFVjRGJLn.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if PTaYpHwtWAObDeSiolKCvNFVjRGJmB==PTaYpHwtWAObDeSiolKCvNFVjRGJUL:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if PTaYpHwtWAObDeSiolKCvNFVjRGJLX.cookiefile_check():return
  if base64.standard_b64encode(PTaYpHwtWAObDeSiolKCvNFVjRGJmh.encode()).decode('utf-8')=='a3ltOTUxMDg4':
   PTaYpHwtWAObDeSiolKCvNFVjRGJmX=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.GetCredential2(PTaYpHwtWAObDeSiolKCvNFVjRGJmh,PTaYpHwtWAObDeSiolKCvNFVjRGJmU,PTaYpHwtWAObDeSiolKCvNFVjRGJmc,PTaYpHwtWAObDeSiolKCvNFVjRGJmx)
  else:
   PTaYpHwtWAObDeSiolKCvNFVjRGJLn=xbmcgui.Dialog()
   PTaYpHwtWAObDeSiolKCvNFVjRGJmy=PTaYpHwtWAObDeSiolKCvNFVjRGJLn.browse(1,__language__(30917).encode('utf8'),'','.twc',PTaYpHwtWAObDeSiolKCvNFVjRGJUd,PTaYpHwtWAObDeSiolKCvNFVjRGJUd,'',PTaYpHwtWAObDeSiolKCvNFVjRGJUd)
   if PTaYpHwtWAObDeSiolKCvNFVjRGJmy!='':
    PTaYpHwtWAObDeSiolKCvNFVjRGJmQ=xbmcvfs.translatePath(os.path.join(__profile__,'tvinginfo-temp.twc'))
    xbmcvfs.copy(PTaYpHwtWAObDeSiolKCvNFVjRGJmy,PTaYpHwtWAObDeSiolKCvNFVjRGJmQ)
    PTaYpHwtWAObDeSiolKCvNFVjRGJmX=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.WebCookies_Load(PTaYpHwtWAObDeSiolKCvNFVjRGJmQ)
    xbmcvfs.delete(PTaYpHwtWAObDeSiolKCvNFVjRGJmQ)
    if PTaYpHwtWAObDeSiolKCvNFVjRGJmX:
     PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.JsonFile_Save(PTaYpHwtWAObDeSiolKCvNFVjRGJLx,PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.TV)
     PTaYpHwtWAObDeSiolKCvNFVjRGJLX.addon_noti(__language__(30918).encode('utf8'))
     return
   else:
    PTaYpHwtWAObDeSiolKCvNFVjRGJmX=PTaYpHwtWAObDeSiolKCvNFVjRGJUd
  if PTaYpHwtWAObDeSiolKCvNFVjRGJmX==PTaYpHwtWAObDeSiolKCvNFVjRGJUL:
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.cookiefile_save()
  else:
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(PTaYpHwtWAObDeSiolKCvNFVjRGJLX,PTaYpHwtWAObDeSiolKCvNFVjRGJmg):
  PTaYpHwtWAObDeSiolKCvNFVjRGJmz=PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('stype')
  if PTaYpHwtWAObDeSiolKCvNFVjRGJmz=='live':
   PTaYpHwtWAObDeSiolKCvNFVjRGJmf=PTaYpHwtWAObDeSiolKCvNFVjRGJLq
  elif PTaYpHwtWAObDeSiolKCvNFVjRGJmz=='vod':
   PTaYpHwtWAObDeSiolKCvNFVjRGJmf=PTaYpHwtWAObDeSiolKCvNFVjRGJLr
  else:
   PTaYpHwtWAObDeSiolKCvNFVjRGJmf=PTaYpHwtWAObDeSiolKCvNFVjRGJLh
  for PTaYpHwtWAObDeSiolKCvNFVjRGJmn in PTaYpHwtWAObDeSiolKCvNFVjRGJmf:
   PTaYpHwtWAObDeSiolKCvNFVjRGJdz=PTaYpHwtWAObDeSiolKCvNFVjRGJmn.get('title')
   if PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('ordernm')!='-':
    PTaYpHwtWAObDeSiolKCvNFVjRGJdz+='  ('+PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('ordernm')+')'
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd={'mode':PTaYpHwtWAObDeSiolKCvNFVjRGJmn.get('mode'),'stype':PTaYpHwtWAObDeSiolKCvNFVjRGJmn.get('stype'),'orderby':PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('orderby'),'ordernm':PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('ordernm'),'page':'1'}
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.add_dir(PTaYpHwtWAObDeSiolKCvNFVjRGJdz,sublabel='',img='',infoLabels=PTaYpHwtWAObDeSiolKCvNFVjRGJhk,isFolder=PTaYpHwtWAObDeSiolKCvNFVjRGJUL,params=PTaYpHwtWAObDeSiolKCvNFVjRGJmd)
  if PTaYpHwtWAObDeSiolKCvNFVjRGJUr(PTaYpHwtWAObDeSiolKCvNFVjRGJmf)>0:xbmcplugin.endOfDirectory(PTaYpHwtWAObDeSiolKCvNFVjRGJLX._addon_handle)
 def dp_SubTitle_Group(PTaYpHwtWAObDeSiolKCvNFVjRGJLX,PTaYpHwtWAObDeSiolKCvNFVjRGJmg): 
  for PTaYpHwtWAObDeSiolKCvNFVjRGJmn in PTaYpHwtWAObDeSiolKCvNFVjRGJLU:
   PTaYpHwtWAObDeSiolKCvNFVjRGJdz=PTaYpHwtWAObDeSiolKCvNFVjRGJmn.get('title')
   if PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('ordernm')!='-':
    PTaYpHwtWAObDeSiolKCvNFVjRGJdz+='  ('+PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('ordernm')+')'
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd={'mode':PTaYpHwtWAObDeSiolKCvNFVjRGJmn.get('mode'),'genreCode':PTaYpHwtWAObDeSiolKCvNFVjRGJmn.get('genreCode'),'stype':PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('stype'),'orderby':PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('orderby'),'page':'1'}
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.add_dir(PTaYpHwtWAObDeSiolKCvNFVjRGJdz,sublabel='',img='',infoLabels=PTaYpHwtWAObDeSiolKCvNFVjRGJhk,isFolder=PTaYpHwtWAObDeSiolKCvNFVjRGJUL,params=PTaYpHwtWAObDeSiolKCvNFVjRGJmd)
  if PTaYpHwtWAObDeSiolKCvNFVjRGJUr(PTaYpHwtWAObDeSiolKCvNFVjRGJLU)>0:xbmcplugin.endOfDirectory(PTaYpHwtWAObDeSiolKCvNFVjRGJLX._addon_handle)
 def dp_LiveChannel_List(PTaYpHwtWAObDeSiolKCvNFVjRGJLX,PTaYpHwtWAObDeSiolKCvNFVjRGJmg):
  PTaYpHwtWAObDeSiolKCvNFVjRGJmz =PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('stype')
  PTaYpHwtWAObDeSiolKCvNFVjRGJmI =PTaYpHwtWAObDeSiolKCvNFVjRGJhM(PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('page'))
  PTaYpHwtWAObDeSiolKCvNFVjRGJms,PTaYpHwtWAObDeSiolKCvNFVjRGJmk=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.GetLiveChannelList(PTaYpHwtWAObDeSiolKCvNFVjRGJmz,PTaYpHwtWAObDeSiolKCvNFVjRGJmI)
  for PTaYpHwtWAObDeSiolKCvNFVjRGJmM in PTaYpHwtWAObDeSiolKCvNFVjRGJms:
   PTaYpHwtWAObDeSiolKCvNFVjRGJdz =PTaYpHwtWAObDeSiolKCvNFVjRGJmM.get('title')
   PTaYpHwtWAObDeSiolKCvNFVjRGJmr =PTaYpHwtWAObDeSiolKCvNFVjRGJmM.get('channel')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqL =PTaYpHwtWAObDeSiolKCvNFVjRGJmM.get('thumbnail')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqd =PTaYpHwtWAObDeSiolKCvNFVjRGJmM.get('synopsis')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqm =PTaYpHwtWAObDeSiolKCvNFVjRGJmM.get('channelepg')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqE =PTaYpHwtWAObDeSiolKCvNFVjRGJmM.get('cast')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqu =PTaYpHwtWAObDeSiolKCvNFVjRGJmM.get('director')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqr =PTaYpHwtWAObDeSiolKCvNFVjRGJmM.get('info_genre')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqh =PTaYpHwtWAObDeSiolKCvNFVjRGJmM.get('year')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqU =PTaYpHwtWAObDeSiolKCvNFVjRGJmM.get('mpaa')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqc =PTaYpHwtWAObDeSiolKCvNFVjRGJmM.get('premiered')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqx={'mediatype':'episode','title':PTaYpHwtWAObDeSiolKCvNFVjRGJdz,'studio':PTaYpHwtWAObDeSiolKCvNFVjRGJmr,'cast':PTaYpHwtWAObDeSiolKCvNFVjRGJqE,'director':PTaYpHwtWAObDeSiolKCvNFVjRGJqu,'genre':PTaYpHwtWAObDeSiolKCvNFVjRGJqr,'plot':'%s\n%s\n%s\n\n%s'%(PTaYpHwtWAObDeSiolKCvNFVjRGJmr,PTaYpHwtWAObDeSiolKCvNFVjRGJdz,PTaYpHwtWAObDeSiolKCvNFVjRGJqm,PTaYpHwtWAObDeSiolKCvNFVjRGJqd),'year':PTaYpHwtWAObDeSiolKCvNFVjRGJqh,'mpaa':PTaYpHwtWAObDeSiolKCvNFVjRGJqU,'premiered':PTaYpHwtWAObDeSiolKCvNFVjRGJqc}
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd={'mode':'LIVE','mediacode':PTaYpHwtWAObDeSiolKCvNFVjRGJmM.get('mediacode'),'stype':PTaYpHwtWAObDeSiolKCvNFVjRGJmz}
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.add_dir(PTaYpHwtWAObDeSiolKCvNFVjRGJmr,sublabel=PTaYpHwtWAObDeSiolKCvNFVjRGJdz,img=PTaYpHwtWAObDeSiolKCvNFVjRGJqL,infoLabels=PTaYpHwtWAObDeSiolKCvNFVjRGJqx,isFolder=PTaYpHwtWAObDeSiolKCvNFVjRGJUd,params=PTaYpHwtWAObDeSiolKCvNFVjRGJmd)
  if PTaYpHwtWAObDeSiolKCvNFVjRGJmk:
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd['mode']='CHANNEL' 
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd['stype']=PTaYpHwtWAObDeSiolKCvNFVjRGJmz 
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd['page']=PTaYpHwtWAObDeSiolKCvNFVjRGJUh(PTaYpHwtWAObDeSiolKCvNFVjRGJmI+1)
   PTaYpHwtWAObDeSiolKCvNFVjRGJdz='[B]%s >>[/B]'%'다음 페이지'
   PTaYpHwtWAObDeSiolKCvNFVjRGJqB=PTaYpHwtWAObDeSiolKCvNFVjRGJUh(PTaYpHwtWAObDeSiolKCvNFVjRGJmI+1)
   PTaYpHwtWAObDeSiolKCvNFVjRGJmL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.add_dir(PTaYpHwtWAObDeSiolKCvNFVjRGJdz,sublabel=PTaYpHwtWAObDeSiolKCvNFVjRGJqB,img=PTaYpHwtWAObDeSiolKCvNFVjRGJmL,infoLabels=PTaYpHwtWAObDeSiolKCvNFVjRGJhk,isFolder=PTaYpHwtWAObDeSiolKCvNFVjRGJUL,params=PTaYpHwtWAObDeSiolKCvNFVjRGJmd)
  if PTaYpHwtWAObDeSiolKCvNFVjRGJUr(PTaYpHwtWAObDeSiolKCvNFVjRGJms)>0:xbmcplugin.endOfDirectory(PTaYpHwtWAObDeSiolKCvNFVjRGJLX._addon_handle,cacheToDisc=PTaYpHwtWAObDeSiolKCvNFVjRGJUd)
 def dp_Program_List(PTaYpHwtWAObDeSiolKCvNFVjRGJLX,PTaYpHwtWAObDeSiolKCvNFVjRGJmg):
  PTaYpHwtWAObDeSiolKCvNFVjRGJqX =PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('stype')
  PTaYpHwtWAObDeSiolKCvNFVjRGJdy =PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('orderby')
  PTaYpHwtWAObDeSiolKCvNFVjRGJmI =PTaYpHwtWAObDeSiolKCvNFVjRGJhM(PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('page'))
  PTaYpHwtWAObDeSiolKCvNFVjRGJqy=PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('genreCode')
  if PTaYpHwtWAObDeSiolKCvNFVjRGJqy==PTaYpHwtWAObDeSiolKCvNFVjRGJhk:PTaYpHwtWAObDeSiolKCvNFVjRGJqy='all'
  PTaYpHwtWAObDeSiolKCvNFVjRGJqQ,PTaYpHwtWAObDeSiolKCvNFVjRGJmk=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.GetProgramList(PTaYpHwtWAObDeSiolKCvNFVjRGJqX,PTaYpHwtWAObDeSiolKCvNFVjRGJdy,PTaYpHwtWAObDeSiolKCvNFVjRGJmI,PTaYpHwtWAObDeSiolKCvNFVjRGJqy)
  for PTaYpHwtWAObDeSiolKCvNFVjRGJqz in PTaYpHwtWAObDeSiolKCvNFVjRGJqQ:
   PTaYpHwtWAObDeSiolKCvNFVjRGJdz =PTaYpHwtWAObDeSiolKCvNFVjRGJqz.get('title')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqL =PTaYpHwtWAObDeSiolKCvNFVjRGJqz.get('thumbnail')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqd =PTaYpHwtWAObDeSiolKCvNFVjRGJqz.get('synopsis')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqf =PTaYpHwtWAObDeSiolKCvNFVjRGJqz.get('channel')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqE =PTaYpHwtWAObDeSiolKCvNFVjRGJqz.get('cast')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqu =PTaYpHwtWAObDeSiolKCvNFVjRGJqz.get('director')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqr=PTaYpHwtWAObDeSiolKCvNFVjRGJqz.get('info_genre')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqh =PTaYpHwtWAObDeSiolKCvNFVjRGJqz.get('year')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqc =PTaYpHwtWAObDeSiolKCvNFVjRGJqz.get('premiered')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqU =PTaYpHwtWAObDeSiolKCvNFVjRGJqz.get('mpaa')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqx={'mediatype':'tvshow','title':PTaYpHwtWAObDeSiolKCvNFVjRGJdz,'studio':PTaYpHwtWAObDeSiolKCvNFVjRGJqf,'cast':PTaYpHwtWAObDeSiolKCvNFVjRGJqE,'director':PTaYpHwtWAObDeSiolKCvNFVjRGJqu,'genre':PTaYpHwtWAObDeSiolKCvNFVjRGJqr,'year':PTaYpHwtWAObDeSiolKCvNFVjRGJqh,'premiered':PTaYpHwtWAObDeSiolKCvNFVjRGJqc,'mpaa':PTaYpHwtWAObDeSiolKCvNFVjRGJqU,'plot':PTaYpHwtWAObDeSiolKCvNFVjRGJqd}
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd={'mode':'EPISODE','programcode':PTaYpHwtWAObDeSiolKCvNFVjRGJqz.get('program'),'page':'1'}
   if PTaYpHwtWAObDeSiolKCvNFVjRGJLX.get_settings_makebookmark():
    PTaYpHwtWAObDeSiolKCvNFVjRGJqn={'videoid':PTaYpHwtWAObDeSiolKCvNFVjRGJqz.get('program'),'vidtype':'tvshow','vtitle':PTaYpHwtWAObDeSiolKCvNFVjRGJdz,'vsubtitle':PTaYpHwtWAObDeSiolKCvNFVjRGJqf,}
    PTaYpHwtWAObDeSiolKCvNFVjRGJqg=json.dumps(PTaYpHwtWAObDeSiolKCvNFVjRGJqn)
    PTaYpHwtWAObDeSiolKCvNFVjRGJqg=urllib.parse.quote(PTaYpHwtWAObDeSiolKCvNFVjRGJqg)
    PTaYpHwtWAObDeSiolKCvNFVjRGJqI='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(PTaYpHwtWAObDeSiolKCvNFVjRGJqg)
    PTaYpHwtWAObDeSiolKCvNFVjRGJqs=[('(통합) 찜 영상에 추가',PTaYpHwtWAObDeSiolKCvNFVjRGJqI)]
   else:
    PTaYpHwtWAObDeSiolKCvNFVjRGJqs=PTaYpHwtWAObDeSiolKCvNFVjRGJhk
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.add_dir(PTaYpHwtWAObDeSiolKCvNFVjRGJdz,sublabel=PTaYpHwtWAObDeSiolKCvNFVjRGJqf,img=PTaYpHwtWAObDeSiolKCvNFVjRGJqL,infoLabels=PTaYpHwtWAObDeSiolKCvNFVjRGJqx,isFolder=PTaYpHwtWAObDeSiolKCvNFVjRGJUL,params=PTaYpHwtWAObDeSiolKCvNFVjRGJmd,ContextMenu=PTaYpHwtWAObDeSiolKCvNFVjRGJqs)
  if PTaYpHwtWAObDeSiolKCvNFVjRGJmk:
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd['mode'] ='PROGRAM' 
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd['stype'] =PTaYpHwtWAObDeSiolKCvNFVjRGJqX
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd['orderby'] =PTaYpHwtWAObDeSiolKCvNFVjRGJdy
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd['page'] =PTaYpHwtWAObDeSiolKCvNFVjRGJUh(PTaYpHwtWAObDeSiolKCvNFVjRGJmI+1)
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd['genreCode']=PTaYpHwtWAObDeSiolKCvNFVjRGJqy 
   PTaYpHwtWAObDeSiolKCvNFVjRGJdz='[B]%s >>[/B]'%'다음 페이지'
   PTaYpHwtWAObDeSiolKCvNFVjRGJqB=PTaYpHwtWAObDeSiolKCvNFVjRGJUh(PTaYpHwtWAObDeSiolKCvNFVjRGJmI+1)
   PTaYpHwtWAObDeSiolKCvNFVjRGJmL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.add_dir(PTaYpHwtWAObDeSiolKCvNFVjRGJdz,sublabel=PTaYpHwtWAObDeSiolKCvNFVjRGJqB,img=PTaYpHwtWAObDeSiolKCvNFVjRGJmL,infoLabels=PTaYpHwtWAObDeSiolKCvNFVjRGJhk,isFolder=PTaYpHwtWAObDeSiolKCvNFVjRGJUL,params=PTaYpHwtWAObDeSiolKCvNFVjRGJmd)
  xbmcplugin.setContent(PTaYpHwtWAObDeSiolKCvNFVjRGJLX._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(PTaYpHwtWAObDeSiolKCvNFVjRGJLX._addon_handle,cacheToDisc=PTaYpHwtWAObDeSiolKCvNFVjRGJUd)
 def dp_4K_Program_List(PTaYpHwtWAObDeSiolKCvNFVjRGJLX,PTaYpHwtWAObDeSiolKCvNFVjRGJmg):
  PTaYpHwtWAObDeSiolKCvNFVjRGJmI =PTaYpHwtWAObDeSiolKCvNFVjRGJhM(PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('page'))
  PTaYpHwtWAObDeSiolKCvNFVjRGJqQ,PTaYpHwtWAObDeSiolKCvNFVjRGJmk=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.Get_UHD_ProgramList(PTaYpHwtWAObDeSiolKCvNFVjRGJmI)
  for PTaYpHwtWAObDeSiolKCvNFVjRGJqz in PTaYpHwtWAObDeSiolKCvNFVjRGJqQ:
   PTaYpHwtWAObDeSiolKCvNFVjRGJdz =PTaYpHwtWAObDeSiolKCvNFVjRGJqz.get('title')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqL =PTaYpHwtWAObDeSiolKCvNFVjRGJqz.get('thumbnail')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqd =PTaYpHwtWAObDeSiolKCvNFVjRGJqz.get('synopsis')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqf =PTaYpHwtWAObDeSiolKCvNFVjRGJqz.get('channel')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqE =PTaYpHwtWAObDeSiolKCvNFVjRGJqz.get('cast')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqu =PTaYpHwtWAObDeSiolKCvNFVjRGJqz.get('director')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqr=PTaYpHwtWAObDeSiolKCvNFVjRGJqz.get('info_genre')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqh =PTaYpHwtWAObDeSiolKCvNFVjRGJqz.get('year')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqc =PTaYpHwtWAObDeSiolKCvNFVjRGJqz.get('premiered')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqU =PTaYpHwtWAObDeSiolKCvNFVjRGJqz.get('mpaa')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqx={'mediatype':'tvshow','title':PTaYpHwtWAObDeSiolKCvNFVjRGJdz,'studio':PTaYpHwtWAObDeSiolKCvNFVjRGJqf,'cast':PTaYpHwtWAObDeSiolKCvNFVjRGJqE,'director':PTaYpHwtWAObDeSiolKCvNFVjRGJqu,'genre':PTaYpHwtWAObDeSiolKCvNFVjRGJqr,'year':PTaYpHwtWAObDeSiolKCvNFVjRGJqh,'premiered':PTaYpHwtWAObDeSiolKCvNFVjRGJqc,'mpaa':PTaYpHwtWAObDeSiolKCvNFVjRGJqU,'plot':PTaYpHwtWAObDeSiolKCvNFVjRGJqd}
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd={'mode':'EPISODE','programcode':PTaYpHwtWAObDeSiolKCvNFVjRGJqz.get('program'),'page':'1'}
   if PTaYpHwtWAObDeSiolKCvNFVjRGJLX.get_settings_makebookmark():
    PTaYpHwtWAObDeSiolKCvNFVjRGJqn={'videoid':PTaYpHwtWAObDeSiolKCvNFVjRGJqz.get('program'),'vidtype':'tvshow','vtitle':PTaYpHwtWAObDeSiolKCvNFVjRGJdz,'vsubtitle':PTaYpHwtWAObDeSiolKCvNFVjRGJqf,}
    PTaYpHwtWAObDeSiolKCvNFVjRGJqg=json.dumps(PTaYpHwtWAObDeSiolKCvNFVjRGJqn)
    PTaYpHwtWAObDeSiolKCvNFVjRGJqg=urllib.parse.quote(PTaYpHwtWAObDeSiolKCvNFVjRGJqg)
    PTaYpHwtWAObDeSiolKCvNFVjRGJqI='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(PTaYpHwtWAObDeSiolKCvNFVjRGJqg)
    PTaYpHwtWAObDeSiolKCvNFVjRGJqs=[('(통합) 찜 영상에 추가',PTaYpHwtWAObDeSiolKCvNFVjRGJqI)]
   else:
    PTaYpHwtWAObDeSiolKCvNFVjRGJqs=PTaYpHwtWAObDeSiolKCvNFVjRGJhk
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.add_dir(PTaYpHwtWAObDeSiolKCvNFVjRGJdz,sublabel=PTaYpHwtWAObDeSiolKCvNFVjRGJqf,img=PTaYpHwtWAObDeSiolKCvNFVjRGJqL,infoLabels=PTaYpHwtWAObDeSiolKCvNFVjRGJqx,isFolder=PTaYpHwtWAObDeSiolKCvNFVjRGJUL,params=PTaYpHwtWAObDeSiolKCvNFVjRGJmd,ContextMenu=PTaYpHwtWAObDeSiolKCvNFVjRGJqs)
  if PTaYpHwtWAObDeSiolKCvNFVjRGJmk:
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd['mode'] ='4K_PROGRAM' 
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd['page'] =PTaYpHwtWAObDeSiolKCvNFVjRGJUh(PTaYpHwtWAObDeSiolKCvNFVjRGJmI+1)
   PTaYpHwtWAObDeSiolKCvNFVjRGJdz='[B]%s >>[/B]'%'다음 페이지'
   PTaYpHwtWAObDeSiolKCvNFVjRGJqB=PTaYpHwtWAObDeSiolKCvNFVjRGJUh(PTaYpHwtWAObDeSiolKCvNFVjRGJmI+1)
   PTaYpHwtWAObDeSiolKCvNFVjRGJmL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.add_dir(PTaYpHwtWAObDeSiolKCvNFVjRGJdz,sublabel=PTaYpHwtWAObDeSiolKCvNFVjRGJqB,img=PTaYpHwtWAObDeSiolKCvNFVjRGJmL,infoLabels=PTaYpHwtWAObDeSiolKCvNFVjRGJhk,isFolder=PTaYpHwtWAObDeSiolKCvNFVjRGJUL,params=PTaYpHwtWAObDeSiolKCvNFVjRGJmd)
  xbmcplugin.setContent(PTaYpHwtWAObDeSiolKCvNFVjRGJLX._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(PTaYpHwtWAObDeSiolKCvNFVjRGJLX._addon_handle,cacheToDisc=PTaYpHwtWAObDeSiolKCvNFVjRGJUd)
 def dp_Ori_Program_List(PTaYpHwtWAObDeSiolKCvNFVjRGJLX,PTaYpHwtWAObDeSiolKCvNFVjRGJmg):
  PTaYpHwtWAObDeSiolKCvNFVjRGJmI =PTaYpHwtWAObDeSiolKCvNFVjRGJhM(PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('page'))
  PTaYpHwtWAObDeSiolKCvNFVjRGJqQ,PTaYpHwtWAObDeSiolKCvNFVjRGJmk=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.Get_Origianl_ProgramList(PTaYpHwtWAObDeSiolKCvNFVjRGJmI)
  for PTaYpHwtWAObDeSiolKCvNFVjRGJqz in PTaYpHwtWAObDeSiolKCvNFVjRGJqQ:
   PTaYpHwtWAObDeSiolKCvNFVjRGJdz =PTaYpHwtWAObDeSiolKCvNFVjRGJqz.get('title')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqL =PTaYpHwtWAObDeSiolKCvNFVjRGJqz.get('thumbnail')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqM =PTaYpHwtWAObDeSiolKCvNFVjRGJqz.get('vod_type')
   PTaYpHwtWAObDeSiolKCvNFVjRGJEL =PTaYpHwtWAObDeSiolKCvNFVjRGJqz.get('vod_code')
   if PTaYpHwtWAObDeSiolKCvNFVjRGJqM=='vod':
    PTaYpHwtWAObDeSiolKCvNFVjRGJqx={'mediatype':'tvshow','title':PTaYpHwtWAObDeSiolKCvNFVjRGJdz,}
    PTaYpHwtWAObDeSiolKCvNFVjRGJmd={'mode':'EPISODE','programcode':PTaYpHwtWAObDeSiolKCvNFVjRGJEL,'page':'1',}
    PTaYpHwtWAObDeSiolKCvNFVjRGJmq=PTaYpHwtWAObDeSiolKCvNFVjRGJUL
   else:
    PTaYpHwtWAObDeSiolKCvNFVjRGJqx={'mediatype':'movie','title':PTaYpHwtWAObDeSiolKCvNFVjRGJdz,'plot':'movie',}
    PTaYpHwtWAObDeSiolKCvNFVjRGJmd={'mode':'MOVIE','mediacode':PTaYpHwtWAObDeSiolKCvNFVjRGJEL,'stype':'movie','title':PTaYpHwtWAObDeSiolKCvNFVjRGJdz,'thumbnail':PTaYpHwtWAObDeSiolKCvNFVjRGJqL,}
    PTaYpHwtWAObDeSiolKCvNFVjRGJmq=PTaYpHwtWAObDeSiolKCvNFVjRGJUd
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.add_dir(PTaYpHwtWAObDeSiolKCvNFVjRGJdz,sublabel=PTaYpHwtWAObDeSiolKCvNFVjRGJhk,img=PTaYpHwtWAObDeSiolKCvNFVjRGJqL,infoLabels=PTaYpHwtWAObDeSiolKCvNFVjRGJqx,isFolder=PTaYpHwtWAObDeSiolKCvNFVjRGJmq,params=PTaYpHwtWAObDeSiolKCvNFVjRGJmd,ContextMenu=PTaYpHwtWAObDeSiolKCvNFVjRGJhk)
  if PTaYpHwtWAObDeSiolKCvNFVjRGJmk:
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd['mode'] ='ORI_PROGRAM' 
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd['page'] =PTaYpHwtWAObDeSiolKCvNFVjRGJUh(PTaYpHwtWAObDeSiolKCvNFVjRGJmI+1)
   PTaYpHwtWAObDeSiolKCvNFVjRGJdz='[B]%s >>[/B]'%'다음 페이지'
   PTaYpHwtWAObDeSiolKCvNFVjRGJqB=PTaYpHwtWAObDeSiolKCvNFVjRGJUh(PTaYpHwtWAObDeSiolKCvNFVjRGJmI+1)
   PTaYpHwtWAObDeSiolKCvNFVjRGJmL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.add_dir(PTaYpHwtWAObDeSiolKCvNFVjRGJdz,sublabel=PTaYpHwtWAObDeSiolKCvNFVjRGJqB,img=PTaYpHwtWAObDeSiolKCvNFVjRGJmL,infoLabels=PTaYpHwtWAObDeSiolKCvNFVjRGJhk,isFolder=PTaYpHwtWAObDeSiolKCvNFVjRGJUL,params=PTaYpHwtWAObDeSiolKCvNFVjRGJmd)
  xbmcplugin.setContent(PTaYpHwtWAObDeSiolKCvNFVjRGJLX._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(PTaYpHwtWAObDeSiolKCvNFVjRGJLX._addon_handle,cacheToDisc=PTaYpHwtWAObDeSiolKCvNFVjRGJUd)
 def dp_Episode_List(PTaYpHwtWAObDeSiolKCvNFVjRGJLX,PTaYpHwtWAObDeSiolKCvNFVjRGJmg):
  PTaYpHwtWAObDeSiolKCvNFVjRGJEd=PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('programcode')
  PTaYpHwtWAObDeSiolKCvNFVjRGJmI =PTaYpHwtWAObDeSiolKCvNFVjRGJhM(PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('page'))
  PTaYpHwtWAObDeSiolKCvNFVjRGJEm,PTaYpHwtWAObDeSiolKCvNFVjRGJmk,PTaYpHwtWAObDeSiolKCvNFVjRGJEq=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.GetEpisodeList(PTaYpHwtWAObDeSiolKCvNFVjRGJEd,PTaYpHwtWAObDeSiolKCvNFVjRGJmI,orderby=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.get_winEpisodeOrderby())
  for PTaYpHwtWAObDeSiolKCvNFVjRGJEu in PTaYpHwtWAObDeSiolKCvNFVjRGJEm:
   PTaYpHwtWAObDeSiolKCvNFVjRGJdz =PTaYpHwtWAObDeSiolKCvNFVjRGJEu.get('title')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqB =PTaYpHwtWAObDeSiolKCvNFVjRGJEu.get('subtitle')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqL =PTaYpHwtWAObDeSiolKCvNFVjRGJEu.get('thumbnail')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqd =PTaYpHwtWAObDeSiolKCvNFVjRGJEu.get('synopsis')
   PTaYpHwtWAObDeSiolKCvNFVjRGJEr=PTaYpHwtWAObDeSiolKCvNFVjRGJEu.get('info_title')
   PTaYpHwtWAObDeSiolKCvNFVjRGJEh =PTaYpHwtWAObDeSiolKCvNFVjRGJEu.get('aired')
   PTaYpHwtWAObDeSiolKCvNFVjRGJEU =PTaYpHwtWAObDeSiolKCvNFVjRGJEu.get('studio')
   PTaYpHwtWAObDeSiolKCvNFVjRGJEc =PTaYpHwtWAObDeSiolKCvNFVjRGJEu.get('frequency')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqx={'mediatype':'episode','title':PTaYpHwtWAObDeSiolKCvNFVjRGJEr,'aired':PTaYpHwtWAObDeSiolKCvNFVjRGJEh,'studio':PTaYpHwtWAObDeSiolKCvNFVjRGJEU,'episode':PTaYpHwtWAObDeSiolKCvNFVjRGJEc,'plot':PTaYpHwtWAObDeSiolKCvNFVjRGJqd}
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd={'mode':'VOD','mediacode':PTaYpHwtWAObDeSiolKCvNFVjRGJEu.get('episode'),'stype':'vod','programcode':PTaYpHwtWAObDeSiolKCvNFVjRGJEd,'title':PTaYpHwtWAObDeSiolKCvNFVjRGJdz,'thumbnail':PTaYpHwtWAObDeSiolKCvNFVjRGJqL}
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.add_dir(PTaYpHwtWAObDeSiolKCvNFVjRGJdz,sublabel=PTaYpHwtWAObDeSiolKCvNFVjRGJqB,img=PTaYpHwtWAObDeSiolKCvNFVjRGJqL,infoLabels=PTaYpHwtWAObDeSiolKCvNFVjRGJqx,isFolder=PTaYpHwtWAObDeSiolKCvNFVjRGJUd,params=PTaYpHwtWAObDeSiolKCvNFVjRGJmd)
  if PTaYpHwtWAObDeSiolKCvNFVjRGJmI==1:
   PTaYpHwtWAObDeSiolKCvNFVjRGJqx={'plot':'정렬순서를 변경합니다.'}
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd={}
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd['mode'] ='ORDER_BY' 
   if PTaYpHwtWAObDeSiolKCvNFVjRGJLX.get_winEpisodeOrderby()=='desc':
    PTaYpHwtWAObDeSiolKCvNFVjRGJdz='정렬순서변경 : 최신화부터 -> 1회부터'
    PTaYpHwtWAObDeSiolKCvNFVjRGJmd['orderby']='asc'
   else:
    PTaYpHwtWAObDeSiolKCvNFVjRGJdz='정렬순서변경 : 1회부터 -> 최신화부터'
    PTaYpHwtWAObDeSiolKCvNFVjRGJmd['orderby']='desc'
   PTaYpHwtWAObDeSiolKCvNFVjRGJmL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.add_dir(PTaYpHwtWAObDeSiolKCvNFVjRGJdz,sublabel='',img=PTaYpHwtWAObDeSiolKCvNFVjRGJmL,infoLabels=PTaYpHwtWAObDeSiolKCvNFVjRGJqx,isFolder=PTaYpHwtWAObDeSiolKCvNFVjRGJUd,params=PTaYpHwtWAObDeSiolKCvNFVjRGJmd,isLink=PTaYpHwtWAObDeSiolKCvNFVjRGJUL)
  if PTaYpHwtWAObDeSiolKCvNFVjRGJmk:
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd['mode'] ='EPISODE' 
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd['programcode']=PTaYpHwtWAObDeSiolKCvNFVjRGJEd
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd['page'] =PTaYpHwtWAObDeSiolKCvNFVjRGJUh(PTaYpHwtWAObDeSiolKCvNFVjRGJmI+1)
   PTaYpHwtWAObDeSiolKCvNFVjRGJdz='[B]%s >>[/B]'%'다음 페이지'
   PTaYpHwtWAObDeSiolKCvNFVjRGJqB=PTaYpHwtWAObDeSiolKCvNFVjRGJUh(PTaYpHwtWAObDeSiolKCvNFVjRGJmI+1)
   PTaYpHwtWAObDeSiolKCvNFVjRGJmL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.add_dir(PTaYpHwtWAObDeSiolKCvNFVjRGJdz,sublabel=PTaYpHwtWAObDeSiolKCvNFVjRGJqB,img=PTaYpHwtWAObDeSiolKCvNFVjRGJmL,infoLabels=PTaYpHwtWAObDeSiolKCvNFVjRGJhk,isFolder=PTaYpHwtWAObDeSiolKCvNFVjRGJUL,params=PTaYpHwtWAObDeSiolKCvNFVjRGJmd)
  xbmcplugin.setContent(PTaYpHwtWAObDeSiolKCvNFVjRGJLX._addon_handle,'episodes')
  if PTaYpHwtWAObDeSiolKCvNFVjRGJUr(PTaYpHwtWAObDeSiolKCvNFVjRGJEm)>0:xbmcplugin.endOfDirectory(PTaYpHwtWAObDeSiolKCvNFVjRGJLX._addon_handle,cacheToDisc=PTaYpHwtWAObDeSiolKCvNFVjRGJUL)
 def dp_setEpOrderby(PTaYpHwtWAObDeSiolKCvNFVjRGJLX,PTaYpHwtWAObDeSiolKCvNFVjRGJmg):
  PTaYpHwtWAObDeSiolKCvNFVjRGJdy =PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('orderby')
  PTaYpHwtWAObDeSiolKCvNFVjRGJLX.set_winEpisodeOrderby(PTaYpHwtWAObDeSiolKCvNFVjRGJdy)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(PTaYpHwtWAObDeSiolKCvNFVjRGJLX,PTaYpHwtWAObDeSiolKCvNFVjRGJmg):
  PTaYpHwtWAObDeSiolKCvNFVjRGJqX =PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('stype')
  PTaYpHwtWAObDeSiolKCvNFVjRGJdy =PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('orderby')
  PTaYpHwtWAObDeSiolKCvNFVjRGJmI=PTaYpHwtWAObDeSiolKCvNFVjRGJhM(PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('page'))
  PTaYpHwtWAObDeSiolKCvNFVjRGJEx,PTaYpHwtWAObDeSiolKCvNFVjRGJmk=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.GetMovieList(PTaYpHwtWAObDeSiolKCvNFVjRGJqX,PTaYpHwtWAObDeSiolKCvNFVjRGJdy,PTaYpHwtWAObDeSiolKCvNFVjRGJmI)
  for PTaYpHwtWAObDeSiolKCvNFVjRGJEB in PTaYpHwtWAObDeSiolKCvNFVjRGJEx:
   PTaYpHwtWAObDeSiolKCvNFVjRGJdz =PTaYpHwtWAObDeSiolKCvNFVjRGJEB.get('title')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqL =PTaYpHwtWAObDeSiolKCvNFVjRGJEB.get('thumbnail')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqd =PTaYpHwtWAObDeSiolKCvNFVjRGJEB.get('synopsis')
   PTaYpHwtWAObDeSiolKCvNFVjRGJEr =PTaYpHwtWAObDeSiolKCvNFVjRGJEB.get('info_title')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqh =PTaYpHwtWAObDeSiolKCvNFVjRGJEB.get('year')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqE =PTaYpHwtWAObDeSiolKCvNFVjRGJEB.get('cast')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqu =PTaYpHwtWAObDeSiolKCvNFVjRGJEB.get('director')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqr =PTaYpHwtWAObDeSiolKCvNFVjRGJEB.get('info_genre')
   PTaYpHwtWAObDeSiolKCvNFVjRGJEX =PTaYpHwtWAObDeSiolKCvNFVjRGJEB.get('duration')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqc =PTaYpHwtWAObDeSiolKCvNFVjRGJEB.get('premiered')
   PTaYpHwtWAObDeSiolKCvNFVjRGJEU =PTaYpHwtWAObDeSiolKCvNFVjRGJEB.get('studio')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqU =PTaYpHwtWAObDeSiolKCvNFVjRGJEB.get('mpaa')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqx={'mediatype':'movie','title':PTaYpHwtWAObDeSiolKCvNFVjRGJEr,'year':PTaYpHwtWAObDeSiolKCvNFVjRGJqh,'cast':PTaYpHwtWAObDeSiolKCvNFVjRGJqE,'director':PTaYpHwtWAObDeSiolKCvNFVjRGJqu,'genre':PTaYpHwtWAObDeSiolKCvNFVjRGJqr,'duration':PTaYpHwtWAObDeSiolKCvNFVjRGJEX,'premiered':PTaYpHwtWAObDeSiolKCvNFVjRGJqc,'studio':PTaYpHwtWAObDeSiolKCvNFVjRGJEU,'mpaa':PTaYpHwtWAObDeSiolKCvNFVjRGJqU,'plot':PTaYpHwtWAObDeSiolKCvNFVjRGJqd}
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd={'mode':'MOVIE','mediacode':PTaYpHwtWAObDeSiolKCvNFVjRGJEB.get('moviecode'),'stype':'movie','title':PTaYpHwtWAObDeSiolKCvNFVjRGJdz,'thumbnail':PTaYpHwtWAObDeSiolKCvNFVjRGJqL}
   if PTaYpHwtWAObDeSiolKCvNFVjRGJLX.get_settings_makebookmark():
    PTaYpHwtWAObDeSiolKCvNFVjRGJqn={'videoid':PTaYpHwtWAObDeSiolKCvNFVjRGJEB.get('moviecode'),'vidtype':'movie','vtitle':PTaYpHwtWAObDeSiolKCvNFVjRGJEr,'vsubtitle':'',}
    PTaYpHwtWAObDeSiolKCvNFVjRGJqg=json.dumps(PTaYpHwtWAObDeSiolKCvNFVjRGJqn)
    PTaYpHwtWAObDeSiolKCvNFVjRGJqg=urllib.parse.quote(PTaYpHwtWAObDeSiolKCvNFVjRGJqg)
    PTaYpHwtWAObDeSiolKCvNFVjRGJqI='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(PTaYpHwtWAObDeSiolKCvNFVjRGJqg)
    PTaYpHwtWAObDeSiolKCvNFVjRGJqs=[('(통합) 찜 영상에 추가',PTaYpHwtWAObDeSiolKCvNFVjRGJqI)]
   else:
    PTaYpHwtWAObDeSiolKCvNFVjRGJqs=PTaYpHwtWAObDeSiolKCvNFVjRGJhk
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.add_dir(PTaYpHwtWAObDeSiolKCvNFVjRGJdz,sublabel='',img=PTaYpHwtWAObDeSiolKCvNFVjRGJqL,infoLabels=PTaYpHwtWAObDeSiolKCvNFVjRGJqx,isFolder=PTaYpHwtWAObDeSiolKCvNFVjRGJUd,params=PTaYpHwtWAObDeSiolKCvNFVjRGJmd,ContextMenu=PTaYpHwtWAObDeSiolKCvNFVjRGJqs)
  if PTaYpHwtWAObDeSiolKCvNFVjRGJmk:
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd={}
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd['mode'] ='MOVIE_SUB' 
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd['orderby']=PTaYpHwtWAObDeSiolKCvNFVjRGJdy
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd['stype'] =PTaYpHwtWAObDeSiolKCvNFVjRGJqX
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd['page'] =PTaYpHwtWAObDeSiolKCvNFVjRGJUh(PTaYpHwtWAObDeSiolKCvNFVjRGJmI+1)
   PTaYpHwtWAObDeSiolKCvNFVjRGJdz='[B]%s >>[/B]'%'다음 페이지'
   PTaYpHwtWAObDeSiolKCvNFVjRGJqB=PTaYpHwtWAObDeSiolKCvNFVjRGJUh(PTaYpHwtWAObDeSiolKCvNFVjRGJmI+1)
   PTaYpHwtWAObDeSiolKCvNFVjRGJmL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.add_dir(PTaYpHwtWAObDeSiolKCvNFVjRGJdz,sublabel=PTaYpHwtWAObDeSiolKCvNFVjRGJqB,img=PTaYpHwtWAObDeSiolKCvNFVjRGJmL,infoLabels=PTaYpHwtWAObDeSiolKCvNFVjRGJhk,isFolder=PTaYpHwtWAObDeSiolKCvNFVjRGJUL,params=PTaYpHwtWAObDeSiolKCvNFVjRGJmd)
  xbmcplugin.setContent(PTaYpHwtWAObDeSiolKCvNFVjRGJLX._addon_handle,'movies')
  xbmcplugin.endOfDirectory(PTaYpHwtWAObDeSiolKCvNFVjRGJLX._addon_handle,cacheToDisc=PTaYpHwtWAObDeSiolKCvNFVjRGJUd)
 def dp_4K_Movie_List(PTaYpHwtWAObDeSiolKCvNFVjRGJLX,PTaYpHwtWAObDeSiolKCvNFVjRGJmg):
  PTaYpHwtWAObDeSiolKCvNFVjRGJmI=PTaYpHwtWAObDeSiolKCvNFVjRGJhM(PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('page'))
  PTaYpHwtWAObDeSiolKCvNFVjRGJEx,PTaYpHwtWAObDeSiolKCvNFVjRGJmk=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.Get_UHD_MovieList(PTaYpHwtWAObDeSiolKCvNFVjRGJmI)
  for PTaYpHwtWAObDeSiolKCvNFVjRGJEB in PTaYpHwtWAObDeSiolKCvNFVjRGJEx:
   PTaYpHwtWAObDeSiolKCvNFVjRGJdz =PTaYpHwtWAObDeSiolKCvNFVjRGJEB.get('title')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqL =PTaYpHwtWAObDeSiolKCvNFVjRGJEB.get('thumbnail')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqd =PTaYpHwtWAObDeSiolKCvNFVjRGJEB.get('synopsis')
   PTaYpHwtWAObDeSiolKCvNFVjRGJEr =PTaYpHwtWAObDeSiolKCvNFVjRGJEB.get('info_title')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqh =PTaYpHwtWAObDeSiolKCvNFVjRGJEB.get('year')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqE =PTaYpHwtWAObDeSiolKCvNFVjRGJEB.get('cast')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqu =PTaYpHwtWAObDeSiolKCvNFVjRGJEB.get('director')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqr =PTaYpHwtWAObDeSiolKCvNFVjRGJEB.get('info_genre')
   PTaYpHwtWAObDeSiolKCvNFVjRGJEX =PTaYpHwtWAObDeSiolKCvNFVjRGJEB.get('duration')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqc =PTaYpHwtWAObDeSiolKCvNFVjRGJEB.get('premiered')
   PTaYpHwtWAObDeSiolKCvNFVjRGJEU =PTaYpHwtWAObDeSiolKCvNFVjRGJEB.get('studio')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqU =PTaYpHwtWAObDeSiolKCvNFVjRGJEB.get('mpaa')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqx={'mediatype':'movie','title':PTaYpHwtWAObDeSiolKCvNFVjRGJEr,'year':PTaYpHwtWAObDeSiolKCvNFVjRGJqh,'cast':PTaYpHwtWAObDeSiolKCvNFVjRGJqE,'director':PTaYpHwtWAObDeSiolKCvNFVjRGJqu,'genre':PTaYpHwtWAObDeSiolKCvNFVjRGJqr,'duration':PTaYpHwtWAObDeSiolKCvNFVjRGJEX,'premiered':PTaYpHwtWAObDeSiolKCvNFVjRGJqc,'studio':PTaYpHwtWAObDeSiolKCvNFVjRGJEU,'mpaa':PTaYpHwtWAObDeSiolKCvNFVjRGJqU,'plot':PTaYpHwtWAObDeSiolKCvNFVjRGJqd}
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd={'mode':'MOVIE','mediacode':PTaYpHwtWAObDeSiolKCvNFVjRGJEB.get('moviecode'),'stype':'movie','title':PTaYpHwtWAObDeSiolKCvNFVjRGJdz,'thumbnail':PTaYpHwtWAObDeSiolKCvNFVjRGJqL}
   if PTaYpHwtWAObDeSiolKCvNFVjRGJLX.get_settings_makebookmark():
    PTaYpHwtWAObDeSiolKCvNFVjRGJqn={'videoid':PTaYpHwtWAObDeSiolKCvNFVjRGJEB.get('moviecode'),'vidtype':'movie','vtitle':PTaYpHwtWAObDeSiolKCvNFVjRGJEr,'vsubtitle':'',}
    PTaYpHwtWAObDeSiolKCvNFVjRGJqg=json.dumps(PTaYpHwtWAObDeSiolKCvNFVjRGJqn)
    PTaYpHwtWAObDeSiolKCvNFVjRGJqg=urllib.parse.quote(PTaYpHwtWAObDeSiolKCvNFVjRGJqg)
    PTaYpHwtWAObDeSiolKCvNFVjRGJqI='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(PTaYpHwtWAObDeSiolKCvNFVjRGJqg)
    PTaYpHwtWAObDeSiolKCvNFVjRGJqs=[('(통합) 찜 영상에 추가',PTaYpHwtWAObDeSiolKCvNFVjRGJqI)]
   else:
    PTaYpHwtWAObDeSiolKCvNFVjRGJqs=PTaYpHwtWAObDeSiolKCvNFVjRGJhk
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.add_dir(PTaYpHwtWAObDeSiolKCvNFVjRGJdz,sublabel='',img=PTaYpHwtWAObDeSiolKCvNFVjRGJqL,infoLabels=PTaYpHwtWAObDeSiolKCvNFVjRGJqx,isFolder=PTaYpHwtWAObDeSiolKCvNFVjRGJUd,params=PTaYpHwtWAObDeSiolKCvNFVjRGJmd,ContextMenu=PTaYpHwtWAObDeSiolKCvNFVjRGJqs)
  if PTaYpHwtWAObDeSiolKCvNFVjRGJmk:
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd={}
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd['mode'] ='4K_MOVIE' 
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd['page'] =PTaYpHwtWAObDeSiolKCvNFVjRGJUh(PTaYpHwtWAObDeSiolKCvNFVjRGJmI+1)
   PTaYpHwtWAObDeSiolKCvNFVjRGJdz='[B]%s >>[/B]'%'다음 페이지'
   PTaYpHwtWAObDeSiolKCvNFVjRGJqB=PTaYpHwtWAObDeSiolKCvNFVjRGJUh(PTaYpHwtWAObDeSiolKCvNFVjRGJmI+1)
   PTaYpHwtWAObDeSiolKCvNFVjRGJmL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.add_dir(PTaYpHwtWAObDeSiolKCvNFVjRGJdz,sublabel=PTaYpHwtWAObDeSiolKCvNFVjRGJqB,img=PTaYpHwtWAObDeSiolKCvNFVjRGJmL,infoLabels=PTaYpHwtWAObDeSiolKCvNFVjRGJhk,isFolder=PTaYpHwtWAObDeSiolKCvNFVjRGJUL,params=PTaYpHwtWAObDeSiolKCvNFVjRGJmd)
  xbmcplugin.setContent(PTaYpHwtWAObDeSiolKCvNFVjRGJLX._addon_handle,'movies')
  xbmcplugin.endOfDirectory(PTaYpHwtWAObDeSiolKCvNFVjRGJLX._addon_handle,cacheToDisc=PTaYpHwtWAObDeSiolKCvNFVjRGJUd)
 def dp_Set_Bookmark(PTaYpHwtWAObDeSiolKCvNFVjRGJLX,PTaYpHwtWAObDeSiolKCvNFVjRGJmg):
  PTaYpHwtWAObDeSiolKCvNFVjRGJEy=urllib.parse.unquote(PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('bm_param'))
  PTaYpHwtWAObDeSiolKCvNFVjRGJEy=json.loads(PTaYpHwtWAObDeSiolKCvNFVjRGJEy)
  PTaYpHwtWAObDeSiolKCvNFVjRGJEQ =PTaYpHwtWAObDeSiolKCvNFVjRGJEy.get('videoid')
  PTaYpHwtWAObDeSiolKCvNFVjRGJEz =PTaYpHwtWAObDeSiolKCvNFVjRGJEy.get('vidtype')
  PTaYpHwtWAObDeSiolKCvNFVjRGJEf =PTaYpHwtWAObDeSiolKCvNFVjRGJEy.get('vtitle')
  PTaYpHwtWAObDeSiolKCvNFVjRGJEn =PTaYpHwtWAObDeSiolKCvNFVjRGJEy.get('vsubtitle')
  PTaYpHwtWAObDeSiolKCvNFVjRGJLn=xbmcgui.Dialog()
  PTaYpHwtWAObDeSiolKCvNFVjRGJmB=PTaYpHwtWAObDeSiolKCvNFVjRGJLn.yesno(__language__(30913).encode('utf8'),PTaYpHwtWAObDeSiolKCvNFVjRGJEf+' \n\n'+__language__(30914))
  if PTaYpHwtWAObDeSiolKCvNFVjRGJmB==PTaYpHwtWAObDeSiolKCvNFVjRGJUd:return
  PTaYpHwtWAObDeSiolKCvNFVjRGJEg=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.GetBookmarkInfo(PTaYpHwtWAObDeSiolKCvNFVjRGJEQ,PTaYpHwtWAObDeSiolKCvNFVjRGJEz)
  if PTaYpHwtWAObDeSiolKCvNFVjRGJEn!='':
   PTaYpHwtWAObDeSiolKCvNFVjRGJEg['saveinfo']['subtitle']=PTaYpHwtWAObDeSiolKCvNFVjRGJEn 
   if PTaYpHwtWAObDeSiolKCvNFVjRGJEz=='tvshow':PTaYpHwtWAObDeSiolKCvNFVjRGJEg['saveinfo']['infoLabels']['studio']=PTaYpHwtWAObDeSiolKCvNFVjRGJEn 
  PTaYpHwtWAObDeSiolKCvNFVjRGJEI=json.dumps(PTaYpHwtWAObDeSiolKCvNFVjRGJEg)
  PTaYpHwtWAObDeSiolKCvNFVjRGJEI=urllib.parse.quote(PTaYpHwtWAObDeSiolKCvNFVjRGJEI)
  PTaYpHwtWAObDeSiolKCvNFVjRGJqI ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(PTaYpHwtWAObDeSiolKCvNFVjRGJEI)
  xbmc.executebuiltin(PTaYpHwtWAObDeSiolKCvNFVjRGJqI)
 def dp_Search_Group(PTaYpHwtWAObDeSiolKCvNFVjRGJLX,PTaYpHwtWAObDeSiolKCvNFVjRGJmg):
  if 'search_key' in PTaYpHwtWAObDeSiolKCvNFVjRGJmg:
   PTaYpHwtWAObDeSiolKCvNFVjRGJEs=PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('search_key')
  else:
   PTaYpHwtWAObDeSiolKCvNFVjRGJEs=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not PTaYpHwtWAObDeSiolKCvNFVjRGJEs:
    return
  for PTaYpHwtWAObDeSiolKCvNFVjRGJmn in PTaYpHwtWAObDeSiolKCvNFVjRGJLu:
   PTaYpHwtWAObDeSiolKCvNFVjRGJEk =PTaYpHwtWAObDeSiolKCvNFVjRGJmn.get('mode')
   PTaYpHwtWAObDeSiolKCvNFVjRGJmz=PTaYpHwtWAObDeSiolKCvNFVjRGJmn.get('stype')
   PTaYpHwtWAObDeSiolKCvNFVjRGJdz=PTaYpHwtWAObDeSiolKCvNFVjRGJmn.get('title')
   (PTaYpHwtWAObDeSiolKCvNFVjRGJEM,PTaYpHwtWAObDeSiolKCvNFVjRGJmk)=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.GetSearchList(PTaYpHwtWAObDeSiolKCvNFVjRGJEs,1,PTaYpHwtWAObDeSiolKCvNFVjRGJmz)
   PTaYpHwtWAObDeSiolKCvNFVjRGJmu={'plot':'검색어 : '+PTaYpHwtWAObDeSiolKCvNFVjRGJEs+'\n\n'+PTaYpHwtWAObDeSiolKCvNFVjRGJLX.Search_FreeList(PTaYpHwtWAObDeSiolKCvNFVjRGJEM)}
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd={'mode':PTaYpHwtWAObDeSiolKCvNFVjRGJEk,'stype':PTaYpHwtWAObDeSiolKCvNFVjRGJmz,'search_key':PTaYpHwtWAObDeSiolKCvNFVjRGJEs,'page':'1',}
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.add_dir(PTaYpHwtWAObDeSiolKCvNFVjRGJdz,sublabel='',img='',infoLabels=PTaYpHwtWAObDeSiolKCvNFVjRGJmu,isFolder=PTaYpHwtWAObDeSiolKCvNFVjRGJUL,params=PTaYpHwtWAObDeSiolKCvNFVjRGJmd)
  if PTaYpHwtWAObDeSiolKCvNFVjRGJUr(PTaYpHwtWAObDeSiolKCvNFVjRGJLu)>0:xbmcplugin.endOfDirectory(PTaYpHwtWAObDeSiolKCvNFVjRGJLX._addon_handle,cacheToDisc=PTaYpHwtWAObDeSiolKCvNFVjRGJUL)
  PTaYpHwtWAObDeSiolKCvNFVjRGJLX.Save_Searched_List(PTaYpHwtWAObDeSiolKCvNFVjRGJEs)
 def Search_FreeList(PTaYpHwtWAObDeSiolKCvNFVjRGJLX,PTaYpHwtWAObDeSiolKCvNFVjRGJuc):
  PTaYpHwtWAObDeSiolKCvNFVjRGJuL=''
  PTaYpHwtWAObDeSiolKCvNFVjRGJud=7
  try:
   if PTaYpHwtWAObDeSiolKCvNFVjRGJUr(PTaYpHwtWAObDeSiolKCvNFVjRGJuc)==0:return '검색결과 없음'
   for i in PTaYpHwtWAObDeSiolKCvNFVjRGJUc(PTaYpHwtWAObDeSiolKCvNFVjRGJUr(PTaYpHwtWAObDeSiolKCvNFVjRGJuc)):
    if i>=PTaYpHwtWAObDeSiolKCvNFVjRGJud:
     PTaYpHwtWAObDeSiolKCvNFVjRGJuL=PTaYpHwtWAObDeSiolKCvNFVjRGJuL+'...'
     break
    PTaYpHwtWAObDeSiolKCvNFVjRGJuL=PTaYpHwtWAObDeSiolKCvNFVjRGJuL+PTaYpHwtWAObDeSiolKCvNFVjRGJuc[i]['title']+'\n'
  except:
   return ''
  return PTaYpHwtWAObDeSiolKCvNFVjRGJuL
 def dp_Search_History(PTaYpHwtWAObDeSiolKCvNFVjRGJLX,PTaYpHwtWAObDeSiolKCvNFVjRGJmg):
  PTaYpHwtWAObDeSiolKCvNFVjRGJum=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.Load_List_File('search')
  for PTaYpHwtWAObDeSiolKCvNFVjRGJuq in PTaYpHwtWAObDeSiolKCvNFVjRGJum:
   PTaYpHwtWAObDeSiolKCvNFVjRGJuE=PTaYpHwtWAObDeSiolKCvNFVjRGJUq(urllib.parse.parse_qsl(PTaYpHwtWAObDeSiolKCvNFVjRGJuq))
   PTaYpHwtWAObDeSiolKCvNFVjRGJur=PTaYpHwtWAObDeSiolKCvNFVjRGJuE.get('skey').strip()
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd={'mode':'SEARCH_GROUP','search_key':PTaYpHwtWAObDeSiolKCvNFVjRGJur,}
   PTaYpHwtWAObDeSiolKCvNFVjRGJuh={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':PTaYpHwtWAObDeSiolKCvNFVjRGJur,'vType':'-',}
   PTaYpHwtWAObDeSiolKCvNFVjRGJuU=urllib.parse.urlencode(PTaYpHwtWAObDeSiolKCvNFVjRGJuh)
   PTaYpHwtWAObDeSiolKCvNFVjRGJqs=[('선택된 검색어 ( %s ) 삭제'%(PTaYpHwtWAObDeSiolKCvNFVjRGJur),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(PTaYpHwtWAObDeSiolKCvNFVjRGJuU))]
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.add_dir(PTaYpHwtWAObDeSiolKCvNFVjRGJur,sublabel='',img=PTaYpHwtWAObDeSiolKCvNFVjRGJhk,infoLabels=PTaYpHwtWAObDeSiolKCvNFVjRGJhk,isFolder=PTaYpHwtWAObDeSiolKCvNFVjRGJUL,params=PTaYpHwtWAObDeSiolKCvNFVjRGJmd,ContextMenu=PTaYpHwtWAObDeSiolKCvNFVjRGJqs)
  PTaYpHwtWAObDeSiolKCvNFVjRGJqx={'plot':'검색목록 전체를 삭제합니다.'}
  PTaYpHwtWAObDeSiolKCvNFVjRGJdz='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  PTaYpHwtWAObDeSiolKCvNFVjRGJmd={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  PTaYpHwtWAObDeSiolKCvNFVjRGJmL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  PTaYpHwtWAObDeSiolKCvNFVjRGJLX.add_dir(PTaYpHwtWAObDeSiolKCvNFVjRGJdz,sublabel='',img=PTaYpHwtWAObDeSiolKCvNFVjRGJmL,infoLabels=PTaYpHwtWAObDeSiolKCvNFVjRGJqx,isFolder=PTaYpHwtWAObDeSiolKCvNFVjRGJUd,params=PTaYpHwtWAObDeSiolKCvNFVjRGJmd,isLink=PTaYpHwtWAObDeSiolKCvNFVjRGJUL)
  xbmcplugin.endOfDirectory(PTaYpHwtWAObDeSiolKCvNFVjRGJLX._addon_handle,cacheToDisc=PTaYpHwtWAObDeSiolKCvNFVjRGJUd)
 def dp_Search_List(PTaYpHwtWAObDeSiolKCvNFVjRGJLX,PTaYpHwtWAObDeSiolKCvNFVjRGJmg):
  PTaYpHwtWAObDeSiolKCvNFVjRGJmI =PTaYpHwtWAObDeSiolKCvNFVjRGJhM(PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('page'))
  PTaYpHwtWAObDeSiolKCvNFVjRGJmz =PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('stype')
  if 'search_key' in PTaYpHwtWAObDeSiolKCvNFVjRGJmg:
   PTaYpHwtWAObDeSiolKCvNFVjRGJEs=PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('search_key')
  else:
   PTaYpHwtWAObDeSiolKCvNFVjRGJEs=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not PTaYpHwtWAObDeSiolKCvNFVjRGJEs:
    xbmcplugin.endOfDirectory(PTaYpHwtWAObDeSiolKCvNFVjRGJLX._addon_handle)
    return
  PTaYpHwtWAObDeSiolKCvNFVjRGJEM,PTaYpHwtWAObDeSiolKCvNFVjRGJmk=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.GetSearchList(PTaYpHwtWAObDeSiolKCvNFVjRGJEs,PTaYpHwtWAObDeSiolKCvNFVjRGJmI,PTaYpHwtWAObDeSiolKCvNFVjRGJmz)
  for PTaYpHwtWAObDeSiolKCvNFVjRGJuc in PTaYpHwtWAObDeSiolKCvNFVjRGJEM:
   PTaYpHwtWAObDeSiolKCvNFVjRGJdz =PTaYpHwtWAObDeSiolKCvNFVjRGJuc.get('title')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqL =PTaYpHwtWAObDeSiolKCvNFVjRGJuc.get('thumbnail')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqd =PTaYpHwtWAObDeSiolKCvNFVjRGJuc.get('synopsis')
   PTaYpHwtWAObDeSiolKCvNFVjRGJux =PTaYpHwtWAObDeSiolKCvNFVjRGJuc.get('program')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqE =PTaYpHwtWAObDeSiolKCvNFVjRGJuc.get('cast')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqu =PTaYpHwtWAObDeSiolKCvNFVjRGJuc.get('director')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqr=PTaYpHwtWAObDeSiolKCvNFVjRGJuc.get('info_genre')
   PTaYpHwtWAObDeSiolKCvNFVjRGJEX =PTaYpHwtWAObDeSiolKCvNFVjRGJuc.get('duration')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqU =PTaYpHwtWAObDeSiolKCvNFVjRGJuc.get('mpaa')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqh =PTaYpHwtWAObDeSiolKCvNFVjRGJuc.get('year')
   PTaYpHwtWAObDeSiolKCvNFVjRGJEh =PTaYpHwtWAObDeSiolKCvNFVjRGJuc.get('aired')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqx={'mediatype':'tvshow' if PTaYpHwtWAObDeSiolKCvNFVjRGJmz=='vod' else 'movie','title':PTaYpHwtWAObDeSiolKCvNFVjRGJdz,'cast':PTaYpHwtWAObDeSiolKCvNFVjRGJqE,'director':PTaYpHwtWAObDeSiolKCvNFVjRGJqu,'genre':PTaYpHwtWAObDeSiolKCvNFVjRGJqr,'duration':PTaYpHwtWAObDeSiolKCvNFVjRGJEX,'mpaa':PTaYpHwtWAObDeSiolKCvNFVjRGJqU,'year':PTaYpHwtWAObDeSiolKCvNFVjRGJqh,'aired':PTaYpHwtWAObDeSiolKCvNFVjRGJEh,'plot':'%s\n\n%s'%(PTaYpHwtWAObDeSiolKCvNFVjRGJdz,PTaYpHwtWAObDeSiolKCvNFVjRGJqd)}
   if PTaYpHwtWAObDeSiolKCvNFVjRGJmz=='vod':
    PTaYpHwtWAObDeSiolKCvNFVjRGJEQ=PTaYpHwtWAObDeSiolKCvNFVjRGJuc.get('program')
    PTaYpHwtWAObDeSiolKCvNFVjRGJEz='tvshow'
    PTaYpHwtWAObDeSiolKCvNFVjRGJmd={'mode':'EPISODE','programcode':PTaYpHwtWAObDeSiolKCvNFVjRGJEQ,'page':'1',}
    PTaYpHwtWAObDeSiolKCvNFVjRGJmq=PTaYpHwtWAObDeSiolKCvNFVjRGJUL
   else:
    PTaYpHwtWAObDeSiolKCvNFVjRGJEQ=PTaYpHwtWAObDeSiolKCvNFVjRGJuc.get('movie')
    PTaYpHwtWAObDeSiolKCvNFVjRGJEz='movie'
    PTaYpHwtWAObDeSiolKCvNFVjRGJmd={'mode':'MOVIE','mediacode':PTaYpHwtWAObDeSiolKCvNFVjRGJEQ,'stype':'movie','title':PTaYpHwtWAObDeSiolKCvNFVjRGJdz,'thumbnail':PTaYpHwtWAObDeSiolKCvNFVjRGJqL,}
    PTaYpHwtWAObDeSiolKCvNFVjRGJmq=PTaYpHwtWAObDeSiolKCvNFVjRGJUd
   if PTaYpHwtWAObDeSiolKCvNFVjRGJLX.get_settings_makebookmark():
    PTaYpHwtWAObDeSiolKCvNFVjRGJqn={'videoid':PTaYpHwtWAObDeSiolKCvNFVjRGJEQ,'vidtype':PTaYpHwtWAObDeSiolKCvNFVjRGJEz,'vtitle':PTaYpHwtWAObDeSiolKCvNFVjRGJdz,'vsubtitle':'',}
    PTaYpHwtWAObDeSiolKCvNFVjRGJqg=json.dumps(PTaYpHwtWAObDeSiolKCvNFVjRGJqn)
    PTaYpHwtWAObDeSiolKCvNFVjRGJqg=urllib.parse.quote(PTaYpHwtWAObDeSiolKCvNFVjRGJqg)
    PTaYpHwtWAObDeSiolKCvNFVjRGJqI='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(PTaYpHwtWAObDeSiolKCvNFVjRGJqg)
    PTaYpHwtWAObDeSiolKCvNFVjRGJqs=[('(통합) 찜 영상에 추가',PTaYpHwtWAObDeSiolKCvNFVjRGJqI)]
   else:
    PTaYpHwtWAObDeSiolKCvNFVjRGJqs=PTaYpHwtWAObDeSiolKCvNFVjRGJhk
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.add_dir(PTaYpHwtWAObDeSiolKCvNFVjRGJdz,sublabel='',img=PTaYpHwtWAObDeSiolKCvNFVjRGJqL,infoLabels=PTaYpHwtWAObDeSiolKCvNFVjRGJqx,isFolder=PTaYpHwtWAObDeSiolKCvNFVjRGJmq,params=PTaYpHwtWAObDeSiolKCvNFVjRGJmd,isLink=PTaYpHwtWAObDeSiolKCvNFVjRGJUd,ContextMenu=PTaYpHwtWAObDeSiolKCvNFVjRGJqs)
  if PTaYpHwtWAObDeSiolKCvNFVjRGJmk:
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd['mode'] ='SEARCH' 
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd['search_key']=PTaYpHwtWAObDeSiolKCvNFVjRGJEs
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd['page'] =PTaYpHwtWAObDeSiolKCvNFVjRGJUh(PTaYpHwtWAObDeSiolKCvNFVjRGJmI+1)
   PTaYpHwtWAObDeSiolKCvNFVjRGJdz='[B]%s >>[/B]'%'다음 페이지'
   PTaYpHwtWAObDeSiolKCvNFVjRGJqB=PTaYpHwtWAObDeSiolKCvNFVjRGJUh(PTaYpHwtWAObDeSiolKCvNFVjRGJmI+1)
   PTaYpHwtWAObDeSiolKCvNFVjRGJmL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.add_dir(PTaYpHwtWAObDeSiolKCvNFVjRGJdz,sublabel=PTaYpHwtWAObDeSiolKCvNFVjRGJqB,img=PTaYpHwtWAObDeSiolKCvNFVjRGJmL,infoLabels=PTaYpHwtWAObDeSiolKCvNFVjRGJhk,isFolder=PTaYpHwtWAObDeSiolKCvNFVjRGJUL,params=PTaYpHwtWAObDeSiolKCvNFVjRGJmd)
  if PTaYpHwtWAObDeSiolKCvNFVjRGJmz=='movie':xbmcplugin.setContent(PTaYpHwtWAObDeSiolKCvNFVjRGJLX._addon_handle,'movies')
  else:xbmcplugin.setContent(PTaYpHwtWAObDeSiolKCvNFVjRGJLX._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(PTaYpHwtWAObDeSiolKCvNFVjRGJLX._addon_handle,cacheToDisc=PTaYpHwtWAObDeSiolKCvNFVjRGJUd)
 def dp_History_Remove(PTaYpHwtWAObDeSiolKCvNFVjRGJLX,PTaYpHwtWAObDeSiolKCvNFVjRGJmg):
  PTaYpHwtWAObDeSiolKCvNFVjRGJuB=PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('delType')
  PTaYpHwtWAObDeSiolKCvNFVjRGJuX =PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('sKey')
  PTaYpHwtWAObDeSiolKCvNFVjRGJuy =PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('vType')
  PTaYpHwtWAObDeSiolKCvNFVjRGJLn=xbmcgui.Dialog()
  if PTaYpHwtWAObDeSiolKCvNFVjRGJuB=='SEARCH_ALL':
   PTaYpHwtWAObDeSiolKCvNFVjRGJmB=PTaYpHwtWAObDeSiolKCvNFVjRGJLn.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif PTaYpHwtWAObDeSiolKCvNFVjRGJuB=='SEARCH_ONE':
   PTaYpHwtWAObDeSiolKCvNFVjRGJmB=PTaYpHwtWAObDeSiolKCvNFVjRGJLn.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif PTaYpHwtWAObDeSiolKCvNFVjRGJuB=='WATCH_ALL':
   PTaYpHwtWAObDeSiolKCvNFVjRGJmB=PTaYpHwtWAObDeSiolKCvNFVjRGJLn.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif PTaYpHwtWAObDeSiolKCvNFVjRGJuB=='WATCH_ONE':
   PTaYpHwtWAObDeSiolKCvNFVjRGJmB=PTaYpHwtWAObDeSiolKCvNFVjRGJLn.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if PTaYpHwtWAObDeSiolKCvNFVjRGJmB==PTaYpHwtWAObDeSiolKCvNFVjRGJUd:sys.exit()
  if PTaYpHwtWAObDeSiolKCvNFVjRGJuB=='SEARCH_ALL':
   if os.path.isfile(PTaYpHwtWAObDeSiolKCvNFVjRGJLB):os.remove(PTaYpHwtWAObDeSiolKCvNFVjRGJLB)
  elif PTaYpHwtWAObDeSiolKCvNFVjRGJuB=='SEARCH_ONE':
   try:
    PTaYpHwtWAObDeSiolKCvNFVjRGJuQ=PTaYpHwtWAObDeSiolKCvNFVjRGJLB
    PTaYpHwtWAObDeSiolKCvNFVjRGJuz=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.Load_List_File('search') 
    fp=PTaYpHwtWAObDeSiolKCvNFVjRGJUx(PTaYpHwtWAObDeSiolKCvNFVjRGJuQ,'w',-1,'utf-8')
    for PTaYpHwtWAObDeSiolKCvNFVjRGJuf in PTaYpHwtWAObDeSiolKCvNFVjRGJuz:
     PTaYpHwtWAObDeSiolKCvNFVjRGJun=PTaYpHwtWAObDeSiolKCvNFVjRGJUq(urllib.parse.parse_qsl(PTaYpHwtWAObDeSiolKCvNFVjRGJuf))
     PTaYpHwtWAObDeSiolKCvNFVjRGJug=PTaYpHwtWAObDeSiolKCvNFVjRGJun.get('skey').strip()
     if PTaYpHwtWAObDeSiolKCvNFVjRGJuX!=PTaYpHwtWAObDeSiolKCvNFVjRGJug:
      fp.write(PTaYpHwtWAObDeSiolKCvNFVjRGJuf)
    fp.close()
   except:
    PTaYpHwtWAObDeSiolKCvNFVjRGJhk
  elif PTaYpHwtWAObDeSiolKCvNFVjRGJuB=='WATCH_ALL':
   PTaYpHwtWAObDeSiolKCvNFVjRGJuQ=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%PTaYpHwtWAObDeSiolKCvNFVjRGJuy))
   if os.path.isfile(PTaYpHwtWAObDeSiolKCvNFVjRGJuQ):os.remove(PTaYpHwtWAObDeSiolKCvNFVjRGJuQ)
  elif PTaYpHwtWAObDeSiolKCvNFVjRGJuB=='WATCH_ONE':
   PTaYpHwtWAObDeSiolKCvNFVjRGJuQ=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%PTaYpHwtWAObDeSiolKCvNFVjRGJuy))
   try:
    PTaYpHwtWAObDeSiolKCvNFVjRGJuz=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.Load_List_File(PTaYpHwtWAObDeSiolKCvNFVjRGJuy) 
    fp=PTaYpHwtWAObDeSiolKCvNFVjRGJUx(PTaYpHwtWAObDeSiolKCvNFVjRGJuQ,'w',-1,'utf-8')
    for PTaYpHwtWAObDeSiolKCvNFVjRGJuf in PTaYpHwtWAObDeSiolKCvNFVjRGJuz:
     PTaYpHwtWAObDeSiolKCvNFVjRGJun=PTaYpHwtWAObDeSiolKCvNFVjRGJUq(urllib.parse.parse_qsl(PTaYpHwtWAObDeSiolKCvNFVjRGJuf))
     PTaYpHwtWAObDeSiolKCvNFVjRGJug=PTaYpHwtWAObDeSiolKCvNFVjRGJun.get('code').strip()
     if PTaYpHwtWAObDeSiolKCvNFVjRGJuX!=PTaYpHwtWAObDeSiolKCvNFVjRGJug:
      fp.write(PTaYpHwtWAObDeSiolKCvNFVjRGJuf)
    fp.close()
   except:
    PTaYpHwtWAObDeSiolKCvNFVjRGJhk
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(PTaYpHwtWAObDeSiolKCvNFVjRGJLX,PTaYpHwtWAObDeSiolKCvNFVjRGJmz): 
  try:
   if PTaYpHwtWAObDeSiolKCvNFVjRGJmz=='search':
    PTaYpHwtWAObDeSiolKCvNFVjRGJuQ=PTaYpHwtWAObDeSiolKCvNFVjRGJLB
   elif PTaYpHwtWAObDeSiolKCvNFVjRGJmz in['vod','movie']:
    PTaYpHwtWAObDeSiolKCvNFVjRGJuQ=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%PTaYpHwtWAObDeSiolKCvNFVjRGJmz))
   else:
    return[]
   fp=PTaYpHwtWAObDeSiolKCvNFVjRGJUx(PTaYpHwtWAObDeSiolKCvNFVjRGJuQ,'r',-1,'utf-8')
   PTaYpHwtWAObDeSiolKCvNFVjRGJuI=fp.readlines()
   fp.close()
  except:
   PTaYpHwtWAObDeSiolKCvNFVjRGJuI=[]
  return PTaYpHwtWAObDeSiolKCvNFVjRGJuI
 def Save_Watched_List(PTaYpHwtWAObDeSiolKCvNFVjRGJLX,PTaYpHwtWAObDeSiolKCvNFVjRGJmz,PTaYpHwtWAObDeSiolKCvNFVjRGJLz):
  try:
   PTaYpHwtWAObDeSiolKCvNFVjRGJus=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%PTaYpHwtWAObDeSiolKCvNFVjRGJmz))
   PTaYpHwtWAObDeSiolKCvNFVjRGJuz=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.Load_List_File(PTaYpHwtWAObDeSiolKCvNFVjRGJmz) 
   fp=PTaYpHwtWAObDeSiolKCvNFVjRGJUx(PTaYpHwtWAObDeSiolKCvNFVjRGJus,'w',-1,'utf-8')
   PTaYpHwtWAObDeSiolKCvNFVjRGJuk=urllib.parse.urlencode(PTaYpHwtWAObDeSiolKCvNFVjRGJLz)
   PTaYpHwtWAObDeSiolKCvNFVjRGJuk=PTaYpHwtWAObDeSiolKCvNFVjRGJuk+'\n'
   fp.write(PTaYpHwtWAObDeSiolKCvNFVjRGJuk)
   PTaYpHwtWAObDeSiolKCvNFVjRGJuM=0
   for PTaYpHwtWAObDeSiolKCvNFVjRGJuf in PTaYpHwtWAObDeSiolKCvNFVjRGJuz:
    PTaYpHwtWAObDeSiolKCvNFVjRGJun=PTaYpHwtWAObDeSiolKCvNFVjRGJUq(urllib.parse.parse_qsl(PTaYpHwtWAObDeSiolKCvNFVjRGJuf))
    PTaYpHwtWAObDeSiolKCvNFVjRGJrL=PTaYpHwtWAObDeSiolKCvNFVjRGJLz.get('code').strip()
    PTaYpHwtWAObDeSiolKCvNFVjRGJrd=PTaYpHwtWAObDeSiolKCvNFVjRGJun.get('code').strip()
    if PTaYpHwtWAObDeSiolKCvNFVjRGJmz=='vod' and PTaYpHwtWAObDeSiolKCvNFVjRGJLX.get_settings_direct_replay()==PTaYpHwtWAObDeSiolKCvNFVjRGJUL:
     PTaYpHwtWAObDeSiolKCvNFVjRGJrL=PTaYpHwtWAObDeSiolKCvNFVjRGJLz.get('videoid').strip()
     PTaYpHwtWAObDeSiolKCvNFVjRGJrd=PTaYpHwtWAObDeSiolKCvNFVjRGJun.get('videoid').strip()if PTaYpHwtWAObDeSiolKCvNFVjRGJrd!=PTaYpHwtWAObDeSiolKCvNFVjRGJhk else '-'
    if PTaYpHwtWAObDeSiolKCvNFVjRGJrL!=PTaYpHwtWAObDeSiolKCvNFVjRGJrd:
     fp.write(PTaYpHwtWAObDeSiolKCvNFVjRGJuf)
     PTaYpHwtWAObDeSiolKCvNFVjRGJuM+=1
     if PTaYpHwtWAObDeSiolKCvNFVjRGJuM>=50:break
   fp.close()
  except:
   PTaYpHwtWAObDeSiolKCvNFVjRGJhk
 def dp_Watch_List(PTaYpHwtWAObDeSiolKCvNFVjRGJLX,PTaYpHwtWAObDeSiolKCvNFVjRGJmg):
  PTaYpHwtWAObDeSiolKCvNFVjRGJmz =PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('stype')
  PTaYpHwtWAObDeSiolKCvNFVjRGJdB=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.get_settings_direct_replay()
  if PTaYpHwtWAObDeSiolKCvNFVjRGJmz=='-':
   for PTaYpHwtWAObDeSiolKCvNFVjRGJmn in PTaYpHwtWAObDeSiolKCvNFVjRGJLE:
    PTaYpHwtWAObDeSiolKCvNFVjRGJdz=PTaYpHwtWAObDeSiolKCvNFVjRGJmn.get('title')
    PTaYpHwtWAObDeSiolKCvNFVjRGJmd={'mode':PTaYpHwtWAObDeSiolKCvNFVjRGJmn.get('mode'),'stype':PTaYpHwtWAObDeSiolKCvNFVjRGJmn.get('stype')}
    PTaYpHwtWAObDeSiolKCvNFVjRGJLX.add_dir(PTaYpHwtWAObDeSiolKCvNFVjRGJdz,sublabel='',img='',infoLabels=PTaYpHwtWAObDeSiolKCvNFVjRGJhk,isFolder=PTaYpHwtWAObDeSiolKCvNFVjRGJUL,params=PTaYpHwtWAObDeSiolKCvNFVjRGJmd)
   if PTaYpHwtWAObDeSiolKCvNFVjRGJUr(PTaYpHwtWAObDeSiolKCvNFVjRGJLE)>0:xbmcplugin.endOfDirectory(PTaYpHwtWAObDeSiolKCvNFVjRGJLX._addon_handle)
  else:
   PTaYpHwtWAObDeSiolKCvNFVjRGJrm=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.Load_List_File(PTaYpHwtWAObDeSiolKCvNFVjRGJmz)
   for PTaYpHwtWAObDeSiolKCvNFVjRGJrq in PTaYpHwtWAObDeSiolKCvNFVjRGJrm:
    PTaYpHwtWAObDeSiolKCvNFVjRGJuE=PTaYpHwtWAObDeSiolKCvNFVjRGJUq(urllib.parse.parse_qsl(PTaYpHwtWAObDeSiolKCvNFVjRGJrq))
    PTaYpHwtWAObDeSiolKCvNFVjRGJrE =PTaYpHwtWAObDeSiolKCvNFVjRGJuE.get('code').strip()
    PTaYpHwtWAObDeSiolKCvNFVjRGJdz =PTaYpHwtWAObDeSiolKCvNFVjRGJuE.get('title').strip()
    PTaYpHwtWAObDeSiolKCvNFVjRGJqL=PTaYpHwtWAObDeSiolKCvNFVjRGJuE.get('img').strip()
    PTaYpHwtWAObDeSiolKCvNFVjRGJEQ =PTaYpHwtWAObDeSiolKCvNFVjRGJuE.get('videoid').strip()
    try:
     PTaYpHwtWAObDeSiolKCvNFVjRGJqL=PTaYpHwtWAObDeSiolKCvNFVjRGJqL.replace('\'','\"')
     PTaYpHwtWAObDeSiolKCvNFVjRGJqL=json.loads(PTaYpHwtWAObDeSiolKCvNFVjRGJqL)
    except:
     PTaYpHwtWAObDeSiolKCvNFVjRGJhk
    PTaYpHwtWAObDeSiolKCvNFVjRGJqx={}
    PTaYpHwtWAObDeSiolKCvNFVjRGJqx['plot']=PTaYpHwtWAObDeSiolKCvNFVjRGJdz
    if PTaYpHwtWAObDeSiolKCvNFVjRGJmz=='vod':
     if PTaYpHwtWAObDeSiolKCvNFVjRGJdB==PTaYpHwtWAObDeSiolKCvNFVjRGJUd or PTaYpHwtWAObDeSiolKCvNFVjRGJEQ==PTaYpHwtWAObDeSiolKCvNFVjRGJhk:
      PTaYpHwtWAObDeSiolKCvNFVjRGJqx['mediatype']='tvshow'
      PTaYpHwtWAObDeSiolKCvNFVjRGJmd={'mode':'EPISODE','programcode':PTaYpHwtWAObDeSiolKCvNFVjRGJrE,'page':'1'}
      PTaYpHwtWAObDeSiolKCvNFVjRGJmq=PTaYpHwtWAObDeSiolKCvNFVjRGJUL
     else:
      PTaYpHwtWAObDeSiolKCvNFVjRGJqx['mediatype']='episode'
      PTaYpHwtWAObDeSiolKCvNFVjRGJmd={'mode':'VOD','mediacode':PTaYpHwtWAObDeSiolKCvNFVjRGJEQ,'stype':'vod','programcode':PTaYpHwtWAObDeSiolKCvNFVjRGJrE,'title':PTaYpHwtWAObDeSiolKCvNFVjRGJdz,'thumbnail':PTaYpHwtWAObDeSiolKCvNFVjRGJqL}
      PTaYpHwtWAObDeSiolKCvNFVjRGJmq=PTaYpHwtWAObDeSiolKCvNFVjRGJUd
    else:
     PTaYpHwtWAObDeSiolKCvNFVjRGJqx['mediatype']='movie'
     PTaYpHwtWAObDeSiolKCvNFVjRGJmd={'mode':'MOVIE','mediacode':PTaYpHwtWAObDeSiolKCvNFVjRGJrE,'stype':'movie','title':PTaYpHwtWAObDeSiolKCvNFVjRGJdz,'thumbnail':PTaYpHwtWAObDeSiolKCvNFVjRGJqL}
     PTaYpHwtWAObDeSiolKCvNFVjRGJmq=PTaYpHwtWAObDeSiolKCvNFVjRGJUd
    PTaYpHwtWAObDeSiolKCvNFVjRGJuh={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':PTaYpHwtWAObDeSiolKCvNFVjRGJrE,'vType':PTaYpHwtWAObDeSiolKCvNFVjRGJmz,}
    PTaYpHwtWAObDeSiolKCvNFVjRGJuU=urllib.parse.urlencode(PTaYpHwtWAObDeSiolKCvNFVjRGJuh)
    PTaYpHwtWAObDeSiolKCvNFVjRGJqs=[('선택된 시청이력 ( %s ) 삭제'%(PTaYpHwtWAObDeSiolKCvNFVjRGJdz),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(PTaYpHwtWAObDeSiolKCvNFVjRGJuU))]
    PTaYpHwtWAObDeSiolKCvNFVjRGJLX.add_dir(PTaYpHwtWAObDeSiolKCvNFVjRGJdz,sublabel='',img=PTaYpHwtWAObDeSiolKCvNFVjRGJqL,infoLabels=PTaYpHwtWAObDeSiolKCvNFVjRGJqx,isFolder=PTaYpHwtWAObDeSiolKCvNFVjRGJmq,params=PTaYpHwtWAObDeSiolKCvNFVjRGJmd,ContextMenu=PTaYpHwtWAObDeSiolKCvNFVjRGJqs)
   PTaYpHwtWAObDeSiolKCvNFVjRGJqx={'plot':'시청목록을 삭제합니다.'}
   PTaYpHwtWAObDeSiolKCvNFVjRGJdz='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':PTaYpHwtWAObDeSiolKCvNFVjRGJmz,}
   PTaYpHwtWAObDeSiolKCvNFVjRGJmL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.add_dir(PTaYpHwtWAObDeSiolKCvNFVjRGJdz,sublabel='',img=PTaYpHwtWAObDeSiolKCvNFVjRGJmL,infoLabels=PTaYpHwtWAObDeSiolKCvNFVjRGJqx,isFolder=PTaYpHwtWAObDeSiolKCvNFVjRGJUd,params=PTaYpHwtWAObDeSiolKCvNFVjRGJmd,isLink=PTaYpHwtWAObDeSiolKCvNFVjRGJUL)
   if PTaYpHwtWAObDeSiolKCvNFVjRGJmz=='movie':xbmcplugin.setContent(PTaYpHwtWAObDeSiolKCvNFVjRGJLX._addon_handle,'movies')
   else:xbmcplugin.setContent(PTaYpHwtWAObDeSiolKCvNFVjRGJLX._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(PTaYpHwtWAObDeSiolKCvNFVjRGJLX._addon_handle,cacheToDisc=PTaYpHwtWAObDeSiolKCvNFVjRGJUd)
 def Save_Searched_List(PTaYpHwtWAObDeSiolKCvNFVjRGJLX,PTaYpHwtWAObDeSiolKCvNFVjRGJEs):
  try:
   PTaYpHwtWAObDeSiolKCvNFVjRGJru=PTaYpHwtWAObDeSiolKCvNFVjRGJLB
   PTaYpHwtWAObDeSiolKCvNFVjRGJuz=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.Load_List_File('search') 
   PTaYpHwtWAObDeSiolKCvNFVjRGJrh={'skey':PTaYpHwtWAObDeSiolKCvNFVjRGJEs.strip()}
   fp=PTaYpHwtWAObDeSiolKCvNFVjRGJUx(PTaYpHwtWAObDeSiolKCvNFVjRGJru,'w',-1,'utf-8')
   PTaYpHwtWAObDeSiolKCvNFVjRGJuk=urllib.parse.urlencode(PTaYpHwtWAObDeSiolKCvNFVjRGJrh)
   PTaYpHwtWAObDeSiolKCvNFVjRGJuk=PTaYpHwtWAObDeSiolKCvNFVjRGJuk+'\n'
   fp.write(PTaYpHwtWAObDeSiolKCvNFVjRGJuk)
   PTaYpHwtWAObDeSiolKCvNFVjRGJuM=0
   for PTaYpHwtWAObDeSiolKCvNFVjRGJuf in PTaYpHwtWAObDeSiolKCvNFVjRGJuz:
    PTaYpHwtWAObDeSiolKCvNFVjRGJun=PTaYpHwtWAObDeSiolKCvNFVjRGJUq(urllib.parse.parse_qsl(PTaYpHwtWAObDeSiolKCvNFVjRGJuf))
    PTaYpHwtWAObDeSiolKCvNFVjRGJrL=PTaYpHwtWAObDeSiolKCvNFVjRGJrh.get('skey').strip()
    PTaYpHwtWAObDeSiolKCvNFVjRGJrd=PTaYpHwtWAObDeSiolKCvNFVjRGJun.get('skey').strip()
    if PTaYpHwtWAObDeSiolKCvNFVjRGJrL!=PTaYpHwtWAObDeSiolKCvNFVjRGJrd:
     fp.write(PTaYpHwtWAObDeSiolKCvNFVjRGJuf)
     PTaYpHwtWAObDeSiolKCvNFVjRGJuM+=1
     if PTaYpHwtWAObDeSiolKCvNFVjRGJuM>=50:break
   fp.close()
  except:
   PTaYpHwtWAObDeSiolKCvNFVjRGJhk
 def play_VIDEO(PTaYpHwtWAObDeSiolKCvNFVjRGJLX,PTaYpHwtWAObDeSiolKCvNFVjRGJmg):
  PTaYpHwtWAObDeSiolKCvNFVjRGJrU =PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('mediacode')
  PTaYpHwtWAObDeSiolKCvNFVjRGJmz =PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('stype')
  PTaYpHwtWAObDeSiolKCvNFVjRGJrc =PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('pvrmode')
  PTaYpHwtWAObDeSiolKCvNFVjRGJrx=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.get_selQuality(PTaYpHwtWAObDeSiolKCvNFVjRGJmz)
  PTaYpHwtWAObDeSiolKCvNFVjRGJLX.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(PTaYpHwtWAObDeSiolKCvNFVjRGJrU,PTaYpHwtWAObDeSiolKCvNFVjRGJUh(PTaYpHwtWAObDeSiolKCvNFVjRGJrx),PTaYpHwtWAObDeSiolKCvNFVjRGJmz,PTaYpHwtWAObDeSiolKCvNFVjRGJrc))
  PTaYpHwtWAObDeSiolKCvNFVjRGJrB=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.GetBroadURL(PTaYpHwtWAObDeSiolKCvNFVjRGJrU,PTaYpHwtWAObDeSiolKCvNFVjRGJrx,PTaYpHwtWAObDeSiolKCvNFVjRGJmz,PTaYpHwtWAObDeSiolKCvNFVjRGJrc,optUHD=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.get_settings_uhd())
  PTaYpHwtWAObDeSiolKCvNFVjRGJLX.addon_log('qt, stype, url : %s - %s - %s'%(PTaYpHwtWAObDeSiolKCvNFVjRGJUh(PTaYpHwtWAObDeSiolKCvNFVjRGJrx),PTaYpHwtWAObDeSiolKCvNFVjRGJmz,PTaYpHwtWAObDeSiolKCvNFVjRGJrB['streaming_url']))
  if PTaYpHwtWAObDeSiolKCvNFVjRGJrB['streaming_url']=='':
   if PTaYpHwtWAObDeSiolKCvNFVjRGJrB['error_msg']=='':
    PTaYpHwtWAObDeSiolKCvNFVjRGJLX.addon_noti(__language__(30908).encode('utf8'))
   else:
    PTaYpHwtWAObDeSiolKCvNFVjRGJLX.addon_noti(PTaYpHwtWAObDeSiolKCvNFVjRGJrB['error_msg'].encode('utf8'))
   return
  PTaYpHwtWAObDeSiolKCvNFVjRGJrX={'user-agent':PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.USER_AGENT}
  PTaYpHwtWAObDeSiolKCvNFVjRGJry=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.makeDefaultCookies() 
  if PTaYpHwtWAObDeSiolKCvNFVjRGJrB['watermark'] !='':
   PTaYpHwtWAObDeSiolKCvNFVjRGJrX['x-tving-param1']=PTaYpHwtWAObDeSiolKCvNFVjRGJrB['watermarkKey']
   PTaYpHwtWAObDeSiolKCvNFVjRGJrX['x-tving-param2']=PTaYpHwtWAObDeSiolKCvNFVjRGJrB['watermark'] 
  if PTaYpHwtWAObDeSiolKCvNFVjRGJrB['drm_server_url'] !='':
   PTaYpHwtWAObDeSiolKCvNFVjRGJrX[PTaYpHwtWAObDeSiolKCvNFVjRGJrB['drm_header_key']]=PTaYpHwtWAObDeSiolKCvNFVjRGJrB['drm_header_value']
  PTaYpHwtWAObDeSiolKCvNFVjRGJrQ =PTaYpHwtWAObDeSiolKCvNFVjRGJUd
  PTaYpHwtWAObDeSiolKCvNFVjRGJrz =PTaYpHwtWAObDeSiolKCvNFVjRGJrB['streaming_url'].find('Policy=')
  if PTaYpHwtWAObDeSiolKCvNFVjRGJrz!=-1:
   PTaYpHwtWAObDeSiolKCvNFVjRGJrf =PTaYpHwtWAObDeSiolKCvNFVjRGJrB['streaming_url'].split('?')[0]
   PTaYpHwtWAObDeSiolKCvNFVjRGJrn=PTaYpHwtWAObDeSiolKCvNFVjRGJUq(urllib.parse.parse_qsl(urllib.parse.urlsplit(PTaYpHwtWAObDeSiolKCvNFVjRGJrB['streaming_url']).query))
   PTaYpHwtWAObDeSiolKCvNFVjRGJry['CloudFront-Policy'] =PTaYpHwtWAObDeSiolKCvNFVjRGJrn['Policy'] 
   PTaYpHwtWAObDeSiolKCvNFVjRGJry['CloudFront-Signature'] =PTaYpHwtWAObDeSiolKCvNFVjRGJrn['Signature'] 
   PTaYpHwtWAObDeSiolKCvNFVjRGJry['CloudFront-Key-Pair-Id']=PTaYpHwtWAObDeSiolKCvNFVjRGJrn['Key-Pair-Id'] 
   PTaYpHwtWAObDeSiolKCvNFVjRGJrg=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.make_stream_header(PTaYpHwtWAObDeSiolKCvNFVjRGJrX,PTaYpHwtWAObDeSiolKCvNFVjRGJry)
   if 'quickvod-mcdn.tving.com' in PTaYpHwtWAObDeSiolKCvNFVjRGJrf:
    PTaYpHwtWAObDeSiolKCvNFVjRGJrQ=PTaYpHwtWAObDeSiolKCvNFVjRGJUL
    PTaYpHwtWAObDeSiolKCvNFVjRGJrI =PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    PTaYpHwtWAObDeSiolKCvNFVjRGJrs=PTaYpHwtWAObDeSiolKCvNFVjRGJrI.strftime('%Y-%m-%d-%H:%M:%S')
    if PTaYpHwtWAObDeSiolKCvNFVjRGJhM(PTaYpHwtWAObDeSiolKCvNFVjRGJrs.replace('-','').replace(':',''))<PTaYpHwtWAObDeSiolKCvNFVjRGJhM(PTaYpHwtWAObDeSiolKCvNFVjRGJrn['end'].replace('-','').replace(':','')):
     PTaYpHwtWAObDeSiolKCvNFVjRGJrn['end']=PTaYpHwtWAObDeSiolKCvNFVjRGJrs
     PTaYpHwtWAObDeSiolKCvNFVjRGJLX.addon_noti(__language__(30915).encode('utf8'))
    PTaYpHwtWAObDeSiolKCvNFVjRGJrf ='%s?%s'%(PTaYpHwtWAObDeSiolKCvNFVjRGJrf,urllib.parse.urlencode(PTaYpHwtWAObDeSiolKCvNFVjRGJrn,doseq=PTaYpHwtWAObDeSiolKCvNFVjRGJUL))
    PTaYpHwtWAObDeSiolKCvNFVjRGJrk='{}|{}'.format(PTaYpHwtWAObDeSiolKCvNFVjRGJrf,PTaYpHwtWAObDeSiolKCvNFVjRGJrg)
   else:
    PTaYpHwtWAObDeSiolKCvNFVjRGJrk='{}|{}'.format(PTaYpHwtWAObDeSiolKCvNFVjRGJrB['streaming_url'],PTaYpHwtWAObDeSiolKCvNFVjRGJrg)
  else:
   PTaYpHwtWAObDeSiolKCvNFVjRGJrg=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.make_stream_header(PTaYpHwtWAObDeSiolKCvNFVjRGJrX,PTaYpHwtWAObDeSiolKCvNFVjRGJry)
   PTaYpHwtWAObDeSiolKCvNFVjRGJrk='{}|{}'.format(PTaYpHwtWAObDeSiolKCvNFVjRGJrB['streaming_url'],PTaYpHwtWAObDeSiolKCvNFVjRGJrg)
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.addon_log('if tmp_pos == -1')
  PTaYpHwtWAObDeSiolKCvNFVjRGJdE,PTaYpHwtWAObDeSiolKCvNFVjRGJdu=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.get_settings_proxyport()
  PTaYpHwtWAObDeSiolKCvNFVjRGJdq=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.get_settings_playback()
  if(PTaYpHwtWAObDeSiolKCvNFVjRGJdE and PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('mode')in['VOD','MOVIE']and PTaYpHwtWAObDeSiolKCvNFVjRGJrQ==PTaYpHwtWAObDeSiolKCvNFVjRGJUd and(PTaYpHwtWAObDeSiolKCvNFVjRGJrB['drm_server_url']!='' or(PTaYpHwtWAObDeSiolKCvNFVjRGJrB['url_filename'].split('.')[1]=='mpd')or(PTaYpHwtWAObDeSiolKCvNFVjRGJrB['url_filename'].split('.')[1]!='mpd' and PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.KodiVersion>=21 and PTaYpHwtWAObDeSiolKCvNFVjRGJrB['qt_stream']=='stream70'))):
   if PTaYpHwtWAObDeSiolKCvNFVjRGJrB['url_filename'].split('.')[1]=='mpd':
    PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.Tving_Parse_mpd(PTaYpHwtWAObDeSiolKCvNFVjRGJrB['streaming_url'],PTaYpHwtWAObDeSiolKCvNFVjRGJrB['watermarkKey'],PTaYpHwtWAObDeSiolKCvNFVjRGJrB['watermark'])
   else:
    PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.Tving_Parse_m3u8(PTaYpHwtWAObDeSiolKCvNFVjRGJrB['streaming_url'])
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.addon_log('xxx '+PTaYpHwtWAObDeSiolKCvNFVjRGJrB['streaming_url'])
   PTaYpHwtWAObDeSiolKCvNFVjRGJrM={'addon':'tvingm','playOption':PTaYpHwtWAObDeSiolKCvNFVjRGJdq,'url_filename':PTaYpHwtWAObDeSiolKCvNFVjRGJrB['url_filename'],}
   PTaYpHwtWAObDeSiolKCvNFVjRGJrM=json.dumps(PTaYpHwtWAObDeSiolKCvNFVjRGJrM,separators=(',',':'))
   PTaYpHwtWAObDeSiolKCvNFVjRGJrM=base64.standard_b64encode(PTaYpHwtWAObDeSiolKCvNFVjRGJrM.encode()).decode('utf-8')
   PTaYpHwtWAObDeSiolKCvNFVjRGJrk ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(PTaYpHwtWAObDeSiolKCvNFVjRGJdu,PTaYpHwtWAObDeSiolKCvNFVjRGJrk,PTaYpHwtWAObDeSiolKCvNFVjRGJrM)
   PTaYpHwtWAObDeSiolKCvNFVjRGJrX['proxy-mini']=PTaYpHwtWAObDeSiolKCvNFVjRGJrM 
  PTaYpHwtWAObDeSiolKCvNFVjRGJLX.addon_log('surl(2) : {}'.format(PTaYpHwtWAObDeSiolKCvNFVjRGJrk))
  PTaYpHwtWAObDeSiolKCvNFVjRGJLX.addon_log('drm     : {}'.format(PTaYpHwtWAObDeSiolKCvNFVjRGJrB['drm_server_url']))
  PTaYpHwtWAObDeSiolKCvNFVjRGJrg=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.make_stream_header(PTaYpHwtWAObDeSiolKCvNFVjRGJrX,PTaYpHwtWAObDeSiolKCvNFVjRGJry)
  PTaYpHwtWAObDeSiolKCvNFVjRGJhL=xbmcgui.ListItem(path=PTaYpHwtWAObDeSiolKCvNFVjRGJrk)
  if PTaYpHwtWAObDeSiolKCvNFVjRGJrB['drm_server_url']!='':
   PTaYpHwtWAObDeSiolKCvNFVjRGJhd=PTaYpHwtWAObDeSiolKCvNFVjRGJrB['drm_server_url']
   PTaYpHwtWAObDeSiolKCvNFVjRGJhm ='https://license-global.pallycon.com/ri/licenseManager.do' 
   PTaYpHwtWAObDeSiolKCvNFVjRGJhq ='mpd'
   PTaYpHwtWAObDeSiolKCvNFVjRGJhE ='com.widevine.alpha'
   inputstreamhelper.Helper('mpd',drm='com.widevine.alpha').check_inputstream()
   PTaYpHwtWAObDeSiolKCvNFVjRGJhr={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.USER_AGENT,PTaYpHwtWAObDeSiolKCvNFVjRGJrB['drm_header_key']:PTaYpHwtWAObDeSiolKCvNFVjRGJrB['drm_header_value'],}
   PTaYpHwtWAObDeSiolKCvNFVjRGJhU=PTaYpHwtWAObDeSiolKCvNFVjRGJhm+'|'+urllib.parse.urlencode(PTaYpHwtWAObDeSiolKCvNFVjRGJhr)+'|R{SSM}|'
   PTaYpHwtWAObDeSiolKCvNFVjRGJhL.setProperty('inputstream','inputstream.adaptive')
   if PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.KodiVersion<=20:
    PTaYpHwtWAObDeSiolKCvNFVjRGJhL.setProperty('inputstream.adaptive.manifest_type',PTaYpHwtWAObDeSiolKCvNFVjRGJhq)
   PTaYpHwtWAObDeSiolKCvNFVjRGJhL.setProperty('inputstream.adaptive.license_type',PTaYpHwtWAObDeSiolKCvNFVjRGJhE)
   PTaYpHwtWAObDeSiolKCvNFVjRGJhL.setProperty('inputstream.adaptive.license_key',PTaYpHwtWAObDeSiolKCvNFVjRGJhU)
   PTaYpHwtWAObDeSiolKCvNFVjRGJhL.setProperty('inputstream.adaptive.stream_headers',PTaYpHwtWAObDeSiolKCvNFVjRGJrg)
   PTaYpHwtWAObDeSiolKCvNFVjRGJhL.setProperty('inputstream.adaptive.manifest_headers',PTaYpHwtWAObDeSiolKCvNFVjRGJrg)
  elif PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('mode')in['VOD','MOVIE']:
   PTaYpHwtWAObDeSiolKCvNFVjRGJhL.setContentLookup(PTaYpHwtWAObDeSiolKCvNFVjRGJUd)
   PTaYpHwtWAObDeSiolKCvNFVjRGJhL.setMimeType('application/x-mpegURL')
   PTaYpHwtWAObDeSiolKCvNFVjRGJhL.setProperty('inputstream','inputstream.adaptive')
   if PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.KodiVersion<=20:
    PTaYpHwtWAObDeSiolKCvNFVjRGJhL.setProperty('inputstream.adaptive.manifest_type','hls')
   PTaYpHwtWAObDeSiolKCvNFVjRGJhL.setProperty('inputstream.adaptive.stream_headers',PTaYpHwtWAObDeSiolKCvNFVjRGJrg)
   PTaYpHwtWAObDeSiolKCvNFVjRGJhL.setProperty('inputstream.adaptive.manifest_headers',PTaYpHwtWAObDeSiolKCvNFVjRGJrg)
  elif PTaYpHwtWAObDeSiolKCvNFVjRGJrQ==PTaYpHwtWAObDeSiolKCvNFVjRGJUL:
   PTaYpHwtWAObDeSiolKCvNFVjRGJhL.setContentLookup(PTaYpHwtWAObDeSiolKCvNFVjRGJUd)
   PTaYpHwtWAObDeSiolKCvNFVjRGJhL.setMimeType('application/x-mpegURL')
   PTaYpHwtWAObDeSiolKCvNFVjRGJhL.setProperty('inputstream','inputstream.ffmpegdirect')
   PTaYpHwtWAObDeSiolKCvNFVjRGJhL.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   PTaYpHwtWAObDeSiolKCvNFVjRGJhL.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   PTaYpHwtWAObDeSiolKCvNFVjRGJhL.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   PTaYpHwtWAObDeSiolKCvNFVjRGJhL.setProperty('ResumeTime','0')
   PTaYpHwtWAObDeSiolKCvNFVjRGJhL.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(PTaYpHwtWAObDeSiolKCvNFVjRGJLX._addon_handle,PTaYpHwtWAObDeSiolKCvNFVjRGJUL,PTaYpHwtWAObDeSiolKCvNFVjRGJhL)
  try:
   if PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('mode')in['VOD','MOVIE']and PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('title'):
    PTaYpHwtWAObDeSiolKCvNFVjRGJmd={'code':PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('programcode')if PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('mode')=='VOD' else PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('mediacode'),'img':PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('thumbnail'),'title':PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('title'),'videoid':PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('mediacode')}
    PTaYpHwtWAObDeSiolKCvNFVjRGJLX.Save_Watched_List(PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('stype'),PTaYpHwtWAObDeSiolKCvNFVjRGJmd)
  except:
   PTaYpHwtWAObDeSiolKCvNFVjRGJhk
 def logout(PTaYpHwtWAObDeSiolKCvNFVjRGJLX):
  PTaYpHwtWAObDeSiolKCvNFVjRGJLn=xbmcgui.Dialog()
  PTaYpHwtWAObDeSiolKCvNFVjRGJmB=PTaYpHwtWAObDeSiolKCvNFVjRGJLn.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if PTaYpHwtWAObDeSiolKCvNFVjRGJmB==PTaYpHwtWAObDeSiolKCvNFVjRGJUd:sys.exit()
  PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.Init_TV_Total()
  if os.path.isfile(PTaYpHwtWAObDeSiolKCvNFVjRGJLx):os.remove(PTaYpHwtWAObDeSiolKCvNFVjRGJLx)
  PTaYpHwtWAObDeSiolKCvNFVjRGJLX.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(PTaYpHwtWAObDeSiolKCvNFVjRGJLX):
  PTaYpHwtWAObDeSiolKCvNFVjRGJhc =PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.Get_Now_Datetime()
  PTaYpHwtWAObDeSiolKCvNFVjRGJhx=PTaYpHwtWAObDeSiolKCvNFVjRGJhc+datetime.timedelta(days=30) 
  (PTaYpHwtWAObDeSiolKCvNFVjRGJmh,PTaYpHwtWAObDeSiolKCvNFVjRGJmU,PTaYpHwtWAObDeSiolKCvNFVjRGJmc,PTaYpHwtWAObDeSiolKCvNFVjRGJmx)=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.get_settings_account()
  PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.Save_session_acount(PTaYpHwtWAObDeSiolKCvNFVjRGJmh,PTaYpHwtWAObDeSiolKCvNFVjRGJmU,PTaYpHwtWAObDeSiolKCvNFVjRGJmc,PTaYpHwtWAObDeSiolKCvNFVjRGJmx)
  PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.TV['account']['token_limit']=PTaYpHwtWAObDeSiolKCvNFVjRGJhx.strftime('%Y%m%d')
  PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.JsonFile_Save(PTaYpHwtWAObDeSiolKCvNFVjRGJLx,PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.TV)
 def cookiefile_check(PTaYpHwtWAObDeSiolKCvNFVjRGJLX):
  PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.TV=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.JsonFile_Load(PTaYpHwtWAObDeSiolKCvNFVjRGJLx)
  if PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.TV=={}:
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.Init_TV_Total()
   return PTaYpHwtWAObDeSiolKCvNFVjRGJUd
  (PTaYpHwtWAObDeSiolKCvNFVjRGJhB,PTaYpHwtWAObDeSiolKCvNFVjRGJhX,PTaYpHwtWAObDeSiolKCvNFVjRGJhy,PTaYpHwtWAObDeSiolKCvNFVjRGJhQ)=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.get_settings_account()
  (PTaYpHwtWAObDeSiolKCvNFVjRGJhz,PTaYpHwtWAObDeSiolKCvNFVjRGJhf,PTaYpHwtWAObDeSiolKCvNFVjRGJhn,PTaYpHwtWAObDeSiolKCvNFVjRGJhg)=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.Load_session_acount()
  if(PTaYpHwtWAObDeSiolKCvNFVjRGJhB!=PTaYpHwtWAObDeSiolKCvNFVjRGJhz or PTaYpHwtWAObDeSiolKCvNFVjRGJhX!=PTaYpHwtWAObDeSiolKCvNFVjRGJhf or PTaYpHwtWAObDeSiolKCvNFVjRGJhy!=PTaYpHwtWAObDeSiolKCvNFVjRGJhn or PTaYpHwtWAObDeSiolKCvNFVjRGJhQ!=PTaYpHwtWAObDeSiolKCvNFVjRGJhg)and PTaYpHwtWAObDeSiolKCvNFVjRGJhz!='xxxxx':
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.Init_TV_Total()
   return PTaYpHwtWAObDeSiolKCvNFVjRGJUd
  if PTaYpHwtWAObDeSiolKCvNFVjRGJhM(PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>PTaYpHwtWAObDeSiolKCvNFVjRGJhM(PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.TV['account']['token_limit']):
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.Init_TV_Total()
   return PTaYpHwtWAObDeSiolKCvNFVjRGJUd
  return PTaYpHwtWAObDeSiolKCvNFVjRGJUL
 def dp_Global_Search(PTaYpHwtWAObDeSiolKCvNFVjRGJLX,PTaYpHwtWAObDeSiolKCvNFVjRGJmg):
  PTaYpHwtWAObDeSiolKCvNFVjRGJEk=PTaYpHwtWAObDeSiolKCvNFVjRGJmg.get('mode')
  if PTaYpHwtWAObDeSiolKCvNFVjRGJEk=='TOTAL_SEARCH':
   PTaYpHwtWAObDeSiolKCvNFVjRGJhI='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   PTaYpHwtWAObDeSiolKCvNFVjRGJhI='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(PTaYpHwtWAObDeSiolKCvNFVjRGJhI)
 def dp_Bookmark_Menu(PTaYpHwtWAObDeSiolKCvNFVjRGJLX,PTaYpHwtWAObDeSiolKCvNFVjRGJmg):
  PTaYpHwtWAObDeSiolKCvNFVjRGJhI='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(PTaYpHwtWAObDeSiolKCvNFVjRGJhI)
 def dp_EuroLive_List(PTaYpHwtWAObDeSiolKCvNFVjRGJLX,PTaYpHwtWAObDeSiolKCvNFVjRGJmg):
  PTaYpHwtWAObDeSiolKCvNFVjRGJms=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.GetEuroChannelList()
  for PTaYpHwtWAObDeSiolKCvNFVjRGJmM in PTaYpHwtWAObDeSiolKCvNFVjRGJms:
   PTaYpHwtWAObDeSiolKCvNFVjRGJqf =PTaYpHwtWAObDeSiolKCvNFVjRGJmM.get('channel')
   PTaYpHwtWAObDeSiolKCvNFVjRGJdz =PTaYpHwtWAObDeSiolKCvNFVjRGJmM.get('title')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqB =PTaYpHwtWAObDeSiolKCvNFVjRGJmM.get('subtitle')
   PTaYpHwtWAObDeSiolKCvNFVjRGJqx={'mediatype':'episode','title':PTaYpHwtWAObDeSiolKCvNFVjRGJdz,'plot':'%s\n%s'%(PTaYpHwtWAObDeSiolKCvNFVjRGJdz,PTaYpHwtWAObDeSiolKCvNFVjRGJqB)}
   PTaYpHwtWAObDeSiolKCvNFVjRGJmd={'mode':'LIVE','mediacode':PTaYpHwtWAObDeSiolKCvNFVjRGJqf,'stype':'onair',}
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.add_dir(PTaYpHwtWAObDeSiolKCvNFVjRGJdz,sublabel=PTaYpHwtWAObDeSiolKCvNFVjRGJqB,img='',infoLabels=PTaYpHwtWAObDeSiolKCvNFVjRGJqx,isFolder=PTaYpHwtWAObDeSiolKCvNFVjRGJUd,params=PTaYpHwtWAObDeSiolKCvNFVjRGJmd)
  if PTaYpHwtWAObDeSiolKCvNFVjRGJUr(PTaYpHwtWAObDeSiolKCvNFVjRGJms)>0:xbmcplugin.endOfDirectory(PTaYpHwtWAObDeSiolKCvNFVjRGJLX._addon_handle,cacheToDisc=PTaYpHwtWAObDeSiolKCvNFVjRGJUd)
 def tving_main(PTaYpHwtWAObDeSiolKCvNFVjRGJLX):
  PTaYpHwtWAObDeSiolKCvNFVjRGJLX.TvingObj.KodiVersion=PTaYpHwtWAObDeSiolKCvNFVjRGJhM(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  PTaYpHwtWAObDeSiolKCvNFVjRGJEk=PTaYpHwtWAObDeSiolKCvNFVjRGJLX.main_params.get('mode',PTaYpHwtWAObDeSiolKCvNFVjRGJhk)
  if PTaYpHwtWAObDeSiolKCvNFVjRGJEk=='LOGOUT':
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.logout()
   return
  PTaYpHwtWAObDeSiolKCvNFVjRGJLX.login_main()
  if PTaYpHwtWAObDeSiolKCvNFVjRGJEk is PTaYpHwtWAObDeSiolKCvNFVjRGJhk:
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.dp_Main_List()
  elif PTaYpHwtWAObDeSiolKCvNFVjRGJEk in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.dp_Title_Group(PTaYpHwtWAObDeSiolKCvNFVjRGJLX.main_params)
  elif PTaYpHwtWAObDeSiolKCvNFVjRGJEk in['GLOBAL_GROUP']:
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.dp_SubTitle_Group(PTaYpHwtWAObDeSiolKCvNFVjRGJLX.main_params)
  elif PTaYpHwtWAObDeSiolKCvNFVjRGJEk=='CHANNEL':
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.dp_LiveChannel_List(PTaYpHwtWAObDeSiolKCvNFVjRGJLX.main_params)
  elif PTaYpHwtWAObDeSiolKCvNFVjRGJEk in['LIVE','VOD','MOVIE']:
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.play_VIDEO(PTaYpHwtWAObDeSiolKCvNFVjRGJLX.main_params)
  elif PTaYpHwtWAObDeSiolKCvNFVjRGJEk=='PROGRAM':
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.dp_Program_List(PTaYpHwtWAObDeSiolKCvNFVjRGJLX.main_params)
  elif PTaYpHwtWAObDeSiolKCvNFVjRGJEk=='4K_PROGRAM':
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.dp_4K_Program_List(PTaYpHwtWAObDeSiolKCvNFVjRGJLX.main_params)
  elif PTaYpHwtWAObDeSiolKCvNFVjRGJEk=='ORI_PROGRAM':
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.dp_Ori_Program_List(PTaYpHwtWAObDeSiolKCvNFVjRGJLX.main_params)
  elif PTaYpHwtWAObDeSiolKCvNFVjRGJEk=='EPISODE':
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.dp_Episode_List(PTaYpHwtWAObDeSiolKCvNFVjRGJLX.main_params)
  elif PTaYpHwtWAObDeSiolKCvNFVjRGJEk=='MOVIE_SUB':
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.dp_Movie_List(PTaYpHwtWAObDeSiolKCvNFVjRGJLX.main_params)
  elif PTaYpHwtWAObDeSiolKCvNFVjRGJEk=='4K_MOVIE':
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.dp_4K_Movie_List(PTaYpHwtWAObDeSiolKCvNFVjRGJLX.main_params)
  elif PTaYpHwtWAObDeSiolKCvNFVjRGJEk=='SEARCH_GROUP':
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.dp_Search_Group(PTaYpHwtWAObDeSiolKCvNFVjRGJLX.main_params)
  elif PTaYpHwtWAObDeSiolKCvNFVjRGJEk in['SEARCH','LOCAL_SEARCH']:
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.dp_Search_List(PTaYpHwtWAObDeSiolKCvNFVjRGJLX.main_params)
  elif PTaYpHwtWAObDeSiolKCvNFVjRGJEk=='WATCH':
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.dp_Watch_List(PTaYpHwtWAObDeSiolKCvNFVjRGJLX.main_params)
  elif PTaYpHwtWAObDeSiolKCvNFVjRGJEk in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.dp_History_Remove(PTaYpHwtWAObDeSiolKCvNFVjRGJLX.main_params)
  elif PTaYpHwtWAObDeSiolKCvNFVjRGJEk=='ORDER_BY':
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.dp_setEpOrderby(PTaYpHwtWAObDeSiolKCvNFVjRGJLX.main_params)
  elif PTaYpHwtWAObDeSiolKCvNFVjRGJEk=='SET_BOOKMARK':
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.dp_Set_Bookmark(PTaYpHwtWAObDeSiolKCvNFVjRGJLX.main_params)
  elif PTaYpHwtWAObDeSiolKCvNFVjRGJEk in['TOTAL_SEARCH','TOTAL_HISTORY']:
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.dp_Global_Search(PTaYpHwtWAObDeSiolKCvNFVjRGJLX.main_params)
  elif PTaYpHwtWAObDeSiolKCvNFVjRGJEk=='SEARCH_HISTORY':
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.dp_Search_History(PTaYpHwtWAObDeSiolKCvNFVjRGJLX.main_params)
  elif PTaYpHwtWAObDeSiolKCvNFVjRGJEk=='MENU_BOOKMARK':
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.dp_Bookmark_Menu(PTaYpHwtWAObDeSiolKCvNFVjRGJLX.main_params)
  elif PTaYpHwtWAObDeSiolKCvNFVjRGJEk=='EURO_GROUP':
   PTaYpHwtWAObDeSiolKCvNFVjRGJLX.dp_EuroLive_List(PTaYpHwtWAObDeSiolKCvNFVjRGJLX.main_params)
  else:
   PTaYpHwtWAObDeSiolKCvNFVjRGJhk
# Created by pyminifier (https://github.com/liftoff/pyminifier)
