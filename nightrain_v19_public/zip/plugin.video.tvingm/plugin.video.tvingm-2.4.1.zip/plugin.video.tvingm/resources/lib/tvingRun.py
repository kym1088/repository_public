__author__="NightRain"
gworSyJHIYMCxkjQDiGfAReblUpzNP=object
gworSyJHIYMCxkjQDiGfAReblUpzNt=None
gworSyJHIYMCxkjQDiGfAReblUpzNL=int
gworSyJHIYMCxkjQDiGfAReblUpzNK=True
gworSyJHIYMCxkjQDiGfAReblUpzNs=False
gworSyJHIYMCxkjQDiGfAReblUpzNn=type
gworSyJHIYMCxkjQDiGfAReblUpzNm=dict
gworSyJHIYMCxkjQDiGfAReblUpzNq=len
gworSyJHIYMCxkjQDiGfAReblUpzNT=str
gworSyJHIYMCxkjQDiGfAReblUpzNB=range
gworSyJHIYMCxkjQDiGfAReblUpzNh=open
gworSyJHIYMCxkjQDiGfAReblUpzNW=Exception
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
gworSyJHIYMCxkjQDiGfAReblUpzav=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewWeek','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
gworSyJHIYMCxkjQDiGfAReblUpzad=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
gworSyJHIYMCxkjQDiGfAReblUpzaP=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
gworSyJHIYMCxkjQDiGfAReblUpzat=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
gworSyJHIYMCxkjQDiGfAReblUpzaL=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'키즈/애니','mode':'PROGRAM','stype':'PCC,PCAN'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'뮤직','mode':'PROGRAM','stype':'PCG'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'}]
gworSyJHIYMCxkjQDiGfAReblUpzaN=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG190,MG230,MG270,MG290'},{'title':'로맨스/멜로','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'액션/SF','mode':'MOVIE_SUB','stype':'MG120,MG170,MG180,MG220,MG260,MG200,MG210'},{'title':'공포/스릴러','mode':'MOVIE_SUB','stype':'MG140,MG150,MG160'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'다큐','mode':'MOVIE_SUB','stype':'MG250,MG330'}]
gworSyJHIYMCxkjQDiGfAReblUpzaK=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
gworSyJHIYMCxkjQDiGfAReblUpzas =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
gworSyJHIYMCxkjQDiGfAReblUpzan=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
from tvingCore import*
class gworSyJHIYMCxkjQDiGfAReblUpzac(gworSyJHIYMCxkjQDiGfAReblUpzNP):
 def __init__(gworSyJHIYMCxkjQDiGfAReblUpzam,gworSyJHIYMCxkjQDiGfAReblUpzaq,gworSyJHIYMCxkjQDiGfAReblUpzaT,gworSyJHIYMCxkjQDiGfAReblUpzaB):
  gworSyJHIYMCxkjQDiGfAReblUpzam._addon_url =gworSyJHIYMCxkjQDiGfAReblUpzaq
  gworSyJHIYMCxkjQDiGfAReblUpzam._addon_handle=gworSyJHIYMCxkjQDiGfAReblUpzaT
  gworSyJHIYMCxkjQDiGfAReblUpzam.main_params =gworSyJHIYMCxkjQDiGfAReblUpzaB
  gworSyJHIYMCxkjQDiGfAReblUpzam.TvingObj =KSTEvcJlDfhYAUmQgRzasoterVnXCw() 
 def addon_noti(gworSyJHIYMCxkjQDiGfAReblUpzam,sting):
  try:
   gworSyJHIYMCxkjQDiGfAReblUpzaW=xbmcgui.Dialog()
   gworSyJHIYMCxkjQDiGfAReblUpzaW.notification(__addonname__,sting)
  except:
   gworSyJHIYMCxkjQDiGfAReblUpzNt
 def addon_log(gworSyJHIYMCxkjQDiGfAReblUpzam,string):
  try:
   gworSyJHIYMCxkjQDiGfAReblUpzaO=string.encode('utf-8','ignore')
  except:
   gworSyJHIYMCxkjQDiGfAReblUpzaO='addonException: addon_log'
  gworSyJHIYMCxkjQDiGfAReblUpzaV=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,gworSyJHIYMCxkjQDiGfAReblUpzaO),level=gworSyJHIYMCxkjQDiGfAReblUpzaV)
 def get_keyboard_input(gworSyJHIYMCxkjQDiGfAReblUpzam,gworSyJHIYMCxkjQDiGfAReblUpzcm):
  gworSyJHIYMCxkjQDiGfAReblUpzau=gworSyJHIYMCxkjQDiGfAReblUpzNt
  kb=xbmc.Keyboard()
  kb.setHeading(gworSyJHIYMCxkjQDiGfAReblUpzcm)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   gworSyJHIYMCxkjQDiGfAReblUpzau=kb.getText()
  return gworSyJHIYMCxkjQDiGfAReblUpzau
 def get_settings_login_info(gworSyJHIYMCxkjQDiGfAReblUpzam):
  gworSyJHIYMCxkjQDiGfAReblUpzaF =__addon__.getSetting('id')
  gworSyJHIYMCxkjQDiGfAReblUpzaE =__addon__.getSetting('pw')
  gworSyJHIYMCxkjQDiGfAReblUpzaX =__addon__.getSetting('login_type')
  gworSyJHIYMCxkjQDiGfAReblUpzca=gworSyJHIYMCxkjQDiGfAReblUpzNL(__addon__.getSetting('selected_profile'))
  return(gworSyJHIYMCxkjQDiGfAReblUpzaF,gworSyJHIYMCxkjQDiGfAReblUpzaE,gworSyJHIYMCxkjQDiGfAReblUpzaX,gworSyJHIYMCxkjQDiGfAReblUpzca)
 def get_settings_totalsearch(gworSyJHIYMCxkjQDiGfAReblUpzam):
  gworSyJHIYMCxkjQDiGfAReblUpzcv =gworSyJHIYMCxkjQDiGfAReblUpzNK if __addon__.getSetting('local_search')=='true' else gworSyJHIYMCxkjQDiGfAReblUpzNs
  gworSyJHIYMCxkjQDiGfAReblUpzcd=gworSyJHIYMCxkjQDiGfAReblUpzNK if __addon__.getSetting('local_history')=='true' else gworSyJHIYMCxkjQDiGfAReblUpzNs
  gworSyJHIYMCxkjQDiGfAReblUpzcP =gworSyJHIYMCxkjQDiGfAReblUpzNK if __addon__.getSetting('total_search')=='true' else gworSyJHIYMCxkjQDiGfAReblUpzNs
  gworSyJHIYMCxkjQDiGfAReblUpzct=gworSyJHIYMCxkjQDiGfAReblUpzNK if __addon__.getSetting('total_history')=='true' else gworSyJHIYMCxkjQDiGfAReblUpzNs
  gworSyJHIYMCxkjQDiGfAReblUpzcL=gworSyJHIYMCxkjQDiGfAReblUpzNK if __addon__.getSetting('menu_bookmark')=='true' else gworSyJHIYMCxkjQDiGfAReblUpzNs
  return(gworSyJHIYMCxkjQDiGfAReblUpzcv,gworSyJHIYMCxkjQDiGfAReblUpzcd,gworSyJHIYMCxkjQDiGfAReblUpzcP,gworSyJHIYMCxkjQDiGfAReblUpzct,gworSyJHIYMCxkjQDiGfAReblUpzcL)
 def get_settings_makebookmark(gworSyJHIYMCxkjQDiGfAReblUpzam):
  return gworSyJHIYMCxkjQDiGfAReblUpzNK if __addon__.getSetting('make_bookmark')=='true' else gworSyJHIYMCxkjQDiGfAReblUpzNs
 def get_settings_direct_replay(gworSyJHIYMCxkjQDiGfAReblUpzam):
  gworSyJHIYMCxkjQDiGfAReblUpzcN=gworSyJHIYMCxkjQDiGfAReblUpzNL(__addon__.getSetting('direct_replay'))
  if gworSyJHIYMCxkjQDiGfAReblUpzcN==0:
   return gworSyJHIYMCxkjQDiGfAReblUpzNs
  else:
   return gworSyJHIYMCxkjQDiGfAReblUpzNK
 def set_winCredential(gworSyJHIYMCxkjQDiGfAReblUpzam,credential):
  gworSyJHIYMCxkjQDiGfAReblUpzcK=xbmcgui.Window(10000)
  gworSyJHIYMCxkjQDiGfAReblUpzcK.setProperty('TVING_M_TOKEN',credential.get('tving_token'))
  gworSyJHIYMCxkjQDiGfAReblUpzcK.setProperty('TVING_M_USERINFO',credential.get('poc_userinfo'))
  gworSyJHIYMCxkjQDiGfAReblUpzcK.setProperty('TVING_M_UUID',credential.get('tving_uuid'))
  gworSyJHIYMCxkjQDiGfAReblUpzcK.setProperty('TVING_M_LOGINTIME',gworSyJHIYMCxkjQDiGfAReblUpzam.TvingObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
  gworSyJHIYMCxkjQDiGfAReblUpzcK.setProperty('TVING_M_MAINTOKEN',credential.get('tving_maintoken'))
  gworSyJHIYMCxkjQDiGfAReblUpzcK.setProperty('TVING_M_COOKIEKEY',credential.get('tving_cookiekey'))
  gworSyJHIYMCxkjQDiGfAReblUpzcK.setProperty('TVING_M_LOCKKEY',credential.get('tving_lockkey'))
 def get_winCredential(gworSyJHIYMCxkjQDiGfAReblUpzam):
  gworSyJHIYMCxkjQDiGfAReblUpzcK=xbmcgui.Window(10000)
  gworSyJHIYMCxkjQDiGfAReblUpzcs={'tving_token':gworSyJHIYMCxkjQDiGfAReblUpzcK.getProperty('TVING_M_TOKEN'),'poc_userinfo':gworSyJHIYMCxkjQDiGfAReblUpzcK.getProperty('TVING_M_USERINFO'),'tving_uuid':gworSyJHIYMCxkjQDiGfAReblUpzcK.getProperty('TVING_M_UUID'),'tving_maintoken':gworSyJHIYMCxkjQDiGfAReblUpzcK.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':gworSyJHIYMCxkjQDiGfAReblUpzcK.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':gworSyJHIYMCxkjQDiGfAReblUpzcK.getProperty('TVING_M_LOCKKEY')}
  return gworSyJHIYMCxkjQDiGfAReblUpzcs
 def set_winEpisodeOrderby(gworSyJHIYMCxkjQDiGfAReblUpzam,gworSyJHIYMCxkjQDiGfAReblUpzdL):
  gworSyJHIYMCxkjQDiGfAReblUpzcK=xbmcgui.Window(10000)
  gworSyJHIYMCxkjQDiGfAReblUpzcK.setProperty('TVING_M_ORDERBY',gworSyJHIYMCxkjQDiGfAReblUpzdL)
 def get_winEpisodeOrderby(gworSyJHIYMCxkjQDiGfAReblUpzam):
  gworSyJHIYMCxkjQDiGfAReblUpzcK=xbmcgui.Window(10000)
  return gworSyJHIYMCxkjQDiGfAReblUpzcK.getProperty('TVING_M_ORDERBY')
 def add_dir(gworSyJHIYMCxkjQDiGfAReblUpzam,label,sublabel='',img='',infoLabels=gworSyJHIYMCxkjQDiGfAReblUpzNt,isFolder=gworSyJHIYMCxkjQDiGfAReblUpzNK,params='',isLink=gworSyJHIYMCxkjQDiGfAReblUpzNs,ContextMenu=gworSyJHIYMCxkjQDiGfAReblUpzNt):
  gworSyJHIYMCxkjQDiGfAReblUpzcn='%s?%s'%(gworSyJHIYMCxkjQDiGfAReblUpzam._addon_url,urllib.parse.urlencode(params))
  if sublabel:gworSyJHIYMCxkjQDiGfAReblUpzcm='%s < %s >'%(label,sublabel)
  else: gworSyJHIYMCxkjQDiGfAReblUpzcm=label
  if not img:img='DefaultFolder.png'
  gworSyJHIYMCxkjQDiGfAReblUpzcq=xbmcgui.ListItem(gworSyJHIYMCxkjQDiGfAReblUpzcm)
  if gworSyJHIYMCxkjQDiGfAReblUpzNn(img)==gworSyJHIYMCxkjQDiGfAReblUpzNm:
   gworSyJHIYMCxkjQDiGfAReblUpzcq.setArt(img)
  else:
   gworSyJHIYMCxkjQDiGfAReblUpzcq.setArt({'thumb':img,'poster':img})
  if infoLabels:gworSyJHIYMCxkjQDiGfAReblUpzcq.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   gworSyJHIYMCxkjQDiGfAReblUpzcq.setProperty('IsPlayable','true')
  if ContextMenu:gworSyJHIYMCxkjQDiGfAReblUpzcq.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(gworSyJHIYMCxkjQDiGfAReblUpzam._addon_handle,gworSyJHIYMCxkjQDiGfAReblUpzcn,gworSyJHIYMCxkjQDiGfAReblUpzcq,isFolder)
 def get_selQuality(gworSyJHIYMCxkjQDiGfAReblUpzam,etype):
  try:
   gworSyJHIYMCxkjQDiGfAReblUpzcT='selected_quality'
   gworSyJHIYMCxkjQDiGfAReblUpzcB=[1080,720,480,360]
   gworSyJHIYMCxkjQDiGfAReblUpzch=gworSyJHIYMCxkjQDiGfAReblUpzNL(__addon__.getSetting(gworSyJHIYMCxkjQDiGfAReblUpzcT))
   return gworSyJHIYMCxkjQDiGfAReblUpzcB[gworSyJHIYMCxkjQDiGfAReblUpzch]
  except:
   gworSyJHIYMCxkjQDiGfAReblUpzNt
  return 720 
 def dp_Main_List(gworSyJHIYMCxkjQDiGfAReblUpzam):
  (gworSyJHIYMCxkjQDiGfAReblUpzcv,gworSyJHIYMCxkjQDiGfAReblUpzcd,gworSyJHIYMCxkjQDiGfAReblUpzcP,gworSyJHIYMCxkjQDiGfAReblUpzct,gworSyJHIYMCxkjQDiGfAReblUpzcL)=gworSyJHIYMCxkjQDiGfAReblUpzam.get_settings_totalsearch()
  for gworSyJHIYMCxkjQDiGfAReblUpzcW in gworSyJHIYMCxkjQDiGfAReblUpzav:
   gworSyJHIYMCxkjQDiGfAReblUpzcm=gworSyJHIYMCxkjQDiGfAReblUpzcW.get('title')
   gworSyJHIYMCxkjQDiGfAReblUpzcO=''
   if gworSyJHIYMCxkjQDiGfAReblUpzcW.get('mode')=='SEARCH_GROUP' and gworSyJHIYMCxkjQDiGfAReblUpzcv ==gworSyJHIYMCxkjQDiGfAReblUpzNs:continue
   elif gworSyJHIYMCxkjQDiGfAReblUpzcW.get('mode')=='SEARCH_HISTORY' and gworSyJHIYMCxkjQDiGfAReblUpzcd==gworSyJHIYMCxkjQDiGfAReblUpzNs:continue
   elif gworSyJHIYMCxkjQDiGfAReblUpzcW.get('mode')=='TOTAL_SEARCH' and gworSyJHIYMCxkjQDiGfAReblUpzcP ==gworSyJHIYMCxkjQDiGfAReblUpzNs:continue
   elif gworSyJHIYMCxkjQDiGfAReblUpzcW.get('mode')=='TOTAL_HISTORY' and gworSyJHIYMCxkjQDiGfAReblUpzct==gworSyJHIYMCxkjQDiGfAReblUpzNs:continue
   elif gworSyJHIYMCxkjQDiGfAReblUpzcW.get('mode')=='MENU_BOOKMARK' and gworSyJHIYMCxkjQDiGfAReblUpzcL==gworSyJHIYMCxkjQDiGfAReblUpzNs:continue
   gworSyJHIYMCxkjQDiGfAReblUpzcV={'mode':gworSyJHIYMCxkjQDiGfAReblUpzcW.get('mode'),'stype':gworSyJHIYMCxkjQDiGfAReblUpzcW.get('stype'),'orderby':gworSyJHIYMCxkjQDiGfAReblUpzcW.get('orderby'),'ordernm':gworSyJHIYMCxkjQDiGfAReblUpzcW.get('ordernm'),'page':'1'}
   if gworSyJHIYMCxkjQDiGfAReblUpzcW.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    gworSyJHIYMCxkjQDiGfAReblUpzcu=gworSyJHIYMCxkjQDiGfAReblUpzNs
    gworSyJHIYMCxkjQDiGfAReblUpzcF =gworSyJHIYMCxkjQDiGfAReblUpzNK
   else:
    gworSyJHIYMCxkjQDiGfAReblUpzcu=gworSyJHIYMCxkjQDiGfAReblUpzNK
    gworSyJHIYMCxkjQDiGfAReblUpzcF =gworSyJHIYMCxkjQDiGfAReblUpzNs
   if 'icon' in gworSyJHIYMCxkjQDiGfAReblUpzcW:gworSyJHIYMCxkjQDiGfAReblUpzcO=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',gworSyJHIYMCxkjQDiGfAReblUpzcW.get('icon')) 
   gworSyJHIYMCxkjQDiGfAReblUpzam.add_dir(gworSyJHIYMCxkjQDiGfAReblUpzcm,sublabel='',img=gworSyJHIYMCxkjQDiGfAReblUpzcO,infoLabels=gworSyJHIYMCxkjQDiGfAReblUpzNt,isFolder=gworSyJHIYMCxkjQDiGfAReblUpzcu,params=gworSyJHIYMCxkjQDiGfAReblUpzcV,isLink=gworSyJHIYMCxkjQDiGfAReblUpzcF)
  xbmcplugin.endOfDirectory(gworSyJHIYMCxkjQDiGfAReblUpzam._addon_handle)
 def login_main(gworSyJHIYMCxkjQDiGfAReblUpzam):
  (gworSyJHIYMCxkjQDiGfAReblUpzcX,gworSyJHIYMCxkjQDiGfAReblUpzva,gworSyJHIYMCxkjQDiGfAReblUpzvc,gworSyJHIYMCxkjQDiGfAReblUpzvd)=gworSyJHIYMCxkjQDiGfAReblUpzam.get_settings_login_info()
  if not(gworSyJHIYMCxkjQDiGfAReblUpzcX and gworSyJHIYMCxkjQDiGfAReblUpzva):
   gworSyJHIYMCxkjQDiGfAReblUpzaW=xbmcgui.Dialog()
   gworSyJHIYMCxkjQDiGfAReblUpzvP=gworSyJHIYMCxkjQDiGfAReblUpzaW.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if gworSyJHIYMCxkjQDiGfAReblUpzvP==gworSyJHIYMCxkjQDiGfAReblUpzNK:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if gworSyJHIYMCxkjQDiGfAReblUpzam.get_winEpisodeOrderby()=='':
   gworSyJHIYMCxkjQDiGfAReblUpzam.set_winEpisodeOrderby('desc')
  if gworSyJHIYMCxkjQDiGfAReblUpzam.cookiefile_check():return
  gworSyJHIYMCxkjQDiGfAReblUpzvt =gworSyJHIYMCxkjQDiGfAReblUpzNL(gworSyJHIYMCxkjQDiGfAReblUpzam.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  gworSyJHIYMCxkjQDiGfAReblUpzvL=xbmcgui.Window(10000).getProperty('TVING_M_LOGINTIME')
  if gworSyJHIYMCxkjQDiGfAReblUpzvL==gworSyJHIYMCxkjQDiGfAReblUpzNt or gworSyJHIYMCxkjQDiGfAReblUpzvL=='':
   gworSyJHIYMCxkjQDiGfAReblUpzvL=gworSyJHIYMCxkjQDiGfAReblUpzNL('19000101')
  else:
   gworSyJHIYMCxkjQDiGfAReblUpzvL=gworSyJHIYMCxkjQDiGfAReblUpzNL(re.sub('-','',gworSyJHIYMCxkjQDiGfAReblUpzvL))
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   gworSyJHIYMCxkjQDiGfAReblUpzvN=0
   while gworSyJHIYMCxkjQDiGfAReblUpzNK:
    gworSyJHIYMCxkjQDiGfAReblUpzvN+=1
    time.sleep(0.05)
    if gworSyJHIYMCxkjQDiGfAReblUpzvL>=gworSyJHIYMCxkjQDiGfAReblUpzvt:return
    if gworSyJHIYMCxkjQDiGfAReblUpzvN>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  if gworSyJHIYMCxkjQDiGfAReblUpzvL>=gworSyJHIYMCxkjQDiGfAReblUpzvt:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   return
  if not gworSyJHIYMCxkjQDiGfAReblUpzam.TvingObj.GetCredential(gworSyJHIYMCxkjQDiGfAReblUpzcX,gworSyJHIYMCxkjQDiGfAReblUpzva,gworSyJHIYMCxkjQDiGfAReblUpzvc,gworSyJHIYMCxkjQDiGfAReblUpzvd):
   gworSyJHIYMCxkjQDiGfAReblUpzam.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   sys.exit()
  gworSyJHIYMCxkjQDiGfAReblUpzam.set_winCredential(gworSyJHIYMCxkjQDiGfAReblUpzam.TvingObj.LoadCredential())
  gworSyJHIYMCxkjQDiGfAReblUpzam.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
 def dp_Title_Group(gworSyJHIYMCxkjQDiGfAReblUpzam,gworSyJHIYMCxkjQDiGfAReblUpzvm):
  gworSyJHIYMCxkjQDiGfAReblUpzvK=gworSyJHIYMCxkjQDiGfAReblUpzvm.get('stype')
  if gworSyJHIYMCxkjQDiGfAReblUpzvK=='live':
   gworSyJHIYMCxkjQDiGfAReblUpzvs=gworSyJHIYMCxkjQDiGfAReblUpzad
  elif gworSyJHIYMCxkjQDiGfAReblUpzvK=='vod':
   gworSyJHIYMCxkjQDiGfAReblUpzvs=gworSyJHIYMCxkjQDiGfAReblUpzaL
  else:
   gworSyJHIYMCxkjQDiGfAReblUpzvs=gworSyJHIYMCxkjQDiGfAReblUpzaN
  for gworSyJHIYMCxkjQDiGfAReblUpzvn in gworSyJHIYMCxkjQDiGfAReblUpzvs:
   gworSyJHIYMCxkjQDiGfAReblUpzcm=gworSyJHIYMCxkjQDiGfAReblUpzvn.get('title')
   if gworSyJHIYMCxkjQDiGfAReblUpzvm.get('ordernm')!='-':
    gworSyJHIYMCxkjQDiGfAReblUpzcm+='  ('+gworSyJHIYMCxkjQDiGfAReblUpzvm.get('ordernm')+')'
   gworSyJHIYMCxkjQDiGfAReblUpzcV={'mode':gworSyJHIYMCxkjQDiGfAReblUpzvn.get('mode'),'stype':gworSyJHIYMCxkjQDiGfAReblUpzvn.get('stype'),'orderby':gworSyJHIYMCxkjQDiGfAReblUpzvm.get('orderby'),'ordernm':gworSyJHIYMCxkjQDiGfAReblUpzvm.get('ordernm'),'page':'1'}
   gworSyJHIYMCxkjQDiGfAReblUpzam.add_dir(gworSyJHIYMCxkjQDiGfAReblUpzcm,sublabel='',img='',infoLabels=gworSyJHIYMCxkjQDiGfAReblUpzNt,isFolder=gworSyJHIYMCxkjQDiGfAReblUpzNK,params=gworSyJHIYMCxkjQDiGfAReblUpzcV)
  if gworSyJHIYMCxkjQDiGfAReblUpzNq(gworSyJHIYMCxkjQDiGfAReblUpzvs)>0:xbmcplugin.endOfDirectory(gworSyJHIYMCxkjQDiGfAReblUpzam._addon_handle)
 def dp_SubTitle_Group(gworSyJHIYMCxkjQDiGfAReblUpzam,gworSyJHIYMCxkjQDiGfAReblUpzvm): 
  for gworSyJHIYMCxkjQDiGfAReblUpzvn in gworSyJHIYMCxkjQDiGfAReblUpzaK:
   gworSyJHIYMCxkjQDiGfAReblUpzcm=gworSyJHIYMCxkjQDiGfAReblUpzvn.get('title')
   if gworSyJHIYMCxkjQDiGfAReblUpzvm.get('ordernm')!='-':
    gworSyJHIYMCxkjQDiGfAReblUpzcm+='  ('+gworSyJHIYMCxkjQDiGfAReblUpzvm.get('ordernm')+')'
   gworSyJHIYMCxkjQDiGfAReblUpzcV={'mode':gworSyJHIYMCxkjQDiGfAReblUpzvn.get('mode'),'genreCode':gworSyJHIYMCxkjQDiGfAReblUpzvn.get('genreCode'),'stype':gworSyJHIYMCxkjQDiGfAReblUpzvm.get('stype'),'orderby':gworSyJHIYMCxkjQDiGfAReblUpzvm.get('orderby'),'page':'1'}
   gworSyJHIYMCxkjQDiGfAReblUpzam.add_dir(gworSyJHIYMCxkjQDiGfAReblUpzcm,sublabel='',img='',infoLabels=gworSyJHIYMCxkjQDiGfAReblUpzNt,isFolder=gworSyJHIYMCxkjQDiGfAReblUpzNK,params=gworSyJHIYMCxkjQDiGfAReblUpzcV)
  if gworSyJHIYMCxkjQDiGfAReblUpzNq(gworSyJHIYMCxkjQDiGfAReblUpzaK)>0:xbmcplugin.endOfDirectory(gworSyJHIYMCxkjQDiGfAReblUpzam._addon_handle)
 def dp_LiveChannel_List(gworSyJHIYMCxkjQDiGfAReblUpzam,gworSyJHIYMCxkjQDiGfAReblUpzvm):
  gworSyJHIYMCxkjQDiGfAReblUpzam.TvingObj.SaveCredential(gworSyJHIYMCxkjQDiGfAReblUpzam.get_winCredential())
  gworSyJHIYMCxkjQDiGfAReblUpzvK =gworSyJHIYMCxkjQDiGfAReblUpzvm.get('stype')
  gworSyJHIYMCxkjQDiGfAReblUpzvq =gworSyJHIYMCxkjQDiGfAReblUpzNL(gworSyJHIYMCxkjQDiGfAReblUpzvm.get('page'))
  gworSyJHIYMCxkjQDiGfAReblUpzvT,gworSyJHIYMCxkjQDiGfAReblUpzvB=gworSyJHIYMCxkjQDiGfAReblUpzam.TvingObj.GetLiveChannelList(gworSyJHIYMCxkjQDiGfAReblUpzvK,gworSyJHIYMCxkjQDiGfAReblUpzvq)
  for gworSyJHIYMCxkjQDiGfAReblUpzvh in gworSyJHIYMCxkjQDiGfAReblUpzvT:
   gworSyJHIYMCxkjQDiGfAReblUpzcm =gworSyJHIYMCxkjQDiGfAReblUpzvh.get('title')
   gworSyJHIYMCxkjQDiGfAReblUpzcE =gworSyJHIYMCxkjQDiGfAReblUpzvh.get('channel')
   gworSyJHIYMCxkjQDiGfAReblUpzvW =gworSyJHIYMCxkjQDiGfAReblUpzvh.get('thumbnail')
   gworSyJHIYMCxkjQDiGfAReblUpzvO =gworSyJHIYMCxkjQDiGfAReblUpzvh.get('synopsis')
   gworSyJHIYMCxkjQDiGfAReblUpzvV =gworSyJHIYMCxkjQDiGfAReblUpzvh.get('channelepg')
   gworSyJHIYMCxkjQDiGfAReblUpzvu =gworSyJHIYMCxkjQDiGfAReblUpzvh.get('cast')
   gworSyJHIYMCxkjQDiGfAReblUpzvF =gworSyJHIYMCxkjQDiGfAReblUpzvh.get('director')
   gworSyJHIYMCxkjQDiGfAReblUpzvE =gworSyJHIYMCxkjQDiGfAReblUpzvh.get('info_genre')
   gworSyJHIYMCxkjQDiGfAReblUpzvX =gworSyJHIYMCxkjQDiGfAReblUpzvh.get('year')
   gworSyJHIYMCxkjQDiGfAReblUpzda =gworSyJHIYMCxkjQDiGfAReblUpzvh.get('mpaa')
   gworSyJHIYMCxkjQDiGfAReblUpzdc =gworSyJHIYMCxkjQDiGfAReblUpzvh.get('premiered')
   gworSyJHIYMCxkjQDiGfAReblUpzdv={'mediatype':'episode','title':gworSyJHIYMCxkjQDiGfAReblUpzcm,'studio':gworSyJHIYMCxkjQDiGfAReblUpzcE,'cast':gworSyJHIYMCxkjQDiGfAReblUpzvu,'director':gworSyJHIYMCxkjQDiGfAReblUpzvF,'genre':gworSyJHIYMCxkjQDiGfAReblUpzvE,'plot':'%s\n%s\n%s\n\n%s'%(gworSyJHIYMCxkjQDiGfAReblUpzcE,gworSyJHIYMCxkjQDiGfAReblUpzcm,gworSyJHIYMCxkjQDiGfAReblUpzvV,gworSyJHIYMCxkjQDiGfAReblUpzvO),'year':gworSyJHIYMCxkjQDiGfAReblUpzvX,'mpaa':gworSyJHIYMCxkjQDiGfAReblUpzda,'premiered':gworSyJHIYMCxkjQDiGfAReblUpzdc}
   gworSyJHIYMCxkjQDiGfAReblUpzcV={'mode':'LIVE','mediacode':gworSyJHIYMCxkjQDiGfAReblUpzvh.get('mediacode'),'stype':gworSyJHIYMCxkjQDiGfAReblUpzvK}
   gworSyJHIYMCxkjQDiGfAReblUpzam.add_dir(gworSyJHIYMCxkjQDiGfAReblUpzcE,sublabel=gworSyJHIYMCxkjQDiGfAReblUpzcm,img=gworSyJHIYMCxkjQDiGfAReblUpzvW,infoLabels=gworSyJHIYMCxkjQDiGfAReblUpzdv,isFolder=gworSyJHIYMCxkjQDiGfAReblUpzNs,params=gworSyJHIYMCxkjQDiGfAReblUpzcV)
  if gworSyJHIYMCxkjQDiGfAReblUpzvB:
   gworSyJHIYMCxkjQDiGfAReblUpzcV['mode']='CHANNEL' 
   gworSyJHIYMCxkjQDiGfAReblUpzcV['stype']=gworSyJHIYMCxkjQDiGfAReblUpzvK 
   gworSyJHIYMCxkjQDiGfAReblUpzcV['page']=gworSyJHIYMCxkjQDiGfAReblUpzNT(gworSyJHIYMCxkjQDiGfAReblUpzvq+1)
   gworSyJHIYMCxkjQDiGfAReblUpzcm='[B]%s >>[/B]'%'다음 페이지'
   gworSyJHIYMCxkjQDiGfAReblUpzdP=gworSyJHIYMCxkjQDiGfAReblUpzNT(gworSyJHIYMCxkjQDiGfAReblUpzvq+1)
   gworSyJHIYMCxkjQDiGfAReblUpzcO=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   gworSyJHIYMCxkjQDiGfAReblUpzam.add_dir(gworSyJHIYMCxkjQDiGfAReblUpzcm,sublabel=gworSyJHIYMCxkjQDiGfAReblUpzdP,img=gworSyJHIYMCxkjQDiGfAReblUpzcO,infoLabels=gworSyJHIYMCxkjQDiGfAReblUpzNt,isFolder=gworSyJHIYMCxkjQDiGfAReblUpzNK,params=gworSyJHIYMCxkjQDiGfAReblUpzcV)
  if gworSyJHIYMCxkjQDiGfAReblUpzNq(gworSyJHIYMCxkjQDiGfAReblUpzvT)>0:xbmcplugin.endOfDirectory(gworSyJHIYMCxkjQDiGfAReblUpzam._addon_handle,cacheToDisc=gworSyJHIYMCxkjQDiGfAReblUpzNs)
 def dp_Program_List(gworSyJHIYMCxkjQDiGfAReblUpzam,gworSyJHIYMCxkjQDiGfAReblUpzvm):
  gworSyJHIYMCxkjQDiGfAReblUpzam.TvingObj.SaveCredential(gworSyJHIYMCxkjQDiGfAReblUpzam.get_winCredential())
  gworSyJHIYMCxkjQDiGfAReblUpzdt =gworSyJHIYMCxkjQDiGfAReblUpzvm.get('stype')
  gworSyJHIYMCxkjQDiGfAReblUpzdL =gworSyJHIYMCxkjQDiGfAReblUpzvm.get('orderby')
  gworSyJHIYMCxkjQDiGfAReblUpzvq =gworSyJHIYMCxkjQDiGfAReblUpzNL(gworSyJHIYMCxkjQDiGfAReblUpzvm.get('page'))
  gworSyJHIYMCxkjQDiGfAReblUpzdN=gworSyJHIYMCxkjQDiGfAReblUpzvm.get('genreCode')
  if gworSyJHIYMCxkjQDiGfAReblUpzdN==gworSyJHIYMCxkjQDiGfAReblUpzNt:gworSyJHIYMCxkjQDiGfAReblUpzdN='all'
  gworSyJHIYMCxkjQDiGfAReblUpzdK,gworSyJHIYMCxkjQDiGfAReblUpzvB=gworSyJHIYMCxkjQDiGfAReblUpzam.TvingObj.GetProgramList(gworSyJHIYMCxkjQDiGfAReblUpzdt,gworSyJHIYMCxkjQDiGfAReblUpzdL,gworSyJHIYMCxkjQDiGfAReblUpzvq,gworSyJHIYMCxkjQDiGfAReblUpzdN)
  for gworSyJHIYMCxkjQDiGfAReblUpzds in gworSyJHIYMCxkjQDiGfAReblUpzdK:
   gworSyJHIYMCxkjQDiGfAReblUpzcm =gworSyJHIYMCxkjQDiGfAReblUpzds.get('title')
   gworSyJHIYMCxkjQDiGfAReblUpzvW =gworSyJHIYMCxkjQDiGfAReblUpzds.get('thumbnail')
   gworSyJHIYMCxkjQDiGfAReblUpzvO =gworSyJHIYMCxkjQDiGfAReblUpzds.get('synopsis')
   gworSyJHIYMCxkjQDiGfAReblUpzdn =gworSyJHIYMCxkjQDiGfAReblUpzds.get('channel')
   gworSyJHIYMCxkjQDiGfAReblUpzvu =gworSyJHIYMCxkjQDiGfAReblUpzds.get('cast')
   gworSyJHIYMCxkjQDiGfAReblUpzvF =gworSyJHIYMCxkjQDiGfAReblUpzds.get('director')
   gworSyJHIYMCxkjQDiGfAReblUpzvE=gworSyJHIYMCxkjQDiGfAReblUpzds.get('info_genre')
   gworSyJHIYMCxkjQDiGfAReblUpzvX =gworSyJHIYMCxkjQDiGfAReblUpzds.get('year')
   gworSyJHIYMCxkjQDiGfAReblUpzdc =gworSyJHIYMCxkjQDiGfAReblUpzds.get('premiered')
   gworSyJHIYMCxkjQDiGfAReblUpzda =gworSyJHIYMCxkjQDiGfAReblUpzds.get('mpaa')
   gworSyJHIYMCxkjQDiGfAReblUpzdv={'mediatype':'tvshow','title':gworSyJHIYMCxkjQDiGfAReblUpzcm,'studio':gworSyJHIYMCxkjQDiGfAReblUpzdn,'cast':gworSyJHIYMCxkjQDiGfAReblUpzvu,'director':gworSyJHIYMCxkjQDiGfAReblUpzvF,'genre':gworSyJHIYMCxkjQDiGfAReblUpzvE,'year':gworSyJHIYMCxkjQDiGfAReblUpzvX,'premiered':gworSyJHIYMCxkjQDiGfAReblUpzdc,'mpaa':gworSyJHIYMCxkjQDiGfAReblUpzda,'plot':gworSyJHIYMCxkjQDiGfAReblUpzvO}
   gworSyJHIYMCxkjQDiGfAReblUpzcV={'mode':'EPISODE','programcode':gworSyJHIYMCxkjQDiGfAReblUpzds.get('program'),'page':'1'}
   if gworSyJHIYMCxkjQDiGfAReblUpzam.get_settings_makebookmark():
    gworSyJHIYMCxkjQDiGfAReblUpzdm={'videoid':gworSyJHIYMCxkjQDiGfAReblUpzds.get('program'),'vidtype':'tvshow','vtitle':gworSyJHIYMCxkjQDiGfAReblUpzcm,'vsubtitle':gworSyJHIYMCxkjQDiGfAReblUpzdn,}
    gworSyJHIYMCxkjQDiGfAReblUpzdq=json.dumps(gworSyJHIYMCxkjQDiGfAReblUpzdm)
    gworSyJHIYMCxkjQDiGfAReblUpzdq=urllib.parse.quote(gworSyJHIYMCxkjQDiGfAReblUpzdq)
    gworSyJHIYMCxkjQDiGfAReblUpzdT='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(gworSyJHIYMCxkjQDiGfAReblUpzdq)
    gworSyJHIYMCxkjQDiGfAReblUpzdB=[('(통합) 찜 영상에 추가',gworSyJHIYMCxkjQDiGfAReblUpzdT)]
   else:
    gworSyJHIYMCxkjQDiGfAReblUpzdB=gworSyJHIYMCxkjQDiGfAReblUpzNt
   gworSyJHIYMCxkjQDiGfAReblUpzam.add_dir(gworSyJHIYMCxkjQDiGfAReblUpzcm,sublabel=gworSyJHIYMCxkjQDiGfAReblUpzdn,img=gworSyJHIYMCxkjQDiGfAReblUpzvW,infoLabels=gworSyJHIYMCxkjQDiGfAReblUpzdv,isFolder=gworSyJHIYMCxkjQDiGfAReblUpzNK,params=gworSyJHIYMCxkjQDiGfAReblUpzcV,ContextMenu=gworSyJHIYMCxkjQDiGfAReblUpzdB)
  if gworSyJHIYMCxkjQDiGfAReblUpzvB:
   gworSyJHIYMCxkjQDiGfAReblUpzcV['mode'] ='PROGRAM' 
   gworSyJHIYMCxkjQDiGfAReblUpzcV['stype'] =gworSyJHIYMCxkjQDiGfAReblUpzdt
   gworSyJHIYMCxkjQDiGfAReblUpzcV['orderby'] =gworSyJHIYMCxkjQDiGfAReblUpzdL
   gworSyJHIYMCxkjQDiGfAReblUpzcV['page'] =gworSyJHIYMCxkjQDiGfAReblUpzNT(gworSyJHIYMCxkjQDiGfAReblUpzvq+1)
   gworSyJHIYMCxkjQDiGfAReblUpzcV['genreCode']=gworSyJHIYMCxkjQDiGfAReblUpzdN 
   gworSyJHIYMCxkjQDiGfAReblUpzcm='[B]%s >>[/B]'%'다음 페이지'
   gworSyJHIYMCxkjQDiGfAReblUpzdP=gworSyJHIYMCxkjQDiGfAReblUpzNT(gworSyJHIYMCxkjQDiGfAReblUpzvq+1)
   gworSyJHIYMCxkjQDiGfAReblUpzcO=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   gworSyJHIYMCxkjQDiGfAReblUpzam.add_dir(gworSyJHIYMCxkjQDiGfAReblUpzcm,sublabel=gworSyJHIYMCxkjQDiGfAReblUpzdP,img=gworSyJHIYMCxkjQDiGfAReblUpzcO,infoLabels=gworSyJHIYMCxkjQDiGfAReblUpzNt,isFolder=gworSyJHIYMCxkjQDiGfAReblUpzNK,params=gworSyJHIYMCxkjQDiGfAReblUpzcV)
  xbmcplugin.setContent(gworSyJHIYMCxkjQDiGfAReblUpzam._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(gworSyJHIYMCxkjQDiGfAReblUpzam._addon_handle,cacheToDisc=gworSyJHIYMCxkjQDiGfAReblUpzNs)
 def dp_Episode_List(gworSyJHIYMCxkjQDiGfAReblUpzam,gworSyJHIYMCxkjQDiGfAReblUpzvm):
  gworSyJHIYMCxkjQDiGfAReblUpzam.TvingObj.SaveCredential(gworSyJHIYMCxkjQDiGfAReblUpzam.get_winCredential())
  gworSyJHIYMCxkjQDiGfAReblUpzdW=gworSyJHIYMCxkjQDiGfAReblUpzvm.get('programcode')
  gworSyJHIYMCxkjQDiGfAReblUpzvq =gworSyJHIYMCxkjQDiGfAReblUpzNL(gworSyJHIYMCxkjQDiGfAReblUpzvm.get('page'))
  gworSyJHIYMCxkjQDiGfAReblUpzdO,gworSyJHIYMCxkjQDiGfAReblUpzvB,gworSyJHIYMCxkjQDiGfAReblUpzdV=gworSyJHIYMCxkjQDiGfAReblUpzam.TvingObj.GetEpisodeList(gworSyJHIYMCxkjQDiGfAReblUpzdW,gworSyJHIYMCxkjQDiGfAReblUpzvq,orderby=gworSyJHIYMCxkjQDiGfAReblUpzam.get_winEpisodeOrderby())
  for gworSyJHIYMCxkjQDiGfAReblUpzdu in gworSyJHIYMCxkjQDiGfAReblUpzdO:
   gworSyJHIYMCxkjQDiGfAReblUpzcm =gworSyJHIYMCxkjQDiGfAReblUpzdu.get('title')
   gworSyJHIYMCxkjQDiGfAReblUpzdP =gworSyJHIYMCxkjQDiGfAReblUpzdu.get('subtitle')
   gworSyJHIYMCxkjQDiGfAReblUpzvW =gworSyJHIYMCxkjQDiGfAReblUpzdu.get('thumbnail')
   gworSyJHIYMCxkjQDiGfAReblUpzvO =gworSyJHIYMCxkjQDiGfAReblUpzdu.get('synopsis')
   gworSyJHIYMCxkjQDiGfAReblUpzdF=gworSyJHIYMCxkjQDiGfAReblUpzdu.get('info_title')
   gworSyJHIYMCxkjQDiGfAReblUpzdE =gworSyJHIYMCxkjQDiGfAReblUpzdu.get('aired')
   gworSyJHIYMCxkjQDiGfAReblUpzdX =gworSyJHIYMCxkjQDiGfAReblUpzdu.get('studio')
   gworSyJHIYMCxkjQDiGfAReblUpzPa =gworSyJHIYMCxkjQDiGfAReblUpzdu.get('frequency')
   gworSyJHIYMCxkjQDiGfAReblUpzdv={'mediatype':'episode','title':gworSyJHIYMCxkjQDiGfAReblUpzdF,'aired':gworSyJHIYMCxkjQDiGfAReblUpzdE,'studio':gworSyJHIYMCxkjQDiGfAReblUpzdX,'episode':gworSyJHIYMCxkjQDiGfAReblUpzPa,'plot':gworSyJHIYMCxkjQDiGfAReblUpzvO}
   gworSyJHIYMCxkjQDiGfAReblUpzcV={'mode':'VOD','mediacode':gworSyJHIYMCxkjQDiGfAReblUpzdu.get('episode'),'stype':'vod','programcode':gworSyJHIYMCxkjQDiGfAReblUpzdW,'title':gworSyJHIYMCxkjQDiGfAReblUpzcm,'thumbnail':gworSyJHIYMCxkjQDiGfAReblUpzvW}
   gworSyJHIYMCxkjQDiGfAReblUpzam.add_dir(gworSyJHIYMCxkjQDiGfAReblUpzcm,sublabel=gworSyJHIYMCxkjQDiGfAReblUpzdP,img=gworSyJHIYMCxkjQDiGfAReblUpzvW,infoLabels=gworSyJHIYMCxkjQDiGfAReblUpzdv,isFolder=gworSyJHIYMCxkjQDiGfAReblUpzNs,params=gworSyJHIYMCxkjQDiGfAReblUpzcV)
  if gworSyJHIYMCxkjQDiGfAReblUpzvq==1:
   gworSyJHIYMCxkjQDiGfAReblUpzdv={'plot':'정렬순서를 변경합니다.'}
   gworSyJHIYMCxkjQDiGfAReblUpzcV={}
   gworSyJHIYMCxkjQDiGfAReblUpzcV['mode'] ='ORDER_BY' 
   if gworSyJHIYMCxkjQDiGfAReblUpzam.get_winEpisodeOrderby()=='desc':
    gworSyJHIYMCxkjQDiGfAReblUpzcm='정렬순서변경 : 최신화부터 -> 1회부터'
    gworSyJHIYMCxkjQDiGfAReblUpzcV['orderby']='asc'
   else:
    gworSyJHIYMCxkjQDiGfAReblUpzcm='정렬순서변경 : 1회부터 -> 최신화부터'
    gworSyJHIYMCxkjQDiGfAReblUpzcV['orderby']='desc'
   gworSyJHIYMCxkjQDiGfAReblUpzcO=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   gworSyJHIYMCxkjQDiGfAReblUpzam.add_dir(gworSyJHIYMCxkjQDiGfAReblUpzcm,sublabel='',img=gworSyJHIYMCxkjQDiGfAReblUpzcO,infoLabels=gworSyJHIYMCxkjQDiGfAReblUpzdv,isFolder=gworSyJHIYMCxkjQDiGfAReblUpzNs,params=gworSyJHIYMCxkjQDiGfAReblUpzcV,isLink=gworSyJHIYMCxkjQDiGfAReblUpzNK)
  if gworSyJHIYMCxkjQDiGfAReblUpzvB:
   gworSyJHIYMCxkjQDiGfAReblUpzcV['mode'] ='EPISODE' 
   gworSyJHIYMCxkjQDiGfAReblUpzcV['programcode']=gworSyJHIYMCxkjQDiGfAReblUpzdW
   gworSyJHIYMCxkjQDiGfAReblUpzcV['page'] =gworSyJHIYMCxkjQDiGfAReblUpzNT(gworSyJHIYMCxkjQDiGfAReblUpzvq+1)
   gworSyJHIYMCxkjQDiGfAReblUpzcm='[B]%s >>[/B]'%'다음 페이지'
   gworSyJHIYMCxkjQDiGfAReblUpzdP=gworSyJHIYMCxkjQDiGfAReblUpzNT(gworSyJHIYMCxkjQDiGfAReblUpzvq+1)
   gworSyJHIYMCxkjQDiGfAReblUpzcO=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   gworSyJHIYMCxkjQDiGfAReblUpzam.add_dir(gworSyJHIYMCxkjQDiGfAReblUpzcm,sublabel=gworSyJHIYMCxkjQDiGfAReblUpzdP,img=gworSyJHIYMCxkjQDiGfAReblUpzcO,infoLabels=gworSyJHIYMCxkjQDiGfAReblUpzNt,isFolder=gworSyJHIYMCxkjQDiGfAReblUpzNK,params=gworSyJHIYMCxkjQDiGfAReblUpzcV)
  xbmcplugin.setContent(gworSyJHIYMCxkjQDiGfAReblUpzam._addon_handle,'episodes')
  if gworSyJHIYMCxkjQDiGfAReblUpzNq(gworSyJHIYMCxkjQDiGfAReblUpzdO)>0:xbmcplugin.endOfDirectory(gworSyJHIYMCxkjQDiGfAReblUpzam._addon_handle,cacheToDisc=gworSyJHIYMCxkjQDiGfAReblUpzNK)
 def dp_setEpOrderby(gworSyJHIYMCxkjQDiGfAReblUpzam,gworSyJHIYMCxkjQDiGfAReblUpzvm):
  gworSyJHIYMCxkjQDiGfAReblUpzdL =gworSyJHIYMCxkjQDiGfAReblUpzvm.get('orderby')
  gworSyJHIYMCxkjQDiGfAReblUpzam.set_winEpisodeOrderby(gworSyJHIYMCxkjQDiGfAReblUpzdL)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(gworSyJHIYMCxkjQDiGfAReblUpzam,gworSyJHIYMCxkjQDiGfAReblUpzvm):
  gworSyJHIYMCxkjQDiGfAReblUpzam.TvingObj.SaveCredential(gworSyJHIYMCxkjQDiGfAReblUpzam.get_winCredential())
  gworSyJHIYMCxkjQDiGfAReblUpzdt =gworSyJHIYMCxkjQDiGfAReblUpzvm.get('stype')
  gworSyJHIYMCxkjQDiGfAReblUpzdL =gworSyJHIYMCxkjQDiGfAReblUpzvm.get('orderby')
  gworSyJHIYMCxkjQDiGfAReblUpzvq=gworSyJHIYMCxkjQDiGfAReblUpzNL(gworSyJHIYMCxkjQDiGfAReblUpzvm.get('page'))
  gworSyJHIYMCxkjQDiGfAReblUpzPc,gworSyJHIYMCxkjQDiGfAReblUpzvB=gworSyJHIYMCxkjQDiGfAReblUpzam.TvingObj.GetMovieList(gworSyJHIYMCxkjQDiGfAReblUpzdt,gworSyJHIYMCxkjQDiGfAReblUpzdL,gworSyJHIYMCxkjQDiGfAReblUpzvq)
  for gworSyJHIYMCxkjQDiGfAReblUpzPv in gworSyJHIYMCxkjQDiGfAReblUpzPc:
   gworSyJHIYMCxkjQDiGfAReblUpzcm =gworSyJHIYMCxkjQDiGfAReblUpzPv.get('title')
   gworSyJHIYMCxkjQDiGfAReblUpzvW =gworSyJHIYMCxkjQDiGfAReblUpzPv.get('thumbnail')
   gworSyJHIYMCxkjQDiGfAReblUpzvO =gworSyJHIYMCxkjQDiGfAReblUpzPv.get('synopsis')
   gworSyJHIYMCxkjQDiGfAReblUpzdF =gworSyJHIYMCxkjQDiGfAReblUpzPv.get('info_title')
   gworSyJHIYMCxkjQDiGfAReblUpzvX =gworSyJHIYMCxkjQDiGfAReblUpzPv.get('year')
   gworSyJHIYMCxkjQDiGfAReblUpzvu =gworSyJHIYMCxkjQDiGfAReblUpzPv.get('cast')
   gworSyJHIYMCxkjQDiGfAReblUpzvF =gworSyJHIYMCxkjQDiGfAReblUpzPv.get('director')
   gworSyJHIYMCxkjQDiGfAReblUpzvE =gworSyJHIYMCxkjQDiGfAReblUpzPv.get('info_genre')
   gworSyJHIYMCxkjQDiGfAReblUpzPd =gworSyJHIYMCxkjQDiGfAReblUpzPv.get('duration')
   gworSyJHIYMCxkjQDiGfAReblUpzdc =gworSyJHIYMCxkjQDiGfAReblUpzPv.get('premiered')
   gworSyJHIYMCxkjQDiGfAReblUpzdX =gworSyJHIYMCxkjQDiGfAReblUpzPv.get('studio')
   gworSyJHIYMCxkjQDiGfAReblUpzda =gworSyJHIYMCxkjQDiGfAReblUpzPv.get('mpaa')
   gworSyJHIYMCxkjQDiGfAReblUpzdv={'mediatype':'movie','title':gworSyJHIYMCxkjQDiGfAReblUpzdF,'year':gworSyJHIYMCxkjQDiGfAReblUpzvX,'cast':gworSyJHIYMCxkjQDiGfAReblUpzvu,'director':gworSyJHIYMCxkjQDiGfAReblUpzvF,'genre':gworSyJHIYMCxkjQDiGfAReblUpzvE,'duration':gworSyJHIYMCxkjQDiGfAReblUpzPd,'premiered':gworSyJHIYMCxkjQDiGfAReblUpzdc,'studio':gworSyJHIYMCxkjQDiGfAReblUpzdX,'mpaa':gworSyJHIYMCxkjQDiGfAReblUpzda,'plot':gworSyJHIYMCxkjQDiGfAReblUpzvO}
   gworSyJHIYMCxkjQDiGfAReblUpzcV={'mode':'MOVIE','mediacode':gworSyJHIYMCxkjQDiGfAReblUpzPv.get('moviecode'),'stype':'movie','title':gworSyJHIYMCxkjQDiGfAReblUpzcm,'thumbnail':gworSyJHIYMCxkjQDiGfAReblUpzvW}
   if gworSyJHIYMCxkjQDiGfAReblUpzam.get_settings_makebookmark():
    gworSyJHIYMCxkjQDiGfAReblUpzdm={'videoid':gworSyJHIYMCxkjQDiGfAReblUpzPv.get('moviecode'),'vidtype':'movie','vtitle':gworSyJHIYMCxkjQDiGfAReblUpzdF,'vsubtitle':'',}
    gworSyJHIYMCxkjQDiGfAReblUpzdq=json.dumps(gworSyJHIYMCxkjQDiGfAReblUpzdm)
    gworSyJHIYMCxkjQDiGfAReblUpzdq=urllib.parse.quote(gworSyJHIYMCxkjQDiGfAReblUpzdq)
    gworSyJHIYMCxkjQDiGfAReblUpzdT='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(gworSyJHIYMCxkjQDiGfAReblUpzdq)
    gworSyJHIYMCxkjQDiGfAReblUpzdB=[('(통합) 찜 영상에 추가',gworSyJHIYMCxkjQDiGfAReblUpzdT)]
   else:
    gworSyJHIYMCxkjQDiGfAReblUpzdB=gworSyJHIYMCxkjQDiGfAReblUpzNt
   gworSyJHIYMCxkjQDiGfAReblUpzam.add_dir(gworSyJHIYMCxkjQDiGfAReblUpzcm,sublabel='',img=gworSyJHIYMCxkjQDiGfAReblUpzvW,infoLabels=gworSyJHIYMCxkjQDiGfAReblUpzdv,isFolder=gworSyJHIYMCxkjQDiGfAReblUpzNs,params=gworSyJHIYMCxkjQDiGfAReblUpzcV,ContextMenu=gworSyJHIYMCxkjQDiGfAReblUpzdB)
  if gworSyJHIYMCxkjQDiGfAReblUpzvB:
   gworSyJHIYMCxkjQDiGfAReblUpzcV={}
   gworSyJHIYMCxkjQDiGfAReblUpzcV['mode'] ='MOVIE_SUB' 
   gworSyJHIYMCxkjQDiGfAReblUpzcV['orderby']=gworSyJHIYMCxkjQDiGfAReblUpzdL
   gworSyJHIYMCxkjQDiGfAReblUpzcV['stype'] =gworSyJHIYMCxkjQDiGfAReblUpzdt
   gworSyJHIYMCxkjQDiGfAReblUpzcV['page'] =gworSyJHIYMCxkjQDiGfAReblUpzNT(gworSyJHIYMCxkjQDiGfAReblUpzvq+1)
   gworSyJHIYMCxkjQDiGfAReblUpzcm='[B]%s >>[/B]'%'다음 페이지'
   gworSyJHIYMCxkjQDiGfAReblUpzdP=gworSyJHIYMCxkjQDiGfAReblUpzNT(gworSyJHIYMCxkjQDiGfAReblUpzvq+1)
   gworSyJHIYMCxkjQDiGfAReblUpzcO=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   gworSyJHIYMCxkjQDiGfAReblUpzam.add_dir(gworSyJHIYMCxkjQDiGfAReblUpzcm,sublabel=gworSyJHIYMCxkjQDiGfAReblUpzdP,img=gworSyJHIYMCxkjQDiGfAReblUpzcO,infoLabels=gworSyJHIYMCxkjQDiGfAReblUpzNt,isFolder=gworSyJHIYMCxkjQDiGfAReblUpzNK,params=gworSyJHIYMCxkjQDiGfAReblUpzcV)
  xbmcplugin.setContent(gworSyJHIYMCxkjQDiGfAReblUpzam._addon_handle,'movies')
  xbmcplugin.endOfDirectory(gworSyJHIYMCxkjQDiGfAReblUpzam._addon_handle,cacheToDisc=gworSyJHIYMCxkjQDiGfAReblUpzNs)
 def dp_Set_Bookmark(gworSyJHIYMCxkjQDiGfAReblUpzam,gworSyJHIYMCxkjQDiGfAReblUpzvm):
  gworSyJHIYMCxkjQDiGfAReblUpzPt=urllib.parse.unquote(gworSyJHIYMCxkjQDiGfAReblUpzvm.get('bm_param'))
  gworSyJHIYMCxkjQDiGfAReblUpzPt=json.loads(gworSyJHIYMCxkjQDiGfAReblUpzPt)
  gworSyJHIYMCxkjQDiGfAReblUpzPL =gworSyJHIYMCxkjQDiGfAReblUpzPt.get('videoid')
  gworSyJHIYMCxkjQDiGfAReblUpzPN =gworSyJHIYMCxkjQDiGfAReblUpzPt.get('vidtype')
  gworSyJHIYMCxkjQDiGfAReblUpzPK =gworSyJHIYMCxkjQDiGfAReblUpzPt.get('vtitle')
  gworSyJHIYMCxkjQDiGfAReblUpzPs =gworSyJHIYMCxkjQDiGfAReblUpzPt.get('vsubtitle')
  gworSyJHIYMCxkjQDiGfAReblUpzaW=xbmcgui.Dialog()
  gworSyJHIYMCxkjQDiGfAReblUpzvP=gworSyJHIYMCxkjQDiGfAReblUpzaW.yesno(__language__(30913).encode('utf8'),gworSyJHIYMCxkjQDiGfAReblUpzPK+' \n\n'+__language__(30914))
  if gworSyJHIYMCxkjQDiGfAReblUpzvP==gworSyJHIYMCxkjQDiGfAReblUpzNs:return
  gworSyJHIYMCxkjQDiGfAReblUpzPn=gworSyJHIYMCxkjQDiGfAReblUpzam.TvingObj.GetBookmarkInfo(gworSyJHIYMCxkjQDiGfAReblUpzPL,gworSyJHIYMCxkjQDiGfAReblUpzPN)
  if gworSyJHIYMCxkjQDiGfAReblUpzPs!='':
   gworSyJHIYMCxkjQDiGfAReblUpzPn['saveinfo']['subtitle']=gworSyJHIYMCxkjQDiGfAReblUpzPs 
   if gworSyJHIYMCxkjQDiGfAReblUpzPN=='tvshow':gworSyJHIYMCxkjQDiGfAReblUpzPn['saveinfo']['infoLabels']['studio']=gworSyJHIYMCxkjQDiGfAReblUpzPs 
  gworSyJHIYMCxkjQDiGfAReblUpzPm=json.dumps(gworSyJHIYMCxkjQDiGfAReblUpzPn)
  gworSyJHIYMCxkjQDiGfAReblUpzPm=urllib.parse.quote(gworSyJHIYMCxkjQDiGfAReblUpzPm)
  gworSyJHIYMCxkjQDiGfAReblUpzdT ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(gworSyJHIYMCxkjQDiGfAReblUpzPm)
  xbmc.executebuiltin(gworSyJHIYMCxkjQDiGfAReblUpzdT)
 def dp_Search_Group(gworSyJHIYMCxkjQDiGfAReblUpzam,gworSyJHIYMCxkjQDiGfAReblUpzvm):
  if 'search_key' in gworSyJHIYMCxkjQDiGfAReblUpzvm:
   gworSyJHIYMCxkjQDiGfAReblUpzPq=gworSyJHIYMCxkjQDiGfAReblUpzvm.get('search_key')
  else:
   gworSyJHIYMCxkjQDiGfAReblUpzPq=gworSyJHIYMCxkjQDiGfAReblUpzam.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not gworSyJHIYMCxkjQDiGfAReblUpzPq:
    return
  for gworSyJHIYMCxkjQDiGfAReblUpzvn in gworSyJHIYMCxkjQDiGfAReblUpzat:
   gworSyJHIYMCxkjQDiGfAReblUpzPT =gworSyJHIYMCxkjQDiGfAReblUpzvn.get('mode')
   gworSyJHIYMCxkjQDiGfAReblUpzvK=gworSyJHIYMCxkjQDiGfAReblUpzvn.get('stype')
   gworSyJHIYMCxkjQDiGfAReblUpzcm=gworSyJHIYMCxkjQDiGfAReblUpzvn.get('title')
   (gworSyJHIYMCxkjQDiGfAReblUpzPB,gworSyJHIYMCxkjQDiGfAReblUpzvB)=gworSyJHIYMCxkjQDiGfAReblUpzam.TvingObj.GetSearchList(gworSyJHIYMCxkjQDiGfAReblUpzPq,1,gworSyJHIYMCxkjQDiGfAReblUpzvK)
   gworSyJHIYMCxkjQDiGfAReblUpzPh={'plot':'검색어 : '+gworSyJHIYMCxkjQDiGfAReblUpzPq+'\n\n'+gworSyJHIYMCxkjQDiGfAReblUpzam.Search_FreeList(gworSyJHIYMCxkjQDiGfAReblUpzPB)}
   gworSyJHIYMCxkjQDiGfAReblUpzcV={'mode':gworSyJHIYMCxkjQDiGfAReblUpzPT,'stype':gworSyJHIYMCxkjQDiGfAReblUpzvK,'search_key':gworSyJHIYMCxkjQDiGfAReblUpzPq,'page':'1',}
   gworSyJHIYMCxkjQDiGfAReblUpzam.add_dir(gworSyJHIYMCxkjQDiGfAReblUpzcm,sublabel='',img='',infoLabels=gworSyJHIYMCxkjQDiGfAReblUpzPh,isFolder=gworSyJHIYMCxkjQDiGfAReblUpzNK,params=gworSyJHIYMCxkjQDiGfAReblUpzcV)
  if gworSyJHIYMCxkjQDiGfAReblUpzNq(gworSyJHIYMCxkjQDiGfAReblUpzat)>0:xbmcplugin.endOfDirectory(gworSyJHIYMCxkjQDiGfAReblUpzam._addon_handle,cacheToDisc=gworSyJHIYMCxkjQDiGfAReblUpzNK)
  gworSyJHIYMCxkjQDiGfAReblUpzam.Save_Searched_List(gworSyJHIYMCxkjQDiGfAReblUpzPq)
 def Search_FreeList(gworSyJHIYMCxkjQDiGfAReblUpzam,gworSyJHIYMCxkjQDiGfAReblUpztc):
  gworSyJHIYMCxkjQDiGfAReblUpzPW=''
  gworSyJHIYMCxkjQDiGfAReblUpzPO=7
  try:
   if gworSyJHIYMCxkjQDiGfAReblUpzNq(gworSyJHIYMCxkjQDiGfAReblUpztc)==0:return '검색결과 없음'
   for i in gworSyJHIYMCxkjQDiGfAReblUpzNB(gworSyJHIYMCxkjQDiGfAReblUpzNq(gworSyJHIYMCxkjQDiGfAReblUpztc)):
    if i>=gworSyJHIYMCxkjQDiGfAReblUpzPO:
     gworSyJHIYMCxkjQDiGfAReblUpzPW=gworSyJHIYMCxkjQDiGfAReblUpzPW+'...'
     break
    gworSyJHIYMCxkjQDiGfAReblUpzPW=gworSyJHIYMCxkjQDiGfAReblUpzPW+gworSyJHIYMCxkjQDiGfAReblUpztc[i]['title']+'\n'
  except:
   return ''
  return gworSyJHIYMCxkjQDiGfAReblUpzPW
 def dp_Search_History(gworSyJHIYMCxkjQDiGfAReblUpzam,gworSyJHIYMCxkjQDiGfAReblUpzvm):
  gworSyJHIYMCxkjQDiGfAReblUpzPV=gworSyJHIYMCxkjQDiGfAReblUpzam.Load_List_File('search')
  for gworSyJHIYMCxkjQDiGfAReblUpzPu in gworSyJHIYMCxkjQDiGfAReblUpzPV:
   gworSyJHIYMCxkjQDiGfAReblUpzPF=gworSyJHIYMCxkjQDiGfAReblUpzNm(urllib.parse.parse_qsl(gworSyJHIYMCxkjQDiGfAReblUpzPu))
   gworSyJHIYMCxkjQDiGfAReblUpzPE=gworSyJHIYMCxkjQDiGfAReblUpzPF.get('skey').strip()
   gworSyJHIYMCxkjQDiGfAReblUpzcV={'mode':'SEARCH_GROUP','search_key':gworSyJHIYMCxkjQDiGfAReblUpzPE,}
   gworSyJHIYMCxkjQDiGfAReblUpzPX={'mode':'SEARCH_REMOVE','stype':'ONE','skey':gworSyJHIYMCxkjQDiGfAReblUpzPE,}
   gworSyJHIYMCxkjQDiGfAReblUpzta=urllib.parse.urlencode(gworSyJHIYMCxkjQDiGfAReblUpzPX)
   gworSyJHIYMCxkjQDiGfAReblUpzdB=[('선택된 검색어 ( %s ) 삭제'%(gworSyJHIYMCxkjQDiGfAReblUpzPE),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(gworSyJHIYMCxkjQDiGfAReblUpzta))]
   gworSyJHIYMCxkjQDiGfAReblUpzam.add_dir(gworSyJHIYMCxkjQDiGfAReblUpzPE,sublabel='',img=gworSyJHIYMCxkjQDiGfAReblUpzNt,infoLabels=gworSyJHIYMCxkjQDiGfAReblUpzNt,isFolder=gworSyJHIYMCxkjQDiGfAReblUpzNK,params=gworSyJHIYMCxkjQDiGfAReblUpzcV,ContextMenu=gworSyJHIYMCxkjQDiGfAReblUpzdB)
  gworSyJHIYMCxkjQDiGfAReblUpzdv={'plot':'검색목록 전체를 삭제합니다.'}
  gworSyJHIYMCxkjQDiGfAReblUpzcm='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  gworSyJHIYMCxkjQDiGfAReblUpzcV={'mode':'SEARCH_REMOVE','stype':'ALL','skey':'-',}
  gworSyJHIYMCxkjQDiGfAReblUpzcO=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  gworSyJHIYMCxkjQDiGfAReblUpzam.add_dir(gworSyJHIYMCxkjQDiGfAReblUpzcm,sublabel='',img=gworSyJHIYMCxkjQDiGfAReblUpzcO,infoLabels=gworSyJHIYMCxkjQDiGfAReblUpzdv,isFolder=gworSyJHIYMCxkjQDiGfAReblUpzNs,params=gworSyJHIYMCxkjQDiGfAReblUpzcV,isLink=gworSyJHIYMCxkjQDiGfAReblUpzNK)
  xbmcplugin.endOfDirectory(gworSyJHIYMCxkjQDiGfAReblUpzam._addon_handle,cacheToDisc=gworSyJHIYMCxkjQDiGfAReblUpzNs)
 def dp_Search_List(gworSyJHIYMCxkjQDiGfAReblUpzam,gworSyJHIYMCxkjQDiGfAReblUpzvm):
  gworSyJHIYMCxkjQDiGfAReblUpzam.TvingObj.SaveCredential(gworSyJHIYMCxkjQDiGfAReblUpzam.get_winCredential())
  gworSyJHIYMCxkjQDiGfAReblUpzvq =gworSyJHIYMCxkjQDiGfAReblUpzNL(gworSyJHIYMCxkjQDiGfAReblUpzvm.get('page'))
  gworSyJHIYMCxkjQDiGfAReblUpzvK =gworSyJHIYMCxkjQDiGfAReblUpzvm.get('stype')
  if 'search_key' in gworSyJHIYMCxkjQDiGfAReblUpzvm:
   gworSyJHIYMCxkjQDiGfAReblUpzPq=gworSyJHIYMCxkjQDiGfAReblUpzvm.get('search_key')
  else:
   gworSyJHIYMCxkjQDiGfAReblUpzPq=gworSyJHIYMCxkjQDiGfAReblUpzam.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not gworSyJHIYMCxkjQDiGfAReblUpzPq:
    xbmcplugin.endOfDirectory(gworSyJHIYMCxkjQDiGfAReblUpzam._addon_handle)
    return
  gworSyJHIYMCxkjQDiGfAReblUpzPB,gworSyJHIYMCxkjQDiGfAReblUpzvB=gworSyJHIYMCxkjQDiGfAReblUpzam.TvingObj.GetSearchList(gworSyJHIYMCxkjQDiGfAReblUpzPq,gworSyJHIYMCxkjQDiGfAReblUpzvq,gworSyJHIYMCxkjQDiGfAReblUpzvK)
  for gworSyJHIYMCxkjQDiGfAReblUpztc in gworSyJHIYMCxkjQDiGfAReblUpzPB:
   gworSyJHIYMCxkjQDiGfAReblUpzcm =gworSyJHIYMCxkjQDiGfAReblUpztc.get('title')
   gworSyJHIYMCxkjQDiGfAReblUpzvW =gworSyJHIYMCxkjQDiGfAReblUpztc.get('thumbnail')
   gworSyJHIYMCxkjQDiGfAReblUpzvO =gworSyJHIYMCxkjQDiGfAReblUpztc.get('synopsis')
   gworSyJHIYMCxkjQDiGfAReblUpztv =gworSyJHIYMCxkjQDiGfAReblUpztc.get('program')
   gworSyJHIYMCxkjQDiGfAReblUpzvu =gworSyJHIYMCxkjQDiGfAReblUpztc.get('cast')
   gworSyJHIYMCxkjQDiGfAReblUpzvF =gworSyJHIYMCxkjQDiGfAReblUpztc.get('director')
   gworSyJHIYMCxkjQDiGfAReblUpzvE=gworSyJHIYMCxkjQDiGfAReblUpztc.get('info_genre')
   gworSyJHIYMCxkjQDiGfAReblUpzPd =gworSyJHIYMCxkjQDiGfAReblUpztc.get('duration')
   gworSyJHIYMCxkjQDiGfAReblUpzda =gworSyJHIYMCxkjQDiGfAReblUpztc.get('mpaa')
   gworSyJHIYMCxkjQDiGfAReblUpzvX =gworSyJHIYMCxkjQDiGfAReblUpztc.get('year')
   gworSyJHIYMCxkjQDiGfAReblUpzdE =gworSyJHIYMCxkjQDiGfAReblUpztc.get('aired')
   gworSyJHIYMCxkjQDiGfAReblUpzdv={'mediatype':'tvshow' if gworSyJHIYMCxkjQDiGfAReblUpzvK=='vod' else 'movie','title':gworSyJHIYMCxkjQDiGfAReblUpzcm,'cast':gworSyJHIYMCxkjQDiGfAReblUpzvu,'director':gworSyJHIYMCxkjQDiGfAReblUpzvF,'genre':gworSyJHIYMCxkjQDiGfAReblUpzvE,'duration':gworSyJHIYMCxkjQDiGfAReblUpzPd,'mpaa':gworSyJHIYMCxkjQDiGfAReblUpzda,'year':gworSyJHIYMCxkjQDiGfAReblUpzvX,'aired':gworSyJHIYMCxkjQDiGfAReblUpzdE,'plot':'%s\n\n%s'%(gworSyJHIYMCxkjQDiGfAReblUpzcm,gworSyJHIYMCxkjQDiGfAReblUpzvO)}
   if gworSyJHIYMCxkjQDiGfAReblUpzvK=='vod':
    gworSyJHIYMCxkjQDiGfAReblUpzPL=gworSyJHIYMCxkjQDiGfAReblUpztc.get('program')
    gworSyJHIYMCxkjQDiGfAReblUpzPN='tvshow'
    gworSyJHIYMCxkjQDiGfAReblUpzcV={'mode':'EPISODE','programcode':gworSyJHIYMCxkjQDiGfAReblUpzPL,'page':'1',}
    gworSyJHIYMCxkjQDiGfAReblUpzcu=gworSyJHIYMCxkjQDiGfAReblUpzNK
   else:
    gworSyJHIYMCxkjQDiGfAReblUpzPL=gworSyJHIYMCxkjQDiGfAReblUpztc.get('movie')
    gworSyJHIYMCxkjQDiGfAReblUpzPN='movie'
    gworSyJHIYMCxkjQDiGfAReblUpzcV={'mode':'MOVIE','mediacode':gworSyJHIYMCxkjQDiGfAReblUpzPL,'stype':'movie','title':gworSyJHIYMCxkjQDiGfAReblUpzcm,'thumbnail':gworSyJHIYMCxkjQDiGfAReblUpzvW,}
    gworSyJHIYMCxkjQDiGfAReblUpzcu=gworSyJHIYMCxkjQDiGfAReblUpzNs
   if gworSyJHIYMCxkjQDiGfAReblUpzam.get_settings_makebookmark():
    gworSyJHIYMCxkjQDiGfAReblUpzdm={'videoid':gworSyJHIYMCxkjQDiGfAReblUpzPL,'vidtype':gworSyJHIYMCxkjQDiGfAReblUpzPN,'vtitle':gworSyJHIYMCxkjQDiGfAReblUpzcm,'vsubtitle':'',}
    gworSyJHIYMCxkjQDiGfAReblUpzdq=json.dumps(gworSyJHIYMCxkjQDiGfAReblUpzdm)
    gworSyJHIYMCxkjQDiGfAReblUpzdq=urllib.parse.quote(gworSyJHIYMCxkjQDiGfAReblUpzdq)
    gworSyJHIYMCxkjQDiGfAReblUpzdT='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(gworSyJHIYMCxkjQDiGfAReblUpzdq)
    gworSyJHIYMCxkjQDiGfAReblUpzdB=[('(통합) 찜 영상에 추가',gworSyJHIYMCxkjQDiGfAReblUpzdT)]
   else:
    gworSyJHIYMCxkjQDiGfAReblUpzdB=gworSyJHIYMCxkjQDiGfAReblUpzNt
   gworSyJHIYMCxkjQDiGfAReblUpzam.add_dir(gworSyJHIYMCxkjQDiGfAReblUpzcm,sublabel='',img=gworSyJHIYMCxkjQDiGfAReblUpzvW,infoLabels=gworSyJHIYMCxkjQDiGfAReblUpzdv,isFolder=gworSyJHIYMCxkjQDiGfAReblUpzcu,params=gworSyJHIYMCxkjQDiGfAReblUpzcV,isLink=gworSyJHIYMCxkjQDiGfAReblUpzNs,ContextMenu=gworSyJHIYMCxkjQDiGfAReblUpzdB)
  if gworSyJHIYMCxkjQDiGfAReblUpzvB:
   gworSyJHIYMCxkjQDiGfAReblUpzcV['mode'] ='SEARCH' 
   gworSyJHIYMCxkjQDiGfAReblUpzcV['search_key']=gworSyJHIYMCxkjQDiGfAReblUpzPq
   gworSyJHIYMCxkjQDiGfAReblUpzcV['page'] =gworSyJHIYMCxkjQDiGfAReblUpzNT(gworSyJHIYMCxkjQDiGfAReblUpzvq+1)
   gworSyJHIYMCxkjQDiGfAReblUpzcm='[B]%s >>[/B]'%'다음 페이지'
   gworSyJHIYMCxkjQDiGfAReblUpzdP=gworSyJHIYMCxkjQDiGfAReblUpzNT(gworSyJHIYMCxkjQDiGfAReblUpzvq+1)
   gworSyJHIYMCxkjQDiGfAReblUpzcO=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   gworSyJHIYMCxkjQDiGfAReblUpzam.add_dir(gworSyJHIYMCxkjQDiGfAReblUpzcm,sublabel=gworSyJHIYMCxkjQDiGfAReblUpzdP,img=gworSyJHIYMCxkjQDiGfAReblUpzcO,infoLabels=gworSyJHIYMCxkjQDiGfAReblUpzNt,isFolder=gworSyJHIYMCxkjQDiGfAReblUpzNK,params=gworSyJHIYMCxkjQDiGfAReblUpzcV)
  if gworSyJHIYMCxkjQDiGfAReblUpzvK=='movie':xbmcplugin.setContent(gworSyJHIYMCxkjQDiGfAReblUpzam._addon_handle,'movies')
  else:xbmcplugin.setContent(gworSyJHIYMCxkjQDiGfAReblUpzam._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(gworSyJHIYMCxkjQDiGfAReblUpzam._addon_handle,cacheToDisc=gworSyJHIYMCxkjQDiGfAReblUpzNs)
 def Delete_List_File(gworSyJHIYMCxkjQDiGfAReblUpzam,gworSyJHIYMCxkjQDiGfAReblUpzvK,skey='-'):
  if gworSyJHIYMCxkjQDiGfAReblUpzvK=='ALL':
   try:
    gworSyJHIYMCxkjQDiGfAReblUpztd=gworSyJHIYMCxkjQDiGfAReblUpzan
    fp=gworSyJHIYMCxkjQDiGfAReblUpzNh(gworSyJHIYMCxkjQDiGfAReblUpztd,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    gworSyJHIYMCxkjQDiGfAReblUpzNt
  elif gworSyJHIYMCxkjQDiGfAReblUpzvK=='ONE':
   try:
    gworSyJHIYMCxkjQDiGfAReblUpztd=gworSyJHIYMCxkjQDiGfAReblUpzan
    gworSyJHIYMCxkjQDiGfAReblUpztP=gworSyJHIYMCxkjQDiGfAReblUpzam.Load_List_File('search') 
    fp=gworSyJHIYMCxkjQDiGfAReblUpzNh(gworSyJHIYMCxkjQDiGfAReblUpztd,'w',-1,'utf-8')
    for gworSyJHIYMCxkjQDiGfAReblUpztL in gworSyJHIYMCxkjQDiGfAReblUpztP:
     gworSyJHIYMCxkjQDiGfAReblUpztN=gworSyJHIYMCxkjQDiGfAReblUpzNm(urllib.parse.parse_qsl(gworSyJHIYMCxkjQDiGfAReblUpztL))
     gworSyJHIYMCxkjQDiGfAReblUpztK=gworSyJHIYMCxkjQDiGfAReblUpztN.get('skey').strip()
     if skey!=gworSyJHIYMCxkjQDiGfAReblUpztK:
      fp.write(gworSyJHIYMCxkjQDiGfAReblUpztL)
    fp.close()
   except:
    gworSyJHIYMCxkjQDiGfAReblUpzNt
  elif gworSyJHIYMCxkjQDiGfAReblUpzvK in['vod','movie']:
   try:
    gworSyJHIYMCxkjQDiGfAReblUpztd=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%gworSyJHIYMCxkjQDiGfAReblUpzvK))
    fp=gworSyJHIYMCxkjQDiGfAReblUpzNh(gworSyJHIYMCxkjQDiGfAReblUpztd,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    gworSyJHIYMCxkjQDiGfAReblUpzNt
 def dp_Listfile_Delete(gworSyJHIYMCxkjQDiGfAReblUpzam,gworSyJHIYMCxkjQDiGfAReblUpzvm):
  gworSyJHIYMCxkjQDiGfAReblUpzvK=gworSyJHIYMCxkjQDiGfAReblUpzvm.get('stype')
  gworSyJHIYMCxkjQDiGfAReblUpzPE =gworSyJHIYMCxkjQDiGfAReblUpzvm.get('skey')
  gworSyJHIYMCxkjQDiGfAReblUpzaW=xbmcgui.Dialog()
  if gworSyJHIYMCxkjQDiGfAReblUpzvK=='ALL':
   gworSyJHIYMCxkjQDiGfAReblUpzvP=gworSyJHIYMCxkjQDiGfAReblUpzaW.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif gworSyJHIYMCxkjQDiGfAReblUpzvK=='ONE':
   gworSyJHIYMCxkjQDiGfAReblUpzvP=gworSyJHIYMCxkjQDiGfAReblUpzaW.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif gworSyJHIYMCxkjQDiGfAReblUpzvK in['vod','movie']:
   gworSyJHIYMCxkjQDiGfAReblUpzvP=gworSyJHIYMCxkjQDiGfAReblUpzaW.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if gworSyJHIYMCxkjQDiGfAReblUpzvP==gworSyJHIYMCxkjQDiGfAReblUpzNs:sys.exit()
  gworSyJHIYMCxkjQDiGfAReblUpzam.Delete_List_File(gworSyJHIYMCxkjQDiGfAReblUpzvK,skey=gworSyJHIYMCxkjQDiGfAReblUpzPE)
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(gworSyJHIYMCxkjQDiGfAReblUpzam,gworSyJHIYMCxkjQDiGfAReblUpzvK): 
  try:
   if gworSyJHIYMCxkjQDiGfAReblUpzvK=='search':
    gworSyJHIYMCxkjQDiGfAReblUpztd=gworSyJHIYMCxkjQDiGfAReblUpzan
   elif gworSyJHIYMCxkjQDiGfAReblUpzvK in['vod','movie']:
    gworSyJHIYMCxkjQDiGfAReblUpztd=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%gworSyJHIYMCxkjQDiGfAReblUpzvK))
   else:
    return[]
   fp=gworSyJHIYMCxkjQDiGfAReblUpzNh(gworSyJHIYMCxkjQDiGfAReblUpztd,'r',-1,'utf-8')
   gworSyJHIYMCxkjQDiGfAReblUpzts=fp.readlines()
   fp.close()
  except:
   gworSyJHIYMCxkjQDiGfAReblUpzts=[]
  return gworSyJHIYMCxkjQDiGfAReblUpzts
 def Save_Watched_List(gworSyJHIYMCxkjQDiGfAReblUpzam,gworSyJHIYMCxkjQDiGfAReblUpzvK,gworSyJHIYMCxkjQDiGfAReblUpzaB):
  try:
   gworSyJHIYMCxkjQDiGfAReblUpztn=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%gworSyJHIYMCxkjQDiGfAReblUpzvK))
   gworSyJHIYMCxkjQDiGfAReblUpztP=gworSyJHIYMCxkjQDiGfAReblUpzam.Load_List_File(gworSyJHIYMCxkjQDiGfAReblUpzvK) 
   fp=gworSyJHIYMCxkjQDiGfAReblUpzNh(gworSyJHIYMCxkjQDiGfAReblUpztn,'w',-1,'utf-8')
   gworSyJHIYMCxkjQDiGfAReblUpztm=urllib.parse.urlencode(gworSyJHIYMCxkjQDiGfAReblUpzaB)
   gworSyJHIYMCxkjQDiGfAReblUpztm=gworSyJHIYMCxkjQDiGfAReblUpztm+'\n'
   fp.write(gworSyJHIYMCxkjQDiGfAReblUpztm)
   gworSyJHIYMCxkjQDiGfAReblUpztq=0
   for gworSyJHIYMCxkjQDiGfAReblUpztL in gworSyJHIYMCxkjQDiGfAReblUpztP:
    gworSyJHIYMCxkjQDiGfAReblUpztN=gworSyJHIYMCxkjQDiGfAReblUpzNm(urllib.parse.parse_qsl(gworSyJHIYMCxkjQDiGfAReblUpztL))
    gworSyJHIYMCxkjQDiGfAReblUpztT=gworSyJHIYMCxkjQDiGfAReblUpzaB.get('code').strip()
    gworSyJHIYMCxkjQDiGfAReblUpztB=gworSyJHIYMCxkjQDiGfAReblUpztN.get('code').strip()
    if gworSyJHIYMCxkjQDiGfAReblUpzvK=='vod' and gworSyJHIYMCxkjQDiGfAReblUpzam.get_settings_direct_replay()==gworSyJHIYMCxkjQDiGfAReblUpzNK:
     gworSyJHIYMCxkjQDiGfAReblUpztT=gworSyJHIYMCxkjQDiGfAReblUpzaB.get('videoid').strip()
     gworSyJHIYMCxkjQDiGfAReblUpztB=gworSyJHIYMCxkjQDiGfAReblUpztN.get('videoid').strip()if gworSyJHIYMCxkjQDiGfAReblUpztB!=gworSyJHIYMCxkjQDiGfAReblUpzNt else '-'
    if gworSyJHIYMCxkjQDiGfAReblUpztT!=gworSyJHIYMCxkjQDiGfAReblUpztB:
     fp.write(gworSyJHIYMCxkjQDiGfAReblUpztL)
     gworSyJHIYMCxkjQDiGfAReblUpztq+=1
     if gworSyJHIYMCxkjQDiGfAReblUpztq>=50:break
   fp.close()
  except:
   gworSyJHIYMCxkjQDiGfAReblUpzNt
 def dp_Watch_List(gworSyJHIYMCxkjQDiGfAReblUpzam,gworSyJHIYMCxkjQDiGfAReblUpzvm):
  gworSyJHIYMCxkjQDiGfAReblUpzvK =gworSyJHIYMCxkjQDiGfAReblUpzvm.get('stype')
  gworSyJHIYMCxkjQDiGfAReblUpzcN=gworSyJHIYMCxkjQDiGfAReblUpzam.get_settings_direct_replay()
  if gworSyJHIYMCxkjQDiGfAReblUpzvK=='-':
   for gworSyJHIYMCxkjQDiGfAReblUpzvn in gworSyJHIYMCxkjQDiGfAReblUpzaP:
    gworSyJHIYMCxkjQDiGfAReblUpzcm=gworSyJHIYMCxkjQDiGfAReblUpzvn.get('title')
    gworSyJHIYMCxkjQDiGfAReblUpzcV={'mode':gworSyJHIYMCxkjQDiGfAReblUpzvn.get('mode'),'stype':gworSyJHIYMCxkjQDiGfAReblUpzvn.get('stype')}
    gworSyJHIYMCxkjQDiGfAReblUpzam.add_dir(gworSyJHIYMCxkjQDiGfAReblUpzcm,sublabel='',img='',infoLabels=gworSyJHIYMCxkjQDiGfAReblUpzNt,isFolder=gworSyJHIYMCxkjQDiGfAReblUpzNK,params=gworSyJHIYMCxkjQDiGfAReblUpzcV)
   if gworSyJHIYMCxkjQDiGfAReblUpzNq(gworSyJHIYMCxkjQDiGfAReblUpzaP)>0:xbmcplugin.endOfDirectory(gworSyJHIYMCxkjQDiGfAReblUpzam._addon_handle)
  else:
   gworSyJHIYMCxkjQDiGfAReblUpzth=gworSyJHIYMCxkjQDiGfAReblUpzam.Load_List_File(gworSyJHIYMCxkjQDiGfAReblUpzvK)
   for gworSyJHIYMCxkjQDiGfAReblUpztW in gworSyJHIYMCxkjQDiGfAReblUpzth:
    gworSyJHIYMCxkjQDiGfAReblUpzPF=gworSyJHIYMCxkjQDiGfAReblUpzNm(urllib.parse.parse_qsl(gworSyJHIYMCxkjQDiGfAReblUpztW))
    gworSyJHIYMCxkjQDiGfAReblUpztO =gworSyJHIYMCxkjQDiGfAReblUpzPF.get('code').strip()
    gworSyJHIYMCxkjQDiGfAReblUpzcm =gworSyJHIYMCxkjQDiGfAReblUpzPF.get('title').strip()
    gworSyJHIYMCxkjQDiGfAReblUpzvW=gworSyJHIYMCxkjQDiGfAReblUpzPF.get('img').strip()
    gworSyJHIYMCxkjQDiGfAReblUpzPL =gworSyJHIYMCxkjQDiGfAReblUpzPF.get('videoid').strip()
    try:
     gworSyJHIYMCxkjQDiGfAReblUpzvW=gworSyJHIYMCxkjQDiGfAReblUpzvW.replace('\'','\"')
     gworSyJHIYMCxkjQDiGfAReblUpzvW=json.loads(gworSyJHIYMCxkjQDiGfAReblUpzvW)
    except:
     gworSyJHIYMCxkjQDiGfAReblUpzNt
    gworSyJHIYMCxkjQDiGfAReblUpzdv={}
    gworSyJHIYMCxkjQDiGfAReblUpzdv['plot']=gworSyJHIYMCxkjQDiGfAReblUpzcm
    if gworSyJHIYMCxkjQDiGfAReblUpzvK=='vod':
     if gworSyJHIYMCxkjQDiGfAReblUpzcN==gworSyJHIYMCxkjQDiGfAReblUpzNs or gworSyJHIYMCxkjQDiGfAReblUpzPL==gworSyJHIYMCxkjQDiGfAReblUpzNt:
      gworSyJHIYMCxkjQDiGfAReblUpzcV={'mode':'EPISODE','programcode':gworSyJHIYMCxkjQDiGfAReblUpztO,'page':'1'}
      gworSyJHIYMCxkjQDiGfAReblUpzcu=gworSyJHIYMCxkjQDiGfAReblUpzNK
     else:
      gworSyJHIYMCxkjQDiGfAReblUpzcV={'mode':'VOD','mediacode':gworSyJHIYMCxkjQDiGfAReblUpzPL,'stype':'vod','programcode':gworSyJHIYMCxkjQDiGfAReblUpztO,'title':gworSyJHIYMCxkjQDiGfAReblUpzcm,'thumbnail':gworSyJHIYMCxkjQDiGfAReblUpzvW}
      gworSyJHIYMCxkjQDiGfAReblUpzcu=gworSyJHIYMCxkjQDiGfAReblUpzNs
    else:
     gworSyJHIYMCxkjQDiGfAReblUpzcV={'mode':'MOVIE','mediacode':gworSyJHIYMCxkjQDiGfAReblUpztO,'stype':'movie','title':gworSyJHIYMCxkjQDiGfAReblUpzcm,'thumbnail':gworSyJHIYMCxkjQDiGfAReblUpzvW}
     gworSyJHIYMCxkjQDiGfAReblUpzcu=gworSyJHIYMCxkjQDiGfAReblUpzNs
    gworSyJHIYMCxkjQDiGfAReblUpzam.add_dir(gworSyJHIYMCxkjQDiGfAReblUpzcm,sublabel='',img=gworSyJHIYMCxkjQDiGfAReblUpzvW,infoLabels=gworSyJHIYMCxkjQDiGfAReblUpzdv,isFolder=gworSyJHIYMCxkjQDiGfAReblUpzcu,params=gworSyJHIYMCxkjQDiGfAReblUpzcV)
   gworSyJHIYMCxkjQDiGfAReblUpzdv={'plot':'시청목록을 삭제합니다.'}
   gworSyJHIYMCxkjQDiGfAReblUpzcm='*** 시청목록 삭제 ***'
   gworSyJHIYMCxkjQDiGfAReblUpzcV={'mode':'MYVIEW_REMOVE','stype':gworSyJHIYMCxkjQDiGfAReblUpzvK,'skey':'-',}
   gworSyJHIYMCxkjQDiGfAReblUpzcO=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   gworSyJHIYMCxkjQDiGfAReblUpzam.add_dir(gworSyJHIYMCxkjQDiGfAReblUpzcm,sublabel='',img=gworSyJHIYMCxkjQDiGfAReblUpzcO,infoLabels=gworSyJHIYMCxkjQDiGfAReblUpzdv,isFolder=gworSyJHIYMCxkjQDiGfAReblUpzNs,params=gworSyJHIYMCxkjQDiGfAReblUpzcV,isLink=gworSyJHIYMCxkjQDiGfAReblUpzNK)
   if gworSyJHIYMCxkjQDiGfAReblUpzvK=='movie':xbmcplugin.setContent(gworSyJHIYMCxkjQDiGfAReblUpzam._addon_handle,'movies')
   else:xbmcplugin.setContent(gworSyJHIYMCxkjQDiGfAReblUpzam._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(gworSyJHIYMCxkjQDiGfAReblUpzam._addon_handle,cacheToDisc=gworSyJHIYMCxkjQDiGfAReblUpzNs)
 def Save_Searched_List(gworSyJHIYMCxkjQDiGfAReblUpzam,gworSyJHIYMCxkjQDiGfAReblUpzPq):
  try:
   gworSyJHIYMCxkjQDiGfAReblUpztV=gworSyJHIYMCxkjQDiGfAReblUpzan
   gworSyJHIYMCxkjQDiGfAReblUpztP=gworSyJHIYMCxkjQDiGfAReblUpzam.Load_List_File('search') 
   gworSyJHIYMCxkjQDiGfAReblUpztu={'skey':gworSyJHIYMCxkjQDiGfAReblUpzPq.strip()}
   fp=gworSyJHIYMCxkjQDiGfAReblUpzNh(gworSyJHIYMCxkjQDiGfAReblUpztV,'w',-1,'utf-8')
   gworSyJHIYMCxkjQDiGfAReblUpztm=urllib.parse.urlencode(gworSyJHIYMCxkjQDiGfAReblUpztu)
   gworSyJHIYMCxkjQDiGfAReblUpztm=gworSyJHIYMCxkjQDiGfAReblUpztm+'\n'
   fp.write(gworSyJHIYMCxkjQDiGfAReblUpztm)
   gworSyJHIYMCxkjQDiGfAReblUpztq=0
   for gworSyJHIYMCxkjQDiGfAReblUpztL in gworSyJHIYMCxkjQDiGfAReblUpztP:
    gworSyJHIYMCxkjQDiGfAReblUpztN=gworSyJHIYMCxkjQDiGfAReblUpzNm(urllib.parse.parse_qsl(gworSyJHIYMCxkjQDiGfAReblUpztL))
    gworSyJHIYMCxkjQDiGfAReblUpztT=gworSyJHIYMCxkjQDiGfAReblUpztu.get('skey').strip()
    gworSyJHIYMCxkjQDiGfAReblUpztB=gworSyJHIYMCxkjQDiGfAReblUpztN.get('skey').strip()
    if gworSyJHIYMCxkjQDiGfAReblUpztT!=gworSyJHIYMCxkjQDiGfAReblUpztB:
     fp.write(gworSyJHIYMCxkjQDiGfAReblUpztL)
     gworSyJHIYMCxkjQDiGfAReblUpztq+=1
     if gworSyJHIYMCxkjQDiGfAReblUpztq>=50:break
   fp.close()
  except:
   gworSyJHIYMCxkjQDiGfAReblUpzNt
 def play_VIDEO(gworSyJHIYMCxkjQDiGfAReblUpzam,gworSyJHIYMCxkjQDiGfAReblUpzvm):
  gworSyJHIYMCxkjQDiGfAReblUpzam.TvingObj.SaveCredential(gworSyJHIYMCxkjQDiGfAReblUpzam.get_winCredential())
  gworSyJHIYMCxkjQDiGfAReblUpztF =gworSyJHIYMCxkjQDiGfAReblUpzvm.get('mediacode')
  gworSyJHIYMCxkjQDiGfAReblUpzvK =gworSyJHIYMCxkjQDiGfAReblUpzvm.get('stype')
  gworSyJHIYMCxkjQDiGfAReblUpztE =gworSyJHIYMCxkjQDiGfAReblUpzvm.get('pvrmode')
  gworSyJHIYMCxkjQDiGfAReblUpztX=gworSyJHIYMCxkjQDiGfAReblUpzam.get_selQuality(gworSyJHIYMCxkjQDiGfAReblUpzvK)
  gworSyJHIYMCxkjQDiGfAReblUpzam.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(gworSyJHIYMCxkjQDiGfAReblUpztF,gworSyJHIYMCxkjQDiGfAReblUpzNT(gworSyJHIYMCxkjQDiGfAReblUpztX),gworSyJHIYMCxkjQDiGfAReblUpzvK,gworSyJHIYMCxkjQDiGfAReblUpztE))
  gworSyJHIYMCxkjQDiGfAReblUpzLa,gworSyJHIYMCxkjQDiGfAReblUpzLc=gworSyJHIYMCxkjQDiGfAReblUpzam.TvingObj.GetBroadURL(gworSyJHIYMCxkjQDiGfAReblUpztF,gworSyJHIYMCxkjQDiGfAReblUpztX,gworSyJHIYMCxkjQDiGfAReblUpzvK,gworSyJHIYMCxkjQDiGfAReblUpztE)
  gworSyJHIYMCxkjQDiGfAReblUpzam.addon_log('qt, stype, url : %s - %s - %s'%(gworSyJHIYMCxkjQDiGfAReblUpzNT(gworSyJHIYMCxkjQDiGfAReblUpztX),gworSyJHIYMCxkjQDiGfAReblUpzvK,gworSyJHIYMCxkjQDiGfAReblUpzLa))
  if gworSyJHIYMCxkjQDiGfAReblUpzLa=='':
   if gworSyJHIYMCxkjQDiGfAReblUpzLc=='':
    gworSyJHIYMCxkjQDiGfAReblUpzam.addon_noti(__language__(30908).encode('utf8'))
   else:
    gworSyJHIYMCxkjQDiGfAReblUpzam.addon_noti(gworSyJHIYMCxkjQDiGfAReblUpzLc.encode('utf8'))
   return
  gworSyJHIYMCxkjQDiGfAReblUpzLv =gworSyJHIYMCxkjQDiGfAReblUpzNs
  gworSyJHIYMCxkjQDiGfAReblUpzLd =gworSyJHIYMCxkjQDiGfAReblUpzLa.find('Policy=')
  if gworSyJHIYMCxkjQDiGfAReblUpzLd!=-1:
   gworSyJHIYMCxkjQDiGfAReblUpzLP =gworSyJHIYMCxkjQDiGfAReblUpzLa.split('?')[0]
   gworSyJHIYMCxkjQDiGfAReblUpzLt=gworSyJHIYMCxkjQDiGfAReblUpzNm(urllib.parse.parse_qsl(urllib.parse.urlsplit(gworSyJHIYMCxkjQDiGfAReblUpzLa).query))
   gworSyJHIYMCxkjQDiGfAReblUpzLN='CloudFront-Policy=%s;CloudFront-Signature=%s;CloudFront-Key-Pair-Id=%s'%(gworSyJHIYMCxkjQDiGfAReblUpzLt['Policy'],gworSyJHIYMCxkjQDiGfAReblUpzLt['Signature'],gworSyJHIYMCxkjQDiGfAReblUpzLt['Key-Pair-Id'])
   if 'quickvod-mcdn.tving.com' in gworSyJHIYMCxkjQDiGfAReblUpzLP:
    gworSyJHIYMCxkjQDiGfAReblUpzLv=gworSyJHIYMCxkjQDiGfAReblUpzNK
    gworSyJHIYMCxkjQDiGfAReblUpzLK =gworSyJHIYMCxkjQDiGfAReblUpzam.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    gworSyJHIYMCxkjQDiGfAReblUpzLs=gworSyJHIYMCxkjQDiGfAReblUpzLK.strftime('%Y-%m-%d-%H:%M:%S')
    if gworSyJHIYMCxkjQDiGfAReblUpzNL(gworSyJHIYMCxkjQDiGfAReblUpzLs.replace('-','').replace(':',''))<gworSyJHIYMCxkjQDiGfAReblUpzNL(gworSyJHIYMCxkjQDiGfAReblUpzLt['end'].replace('-','').replace(':','')):
     gworSyJHIYMCxkjQDiGfAReblUpzLt['end']=gworSyJHIYMCxkjQDiGfAReblUpzLs
     gworSyJHIYMCxkjQDiGfAReblUpzam.addon_noti(__language__(30915).encode('utf8'))
    gworSyJHIYMCxkjQDiGfAReblUpzLP ='%s?%s'%(gworSyJHIYMCxkjQDiGfAReblUpzLP,urllib.parse.urlencode(gworSyJHIYMCxkjQDiGfAReblUpzLt,doseq=gworSyJHIYMCxkjQDiGfAReblUpzNK))
   gworSyJHIYMCxkjQDiGfAReblUpzLn='%s|Cookie=%s'%(gworSyJHIYMCxkjQDiGfAReblUpzLP,gworSyJHIYMCxkjQDiGfAReblUpzLN)
  else:
   gworSyJHIYMCxkjQDiGfAReblUpzLn=gworSyJHIYMCxkjQDiGfAReblUpzLa
  gworSyJHIYMCxkjQDiGfAReblUpzam.addon_log(gworSyJHIYMCxkjQDiGfAReblUpzLn)
  gworSyJHIYMCxkjQDiGfAReblUpzLm=xbmcgui.ListItem(path=gworSyJHIYMCxkjQDiGfAReblUpzLn)
  if gworSyJHIYMCxkjQDiGfAReblUpzLc!='':
   gworSyJHIYMCxkjQDiGfAReblUpzLq=gworSyJHIYMCxkjQDiGfAReblUpzLc
   gworSyJHIYMCxkjQDiGfAReblUpzLT ='https://cj.drmkeyserver.com/widevine_license'
   gworSyJHIYMCxkjQDiGfAReblUpzLB ='mpd'
   gworSyJHIYMCxkjQDiGfAReblUpzLh ='com.widevine.alpha'
   gworSyJHIYMCxkjQDiGfAReblUpzLW =inputstreamhelper.Helper(gworSyJHIYMCxkjQDiGfAReblUpzLB,drm='widevine')
   if gworSyJHIYMCxkjQDiGfAReblUpzLW.check_inputstream():
    gworSyJHIYMCxkjQDiGfAReblUpzLO={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/live/player/%s'%gworSyJHIYMCxkjQDiGfAReblUpztF,'sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':gworSyJHIYMCxkjQDiGfAReblUpzam.TvingObj.USER_AGENT,'AcquireLicenseAssertion':gworSyJHIYMCxkjQDiGfAReblUpzLq,'Host':'cj.drmkeyserver.com'}
    gworSyJHIYMCxkjQDiGfAReblUpzLV=gworSyJHIYMCxkjQDiGfAReblUpzLT+'|'+urllib.parse.urlencode(gworSyJHIYMCxkjQDiGfAReblUpzLO)+'|R{SSM}|'
    gworSyJHIYMCxkjQDiGfAReblUpzLm.setProperty('inputstream',gworSyJHIYMCxkjQDiGfAReblUpzLW.inputstream_addon)
    gworSyJHIYMCxkjQDiGfAReblUpzLm.setProperty('inputstream.adaptive.manifest_type',gworSyJHIYMCxkjQDiGfAReblUpzLB)
    gworSyJHIYMCxkjQDiGfAReblUpzLm.setProperty('inputstream.adaptive.license_type',gworSyJHIYMCxkjQDiGfAReblUpzLh)
    gworSyJHIYMCxkjQDiGfAReblUpzLm.setProperty('inputstream.adaptive.license_key',gworSyJHIYMCxkjQDiGfAReblUpzLV)
    gworSyJHIYMCxkjQDiGfAReblUpzLm.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(gworSyJHIYMCxkjQDiGfAReblUpzam.TvingObj.USER_AGENT))
  elif gworSyJHIYMCxkjQDiGfAReblUpzLv==gworSyJHIYMCxkjQDiGfAReblUpzNK:
   gworSyJHIYMCxkjQDiGfAReblUpzLm.setContentLookup(gworSyJHIYMCxkjQDiGfAReblUpzNs)
   gworSyJHIYMCxkjQDiGfAReblUpzLm.setMimeType('application/x-mpegURL')
   gworSyJHIYMCxkjQDiGfAReblUpzLm.setProperty('inputstream','inputstream.ffmpegdirect')
   gworSyJHIYMCxkjQDiGfAReblUpzLm.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   gworSyJHIYMCxkjQDiGfAReblUpzLm.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   gworSyJHIYMCxkjQDiGfAReblUpzLm.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   gworSyJHIYMCxkjQDiGfAReblUpzLm.setProperty('ResumeTime','0')
   gworSyJHIYMCxkjQDiGfAReblUpzLm.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(gworSyJHIYMCxkjQDiGfAReblUpzam._addon_handle,gworSyJHIYMCxkjQDiGfAReblUpzNK,gworSyJHIYMCxkjQDiGfAReblUpzLm)
  try:
   if gworSyJHIYMCxkjQDiGfAReblUpzvm.get('mode')in['VOD','MOVIE']and gworSyJHIYMCxkjQDiGfAReblUpzvm.get('title'):
    gworSyJHIYMCxkjQDiGfAReblUpzcV={'code':gworSyJHIYMCxkjQDiGfAReblUpzvm.get('programcode')if gworSyJHIYMCxkjQDiGfAReblUpzvm.get('mode')=='VOD' else gworSyJHIYMCxkjQDiGfAReblUpzvm.get('mediacode'),'img':gworSyJHIYMCxkjQDiGfAReblUpzvm.get('thumbnail'),'title':gworSyJHIYMCxkjQDiGfAReblUpzvm.get('title'),'videoid':gworSyJHIYMCxkjQDiGfAReblUpzvm.get('mediacode')}
    gworSyJHIYMCxkjQDiGfAReblUpzam.Save_Watched_List(gworSyJHIYMCxkjQDiGfAReblUpzvm.get('stype'),gworSyJHIYMCxkjQDiGfAReblUpzcV)
  except:
   gworSyJHIYMCxkjQDiGfAReblUpzNt
 def logout(gworSyJHIYMCxkjQDiGfAReblUpzam):
  gworSyJHIYMCxkjQDiGfAReblUpzaW=xbmcgui.Dialog()
  gworSyJHIYMCxkjQDiGfAReblUpzvP=gworSyJHIYMCxkjQDiGfAReblUpzaW.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if gworSyJHIYMCxkjQDiGfAReblUpzvP==gworSyJHIYMCxkjQDiGfAReblUpzNs:sys.exit()
  gworSyJHIYMCxkjQDiGfAReblUpzam.wininfo_clear()
  if os.path.isfile(gworSyJHIYMCxkjQDiGfAReblUpzas):os.remove(gworSyJHIYMCxkjQDiGfAReblUpzas)
  gworSyJHIYMCxkjQDiGfAReblUpzam.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(gworSyJHIYMCxkjQDiGfAReblUpzam):
  gworSyJHIYMCxkjQDiGfAReblUpzcK=xbmcgui.Window(10000)
  gworSyJHIYMCxkjQDiGfAReblUpzcK.setProperty('TVING_M_TOKEN','')
  gworSyJHIYMCxkjQDiGfAReblUpzcK.setProperty('TVING_M_USERINFO','')
  gworSyJHIYMCxkjQDiGfAReblUpzcK.setProperty('TVING_M_UUID','')
  gworSyJHIYMCxkjQDiGfAReblUpzcK.setProperty('TVING_M_LOGINTIME','')
  gworSyJHIYMCxkjQDiGfAReblUpzcK.setProperty('TVING_M_MAINTOKEN','')
  gworSyJHIYMCxkjQDiGfAReblUpzcK.setProperty('TVING_M_COOKIEKEY','')
  gworSyJHIYMCxkjQDiGfAReblUpzcK.setProperty('TVING_M_LOCKKEY','')
 def cookiefile_save(gworSyJHIYMCxkjQDiGfAReblUpzam):
  gworSyJHIYMCxkjQDiGfAReblUpzLu =gworSyJHIYMCxkjQDiGfAReblUpzam.TvingObj.Get_Now_Datetime()
  gworSyJHIYMCxkjQDiGfAReblUpzLF=gworSyJHIYMCxkjQDiGfAReblUpzLu+datetime.timedelta(days=gworSyJHIYMCxkjQDiGfAReblUpzNL(__addon__.getSetting('cache_ttl')))
  gworSyJHIYMCxkjQDiGfAReblUpzcK=xbmcgui.Window(10000)
  gworSyJHIYMCxkjQDiGfAReblUpzLE={'tving_token':gworSyJHIYMCxkjQDiGfAReblUpzcK.getProperty('TVING_M_TOKEN'),'tving_userinfo':gworSyJHIYMCxkjQDiGfAReblUpzcK.getProperty('TVING_M_USERINFO'),'tving_uuid':gworSyJHIYMCxkjQDiGfAReblUpzcK.getProperty('TVING_M_UUID'),'tving_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'tving_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'tving_logintype':__addon__.getSetting('login_type'),'tving_profile':__addon__.getSetting('selected_profile'),'tving_limitdate':gworSyJHIYMCxkjQDiGfAReblUpzLF.strftime('%Y-%m-%d'),'tving_maintoken':gworSyJHIYMCxkjQDiGfAReblUpzcK.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':gworSyJHIYMCxkjQDiGfAReblUpzcK.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':gworSyJHIYMCxkjQDiGfAReblUpzcK.getProperty('TVING_M_LOCKKEY')}
  fp=gworSyJHIYMCxkjQDiGfAReblUpzNh(gworSyJHIYMCxkjQDiGfAReblUpzas,'w',-1,'utf-8')
  json.dump(gworSyJHIYMCxkjQDiGfAReblUpzLE,fp,indent=4,ensure_ascii=gworSyJHIYMCxkjQDiGfAReblUpzNs)
  fp.close()
 def cookiefile_check(gworSyJHIYMCxkjQDiGfAReblUpzam):
  gworSyJHIYMCxkjQDiGfAReblUpzLE={}
  try: 
   fp=gworSyJHIYMCxkjQDiGfAReblUpzNh(gworSyJHIYMCxkjQDiGfAReblUpzas,'r',-1,'utf-8')
   gworSyJHIYMCxkjQDiGfAReblUpzLE= json.load(fp)
   fp.close()
  except gworSyJHIYMCxkjQDiGfAReblUpzNW as exception:
   gworSyJHIYMCxkjQDiGfAReblUpzam.wininfo_clear()
   return gworSyJHIYMCxkjQDiGfAReblUpzNs
  gworSyJHIYMCxkjQDiGfAReblUpzcX =__addon__.getSetting('id')
  gworSyJHIYMCxkjQDiGfAReblUpzva =__addon__.getSetting('pw')
  gworSyJHIYMCxkjQDiGfAReblUpzNa=__addon__.getSetting('login_type')
  gworSyJHIYMCxkjQDiGfAReblUpzNc =__addon__.getSetting('selected_profile')
  gworSyJHIYMCxkjQDiGfAReblUpzLE['tving_id']=base64.standard_b64decode(gworSyJHIYMCxkjQDiGfAReblUpzLE['tving_id']).decode('utf-8')
  gworSyJHIYMCxkjQDiGfAReblUpzLE['tving_pw']=base64.standard_b64decode(gworSyJHIYMCxkjQDiGfAReblUpzLE['tving_pw']).decode('utf-8')
  try:
   gworSyJHIYMCxkjQDiGfAReblUpzLE['tving_profile']
  except:
   gworSyJHIYMCxkjQDiGfAReblUpzLE['tving_profile']='0'
  if gworSyJHIYMCxkjQDiGfAReblUpzcX!=gworSyJHIYMCxkjQDiGfAReblUpzLE['tving_id']or gworSyJHIYMCxkjQDiGfAReblUpzva!=gworSyJHIYMCxkjQDiGfAReblUpzLE['tving_pw']or gworSyJHIYMCxkjQDiGfAReblUpzNa!=gworSyJHIYMCxkjQDiGfAReblUpzLE['tving_logintype']or gworSyJHIYMCxkjQDiGfAReblUpzNc!=gworSyJHIYMCxkjQDiGfAReblUpzLE['tving_profile']or gworSyJHIYMCxkjQDiGfAReblUpzLE['tving_token']=='':
   gworSyJHIYMCxkjQDiGfAReblUpzam.wininfo_clear()
   return gworSyJHIYMCxkjQDiGfAReblUpzNs
  gworSyJHIYMCxkjQDiGfAReblUpzvt =gworSyJHIYMCxkjQDiGfAReblUpzNL(gworSyJHIYMCxkjQDiGfAReblUpzam.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  gworSyJHIYMCxkjQDiGfAReblUpzNv=gworSyJHIYMCxkjQDiGfAReblUpzLE['tving_limitdate']
  gworSyJHIYMCxkjQDiGfAReblUpzvL =gworSyJHIYMCxkjQDiGfAReblUpzNL(re.sub('-','',gworSyJHIYMCxkjQDiGfAReblUpzNv))
  if gworSyJHIYMCxkjQDiGfAReblUpzvL<gworSyJHIYMCxkjQDiGfAReblUpzvt:
   gworSyJHIYMCxkjQDiGfAReblUpzam.wininfo_clear()
   return gworSyJHIYMCxkjQDiGfAReblUpzNs
  gworSyJHIYMCxkjQDiGfAReblUpzcK=xbmcgui.Window(10000)
  gworSyJHIYMCxkjQDiGfAReblUpzcK.setProperty('TVING_M_TOKEN',gworSyJHIYMCxkjQDiGfAReblUpzLE['tving_token'])
  gworSyJHIYMCxkjQDiGfAReblUpzcK.setProperty('TVING_M_USERINFO',gworSyJHIYMCxkjQDiGfAReblUpzLE['tving_userinfo'])
  gworSyJHIYMCxkjQDiGfAReblUpzcK.setProperty('TVING_M_UUID',gworSyJHIYMCxkjQDiGfAReblUpzLE['tving_uuid'])
  gworSyJHIYMCxkjQDiGfAReblUpzcK.setProperty('TVING_M_LOGINTIME',gworSyJHIYMCxkjQDiGfAReblUpzNv)
  try:
   gworSyJHIYMCxkjQDiGfAReblUpzcK.setProperty('TVING_M_MAINTOKEN',gworSyJHIYMCxkjQDiGfAReblUpzLE['tving_maintoken'])
   gworSyJHIYMCxkjQDiGfAReblUpzcK.setProperty('TVING_M_COOKIEKEY',gworSyJHIYMCxkjQDiGfAReblUpzLE['tving_cookiekey'])
   gworSyJHIYMCxkjQDiGfAReblUpzcK.setProperty('TVING_M_LOCKKEY',gworSyJHIYMCxkjQDiGfAReblUpzLE['tving_lockkey'])
  except:
   gworSyJHIYMCxkjQDiGfAReblUpzcK.setProperty('TVING_M_MAINTOKEN',gworSyJHIYMCxkjQDiGfAReblUpzLE['tving_token'])
   gworSyJHIYMCxkjQDiGfAReblUpzcK.setProperty('TVING_M_COOKIEKEY','Y')
   gworSyJHIYMCxkjQDiGfAReblUpzcK.setProperty('TVING_M_LOCKKEY','N')
  return gworSyJHIYMCxkjQDiGfAReblUpzNK
 def dp_Global_Search(gworSyJHIYMCxkjQDiGfAReblUpzam,gworSyJHIYMCxkjQDiGfAReblUpzvm):
  gworSyJHIYMCxkjQDiGfAReblUpzPT=gworSyJHIYMCxkjQDiGfAReblUpzvm.get('mode')
  if gworSyJHIYMCxkjQDiGfAReblUpzPT=='TOTAL_SEARCH':
   gworSyJHIYMCxkjQDiGfAReblUpzNd='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   gworSyJHIYMCxkjQDiGfAReblUpzNd='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(gworSyJHIYMCxkjQDiGfAReblUpzNd)
 def dp_Bookmark_Menu(gworSyJHIYMCxkjQDiGfAReblUpzam,gworSyJHIYMCxkjQDiGfAReblUpzvm):
  gworSyJHIYMCxkjQDiGfAReblUpzNd='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(gworSyJHIYMCxkjQDiGfAReblUpzNd)
 def dp_EuroLive_List(gworSyJHIYMCxkjQDiGfAReblUpzam,gworSyJHIYMCxkjQDiGfAReblUpzvm):
  gworSyJHIYMCxkjQDiGfAReblUpzam.TvingObj.SaveCredential(gworSyJHIYMCxkjQDiGfAReblUpzam.get_winCredential())
  gworSyJHIYMCxkjQDiGfAReblUpzvT=gworSyJHIYMCxkjQDiGfAReblUpzam.TvingObj.GetEuroChannelList()
  for gworSyJHIYMCxkjQDiGfAReblUpzvh in gworSyJHIYMCxkjQDiGfAReblUpzvT:
   gworSyJHIYMCxkjQDiGfAReblUpzdn =gworSyJHIYMCxkjQDiGfAReblUpzvh.get('channel')
   gworSyJHIYMCxkjQDiGfAReblUpzcm =gworSyJHIYMCxkjQDiGfAReblUpzvh.get('title')
   gworSyJHIYMCxkjQDiGfAReblUpzdP =gworSyJHIYMCxkjQDiGfAReblUpzvh.get('subtitle')
   gworSyJHIYMCxkjQDiGfAReblUpzdv={'mediatype':'episode','title':gworSyJHIYMCxkjQDiGfAReblUpzcm,'plot':'%s\n%s'%(gworSyJHIYMCxkjQDiGfAReblUpzcm,gworSyJHIYMCxkjQDiGfAReblUpzdP)}
   gworSyJHIYMCxkjQDiGfAReblUpzcV={'mode':'LIVE','mediacode':gworSyJHIYMCxkjQDiGfAReblUpzvh.get('channel'),'stype':'onair',}
   gworSyJHIYMCxkjQDiGfAReblUpzam.add_dir(gworSyJHIYMCxkjQDiGfAReblUpzcm,sublabel=gworSyJHIYMCxkjQDiGfAReblUpzdP,img='',infoLabels=gworSyJHIYMCxkjQDiGfAReblUpzdv,isFolder=gworSyJHIYMCxkjQDiGfAReblUpzNs,params=gworSyJHIYMCxkjQDiGfAReblUpzcV)
  if gworSyJHIYMCxkjQDiGfAReblUpzNq(gworSyJHIYMCxkjQDiGfAReblUpzvT)>0:xbmcplugin.endOfDirectory(gworSyJHIYMCxkjQDiGfAReblUpzam._addon_handle,cacheToDisc=gworSyJHIYMCxkjQDiGfAReblUpzNs)
 def tving_main(gworSyJHIYMCxkjQDiGfAReblUpzam):
  gworSyJHIYMCxkjQDiGfAReblUpzPT=gworSyJHIYMCxkjQDiGfAReblUpzam.main_params.get('mode',gworSyJHIYMCxkjQDiGfAReblUpzNt)
  if gworSyJHIYMCxkjQDiGfAReblUpzPT=='LOGOUT':
   gworSyJHIYMCxkjQDiGfAReblUpzam.logout()
   return
  gworSyJHIYMCxkjQDiGfAReblUpzam.login_main()
  if gworSyJHIYMCxkjQDiGfAReblUpzPT is gworSyJHIYMCxkjQDiGfAReblUpzNt:
   gworSyJHIYMCxkjQDiGfAReblUpzam.dp_Main_List()
  elif gworSyJHIYMCxkjQDiGfAReblUpzPT in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   gworSyJHIYMCxkjQDiGfAReblUpzam.dp_Title_Group(gworSyJHIYMCxkjQDiGfAReblUpzam.main_params)
  elif gworSyJHIYMCxkjQDiGfAReblUpzPT in['GLOBAL_GROUP']:
   gworSyJHIYMCxkjQDiGfAReblUpzam.dp_SubTitle_Group(gworSyJHIYMCxkjQDiGfAReblUpzam.main_params)
  elif gworSyJHIYMCxkjQDiGfAReblUpzPT=='CHANNEL':
   gworSyJHIYMCxkjQDiGfAReblUpzam.dp_LiveChannel_List(gworSyJHIYMCxkjQDiGfAReblUpzam.main_params)
  elif gworSyJHIYMCxkjQDiGfAReblUpzPT in['LIVE','VOD','MOVIE']:
   gworSyJHIYMCxkjQDiGfAReblUpzam.play_VIDEO(gworSyJHIYMCxkjQDiGfAReblUpzam.main_params)
  elif gworSyJHIYMCxkjQDiGfAReblUpzPT=='PROGRAM':
   gworSyJHIYMCxkjQDiGfAReblUpzam.dp_Program_List(gworSyJHIYMCxkjQDiGfAReblUpzam.main_params)
  elif gworSyJHIYMCxkjQDiGfAReblUpzPT=='EPISODE':
   gworSyJHIYMCxkjQDiGfAReblUpzam.dp_Episode_List(gworSyJHIYMCxkjQDiGfAReblUpzam.main_params)
  elif gworSyJHIYMCxkjQDiGfAReblUpzPT=='MOVIE_SUB':
   gworSyJHIYMCxkjQDiGfAReblUpzam.dp_Movie_List(gworSyJHIYMCxkjQDiGfAReblUpzam.main_params)
  elif gworSyJHIYMCxkjQDiGfAReblUpzPT=='SEARCH_GROUP':
   gworSyJHIYMCxkjQDiGfAReblUpzam.dp_Search_Group(gworSyJHIYMCxkjQDiGfAReblUpzam.main_params)
  elif gworSyJHIYMCxkjQDiGfAReblUpzPT in['SEARCH','LOCAL_SEARCH']:
   gworSyJHIYMCxkjQDiGfAReblUpzam.dp_Search_List(gworSyJHIYMCxkjQDiGfAReblUpzam.main_params)
  elif gworSyJHIYMCxkjQDiGfAReblUpzPT=='WATCH':
   gworSyJHIYMCxkjQDiGfAReblUpzam.dp_Watch_List(gworSyJHIYMCxkjQDiGfAReblUpzam.main_params)
  elif gworSyJHIYMCxkjQDiGfAReblUpzPT in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   gworSyJHIYMCxkjQDiGfAReblUpzam.dp_Listfile_Delete(gworSyJHIYMCxkjQDiGfAReblUpzam.main_params)
  elif gworSyJHIYMCxkjQDiGfAReblUpzPT=='ORDER_BY':
   gworSyJHIYMCxkjQDiGfAReblUpzam.dp_setEpOrderby(gworSyJHIYMCxkjQDiGfAReblUpzam.main_params)
  elif gworSyJHIYMCxkjQDiGfAReblUpzPT=='SET_BOOKMARK':
   gworSyJHIYMCxkjQDiGfAReblUpzam.dp_Set_Bookmark(gworSyJHIYMCxkjQDiGfAReblUpzam.main_params)
  elif gworSyJHIYMCxkjQDiGfAReblUpzPT in['TOTAL_SEARCH','TOTAL_HISTORY']:
   gworSyJHIYMCxkjQDiGfAReblUpzam.dp_Global_Search(gworSyJHIYMCxkjQDiGfAReblUpzam.main_params)
  elif gworSyJHIYMCxkjQDiGfAReblUpzPT=='SEARCH_HISTORY':
   gworSyJHIYMCxkjQDiGfAReblUpzam.dp_Search_History(gworSyJHIYMCxkjQDiGfAReblUpzam.main_params)
  elif gworSyJHIYMCxkjQDiGfAReblUpzPT=='MENU_BOOKMARK':
   gworSyJHIYMCxkjQDiGfAReblUpzam.dp_Bookmark_Menu(gworSyJHIYMCxkjQDiGfAReblUpzam.main_params)
  elif gworSyJHIYMCxkjQDiGfAReblUpzPT=='EURO_GROUP':
   gworSyJHIYMCxkjQDiGfAReblUpzam.dp_EuroLive_List(gworSyJHIYMCxkjQDiGfAReblUpzam.main_params)
  else:
   gworSyJHIYMCxkjQDiGfAReblUpzNt
# Created by pyminifier (https://github.com/liftoff/pyminifier)
