__author__="NightRain"
KSTEvcJlDfhYAUmQgRzasoterVnXWk=ImportError
KSTEvcJlDfhYAUmQgRzasoterVnXWF=object
KSTEvcJlDfhYAUmQgRzasoterVnXWH=None
KSTEvcJlDfhYAUmQgRzasoterVnXWP=False
KSTEvcJlDfhYAUmQgRzasoterVnXWy=int
KSTEvcJlDfhYAUmQgRzasoterVnXWI=range
KSTEvcJlDfhYAUmQgRzasoterVnXWu=True
KSTEvcJlDfhYAUmQgRzasoterVnXWj=print
KSTEvcJlDfhYAUmQgRzasoterVnXWb=Exception
KSTEvcJlDfhYAUmQgRzasoterVnXWG=str
KSTEvcJlDfhYAUmQgRzasoterVnXWB=list
KSTEvcJlDfhYAUmQgRzasoterVnXpC=len
KSTEvcJlDfhYAUmQgRzasoterVnXpw=bytes
KSTEvcJlDfhYAUmQgRzasoterVnXpd=ord
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
try:
 from Cryptodome.PublicKey import RSA
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
except KSTEvcJlDfhYAUmQgRzasoterVnXWk:
 from Crypto.PublicKey import RSA
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
KSTEvcJlDfhYAUmQgRzasoterVnXCd={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
KSTEvcJlDfhYAUmQgRzasoterVnXCq ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
class KSTEvcJlDfhYAUmQgRzasoterVnXCw(KSTEvcJlDfhYAUmQgRzasoterVnXWF):
 def __init__(KSTEvcJlDfhYAUmQgRzasoterVnXCL):
  KSTEvcJlDfhYAUmQgRzasoterVnXCL.TVING_TOKEN =''
  KSTEvcJlDfhYAUmQgRzasoterVnXCL.POC_USERINFO =''
  KSTEvcJlDfhYAUmQgRzasoterVnXCL.TVING_UUID ='-'
  KSTEvcJlDfhYAUmQgRzasoterVnXCL.TVING_MAINTOKEN=''
  KSTEvcJlDfhYAUmQgRzasoterVnXCL.TVIGN_COOKIEKEY=''
  KSTEvcJlDfhYAUmQgRzasoterVnXCL.TVING_LOCKKEY =''
  KSTEvcJlDfhYAUmQgRzasoterVnXCL.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  KSTEvcJlDfhYAUmQgRzasoterVnXCL.NETWORKCODE ='CSND0900'
  KSTEvcJlDfhYAUmQgRzasoterVnXCL.OSCODE ='CSOD0900' 
  KSTEvcJlDfhYAUmQgRzasoterVnXCL.TELECODE ='CSCD0900'
  KSTEvcJlDfhYAUmQgRzasoterVnXCL.SCREENCODE ='CSSD0100'
  KSTEvcJlDfhYAUmQgRzasoterVnXCL.LIVE_LIMIT =23
  KSTEvcJlDfhYAUmQgRzasoterVnXCL.VOD_LIMIT =20
  KSTEvcJlDfhYAUmQgRzasoterVnXCL.EPISODE_LIMIT =30 
  KSTEvcJlDfhYAUmQgRzasoterVnXCL.SEARCH_LIMIT =30 
  KSTEvcJlDfhYAUmQgRzasoterVnXCL.MOVIE_LIMIT =18
  KSTEvcJlDfhYAUmQgRzasoterVnXCL.API_DOMAIN ='https://api.tving.com'
  KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN ='https://image.tving.com'
  KSTEvcJlDfhYAUmQgRzasoterVnXCL.SEARCH_DOMAIN ='https://search.tving.com'
  KSTEvcJlDfhYAUmQgRzasoterVnXCL.LOGIN_DOMAIN ='https://user.tving.com'
  KSTEvcJlDfhYAUmQgRzasoterVnXCL.URL_DOMAIN ='https://www.tving.com'
  KSTEvcJlDfhYAUmQgRzasoterVnXCL.MOVIE_LITE =['2610061','2610161','261062']
  KSTEvcJlDfhYAUmQgRzasoterVnXCL.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  KSTEvcJlDfhYAUmQgRzasoterVnXCL.DEFAULT_HEADER ={'user-agent':KSTEvcJlDfhYAUmQgRzasoterVnXCL.USER_AGENT}
  KSTEvcJlDfhYAUmQgRzasoterVnXCL.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
 def callRequestCookies(KSTEvcJlDfhYAUmQgRzasoterVnXCL,jobtype,KSTEvcJlDfhYAUmQgRzasoterVnXwH,payload=KSTEvcJlDfhYAUmQgRzasoterVnXWH,params=KSTEvcJlDfhYAUmQgRzasoterVnXWH,headers=KSTEvcJlDfhYAUmQgRzasoterVnXWH,cookies=KSTEvcJlDfhYAUmQgRzasoterVnXWH,redirects=KSTEvcJlDfhYAUmQgRzasoterVnXWP):
  KSTEvcJlDfhYAUmQgRzasoterVnXCW=KSTEvcJlDfhYAUmQgRzasoterVnXCL.DEFAULT_HEADER
  if headers:KSTEvcJlDfhYAUmQgRzasoterVnXCW.update(headers)
  if jobtype=='Get':
   KSTEvcJlDfhYAUmQgRzasoterVnXCp=requests.get(KSTEvcJlDfhYAUmQgRzasoterVnXwH,params=params,headers=KSTEvcJlDfhYAUmQgRzasoterVnXCW,cookies=cookies,allow_redirects=redirects)
  else:
   KSTEvcJlDfhYAUmQgRzasoterVnXCp=requests.post(KSTEvcJlDfhYAUmQgRzasoterVnXwH,data=payload,params=params,headers=KSTEvcJlDfhYAUmQgRzasoterVnXCW,cookies=cookies,allow_redirects=redirects)
  return KSTEvcJlDfhYAUmQgRzasoterVnXCp
 def makeDefaultCookies(KSTEvcJlDfhYAUmQgRzasoterVnXCL,vToken=KSTEvcJlDfhYAUmQgRzasoterVnXWH,vUserinfo=KSTEvcJlDfhYAUmQgRzasoterVnXWH):
  KSTEvcJlDfhYAUmQgRzasoterVnXCM={}
  KSTEvcJlDfhYAUmQgRzasoterVnXCM['_tving_token']=KSTEvcJlDfhYAUmQgRzasoterVnXCL.TVING_TOKEN if vToken==KSTEvcJlDfhYAUmQgRzasoterVnXWH else vToken
  KSTEvcJlDfhYAUmQgRzasoterVnXCM['POC_USERINFO']=KSTEvcJlDfhYAUmQgRzasoterVnXCL.POC_USERINFO if vToken==KSTEvcJlDfhYAUmQgRzasoterVnXWH else vUserinfo
  if KSTEvcJlDfhYAUmQgRzasoterVnXCL.TVING_MAINTOKEN!='':KSTEvcJlDfhYAUmQgRzasoterVnXCM[KSTEvcJlDfhYAUmQgRzasoterVnXCL.GLOBAL_COOKIENM['tv_maintoken']]=KSTEvcJlDfhYAUmQgRzasoterVnXCL.TVING_MAINTOKEN
  if KSTEvcJlDfhYAUmQgRzasoterVnXCL.TVIGN_COOKIEKEY!='':KSTEvcJlDfhYAUmQgRzasoterVnXCM[KSTEvcJlDfhYAUmQgRzasoterVnXCL.GLOBAL_COOKIENM['tv_cookiekey']]=KSTEvcJlDfhYAUmQgRzasoterVnXCL.TVIGN_COOKIEKEY
  if KSTEvcJlDfhYAUmQgRzasoterVnXCL.TVING_LOCKKEY !='':KSTEvcJlDfhYAUmQgRzasoterVnXCM[KSTEvcJlDfhYAUmQgRzasoterVnXCL.GLOBAL_COOKIENM['tv_lockkey']] =KSTEvcJlDfhYAUmQgRzasoterVnXCL.TVING_LOCKKEY
  return KSTEvcJlDfhYAUmQgRzasoterVnXCM
 def getDeviceStr(KSTEvcJlDfhYAUmQgRzasoterVnXCL):
  KSTEvcJlDfhYAUmQgRzasoterVnXCi=[]
  KSTEvcJlDfhYAUmQgRzasoterVnXCi.append('Windows') 
  KSTEvcJlDfhYAUmQgRzasoterVnXCi.append('Chrome') 
  KSTEvcJlDfhYAUmQgRzasoterVnXCi.append('ko-KR') 
  KSTEvcJlDfhYAUmQgRzasoterVnXCi.append('undefined') 
  KSTEvcJlDfhYAUmQgRzasoterVnXCi.append('24') 
  KSTEvcJlDfhYAUmQgRzasoterVnXCi.append(u'한국 표준시')
  KSTEvcJlDfhYAUmQgRzasoterVnXCi.append('undefined') 
  KSTEvcJlDfhYAUmQgRzasoterVnXCi.append('undefined') 
  KSTEvcJlDfhYAUmQgRzasoterVnXCi.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  KSTEvcJlDfhYAUmQgRzasoterVnXCN=''
  for KSTEvcJlDfhYAUmQgRzasoterVnXCx in KSTEvcJlDfhYAUmQgRzasoterVnXCi:
   KSTEvcJlDfhYAUmQgRzasoterVnXCN+=KSTEvcJlDfhYAUmQgRzasoterVnXCx+'|'
  return KSTEvcJlDfhYAUmQgRzasoterVnXCN
 def SaveCredential(KSTEvcJlDfhYAUmQgRzasoterVnXCL,KSTEvcJlDfhYAUmQgRzasoterVnXCO):
  KSTEvcJlDfhYAUmQgRzasoterVnXCL.TVING_TOKEN =KSTEvcJlDfhYAUmQgRzasoterVnXCO.get('tving_token')
  KSTEvcJlDfhYAUmQgRzasoterVnXCL.POC_USERINFO =KSTEvcJlDfhYAUmQgRzasoterVnXCO.get('poc_userinfo')
  KSTEvcJlDfhYAUmQgRzasoterVnXCL.TVING_UUID =KSTEvcJlDfhYAUmQgRzasoterVnXCO.get('tving_uuid')
  KSTEvcJlDfhYAUmQgRzasoterVnXCL.TVING_MAINTOKEN=KSTEvcJlDfhYAUmQgRzasoterVnXCO.get('tving_maintoken')
  KSTEvcJlDfhYAUmQgRzasoterVnXCL.TVIGN_COOKIEKEY=KSTEvcJlDfhYAUmQgRzasoterVnXCO.get('tving_cookiekey')
  KSTEvcJlDfhYAUmQgRzasoterVnXCL.TVING_LOCKKEY =KSTEvcJlDfhYAUmQgRzasoterVnXCO.get('tving_lockkey')
 def LoadCredential(KSTEvcJlDfhYAUmQgRzasoterVnXCL):
  KSTEvcJlDfhYAUmQgRzasoterVnXCO={'tving_token':KSTEvcJlDfhYAUmQgRzasoterVnXCL.TVING_TOKEN,'poc_userinfo':KSTEvcJlDfhYAUmQgRzasoterVnXCL.POC_USERINFO,'tving_uuid':KSTEvcJlDfhYAUmQgRzasoterVnXCL.TVING_UUID,'tving_maintoken':KSTEvcJlDfhYAUmQgRzasoterVnXCL.TVING_MAINTOKEN,'tving_cookiekey':KSTEvcJlDfhYAUmQgRzasoterVnXCL.TVIGN_COOKIEKEY,'tving_lockkey':KSTEvcJlDfhYAUmQgRzasoterVnXCL.TVING_LOCKKEY}
  return KSTEvcJlDfhYAUmQgRzasoterVnXCO
 def GetDefaultParams(KSTEvcJlDfhYAUmQgRzasoterVnXCL):
  KSTEvcJlDfhYAUmQgRzasoterVnXCk={'apiKey':KSTEvcJlDfhYAUmQgRzasoterVnXCL.APIKEY,'networkCode':KSTEvcJlDfhYAUmQgRzasoterVnXCL.NETWORKCODE,'osCode':KSTEvcJlDfhYAUmQgRzasoterVnXCL.OSCODE,'teleCode':KSTEvcJlDfhYAUmQgRzasoterVnXCL.TELECODE,'screenCode':KSTEvcJlDfhYAUmQgRzasoterVnXCL.SCREENCODE}
  return KSTEvcJlDfhYAUmQgRzasoterVnXCk
 def GetNoCache(KSTEvcJlDfhYAUmQgRzasoterVnXCL,timetype=1):
  if timetype==1:
   return KSTEvcJlDfhYAUmQgRzasoterVnXWy(time.time())
  else:
   return KSTEvcJlDfhYAUmQgRzasoterVnXWy(time.time()*1000)
 def GetUniqueid(KSTEvcJlDfhYAUmQgRzasoterVnXCL):
  KSTEvcJlDfhYAUmQgRzasoterVnXCF=[0 for i in KSTEvcJlDfhYAUmQgRzasoterVnXWI(256)]
  for i in KSTEvcJlDfhYAUmQgRzasoterVnXWI(256):
   KSTEvcJlDfhYAUmQgRzasoterVnXCF[i]='%02x'%(i)
  KSTEvcJlDfhYAUmQgRzasoterVnXCH=KSTEvcJlDfhYAUmQgRzasoterVnXWy(4294967295*random.random())|0
  KSTEvcJlDfhYAUmQgRzasoterVnXCP=KSTEvcJlDfhYAUmQgRzasoterVnXCF[255&KSTEvcJlDfhYAUmQgRzasoterVnXCH]+KSTEvcJlDfhYAUmQgRzasoterVnXCF[KSTEvcJlDfhYAUmQgRzasoterVnXCH>>8&255]+KSTEvcJlDfhYAUmQgRzasoterVnXCF[KSTEvcJlDfhYAUmQgRzasoterVnXCH>>16&255]+KSTEvcJlDfhYAUmQgRzasoterVnXCF[KSTEvcJlDfhYAUmQgRzasoterVnXCH>>24&255]
  return KSTEvcJlDfhYAUmQgRzasoterVnXCP
 def GetCredential(KSTEvcJlDfhYAUmQgRzasoterVnXCL,user_id,user_pw,login_type,user_pf):
  KSTEvcJlDfhYAUmQgRzasoterVnXCy=KSTEvcJlDfhYAUmQgRzasoterVnXWP
  KSTEvcJlDfhYAUmQgRzasoterVnXCI=KSTEvcJlDfhYAUmQgRzasoterVnXwC=KSTEvcJlDfhYAUmQgRzasoterVnXwd=KSTEvcJlDfhYAUmQgRzasoterVnXwq=KSTEvcJlDfhYAUmQgRzasoterVnXwL='' 
  KSTEvcJlDfhYAUmQgRzasoterVnXCu ='-'
  try:
   KSTEvcJlDfhYAUmQgRzasoterVnXCj=KSTEvcJlDfhYAUmQgRzasoterVnXCL.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   KSTEvcJlDfhYAUmQgRzasoterVnXCb={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com','csite':'',}
   KSTEvcJlDfhYAUmQgRzasoterVnXCG=KSTEvcJlDfhYAUmQgRzasoterVnXCL.callRequestCookies('Post',KSTEvcJlDfhYAUmQgRzasoterVnXCj,payload=KSTEvcJlDfhYAUmQgRzasoterVnXCb,params=KSTEvcJlDfhYAUmQgRzasoterVnXWH,headers=KSTEvcJlDfhYAUmQgRzasoterVnXWH,cookies=KSTEvcJlDfhYAUmQgRzasoterVnXWH)
   for KSTEvcJlDfhYAUmQgRzasoterVnXCB in KSTEvcJlDfhYAUmQgRzasoterVnXCG.cookies:
    if KSTEvcJlDfhYAUmQgRzasoterVnXCB.name=='_tving_token':
     KSTEvcJlDfhYAUmQgRzasoterVnXwC=KSTEvcJlDfhYAUmQgRzasoterVnXCB.value
    elif KSTEvcJlDfhYAUmQgRzasoterVnXCB.name=='POC_USERINFO':
     KSTEvcJlDfhYAUmQgRzasoterVnXwd=KSTEvcJlDfhYAUmQgRzasoterVnXCB.value
   if KSTEvcJlDfhYAUmQgRzasoterVnXwC=='':return KSTEvcJlDfhYAUmQgRzasoterVnXCy
   KSTEvcJlDfhYAUmQgRzasoterVnXCI=KSTEvcJlDfhYAUmQgRzasoterVnXwC
   KSTEvcJlDfhYAUmQgRzasoterVnXwC,KSTEvcJlDfhYAUmQgRzasoterVnXwq,KSTEvcJlDfhYAUmQgRzasoterVnXwL=KSTEvcJlDfhYAUmQgRzasoterVnXCL.GetProfileToken(KSTEvcJlDfhYAUmQgRzasoterVnXwC,KSTEvcJlDfhYAUmQgRzasoterVnXwd,user_pf)
   KSTEvcJlDfhYAUmQgRzasoterVnXCy=KSTEvcJlDfhYAUmQgRzasoterVnXWu
   KSTEvcJlDfhYAUmQgRzasoterVnXCu =KSTEvcJlDfhYAUmQgRzasoterVnXCL.GetDeviceList(KSTEvcJlDfhYAUmQgRzasoterVnXwC,KSTEvcJlDfhYAUmQgRzasoterVnXwd)
   KSTEvcJlDfhYAUmQgRzasoterVnXCu =KSTEvcJlDfhYAUmQgRzasoterVnXCu+'-'+KSTEvcJlDfhYAUmQgRzasoterVnXCL.GetUniqueid()
   KSTEvcJlDfhYAUmQgRzasoterVnXWj(KSTEvcJlDfhYAUmQgRzasoterVnXCu)
  except KSTEvcJlDfhYAUmQgRzasoterVnXWb as exception:
   KSTEvcJlDfhYAUmQgRzasoterVnXCI=KSTEvcJlDfhYAUmQgRzasoterVnXwC=KSTEvcJlDfhYAUmQgRzasoterVnXwd=KSTEvcJlDfhYAUmQgRzasoterVnXwq=KSTEvcJlDfhYAUmQgRzasoterVnXwL=''
   KSTEvcJlDfhYAUmQgRzasoterVnXCu='-'
   KSTEvcJlDfhYAUmQgRzasoterVnXWj(exception)
  KSTEvcJlDfhYAUmQgRzasoterVnXCO={'tving_token':KSTEvcJlDfhYAUmQgRzasoterVnXwC,'poc_userinfo':KSTEvcJlDfhYAUmQgRzasoterVnXwd,'tving_uuid':KSTEvcJlDfhYAUmQgRzasoterVnXCu,'tving_maintoken':KSTEvcJlDfhYAUmQgRzasoterVnXCI,'tving_cookiekey':KSTEvcJlDfhYAUmQgRzasoterVnXwq,'tving_lockkey':KSTEvcJlDfhYAUmQgRzasoterVnXwL}
  KSTEvcJlDfhYAUmQgRzasoterVnXCL.SaveCredential(KSTEvcJlDfhYAUmQgRzasoterVnXCO)
  return KSTEvcJlDfhYAUmQgRzasoterVnXCy
 def Get_Now_Datetime(KSTEvcJlDfhYAUmQgRzasoterVnXCL):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(KSTEvcJlDfhYAUmQgRzasoterVnXCL,mediacode,sel_quality,stype,pvrmode='-'):
  KSTEvcJlDfhYAUmQgRzasoterVnXwp=''
  KSTEvcJlDfhYAUmQgRzasoterVnXwM=''
  KSTEvcJlDfhYAUmQgRzasoterVnXwi =KSTEvcJlDfhYAUmQgRzasoterVnXCL.TVING_UUID.split('-')[0] 
  KSTEvcJlDfhYAUmQgRzasoterVnXwN =KSTEvcJlDfhYAUmQgRzasoterVnXCL.TVING_UUID 
  try:
   KSTEvcJlDfhYAUmQgRzasoterVnXwx=KSTEvcJlDfhYAUmQgRzasoterVnXWG(KSTEvcJlDfhYAUmQgRzasoterVnXCL.GetNoCache(1))
   if stype!='tvingtv':
    KSTEvcJlDfhYAUmQgRzasoterVnXwO ='/v2/media/stream/info' 
    KSTEvcJlDfhYAUmQgRzasoterVnXwk=KSTEvcJlDfhYAUmQgRzasoterVnXCL.GetDefaultParams()
    KSTEvcJlDfhYAUmQgRzasoterVnXwF={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':KSTEvcJlDfhYAUmQgRzasoterVnXwN,'deviceInfo':'PC','noCache':KSTEvcJlDfhYAUmQgRzasoterVnXwx,}
    KSTEvcJlDfhYAUmQgRzasoterVnXwk.update(KSTEvcJlDfhYAUmQgRzasoterVnXwF)
    KSTEvcJlDfhYAUmQgRzasoterVnXwH=KSTEvcJlDfhYAUmQgRzasoterVnXCL.API_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXwO
    KSTEvcJlDfhYAUmQgRzasoterVnXCM=KSTEvcJlDfhYAUmQgRzasoterVnXCL.makeDefaultCookies()
    KSTEvcJlDfhYAUmQgRzasoterVnXCG=KSTEvcJlDfhYAUmQgRzasoterVnXCL.callRequestCookies('Get',KSTEvcJlDfhYAUmQgRzasoterVnXwH,payload=KSTEvcJlDfhYAUmQgRzasoterVnXWH,params=KSTEvcJlDfhYAUmQgRzasoterVnXwk,headers=KSTEvcJlDfhYAUmQgRzasoterVnXWH,cookies=KSTEvcJlDfhYAUmQgRzasoterVnXCM)
    if KSTEvcJlDfhYAUmQgRzasoterVnXCG.status_code!=200:return KSTEvcJlDfhYAUmQgRzasoterVnXwp,KSTEvcJlDfhYAUmQgRzasoterVnXwM
    KSTEvcJlDfhYAUmQgRzasoterVnXwP=json.loads(KSTEvcJlDfhYAUmQgRzasoterVnXCG.text)
    if KSTEvcJlDfhYAUmQgRzasoterVnXwP['body']['result']['code']=='060':
     for KSTEvcJlDfhYAUmQgRzasoterVnXwy,KSTEvcJlDfhYAUmQgRzasoterVnXdq in KSTEvcJlDfhYAUmQgRzasoterVnXCd.items():
      if KSTEvcJlDfhYAUmQgRzasoterVnXdq==sel_quality:
       KSTEvcJlDfhYAUmQgRzasoterVnXwI=KSTEvcJlDfhYAUmQgRzasoterVnXwy
    elif KSTEvcJlDfhYAUmQgRzasoterVnXwP['body']['result']['code']!='000':
     KSTEvcJlDfhYAUmQgRzasoterVnXwM=KSTEvcJlDfhYAUmQgRzasoterVnXwP['body']['result']['message']
     return KSTEvcJlDfhYAUmQgRzasoterVnXwp,KSTEvcJlDfhYAUmQgRzasoterVnXwM
    else: 
     if not('stream' in KSTEvcJlDfhYAUmQgRzasoterVnXwP['body']):return KSTEvcJlDfhYAUmQgRzasoterVnXwp,KSTEvcJlDfhYAUmQgRzasoterVnXwM 
     KSTEvcJlDfhYAUmQgRzasoterVnXwu=KSTEvcJlDfhYAUmQgRzasoterVnXwP['body']['stream']
     KSTEvcJlDfhYAUmQgRzasoterVnXwj=KSTEvcJlDfhYAUmQgRzasoterVnXwu['quality']
     KSTEvcJlDfhYAUmQgRzasoterVnXwb=[]
     for KSTEvcJlDfhYAUmQgRzasoterVnXwG in KSTEvcJlDfhYAUmQgRzasoterVnXwj:
      if KSTEvcJlDfhYAUmQgRzasoterVnXwG['active']=='Y':
       KSTEvcJlDfhYAUmQgRzasoterVnXwb.append({KSTEvcJlDfhYAUmQgRzasoterVnXCd.get(KSTEvcJlDfhYAUmQgRzasoterVnXwG['code']):KSTEvcJlDfhYAUmQgRzasoterVnXwG['code']})
     KSTEvcJlDfhYAUmQgRzasoterVnXwI=KSTEvcJlDfhYAUmQgRzasoterVnXCL.CheckQuality(sel_quality,KSTEvcJlDfhYAUmQgRzasoterVnXwb)
   else:
    KSTEvcJlDfhYAUmQgRzasoterVnXwI='stream40'
  except KSTEvcJlDfhYAUmQgRzasoterVnXWb as exception:
   KSTEvcJlDfhYAUmQgRzasoterVnXWj(exception)
   return KSTEvcJlDfhYAUmQgRzasoterVnXwp,KSTEvcJlDfhYAUmQgRzasoterVnXwM
  KSTEvcJlDfhYAUmQgRzasoterVnXWj(KSTEvcJlDfhYAUmQgRzasoterVnXwI)
  try:
   KSTEvcJlDfhYAUmQgRzasoterVnXwx=KSTEvcJlDfhYAUmQgRzasoterVnXWG(KSTEvcJlDfhYAUmQgRzasoterVnXCL.GetNoCache(1))
   KSTEvcJlDfhYAUmQgRzasoterVnXwO ='/v2a/media/stream/info'
   KSTEvcJlDfhYAUmQgRzasoterVnXwk=KSTEvcJlDfhYAUmQgRzasoterVnXCL.GetDefaultParams()
   KSTEvcJlDfhYAUmQgRzasoterVnXwF={'callingFrom':'HTML5','mediaCode':mediacode,'info':'Y','adReq':'adproxy','streamCode':KSTEvcJlDfhYAUmQgRzasoterVnXwI,'deviceId':KSTEvcJlDfhYAUmQgRzasoterVnXwi,'uuid':KSTEvcJlDfhYAUmQgRzasoterVnXwN,'deviceInfo':'PC_Chrome','noCache':KSTEvcJlDfhYAUmQgRzasoterVnXwx,'wm':'Y'}
   KSTEvcJlDfhYAUmQgRzasoterVnXwk.update(KSTEvcJlDfhYAUmQgRzasoterVnXwF)
   KSTEvcJlDfhYAUmQgRzasoterVnXwH=KSTEvcJlDfhYAUmQgRzasoterVnXCL.API_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXwO
   KSTEvcJlDfhYAUmQgRzasoterVnXCM=KSTEvcJlDfhYAUmQgRzasoterVnXCL.makeDefaultCookies()
   KSTEvcJlDfhYAUmQgRzasoterVnXCG=KSTEvcJlDfhYAUmQgRzasoterVnXCL.callRequestCookies('Get',KSTEvcJlDfhYAUmQgRzasoterVnXwH,payload=KSTEvcJlDfhYAUmQgRzasoterVnXWH,params=KSTEvcJlDfhYAUmQgRzasoterVnXwk,headers=KSTEvcJlDfhYAUmQgRzasoterVnXWH,cookies=KSTEvcJlDfhYAUmQgRzasoterVnXCM,redirects=KSTEvcJlDfhYAUmQgRzasoterVnXWP)
   KSTEvcJlDfhYAUmQgRzasoterVnXwP=json.loads(KSTEvcJlDfhYAUmQgRzasoterVnXCG.text)
   if KSTEvcJlDfhYAUmQgRzasoterVnXwP['body']['result']['code']!='000':
    KSTEvcJlDfhYAUmQgRzasoterVnXwM=KSTEvcJlDfhYAUmQgRzasoterVnXwP['body']['result']['message']
    return KSTEvcJlDfhYAUmQgRzasoterVnXwp,KSTEvcJlDfhYAUmQgRzasoterVnXwM
   KSTEvcJlDfhYAUmQgRzasoterVnXwu=KSTEvcJlDfhYAUmQgRzasoterVnXwP['body']['stream']
   if 'drm_license_assertion' in KSTEvcJlDfhYAUmQgRzasoterVnXwu:
    KSTEvcJlDfhYAUmQgRzasoterVnXwM =KSTEvcJlDfhYAUmQgRzasoterVnXwu['drm_license_assertion']
    KSTEvcJlDfhYAUmQgRzasoterVnXwp=KSTEvcJlDfhYAUmQgRzasoterVnXwu['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in KSTEvcJlDfhYAUmQgRzasoterVnXwu['broadcast']):return KSTEvcJlDfhYAUmQgRzasoterVnXwp,KSTEvcJlDfhYAUmQgRzasoterVnXwM
    KSTEvcJlDfhYAUmQgRzasoterVnXwp=KSTEvcJlDfhYAUmQgRzasoterVnXwu['broadcast']['broad_url']
  except KSTEvcJlDfhYAUmQgRzasoterVnXWb as exception:
   KSTEvcJlDfhYAUmQgRzasoterVnXWj(exception)
  KSTEvcJlDfhYAUmQgRzasoterVnXwB=KSTEvcJlDfhYAUmQgRzasoterVnXwx
  KSTEvcJlDfhYAUmQgRzasoterVnXwp=KSTEvcJlDfhYAUmQgRzasoterVnXwp.split('|')[1]
  KSTEvcJlDfhYAUmQgRzasoterVnXwp=KSTEvcJlDfhYAUmQgRzasoterVnXCL.Decrypt_Url(KSTEvcJlDfhYAUmQgRzasoterVnXwp,mediacode,KSTEvcJlDfhYAUmQgRzasoterVnXwB)
  return KSTEvcJlDfhYAUmQgRzasoterVnXwp,KSTEvcJlDfhYAUmQgRzasoterVnXwM
 def CheckQuality(KSTEvcJlDfhYAUmQgRzasoterVnXCL,sel_qt,KSTEvcJlDfhYAUmQgRzasoterVnXwb):
  for KSTEvcJlDfhYAUmQgRzasoterVnXdC in KSTEvcJlDfhYAUmQgRzasoterVnXwb:
   if sel_qt>=KSTEvcJlDfhYAUmQgRzasoterVnXWB(KSTEvcJlDfhYAUmQgRzasoterVnXdC)[0]:return KSTEvcJlDfhYAUmQgRzasoterVnXdC.get(KSTEvcJlDfhYAUmQgRzasoterVnXWB(KSTEvcJlDfhYAUmQgRzasoterVnXdC)[0])
   KSTEvcJlDfhYAUmQgRzasoterVnXdw=KSTEvcJlDfhYAUmQgRzasoterVnXdC.get(KSTEvcJlDfhYAUmQgRzasoterVnXWB(KSTEvcJlDfhYAUmQgRzasoterVnXdC)[0])
  return KSTEvcJlDfhYAUmQgRzasoterVnXdw
 def makeOocUrl(KSTEvcJlDfhYAUmQgRzasoterVnXCL,ooc_params):
  KSTEvcJlDfhYAUmQgRzasoterVnXwH=''
  for KSTEvcJlDfhYAUmQgRzasoterVnXwy,KSTEvcJlDfhYAUmQgRzasoterVnXdq in ooc_params.items():
   KSTEvcJlDfhYAUmQgRzasoterVnXwH+="%s=%s^"%(KSTEvcJlDfhYAUmQgRzasoterVnXwy,KSTEvcJlDfhYAUmQgRzasoterVnXdq)
  return KSTEvcJlDfhYAUmQgRzasoterVnXwH
 def GetLiveChannelList(KSTEvcJlDfhYAUmQgRzasoterVnXCL,stype,page_int):
  KSTEvcJlDfhYAUmQgRzasoterVnXdL=[]
  KSTEvcJlDfhYAUmQgRzasoterVnXdW=KSTEvcJlDfhYAUmQgRzasoterVnXWP
  KSTEvcJlDfhYAUmQgRzasoterVnXdp=KSTEvcJlDfhYAUmQgRzasoterVnXWP
  try:
   KSTEvcJlDfhYAUmQgRzasoterVnXwO ='/v2/media/lives'
   if stype=='onair': 
    KSTEvcJlDfhYAUmQgRzasoterVnXdM='CPCS0100,CPCS0400'
   else:
    KSTEvcJlDfhYAUmQgRzasoterVnXdM='CPCS0300'
   KSTEvcJlDfhYAUmQgRzasoterVnXwk=KSTEvcJlDfhYAUmQgRzasoterVnXCL.GetDefaultParams()
   KSTEvcJlDfhYAUmQgRzasoterVnXwF={'pageNo':KSTEvcJlDfhYAUmQgRzasoterVnXWG(page_int),'pageSize':KSTEvcJlDfhYAUmQgRzasoterVnXWG(KSTEvcJlDfhYAUmQgRzasoterVnXCL.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':KSTEvcJlDfhYAUmQgRzasoterVnXdM,'_':KSTEvcJlDfhYAUmQgRzasoterVnXWG(KSTEvcJlDfhYAUmQgRzasoterVnXCL.GetNoCache(2))}
   KSTEvcJlDfhYAUmQgRzasoterVnXwk.update(KSTEvcJlDfhYAUmQgRzasoterVnXwF)
   KSTEvcJlDfhYAUmQgRzasoterVnXwH=KSTEvcJlDfhYAUmQgRzasoterVnXCL.API_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXwO
   KSTEvcJlDfhYAUmQgRzasoterVnXCG=KSTEvcJlDfhYAUmQgRzasoterVnXCL.callRequestCookies('Get',KSTEvcJlDfhYAUmQgRzasoterVnXwH,payload=KSTEvcJlDfhYAUmQgRzasoterVnXWH,params=KSTEvcJlDfhYAUmQgRzasoterVnXwk,headers=KSTEvcJlDfhYAUmQgRzasoterVnXWH,cookies=KSTEvcJlDfhYAUmQgRzasoterVnXWH)
   KSTEvcJlDfhYAUmQgRzasoterVnXwP=json.loads(KSTEvcJlDfhYAUmQgRzasoterVnXCG.text)
   if not('result' in KSTEvcJlDfhYAUmQgRzasoterVnXwP['body']):return KSTEvcJlDfhYAUmQgRzasoterVnXdL,KSTEvcJlDfhYAUmQgRzasoterVnXdW
   KSTEvcJlDfhYAUmQgRzasoterVnXdi=KSTEvcJlDfhYAUmQgRzasoterVnXwP['body']['result']
   for KSTEvcJlDfhYAUmQgRzasoterVnXwG in KSTEvcJlDfhYAUmQgRzasoterVnXdi:
    KSTEvcJlDfhYAUmQgRzasoterVnXdN=KSTEvcJlDfhYAUmQgRzasoterVnXdk=KSTEvcJlDfhYAUmQgRzasoterVnXdF=''
    KSTEvcJlDfhYAUmQgRzasoterVnXdx=KSTEvcJlDfhYAUmQgRzasoterVnXqi=''
    KSTEvcJlDfhYAUmQgRzasoterVnXdO=KSTEvcJlDfhYAUmQgRzasoterVnXwG['live_code']
    if KSTEvcJlDfhYAUmQgRzasoterVnXdO=='C01345':KSTEvcJlDfhYAUmQgRzasoterVnXdp=KSTEvcJlDfhYAUmQgRzasoterVnXWu 
    KSTEvcJlDfhYAUmQgRzasoterVnXdN =KSTEvcJlDfhYAUmQgRzasoterVnXwG['schedule']['channel']['name']['ko']
    if KSTEvcJlDfhYAUmQgRzasoterVnXwG['schedule']['episode']!=KSTEvcJlDfhYAUmQgRzasoterVnXWH:
     KSTEvcJlDfhYAUmQgRzasoterVnXdk =KSTEvcJlDfhYAUmQgRzasoterVnXwG['schedule']['program']['name']['ko']
     KSTEvcJlDfhYAUmQgRzasoterVnXdk =KSTEvcJlDfhYAUmQgRzasoterVnXdk+', '+KSTEvcJlDfhYAUmQgRzasoterVnXWG(KSTEvcJlDfhYAUmQgRzasoterVnXwG['schedule']['episode']['frequency'])+'회'
     KSTEvcJlDfhYAUmQgRzasoterVnXdF=KSTEvcJlDfhYAUmQgRzasoterVnXwG['schedule']['episode']['synopsis']['ko']
    else:
     KSTEvcJlDfhYAUmQgRzasoterVnXdk =KSTEvcJlDfhYAUmQgRzasoterVnXwG['schedule']['program']['name']['ko']
     KSTEvcJlDfhYAUmQgRzasoterVnXdF=KSTEvcJlDfhYAUmQgRzasoterVnXwG['schedule']['program']['synopsis']['ko']
    try: 
     KSTEvcJlDfhYAUmQgRzasoterVnXdH =''
     KSTEvcJlDfhYAUmQgRzasoterVnXdP =''
     KSTEvcJlDfhYAUmQgRzasoterVnXdy=''
     KSTEvcJlDfhYAUmQgRzasoterVnXdI =''
     KSTEvcJlDfhYAUmQgRzasoterVnXdu =''
     KSTEvcJlDfhYAUmQgRzasoterVnXdj =''
     for KSTEvcJlDfhYAUmQgRzasoterVnXdb in KSTEvcJlDfhYAUmQgRzasoterVnXwG['schedule']['program']['image']:
      if KSTEvcJlDfhYAUmQgRzasoterVnXdb['code']=='CAIP0900':KSTEvcJlDfhYAUmQgRzasoterVnXdP =KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXdb['url']
      elif KSTEvcJlDfhYAUmQgRzasoterVnXdb['code']=='CAIP1800':KSTEvcJlDfhYAUmQgRzasoterVnXdy=KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXdb['url']
      elif KSTEvcJlDfhYAUmQgRzasoterVnXdb['code']=='CAIP2000':KSTEvcJlDfhYAUmQgRzasoterVnXdI =KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXdb['url']
      elif KSTEvcJlDfhYAUmQgRzasoterVnXdb['code']=='CAIP1900':KSTEvcJlDfhYAUmQgRzasoterVnXdu =KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXdb['url']
      elif KSTEvcJlDfhYAUmQgRzasoterVnXdb['code']=='CAIP0200':KSTEvcJlDfhYAUmQgRzasoterVnXdj =KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXdb['url']
      elif KSTEvcJlDfhYAUmQgRzasoterVnXdb['code']=='CAIP0500':KSTEvcJlDfhYAUmQgRzasoterVnXdH =KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXdb['url']
      elif KSTEvcJlDfhYAUmQgRzasoterVnXdb['code']=='CAIP0800':KSTEvcJlDfhYAUmQgRzasoterVnXdH =KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXdb['url']
     if KSTEvcJlDfhYAUmQgRzasoterVnXdH=='':
      for KSTEvcJlDfhYAUmQgRzasoterVnXdb in KSTEvcJlDfhYAUmQgRzasoterVnXwG['schedule']['channel']['image']:
       if KSTEvcJlDfhYAUmQgRzasoterVnXdb['code']=='CAIC0400':KSTEvcJlDfhYAUmQgRzasoterVnXdH =KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXdb['url']
       elif KSTEvcJlDfhYAUmQgRzasoterVnXdb['code']=='CAIC1400':KSTEvcJlDfhYAUmQgRzasoterVnXdH =KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXdb['url']
       elif KSTEvcJlDfhYAUmQgRzasoterVnXdb['code']=='CAIC1900':KSTEvcJlDfhYAUmQgRzasoterVnXdH =KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXdb['url']
    except:
     KSTEvcJlDfhYAUmQgRzasoterVnXWH
    try:
     KSTEvcJlDfhYAUmQgRzasoterVnXdG =[]
     KSTEvcJlDfhYAUmQgRzasoterVnXdB=[]
     KSTEvcJlDfhYAUmQgRzasoterVnXqC =[]
     KSTEvcJlDfhYAUmQgRzasoterVnXqw=''
     KSTEvcJlDfhYAUmQgRzasoterVnXqd=''
     KSTEvcJlDfhYAUmQgRzasoterVnXqL=''
     for KSTEvcJlDfhYAUmQgRzasoterVnXqW in KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('schedule').get('program').get('actor'):
      if KSTEvcJlDfhYAUmQgRzasoterVnXqW!='' and KSTEvcJlDfhYAUmQgRzasoterVnXqW!=u'없음':KSTEvcJlDfhYAUmQgRzasoterVnXdG.append(KSTEvcJlDfhYAUmQgRzasoterVnXqW)
     for KSTEvcJlDfhYAUmQgRzasoterVnXqp in KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('schedule').get('program').get('director'):
      if KSTEvcJlDfhYAUmQgRzasoterVnXqp!='' and KSTEvcJlDfhYAUmQgRzasoterVnXqp!='-' and KSTEvcJlDfhYAUmQgRzasoterVnXqp!=u'없음':KSTEvcJlDfhYAUmQgRzasoterVnXdB.append(KSTEvcJlDfhYAUmQgRzasoterVnXqp)
     if KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('schedule').get('program').get('category1_name').get('ko')!='':
      KSTEvcJlDfhYAUmQgRzasoterVnXqC.append(KSTEvcJlDfhYAUmQgRzasoterVnXwG['schedule']['program']['category1_name']['ko'])
     if KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('schedule').get('program').get('category2_name').get('ko')!='':
      KSTEvcJlDfhYAUmQgRzasoterVnXqC.append(KSTEvcJlDfhYAUmQgRzasoterVnXwG['schedule']['program']['category2_name']['ko'])
     if KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('schedule').get('program').get('product_year'):KSTEvcJlDfhYAUmQgRzasoterVnXqw=KSTEvcJlDfhYAUmQgRzasoterVnXwG['schedule']['program']['product_year']
     if KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('schedule').get('program').get('grade_code') :KSTEvcJlDfhYAUmQgRzasoterVnXqd= KSTEvcJlDfhYAUmQgRzasoterVnXCq.get(KSTEvcJlDfhYAUmQgRzasoterVnXwG['schedule']['program']['grade_code'])
     if 'broad_dt' in KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('schedule').get('program'):
      KSTEvcJlDfhYAUmQgRzasoterVnXqM =KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('schedule').get('program').get('broad_dt')
      KSTEvcJlDfhYAUmQgRzasoterVnXqL='%s-%s-%s'%(KSTEvcJlDfhYAUmQgRzasoterVnXqM[:4],KSTEvcJlDfhYAUmQgRzasoterVnXqM[4:6],KSTEvcJlDfhYAUmQgRzasoterVnXqM[6:])
    except:
     KSTEvcJlDfhYAUmQgRzasoterVnXWH
    KSTEvcJlDfhYAUmQgRzasoterVnXdx=KSTEvcJlDfhYAUmQgRzasoterVnXWG(KSTEvcJlDfhYAUmQgRzasoterVnXwG['schedule']['broadcast_start_time'])[8:12]
    KSTEvcJlDfhYAUmQgRzasoterVnXqi =KSTEvcJlDfhYAUmQgRzasoterVnXWG(KSTEvcJlDfhYAUmQgRzasoterVnXwG['schedule']['broadcast_end_time'])[8:12]
    KSTEvcJlDfhYAUmQgRzasoterVnXqN={'channel':KSTEvcJlDfhYAUmQgRzasoterVnXdN,'title':KSTEvcJlDfhYAUmQgRzasoterVnXdk,'mediacode':KSTEvcJlDfhYAUmQgRzasoterVnXdO,'thumbnail':{'poster':KSTEvcJlDfhYAUmQgRzasoterVnXdP,'thumb':KSTEvcJlDfhYAUmQgRzasoterVnXdH,'clearlogo':KSTEvcJlDfhYAUmQgRzasoterVnXdy,'icon':KSTEvcJlDfhYAUmQgRzasoterVnXdI,'fanart':KSTEvcJlDfhYAUmQgRzasoterVnXdj},'synopsis':KSTEvcJlDfhYAUmQgRzasoterVnXdF,'channelepg':' [%s:%s ~ %s:%s]'%(KSTEvcJlDfhYAUmQgRzasoterVnXdx[0:2],KSTEvcJlDfhYAUmQgRzasoterVnXdx[2:],KSTEvcJlDfhYAUmQgRzasoterVnXqi[0:2],KSTEvcJlDfhYAUmQgRzasoterVnXqi[2:]),'cast':KSTEvcJlDfhYAUmQgRzasoterVnXdG,'director':KSTEvcJlDfhYAUmQgRzasoterVnXdB,'info_genre':KSTEvcJlDfhYAUmQgRzasoterVnXqC,'year':KSTEvcJlDfhYAUmQgRzasoterVnXqw,'mpaa':KSTEvcJlDfhYAUmQgRzasoterVnXqd,'premiered':KSTEvcJlDfhYAUmQgRzasoterVnXqL}
    KSTEvcJlDfhYAUmQgRzasoterVnXdL.append(KSTEvcJlDfhYAUmQgRzasoterVnXqN)
   if KSTEvcJlDfhYAUmQgRzasoterVnXwP['body']['has_more']=='Y':
    KSTEvcJlDfhYAUmQgRzasoterVnXdW=KSTEvcJlDfhYAUmQgRzasoterVnXWu
   else:
    KSTEvcJlDfhYAUmQgRzasoterVnXqN={'channel':'OCN Original','title':'temp','mediacode':'C01345','thumbnail':'http://image.tving.com/upload/cms/caic/CAIC0400/C01345.png','cast':[],'director':[]}
  except KSTEvcJlDfhYAUmQgRzasoterVnXWb as exception:
   KSTEvcJlDfhYAUmQgRzasoterVnXWj(exception)
  return KSTEvcJlDfhYAUmQgRzasoterVnXdL,KSTEvcJlDfhYAUmQgRzasoterVnXdW
 def GetProgramList(KSTEvcJlDfhYAUmQgRzasoterVnXCL,genre,orderby,page_int,genreCode='all'):
  KSTEvcJlDfhYAUmQgRzasoterVnXdL=[]
  KSTEvcJlDfhYAUmQgRzasoterVnXdW=KSTEvcJlDfhYAUmQgRzasoterVnXWP
  try:
   KSTEvcJlDfhYAUmQgRzasoterVnXwO ='/v2/media/episodes'
   KSTEvcJlDfhYAUmQgRzasoterVnXwk=KSTEvcJlDfhYAUmQgRzasoterVnXCL.GetDefaultParams()
   KSTEvcJlDfhYAUmQgRzasoterVnXwF={'pageNo':KSTEvcJlDfhYAUmQgRzasoterVnXWG(page_int),'pageSize':KSTEvcJlDfhYAUmQgRzasoterVnXWG(KSTEvcJlDfhYAUmQgRzasoterVnXCL.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','_':KSTEvcJlDfhYAUmQgRzasoterVnXWG(KSTEvcJlDfhYAUmQgRzasoterVnXCL.GetNoCache(2))}
   if genre !='all':KSTEvcJlDfhYAUmQgRzasoterVnXwF['categoryCode']=genre
   if genreCode!='all':KSTEvcJlDfhYAUmQgRzasoterVnXwF['genreCode'] =genreCode 
   KSTEvcJlDfhYAUmQgRzasoterVnXwk.update(KSTEvcJlDfhYAUmQgRzasoterVnXwF)
   KSTEvcJlDfhYAUmQgRzasoterVnXwH=KSTEvcJlDfhYAUmQgRzasoterVnXCL.API_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXwO
   KSTEvcJlDfhYAUmQgRzasoterVnXCG=KSTEvcJlDfhYAUmQgRzasoterVnXCL.callRequestCookies('Get',KSTEvcJlDfhYAUmQgRzasoterVnXwH,payload=KSTEvcJlDfhYAUmQgRzasoterVnXWH,params=KSTEvcJlDfhYAUmQgRzasoterVnXwk,headers=KSTEvcJlDfhYAUmQgRzasoterVnXWH,cookies=KSTEvcJlDfhYAUmQgRzasoterVnXWH)
   KSTEvcJlDfhYAUmQgRzasoterVnXwP=json.loads(KSTEvcJlDfhYAUmQgRzasoterVnXCG.text)
   if not('result' in KSTEvcJlDfhYAUmQgRzasoterVnXwP['body']):return KSTEvcJlDfhYAUmQgRzasoterVnXdL,KSTEvcJlDfhYAUmQgRzasoterVnXdW
   KSTEvcJlDfhYAUmQgRzasoterVnXdi=KSTEvcJlDfhYAUmQgRzasoterVnXwP['body']['result']
   for KSTEvcJlDfhYAUmQgRzasoterVnXwG in KSTEvcJlDfhYAUmQgRzasoterVnXdi:
    KSTEvcJlDfhYAUmQgRzasoterVnXqx=KSTEvcJlDfhYAUmQgRzasoterVnXwG['program']['code']
    KSTEvcJlDfhYAUmQgRzasoterVnXdk =KSTEvcJlDfhYAUmQgRzasoterVnXwG['program']['name']['ko']
    KSTEvcJlDfhYAUmQgRzasoterVnXqd =KSTEvcJlDfhYAUmQgRzasoterVnXCq.get(KSTEvcJlDfhYAUmQgRzasoterVnXwG['program'].get('grade_code'))
    KSTEvcJlDfhYAUmQgRzasoterVnXdP =''
    KSTEvcJlDfhYAUmQgRzasoterVnXdH =''
    KSTEvcJlDfhYAUmQgRzasoterVnXdy=''
    KSTEvcJlDfhYAUmQgRzasoterVnXdI =''
    KSTEvcJlDfhYAUmQgRzasoterVnXdu =''
    for KSTEvcJlDfhYAUmQgRzasoterVnXdb in KSTEvcJlDfhYAUmQgRzasoterVnXwG['program']['image']:
     if KSTEvcJlDfhYAUmQgRzasoterVnXdb['code']=='CAIP0900':KSTEvcJlDfhYAUmQgRzasoterVnXdP =KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXdb['url']
     elif KSTEvcJlDfhYAUmQgRzasoterVnXdb['code']=='CAIP0200':KSTEvcJlDfhYAUmQgRzasoterVnXdH =KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXdb['url']
     elif KSTEvcJlDfhYAUmQgRzasoterVnXdb['code']=='CAIP1800':KSTEvcJlDfhYAUmQgRzasoterVnXdy=KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXdb['url']
     elif KSTEvcJlDfhYAUmQgRzasoterVnXdb['code']=='CAIP2000':KSTEvcJlDfhYAUmQgRzasoterVnXdI =KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXdb['url']
     elif KSTEvcJlDfhYAUmQgRzasoterVnXdb['code']=='CAIP1900':KSTEvcJlDfhYAUmQgRzasoterVnXdu =KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXdb['url']
    KSTEvcJlDfhYAUmQgRzasoterVnXdF =KSTEvcJlDfhYAUmQgRzasoterVnXwG['program']['synopsis']['ko']
    try:
     KSTEvcJlDfhYAUmQgRzasoterVnXqO=KSTEvcJlDfhYAUmQgRzasoterVnXwG['channel']['name']['ko']
    except:
     KSTEvcJlDfhYAUmQgRzasoterVnXqO=''
    try:
     KSTEvcJlDfhYAUmQgRzasoterVnXdG =[]
     KSTEvcJlDfhYAUmQgRzasoterVnXdB=[]
     KSTEvcJlDfhYAUmQgRzasoterVnXqC =[]
     KSTEvcJlDfhYAUmQgRzasoterVnXqw =''
     KSTEvcJlDfhYAUmQgRzasoterVnXqL=''
     for KSTEvcJlDfhYAUmQgRzasoterVnXqW in KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('program').get('actor'):
      if KSTEvcJlDfhYAUmQgRzasoterVnXqW!='' and KSTEvcJlDfhYAUmQgRzasoterVnXqW!='-' and KSTEvcJlDfhYAUmQgRzasoterVnXqW!=u'없음':KSTEvcJlDfhYAUmQgRzasoterVnXdG.append(KSTEvcJlDfhYAUmQgRzasoterVnXqW)
     for KSTEvcJlDfhYAUmQgRzasoterVnXqp in KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('program').get('director'):
      if KSTEvcJlDfhYAUmQgRzasoterVnXqp!='' and KSTEvcJlDfhYAUmQgRzasoterVnXqp!='-' and KSTEvcJlDfhYAUmQgRzasoterVnXqp!=u'없음':KSTEvcJlDfhYAUmQgRzasoterVnXdB.append(KSTEvcJlDfhYAUmQgRzasoterVnXqp)
     if KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('program').get('category1_name').get('ko')!='':
      KSTEvcJlDfhYAUmQgRzasoterVnXqC.append(KSTEvcJlDfhYAUmQgRzasoterVnXwG['program']['category1_name']['ko'])
     if KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('program').get('category2_name').get('ko')!='':
      KSTEvcJlDfhYAUmQgRzasoterVnXqC.append(KSTEvcJlDfhYAUmQgRzasoterVnXwG['program']['category2_name']['ko'])
     if KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('program').get('product_year'):KSTEvcJlDfhYAUmQgRzasoterVnXqw=KSTEvcJlDfhYAUmQgRzasoterVnXwG['program']['product_year']
     if 'broad_dt' in KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('program'):
      KSTEvcJlDfhYAUmQgRzasoterVnXqM =KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('program').get('broad_dt')
      KSTEvcJlDfhYAUmQgRzasoterVnXqL='%s-%s-%s'%(KSTEvcJlDfhYAUmQgRzasoterVnXqM[:4],KSTEvcJlDfhYAUmQgRzasoterVnXqM[4:6],KSTEvcJlDfhYAUmQgRzasoterVnXqM[6:])
    except:
     KSTEvcJlDfhYAUmQgRzasoterVnXWH
    KSTEvcJlDfhYAUmQgRzasoterVnXqN={'program':KSTEvcJlDfhYAUmQgRzasoterVnXqx,'title':KSTEvcJlDfhYAUmQgRzasoterVnXdk,'thumbnail':{'poster':KSTEvcJlDfhYAUmQgRzasoterVnXdP,'thumb':KSTEvcJlDfhYAUmQgRzasoterVnXdH,'clearlogo':KSTEvcJlDfhYAUmQgRzasoterVnXdy,'icon':KSTEvcJlDfhYAUmQgRzasoterVnXdI,'banner':KSTEvcJlDfhYAUmQgRzasoterVnXdu,'fanart':KSTEvcJlDfhYAUmQgRzasoterVnXdH},'synopsis':KSTEvcJlDfhYAUmQgRzasoterVnXdF,'channel':KSTEvcJlDfhYAUmQgRzasoterVnXqO,'cast':KSTEvcJlDfhYAUmQgRzasoterVnXdG,'director':KSTEvcJlDfhYAUmQgRzasoterVnXdB,'info_genre':KSTEvcJlDfhYAUmQgRzasoterVnXqC,'year':KSTEvcJlDfhYAUmQgRzasoterVnXqw,'premiered':KSTEvcJlDfhYAUmQgRzasoterVnXqL,'mpaa':KSTEvcJlDfhYAUmQgRzasoterVnXqd}
    KSTEvcJlDfhYAUmQgRzasoterVnXdL.append(KSTEvcJlDfhYAUmQgRzasoterVnXqN)
   if KSTEvcJlDfhYAUmQgRzasoterVnXwP['body']['has_more']=='Y':KSTEvcJlDfhYAUmQgRzasoterVnXdW=KSTEvcJlDfhYAUmQgRzasoterVnXWu
  except KSTEvcJlDfhYAUmQgRzasoterVnXWb as exception:
   KSTEvcJlDfhYAUmQgRzasoterVnXWj(exception)
  return KSTEvcJlDfhYAUmQgRzasoterVnXdL,KSTEvcJlDfhYAUmQgRzasoterVnXdW
 def GetEpisodeList(KSTEvcJlDfhYAUmQgRzasoterVnXCL,program_code,page_int,orderby='desc'):
  KSTEvcJlDfhYAUmQgRzasoterVnXdL=[]
  KSTEvcJlDfhYAUmQgRzasoterVnXdW=KSTEvcJlDfhYAUmQgRzasoterVnXWP
  try:
   KSTEvcJlDfhYAUmQgRzasoterVnXwO ='/v2/media/frequency/program/'+program_code
   KSTEvcJlDfhYAUmQgRzasoterVnXwk=KSTEvcJlDfhYAUmQgRzasoterVnXCL.GetDefaultParams()
   KSTEvcJlDfhYAUmQgRzasoterVnXwF={'pageNo':'1','pageSize':'10','order':'new','free':'all','adult':'all','scope':'all','_':KSTEvcJlDfhYAUmQgRzasoterVnXWG(KSTEvcJlDfhYAUmQgRzasoterVnXCL.GetNoCache(2))}
   KSTEvcJlDfhYAUmQgRzasoterVnXwk.update(KSTEvcJlDfhYAUmQgRzasoterVnXwF)
   KSTEvcJlDfhYAUmQgRzasoterVnXwH=KSTEvcJlDfhYAUmQgRzasoterVnXCL.API_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXwO
   KSTEvcJlDfhYAUmQgRzasoterVnXCG=KSTEvcJlDfhYAUmQgRzasoterVnXCL.callRequestCookies('Get',KSTEvcJlDfhYAUmQgRzasoterVnXwH,payload=KSTEvcJlDfhYAUmQgRzasoterVnXWH,params=KSTEvcJlDfhYAUmQgRzasoterVnXwk,headers=KSTEvcJlDfhYAUmQgRzasoterVnXWH,cookies=KSTEvcJlDfhYAUmQgRzasoterVnXWH)
   KSTEvcJlDfhYAUmQgRzasoterVnXwP=json.loads(KSTEvcJlDfhYAUmQgRzasoterVnXCG.text)
   if not('result' in KSTEvcJlDfhYAUmQgRzasoterVnXwP['body']):return KSTEvcJlDfhYAUmQgRzasoterVnXdL,KSTEvcJlDfhYAUmQgRzasoterVnXdW
   KSTEvcJlDfhYAUmQgRzasoterVnXdi=KSTEvcJlDfhYAUmQgRzasoterVnXwP['body']['result']
   KSTEvcJlDfhYAUmQgRzasoterVnXqk=KSTEvcJlDfhYAUmQgRzasoterVnXWy(KSTEvcJlDfhYAUmQgRzasoterVnXwP['body']['total_count'])
   KSTEvcJlDfhYAUmQgRzasoterVnXqF =KSTEvcJlDfhYAUmQgRzasoterVnXWy(KSTEvcJlDfhYAUmQgRzasoterVnXqk//(KSTEvcJlDfhYAUmQgRzasoterVnXCL.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    KSTEvcJlDfhYAUmQgRzasoterVnXqH =(KSTEvcJlDfhYAUmQgRzasoterVnXqk-1)-((page_int-1)*KSTEvcJlDfhYAUmQgRzasoterVnXCL.EPISODE_LIMIT)
   else:
    KSTEvcJlDfhYAUmQgRzasoterVnXqH =(page_int-1)*KSTEvcJlDfhYAUmQgRzasoterVnXCL.EPISODE_LIMIT
   for i in KSTEvcJlDfhYAUmQgRzasoterVnXWI(KSTEvcJlDfhYAUmQgRzasoterVnXCL.EPISODE_LIMIT):
    if orderby=='desc':
     KSTEvcJlDfhYAUmQgRzasoterVnXqP=KSTEvcJlDfhYAUmQgRzasoterVnXqH-i
     if KSTEvcJlDfhYAUmQgRzasoterVnXqP<0:break
    else:
     KSTEvcJlDfhYAUmQgRzasoterVnXqP=KSTEvcJlDfhYAUmQgRzasoterVnXqH+i
     if KSTEvcJlDfhYAUmQgRzasoterVnXqP>=KSTEvcJlDfhYAUmQgRzasoterVnXqk:break
    KSTEvcJlDfhYAUmQgRzasoterVnXqy=KSTEvcJlDfhYAUmQgRzasoterVnXdi[KSTEvcJlDfhYAUmQgRzasoterVnXqP]['episode']['code']
    KSTEvcJlDfhYAUmQgRzasoterVnXdk =KSTEvcJlDfhYAUmQgRzasoterVnXdi[KSTEvcJlDfhYAUmQgRzasoterVnXqP]['vod_name']['ko']
    KSTEvcJlDfhYAUmQgRzasoterVnXqI =''
    try:
     KSTEvcJlDfhYAUmQgRzasoterVnXqM=KSTEvcJlDfhYAUmQgRzasoterVnXWG(KSTEvcJlDfhYAUmQgRzasoterVnXdi[KSTEvcJlDfhYAUmQgRzasoterVnXqP]['episode']['broadcast_date'])
     KSTEvcJlDfhYAUmQgRzasoterVnXqI='%s-%s-%s'%(KSTEvcJlDfhYAUmQgRzasoterVnXqM[:4],KSTEvcJlDfhYAUmQgRzasoterVnXqM[4:6],KSTEvcJlDfhYAUmQgRzasoterVnXqM[6:])
    except:
     KSTEvcJlDfhYAUmQgRzasoterVnXWH
    try:
     if KSTEvcJlDfhYAUmQgRzasoterVnXdi[KSTEvcJlDfhYAUmQgRzasoterVnXqP]['episode']['pip_cliptype']=='C012':
      KSTEvcJlDfhYAUmQgRzasoterVnXqI+=' - Quick VOD'
    except:
     KSTEvcJlDfhYAUmQgRzasoterVnXWH
    KSTEvcJlDfhYAUmQgRzasoterVnXdF =KSTEvcJlDfhYAUmQgRzasoterVnXdi[KSTEvcJlDfhYAUmQgRzasoterVnXqP]['episode']['synopsis']['ko']
    KSTEvcJlDfhYAUmQgRzasoterVnXdP =''
    KSTEvcJlDfhYAUmQgRzasoterVnXdH =''
    KSTEvcJlDfhYAUmQgRzasoterVnXdy=''
    KSTEvcJlDfhYAUmQgRzasoterVnXdI =''
    KSTEvcJlDfhYAUmQgRzasoterVnXdu =''
    KSTEvcJlDfhYAUmQgRzasoterVnXdj =''
    for KSTEvcJlDfhYAUmQgRzasoterVnXdb in KSTEvcJlDfhYAUmQgRzasoterVnXdi[KSTEvcJlDfhYAUmQgRzasoterVnXqP]['program']['image']:
     if KSTEvcJlDfhYAUmQgRzasoterVnXdb['code']=='CAIP0900':KSTEvcJlDfhYAUmQgRzasoterVnXdP =KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXdb['url']
     elif KSTEvcJlDfhYAUmQgRzasoterVnXdb['code']=='CAIP1800':KSTEvcJlDfhYAUmQgRzasoterVnXdy=KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXdb['url']
     elif KSTEvcJlDfhYAUmQgRzasoterVnXdb['code']=='CAIP2000':KSTEvcJlDfhYAUmQgRzasoterVnXdI =KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXdb['url']
     elif KSTEvcJlDfhYAUmQgRzasoterVnXdb['code']=='CAIP1900':KSTEvcJlDfhYAUmQgRzasoterVnXdu =KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXdb['url']
     elif KSTEvcJlDfhYAUmQgRzasoterVnXdb['code']=='CAIP0200':KSTEvcJlDfhYAUmQgRzasoterVnXdj =KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXdb['url']
    for KSTEvcJlDfhYAUmQgRzasoterVnXdb in KSTEvcJlDfhYAUmQgRzasoterVnXdi[KSTEvcJlDfhYAUmQgRzasoterVnXqP]['episode']['image']:
     if KSTEvcJlDfhYAUmQgRzasoterVnXdb['code']=='CAIE0400':KSTEvcJlDfhYAUmQgRzasoterVnXdH =KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXdb['url']
    try:
     KSTEvcJlDfhYAUmQgRzasoterVnXqu=KSTEvcJlDfhYAUmQgRzasoterVnXqb=KSTEvcJlDfhYAUmQgRzasoterVnXqG=''
     KSTEvcJlDfhYAUmQgRzasoterVnXqj=0
     KSTEvcJlDfhYAUmQgRzasoterVnXqu =KSTEvcJlDfhYAUmQgRzasoterVnXdi[KSTEvcJlDfhYAUmQgRzasoterVnXqP]['program']['name']['ko']
     KSTEvcJlDfhYAUmQgRzasoterVnXqb =KSTEvcJlDfhYAUmQgRzasoterVnXqI
     KSTEvcJlDfhYAUmQgRzasoterVnXqG =KSTEvcJlDfhYAUmQgRzasoterVnXdi[KSTEvcJlDfhYAUmQgRzasoterVnXqP]['channel']['name']['ko']
     if 'frequency' in KSTEvcJlDfhYAUmQgRzasoterVnXdi[KSTEvcJlDfhYAUmQgRzasoterVnXqP]['episode']:KSTEvcJlDfhYAUmQgRzasoterVnXqj=KSTEvcJlDfhYAUmQgRzasoterVnXdi[KSTEvcJlDfhYAUmQgRzasoterVnXqP]['episode']['frequency']
    except:
     KSTEvcJlDfhYAUmQgRzasoterVnXWH
    KSTEvcJlDfhYAUmQgRzasoterVnXqN={'episode':KSTEvcJlDfhYAUmQgRzasoterVnXqy,'title':KSTEvcJlDfhYAUmQgRzasoterVnXdk,'subtitle':KSTEvcJlDfhYAUmQgRzasoterVnXqI,'thumbnail':{'poster':KSTEvcJlDfhYAUmQgRzasoterVnXdP,'thumb':KSTEvcJlDfhYAUmQgRzasoterVnXdH,'clearlogo':KSTEvcJlDfhYAUmQgRzasoterVnXdy,'icon':KSTEvcJlDfhYAUmQgRzasoterVnXdI,'banner':KSTEvcJlDfhYAUmQgRzasoterVnXdu,'fanart':KSTEvcJlDfhYAUmQgRzasoterVnXdj},'synopsis':KSTEvcJlDfhYAUmQgRzasoterVnXdF,'info_title':KSTEvcJlDfhYAUmQgRzasoterVnXqu,'aired':KSTEvcJlDfhYAUmQgRzasoterVnXqb,'studio':KSTEvcJlDfhYAUmQgRzasoterVnXqG,'frequency':KSTEvcJlDfhYAUmQgRzasoterVnXqj}
    KSTEvcJlDfhYAUmQgRzasoterVnXdL.append(KSTEvcJlDfhYAUmQgRzasoterVnXqN)
   if KSTEvcJlDfhYAUmQgRzasoterVnXqF>page_int:KSTEvcJlDfhYAUmQgRzasoterVnXdW=KSTEvcJlDfhYAUmQgRzasoterVnXWu
  except KSTEvcJlDfhYAUmQgRzasoterVnXWb as exception:
   KSTEvcJlDfhYAUmQgRzasoterVnXWj(exception)
  return KSTEvcJlDfhYAUmQgRzasoterVnXdL,KSTEvcJlDfhYAUmQgRzasoterVnXdW,KSTEvcJlDfhYAUmQgRzasoterVnXqF
 def GetMovieList(KSTEvcJlDfhYAUmQgRzasoterVnXCL,genre,orderby,page_int):
  KSTEvcJlDfhYAUmQgRzasoterVnXdL=[]
  KSTEvcJlDfhYAUmQgRzasoterVnXdW=KSTEvcJlDfhYAUmQgRzasoterVnXWP
  try:
   KSTEvcJlDfhYAUmQgRzasoterVnXwO ='/v2/media/movies'
   KSTEvcJlDfhYAUmQgRzasoterVnXwk=KSTEvcJlDfhYAUmQgRzasoterVnXCL.GetDefaultParams()
   KSTEvcJlDfhYAUmQgRzasoterVnXwF={'pageNo':KSTEvcJlDfhYAUmQgRzasoterVnXWG(page_int),'pageSize':KSTEvcJlDfhYAUmQgRzasoterVnXWG(KSTEvcJlDfhYAUmQgRzasoterVnXCL.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','_':KSTEvcJlDfhYAUmQgRzasoterVnXWG(KSTEvcJlDfhYAUmQgRzasoterVnXCL.GetNoCache(2))}
   if genre!='all' :KSTEvcJlDfhYAUmQgRzasoterVnXwF['multiCategoryCode']=genre
   KSTEvcJlDfhYAUmQgRzasoterVnXwF['productPackageCode']=','.join(KSTEvcJlDfhYAUmQgRzasoterVnXCL.MOVIE_LITE)
   KSTEvcJlDfhYAUmQgRzasoterVnXwk.update(KSTEvcJlDfhYAUmQgRzasoterVnXwF)
   KSTEvcJlDfhYAUmQgRzasoterVnXwH=KSTEvcJlDfhYAUmQgRzasoterVnXCL.API_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXwO
   KSTEvcJlDfhYAUmQgRzasoterVnXCG=KSTEvcJlDfhYAUmQgRzasoterVnXCL.callRequestCookies('Get',KSTEvcJlDfhYAUmQgRzasoterVnXwH,payload=KSTEvcJlDfhYAUmQgRzasoterVnXWH,params=KSTEvcJlDfhYAUmQgRzasoterVnXwk,headers=KSTEvcJlDfhYAUmQgRzasoterVnXWH,cookies=KSTEvcJlDfhYAUmQgRzasoterVnXWH)
   KSTEvcJlDfhYAUmQgRzasoterVnXwP=json.loads(KSTEvcJlDfhYAUmQgRzasoterVnXCG.text)
   if not('result' in KSTEvcJlDfhYAUmQgRzasoterVnXwP['body']):return KSTEvcJlDfhYAUmQgRzasoterVnXdL,KSTEvcJlDfhYAUmQgRzasoterVnXdW
   KSTEvcJlDfhYAUmQgRzasoterVnXdi=KSTEvcJlDfhYAUmQgRzasoterVnXwP['body']['result']
   for KSTEvcJlDfhYAUmQgRzasoterVnXwG in KSTEvcJlDfhYAUmQgRzasoterVnXdi:
    KSTEvcJlDfhYAUmQgRzasoterVnXqB =KSTEvcJlDfhYAUmQgRzasoterVnXwG['movie']['code']
    KSTEvcJlDfhYAUmQgRzasoterVnXdk =KSTEvcJlDfhYAUmQgRzasoterVnXwG['movie']['name']['ko'].strip()
    KSTEvcJlDfhYAUmQgRzasoterVnXdk +=u' (%s)'%(KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('movie').get('product_year'))
    KSTEvcJlDfhYAUmQgRzasoterVnXdP=''
    KSTEvcJlDfhYAUmQgRzasoterVnXdH =''
    KSTEvcJlDfhYAUmQgRzasoterVnXdy=''
    for KSTEvcJlDfhYAUmQgRzasoterVnXdb in KSTEvcJlDfhYAUmQgRzasoterVnXwG['movie']['image']:
     if KSTEvcJlDfhYAUmQgRzasoterVnXdb['code']=='CAIM2100':KSTEvcJlDfhYAUmQgRzasoterVnXdP =KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXdb['url']
     elif KSTEvcJlDfhYAUmQgRzasoterVnXdb['code']=='CAIM0400':KSTEvcJlDfhYAUmQgRzasoterVnXdH =KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXdb['url']
     elif KSTEvcJlDfhYAUmQgRzasoterVnXdb['code']=='CAIM1800':KSTEvcJlDfhYAUmQgRzasoterVnXdy=KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXdb['url']
    KSTEvcJlDfhYAUmQgRzasoterVnXdF =KSTEvcJlDfhYAUmQgRzasoterVnXwG['movie']['story']['ko']
    try:
     KSTEvcJlDfhYAUmQgRzasoterVnXqu =KSTEvcJlDfhYAUmQgRzasoterVnXwG['movie']['name']['ko'].strip()
     KSTEvcJlDfhYAUmQgRzasoterVnXqw =KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('movie').get('product_year')
     KSTEvcJlDfhYAUmQgRzasoterVnXqd =KSTEvcJlDfhYAUmQgRzasoterVnXCq.get(KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('grade_code'))
     KSTEvcJlDfhYAUmQgRzasoterVnXdG=[]
     KSTEvcJlDfhYAUmQgRzasoterVnXdB=[]
     KSTEvcJlDfhYAUmQgRzasoterVnXqC=[]
     KSTEvcJlDfhYAUmQgRzasoterVnXLC=0
     KSTEvcJlDfhYAUmQgRzasoterVnXqL=''
     KSTEvcJlDfhYAUmQgRzasoterVnXqG =''
     for KSTEvcJlDfhYAUmQgRzasoterVnXqW in KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('movie').get('actor'):
      if KSTEvcJlDfhYAUmQgRzasoterVnXqW!='':KSTEvcJlDfhYAUmQgRzasoterVnXdG.append(KSTEvcJlDfhYAUmQgRzasoterVnXqW)
     for KSTEvcJlDfhYAUmQgRzasoterVnXqp in KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('movie').get('director'):
      if KSTEvcJlDfhYAUmQgRzasoterVnXqp!='':KSTEvcJlDfhYAUmQgRzasoterVnXdB.append(KSTEvcJlDfhYAUmQgRzasoterVnXqp)
     if KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('movie').get('category1_name').get('ko')!='':
      KSTEvcJlDfhYAUmQgRzasoterVnXqC.append(KSTEvcJlDfhYAUmQgRzasoterVnXwG['movie']['category1_name']['ko'])
     if KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('movie').get('category2_name').get('ko')!='':
      KSTEvcJlDfhYAUmQgRzasoterVnXqC.append(KSTEvcJlDfhYAUmQgRzasoterVnXwG['movie']['category2_name']['ko'])
     if 'duration' in KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('movie'):KSTEvcJlDfhYAUmQgRzasoterVnXLC=KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('movie').get('duration')
     if 'release_date' in KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('movie'):
      KSTEvcJlDfhYAUmQgRzasoterVnXqM=KSTEvcJlDfhYAUmQgRzasoterVnXWG(KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('movie').get('release_date'))
      if KSTEvcJlDfhYAUmQgRzasoterVnXqM!='0':KSTEvcJlDfhYAUmQgRzasoterVnXqL='%s-%s-%s'%(KSTEvcJlDfhYAUmQgRzasoterVnXqM[:4],KSTEvcJlDfhYAUmQgRzasoterVnXqM[4:6],KSTEvcJlDfhYAUmQgRzasoterVnXqM[6:])
     if 'production' in KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('movie'):KSTEvcJlDfhYAUmQgRzasoterVnXqG=KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('movie').get('production')
    except:
     KSTEvcJlDfhYAUmQgRzasoterVnXWH
    KSTEvcJlDfhYAUmQgRzasoterVnXqN={'moviecode':KSTEvcJlDfhYAUmQgRzasoterVnXqB,'title':KSTEvcJlDfhYAUmQgRzasoterVnXdk,'thumbnail':{'poster':KSTEvcJlDfhYAUmQgRzasoterVnXdP,'thumb':KSTEvcJlDfhYAUmQgRzasoterVnXdH,'clearlogo':KSTEvcJlDfhYAUmQgRzasoterVnXdy,'fanart':KSTEvcJlDfhYAUmQgRzasoterVnXdH},'synopsis':KSTEvcJlDfhYAUmQgRzasoterVnXdF,'info_title':KSTEvcJlDfhYAUmQgRzasoterVnXqu,'year':KSTEvcJlDfhYAUmQgRzasoterVnXqw,'cast':KSTEvcJlDfhYAUmQgRzasoterVnXdG,'director':KSTEvcJlDfhYAUmQgRzasoterVnXdB,'info_genre':KSTEvcJlDfhYAUmQgRzasoterVnXqC,'duration':KSTEvcJlDfhYAUmQgRzasoterVnXLC,'premiered':KSTEvcJlDfhYAUmQgRzasoterVnXqL,'studio':KSTEvcJlDfhYAUmQgRzasoterVnXqG,'mpaa':KSTEvcJlDfhYAUmQgRzasoterVnXqd}
    KSTEvcJlDfhYAUmQgRzasoterVnXLw=KSTEvcJlDfhYAUmQgRzasoterVnXWP
    for KSTEvcJlDfhYAUmQgRzasoterVnXLd in KSTEvcJlDfhYAUmQgRzasoterVnXwG['billing_package_id']:
     if KSTEvcJlDfhYAUmQgRzasoterVnXLd in KSTEvcJlDfhYAUmQgRzasoterVnXCL.MOVIE_LITE:
      KSTEvcJlDfhYAUmQgRzasoterVnXLw=KSTEvcJlDfhYAUmQgRzasoterVnXWu
      break
    if KSTEvcJlDfhYAUmQgRzasoterVnXLw==KSTEvcJlDfhYAUmQgRzasoterVnXWP: 
     KSTEvcJlDfhYAUmQgRzasoterVnXqN['title']=KSTEvcJlDfhYAUmQgRzasoterVnXqN['title']+' [개별구매]'
    KSTEvcJlDfhYAUmQgRzasoterVnXdL.append(KSTEvcJlDfhYAUmQgRzasoterVnXqN)
   if KSTEvcJlDfhYAUmQgRzasoterVnXwP['body']['has_more']=='Y':KSTEvcJlDfhYAUmQgRzasoterVnXdW=KSTEvcJlDfhYAUmQgRzasoterVnXWu
  except KSTEvcJlDfhYAUmQgRzasoterVnXWb as exception:
   KSTEvcJlDfhYAUmQgRzasoterVnXWj(exception)
  return KSTEvcJlDfhYAUmQgRzasoterVnXdL,KSTEvcJlDfhYAUmQgRzasoterVnXdW
 def GetMovieListGenre(KSTEvcJlDfhYAUmQgRzasoterVnXCL,genre,page_int):
  KSTEvcJlDfhYAUmQgRzasoterVnXdL=[]
  KSTEvcJlDfhYAUmQgRzasoterVnXdW=KSTEvcJlDfhYAUmQgRzasoterVnXWP
  try:
   KSTEvcJlDfhYAUmQgRzasoterVnXwO ='/v2/media/movie/curation/'+genre
   KSTEvcJlDfhYAUmQgRzasoterVnXwk=KSTEvcJlDfhYAUmQgRzasoterVnXCL.GetDefaultParams()
   KSTEvcJlDfhYAUmQgRzasoterVnXwF={'pageNo':KSTEvcJlDfhYAUmQgRzasoterVnXWG(page_int),'pageSize':KSTEvcJlDfhYAUmQgRzasoterVnXWG(KSTEvcJlDfhYAUmQgRzasoterVnXCL.MOVIE_LIMIT),'_':KSTEvcJlDfhYAUmQgRzasoterVnXWG(KSTEvcJlDfhYAUmQgRzasoterVnXCL.GetNoCache(2))}
   KSTEvcJlDfhYAUmQgRzasoterVnXwk.update(KSTEvcJlDfhYAUmQgRzasoterVnXwF)
   KSTEvcJlDfhYAUmQgRzasoterVnXwH=KSTEvcJlDfhYAUmQgRzasoterVnXCL.API_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXwO
   KSTEvcJlDfhYAUmQgRzasoterVnXCG=KSTEvcJlDfhYAUmQgRzasoterVnXCL.callRequestCookies('Get',KSTEvcJlDfhYAUmQgRzasoterVnXwH,payload=KSTEvcJlDfhYAUmQgRzasoterVnXWH,params=KSTEvcJlDfhYAUmQgRzasoterVnXwk,headers=KSTEvcJlDfhYAUmQgRzasoterVnXWH,cookies=KSTEvcJlDfhYAUmQgRzasoterVnXWH)
   KSTEvcJlDfhYAUmQgRzasoterVnXwP=json.loads(KSTEvcJlDfhYAUmQgRzasoterVnXCG.text)
   if not('movies' in KSTEvcJlDfhYAUmQgRzasoterVnXwP['body']):return KSTEvcJlDfhYAUmQgRzasoterVnXdL,KSTEvcJlDfhYAUmQgRzasoterVnXdW
   KSTEvcJlDfhYAUmQgRzasoterVnXdi=KSTEvcJlDfhYAUmQgRzasoterVnXwP['body']['movies']
   for KSTEvcJlDfhYAUmQgRzasoterVnXwG in KSTEvcJlDfhYAUmQgRzasoterVnXdi:
    KSTEvcJlDfhYAUmQgRzasoterVnXqB =KSTEvcJlDfhYAUmQgRzasoterVnXwG['code']
    KSTEvcJlDfhYAUmQgRzasoterVnXdk =KSTEvcJlDfhYAUmQgRzasoterVnXwG['name']['ko']
    KSTEvcJlDfhYAUmQgRzasoterVnXLq =KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXwG['image'][0]['url']
    for KSTEvcJlDfhYAUmQgRzasoterVnXdb in KSTEvcJlDfhYAUmQgRzasoterVnXwG['image']:
     if KSTEvcJlDfhYAUmQgRzasoterVnXdb['code']=='CAIM2100':
      KSTEvcJlDfhYAUmQgRzasoterVnXLq =KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXdb['url']
    KSTEvcJlDfhYAUmQgRzasoterVnXdF =KSTEvcJlDfhYAUmQgRzasoterVnXwG['story']['ko']
    KSTEvcJlDfhYAUmQgRzasoterVnXqN={'moviecode':KSTEvcJlDfhYAUmQgRzasoterVnXqB,'title':KSTEvcJlDfhYAUmQgRzasoterVnXdk.strip(),'thumbnail':KSTEvcJlDfhYAUmQgRzasoterVnXLq,'synopsis':KSTEvcJlDfhYAUmQgRzasoterVnXdF}
    KSTEvcJlDfhYAUmQgRzasoterVnXdL.append(KSTEvcJlDfhYAUmQgRzasoterVnXqN)
  except KSTEvcJlDfhYAUmQgRzasoterVnXWb as exception:
   KSTEvcJlDfhYAUmQgRzasoterVnXWj(exception)
  return KSTEvcJlDfhYAUmQgRzasoterVnXdL,KSTEvcJlDfhYAUmQgRzasoterVnXdW
 def GetMovieGenre(KSTEvcJlDfhYAUmQgRzasoterVnXCL):
  KSTEvcJlDfhYAUmQgRzasoterVnXdL=[]
  KSTEvcJlDfhYAUmQgRzasoterVnXdW=KSTEvcJlDfhYAUmQgRzasoterVnXWP
  try:
   KSTEvcJlDfhYAUmQgRzasoterVnXwO ='/v2/media/movie/curations'
   KSTEvcJlDfhYAUmQgRzasoterVnXwk=KSTEvcJlDfhYAUmQgRzasoterVnXCL.GetDefaultParams()
   KSTEvcJlDfhYAUmQgRzasoterVnXwF={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code','_':KSTEvcJlDfhYAUmQgRzasoterVnXWG(KSTEvcJlDfhYAUmQgRzasoterVnXCL.GetNoCache(2))}
   KSTEvcJlDfhYAUmQgRzasoterVnXwk.update(KSTEvcJlDfhYAUmQgRzasoterVnXwF)
   KSTEvcJlDfhYAUmQgRzasoterVnXwH=KSTEvcJlDfhYAUmQgRzasoterVnXCL.API_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXwO
   KSTEvcJlDfhYAUmQgRzasoterVnXCG=KSTEvcJlDfhYAUmQgRzasoterVnXCL.callRequestCookies('Get',KSTEvcJlDfhYAUmQgRzasoterVnXwH,payload=KSTEvcJlDfhYAUmQgRzasoterVnXWH,params=KSTEvcJlDfhYAUmQgRzasoterVnXwk,headers=KSTEvcJlDfhYAUmQgRzasoterVnXWH,cookies=KSTEvcJlDfhYAUmQgRzasoterVnXWH)
   KSTEvcJlDfhYAUmQgRzasoterVnXwP=json.loads(KSTEvcJlDfhYAUmQgRzasoterVnXCG.text)
   if not('result' in KSTEvcJlDfhYAUmQgRzasoterVnXwP['body']):return KSTEvcJlDfhYAUmQgRzasoterVnXdL,KSTEvcJlDfhYAUmQgRzasoterVnXdW
   KSTEvcJlDfhYAUmQgRzasoterVnXdi=KSTEvcJlDfhYAUmQgRzasoterVnXwP['body']['result']
   for KSTEvcJlDfhYAUmQgRzasoterVnXwG in KSTEvcJlDfhYAUmQgRzasoterVnXdi:
    KSTEvcJlDfhYAUmQgRzasoterVnXLW =KSTEvcJlDfhYAUmQgRzasoterVnXwG['curation_code']
    KSTEvcJlDfhYAUmQgRzasoterVnXLp =KSTEvcJlDfhYAUmQgRzasoterVnXwG['curation_name']
    KSTEvcJlDfhYAUmQgRzasoterVnXqN={'curation_code':KSTEvcJlDfhYAUmQgRzasoterVnXLW,'curation_name':KSTEvcJlDfhYAUmQgRzasoterVnXLp}
    KSTEvcJlDfhYAUmQgRzasoterVnXdL.append(KSTEvcJlDfhYAUmQgRzasoterVnXqN)
  except KSTEvcJlDfhYAUmQgRzasoterVnXWb as exception:
   KSTEvcJlDfhYAUmQgRzasoterVnXWj(exception)
  return KSTEvcJlDfhYAUmQgRzasoterVnXdL,KSTEvcJlDfhYAUmQgRzasoterVnXdW
 def GetSearchList(KSTEvcJlDfhYAUmQgRzasoterVnXCL,search_key,page_int,stype):
  KSTEvcJlDfhYAUmQgRzasoterVnXLM=[]
  KSTEvcJlDfhYAUmQgRzasoterVnXdW=KSTEvcJlDfhYAUmQgRzasoterVnXWP
  try:
   KSTEvcJlDfhYAUmQgRzasoterVnXwO ='/search/getSearch.jsp'
   KSTEvcJlDfhYAUmQgRzasoterVnXwF={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':KSTEvcJlDfhYAUmQgRzasoterVnXWG(page_int),'pageSize':KSTEvcJlDfhYAUmQgRzasoterVnXWG(KSTEvcJlDfhYAUmQgRzasoterVnXCL.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':KSTEvcJlDfhYAUmQgRzasoterVnXCL.SCREENCODE,'os':KSTEvcJlDfhYAUmQgRzasoterVnXCL.OSCODE,'network':KSTEvcJlDfhYAUmQgRzasoterVnXCL.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':KSTEvcJlDfhYAUmQgRzasoterVnXWG(KSTEvcJlDfhYAUmQgRzasoterVnXCL.SEARCH_LIMIT)if stype=='vod' else '','vodMVReqCnt':KSTEvcJlDfhYAUmQgRzasoterVnXWG(KSTEvcJlDfhYAUmQgRzasoterVnXCL.SEARCH_LIMIT)if stype=='movie' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':KSTEvcJlDfhYAUmQgRzasoterVnXWG(KSTEvcJlDfhYAUmQgRzasoterVnXCL.GetNoCache(2))}
   KSTEvcJlDfhYAUmQgRzasoterVnXwH=KSTEvcJlDfhYAUmQgRzasoterVnXCL.SEARCH_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXwO
   KSTEvcJlDfhYAUmQgRzasoterVnXCG=KSTEvcJlDfhYAUmQgRzasoterVnXCL.callRequestCookies('Get',KSTEvcJlDfhYAUmQgRzasoterVnXwH,payload=KSTEvcJlDfhYAUmQgRzasoterVnXWH,params=KSTEvcJlDfhYAUmQgRzasoterVnXwF,headers=KSTEvcJlDfhYAUmQgRzasoterVnXWH,cookies=KSTEvcJlDfhYAUmQgRzasoterVnXWH)
   KSTEvcJlDfhYAUmQgRzasoterVnXwP=json.loads(KSTEvcJlDfhYAUmQgRzasoterVnXCG.text)
   if stype=='vod':
    if not('programRsb' in KSTEvcJlDfhYAUmQgRzasoterVnXwP):return KSTEvcJlDfhYAUmQgRzasoterVnXLM,KSTEvcJlDfhYAUmQgRzasoterVnXdW
    KSTEvcJlDfhYAUmQgRzasoterVnXLi=KSTEvcJlDfhYAUmQgRzasoterVnXwP['programRsb']['dataList']
    KSTEvcJlDfhYAUmQgRzasoterVnXLN =KSTEvcJlDfhYAUmQgRzasoterVnXWy(KSTEvcJlDfhYAUmQgRzasoterVnXwP['programRsb']['count'])
    for KSTEvcJlDfhYAUmQgRzasoterVnXwG in KSTEvcJlDfhYAUmQgRzasoterVnXLi:
     KSTEvcJlDfhYAUmQgRzasoterVnXqx=KSTEvcJlDfhYAUmQgRzasoterVnXwG['mast_cd']
     KSTEvcJlDfhYAUmQgRzasoterVnXdk =KSTEvcJlDfhYAUmQgRzasoterVnXwG['mast_nm']
     KSTEvcJlDfhYAUmQgRzasoterVnXdP=KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXwG['web_url4']
     KSTEvcJlDfhYAUmQgRzasoterVnXdH =KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXwG['web_url']
     try:
      KSTEvcJlDfhYAUmQgRzasoterVnXdG =[]
      KSTEvcJlDfhYAUmQgRzasoterVnXdB=[]
      KSTEvcJlDfhYAUmQgRzasoterVnXqC =[]
      KSTEvcJlDfhYAUmQgRzasoterVnXLC =0
      KSTEvcJlDfhYAUmQgRzasoterVnXqd =''
      KSTEvcJlDfhYAUmQgRzasoterVnXqw =''
      KSTEvcJlDfhYAUmQgRzasoterVnXqb =''
      if KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('actor') !='' and KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('actor') !='-':KSTEvcJlDfhYAUmQgRzasoterVnXdG =KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('actor').split(',')
      if KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('director')!='' and KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('director')!='-':KSTEvcJlDfhYAUmQgRzasoterVnXdB=KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('director').split(',')
      if KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('cate_nm')!='' and KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('cate_nm')!='-':KSTEvcJlDfhYAUmQgRzasoterVnXqC =KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('cate_nm').split('/')
      if 'targetage' in KSTEvcJlDfhYAUmQgRzasoterVnXwG:KSTEvcJlDfhYAUmQgRzasoterVnXqd=KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('targetage')
      if 'broad_dt' in KSTEvcJlDfhYAUmQgRzasoterVnXwG:
       KSTEvcJlDfhYAUmQgRzasoterVnXqM=KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('broad_dt')
       KSTEvcJlDfhYAUmQgRzasoterVnXqb='%s-%s-%s'%(KSTEvcJlDfhYAUmQgRzasoterVnXqM[:4],KSTEvcJlDfhYAUmQgRzasoterVnXqM[4:6],KSTEvcJlDfhYAUmQgRzasoterVnXqM[6:])
       KSTEvcJlDfhYAUmQgRzasoterVnXqw =KSTEvcJlDfhYAUmQgRzasoterVnXqM[:4]
     except:
      KSTEvcJlDfhYAUmQgRzasoterVnXWH
     KSTEvcJlDfhYAUmQgRzasoterVnXqN={'program':KSTEvcJlDfhYAUmQgRzasoterVnXqx,'title':KSTEvcJlDfhYAUmQgRzasoterVnXdk,'thumbnail':{'poster':KSTEvcJlDfhYAUmQgRzasoterVnXdP,'thumb':KSTEvcJlDfhYAUmQgRzasoterVnXdH,'fanart':KSTEvcJlDfhYAUmQgRzasoterVnXdH},'synopsis':'','cast':KSTEvcJlDfhYAUmQgRzasoterVnXdG,'director':KSTEvcJlDfhYAUmQgRzasoterVnXdB,'info_genre':KSTEvcJlDfhYAUmQgRzasoterVnXqC,'duration':KSTEvcJlDfhYAUmQgRzasoterVnXLC,'mpaa':KSTEvcJlDfhYAUmQgRzasoterVnXqd,'year':KSTEvcJlDfhYAUmQgRzasoterVnXqw,'aired':KSTEvcJlDfhYAUmQgRzasoterVnXqb}
     KSTEvcJlDfhYAUmQgRzasoterVnXLM.append(KSTEvcJlDfhYAUmQgRzasoterVnXqN)
   else:
    if not('vodMVRsb' in KSTEvcJlDfhYAUmQgRzasoterVnXwP):return KSTEvcJlDfhYAUmQgRzasoterVnXLM,KSTEvcJlDfhYAUmQgRzasoterVnXdW
    KSTEvcJlDfhYAUmQgRzasoterVnXLx=KSTEvcJlDfhYAUmQgRzasoterVnXwP['vodMVRsb']['dataList']
    KSTEvcJlDfhYAUmQgRzasoterVnXLN =KSTEvcJlDfhYAUmQgRzasoterVnXWy(KSTEvcJlDfhYAUmQgRzasoterVnXwP['vodMVRsb']['count'])
    for KSTEvcJlDfhYAUmQgRzasoterVnXwG in KSTEvcJlDfhYAUmQgRzasoterVnXLx:
     KSTEvcJlDfhYAUmQgRzasoterVnXqx=KSTEvcJlDfhYAUmQgRzasoterVnXwG['mast_cd']
     KSTEvcJlDfhYAUmQgRzasoterVnXdk =KSTEvcJlDfhYAUmQgRzasoterVnXwG['mast_nm'].strip()
     KSTEvcJlDfhYAUmQgRzasoterVnXdP =KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXwG['web_url']
     KSTEvcJlDfhYAUmQgRzasoterVnXdH =KSTEvcJlDfhYAUmQgRzasoterVnXdP
     KSTEvcJlDfhYAUmQgRzasoterVnXdy=''
     try:
      KSTEvcJlDfhYAUmQgRzasoterVnXdG =[]
      KSTEvcJlDfhYAUmQgRzasoterVnXdB=[]
      KSTEvcJlDfhYAUmQgRzasoterVnXqC =[]
      KSTEvcJlDfhYAUmQgRzasoterVnXLC =0
      KSTEvcJlDfhYAUmQgRzasoterVnXqd =''
      KSTEvcJlDfhYAUmQgRzasoterVnXqw =''
      KSTEvcJlDfhYAUmQgRzasoterVnXqb =''
      if KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('actor') !='' and KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('actor') !='-':KSTEvcJlDfhYAUmQgRzasoterVnXdG =KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('actor').split(',')
      if KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('director')!='' and KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('director')!='-':KSTEvcJlDfhYAUmQgRzasoterVnXdB=KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('director').split(',')
      if KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('cate_nm')!='' and KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('cate_nm')!='-':KSTEvcJlDfhYAUmQgRzasoterVnXqC =KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('cate_nm').split('/')
      if KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('runtime_sec')!='':KSTEvcJlDfhYAUmQgRzasoterVnXLC=KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('runtime_sec')
      if 'grade_nm' in KSTEvcJlDfhYAUmQgRzasoterVnXwG:KSTEvcJlDfhYAUmQgRzasoterVnXqd=KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('grade_nm')
      KSTEvcJlDfhYAUmQgRzasoterVnXqM=KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('broad_dt')
      if data_str!='':
       KSTEvcJlDfhYAUmQgRzasoterVnXqb='%s-%s-%s'%(KSTEvcJlDfhYAUmQgRzasoterVnXqM[:4],KSTEvcJlDfhYAUmQgRzasoterVnXqM[4:6],KSTEvcJlDfhYAUmQgRzasoterVnXqM[6:])
       KSTEvcJlDfhYAUmQgRzasoterVnXqw =KSTEvcJlDfhYAUmQgRzasoterVnXqM[:4]
     except:
      KSTEvcJlDfhYAUmQgRzasoterVnXWH
     KSTEvcJlDfhYAUmQgRzasoterVnXqN={'movie':KSTEvcJlDfhYAUmQgRzasoterVnXqx,'title':KSTEvcJlDfhYAUmQgRzasoterVnXdk,'thumbnail':{'poster':KSTEvcJlDfhYAUmQgRzasoterVnXdP,'thumb':KSTEvcJlDfhYAUmQgRzasoterVnXdH,'fanart':KSTEvcJlDfhYAUmQgRzasoterVnXdH,'clearlogo':KSTEvcJlDfhYAUmQgRzasoterVnXdy},'synopsis':'','cast':KSTEvcJlDfhYAUmQgRzasoterVnXdG,'director':KSTEvcJlDfhYAUmQgRzasoterVnXdB,'info_genre':KSTEvcJlDfhYAUmQgRzasoterVnXqC,'duration':KSTEvcJlDfhYAUmQgRzasoterVnXLC,'mpaa':KSTEvcJlDfhYAUmQgRzasoterVnXqd,'year':KSTEvcJlDfhYAUmQgRzasoterVnXqw,'aired':KSTEvcJlDfhYAUmQgRzasoterVnXqb}
     KSTEvcJlDfhYAUmQgRzasoterVnXLw=KSTEvcJlDfhYAUmQgRzasoterVnXWP
     for KSTEvcJlDfhYAUmQgRzasoterVnXLd in KSTEvcJlDfhYAUmQgRzasoterVnXwG['bill']:
      if KSTEvcJlDfhYAUmQgRzasoterVnXLd in KSTEvcJlDfhYAUmQgRzasoterVnXCL.MOVIE_LITE:
       KSTEvcJlDfhYAUmQgRzasoterVnXLw=KSTEvcJlDfhYAUmQgRzasoterVnXWu
       break
     if KSTEvcJlDfhYAUmQgRzasoterVnXLw==KSTEvcJlDfhYAUmQgRzasoterVnXWP: 
      KSTEvcJlDfhYAUmQgRzasoterVnXqN['title']=KSTEvcJlDfhYAUmQgRzasoterVnXqN['title']+' [개별구매]'
     KSTEvcJlDfhYAUmQgRzasoterVnXLM.append(KSTEvcJlDfhYAUmQgRzasoterVnXqN)
   if KSTEvcJlDfhYAUmQgRzasoterVnXLN>(page_int*KSTEvcJlDfhYAUmQgRzasoterVnXCL.SEARCH_LIMIT):KSTEvcJlDfhYAUmQgRzasoterVnXdW=KSTEvcJlDfhYAUmQgRzasoterVnXWu
  except KSTEvcJlDfhYAUmQgRzasoterVnXWb as exception:
   KSTEvcJlDfhYAUmQgRzasoterVnXWj(exception)
  return KSTEvcJlDfhYAUmQgRzasoterVnXLM,KSTEvcJlDfhYAUmQgRzasoterVnXdW
 def GetDeviceList(KSTEvcJlDfhYAUmQgRzasoterVnXCL,KSTEvcJlDfhYAUmQgRzasoterVnXwC,KSTEvcJlDfhYAUmQgRzasoterVnXwd):
  KSTEvcJlDfhYAUmQgRzasoterVnXdL=[]
  KSTEvcJlDfhYAUmQgRzasoterVnXwi='-'
  try:
   KSTEvcJlDfhYAUmQgRzasoterVnXwO ='/v1/user/device/list'
   KSTEvcJlDfhYAUmQgRzasoterVnXLO=KSTEvcJlDfhYAUmQgRzasoterVnXCL.API_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXwO
   KSTEvcJlDfhYAUmQgRzasoterVnXwF={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   KSTEvcJlDfhYAUmQgRzasoterVnXCM=KSTEvcJlDfhYAUmQgRzasoterVnXCL.makeDefaultCookies(vToken=KSTEvcJlDfhYAUmQgRzasoterVnXwC,vUserinfo=KSTEvcJlDfhYAUmQgRzasoterVnXwd)
   KSTEvcJlDfhYAUmQgRzasoterVnXCG=KSTEvcJlDfhYAUmQgRzasoterVnXCL.callRequestCookies('Get',KSTEvcJlDfhYAUmQgRzasoterVnXLO,payload=KSTEvcJlDfhYAUmQgRzasoterVnXWH,params=KSTEvcJlDfhYAUmQgRzasoterVnXwF,headers=KSTEvcJlDfhYAUmQgRzasoterVnXWH,cookies=KSTEvcJlDfhYAUmQgRzasoterVnXCM)
   KSTEvcJlDfhYAUmQgRzasoterVnXwP=json.loads(KSTEvcJlDfhYAUmQgRzasoterVnXCG.text)
   KSTEvcJlDfhYAUmQgRzasoterVnXWj(KSTEvcJlDfhYAUmQgRzasoterVnXwP)
   KSTEvcJlDfhYAUmQgRzasoterVnXdL=KSTEvcJlDfhYAUmQgRzasoterVnXwP['body']
   for KSTEvcJlDfhYAUmQgRzasoterVnXwG in KSTEvcJlDfhYAUmQgRzasoterVnXdL:
    if KSTEvcJlDfhYAUmQgRzasoterVnXwG['model']=='PC' or KSTEvcJlDfhYAUmQgRzasoterVnXwG['model']=='PC-Chrome':
     KSTEvcJlDfhYAUmQgRzasoterVnXwi=KSTEvcJlDfhYAUmQgRzasoterVnXwG['uuid']
  except KSTEvcJlDfhYAUmQgRzasoterVnXWb as exception:
   KSTEvcJlDfhYAUmQgRzasoterVnXWj(exception)
  return KSTEvcJlDfhYAUmQgRzasoterVnXwi
 def GetProfileToken(KSTEvcJlDfhYAUmQgRzasoterVnXCL,KSTEvcJlDfhYAUmQgRzasoterVnXwC,KSTEvcJlDfhYAUmQgRzasoterVnXwd,user_pf):
  KSTEvcJlDfhYAUmQgRzasoterVnXLk=[]
  KSTEvcJlDfhYAUmQgRzasoterVnXLF =''
  KSTEvcJlDfhYAUmQgRzasoterVnXLH =''
  KSTEvcJlDfhYAUmQgRzasoterVnXLP='Y'
  KSTEvcJlDfhYAUmQgRzasoterVnXLy ='N'
  try:
   KSTEvcJlDfhYAUmQgRzasoterVnXwO ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com'
   KSTEvcJlDfhYAUmQgRzasoterVnXCM=KSTEvcJlDfhYAUmQgRzasoterVnXCL.makeDefaultCookies(vToken=KSTEvcJlDfhYAUmQgRzasoterVnXwC,vUserinfo=KSTEvcJlDfhYAUmQgRzasoterVnXwd)
   KSTEvcJlDfhYAUmQgRzasoterVnXCG=KSTEvcJlDfhYAUmQgRzasoterVnXCL.callRequestCookies('Get',KSTEvcJlDfhYAUmQgRzasoterVnXwO,payload=KSTEvcJlDfhYAUmQgRzasoterVnXWH,params=KSTEvcJlDfhYAUmQgRzasoterVnXWH,headers=KSTEvcJlDfhYAUmQgRzasoterVnXWH,cookies=KSTEvcJlDfhYAUmQgRzasoterVnXCM)
   KSTEvcJlDfhYAUmQgRzasoterVnXLk =re.findall('data-profile-no="\d+"',KSTEvcJlDfhYAUmQgRzasoterVnXCG.text)
   for i in KSTEvcJlDfhYAUmQgRzasoterVnXWI(KSTEvcJlDfhYAUmQgRzasoterVnXpC(KSTEvcJlDfhYAUmQgRzasoterVnXLk)):
    KSTEvcJlDfhYAUmQgRzasoterVnXLI =KSTEvcJlDfhYAUmQgRzasoterVnXLk[i].replace('data-profile-no=','').replace('"','')
    KSTEvcJlDfhYAUmQgRzasoterVnXLk[i]=KSTEvcJlDfhYAUmQgRzasoterVnXLI
   KSTEvcJlDfhYAUmQgRzasoterVnXLF=KSTEvcJlDfhYAUmQgRzasoterVnXLk[user_pf]
  except KSTEvcJlDfhYAUmQgRzasoterVnXWb as exception:
   KSTEvcJlDfhYAUmQgRzasoterVnXWj(exception)
   return KSTEvcJlDfhYAUmQgRzasoterVnXLH,KSTEvcJlDfhYAUmQgRzasoterVnXLP,KSTEvcJlDfhYAUmQgRzasoterVnXLy
  try:
   KSTEvcJlDfhYAUmQgRzasoterVnXwO ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   KSTEvcJlDfhYAUmQgRzasoterVnXCM=KSTEvcJlDfhYAUmQgRzasoterVnXCL.makeDefaultCookies(vToken=KSTEvcJlDfhYAUmQgRzasoterVnXwC,vUserinfo=KSTEvcJlDfhYAUmQgRzasoterVnXwd)
   KSTEvcJlDfhYAUmQgRzasoterVnXCb={'profileNo':KSTEvcJlDfhYAUmQgRzasoterVnXLF}
   KSTEvcJlDfhYAUmQgRzasoterVnXCG=KSTEvcJlDfhYAUmQgRzasoterVnXCL.callRequestCookies('Post',KSTEvcJlDfhYAUmQgRzasoterVnXwO,payload=KSTEvcJlDfhYAUmQgRzasoterVnXCb,params=KSTEvcJlDfhYAUmQgRzasoterVnXWH,headers=KSTEvcJlDfhYAUmQgRzasoterVnXWH,cookies=KSTEvcJlDfhYAUmQgRzasoterVnXCM)
   for KSTEvcJlDfhYAUmQgRzasoterVnXCB in KSTEvcJlDfhYAUmQgRzasoterVnXCG.cookies:
    if KSTEvcJlDfhYAUmQgRzasoterVnXCB.name=='_tving_token':
     KSTEvcJlDfhYAUmQgRzasoterVnXLH=KSTEvcJlDfhYAUmQgRzasoterVnXCB.value
    elif KSTEvcJlDfhYAUmQgRzasoterVnXCB.name==KSTEvcJlDfhYAUmQgRzasoterVnXCL.GLOBAL_COOKIENM['tv_cookiekey']:
     KSTEvcJlDfhYAUmQgRzasoterVnXLP=KSTEvcJlDfhYAUmQgRzasoterVnXCB.value
    elif KSTEvcJlDfhYAUmQgRzasoterVnXCB.name==KSTEvcJlDfhYAUmQgRzasoterVnXCL.GLOBAL_COOKIENM['tv_lockkey']:
     KSTEvcJlDfhYAUmQgRzasoterVnXLy=KSTEvcJlDfhYAUmQgRzasoterVnXCB.value
  except KSTEvcJlDfhYAUmQgRzasoterVnXWb as exception:
   KSTEvcJlDfhYAUmQgRzasoterVnXWj(exception)
  return KSTEvcJlDfhYAUmQgRzasoterVnXLH,KSTEvcJlDfhYAUmQgRzasoterVnXLP,KSTEvcJlDfhYAUmQgRzasoterVnXLy
 def GetProfileLockYN(KSTEvcJlDfhYAUmQgRzasoterVnXCL,KSTEvcJlDfhYAUmQgRzasoterVnXwC,KSTEvcJlDfhYAUmQgRzasoterVnXwd):
  KSTEvcJlDfhYAUmQgRzasoterVnXLk=[]
  KSTEvcJlDfhYAUmQgRzasoterVnXLy ='N'
  try:
   KSTEvcJlDfhYAUmQgRzasoterVnXwO ='/profile/select.do'
   KSTEvcJlDfhYAUmQgRzasoterVnXLO=KSTEvcJlDfhYAUmQgRzasoterVnXCL.URL_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXwO
   KSTEvcJlDfhYAUmQgRzasoterVnXCM=KSTEvcJlDfhYAUmQgRzasoterVnXCL.makeDefaultCookies(vToken=KSTEvcJlDfhYAUmQgRzasoterVnXwC,vUserinfo=KSTEvcJlDfhYAUmQgRzasoterVnXwd)
   KSTEvcJlDfhYAUmQgRzasoterVnXCG=KSTEvcJlDfhYAUmQgRzasoterVnXCL.callRequestCookies('Get',KSTEvcJlDfhYAUmQgRzasoterVnXLO,payload=KSTEvcJlDfhYAUmQgRzasoterVnXWH,params=KSTEvcJlDfhYAUmQgRzasoterVnXWH,headers=KSTEvcJlDfhYAUmQgRzasoterVnXWH,cookies=KSTEvcJlDfhYAUmQgRzasoterVnXCM)
   KSTEvcJlDfhYAUmQgRzasoterVnXLk =re.findall('data-profile-no="\d+"',KSTEvcJlDfhYAUmQgRzasoterVnXCG.text)
   for i in KSTEvcJlDfhYAUmQgRzasoterVnXWI(KSTEvcJlDfhYAUmQgRzasoterVnXpC(KSTEvcJlDfhYAUmQgRzasoterVnXLk)):
    KSTEvcJlDfhYAUmQgRzasoterVnXLI =KSTEvcJlDfhYAUmQgRzasoterVnXLk[i].replace('data-profile-no=','').replace('"','')
    KSTEvcJlDfhYAUmQgRzasoterVnXLk[i]=KSTEvcJlDfhYAUmQgRzasoterVnXLI
  except KSTEvcJlDfhYAUmQgRzasoterVnXWb as exception:
   KSTEvcJlDfhYAUmQgRzasoterVnXWj(exception)
   return KSTEvcJlDfhYAUmQgRzasoterVnXLy
  try:
   KSTEvcJlDfhYAUmQgRzasoterVnXwO ='/profile/api/select.do'
   KSTEvcJlDfhYAUmQgRzasoterVnXLO=KSTEvcJlDfhYAUmQgRzasoterVnXCL.URL_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXwO
   KSTEvcJlDfhYAUmQgRzasoterVnXCM=KSTEvcJlDfhYAUmQgRzasoterVnXCL.makeDefaultCookies(vToken=KSTEvcJlDfhYAUmQgRzasoterVnXwC,vUserinfo=KSTEvcJlDfhYAUmQgRzasoterVnXwd)
   for i in KSTEvcJlDfhYAUmQgRzasoterVnXWI(KSTEvcJlDfhYAUmQgRzasoterVnXpC(KSTEvcJlDfhYAUmQgRzasoterVnXLk)):
    KSTEvcJlDfhYAUmQgRzasoterVnXCb={'profileNo':KSTEvcJlDfhYAUmQgRzasoterVnXLk[i]}
    KSTEvcJlDfhYAUmQgRzasoterVnXCG=KSTEvcJlDfhYAUmQgRzasoterVnXCL.callRequestCookies('Post',KSTEvcJlDfhYAUmQgRzasoterVnXLO,payload=KSTEvcJlDfhYAUmQgRzasoterVnXCb,params=KSTEvcJlDfhYAUmQgRzasoterVnXWH,headers=KSTEvcJlDfhYAUmQgRzasoterVnXWH,cookies=KSTEvcJlDfhYAUmQgRzasoterVnXCM)
    for KSTEvcJlDfhYAUmQgRzasoterVnXCB in KSTEvcJlDfhYAUmQgRzasoterVnXCG.cookies:
     if KSTEvcJlDfhYAUmQgRzasoterVnXCB.name=='_tving_token':
      KSTEvcJlDfhYAUmQgRzasoterVnXLu=KSTEvcJlDfhYAUmQgRzasoterVnXCB.value
     elif KSTEvcJlDfhYAUmQgRzasoterVnXCB.name==KSTEvcJlDfhYAUmQgRzasoterVnXCL.GLOBAL_COOKIENM['tv_lockkey']:
      KSTEvcJlDfhYAUmQgRzasoterVnXLj=KSTEvcJlDfhYAUmQgRzasoterVnXCB.value
    if KSTEvcJlDfhYAUmQgRzasoterVnXLu==KSTEvcJlDfhYAUmQgRzasoterVnXwC:
     KSTEvcJlDfhYAUmQgRzasoterVnXLy=KSTEvcJlDfhYAUmQgRzasoterVnXLj
     KSTEvcJlDfhYAUmQgRzasoterVnXWj(KSTEvcJlDfhYAUmQgRzasoterVnXwC)
     break
  except KSTEvcJlDfhYAUmQgRzasoterVnXWb as exception:
   KSTEvcJlDfhYAUmQgRzasoterVnXWj(exception)
  return KSTEvcJlDfhYAUmQgRzasoterVnXLy
 def GetBookmarkInfo(KSTEvcJlDfhYAUmQgRzasoterVnXCL,videoid,vidtype):
  KSTEvcJlDfhYAUmQgRzasoterVnXLb={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   KSTEvcJlDfhYAUmQgRzasoterVnXwH=KSTEvcJlDfhYAUmQgRzasoterVnXCL.API_DOMAIN+'/v2/media/program/'+videoid
   KSTEvcJlDfhYAUmQgRzasoterVnXwk=KSTEvcJlDfhYAUmQgRzasoterVnXCL.GetDefaultParams()
   KSTEvcJlDfhYAUmQgRzasoterVnXwF={'pageNo':'1','pageSize':'10','order':'name',}
   KSTEvcJlDfhYAUmQgRzasoterVnXwk.update(KSTEvcJlDfhYAUmQgRzasoterVnXwF)
   KSTEvcJlDfhYAUmQgRzasoterVnXCG=KSTEvcJlDfhYAUmQgRzasoterVnXCL.callRequestCookies('Get',KSTEvcJlDfhYAUmQgRzasoterVnXwH,payload=KSTEvcJlDfhYAUmQgRzasoterVnXWH,params=KSTEvcJlDfhYAUmQgRzasoterVnXwk,headers=KSTEvcJlDfhYAUmQgRzasoterVnXWH,cookies=KSTEvcJlDfhYAUmQgRzasoterVnXWH)
   KSTEvcJlDfhYAUmQgRzasoterVnXLG=json.loads(KSTEvcJlDfhYAUmQgRzasoterVnXCG.text)
   if not('body' in KSTEvcJlDfhYAUmQgRzasoterVnXLG):return{}
   KSTEvcJlDfhYAUmQgRzasoterVnXLB=KSTEvcJlDfhYAUmQgRzasoterVnXLG['body']
   KSTEvcJlDfhYAUmQgRzasoterVnXdk=KSTEvcJlDfhYAUmQgRzasoterVnXLB.get('name').get('ko').strip()
   KSTEvcJlDfhYAUmQgRzasoterVnXLb['saveinfo']['title'] =KSTEvcJlDfhYAUmQgRzasoterVnXdk
   KSTEvcJlDfhYAUmQgRzasoterVnXLb['saveinfo']['infoLabels']['title']=KSTEvcJlDfhYAUmQgRzasoterVnXdk
   KSTEvcJlDfhYAUmQgRzasoterVnXLb['saveinfo']['infoLabels']['mpaa'] =KSTEvcJlDfhYAUmQgRzasoterVnXCq.get(KSTEvcJlDfhYAUmQgRzasoterVnXLB.get('grade_code'))
   KSTEvcJlDfhYAUmQgRzasoterVnXLb['saveinfo']['infoLabels']['plot'] =KSTEvcJlDfhYAUmQgRzasoterVnXLB.get('synopsis').get('ko')
   KSTEvcJlDfhYAUmQgRzasoterVnXLb['saveinfo']['infoLabels']['year'] =KSTEvcJlDfhYAUmQgRzasoterVnXLB.get('product_year')
   KSTEvcJlDfhYAUmQgRzasoterVnXLb['saveinfo']['infoLabels']['cast'] =KSTEvcJlDfhYAUmQgRzasoterVnXLB.get('actor')
   KSTEvcJlDfhYAUmQgRzasoterVnXLb['saveinfo']['infoLabels']['director']=KSTEvcJlDfhYAUmQgRzasoterVnXLB.get('director')
   if KSTEvcJlDfhYAUmQgRzasoterVnXLB.get('category1_name').get('ko')!='':
    KSTEvcJlDfhYAUmQgRzasoterVnXLb['saveinfo']['infoLabels']['genre'].append(KSTEvcJlDfhYAUmQgRzasoterVnXLB.get('category1_name').get('ko'))
   if KSTEvcJlDfhYAUmQgRzasoterVnXLB.get('category2_name').get('ko')!='':
    KSTEvcJlDfhYAUmQgRzasoterVnXLb['saveinfo']['infoLabels']['genre'].append(KSTEvcJlDfhYAUmQgRzasoterVnXLB.get('category2_name').get('ko'))
   KSTEvcJlDfhYAUmQgRzasoterVnXqM=KSTEvcJlDfhYAUmQgRzasoterVnXWG(KSTEvcJlDfhYAUmQgRzasoterVnXLB.get('broad_dt'))
   if KSTEvcJlDfhYAUmQgRzasoterVnXqM!='0':KSTEvcJlDfhYAUmQgRzasoterVnXLb['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(KSTEvcJlDfhYAUmQgRzasoterVnXqM[:4],KSTEvcJlDfhYAUmQgRzasoterVnXqM[4:6],KSTEvcJlDfhYAUmQgRzasoterVnXqM[6:])
   KSTEvcJlDfhYAUmQgRzasoterVnXdP =''
   KSTEvcJlDfhYAUmQgRzasoterVnXdH =''
   KSTEvcJlDfhYAUmQgRzasoterVnXdy=''
   KSTEvcJlDfhYAUmQgRzasoterVnXdI =''
   KSTEvcJlDfhYAUmQgRzasoterVnXdu =''
   for KSTEvcJlDfhYAUmQgRzasoterVnXdb in KSTEvcJlDfhYAUmQgRzasoterVnXLB.get('image'):
    if KSTEvcJlDfhYAUmQgRzasoterVnXdb.get('code')=='CAIP0900':KSTEvcJlDfhYAUmQgRzasoterVnXdP =KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXdb.get('url')
    elif KSTEvcJlDfhYAUmQgRzasoterVnXdb.get('code')=='CAIP0200':KSTEvcJlDfhYAUmQgRzasoterVnXdH =KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXdb.get('url')
    elif KSTEvcJlDfhYAUmQgRzasoterVnXdb.get('code')=='CAIP1800':KSTEvcJlDfhYAUmQgRzasoterVnXdy=KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXdb.get('url')
    elif KSTEvcJlDfhYAUmQgRzasoterVnXdb.get('code')=='CAIP2000':KSTEvcJlDfhYAUmQgRzasoterVnXdI =KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXdb.get('url')
    elif KSTEvcJlDfhYAUmQgRzasoterVnXdb.get('code')=='CAIP1900':KSTEvcJlDfhYAUmQgRzasoterVnXdu =KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXdb.get('url')
   KSTEvcJlDfhYAUmQgRzasoterVnXLb['saveinfo']['thumbnail']['poster']=KSTEvcJlDfhYAUmQgRzasoterVnXdP
   KSTEvcJlDfhYAUmQgRzasoterVnXLb['saveinfo']['thumbnail']['thumb']=KSTEvcJlDfhYAUmQgRzasoterVnXdH
   KSTEvcJlDfhYAUmQgRzasoterVnXLb['saveinfo']['thumbnail']['clearlogo']=KSTEvcJlDfhYAUmQgRzasoterVnXdy
   KSTEvcJlDfhYAUmQgRzasoterVnXLb['saveinfo']['thumbnail']['icon']=KSTEvcJlDfhYAUmQgRzasoterVnXdI
   KSTEvcJlDfhYAUmQgRzasoterVnXLb['saveinfo']['thumbnail']['banner']=KSTEvcJlDfhYAUmQgRzasoterVnXdu
   KSTEvcJlDfhYAUmQgRzasoterVnXLb['saveinfo']['thumbnail']['fanart']=KSTEvcJlDfhYAUmQgRzasoterVnXdH
  else:
   KSTEvcJlDfhYAUmQgRzasoterVnXwH=KSTEvcJlDfhYAUmQgRzasoterVnXCL.API_DOMAIN+'/v2a/media/stream/info'
   KSTEvcJlDfhYAUmQgRzasoterVnXwk=KSTEvcJlDfhYAUmQgRzasoterVnXCL.GetDefaultParams()
   KSTEvcJlDfhYAUmQgRzasoterVnXwF={'info':'Y','mediaCode':videoid,'noCache':KSTEvcJlDfhYAUmQgRzasoterVnXWG(KSTEvcJlDfhYAUmQgRzasoterVnXCL.GetNoCache(1)),'callingFrom':'HTML5','adReq':'adproxy','ooc':'','deviceId':'','uuid':'','deviceInfo':'PC','wm':'Y',}
   KSTEvcJlDfhYAUmQgRzasoterVnXwk.update(KSTEvcJlDfhYAUmQgRzasoterVnXwF)
   KSTEvcJlDfhYAUmQgRzasoterVnXCG=KSTEvcJlDfhYAUmQgRzasoterVnXCL.callRequestCookies('Get',KSTEvcJlDfhYAUmQgRzasoterVnXwH,payload=KSTEvcJlDfhYAUmQgRzasoterVnXWH,params=KSTEvcJlDfhYAUmQgRzasoterVnXwk,headers=KSTEvcJlDfhYAUmQgRzasoterVnXWH,cookies=KSTEvcJlDfhYAUmQgRzasoterVnXWH)
   KSTEvcJlDfhYAUmQgRzasoterVnXLG=json.loads(KSTEvcJlDfhYAUmQgRzasoterVnXCG.text)
   if not('content' in KSTEvcJlDfhYAUmQgRzasoterVnXLG['body']):return{}
   KSTEvcJlDfhYAUmQgRzasoterVnXLB=KSTEvcJlDfhYAUmQgRzasoterVnXLG['body']['content']['info']['movie']
   KSTEvcJlDfhYAUmQgRzasoterVnXdk =KSTEvcJlDfhYAUmQgRzasoterVnXLB.get('name').get('ko').strip()
   KSTEvcJlDfhYAUmQgRzasoterVnXLb['saveinfo']['infoLabels']['title']=KSTEvcJlDfhYAUmQgRzasoterVnXdk
   KSTEvcJlDfhYAUmQgRzasoterVnXdk +=u' (%s)'%(KSTEvcJlDfhYAUmQgRzasoterVnXLB.get('product_year'))
   KSTEvcJlDfhYAUmQgRzasoterVnXLb['saveinfo']['title'] =KSTEvcJlDfhYAUmQgRzasoterVnXdk
   KSTEvcJlDfhYAUmQgRzasoterVnXLb['saveinfo']['infoLabels']['mpaa'] =KSTEvcJlDfhYAUmQgRzasoterVnXCq.get(KSTEvcJlDfhYAUmQgRzasoterVnXLB.get('grade_code'))
   KSTEvcJlDfhYAUmQgRzasoterVnXLb['saveinfo']['infoLabels']['plot'] =KSTEvcJlDfhYAUmQgRzasoterVnXLB.get('story').get('ko')
   KSTEvcJlDfhYAUmQgRzasoterVnXLb['saveinfo']['infoLabels']['year'] =KSTEvcJlDfhYAUmQgRzasoterVnXLB.get('product_year')
   KSTEvcJlDfhYAUmQgRzasoterVnXLb['saveinfo']['infoLabels']['studio'] =KSTEvcJlDfhYAUmQgRzasoterVnXLB.get('production')
   KSTEvcJlDfhYAUmQgRzasoterVnXLb['saveinfo']['infoLabels']['duration']=KSTEvcJlDfhYAUmQgRzasoterVnXLB.get('duration')
   KSTEvcJlDfhYAUmQgRzasoterVnXLb['saveinfo']['infoLabels']['cast'] =KSTEvcJlDfhYAUmQgRzasoterVnXLB.get('actor')
   KSTEvcJlDfhYAUmQgRzasoterVnXLb['saveinfo']['infoLabels']['director']=KSTEvcJlDfhYAUmQgRzasoterVnXLB.get('director')
   if KSTEvcJlDfhYAUmQgRzasoterVnXLB.get('category1_name').get('ko')!='':
    KSTEvcJlDfhYAUmQgRzasoterVnXLb['saveinfo']['infoLabels']['genre'].append(KSTEvcJlDfhYAUmQgRzasoterVnXLB.get('category1_name').get('ko'))
   if KSTEvcJlDfhYAUmQgRzasoterVnXLB.get('category2_name').get('ko')!='':
    KSTEvcJlDfhYAUmQgRzasoterVnXLb['saveinfo']['infoLabels']['genre'].append(KSTEvcJlDfhYAUmQgRzasoterVnXLB.get('category2_name').get('ko'))
   KSTEvcJlDfhYAUmQgRzasoterVnXqM=KSTEvcJlDfhYAUmQgRzasoterVnXWG(KSTEvcJlDfhYAUmQgRzasoterVnXLB.get('release_date'))
   if KSTEvcJlDfhYAUmQgRzasoterVnXqM!='0':KSTEvcJlDfhYAUmQgRzasoterVnXLb['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(KSTEvcJlDfhYAUmQgRzasoterVnXqM[:4],KSTEvcJlDfhYAUmQgRzasoterVnXqM[4:6],KSTEvcJlDfhYAUmQgRzasoterVnXqM[6:])
   KSTEvcJlDfhYAUmQgRzasoterVnXdP=''
   KSTEvcJlDfhYAUmQgRzasoterVnXdH =''
   KSTEvcJlDfhYAUmQgRzasoterVnXdy=''
   for KSTEvcJlDfhYAUmQgRzasoterVnXdb in KSTEvcJlDfhYAUmQgRzasoterVnXLB.get('image'):
    if KSTEvcJlDfhYAUmQgRzasoterVnXdb.get('code')=='CAIM2100':KSTEvcJlDfhYAUmQgRzasoterVnXdP =KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXdb.get('url')
    elif KSTEvcJlDfhYAUmQgRzasoterVnXdb.get('code')=='CAIM0400':KSTEvcJlDfhYAUmQgRzasoterVnXdH =KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXdb.get('url')
    elif KSTEvcJlDfhYAUmQgRzasoterVnXdb.get('code')=='CAIM1800':KSTEvcJlDfhYAUmQgRzasoterVnXdy=KSTEvcJlDfhYAUmQgRzasoterVnXCL.IMG_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXdb.get('url')
   KSTEvcJlDfhYAUmQgRzasoterVnXLb['saveinfo']['thumbnail']['poster']=KSTEvcJlDfhYAUmQgRzasoterVnXdP
   KSTEvcJlDfhYAUmQgRzasoterVnXLb['saveinfo']['thumbnail']['thumb']=KSTEvcJlDfhYAUmQgRzasoterVnXdP 
   KSTEvcJlDfhYAUmQgRzasoterVnXLb['saveinfo']['thumbnail']['clearlogo']=KSTEvcJlDfhYAUmQgRzasoterVnXdy
   KSTEvcJlDfhYAUmQgRzasoterVnXLb['saveinfo']['thumbnail']['fanart']=KSTEvcJlDfhYAUmQgRzasoterVnXdH
  return KSTEvcJlDfhYAUmQgRzasoterVnXLb
 def GetEuroChannelList(KSTEvcJlDfhYAUmQgRzasoterVnXCL):
  KSTEvcJlDfhYAUmQgRzasoterVnXdL=[]
  try:
   KSTEvcJlDfhYAUmQgRzasoterVnXwO ='/v2/operator/highlights'
   KSTEvcJlDfhYAUmQgRzasoterVnXwk=KSTEvcJlDfhYAUmQgRzasoterVnXCL.GetDefaultParams()
   KSTEvcJlDfhYAUmQgRzasoterVnXwF={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':KSTEvcJlDfhYAUmQgRzasoterVnXWG(KSTEvcJlDfhYAUmQgRzasoterVnXCL.GetNoCache(2))}
   KSTEvcJlDfhYAUmQgRzasoterVnXwk.update(KSTEvcJlDfhYAUmQgRzasoterVnXwF)
   KSTEvcJlDfhYAUmQgRzasoterVnXwH=KSTEvcJlDfhYAUmQgRzasoterVnXCL.API_DOMAIN+KSTEvcJlDfhYAUmQgRzasoterVnXwO
   KSTEvcJlDfhYAUmQgRzasoterVnXCG=KSTEvcJlDfhYAUmQgRzasoterVnXCL.callRequestCookies('Get',KSTEvcJlDfhYAUmQgRzasoterVnXwH,payload=KSTEvcJlDfhYAUmQgRzasoterVnXWH,params=KSTEvcJlDfhYAUmQgRzasoterVnXwk,headers=KSTEvcJlDfhYAUmQgRzasoterVnXWH,cookies=KSTEvcJlDfhYAUmQgRzasoterVnXWH)
   KSTEvcJlDfhYAUmQgRzasoterVnXwP=json.loads(KSTEvcJlDfhYAUmQgRzasoterVnXCG.text)
   if not('result' in KSTEvcJlDfhYAUmQgRzasoterVnXwP['body']):return KSTEvcJlDfhYAUmQgRzasoterVnXdL,KSTEvcJlDfhYAUmQgRzasoterVnXdW
   KSTEvcJlDfhYAUmQgRzasoterVnXdi=KSTEvcJlDfhYAUmQgRzasoterVnXwP['body']['result']
   KSTEvcJlDfhYAUmQgRzasoterVnXWC =KSTEvcJlDfhYAUmQgRzasoterVnXCL.Get_Now_Datetime()
   KSTEvcJlDfhYAUmQgRzasoterVnXWw=KSTEvcJlDfhYAUmQgRzasoterVnXWC+datetime.timedelta(days=-1)
   KSTEvcJlDfhYAUmQgRzasoterVnXWw=KSTEvcJlDfhYAUmQgRzasoterVnXWy(KSTEvcJlDfhYAUmQgRzasoterVnXWw.strftime('%Y%m%d'))
   for KSTEvcJlDfhYAUmQgRzasoterVnXwG in KSTEvcJlDfhYAUmQgRzasoterVnXdi:
    KSTEvcJlDfhYAUmQgRzasoterVnXWd=KSTEvcJlDfhYAUmQgRzasoterVnXWy(KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('content').get('banner_title2')[:8])
    if KSTEvcJlDfhYAUmQgRzasoterVnXWw<=KSTEvcJlDfhYAUmQgRzasoterVnXWd:
     KSTEvcJlDfhYAUmQgRzasoterVnXqN={'channel':KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('content').get('banner_sub_title3'),'title':KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('content').get('banner_title'),'subtitle':KSTEvcJlDfhYAUmQgRzasoterVnXwG.get('content').get('banner_sub_title2'),}
     KSTEvcJlDfhYAUmQgRzasoterVnXdL.append(KSTEvcJlDfhYAUmQgRzasoterVnXqN)
  except KSTEvcJlDfhYAUmQgRzasoterVnXWb as exception:
   KSTEvcJlDfhYAUmQgRzasoterVnXWj(exception)
  return KSTEvcJlDfhYAUmQgRzasoterVnXdL
 def Make_DecryptKey(KSTEvcJlDfhYAUmQgRzasoterVnXCL,step,mediacode='000',timecode='000'):
  if step=='1':
   KSTEvcJlDfhYAUmQgRzasoterVnXWq=KSTEvcJlDfhYAUmQgRzasoterVnXpw('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   KSTEvcJlDfhYAUmQgRzasoterVnXWL=KSTEvcJlDfhYAUmQgRzasoterVnXpw('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   KSTEvcJlDfhYAUmQgRzasoterVnXWq=KSTEvcJlDfhYAUmQgRzasoterVnXpw('kss2lym0kdw1lks3','utf-8')
   KSTEvcJlDfhYAUmQgRzasoterVnXWL=KSTEvcJlDfhYAUmQgRzasoterVnXpw([KSTEvcJlDfhYAUmQgRzasoterVnXpd('*'),0x07,KSTEvcJlDfhYAUmQgRzasoterVnXpd('r'),KSTEvcJlDfhYAUmQgRzasoterVnXpd(';'),KSTEvcJlDfhYAUmQgRzasoterVnXpd('7'),0x05,0x1e,0x01,KSTEvcJlDfhYAUmQgRzasoterVnXpd('n'),KSTEvcJlDfhYAUmQgRzasoterVnXpd('D'),0x02,KSTEvcJlDfhYAUmQgRzasoterVnXpd('3'),KSTEvcJlDfhYAUmQgRzasoterVnXpd('*'),KSTEvcJlDfhYAUmQgRzasoterVnXpd('a'),KSTEvcJlDfhYAUmQgRzasoterVnXpd('&'),KSTEvcJlDfhYAUmQgRzasoterVnXpd('<')])
  return KSTEvcJlDfhYAUmQgRzasoterVnXWq,KSTEvcJlDfhYAUmQgRzasoterVnXWL
 def DecryptPlaintext(KSTEvcJlDfhYAUmQgRzasoterVnXCL,ciphertext,encryption_key,init_vector):
  KSTEvcJlDfhYAUmQgRzasoterVnXWp=AES.new(encryption_key,AES.MODE_CBC,init_vector,)
  KSTEvcJlDfhYAUmQgRzasoterVnXWM=Padding.unpad(KSTEvcJlDfhYAUmQgRzasoterVnXWp.decrypt(base64.standard_b64decode(ciphertext)),16)
  return KSTEvcJlDfhYAUmQgRzasoterVnXWM.decode('utf-8')
 def Decrypt_Url(KSTEvcJlDfhYAUmQgRzasoterVnXCL,ciphertext,mediacode,KSTEvcJlDfhYAUmQgRzasoterVnXwB):
  KSTEvcJlDfhYAUmQgRzasoterVnXWi=''
  try:
   KSTEvcJlDfhYAUmQgRzasoterVnXWq,KSTEvcJlDfhYAUmQgRzasoterVnXWL=KSTEvcJlDfhYAUmQgRzasoterVnXCL.Make_DecryptKey('1',mediacode=mediacode,timecode=KSTEvcJlDfhYAUmQgRzasoterVnXwB)
   KSTEvcJlDfhYAUmQgRzasoterVnXWN=json.loads(KSTEvcJlDfhYAUmQgRzasoterVnXCL.DecryptPlaintext(ciphertext,KSTEvcJlDfhYAUmQgRzasoterVnXWq,KSTEvcJlDfhYAUmQgRzasoterVnXWL)).get('broad_url')
   KSTEvcJlDfhYAUmQgRzasoterVnXWq,KSTEvcJlDfhYAUmQgRzasoterVnXWL=KSTEvcJlDfhYAUmQgRzasoterVnXCL.Make_DecryptKey('2',mediacode=mediacode,timecode=KSTEvcJlDfhYAUmQgRzasoterVnXwB)
   KSTEvcJlDfhYAUmQgRzasoterVnXWi=KSTEvcJlDfhYAUmQgRzasoterVnXCL.DecryptPlaintext(KSTEvcJlDfhYAUmQgRzasoterVnXWN,KSTEvcJlDfhYAUmQgRzasoterVnXWq,KSTEvcJlDfhYAUmQgRzasoterVnXWL)
  except KSTEvcJlDfhYAUmQgRzasoterVnXWb as exception:
   KSTEvcJlDfhYAUmQgRzasoterVnXWj(exception)
  return KSTEvcJlDfhYAUmQgRzasoterVnXWi
 def Get_Naver_Login(KSTEvcJlDfhYAUmQgRzasoterVnXCL):
  try:
   KSTEvcJlDfhYAUmQgRzasoterVnXwH='https://user.tving.com/oauth/oauthLogin.tving?target=naver&from=pc&rtUrl=https://user.tving.com/pc/user/login.tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fmain.do%3FretRef%3DY%26source%3Dhttps%3A%2F%2Fwww.google.com%2F&csite=&isAuto=false'
   KSTEvcJlDfhYAUmQgRzasoterVnXCG=KSTEvcJlDfhYAUmQgRzasoterVnXCL.callRequestCookies('Get',KSTEvcJlDfhYAUmQgRzasoterVnXwH,payload=KSTEvcJlDfhYAUmQgRzasoterVnXWH,params=KSTEvcJlDfhYAUmQgRzasoterVnXWH,headers=KSTEvcJlDfhYAUmQgRzasoterVnXWH,cookies=KSTEvcJlDfhYAUmQgRzasoterVnXWH)
   if KSTEvcJlDfhYAUmQgRzasoterVnXCG.status_code!=200:return KSTEvcJlDfhYAUmQgRzasoterVnXWP
   KSTEvcJlDfhYAUmQgRzasoterVnXWx=re.findall('\'https://nid.naver.com/(?:[a-zA-Z]|[0-9]|[$\-@\.&+:/?=_]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+\'',KSTEvcJlDfhYAUmQgRzasoterVnXCG.text)
   KSTEvcJlDfhYAUmQgRzasoterVnXWO=KSTEvcJlDfhYAUmQgRzasoterVnXWx[0].replace('\'','')
   KSTEvcJlDfhYAUmQgRzasoterVnXWj(KSTEvcJlDfhYAUmQgRzasoterVnXWO)
  except KSTEvcJlDfhYAUmQgRzasoterVnXWb as exception:
   KSTEvcJlDfhYAUmQgRzasoterVnXWj('n login pass1 error')
   KSTEvcJlDfhYAUmQgRzasoterVnXWj(exception)
  try:
   KSTEvcJlDfhYAUmQgRzasoterVnXwH=KSTEvcJlDfhYAUmQgRzasoterVnXWO
  except KSTEvcJlDfhYAUmQgRzasoterVnXWb as exception:
   KSTEvcJlDfhYAUmQgRzasoterVnXWj('n login pass1 error')
   KSTEvcJlDfhYAUmQgRzasoterVnXWj(exception)
  return KSTEvcJlDfhYAUmQgRzasoterVnXWu
# Created by pyminifier (https://github.com/liftoff/pyminifier)
