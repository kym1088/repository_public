__author__="NightRain"
tVPRCNYfFdDgxuKIvMoBkeXaOhWbUE=int
import os
import sys
import xbmcaddon
import urllib
__cwd__=xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
__lib__=os.path.join(__cwd__,'resources','lib')
sys.path.append(__lib__)
from tvingRun import*
def get_params():
 p=urllib.parse.parse_qs(sys.argv[2][1:])
 for i in p.keys():
  p[i]=p[i][0]
 return p
tVPRCNYfFdDgxuKIvMoBkeXaOhWbUz=eFvBQHLJAGtjwmKIPVRSDMoxpCuiky(sys.argv[0],tVPRCNYfFdDgxuKIvMoBkeXaOhWbUE(sys.argv[1]),get_params()) 
tVPRCNYfFdDgxuKIvMoBkeXaOhWbUz.tving_main()
# Created by pyminifier (https://github.com/liftoff/pyminifier)
