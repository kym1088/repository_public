__author__="NightRain"
OXAdBejwJQFHpfaEoritLSyYvKbPxN=object
OXAdBejwJQFHpfaEoritLSyYvKbPxm=None
OXAdBejwJQFHpfaEoritLSyYvKbPxg=False
OXAdBejwJQFHpfaEoritLSyYvKbPIM=int
OXAdBejwJQFHpfaEoritLSyYvKbPIz=True
OXAdBejwJQFHpfaEoritLSyYvKbPID=Exception
OXAdBejwJQFHpfaEoritLSyYvKbPIx=print
OXAdBejwJQFHpfaEoritLSyYvKbPIk=str
OXAdBejwJQFHpfaEoritLSyYvKbPIu=list
OXAdBejwJQFHpfaEoritLSyYvKbPIC=range
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import requests
import datetime
OXAdBejwJQFHpfaEoritLSyYvKbPMD ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'
OXAdBejwJQFHpfaEoritLSyYvKbPMx={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
class OXAdBejwJQFHpfaEoritLSyYvKbPMz(OXAdBejwJQFHpfaEoritLSyYvKbPxN):
 def __init__(OXAdBejwJQFHpfaEoritLSyYvKbPMI):
  OXAdBejwJQFHpfaEoritLSyYvKbPMI.TVING_TOKEN =''
  OXAdBejwJQFHpfaEoritLSyYvKbPMI.POC_USERINFO =''
  OXAdBejwJQFHpfaEoritLSyYvKbPMI.TVING_UUID ='-'
  OXAdBejwJQFHpfaEoritLSyYvKbPMI.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  OXAdBejwJQFHpfaEoritLSyYvKbPMI.NETWORKCODE ='CSND0900'
  OXAdBejwJQFHpfaEoritLSyYvKbPMI.OSCODE ='CSOD0900' 
  OXAdBejwJQFHpfaEoritLSyYvKbPMI.TELECODE ='CSCD0900'
  OXAdBejwJQFHpfaEoritLSyYvKbPMI.SCREENCODE ='CSSD0100'
  OXAdBejwJQFHpfaEoritLSyYvKbPMI.LIVE_LIMIT =23
  OXAdBejwJQFHpfaEoritLSyYvKbPMI.VOD_LIMIT =20
  OXAdBejwJQFHpfaEoritLSyYvKbPMI.EPISODE_LIMIT=30 
  OXAdBejwJQFHpfaEoritLSyYvKbPMI.SEARCH_LIMIT =80 
  OXAdBejwJQFHpfaEoritLSyYvKbPMI.MOVIE_LIMIT =18
  OXAdBejwJQFHpfaEoritLSyYvKbPMI.API_DOMAIN ='https://api.tving.com'
  OXAdBejwJQFHpfaEoritLSyYvKbPMI.IMG_DOMAIN ='https://image.tving.com'
  OXAdBejwJQFHpfaEoritLSyYvKbPMI.SEARCH_DOMAIN='https://search.tving.com'
  OXAdBejwJQFHpfaEoritLSyYvKbPMI.LOGIN_DOMAIN ='https://user.tving.com'
  OXAdBejwJQFHpfaEoritLSyYvKbPMI.URL_DOMAIN ='https://www.tving.com'
  OXAdBejwJQFHpfaEoritLSyYvKbPMI.MOVIE_LITE ='338723'
  OXAdBejwJQFHpfaEoritLSyYvKbPMI.MOVIE_PREMIUM='1513561'
  OXAdBejwJQFHpfaEoritLSyYvKbPMI.DEFAULT_HEADER={'user-agent':OXAdBejwJQFHpfaEoritLSyYvKbPMD}
 def callRequestCookies(OXAdBejwJQFHpfaEoritLSyYvKbPMI,jobtype,OXAdBejwJQFHpfaEoritLSyYvKbPMn,payload=OXAdBejwJQFHpfaEoritLSyYvKbPxm,params=OXAdBejwJQFHpfaEoritLSyYvKbPxm,headers=OXAdBejwJQFHpfaEoritLSyYvKbPxm,cookies=OXAdBejwJQFHpfaEoritLSyYvKbPxm,redirects=OXAdBejwJQFHpfaEoritLSyYvKbPxg):
  OXAdBejwJQFHpfaEoritLSyYvKbPMk=OXAdBejwJQFHpfaEoritLSyYvKbPMI.DEFAULT_HEADER
  if headers:OXAdBejwJQFHpfaEoritLSyYvKbPMk.update(headers)
  if jobtype=='Get':
   OXAdBejwJQFHpfaEoritLSyYvKbPMu=requests.get(OXAdBejwJQFHpfaEoritLSyYvKbPMn,params=params,headers=OXAdBejwJQFHpfaEoritLSyYvKbPMk,cookies=cookies,allow_redirects=redirects)
  else:
   OXAdBejwJQFHpfaEoritLSyYvKbPMu=requests.post(OXAdBejwJQFHpfaEoritLSyYvKbPMn,data=payload,params=params,headers=OXAdBejwJQFHpfaEoritLSyYvKbPMk,cookies=cookies,allow_redirects=redirects)
  return OXAdBejwJQFHpfaEoritLSyYvKbPMu
 def makeDefaultCookies(OXAdBejwJQFHpfaEoritLSyYvKbPMI,vToken=OXAdBejwJQFHpfaEoritLSyYvKbPxm,vUserinfo=OXAdBejwJQFHpfaEoritLSyYvKbPxm):
  OXAdBejwJQFHpfaEoritLSyYvKbPMC={}
  OXAdBejwJQFHpfaEoritLSyYvKbPMC['_tving_token']=OXAdBejwJQFHpfaEoritLSyYvKbPMI.TVING_TOKEN if vToken==OXAdBejwJQFHpfaEoritLSyYvKbPxm else vToken
  OXAdBejwJQFHpfaEoritLSyYvKbPMC['POC_USERINFO']=OXAdBejwJQFHpfaEoritLSyYvKbPMI.POC_USERINFO if vToken==OXAdBejwJQFHpfaEoritLSyYvKbPxm else vUserinfo
  return OXAdBejwJQFHpfaEoritLSyYvKbPMC
 def getDeviceStr(OXAdBejwJQFHpfaEoritLSyYvKbPMI):
  OXAdBejwJQFHpfaEoritLSyYvKbPMG=[]
  OXAdBejwJQFHpfaEoritLSyYvKbPMG.append('Windows') 
  OXAdBejwJQFHpfaEoritLSyYvKbPMG.append('Chrome') 
  OXAdBejwJQFHpfaEoritLSyYvKbPMG.append('ko-KR') 
  OXAdBejwJQFHpfaEoritLSyYvKbPMG.append('undefined') 
  OXAdBejwJQFHpfaEoritLSyYvKbPMG.append('24') 
  OXAdBejwJQFHpfaEoritLSyYvKbPMG.append(u'한국 표준시')
  OXAdBejwJQFHpfaEoritLSyYvKbPMG.append('undefined') 
  OXAdBejwJQFHpfaEoritLSyYvKbPMG.append('undefined') 
  OXAdBejwJQFHpfaEoritLSyYvKbPMG.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  OXAdBejwJQFHpfaEoritLSyYvKbPMl=''
  for OXAdBejwJQFHpfaEoritLSyYvKbPMs in OXAdBejwJQFHpfaEoritLSyYvKbPMG:
   OXAdBejwJQFHpfaEoritLSyYvKbPMl+=OXAdBejwJQFHpfaEoritLSyYvKbPMs+'|'
  return OXAdBejwJQFHpfaEoritLSyYvKbPMl
 def SaveCredential(OXAdBejwJQFHpfaEoritLSyYvKbPMI,OXAdBejwJQFHpfaEoritLSyYvKbPMW):
  OXAdBejwJQFHpfaEoritLSyYvKbPMI.TVING_TOKEN =OXAdBejwJQFHpfaEoritLSyYvKbPMW.get('tving_token')
  OXAdBejwJQFHpfaEoritLSyYvKbPMI.POC_USERINFO=OXAdBejwJQFHpfaEoritLSyYvKbPMW.get('poc_userinfo')
  OXAdBejwJQFHpfaEoritLSyYvKbPMI.TVING_UUID =OXAdBejwJQFHpfaEoritLSyYvKbPMW.get('tving_uuid')
 def LoadCredential(OXAdBejwJQFHpfaEoritLSyYvKbPMI):
  OXAdBejwJQFHpfaEoritLSyYvKbPMW={'tving_token':OXAdBejwJQFHpfaEoritLSyYvKbPMI.TVING_TOKEN,'poc_userinfo':OXAdBejwJQFHpfaEoritLSyYvKbPMI.POC_USERINFO,'tving_uuid':OXAdBejwJQFHpfaEoritLSyYvKbPMI.TVING_UUID}
  return OXAdBejwJQFHpfaEoritLSyYvKbPMW
 def GetDefaultParams(OXAdBejwJQFHpfaEoritLSyYvKbPMI):
  OXAdBejwJQFHpfaEoritLSyYvKbPMh={'apiKey':OXAdBejwJQFHpfaEoritLSyYvKbPMI.APIKEY,'networkCode':OXAdBejwJQFHpfaEoritLSyYvKbPMI.NETWORKCODE,'osCode':OXAdBejwJQFHpfaEoritLSyYvKbPMI.OSCODE,'teleCode':OXAdBejwJQFHpfaEoritLSyYvKbPMI.TELECODE,'screenCode':OXAdBejwJQFHpfaEoritLSyYvKbPMI.SCREENCODE}
  return OXAdBejwJQFHpfaEoritLSyYvKbPMh
 def GetNoCache(OXAdBejwJQFHpfaEoritLSyYvKbPMI,timetype=1):
  if timetype==1:
   return OXAdBejwJQFHpfaEoritLSyYvKbPIM(time.time())
  else:
   return OXAdBejwJQFHpfaEoritLSyYvKbPIM(time.time()*1000)
 def makeurl(OXAdBejwJQFHpfaEoritLSyYvKbPMI,domain,path,query1=OXAdBejwJQFHpfaEoritLSyYvKbPxm,query2=OXAdBejwJQFHpfaEoritLSyYvKbPxm):
  OXAdBejwJQFHpfaEoritLSyYvKbPMn=domain+path
  if query1:
   OXAdBejwJQFHpfaEoritLSyYvKbPMn+='?%s'%urllib.parse.urlencode(query1)
  if query2:
   OXAdBejwJQFHpfaEoritLSyYvKbPMn+='&%s'%urllib.parse.urlencode(query2)
  return OXAdBejwJQFHpfaEoritLSyYvKbPMn
 def GetCredential(OXAdBejwJQFHpfaEoritLSyYvKbPMI,user_id,user_pw,login_type):
  OXAdBejwJQFHpfaEoritLSyYvKbPMR=OXAdBejwJQFHpfaEoritLSyYvKbPxg
  OXAdBejwJQFHpfaEoritLSyYvKbPMT=OXAdBejwJQFHpfaEoritLSyYvKbPzM='' 
  OXAdBejwJQFHpfaEoritLSyYvKbPMq='-'
  try:
   OXAdBejwJQFHpfaEoritLSyYvKbPMc=OXAdBejwJQFHpfaEoritLSyYvKbPMI.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   OXAdBejwJQFHpfaEoritLSyYvKbPMN={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'','csite':''}
   OXAdBejwJQFHpfaEoritLSyYvKbPMm=OXAdBejwJQFHpfaEoritLSyYvKbPMI.callRequestCookies('Post',OXAdBejwJQFHpfaEoritLSyYvKbPMc,payload=OXAdBejwJQFHpfaEoritLSyYvKbPMN,params=OXAdBejwJQFHpfaEoritLSyYvKbPxm,headers=OXAdBejwJQFHpfaEoritLSyYvKbPxm,cookies=OXAdBejwJQFHpfaEoritLSyYvKbPxm)
   for OXAdBejwJQFHpfaEoritLSyYvKbPMg in OXAdBejwJQFHpfaEoritLSyYvKbPMm.cookies:
    if OXAdBejwJQFHpfaEoritLSyYvKbPMg.name=='_tving_token':
     OXAdBejwJQFHpfaEoritLSyYvKbPMT=OXAdBejwJQFHpfaEoritLSyYvKbPMg.value
    elif OXAdBejwJQFHpfaEoritLSyYvKbPMg.name=='POC_USERINFO':
     OXAdBejwJQFHpfaEoritLSyYvKbPzM=OXAdBejwJQFHpfaEoritLSyYvKbPMg.value
   if OXAdBejwJQFHpfaEoritLSyYvKbPMT:OXAdBejwJQFHpfaEoritLSyYvKbPMR=OXAdBejwJQFHpfaEoritLSyYvKbPIz
   OXAdBejwJQFHpfaEoritLSyYvKbPMq=OXAdBejwJQFHpfaEoritLSyYvKbPMI.GetDeviceList(OXAdBejwJQFHpfaEoritLSyYvKbPMT,OXAdBejwJQFHpfaEoritLSyYvKbPzM)
  except OXAdBejwJQFHpfaEoritLSyYvKbPID as exception:
   OXAdBejwJQFHpfaEoritLSyYvKbPMT=OXAdBejwJQFHpfaEoritLSyYvKbPzM='' 
   OXAdBejwJQFHpfaEoritLSyYvKbPMq='-'
   OXAdBejwJQFHpfaEoritLSyYvKbPIx(exception)
  OXAdBejwJQFHpfaEoritLSyYvKbPMW={'tving_token':OXAdBejwJQFHpfaEoritLSyYvKbPMT,'poc_userinfo':OXAdBejwJQFHpfaEoritLSyYvKbPzM,'tving_uuid':OXAdBejwJQFHpfaEoritLSyYvKbPMq}
  OXAdBejwJQFHpfaEoritLSyYvKbPMI.SaveCredential(OXAdBejwJQFHpfaEoritLSyYvKbPMW)
  return OXAdBejwJQFHpfaEoritLSyYvKbPMR
 def Get_Now_Datetime(OXAdBejwJQFHpfaEoritLSyYvKbPMI):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(OXAdBejwJQFHpfaEoritLSyYvKbPMI,mediacode,sel_quality,stype):
  OXAdBejwJQFHpfaEoritLSyYvKbPzx=''
  OXAdBejwJQFHpfaEoritLSyYvKbPzI=''
  OXAdBejwJQFHpfaEoritLSyYvKbPzk=OXAdBejwJQFHpfaEoritLSyYvKbPMI.TVING_UUID 
  try:
   if stype!='tvingtv':
    OXAdBejwJQFHpfaEoritLSyYvKbPzu ='/v2/media/stream/info'
    OXAdBejwJQFHpfaEoritLSyYvKbPzC=OXAdBejwJQFHpfaEoritLSyYvKbPMI.GetDefaultParams()
    OXAdBejwJQFHpfaEoritLSyYvKbPzG={'info':'Y','mediaCode':mediacode,'noCache':OXAdBejwJQFHpfaEoritLSyYvKbPIk(OXAdBejwJQFHpfaEoritLSyYvKbPMI.GetNoCache(1)),'callingFrom':'HTML5','adReq':'none','ooc':'','deviceId':OXAdBejwJQFHpfaEoritLSyYvKbPzk,'wm':'Y'}
    OXAdBejwJQFHpfaEoritLSyYvKbPzC.update(OXAdBejwJQFHpfaEoritLSyYvKbPzG)
    OXAdBejwJQFHpfaEoritLSyYvKbPMn=OXAdBejwJQFHpfaEoritLSyYvKbPMI.makeurl(OXAdBejwJQFHpfaEoritLSyYvKbPMI.API_DOMAIN,OXAdBejwJQFHpfaEoritLSyYvKbPzu)
    OXAdBejwJQFHpfaEoritLSyYvKbPMC=OXAdBejwJQFHpfaEoritLSyYvKbPMI.makeDefaultCookies()
    OXAdBejwJQFHpfaEoritLSyYvKbPMm=OXAdBejwJQFHpfaEoritLSyYvKbPMI.callRequestCookies('Get',OXAdBejwJQFHpfaEoritLSyYvKbPMn,payload=OXAdBejwJQFHpfaEoritLSyYvKbPxm,params=OXAdBejwJQFHpfaEoritLSyYvKbPzC,headers=OXAdBejwJQFHpfaEoritLSyYvKbPxm,cookies=OXAdBejwJQFHpfaEoritLSyYvKbPMC)
    OXAdBejwJQFHpfaEoritLSyYvKbPzl=json.loads(OXAdBejwJQFHpfaEoritLSyYvKbPMm.text)
    if not('stream' in OXAdBejwJQFHpfaEoritLSyYvKbPzl['body']):return OXAdBejwJQFHpfaEoritLSyYvKbPzx,OXAdBejwJQFHpfaEoritLSyYvKbPzI 
    OXAdBejwJQFHpfaEoritLSyYvKbPzs=OXAdBejwJQFHpfaEoritLSyYvKbPzl['body']['stream']
    if 'drm_license_assertion' in OXAdBejwJQFHpfaEoritLSyYvKbPzs:
     OXAdBejwJQFHpfaEoritLSyYvKbPzI=OXAdBejwJQFHpfaEoritLSyYvKbPzs['drm_license_assertion']
    OXAdBejwJQFHpfaEoritLSyYvKbPzW=OXAdBejwJQFHpfaEoritLSyYvKbPzs['quality']
    OXAdBejwJQFHpfaEoritLSyYvKbPzh=[]
    for OXAdBejwJQFHpfaEoritLSyYvKbPzn in OXAdBejwJQFHpfaEoritLSyYvKbPzW:
     if OXAdBejwJQFHpfaEoritLSyYvKbPzn['active']=='Y':
      OXAdBejwJQFHpfaEoritLSyYvKbPzh.append({OXAdBejwJQFHpfaEoritLSyYvKbPMx.get(OXAdBejwJQFHpfaEoritLSyYvKbPzn['code']):OXAdBejwJQFHpfaEoritLSyYvKbPzn['code']})
    OXAdBejwJQFHpfaEoritLSyYvKbPzV=OXAdBejwJQFHpfaEoritLSyYvKbPMI.CheckQuality(sel_quality,OXAdBejwJQFHpfaEoritLSyYvKbPzh)
   else:
    for OXAdBejwJQFHpfaEoritLSyYvKbPzU,OXAdBejwJQFHpfaEoritLSyYvKbPDM in OXAdBejwJQFHpfaEoritLSyYvKbPMx.items():
     if OXAdBejwJQFHpfaEoritLSyYvKbPDM==sel_quality:
      OXAdBejwJQFHpfaEoritLSyYvKbPzV=OXAdBejwJQFHpfaEoritLSyYvKbPzU
  except OXAdBejwJQFHpfaEoritLSyYvKbPID as exception:
   OXAdBejwJQFHpfaEoritLSyYvKbPIx(exception)
   for OXAdBejwJQFHpfaEoritLSyYvKbPzU,OXAdBejwJQFHpfaEoritLSyYvKbPDM in OXAdBejwJQFHpfaEoritLSyYvKbPMx.items():
    if OXAdBejwJQFHpfaEoritLSyYvKbPDM==sel_quality:
     OXAdBejwJQFHpfaEoritLSyYvKbPzV=OXAdBejwJQFHpfaEoritLSyYvKbPzU
   return OXAdBejwJQFHpfaEoritLSyYvKbPzx,OXAdBejwJQFHpfaEoritLSyYvKbPzI
  try:
   OXAdBejwJQFHpfaEoritLSyYvKbPzu ='/streaming/info'
   OXAdBejwJQFHpfaEoritLSyYvKbPzC=OXAdBejwJQFHpfaEoritLSyYvKbPMI.GetDefaultParams()
   if stype=='onair':OXAdBejwJQFHpfaEoritLSyYvKbPzC['osCode']='CSOD0400' 
   OXAdBejwJQFHpfaEoritLSyYvKbPzR={'isTrusted':'false','NONE':'0','CAPTURING_PHASE':'1','AT_TARGET':'2','BUBBLING_PHASE':'3','type':'oocCreate','eventPhase':'0','bubbles':'false','cancelable':'false','defaultPrevented':'false','composed':'false','timeStamp':'2158.7350000045262','returnValue':'true','cancelBubble':'false'}
   OXAdBejwJQFHpfaEoritLSyYvKbPzT=OXAdBejwJQFHpfaEoritLSyYvKbPMI.makeOocUrl(OXAdBejwJQFHpfaEoritLSyYvKbPzR)
   OXAdBejwJQFHpfaEoritLSyYvKbPzq=urllib.parse.quote(OXAdBejwJQFHpfaEoritLSyYvKbPzT)
   OXAdBejwJQFHpfaEoritLSyYvKbPzG={'info':'Y','mediaCode':mediacode,'callingFrom':'HTML5','streamCode':OXAdBejwJQFHpfaEoritLSyYvKbPzV,'adReq':'none','ooc':OXAdBejwJQFHpfaEoritLSyYvKbPzT,'deviceId':OXAdBejwJQFHpfaEoritLSyYvKbPzk}
   OXAdBejwJQFHpfaEoritLSyYvKbPzc =OXAdBejwJQFHpfaEoritLSyYvKbPzC
   OXAdBejwJQFHpfaEoritLSyYvKbPzc.update(OXAdBejwJQFHpfaEoritLSyYvKbPzG)
   OXAdBejwJQFHpfaEoritLSyYvKbPMn=OXAdBejwJQFHpfaEoritLSyYvKbPMI.URL_DOMAIN+OXAdBejwJQFHpfaEoritLSyYvKbPzu
   OXAdBejwJQFHpfaEoritLSyYvKbPzN={'origin':'https://www.tving.com','Referer':'https://www.tving.com/vod/player/'+mediacode}
   OXAdBejwJQFHpfaEoritLSyYvKbPMC=OXAdBejwJQFHpfaEoritLSyYvKbPMI.makeDefaultCookies()
   OXAdBejwJQFHpfaEoritLSyYvKbPMC['onClickEvent2']=OXAdBejwJQFHpfaEoritLSyYvKbPzq
   OXAdBejwJQFHpfaEoritLSyYvKbPMm=OXAdBejwJQFHpfaEoritLSyYvKbPMI.callRequestCookies('Post',OXAdBejwJQFHpfaEoritLSyYvKbPMn,payload=OXAdBejwJQFHpfaEoritLSyYvKbPzc,params=OXAdBejwJQFHpfaEoritLSyYvKbPxm,headers=OXAdBejwJQFHpfaEoritLSyYvKbPzN,cookies=OXAdBejwJQFHpfaEoritLSyYvKbPMC)
   OXAdBejwJQFHpfaEoritLSyYvKbPzl=json.loads(OXAdBejwJQFHpfaEoritLSyYvKbPMm.text)
   if OXAdBejwJQFHpfaEoritLSyYvKbPzI!='':
    OXAdBejwJQFHpfaEoritLSyYvKbPzI =OXAdBejwJQFHpfaEoritLSyYvKbPzl['stream']['drm_license_assertion']
    OXAdBejwJQFHpfaEoritLSyYvKbPzx=OXAdBejwJQFHpfaEoritLSyYvKbPzl['stream']['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in OXAdBejwJQFHpfaEoritLSyYvKbPzl['stream']['broadcast']):return OXAdBejwJQFHpfaEoritLSyYvKbPzx,OXAdBejwJQFHpfaEoritLSyYvKbPzI
    OXAdBejwJQFHpfaEoritLSyYvKbPzx=OXAdBejwJQFHpfaEoritLSyYvKbPzl['stream']['broadcast']['broad_url']
  except OXAdBejwJQFHpfaEoritLSyYvKbPID as exception:
   OXAdBejwJQFHpfaEoritLSyYvKbPIx(exception)
  return OXAdBejwJQFHpfaEoritLSyYvKbPzx,OXAdBejwJQFHpfaEoritLSyYvKbPzI
 def CheckQuality(OXAdBejwJQFHpfaEoritLSyYvKbPMI,sel_qt,OXAdBejwJQFHpfaEoritLSyYvKbPzh):
  for OXAdBejwJQFHpfaEoritLSyYvKbPzm in OXAdBejwJQFHpfaEoritLSyYvKbPzh:
   if sel_qt>=OXAdBejwJQFHpfaEoritLSyYvKbPIu(OXAdBejwJQFHpfaEoritLSyYvKbPzm)[0]:return OXAdBejwJQFHpfaEoritLSyYvKbPzm.get(OXAdBejwJQFHpfaEoritLSyYvKbPIu(OXAdBejwJQFHpfaEoritLSyYvKbPzm)[0])
   OXAdBejwJQFHpfaEoritLSyYvKbPzg=OXAdBejwJQFHpfaEoritLSyYvKbPzm.get(OXAdBejwJQFHpfaEoritLSyYvKbPIu(OXAdBejwJQFHpfaEoritLSyYvKbPzm)[0])
  return OXAdBejwJQFHpfaEoritLSyYvKbPzg
 def makeOocUrl(OXAdBejwJQFHpfaEoritLSyYvKbPMI,OXAdBejwJQFHpfaEoritLSyYvKbPzR):
  OXAdBejwJQFHpfaEoritLSyYvKbPMn=''
  for OXAdBejwJQFHpfaEoritLSyYvKbPzU,OXAdBejwJQFHpfaEoritLSyYvKbPDM in OXAdBejwJQFHpfaEoritLSyYvKbPzR.items():
   OXAdBejwJQFHpfaEoritLSyYvKbPMn+="%s=%s^"%(OXAdBejwJQFHpfaEoritLSyYvKbPzU,OXAdBejwJQFHpfaEoritLSyYvKbPDM)
  return OXAdBejwJQFHpfaEoritLSyYvKbPMn
 def GetLiveChannelList(OXAdBejwJQFHpfaEoritLSyYvKbPMI,stype,page_int):
  OXAdBejwJQFHpfaEoritLSyYvKbPDz=[]
  OXAdBejwJQFHpfaEoritLSyYvKbPDx=OXAdBejwJQFHpfaEoritLSyYvKbPxg
  try:
   OXAdBejwJQFHpfaEoritLSyYvKbPzu ='/v2/media/lives'
   if stype=='onair':
    OXAdBejwJQFHpfaEoritLSyYvKbPDI='CPCS0100,CPCS0400'
   else:
    OXAdBejwJQFHpfaEoritLSyYvKbPDI='CPCS0300'
   OXAdBejwJQFHpfaEoritLSyYvKbPzC=OXAdBejwJQFHpfaEoritLSyYvKbPMI.GetDefaultParams()
   OXAdBejwJQFHpfaEoritLSyYvKbPzG={'pageNo':OXAdBejwJQFHpfaEoritLSyYvKbPIk(page_int),'pageSize':OXAdBejwJQFHpfaEoritLSyYvKbPIk(OXAdBejwJQFHpfaEoritLSyYvKbPMI.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':OXAdBejwJQFHpfaEoritLSyYvKbPDI,'_':OXAdBejwJQFHpfaEoritLSyYvKbPIk(OXAdBejwJQFHpfaEoritLSyYvKbPMI.GetNoCache(2))}
   OXAdBejwJQFHpfaEoritLSyYvKbPzC.update(OXAdBejwJQFHpfaEoritLSyYvKbPzG)
   OXAdBejwJQFHpfaEoritLSyYvKbPMn=OXAdBejwJQFHpfaEoritLSyYvKbPMI.makeurl(OXAdBejwJQFHpfaEoritLSyYvKbPMI.API_DOMAIN,OXAdBejwJQFHpfaEoritLSyYvKbPzu)
   OXAdBejwJQFHpfaEoritLSyYvKbPMC=OXAdBejwJQFHpfaEoritLSyYvKbPMI.makeDefaultCookies()
   OXAdBejwJQFHpfaEoritLSyYvKbPMm=OXAdBejwJQFHpfaEoritLSyYvKbPMI.callRequestCookies('Get',OXAdBejwJQFHpfaEoritLSyYvKbPMn,payload=OXAdBejwJQFHpfaEoritLSyYvKbPxm,params=OXAdBejwJQFHpfaEoritLSyYvKbPzC,headers=OXAdBejwJQFHpfaEoritLSyYvKbPxm,cookies=OXAdBejwJQFHpfaEoritLSyYvKbPMC)
   OXAdBejwJQFHpfaEoritLSyYvKbPzl=json.loads(OXAdBejwJQFHpfaEoritLSyYvKbPMm.text)
   if not('result' in OXAdBejwJQFHpfaEoritLSyYvKbPzl['body']):return OXAdBejwJQFHpfaEoritLSyYvKbPDz,OXAdBejwJQFHpfaEoritLSyYvKbPDx
   OXAdBejwJQFHpfaEoritLSyYvKbPDk=OXAdBejwJQFHpfaEoritLSyYvKbPzl['body']['result']
   for OXAdBejwJQFHpfaEoritLSyYvKbPzn in OXAdBejwJQFHpfaEoritLSyYvKbPDk:
    OXAdBejwJQFHpfaEoritLSyYvKbPDu={}
    OXAdBejwJQFHpfaEoritLSyYvKbPDu['mediatype']='video'
    OXAdBejwJQFHpfaEoritLSyYvKbPDC=OXAdBejwJQFHpfaEoritLSyYvKbPDs=OXAdBejwJQFHpfaEoritLSyYvKbPDW=OXAdBejwJQFHpfaEoritLSyYvKbPDh=''
    OXAdBejwJQFHpfaEoritLSyYvKbPDG=OXAdBejwJQFHpfaEoritLSyYvKbPDR=''
    OXAdBejwJQFHpfaEoritLSyYvKbPDl=OXAdBejwJQFHpfaEoritLSyYvKbPzn['live_code']
    OXAdBejwJQFHpfaEoritLSyYvKbPDC =OXAdBejwJQFHpfaEoritLSyYvKbPzn['schedule']['channel']['name']['ko']
    if OXAdBejwJQFHpfaEoritLSyYvKbPzn['schedule']['episode']!=OXAdBejwJQFHpfaEoritLSyYvKbPxm:
     OXAdBejwJQFHpfaEoritLSyYvKbPDs =OXAdBejwJQFHpfaEoritLSyYvKbPzn['schedule']['program']['name']['ko']
     OXAdBejwJQFHpfaEoritLSyYvKbPDs =OXAdBejwJQFHpfaEoritLSyYvKbPDs+', '+OXAdBejwJQFHpfaEoritLSyYvKbPIk(OXAdBejwJQFHpfaEoritLSyYvKbPzn['schedule']['episode']['frequency'])+'회'
     if OXAdBejwJQFHpfaEoritLSyYvKbPzn['schedule']['episode']['image']!=[]:
      OXAdBejwJQFHpfaEoritLSyYvKbPDW=OXAdBejwJQFHpfaEoritLSyYvKbPzn['schedule']['episode']['image'][0]['url']
     OXAdBejwJQFHpfaEoritLSyYvKbPDh=OXAdBejwJQFHpfaEoritLSyYvKbPzn['schedule']['episode']['synopsis']['ko']
    else:
     OXAdBejwJQFHpfaEoritLSyYvKbPDs =OXAdBejwJQFHpfaEoritLSyYvKbPzn['schedule']['program']['name']['ko']
     if OXAdBejwJQFHpfaEoritLSyYvKbPzn['schedule']['program']['image']!=[]:
      OXAdBejwJQFHpfaEoritLSyYvKbPDW=OXAdBejwJQFHpfaEoritLSyYvKbPzn['schedule']['program']['image'][0]['url']
     OXAdBejwJQFHpfaEoritLSyYvKbPDh=OXAdBejwJQFHpfaEoritLSyYvKbPzn['schedule']['program']['synopsis']['ko']
    OXAdBejwJQFHpfaEoritLSyYvKbPDu['title'] =OXAdBejwJQFHpfaEoritLSyYvKbPzn['schedule']['program']['name']['ko']
    OXAdBejwJQFHpfaEoritLSyYvKbPDu['studio'] =OXAdBejwJQFHpfaEoritLSyYvKbPDC
    try:
     OXAdBejwJQFHpfaEoritLSyYvKbPDn=[]
     for OXAdBejwJQFHpfaEoritLSyYvKbPDV in OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('schedule').get('program').get('actor'):OXAdBejwJQFHpfaEoritLSyYvKbPDn.append(OXAdBejwJQFHpfaEoritLSyYvKbPDV)
     if OXAdBejwJQFHpfaEoritLSyYvKbPDn[0]!='' and OXAdBejwJQFHpfaEoritLSyYvKbPDn[0]!=u'없음':OXAdBejwJQFHpfaEoritLSyYvKbPDu['cast']=OXAdBejwJQFHpfaEoritLSyYvKbPDn
    except:
     OXAdBejwJQFHpfaEoritLSyYvKbPxm
    try:
     OXAdBejwJQFHpfaEoritLSyYvKbPDU=[]
     if OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('schedule').get('program').get('category1_name').get('ko')!='':
      OXAdBejwJQFHpfaEoritLSyYvKbPDU.append(OXAdBejwJQFHpfaEoritLSyYvKbPzn['schedule']['program']['category1_name']['ko'])
     if OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('schedule').get('program').get('category2_name').get('ko')!='':
      OXAdBejwJQFHpfaEoritLSyYvKbPDU.append(OXAdBejwJQFHpfaEoritLSyYvKbPzn['schedule']['program']['category2_name']['ko'])
     if OXAdBejwJQFHpfaEoritLSyYvKbPDU[0]!='':OXAdBejwJQFHpfaEoritLSyYvKbPDu['genre']=OXAdBejwJQFHpfaEoritLSyYvKbPDU
    except:
     OXAdBejwJQFHpfaEoritLSyYvKbPxm
    if OXAdBejwJQFHpfaEoritLSyYvKbPDW=='':
     OXAdBejwJQFHpfaEoritLSyYvKbPDW=OXAdBejwJQFHpfaEoritLSyYvKbPzn['schedule']['channel']['image'][0]['url']
    if OXAdBejwJQFHpfaEoritLSyYvKbPDW!='':OXAdBejwJQFHpfaEoritLSyYvKbPDW=OXAdBejwJQFHpfaEoritLSyYvKbPMI.IMG_DOMAIN+OXAdBejwJQFHpfaEoritLSyYvKbPDW
    OXAdBejwJQFHpfaEoritLSyYvKbPDG=OXAdBejwJQFHpfaEoritLSyYvKbPIk(OXAdBejwJQFHpfaEoritLSyYvKbPzn['schedule']['broadcast_start_time'])[8:12]
    OXAdBejwJQFHpfaEoritLSyYvKbPDR =OXAdBejwJQFHpfaEoritLSyYvKbPIk(OXAdBejwJQFHpfaEoritLSyYvKbPzn['schedule']['broadcast_end_time'])[8:12]
    OXAdBejwJQFHpfaEoritLSyYvKbPDT={'channel':OXAdBejwJQFHpfaEoritLSyYvKbPDC,'title':OXAdBejwJQFHpfaEoritLSyYvKbPDs,'mediacode':OXAdBejwJQFHpfaEoritLSyYvKbPDl,'thumbnail':OXAdBejwJQFHpfaEoritLSyYvKbPDW,'synopsis':OXAdBejwJQFHpfaEoritLSyYvKbPDh,'channelepg':' [%s:%s ~ %s:%s]'%(OXAdBejwJQFHpfaEoritLSyYvKbPDG[0:2],OXAdBejwJQFHpfaEoritLSyYvKbPDG[2:],OXAdBejwJQFHpfaEoritLSyYvKbPDR[0:2],OXAdBejwJQFHpfaEoritLSyYvKbPDR[2:]),'info':OXAdBejwJQFHpfaEoritLSyYvKbPDu}
    OXAdBejwJQFHpfaEoritLSyYvKbPDz.append(OXAdBejwJQFHpfaEoritLSyYvKbPDT)
   if OXAdBejwJQFHpfaEoritLSyYvKbPzl['body']['has_more']=='Y':OXAdBejwJQFHpfaEoritLSyYvKbPDx=OXAdBejwJQFHpfaEoritLSyYvKbPIz
  except OXAdBejwJQFHpfaEoritLSyYvKbPID as exception:
   OXAdBejwJQFHpfaEoritLSyYvKbPIx(exception)
  return OXAdBejwJQFHpfaEoritLSyYvKbPDz,OXAdBejwJQFHpfaEoritLSyYvKbPDx
 def GetProgramList(OXAdBejwJQFHpfaEoritLSyYvKbPMI,stype,orderby,page_int,landyn=OXAdBejwJQFHpfaEoritLSyYvKbPxg):
  OXAdBejwJQFHpfaEoritLSyYvKbPDz=[]
  OXAdBejwJQFHpfaEoritLSyYvKbPDx=OXAdBejwJQFHpfaEoritLSyYvKbPxg
  try:
   OXAdBejwJQFHpfaEoritLSyYvKbPzu ='/v2/media/episodes'
   OXAdBejwJQFHpfaEoritLSyYvKbPzC=OXAdBejwJQFHpfaEoritLSyYvKbPMI.GetDefaultParams()
   OXAdBejwJQFHpfaEoritLSyYvKbPzG={'pageNo':OXAdBejwJQFHpfaEoritLSyYvKbPIk(page_int),'pageSize':OXAdBejwJQFHpfaEoritLSyYvKbPIk(OXAdBejwJQFHpfaEoritLSyYvKbPMI.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','_':OXAdBejwJQFHpfaEoritLSyYvKbPIk(OXAdBejwJQFHpfaEoritLSyYvKbPMI.GetNoCache(2))}
   if stype!='all':OXAdBejwJQFHpfaEoritLSyYvKbPzG['multiCategoryCode']=stype
   OXAdBejwJQFHpfaEoritLSyYvKbPzC.update(OXAdBejwJQFHpfaEoritLSyYvKbPzG)
   OXAdBejwJQFHpfaEoritLSyYvKbPMn=OXAdBejwJQFHpfaEoritLSyYvKbPMI.makeurl(OXAdBejwJQFHpfaEoritLSyYvKbPMI.API_DOMAIN,OXAdBejwJQFHpfaEoritLSyYvKbPzu)
   OXAdBejwJQFHpfaEoritLSyYvKbPMC=OXAdBejwJQFHpfaEoritLSyYvKbPMI.makeDefaultCookies()
   OXAdBejwJQFHpfaEoritLSyYvKbPMm=OXAdBejwJQFHpfaEoritLSyYvKbPMI.callRequestCookies('Get',OXAdBejwJQFHpfaEoritLSyYvKbPMn,payload=OXAdBejwJQFHpfaEoritLSyYvKbPxm,params=OXAdBejwJQFHpfaEoritLSyYvKbPzC,headers=OXAdBejwJQFHpfaEoritLSyYvKbPxm,cookies=OXAdBejwJQFHpfaEoritLSyYvKbPMC)
   OXAdBejwJQFHpfaEoritLSyYvKbPzl=json.loads(OXAdBejwJQFHpfaEoritLSyYvKbPMm.text)
   if not('result' in OXAdBejwJQFHpfaEoritLSyYvKbPzl['body']):return OXAdBejwJQFHpfaEoritLSyYvKbPDz,OXAdBejwJQFHpfaEoritLSyYvKbPDx
   OXAdBejwJQFHpfaEoritLSyYvKbPDk=OXAdBejwJQFHpfaEoritLSyYvKbPzl['body']['result']
   for OXAdBejwJQFHpfaEoritLSyYvKbPzn in OXAdBejwJQFHpfaEoritLSyYvKbPDk:
    OXAdBejwJQFHpfaEoritLSyYvKbPDq=OXAdBejwJQFHpfaEoritLSyYvKbPzn['program']['code']
    OXAdBejwJQFHpfaEoritLSyYvKbPDs =OXAdBejwJQFHpfaEoritLSyYvKbPzn['program']['name']['ko']
    OXAdBejwJQFHpfaEoritLSyYvKbPDW =OXAdBejwJQFHpfaEoritLSyYvKbPMI.IMG_DOMAIN+OXAdBejwJQFHpfaEoritLSyYvKbPzn['program']['image'][0]['url']
    OXAdBejwJQFHpfaEoritLSyYvKbPDc='CAIP0200' if landyn else 'CAIP0900' 
    for OXAdBejwJQFHpfaEoritLSyYvKbPDN in OXAdBejwJQFHpfaEoritLSyYvKbPzn['program']['image']:
     if OXAdBejwJQFHpfaEoritLSyYvKbPDN['code']==OXAdBejwJQFHpfaEoritLSyYvKbPDc:
      OXAdBejwJQFHpfaEoritLSyYvKbPDW =OXAdBejwJQFHpfaEoritLSyYvKbPMI.IMG_DOMAIN+OXAdBejwJQFHpfaEoritLSyYvKbPDN['url']
      break
    OXAdBejwJQFHpfaEoritLSyYvKbPDh =OXAdBejwJQFHpfaEoritLSyYvKbPzn['program']['synopsis']['ko']
    OXAdBejwJQFHpfaEoritLSyYvKbPDm=OXAdBejwJQFHpfaEoritLSyYvKbPzn['program']['channel_code']
    OXAdBejwJQFHpfaEoritLSyYvKbPDu={}
    OXAdBejwJQFHpfaEoritLSyYvKbPDu['title'] =OXAdBejwJQFHpfaEoritLSyYvKbPDs 
    OXAdBejwJQFHpfaEoritLSyYvKbPDu['mediatype']='episode' 
    try:
     OXAdBejwJQFHpfaEoritLSyYvKbPDn=[]
     for OXAdBejwJQFHpfaEoritLSyYvKbPDV in OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('program').get('actor'):OXAdBejwJQFHpfaEoritLSyYvKbPDn.append(OXAdBejwJQFHpfaEoritLSyYvKbPDV)
     if OXAdBejwJQFHpfaEoritLSyYvKbPDn[0]!='' and OXAdBejwJQFHpfaEoritLSyYvKbPDn[0]!='-':OXAdBejwJQFHpfaEoritLSyYvKbPDu['cast']=OXAdBejwJQFHpfaEoritLSyYvKbPDn
    except:
     OXAdBejwJQFHpfaEoritLSyYvKbPxm
    try:
     OXAdBejwJQFHpfaEoritLSyYvKbPDg=[]
     for OXAdBejwJQFHpfaEoritLSyYvKbPxM in OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('program').get('director'):OXAdBejwJQFHpfaEoritLSyYvKbPDg.append(OXAdBejwJQFHpfaEoritLSyYvKbPxM)
     if OXAdBejwJQFHpfaEoritLSyYvKbPDg[0]!='' and OXAdBejwJQFHpfaEoritLSyYvKbPDg[0]!='-':OXAdBejwJQFHpfaEoritLSyYvKbPDu['director']=OXAdBejwJQFHpfaEoritLSyYvKbPDg
    except:
     OXAdBejwJQFHpfaEoritLSyYvKbPxm
    OXAdBejwJQFHpfaEoritLSyYvKbPDU=[]
    if OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('program').get('category1_name').get('ko')!='':
     OXAdBejwJQFHpfaEoritLSyYvKbPDU.append(OXAdBejwJQFHpfaEoritLSyYvKbPzn['program']['category1_name']['ko'])
    if OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('program').get('category2_name').get('ko')!='':
     OXAdBejwJQFHpfaEoritLSyYvKbPDU.append(OXAdBejwJQFHpfaEoritLSyYvKbPzn['program']['category2_name']['ko'])
    if OXAdBejwJQFHpfaEoritLSyYvKbPDU[0]!='':OXAdBejwJQFHpfaEoritLSyYvKbPDu['genre']=OXAdBejwJQFHpfaEoritLSyYvKbPDU
    try:
     if OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('program').get('product_year'):OXAdBejwJQFHpfaEoritLSyYvKbPDu['year']=OXAdBejwJQFHpfaEoritLSyYvKbPzn['program']['product_year']
     if 'broad_dt' in OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('program'):
      OXAdBejwJQFHpfaEoritLSyYvKbPxz=OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('program').get('broad_dt')
      OXAdBejwJQFHpfaEoritLSyYvKbPDu['aired']='%s-%s-%s'%(OXAdBejwJQFHpfaEoritLSyYvKbPxz[:4],OXAdBejwJQFHpfaEoritLSyYvKbPxz[4:6],OXAdBejwJQFHpfaEoritLSyYvKbPxz[6:])
    except:
     OXAdBejwJQFHpfaEoritLSyYvKbPxm
    OXAdBejwJQFHpfaEoritLSyYvKbPDT={'program':OXAdBejwJQFHpfaEoritLSyYvKbPDq,'title':OXAdBejwJQFHpfaEoritLSyYvKbPDs,'thumbnail':OXAdBejwJQFHpfaEoritLSyYvKbPDW,'synopsis':OXAdBejwJQFHpfaEoritLSyYvKbPDh,'channel':OXAdBejwJQFHpfaEoritLSyYvKbPDm,'info':OXAdBejwJQFHpfaEoritLSyYvKbPDu}
    OXAdBejwJQFHpfaEoritLSyYvKbPDz.append(OXAdBejwJQFHpfaEoritLSyYvKbPDT)
   if OXAdBejwJQFHpfaEoritLSyYvKbPzl['body']['has_more']=='Y':OXAdBejwJQFHpfaEoritLSyYvKbPDx=OXAdBejwJQFHpfaEoritLSyYvKbPIz
  except OXAdBejwJQFHpfaEoritLSyYvKbPID as exception:
   OXAdBejwJQFHpfaEoritLSyYvKbPIx(exception)
  return OXAdBejwJQFHpfaEoritLSyYvKbPDz,OXAdBejwJQFHpfaEoritLSyYvKbPDx
 def GetEpisodoList(OXAdBejwJQFHpfaEoritLSyYvKbPMI,program_code,page_int,orderby='desc'):
  OXAdBejwJQFHpfaEoritLSyYvKbPDz=[]
  OXAdBejwJQFHpfaEoritLSyYvKbPDx=OXAdBejwJQFHpfaEoritLSyYvKbPxg
  try:
   OXAdBejwJQFHpfaEoritLSyYvKbPzu ='/v2/media/frequency/program/'+program_code
   OXAdBejwJQFHpfaEoritLSyYvKbPzC=OXAdBejwJQFHpfaEoritLSyYvKbPMI.GetDefaultParams()
   OXAdBejwJQFHpfaEoritLSyYvKbPzG={'pageNo':'1','pageSize':'10','order':'new','free':'all','adult':'all','scope':'all','_':OXAdBejwJQFHpfaEoritLSyYvKbPIk(OXAdBejwJQFHpfaEoritLSyYvKbPMI.GetNoCache(2))}
   OXAdBejwJQFHpfaEoritLSyYvKbPzC.update(OXAdBejwJQFHpfaEoritLSyYvKbPzG)
   OXAdBejwJQFHpfaEoritLSyYvKbPMn=OXAdBejwJQFHpfaEoritLSyYvKbPMI.makeurl(OXAdBejwJQFHpfaEoritLSyYvKbPMI.API_DOMAIN,OXAdBejwJQFHpfaEoritLSyYvKbPzu)
   OXAdBejwJQFHpfaEoritLSyYvKbPMC=OXAdBejwJQFHpfaEoritLSyYvKbPMI.makeDefaultCookies()
   OXAdBejwJQFHpfaEoritLSyYvKbPMm=OXAdBejwJQFHpfaEoritLSyYvKbPMI.callRequestCookies('Get',OXAdBejwJQFHpfaEoritLSyYvKbPMn,payload=OXAdBejwJQFHpfaEoritLSyYvKbPxm,params=OXAdBejwJQFHpfaEoritLSyYvKbPzC,headers=OXAdBejwJQFHpfaEoritLSyYvKbPxm,cookies=OXAdBejwJQFHpfaEoritLSyYvKbPMC)
   OXAdBejwJQFHpfaEoritLSyYvKbPzl=json.loads(OXAdBejwJQFHpfaEoritLSyYvKbPMm.text)
   if not('result' in OXAdBejwJQFHpfaEoritLSyYvKbPzl['body']):return OXAdBejwJQFHpfaEoritLSyYvKbPDz,OXAdBejwJQFHpfaEoritLSyYvKbPDx
   OXAdBejwJQFHpfaEoritLSyYvKbPDk=OXAdBejwJQFHpfaEoritLSyYvKbPzl['body']['result']
   OXAdBejwJQFHpfaEoritLSyYvKbPxD=OXAdBejwJQFHpfaEoritLSyYvKbPIM(OXAdBejwJQFHpfaEoritLSyYvKbPzl['body']['total_count'])
   OXAdBejwJQFHpfaEoritLSyYvKbPxI =OXAdBejwJQFHpfaEoritLSyYvKbPIM(OXAdBejwJQFHpfaEoritLSyYvKbPxD//(OXAdBejwJQFHpfaEoritLSyYvKbPMI.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    OXAdBejwJQFHpfaEoritLSyYvKbPxk =(OXAdBejwJQFHpfaEoritLSyYvKbPxD-1)-((page_int-1)*OXAdBejwJQFHpfaEoritLSyYvKbPMI.EPISODE_LIMIT)
   else:
    OXAdBejwJQFHpfaEoritLSyYvKbPxk =(page_int-1)*OXAdBejwJQFHpfaEoritLSyYvKbPMI.EPISODE_LIMIT
   for i in OXAdBejwJQFHpfaEoritLSyYvKbPIC(OXAdBejwJQFHpfaEoritLSyYvKbPMI.EPISODE_LIMIT):
    if orderby=='desc':
     OXAdBejwJQFHpfaEoritLSyYvKbPxu=OXAdBejwJQFHpfaEoritLSyYvKbPxk-i
     if OXAdBejwJQFHpfaEoritLSyYvKbPxu<0:break
    else:
     OXAdBejwJQFHpfaEoritLSyYvKbPxu=OXAdBejwJQFHpfaEoritLSyYvKbPxk+i
     if OXAdBejwJQFHpfaEoritLSyYvKbPxu>=OXAdBejwJQFHpfaEoritLSyYvKbPxD:break
    OXAdBejwJQFHpfaEoritLSyYvKbPxC=OXAdBejwJQFHpfaEoritLSyYvKbPDk[OXAdBejwJQFHpfaEoritLSyYvKbPxu]['episode']['code']
    OXAdBejwJQFHpfaEoritLSyYvKbPDs =OXAdBejwJQFHpfaEoritLSyYvKbPDk[OXAdBejwJQFHpfaEoritLSyYvKbPxu]['vod_name']['ko']
    OXAdBejwJQFHpfaEoritLSyYvKbPxG =''
    try:
     OXAdBejwJQFHpfaEoritLSyYvKbPxz=OXAdBejwJQFHpfaEoritLSyYvKbPIk(OXAdBejwJQFHpfaEoritLSyYvKbPDk[OXAdBejwJQFHpfaEoritLSyYvKbPxu]['episode']['broadcast_date'])
     OXAdBejwJQFHpfaEoritLSyYvKbPxG='%s-%s-%s'%(OXAdBejwJQFHpfaEoritLSyYvKbPxz[:4],OXAdBejwJQFHpfaEoritLSyYvKbPxz[4:6],OXAdBejwJQFHpfaEoritLSyYvKbPxz[6:])
    except:
     OXAdBejwJQFHpfaEoritLSyYvKbPxm
    if OXAdBejwJQFHpfaEoritLSyYvKbPDk[OXAdBejwJQFHpfaEoritLSyYvKbPxu]['episode']['image']!=[]:
     OXAdBejwJQFHpfaEoritLSyYvKbPDW=OXAdBejwJQFHpfaEoritLSyYvKbPMI.IMG_DOMAIN+OXAdBejwJQFHpfaEoritLSyYvKbPDk[OXAdBejwJQFHpfaEoritLSyYvKbPxu]['episode']['image'][0]['url']
    else:
     OXAdBejwJQFHpfaEoritLSyYvKbPDW=OXAdBejwJQFHpfaEoritLSyYvKbPMI.IMG_DOMAIN+OXAdBejwJQFHpfaEoritLSyYvKbPDk[OXAdBejwJQFHpfaEoritLSyYvKbPxu]['program']['image'][0]['url']
    OXAdBejwJQFHpfaEoritLSyYvKbPDh =OXAdBejwJQFHpfaEoritLSyYvKbPDk[OXAdBejwJQFHpfaEoritLSyYvKbPxu]['episode']['synopsis']['ko']
    OXAdBejwJQFHpfaEoritLSyYvKbPDu={}
    OXAdBejwJQFHpfaEoritLSyYvKbPDu['mediatype']='episode' 
    try:
     OXAdBejwJQFHpfaEoritLSyYvKbPDu['title'] =OXAdBejwJQFHpfaEoritLSyYvKbPDk[OXAdBejwJQFHpfaEoritLSyYvKbPxu]['program']['name']['ko']
     OXAdBejwJQFHpfaEoritLSyYvKbPDu['aired'] =OXAdBejwJQFHpfaEoritLSyYvKbPxG
     OXAdBejwJQFHpfaEoritLSyYvKbPDu['studio'] =OXAdBejwJQFHpfaEoritLSyYvKbPDk[OXAdBejwJQFHpfaEoritLSyYvKbPxu]['channel']['name']['ko']
     if 'frequency' in OXAdBejwJQFHpfaEoritLSyYvKbPDk[OXAdBejwJQFHpfaEoritLSyYvKbPxu]['episode']:OXAdBejwJQFHpfaEoritLSyYvKbPDu['episode']=OXAdBejwJQFHpfaEoritLSyYvKbPDk[OXAdBejwJQFHpfaEoritLSyYvKbPxu]['episode']['frequency']
    except:
     OXAdBejwJQFHpfaEoritLSyYvKbPxm
    OXAdBejwJQFHpfaEoritLSyYvKbPDT={'episode':OXAdBejwJQFHpfaEoritLSyYvKbPxC,'title':OXAdBejwJQFHpfaEoritLSyYvKbPDs,'subtitle':OXAdBejwJQFHpfaEoritLSyYvKbPxG,'thumbnail':OXAdBejwJQFHpfaEoritLSyYvKbPDW,'synopsis':OXAdBejwJQFHpfaEoritLSyYvKbPDh,'info':OXAdBejwJQFHpfaEoritLSyYvKbPDu}
    OXAdBejwJQFHpfaEoritLSyYvKbPDz.append(OXAdBejwJQFHpfaEoritLSyYvKbPDT)
   if OXAdBejwJQFHpfaEoritLSyYvKbPxI>page_int:OXAdBejwJQFHpfaEoritLSyYvKbPDx=OXAdBejwJQFHpfaEoritLSyYvKbPIz
  except OXAdBejwJQFHpfaEoritLSyYvKbPID as exception:
   OXAdBejwJQFHpfaEoritLSyYvKbPIx(exception)
  return OXAdBejwJQFHpfaEoritLSyYvKbPDz,OXAdBejwJQFHpfaEoritLSyYvKbPDx,OXAdBejwJQFHpfaEoritLSyYvKbPxI
 def GetMovieList(OXAdBejwJQFHpfaEoritLSyYvKbPMI,orderby,page_int,premiumyn=OXAdBejwJQFHpfaEoritLSyYvKbPxg,landyn=OXAdBejwJQFHpfaEoritLSyYvKbPxg):
  OXAdBejwJQFHpfaEoritLSyYvKbPDz=[]
  OXAdBejwJQFHpfaEoritLSyYvKbPDx=OXAdBejwJQFHpfaEoritLSyYvKbPxg
  if premiumyn==OXAdBejwJQFHpfaEoritLSyYvKbPIz:
   OXAdBejwJQFHpfaEoritLSyYvKbPxl=OXAdBejwJQFHpfaEoritLSyYvKbPMI.MOVIE_LITE+','+OXAdBejwJQFHpfaEoritLSyYvKbPMI.MOVIE_PREMIUM
  else:
   OXAdBejwJQFHpfaEoritLSyYvKbPxl=OXAdBejwJQFHpfaEoritLSyYvKbPMI.MOVIE_LITE
  try:
   OXAdBejwJQFHpfaEoritLSyYvKbPzu ='/v2/media/movies'
   OXAdBejwJQFHpfaEoritLSyYvKbPzC=OXAdBejwJQFHpfaEoritLSyYvKbPMI.GetDefaultParams()
   OXAdBejwJQFHpfaEoritLSyYvKbPzG={'pageNo':OXAdBejwJQFHpfaEoritLSyYvKbPIk(page_int),'pageSize':OXAdBejwJQFHpfaEoritLSyYvKbPIk(OXAdBejwJQFHpfaEoritLSyYvKbPMI.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','productPackageCode':OXAdBejwJQFHpfaEoritLSyYvKbPxl,'_':OXAdBejwJQFHpfaEoritLSyYvKbPIk(OXAdBejwJQFHpfaEoritLSyYvKbPMI.GetNoCache(2))}
   OXAdBejwJQFHpfaEoritLSyYvKbPzC.update(OXAdBejwJQFHpfaEoritLSyYvKbPzG)
   OXAdBejwJQFHpfaEoritLSyYvKbPMn=OXAdBejwJQFHpfaEoritLSyYvKbPMI.makeurl(OXAdBejwJQFHpfaEoritLSyYvKbPMI.API_DOMAIN,OXAdBejwJQFHpfaEoritLSyYvKbPzu)
   OXAdBejwJQFHpfaEoritLSyYvKbPMC=OXAdBejwJQFHpfaEoritLSyYvKbPMI.makeDefaultCookies()
   OXAdBejwJQFHpfaEoritLSyYvKbPMm=OXAdBejwJQFHpfaEoritLSyYvKbPMI.callRequestCookies('Get',OXAdBejwJQFHpfaEoritLSyYvKbPMn,payload=OXAdBejwJQFHpfaEoritLSyYvKbPxm,params=OXAdBejwJQFHpfaEoritLSyYvKbPzC,headers=OXAdBejwJQFHpfaEoritLSyYvKbPxm,cookies=OXAdBejwJQFHpfaEoritLSyYvKbPMC)
   OXAdBejwJQFHpfaEoritLSyYvKbPzl=json.loads(OXAdBejwJQFHpfaEoritLSyYvKbPMm.text)
   if not('result' in OXAdBejwJQFHpfaEoritLSyYvKbPzl['body']):return OXAdBejwJQFHpfaEoritLSyYvKbPDz,OXAdBejwJQFHpfaEoritLSyYvKbPDx
   OXAdBejwJQFHpfaEoritLSyYvKbPDk=OXAdBejwJQFHpfaEoritLSyYvKbPzl['body']['result']
   for OXAdBejwJQFHpfaEoritLSyYvKbPzn in OXAdBejwJQFHpfaEoritLSyYvKbPDk:
    OXAdBejwJQFHpfaEoritLSyYvKbPxs =OXAdBejwJQFHpfaEoritLSyYvKbPzn['movie']['code']
    OXAdBejwJQFHpfaEoritLSyYvKbPDs =OXAdBejwJQFHpfaEoritLSyYvKbPzn['movie']['name']['ko'].strip()
    OXAdBejwJQFHpfaEoritLSyYvKbPDs +=u' (%s년)'%(OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('movie').get('product_year'))
    OXAdBejwJQFHpfaEoritLSyYvKbPDW =OXAdBejwJQFHpfaEoritLSyYvKbPMI.IMG_DOMAIN+OXAdBejwJQFHpfaEoritLSyYvKbPzn['movie']['image'][0]['url']
    OXAdBejwJQFHpfaEoritLSyYvKbPDc='CAIM0400' if landyn else 'CAIM2100' 
    for OXAdBejwJQFHpfaEoritLSyYvKbPDN in OXAdBejwJQFHpfaEoritLSyYvKbPzn['movie']['image']:
     if OXAdBejwJQFHpfaEoritLSyYvKbPDN['code']==OXAdBejwJQFHpfaEoritLSyYvKbPDc:
      OXAdBejwJQFHpfaEoritLSyYvKbPDW =OXAdBejwJQFHpfaEoritLSyYvKbPMI.IMG_DOMAIN+OXAdBejwJQFHpfaEoritLSyYvKbPDN['url']
      break
    OXAdBejwJQFHpfaEoritLSyYvKbPDh =OXAdBejwJQFHpfaEoritLSyYvKbPzn['movie']['story']['ko']
    OXAdBejwJQFHpfaEoritLSyYvKbPDu={}
    OXAdBejwJQFHpfaEoritLSyYvKbPDu['mediatype']='movie' 
    OXAdBejwJQFHpfaEoritLSyYvKbPDu['title'] = OXAdBejwJQFHpfaEoritLSyYvKbPzn['movie']['name']['ko'].strip()
    OXAdBejwJQFHpfaEoritLSyYvKbPDu['year'] =OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('movie').get('product_year')
    try:
     OXAdBejwJQFHpfaEoritLSyYvKbPDn=[]
     for OXAdBejwJQFHpfaEoritLSyYvKbPDV in OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('movie').get('actor'):OXAdBejwJQFHpfaEoritLSyYvKbPDn.append(OXAdBejwJQFHpfaEoritLSyYvKbPDV)
     if OXAdBejwJQFHpfaEoritLSyYvKbPDn[0]!='':OXAdBejwJQFHpfaEoritLSyYvKbPDu['cast']=OXAdBejwJQFHpfaEoritLSyYvKbPDn
    except:
     OXAdBejwJQFHpfaEoritLSyYvKbPxm
    try:
     OXAdBejwJQFHpfaEoritLSyYvKbPDg=[]
     for OXAdBejwJQFHpfaEoritLSyYvKbPxM in OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('movie').get('director'):OXAdBejwJQFHpfaEoritLSyYvKbPDg.append(OXAdBejwJQFHpfaEoritLSyYvKbPxM)
     if OXAdBejwJQFHpfaEoritLSyYvKbPDg[0]!='':OXAdBejwJQFHpfaEoritLSyYvKbPDu['director']=OXAdBejwJQFHpfaEoritLSyYvKbPDg
    except:
     OXAdBejwJQFHpfaEoritLSyYvKbPxm
    try:
     OXAdBejwJQFHpfaEoritLSyYvKbPDU=[]
     if OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('movie').get('category1_name').get('ko')!='':
      OXAdBejwJQFHpfaEoritLSyYvKbPDU.append(OXAdBejwJQFHpfaEoritLSyYvKbPzn['movie']['category1_name']['ko'])
     if OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('movie').get('category2_name').get('ko')!='':
      OXAdBejwJQFHpfaEoritLSyYvKbPDU.append(OXAdBejwJQFHpfaEoritLSyYvKbPzn['movie']['category2_name']['ko'])
     if OXAdBejwJQFHpfaEoritLSyYvKbPDU[0]!='':OXAdBejwJQFHpfaEoritLSyYvKbPDu['genre']=OXAdBejwJQFHpfaEoritLSyYvKbPDU
    except:
     OXAdBejwJQFHpfaEoritLSyYvKbPxm
    try:
     if 'release_date' in OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('movie'):
      OXAdBejwJQFHpfaEoritLSyYvKbPxz=OXAdBejwJQFHpfaEoritLSyYvKbPIk(OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('movie').get('release_date'))
      OXAdBejwJQFHpfaEoritLSyYvKbPDu['aired']='%s-%s-%s'%(OXAdBejwJQFHpfaEoritLSyYvKbPxz[:4],OXAdBejwJQFHpfaEoritLSyYvKbPxz[4:6],OXAdBejwJQFHpfaEoritLSyYvKbPxz[6:])
    except:
     OXAdBejwJQFHpfaEoritLSyYvKbPxm
    try:
     if 'duration' in OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('movie'):OXAdBejwJQFHpfaEoritLSyYvKbPDu['duration']=OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('movie').get('duration')
    except:
     OXAdBejwJQFHpfaEoritLSyYvKbPxm
    OXAdBejwJQFHpfaEoritLSyYvKbPDT={'moviecode':OXAdBejwJQFHpfaEoritLSyYvKbPxs,'title':OXAdBejwJQFHpfaEoritLSyYvKbPDs,'thumbnail':OXAdBejwJQFHpfaEoritLSyYvKbPDW,'synopsis':OXAdBejwJQFHpfaEoritLSyYvKbPDh,'info':OXAdBejwJQFHpfaEoritLSyYvKbPDu}
    if premiumyn==OXAdBejwJQFHpfaEoritLSyYvKbPIz:
     OXAdBejwJQFHpfaEoritLSyYvKbPxW=OXAdBejwJQFHpfaEoritLSyYvKbPxg
     for OXAdBejwJQFHpfaEoritLSyYvKbPxh in OXAdBejwJQFHpfaEoritLSyYvKbPzn['billing_package_id']:
      if OXAdBejwJQFHpfaEoritLSyYvKbPxh==OXAdBejwJQFHpfaEoritLSyYvKbPMI.MOVIE_LITE:
       OXAdBejwJQFHpfaEoritLSyYvKbPxW=OXAdBejwJQFHpfaEoritLSyYvKbPIz
       break
     if OXAdBejwJQFHpfaEoritLSyYvKbPxW==OXAdBejwJQFHpfaEoritLSyYvKbPxg:
      OXAdBejwJQFHpfaEoritLSyYvKbPDT['title']=OXAdBejwJQFHpfaEoritLSyYvKbPDT['title']+' [Premium]'
    OXAdBejwJQFHpfaEoritLSyYvKbPDz.append(OXAdBejwJQFHpfaEoritLSyYvKbPDT)
   if OXAdBejwJQFHpfaEoritLSyYvKbPzl['body']['has_more']=='Y':OXAdBejwJQFHpfaEoritLSyYvKbPDx=OXAdBejwJQFHpfaEoritLSyYvKbPIz
  except OXAdBejwJQFHpfaEoritLSyYvKbPID as exception:
   OXAdBejwJQFHpfaEoritLSyYvKbPIx(exception)
  return OXAdBejwJQFHpfaEoritLSyYvKbPDz,OXAdBejwJQFHpfaEoritLSyYvKbPDx
 def GetMovieListGenre(OXAdBejwJQFHpfaEoritLSyYvKbPMI,genre,page_int,premiumyn=OXAdBejwJQFHpfaEoritLSyYvKbPxg):
  OXAdBejwJQFHpfaEoritLSyYvKbPDz=[]
  OXAdBejwJQFHpfaEoritLSyYvKbPDx=OXAdBejwJQFHpfaEoritLSyYvKbPxg
  if premiumyn==OXAdBejwJQFHpfaEoritLSyYvKbPIz:
   OXAdBejwJQFHpfaEoritLSyYvKbPxl=OXAdBejwJQFHpfaEoritLSyYvKbPMI.MOVIE_LITE+','+OXAdBejwJQFHpfaEoritLSyYvKbPMI.MOVIE_PREMIUM
  else:
   OXAdBejwJQFHpfaEoritLSyYvKbPxl=OXAdBejwJQFHpfaEoritLSyYvKbPMI.MOVIE_LITE
  try:
   OXAdBejwJQFHpfaEoritLSyYvKbPzu ='/v2/media/movie/curation/'+genre
   OXAdBejwJQFHpfaEoritLSyYvKbPzC=OXAdBejwJQFHpfaEoritLSyYvKbPMI.GetDefaultParams()
   OXAdBejwJQFHpfaEoritLSyYvKbPzG={'pageNo':OXAdBejwJQFHpfaEoritLSyYvKbPIk(page_int),'pageSize':OXAdBejwJQFHpfaEoritLSyYvKbPIk(OXAdBejwJQFHpfaEoritLSyYvKbPMI.MOVIE_LIMIT),'productPackageCode':OXAdBejwJQFHpfaEoritLSyYvKbPxl,'_':OXAdBejwJQFHpfaEoritLSyYvKbPIk(OXAdBejwJQFHpfaEoritLSyYvKbPMI.GetNoCache(2))}
   OXAdBejwJQFHpfaEoritLSyYvKbPzC.update(OXAdBejwJQFHpfaEoritLSyYvKbPzG)
   OXAdBejwJQFHpfaEoritLSyYvKbPMn=OXAdBejwJQFHpfaEoritLSyYvKbPMI.makeurl(OXAdBejwJQFHpfaEoritLSyYvKbPMI.API_DOMAIN,OXAdBejwJQFHpfaEoritLSyYvKbPzu)
   OXAdBejwJQFHpfaEoritLSyYvKbPMC=OXAdBejwJQFHpfaEoritLSyYvKbPMI.makeDefaultCookies()
   OXAdBejwJQFHpfaEoritLSyYvKbPMm=OXAdBejwJQFHpfaEoritLSyYvKbPMI.callRequestCookies('Get',OXAdBejwJQFHpfaEoritLSyYvKbPMn,payload=OXAdBejwJQFHpfaEoritLSyYvKbPxm,params=OXAdBejwJQFHpfaEoritLSyYvKbPzC,headers=OXAdBejwJQFHpfaEoritLSyYvKbPxm,cookies=OXAdBejwJQFHpfaEoritLSyYvKbPMC)
   OXAdBejwJQFHpfaEoritLSyYvKbPzl=json.loads(OXAdBejwJQFHpfaEoritLSyYvKbPMm.text)
   if not('movies' in OXAdBejwJQFHpfaEoritLSyYvKbPzl['body']):return OXAdBejwJQFHpfaEoritLSyYvKbPDz,OXAdBejwJQFHpfaEoritLSyYvKbPDx
   OXAdBejwJQFHpfaEoritLSyYvKbPDk=OXAdBejwJQFHpfaEoritLSyYvKbPzl['body']['movies']
   for OXAdBejwJQFHpfaEoritLSyYvKbPzn in OXAdBejwJQFHpfaEoritLSyYvKbPDk:
    OXAdBejwJQFHpfaEoritLSyYvKbPxs =OXAdBejwJQFHpfaEoritLSyYvKbPzn['code']
    OXAdBejwJQFHpfaEoritLSyYvKbPDs =OXAdBejwJQFHpfaEoritLSyYvKbPzn['name']['ko']
    OXAdBejwJQFHpfaEoritLSyYvKbPDW =OXAdBejwJQFHpfaEoritLSyYvKbPMI.IMG_DOMAIN+OXAdBejwJQFHpfaEoritLSyYvKbPzn['image'][0]['url']
    for OXAdBejwJQFHpfaEoritLSyYvKbPDN in OXAdBejwJQFHpfaEoritLSyYvKbPzn['image']:
     if OXAdBejwJQFHpfaEoritLSyYvKbPDN['code']=='CAIM2100':
      OXAdBejwJQFHpfaEoritLSyYvKbPDW =OXAdBejwJQFHpfaEoritLSyYvKbPMI.IMG_DOMAIN+OXAdBejwJQFHpfaEoritLSyYvKbPDN['url']
    OXAdBejwJQFHpfaEoritLSyYvKbPDh =OXAdBejwJQFHpfaEoritLSyYvKbPzn['story']['ko']
    OXAdBejwJQFHpfaEoritLSyYvKbPDT={'moviecode':OXAdBejwJQFHpfaEoritLSyYvKbPxs,'title':OXAdBejwJQFHpfaEoritLSyYvKbPDs.strip(),'thumbnail':OXAdBejwJQFHpfaEoritLSyYvKbPDW,'synopsis':OXAdBejwJQFHpfaEoritLSyYvKbPDh}
    if premiumyn==OXAdBejwJQFHpfaEoritLSyYvKbPIz:
     OXAdBejwJQFHpfaEoritLSyYvKbPxW=OXAdBejwJQFHpfaEoritLSyYvKbPxg
     for OXAdBejwJQFHpfaEoritLSyYvKbPxh in OXAdBejwJQFHpfaEoritLSyYvKbPzn['billing_package_id']:
      if OXAdBejwJQFHpfaEoritLSyYvKbPxh==OXAdBejwJQFHpfaEoritLSyYvKbPMI.MOVIE_LITE:
       OXAdBejwJQFHpfaEoritLSyYvKbPxW=OXAdBejwJQFHpfaEoritLSyYvKbPIz
       break
     if OXAdBejwJQFHpfaEoritLSyYvKbPxW==OXAdBejwJQFHpfaEoritLSyYvKbPxg:
      OXAdBejwJQFHpfaEoritLSyYvKbPDT['title']=OXAdBejwJQFHpfaEoritLSyYvKbPDT['title']+' [Premium]'
    OXAdBejwJQFHpfaEoritLSyYvKbPDz.append(OXAdBejwJQFHpfaEoritLSyYvKbPDT)
  except OXAdBejwJQFHpfaEoritLSyYvKbPID as exception:
   OXAdBejwJQFHpfaEoritLSyYvKbPIx(exception)
  return OXAdBejwJQFHpfaEoritLSyYvKbPDz,OXAdBejwJQFHpfaEoritLSyYvKbPDx
 def GetMovieGenre(OXAdBejwJQFHpfaEoritLSyYvKbPMI):
  OXAdBejwJQFHpfaEoritLSyYvKbPDz=[]
  OXAdBejwJQFHpfaEoritLSyYvKbPDx=OXAdBejwJQFHpfaEoritLSyYvKbPxg
  try:
   OXAdBejwJQFHpfaEoritLSyYvKbPzu ='/v2/media/movie/curations'
   OXAdBejwJQFHpfaEoritLSyYvKbPzC=OXAdBejwJQFHpfaEoritLSyYvKbPMI.GetDefaultParams()
   OXAdBejwJQFHpfaEoritLSyYvKbPzG={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code','_':OXAdBejwJQFHpfaEoritLSyYvKbPIk(OXAdBejwJQFHpfaEoritLSyYvKbPMI.GetNoCache(2))}
   OXAdBejwJQFHpfaEoritLSyYvKbPzC.update(OXAdBejwJQFHpfaEoritLSyYvKbPzG)
   OXAdBejwJQFHpfaEoritLSyYvKbPMn=OXAdBejwJQFHpfaEoritLSyYvKbPMI.makeurl(OXAdBejwJQFHpfaEoritLSyYvKbPMI.API_DOMAIN,OXAdBejwJQFHpfaEoritLSyYvKbPzu)
   OXAdBejwJQFHpfaEoritLSyYvKbPMC=OXAdBejwJQFHpfaEoritLSyYvKbPMI.makeDefaultCookies()
   OXAdBejwJQFHpfaEoritLSyYvKbPMm=OXAdBejwJQFHpfaEoritLSyYvKbPMI.callRequestCookies('Get',OXAdBejwJQFHpfaEoritLSyYvKbPMn,payload=OXAdBejwJQFHpfaEoritLSyYvKbPxm,params=OXAdBejwJQFHpfaEoritLSyYvKbPzC,headers=OXAdBejwJQFHpfaEoritLSyYvKbPxm,cookies=OXAdBejwJQFHpfaEoritLSyYvKbPMC)
   OXAdBejwJQFHpfaEoritLSyYvKbPzl=json.loads(OXAdBejwJQFHpfaEoritLSyYvKbPMm.text)
   if not('result' in OXAdBejwJQFHpfaEoritLSyYvKbPzl['body']):return OXAdBejwJQFHpfaEoritLSyYvKbPDz,OXAdBejwJQFHpfaEoritLSyYvKbPDx
   OXAdBejwJQFHpfaEoritLSyYvKbPDk=OXAdBejwJQFHpfaEoritLSyYvKbPzl['body']['result']
   for OXAdBejwJQFHpfaEoritLSyYvKbPzn in OXAdBejwJQFHpfaEoritLSyYvKbPDk:
    OXAdBejwJQFHpfaEoritLSyYvKbPxn =OXAdBejwJQFHpfaEoritLSyYvKbPzn['curation_code']
    OXAdBejwJQFHpfaEoritLSyYvKbPxV =OXAdBejwJQFHpfaEoritLSyYvKbPzn['curation_name']
    OXAdBejwJQFHpfaEoritLSyYvKbPDT={'curation_code':OXAdBejwJQFHpfaEoritLSyYvKbPxn,'curation_name':OXAdBejwJQFHpfaEoritLSyYvKbPxV}
    OXAdBejwJQFHpfaEoritLSyYvKbPDz.append(OXAdBejwJQFHpfaEoritLSyYvKbPDT)
  except OXAdBejwJQFHpfaEoritLSyYvKbPID as exception:
   OXAdBejwJQFHpfaEoritLSyYvKbPIx(exception)
  return OXAdBejwJQFHpfaEoritLSyYvKbPDz,OXAdBejwJQFHpfaEoritLSyYvKbPDx
 def GetSearchList(OXAdBejwJQFHpfaEoritLSyYvKbPMI,search_key,userid,page_int,stype,premiumyn=OXAdBejwJQFHpfaEoritLSyYvKbPxg,landyn=OXAdBejwJQFHpfaEoritLSyYvKbPxg):
  OXAdBejwJQFHpfaEoritLSyYvKbPxU=[]
  OXAdBejwJQFHpfaEoritLSyYvKbPDx=OXAdBejwJQFHpfaEoritLSyYvKbPxg
  try:
   OXAdBejwJQFHpfaEoritLSyYvKbPzu ='/search/getSearch.jsp'
   OXAdBejwJQFHpfaEoritLSyYvKbPzG={'kwd':search_key,'notFoundText':search_key,'userid':userid,'siteName':'TVING_WEB','category':'TOTAL','pageNum':OXAdBejwJQFHpfaEoritLSyYvKbPIk(page_int),'pageSize':OXAdBejwJQFHpfaEoritLSyYvKbPIk(OXAdBejwJQFHpfaEoritLSyYvKbPMI.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':OXAdBejwJQFHpfaEoritLSyYvKbPMI.SCREENCODE,'os':OXAdBejwJQFHpfaEoritLSyYvKbPMI.OSCODE,'network':OXAdBejwJQFHpfaEoritLSyYvKbPMI.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':OXAdBejwJQFHpfaEoritLSyYvKbPIk(OXAdBejwJQFHpfaEoritLSyYvKbPMI.SEARCH_LIMIT),'vodMVReqCnt':OXAdBejwJQFHpfaEoritLSyYvKbPIk(OXAdBejwJQFHpfaEoritLSyYvKbPMI.SEARCH_LIMIT),'smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':OXAdBejwJQFHpfaEoritLSyYvKbPIk(OXAdBejwJQFHpfaEoritLSyYvKbPMI.GetNoCache(2))}
   OXAdBejwJQFHpfaEoritLSyYvKbPMn=OXAdBejwJQFHpfaEoritLSyYvKbPMI.makeurl(OXAdBejwJQFHpfaEoritLSyYvKbPMI.SEARCH_DOMAIN,OXAdBejwJQFHpfaEoritLSyYvKbPzu)
   OXAdBejwJQFHpfaEoritLSyYvKbPMC=OXAdBejwJQFHpfaEoritLSyYvKbPMI.makeDefaultCookies()
   OXAdBejwJQFHpfaEoritLSyYvKbPMm=OXAdBejwJQFHpfaEoritLSyYvKbPMI.callRequestCookies('Get',OXAdBejwJQFHpfaEoritLSyYvKbPMn,payload=OXAdBejwJQFHpfaEoritLSyYvKbPxm,params=OXAdBejwJQFHpfaEoritLSyYvKbPzG,headers=OXAdBejwJQFHpfaEoritLSyYvKbPxm,cookies=OXAdBejwJQFHpfaEoritLSyYvKbPMC)
   OXAdBejwJQFHpfaEoritLSyYvKbPzl=json.loads(OXAdBejwJQFHpfaEoritLSyYvKbPMm.text)
   if stype=='vod':
    if not('programRsb' in OXAdBejwJQFHpfaEoritLSyYvKbPzl):return OXAdBejwJQFHpfaEoritLSyYvKbPxU,OXAdBejwJQFHpfaEoritLSyYvKbPDx
    OXAdBejwJQFHpfaEoritLSyYvKbPxR=OXAdBejwJQFHpfaEoritLSyYvKbPzl['programRsb']['dataList']
    OXAdBejwJQFHpfaEoritLSyYvKbPxT =OXAdBejwJQFHpfaEoritLSyYvKbPIM(OXAdBejwJQFHpfaEoritLSyYvKbPzl['programRsb']['count'])
    for OXAdBejwJQFHpfaEoritLSyYvKbPzn in OXAdBejwJQFHpfaEoritLSyYvKbPxR:
     OXAdBejwJQFHpfaEoritLSyYvKbPDq=OXAdBejwJQFHpfaEoritLSyYvKbPzn['mast_cd']
     OXAdBejwJQFHpfaEoritLSyYvKbPDs =OXAdBejwJQFHpfaEoritLSyYvKbPzn['mast_nm']
     OXAdBejwJQFHpfaEoritLSyYvKbPDW =OXAdBejwJQFHpfaEoritLSyYvKbPMI.IMG_DOMAIN+OXAdBejwJQFHpfaEoritLSyYvKbPzn['web_url']
     if landyn==OXAdBejwJQFHpfaEoritLSyYvKbPxg:
      OXAdBejwJQFHpfaEoritLSyYvKbPDW =OXAdBejwJQFHpfaEoritLSyYvKbPMI.IMG_DOMAIN+OXAdBejwJQFHpfaEoritLSyYvKbPzn['web_url4']
     OXAdBejwJQFHpfaEoritLSyYvKbPDu={}
     OXAdBejwJQFHpfaEoritLSyYvKbPDu['title']=OXAdBejwJQFHpfaEoritLSyYvKbPzn['mast_nm']
     OXAdBejwJQFHpfaEoritLSyYvKbPDu['mediatype']='episode' 
     try:
      if OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('actor')!='' and OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('actor')!='-':OXAdBejwJQFHpfaEoritLSyYvKbPDu['cast'] =OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('actor').split(',')
      if OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('director')!='' and OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('director')!='-':OXAdBejwJQFHpfaEoritLSyYvKbPDu['director']=OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('director').split(',')
      if OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('cate_nm')!='':OXAdBejwJQFHpfaEoritLSyYvKbPDu['genre'] =OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('cate_nm').split('/')
      if 'targetage' in OXAdBejwJQFHpfaEoritLSyYvKbPzn:OXAdBejwJQFHpfaEoritLSyYvKbPDu['mpaa']=OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('targetage')
     except:
      OXAdBejwJQFHpfaEoritLSyYvKbPxm
     try:
      if 'broad_dt' in OXAdBejwJQFHpfaEoritLSyYvKbPzn:
       OXAdBejwJQFHpfaEoritLSyYvKbPxz=OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('broad_dt')
       OXAdBejwJQFHpfaEoritLSyYvKbPDu['aired']='%s-%s-%s'%(OXAdBejwJQFHpfaEoritLSyYvKbPxz[:4],OXAdBejwJQFHpfaEoritLSyYvKbPxz[4:6],OXAdBejwJQFHpfaEoritLSyYvKbPxz[6:])
     except:
      OXAdBejwJQFHpfaEoritLSyYvKbPxm
     OXAdBejwJQFHpfaEoritLSyYvKbPDT={'program':OXAdBejwJQFHpfaEoritLSyYvKbPDq,'title':OXAdBejwJQFHpfaEoritLSyYvKbPDs,'thumbnail':OXAdBejwJQFHpfaEoritLSyYvKbPDW,'synopsis':'','info':OXAdBejwJQFHpfaEoritLSyYvKbPDu}
     OXAdBejwJQFHpfaEoritLSyYvKbPxU.append(OXAdBejwJQFHpfaEoritLSyYvKbPDT)
   else:
    if not('vodMVRsb' in OXAdBejwJQFHpfaEoritLSyYvKbPzl):return OXAdBejwJQFHpfaEoritLSyYvKbPxU,OXAdBejwJQFHpfaEoritLSyYvKbPDx
    OXAdBejwJQFHpfaEoritLSyYvKbPxq=OXAdBejwJQFHpfaEoritLSyYvKbPzl['vodMVRsb']['dataList']
    OXAdBejwJQFHpfaEoritLSyYvKbPxT =OXAdBejwJQFHpfaEoritLSyYvKbPIM(OXAdBejwJQFHpfaEoritLSyYvKbPzl['vodMVRsb']['count'])
    for OXAdBejwJQFHpfaEoritLSyYvKbPzn in OXAdBejwJQFHpfaEoritLSyYvKbPxq:
     OXAdBejwJQFHpfaEoritLSyYvKbPDq=OXAdBejwJQFHpfaEoritLSyYvKbPzn['mast_cd']
     OXAdBejwJQFHpfaEoritLSyYvKbPDs =OXAdBejwJQFHpfaEoritLSyYvKbPzn['mast_nm'].strip()
     OXAdBejwJQFHpfaEoritLSyYvKbPDW =OXAdBejwJQFHpfaEoritLSyYvKbPMI.IMG_DOMAIN+OXAdBejwJQFHpfaEoritLSyYvKbPzn['web_url']
     if landyn==OXAdBejwJQFHpfaEoritLSyYvKbPxg:
      OXAdBejwJQFHpfaEoritLSyYvKbPDW =OXAdBejwJQFHpfaEoritLSyYvKbPMI.IMG_DOMAIN+OXAdBejwJQFHpfaEoritLSyYvKbPzn['web_url5']
     OXAdBejwJQFHpfaEoritLSyYvKbPDu={}
     OXAdBejwJQFHpfaEoritLSyYvKbPDu['title'] =OXAdBejwJQFHpfaEoritLSyYvKbPDs
     OXAdBejwJQFHpfaEoritLSyYvKbPDu['mediatype']='movie' 
     try:
      if OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('actor') !='':OXAdBejwJQFHpfaEoritLSyYvKbPDu['cast'] =OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('actor').split(',')
      if OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('cate_nm')!='':OXAdBejwJQFHpfaEoritLSyYvKbPDu['genre'] =OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('cate_nm').split('/')
      if OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('runtime_sec')!='':OXAdBejwJQFHpfaEoritLSyYvKbPDu['duration']=OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('runtime_sec')
      if 'grade_nm' in OXAdBejwJQFHpfaEoritLSyYvKbPzn:OXAdBejwJQFHpfaEoritLSyYvKbPDu['mpaa']=OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('grade_nm')
     except:
      OXAdBejwJQFHpfaEoritLSyYvKbPxm
     try:
      OXAdBejwJQFHpfaEoritLSyYvKbPxz=OXAdBejwJQFHpfaEoritLSyYvKbPzn.get('broad_dt')
      if data_str!='':
       OXAdBejwJQFHpfaEoritLSyYvKbPDu['aired']='%s-%s-%s'%(OXAdBejwJQFHpfaEoritLSyYvKbPxz[:4],OXAdBejwJQFHpfaEoritLSyYvKbPxz[4:6],OXAdBejwJQFHpfaEoritLSyYvKbPxz[6:])
       OXAdBejwJQFHpfaEoritLSyYvKbPDu['year']=OXAdBejwJQFHpfaEoritLSyYvKbPxz[:4]
     except:
      OXAdBejwJQFHpfaEoritLSyYvKbPxm
     if OXAdBejwJQFHpfaEoritLSyYvKbPIz:
      OXAdBejwJQFHpfaEoritLSyYvKbPDT={'movie':OXAdBejwJQFHpfaEoritLSyYvKbPDq,'title':OXAdBejwJQFHpfaEoritLSyYvKbPDs,'thumbnail':OXAdBejwJQFHpfaEoritLSyYvKbPDW,'synopsis':'','info':OXAdBejwJQFHpfaEoritLSyYvKbPDu}
      OXAdBejwJQFHpfaEoritLSyYvKbPxU.append(OXAdBejwJQFHpfaEoritLSyYvKbPDT)
  except OXAdBejwJQFHpfaEoritLSyYvKbPID as exception:
   OXAdBejwJQFHpfaEoritLSyYvKbPIx(exception)
  return OXAdBejwJQFHpfaEoritLSyYvKbPxU,OXAdBejwJQFHpfaEoritLSyYvKbPDx
 def GetDeviceList(OXAdBejwJQFHpfaEoritLSyYvKbPMI,OXAdBejwJQFHpfaEoritLSyYvKbPMT,OXAdBejwJQFHpfaEoritLSyYvKbPzM):
  OXAdBejwJQFHpfaEoritLSyYvKbPDz=[]
  OXAdBejwJQFHpfaEoritLSyYvKbPzk='-'
  try:
   OXAdBejwJQFHpfaEoritLSyYvKbPzu ='/v1/user/device/list'
   OXAdBejwJQFHpfaEoritLSyYvKbPxc=OXAdBejwJQFHpfaEoritLSyYvKbPMI.makeurl(OXAdBejwJQFHpfaEoritLSyYvKbPMI.API_DOMAIN,OXAdBejwJQFHpfaEoritLSyYvKbPzu)
   OXAdBejwJQFHpfaEoritLSyYvKbPzG={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   OXAdBejwJQFHpfaEoritLSyYvKbPMC=OXAdBejwJQFHpfaEoritLSyYvKbPMI.makeDefaultCookies(vToken=OXAdBejwJQFHpfaEoritLSyYvKbPMT,vUserinfo=OXAdBejwJQFHpfaEoritLSyYvKbPzM)
   OXAdBejwJQFHpfaEoritLSyYvKbPMm=OXAdBejwJQFHpfaEoritLSyYvKbPMI.callRequestCookies('Get',OXAdBejwJQFHpfaEoritLSyYvKbPxc,payload=OXAdBejwJQFHpfaEoritLSyYvKbPxm,params=OXAdBejwJQFHpfaEoritLSyYvKbPzG,headers=OXAdBejwJQFHpfaEoritLSyYvKbPxm,cookies=OXAdBejwJQFHpfaEoritLSyYvKbPMC)
   OXAdBejwJQFHpfaEoritLSyYvKbPzl=json.loads(OXAdBejwJQFHpfaEoritLSyYvKbPMm.text)
   OXAdBejwJQFHpfaEoritLSyYvKbPDz=OXAdBejwJQFHpfaEoritLSyYvKbPzl['body']
   for OXAdBejwJQFHpfaEoritLSyYvKbPzn in OXAdBejwJQFHpfaEoritLSyYvKbPDz:
    if OXAdBejwJQFHpfaEoritLSyYvKbPzn['model']=='PC':
     OXAdBejwJQFHpfaEoritLSyYvKbPzk=OXAdBejwJQFHpfaEoritLSyYvKbPzn['uuid']
  except OXAdBejwJQFHpfaEoritLSyYvKbPID as exception:
   OXAdBejwJQFHpfaEoritLSyYvKbPIx(exception)
  return OXAdBejwJQFHpfaEoritLSyYvKbPzk
# Created by pyminifier (https://github.com/liftoff/pyminifier)
