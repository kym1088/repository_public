__author__="NightRain"
eFvBQHLJAGtjwmKIPVRSDMoxpCuiqb=object
eFvBQHLJAGtjwmKIPVRSDMoxpCuiql=None
eFvBQHLJAGtjwmKIPVRSDMoxpCuiqE=False
eFvBQHLJAGtjwmKIPVRSDMoxpCuidk=True
eFvBQHLJAGtjwmKIPVRSDMoxpCuidy=int
eFvBQHLJAGtjwmKIPVRSDMoxpCuidU=len
eFvBQHLJAGtjwmKIPVRSDMoxpCuidr=str
eFvBQHLJAGtjwmKIPVRSDMoxpCuidq=open
eFvBQHLJAGtjwmKIPVRSDMoxpCuidO=dict
eFvBQHLJAGtjwmKIPVRSDMoxpCuidN=Exception
eFvBQHLJAGtjwmKIPVRSDMoxpCuidg=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmc.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
eFvBQHLJAGtjwmKIPVRSDMoxpCuikU=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-'},{'title':'VOD 방송 (인기순)','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 (최신순)','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'월정액 영화관 (인기)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewWeek','ordernm':'-'},{'title':'월정액 영화관 (최신)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'검색 (search)','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-'}]
eFvBQHLJAGtjwmKIPVRSDMoxpCuikr=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
eFvBQHLJAGtjwmKIPVRSDMoxpCuikq=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
eFvBQHLJAGtjwmKIPVRSDMoxpCuikd=[{'title':'VOD 검색','mode':'SEARCH','stype':'vod'},{'title':'영화 검색','mode':'SEARCH','stype':'movie'}]
eFvBQHLJAGtjwmKIPVRSDMoxpCuikO=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'PROGRAM','stype':'PCPOS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'키즈/애니','mode':'PROGRAM','stype':'PCC,PCAN'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'뮤직','mode':'PROGRAM','stype':'PCG'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'}]
eFvBQHLJAGtjwmKIPVRSDMoxpCuikN={'C00551':'tvN','C00544':'중화TV','C00575':'Olive','C00579':'Mnet','C00590':'OGN','C01141':'XtvN','C01142':'ONSTYLE','C01143':'OtvN','C04601':'CGV','C06941':'tooniverse','C07381':'OCN','C07382':'SUPER ACTION','C15251':'OGN x LOL','C15252':'OGN x 오버워치','C15042':'티빙라이브','C01581':'TV CHOSUN','C01583':'채널A','C00708':'MBN','C00593':'YTN','C01101':'YTN Life','C15347':'YTN science','C01723':'연합뉴스TV','C15152':'DIA TV','C01582':'JTBC','C00588':'JTBC Golf','C15741':'JTBC2','C00805':'JTBC3 FOX Sports','C05661':'디즈니채널','C18641':'IHQ','C22041':'JTBC4','C23343':'t.cast','C23441':'E channel','C17341':'히스토리','C00585':'TV CHOSUN2','C17141':'채널A 플러스','C00611':'LIFETIME','C08041':'tvN go','C05901':'채널W','C23442':"D'LIVE",'C27441':'KBS N'}
eFvBQHLJAGtjwmKIPVRSDMoxpCuikg ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'
eFvBQHLJAGtjwmKIPVRSDMoxpCuikz=xbmc.translatePath(os.path.join(__profile__,'tving_cookies.json'))
from tvingCore import*
class eFvBQHLJAGtjwmKIPVRSDMoxpCuiky(eFvBQHLJAGtjwmKIPVRSDMoxpCuiqb):
 def __init__(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf,eFvBQHLJAGtjwmKIPVRSDMoxpCuikh,eFvBQHLJAGtjwmKIPVRSDMoxpCuikX,eFvBQHLJAGtjwmKIPVRSDMoxpCuikY):
  eFvBQHLJAGtjwmKIPVRSDMoxpCuikf._addon_url =eFvBQHLJAGtjwmKIPVRSDMoxpCuikh
  eFvBQHLJAGtjwmKIPVRSDMoxpCuikf._addon_handle=eFvBQHLJAGtjwmKIPVRSDMoxpCuikX
  eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.main_params =eFvBQHLJAGtjwmKIPVRSDMoxpCuikY
  eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.TvingObj =OXAdBejwJQFHpfaEoritLSyYvKbPMz() 
 def addon_noti(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf,sting):
  try:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikW=xbmcgui.Dialog()
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikW.notification(__addonname__,sting)
  except:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiql
 def addon_log(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf,string,isDebug=eFvBQHLJAGtjwmKIPVRSDMoxpCuiqE):
  try:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuika=string.encode('utf-8','ignore')
  except:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuika='addonException: addon_log'
  if isDebug:eFvBQHLJAGtjwmKIPVRSDMoxpCuiks=xbmc.LOGDEBUG
  else:eFvBQHLJAGtjwmKIPVRSDMoxpCuiks=xbmc.LOGNOTICE
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,eFvBQHLJAGtjwmKIPVRSDMoxpCuika),level=eFvBQHLJAGtjwmKIPVRSDMoxpCuiks)
 def get_keyboard_input(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf,eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO):
  eFvBQHLJAGtjwmKIPVRSDMoxpCuikn=eFvBQHLJAGtjwmKIPVRSDMoxpCuiql
  kb=xbmc.Keyboard()
  kb.setHeading(eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikn=kb.getText()
  return eFvBQHLJAGtjwmKIPVRSDMoxpCuikn
 def get_settings_login_info(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf):
  eFvBQHLJAGtjwmKIPVRSDMoxpCuikc =__addon__.getSetting('id')
  eFvBQHLJAGtjwmKIPVRSDMoxpCuikb =__addon__.getSetting('pw')
  eFvBQHLJAGtjwmKIPVRSDMoxpCuikl =__addon__.getSetting('login_type')
  return(eFvBQHLJAGtjwmKIPVRSDMoxpCuikc,eFvBQHLJAGtjwmKIPVRSDMoxpCuikb,eFvBQHLJAGtjwmKIPVRSDMoxpCuikl)
 def get_settings_premiumyn(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf):
  eFvBQHLJAGtjwmKIPVRSDMoxpCuikE =__addon__.getSetting('premium_movieyn')
  if eFvBQHLJAGtjwmKIPVRSDMoxpCuikE=='false':
   return eFvBQHLJAGtjwmKIPVRSDMoxpCuiqE
  else:
   return eFvBQHLJAGtjwmKIPVRSDMoxpCuidk
 def get_settings_direct_replay(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf):
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyk=eFvBQHLJAGtjwmKIPVRSDMoxpCuidy(__addon__.getSetting('direct_replay'))
  if eFvBQHLJAGtjwmKIPVRSDMoxpCuiyk==0:
   return eFvBQHLJAGtjwmKIPVRSDMoxpCuiqE
  else:
   return eFvBQHLJAGtjwmKIPVRSDMoxpCuidk
 def get_settings_thumbnail_landyn(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf):
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyU =eFvBQHLJAGtjwmKIPVRSDMoxpCuidy(__addon__.getSetting('thumbnail_way'))
  if eFvBQHLJAGtjwmKIPVRSDMoxpCuiyU==0:
   return eFvBQHLJAGtjwmKIPVRSDMoxpCuidk
  else:
   return eFvBQHLJAGtjwmKIPVRSDMoxpCuiqE
 def set_winCredential(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf,credential):
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyr=xbmcgui.Window(10000)
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyr.setProperty('TVING_M_TOKEN',credential.get('tving_token'))
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyr.setProperty('TVING_M_USERINFO',credential.get('poc_userinfo'))
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyr.setProperty('TVING_M_UUID',credential.get('tving_uuid'))
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyr.setProperty('TVING_M_LOGINTIME',eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.TvingObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf):
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyr=xbmcgui.Window(10000)
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyq={'tving_token':eFvBQHLJAGtjwmKIPVRSDMoxpCuiyr.getProperty('TVING_M_TOKEN'),'poc_userinfo':eFvBQHLJAGtjwmKIPVRSDMoxpCuiyr.getProperty('TVING_M_USERINFO'),'tving_uuid':eFvBQHLJAGtjwmKIPVRSDMoxpCuiyr.getProperty('TVING_M_UUID')}
  return eFvBQHLJAGtjwmKIPVRSDMoxpCuiyq
 def set_winEpisodeOrderby(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf,eFvBQHLJAGtjwmKIPVRSDMoxpCuiUY):
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyr=xbmcgui.Window(10000)
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyr.setProperty('TVING_M_ORDERBY',eFvBQHLJAGtjwmKIPVRSDMoxpCuiUY)
 def get_winEpisodeOrderby(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf):
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyr=xbmcgui.Window(10000)
  return eFvBQHLJAGtjwmKIPVRSDMoxpCuiyr.getProperty('TVING_M_ORDERBY')
 def add_dir(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf,label,sublabel='',img='',infoLabels=eFvBQHLJAGtjwmKIPVRSDMoxpCuiql,isFolder=eFvBQHLJAGtjwmKIPVRSDMoxpCuidk,params=''):
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyd='%s?%s'%(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf._addon_url,urllib.parse.urlencode(params))
  if sublabel:eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO='%s < %s >'%(label,sublabel)
  else: eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO=label
  if not img:img='DefaultFolder.png'
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyN=xbmcgui.ListItem(eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO)
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyN.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:eFvBQHLJAGtjwmKIPVRSDMoxpCuiyN.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:eFvBQHLJAGtjwmKIPVRSDMoxpCuiyN.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf._addon_handle,eFvBQHLJAGtjwmKIPVRSDMoxpCuiyd,eFvBQHLJAGtjwmKIPVRSDMoxpCuiyN,isFolder)
 def get_selQuality(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf,etype):
  try:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyg='selected_quality'
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyz=[1080,720,480,360]
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyf=eFvBQHLJAGtjwmKIPVRSDMoxpCuidy(__addon__.getSetting(eFvBQHLJAGtjwmKIPVRSDMoxpCuiyg))
   return eFvBQHLJAGtjwmKIPVRSDMoxpCuiyz[eFvBQHLJAGtjwmKIPVRSDMoxpCuiyf]
  except:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiql
  return 720 
 def dp_Main_List(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf):
  for eFvBQHLJAGtjwmKIPVRSDMoxpCuiyh in eFvBQHLJAGtjwmKIPVRSDMoxpCuikU:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO=eFvBQHLJAGtjwmKIPVRSDMoxpCuiyh.get('title')
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX={'mode':eFvBQHLJAGtjwmKIPVRSDMoxpCuiyh.get('mode'),'stype':eFvBQHLJAGtjwmKIPVRSDMoxpCuiyh.get('stype'),'orderby':eFvBQHLJAGtjwmKIPVRSDMoxpCuiyh.get('orderby'),'ordernm':eFvBQHLJAGtjwmKIPVRSDMoxpCuiyh.get('ordernm'),'page':'1'}
   if eFvBQHLJAGtjwmKIPVRSDMoxpCuiyh.get('mode')=='XXX':
    eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX['mode']='XXX'
    eFvBQHLJAGtjwmKIPVRSDMoxpCuiyY=eFvBQHLJAGtjwmKIPVRSDMoxpCuiqE
   else:
    eFvBQHLJAGtjwmKIPVRSDMoxpCuiyY=eFvBQHLJAGtjwmKIPVRSDMoxpCuidk
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.add_dir(eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO,sublabel='',img='',infoLabels=eFvBQHLJAGtjwmKIPVRSDMoxpCuiql,isFolder=eFvBQHLJAGtjwmKIPVRSDMoxpCuiyY,params=eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX)
  if eFvBQHLJAGtjwmKIPVRSDMoxpCuidU(eFvBQHLJAGtjwmKIPVRSDMoxpCuikU)>0:xbmcplugin.endOfDirectory(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf._addon_handle)
 def login_main(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf):
  (eFvBQHLJAGtjwmKIPVRSDMoxpCuiyW,eFvBQHLJAGtjwmKIPVRSDMoxpCuiya,eFvBQHLJAGtjwmKIPVRSDMoxpCuiys)=eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.get_settings_login_info()
  if not(eFvBQHLJAGtjwmKIPVRSDMoxpCuiyW and eFvBQHLJAGtjwmKIPVRSDMoxpCuiya):
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikW=xbmcgui.Dialog()
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyn=eFvBQHLJAGtjwmKIPVRSDMoxpCuikW.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if eFvBQHLJAGtjwmKIPVRSDMoxpCuiyn==eFvBQHLJAGtjwmKIPVRSDMoxpCuidk:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.get_winEpisodeOrderby()=='':
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.set_winEpisodeOrderby('desc')
  if eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.cookiefile_check():return
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyc =eFvBQHLJAGtjwmKIPVRSDMoxpCuidy(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyb=xbmcgui.Window(10000).getProperty('TVING_M_LOGINTIME')
  if eFvBQHLJAGtjwmKIPVRSDMoxpCuiyb==eFvBQHLJAGtjwmKIPVRSDMoxpCuiql or eFvBQHLJAGtjwmKIPVRSDMoxpCuiyb=='':eFvBQHLJAGtjwmKIPVRSDMoxpCuiyb=eFvBQHLJAGtjwmKIPVRSDMoxpCuidy('19000101')
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyl=0
   while eFvBQHLJAGtjwmKIPVRSDMoxpCuidk:
    eFvBQHLJAGtjwmKIPVRSDMoxpCuiyl+=1
    time.sleep(0.05)
    if eFvBQHLJAGtjwmKIPVRSDMoxpCuiyb>=eFvBQHLJAGtjwmKIPVRSDMoxpCuiyc:return
    if eFvBQHLJAGtjwmKIPVRSDMoxpCuiyl>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  if eFvBQHLJAGtjwmKIPVRSDMoxpCuiyb>=eFvBQHLJAGtjwmKIPVRSDMoxpCuiyc:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   return
  if not eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.TvingObj.GetCredential(eFvBQHLJAGtjwmKIPVRSDMoxpCuiyW,eFvBQHLJAGtjwmKIPVRSDMoxpCuiya,eFvBQHLJAGtjwmKIPVRSDMoxpCuiys):
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   sys.exit()
  eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.set_winCredential(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.TvingObj.LoadCredential())
  eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
 def dp_Title_Group(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf,eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr):
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyE=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr.get('stype')
  if eFvBQHLJAGtjwmKIPVRSDMoxpCuiyE=='live':
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiUk=eFvBQHLJAGtjwmKIPVRSDMoxpCuikr
  else:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiUk=eFvBQHLJAGtjwmKIPVRSDMoxpCuikO
  for eFvBQHLJAGtjwmKIPVRSDMoxpCuiUy in eFvBQHLJAGtjwmKIPVRSDMoxpCuiUk:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUy.get('title')
   if eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr.get('ordernm')!='-':
    eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO+='  ('+eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr.get('ordernm')+')'
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX={'mode':eFvBQHLJAGtjwmKIPVRSDMoxpCuiUy.get('mode'),'stype':eFvBQHLJAGtjwmKIPVRSDMoxpCuiUy.get('stype'),'orderby':eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr.get('orderby'),'page':'1'}
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.add_dir(eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO,sublabel='',img='',infoLabels=eFvBQHLJAGtjwmKIPVRSDMoxpCuiql,isFolder=eFvBQHLJAGtjwmKIPVRSDMoxpCuidk,params=eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX)
  if eFvBQHLJAGtjwmKIPVRSDMoxpCuidU(eFvBQHLJAGtjwmKIPVRSDMoxpCuiUk)>0:xbmcplugin.endOfDirectory(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf._addon_handle)
 def dp_LiveChannel_List(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf,eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr):
  eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.TvingObj.SaveCredential(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.get_winCredential())
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyE =eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr.get('stype')
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiUq =eFvBQHLJAGtjwmKIPVRSDMoxpCuidy(eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr.get('page'))
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiUd,eFvBQHLJAGtjwmKIPVRSDMoxpCuiUO=eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.TvingObj.GetLiveChannelList(eFvBQHLJAGtjwmKIPVRSDMoxpCuiyE,eFvBQHLJAGtjwmKIPVRSDMoxpCuiUq)
  for eFvBQHLJAGtjwmKIPVRSDMoxpCuiUN in eFvBQHLJAGtjwmKIPVRSDMoxpCuiUd:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO =eFvBQHLJAGtjwmKIPVRSDMoxpCuiUN.get('title')
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyT =eFvBQHLJAGtjwmKIPVRSDMoxpCuiUN.get('channel')
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiUg =eFvBQHLJAGtjwmKIPVRSDMoxpCuiUN.get('thumbnail')
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiUz =eFvBQHLJAGtjwmKIPVRSDMoxpCuiUN.get('synopsis')
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiUf=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUN.get('channelepg')
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiUh=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUN.get('info')
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiUh['plot']='%s\n%s\n%s\n\n%s'%(eFvBQHLJAGtjwmKIPVRSDMoxpCuiyT,eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO,eFvBQHLJAGtjwmKIPVRSDMoxpCuiUf,eFvBQHLJAGtjwmKIPVRSDMoxpCuiUz)
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX={'mode':'LIVE','mediacode':eFvBQHLJAGtjwmKIPVRSDMoxpCuiUN.get('mediacode'),'stype':eFvBQHLJAGtjwmKIPVRSDMoxpCuiyE}
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.add_dir(eFvBQHLJAGtjwmKIPVRSDMoxpCuiyT,sublabel=eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO,img=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUg,infoLabels=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUh,isFolder=eFvBQHLJAGtjwmKIPVRSDMoxpCuiqE,params=eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX)
  if eFvBQHLJAGtjwmKIPVRSDMoxpCuiUO:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX['mode']='CHANNEL' 
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX['stype']=eFvBQHLJAGtjwmKIPVRSDMoxpCuiyE 
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX['page']=eFvBQHLJAGtjwmKIPVRSDMoxpCuidr(eFvBQHLJAGtjwmKIPVRSDMoxpCuiUq+1)
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO='[B]%s >>[/B]'%'다음 페이지'
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiUX=eFvBQHLJAGtjwmKIPVRSDMoxpCuidr(eFvBQHLJAGtjwmKIPVRSDMoxpCuiUq+1)
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.add_dir(eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO,sublabel=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUX,img='',infoLabels=eFvBQHLJAGtjwmKIPVRSDMoxpCuiql,isFolder=eFvBQHLJAGtjwmKIPVRSDMoxpCuidk,params=eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX)
  if eFvBQHLJAGtjwmKIPVRSDMoxpCuidU(eFvBQHLJAGtjwmKIPVRSDMoxpCuiUd)>0:xbmcplugin.endOfDirectory(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf._addon_handle,cacheToDisc=eFvBQHLJAGtjwmKIPVRSDMoxpCuiqE)
 def dp_Program_List(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf,eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr):
  eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.TvingObj.SaveCredential(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.get_winCredential())
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyE =eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr.get('stype')
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiUY =eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr.get('orderby')
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiUq =eFvBQHLJAGtjwmKIPVRSDMoxpCuidy(eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr.get('page'))
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiUT,eFvBQHLJAGtjwmKIPVRSDMoxpCuiUO=eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.TvingObj.GetProgramList(eFvBQHLJAGtjwmKIPVRSDMoxpCuiyE,eFvBQHLJAGtjwmKIPVRSDMoxpCuiUY,eFvBQHLJAGtjwmKIPVRSDMoxpCuiUq,landyn=eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.get_settings_thumbnail_landyn())
  for eFvBQHLJAGtjwmKIPVRSDMoxpCuiUW in eFvBQHLJAGtjwmKIPVRSDMoxpCuiUT:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO =eFvBQHLJAGtjwmKIPVRSDMoxpCuiUW.get('title')
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiUg=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUW.get('thumbnail')
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiUz =eFvBQHLJAGtjwmKIPVRSDMoxpCuiUW.get('synopsis')
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiUa =eFvBQHLJAGtjwmKIPVRSDMoxpCuikN.get(eFvBQHLJAGtjwmKIPVRSDMoxpCuiUW.get('channel'))
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiUh=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUW.get('info')
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiUh['studio']=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUa
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiUh['plot']='%s <%s>\n\n%s'%(eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO,eFvBQHLJAGtjwmKIPVRSDMoxpCuiUa,eFvBQHLJAGtjwmKIPVRSDMoxpCuiUz)
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX={'mode':'EPISODE','programcode':eFvBQHLJAGtjwmKIPVRSDMoxpCuiUW.get('program'),'page':'1'}
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.add_dir(eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO,sublabel=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUa,img=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUg,infoLabels=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUh,isFolder=eFvBQHLJAGtjwmKIPVRSDMoxpCuidk,params=eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX)
  if eFvBQHLJAGtjwmKIPVRSDMoxpCuiUO:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX['mode'] ='PROGRAM' 
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX['stype'] =eFvBQHLJAGtjwmKIPVRSDMoxpCuiyE
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX['orderby']=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUY
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX['page'] =eFvBQHLJAGtjwmKIPVRSDMoxpCuidr(eFvBQHLJAGtjwmKIPVRSDMoxpCuiUq+1)
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO='[B]%s >>[/B]'%'다음 페이지'
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiUX=eFvBQHLJAGtjwmKIPVRSDMoxpCuidr(eFvBQHLJAGtjwmKIPVRSDMoxpCuiUq+1)
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.add_dir(eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO,sublabel=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUX,img='',infoLabels=eFvBQHLJAGtjwmKIPVRSDMoxpCuiql,isFolder=eFvBQHLJAGtjwmKIPVRSDMoxpCuidk,params=eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX)
  if eFvBQHLJAGtjwmKIPVRSDMoxpCuidU(eFvBQHLJAGtjwmKIPVRSDMoxpCuiUT)>0:xbmcplugin.endOfDirectory(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf._addon_handle,cacheToDisc=eFvBQHLJAGtjwmKIPVRSDMoxpCuiqE)
 def dp_Episode_List(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf,eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr):
  eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.TvingObj.SaveCredential(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.get_winCredential())
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiUs=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr.get('programcode')
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiUq =eFvBQHLJAGtjwmKIPVRSDMoxpCuidy(eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr.get('page'))
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiUn,eFvBQHLJAGtjwmKIPVRSDMoxpCuiUO,eFvBQHLJAGtjwmKIPVRSDMoxpCuiUc=eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.TvingObj.GetEpisodoList(eFvBQHLJAGtjwmKIPVRSDMoxpCuiUs,eFvBQHLJAGtjwmKIPVRSDMoxpCuiUq,orderby=eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.get_winEpisodeOrderby())
  for eFvBQHLJAGtjwmKIPVRSDMoxpCuiUb in eFvBQHLJAGtjwmKIPVRSDMoxpCuiUn:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO =eFvBQHLJAGtjwmKIPVRSDMoxpCuiUb.get('title')
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiUX =eFvBQHLJAGtjwmKIPVRSDMoxpCuiUb.get('subtitle')
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiUg=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUb.get('thumbnail')
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiUz =eFvBQHLJAGtjwmKIPVRSDMoxpCuiUb.get('synopsis')
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiUh=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUb.get('info')
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiUh['plot']='%s\n\n%s'%(eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO,eFvBQHLJAGtjwmKIPVRSDMoxpCuiUz)
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX={'mode':'VOD','mediacode':eFvBQHLJAGtjwmKIPVRSDMoxpCuiUb.get('episode'),'stype':'vod','programcode':eFvBQHLJAGtjwmKIPVRSDMoxpCuiUs,'title':eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO,'thumbnail':eFvBQHLJAGtjwmKIPVRSDMoxpCuiUg}
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.add_dir(eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO,sublabel=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUX,img=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUg,infoLabels=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUh,isFolder=eFvBQHLJAGtjwmKIPVRSDMoxpCuiqE,params=eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX)
  if eFvBQHLJAGtjwmKIPVRSDMoxpCuiUq==1:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiUh={'plot':'정렬순서를 변경합니다.'}
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX={}
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX['mode'] ='ORDER_BY' 
   if eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.get_winEpisodeOrderby()=='desc':
    eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO='정렬순서변경 : 최신화부터 -> 1회부터'
    eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX['orderby']='asc'
   else:
    eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO='정렬순서변경 : 1회부터 -> 최신화부터'
    eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX['orderby']='desc'
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.add_dir(eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO,sublabel='',img='',infoLabels=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUh,isFolder=eFvBQHLJAGtjwmKIPVRSDMoxpCuiqE,params=eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX)
  if eFvBQHLJAGtjwmKIPVRSDMoxpCuiUO:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX['mode'] ='EPISODE' 
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX['programcode']=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUs
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX['page'] =eFvBQHLJAGtjwmKIPVRSDMoxpCuidr(eFvBQHLJAGtjwmKIPVRSDMoxpCuiUq+1)
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO='[B]%s >>[/B]'%'다음 페이지'
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiUX=eFvBQHLJAGtjwmKIPVRSDMoxpCuidr(eFvBQHLJAGtjwmKIPVRSDMoxpCuiUq+1)
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.add_dir(eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO,sublabel=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUX,img='',infoLabels=eFvBQHLJAGtjwmKIPVRSDMoxpCuiql,isFolder=eFvBQHLJAGtjwmKIPVRSDMoxpCuidk,params=eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX)
  if eFvBQHLJAGtjwmKIPVRSDMoxpCuidU(eFvBQHLJAGtjwmKIPVRSDMoxpCuiUn)>0:xbmcplugin.endOfDirectory(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf._addon_handle,cacheToDisc=eFvBQHLJAGtjwmKIPVRSDMoxpCuidk)
 def dp_setEpOrderby(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf,eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr):
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiUY =eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr.get('orderby')
  eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.set_winEpisodeOrderby(eFvBQHLJAGtjwmKIPVRSDMoxpCuiUY)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf,eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr):
  eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.TvingObj.SaveCredential(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.get_winCredential())
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiUY =eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr.get('orderby')
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiUq=eFvBQHLJAGtjwmKIPVRSDMoxpCuidy(eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr.get('page'))
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiUl,eFvBQHLJAGtjwmKIPVRSDMoxpCuiUO=eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.TvingObj.GetMovieList(eFvBQHLJAGtjwmKIPVRSDMoxpCuiUY,eFvBQHLJAGtjwmKIPVRSDMoxpCuiUq,premiumyn=eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.get_settings_premiumyn(),landyn=eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.get_settings_thumbnail_landyn())
  for eFvBQHLJAGtjwmKIPVRSDMoxpCuiUE in eFvBQHLJAGtjwmKIPVRSDMoxpCuiUl:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO =eFvBQHLJAGtjwmKIPVRSDMoxpCuiUE.get('title')
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiUg=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUE.get('thumbnail')
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiUz =eFvBQHLJAGtjwmKIPVRSDMoxpCuiUE.get('synopsis')
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiUh=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUE.get('info')
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiUh['plot']='%s\n\n%s'%(eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO,eFvBQHLJAGtjwmKIPVRSDMoxpCuiUz)
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX={'mode':'MOVIE','mediacode':eFvBQHLJAGtjwmKIPVRSDMoxpCuiUE.get('moviecode'),'stype':'movie','title':eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO,'thumbnail':eFvBQHLJAGtjwmKIPVRSDMoxpCuiUg}
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.add_dir(eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO,sublabel='',img=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUg,infoLabels=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUh,isFolder=eFvBQHLJAGtjwmKIPVRSDMoxpCuiqE,params=eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX)
  if eFvBQHLJAGtjwmKIPVRSDMoxpCuiUO:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX['mode'] ='MOVIE_GROUP' 
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX['orderby']=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUY
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX['page'] =eFvBQHLJAGtjwmKIPVRSDMoxpCuidr(eFvBQHLJAGtjwmKIPVRSDMoxpCuiUq+1)
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO='[B]%s >>[/B]'%'다음 페이지'
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiUX=eFvBQHLJAGtjwmKIPVRSDMoxpCuidr(eFvBQHLJAGtjwmKIPVRSDMoxpCuiUq+1)
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.add_dir(eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO,sublabel=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUX,img='',infoLabels=eFvBQHLJAGtjwmKIPVRSDMoxpCuiql,isFolder=eFvBQHLJAGtjwmKIPVRSDMoxpCuidk,params=eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX)
  if eFvBQHLJAGtjwmKIPVRSDMoxpCuidU(eFvBQHLJAGtjwmKIPVRSDMoxpCuiUl)>0:xbmcplugin.endOfDirectory(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf._addon_handle,cacheToDisc=eFvBQHLJAGtjwmKIPVRSDMoxpCuiqE)
 def dp_Search_Group(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf,eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr):
  for eFvBQHLJAGtjwmKIPVRSDMoxpCuiUy in eFvBQHLJAGtjwmKIPVRSDMoxpCuikd:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUy.get('title')
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX={'mode':eFvBQHLJAGtjwmKIPVRSDMoxpCuiUy.get('mode'),'stype':eFvBQHLJAGtjwmKIPVRSDMoxpCuiUy.get('stype'),'page':'1'}
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.add_dir(eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO,sublabel='',img='',infoLabels=eFvBQHLJAGtjwmKIPVRSDMoxpCuiql,isFolder=eFvBQHLJAGtjwmKIPVRSDMoxpCuidk,params=eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX)
  if eFvBQHLJAGtjwmKIPVRSDMoxpCuidU(eFvBQHLJAGtjwmKIPVRSDMoxpCuikd)>0:xbmcplugin.endOfDirectory(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf._addon_handle)
 def dp_Search_List(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf,eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr):
  eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.TvingObj.SaveCredential(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.get_winCredential())
  eFvBQHLJAGtjwmKIPVRSDMoxpCuirk =__addon__.getSetting('id')
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiUq =eFvBQHLJAGtjwmKIPVRSDMoxpCuidy(eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr.get('page'))
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyE =eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr.get('stype')
  if 'search_key' in eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiry=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr.get('search_key')
  else:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiry=eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not eFvBQHLJAGtjwmKIPVRSDMoxpCuiry:return
  eFvBQHLJAGtjwmKIPVRSDMoxpCuirU,eFvBQHLJAGtjwmKIPVRSDMoxpCuiUO=eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.TvingObj.GetSearchList(eFvBQHLJAGtjwmKIPVRSDMoxpCuiry,eFvBQHLJAGtjwmKIPVRSDMoxpCuirk,eFvBQHLJAGtjwmKIPVRSDMoxpCuiUq,eFvBQHLJAGtjwmKIPVRSDMoxpCuiyE,premiumyn=eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.get_settings_premiumyn(),landyn=eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.get_settings_thumbnail_landyn())
  if eFvBQHLJAGtjwmKIPVRSDMoxpCuidU(eFvBQHLJAGtjwmKIPVRSDMoxpCuirU)==0:return
  for eFvBQHLJAGtjwmKIPVRSDMoxpCuirq in eFvBQHLJAGtjwmKIPVRSDMoxpCuirU:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO =eFvBQHLJAGtjwmKIPVRSDMoxpCuirq.get('title')
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiUg=eFvBQHLJAGtjwmKIPVRSDMoxpCuirq.get('thumbnail')
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiUz =eFvBQHLJAGtjwmKIPVRSDMoxpCuirq.get('synopsis')
   eFvBQHLJAGtjwmKIPVRSDMoxpCuird =eFvBQHLJAGtjwmKIPVRSDMoxpCuirq.get('program')
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiUh=eFvBQHLJAGtjwmKIPVRSDMoxpCuirq.get('info')
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiUh['plot']='%s\n\n%s'%(eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO,eFvBQHLJAGtjwmKIPVRSDMoxpCuiUz)
   if eFvBQHLJAGtjwmKIPVRSDMoxpCuiyE=='vod':
    eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX={'mode':'EPISODE','programcode':eFvBQHLJAGtjwmKIPVRSDMoxpCuirq.get('program'),'page':'1'}
    eFvBQHLJAGtjwmKIPVRSDMoxpCuiyY=eFvBQHLJAGtjwmKIPVRSDMoxpCuidk
   else:
    eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX={'mode':'MOVIE','mediacode':eFvBQHLJAGtjwmKIPVRSDMoxpCuirq.get('movie'),'stype':'movie','title':eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO,'thumbnail':eFvBQHLJAGtjwmKIPVRSDMoxpCuiUg}
    eFvBQHLJAGtjwmKIPVRSDMoxpCuiyY=eFvBQHLJAGtjwmKIPVRSDMoxpCuiqE
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.add_dir(eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO,sublabel='',img=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUg,infoLabels=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUh,isFolder=eFvBQHLJAGtjwmKIPVRSDMoxpCuiyY,params=eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX)
  if eFvBQHLJAGtjwmKIPVRSDMoxpCuiUO:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX['mode'] ='SEARCH' 
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX['search_key']=eFvBQHLJAGtjwmKIPVRSDMoxpCuiry
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX['page'] =eFvBQHLJAGtjwmKIPVRSDMoxpCuidr(eFvBQHLJAGtjwmKIPVRSDMoxpCuiUq+1)
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO='[B]%s >>[/B]'%'다음 페이지'
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiUX=eFvBQHLJAGtjwmKIPVRSDMoxpCuidr(eFvBQHLJAGtjwmKIPVRSDMoxpCuiUq+1)
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.add_dir(eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO,sublabel=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUX,img='',infoLabels=eFvBQHLJAGtjwmKIPVRSDMoxpCuiql,isFolder=eFvBQHLJAGtjwmKIPVRSDMoxpCuidk,params=eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX)
  if eFvBQHLJAGtjwmKIPVRSDMoxpCuidU(eFvBQHLJAGtjwmKIPVRSDMoxpCuirU)>0:xbmcplugin.endOfDirectory(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf._addon_handle)
 def Delete_Watched_List(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf,eFvBQHLJAGtjwmKIPVRSDMoxpCuiyE):
  try:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuirO=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%eFvBQHLJAGtjwmKIPVRSDMoxpCuiyE))
   fp=eFvBQHLJAGtjwmKIPVRSDMoxpCuidq(eFvBQHLJAGtjwmKIPVRSDMoxpCuirO,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiql
 def dp_WatchList_Delete(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf,eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr):
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyE=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr.get('stype')
  eFvBQHLJAGtjwmKIPVRSDMoxpCuikW=xbmcgui.Dialog()
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyn=eFvBQHLJAGtjwmKIPVRSDMoxpCuikW.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if eFvBQHLJAGtjwmKIPVRSDMoxpCuiyn==eFvBQHLJAGtjwmKIPVRSDMoxpCuiqE:sys.exit()
  eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.Delete_Watched_List(eFvBQHLJAGtjwmKIPVRSDMoxpCuiyE)
  xbmc.executebuiltin("Container.Refresh")
 def Load_Watched_List(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf,eFvBQHLJAGtjwmKIPVRSDMoxpCuiyE):
  try:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuirO=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%eFvBQHLJAGtjwmKIPVRSDMoxpCuiyE))
   fp=eFvBQHLJAGtjwmKIPVRSDMoxpCuidq(eFvBQHLJAGtjwmKIPVRSDMoxpCuirO,'r',-1,'utf-8')
   eFvBQHLJAGtjwmKIPVRSDMoxpCuirN=fp.readlines()
   fp.close()
  except:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuirN=[]
  return eFvBQHLJAGtjwmKIPVRSDMoxpCuirN
 def Save_Watched_List(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf,eFvBQHLJAGtjwmKIPVRSDMoxpCuiyE,eFvBQHLJAGtjwmKIPVRSDMoxpCuikY):
  try:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuirO=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%eFvBQHLJAGtjwmKIPVRSDMoxpCuiyE))
   eFvBQHLJAGtjwmKIPVRSDMoxpCuirg=eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.Load_Watched_List(eFvBQHLJAGtjwmKIPVRSDMoxpCuiyE) 
   fp=eFvBQHLJAGtjwmKIPVRSDMoxpCuidq(eFvBQHLJAGtjwmKIPVRSDMoxpCuirO,'w',-1,'utf-8')
   eFvBQHLJAGtjwmKIPVRSDMoxpCuirz=urllib.parse.urlencode(eFvBQHLJAGtjwmKIPVRSDMoxpCuikY)
   eFvBQHLJAGtjwmKIPVRSDMoxpCuirz=eFvBQHLJAGtjwmKIPVRSDMoxpCuirz+'\n'
   fp.write(eFvBQHLJAGtjwmKIPVRSDMoxpCuirz)
   eFvBQHLJAGtjwmKIPVRSDMoxpCuirf=0
   for eFvBQHLJAGtjwmKIPVRSDMoxpCuirh in eFvBQHLJAGtjwmKIPVRSDMoxpCuirg:
    eFvBQHLJAGtjwmKIPVRSDMoxpCuirX=eFvBQHLJAGtjwmKIPVRSDMoxpCuidO(urllib.parse.parse_qsl(eFvBQHLJAGtjwmKIPVRSDMoxpCuirh))
    eFvBQHLJAGtjwmKIPVRSDMoxpCuirY=eFvBQHLJAGtjwmKIPVRSDMoxpCuikY.get('code')
    eFvBQHLJAGtjwmKIPVRSDMoxpCuirT=eFvBQHLJAGtjwmKIPVRSDMoxpCuirX.get('code')
    if eFvBQHLJAGtjwmKIPVRSDMoxpCuiyE=='vod' and eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.get_settings_direct_replay()==eFvBQHLJAGtjwmKIPVRSDMoxpCuidk:
     eFvBQHLJAGtjwmKIPVRSDMoxpCuirY=eFvBQHLJAGtjwmKIPVRSDMoxpCuikY.get('videoid')
     eFvBQHLJAGtjwmKIPVRSDMoxpCuirT=eFvBQHLJAGtjwmKIPVRSDMoxpCuirX.get('videoid')if eFvBQHLJAGtjwmKIPVRSDMoxpCuirT!=eFvBQHLJAGtjwmKIPVRSDMoxpCuiql else '-'
    if eFvBQHLJAGtjwmKIPVRSDMoxpCuirY!=eFvBQHLJAGtjwmKIPVRSDMoxpCuirT:
     fp.write(eFvBQHLJAGtjwmKIPVRSDMoxpCuirh)
     eFvBQHLJAGtjwmKIPVRSDMoxpCuirf+=1
     if eFvBQHLJAGtjwmKIPVRSDMoxpCuirf>=50:break
   fp.close()
  except:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiql
 def dp_Watch_List(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf,eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr):
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyE =eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr.get('stype')
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyk=eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.get_settings_direct_replay()
  if eFvBQHLJAGtjwmKIPVRSDMoxpCuiyE=='-':
   for eFvBQHLJAGtjwmKIPVRSDMoxpCuiUy in eFvBQHLJAGtjwmKIPVRSDMoxpCuikq:
    eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUy.get('title')
    eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX={'mode':eFvBQHLJAGtjwmKIPVRSDMoxpCuiUy.get('mode'),'stype':eFvBQHLJAGtjwmKIPVRSDMoxpCuiUy.get('stype')}
    eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.add_dir(eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO,sublabel='',img='',infoLabels=eFvBQHLJAGtjwmKIPVRSDMoxpCuiql,isFolder=eFvBQHLJAGtjwmKIPVRSDMoxpCuidk,params=eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX)
   if eFvBQHLJAGtjwmKIPVRSDMoxpCuidU(eFvBQHLJAGtjwmKIPVRSDMoxpCuikq)>0:xbmcplugin.endOfDirectory(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf._addon_handle)
  else:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuirW=eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.Load_Watched_List(eFvBQHLJAGtjwmKIPVRSDMoxpCuiyE)
   for eFvBQHLJAGtjwmKIPVRSDMoxpCuira in eFvBQHLJAGtjwmKIPVRSDMoxpCuirW:
    eFvBQHLJAGtjwmKIPVRSDMoxpCuirs=eFvBQHLJAGtjwmKIPVRSDMoxpCuidO(urllib.parse.parse_qsl(eFvBQHLJAGtjwmKIPVRSDMoxpCuira))
    eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO =eFvBQHLJAGtjwmKIPVRSDMoxpCuirs.get('title')
    eFvBQHLJAGtjwmKIPVRSDMoxpCuiUg=eFvBQHLJAGtjwmKIPVRSDMoxpCuirs.get('img')
    eFvBQHLJAGtjwmKIPVRSDMoxpCuirn =eFvBQHLJAGtjwmKIPVRSDMoxpCuirs.get('videoid')
    eFvBQHLJAGtjwmKIPVRSDMoxpCuiUh={}
    eFvBQHLJAGtjwmKIPVRSDMoxpCuiUh['plot']=eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO
    if eFvBQHLJAGtjwmKIPVRSDMoxpCuiyE=='vod':
     if eFvBQHLJAGtjwmKIPVRSDMoxpCuiyk==eFvBQHLJAGtjwmKIPVRSDMoxpCuiqE or eFvBQHLJAGtjwmKIPVRSDMoxpCuirn==eFvBQHLJAGtjwmKIPVRSDMoxpCuiql:
      eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX={'mode':'EPISODE','programcode':eFvBQHLJAGtjwmKIPVRSDMoxpCuirs.get('code'),'page':'1'}
      eFvBQHLJAGtjwmKIPVRSDMoxpCuiyY=eFvBQHLJAGtjwmKIPVRSDMoxpCuidk
     else:
      eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX={'mode':'VOD','mediacode':eFvBQHLJAGtjwmKIPVRSDMoxpCuirn,'stype':'vod','programcode':eFvBQHLJAGtjwmKIPVRSDMoxpCuirs.get('code'),'title':eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO,'thumbnail':eFvBQHLJAGtjwmKIPVRSDMoxpCuiUg}
      eFvBQHLJAGtjwmKIPVRSDMoxpCuiyY=eFvBQHLJAGtjwmKIPVRSDMoxpCuiqE
    else:
     eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX={'mode':'MOVIE','mediacode':eFvBQHLJAGtjwmKIPVRSDMoxpCuirs.get('code'),'stype':'movie','title':eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO,'thumbnail':eFvBQHLJAGtjwmKIPVRSDMoxpCuiUg}
     eFvBQHLJAGtjwmKIPVRSDMoxpCuiyY=eFvBQHLJAGtjwmKIPVRSDMoxpCuiqE
    eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.add_dir(eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO,sublabel='',img=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUg,infoLabels=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUh,isFolder=eFvBQHLJAGtjwmKIPVRSDMoxpCuiyY,params=eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX)
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiUh={'plot':'시청목록을 삭제합니다.'}
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO='*** 시청목록 삭제 ***'
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX={'mode':'MYVIEW_REMOVE','stype':eFvBQHLJAGtjwmKIPVRSDMoxpCuiyE}
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.add_dir(eFvBQHLJAGtjwmKIPVRSDMoxpCuiyO,sublabel='',img='',infoLabels=eFvBQHLJAGtjwmKIPVRSDMoxpCuiUh,isFolder=eFvBQHLJAGtjwmKIPVRSDMoxpCuiqE,params=eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX)
   xbmcplugin.endOfDirectory(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf._addon_handle,cacheToDisc=eFvBQHLJAGtjwmKIPVRSDMoxpCuiqE)
 def play_VIDEO(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf,eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr):
  eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.TvingObj.SaveCredential(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.get_winCredential())
  eFvBQHLJAGtjwmKIPVRSDMoxpCuirb =eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr.get('mediacode')
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyE =eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr.get('stype')
  eFvBQHLJAGtjwmKIPVRSDMoxpCuirl=eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.get_selQuality(eFvBQHLJAGtjwmKIPVRSDMoxpCuiyE)
  eFvBQHLJAGtjwmKIPVRSDMoxpCuirE,eFvBQHLJAGtjwmKIPVRSDMoxpCuiqk=eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.TvingObj.GetBroadURL(eFvBQHLJAGtjwmKIPVRSDMoxpCuirb,eFvBQHLJAGtjwmKIPVRSDMoxpCuirl,eFvBQHLJAGtjwmKIPVRSDMoxpCuiyE)
  eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.addon_log('qt, stype, url : %s - %s - %s'%(eFvBQHLJAGtjwmKIPVRSDMoxpCuidr(eFvBQHLJAGtjwmKIPVRSDMoxpCuirl),eFvBQHLJAGtjwmKIPVRSDMoxpCuiyE,eFvBQHLJAGtjwmKIPVRSDMoxpCuirE))
  if eFvBQHLJAGtjwmKIPVRSDMoxpCuirE=='':
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.addon_noti(__language__(30908).encode('utf8'))
   return
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiqy =eFvBQHLJAGtjwmKIPVRSDMoxpCuirE.find('Policy=')
  if eFvBQHLJAGtjwmKIPVRSDMoxpCuiqy!=-1:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiqU =eFvBQHLJAGtjwmKIPVRSDMoxpCuirE.split('?')[0]
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiqr=eFvBQHLJAGtjwmKIPVRSDMoxpCuidO(urllib.parse.parse_qsl(urllib.parse.urlsplit(eFvBQHLJAGtjwmKIPVRSDMoxpCuirE).query))
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiqr=urllib.parse.urlencode(eFvBQHLJAGtjwmKIPVRSDMoxpCuiqr)
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiqr=eFvBQHLJAGtjwmKIPVRSDMoxpCuiqr.replace('&',';')
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiqr=eFvBQHLJAGtjwmKIPVRSDMoxpCuiqr.replace('Policy','CloudFront-Policy')
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiqr=eFvBQHLJAGtjwmKIPVRSDMoxpCuiqr.replace('Signature','CloudFront-Signature')
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiqr=eFvBQHLJAGtjwmKIPVRSDMoxpCuiqr.replace('Key-Pair-Id','CloudFront-Key-Pair-Id')
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiqd='%s|Cookie=%s'%(eFvBQHLJAGtjwmKIPVRSDMoxpCuiqU,eFvBQHLJAGtjwmKIPVRSDMoxpCuiqr)
  else:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiqd=eFvBQHLJAGtjwmKIPVRSDMoxpCuirE
  eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.addon_log(eFvBQHLJAGtjwmKIPVRSDMoxpCuiqd,eFvBQHLJAGtjwmKIPVRSDMoxpCuiqE)
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiqO=xbmcgui.ListItem(path=eFvBQHLJAGtjwmKIPVRSDMoxpCuiqd)
  if eFvBQHLJAGtjwmKIPVRSDMoxpCuiqk!='':
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiqN=eFvBQHLJAGtjwmKIPVRSDMoxpCuiqk
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiqg ='https://cj.drmkeyserver.com/widevine_license'
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiqz ='mpd'
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiqf ='com.widevine.alpha'
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiqh =inputstreamhelper.Helper(eFvBQHLJAGtjwmKIPVRSDMoxpCuiqz,drm='widevine')
   if eFvBQHLJAGtjwmKIPVRSDMoxpCuiqh.check_inputstream():
    eFvBQHLJAGtjwmKIPVRSDMoxpCuiqX={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/live/player/%s'%eFvBQHLJAGtjwmKIPVRSDMoxpCuirb,'sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':eFvBQHLJAGtjwmKIPVRSDMoxpCuikg,'AcquireLicenseAssertion':eFvBQHLJAGtjwmKIPVRSDMoxpCuiqN,'Host':'cj.drmkeyserver.com'}
    eFvBQHLJAGtjwmKIPVRSDMoxpCuiqY=eFvBQHLJAGtjwmKIPVRSDMoxpCuiqg+'|'+urllib.parse.urlencode(eFvBQHLJAGtjwmKIPVRSDMoxpCuiqX)+'|R{SSM}|'
    eFvBQHLJAGtjwmKIPVRSDMoxpCuiqO.setProperty('inputstream',eFvBQHLJAGtjwmKIPVRSDMoxpCuiqh.inputstream_addon)
    eFvBQHLJAGtjwmKIPVRSDMoxpCuiqO.setProperty('inputstream.adaptive.manifest_type',eFvBQHLJAGtjwmKIPVRSDMoxpCuiqz)
    eFvBQHLJAGtjwmKIPVRSDMoxpCuiqO.setProperty('inputstream.adaptive.license_type',eFvBQHLJAGtjwmKIPVRSDMoxpCuiqf)
    eFvBQHLJAGtjwmKIPVRSDMoxpCuiqO.setProperty('inputstream.adaptive.license_key',eFvBQHLJAGtjwmKIPVRSDMoxpCuiqY)
    eFvBQHLJAGtjwmKIPVRSDMoxpCuiqO.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(eFvBQHLJAGtjwmKIPVRSDMoxpCuikg))
  xbmcplugin.setResolvedUrl(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf._addon_handle,eFvBQHLJAGtjwmKIPVRSDMoxpCuidk,eFvBQHLJAGtjwmKIPVRSDMoxpCuiqO)
  try:
   if eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr.get('mode')in['VOD','MOVIE']and eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr.get('title'):
    eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX={'code':eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr.get('programcode')if eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr.get('mode')=='VOD' else eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr.get('mediacode'),'img':eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr.get('thumbnail'),'title':eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr.get('title'),'videoid':eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr.get('mediacode')}
    eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.Save_Watched_List(eFvBQHLJAGtjwmKIPVRSDMoxpCuiUr.get('stype'),eFvBQHLJAGtjwmKIPVRSDMoxpCuiyX)
  except:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiql
 def logout(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf):
  eFvBQHLJAGtjwmKIPVRSDMoxpCuikW=xbmcgui.Dialog()
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyn=eFvBQHLJAGtjwmKIPVRSDMoxpCuikW.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if eFvBQHLJAGtjwmKIPVRSDMoxpCuiyn==eFvBQHLJAGtjwmKIPVRSDMoxpCuiqE:sys.exit()
  eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.wininfo_clear()
  if os.path.isfile(eFvBQHLJAGtjwmKIPVRSDMoxpCuikz):os.remove(eFvBQHLJAGtjwmKIPVRSDMoxpCuikz)
  eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf):
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyr=xbmcgui.Window(10000)
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyr.setProperty('TVING_M_TOKEN','')
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyr.setProperty('TVING_M_USERINFO','')
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyr.setProperty('TVING_M_UUID','')
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyr.setProperty('TVING_M_LOGINTIME','')
 def cookiefile_save(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf):
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiqT =eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.TvingObj.Get_Now_Datetime()
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiqW=eFvBQHLJAGtjwmKIPVRSDMoxpCuiqT+datetime.timedelta(days=eFvBQHLJAGtjwmKIPVRSDMoxpCuidy(__addon__.getSetting('cache_ttl')))
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyr=xbmcgui.Window(10000)
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiqa={'tving_token':eFvBQHLJAGtjwmKIPVRSDMoxpCuiyr.getProperty('TVING_M_TOKEN'),'tving_userinfo':eFvBQHLJAGtjwmKIPVRSDMoxpCuiyr.getProperty('TVING_M_USERINFO'),'tving_uuid':eFvBQHLJAGtjwmKIPVRSDMoxpCuiyr.getProperty('TVING_M_UUID'),'tving_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'tving_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'tving_logintype':__addon__.getSetting('login_type'),'tving_limitdate':eFvBQHLJAGtjwmKIPVRSDMoxpCuiqW.strftime('%Y-%m-%d')}
  try: 
   fp=eFvBQHLJAGtjwmKIPVRSDMoxpCuidq(eFvBQHLJAGtjwmKIPVRSDMoxpCuikz,'w',-1,'utf-8')
   json.dump(eFvBQHLJAGtjwmKIPVRSDMoxpCuiqa,fp)
   fp.close()
  except eFvBQHLJAGtjwmKIPVRSDMoxpCuidN as exception:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuidg(exception)
 def cookiefile_check(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf):
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiqa={}
  try: 
   fp=eFvBQHLJAGtjwmKIPVRSDMoxpCuidq(eFvBQHLJAGtjwmKIPVRSDMoxpCuikz,'r',-1,'utf-8')
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiqa= json.load(fp)
   fp.close()
  except eFvBQHLJAGtjwmKIPVRSDMoxpCuidN as exception:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.wininfo_clear()
   return eFvBQHLJAGtjwmKIPVRSDMoxpCuiqE
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyW =__addon__.getSetting('id')
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiya =__addon__.getSetting('pw')
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiqs=__addon__.getSetting('login_type')
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiqa['tving_id']=base64.standard_b64decode(eFvBQHLJAGtjwmKIPVRSDMoxpCuiqa['tving_id']).decode('utf-8')
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiqa['tving_pw']=base64.standard_b64decode(eFvBQHLJAGtjwmKIPVRSDMoxpCuiqa['tving_pw']).decode('utf-8')
  if eFvBQHLJAGtjwmKIPVRSDMoxpCuiyW!=eFvBQHLJAGtjwmKIPVRSDMoxpCuiqa['tving_id']or eFvBQHLJAGtjwmKIPVRSDMoxpCuiya!=eFvBQHLJAGtjwmKIPVRSDMoxpCuiqa['tving_pw']or eFvBQHLJAGtjwmKIPVRSDMoxpCuiqs!=eFvBQHLJAGtjwmKIPVRSDMoxpCuiqa['tving_logintype']:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.wininfo_clear()
   return eFvBQHLJAGtjwmKIPVRSDMoxpCuiqE
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyc =eFvBQHLJAGtjwmKIPVRSDMoxpCuidy(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiqn=eFvBQHLJAGtjwmKIPVRSDMoxpCuiqa['tving_limitdate']
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyb =eFvBQHLJAGtjwmKIPVRSDMoxpCuidy(re.sub('-','',eFvBQHLJAGtjwmKIPVRSDMoxpCuiqn))
  if eFvBQHLJAGtjwmKIPVRSDMoxpCuiyb<eFvBQHLJAGtjwmKIPVRSDMoxpCuiyc:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.wininfo_clear()
   return eFvBQHLJAGtjwmKIPVRSDMoxpCuiqE
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyr=xbmcgui.Window(10000)
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyr.setProperty('TVING_M_TOKEN',eFvBQHLJAGtjwmKIPVRSDMoxpCuiqa['tving_token'])
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyr.setProperty('TVING_M_USERINFO',eFvBQHLJAGtjwmKIPVRSDMoxpCuiqa['tving_userinfo'])
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyr.setProperty('TVING_M_UUID',eFvBQHLJAGtjwmKIPVRSDMoxpCuiqa['tving_uuid'])
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiyr.setProperty('TVING_M_LOGINTIME',eFvBQHLJAGtjwmKIPVRSDMoxpCuiqn)
  return eFvBQHLJAGtjwmKIPVRSDMoxpCuidk
 def tving_main(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf):
  eFvBQHLJAGtjwmKIPVRSDMoxpCuiqc=eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.main_params.get('mode',eFvBQHLJAGtjwmKIPVRSDMoxpCuiql)
  if eFvBQHLJAGtjwmKIPVRSDMoxpCuiqc=='LOGOUT':
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.logout()
   return
  eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.login_main()
  if eFvBQHLJAGtjwmKIPVRSDMoxpCuiqc is eFvBQHLJAGtjwmKIPVRSDMoxpCuiql:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.dp_Main_List()
  elif eFvBQHLJAGtjwmKIPVRSDMoxpCuiqc in['LIVE_GROUP','VOD_GROUP']:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.dp_Title_Group(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.main_params)
  elif eFvBQHLJAGtjwmKIPVRSDMoxpCuiqc=='CHANNEL':
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.dp_LiveChannel_List(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.main_params)
  elif eFvBQHLJAGtjwmKIPVRSDMoxpCuiqc in['LIVE','VOD','MOVIE']:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.play_VIDEO(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.main_params)
   time.sleep(0.1)
  elif eFvBQHLJAGtjwmKIPVRSDMoxpCuiqc=='PROGRAM':
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.dp_Program_List(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.main_params)
  elif eFvBQHLJAGtjwmKIPVRSDMoxpCuiqc=='EPISODE':
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.dp_Episode_List(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.main_params)
  elif eFvBQHLJAGtjwmKIPVRSDMoxpCuiqc=='MOVIE_GROUP':
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.dp_Movie_List(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.main_params)
  elif eFvBQHLJAGtjwmKIPVRSDMoxpCuiqc=='SEARCH_GROUP':
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.dp_Search_Group(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.main_params)
  elif eFvBQHLJAGtjwmKIPVRSDMoxpCuiqc=='SEARCH':
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.dp_Search_List(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.main_params)
  elif eFvBQHLJAGtjwmKIPVRSDMoxpCuiqc=='WATCH':
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.dp_Watch_List(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.main_params)
  elif eFvBQHLJAGtjwmKIPVRSDMoxpCuiqc=='MYVIEW_REMOVE':
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.dp_WatchList_Delete(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.main_params)
  elif eFvBQHLJAGtjwmKIPVRSDMoxpCuiqc=='ORDER_BY':
   eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.dp_setEpOrderby(eFvBQHLJAGtjwmKIPVRSDMoxpCuikf.main_params)
  else:
   eFvBQHLJAGtjwmKIPVRSDMoxpCuiql
# Created by pyminifier (https://github.com/liftoff/pyminifier)
