__author__="NightRain"
wxbeohRInzGuYvidNJWTHsLSfgODVk=object
wxbeohRInzGuYvidNJWTHsLSfgODVy=id
wxbeohRInzGuYvidNJWTHsLSfgODVc=int
wxbeohRInzGuYvidNJWTHsLSfgODpm=None
wxbeohRInzGuYvidNJWTHsLSfgODpV=False
wxbeohRInzGuYvidNJWTHsLSfgODpr=print
wxbeohRInzGuYvidNJWTHsLSfgODpC=str
wxbeohRInzGuYvidNJWTHsLSfgODpQ=open
wxbeohRInzGuYvidNJWTHsLSfgODpa=True
wxbeohRInzGuYvidNJWTHsLSfgODpU=Exception
wxbeohRInzGuYvidNJWTHsLSfgODpX=dict
wxbeohRInzGuYvidNJWTHsLSfgODpl=len
import urllib
import re
import json
import requests
import datetime
import base64
import time
from bs4 import BeautifulSoup
class wxbeohRInzGuYvidNJWTHsLSfgODmV(wxbeohRInzGuYvidNJWTHsLSfgODVk):
 def __init__(wxbeohRInzGuYvidNJWTHsLSfgODmp):
  wxbeohRInzGuYvidNJWTHsLSfgODmp.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36'
  wxbeohRInzGuYvidNJWTHsLSfgODmp.DEFAULT_HEADER ={'user-agent':wxbeohRInzGuYvidNJWTHsLSfgODmp.USER_AGENT}
  wxbeohRInzGuYvidNJWTHsLSfgODmp.COOKIE_FILE_SBS =''
  wxbeohRInzGuYvidNJWTHsLSfgODmp.COOKIE_FILE_MBC =''
  wxbeohRInzGuYvidNJWTHsLSfgODmp.SESSION_JSON1=''
  wxbeohRInzGuYvidNJWTHsLSfgODmp.SESSION_JSON2=''
  wxbeohRInzGuYvidNJWTHsLSfgODmp.SESSION_TEXT1=''
  wxbeohRInzGuYvidNJWTHsLSfgODmp.SESSION_TEXT2=''
  wxbeohRInzGuYvidNJWTHsLSfgODmp.ConfigAccout ={}
  wxbeohRInzGuYvidNJWTHsLSfgODmp.SBS={}
  wxbeohRInzGuYvidNJWTHsLSfgODmp.Init_SBS()
  wxbeohRInzGuYvidNJWTHsLSfgODmp.MBC={}
  wxbeohRInzGuYvidNJWTHsLSfgODmp.Init_MBC()
 def Init_SBS(wxbeohRInzGuYvidNJWTHsLSfgODmp):
  wxbeohRInzGuYvidNJWTHsLSfgODmp.SBS={'account':{},'cookies':{},}
 def Init_MBC(wxbeohRInzGuYvidNJWTHsLSfgODmp):
  wxbeohRInzGuYvidNJWTHsLSfgODmp.MBC={'account':{},'cookies':{},}
 def Init_Company(wxbeohRInzGuYvidNJWTHsLSfgODmp,company):
  if company=='SBS':
   wxbeohRInzGuYvidNJWTHsLSfgODmp.Init_SBS()
  elif company=='MBC':
   wxbeohRInzGuYvidNJWTHsLSfgODmp.Init_MBC()
 def Save_session_acount(wxbeohRInzGuYvidNJWTHsLSfgODmp,company,wxbeohRInzGuYvidNJWTHsLSfgODVy,pw):
  if company=='SBS':
   wxbeohRInzGuYvidNJWTHsLSfgODmp.SBS['account']['id'] =base64.standard_b64encode(wxbeohRInzGuYvidNJWTHsLSfgODVy.encode()).decode('utf-8')
   wxbeohRInzGuYvidNJWTHsLSfgODmp.SBS['account']['pw'] =base64.standard_b64encode(pw.encode()).decode('utf-8')
  elif company=='MBC':
   wxbeohRInzGuYvidNJWTHsLSfgODmp.MBC['account']['id'] =base64.standard_b64encode(wxbeohRInzGuYvidNJWTHsLSfgODVy.encode()).decode('utf-8')
   wxbeohRInzGuYvidNJWTHsLSfgODmp.MBC['account']['pw'] =base64.standard_b64encode(pw.encode()).decode('utf-8')
 def Load_session_acount(wxbeohRInzGuYvidNJWTHsLSfgODmp,company):
  try:
   if company=='SBS':
    wxbeohRInzGuYvidNJWTHsLSfgODVy =base64.standard_b64decode(wxbeohRInzGuYvidNJWTHsLSfgODmp.SBS['account']['id']).decode('utf-8')
    pw =base64.standard_b64decode(wxbeohRInzGuYvidNJWTHsLSfgODmp.SBS['account']['pw']).decode('utf-8')
   elif company=='MBC':
    wxbeohRInzGuYvidNJWTHsLSfgODVy =base64.standard_b64decode(wxbeohRInzGuYvidNJWTHsLSfgODmp.MBC['account']['id']).decode('utf-8')
    pw =base64.standard_b64decode(wxbeohRInzGuYvidNJWTHsLSfgODmp.MBC['account']['pw']).decode('utf-8')
  except:
   return '',''
  return wxbeohRInzGuYvidNJWTHsLSfgODVy,pw
 def GetNoCache(wxbeohRInzGuYvidNJWTHsLSfgODmp,timetype=1):
  if timetype==1:
   return wxbeohRInzGuYvidNJWTHsLSfgODVc(time.time())
  else:
   return wxbeohRInzGuYvidNJWTHsLSfgODVc(time.time()*1000)
 def callRequestCookies(wxbeohRInzGuYvidNJWTHsLSfgODmp,jobtype,wxbeohRInzGuYvidNJWTHsLSfgODmP,payload=wxbeohRInzGuYvidNJWTHsLSfgODpm,params=wxbeohRInzGuYvidNJWTHsLSfgODpm,headers=wxbeohRInzGuYvidNJWTHsLSfgODpm,cookies=wxbeohRInzGuYvidNJWTHsLSfgODpm,redirects=wxbeohRInzGuYvidNJWTHsLSfgODpV):
  wxbeohRInzGuYvidNJWTHsLSfgODmr=wxbeohRInzGuYvidNJWTHsLSfgODmp.DEFAULT_HEADER
  if headers:wxbeohRInzGuYvidNJWTHsLSfgODmr.update(headers)
  if jobtype=='Get':
   wxbeohRInzGuYvidNJWTHsLSfgODmC=requests.get(wxbeohRInzGuYvidNJWTHsLSfgODmP,params=params,headers=wxbeohRInzGuYvidNJWTHsLSfgODmr,cookies=cookies,allow_redirects=redirects)
  else:
   wxbeohRInzGuYvidNJWTHsLSfgODmC=requests.post(wxbeohRInzGuYvidNJWTHsLSfgODmP,data=payload,params=params,headers=wxbeohRInzGuYvidNJWTHsLSfgODmr,cookies=cookies,allow_redirects=redirects)
  wxbeohRInzGuYvidNJWTHsLSfgODpr(wxbeohRInzGuYvidNJWTHsLSfgODpC(wxbeohRInzGuYvidNJWTHsLSfgODmC.status_code)+' - '+wxbeohRInzGuYvidNJWTHsLSfgODpC(wxbeohRInzGuYvidNJWTHsLSfgODmC.url))
  return wxbeohRInzGuYvidNJWTHsLSfgODmC
 def Get_Now_Datetime(wxbeohRInzGuYvidNJWTHsLSfgODmp):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def JsonFile_Save(wxbeohRInzGuYvidNJWTHsLSfgODmp,filename,wxbeohRInzGuYvidNJWTHsLSfgODma):
  if filename=='':return wxbeohRInzGuYvidNJWTHsLSfgODpV
  try:
   fp=wxbeohRInzGuYvidNJWTHsLSfgODpQ(filename,'w',-1,'utf-8')
   json.dump(wxbeohRInzGuYvidNJWTHsLSfgODma,fp,indent=4,ensure_ascii=wxbeohRInzGuYvidNJWTHsLSfgODpV)
   fp.close()
  except:
   return wxbeohRInzGuYvidNJWTHsLSfgODpV
  return wxbeohRInzGuYvidNJWTHsLSfgODpa
 def JsonFile_Load(wxbeohRInzGuYvidNJWTHsLSfgODmp,filename):
  if filename=='':return{}
  try:
   fp=wxbeohRInzGuYvidNJWTHsLSfgODpQ(filename,'r',-1,'utf-8')
   wxbeohRInzGuYvidNJWTHsLSfgODmX=json.load(fp)
   fp.close()
  except:
   return{}
  return wxbeohRInzGuYvidNJWTHsLSfgODmX
 def TextFile_Save(wxbeohRInzGuYvidNJWTHsLSfgODmp,filename,resText):
  if filename=='':return wxbeohRInzGuYvidNJWTHsLSfgODpV
  try:
   fp=wxbeohRInzGuYvidNJWTHsLSfgODpQ(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return wxbeohRInzGuYvidNJWTHsLSfgODpV
  return wxbeohRInzGuYvidNJWTHsLSfgODpa
 def Get_ChannalList_KBS(wxbeohRInzGuYvidNJWTHsLSfgODmp):
  wxbeohRInzGuYvidNJWTHsLSfgODml=[]
  try:
   wxbeohRInzGuYvidNJWTHsLSfgODmP='https://onair.kbs.co.kr/'
   wxbeohRInzGuYvidNJWTHsLSfgODmE=wxbeohRInzGuYvidNJWTHsLSfgODmp.callRequestCookies('Get',wxbeohRInzGuYvidNJWTHsLSfgODmP,payload=wxbeohRInzGuYvidNJWTHsLSfgODpm,params=wxbeohRInzGuYvidNJWTHsLSfgODpm,headers=wxbeohRInzGuYvidNJWTHsLSfgODpm,cookies=wxbeohRInzGuYvidNJWTHsLSfgODpm,redirects=wxbeohRInzGuYvidNJWTHsLSfgODpa)
   if wxbeohRInzGuYvidNJWTHsLSfgODmE.status_code!=200:return[]
   wxbeohRInzGuYvidNJWTHsLSfgODmK =r"window.adminChannelList = JSON.parse\(\'(.*?)'\);"
   wxbeohRInzGuYvidNJWTHsLSfgODmj=re.compile(wxbeohRInzGuYvidNJWTHsLSfgODmK,re.DOTALL).findall(wxbeohRInzGuYvidNJWTHsLSfgODmE.text)[0]
   wxbeohRInzGuYvidNJWTHsLSfgODmt=wxbeohRInzGuYvidNJWTHsLSfgODmj.replace('\\\"','\"')
   wxbeohRInzGuYvidNJWTHsLSfgODmq=json.loads(wxbeohRInzGuYvidNJWTHsLSfgODmt)
   for wxbeohRInzGuYvidNJWTHsLSfgODmA in wxbeohRInzGuYvidNJWTHsLSfgODmq.get('channel'):
    if wxbeohRInzGuYvidNJWTHsLSfgODmA.get('channel_group').startswith('G')==wxbeohRInzGuYvidNJWTHsLSfgODpV:continue
    for wxbeohRInzGuYvidNJWTHsLSfgODmF in wxbeohRInzGuYvidNJWTHsLSfgODmA.get('channel_master'):
     wxbeohRInzGuYvidNJWTHsLSfgODmB={'company':'kbs','channelNm':wxbeohRInzGuYvidNJWTHsLSfgODmF.get('title'),'logo':wxbeohRInzGuYvidNJWTHsLSfgODmF.get('image_path_channel_logo'),'thumbnail':wxbeohRInzGuYvidNJWTHsLSfgODmF.get('image_path_video_thumbnail'),'channlCode':wxbeohRInzGuYvidNJWTHsLSfgODmF.get('channel_code'),}
     wxbeohRInzGuYvidNJWTHsLSfgODml.append(wxbeohRInzGuYvidNJWTHsLSfgODmB)
  except wxbeohRInzGuYvidNJWTHsLSfgODpU as exception:
   wxbeohRInzGuYvidNJWTHsLSfgODpr(exception)
   return[]
  return wxbeohRInzGuYvidNJWTHsLSfgODml
 def Get_ChannalList_SBS(wxbeohRInzGuYvidNJWTHsLSfgODmp):
  wxbeohRInzGuYvidNJWTHsLSfgODml=[]
  try:
   wxbeohRInzGuYvidNJWTHsLSfgODmP='https://apis.sbs.co.kr/play-api/1.0/onair/channels'
   wxbeohRInzGuYvidNJWTHsLSfgODmE=wxbeohRInzGuYvidNJWTHsLSfgODmp.callRequestCookies('Get',wxbeohRInzGuYvidNJWTHsLSfgODmP,payload=wxbeohRInzGuYvidNJWTHsLSfgODpm,params=wxbeohRInzGuYvidNJWTHsLSfgODpm,headers=wxbeohRInzGuYvidNJWTHsLSfgODpm,cookies=wxbeohRInzGuYvidNJWTHsLSfgODpm,redirects=wxbeohRInzGuYvidNJWTHsLSfgODpa)
   if wxbeohRInzGuYvidNJWTHsLSfgODmE.status_code!=200:return[]
   wxbeohRInzGuYvidNJWTHsLSfgODmq=json.loads(wxbeohRInzGuYvidNJWTHsLSfgODmE.text)
   for wxbeohRInzGuYvidNJWTHsLSfgODmM in wxbeohRInzGuYvidNJWTHsLSfgODmq.get('list'):
    if wxbeohRInzGuYvidNJWTHsLSfgODmM['type']=='TV':
     wxbeohRInzGuYvidNJWTHsLSfgODmB={'company':'sbs','channelNm':wxbeohRInzGuYvidNJWTHsLSfgODmM.get('channelname'),'logo':'','thumbnail':wxbeohRInzGuYvidNJWTHsLSfgODmM.get('thumbimg'),'channlCode':wxbeohRInzGuYvidNJWTHsLSfgODmM.get('channelid'),}
     wxbeohRInzGuYvidNJWTHsLSfgODml.append(wxbeohRInzGuYvidNJWTHsLSfgODmB)
  except wxbeohRInzGuYvidNJWTHsLSfgODpU as exception:
   wxbeohRInzGuYvidNJWTHsLSfgODpr(exception)
   return[]
  return wxbeohRInzGuYvidNJWTHsLSfgODml
 def Get_ChannalList_MBC(wxbeohRInzGuYvidNJWTHsLSfgODmp):
  wxbeohRInzGuYvidNJWTHsLSfgODml=[]
  try:
   t =wxbeohRInzGuYvidNJWTHsLSfgODmp.Get_Now_Datetime().strftime('%Y%m%d%H%M')
   wxbeohRInzGuYvidNJWTHsLSfgODmP='https://control.imbc.com/Schedule/ONAIRWITHNVOD?t='+t
   wxbeohRInzGuYvidNJWTHsLSfgODmE=wxbeohRInzGuYvidNJWTHsLSfgODmp.callRequestCookies('Get',wxbeohRInzGuYvidNJWTHsLSfgODmP,payload=wxbeohRInzGuYvidNJWTHsLSfgODpm,params=wxbeohRInzGuYvidNJWTHsLSfgODpm,headers=wxbeohRInzGuYvidNJWTHsLSfgODpm,cookies=wxbeohRInzGuYvidNJWTHsLSfgODpm,redirects=wxbeohRInzGuYvidNJWTHsLSfgODpa)
   if wxbeohRInzGuYvidNJWTHsLSfgODmE.status_code!=200:return[]
   wxbeohRInzGuYvidNJWTHsLSfgODmq=json.loads(wxbeohRInzGuYvidNJWTHsLSfgODmE.text)
   for wxbeohRInzGuYvidNJWTHsLSfgODmM in wxbeohRInzGuYvidNJWTHsLSfgODmq:
    if wxbeohRInzGuYvidNJWTHsLSfgODmM['Type']not in['TV','MBCPLUS']:continue
    wxbeohRInzGuYvidNJWTHsLSfgODmB={'company':'mbc','channelNm':wxbeohRInzGuYvidNJWTHsLSfgODmM.get('TypeTitle'),'logo':'','thumbnail':wxbeohRInzGuYvidNJWTHsLSfgODmM.get('OnAirImage'),'channlCode':wxbeohRInzGuYvidNJWTHsLSfgODmM.get('MediaCode'),'programTitle':wxbeohRInzGuYvidNJWTHsLSfgODmM.get('Title'),}
    wxbeohRInzGuYvidNJWTHsLSfgODml.append(wxbeohRInzGuYvidNJWTHsLSfgODmB)
  except wxbeohRInzGuYvidNJWTHsLSfgODpU as exception:
   wxbeohRInzGuYvidNJWTHsLSfgODpr(exception)
   return[]
  return wxbeohRInzGuYvidNJWTHsLSfgODml
 def Get_StreamingURL_KBS(wxbeohRInzGuYvidNJWTHsLSfgODmp,channelCode):
  wxbeohRInzGuYvidNJWTHsLSfgODmk=''
  try:
   wxbeohRInzGuYvidNJWTHsLSfgODmP='https://cfpwwwapi.kbs.co.kr/api/v1/landing/live/channel_code/'+channelCode
   wxbeohRInzGuYvidNJWTHsLSfgODmE=wxbeohRInzGuYvidNJWTHsLSfgODmp.callRequestCookies('Get',wxbeohRInzGuYvidNJWTHsLSfgODmP,payload=wxbeohRInzGuYvidNJWTHsLSfgODpm,params=wxbeohRInzGuYvidNJWTHsLSfgODpm,headers=wxbeohRInzGuYvidNJWTHsLSfgODpm,cookies=wxbeohRInzGuYvidNJWTHsLSfgODpm)
   if wxbeohRInzGuYvidNJWTHsLSfgODmE.status_code!=200:return ''
   wxbeohRInzGuYvidNJWTHsLSfgODmq=json.loads(wxbeohRInzGuYvidNJWTHsLSfgODmE.text)
   for wxbeohRInzGuYvidNJWTHsLSfgODmy in wxbeohRInzGuYvidNJWTHsLSfgODmq.get('channel_item'):
    if wxbeohRInzGuYvidNJWTHsLSfgODmy.get('media_type')=='tv': 
     wxbeohRInzGuYvidNJWTHsLSfgODmk=wxbeohRInzGuYvidNJWTHsLSfgODmy.get('service_url')
     break
   if wxbeohRInzGuYvidNJWTHsLSfgODmk=='':
    for wxbeohRInzGuYvidNJWTHsLSfgODmy in wxbeohRInzGuYvidNJWTHsLSfgODmq.get('channel_item'):
     if wxbeohRInzGuYvidNJWTHsLSfgODmy.get('media_type')=='HTTPS':
      wxbeohRInzGuYvidNJWTHsLSfgODmk=wxbeohRInzGuYvidNJWTHsLSfgODmy.get('service_url')
      break
  except wxbeohRInzGuYvidNJWTHsLSfgODpU as exception:
   wxbeohRInzGuYvidNJWTHsLSfgODpr(exception)
   return ''
  return wxbeohRInzGuYvidNJWTHsLSfgODmk
 def Get_StreamingURL_SBS(wxbeohRInzGuYvidNJWTHsLSfgODmp,channelCode):
  try:
   if channelCode=='S29':
    wxbeohRInzGuYvidNJWTHsLSfgODmP='https://apis.sbs.co.kr/play-api/1.0/onair/binge-watch/channel/'+channelCode
   else:
    wxbeohRInzGuYvidNJWTHsLSfgODmP='https://apis.sbs.co.kr/play-api/1.0/onair/channel/'+channelCode
   wxbeohRInzGuYvidNJWTHsLSfgODmc={'v_type':'2','platform':'pcweb','protocol':'hls','ssl':'Y','rscuse':'','extra':'','jwt-token':wxbeohRInzGuYvidNJWTHsLSfgODmp.SBS['cookies']['LOGIN_JWT'],}
   wxbeohRInzGuYvidNJWTHsLSfgODmE=wxbeohRInzGuYvidNJWTHsLSfgODmp.callRequestCookies('Get',wxbeohRInzGuYvidNJWTHsLSfgODmP,payload=wxbeohRInzGuYvidNJWTHsLSfgODpm,params=wxbeohRInzGuYvidNJWTHsLSfgODmc,headers=wxbeohRInzGuYvidNJWTHsLSfgODpm,cookies=wxbeohRInzGuYvidNJWTHsLSfgODpm)
   if wxbeohRInzGuYvidNJWTHsLSfgODmE.status_code!=200:return ''
   wxbeohRInzGuYvidNJWTHsLSfgODmq=json.loads(wxbeohRInzGuYvidNJWTHsLSfgODmE.text)
   wxbeohRInzGuYvidNJWTHsLSfgODmk=wxbeohRInzGuYvidNJWTHsLSfgODmq['onair']['source']['mediasource']['mediaurl']
  except wxbeohRInzGuYvidNJWTHsLSfgODpU as exception:
   wxbeohRInzGuYvidNJWTHsLSfgODpr(exception)
   return ''
  return wxbeohRInzGuYvidNJWTHsLSfgODmk
 def Change_Token_SBS(wxbeohRInzGuYvidNJWTHsLSfgODmp,wxbeohRInzGuYvidNJWTHsLSfgODVU):
  wxbeohRInzGuYvidNJWTHsLSfgODVm =urllib.parse.urlparse(wxbeohRInzGuYvidNJWTHsLSfgODVU)
  wxbeohRInzGuYvidNJWTHsLSfgODVp =wxbeohRInzGuYvidNJWTHsLSfgODpX(urllib.parse.parse_qsl(wxbeohRInzGuYvidNJWTHsLSfgODVm.query))
  wxbeohRInzGuYvidNJWTHsLSfgODVr=wxbeohRInzGuYvidNJWTHsLSfgODVp['token'].split('.')
  wxbeohRInzGuYvidNJWTHsLSfgODVC=wxbeohRInzGuYvidNJWTHsLSfgODVr[1]
  wxbeohRInzGuYvidNJWTHsLSfgODVC+='='*((4-wxbeohRInzGuYvidNJWTHsLSfgODpl(wxbeohRInzGuYvidNJWTHsLSfgODVC)%4)%4)
  wxbeohRInzGuYvidNJWTHsLSfgODVQ=base64.standard_b64decode(wxbeohRInzGuYvidNJWTHsLSfgODVC).decode('utf-8')
  wxbeohRInzGuYvidNJWTHsLSfgODVQ=json.loads(wxbeohRInzGuYvidNJWTHsLSfgODVQ)
  wxbeohRInzGuYvidNJWTHsLSfgODVQ['duration']=-1 
  wxbeohRInzGuYvidNJWTHsLSfgODVQ['exp'] =wxbeohRInzGuYvidNJWTHsLSfgODVc((datetime.datetime.fromtimestamp(wxbeohRInzGuYvidNJWTHsLSfgODVQ['iat'])+datetime.timedelta(hours=2)).timestamp())
  wxbeohRInzGuYvidNJWTHsLSfgODpr(wxbeohRInzGuYvidNJWTHsLSfgODVQ)
  wxbeohRInzGuYvidNJWTHsLSfgODVQ=json.dumps(wxbeohRInzGuYvidNJWTHsLSfgODVQ,separators=(',',':'))
  wxbeohRInzGuYvidNJWTHsLSfgODVa =base64.standard_b64encode(wxbeohRInzGuYvidNJWTHsLSfgODVQ.encode()).decode('utf-8').strip('=')
  wxbeohRInzGuYvidNJWTHsLSfgODVU=wxbeohRInzGuYvidNJWTHsLSfgODVU.replace(wxbeohRInzGuYvidNJWTHsLSfgODVr[1],wxbeohRInzGuYvidNJWTHsLSfgODVa)
  return wxbeohRInzGuYvidNJWTHsLSfgODVU
 def Get_StreamingURL_MBC(wxbeohRInzGuYvidNJWTHsLSfgODmp,channelCode):
  try:
   t =wxbeohRInzGuYvidNJWTHsLSfgODmp.GetNoCache(timetype=2)
   ch=wxbeohRInzGuYvidNJWTHsLSfgODVc(channelCode)
   if ch==0:
    wxbeohRInzGuYvidNJWTHsLSfgODmP='https://mediaapi.imbc.com/Player/OnAirURLUtil?type=PC&t={}'.format(t)
    wxbeohRInzGuYvidNJWTHsLSfgODVX='1'
   elif(ch>12 and ch<17)or ch==18:
    ch=ch-12
    wxbeohRInzGuYvidNJWTHsLSfgODmP='https://mediaapi.imbc.com/Player/OnAirPlusURLUtil?ch={}&type=PC&t={}'.format(ch,t)
    wxbeohRInzGuYvidNJWTHsLSfgODVX='2'
   else:
    wxbeohRInzGuYvidNJWTHsLSfgODmP='https://mediaapi.imbc.com/Player/NVodURLUtil?type=PC&chid={}&t={}'.format(ch,t)
    wxbeohRInzGuYvidNJWTHsLSfgODVX='3'
   wxbeohRInzGuYvidNJWTHsLSfgODVl=wxbeohRInzGuYvidNJWTHsLSfgODmp.MBC['cookies']
   wxbeohRInzGuYvidNJWTHsLSfgODVP={'Referer':'https://onair.imbc.com/?chid={}'.format(channelCode)}
   wxbeohRInzGuYvidNJWTHsLSfgODmE=wxbeohRInzGuYvidNJWTHsLSfgODmp.callRequestCookies('Get',wxbeohRInzGuYvidNJWTHsLSfgODmP,payload=wxbeohRInzGuYvidNJWTHsLSfgODpm,params=wxbeohRInzGuYvidNJWTHsLSfgODpm,headers=wxbeohRInzGuYvidNJWTHsLSfgODVP,cookies=wxbeohRInzGuYvidNJWTHsLSfgODVl)
   if wxbeohRInzGuYvidNJWTHsLSfgODmE.status_code!=200:return ''
   wxbeohRInzGuYvidNJWTHsLSfgODmq=json.loads(wxbeohRInzGuYvidNJWTHsLSfgODmE.text)
   if wxbeohRInzGuYvidNJWTHsLSfgODVX!='3':
    wxbeohRInzGuYvidNJWTHsLSfgODmk=wxbeohRInzGuYvidNJWTHsLSfgODmq['MediaInfo']['MediaURL']
   else:
    wxbeohRInzGuYvidNJWTHsLSfgODmk=wxbeohRInzGuYvidNJWTHsLSfgODmq['MediaURL']
  except wxbeohRInzGuYvidNJWTHsLSfgODpU as exception:
   wxbeohRInzGuYvidNJWTHsLSfgODpr(exception)
   return ''
  return wxbeohRInzGuYvidNJWTHsLSfgODmk
 def Login_SBS(wxbeohRInzGuYvidNJWTHsLSfgODmp,sbsid,sbspw,ttl):
  wxbeohRInzGuYvidNJWTHsLSfgODmP='https://join.sbs.co.kr/login/login.do?div=gnb_pc&returnUrl=https%3A%2F%2Fwww.sbs.co.kr%2F%3Fdiv%3Dgnb_pc'
  wxbeohRInzGuYvidNJWTHsLSfgODmE=wxbeohRInzGuYvidNJWTHsLSfgODmp.callRequestCookies('Get',wxbeohRInzGuYvidNJWTHsLSfgODmP,payload=wxbeohRInzGuYvidNJWTHsLSfgODpm,params=wxbeohRInzGuYvidNJWTHsLSfgODpm,headers=wxbeohRInzGuYvidNJWTHsLSfgODpm,cookies=wxbeohRInzGuYvidNJWTHsLSfgODpm)
  if wxbeohRInzGuYvidNJWTHsLSfgODmE.status_code!=200:return wxbeohRInzGuYvidNJWTHsLSfgODpV
  wxbeohRInzGuYvidNJWTHsLSfgODVE =BeautifulSoup(wxbeohRInzGuYvidNJWTHsLSfgODmE.text,'html.parser')
  wxbeohRInzGuYvidNJWTHsLSfgODVK=wxbeohRInzGuYvidNJWTHsLSfgODVE.select_one('#loginPageCheck').get('value')
  for wxbeohRInzGuYvidNJWTHsLSfgODVj in wxbeohRInzGuYvidNJWTHsLSfgODmE.cookies:
   wxbeohRInzGuYvidNJWTHsLSfgODmp.SBS['cookies'][wxbeohRInzGuYvidNJWTHsLSfgODVj.name]=wxbeohRInzGuYvidNJWTHsLSfgODVj.value
  wxbeohRInzGuYvidNJWTHsLSfgODmp.SBS['cookies']['auto_login']='Y'
  wxbeohRInzGuYvidNJWTHsLSfgODmP='https://join.sbs.co.kr/login/ajax/passwdEnc.do'
  wxbeohRInzGuYvidNJWTHsLSfgODVt={'passwd':sbspw}
  wxbeohRInzGuYvidNJWTHsLSfgODmE=wxbeohRInzGuYvidNJWTHsLSfgODmp.callRequestCookies('Post',wxbeohRInzGuYvidNJWTHsLSfgODmP,payload=wxbeohRInzGuYvidNJWTHsLSfgODVt,params=wxbeohRInzGuYvidNJWTHsLSfgODpm,headers=wxbeohRInzGuYvidNJWTHsLSfgODpm,cookies=wxbeohRInzGuYvidNJWTHsLSfgODmp.SBS['cookies'])
  if wxbeohRInzGuYvidNJWTHsLSfgODmE.status_code!=200:return wxbeohRInzGuYvidNJWTHsLSfgODpV
  for wxbeohRInzGuYvidNJWTHsLSfgODVj in wxbeohRInzGuYvidNJWTHsLSfgODmE.cookies:
   wxbeohRInzGuYvidNJWTHsLSfgODmp.SBS['cookies'][wxbeohRInzGuYvidNJWTHsLSfgODVj.name]=wxbeohRInzGuYvidNJWTHsLSfgODVj.value
  wxbeohRInzGuYvidNJWTHsLSfgODVq=json.loads(wxbeohRInzGuYvidNJWTHsLSfgODmE.text)
  wxbeohRInzGuYvidNJWTHsLSfgODmP='https://join.sbs.co.kr/login/loginChk.do'
  wxbeohRInzGuYvidNJWTHsLSfgODVt={'return_url':'https://www.sbs.co.kr/?div=gnb_pc','web_app':'','lang':'k','loginPageCheck':wxbeohRInzGuYvidNJWTHsLSfgODVK,'passwd_1':wxbeohRInzGuYvidNJWTHsLSfgODVq['passwd_1'],'passwd_2':wxbeohRInzGuYvidNJWTHsLSfgODVq['passwd_2'],'alg':'1','NAVER_CLIENT_ID':'','id':sbsid,'passwd':'','checksavelogin':'on',}
  wxbeohRInzGuYvidNJWTHsLSfgODmE=wxbeohRInzGuYvidNJWTHsLSfgODmp.callRequestCookies('Post',wxbeohRInzGuYvidNJWTHsLSfgODmP,payload=wxbeohRInzGuYvidNJWTHsLSfgODVt,params=wxbeohRInzGuYvidNJWTHsLSfgODpm,headers=wxbeohRInzGuYvidNJWTHsLSfgODpm,cookies=wxbeohRInzGuYvidNJWTHsLSfgODmp.SBS['cookies'])
  if wxbeohRInzGuYvidNJWTHsLSfgODmE.status_code not in[200,302]:return wxbeohRInzGuYvidNJWTHsLSfgODpV
  for wxbeohRInzGuYvidNJWTHsLSfgODVj in wxbeohRInzGuYvidNJWTHsLSfgODmE.cookies:
   wxbeohRInzGuYvidNJWTHsLSfgODmp.SBS['cookies'][wxbeohRInzGuYvidNJWTHsLSfgODVj.name]=wxbeohRInzGuYvidNJWTHsLSfgODVj.value
  wxbeohRInzGuYvidNJWTHsLSfgODmp.Save_session_acount('SBS',sbsid,sbspw)
  wxbeohRInzGuYvidNJWTHsLSfgODVA =wxbeohRInzGuYvidNJWTHsLSfgODmp.Get_Now_Datetime()
  wxbeohRInzGuYvidNJWTHsLSfgODVF=wxbeohRInzGuYvidNJWTHsLSfgODVA+datetime.timedelta(days=ttl)
  wxbeohRInzGuYvidNJWTHsLSfgODmp.SBS['account']['token_limit']=wxbeohRInzGuYvidNJWTHsLSfgODVF.strftime('%Y%m%d')
  wxbeohRInzGuYvidNJWTHsLSfgODmp.JsonFile_Save(wxbeohRInzGuYvidNJWTHsLSfgODmp.COOKIE_FILE_SBS,wxbeohRInzGuYvidNJWTHsLSfgODmp.SBS)
  return wxbeohRInzGuYvidNJWTHsLSfgODpa
 def Login_MBC(wxbeohRInzGuYvidNJWTHsLSfgODmp,mbcid,mbcpw,ttl):
  wxbeohRInzGuYvidNJWTHsLSfgODVB=''
  wxbeohRInzGuYvidNJWTHsLSfgODmP='https://member.imbc.com/Login/Login.aspx'
  wxbeohRInzGuYvidNJWTHsLSfgODmE=wxbeohRInzGuYvidNJWTHsLSfgODmp.callRequestCookies('Get',wxbeohRInzGuYvidNJWTHsLSfgODmP,payload=wxbeohRInzGuYvidNJWTHsLSfgODpm,params=wxbeohRInzGuYvidNJWTHsLSfgODpm,headers=wxbeohRInzGuYvidNJWTHsLSfgODpm,cookies=wxbeohRInzGuYvidNJWTHsLSfgODpm)
  if wxbeohRInzGuYvidNJWTHsLSfgODmE.status_code!=200:return wxbeohRInzGuYvidNJWTHsLSfgODpV,wxbeohRInzGuYvidNJWTHsLSfgODVB
  for wxbeohRInzGuYvidNJWTHsLSfgODVj in wxbeohRInzGuYvidNJWTHsLSfgODmE.cookies:
   wxbeohRInzGuYvidNJWTHsLSfgODmp.MBC['cookies'][wxbeohRInzGuYvidNJWTHsLSfgODVj.name]=wxbeohRInzGuYvidNJWTHsLSfgODVj.value
  wxbeohRInzGuYvidNJWTHsLSfgODpr(wxbeohRInzGuYvidNJWTHsLSfgODmp.MBC['cookies'])
  wxbeohRInzGuYvidNJWTHsLSfgODmP='https://member.imbc.com/Login/LoginProcess.aspx'
  wxbeohRInzGuYvidNJWTHsLSfgODVt={'TemplateID':'main','TURL':'','confirmMsg':'','IdsafeURL':'','AdultYN':'n','AppID':'','SNSType':'','Uid':mbcid,'Password':mbcpw,}
  wxbeohRInzGuYvidNJWTHsLSfgODmE=wxbeohRInzGuYvidNJWTHsLSfgODmp.callRequestCookies('Post',wxbeohRInzGuYvidNJWTHsLSfgODmP,payload=wxbeohRInzGuYvidNJWTHsLSfgODVt,params=wxbeohRInzGuYvidNJWTHsLSfgODpm,headers=wxbeohRInzGuYvidNJWTHsLSfgODpm,cookies=wxbeohRInzGuYvidNJWTHsLSfgODmp.MBC['cookies'])
  if wxbeohRInzGuYvidNJWTHsLSfgODmE.status_code==302:
   if 'ChangePW90Days.aspx' in wxbeohRInzGuYvidNJWTHsLSfgODmE.headers.get('location'):
    wxbeohRInzGuYvidNJWTHsLSfgODVB='비밀번호 변경필요(90일초과)'
    for wxbeohRInzGuYvidNJWTHsLSfgODVj in wxbeohRInzGuYvidNJWTHsLSfgODmE.cookies:
     wxbeohRInzGuYvidNJWTHsLSfgODmp.MBC['cookies'][wxbeohRInzGuYvidNJWTHsLSfgODVj.name]=wxbeohRInzGuYvidNJWTHsLSfgODVj.value
    wxbeohRInzGuYvidNJWTHsLSfgODpr(wxbeohRInzGuYvidNJWTHsLSfgODmp.MBC['cookies'])
    wxbeohRInzGuYvidNJWTHsLSfgODVM='https://member.imbc.com/api/info/NextReChangePW.ashx'
    wxbeohRInzGuYvidNJWTHsLSfgODVl=wxbeohRInzGuYvidNJWTHsLSfgODmp.MBC['cookies']
    wxbeohRInzGuYvidNJWTHsLSfgODmE=wxbeohRInzGuYvidNJWTHsLSfgODmp.callRequestCookies('Post',wxbeohRInzGuYvidNJWTHsLSfgODVM,payload=wxbeohRInzGuYvidNJWTHsLSfgODpm,params=wxbeohRInzGuYvidNJWTHsLSfgODpm,headers=wxbeohRInzGuYvidNJWTHsLSfgODpm,cookies=wxbeohRInzGuYvidNJWTHsLSfgODVl)
    if wxbeohRInzGuYvidNJWTHsLSfgODmE.status_code!=200:return wxbeohRInzGuYvidNJWTHsLSfgODpV,wxbeohRInzGuYvidNJWTHsLSfgODVB
  if wxbeohRInzGuYvidNJWTHsLSfgODmE.status_code!=200:return wxbeohRInzGuYvidNJWTHsLSfgODpV,wxbeohRInzGuYvidNJWTHsLSfgODVB
  for wxbeohRInzGuYvidNJWTHsLSfgODVj in wxbeohRInzGuYvidNJWTHsLSfgODmE.cookies:
   wxbeohRInzGuYvidNJWTHsLSfgODmp.MBC['cookies'][wxbeohRInzGuYvidNJWTHsLSfgODVj.name]=wxbeohRInzGuYvidNJWTHsLSfgODVj.value
  wxbeohRInzGuYvidNJWTHsLSfgODmp.Save_session_acount('MBC',mbcid,mbcpw)
  wxbeohRInzGuYvidNJWTHsLSfgODVA =wxbeohRInzGuYvidNJWTHsLSfgODmp.Get_Now_Datetime()
  wxbeohRInzGuYvidNJWTHsLSfgODVF=wxbeohRInzGuYvidNJWTHsLSfgODVA+datetime.timedelta(days=ttl)
  wxbeohRInzGuYvidNJWTHsLSfgODmp.MBC['account']['token_limit']=wxbeohRInzGuYvidNJWTHsLSfgODVF.strftime('%Y%m%d')
  wxbeohRInzGuYvidNJWTHsLSfgODmp.JsonFile_Save(wxbeohRInzGuYvidNJWTHsLSfgODmp.COOKIE_FILE_MBC,wxbeohRInzGuYvidNJWTHsLSfgODmp.MBC)
  return wxbeohRInzGuYvidNJWTHsLSfgODpa,wxbeohRInzGuYvidNJWTHsLSfgODVB
# Created by pyminifier (https://github.com/liftoff/pyminifier)
