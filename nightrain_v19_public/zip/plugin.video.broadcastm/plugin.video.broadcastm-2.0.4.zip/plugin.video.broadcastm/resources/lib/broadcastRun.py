__author__="NightRain"
pGqUzhuyOLmdwcTrPDvIaHJBClgxEQ=object
pGqUzhuyOLmdwcTrPDvIaHJBClgxEi=None
pGqUzhuyOLmdwcTrPDvIaHJBClgxEf=True
pGqUzhuyOLmdwcTrPDvIaHJBClgxEX=False
pGqUzhuyOLmdwcTrPDvIaHJBClgxEA=type
pGqUzhuyOLmdwcTrPDvIaHJBClgxEb=dict
pGqUzhuyOLmdwcTrPDvIaHJBClgxEt=int
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
pGqUzhuyOLmdwcTrPDvIaHJBClgxoE=[{'title':'KBS','mode':'CHANNEL_LIST','sType':'kbs','icon':'kbs.png'},{'title':'SBS - 로그인필요','mode':'CHANNEL_LIST','sType':'sbs','icon':'sbs.png'},{'title':'MBC - 로그인필요','mode':'CHANNEL_LIST','sType':'mbc','icon':'mbc.png'},]
from broadcastCore import*
class pGqUzhuyOLmdwcTrPDvIaHJBClgxoQ(pGqUzhuyOLmdwcTrPDvIaHJBClgxEQ):
 def __init__(pGqUzhuyOLmdwcTrPDvIaHJBClgxoi,pGqUzhuyOLmdwcTrPDvIaHJBClgxof,pGqUzhuyOLmdwcTrPDvIaHJBClgxoX,pGqUzhuyOLmdwcTrPDvIaHJBClgxoA):
  pGqUzhuyOLmdwcTrPDvIaHJBClgxoi._addon_url =pGqUzhuyOLmdwcTrPDvIaHJBClgxof
  pGqUzhuyOLmdwcTrPDvIaHJBClgxoi._addon_handle=pGqUzhuyOLmdwcTrPDvIaHJBClgxoX
  pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.main_params =pGqUzhuyOLmdwcTrPDvIaHJBClgxoA
  pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.BroadcastObj =wxbeohRInzGuYvidNJWTHsLSfgODmV() 
  pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.BroadcastObj.COOKIE_FILE_SBS=xbmcvfs.translatePath(os.path.join(__profile__,'cookies_sbs.json'))
  pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.BroadcastObj.COOKIE_FILE_MBC=xbmcvfs.translatePath(os.path.join(__profile__,'cookies_mbc.json'))
  pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.BroadcastObj.SESSION_JSON1 =xbmcvfs.translatePath(os.path.join(__profile__,'broad_cookies1.json'))
 def addon_noti(pGqUzhuyOLmdwcTrPDvIaHJBClgxoi,sting):
  try:
   pGqUzhuyOLmdwcTrPDvIaHJBClgxot=xbmcgui.Dialog()
   pGqUzhuyOLmdwcTrPDvIaHJBClgxot.notification(__addonname__,sting)
  except:
   pGqUzhuyOLmdwcTrPDvIaHJBClgxEi
 def addon_log(pGqUzhuyOLmdwcTrPDvIaHJBClgxoi,string):
  try:
   pGqUzhuyOLmdwcTrPDvIaHJBClgxoF=string.encode('utf-8','ignore')
  except:
   pGqUzhuyOLmdwcTrPDvIaHJBClgxoF='addonException: addon_log'
  pGqUzhuyOLmdwcTrPDvIaHJBClgxoW=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,pGqUzhuyOLmdwcTrPDvIaHJBClgxoF),level=pGqUzhuyOLmdwcTrPDvIaHJBClgxoW)
 def add_dir(pGqUzhuyOLmdwcTrPDvIaHJBClgxoi,label,sublabel='',img='',infoLabels=pGqUzhuyOLmdwcTrPDvIaHJBClgxEi,isFolder=pGqUzhuyOLmdwcTrPDvIaHJBClgxEf,params='',isLink=pGqUzhuyOLmdwcTrPDvIaHJBClgxEX,ContextMenu=pGqUzhuyOLmdwcTrPDvIaHJBClgxEi):
  pGqUzhuyOLmdwcTrPDvIaHJBClgxon='%s?%s'%(pGqUzhuyOLmdwcTrPDvIaHJBClgxoi._addon_url,urllib.parse.urlencode(params))
  if sublabel:pGqUzhuyOLmdwcTrPDvIaHJBClgxoe='%s < %s >'%(label,sublabel)
  else: pGqUzhuyOLmdwcTrPDvIaHJBClgxoe=label
  if not img:img='DefaultFolder.png'
  pGqUzhuyOLmdwcTrPDvIaHJBClgxoY=xbmcgui.ListItem(pGqUzhuyOLmdwcTrPDvIaHJBClgxoe)
  if pGqUzhuyOLmdwcTrPDvIaHJBClgxEA(img)==pGqUzhuyOLmdwcTrPDvIaHJBClgxEb:
   pGqUzhuyOLmdwcTrPDvIaHJBClgxoY.setArt(img)
  else:
   pGqUzhuyOLmdwcTrPDvIaHJBClgxoY.setArt({'thumb':img,'poster':img})
  if infoLabels:pGqUzhuyOLmdwcTrPDvIaHJBClgxoY.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   pGqUzhuyOLmdwcTrPDvIaHJBClgxoY.setProperty('IsPlayable','true')
  if ContextMenu:pGqUzhuyOLmdwcTrPDvIaHJBClgxoY.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(pGqUzhuyOLmdwcTrPDvIaHJBClgxoi._addon_handle,pGqUzhuyOLmdwcTrPDvIaHJBClgxon,pGqUzhuyOLmdwcTrPDvIaHJBClgxoY,isFolder)
 def get_settings_company(pGqUzhuyOLmdwcTrPDvIaHJBClgxoi):
  pGqUzhuyOLmdwcTrPDvIaHJBClgxoS=pGqUzhuyOLmdwcTrPDvIaHJBClgxEf if __addon__.getSetting('sbs_yn')=='true' else pGqUzhuyOLmdwcTrPDvIaHJBClgxEX
  pGqUzhuyOLmdwcTrPDvIaHJBClgxoR=pGqUzhuyOLmdwcTrPDvIaHJBClgxEf if __addon__.getSetting('mbc_yn')=='true' else pGqUzhuyOLmdwcTrPDvIaHJBClgxEX
  pGqUzhuyOLmdwcTrPDvIaHJBClgxoM={'sbs_yn':pGqUzhuyOLmdwcTrPDvIaHJBClgxoS,'mbc_yn':pGqUzhuyOLmdwcTrPDvIaHJBClgxoR,}
  return pGqUzhuyOLmdwcTrPDvIaHJBClgxoM
 def get_settings_account(pGqUzhuyOLmdwcTrPDvIaHJBClgxoi,pGqUzhuyOLmdwcTrPDvIaHJBClgxQX):
  if pGqUzhuyOLmdwcTrPDvIaHJBClgxQX=='SBS':
   pGqUzhuyOLmdwcTrPDvIaHJBClgxoj={'id':__addon__.getSetting('sbs_id'),'pw':__addon__.getSetting('sbs_pw'),'ttl':1,}
  elif pGqUzhuyOLmdwcTrPDvIaHJBClgxQX=='MBC':
   pGqUzhuyOLmdwcTrPDvIaHJBClgxoj={'id':__addon__.getSetting('mbc_id'),'pw':__addon__.getSetting('mbc_pw'),'ttl':1,}
  return pGqUzhuyOLmdwcTrPDvIaHJBClgxoj
 def dp_Main_List(pGqUzhuyOLmdwcTrPDvIaHJBClgxoi,args):
  for pGqUzhuyOLmdwcTrPDvIaHJBClgxok in pGqUzhuyOLmdwcTrPDvIaHJBClgxoE:
   pGqUzhuyOLmdwcTrPDvIaHJBClgxoe=pGqUzhuyOLmdwcTrPDvIaHJBClgxok.get('title')
   pGqUzhuyOLmdwcTrPDvIaHJBClgxoN=''
   pGqUzhuyOLmdwcTrPDvIaHJBClgxoV={'mode':pGqUzhuyOLmdwcTrPDvIaHJBClgxok.get('mode'),'sType':pGqUzhuyOLmdwcTrPDvIaHJBClgxok.get('sType'),}
   if pGqUzhuyOLmdwcTrPDvIaHJBClgxok.get('mode')in['XXX']:
    pGqUzhuyOLmdwcTrPDvIaHJBClgxoK=pGqUzhuyOLmdwcTrPDvIaHJBClgxEX
    pGqUzhuyOLmdwcTrPDvIaHJBClgxos =pGqUzhuyOLmdwcTrPDvIaHJBClgxEf
   else:
    pGqUzhuyOLmdwcTrPDvIaHJBClgxoK=pGqUzhuyOLmdwcTrPDvIaHJBClgxEf
    pGqUzhuyOLmdwcTrPDvIaHJBClgxos =pGqUzhuyOLmdwcTrPDvIaHJBClgxEX
   if 'icon' in pGqUzhuyOLmdwcTrPDvIaHJBClgxok:pGqUzhuyOLmdwcTrPDvIaHJBClgxoN=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',pGqUzhuyOLmdwcTrPDvIaHJBClgxok.get('icon')) 
   pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.add_dir(pGqUzhuyOLmdwcTrPDvIaHJBClgxoe,sublabel='',img=pGqUzhuyOLmdwcTrPDvIaHJBClgxoN,infoLabels=pGqUzhuyOLmdwcTrPDvIaHJBClgxEi,isFolder=pGqUzhuyOLmdwcTrPDvIaHJBClgxoK,params=pGqUzhuyOLmdwcTrPDvIaHJBClgxoV,isLink=pGqUzhuyOLmdwcTrPDvIaHJBClgxos)
  xbmcplugin.endOfDirectory(pGqUzhuyOLmdwcTrPDvIaHJBClgxoi._addon_handle)
 def dp_Channel_List(pGqUzhuyOLmdwcTrPDvIaHJBClgxoi,args):
  pGqUzhuyOLmdwcTrPDvIaHJBClgxQE =args.get('sType')
  if pGqUzhuyOLmdwcTrPDvIaHJBClgxQE=='kbs':
   pGqUzhuyOLmdwcTrPDvIaHJBClgxQi=pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.BroadcastObj.Get_ChannalList_KBS()
  elif pGqUzhuyOLmdwcTrPDvIaHJBClgxQE=='sbs':
   pGqUzhuyOLmdwcTrPDvIaHJBClgxQi=pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.BroadcastObj.Get_ChannalList_SBS()
  elif pGqUzhuyOLmdwcTrPDvIaHJBClgxQE=='mbc':
   pGqUzhuyOLmdwcTrPDvIaHJBClgxQi=pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.BroadcastObj.Get_ChannalList_MBC()
  else:
   return
  for pGqUzhuyOLmdwcTrPDvIaHJBClgxQf in pGqUzhuyOLmdwcTrPDvIaHJBClgxQi:
   pGqUzhuyOLmdwcTrPDvIaHJBClgxQX =pGqUzhuyOLmdwcTrPDvIaHJBClgxQf.get('company')
   pGqUzhuyOLmdwcTrPDvIaHJBClgxQA =pGqUzhuyOLmdwcTrPDvIaHJBClgxQf.get('channelNm')
   pGqUzhuyOLmdwcTrPDvIaHJBClgxQb =pGqUzhuyOLmdwcTrPDvIaHJBClgxQf.get('thumbnail')
   pGqUzhuyOLmdwcTrPDvIaHJBClgxQt =pGqUzhuyOLmdwcTrPDvIaHJBClgxQf.get('channlCode')
   pGqUzhuyOLmdwcTrPDvIaHJBClgxQF =pGqUzhuyOLmdwcTrPDvIaHJBClgxQf.get('programTitle')
   pGqUzhuyOLmdwcTrPDvIaHJBClgxQW={'mediatype':'episode','title':pGqUzhuyOLmdwcTrPDvIaHJBClgxQA,'plot':pGqUzhuyOLmdwcTrPDvIaHJBClgxQF,}
   pGqUzhuyOLmdwcTrPDvIaHJBClgxoV={'mode':'LIVE','company':pGqUzhuyOLmdwcTrPDvIaHJBClgxQX,'channlCode':pGqUzhuyOLmdwcTrPDvIaHJBClgxQt,}
   pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.add_dir(pGqUzhuyOLmdwcTrPDvIaHJBClgxQA,sublabel=pGqUzhuyOLmdwcTrPDvIaHJBClgxQX.upper(),img=pGqUzhuyOLmdwcTrPDvIaHJBClgxQb,infoLabels=pGqUzhuyOLmdwcTrPDvIaHJBClgxQW,isFolder=pGqUzhuyOLmdwcTrPDvIaHJBClgxEX,params=pGqUzhuyOLmdwcTrPDvIaHJBClgxoV,isLink=pGqUzhuyOLmdwcTrPDvIaHJBClgxEX)
  xbmcplugin.endOfDirectory(pGqUzhuyOLmdwcTrPDvIaHJBClgxoi._addon_handle)
 def play_VIDEO(pGqUzhuyOLmdwcTrPDvIaHJBClgxoi,args):
  pGqUzhuyOLmdwcTrPDvIaHJBClgxQX =args.get('company')
  pGqUzhuyOLmdwcTrPDvIaHJBClgxQt =args.get('channlCode')
  pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.addon_log('channlCode  : '+pGqUzhuyOLmdwcTrPDvIaHJBClgxQt)
  pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.addon_log('company     : '+pGqUzhuyOLmdwcTrPDvIaHJBClgxQX)
  if pGqUzhuyOLmdwcTrPDvIaHJBClgxQX=='kbs':
   pGqUzhuyOLmdwcTrPDvIaHJBClgxQn=pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.BroadcastObj.Get_StreamingURL_KBS(pGqUzhuyOLmdwcTrPDvIaHJBClgxQt)
  elif pGqUzhuyOLmdwcTrPDvIaHJBClgxQX=='sbs':
   pGqUzhuyOLmdwcTrPDvIaHJBClgxQn=pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.BroadcastObj.Get_StreamingURL_SBS(pGqUzhuyOLmdwcTrPDvIaHJBClgxQt)
  elif pGqUzhuyOLmdwcTrPDvIaHJBClgxQX=='mbc':
   pGqUzhuyOLmdwcTrPDvIaHJBClgxQn=pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.BroadcastObj.Get_StreamingURL_MBC(pGqUzhuyOLmdwcTrPDvIaHJBClgxQt)
  else:
   return
  pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.addon_log('service_url : '+pGqUzhuyOLmdwcTrPDvIaHJBClgxQn)
  pGqUzhuyOLmdwcTrPDvIaHJBClgxQe=xbmcgui.ListItem(path=pGqUzhuyOLmdwcTrPDvIaHJBClgxQn)
  xbmcplugin.setResolvedUrl(pGqUzhuyOLmdwcTrPDvIaHJBClgxoi._addon_handle,pGqUzhuyOLmdwcTrPDvIaHJBClgxEf,pGqUzhuyOLmdwcTrPDvIaHJBClgxQe)
 def login_main(pGqUzhuyOLmdwcTrPDvIaHJBClgxoi,pGqUzhuyOLmdwcTrPDvIaHJBClgxQX):
  pGqUzhuyOLmdwcTrPDvIaHJBClgxQY=pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.get_settings_account(pGqUzhuyOLmdwcTrPDvIaHJBClgxQX)
  if not(pGqUzhuyOLmdwcTrPDvIaHJBClgxQY['id']and pGqUzhuyOLmdwcTrPDvIaHJBClgxQY['pw']):
   pGqUzhuyOLmdwcTrPDvIaHJBClgxot=xbmcgui.Dialog()
   pGqUzhuyOLmdwcTrPDvIaHJBClgxQS=pGqUzhuyOLmdwcTrPDvIaHJBClgxot.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if pGqUzhuyOLmdwcTrPDvIaHJBClgxQS==pGqUzhuyOLmdwcTrPDvIaHJBClgxEf:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.cookiefile_check(pGqUzhuyOLmdwcTrPDvIaHJBClgxQX):return
  if pGqUzhuyOLmdwcTrPDvIaHJBClgxQX=='SBS':
   pGqUzhuyOLmdwcTrPDvIaHJBClgxQR=pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.BroadcastObj.Login_SBS(pGqUzhuyOLmdwcTrPDvIaHJBClgxQY['id'],pGqUzhuyOLmdwcTrPDvIaHJBClgxQY['pw'],pGqUzhuyOLmdwcTrPDvIaHJBClgxQY['ttl'])
   if pGqUzhuyOLmdwcTrPDvIaHJBClgxQR==pGqUzhuyOLmdwcTrPDvIaHJBClgxEX:
    pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.addon_noti('{} {}'.format(pGqUzhuyOLmdwcTrPDvIaHJBClgxQX,__language__(30903)))
    sys.exit()
  elif pGqUzhuyOLmdwcTrPDvIaHJBClgxQX=='MBC':
   pGqUzhuyOLmdwcTrPDvIaHJBClgxQR,pGqUzhuyOLmdwcTrPDvIaHJBClgxQM=pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.BroadcastObj.Login_MBC(pGqUzhuyOLmdwcTrPDvIaHJBClgxQY['id'],pGqUzhuyOLmdwcTrPDvIaHJBClgxQY['pw'],pGqUzhuyOLmdwcTrPDvIaHJBClgxQY['ttl'])
   if pGqUzhuyOLmdwcTrPDvIaHJBClgxQR==pGqUzhuyOLmdwcTrPDvIaHJBClgxEX:
    if pGqUzhuyOLmdwcTrPDvIaHJBClgxQM!='':
     pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.addon_noti('{} {}'.format(pGqUzhuyOLmdwcTrPDvIaHJBClgxQX,pGqUzhuyOLmdwcTrPDvIaHJBClgxQM))
    else:
     pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.addon_noti('{} {}'.format(pGqUzhuyOLmdwcTrPDvIaHJBClgxQX,__language__(30903)))
    sys.exit()
 def cookiefile_check(pGqUzhuyOLmdwcTrPDvIaHJBClgxoi,pGqUzhuyOLmdwcTrPDvIaHJBClgxQX):
  if pGqUzhuyOLmdwcTrPDvIaHJBClgxQX=='SBS':
   pGqUzhuyOLmdwcTrPDvIaHJBClgxQj=pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.BroadcastObj.JsonFile_Load(pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.BroadcastObj.COOKIE_FILE_SBS)
   pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.BroadcastObj.SBS=pGqUzhuyOLmdwcTrPDvIaHJBClgxQj
  elif pGqUzhuyOLmdwcTrPDvIaHJBClgxQX=='MBC':
   pGqUzhuyOLmdwcTrPDvIaHJBClgxQj=pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.BroadcastObj.JsonFile_Load(pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.BroadcastObj.COOKIE_FILE_MBC)
   pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.BroadcastObj.MBC=pGqUzhuyOLmdwcTrPDvIaHJBClgxQj
  else:
   return pGqUzhuyOLmdwcTrPDvIaHJBClgxEX
  if pGqUzhuyOLmdwcTrPDvIaHJBClgxQj=={}:
   pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.BroadcastObj.Init_Company(pGqUzhuyOLmdwcTrPDvIaHJBClgxQX)
   return pGqUzhuyOLmdwcTrPDvIaHJBClgxEX
  pGqUzhuyOLmdwcTrPDvIaHJBClgxQk =pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.get_settings_account(pGqUzhuyOLmdwcTrPDvIaHJBClgxQX)
  (pGqUzhuyOLmdwcTrPDvIaHJBClgxQN,pGqUzhuyOLmdwcTrPDvIaHJBClgxQV) =pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.BroadcastObj.Load_session_acount(pGqUzhuyOLmdwcTrPDvIaHJBClgxQX)
  if pGqUzhuyOLmdwcTrPDvIaHJBClgxQk['id']!=pGqUzhuyOLmdwcTrPDvIaHJBClgxQN or pGqUzhuyOLmdwcTrPDvIaHJBClgxQk['pw']!=pGqUzhuyOLmdwcTrPDvIaHJBClgxQV:
   pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.BroadcastObj.Init_Company(pGqUzhuyOLmdwcTrPDvIaHJBClgxQX)
   return pGqUzhuyOLmdwcTrPDvIaHJBClgxEX
  if pGqUzhuyOLmdwcTrPDvIaHJBClgxEt(pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.BroadcastObj.Get_Now_Datetime().strftime('%Y%m%d'))>pGqUzhuyOLmdwcTrPDvIaHJBClgxEt(pGqUzhuyOLmdwcTrPDvIaHJBClgxQj['account']['token_limit']):
   pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.BroadcastObj.Init_Company(pGqUzhuyOLmdwcTrPDvIaHJBClgxQX)
   return pGqUzhuyOLmdwcTrPDvIaHJBClgxEX
  return pGqUzhuyOLmdwcTrPDvIaHJBClgxEf
 def logout(pGqUzhuyOLmdwcTrPDvIaHJBClgxoi,pGqUzhuyOLmdwcTrPDvIaHJBClgxQX):
  if pGqUzhuyOLmdwcTrPDvIaHJBClgxQX=='SBS':
   pGqUzhuyOLmdwcTrPDvIaHJBClgxQK=pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.BroadcastObj.COOKIE_FILE_SBS
  elif pGqUzhuyOLmdwcTrPDvIaHJBClgxQX=='MBC':
   pGqUzhuyOLmdwcTrPDvIaHJBClgxQK=pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.BroadcastObj.COOKIE_FILE_MBC
  else:
   return
  pGqUzhuyOLmdwcTrPDvIaHJBClgxot=xbmcgui.Dialog()
  pGqUzhuyOLmdwcTrPDvIaHJBClgxQS=pGqUzhuyOLmdwcTrPDvIaHJBClgxot.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if pGqUzhuyOLmdwcTrPDvIaHJBClgxQS==pGqUzhuyOLmdwcTrPDvIaHJBClgxEX:sys.exit()
  pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.BroadcastObj.Init_Company(pGqUzhuyOLmdwcTrPDvIaHJBClgxQX)
  if os.path.isfile(pGqUzhuyOLmdwcTrPDvIaHJBClgxQK):os.remove(pGqUzhuyOLmdwcTrPDvIaHJBClgxQK)
  pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.addon_noti(__language__(30906).encode('utf-8'))
 def broadcast_main(pGqUzhuyOLmdwcTrPDvIaHJBClgxoi):
  pGqUzhuyOLmdwcTrPDvIaHJBClgxQs=pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.main_params.get('mode',pGqUzhuyOLmdwcTrPDvIaHJBClgxEi)
  if pGqUzhuyOLmdwcTrPDvIaHJBClgxQs=='SBS_LOGOUT':
   pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.logout('SBS')
   return
  elif pGqUzhuyOLmdwcTrPDvIaHJBClgxQs=='MBC_LOGOUT':
   pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.logout('MBC')
   return
  pGqUzhuyOLmdwcTrPDvIaHJBClgxEo=pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.get_settings_company()
  if pGqUzhuyOLmdwcTrPDvIaHJBClgxEo['sbs_yn']:pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.login_main('SBS')
  if pGqUzhuyOLmdwcTrPDvIaHJBClgxEo['mbc_yn']:pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.login_main('MBC')
  if pGqUzhuyOLmdwcTrPDvIaHJBClgxQs is pGqUzhuyOLmdwcTrPDvIaHJBClgxEi:
   pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.dp_Main_List(pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.main_params)
  elif pGqUzhuyOLmdwcTrPDvIaHJBClgxQs=='CHANNEL_LIST':
   pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.dp_Channel_List(pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.main_params)
  elif pGqUzhuyOLmdwcTrPDvIaHJBClgxQs=='LIVE':
   pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.play_VIDEO(pGqUzhuyOLmdwcTrPDvIaHJBClgxoi.main_params)
  else:
   pGqUzhuyOLmdwcTrPDvIaHJBClgxEi
# Created by pyminifier (https://github.com/liftoff/pyminifier)
