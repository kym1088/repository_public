Query_Ranking_List = '''
query RankingDetail($rankingLimit: Int = 10, $rankingProviderIds: [Int!], $isInTheaters: Boolean) {
  contentRankingsV2(
    limit: $rankingLimit
    providerIds: $rankingProviderIds
    isInTheaters: $isInTheaters
  ) {
    content {
      id
      ...FragmentSeasonTitleAndLabel
      posterImage {
        id
        pathUrl
      }
      stillCutImage {
        id
        pathUrl
      }
      isInTheaters
      vodOfferItems {
        id
        providerId
        monetizationType
      }
      indexRatingScore
      indexRatingType
      contentTypes
      mediaType
    }
    delta
    isNew
  }
}

fragment FragmentSeasonTitleAndLabel on MovieOutput {
  titleKr
  titleLogoImage {
    id
    pathUrl
  }
  seasonLabels {
    id
    color
    type
    value
  }
  editionType
}
'''



Query_Content_View = '''
fragment FragmentMovieCardMyStatus on MovieOutput {
  isMyInterest
  isMyWatched
  userIndexRating(userId: $userId) {
    index
  }
}

fragment FragmentMovieDetailField on MovieOutput {
  id
  titleKr
  titleEn
  titleOri
  mediaType
  productionYear
  rating
  showTime
  synopsis
  openYear
  imdbScore
  rottenTomatoesScore
  posterImage {
    pathUrl
  }
  genres
  contentTypes
  nations {
    name
  }
  releases {
    id
    releaseDate
    nation {
      name
    }
  }
  stillCutImage {
    pathUrl
  }
  indexRatingCount
  indexRatingType
  indexRatingScore
  starRatingScore
  vodOfferItems {
    id
    providerId
    title
    retailPrice
    monetizationType
    url
    openDate
    expireDate
    properties
  }
  certifiedAt
  contentTheaters {
    id
    theater
    link
    isActive
    releaseDate
  }
  ...FragmentMovieCardMyStatus @include(if: $withUser)
  isUninterest
  isMyWatching @include(if: $withUser)
  userStarRating(userId: $userId) @include(if: $withUser) {
    star
  }
  userReview(userId: $userId) @include(if: $withUser) {
    id
    movieId
    userId
    reviewTitle
    review
    reviewLink
    isPrivate
    isPreview
    hasSpoiler
    watchedAt {
      watchedAt
    }
  }
  userWatched(userId: $userId) @include(if: $withUser) {
    createdAt
    watchedAt
  }
  isMyBestContent @include(if: $withUser)
}

fragment FragmentInventory on BannerOutput {
  id
  inventory
  inventoryImage {
    pathUrl
  }
  link
  title
}

fragment FragmentTrailerVideo on BannerOutput {
  id
  title
  link
  inventory
  inventoryImage {
    pathUrl
  }
  inventoryVideo {
    pathUrl
  }
  inventoryVideoThumbnailUrl
}

query QueryContentDefault($contentId: Int!, $inventoryType: InventoryType! = TITLE_MIDDLE, $videoInventoryType: InventoryType! = TRAILER_VIDEO, $userId: Int!, $withUser: Boolean!) {
  movie: content(movieId: $contentId) {
    ...FragmentMovieDetailField
    kinobelUser {
      id
      name
    }
    upcomingDate
    episodeCount
    contentTags {
      category
      name
    }
    kmrb {
      ratingReason
      mainHarmReason
      subjectRating
      drugRating
      horrorRating
      sexualRating
      violenceRating
      dialogueRating
      horrorRating
      imitationRating
      rating
    }
  }
  titleMiddleInventories: inventories(inventoryType: $inventoryType) {
    ...FragmentInventory
  }
  trailerVideoInventories: inventories(inventoryType: $videoInventoryType) {
    ...FragmentTrailerVideo
  }
}
'''

Query_Content_Person = '''

query QueryContentInfo($contentId: Int!, $withActor: Boolean!, $crewTypesByActors: [CrewType!] = [ACTOR_MAIN], $crewOffsetByActors: Int = 0, $crewLimitByActors: Int, $withDirector: Boolean!, $crewTypesByDirector: [CrewType!] = [DIRECTOR], $crewOffsetByDirector: Int = 0, $crewLimitByDirector: Int, $withScenario: Boolean!, $crewTypesByScenario: [CrewType!] = [SCENARIO], $crewOffsetByScenario: Int = 0, $crewLimitByScenario: Int ) {
  actors: contentCrewsByTypes(
    movieId: $contentId
    crewTypes: $crewTypesByActors
    offset: $crewOffsetByActors
    limit: $crewLimitByActors
  ) @include(if: $withActor) {
    id
    sequence
    role
    type
    person {
      personId: id
      nameKr
      profileImage {
        pathUrl
      }
    }
  }
  directors: contentCrewsByTypes(
    movieId: $contentId
    crewTypes: $crewTypesByDirector
    offset: $crewOffsetByDirector
    limit: $crewLimitByDirector
  ) @include(if: $withDirector) {
    id
    sequence
    role
    type
    person {
      personId: id
      nameKr
      profileImage {
        pathUrl
      }
    }
  }
  scenarios: contentCrewsByTypes(
    movieId: $contentId
    crewTypes: $crewTypesByScenario
    offset: $crewOffsetByScenario
    limit: $crewLimitByScenario
  ) @include(if: $withScenario) {
    id
    sequence
    role
    type
    person {
      personId: id
      nameKr
      profileImage {
        pathUrl
      }
    }
  }
}
'''


Query_Filmography_List = '''
query FilmographyContents($crewTypes: [CrewType!], $limit: Int = 20, $offset: Int = 0, $orderBy: FilmographyMoviesOrderType!, $orderOption: OrderOptionType!, $personId: Int!) {
  filmographyContents(
    crewTypes: $crewTypes
    limit: $limit
    offset: $offset
    orderBy: $orderBy
    orderOption: $orderOption
    personId: $personId
  ) {
    ...FragmentSeasonCard
  }
}

fragment FragmentSeasonCard on MovieOutput {
  id
  titleKr
  contentTypes
  posterImage {
    id
    pathUrl
  }
  indexRatingScore
  indexRatingType
  starRatingScore
  certifiedAt
  isInTheaters
  isMyInterest
  isMyWatched
  isMyWatching
  isUninterest
  myIndexRating {
    index
  }
  openYear
  vodOfferItems {
    id
    providerId
    monetizationType
    openDate
    expireDate
  }
  rankingBadge {
    badgeType
    subject
  }
  mediaType
  synopsis
}
'''

Query_Search_Kerword_bak = '''
query SearchAll($keyword: String!) {
  userCount(keyword: $keyword)
  contentCollectionCount(orderBy: UPDATED_AT, keyword: $keyword)
  searchContentsByKeyword(limit: 10, keyword: $keyword) {
    items {
      content {
        ...FragmentSeasonCard
      }
      searchAfter
    }
    totalCount
  }
  contentCollections(
    orderBy: UPDATED_AT
    orderOption: DESC
    limit: 9
    keyword: $keyword
  ) {
    id
    title
    description
    contentCount
    searchAfter
    isPrivate
    isMyInterest
    author {
      id
      name
    }
    contents(limit: 1) {
      stillCutImage {
        id
        pathUrl
      }
      posterImage {
        id
        pathUrl
      }
    }
  }
  users(limit: 10, offset: 0, keyword: $keyword) {
    id
    name
    watchedCount
    publicReviewCount
    isPremium
    profileImage {
      id
      pathUrl
    }
  }
}

fragment FragmentSeasonCard on MovieOutput {
  id
  titleKr
  contentTypes
  posterImage {
    id
    pathUrl
  }
  mainStillCutImage {
    id
    pathUrl
  }
  indexRatingScore
  indexRatingType
  starRatingScore
  certifiedAt
  isInTheaters
  isMyInterest
  isMyWatched
  isMyWatching
  isUninterest
  myIndexRating {
    index
  }
  openYear
  vodOfferItems {
    id
    providerId
    providerTechnicalName
    monetizationType
    openDate
    expireDate
  }
  rankingBadge {
    badgeType
    subject
  }
  taxonomy {
    id
    category
    value
  }
  mediaType
}
'''


Query_Search_Kerword = '''
query SearchMoreSeason($keyword: String!, $searchAfter: [String!]) {
  searchContentsByKeyword(limit: 10, keyword: $keyword, searchAfter: $searchAfter) {
    items {
      content {
        ...FragmentSeasonCard
      }
      searchAfter
    }
  }
}

fragment FragmentSeasonCard on MovieOutput {
  id
  titleKr
  contentTypes
  posterImage {
    id
    pathUrl
  }
  mainStillCutImage {
    id
    pathUrl
  }
  indexRatingScore
  indexRatingType
  starRatingScore
  certifiedAt
  isInTheaters
  isMyInterest
  isMyWatched
  isMyWatching
  isUninterest
  myIndexRating {
    index
  }
  openYear
  vodOfferItems {
    id
    providerId
    providerTechnicalName
    monetizationType
    openDate
    expireDate
  }
  rankingBadge {
    badgeType
    subject
  }
  taxonomy {
    id
    category
    value
  }
  mediaType
}
'''

