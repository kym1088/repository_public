__author__="NightRain"
mAIdohxWJPEeNSURTwKflMbjLOsGBQ=True
mAIdohxWJPEeNSURTwKflMbjLOsGBc=False
mAIdohxWJPEeNSURTwKflMbjLOsGBa=object
mAIdohxWJPEeNSURTwKflMbjLOsGBk=int
mAIdohxWJPEeNSURTwKflMbjLOsGBt=None
mAIdohxWJPEeNSURTwKflMbjLOsGBi=Exception
mAIdohxWJPEeNSURTwKflMbjLOsGBn=print
mAIdohxWJPEeNSURTwKflMbjLOsGBF=len
import re
from baseHttp import*
from baseFunc import*
from kinoQuery import*
PROVIDER_LIST={4:{'name':'netflix','link':mAIdohxWJPEeNSURTwKflMbjLOsGBQ},5:{'name':'watcha','link':mAIdohxWJPEeNSURTwKflMbjLOsGBQ},8:{'name':'wavve','link':mAIdohxWJPEeNSURTwKflMbjLOsGBQ},10:{'name':'tving','link':mAIdohxWJPEeNSURTwKflMbjLOsGBQ},14:{'name':'coupang','link':mAIdohxWJPEeNSURTwKflMbjLOsGBQ},17:{'name':'disney','link':mAIdohxWJPEeNSURTwKflMbjLOsGBQ},18:{'name':'uplus','link':mAIdohxWJPEeNSURTwKflMbjLOsGBc},1:{'name':'serieson','link':mAIdohxWJPEeNSURTwKflMbjLOsGBc},12:{'name':'laftel','link':mAIdohxWJPEeNSURTwKflMbjLOsGBc},9:{'name':'prime','link':mAIdohxWJPEeNSURTwKflMbjLOsGBQ},16:{'name':'apple','link':mAIdohxWJPEeNSURTwKflMbjLOsGBc},}
class mAIdohxWJPEeNSURTwKflMbjLOsGBq(mAIdohxWJPEeNSURTwKflMbjLOsGBa):
 def __init__(self):
  self.OS_ANDROID =mAIdohxWJPEeNSURTwKflMbjLOsGBc
  self.API_DOMAIN ='https://gateway.kinolights.com'
  self.ONE_PAGE =20 
  self.HttpObj =BaseHttp()
  self.KN_SEARCHED_FILENAME =''
  self.KN_SESSION_COOKIES1 =''
  self.KN_SESSION_COOKIES2 =''
  self.KN_SESSION_COOKIES3 =''
  self.KN_SESSION_COOKIES4 =''
  self.KN_SESSION_FULLTEXT1 =''
  self.KN_SESSION_FULLTEXT2 =''
  self.KN_SESSION_FULLTEXT3 =''
  self.KN_SESSION_FULLTEXT4 =''
  self.KN_CONTEXTJSON_FILE1 =''
  self.KN_CONTEXTJSON_FILE2 =''
  self.KN_CONTEXTJSON_FILE3 =''
  self.KN_CONTEXTJSON_FILE4 =''
 def Get_ProviderNm(self,providerId):
  if providerId in PROVIDER_LIST:
   return PROVIDER_LIST[providerId]['name']
  else:
   return '-'
 def Get_Content_Ranking_New(self,ottId,page_int=1):
  rank_list=[]
  try:
   url =self.API_DOMAIN+'/graphql' 
   endYear=mAIdohxWJPEeNSURTwKflMbjLOsGBk(datetime.datetime.fromtimestamp(time.time()).strftime('%Y'))+1
   payload={'operationName':'QueryExploreContents','query':Query_Explore_List,'variables':{'adMovieId':0,'excludeWatched':mAIdohxWJPEeNSURTwKflMbjLOsGBQ,'imdbScoreRange':{'start':1,'end':10},'indexRatingRange':{'start':0,'end':100},'isCertified':mAIdohxWJPEeNSURTwKflMbjLOsGBc,'isSubscription':mAIdohxWJPEeNSURTwKflMbjLOsGBc,'limit':self.ONE_PAGE,'offset':(page_int-1)*self.ONE_PAGE,'openYearRange':{'start':1874,'end':endYear},'orderBy':'YESTERDAY_VIEW_COUNT','orderOption':'DESC','priceRange':{'start':0,'end':5100},'providerIds':[]if ottId==0 else[ottId],'rottenScoreRange':{'start':0,'end':100},'runningTimeRange':{'start':0,'end':201},'starRatingRange':{'start':0.5,'end':5},'userId':0,'withAdMovie':mAIdohxWJPEeNSURTwKflMbjLOsGBc,'withUser':mAIdohxWJPEeNSURTwKflMbjLOsGBc,},}
   response=self.HttpObj.Call_Request(url,json=payload,headers=mAIdohxWJPEeNSURTwKflMbjLOsGBt,method='POST')
   if response.status_code not in[200,201]:return[]
   resJson=response.json()
   i=0
   for iList in resJson.get('data').get('exploreMovies'):
    i+=1
    temp_list={'seq':'{:>3}'.format(i+(page_int-1)*self.ONE_PAGE),'contentid':iList['id'],'title':iList['titleKr'],'poster':iList['posterImage']['pathUrl'],'mediaType':iList['mediaType'],}
    rank_list.append(temp_list)
  except mAIdohxWJPEeNSURTwKflMbjLOsGBi as exception:
   mAIdohxWJPEeNSURTwKflMbjLOsGBn(exception)
   return[]
  return rank_list
 def Get_Content_Ranking(self,ottNm):
  rank_list=[]
  try:
   url =self.API_DOMAIN+'/graphql' 
   payload={'operationName':'QueryRankings','query':Query_Ranking_List,'variables':{'limit':self.ONE_PAGE,'rankingType':'MONTHLY','target':datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m'),},}
   response=self.HttpObj.Call_Request(url,json=payload,headers=mAIdohxWJPEeNSURTwKflMbjLOsGBt,method='POST')
   if response.status_code not in[200,201]:return[]
   resJson=response.json()
   for iProv in resJson.get('data').get('contentDailyRankings').get('providers'):
    if ottNm!=iProv.get('name'):continue
    i=0
    for iRank in iProv.get('rank'):
     i+=1
     temp_list={'seq':'{:>2}'.format(i),'contentid':iRank['title']['id'],'title':iRank['title']['titleKr'],'poster':iRank['title']['posterImage']['path'],'mediaType':iRank['title']['mediaType'],}
     rank_list.append(temp_list)
  except mAIdohxWJPEeNSURTwKflMbjLOsGBi as exception:
   mAIdohxWJPEeNSURTwKflMbjLOsGBn(exception)
   return[]
  return rank_list
 def Get_Person_Ranking(self):
  rank_list=[]
  try:
   url =self.API_DOMAIN+'/graphql' 
   payload={'operationName':'QueryRankings','query':Query_Ranking_List,'variables':{'limit':self.ONE_PAGE,'rankingType':'MONTHLY','target':datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m'),},}
   response=self.HttpObj.Call_Request(url,json=payload,headers=mAIdohxWJPEeNSURTwKflMbjLOsGBt,method='POST')
   if response.status_code not in[200,201]:return[]
   resJson=response.json()
   for iPerson in resJson.get('data').get('personRanking'):
    temp_list={'seq':'{:>2}'.format(iPerson['rank']),'personid':iPerson['id'],'name':iPerson['nameKr'],'poster':iPerson['profileImage']['path'],}
    rank_list.append(temp_list)
  except mAIdohxWJPEeNSURTwKflMbjLOsGBi as exception:
   mAIdohxWJPEeNSURTwKflMbjLOsGBn(exception)
   return[]
  return rank_list
 def Catch_Contentid(self,url,providerId):
  if providerId not in PROVIDER_LIST:return 0 
  if PROVIDER_LIST[providerId]['link']==mAIdohxWJPEeNSURTwKflMbjLOsGBc:return 0
  if providerId==8:
   param_list=URL_GetParamList(url)
   idStr=param_list.get('programid')or param_list.get('movieid')
  else:
   str_list=url.split('/')
   idStr=str_list[mAIdohxWJPEeNSURTwKflMbjLOsGBF(str_list)-1]
   if '#' in idStr:
    idStr=idStr.split('#')[0]
  return idStr
 def Get_Content_Info(self,contentid):
  VIDEO_INFO={'title':'','contentid':0,'thumbnail':{'poster':'','fanart':''},'infoLabels':{'mediatype':'','title':'','plot':'','year':'','cast':[],'genre':[],'premiered':'','country':'',},'ott':[],'imdb':0,'rating':0,}
  try:
   url =self.API_DOMAIN+'/graphql' 
   payload={'operationName':'QueryContentDefault','query':Query_Content_View,'variables':{'contentId':mAIdohxWJPEeNSURTwKflMbjLOsGBk(contentid),'inventoryType':'TITLE_MIDDLE','userId':0,'videoInventoryType':'TRAILER_VIDEO','withUser':mAIdohxWJPEeNSURTwKflMbjLOsGBc,},}
   response=self.HttpObj.Call_Request(url,json=payload,headers=mAIdohxWJPEeNSURTwKflMbjLOsGBt,method='POST')
   if response.status_code not in[200,201]:return{}
   resJson=response.json()
   resJson=resJson['data']['movie']
   VIDEO_INFO['contentid'] =contentid
   VIDEO_INFO['title'] =resJson['titleKr']
   VIDEO_INFO['imdb'] =resJson['imdbScore']or 0
   VIDEO_INFO['rating'] =resJson['indexRatingScore']or 0
   VIDEO_INFO['infoLabels']['title'] =resJson['titleKr']
   VIDEO_INFO['infoLabels']['mediatype']='tvshow' if resJson['mediaType']=='TV' else 'movie'
   VIDEO_INFO['infoLabels']['plot'] =resJson['synopsis']
   VIDEO_INFO['infoLabels']['year'] =resJson['productionYear']
   if resJson['releases']:
    VIDEO_INFO['infoLabels']['premiered']=resJson['releases'][0]['releaseDate']
   VIDEO_INFO['infoLabels']['genre'] =resJson['genres']
   for nation in resJson['nations']:
    VIDEO_INFO['infoLabels']['country'] =nation['name']
    break
   if resJson['posterImage']:
    VIDEO_INFO['thumbnail']['poster'] =resJson['posterImage']['pathUrl']
    VIDEO_INFO['thumbnail']['fanart'] =resJson['posterImage']['pathUrl']
   if resJson['stillCutImage']:
    VIDEO_INFO['thumbnail']['fanart'] =resJson['stillCutImage'][0]['pathUrl']
   for i_ott in resJson['vodOfferItems']:
    if i_ott['monetizationType']not in['streaming']:continue
    temp_ott={'provider':self.Get_ProviderNm(i_ott['providerId']),'contentid':self.Catch_Contentid(i_ott['url'],i_ott['providerId']),'mediatype':resJson['mediaType'],'properties':', '.join(i_ott['properties']),}
    VIDEO_INFO['ott'].append(temp_ott)
   if not VIDEO_INFO['ott']:
    for i_ott in resJson['contentTheaters']:
     temp_ott={'provider':'cinema','contentid':0,'mediatype':resJson['mediaType'],'properties':'',}
     VIDEO_INFO['ott'].append(temp_ott)
     break
   if not VIDEO_INFO['ott']:
    temp_ott={'provider':'none','contentid':0,'mediatype':resJson['mediaType'],'properties':'',}
    VIDEO_INFO['ott'].append(temp_ott)
   cast_list=self.Get_Content_Person(contentid)
   VIDEO_INFO['infoLabels']['cast']=self.make_setCast(cast_list)
  except mAIdohxWJPEeNSURTwKflMbjLOsGBi as exception:
   mAIdohxWJPEeNSURTwKflMbjLOsGBn(exception)
   return{}
  return VIDEO_INFO
 def make_setCast(self,person):
  cast_list=[]
  order=0
  for i_cast in person.get('actors'):
   order=+1
   temp_list={'name':i_cast['name'],'role':i_cast['role'],'thumbnail':i_cast['thumbnail'],'order':order,'personid':i_cast['personid'],}
   cast_list.append(temp_list)
  for i_cast in person.get('staffs'):
   order=+1
   temp_list={'name':i_cast['name'],'role':i_cast['role'],'thumbnail':i_cast['thumbnail'],'order':order,'personid':i_cast['personid'],}
   cast_list.append(temp_list)
  return cast_list
 def Get_Content_Person(self,contentid):
  PERSON_INFO={'actors':[],'staffs':[],}
  try:
   url =self.API_DOMAIN+'/graphql' 
   payload={'operationName':'QueryContentInfo','query':Query_Content_Person,'variables':{'contentId':mAIdohxWJPEeNSURTwKflMbjLOsGBk(contentid),'crewLimitByActors':20,'crewLimitByDirector':20,'crewLimitByScenario':20,'crewOffsetByActors':0,'crewOffsetByDirector':0,'crewOffsetByScenario':0,'crewTypesByActors':['ACTOR_MAIN'],'crewTypesByDirector':['DIRECTOR'],'crewTypesByScenario':['SCENARIO'],'withActor':mAIdohxWJPEeNSURTwKflMbjLOsGBQ,'withDirector':mAIdohxWJPEeNSURTwKflMbjLOsGBQ,'withScenario':mAIdohxWJPEeNSURTwKflMbjLOsGBQ,},}
   response=self.HttpObj.Call_Request(url,json=payload,headers=mAIdohxWJPEeNSURTwKflMbjLOsGBt,method='POST')
   if response.status_code not in[200,201]:return{}
   resJson=response.json()
   resJson=resJson['data']
   for actor in resJson['actors']:
    temp_list={'personid':actor['person']['personId'],'name':actor['person']['nameKr'],'thumbnail':actor['person']['profileImage']['pathUrl']if actor['person']['profileImage']else '','role':actor['role']or '-',}
    PERSON_INFO['actors'].append(temp_list)
   for director in resJson['directors']:
    temp_list={'personid':director['person']['personId'],'name':director['person']['nameKr'],'thumbnail':director['person']['profileImage']['pathUrl']if director['person']['profileImage']else '','role':director['role']or '-',}
    PERSON_INFO['actors'].append(temp_list)
   for staff in resJson['scenarios']:
    temp_list={'personid':staff['person']['personId'],'name':staff['person']['nameKr'],'thumbnail':staff['person']['profileImage']['pathUrl']if staff['person']['profileImage']else '','role':staff['role']or '-',}
    PERSON_INFO['staffs'].append(temp_list)
  except mAIdohxWJPEeNSURTwKflMbjLOsGBi as exception:
   mAIdohxWJPEeNSURTwKflMbjLOsGBn(exception)
   return{}
  return PERSON_INFO
 def Get_Filmography_List(self,personid,page_int=1):
  FILMO_INFO={'filmo_list':[],'more_page':mAIdohxWJPEeNSURTwKflMbjLOsGBc,}
  try:
   url =self.API_DOMAIN+'/graphql' 
   payload={'operationName':'QueryLoadPerson','query':Query_Filmography_List,'variables':{'limit':self.ONE_PAGE,'offset':(page_int-1)*(self.ONE_PAGE),'orderBy':'OPEN_YEAR','orderOption':'DESC','personId':mAIdohxWJPEeNSURTwKflMbjLOsGBk(personid),'target':datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m'),'userId':0,'withAllCount':mAIdohxWJPEeNSURTwKflMbjLOsGBc,'withUser':mAIdohxWJPEeNSURTwKflMbjLOsGBc,},}
   response=self.HttpObj.Call_Request(url,json=payload,headers=mAIdohxWJPEeNSURTwKflMbjLOsGBt,method='POST')
   if response.status_code not in[200,201]:return{}
   resJson=response.json()
   resJson=resJson['data']
   for iFilmo in resJson.get('filmography'):
    thumbnail ={'poster':'','fanart':''}
    if iFilmo['posterImage']:
     thumbnail['poster'] =iFilmo['posterImage']['pathUrl']
     thumbnail['thumb'] =iFilmo['posterImage']['pathUrl']
    temp_list={'contentid':iFilmo['id'],'title':iFilmo['titleKr'],'thumbnail':thumbnail,'mediaType':iFilmo['mediaType'],'rating':iFilmo['indexRatingScore']or 0,}
    FILMO_INFO['filmo_list'].append(temp_list)
   if resJson.get('filmographyCount')>self.ONE_PAGE*(page_int):FILMO_INFO['more_page']=mAIdohxWJPEeNSURTwKflMbjLOsGBQ
  except mAIdohxWJPEeNSURTwKflMbjLOsGBi as exception:
   mAIdohxWJPEeNSURTwKflMbjLOsGBn(exception)
   return{}
  return FILMO_INFO
 def Get_Search_List(self,search_key,page_int=1,searchAfter=mAIdohxWJPEeNSURTwKflMbjLOsGBt):
  SEARCH_LIST={'search_list':[],'more_page':mAIdohxWJPEeNSURTwKflMbjLOsGBc,'searchAfter':mAIdohxWJPEeNSURTwKflMbjLOsGBt,}
  try:
   url =self.API_DOMAIN+'/graphql' 
   payload={'operationName':'QueryContentsByKeyword','query':Query_Search_Kerword,'variables':{'keyword':search_key,'limit':self.ONE_PAGE,'userId':0,'withUser':mAIdohxWJPEeNSURTwKflMbjLOsGBc,},}
   if searchAfter:
    payload['variables']['searchAfter']=searchAfter
   response=self.HttpObj.Call_Request(url,json=payload,headers=mAIdohxWJPEeNSURTwKflMbjLOsGBt,method='POST')
   if response.status_code not in[200,201]:return SEARCH_LIST
   resJson=response.json()
   resJson=resJson['data']['contentsByKeyword']
   for iItem in resJson.get('items'):
    thumbnail ={'poster':'','fanart':''}
    if iItem['content']['posterImage']:
     thumbnail['poster'] =iItem['content']['posterImage']['path']
     thumbnail['thumb'] =iItem['content']['posterImage']['path']
    if iItem['content']['stillCutImage']:
     thumbnail['fanart'] =iItem['content']['stillCutImage'][0]['path']
    temp_list={'contentid':iItem['content']['id'],'title':iItem['content']['titleKr'],'thumbnail':thumbnail,'mediaType':iItem['content']['mediaType'],'synopsis':iItem['content']['synopsis'],'imdb':iItem['content']['imdbScore']or 0,'rating':iItem['content']['indexRatingScore']or 0,}
    SEARCH_LIST['search_list'].append(temp_list)
    iAfter=iItem['searchAfter']
   if resJson.get('totalCount')>self.ONE_PAGE*(page_int):
    SEARCH_LIST['more_page']=mAIdohxWJPEeNSURTwKflMbjLOsGBQ
    SEARCH_LIST['searchAfter']=iAfter 
  except mAIdohxWJPEeNSURTwKflMbjLOsGBi as exception:
   mAIdohxWJPEeNSURTwKflMbjLOsGBn(exception)
   return SEARCH_LIST
  return SEARCH_LIST
 def Get_Expired_Content_1(self):
  try:
   url =self.API_DOMAIN+'/graphql' 
   payload={'operationName':'AvailableExpiredContentDate','query':Query_ExpiredContent_Date,'variables':{'excludeWatched':mAIdohxWJPEeNSURTwKflMbjLOsGBQ,'isSubscription':mAIdohxWJPEeNSURTwKflMbjLOsGBQ,},}
   response=self.HttpObj.Call_Request(url,json=payload,headers=mAIdohxWJPEeNSURTwKflMbjLOsGBt,method='POST')
   if response.status_code not in[200,201]:return{}
   resJson=response.json()
   JsonFile_Save(self.KN_SESSION_COOKIES1,resJson)
   resJson=resJson['data']
  except mAIdohxWJPEeNSURTwKflMbjLOsGBi as exception:
   mAIdohxWJPEeNSURTwKflMbjLOsGBn(exception)
   return{}
  return mAIdohxWJPEeNSURTwKflMbjLOsGBt
 def Get_Expired_Content_2(self):
  try:
   url =self.API_DOMAIN+'/graphql' 
   payload={'operationName':'QueryExpiredContents','query':Query_ExpiredContent_List,'variables':{'excludeWatched':mAIdohxWJPEeNSURTwKflMbjLOsGBQ,'isSubscription':mAIdohxWJPEeNSURTwKflMbjLOsGBQ,'limit':self.ONE_PAGE,'targetDate':'2024-04-04','userId':0,'withUser':mAIdohxWJPEeNSURTwKflMbjLOsGBc,},}
   response=self.HttpObj.Call_Request(url,json=payload,headers=mAIdohxWJPEeNSURTwKflMbjLOsGBt,method='POST')
   if response.status_code not in[200,201]:return{}
   resJson=response.json()
   JsonFile_Save(self.KN_SESSION_COOKIES2,resJson)
   resJson=resJson['data']
  except mAIdohxWJPEeNSURTwKflMbjLOsGBi as exception:
   mAIdohxWJPEeNSURTwKflMbjLOsGBn(exception)
   return{}
  return mAIdohxWJPEeNSURTwKflMbjLOsGBt
# Created by pyminifier (https://github.com/liftoff/pyminifier)
