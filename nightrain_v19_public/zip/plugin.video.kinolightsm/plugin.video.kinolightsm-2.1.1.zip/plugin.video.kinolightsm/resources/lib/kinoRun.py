__author__="NightRain"
XmJcxOTlfUHCzMdANkRtiesqEIuyPp=None
XmJcxOTlfUHCzMdANkRtiesqEIuyPD=object
XmJcxOTlfUHCzMdANkRtiesqEIuyPa=True
XmJcxOTlfUHCzMdANkRtiesqEIuyPw=str
XmJcxOTlfUHCzMdANkRtiesqEIuyPV=False
import sys
from kodiFunc import*
from kinoCore import*
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
MAIN_GROUP=[{'title':'트랜드 랭킹 (일간)','mode':'RANKING_MENU_GROUP','icon':'rank.png','values':{'rank_type':'daily'}},{'title':'-----------------','mode':'XXX','values':{}},{'title':'(키노) 검색','mode':'LOCAL_SEARCH_LIST','icon':'search.png','values':{'page_int':1,'searchAfter':XmJcxOTlfUHCzMdANkRtiesqEIuyPp}},{'title':'(키노) 검색기록','mode':'LOCAL_SEARCH_HIST','icon':'search_history.png','values':{}},]
CONTENT_GROUP1=[{'title':'콘텐츠 통합','mode':'CONTENT_RANKING','icon':'kinolight.png','values':{'rank_type':'daily','name':'kinolights','page_int':1}},{'title':'넷플릭스','mode':'CONTENT_RANKING','icon':'netflix.png','values':{'rank_type':'daily','name':'netflix','page_int':1}},{'title':'티빙','mode':'CONTENT_RANKING','icon':'tving.png','values':{'rank_type':'daily','name':'tving','page_int':1}},{'title':'쿠팡플레이','mode':'CONTENT_RANKING','icon':'coupang.png','values':{'rank_type':'daily','name':'coupang','page_int':1}},{'title':'웨이브','mode':'CONTENT_RANKING','icon':'wavve.png','values':{'rank_type':'daily','name':'wavve','page_int':1}},{'title':'디즈니+','mode':'CONTENT_RANKING','icon':'disney.jpg','values':{'rank_type':'daily','name':'disney','page_int':1}},{'title':'왓챠','mode':'CONTENT_RANKING','icon':'watcha.png','values':{'rank_type':'daily','name':'watcha','page_int':1}},]
CONTENT_GROUP2=[{'title':'콘텐츠 통합','mode':'CONTENT_RANKING','icon':'kinolight.png','values':{'rank_type':'chart','name':'kinolights','page_int':1}},{'title':'넷플릭스','mode':'CONTENT_RANKING','icon':'netflix.png','values':{'rank_type':'chart','name':'netflix','page_int':1}},{'title':'티빙','mode':'CONTENT_RANKING','icon':'tving.png','values':{'rank_type':'chart','name':'tving','page_int':1}},{'title':'쿠팡플레이','mode':'CONTENT_RANKING','icon':'coupang.png','values':{'rank_type':'chart','name':'coupang','page_int':1}},{'title':'웨이브','mode':'CONTENT_RANKING','icon':'wavve.png','values':{'rank_type':'chart','name':'wavve','page_int':1}},{'title':'디즈니+','mode':'CONTENT_RANKING','icon':'disney.jpg','values':{'rank_type':'chart','name':'disney','page_int':1}},{'title':'왓챠','mode':'CONTENT_RANKING','icon':'watcha.png','values':{'rank_type':'chart','name':'watcha','page_int':1}},{'title':'프라임비디오','mode':'CONTENT_RANKING','icon':'prime.png','values':{'rank_type':'chart','name':'prime','page_int':1}},]
OTT_INFO={'netflix':{'title':'넷플릭스','icon':'netflix.png','isType':'FOLDER','providerId':4},'tving':{'title':'티빙','icon':'tving.png','isType':'FOLDER','providerId':10},'coupang':{'title':'쿠팡플레이','icon':'coupang.png','isType':'FOLDER','providerId':14},'wavve':{'title':'웨이브','icon':'wavve.png','isType':'FOLDER','providerId':8},'disney':{'title':'디즈니+','icon':'disney.jpg','isType':'FOLDER','providerId':17},'watcha':{'title':'왓챠','icon':'watcha.png','isType':'FOLDER','providerId':5},'prime':{'title':'프라임비디오','icon':'prime.png','isType':'FOLDER','providerId':9},'apple':{'title':'애플TV','icon':'apple.png','isType':'-','providerId':16},'uplus':{'title':'U+모바일TV','icon':'uplus.jpg','isType':'-','providerId':18},'serieson':{'title':'네이버 시리즈온','icon':'serieson.png','isType':'-','providerId':1},'laftel':{'title':'라프텔','icon':'laftel.png','isType':'-','providerId':12},'cinema':{'title':'영화관','icon':'cinema.png','isType':'-','providerId':0},'none':{'title':'감상 플랫폼 없음','icon':'none.png','isType':'-','providerId':0},'-':{'title':'미분류','icon':'none.png','isType':'-','providerId':0},}
class XmJcxOTlfUHCzMdANkRtiesqEIuyPo(XmJcxOTlfUHCzMdANkRtiesqEIuyPD):
 def __init__(self,in_addonurl,in_handle,in_params):
  self.ADDON_URL =in_addonurl
  self.ADDON_HANDLE =in_handle
  self.MAIN_PARAMS =in_params
  self.KFuncObj =KodiFunc(in_addonurl,in_handle)
  self.KinoObj =mALFidpovQSxKItBTbHlzNrEPDRjGf() 
  self.KinoObj.KN_SEARCHED_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'kn_searched.json'))
  if xbmc.getCondVisibility('system.platform.android'):
   self.KinoObj.OS_ANDROID=XmJcxOTlfUHCzMdANkRtiesqEIuyPa
 def dp_Main_List(self):
  for main_group in MAIN_GROUP:
   title =main_group.get('title')
   icon_img=XmJcxOTlfUHCzMdANkRtiesqEIuyPp
   params={'mode':main_group.get('mode'),'values':main_group.get('values'),}
   if main_group.get('mode')in['XXX']:
    isType ='LINK'
   else:
    isType ='FOLDER'
   infoLabels={'title':title,'plot':title}
   if main_group.get('mode')=='XXX':infoLabels=XmJcxOTlfUHCzMdANkRtiesqEIuyPp
   if 'icon' in main_group:icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',main_group.get('icon')) 
   self.KFuncObj.Add_Dir(title,img=icon_img,infoLabels=infoLabels,isType=isType,ContextMenu=XmJcxOTlfUHCzMdANkRtiesqEIuyPp,params=params)
  xbmcplugin.endOfDirectory(self.ADDON_HANDLE)
 def Get_Ott_Info(self,ott):
  oInfo=OTT_INFO[ott]
  oInfo['icon']=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',oInfo['icon']) 
  return oInfo
 def dp_Ranking_Group(self,argsValue):
  rank_type=argsValue.get('rank_type')
  DP_LIST=CONTENT_GROUP2 if rank_type=='chart' else CONTENT_GROUP1
  for rank_group in DP_LIST:
   title =rank_group.get('title')
   icon_img=XmJcxOTlfUHCzMdANkRtiesqEIuyPp
   params={'mode':rank_group.get('mode'),'values':rank_group.get('values'),}
   isType ='FOLDER'
   infoLabels={'title':title,'plot':title}
   if 'icon' in rank_group:icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',rank_group.get('icon')) 
   self.KFuncObj.Add_Dir(title,img=icon_img,infoLabels=infoLabels,isType=isType,ContextMenu=XmJcxOTlfUHCzMdANkRtiesqEIuyPp,params=params)
  xbmcplugin.endOfDirectory(self.ADDON_HANDLE)
 def dp_Content_Ranking(self,argsValue):
  ottNm =argsValue.get('name')
  page_int =argsValue.get('page_int')
  rank_type=argsValue.get('rank_type')
  self.KFuncObj.Addon_Log('ottNm     : '+ottNm)
  self.KFuncObj.Addon_Log('page_int  : '+XmJcxOTlfUHCzMdANkRtiesqEIuyPw(page_int))
  self.KFuncObj.Addon_Log('rank_type : '+rank_type)
  if ottNm=='kinolights':
   providerId=0
  else:
   providerId=OTT_INFO[ottNm]['providerId']
  if rank_type=='chart':
   RES_LIST=self.KinoObj.Get_Content_Ranking_2(providerId,page_int)
  else:
   RES_LIST=self.KinoObj.Get_Content_Ranking_3(providerId)
   page_int=5 
  for i_res in RES_LIST:
   seq =i_res.get('seq')
   title =i_res.get('title')
   contentid=i_res.get('contentid')
   mediaType=i_res.get('mediaType')
   image ={'poster':i_res.get('poster'),'thumb':i_res.get('poster'),} 
   params={'mode':'CONTENT_VIEW','values':{'contentid':contentid,}}
   infoLabels={'mediatype':'tvshow' if mediaType=='TV' else 'movie','title':title,'plot':title}
   title='{}. {}'.format(seq,title)
   subTitle='TV' if mediaType=='TV' else ''
   self.KFuncObj.Add_Dir(title,subTitle=subTitle,img=image,infoLabels=infoLabels,isType='FOLDER',ContextMenu=XmJcxOTlfUHCzMdANkRtiesqEIuyPp,params=params)
  if page_int<5:
   title ='[B]%s >>[/B]'%'다음 페이지'
   params={'mode':'CONTENT_RANKING','values':{'name':ottNm,'page_int':page_int+1,'rank_type':rank_type,}}
   subtitle=XmJcxOTlfUHCzMdANkRtiesqEIuyPw(page_int+1)
   icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   self.KFuncObj.Add_Dir(title,subTitle=subtitle,img=icon_img,infoLabels=XmJcxOTlfUHCzMdANkRtiesqEIuyPp,isType='FOLDER',ContextMenu=XmJcxOTlfUHCzMdANkRtiesqEIuyPp,params=params)
  xbmcplugin.endOfDirectory(self.ADDON_HANDLE)
 def dp_Content_View(self,argsValue):
  contentid=argsValue.get('contentid')
  self.KFuncObj.Addon_Log('local contentid : '+XmJcxOTlfUHCzMdANkRtiesqEIuyPw(contentid))
  cInfo=self.KinoObj.Get_Content_Info(contentid)
  plot =cInfo['infoLabels']['plot']
  imdb =cInfo['imdb']
  rating=cInfo['rating']
  cInfo['infoLabels']['plot']='키노  Score : {}\nIMDB Score : {}\n\n{}'.format(rating,imdb,plot)
  for i_res in cInfo['ott']:
   provider=self.Get_Ott_Info(i_res['provider'])
   params={'mode':'OTT_LINK','values':{'contentid':i_res['contentid'],'provider':i_res['provider'],'mediatype':i_res['mediatype'],}}
   IMG =cInfo['thumbnail']
   IMG['icon']=provider['icon']
   hyperLink=self.make_Hyper_Link(i_res,cInfo)
   infoLabels=cInfo['infoLabels']
   isType=provider['isType']
   if i_res['mediatype']=='MOVIE' and provider['isType']!='-':isType='VOD'
   title=provider['title']
   if i_res['openDate']not in['',XmJcxOTlfUHCzMdANkRtiesqEIuyPp]:
    title='{} (공개 : {})'.format(provider['title'],i_res['openDate'])
   self.KFuncObj.Add_Dir(title,subTitle=i_res['properties'],img=IMG,infoLabels=infoLabels,isType=isType,ContextMenu=XmJcxOTlfUHCzMdANkRtiesqEIuyPp,params=params,direct_url=hyperLink)
  for i_cast in cInfo['infoLabels']['cast']:
   params={'mode':'FILMO_LIST','values':{'personid':i_cast['personid'],'page_int':1,}}
   infoLabels={'title':i_cast['name'],}
   IMG =i_cast['thumbnail']
   self.KFuncObj.Add_Dir(i_cast['name'],subTitle=i_cast['role'],img=IMG,infoLabels=infoLabels,isType='FOLDER',ContextMenu=XmJcxOTlfUHCzMdANkRtiesqEIuyPp,params=params)
  xbmcplugin.endOfDirectory(self.ADDON_HANDLE,cacheToDisc=XmJcxOTlfUHCzMdANkRtiesqEIuyPV)
 def dp_Person_Ranking(self,argsValue):
  RES_LIST=self.KinoObj.Get_Person_Ranking()
  for i_res in RES_LIST:
   seq =i_res.get('seq')
   name =i_res.get('name')
   personid =i_res.get('personid')
   image ={'poster':i_res.get('poster'),'thumb':i_res.get('poster'),} 
   params={'mode':'FILMO_LIST','values':{'personid':personid,'page_int':1,}}
   infoLabels={'title':name,'plot':name}
   title='{}. {}'.format(seq,name)
   self.KFuncObj.Add_Dir(title,img=image,infoLabels=infoLabels,isType='FOLDER',ContextMenu=XmJcxOTlfUHCzMdANkRtiesqEIuyPp,params=params)
  xbmcplugin.endOfDirectory(self.ADDON_HANDLE)
 def dp_Filmography_List(self,argsValue):
  personid=argsValue.get('personid')
  page_int=argsValue.get('page_int')
  RES_INFO=self.KinoObj.Get_Filmography_List(personid,page_int)
  for i_res in RES_INFO['filmo_list']:
   title =i_res.get('title')
   contentid =i_res.get('contentid')
   mediaType =i_res.get('mediaType')
   rating =i_res.get('rating')
   image =i_res.get('thumbnail')
   params={'mode':'CONTENT_VIEW','values':{'contentid':contentid,}}
   infoLabels={'mediatype':'tvshow' if mediaType=='TV' else 'movie','title':title,'plot':'키노  Score : {}'.format(rating)}
   subTitle='TV' if mediaType=='TV' else ''
   self.KFuncObj.Add_Dir(title,subTitle=subTitle,img=image,infoLabels=infoLabels,isType='FOLDER',ContextMenu=XmJcxOTlfUHCzMdANkRtiesqEIuyPp,params=params)
  if RES_INFO['more_page']:
   title ='[B]%s >>[/B]'%'다음 페이지'
   params={'mode':'FILMO_LIST','values':{'personid':personid,'page_int':page_int+1,}}
   subtitle=XmJcxOTlfUHCzMdANkRtiesqEIuyPw(page_int+1)
   icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   self.KFuncObj.Add_Dir(title,subTitle=subtitle,img=icon_img,infoLabels=XmJcxOTlfUHCzMdANkRtiesqEIuyPp,isType='FOLDER',ContextMenu=XmJcxOTlfUHCzMdANkRtiesqEIuyPp,params=params)
  xbmcplugin.setContent(self.ADDON_HANDLE,'tvshows')
  xbmcplugin.endOfDirectory(self.ADDON_HANDLE)
 def make_Hyper_Link(self,argsValue,contentInfo):
  provider =argsValue.get('provider')
  contentid=argsValue.get('contentid')
  mediatype=argsValue.get('mediatype')
  result_url=XmJcxOTlfUHCzMdANkRtiesqEIuyPp
  if OTT_INFO[provider]['isType']!='FOLDER':return result_url
  self.KFuncObj.Addon_Log('provider contentid : '+provider+' - '+XmJcxOTlfUHCzMdANkRtiesqEIuyPw(contentid))
  if provider=='netflix':
   if mediatype=='TV':
    result_url='plugin://plugin.video.netflix/directory/show/{}'.format(contentid)
   else:
    result_url='plugin://plugin.video.netflix/play/movie/{}'.format(contentid)
  elif provider=='tving':
   if mediatype=='TV':
    ott_param={'mode':'EPISODE','programcode':XmJcxOTlfUHCzMdANkRtiesqEIuyPw(contentid),'page':'1',}
   else:
    ott_param={'mode':'MOVIE','stype':'movie','mediacode':XmJcxOTlfUHCzMdANkRtiesqEIuyPw(contentid),'title':contentInfo['title'],'thumbnail':contentInfo['thumbnail'],}
   ott_param_str=urllib.parse.urlencode(ott_param)
   result_url='plugin://plugin.video.tvingm/?'
   result_url+=ott_param_str
  elif provider=='coupang':
   if mediatype=='TV':
    ott_param={'mode':'SEASON_LIST','id':XmJcxOTlfUHCzMdANkRtiesqEIuyPw(contentid),'asis':'TVSHOW','title':contentInfo['title'],'thumbnail':contentInfo['thumbnail'],'page':'1',}
   else:
    ott_param={'mode':'MOVIE','id':XmJcxOTlfUHCzMdANkRtiesqEIuyPw(contentid),'asis':'MOVIE','title':contentInfo['title'],'thumbnail':contentInfo['thumbnail'],}
   ott_param_str=urllib.parse.urlencode(ott_param)
   result_url='plugin://plugin.video.coupangm/?'
   result_url+=ott_param_str
  elif provider=='watcha':
   if mediatype=='TV':
    ott_param={'mode':'EPISODE','movie_code':XmJcxOTlfUHCzMdANkRtiesqEIuyPw(contentid),'season_code':XmJcxOTlfUHCzMdANkRtiesqEIuyPw(contentid),'page':'1',}
   else:
    ott_param={'mode':'MOVIE','movie_code':XmJcxOTlfUHCzMdANkRtiesqEIuyPw(contentid),'season_code':'-','title':contentInfo['title'],'thumbnail':contentInfo['thumbnail'],}
   ott_param_str=urllib.parse.urlencode(ott_param)
   result_url='plugin://plugin.video.watcham/?'
   result_url+=ott_param_str
  elif provider=='wavve':
   if mediatype=='TV':
    ott_param={'mode':'SEASON_LIST','videoid':XmJcxOTlfUHCzMdANkRtiesqEIuyPw(contentid),'vidtype':'tvshow',}
   else:
    ott_param={'mode':'MOVIE','contentid':XmJcxOTlfUHCzMdANkRtiesqEIuyPw(contentid),'title':contentInfo['title'],'thumbnail':contentInfo['thumbnail'],}
   ott_param_str=urllib.parse.urlencode(ott_param)
   result_url='plugin://plugin.video.wavvem/?'
   result_url+=ott_param_str
  elif provider=='disney':
   if mediatype=='TV':
    ott_param={'mode':'SEASON_LIST','values':{'entityId':XmJcxOTlfUHCzMdANkRtiesqEIuyPw(contentid),'vType':'tvshow','image':contentInfo['thumbnail'],'title':contentInfo['title'],'programTitle':contentInfo['title'],'infoLabels':contentInfo['infoLabels'],}}
   else:
    ott_param={'mode':'MOVIE','values':{'contentId':XmJcxOTlfUHCzMdANkRtiesqEIuyPw(contentid),'vType':'kinolight','image':contentInfo['thumbnail'],'title':contentInfo['title'],'programTitle':contentInfo['title'],'infoLabels':contentInfo['infoLabels'],}}
   ott_param_str=json.dumps(ott_param,separators=(',',':'))
   ott_param_str=base64.standard_b64encode(ott_param_str.encode()).decode('utf-8')
   ott_param_str=ott_param_str.replace('+','%2B')
   result_url='plugin://plugin.video.disneym/?params='
   result_url+=ott_param_str
  elif provider=='prime':
   if mediatype=='TV':
    ott_param={'mode':'SEASON_LIST','values':{'titleID':XmJcxOTlfUHCzMdANkRtiesqEIuyPw(contentid),'linkUrl':'/detail/{}'.format(XmJcxOTlfUHCzMdANkRtiesqEIuyPw(contentid)),}}
   else:
    ott_param={'mode':'MOVIE','values':{'titleID':XmJcxOTlfUHCzMdANkRtiesqEIuyPw(contentid),'vType':'kino_movie','image':contentInfo['thumbnail'],'title':contentInfo['title'],'infoLabels':contentInfo['infoLabels'],}}
   ott_param_str=json.dumps(ott_param,separators=(',',':'))
   ott_param_str=base64.standard_b64encode(ott_param_str.encode()).decode('utf-8')
   ott_param_str=ott_param_str.replace('+','%2B')
   result_url='plugin://plugin.video.primevm/?params='
   result_url+=ott_param_str
  return result_url
 def Searched_Save(self,sKey):
  HistoryFile_Insert(self.KinoObj.KN_SEARCHED_FILENAME,sKey)
 def Searched_Load(self):
  return HistoryFile_Load(self.KinoObj.KN_SEARCHED_FILENAME)
 def Searched_Remove(self,delType,sKey='-'):
  if delType=='ALL':
   File_Delete(self.KinoObj.KN_SEARCHED_FILENAME)
  else:
   HistoryFile_Remove(self.KinoObj.KN_SEARCHED_FILENAME,sKey=sKey)
 def dp_History_Remove(self,argsValue):
  delType=argsValue.get('delType')
  sKey =argsValue.get('sKey')
  dialog=xbmcgui.Dialog()
  if delType=='SEARCH_ALL':
   ret=dialog.yesno(__language__(30911).encode('utf8'),__language__(30903).encode('utf8'))
  elif delType=='SEARCH_ONE':
   ret=dialog.yesno(__language__(30912).encode('utf8'),__language__(30903).encode('utf8'))
  if ret==XmJcxOTlfUHCzMdANkRtiesqEIuyPV:sys.exit()
  if delType=='SEARCH_ALL':
   self.Searched_Remove('ALL',sKey='-')
  elif delType=='SEARCH_ONE':
   self.Searched_Remove('ONE',sKey=sKey)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Local_SearchList(self,argsValue):
  page_int=argsValue.get('page_int')
  searchAfter=argsValue.get('searchAfter')
  if 'search_key' in argsValue:
   search_key=argsValue.get('search_key')
  else:
   search_key=self.KFuncObj.Get_Keyboard_Input(__language__(30902).encode('utf-8'))
   if not search_key:
    return
   self.Searched_Save(search_key)
  RES_INFO=self.KinoObj.Get_Search_List(search_key,page_int,searchAfter)
  for i_res in RES_INFO['search_list']:
   title =i_res.get('title')
   contentid =i_res.get('contentid')
   mediaType =i_res.get('mediaType')
   imdb =i_res.get('imdb')
   rating =i_res.get('rating')
   image =i_res.get('thumbnail')
   synopsis =i_res.get('synopsis')
   params={'mode':'CONTENT_VIEW','values':{'contentid':contentid,}}
   infoLabels={'mediatype':'tvshow' if mediaType=='TV' else 'movie','title':title,'plot':'키노  Score : {}\nIMDB Score : {}\n\n{}'.format(rating,imdb,synopsis)}
   subTitle='TV' if mediaType=='TV' else ''
   self.KFuncObj.Add_Dir(title,subTitle=subTitle,img=image,infoLabels=infoLabels,isType='FOLDER',ContextMenu=XmJcxOTlfUHCzMdANkRtiesqEIuyPp,params=params)
  if RES_INFO['more_page']:
   title ='[B]%s >>[/B]'%'다음 페이지'
   params={'mode':'LOCAL_SEARCH_LIST','values':{'search_key':search_key,'page_int':page_int+1,'searchAfter':RES_INFO['searchAfter'],}}
   subtitle=XmJcxOTlfUHCzMdANkRtiesqEIuyPw(page_int+1)
   icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   self.KFuncObj.Add_Dir(title,subTitle=subtitle,img=icon_img,infoLabels=XmJcxOTlfUHCzMdANkRtiesqEIuyPp,isType='FOLDER',ContextMenu=XmJcxOTlfUHCzMdANkRtiesqEIuyPp,params=params)
  xbmcplugin.setContent(self.ADDON_HANDLE,'tvshows')
  xbmcplugin.endOfDirectory(self.ADDON_HANDLE)
 def dp_Local_SearchHist(self,argsValue):
  SEARCH_HISTORY=self.Searched_Load()
  for search_history in SEARCH_HISTORY:
   sKey =search_history.get('sKey')
   params={'mode':'LOCAL_SEARCH_LIST','values':{'search_key':sKey,}}
   menu_param={'mode':'LOCAL_SEARCH_REMOVE','values':{'delType':'SEARCH_ONE','sKey':sKey,}}
   menu_param_str=Params_JsonToStr(menu_param)
   ContextMenu=[('선택된 검색어 ( %s ) 삭제'%(sKey),'RunPlugin(plugin://plugin.video.kinolightsm/?params=%s)'%(menu_param_str))]
   infoLabels={'plot':'개별삭제는 팝업메뉴 사용'}
   self.KFuncObj.Add_Dir(sKey,subTitle='',img=XmJcxOTlfUHCzMdANkRtiesqEIuyPp,infoLabels=infoLabels,isType='FOLDER',ContextMenu=ContextMenu,params=params)
  infoLabels={'plot':'검색목록 전체를 삭제합니다.'}
  title ='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  params={'mode':'LOCAL_SEARCH_REMOVE','values':{'delType':'SEARCH_ALL','sKey':'-',}}
  icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  self.KFuncObj.Add_Dir(title,subTitle='',img=icon_img,infoLabels=infoLabels,isType='FOLDER',ContextMenu=XmJcxOTlfUHCzMdANkRtiesqEIuyPp,params=params)
  xbmcplugin.endOfDirectory(self.ADDON_HANDLE,cacheToDisc=XmJcxOTlfUHCzMdANkRtiesqEIuyPV)
 def kino_main(self):
  if not os.path.isdir(xbmcvfs.translatePath(__profile__)):os.mkdir(xbmcvfs.translatePath(__profile__))
  mode =XmJcxOTlfUHCzMdANkRtiesqEIuyPp
  paramJson={}
  paramText=self.MAIN_PARAMS.get('params')
  if paramText:
   paramJson =Params_StrToJson(paramText)
   mode =paramJson.get('mode')
   argsValue =paramJson.get('values')
  if mode is XmJcxOTlfUHCzMdANkRtiesqEIuyPp:
   self.dp_Main_List()
  elif mode=='RANKING_MENU_GROUP':
   self.dp_Ranking_Group(argsValue)
  elif mode=='CONTENT_RANKING':
   self.dp_Content_Ranking(argsValue)
  elif mode=='CONTENT_VIEW':
   self.dp_Content_View(argsValue)
  elif mode=='PERSON_RANKING':
   self.dp_Person_Ranking(argsValue)
  elif mode=='FILMO_LIST':
   self.dp_Filmography_List(argsValue)
  elif mode=='LOCAL_SEARCH_LIST':
   self.dp_Local_SearchList(argsValue)
  elif mode=='LOCAL_SEARCH_REMOVE':
   self.dp_History_Remove(argsValue)
  elif mode=='LOCAL_SEARCH_HIST':
   self.dp_Local_SearchHist(argsValue)
  else:
   XmJcxOTlfUHCzMdANkRtiesqEIuyPp
# Created by pyminifier (https://github.com/liftoff/pyminifier)
