_AB='[B]%s >>[/B]'
_AA='more_page'
_A9='키노  Score : {}\nIMDB Score : {}\n\n{}'
_A8='LOCAL_SEARCH_HIST'
_A7='RANKING_MENU_GROUP'
_A6='LOCAL_SEARCH_REMOVE'
_A5='SEARCH_ONE'
_A4='SEARCH_ALL'
_A3='delType'
_A2='utf-8'
_A1='FILMO_LIST'
_A0='rating'
_z='mediaType'
_y='watcha.png'
_x='disney.jpg'
_w='디즈니+'
_v='wavve.png'
_u='웨이브'
_t='coupang.png'
_s='쿠팡플레이'
_r='tving.png'
_q='netflix.png'
_p='넷플릭스'
_o='kinolights'
_n='kinolight.png'
_m='XXX'
_l='search_key'
_k='sKey'
_j='personid'
_i='provider'
_h='movie'
_g='CONTENT_VIEW'
_f='watcha'
_e='disney'
_d='wavve'
_c='coupang'
_b='tving'
_a='netflix'
_Z='searchAfter'
_Y='LOCAL_SEARCH_LIST'
_X='tvshow'
_W='img'
_V='path'
_U='mediatype'
_T='daily'
_S='rank_type'
_R='MOVIE'
_Q='plot'
_P='infoLabels'
_O='contentid'
_N='-'
_M='TV'
_L='providerId'
_K='CONTENT_RANKING'
_J='thumbnail'
_I='isType'
_H='FOLDER'
_G='name'
_F=None
_E='page_int'
_D='values'
_C='icon'
_B='mode'
_A='title'
__author__='NightRain'
import sys
from kodiFunc import*
from kinoCore import*
__addon__=xbmcaddon.Addon()
__language__=__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo(_G)
MAIN_GROUP=[{_A:'랭킹 차트',_B:_A7,_C:'rank.png'},{_A:'-----------------',_B:_m,_D:{}},{_A:'(키노) 검색',_B:_Y,_C:'search.png',_D:{_E:1,_Z:_F}},{_A:'(키노) 검색기록',_B:_A8,_C:'search_history.png',_D:{}}]
CONTENT_GROUP=[{_A:'전체',_B:_K,_C:_n,_D:{_G:_o,_E:1}},{_A:'박스오피스',_B:_K,_C:'popcorn.png',_D:{_G:'cinema',_E:1}},{_A:_p,_B:_K,_C:_q,_D:{_G:_a,_E:1}},{_A:'티빙',_B:_K,_C:_r,_D:{_G:_b,_E:1}},{_A:_s,_B:_K,_C:_t,_D:{_G:_c,_E:1}},{_A:_u,_B:_K,_C:_v,_D:{_G:_d,_E:1}},{_A:_w,_B:_K,_C:_x,_D:{_G:_e,_E:1}},{_A:'왓챠',_B:_K,_C:_y,_D:{_G:_f,_E:1}}]
CONTENT_GROUP1=[{_A:'콘텐츠 통합',_B:_K,_C:_n,_D:{_S:_T,_G:_o,_E:1}},{_A:_p,_B:_K,_C:_q,_D:{_S:_T,_G:_a,_E:1}},{_A:'티빙',_B:_K,_C:_r,_D:{_S:_T,_G:_b,_E:1}},{_A:_s,_B:_K,_C:_t,_D:{_S:_T,_G:_c,_E:1}},{_A:_u,_B:_K,_C:_v,_D:{_S:_T,_G:_d,_E:1}},{_A:_w,_B:_K,_C:_x,_D:{_S:_T,_G:_e,_E:1}},{_A:'왓챠',_B:_K,_C:_y,_D:{_S:_T,_G:_f,_E:1}}]
OTT_INFO={_a:{_A:_p,_C:_q,_I:_H,_L:4},_b:{_A:'티빙',_C:_r,_I:_H,_L:10},_c:{_A:_s,_C:_t,_I:_H,_L:14},_d:{_A:_u,_C:_v,_I:_H,_L:8},_e:{_A:_w,_C:_x,_I:_H,_L:17},_f:{_A:'왓챠',_C:_y,_I:_H,_L:5},'prime':{_A:'프라임비디오',_C:'prime.png',_I:_H,_L:9},'apple':{_A:'애플TV',_C:'apple.png',_I:_N,_L:16},'uplus':{_A:'U+모바일TV',_C:'uplus.jpg',_I:_N,_L:18},'serieson':{_A:'네이버 시리즈온',_C:'serieson.png',_I:_N,_L:1},'laftel':{_A:'라프텔',_C:'laftel.png',_I:_N,_L:12},'cinema':{_A:'영화관',_C:'cinema.png',_I:_N,_L:0},'none':{_A:'감상 플랫폼 없음',_C:'none.png',_I:_N,_L:0},_N:{_A:'미분류',_C:'none.png',_I:_N,_L:0},_o:{_A:'전체',_C:_n,_I:_H,_L:0}}
class KinoRun:
	def __init__(self,in_addonurl,in_handle,in_params):
		self.ADDON_URL=in_addonurl;self.ADDON_HANDLE=in_handle;self.MAIN_PARAMS=in_params;self.KFuncObj=KodiFunc(in_addonurl,in_handle);self.KinoObj=Kino();self.KinoObj.KN_SEARCHED_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'kn_searched.json'))
		if xbmc.getCondVisibility('system.platform.android'):self.KinoObj.OS_ANDROID=True
	def dp_Main_List(self):
		for main_group in MAIN_GROUP:
			title=main_group.get(_A);icon_img=_F;params={_B:main_group.get(_B),_D:main_group.get(_D)}
			if main_group.get(_B)in[_m]:isType='LINK'
			else:isType=_H
			infoLabels={_A:title,_Q:title}
			if main_group.get(_B)==_m:infoLabels=_F
			if _C in main_group:icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_V),_W,main_group.get(_C))
			self.KFuncObj.Add_Dir(title,img=icon_img,infoLabels=infoLabels,isType=isType,ContextMenu=_F,params=params)
		xbmcplugin.endOfDirectory(self.ADDON_HANDLE)
	def Get_Ott_Info(self,ott):oInfo=OTT_INFO[ott];oInfo[_C]=os.path.join(xbmcaddon.Addon().getAddonInfo(_V),_W,oInfo[_C]);return oInfo
	def dp_Ranking_Group(self,argsValue):
		for rank_group in CONTENT_GROUP:
			title=rank_group.get(_A);icon_img=_F;params={_B:rank_group.get(_B),_D:rank_group.get(_D)};isType=_H;infoLabels={_A:title,_Q:title}
			if _C in rank_group:icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_V),_W,rank_group.get(_C))
			self.KFuncObj.Add_Dir(title,img=icon_img,infoLabels=infoLabels,isType=isType,ContextMenu=_F,params=params)
		xbmcplugin.endOfDirectory(self.ADDON_HANDLE)
	def dp_Content_Ranking(self,argsValue):
		A='poster';ottNm=argsValue.get(_G);page_int=argsValue.get(_E);self.KFuncObj.Addon_Log('ottNm     : '+ottNm);self.KFuncObj.Addon_Log('page_int  : '+str(page_int));"\n\t\tif ottNm == 'kinolights':\n\t\t\tproviderId = 0\n\t\telse:\n\t\t\tproviderId = OTT_INFO[ottNm]['providerId']\n\t\t";providerId=OTT_INFO[ottNm][_L];RES_LIST=self.KinoObj.Get_Content_Ranking(ottNm,providerId)
		for i_res in RES_LIST:seq=i_res.get('seq');title=i_res.get(_A);contentid=i_res.get(_O);mediaType=i_res.get(_z);image={A:i_res.get(A),'thumb':i_res.get(A)};params={_B:_g,_D:{_O:contentid}};infoLabels={_U:_X if mediaType==_M else _h,_A:title,_Q:title};title='{}. {}'.format(seq,title);subTitle=_M if mediaType==_M else'';self.KFuncObj.Add_Dir(title,subTitle=subTitle,img=image,infoLabels=infoLabels,isType=_H,ContextMenu=_F,params=params)
		"\n\t\tif page_int < 5 :\n\t\t\ttitle  = '[B]%s >>[/B]' %'다음 페이지'\n\t\t\tparams = {\n\t\t\t\t\t\t'mode'      : 'CONTENT_RANKING',\n\t\t\t\t\t\t'values'    : {\n\t\t\t\t\t\t\t\t\t\t'name'\t    : ottNm,\n\t\t\t\t\t\t\t\t\t\t'page_int'  : page_int + 1,\n\t\t\t\t\t\t}\n\t\t\t}\n\t\t\tsubtitle = str(page_int + 1)\n\t\t\ticon_img = os.path.join( xbmcaddon.Addon().getAddonInfo('path'), 'img', 'next.png' )\n\t\t\tself.KFuncObj.Add_Dir( title, subTitle=subtitle, img=icon_img, infoLabels=None, isType='FOLDER', ContextMenu=None, params=params )\n\t\t";xbmcplugin.endOfDirectory(self.ADDON_HANDLE)
	def dp_Content_View(self,argsValue):
		A='openDate';contentid=argsValue.get(_O);self.KFuncObj.Addon_Log('local contentid : '+str(contentid));cInfo=self.KinoObj.Get_Content_Info(contentid);plot=cInfo[_P][_Q];imdb=cInfo['imdb'];rating=cInfo[_A0];cInfo[_P][_Q]=_A9.format(rating,imdb,plot)
		for i_res in cInfo['ott']:
			provider=self.Get_Ott_Info(i_res[_i]);params={_B:'OTT_LINK',_D:{_O:i_res[_O],_i:i_res[_i],_U:i_res[_U]}};IMG=cInfo[_J];IMG[_C]=provider[_C];hyperLink=self.make_Hyper_Link(i_res,cInfo);infoLabels=cInfo[_P];isType=provider[_I]
			if i_res[_U]==_R and provider[_I]!=_N:isType='VOD'
			title=provider[_A]
			if i_res[A]not in['',_F]:title='{} (공개 : {})'.format(provider[_A],i_res[A])
			self.KFuncObj.Add_Dir(title,subTitle=i_res['properties'],img=IMG,infoLabels=infoLabels,isType=isType,ContextMenu=_F,params=params,direct_url=hyperLink)
		for i_cast in cInfo[_P]['cast']:params={_B:_A1,_D:{_j:i_cast[_j],_E:1}};infoLabels={_A:i_cast[_G]};IMG=i_cast[_J];self.KFuncObj.Add_Dir(i_cast[_G],subTitle=i_cast['role'],img=IMG,infoLabels=infoLabels,isType=_H,ContextMenu=_F,params=params)
		xbmcplugin.endOfDirectory(self.ADDON_HANDLE,cacheToDisc=False)
	def dp_Filmography_List(self,argsValue):
		personid=argsValue.get(_j);page_int=argsValue.get(_E);self.KFuncObj.Addon_Log('personid : '+str(personid));RES_INFO=self.KinoObj.Get_Filmography_List(personid,page_int)
		for i_res in RES_INFO['filmo_list']:title=i_res.get(_A);contentid=i_res.get(_O);mediaType=i_res.get(_z);rating=i_res.get(_A0);image=i_res.get(_J);params={_B:_g,_D:{_O:contentid}};infoLabels={_U:_X if mediaType==_M else _h,_A:title,_Q:'키노  Score : {}'.format(rating)};subTitle=_M if mediaType==_M else'';self.KFuncObj.Add_Dir(title,subTitle=subTitle,img=image,infoLabels=infoLabels,isType=_H,ContextMenu=_F,params=params)
		if RES_INFO[_AA]:title=_AB%'다음 페이지';params={_B:_A1,_D:{_j:personid,_E:page_int+1}};subtitle=str(page_int+1);icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_V),_W,'next.png');self.KFuncObj.Add_Dir(title,subTitle=subtitle,img=icon_img,infoLabels=_F,isType=_H,ContextMenu=_F,params=params)
		xbmcplugin.setContent(self.ADDON_HANDLE,'tvshows');xbmcplugin.endOfDirectory(self.ADDON_HANDLE)
	def make_Hyper_Link(self,argsValue,contentInfo):
		M='titleID';L='%2B';K='programTitle';J='entityId';I='season_code';H='movie_code';G='asis';F='EPISODE';E='image';D='vType';C='1';B='page';A='SEASON_LIST';provider=argsValue.get(_i);contentid=argsValue.get(_O);mediatype=argsValue.get(_U);result_url=_F
		if OTT_INFO[provider][_I]!=_H:return result_url
		self.KFuncObj.Addon_Log('provider contentid : '+provider+' - '+str(contentid))
		if provider==_a:
			if mediatype==_M:result_url='plugin://plugin.video.netflix/directory/show/{}'.format(contentid)
			else:result_url='plugin://plugin.video.netflix/play/movie/{}'.format(contentid)
		elif provider==_b:
			if mediatype==_M:ott_param={_B:F,'programcode':str(contentid),B:C}
			else:ott_param={_B:_R,'stype':_h,'mediacode':str(contentid),_A:contentInfo[_A],_J:contentInfo[_J]}
			ott_param_str=urllib.parse.urlencode(ott_param);result_url='plugin://plugin.video.tvingm/?';result_url+=ott_param_str
		elif provider==_c:
			if mediatype==_M:ott_param={_B:A,'id':str(contentid),G:'TVSHOW',_A:contentInfo[_A],_J:contentInfo[_J],B:C}
			else:ott_param={_B:_R,'id':str(contentid),G:_R,_A:contentInfo[_A],_J:contentInfo[_J]}
			ott_param_str=urllib.parse.urlencode(ott_param);result_url='plugin://plugin.video.coupangm/?';result_url+=ott_param_str
		elif provider==_f:
			if mediatype==_M:ott_param={_B:F,H:str(contentid),I:str(contentid),B:C}
			else:ott_param={_B:_R,H:str(contentid),I:_N,_A:contentInfo[_A],_J:contentInfo[_J]}
			ott_param_str=urllib.parse.urlencode(ott_param);result_url='plugin://plugin.video.watcham/?';result_url+=ott_param_str
		elif provider==_d:
			if mediatype==_M:ott_param={_B:A,'videoid':str(contentid),'vidtype':_X}
			else:ott_param={_B:_R,_O:str(contentid),_A:contentInfo[_A],_J:contentInfo[_J]}
			ott_param_str=urllib.parse.urlencode(ott_param);result_url='plugin://plugin.video.wavvem/?';result_url+=ott_param_str
		elif provider==_e:
			if mediatype==_M:ott_param={_B:A,_D:{J:str(contentid),D:_X,E:contentInfo[_J],_A:contentInfo[_A],K:contentInfo[_A],_P:contentInfo[_P]}}
			else:ott_param={_B:_R,_D:{J:str(contentid),D:'kinolight',E:contentInfo[_J],_A:contentInfo[_A],K:contentInfo[_A],_P:contentInfo[_P]}}
			ott_param_str=json.dumps(ott_param,separators=(',',':'));ott_param_str=base64.standard_b64encode(ott_param_str.encode()).decode(_A2);ott_param_str=ott_param_str.replace('+',L);result_url='plugin://plugin.video.disneym/?params=';result_url+=ott_param_str
		elif provider=='prime':
			if mediatype==_M:ott_param={_B:A,_D:{M:str(contentid),'linkUrl':'/detail/{}'.format(str(contentid))}}
			else:ott_param={_B:_R,_D:{M:str(contentid),D:'kino_movie',E:contentInfo[_J],_A:contentInfo[_A],_P:contentInfo[_P]}}
			ott_param_str=json.dumps(ott_param,separators=(',',':'));ott_param_str=base64.standard_b64encode(ott_param_str.encode()).decode(_A2);ott_param_str=ott_param_str.replace('+',L);result_url='plugin://plugin.video.primevm/?params=';result_url+=ott_param_str
		return result_url
	def Searched_Save(self,sKey):HistoryFile_Insert(self.KinoObj.KN_SEARCHED_FILENAME,sKey)
	def Searched_Load(self):return HistoryFile_Load(self.KinoObj.KN_SEARCHED_FILENAME)
	def Searched_Remove(self,delType,sKey=_N):
		if delType=='ALL':File_Delete(self.KinoObj.KN_SEARCHED_FILENAME)
		else:HistoryFile_Remove(self.KinoObj.KN_SEARCHED_FILENAME,sKey=sKey)
	def dp_History_Remove(self,argsValue):
		A='utf8';delType=argsValue.get(_A3);sKey=argsValue.get(_k);dialog=xbmcgui.Dialog()
		if delType==_A4:ret=dialog.yesno(__language__(30911).encode(A),__language__(30903).encode(A))
		elif delType==_A5:ret=dialog.yesno(__language__(30912).encode(A),__language__(30903).encode(A))
		if ret==False:sys.exit()
		if delType==_A4:self.Searched_Remove('ALL',sKey=_N)
		elif delType==_A5:self.Searched_Remove('ONE',sKey=sKey)
		xbmc.executebuiltin('Container.Refresh')
	def dp_Local_SearchList(self,argsValue):
		page_int=argsValue.get(_E);searchAfter=argsValue.get(_Z)
		if _l in argsValue:search_key=argsValue.get(_l)
		else:
			search_key=self.KFuncObj.Get_Keyboard_Input(__language__(30902).encode(_A2))
			if not search_key:return
			self.Searched_Save(search_key)
		RES_INFO=self.KinoObj.Get_Search_List(search_key,page_int,searchAfter)
		for i_res in RES_INFO['search_list']:title=i_res.get(_A);contentid=i_res.get(_O);mediaType=i_res.get(_z);imdb=i_res.get('imdb');rating=i_res.get(_A0);image=i_res.get(_J);synopsis=i_res.get('synopsis');params={_B:_g,_D:{_O:contentid}};infoLabels={_U:_X if mediaType==_M else _h,_A:title,_Q:_A9.format(rating,imdb,synopsis)};subTitle=_M if mediaType==_M else'';self.KFuncObj.Add_Dir(title,subTitle=subTitle,img=image,infoLabels=infoLabels,isType=_H,ContextMenu=_F,params=params)
		if RES_INFO[_AA]:title=_AB%'다음 페이지';params={_B:_Y,_D:{_l:search_key,_E:page_int+1,_Z:RES_INFO[_Z]}};subtitle=str(page_int+1);icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_V),_W,'next.png');self.KFuncObj.Add_Dir(title,subTitle=subtitle,img=icon_img,infoLabels=_F,isType=_H,ContextMenu=_F,params=params)
		xbmcplugin.setContent(self.ADDON_HANDLE,'tvshows');xbmcplugin.endOfDirectory(self.ADDON_HANDLE)
	def dp_Local_SearchHist(self,argsValue):
		SEARCH_HISTORY=self.Searched_Load()
		for search_history in SEARCH_HISTORY:sKey=search_history.get(_k);params={_B:_Y,_D:{_l:sKey}};menu_param={_B:_A6,_D:{_A3:_A5,_k:sKey}};menu_param_str=Params_JsonToStr(menu_param);ContextMenu=[('선택된 검색어 ( %s ) 삭제'%sKey,'RunPlugin(plugin://plugin.video.kinolightsm/?params=%s)'%menu_param_str)];infoLabels={_Q:'개별삭제는 팝업메뉴 사용'};self.KFuncObj.Add_Dir(sKey,subTitle='',img=_F,infoLabels=infoLabels,isType=_H,ContextMenu=ContextMenu,params=params)
		infoLabels={_Q:'검색목록 전체를 삭제합니다.'};title='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **';params={_B:_A6,_D:{_A3:_A4,_k:_N}};icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_V),_W,'delete.png');self.KFuncObj.Add_Dir(title,subTitle='',img=icon_img,infoLabels=infoLabels,isType=_H,ContextMenu=_F,params=params);xbmcplugin.endOfDirectory(self.ADDON_HANDLE,cacheToDisc=False)
	def kino_main(self):
		if not os.path.isdir(xbmcvfs.translatePath(__profile__)):os.mkdir(xbmcvfs.translatePath(__profile__))
		mode=_F;paramJson={};paramText=self.MAIN_PARAMS.get('params')
		if paramText:paramJson=Params_StrToJson(paramText);mode=paramJson.get(_B);argsValue=paramJson.get(_D)
		if mode is _F:self.dp_Main_List()
		elif mode==_A7:self.dp_Ranking_Group(argsValue)
		elif mode==_K:self.dp_Content_Ranking(argsValue)
		elif mode==_g:self.dp_Content_View(argsValue)
		elif mode==_A1:self.dp_Filmography_List(argsValue)
		elif mode==_Y:self.dp_Local_SearchList(argsValue)
		elif mode==_A6:self.dp_History_Remove(argsValue)
		elif mode==_A8:self.dp_Local_SearchHist(argsValue)
		else:_F