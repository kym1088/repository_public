Query_Ranking_List_3 = '''
query QueryRanking($rankingType: ContentRankingType!, $ageGroup: AgeGroup, $gender: Gender, $limit: Int = 100) {
  contentRankings(
    rankingType: $rankingType
    ageGroup: $ageGroup
    gender: $gender
    limit: $limit
  ) {
    content {
      id
      titleKr
      genres
      contentTypes
      openYear
      posterImage {
        pathUrl
      }
      indexRatingScore
      indexRatingType
      isInTheaters
      vodOfferItems {
        providerId
        isActive
      }
      mediaType
    }
    delta
    isNew
  }
}
'''

Query_Ranking_List_2 = '''
fragment FragmentMovieCardInfo on MovieOutput {
  id
  isInTheaters
  mediaType
  posterImage {
    pathUrl
  }
  titleEn
  titleKr
  indexRatingType
  indexRatingScore
  certifiedAt
  isUninterest
}

fragment FragmentMovieCardMyStatus on MovieOutput {
  isUserInterest(userId: $userId)
  isUserWatched(userId: $userId)
  userIndexRating(userId: $userId) {
    index
  }
}

query QueryExploreContents($genres: [Int!], $imdbScoreRange: FloatRangeInput, $includeEtcNations: Boolean, $indexRatingRange: IntRangeInput, $isSubscription: Boolean, $mediaTypes: [MediaType!], $nations: [Int!], $priceRange: IntRangeInput, $openYearRange: IntRangeInput, $providerIds: [Int!], $ratingTypes: [RatingType!], $rottenScoreRange: IntRangeInput, $runningTimeRange: IntRangeInput, $starRatingRange: FloatRangeInput, $excludeWatched: Boolean, $isCertified: Boolean, $limit: Int = 40, $offset: Int = 0, $orderBy: ExploreMoviesOrderType!, $orderOption: OrderOptionType!, $userId: Int!, $withUser: Boolean = false, $withAdMovie: Boolean = false, $adMovieId: Int = 0) {
  exploreMovies: exploreContents(
    genres: $genres
    imdbScoreRange: $imdbScoreRange
    includeEtcNations: $includeEtcNations
    indexRatingRange: $indexRatingRange
    isSubscription: $isSubscription
    mediaTypes: $mediaTypes
    nations: $nations
    priceRange: $priceRange
    openYearRange: $openYearRange
    providerIds: $providerIds
    ratingTypes: $ratingTypes
    rottenScoreRange: $rottenScoreRange
    runningTimeRange: $runningTimeRange
    starRatingRange: $starRatingRange
    excludeWatched: $excludeWatched
    limit: $limit
    offset: $offset
    orderBy: $orderBy
    orderOption: $orderOption
    isCertified: $isCertified
  ) {
    ...FragmentMovieCardInfo
    ...FragmentMovieCardMyStatus @include(if: $withUser)
  }
  adMovie: movie(movieId: $adMovieId) @include(if: $withAdMovie) {
    ...FragmentMovieCardInfo
    ...FragmentMovieCardMyStatus @include(if: $withUser)
  }
}
'''


Query_Ranking_List_1 = '''
query QueryRankings($rankingType: PersonRankingType = MONTHLY, $limit: Int! = 20, $searchAfter: [String!], $target: String) {
  contentDailyRankings {
    providers {
      name
      rank {
        title {
          id
          titleKr
          mediaType
          posterImage {
            path
          }
        }
        delta
        isNew
      }
    }
  }
  personRanking(
    rankingType: $rankingType
    limit: $limit
    searchAfter: $searchAfter
    target: $target
  ) {
    id
    nameKr
    profileImage {
      path
    }
    rank(rankingType: $rankingType, target: $target)
  }
}
'''


Query_Content_View = '''
fragment FragmentMovieCardMyStatus on MovieOutput {
  isUserInterest(userId: $userId)
  isUserWatched(userId: $userId)
  userIndexRating(userId: $userId) {
    index
  }
}

fragment FragmentMovieDetailField on MovieOutput {
  id
  titleKr
  titleEn
  titleOri
  productionYear
  rating
  showTime
  synopsis
  openYear
  mediaType
  imdbScore
  rottenTomatoesScore
  posterImage {
    pathUrl
  }
  genres
  contentTypes
  nations {
    name
  }
  releases {
    id
    releaseDate
    nation {
      name
    }
  }
  stillCutImage {
    pathUrl
  }
  indexRatingCount
  indexRatingType
  indexRatingScore
  starRatingScore
  vodOfferItems {
    id
    providerId
    title
    retailPrice
    monetizationType
    url
    openDate
    expireDate
    properties
  }
  certifiedAt
  contentTheaters {
    id
    theater
    link
    isActive
    releaseDate
  }
  ...FragmentMovieCardMyStatus @include(if: $withUser)
  isUninterest
  isUserWatching(userId: $userId) @include(if: $withUser)
  userStarRating(userId: $userId) @include(if: $withUser) {
    star
  }
  userReview(userId: $userId) @include(if: $withUser) {
    id
    movieId
    userId
    reviewTitle
    review
    reviewLink
    isPrivate
    isPreview
    hasSpoiler
    watchedAt {
      watchedAt
    }
  }
  userWatched(userId: $userId) @include(if: $withUser) {
    createdAt
    watchedAt
  }
  isMyBestContent @include(if: $withUser)
}

fragment FragmentInventory on BannerOutput {
  id
  inventory
  inventoryImage {
    pathUrl
  }
  link
  title
}

fragment FragmentTrailerVideo on BannerOutput {
  id
  title
  link
  inventory
  inventoryImage {
    pathUrl
  }
  inventoryVideo {
    pathUrl
  }
  inventoryVideoThumbnailUrl
}

query QueryContentDefault($contentId: Int!, $inventoryType: InventoryType! = TITLE_MIDDLE, $videoInventoryType: InventoryType! = TRAILER_VIDEO, $userId: Int!, $withUser: Boolean!) {
  movie: content(movieId: $contentId) {
    ...FragmentMovieDetailField
    kinobelUser {
      id
      name
    }
    upcomingDate
    episodeCount
    contentTags {
      category
      name
    }
    kmrb {
      ratingReason
      mainHarmReason
      subjectRating
      drugRating
      horrorRating
      sexualRating
      violenceRating
      dialogueRating
      horrorRating
      imitationRating
      rating
    }
  }
  titleMiddleInventories: inventories(inventoryType: $inventoryType) {
    ...FragmentInventory
  }
  trailerVideoInventories: inventories(inventoryType: $videoInventoryType) {
    ...FragmentTrailerVideo
  }
}
'''



Query_Content_Person = '''

query QueryContentInfo($contentId: Int!, $withActor: Boolean!, $crewTypesByActors: [CrewType!] = [ACTOR_MAIN], $crewOffsetByActors: Int = 0, $crewLimitByActors: Int, $withDirector: Boolean!, $crewTypesByDirector: [CrewType!] = [DIRECTOR], $crewOffsetByDirector: Int = 0, $crewLimitByDirector: Int, $withScenario: Boolean!, $crewTypesByScenario: [CrewType!] = [SCENARIO], $crewOffsetByScenario: Int = 0, $crewLimitByScenario: Int ) {
  actors: contentCrewsByTypes(
    movieId: $contentId
    crewTypes: $crewTypesByActors
    offset: $crewOffsetByActors
    limit: $crewLimitByActors
  ) @include(if: $withActor) {
    id
    sequence
    role
    type
    person {
      personId: id
      nameKr
      profileImage {
        pathUrl
      }
    }
  }
  directors: contentCrewsByTypes(
    movieId: $contentId
    crewTypes: $crewTypesByDirector
    offset: $crewOffsetByDirector
    limit: $crewLimitByDirector
  ) @include(if: $withDirector) {
    id
    sequence
    role
    type
    person {
      personId: id
      nameKr
      profileImage {
        pathUrl
      }
    }
  }
  scenarios: contentCrewsByTypes(
    movieId: $contentId
    crewTypes: $crewTypesByScenario
    offset: $crewOffsetByScenario
    limit: $crewLimitByScenario
  ) @include(if: $withScenario) {
    id
    sequence
    role
    type
    person {
      personId: id
      nameKr
      profileImage {
        pathUrl
      }
    }
  }
}
'''


Query_Filmography_List = '''
fragment FragmentMovieCardMyStatus on MovieOutput {
  isUserInterest(userId: $userId)
  isUserWatched(userId: $userId)
  userIndexRating(userId: $userId) {
    index
  }
}

fragment FragmentMovieOutputInPerson on MovieOutput {
  id
  mediaType
  contentTypes
  posterImage {
    pathUrl
  }
  titleEn
  titleKr
  indexRatingType
  indexRatingScore
  certifiedAt
  isUninterest
  ...FragmentMovieCardMyStatus @include(if: $withUser)
}

query QueryLoadPerson($crewTypes: [CrewType!], $limit: Int, $offset: Int, $orderBy: FilmographyMoviesOrderType!, $orderOption: OrderOptionType!, $personId: Int!, $userId: Int = 0, $withUser: Boolean!, $withAllCount: Boolean!) {
  filmography: filmographyContents(
    crewTypes: $crewTypes
    limit: $limit
    offset: $offset
    orderBy: $orderBy
    orderOption: $orderOption
    personId: $personId
  ) {
    ...FragmentMovieOutputInPerson
  }
  filmographyCount: filmographyContentCount(
    personId: $personId
    crewTypes: $crewTypes
  )
  allFilmographyCount: filmographyContentCount(personId: $personId) @include(if: $withAllCount)
  popcorn @include(if: $withUser)
}
'''


Query_Search_Kerword = '''
fragment FragmentMovieCardInfo on MovieOutput {
  id
  isInTheaters
  contentTypes
  posterImage {
    pathUrl
  }
  titleEn
  titleKr
  indexRatingType
  indexRatingScore
  certifiedAt
  isUninterest
}

fragment FragmentMovieCardMyStatus on MovieOutput {
  isUserInterest(userId: $userId)
  isUserWatched(userId: $userId)
  userIndexRating(userId: $userId) {
    index
  }
}

query QuerySearchCountAndContents($limit: Int! = 20, $keyword: String!, $userId: Int!, $withUser: Boolean = false) {
  personsByKeyword(limit: 1, keyword: $keyword) {
    totalCount
  }
  usersCount: userCount(keyword: $keyword)
  collectionCount: contentCollectionCount(orderBy: UPDATED_AT, keyword: $keyword)
  contentsByKeyword(limit: $limit, keyword: $keyword) {
    items {
      content {
        ...FragmentMovieCardInfo
        ...FragmentMovieCardMyStatus @include(if: $withUser)
        genres
        contentTypes
        openYear
      }
      searchAfter
    }
    totalCount
  }
}
'''




Query_ExpiredContent_Date = '''
query AvailableExpiredContentDate(
  $isSubscription: Boolean
  $excludeWatched: Boolean
) {
  availableContentsSchedule: availableExpiredContentDate(
    isSubscription: $isSubscription
    excludeWatched: $excludeWatched
  ) {
    date
    providerIds
  }
}  
'''

Query_ExpiredContent_List = '''
fragment FragmentMovieCardInfo on MovieOutput {
  id
  isInTheaters
  mediaType
  posterImage{
    path
  }
  productionYear
  releasedAt
  releases{
    id
    releaseDate
    nation{
      name
    }
  }
  titleEn
  titleKr
  indexRatingType
  indexRatingScore
  certifiedAt
  isUninterest
  genres
}

fragment FragmentMovieCardMyStatus on MovieOutput {
  userIndexRating(userId: $userId) {
    index
  }
}

query QueryExpiredContents(
  $limit: Int!
  $targetDate: String
  $userId: Int!
  $withUser: Boolean = false
) {

scheduleContents4:expiredContents(
  limit: $limit
  providerId: 4
  expireDate: $targetDate
) {
  ...FragmentMovieCardInfo
  ...FragmentMovieCardMyStatus @include(if: $withUser)
}

scheduleContents5:expiredContents(
  limit: $limit
  providerId: 5
  expireDate: $targetDate
) {
  ...FragmentMovieCardInfo
  ...FragmentMovieCardMyStatus @include(if: $withUser)
}


}
'''