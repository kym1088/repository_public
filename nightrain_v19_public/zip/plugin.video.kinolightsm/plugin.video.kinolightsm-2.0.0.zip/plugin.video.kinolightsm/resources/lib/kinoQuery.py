Query_Ranking_List = '''
query QueryRankings($rankingType: PersonRankingType = MONTHLY, $limit: Int! = 20, $searchAfter: [String!], $target: String) {
  contentDailyRankings {
    providers {
      name
      rank {
        title {
          id
          titleKr
          mediaType
          posterImage {
            path
          }
        }
        delta
        isNew
      }
    }
  }
  personRanking(
    rankingType: $rankingType
    limit: $limit
    searchAfter: $searchAfter
    target: $target
  ) {
    id
    nameKr
    profileImage {
      path
    }
    rank(rankingType: $rankingType, target: $target)
  }
}
'''

Query_Content_View = '''
fragment FragmentMovieField on MovieOutput {
  id
  titleKr
  titleEn
  titleOri
  productionYear
  rating
  showTime
  synopsis
  releasedAt
  movieClip
  mediaType
  imdbScore
  rottenTomatoesScore
  posterImage {
    path
  }
  genres
  nations {
    name
  }
  reReleases {
    releasedAt
  }
  releases {
    id
    releaseDate
    nation {
      name
    }
  }
  stillCutImage {
    path
  }
  indexRatingCount
  indexRatingType
  indexRatingScore
  starRatingScore
  vodOfferItems {
    id
    providerId
    title
    retailPrice
    monetizationType
    url
    openDate
    expireDate
    properties
  }
  certifiedAt
  contentTheaters {
    id
    theater
    link
    isActive
  }
  isUninterest
  userStarRating(userId: $userId) @include(if: $withUser) {
    star
  }
}

query QueryContentDefault($contentId: Int!, $userId: Int!, $withUser: Boolean!) {
  movie(movieId: $contentId) {
    ...FragmentMovieField
    kinobelUser {
      id
      name
    }
  }
}
'''

Query_Content_Person = '''
fragment FragmentCrew on ContentCrewMapping {
  id
  sequence
  role
  type
  person {
    personId: id
    nameKr
    profileImage {
      path
    }
  }
}

query QueryContentInfo($contentId: Int!, $crewTypesByActors: [CrewType!] = [ACTOR_MAIN, ACTOR_SUPPORTING, ACTOR_BACKGROUND], $crewOffsetByActors: Int = 0, $crewLimitByActors: Int = 9, $crewTypesByStaffs: [CrewType!] = [DIRECTOR, DIRECTOR_ASSISTANT, PRODUCER, PLANNING, SCENARIO, ADAPTATION, ORIGINAL, CAMERA, LIGHTING, OST, EDITOR, SOUND, PRODUCTION_DESIGN, COSTUME_DESIGN, SPECIAL_EFFECTS, ACTION, DI, DISTRIBUTION, INVESTMENT, MAKEUP_ARTIST, MARKETING, VFX], $crewOffsetByStaffs: Int = 0, $crewLimitByStaffs: Int = 9) {
  actors: contentCrewsByTypes(
    movieId: $contentId
    crewTypes: $crewTypesByActors
    offset: $crewOffsetByActors
    limit: $crewLimitByActors
  ) {
    ...FragmentCrew
  }
  staffs: contentCrewsByTypes(
    movieId: $contentId
    crewTypes: $crewTypesByStaffs
    offset: $crewOffsetByStaffs
    limit: $crewLimitByStaffs
  ) {
    ...FragmentCrew
  }
  articlesByMovieId(movieId: $contentId) {
    id
    title
    headline
    permalink
    category
    summary
    providerIds
    isMain
    mappedMovies {
      titleKr
      isMain
    }
    listImage {
      path
    }
  }
  themesByMovieId(movieId: $contentId) {
    id
    title
    themeImageUrls: imageUrls
    themeImages {
      path
    }
    isThemeSaved
    itemCount
  }
}
'''

Query_Filmography_List = '''
fragment FragmentMovieCardMyStatus on MovieOutput {
  userIndexRating(userId: $userId) {
    index
  }
}

fragment FragmentMovieOutputInPerson on MovieOutput {
  id
  mediaType
  posterImage {
    path
  }
  stillCutImage {
    path
  }
  titleEn
  titleKr
  synopsis
  imdbScore
  indexRatingType
  indexRatingScore
  ...FragmentMovieCardMyStatus @include(if: $withUser)
}

query QueryLoadPerson($crewTypes: [CrewType!], $limit: Int, $offset: Int, $orderBy: FilmographyMoviesOrderType!, $orderOption: OrderOptionType!, $personId: Int!, $userId: Int = 0, $withUser: Boolean!, $rankingType: PersonRankingType = MONTHLY, $withAllCount: Boolean!, $target: String) {
  person(id: $personId) {
    id
    nameKr
    nameEn
    profileImage {
      path
    }
    rank(rankingType: $rankingType, target: $target)
  }
  filmography: filmographyContents(
    crewTypes: $crewTypes
    limit: $limit
    offset: $offset
    orderBy: $orderBy
    orderOption: $orderOption
    personId: $personId
  ) {
    ...FragmentMovieOutputInPerson
  }
  filmographyCount: filmographyContentCount(
    personId: $personId
  )
  allFilmographyCount: filmographyContentCount(personId: $personId) @include(if: $withAllCount)
}
'''


Query_Search_Kerword = '''
fragment FragmentMovieCardInfo on MovieOutput {
  id
  isInTheaters
  mediaType
  posterImage {
    path
  }
  stillCutImage {
    path
  }
  productionYear
  releasedAt
  releases {
    id
    releaseDate
    nation {
      name
    }
  }
  titleEn
  titleKr
  synopsis
  indexRatingType
  indexRatingScore
  imdbScore
}

fragment FragmentMovieCardMyStatus on MovieOutput {
  userIndexRating(userId: $userId) {
    index
  }
}

query QueryContentsByKeyword($limit: Int! = 10, $keyword: String!, $searchAfter: [String!], $userId: Int! = 0, $withUser: Boolean = false) {
  contentsByKeyword(limit: $limit, keyword: $keyword, searchAfter: $searchAfter) {
    items {
      contentId
      content {
        genres
        ...FragmentMovieCardInfo
        ...FragmentMovieCardMyStatus @include(if: $withUser)
      }
      searchAfter
    }
    totalCount
  }
}
'''



Query_ExpiredContent_Date = '''
query AvailableExpiredContentDate(
  $isSubscription: Boolean
  $excludeWatched: Boolean
) {
  availableContentsSchedule: availableExpiredContentDate(
    isSubscription: $isSubscription
    excludeWatched: $excludeWatched
  ) {
    date
    providerIds
  }
}  
'''

Query_ExpiredContent_List = '''
fragment FragmentMovieCardInfo on MovieOutput {
  id
  isInTheaters
  mediaType
  posterImage{
    path
  }
  productionYear
  releasedAt
  releases{
    id
    releaseDate
    nation{
      name
    }
  }
  titleEn
  titleKr
  indexRatingType
  indexRatingScore
  certifiedAt
  isUninterest
  genres
}

fragment FragmentMovieCardMyStatus on MovieOutput {
  userIndexRating(userId: $userId) {
    index
  }
}

query QueryExpiredContents(
  $limit: Int!
  $targetDate: String
  $userId: Int!
  $withUser: Boolean = false
) {

scheduleContents4:expiredContents(
  limit: $limit
  providerId: 4
  expireDate: $targetDate
) {
  ...FragmentMovieCardInfo
  ...FragmentMovieCardMyStatus @include(if: $withUser)
}

scheduleContents5:expiredContents(
  limit: $limit
  providerId: 5
  expireDate: $targetDate
) {
  ...FragmentMovieCardInfo
  ...FragmentMovieCardMyStatus @include(if: $withUser)
}


}
'''