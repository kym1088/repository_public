__author__='NightRain'
import os,sys,xbmcaddon,xbmcvfs,urllib
ADDON_PATH=xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
LIB_PATH=os.path.join(ADDON_PATH,'resources','lib')
sys.path.append(LIB_PATH)
PKG_PATH=os.path.join(ADDON_PATH,'packages')
sys.path.append(PKG_PATH)
from kinoRun import*
def get_params():
	p=urllib.parse.parse_qs(sys.argv[2][1:])
	for i in p.keys():p[i]=p[i][0]
	return p
runObj=KinoRun(sys.argv[0],int(sys.argv[1]),get_params())
runObj.kino_main()