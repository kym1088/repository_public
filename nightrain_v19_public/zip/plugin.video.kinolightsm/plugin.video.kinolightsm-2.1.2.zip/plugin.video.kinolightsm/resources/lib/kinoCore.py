_j='contentId'
_i='cinema'
_h='more_page'
_g='staffs'
_f='indexRatingScore'
_e='4.1.6'
_d='@apollo/client'
_c='version'
_b='clientLibrary'
_a='extensions'
_Z='personId'
_Y='rating'
_X='actors'
_W='fanart'
_V='titleKr'
_U='data'
_T='POST'
_S='query'
_R='operationName'
_Q='/graphql'
_P='mediaType'
_O='personid'
_N='poster'
_M='title'
_L='contentid'
_K='variables'
_J=None
_I=False
_H='role'
_G='posterImage'
_F='pathUrl'
_E='content'
_D=True
_C='link'
_B='thumbnail'
_A='name'
__author__='NightRain'
import re
from baseHttp import*
from baseFunc import*
from kinoQuery import*
PROVIDER_LIST={4:{_A:'netflix',_C:_D},5:{_A:'watcha',_C:_D},8:{_A:'wavve',_C:_D},10:{_A:'tving',_C:_D},14:{_A:'coupang',_C:_D},17:{_A:'disney',_C:_D},18:{_A:'uplus',_C:_I},1:{_A:'serieson',_C:_I},12:{_A:'laftel',_C:_I},9:{_A:'prime',_C:_D},16:{_A:'apple',_C:_I}}
class Kino:
	def __init__(self):self.OS_ANDROID=_I;self.API_DOMAIN='https://gateway.kinolights.com';self.ONE_PAGE=100;self.HttpObj=BaseHttp();self.KN_SEARCHED_FILENAME='';self.KN_SESSION_COOKIES1='';self.KN_SESSION_COOKIES2='';self.KN_SESSION_COOKIES3='';self.KN_SESSION_COOKIES4='';self.KN_SESSION_FULLTEXT1='';self.KN_SESSION_FULLTEXT2='';self.KN_SESSION_FULLTEXT3='';self.KN_SESSION_FULLTEXT4='';self.KN_CONTEXTJSON_FILE1='';self.KN_CONTEXTJSON_FILE2='';self.KN_CONTEXTJSON_FILE3='';self.KN_CONTEXTJSON_FILE4=''
	def Get_ProviderNm(self,providerId):
		if providerId in PROVIDER_LIST:return PROVIDER_LIST[providerId][_A]
		else:return'-'
	def Get_Content_Ranking(self,ottNm,providerId):
		rank_list=[]
		try:
			url=self.API_DOMAIN+_Q;payload={_R:'RankingDetail',_S:Query_Ranking_List,_K:{'rankingLimit':self.ONE_PAGE},_a:{_b:{_A:_d,_c:_e}}}
			if ottNm==_i:payload[_K]['isInTheaters']=_D
			elif providerId!=0:payload[_K]['rankingProviderIds']=[providerId]
			response=self.HttpObj.Call_Request(url,json=payload,headers=_J,method=_T)
			if response.status_code not in[200,201]:return[]
			resJson=response.json();i=0
			for iProv in resJson.get(_U).get('contentRankingsV2'):i+=1;temp_list={'seq':'{:>2}'.format(i),_L:iProv[_E]['id'],_M:iProv[_E][_V],_N:iProv[_E][_G][_F],_P:iProv[_E][_P]};rank_list.append(temp_list)
		except Exception as exception:print(exception);return[]
		return rank_list
	def Catch_Contentid(self,url,providerId):
		A='entity-'
		if providerId not in PROVIDER_LIST:return 0
		if PROVIDER_LIST[providerId][_C]==_I:return 0
		if providerId==8:param_list=URL_GetParamList(url);idStr=param_list.get('programid')or param_list.get('movieid')
		else:
			str_list=url.split('/');idStr=str_list[len(str_list)-1]
			if'#'in idStr:idStr=idStr.split('#')[0]
			if'?'in idStr:idStr=idStr.split('?')[0]
		if providerId==17 and not idStr.startswith(A):idStr=A+idStr
		return idStr
	def Get_Content_Info(self,contentid):
		U='providerId';T='stillCutImage';S='releases';R='movie';Q='country';P='premiered';O='genre';N='cast';M='year';L='plot';K='imdb';J='TV';I='MOVIE';H='provider';G='openDate';F='properties';E='contentTypes';D='영화';C='mediatype';B='ott';A='infoLabels';VIDEO_INFO={_M:'',_L:0,_B:{_N:'',_W:''},A:{C:'',_M:'',L:'',M:'',N:[],O:[],P:'',Q:''},B:[],K:0,_Y:0}
		try:
			url=self.API_DOMAIN+_Q;payload={_R:'QueryContentDefault',_S:Query_Content_View,_K:{_j:int(contentid),'inventoryType':'TITLE_MIDDLE','userId':0,'videoInventoryType':'TRAILER_VIDEO','withUser':_I}};response=self.HttpObj.Call_Request(url,json=payload,headers=_J,method=_T)
			if response.status_code not in[200,201]:return{}
			resJson=response.json();resJson=resJson[_U][R];VIDEO_INFO[_L]=contentid;VIDEO_INFO[_M]=resJson[_V];VIDEO_INFO[K]=resJson['imdbScore']or 0;VIDEO_INFO[_Y]=resJson[_f]or 0;VIDEO_INFO[A][_M]=resJson[_V];VIDEO_INFO[A][C]=R if D in resJson[E]else'tvshow';VIDEO_INFO[A][L]=resJson['synopsis'];VIDEO_INFO[A][M]=resJson['productionYear']
			if resJson[S]:VIDEO_INFO[A][P]=resJson[S][0]['releaseDate']
			VIDEO_INFO[A][O]=resJson['genres']
			for nation in resJson['nations']:VIDEO_INFO[A][Q]=nation[_A];break
			if resJson[_G]:VIDEO_INFO[_B][_N]=resJson[_G][_F];VIDEO_INFO[_B][_W]=resJson[_G][_F]
			if resJson[T]:VIDEO_INFO[_B][_W]=resJson[T][0][_F]
			for i_ott in resJson['vodOfferItems']:
				if i_ott['monetizationType']not in['streaming']:continue
				temp_ott={H:self.Get_ProviderNm(i_ott[U]),_L:self.Catch_Contentid(i_ott['url'],i_ott[U]),C:I if D in resJson[E]else J,F:', '.join(i_ott[F]),G:i_ott.get(G)};VIDEO_INFO[B].append(temp_ott)
			if not VIDEO_INFO[B]:
				for i_ott in resJson['contentTheaters']:temp_ott={H:_i,_L:0,C:I if D in resJson[E]else J,F:'',G:_J};VIDEO_INFO[B].append(temp_ott);break
			if not VIDEO_INFO[B]:temp_ott={H:'none',_L:0,C:I if D in resJson[E]else J,F:'',G:_J};VIDEO_INFO[B].append(temp_ott)
			cast_list=self.Get_Content_Person(contentid);VIDEO_INFO[A][N]=self.make_setCast(cast_list)
		except Exception as exception:print(exception);return{}
		return VIDEO_INFO
	def make_setCast(self,person):
		A='order';cast_list=[];order=0
		for i_cast in person.get(_X):order=1;temp_list={_A:i_cast[_A],_H:i_cast[_H],_B:i_cast[_B],A:order,_O:i_cast[_O]};cast_list.append(temp_list)
		for i_cast in person.get(_g):order=1;temp_list={_A:i_cast[_A],_H:i_cast[_H],_B:i_cast[_B],A:order,_O:i_cast[_O]};cast_list.append(temp_list)
		return cast_list
	def Get_Content_Person(self,contentid):
		C='nameKr';B='profileImage';A='person';PERSON_INFO={_X:[],_g:[]}
		try:
			url=self.API_DOMAIN+_Q;payload={_R:'QueryContentInfo',_S:Query_Content_Person,_K:{_j:int(contentid),'crewLimitByActors':20,'crewLimitByDirector':20,'crewLimitByScenario':20,'crewOffsetByActors':0,'crewOffsetByDirector':0,'crewOffsetByScenario':0,'crewTypesByActors':['ACTOR_MAIN'],'crewTypesByDirector':['DIRECTOR'],'crewTypesByScenario':['SCENARIO'],'withActor':_D,'withDirector':_D,'withScenario':_D}};response=self.HttpObj.Call_Request(url,json=payload,headers=_J,method=_T)
			if response.status_code not in[200,201]:return{}
			resJson=response.json();resJson=resJson[_U]
			for actor in resJson[_X]:temp_list={_O:actor[A][_Z],_A:actor[A][C],_B:actor[A][B][_F]if actor[A][B]else'',_H:actor[_H]or'-'};PERSON_INFO[_X].append(temp_list)
			for director in resJson['directors']:temp_list={_O:director[A][_Z],_A:director[A][C],_B:director[A][B][_F]if director[A][B]else'',_H:director[_H]or'-'};PERSON_INFO[_X].append(temp_list)
			for staff in resJson['scenarios']:temp_list={_O:staff[A][_Z],_A:staff[A][C],_B:staff[A][B][_F]if staff[A][B]else'',_H:staff[_H]or'-'};PERSON_INFO[_g].append(temp_list)
		except Exception as exception:print(exception);return{}
		return PERSON_INFO
	def Get_Filmography_List(self,personid,page_int=1):
		A='filmo_list';FILMO_INFO={A:[],_h:_I}
		try:
			url=self.API_DOMAIN+_Q;payload={_R:'FilmographyContents',_S:Query_Filmography_List,_K:{'crewTypes':[],'limit':self.ONE_PAGE,'offset':(page_int-1)*self.ONE_PAGE,'orderBy':'OPEN_YEAR','orderOption':'DESC',_Z:int(personid)},_a:{_b:{_A:_d,_c:_e}}};response=self.HttpObj.Call_Request(url,json=payload,headers=_J,method=_T)
			if response.status_code not in[200,201]:return{}
			resJson=response.json();resJson=resJson[_U]
			for iFilmo in resJson.get('filmographyContents'):
				thumbnail={_N:'',_W:''}
				if iFilmo[_G]:thumbnail[_N]=iFilmo[_G][_F];thumbnail['thumb']=iFilmo[_G][_F]
				temp_list={_L:iFilmo['id'],_M:iFilmo[_V],_B:thumbnail,_P:iFilmo[_P],_Y:iFilmo[_f]or 0};FILMO_INFO[A].append(temp_list)
		except Exception as exception:print(exception);return{}
		return FILMO_INFO
	def Get_Search_List(self,search_key,page_int=1,searchAfter=_J):
		B='search_list';A='searchAfter';SEARCH_LIST={B:[],_h:_I,A:_J}
		try:
			url=self.API_DOMAIN+_Q;payload={_R:'SearchMoreSeason',_S:Query_Search_Kerword,_K:{'keyword':search_key},_a:{_b:{_A:_d,_c:_e}}}
			if searchAfter:payload[_K][A]=searchAfter
			response=self.HttpObj.Call_Request(url,json=payload,headers=_J,method=_T)
			if response.status_code not in[200,201]:return SEARCH_LIST
			resJson=response.json();resJson=resJson[_U]['contentsByKeyword']
			for iItem in resJson.get('items'):
				thumbnail={_N:'',_W:''}
				if iItem[_E][_G]:thumbnail[_N]=iItem[_E][_G][_F];thumbnail['thumb']=iItem[_E][_G][_F]
				temp_list={_L:iItem[_E]['id'],_M:iItem[_E][_V],_B:thumbnail,_P:iItem[_E][_P],_Y:iItem[_E][_f]or 0};SEARCH_LIST[B].append(temp_list);iAfter=iItem[A]
			if iAfter:SEARCH_LIST[_h]=_D;SEARCH_LIST[A]=iAfter
		except Exception as exception:print(exception);return SEARCH_LIST
		return SEARCH_LIST