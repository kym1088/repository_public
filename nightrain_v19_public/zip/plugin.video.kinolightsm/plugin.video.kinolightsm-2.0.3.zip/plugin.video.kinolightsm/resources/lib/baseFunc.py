# -*- coding: utf-8 -*-
__author__ = "NightRain"

import os
import datetime
import time
import json
import base64
import urllib
import html

##### datetime #####
def Get_Now_Datetime( ):
	return datetime.datetime.now( datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul') )

def Get_TimeStamp( millisecond=False ): # 10 / 13
	if millisecond:
		return int(time.time()*1000) #13
	else:
		return int(time.time()) #10

def Timestamp_To_Str( timestamp ): # 10 digit
	return datetime.datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M:%S')

def Timestamp_To_Timezone( timestamp ): # 10 digit
	return datetime.datetime.fromtimestamp(timestamp, datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))


##### file ######
def JsonFile_Save( filename, dic ):
	if filename == '': return False
	try:
		fp = open(filename, 'w', -1, 'utf-8')
		json.dump(dic, fp, indent=4, ensure_ascii=False)
		fp.close()
	except:
		return False
	#finally:
	return True


def JsonFile_Load( filename ):
	if filename == '': return {}
	try:
		fp = open(filename, 'r', -1, 'utf-8')
		result = json.load(fp)
		fp.close()
	except:
		return {}
	#finally:
	return result


def TextFile_Save( filename, resText ):
	if filename == '': return False
	try:
		fp = open(filename, 'w', -1, 'utf-8')
		fp.write(resText)
		fp.close()
	except:
		return False
	#finally:
	return True


def TextFile_Load( filename ):
	if filename == '': return ''
	try:
		fp = open(filename, 'r', -1, 'utf-8')
		result = fp.read()
		fp.close()
	except:
		result = ''
	#finally:
	return result


def File_Delete( filename ):
	if os.path.isfile(filename): os.remove(filename)


def HistoryFile_Load( filename ):
	if os.path.isfile( filename ):
		historyList_json = JsonFile_Load( filename )
	else:
		historyList_json = []
	return historyList_json


def HistoryFile_Insert( filename, sKey, sValue=None, maxCnt=50 ):
	try:
		# 1단계 history 파일 읽어오기
		if os.path.isfile( filename ):
			historyList_json = JsonFile_Load( filename )
		else:
			historyList_json = []

		# 2단계 중복 제거
		for i in range( len(historyList_json) ):
			i_sKey    = historyList_json[i].get('sKey')
			if sKey == i_sKey: # or i >= maxCnt :
				historyList_json.pop(i)
				break

		# 3단계 처음위치에 추가
		tmp_history = {
					'sKey'   : sKey,
					'sValue' : sValue,
		}
		historyList_json.insert( 0, tmp_history )

		# 4단계 최대갯수 이상 삭제
		totalCnt = len(historyList_json)
		if totalCnt > maxCnt:
			for i in range( totalCnt, maxCnt, -1 ):
				historyList_json.pop(i-1)

		# 5단계 파일 다시 저장
		JsonFile_Save( filename, historyList_json )
	except:
		return False		
	return True


def HistoryFile_Remove( filename, sKey ):
	try:
		# 1단계 history 파일 읽어오기
		if os.path.isfile( filename ):
			historyList_json = JsonFile_Load( filename )
		else:
			historyList_json = []

		# 2단계 제거
		for i in range( len(historyList_json) ):
			i_sKey    = historyList_json[i].get('sKey')
			if sKey == i_sKey: # or i >= maxCnt :
				historyList_json.pop(i)
				break

		# 3단계 파일 다시 저장
		JsonFile_Save( filename, historyList_json )
	except:
		return False		
	return True



##### base64 ######
def Base64_Encode( plaintext ):
	return base64.standard_b64encode( plaintext.encode() ).decode('utf-8')
	#return base64.b64encode( plaintext.encode() ).decode('utf-8')

def Base64_Decode( ciphertext ):
	return base64.standard_b64decode( ciphertext ).decode('utf-8')
	#return base64.b64decode( ciphertext ).decode('utf-8')


##### url ######
def URL_DicToStr( dict ):
	return urllib.parse.urlencode( dict, doseq=True ) # False->list[]

def URL_StrToDic( dictStr ):
	return dict( urllib.parse.parse_qsl( dictStr ) ) # parse_ql : multi

def URL_StrEncode( strText ):
	return urllib.parse.quote_plus( strText )   # strText -> encText

def URL_EncDecode( encText ):
	return urllib.parse.unquote_plus( encText ) # encText -> strText

def URL_GetParamList( fullUrl ):
	urlsplit   = urllib.parse.urlparse(fullUrl)   # scheme, netloc, path, params, query, fragment
	#urlsplit   = urllib.parse.urlsplit(fullUrl)  # scheme, netloc, path,         query, fragment
	return dict( urllib.parse.parse_qsl( urlsplit.query ) )

def JSON_DUMPS( dict ):
	return json.dumps(dict, separators=(',', ':'))

def Html_StrEncode( strText ):
	if strText in ['',None] : return ''
	return html.escape( strText )   # strText -> encText

def Html_EncDecode( encText ):
	if encText in ['',None] : return ''
	return html.unescape( encText ) # encText -> strText



##### parameter Function ######
def Params_StrToJson( paramText ):
	#returnValue = urllib.parse.unquote( paramText ) # {'s': '한글'}
	returnValue = Base64_Decode( paramText )
	returnValue = json.loads( returnValue )
	return returnValue

def Params_JsonToStr( paramJson ):
	returnValue = json.dumps(paramJson, separators=(',', ':'))
	#returnValue = urllib.parse.quote(returnValue)
	returnValue = Base64_Encode(returnValue)
	return returnValue


##### Sub Function ######
def Preview_TitleList( ItemList, titleTagNm, maxCount ):
	previewText = ''

	for i in range( len(ItemList) ):
		if i >= maxCount:
			previewText = previewText + '...'
			break
		previewText = '%s%s\n' %( previewText, ItemList[i].get(titleTagNm) )

	return previewText

