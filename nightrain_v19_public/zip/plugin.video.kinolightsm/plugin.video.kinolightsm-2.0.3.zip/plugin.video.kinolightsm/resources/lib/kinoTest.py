# -*- coding: utf-8 -*-
import sys
import json
import re
import datetime
import time
import os
import urllib


from kinoCore import *
from baseHttp import *
from baseFunc import *

KinoObj = Kino()
#HttpObj   = BaseHttp()
#FuncObj   = BaseFunc()


##### main start #####
userid = '-'
userpw = '-'
userpf = 0


def init():
	global userid
	global userpw
	global userpf
	
	userid = ''
	userpw = ''
	userpf = 0 



	KinoObj.KN_SESSION_COOKIES1      = 'd:\\Naver MYBOX\\sync\\job\\kn_cookies1.json'
	KinoObj.KN_SESSION_COOKIES2      = 'd:\\Naver MYBOX\\sync\\job\\kn_cookies2.json'
	KinoObj.KN_SESSION_COOKIES3      = 'd:\\Naver MYBOX\\sync\\job\\kn_cookies3.json'
	KinoObj.KN_SESSION_COOKIES4      = 'd:\\Naver MYBOX\\sync\\job\\kn_cookies4.json'
	KinoObj.KN_SESSION_FULLTEXT1     = 'd:\\Naver MYBOX\\sync\\job\\kn_fulltext1.html'
	KinoObj.KN_SESSION_FULLTEXT2     = 'd:\\Naver MYBOX\\sync\\job\\kn_fulltext2.html'
	KinoObj.KN_SESSION_FULLTEXT3     = 'd:\\Naver MYBOX\\sync\\job\\kn_fulltext3.html'
	KinoObj.KN_SESSION_FULLTEXT4     = 'd:\\Naver MYBOX\\sync\\job\\kn_fulltext4.html'
	KinoObj.KN_CONTEXTJSON_FILE1     = 'd:\\Naver MYBOX\\sync\\job\\kn_context1.json'
	KinoObj.KN_CONTEXTJSON_FILE2     = 'd:\\Naver MYBOX\\sync\\job\\kn_context2.json'
	KinoObj.KN_CONTEXTJSON_FILE3     = 'd:\\Naver MYBOX\\sync\\job\\kn_context3.json'
	KinoObj.KN_CONTEXTJSON_FILE4     = 'd:\\Naver MYBOX\\sync\\job\\kn_context4.json'



def login(realboolean):
	if realboolean:
		None

	

	else:
		None


	#print( datetime.datetime.fromtimestamp(time.time() ).strftime('%Y-%m') )



def test():
	None

	#ranklist = KinoObj.Get_Content_Ranking('kinolights')
	#ranklist = KinoObj.Get_Person_Ranking()
	#print( ranklist )

	#content_detail = KinoObj.Get_Content_Info(124198) # 삼체
	content_detail = KinoObj.Get_Content_Info(136358) # 
	#content_detail = KinoObj.Get_Content_Info(120009) # 눈물의여왕
	#content_detail = KinoObj.Get_Content_Info(131265) # 멱살 한번 잡힙시다
	#content_detail = KinoObj.Get_Content_Info(125723) # 파묘(영화)
	#content_detail = KinoObj.Get_Content_Info(101661) # 스즈메의문단속 wavve
	#content_detail = KinoObj.Get_Content_Info(122667) # 킬러들의쇼핑몰 disney
	#content_detail = KinoObj.Get_Content_Info(125161) # 나혼자만 레벨업
	#print( content_detail )

	

	#content_person = KinoObj.Get_Content_Person(124198) # 삼체
	#content_person = KinoObj.Get_Content_Person(120009) #  눈물의여왕
	#content_person = KinoObj.Get_Content_Person(129011) #  히어로는 아닙니다만
	#print( content_person )

	#filmo_list = KinoObj.Get_Filmography_List('1728', page_int=1)
	#print(filmo_list)

	#search_list = KinoObj.Get_Search_List( '킬러', page_int=2, searchAfter=['4', '76151'] )
	#print(search_list)



	#KinoObj.Get_Expired_Content_1( )
	#KinoObj.Get_Expired_Content_2( )


##################
init()
login( realboolean=False ) 
test()


##############

##### main end #####


