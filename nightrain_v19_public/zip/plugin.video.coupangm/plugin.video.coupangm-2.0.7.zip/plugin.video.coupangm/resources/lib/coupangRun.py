__author__="NightRain"
TbgNyqMerStCIUQoRcFLfvVjEKHuxk=object
TbgNyqMerStCIUQoRcFLfvVjEKHuxY=None
TbgNyqMerStCIUQoRcFLfvVjEKHuxs=False
TbgNyqMerStCIUQoRcFLfvVjEKHuxh=True
TbgNyqMerStCIUQoRcFLfvVjEKHuxd=type
TbgNyqMerStCIUQoRcFLfvVjEKHuxX=dict
TbgNyqMerStCIUQoRcFLfvVjEKHuxa=int
TbgNyqMerStCIUQoRcFLfvVjEKHuil=open
TbgNyqMerStCIUQoRcFLfvVjEKHuip=Exception
TbgNyqMerStCIUQoRcFLfvVjEKHuiW=str
TbgNyqMerStCIUQoRcFLfvVjEKHuiP=id
TbgNyqMerStCIUQoRcFLfvVjEKHuiz=len
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import inputstreamhelper
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
TbgNyqMerStCIUQoRcFLfvVjEKHulW=[{'title':'홈   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'ALL'},{'title':'TV   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'MOVIES'},{'title':'교육 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'EDUCATION'},{'title':'생중계','mode':'EVENT_GROUPLIST','vType':'LIVE'},{'title':'TV   (테마별)','mode':'THEME_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (테마별)','mode':'THEME_GROUPLIST','vType':'MOVIES'},{'title':'교육 (테마별)','mode':'THEME_GROUPLIST','vType':'EDUCATION'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},{'title':'(쿠팡) 검색','mode':'LOCAL_SEARCH','icon':'search.png'},{'title':'(쿠팡) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
TbgNyqMerStCIUQoRcFLfvVjEKHulP=[{'title':'시리즈 시청내역','mode':'WATCH','stype':'tvshow'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},]
TbgNyqMerStCIUQoRcFLfvVjEKHulz=xbmcvfs.translatePath(os.path.join(__profile__,'coupang_searched.txt'))
from coupangCore import*
class TbgNyqMerStCIUQoRcFLfvVjEKHulp(TbgNyqMerStCIUQoRcFLfvVjEKHuxk):
 def __init__(TbgNyqMerStCIUQoRcFLfvVjEKHulx,TbgNyqMerStCIUQoRcFLfvVjEKHuli,TbgNyqMerStCIUQoRcFLfvVjEKHulD,TbgNyqMerStCIUQoRcFLfvVjEKHulG):
  TbgNyqMerStCIUQoRcFLfvVjEKHulx._addon_url =TbgNyqMerStCIUQoRcFLfvVjEKHuli
  TbgNyqMerStCIUQoRcFLfvVjEKHulx._addon_handle=TbgNyqMerStCIUQoRcFLfvVjEKHulD
  TbgNyqMerStCIUQoRcFLfvVjEKHulx.main_params =TbgNyqMerStCIUQoRcFLfvVjEKHulG
  TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj =NdrmHGwijBuVehkPfbnoJyalYLSgKM() 
  TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.CP_COOKIE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_cookies.json'))
  TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.CP_DEVICE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_device.json'))
 def addon_noti(TbgNyqMerStCIUQoRcFLfvVjEKHulx,sting):
  try:
   TbgNyqMerStCIUQoRcFLfvVjEKHulA=xbmcgui.Dialog()
   TbgNyqMerStCIUQoRcFLfvVjEKHulA.notification(__addonname__,sting)
  except:
   TbgNyqMerStCIUQoRcFLfvVjEKHuxY
 def addon_log(TbgNyqMerStCIUQoRcFLfvVjEKHulx,string):
  try:
   TbgNyqMerStCIUQoRcFLfvVjEKHulO=string.encode('utf-8','ignore')
  except:
   TbgNyqMerStCIUQoRcFLfvVjEKHulO='addonException: addon_log'
  TbgNyqMerStCIUQoRcFLfvVjEKHulm=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,TbgNyqMerStCIUQoRcFLfvVjEKHulO),level=TbgNyqMerStCIUQoRcFLfvVjEKHulm)
 def get_keyboard_input(TbgNyqMerStCIUQoRcFLfvVjEKHulx,TbgNyqMerStCIUQoRcFLfvVjEKHupW):
  TbgNyqMerStCIUQoRcFLfvVjEKHulJ=TbgNyqMerStCIUQoRcFLfvVjEKHuxY
  kb=xbmc.Keyboard()
  kb.setHeading(TbgNyqMerStCIUQoRcFLfvVjEKHupW)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   TbgNyqMerStCIUQoRcFLfvVjEKHulJ=kb.getText()
  return TbgNyqMerStCIUQoRcFLfvVjEKHulJ
 def get_settings_account(TbgNyqMerStCIUQoRcFLfvVjEKHulx):
  TbgNyqMerStCIUQoRcFLfvVjEKHulw=__addon__.getSetting('id')
  TbgNyqMerStCIUQoRcFLfvVjEKHulB=__addon__.getSetting('pw')
  TbgNyqMerStCIUQoRcFLfvVjEKHulk=__addon__.getSetting('profile')
  return(TbgNyqMerStCIUQoRcFLfvVjEKHulw,TbgNyqMerStCIUQoRcFLfvVjEKHulB,TbgNyqMerStCIUQoRcFLfvVjEKHulk)
 def get_settings_exclusion21(TbgNyqMerStCIUQoRcFLfvVjEKHulx):
  TbgNyqMerStCIUQoRcFLfvVjEKHulY =__addon__.getSetting('exclusion21')
  if TbgNyqMerStCIUQoRcFLfvVjEKHulY=='false':
   return TbgNyqMerStCIUQoRcFLfvVjEKHuxs
  else:
   return TbgNyqMerStCIUQoRcFLfvVjEKHuxh
 def get_settings_totalsearch(TbgNyqMerStCIUQoRcFLfvVjEKHulx):
  TbgNyqMerStCIUQoRcFLfvVjEKHuls =TbgNyqMerStCIUQoRcFLfvVjEKHuxh if __addon__.getSetting('local_search')=='true' else TbgNyqMerStCIUQoRcFLfvVjEKHuxs
  TbgNyqMerStCIUQoRcFLfvVjEKHulh=TbgNyqMerStCIUQoRcFLfvVjEKHuxh if __addon__.getSetting('local_history')=='true' else TbgNyqMerStCIUQoRcFLfvVjEKHuxs
  TbgNyqMerStCIUQoRcFLfvVjEKHuld =TbgNyqMerStCIUQoRcFLfvVjEKHuxh if __addon__.getSetting('total_search')=='true' else TbgNyqMerStCIUQoRcFLfvVjEKHuxs
  TbgNyqMerStCIUQoRcFLfvVjEKHulX=TbgNyqMerStCIUQoRcFLfvVjEKHuxh if __addon__.getSetting('total_history')=='true' else TbgNyqMerStCIUQoRcFLfvVjEKHuxs
  TbgNyqMerStCIUQoRcFLfvVjEKHula=TbgNyqMerStCIUQoRcFLfvVjEKHuxh if __addon__.getSetting('menu_bookmark')=='true' else TbgNyqMerStCIUQoRcFLfvVjEKHuxs
  return(TbgNyqMerStCIUQoRcFLfvVjEKHuls,TbgNyqMerStCIUQoRcFLfvVjEKHulh,TbgNyqMerStCIUQoRcFLfvVjEKHuld,TbgNyqMerStCIUQoRcFLfvVjEKHulX,TbgNyqMerStCIUQoRcFLfvVjEKHula)
 def get_settings_makebookmark(TbgNyqMerStCIUQoRcFLfvVjEKHulx):
  return TbgNyqMerStCIUQoRcFLfvVjEKHuxh if __addon__.getSetting('make_bookmark')=='true' else TbgNyqMerStCIUQoRcFLfvVjEKHuxs
 def add_dir(TbgNyqMerStCIUQoRcFLfvVjEKHulx,label,sublabel='',img='',infoLabels=TbgNyqMerStCIUQoRcFLfvVjEKHuxY,isFolder=TbgNyqMerStCIUQoRcFLfvVjEKHuxh,params='',isLink=TbgNyqMerStCIUQoRcFLfvVjEKHuxs,ContextMenu=TbgNyqMerStCIUQoRcFLfvVjEKHuxY):
  TbgNyqMerStCIUQoRcFLfvVjEKHupl='%s?%s'%(TbgNyqMerStCIUQoRcFLfvVjEKHulx._addon_url,urllib.parse.urlencode(params))
  if sublabel:TbgNyqMerStCIUQoRcFLfvVjEKHupW='%s < %s >'%(label,sublabel)
  else: TbgNyqMerStCIUQoRcFLfvVjEKHupW=label
  if not img:img='DefaultFolder.png'
  TbgNyqMerStCIUQoRcFLfvVjEKHupP=xbmcgui.ListItem(TbgNyqMerStCIUQoRcFLfvVjEKHupW)
  if TbgNyqMerStCIUQoRcFLfvVjEKHuxd(img)==TbgNyqMerStCIUQoRcFLfvVjEKHuxX:
   TbgNyqMerStCIUQoRcFLfvVjEKHupP.setArt(img)
  else:
   TbgNyqMerStCIUQoRcFLfvVjEKHupP.setArt({'thumb':img,'poster':img})
  if infoLabels:TbgNyqMerStCIUQoRcFLfvVjEKHupP.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   TbgNyqMerStCIUQoRcFLfvVjEKHupP.setProperty('IsPlayable','true')
  if ContextMenu:TbgNyqMerStCIUQoRcFLfvVjEKHupP.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(TbgNyqMerStCIUQoRcFLfvVjEKHulx._addon_handle,TbgNyqMerStCIUQoRcFLfvVjEKHupl,TbgNyqMerStCIUQoRcFLfvVjEKHupP,isFolder)
 def dp_Main_List(TbgNyqMerStCIUQoRcFLfvVjEKHulx,args):
  (TbgNyqMerStCIUQoRcFLfvVjEKHuls,TbgNyqMerStCIUQoRcFLfvVjEKHulh,TbgNyqMerStCIUQoRcFLfvVjEKHuld,TbgNyqMerStCIUQoRcFLfvVjEKHulX,TbgNyqMerStCIUQoRcFLfvVjEKHula)=TbgNyqMerStCIUQoRcFLfvVjEKHulx.get_settings_totalsearch()
  for TbgNyqMerStCIUQoRcFLfvVjEKHupz in TbgNyqMerStCIUQoRcFLfvVjEKHulW:
   TbgNyqMerStCIUQoRcFLfvVjEKHupW=TbgNyqMerStCIUQoRcFLfvVjEKHupz.get('title')
   TbgNyqMerStCIUQoRcFLfvVjEKHupx=''
   if TbgNyqMerStCIUQoRcFLfvVjEKHupz.get('mode')=='LOCAL_SEARCH' and TbgNyqMerStCIUQoRcFLfvVjEKHuls ==TbgNyqMerStCIUQoRcFLfvVjEKHuxs:continue
   elif TbgNyqMerStCIUQoRcFLfvVjEKHupz.get('mode')=='SEARCH_HISTORY' and TbgNyqMerStCIUQoRcFLfvVjEKHulh==TbgNyqMerStCIUQoRcFLfvVjEKHuxs:continue
   elif TbgNyqMerStCIUQoRcFLfvVjEKHupz.get('mode')=='TOTAL_SEARCH' and TbgNyqMerStCIUQoRcFLfvVjEKHuld ==TbgNyqMerStCIUQoRcFLfvVjEKHuxs:continue
   elif TbgNyqMerStCIUQoRcFLfvVjEKHupz.get('mode')=='TOTAL_HISTORY' and TbgNyqMerStCIUQoRcFLfvVjEKHulX==TbgNyqMerStCIUQoRcFLfvVjEKHuxs:continue
   elif TbgNyqMerStCIUQoRcFLfvVjEKHupz.get('mode')=='MENU_BOOKMARK' and TbgNyqMerStCIUQoRcFLfvVjEKHula==TbgNyqMerStCIUQoRcFLfvVjEKHuxs:continue
   TbgNyqMerStCIUQoRcFLfvVjEKHupi={'mode':TbgNyqMerStCIUQoRcFLfvVjEKHupz.get('mode'),'vType':TbgNyqMerStCIUQoRcFLfvVjEKHupz.get('vType'),'page':'1',}
   if TbgNyqMerStCIUQoRcFLfvVjEKHupz.get('mode')=='LOCAL_SEARCH':TbgNyqMerStCIUQoRcFLfvVjEKHupi['historyyn']='Y' 
   if TbgNyqMerStCIUQoRcFLfvVjEKHupz.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    TbgNyqMerStCIUQoRcFLfvVjEKHupD=TbgNyqMerStCIUQoRcFLfvVjEKHuxs
    TbgNyqMerStCIUQoRcFLfvVjEKHupG =TbgNyqMerStCIUQoRcFLfvVjEKHuxh
   else:
    TbgNyqMerStCIUQoRcFLfvVjEKHupD=TbgNyqMerStCIUQoRcFLfvVjEKHuxh
    TbgNyqMerStCIUQoRcFLfvVjEKHupG =TbgNyqMerStCIUQoRcFLfvVjEKHuxs
   if 'icon' in TbgNyqMerStCIUQoRcFLfvVjEKHupz:TbgNyqMerStCIUQoRcFLfvVjEKHupx=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',TbgNyqMerStCIUQoRcFLfvVjEKHupz.get('icon')) 
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.add_dir(TbgNyqMerStCIUQoRcFLfvVjEKHupW,sublabel='',img=TbgNyqMerStCIUQoRcFLfvVjEKHupx,infoLabels=TbgNyqMerStCIUQoRcFLfvVjEKHuxY,isFolder=TbgNyqMerStCIUQoRcFLfvVjEKHupD,params=TbgNyqMerStCIUQoRcFLfvVjEKHupi,isLink=TbgNyqMerStCIUQoRcFLfvVjEKHupG)
  xbmcplugin.endOfDirectory(TbgNyqMerStCIUQoRcFLfvVjEKHulx._addon_handle)
 def dp_Test(TbgNyqMerStCIUQoRcFLfvVjEKHulx,args):
  TbgNyqMerStCIUQoRcFLfvVjEKHulx.addon_noti('test')
 def CP_logout(TbgNyqMerStCIUQoRcFLfvVjEKHulx):
  TbgNyqMerStCIUQoRcFLfvVjEKHulA=xbmcgui.Dialog()
  TbgNyqMerStCIUQoRcFLfvVjEKHupA=TbgNyqMerStCIUQoRcFLfvVjEKHulA.yesno(__language__(30905).encode('utf8'),__language__(30906).encode('utf8'))
  if TbgNyqMerStCIUQoRcFLfvVjEKHupA==TbgNyqMerStCIUQoRcFLfvVjEKHuxs:return 
  if os.path.isfile(TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.CP_COOKIE_FILENAME):os.remove(TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.CP_COOKIE_FILENAME)
  TbgNyqMerStCIUQoRcFLfvVjEKHulx.addon_noti(__language__(30904).encode('utf-8'))
 def option_check(TbgNyqMerStCIUQoRcFLfvVjEKHulx):
  (TbgNyqMerStCIUQoRcFLfvVjEKHulw,TbgNyqMerStCIUQoRcFLfvVjEKHulB,TbgNyqMerStCIUQoRcFLfvVjEKHulk)=TbgNyqMerStCIUQoRcFLfvVjEKHulx.get_settings_account()
  if TbgNyqMerStCIUQoRcFLfvVjEKHulw=='' or TbgNyqMerStCIUQoRcFLfvVjEKHulB=='':
   TbgNyqMerStCIUQoRcFLfvVjEKHulA=xbmcgui.Dialog()
   TbgNyqMerStCIUQoRcFLfvVjEKHupA=TbgNyqMerStCIUQoRcFLfvVjEKHulA.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if TbgNyqMerStCIUQoRcFLfvVjEKHupA==TbgNyqMerStCIUQoRcFLfvVjEKHuxh:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if TbgNyqMerStCIUQoRcFLfvVjEKHulx.cookiefile_check()==TbgNyqMerStCIUQoRcFLfvVjEKHuxs:
   if TbgNyqMerStCIUQoRcFLfvVjEKHulx.CP_login(TbgNyqMerStCIUQoRcFLfvVjEKHulw,TbgNyqMerStCIUQoRcFLfvVjEKHulB,TbgNyqMerStCIUQoRcFLfvVjEKHulk)==TbgNyqMerStCIUQoRcFLfvVjEKHuxs:
    TbgNyqMerStCIUQoRcFLfvVjEKHulx.addon_noti(__language__(30903).encode('utf8'))
    sys.exit()
  else:
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.Get_CP_profile(TbgNyqMerStCIUQoRcFLfvVjEKHulk,limit_days=TbgNyqMerStCIUQoRcFLfvVjEKHuxa(__addon__.getSetting('cache_ttl')),re_check=TbgNyqMerStCIUQoRcFLfvVjEKHuxh)
 def cookiefile_check(TbgNyqMerStCIUQoRcFLfvVjEKHulx):
  TbgNyqMerStCIUQoRcFLfvVjEKHupm={}
  try: 
   fp=TbgNyqMerStCIUQoRcFLfvVjEKHuil(TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.CP_COOKIE_FILENAME,'r',-1,'utf-8')
   TbgNyqMerStCIUQoRcFLfvVjEKHupm= json.load(fp)
   fp.close()
  except TbgNyqMerStCIUQoRcFLfvVjEKHuip as exception:
   return TbgNyqMerStCIUQoRcFLfvVjEKHuxs
  TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.CP=TbgNyqMerStCIUQoRcFLfvVjEKHupm
  (TbgNyqMerStCIUQoRcFLfvVjEKHulw,TbgNyqMerStCIUQoRcFLfvVjEKHulB,TbgNyqMerStCIUQoRcFLfvVjEKHulk)=TbgNyqMerStCIUQoRcFLfvVjEKHulx.get_settings_account()
  (TbgNyqMerStCIUQoRcFLfvVjEKHupJ,TbgNyqMerStCIUQoRcFLfvVjEKHupw,TbgNyqMerStCIUQoRcFLfvVjEKHupB)=TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.Load_session_acount()
  if TbgNyqMerStCIUQoRcFLfvVjEKHulw!=TbgNyqMerStCIUQoRcFLfvVjEKHupJ or TbgNyqMerStCIUQoRcFLfvVjEKHulB!=TbgNyqMerStCIUQoRcFLfvVjEKHupw or TbgNyqMerStCIUQoRcFLfvVjEKHulk!=TbgNyqMerStCIUQoRcFLfvVjEKHuiW(TbgNyqMerStCIUQoRcFLfvVjEKHupB):
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.Init_CP()
   return TbgNyqMerStCIUQoRcFLfvVjEKHuxs
  TbgNyqMerStCIUQoRcFLfvVjEKHupk =TbgNyqMerStCIUQoRcFLfvVjEKHuxa(TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.Get_Now_Datetime().strftime('%Y%m%d'))
  TbgNyqMerStCIUQoRcFLfvVjEKHupY=TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.CP['SESSION']['limitdate']
  TbgNyqMerStCIUQoRcFLfvVjEKHups =TbgNyqMerStCIUQoRcFLfvVjEKHuxa(re.sub('-','',TbgNyqMerStCIUQoRcFLfvVjEKHupY))
  if TbgNyqMerStCIUQoRcFLfvVjEKHups<TbgNyqMerStCIUQoRcFLfvVjEKHupk:
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.Init_CP()
   return TbgNyqMerStCIUQoRcFLfvVjEKHuxs
  return TbgNyqMerStCIUQoRcFLfvVjEKHuxh
 def CP_login(TbgNyqMerStCIUQoRcFLfvVjEKHulx,TbgNyqMerStCIUQoRcFLfvVjEKHulw,TbgNyqMerStCIUQoRcFLfvVjEKHulB,TbgNyqMerStCIUQoRcFLfvVjEKHulk):
  if TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.Get_CP_Login(TbgNyqMerStCIUQoRcFLfvVjEKHulw,TbgNyqMerStCIUQoRcFLfvVjEKHulB,TbgNyqMerStCIUQoRcFLfvVjEKHulk)==TbgNyqMerStCIUQoRcFLfvVjEKHuxs:return TbgNyqMerStCIUQoRcFLfvVjEKHuxs
  if TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.Get_CP_profile(TbgNyqMerStCIUQoRcFLfvVjEKHulk,limit_days=TbgNyqMerStCIUQoRcFLfvVjEKHuxa(__addon__.getSetting('cache_ttl')),re_check=TbgNyqMerStCIUQoRcFLfvVjEKHuxs)==TbgNyqMerStCIUQoRcFLfvVjEKHuxs:return TbgNyqMerStCIUQoRcFLfvVjEKHuxs
  return TbgNyqMerStCIUQoRcFLfvVjEKHuxh
 def dp_Category_GroupList(TbgNyqMerStCIUQoRcFLfvVjEKHulx,args):
  TbgNyqMerStCIUQoRcFLfvVjEKHuph =args.get('vType') 
  TbgNyqMerStCIUQoRcFLfvVjEKHupd=TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.Get_Category_GroupList(TbgNyqMerStCIUQoRcFLfvVjEKHuph)
  for TbgNyqMerStCIUQoRcFLfvVjEKHupX in TbgNyqMerStCIUQoRcFLfvVjEKHupd:
   TbgNyqMerStCIUQoRcFLfvVjEKHupW =TbgNyqMerStCIUQoRcFLfvVjEKHupX.get('title')
   TbgNyqMerStCIUQoRcFLfvVjEKHupa=TbgNyqMerStCIUQoRcFLfvVjEKHupX.get('pre_title')
   if TbgNyqMerStCIUQoRcFLfvVjEKHulx.get_settings_exclusion21()==TbgNyqMerStCIUQoRcFLfvVjEKHuxh and TbgNyqMerStCIUQoRcFLfvVjEKHupW=='성인':continue
   TbgNyqMerStCIUQoRcFLfvVjEKHuWl={'mediatype':'tvshow','plot':TbgNyqMerStCIUQoRcFLfvVjEKHupa,}
   TbgNyqMerStCIUQoRcFLfvVjEKHupi={'mode':'CATEGORY_LIST','collectionId':TbgNyqMerStCIUQoRcFLfvVjEKHupX.get('collectionId'),'vType':TbgNyqMerStCIUQoRcFLfvVjEKHupX.get('category'),'page':'1',}
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.add_dir(TbgNyqMerStCIUQoRcFLfvVjEKHupW,sublabel='',img='',infoLabels=TbgNyqMerStCIUQoRcFLfvVjEKHuWl,isFolder=TbgNyqMerStCIUQoRcFLfvVjEKHuxh,params=TbgNyqMerStCIUQoRcFLfvVjEKHupi)
  xbmcplugin.endOfDirectory(TbgNyqMerStCIUQoRcFLfvVjEKHulx._addon_handle,cacheToDisc=TbgNyqMerStCIUQoRcFLfvVjEKHuxs)
 def dp_Theme_GroupList(TbgNyqMerStCIUQoRcFLfvVjEKHulx,args):
  TbgNyqMerStCIUQoRcFLfvVjEKHuph =args.get('vType') 
  TbgNyqMerStCIUQoRcFLfvVjEKHupd=TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.Get_Theme_GroupList(TbgNyqMerStCIUQoRcFLfvVjEKHuph)
  for TbgNyqMerStCIUQoRcFLfvVjEKHupX in TbgNyqMerStCIUQoRcFLfvVjEKHupd:
   TbgNyqMerStCIUQoRcFLfvVjEKHupW =TbgNyqMerStCIUQoRcFLfvVjEKHupX.get('title')
   TbgNyqMerStCIUQoRcFLfvVjEKHupa=TbgNyqMerStCIUQoRcFLfvVjEKHupX.get('pre_title')
   TbgNyqMerStCIUQoRcFLfvVjEKHuWl={'mediatype':'tvshow','plot':TbgNyqMerStCIUQoRcFLfvVjEKHupa,}
   TbgNyqMerStCIUQoRcFLfvVjEKHupi={'mode':'CATEGORY_LIST','collectionId':TbgNyqMerStCIUQoRcFLfvVjEKHupX.get('collectionId'),'vType':TbgNyqMerStCIUQoRcFLfvVjEKHupX.get('category'),'page':'1',}
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.add_dir(TbgNyqMerStCIUQoRcFLfvVjEKHupW,sublabel='',img='',infoLabels=TbgNyqMerStCIUQoRcFLfvVjEKHuWl,isFolder=TbgNyqMerStCIUQoRcFLfvVjEKHuxh,params=TbgNyqMerStCIUQoRcFLfvVjEKHupi)
  xbmcplugin.endOfDirectory(TbgNyqMerStCIUQoRcFLfvVjEKHulx._addon_handle,cacheToDisc=TbgNyqMerStCIUQoRcFLfvVjEKHuxs)
 def dp_Event_GroupList(TbgNyqMerStCIUQoRcFLfvVjEKHulx,args):
  TbgNyqMerStCIUQoRcFLfvVjEKHupd=TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.Get_Event_GroupList()
  for TbgNyqMerStCIUQoRcFLfvVjEKHupX in TbgNyqMerStCIUQoRcFLfvVjEKHupd:
   TbgNyqMerStCIUQoRcFLfvVjEKHupW =TbgNyqMerStCIUQoRcFLfvVjEKHupX.get('title')
   TbgNyqMerStCIUQoRcFLfvVjEKHupa=TbgNyqMerStCIUQoRcFLfvVjEKHupX.get('pre_title')
   TbgNyqMerStCIUQoRcFLfvVjEKHuWl={'mediatype':'tvshow','plot':TbgNyqMerStCIUQoRcFLfvVjEKHupa,}
   TbgNyqMerStCIUQoRcFLfvVjEKHupi={'mode':'EVENT_GAMELIST','collectionId':TbgNyqMerStCIUQoRcFLfvVjEKHupX.get('collectionId'),'vType':'LIVE',}
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.add_dir(TbgNyqMerStCIUQoRcFLfvVjEKHupW,sublabel='',img='',infoLabels=TbgNyqMerStCIUQoRcFLfvVjEKHuWl,isFolder=TbgNyqMerStCIUQoRcFLfvVjEKHuxh,params=TbgNyqMerStCIUQoRcFLfvVjEKHupi)
  xbmcplugin.endOfDirectory(TbgNyqMerStCIUQoRcFLfvVjEKHulx._addon_handle,cacheToDisc=TbgNyqMerStCIUQoRcFLfvVjEKHuxs)
 def dp_Event_GameList(TbgNyqMerStCIUQoRcFLfvVjEKHulx,args):
  TbgNyqMerStCIUQoRcFLfvVjEKHuph =args.get('vType') 
  TbgNyqMerStCIUQoRcFLfvVjEKHuWP =args.get('collectionId')
  TbgNyqMerStCIUQoRcFLfvVjEKHupd=TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.Get_Event_GameList(TbgNyqMerStCIUQoRcFLfvVjEKHuWP)
  for TbgNyqMerStCIUQoRcFLfvVjEKHupX in TbgNyqMerStCIUQoRcFLfvVjEKHupd:
   TbgNyqMerStCIUQoRcFLfvVjEKHupW =TbgNyqMerStCIUQoRcFLfvVjEKHupX.get('title')
   TbgNyqMerStCIUQoRcFLfvVjEKHuiP =TbgNyqMerStCIUQoRcFLfvVjEKHupX.get('id')
   TbgNyqMerStCIUQoRcFLfvVjEKHuWz =TbgNyqMerStCIUQoRcFLfvVjEKHupX.get('thumbnail')
   TbgNyqMerStCIUQoRcFLfvVjEKHuWx =TbgNyqMerStCIUQoRcFLfvVjEKHupX.get('asis') 
   TbgNyqMerStCIUQoRcFLfvVjEKHuWi =TbgNyqMerStCIUQoRcFLfvVjEKHupX.get('addInfo')
   TbgNyqMerStCIUQoRcFLfvVjEKHuWD =TbgNyqMerStCIUQoRcFLfvVjEKHupX.get('starttm')
   TbgNyqMerStCIUQoRcFLfvVjEKHuWl={'mediatype':'tvshow','title':TbgNyqMerStCIUQoRcFLfvVjEKHupW,'plot':TbgNyqMerStCIUQoRcFLfvVjEKHuWi,}
   TbgNyqMerStCIUQoRcFLfvVjEKHupi={'mode':'EVENT_LIST','id':TbgNyqMerStCIUQoRcFLfvVjEKHuiP,'asis':TbgNyqMerStCIUQoRcFLfvVjEKHuWx,'title':TbgNyqMerStCIUQoRcFLfvVjEKHupW,}
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.add_dir(TbgNyqMerStCIUQoRcFLfvVjEKHupW,sublabel=TbgNyqMerStCIUQoRcFLfvVjEKHuWD,img=TbgNyqMerStCIUQoRcFLfvVjEKHuWz,infoLabels=TbgNyqMerStCIUQoRcFLfvVjEKHuWl,isFolder=TbgNyqMerStCIUQoRcFLfvVjEKHuxh,params=TbgNyqMerStCIUQoRcFLfvVjEKHupi,ContextMenu=TbgNyqMerStCIUQoRcFLfvVjEKHuxY)
  xbmcplugin.setContent(TbgNyqMerStCIUQoRcFLfvVjEKHulx._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(TbgNyqMerStCIUQoRcFLfvVjEKHulx._addon_handle,cacheToDisc=TbgNyqMerStCIUQoRcFLfvVjEKHuxs)
 def dp_Event_List(TbgNyqMerStCIUQoRcFLfvVjEKHulx,args):
  TbgNyqMerStCIUQoRcFLfvVjEKHuWG=args.get('id')
  TbgNyqMerStCIUQoRcFLfvVjEKHupd=TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.Get_Event_List(TbgNyqMerStCIUQoRcFLfvVjEKHuWG)
  for TbgNyqMerStCIUQoRcFLfvVjEKHupX in TbgNyqMerStCIUQoRcFLfvVjEKHupd:
   TbgNyqMerStCIUQoRcFLfvVjEKHupW =TbgNyqMerStCIUQoRcFLfvVjEKHupX.get('title')
   TbgNyqMerStCIUQoRcFLfvVjEKHuiP =TbgNyqMerStCIUQoRcFLfvVjEKHupX.get('id')
   TbgNyqMerStCIUQoRcFLfvVjEKHuWz =TbgNyqMerStCIUQoRcFLfvVjEKHupX.get('thumbnail')
   TbgNyqMerStCIUQoRcFLfvVjEKHuWx =TbgNyqMerStCIUQoRcFLfvVjEKHupX.get('asis') 
   TbgNyqMerStCIUQoRcFLfvVjEKHuWn =TbgNyqMerStCIUQoRcFLfvVjEKHupX.get('duration')
   TbgNyqMerStCIUQoRcFLfvVjEKHuWD =TbgNyqMerStCIUQoRcFLfvVjEKHupX.get('starttm')
   TbgNyqMerStCIUQoRcFLfvVjEKHuWl={'mediatype':'episode','title':TbgNyqMerStCIUQoRcFLfvVjEKHupW,'plot':TbgNyqMerStCIUQoRcFLfvVjEKHuWx,'duration':TbgNyqMerStCIUQoRcFLfvVjEKHuWn,}
   TbgNyqMerStCIUQoRcFLfvVjEKHupi={'mode':TbgNyqMerStCIUQoRcFLfvVjEKHuWx,'id':TbgNyqMerStCIUQoRcFLfvVjEKHuiP,'asis':TbgNyqMerStCIUQoRcFLfvVjEKHuWx,'title':TbgNyqMerStCIUQoRcFLfvVjEKHupW,}
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.add_dir(TbgNyqMerStCIUQoRcFLfvVjEKHupW,sublabel=TbgNyqMerStCIUQoRcFLfvVjEKHuWD,img=TbgNyqMerStCIUQoRcFLfvVjEKHuWz,infoLabels=TbgNyqMerStCIUQoRcFLfvVjEKHuWl,isFolder=TbgNyqMerStCIUQoRcFLfvVjEKHuxs,params=TbgNyqMerStCIUQoRcFLfvVjEKHupi,ContextMenu=TbgNyqMerStCIUQoRcFLfvVjEKHuxY)
  xbmcplugin.setContent(TbgNyqMerStCIUQoRcFLfvVjEKHulx._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(TbgNyqMerStCIUQoRcFLfvVjEKHulx._addon_handle,cacheToDisc=TbgNyqMerStCIUQoRcFLfvVjEKHuxs)
 def dp_Category_List(TbgNyqMerStCIUQoRcFLfvVjEKHulx,args):
  TbgNyqMerStCIUQoRcFLfvVjEKHuph =args.get('vType') 
  TbgNyqMerStCIUQoRcFLfvVjEKHuWP =args.get('collectionId')
  TbgNyqMerStCIUQoRcFLfvVjEKHuWA =TbgNyqMerStCIUQoRcFLfvVjEKHuxa(args.get('page'))
  TbgNyqMerStCIUQoRcFLfvVjEKHupd,TbgNyqMerStCIUQoRcFLfvVjEKHuWO=TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.Get_Category_List(TbgNyqMerStCIUQoRcFLfvVjEKHuph,TbgNyqMerStCIUQoRcFLfvVjEKHuWP,TbgNyqMerStCIUQoRcFLfvVjEKHuWA)
  for TbgNyqMerStCIUQoRcFLfvVjEKHupX in TbgNyqMerStCIUQoRcFLfvVjEKHupd:
   TbgNyqMerStCIUQoRcFLfvVjEKHupW =TbgNyqMerStCIUQoRcFLfvVjEKHupX.get('title')
   TbgNyqMerStCIUQoRcFLfvVjEKHuiP =TbgNyqMerStCIUQoRcFLfvVjEKHupX.get('id')
   TbgNyqMerStCIUQoRcFLfvVjEKHuWz =TbgNyqMerStCIUQoRcFLfvVjEKHupX.get('thumbnail')
   TbgNyqMerStCIUQoRcFLfvVjEKHuWm =TbgNyqMerStCIUQoRcFLfvVjEKHupX.get('mpaa')
   TbgNyqMerStCIUQoRcFLfvVjEKHuWn =TbgNyqMerStCIUQoRcFLfvVjEKHupX.get('duration')
   TbgNyqMerStCIUQoRcFLfvVjEKHuWx =TbgNyqMerStCIUQoRcFLfvVjEKHupX.get('asis')
   TbgNyqMerStCIUQoRcFLfvVjEKHuWJ =TbgNyqMerStCIUQoRcFLfvVjEKHupX.get('badge')
   TbgNyqMerStCIUQoRcFLfvVjEKHuWw =TbgNyqMerStCIUQoRcFLfvVjEKHupX.get('year')
   TbgNyqMerStCIUQoRcFLfvVjEKHuWB=TbgNyqMerStCIUQoRcFLfvVjEKHupX.get('seasonList')
   TbgNyqMerStCIUQoRcFLfvVjEKHuWk =TbgNyqMerStCIUQoRcFLfvVjEKHupX.get('genreList')
   if TbgNyqMerStCIUQoRcFLfvVjEKHuWx in['TVSHOW','EDUCATION']: 
    TbgNyqMerStCIUQoRcFLfvVjEKHuWY ='SEASON_LIST'
    TbgNyqMerStCIUQoRcFLfvVjEKHuWl={'mediatype':'tvshow','title':TbgNyqMerStCIUQoRcFLfvVjEKHupW,'mpaa':TbgNyqMerStCIUQoRcFLfvVjEKHuWm,'genre':TbgNyqMerStCIUQoRcFLfvVjEKHuWk,'year':TbgNyqMerStCIUQoRcFLfvVjEKHuWw,'plot':'Year : %s\nSeason : %s'%(TbgNyqMerStCIUQoRcFLfvVjEKHuWw,TbgNyqMerStCIUQoRcFLfvVjEKHuWB),}
    TbgNyqMerStCIUQoRcFLfvVjEKHupD =TbgNyqMerStCIUQoRcFLfvVjEKHuxh
   else:
    TbgNyqMerStCIUQoRcFLfvVjEKHuWY ='MOVIE'
    TbgNyqMerStCIUQoRcFLfvVjEKHuWl={'mediatype':'movie','title':TbgNyqMerStCIUQoRcFLfvVjEKHupW,'mpaa':TbgNyqMerStCIUQoRcFLfvVjEKHuWm,'genre':TbgNyqMerStCIUQoRcFLfvVjEKHuWk,'duration':TbgNyqMerStCIUQoRcFLfvVjEKHuWn,'year':TbgNyqMerStCIUQoRcFLfvVjEKHuWw,'plot':'(%s)'%(TbgNyqMerStCIUQoRcFLfvVjEKHuWm),}
    TbgNyqMerStCIUQoRcFLfvVjEKHupD =TbgNyqMerStCIUQoRcFLfvVjEKHuxs
    TbgNyqMerStCIUQoRcFLfvVjEKHupW +=' (%s)'%(TbgNyqMerStCIUQoRcFLfvVjEKHuiW(TbgNyqMerStCIUQoRcFLfvVjEKHuWw))
   TbgNyqMerStCIUQoRcFLfvVjEKHupi={'mode':TbgNyqMerStCIUQoRcFLfvVjEKHuWY,'id':TbgNyqMerStCIUQoRcFLfvVjEKHuiP,'asis':TbgNyqMerStCIUQoRcFLfvVjEKHuWx,'seasonList':TbgNyqMerStCIUQoRcFLfvVjEKHuWB,'title':TbgNyqMerStCIUQoRcFLfvVjEKHupW,'thumbnail':TbgNyqMerStCIUQoRcFLfvVjEKHuWz,'year':TbgNyqMerStCIUQoRcFLfvVjEKHuWw,}
   if TbgNyqMerStCIUQoRcFLfvVjEKHulx.get_settings_makebookmark():
    TbgNyqMerStCIUQoRcFLfvVjEKHuWs={'videoid':TbgNyqMerStCIUQoRcFLfvVjEKHuiP,'vidtype':'movie' if TbgNyqMerStCIUQoRcFLfvVjEKHuph=='MOVIES' else 'tvshow','vtitle':TbgNyqMerStCIUQoRcFLfvVjEKHupW,'vsubtitle':'',}
    TbgNyqMerStCIUQoRcFLfvVjEKHuWh=json.dumps(TbgNyqMerStCIUQoRcFLfvVjEKHuWs)
    TbgNyqMerStCIUQoRcFLfvVjEKHuWh=urllib.parse.quote(TbgNyqMerStCIUQoRcFLfvVjEKHuWh)
    TbgNyqMerStCIUQoRcFLfvVjEKHuWd='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(TbgNyqMerStCIUQoRcFLfvVjEKHuWh)
    TbgNyqMerStCIUQoRcFLfvVjEKHuWX=[('(통합) 찜 영상에 추가',TbgNyqMerStCIUQoRcFLfvVjEKHuWd)]
   else:
    TbgNyqMerStCIUQoRcFLfvVjEKHuWX=TbgNyqMerStCIUQoRcFLfvVjEKHuxY
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.add_dir(TbgNyqMerStCIUQoRcFLfvVjEKHupW,sublabel=TbgNyqMerStCIUQoRcFLfvVjEKHuWJ,img=TbgNyqMerStCIUQoRcFLfvVjEKHuWz,infoLabels=TbgNyqMerStCIUQoRcFLfvVjEKHuWl,isFolder=TbgNyqMerStCIUQoRcFLfvVjEKHupD,params=TbgNyqMerStCIUQoRcFLfvVjEKHupi,ContextMenu=TbgNyqMerStCIUQoRcFLfvVjEKHuWX)
  if TbgNyqMerStCIUQoRcFLfvVjEKHuWO:
   TbgNyqMerStCIUQoRcFLfvVjEKHupi['mode'] ='CATEGORY_LIST' 
   TbgNyqMerStCIUQoRcFLfvVjEKHupi['collectionId']=TbgNyqMerStCIUQoRcFLfvVjEKHuWP 
   TbgNyqMerStCIUQoRcFLfvVjEKHupi['vType'] =TbgNyqMerStCIUQoRcFLfvVjEKHuph 
   TbgNyqMerStCIUQoRcFLfvVjEKHupi['page'] =TbgNyqMerStCIUQoRcFLfvVjEKHuiW(TbgNyqMerStCIUQoRcFLfvVjEKHuWA+1)
   TbgNyqMerStCIUQoRcFLfvVjEKHupW='[B]%s >>[/B]'%'다음 페이지'
   TbgNyqMerStCIUQoRcFLfvVjEKHuWa=TbgNyqMerStCIUQoRcFLfvVjEKHuiW(TbgNyqMerStCIUQoRcFLfvVjEKHuWA+1)
   TbgNyqMerStCIUQoRcFLfvVjEKHupx=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.add_dir(TbgNyqMerStCIUQoRcFLfvVjEKHupW,sublabel=TbgNyqMerStCIUQoRcFLfvVjEKHuWa,img=TbgNyqMerStCIUQoRcFLfvVjEKHupx,infoLabels=TbgNyqMerStCIUQoRcFLfvVjEKHuxY,isFolder=TbgNyqMerStCIUQoRcFLfvVjEKHuxh,params=TbgNyqMerStCIUQoRcFLfvVjEKHupi)
  if TbgNyqMerStCIUQoRcFLfvVjEKHuph=='TVSHOWS':xbmcplugin.setContent(TbgNyqMerStCIUQoRcFLfvVjEKHulx._addon_handle,'tvshows')
  else:xbmcplugin.setContent(TbgNyqMerStCIUQoRcFLfvVjEKHulx._addon_handle,'movies')
  xbmcplugin.endOfDirectory(TbgNyqMerStCIUQoRcFLfvVjEKHulx._addon_handle,cacheToDisc=TbgNyqMerStCIUQoRcFLfvVjEKHuxs)
 def dp_Season_List(TbgNyqMerStCIUQoRcFLfvVjEKHulx,args):
  TbgNyqMerStCIUQoRcFLfvVjEKHuPl =args.get('title')
  TbgNyqMerStCIUQoRcFLfvVjEKHuPp =args.get('id')
  TbgNyqMerStCIUQoRcFLfvVjEKHuWx =args.get('asis')
  TbgNyqMerStCIUQoRcFLfvVjEKHuWB =args.get('seasonList')
  TbgNyqMerStCIUQoRcFLfvVjEKHuWz =args.get('thumbnail')
  TbgNyqMerStCIUQoRcFLfvVjEKHuWw =args.get('year')
  if TbgNyqMerStCIUQoRcFLfvVjEKHuWB in['',TbgNyqMerStCIUQoRcFLfvVjEKHuxY]:
   TbgNyqMerStCIUQoRcFLfvVjEKHuWB=TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.Get_vInfo(TbgNyqMerStCIUQoRcFLfvVjEKHuPp).get('seasonList')
  if TbgNyqMerStCIUQoRcFLfvVjEKHuiz(TbgNyqMerStCIUQoRcFLfvVjEKHuWB.split(','))>1:
   for TbgNyqMerStCIUQoRcFLfvVjEKHuPW in TbgNyqMerStCIUQoRcFLfvVjEKHuWB.split(','):
    TbgNyqMerStCIUQoRcFLfvVjEKHupW='시즌 '+TbgNyqMerStCIUQoRcFLfvVjEKHuPW
    TbgNyqMerStCIUQoRcFLfvVjEKHuWl={'mediatype':'tvshow','plot':'%s (%s)'%(TbgNyqMerStCIUQoRcFLfvVjEKHuPl,TbgNyqMerStCIUQoRcFLfvVjEKHuWw),}
    TbgNyqMerStCIUQoRcFLfvVjEKHupi={'mode':'EPISODE_LIST','programid':TbgNyqMerStCIUQoRcFLfvVjEKHuPp,'programnm':TbgNyqMerStCIUQoRcFLfvVjEKHuPl,'season':TbgNyqMerStCIUQoRcFLfvVjEKHuPW,'asis':TbgNyqMerStCIUQoRcFLfvVjEKHuWx,'programimg':TbgNyqMerStCIUQoRcFLfvVjEKHuWz,}
    TbgNyqMerStCIUQoRcFLfvVjEKHuPz=TbgNyqMerStCIUQoRcFLfvVjEKHuWz.replace('\'','\"')
    TbgNyqMerStCIUQoRcFLfvVjEKHuPz=json.loads(TbgNyqMerStCIUQoRcFLfvVjEKHuPz)
    TbgNyqMerStCIUQoRcFLfvVjEKHulx.add_dir(TbgNyqMerStCIUQoRcFLfvVjEKHupW,sublabel='',img=TbgNyqMerStCIUQoRcFLfvVjEKHuPz,infoLabels=TbgNyqMerStCIUQoRcFLfvVjEKHuWl,isFolder=TbgNyqMerStCIUQoRcFLfvVjEKHuxh,params=TbgNyqMerStCIUQoRcFLfvVjEKHupi)
   xbmcplugin.setContent(TbgNyqMerStCIUQoRcFLfvVjEKHulx._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(TbgNyqMerStCIUQoRcFLfvVjEKHulx._addon_handle,cacheToDisc=TbgNyqMerStCIUQoRcFLfvVjEKHuxs)
  else:
   TbgNyqMerStCIUQoRcFLfvVjEKHuPx={'programid':TbgNyqMerStCIUQoRcFLfvVjEKHuPp,'programnm':TbgNyqMerStCIUQoRcFLfvVjEKHuPl,'season':TbgNyqMerStCIUQoRcFLfvVjEKHuWB,'programimg':TbgNyqMerStCIUQoRcFLfvVjEKHuWz,}
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.dp_Episode_List(TbgNyqMerStCIUQoRcFLfvVjEKHuPx)
 def dp_Episode_List(TbgNyqMerStCIUQoRcFLfvVjEKHulx,args):
  TbgNyqMerStCIUQoRcFLfvVjEKHuPp =args.get('programid')
  TbgNyqMerStCIUQoRcFLfvVjEKHuPl =args.get('programnm')
  TbgNyqMerStCIUQoRcFLfvVjEKHuPi =args.get('season')
  TbgNyqMerStCIUQoRcFLfvVjEKHuPD =args.get('programimg')
  TbgNyqMerStCIUQoRcFLfvVjEKHuPG=TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.Get_Episode_List(TbgNyqMerStCIUQoRcFLfvVjEKHuPp,TbgNyqMerStCIUQoRcFLfvVjEKHuPi)
  for TbgNyqMerStCIUQoRcFLfvVjEKHuPW in TbgNyqMerStCIUQoRcFLfvVjEKHuPG:
   TbgNyqMerStCIUQoRcFLfvVjEKHuPn =TbgNyqMerStCIUQoRcFLfvVjEKHuPW.get('title')
   TbgNyqMerStCIUQoRcFLfvVjEKHuPA =TbgNyqMerStCIUQoRcFLfvVjEKHuPW.get('id')
   TbgNyqMerStCIUQoRcFLfvVjEKHuWx =TbgNyqMerStCIUQoRcFLfvVjEKHuPW.get('asis')
   TbgNyqMerStCIUQoRcFLfvVjEKHuWz =TbgNyqMerStCIUQoRcFLfvVjEKHuPW.get('thumbnail')
   TbgNyqMerStCIUQoRcFLfvVjEKHuWm =TbgNyqMerStCIUQoRcFLfvVjEKHuPW.get('mpaa')
   TbgNyqMerStCIUQoRcFLfvVjEKHuWn =TbgNyqMerStCIUQoRcFLfvVjEKHuPW.get('duration')
   TbgNyqMerStCIUQoRcFLfvVjEKHuWw =TbgNyqMerStCIUQoRcFLfvVjEKHuPW.get('year')
   TbgNyqMerStCIUQoRcFLfvVjEKHuPO =TbgNyqMerStCIUQoRcFLfvVjEKHuPW.get('episode')
   TbgNyqMerStCIUQoRcFLfvVjEKHuWk =TbgNyqMerStCIUQoRcFLfvVjEKHuPW.get('genreList')
   TbgNyqMerStCIUQoRcFLfvVjEKHuPm =TbgNyqMerStCIUQoRcFLfvVjEKHuPW.get('desc')
   TbgNyqMerStCIUQoRcFLfvVjEKHuPJ ='%sx%s'%(TbgNyqMerStCIUQoRcFLfvVjEKHuPi,TbgNyqMerStCIUQoRcFLfvVjEKHuPO)
   TbgNyqMerStCIUQoRcFLfvVjEKHupW ='%s. %s'%(TbgNyqMerStCIUQoRcFLfvVjEKHuPJ,TbgNyqMerStCIUQoRcFLfvVjEKHuPn)
   TbgNyqMerStCIUQoRcFLfvVjEKHuWl={'mediatype':'episode','mpaa':TbgNyqMerStCIUQoRcFLfvVjEKHuWm,'genre':TbgNyqMerStCIUQoRcFLfvVjEKHuWk,'duration':TbgNyqMerStCIUQoRcFLfvVjEKHuWn,'year':TbgNyqMerStCIUQoRcFLfvVjEKHuWw,'plot':'%s (%s)\n\n%s'%(TbgNyqMerStCIUQoRcFLfvVjEKHuPl,TbgNyqMerStCIUQoRcFLfvVjEKHuPJ,TbgNyqMerStCIUQoRcFLfvVjEKHuPm),}
   TbgNyqMerStCIUQoRcFLfvVjEKHupi={'mode':'VOD','programid':TbgNyqMerStCIUQoRcFLfvVjEKHuPp,'programnm':TbgNyqMerStCIUQoRcFLfvVjEKHuPl,'title':TbgNyqMerStCIUQoRcFLfvVjEKHupW,'season':TbgNyqMerStCIUQoRcFLfvVjEKHuPi,'id':TbgNyqMerStCIUQoRcFLfvVjEKHuPA,'asis':TbgNyqMerStCIUQoRcFLfvVjEKHuWx,'thumbnail':TbgNyqMerStCIUQoRcFLfvVjEKHuWz,'programimg':TbgNyqMerStCIUQoRcFLfvVjEKHuPD,}
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.add_dir(TbgNyqMerStCIUQoRcFLfvVjEKHupW,sublabel='',img=TbgNyqMerStCIUQoRcFLfvVjEKHuWz,infoLabels=TbgNyqMerStCIUQoRcFLfvVjEKHuWl,isFolder=TbgNyqMerStCIUQoRcFLfvVjEKHuxs,params=TbgNyqMerStCIUQoRcFLfvVjEKHupi)
  xbmcplugin.setContent(TbgNyqMerStCIUQoRcFLfvVjEKHulx._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(TbgNyqMerStCIUQoRcFLfvVjEKHulx._addon_handle,cacheToDisc=TbgNyqMerStCIUQoRcFLfvVjEKHuxs)
 def play_VIDEO(TbgNyqMerStCIUQoRcFLfvVjEKHulx,args):
  TbgNyqMerStCIUQoRcFLfvVjEKHuPw =args.get('id')
  TbgNyqMerStCIUQoRcFLfvVjEKHuWx =args.get('asis')
  if TbgNyqMerStCIUQoRcFLfvVjEKHuWx in['HIGHLIGHT']:
   TbgNyqMerStCIUQoRcFLfvVjEKHuPB,TbgNyqMerStCIUQoRcFLfvVjEKHuPk=TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.GetEventURL(TbgNyqMerStCIUQoRcFLfvVjEKHuPw,TbgNyqMerStCIUQoRcFLfvVjEKHuWx)
  elif TbgNyqMerStCIUQoRcFLfvVjEKHuWx in['LIVE']:
   TbgNyqMerStCIUQoRcFLfvVjEKHuPB,TbgNyqMerStCIUQoRcFLfvVjEKHuPk=TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.GetEventURL_Live(TbgNyqMerStCIUQoRcFLfvVjEKHuPw,TbgNyqMerStCIUQoRcFLfvVjEKHuWx)
  else:
   TbgNyqMerStCIUQoRcFLfvVjEKHuPB,TbgNyqMerStCIUQoRcFLfvVjEKHuPk=TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.GetBroadURL(TbgNyqMerStCIUQoRcFLfvVjEKHuPw)
  TbgNyqMerStCIUQoRcFLfvVjEKHulx.addon_log('asis, url : %s - %s - %s'%(TbgNyqMerStCIUQoRcFLfvVjEKHuWx,TbgNyqMerStCIUQoRcFLfvVjEKHuPw,TbgNyqMerStCIUQoRcFLfvVjEKHuPB))
  if TbgNyqMerStCIUQoRcFLfvVjEKHuPB=='':
   if TbgNyqMerStCIUQoRcFLfvVjEKHuPk=='':
    TbgNyqMerStCIUQoRcFLfvVjEKHulx.addon_noti(__language__(30907).encode('utf8'))
   else:
    TbgNyqMerStCIUQoRcFLfvVjEKHulx.addon_noti(TbgNyqMerStCIUQoRcFLfvVjEKHuPk)
   return
  TbgNyqMerStCIUQoRcFLfvVjEKHuPY='PCID=%s;token=%s;member_srl=%s;NEXT_LOCALE=%s;bm_mi=%s;ak_bmsc=%s;bm_sv=%s'%(TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.CP['SESSION']['PCID'],TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.CP['SESSION']['token'],TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.CP['SESSION']['member_srl'],TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.CP['SESSION']['NEXT_LOCALE'],TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.CP['SESSION']['bm_mi'],TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.CP['SESSION']['ak_bmsc'],TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.CP['SESSION']['bm_sv'],)
  TbgNyqMerStCIUQoRcFLfvVjEKHuPs='%s|Cookie=%s'%(TbgNyqMerStCIUQoRcFLfvVjEKHuPB,TbgNyqMerStCIUQoRcFLfvVjEKHuPY)
  TbgNyqMerStCIUQoRcFLfvVjEKHuPh=xbmcgui.ListItem(path=TbgNyqMerStCIUQoRcFLfvVjEKHuPs)
  TbgNyqMerStCIUQoRcFLfvVjEKHuPd=TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.Get_Url_PostFix(TbgNyqMerStCIUQoRcFLfvVjEKHuPB) 
  TbgNyqMerStCIUQoRcFLfvVjEKHulx.addon_log('post_fix : '+TbgNyqMerStCIUQoRcFLfvVjEKHuPd)
  if TbgNyqMerStCIUQoRcFLfvVjEKHuPk:
   TbgNyqMerStCIUQoRcFLfvVjEKHuPX =TbgNyqMerStCIUQoRcFLfvVjEKHuPk 
   if TbgNyqMerStCIUQoRcFLfvVjEKHuPd=='m3u8':
    TbgNyqMerStCIUQoRcFLfvVjEKHuPa ='hls' 
   else:
    TbgNyqMerStCIUQoRcFLfvVjEKHuPa ='mpd' 
   TbgNyqMerStCIUQoRcFLfvVjEKHuzl ='com.widevine.alpha'
   TbgNyqMerStCIUQoRcFLfvVjEKHuzp =inputstreamhelper.Helper(TbgNyqMerStCIUQoRcFLfvVjEKHuPa,drm='widevine')
   if TbgNyqMerStCIUQoRcFLfvVjEKHuzp.check_inputstream():
    TbgNyqMerStCIUQoRcFLfvVjEKHuzW,TbgNyqMerStCIUQoRcFLfvVjEKHuzP,TbgNyqMerStCIUQoRcFLfvVjEKHuzx=TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.Make_authHeader()
    TbgNyqMerStCIUQoRcFLfvVjEKHuzi={'traceparent':TbgNyqMerStCIUQoRcFLfvVjEKHuzW,'tracestate':TbgNyqMerStCIUQoRcFLfvVjEKHuzP,'newrelic':TbgNyqMerStCIUQoRcFLfvVjEKHuzx,'content-type':'application/octet-stream','User-Agent':TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.USER_AGENT,'Cookie':TbgNyqMerStCIUQoRcFLfvVjEKHuPY,}
    TbgNyqMerStCIUQoRcFLfvVjEKHuzD=TbgNyqMerStCIUQoRcFLfvVjEKHuPX+'|'+urllib.parse.urlencode(TbgNyqMerStCIUQoRcFLfvVjEKHuzi)+'|R{SSM}|'
    TbgNyqMerStCIUQoRcFLfvVjEKHuPh.setProperty('inputstream',TbgNyqMerStCIUQoRcFLfvVjEKHuzp.inputstream_addon)
    TbgNyqMerStCIUQoRcFLfvVjEKHuPh.setProperty('inputstream.adaptive.manifest_type',TbgNyqMerStCIUQoRcFLfvVjEKHuPa)
    TbgNyqMerStCIUQoRcFLfvVjEKHuPh.setProperty('inputstream.adaptive.license_type',TbgNyqMerStCIUQoRcFLfvVjEKHuzl)
    TbgNyqMerStCIUQoRcFLfvVjEKHuPh.setProperty('inputstream.adaptive.license_key',TbgNyqMerStCIUQoRcFLfvVjEKHuzD)
    TbgNyqMerStCIUQoRcFLfvVjEKHuPh.setProperty('inputstream.adaptive.stream_headers','User-Agent=%s&Cookie=%s'%(TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.USER_AGENT,TbgNyqMerStCIUQoRcFLfvVjEKHuPY))
    TbgNyqMerStCIUQoRcFLfvVjEKHuPh.setMimeType('application/dash+xml')
    TbgNyqMerStCIUQoRcFLfvVjEKHuPh.setContentLookup(TbgNyqMerStCIUQoRcFLfvVjEKHuxs)
  xbmcplugin.setResolvedUrl(TbgNyqMerStCIUQoRcFLfvVjEKHulx._addon_handle,TbgNyqMerStCIUQoRcFLfvVjEKHuxh,TbgNyqMerStCIUQoRcFLfvVjEKHuPh)
  try:
   if TbgNyqMerStCIUQoRcFLfvVjEKHuWx=='MOVIE':
    TbgNyqMerStCIUQoRcFLfvVjEKHuzG='movie'
    TbgNyqMerStCIUQoRcFLfvVjEKHupi={'code':TbgNyqMerStCIUQoRcFLfvVjEKHuPw,'asis':TbgNyqMerStCIUQoRcFLfvVjEKHuWx,'title':args.get('title'),'img':args.get('thumbnail'),}
    TbgNyqMerStCIUQoRcFLfvVjEKHulx.Save_Watched_List(TbgNyqMerStCIUQoRcFLfvVjEKHuzG,TbgNyqMerStCIUQoRcFLfvVjEKHupi)
   elif TbgNyqMerStCIUQoRcFLfvVjEKHuWx=='TVSHOW':
    TbgNyqMerStCIUQoRcFLfvVjEKHuzG='tvshow'
    TbgNyqMerStCIUQoRcFLfvVjEKHupi={'code':args.get('programid'),'asis':TbgNyqMerStCIUQoRcFLfvVjEKHuWx,'title':'%s <%s>'%(args.get('title'),args.get('programnm')),'img':args.get('programimg'),}
    TbgNyqMerStCIUQoRcFLfvVjEKHulx.Save_Watched_List(TbgNyqMerStCIUQoRcFLfvVjEKHuzG,TbgNyqMerStCIUQoRcFLfvVjEKHupi)
  except:
   TbgNyqMerStCIUQoRcFLfvVjEKHuxY
 def dp_Global_Search(TbgNyqMerStCIUQoRcFLfvVjEKHulx,args):
  TbgNyqMerStCIUQoRcFLfvVjEKHuWY=args.get('mode')
  if TbgNyqMerStCIUQoRcFLfvVjEKHuWY=='TOTAL_SEARCH':
   TbgNyqMerStCIUQoRcFLfvVjEKHuzn='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   TbgNyqMerStCIUQoRcFLfvVjEKHuzn='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(TbgNyqMerStCIUQoRcFLfvVjEKHuzn)
 def dp_Bookmark_Menu(TbgNyqMerStCIUQoRcFLfvVjEKHulx,args):
  TbgNyqMerStCIUQoRcFLfvVjEKHuzn='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(TbgNyqMerStCIUQoRcFLfvVjEKHuzn)
 def dp_Search_List(TbgNyqMerStCIUQoRcFLfvVjEKHulx,args):
  TbgNyqMerStCIUQoRcFLfvVjEKHuWA =TbgNyqMerStCIUQoRcFLfvVjEKHuxa(args.get('page'))
  if 'search_key' in args:
   TbgNyqMerStCIUQoRcFLfvVjEKHuzA=args.get('search_key')
  else:
   TbgNyqMerStCIUQoRcFLfvVjEKHuzA=TbgNyqMerStCIUQoRcFLfvVjEKHulx.get_keyboard_input(__language__(30908).encode('utf-8'))
   if not TbgNyqMerStCIUQoRcFLfvVjEKHuzA:
    return
  TbgNyqMerStCIUQoRcFLfvVjEKHuzO,TbgNyqMerStCIUQoRcFLfvVjEKHuWO=TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.Get_Search_List(TbgNyqMerStCIUQoRcFLfvVjEKHuzA,TbgNyqMerStCIUQoRcFLfvVjEKHuWA)
  for TbgNyqMerStCIUQoRcFLfvVjEKHuzm in TbgNyqMerStCIUQoRcFLfvVjEKHuzO:
   TbgNyqMerStCIUQoRcFLfvVjEKHuiP =TbgNyqMerStCIUQoRcFLfvVjEKHuzm.get('id')
   TbgNyqMerStCIUQoRcFLfvVjEKHupW =TbgNyqMerStCIUQoRcFLfvVjEKHuzm.get('title')
   TbgNyqMerStCIUQoRcFLfvVjEKHuWx =TbgNyqMerStCIUQoRcFLfvVjEKHuzm.get('asis')
   TbgNyqMerStCIUQoRcFLfvVjEKHuWz =TbgNyqMerStCIUQoRcFLfvVjEKHuzm.get('thumbnail')
   TbgNyqMerStCIUQoRcFLfvVjEKHuWm =TbgNyqMerStCIUQoRcFLfvVjEKHuzm.get('mpaa')
   TbgNyqMerStCIUQoRcFLfvVjEKHuWw =TbgNyqMerStCIUQoRcFLfvVjEKHuzm.get('year')
   TbgNyqMerStCIUQoRcFLfvVjEKHuWn =TbgNyqMerStCIUQoRcFLfvVjEKHuzm.get('duration')
   TbgNyqMerStCIUQoRcFLfvVjEKHuWJ =TbgNyqMerStCIUQoRcFLfvVjEKHuzm.get('badge')
   if TbgNyqMerStCIUQoRcFLfvVjEKHuWx=='TVSHOW': 
    TbgNyqMerStCIUQoRcFLfvVjEKHuWY ='SEASON_LIST'
    TbgNyqMerStCIUQoRcFLfvVjEKHuWl={'mediatype':'tvshow','title':TbgNyqMerStCIUQoRcFLfvVjEKHupW,'mpaa':TbgNyqMerStCIUQoRcFLfvVjEKHuWm,'year':TbgNyqMerStCIUQoRcFLfvVjEKHuWw,'plot':'Year : %s'%(TbgNyqMerStCIUQoRcFLfvVjEKHuWw),}
    TbgNyqMerStCIUQoRcFLfvVjEKHupD =TbgNyqMerStCIUQoRcFLfvVjEKHuxh
   elif TbgNyqMerStCIUQoRcFLfvVjEKHuWx=='MOVIE':
    TbgNyqMerStCIUQoRcFLfvVjEKHuWY ='MOVIE'
    TbgNyqMerStCIUQoRcFLfvVjEKHuWl={'mediatype':'movie','title':TbgNyqMerStCIUQoRcFLfvVjEKHupW,'mpaa':TbgNyqMerStCIUQoRcFLfvVjEKHuWm,'duration':TbgNyqMerStCIUQoRcFLfvVjEKHuWn,'year':TbgNyqMerStCIUQoRcFLfvVjEKHuWw,'plot':'(%s)'%(TbgNyqMerStCIUQoRcFLfvVjEKHuWm),}
    TbgNyqMerStCIUQoRcFLfvVjEKHupD =TbgNyqMerStCIUQoRcFLfvVjEKHuxs
    TbgNyqMerStCIUQoRcFLfvVjEKHupW +=' (%s)'%(TbgNyqMerStCIUQoRcFLfvVjEKHuiW(TbgNyqMerStCIUQoRcFLfvVjEKHuWw))
   elif TbgNyqMerStCIUQoRcFLfvVjEKHuWx=='HIGHLIGHT':
    TbgNyqMerStCIUQoRcFLfvVjEKHuWY ='HIGHLIGHT'
    TbgNyqMerStCIUQoRcFLfvVjEKHuWl={'mediatype':'episode','title':TbgNyqMerStCIUQoRcFLfvVjEKHupW,'duration':TbgNyqMerStCIUQoRcFLfvVjEKHuWn,'plot':TbgNyqMerStCIUQoRcFLfvVjEKHuWY,}
    TbgNyqMerStCIUQoRcFLfvVjEKHupD =TbgNyqMerStCIUQoRcFLfvVjEKHuxs
   elif TbgNyqMerStCIUQoRcFLfvVjEKHuWx=='LIVE':
    TbgNyqMerStCIUQoRcFLfvVjEKHuWY ='LIVE'
    TbgNyqMerStCIUQoRcFLfvVjEKHuWl={'mediatype':'episode','title':TbgNyqMerStCIUQoRcFLfvVjEKHupW,'plot':TbgNyqMerStCIUQoRcFLfvVjEKHuWY,}
    TbgNyqMerStCIUQoRcFLfvVjEKHupD =TbgNyqMerStCIUQoRcFLfvVjEKHuxs
   TbgNyqMerStCIUQoRcFLfvVjEKHupi={'mode':TbgNyqMerStCIUQoRcFLfvVjEKHuWY,'id':TbgNyqMerStCIUQoRcFLfvVjEKHuiP,'asis':TbgNyqMerStCIUQoRcFLfvVjEKHuWx,'seasonList':'','title':TbgNyqMerStCIUQoRcFLfvVjEKHupW,'thumbnail':json.dumps(TbgNyqMerStCIUQoRcFLfvVjEKHuWz,separators=(',',':')),'year':TbgNyqMerStCIUQoRcFLfvVjEKHuWw,}
   if TbgNyqMerStCIUQoRcFLfvVjEKHulx.get_settings_makebookmark()and TbgNyqMerStCIUQoRcFLfvVjEKHuWx not in['HIGHLIGHT','']:
    TbgNyqMerStCIUQoRcFLfvVjEKHuWs={'videoid':TbgNyqMerStCIUQoRcFLfvVjEKHuiP,'vidtype':'movie' if TbgNyqMerStCIUQoRcFLfvVjEKHuWx=='MOVIE' else 'tvshow','vtitle':TbgNyqMerStCIUQoRcFLfvVjEKHupW,'vsubtitle':'',}
    TbgNyqMerStCIUQoRcFLfvVjEKHuWh=json.dumps(TbgNyqMerStCIUQoRcFLfvVjEKHuWs)
    TbgNyqMerStCIUQoRcFLfvVjEKHuWh=urllib.parse.quote(TbgNyqMerStCIUQoRcFLfvVjEKHuWh)
    TbgNyqMerStCIUQoRcFLfvVjEKHuWd='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(TbgNyqMerStCIUQoRcFLfvVjEKHuWh)
    TbgNyqMerStCIUQoRcFLfvVjEKHuWX=[('(통합) 찜 영상에 추가',TbgNyqMerStCIUQoRcFLfvVjEKHuWd)]
   else:
    TbgNyqMerStCIUQoRcFLfvVjEKHuWX=TbgNyqMerStCIUQoRcFLfvVjEKHuxY
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.add_dir(TbgNyqMerStCIUQoRcFLfvVjEKHupW,sublabel=TbgNyqMerStCIUQoRcFLfvVjEKHuWJ,img=TbgNyqMerStCIUQoRcFLfvVjEKHuWz,infoLabels=TbgNyqMerStCIUQoRcFLfvVjEKHuWl,isFolder=TbgNyqMerStCIUQoRcFLfvVjEKHupD,params=TbgNyqMerStCIUQoRcFLfvVjEKHupi,ContextMenu=TbgNyqMerStCIUQoRcFLfvVjEKHuWX)
  if TbgNyqMerStCIUQoRcFLfvVjEKHuWO:
   TbgNyqMerStCIUQoRcFLfvVjEKHupi={}
   TbgNyqMerStCIUQoRcFLfvVjEKHupi['mode'] ='LOCAL_SEARCH'
   TbgNyqMerStCIUQoRcFLfvVjEKHupi['search_key']=TbgNyqMerStCIUQoRcFLfvVjEKHuzA
   TbgNyqMerStCIUQoRcFLfvVjEKHupi['page'] =TbgNyqMerStCIUQoRcFLfvVjEKHuiW(TbgNyqMerStCIUQoRcFLfvVjEKHuWA+1)
   TbgNyqMerStCIUQoRcFLfvVjEKHupW='[B]%s >>[/B]'%'다음 페이지'
   TbgNyqMerStCIUQoRcFLfvVjEKHuWa=TbgNyqMerStCIUQoRcFLfvVjEKHuiW(TbgNyqMerStCIUQoRcFLfvVjEKHuWA+1)
   TbgNyqMerStCIUQoRcFLfvVjEKHupx=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.add_dir(TbgNyqMerStCIUQoRcFLfvVjEKHupW,sublabel=TbgNyqMerStCIUQoRcFLfvVjEKHuWa,img=TbgNyqMerStCIUQoRcFLfvVjEKHupx,infoLabels=TbgNyqMerStCIUQoRcFLfvVjEKHuxY,isFolder=TbgNyqMerStCIUQoRcFLfvVjEKHuxh,params=TbgNyqMerStCIUQoRcFLfvVjEKHupi)
  xbmcplugin.setContent(TbgNyqMerStCIUQoRcFLfvVjEKHulx._addon_handle,'movies')
  xbmcplugin.endOfDirectory(TbgNyqMerStCIUQoRcFLfvVjEKHulx._addon_handle,cacheToDisc=TbgNyqMerStCIUQoRcFLfvVjEKHuxh)
  if args.get('historyyn')=='Y':TbgNyqMerStCIUQoRcFLfvVjEKHulx.Save_Searched_List(TbgNyqMerStCIUQoRcFLfvVjEKHuzA)
 def Load_List_File(TbgNyqMerStCIUQoRcFLfvVjEKHulx,TbgNyqMerStCIUQoRcFLfvVjEKHuzG): 
  try:
   if TbgNyqMerStCIUQoRcFLfvVjEKHuzG=='search':
    TbgNyqMerStCIUQoRcFLfvVjEKHuzJ=TbgNyqMerStCIUQoRcFLfvVjEKHulz
   elif TbgNyqMerStCIUQoRcFLfvVjEKHuzG in['tvshow','movie']:
    TbgNyqMerStCIUQoRcFLfvVjEKHuzJ=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%TbgNyqMerStCIUQoRcFLfvVjEKHuzG))
   else:
    return[]
   fp=TbgNyqMerStCIUQoRcFLfvVjEKHuil(TbgNyqMerStCIUQoRcFLfvVjEKHuzJ,'r',-1,'utf-8')
   TbgNyqMerStCIUQoRcFLfvVjEKHuzw=fp.readlines()
   fp.close()
  except:
   TbgNyqMerStCIUQoRcFLfvVjEKHuzw=[]
  return TbgNyqMerStCIUQoRcFLfvVjEKHuzw
 def Save_Watched_List(TbgNyqMerStCIUQoRcFLfvVjEKHulx,TbgNyqMerStCIUQoRcFLfvVjEKHuzG,TbgNyqMerStCIUQoRcFLfvVjEKHulG):
  try:
   TbgNyqMerStCIUQoRcFLfvVjEKHuzB=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%TbgNyqMerStCIUQoRcFLfvVjEKHuzG))
   TbgNyqMerStCIUQoRcFLfvVjEKHuzk=TbgNyqMerStCIUQoRcFLfvVjEKHulx.Load_List_File(TbgNyqMerStCIUQoRcFLfvVjEKHuzG) 
   fp=TbgNyqMerStCIUQoRcFLfvVjEKHuil(TbgNyqMerStCIUQoRcFLfvVjEKHuzB,'w',-1,'utf-8')
   TbgNyqMerStCIUQoRcFLfvVjEKHuzY=urllib.parse.urlencode(TbgNyqMerStCIUQoRcFLfvVjEKHulG)
   TbgNyqMerStCIUQoRcFLfvVjEKHuzY=TbgNyqMerStCIUQoRcFLfvVjEKHuzY+'\n'
   fp.write(TbgNyqMerStCIUQoRcFLfvVjEKHuzY)
   TbgNyqMerStCIUQoRcFLfvVjEKHuzs=0
   for TbgNyqMerStCIUQoRcFLfvVjEKHuzh in TbgNyqMerStCIUQoRcFLfvVjEKHuzk:
    TbgNyqMerStCIUQoRcFLfvVjEKHuzd=TbgNyqMerStCIUQoRcFLfvVjEKHuxX(urllib.parse.parse_qsl(TbgNyqMerStCIUQoRcFLfvVjEKHuzh))
    TbgNyqMerStCIUQoRcFLfvVjEKHuzX=TbgNyqMerStCIUQoRcFLfvVjEKHulG.get('code').strip()
    TbgNyqMerStCIUQoRcFLfvVjEKHuza=TbgNyqMerStCIUQoRcFLfvVjEKHuzd.get('code').strip()
    if TbgNyqMerStCIUQoRcFLfvVjEKHuzX!=TbgNyqMerStCIUQoRcFLfvVjEKHuza:
     fp.write(TbgNyqMerStCIUQoRcFLfvVjEKHuzh)
     TbgNyqMerStCIUQoRcFLfvVjEKHuzs+=1
     if TbgNyqMerStCIUQoRcFLfvVjEKHuzs>=50:break
   fp.close()
  except:
   TbgNyqMerStCIUQoRcFLfvVjEKHuxY
 def Save_Searched_List(TbgNyqMerStCIUQoRcFLfvVjEKHulx,TbgNyqMerStCIUQoRcFLfvVjEKHuzA):
  try:
   TbgNyqMerStCIUQoRcFLfvVjEKHuzA=TbgNyqMerStCIUQoRcFLfvVjEKHuzA.strip()
   TbgNyqMerStCIUQoRcFLfvVjEKHuzk=TbgNyqMerStCIUQoRcFLfvVjEKHulx.Load_List_File('search') 
   fp=TbgNyqMerStCIUQoRcFLfvVjEKHuil(TbgNyqMerStCIUQoRcFLfvVjEKHulz,'w',-1,'utf-8')
   fp.write(TbgNyqMerStCIUQoRcFLfvVjEKHuzA+'\n')
   TbgNyqMerStCIUQoRcFLfvVjEKHuzs=0
   for TbgNyqMerStCIUQoRcFLfvVjEKHuzh in TbgNyqMerStCIUQoRcFLfvVjEKHuzk:
    TbgNyqMerStCIUQoRcFLfvVjEKHuzh=TbgNyqMerStCIUQoRcFLfvVjEKHuzh.strip()
    if TbgNyqMerStCIUQoRcFLfvVjEKHuzA!=TbgNyqMerStCIUQoRcFLfvVjEKHuzh:
     fp.write(TbgNyqMerStCIUQoRcFLfvVjEKHuzh+'\n')
     TbgNyqMerStCIUQoRcFLfvVjEKHuzs+=1
     if TbgNyqMerStCIUQoRcFLfvVjEKHuzs>=50:break
   fp.close()
  except:
   TbgNyqMerStCIUQoRcFLfvVjEKHuxY
 def dp_Search_History(TbgNyqMerStCIUQoRcFLfvVjEKHulx,args):
  TbgNyqMerStCIUQoRcFLfvVjEKHuxl=TbgNyqMerStCIUQoRcFLfvVjEKHulx.Load_List_File('search')
  for TbgNyqMerStCIUQoRcFLfvVjEKHuxp in TbgNyqMerStCIUQoRcFLfvVjEKHuxl:
   TbgNyqMerStCIUQoRcFLfvVjEKHuxp=TbgNyqMerStCIUQoRcFLfvVjEKHuxp.strip()
   TbgNyqMerStCIUQoRcFLfvVjEKHupi={'mode':'LOCAL_SEARCH','search_key':TbgNyqMerStCIUQoRcFLfvVjEKHuxp,'page':'1','historyyn':'Y',}
   TbgNyqMerStCIUQoRcFLfvVjEKHuxW={'mode':'SEARCH_REMOVE','stype':'ONE','skey':TbgNyqMerStCIUQoRcFLfvVjEKHuxp,}
   TbgNyqMerStCIUQoRcFLfvVjEKHuxP=urllib.parse.urlencode(TbgNyqMerStCIUQoRcFLfvVjEKHuxW)
   TbgNyqMerStCIUQoRcFLfvVjEKHuWX=[('선택된 검색어 ( %s ) 삭제'%(TbgNyqMerStCIUQoRcFLfvVjEKHuxp),'RunPlugin(plugin://plugin.video.coupangm/?%s)'%(TbgNyqMerStCIUQoRcFLfvVjEKHuxP))]
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.add_dir(TbgNyqMerStCIUQoRcFLfvVjEKHuxp,sublabel='',img=TbgNyqMerStCIUQoRcFLfvVjEKHuxY,infoLabels=TbgNyqMerStCIUQoRcFLfvVjEKHuxY,isFolder=TbgNyqMerStCIUQoRcFLfvVjEKHuxh,params=TbgNyqMerStCIUQoRcFLfvVjEKHupi,ContextMenu=TbgNyqMerStCIUQoRcFLfvVjEKHuWX)
  TbgNyqMerStCIUQoRcFLfvVjEKHuWl={'plot':'검색목록 전체를 삭제합니다.'}
  TbgNyqMerStCIUQoRcFLfvVjEKHupW='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  TbgNyqMerStCIUQoRcFLfvVjEKHupi={'mode':'SEARCH_REMOVE','stype':'ALL','skey':'-',}
  TbgNyqMerStCIUQoRcFLfvVjEKHupx=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  TbgNyqMerStCIUQoRcFLfvVjEKHulx.add_dir(TbgNyqMerStCIUQoRcFLfvVjEKHupW,sublabel='',img=TbgNyqMerStCIUQoRcFLfvVjEKHupx,infoLabels=TbgNyqMerStCIUQoRcFLfvVjEKHuWl,isFolder=TbgNyqMerStCIUQoRcFLfvVjEKHuxs,params=TbgNyqMerStCIUQoRcFLfvVjEKHupi,isLink=TbgNyqMerStCIUQoRcFLfvVjEKHuxh)
  xbmcplugin.endOfDirectory(TbgNyqMerStCIUQoRcFLfvVjEKHulx._addon_handle,cacheToDisc=TbgNyqMerStCIUQoRcFLfvVjEKHuxs)
 def dp_Listfile_Delete(TbgNyqMerStCIUQoRcFLfvVjEKHulx,args):
  TbgNyqMerStCIUQoRcFLfvVjEKHuzG=args.get('stype')
  TbgNyqMerStCIUQoRcFLfvVjEKHuxz =args.get('skey')
  TbgNyqMerStCIUQoRcFLfvVjEKHulA=xbmcgui.Dialog()
  if TbgNyqMerStCIUQoRcFLfvVjEKHuzG=='ALL':
   TbgNyqMerStCIUQoRcFLfvVjEKHupA=TbgNyqMerStCIUQoRcFLfvVjEKHulA.yesno(__language__(30911).encode('utf8'),__language__(30906).encode('utf8'))
  elif TbgNyqMerStCIUQoRcFLfvVjEKHuzG=='ONE':
   TbgNyqMerStCIUQoRcFLfvVjEKHupA=TbgNyqMerStCIUQoRcFLfvVjEKHulA.yesno(__language__(30912).encode('utf8'),__language__(30906).encode('utf8'))
  elif TbgNyqMerStCIUQoRcFLfvVjEKHuzG in['tvshow','movie']:
   TbgNyqMerStCIUQoRcFLfvVjEKHupA=TbgNyqMerStCIUQoRcFLfvVjEKHulA.yesno(__language__(30913).encode('utf8'),__language__(30906).encode('utf8'))
  if TbgNyqMerStCIUQoRcFLfvVjEKHupA==TbgNyqMerStCIUQoRcFLfvVjEKHuxs:sys.exit()
  TbgNyqMerStCIUQoRcFLfvVjEKHulx.Delete_List_File(TbgNyqMerStCIUQoRcFLfvVjEKHuzG,skey=TbgNyqMerStCIUQoRcFLfvVjEKHuxz)
  xbmc.executebuiltin("Container.Refresh")
 def Delete_List_File(TbgNyqMerStCIUQoRcFLfvVjEKHulx,TbgNyqMerStCIUQoRcFLfvVjEKHuzG,skey='-'):
  if TbgNyqMerStCIUQoRcFLfvVjEKHuzG=='ALL':
   try:
    TbgNyqMerStCIUQoRcFLfvVjEKHuzJ=TbgNyqMerStCIUQoRcFLfvVjEKHulz
    fp=TbgNyqMerStCIUQoRcFLfvVjEKHuil(TbgNyqMerStCIUQoRcFLfvVjEKHuzJ,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    TbgNyqMerStCIUQoRcFLfvVjEKHuxY
  elif TbgNyqMerStCIUQoRcFLfvVjEKHuzG=='ONE':
   try:
    TbgNyqMerStCIUQoRcFLfvVjEKHuzJ=TbgNyqMerStCIUQoRcFLfvVjEKHulz
    TbgNyqMerStCIUQoRcFLfvVjEKHuzk=TbgNyqMerStCIUQoRcFLfvVjEKHulx.Load_List_File('search') 
    fp=TbgNyqMerStCIUQoRcFLfvVjEKHuil(TbgNyqMerStCIUQoRcFLfvVjEKHuzJ,'w',-1,'utf-8')
    for TbgNyqMerStCIUQoRcFLfvVjEKHuzh in TbgNyqMerStCIUQoRcFLfvVjEKHuzk:
     if skey!=TbgNyqMerStCIUQoRcFLfvVjEKHuzh.strip():
      fp.write(TbgNyqMerStCIUQoRcFLfvVjEKHuzh)
    fp.close()
   except:
    TbgNyqMerStCIUQoRcFLfvVjEKHuxY
  elif TbgNyqMerStCIUQoRcFLfvVjEKHuzG in['tvshow','movie']:
   try:
    TbgNyqMerStCIUQoRcFLfvVjEKHuzJ=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%TbgNyqMerStCIUQoRcFLfvVjEKHuzG))
    fp=TbgNyqMerStCIUQoRcFLfvVjEKHuil(TbgNyqMerStCIUQoRcFLfvVjEKHuzJ,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    TbgNyqMerStCIUQoRcFLfvVjEKHuxY
 def dp_Watch_List(TbgNyqMerStCIUQoRcFLfvVjEKHulx,args):
  TbgNyqMerStCIUQoRcFLfvVjEKHuzG =args.get('stype')
  if TbgNyqMerStCIUQoRcFLfvVjEKHuzG in['',TbgNyqMerStCIUQoRcFLfvVjEKHuxY]:
   for TbgNyqMerStCIUQoRcFLfvVjEKHuxi in TbgNyqMerStCIUQoRcFLfvVjEKHulP:
    TbgNyqMerStCIUQoRcFLfvVjEKHupW=TbgNyqMerStCIUQoRcFLfvVjEKHuxi.get('title')
    TbgNyqMerStCIUQoRcFLfvVjEKHupi={'mode':TbgNyqMerStCIUQoRcFLfvVjEKHuxi.get('mode'),'stype':TbgNyqMerStCIUQoRcFLfvVjEKHuxi.get('stype'),}
    TbgNyqMerStCIUQoRcFLfvVjEKHulx.add_dir(TbgNyqMerStCIUQoRcFLfvVjEKHupW,sublabel='',img='',infoLabels=TbgNyqMerStCIUQoRcFLfvVjEKHuxY,isFolder=TbgNyqMerStCIUQoRcFLfvVjEKHuxh,params=TbgNyqMerStCIUQoRcFLfvVjEKHupi)
   xbmcplugin.endOfDirectory(TbgNyqMerStCIUQoRcFLfvVjEKHulx._addon_handle)
  else:
   TbgNyqMerStCIUQoRcFLfvVjEKHuxD=TbgNyqMerStCIUQoRcFLfvVjEKHulx.Load_List_File(TbgNyqMerStCIUQoRcFLfvVjEKHuzG)
   for TbgNyqMerStCIUQoRcFLfvVjEKHuxG in TbgNyqMerStCIUQoRcFLfvVjEKHuxD:
    TbgNyqMerStCIUQoRcFLfvVjEKHuxn=TbgNyqMerStCIUQoRcFLfvVjEKHuxX(urllib.parse.parse_qsl(TbgNyqMerStCIUQoRcFLfvVjEKHuxG))
    TbgNyqMerStCIUQoRcFLfvVjEKHuPw =TbgNyqMerStCIUQoRcFLfvVjEKHuxn.get('code').strip()
    TbgNyqMerStCIUQoRcFLfvVjEKHupW =TbgNyqMerStCIUQoRcFLfvVjEKHuxn.get('title').strip()
    TbgNyqMerStCIUQoRcFLfvVjEKHuWz =TbgNyqMerStCIUQoRcFLfvVjEKHuxn.get('img').strip()
    TbgNyqMerStCIUQoRcFLfvVjEKHuWx =TbgNyqMerStCIUQoRcFLfvVjEKHuxn.get('asis').strip()
    try:
     TbgNyqMerStCIUQoRcFLfvVjEKHuWz=TbgNyqMerStCIUQoRcFLfvVjEKHuWz.replace('\'','\"')
     TbgNyqMerStCIUQoRcFLfvVjEKHuWz=json.loads(TbgNyqMerStCIUQoRcFLfvVjEKHuWz)
    except:
     TbgNyqMerStCIUQoRcFLfvVjEKHuxY
    TbgNyqMerStCIUQoRcFLfvVjEKHuWl={}
    TbgNyqMerStCIUQoRcFLfvVjEKHuWl['plot']=TbgNyqMerStCIUQoRcFLfvVjEKHupW
    if TbgNyqMerStCIUQoRcFLfvVjEKHuzG=='movie':
     TbgNyqMerStCIUQoRcFLfvVjEKHuWl['mediatype']='movie'
     TbgNyqMerStCIUQoRcFLfvVjEKHupi={'mode':'MOVIE','id':TbgNyqMerStCIUQoRcFLfvVjEKHuPw,'asis':TbgNyqMerStCIUQoRcFLfvVjEKHuWx,'title':TbgNyqMerStCIUQoRcFLfvVjEKHupW,'thumbnail':TbgNyqMerStCIUQoRcFLfvVjEKHuWz,}
     TbgNyqMerStCIUQoRcFLfvVjEKHupD=TbgNyqMerStCIUQoRcFLfvVjEKHuxs
    else:
     TbgNyqMerStCIUQoRcFLfvVjEKHuWl['mediatype']='episode'
     TbgNyqMerStCIUQoRcFLfvVjEKHupi={'mode':'SEASON_LIST','id':TbgNyqMerStCIUQoRcFLfvVjEKHuPw,'asis':TbgNyqMerStCIUQoRcFLfvVjEKHuWx,'title':TbgNyqMerStCIUQoRcFLfvVjEKHupW,'thumbnail':json.dumps(TbgNyqMerStCIUQoRcFLfvVjEKHuWz,separators=(',',':')),}
     TbgNyqMerStCIUQoRcFLfvVjEKHupD=TbgNyqMerStCIUQoRcFLfvVjEKHuxh
    TbgNyqMerStCIUQoRcFLfvVjEKHulx.add_dir(TbgNyqMerStCIUQoRcFLfvVjEKHupW,sublabel='',img=TbgNyqMerStCIUQoRcFLfvVjEKHuWz,infoLabels=TbgNyqMerStCIUQoRcFLfvVjEKHuWl,isFolder=TbgNyqMerStCIUQoRcFLfvVjEKHupD,params=TbgNyqMerStCIUQoRcFLfvVjEKHupi)
   TbgNyqMerStCIUQoRcFLfvVjEKHuWl={'plot':'시청목록을 삭제합니다.'}
   TbgNyqMerStCIUQoRcFLfvVjEKHupW='*** 시청목록 삭제 ***'
   TbgNyqMerStCIUQoRcFLfvVjEKHupi={'mode':'MYVIEW_REMOVE','stype':TbgNyqMerStCIUQoRcFLfvVjEKHuzG,'skey':'-',}
   TbgNyqMerStCIUQoRcFLfvVjEKHupx=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.add_dir(TbgNyqMerStCIUQoRcFLfvVjEKHupW,sublabel='',img=TbgNyqMerStCIUQoRcFLfvVjEKHupx,infoLabels=TbgNyqMerStCIUQoRcFLfvVjEKHuWl,isFolder=TbgNyqMerStCIUQoRcFLfvVjEKHuxs,params=TbgNyqMerStCIUQoRcFLfvVjEKHupi,isLink=TbgNyqMerStCIUQoRcFLfvVjEKHuxh)
   if TbgNyqMerStCIUQoRcFLfvVjEKHuzG=='movie':xbmcplugin.setContent(TbgNyqMerStCIUQoRcFLfvVjEKHulx._addon_handle,'movies')
   else:xbmcplugin.setContent(TbgNyqMerStCIUQoRcFLfvVjEKHulx._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(TbgNyqMerStCIUQoRcFLfvVjEKHulx._addon_handle,cacheToDisc=TbgNyqMerStCIUQoRcFLfvVjEKHuxs)
 def dp_Set_Bookmark(TbgNyqMerStCIUQoRcFLfvVjEKHulx,args):
  TbgNyqMerStCIUQoRcFLfvVjEKHuxA=urllib.parse.unquote(args.get('bm_param'))
  TbgNyqMerStCIUQoRcFLfvVjEKHuxA=json.loads(TbgNyqMerStCIUQoRcFLfvVjEKHuxA)
  TbgNyqMerStCIUQoRcFLfvVjEKHuxO =TbgNyqMerStCIUQoRcFLfvVjEKHuxA.get('videoid')
  TbgNyqMerStCIUQoRcFLfvVjEKHuxm =TbgNyqMerStCIUQoRcFLfvVjEKHuxA.get('vidtype')
  TbgNyqMerStCIUQoRcFLfvVjEKHuxJ =TbgNyqMerStCIUQoRcFLfvVjEKHuxA.get('vtitle')
  TbgNyqMerStCIUQoRcFLfvVjEKHulA=xbmcgui.Dialog()
  TbgNyqMerStCIUQoRcFLfvVjEKHupA=TbgNyqMerStCIUQoRcFLfvVjEKHulA.yesno(__language__(30914).encode('utf8'),TbgNyqMerStCIUQoRcFLfvVjEKHuxJ+' \n\n'+__language__(30915))
  if TbgNyqMerStCIUQoRcFLfvVjEKHupA==TbgNyqMerStCIUQoRcFLfvVjEKHuxs:return
  TbgNyqMerStCIUQoRcFLfvVjEKHuxw=TbgNyqMerStCIUQoRcFLfvVjEKHulx.CoupangObj.GetBookmarkInfo(TbgNyqMerStCIUQoRcFLfvVjEKHuxO,TbgNyqMerStCIUQoRcFLfvVjEKHuxm)
  TbgNyqMerStCIUQoRcFLfvVjEKHuxB=json.dumps(TbgNyqMerStCIUQoRcFLfvVjEKHuxw)
  TbgNyqMerStCIUQoRcFLfvVjEKHuxB=urllib.parse.quote(TbgNyqMerStCIUQoRcFLfvVjEKHuxB)
  TbgNyqMerStCIUQoRcFLfvVjEKHuWd ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(TbgNyqMerStCIUQoRcFLfvVjEKHuxB)
  xbmc.executebuiltin(TbgNyqMerStCIUQoRcFLfvVjEKHuWd)
 def coupang_main(TbgNyqMerStCIUQoRcFLfvVjEKHulx):
  TbgNyqMerStCIUQoRcFLfvVjEKHuWY=TbgNyqMerStCIUQoRcFLfvVjEKHulx.main_params.get('mode',TbgNyqMerStCIUQoRcFLfvVjEKHuxY)
  if TbgNyqMerStCIUQoRcFLfvVjEKHuWY=='LOGOUT':
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.CP_logout()
   return
  TbgNyqMerStCIUQoRcFLfvVjEKHulx.option_check()
  if TbgNyqMerStCIUQoRcFLfvVjEKHuWY is TbgNyqMerStCIUQoRcFLfvVjEKHuxY:
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.dp_Main_List(TbgNyqMerStCIUQoRcFLfvVjEKHulx.main_params)
  elif TbgNyqMerStCIUQoRcFLfvVjEKHuWY=='CATEGORY_GROUPLIST':
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.dp_Category_GroupList(TbgNyqMerStCIUQoRcFLfvVjEKHulx.main_params)
  elif TbgNyqMerStCIUQoRcFLfvVjEKHuWY=='THEME_GROUPLIST':
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.dp_Theme_GroupList(TbgNyqMerStCIUQoRcFLfvVjEKHulx.main_params)
  elif TbgNyqMerStCIUQoRcFLfvVjEKHuWY=='EVENT_GROUPLIST':
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.dp_Event_GroupList(TbgNyqMerStCIUQoRcFLfvVjEKHulx.main_params)
  elif TbgNyqMerStCIUQoRcFLfvVjEKHuWY=='EVENT_GAMELIST':
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.dp_Event_GameList(TbgNyqMerStCIUQoRcFLfvVjEKHulx.main_params)
  elif TbgNyqMerStCIUQoRcFLfvVjEKHuWY=='EVENT_LIST':
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.dp_Event_List(TbgNyqMerStCIUQoRcFLfvVjEKHulx.main_params)
  elif TbgNyqMerStCIUQoRcFLfvVjEKHuWY=='CATEGORY_LIST':
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.dp_Category_List(TbgNyqMerStCIUQoRcFLfvVjEKHulx.main_params)
  elif TbgNyqMerStCIUQoRcFLfvVjEKHuWY=='SEASON_LIST':
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.dp_Season_List(TbgNyqMerStCIUQoRcFLfvVjEKHulx.main_params)
  elif TbgNyqMerStCIUQoRcFLfvVjEKHuWY=='EPISODE_LIST':
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.dp_Episode_List(TbgNyqMerStCIUQoRcFLfvVjEKHulx.main_params)
  elif TbgNyqMerStCIUQoRcFLfvVjEKHuWY=='TEST':
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.dp_Test(TbgNyqMerStCIUQoRcFLfvVjEKHulx.main_params)
  elif TbgNyqMerStCIUQoRcFLfvVjEKHuWY in['MOVIE','VOD','HIGHLIGHT','LIVE']:
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.play_VIDEO(TbgNyqMerStCIUQoRcFLfvVjEKHulx.main_params)
  elif TbgNyqMerStCIUQoRcFLfvVjEKHuWY=='WATCH':
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.dp_Watch_List(TbgNyqMerStCIUQoRcFLfvVjEKHulx.main_params)
  elif TbgNyqMerStCIUQoRcFLfvVjEKHuWY=='LOCAL_SEARCH':
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.dp_Search_List(TbgNyqMerStCIUQoRcFLfvVjEKHulx.main_params)
  elif TbgNyqMerStCIUQoRcFLfvVjEKHuWY=='SEARCH_HISTORY':
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.dp_Search_History(TbgNyqMerStCIUQoRcFLfvVjEKHulx.main_params)
  elif TbgNyqMerStCIUQoRcFLfvVjEKHuWY in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.dp_Listfile_Delete(TbgNyqMerStCIUQoRcFLfvVjEKHulx.main_params)
  elif TbgNyqMerStCIUQoRcFLfvVjEKHuWY in['TOTAL_SEARCH','TOTAL_HISTORY']:
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.dp_Global_Search(TbgNyqMerStCIUQoRcFLfvVjEKHulx.main_params)
  elif TbgNyqMerStCIUQoRcFLfvVjEKHuWY=='MENU_BOOKMARK':
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.dp_Bookmark_Menu(TbgNyqMerStCIUQoRcFLfvVjEKHulx.main_params)
  elif TbgNyqMerStCIUQoRcFLfvVjEKHuWY=='SET_BOOKMARK':
   TbgNyqMerStCIUQoRcFLfvVjEKHulx.dp_Set_Bookmark(TbgNyqMerStCIUQoRcFLfvVjEKHulx.main_params)
  else:
   TbgNyqMerStCIUQoRcFLfvVjEKHuxY
# Created by pyminifier (https://github.com/liftoff/pyminifier)
