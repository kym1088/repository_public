__author__="NightRain"
NdrmHGwijBuVehkPfbnoJyalYLSgzO=object
NdrmHGwijBuVehkPfbnoJyalYLSgzF=None
NdrmHGwijBuVehkPfbnoJyalYLSgzq=False
NdrmHGwijBuVehkPfbnoJyalYLSgzc=print
NdrmHGwijBuVehkPfbnoJyalYLSgzI=str
NdrmHGwijBuVehkPfbnoJyalYLSgzQ=open
NdrmHGwijBuVehkPfbnoJyalYLSgzR=int
NdrmHGwijBuVehkPfbnoJyalYLSgzt=Exception
NdrmHGwijBuVehkPfbnoJyalYLSgzv=id
NdrmHGwijBuVehkPfbnoJyalYLSgzp=True
NdrmHGwijBuVehkPfbnoJyalYLSgzC=len
NdrmHGwijBuVehkPfbnoJyalYLSgzA=range
import urllib
import re
import json
import requests
import datetime
import time
import random
import base64
class NdrmHGwijBuVehkPfbnoJyalYLSgKM(NdrmHGwijBuVehkPfbnoJyalYLSgzO):
 def __init__(NdrmHGwijBuVehkPfbnoJyalYLSgKx):
  NdrmHGwijBuVehkPfbnoJyalYLSgKx.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.82 Safari/537.36'
  NdrmHGwijBuVehkPfbnoJyalYLSgKx.MODEL ='Chrome_98' 
  NdrmHGwijBuVehkPfbnoJyalYLSgKx.DEFAULT_HEADER ={'user-agent':NdrmHGwijBuVehkPfbnoJyalYLSgKx.USER_AGENT}
  NdrmHGwijBuVehkPfbnoJyalYLSgKx.API_DOMAIN ='https://www.coupangplay.com'
  NdrmHGwijBuVehkPfbnoJyalYLSgKx.API_VIEWURL ='https://discover.coupangstreaming.com'
  NdrmHGwijBuVehkPfbnoJyalYLSgKx.PAGE_LIMIT =40
  NdrmHGwijBuVehkPfbnoJyalYLSgKx.SEARCH_LIMIT =20
  NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP={}
  NdrmHGwijBuVehkPfbnoJyalYLSgKx.Init_CP()
  NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP_DEVICE_FILENAME=''
  NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP_COOKIE_FILENAME=''
 def callRequestCookies(NdrmHGwijBuVehkPfbnoJyalYLSgKx,jobtype,NdrmHGwijBuVehkPfbnoJyalYLSgMz,payload=NdrmHGwijBuVehkPfbnoJyalYLSgzF,params=NdrmHGwijBuVehkPfbnoJyalYLSgzF,headers=NdrmHGwijBuVehkPfbnoJyalYLSgzF,cookies=NdrmHGwijBuVehkPfbnoJyalYLSgzF,redirects=NdrmHGwijBuVehkPfbnoJyalYLSgzq):
  NdrmHGwijBuVehkPfbnoJyalYLSgKz=NdrmHGwijBuVehkPfbnoJyalYLSgKx.DEFAULT_HEADER
  if headers:NdrmHGwijBuVehkPfbnoJyalYLSgKz.update(headers)
  if jobtype=='Get':
   NdrmHGwijBuVehkPfbnoJyalYLSgKT=requests.get(NdrmHGwijBuVehkPfbnoJyalYLSgMz,params=params,headers=NdrmHGwijBuVehkPfbnoJyalYLSgKz,cookies=cookies,allow_redirects=redirects)
  else:
   NdrmHGwijBuVehkPfbnoJyalYLSgKT=requests.post(NdrmHGwijBuVehkPfbnoJyalYLSgMz,data=payload,params=params,headers=NdrmHGwijBuVehkPfbnoJyalYLSgKz,cookies=cookies,allow_redirects=redirects)
  NdrmHGwijBuVehkPfbnoJyalYLSgzc(NdrmHGwijBuVehkPfbnoJyalYLSgzI(NdrmHGwijBuVehkPfbnoJyalYLSgKT.status_code)+' - '+NdrmHGwijBuVehkPfbnoJyalYLSgzI(NdrmHGwijBuVehkPfbnoJyalYLSgKT.url))
  return NdrmHGwijBuVehkPfbnoJyalYLSgKT
 def callRequestCookies_test(NdrmHGwijBuVehkPfbnoJyalYLSgKx,jobtype,NdrmHGwijBuVehkPfbnoJyalYLSgMz,payload=NdrmHGwijBuVehkPfbnoJyalYLSgzF,params=NdrmHGwijBuVehkPfbnoJyalYLSgzF,headers=NdrmHGwijBuVehkPfbnoJyalYLSgzF,cookies=NdrmHGwijBuVehkPfbnoJyalYLSgzF,redirects=NdrmHGwijBuVehkPfbnoJyalYLSgzq):
  NdrmHGwijBuVehkPfbnoJyalYLSgKz=NdrmHGwijBuVehkPfbnoJyalYLSgKx.DEFAULT_HEADER
  if headers:NdrmHGwijBuVehkPfbnoJyalYLSgKz.update(headers)
  NdrmHGwijBuVehkPfbnoJyalYLSgKT=requests.Request('POST',NdrmHGwijBuVehkPfbnoJyalYLSgMz,headers=headers,data=payload,params=params,cookies=cookies)
  NdrmHGwijBuVehkPfbnoJyalYLSgKD=NdrmHGwijBuVehkPfbnoJyalYLSgKT.prepare()
  NdrmHGwijBuVehkPfbnoJyalYLSgKx.pretty_print_POST(NdrmHGwijBuVehkPfbnoJyalYLSgKD)
  return NdrmHGwijBuVehkPfbnoJyalYLSgKT
 def pretty_print_POST(NdrmHGwijBuVehkPfbnoJyalYLSgKx,req):
  NdrmHGwijBuVehkPfbnoJyalYLSgzc('{}\n{}\r\n{}\r\n\r\n{}'.format('-----------START-----------',req.method+' '+req.url,'\r\n'.join('{}: {}'.format(k,v)for k,v in req.headers.items()),req.body,))
 def dic_To_jsonfile(NdrmHGwijBuVehkPfbnoJyalYLSgKx,filename,NdrmHGwijBuVehkPfbnoJyalYLSgKs):
  if filename=='':return
  fp=NdrmHGwijBuVehkPfbnoJyalYLSgzQ(filename,'w',-1,'utf-8')
  json.dump(NdrmHGwijBuVehkPfbnoJyalYLSgKs,fp,indent=4,ensure_ascii=NdrmHGwijBuVehkPfbnoJyalYLSgzq)
  fp.close()
 def jsonfile_To_dic(NdrmHGwijBuVehkPfbnoJyalYLSgKx,filename):
  if filename=='':return NdrmHGwijBuVehkPfbnoJyalYLSgzF
  try:
   fp=NdrmHGwijBuVehkPfbnoJyalYLSgzQ(filename,'r',-1,'utf-8')
   NdrmHGwijBuVehkPfbnoJyalYLSgKW=json.load(fp)
   fp.close()
  except:
   NdrmHGwijBuVehkPfbnoJyalYLSgKW={}
  return NdrmHGwijBuVehkPfbnoJyalYLSgKW
 def convert_TimeStr(NdrmHGwijBuVehkPfbnoJyalYLSgKx,NdrmHGwijBuVehkPfbnoJyalYLSgKU):
  try:
   NdrmHGwijBuVehkPfbnoJyalYLSgKU =NdrmHGwijBuVehkPfbnoJyalYLSgKU[0:16]
   NdrmHGwijBuVehkPfbnoJyalYLSgKE=datetime.datetime.strptime(NdrmHGwijBuVehkPfbnoJyalYLSgKU,'%Y-%m-%dT%H:%M')+datetime.timedelta(hours=9)
   return NdrmHGwijBuVehkPfbnoJyalYLSgKE.strftime('%Y-%m-%d %H:%M')
  except:
   return NdrmHGwijBuVehkPfbnoJyalYLSgzF
 def Get_Now_Datetime(NdrmHGwijBuVehkPfbnoJyalYLSgKx):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetNoCache(NdrmHGwijBuVehkPfbnoJyalYLSgKx):
  NdrmHGwijBuVehkPfbnoJyalYLSgKF =NdrmHGwijBuVehkPfbnoJyalYLSgzR(time.time()*1000)
  return NdrmHGwijBuVehkPfbnoJyalYLSgKF
 def generatePcId(NdrmHGwijBuVehkPfbnoJyalYLSgKx):
  t=NdrmHGwijBuVehkPfbnoJyalYLSgKx.GetNoCache()
  r=random.random()
  NdrmHGwijBuVehkPfbnoJyalYLSgKq=NdrmHGwijBuVehkPfbnoJyalYLSgzI(t)+NdrmHGwijBuVehkPfbnoJyalYLSgzI(r)[2:12]
  return NdrmHGwijBuVehkPfbnoJyalYLSgKq
 def generatePvId(NdrmHGwijBuVehkPfbnoJyalYLSgKx,genType='1'):
  import hashlib
  m=hashlib.md5()
  NdrmHGwijBuVehkPfbnoJyalYLSgKc=NdrmHGwijBuVehkPfbnoJyalYLSgzI(random.random())
  m.update(NdrmHGwijBuVehkPfbnoJyalYLSgKc.encode('utf-8'))
  NdrmHGwijBuVehkPfbnoJyalYLSgKI=NdrmHGwijBuVehkPfbnoJyalYLSgzI(m.hexdigest())
  if genType=='1':
   return '%s-%s-%s-%s-%s'%(NdrmHGwijBuVehkPfbnoJyalYLSgKI[:8],NdrmHGwijBuVehkPfbnoJyalYLSgKI[8:12],NdrmHGwijBuVehkPfbnoJyalYLSgKI[12:16],NdrmHGwijBuVehkPfbnoJyalYLSgKI[16:20],NdrmHGwijBuVehkPfbnoJyalYLSgKI[20:])
  else:
   return NdrmHGwijBuVehkPfbnoJyalYLSgKI
 def Get_DeviceID(NdrmHGwijBuVehkPfbnoJyalYLSgKx):
  NdrmHGwijBuVehkPfbnoJyalYLSgKQ=''
  try: 
   fp=NdrmHGwijBuVehkPfbnoJyalYLSgzQ(NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP_DEVICE_FILENAME,'r',-1,'utf-8')
   NdrmHGwijBuVehkPfbnoJyalYLSgKR= json.load(fp)
   fp.close()
   NdrmHGwijBuVehkPfbnoJyalYLSgKQ=NdrmHGwijBuVehkPfbnoJyalYLSgKR.get('device_id')
  except NdrmHGwijBuVehkPfbnoJyalYLSgzt as exception:
   NdrmHGwijBuVehkPfbnoJyalYLSgzF
  if NdrmHGwijBuVehkPfbnoJyalYLSgKQ=='':
   NdrmHGwijBuVehkPfbnoJyalYLSgKQ=NdrmHGwijBuVehkPfbnoJyalYLSgKx.generatePvId(genType='1')
   try: 
    fp=NdrmHGwijBuVehkPfbnoJyalYLSgzQ(NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP_DEVICE_FILENAME,'w',-1,'utf-8')
    json.dump({'device_id':NdrmHGwijBuVehkPfbnoJyalYLSgKQ},fp,indent=4,ensure_ascii=NdrmHGwijBuVehkPfbnoJyalYLSgzq)
    fp.close()
   except NdrmHGwijBuVehkPfbnoJyalYLSgzt as exception:
    return ''
  return NdrmHGwijBuVehkPfbnoJyalYLSgKQ
 def Make_authHeader(NdrmHGwijBuVehkPfbnoJyalYLSgKx):
  tr=NdrmHGwijBuVehkPfbnoJyalYLSgKx.generatePvId(genType=2)
  ti=NdrmHGwijBuVehkPfbnoJyalYLSgKx.GetNoCache()
  NdrmHGwijBuVehkPfbnoJyalYLSgzv=NdrmHGwijBuVehkPfbnoJyalYLSgKx.generatePvId(genType=2)[:16]
  NdrmHGwijBuVehkPfbnoJyalYLSgKt='00-%s-%s-01'%(tr,NdrmHGwijBuVehkPfbnoJyalYLSgzv,)
  NdrmHGwijBuVehkPfbnoJyalYLSgKv ='%s@nr=0-1-%s-%s-%s----%s'%(NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['NREUM']['tk'],NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['NREUM']['ac'],NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['NREUM']['ap'],NdrmHGwijBuVehkPfbnoJyalYLSgzv,ti,)
  NdrmHGwijBuVehkPfbnoJyalYLSgKp ='{"v":[0,1],"d":{"ty":"Browser","ac":"%s","ap":"%s","id":"%s","tr":"%s","ti":%s,"tk":"%s"}}'%(NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['NREUM']['ac'],NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['NREUM']['ap'],NdrmHGwijBuVehkPfbnoJyalYLSgzv,tr,ti,NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['NREUM']['tk'],) 
  return NdrmHGwijBuVehkPfbnoJyalYLSgKt,NdrmHGwijBuVehkPfbnoJyalYLSgKv,base64.standard_b64encode(NdrmHGwijBuVehkPfbnoJyalYLSgKp.encode()).decode('utf-8')
 def Init_CP(NdrmHGwijBuVehkPfbnoJyalYLSgKx):
  NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP={}
  NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['ACCOUNT']={'cpid':'','cppw':'','cppf':'0'}
  NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']={}
 def Save_session_acount(NdrmHGwijBuVehkPfbnoJyalYLSgKx,NdrmHGwijBuVehkPfbnoJyalYLSgKC,NdrmHGwijBuVehkPfbnoJyalYLSgKA,NdrmHGwijBuVehkPfbnoJyalYLSgMK):
  NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['ACCOUNT']['cpid']=base64.standard_b64encode(NdrmHGwijBuVehkPfbnoJyalYLSgKC.encode()).decode('utf-8')
  NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['ACCOUNT']['cppw']=base64.standard_b64encode(NdrmHGwijBuVehkPfbnoJyalYLSgKA.encode()).decode('utf-8')
  NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['ACCOUNT']['cppf']=NdrmHGwijBuVehkPfbnoJyalYLSgzI(NdrmHGwijBuVehkPfbnoJyalYLSgMK)
 def Load_session_acount(NdrmHGwijBuVehkPfbnoJyalYLSgKx):
  NdrmHGwijBuVehkPfbnoJyalYLSgKC=base64.standard_b64decode(NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['ACCOUNT']['cpid']).decode('utf-8')
  NdrmHGwijBuVehkPfbnoJyalYLSgKA=base64.standard_b64decode(NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['ACCOUNT']['cppw']).decode('utf-8')
  NdrmHGwijBuVehkPfbnoJyalYLSgMK=NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['ACCOUNT']['cppf']
  return NdrmHGwijBuVehkPfbnoJyalYLSgKC,NdrmHGwijBuVehkPfbnoJyalYLSgKA,NdrmHGwijBuVehkPfbnoJyalYLSgMK
 def make_CP_DefaultCookies(NdrmHGwijBuVehkPfbnoJyalYLSgKx):
  NdrmHGwijBuVehkPfbnoJyalYLSgMx={}
  if 'NEXT_LOCALE' in NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']:NdrmHGwijBuVehkPfbnoJyalYLSgMx['NEXT_LOCALE']=NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['NEXT_LOCALE']
  if 'ak_bmsc' in NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']:NdrmHGwijBuVehkPfbnoJyalYLSgMx['ak_bmsc'] =NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['ak_bmsc']
  if 'bm_mi' in NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']:NdrmHGwijBuVehkPfbnoJyalYLSgMx['bm_mi'] =NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['bm_mi']
  if 'bm_sv' in NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']:NdrmHGwijBuVehkPfbnoJyalYLSgMx['bm_sv'] =NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['bm_sv']
  if 'PCID' in NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']:NdrmHGwijBuVehkPfbnoJyalYLSgMx['PCID'] =NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['PCID']
  if 'member_srl' in NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']:NdrmHGwijBuVehkPfbnoJyalYLSgMx['member_srl']=NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['member_srl']
  if 'token' in NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']:NdrmHGwijBuVehkPfbnoJyalYLSgMx['token'] =NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['token']
  return NdrmHGwijBuVehkPfbnoJyalYLSgMx
 def Get_CP_Login(NdrmHGwijBuVehkPfbnoJyalYLSgKx,userid,userpw,NdrmHGwijBuVehkPfbnoJyalYLSgMq):
  try:
   NdrmHGwijBuVehkPfbnoJyalYLSgMz=NdrmHGwijBuVehkPfbnoJyalYLSgKx.API_DOMAIN
   NdrmHGwijBuVehkPfbnoJyalYLSgMT=NdrmHGwijBuVehkPfbnoJyalYLSgKx.callRequestCookies('Get',NdrmHGwijBuVehkPfbnoJyalYLSgMz,payload=NdrmHGwijBuVehkPfbnoJyalYLSgzF,params=NdrmHGwijBuVehkPfbnoJyalYLSgzF,headers=NdrmHGwijBuVehkPfbnoJyalYLSgzF,cookies=NdrmHGwijBuVehkPfbnoJyalYLSgzF,redirects=NdrmHGwijBuVehkPfbnoJyalYLSgzq)
   if NdrmHGwijBuVehkPfbnoJyalYLSgMT.status_code not in[301,302]:return NdrmHGwijBuVehkPfbnoJyalYLSgzq
   for NdrmHGwijBuVehkPfbnoJyalYLSgMD in NdrmHGwijBuVehkPfbnoJyalYLSgMT.cookies:
    if NdrmHGwijBuVehkPfbnoJyalYLSgMD.name=='NEXT_LOCALE':
     NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['NEXT_LOCALE']=NdrmHGwijBuVehkPfbnoJyalYLSgMD.value
    elif NdrmHGwijBuVehkPfbnoJyalYLSgMD.name=='ak_bmsc':
     NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['ak_bmsc']=NdrmHGwijBuVehkPfbnoJyalYLSgMD.value
   NdrmHGwijBuVehkPfbnoJyalYLSgMx={'NEXT_LOCALE':NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['NEXT_LOCALE'],'ak_bmsc':NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['ak_bmsc'],}
   NdrmHGwijBuVehkPfbnoJyalYLSgMT=NdrmHGwijBuVehkPfbnoJyalYLSgKx.callRequestCookies('Get',NdrmHGwijBuVehkPfbnoJyalYLSgMz,payload=NdrmHGwijBuVehkPfbnoJyalYLSgzF,params=NdrmHGwijBuVehkPfbnoJyalYLSgzF,headers=NdrmHGwijBuVehkPfbnoJyalYLSgzF,cookies=NdrmHGwijBuVehkPfbnoJyalYLSgMx,redirects=NdrmHGwijBuVehkPfbnoJyalYLSgzq)
   if NdrmHGwijBuVehkPfbnoJyalYLSgMT.status_code not in[200]:return NdrmHGwijBuVehkPfbnoJyalYLSgzq
   NdrmHGwijBuVehkPfbnoJyalYLSgMs=re.findall('NREUM.loader_config=\{[\w\d\":,-]+\}',NdrmHGwijBuVehkPfbnoJyalYLSgMT.text)[0].split('=')[1]
   NdrmHGwijBuVehkPfbnoJyalYLSgMs=NdrmHGwijBuVehkPfbnoJyalYLSgMs.replace('{','{"').replace(':','":').replace(',',',"')
   NdrmHGwijBuVehkPfbnoJyalYLSgMs=json.loads(NdrmHGwijBuVehkPfbnoJyalYLSgMs)
   NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['NREUM']={'ac':NdrmHGwijBuVehkPfbnoJyalYLSgMs['accountID'],'tk':NdrmHGwijBuVehkPfbnoJyalYLSgMs['trustKey'],'ap':NdrmHGwijBuVehkPfbnoJyalYLSgMs['agentID'],'lk':NdrmHGwijBuVehkPfbnoJyalYLSgMs['licenseKey'],}
   for NdrmHGwijBuVehkPfbnoJyalYLSgMD in NdrmHGwijBuVehkPfbnoJyalYLSgMT.cookies:
    if NdrmHGwijBuVehkPfbnoJyalYLSgMD.name=='bm_mi':
     NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['bm_mi']=NdrmHGwijBuVehkPfbnoJyalYLSgMD.value
    elif NdrmHGwijBuVehkPfbnoJyalYLSgMD.name=='bm_sv':
     NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['bm_sv'] =NdrmHGwijBuVehkPfbnoJyalYLSgMD.value
     NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['bm_sv_ex']=NdrmHGwijBuVehkPfbnoJyalYLSgMD.expires 
  except NdrmHGwijBuVehkPfbnoJyalYLSgzt as exception:
   NdrmHGwijBuVehkPfbnoJyalYLSgzc(exception)
   return NdrmHGwijBuVehkPfbnoJyalYLSgzq
  try:
   NdrmHGwijBuVehkPfbnoJyalYLSgMz=NdrmHGwijBuVehkPfbnoJyalYLSgKx.API_DOMAIN+'/api/auth'
   NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['PCID']=NdrmHGwijBuVehkPfbnoJyalYLSgKx.generatePcId()
   NdrmHGwijBuVehkPfbnoJyalYLSgMX=NdrmHGwijBuVehkPfbnoJyalYLSgKx.Get_DeviceID()
   NdrmHGwijBuVehkPfbnoJyalYLSgMW =NdrmHGwijBuVehkPfbnoJyalYLSgMX.split('-')[0]
   NdrmHGwijBuVehkPfbnoJyalYLSgKt,NdrmHGwijBuVehkPfbnoJyalYLSgKv,NdrmHGwijBuVehkPfbnoJyalYLSgKp=NdrmHGwijBuVehkPfbnoJyalYLSgKx.Make_authHeader()
   NdrmHGwijBuVehkPfbnoJyalYLSgMU={'traceparent':NdrmHGwijBuVehkPfbnoJyalYLSgKt,'tracestate':NdrmHGwijBuVehkPfbnoJyalYLSgKv,'newrelic':NdrmHGwijBuVehkPfbnoJyalYLSgKp,'content-type':'application/json',}
   NdrmHGwijBuVehkPfbnoJyalYLSgME={'device':{'deviceId':'web-'+NdrmHGwijBuVehkPfbnoJyalYLSgMX,'model':NdrmHGwijBuVehkPfbnoJyalYLSgKx.MODEL,'name':'Chrome Desktop '+NdrmHGwijBuVehkPfbnoJyalYLSgMW,'os':'Windows','osVersion':'10','type':'webclient',},'email':userid,'password':userpw,}
   NdrmHGwijBuVehkPfbnoJyalYLSgME=json.dumps(NdrmHGwijBuVehkPfbnoJyalYLSgME,separators=(',',':'))
   NdrmHGwijBuVehkPfbnoJyalYLSgMx={'NEXT_LOCALE':NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['NEXT_LOCALE'],'ak_bmsc':NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['ak_bmsc'],'bm_mi':NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['bm_mi'],'bm_sv':NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['bm_sv'],'PCID':NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['PCID'],}
   NdrmHGwijBuVehkPfbnoJyalYLSgMT=NdrmHGwijBuVehkPfbnoJyalYLSgKx.callRequestCookies('Post',NdrmHGwijBuVehkPfbnoJyalYLSgMz,payload=NdrmHGwijBuVehkPfbnoJyalYLSgME,params=NdrmHGwijBuVehkPfbnoJyalYLSgzF,headers=NdrmHGwijBuVehkPfbnoJyalYLSgMU,cookies=NdrmHGwijBuVehkPfbnoJyalYLSgMx,redirects=NdrmHGwijBuVehkPfbnoJyalYLSgzq)
   if NdrmHGwijBuVehkPfbnoJyalYLSgMT.status_code not in[200]:
    NdrmHGwijBuVehkPfbnoJyalYLSgMO=json.loads(NdrmHGwijBuVehkPfbnoJyalYLSgMT.text)
    if 'error' in NdrmHGwijBuVehkPfbnoJyalYLSgMO:
     NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['error']=NdrmHGwijBuVehkPfbnoJyalYLSgMO.get('error').get('detail')
    return NdrmHGwijBuVehkPfbnoJyalYLSgzq
   for NdrmHGwijBuVehkPfbnoJyalYLSgMD in NdrmHGwijBuVehkPfbnoJyalYLSgMT.cookies:
    if NdrmHGwijBuVehkPfbnoJyalYLSgMD.name=='token':
     NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['token']=NdrmHGwijBuVehkPfbnoJyalYLSgMD.value
    elif NdrmHGwijBuVehkPfbnoJyalYLSgMD.name=='member_srl':
     NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['member_srl']=NdrmHGwijBuVehkPfbnoJyalYLSgMD.value
    elif NdrmHGwijBuVehkPfbnoJyalYLSgMD.name=='bm_sv':
     NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['bm_sv'] =NdrmHGwijBuVehkPfbnoJyalYLSgMD.value
     NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['bm_sv_ex']=NdrmHGwijBuVehkPfbnoJyalYLSgMD.expires 
  except NdrmHGwijBuVehkPfbnoJyalYLSgzt as exception:
   NdrmHGwijBuVehkPfbnoJyalYLSgzc(exception)
   return NdrmHGwijBuVehkPfbnoJyalYLSgzq
  NdrmHGwijBuVehkPfbnoJyalYLSgKx.Save_session_acount(userid,userpw,NdrmHGwijBuVehkPfbnoJyalYLSgMq)
  return NdrmHGwijBuVehkPfbnoJyalYLSgzp
 def Get_CP_profile(NdrmHGwijBuVehkPfbnoJyalYLSgKx,NdrmHGwijBuVehkPfbnoJyalYLSgMq,limit_days=1,re_check=NdrmHGwijBuVehkPfbnoJyalYLSgzq):
  if re_check==NdrmHGwijBuVehkPfbnoJyalYLSgzp:
   if NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['bm_sv_ex']>NdrmHGwijBuVehkPfbnoJyalYLSgzR(time.time()):
    NdrmHGwijBuVehkPfbnoJyalYLSgzc('bm_sv_ex ok')
    return NdrmHGwijBuVehkPfbnoJyalYLSgzp
  try:
   NdrmHGwijBuVehkPfbnoJyalYLSgMz=NdrmHGwijBuVehkPfbnoJyalYLSgKx.API_DOMAIN+'/api/profiles'
   NdrmHGwijBuVehkPfbnoJyalYLSgKt,NdrmHGwijBuVehkPfbnoJyalYLSgKv,NdrmHGwijBuVehkPfbnoJyalYLSgKp=NdrmHGwijBuVehkPfbnoJyalYLSgKx.Make_authHeader()
   NdrmHGwijBuVehkPfbnoJyalYLSgMU={'traceparent':NdrmHGwijBuVehkPfbnoJyalYLSgKt,'tracestate':NdrmHGwijBuVehkPfbnoJyalYLSgKv,'newrelic':NdrmHGwijBuVehkPfbnoJyalYLSgKp,}
   NdrmHGwijBuVehkPfbnoJyalYLSgMx=NdrmHGwijBuVehkPfbnoJyalYLSgKx.make_CP_DefaultCookies()
   NdrmHGwijBuVehkPfbnoJyalYLSgMT=NdrmHGwijBuVehkPfbnoJyalYLSgKx.callRequestCookies('Get',NdrmHGwijBuVehkPfbnoJyalYLSgMz,payload=NdrmHGwijBuVehkPfbnoJyalYLSgzF,params=NdrmHGwijBuVehkPfbnoJyalYLSgzF,headers=NdrmHGwijBuVehkPfbnoJyalYLSgMU,cookies=NdrmHGwijBuVehkPfbnoJyalYLSgMx,redirects=NdrmHGwijBuVehkPfbnoJyalYLSgzq)
   if NdrmHGwijBuVehkPfbnoJyalYLSgMT.status_code not in[200]:return NdrmHGwijBuVehkPfbnoJyalYLSgzq
   NdrmHGwijBuVehkPfbnoJyalYLSgMO=json.loads(NdrmHGwijBuVehkPfbnoJyalYLSgMT.text)
   NdrmHGwijBuVehkPfbnoJyalYLSgMF=0 
   for NdrmHGwijBuVehkPfbnoJyalYLSgMD in NdrmHGwijBuVehkPfbnoJyalYLSgMT.cookies:
    NdrmHGwijBuVehkPfbnoJyalYLSgzc(NdrmHGwijBuVehkPfbnoJyalYLSgMD.name)
    if NdrmHGwijBuVehkPfbnoJyalYLSgMD.name=='bm_sv':
     NdrmHGwijBuVehkPfbnoJyalYLSgMF=1
     NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['bm_sv'] =NdrmHGwijBuVehkPfbnoJyalYLSgMD.value
     NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['bm_sv_ex']=NdrmHGwijBuVehkPfbnoJyalYLSgMD.expires 
   if NdrmHGwijBuVehkPfbnoJyalYLSgMF==0:
    NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['bm_sv_ex']=NdrmHGwijBuVehkPfbnoJyalYLSgzR(time.time())+60*60*2 
   NdrmHGwijBuVehkPfbnoJyalYLSgMq=NdrmHGwijBuVehkPfbnoJyalYLSgMO.get('data')[NdrmHGwijBuVehkPfbnoJyalYLSgzR(NdrmHGwijBuVehkPfbnoJyalYLSgMq)]
   NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['accountId']=NdrmHGwijBuVehkPfbnoJyalYLSgMq.get('accountId')
   NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['profileId']=NdrmHGwijBuVehkPfbnoJyalYLSgMq.get('profileId')
  except NdrmHGwijBuVehkPfbnoJyalYLSgzt as exception:
   NdrmHGwijBuVehkPfbnoJyalYLSgzc(exception)
   return NdrmHGwijBuVehkPfbnoJyalYLSgzq
  if re_check==NdrmHGwijBuVehkPfbnoJyalYLSgzq:
   NdrmHGwijBuVehkPfbnoJyalYLSgMc =NdrmHGwijBuVehkPfbnoJyalYLSgKx.Get_Now_Datetime()
   NdrmHGwijBuVehkPfbnoJyalYLSgMI=NdrmHGwijBuVehkPfbnoJyalYLSgMc+datetime.timedelta(days=limit_days)
   NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['limitdate']=NdrmHGwijBuVehkPfbnoJyalYLSgMI.strftime('%Y-%m-%d')
  else:
   NdrmHGwijBuVehkPfbnoJyalYLSgzc('re check')
  NdrmHGwijBuVehkPfbnoJyalYLSgKx.dic_To_jsonfile(NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP_COOKIE_FILENAME,NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP)
  return NdrmHGwijBuVehkPfbnoJyalYLSgzp
 def Get_Category_GroupList(NdrmHGwijBuVehkPfbnoJyalYLSgKx,vType):
  NdrmHGwijBuVehkPfbnoJyalYLSgMQ=[] 
  try:
   NdrmHGwijBuVehkPfbnoJyalYLSgMz=NdrmHGwijBuVehkPfbnoJyalYLSgKx.API_VIEWURL+'/v2/discover/feed' 
   NdrmHGwijBuVehkPfbnoJyalYLSgMR={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false',}
   NdrmHGwijBuVehkPfbnoJyalYLSgMT=NdrmHGwijBuVehkPfbnoJyalYLSgKx.callRequestCookies('Get',NdrmHGwijBuVehkPfbnoJyalYLSgMz,payload=NdrmHGwijBuVehkPfbnoJyalYLSgzF,params=NdrmHGwijBuVehkPfbnoJyalYLSgMR,headers=NdrmHGwijBuVehkPfbnoJyalYLSgzF,cookies=NdrmHGwijBuVehkPfbnoJyalYLSgzF,redirects=NdrmHGwijBuVehkPfbnoJyalYLSgzp)
   if NdrmHGwijBuVehkPfbnoJyalYLSgMT.status_code not in[200]:return[]
   NdrmHGwijBuVehkPfbnoJyalYLSgMO=json.loads(NdrmHGwijBuVehkPfbnoJyalYLSgMT.text)
   if vType in['TVSHOWS','MOVIES']:
    NdrmHGwijBuVehkPfbnoJyalYLSgMt='Explores' 
   elif vType in['EDUCATION']:
    NdrmHGwijBuVehkPfbnoJyalYLSgMt='Collection-Rails-Curation'
   elif vType in['ALL']:
    NdrmHGwijBuVehkPfbnoJyalYLSgMt='Explores-Categories'
   for NdrmHGwijBuVehkPfbnoJyalYLSgMv in NdrmHGwijBuVehkPfbnoJyalYLSgMO.get('data'):
    if NdrmHGwijBuVehkPfbnoJyalYLSgMv.get('type')==NdrmHGwijBuVehkPfbnoJyalYLSgMt:
     for NdrmHGwijBuVehkPfbnoJyalYLSgMp in NdrmHGwijBuVehkPfbnoJyalYLSgMv.get('data'):
      if vType in['TVSHOWS','MOVIES']:
       NdrmHGwijBuVehkPfbnoJyalYLSgMC=NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('collectionId')
      elif vType in['EDUCATION','ALL']:
       NdrmHGwijBuVehkPfbnoJyalYLSgMC=NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('id')
      NdrmHGwijBuVehkPfbnoJyalYLSgMA={'collectionId':NdrmHGwijBuVehkPfbnoJyalYLSgMC,'title':NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('name'),'category':NdrmHGwijBuVehkPfbnoJyalYLSgMv.get('category'),'pre_title':'',}
      NdrmHGwijBuVehkPfbnoJyalYLSgMQ.append(NdrmHGwijBuVehkPfbnoJyalYLSgMA)
     break
  except NdrmHGwijBuVehkPfbnoJyalYLSgzt as exception:
   NdrmHGwijBuVehkPfbnoJyalYLSgzc(exception)
   return[]
  return NdrmHGwijBuVehkPfbnoJyalYLSgMQ
 def Get_Category_List(NdrmHGwijBuVehkPfbnoJyalYLSgKx,vType,NdrmHGwijBuVehkPfbnoJyalYLSgMC,page_int):
  NdrmHGwijBuVehkPfbnoJyalYLSgMQ=[] 
  NdrmHGwijBuVehkPfbnoJyalYLSgxK=NdrmHGwijBuVehkPfbnoJyalYLSgzq
  try:
   if vType=='ALL':
    NdrmHGwijBuVehkPfbnoJyalYLSgMU={'x-membersrl':NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['member_srl'],'x-pcid':NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['PCID'],'x-profileid':NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['profileId'],}
    NdrmHGwijBuVehkPfbnoJyalYLSgMR={'platform':'WEBCLIENT','page':NdrmHGwijBuVehkPfbnoJyalYLSgzI(page_int),'perPage':NdrmHGwijBuVehkPfbnoJyalYLSgzI(NdrmHGwijBuVehkPfbnoJyalYLSgKx.PAGE_LIMIT),'locale':'ko','sort':'',}
    NdrmHGwijBuVehkPfbnoJyalYLSgMz=NdrmHGwijBuVehkPfbnoJyalYLSgKx.API_VIEWURL+'/v1/discover/categories/'+NdrmHGwijBuVehkPfbnoJyalYLSgMC+'/titles'
    NdrmHGwijBuVehkPfbnoJyalYLSgMT=NdrmHGwijBuVehkPfbnoJyalYLSgKx.callRequestCookies('Get',NdrmHGwijBuVehkPfbnoJyalYLSgMz,payload=NdrmHGwijBuVehkPfbnoJyalYLSgzF,params=NdrmHGwijBuVehkPfbnoJyalYLSgMR,headers=NdrmHGwijBuVehkPfbnoJyalYLSgMU,cookies=NdrmHGwijBuVehkPfbnoJyalYLSgzF,redirects=NdrmHGwijBuVehkPfbnoJyalYLSgzp)
   else: 
    NdrmHGwijBuVehkPfbnoJyalYLSgMR={'platform':'WEBCLIENT','page':NdrmHGwijBuVehkPfbnoJyalYLSgzI(page_int),'perPage':NdrmHGwijBuVehkPfbnoJyalYLSgzI(NdrmHGwijBuVehkPfbnoJyalYLSgKx.PAGE_LIMIT),}
    NdrmHGwijBuVehkPfbnoJyalYLSgMz=NdrmHGwijBuVehkPfbnoJyalYLSgKx.API_VIEWURL+'/v1/discover/collections/'+NdrmHGwijBuVehkPfbnoJyalYLSgMC+'/titles'
    NdrmHGwijBuVehkPfbnoJyalYLSgMT=NdrmHGwijBuVehkPfbnoJyalYLSgKx.callRequestCookies('Get',NdrmHGwijBuVehkPfbnoJyalYLSgMz,payload=NdrmHGwijBuVehkPfbnoJyalYLSgzF,params=NdrmHGwijBuVehkPfbnoJyalYLSgMR,headers=NdrmHGwijBuVehkPfbnoJyalYLSgzF,cookies=NdrmHGwijBuVehkPfbnoJyalYLSgzF,redirects=NdrmHGwijBuVehkPfbnoJyalYLSgzp)
   if NdrmHGwijBuVehkPfbnoJyalYLSgMT.status_code not in[200]:return[],NdrmHGwijBuVehkPfbnoJyalYLSgzq
   NdrmHGwijBuVehkPfbnoJyalYLSgMO=json.loads(NdrmHGwijBuVehkPfbnoJyalYLSgMT.text)
   if vType=='ALL':
    NdrmHGwijBuVehkPfbnoJyalYLSgxM=NdrmHGwijBuVehkPfbnoJyalYLSgMO.get('data').get('data')
   else:
    NdrmHGwijBuVehkPfbnoJyalYLSgxM=NdrmHGwijBuVehkPfbnoJyalYLSgMO.get('data')
   for NdrmHGwijBuVehkPfbnoJyalYLSgMp in NdrmHGwijBuVehkPfbnoJyalYLSgxM:
    NdrmHGwijBuVehkPfbnoJyalYLSgxz=NdrmHGwijBuVehkPfbnoJyalYLSgxW=NdrmHGwijBuVehkPfbnoJyalYLSgzX=NdrmHGwijBuVehkPfbnoJyalYLSgzs=''
    if 'poster' in NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('images'):NdrmHGwijBuVehkPfbnoJyalYLSgxz =NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('images').get('poster').get('url')
    if 'story-art' in NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('images'):NdrmHGwijBuVehkPfbnoJyalYLSgxW =NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('images').get('story-art').get('url')
    if 'title-treatment' in NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('images'):NdrmHGwijBuVehkPfbnoJyalYLSgzX=NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('images').get('title-treatment').get('url')
    if 'story-art' in NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('images'):NdrmHGwijBuVehkPfbnoJyalYLSgzs =NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('images').get('story-art').get('url')
    NdrmHGwijBuVehkPfbnoJyalYLSgxT=''
    if NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('badge')not in[{},NdrmHGwijBuVehkPfbnoJyalYLSgzF]:
     for i in NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('badge').get('text'):
      NdrmHGwijBuVehkPfbnoJyalYLSgxT+=i.get('text')
    NdrmHGwijBuVehkPfbnoJyalYLSgxD=''
    if NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('seasonList')!=NdrmHGwijBuVehkPfbnoJyalYLSgzF:
     NdrmHGwijBuVehkPfbnoJyalYLSgxD=','.join(NdrmHGwijBuVehkPfbnoJyalYLSgzI(e)for e in NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('seasonList'))
    NdrmHGwijBuVehkPfbnoJyalYLSgxs =[]
    for NdrmHGwijBuVehkPfbnoJyalYLSgxX in NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('tags'):
     NdrmHGwijBuVehkPfbnoJyalYLSgxs.append(NdrmHGwijBuVehkPfbnoJyalYLSgxX.get('tag'))
    NdrmHGwijBuVehkPfbnoJyalYLSgMA={'id':NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('id'),'title':NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('title'),'thumbnail':{'poster':NdrmHGwijBuVehkPfbnoJyalYLSgxz,'thumb':NdrmHGwijBuVehkPfbnoJyalYLSgxW,'clearlogo':NdrmHGwijBuVehkPfbnoJyalYLSgzX,'fanart':NdrmHGwijBuVehkPfbnoJyalYLSgzs},'mpaa':NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('age_rating'),'duration':NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('running_time'),'asis':NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('as'),'badge':NdrmHGwijBuVehkPfbnoJyalYLSgxT,'year':NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('meta').get('releaseYear'),'seasonList':NdrmHGwijBuVehkPfbnoJyalYLSgxD,'genreList':NdrmHGwijBuVehkPfbnoJyalYLSgxs,}
    NdrmHGwijBuVehkPfbnoJyalYLSgMQ.append(NdrmHGwijBuVehkPfbnoJyalYLSgMA)
   if NdrmHGwijBuVehkPfbnoJyalYLSgMO.get('pagination').get('totalPages')>page_int:
    NdrmHGwijBuVehkPfbnoJyalYLSgxK=NdrmHGwijBuVehkPfbnoJyalYLSgzp
  except NdrmHGwijBuVehkPfbnoJyalYLSgzt as exception:
   NdrmHGwijBuVehkPfbnoJyalYLSgzc(exception)
   return[],NdrmHGwijBuVehkPfbnoJyalYLSgzq
  return NdrmHGwijBuVehkPfbnoJyalYLSgMQ,NdrmHGwijBuVehkPfbnoJyalYLSgxK
 def Get_Episode_List(NdrmHGwijBuVehkPfbnoJyalYLSgKx,programId,season):
  NdrmHGwijBuVehkPfbnoJyalYLSgMQ=[] 
  try:
   NdrmHGwijBuVehkPfbnoJyalYLSgMz=NdrmHGwijBuVehkPfbnoJyalYLSgKx.API_VIEWURL+'/v1/discover/titles/'+programId+'/episodes'
   NdrmHGwijBuVehkPfbnoJyalYLSgMR={'season':season,'sort':'true','locale':'ko',}
   NdrmHGwijBuVehkPfbnoJyalYLSgMT=NdrmHGwijBuVehkPfbnoJyalYLSgKx.callRequestCookies('Get',NdrmHGwijBuVehkPfbnoJyalYLSgMz,payload=NdrmHGwijBuVehkPfbnoJyalYLSgzF,params=NdrmHGwijBuVehkPfbnoJyalYLSgMR,headers=NdrmHGwijBuVehkPfbnoJyalYLSgzF,cookies=NdrmHGwijBuVehkPfbnoJyalYLSgzF,redirects=NdrmHGwijBuVehkPfbnoJyalYLSgzp)
   if NdrmHGwijBuVehkPfbnoJyalYLSgMT.status_code not in[200]:return[]
   NdrmHGwijBuVehkPfbnoJyalYLSgMO=json.loads(NdrmHGwijBuVehkPfbnoJyalYLSgMT.text)
   for NdrmHGwijBuVehkPfbnoJyalYLSgMp in NdrmHGwijBuVehkPfbnoJyalYLSgMO.get('data'):
    NdrmHGwijBuVehkPfbnoJyalYLSgxW=''
    if 'story-art' in NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('images'):NdrmHGwijBuVehkPfbnoJyalYLSgxW =NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('images').get('story-art').get('url')
    NdrmHGwijBuVehkPfbnoJyalYLSgxs =[]
    for NdrmHGwijBuVehkPfbnoJyalYLSgxX in NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('tags'):
     NdrmHGwijBuVehkPfbnoJyalYLSgxs.append(NdrmHGwijBuVehkPfbnoJyalYLSgxX.get('tag'))
    NdrmHGwijBuVehkPfbnoJyalYLSgMA={'id':NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('id'),'title':NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('title'),'thumbnail':{'thumb':NdrmHGwijBuVehkPfbnoJyalYLSgxW,'fanart':NdrmHGwijBuVehkPfbnoJyalYLSgxW},'mpaa':NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('age_rating'),'duration':NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('running_time'),'asis':NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('as'),'year':NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('meta').get('releaseYear'),'episode':NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('episode'),'genreList':NdrmHGwijBuVehkPfbnoJyalYLSgxs,'desc':NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('description'),}
    NdrmHGwijBuVehkPfbnoJyalYLSgMQ.append(NdrmHGwijBuVehkPfbnoJyalYLSgMA)
  except NdrmHGwijBuVehkPfbnoJyalYLSgzt as exception:
   NdrmHGwijBuVehkPfbnoJyalYLSgzc(exception)
   return[]
  return NdrmHGwijBuVehkPfbnoJyalYLSgMQ
 def Get_vInfo(NdrmHGwijBuVehkPfbnoJyalYLSgKx,titleId):
  try:
   NdrmHGwijBuVehkPfbnoJyalYLSgMz=NdrmHGwijBuVehkPfbnoJyalYLSgKx.API_VIEWURL+'/v1/discover/titles/'+titleId 
   NdrmHGwijBuVehkPfbnoJyalYLSgMR={'locale':'ko'}
   NdrmHGwijBuVehkPfbnoJyalYLSgMT=NdrmHGwijBuVehkPfbnoJyalYLSgKx.callRequestCookies('Get',NdrmHGwijBuVehkPfbnoJyalYLSgMz,payload=NdrmHGwijBuVehkPfbnoJyalYLSgzF,params=NdrmHGwijBuVehkPfbnoJyalYLSgMR,headers=NdrmHGwijBuVehkPfbnoJyalYLSgzF,cookies=NdrmHGwijBuVehkPfbnoJyalYLSgzF,redirects=NdrmHGwijBuVehkPfbnoJyalYLSgzp)
   if NdrmHGwijBuVehkPfbnoJyalYLSgMT.status_code not in[200]:return '','',''
   NdrmHGwijBuVehkPfbnoJyalYLSgMO=json.loads(NdrmHGwijBuVehkPfbnoJyalYLSgMT.text).get('data')
   NdrmHGwijBuVehkPfbnoJyalYLSgxD=''
   if NdrmHGwijBuVehkPfbnoJyalYLSgMO.get('seasonList')!=NdrmHGwijBuVehkPfbnoJyalYLSgzF:
    NdrmHGwijBuVehkPfbnoJyalYLSgxD=','.join(NdrmHGwijBuVehkPfbnoJyalYLSgzI(e)for e in NdrmHGwijBuVehkPfbnoJyalYLSgMO.get('seasonList'))
   NdrmHGwijBuVehkPfbnoJyalYLSgxU={'age_rating':NdrmHGwijBuVehkPfbnoJyalYLSgMO.get('age_rating'),'asset_id':NdrmHGwijBuVehkPfbnoJyalYLSgMO.get('asset_id'),'availability':NdrmHGwijBuVehkPfbnoJyalYLSgMO.get('availability'),'deal_id':NdrmHGwijBuVehkPfbnoJyalYLSgMO.get('deal_id'),'downloadable':'true' if NdrmHGwijBuVehkPfbnoJyalYLSgMO.get('downloadable')else 'false','region':NdrmHGwijBuVehkPfbnoJyalYLSgMO.get('region'),'streamable':'true' if NdrmHGwijBuVehkPfbnoJyalYLSgMO.get('streamable')else 'false','asis':NdrmHGwijBuVehkPfbnoJyalYLSgMO.get('as'),'seasonList':NdrmHGwijBuVehkPfbnoJyalYLSgxD}
  except NdrmHGwijBuVehkPfbnoJyalYLSgzt as exception:
   NdrmHGwijBuVehkPfbnoJyalYLSgzc(exception)
   return{}
  return NdrmHGwijBuVehkPfbnoJyalYLSgxU
 def Get_eInfo(NdrmHGwijBuVehkPfbnoJyalYLSgKx,eventId):
  try:
   NdrmHGwijBuVehkPfbnoJyalYLSgMz=NdrmHGwijBuVehkPfbnoJyalYLSgKx.API_VIEWURL+'/v1/discover/events/'+eventId 
   NdrmHGwijBuVehkPfbnoJyalYLSgMR={'locale':'ko'}
   NdrmHGwijBuVehkPfbnoJyalYLSgMT=NdrmHGwijBuVehkPfbnoJyalYLSgKx.callRequestCookies('Get',NdrmHGwijBuVehkPfbnoJyalYLSgMz,payload=NdrmHGwijBuVehkPfbnoJyalYLSgzF,params=NdrmHGwijBuVehkPfbnoJyalYLSgMR,headers=NdrmHGwijBuVehkPfbnoJyalYLSgzF,cookies=NdrmHGwijBuVehkPfbnoJyalYLSgzF,redirects=NdrmHGwijBuVehkPfbnoJyalYLSgzp)
   if NdrmHGwijBuVehkPfbnoJyalYLSgMT.status_code not in[200]:return '','',''
   NdrmHGwijBuVehkPfbnoJyalYLSgMO=json.loads(NdrmHGwijBuVehkPfbnoJyalYLSgMT.text).get('data')
   NdrmHGwijBuVehkPfbnoJyalYLSgxU={'asset_id':NdrmHGwijBuVehkPfbnoJyalYLSgMO.get('asset_id'),'deal_id':NdrmHGwijBuVehkPfbnoJyalYLSgMO.get('deal_id'),'region':NdrmHGwijBuVehkPfbnoJyalYLSgMO.get('region'),'streamable':'true' if NdrmHGwijBuVehkPfbnoJyalYLSgMO.get('streamable')else 'false',}
  except NdrmHGwijBuVehkPfbnoJyalYLSgzt as exception:
   NdrmHGwijBuVehkPfbnoJyalYLSgzc(exception)
   return{}
  return NdrmHGwijBuVehkPfbnoJyalYLSgxU
 def GetBroadURL(NdrmHGwijBuVehkPfbnoJyalYLSgKx,titleId):
  NdrmHGwijBuVehkPfbnoJyalYLSgxE=''
  NdrmHGwijBuVehkPfbnoJyalYLSgxO =''
  NdrmHGwijBuVehkPfbnoJyalYLSgxU=NdrmHGwijBuVehkPfbnoJyalYLSgKx.Get_vInfo(titleId)
  if NdrmHGwijBuVehkPfbnoJyalYLSgxU=={}:return '',''
  try:
   NdrmHGwijBuVehkPfbnoJyalYLSgMz=NdrmHGwijBuVehkPfbnoJyalYLSgKx.API_DOMAIN+'/api/playback/play' 
   NdrmHGwijBuVehkPfbnoJyalYLSgMR={'titleId':titleId}
   NdrmHGwijBuVehkPfbnoJyalYLSgKt,NdrmHGwijBuVehkPfbnoJyalYLSgKv,NdrmHGwijBuVehkPfbnoJyalYLSgKp=NdrmHGwijBuVehkPfbnoJyalYLSgKx.Make_authHeader()
   NdrmHGwijBuVehkPfbnoJyalYLSgMU={'traceparent':NdrmHGwijBuVehkPfbnoJyalYLSgKt,'tracestate':NdrmHGwijBuVehkPfbnoJyalYLSgKv,'newrelic':NdrmHGwijBuVehkPfbnoJyalYLSgKp,'x-force-raw':'true','x-pcid':NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':NdrmHGwijBuVehkPfbnoJyalYLSgxU.get('age_rating'),'x-title-availability':NdrmHGwijBuVehkPfbnoJyalYLSgxU.get('availability'),'x-title-brightcove-id':NdrmHGwijBuVehkPfbnoJyalYLSgxU.get('asset_id'),'x-title-deal-id':NdrmHGwijBuVehkPfbnoJyalYLSgxU.get('deal_id'),'x-title-downloadable':NdrmHGwijBuVehkPfbnoJyalYLSgxU.get('downloadable'),'x-title-region':NdrmHGwijBuVehkPfbnoJyalYLSgxU.get('region'),'x-title-streamable':NdrmHGwijBuVehkPfbnoJyalYLSgxU.get('streamable'),}
   NdrmHGwijBuVehkPfbnoJyalYLSgMx=NdrmHGwijBuVehkPfbnoJyalYLSgKx.make_CP_DefaultCookies()
   NdrmHGwijBuVehkPfbnoJyalYLSgMT=NdrmHGwijBuVehkPfbnoJyalYLSgKx.callRequestCookies('Get',NdrmHGwijBuVehkPfbnoJyalYLSgMz,payload=NdrmHGwijBuVehkPfbnoJyalYLSgzF,params=NdrmHGwijBuVehkPfbnoJyalYLSgMR,headers=NdrmHGwijBuVehkPfbnoJyalYLSgMU,cookies=NdrmHGwijBuVehkPfbnoJyalYLSgMx,redirects=NdrmHGwijBuVehkPfbnoJyalYLSgzp)
   if NdrmHGwijBuVehkPfbnoJyalYLSgMT.status_code not in[200]:return '',json.loads(NdrmHGwijBuVehkPfbnoJyalYLSgMT.text).get('error').get('detail')
   NdrmHGwijBuVehkPfbnoJyalYLSgMO=json.loads(NdrmHGwijBuVehkPfbnoJyalYLSgMT.text)
   for NdrmHGwijBuVehkPfbnoJyalYLSgMp in NdrmHGwijBuVehkPfbnoJyalYLSgMO.get('data').get('raw').get('sources'):
    if NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('type')=='application/dash+xml' and NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('src')[0:8]=='https://':
     NdrmHGwijBuVehkPfbnoJyalYLSgxE=NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('src')
     if 'key_systems' in NdrmHGwijBuVehkPfbnoJyalYLSgMp:
      NdrmHGwijBuVehkPfbnoJyalYLSgxO =NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('key_systems').get('com.widevine.alpha').get('license_url')
     break
  except NdrmHGwijBuVehkPfbnoJyalYLSgzt as exception:
   NdrmHGwijBuVehkPfbnoJyalYLSgzc(exception)
   return '',''
  return NdrmHGwijBuVehkPfbnoJyalYLSgxE,NdrmHGwijBuVehkPfbnoJyalYLSgxO
 def GetEventURL(NdrmHGwijBuVehkPfbnoJyalYLSgKx,eventId,NdrmHGwijBuVehkPfbnoJyalYLSgzK):
  NdrmHGwijBuVehkPfbnoJyalYLSgxE=''
  NdrmHGwijBuVehkPfbnoJyalYLSgxO =''
  NdrmHGwijBuVehkPfbnoJyalYLSgxU=NdrmHGwijBuVehkPfbnoJyalYLSgKx.Get_eInfo(eventId)
  if NdrmHGwijBuVehkPfbnoJyalYLSgxU=={}:return '',''
  try:
   NdrmHGwijBuVehkPfbnoJyalYLSgMz=NdrmHGwijBuVehkPfbnoJyalYLSgKx.API_DOMAIN+'/api/playback/play' 
   NdrmHGwijBuVehkPfbnoJyalYLSgMR={'titleId':eventId,'titleType':NdrmHGwijBuVehkPfbnoJyalYLSgzK,}
   NdrmHGwijBuVehkPfbnoJyalYLSgKt,NdrmHGwijBuVehkPfbnoJyalYLSgKv,NdrmHGwijBuVehkPfbnoJyalYLSgKp=NdrmHGwijBuVehkPfbnoJyalYLSgKx.Make_authHeader()
   NdrmHGwijBuVehkPfbnoJyalYLSgMU={'traceparent':NdrmHGwijBuVehkPfbnoJyalYLSgKt,'tracestate':NdrmHGwijBuVehkPfbnoJyalYLSgKv,'newrelic':NdrmHGwijBuVehkPfbnoJyalYLSgKp,'x-force-raw':'true','x-pcid':NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':NdrmHGwijBuVehkPfbnoJyalYLSgxU.get('asset_id'),'x-title-deal-id':NdrmHGwijBuVehkPfbnoJyalYLSgxU.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':NdrmHGwijBuVehkPfbnoJyalYLSgxU.get('region'),'x-title-streamable':NdrmHGwijBuVehkPfbnoJyalYLSgxU.get('streamable'),}
   NdrmHGwijBuVehkPfbnoJyalYLSgMx=NdrmHGwijBuVehkPfbnoJyalYLSgKx.make_CP_DefaultCookies()
   NdrmHGwijBuVehkPfbnoJyalYLSgMT=NdrmHGwijBuVehkPfbnoJyalYLSgKx.callRequestCookies('Get',NdrmHGwijBuVehkPfbnoJyalYLSgMz,payload=NdrmHGwijBuVehkPfbnoJyalYLSgzF,params=NdrmHGwijBuVehkPfbnoJyalYLSgMR,headers=NdrmHGwijBuVehkPfbnoJyalYLSgMU,cookies=NdrmHGwijBuVehkPfbnoJyalYLSgMx,redirects=NdrmHGwijBuVehkPfbnoJyalYLSgzp)
   if NdrmHGwijBuVehkPfbnoJyalYLSgMT.status_code not in[200]:return '',json.loads(NdrmHGwijBuVehkPfbnoJyalYLSgMT.text).get('error').get('detail')
   NdrmHGwijBuVehkPfbnoJyalYLSgMO=json.loads(NdrmHGwijBuVehkPfbnoJyalYLSgMT.text)
   for NdrmHGwijBuVehkPfbnoJyalYLSgMp in NdrmHGwijBuVehkPfbnoJyalYLSgMO.get('data').get('raw').get('sources'):
    if NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('type')=='application/dash+xml' and NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('src')[0:8]=='https://':
     NdrmHGwijBuVehkPfbnoJyalYLSgxE=NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('src')
     if 'key_systems' in NdrmHGwijBuVehkPfbnoJyalYLSgMp:
      NdrmHGwijBuVehkPfbnoJyalYLSgxO =NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('key_systems').get('com.widevine.alpha').get('license_url')
     break
  except NdrmHGwijBuVehkPfbnoJyalYLSgzt as exception:
   NdrmHGwijBuVehkPfbnoJyalYLSgzc(exception)
   return '',''
  return NdrmHGwijBuVehkPfbnoJyalYLSgxE,NdrmHGwijBuVehkPfbnoJyalYLSgxO
 def GetEventURL_Live(NdrmHGwijBuVehkPfbnoJyalYLSgKx,eventId,NdrmHGwijBuVehkPfbnoJyalYLSgzK):
  NdrmHGwijBuVehkPfbnoJyalYLSgxE=''
  NdrmHGwijBuVehkPfbnoJyalYLSgxO =''
  NdrmHGwijBuVehkPfbnoJyalYLSgxU=NdrmHGwijBuVehkPfbnoJyalYLSgKx.Get_eInfo(eventId)
  if NdrmHGwijBuVehkPfbnoJyalYLSgxU=={}:return '',''
  try:
   NdrmHGwijBuVehkPfbnoJyalYLSgMz=NdrmHGwijBuVehkPfbnoJyalYLSgKx.API_DOMAIN+'/api/playback/play' 
   NdrmHGwijBuVehkPfbnoJyalYLSgMR={'titleId':eventId,'titleType':NdrmHGwijBuVehkPfbnoJyalYLSgzK,}
   NdrmHGwijBuVehkPfbnoJyalYLSgKt,NdrmHGwijBuVehkPfbnoJyalYLSgKv,NdrmHGwijBuVehkPfbnoJyalYLSgKp=NdrmHGwijBuVehkPfbnoJyalYLSgKx.Make_authHeader()
   NdrmHGwijBuVehkPfbnoJyalYLSgMU={'traceparent':NdrmHGwijBuVehkPfbnoJyalYLSgKt,'tracestate':NdrmHGwijBuVehkPfbnoJyalYLSgKv,'newrelic':NdrmHGwijBuVehkPfbnoJyalYLSgKp,'x-force-raw':'true','x-pcid':NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':NdrmHGwijBuVehkPfbnoJyalYLSgxU.get('asset_id'),'x-title-deal-id':NdrmHGwijBuVehkPfbnoJyalYLSgxU.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':NdrmHGwijBuVehkPfbnoJyalYLSgxU.get('region'),'x-title-streamable':NdrmHGwijBuVehkPfbnoJyalYLSgxU.get('streamable'),}
   NdrmHGwijBuVehkPfbnoJyalYLSgMx=NdrmHGwijBuVehkPfbnoJyalYLSgKx.make_CP_DefaultCookies()
   NdrmHGwijBuVehkPfbnoJyalYLSgMT=NdrmHGwijBuVehkPfbnoJyalYLSgKx.callRequestCookies('Get',NdrmHGwijBuVehkPfbnoJyalYLSgMz,payload=NdrmHGwijBuVehkPfbnoJyalYLSgzF,params=NdrmHGwijBuVehkPfbnoJyalYLSgMR,headers=NdrmHGwijBuVehkPfbnoJyalYLSgMU,cookies=NdrmHGwijBuVehkPfbnoJyalYLSgMx,redirects=NdrmHGwijBuVehkPfbnoJyalYLSgzp)
   if NdrmHGwijBuVehkPfbnoJyalYLSgMT.status_code not in[200]:return '',json.loads(NdrmHGwijBuVehkPfbnoJyalYLSgMT.text).get('error').get('detail')
   NdrmHGwijBuVehkPfbnoJyalYLSgMO=json.loads(NdrmHGwijBuVehkPfbnoJyalYLSgMT.text)
   for NdrmHGwijBuVehkPfbnoJyalYLSgMp in NdrmHGwijBuVehkPfbnoJyalYLSgMO.get('data').get('raw').get('sources'):
    if 'key_systems' in NdrmHGwijBuVehkPfbnoJyalYLSgMp:
     if NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('type')=='application/dash+xml' and 'com.widevine.alpha' in NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('key_systems')and NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('src').startswith('https://')==NdrmHGwijBuVehkPfbnoJyalYLSgzp:
      NdrmHGwijBuVehkPfbnoJyalYLSgxE=NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('src')
      NdrmHGwijBuVehkPfbnoJyalYLSgxO =NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('key_systems').get('com.widevine.alpha').get('license_url')
   if NdrmHGwijBuVehkPfbnoJyalYLSgxE=='':
    for NdrmHGwijBuVehkPfbnoJyalYLSgMp in NdrmHGwijBuVehkPfbnoJyalYLSgMO.get('data').get('raw').get('sources'):
     if 'key_systems' in NdrmHGwijBuVehkPfbnoJyalYLSgMp:
      if NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('key_systems')and NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('src').startswith('https://')==NdrmHGwijBuVehkPfbnoJyalYLSgzp:
       NdrmHGwijBuVehkPfbnoJyalYLSgxE=NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('src')
       NdrmHGwijBuVehkPfbnoJyalYLSgxO =NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('key_systems').get('com.widevine.alpha').get('license_url')
   if NdrmHGwijBuVehkPfbnoJyalYLSgxE=='':
    for NdrmHGwijBuVehkPfbnoJyalYLSgMp in NdrmHGwijBuVehkPfbnoJyalYLSgMO.get('data').get('raw').get('sources'):
     if NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('type')=='application/dash+xml' and NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('src').startswith('https://')==NdrmHGwijBuVehkPfbnoJyalYLSgzp:
      NdrmHGwijBuVehkPfbnoJyalYLSgxE=NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('src')
   if NdrmHGwijBuVehkPfbnoJyalYLSgxE=='':
    for NdrmHGwijBuVehkPfbnoJyalYLSgMp in NdrmHGwijBuVehkPfbnoJyalYLSgMO.get('data').get('raw').get('sources'):
     if NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('type')=='application/x-mpegURL' and NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('src').startswith('https://')==NdrmHGwijBuVehkPfbnoJyalYLSgzp:
      NdrmHGwijBuVehkPfbnoJyalYLSgxE=NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('src')
  except NdrmHGwijBuVehkPfbnoJyalYLSgzt as exception:
   NdrmHGwijBuVehkPfbnoJyalYLSgzc(exception)
   return '',''
  return NdrmHGwijBuVehkPfbnoJyalYLSgxE,NdrmHGwijBuVehkPfbnoJyalYLSgxO
 def Get_Url_PostFix(NdrmHGwijBuVehkPfbnoJyalYLSgKx,in_url):
  NdrmHGwijBuVehkPfbnoJyalYLSgxF=urllib.parse.urlparse(in_url) 
  NdrmHGwijBuVehkPfbnoJyalYLSgxq =NdrmHGwijBuVehkPfbnoJyalYLSgxF.path.strip('/').split('/')
  NdrmHGwijBuVehkPfbnoJyalYLSgxc =NdrmHGwijBuVehkPfbnoJyalYLSgxq[NdrmHGwijBuVehkPfbnoJyalYLSgzC(NdrmHGwijBuVehkPfbnoJyalYLSgxq)-1]
  NdrmHGwijBuVehkPfbnoJyalYLSgxI=NdrmHGwijBuVehkPfbnoJyalYLSgxc.split('.')
  return NdrmHGwijBuVehkPfbnoJyalYLSgxI[NdrmHGwijBuVehkPfbnoJyalYLSgzC(NdrmHGwijBuVehkPfbnoJyalYLSgxI)-1]
 def Get_Theme_GroupList(NdrmHGwijBuVehkPfbnoJyalYLSgKx,vType):
  NdrmHGwijBuVehkPfbnoJyalYLSgMQ=[] 
  try:
   NdrmHGwijBuVehkPfbnoJyalYLSgMz=NdrmHGwijBuVehkPfbnoJyalYLSgKx.API_VIEWURL+'/v2/discover/feed' 
   NdrmHGwijBuVehkPfbnoJyalYLSgMR={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':NdrmHGwijBuVehkPfbnoJyalYLSgzI(NdrmHGwijBuVehkPfbnoJyalYLSgKx.PAGE_LIMIT),'filterRestrictedContent':'false',}
   NdrmHGwijBuVehkPfbnoJyalYLSgMT=NdrmHGwijBuVehkPfbnoJyalYLSgKx.callRequestCookies('Get',NdrmHGwijBuVehkPfbnoJyalYLSgMz,payload=NdrmHGwijBuVehkPfbnoJyalYLSgzF,params=NdrmHGwijBuVehkPfbnoJyalYLSgMR,headers=NdrmHGwijBuVehkPfbnoJyalYLSgzF,cookies=NdrmHGwijBuVehkPfbnoJyalYLSgzF,redirects=NdrmHGwijBuVehkPfbnoJyalYLSgzp)
   if NdrmHGwijBuVehkPfbnoJyalYLSgMT.status_code not in[200]:return[]
   NdrmHGwijBuVehkPfbnoJyalYLSgMO=json.loads(NdrmHGwijBuVehkPfbnoJyalYLSgMT.text)
   for NdrmHGwijBuVehkPfbnoJyalYLSgMp in NdrmHGwijBuVehkPfbnoJyalYLSgMO.get('data'):
    if NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('type')=='Title-Rails-Curation':
     NdrmHGwijBuVehkPfbnoJyalYLSgxQ =''
     NdrmHGwijBuVehkPfbnoJyalYLSgxR=7
     try:
      for i in NdrmHGwijBuVehkPfbnoJyalYLSgzA(NdrmHGwijBuVehkPfbnoJyalYLSgzC(NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('data'))):
       if i>=NdrmHGwijBuVehkPfbnoJyalYLSgxR:
        NdrmHGwijBuVehkPfbnoJyalYLSgxQ=NdrmHGwijBuVehkPfbnoJyalYLSgxQ+'...'
        break
       NdrmHGwijBuVehkPfbnoJyalYLSgxQ=NdrmHGwijBuVehkPfbnoJyalYLSgxQ+NdrmHGwijBuVehkPfbnoJyalYLSgMp['data'][i]['title']+'\n'
     except NdrmHGwijBuVehkPfbnoJyalYLSgzt as exception:
      NdrmHGwijBuVehkPfbnoJyalYLSgzc(exception)
     NdrmHGwijBuVehkPfbnoJyalYLSgMA={'collectionId':NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('obj_id'),'title':NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('row_name'),'category':NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('category'),'pre_title':NdrmHGwijBuVehkPfbnoJyalYLSgxQ,}
     NdrmHGwijBuVehkPfbnoJyalYLSgMQ.append(NdrmHGwijBuVehkPfbnoJyalYLSgMA)
  except NdrmHGwijBuVehkPfbnoJyalYLSgzt as exception:
   NdrmHGwijBuVehkPfbnoJyalYLSgzc(exception)
   return[]
  return NdrmHGwijBuVehkPfbnoJyalYLSgMQ
 def Get_Event_GroupList(NdrmHGwijBuVehkPfbnoJyalYLSgKx):
  NdrmHGwijBuVehkPfbnoJyalYLSgMQ=[] 
  try:
   NdrmHGwijBuVehkPfbnoJyalYLSgMz=NdrmHGwijBuVehkPfbnoJyalYLSgKx.API_VIEWURL+'/v2/discover/feed' 
   NdrmHGwijBuVehkPfbnoJyalYLSgMR={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':7,'filterRestrictedContent':'false',}
   NdrmHGwijBuVehkPfbnoJyalYLSgMT=NdrmHGwijBuVehkPfbnoJyalYLSgKx.callRequestCookies('Get',NdrmHGwijBuVehkPfbnoJyalYLSgMz,payload=NdrmHGwijBuVehkPfbnoJyalYLSgzF,params=NdrmHGwijBuVehkPfbnoJyalYLSgMR,headers=NdrmHGwijBuVehkPfbnoJyalYLSgzF,cookies=NdrmHGwijBuVehkPfbnoJyalYLSgzF,redirects=NdrmHGwijBuVehkPfbnoJyalYLSgzp)
   if NdrmHGwijBuVehkPfbnoJyalYLSgMT.status_code not in[200]:return[]
   NdrmHGwijBuVehkPfbnoJyalYLSgMO=json.loads(NdrmHGwijBuVehkPfbnoJyalYLSgMT.text)
   for NdrmHGwijBuVehkPfbnoJyalYLSgMp in NdrmHGwijBuVehkPfbnoJyalYLSgMO.get('data'):
    if NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('row_name').strip()!='':
     NdrmHGwijBuVehkPfbnoJyalYLSgxQ =''
     NdrmHGwijBuVehkPfbnoJyalYLSgxR=7
     try:
      for i in NdrmHGwijBuVehkPfbnoJyalYLSgzA(NdrmHGwijBuVehkPfbnoJyalYLSgzC(NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('data'))):
       if i>=NdrmHGwijBuVehkPfbnoJyalYLSgxR:
        NdrmHGwijBuVehkPfbnoJyalYLSgxQ=NdrmHGwijBuVehkPfbnoJyalYLSgxQ+'...'
        break
       NdrmHGwijBuVehkPfbnoJyalYLSgxQ=NdrmHGwijBuVehkPfbnoJyalYLSgxQ+NdrmHGwijBuVehkPfbnoJyalYLSgMp['data'][i]['title']+'\n'
     except NdrmHGwijBuVehkPfbnoJyalYLSgzt as exception:
      NdrmHGwijBuVehkPfbnoJyalYLSgzc(exception)
     NdrmHGwijBuVehkPfbnoJyalYLSgMA={'collectionId':NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('obj_id'),'title':NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('row_name'),'category':NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('type'),'pre_title':NdrmHGwijBuVehkPfbnoJyalYLSgxQ,}
     NdrmHGwijBuVehkPfbnoJyalYLSgMQ.append(NdrmHGwijBuVehkPfbnoJyalYLSgMA)
  except NdrmHGwijBuVehkPfbnoJyalYLSgzt as exception:
   NdrmHGwijBuVehkPfbnoJyalYLSgzc(exception)
   return[]
  return NdrmHGwijBuVehkPfbnoJyalYLSgMQ
 def Get_Event_GameList(NdrmHGwijBuVehkPfbnoJyalYLSgKx,NdrmHGwijBuVehkPfbnoJyalYLSgMC):
  NdrmHGwijBuVehkPfbnoJyalYLSgMQ=[] 
  try:
   NdrmHGwijBuVehkPfbnoJyalYLSgMz=NdrmHGwijBuVehkPfbnoJyalYLSgKx.API_VIEWURL+'/v2/discover/feed' 
   NdrmHGwijBuVehkPfbnoJyalYLSgMR={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false',}
   NdrmHGwijBuVehkPfbnoJyalYLSgMT=NdrmHGwijBuVehkPfbnoJyalYLSgKx.callRequestCookies('Get',NdrmHGwijBuVehkPfbnoJyalYLSgMz,payload=NdrmHGwijBuVehkPfbnoJyalYLSgzF,params=NdrmHGwijBuVehkPfbnoJyalYLSgMR,headers=NdrmHGwijBuVehkPfbnoJyalYLSgzF,cookies=NdrmHGwijBuVehkPfbnoJyalYLSgzF,redirects=NdrmHGwijBuVehkPfbnoJyalYLSgzp)
   if NdrmHGwijBuVehkPfbnoJyalYLSgMT.status_code not in[200]:return[]
   NdrmHGwijBuVehkPfbnoJyalYLSgMO=json.loads(NdrmHGwijBuVehkPfbnoJyalYLSgMT.text)
   for NdrmHGwijBuVehkPfbnoJyalYLSgMp in NdrmHGwijBuVehkPfbnoJyalYLSgMO.get('data'):
    if NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('obj_id')==NdrmHGwijBuVehkPfbnoJyalYLSgMC:
     for NdrmHGwijBuVehkPfbnoJyalYLSgxt in NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('data'):
      NdrmHGwijBuVehkPfbnoJyalYLSgxz=NdrmHGwijBuVehkPfbnoJyalYLSgxW=NdrmHGwijBuVehkPfbnoJyalYLSgzs=''
      if 'poster' in NdrmHGwijBuVehkPfbnoJyalYLSgxt.get('images'):NdrmHGwijBuVehkPfbnoJyalYLSgxz =NdrmHGwijBuVehkPfbnoJyalYLSgxt.get('images').get('poster').get('url')
      if 'story-art' in NdrmHGwijBuVehkPfbnoJyalYLSgxt.get('images'):NdrmHGwijBuVehkPfbnoJyalYLSgxW =NdrmHGwijBuVehkPfbnoJyalYLSgxt.get('images').get('story-art').get('url')
      if 'hero' in NdrmHGwijBuVehkPfbnoJyalYLSgxt.get('images'):NdrmHGwijBuVehkPfbnoJyalYLSgzs =NdrmHGwijBuVehkPfbnoJyalYLSgxt.get('images').get('hero').get('url')
      NdrmHGwijBuVehkPfbnoJyalYLSgxv=NdrmHGwijBuVehkPfbnoJyalYLSgxt.get('meta').get(NdrmHGwijBuVehkPfbnoJyalYLSgxt.get('category')).get(NdrmHGwijBuVehkPfbnoJyalYLSgxt.get('sub_category'))
      if 'league' in NdrmHGwijBuVehkPfbnoJyalYLSgxv:
       NdrmHGwijBuVehkPfbnoJyalYLSgxp=NdrmHGwijBuVehkPfbnoJyalYLSgxv.get('league')
      else:
       NdrmHGwijBuVehkPfbnoJyalYLSgxp=NdrmHGwijBuVehkPfbnoJyalYLSgxv.get('round')
      NdrmHGwijBuVehkPfbnoJyalYLSgMA={'id':NdrmHGwijBuVehkPfbnoJyalYLSgxt.get('id'),'title':NdrmHGwijBuVehkPfbnoJyalYLSgxt.get('title'),'thumbnail':{'poster':NdrmHGwijBuVehkPfbnoJyalYLSgxz,'thumb':NdrmHGwijBuVehkPfbnoJyalYLSgxW,'fanart':NdrmHGwijBuVehkPfbnoJyalYLSgzs},'asis':NdrmHGwijBuVehkPfbnoJyalYLSgxt.get('type'),'addInfo':NdrmHGwijBuVehkPfbnoJyalYLSgxp,'starttm':NdrmHGwijBuVehkPfbnoJyalYLSgKx.convert_TimeStr(NdrmHGwijBuVehkPfbnoJyalYLSgxt.get('start_at')),}
      NdrmHGwijBuVehkPfbnoJyalYLSgMQ.append(NdrmHGwijBuVehkPfbnoJyalYLSgMA)
  except NdrmHGwijBuVehkPfbnoJyalYLSgzt as exception:
   NdrmHGwijBuVehkPfbnoJyalYLSgzc(exception)
   return[]
  return NdrmHGwijBuVehkPfbnoJyalYLSgMQ
 def Get_Event_List(NdrmHGwijBuVehkPfbnoJyalYLSgKx,gameId):
  NdrmHGwijBuVehkPfbnoJyalYLSgMQ=[] 
  try:
   NdrmHGwijBuVehkPfbnoJyalYLSgMz=NdrmHGwijBuVehkPfbnoJyalYLSgKx.API_VIEWURL+'/v1/discover/events/'+gameId 
   NdrmHGwijBuVehkPfbnoJyalYLSgMR={'platform':'WEBCLIENT','locale':'ko','filterRestrictedContent':'false',}
   NdrmHGwijBuVehkPfbnoJyalYLSgMT=NdrmHGwijBuVehkPfbnoJyalYLSgKx.callRequestCookies('Get',NdrmHGwijBuVehkPfbnoJyalYLSgMz,payload=NdrmHGwijBuVehkPfbnoJyalYLSgzF,params=NdrmHGwijBuVehkPfbnoJyalYLSgMR,headers=NdrmHGwijBuVehkPfbnoJyalYLSgzF,cookies=NdrmHGwijBuVehkPfbnoJyalYLSgzF,redirects=NdrmHGwijBuVehkPfbnoJyalYLSgzp)
   if NdrmHGwijBuVehkPfbnoJyalYLSgMT.status_code not in[200]:return[]
   NdrmHGwijBuVehkPfbnoJyalYLSgMO=json.loads(NdrmHGwijBuVehkPfbnoJyalYLSgMT.text)
   NdrmHGwijBuVehkPfbnoJyalYLSgMp=NdrmHGwijBuVehkPfbnoJyalYLSgMO.get('data')
   NdrmHGwijBuVehkPfbnoJyalYLSgxC=NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('end_at')
   NdrmHGwijBuVehkPfbnoJyalYLSgxC=NdrmHGwijBuVehkPfbnoJyalYLSgxC[0:19].replace('-','').replace(':','').replace('T','')
   NdrmHGwijBuVehkPfbnoJyalYLSgxA=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d%H%M%S')
   if NdrmHGwijBuVehkPfbnoJyalYLSgzR(NdrmHGwijBuVehkPfbnoJyalYLSgxA)<NdrmHGwijBuVehkPfbnoJyalYLSgzR(NdrmHGwijBuVehkPfbnoJyalYLSgxC):
    NdrmHGwijBuVehkPfbnoJyalYLSgxz=NdrmHGwijBuVehkPfbnoJyalYLSgxW=NdrmHGwijBuVehkPfbnoJyalYLSgzs=''
    if 'poster' in NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('images'):NdrmHGwijBuVehkPfbnoJyalYLSgxz =NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('images').get('poster').get('url')
    if 'story-art' in NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('images'):NdrmHGwijBuVehkPfbnoJyalYLSgxW =NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('images').get('story-art').get('url')
    if 'story-art' in NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('images'):NdrmHGwijBuVehkPfbnoJyalYLSgzs =NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('images').get('story-art').get('url')
    NdrmHGwijBuVehkPfbnoJyalYLSgMA={'id':NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('id'),'title':NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('title'),'thumbnail':{'poster':NdrmHGwijBuVehkPfbnoJyalYLSgxz,'thumb':NdrmHGwijBuVehkPfbnoJyalYLSgxW,'fanart':NdrmHGwijBuVehkPfbnoJyalYLSgzs},'duration':NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('running_time'),'asis':NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('type'),'starttm':NdrmHGwijBuVehkPfbnoJyalYLSgKx.convert_TimeStr(NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('start_at')),}
    NdrmHGwijBuVehkPfbnoJyalYLSgMQ.append(NdrmHGwijBuVehkPfbnoJyalYLSgMA)
  except NdrmHGwijBuVehkPfbnoJyalYLSgzt as exception:
   NdrmHGwijBuVehkPfbnoJyalYLSgzc(exception)
   return[]
  try:
   NdrmHGwijBuVehkPfbnoJyalYLSgMz=NdrmHGwijBuVehkPfbnoJyalYLSgKx.API_VIEWURL+'/v1/discover/events/'+gameId+'/related' 
   NdrmHGwijBuVehkPfbnoJyalYLSgMR={'locale':'ko','page':'1','perPage':'25','platform':'WEBCLIENT','currentPageTracking':'page_discover_title_detail',}
   NdrmHGwijBuVehkPfbnoJyalYLSgMT=NdrmHGwijBuVehkPfbnoJyalYLSgKx.callRequestCookies('Get',NdrmHGwijBuVehkPfbnoJyalYLSgMz,payload=NdrmHGwijBuVehkPfbnoJyalYLSgzF,params=NdrmHGwijBuVehkPfbnoJyalYLSgMR,headers=NdrmHGwijBuVehkPfbnoJyalYLSgzF,cookies=NdrmHGwijBuVehkPfbnoJyalYLSgzF,redirects=NdrmHGwijBuVehkPfbnoJyalYLSgzp)
   if NdrmHGwijBuVehkPfbnoJyalYLSgMT.status_code not in[200]:return[]
   NdrmHGwijBuVehkPfbnoJyalYLSgMO=json.loads(NdrmHGwijBuVehkPfbnoJyalYLSgMT.text)
   for NdrmHGwijBuVehkPfbnoJyalYLSgMp in NdrmHGwijBuVehkPfbnoJyalYLSgMO.get('data').get('data'):
    NdrmHGwijBuVehkPfbnoJyalYLSgxz=NdrmHGwijBuVehkPfbnoJyalYLSgxW=NdrmHGwijBuVehkPfbnoJyalYLSgzs=''
    if 'poster' in NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('images'):NdrmHGwijBuVehkPfbnoJyalYLSgxz =NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('images').get('poster').get('url')
    if 'story-art' in NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('images'):NdrmHGwijBuVehkPfbnoJyalYLSgxW =NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('images').get('story-art').get('url')
    if 'story-art' in NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('images'):NdrmHGwijBuVehkPfbnoJyalYLSgzs =NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('images').get('story-art').get('url')
    NdrmHGwijBuVehkPfbnoJyalYLSgMA={'id':NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('id'),'title':NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('title'),'thumbnail':{'poster':NdrmHGwijBuVehkPfbnoJyalYLSgxz,'thumb':NdrmHGwijBuVehkPfbnoJyalYLSgxW,'fanart':NdrmHGwijBuVehkPfbnoJyalYLSgzs},'duration':NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('running_time'),'asis':NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('type'),}
    NdrmHGwijBuVehkPfbnoJyalYLSgMQ.append(NdrmHGwijBuVehkPfbnoJyalYLSgMA)
  except NdrmHGwijBuVehkPfbnoJyalYLSgzt as exception:
   NdrmHGwijBuVehkPfbnoJyalYLSgzc(exception)
   return[]
  return NdrmHGwijBuVehkPfbnoJyalYLSgMQ
 def Get_Search_List(NdrmHGwijBuVehkPfbnoJyalYLSgKx,search_key,page_int):
  NdrmHGwijBuVehkPfbnoJyalYLSgMQ=[] 
  NdrmHGwijBuVehkPfbnoJyalYLSgxK=NdrmHGwijBuVehkPfbnoJyalYLSgzq
  try:
   NdrmHGwijBuVehkPfbnoJyalYLSgMz=NdrmHGwijBuVehkPfbnoJyalYLSgKx.API_VIEWURL+'/v2/search' 
   NdrmHGwijBuVehkPfbnoJyalYLSgMR={'query':search_key,'platform':'WEBCLIENT','page':NdrmHGwijBuVehkPfbnoJyalYLSgzI(page_int),'perPage':NdrmHGwijBuVehkPfbnoJyalYLSgzI(NdrmHGwijBuVehkPfbnoJyalYLSgKx.SEARCH_LIMIT),}
   NdrmHGwijBuVehkPfbnoJyalYLSgMU={'x-membersrl':NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['member_srl'],'x-pcid':NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['PCID'],'x-profileid':NdrmHGwijBuVehkPfbnoJyalYLSgKx.CP['SESSION']['profileId'],}
   NdrmHGwijBuVehkPfbnoJyalYLSgMT=NdrmHGwijBuVehkPfbnoJyalYLSgKx.callRequestCookies('Get',NdrmHGwijBuVehkPfbnoJyalYLSgMz,payload=NdrmHGwijBuVehkPfbnoJyalYLSgzF,params=NdrmHGwijBuVehkPfbnoJyalYLSgMR,headers=NdrmHGwijBuVehkPfbnoJyalYLSgMU,cookies=NdrmHGwijBuVehkPfbnoJyalYLSgzF,redirects=NdrmHGwijBuVehkPfbnoJyalYLSgzp)
   if NdrmHGwijBuVehkPfbnoJyalYLSgMT.status_code not in[200]:return[],NdrmHGwijBuVehkPfbnoJyalYLSgzq
   NdrmHGwijBuVehkPfbnoJyalYLSgMO=json.loads(NdrmHGwijBuVehkPfbnoJyalYLSgMT.text)
   for NdrmHGwijBuVehkPfbnoJyalYLSgMp in NdrmHGwijBuVehkPfbnoJyalYLSgMO.get('data').get('data'):
    NdrmHGwijBuVehkPfbnoJyalYLSgMp=NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('data')
    NdrmHGwijBuVehkPfbnoJyalYLSgxz=NdrmHGwijBuVehkPfbnoJyalYLSgxW=NdrmHGwijBuVehkPfbnoJyalYLSgzX=NdrmHGwijBuVehkPfbnoJyalYLSgzs=''
    if 'poster' in NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('images'):NdrmHGwijBuVehkPfbnoJyalYLSgxz =NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('images').get('poster').get('url')
    if 'story-art' in NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('images'):NdrmHGwijBuVehkPfbnoJyalYLSgxW =NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('images').get('story-art').get('url')
    if 'title-treatment' in NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('images'):NdrmHGwijBuVehkPfbnoJyalYLSgzX=NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('images').get('title-treatment').get('url')
    if 'story-art' in NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('images'):NdrmHGwijBuVehkPfbnoJyalYLSgzs =NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('images').get('story-art').get('url')
    NdrmHGwijBuVehkPfbnoJyalYLSgxT=''
    if NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('badge')not in[{},NdrmHGwijBuVehkPfbnoJyalYLSgzF]:
     for i in NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('badge').get('text'):
      if NdrmHGwijBuVehkPfbnoJyalYLSgxT!='':NdrmHGwijBuVehkPfbnoJyalYLSgxT+=' '
      NdrmHGwijBuVehkPfbnoJyalYLSgxT+=i.get('text')
    if 'as' in NdrmHGwijBuVehkPfbnoJyalYLSgMp:
     NdrmHGwijBuVehkPfbnoJyalYLSgzK=NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('as') 
    else:
     NdrmHGwijBuVehkPfbnoJyalYLSgzK=NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('type')
    NdrmHGwijBuVehkPfbnoJyalYLSgMA={'id':NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('id'),'title':NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('title'),'asis':NdrmHGwijBuVehkPfbnoJyalYLSgzK,'thumbnail':{'poster':NdrmHGwijBuVehkPfbnoJyalYLSgxz,'thumb':NdrmHGwijBuVehkPfbnoJyalYLSgxW,'clearlogo':NdrmHGwijBuVehkPfbnoJyalYLSgzX,'fanart':NdrmHGwijBuVehkPfbnoJyalYLSgzs},'mpaa':NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('age_rating'),'duration':NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('running_time'),'badge':NdrmHGwijBuVehkPfbnoJyalYLSgxT,'year':NdrmHGwijBuVehkPfbnoJyalYLSgMp.get('meta').get('releaseYear'),}
    NdrmHGwijBuVehkPfbnoJyalYLSgMQ.append(NdrmHGwijBuVehkPfbnoJyalYLSgMA)
   if NdrmHGwijBuVehkPfbnoJyalYLSgMO.get('pagination').get('totalPages')>page_int:
    NdrmHGwijBuVehkPfbnoJyalYLSgxK=NdrmHGwijBuVehkPfbnoJyalYLSgzp
  except NdrmHGwijBuVehkPfbnoJyalYLSgzt as exception:
   NdrmHGwijBuVehkPfbnoJyalYLSgzc(exception)
   return[],NdrmHGwijBuVehkPfbnoJyalYLSgzq
  return NdrmHGwijBuVehkPfbnoJyalYLSgMQ,NdrmHGwijBuVehkPfbnoJyalYLSgxK
 def GetBookmarkInfo(NdrmHGwijBuVehkPfbnoJyalYLSgKx,videoid,vidtype):
  NdrmHGwijBuVehkPfbnoJyalYLSgzM={'indexinfo':{'ott':'coupang','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  NdrmHGwijBuVehkPfbnoJyalYLSgMz=NdrmHGwijBuVehkPfbnoJyalYLSgKx.API_VIEWURL+'/v1/discover/titles/'+videoid 
  NdrmHGwijBuVehkPfbnoJyalYLSgMR={'locale':'ko'}
  NdrmHGwijBuVehkPfbnoJyalYLSgMT=NdrmHGwijBuVehkPfbnoJyalYLSgKx.callRequestCookies('Get',NdrmHGwijBuVehkPfbnoJyalYLSgMz,payload=NdrmHGwijBuVehkPfbnoJyalYLSgzF,params=NdrmHGwijBuVehkPfbnoJyalYLSgMR,headers=NdrmHGwijBuVehkPfbnoJyalYLSgzF,cookies=NdrmHGwijBuVehkPfbnoJyalYLSgzF,redirects=NdrmHGwijBuVehkPfbnoJyalYLSgzp)
  if NdrmHGwijBuVehkPfbnoJyalYLSgMT.status_code not in[200]:return{}
  NdrmHGwijBuVehkPfbnoJyalYLSgzx=json.loads(NdrmHGwijBuVehkPfbnoJyalYLSgMT.text).get('data')
  NdrmHGwijBuVehkPfbnoJyalYLSgzT=NdrmHGwijBuVehkPfbnoJyalYLSgzx.get('title')
  NdrmHGwijBuVehkPfbnoJyalYLSgzD =NdrmHGwijBuVehkPfbnoJyalYLSgzx.get('meta').get('releaseYear')
  NdrmHGwijBuVehkPfbnoJyalYLSgzM['saveinfo']['infoLabels']['title']=NdrmHGwijBuVehkPfbnoJyalYLSgzT
  if vidtype=='movie':
   NdrmHGwijBuVehkPfbnoJyalYLSgzT='%s  (%s)'%(NdrmHGwijBuVehkPfbnoJyalYLSgzT,NdrmHGwijBuVehkPfbnoJyalYLSgzD)
  NdrmHGwijBuVehkPfbnoJyalYLSgzM['saveinfo']['title'] =NdrmHGwijBuVehkPfbnoJyalYLSgzT
  NdrmHGwijBuVehkPfbnoJyalYLSgzM['saveinfo']['infoLabels']['mpaa'] =NdrmHGwijBuVehkPfbnoJyalYLSgzx.get('age_rating')
  NdrmHGwijBuVehkPfbnoJyalYLSgzM['saveinfo']['infoLabels']['plot'] ='%s\n\n%s'%(NdrmHGwijBuVehkPfbnoJyalYLSgzx.get('short_description'),NdrmHGwijBuVehkPfbnoJyalYLSgzx.get('description'))
  NdrmHGwijBuVehkPfbnoJyalYLSgzM['saveinfo']['infoLabels']['year'] =NdrmHGwijBuVehkPfbnoJyalYLSgzD
  if vidtype=='movie':
   NdrmHGwijBuVehkPfbnoJyalYLSgzM['saveinfo']['infoLabels']['duration']=NdrmHGwijBuVehkPfbnoJyalYLSgzx.get('running_time')
  NdrmHGwijBuVehkPfbnoJyalYLSgxz =''
  NdrmHGwijBuVehkPfbnoJyalYLSgzs =''
  NdrmHGwijBuVehkPfbnoJyalYLSgxW =''
  NdrmHGwijBuVehkPfbnoJyalYLSgzX=''
  if NdrmHGwijBuVehkPfbnoJyalYLSgzx.get('images').get('poster') !=NdrmHGwijBuVehkPfbnoJyalYLSgzF:NdrmHGwijBuVehkPfbnoJyalYLSgxz =NdrmHGwijBuVehkPfbnoJyalYLSgzx.get('images').get('poster').get('url')
  if NdrmHGwijBuVehkPfbnoJyalYLSgzx.get('images').get('background') !=NdrmHGwijBuVehkPfbnoJyalYLSgzF:NdrmHGwijBuVehkPfbnoJyalYLSgzs =NdrmHGwijBuVehkPfbnoJyalYLSgzx.get('images').get('background').get('url')
  if NdrmHGwijBuVehkPfbnoJyalYLSgzx.get('images').get('story-art') !=NdrmHGwijBuVehkPfbnoJyalYLSgzF:NdrmHGwijBuVehkPfbnoJyalYLSgxW =NdrmHGwijBuVehkPfbnoJyalYLSgzx.get('images').get('story-art').get('url')
  if NdrmHGwijBuVehkPfbnoJyalYLSgzx.get('images').get('title-treatment')!=NdrmHGwijBuVehkPfbnoJyalYLSgzF:NdrmHGwijBuVehkPfbnoJyalYLSgzX=NdrmHGwijBuVehkPfbnoJyalYLSgzx.get('images').get('title-treatment').get('url')
  if NdrmHGwijBuVehkPfbnoJyalYLSgzs=='':NdrmHGwijBuVehkPfbnoJyalYLSgzs=NdrmHGwijBuVehkPfbnoJyalYLSgxW
  NdrmHGwijBuVehkPfbnoJyalYLSgzM['saveinfo']['thumbnail']['poster']=NdrmHGwijBuVehkPfbnoJyalYLSgxz
  NdrmHGwijBuVehkPfbnoJyalYLSgzM['saveinfo']['thumbnail']['fanart']=NdrmHGwijBuVehkPfbnoJyalYLSgzs
  NdrmHGwijBuVehkPfbnoJyalYLSgzM['saveinfo']['thumbnail']['thumb']=NdrmHGwijBuVehkPfbnoJyalYLSgxW
  NdrmHGwijBuVehkPfbnoJyalYLSgzM['saveinfo']['thumbnail']['clearlogo']=NdrmHGwijBuVehkPfbnoJyalYLSgzX
  NdrmHGwijBuVehkPfbnoJyalYLSgzW=[]
  for NdrmHGwijBuVehkPfbnoJyalYLSgxX in NdrmHGwijBuVehkPfbnoJyalYLSgzx.get('tags'):NdrmHGwijBuVehkPfbnoJyalYLSgzW.append(NdrmHGwijBuVehkPfbnoJyalYLSgxX.get('tag'))
  if NdrmHGwijBuVehkPfbnoJyalYLSgzC(NdrmHGwijBuVehkPfbnoJyalYLSgzW)>0:
   NdrmHGwijBuVehkPfbnoJyalYLSgzM['saveinfo']['infoLabels']['genre']=NdrmHGwijBuVehkPfbnoJyalYLSgzW
  NdrmHGwijBuVehkPfbnoJyalYLSgzU=[]
  NdrmHGwijBuVehkPfbnoJyalYLSgzE=[]
  for NdrmHGwijBuVehkPfbnoJyalYLSgxX in NdrmHGwijBuVehkPfbnoJyalYLSgzx.get('people'):
   if NdrmHGwijBuVehkPfbnoJyalYLSgxX.get('role')=='CAST' :NdrmHGwijBuVehkPfbnoJyalYLSgzU.append(NdrmHGwijBuVehkPfbnoJyalYLSgxX.get('name'))
   if NdrmHGwijBuVehkPfbnoJyalYLSgxX.get('role')=='DIRECTOR':NdrmHGwijBuVehkPfbnoJyalYLSgzE.append(NdrmHGwijBuVehkPfbnoJyalYLSgxX.get('name'))
  if NdrmHGwijBuVehkPfbnoJyalYLSgzC(NdrmHGwijBuVehkPfbnoJyalYLSgzU)>0:
   NdrmHGwijBuVehkPfbnoJyalYLSgzM['saveinfo']['infoLabels']['cast'] =NdrmHGwijBuVehkPfbnoJyalYLSgzU
  if NdrmHGwijBuVehkPfbnoJyalYLSgzC(NdrmHGwijBuVehkPfbnoJyalYLSgzE)>0:
   NdrmHGwijBuVehkPfbnoJyalYLSgzM['saveinfo']['infoLabels']['director']=NdrmHGwijBuVehkPfbnoJyalYLSgzE
  return NdrmHGwijBuVehkPfbnoJyalYLSgzM
# Created by pyminifier (https://github.com/liftoff/pyminifier)
