__author__="NightRain"
AUjLERhDIGcObnkQdlrmPoVNszvBtf=object
AUjLERhDIGcObnkQdlrmPoVNszvBtM=None
AUjLERhDIGcObnkQdlrmPoVNszvBtg=False
AUjLERhDIGcObnkQdlrmPoVNszvBtX=print
AUjLERhDIGcObnkQdlrmPoVNszvBtJ=str
AUjLERhDIGcObnkQdlrmPoVNszvBtS=open
AUjLERhDIGcObnkQdlrmPoVNszvBtq=int
AUjLERhDIGcObnkQdlrmPoVNszvBtT=Exception
AUjLERhDIGcObnkQdlrmPoVNszvBtF=id
AUjLERhDIGcObnkQdlrmPoVNszvBtK=True
AUjLERhDIGcObnkQdlrmPoVNszvBtY=len
AUjLERhDIGcObnkQdlrmPoVNszvBtH=range
import urllib
import re
import json
import requests
import datetime
import time
import random
import base64
class AUjLERhDIGcObnkQdlrmPoVNszvBCu(AUjLERhDIGcObnkQdlrmPoVNszvBtf):
 def __init__(AUjLERhDIGcObnkQdlrmPoVNszvBCp):
  AUjLERhDIGcObnkQdlrmPoVNszvBCp.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.82 Safari/537.36'
  AUjLERhDIGcObnkQdlrmPoVNszvBCp.MODEL ='Chrome_98' 
  AUjLERhDIGcObnkQdlrmPoVNszvBCp.DEFAULT_HEADER ={'user-agent':AUjLERhDIGcObnkQdlrmPoVNszvBCp.USER_AGENT}
  AUjLERhDIGcObnkQdlrmPoVNszvBCp.API_DOMAIN ='https://www.coupangplay.com'
  AUjLERhDIGcObnkQdlrmPoVNszvBCp.API_VIEWURL ='https://discover.coupangstreaming.com'
  AUjLERhDIGcObnkQdlrmPoVNszvBCp.PAGE_LIMIT =40
  AUjLERhDIGcObnkQdlrmPoVNszvBCp.SEARCH_LIMIT =20
  AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP={}
  AUjLERhDIGcObnkQdlrmPoVNszvBCp.Init_CP()
  AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP_DEVICE_FILENAME=''
  AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP_COOKIE_FILENAME=''
 def callRequestCookies(AUjLERhDIGcObnkQdlrmPoVNszvBCp,jobtype,AUjLERhDIGcObnkQdlrmPoVNszvBut,payload=AUjLERhDIGcObnkQdlrmPoVNszvBtM,params=AUjLERhDIGcObnkQdlrmPoVNszvBtM,headers=AUjLERhDIGcObnkQdlrmPoVNszvBtM,cookies=AUjLERhDIGcObnkQdlrmPoVNszvBtM,redirects=AUjLERhDIGcObnkQdlrmPoVNszvBtg):
  AUjLERhDIGcObnkQdlrmPoVNszvBCt=AUjLERhDIGcObnkQdlrmPoVNszvBCp.DEFAULT_HEADER
  if headers:AUjLERhDIGcObnkQdlrmPoVNszvBCt.update(headers)
  if jobtype=='Get':
   AUjLERhDIGcObnkQdlrmPoVNszvBCa=requests.get(AUjLERhDIGcObnkQdlrmPoVNszvBut,params=params,headers=AUjLERhDIGcObnkQdlrmPoVNszvBCt,cookies=cookies,allow_redirects=redirects)
  else:
   AUjLERhDIGcObnkQdlrmPoVNszvBCa=requests.post(AUjLERhDIGcObnkQdlrmPoVNszvBut,data=payload,params=params,headers=AUjLERhDIGcObnkQdlrmPoVNszvBCt,cookies=cookies,allow_redirects=redirects)
  AUjLERhDIGcObnkQdlrmPoVNszvBtX(AUjLERhDIGcObnkQdlrmPoVNszvBtJ(AUjLERhDIGcObnkQdlrmPoVNszvBCa.status_code)+' - '+AUjLERhDIGcObnkQdlrmPoVNszvBtJ(AUjLERhDIGcObnkQdlrmPoVNszvBCa.url))
  return AUjLERhDIGcObnkQdlrmPoVNszvBCa
 def callRequestCookies_test(AUjLERhDIGcObnkQdlrmPoVNszvBCp,jobtype,AUjLERhDIGcObnkQdlrmPoVNszvBut,payload=AUjLERhDIGcObnkQdlrmPoVNszvBtM,params=AUjLERhDIGcObnkQdlrmPoVNszvBtM,headers=AUjLERhDIGcObnkQdlrmPoVNszvBtM,cookies=AUjLERhDIGcObnkQdlrmPoVNszvBtM,redirects=AUjLERhDIGcObnkQdlrmPoVNszvBtg):
  AUjLERhDIGcObnkQdlrmPoVNszvBCt=AUjLERhDIGcObnkQdlrmPoVNszvBCp.DEFAULT_HEADER
  if headers:AUjLERhDIGcObnkQdlrmPoVNszvBCt.update(headers)
  AUjLERhDIGcObnkQdlrmPoVNszvBCa=requests.Request('POST',AUjLERhDIGcObnkQdlrmPoVNszvBut,headers=headers,data=payload,params=params,cookies=cookies)
  AUjLERhDIGcObnkQdlrmPoVNszvBCx=AUjLERhDIGcObnkQdlrmPoVNszvBCa.prepare()
  AUjLERhDIGcObnkQdlrmPoVNszvBCp.pretty_print_POST(AUjLERhDIGcObnkQdlrmPoVNszvBCx)
  return AUjLERhDIGcObnkQdlrmPoVNszvBCa
 def pretty_print_POST(AUjLERhDIGcObnkQdlrmPoVNszvBCp,req):
  AUjLERhDIGcObnkQdlrmPoVNszvBtX('{}\n{}\r\n{}\r\n\r\n{}'.format('-----------START-----------',req.method+' '+req.url,'\r\n'.join('{}: {}'.format(k,v)for k,v in req.headers.items()),req.body,))
 def dic_To_jsonfile(AUjLERhDIGcObnkQdlrmPoVNszvBCp,filename,AUjLERhDIGcObnkQdlrmPoVNszvBCi):
  if filename=='':return
  fp=AUjLERhDIGcObnkQdlrmPoVNszvBtS(filename,'w',-1,'utf-8')
  json.dump(AUjLERhDIGcObnkQdlrmPoVNszvBCi,fp,indent=4,ensure_ascii=AUjLERhDIGcObnkQdlrmPoVNszvBtg)
  fp.close()
 def jsonfile_To_dic(AUjLERhDIGcObnkQdlrmPoVNszvBCp,filename):
  if filename=='':return AUjLERhDIGcObnkQdlrmPoVNszvBtM
  try:
   fp=AUjLERhDIGcObnkQdlrmPoVNszvBtS(filename,'r',-1,'utf-8')
   AUjLERhDIGcObnkQdlrmPoVNszvBCw=json.load(fp)
   fp.close()
  except:
   AUjLERhDIGcObnkQdlrmPoVNszvBCw={}
  return AUjLERhDIGcObnkQdlrmPoVNszvBCw
 def convert_TimeStr(AUjLERhDIGcObnkQdlrmPoVNszvBCp,AUjLERhDIGcObnkQdlrmPoVNszvBCW):
  try:
   AUjLERhDIGcObnkQdlrmPoVNszvBCW =AUjLERhDIGcObnkQdlrmPoVNszvBCW[0:16]
   AUjLERhDIGcObnkQdlrmPoVNszvBCe=datetime.datetime.strptime(AUjLERhDIGcObnkQdlrmPoVNszvBCW,'%Y-%m-%dT%H:%M')+datetime.timedelta(hours=9)
   return AUjLERhDIGcObnkQdlrmPoVNszvBCe.strftime('%Y-%m-%d %H:%M')
  except:
   return AUjLERhDIGcObnkQdlrmPoVNszvBtM
 def Get_Now_Datetime(AUjLERhDIGcObnkQdlrmPoVNszvBCp):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetNoCache(AUjLERhDIGcObnkQdlrmPoVNszvBCp):
  AUjLERhDIGcObnkQdlrmPoVNszvBCM =AUjLERhDIGcObnkQdlrmPoVNszvBtq(time.time()*1000)
  return AUjLERhDIGcObnkQdlrmPoVNszvBCM
 def generatePcId(AUjLERhDIGcObnkQdlrmPoVNszvBCp):
  t=AUjLERhDIGcObnkQdlrmPoVNszvBCp.GetNoCache()
  r=random.random()
  AUjLERhDIGcObnkQdlrmPoVNszvBCg=AUjLERhDIGcObnkQdlrmPoVNszvBtJ(t)+AUjLERhDIGcObnkQdlrmPoVNszvBtJ(r)[2:12]
  return AUjLERhDIGcObnkQdlrmPoVNszvBCg
 def generatePvId(AUjLERhDIGcObnkQdlrmPoVNszvBCp,genType='1'):
  import hashlib
  m=hashlib.md5()
  AUjLERhDIGcObnkQdlrmPoVNszvBCX=AUjLERhDIGcObnkQdlrmPoVNszvBtJ(random.random())
  m.update(AUjLERhDIGcObnkQdlrmPoVNszvBCX.encode('utf-8'))
  AUjLERhDIGcObnkQdlrmPoVNszvBCJ=AUjLERhDIGcObnkQdlrmPoVNszvBtJ(m.hexdigest())
  if genType=='1':
   return '%s-%s-%s-%s-%s'%(AUjLERhDIGcObnkQdlrmPoVNszvBCJ[:8],AUjLERhDIGcObnkQdlrmPoVNszvBCJ[8:12],AUjLERhDIGcObnkQdlrmPoVNszvBCJ[12:16],AUjLERhDIGcObnkQdlrmPoVNszvBCJ[16:20],AUjLERhDIGcObnkQdlrmPoVNszvBCJ[20:])
  else:
   return AUjLERhDIGcObnkQdlrmPoVNszvBCJ
 def Get_DeviceID(AUjLERhDIGcObnkQdlrmPoVNszvBCp):
  AUjLERhDIGcObnkQdlrmPoVNszvBCS=''
  try: 
   fp=AUjLERhDIGcObnkQdlrmPoVNszvBtS(AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP_DEVICE_FILENAME,'r',-1,'utf-8')
   AUjLERhDIGcObnkQdlrmPoVNszvBCq= json.load(fp)
   fp.close()
   AUjLERhDIGcObnkQdlrmPoVNszvBCS=AUjLERhDIGcObnkQdlrmPoVNszvBCq.get('device_id')
  except AUjLERhDIGcObnkQdlrmPoVNszvBtT as exception:
   AUjLERhDIGcObnkQdlrmPoVNszvBtM
  if AUjLERhDIGcObnkQdlrmPoVNszvBCS=='':
   AUjLERhDIGcObnkQdlrmPoVNszvBCS=AUjLERhDIGcObnkQdlrmPoVNszvBCp.generatePvId(genType='1')
   try: 
    fp=AUjLERhDIGcObnkQdlrmPoVNszvBtS(AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP_DEVICE_FILENAME,'w',-1,'utf-8')
    json.dump({'device_id':AUjLERhDIGcObnkQdlrmPoVNszvBCS},fp,indent=4,ensure_ascii=AUjLERhDIGcObnkQdlrmPoVNszvBtg)
    fp.close()
   except AUjLERhDIGcObnkQdlrmPoVNszvBtT as exception:
    return ''
  return AUjLERhDIGcObnkQdlrmPoVNszvBCS
 def Make_authHeader(AUjLERhDIGcObnkQdlrmPoVNszvBCp):
  tr=AUjLERhDIGcObnkQdlrmPoVNszvBCp.generatePvId(genType=2)
  ti=AUjLERhDIGcObnkQdlrmPoVNszvBCp.GetNoCache()
  AUjLERhDIGcObnkQdlrmPoVNszvBtF=AUjLERhDIGcObnkQdlrmPoVNszvBCp.generatePvId(genType=2)[:16]
  AUjLERhDIGcObnkQdlrmPoVNszvBCT='00-%s-%s-01'%(tr,AUjLERhDIGcObnkQdlrmPoVNszvBtF,)
  AUjLERhDIGcObnkQdlrmPoVNszvBCF ='%s@nr=0-1-%s-%s-%s----%s'%(AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['NREUM']['tk'],AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['NREUM']['ac'],AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['NREUM']['ap'],AUjLERhDIGcObnkQdlrmPoVNszvBtF,ti,)
  AUjLERhDIGcObnkQdlrmPoVNszvBCK ='{"v":[0,1],"d":{"ty":"Browser","ac":"%s","ap":"%s","id":"%s","tr":"%s","ti":%s,"tk":"%s"}}'%(AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['NREUM']['ac'],AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['NREUM']['ap'],AUjLERhDIGcObnkQdlrmPoVNszvBtF,tr,ti,AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['NREUM']['tk'],) 
  return AUjLERhDIGcObnkQdlrmPoVNszvBCT,AUjLERhDIGcObnkQdlrmPoVNszvBCF,base64.standard_b64encode(AUjLERhDIGcObnkQdlrmPoVNszvBCK.encode()).decode('utf-8')
 def Init_CP(AUjLERhDIGcObnkQdlrmPoVNszvBCp):
  AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP={}
  AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['ACCOUNT']={'cpid':'','cppw':'','cppf':'0'}
  AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']={}
 def Save_session_acount(AUjLERhDIGcObnkQdlrmPoVNszvBCp,AUjLERhDIGcObnkQdlrmPoVNszvBCY,AUjLERhDIGcObnkQdlrmPoVNszvBCH,AUjLERhDIGcObnkQdlrmPoVNszvBuC):
  AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['ACCOUNT']['cpid']=base64.standard_b64encode(AUjLERhDIGcObnkQdlrmPoVNszvBCY.encode()).decode('utf-8')
  AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['ACCOUNT']['cppw']=base64.standard_b64encode(AUjLERhDIGcObnkQdlrmPoVNszvBCH.encode()).decode('utf-8')
  AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['ACCOUNT']['cppf']=AUjLERhDIGcObnkQdlrmPoVNszvBtJ(AUjLERhDIGcObnkQdlrmPoVNszvBuC)
 def Load_session_acount(AUjLERhDIGcObnkQdlrmPoVNszvBCp):
  AUjLERhDIGcObnkQdlrmPoVNszvBCY=base64.standard_b64decode(AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['ACCOUNT']['cpid']).decode('utf-8')
  AUjLERhDIGcObnkQdlrmPoVNszvBCH=base64.standard_b64decode(AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['ACCOUNT']['cppw']).decode('utf-8')
  AUjLERhDIGcObnkQdlrmPoVNszvBuC=AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['ACCOUNT']['cppf']
  return AUjLERhDIGcObnkQdlrmPoVNszvBCY,AUjLERhDIGcObnkQdlrmPoVNszvBCH,AUjLERhDIGcObnkQdlrmPoVNszvBuC
 def make_CP_DefaultCookies(AUjLERhDIGcObnkQdlrmPoVNszvBCp):
  AUjLERhDIGcObnkQdlrmPoVNszvBup={}
  if 'NEXT_LOCALE' in AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']:AUjLERhDIGcObnkQdlrmPoVNszvBup['NEXT_LOCALE']=AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['NEXT_LOCALE']
  if 'ak_bmsc' in AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']:AUjLERhDIGcObnkQdlrmPoVNszvBup['ak_bmsc'] =AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['ak_bmsc']
  if 'bm_mi' in AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']:AUjLERhDIGcObnkQdlrmPoVNszvBup['bm_mi'] =AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['bm_mi']
  if 'bm_sv' in AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']:AUjLERhDIGcObnkQdlrmPoVNszvBup['bm_sv'] =AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['bm_sv']
  if 'PCID' in AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']:AUjLERhDIGcObnkQdlrmPoVNszvBup['PCID'] =AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['PCID']
  if 'member_srl' in AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']:AUjLERhDIGcObnkQdlrmPoVNszvBup['member_srl']=AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['member_srl']
  if 'token' in AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']:AUjLERhDIGcObnkQdlrmPoVNszvBup['token'] =AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['token']
  return AUjLERhDIGcObnkQdlrmPoVNszvBup
 def Get_CP_Login(AUjLERhDIGcObnkQdlrmPoVNszvBCp,userid,userpw,AUjLERhDIGcObnkQdlrmPoVNszvBug):
  try:
   AUjLERhDIGcObnkQdlrmPoVNszvBut=AUjLERhDIGcObnkQdlrmPoVNszvBCp.API_DOMAIN
   AUjLERhDIGcObnkQdlrmPoVNszvBua=AUjLERhDIGcObnkQdlrmPoVNszvBCp.callRequestCookies('Get',AUjLERhDIGcObnkQdlrmPoVNszvBut,payload=AUjLERhDIGcObnkQdlrmPoVNszvBtM,params=AUjLERhDIGcObnkQdlrmPoVNszvBtM,headers=AUjLERhDIGcObnkQdlrmPoVNszvBtM,cookies=AUjLERhDIGcObnkQdlrmPoVNszvBtM,redirects=AUjLERhDIGcObnkQdlrmPoVNszvBtg)
   if AUjLERhDIGcObnkQdlrmPoVNszvBua.status_code not in[301,302]:return AUjLERhDIGcObnkQdlrmPoVNszvBtg
   for AUjLERhDIGcObnkQdlrmPoVNszvBux in AUjLERhDIGcObnkQdlrmPoVNszvBua.cookies:
    if AUjLERhDIGcObnkQdlrmPoVNszvBux.name=='NEXT_LOCALE':
     AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['NEXT_LOCALE']=AUjLERhDIGcObnkQdlrmPoVNszvBux.value
    elif AUjLERhDIGcObnkQdlrmPoVNszvBux.name=='ak_bmsc':
     AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['ak_bmsc']=AUjLERhDIGcObnkQdlrmPoVNszvBux.value
   AUjLERhDIGcObnkQdlrmPoVNszvBup={'NEXT_LOCALE':AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['NEXT_LOCALE'],'ak_bmsc':AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['ak_bmsc'],}
   AUjLERhDIGcObnkQdlrmPoVNszvBua=AUjLERhDIGcObnkQdlrmPoVNszvBCp.callRequestCookies('Get',AUjLERhDIGcObnkQdlrmPoVNszvBut,payload=AUjLERhDIGcObnkQdlrmPoVNszvBtM,params=AUjLERhDIGcObnkQdlrmPoVNszvBtM,headers=AUjLERhDIGcObnkQdlrmPoVNszvBtM,cookies=AUjLERhDIGcObnkQdlrmPoVNszvBup,redirects=AUjLERhDIGcObnkQdlrmPoVNszvBtg)
   if AUjLERhDIGcObnkQdlrmPoVNszvBua.status_code not in[200]:return AUjLERhDIGcObnkQdlrmPoVNszvBtg
   AUjLERhDIGcObnkQdlrmPoVNszvBui=re.findall('NREUM.loader_config=\{[\w\d\":,-]+\}',AUjLERhDIGcObnkQdlrmPoVNszvBua.text)[0].split('=')[1]
   AUjLERhDIGcObnkQdlrmPoVNszvBui=AUjLERhDIGcObnkQdlrmPoVNszvBui.replace('{','{"').replace(':','":').replace(',',',"')
   AUjLERhDIGcObnkQdlrmPoVNszvBui=json.loads(AUjLERhDIGcObnkQdlrmPoVNszvBui)
   AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['NREUM']={'ac':AUjLERhDIGcObnkQdlrmPoVNszvBui['accountID'],'tk':AUjLERhDIGcObnkQdlrmPoVNszvBui['trustKey'],'ap':AUjLERhDIGcObnkQdlrmPoVNszvBui['agentID'],'lk':AUjLERhDIGcObnkQdlrmPoVNszvBui['licenseKey'],}
   for AUjLERhDIGcObnkQdlrmPoVNszvBux in AUjLERhDIGcObnkQdlrmPoVNszvBua.cookies:
    if AUjLERhDIGcObnkQdlrmPoVNszvBux.name=='bm_mi':
     AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['bm_mi']=AUjLERhDIGcObnkQdlrmPoVNszvBux.value
    elif AUjLERhDIGcObnkQdlrmPoVNszvBux.name=='bm_sv':
     AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['bm_sv'] =AUjLERhDIGcObnkQdlrmPoVNszvBux.value
     AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['bm_sv_ex']=AUjLERhDIGcObnkQdlrmPoVNszvBux.expires 
  except AUjLERhDIGcObnkQdlrmPoVNszvBtT as exception:
   AUjLERhDIGcObnkQdlrmPoVNszvBtX(exception)
   return AUjLERhDIGcObnkQdlrmPoVNszvBtg
  try:
   AUjLERhDIGcObnkQdlrmPoVNszvBut=AUjLERhDIGcObnkQdlrmPoVNszvBCp.API_DOMAIN+'/api/auth'
   AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['PCID']=AUjLERhDIGcObnkQdlrmPoVNszvBCp.generatePcId()
   AUjLERhDIGcObnkQdlrmPoVNszvBuy=AUjLERhDIGcObnkQdlrmPoVNszvBCp.Get_DeviceID()
   AUjLERhDIGcObnkQdlrmPoVNszvBuw =AUjLERhDIGcObnkQdlrmPoVNszvBuy.split('-')[0]
   AUjLERhDIGcObnkQdlrmPoVNszvBCT,AUjLERhDIGcObnkQdlrmPoVNszvBCF,AUjLERhDIGcObnkQdlrmPoVNszvBCK=AUjLERhDIGcObnkQdlrmPoVNszvBCp.Make_authHeader()
   AUjLERhDIGcObnkQdlrmPoVNszvBuW={'traceparent':AUjLERhDIGcObnkQdlrmPoVNszvBCT,'tracestate':AUjLERhDIGcObnkQdlrmPoVNszvBCF,'newrelic':AUjLERhDIGcObnkQdlrmPoVNszvBCK,'content-type':'application/json',}
   AUjLERhDIGcObnkQdlrmPoVNszvBue={'device':{'deviceId':'web-'+AUjLERhDIGcObnkQdlrmPoVNszvBuy,'model':AUjLERhDIGcObnkQdlrmPoVNszvBCp.MODEL,'name':'Chrome Desktop '+AUjLERhDIGcObnkQdlrmPoVNszvBuw,'os':'Windows','osVersion':'10','type':'webclient',},'email':userid,'password':userpw,}
   AUjLERhDIGcObnkQdlrmPoVNszvBue=json.dumps(AUjLERhDIGcObnkQdlrmPoVNszvBue,separators=(',',':'))
   AUjLERhDIGcObnkQdlrmPoVNszvBup={'NEXT_LOCALE':AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['NEXT_LOCALE'],'ak_bmsc':AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['ak_bmsc'],'bm_mi':AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['bm_mi'],'bm_sv':AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['bm_sv'],'PCID':AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['PCID'],}
   AUjLERhDIGcObnkQdlrmPoVNszvBua=AUjLERhDIGcObnkQdlrmPoVNszvBCp.callRequestCookies('Post',AUjLERhDIGcObnkQdlrmPoVNszvBut,payload=AUjLERhDIGcObnkQdlrmPoVNszvBue,params=AUjLERhDIGcObnkQdlrmPoVNszvBtM,headers=AUjLERhDIGcObnkQdlrmPoVNszvBuW,cookies=AUjLERhDIGcObnkQdlrmPoVNszvBup,redirects=AUjLERhDIGcObnkQdlrmPoVNszvBtg)
   if AUjLERhDIGcObnkQdlrmPoVNszvBua.status_code not in[200]:
    AUjLERhDIGcObnkQdlrmPoVNszvBuf=json.loads(AUjLERhDIGcObnkQdlrmPoVNszvBua.text)
    if 'error' in AUjLERhDIGcObnkQdlrmPoVNszvBuf:
     AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['error']=AUjLERhDIGcObnkQdlrmPoVNszvBuf.get('error').get('detail')
    return AUjLERhDIGcObnkQdlrmPoVNszvBtg
   for AUjLERhDIGcObnkQdlrmPoVNszvBux in AUjLERhDIGcObnkQdlrmPoVNszvBua.cookies:
    if AUjLERhDIGcObnkQdlrmPoVNszvBux.name=='token':
     AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['token']=AUjLERhDIGcObnkQdlrmPoVNszvBux.value
    elif AUjLERhDIGcObnkQdlrmPoVNszvBux.name=='member_srl':
     AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['member_srl']=AUjLERhDIGcObnkQdlrmPoVNszvBux.value
    elif AUjLERhDIGcObnkQdlrmPoVNszvBux.name=='bm_sv':
     AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['bm_sv'] =AUjLERhDIGcObnkQdlrmPoVNszvBux.value
     AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['bm_sv_ex']=AUjLERhDIGcObnkQdlrmPoVNszvBux.expires 
  except AUjLERhDIGcObnkQdlrmPoVNszvBtT as exception:
   AUjLERhDIGcObnkQdlrmPoVNszvBtX(exception)
   return AUjLERhDIGcObnkQdlrmPoVNszvBtg
  AUjLERhDIGcObnkQdlrmPoVNszvBCp.Save_session_acount(userid,userpw,AUjLERhDIGcObnkQdlrmPoVNszvBug)
  return AUjLERhDIGcObnkQdlrmPoVNszvBtK
 def Get_CP_profile(AUjLERhDIGcObnkQdlrmPoVNszvBCp,AUjLERhDIGcObnkQdlrmPoVNszvBug,limit_days=1,re_check=AUjLERhDIGcObnkQdlrmPoVNszvBtg):
  if re_check==AUjLERhDIGcObnkQdlrmPoVNszvBtK:
   if AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['bm_sv_ex']>AUjLERhDIGcObnkQdlrmPoVNszvBtq(time.time()):
    AUjLERhDIGcObnkQdlrmPoVNszvBtX('bm_sv_ex ok')
    return AUjLERhDIGcObnkQdlrmPoVNszvBtK
  try:
   AUjLERhDIGcObnkQdlrmPoVNszvBut=AUjLERhDIGcObnkQdlrmPoVNszvBCp.API_DOMAIN+'/api/profiles'
   AUjLERhDIGcObnkQdlrmPoVNszvBCT,AUjLERhDIGcObnkQdlrmPoVNszvBCF,AUjLERhDIGcObnkQdlrmPoVNszvBCK=AUjLERhDIGcObnkQdlrmPoVNszvBCp.Make_authHeader()
   AUjLERhDIGcObnkQdlrmPoVNszvBuW={'traceparent':AUjLERhDIGcObnkQdlrmPoVNszvBCT,'tracestate':AUjLERhDIGcObnkQdlrmPoVNszvBCF,'newrelic':AUjLERhDIGcObnkQdlrmPoVNszvBCK,}
   AUjLERhDIGcObnkQdlrmPoVNszvBup=AUjLERhDIGcObnkQdlrmPoVNszvBCp.make_CP_DefaultCookies()
   AUjLERhDIGcObnkQdlrmPoVNszvBua=AUjLERhDIGcObnkQdlrmPoVNszvBCp.callRequestCookies('Get',AUjLERhDIGcObnkQdlrmPoVNszvBut,payload=AUjLERhDIGcObnkQdlrmPoVNszvBtM,params=AUjLERhDIGcObnkQdlrmPoVNszvBtM,headers=AUjLERhDIGcObnkQdlrmPoVNszvBuW,cookies=AUjLERhDIGcObnkQdlrmPoVNszvBup,redirects=AUjLERhDIGcObnkQdlrmPoVNszvBtg)
   if AUjLERhDIGcObnkQdlrmPoVNszvBua.status_code not in[200]:return AUjLERhDIGcObnkQdlrmPoVNszvBtg
   AUjLERhDIGcObnkQdlrmPoVNszvBuf=json.loads(AUjLERhDIGcObnkQdlrmPoVNszvBua.text)
   AUjLERhDIGcObnkQdlrmPoVNszvBuM=0 
   for AUjLERhDIGcObnkQdlrmPoVNszvBux in AUjLERhDIGcObnkQdlrmPoVNszvBua.cookies:
    AUjLERhDIGcObnkQdlrmPoVNszvBtX(AUjLERhDIGcObnkQdlrmPoVNszvBux.name)
    if AUjLERhDIGcObnkQdlrmPoVNszvBux.name=='bm_sv':
     AUjLERhDIGcObnkQdlrmPoVNszvBuM=1
     AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['bm_sv'] =AUjLERhDIGcObnkQdlrmPoVNszvBux.value
     AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['bm_sv_ex']=AUjLERhDIGcObnkQdlrmPoVNszvBux.expires 
   if AUjLERhDIGcObnkQdlrmPoVNszvBuM==0:
    AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['bm_sv_ex']=AUjLERhDIGcObnkQdlrmPoVNszvBtq(time.time())+60*60*2 
   AUjLERhDIGcObnkQdlrmPoVNszvBug=AUjLERhDIGcObnkQdlrmPoVNszvBuf.get('data')[AUjLERhDIGcObnkQdlrmPoVNszvBtq(AUjLERhDIGcObnkQdlrmPoVNszvBug)]
   AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['accountId']=AUjLERhDIGcObnkQdlrmPoVNszvBug.get('accountId')
   AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['profileId']=AUjLERhDIGcObnkQdlrmPoVNszvBug.get('profileId')
  except AUjLERhDIGcObnkQdlrmPoVNszvBtT as exception:
   AUjLERhDIGcObnkQdlrmPoVNszvBtX(exception)
   return AUjLERhDIGcObnkQdlrmPoVNszvBtg
  if re_check==AUjLERhDIGcObnkQdlrmPoVNszvBtg:
   AUjLERhDIGcObnkQdlrmPoVNszvBuX =AUjLERhDIGcObnkQdlrmPoVNszvBCp.Get_Now_Datetime()
   AUjLERhDIGcObnkQdlrmPoVNszvBuJ=AUjLERhDIGcObnkQdlrmPoVNszvBuX+datetime.timedelta(days=limit_days)
   AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['limitdate']=AUjLERhDIGcObnkQdlrmPoVNszvBuJ.strftime('%Y-%m-%d')
  else:
   AUjLERhDIGcObnkQdlrmPoVNszvBtX('re check')
  AUjLERhDIGcObnkQdlrmPoVNszvBCp.dic_To_jsonfile(AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP_COOKIE_FILENAME,AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP)
  return AUjLERhDIGcObnkQdlrmPoVNszvBtK
 def Get_Category_GroupList(AUjLERhDIGcObnkQdlrmPoVNszvBCp,vType):
  AUjLERhDIGcObnkQdlrmPoVNszvBuS=[] 
  try:
   AUjLERhDIGcObnkQdlrmPoVNszvBut=AUjLERhDIGcObnkQdlrmPoVNszvBCp.API_VIEWURL+'/v2/discover/feed' 
   AUjLERhDIGcObnkQdlrmPoVNszvBuq={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false',}
   AUjLERhDIGcObnkQdlrmPoVNszvBua=AUjLERhDIGcObnkQdlrmPoVNszvBCp.callRequestCookies('Get',AUjLERhDIGcObnkQdlrmPoVNszvBut,payload=AUjLERhDIGcObnkQdlrmPoVNszvBtM,params=AUjLERhDIGcObnkQdlrmPoVNszvBuq,headers=AUjLERhDIGcObnkQdlrmPoVNszvBtM,cookies=AUjLERhDIGcObnkQdlrmPoVNszvBtM,redirects=AUjLERhDIGcObnkQdlrmPoVNszvBtK)
   if AUjLERhDIGcObnkQdlrmPoVNszvBua.status_code not in[200]:return[]
   AUjLERhDIGcObnkQdlrmPoVNszvBuf=json.loads(AUjLERhDIGcObnkQdlrmPoVNszvBua.text)
   if vType in['TVSHOWS','MOVIES']:
    AUjLERhDIGcObnkQdlrmPoVNszvBuT='Explores' 
   elif vType in['EDUCATION']:
    AUjLERhDIGcObnkQdlrmPoVNszvBuT='Collection-Rails-Curation'
   elif vType in['ALL']:
    AUjLERhDIGcObnkQdlrmPoVNszvBuT='Explores-Categories'
   for AUjLERhDIGcObnkQdlrmPoVNszvBuF in AUjLERhDIGcObnkQdlrmPoVNszvBuf.get('data'):
    if AUjLERhDIGcObnkQdlrmPoVNszvBuF.get('type')==AUjLERhDIGcObnkQdlrmPoVNszvBuT:
     for AUjLERhDIGcObnkQdlrmPoVNszvBuK in AUjLERhDIGcObnkQdlrmPoVNszvBuF.get('data'):
      if vType in['TVSHOWS','MOVIES']:
       AUjLERhDIGcObnkQdlrmPoVNszvBuY=AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('collectionId')
      elif vType in['EDUCATION','ALL']:
       AUjLERhDIGcObnkQdlrmPoVNszvBuY=AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('id')
      AUjLERhDIGcObnkQdlrmPoVNszvBuH={'collectionId':AUjLERhDIGcObnkQdlrmPoVNszvBuY,'title':AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('name'),'category':AUjLERhDIGcObnkQdlrmPoVNszvBuF.get('category'),'pre_title':'',}
      AUjLERhDIGcObnkQdlrmPoVNszvBuS.append(AUjLERhDIGcObnkQdlrmPoVNszvBuH)
     break
  except AUjLERhDIGcObnkQdlrmPoVNszvBtT as exception:
   AUjLERhDIGcObnkQdlrmPoVNszvBtX(exception)
   return[]
  return AUjLERhDIGcObnkQdlrmPoVNszvBuS
 def Get_Category_List(AUjLERhDIGcObnkQdlrmPoVNszvBCp,vType,AUjLERhDIGcObnkQdlrmPoVNszvBuY,page_int):
  AUjLERhDIGcObnkQdlrmPoVNszvBuS=[] 
  AUjLERhDIGcObnkQdlrmPoVNszvBpC=AUjLERhDIGcObnkQdlrmPoVNszvBtg
  try:
   if vType=='ALL':
    AUjLERhDIGcObnkQdlrmPoVNszvBuW={'x-membersrl':AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['member_srl'],'x-pcid':AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['PCID'],'x-profileid':AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['profileId'],}
    AUjLERhDIGcObnkQdlrmPoVNszvBuq={'platform':'WEBCLIENT','page':AUjLERhDIGcObnkQdlrmPoVNszvBtJ(page_int),'perPage':AUjLERhDIGcObnkQdlrmPoVNszvBtJ(AUjLERhDIGcObnkQdlrmPoVNszvBCp.PAGE_LIMIT),'locale':'ko','sort':'',}
    AUjLERhDIGcObnkQdlrmPoVNszvBut=AUjLERhDIGcObnkQdlrmPoVNszvBCp.API_VIEWURL+'/v1/discover/categories/'+AUjLERhDIGcObnkQdlrmPoVNszvBuY+'/titles'
    AUjLERhDIGcObnkQdlrmPoVNszvBua=AUjLERhDIGcObnkQdlrmPoVNszvBCp.callRequestCookies('Get',AUjLERhDIGcObnkQdlrmPoVNszvBut,payload=AUjLERhDIGcObnkQdlrmPoVNszvBtM,params=AUjLERhDIGcObnkQdlrmPoVNszvBuq,headers=AUjLERhDIGcObnkQdlrmPoVNszvBuW,cookies=AUjLERhDIGcObnkQdlrmPoVNszvBtM,redirects=AUjLERhDIGcObnkQdlrmPoVNszvBtK)
   else: 
    AUjLERhDIGcObnkQdlrmPoVNszvBuq={'platform':'WEBCLIENT','page':AUjLERhDIGcObnkQdlrmPoVNszvBtJ(page_int),'perPage':AUjLERhDIGcObnkQdlrmPoVNszvBtJ(AUjLERhDIGcObnkQdlrmPoVNszvBCp.PAGE_LIMIT),}
    AUjLERhDIGcObnkQdlrmPoVNszvBut=AUjLERhDIGcObnkQdlrmPoVNszvBCp.API_VIEWURL+'/v1/discover/collections/'+AUjLERhDIGcObnkQdlrmPoVNszvBuY+'/titles'
    AUjLERhDIGcObnkQdlrmPoVNszvBua=AUjLERhDIGcObnkQdlrmPoVNszvBCp.callRequestCookies('Get',AUjLERhDIGcObnkQdlrmPoVNszvBut,payload=AUjLERhDIGcObnkQdlrmPoVNszvBtM,params=AUjLERhDIGcObnkQdlrmPoVNszvBuq,headers=AUjLERhDIGcObnkQdlrmPoVNszvBtM,cookies=AUjLERhDIGcObnkQdlrmPoVNszvBtM,redirects=AUjLERhDIGcObnkQdlrmPoVNszvBtK)
   if AUjLERhDIGcObnkQdlrmPoVNszvBua.status_code not in[200]:return[],AUjLERhDIGcObnkQdlrmPoVNszvBtg
   AUjLERhDIGcObnkQdlrmPoVNszvBuf=json.loads(AUjLERhDIGcObnkQdlrmPoVNszvBua.text)
   if vType=='ALL':
    AUjLERhDIGcObnkQdlrmPoVNszvBpu=AUjLERhDIGcObnkQdlrmPoVNszvBuf.get('data').get('data')
   else:
    AUjLERhDIGcObnkQdlrmPoVNszvBpu=AUjLERhDIGcObnkQdlrmPoVNszvBuf.get('data')
   for AUjLERhDIGcObnkQdlrmPoVNszvBuK in AUjLERhDIGcObnkQdlrmPoVNszvBpu:
    AUjLERhDIGcObnkQdlrmPoVNszvBpt=AUjLERhDIGcObnkQdlrmPoVNszvBpw=AUjLERhDIGcObnkQdlrmPoVNszvBty=AUjLERhDIGcObnkQdlrmPoVNszvBti=''
    if 'poster' in AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('images'):AUjLERhDIGcObnkQdlrmPoVNszvBpt =AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('images').get('poster').get('url')
    if 'story-art' in AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('images'):AUjLERhDIGcObnkQdlrmPoVNszvBpw =AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('images').get('story-art').get('url')
    if 'title-treatment' in AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('images'):AUjLERhDIGcObnkQdlrmPoVNszvBty=AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('images').get('title-treatment').get('url')
    if 'story-art' in AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('images'):AUjLERhDIGcObnkQdlrmPoVNszvBti =AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('images').get('story-art').get('url')
    AUjLERhDIGcObnkQdlrmPoVNszvBpa=''
    if AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('badge')not in[{},AUjLERhDIGcObnkQdlrmPoVNszvBtM]:
     for i in AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('badge').get('text'):
      AUjLERhDIGcObnkQdlrmPoVNszvBpa+=i.get('text')
    AUjLERhDIGcObnkQdlrmPoVNszvBpx=''
    if AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('seasonList')!=AUjLERhDIGcObnkQdlrmPoVNszvBtM:
     AUjLERhDIGcObnkQdlrmPoVNszvBpx=','.join(AUjLERhDIGcObnkQdlrmPoVNszvBtJ(e)for e in AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('seasonList'))
    AUjLERhDIGcObnkQdlrmPoVNszvBpi =[]
    for AUjLERhDIGcObnkQdlrmPoVNszvBpy in AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('tags'):
     AUjLERhDIGcObnkQdlrmPoVNszvBpi.append(AUjLERhDIGcObnkQdlrmPoVNszvBpy.get('tag'))
    AUjLERhDIGcObnkQdlrmPoVNszvBuH={'id':AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('id'),'title':AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('title'),'thumbnail':{'poster':AUjLERhDIGcObnkQdlrmPoVNszvBpt,'thumb':AUjLERhDIGcObnkQdlrmPoVNszvBpw,'clearlogo':AUjLERhDIGcObnkQdlrmPoVNszvBty,'fanart':AUjLERhDIGcObnkQdlrmPoVNszvBti},'mpaa':AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('age_rating'),'duration':AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('running_time'),'asis':AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('as'),'badge':AUjLERhDIGcObnkQdlrmPoVNszvBpa,'year':AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('meta').get('releaseYear'),'seasonList':AUjLERhDIGcObnkQdlrmPoVNszvBpx,'genreList':AUjLERhDIGcObnkQdlrmPoVNszvBpi,}
    AUjLERhDIGcObnkQdlrmPoVNszvBuS.append(AUjLERhDIGcObnkQdlrmPoVNszvBuH)
   if AUjLERhDIGcObnkQdlrmPoVNszvBuf.get('pagination').get('totalPages')>page_int:
    AUjLERhDIGcObnkQdlrmPoVNszvBpC=AUjLERhDIGcObnkQdlrmPoVNszvBtK
  except AUjLERhDIGcObnkQdlrmPoVNszvBtT as exception:
   AUjLERhDIGcObnkQdlrmPoVNszvBtX(exception)
   return[],AUjLERhDIGcObnkQdlrmPoVNszvBtg
  return AUjLERhDIGcObnkQdlrmPoVNszvBuS,AUjLERhDIGcObnkQdlrmPoVNszvBpC
 def Get_Episode_List(AUjLERhDIGcObnkQdlrmPoVNszvBCp,programId,season):
  AUjLERhDIGcObnkQdlrmPoVNszvBuS=[] 
  try:
   AUjLERhDIGcObnkQdlrmPoVNszvBut=AUjLERhDIGcObnkQdlrmPoVNszvBCp.API_VIEWURL+'/v1/discover/titles/'+programId+'/episodes'
   AUjLERhDIGcObnkQdlrmPoVNszvBuq={'season':season,'sort':'true','locale':'ko',}
   AUjLERhDIGcObnkQdlrmPoVNszvBua=AUjLERhDIGcObnkQdlrmPoVNszvBCp.callRequestCookies('Get',AUjLERhDIGcObnkQdlrmPoVNszvBut,payload=AUjLERhDIGcObnkQdlrmPoVNszvBtM,params=AUjLERhDIGcObnkQdlrmPoVNszvBuq,headers=AUjLERhDIGcObnkQdlrmPoVNszvBtM,cookies=AUjLERhDIGcObnkQdlrmPoVNszvBtM,redirects=AUjLERhDIGcObnkQdlrmPoVNszvBtK)
   if AUjLERhDIGcObnkQdlrmPoVNszvBua.status_code not in[200]:return[]
   AUjLERhDIGcObnkQdlrmPoVNszvBuf=json.loads(AUjLERhDIGcObnkQdlrmPoVNszvBua.text)
   for AUjLERhDIGcObnkQdlrmPoVNszvBuK in AUjLERhDIGcObnkQdlrmPoVNszvBuf.get('data'):
    AUjLERhDIGcObnkQdlrmPoVNszvBpw=''
    if 'story-art' in AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('images'):AUjLERhDIGcObnkQdlrmPoVNszvBpw =AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('images').get('story-art').get('url')
    AUjLERhDIGcObnkQdlrmPoVNszvBpi =[]
    for AUjLERhDIGcObnkQdlrmPoVNszvBpy in AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('tags'):
     AUjLERhDIGcObnkQdlrmPoVNszvBpi.append(AUjLERhDIGcObnkQdlrmPoVNszvBpy.get('tag'))
    AUjLERhDIGcObnkQdlrmPoVNszvBuH={'id':AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('id'),'title':AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('title'),'thumbnail':{'thumb':AUjLERhDIGcObnkQdlrmPoVNszvBpw,'fanart':AUjLERhDIGcObnkQdlrmPoVNszvBpw},'mpaa':AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('age_rating'),'duration':AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('running_time'),'asis':AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('as'),'year':AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('meta').get('releaseYear'),'episode':AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('episode'),'genreList':AUjLERhDIGcObnkQdlrmPoVNszvBpi,'desc':AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('description'),}
    AUjLERhDIGcObnkQdlrmPoVNszvBuS.append(AUjLERhDIGcObnkQdlrmPoVNszvBuH)
  except AUjLERhDIGcObnkQdlrmPoVNszvBtT as exception:
   AUjLERhDIGcObnkQdlrmPoVNszvBtX(exception)
   return[]
  return AUjLERhDIGcObnkQdlrmPoVNszvBuS
 def Get_vInfo(AUjLERhDIGcObnkQdlrmPoVNszvBCp,titleId):
  try:
   AUjLERhDIGcObnkQdlrmPoVNszvBut=AUjLERhDIGcObnkQdlrmPoVNszvBCp.API_VIEWURL+'/v1/discover/titles/'+titleId 
   AUjLERhDIGcObnkQdlrmPoVNszvBuq={'locale':'ko'}
   AUjLERhDIGcObnkQdlrmPoVNszvBua=AUjLERhDIGcObnkQdlrmPoVNszvBCp.callRequestCookies('Get',AUjLERhDIGcObnkQdlrmPoVNszvBut,payload=AUjLERhDIGcObnkQdlrmPoVNszvBtM,params=AUjLERhDIGcObnkQdlrmPoVNszvBuq,headers=AUjLERhDIGcObnkQdlrmPoVNszvBtM,cookies=AUjLERhDIGcObnkQdlrmPoVNszvBtM,redirects=AUjLERhDIGcObnkQdlrmPoVNszvBtK)
   if AUjLERhDIGcObnkQdlrmPoVNszvBua.status_code not in[200]:return '','',''
   AUjLERhDIGcObnkQdlrmPoVNszvBuf=json.loads(AUjLERhDIGcObnkQdlrmPoVNszvBua.text).get('data')
   AUjLERhDIGcObnkQdlrmPoVNszvBpx=''
   if AUjLERhDIGcObnkQdlrmPoVNszvBuf.get('seasonList')!=AUjLERhDIGcObnkQdlrmPoVNszvBtM:
    AUjLERhDIGcObnkQdlrmPoVNszvBpx=','.join(AUjLERhDIGcObnkQdlrmPoVNszvBtJ(e)for e in AUjLERhDIGcObnkQdlrmPoVNszvBuf.get('seasonList'))
   AUjLERhDIGcObnkQdlrmPoVNszvBpW={'age_rating':AUjLERhDIGcObnkQdlrmPoVNszvBuf.get('age_rating'),'asset_id':AUjLERhDIGcObnkQdlrmPoVNszvBuf.get('asset_id'),'availability':AUjLERhDIGcObnkQdlrmPoVNszvBuf.get('availability'),'deal_id':AUjLERhDIGcObnkQdlrmPoVNszvBuf.get('deal_id'),'downloadable':'true' if AUjLERhDIGcObnkQdlrmPoVNszvBuf.get('downloadable')else 'false','region':AUjLERhDIGcObnkQdlrmPoVNszvBuf.get('region'),'streamable':'true' if AUjLERhDIGcObnkQdlrmPoVNszvBuf.get('streamable')else 'false','asis':AUjLERhDIGcObnkQdlrmPoVNszvBuf.get('as'),'seasonList':AUjLERhDIGcObnkQdlrmPoVNszvBpx}
  except AUjLERhDIGcObnkQdlrmPoVNszvBtT as exception:
   AUjLERhDIGcObnkQdlrmPoVNszvBtX(exception)
   return{}
  return AUjLERhDIGcObnkQdlrmPoVNszvBpW
 def Get_eInfo(AUjLERhDIGcObnkQdlrmPoVNszvBCp,eventId):
  try:
   AUjLERhDIGcObnkQdlrmPoVNszvBut=AUjLERhDIGcObnkQdlrmPoVNszvBCp.API_VIEWURL+'/v1/discover/events/'+eventId 
   AUjLERhDIGcObnkQdlrmPoVNszvBuq={'locale':'ko'}
   AUjLERhDIGcObnkQdlrmPoVNszvBua=AUjLERhDIGcObnkQdlrmPoVNszvBCp.callRequestCookies('Get',AUjLERhDIGcObnkQdlrmPoVNszvBut,payload=AUjLERhDIGcObnkQdlrmPoVNszvBtM,params=AUjLERhDIGcObnkQdlrmPoVNszvBuq,headers=AUjLERhDIGcObnkQdlrmPoVNszvBtM,cookies=AUjLERhDIGcObnkQdlrmPoVNszvBtM,redirects=AUjLERhDIGcObnkQdlrmPoVNszvBtK)
   if AUjLERhDIGcObnkQdlrmPoVNszvBua.status_code not in[200]:return '','',''
   AUjLERhDIGcObnkQdlrmPoVNszvBuf=json.loads(AUjLERhDIGcObnkQdlrmPoVNszvBua.text).get('data')
   AUjLERhDIGcObnkQdlrmPoVNszvBpW={'asset_id':AUjLERhDIGcObnkQdlrmPoVNszvBuf.get('asset_id'),'deal_id':AUjLERhDIGcObnkQdlrmPoVNszvBuf.get('deal_id'),'region':AUjLERhDIGcObnkQdlrmPoVNszvBuf.get('region'),'streamable':'true' if AUjLERhDIGcObnkQdlrmPoVNszvBuf.get('streamable')else 'false',}
  except AUjLERhDIGcObnkQdlrmPoVNszvBtT as exception:
   AUjLERhDIGcObnkQdlrmPoVNszvBtX(exception)
   return{}
  return AUjLERhDIGcObnkQdlrmPoVNszvBpW
 def GetBroadURL(AUjLERhDIGcObnkQdlrmPoVNszvBCp,titleId):
  AUjLERhDIGcObnkQdlrmPoVNszvBpe=''
  AUjLERhDIGcObnkQdlrmPoVNszvBpf =''
  AUjLERhDIGcObnkQdlrmPoVNszvBpW=AUjLERhDIGcObnkQdlrmPoVNszvBCp.Get_vInfo(titleId)
  if AUjLERhDIGcObnkQdlrmPoVNszvBpW=={}:return '',''
  try:
   AUjLERhDIGcObnkQdlrmPoVNszvBut=AUjLERhDIGcObnkQdlrmPoVNszvBCp.API_DOMAIN+'/api/playback/play' 
   AUjLERhDIGcObnkQdlrmPoVNszvBuq={'titleId':titleId}
   AUjLERhDIGcObnkQdlrmPoVNszvBCT,AUjLERhDIGcObnkQdlrmPoVNszvBCF,AUjLERhDIGcObnkQdlrmPoVNszvBCK=AUjLERhDIGcObnkQdlrmPoVNszvBCp.Make_authHeader()
   AUjLERhDIGcObnkQdlrmPoVNszvBuW={'traceparent':AUjLERhDIGcObnkQdlrmPoVNszvBCT,'tracestate':AUjLERhDIGcObnkQdlrmPoVNszvBCF,'newrelic':AUjLERhDIGcObnkQdlrmPoVNszvBCK,'x-force-raw':'true','x-pcid':AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':AUjLERhDIGcObnkQdlrmPoVNszvBpW.get('age_rating'),'x-title-availability':AUjLERhDIGcObnkQdlrmPoVNszvBpW.get('availability'),'x-title-brightcove-id':AUjLERhDIGcObnkQdlrmPoVNszvBpW.get('asset_id'),'x-title-deal-id':AUjLERhDIGcObnkQdlrmPoVNszvBpW.get('deal_id'),'x-title-downloadable':AUjLERhDIGcObnkQdlrmPoVNszvBpW.get('downloadable'),'x-title-region':AUjLERhDIGcObnkQdlrmPoVNszvBpW.get('region'),'x-title-streamable':AUjLERhDIGcObnkQdlrmPoVNszvBpW.get('streamable'),}
   AUjLERhDIGcObnkQdlrmPoVNszvBup=AUjLERhDIGcObnkQdlrmPoVNszvBCp.make_CP_DefaultCookies()
   AUjLERhDIGcObnkQdlrmPoVNszvBua=AUjLERhDIGcObnkQdlrmPoVNszvBCp.callRequestCookies('Get',AUjLERhDIGcObnkQdlrmPoVNszvBut,payload=AUjLERhDIGcObnkQdlrmPoVNszvBtM,params=AUjLERhDIGcObnkQdlrmPoVNszvBuq,headers=AUjLERhDIGcObnkQdlrmPoVNszvBuW,cookies=AUjLERhDIGcObnkQdlrmPoVNszvBup,redirects=AUjLERhDIGcObnkQdlrmPoVNszvBtK)
   if AUjLERhDIGcObnkQdlrmPoVNszvBua.status_code not in[200]:return '',json.loads(AUjLERhDIGcObnkQdlrmPoVNszvBua.text).get('error').get('detail')
   AUjLERhDIGcObnkQdlrmPoVNszvBuf=json.loads(AUjLERhDIGcObnkQdlrmPoVNszvBua.text)
   for AUjLERhDIGcObnkQdlrmPoVNszvBuK in AUjLERhDIGcObnkQdlrmPoVNszvBuf.get('data').get('raw').get('sources'):
    if AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('type')=='application/dash+xml' and AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('src')[0:8]=='https://':
     AUjLERhDIGcObnkQdlrmPoVNszvBpe=AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('src')
     if 'key_systems' in AUjLERhDIGcObnkQdlrmPoVNszvBuK:
      AUjLERhDIGcObnkQdlrmPoVNszvBpf =AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('key_systems').get('com.widevine.alpha').get('license_url')
     break
  except AUjLERhDIGcObnkQdlrmPoVNszvBtT as exception:
   AUjLERhDIGcObnkQdlrmPoVNszvBtX(exception)
   return '',''
  return AUjLERhDIGcObnkQdlrmPoVNszvBpe,AUjLERhDIGcObnkQdlrmPoVNszvBpf
 def GetEventURL(AUjLERhDIGcObnkQdlrmPoVNszvBCp,eventId,AUjLERhDIGcObnkQdlrmPoVNszvBtC):
  AUjLERhDIGcObnkQdlrmPoVNszvBpe=''
  AUjLERhDIGcObnkQdlrmPoVNszvBpf =''
  AUjLERhDIGcObnkQdlrmPoVNszvBpW=AUjLERhDIGcObnkQdlrmPoVNszvBCp.Get_eInfo(eventId)
  if AUjLERhDIGcObnkQdlrmPoVNszvBpW=={}:return '',''
  try:
   AUjLERhDIGcObnkQdlrmPoVNszvBut=AUjLERhDIGcObnkQdlrmPoVNszvBCp.API_DOMAIN+'/api/playback/play' 
   AUjLERhDIGcObnkQdlrmPoVNszvBuq={'titleId':eventId,'titleType':AUjLERhDIGcObnkQdlrmPoVNszvBtC,}
   AUjLERhDIGcObnkQdlrmPoVNszvBCT,AUjLERhDIGcObnkQdlrmPoVNszvBCF,AUjLERhDIGcObnkQdlrmPoVNszvBCK=AUjLERhDIGcObnkQdlrmPoVNszvBCp.Make_authHeader()
   AUjLERhDIGcObnkQdlrmPoVNszvBuW={'traceparent':AUjLERhDIGcObnkQdlrmPoVNszvBCT,'tracestate':AUjLERhDIGcObnkQdlrmPoVNszvBCF,'newrelic':AUjLERhDIGcObnkQdlrmPoVNszvBCK,'x-force-raw':'true','x-pcid':AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':AUjLERhDIGcObnkQdlrmPoVNszvBpW.get('asset_id'),'x-title-deal-id':AUjLERhDIGcObnkQdlrmPoVNszvBpW.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':AUjLERhDIGcObnkQdlrmPoVNszvBpW.get('region'),'x-title-streamable':AUjLERhDIGcObnkQdlrmPoVNszvBpW.get('streamable'),}
   AUjLERhDIGcObnkQdlrmPoVNszvBup=AUjLERhDIGcObnkQdlrmPoVNszvBCp.make_CP_DefaultCookies()
   AUjLERhDIGcObnkQdlrmPoVNszvBua=AUjLERhDIGcObnkQdlrmPoVNszvBCp.callRequestCookies('Get',AUjLERhDIGcObnkQdlrmPoVNszvBut,payload=AUjLERhDIGcObnkQdlrmPoVNszvBtM,params=AUjLERhDIGcObnkQdlrmPoVNszvBuq,headers=AUjLERhDIGcObnkQdlrmPoVNszvBuW,cookies=AUjLERhDIGcObnkQdlrmPoVNszvBup,redirects=AUjLERhDIGcObnkQdlrmPoVNszvBtK)
   if AUjLERhDIGcObnkQdlrmPoVNszvBua.status_code not in[200]:return '',json.loads(AUjLERhDIGcObnkQdlrmPoVNszvBua.text).get('error').get('detail')
   AUjLERhDIGcObnkQdlrmPoVNszvBuf=json.loads(AUjLERhDIGcObnkQdlrmPoVNszvBua.text)
   for AUjLERhDIGcObnkQdlrmPoVNszvBuK in AUjLERhDIGcObnkQdlrmPoVNszvBuf.get('data').get('raw').get('sources'):
    if AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('type')=='application/dash+xml' and AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('src')[0:8]=='https://':
     AUjLERhDIGcObnkQdlrmPoVNszvBpe=AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('src')
     if 'key_systems' in AUjLERhDIGcObnkQdlrmPoVNszvBuK:
      AUjLERhDIGcObnkQdlrmPoVNszvBpf =AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('key_systems').get('com.widevine.alpha').get('license_url')
     break
  except AUjLERhDIGcObnkQdlrmPoVNszvBtT as exception:
   AUjLERhDIGcObnkQdlrmPoVNszvBtX(exception)
   return '',''
  return AUjLERhDIGcObnkQdlrmPoVNszvBpe,AUjLERhDIGcObnkQdlrmPoVNszvBpf
 def GetEventURL_Live(AUjLERhDIGcObnkQdlrmPoVNszvBCp,eventId,AUjLERhDIGcObnkQdlrmPoVNszvBtC):
  AUjLERhDIGcObnkQdlrmPoVNszvBpe=''
  AUjLERhDIGcObnkQdlrmPoVNszvBpf =''
  AUjLERhDIGcObnkQdlrmPoVNszvBpW=AUjLERhDIGcObnkQdlrmPoVNszvBCp.Get_eInfo(eventId)
  if AUjLERhDIGcObnkQdlrmPoVNszvBpW=={}:return '',''
  try:
   AUjLERhDIGcObnkQdlrmPoVNszvBut=AUjLERhDIGcObnkQdlrmPoVNszvBCp.API_DOMAIN+'/api/playback/play' 
   AUjLERhDIGcObnkQdlrmPoVNszvBuq={'titleId':eventId,'titleType':AUjLERhDIGcObnkQdlrmPoVNszvBtC,}
   AUjLERhDIGcObnkQdlrmPoVNszvBCT,AUjLERhDIGcObnkQdlrmPoVNszvBCF,AUjLERhDIGcObnkQdlrmPoVNszvBCK=AUjLERhDIGcObnkQdlrmPoVNszvBCp.Make_authHeader()
   AUjLERhDIGcObnkQdlrmPoVNszvBuW={'traceparent':AUjLERhDIGcObnkQdlrmPoVNszvBCT,'tracestate':AUjLERhDIGcObnkQdlrmPoVNszvBCF,'newrelic':AUjLERhDIGcObnkQdlrmPoVNszvBCK,'x-force-raw':'true','x-pcid':AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':AUjLERhDIGcObnkQdlrmPoVNszvBpW.get('asset_id'),'x-title-deal-id':AUjLERhDIGcObnkQdlrmPoVNszvBpW.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':AUjLERhDIGcObnkQdlrmPoVNszvBpW.get('region'),'x-title-streamable':AUjLERhDIGcObnkQdlrmPoVNszvBpW.get('streamable'),}
   AUjLERhDIGcObnkQdlrmPoVNszvBup=AUjLERhDIGcObnkQdlrmPoVNszvBCp.make_CP_DefaultCookies()
   AUjLERhDIGcObnkQdlrmPoVNszvBua=AUjLERhDIGcObnkQdlrmPoVNszvBCp.callRequestCookies('Get',AUjLERhDIGcObnkQdlrmPoVNszvBut,payload=AUjLERhDIGcObnkQdlrmPoVNszvBtM,params=AUjLERhDIGcObnkQdlrmPoVNszvBuq,headers=AUjLERhDIGcObnkQdlrmPoVNszvBuW,cookies=AUjLERhDIGcObnkQdlrmPoVNszvBup,redirects=AUjLERhDIGcObnkQdlrmPoVNszvBtK)
   if AUjLERhDIGcObnkQdlrmPoVNszvBua.status_code not in[200]:return '',json.loads(AUjLERhDIGcObnkQdlrmPoVNszvBua.text).get('error').get('detail')
   AUjLERhDIGcObnkQdlrmPoVNszvBuf=json.loads(AUjLERhDIGcObnkQdlrmPoVNszvBua.text)
   for AUjLERhDIGcObnkQdlrmPoVNszvBuK in AUjLERhDIGcObnkQdlrmPoVNszvBuf.get('data').get('raw').get('sources'):
    if 'key_systems' in AUjLERhDIGcObnkQdlrmPoVNszvBuK:
     if AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('type')=='application/dash+xml' and 'com.widevine.alpha' in AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('key_systems')and AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('src').startswith('https://')==AUjLERhDIGcObnkQdlrmPoVNszvBtK:
      AUjLERhDIGcObnkQdlrmPoVNszvBpe=AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('src')
      AUjLERhDIGcObnkQdlrmPoVNszvBpf =AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('key_systems').get('com.widevine.alpha').get('license_url')
   if AUjLERhDIGcObnkQdlrmPoVNszvBpe=='':
    for AUjLERhDIGcObnkQdlrmPoVNszvBuK in AUjLERhDIGcObnkQdlrmPoVNszvBuf.get('data').get('raw').get('sources'):
     if 'key_systems' in AUjLERhDIGcObnkQdlrmPoVNszvBuK:
      if AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('key_systems')and AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('src').startswith('https://')==AUjLERhDIGcObnkQdlrmPoVNszvBtK:
       AUjLERhDIGcObnkQdlrmPoVNszvBpe=AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('src')
       AUjLERhDIGcObnkQdlrmPoVNszvBpf =AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('key_systems').get('com.widevine.alpha').get('license_url')
   if AUjLERhDIGcObnkQdlrmPoVNszvBpe=='':
    for AUjLERhDIGcObnkQdlrmPoVNszvBuK in AUjLERhDIGcObnkQdlrmPoVNszvBuf.get('data').get('raw').get('sources'):
     if AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('type')=='application/dash+xml' and AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('src').startswith('https://')==AUjLERhDIGcObnkQdlrmPoVNszvBtK:
      AUjLERhDIGcObnkQdlrmPoVNszvBpe=AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('src')
   if AUjLERhDIGcObnkQdlrmPoVNszvBpe=='':
    for AUjLERhDIGcObnkQdlrmPoVNszvBuK in AUjLERhDIGcObnkQdlrmPoVNszvBuf.get('data').get('raw').get('sources'):
     if AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('type')=='application/x-mpegURL' and AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('src').startswith('https://')==AUjLERhDIGcObnkQdlrmPoVNszvBtK:
      AUjLERhDIGcObnkQdlrmPoVNszvBpe=AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('src')
  except AUjLERhDIGcObnkQdlrmPoVNszvBtT as exception:
   AUjLERhDIGcObnkQdlrmPoVNszvBtX(exception)
   return '',''
  return AUjLERhDIGcObnkQdlrmPoVNszvBpe,AUjLERhDIGcObnkQdlrmPoVNszvBpf
 def Get_Url_PostFix(AUjLERhDIGcObnkQdlrmPoVNszvBCp,in_url):
  AUjLERhDIGcObnkQdlrmPoVNszvBpM=urllib.parse.urlparse(in_url) 
  AUjLERhDIGcObnkQdlrmPoVNszvBpg =AUjLERhDIGcObnkQdlrmPoVNszvBpM.path.strip('/').split('/')
  AUjLERhDIGcObnkQdlrmPoVNszvBpX =AUjLERhDIGcObnkQdlrmPoVNszvBpg[AUjLERhDIGcObnkQdlrmPoVNszvBtY(AUjLERhDIGcObnkQdlrmPoVNszvBpg)-1]
  AUjLERhDIGcObnkQdlrmPoVNszvBpJ=AUjLERhDIGcObnkQdlrmPoVNszvBpX.split('.')
  return AUjLERhDIGcObnkQdlrmPoVNszvBpJ[AUjLERhDIGcObnkQdlrmPoVNszvBtY(AUjLERhDIGcObnkQdlrmPoVNszvBpJ)-1]
 def Get_Theme_GroupList(AUjLERhDIGcObnkQdlrmPoVNszvBCp,vType):
  AUjLERhDIGcObnkQdlrmPoVNszvBuS=[] 
  try:
   AUjLERhDIGcObnkQdlrmPoVNszvBut=AUjLERhDIGcObnkQdlrmPoVNszvBCp.API_VIEWURL+'/v2/discover/feed' 
   AUjLERhDIGcObnkQdlrmPoVNszvBuq={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':AUjLERhDIGcObnkQdlrmPoVNszvBtJ(AUjLERhDIGcObnkQdlrmPoVNszvBCp.PAGE_LIMIT),'filterRestrictedContent':'false',}
   AUjLERhDIGcObnkQdlrmPoVNszvBua=AUjLERhDIGcObnkQdlrmPoVNszvBCp.callRequestCookies('Get',AUjLERhDIGcObnkQdlrmPoVNszvBut,payload=AUjLERhDIGcObnkQdlrmPoVNszvBtM,params=AUjLERhDIGcObnkQdlrmPoVNszvBuq,headers=AUjLERhDIGcObnkQdlrmPoVNszvBtM,cookies=AUjLERhDIGcObnkQdlrmPoVNszvBtM,redirects=AUjLERhDIGcObnkQdlrmPoVNszvBtK)
   if AUjLERhDIGcObnkQdlrmPoVNszvBua.status_code not in[200]:return[]
   AUjLERhDIGcObnkQdlrmPoVNszvBuf=json.loads(AUjLERhDIGcObnkQdlrmPoVNszvBua.text)
   for AUjLERhDIGcObnkQdlrmPoVNszvBuK in AUjLERhDIGcObnkQdlrmPoVNszvBuf.get('data'):
    if AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('type')=='Title-Rails-Curation':
     AUjLERhDIGcObnkQdlrmPoVNszvBpS =''
     AUjLERhDIGcObnkQdlrmPoVNszvBpq=7
     try:
      for i in AUjLERhDIGcObnkQdlrmPoVNszvBtH(AUjLERhDIGcObnkQdlrmPoVNszvBtY(AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('data'))):
       if i>=AUjLERhDIGcObnkQdlrmPoVNszvBpq:
        AUjLERhDIGcObnkQdlrmPoVNszvBpS=AUjLERhDIGcObnkQdlrmPoVNszvBpS+'...'
        break
       AUjLERhDIGcObnkQdlrmPoVNszvBpS=AUjLERhDIGcObnkQdlrmPoVNszvBpS+AUjLERhDIGcObnkQdlrmPoVNszvBuK['data'][i]['title']+'\n'
     except AUjLERhDIGcObnkQdlrmPoVNszvBtT as exception:
      AUjLERhDIGcObnkQdlrmPoVNszvBtX(exception)
     AUjLERhDIGcObnkQdlrmPoVNszvBuH={'collectionId':AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('obj_id'),'title':AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('row_name'),'category':AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('category'),'pre_title':AUjLERhDIGcObnkQdlrmPoVNszvBpS,}
     AUjLERhDIGcObnkQdlrmPoVNszvBuS.append(AUjLERhDIGcObnkQdlrmPoVNszvBuH)
  except AUjLERhDIGcObnkQdlrmPoVNszvBtT as exception:
   AUjLERhDIGcObnkQdlrmPoVNszvBtX(exception)
   return[]
  return AUjLERhDIGcObnkQdlrmPoVNszvBuS
 def Get_Event_GroupList(AUjLERhDIGcObnkQdlrmPoVNszvBCp):
  AUjLERhDIGcObnkQdlrmPoVNszvBuS=[] 
  try:
   AUjLERhDIGcObnkQdlrmPoVNszvBut=AUjLERhDIGcObnkQdlrmPoVNszvBCp.API_VIEWURL+'/v2/discover/feed' 
   AUjLERhDIGcObnkQdlrmPoVNszvBuq={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':7,'filterRestrictedContent':'false',}
   AUjLERhDIGcObnkQdlrmPoVNszvBua=AUjLERhDIGcObnkQdlrmPoVNszvBCp.callRequestCookies('Get',AUjLERhDIGcObnkQdlrmPoVNszvBut,payload=AUjLERhDIGcObnkQdlrmPoVNszvBtM,params=AUjLERhDIGcObnkQdlrmPoVNszvBuq,headers=AUjLERhDIGcObnkQdlrmPoVNszvBtM,cookies=AUjLERhDIGcObnkQdlrmPoVNszvBtM,redirects=AUjLERhDIGcObnkQdlrmPoVNszvBtK)
   if AUjLERhDIGcObnkQdlrmPoVNszvBua.status_code not in[200]:return[]
   AUjLERhDIGcObnkQdlrmPoVNszvBuf=json.loads(AUjLERhDIGcObnkQdlrmPoVNszvBua.text)
   for AUjLERhDIGcObnkQdlrmPoVNszvBuK in AUjLERhDIGcObnkQdlrmPoVNszvBuf.get('data'):
    if AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('row_name').strip()!='':
     AUjLERhDIGcObnkQdlrmPoVNszvBpS =''
     AUjLERhDIGcObnkQdlrmPoVNszvBpq=7
     try:
      for i in AUjLERhDIGcObnkQdlrmPoVNszvBtH(AUjLERhDIGcObnkQdlrmPoVNszvBtY(AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('data'))):
       if i>=AUjLERhDIGcObnkQdlrmPoVNszvBpq:
        AUjLERhDIGcObnkQdlrmPoVNszvBpS=AUjLERhDIGcObnkQdlrmPoVNszvBpS+'...'
        break
       AUjLERhDIGcObnkQdlrmPoVNszvBpS=AUjLERhDIGcObnkQdlrmPoVNszvBpS+AUjLERhDIGcObnkQdlrmPoVNszvBuK['data'][i]['title']+'\n'
     except AUjLERhDIGcObnkQdlrmPoVNszvBtT as exception:
      AUjLERhDIGcObnkQdlrmPoVNszvBtX(exception)
     AUjLERhDIGcObnkQdlrmPoVNszvBuH={'collectionId':AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('obj_id'),'title':AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('row_name'),'category':AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('type'),'pre_title':AUjLERhDIGcObnkQdlrmPoVNszvBpS,}
     AUjLERhDIGcObnkQdlrmPoVNszvBuS.append(AUjLERhDIGcObnkQdlrmPoVNszvBuH)
  except AUjLERhDIGcObnkQdlrmPoVNszvBtT as exception:
   AUjLERhDIGcObnkQdlrmPoVNszvBtX(exception)
   return[]
  return AUjLERhDIGcObnkQdlrmPoVNszvBuS
 def Get_Event_GameList(AUjLERhDIGcObnkQdlrmPoVNszvBCp,AUjLERhDIGcObnkQdlrmPoVNszvBuY):
  AUjLERhDIGcObnkQdlrmPoVNszvBuS=[] 
  try:
   AUjLERhDIGcObnkQdlrmPoVNszvBut=AUjLERhDIGcObnkQdlrmPoVNszvBCp.API_VIEWURL+'/v2/discover/feed' 
   AUjLERhDIGcObnkQdlrmPoVNszvBuq={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false',}
   AUjLERhDIGcObnkQdlrmPoVNszvBua=AUjLERhDIGcObnkQdlrmPoVNszvBCp.callRequestCookies('Get',AUjLERhDIGcObnkQdlrmPoVNszvBut,payload=AUjLERhDIGcObnkQdlrmPoVNszvBtM,params=AUjLERhDIGcObnkQdlrmPoVNszvBuq,headers=AUjLERhDIGcObnkQdlrmPoVNszvBtM,cookies=AUjLERhDIGcObnkQdlrmPoVNszvBtM,redirects=AUjLERhDIGcObnkQdlrmPoVNszvBtK)
   if AUjLERhDIGcObnkQdlrmPoVNszvBua.status_code not in[200]:return[]
   AUjLERhDIGcObnkQdlrmPoVNszvBuf=json.loads(AUjLERhDIGcObnkQdlrmPoVNszvBua.text)
   for AUjLERhDIGcObnkQdlrmPoVNszvBuK in AUjLERhDIGcObnkQdlrmPoVNszvBuf.get('data'):
    if AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('obj_id')==AUjLERhDIGcObnkQdlrmPoVNszvBuY:
     for AUjLERhDIGcObnkQdlrmPoVNszvBpT in AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('data'):
      AUjLERhDIGcObnkQdlrmPoVNszvBpt=AUjLERhDIGcObnkQdlrmPoVNszvBpw=AUjLERhDIGcObnkQdlrmPoVNszvBti=''
      if 'poster' in AUjLERhDIGcObnkQdlrmPoVNszvBpT.get('images'):AUjLERhDIGcObnkQdlrmPoVNszvBpt =AUjLERhDIGcObnkQdlrmPoVNszvBpT.get('images').get('poster').get('url')
      if 'story-art' in AUjLERhDIGcObnkQdlrmPoVNszvBpT.get('images'):AUjLERhDIGcObnkQdlrmPoVNszvBpw =AUjLERhDIGcObnkQdlrmPoVNszvBpT.get('images').get('story-art').get('url')
      if 'hero' in AUjLERhDIGcObnkQdlrmPoVNszvBpT.get('images'):AUjLERhDIGcObnkQdlrmPoVNszvBti =AUjLERhDIGcObnkQdlrmPoVNszvBpT.get('images').get('hero').get('url')
      AUjLERhDIGcObnkQdlrmPoVNszvBpF=AUjLERhDIGcObnkQdlrmPoVNszvBpT.get('meta').get(AUjLERhDIGcObnkQdlrmPoVNszvBpT.get('category')).get(AUjLERhDIGcObnkQdlrmPoVNszvBpT.get('sub_category'))
      if 'league' in AUjLERhDIGcObnkQdlrmPoVNszvBpF:
       AUjLERhDIGcObnkQdlrmPoVNszvBpK=AUjLERhDIGcObnkQdlrmPoVNszvBpF.get('league')
      else:
       AUjLERhDIGcObnkQdlrmPoVNszvBpK=AUjLERhDIGcObnkQdlrmPoVNszvBpF.get('round')
      AUjLERhDIGcObnkQdlrmPoVNszvBuH={'id':AUjLERhDIGcObnkQdlrmPoVNszvBpT.get('id'),'title':AUjLERhDIGcObnkQdlrmPoVNszvBpT.get('title'),'thumbnail':{'poster':AUjLERhDIGcObnkQdlrmPoVNszvBpt,'thumb':AUjLERhDIGcObnkQdlrmPoVNszvBpw,'fanart':AUjLERhDIGcObnkQdlrmPoVNszvBti},'asis':AUjLERhDIGcObnkQdlrmPoVNszvBpT.get('type'),'addInfo':AUjLERhDIGcObnkQdlrmPoVNszvBpK,'starttm':AUjLERhDIGcObnkQdlrmPoVNszvBCp.convert_TimeStr(AUjLERhDIGcObnkQdlrmPoVNszvBpT.get('start_at')),}
      AUjLERhDIGcObnkQdlrmPoVNszvBuS.append(AUjLERhDIGcObnkQdlrmPoVNszvBuH)
  except AUjLERhDIGcObnkQdlrmPoVNszvBtT as exception:
   AUjLERhDIGcObnkQdlrmPoVNszvBtX(exception)
   return[]
  return AUjLERhDIGcObnkQdlrmPoVNszvBuS
 def Get_Event_List(AUjLERhDIGcObnkQdlrmPoVNszvBCp,gameId):
  AUjLERhDIGcObnkQdlrmPoVNszvBuS=[] 
  try:
   AUjLERhDIGcObnkQdlrmPoVNszvBut=AUjLERhDIGcObnkQdlrmPoVNszvBCp.API_VIEWURL+'/v1/discover/events/'+gameId 
   AUjLERhDIGcObnkQdlrmPoVNszvBuq={'platform':'WEBCLIENT','locale':'ko','filterRestrictedContent':'false',}
   AUjLERhDIGcObnkQdlrmPoVNszvBua=AUjLERhDIGcObnkQdlrmPoVNszvBCp.callRequestCookies('Get',AUjLERhDIGcObnkQdlrmPoVNszvBut,payload=AUjLERhDIGcObnkQdlrmPoVNszvBtM,params=AUjLERhDIGcObnkQdlrmPoVNszvBuq,headers=AUjLERhDIGcObnkQdlrmPoVNszvBtM,cookies=AUjLERhDIGcObnkQdlrmPoVNszvBtM,redirects=AUjLERhDIGcObnkQdlrmPoVNszvBtK)
   if AUjLERhDIGcObnkQdlrmPoVNszvBua.status_code not in[200]:return[]
   AUjLERhDIGcObnkQdlrmPoVNszvBuf=json.loads(AUjLERhDIGcObnkQdlrmPoVNszvBua.text)
   AUjLERhDIGcObnkQdlrmPoVNszvBuK=AUjLERhDIGcObnkQdlrmPoVNszvBuf.get('data')
   AUjLERhDIGcObnkQdlrmPoVNszvBpY=AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('end_at')
   AUjLERhDIGcObnkQdlrmPoVNszvBpY=AUjLERhDIGcObnkQdlrmPoVNszvBpY[0:19].replace('-','').replace(':','').replace('T','')
   AUjLERhDIGcObnkQdlrmPoVNszvBpH=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d%H%M%S')
   if AUjLERhDIGcObnkQdlrmPoVNszvBtq(AUjLERhDIGcObnkQdlrmPoVNszvBpH)<AUjLERhDIGcObnkQdlrmPoVNszvBtq(AUjLERhDIGcObnkQdlrmPoVNszvBpY):
    AUjLERhDIGcObnkQdlrmPoVNszvBpt=AUjLERhDIGcObnkQdlrmPoVNszvBpw=AUjLERhDIGcObnkQdlrmPoVNszvBti=''
    if 'poster' in AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('images'):AUjLERhDIGcObnkQdlrmPoVNszvBpt =AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('images').get('poster').get('url')
    if 'story-art' in AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('images'):AUjLERhDIGcObnkQdlrmPoVNszvBpw =AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('images').get('story-art').get('url')
    if 'story-art' in AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('images'):AUjLERhDIGcObnkQdlrmPoVNszvBti =AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('images').get('story-art').get('url')
    AUjLERhDIGcObnkQdlrmPoVNszvBuH={'id':AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('id'),'title':AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('title'),'thumbnail':{'poster':AUjLERhDIGcObnkQdlrmPoVNszvBpt,'thumb':AUjLERhDIGcObnkQdlrmPoVNszvBpw,'fanart':AUjLERhDIGcObnkQdlrmPoVNszvBti},'duration':AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('running_time'),'asis':AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('type'),'starttm':AUjLERhDIGcObnkQdlrmPoVNszvBCp.convert_TimeStr(AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('start_at')),}
    AUjLERhDIGcObnkQdlrmPoVNszvBuS.append(AUjLERhDIGcObnkQdlrmPoVNszvBuH)
  except AUjLERhDIGcObnkQdlrmPoVNszvBtT as exception:
   AUjLERhDIGcObnkQdlrmPoVNszvBtX(exception)
   return[]
  try:
   AUjLERhDIGcObnkQdlrmPoVNszvBut=AUjLERhDIGcObnkQdlrmPoVNszvBCp.API_VIEWURL+'/v1/discover/events/'+gameId+'/related' 
   AUjLERhDIGcObnkQdlrmPoVNszvBuq={'locale':'ko','page':'1','perPage':'25','platform':'WEBCLIENT','currentPageTracking':'page_discover_title_detail',}
   AUjLERhDIGcObnkQdlrmPoVNszvBua=AUjLERhDIGcObnkQdlrmPoVNszvBCp.callRequestCookies('Get',AUjLERhDIGcObnkQdlrmPoVNszvBut,payload=AUjLERhDIGcObnkQdlrmPoVNszvBtM,params=AUjLERhDIGcObnkQdlrmPoVNszvBuq,headers=AUjLERhDIGcObnkQdlrmPoVNszvBtM,cookies=AUjLERhDIGcObnkQdlrmPoVNszvBtM,redirects=AUjLERhDIGcObnkQdlrmPoVNszvBtK)
   if AUjLERhDIGcObnkQdlrmPoVNszvBua.status_code not in[200]:return[]
   AUjLERhDIGcObnkQdlrmPoVNszvBuf=json.loads(AUjLERhDIGcObnkQdlrmPoVNszvBua.text)
   for AUjLERhDIGcObnkQdlrmPoVNszvBuK in AUjLERhDIGcObnkQdlrmPoVNszvBuf.get('data').get('data'):
    AUjLERhDIGcObnkQdlrmPoVNszvBpt=AUjLERhDIGcObnkQdlrmPoVNszvBpw=AUjLERhDIGcObnkQdlrmPoVNszvBti=''
    if 'poster' in AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('images'):AUjLERhDIGcObnkQdlrmPoVNszvBpt =AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('images').get('poster').get('url')
    if 'story-art' in AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('images'):AUjLERhDIGcObnkQdlrmPoVNszvBpw =AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('images').get('story-art').get('url')
    if 'story-art' in AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('images'):AUjLERhDIGcObnkQdlrmPoVNszvBti =AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('images').get('story-art').get('url')
    AUjLERhDIGcObnkQdlrmPoVNszvBuH={'id':AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('id'),'title':AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('title'),'thumbnail':{'poster':AUjLERhDIGcObnkQdlrmPoVNszvBpt,'thumb':AUjLERhDIGcObnkQdlrmPoVNszvBpw,'fanart':AUjLERhDIGcObnkQdlrmPoVNszvBti},'duration':AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('running_time'),'asis':AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('type'),}
    AUjLERhDIGcObnkQdlrmPoVNszvBuS.append(AUjLERhDIGcObnkQdlrmPoVNszvBuH)
  except AUjLERhDIGcObnkQdlrmPoVNszvBtT as exception:
   AUjLERhDIGcObnkQdlrmPoVNszvBtX(exception)
   return[]
  return AUjLERhDIGcObnkQdlrmPoVNszvBuS
 def Get_Search_List(AUjLERhDIGcObnkQdlrmPoVNszvBCp,search_key,page_int):
  AUjLERhDIGcObnkQdlrmPoVNszvBuS=[] 
  AUjLERhDIGcObnkQdlrmPoVNszvBpC=AUjLERhDIGcObnkQdlrmPoVNszvBtg
  try:
   AUjLERhDIGcObnkQdlrmPoVNszvBut=AUjLERhDIGcObnkQdlrmPoVNszvBCp.API_VIEWURL+'/v2/search' 
   AUjLERhDIGcObnkQdlrmPoVNszvBuq={'query':search_key,'platform':'WEBCLIENT','page':AUjLERhDIGcObnkQdlrmPoVNszvBtJ(page_int),'perPage':AUjLERhDIGcObnkQdlrmPoVNszvBtJ(AUjLERhDIGcObnkQdlrmPoVNszvBCp.SEARCH_LIMIT),}
   AUjLERhDIGcObnkQdlrmPoVNszvBuW={'x-membersrl':AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['member_srl'],'x-pcid':AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['PCID'],'x-profileid':AUjLERhDIGcObnkQdlrmPoVNszvBCp.CP['SESSION']['profileId'],}
   AUjLERhDIGcObnkQdlrmPoVNszvBua=AUjLERhDIGcObnkQdlrmPoVNszvBCp.callRequestCookies('Get',AUjLERhDIGcObnkQdlrmPoVNszvBut,payload=AUjLERhDIGcObnkQdlrmPoVNszvBtM,params=AUjLERhDIGcObnkQdlrmPoVNszvBuq,headers=AUjLERhDIGcObnkQdlrmPoVNszvBuW,cookies=AUjLERhDIGcObnkQdlrmPoVNszvBtM,redirects=AUjLERhDIGcObnkQdlrmPoVNszvBtK)
   if AUjLERhDIGcObnkQdlrmPoVNszvBua.status_code not in[200]:return[],AUjLERhDIGcObnkQdlrmPoVNszvBtg
   AUjLERhDIGcObnkQdlrmPoVNszvBuf=json.loads(AUjLERhDIGcObnkQdlrmPoVNszvBua.text)
   for AUjLERhDIGcObnkQdlrmPoVNszvBuK in AUjLERhDIGcObnkQdlrmPoVNszvBuf.get('data').get('data'):
    AUjLERhDIGcObnkQdlrmPoVNszvBuK=AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('data')
    AUjLERhDIGcObnkQdlrmPoVNszvBpt=AUjLERhDIGcObnkQdlrmPoVNszvBpw=AUjLERhDIGcObnkQdlrmPoVNszvBty=AUjLERhDIGcObnkQdlrmPoVNszvBti=''
    if 'poster' in AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('images'):AUjLERhDIGcObnkQdlrmPoVNszvBpt =AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('images').get('poster').get('url')
    if 'story-art' in AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('images'):AUjLERhDIGcObnkQdlrmPoVNszvBpw =AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('images').get('story-art').get('url')
    if 'title-treatment' in AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('images'):AUjLERhDIGcObnkQdlrmPoVNszvBty=AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('images').get('title-treatment').get('url')
    if 'story-art' in AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('images'):AUjLERhDIGcObnkQdlrmPoVNszvBti =AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('images').get('story-art').get('url')
    AUjLERhDIGcObnkQdlrmPoVNszvBpa=''
    if AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('badge')not in[{},AUjLERhDIGcObnkQdlrmPoVNszvBtM]:
     for i in AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('badge').get('text'):
      if AUjLERhDIGcObnkQdlrmPoVNszvBpa!='':AUjLERhDIGcObnkQdlrmPoVNszvBpa+=' '
      AUjLERhDIGcObnkQdlrmPoVNszvBpa+=i.get('text')
    if 'as' in AUjLERhDIGcObnkQdlrmPoVNszvBuK:
     AUjLERhDIGcObnkQdlrmPoVNszvBtC=AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('as') 
    else:
     AUjLERhDIGcObnkQdlrmPoVNszvBtC=AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('type')
    AUjLERhDIGcObnkQdlrmPoVNszvBuH={'id':AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('id'),'title':AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('title'),'asis':AUjLERhDIGcObnkQdlrmPoVNszvBtC,'thumbnail':{'poster':AUjLERhDIGcObnkQdlrmPoVNszvBpt,'thumb':AUjLERhDIGcObnkQdlrmPoVNszvBpw,'clearlogo':AUjLERhDIGcObnkQdlrmPoVNszvBty,'fanart':AUjLERhDIGcObnkQdlrmPoVNszvBti},'mpaa':AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('age_rating'),'duration':AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('running_time'),'badge':AUjLERhDIGcObnkQdlrmPoVNszvBpa,'year':AUjLERhDIGcObnkQdlrmPoVNszvBuK.get('meta').get('releaseYear'),}
    AUjLERhDIGcObnkQdlrmPoVNszvBuS.append(AUjLERhDIGcObnkQdlrmPoVNszvBuH)
   if AUjLERhDIGcObnkQdlrmPoVNszvBuf.get('pagination').get('totalPages')>page_int:
    AUjLERhDIGcObnkQdlrmPoVNszvBpC=AUjLERhDIGcObnkQdlrmPoVNszvBtK
  except AUjLERhDIGcObnkQdlrmPoVNszvBtT as exception:
   AUjLERhDIGcObnkQdlrmPoVNszvBtX(exception)
   return[],AUjLERhDIGcObnkQdlrmPoVNszvBtg
  return AUjLERhDIGcObnkQdlrmPoVNszvBuS,AUjLERhDIGcObnkQdlrmPoVNszvBpC
 def GetBookmarkInfo(AUjLERhDIGcObnkQdlrmPoVNszvBCp,videoid,vidtype):
  AUjLERhDIGcObnkQdlrmPoVNszvBtu={'indexinfo':{'ott':'coupang','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  AUjLERhDIGcObnkQdlrmPoVNszvBut=AUjLERhDIGcObnkQdlrmPoVNszvBCp.API_VIEWURL+'/v1/discover/titles/'+videoid 
  AUjLERhDIGcObnkQdlrmPoVNszvBuq={'locale':'ko'}
  AUjLERhDIGcObnkQdlrmPoVNszvBua=AUjLERhDIGcObnkQdlrmPoVNszvBCp.callRequestCookies('Get',AUjLERhDIGcObnkQdlrmPoVNszvBut,payload=AUjLERhDIGcObnkQdlrmPoVNszvBtM,params=AUjLERhDIGcObnkQdlrmPoVNszvBuq,headers=AUjLERhDIGcObnkQdlrmPoVNszvBtM,cookies=AUjLERhDIGcObnkQdlrmPoVNszvBtM,redirects=AUjLERhDIGcObnkQdlrmPoVNszvBtK)
  if AUjLERhDIGcObnkQdlrmPoVNszvBua.status_code not in[200]:return{}
  AUjLERhDIGcObnkQdlrmPoVNszvBtp=json.loads(AUjLERhDIGcObnkQdlrmPoVNszvBua.text).get('data')
  AUjLERhDIGcObnkQdlrmPoVNszvBta=AUjLERhDIGcObnkQdlrmPoVNszvBtp.get('title')
  AUjLERhDIGcObnkQdlrmPoVNszvBtx =AUjLERhDIGcObnkQdlrmPoVNszvBtp.get('meta').get('releaseYear')
  AUjLERhDIGcObnkQdlrmPoVNszvBtu['saveinfo']['infoLabels']['title']=AUjLERhDIGcObnkQdlrmPoVNszvBta
  if vidtype=='movie':
   AUjLERhDIGcObnkQdlrmPoVNszvBta='%s  (%s)'%(AUjLERhDIGcObnkQdlrmPoVNszvBta,AUjLERhDIGcObnkQdlrmPoVNszvBtx)
  AUjLERhDIGcObnkQdlrmPoVNszvBtu['saveinfo']['title'] =AUjLERhDIGcObnkQdlrmPoVNszvBta
  AUjLERhDIGcObnkQdlrmPoVNszvBtu['saveinfo']['infoLabels']['mpaa'] =AUjLERhDIGcObnkQdlrmPoVNszvBtp.get('age_rating')
  AUjLERhDIGcObnkQdlrmPoVNszvBtu['saveinfo']['infoLabels']['plot'] ='%s\n\n%s'%(AUjLERhDIGcObnkQdlrmPoVNszvBtp.get('short_description'),AUjLERhDIGcObnkQdlrmPoVNszvBtp.get('description'))
  AUjLERhDIGcObnkQdlrmPoVNszvBtu['saveinfo']['infoLabels']['year'] =AUjLERhDIGcObnkQdlrmPoVNszvBtx
  if vidtype=='movie':
   AUjLERhDIGcObnkQdlrmPoVNszvBtu['saveinfo']['infoLabels']['duration']=AUjLERhDIGcObnkQdlrmPoVNszvBtp.get('running_time')
  AUjLERhDIGcObnkQdlrmPoVNszvBpt =''
  AUjLERhDIGcObnkQdlrmPoVNszvBti =''
  AUjLERhDIGcObnkQdlrmPoVNszvBpw =''
  AUjLERhDIGcObnkQdlrmPoVNszvBty=''
  if AUjLERhDIGcObnkQdlrmPoVNszvBtp.get('images').get('poster') !=AUjLERhDIGcObnkQdlrmPoVNszvBtM:AUjLERhDIGcObnkQdlrmPoVNszvBpt =AUjLERhDIGcObnkQdlrmPoVNszvBtp.get('images').get('poster').get('url')
  if AUjLERhDIGcObnkQdlrmPoVNszvBtp.get('images').get('background') !=AUjLERhDIGcObnkQdlrmPoVNszvBtM:AUjLERhDIGcObnkQdlrmPoVNszvBti =AUjLERhDIGcObnkQdlrmPoVNszvBtp.get('images').get('background').get('url')
  if AUjLERhDIGcObnkQdlrmPoVNszvBtp.get('images').get('story-art') !=AUjLERhDIGcObnkQdlrmPoVNszvBtM:AUjLERhDIGcObnkQdlrmPoVNszvBpw =AUjLERhDIGcObnkQdlrmPoVNszvBtp.get('images').get('story-art').get('url')
  if AUjLERhDIGcObnkQdlrmPoVNszvBtp.get('images').get('title-treatment')!=AUjLERhDIGcObnkQdlrmPoVNszvBtM:AUjLERhDIGcObnkQdlrmPoVNszvBty=AUjLERhDIGcObnkQdlrmPoVNszvBtp.get('images').get('title-treatment').get('url')
  if AUjLERhDIGcObnkQdlrmPoVNszvBti=='':AUjLERhDIGcObnkQdlrmPoVNszvBti=AUjLERhDIGcObnkQdlrmPoVNszvBpw
  AUjLERhDIGcObnkQdlrmPoVNszvBtu['saveinfo']['thumbnail']['poster']=AUjLERhDIGcObnkQdlrmPoVNszvBpt
  AUjLERhDIGcObnkQdlrmPoVNszvBtu['saveinfo']['thumbnail']['fanart']=AUjLERhDIGcObnkQdlrmPoVNszvBti
  AUjLERhDIGcObnkQdlrmPoVNszvBtu['saveinfo']['thumbnail']['thumb']=AUjLERhDIGcObnkQdlrmPoVNszvBpw
  AUjLERhDIGcObnkQdlrmPoVNszvBtu['saveinfo']['thumbnail']['clearlogo']=AUjLERhDIGcObnkQdlrmPoVNszvBty
  AUjLERhDIGcObnkQdlrmPoVNszvBtw=[]
  for AUjLERhDIGcObnkQdlrmPoVNszvBpy in AUjLERhDIGcObnkQdlrmPoVNszvBtp.get('tags'):AUjLERhDIGcObnkQdlrmPoVNszvBtw.append(AUjLERhDIGcObnkQdlrmPoVNszvBpy.get('tag'))
  if AUjLERhDIGcObnkQdlrmPoVNszvBtY(AUjLERhDIGcObnkQdlrmPoVNszvBtw)>0:
   AUjLERhDIGcObnkQdlrmPoVNszvBtu['saveinfo']['infoLabels']['genre']=AUjLERhDIGcObnkQdlrmPoVNszvBtw
  AUjLERhDIGcObnkQdlrmPoVNszvBtW=[]
  AUjLERhDIGcObnkQdlrmPoVNszvBte=[]
  for AUjLERhDIGcObnkQdlrmPoVNszvBpy in AUjLERhDIGcObnkQdlrmPoVNszvBtp.get('people'):
   if AUjLERhDIGcObnkQdlrmPoVNszvBpy.get('role')=='CAST' :AUjLERhDIGcObnkQdlrmPoVNszvBtW.append(AUjLERhDIGcObnkQdlrmPoVNszvBpy.get('name'))
   if AUjLERhDIGcObnkQdlrmPoVNszvBpy.get('role')=='DIRECTOR':AUjLERhDIGcObnkQdlrmPoVNszvBte.append(AUjLERhDIGcObnkQdlrmPoVNszvBpy.get('name'))
  if AUjLERhDIGcObnkQdlrmPoVNszvBtY(AUjLERhDIGcObnkQdlrmPoVNszvBtW)>0:
   AUjLERhDIGcObnkQdlrmPoVNszvBtu['saveinfo']['infoLabels']['cast'] =AUjLERhDIGcObnkQdlrmPoVNszvBtW
  if AUjLERhDIGcObnkQdlrmPoVNszvBtY(AUjLERhDIGcObnkQdlrmPoVNszvBte)>0:
   AUjLERhDIGcObnkQdlrmPoVNszvBtu['saveinfo']['infoLabels']['director']=AUjLERhDIGcObnkQdlrmPoVNszvBte
  return AUjLERhDIGcObnkQdlrmPoVNszvBtu
# Created by pyminifier (https://github.com/liftoff/pyminifier)
