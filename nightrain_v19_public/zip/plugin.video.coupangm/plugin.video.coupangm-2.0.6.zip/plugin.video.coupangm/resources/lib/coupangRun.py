__author__="NightRain"
nDNzpfQauVFbRHjedUlryMJwKCEXgP=object
nDNzpfQauVFbRHjedUlryMJwKCEXgL=None
nDNzpfQauVFbRHjedUlryMJwKCEXgT=False
nDNzpfQauVFbRHjedUlryMJwKCEXgY=True
nDNzpfQauVFbRHjedUlryMJwKCEXgk=type
nDNzpfQauVFbRHjedUlryMJwKCEXgA=dict
nDNzpfQauVFbRHjedUlryMJwKCEXgc=int
nDNzpfQauVFbRHjedUlryMJwKCEXmS=open
nDNzpfQauVFbRHjedUlryMJwKCEXmx=Exception
nDNzpfQauVFbRHjedUlryMJwKCEXmo=str
nDNzpfQauVFbRHjedUlryMJwKCEXmi=id
nDNzpfQauVFbRHjedUlryMJwKCEXms=len
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import inputstreamhelper
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
nDNzpfQauVFbRHjedUlryMJwKCEXSo=[{'title':'홈   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'ALL'},{'title':'TV   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'MOVIES'},{'title':'교육 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'EDUCATION'},{'title':'생중계','mode':'EVENT_GROUPLIST','vType':'LIVE'},{'title':'TV   (테마별)','mode':'THEME_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (테마별)','mode':'THEME_GROUPLIST','vType':'MOVIES'},{'title':'교육 (테마별)','mode':'THEME_GROUPLIST','vType':'EDUCATION'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},{'title':'(쿠팡) 검색','mode':'LOCAL_SEARCH','icon':'search.png'},{'title':'(쿠팡) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
nDNzpfQauVFbRHjedUlryMJwKCEXSi=[{'title':'시리즈 시청내역','mode':'WATCH','stype':'tvshow'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},]
nDNzpfQauVFbRHjedUlryMJwKCEXSs=xbmcvfs.translatePath(os.path.join(__profile__,'coupang_searched.txt'))
from coupangCore import*
class nDNzpfQauVFbRHjedUlryMJwKCEXSx(nDNzpfQauVFbRHjedUlryMJwKCEXgP):
 def __init__(nDNzpfQauVFbRHjedUlryMJwKCEXSg,nDNzpfQauVFbRHjedUlryMJwKCEXSm,nDNzpfQauVFbRHjedUlryMJwKCEXSv,nDNzpfQauVFbRHjedUlryMJwKCEXSI):
  nDNzpfQauVFbRHjedUlryMJwKCEXSg._addon_url =nDNzpfQauVFbRHjedUlryMJwKCEXSm
  nDNzpfQauVFbRHjedUlryMJwKCEXSg._addon_handle=nDNzpfQauVFbRHjedUlryMJwKCEXSv
  nDNzpfQauVFbRHjedUlryMJwKCEXSg.main_params =nDNzpfQauVFbRHjedUlryMJwKCEXSI
  nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj =AUjLERhDIGcObnkQdlrmPoVNszvBCu() 
  nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.CP_COOKIE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_cookies.json'))
  nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.CP_DEVICE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_device.json'))
 def addon_noti(nDNzpfQauVFbRHjedUlryMJwKCEXSg,sting):
  try:
   nDNzpfQauVFbRHjedUlryMJwKCEXSB=xbmcgui.Dialog()
   nDNzpfQauVFbRHjedUlryMJwKCEXSB.notification(__addonname__,sting)
  except:
   nDNzpfQauVFbRHjedUlryMJwKCEXgL
 def addon_log(nDNzpfQauVFbRHjedUlryMJwKCEXSg,string):
  try:
   nDNzpfQauVFbRHjedUlryMJwKCEXSW=string.encode('utf-8','ignore')
  except:
   nDNzpfQauVFbRHjedUlryMJwKCEXSW='addonException: addon_log'
  nDNzpfQauVFbRHjedUlryMJwKCEXSt=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,nDNzpfQauVFbRHjedUlryMJwKCEXSW),level=nDNzpfQauVFbRHjedUlryMJwKCEXSt)
 def get_keyboard_input(nDNzpfQauVFbRHjedUlryMJwKCEXSg,nDNzpfQauVFbRHjedUlryMJwKCEXxo):
  nDNzpfQauVFbRHjedUlryMJwKCEXSG=nDNzpfQauVFbRHjedUlryMJwKCEXgL
  kb=xbmc.Keyboard()
  kb.setHeading(nDNzpfQauVFbRHjedUlryMJwKCEXxo)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   nDNzpfQauVFbRHjedUlryMJwKCEXSG=kb.getText()
  return nDNzpfQauVFbRHjedUlryMJwKCEXSG
 def get_settings_account(nDNzpfQauVFbRHjedUlryMJwKCEXSg):
  nDNzpfQauVFbRHjedUlryMJwKCEXSO=__addon__.getSetting('id')
  nDNzpfQauVFbRHjedUlryMJwKCEXSq=__addon__.getSetting('pw')
  nDNzpfQauVFbRHjedUlryMJwKCEXSP=__addon__.getSetting('profile')
  return(nDNzpfQauVFbRHjedUlryMJwKCEXSO,nDNzpfQauVFbRHjedUlryMJwKCEXSq,nDNzpfQauVFbRHjedUlryMJwKCEXSP)
 def get_settings_exclusion21(nDNzpfQauVFbRHjedUlryMJwKCEXSg):
  nDNzpfQauVFbRHjedUlryMJwKCEXSL =__addon__.getSetting('exclusion21')
  if nDNzpfQauVFbRHjedUlryMJwKCEXSL=='false':
   return nDNzpfQauVFbRHjedUlryMJwKCEXgT
  else:
   return nDNzpfQauVFbRHjedUlryMJwKCEXgY
 def get_settings_totalsearch(nDNzpfQauVFbRHjedUlryMJwKCEXSg):
  nDNzpfQauVFbRHjedUlryMJwKCEXST =nDNzpfQauVFbRHjedUlryMJwKCEXgY if __addon__.getSetting('local_search')=='true' else nDNzpfQauVFbRHjedUlryMJwKCEXgT
  nDNzpfQauVFbRHjedUlryMJwKCEXSY=nDNzpfQauVFbRHjedUlryMJwKCEXgY if __addon__.getSetting('local_history')=='true' else nDNzpfQauVFbRHjedUlryMJwKCEXgT
  nDNzpfQauVFbRHjedUlryMJwKCEXSk =nDNzpfQauVFbRHjedUlryMJwKCEXgY if __addon__.getSetting('total_search')=='true' else nDNzpfQauVFbRHjedUlryMJwKCEXgT
  nDNzpfQauVFbRHjedUlryMJwKCEXSA=nDNzpfQauVFbRHjedUlryMJwKCEXgY if __addon__.getSetting('total_history')=='true' else nDNzpfQauVFbRHjedUlryMJwKCEXgT
  nDNzpfQauVFbRHjedUlryMJwKCEXSc=nDNzpfQauVFbRHjedUlryMJwKCEXgY if __addon__.getSetting('menu_bookmark')=='true' else nDNzpfQauVFbRHjedUlryMJwKCEXgT
  return(nDNzpfQauVFbRHjedUlryMJwKCEXST,nDNzpfQauVFbRHjedUlryMJwKCEXSY,nDNzpfQauVFbRHjedUlryMJwKCEXSk,nDNzpfQauVFbRHjedUlryMJwKCEXSA,nDNzpfQauVFbRHjedUlryMJwKCEXSc)
 def get_settings_makebookmark(nDNzpfQauVFbRHjedUlryMJwKCEXSg):
  return nDNzpfQauVFbRHjedUlryMJwKCEXgY if __addon__.getSetting('make_bookmark')=='true' else nDNzpfQauVFbRHjedUlryMJwKCEXgT
 def add_dir(nDNzpfQauVFbRHjedUlryMJwKCEXSg,label,sublabel='',img='',infoLabels=nDNzpfQauVFbRHjedUlryMJwKCEXgL,isFolder=nDNzpfQauVFbRHjedUlryMJwKCEXgY,params='',isLink=nDNzpfQauVFbRHjedUlryMJwKCEXgT,ContextMenu=nDNzpfQauVFbRHjedUlryMJwKCEXgL):
  nDNzpfQauVFbRHjedUlryMJwKCEXxS='%s?%s'%(nDNzpfQauVFbRHjedUlryMJwKCEXSg._addon_url,urllib.parse.urlencode(params))
  if sublabel:nDNzpfQauVFbRHjedUlryMJwKCEXxo='%s < %s >'%(label,sublabel)
  else: nDNzpfQauVFbRHjedUlryMJwKCEXxo=label
  if not img:img='DefaultFolder.png'
  nDNzpfQauVFbRHjedUlryMJwKCEXxi=xbmcgui.ListItem(nDNzpfQauVFbRHjedUlryMJwKCEXxo)
  if nDNzpfQauVFbRHjedUlryMJwKCEXgk(img)==nDNzpfQauVFbRHjedUlryMJwKCEXgA:
   nDNzpfQauVFbRHjedUlryMJwKCEXxi.setArt(img)
  else:
   nDNzpfQauVFbRHjedUlryMJwKCEXxi.setArt({'thumb':img,'poster':img})
  if infoLabels:nDNzpfQauVFbRHjedUlryMJwKCEXxi.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   nDNzpfQauVFbRHjedUlryMJwKCEXxi.setProperty('IsPlayable','true')
  if ContextMenu:nDNzpfQauVFbRHjedUlryMJwKCEXxi.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(nDNzpfQauVFbRHjedUlryMJwKCEXSg._addon_handle,nDNzpfQauVFbRHjedUlryMJwKCEXxS,nDNzpfQauVFbRHjedUlryMJwKCEXxi,isFolder)
 def dp_Main_List(nDNzpfQauVFbRHjedUlryMJwKCEXSg,args):
  (nDNzpfQauVFbRHjedUlryMJwKCEXST,nDNzpfQauVFbRHjedUlryMJwKCEXSY,nDNzpfQauVFbRHjedUlryMJwKCEXSk,nDNzpfQauVFbRHjedUlryMJwKCEXSA,nDNzpfQauVFbRHjedUlryMJwKCEXSc)=nDNzpfQauVFbRHjedUlryMJwKCEXSg.get_settings_totalsearch()
  for nDNzpfQauVFbRHjedUlryMJwKCEXxs in nDNzpfQauVFbRHjedUlryMJwKCEXSo:
   nDNzpfQauVFbRHjedUlryMJwKCEXxo=nDNzpfQauVFbRHjedUlryMJwKCEXxs.get('title')
   nDNzpfQauVFbRHjedUlryMJwKCEXxg=''
   if nDNzpfQauVFbRHjedUlryMJwKCEXxs.get('mode')=='LOCAL_SEARCH' and nDNzpfQauVFbRHjedUlryMJwKCEXST ==nDNzpfQauVFbRHjedUlryMJwKCEXgT:continue
   elif nDNzpfQauVFbRHjedUlryMJwKCEXxs.get('mode')=='SEARCH_HISTORY' and nDNzpfQauVFbRHjedUlryMJwKCEXSY==nDNzpfQauVFbRHjedUlryMJwKCEXgT:continue
   elif nDNzpfQauVFbRHjedUlryMJwKCEXxs.get('mode')=='TOTAL_SEARCH' and nDNzpfQauVFbRHjedUlryMJwKCEXSk ==nDNzpfQauVFbRHjedUlryMJwKCEXgT:continue
   elif nDNzpfQauVFbRHjedUlryMJwKCEXxs.get('mode')=='TOTAL_HISTORY' and nDNzpfQauVFbRHjedUlryMJwKCEXSA==nDNzpfQauVFbRHjedUlryMJwKCEXgT:continue
   elif nDNzpfQauVFbRHjedUlryMJwKCEXxs.get('mode')=='MENU_BOOKMARK' and nDNzpfQauVFbRHjedUlryMJwKCEXSc==nDNzpfQauVFbRHjedUlryMJwKCEXgT:continue
   nDNzpfQauVFbRHjedUlryMJwKCEXxm={'mode':nDNzpfQauVFbRHjedUlryMJwKCEXxs.get('mode'),'vType':nDNzpfQauVFbRHjedUlryMJwKCEXxs.get('vType'),'page':'1',}
   if nDNzpfQauVFbRHjedUlryMJwKCEXxs.get('mode')=='LOCAL_SEARCH':nDNzpfQauVFbRHjedUlryMJwKCEXxm['historyyn']='Y' 
   if nDNzpfQauVFbRHjedUlryMJwKCEXxs.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    nDNzpfQauVFbRHjedUlryMJwKCEXxv=nDNzpfQauVFbRHjedUlryMJwKCEXgT
    nDNzpfQauVFbRHjedUlryMJwKCEXxI =nDNzpfQauVFbRHjedUlryMJwKCEXgY
   else:
    nDNzpfQauVFbRHjedUlryMJwKCEXxv=nDNzpfQauVFbRHjedUlryMJwKCEXgY
    nDNzpfQauVFbRHjedUlryMJwKCEXxI =nDNzpfQauVFbRHjedUlryMJwKCEXgT
   if 'icon' in nDNzpfQauVFbRHjedUlryMJwKCEXxs:nDNzpfQauVFbRHjedUlryMJwKCEXxg=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',nDNzpfQauVFbRHjedUlryMJwKCEXxs.get('icon')) 
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.add_dir(nDNzpfQauVFbRHjedUlryMJwKCEXxo,sublabel='',img=nDNzpfQauVFbRHjedUlryMJwKCEXxg,infoLabels=nDNzpfQauVFbRHjedUlryMJwKCEXgL,isFolder=nDNzpfQauVFbRHjedUlryMJwKCEXxv,params=nDNzpfQauVFbRHjedUlryMJwKCEXxm,isLink=nDNzpfQauVFbRHjedUlryMJwKCEXxI)
  xbmcplugin.endOfDirectory(nDNzpfQauVFbRHjedUlryMJwKCEXSg._addon_handle)
 def dp_Test(nDNzpfQauVFbRHjedUlryMJwKCEXSg,args):
  nDNzpfQauVFbRHjedUlryMJwKCEXSg.addon_noti('test')
 def CP_logout(nDNzpfQauVFbRHjedUlryMJwKCEXSg):
  nDNzpfQauVFbRHjedUlryMJwKCEXSB=xbmcgui.Dialog()
  nDNzpfQauVFbRHjedUlryMJwKCEXxB=nDNzpfQauVFbRHjedUlryMJwKCEXSB.yesno(__language__(30905).encode('utf8'),__language__(30906).encode('utf8'))
  if nDNzpfQauVFbRHjedUlryMJwKCEXxB==nDNzpfQauVFbRHjedUlryMJwKCEXgT:return 
  if os.path.isfile(nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.CP_COOKIE_FILENAME):os.remove(nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.CP_COOKIE_FILENAME)
  nDNzpfQauVFbRHjedUlryMJwKCEXSg.addon_noti(__language__(30904).encode('utf-8'))
 def option_check(nDNzpfQauVFbRHjedUlryMJwKCEXSg):
  (nDNzpfQauVFbRHjedUlryMJwKCEXSO,nDNzpfQauVFbRHjedUlryMJwKCEXSq,nDNzpfQauVFbRHjedUlryMJwKCEXSP)=nDNzpfQauVFbRHjedUlryMJwKCEXSg.get_settings_account()
  if nDNzpfQauVFbRHjedUlryMJwKCEXSO=='' or nDNzpfQauVFbRHjedUlryMJwKCEXSq=='':
   nDNzpfQauVFbRHjedUlryMJwKCEXSB=xbmcgui.Dialog()
   nDNzpfQauVFbRHjedUlryMJwKCEXxB=nDNzpfQauVFbRHjedUlryMJwKCEXSB.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if nDNzpfQauVFbRHjedUlryMJwKCEXxB==nDNzpfQauVFbRHjedUlryMJwKCEXgY:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if nDNzpfQauVFbRHjedUlryMJwKCEXSg.cookiefile_check()==nDNzpfQauVFbRHjedUlryMJwKCEXgT:
   if nDNzpfQauVFbRHjedUlryMJwKCEXSg.CP_login(nDNzpfQauVFbRHjedUlryMJwKCEXSO,nDNzpfQauVFbRHjedUlryMJwKCEXSq,nDNzpfQauVFbRHjedUlryMJwKCEXSP)==nDNzpfQauVFbRHjedUlryMJwKCEXgT:
    nDNzpfQauVFbRHjedUlryMJwKCEXSg.addon_noti(__language__(30903).encode('utf8'))
    sys.exit()
  else:
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.Get_CP_profile(nDNzpfQauVFbRHjedUlryMJwKCEXSP,limit_days=nDNzpfQauVFbRHjedUlryMJwKCEXgc(__addon__.getSetting('cache_ttl')),re_check=nDNzpfQauVFbRHjedUlryMJwKCEXgY)
 def cookiefile_check(nDNzpfQauVFbRHjedUlryMJwKCEXSg):
  nDNzpfQauVFbRHjedUlryMJwKCEXxt={}
  try: 
   fp=nDNzpfQauVFbRHjedUlryMJwKCEXmS(nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.CP_COOKIE_FILENAME,'r',-1,'utf-8')
   nDNzpfQauVFbRHjedUlryMJwKCEXxt= json.load(fp)
   fp.close()
  except nDNzpfQauVFbRHjedUlryMJwKCEXmx as exception:
   return nDNzpfQauVFbRHjedUlryMJwKCEXgT
  nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.CP=nDNzpfQauVFbRHjedUlryMJwKCEXxt
  (nDNzpfQauVFbRHjedUlryMJwKCEXSO,nDNzpfQauVFbRHjedUlryMJwKCEXSq,nDNzpfQauVFbRHjedUlryMJwKCEXSP)=nDNzpfQauVFbRHjedUlryMJwKCEXSg.get_settings_account()
  (nDNzpfQauVFbRHjedUlryMJwKCEXxG,nDNzpfQauVFbRHjedUlryMJwKCEXxO,nDNzpfQauVFbRHjedUlryMJwKCEXxq)=nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.Load_session_acount()
  if nDNzpfQauVFbRHjedUlryMJwKCEXSO!=nDNzpfQauVFbRHjedUlryMJwKCEXxG or nDNzpfQauVFbRHjedUlryMJwKCEXSq!=nDNzpfQauVFbRHjedUlryMJwKCEXxO or nDNzpfQauVFbRHjedUlryMJwKCEXSP!=nDNzpfQauVFbRHjedUlryMJwKCEXmo(nDNzpfQauVFbRHjedUlryMJwKCEXxq):
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.Init_CP()
   return nDNzpfQauVFbRHjedUlryMJwKCEXgT
  nDNzpfQauVFbRHjedUlryMJwKCEXxP =nDNzpfQauVFbRHjedUlryMJwKCEXgc(nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.Get_Now_Datetime().strftime('%Y%m%d'))
  nDNzpfQauVFbRHjedUlryMJwKCEXxL=nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.CP['SESSION']['limitdate']
  nDNzpfQauVFbRHjedUlryMJwKCEXxT =nDNzpfQauVFbRHjedUlryMJwKCEXgc(re.sub('-','',nDNzpfQauVFbRHjedUlryMJwKCEXxL))
  if nDNzpfQauVFbRHjedUlryMJwKCEXxT<nDNzpfQauVFbRHjedUlryMJwKCEXxP:
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.Init_CP()
   return nDNzpfQauVFbRHjedUlryMJwKCEXgT
  return nDNzpfQauVFbRHjedUlryMJwKCEXgY
 def CP_login(nDNzpfQauVFbRHjedUlryMJwKCEXSg,nDNzpfQauVFbRHjedUlryMJwKCEXSO,nDNzpfQauVFbRHjedUlryMJwKCEXSq,nDNzpfQauVFbRHjedUlryMJwKCEXSP):
  if nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.Get_CP_Login(nDNzpfQauVFbRHjedUlryMJwKCEXSO,nDNzpfQauVFbRHjedUlryMJwKCEXSq,nDNzpfQauVFbRHjedUlryMJwKCEXSP)==nDNzpfQauVFbRHjedUlryMJwKCEXgT:return nDNzpfQauVFbRHjedUlryMJwKCEXgT
  if nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.Get_CP_profile(nDNzpfQauVFbRHjedUlryMJwKCEXSP,limit_days=nDNzpfQauVFbRHjedUlryMJwKCEXgc(__addon__.getSetting('cache_ttl')),re_check=nDNzpfQauVFbRHjedUlryMJwKCEXgT)==nDNzpfQauVFbRHjedUlryMJwKCEXgT:return nDNzpfQauVFbRHjedUlryMJwKCEXgT
  return nDNzpfQauVFbRHjedUlryMJwKCEXgY
 def dp_Category_GroupList(nDNzpfQauVFbRHjedUlryMJwKCEXSg,args):
  nDNzpfQauVFbRHjedUlryMJwKCEXxY =args.get('vType') 
  nDNzpfQauVFbRHjedUlryMJwKCEXxk=nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.Get_Category_GroupList(nDNzpfQauVFbRHjedUlryMJwKCEXxY)
  for nDNzpfQauVFbRHjedUlryMJwKCEXxA in nDNzpfQauVFbRHjedUlryMJwKCEXxk:
   nDNzpfQauVFbRHjedUlryMJwKCEXxo =nDNzpfQauVFbRHjedUlryMJwKCEXxA.get('title')
   nDNzpfQauVFbRHjedUlryMJwKCEXxc=nDNzpfQauVFbRHjedUlryMJwKCEXxA.get('pre_title')
   if nDNzpfQauVFbRHjedUlryMJwKCEXSg.get_settings_exclusion21()==nDNzpfQauVFbRHjedUlryMJwKCEXgY and nDNzpfQauVFbRHjedUlryMJwKCEXxo=='성인':continue
   nDNzpfQauVFbRHjedUlryMJwKCEXoS={'mediatype':'tvshow','plot':nDNzpfQauVFbRHjedUlryMJwKCEXxc,}
   nDNzpfQauVFbRHjedUlryMJwKCEXxm={'mode':'CATEGORY_LIST','collectionId':nDNzpfQauVFbRHjedUlryMJwKCEXxA.get('collectionId'),'vType':nDNzpfQauVFbRHjedUlryMJwKCEXxA.get('category'),'page':'1',}
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.add_dir(nDNzpfQauVFbRHjedUlryMJwKCEXxo,sublabel='',img='',infoLabels=nDNzpfQauVFbRHjedUlryMJwKCEXoS,isFolder=nDNzpfQauVFbRHjedUlryMJwKCEXgY,params=nDNzpfQauVFbRHjedUlryMJwKCEXxm)
  xbmcplugin.endOfDirectory(nDNzpfQauVFbRHjedUlryMJwKCEXSg._addon_handle,cacheToDisc=nDNzpfQauVFbRHjedUlryMJwKCEXgT)
 def dp_Theme_GroupList(nDNzpfQauVFbRHjedUlryMJwKCEXSg,args):
  nDNzpfQauVFbRHjedUlryMJwKCEXxY =args.get('vType') 
  nDNzpfQauVFbRHjedUlryMJwKCEXxk=nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.Get_Theme_GroupList(nDNzpfQauVFbRHjedUlryMJwKCEXxY)
  for nDNzpfQauVFbRHjedUlryMJwKCEXxA in nDNzpfQauVFbRHjedUlryMJwKCEXxk:
   nDNzpfQauVFbRHjedUlryMJwKCEXxo =nDNzpfQauVFbRHjedUlryMJwKCEXxA.get('title')
   nDNzpfQauVFbRHjedUlryMJwKCEXxc=nDNzpfQauVFbRHjedUlryMJwKCEXxA.get('pre_title')
   nDNzpfQauVFbRHjedUlryMJwKCEXoS={'mediatype':'tvshow','plot':nDNzpfQauVFbRHjedUlryMJwKCEXxc,}
   nDNzpfQauVFbRHjedUlryMJwKCEXxm={'mode':'CATEGORY_LIST','collectionId':nDNzpfQauVFbRHjedUlryMJwKCEXxA.get('collectionId'),'vType':nDNzpfQauVFbRHjedUlryMJwKCEXxA.get('category'),'page':'1',}
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.add_dir(nDNzpfQauVFbRHjedUlryMJwKCEXxo,sublabel='',img='',infoLabels=nDNzpfQauVFbRHjedUlryMJwKCEXoS,isFolder=nDNzpfQauVFbRHjedUlryMJwKCEXgY,params=nDNzpfQauVFbRHjedUlryMJwKCEXxm)
  xbmcplugin.endOfDirectory(nDNzpfQauVFbRHjedUlryMJwKCEXSg._addon_handle,cacheToDisc=nDNzpfQauVFbRHjedUlryMJwKCEXgT)
 def dp_Event_GroupList(nDNzpfQauVFbRHjedUlryMJwKCEXSg,args):
  nDNzpfQauVFbRHjedUlryMJwKCEXxk=nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.Get_Event_GroupList()
  for nDNzpfQauVFbRHjedUlryMJwKCEXxA in nDNzpfQauVFbRHjedUlryMJwKCEXxk:
   nDNzpfQauVFbRHjedUlryMJwKCEXxo =nDNzpfQauVFbRHjedUlryMJwKCEXxA.get('title')
   nDNzpfQauVFbRHjedUlryMJwKCEXxc=nDNzpfQauVFbRHjedUlryMJwKCEXxA.get('pre_title')
   nDNzpfQauVFbRHjedUlryMJwKCEXoS={'mediatype':'tvshow','plot':nDNzpfQauVFbRHjedUlryMJwKCEXxc,}
   nDNzpfQauVFbRHjedUlryMJwKCEXxm={'mode':'EVENT_GAMELIST','collectionId':nDNzpfQauVFbRHjedUlryMJwKCEXxA.get('collectionId'),'vType':'LIVE',}
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.add_dir(nDNzpfQauVFbRHjedUlryMJwKCEXxo,sublabel='',img='',infoLabels=nDNzpfQauVFbRHjedUlryMJwKCEXoS,isFolder=nDNzpfQauVFbRHjedUlryMJwKCEXgY,params=nDNzpfQauVFbRHjedUlryMJwKCEXxm)
  xbmcplugin.endOfDirectory(nDNzpfQauVFbRHjedUlryMJwKCEXSg._addon_handle,cacheToDisc=nDNzpfQauVFbRHjedUlryMJwKCEXgT)
 def dp_Event_GameList(nDNzpfQauVFbRHjedUlryMJwKCEXSg,args):
  nDNzpfQauVFbRHjedUlryMJwKCEXxY =args.get('vType') 
  nDNzpfQauVFbRHjedUlryMJwKCEXoi =args.get('collectionId')
  nDNzpfQauVFbRHjedUlryMJwKCEXxk=nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.Get_Event_GameList(nDNzpfQauVFbRHjedUlryMJwKCEXoi)
  for nDNzpfQauVFbRHjedUlryMJwKCEXxA in nDNzpfQauVFbRHjedUlryMJwKCEXxk:
   nDNzpfQauVFbRHjedUlryMJwKCEXxo =nDNzpfQauVFbRHjedUlryMJwKCEXxA.get('title')
   nDNzpfQauVFbRHjedUlryMJwKCEXmi =nDNzpfQauVFbRHjedUlryMJwKCEXxA.get('id')
   nDNzpfQauVFbRHjedUlryMJwKCEXos =nDNzpfQauVFbRHjedUlryMJwKCEXxA.get('thumbnail')
   nDNzpfQauVFbRHjedUlryMJwKCEXog =nDNzpfQauVFbRHjedUlryMJwKCEXxA.get('asis') 
   nDNzpfQauVFbRHjedUlryMJwKCEXom =nDNzpfQauVFbRHjedUlryMJwKCEXxA.get('addInfo')
   nDNzpfQauVFbRHjedUlryMJwKCEXov =nDNzpfQauVFbRHjedUlryMJwKCEXxA.get('starttm')
   nDNzpfQauVFbRHjedUlryMJwKCEXoS={'mediatype':'tvshow','title':nDNzpfQauVFbRHjedUlryMJwKCEXxo,'plot':nDNzpfQauVFbRHjedUlryMJwKCEXom,}
   nDNzpfQauVFbRHjedUlryMJwKCEXxm={'mode':'EVENT_LIST','id':nDNzpfQauVFbRHjedUlryMJwKCEXmi,'asis':nDNzpfQauVFbRHjedUlryMJwKCEXog,'title':nDNzpfQauVFbRHjedUlryMJwKCEXxo,}
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.add_dir(nDNzpfQauVFbRHjedUlryMJwKCEXxo,sublabel=nDNzpfQauVFbRHjedUlryMJwKCEXov,img=nDNzpfQauVFbRHjedUlryMJwKCEXos,infoLabels=nDNzpfQauVFbRHjedUlryMJwKCEXoS,isFolder=nDNzpfQauVFbRHjedUlryMJwKCEXgY,params=nDNzpfQauVFbRHjedUlryMJwKCEXxm,ContextMenu=nDNzpfQauVFbRHjedUlryMJwKCEXgL)
  xbmcplugin.setContent(nDNzpfQauVFbRHjedUlryMJwKCEXSg._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(nDNzpfQauVFbRHjedUlryMJwKCEXSg._addon_handle,cacheToDisc=nDNzpfQauVFbRHjedUlryMJwKCEXgT)
 def dp_Event_List(nDNzpfQauVFbRHjedUlryMJwKCEXSg,args):
  nDNzpfQauVFbRHjedUlryMJwKCEXoI=args.get('id')
  nDNzpfQauVFbRHjedUlryMJwKCEXxk=nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.Get_Event_List(nDNzpfQauVFbRHjedUlryMJwKCEXoI)
  for nDNzpfQauVFbRHjedUlryMJwKCEXxA in nDNzpfQauVFbRHjedUlryMJwKCEXxk:
   nDNzpfQauVFbRHjedUlryMJwKCEXxo =nDNzpfQauVFbRHjedUlryMJwKCEXxA.get('title')
   nDNzpfQauVFbRHjedUlryMJwKCEXmi =nDNzpfQauVFbRHjedUlryMJwKCEXxA.get('id')
   nDNzpfQauVFbRHjedUlryMJwKCEXos =nDNzpfQauVFbRHjedUlryMJwKCEXxA.get('thumbnail')
   nDNzpfQauVFbRHjedUlryMJwKCEXog =nDNzpfQauVFbRHjedUlryMJwKCEXxA.get('asis') 
   nDNzpfQauVFbRHjedUlryMJwKCEXoh =nDNzpfQauVFbRHjedUlryMJwKCEXxA.get('duration')
   nDNzpfQauVFbRHjedUlryMJwKCEXov =nDNzpfQauVFbRHjedUlryMJwKCEXxA.get('starttm')
   nDNzpfQauVFbRHjedUlryMJwKCEXoS={'mediatype':'episode','title':nDNzpfQauVFbRHjedUlryMJwKCEXxo,'plot':nDNzpfQauVFbRHjedUlryMJwKCEXog,'duration':nDNzpfQauVFbRHjedUlryMJwKCEXoh,}
   nDNzpfQauVFbRHjedUlryMJwKCEXxm={'mode':nDNzpfQauVFbRHjedUlryMJwKCEXog,'id':nDNzpfQauVFbRHjedUlryMJwKCEXmi,'asis':nDNzpfQauVFbRHjedUlryMJwKCEXog,'title':nDNzpfQauVFbRHjedUlryMJwKCEXxo,}
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.add_dir(nDNzpfQauVFbRHjedUlryMJwKCEXxo,sublabel=nDNzpfQauVFbRHjedUlryMJwKCEXov,img=nDNzpfQauVFbRHjedUlryMJwKCEXos,infoLabels=nDNzpfQauVFbRHjedUlryMJwKCEXoS,isFolder=nDNzpfQauVFbRHjedUlryMJwKCEXgT,params=nDNzpfQauVFbRHjedUlryMJwKCEXxm,ContextMenu=nDNzpfQauVFbRHjedUlryMJwKCEXgL)
  xbmcplugin.setContent(nDNzpfQauVFbRHjedUlryMJwKCEXSg._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(nDNzpfQauVFbRHjedUlryMJwKCEXSg._addon_handle,cacheToDisc=nDNzpfQauVFbRHjedUlryMJwKCEXgT)
 def dp_Category_List(nDNzpfQauVFbRHjedUlryMJwKCEXSg,args):
  nDNzpfQauVFbRHjedUlryMJwKCEXxY =args.get('vType') 
  nDNzpfQauVFbRHjedUlryMJwKCEXoi =args.get('collectionId')
  nDNzpfQauVFbRHjedUlryMJwKCEXoB =nDNzpfQauVFbRHjedUlryMJwKCEXgc(args.get('page'))
  nDNzpfQauVFbRHjedUlryMJwKCEXxk,nDNzpfQauVFbRHjedUlryMJwKCEXoW=nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.Get_Category_List(nDNzpfQauVFbRHjedUlryMJwKCEXxY,nDNzpfQauVFbRHjedUlryMJwKCEXoi,nDNzpfQauVFbRHjedUlryMJwKCEXoB)
  for nDNzpfQauVFbRHjedUlryMJwKCEXxA in nDNzpfQauVFbRHjedUlryMJwKCEXxk:
   nDNzpfQauVFbRHjedUlryMJwKCEXxo =nDNzpfQauVFbRHjedUlryMJwKCEXxA.get('title')
   nDNzpfQauVFbRHjedUlryMJwKCEXmi =nDNzpfQauVFbRHjedUlryMJwKCEXxA.get('id')
   nDNzpfQauVFbRHjedUlryMJwKCEXos =nDNzpfQauVFbRHjedUlryMJwKCEXxA.get('thumbnail')
   nDNzpfQauVFbRHjedUlryMJwKCEXot =nDNzpfQauVFbRHjedUlryMJwKCEXxA.get('mpaa')
   nDNzpfQauVFbRHjedUlryMJwKCEXoh =nDNzpfQauVFbRHjedUlryMJwKCEXxA.get('duration')
   nDNzpfQauVFbRHjedUlryMJwKCEXog =nDNzpfQauVFbRHjedUlryMJwKCEXxA.get('asis')
   nDNzpfQauVFbRHjedUlryMJwKCEXoG =nDNzpfQauVFbRHjedUlryMJwKCEXxA.get('badge')
   nDNzpfQauVFbRHjedUlryMJwKCEXoO =nDNzpfQauVFbRHjedUlryMJwKCEXxA.get('year')
   nDNzpfQauVFbRHjedUlryMJwKCEXoq=nDNzpfQauVFbRHjedUlryMJwKCEXxA.get('seasonList')
   nDNzpfQauVFbRHjedUlryMJwKCEXoP =nDNzpfQauVFbRHjedUlryMJwKCEXxA.get('genreList')
   if nDNzpfQauVFbRHjedUlryMJwKCEXog in['TVSHOW','EDUCATION']: 
    nDNzpfQauVFbRHjedUlryMJwKCEXoL ='SEASON_LIST'
    nDNzpfQauVFbRHjedUlryMJwKCEXoS={'mediatype':'tvshow','title':nDNzpfQauVFbRHjedUlryMJwKCEXxo,'mpaa':nDNzpfQauVFbRHjedUlryMJwKCEXot,'genre':nDNzpfQauVFbRHjedUlryMJwKCEXoP,'year':nDNzpfQauVFbRHjedUlryMJwKCEXoO,'plot':'Year : %s\nSeason : %s'%(nDNzpfQauVFbRHjedUlryMJwKCEXoO,nDNzpfQauVFbRHjedUlryMJwKCEXoq),}
    nDNzpfQauVFbRHjedUlryMJwKCEXxv =nDNzpfQauVFbRHjedUlryMJwKCEXgY
   else:
    nDNzpfQauVFbRHjedUlryMJwKCEXoL ='MOVIE'
    nDNzpfQauVFbRHjedUlryMJwKCEXoS={'mediatype':'movie','title':nDNzpfQauVFbRHjedUlryMJwKCEXxo,'mpaa':nDNzpfQauVFbRHjedUlryMJwKCEXot,'genre':nDNzpfQauVFbRHjedUlryMJwKCEXoP,'duration':nDNzpfQauVFbRHjedUlryMJwKCEXoh,'year':nDNzpfQauVFbRHjedUlryMJwKCEXoO,'plot':'(%s)'%(nDNzpfQauVFbRHjedUlryMJwKCEXot),}
    nDNzpfQauVFbRHjedUlryMJwKCEXxv =nDNzpfQauVFbRHjedUlryMJwKCEXgT
    nDNzpfQauVFbRHjedUlryMJwKCEXxo +=' (%s)'%(nDNzpfQauVFbRHjedUlryMJwKCEXmo(nDNzpfQauVFbRHjedUlryMJwKCEXoO))
   nDNzpfQauVFbRHjedUlryMJwKCEXxm={'mode':nDNzpfQauVFbRHjedUlryMJwKCEXoL,'id':nDNzpfQauVFbRHjedUlryMJwKCEXmi,'asis':nDNzpfQauVFbRHjedUlryMJwKCEXog,'seasonList':nDNzpfQauVFbRHjedUlryMJwKCEXoq,'title':nDNzpfQauVFbRHjedUlryMJwKCEXxo,'thumbnail':nDNzpfQauVFbRHjedUlryMJwKCEXos,'year':nDNzpfQauVFbRHjedUlryMJwKCEXoO,}
   if nDNzpfQauVFbRHjedUlryMJwKCEXSg.get_settings_makebookmark():
    nDNzpfQauVFbRHjedUlryMJwKCEXoT={'videoid':nDNzpfQauVFbRHjedUlryMJwKCEXmi,'vidtype':'movie' if nDNzpfQauVFbRHjedUlryMJwKCEXxY=='MOVIES' else 'tvshow','vtitle':nDNzpfQauVFbRHjedUlryMJwKCEXxo,'vsubtitle':'',}
    nDNzpfQauVFbRHjedUlryMJwKCEXoY=json.dumps(nDNzpfQauVFbRHjedUlryMJwKCEXoT)
    nDNzpfQauVFbRHjedUlryMJwKCEXoY=urllib.parse.quote(nDNzpfQauVFbRHjedUlryMJwKCEXoY)
    nDNzpfQauVFbRHjedUlryMJwKCEXok='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(nDNzpfQauVFbRHjedUlryMJwKCEXoY)
    nDNzpfQauVFbRHjedUlryMJwKCEXoA=[('(통합) 찜 영상에 추가',nDNzpfQauVFbRHjedUlryMJwKCEXok)]
   else:
    nDNzpfQauVFbRHjedUlryMJwKCEXoA=nDNzpfQauVFbRHjedUlryMJwKCEXgL
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.add_dir(nDNzpfQauVFbRHjedUlryMJwKCEXxo,sublabel=nDNzpfQauVFbRHjedUlryMJwKCEXoG,img=nDNzpfQauVFbRHjedUlryMJwKCEXos,infoLabels=nDNzpfQauVFbRHjedUlryMJwKCEXoS,isFolder=nDNzpfQauVFbRHjedUlryMJwKCEXxv,params=nDNzpfQauVFbRHjedUlryMJwKCEXxm,ContextMenu=nDNzpfQauVFbRHjedUlryMJwKCEXoA)
  if nDNzpfQauVFbRHjedUlryMJwKCEXoW:
   nDNzpfQauVFbRHjedUlryMJwKCEXxm['mode'] ='CATEGORY_LIST' 
   nDNzpfQauVFbRHjedUlryMJwKCEXxm['collectionId']=nDNzpfQauVFbRHjedUlryMJwKCEXoi 
   nDNzpfQauVFbRHjedUlryMJwKCEXxm['vType'] =nDNzpfQauVFbRHjedUlryMJwKCEXxY 
   nDNzpfQauVFbRHjedUlryMJwKCEXxm['page'] =nDNzpfQauVFbRHjedUlryMJwKCEXmo(nDNzpfQauVFbRHjedUlryMJwKCEXoB+1)
   nDNzpfQauVFbRHjedUlryMJwKCEXxo='[B]%s >>[/B]'%'다음 페이지'
   nDNzpfQauVFbRHjedUlryMJwKCEXoc=nDNzpfQauVFbRHjedUlryMJwKCEXmo(nDNzpfQauVFbRHjedUlryMJwKCEXoB+1)
   nDNzpfQauVFbRHjedUlryMJwKCEXxg=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.add_dir(nDNzpfQauVFbRHjedUlryMJwKCEXxo,sublabel=nDNzpfQauVFbRHjedUlryMJwKCEXoc,img=nDNzpfQauVFbRHjedUlryMJwKCEXxg,infoLabels=nDNzpfQauVFbRHjedUlryMJwKCEXgL,isFolder=nDNzpfQauVFbRHjedUlryMJwKCEXgY,params=nDNzpfQauVFbRHjedUlryMJwKCEXxm)
  if nDNzpfQauVFbRHjedUlryMJwKCEXxY=='TVSHOWS':xbmcplugin.setContent(nDNzpfQauVFbRHjedUlryMJwKCEXSg._addon_handle,'tvshows')
  else:xbmcplugin.setContent(nDNzpfQauVFbRHjedUlryMJwKCEXSg._addon_handle,'movies')
  xbmcplugin.endOfDirectory(nDNzpfQauVFbRHjedUlryMJwKCEXSg._addon_handle,cacheToDisc=nDNzpfQauVFbRHjedUlryMJwKCEXgT)
 def dp_Season_List(nDNzpfQauVFbRHjedUlryMJwKCEXSg,args):
  nDNzpfQauVFbRHjedUlryMJwKCEXiS =args.get('title')
  nDNzpfQauVFbRHjedUlryMJwKCEXix =args.get('id')
  nDNzpfQauVFbRHjedUlryMJwKCEXog =args.get('asis')
  nDNzpfQauVFbRHjedUlryMJwKCEXoq =args.get('seasonList')
  nDNzpfQauVFbRHjedUlryMJwKCEXos =args.get('thumbnail')
  nDNzpfQauVFbRHjedUlryMJwKCEXoO =args.get('year')
  if nDNzpfQauVFbRHjedUlryMJwKCEXoq in['',nDNzpfQauVFbRHjedUlryMJwKCEXgL]:
   nDNzpfQauVFbRHjedUlryMJwKCEXoq=nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.Get_vInfo(nDNzpfQauVFbRHjedUlryMJwKCEXix).get('seasonList')
  if nDNzpfQauVFbRHjedUlryMJwKCEXms(nDNzpfQauVFbRHjedUlryMJwKCEXoq.split(','))>1:
   for nDNzpfQauVFbRHjedUlryMJwKCEXio in nDNzpfQauVFbRHjedUlryMJwKCEXoq.split(','):
    nDNzpfQauVFbRHjedUlryMJwKCEXxo='시즌 '+nDNzpfQauVFbRHjedUlryMJwKCEXio
    nDNzpfQauVFbRHjedUlryMJwKCEXoS={'mediatype':'tvshow','plot':'%s (%s)'%(nDNzpfQauVFbRHjedUlryMJwKCEXiS,nDNzpfQauVFbRHjedUlryMJwKCEXoO),}
    nDNzpfQauVFbRHjedUlryMJwKCEXxm={'mode':'EPISODE_LIST','programid':nDNzpfQauVFbRHjedUlryMJwKCEXix,'programnm':nDNzpfQauVFbRHjedUlryMJwKCEXiS,'season':nDNzpfQauVFbRHjedUlryMJwKCEXio,'asis':nDNzpfQauVFbRHjedUlryMJwKCEXog,'programimg':nDNzpfQauVFbRHjedUlryMJwKCEXos,}
    nDNzpfQauVFbRHjedUlryMJwKCEXis=nDNzpfQauVFbRHjedUlryMJwKCEXos.replace('\'','\"')
    nDNzpfQauVFbRHjedUlryMJwKCEXis=json.loads(nDNzpfQauVFbRHjedUlryMJwKCEXis)
    nDNzpfQauVFbRHjedUlryMJwKCEXSg.add_dir(nDNzpfQauVFbRHjedUlryMJwKCEXxo,sublabel='',img=nDNzpfQauVFbRHjedUlryMJwKCEXis,infoLabels=nDNzpfQauVFbRHjedUlryMJwKCEXoS,isFolder=nDNzpfQauVFbRHjedUlryMJwKCEXgY,params=nDNzpfQauVFbRHjedUlryMJwKCEXxm)
   xbmcplugin.setContent(nDNzpfQauVFbRHjedUlryMJwKCEXSg._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(nDNzpfQauVFbRHjedUlryMJwKCEXSg._addon_handle,cacheToDisc=nDNzpfQauVFbRHjedUlryMJwKCEXgT)
  else:
   nDNzpfQauVFbRHjedUlryMJwKCEXig={'programid':nDNzpfQauVFbRHjedUlryMJwKCEXix,'programnm':nDNzpfQauVFbRHjedUlryMJwKCEXiS,'season':nDNzpfQauVFbRHjedUlryMJwKCEXoq,'programimg':nDNzpfQauVFbRHjedUlryMJwKCEXos,}
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.dp_Episode_List(nDNzpfQauVFbRHjedUlryMJwKCEXig)
 def dp_Episode_List(nDNzpfQauVFbRHjedUlryMJwKCEXSg,args):
  nDNzpfQauVFbRHjedUlryMJwKCEXix =args.get('programid')
  nDNzpfQauVFbRHjedUlryMJwKCEXiS =args.get('programnm')
  nDNzpfQauVFbRHjedUlryMJwKCEXim =args.get('season')
  nDNzpfQauVFbRHjedUlryMJwKCEXiv =args.get('programimg')
  nDNzpfQauVFbRHjedUlryMJwKCEXiI=nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.Get_Episode_List(nDNzpfQauVFbRHjedUlryMJwKCEXix,nDNzpfQauVFbRHjedUlryMJwKCEXim)
  for nDNzpfQauVFbRHjedUlryMJwKCEXio in nDNzpfQauVFbRHjedUlryMJwKCEXiI:
   nDNzpfQauVFbRHjedUlryMJwKCEXih =nDNzpfQauVFbRHjedUlryMJwKCEXio.get('title')
   nDNzpfQauVFbRHjedUlryMJwKCEXiB =nDNzpfQauVFbRHjedUlryMJwKCEXio.get('id')
   nDNzpfQauVFbRHjedUlryMJwKCEXog =nDNzpfQauVFbRHjedUlryMJwKCEXio.get('asis')
   nDNzpfQauVFbRHjedUlryMJwKCEXos =nDNzpfQauVFbRHjedUlryMJwKCEXio.get('thumbnail')
   nDNzpfQauVFbRHjedUlryMJwKCEXot =nDNzpfQauVFbRHjedUlryMJwKCEXio.get('mpaa')
   nDNzpfQauVFbRHjedUlryMJwKCEXoh =nDNzpfQauVFbRHjedUlryMJwKCEXio.get('duration')
   nDNzpfQauVFbRHjedUlryMJwKCEXoO =nDNzpfQauVFbRHjedUlryMJwKCEXio.get('year')
   nDNzpfQauVFbRHjedUlryMJwKCEXiW =nDNzpfQauVFbRHjedUlryMJwKCEXio.get('episode')
   nDNzpfQauVFbRHjedUlryMJwKCEXoP =nDNzpfQauVFbRHjedUlryMJwKCEXio.get('genreList')
   nDNzpfQauVFbRHjedUlryMJwKCEXit =nDNzpfQauVFbRHjedUlryMJwKCEXio.get('desc')
   nDNzpfQauVFbRHjedUlryMJwKCEXiG ='%sx%s'%(nDNzpfQauVFbRHjedUlryMJwKCEXim,nDNzpfQauVFbRHjedUlryMJwKCEXiW)
   nDNzpfQauVFbRHjedUlryMJwKCEXxo ='%s. %s'%(nDNzpfQauVFbRHjedUlryMJwKCEXiG,nDNzpfQauVFbRHjedUlryMJwKCEXih)
   nDNzpfQauVFbRHjedUlryMJwKCEXoS={'mediatype':'episode','mpaa':nDNzpfQauVFbRHjedUlryMJwKCEXot,'genre':nDNzpfQauVFbRHjedUlryMJwKCEXoP,'duration':nDNzpfQauVFbRHjedUlryMJwKCEXoh,'year':nDNzpfQauVFbRHjedUlryMJwKCEXoO,'plot':'%s (%s)\n\n%s'%(nDNzpfQauVFbRHjedUlryMJwKCEXiS,nDNzpfQauVFbRHjedUlryMJwKCEXiG,nDNzpfQauVFbRHjedUlryMJwKCEXit),}
   nDNzpfQauVFbRHjedUlryMJwKCEXxm={'mode':'VOD','programid':nDNzpfQauVFbRHjedUlryMJwKCEXix,'programnm':nDNzpfQauVFbRHjedUlryMJwKCEXiS,'title':nDNzpfQauVFbRHjedUlryMJwKCEXxo,'season':nDNzpfQauVFbRHjedUlryMJwKCEXim,'id':nDNzpfQauVFbRHjedUlryMJwKCEXiB,'asis':nDNzpfQauVFbRHjedUlryMJwKCEXog,'thumbnail':nDNzpfQauVFbRHjedUlryMJwKCEXos,'programimg':nDNzpfQauVFbRHjedUlryMJwKCEXiv,}
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.add_dir(nDNzpfQauVFbRHjedUlryMJwKCEXxo,sublabel='',img=nDNzpfQauVFbRHjedUlryMJwKCEXos,infoLabels=nDNzpfQauVFbRHjedUlryMJwKCEXoS,isFolder=nDNzpfQauVFbRHjedUlryMJwKCEXgT,params=nDNzpfQauVFbRHjedUlryMJwKCEXxm)
  xbmcplugin.setContent(nDNzpfQauVFbRHjedUlryMJwKCEXSg._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(nDNzpfQauVFbRHjedUlryMJwKCEXSg._addon_handle,cacheToDisc=nDNzpfQauVFbRHjedUlryMJwKCEXgT)
 def play_VIDEO(nDNzpfQauVFbRHjedUlryMJwKCEXSg,args):
  nDNzpfQauVFbRHjedUlryMJwKCEXiO =args.get('id')
  nDNzpfQauVFbRHjedUlryMJwKCEXog =args.get('asis')
  if nDNzpfQauVFbRHjedUlryMJwKCEXog in['HIGHLIGHT']:
   nDNzpfQauVFbRHjedUlryMJwKCEXiq,nDNzpfQauVFbRHjedUlryMJwKCEXiP=nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.GetEventURL(nDNzpfQauVFbRHjedUlryMJwKCEXiO,nDNzpfQauVFbRHjedUlryMJwKCEXog)
  elif nDNzpfQauVFbRHjedUlryMJwKCEXog in['LIVE']:
   nDNzpfQauVFbRHjedUlryMJwKCEXiq,nDNzpfQauVFbRHjedUlryMJwKCEXiP=nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.GetEventURL_Live(nDNzpfQauVFbRHjedUlryMJwKCEXiO,nDNzpfQauVFbRHjedUlryMJwKCEXog)
  else:
   nDNzpfQauVFbRHjedUlryMJwKCEXiq,nDNzpfQauVFbRHjedUlryMJwKCEXiP=nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.GetBroadURL(nDNzpfQauVFbRHjedUlryMJwKCEXiO)
  nDNzpfQauVFbRHjedUlryMJwKCEXSg.addon_log('asis, url : %s - %s - %s'%(nDNzpfQauVFbRHjedUlryMJwKCEXog,nDNzpfQauVFbRHjedUlryMJwKCEXiO,nDNzpfQauVFbRHjedUlryMJwKCEXiq))
  if nDNzpfQauVFbRHjedUlryMJwKCEXiq=='':
   if nDNzpfQauVFbRHjedUlryMJwKCEXiP=='':
    nDNzpfQauVFbRHjedUlryMJwKCEXSg.addon_noti(__language__(30907).encode('utf8'))
   else:
    nDNzpfQauVFbRHjedUlryMJwKCEXSg.addon_noti(nDNzpfQauVFbRHjedUlryMJwKCEXiP)
   return
  nDNzpfQauVFbRHjedUlryMJwKCEXiL='PCID=%s;token=%s;member_srl=%s;NEXT_LOCALE=%s;bm_mi=%s;ak_bmsc=%s;bm_sv=%s'%(nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.CP['SESSION']['PCID'],nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.CP['SESSION']['token'],nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.CP['SESSION']['member_srl'],nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.CP['SESSION']['NEXT_LOCALE'],nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.CP['SESSION']['bm_mi'],nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.CP['SESSION']['ak_bmsc'],nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.CP['SESSION']['bm_sv'],)
  nDNzpfQauVFbRHjedUlryMJwKCEXiT='%s|Cookie=%s'%(nDNzpfQauVFbRHjedUlryMJwKCEXiq,nDNzpfQauVFbRHjedUlryMJwKCEXiL)
  nDNzpfQauVFbRHjedUlryMJwKCEXiY=xbmcgui.ListItem(path=nDNzpfQauVFbRHjedUlryMJwKCEXiT)
  nDNzpfQauVFbRHjedUlryMJwKCEXik=nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.Get_Url_PostFix(nDNzpfQauVFbRHjedUlryMJwKCEXiT) 
  nDNzpfQauVFbRHjedUlryMJwKCEXSg.addon_log('post_fix : '+nDNzpfQauVFbRHjedUlryMJwKCEXik)
  if nDNzpfQauVFbRHjedUlryMJwKCEXiP:
   nDNzpfQauVFbRHjedUlryMJwKCEXiA =nDNzpfQauVFbRHjedUlryMJwKCEXiP 
   if nDNzpfQauVFbRHjedUlryMJwKCEXik=='m3u8':
    nDNzpfQauVFbRHjedUlryMJwKCEXic ='hls' 
   else:
    nDNzpfQauVFbRHjedUlryMJwKCEXic ='mpd' 
   nDNzpfQauVFbRHjedUlryMJwKCEXsS ='com.widevine.alpha'
   nDNzpfQauVFbRHjedUlryMJwKCEXsx =inputstreamhelper.Helper(nDNzpfQauVFbRHjedUlryMJwKCEXic,drm='widevine')
   if nDNzpfQauVFbRHjedUlryMJwKCEXsx.check_inputstream():
    nDNzpfQauVFbRHjedUlryMJwKCEXso,nDNzpfQauVFbRHjedUlryMJwKCEXsi,nDNzpfQauVFbRHjedUlryMJwKCEXsg=nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.Make_authHeader()
    nDNzpfQauVFbRHjedUlryMJwKCEXsm={'traceparent':nDNzpfQauVFbRHjedUlryMJwKCEXso,'tracestate':nDNzpfQauVFbRHjedUlryMJwKCEXsi,'newrelic':nDNzpfQauVFbRHjedUlryMJwKCEXsg,'content-type':'application/octet-stream','User-Agent':nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.USER_AGENT,'Cookie':nDNzpfQauVFbRHjedUlryMJwKCEXiL,}
    nDNzpfQauVFbRHjedUlryMJwKCEXsv=nDNzpfQauVFbRHjedUlryMJwKCEXiA+'|'+urllib.parse.urlencode(nDNzpfQauVFbRHjedUlryMJwKCEXsm)+'|R{SSM}|'
    nDNzpfQauVFbRHjedUlryMJwKCEXiY.setProperty('inputstream',nDNzpfQauVFbRHjedUlryMJwKCEXsx.inputstream_addon)
    nDNzpfQauVFbRHjedUlryMJwKCEXiY.setProperty('inputstream.adaptive.manifest_type',nDNzpfQauVFbRHjedUlryMJwKCEXic)
    nDNzpfQauVFbRHjedUlryMJwKCEXiY.setProperty('inputstream.adaptive.license_type',nDNzpfQauVFbRHjedUlryMJwKCEXsS)
    nDNzpfQauVFbRHjedUlryMJwKCEXiY.setProperty('inputstream.adaptive.license_key',nDNzpfQauVFbRHjedUlryMJwKCEXsv)
    nDNzpfQauVFbRHjedUlryMJwKCEXiY.setProperty('inputstream.adaptive.stream_headers','User-Agent=%s&Cookie=%s'%(nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.USER_AGENT,nDNzpfQauVFbRHjedUlryMJwKCEXiL))
    nDNzpfQauVFbRHjedUlryMJwKCEXiY.setMimeType('application/dash+xml')
    nDNzpfQauVFbRHjedUlryMJwKCEXiY.setContentLookup(nDNzpfQauVFbRHjedUlryMJwKCEXgT)
  xbmcplugin.setResolvedUrl(nDNzpfQauVFbRHjedUlryMJwKCEXSg._addon_handle,nDNzpfQauVFbRHjedUlryMJwKCEXgY,nDNzpfQauVFbRHjedUlryMJwKCEXiY)
  try:
   if nDNzpfQauVFbRHjedUlryMJwKCEXog=='MOVIE':
    nDNzpfQauVFbRHjedUlryMJwKCEXsI='movie'
    nDNzpfQauVFbRHjedUlryMJwKCEXxm={'code':nDNzpfQauVFbRHjedUlryMJwKCEXiO,'asis':nDNzpfQauVFbRHjedUlryMJwKCEXog,'title':args.get('title'),'img':args.get('thumbnail'),}
    nDNzpfQauVFbRHjedUlryMJwKCEXSg.Save_Watched_List(nDNzpfQauVFbRHjedUlryMJwKCEXsI,nDNzpfQauVFbRHjedUlryMJwKCEXxm)
   elif nDNzpfQauVFbRHjedUlryMJwKCEXog=='TVSHOW':
    nDNzpfQauVFbRHjedUlryMJwKCEXsI='tvshow'
    nDNzpfQauVFbRHjedUlryMJwKCEXxm={'code':args.get('programid'),'asis':nDNzpfQauVFbRHjedUlryMJwKCEXog,'title':'%s <%s>'%(args.get('title'),args.get('programnm')),'img':args.get('programimg'),}
    nDNzpfQauVFbRHjedUlryMJwKCEXSg.Save_Watched_List(nDNzpfQauVFbRHjedUlryMJwKCEXsI,nDNzpfQauVFbRHjedUlryMJwKCEXxm)
  except:
   nDNzpfQauVFbRHjedUlryMJwKCEXgL
 def dp_Global_Search(nDNzpfQauVFbRHjedUlryMJwKCEXSg,args):
  nDNzpfQauVFbRHjedUlryMJwKCEXoL=args.get('mode')
  if nDNzpfQauVFbRHjedUlryMJwKCEXoL=='TOTAL_SEARCH':
   nDNzpfQauVFbRHjedUlryMJwKCEXsh='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   nDNzpfQauVFbRHjedUlryMJwKCEXsh='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(nDNzpfQauVFbRHjedUlryMJwKCEXsh)
 def dp_Bookmark_Menu(nDNzpfQauVFbRHjedUlryMJwKCEXSg,args):
  nDNzpfQauVFbRHjedUlryMJwKCEXsh='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(nDNzpfQauVFbRHjedUlryMJwKCEXsh)
 def dp_Search_List(nDNzpfQauVFbRHjedUlryMJwKCEXSg,args):
  nDNzpfQauVFbRHjedUlryMJwKCEXoB =nDNzpfQauVFbRHjedUlryMJwKCEXgc(args.get('page'))
  if 'search_key' in args:
   nDNzpfQauVFbRHjedUlryMJwKCEXsB=args.get('search_key')
  else:
   nDNzpfQauVFbRHjedUlryMJwKCEXsB=nDNzpfQauVFbRHjedUlryMJwKCEXSg.get_keyboard_input(__language__(30908).encode('utf-8'))
   if not nDNzpfQauVFbRHjedUlryMJwKCEXsB:
    return
  nDNzpfQauVFbRHjedUlryMJwKCEXsW,nDNzpfQauVFbRHjedUlryMJwKCEXoW=nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.Get_Search_List(nDNzpfQauVFbRHjedUlryMJwKCEXsB,nDNzpfQauVFbRHjedUlryMJwKCEXoB)
  for nDNzpfQauVFbRHjedUlryMJwKCEXst in nDNzpfQauVFbRHjedUlryMJwKCEXsW:
   nDNzpfQauVFbRHjedUlryMJwKCEXmi =nDNzpfQauVFbRHjedUlryMJwKCEXst.get('id')
   nDNzpfQauVFbRHjedUlryMJwKCEXxo =nDNzpfQauVFbRHjedUlryMJwKCEXst.get('title')
   nDNzpfQauVFbRHjedUlryMJwKCEXog =nDNzpfQauVFbRHjedUlryMJwKCEXst.get('asis')
   nDNzpfQauVFbRHjedUlryMJwKCEXos =nDNzpfQauVFbRHjedUlryMJwKCEXst.get('thumbnail')
   nDNzpfQauVFbRHjedUlryMJwKCEXot =nDNzpfQauVFbRHjedUlryMJwKCEXst.get('mpaa')
   nDNzpfQauVFbRHjedUlryMJwKCEXoO =nDNzpfQauVFbRHjedUlryMJwKCEXst.get('year')
   nDNzpfQauVFbRHjedUlryMJwKCEXoh =nDNzpfQauVFbRHjedUlryMJwKCEXst.get('duration')
   nDNzpfQauVFbRHjedUlryMJwKCEXoG =nDNzpfQauVFbRHjedUlryMJwKCEXst.get('badge')
   if nDNzpfQauVFbRHjedUlryMJwKCEXog=='TVSHOW': 
    nDNzpfQauVFbRHjedUlryMJwKCEXoL ='SEASON_LIST'
    nDNzpfQauVFbRHjedUlryMJwKCEXoS={'mediatype':'tvshow','title':nDNzpfQauVFbRHjedUlryMJwKCEXxo,'mpaa':nDNzpfQauVFbRHjedUlryMJwKCEXot,'year':nDNzpfQauVFbRHjedUlryMJwKCEXoO,'plot':'Year : %s'%(nDNzpfQauVFbRHjedUlryMJwKCEXoO),}
    nDNzpfQauVFbRHjedUlryMJwKCEXxv =nDNzpfQauVFbRHjedUlryMJwKCEXgY
   elif nDNzpfQauVFbRHjedUlryMJwKCEXog=='MOVIE':
    nDNzpfQauVFbRHjedUlryMJwKCEXoL ='MOVIE'
    nDNzpfQauVFbRHjedUlryMJwKCEXoS={'mediatype':'movie','title':nDNzpfQauVFbRHjedUlryMJwKCEXxo,'mpaa':nDNzpfQauVFbRHjedUlryMJwKCEXot,'duration':nDNzpfQauVFbRHjedUlryMJwKCEXoh,'year':nDNzpfQauVFbRHjedUlryMJwKCEXoO,'plot':'(%s)'%(nDNzpfQauVFbRHjedUlryMJwKCEXot),}
    nDNzpfQauVFbRHjedUlryMJwKCEXxv =nDNzpfQauVFbRHjedUlryMJwKCEXgT
    nDNzpfQauVFbRHjedUlryMJwKCEXxo +=' (%s)'%(nDNzpfQauVFbRHjedUlryMJwKCEXmo(nDNzpfQauVFbRHjedUlryMJwKCEXoO))
   elif nDNzpfQauVFbRHjedUlryMJwKCEXog=='HIGHLIGHT':
    nDNzpfQauVFbRHjedUlryMJwKCEXoL ='HIGHLIGHT'
    nDNzpfQauVFbRHjedUlryMJwKCEXoS={'mediatype':'episode','title':nDNzpfQauVFbRHjedUlryMJwKCEXxo,'duration':nDNzpfQauVFbRHjedUlryMJwKCEXoh,'plot':nDNzpfQauVFbRHjedUlryMJwKCEXoL,}
    nDNzpfQauVFbRHjedUlryMJwKCEXxv =nDNzpfQauVFbRHjedUlryMJwKCEXgT
   elif nDNzpfQauVFbRHjedUlryMJwKCEXog=='LIVE':
    nDNzpfQauVFbRHjedUlryMJwKCEXoL ='LIVE'
    nDNzpfQauVFbRHjedUlryMJwKCEXoS={'mediatype':'episode','title':nDNzpfQauVFbRHjedUlryMJwKCEXxo,'plot':nDNzpfQauVFbRHjedUlryMJwKCEXoL,}
    nDNzpfQauVFbRHjedUlryMJwKCEXxv =nDNzpfQauVFbRHjedUlryMJwKCEXgT
   nDNzpfQauVFbRHjedUlryMJwKCEXxm={'mode':nDNzpfQauVFbRHjedUlryMJwKCEXoL,'id':nDNzpfQauVFbRHjedUlryMJwKCEXmi,'asis':nDNzpfQauVFbRHjedUlryMJwKCEXog,'seasonList':'','title':nDNzpfQauVFbRHjedUlryMJwKCEXxo,'thumbnail':json.dumps(nDNzpfQauVFbRHjedUlryMJwKCEXos,separators=(',',':')),'year':nDNzpfQauVFbRHjedUlryMJwKCEXoO,}
   if nDNzpfQauVFbRHjedUlryMJwKCEXSg.get_settings_makebookmark()and nDNzpfQauVFbRHjedUlryMJwKCEXog not in['HIGHLIGHT','']:
    nDNzpfQauVFbRHjedUlryMJwKCEXoT={'videoid':nDNzpfQauVFbRHjedUlryMJwKCEXmi,'vidtype':'movie' if nDNzpfQauVFbRHjedUlryMJwKCEXog=='MOVIE' else 'tvshow','vtitle':nDNzpfQauVFbRHjedUlryMJwKCEXxo,'vsubtitle':'',}
    nDNzpfQauVFbRHjedUlryMJwKCEXoY=json.dumps(nDNzpfQauVFbRHjedUlryMJwKCEXoT)
    nDNzpfQauVFbRHjedUlryMJwKCEXoY=urllib.parse.quote(nDNzpfQauVFbRHjedUlryMJwKCEXoY)
    nDNzpfQauVFbRHjedUlryMJwKCEXok='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(nDNzpfQauVFbRHjedUlryMJwKCEXoY)
    nDNzpfQauVFbRHjedUlryMJwKCEXoA=[('(통합) 찜 영상에 추가',nDNzpfQauVFbRHjedUlryMJwKCEXok)]
   else:
    nDNzpfQauVFbRHjedUlryMJwKCEXoA=nDNzpfQauVFbRHjedUlryMJwKCEXgL
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.add_dir(nDNzpfQauVFbRHjedUlryMJwKCEXxo,sublabel=nDNzpfQauVFbRHjedUlryMJwKCEXoG,img=nDNzpfQauVFbRHjedUlryMJwKCEXos,infoLabels=nDNzpfQauVFbRHjedUlryMJwKCEXoS,isFolder=nDNzpfQauVFbRHjedUlryMJwKCEXxv,params=nDNzpfQauVFbRHjedUlryMJwKCEXxm,ContextMenu=nDNzpfQauVFbRHjedUlryMJwKCEXoA)
  if nDNzpfQauVFbRHjedUlryMJwKCEXoW:
   nDNzpfQauVFbRHjedUlryMJwKCEXxm={}
   nDNzpfQauVFbRHjedUlryMJwKCEXxm['mode'] ='LOCAL_SEARCH'
   nDNzpfQauVFbRHjedUlryMJwKCEXxm['search_key']=nDNzpfQauVFbRHjedUlryMJwKCEXsB
   nDNzpfQauVFbRHjedUlryMJwKCEXxm['page'] =nDNzpfQauVFbRHjedUlryMJwKCEXmo(nDNzpfQauVFbRHjedUlryMJwKCEXoB+1)
   nDNzpfQauVFbRHjedUlryMJwKCEXxo='[B]%s >>[/B]'%'다음 페이지'
   nDNzpfQauVFbRHjedUlryMJwKCEXoc=nDNzpfQauVFbRHjedUlryMJwKCEXmo(nDNzpfQauVFbRHjedUlryMJwKCEXoB+1)
   nDNzpfQauVFbRHjedUlryMJwKCEXxg=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.add_dir(nDNzpfQauVFbRHjedUlryMJwKCEXxo,sublabel=nDNzpfQauVFbRHjedUlryMJwKCEXoc,img=nDNzpfQauVFbRHjedUlryMJwKCEXxg,infoLabels=nDNzpfQauVFbRHjedUlryMJwKCEXgL,isFolder=nDNzpfQauVFbRHjedUlryMJwKCEXgY,params=nDNzpfQauVFbRHjedUlryMJwKCEXxm)
  xbmcplugin.setContent(nDNzpfQauVFbRHjedUlryMJwKCEXSg._addon_handle,'movies')
  xbmcplugin.endOfDirectory(nDNzpfQauVFbRHjedUlryMJwKCEXSg._addon_handle,cacheToDisc=nDNzpfQauVFbRHjedUlryMJwKCEXgY)
  if args.get('historyyn')=='Y':nDNzpfQauVFbRHjedUlryMJwKCEXSg.Save_Searched_List(nDNzpfQauVFbRHjedUlryMJwKCEXsB)
 def Load_List_File(nDNzpfQauVFbRHjedUlryMJwKCEXSg,nDNzpfQauVFbRHjedUlryMJwKCEXsI): 
  try:
   if nDNzpfQauVFbRHjedUlryMJwKCEXsI=='search':
    nDNzpfQauVFbRHjedUlryMJwKCEXsG=nDNzpfQauVFbRHjedUlryMJwKCEXSs
   elif nDNzpfQauVFbRHjedUlryMJwKCEXsI in['tvshow','movie']:
    nDNzpfQauVFbRHjedUlryMJwKCEXsG=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%nDNzpfQauVFbRHjedUlryMJwKCEXsI))
   else:
    return[]
   fp=nDNzpfQauVFbRHjedUlryMJwKCEXmS(nDNzpfQauVFbRHjedUlryMJwKCEXsG,'r',-1,'utf-8')
   nDNzpfQauVFbRHjedUlryMJwKCEXsO=fp.readlines()
   fp.close()
  except:
   nDNzpfQauVFbRHjedUlryMJwKCEXsO=[]
  return nDNzpfQauVFbRHjedUlryMJwKCEXsO
 def Save_Watched_List(nDNzpfQauVFbRHjedUlryMJwKCEXSg,nDNzpfQauVFbRHjedUlryMJwKCEXsI,nDNzpfQauVFbRHjedUlryMJwKCEXSI):
  try:
   nDNzpfQauVFbRHjedUlryMJwKCEXsq=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%nDNzpfQauVFbRHjedUlryMJwKCEXsI))
   nDNzpfQauVFbRHjedUlryMJwKCEXsP=nDNzpfQauVFbRHjedUlryMJwKCEXSg.Load_List_File(nDNzpfQauVFbRHjedUlryMJwKCEXsI) 
   fp=nDNzpfQauVFbRHjedUlryMJwKCEXmS(nDNzpfQauVFbRHjedUlryMJwKCEXsq,'w',-1,'utf-8')
   nDNzpfQauVFbRHjedUlryMJwKCEXsL=urllib.parse.urlencode(nDNzpfQauVFbRHjedUlryMJwKCEXSI)
   nDNzpfQauVFbRHjedUlryMJwKCEXsL=nDNzpfQauVFbRHjedUlryMJwKCEXsL+'\n'
   fp.write(nDNzpfQauVFbRHjedUlryMJwKCEXsL)
   nDNzpfQauVFbRHjedUlryMJwKCEXsT=0
   for nDNzpfQauVFbRHjedUlryMJwKCEXsY in nDNzpfQauVFbRHjedUlryMJwKCEXsP:
    nDNzpfQauVFbRHjedUlryMJwKCEXsk=nDNzpfQauVFbRHjedUlryMJwKCEXgA(urllib.parse.parse_qsl(nDNzpfQauVFbRHjedUlryMJwKCEXsY))
    nDNzpfQauVFbRHjedUlryMJwKCEXsA=nDNzpfQauVFbRHjedUlryMJwKCEXSI.get('code').strip()
    nDNzpfQauVFbRHjedUlryMJwKCEXsc=nDNzpfQauVFbRHjedUlryMJwKCEXsk.get('code').strip()
    if nDNzpfQauVFbRHjedUlryMJwKCEXsA!=nDNzpfQauVFbRHjedUlryMJwKCEXsc:
     fp.write(nDNzpfQauVFbRHjedUlryMJwKCEXsY)
     nDNzpfQauVFbRHjedUlryMJwKCEXsT+=1
     if nDNzpfQauVFbRHjedUlryMJwKCEXsT>=50:break
   fp.close()
  except:
   nDNzpfQauVFbRHjedUlryMJwKCEXgL
 def Save_Searched_List(nDNzpfQauVFbRHjedUlryMJwKCEXSg,nDNzpfQauVFbRHjedUlryMJwKCEXsB):
  try:
   nDNzpfQauVFbRHjedUlryMJwKCEXsB=nDNzpfQauVFbRHjedUlryMJwKCEXsB.strip()
   nDNzpfQauVFbRHjedUlryMJwKCEXsP=nDNzpfQauVFbRHjedUlryMJwKCEXSg.Load_List_File('search') 
   fp=nDNzpfQauVFbRHjedUlryMJwKCEXmS(nDNzpfQauVFbRHjedUlryMJwKCEXSs,'w',-1,'utf-8')
   fp.write(nDNzpfQauVFbRHjedUlryMJwKCEXsB+'\n')
   nDNzpfQauVFbRHjedUlryMJwKCEXsT=0
   for nDNzpfQauVFbRHjedUlryMJwKCEXsY in nDNzpfQauVFbRHjedUlryMJwKCEXsP:
    nDNzpfQauVFbRHjedUlryMJwKCEXsY=nDNzpfQauVFbRHjedUlryMJwKCEXsY.strip()
    if nDNzpfQauVFbRHjedUlryMJwKCEXsB!=nDNzpfQauVFbRHjedUlryMJwKCEXsY:
     fp.write(nDNzpfQauVFbRHjedUlryMJwKCEXsY+'\n')
     nDNzpfQauVFbRHjedUlryMJwKCEXsT+=1
     if nDNzpfQauVFbRHjedUlryMJwKCEXsT>=50:break
   fp.close()
  except:
   nDNzpfQauVFbRHjedUlryMJwKCEXgL
 def dp_Search_History(nDNzpfQauVFbRHjedUlryMJwKCEXSg,args):
  nDNzpfQauVFbRHjedUlryMJwKCEXgS=nDNzpfQauVFbRHjedUlryMJwKCEXSg.Load_List_File('search')
  for nDNzpfQauVFbRHjedUlryMJwKCEXgx in nDNzpfQauVFbRHjedUlryMJwKCEXgS:
   nDNzpfQauVFbRHjedUlryMJwKCEXgx=nDNzpfQauVFbRHjedUlryMJwKCEXgx.strip()
   nDNzpfQauVFbRHjedUlryMJwKCEXxm={'mode':'LOCAL_SEARCH','search_key':nDNzpfQauVFbRHjedUlryMJwKCEXgx,'page':'1','historyyn':'Y',}
   nDNzpfQauVFbRHjedUlryMJwKCEXgo={'mode':'SEARCH_REMOVE','stype':'ONE','skey':nDNzpfQauVFbRHjedUlryMJwKCEXgx,}
   nDNzpfQauVFbRHjedUlryMJwKCEXgi=urllib.parse.urlencode(nDNzpfQauVFbRHjedUlryMJwKCEXgo)
   nDNzpfQauVFbRHjedUlryMJwKCEXoA=[('선택된 검색어 ( %s ) 삭제'%(nDNzpfQauVFbRHjedUlryMJwKCEXgx),'RunPlugin(plugin://plugin.video.coupangm/?%s)'%(nDNzpfQauVFbRHjedUlryMJwKCEXgi))]
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.add_dir(nDNzpfQauVFbRHjedUlryMJwKCEXgx,sublabel='',img=nDNzpfQauVFbRHjedUlryMJwKCEXgL,infoLabels=nDNzpfQauVFbRHjedUlryMJwKCEXgL,isFolder=nDNzpfQauVFbRHjedUlryMJwKCEXgY,params=nDNzpfQauVFbRHjedUlryMJwKCEXxm,ContextMenu=nDNzpfQauVFbRHjedUlryMJwKCEXoA)
  nDNzpfQauVFbRHjedUlryMJwKCEXoS={'plot':'검색목록 전체를 삭제합니다.'}
  nDNzpfQauVFbRHjedUlryMJwKCEXxo='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  nDNzpfQauVFbRHjedUlryMJwKCEXxm={'mode':'SEARCH_REMOVE','stype':'ALL','skey':'-',}
  nDNzpfQauVFbRHjedUlryMJwKCEXxg=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  nDNzpfQauVFbRHjedUlryMJwKCEXSg.add_dir(nDNzpfQauVFbRHjedUlryMJwKCEXxo,sublabel='',img=nDNzpfQauVFbRHjedUlryMJwKCEXxg,infoLabels=nDNzpfQauVFbRHjedUlryMJwKCEXoS,isFolder=nDNzpfQauVFbRHjedUlryMJwKCEXgT,params=nDNzpfQauVFbRHjedUlryMJwKCEXxm,isLink=nDNzpfQauVFbRHjedUlryMJwKCEXgY)
  xbmcplugin.endOfDirectory(nDNzpfQauVFbRHjedUlryMJwKCEXSg._addon_handle,cacheToDisc=nDNzpfQauVFbRHjedUlryMJwKCEXgT)
 def dp_Listfile_Delete(nDNzpfQauVFbRHjedUlryMJwKCEXSg,args):
  nDNzpfQauVFbRHjedUlryMJwKCEXsI=args.get('stype')
  nDNzpfQauVFbRHjedUlryMJwKCEXgs =args.get('skey')
  nDNzpfQauVFbRHjedUlryMJwKCEXSB=xbmcgui.Dialog()
  if nDNzpfQauVFbRHjedUlryMJwKCEXsI=='ALL':
   nDNzpfQauVFbRHjedUlryMJwKCEXxB=nDNzpfQauVFbRHjedUlryMJwKCEXSB.yesno(__language__(30911).encode('utf8'),__language__(30906).encode('utf8'))
  elif nDNzpfQauVFbRHjedUlryMJwKCEXsI=='ONE':
   nDNzpfQauVFbRHjedUlryMJwKCEXxB=nDNzpfQauVFbRHjedUlryMJwKCEXSB.yesno(__language__(30912).encode('utf8'),__language__(30906).encode('utf8'))
  elif nDNzpfQauVFbRHjedUlryMJwKCEXsI in['tvshow','movie']:
   nDNzpfQauVFbRHjedUlryMJwKCEXxB=nDNzpfQauVFbRHjedUlryMJwKCEXSB.yesno(__language__(30913).encode('utf8'),__language__(30906).encode('utf8'))
  if nDNzpfQauVFbRHjedUlryMJwKCEXxB==nDNzpfQauVFbRHjedUlryMJwKCEXgT:sys.exit()
  nDNzpfQauVFbRHjedUlryMJwKCEXSg.Delete_List_File(nDNzpfQauVFbRHjedUlryMJwKCEXsI,skey=nDNzpfQauVFbRHjedUlryMJwKCEXgs)
  xbmc.executebuiltin("Container.Refresh")
 def Delete_List_File(nDNzpfQauVFbRHjedUlryMJwKCEXSg,nDNzpfQauVFbRHjedUlryMJwKCEXsI,skey='-'):
  if nDNzpfQauVFbRHjedUlryMJwKCEXsI=='ALL':
   try:
    nDNzpfQauVFbRHjedUlryMJwKCEXsG=nDNzpfQauVFbRHjedUlryMJwKCEXSs
    fp=nDNzpfQauVFbRHjedUlryMJwKCEXmS(nDNzpfQauVFbRHjedUlryMJwKCEXsG,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    nDNzpfQauVFbRHjedUlryMJwKCEXgL
  elif nDNzpfQauVFbRHjedUlryMJwKCEXsI=='ONE':
   try:
    nDNzpfQauVFbRHjedUlryMJwKCEXsG=nDNzpfQauVFbRHjedUlryMJwKCEXSs
    nDNzpfQauVFbRHjedUlryMJwKCEXsP=nDNzpfQauVFbRHjedUlryMJwKCEXSg.Load_List_File('search') 
    fp=nDNzpfQauVFbRHjedUlryMJwKCEXmS(nDNzpfQauVFbRHjedUlryMJwKCEXsG,'w',-1,'utf-8')
    for nDNzpfQauVFbRHjedUlryMJwKCEXsY in nDNzpfQauVFbRHjedUlryMJwKCEXsP:
     if skey!=nDNzpfQauVFbRHjedUlryMJwKCEXsY.strip():
      fp.write(nDNzpfQauVFbRHjedUlryMJwKCEXsY)
    fp.close()
   except:
    nDNzpfQauVFbRHjedUlryMJwKCEXgL
  elif nDNzpfQauVFbRHjedUlryMJwKCEXsI in['tvshow','movie']:
   try:
    nDNzpfQauVFbRHjedUlryMJwKCEXsG=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%nDNzpfQauVFbRHjedUlryMJwKCEXsI))
    fp=nDNzpfQauVFbRHjedUlryMJwKCEXmS(nDNzpfQauVFbRHjedUlryMJwKCEXsG,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    nDNzpfQauVFbRHjedUlryMJwKCEXgL
 def dp_Watch_List(nDNzpfQauVFbRHjedUlryMJwKCEXSg,args):
  nDNzpfQauVFbRHjedUlryMJwKCEXsI =args.get('stype')
  if nDNzpfQauVFbRHjedUlryMJwKCEXsI in['',nDNzpfQauVFbRHjedUlryMJwKCEXgL]:
   for nDNzpfQauVFbRHjedUlryMJwKCEXgm in nDNzpfQauVFbRHjedUlryMJwKCEXSi:
    nDNzpfQauVFbRHjedUlryMJwKCEXxo=nDNzpfQauVFbRHjedUlryMJwKCEXgm.get('title')
    nDNzpfQauVFbRHjedUlryMJwKCEXxm={'mode':nDNzpfQauVFbRHjedUlryMJwKCEXgm.get('mode'),'stype':nDNzpfQauVFbRHjedUlryMJwKCEXgm.get('stype'),}
    nDNzpfQauVFbRHjedUlryMJwKCEXSg.add_dir(nDNzpfQauVFbRHjedUlryMJwKCEXxo,sublabel='',img='',infoLabels=nDNzpfQauVFbRHjedUlryMJwKCEXgL,isFolder=nDNzpfQauVFbRHjedUlryMJwKCEXgY,params=nDNzpfQauVFbRHjedUlryMJwKCEXxm)
   xbmcplugin.endOfDirectory(nDNzpfQauVFbRHjedUlryMJwKCEXSg._addon_handle)
  else:
   nDNzpfQauVFbRHjedUlryMJwKCEXgv=nDNzpfQauVFbRHjedUlryMJwKCEXSg.Load_List_File(nDNzpfQauVFbRHjedUlryMJwKCEXsI)
   for nDNzpfQauVFbRHjedUlryMJwKCEXgI in nDNzpfQauVFbRHjedUlryMJwKCEXgv:
    nDNzpfQauVFbRHjedUlryMJwKCEXgh=nDNzpfQauVFbRHjedUlryMJwKCEXgA(urllib.parse.parse_qsl(nDNzpfQauVFbRHjedUlryMJwKCEXgI))
    nDNzpfQauVFbRHjedUlryMJwKCEXiO =nDNzpfQauVFbRHjedUlryMJwKCEXgh.get('code').strip()
    nDNzpfQauVFbRHjedUlryMJwKCEXxo =nDNzpfQauVFbRHjedUlryMJwKCEXgh.get('title').strip()
    nDNzpfQauVFbRHjedUlryMJwKCEXos =nDNzpfQauVFbRHjedUlryMJwKCEXgh.get('img').strip()
    nDNzpfQauVFbRHjedUlryMJwKCEXog =nDNzpfQauVFbRHjedUlryMJwKCEXgh.get('asis').strip()
    try:
     nDNzpfQauVFbRHjedUlryMJwKCEXos=nDNzpfQauVFbRHjedUlryMJwKCEXos.replace('\'','\"')
     nDNzpfQauVFbRHjedUlryMJwKCEXos=json.loads(nDNzpfQauVFbRHjedUlryMJwKCEXos)
    except:
     nDNzpfQauVFbRHjedUlryMJwKCEXgL
    nDNzpfQauVFbRHjedUlryMJwKCEXoS={}
    nDNzpfQauVFbRHjedUlryMJwKCEXoS['plot']=nDNzpfQauVFbRHjedUlryMJwKCEXxo
    if nDNzpfQauVFbRHjedUlryMJwKCEXsI=='movie':
     nDNzpfQauVFbRHjedUlryMJwKCEXoS['mediatype']='movie'
     nDNzpfQauVFbRHjedUlryMJwKCEXxm={'mode':'MOVIE','id':nDNzpfQauVFbRHjedUlryMJwKCEXiO,'asis':nDNzpfQauVFbRHjedUlryMJwKCEXog,'title':nDNzpfQauVFbRHjedUlryMJwKCEXxo,'thumbnail':nDNzpfQauVFbRHjedUlryMJwKCEXos,}
     nDNzpfQauVFbRHjedUlryMJwKCEXxv=nDNzpfQauVFbRHjedUlryMJwKCEXgT
    else:
     nDNzpfQauVFbRHjedUlryMJwKCEXoS['mediatype']='episode'
     nDNzpfQauVFbRHjedUlryMJwKCEXxm={'mode':'SEASON_LIST','id':nDNzpfQauVFbRHjedUlryMJwKCEXiO,'asis':nDNzpfQauVFbRHjedUlryMJwKCEXog,'title':nDNzpfQauVFbRHjedUlryMJwKCEXxo,'thumbnail':json.dumps(nDNzpfQauVFbRHjedUlryMJwKCEXos,separators=(',',':')),}
     nDNzpfQauVFbRHjedUlryMJwKCEXxv=nDNzpfQauVFbRHjedUlryMJwKCEXgY
    nDNzpfQauVFbRHjedUlryMJwKCEXSg.add_dir(nDNzpfQauVFbRHjedUlryMJwKCEXxo,sublabel='',img=nDNzpfQauVFbRHjedUlryMJwKCEXos,infoLabels=nDNzpfQauVFbRHjedUlryMJwKCEXoS,isFolder=nDNzpfQauVFbRHjedUlryMJwKCEXxv,params=nDNzpfQauVFbRHjedUlryMJwKCEXxm)
   nDNzpfQauVFbRHjedUlryMJwKCEXoS={'plot':'시청목록을 삭제합니다.'}
   nDNzpfQauVFbRHjedUlryMJwKCEXxo='*** 시청목록 삭제 ***'
   nDNzpfQauVFbRHjedUlryMJwKCEXxm={'mode':'MYVIEW_REMOVE','stype':nDNzpfQauVFbRHjedUlryMJwKCEXsI,'skey':'-',}
   nDNzpfQauVFbRHjedUlryMJwKCEXxg=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.add_dir(nDNzpfQauVFbRHjedUlryMJwKCEXxo,sublabel='',img=nDNzpfQauVFbRHjedUlryMJwKCEXxg,infoLabels=nDNzpfQauVFbRHjedUlryMJwKCEXoS,isFolder=nDNzpfQauVFbRHjedUlryMJwKCEXgT,params=nDNzpfQauVFbRHjedUlryMJwKCEXxm,isLink=nDNzpfQauVFbRHjedUlryMJwKCEXgY)
   if nDNzpfQauVFbRHjedUlryMJwKCEXsI=='movie':xbmcplugin.setContent(nDNzpfQauVFbRHjedUlryMJwKCEXSg._addon_handle,'movies')
   else:xbmcplugin.setContent(nDNzpfQauVFbRHjedUlryMJwKCEXSg._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(nDNzpfQauVFbRHjedUlryMJwKCEXSg._addon_handle,cacheToDisc=nDNzpfQauVFbRHjedUlryMJwKCEXgT)
 def dp_Set_Bookmark(nDNzpfQauVFbRHjedUlryMJwKCEXSg,args):
  nDNzpfQauVFbRHjedUlryMJwKCEXgB=urllib.parse.unquote(args.get('bm_param'))
  nDNzpfQauVFbRHjedUlryMJwKCEXgB=json.loads(nDNzpfQauVFbRHjedUlryMJwKCEXgB)
  nDNzpfQauVFbRHjedUlryMJwKCEXgW =nDNzpfQauVFbRHjedUlryMJwKCEXgB.get('videoid')
  nDNzpfQauVFbRHjedUlryMJwKCEXgt =nDNzpfQauVFbRHjedUlryMJwKCEXgB.get('vidtype')
  nDNzpfQauVFbRHjedUlryMJwKCEXgG =nDNzpfQauVFbRHjedUlryMJwKCEXgB.get('vtitle')
  nDNzpfQauVFbRHjedUlryMJwKCEXSB=xbmcgui.Dialog()
  nDNzpfQauVFbRHjedUlryMJwKCEXxB=nDNzpfQauVFbRHjedUlryMJwKCEXSB.yesno(__language__(30914).encode('utf8'),nDNzpfQauVFbRHjedUlryMJwKCEXgG+' \n\n'+__language__(30915))
  if nDNzpfQauVFbRHjedUlryMJwKCEXxB==nDNzpfQauVFbRHjedUlryMJwKCEXgT:return
  nDNzpfQauVFbRHjedUlryMJwKCEXgO=nDNzpfQauVFbRHjedUlryMJwKCEXSg.CoupangObj.GetBookmarkInfo(nDNzpfQauVFbRHjedUlryMJwKCEXgW,nDNzpfQauVFbRHjedUlryMJwKCEXgt)
  nDNzpfQauVFbRHjedUlryMJwKCEXgq=json.dumps(nDNzpfQauVFbRHjedUlryMJwKCEXgO)
  nDNzpfQauVFbRHjedUlryMJwKCEXgq=urllib.parse.quote(nDNzpfQauVFbRHjedUlryMJwKCEXgq)
  nDNzpfQauVFbRHjedUlryMJwKCEXok ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(nDNzpfQauVFbRHjedUlryMJwKCEXgq)
  xbmc.executebuiltin(nDNzpfQauVFbRHjedUlryMJwKCEXok)
 def coupang_main(nDNzpfQauVFbRHjedUlryMJwKCEXSg):
  nDNzpfQauVFbRHjedUlryMJwKCEXoL=nDNzpfQauVFbRHjedUlryMJwKCEXSg.main_params.get('mode',nDNzpfQauVFbRHjedUlryMJwKCEXgL)
  if nDNzpfQauVFbRHjedUlryMJwKCEXoL=='LOGOUT':
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.CP_logout()
   return
  nDNzpfQauVFbRHjedUlryMJwKCEXSg.option_check()
  if nDNzpfQauVFbRHjedUlryMJwKCEXoL is nDNzpfQauVFbRHjedUlryMJwKCEXgL:
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.dp_Main_List(nDNzpfQauVFbRHjedUlryMJwKCEXSg.main_params)
  elif nDNzpfQauVFbRHjedUlryMJwKCEXoL=='CATEGORY_GROUPLIST':
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.dp_Category_GroupList(nDNzpfQauVFbRHjedUlryMJwKCEXSg.main_params)
  elif nDNzpfQauVFbRHjedUlryMJwKCEXoL=='THEME_GROUPLIST':
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.dp_Theme_GroupList(nDNzpfQauVFbRHjedUlryMJwKCEXSg.main_params)
  elif nDNzpfQauVFbRHjedUlryMJwKCEXoL=='EVENT_GROUPLIST':
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.dp_Event_GroupList(nDNzpfQauVFbRHjedUlryMJwKCEXSg.main_params)
  elif nDNzpfQauVFbRHjedUlryMJwKCEXoL=='EVENT_GAMELIST':
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.dp_Event_GameList(nDNzpfQauVFbRHjedUlryMJwKCEXSg.main_params)
  elif nDNzpfQauVFbRHjedUlryMJwKCEXoL=='EVENT_LIST':
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.dp_Event_List(nDNzpfQauVFbRHjedUlryMJwKCEXSg.main_params)
  elif nDNzpfQauVFbRHjedUlryMJwKCEXoL=='CATEGORY_LIST':
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.dp_Category_List(nDNzpfQauVFbRHjedUlryMJwKCEXSg.main_params)
  elif nDNzpfQauVFbRHjedUlryMJwKCEXoL=='SEASON_LIST':
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.dp_Season_List(nDNzpfQauVFbRHjedUlryMJwKCEXSg.main_params)
  elif nDNzpfQauVFbRHjedUlryMJwKCEXoL=='EPISODE_LIST':
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.dp_Episode_List(nDNzpfQauVFbRHjedUlryMJwKCEXSg.main_params)
  elif nDNzpfQauVFbRHjedUlryMJwKCEXoL=='TEST':
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.dp_Test(nDNzpfQauVFbRHjedUlryMJwKCEXSg.main_params)
  elif nDNzpfQauVFbRHjedUlryMJwKCEXoL in['MOVIE','VOD','HIGHLIGHT','LIVE']:
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.play_VIDEO(nDNzpfQauVFbRHjedUlryMJwKCEXSg.main_params)
  elif nDNzpfQauVFbRHjedUlryMJwKCEXoL=='WATCH':
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.dp_Watch_List(nDNzpfQauVFbRHjedUlryMJwKCEXSg.main_params)
  elif nDNzpfQauVFbRHjedUlryMJwKCEXoL=='LOCAL_SEARCH':
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.dp_Search_List(nDNzpfQauVFbRHjedUlryMJwKCEXSg.main_params)
  elif nDNzpfQauVFbRHjedUlryMJwKCEXoL=='SEARCH_HISTORY':
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.dp_Search_History(nDNzpfQauVFbRHjedUlryMJwKCEXSg.main_params)
  elif nDNzpfQauVFbRHjedUlryMJwKCEXoL in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.dp_Listfile_Delete(nDNzpfQauVFbRHjedUlryMJwKCEXSg.main_params)
  elif nDNzpfQauVFbRHjedUlryMJwKCEXoL in['TOTAL_SEARCH','TOTAL_HISTORY']:
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.dp_Global_Search(nDNzpfQauVFbRHjedUlryMJwKCEXSg.main_params)
  elif nDNzpfQauVFbRHjedUlryMJwKCEXoL=='MENU_BOOKMARK':
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.dp_Bookmark_Menu(nDNzpfQauVFbRHjedUlryMJwKCEXSg.main_params)
  elif nDNzpfQauVFbRHjedUlryMJwKCEXoL=='SET_BOOKMARK':
   nDNzpfQauVFbRHjedUlryMJwKCEXSg.dp_Set_Bookmark(nDNzpfQauVFbRHjedUlryMJwKCEXSg.main_params)
  else:
   nDNzpfQauVFbRHjedUlryMJwKCEXgL
# Created by pyminifier (https://github.com/liftoff/pyminifier)
