__author__="NightRain"
cCoHPdGguksBDOyqpwflAevJhQmLMW=object
cCoHPdGguksBDOyqpwflAevJhQmLMx=None
cCoHPdGguksBDOyqpwflAevJhQmLMU=False
cCoHPdGguksBDOyqpwflAevJhQmLYz=True
cCoHPdGguksBDOyqpwflAevJhQmLYX=type
cCoHPdGguksBDOyqpwflAevJhQmLYt=dict
cCoHPdGguksBDOyqpwflAevJhQmLYS=getattr
cCoHPdGguksBDOyqpwflAevJhQmLYR=int
cCoHPdGguksBDOyqpwflAevJhQmLYM=list
cCoHPdGguksBDOyqpwflAevJhQmLYa=open
cCoHPdGguksBDOyqpwflAevJhQmLYF=Exception
cCoHPdGguksBDOyqpwflAevJhQmLYT=str
cCoHPdGguksBDOyqpwflAevJhQmLYi=id
cCoHPdGguksBDOyqpwflAevJhQmLYn=len
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import inputstreamhelper
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
cCoHPdGguksBDOyqpwflAevJhQmLzt=[{'title':'오직 쿠팡플레이에서','mode':'CATEGORY_LIST','vType':'ORIGINAL','collectionId':'5c33c5ca-ee6f-45f8-a026-dd789a8b63cf'},{'title':'홈   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'ALL'},{'title':'TV   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'MOVIES'},{'title':'키즈 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'KIDS'},{'title':'생중계','mode':'EVENT_GROUPLIST','vType':'LIVE'},{'title':'TV   (테마별)','mode':'THEME_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (테마별)','mode':'THEME_GROUPLIST','vType':'MOVIES'},{'title':'키즈 (테마별)','mode':'THEME_GROUPLIST','vType':'KIDS'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},{'title':'(쿠팡) 검색','mode':'LOCAL_SEARCH','icon':'search.png'},{'title':'(쿠팡) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
cCoHPdGguksBDOyqpwflAevJhQmLzS=[{'title':'시리즈 시청내역','mode':'WATCH','stype':'tvshow'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},]
cCoHPdGguksBDOyqpwflAevJhQmLzR={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
cCoHPdGguksBDOyqpwflAevJhQmLzM=xbmcvfs.translatePath(os.path.join(__profile__,'coupang_searched.txt'))
from coupangCore import*
class cCoHPdGguksBDOyqpwflAevJhQmLzX(cCoHPdGguksBDOyqpwflAevJhQmLMW):
 def __init__(cCoHPdGguksBDOyqpwflAevJhQmLzY,cCoHPdGguksBDOyqpwflAevJhQmLza,cCoHPdGguksBDOyqpwflAevJhQmLzF,cCoHPdGguksBDOyqpwflAevJhQmLzT):
  cCoHPdGguksBDOyqpwflAevJhQmLzY._addon_url =cCoHPdGguksBDOyqpwflAevJhQmLza
  cCoHPdGguksBDOyqpwflAevJhQmLzY._addon_handle=cCoHPdGguksBDOyqpwflAevJhQmLzF
  cCoHPdGguksBDOyqpwflAevJhQmLzY.main_params =cCoHPdGguksBDOyqpwflAevJhQmLzT
  cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj =jlikCRVadeOAPowyEKTpsJvFfuWnHU() 
  cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.CP_COOKIE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_cookies.json'))
  cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.CP_DEVICE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_device.json'))
 def addon_noti(cCoHPdGguksBDOyqpwflAevJhQmLzY,sting):
  try:
   cCoHPdGguksBDOyqpwflAevJhQmLzn=xbmcgui.Dialog()
   cCoHPdGguksBDOyqpwflAevJhQmLzn.notification(__addonname__,sting)
  except:
   cCoHPdGguksBDOyqpwflAevJhQmLMx
 def addon_log(cCoHPdGguksBDOyqpwflAevJhQmLzY,string):
  try:
   cCoHPdGguksBDOyqpwflAevJhQmLzI=string.encode('utf-8','ignore')
  except:
   cCoHPdGguksBDOyqpwflAevJhQmLzI='addonException: addon_log'
  cCoHPdGguksBDOyqpwflAevJhQmLzK=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,cCoHPdGguksBDOyqpwflAevJhQmLzI),level=cCoHPdGguksBDOyqpwflAevJhQmLzK)
 def get_keyboard_input(cCoHPdGguksBDOyqpwflAevJhQmLzY,cCoHPdGguksBDOyqpwflAevJhQmLXS):
  cCoHPdGguksBDOyqpwflAevJhQmLzV=cCoHPdGguksBDOyqpwflAevJhQmLMx
  kb=xbmc.Keyboard()
  kb.setHeading(cCoHPdGguksBDOyqpwflAevJhQmLXS)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   cCoHPdGguksBDOyqpwflAevJhQmLzV=kb.getText()
  return cCoHPdGguksBDOyqpwflAevJhQmLzV
 def get_settings_account(cCoHPdGguksBDOyqpwflAevJhQmLzY):
  cCoHPdGguksBDOyqpwflAevJhQmLzj=__addon__.getSetting('id')
  cCoHPdGguksBDOyqpwflAevJhQmLzE=__addon__.getSetting('pw')
  cCoHPdGguksBDOyqpwflAevJhQmLzN=__addon__.getSetting('profile')
  return(cCoHPdGguksBDOyqpwflAevJhQmLzj,cCoHPdGguksBDOyqpwflAevJhQmLzE,cCoHPdGguksBDOyqpwflAevJhQmLzN)
 def get_settings_exclusion21(cCoHPdGguksBDOyqpwflAevJhQmLzY):
  cCoHPdGguksBDOyqpwflAevJhQmLzb =__addon__.getSetting('exclusion21')
  if cCoHPdGguksBDOyqpwflAevJhQmLzb=='false':
   return cCoHPdGguksBDOyqpwflAevJhQmLMU
  else:
   return cCoHPdGguksBDOyqpwflAevJhQmLYz
 def get_settings_totalsearch(cCoHPdGguksBDOyqpwflAevJhQmLzY):
  cCoHPdGguksBDOyqpwflAevJhQmLzr =cCoHPdGguksBDOyqpwflAevJhQmLYz if __addon__.getSetting('local_search')=='true' else cCoHPdGguksBDOyqpwflAevJhQmLMU
  cCoHPdGguksBDOyqpwflAevJhQmLzW=cCoHPdGguksBDOyqpwflAevJhQmLYz if __addon__.getSetting('local_history')=='true' else cCoHPdGguksBDOyqpwflAevJhQmLMU
  cCoHPdGguksBDOyqpwflAevJhQmLzx =cCoHPdGguksBDOyqpwflAevJhQmLYz if __addon__.getSetting('total_search')=='true' else cCoHPdGguksBDOyqpwflAevJhQmLMU
  cCoHPdGguksBDOyqpwflAevJhQmLzU=cCoHPdGguksBDOyqpwflAevJhQmLYz if __addon__.getSetting('total_history')=='true' else cCoHPdGguksBDOyqpwflAevJhQmLMU
  cCoHPdGguksBDOyqpwflAevJhQmLXz=cCoHPdGguksBDOyqpwflAevJhQmLYz if __addon__.getSetting('menu_bookmark')=='true' else cCoHPdGguksBDOyqpwflAevJhQmLMU
  return(cCoHPdGguksBDOyqpwflAevJhQmLzr,cCoHPdGguksBDOyqpwflAevJhQmLzW,cCoHPdGguksBDOyqpwflAevJhQmLzx,cCoHPdGguksBDOyqpwflAevJhQmLzU,cCoHPdGguksBDOyqpwflAevJhQmLXz)
 def get_settings_makebookmark(cCoHPdGguksBDOyqpwflAevJhQmLzY):
  return cCoHPdGguksBDOyqpwflAevJhQmLYz if __addon__.getSetting('make_bookmark')=='true' else cCoHPdGguksBDOyqpwflAevJhQmLMU
 def add_dir(cCoHPdGguksBDOyqpwflAevJhQmLzY,label,sublabel='',img='',infoLabels=cCoHPdGguksBDOyqpwflAevJhQmLMx,isFolder=cCoHPdGguksBDOyqpwflAevJhQmLYz,params='',isLink=cCoHPdGguksBDOyqpwflAevJhQmLMU,ContextMenu=cCoHPdGguksBDOyqpwflAevJhQmLMx):
  cCoHPdGguksBDOyqpwflAevJhQmLXt='%s?%s'%(cCoHPdGguksBDOyqpwflAevJhQmLzY._addon_url,urllib.parse.urlencode(params))
  if sublabel:cCoHPdGguksBDOyqpwflAevJhQmLXS='%s < %s >'%(label,sublabel)
  else: cCoHPdGguksBDOyqpwflAevJhQmLXS=label
  if not img:img='DefaultFolder.png'
  cCoHPdGguksBDOyqpwflAevJhQmLXR=xbmcgui.ListItem(cCoHPdGguksBDOyqpwflAevJhQmLXS)
  if cCoHPdGguksBDOyqpwflAevJhQmLYX(img)==cCoHPdGguksBDOyqpwflAevJhQmLYt:
   cCoHPdGguksBDOyqpwflAevJhQmLXR.setArt(img)
  else:
   cCoHPdGguksBDOyqpwflAevJhQmLXR.setArt({'thumb':img,'poster':img})
  if cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.KodiVersion>=20:
   if infoLabels:cCoHPdGguksBDOyqpwflAevJhQmLzY.Set_InfoTag(cCoHPdGguksBDOyqpwflAevJhQmLXR.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:cCoHPdGguksBDOyqpwflAevJhQmLXR.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   cCoHPdGguksBDOyqpwflAevJhQmLXR.setProperty('IsPlayable','true')
  if ContextMenu:cCoHPdGguksBDOyqpwflAevJhQmLXR.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(cCoHPdGguksBDOyqpwflAevJhQmLzY._addon_handle,cCoHPdGguksBDOyqpwflAevJhQmLXt,cCoHPdGguksBDOyqpwflAevJhQmLXR,isFolder)
 def Set_InfoTag(cCoHPdGguksBDOyqpwflAevJhQmLzY,video_InfoTag:xbmc.InfoTagVideo,cCoHPdGguksBDOyqpwflAevJhQmLXI):
  for cCoHPdGguksBDOyqpwflAevJhQmLXM,value in cCoHPdGguksBDOyqpwflAevJhQmLXI.items():
   if cCoHPdGguksBDOyqpwflAevJhQmLzR[cCoHPdGguksBDOyqpwflAevJhQmLXM]['type']=='string':
    cCoHPdGguksBDOyqpwflAevJhQmLYS(video_InfoTag,cCoHPdGguksBDOyqpwflAevJhQmLzR[cCoHPdGguksBDOyqpwflAevJhQmLXM]['func'])(value)
   elif cCoHPdGguksBDOyqpwflAevJhQmLzR[cCoHPdGguksBDOyqpwflAevJhQmLXM]['type']=='int':
    if cCoHPdGguksBDOyqpwflAevJhQmLYX(value)==cCoHPdGguksBDOyqpwflAevJhQmLYR:
     cCoHPdGguksBDOyqpwflAevJhQmLXY=cCoHPdGguksBDOyqpwflAevJhQmLYR(value)
    else:
     cCoHPdGguksBDOyqpwflAevJhQmLXY=0
    cCoHPdGguksBDOyqpwflAevJhQmLYS(video_InfoTag,cCoHPdGguksBDOyqpwflAevJhQmLzR[cCoHPdGguksBDOyqpwflAevJhQmLXM]['func'])(cCoHPdGguksBDOyqpwflAevJhQmLXY)
   elif cCoHPdGguksBDOyqpwflAevJhQmLzR[cCoHPdGguksBDOyqpwflAevJhQmLXM]['type']=='actor':
    if value!=[]:
     cCoHPdGguksBDOyqpwflAevJhQmLYS(video_InfoTag,cCoHPdGguksBDOyqpwflAevJhQmLzR[cCoHPdGguksBDOyqpwflAevJhQmLXM]['func'])([xbmc.Actor(name)for name in value])
   elif cCoHPdGguksBDOyqpwflAevJhQmLzR[cCoHPdGguksBDOyqpwflAevJhQmLXM]['type']=='list':
    if cCoHPdGguksBDOyqpwflAevJhQmLYX(value)==cCoHPdGguksBDOyqpwflAevJhQmLYM:
     cCoHPdGguksBDOyqpwflAevJhQmLYS(video_InfoTag,cCoHPdGguksBDOyqpwflAevJhQmLzR[cCoHPdGguksBDOyqpwflAevJhQmLXM]['func'])(value)
    else:
     cCoHPdGguksBDOyqpwflAevJhQmLYS(video_InfoTag,cCoHPdGguksBDOyqpwflAevJhQmLzR[cCoHPdGguksBDOyqpwflAevJhQmLXM]['func'])([value])
 def dp_Main_List(cCoHPdGguksBDOyqpwflAevJhQmLzY,args):
  (cCoHPdGguksBDOyqpwflAevJhQmLzr,cCoHPdGguksBDOyqpwflAevJhQmLzW,cCoHPdGguksBDOyqpwflAevJhQmLzx,cCoHPdGguksBDOyqpwflAevJhQmLzU,cCoHPdGguksBDOyqpwflAevJhQmLXz)=cCoHPdGguksBDOyqpwflAevJhQmLzY.get_settings_totalsearch()
  for cCoHPdGguksBDOyqpwflAevJhQmLXa in cCoHPdGguksBDOyqpwflAevJhQmLzt:
   cCoHPdGguksBDOyqpwflAevJhQmLXS=cCoHPdGguksBDOyqpwflAevJhQmLXa.get('title')
   cCoHPdGguksBDOyqpwflAevJhQmLXF=''
   if cCoHPdGguksBDOyqpwflAevJhQmLXa.get('mode')=='LOCAL_SEARCH' and cCoHPdGguksBDOyqpwflAevJhQmLzr ==cCoHPdGguksBDOyqpwflAevJhQmLMU:continue
   elif cCoHPdGguksBDOyqpwflAevJhQmLXa.get('mode')=='SEARCH_HISTORY' and cCoHPdGguksBDOyqpwflAevJhQmLzW==cCoHPdGguksBDOyqpwflAevJhQmLMU:continue
   elif cCoHPdGguksBDOyqpwflAevJhQmLXa.get('mode')=='TOTAL_SEARCH' and cCoHPdGguksBDOyqpwflAevJhQmLzx ==cCoHPdGguksBDOyqpwflAevJhQmLMU:continue
   elif cCoHPdGguksBDOyqpwflAevJhQmLXa.get('mode')=='TOTAL_HISTORY' and cCoHPdGguksBDOyqpwflAevJhQmLzU==cCoHPdGguksBDOyqpwflAevJhQmLMU:continue
   elif cCoHPdGguksBDOyqpwflAevJhQmLXa.get('mode')=='MENU_BOOKMARK' and cCoHPdGguksBDOyqpwflAevJhQmLXz==cCoHPdGguksBDOyqpwflAevJhQmLMU:continue
   cCoHPdGguksBDOyqpwflAevJhQmLXT={'mode':cCoHPdGguksBDOyqpwflAevJhQmLXa.get('mode'),'vType':cCoHPdGguksBDOyqpwflAevJhQmLXa.get('vType'),'collectionId':cCoHPdGguksBDOyqpwflAevJhQmLXa.get('collectionId'),'page':'1',}
   if cCoHPdGguksBDOyqpwflAevJhQmLXa.get('mode')=='LOCAL_SEARCH':cCoHPdGguksBDOyqpwflAevJhQmLXT['historyyn']='Y' 
   if cCoHPdGguksBDOyqpwflAevJhQmLXa.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    cCoHPdGguksBDOyqpwflAevJhQmLXi=cCoHPdGguksBDOyqpwflAevJhQmLMU
    cCoHPdGguksBDOyqpwflAevJhQmLXn =cCoHPdGguksBDOyqpwflAevJhQmLYz
   else:
    cCoHPdGguksBDOyqpwflAevJhQmLXi=cCoHPdGguksBDOyqpwflAevJhQmLYz
    cCoHPdGguksBDOyqpwflAevJhQmLXn =cCoHPdGguksBDOyqpwflAevJhQmLMU
   cCoHPdGguksBDOyqpwflAevJhQmLXI={'title':cCoHPdGguksBDOyqpwflAevJhQmLXS,'plot':cCoHPdGguksBDOyqpwflAevJhQmLXS}
   if cCoHPdGguksBDOyqpwflAevJhQmLXa.get('mode')=='XXX':cCoHPdGguksBDOyqpwflAevJhQmLXI=cCoHPdGguksBDOyqpwflAevJhQmLMx
   if 'icon' in cCoHPdGguksBDOyqpwflAevJhQmLXa:cCoHPdGguksBDOyqpwflAevJhQmLXF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',cCoHPdGguksBDOyqpwflAevJhQmLXa.get('icon')) 
   cCoHPdGguksBDOyqpwflAevJhQmLzY.add_dir(cCoHPdGguksBDOyqpwflAevJhQmLXS,sublabel='',img=cCoHPdGguksBDOyqpwflAevJhQmLXF,infoLabels=cCoHPdGguksBDOyqpwflAevJhQmLXI,isFolder=cCoHPdGguksBDOyqpwflAevJhQmLXi,params=cCoHPdGguksBDOyqpwflAevJhQmLXT,isLink=cCoHPdGguksBDOyqpwflAevJhQmLXn)
  xbmcplugin.endOfDirectory(cCoHPdGguksBDOyqpwflAevJhQmLzY._addon_handle)
 def dp_Test(cCoHPdGguksBDOyqpwflAevJhQmLzY,args):
  cCoHPdGguksBDOyqpwflAevJhQmLzY.addon_noti('test')
 def CP_logout(cCoHPdGguksBDOyqpwflAevJhQmLzY):
  cCoHPdGguksBDOyqpwflAevJhQmLzn=xbmcgui.Dialog()
  cCoHPdGguksBDOyqpwflAevJhQmLXV=cCoHPdGguksBDOyqpwflAevJhQmLzn.yesno(__language__(30905).encode('utf8'),__language__(30906).encode('utf8'))
  if cCoHPdGguksBDOyqpwflAevJhQmLXV==cCoHPdGguksBDOyqpwflAevJhQmLMU:return 
  if os.path.isfile(cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.CP_COOKIE_FILENAME):os.remove(cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.CP_COOKIE_FILENAME)
  cCoHPdGguksBDOyqpwflAevJhQmLzY.addon_noti(__language__(30904).encode('utf-8'))
 def option_check(cCoHPdGguksBDOyqpwflAevJhQmLzY):
  (cCoHPdGguksBDOyqpwflAevJhQmLzj,cCoHPdGguksBDOyqpwflAevJhQmLzE,cCoHPdGguksBDOyqpwflAevJhQmLzN)=cCoHPdGguksBDOyqpwflAevJhQmLzY.get_settings_account()
  if cCoHPdGguksBDOyqpwflAevJhQmLzj=='' or cCoHPdGguksBDOyqpwflAevJhQmLzE=='':
   cCoHPdGguksBDOyqpwflAevJhQmLzn=xbmcgui.Dialog()
   cCoHPdGguksBDOyqpwflAevJhQmLXV=cCoHPdGguksBDOyqpwflAevJhQmLzn.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if cCoHPdGguksBDOyqpwflAevJhQmLXV==cCoHPdGguksBDOyqpwflAevJhQmLYz:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if cCoHPdGguksBDOyqpwflAevJhQmLzY.cookiefile_check()==cCoHPdGguksBDOyqpwflAevJhQmLMU:
   if cCoHPdGguksBDOyqpwflAevJhQmLzY.CP_login(cCoHPdGguksBDOyqpwflAevJhQmLzj,cCoHPdGguksBDOyqpwflAevJhQmLzE,cCoHPdGguksBDOyqpwflAevJhQmLzN)==cCoHPdGguksBDOyqpwflAevJhQmLMU:
    cCoHPdGguksBDOyqpwflAevJhQmLzY.addon_noti(__language__(30903).encode('utf8'))
    sys.exit()
  else:
   cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.Get_CP_profile(cCoHPdGguksBDOyqpwflAevJhQmLzN,limit_days=cCoHPdGguksBDOyqpwflAevJhQmLYR(__addon__.getSetting('cache_ttl')),re_check=cCoHPdGguksBDOyqpwflAevJhQmLYz)
 def cookiefile_check(cCoHPdGguksBDOyqpwflAevJhQmLzY):
  cCoHPdGguksBDOyqpwflAevJhQmLXE={}
  try: 
   fp=cCoHPdGguksBDOyqpwflAevJhQmLYa(cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.CP_COOKIE_FILENAME,'r',-1,'utf-8')
   cCoHPdGguksBDOyqpwflAevJhQmLXE= json.load(fp)
   fp.close()
  except cCoHPdGguksBDOyqpwflAevJhQmLYF as exception:
   return cCoHPdGguksBDOyqpwflAevJhQmLMU
  cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.CP=cCoHPdGguksBDOyqpwflAevJhQmLXE
  if 'session_web_id' not in cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.CP.get('SESSION'):
   cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.Init_CP()
   return cCoHPdGguksBDOyqpwflAevJhQmLMU
  (cCoHPdGguksBDOyqpwflAevJhQmLzj,cCoHPdGguksBDOyqpwflAevJhQmLzE,cCoHPdGguksBDOyqpwflAevJhQmLzN)=cCoHPdGguksBDOyqpwflAevJhQmLzY.get_settings_account()
  (cCoHPdGguksBDOyqpwflAevJhQmLXN,cCoHPdGguksBDOyqpwflAevJhQmLXb,cCoHPdGguksBDOyqpwflAevJhQmLXr)=cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.Load_session_acount()
  if cCoHPdGguksBDOyqpwflAevJhQmLzj!=cCoHPdGguksBDOyqpwflAevJhQmLXN or cCoHPdGguksBDOyqpwflAevJhQmLzE!=cCoHPdGguksBDOyqpwflAevJhQmLXb or cCoHPdGguksBDOyqpwflAevJhQmLzN!=cCoHPdGguksBDOyqpwflAevJhQmLYT(cCoHPdGguksBDOyqpwflAevJhQmLXr):
   cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.Init_CP()
   return cCoHPdGguksBDOyqpwflAevJhQmLMU
  cCoHPdGguksBDOyqpwflAevJhQmLXW =cCoHPdGguksBDOyqpwflAevJhQmLYR(cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.Get_Now_Datetime().strftime('%Y%m%d'))
  cCoHPdGguksBDOyqpwflAevJhQmLXx=cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.CP['SESSION']['limitdate']
  cCoHPdGguksBDOyqpwflAevJhQmLXU =cCoHPdGguksBDOyqpwflAevJhQmLYR(re.sub('-','',cCoHPdGguksBDOyqpwflAevJhQmLXx))
  if cCoHPdGguksBDOyqpwflAevJhQmLXU<cCoHPdGguksBDOyqpwflAevJhQmLXW:
   cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.Init_CP()
   return cCoHPdGguksBDOyqpwflAevJhQmLMU
  return cCoHPdGguksBDOyqpwflAevJhQmLYz
 def CP_login(cCoHPdGguksBDOyqpwflAevJhQmLzY,cCoHPdGguksBDOyqpwflAevJhQmLzj,cCoHPdGguksBDOyqpwflAevJhQmLzE,cCoHPdGguksBDOyqpwflAevJhQmLzN):
  if cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.Get_CP_Login(cCoHPdGguksBDOyqpwflAevJhQmLzj,cCoHPdGguksBDOyqpwflAevJhQmLzE,cCoHPdGguksBDOyqpwflAevJhQmLzN)==cCoHPdGguksBDOyqpwflAevJhQmLMU:return cCoHPdGguksBDOyqpwflAevJhQmLMU
  if cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.Get_CP_profile(cCoHPdGguksBDOyqpwflAevJhQmLzN,limit_days=cCoHPdGguksBDOyqpwflAevJhQmLYR(__addon__.getSetting('cache_ttl')),re_check=cCoHPdGguksBDOyqpwflAevJhQmLMU)==cCoHPdGguksBDOyqpwflAevJhQmLMU:return cCoHPdGguksBDOyqpwflAevJhQmLMU
  return cCoHPdGguksBDOyqpwflAevJhQmLYz
 def dp_Category_GroupList(cCoHPdGguksBDOyqpwflAevJhQmLzY,args):
  cCoHPdGguksBDOyqpwflAevJhQmLtz =args.get('vType') 
  cCoHPdGguksBDOyqpwflAevJhQmLtX=cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.Get_Category_GroupList(cCoHPdGguksBDOyqpwflAevJhQmLtz)
  for cCoHPdGguksBDOyqpwflAevJhQmLtS in cCoHPdGguksBDOyqpwflAevJhQmLtX:
   cCoHPdGguksBDOyqpwflAevJhQmLXS =cCoHPdGguksBDOyqpwflAevJhQmLtS.get('title')
   cCoHPdGguksBDOyqpwflAevJhQmLtR=cCoHPdGguksBDOyqpwflAevJhQmLtS.get('pre_title')
   if cCoHPdGguksBDOyqpwflAevJhQmLzY.get_settings_exclusion21()==cCoHPdGguksBDOyqpwflAevJhQmLYz and cCoHPdGguksBDOyqpwflAevJhQmLXS=='성인':continue
   cCoHPdGguksBDOyqpwflAevJhQmLtM={'mediatype':'tvshow','plot':cCoHPdGguksBDOyqpwflAevJhQmLtR,}
   cCoHPdGguksBDOyqpwflAevJhQmLXT={'mode':'CATEGORY_LIST','collectionId':cCoHPdGguksBDOyqpwflAevJhQmLtS.get('collectionId'),'vType':cCoHPdGguksBDOyqpwflAevJhQmLtS.get('category'),'page':'1',}
   cCoHPdGguksBDOyqpwflAevJhQmLzY.add_dir(cCoHPdGguksBDOyqpwflAevJhQmLXS,sublabel='',img='',infoLabels=cCoHPdGguksBDOyqpwflAevJhQmLtM,isFolder=cCoHPdGguksBDOyqpwflAevJhQmLYz,params=cCoHPdGguksBDOyqpwflAevJhQmLXT)
  xbmcplugin.endOfDirectory(cCoHPdGguksBDOyqpwflAevJhQmLzY._addon_handle,cacheToDisc=cCoHPdGguksBDOyqpwflAevJhQmLMU)
 def dp_Theme_GroupList(cCoHPdGguksBDOyqpwflAevJhQmLzY,args):
  cCoHPdGguksBDOyqpwflAevJhQmLtz =args.get('vType') 
  cCoHPdGguksBDOyqpwflAevJhQmLtX=cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.Get_Theme_GroupList(cCoHPdGguksBDOyqpwflAevJhQmLtz)
  for cCoHPdGguksBDOyqpwflAevJhQmLtS in cCoHPdGguksBDOyqpwflAevJhQmLtX:
   cCoHPdGguksBDOyqpwflAevJhQmLXS =cCoHPdGguksBDOyqpwflAevJhQmLtS.get('title')
   cCoHPdGguksBDOyqpwflAevJhQmLtR=cCoHPdGguksBDOyqpwflAevJhQmLtS.get('pre_title')
   cCoHPdGguksBDOyqpwflAevJhQmLtM={'mediatype':'tvshow','plot':cCoHPdGguksBDOyqpwflAevJhQmLtR,}
   cCoHPdGguksBDOyqpwflAevJhQmLXT={'mode':'CATEGORY_LIST','collectionId':cCoHPdGguksBDOyqpwflAevJhQmLtS.get('collectionId'),'vType':cCoHPdGguksBDOyqpwflAevJhQmLtS.get('category'),'page':'1',}
   cCoHPdGguksBDOyqpwflAevJhQmLzY.add_dir(cCoHPdGguksBDOyqpwflAevJhQmLXS,sublabel='',img='',infoLabels=cCoHPdGguksBDOyqpwflAevJhQmLtM,isFolder=cCoHPdGguksBDOyqpwflAevJhQmLYz,params=cCoHPdGguksBDOyqpwflAevJhQmLXT)
  xbmcplugin.endOfDirectory(cCoHPdGguksBDOyqpwflAevJhQmLzY._addon_handle,cacheToDisc=cCoHPdGguksBDOyqpwflAevJhQmLMU)
 def dp_Event_GroupList(cCoHPdGguksBDOyqpwflAevJhQmLzY,args):
  cCoHPdGguksBDOyqpwflAevJhQmLtX=cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.Get_Event_GroupList()
  for cCoHPdGguksBDOyqpwflAevJhQmLtS in cCoHPdGguksBDOyqpwflAevJhQmLtX:
   cCoHPdGguksBDOyqpwflAevJhQmLXS =cCoHPdGguksBDOyqpwflAevJhQmLtS.get('title')
   cCoHPdGguksBDOyqpwflAevJhQmLtR=cCoHPdGguksBDOyqpwflAevJhQmLtS.get('pre_title')
   cCoHPdGguksBDOyqpwflAevJhQmLtM={'mediatype':'tvshow','plot':cCoHPdGguksBDOyqpwflAevJhQmLtR,}
   cCoHPdGguksBDOyqpwflAevJhQmLXT={'mode':'EVENT_GAMELIST','collectionId':cCoHPdGguksBDOyqpwflAevJhQmLtS.get('collectionId'),'vType':'LIVE',}
   cCoHPdGguksBDOyqpwflAevJhQmLzY.add_dir(cCoHPdGguksBDOyqpwflAevJhQmLXS,sublabel='',img='',infoLabels=cCoHPdGguksBDOyqpwflAevJhQmLtM,isFolder=cCoHPdGguksBDOyqpwflAevJhQmLYz,params=cCoHPdGguksBDOyqpwflAevJhQmLXT)
  xbmcplugin.endOfDirectory(cCoHPdGguksBDOyqpwflAevJhQmLzY._addon_handle,cacheToDisc=cCoHPdGguksBDOyqpwflAevJhQmLMU)
 def dp_Event_GameList(cCoHPdGguksBDOyqpwflAevJhQmLzY,args):
  cCoHPdGguksBDOyqpwflAevJhQmLtz =args.get('vType') 
  cCoHPdGguksBDOyqpwflAevJhQmLta =args.get('collectionId')
  cCoHPdGguksBDOyqpwflAevJhQmLtX=cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.Get_Event_GameList(cCoHPdGguksBDOyqpwflAevJhQmLta)
  for cCoHPdGguksBDOyqpwflAevJhQmLtS in cCoHPdGguksBDOyqpwflAevJhQmLtX:
   cCoHPdGguksBDOyqpwflAevJhQmLXS =cCoHPdGguksBDOyqpwflAevJhQmLtS.get('title')
   cCoHPdGguksBDOyqpwflAevJhQmLYi =cCoHPdGguksBDOyqpwflAevJhQmLtS.get('id')
   cCoHPdGguksBDOyqpwflAevJhQmLtF =cCoHPdGguksBDOyqpwflAevJhQmLtS.get('thumbnail')
   cCoHPdGguksBDOyqpwflAevJhQmLtT =cCoHPdGguksBDOyqpwflAevJhQmLtS.get('asis') 
   cCoHPdGguksBDOyqpwflAevJhQmLti =cCoHPdGguksBDOyqpwflAevJhQmLtS.get('addInfo')
   cCoHPdGguksBDOyqpwflAevJhQmLtn =cCoHPdGguksBDOyqpwflAevJhQmLtS.get('starttm')
   cCoHPdGguksBDOyqpwflAevJhQmLtM={'mediatype':'tvshow','title':cCoHPdGguksBDOyqpwflAevJhQmLXS,'plot':cCoHPdGguksBDOyqpwflAevJhQmLti,}
   cCoHPdGguksBDOyqpwflAevJhQmLXT={'mode':'EVENT_LIST','id':cCoHPdGguksBDOyqpwflAevJhQmLYi,'asis':cCoHPdGguksBDOyqpwflAevJhQmLtT,'title':cCoHPdGguksBDOyqpwflAevJhQmLXS,}
   cCoHPdGguksBDOyqpwflAevJhQmLzY.add_dir(cCoHPdGguksBDOyqpwflAevJhQmLXS,sublabel=cCoHPdGguksBDOyqpwflAevJhQmLtn,img=cCoHPdGguksBDOyqpwflAevJhQmLtF,infoLabels=cCoHPdGguksBDOyqpwflAevJhQmLtM,isFolder=cCoHPdGguksBDOyqpwflAevJhQmLYz,params=cCoHPdGguksBDOyqpwflAevJhQmLXT,ContextMenu=cCoHPdGguksBDOyqpwflAevJhQmLMx)
  xbmcplugin.setContent(cCoHPdGguksBDOyqpwflAevJhQmLzY._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(cCoHPdGguksBDOyqpwflAevJhQmLzY._addon_handle,cacheToDisc=cCoHPdGguksBDOyqpwflAevJhQmLMU)
 def dp_Event_List(cCoHPdGguksBDOyqpwflAevJhQmLzY,args):
  cCoHPdGguksBDOyqpwflAevJhQmLtI=args.get('id')
  cCoHPdGguksBDOyqpwflAevJhQmLtX=cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.Get_Event_List(cCoHPdGguksBDOyqpwflAevJhQmLtI)
  for cCoHPdGguksBDOyqpwflAevJhQmLtS in cCoHPdGguksBDOyqpwflAevJhQmLtX:
   cCoHPdGguksBDOyqpwflAevJhQmLXS =cCoHPdGguksBDOyqpwflAevJhQmLtS.get('title')
   cCoHPdGguksBDOyqpwflAevJhQmLYi =cCoHPdGguksBDOyqpwflAevJhQmLtS.get('id')
   cCoHPdGguksBDOyqpwflAevJhQmLtF =cCoHPdGguksBDOyqpwflAevJhQmLtS.get('thumbnail')
   cCoHPdGguksBDOyqpwflAevJhQmLtT =cCoHPdGguksBDOyqpwflAevJhQmLtS.get('asis') 
   cCoHPdGguksBDOyqpwflAevJhQmLtK =cCoHPdGguksBDOyqpwflAevJhQmLtS.get('duration')
   cCoHPdGguksBDOyqpwflAevJhQmLtn =cCoHPdGguksBDOyqpwflAevJhQmLtS.get('starttm')
   cCoHPdGguksBDOyqpwflAevJhQmLtM={'mediatype':'episode','title':cCoHPdGguksBDOyqpwflAevJhQmLXS,'plot':cCoHPdGguksBDOyqpwflAevJhQmLtT,'duration':cCoHPdGguksBDOyqpwflAevJhQmLtK,}
   cCoHPdGguksBDOyqpwflAevJhQmLXT={'mode':cCoHPdGguksBDOyqpwflAevJhQmLtT,'id':cCoHPdGguksBDOyqpwflAevJhQmLYi,'asis':cCoHPdGguksBDOyqpwflAevJhQmLtT,'title':cCoHPdGguksBDOyqpwflAevJhQmLXS,}
   cCoHPdGguksBDOyqpwflAevJhQmLzY.add_dir(cCoHPdGguksBDOyqpwflAevJhQmLXS,sublabel=cCoHPdGguksBDOyqpwflAevJhQmLtn,img=cCoHPdGguksBDOyqpwflAevJhQmLtF,infoLabels=cCoHPdGguksBDOyqpwflAevJhQmLtM,isFolder=cCoHPdGguksBDOyqpwflAevJhQmLMU,params=cCoHPdGguksBDOyqpwflAevJhQmLXT,ContextMenu=cCoHPdGguksBDOyqpwflAevJhQmLMx)
  xbmcplugin.setContent(cCoHPdGguksBDOyqpwflAevJhQmLzY._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(cCoHPdGguksBDOyqpwflAevJhQmLzY._addon_handle,cacheToDisc=cCoHPdGguksBDOyqpwflAevJhQmLMU)
 def dp_Category_List(cCoHPdGguksBDOyqpwflAevJhQmLzY,args):
  cCoHPdGguksBDOyqpwflAevJhQmLtz =args.get('vType') 
  cCoHPdGguksBDOyqpwflAevJhQmLta =args.get('collectionId')
  cCoHPdGguksBDOyqpwflAevJhQmLtV =cCoHPdGguksBDOyqpwflAevJhQmLYR(args.get('page'))
  cCoHPdGguksBDOyqpwflAevJhQmLtX,cCoHPdGguksBDOyqpwflAevJhQmLtj=cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.Get_Category_List(cCoHPdGguksBDOyqpwflAevJhQmLtz,cCoHPdGguksBDOyqpwflAevJhQmLta,cCoHPdGguksBDOyqpwflAevJhQmLtV)
  for cCoHPdGguksBDOyqpwflAevJhQmLtS in cCoHPdGguksBDOyqpwflAevJhQmLtX:
   cCoHPdGguksBDOyqpwflAevJhQmLXS =cCoHPdGguksBDOyqpwflAevJhQmLtS.get('title')
   cCoHPdGguksBDOyqpwflAevJhQmLYi =cCoHPdGguksBDOyqpwflAevJhQmLtS.get('id')
   cCoHPdGguksBDOyqpwflAevJhQmLtF =cCoHPdGguksBDOyqpwflAevJhQmLtS.get('thumbnail')
   cCoHPdGguksBDOyqpwflAevJhQmLtE =cCoHPdGguksBDOyqpwflAevJhQmLtS.get('mpaa')
   cCoHPdGguksBDOyqpwflAevJhQmLtK =cCoHPdGguksBDOyqpwflAevJhQmLtS.get('duration')
   cCoHPdGguksBDOyqpwflAevJhQmLtT =cCoHPdGguksBDOyqpwflAevJhQmLtS.get('asis')
   cCoHPdGguksBDOyqpwflAevJhQmLtN =cCoHPdGguksBDOyqpwflAevJhQmLtS.get('badge')
   cCoHPdGguksBDOyqpwflAevJhQmLtb =cCoHPdGguksBDOyqpwflAevJhQmLtS.get('year')
   cCoHPdGguksBDOyqpwflAevJhQmLtr=cCoHPdGguksBDOyqpwflAevJhQmLtS.get('seasonList')
   cCoHPdGguksBDOyqpwflAevJhQmLtW =cCoHPdGguksBDOyqpwflAevJhQmLtS.get('genreList')
   if cCoHPdGguksBDOyqpwflAevJhQmLtT in['TVSHOW','EDUCATION']: 
    cCoHPdGguksBDOyqpwflAevJhQmLtx ='SEASON_LIST'
    cCoHPdGguksBDOyqpwflAevJhQmLtM={'mediatype':'tvshow','title':cCoHPdGguksBDOyqpwflAevJhQmLXS,'mpaa':cCoHPdGguksBDOyqpwflAevJhQmLtE,'genre':cCoHPdGguksBDOyqpwflAevJhQmLtW,'year':cCoHPdGguksBDOyqpwflAevJhQmLtb,'plot':'Year : %s\nSeason : %s'%(cCoHPdGguksBDOyqpwflAevJhQmLtb,cCoHPdGguksBDOyqpwflAevJhQmLtr),}
    cCoHPdGguksBDOyqpwflAevJhQmLXi =cCoHPdGguksBDOyqpwflAevJhQmLYz
   else:
    cCoHPdGguksBDOyqpwflAevJhQmLtx ='MOVIE'
    cCoHPdGguksBDOyqpwflAevJhQmLtM={'mediatype':'movie','title':cCoHPdGguksBDOyqpwflAevJhQmLXS,'mpaa':cCoHPdGguksBDOyqpwflAevJhQmLtE,'genre':cCoHPdGguksBDOyqpwflAevJhQmLtW,'duration':cCoHPdGguksBDOyqpwflAevJhQmLtK,'year':cCoHPdGguksBDOyqpwflAevJhQmLtb,'plot':'(%s)'%(cCoHPdGguksBDOyqpwflAevJhQmLtE),}
    cCoHPdGguksBDOyqpwflAevJhQmLXi =cCoHPdGguksBDOyqpwflAevJhQmLMU
    cCoHPdGguksBDOyqpwflAevJhQmLXS +=' (%s)'%(cCoHPdGguksBDOyqpwflAevJhQmLYT(cCoHPdGguksBDOyqpwflAevJhQmLtb))
   cCoHPdGguksBDOyqpwflAevJhQmLXT={'mode':cCoHPdGguksBDOyqpwflAevJhQmLtx,'id':cCoHPdGguksBDOyqpwflAevJhQmLYi,'asis':cCoHPdGguksBDOyqpwflAevJhQmLtT,'seasonList':cCoHPdGguksBDOyqpwflAevJhQmLtr,'title':cCoHPdGguksBDOyqpwflAevJhQmLXS,'thumbnail':cCoHPdGguksBDOyqpwflAevJhQmLtF,'year':cCoHPdGguksBDOyqpwflAevJhQmLtb,}
   if cCoHPdGguksBDOyqpwflAevJhQmLzY.get_settings_makebookmark():
    cCoHPdGguksBDOyqpwflAevJhQmLtU={'videoid':cCoHPdGguksBDOyqpwflAevJhQmLYi,'vidtype':'movie' if cCoHPdGguksBDOyqpwflAevJhQmLtz=='MOVIES' else 'tvshow','vtitle':cCoHPdGguksBDOyqpwflAevJhQmLXS,'vsubtitle':'',}
    cCoHPdGguksBDOyqpwflAevJhQmLSz=json.dumps(cCoHPdGguksBDOyqpwflAevJhQmLtU)
    cCoHPdGguksBDOyqpwflAevJhQmLSz=urllib.parse.quote(cCoHPdGguksBDOyqpwflAevJhQmLSz)
    cCoHPdGguksBDOyqpwflAevJhQmLSX='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(cCoHPdGguksBDOyqpwflAevJhQmLSz)
    cCoHPdGguksBDOyqpwflAevJhQmLSt=[('(통합) 찜 영상에 추가',cCoHPdGguksBDOyqpwflAevJhQmLSX)]
   else:
    cCoHPdGguksBDOyqpwflAevJhQmLSt=cCoHPdGguksBDOyqpwflAevJhQmLMx
   cCoHPdGguksBDOyqpwflAevJhQmLzY.add_dir(cCoHPdGguksBDOyqpwflAevJhQmLXS,sublabel=cCoHPdGguksBDOyqpwflAevJhQmLtN,img=cCoHPdGguksBDOyqpwflAevJhQmLtF,infoLabels=cCoHPdGguksBDOyqpwflAevJhQmLtM,isFolder=cCoHPdGguksBDOyqpwflAevJhQmLXi,params=cCoHPdGguksBDOyqpwflAevJhQmLXT,ContextMenu=cCoHPdGguksBDOyqpwflAevJhQmLSt)
  if cCoHPdGguksBDOyqpwflAevJhQmLtj:
   cCoHPdGguksBDOyqpwflAevJhQmLXT['mode'] ='CATEGORY_LIST' 
   cCoHPdGguksBDOyqpwflAevJhQmLXT['collectionId']=cCoHPdGguksBDOyqpwflAevJhQmLta 
   cCoHPdGguksBDOyqpwflAevJhQmLXT['vType'] =cCoHPdGguksBDOyqpwflAevJhQmLtz 
   cCoHPdGguksBDOyqpwflAevJhQmLXT['page'] =cCoHPdGguksBDOyqpwflAevJhQmLYT(cCoHPdGguksBDOyqpwflAevJhQmLtV+1)
   cCoHPdGguksBDOyqpwflAevJhQmLXS='[B]%s >>[/B]'%'다음 페이지'
   cCoHPdGguksBDOyqpwflAevJhQmLSR=cCoHPdGguksBDOyqpwflAevJhQmLYT(cCoHPdGguksBDOyqpwflAevJhQmLtV+1)
   cCoHPdGguksBDOyqpwflAevJhQmLXF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   cCoHPdGguksBDOyqpwflAevJhQmLzY.add_dir(cCoHPdGguksBDOyqpwflAevJhQmLXS,sublabel=cCoHPdGguksBDOyqpwflAevJhQmLSR,img=cCoHPdGguksBDOyqpwflAevJhQmLXF,infoLabels=cCoHPdGguksBDOyqpwflAevJhQmLMx,isFolder=cCoHPdGguksBDOyqpwflAevJhQmLYz,params=cCoHPdGguksBDOyqpwflAevJhQmLXT)
  if cCoHPdGguksBDOyqpwflAevJhQmLtz=='TVSHOWS':xbmcplugin.setContent(cCoHPdGguksBDOyqpwflAevJhQmLzY._addon_handle,'tvshows')
  else:xbmcplugin.setContent(cCoHPdGguksBDOyqpwflAevJhQmLzY._addon_handle,'movies')
  xbmcplugin.endOfDirectory(cCoHPdGguksBDOyqpwflAevJhQmLzY._addon_handle,cacheToDisc=cCoHPdGguksBDOyqpwflAevJhQmLMU)
 def dp_Season_List(cCoHPdGguksBDOyqpwflAevJhQmLzY,args):
  cCoHPdGguksBDOyqpwflAevJhQmLSM =args.get('title')
  cCoHPdGguksBDOyqpwflAevJhQmLSY =args.get('id')
  cCoHPdGguksBDOyqpwflAevJhQmLtT =args.get('asis')
  cCoHPdGguksBDOyqpwflAevJhQmLtr =args.get('seasonList')
  cCoHPdGguksBDOyqpwflAevJhQmLtF =args.get('thumbnail')
  cCoHPdGguksBDOyqpwflAevJhQmLtb =args.get('year')
  if cCoHPdGguksBDOyqpwflAevJhQmLtr in['',cCoHPdGguksBDOyqpwflAevJhQmLMx]:
   cCoHPdGguksBDOyqpwflAevJhQmLtr=cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.Get_vInfo(cCoHPdGguksBDOyqpwflAevJhQmLSY).get('seasonList')
  if cCoHPdGguksBDOyqpwflAevJhQmLYn(cCoHPdGguksBDOyqpwflAevJhQmLtr.split(','))>1:
   for cCoHPdGguksBDOyqpwflAevJhQmLSa in cCoHPdGguksBDOyqpwflAevJhQmLtr.split(','):
    cCoHPdGguksBDOyqpwflAevJhQmLXS='시즌 '+cCoHPdGguksBDOyqpwflAevJhQmLSa
    cCoHPdGguksBDOyqpwflAevJhQmLtM={'mediatype':'tvshow','plot':'%s (%s)'%(cCoHPdGguksBDOyqpwflAevJhQmLSM,cCoHPdGguksBDOyqpwflAevJhQmLtb),}
    cCoHPdGguksBDOyqpwflAevJhQmLXT={'mode':'EPISODE_LIST','programid':cCoHPdGguksBDOyqpwflAevJhQmLSY,'programnm':cCoHPdGguksBDOyqpwflAevJhQmLSM,'season':cCoHPdGguksBDOyqpwflAevJhQmLSa,'asis':cCoHPdGguksBDOyqpwflAevJhQmLtT,'programimg':cCoHPdGguksBDOyqpwflAevJhQmLtF,}
    cCoHPdGguksBDOyqpwflAevJhQmLSF=cCoHPdGguksBDOyqpwflAevJhQmLtF.replace('\'','\"')
    cCoHPdGguksBDOyqpwflAevJhQmLSF=json.loads(cCoHPdGguksBDOyqpwflAevJhQmLSF)
    cCoHPdGguksBDOyqpwflAevJhQmLzY.add_dir(cCoHPdGguksBDOyqpwflAevJhQmLXS,sublabel='',img=cCoHPdGguksBDOyqpwflAevJhQmLSF,infoLabels=cCoHPdGguksBDOyqpwflAevJhQmLtM,isFolder=cCoHPdGguksBDOyqpwflAevJhQmLYz,params=cCoHPdGguksBDOyqpwflAevJhQmLXT)
   xbmcplugin.setContent(cCoHPdGguksBDOyqpwflAevJhQmLzY._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(cCoHPdGguksBDOyqpwflAevJhQmLzY._addon_handle,cacheToDisc=cCoHPdGguksBDOyqpwflAevJhQmLMU)
  else:
   cCoHPdGguksBDOyqpwflAevJhQmLST={'programid':cCoHPdGguksBDOyqpwflAevJhQmLSY,'programnm':cCoHPdGguksBDOyqpwflAevJhQmLSM,'season':cCoHPdGguksBDOyqpwflAevJhQmLtr,'programimg':cCoHPdGguksBDOyqpwflAevJhQmLtF,}
   cCoHPdGguksBDOyqpwflAevJhQmLzY.dp_Episode_List(cCoHPdGguksBDOyqpwflAevJhQmLST)
 def dp_Episode_List(cCoHPdGguksBDOyqpwflAevJhQmLzY,args):
  cCoHPdGguksBDOyqpwflAevJhQmLSY =args.get('programid')
  cCoHPdGguksBDOyqpwflAevJhQmLSM =args.get('programnm')
  cCoHPdGguksBDOyqpwflAevJhQmLSi =args.get('season')
  cCoHPdGguksBDOyqpwflAevJhQmLSn =args.get('programimg')
  cCoHPdGguksBDOyqpwflAevJhQmLSI=cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.Get_Episode_List(cCoHPdGguksBDOyqpwflAevJhQmLSY,cCoHPdGguksBDOyqpwflAevJhQmLSi)
  for cCoHPdGguksBDOyqpwflAevJhQmLSa in cCoHPdGguksBDOyqpwflAevJhQmLSI:
   cCoHPdGguksBDOyqpwflAevJhQmLSK =cCoHPdGguksBDOyqpwflAevJhQmLSa.get('title')
   cCoHPdGguksBDOyqpwflAevJhQmLSV =cCoHPdGguksBDOyqpwflAevJhQmLSa.get('id')
   cCoHPdGguksBDOyqpwflAevJhQmLtT =cCoHPdGguksBDOyqpwflAevJhQmLSa.get('asis')
   cCoHPdGguksBDOyqpwflAevJhQmLtF =cCoHPdGguksBDOyqpwflAevJhQmLSa.get('thumbnail')
   cCoHPdGguksBDOyqpwflAevJhQmLtE =cCoHPdGguksBDOyqpwflAevJhQmLSa.get('mpaa')
   cCoHPdGguksBDOyqpwflAevJhQmLtK =cCoHPdGguksBDOyqpwflAevJhQmLSa.get('duration')
   cCoHPdGguksBDOyqpwflAevJhQmLtb =cCoHPdGguksBDOyqpwflAevJhQmLSa.get('year')
   cCoHPdGguksBDOyqpwflAevJhQmLSj =cCoHPdGguksBDOyqpwflAevJhQmLSa.get('episode')
   cCoHPdGguksBDOyqpwflAevJhQmLtW =cCoHPdGguksBDOyqpwflAevJhQmLSa.get('genreList')
   cCoHPdGguksBDOyqpwflAevJhQmLSE =cCoHPdGguksBDOyqpwflAevJhQmLSa.get('desc')
   cCoHPdGguksBDOyqpwflAevJhQmLSN ='%sx%s'%(cCoHPdGguksBDOyqpwflAevJhQmLSi,cCoHPdGguksBDOyqpwflAevJhQmLSj)
   cCoHPdGguksBDOyqpwflAevJhQmLXS ='%s. %s'%(cCoHPdGguksBDOyqpwflAevJhQmLSN,cCoHPdGguksBDOyqpwflAevJhQmLSK)
   cCoHPdGguksBDOyqpwflAevJhQmLtM={'mediatype':'episode','mpaa':cCoHPdGguksBDOyqpwflAevJhQmLtE,'genre':cCoHPdGguksBDOyqpwflAevJhQmLtW,'duration':cCoHPdGguksBDOyqpwflAevJhQmLtK,'year':cCoHPdGguksBDOyqpwflAevJhQmLtb,'plot':'%s (%s)\n\n%s'%(cCoHPdGguksBDOyqpwflAevJhQmLSM,cCoHPdGguksBDOyqpwflAevJhQmLSN,cCoHPdGguksBDOyqpwflAevJhQmLSE),}
   cCoHPdGguksBDOyqpwflAevJhQmLXT={'mode':'VOD','programid':cCoHPdGguksBDOyqpwflAevJhQmLSY,'programnm':cCoHPdGguksBDOyqpwflAevJhQmLSM,'title':cCoHPdGguksBDOyqpwflAevJhQmLXS,'season':cCoHPdGguksBDOyqpwflAevJhQmLSi,'id':cCoHPdGguksBDOyqpwflAevJhQmLSV,'asis':cCoHPdGguksBDOyqpwflAevJhQmLtT,'thumbnail':cCoHPdGguksBDOyqpwflAevJhQmLtF,'programimg':cCoHPdGguksBDOyqpwflAevJhQmLSn,}
   cCoHPdGguksBDOyqpwflAevJhQmLzY.add_dir(cCoHPdGguksBDOyqpwflAevJhQmLXS,sublabel='',img=cCoHPdGguksBDOyqpwflAevJhQmLtF,infoLabels=cCoHPdGguksBDOyqpwflAevJhQmLtM,isFolder=cCoHPdGguksBDOyqpwflAevJhQmLMU,params=cCoHPdGguksBDOyqpwflAevJhQmLXT)
  xbmcplugin.setContent(cCoHPdGguksBDOyqpwflAevJhQmLzY._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(cCoHPdGguksBDOyqpwflAevJhQmLzY._addon_handle,cacheToDisc=cCoHPdGguksBDOyqpwflAevJhQmLMU)
 def play_VIDEO(cCoHPdGguksBDOyqpwflAevJhQmLzY,args):
  cCoHPdGguksBDOyqpwflAevJhQmLSb =args.get('id')
  cCoHPdGguksBDOyqpwflAevJhQmLtT =args.get('asis')
  if cCoHPdGguksBDOyqpwflAevJhQmLtT in['HIGHLIGHT']:
   cCoHPdGguksBDOyqpwflAevJhQmLSr,cCoHPdGguksBDOyqpwflAevJhQmLSW=cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.GetEventURL(cCoHPdGguksBDOyqpwflAevJhQmLSb,cCoHPdGguksBDOyqpwflAevJhQmLtT)
  elif cCoHPdGguksBDOyqpwflAevJhQmLtT in['LIVE']:
   cCoHPdGguksBDOyqpwflAevJhQmLSr,cCoHPdGguksBDOyqpwflAevJhQmLSW=cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.GetEventURL_Live(cCoHPdGguksBDOyqpwflAevJhQmLSb,cCoHPdGguksBDOyqpwflAevJhQmLtT)
  else:
   cCoHPdGguksBDOyqpwflAevJhQmLSr,cCoHPdGguksBDOyqpwflAevJhQmLSW=cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.GetBroadURL(cCoHPdGguksBDOyqpwflAevJhQmLSb)
  cCoHPdGguksBDOyqpwflAevJhQmLzY.addon_log('asis, url : %s - %s - %s'%(cCoHPdGguksBDOyqpwflAevJhQmLtT,cCoHPdGguksBDOyqpwflAevJhQmLSb,cCoHPdGguksBDOyqpwflAevJhQmLSr))
  if cCoHPdGguksBDOyqpwflAevJhQmLSr=='':
   if cCoHPdGguksBDOyqpwflAevJhQmLSW=='':
    cCoHPdGguksBDOyqpwflAevJhQmLzY.addon_noti(__language__(30907).encode('utf8'))
   else:
    cCoHPdGguksBDOyqpwflAevJhQmLzY.addon_log('drm_license_1 : %s'%(cCoHPdGguksBDOyqpwflAevJhQmLSW))
    cCoHPdGguksBDOyqpwflAevJhQmLzY.addon_noti(cCoHPdGguksBDOyqpwflAevJhQmLSW)
   return
  else:
   cCoHPdGguksBDOyqpwflAevJhQmLzY.addon_log('drm_license : %s'%(cCoHPdGguksBDOyqpwflAevJhQmLSW))
  cCoHPdGguksBDOyqpwflAevJhQmLSx='PCID=%s;token=%s;member_srl=%s;NEXT_LOCALE=%s;bm_mi=%s;ak_bmsc=%s;bm_sv=%s;session_web_id=%s;device_id=%s'%(cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.CP['SESSION']['PCID'],cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.CP['SESSION']['token'],cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.CP['SESSION']['member_srl'],cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.CP['SESSION']['NEXT_LOCALE'],cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.CP['SESSION']['bm_mi'],cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.CP['SESSION']['ak_bmsc'],cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.CP['SESSION']['bm_sv'],cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.CP['SESSION']['session_web_id'],cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.CP['SESSION']['device_id'],)
  if cCoHPdGguksBDOyqpwflAevJhQmLtT in['EPISODE']:
   cCoHPdGguksBDOyqpwflAevJhQmLSU='https://www.coupangplay.com/play/{}/episode?titleId={}&type=EPISODE&sourceType=page_discover_title_detail%3Apage_discover_feed'.format(cCoHPdGguksBDOyqpwflAevJhQmLSb,cCoHPdGguksBDOyqpwflAevJhQmLSb)
  elif cCoHPdGguksBDOyqpwflAevJhQmLtT in['MOVIE']:
   cCoHPdGguksBDOyqpwflAevJhQmLSU='https://www.coupangplay.com/play/{}/movie?sourceType=page_discover_feed'.format(cCoHPdGguksBDOyqpwflAevJhQmLSb)
  else:
   cCoHPdGguksBDOyqpwflAevJhQmLSU='https://www.coupangplay.com/play/'+cCoHPdGguksBDOyqpwflAevJhQmLSb 
  cCoHPdGguksBDOyqpwflAevJhQmLRz,cCoHPdGguksBDOyqpwflAevJhQmLRX,cCoHPdGguksBDOyqpwflAevJhQmLRt=cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.Make_authHeader()
  cCoHPdGguksBDOyqpwflAevJhQmLRS=cCoHPdGguksBDOyqpwflAevJhQmLSr 
  cCoHPdGguksBDOyqpwflAevJhQmLzY.addon_log('tobe, surl : %s'%(cCoHPdGguksBDOyqpwflAevJhQmLRS))
  cCoHPdGguksBDOyqpwflAevJhQmLRM=xbmcgui.ListItem(path=cCoHPdGguksBDOyqpwflAevJhQmLRS)
  cCoHPdGguksBDOyqpwflAevJhQmLRY=cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.Get_Url_PostFix(cCoHPdGguksBDOyqpwflAevJhQmLSr) 
  cCoHPdGguksBDOyqpwflAevJhQmLzY.addon_log('post_fix : '+cCoHPdGguksBDOyqpwflAevJhQmLRY)
  if cCoHPdGguksBDOyqpwflAevJhQmLRY=='m3u8':
   cCoHPdGguksBDOyqpwflAevJhQmLRa ='hls' 
  else:
   cCoHPdGguksBDOyqpwflAevJhQmLRa ='mpd' 
  if cCoHPdGguksBDOyqpwflAevJhQmLSW:
   cCoHPdGguksBDOyqpwflAevJhQmLRF =cCoHPdGguksBDOyqpwflAevJhQmLSW 
   cCoHPdGguksBDOyqpwflAevJhQmLRT ='com.widevine.alpha'
   cCoHPdGguksBDOyqpwflAevJhQmLRi={'traceparent':cCoHPdGguksBDOyqpwflAevJhQmLRz,'tracestate':cCoHPdGguksBDOyqpwflAevJhQmLRX,'newrelic':cCoHPdGguksBDOyqpwflAevJhQmLRt,'User-Agent':cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.USER_AGENT,'Referer':cCoHPdGguksBDOyqpwflAevJhQmLSU,'Cookie':cCoHPdGguksBDOyqpwflAevJhQmLSx,}
   cCoHPdGguksBDOyqpwflAevJhQmLRn=cCoHPdGguksBDOyqpwflAevJhQmLRF+'|'+urllib.parse.urlencode(cCoHPdGguksBDOyqpwflAevJhQmLRi)+'|R{SSM}|'
   cCoHPdGguksBDOyqpwflAevJhQmLRM.setProperty('inputstream','inputstream.adaptive')
   cCoHPdGguksBDOyqpwflAevJhQmLRM.setProperty('inputstream.adaptive.manifest_type',cCoHPdGguksBDOyqpwflAevJhQmLRa)
   cCoHPdGguksBDOyqpwflAevJhQmLRM.setProperty('inputstream.adaptive.license_type',cCoHPdGguksBDOyqpwflAevJhQmLRT)
   cCoHPdGguksBDOyqpwflAevJhQmLRM.setProperty('inputstream.adaptive.license_key',cCoHPdGguksBDOyqpwflAevJhQmLRn)
   cCoHPdGguksBDOyqpwflAevJhQmLRM.setProperty('inputstream.adaptive.stream_headers','User-Agent={}&Cookie={}&Referer={}&traceparent={}&tracestate={}&newrelic={}'.format(cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.USER_AGENT,cCoHPdGguksBDOyqpwflAevJhQmLSx,cCoHPdGguksBDOyqpwflAevJhQmLSU,cCoHPdGguksBDOyqpwflAevJhQmLRz,cCoHPdGguksBDOyqpwflAevJhQmLRX,cCoHPdGguksBDOyqpwflAevJhQmLRt))
   cCoHPdGguksBDOyqpwflAevJhQmLRM.setMimeType('application/dash+xml')
   cCoHPdGguksBDOyqpwflAevJhQmLRM.setContentLookup(cCoHPdGguksBDOyqpwflAevJhQmLMU)
  else:
   cCoHPdGguksBDOyqpwflAevJhQmLRM.setContentLookup(cCoHPdGguksBDOyqpwflAevJhQmLMU)
   cCoHPdGguksBDOyqpwflAevJhQmLRM.setMimeType('application/x-mpegURL')
   cCoHPdGguksBDOyqpwflAevJhQmLRM.setProperty('inputstream','inputstream.adaptive')
   cCoHPdGguksBDOyqpwflAevJhQmLRM.setProperty('inputstream.adaptive.manifest_type',cCoHPdGguksBDOyqpwflAevJhQmLRa)
   cCoHPdGguksBDOyqpwflAevJhQmLRM.setProperty('inputstream.adaptive.stream_headers','User-Agent={}&Cookie={}&Referer={}&traceparent={}&tracestate={}&newrelic={}'.format(cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.USER_AGENT,cCoHPdGguksBDOyqpwflAevJhQmLSx,cCoHPdGguksBDOyqpwflAevJhQmLSU,cCoHPdGguksBDOyqpwflAevJhQmLRz,cCoHPdGguksBDOyqpwflAevJhQmLRX,cCoHPdGguksBDOyqpwflAevJhQmLRt))
  xbmcplugin.setResolvedUrl(cCoHPdGguksBDOyqpwflAevJhQmLzY._addon_handle,cCoHPdGguksBDOyqpwflAevJhQmLYz,cCoHPdGguksBDOyqpwflAevJhQmLRM)
  try:
   if cCoHPdGguksBDOyqpwflAevJhQmLtT=='MOVIE':
    cCoHPdGguksBDOyqpwflAevJhQmLRI='movie'
    cCoHPdGguksBDOyqpwflAevJhQmLXT={'code':cCoHPdGguksBDOyqpwflAevJhQmLSb,'asis':cCoHPdGguksBDOyqpwflAevJhQmLtT,'title':args.get('title'),'img':args.get('thumbnail'),}
    cCoHPdGguksBDOyqpwflAevJhQmLzY.Save_Watched_List(cCoHPdGguksBDOyqpwflAevJhQmLRI,cCoHPdGguksBDOyqpwflAevJhQmLXT)
   elif cCoHPdGguksBDOyqpwflAevJhQmLtT=='TVSHOW':
    cCoHPdGguksBDOyqpwflAevJhQmLRI='tvshow'
    cCoHPdGguksBDOyqpwflAevJhQmLXT={'code':args.get('programid'),'asis':cCoHPdGguksBDOyqpwflAevJhQmLtT,'title':'%s <%s>'%(args.get('title'),args.get('programnm')),'img':args.get('programimg'),}
    cCoHPdGguksBDOyqpwflAevJhQmLzY.Save_Watched_List(cCoHPdGguksBDOyqpwflAevJhQmLRI,cCoHPdGguksBDOyqpwflAevJhQmLXT)
  except:
   cCoHPdGguksBDOyqpwflAevJhQmLMx
 def dp_Global_Search(cCoHPdGguksBDOyqpwflAevJhQmLzY,args):
  cCoHPdGguksBDOyqpwflAevJhQmLtx=args.get('mode')
  if cCoHPdGguksBDOyqpwflAevJhQmLtx=='TOTAL_SEARCH':
   cCoHPdGguksBDOyqpwflAevJhQmLRK='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   cCoHPdGguksBDOyqpwflAevJhQmLRK='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(cCoHPdGguksBDOyqpwflAevJhQmLRK)
 def dp_Bookmark_Menu(cCoHPdGguksBDOyqpwflAevJhQmLzY,args):
  cCoHPdGguksBDOyqpwflAevJhQmLRK='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(cCoHPdGguksBDOyqpwflAevJhQmLRK)
 def dp_Search_List(cCoHPdGguksBDOyqpwflAevJhQmLzY,args):
  cCoHPdGguksBDOyqpwflAevJhQmLtV =cCoHPdGguksBDOyqpwflAevJhQmLYR(args.get('page'))
  if 'search_key' in args:
   cCoHPdGguksBDOyqpwflAevJhQmLRV=args.get('search_key')
  else:
   cCoHPdGguksBDOyqpwflAevJhQmLRV=cCoHPdGguksBDOyqpwflAevJhQmLzY.get_keyboard_input(__language__(30908).encode('utf-8'))
   if not cCoHPdGguksBDOyqpwflAevJhQmLRV:
    return
  cCoHPdGguksBDOyqpwflAevJhQmLRj,cCoHPdGguksBDOyqpwflAevJhQmLtj=cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.Get_Search_List(cCoHPdGguksBDOyqpwflAevJhQmLRV,cCoHPdGguksBDOyqpwflAevJhQmLtV)
  for cCoHPdGguksBDOyqpwflAevJhQmLRE in cCoHPdGguksBDOyqpwflAevJhQmLRj:
   cCoHPdGguksBDOyqpwflAevJhQmLYi =cCoHPdGguksBDOyqpwflAevJhQmLRE.get('id')
   cCoHPdGguksBDOyqpwflAevJhQmLXS =cCoHPdGguksBDOyqpwflAevJhQmLRE.get('title')
   cCoHPdGguksBDOyqpwflAevJhQmLtT =cCoHPdGguksBDOyqpwflAevJhQmLRE.get('asis')
   cCoHPdGguksBDOyqpwflAevJhQmLtF =cCoHPdGguksBDOyqpwflAevJhQmLRE.get('thumbnail')
   cCoHPdGguksBDOyqpwflAevJhQmLtE =cCoHPdGguksBDOyqpwflAevJhQmLRE.get('mpaa')
   cCoHPdGguksBDOyqpwflAevJhQmLtb =cCoHPdGguksBDOyqpwflAevJhQmLRE.get('year')
   cCoHPdGguksBDOyqpwflAevJhQmLtK =cCoHPdGguksBDOyqpwflAevJhQmLRE.get('duration')
   cCoHPdGguksBDOyqpwflAevJhQmLtN =cCoHPdGguksBDOyqpwflAevJhQmLRE.get('badge')
   if cCoHPdGguksBDOyqpwflAevJhQmLtT=='TVSHOW': 
    cCoHPdGguksBDOyqpwflAevJhQmLtx ='SEASON_LIST'
    cCoHPdGguksBDOyqpwflAevJhQmLtM={'mediatype':'tvshow','title':cCoHPdGguksBDOyqpwflAevJhQmLXS,'mpaa':cCoHPdGguksBDOyqpwflAevJhQmLtE,'year':cCoHPdGguksBDOyqpwflAevJhQmLtb,'plot':'Year : %s'%(cCoHPdGguksBDOyqpwflAevJhQmLtb),}
    cCoHPdGguksBDOyqpwflAevJhQmLXi =cCoHPdGguksBDOyqpwflAevJhQmLYz
   elif cCoHPdGguksBDOyqpwflAevJhQmLtT=='MOVIE':
    cCoHPdGguksBDOyqpwflAevJhQmLtx ='MOVIE'
    cCoHPdGguksBDOyqpwflAevJhQmLtM={'mediatype':'movie','title':cCoHPdGguksBDOyqpwflAevJhQmLXS,'mpaa':cCoHPdGguksBDOyqpwflAevJhQmLtE,'duration':cCoHPdGguksBDOyqpwflAevJhQmLtK,'year':cCoHPdGguksBDOyqpwflAevJhQmLtb,'plot':'(%s)'%(cCoHPdGguksBDOyqpwflAevJhQmLtE),}
    cCoHPdGguksBDOyqpwflAevJhQmLXi =cCoHPdGguksBDOyqpwflAevJhQmLMU
    cCoHPdGguksBDOyqpwflAevJhQmLXS +=' (%s)'%(cCoHPdGguksBDOyqpwflAevJhQmLYT(cCoHPdGguksBDOyqpwflAevJhQmLtb))
   elif cCoHPdGguksBDOyqpwflAevJhQmLtT=='HIGHLIGHT':
    cCoHPdGguksBDOyqpwflAevJhQmLtx ='HIGHLIGHT'
    cCoHPdGguksBDOyqpwflAevJhQmLtM={'mediatype':'episode','title':cCoHPdGguksBDOyqpwflAevJhQmLXS,'duration':cCoHPdGguksBDOyqpwflAevJhQmLtK,'plot':cCoHPdGguksBDOyqpwflAevJhQmLtx,}
    cCoHPdGguksBDOyqpwflAevJhQmLXi =cCoHPdGguksBDOyqpwflAevJhQmLMU
   elif cCoHPdGguksBDOyqpwflAevJhQmLtT=='LIVE':
    cCoHPdGguksBDOyqpwflAevJhQmLtx ='LIVE'
    cCoHPdGguksBDOyqpwflAevJhQmLtM={'mediatype':'episode','title':cCoHPdGguksBDOyqpwflAevJhQmLXS,'plot':cCoHPdGguksBDOyqpwflAevJhQmLtx,}
    cCoHPdGguksBDOyqpwflAevJhQmLXi =cCoHPdGguksBDOyqpwflAevJhQmLMU
   cCoHPdGguksBDOyqpwflAevJhQmLXT={'mode':cCoHPdGguksBDOyqpwflAevJhQmLtx,'id':cCoHPdGguksBDOyqpwflAevJhQmLYi,'asis':cCoHPdGguksBDOyqpwflAevJhQmLtT,'seasonList':'','title':cCoHPdGguksBDOyqpwflAevJhQmLXS,'thumbnail':json.dumps(cCoHPdGguksBDOyqpwflAevJhQmLtF,separators=(',',':')),'year':cCoHPdGguksBDOyqpwflAevJhQmLtb,}
   if cCoHPdGguksBDOyqpwflAevJhQmLzY.get_settings_makebookmark()and cCoHPdGguksBDOyqpwflAevJhQmLtT not in['HIGHLIGHT','']:
    cCoHPdGguksBDOyqpwflAevJhQmLtU={'videoid':cCoHPdGguksBDOyqpwflAevJhQmLYi,'vidtype':'movie' if cCoHPdGguksBDOyqpwflAevJhQmLtT=='MOVIE' else 'tvshow','vtitle':cCoHPdGguksBDOyqpwflAevJhQmLXS,'vsubtitle':'',}
    cCoHPdGguksBDOyqpwflAevJhQmLSz=json.dumps(cCoHPdGguksBDOyqpwflAevJhQmLtU)
    cCoHPdGguksBDOyqpwflAevJhQmLSz=urllib.parse.quote(cCoHPdGguksBDOyqpwflAevJhQmLSz)
    cCoHPdGguksBDOyqpwflAevJhQmLSX='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(cCoHPdGguksBDOyqpwflAevJhQmLSz)
    cCoHPdGguksBDOyqpwflAevJhQmLSt=[('(통합) 찜 영상에 추가',cCoHPdGguksBDOyqpwflAevJhQmLSX)]
   else:
    cCoHPdGguksBDOyqpwflAevJhQmLSt=cCoHPdGguksBDOyqpwflAevJhQmLMx
   cCoHPdGguksBDOyqpwflAevJhQmLzY.add_dir(cCoHPdGguksBDOyqpwflAevJhQmLXS,sublabel=cCoHPdGguksBDOyqpwflAevJhQmLtN,img=cCoHPdGguksBDOyqpwflAevJhQmLtF,infoLabels=cCoHPdGguksBDOyqpwflAevJhQmLtM,isFolder=cCoHPdGguksBDOyqpwflAevJhQmLXi,params=cCoHPdGguksBDOyqpwflAevJhQmLXT,ContextMenu=cCoHPdGguksBDOyqpwflAevJhQmLSt)
  if cCoHPdGguksBDOyqpwflAevJhQmLtj:
   cCoHPdGguksBDOyqpwflAevJhQmLXT={}
   cCoHPdGguksBDOyqpwflAevJhQmLXT['mode'] ='LOCAL_SEARCH'
   cCoHPdGguksBDOyqpwflAevJhQmLXT['search_key']=cCoHPdGguksBDOyqpwflAevJhQmLRV
   cCoHPdGguksBDOyqpwflAevJhQmLXT['page'] =cCoHPdGguksBDOyqpwflAevJhQmLYT(cCoHPdGguksBDOyqpwflAevJhQmLtV+1)
   cCoHPdGguksBDOyqpwflAevJhQmLXS='[B]%s >>[/B]'%'다음 페이지'
   cCoHPdGguksBDOyqpwflAevJhQmLSR=cCoHPdGguksBDOyqpwflAevJhQmLYT(cCoHPdGguksBDOyqpwflAevJhQmLtV+1)
   cCoHPdGguksBDOyqpwflAevJhQmLXF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   cCoHPdGguksBDOyqpwflAevJhQmLzY.add_dir(cCoHPdGguksBDOyqpwflAevJhQmLXS,sublabel=cCoHPdGguksBDOyqpwflAevJhQmLSR,img=cCoHPdGguksBDOyqpwflAevJhQmLXF,infoLabels=cCoHPdGguksBDOyqpwflAevJhQmLMx,isFolder=cCoHPdGguksBDOyqpwflAevJhQmLYz,params=cCoHPdGguksBDOyqpwflAevJhQmLXT)
  xbmcplugin.setContent(cCoHPdGguksBDOyqpwflAevJhQmLzY._addon_handle,'movies')
  xbmcplugin.endOfDirectory(cCoHPdGguksBDOyqpwflAevJhQmLzY._addon_handle,cacheToDisc=cCoHPdGguksBDOyqpwflAevJhQmLYz)
  if args.get('historyyn')=='Y':cCoHPdGguksBDOyqpwflAevJhQmLzY.Save_Searched_List(cCoHPdGguksBDOyqpwflAevJhQmLRV)
 def Load_List_File(cCoHPdGguksBDOyqpwflAevJhQmLzY,cCoHPdGguksBDOyqpwflAevJhQmLRI): 
  try:
   if cCoHPdGguksBDOyqpwflAevJhQmLRI=='search':
    cCoHPdGguksBDOyqpwflAevJhQmLRN=cCoHPdGguksBDOyqpwflAevJhQmLzM
   elif cCoHPdGguksBDOyqpwflAevJhQmLRI in['tvshow','movie']:
    cCoHPdGguksBDOyqpwflAevJhQmLRN=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%cCoHPdGguksBDOyqpwflAevJhQmLRI))
   else:
    return[]
   fp=cCoHPdGguksBDOyqpwflAevJhQmLYa(cCoHPdGguksBDOyqpwflAevJhQmLRN,'r',-1,'utf-8')
   cCoHPdGguksBDOyqpwflAevJhQmLRb=fp.readlines()
   fp.close()
  except:
   cCoHPdGguksBDOyqpwflAevJhQmLRb=[]
  return cCoHPdGguksBDOyqpwflAevJhQmLRb
 def Save_Watched_List(cCoHPdGguksBDOyqpwflAevJhQmLzY,cCoHPdGguksBDOyqpwflAevJhQmLRI,cCoHPdGguksBDOyqpwflAevJhQmLzT):
  try:
   cCoHPdGguksBDOyqpwflAevJhQmLRr=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%cCoHPdGguksBDOyqpwflAevJhQmLRI))
   cCoHPdGguksBDOyqpwflAevJhQmLRW=cCoHPdGguksBDOyqpwflAevJhQmLzY.Load_List_File(cCoHPdGguksBDOyqpwflAevJhQmLRI) 
   fp=cCoHPdGguksBDOyqpwflAevJhQmLYa(cCoHPdGguksBDOyqpwflAevJhQmLRr,'w',-1,'utf-8')
   cCoHPdGguksBDOyqpwflAevJhQmLRx=urllib.parse.urlencode(cCoHPdGguksBDOyqpwflAevJhQmLzT)
   cCoHPdGguksBDOyqpwflAevJhQmLRx=cCoHPdGguksBDOyqpwflAevJhQmLRx+'\n'
   fp.write(cCoHPdGguksBDOyqpwflAevJhQmLRx)
   cCoHPdGguksBDOyqpwflAevJhQmLRU=0
   for cCoHPdGguksBDOyqpwflAevJhQmLMz in cCoHPdGguksBDOyqpwflAevJhQmLRW:
    cCoHPdGguksBDOyqpwflAevJhQmLMX=cCoHPdGguksBDOyqpwflAevJhQmLYt(urllib.parse.parse_qsl(cCoHPdGguksBDOyqpwflAevJhQmLMz))
    cCoHPdGguksBDOyqpwflAevJhQmLMt=cCoHPdGguksBDOyqpwflAevJhQmLzT.get('code').strip()
    cCoHPdGguksBDOyqpwflAevJhQmLMS=cCoHPdGguksBDOyqpwflAevJhQmLMX.get('code').strip()
    if cCoHPdGguksBDOyqpwflAevJhQmLMt!=cCoHPdGguksBDOyqpwflAevJhQmLMS:
     fp.write(cCoHPdGguksBDOyqpwflAevJhQmLMz)
     cCoHPdGguksBDOyqpwflAevJhQmLRU+=1
     if cCoHPdGguksBDOyqpwflAevJhQmLRU>=50:break
   fp.close()
  except:
   cCoHPdGguksBDOyqpwflAevJhQmLMx
 def Save_Searched_List(cCoHPdGguksBDOyqpwflAevJhQmLzY,cCoHPdGguksBDOyqpwflAevJhQmLRV):
  try:
   cCoHPdGguksBDOyqpwflAevJhQmLRV=cCoHPdGguksBDOyqpwflAevJhQmLRV.strip()
   cCoHPdGguksBDOyqpwflAevJhQmLRW=cCoHPdGguksBDOyqpwflAevJhQmLzY.Load_List_File('search') 
   fp=cCoHPdGguksBDOyqpwflAevJhQmLYa(cCoHPdGguksBDOyqpwflAevJhQmLzM,'w',-1,'utf-8')
   fp.write(cCoHPdGguksBDOyqpwflAevJhQmLRV+'\n')
   cCoHPdGguksBDOyqpwflAevJhQmLRU=0
   for cCoHPdGguksBDOyqpwflAevJhQmLMz in cCoHPdGguksBDOyqpwflAevJhQmLRW:
    cCoHPdGguksBDOyqpwflAevJhQmLMz=cCoHPdGguksBDOyqpwflAevJhQmLMz.strip()
    if cCoHPdGguksBDOyqpwflAevJhQmLRV!=cCoHPdGguksBDOyqpwflAevJhQmLMz:
     fp.write(cCoHPdGguksBDOyqpwflAevJhQmLMz+'\n')
     cCoHPdGguksBDOyqpwflAevJhQmLRU+=1
     if cCoHPdGguksBDOyqpwflAevJhQmLRU>=50:break
   fp.close()
  except:
   cCoHPdGguksBDOyqpwflAevJhQmLMx
 def dp_Search_History(cCoHPdGguksBDOyqpwflAevJhQmLzY,args):
  cCoHPdGguksBDOyqpwflAevJhQmLMR=cCoHPdGguksBDOyqpwflAevJhQmLzY.Load_List_File('search')
  for cCoHPdGguksBDOyqpwflAevJhQmLMY in cCoHPdGguksBDOyqpwflAevJhQmLMR:
   cCoHPdGguksBDOyqpwflAevJhQmLMY=cCoHPdGguksBDOyqpwflAevJhQmLMY.strip()
   cCoHPdGguksBDOyqpwflAevJhQmLXT={'mode':'LOCAL_SEARCH','search_key':cCoHPdGguksBDOyqpwflAevJhQmLMY,'page':'1','historyyn':'Y',}
   cCoHPdGguksBDOyqpwflAevJhQmLMa={'mode':'SEARCH_REMOVE','stype':'ONE','skey':cCoHPdGguksBDOyqpwflAevJhQmLMY,}
   cCoHPdGguksBDOyqpwflAevJhQmLMF=urllib.parse.urlencode(cCoHPdGguksBDOyqpwflAevJhQmLMa)
   cCoHPdGguksBDOyqpwflAevJhQmLSt=[('선택된 검색어 ( %s ) 삭제'%(cCoHPdGguksBDOyqpwflAevJhQmLMY),'RunPlugin(plugin://plugin.video.coupangm/?%s)'%(cCoHPdGguksBDOyqpwflAevJhQmLMF))]
   cCoHPdGguksBDOyqpwflAevJhQmLzY.add_dir(cCoHPdGguksBDOyqpwflAevJhQmLMY,sublabel='',img=cCoHPdGguksBDOyqpwflAevJhQmLMx,infoLabels=cCoHPdGguksBDOyqpwflAevJhQmLMx,isFolder=cCoHPdGguksBDOyqpwflAevJhQmLYz,params=cCoHPdGguksBDOyqpwflAevJhQmLXT,ContextMenu=cCoHPdGguksBDOyqpwflAevJhQmLSt)
  cCoHPdGguksBDOyqpwflAevJhQmLtM={'plot':'검색목록 전체를 삭제합니다.'}
  cCoHPdGguksBDOyqpwflAevJhQmLXS='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  cCoHPdGguksBDOyqpwflAevJhQmLXT={'mode':'SEARCH_REMOVE','stype':'ALL','skey':'-',}
  cCoHPdGguksBDOyqpwflAevJhQmLXF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  cCoHPdGguksBDOyqpwflAevJhQmLzY.add_dir(cCoHPdGguksBDOyqpwflAevJhQmLXS,sublabel='',img=cCoHPdGguksBDOyqpwflAevJhQmLXF,infoLabels=cCoHPdGguksBDOyqpwflAevJhQmLtM,isFolder=cCoHPdGguksBDOyqpwflAevJhQmLMU,params=cCoHPdGguksBDOyqpwflAevJhQmLXT,isLink=cCoHPdGguksBDOyqpwflAevJhQmLYz)
  xbmcplugin.endOfDirectory(cCoHPdGguksBDOyqpwflAevJhQmLzY._addon_handle,cacheToDisc=cCoHPdGguksBDOyqpwflAevJhQmLMU)
 def dp_Listfile_Delete(cCoHPdGguksBDOyqpwflAevJhQmLzY,args):
  cCoHPdGguksBDOyqpwflAevJhQmLRI=args.get('stype')
  cCoHPdGguksBDOyqpwflAevJhQmLMT =args.get('skey')
  cCoHPdGguksBDOyqpwflAevJhQmLzn=xbmcgui.Dialog()
  if cCoHPdGguksBDOyqpwflAevJhQmLRI=='ALL':
   cCoHPdGguksBDOyqpwflAevJhQmLXV=cCoHPdGguksBDOyqpwflAevJhQmLzn.yesno(__language__(30911).encode('utf8'),__language__(30906).encode('utf8'))
  elif cCoHPdGguksBDOyqpwflAevJhQmLRI=='ONE':
   cCoHPdGguksBDOyqpwflAevJhQmLXV=cCoHPdGguksBDOyqpwflAevJhQmLzn.yesno(__language__(30912).encode('utf8'),__language__(30906).encode('utf8'))
  elif cCoHPdGguksBDOyqpwflAevJhQmLRI in['tvshow','movie']:
   cCoHPdGguksBDOyqpwflAevJhQmLXV=cCoHPdGguksBDOyqpwflAevJhQmLzn.yesno(__language__(30913).encode('utf8'),__language__(30906).encode('utf8'))
  if cCoHPdGguksBDOyqpwflAevJhQmLXV==cCoHPdGguksBDOyqpwflAevJhQmLMU:sys.exit()
  cCoHPdGguksBDOyqpwflAevJhQmLzY.Delete_List_File(cCoHPdGguksBDOyqpwflAevJhQmLRI,skey=cCoHPdGguksBDOyqpwflAevJhQmLMT)
  xbmc.executebuiltin("Container.Refresh")
 def Delete_List_File(cCoHPdGguksBDOyqpwflAevJhQmLzY,cCoHPdGguksBDOyqpwflAevJhQmLRI,skey='-'):
  if cCoHPdGguksBDOyqpwflAevJhQmLRI=='ALL':
   try:
    cCoHPdGguksBDOyqpwflAevJhQmLRN=cCoHPdGguksBDOyqpwflAevJhQmLzM
    fp=cCoHPdGguksBDOyqpwflAevJhQmLYa(cCoHPdGguksBDOyqpwflAevJhQmLRN,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    cCoHPdGguksBDOyqpwflAevJhQmLMx
  elif cCoHPdGguksBDOyqpwflAevJhQmLRI=='ONE':
   try:
    cCoHPdGguksBDOyqpwflAevJhQmLRN=cCoHPdGguksBDOyqpwflAevJhQmLzM
    cCoHPdGguksBDOyqpwflAevJhQmLRW=cCoHPdGguksBDOyqpwflAevJhQmLzY.Load_List_File('search') 
    fp=cCoHPdGguksBDOyqpwflAevJhQmLYa(cCoHPdGguksBDOyqpwflAevJhQmLRN,'w',-1,'utf-8')
    for cCoHPdGguksBDOyqpwflAevJhQmLMz in cCoHPdGguksBDOyqpwflAevJhQmLRW:
     if skey!=cCoHPdGguksBDOyqpwflAevJhQmLMz.strip():
      fp.write(cCoHPdGguksBDOyqpwflAevJhQmLMz)
    fp.close()
   except:
    cCoHPdGguksBDOyqpwflAevJhQmLMx
  elif cCoHPdGguksBDOyqpwflAevJhQmLRI in['tvshow','movie']:
   try:
    cCoHPdGguksBDOyqpwflAevJhQmLRN=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%cCoHPdGguksBDOyqpwflAevJhQmLRI))
    fp=cCoHPdGguksBDOyqpwflAevJhQmLYa(cCoHPdGguksBDOyqpwflAevJhQmLRN,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    cCoHPdGguksBDOyqpwflAevJhQmLMx
 def dp_Watch_List(cCoHPdGguksBDOyqpwflAevJhQmLzY,args):
  cCoHPdGguksBDOyqpwflAevJhQmLRI =args.get('stype')
  if cCoHPdGguksBDOyqpwflAevJhQmLRI in['',cCoHPdGguksBDOyqpwflAevJhQmLMx]:
   for cCoHPdGguksBDOyqpwflAevJhQmLMi in cCoHPdGguksBDOyqpwflAevJhQmLzS:
    cCoHPdGguksBDOyqpwflAevJhQmLXS=cCoHPdGguksBDOyqpwflAevJhQmLMi.get('title')
    cCoHPdGguksBDOyqpwflAevJhQmLXT={'mode':cCoHPdGguksBDOyqpwflAevJhQmLMi.get('mode'),'stype':cCoHPdGguksBDOyqpwflAevJhQmLMi.get('stype'),}
    cCoHPdGguksBDOyqpwflAevJhQmLzY.add_dir(cCoHPdGguksBDOyqpwflAevJhQmLXS,sublabel='',img='',infoLabels=cCoHPdGguksBDOyqpwflAevJhQmLMx,isFolder=cCoHPdGguksBDOyqpwflAevJhQmLYz,params=cCoHPdGguksBDOyqpwflAevJhQmLXT)
   xbmcplugin.endOfDirectory(cCoHPdGguksBDOyqpwflAevJhQmLzY._addon_handle)
  else:
   cCoHPdGguksBDOyqpwflAevJhQmLMn=cCoHPdGguksBDOyqpwflAevJhQmLzY.Load_List_File(cCoHPdGguksBDOyqpwflAevJhQmLRI)
   for cCoHPdGguksBDOyqpwflAevJhQmLMI in cCoHPdGguksBDOyqpwflAevJhQmLMn:
    cCoHPdGguksBDOyqpwflAevJhQmLMK=cCoHPdGguksBDOyqpwflAevJhQmLYt(urllib.parse.parse_qsl(cCoHPdGguksBDOyqpwflAevJhQmLMI))
    cCoHPdGguksBDOyqpwflAevJhQmLSb =cCoHPdGguksBDOyqpwflAevJhQmLMK.get('code').strip()
    cCoHPdGguksBDOyqpwflAevJhQmLXS =cCoHPdGguksBDOyqpwflAevJhQmLMK.get('title').strip()
    cCoHPdGguksBDOyqpwflAevJhQmLtF =cCoHPdGguksBDOyqpwflAevJhQmLMK.get('img').strip()
    cCoHPdGguksBDOyqpwflAevJhQmLtT =cCoHPdGguksBDOyqpwflAevJhQmLMK.get('asis').strip()
    try:
     cCoHPdGguksBDOyqpwflAevJhQmLtF=cCoHPdGguksBDOyqpwflAevJhQmLtF.replace('\'','\"')
     cCoHPdGguksBDOyqpwflAevJhQmLtF=json.loads(cCoHPdGguksBDOyqpwflAevJhQmLtF)
    except:
     cCoHPdGguksBDOyqpwflAevJhQmLMx
    cCoHPdGguksBDOyqpwflAevJhQmLtM={}
    cCoHPdGguksBDOyqpwflAevJhQmLtM['plot']=cCoHPdGguksBDOyqpwflAevJhQmLXS
    if cCoHPdGguksBDOyqpwflAevJhQmLRI=='movie':
     cCoHPdGguksBDOyqpwflAevJhQmLtM['mediatype']='movie'
     cCoHPdGguksBDOyqpwflAevJhQmLXT={'mode':'MOVIE','id':cCoHPdGguksBDOyqpwflAevJhQmLSb,'asis':cCoHPdGguksBDOyqpwflAevJhQmLtT,'title':cCoHPdGguksBDOyqpwflAevJhQmLXS,'thumbnail':cCoHPdGguksBDOyqpwflAevJhQmLtF,}
     cCoHPdGguksBDOyqpwflAevJhQmLXi=cCoHPdGguksBDOyqpwflAevJhQmLMU
    else:
     cCoHPdGguksBDOyqpwflAevJhQmLtM['mediatype']='episode'
     cCoHPdGguksBDOyqpwflAevJhQmLXT={'mode':'SEASON_LIST','id':cCoHPdGguksBDOyqpwflAevJhQmLSb,'asis':cCoHPdGguksBDOyqpwflAevJhQmLtT,'title':cCoHPdGguksBDOyqpwflAevJhQmLXS,'thumbnail':json.dumps(cCoHPdGguksBDOyqpwflAevJhQmLtF,separators=(',',':')),}
     cCoHPdGguksBDOyqpwflAevJhQmLXi=cCoHPdGguksBDOyqpwflAevJhQmLYz
    cCoHPdGguksBDOyqpwflAevJhQmLzY.add_dir(cCoHPdGguksBDOyqpwflAevJhQmLXS,sublabel='',img=cCoHPdGguksBDOyqpwflAevJhQmLtF,infoLabels=cCoHPdGguksBDOyqpwflAevJhQmLtM,isFolder=cCoHPdGguksBDOyqpwflAevJhQmLXi,params=cCoHPdGguksBDOyqpwflAevJhQmLXT)
   cCoHPdGguksBDOyqpwflAevJhQmLtM={'plot':'시청목록을 삭제합니다.'}
   cCoHPdGguksBDOyqpwflAevJhQmLXS='*** 시청목록 삭제 ***'
   cCoHPdGguksBDOyqpwflAevJhQmLXT={'mode':'MYVIEW_REMOVE','stype':cCoHPdGguksBDOyqpwflAevJhQmLRI,'skey':'-',}
   cCoHPdGguksBDOyqpwflAevJhQmLXF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   cCoHPdGguksBDOyqpwflAevJhQmLzY.add_dir(cCoHPdGguksBDOyqpwflAevJhQmLXS,sublabel='',img=cCoHPdGguksBDOyqpwflAevJhQmLXF,infoLabels=cCoHPdGguksBDOyqpwflAevJhQmLtM,isFolder=cCoHPdGguksBDOyqpwflAevJhQmLMU,params=cCoHPdGguksBDOyqpwflAevJhQmLXT,isLink=cCoHPdGguksBDOyqpwflAevJhQmLYz)
   if cCoHPdGguksBDOyqpwflAevJhQmLRI=='movie':xbmcplugin.setContent(cCoHPdGguksBDOyqpwflAevJhQmLzY._addon_handle,'movies')
   else:xbmcplugin.setContent(cCoHPdGguksBDOyqpwflAevJhQmLzY._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(cCoHPdGguksBDOyqpwflAevJhQmLzY._addon_handle,cacheToDisc=cCoHPdGguksBDOyqpwflAevJhQmLMU)
 def dp_Set_Bookmark(cCoHPdGguksBDOyqpwflAevJhQmLzY,args):
  cCoHPdGguksBDOyqpwflAevJhQmLMV=urllib.parse.unquote(args.get('bm_param'))
  cCoHPdGguksBDOyqpwflAevJhQmLMV=json.loads(cCoHPdGguksBDOyqpwflAevJhQmLMV)
  cCoHPdGguksBDOyqpwflAevJhQmLMj =cCoHPdGguksBDOyqpwflAevJhQmLMV.get('videoid')
  cCoHPdGguksBDOyqpwflAevJhQmLME =cCoHPdGguksBDOyqpwflAevJhQmLMV.get('vidtype')
  cCoHPdGguksBDOyqpwflAevJhQmLMN =cCoHPdGguksBDOyqpwflAevJhQmLMV.get('vtitle')
  cCoHPdGguksBDOyqpwflAevJhQmLzn=xbmcgui.Dialog()
  cCoHPdGguksBDOyqpwflAevJhQmLXV=cCoHPdGguksBDOyqpwflAevJhQmLzn.yesno(__language__(30914).encode('utf8'),cCoHPdGguksBDOyqpwflAevJhQmLMN+' \n\n'+__language__(30915))
  if cCoHPdGguksBDOyqpwflAevJhQmLXV==cCoHPdGguksBDOyqpwflAevJhQmLMU:return
  cCoHPdGguksBDOyqpwflAevJhQmLMb=cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.GetBookmarkInfo(cCoHPdGguksBDOyqpwflAevJhQmLMj,cCoHPdGguksBDOyqpwflAevJhQmLME)
  cCoHPdGguksBDOyqpwflAevJhQmLMr=json.dumps(cCoHPdGguksBDOyqpwflAevJhQmLMb)
  cCoHPdGguksBDOyqpwflAevJhQmLMr=urllib.parse.quote(cCoHPdGguksBDOyqpwflAevJhQmLMr)
  cCoHPdGguksBDOyqpwflAevJhQmLSX ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(cCoHPdGguksBDOyqpwflAevJhQmLMr)
  xbmc.executebuiltin(cCoHPdGguksBDOyqpwflAevJhQmLSX)
 def coupang_main(cCoHPdGguksBDOyqpwflAevJhQmLzY):
  cCoHPdGguksBDOyqpwflAevJhQmLzY.CoupangObj.KodiVersion=cCoHPdGguksBDOyqpwflAevJhQmLYR(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  cCoHPdGguksBDOyqpwflAevJhQmLtx=cCoHPdGguksBDOyqpwflAevJhQmLzY.main_params.get('mode',cCoHPdGguksBDOyqpwflAevJhQmLMx)
  if cCoHPdGguksBDOyqpwflAevJhQmLtx=='LOGOUT':
   cCoHPdGguksBDOyqpwflAevJhQmLzY.CP_logout()
   return
  cCoHPdGguksBDOyqpwflAevJhQmLzY.option_check()
  if cCoHPdGguksBDOyqpwflAevJhQmLtx is cCoHPdGguksBDOyqpwflAevJhQmLMx:
   cCoHPdGguksBDOyqpwflAevJhQmLzY.dp_Main_List(cCoHPdGguksBDOyqpwflAevJhQmLzY.main_params)
  elif cCoHPdGguksBDOyqpwflAevJhQmLtx=='CATEGORY_GROUPLIST':
   cCoHPdGguksBDOyqpwflAevJhQmLzY.dp_Category_GroupList(cCoHPdGguksBDOyqpwflAevJhQmLzY.main_params)
  elif cCoHPdGguksBDOyqpwflAevJhQmLtx=='THEME_GROUPLIST':
   cCoHPdGguksBDOyqpwflAevJhQmLzY.dp_Theme_GroupList(cCoHPdGguksBDOyqpwflAevJhQmLzY.main_params)
  elif cCoHPdGguksBDOyqpwflAevJhQmLtx=='EVENT_GROUPLIST':
   cCoHPdGguksBDOyqpwflAevJhQmLzY.dp_Event_GroupList(cCoHPdGguksBDOyqpwflAevJhQmLzY.main_params)
  elif cCoHPdGguksBDOyqpwflAevJhQmLtx=='EVENT_GAMELIST':
   cCoHPdGguksBDOyqpwflAevJhQmLzY.dp_Event_GameList(cCoHPdGguksBDOyqpwflAevJhQmLzY.main_params)
  elif cCoHPdGguksBDOyqpwflAevJhQmLtx=='EVENT_LIST':
   cCoHPdGguksBDOyqpwflAevJhQmLzY.dp_Event_List(cCoHPdGguksBDOyqpwflAevJhQmLzY.main_params)
  elif cCoHPdGguksBDOyqpwflAevJhQmLtx=='CATEGORY_LIST':
   cCoHPdGguksBDOyqpwflAevJhQmLzY.dp_Category_List(cCoHPdGguksBDOyqpwflAevJhQmLzY.main_params)
  elif cCoHPdGguksBDOyqpwflAevJhQmLtx=='SEASON_LIST':
   cCoHPdGguksBDOyqpwflAevJhQmLzY.dp_Season_List(cCoHPdGguksBDOyqpwflAevJhQmLzY.main_params)
  elif cCoHPdGguksBDOyqpwflAevJhQmLtx=='EPISODE_LIST':
   cCoHPdGguksBDOyqpwflAevJhQmLzY.dp_Episode_List(cCoHPdGguksBDOyqpwflAevJhQmLzY.main_params)
  elif cCoHPdGguksBDOyqpwflAevJhQmLtx=='TEST':
   cCoHPdGguksBDOyqpwflAevJhQmLzY.dp_Test(cCoHPdGguksBDOyqpwflAevJhQmLzY.main_params)
  elif cCoHPdGguksBDOyqpwflAevJhQmLtx in['MOVIE','VOD','HIGHLIGHT','LIVE']:
   cCoHPdGguksBDOyqpwflAevJhQmLzY.play_VIDEO(cCoHPdGguksBDOyqpwflAevJhQmLzY.main_params)
  elif cCoHPdGguksBDOyqpwflAevJhQmLtx=='WATCH':
   cCoHPdGguksBDOyqpwflAevJhQmLzY.dp_Watch_List(cCoHPdGguksBDOyqpwflAevJhQmLzY.main_params)
  elif cCoHPdGguksBDOyqpwflAevJhQmLtx=='LOCAL_SEARCH':
   cCoHPdGguksBDOyqpwflAevJhQmLzY.dp_Search_List(cCoHPdGguksBDOyqpwflAevJhQmLzY.main_params)
  elif cCoHPdGguksBDOyqpwflAevJhQmLtx=='SEARCH_HISTORY':
   cCoHPdGguksBDOyqpwflAevJhQmLzY.dp_Search_History(cCoHPdGguksBDOyqpwflAevJhQmLzY.main_params)
  elif cCoHPdGguksBDOyqpwflAevJhQmLtx in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   cCoHPdGguksBDOyqpwflAevJhQmLzY.dp_Listfile_Delete(cCoHPdGguksBDOyqpwflAevJhQmLzY.main_params)
  elif cCoHPdGguksBDOyqpwflAevJhQmLtx in['TOTAL_SEARCH','TOTAL_HISTORY']:
   cCoHPdGguksBDOyqpwflAevJhQmLzY.dp_Global_Search(cCoHPdGguksBDOyqpwflAevJhQmLzY.main_params)
  elif cCoHPdGguksBDOyqpwflAevJhQmLtx=='MENU_BOOKMARK':
   cCoHPdGguksBDOyqpwflAevJhQmLzY.dp_Bookmark_Menu(cCoHPdGguksBDOyqpwflAevJhQmLzY.main_params)
  elif cCoHPdGguksBDOyqpwflAevJhQmLtx=='SET_BOOKMARK':
   cCoHPdGguksBDOyqpwflAevJhQmLzY.dp_Set_Bookmark(cCoHPdGguksBDOyqpwflAevJhQmLzY.main_params)
  else:
   cCoHPdGguksBDOyqpwflAevJhQmLMx
# Created by pyminifier (https://github.com/liftoff/pyminifier)
