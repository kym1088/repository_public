__author__="NightRain"
jlikCRVadeOAPowyEKTpsJvFfuWncN=object
jlikCRVadeOAPowyEKTpsJvFfuWncY=None
jlikCRVadeOAPowyEKTpsJvFfuWncq=False
jlikCRVadeOAPowyEKTpsJvFfuWnch=print
jlikCRVadeOAPowyEKTpsJvFfuWncS=str
jlikCRVadeOAPowyEKTpsJvFfuWncm=open
jlikCRVadeOAPowyEKTpsJvFfuWncQ=int
jlikCRVadeOAPowyEKTpsJvFfuWncM=Exception
jlikCRVadeOAPowyEKTpsJvFfuWncD=id
jlikCRVadeOAPowyEKTpsJvFfuWncB=True
jlikCRVadeOAPowyEKTpsJvFfuWncI=len
jlikCRVadeOAPowyEKTpsJvFfuWncL=range
import urllib
import re
import json
import requests
import datetime
import time
import random
import base64
class jlikCRVadeOAPowyEKTpsJvFfuWnHU(jlikCRVadeOAPowyEKTpsJvFfuWncN):
 def __init__(jlikCRVadeOAPowyEKTpsJvFfuWnHx):
  jlikCRVadeOAPowyEKTpsJvFfuWnHx.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.1901.183' 
  jlikCRVadeOAPowyEKTpsJvFfuWnHx.MODEL ='Edge_115' 
  jlikCRVadeOAPowyEKTpsJvFfuWnHx.OS_VERSION ='115' 
  jlikCRVadeOAPowyEKTpsJvFfuWnHx.DEFAULT_HEADER ={'user-agent':jlikCRVadeOAPowyEKTpsJvFfuWnHx.USER_AGENT}
  jlikCRVadeOAPowyEKTpsJvFfuWnHx.API_DOMAIN ='https://www.coupangplay.com'
  jlikCRVadeOAPowyEKTpsJvFfuWnHx.API_VIEWURL ='https://discover.coupangstreaming.com'
  jlikCRVadeOAPowyEKTpsJvFfuWnHx.PAGE_LIMIT =40
  jlikCRVadeOAPowyEKTpsJvFfuWnHx.SEARCH_LIMIT =20
  jlikCRVadeOAPowyEKTpsJvFfuWnHx.KodiVersion =20
  jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP={}
  jlikCRVadeOAPowyEKTpsJvFfuWnHx.Init_CP()
  jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP_DEVICE_FILENAME=''
  jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP_COOKIE_FILENAME=''
 def callRequestCookies(jlikCRVadeOAPowyEKTpsJvFfuWnHx,jobtype,jlikCRVadeOAPowyEKTpsJvFfuWnUc,payload=jlikCRVadeOAPowyEKTpsJvFfuWncY,params=jlikCRVadeOAPowyEKTpsJvFfuWncY,headers=jlikCRVadeOAPowyEKTpsJvFfuWncY,cookies=jlikCRVadeOAPowyEKTpsJvFfuWncY,redirects=jlikCRVadeOAPowyEKTpsJvFfuWncq):
  jlikCRVadeOAPowyEKTpsJvFfuWnHc=jlikCRVadeOAPowyEKTpsJvFfuWnHx.DEFAULT_HEADER
  if headers:jlikCRVadeOAPowyEKTpsJvFfuWnHc.update(headers)
  if jobtype=='Get':
   jlikCRVadeOAPowyEKTpsJvFfuWnHX=requests.get(jlikCRVadeOAPowyEKTpsJvFfuWnUc,params=params,headers=jlikCRVadeOAPowyEKTpsJvFfuWnHc,cookies=cookies,allow_redirects=redirects)
  else:
   jlikCRVadeOAPowyEKTpsJvFfuWnHX=requests.post(jlikCRVadeOAPowyEKTpsJvFfuWnUc,data=payload,params=params,headers=jlikCRVadeOAPowyEKTpsJvFfuWnHc,cookies=cookies,allow_redirects=redirects)
  jlikCRVadeOAPowyEKTpsJvFfuWnch(jlikCRVadeOAPowyEKTpsJvFfuWncS(jlikCRVadeOAPowyEKTpsJvFfuWnHX.status_code)+' - '+jlikCRVadeOAPowyEKTpsJvFfuWncS(jlikCRVadeOAPowyEKTpsJvFfuWnHX.url))
  return jlikCRVadeOAPowyEKTpsJvFfuWnHX
 def callRequestCookies_test(jlikCRVadeOAPowyEKTpsJvFfuWnHx,jobtype,jlikCRVadeOAPowyEKTpsJvFfuWnUc,payload=jlikCRVadeOAPowyEKTpsJvFfuWncY,params=jlikCRVadeOAPowyEKTpsJvFfuWncY,headers=jlikCRVadeOAPowyEKTpsJvFfuWncY,cookies=jlikCRVadeOAPowyEKTpsJvFfuWncY,redirects=jlikCRVadeOAPowyEKTpsJvFfuWncq):
  jlikCRVadeOAPowyEKTpsJvFfuWnHc=jlikCRVadeOAPowyEKTpsJvFfuWnHx.DEFAULT_HEADER
  if headers:jlikCRVadeOAPowyEKTpsJvFfuWnHc.update(headers)
  jlikCRVadeOAPowyEKTpsJvFfuWnHX=requests.Request('POST',jlikCRVadeOAPowyEKTpsJvFfuWnUc,headers=headers,data=payload,params=params,cookies=cookies)
  jlikCRVadeOAPowyEKTpsJvFfuWnHG=jlikCRVadeOAPowyEKTpsJvFfuWnHX.prepare()
  jlikCRVadeOAPowyEKTpsJvFfuWnHx.pretty_print_POST(jlikCRVadeOAPowyEKTpsJvFfuWnHG)
  return jlikCRVadeOAPowyEKTpsJvFfuWnHX
 def pretty_print_POST(jlikCRVadeOAPowyEKTpsJvFfuWnHx,req):
  jlikCRVadeOAPowyEKTpsJvFfuWnch('{}\n{}\r\n{}\r\n\r\n{}'.format('-----------START-----------',req.method+' '+req.url,'\r\n'.join('{}: {}'.format(k,v)for k,v in req.headers.items()),req.body,))
 def dic_To_jsonfile(jlikCRVadeOAPowyEKTpsJvFfuWnHx,filename,jlikCRVadeOAPowyEKTpsJvFfuWnHg):
  if filename=='':return
  fp=jlikCRVadeOAPowyEKTpsJvFfuWncm(filename,'w',-1,'utf-8')
  json.dump(jlikCRVadeOAPowyEKTpsJvFfuWnHg,fp,indent=4,ensure_ascii=jlikCRVadeOAPowyEKTpsJvFfuWncq)
  fp.close()
 def jsonfile_To_dic(jlikCRVadeOAPowyEKTpsJvFfuWnHx,filename):
  if filename=='':return jlikCRVadeOAPowyEKTpsJvFfuWncY
  try:
   fp=jlikCRVadeOAPowyEKTpsJvFfuWncm(filename,'r',-1,'utf-8')
   jlikCRVadeOAPowyEKTpsJvFfuWnHt=json.load(fp)
   fp.close()
  except:
   jlikCRVadeOAPowyEKTpsJvFfuWnHt={}
  return jlikCRVadeOAPowyEKTpsJvFfuWnHt
 def convert_TimeStr(jlikCRVadeOAPowyEKTpsJvFfuWnHx,jlikCRVadeOAPowyEKTpsJvFfuWnHr):
  try:
   jlikCRVadeOAPowyEKTpsJvFfuWnHr =jlikCRVadeOAPowyEKTpsJvFfuWnHr[0:16]
   jlikCRVadeOAPowyEKTpsJvFfuWnHz=datetime.datetime.strptime(jlikCRVadeOAPowyEKTpsJvFfuWnHr,'%Y-%m-%dT%H:%M')+datetime.timedelta(hours=9)
   return jlikCRVadeOAPowyEKTpsJvFfuWnHz.strftime('%Y-%m-%d %H:%M')
  except:
   return jlikCRVadeOAPowyEKTpsJvFfuWncY
 def Get_Now_Datetime(jlikCRVadeOAPowyEKTpsJvFfuWnHx):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetNoCache(jlikCRVadeOAPowyEKTpsJvFfuWnHx):
  jlikCRVadeOAPowyEKTpsJvFfuWnHY =jlikCRVadeOAPowyEKTpsJvFfuWncQ(time.time()*1000)
  return jlikCRVadeOAPowyEKTpsJvFfuWnHY
 def generatePcId(jlikCRVadeOAPowyEKTpsJvFfuWnHx):
  t=jlikCRVadeOAPowyEKTpsJvFfuWnHx.GetNoCache()
  r=random.random()
  jlikCRVadeOAPowyEKTpsJvFfuWnHq=jlikCRVadeOAPowyEKTpsJvFfuWncS(t)+jlikCRVadeOAPowyEKTpsJvFfuWncS(r)[2:12]
  return jlikCRVadeOAPowyEKTpsJvFfuWnHq
 def generatePvId(jlikCRVadeOAPowyEKTpsJvFfuWnHx,genType='1'):
  import hashlib
  m=hashlib.md5()
  jlikCRVadeOAPowyEKTpsJvFfuWnHh=jlikCRVadeOAPowyEKTpsJvFfuWncS(random.random())
  m.update(jlikCRVadeOAPowyEKTpsJvFfuWnHh.encode('utf-8'))
  jlikCRVadeOAPowyEKTpsJvFfuWnHS=jlikCRVadeOAPowyEKTpsJvFfuWncS(m.hexdigest())
  if genType=='1':
   return '%s-%s-%s-%s-%s'%(jlikCRVadeOAPowyEKTpsJvFfuWnHS[:8],jlikCRVadeOAPowyEKTpsJvFfuWnHS[8:12],jlikCRVadeOAPowyEKTpsJvFfuWnHS[12:16],jlikCRVadeOAPowyEKTpsJvFfuWnHS[16:20],jlikCRVadeOAPowyEKTpsJvFfuWnHS[20:])
  else:
   return jlikCRVadeOAPowyEKTpsJvFfuWnHS
 def Get_DeviceID(jlikCRVadeOAPowyEKTpsJvFfuWnHx):
  jlikCRVadeOAPowyEKTpsJvFfuWnHm=''
  try: 
   fp=jlikCRVadeOAPowyEKTpsJvFfuWncm(jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP_DEVICE_FILENAME,'r',-1,'utf-8')
   jlikCRVadeOAPowyEKTpsJvFfuWnHQ= json.load(fp)
   fp.close()
   jlikCRVadeOAPowyEKTpsJvFfuWnHm=jlikCRVadeOAPowyEKTpsJvFfuWnHQ.get('device_id')
  except jlikCRVadeOAPowyEKTpsJvFfuWncM as exception:
   jlikCRVadeOAPowyEKTpsJvFfuWncY
  if jlikCRVadeOAPowyEKTpsJvFfuWnHm=='':
   jlikCRVadeOAPowyEKTpsJvFfuWnHm=jlikCRVadeOAPowyEKTpsJvFfuWnHx.generatePvId(genType='1')
   try: 
    fp=jlikCRVadeOAPowyEKTpsJvFfuWncm(jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP_DEVICE_FILENAME,'w',-1,'utf-8')
    json.dump({'device_id':jlikCRVadeOAPowyEKTpsJvFfuWnHm},fp,indent=4,ensure_ascii=jlikCRVadeOAPowyEKTpsJvFfuWncq)
    fp.close()
   except jlikCRVadeOAPowyEKTpsJvFfuWncM as exception:
    return ''
  return jlikCRVadeOAPowyEKTpsJvFfuWnHm
 def Make_authHeader(jlikCRVadeOAPowyEKTpsJvFfuWnHx):
  tr=jlikCRVadeOAPowyEKTpsJvFfuWnHx.generatePvId(genType=2)
  ti=jlikCRVadeOAPowyEKTpsJvFfuWnHx.GetNoCache()
  jlikCRVadeOAPowyEKTpsJvFfuWncD=jlikCRVadeOAPowyEKTpsJvFfuWnHx.generatePvId(genType=2)[:16]
  jlikCRVadeOAPowyEKTpsJvFfuWnHM='00-%s-%s-01'%(tr,jlikCRVadeOAPowyEKTpsJvFfuWncD,)
  jlikCRVadeOAPowyEKTpsJvFfuWnHD ='%s@nr=0-1-%s-%s-%s----%s'%(jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['NREUM']['tk'],jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['NREUM']['ac'],jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['NREUM']['ap'],jlikCRVadeOAPowyEKTpsJvFfuWncD,ti,)
  jlikCRVadeOAPowyEKTpsJvFfuWnHB ='{"v":[0,1],"d":{"ty":"Browser","ac":"%s","ap":"%s","id":"%s","tr":"%s","ti":%s,"tk":"%s"}}'%(jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['NREUM']['ac'],jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['NREUM']['ap'],jlikCRVadeOAPowyEKTpsJvFfuWncD,tr,ti,jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['NREUM']['tk'],) 
  return jlikCRVadeOAPowyEKTpsJvFfuWnHM,jlikCRVadeOAPowyEKTpsJvFfuWnHD,base64.standard_b64encode(jlikCRVadeOAPowyEKTpsJvFfuWnHB.encode()).decode('utf-8')
 def Init_CP(jlikCRVadeOAPowyEKTpsJvFfuWnHx):
  jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP={}
  jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['ACCOUNT']={'cpid':'','cppw':'','cppf':'0'}
  jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']={}
 def Save_session_acount(jlikCRVadeOAPowyEKTpsJvFfuWnHx,jlikCRVadeOAPowyEKTpsJvFfuWnHI,jlikCRVadeOAPowyEKTpsJvFfuWnHL,jlikCRVadeOAPowyEKTpsJvFfuWnUH):
  jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['ACCOUNT']['cpid']=base64.standard_b64encode(jlikCRVadeOAPowyEKTpsJvFfuWnHI.encode()).decode('utf-8')
  jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['ACCOUNT']['cppw']=base64.standard_b64encode(jlikCRVadeOAPowyEKTpsJvFfuWnHL.encode()).decode('utf-8')
  jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['ACCOUNT']['cppf']=jlikCRVadeOAPowyEKTpsJvFfuWncS(jlikCRVadeOAPowyEKTpsJvFfuWnUH)
 def Load_session_acount(jlikCRVadeOAPowyEKTpsJvFfuWnHx):
  jlikCRVadeOAPowyEKTpsJvFfuWnHI=base64.standard_b64decode(jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['ACCOUNT']['cpid']).decode('utf-8')
  jlikCRVadeOAPowyEKTpsJvFfuWnHL=base64.standard_b64decode(jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['ACCOUNT']['cppw']).decode('utf-8')
  jlikCRVadeOAPowyEKTpsJvFfuWnUH=jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['ACCOUNT']['cppf']
  return jlikCRVadeOAPowyEKTpsJvFfuWnHI,jlikCRVadeOAPowyEKTpsJvFfuWnHL,jlikCRVadeOAPowyEKTpsJvFfuWnUH
 def make_CP_DefaultCookies(jlikCRVadeOAPowyEKTpsJvFfuWnHx):
  jlikCRVadeOAPowyEKTpsJvFfuWnUx={}
  if 'NEXT_LOCALE' in jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']:jlikCRVadeOAPowyEKTpsJvFfuWnUx['NEXT_LOCALE'] =jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['NEXT_LOCALE']
  if 'ak_bmsc' in jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']:jlikCRVadeOAPowyEKTpsJvFfuWnUx['ak_bmsc'] =jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['ak_bmsc']
  if 'bm_sv' in jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']:jlikCRVadeOAPowyEKTpsJvFfuWnUx['bm_sv'] =jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['bm_sv']
  if 'PCID' in jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']:jlikCRVadeOAPowyEKTpsJvFfuWnUx['PCID'] =jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['PCID']
  if 'member_srl' in jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']:jlikCRVadeOAPowyEKTpsJvFfuWnUx['member_srl'] =jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['member_srl']
  if 'token' in jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']:jlikCRVadeOAPowyEKTpsJvFfuWnUx['token'] =jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['token']
  if 'session_web_id' in jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']:jlikCRVadeOAPowyEKTpsJvFfuWnUx['session_web_id']=jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['session_web_id']
  if 'device_id' in jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']:jlikCRVadeOAPowyEKTpsJvFfuWnUx['device_id'] =jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['device_id']
  return jlikCRVadeOAPowyEKTpsJvFfuWnUx
 def Get_CP_Login(jlikCRVadeOAPowyEKTpsJvFfuWnHx,userid,userpw,jlikCRVadeOAPowyEKTpsJvFfuWnUq):
  try:
   jlikCRVadeOAPowyEKTpsJvFfuWnUc=jlikCRVadeOAPowyEKTpsJvFfuWnHx.API_DOMAIN
   jlikCRVadeOAPowyEKTpsJvFfuWnUX={'Accept-Language':'ko-KR,ko;q=0.9',}
   jlikCRVadeOAPowyEKTpsJvFfuWnUG=jlikCRVadeOAPowyEKTpsJvFfuWnHx.callRequestCookies('Get',jlikCRVadeOAPowyEKTpsJvFfuWnUc,payload=jlikCRVadeOAPowyEKTpsJvFfuWncY,params=jlikCRVadeOAPowyEKTpsJvFfuWncY,headers=jlikCRVadeOAPowyEKTpsJvFfuWnUX,cookies=jlikCRVadeOAPowyEKTpsJvFfuWncY,redirects=jlikCRVadeOAPowyEKTpsJvFfuWncq)
   if jlikCRVadeOAPowyEKTpsJvFfuWnUG.status_code not in[301,302]:return jlikCRVadeOAPowyEKTpsJvFfuWncq
   for jlikCRVadeOAPowyEKTpsJvFfuWnUg in jlikCRVadeOAPowyEKTpsJvFfuWnUG.cookies:
    jlikCRVadeOAPowyEKTpsJvFfuWnch(jlikCRVadeOAPowyEKTpsJvFfuWnUg.name,jlikCRVadeOAPowyEKTpsJvFfuWnUg.value) 
    if jlikCRVadeOAPowyEKTpsJvFfuWnUg.name=='NEXT_LOCALE':
     jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['NEXT_LOCALE']=jlikCRVadeOAPowyEKTpsJvFfuWnUg.value
    elif jlikCRVadeOAPowyEKTpsJvFfuWnUg.name=='ak_bmsc':
     jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['ak_bmsc']=jlikCRVadeOAPowyEKTpsJvFfuWnUg.value
   jlikCRVadeOAPowyEKTpsJvFfuWnUx=jlikCRVadeOAPowyEKTpsJvFfuWnHx.make_CP_DefaultCookies()
   jlikCRVadeOAPowyEKTpsJvFfuWnUG=jlikCRVadeOAPowyEKTpsJvFfuWnHx.callRequestCookies('Get',jlikCRVadeOAPowyEKTpsJvFfuWnUc,payload=jlikCRVadeOAPowyEKTpsJvFfuWncY,params=jlikCRVadeOAPowyEKTpsJvFfuWncY,headers=jlikCRVadeOAPowyEKTpsJvFfuWncY,cookies=jlikCRVadeOAPowyEKTpsJvFfuWnUx,redirects=jlikCRVadeOAPowyEKTpsJvFfuWncq)
   if jlikCRVadeOAPowyEKTpsJvFfuWnUG.status_code not in[200]:return jlikCRVadeOAPowyEKTpsJvFfuWncq
   jlikCRVadeOAPowyEKTpsJvFfuWnUb=re.findall('NREUM.loader_config=\{[\w\d\":,-]+\}',jlikCRVadeOAPowyEKTpsJvFfuWnUG.text)[0].split('=')[1]
   jlikCRVadeOAPowyEKTpsJvFfuWnUb=jlikCRVadeOAPowyEKTpsJvFfuWnUb.replace('{','{"').replace(':','":').replace(',',',"')
   jlikCRVadeOAPowyEKTpsJvFfuWnUb=json.loads(jlikCRVadeOAPowyEKTpsJvFfuWnUb)
   jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['NREUM']={'ac':jlikCRVadeOAPowyEKTpsJvFfuWnUb['accountID'],'tk':jlikCRVadeOAPowyEKTpsJvFfuWnUb['trustKey'],'ap':jlikCRVadeOAPowyEKTpsJvFfuWnUb['agentID'],'lk':jlikCRVadeOAPowyEKTpsJvFfuWnUb['licenseKey'],}
   jlikCRVadeOAPowyEKTpsJvFfuWnch('---')
   for jlikCRVadeOAPowyEKTpsJvFfuWnUg in jlikCRVadeOAPowyEKTpsJvFfuWnUG.cookies:
    jlikCRVadeOAPowyEKTpsJvFfuWnch(jlikCRVadeOAPowyEKTpsJvFfuWnUg.name,jlikCRVadeOAPowyEKTpsJvFfuWnUg.value) 
    if jlikCRVadeOAPowyEKTpsJvFfuWnUg.name=='bm_mi':
     jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['bm_mi']=jlikCRVadeOAPowyEKTpsJvFfuWnUg.value
    elif jlikCRVadeOAPowyEKTpsJvFfuWnUg.name=='bm_sv':
     jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['bm_sv'] =jlikCRVadeOAPowyEKTpsJvFfuWnUg.value
     jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['bm_sv_ex']=jlikCRVadeOAPowyEKTpsJvFfuWnUg.expires 
    elif jlikCRVadeOAPowyEKTpsJvFfuWnUg.name=='session_web_id':
     jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['session_web_id']=jlikCRVadeOAPowyEKTpsJvFfuWnUg.value
  except jlikCRVadeOAPowyEKTpsJvFfuWncM as exception:
   jlikCRVadeOAPowyEKTpsJvFfuWnch(exception)
   return jlikCRVadeOAPowyEKTpsJvFfuWncq
  try:
   jlikCRVadeOAPowyEKTpsJvFfuWnUc=jlikCRVadeOAPowyEKTpsJvFfuWnHx.API_DOMAIN+'/api/auth'
   jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['PCID']=jlikCRVadeOAPowyEKTpsJvFfuWnHx.generatePcId()
   jlikCRVadeOAPowyEKTpsJvFfuWnUt=jlikCRVadeOAPowyEKTpsJvFfuWnHx.Get_DeviceID()
   jlikCRVadeOAPowyEKTpsJvFfuWnUr =jlikCRVadeOAPowyEKTpsJvFfuWnUt.split('-')[0]
   jlikCRVadeOAPowyEKTpsJvFfuWnHM,jlikCRVadeOAPowyEKTpsJvFfuWnHD,jlikCRVadeOAPowyEKTpsJvFfuWnHB=jlikCRVadeOAPowyEKTpsJvFfuWnHx.Make_authHeader()
   jlikCRVadeOAPowyEKTpsJvFfuWnUX={'traceparent':jlikCRVadeOAPowyEKTpsJvFfuWnHM,'tracestate':jlikCRVadeOAPowyEKTpsJvFfuWnHD,'newrelic':jlikCRVadeOAPowyEKTpsJvFfuWnHB,'content-type':'application/json','x-app-version':'1.26.1','x-device-id':'','x-device-os-version':jlikCRVadeOAPowyEKTpsJvFfuWnHx.OS_VERSION,'x-nr-session-id':jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['session_web_id'],'x-pcid':'',}
   jlikCRVadeOAPowyEKTpsJvFfuWnUz={'device':{'deviceId':'web-'+jlikCRVadeOAPowyEKTpsJvFfuWnUt,'model':jlikCRVadeOAPowyEKTpsJvFfuWnHx.MODEL,'name':'Edge Desktop '+jlikCRVadeOAPowyEKTpsJvFfuWnUr,'os':'Windows','osVersion':'10','type':'webclient',},'email':userid,'password':userpw,}
   jlikCRVadeOAPowyEKTpsJvFfuWnUz=json.dumps(jlikCRVadeOAPowyEKTpsJvFfuWnUz,separators=(',',':'))
   jlikCRVadeOAPowyEKTpsJvFfuWnUx=jlikCRVadeOAPowyEKTpsJvFfuWnHx.make_CP_DefaultCookies()
   jlikCRVadeOAPowyEKTpsJvFfuWnUG=jlikCRVadeOAPowyEKTpsJvFfuWnHx.callRequestCookies('Post',jlikCRVadeOAPowyEKTpsJvFfuWnUc,payload=jlikCRVadeOAPowyEKTpsJvFfuWnUz,params=jlikCRVadeOAPowyEKTpsJvFfuWncY,headers=jlikCRVadeOAPowyEKTpsJvFfuWnUX,cookies=jlikCRVadeOAPowyEKTpsJvFfuWnUx,redirects=jlikCRVadeOAPowyEKTpsJvFfuWncq)
   if jlikCRVadeOAPowyEKTpsJvFfuWnUG.status_code not in[200]:
    jlikCRVadeOAPowyEKTpsJvFfuWnUN=json.loads(jlikCRVadeOAPowyEKTpsJvFfuWnUG.text)
    if 'error' in jlikCRVadeOAPowyEKTpsJvFfuWnUN:
     jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['error']=jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('error').get('detail')
    return jlikCRVadeOAPowyEKTpsJvFfuWncq
   jlikCRVadeOAPowyEKTpsJvFfuWnch('---')
   for jlikCRVadeOAPowyEKTpsJvFfuWnUg in jlikCRVadeOAPowyEKTpsJvFfuWnUG.cookies:
    jlikCRVadeOAPowyEKTpsJvFfuWnch(jlikCRVadeOAPowyEKTpsJvFfuWnUg.name,jlikCRVadeOAPowyEKTpsJvFfuWnUg.value) 
    if jlikCRVadeOAPowyEKTpsJvFfuWnUg.name=='token':
     jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['token']=jlikCRVadeOAPowyEKTpsJvFfuWnUg.value
    elif jlikCRVadeOAPowyEKTpsJvFfuWnUg.name=='member_srl':
     jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['member_srl']=jlikCRVadeOAPowyEKTpsJvFfuWnUg.value
    elif jlikCRVadeOAPowyEKTpsJvFfuWnUg.name=='bm_sv':
     jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['bm_sv'] =jlikCRVadeOAPowyEKTpsJvFfuWnUg.value
     jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['bm_sv_ex']=jlikCRVadeOAPowyEKTpsJvFfuWnUg.expires 
    elif jlikCRVadeOAPowyEKTpsJvFfuWnUg.name=='device_id':
     jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['device_id']=jlikCRVadeOAPowyEKTpsJvFfuWnUg.value
  except jlikCRVadeOAPowyEKTpsJvFfuWncM as exception:
   jlikCRVadeOAPowyEKTpsJvFfuWnch(exception)
   return jlikCRVadeOAPowyEKTpsJvFfuWncq
  jlikCRVadeOAPowyEKTpsJvFfuWnHx.Save_session_acount(userid,userpw,jlikCRVadeOAPowyEKTpsJvFfuWnUq)
  return jlikCRVadeOAPowyEKTpsJvFfuWncB
 def Get_CP_profile(jlikCRVadeOAPowyEKTpsJvFfuWnHx,jlikCRVadeOAPowyEKTpsJvFfuWnUq,limit_days=1,re_check=jlikCRVadeOAPowyEKTpsJvFfuWncq):
  if re_check==jlikCRVadeOAPowyEKTpsJvFfuWncB:
   if jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['bm_sv_ex']>jlikCRVadeOAPowyEKTpsJvFfuWncQ(time.time()):
    jlikCRVadeOAPowyEKTpsJvFfuWnch('bm_sv_ex ok')
    return jlikCRVadeOAPowyEKTpsJvFfuWncB
  try:
   jlikCRVadeOAPowyEKTpsJvFfuWnUc=jlikCRVadeOAPowyEKTpsJvFfuWnHx.API_DOMAIN+'/api/profiles'
   jlikCRVadeOAPowyEKTpsJvFfuWnHM,jlikCRVadeOAPowyEKTpsJvFfuWnHD,jlikCRVadeOAPowyEKTpsJvFfuWnHB=jlikCRVadeOAPowyEKTpsJvFfuWnHx.Make_authHeader()
   jlikCRVadeOAPowyEKTpsJvFfuWnUX={'traceparent':jlikCRVadeOAPowyEKTpsJvFfuWnHM,'tracestate':jlikCRVadeOAPowyEKTpsJvFfuWnHD,'newrelic':jlikCRVadeOAPowyEKTpsJvFfuWnHB,'x-app-version':'1.26.1','x-device-id':'','x-device-os-version':jlikCRVadeOAPowyEKTpsJvFfuWnHx.OS_VERSION,'x-nr-session-id':jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['session_web_id'],'x-pcid':'',}
   jlikCRVadeOAPowyEKTpsJvFfuWnUx=jlikCRVadeOAPowyEKTpsJvFfuWnHx.make_CP_DefaultCookies()
   jlikCRVadeOAPowyEKTpsJvFfuWnUG=jlikCRVadeOAPowyEKTpsJvFfuWnHx.callRequestCookies('Get',jlikCRVadeOAPowyEKTpsJvFfuWnUc,payload=jlikCRVadeOAPowyEKTpsJvFfuWncY,params=jlikCRVadeOAPowyEKTpsJvFfuWncY,headers=jlikCRVadeOAPowyEKTpsJvFfuWnUX,cookies=jlikCRVadeOAPowyEKTpsJvFfuWnUx,redirects=jlikCRVadeOAPowyEKTpsJvFfuWncq)
   if jlikCRVadeOAPowyEKTpsJvFfuWnUG.status_code not in[200]:return jlikCRVadeOAPowyEKTpsJvFfuWncq
   jlikCRVadeOAPowyEKTpsJvFfuWnUN=json.loads(jlikCRVadeOAPowyEKTpsJvFfuWnUG.text)
   jlikCRVadeOAPowyEKTpsJvFfuWnUY=0 
   for jlikCRVadeOAPowyEKTpsJvFfuWnUg in jlikCRVadeOAPowyEKTpsJvFfuWnUG.cookies:
    jlikCRVadeOAPowyEKTpsJvFfuWnch(jlikCRVadeOAPowyEKTpsJvFfuWnUg.name)
    if jlikCRVadeOAPowyEKTpsJvFfuWnUg.name=='bm_sv':
     jlikCRVadeOAPowyEKTpsJvFfuWnUY=1
     jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['bm_sv'] =jlikCRVadeOAPowyEKTpsJvFfuWnUg.value
     jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['bm_sv_ex']=jlikCRVadeOAPowyEKTpsJvFfuWnUg.expires 
   if jlikCRVadeOAPowyEKTpsJvFfuWnUY==0:
    jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['bm_sv_ex']=jlikCRVadeOAPowyEKTpsJvFfuWncQ(time.time())+60*60*2 
   jlikCRVadeOAPowyEKTpsJvFfuWnUq=jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('data')[jlikCRVadeOAPowyEKTpsJvFfuWncQ(jlikCRVadeOAPowyEKTpsJvFfuWnUq)]
   jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['accountId']=jlikCRVadeOAPowyEKTpsJvFfuWnUq.get('accountId')
   jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['profileId']=jlikCRVadeOAPowyEKTpsJvFfuWnUq.get('profileId')
  except jlikCRVadeOAPowyEKTpsJvFfuWncM as exception:
   jlikCRVadeOAPowyEKTpsJvFfuWnch(exception)
   return jlikCRVadeOAPowyEKTpsJvFfuWncq
  if re_check==jlikCRVadeOAPowyEKTpsJvFfuWncq:
   jlikCRVadeOAPowyEKTpsJvFfuWnUh =jlikCRVadeOAPowyEKTpsJvFfuWnHx.Get_Now_Datetime()
   jlikCRVadeOAPowyEKTpsJvFfuWnUS=jlikCRVadeOAPowyEKTpsJvFfuWnUh+datetime.timedelta(days=limit_days)
   jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['limitdate']=jlikCRVadeOAPowyEKTpsJvFfuWnUS.strftime('%Y-%m-%d')
  else:
   jlikCRVadeOAPowyEKTpsJvFfuWnch('re check')
  jlikCRVadeOAPowyEKTpsJvFfuWnHx.dic_To_jsonfile(jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP_COOKIE_FILENAME,jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP)
  return jlikCRVadeOAPowyEKTpsJvFfuWncB
 def Get_Category_GroupList(jlikCRVadeOAPowyEKTpsJvFfuWnHx,vType):
  jlikCRVadeOAPowyEKTpsJvFfuWnUm=[] 
  try:
   jlikCRVadeOAPowyEKTpsJvFfuWnUc=jlikCRVadeOAPowyEKTpsJvFfuWnHx.API_VIEWURL+'/v2/discover/feed' 
   jlikCRVadeOAPowyEKTpsJvFfuWnUQ={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false',}
   jlikCRVadeOAPowyEKTpsJvFfuWnUG=jlikCRVadeOAPowyEKTpsJvFfuWnHx.callRequestCookies('Get',jlikCRVadeOAPowyEKTpsJvFfuWnUc,payload=jlikCRVadeOAPowyEKTpsJvFfuWncY,params=jlikCRVadeOAPowyEKTpsJvFfuWnUQ,headers=jlikCRVadeOAPowyEKTpsJvFfuWncY,cookies=jlikCRVadeOAPowyEKTpsJvFfuWncY,redirects=jlikCRVadeOAPowyEKTpsJvFfuWncB)
   if jlikCRVadeOAPowyEKTpsJvFfuWnUG.status_code not in[200]:return[]
   jlikCRVadeOAPowyEKTpsJvFfuWnUN=json.loads(jlikCRVadeOAPowyEKTpsJvFfuWnUG.text)
   if vType in['TVSHOWS','MOVIES']:
    jlikCRVadeOAPowyEKTpsJvFfuWnUM='Explores' 
   elif vType in['EDUCATION']:
    jlikCRVadeOAPowyEKTpsJvFfuWnUM='Collection-Rails-Curation'
   elif vType in['ALL','KIDS']:
    jlikCRVadeOAPowyEKTpsJvFfuWnUM='Explores-Categories'
   for jlikCRVadeOAPowyEKTpsJvFfuWnUD in jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('data'):
    if jlikCRVadeOAPowyEKTpsJvFfuWnUD.get('type')==jlikCRVadeOAPowyEKTpsJvFfuWnUM:
     for jlikCRVadeOAPowyEKTpsJvFfuWnUB in jlikCRVadeOAPowyEKTpsJvFfuWnUD.get('data'):
      if vType in['TVSHOWS','MOVIES']:
       jlikCRVadeOAPowyEKTpsJvFfuWnUI=jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('collectionId')
      elif vType in['EDUCATION','ALL','KIDS']:
       jlikCRVadeOAPowyEKTpsJvFfuWnUI=jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('id')
      jlikCRVadeOAPowyEKTpsJvFfuWnUL={'collectionId':jlikCRVadeOAPowyEKTpsJvFfuWnUI,'title':jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('name'),'category':jlikCRVadeOAPowyEKTpsJvFfuWnUD.get('category'),'pre_title':'',}
      jlikCRVadeOAPowyEKTpsJvFfuWnUm.append(jlikCRVadeOAPowyEKTpsJvFfuWnUL)
     break
  except jlikCRVadeOAPowyEKTpsJvFfuWncM as exception:
   jlikCRVadeOAPowyEKTpsJvFfuWnch(exception)
   return[]
  return jlikCRVadeOAPowyEKTpsJvFfuWnUm
 def Get_Category_List(jlikCRVadeOAPowyEKTpsJvFfuWnHx,vType,jlikCRVadeOAPowyEKTpsJvFfuWnUI,page_int):
  jlikCRVadeOAPowyEKTpsJvFfuWnUm=[] 
  jlikCRVadeOAPowyEKTpsJvFfuWnxH=jlikCRVadeOAPowyEKTpsJvFfuWncq
  try:
   if vType in['ALL','KIDS']:
    jlikCRVadeOAPowyEKTpsJvFfuWnUX={'x-membersrl':jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['member_srl'],'x-pcid':jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['PCID'],'x-profileid':jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['profileId'],}
    jlikCRVadeOAPowyEKTpsJvFfuWnUQ={'platform':'WEBCLIENT','page':jlikCRVadeOAPowyEKTpsJvFfuWncS(page_int),'perPage':jlikCRVadeOAPowyEKTpsJvFfuWncS(jlikCRVadeOAPowyEKTpsJvFfuWnHx.PAGE_LIMIT),'locale':'ko','sort':'',}
    jlikCRVadeOAPowyEKTpsJvFfuWnUc=jlikCRVadeOAPowyEKTpsJvFfuWnHx.API_VIEWURL+'/v1/discover/categories/'+jlikCRVadeOAPowyEKTpsJvFfuWnUI+'/titles'
    jlikCRVadeOAPowyEKTpsJvFfuWnUG=jlikCRVadeOAPowyEKTpsJvFfuWnHx.callRequestCookies('Get',jlikCRVadeOAPowyEKTpsJvFfuWnUc,payload=jlikCRVadeOAPowyEKTpsJvFfuWncY,params=jlikCRVadeOAPowyEKTpsJvFfuWnUQ,headers=jlikCRVadeOAPowyEKTpsJvFfuWnUX,cookies=jlikCRVadeOAPowyEKTpsJvFfuWncY,redirects=jlikCRVadeOAPowyEKTpsJvFfuWncB)
   else: 
    jlikCRVadeOAPowyEKTpsJvFfuWnUQ={'platform':'WEBCLIENT','page':jlikCRVadeOAPowyEKTpsJvFfuWncS(page_int),'perPage':jlikCRVadeOAPowyEKTpsJvFfuWncS(jlikCRVadeOAPowyEKTpsJvFfuWnHx.PAGE_LIMIT),}
    jlikCRVadeOAPowyEKTpsJvFfuWnUc=jlikCRVadeOAPowyEKTpsJvFfuWnHx.API_VIEWURL+'/v1/discover/collections/'+jlikCRVadeOAPowyEKTpsJvFfuWnUI+'/titles'
    jlikCRVadeOAPowyEKTpsJvFfuWnUG=jlikCRVadeOAPowyEKTpsJvFfuWnHx.callRequestCookies('Get',jlikCRVadeOAPowyEKTpsJvFfuWnUc,payload=jlikCRVadeOAPowyEKTpsJvFfuWncY,params=jlikCRVadeOAPowyEKTpsJvFfuWnUQ,headers=jlikCRVadeOAPowyEKTpsJvFfuWncY,cookies=jlikCRVadeOAPowyEKTpsJvFfuWncY,redirects=jlikCRVadeOAPowyEKTpsJvFfuWncB)
   if jlikCRVadeOAPowyEKTpsJvFfuWnUG.status_code not in[200]:return[],jlikCRVadeOAPowyEKTpsJvFfuWncq
   jlikCRVadeOAPowyEKTpsJvFfuWnUN=json.loads(jlikCRVadeOAPowyEKTpsJvFfuWnUG.text)
   if vType in['ALL','KIDS']:
    jlikCRVadeOAPowyEKTpsJvFfuWnxU=jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('data').get('data')
   else:
    jlikCRVadeOAPowyEKTpsJvFfuWnxU=jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('data')
   for jlikCRVadeOAPowyEKTpsJvFfuWnUB in jlikCRVadeOAPowyEKTpsJvFfuWnxU:
    jlikCRVadeOAPowyEKTpsJvFfuWnxc=jlikCRVadeOAPowyEKTpsJvFfuWnxt=jlikCRVadeOAPowyEKTpsJvFfuWncb=jlikCRVadeOAPowyEKTpsJvFfuWncg=''
    if 'poster' in jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('images'):jlikCRVadeOAPowyEKTpsJvFfuWnxc =jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('images'):jlikCRVadeOAPowyEKTpsJvFfuWnxt =jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('images').get('story-art').get('url') +'?imwidth=600'
    if 'title-treatment' in jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('images'):jlikCRVadeOAPowyEKTpsJvFfuWncb=jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('images').get('title-treatment').get('url')+'?imwidth=300'
    if 'story-art' in jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('images'):jlikCRVadeOAPowyEKTpsJvFfuWncg =jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('images').get('story-art').get('url') +'?imwidth=600'
    jlikCRVadeOAPowyEKTpsJvFfuWnxX=''
    if jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('badge')not in[{},jlikCRVadeOAPowyEKTpsJvFfuWncY]:
     for i in jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('badge').get('text'):
      jlikCRVadeOAPowyEKTpsJvFfuWnxX+=i.get('text')
    jlikCRVadeOAPowyEKTpsJvFfuWnxG=''
    if jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('seasonList')!=jlikCRVadeOAPowyEKTpsJvFfuWncY:
     jlikCRVadeOAPowyEKTpsJvFfuWnxG=','.join(jlikCRVadeOAPowyEKTpsJvFfuWncS(e)for e in jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('seasonList'))
    jlikCRVadeOAPowyEKTpsJvFfuWnxg =[]
    for jlikCRVadeOAPowyEKTpsJvFfuWnxb in jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('tags'):
     jlikCRVadeOAPowyEKTpsJvFfuWnxg.append(jlikCRVadeOAPowyEKTpsJvFfuWnxb.get('tag'))
    jlikCRVadeOAPowyEKTpsJvFfuWnUL={'id':jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('id'),'title':jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('title'),'thumbnail':{'poster':jlikCRVadeOAPowyEKTpsJvFfuWnxc,'thumb':jlikCRVadeOAPowyEKTpsJvFfuWnxt,'clearlogo':jlikCRVadeOAPowyEKTpsJvFfuWncb,'fanart':jlikCRVadeOAPowyEKTpsJvFfuWncg},'mpaa':jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('age_rating'),'duration':jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('running_time'),'asis':jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('as'),'badge':jlikCRVadeOAPowyEKTpsJvFfuWnxX,'year':jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('meta').get('releaseYear'),'seasonList':jlikCRVadeOAPowyEKTpsJvFfuWnxG,'genreList':jlikCRVadeOAPowyEKTpsJvFfuWnxg,}
    jlikCRVadeOAPowyEKTpsJvFfuWnUm.append(jlikCRVadeOAPowyEKTpsJvFfuWnUL)
   if jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('pagination').get('totalPages')>page_int:
    jlikCRVadeOAPowyEKTpsJvFfuWnxH=jlikCRVadeOAPowyEKTpsJvFfuWncB
  except jlikCRVadeOAPowyEKTpsJvFfuWncM as exception:
   jlikCRVadeOAPowyEKTpsJvFfuWnch(exception)
   return[],jlikCRVadeOAPowyEKTpsJvFfuWncq
  return jlikCRVadeOAPowyEKTpsJvFfuWnUm,jlikCRVadeOAPowyEKTpsJvFfuWnxH
 def Get_Episode_List(jlikCRVadeOAPowyEKTpsJvFfuWnHx,programId,season):
  jlikCRVadeOAPowyEKTpsJvFfuWnUm=[] 
  try:
   jlikCRVadeOAPowyEKTpsJvFfuWnUc=jlikCRVadeOAPowyEKTpsJvFfuWnHx.API_VIEWURL+'/v1/discover/titles/'+programId+'/episodes'
   jlikCRVadeOAPowyEKTpsJvFfuWnUQ={'season':season,'sort':'true','locale':'ko',}
   jlikCRVadeOAPowyEKTpsJvFfuWnUG=jlikCRVadeOAPowyEKTpsJvFfuWnHx.callRequestCookies('Get',jlikCRVadeOAPowyEKTpsJvFfuWnUc,payload=jlikCRVadeOAPowyEKTpsJvFfuWncY,params=jlikCRVadeOAPowyEKTpsJvFfuWnUQ,headers=jlikCRVadeOAPowyEKTpsJvFfuWncY,cookies=jlikCRVadeOAPowyEKTpsJvFfuWncY,redirects=jlikCRVadeOAPowyEKTpsJvFfuWncB)
   if jlikCRVadeOAPowyEKTpsJvFfuWnUG.status_code not in[200]:return[]
   jlikCRVadeOAPowyEKTpsJvFfuWnUN=json.loads(jlikCRVadeOAPowyEKTpsJvFfuWnUG.text)
   for jlikCRVadeOAPowyEKTpsJvFfuWnUB in jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('data'):
    jlikCRVadeOAPowyEKTpsJvFfuWnxt=''
    if 'story-art' in jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('images'):jlikCRVadeOAPowyEKTpsJvFfuWnxt =jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('images').get('story-art').get('url')+'?imwidth=600'
    jlikCRVadeOAPowyEKTpsJvFfuWnxg =[]
    for jlikCRVadeOAPowyEKTpsJvFfuWnxb in jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('tags'):
     jlikCRVadeOAPowyEKTpsJvFfuWnxg.append(jlikCRVadeOAPowyEKTpsJvFfuWnxb.get('tag'))
    jlikCRVadeOAPowyEKTpsJvFfuWnUL={'id':jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('id'),'title':jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('title'),'thumbnail':{'thumb':jlikCRVadeOAPowyEKTpsJvFfuWnxt,'fanart':jlikCRVadeOAPowyEKTpsJvFfuWnxt},'mpaa':jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('age_rating'),'duration':jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('running_time'),'asis':jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('as'),'year':jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('meta').get('releaseYear'),'episode':jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('episode'),'genreList':jlikCRVadeOAPowyEKTpsJvFfuWnxg,'desc':jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('description'),}
    jlikCRVadeOAPowyEKTpsJvFfuWnUm.append(jlikCRVadeOAPowyEKTpsJvFfuWnUL)
  except jlikCRVadeOAPowyEKTpsJvFfuWncM as exception:
   jlikCRVadeOAPowyEKTpsJvFfuWnch(exception)
   return[]
  return jlikCRVadeOAPowyEKTpsJvFfuWnUm
 def Get_vInfo(jlikCRVadeOAPowyEKTpsJvFfuWnHx,titleId):
  try:
   jlikCRVadeOAPowyEKTpsJvFfuWnUc=jlikCRVadeOAPowyEKTpsJvFfuWnHx.API_VIEWURL+'/v1/discover/titles/'+titleId 
   jlikCRVadeOAPowyEKTpsJvFfuWnUQ={'platform':'WEBCLIENT','locale':'ko','filterRestrictedContent':'false',}
   jlikCRVadeOAPowyEKTpsJvFfuWnUG=jlikCRVadeOAPowyEKTpsJvFfuWnHx.callRequestCookies('Get',jlikCRVadeOAPowyEKTpsJvFfuWnUc,payload=jlikCRVadeOAPowyEKTpsJvFfuWncY,params=jlikCRVadeOAPowyEKTpsJvFfuWnUQ,headers=jlikCRVadeOAPowyEKTpsJvFfuWncY,cookies=jlikCRVadeOAPowyEKTpsJvFfuWncY,redirects=jlikCRVadeOAPowyEKTpsJvFfuWncB)
   if jlikCRVadeOAPowyEKTpsJvFfuWnUG.status_code not in[200]:return '','',''
   jlikCRVadeOAPowyEKTpsJvFfuWnUN=json.loads(jlikCRVadeOAPowyEKTpsJvFfuWnUG.text).get('data')
   jlikCRVadeOAPowyEKTpsJvFfuWnxG=''
   if jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('seasonList')!=jlikCRVadeOAPowyEKTpsJvFfuWncY:
    jlikCRVadeOAPowyEKTpsJvFfuWnxG=','.join(jlikCRVadeOAPowyEKTpsJvFfuWncS(e)for e in jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('seasonList'))
   jlikCRVadeOAPowyEKTpsJvFfuWnxr={'age_rating':jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('age_rating'),'asset_id':jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('asset_id'),'availability':jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('availability'),'deal_id':jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('deal_id'),'downloadable':'true' if jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('downloadable')else 'false','region':jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('region'),'streamable':'true' if jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('streamable')else 'false','asis':jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('as'),'seasonList':jlikCRVadeOAPowyEKTpsJvFfuWnxG}
  except jlikCRVadeOAPowyEKTpsJvFfuWncM as exception:
   jlikCRVadeOAPowyEKTpsJvFfuWnch(exception)
   return{}
  return jlikCRVadeOAPowyEKTpsJvFfuWnxr
 def Get_eInfo(jlikCRVadeOAPowyEKTpsJvFfuWnHx,eventId):
  try:
   jlikCRVadeOAPowyEKTpsJvFfuWnUc=jlikCRVadeOAPowyEKTpsJvFfuWnHx.API_VIEWURL+'/v1/discover/events/'+eventId 
   jlikCRVadeOAPowyEKTpsJvFfuWnUQ={'locale':'ko'}
   jlikCRVadeOAPowyEKTpsJvFfuWnUG=jlikCRVadeOAPowyEKTpsJvFfuWnHx.callRequestCookies('Get',jlikCRVadeOAPowyEKTpsJvFfuWnUc,payload=jlikCRVadeOAPowyEKTpsJvFfuWncY,params=jlikCRVadeOAPowyEKTpsJvFfuWnUQ,headers=jlikCRVadeOAPowyEKTpsJvFfuWncY,cookies=jlikCRVadeOAPowyEKTpsJvFfuWncY,redirects=jlikCRVadeOAPowyEKTpsJvFfuWncB)
   if jlikCRVadeOAPowyEKTpsJvFfuWnUG.status_code not in[200]:return '','',''
   jlikCRVadeOAPowyEKTpsJvFfuWnUN=json.loads(jlikCRVadeOAPowyEKTpsJvFfuWnUG.text).get('data')
   jlikCRVadeOAPowyEKTpsJvFfuWnxr={'asset_id':jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('asset_id'),'deal_id':jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('deal_id'),'region':jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('region'),'streamable':'true' if jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('streamable')else 'false',}
  except jlikCRVadeOAPowyEKTpsJvFfuWncM as exception:
   jlikCRVadeOAPowyEKTpsJvFfuWnch(exception)
   return{}
  return jlikCRVadeOAPowyEKTpsJvFfuWnxr
 def GetBroadURL(jlikCRVadeOAPowyEKTpsJvFfuWnHx,titleId):
  jlikCRVadeOAPowyEKTpsJvFfuWnxz=''
  jlikCRVadeOAPowyEKTpsJvFfuWnxN =''
  jlikCRVadeOAPowyEKTpsJvFfuWnxr=jlikCRVadeOAPowyEKTpsJvFfuWnHx.Get_vInfo(titleId)
  if jlikCRVadeOAPowyEKTpsJvFfuWnxr=={}:return '',''
  try:
   jlikCRVadeOAPowyEKTpsJvFfuWnUc=jlikCRVadeOAPowyEKTpsJvFfuWnHx.API_DOMAIN+'/api/playback/play' 
   jlikCRVadeOAPowyEKTpsJvFfuWnUQ={'titleId':titleId}
   jlikCRVadeOAPowyEKTpsJvFfuWnHM,jlikCRVadeOAPowyEKTpsJvFfuWnHD,jlikCRVadeOAPowyEKTpsJvFfuWnHB=jlikCRVadeOAPowyEKTpsJvFfuWnHx.Make_authHeader()
   jlikCRVadeOAPowyEKTpsJvFfuWnUX={'traceparent':jlikCRVadeOAPowyEKTpsJvFfuWnHM,'tracestate':jlikCRVadeOAPowyEKTpsJvFfuWnHD,'newrelic':jlikCRVadeOAPowyEKTpsJvFfuWnHB,'x-drm':'com.microsoft.playready','x-app-version':'1.33.5','x-device-id':'','x-device-os-version':jlikCRVadeOAPowyEKTpsJvFfuWnHx.OS_VERSION,'x-force-raw':'true','x-nr-session-id':jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['session_web_id'],'x-pcid':jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['profileId'],'x-profileType':'standard','x-sessionid':jlikCRVadeOAPowyEKTpsJvFfuWnHx.generatePvId(genType='1'),'x-title-age-rating':jlikCRVadeOAPowyEKTpsJvFfuWnxr.get('age_rating'),'x-title-availability':jlikCRVadeOAPowyEKTpsJvFfuWnxr.get('availability'),'x-title-brightcove-id':jlikCRVadeOAPowyEKTpsJvFfuWnxr.get('asset_id'),'x-title-deal-id':jlikCRVadeOAPowyEKTpsJvFfuWnxr.get('deal_id'),'x-title-downloadable':jlikCRVadeOAPowyEKTpsJvFfuWnxr.get('downloadable'),'x-title-region':jlikCRVadeOAPowyEKTpsJvFfuWnxr.get('region'),'x-title-streamable':jlikCRVadeOAPowyEKTpsJvFfuWnxr.get('streamable'),}
   jlikCRVadeOAPowyEKTpsJvFfuWnUx=jlikCRVadeOAPowyEKTpsJvFfuWnHx.make_CP_DefaultCookies()
   jlikCRVadeOAPowyEKTpsJvFfuWnUG=jlikCRVadeOAPowyEKTpsJvFfuWnHx.callRequestCookies('Get',jlikCRVadeOAPowyEKTpsJvFfuWnUc,payload=jlikCRVadeOAPowyEKTpsJvFfuWncY,params=jlikCRVadeOAPowyEKTpsJvFfuWnUQ,headers=jlikCRVadeOAPowyEKTpsJvFfuWnUX,cookies=jlikCRVadeOAPowyEKTpsJvFfuWnUx,redirects=jlikCRVadeOAPowyEKTpsJvFfuWncB)
   if jlikCRVadeOAPowyEKTpsJvFfuWnUG.status_code not in[200]:return '',json.loads(jlikCRVadeOAPowyEKTpsJvFfuWnUG.text).get('error').get('detail')
   jlikCRVadeOAPowyEKTpsJvFfuWnUN=json.loads(jlikCRVadeOAPowyEKTpsJvFfuWnUG.text)
   if jlikCRVadeOAPowyEKTpsJvFfuWnxz=='':
    for jlikCRVadeOAPowyEKTpsJvFfuWnUB in jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('data').get('raw').get('sources'):
     if 'key_systems' in jlikCRVadeOAPowyEKTpsJvFfuWnUB and 'codecs' not in jlikCRVadeOAPowyEKTpsJvFfuWnUB:
      if jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('type')=='application/dash+xml' and 'com.widevine.alpha' in jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('key_systems')and jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('src').startswith('https://')==jlikCRVadeOAPowyEKTpsJvFfuWncB:
       jlikCRVadeOAPowyEKTpsJvFfuWnxz=jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('src')
       jlikCRVadeOAPowyEKTpsJvFfuWnxN =jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if jlikCRVadeOAPowyEKTpsJvFfuWnxz=='':
    for jlikCRVadeOAPowyEKTpsJvFfuWnUB in jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('data').get('raw').get('sources'):
     if 'key_systems' in jlikCRVadeOAPowyEKTpsJvFfuWnUB and 'codecs' not in jlikCRVadeOAPowyEKTpsJvFfuWnUB:
      if jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('key_systems')and jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('src').startswith('https://')==jlikCRVadeOAPowyEKTpsJvFfuWncB:
       jlikCRVadeOAPowyEKTpsJvFfuWnxz=jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('src')
       jlikCRVadeOAPowyEKTpsJvFfuWnxN =jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if jlikCRVadeOAPowyEKTpsJvFfuWnxz=='':
    for jlikCRVadeOAPowyEKTpsJvFfuWnUB in jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('data').get('raw').get('sources'):
     if 'key_systems' in jlikCRVadeOAPowyEKTpsJvFfuWnUB and 'codecs' in jlikCRVadeOAPowyEKTpsJvFfuWnUB:
      if jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('type')=='application/dash+xml' and 'com.widevine.alpha' in jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('key_systems')and jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('src').startswith('https://')==jlikCRVadeOAPowyEKTpsJvFfuWncB:
       jlikCRVadeOAPowyEKTpsJvFfuWnxz=jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('src')
       jlikCRVadeOAPowyEKTpsJvFfuWnxN =jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if jlikCRVadeOAPowyEKTpsJvFfuWnxz=='':
    for jlikCRVadeOAPowyEKTpsJvFfuWnUB in jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('data').get('raw').get('sources'):
     if 'key_systems' in jlikCRVadeOAPowyEKTpsJvFfuWnUB and 'codecs' in jlikCRVadeOAPowyEKTpsJvFfuWnUB:
      if jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('key_systems')and jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('src').startswith('https://')==jlikCRVadeOAPowyEKTpsJvFfuWncB:
       jlikCRVadeOAPowyEKTpsJvFfuWnxz=jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('src')
       jlikCRVadeOAPowyEKTpsJvFfuWnxN =jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
  except jlikCRVadeOAPowyEKTpsJvFfuWncM as exception:
   jlikCRVadeOAPowyEKTpsJvFfuWnch(exception)
   return '',''
  return jlikCRVadeOAPowyEKTpsJvFfuWnxz,jlikCRVadeOAPowyEKTpsJvFfuWnxN
 def GetEventURL(jlikCRVadeOAPowyEKTpsJvFfuWnHx,eventId,jlikCRVadeOAPowyEKTpsJvFfuWncH):
  jlikCRVadeOAPowyEKTpsJvFfuWnxz=''
  jlikCRVadeOAPowyEKTpsJvFfuWnxN =''
  jlikCRVadeOAPowyEKTpsJvFfuWnxr=jlikCRVadeOAPowyEKTpsJvFfuWnHx.Get_eInfo(eventId)
  if jlikCRVadeOAPowyEKTpsJvFfuWnxr=={}:return '',''
  try:
   jlikCRVadeOAPowyEKTpsJvFfuWnUc=jlikCRVadeOAPowyEKTpsJvFfuWnHx.API_DOMAIN+'/api/playback/play' 
   jlikCRVadeOAPowyEKTpsJvFfuWnUQ={'titleId':eventId,'titleType':jlikCRVadeOAPowyEKTpsJvFfuWncH,}
   jlikCRVadeOAPowyEKTpsJvFfuWnHM,jlikCRVadeOAPowyEKTpsJvFfuWnHD,jlikCRVadeOAPowyEKTpsJvFfuWnHB=jlikCRVadeOAPowyEKTpsJvFfuWnHx.Make_authHeader()
   jlikCRVadeOAPowyEKTpsJvFfuWnUX={'traceparent':jlikCRVadeOAPowyEKTpsJvFfuWnHM,'tracestate':jlikCRVadeOAPowyEKTpsJvFfuWnHD,'newrelic':jlikCRVadeOAPowyEKTpsJvFfuWnHB,'x-force-raw':'true','x-pcid':jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':jlikCRVadeOAPowyEKTpsJvFfuWnxr.get('asset_id'),'x-title-deal-id':jlikCRVadeOAPowyEKTpsJvFfuWnxr.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':jlikCRVadeOAPowyEKTpsJvFfuWnxr.get('region'),'x-title-streamable':jlikCRVadeOAPowyEKTpsJvFfuWnxr.get('streamable'),}
   jlikCRVadeOAPowyEKTpsJvFfuWnUx=jlikCRVadeOAPowyEKTpsJvFfuWnHx.make_CP_DefaultCookies()
   jlikCRVadeOAPowyEKTpsJvFfuWnUG=jlikCRVadeOAPowyEKTpsJvFfuWnHx.callRequestCookies('Get',jlikCRVadeOAPowyEKTpsJvFfuWnUc,payload=jlikCRVadeOAPowyEKTpsJvFfuWncY,params=jlikCRVadeOAPowyEKTpsJvFfuWnUQ,headers=jlikCRVadeOAPowyEKTpsJvFfuWnUX,cookies=jlikCRVadeOAPowyEKTpsJvFfuWnUx,redirects=jlikCRVadeOAPowyEKTpsJvFfuWncB)
   if jlikCRVadeOAPowyEKTpsJvFfuWnUG.status_code not in[200]:return '',json.loads(jlikCRVadeOAPowyEKTpsJvFfuWnUG.text).get('error').get('detail')
   jlikCRVadeOAPowyEKTpsJvFfuWnUN=json.loads(jlikCRVadeOAPowyEKTpsJvFfuWnUG.text)
   for jlikCRVadeOAPowyEKTpsJvFfuWnUB in jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('data').get('raw').get('sources'):
    if jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('type')=='application/dash+xml' and jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('src')[0:8]=='https://':
     jlikCRVadeOAPowyEKTpsJvFfuWnxz=jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('src')
     if 'key_systems' in jlikCRVadeOAPowyEKTpsJvFfuWnUB:
      jlikCRVadeOAPowyEKTpsJvFfuWnxN =jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('key_systems').get('com.widevine.alpha').get('license_url')
     break
  except jlikCRVadeOAPowyEKTpsJvFfuWncM as exception:
   jlikCRVadeOAPowyEKTpsJvFfuWnch(exception)
   return '',''
  return jlikCRVadeOAPowyEKTpsJvFfuWnxz,jlikCRVadeOAPowyEKTpsJvFfuWnxN
 def GetEventURL_Live(jlikCRVadeOAPowyEKTpsJvFfuWnHx,eventId,jlikCRVadeOAPowyEKTpsJvFfuWncH):
  jlikCRVadeOAPowyEKTpsJvFfuWnxz=''
  jlikCRVadeOAPowyEKTpsJvFfuWnxN =''
  jlikCRVadeOAPowyEKTpsJvFfuWnxr=jlikCRVadeOAPowyEKTpsJvFfuWnHx.Get_eInfo(eventId)
  if jlikCRVadeOAPowyEKTpsJvFfuWnxr=={}:return '',''
  try:
   jlikCRVadeOAPowyEKTpsJvFfuWnUc=jlikCRVadeOAPowyEKTpsJvFfuWnHx.API_DOMAIN+'/api/playback/play' 
   jlikCRVadeOAPowyEKTpsJvFfuWnUQ={'titleId':eventId,'titleType':jlikCRVadeOAPowyEKTpsJvFfuWncH,}
   jlikCRVadeOAPowyEKTpsJvFfuWnHM,jlikCRVadeOAPowyEKTpsJvFfuWnHD,jlikCRVadeOAPowyEKTpsJvFfuWnHB=jlikCRVadeOAPowyEKTpsJvFfuWnHx.Make_authHeader()
   jlikCRVadeOAPowyEKTpsJvFfuWnUX={'traceparent':jlikCRVadeOAPowyEKTpsJvFfuWnHM,'tracestate':jlikCRVadeOAPowyEKTpsJvFfuWnHD,'newrelic':jlikCRVadeOAPowyEKTpsJvFfuWnHB,'x-force-raw':'true','x-pcid':jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':jlikCRVadeOAPowyEKTpsJvFfuWnxr.get('asset_id'),'x-title-deal-id':jlikCRVadeOAPowyEKTpsJvFfuWnxr.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':jlikCRVadeOAPowyEKTpsJvFfuWnxr.get('region'),'x-title-streamable':jlikCRVadeOAPowyEKTpsJvFfuWnxr.get('streamable'),}
   jlikCRVadeOAPowyEKTpsJvFfuWnUx=jlikCRVadeOAPowyEKTpsJvFfuWnHx.make_CP_DefaultCookies()
   jlikCRVadeOAPowyEKTpsJvFfuWnUG=jlikCRVadeOAPowyEKTpsJvFfuWnHx.callRequestCookies('Get',jlikCRVadeOAPowyEKTpsJvFfuWnUc,payload=jlikCRVadeOAPowyEKTpsJvFfuWncY,params=jlikCRVadeOAPowyEKTpsJvFfuWnUQ,headers=jlikCRVadeOAPowyEKTpsJvFfuWnUX,cookies=jlikCRVadeOAPowyEKTpsJvFfuWnUx,redirects=jlikCRVadeOAPowyEKTpsJvFfuWncB)
   if jlikCRVadeOAPowyEKTpsJvFfuWnUG.status_code not in[200]:return '',json.loads(jlikCRVadeOAPowyEKTpsJvFfuWnUG.text).get('error').get('detail')
   jlikCRVadeOAPowyEKTpsJvFfuWnUN=json.loads(jlikCRVadeOAPowyEKTpsJvFfuWnUG.text)
   if jlikCRVadeOAPowyEKTpsJvFfuWnxz=='':
    for jlikCRVadeOAPowyEKTpsJvFfuWnUB in jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('data').get('raw').get('sources'):
     if 'key_systems' in jlikCRVadeOAPowyEKTpsJvFfuWnUB:
      if jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('type')=='application/dash+xml' and 'com.widevine.alpha' in jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('key_systems')and jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('src').startswith('https://')==jlikCRVadeOAPowyEKTpsJvFfuWncB:
       jlikCRVadeOAPowyEKTpsJvFfuWnxz=jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('src')
       jlikCRVadeOAPowyEKTpsJvFfuWnxN =jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('key_systems').get('com.widevine.alpha').get('license_url')
   if jlikCRVadeOAPowyEKTpsJvFfuWnxz=='':
    for jlikCRVadeOAPowyEKTpsJvFfuWnUB in jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('data').get('raw').get('sources'):
     if 'key_systems' in jlikCRVadeOAPowyEKTpsJvFfuWnUB:
      if jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('key_systems')and jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('src').startswith('https://')==jlikCRVadeOAPowyEKTpsJvFfuWncB:
       jlikCRVadeOAPowyEKTpsJvFfuWnxz=jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('src')
       jlikCRVadeOAPowyEKTpsJvFfuWnxN =jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('key_systems').get('com.widevine.alpha').get('license_url')
   if jlikCRVadeOAPowyEKTpsJvFfuWnxz=='':
    for jlikCRVadeOAPowyEKTpsJvFfuWnUB in jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('data').get('raw').get('sources'):
     if jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('type')=='application/dash+xml' and jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('src').startswith('https://')==jlikCRVadeOAPowyEKTpsJvFfuWncB:
      jlikCRVadeOAPowyEKTpsJvFfuWnxz=jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('src')
   if jlikCRVadeOAPowyEKTpsJvFfuWnxz=='':
    for jlikCRVadeOAPowyEKTpsJvFfuWnUB in jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('data').get('raw').get('sources'):
     if jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('type')=='application/x-mpegURL' and jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('src').startswith('https://')==jlikCRVadeOAPowyEKTpsJvFfuWncB:
      jlikCRVadeOAPowyEKTpsJvFfuWnxz=jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('src')
  except jlikCRVadeOAPowyEKTpsJvFfuWncM as exception:
   jlikCRVadeOAPowyEKTpsJvFfuWnch(exception)
   return '',''
  return jlikCRVadeOAPowyEKTpsJvFfuWnxz,jlikCRVadeOAPowyEKTpsJvFfuWnxN
 def Get_Url_PostFix(jlikCRVadeOAPowyEKTpsJvFfuWnHx,in_url):
  jlikCRVadeOAPowyEKTpsJvFfuWnxY=urllib.parse.urlparse(in_url) 
  jlikCRVadeOAPowyEKTpsJvFfuWnxq =jlikCRVadeOAPowyEKTpsJvFfuWnxY.path.strip('/').split('/')
  jlikCRVadeOAPowyEKTpsJvFfuWnxh =jlikCRVadeOAPowyEKTpsJvFfuWnxq[jlikCRVadeOAPowyEKTpsJvFfuWncI(jlikCRVadeOAPowyEKTpsJvFfuWnxq)-1]
  jlikCRVadeOAPowyEKTpsJvFfuWnxS=jlikCRVadeOAPowyEKTpsJvFfuWnxh.split('.')
  return jlikCRVadeOAPowyEKTpsJvFfuWnxS[jlikCRVadeOAPowyEKTpsJvFfuWncI(jlikCRVadeOAPowyEKTpsJvFfuWnxS)-1]
 def Get_Theme_GroupList(jlikCRVadeOAPowyEKTpsJvFfuWnHx,vType):
  jlikCRVadeOAPowyEKTpsJvFfuWnUm=[] 
  try:
   jlikCRVadeOAPowyEKTpsJvFfuWnUc=jlikCRVadeOAPowyEKTpsJvFfuWnHx.API_VIEWURL+'/v2/discover/feed' 
   jlikCRVadeOAPowyEKTpsJvFfuWnUQ={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':jlikCRVadeOAPowyEKTpsJvFfuWncS(jlikCRVadeOAPowyEKTpsJvFfuWnHx.PAGE_LIMIT),'filterRestrictedContent':'false',}
   jlikCRVadeOAPowyEKTpsJvFfuWnUG=jlikCRVadeOAPowyEKTpsJvFfuWnHx.callRequestCookies('Get',jlikCRVadeOAPowyEKTpsJvFfuWnUc,payload=jlikCRVadeOAPowyEKTpsJvFfuWncY,params=jlikCRVadeOAPowyEKTpsJvFfuWnUQ,headers=jlikCRVadeOAPowyEKTpsJvFfuWncY,cookies=jlikCRVadeOAPowyEKTpsJvFfuWncY,redirects=jlikCRVadeOAPowyEKTpsJvFfuWncB)
   if jlikCRVadeOAPowyEKTpsJvFfuWnUG.status_code not in[200]:return[]
   jlikCRVadeOAPowyEKTpsJvFfuWnUN=json.loads(jlikCRVadeOAPowyEKTpsJvFfuWnUG.text)
   for jlikCRVadeOAPowyEKTpsJvFfuWnUB in jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('data'):
    if jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('type')=='Title-Rails-Curation':
     jlikCRVadeOAPowyEKTpsJvFfuWnxm =''
     jlikCRVadeOAPowyEKTpsJvFfuWnxQ=7
     try:
      for i in jlikCRVadeOAPowyEKTpsJvFfuWncL(jlikCRVadeOAPowyEKTpsJvFfuWncI(jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('data'))):
       if i>=jlikCRVadeOAPowyEKTpsJvFfuWnxQ:
        jlikCRVadeOAPowyEKTpsJvFfuWnxm=jlikCRVadeOAPowyEKTpsJvFfuWnxm+'...'
        break
       jlikCRVadeOAPowyEKTpsJvFfuWnxm=jlikCRVadeOAPowyEKTpsJvFfuWnxm+jlikCRVadeOAPowyEKTpsJvFfuWnUB['data'][i]['title']+'\n'
     except jlikCRVadeOAPowyEKTpsJvFfuWncM as exception:
      jlikCRVadeOAPowyEKTpsJvFfuWnch(exception)
     jlikCRVadeOAPowyEKTpsJvFfuWnUL={'collectionId':jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('obj_id'),'title':jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('row_name'),'category':jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('category'),'pre_title':jlikCRVadeOAPowyEKTpsJvFfuWnxm,}
     jlikCRVadeOAPowyEKTpsJvFfuWnUm.append(jlikCRVadeOAPowyEKTpsJvFfuWnUL)
  except jlikCRVadeOAPowyEKTpsJvFfuWncM as exception:
   jlikCRVadeOAPowyEKTpsJvFfuWnch(exception)
   return[]
  return jlikCRVadeOAPowyEKTpsJvFfuWnUm
 def Get_Event_GroupList(jlikCRVadeOAPowyEKTpsJvFfuWnHx):
  jlikCRVadeOAPowyEKTpsJvFfuWnUm=[] 
  try:
   jlikCRVadeOAPowyEKTpsJvFfuWnUc=jlikCRVadeOAPowyEKTpsJvFfuWnHx.API_VIEWURL+'/v2/discover/feed' 
   jlikCRVadeOAPowyEKTpsJvFfuWnUQ={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':7,'filterRestrictedContent':'false',}
   jlikCRVadeOAPowyEKTpsJvFfuWnUG=jlikCRVadeOAPowyEKTpsJvFfuWnHx.callRequestCookies('Get',jlikCRVadeOAPowyEKTpsJvFfuWnUc,payload=jlikCRVadeOAPowyEKTpsJvFfuWncY,params=jlikCRVadeOAPowyEKTpsJvFfuWnUQ,headers=jlikCRVadeOAPowyEKTpsJvFfuWncY,cookies=jlikCRVadeOAPowyEKTpsJvFfuWncY,redirects=jlikCRVadeOAPowyEKTpsJvFfuWncB)
   if jlikCRVadeOAPowyEKTpsJvFfuWnUG.status_code not in[200]:return[]
   jlikCRVadeOAPowyEKTpsJvFfuWnUN=json.loads(jlikCRVadeOAPowyEKTpsJvFfuWnUG.text)
   for jlikCRVadeOAPowyEKTpsJvFfuWnUB in jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('data'):
    if jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('row_name').strip()!='':
     jlikCRVadeOAPowyEKTpsJvFfuWnxm =''
     jlikCRVadeOAPowyEKTpsJvFfuWnxQ=7
     try:
      for i in jlikCRVadeOAPowyEKTpsJvFfuWncL(jlikCRVadeOAPowyEKTpsJvFfuWncI(jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('data'))):
       if i>=jlikCRVadeOAPowyEKTpsJvFfuWnxQ:
        jlikCRVadeOAPowyEKTpsJvFfuWnxm=jlikCRVadeOAPowyEKTpsJvFfuWnxm+'...'
        break
       jlikCRVadeOAPowyEKTpsJvFfuWnxm=jlikCRVadeOAPowyEKTpsJvFfuWnxm+jlikCRVadeOAPowyEKTpsJvFfuWnUB['data'][i]['title']+'\n'
     except jlikCRVadeOAPowyEKTpsJvFfuWncM as exception:
      jlikCRVadeOAPowyEKTpsJvFfuWnch(exception)
     jlikCRVadeOAPowyEKTpsJvFfuWnUL={'collectionId':jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('obj_id'),'title':jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('row_name'),'category':jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('type'),'pre_title':jlikCRVadeOAPowyEKTpsJvFfuWnxm,}
     jlikCRVadeOAPowyEKTpsJvFfuWnUm.append(jlikCRVadeOAPowyEKTpsJvFfuWnUL)
  except jlikCRVadeOAPowyEKTpsJvFfuWncM as exception:
   jlikCRVadeOAPowyEKTpsJvFfuWnch(exception)
   return[]
  return jlikCRVadeOAPowyEKTpsJvFfuWnUm
 def Get_Event_GameList(jlikCRVadeOAPowyEKTpsJvFfuWnHx,jlikCRVadeOAPowyEKTpsJvFfuWnUI):
  jlikCRVadeOAPowyEKTpsJvFfuWnUm=[] 
  try:
   jlikCRVadeOAPowyEKTpsJvFfuWnUc=jlikCRVadeOAPowyEKTpsJvFfuWnHx.API_VIEWURL+'/v2/discover/feed' 
   jlikCRVadeOAPowyEKTpsJvFfuWnUQ={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false',}
   jlikCRVadeOAPowyEKTpsJvFfuWnUG=jlikCRVadeOAPowyEKTpsJvFfuWnHx.callRequestCookies('Get',jlikCRVadeOAPowyEKTpsJvFfuWnUc,payload=jlikCRVadeOAPowyEKTpsJvFfuWncY,params=jlikCRVadeOAPowyEKTpsJvFfuWnUQ,headers=jlikCRVadeOAPowyEKTpsJvFfuWncY,cookies=jlikCRVadeOAPowyEKTpsJvFfuWncY,redirects=jlikCRVadeOAPowyEKTpsJvFfuWncB)
   if jlikCRVadeOAPowyEKTpsJvFfuWnUG.status_code not in[200]:return[]
   jlikCRVadeOAPowyEKTpsJvFfuWnUN=json.loads(jlikCRVadeOAPowyEKTpsJvFfuWnUG.text)
   for jlikCRVadeOAPowyEKTpsJvFfuWnUB in jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('data'):
    if jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('obj_id')==jlikCRVadeOAPowyEKTpsJvFfuWnUI:
     for jlikCRVadeOAPowyEKTpsJvFfuWnxM in jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('data'):
      jlikCRVadeOAPowyEKTpsJvFfuWnxc=jlikCRVadeOAPowyEKTpsJvFfuWnxt=jlikCRVadeOAPowyEKTpsJvFfuWncg=''
      if 'poster' in jlikCRVadeOAPowyEKTpsJvFfuWnxM.get('images'):jlikCRVadeOAPowyEKTpsJvFfuWnxc =jlikCRVadeOAPowyEKTpsJvFfuWnxM.get('images').get('poster').get('url') +'?imwidth=350'
      if 'story-art' in jlikCRVadeOAPowyEKTpsJvFfuWnxM.get('images'):jlikCRVadeOAPowyEKTpsJvFfuWnxt =jlikCRVadeOAPowyEKTpsJvFfuWnxM.get('images').get('story-art').get('url')+'?imwidth=600'
      if 'hero' in jlikCRVadeOAPowyEKTpsJvFfuWnxM.get('images'):jlikCRVadeOAPowyEKTpsJvFfuWncg =jlikCRVadeOAPowyEKTpsJvFfuWnxM.get('images').get('hero').get('url') +'?imwidth=600'
      jlikCRVadeOAPowyEKTpsJvFfuWnxD=jlikCRVadeOAPowyEKTpsJvFfuWnxM.get('meta').get(jlikCRVadeOAPowyEKTpsJvFfuWnxM.get('category')).get(jlikCRVadeOAPowyEKTpsJvFfuWnxM.get('sub_category'))
      if 'league' in jlikCRVadeOAPowyEKTpsJvFfuWnxD:
       jlikCRVadeOAPowyEKTpsJvFfuWnxB=jlikCRVadeOAPowyEKTpsJvFfuWnxD.get('league')
      else:
       jlikCRVadeOAPowyEKTpsJvFfuWnxB=jlikCRVadeOAPowyEKTpsJvFfuWnxD.get('round')
      jlikCRVadeOAPowyEKTpsJvFfuWnUL={'id':jlikCRVadeOAPowyEKTpsJvFfuWnxM.get('id'),'title':jlikCRVadeOAPowyEKTpsJvFfuWnxM.get('title'),'thumbnail':{'poster':jlikCRVadeOAPowyEKTpsJvFfuWnxc,'thumb':jlikCRVadeOAPowyEKTpsJvFfuWnxt,'fanart':jlikCRVadeOAPowyEKTpsJvFfuWncg},'asis':jlikCRVadeOAPowyEKTpsJvFfuWnxM.get('type'),'addInfo':jlikCRVadeOAPowyEKTpsJvFfuWnxB,'starttm':jlikCRVadeOAPowyEKTpsJvFfuWnHx.convert_TimeStr(jlikCRVadeOAPowyEKTpsJvFfuWnxM.get('start_at')),}
      jlikCRVadeOAPowyEKTpsJvFfuWnUm.append(jlikCRVadeOAPowyEKTpsJvFfuWnUL)
  except jlikCRVadeOAPowyEKTpsJvFfuWncM as exception:
   jlikCRVadeOAPowyEKTpsJvFfuWnch(exception)
   return[]
  return jlikCRVadeOAPowyEKTpsJvFfuWnUm
 def Get_Event_List(jlikCRVadeOAPowyEKTpsJvFfuWnHx,gameId):
  jlikCRVadeOAPowyEKTpsJvFfuWnUm=[] 
  try:
   jlikCRVadeOAPowyEKTpsJvFfuWnUc=jlikCRVadeOAPowyEKTpsJvFfuWnHx.API_VIEWURL+'/v1/discover/events/'+gameId 
   jlikCRVadeOAPowyEKTpsJvFfuWnUQ={'platform':'WEBCLIENT','locale':'ko','filterRestrictedContent':'false',}
   jlikCRVadeOAPowyEKTpsJvFfuWnUG=jlikCRVadeOAPowyEKTpsJvFfuWnHx.callRequestCookies('Get',jlikCRVadeOAPowyEKTpsJvFfuWnUc,payload=jlikCRVadeOAPowyEKTpsJvFfuWncY,params=jlikCRVadeOAPowyEKTpsJvFfuWnUQ,headers=jlikCRVadeOAPowyEKTpsJvFfuWncY,cookies=jlikCRVadeOAPowyEKTpsJvFfuWncY,redirects=jlikCRVadeOAPowyEKTpsJvFfuWncB)
   if jlikCRVadeOAPowyEKTpsJvFfuWnUG.status_code not in[200]:return[]
   jlikCRVadeOAPowyEKTpsJvFfuWnUN=json.loads(jlikCRVadeOAPowyEKTpsJvFfuWnUG.text)
   jlikCRVadeOAPowyEKTpsJvFfuWnUB=jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('data')
   jlikCRVadeOAPowyEKTpsJvFfuWnxI=jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('end_at')
   jlikCRVadeOAPowyEKTpsJvFfuWnxI=jlikCRVadeOAPowyEKTpsJvFfuWnxI[0:19].replace('-','').replace(':','').replace('T','')
   jlikCRVadeOAPowyEKTpsJvFfuWnxL=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d%H%M%S')
   if jlikCRVadeOAPowyEKTpsJvFfuWncQ(jlikCRVadeOAPowyEKTpsJvFfuWnxL)<jlikCRVadeOAPowyEKTpsJvFfuWncQ(jlikCRVadeOAPowyEKTpsJvFfuWnxI):
    jlikCRVadeOAPowyEKTpsJvFfuWnxc=jlikCRVadeOAPowyEKTpsJvFfuWnxt=jlikCRVadeOAPowyEKTpsJvFfuWncg=''
    if 'poster' in jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('images'):jlikCRVadeOAPowyEKTpsJvFfuWnxc =jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('images'):jlikCRVadeOAPowyEKTpsJvFfuWnxt =jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('images').get('story-art').get('url')+'?imwidth=600'
    if 'story-art' in jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('images'):jlikCRVadeOAPowyEKTpsJvFfuWncg =jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('images').get('story-art').get('url')+'?imwidth=600'
    jlikCRVadeOAPowyEKTpsJvFfuWnUL={'id':jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('id'),'title':jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('title'),'thumbnail':{'poster':jlikCRVadeOAPowyEKTpsJvFfuWnxc,'thumb':jlikCRVadeOAPowyEKTpsJvFfuWnxt,'fanart':jlikCRVadeOAPowyEKTpsJvFfuWncg},'duration':jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('running_time'),'asis':jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('type'),'starttm':jlikCRVadeOAPowyEKTpsJvFfuWnHx.convert_TimeStr(jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('start_at')),}
    jlikCRVadeOAPowyEKTpsJvFfuWnUm.append(jlikCRVadeOAPowyEKTpsJvFfuWnUL)
  except jlikCRVadeOAPowyEKTpsJvFfuWncM as exception:
   jlikCRVadeOAPowyEKTpsJvFfuWnch(exception)
   return[]
  try:
   jlikCRVadeOAPowyEKTpsJvFfuWnUc=jlikCRVadeOAPowyEKTpsJvFfuWnHx.API_VIEWURL+'/v1/discover/events/'+gameId+'/related' 
   jlikCRVadeOAPowyEKTpsJvFfuWnUQ={'locale':'ko','page':'1','perPage':'25','platform':'WEBCLIENT','currentPageTracking':'page_discover_title_detail',}
   jlikCRVadeOAPowyEKTpsJvFfuWnUG=jlikCRVadeOAPowyEKTpsJvFfuWnHx.callRequestCookies('Get',jlikCRVadeOAPowyEKTpsJvFfuWnUc,payload=jlikCRVadeOAPowyEKTpsJvFfuWncY,params=jlikCRVadeOAPowyEKTpsJvFfuWnUQ,headers=jlikCRVadeOAPowyEKTpsJvFfuWncY,cookies=jlikCRVadeOAPowyEKTpsJvFfuWncY,redirects=jlikCRVadeOAPowyEKTpsJvFfuWncB)
   if jlikCRVadeOAPowyEKTpsJvFfuWnUG.status_code not in[200]:return[]
   jlikCRVadeOAPowyEKTpsJvFfuWnUN=json.loads(jlikCRVadeOAPowyEKTpsJvFfuWnUG.text)
   for jlikCRVadeOAPowyEKTpsJvFfuWnUB in jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('data').get('data'):
    jlikCRVadeOAPowyEKTpsJvFfuWnxc=jlikCRVadeOAPowyEKTpsJvFfuWnxt=jlikCRVadeOAPowyEKTpsJvFfuWncg=''
    if 'poster' in jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('images'):jlikCRVadeOAPowyEKTpsJvFfuWnxc =jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('images'):jlikCRVadeOAPowyEKTpsJvFfuWnxt =jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('images').get('story-art').get('url')+'?imwidth=600'
    if 'story-art' in jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('images'):jlikCRVadeOAPowyEKTpsJvFfuWncg =jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('images').get('story-art').get('url')+'?imwidth=600'
    jlikCRVadeOAPowyEKTpsJvFfuWnUL={'id':jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('id'),'title':jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('title'),'thumbnail':{'poster':jlikCRVadeOAPowyEKTpsJvFfuWnxc,'thumb':jlikCRVadeOAPowyEKTpsJvFfuWnxt,'fanart':jlikCRVadeOAPowyEKTpsJvFfuWncg},'duration':jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('running_time'),'asis':jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('type'),}
    jlikCRVadeOAPowyEKTpsJvFfuWnUm.append(jlikCRVadeOAPowyEKTpsJvFfuWnUL)
  except jlikCRVadeOAPowyEKTpsJvFfuWncM as exception:
   jlikCRVadeOAPowyEKTpsJvFfuWnch(exception)
   return[]
  return jlikCRVadeOAPowyEKTpsJvFfuWnUm
 def Get_Search_List(jlikCRVadeOAPowyEKTpsJvFfuWnHx,search_key,page_int):
  jlikCRVadeOAPowyEKTpsJvFfuWnUm=[] 
  jlikCRVadeOAPowyEKTpsJvFfuWnxH=jlikCRVadeOAPowyEKTpsJvFfuWncq
  try:
   jlikCRVadeOAPowyEKTpsJvFfuWnUc=jlikCRVadeOAPowyEKTpsJvFfuWnHx.API_VIEWURL+'/v2/search' 
   jlikCRVadeOAPowyEKTpsJvFfuWnUQ={'query':search_key,'platform':'WEBCLIENT','page':jlikCRVadeOAPowyEKTpsJvFfuWncS(page_int),'perPage':jlikCRVadeOAPowyEKTpsJvFfuWncS(jlikCRVadeOAPowyEKTpsJvFfuWnHx.SEARCH_LIMIT),}
   jlikCRVadeOAPowyEKTpsJvFfuWnUX={'x-membersrl':jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['member_srl'],'x-pcid':jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['PCID'],'x-profileid':jlikCRVadeOAPowyEKTpsJvFfuWnHx.CP['SESSION']['profileId'],}
   jlikCRVadeOAPowyEKTpsJvFfuWnUG=jlikCRVadeOAPowyEKTpsJvFfuWnHx.callRequestCookies('Get',jlikCRVadeOAPowyEKTpsJvFfuWnUc,payload=jlikCRVadeOAPowyEKTpsJvFfuWncY,params=jlikCRVadeOAPowyEKTpsJvFfuWnUQ,headers=jlikCRVadeOAPowyEKTpsJvFfuWnUX,cookies=jlikCRVadeOAPowyEKTpsJvFfuWncY,redirects=jlikCRVadeOAPowyEKTpsJvFfuWncB)
   if jlikCRVadeOAPowyEKTpsJvFfuWnUG.status_code not in[200]:return[],jlikCRVadeOAPowyEKTpsJvFfuWncq
   jlikCRVadeOAPowyEKTpsJvFfuWnUN=json.loads(jlikCRVadeOAPowyEKTpsJvFfuWnUG.text)
   for jlikCRVadeOAPowyEKTpsJvFfuWnUB in jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('data').get('data'):
    jlikCRVadeOAPowyEKTpsJvFfuWnUB=jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('data')
    jlikCRVadeOAPowyEKTpsJvFfuWnxc=jlikCRVadeOAPowyEKTpsJvFfuWnxt=jlikCRVadeOAPowyEKTpsJvFfuWncb=jlikCRVadeOAPowyEKTpsJvFfuWncg=''
    if 'poster' in jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('images'):jlikCRVadeOAPowyEKTpsJvFfuWnxc =jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('images'):jlikCRVadeOAPowyEKTpsJvFfuWnxt =jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('images').get('story-art').get('url') +'?imwidth=600'
    if 'title-treatment' in jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('images'):jlikCRVadeOAPowyEKTpsJvFfuWncb=jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('images').get('title-treatment').get('url')+'?imwidth=300'
    if 'story-art' in jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('images'):jlikCRVadeOAPowyEKTpsJvFfuWncg =jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('images').get('story-art').get('url') +'?imwidth=600'
    jlikCRVadeOAPowyEKTpsJvFfuWnxX=''
    if jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('badge')not in[{},jlikCRVadeOAPowyEKTpsJvFfuWncY]:
     for i in jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('badge').get('text'):
      if jlikCRVadeOAPowyEKTpsJvFfuWnxX!='':jlikCRVadeOAPowyEKTpsJvFfuWnxX+=' '
      jlikCRVadeOAPowyEKTpsJvFfuWnxX+=i.get('text')
    if 'as' in jlikCRVadeOAPowyEKTpsJvFfuWnUB:
     jlikCRVadeOAPowyEKTpsJvFfuWncH=jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('as') 
    else:
     jlikCRVadeOAPowyEKTpsJvFfuWncH=jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('type')
    jlikCRVadeOAPowyEKTpsJvFfuWnUL={'id':jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('id'),'title':jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('title'),'asis':jlikCRVadeOAPowyEKTpsJvFfuWncH,'thumbnail':{'poster':jlikCRVadeOAPowyEKTpsJvFfuWnxc,'thumb':jlikCRVadeOAPowyEKTpsJvFfuWnxt,'clearlogo':jlikCRVadeOAPowyEKTpsJvFfuWncb,'fanart':jlikCRVadeOAPowyEKTpsJvFfuWncg},'mpaa':jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('age_rating'),'duration':jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('running_time'),'badge':jlikCRVadeOAPowyEKTpsJvFfuWnxX,'year':jlikCRVadeOAPowyEKTpsJvFfuWnUB.get('meta').get('releaseYear'),}
    jlikCRVadeOAPowyEKTpsJvFfuWnUm.append(jlikCRVadeOAPowyEKTpsJvFfuWnUL)
   if jlikCRVadeOAPowyEKTpsJvFfuWnUN.get('pagination').get('totalPages')>page_int:
    jlikCRVadeOAPowyEKTpsJvFfuWnxH=jlikCRVadeOAPowyEKTpsJvFfuWncB
  except jlikCRVadeOAPowyEKTpsJvFfuWncM as exception:
   jlikCRVadeOAPowyEKTpsJvFfuWnch(exception)
   return[],jlikCRVadeOAPowyEKTpsJvFfuWncq
  return jlikCRVadeOAPowyEKTpsJvFfuWnUm,jlikCRVadeOAPowyEKTpsJvFfuWnxH
 def GetBookmarkInfo(jlikCRVadeOAPowyEKTpsJvFfuWnHx,videoid,vidtype):
  jlikCRVadeOAPowyEKTpsJvFfuWncU={'indexinfo':{'ott':'coupang','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  jlikCRVadeOAPowyEKTpsJvFfuWnUc=jlikCRVadeOAPowyEKTpsJvFfuWnHx.API_VIEWURL+'/v1/discover/titles/'+videoid 
  jlikCRVadeOAPowyEKTpsJvFfuWnUQ={'locale':'ko'}
  jlikCRVadeOAPowyEKTpsJvFfuWnUG=jlikCRVadeOAPowyEKTpsJvFfuWnHx.callRequestCookies('Get',jlikCRVadeOAPowyEKTpsJvFfuWnUc,payload=jlikCRVadeOAPowyEKTpsJvFfuWncY,params=jlikCRVadeOAPowyEKTpsJvFfuWnUQ,headers=jlikCRVadeOAPowyEKTpsJvFfuWncY,cookies=jlikCRVadeOAPowyEKTpsJvFfuWncY,redirects=jlikCRVadeOAPowyEKTpsJvFfuWncB)
  if jlikCRVadeOAPowyEKTpsJvFfuWnUG.status_code not in[200]:return{}
  jlikCRVadeOAPowyEKTpsJvFfuWncx=json.loads(jlikCRVadeOAPowyEKTpsJvFfuWnUG.text).get('data')
  jlikCRVadeOAPowyEKTpsJvFfuWncX=jlikCRVadeOAPowyEKTpsJvFfuWncx.get('title')
  jlikCRVadeOAPowyEKTpsJvFfuWncG =jlikCRVadeOAPowyEKTpsJvFfuWncx.get('meta').get('releaseYear')
  jlikCRVadeOAPowyEKTpsJvFfuWncU['saveinfo']['infoLabels']['title']=jlikCRVadeOAPowyEKTpsJvFfuWncX
  if vidtype=='movie':
   jlikCRVadeOAPowyEKTpsJvFfuWncX='%s  (%s)'%(jlikCRVadeOAPowyEKTpsJvFfuWncX,jlikCRVadeOAPowyEKTpsJvFfuWncG)
  jlikCRVadeOAPowyEKTpsJvFfuWncU['saveinfo']['title'] =jlikCRVadeOAPowyEKTpsJvFfuWncX
  jlikCRVadeOAPowyEKTpsJvFfuWncU['saveinfo']['infoLabels']['mpaa'] =jlikCRVadeOAPowyEKTpsJvFfuWncx.get('age_rating')
  jlikCRVadeOAPowyEKTpsJvFfuWncU['saveinfo']['infoLabels']['plot'] ='%s\n\n%s'%(jlikCRVadeOAPowyEKTpsJvFfuWncx.get('short_description'),jlikCRVadeOAPowyEKTpsJvFfuWncx.get('description'))
  jlikCRVadeOAPowyEKTpsJvFfuWncU['saveinfo']['infoLabels']['year'] =jlikCRVadeOAPowyEKTpsJvFfuWncG
  if vidtype=='movie':
   jlikCRVadeOAPowyEKTpsJvFfuWncU['saveinfo']['infoLabels']['duration']=jlikCRVadeOAPowyEKTpsJvFfuWncx.get('running_time')
  jlikCRVadeOAPowyEKTpsJvFfuWnxc =''
  jlikCRVadeOAPowyEKTpsJvFfuWncg =''
  jlikCRVadeOAPowyEKTpsJvFfuWnxt =''
  jlikCRVadeOAPowyEKTpsJvFfuWncb=''
  if jlikCRVadeOAPowyEKTpsJvFfuWncx.get('images').get('poster') !=jlikCRVadeOAPowyEKTpsJvFfuWncY:jlikCRVadeOAPowyEKTpsJvFfuWnxc =jlikCRVadeOAPowyEKTpsJvFfuWncx.get('images').get('poster').get('url') +'?imwidth=350'
  if jlikCRVadeOAPowyEKTpsJvFfuWncx.get('images').get('background') !=jlikCRVadeOAPowyEKTpsJvFfuWncY:jlikCRVadeOAPowyEKTpsJvFfuWncg =jlikCRVadeOAPowyEKTpsJvFfuWncx.get('images').get('background').get('url') +'?imwidth=600'
  if jlikCRVadeOAPowyEKTpsJvFfuWncx.get('images').get('story-art') !=jlikCRVadeOAPowyEKTpsJvFfuWncY:jlikCRVadeOAPowyEKTpsJvFfuWnxt =jlikCRVadeOAPowyEKTpsJvFfuWncx.get('images').get('story-art').get('url') +'?imwidth=600'
  if jlikCRVadeOAPowyEKTpsJvFfuWncx.get('images').get('title-treatment')!=jlikCRVadeOAPowyEKTpsJvFfuWncY:jlikCRVadeOAPowyEKTpsJvFfuWncb=jlikCRVadeOAPowyEKTpsJvFfuWncx.get('images').get('title-treatment').get('url')+'?imwidth=300'
  if jlikCRVadeOAPowyEKTpsJvFfuWncg=='':jlikCRVadeOAPowyEKTpsJvFfuWncg=jlikCRVadeOAPowyEKTpsJvFfuWnxt
  jlikCRVadeOAPowyEKTpsJvFfuWncU['saveinfo']['thumbnail']['poster']=jlikCRVadeOAPowyEKTpsJvFfuWnxc
  jlikCRVadeOAPowyEKTpsJvFfuWncU['saveinfo']['thumbnail']['fanart']=jlikCRVadeOAPowyEKTpsJvFfuWncg
  jlikCRVadeOAPowyEKTpsJvFfuWncU['saveinfo']['thumbnail']['thumb']=jlikCRVadeOAPowyEKTpsJvFfuWnxt
  jlikCRVadeOAPowyEKTpsJvFfuWncU['saveinfo']['thumbnail']['clearlogo']=jlikCRVadeOAPowyEKTpsJvFfuWncb
  jlikCRVadeOAPowyEKTpsJvFfuWnct=[]
  for jlikCRVadeOAPowyEKTpsJvFfuWnxb in jlikCRVadeOAPowyEKTpsJvFfuWncx.get('tags'):jlikCRVadeOAPowyEKTpsJvFfuWnct.append(jlikCRVadeOAPowyEKTpsJvFfuWnxb.get('tag'))
  if jlikCRVadeOAPowyEKTpsJvFfuWncI(jlikCRVadeOAPowyEKTpsJvFfuWnct)>0:
   jlikCRVadeOAPowyEKTpsJvFfuWncU['saveinfo']['infoLabels']['genre']=jlikCRVadeOAPowyEKTpsJvFfuWnct
  jlikCRVadeOAPowyEKTpsJvFfuWncr=[]
  jlikCRVadeOAPowyEKTpsJvFfuWncz=[]
  for jlikCRVadeOAPowyEKTpsJvFfuWnxb in jlikCRVadeOAPowyEKTpsJvFfuWncx.get('people'):
   if jlikCRVadeOAPowyEKTpsJvFfuWnxb.get('role')=='CAST' :jlikCRVadeOAPowyEKTpsJvFfuWncr.append(jlikCRVadeOAPowyEKTpsJvFfuWnxb.get('name'))
   if jlikCRVadeOAPowyEKTpsJvFfuWnxb.get('role')=='DIRECTOR':jlikCRVadeOAPowyEKTpsJvFfuWncz.append(jlikCRVadeOAPowyEKTpsJvFfuWnxb.get('name'))
  if jlikCRVadeOAPowyEKTpsJvFfuWncI(jlikCRVadeOAPowyEKTpsJvFfuWncr)>0:
   jlikCRVadeOAPowyEKTpsJvFfuWncU['saveinfo']['infoLabels']['cast'] =jlikCRVadeOAPowyEKTpsJvFfuWncr
  if jlikCRVadeOAPowyEKTpsJvFfuWncI(jlikCRVadeOAPowyEKTpsJvFfuWncz)>0:
   jlikCRVadeOAPowyEKTpsJvFfuWncU['saveinfo']['infoLabels']['director']=jlikCRVadeOAPowyEKTpsJvFfuWncz
  return jlikCRVadeOAPowyEKTpsJvFfuWncU
# Created by pyminifier (https://github.com/liftoff/pyminifier)
