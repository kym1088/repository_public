__author__="NightRain"
hUwlFBOkGcdszWNrLqCKeQDYaRImib=object
hUwlFBOkGcdszWNrLqCKeQDYaRImiP=None
hUwlFBOkGcdszWNrLqCKeQDYaRImiT=False
hUwlFBOkGcdszWNrLqCKeQDYaRImip=print
hUwlFBOkGcdszWNrLqCKeQDYaRImiE=str
hUwlFBOkGcdszWNrLqCKeQDYaRImin=open
hUwlFBOkGcdszWNrLqCKeQDYaRImij=int
hUwlFBOkGcdszWNrLqCKeQDYaRImiS=Exception
hUwlFBOkGcdszWNrLqCKeQDYaRImiu=id
hUwlFBOkGcdszWNrLqCKeQDYaRImig=True
hUwlFBOkGcdszWNrLqCKeQDYaRImiV=len
hUwlFBOkGcdszWNrLqCKeQDYaRImiy=range
import urllib
import re
import json
import requests
import datetime
import time
import random
import base64
class hUwlFBOkGcdszWNrLqCKeQDYaRImfo(hUwlFBOkGcdszWNrLqCKeQDYaRImib):
 def __init__(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ):
  hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36 Edg/107.0.1418.62' 
  hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.MODEL ='Edge_107' 
  hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.OS_VERSION ='107' 
  hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.DEFAULT_HEADER ={'user-agent':hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.USER_AGENT}
  hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.API_DOMAIN ='https://www.coupangplay.com'
  hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.API_VIEWURL ='https://discover.coupangstreaming.com'
  hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.PAGE_LIMIT =40
  hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.SEARCH_LIMIT =20
  hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP={}
  hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.Init_CP()
  hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP_DEVICE_FILENAME=''
  hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP_COOKIE_FILENAME=''
 def callRequestCookies(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ,jobtype,hUwlFBOkGcdszWNrLqCKeQDYaRImoi,payload=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,params=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,headers=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,cookies=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,redirects=hUwlFBOkGcdszWNrLqCKeQDYaRImiT):
  hUwlFBOkGcdszWNrLqCKeQDYaRImfi=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.DEFAULT_HEADER
  if headers:hUwlFBOkGcdszWNrLqCKeQDYaRImfi.update(headers)
  if jobtype=='Get':
   hUwlFBOkGcdszWNrLqCKeQDYaRImft=requests.get(hUwlFBOkGcdszWNrLqCKeQDYaRImoi,params=params,headers=hUwlFBOkGcdszWNrLqCKeQDYaRImfi,cookies=cookies,allow_redirects=redirects)
  else:
   hUwlFBOkGcdszWNrLqCKeQDYaRImft=requests.post(hUwlFBOkGcdszWNrLqCKeQDYaRImoi,data=payload,params=params,headers=hUwlFBOkGcdszWNrLqCKeQDYaRImfi,cookies=cookies,allow_redirects=redirects)
  hUwlFBOkGcdszWNrLqCKeQDYaRImip(hUwlFBOkGcdszWNrLqCKeQDYaRImiE(hUwlFBOkGcdszWNrLqCKeQDYaRImft.status_code)+' - '+hUwlFBOkGcdszWNrLqCKeQDYaRImiE(hUwlFBOkGcdszWNrLqCKeQDYaRImft.url))
  return hUwlFBOkGcdszWNrLqCKeQDYaRImft
 def callRequestCookies_test(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ,jobtype,hUwlFBOkGcdszWNrLqCKeQDYaRImoi,payload=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,params=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,headers=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,cookies=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,redirects=hUwlFBOkGcdszWNrLqCKeQDYaRImiT):
  hUwlFBOkGcdszWNrLqCKeQDYaRImfi=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.DEFAULT_HEADER
  if headers:hUwlFBOkGcdszWNrLqCKeQDYaRImfi.update(headers)
  hUwlFBOkGcdszWNrLqCKeQDYaRImft=requests.Request('POST',hUwlFBOkGcdszWNrLqCKeQDYaRImoi,headers=headers,data=payload,params=params,cookies=cookies)
  hUwlFBOkGcdszWNrLqCKeQDYaRImfv=hUwlFBOkGcdszWNrLqCKeQDYaRImft.prepare()
  hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.pretty_print_POST(hUwlFBOkGcdszWNrLqCKeQDYaRImfv)
  return hUwlFBOkGcdszWNrLqCKeQDYaRImft
 def pretty_print_POST(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ,req):
  hUwlFBOkGcdszWNrLqCKeQDYaRImip('{}\n{}\r\n{}\r\n\r\n{}'.format('-----------START-----------',req.method+' '+req.url,'\r\n'.join('{}: {}'.format(k,v)for k,v in req.headers.items()),req.body,))
 def dic_To_jsonfile(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ,filename,hUwlFBOkGcdszWNrLqCKeQDYaRImfx):
  if filename=='':return
  fp=hUwlFBOkGcdszWNrLqCKeQDYaRImin(filename,'w',-1,'utf-8')
  json.dump(hUwlFBOkGcdszWNrLqCKeQDYaRImfx,fp,indent=4,ensure_ascii=hUwlFBOkGcdszWNrLqCKeQDYaRImiT)
  fp.close()
 def jsonfile_To_dic(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ,filename):
  if filename=='':return hUwlFBOkGcdszWNrLqCKeQDYaRImiP
  try:
   fp=hUwlFBOkGcdszWNrLqCKeQDYaRImin(filename,'r',-1,'utf-8')
   hUwlFBOkGcdszWNrLqCKeQDYaRImfM=json.load(fp)
   fp.close()
  except:
   hUwlFBOkGcdszWNrLqCKeQDYaRImfM={}
  return hUwlFBOkGcdszWNrLqCKeQDYaRImfM
 def convert_TimeStr(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ,hUwlFBOkGcdszWNrLqCKeQDYaRImfX):
  try:
   hUwlFBOkGcdszWNrLqCKeQDYaRImfX =hUwlFBOkGcdszWNrLqCKeQDYaRImfX[0:16]
   hUwlFBOkGcdszWNrLqCKeQDYaRImfA=datetime.datetime.strptime(hUwlFBOkGcdszWNrLqCKeQDYaRImfX,'%Y-%m-%dT%H:%M')+datetime.timedelta(hours=9)
   return hUwlFBOkGcdszWNrLqCKeQDYaRImfA.strftime('%Y-%m-%d %H:%M')
  except:
   return hUwlFBOkGcdszWNrLqCKeQDYaRImiP
 def Get_Now_Datetime(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetNoCache(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ):
  hUwlFBOkGcdszWNrLqCKeQDYaRImfP =hUwlFBOkGcdszWNrLqCKeQDYaRImij(time.time()*1000)
  return hUwlFBOkGcdszWNrLqCKeQDYaRImfP
 def generatePcId(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ):
  t=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.GetNoCache()
  r=random.random()
  hUwlFBOkGcdszWNrLqCKeQDYaRImfT=hUwlFBOkGcdszWNrLqCKeQDYaRImiE(t)+hUwlFBOkGcdszWNrLqCKeQDYaRImiE(r)[2:12]
  return hUwlFBOkGcdszWNrLqCKeQDYaRImfT
 def generatePvId(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ,genType='1'):
  import hashlib
  m=hashlib.md5()
  hUwlFBOkGcdszWNrLqCKeQDYaRImfp=hUwlFBOkGcdszWNrLqCKeQDYaRImiE(random.random())
  m.update(hUwlFBOkGcdszWNrLqCKeQDYaRImfp.encode('utf-8'))
  hUwlFBOkGcdszWNrLqCKeQDYaRImfE=hUwlFBOkGcdszWNrLqCKeQDYaRImiE(m.hexdigest())
  if genType=='1':
   return '%s-%s-%s-%s-%s'%(hUwlFBOkGcdszWNrLqCKeQDYaRImfE[:8],hUwlFBOkGcdszWNrLqCKeQDYaRImfE[8:12],hUwlFBOkGcdszWNrLqCKeQDYaRImfE[12:16],hUwlFBOkGcdszWNrLqCKeQDYaRImfE[16:20],hUwlFBOkGcdszWNrLqCKeQDYaRImfE[20:])
  else:
   return hUwlFBOkGcdszWNrLqCKeQDYaRImfE
 def Get_DeviceID(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ):
  hUwlFBOkGcdszWNrLqCKeQDYaRImfn=''
  try: 
   fp=hUwlFBOkGcdszWNrLqCKeQDYaRImin(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP_DEVICE_FILENAME,'r',-1,'utf-8')
   hUwlFBOkGcdszWNrLqCKeQDYaRImfj= json.load(fp)
   fp.close()
   hUwlFBOkGcdszWNrLqCKeQDYaRImfn=hUwlFBOkGcdszWNrLqCKeQDYaRImfj.get('device_id')
  except hUwlFBOkGcdszWNrLqCKeQDYaRImiS as exception:
   hUwlFBOkGcdszWNrLqCKeQDYaRImiP
  if hUwlFBOkGcdszWNrLqCKeQDYaRImfn=='':
   hUwlFBOkGcdszWNrLqCKeQDYaRImfn=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.generatePvId(genType='1')
   try: 
    fp=hUwlFBOkGcdszWNrLqCKeQDYaRImin(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP_DEVICE_FILENAME,'w',-1,'utf-8')
    json.dump({'device_id':hUwlFBOkGcdszWNrLqCKeQDYaRImfn},fp,indent=4,ensure_ascii=hUwlFBOkGcdszWNrLqCKeQDYaRImiT)
    fp.close()
   except hUwlFBOkGcdszWNrLqCKeQDYaRImiS as exception:
    return ''
  return hUwlFBOkGcdszWNrLqCKeQDYaRImfn
 def Make_authHeader(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ):
  tr=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.generatePvId(genType=2)
  ti=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.GetNoCache()
  hUwlFBOkGcdszWNrLqCKeQDYaRImiu=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.generatePvId(genType=2)[:16]
  hUwlFBOkGcdszWNrLqCKeQDYaRImfS='00-%s-%s-01'%(tr,hUwlFBOkGcdszWNrLqCKeQDYaRImiu,)
  hUwlFBOkGcdszWNrLqCKeQDYaRImfu ='%s@nr=0-1-%s-%s-%s----%s'%(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['NREUM']['tk'],hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['NREUM']['ac'],hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['NREUM']['ap'],hUwlFBOkGcdszWNrLqCKeQDYaRImiu,ti,)
  hUwlFBOkGcdszWNrLqCKeQDYaRImfg ='{"v":[0,1],"d":{"ty":"Browser","ac":"%s","ap":"%s","id":"%s","tr":"%s","ti":%s,"tk":"%s"}}'%(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['NREUM']['ac'],hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['NREUM']['ap'],hUwlFBOkGcdszWNrLqCKeQDYaRImiu,tr,ti,hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['NREUM']['tk'],) 
  return hUwlFBOkGcdszWNrLqCKeQDYaRImfS,hUwlFBOkGcdszWNrLqCKeQDYaRImfu,base64.standard_b64encode(hUwlFBOkGcdszWNrLqCKeQDYaRImfg.encode()).decode('utf-8')
 def Init_CP(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ):
  hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP={}
  hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['ACCOUNT']={'cpid':'','cppw':'','cppf':'0'}
  hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']={}
 def Save_session_acount(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ,hUwlFBOkGcdszWNrLqCKeQDYaRImfV,hUwlFBOkGcdszWNrLqCKeQDYaRImfy,hUwlFBOkGcdszWNrLqCKeQDYaRImof):
  hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['ACCOUNT']['cpid']=base64.standard_b64encode(hUwlFBOkGcdszWNrLqCKeQDYaRImfV.encode()).decode('utf-8')
  hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['ACCOUNT']['cppw']=base64.standard_b64encode(hUwlFBOkGcdszWNrLqCKeQDYaRImfy.encode()).decode('utf-8')
  hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['ACCOUNT']['cppf']=hUwlFBOkGcdszWNrLqCKeQDYaRImiE(hUwlFBOkGcdszWNrLqCKeQDYaRImof)
 def Load_session_acount(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ):
  hUwlFBOkGcdszWNrLqCKeQDYaRImfV=base64.standard_b64decode(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['ACCOUNT']['cpid']).decode('utf-8')
  hUwlFBOkGcdszWNrLqCKeQDYaRImfy=base64.standard_b64decode(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['ACCOUNT']['cppw']).decode('utf-8')
  hUwlFBOkGcdszWNrLqCKeQDYaRImof=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['ACCOUNT']['cppf']
  return hUwlFBOkGcdszWNrLqCKeQDYaRImfV,hUwlFBOkGcdszWNrLqCKeQDYaRImfy,hUwlFBOkGcdszWNrLqCKeQDYaRImof
 def make_CP_DefaultCookies(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ):
  hUwlFBOkGcdszWNrLqCKeQDYaRImoJ={}
  if 'NEXT_LOCALE' in hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']:hUwlFBOkGcdszWNrLqCKeQDYaRImoJ['NEXT_LOCALE'] =hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['NEXT_LOCALE']
  if 'ak_bmsc' in hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']:hUwlFBOkGcdszWNrLqCKeQDYaRImoJ['ak_bmsc'] =hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['ak_bmsc']
  if 'bm_mi' in hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']:hUwlFBOkGcdszWNrLqCKeQDYaRImoJ['bm_mi'] =hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['bm_mi']
  if 'bm_sv' in hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']:hUwlFBOkGcdszWNrLqCKeQDYaRImoJ['bm_sv'] =hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['bm_sv']
  if 'PCID' in hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']:hUwlFBOkGcdszWNrLqCKeQDYaRImoJ['PCID'] =hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['PCID']
  if 'member_srl' in hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']:hUwlFBOkGcdszWNrLqCKeQDYaRImoJ['member_srl'] =hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['member_srl']
  if 'token' in hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']:hUwlFBOkGcdszWNrLqCKeQDYaRImoJ['token'] =hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['token']
  if 'session_web_id' in hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']:hUwlFBOkGcdszWNrLqCKeQDYaRImoJ['session_web_id']=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['session_web_id']
  if 'device_id' in hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']:hUwlFBOkGcdszWNrLqCKeQDYaRImoJ['device_id'] =hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['device_id']
  return hUwlFBOkGcdszWNrLqCKeQDYaRImoJ
 def Get_CP_Login(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ,userid,userpw,hUwlFBOkGcdszWNrLqCKeQDYaRImoT):
  try:
   hUwlFBOkGcdszWNrLqCKeQDYaRImoi=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.API_DOMAIN
   hUwlFBOkGcdszWNrLqCKeQDYaRImot=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.callRequestCookies('Get',hUwlFBOkGcdszWNrLqCKeQDYaRImoi,payload=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,params=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,headers=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,cookies=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,redirects=hUwlFBOkGcdszWNrLqCKeQDYaRImiT)
   if hUwlFBOkGcdszWNrLqCKeQDYaRImot.status_code not in[301,302]:return hUwlFBOkGcdszWNrLqCKeQDYaRImiT
   for hUwlFBOkGcdszWNrLqCKeQDYaRImov in hUwlFBOkGcdszWNrLqCKeQDYaRImot.cookies:
    hUwlFBOkGcdszWNrLqCKeQDYaRImip(hUwlFBOkGcdszWNrLqCKeQDYaRImov.name,hUwlFBOkGcdszWNrLqCKeQDYaRImov.value) 
    if hUwlFBOkGcdszWNrLqCKeQDYaRImov.name=='NEXT_LOCALE':
     hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['NEXT_LOCALE']=hUwlFBOkGcdszWNrLqCKeQDYaRImov.value
    elif hUwlFBOkGcdszWNrLqCKeQDYaRImov.name=='ak_bmsc':
     hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['ak_bmsc']=hUwlFBOkGcdszWNrLqCKeQDYaRImov.value
   hUwlFBOkGcdszWNrLqCKeQDYaRImoJ=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.make_CP_DefaultCookies()
   hUwlFBOkGcdszWNrLqCKeQDYaRImot=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.callRequestCookies('Get',hUwlFBOkGcdszWNrLqCKeQDYaRImoi,payload=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,params=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,headers=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,cookies=hUwlFBOkGcdszWNrLqCKeQDYaRImoJ,redirects=hUwlFBOkGcdszWNrLqCKeQDYaRImiT)
   if hUwlFBOkGcdszWNrLqCKeQDYaRImot.status_code not in[200]:return hUwlFBOkGcdszWNrLqCKeQDYaRImiT
   hUwlFBOkGcdszWNrLqCKeQDYaRImox=re.findall('NREUM.loader_config=\{[\w\d\":,-]+\}',hUwlFBOkGcdszWNrLqCKeQDYaRImot.text)[0].split('=')[1]
   hUwlFBOkGcdszWNrLqCKeQDYaRImox=hUwlFBOkGcdszWNrLqCKeQDYaRImox.replace('{','{"').replace(':','":').replace(',',',"')
   hUwlFBOkGcdszWNrLqCKeQDYaRImox=json.loads(hUwlFBOkGcdszWNrLqCKeQDYaRImox)
   hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['NREUM']={'ac':hUwlFBOkGcdszWNrLqCKeQDYaRImox['accountID'],'tk':hUwlFBOkGcdszWNrLqCKeQDYaRImox['trustKey'],'ap':hUwlFBOkGcdszWNrLqCKeQDYaRImox['agentID'],'lk':hUwlFBOkGcdszWNrLqCKeQDYaRImox['licenseKey'],}
   hUwlFBOkGcdszWNrLqCKeQDYaRImip('---')
   for hUwlFBOkGcdszWNrLqCKeQDYaRImov in hUwlFBOkGcdszWNrLqCKeQDYaRImot.cookies:
    hUwlFBOkGcdszWNrLqCKeQDYaRImip(hUwlFBOkGcdszWNrLqCKeQDYaRImov.name,hUwlFBOkGcdszWNrLqCKeQDYaRImov.value) 
    if hUwlFBOkGcdszWNrLqCKeQDYaRImov.name=='bm_mi':
     hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['bm_mi']=hUwlFBOkGcdszWNrLqCKeQDYaRImov.value
    elif hUwlFBOkGcdszWNrLqCKeQDYaRImov.name=='bm_sv':
     hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['bm_sv'] =hUwlFBOkGcdszWNrLqCKeQDYaRImov.value
     hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['bm_sv_ex']=hUwlFBOkGcdszWNrLqCKeQDYaRImov.expires 
    elif hUwlFBOkGcdszWNrLqCKeQDYaRImov.name=='session_web_id':
     hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['session_web_id']=hUwlFBOkGcdszWNrLqCKeQDYaRImov.value
  except hUwlFBOkGcdszWNrLqCKeQDYaRImiS as exception:
   hUwlFBOkGcdszWNrLqCKeQDYaRImip(exception)
   return hUwlFBOkGcdszWNrLqCKeQDYaRImiT
  try:
   hUwlFBOkGcdszWNrLqCKeQDYaRImoi=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.API_DOMAIN+'/api/auth'
   hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['PCID']=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.generatePcId()
   hUwlFBOkGcdszWNrLqCKeQDYaRImoH=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.Get_DeviceID()
   hUwlFBOkGcdszWNrLqCKeQDYaRImoM =hUwlFBOkGcdszWNrLqCKeQDYaRImoH.split('-')[0]
   hUwlFBOkGcdszWNrLqCKeQDYaRImfS,hUwlFBOkGcdszWNrLqCKeQDYaRImfu,hUwlFBOkGcdszWNrLqCKeQDYaRImfg=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.Make_authHeader()
   hUwlFBOkGcdszWNrLqCKeQDYaRImoX={'traceparent':hUwlFBOkGcdszWNrLqCKeQDYaRImfS,'tracestate':hUwlFBOkGcdszWNrLqCKeQDYaRImfu,'newrelic':hUwlFBOkGcdszWNrLqCKeQDYaRImfg,'content-type':'application/json','x-app-version':'1.26.1','x-device-id':'','x-device-os-version':hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.OS_VERSION,'x-nr-session-id':hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['session_web_id'],'x-pcid':'',}
   hUwlFBOkGcdszWNrLqCKeQDYaRImoA={'device':{'deviceId':'web-'+hUwlFBOkGcdszWNrLqCKeQDYaRImoH,'model':hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.MODEL,'name':'Edge Desktop '+hUwlFBOkGcdszWNrLqCKeQDYaRImoM,'os':'Windows','osVersion':'10','type':'webclient',},'email':userid,'password':userpw,}
   hUwlFBOkGcdszWNrLqCKeQDYaRImoA=json.dumps(hUwlFBOkGcdszWNrLqCKeQDYaRImoA,separators=(',',':'))
   hUwlFBOkGcdszWNrLqCKeQDYaRImoJ=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.make_CP_DefaultCookies()
   hUwlFBOkGcdszWNrLqCKeQDYaRImot=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.callRequestCookies('Post',hUwlFBOkGcdszWNrLqCKeQDYaRImoi,payload=hUwlFBOkGcdszWNrLqCKeQDYaRImoA,params=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,headers=hUwlFBOkGcdszWNrLqCKeQDYaRImoX,cookies=hUwlFBOkGcdszWNrLqCKeQDYaRImoJ,redirects=hUwlFBOkGcdszWNrLqCKeQDYaRImiT)
   if hUwlFBOkGcdszWNrLqCKeQDYaRImot.status_code not in[200]:
    hUwlFBOkGcdszWNrLqCKeQDYaRImob=json.loads(hUwlFBOkGcdszWNrLqCKeQDYaRImot.text)
    if 'error' in hUwlFBOkGcdszWNrLqCKeQDYaRImob:
     hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['error']=hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('error').get('detail')
    return hUwlFBOkGcdszWNrLqCKeQDYaRImiT
   hUwlFBOkGcdszWNrLqCKeQDYaRImip('---')
   for hUwlFBOkGcdszWNrLqCKeQDYaRImov in hUwlFBOkGcdszWNrLqCKeQDYaRImot.cookies:
    hUwlFBOkGcdszWNrLqCKeQDYaRImip(hUwlFBOkGcdszWNrLqCKeQDYaRImov.name,hUwlFBOkGcdszWNrLqCKeQDYaRImov.value) 
    if hUwlFBOkGcdszWNrLqCKeQDYaRImov.name=='token':
     hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['token']=hUwlFBOkGcdszWNrLqCKeQDYaRImov.value
    elif hUwlFBOkGcdszWNrLqCKeQDYaRImov.name=='member_srl':
     hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['member_srl']=hUwlFBOkGcdszWNrLqCKeQDYaRImov.value
    elif hUwlFBOkGcdszWNrLqCKeQDYaRImov.name=='bm_sv':
     hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['bm_sv'] =hUwlFBOkGcdszWNrLqCKeQDYaRImov.value
     hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['bm_sv_ex']=hUwlFBOkGcdszWNrLqCKeQDYaRImov.expires 
    elif hUwlFBOkGcdszWNrLqCKeQDYaRImov.name=='device_id':
     hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['device_id']=hUwlFBOkGcdszWNrLqCKeQDYaRImov.value
  except hUwlFBOkGcdszWNrLqCKeQDYaRImiS as exception:
   hUwlFBOkGcdszWNrLqCKeQDYaRImip(exception)
   return hUwlFBOkGcdszWNrLqCKeQDYaRImiT
  hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.Save_session_acount(userid,userpw,hUwlFBOkGcdszWNrLqCKeQDYaRImoT)
  return hUwlFBOkGcdszWNrLqCKeQDYaRImig
 def Get_CP_profile(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ,hUwlFBOkGcdszWNrLqCKeQDYaRImoT,limit_days=1,re_check=hUwlFBOkGcdszWNrLqCKeQDYaRImiT):
  if re_check==hUwlFBOkGcdszWNrLqCKeQDYaRImig:
   if hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['bm_sv_ex']>hUwlFBOkGcdszWNrLqCKeQDYaRImij(time.time()):
    hUwlFBOkGcdszWNrLqCKeQDYaRImip('bm_sv_ex ok')
    return hUwlFBOkGcdszWNrLqCKeQDYaRImig
  try:
   hUwlFBOkGcdszWNrLqCKeQDYaRImoi=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.API_DOMAIN+'/api/profiles'
   hUwlFBOkGcdszWNrLqCKeQDYaRImfS,hUwlFBOkGcdszWNrLqCKeQDYaRImfu,hUwlFBOkGcdszWNrLqCKeQDYaRImfg=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.Make_authHeader()
   hUwlFBOkGcdszWNrLqCKeQDYaRImoX={'traceparent':hUwlFBOkGcdszWNrLqCKeQDYaRImfS,'tracestate':hUwlFBOkGcdszWNrLqCKeQDYaRImfu,'newrelic':hUwlFBOkGcdszWNrLqCKeQDYaRImfg,'x-app-version':'1.26.1','x-device-id':'','x-device-os-version':hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.OS_VERSION,'x-nr-session-id':hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['session_web_id'],'x-pcid':'',}
   hUwlFBOkGcdszWNrLqCKeQDYaRImoJ=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.make_CP_DefaultCookies()
   hUwlFBOkGcdszWNrLqCKeQDYaRImot=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.callRequestCookies('Get',hUwlFBOkGcdszWNrLqCKeQDYaRImoi,payload=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,params=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,headers=hUwlFBOkGcdszWNrLqCKeQDYaRImoX,cookies=hUwlFBOkGcdszWNrLqCKeQDYaRImoJ,redirects=hUwlFBOkGcdszWNrLqCKeQDYaRImiT)
   if hUwlFBOkGcdszWNrLqCKeQDYaRImot.status_code not in[200]:return hUwlFBOkGcdszWNrLqCKeQDYaRImiT
   hUwlFBOkGcdszWNrLqCKeQDYaRImob=json.loads(hUwlFBOkGcdszWNrLqCKeQDYaRImot.text)
   hUwlFBOkGcdszWNrLqCKeQDYaRImoP=0 
   for hUwlFBOkGcdszWNrLqCKeQDYaRImov in hUwlFBOkGcdszWNrLqCKeQDYaRImot.cookies:
    hUwlFBOkGcdszWNrLqCKeQDYaRImip(hUwlFBOkGcdszWNrLqCKeQDYaRImov.name)
    if hUwlFBOkGcdszWNrLqCKeQDYaRImov.name=='bm_sv':
     hUwlFBOkGcdszWNrLqCKeQDYaRImoP=1
     hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['bm_sv'] =hUwlFBOkGcdszWNrLqCKeQDYaRImov.value
     hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['bm_sv_ex']=hUwlFBOkGcdszWNrLqCKeQDYaRImov.expires 
   if hUwlFBOkGcdszWNrLqCKeQDYaRImoP==0:
    hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['bm_sv_ex']=hUwlFBOkGcdszWNrLqCKeQDYaRImij(time.time())+60*60*2 
   hUwlFBOkGcdszWNrLqCKeQDYaRImoT=hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('data')[hUwlFBOkGcdszWNrLqCKeQDYaRImij(hUwlFBOkGcdszWNrLqCKeQDYaRImoT)]
   hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['accountId']=hUwlFBOkGcdszWNrLqCKeQDYaRImoT.get('accountId')
   hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['profileId']=hUwlFBOkGcdszWNrLqCKeQDYaRImoT.get('profileId')
  except hUwlFBOkGcdszWNrLqCKeQDYaRImiS as exception:
   hUwlFBOkGcdszWNrLqCKeQDYaRImip(exception)
   return hUwlFBOkGcdszWNrLqCKeQDYaRImiT
  if re_check==hUwlFBOkGcdszWNrLqCKeQDYaRImiT:
   hUwlFBOkGcdszWNrLqCKeQDYaRImop =hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.Get_Now_Datetime()
   hUwlFBOkGcdszWNrLqCKeQDYaRImoE=hUwlFBOkGcdszWNrLqCKeQDYaRImop+datetime.timedelta(days=limit_days)
   hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['limitdate']=hUwlFBOkGcdszWNrLqCKeQDYaRImoE.strftime('%Y-%m-%d')
  else:
   hUwlFBOkGcdszWNrLqCKeQDYaRImip('re check')
  hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.dic_To_jsonfile(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP_COOKIE_FILENAME,hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP)
  return hUwlFBOkGcdszWNrLqCKeQDYaRImig
 def Get_Category_GroupList(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ,vType):
  hUwlFBOkGcdszWNrLqCKeQDYaRImon=[] 
  try:
   hUwlFBOkGcdszWNrLqCKeQDYaRImoi=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.API_VIEWURL+'/v2/discover/feed' 
   hUwlFBOkGcdszWNrLqCKeQDYaRImoj={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false',}
   hUwlFBOkGcdszWNrLqCKeQDYaRImot=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.callRequestCookies('Get',hUwlFBOkGcdszWNrLqCKeQDYaRImoi,payload=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,params=hUwlFBOkGcdszWNrLqCKeQDYaRImoj,headers=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,cookies=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,redirects=hUwlFBOkGcdszWNrLqCKeQDYaRImig)
   if hUwlFBOkGcdszWNrLqCKeQDYaRImot.status_code not in[200]:return[]
   hUwlFBOkGcdszWNrLqCKeQDYaRImob=json.loads(hUwlFBOkGcdszWNrLqCKeQDYaRImot.text)
   if vType in['TVSHOWS','MOVIES']:
    hUwlFBOkGcdszWNrLqCKeQDYaRImoS='Explores' 
   elif vType in['EDUCATION']:
    hUwlFBOkGcdszWNrLqCKeQDYaRImoS='Collection-Rails-Curation'
   elif vType in['ALL']:
    hUwlFBOkGcdszWNrLqCKeQDYaRImoS='Explores-Categories'
   for hUwlFBOkGcdszWNrLqCKeQDYaRImou in hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('data'):
    if hUwlFBOkGcdszWNrLqCKeQDYaRImou.get('type')==hUwlFBOkGcdszWNrLqCKeQDYaRImoS:
     for hUwlFBOkGcdszWNrLqCKeQDYaRImog in hUwlFBOkGcdszWNrLqCKeQDYaRImou.get('data'):
      if vType in['TVSHOWS','MOVIES']:
       hUwlFBOkGcdszWNrLqCKeQDYaRImoV=hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('collectionId')
      elif vType in['EDUCATION','ALL']:
       hUwlFBOkGcdszWNrLqCKeQDYaRImoV=hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('id')
      hUwlFBOkGcdszWNrLqCKeQDYaRImoy={'collectionId':hUwlFBOkGcdszWNrLqCKeQDYaRImoV,'title':hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('name'),'category':hUwlFBOkGcdszWNrLqCKeQDYaRImou.get('category'),'pre_title':'',}
      hUwlFBOkGcdszWNrLqCKeQDYaRImon.append(hUwlFBOkGcdszWNrLqCKeQDYaRImoy)
     break
  except hUwlFBOkGcdszWNrLqCKeQDYaRImiS as exception:
   hUwlFBOkGcdszWNrLqCKeQDYaRImip(exception)
   return[]
  return hUwlFBOkGcdszWNrLqCKeQDYaRImon
 def Get_Category_List(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ,vType,hUwlFBOkGcdszWNrLqCKeQDYaRImoV,page_int):
  hUwlFBOkGcdszWNrLqCKeQDYaRImon=[] 
  hUwlFBOkGcdszWNrLqCKeQDYaRImJf=hUwlFBOkGcdszWNrLqCKeQDYaRImiT
  try:
   if vType=='ALL':
    hUwlFBOkGcdszWNrLqCKeQDYaRImoX={'x-membersrl':hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['member_srl'],'x-pcid':hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['PCID'],'x-profileid':hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['profileId'],}
    hUwlFBOkGcdszWNrLqCKeQDYaRImoj={'platform':'WEBCLIENT','page':hUwlFBOkGcdszWNrLqCKeQDYaRImiE(page_int),'perPage':hUwlFBOkGcdszWNrLqCKeQDYaRImiE(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.PAGE_LIMIT),'locale':'ko','sort':'',}
    hUwlFBOkGcdszWNrLqCKeQDYaRImoi=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.API_VIEWURL+'/v1/discover/categories/'+hUwlFBOkGcdszWNrLqCKeQDYaRImoV+'/titles'
    hUwlFBOkGcdszWNrLqCKeQDYaRImot=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.callRequestCookies('Get',hUwlFBOkGcdszWNrLqCKeQDYaRImoi,payload=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,params=hUwlFBOkGcdszWNrLqCKeQDYaRImoj,headers=hUwlFBOkGcdszWNrLqCKeQDYaRImoX,cookies=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,redirects=hUwlFBOkGcdszWNrLqCKeQDYaRImig)
   else: 
    hUwlFBOkGcdszWNrLqCKeQDYaRImoj={'platform':'WEBCLIENT','page':hUwlFBOkGcdszWNrLqCKeQDYaRImiE(page_int),'perPage':hUwlFBOkGcdszWNrLqCKeQDYaRImiE(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.PAGE_LIMIT),}
    hUwlFBOkGcdszWNrLqCKeQDYaRImoi=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.API_VIEWURL+'/v1/discover/collections/'+hUwlFBOkGcdszWNrLqCKeQDYaRImoV+'/titles'
    hUwlFBOkGcdszWNrLqCKeQDYaRImot=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.callRequestCookies('Get',hUwlFBOkGcdszWNrLqCKeQDYaRImoi,payload=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,params=hUwlFBOkGcdszWNrLqCKeQDYaRImoj,headers=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,cookies=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,redirects=hUwlFBOkGcdszWNrLqCKeQDYaRImig)
   if hUwlFBOkGcdszWNrLqCKeQDYaRImot.status_code not in[200]:return[],hUwlFBOkGcdszWNrLqCKeQDYaRImiT
   hUwlFBOkGcdszWNrLqCKeQDYaRImob=json.loads(hUwlFBOkGcdszWNrLqCKeQDYaRImot.text)
   if vType=='ALL':
    hUwlFBOkGcdszWNrLqCKeQDYaRImJo=hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('data').get('data')
   else:
    hUwlFBOkGcdszWNrLqCKeQDYaRImJo=hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('data')
   for hUwlFBOkGcdszWNrLqCKeQDYaRImog in hUwlFBOkGcdszWNrLqCKeQDYaRImJo:
    hUwlFBOkGcdszWNrLqCKeQDYaRImJi=hUwlFBOkGcdszWNrLqCKeQDYaRImJM=hUwlFBOkGcdszWNrLqCKeQDYaRImiH=hUwlFBOkGcdszWNrLqCKeQDYaRImix=''
    if 'poster' in hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('images'):hUwlFBOkGcdszWNrLqCKeQDYaRImJi =hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('images'):hUwlFBOkGcdszWNrLqCKeQDYaRImJM =hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('images').get('story-art').get('url') +'?imwidth=600'
    if 'title-treatment' in hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('images'):hUwlFBOkGcdszWNrLqCKeQDYaRImiH=hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('images').get('title-treatment').get('url')+'?imwidth=300'
    if 'story-art' in hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('images'):hUwlFBOkGcdszWNrLqCKeQDYaRImix =hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('images').get('story-art').get('url') +'?imwidth=600'
    hUwlFBOkGcdszWNrLqCKeQDYaRImJt=''
    if hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('badge')not in[{},hUwlFBOkGcdszWNrLqCKeQDYaRImiP]:
     for i in hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('badge').get('text'):
      hUwlFBOkGcdszWNrLqCKeQDYaRImJt+=i.get('text')
    hUwlFBOkGcdszWNrLqCKeQDYaRImJv=''
    if hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('seasonList')!=hUwlFBOkGcdszWNrLqCKeQDYaRImiP:
     hUwlFBOkGcdszWNrLqCKeQDYaRImJv=','.join(hUwlFBOkGcdszWNrLqCKeQDYaRImiE(e)for e in hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('seasonList'))
    hUwlFBOkGcdszWNrLqCKeQDYaRImJx =[]
    for hUwlFBOkGcdszWNrLqCKeQDYaRImJH in hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('tags'):
     hUwlFBOkGcdszWNrLqCKeQDYaRImJx.append(hUwlFBOkGcdszWNrLqCKeQDYaRImJH.get('tag'))
    hUwlFBOkGcdszWNrLqCKeQDYaRImoy={'id':hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('id'),'title':hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('title'),'thumbnail':{'poster':hUwlFBOkGcdszWNrLqCKeQDYaRImJi,'thumb':hUwlFBOkGcdszWNrLqCKeQDYaRImJM,'clearlogo':hUwlFBOkGcdszWNrLqCKeQDYaRImiH,'fanart':hUwlFBOkGcdszWNrLqCKeQDYaRImix},'mpaa':hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('age_rating'),'duration':hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('running_time'),'asis':hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('as'),'badge':hUwlFBOkGcdszWNrLqCKeQDYaRImJt,'year':hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('meta').get('releaseYear'),'seasonList':hUwlFBOkGcdszWNrLqCKeQDYaRImJv,'genreList':hUwlFBOkGcdszWNrLqCKeQDYaRImJx,}
    hUwlFBOkGcdszWNrLqCKeQDYaRImon.append(hUwlFBOkGcdszWNrLqCKeQDYaRImoy)
   if hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('pagination').get('totalPages')>page_int:
    hUwlFBOkGcdszWNrLqCKeQDYaRImJf=hUwlFBOkGcdszWNrLqCKeQDYaRImig
  except hUwlFBOkGcdszWNrLqCKeQDYaRImiS as exception:
   hUwlFBOkGcdszWNrLqCKeQDYaRImip(exception)
   return[],hUwlFBOkGcdszWNrLqCKeQDYaRImiT
  return hUwlFBOkGcdszWNrLqCKeQDYaRImon,hUwlFBOkGcdszWNrLqCKeQDYaRImJf
 def Get_Episode_List(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ,programId,season):
  hUwlFBOkGcdszWNrLqCKeQDYaRImon=[] 
  try:
   hUwlFBOkGcdszWNrLqCKeQDYaRImoi=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.API_VIEWURL+'/v1/discover/titles/'+programId+'/episodes'
   hUwlFBOkGcdszWNrLqCKeQDYaRImoj={'season':season,'sort':'true','locale':'ko',}
   hUwlFBOkGcdszWNrLqCKeQDYaRImot=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.callRequestCookies('Get',hUwlFBOkGcdszWNrLqCKeQDYaRImoi,payload=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,params=hUwlFBOkGcdszWNrLqCKeQDYaRImoj,headers=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,cookies=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,redirects=hUwlFBOkGcdszWNrLqCKeQDYaRImig)
   if hUwlFBOkGcdszWNrLqCKeQDYaRImot.status_code not in[200]:return[]
   hUwlFBOkGcdszWNrLqCKeQDYaRImob=json.loads(hUwlFBOkGcdszWNrLqCKeQDYaRImot.text)
   for hUwlFBOkGcdszWNrLqCKeQDYaRImog in hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('data'):
    hUwlFBOkGcdszWNrLqCKeQDYaRImJM=''
    if 'story-art' in hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('images'):hUwlFBOkGcdszWNrLqCKeQDYaRImJM =hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('images').get('story-art').get('url')+'?imwidth=600'
    hUwlFBOkGcdszWNrLqCKeQDYaRImJx =[]
    for hUwlFBOkGcdszWNrLqCKeQDYaRImJH in hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('tags'):
     hUwlFBOkGcdszWNrLqCKeQDYaRImJx.append(hUwlFBOkGcdszWNrLqCKeQDYaRImJH.get('tag'))
    hUwlFBOkGcdszWNrLqCKeQDYaRImoy={'id':hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('id'),'title':hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('title'),'thumbnail':{'thumb':hUwlFBOkGcdszWNrLqCKeQDYaRImJM,'fanart':hUwlFBOkGcdszWNrLqCKeQDYaRImJM},'mpaa':hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('age_rating'),'duration':hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('running_time'),'asis':hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('as'),'year':hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('meta').get('releaseYear'),'episode':hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('episode'),'genreList':hUwlFBOkGcdszWNrLqCKeQDYaRImJx,'desc':hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('description'),}
    hUwlFBOkGcdszWNrLqCKeQDYaRImon.append(hUwlFBOkGcdszWNrLqCKeQDYaRImoy)
  except hUwlFBOkGcdszWNrLqCKeQDYaRImiS as exception:
   hUwlFBOkGcdszWNrLqCKeQDYaRImip(exception)
   return[]
  return hUwlFBOkGcdszWNrLqCKeQDYaRImon
 def Get_vInfo(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ,titleId):
  try:
   hUwlFBOkGcdszWNrLqCKeQDYaRImoi=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.API_VIEWURL+'/v1/discover/titles/'+titleId 
   hUwlFBOkGcdszWNrLqCKeQDYaRImoj={'platform':'WEBCLIENT','locale':'ko','filterRestrictedContent':'false',}
   hUwlFBOkGcdszWNrLqCKeQDYaRImot=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.callRequestCookies('Get',hUwlFBOkGcdszWNrLqCKeQDYaRImoi,payload=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,params=hUwlFBOkGcdszWNrLqCKeQDYaRImoj,headers=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,cookies=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,redirects=hUwlFBOkGcdszWNrLqCKeQDYaRImig)
   if hUwlFBOkGcdszWNrLqCKeQDYaRImot.status_code not in[200]:return '','',''
   hUwlFBOkGcdszWNrLqCKeQDYaRImob=json.loads(hUwlFBOkGcdszWNrLqCKeQDYaRImot.text).get('data')
   hUwlFBOkGcdszWNrLqCKeQDYaRImJv=''
   if hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('seasonList')!=hUwlFBOkGcdszWNrLqCKeQDYaRImiP:
    hUwlFBOkGcdszWNrLqCKeQDYaRImJv=','.join(hUwlFBOkGcdszWNrLqCKeQDYaRImiE(e)for e in hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('seasonList'))
   hUwlFBOkGcdszWNrLqCKeQDYaRImJX={'age_rating':hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('age_rating'),'asset_id':hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('asset_id'),'availability':hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('availability'),'deal_id':hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('deal_id'),'downloadable':'true' if hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('downloadable')else 'false','region':hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('region'),'streamable':'true' if hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('streamable')else 'false','asis':hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('as'),'seasonList':hUwlFBOkGcdszWNrLqCKeQDYaRImJv}
  except hUwlFBOkGcdszWNrLqCKeQDYaRImiS as exception:
   hUwlFBOkGcdszWNrLqCKeQDYaRImip(exception)
   return{}
  return hUwlFBOkGcdszWNrLqCKeQDYaRImJX
 def Get_eInfo(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ,eventId):
  try:
   hUwlFBOkGcdszWNrLqCKeQDYaRImoi=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.API_VIEWURL+'/v1/discover/events/'+eventId 
   hUwlFBOkGcdszWNrLqCKeQDYaRImoj={'locale':'ko'}
   hUwlFBOkGcdszWNrLqCKeQDYaRImot=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.callRequestCookies('Get',hUwlFBOkGcdszWNrLqCKeQDYaRImoi,payload=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,params=hUwlFBOkGcdszWNrLqCKeQDYaRImoj,headers=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,cookies=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,redirects=hUwlFBOkGcdszWNrLqCKeQDYaRImig)
   if hUwlFBOkGcdszWNrLqCKeQDYaRImot.status_code not in[200]:return '','',''
   hUwlFBOkGcdszWNrLqCKeQDYaRImob=json.loads(hUwlFBOkGcdszWNrLqCKeQDYaRImot.text).get('data')
   hUwlFBOkGcdszWNrLqCKeQDYaRImJX={'asset_id':hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('asset_id'),'deal_id':hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('deal_id'),'region':hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('region'),'streamable':'true' if hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('streamable')else 'false',}
  except hUwlFBOkGcdszWNrLqCKeQDYaRImiS as exception:
   hUwlFBOkGcdszWNrLqCKeQDYaRImip(exception)
   return{}
  return hUwlFBOkGcdszWNrLqCKeQDYaRImJX
 def GetBroadURL(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ,titleId):
  hUwlFBOkGcdszWNrLqCKeQDYaRImJA=''
  hUwlFBOkGcdszWNrLqCKeQDYaRImJb =''
  hUwlFBOkGcdszWNrLqCKeQDYaRImJX=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.Get_vInfo(titleId)
  if hUwlFBOkGcdszWNrLqCKeQDYaRImJX=={}:return '',''
  try:
   hUwlFBOkGcdszWNrLqCKeQDYaRImoi=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.API_DOMAIN+'/api/playback/play' 
   hUwlFBOkGcdszWNrLqCKeQDYaRImoj={'titleId':titleId}
   hUwlFBOkGcdszWNrLqCKeQDYaRImfS,hUwlFBOkGcdszWNrLqCKeQDYaRImfu,hUwlFBOkGcdszWNrLqCKeQDYaRImfg=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.Make_authHeader()
   hUwlFBOkGcdszWNrLqCKeQDYaRImoX={'traceparent':hUwlFBOkGcdszWNrLqCKeQDYaRImfS,'tracestate':hUwlFBOkGcdszWNrLqCKeQDYaRImfu,'newrelic':hUwlFBOkGcdszWNrLqCKeQDYaRImfg,'x-drm':'com.microsoft.playready','x-app-version':'1.33.5','x-device-id':'','x-device-os-version':hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.OS_VERSION,'x-force-raw':'true','x-nr-session-id':hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['session_web_id'],'x-pcid':hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['profileId'],'x-profileType':'standard','x-sessionid':hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.generatePvId(genType='1'),'x-title-age-rating':hUwlFBOkGcdszWNrLqCKeQDYaRImJX.get('age_rating'),'x-title-availability':hUwlFBOkGcdszWNrLqCKeQDYaRImJX.get('availability'),'x-title-brightcove-id':hUwlFBOkGcdszWNrLqCKeQDYaRImJX.get('asset_id'),'x-title-deal-id':hUwlFBOkGcdszWNrLqCKeQDYaRImJX.get('deal_id'),'x-title-downloadable':hUwlFBOkGcdszWNrLqCKeQDYaRImJX.get('downloadable'),'x-title-region':hUwlFBOkGcdszWNrLqCKeQDYaRImJX.get('region'),'x-title-streamable':hUwlFBOkGcdszWNrLqCKeQDYaRImJX.get('streamable'),}
   hUwlFBOkGcdszWNrLqCKeQDYaRImoJ=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.make_CP_DefaultCookies()
   hUwlFBOkGcdszWNrLqCKeQDYaRImot=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.callRequestCookies('Get',hUwlFBOkGcdszWNrLqCKeQDYaRImoi,payload=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,params=hUwlFBOkGcdszWNrLqCKeQDYaRImoj,headers=hUwlFBOkGcdszWNrLqCKeQDYaRImoX,cookies=hUwlFBOkGcdszWNrLqCKeQDYaRImoJ,redirects=hUwlFBOkGcdszWNrLqCKeQDYaRImig)
   if hUwlFBOkGcdszWNrLqCKeQDYaRImot.status_code not in[200]:return '',json.loads(hUwlFBOkGcdszWNrLqCKeQDYaRImot.text).get('error').get('detail')
   hUwlFBOkGcdszWNrLqCKeQDYaRImob=json.loads(hUwlFBOkGcdszWNrLqCKeQDYaRImot.text)
   if hUwlFBOkGcdszWNrLqCKeQDYaRImJA=='':
    for hUwlFBOkGcdszWNrLqCKeQDYaRImog in hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('data').get('raw').get('sources'):
     if 'key_systems' in hUwlFBOkGcdszWNrLqCKeQDYaRImog and 'codecs' not in hUwlFBOkGcdszWNrLqCKeQDYaRImog:
      if hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('type')=='application/dash+xml' and 'com.widevine.alpha' in hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('key_systems')and hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('src').startswith('https://')==hUwlFBOkGcdszWNrLqCKeQDYaRImig:
       hUwlFBOkGcdszWNrLqCKeQDYaRImJA=hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('src')
       hUwlFBOkGcdszWNrLqCKeQDYaRImJb =hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if hUwlFBOkGcdszWNrLqCKeQDYaRImJA=='':
    for hUwlFBOkGcdszWNrLqCKeQDYaRImog in hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('data').get('raw').get('sources'):
     if 'key_systems' in hUwlFBOkGcdszWNrLqCKeQDYaRImog and 'codecs' not in hUwlFBOkGcdszWNrLqCKeQDYaRImog:
      if hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('key_systems')and hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('src').startswith('https://')==hUwlFBOkGcdszWNrLqCKeQDYaRImig:
       hUwlFBOkGcdszWNrLqCKeQDYaRImJA=hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('src')
       hUwlFBOkGcdszWNrLqCKeQDYaRImJb =hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if hUwlFBOkGcdszWNrLqCKeQDYaRImJA=='':
    for hUwlFBOkGcdszWNrLqCKeQDYaRImog in hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('data').get('raw').get('sources'):
     if 'key_systems' in hUwlFBOkGcdszWNrLqCKeQDYaRImog and 'codecs' in hUwlFBOkGcdszWNrLqCKeQDYaRImog:
      if hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('type')=='application/dash+xml' and 'com.widevine.alpha' in hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('key_systems')and hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('src').startswith('https://')==hUwlFBOkGcdszWNrLqCKeQDYaRImig:
       hUwlFBOkGcdszWNrLqCKeQDYaRImJA=hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('src')
       hUwlFBOkGcdszWNrLqCKeQDYaRImJb =hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if hUwlFBOkGcdszWNrLqCKeQDYaRImJA=='':
    for hUwlFBOkGcdszWNrLqCKeQDYaRImog in hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('data').get('raw').get('sources'):
     if 'key_systems' in hUwlFBOkGcdszWNrLqCKeQDYaRImog and 'codecs' in hUwlFBOkGcdszWNrLqCKeQDYaRImog:
      if hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('key_systems')and hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('src').startswith('https://')==hUwlFBOkGcdszWNrLqCKeQDYaRImig:
       hUwlFBOkGcdszWNrLqCKeQDYaRImJA=hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('src')
       hUwlFBOkGcdszWNrLqCKeQDYaRImJb =hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
  except hUwlFBOkGcdszWNrLqCKeQDYaRImiS as exception:
   hUwlFBOkGcdszWNrLqCKeQDYaRImip(exception)
   return '',''
  return hUwlFBOkGcdszWNrLqCKeQDYaRImJA,hUwlFBOkGcdszWNrLqCKeQDYaRImJb
 def GetEventURL(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ,eventId,hUwlFBOkGcdszWNrLqCKeQDYaRImif):
  hUwlFBOkGcdszWNrLqCKeQDYaRImJA=''
  hUwlFBOkGcdszWNrLqCKeQDYaRImJb =''
  hUwlFBOkGcdszWNrLqCKeQDYaRImJX=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.Get_eInfo(eventId)
  if hUwlFBOkGcdszWNrLqCKeQDYaRImJX=={}:return '',''
  try:
   hUwlFBOkGcdszWNrLqCKeQDYaRImoi=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.API_DOMAIN+'/api/playback/play' 
   hUwlFBOkGcdszWNrLqCKeQDYaRImoj={'titleId':eventId,'titleType':hUwlFBOkGcdszWNrLqCKeQDYaRImif,}
   hUwlFBOkGcdszWNrLqCKeQDYaRImfS,hUwlFBOkGcdszWNrLqCKeQDYaRImfu,hUwlFBOkGcdszWNrLqCKeQDYaRImfg=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.Make_authHeader()
   hUwlFBOkGcdszWNrLqCKeQDYaRImoX={'traceparent':hUwlFBOkGcdszWNrLqCKeQDYaRImfS,'tracestate':hUwlFBOkGcdszWNrLqCKeQDYaRImfu,'newrelic':hUwlFBOkGcdszWNrLqCKeQDYaRImfg,'x-force-raw':'true','x-pcid':hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':hUwlFBOkGcdszWNrLqCKeQDYaRImJX.get('asset_id'),'x-title-deal-id':hUwlFBOkGcdszWNrLqCKeQDYaRImJX.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':hUwlFBOkGcdszWNrLqCKeQDYaRImJX.get('region'),'x-title-streamable':hUwlFBOkGcdszWNrLqCKeQDYaRImJX.get('streamable'),}
   hUwlFBOkGcdszWNrLqCKeQDYaRImoJ=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.make_CP_DefaultCookies()
   hUwlFBOkGcdszWNrLqCKeQDYaRImot=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.callRequestCookies('Get',hUwlFBOkGcdszWNrLqCKeQDYaRImoi,payload=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,params=hUwlFBOkGcdszWNrLqCKeQDYaRImoj,headers=hUwlFBOkGcdszWNrLqCKeQDYaRImoX,cookies=hUwlFBOkGcdszWNrLqCKeQDYaRImoJ,redirects=hUwlFBOkGcdszWNrLqCKeQDYaRImig)
   if hUwlFBOkGcdszWNrLqCKeQDYaRImot.status_code not in[200]:return '',json.loads(hUwlFBOkGcdszWNrLqCKeQDYaRImot.text).get('error').get('detail')
   hUwlFBOkGcdszWNrLqCKeQDYaRImob=json.loads(hUwlFBOkGcdszWNrLqCKeQDYaRImot.text)
   for hUwlFBOkGcdszWNrLqCKeQDYaRImog in hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('data').get('raw').get('sources'):
    if hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('type')=='application/dash+xml' and hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('src')[0:8]=='https://':
     hUwlFBOkGcdszWNrLqCKeQDYaRImJA=hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('src')
     if 'key_systems' in hUwlFBOkGcdszWNrLqCKeQDYaRImog:
      hUwlFBOkGcdszWNrLqCKeQDYaRImJb =hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('key_systems').get('com.widevine.alpha').get('license_url')
     break
  except hUwlFBOkGcdszWNrLqCKeQDYaRImiS as exception:
   hUwlFBOkGcdszWNrLqCKeQDYaRImip(exception)
   return '',''
  return hUwlFBOkGcdszWNrLqCKeQDYaRImJA,hUwlFBOkGcdszWNrLqCKeQDYaRImJb
 def GetEventURL_Live(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ,eventId,hUwlFBOkGcdszWNrLqCKeQDYaRImif):
  hUwlFBOkGcdszWNrLqCKeQDYaRImJA=''
  hUwlFBOkGcdszWNrLqCKeQDYaRImJb =''
  hUwlFBOkGcdszWNrLqCKeQDYaRImJX=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.Get_eInfo(eventId)
  if hUwlFBOkGcdszWNrLqCKeQDYaRImJX=={}:return '',''
  try:
   hUwlFBOkGcdszWNrLqCKeQDYaRImoi=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.API_DOMAIN+'/api/playback/play' 
   hUwlFBOkGcdszWNrLqCKeQDYaRImoj={'titleId':eventId,'titleType':hUwlFBOkGcdszWNrLqCKeQDYaRImif,}
   hUwlFBOkGcdszWNrLqCKeQDYaRImfS,hUwlFBOkGcdszWNrLqCKeQDYaRImfu,hUwlFBOkGcdszWNrLqCKeQDYaRImfg=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.Make_authHeader()
   hUwlFBOkGcdszWNrLqCKeQDYaRImoX={'traceparent':hUwlFBOkGcdszWNrLqCKeQDYaRImfS,'tracestate':hUwlFBOkGcdszWNrLqCKeQDYaRImfu,'newrelic':hUwlFBOkGcdszWNrLqCKeQDYaRImfg,'x-force-raw':'true','x-pcid':hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':hUwlFBOkGcdszWNrLqCKeQDYaRImJX.get('asset_id'),'x-title-deal-id':hUwlFBOkGcdszWNrLqCKeQDYaRImJX.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':hUwlFBOkGcdszWNrLqCKeQDYaRImJX.get('region'),'x-title-streamable':hUwlFBOkGcdszWNrLqCKeQDYaRImJX.get('streamable'),}
   hUwlFBOkGcdszWNrLqCKeQDYaRImoJ=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.make_CP_DefaultCookies()
   hUwlFBOkGcdszWNrLqCKeQDYaRImot=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.callRequestCookies('Get',hUwlFBOkGcdszWNrLqCKeQDYaRImoi,payload=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,params=hUwlFBOkGcdszWNrLqCKeQDYaRImoj,headers=hUwlFBOkGcdszWNrLqCKeQDYaRImoX,cookies=hUwlFBOkGcdszWNrLqCKeQDYaRImoJ,redirects=hUwlFBOkGcdszWNrLqCKeQDYaRImig)
   if hUwlFBOkGcdszWNrLqCKeQDYaRImot.status_code not in[200]:return '',json.loads(hUwlFBOkGcdszWNrLqCKeQDYaRImot.text).get('error').get('detail')
   hUwlFBOkGcdszWNrLqCKeQDYaRImob=json.loads(hUwlFBOkGcdszWNrLqCKeQDYaRImot.text)
   if hUwlFBOkGcdszWNrLqCKeQDYaRImJA=='':
    for hUwlFBOkGcdszWNrLqCKeQDYaRImog in hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('data').get('raw').get('sources'):
     if 'key_systems' in hUwlFBOkGcdszWNrLqCKeQDYaRImog:
      if hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('type')=='application/dash+xml' and 'com.widevine.alpha' in hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('key_systems')and hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('src').startswith('https://')==hUwlFBOkGcdszWNrLqCKeQDYaRImig:
       hUwlFBOkGcdszWNrLqCKeQDYaRImJA=hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('src')
       hUwlFBOkGcdszWNrLqCKeQDYaRImJb =hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('key_systems').get('com.widevine.alpha').get('license_url')
   if hUwlFBOkGcdszWNrLqCKeQDYaRImJA=='':
    for hUwlFBOkGcdszWNrLqCKeQDYaRImog in hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('data').get('raw').get('sources'):
     if 'key_systems' in hUwlFBOkGcdszWNrLqCKeQDYaRImog:
      if hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('key_systems')and hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('src').startswith('https://')==hUwlFBOkGcdszWNrLqCKeQDYaRImig:
       hUwlFBOkGcdszWNrLqCKeQDYaRImJA=hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('src')
       hUwlFBOkGcdszWNrLqCKeQDYaRImJb =hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('key_systems').get('com.widevine.alpha').get('license_url')
   if hUwlFBOkGcdszWNrLqCKeQDYaRImJA=='':
    for hUwlFBOkGcdszWNrLqCKeQDYaRImog in hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('data').get('raw').get('sources'):
     if hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('type')=='application/dash+xml' and hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('src').startswith('https://')==hUwlFBOkGcdszWNrLqCKeQDYaRImig:
      hUwlFBOkGcdszWNrLqCKeQDYaRImJA=hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('src')
   if hUwlFBOkGcdszWNrLqCKeQDYaRImJA=='':
    for hUwlFBOkGcdszWNrLqCKeQDYaRImog in hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('data').get('raw').get('sources'):
     if hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('type')=='application/x-mpegURL' and hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('src').startswith('https://')==hUwlFBOkGcdszWNrLqCKeQDYaRImig:
      hUwlFBOkGcdszWNrLqCKeQDYaRImJA=hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('src')
  except hUwlFBOkGcdszWNrLqCKeQDYaRImiS as exception:
   hUwlFBOkGcdszWNrLqCKeQDYaRImip(exception)
   return '',''
  return hUwlFBOkGcdszWNrLqCKeQDYaRImJA,hUwlFBOkGcdszWNrLqCKeQDYaRImJb
 def Get_Url_PostFix(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ,in_url):
  hUwlFBOkGcdszWNrLqCKeQDYaRImJP=urllib.parse.urlparse(in_url) 
  hUwlFBOkGcdszWNrLqCKeQDYaRImJT =hUwlFBOkGcdszWNrLqCKeQDYaRImJP.path.strip('/').split('/')
  hUwlFBOkGcdszWNrLqCKeQDYaRImJp =hUwlFBOkGcdszWNrLqCKeQDYaRImJT[hUwlFBOkGcdszWNrLqCKeQDYaRImiV(hUwlFBOkGcdszWNrLqCKeQDYaRImJT)-1]
  hUwlFBOkGcdszWNrLqCKeQDYaRImJE=hUwlFBOkGcdszWNrLqCKeQDYaRImJp.split('.')
  return hUwlFBOkGcdszWNrLqCKeQDYaRImJE[hUwlFBOkGcdszWNrLqCKeQDYaRImiV(hUwlFBOkGcdszWNrLqCKeQDYaRImJE)-1]
 def Get_Theme_GroupList(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ,vType):
  hUwlFBOkGcdszWNrLqCKeQDYaRImon=[] 
  try:
   hUwlFBOkGcdszWNrLqCKeQDYaRImoi=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.API_VIEWURL+'/v2/discover/feed' 
   hUwlFBOkGcdszWNrLqCKeQDYaRImoj={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':hUwlFBOkGcdszWNrLqCKeQDYaRImiE(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.PAGE_LIMIT),'filterRestrictedContent':'false',}
   hUwlFBOkGcdszWNrLqCKeQDYaRImot=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.callRequestCookies('Get',hUwlFBOkGcdszWNrLqCKeQDYaRImoi,payload=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,params=hUwlFBOkGcdszWNrLqCKeQDYaRImoj,headers=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,cookies=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,redirects=hUwlFBOkGcdszWNrLqCKeQDYaRImig)
   if hUwlFBOkGcdszWNrLqCKeQDYaRImot.status_code not in[200]:return[]
   hUwlFBOkGcdszWNrLqCKeQDYaRImob=json.loads(hUwlFBOkGcdszWNrLqCKeQDYaRImot.text)
   for hUwlFBOkGcdszWNrLqCKeQDYaRImog in hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('data'):
    if hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('type')=='Title-Rails-Curation':
     hUwlFBOkGcdszWNrLqCKeQDYaRImJn =''
     hUwlFBOkGcdszWNrLqCKeQDYaRImJj=7
     try:
      for i in hUwlFBOkGcdszWNrLqCKeQDYaRImiy(hUwlFBOkGcdszWNrLqCKeQDYaRImiV(hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('data'))):
       if i>=hUwlFBOkGcdszWNrLqCKeQDYaRImJj:
        hUwlFBOkGcdszWNrLqCKeQDYaRImJn=hUwlFBOkGcdszWNrLqCKeQDYaRImJn+'...'
        break
       hUwlFBOkGcdszWNrLqCKeQDYaRImJn=hUwlFBOkGcdszWNrLqCKeQDYaRImJn+hUwlFBOkGcdszWNrLqCKeQDYaRImog['data'][i]['title']+'\n'
     except hUwlFBOkGcdszWNrLqCKeQDYaRImiS as exception:
      hUwlFBOkGcdszWNrLqCKeQDYaRImip(exception)
     hUwlFBOkGcdszWNrLqCKeQDYaRImoy={'collectionId':hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('obj_id'),'title':hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('row_name'),'category':hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('category'),'pre_title':hUwlFBOkGcdszWNrLqCKeQDYaRImJn,}
     hUwlFBOkGcdszWNrLqCKeQDYaRImon.append(hUwlFBOkGcdszWNrLqCKeQDYaRImoy)
  except hUwlFBOkGcdszWNrLqCKeQDYaRImiS as exception:
   hUwlFBOkGcdszWNrLqCKeQDYaRImip(exception)
   return[]
  return hUwlFBOkGcdszWNrLqCKeQDYaRImon
 def Get_Event_GroupList(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ):
  hUwlFBOkGcdszWNrLqCKeQDYaRImon=[] 
  try:
   hUwlFBOkGcdszWNrLqCKeQDYaRImoi=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.API_VIEWURL+'/v2/discover/feed' 
   hUwlFBOkGcdszWNrLqCKeQDYaRImoj={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':7,'filterRestrictedContent':'false',}
   hUwlFBOkGcdszWNrLqCKeQDYaRImot=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.callRequestCookies('Get',hUwlFBOkGcdszWNrLqCKeQDYaRImoi,payload=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,params=hUwlFBOkGcdszWNrLqCKeQDYaRImoj,headers=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,cookies=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,redirects=hUwlFBOkGcdszWNrLqCKeQDYaRImig)
   if hUwlFBOkGcdszWNrLqCKeQDYaRImot.status_code not in[200]:return[]
   hUwlFBOkGcdszWNrLqCKeQDYaRImob=json.loads(hUwlFBOkGcdszWNrLqCKeQDYaRImot.text)
   for hUwlFBOkGcdszWNrLqCKeQDYaRImog in hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('data'):
    if hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('row_name').strip()!='':
     hUwlFBOkGcdszWNrLqCKeQDYaRImJn =''
     hUwlFBOkGcdszWNrLqCKeQDYaRImJj=7
     try:
      for i in hUwlFBOkGcdszWNrLqCKeQDYaRImiy(hUwlFBOkGcdszWNrLqCKeQDYaRImiV(hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('data'))):
       if i>=hUwlFBOkGcdszWNrLqCKeQDYaRImJj:
        hUwlFBOkGcdszWNrLqCKeQDYaRImJn=hUwlFBOkGcdszWNrLqCKeQDYaRImJn+'...'
        break
       hUwlFBOkGcdszWNrLqCKeQDYaRImJn=hUwlFBOkGcdszWNrLqCKeQDYaRImJn+hUwlFBOkGcdszWNrLqCKeQDYaRImog['data'][i]['title']+'\n'
     except hUwlFBOkGcdszWNrLqCKeQDYaRImiS as exception:
      hUwlFBOkGcdszWNrLqCKeQDYaRImip(exception)
     hUwlFBOkGcdszWNrLqCKeQDYaRImoy={'collectionId':hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('obj_id'),'title':hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('row_name'),'category':hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('type'),'pre_title':hUwlFBOkGcdszWNrLqCKeQDYaRImJn,}
     hUwlFBOkGcdszWNrLqCKeQDYaRImon.append(hUwlFBOkGcdszWNrLqCKeQDYaRImoy)
  except hUwlFBOkGcdszWNrLqCKeQDYaRImiS as exception:
   hUwlFBOkGcdszWNrLqCKeQDYaRImip(exception)
   return[]
  return hUwlFBOkGcdszWNrLqCKeQDYaRImon
 def Get_Event_GameList(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ,hUwlFBOkGcdszWNrLqCKeQDYaRImoV):
  hUwlFBOkGcdszWNrLqCKeQDYaRImon=[] 
  try:
   hUwlFBOkGcdszWNrLqCKeQDYaRImoi=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.API_VIEWURL+'/v2/discover/feed' 
   hUwlFBOkGcdszWNrLqCKeQDYaRImoj={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false',}
   hUwlFBOkGcdszWNrLqCKeQDYaRImot=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.callRequestCookies('Get',hUwlFBOkGcdszWNrLqCKeQDYaRImoi,payload=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,params=hUwlFBOkGcdszWNrLqCKeQDYaRImoj,headers=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,cookies=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,redirects=hUwlFBOkGcdszWNrLqCKeQDYaRImig)
   if hUwlFBOkGcdszWNrLqCKeQDYaRImot.status_code not in[200]:return[]
   hUwlFBOkGcdszWNrLqCKeQDYaRImob=json.loads(hUwlFBOkGcdszWNrLqCKeQDYaRImot.text)
   for hUwlFBOkGcdszWNrLqCKeQDYaRImog in hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('data'):
    if hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('obj_id')==hUwlFBOkGcdszWNrLqCKeQDYaRImoV:
     for hUwlFBOkGcdszWNrLqCKeQDYaRImJS in hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('data'):
      hUwlFBOkGcdszWNrLqCKeQDYaRImJi=hUwlFBOkGcdszWNrLqCKeQDYaRImJM=hUwlFBOkGcdszWNrLqCKeQDYaRImix=''
      if 'poster' in hUwlFBOkGcdszWNrLqCKeQDYaRImJS.get('images'):hUwlFBOkGcdszWNrLqCKeQDYaRImJi =hUwlFBOkGcdszWNrLqCKeQDYaRImJS.get('images').get('poster').get('url') +'?imwidth=350'
      if 'story-art' in hUwlFBOkGcdszWNrLqCKeQDYaRImJS.get('images'):hUwlFBOkGcdszWNrLqCKeQDYaRImJM =hUwlFBOkGcdszWNrLqCKeQDYaRImJS.get('images').get('story-art').get('url')+'?imwidth=600'
      if 'hero' in hUwlFBOkGcdszWNrLqCKeQDYaRImJS.get('images'):hUwlFBOkGcdszWNrLqCKeQDYaRImix =hUwlFBOkGcdszWNrLqCKeQDYaRImJS.get('images').get('hero').get('url') +'?imwidth=600'
      hUwlFBOkGcdszWNrLqCKeQDYaRImJu=hUwlFBOkGcdszWNrLqCKeQDYaRImJS.get('meta').get(hUwlFBOkGcdszWNrLqCKeQDYaRImJS.get('category')).get(hUwlFBOkGcdszWNrLqCKeQDYaRImJS.get('sub_category'))
      if 'league' in hUwlFBOkGcdszWNrLqCKeQDYaRImJu:
       hUwlFBOkGcdszWNrLqCKeQDYaRImJg=hUwlFBOkGcdszWNrLqCKeQDYaRImJu.get('league')
      else:
       hUwlFBOkGcdszWNrLqCKeQDYaRImJg=hUwlFBOkGcdszWNrLqCKeQDYaRImJu.get('round')
      hUwlFBOkGcdszWNrLqCKeQDYaRImoy={'id':hUwlFBOkGcdszWNrLqCKeQDYaRImJS.get('id'),'title':hUwlFBOkGcdszWNrLqCKeQDYaRImJS.get('title'),'thumbnail':{'poster':hUwlFBOkGcdszWNrLqCKeQDYaRImJi,'thumb':hUwlFBOkGcdszWNrLqCKeQDYaRImJM,'fanart':hUwlFBOkGcdszWNrLqCKeQDYaRImix},'asis':hUwlFBOkGcdszWNrLqCKeQDYaRImJS.get('type'),'addInfo':hUwlFBOkGcdszWNrLqCKeQDYaRImJg,'starttm':hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.convert_TimeStr(hUwlFBOkGcdszWNrLqCKeQDYaRImJS.get('start_at')),}
      hUwlFBOkGcdszWNrLqCKeQDYaRImon.append(hUwlFBOkGcdszWNrLqCKeQDYaRImoy)
  except hUwlFBOkGcdszWNrLqCKeQDYaRImiS as exception:
   hUwlFBOkGcdszWNrLqCKeQDYaRImip(exception)
   return[]
  return hUwlFBOkGcdszWNrLqCKeQDYaRImon
 def Get_Event_List(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ,gameId):
  hUwlFBOkGcdszWNrLqCKeQDYaRImon=[] 
  try:
   hUwlFBOkGcdszWNrLqCKeQDYaRImoi=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.API_VIEWURL+'/v1/discover/events/'+gameId 
   hUwlFBOkGcdszWNrLqCKeQDYaRImoj={'platform':'WEBCLIENT','locale':'ko','filterRestrictedContent':'false',}
   hUwlFBOkGcdszWNrLqCKeQDYaRImot=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.callRequestCookies('Get',hUwlFBOkGcdszWNrLqCKeQDYaRImoi,payload=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,params=hUwlFBOkGcdszWNrLqCKeQDYaRImoj,headers=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,cookies=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,redirects=hUwlFBOkGcdszWNrLqCKeQDYaRImig)
   if hUwlFBOkGcdszWNrLqCKeQDYaRImot.status_code not in[200]:return[]
   hUwlFBOkGcdszWNrLqCKeQDYaRImob=json.loads(hUwlFBOkGcdszWNrLqCKeQDYaRImot.text)
   hUwlFBOkGcdszWNrLqCKeQDYaRImog=hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('data')
   hUwlFBOkGcdszWNrLqCKeQDYaRImJV=hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('end_at')
   hUwlFBOkGcdszWNrLqCKeQDYaRImJV=hUwlFBOkGcdszWNrLqCKeQDYaRImJV[0:19].replace('-','').replace(':','').replace('T','')
   hUwlFBOkGcdszWNrLqCKeQDYaRImJy=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d%H%M%S')
   if hUwlFBOkGcdszWNrLqCKeQDYaRImij(hUwlFBOkGcdszWNrLqCKeQDYaRImJy)<hUwlFBOkGcdszWNrLqCKeQDYaRImij(hUwlFBOkGcdszWNrLqCKeQDYaRImJV):
    hUwlFBOkGcdszWNrLqCKeQDYaRImJi=hUwlFBOkGcdszWNrLqCKeQDYaRImJM=hUwlFBOkGcdszWNrLqCKeQDYaRImix=''
    if 'poster' in hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('images'):hUwlFBOkGcdszWNrLqCKeQDYaRImJi =hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('images'):hUwlFBOkGcdszWNrLqCKeQDYaRImJM =hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('images').get('story-art').get('url')+'?imwidth=600'
    if 'story-art' in hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('images'):hUwlFBOkGcdszWNrLqCKeQDYaRImix =hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('images').get('story-art').get('url')+'?imwidth=600'
    hUwlFBOkGcdszWNrLqCKeQDYaRImoy={'id':hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('id'),'title':hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('title'),'thumbnail':{'poster':hUwlFBOkGcdszWNrLqCKeQDYaRImJi,'thumb':hUwlFBOkGcdszWNrLqCKeQDYaRImJM,'fanart':hUwlFBOkGcdszWNrLqCKeQDYaRImix},'duration':hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('running_time'),'asis':hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('type'),'starttm':hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.convert_TimeStr(hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('start_at')),}
    hUwlFBOkGcdszWNrLqCKeQDYaRImon.append(hUwlFBOkGcdszWNrLqCKeQDYaRImoy)
  except hUwlFBOkGcdszWNrLqCKeQDYaRImiS as exception:
   hUwlFBOkGcdszWNrLqCKeQDYaRImip(exception)
   return[]
  try:
   hUwlFBOkGcdszWNrLqCKeQDYaRImoi=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.API_VIEWURL+'/v1/discover/events/'+gameId+'/related' 
   hUwlFBOkGcdszWNrLqCKeQDYaRImoj={'locale':'ko','page':'1','perPage':'25','platform':'WEBCLIENT','currentPageTracking':'page_discover_title_detail',}
   hUwlFBOkGcdszWNrLqCKeQDYaRImot=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.callRequestCookies('Get',hUwlFBOkGcdszWNrLqCKeQDYaRImoi,payload=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,params=hUwlFBOkGcdszWNrLqCKeQDYaRImoj,headers=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,cookies=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,redirects=hUwlFBOkGcdszWNrLqCKeQDYaRImig)
   if hUwlFBOkGcdszWNrLqCKeQDYaRImot.status_code not in[200]:return[]
   hUwlFBOkGcdszWNrLqCKeQDYaRImob=json.loads(hUwlFBOkGcdszWNrLqCKeQDYaRImot.text)
   for hUwlFBOkGcdszWNrLqCKeQDYaRImog in hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('data').get('data'):
    hUwlFBOkGcdszWNrLqCKeQDYaRImJi=hUwlFBOkGcdszWNrLqCKeQDYaRImJM=hUwlFBOkGcdszWNrLqCKeQDYaRImix=''
    if 'poster' in hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('images'):hUwlFBOkGcdszWNrLqCKeQDYaRImJi =hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('images'):hUwlFBOkGcdszWNrLqCKeQDYaRImJM =hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('images').get('story-art').get('url')+'?imwidth=600'
    if 'story-art' in hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('images'):hUwlFBOkGcdszWNrLqCKeQDYaRImix =hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('images').get('story-art').get('url')+'?imwidth=600'
    hUwlFBOkGcdszWNrLqCKeQDYaRImoy={'id':hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('id'),'title':hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('title'),'thumbnail':{'poster':hUwlFBOkGcdszWNrLqCKeQDYaRImJi,'thumb':hUwlFBOkGcdszWNrLqCKeQDYaRImJM,'fanart':hUwlFBOkGcdszWNrLqCKeQDYaRImix},'duration':hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('running_time'),'asis':hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('type'),}
    hUwlFBOkGcdszWNrLqCKeQDYaRImon.append(hUwlFBOkGcdszWNrLqCKeQDYaRImoy)
  except hUwlFBOkGcdszWNrLqCKeQDYaRImiS as exception:
   hUwlFBOkGcdszWNrLqCKeQDYaRImip(exception)
   return[]
  return hUwlFBOkGcdszWNrLqCKeQDYaRImon
 def Get_Search_List(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ,search_key,page_int):
  hUwlFBOkGcdszWNrLqCKeQDYaRImon=[] 
  hUwlFBOkGcdszWNrLqCKeQDYaRImJf=hUwlFBOkGcdszWNrLqCKeQDYaRImiT
  try:
   hUwlFBOkGcdszWNrLqCKeQDYaRImoi=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.API_VIEWURL+'/v2/search' 
   hUwlFBOkGcdszWNrLqCKeQDYaRImoj={'query':search_key,'platform':'WEBCLIENT','page':hUwlFBOkGcdszWNrLqCKeQDYaRImiE(page_int),'perPage':hUwlFBOkGcdszWNrLqCKeQDYaRImiE(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.SEARCH_LIMIT),}
   hUwlFBOkGcdszWNrLqCKeQDYaRImoX={'x-membersrl':hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['member_srl'],'x-pcid':hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['PCID'],'x-profileid':hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.CP['SESSION']['profileId'],}
   hUwlFBOkGcdszWNrLqCKeQDYaRImot=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.callRequestCookies('Get',hUwlFBOkGcdszWNrLqCKeQDYaRImoi,payload=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,params=hUwlFBOkGcdszWNrLqCKeQDYaRImoj,headers=hUwlFBOkGcdszWNrLqCKeQDYaRImoX,cookies=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,redirects=hUwlFBOkGcdszWNrLqCKeQDYaRImig)
   if hUwlFBOkGcdszWNrLqCKeQDYaRImot.status_code not in[200]:return[],hUwlFBOkGcdszWNrLqCKeQDYaRImiT
   hUwlFBOkGcdszWNrLqCKeQDYaRImob=json.loads(hUwlFBOkGcdszWNrLqCKeQDYaRImot.text)
   for hUwlFBOkGcdszWNrLqCKeQDYaRImog in hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('data').get('data'):
    hUwlFBOkGcdszWNrLqCKeQDYaRImog=hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('data')
    hUwlFBOkGcdszWNrLqCKeQDYaRImJi=hUwlFBOkGcdszWNrLqCKeQDYaRImJM=hUwlFBOkGcdszWNrLqCKeQDYaRImiH=hUwlFBOkGcdszWNrLqCKeQDYaRImix=''
    if 'poster' in hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('images'):hUwlFBOkGcdszWNrLqCKeQDYaRImJi =hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('images'):hUwlFBOkGcdszWNrLqCKeQDYaRImJM =hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('images').get('story-art').get('url') +'?imwidth=600'
    if 'title-treatment' in hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('images'):hUwlFBOkGcdszWNrLqCKeQDYaRImiH=hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('images').get('title-treatment').get('url')+'?imwidth=300'
    if 'story-art' in hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('images'):hUwlFBOkGcdszWNrLqCKeQDYaRImix =hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('images').get('story-art').get('url') +'?imwidth=600'
    hUwlFBOkGcdszWNrLqCKeQDYaRImJt=''
    if hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('badge')not in[{},hUwlFBOkGcdszWNrLqCKeQDYaRImiP]:
     for i in hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('badge').get('text'):
      if hUwlFBOkGcdszWNrLqCKeQDYaRImJt!='':hUwlFBOkGcdszWNrLqCKeQDYaRImJt+=' '
      hUwlFBOkGcdszWNrLqCKeQDYaRImJt+=i.get('text')
    if 'as' in hUwlFBOkGcdszWNrLqCKeQDYaRImog:
     hUwlFBOkGcdszWNrLqCKeQDYaRImif=hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('as') 
    else:
     hUwlFBOkGcdszWNrLqCKeQDYaRImif=hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('type')
    hUwlFBOkGcdszWNrLqCKeQDYaRImoy={'id':hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('id'),'title':hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('title'),'asis':hUwlFBOkGcdszWNrLqCKeQDYaRImif,'thumbnail':{'poster':hUwlFBOkGcdszWNrLqCKeQDYaRImJi,'thumb':hUwlFBOkGcdszWNrLqCKeQDYaRImJM,'clearlogo':hUwlFBOkGcdszWNrLqCKeQDYaRImiH,'fanart':hUwlFBOkGcdszWNrLqCKeQDYaRImix},'mpaa':hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('age_rating'),'duration':hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('running_time'),'badge':hUwlFBOkGcdszWNrLqCKeQDYaRImJt,'year':hUwlFBOkGcdszWNrLqCKeQDYaRImog.get('meta').get('releaseYear'),}
    hUwlFBOkGcdszWNrLqCKeQDYaRImon.append(hUwlFBOkGcdszWNrLqCKeQDYaRImoy)
   if hUwlFBOkGcdszWNrLqCKeQDYaRImob.get('pagination').get('totalPages')>page_int:
    hUwlFBOkGcdszWNrLqCKeQDYaRImJf=hUwlFBOkGcdszWNrLqCKeQDYaRImig
  except hUwlFBOkGcdszWNrLqCKeQDYaRImiS as exception:
   hUwlFBOkGcdszWNrLqCKeQDYaRImip(exception)
   return[],hUwlFBOkGcdszWNrLqCKeQDYaRImiT
  return hUwlFBOkGcdszWNrLqCKeQDYaRImon,hUwlFBOkGcdszWNrLqCKeQDYaRImJf
 def GetBookmarkInfo(hUwlFBOkGcdszWNrLqCKeQDYaRImfJ,videoid,vidtype):
  hUwlFBOkGcdszWNrLqCKeQDYaRImio={'indexinfo':{'ott':'coupang','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  hUwlFBOkGcdszWNrLqCKeQDYaRImoi=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.API_VIEWURL+'/v1/discover/titles/'+videoid 
  hUwlFBOkGcdszWNrLqCKeQDYaRImoj={'locale':'ko'}
  hUwlFBOkGcdszWNrLqCKeQDYaRImot=hUwlFBOkGcdszWNrLqCKeQDYaRImfJ.callRequestCookies('Get',hUwlFBOkGcdszWNrLqCKeQDYaRImoi,payload=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,params=hUwlFBOkGcdszWNrLqCKeQDYaRImoj,headers=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,cookies=hUwlFBOkGcdszWNrLqCKeQDYaRImiP,redirects=hUwlFBOkGcdszWNrLqCKeQDYaRImig)
  if hUwlFBOkGcdszWNrLqCKeQDYaRImot.status_code not in[200]:return{}
  hUwlFBOkGcdszWNrLqCKeQDYaRImiJ=json.loads(hUwlFBOkGcdszWNrLqCKeQDYaRImot.text).get('data')
  hUwlFBOkGcdszWNrLqCKeQDYaRImit=hUwlFBOkGcdszWNrLqCKeQDYaRImiJ.get('title')
  hUwlFBOkGcdszWNrLqCKeQDYaRImiv =hUwlFBOkGcdszWNrLqCKeQDYaRImiJ.get('meta').get('releaseYear')
  hUwlFBOkGcdszWNrLqCKeQDYaRImio['saveinfo']['infoLabels']['title']=hUwlFBOkGcdszWNrLqCKeQDYaRImit
  if vidtype=='movie':
   hUwlFBOkGcdszWNrLqCKeQDYaRImit='%s  (%s)'%(hUwlFBOkGcdszWNrLqCKeQDYaRImit,hUwlFBOkGcdszWNrLqCKeQDYaRImiv)
  hUwlFBOkGcdszWNrLqCKeQDYaRImio['saveinfo']['title'] =hUwlFBOkGcdszWNrLqCKeQDYaRImit
  hUwlFBOkGcdszWNrLqCKeQDYaRImio['saveinfo']['infoLabels']['mpaa'] =hUwlFBOkGcdszWNrLqCKeQDYaRImiJ.get('age_rating')
  hUwlFBOkGcdszWNrLqCKeQDYaRImio['saveinfo']['infoLabels']['plot'] ='%s\n\n%s'%(hUwlFBOkGcdszWNrLqCKeQDYaRImiJ.get('short_description'),hUwlFBOkGcdszWNrLqCKeQDYaRImiJ.get('description'))
  hUwlFBOkGcdszWNrLqCKeQDYaRImio['saveinfo']['infoLabels']['year'] =hUwlFBOkGcdszWNrLqCKeQDYaRImiv
  if vidtype=='movie':
   hUwlFBOkGcdszWNrLqCKeQDYaRImio['saveinfo']['infoLabels']['duration']=hUwlFBOkGcdszWNrLqCKeQDYaRImiJ.get('running_time')
  hUwlFBOkGcdszWNrLqCKeQDYaRImJi =''
  hUwlFBOkGcdszWNrLqCKeQDYaRImix =''
  hUwlFBOkGcdszWNrLqCKeQDYaRImJM =''
  hUwlFBOkGcdszWNrLqCKeQDYaRImiH=''
  if hUwlFBOkGcdszWNrLqCKeQDYaRImiJ.get('images').get('poster') !=hUwlFBOkGcdszWNrLqCKeQDYaRImiP:hUwlFBOkGcdszWNrLqCKeQDYaRImJi =hUwlFBOkGcdszWNrLqCKeQDYaRImiJ.get('images').get('poster').get('url') +'?imwidth=350'
  if hUwlFBOkGcdszWNrLqCKeQDYaRImiJ.get('images').get('background') !=hUwlFBOkGcdszWNrLqCKeQDYaRImiP:hUwlFBOkGcdszWNrLqCKeQDYaRImix =hUwlFBOkGcdszWNrLqCKeQDYaRImiJ.get('images').get('background').get('url') +'?imwidth=600'
  if hUwlFBOkGcdszWNrLqCKeQDYaRImiJ.get('images').get('story-art') !=hUwlFBOkGcdszWNrLqCKeQDYaRImiP:hUwlFBOkGcdszWNrLqCKeQDYaRImJM =hUwlFBOkGcdszWNrLqCKeQDYaRImiJ.get('images').get('story-art').get('url') +'?imwidth=600'
  if hUwlFBOkGcdszWNrLqCKeQDYaRImiJ.get('images').get('title-treatment')!=hUwlFBOkGcdszWNrLqCKeQDYaRImiP:hUwlFBOkGcdszWNrLqCKeQDYaRImiH=hUwlFBOkGcdszWNrLqCKeQDYaRImiJ.get('images').get('title-treatment').get('url')+'?imwidth=300'
  if hUwlFBOkGcdszWNrLqCKeQDYaRImix=='':hUwlFBOkGcdszWNrLqCKeQDYaRImix=hUwlFBOkGcdszWNrLqCKeQDYaRImJM
  hUwlFBOkGcdszWNrLqCKeQDYaRImio['saveinfo']['thumbnail']['poster']=hUwlFBOkGcdszWNrLqCKeQDYaRImJi
  hUwlFBOkGcdszWNrLqCKeQDYaRImio['saveinfo']['thumbnail']['fanart']=hUwlFBOkGcdszWNrLqCKeQDYaRImix
  hUwlFBOkGcdszWNrLqCKeQDYaRImio['saveinfo']['thumbnail']['thumb']=hUwlFBOkGcdszWNrLqCKeQDYaRImJM
  hUwlFBOkGcdszWNrLqCKeQDYaRImio['saveinfo']['thumbnail']['clearlogo']=hUwlFBOkGcdszWNrLqCKeQDYaRImiH
  hUwlFBOkGcdszWNrLqCKeQDYaRImiM=[]
  for hUwlFBOkGcdszWNrLqCKeQDYaRImJH in hUwlFBOkGcdszWNrLqCKeQDYaRImiJ.get('tags'):hUwlFBOkGcdszWNrLqCKeQDYaRImiM.append(hUwlFBOkGcdszWNrLqCKeQDYaRImJH.get('tag'))
  if hUwlFBOkGcdszWNrLqCKeQDYaRImiV(hUwlFBOkGcdszWNrLqCKeQDYaRImiM)>0:
   hUwlFBOkGcdszWNrLqCKeQDYaRImio['saveinfo']['infoLabels']['genre']=hUwlFBOkGcdszWNrLqCKeQDYaRImiM
  hUwlFBOkGcdszWNrLqCKeQDYaRImiX=[]
  hUwlFBOkGcdszWNrLqCKeQDYaRImiA=[]
  for hUwlFBOkGcdszWNrLqCKeQDYaRImJH in hUwlFBOkGcdszWNrLqCKeQDYaRImiJ.get('people'):
   if hUwlFBOkGcdszWNrLqCKeQDYaRImJH.get('role')=='CAST' :hUwlFBOkGcdszWNrLqCKeQDYaRImiX.append(hUwlFBOkGcdszWNrLqCKeQDYaRImJH.get('name'))
   if hUwlFBOkGcdszWNrLqCKeQDYaRImJH.get('role')=='DIRECTOR':hUwlFBOkGcdszWNrLqCKeQDYaRImiA.append(hUwlFBOkGcdszWNrLqCKeQDYaRImJH.get('name'))
  if hUwlFBOkGcdszWNrLqCKeQDYaRImiV(hUwlFBOkGcdszWNrLqCKeQDYaRImiX)>0:
   hUwlFBOkGcdszWNrLqCKeQDYaRImio['saveinfo']['infoLabels']['cast'] =hUwlFBOkGcdszWNrLqCKeQDYaRImiX
  if hUwlFBOkGcdszWNrLqCKeQDYaRImiV(hUwlFBOkGcdszWNrLqCKeQDYaRImiA)>0:
   hUwlFBOkGcdszWNrLqCKeQDYaRImio['saveinfo']['infoLabels']['director']=hUwlFBOkGcdszWNrLqCKeQDYaRImiA
  return hUwlFBOkGcdszWNrLqCKeQDYaRImio
# Created by pyminifier (https://github.com/liftoff/pyminifier)
