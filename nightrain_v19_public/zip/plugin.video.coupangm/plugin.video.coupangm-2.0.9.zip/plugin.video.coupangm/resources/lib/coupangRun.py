__author__="NightRain"
UyixbSVBFHOYKEanhkjefwDtgIAlup=object
UyixbSVBFHOYKEanhkjefwDtgIAluJ=None
UyixbSVBFHOYKEanhkjefwDtgIAlur=False
UyixbSVBFHOYKEanhkjefwDtgIAluT=True
UyixbSVBFHOYKEanhkjefwDtgIAlus=type
UyixbSVBFHOYKEanhkjefwDtgIAluQ=dict
UyixbSVBFHOYKEanhkjefwDtgIAluv=int
UyixbSVBFHOYKEanhkjefwDtgIAlXo=open
UyixbSVBFHOYKEanhkjefwDtgIAlXL=Exception
UyixbSVBFHOYKEanhkjefwDtgIAlXP=str
UyixbSVBFHOYKEanhkjefwDtgIAlXN=id
UyixbSVBFHOYKEanhkjefwDtgIAlXc=len
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import inputstreamhelper
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
UyixbSVBFHOYKEanhkjefwDtgIAloP=[{'title':'홈   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'ALL'},{'title':'TV   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'MOVIES'},{'title':'교육 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'EDUCATION'},{'title':'생중계','mode':'EVENT_GROUPLIST','vType':'LIVE'},{'title':'TV   (테마별)','mode':'THEME_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (테마별)','mode':'THEME_GROUPLIST','vType':'MOVIES'},{'title':'교육 (테마별)','mode':'THEME_GROUPLIST','vType':'EDUCATION'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},{'title':'(쿠팡) 검색','mode':'LOCAL_SEARCH','icon':'search.png'},{'title':'(쿠팡) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
UyixbSVBFHOYKEanhkjefwDtgIAloN=[{'title':'시리즈 시청내역','mode':'WATCH','stype':'tvshow'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},]
UyixbSVBFHOYKEanhkjefwDtgIAloc=xbmcvfs.translatePath(os.path.join(__profile__,'coupang_searched.txt'))
from coupangCore import*
class UyixbSVBFHOYKEanhkjefwDtgIAloL(UyixbSVBFHOYKEanhkjefwDtgIAlup):
 def __init__(UyixbSVBFHOYKEanhkjefwDtgIAlou,UyixbSVBFHOYKEanhkjefwDtgIAloX,UyixbSVBFHOYKEanhkjefwDtgIAlod,UyixbSVBFHOYKEanhkjefwDtgIAloM):
  UyixbSVBFHOYKEanhkjefwDtgIAlou._addon_url =UyixbSVBFHOYKEanhkjefwDtgIAloX
  UyixbSVBFHOYKEanhkjefwDtgIAlou._addon_handle=UyixbSVBFHOYKEanhkjefwDtgIAlod
  UyixbSVBFHOYKEanhkjefwDtgIAlou.main_params =UyixbSVBFHOYKEanhkjefwDtgIAloM
  UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj =hUwlFBOkGcdszWNrLqCKeQDYaRImfo() 
  UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.CP_COOKIE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_cookies.json'))
  UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.CP_DEVICE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_device.json'))
 def addon_noti(UyixbSVBFHOYKEanhkjefwDtgIAlou,sting):
  try:
   UyixbSVBFHOYKEanhkjefwDtgIAloz=xbmcgui.Dialog()
   UyixbSVBFHOYKEanhkjefwDtgIAloz.notification(__addonname__,sting)
  except:
   UyixbSVBFHOYKEanhkjefwDtgIAluJ
 def addon_log(UyixbSVBFHOYKEanhkjefwDtgIAlou,string):
  try:
   UyixbSVBFHOYKEanhkjefwDtgIAlom=string.encode('utf-8','ignore')
  except:
   UyixbSVBFHOYKEanhkjefwDtgIAlom='addonException: addon_log'
  UyixbSVBFHOYKEanhkjefwDtgIAloq=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,UyixbSVBFHOYKEanhkjefwDtgIAlom),level=UyixbSVBFHOYKEanhkjefwDtgIAloq)
 def get_keyboard_input(UyixbSVBFHOYKEanhkjefwDtgIAlou,UyixbSVBFHOYKEanhkjefwDtgIAlLP):
  UyixbSVBFHOYKEanhkjefwDtgIAloR=UyixbSVBFHOYKEanhkjefwDtgIAluJ
  kb=xbmc.Keyboard()
  kb.setHeading(UyixbSVBFHOYKEanhkjefwDtgIAlLP)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   UyixbSVBFHOYKEanhkjefwDtgIAloR=kb.getText()
  return UyixbSVBFHOYKEanhkjefwDtgIAloR
 def get_settings_account(UyixbSVBFHOYKEanhkjefwDtgIAlou):
  UyixbSVBFHOYKEanhkjefwDtgIAloG=__addon__.getSetting('id')
  UyixbSVBFHOYKEanhkjefwDtgIAloC=__addon__.getSetting('pw')
  UyixbSVBFHOYKEanhkjefwDtgIAlop=__addon__.getSetting('profile')
  return(UyixbSVBFHOYKEanhkjefwDtgIAloG,UyixbSVBFHOYKEanhkjefwDtgIAloC,UyixbSVBFHOYKEanhkjefwDtgIAlop)
 def get_settings_exclusion21(UyixbSVBFHOYKEanhkjefwDtgIAlou):
  UyixbSVBFHOYKEanhkjefwDtgIAloJ =__addon__.getSetting('exclusion21')
  if UyixbSVBFHOYKEanhkjefwDtgIAloJ=='false':
   return UyixbSVBFHOYKEanhkjefwDtgIAlur
  else:
   return UyixbSVBFHOYKEanhkjefwDtgIAluT
 def get_settings_totalsearch(UyixbSVBFHOYKEanhkjefwDtgIAlou):
  UyixbSVBFHOYKEanhkjefwDtgIAlor =UyixbSVBFHOYKEanhkjefwDtgIAluT if __addon__.getSetting('local_search')=='true' else UyixbSVBFHOYKEanhkjefwDtgIAlur
  UyixbSVBFHOYKEanhkjefwDtgIAloT=UyixbSVBFHOYKEanhkjefwDtgIAluT if __addon__.getSetting('local_history')=='true' else UyixbSVBFHOYKEanhkjefwDtgIAlur
  UyixbSVBFHOYKEanhkjefwDtgIAlos =UyixbSVBFHOYKEanhkjefwDtgIAluT if __addon__.getSetting('total_search')=='true' else UyixbSVBFHOYKEanhkjefwDtgIAlur
  UyixbSVBFHOYKEanhkjefwDtgIAloQ=UyixbSVBFHOYKEanhkjefwDtgIAluT if __addon__.getSetting('total_history')=='true' else UyixbSVBFHOYKEanhkjefwDtgIAlur
  UyixbSVBFHOYKEanhkjefwDtgIAlov=UyixbSVBFHOYKEanhkjefwDtgIAluT if __addon__.getSetting('menu_bookmark')=='true' else UyixbSVBFHOYKEanhkjefwDtgIAlur
  return(UyixbSVBFHOYKEanhkjefwDtgIAlor,UyixbSVBFHOYKEanhkjefwDtgIAloT,UyixbSVBFHOYKEanhkjefwDtgIAlos,UyixbSVBFHOYKEanhkjefwDtgIAloQ,UyixbSVBFHOYKEanhkjefwDtgIAlov)
 def get_settings_makebookmark(UyixbSVBFHOYKEanhkjefwDtgIAlou):
  return UyixbSVBFHOYKEanhkjefwDtgIAluT if __addon__.getSetting('make_bookmark')=='true' else UyixbSVBFHOYKEanhkjefwDtgIAlur
 def add_dir(UyixbSVBFHOYKEanhkjefwDtgIAlou,label,sublabel='',img='',infoLabels=UyixbSVBFHOYKEanhkjefwDtgIAluJ,isFolder=UyixbSVBFHOYKEanhkjefwDtgIAluT,params='',isLink=UyixbSVBFHOYKEanhkjefwDtgIAlur,ContextMenu=UyixbSVBFHOYKEanhkjefwDtgIAluJ):
  UyixbSVBFHOYKEanhkjefwDtgIAlLo='%s?%s'%(UyixbSVBFHOYKEanhkjefwDtgIAlou._addon_url,urllib.parse.urlencode(params))
  if sublabel:UyixbSVBFHOYKEanhkjefwDtgIAlLP='%s < %s >'%(label,sublabel)
  else: UyixbSVBFHOYKEanhkjefwDtgIAlLP=label
  if not img:img='DefaultFolder.png'
  UyixbSVBFHOYKEanhkjefwDtgIAlLN=xbmcgui.ListItem(UyixbSVBFHOYKEanhkjefwDtgIAlLP)
  if UyixbSVBFHOYKEanhkjefwDtgIAlus(img)==UyixbSVBFHOYKEanhkjefwDtgIAluQ:
   UyixbSVBFHOYKEanhkjefwDtgIAlLN.setArt(img)
  else:
   UyixbSVBFHOYKEanhkjefwDtgIAlLN.setArt({'thumb':img,'poster':img})
  if infoLabels:UyixbSVBFHOYKEanhkjefwDtgIAlLN.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   UyixbSVBFHOYKEanhkjefwDtgIAlLN.setProperty('IsPlayable','true')
  if ContextMenu:UyixbSVBFHOYKEanhkjefwDtgIAlLN.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(UyixbSVBFHOYKEanhkjefwDtgIAlou._addon_handle,UyixbSVBFHOYKEanhkjefwDtgIAlLo,UyixbSVBFHOYKEanhkjefwDtgIAlLN,isFolder)
 def dp_Main_List(UyixbSVBFHOYKEanhkjefwDtgIAlou,args):
  (UyixbSVBFHOYKEanhkjefwDtgIAlor,UyixbSVBFHOYKEanhkjefwDtgIAloT,UyixbSVBFHOYKEanhkjefwDtgIAlos,UyixbSVBFHOYKEanhkjefwDtgIAloQ,UyixbSVBFHOYKEanhkjefwDtgIAlov)=UyixbSVBFHOYKEanhkjefwDtgIAlou.get_settings_totalsearch()
  for UyixbSVBFHOYKEanhkjefwDtgIAlLc in UyixbSVBFHOYKEanhkjefwDtgIAloP:
   UyixbSVBFHOYKEanhkjefwDtgIAlLP=UyixbSVBFHOYKEanhkjefwDtgIAlLc.get('title')
   UyixbSVBFHOYKEanhkjefwDtgIAlLu=''
   if UyixbSVBFHOYKEanhkjefwDtgIAlLc.get('mode')=='LOCAL_SEARCH' and UyixbSVBFHOYKEanhkjefwDtgIAlor ==UyixbSVBFHOYKEanhkjefwDtgIAlur:continue
   elif UyixbSVBFHOYKEanhkjefwDtgIAlLc.get('mode')=='SEARCH_HISTORY' and UyixbSVBFHOYKEanhkjefwDtgIAloT==UyixbSVBFHOYKEanhkjefwDtgIAlur:continue
   elif UyixbSVBFHOYKEanhkjefwDtgIAlLc.get('mode')=='TOTAL_SEARCH' and UyixbSVBFHOYKEanhkjefwDtgIAlos ==UyixbSVBFHOYKEanhkjefwDtgIAlur:continue
   elif UyixbSVBFHOYKEanhkjefwDtgIAlLc.get('mode')=='TOTAL_HISTORY' and UyixbSVBFHOYKEanhkjefwDtgIAloQ==UyixbSVBFHOYKEanhkjefwDtgIAlur:continue
   elif UyixbSVBFHOYKEanhkjefwDtgIAlLc.get('mode')=='MENU_BOOKMARK' and UyixbSVBFHOYKEanhkjefwDtgIAlov==UyixbSVBFHOYKEanhkjefwDtgIAlur:continue
   UyixbSVBFHOYKEanhkjefwDtgIAlLX={'mode':UyixbSVBFHOYKEanhkjefwDtgIAlLc.get('mode'),'vType':UyixbSVBFHOYKEanhkjefwDtgIAlLc.get('vType'),'page':'1',}
   if UyixbSVBFHOYKEanhkjefwDtgIAlLc.get('mode')=='LOCAL_SEARCH':UyixbSVBFHOYKEanhkjefwDtgIAlLX['historyyn']='Y' 
   if UyixbSVBFHOYKEanhkjefwDtgIAlLc.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    UyixbSVBFHOYKEanhkjefwDtgIAlLd=UyixbSVBFHOYKEanhkjefwDtgIAlur
    UyixbSVBFHOYKEanhkjefwDtgIAlLM =UyixbSVBFHOYKEanhkjefwDtgIAluT
   else:
    UyixbSVBFHOYKEanhkjefwDtgIAlLd=UyixbSVBFHOYKEanhkjefwDtgIAluT
    UyixbSVBFHOYKEanhkjefwDtgIAlLM =UyixbSVBFHOYKEanhkjefwDtgIAlur
   if 'icon' in UyixbSVBFHOYKEanhkjefwDtgIAlLc:UyixbSVBFHOYKEanhkjefwDtgIAlLu=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',UyixbSVBFHOYKEanhkjefwDtgIAlLc.get('icon')) 
   UyixbSVBFHOYKEanhkjefwDtgIAlou.add_dir(UyixbSVBFHOYKEanhkjefwDtgIAlLP,sublabel='',img=UyixbSVBFHOYKEanhkjefwDtgIAlLu,infoLabels=UyixbSVBFHOYKEanhkjefwDtgIAluJ,isFolder=UyixbSVBFHOYKEanhkjefwDtgIAlLd,params=UyixbSVBFHOYKEanhkjefwDtgIAlLX,isLink=UyixbSVBFHOYKEanhkjefwDtgIAlLM)
  xbmcplugin.endOfDirectory(UyixbSVBFHOYKEanhkjefwDtgIAlou._addon_handle)
 def dp_Test(UyixbSVBFHOYKEanhkjefwDtgIAlou,args):
  UyixbSVBFHOYKEanhkjefwDtgIAlou.addon_noti('test')
 def CP_logout(UyixbSVBFHOYKEanhkjefwDtgIAlou):
  UyixbSVBFHOYKEanhkjefwDtgIAloz=xbmcgui.Dialog()
  UyixbSVBFHOYKEanhkjefwDtgIAlLz=UyixbSVBFHOYKEanhkjefwDtgIAloz.yesno(__language__(30905).encode('utf8'),__language__(30906).encode('utf8'))
  if UyixbSVBFHOYKEanhkjefwDtgIAlLz==UyixbSVBFHOYKEanhkjefwDtgIAlur:return 
  if os.path.isfile(UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.CP_COOKIE_FILENAME):os.remove(UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.CP_COOKIE_FILENAME)
  UyixbSVBFHOYKEanhkjefwDtgIAlou.addon_noti(__language__(30904).encode('utf-8'))
 def option_check(UyixbSVBFHOYKEanhkjefwDtgIAlou):
  (UyixbSVBFHOYKEanhkjefwDtgIAloG,UyixbSVBFHOYKEanhkjefwDtgIAloC,UyixbSVBFHOYKEanhkjefwDtgIAlop)=UyixbSVBFHOYKEanhkjefwDtgIAlou.get_settings_account()
  if UyixbSVBFHOYKEanhkjefwDtgIAloG=='' or UyixbSVBFHOYKEanhkjefwDtgIAloC=='':
   UyixbSVBFHOYKEanhkjefwDtgIAloz=xbmcgui.Dialog()
   UyixbSVBFHOYKEanhkjefwDtgIAlLz=UyixbSVBFHOYKEanhkjefwDtgIAloz.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if UyixbSVBFHOYKEanhkjefwDtgIAlLz==UyixbSVBFHOYKEanhkjefwDtgIAluT:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if UyixbSVBFHOYKEanhkjefwDtgIAlou.cookiefile_check()==UyixbSVBFHOYKEanhkjefwDtgIAlur:
   if UyixbSVBFHOYKEanhkjefwDtgIAlou.CP_login(UyixbSVBFHOYKEanhkjefwDtgIAloG,UyixbSVBFHOYKEanhkjefwDtgIAloC,UyixbSVBFHOYKEanhkjefwDtgIAlop)==UyixbSVBFHOYKEanhkjefwDtgIAlur:
    UyixbSVBFHOYKEanhkjefwDtgIAlou.addon_noti(__language__(30903).encode('utf8'))
    sys.exit()
  else:
   UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.Get_CP_profile(UyixbSVBFHOYKEanhkjefwDtgIAlop,limit_days=UyixbSVBFHOYKEanhkjefwDtgIAluv(__addon__.getSetting('cache_ttl')),re_check=UyixbSVBFHOYKEanhkjefwDtgIAluT)
 def cookiefile_check(UyixbSVBFHOYKEanhkjefwDtgIAlou):
  UyixbSVBFHOYKEanhkjefwDtgIAlLq={}
  try: 
   fp=UyixbSVBFHOYKEanhkjefwDtgIAlXo(UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.CP_COOKIE_FILENAME,'r',-1,'utf-8')
   UyixbSVBFHOYKEanhkjefwDtgIAlLq= json.load(fp)
   fp.close()
  except UyixbSVBFHOYKEanhkjefwDtgIAlXL as exception:
   return UyixbSVBFHOYKEanhkjefwDtgIAlur
  UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.CP=UyixbSVBFHOYKEanhkjefwDtgIAlLq
  if 'session_web_id' not in UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.CP.get('SESSION'):
   UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.Init_CP()
   return UyixbSVBFHOYKEanhkjefwDtgIAlur
  (UyixbSVBFHOYKEanhkjefwDtgIAloG,UyixbSVBFHOYKEanhkjefwDtgIAloC,UyixbSVBFHOYKEanhkjefwDtgIAlop)=UyixbSVBFHOYKEanhkjefwDtgIAlou.get_settings_account()
  (UyixbSVBFHOYKEanhkjefwDtgIAlLR,UyixbSVBFHOYKEanhkjefwDtgIAlLG,UyixbSVBFHOYKEanhkjefwDtgIAlLC)=UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.Load_session_acount()
  if UyixbSVBFHOYKEanhkjefwDtgIAloG!=UyixbSVBFHOYKEanhkjefwDtgIAlLR or UyixbSVBFHOYKEanhkjefwDtgIAloC!=UyixbSVBFHOYKEanhkjefwDtgIAlLG or UyixbSVBFHOYKEanhkjefwDtgIAlop!=UyixbSVBFHOYKEanhkjefwDtgIAlXP(UyixbSVBFHOYKEanhkjefwDtgIAlLC):
   UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.Init_CP()
   return UyixbSVBFHOYKEanhkjefwDtgIAlur
  UyixbSVBFHOYKEanhkjefwDtgIAlLp =UyixbSVBFHOYKEanhkjefwDtgIAluv(UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.Get_Now_Datetime().strftime('%Y%m%d'))
  UyixbSVBFHOYKEanhkjefwDtgIAlLJ=UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.CP['SESSION']['limitdate']
  UyixbSVBFHOYKEanhkjefwDtgIAlLr =UyixbSVBFHOYKEanhkjefwDtgIAluv(re.sub('-','',UyixbSVBFHOYKEanhkjefwDtgIAlLJ))
  if UyixbSVBFHOYKEanhkjefwDtgIAlLr<UyixbSVBFHOYKEanhkjefwDtgIAlLp:
   UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.Init_CP()
   return UyixbSVBFHOYKEanhkjefwDtgIAlur
  return UyixbSVBFHOYKEanhkjefwDtgIAluT
 def CP_login(UyixbSVBFHOYKEanhkjefwDtgIAlou,UyixbSVBFHOYKEanhkjefwDtgIAloG,UyixbSVBFHOYKEanhkjefwDtgIAloC,UyixbSVBFHOYKEanhkjefwDtgIAlop):
  if UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.Get_CP_Login(UyixbSVBFHOYKEanhkjefwDtgIAloG,UyixbSVBFHOYKEanhkjefwDtgIAloC,UyixbSVBFHOYKEanhkjefwDtgIAlop)==UyixbSVBFHOYKEanhkjefwDtgIAlur:return UyixbSVBFHOYKEanhkjefwDtgIAlur
  if UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.Get_CP_profile(UyixbSVBFHOYKEanhkjefwDtgIAlop,limit_days=UyixbSVBFHOYKEanhkjefwDtgIAluv(__addon__.getSetting('cache_ttl')),re_check=UyixbSVBFHOYKEanhkjefwDtgIAlur)==UyixbSVBFHOYKEanhkjefwDtgIAlur:return UyixbSVBFHOYKEanhkjefwDtgIAlur
  return UyixbSVBFHOYKEanhkjefwDtgIAluT
 def dp_Category_GroupList(UyixbSVBFHOYKEanhkjefwDtgIAlou,args):
  UyixbSVBFHOYKEanhkjefwDtgIAlLT =args.get('vType') 
  UyixbSVBFHOYKEanhkjefwDtgIAlLs=UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.Get_Category_GroupList(UyixbSVBFHOYKEanhkjefwDtgIAlLT)
  for UyixbSVBFHOYKEanhkjefwDtgIAlLQ in UyixbSVBFHOYKEanhkjefwDtgIAlLs:
   UyixbSVBFHOYKEanhkjefwDtgIAlLP =UyixbSVBFHOYKEanhkjefwDtgIAlLQ.get('title')
   UyixbSVBFHOYKEanhkjefwDtgIAlLv=UyixbSVBFHOYKEanhkjefwDtgIAlLQ.get('pre_title')
   if UyixbSVBFHOYKEanhkjefwDtgIAlou.get_settings_exclusion21()==UyixbSVBFHOYKEanhkjefwDtgIAluT and UyixbSVBFHOYKEanhkjefwDtgIAlLP=='성인':continue
   UyixbSVBFHOYKEanhkjefwDtgIAlPo={'mediatype':'tvshow','plot':UyixbSVBFHOYKEanhkjefwDtgIAlLv,}
   UyixbSVBFHOYKEanhkjefwDtgIAlLX={'mode':'CATEGORY_LIST','collectionId':UyixbSVBFHOYKEanhkjefwDtgIAlLQ.get('collectionId'),'vType':UyixbSVBFHOYKEanhkjefwDtgIAlLQ.get('category'),'page':'1',}
   UyixbSVBFHOYKEanhkjefwDtgIAlou.add_dir(UyixbSVBFHOYKEanhkjefwDtgIAlLP,sublabel='',img='',infoLabels=UyixbSVBFHOYKEanhkjefwDtgIAlPo,isFolder=UyixbSVBFHOYKEanhkjefwDtgIAluT,params=UyixbSVBFHOYKEanhkjefwDtgIAlLX)
  xbmcplugin.endOfDirectory(UyixbSVBFHOYKEanhkjefwDtgIAlou._addon_handle,cacheToDisc=UyixbSVBFHOYKEanhkjefwDtgIAlur)
 def dp_Theme_GroupList(UyixbSVBFHOYKEanhkjefwDtgIAlou,args):
  UyixbSVBFHOYKEanhkjefwDtgIAlLT =args.get('vType') 
  UyixbSVBFHOYKEanhkjefwDtgIAlLs=UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.Get_Theme_GroupList(UyixbSVBFHOYKEanhkjefwDtgIAlLT)
  for UyixbSVBFHOYKEanhkjefwDtgIAlLQ in UyixbSVBFHOYKEanhkjefwDtgIAlLs:
   UyixbSVBFHOYKEanhkjefwDtgIAlLP =UyixbSVBFHOYKEanhkjefwDtgIAlLQ.get('title')
   UyixbSVBFHOYKEanhkjefwDtgIAlLv=UyixbSVBFHOYKEanhkjefwDtgIAlLQ.get('pre_title')
   UyixbSVBFHOYKEanhkjefwDtgIAlPo={'mediatype':'tvshow','plot':UyixbSVBFHOYKEanhkjefwDtgIAlLv,}
   UyixbSVBFHOYKEanhkjefwDtgIAlLX={'mode':'CATEGORY_LIST','collectionId':UyixbSVBFHOYKEanhkjefwDtgIAlLQ.get('collectionId'),'vType':UyixbSVBFHOYKEanhkjefwDtgIAlLQ.get('category'),'page':'1',}
   UyixbSVBFHOYKEanhkjefwDtgIAlou.add_dir(UyixbSVBFHOYKEanhkjefwDtgIAlLP,sublabel='',img='',infoLabels=UyixbSVBFHOYKEanhkjefwDtgIAlPo,isFolder=UyixbSVBFHOYKEanhkjefwDtgIAluT,params=UyixbSVBFHOYKEanhkjefwDtgIAlLX)
  xbmcplugin.endOfDirectory(UyixbSVBFHOYKEanhkjefwDtgIAlou._addon_handle,cacheToDisc=UyixbSVBFHOYKEanhkjefwDtgIAlur)
 def dp_Event_GroupList(UyixbSVBFHOYKEanhkjefwDtgIAlou,args):
  UyixbSVBFHOYKEanhkjefwDtgIAlLs=UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.Get_Event_GroupList()
  for UyixbSVBFHOYKEanhkjefwDtgIAlLQ in UyixbSVBFHOYKEanhkjefwDtgIAlLs:
   UyixbSVBFHOYKEanhkjefwDtgIAlLP =UyixbSVBFHOYKEanhkjefwDtgIAlLQ.get('title')
   UyixbSVBFHOYKEanhkjefwDtgIAlLv=UyixbSVBFHOYKEanhkjefwDtgIAlLQ.get('pre_title')
   UyixbSVBFHOYKEanhkjefwDtgIAlPo={'mediatype':'tvshow','plot':UyixbSVBFHOYKEanhkjefwDtgIAlLv,}
   UyixbSVBFHOYKEanhkjefwDtgIAlLX={'mode':'EVENT_GAMELIST','collectionId':UyixbSVBFHOYKEanhkjefwDtgIAlLQ.get('collectionId'),'vType':'LIVE',}
   UyixbSVBFHOYKEanhkjefwDtgIAlou.add_dir(UyixbSVBFHOYKEanhkjefwDtgIAlLP,sublabel='',img='',infoLabels=UyixbSVBFHOYKEanhkjefwDtgIAlPo,isFolder=UyixbSVBFHOYKEanhkjefwDtgIAluT,params=UyixbSVBFHOYKEanhkjefwDtgIAlLX)
  xbmcplugin.endOfDirectory(UyixbSVBFHOYKEanhkjefwDtgIAlou._addon_handle,cacheToDisc=UyixbSVBFHOYKEanhkjefwDtgIAlur)
 def dp_Event_GameList(UyixbSVBFHOYKEanhkjefwDtgIAlou,args):
  UyixbSVBFHOYKEanhkjefwDtgIAlLT =args.get('vType') 
  UyixbSVBFHOYKEanhkjefwDtgIAlPN =args.get('collectionId')
  UyixbSVBFHOYKEanhkjefwDtgIAlLs=UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.Get_Event_GameList(UyixbSVBFHOYKEanhkjefwDtgIAlPN)
  for UyixbSVBFHOYKEanhkjefwDtgIAlLQ in UyixbSVBFHOYKEanhkjefwDtgIAlLs:
   UyixbSVBFHOYKEanhkjefwDtgIAlLP =UyixbSVBFHOYKEanhkjefwDtgIAlLQ.get('title')
   UyixbSVBFHOYKEanhkjefwDtgIAlXN =UyixbSVBFHOYKEanhkjefwDtgIAlLQ.get('id')
   UyixbSVBFHOYKEanhkjefwDtgIAlPc =UyixbSVBFHOYKEanhkjefwDtgIAlLQ.get('thumbnail')
   UyixbSVBFHOYKEanhkjefwDtgIAlPu =UyixbSVBFHOYKEanhkjefwDtgIAlLQ.get('asis') 
   UyixbSVBFHOYKEanhkjefwDtgIAlPX =UyixbSVBFHOYKEanhkjefwDtgIAlLQ.get('addInfo')
   UyixbSVBFHOYKEanhkjefwDtgIAlPd =UyixbSVBFHOYKEanhkjefwDtgIAlLQ.get('starttm')
   UyixbSVBFHOYKEanhkjefwDtgIAlPo={'mediatype':'tvshow','title':UyixbSVBFHOYKEanhkjefwDtgIAlLP,'plot':UyixbSVBFHOYKEanhkjefwDtgIAlPX,}
   UyixbSVBFHOYKEanhkjefwDtgIAlLX={'mode':'EVENT_LIST','id':UyixbSVBFHOYKEanhkjefwDtgIAlXN,'asis':UyixbSVBFHOYKEanhkjefwDtgIAlPu,'title':UyixbSVBFHOYKEanhkjefwDtgIAlLP,}
   UyixbSVBFHOYKEanhkjefwDtgIAlou.add_dir(UyixbSVBFHOYKEanhkjefwDtgIAlLP,sublabel=UyixbSVBFHOYKEanhkjefwDtgIAlPd,img=UyixbSVBFHOYKEanhkjefwDtgIAlPc,infoLabels=UyixbSVBFHOYKEanhkjefwDtgIAlPo,isFolder=UyixbSVBFHOYKEanhkjefwDtgIAluT,params=UyixbSVBFHOYKEanhkjefwDtgIAlLX,ContextMenu=UyixbSVBFHOYKEanhkjefwDtgIAluJ)
  xbmcplugin.setContent(UyixbSVBFHOYKEanhkjefwDtgIAlou._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(UyixbSVBFHOYKEanhkjefwDtgIAlou._addon_handle,cacheToDisc=UyixbSVBFHOYKEanhkjefwDtgIAlur)
 def dp_Event_List(UyixbSVBFHOYKEanhkjefwDtgIAlou,args):
  UyixbSVBFHOYKEanhkjefwDtgIAlPM=args.get('id')
  UyixbSVBFHOYKEanhkjefwDtgIAlLs=UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.Get_Event_List(UyixbSVBFHOYKEanhkjefwDtgIAlPM)
  for UyixbSVBFHOYKEanhkjefwDtgIAlLQ in UyixbSVBFHOYKEanhkjefwDtgIAlLs:
   UyixbSVBFHOYKEanhkjefwDtgIAlLP =UyixbSVBFHOYKEanhkjefwDtgIAlLQ.get('title')
   UyixbSVBFHOYKEanhkjefwDtgIAlXN =UyixbSVBFHOYKEanhkjefwDtgIAlLQ.get('id')
   UyixbSVBFHOYKEanhkjefwDtgIAlPc =UyixbSVBFHOYKEanhkjefwDtgIAlLQ.get('thumbnail')
   UyixbSVBFHOYKEanhkjefwDtgIAlPu =UyixbSVBFHOYKEanhkjefwDtgIAlLQ.get('asis') 
   UyixbSVBFHOYKEanhkjefwDtgIAlPW =UyixbSVBFHOYKEanhkjefwDtgIAlLQ.get('duration')
   UyixbSVBFHOYKEanhkjefwDtgIAlPd =UyixbSVBFHOYKEanhkjefwDtgIAlLQ.get('starttm')
   UyixbSVBFHOYKEanhkjefwDtgIAlPo={'mediatype':'episode','title':UyixbSVBFHOYKEanhkjefwDtgIAlLP,'plot':UyixbSVBFHOYKEanhkjefwDtgIAlPu,'duration':UyixbSVBFHOYKEanhkjefwDtgIAlPW,}
   UyixbSVBFHOYKEanhkjefwDtgIAlLX={'mode':UyixbSVBFHOYKEanhkjefwDtgIAlPu,'id':UyixbSVBFHOYKEanhkjefwDtgIAlXN,'asis':UyixbSVBFHOYKEanhkjefwDtgIAlPu,'title':UyixbSVBFHOYKEanhkjefwDtgIAlLP,}
   UyixbSVBFHOYKEanhkjefwDtgIAlou.add_dir(UyixbSVBFHOYKEanhkjefwDtgIAlLP,sublabel=UyixbSVBFHOYKEanhkjefwDtgIAlPd,img=UyixbSVBFHOYKEanhkjefwDtgIAlPc,infoLabels=UyixbSVBFHOYKEanhkjefwDtgIAlPo,isFolder=UyixbSVBFHOYKEanhkjefwDtgIAlur,params=UyixbSVBFHOYKEanhkjefwDtgIAlLX,ContextMenu=UyixbSVBFHOYKEanhkjefwDtgIAluJ)
  xbmcplugin.setContent(UyixbSVBFHOYKEanhkjefwDtgIAlou._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(UyixbSVBFHOYKEanhkjefwDtgIAlou._addon_handle,cacheToDisc=UyixbSVBFHOYKEanhkjefwDtgIAlur)
 def dp_Category_List(UyixbSVBFHOYKEanhkjefwDtgIAlou,args):
  UyixbSVBFHOYKEanhkjefwDtgIAlLT =args.get('vType') 
  UyixbSVBFHOYKEanhkjefwDtgIAlPN =args.get('collectionId')
  UyixbSVBFHOYKEanhkjefwDtgIAlPz =UyixbSVBFHOYKEanhkjefwDtgIAluv(args.get('page'))
  UyixbSVBFHOYKEanhkjefwDtgIAlLs,UyixbSVBFHOYKEanhkjefwDtgIAlPm=UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.Get_Category_List(UyixbSVBFHOYKEanhkjefwDtgIAlLT,UyixbSVBFHOYKEanhkjefwDtgIAlPN,UyixbSVBFHOYKEanhkjefwDtgIAlPz)
  for UyixbSVBFHOYKEanhkjefwDtgIAlLQ in UyixbSVBFHOYKEanhkjefwDtgIAlLs:
   UyixbSVBFHOYKEanhkjefwDtgIAlLP =UyixbSVBFHOYKEanhkjefwDtgIAlLQ.get('title')
   UyixbSVBFHOYKEanhkjefwDtgIAlXN =UyixbSVBFHOYKEanhkjefwDtgIAlLQ.get('id')
   UyixbSVBFHOYKEanhkjefwDtgIAlPc =UyixbSVBFHOYKEanhkjefwDtgIAlLQ.get('thumbnail')
   UyixbSVBFHOYKEanhkjefwDtgIAlPq =UyixbSVBFHOYKEanhkjefwDtgIAlLQ.get('mpaa')
   UyixbSVBFHOYKEanhkjefwDtgIAlPW =UyixbSVBFHOYKEanhkjefwDtgIAlLQ.get('duration')
   UyixbSVBFHOYKEanhkjefwDtgIAlPu =UyixbSVBFHOYKEanhkjefwDtgIAlLQ.get('asis')
   UyixbSVBFHOYKEanhkjefwDtgIAlPR =UyixbSVBFHOYKEanhkjefwDtgIAlLQ.get('badge')
   UyixbSVBFHOYKEanhkjefwDtgIAlPG =UyixbSVBFHOYKEanhkjefwDtgIAlLQ.get('year')
   UyixbSVBFHOYKEanhkjefwDtgIAlPC=UyixbSVBFHOYKEanhkjefwDtgIAlLQ.get('seasonList')
   UyixbSVBFHOYKEanhkjefwDtgIAlPp =UyixbSVBFHOYKEanhkjefwDtgIAlLQ.get('genreList')
   if UyixbSVBFHOYKEanhkjefwDtgIAlPu in['TVSHOW','EDUCATION']: 
    UyixbSVBFHOYKEanhkjefwDtgIAlPJ ='SEASON_LIST'
    UyixbSVBFHOYKEanhkjefwDtgIAlPo={'mediatype':'tvshow','title':UyixbSVBFHOYKEanhkjefwDtgIAlLP,'mpaa':UyixbSVBFHOYKEanhkjefwDtgIAlPq,'genre':UyixbSVBFHOYKEanhkjefwDtgIAlPp,'year':UyixbSVBFHOYKEanhkjefwDtgIAlPG,'plot':'Year : %s\nSeason : %s'%(UyixbSVBFHOYKEanhkjefwDtgIAlPG,UyixbSVBFHOYKEanhkjefwDtgIAlPC),}
    UyixbSVBFHOYKEanhkjefwDtgIAlLd =UyixbSVBFHOYKEanhkjefwDtgIAluT
   else:
    UyixbSVBFHOYKEanhkjefwDtgIAlPJ ='MOVIE'
    UyixbSVBFHOYKEanhkjefwDtgIAlPo={'mediatype':'movie','title':UyixbSVBFHOYKEanhkjefwDtgIAlLP,'mpaa':UyixbSVBFHOYKEanhkjefwDtgIAlPq,'genre':UyixbSVBFHOYKEanhkjefwDtgIAlPp,'duration':UyixbSVBFHOYKEanhkjefwDtgIAlPW,'year':UyixbSVBFHOYKEanhkjefwDtgIAlPG,'plot':'(%s)'%(UyixbSVBFHOYKEanhkjefwDtgIAlPq),}
    UyixbSVBFHOYKEanhkjefwDtgIAlLd =UyixbSVBFHOYKEanhkjefwDtgIAlur
    UyixbSVBFHOYKEanhkjefwDtgIAlLP +=' (%s)'%(UyixbSVBFHOYKEanhkjefwDtgIAlXP(UyixbSVBFHOYKEanhkjefwDtgIAlPG))
   UyixbSVBFHOYKEanhkjefwDtgIAlLX={'mode':UyixbSVBFHOYKEanhkjefwDtgIAlPJ,'id':UyixbSVBFHOYKEanhkjefwDtgIAlXN,'asis':UyixbSVBFHOYKEanhkjefwDtgIAlPu,'seasonList':UyixbSVBFHOYKEanhkjefwDtgIAlPC,'title':UyixbSVBFHOYKEanhkjefwDtgIAlLP,'thumbnail':UyixbSVBFHOYKEanhkjefwDtgIAlPc,'year':UyixbSVBFHOYKEanhkjefwDtgIAlPG,}
   if UyixbSVBFHOYKEanhkjefwDtgIAlou.get_settings_makebookmark():
    UyixbSVBFHOYKEanhkjefwDtgIAlPr={'videoid':UyixbSVBFHOYKEanhkjefwDtgIAlXN,'vidtype':'movie' if UyixbSVBFHOYKEanhkjefwDtgIAlLT=='MOVIES' else 'tvshow','vtitle':UyixbSVBFHOYKEanhkjefwDtgIAlLP,'vsubtitle':'',}
    UyixbSVBFHOYKEanhkjefwDtgIAlPT=json.dumps(UyixbSVBFHOYKEanhkjefwDtgIAlPr)
    UyixbSVBFHOYKEanhkjefwDtgIAlPT=urllib.parse.quote(UyixbSVBFHOYKEanhkjefwDtgIAlPT)
    UyixbSVBFHOYKEanhkjefwDtgIAlPs='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(UyixbSVBFHOYKEanhkjefwDtgIAlPT)
    UyixbSVBFHOYKEanhkjefwDtgIAlPQ=[('(통합) 찜 영상에 추가',UyixbSVBFHOYKEanhkjefwDtgIAlPs)]
   else:
    UyixbSVBFHOYKEanhkjefwDtgIAlPQ=UyixbSVBFHOYKEanhkjefwDtgIAluJ
   UyixbSVBFHOYKEanhkjefwDtgIAlou.add_dir(UyixbSVBFHOYKEanhkjefwDtgIAlLP,sublabel=UyixbSVBFHOYKEanhkjefwDtgIAlPR,img=UyixbSVBFHOYKEanhkjefwDtgIAlPc,infoLabels=UyixbSVBFHOYKEanhkjefwDtgIAlPo,isFolder=UyixbSVBFHOYKEanhkjefwDtgIAlLd,params=UyixbSVBFHOYKEanhkjefwDtgIAlLX,ContextMenu=UyixbSVBFHOYKEanhkjefwDtgIAlPQ)
  if UyixbSVBFHOYKEanhkjefwDtgIAlPm:
   UyixbSVBFHOYKEanhkjefwDtgIAlLX['mode'] ='CATEGORY_LIST' 
   UyixbSVBFHOYKEanhkjefwDtgIAlLX['collectionId']=UyixbSVBFHOYKEanhkjefwDtgIAlPN 
   UyixbSVBFHOYKEanhkjefwDtgIAlLX['vType'] =UyixbSVBFHOYKEanhkjefwDtgIAlLT 
   UyixbSVBFHOYKEanhkjefwDtgIAlLX['page'] =UyixbSVBFHOYKEanhkjefwDtgIAlXP(UyixbSVBFHOYKEanhkjefwDtgIAlPz+1)
   UyixbSVBFHOYKEanhkjefwDtgIAlLP='[B]%s >>[/B]'%'다음 페이지'
   UyixbSVBFHOYKEanhkjefwDtgIAlPv=UyixbSVBFHOYKEanhkjefwDtgIAlXP(UyixbSVBFHOYKEanhkjefwDtgIAlPz+1)
   UyixbSVBFHOYKEanhkjefwDtgIAlLu=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   UyixbSVBFHOYKEanhkjefwDtgIAlou.add_dir(UyixbSVBFHOYKEanhkjefwDtgIAlLP,sublabel=UyixbSVBFHOYKEanhkjefwDtgIAlPv,img=UyixbSVBFHOYKEanhkjefwDtgIAlLu,infoLabels=UyixbSVBFHOYKEanhkjefwDtgIAluJ,isFolder=UyixbSVBFHOYKEanhkjefwDtgIAluT,params=UyixbSVBFHOYKEanhkjefwDtgIAlLX)
  if UyixbSVBFHOYKEanhkjefwDtgIAlLT=='TVSHOWS':xbmcplugin.setContent(UyixbSVBFHOYKEanhkjefwDtgIAlou._addon_handle,'tvshows')
  else:xbmcplugin.setContent(UyixbSVBFHOYKEanhkjefwDtgIAlou._addon_handle,'movies')
  xbmcplugin.endOfDirectory(UyixbSVBFHOYKEanhkjefwDtgIAlou._addon_handle,cacheToDisc=UyixbSVBFHOYKEanhkjefwDtgIAlur)
 def dp_Season_List(UyixbSVBFHOYKEanhkjefwDtgIAlou,args):
  UyixbSVBFHOYKEanhkjefwDtgIAlNo =args.get('title')
  UyixbSVBFHOYKEanhkjefwDtgIAlNL =args.get('id')
  UyixbSVBFHOYKEanhkjefwDtgIAlPu =args.get('asis')
  UyixbSVBFHOYKEanhkjefwDtgIAlPC =args.get('seasonList')
  UyixbSVBFHOYKEanhkjefwDtgIAlPc =args.get('thumbnail')
  UyixbSVBFHOYKEanhkjefwDtgIAlPG =args.get('year')
  if UyixbSVBFHOYKEanhkjefwDtgIAlPC in['',UyixbSVBFHOYKEanhkjefwDtgIAluJ]:
   UyixbSVBFHOYKEanhkjefwDtgIAlPC=UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.Get_vInfo(UyixbSVBFHOYKEanhkjefwDtgIAlNL).get('seasonList')
  if UyixbSVBFHOYKEanhkjefwDtgIAlXc(UyixbSVBFHOYKEanhkjefwDtgIAlPC.split(','))>1:
   for UyixbSVBFHOYKEanhkjefwDtgIAlNP in UyixbSVBFHOYKEanhkjefwDtgIAlPC.split(','):
    UyixbSVBFHOYKEanhkjefwDtgIAlLP='시즌 '+UyixbSVBFHOYKEanhkjefwDtgIAlNP
    UyixbSVBFHOYKEanhkjefwDtgIAlPo={'mediatype':'tvshow','plot':'%s (%s)'%(UyixbSVBFHOYKEanhkjefwDtgIAlNo,UyixbSVBFHOYKEanhkjefwDtgIAlPG),}
    UyixbSVBFHOYKEanhkjefwDtgIAlLX={'mode':'EPISODE_LIST','programid':UyixbSVBFHOYKEanhkjefwDtgIAlNL,'programnm':UyixbSVBFHOYKEanhkjefwDtgIAlNo,'season':UyixbSVBFHOYKEanhkjefwDtgIAlNP,'asis':UyixbSVBFHOYKEanhkjefwDtgIAlPu,'programimg':UyixbSVBFHOYKEanhkjefwDtgIAlPc,}
    UyixbSVBFHOYKEanhkjefwDtgIAlNc=UyixbSVBFHOYKEanhkjefwDtgIAlPc.replace('\'','\"')
    UyixbSVBFHOYKEanhkjefwDtgIAlNc=json.loads(UyixbSVBFHOYKEanhkjefwDtgIAlNc)
    UyixbSVBFHOYKEanhkjefwDtgIAlou.add_dir(UyixbSVBFHOYKEanhkjefwDtgIAlLP,sublabel='',img=UyixbSVBFHOYKEanhkjefwDtgIAlNc,infoLabels=UyixbSVBFHOYKEanhkjefwDtgIAlPo,isFolder=UyixbSVBFHOYKEanhkjefwDtgIAluT,params=UyixbSVBFHOYKEanhkjefwDtgIAlLX)
   xbmcplugin.setContent(UyixbSVBFHOYKEanhkjefwDtgIAlou._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(UyixbSVBFHOYKEanhkjefwDtgIAlou._addon_handle,cacheToDisc=UyixbSVBFHOYKEanhkjefwDtgIAlur)
  else:
   UyixbSVBFHOYKEanhkjefwDtgIAlNu={'programid':UyixbSVBFHOYKEanhkjefwDtgIAlNL,'programnm':UyixbSVBFHOYKEanhkjefwDtgIAlNo,'season':UyixbSVBFHOYKEanhkjefwDtgIAlPC,'programimg':UyixbSVBFHOYKEanhkjefwDtgIAlPc,}
   UyixbSVBFHOYKEanhkjefwDtgIAlou.dp_Episode_List(UyixbSVBFHOYKEanhkjefwDtgIAlNu)
 def dp_Episode_List(UyixbSVBFHOYKEanhkjefwDtgIAlou,args):
  UyixbSVBFHOYKEanhkjefwDtgIAlNL =args.get('programid')
  UyixbSVBFHOYKEanhkjefwDtgIAlNo =args.get('programnm')
  UyixbSVBFHOYKEanhkjefwDtgIAlNX =args.get('season')
  UyixbSVBFHOYKEanhkjefwDtgIAlNd =args.get('programimg')
  UyixbSVBFHOYKEanhkjefwDtgIAlNM=UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.Get_Episode_List(UyixbSVBFHOYKEanhkjefwDtgIAlNL,UyixbSVBFHOYKEanhkjefwDtgIAlNX)
  for UyixbSVBFHOYKEanhkjefwDtgIAlNP in UyixbSVBFHOYKEanhkjefwDtgIAlNM:
   UyixbSVBFHOYKEanhkjefwDtgIAlNW =UyixbSVBFHOYKEanhkjefwDtgIAlNP.get('title')
   UyixbSVBFHOYKEanhkjefwDtgIAlNz =UyixbSVBFHOYKEanhkjefwDtgIAlNP.get('id')
   UyixbSVBFHOYKEanhkjefwDtgIAlPu =UyixbSVBFHOYKEanhkjefwDtgIAlNP.get('asis')
   UyixbSVBFHOYKEanhkjefwDtgIAlPc =UyixbSVBFHOYKEanhkjefwDtgIAlNP.get('thumbnail')
   UyixbSVBFHOYKEanhkjefwDtgIAlPq =UyixbSVBFHOYKEanhkjefwDtgIAlNP.get('mpaa')
   UyixbSVBFHOYKEanhkjefwDtgIAlPW =UyixbSVBFHOYKEanhkjefwDtgIAlNP.get('duration')
   UyixbSVBFHOYKEanhkjefwDtgIAlPG =UyixbSVBFHOYKEanhkjefwDtgIAlNP.get('year')
   UyixbSVBFHOYKEanhkjefwDtgIAlNm =UyixbSVBFHOYKEanhkjefwDtgIAlNP.get('episode')
   UyixbSVBFHOYKEanhkjefwDtgIAlPp =UyixbSVBFHOYKEanhkjefwDtgIAlNP.get('genreList')
   UyixbSVBFHOYKEanhkjefwDtgIAlNq =UyixbSVBFHOYKEanhkjefwDtgIAlNP.get('desc')
   UyixbSVBFHOYKEanhkjefwDtgIAlNR ='%sx%s'%(UyixbSVBFHOYKEanhkjefwDtgIAlNX,UyixbSVBFHOYKEanhkjefwDtgIAlNm)
   UyixbSVBFHOYKEanhkjefwDtgIAlLP ='%s. %s'%(UyixbSVBFHOYKEanhkjefwDtgIAlNR,UyixbSVBFHOYKEanhkjefwDtgIAlNW)
   UyixbSVBFHOYKEanhkjefwDtgIAlPo={'mediatype':'episode','mpaa':UyixbSVBFHOYKEanhkjefwDtgIAlPq,'genre':UyixbSVBFHOYKEanhkjefwDtgIAlPp,'duration':UyixbSVBFHOYKEanhkjefwDtgIAlPW,'year':UyixbSVBFHOYKEanhkjefwDtgIAlPG,'plot':'%s (%s)\n\n%s'%(UyixbSVBFHOYKEanhkjefwDtgIAlNo,UyixbSVBFHOYKEanhkjefwDtgIAlNR,UyixbSVBFHOYKEanhkjefwDtgIAlNq),}
   UyixbSVBFHOYKEanhkjefwDtgIAlLX={'mode':'VOD','programid':UyixbSVBFHOYKEanhkjefwDtgIAlNL,'programnm':UyixbSVBFHOYKEanhkjefwDtgIAlNo,'title':UyixbSVBFHOYKEanhkjefwDtgIAlLP,'season':UyixbSVBFHOYKEanhkjefwDtgIAlNX,'id':UyixbSVBFHOYKEanhkjefwDtgIAlNz,'asis':UyixbSVBFHOYKEanhkjefwDtgIAlPu,'thumbnail':UyixbSVBFHOYKEanhkjefwDtgIAlPc,'programimg':UyixbSVBFHOYKEanhkjefwDtgIAlNd,}
   UyixbSVBFHOYKEanhkjefwDtgIAlou.add_dir(UyixbSVBFHOYKEanhkjefwDtgIAlLP,sublabel='',img=UyixbSVBFHOYKEanhkjefwDtgIAlPc,infoLabels=UyixbSVBFHOYKEanhkjefwDtgIAlPo,isFolder=UyixbSVBFHOYKEanhkjefwDtgIAlur,params=UyixbSVBFHOYKEanhkjefwDtgIAlLX)
  xbmcplugin.setContent(UyixbSVBFHOYKEanhkjefwDtgIAlou._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(UyixbSVBFHOYKEanhkjefwDtgIAlou._addon_handle,cacheToDisc=UyixbSVBFHOYKEanhkjefwDtgIAlur)
 def play_VIDEO(UyixbSVBFHOYKEanhkjefwDtgIAlou,args):
  UyixbSVBFHOYKEanhkjefwDtgIAlNG =args.get('id')
  UyixbSVBFHOYKEanhkjefwDtgIAlPu =args.get('asis')
  if UyixbSVBFHOYKEanhkjefwDtgIAlPu in['HIGHLIGHT']:
   UyixbSVBFHOYKEanhkjefwDtgIAlNC,UyixbSVBFHOYKEanhkjefwDtgIAlNp=UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.GetEventURL(UyixbSVBFHOYKEanhkjefwDtgIAlNG,UyixbSVBFHOYKEanhkjefwDtgIAlPu)
  elif UyixbSVBFHOYKEanhkjefwDtgIAlPu in['LIVE']:
   UyixbSVBFHOYKEanhkjefwDtgIAlNC,UyixbSVBFHOYKEanhkjefwDtgIAlNp=UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.GetEventURL_Live(UyixbSVBFHOYKEanhkjefwDtgIAlNG,UyixbSVBFHOYKEanhkjefwDtgIAlPu)
  else:
   UyixbSVBFHOYKEanhkjefwDtgIAlNC,UyixbSVBFHOYKEanhkjefwDtgIAlNp=UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.GetBroadURL(UyixbSVBFHOYKEanhkjefwDtgIAlNG)
  UyixbSVBFHOYKEanhkjefwDtgIAlou.addon_log('asis, url : %s - %s - %s'%(UyixbSVBFHOYKEanhkjefwDtgIAlPu,UyixbSVBFHOYKEanhkjefwDtgIAlNG,UyixbSVBFHOYKEanhkjefwDtgIAlNC))
  if UyixbSVBFHOYKEanhkjefwDtgIAlNC=='':
   if UyixbSVBFHOYKEanhkjefwDtgIAlNp=='':
    UyixbSVBFHOYKEanhkjefwDtgIAlou.addon_noti(__language__(30907).encode('utf8'))
   else:
    UyixbSVBFHOYKEanhkjefwDtgIAlou.addon_log('drm_license_1 : %s'%(UyixbSVBFHOYKEanhkjefwDtgIAlNp))
    UyixbSVBFHOYKEanhkjefwDtgIAlou.addon_noti(UyixbSVBFHOYKEanhkjefwDtgIAlNp)
   return
  else:
   UyixbSVBFHOYKEanhkjefwDtgIAlou.addon_log('drm_license : %s'%(UyixbSVBFHOYKEanhkjefwDtgIAlNp))
  UyixbSVBFHOYKEanhkjefwDtgIAlNJ='PCID=%s;token=%s;member_srl=%s;NEXT_LOCALE=%s;bm_mi=%s;ak_bmsc=%s;bm_sv=%s;session_web_id=%s;device_id=%s'%(UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.CP['SESSION']['PCID'],UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.CP['SESSION']['token'],UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.CP['SESSION']['member_srl'],UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.CP['SESSION']['NEXT_LOCALE'],UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.CP['SESSION']['bm_mi'],UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.CP['SESSION']['ak_bmsc'],UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.CP['SESSION']['bm_sv'],UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.CP['SESSION']['session_web_id'],UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.CP['SESSION']['device_id'],)
  if UyixbSVBFHOYKEanhkjefwDtgIAlPu in['EPISODE']:
   UyixbSVBFHOYKEanhkjefwDtgIAlNr='https://www.coupangplay.com/play/{}/episode?titleId={}&type=EPISODE&sourceType=page_discover_title_detail%3Apage_discover_feed'.format(UyixbSVBFHOYKEanhkjefwDtgIAlNG,UyixbSVBFHOYKEanhkjefwDtgIAlNG)
  elif UyixbSVBFHOYKEanhkjefwDtgIAlPu in['MOVIE']:
   UyixbSVBFHOYKEanhkjefwDtgIAlNr='https://www.coupangplay.com/play/{}/movie?sourceType=page_discover_feed'.format(UyixbSVBFHOYKEanhkjefwDtgIAlNG)
  else:
   UyixbSVBFHOYKEanhkjefwDtgIAlNr='https://www.coupangplay.com/play/'+UyixbSVBFHOYKEanhkjefwDtgIAlNG 
  UyixbSVBFHOYKEanhkjefwDtgIAlNT,UyixbSVBFHOYKEanhkjefwDtgIAlNs,UyixbSVBFHOYKEanhkjefwDtgIAlNQ=UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.Make_authHeader()
  UyixbSVBFHOYKEanhkjefwDtgIAlNv=UyixbSVBFHOYKEanhkjefwDtgIAlNC 
  UyixbSVBFHOYKEanhkjefwDtgIAlou.addon_log('tobe, surl : %s'%(UyixbSVBFHOYKEanhkjefwDtgIAlNv))
  UyixbSVBFHOYKEanhkjefwDtgIAlco=xbmcgui.ListItem(path=UyixbSVBFHOYKEanhkjefwDtgIAlNv)
  UyixbSVBFHOYKEanhkjefwDtgIAlcL=UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.Get_Url_PostFix(UyixbSVBFHOYKEanhkjefwDtgIAlNC) 
  UyixbSVBFHOYKEanhkjefwDtgIAlou.addon_log('post_fix : '+UyixbSVBFHOYKEanhkjefwDtgIAlcL)
  if UyixbSVBFHOYKEanhkjefwDtgIAlcL=='m3u8':
   UyixbSVBFHOYKEanhkjefwDtgIAlcP ='hls' 
  else:
   UyixbSVBFHOYKEanhkjefwDtgIAlcP ='mpd' 
  if UyixbSVBFHOYKEanhkjefwDtgIAlNp:
   UyixbSVBFHOYKEanhkjefwDtgIAlcN =UyixbSVBFHOYKEanhkjefwDtgIAlNp 
   UyixbSVBFHOYKEanhkjefwDtgIAlcu ='com.widevine.alpha'
   UyixbSVBFHOYKEanhkjefwDtgIAlcX={'traceparent':UyixbSVBFHOYKEanhkjefwDtgIAlNT,'tracestate':UyixbSVBFHOYKEanhkjefwDtgIAlNs,'newrelic':UyixbSVBFHOYKEanhkjefwDtgIAlNQ,'User-Agent':UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.USER_AGENT,'Referer':UyixbSVBFHOYKEanhkjefwDtgIAlNr,'Cookie':UyixbSVBFHOYKEanhkjefwDtgIAlNJ,}
   UyixbSVBFHOYKEanhkjefwDtgIAlcd=UyixbSVBFHOYKEanhkjefwDtgIAlcN+'|'+urllib.parse.urlencode(UyixbSVBFHOYKEanhkjefwDtgIAlcX)+'|R{SSM}|'
   UyixbSVBFHOYKEanhkjefwDtgIAlco.setProperty('inputstream','inputstream.adaptive')
   UyixbSVBFHOYKEanhkjefwDtgIAlco.setProperty('inputstream.adaptive.manifest_type',UyixbSVBFHOYKEanhkjefwDtgIAlcP)
   UyixbSVBFHOYKEanhkjefwDtgIAlco.setProperty('inputstream.adaptive.license_type',UyixbSVBFHOYKEanhkjefwDtgIAlcu)
   UyixbSVBFHOYKEanhkjefwDtgIAlco.setProperty('inputstream.adaptive.license_key',UyixbSVBFHOYKEanhkjefwDtgIAlcd)
   UyixbSVBFHOYKEanhkjefwDtgIAlco.setProperty('inputstream.adaptive.stream_headers','User-Agent={}&Cookie={}&Referer={}&traceparent={}&tracestate={}&newrelic={}'.format(UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.USER_AGENT,UyixbSVBFHOYKEanhkjefwDtgIAlNJ,UyixbSVBFHOYKEanhkjefwDtgIAlNr,UyixbSVBFHOYKEanhkjefwDtgIAlNT,UyixbSVBFHOYKEanhkjefwDtgIAlNs,UyixbSVBFHOYKEanhkjefwDtgIAlNQ))
   UyixbSVBFHOYKEanhkjefwDtgIAlco.setMimeType('application/dash+xml')
   UyixbSVBFHOYKEanhkjefwDtgIAlco.setContentLookup(UyixbSVBFHOYKEanhkjefwDtgIAlur)
  else:
   UyixbSVBFHOYKEanhkjefwDtgIAlco.setContentLookup(UyixbSVBFHOYKEanhkjefwDtgIAlur)
   UyixbSVBFHOYKEanhkjefwDtgIAlco.setMimeType('application/x-mpegURL')
   UyixbSVBFHOYKEanhkjefwDtgIAlco.setProperty('inputstream','inputstream.adaptive')
   UyixbSVBFHOYKEanhkjefwDtgIAlco.setProperty('inputstream.adaptive.manifest_type',UyixbSVBFHOYKEanhkjefwDtgIAlcP)
   UyixbSVBFHOYKEanhkjefwDtgIAlco.setProperty('inputstream.adaptive.stream_headers','User-Agent={}&Cookie={}&Referer={}&traceparent={}&tracestate={}&newrelic={}'.format(UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.USER_AGENT,UyixbSVBFHOYKEanhkjefwDtgIAlNJ,UyixbSVBFHOYKEanhkjefwDtgIAlNr,UyixbSVBFHOYKEanhkjefwDtgIAlNT,UyixbSVBFHOYKEanhkjefwDtgIAlNs,UyixbSVBFHOYKEanhkjefwDtgIAlNQ))
  xbmcplugin.setResolvedUrl(UyixbSVBFHOYKEanhkjefwDtgIAlou._addon_handle,UyixbSVBFHOYKEanhkjefwDtgIAluT,UyixbSVBFHOYKEanhkjefwDtgIAlco)
  try:
   if UyixbSVBFHOYKEanhkjefwDtgIAlPu=='MOVIE':
    UyixbSVBFHOYKEanhkjefwDtgIAlcM='movie'
    UyixbSVBFHOYKEanhkjefwDtgIAlLX={'code':UyixbSVBFHOYKEanhkjefwDtgIAlNG,'asis':UyixbSVBFHOYKEanhkjefwDtgIAlPu,'title':args.get('title'),'img':args.get('thumbnail'),}
    UyixbSVBFHOYKEanhkjefwDtgIAlou.Save_Watched_List(UyixbSVBFHOYKEanhkjefwDtgIAlcM,UyixbSVBFHOYKEanhkjefwDtgIAlLX)
   elif UyixbSVBFHOYKEanhkjefwDtgIAlPu=='TVSHOW':
    UyixbSVBFHOYKEanhkjefwDtgIAlcM='tvshow'
    UyixbSVBFHOYKEanhkjefwDtgIAlLX={'code':args.get('programid'),'asis':UyixbSVBFHOYKEanhkjefwDtgIAlPu,'title':'%s <%s>'%(args.get('title'),args.get('programnm')),'img':args.get('programimg'),}
    UyixbSVBFHOYKEanhkjefwDtgIAlou.Save_Watched_List(UyixbSVBFHOYKEanhkjefwDtgIAlcM,UyixbSVBFHOYKEanhkjefwDtgIAlLX)
  except:
   UyixbSVBFHOYKEanhkjefwDtgIAluJ
 def dp_Global_Search(UyixbSVBFHOYKEanhkjefwDtgIAlou,args):
  UyixbSVBFHOYKEanhkjefwDtgIAlPJ=args.get('mode')
  if UyixbSVBFHOYKEanhkjefwDtgIAlPJ=='TOTAL_SEARCH':
   UyixbSVBFHOYKEanhkjefwDtgIAlcW='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   UyixbSVBFHOYKEanhkjefwDtgIAlcW='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(UyixbSVBFHOYKEanhkjefwDtgIAlcW)
 def dp_Bookmark_Menu(UyixbSVBFHOYKEanhkjefwDtgIAlou,args):
  UyixbSVBFHOYKEanhkjefwDtgIAlcW='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(UyixbSVBFHOYKEanhkjefwDtgIAlcW)
 def dp_Search_List(UyixbSVBFHOYKEanhkjefwDtgIAlou,args):
  UyixbSVBFHOYKEanhkjefwDtgIAlPz =UyixbSVBFHOYKEanhkjefwDtgIAluv(args.get('page'))
  if 'search_key' in args:
   UyixbSVBFHOYKEanhkjefwDtgIAlcz=args.get('search_key')
  else:
   UyixbSVBFHOYKEanhkjefwDtgIAlcz=UyixbSVBFHOYKEanhkjefwDtgIAlou.get_keyboard_input(__language__(30908).encode('utf-8'))
   if not UyixbSVBFHOYKEanhkjefwDtgIAlcz:
    return
  UyixbSVBFHOYKEanhkjefwDtgIAlcm,UyixbSVBFHOYKEanhkjefwDtgIAlPm=UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.Get_Search_List(UyixbSVBFHOYKEanhkjefwDtgIAlcz,UyixbSVBFHOYKEanhkjefwDtgIAlPz)
  for UyixbSVBFHOYKEanhkjefwDtgIAlcq in UyixbSVBFHOYKEanhkjefwDtgIAlcm:
   UyixbSVBFHOYKEanhkjefwDtgIAlXN =UyixbSVBFHOYKEanhkjefwDtgIAlcq.get('id')
   UyixbSVBFHOYKEanhkjefwDtgIAlLP =UyixbSVBFHOYKEanhkjefwDtgIAlcq.get('title')
   UyixbSVBFHOYKEanhkjefwDtgIAlPu =UyixbSVBFHOYKEanhkjefwDtgIAlcq.get('asis')
   UyixbSVBFHOYKEanhkjefwDtgIAlPc =UyixbSVBFHOYKEanhkjefwDtgIAlcq.get('thumbnail')
   UyixbSVBFHOYKEanhkjefwDtgIAlPq =UyixbSVBFHOYKEanhkjefwDtgIAlcq.get('mpaa')
   UyixbSVBFHOYKEanhkjefwDtgIAlPG =UyixbSVBFHOYKEanhkjefwDtgIAlcq.get('year')
   UyixbSVBFHOYKEanhkjefwDtgIAlPW =UyixbSVBFHOYKEanhkjefwDtgIAlcq.get('duration')
   UyixbSVBFHOYKEanhkjefwDtgIAlPR =UyixbSVBFHOYKEanhkjefwDtgIAlcq.get('badge')
   if UyixbSVBFHOYKEanhkjefwDtgIAlPu=='TVSHOW': 
    UyixbSVBFHOYKEanhkjefwDtgIAlPJ ='SEASON_LIST'
    UyixbSVBFHOYKEanhkjefwDtgIAlPo={'mediatype':'tvshow','title':UyixbSVBFHOYKEanhkjefwDtgIAlLP,'mpaa':UyixbSVBFHOYKEanhkjefwDtgIAlPq,'year':UyixbSVBFHOYKEanhkjefwDtgIAlPG,'plot':'Year : %s'%(UyixbSVBFHOYKEanhkjefwDtgIAlPG),}
    UyixbSVBFHOYKEanhkjefwDtgIAlLd =UyixbSVBFHOYKEanhkjefwDtgIAluT
   elif UyixbSVBFHOYKEanhkjefwDtgIAlPu=='MOVIE':
    UyixbSVBFHOYKEanhkjefwDtgIAlPJ ='MOVIE'
    UyixbSVBFHOYKEanhkjefwDtgIAlPo={'mediatype':'movie','title':UyixbSVBFHOYKEanhkjefwDtgIAlLP,'mpaa':UyixbSVBFHOYKEanhkjefwDtgIAlPq,'duration':UyixbSVBFHOYKEanhkjefwDtgIAlPW,'year':UyixbSVBFHOYKEanhkjefwDtgIAlPG,'plot':'(%s)'%(UyixbSVBFHOYKEanhkjefwDtgIAlPq),}
    UyixbSVBFHOYKEanhkjefwDtgIAlLd =UyixbSVBFHOYKEanhkjefwDtgIAlur
    UyixbSVBFHOYKEanhkjefwDtgIAlLP +=' (%s)'%(UyixbSVBFHOYKEanhkjefwDtgIAlXP(UyixbSVBFHOYKEanhkjefwDtgIAlPG))
   elif UyixbSVBFHOYKEanhkjefwDtgIAlPu=='HIGHLIGHT':
    UyixbSVBFHOYKEanhkjefwDtgIAlPJ ='HIGHLIGHT'
    UyixbSVBFHOYKEanhkjefwDtgIAlPo={'mediatype':'episode','title':UyixbSVBFHOYKEanhkjefwDtgIAlLP,'duration':UyixbSVBFHOYKEanhkjefwDtgIAlPW,'plot':UyixbSVBFHOYKEanhkjefwDtgIAlPJ,}
    UyixbSVBFHOYKEanhkjefwDtgIAlLd =UyixbSVBFHOYKEanhkjefwDtgIAlur
   elif UyixbSVBFHOYKEanhkjefwDtgIAlPu=='LIVE':
    UyixbSVBFHOYKEanhkjefwDtgIAlPJ ='LIVE'
    UyixbSVBFHOYKEanhkjefwDtgIAlPo={'mediatype':'episode','title':UyixbSVBFHOYKEanhkjefwDtgIAlLP,'plot':UyixbSVBFHOYKEanhkjefwDtgIAlPJ,}
    UyixbSVBFHOYKEanhkjefwDtgIAlLd =UyixbSVBFHOYKEanhkjefwDtgIAlur
   UyixbSVBFHOYKEanhkjefwDtgIAlLX={'mode':UyixbSVBFHOYKEanhkjefwDtgIAlPJ,'id':UyixbSVBFHOYKEanhkjefwDtgIAlXN,'asis':UyixbSVBFHOYKEanhkjefwDtgIAlPu,'seasonList':'','title':UyixbSVBFHOYKEanhkjefwDtgIAlLP,'thumbnail':json.dumps(UyixbSVBFHOYKEanhkjefwDtgIAlPc,separators=(',',':')),'year':UyixbSVBFHOYKEanhkjefwDtgIAlPG,}
   if UyixbSVBFHOYKEanhkjefwDtgIAlou.get_settings_makebookmark()and UyixbSVBFHOYKEanhkjefwDtgIAlPu not in['HIGHLIGHT','']:
    UyixbSVBFHOYKEanhkjefwDtgIAlPr={'videoid':UyixbSVBFHOYKEanhkjefwDtgIAlXN,'vidtype':'movie' if UyixbSVBFHOYKEanhkjefwDtgIAlPu=='MOVIE' else 'tvshow','vtitle':UyixbSVBFHOYKEanhkjefwDtgIAlLP,'vsubtitle':'',}
    UyixbSVBFHOYKEanhkjefwDtgIAlPT=json.dumps(UyixbSVBFHOYKEanhkjefwDtgIAlPr)
    UyixbSVBFHOYKEanhkjefwDtgIAlPT=urllib.parse.quote(UyixbSVBFHOYKEanhkjefwDtgIAlPT)
    UyixbSVBFHOYKEanhkjefwDtgIAlPs='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(UyixbSVBFHOYKEanhkjefwDtgIAlPT)
    UyixbSVBFHOYKEanhkjefwDtgIAlPQ=[('(통합) 찜 영상에 추가',UyixbSVBFHOYKEanhkjefwDtgIAlPs)]
   else:
    UyixbSVBFHOYKEanhkjefwDtgIAlPQ=UyixbSVBFHOYKEanhkjefwDtgIAluJ
   UyixbSVBFHOYKEanhkjefwDtgIAlou.add_dir(UyixbSVBFHOYKEanhkjefwDtgIAlLP,sublabel=UyixbSVBFHOYKEanhkjefwDtgIAlPR,img=UyixbSVBFHOYKEanhkjefwDtgIAlPc,infoLabels=UyixbSVBFHOYKEanhkjefwDtgIAlPo,isFolder=UyixbSVBFHOYKEanhkjefwDtgIAlLd,params=UyixbSVBFHOYKEanhkjefwDtgIAlLX,ContextMenu=UyixbSVBFHOYKEanhkjefwDtgIAlPQ)
  if UyixbSVBFHOYKEanhkjefwDtgIAlPm:
   UyixbSVBFHOYKEanhkjefwDtgIAlLX={}
   UyixbSVBFHOYKEanhkjefwDtgIAlLX['mode'] ='LOCAL_SEARCH'
   UyixbSVBFHOYKEanhkjefwDtgIAlLX['search_key']=UyixbSVBFHOYKEanhkjefwDtgIAlcz
   UyixbSVBFHOYKEanhkjefwDtgIAlLX['page'] =UyixbSVBFHOYKEanhkjefwDtgIAlXP(UyixbSVBFHOYKEanhkjefwDtgIAlPz+1)
   UyixbSVBFHOYKEanhkjefwDtgIAlLP='[B]%s >>[/B]'%'다음 페이지'
   UyixbSVBFHOYKEanhkjefwDtgIAlPv=UyixbSVBFHOYKEanhkjefwDtgIAlXP(UyixbSVBFHOYKEanhkjefwDtgIAlPz+1)
   UyixbSVBFHOYKEanhkjefwDtgIAlLu=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   UyixbSVBFHOYKEanhkjefwDtgIAlou.add_dir(UyixbSVBFHOYKEanhkjefwDtgIAlLP,sublabel=UyixbSVBFHOYKEanhkjefwDtgIAlPv,img=UyixbSVBFHOYKEanhkjefwDtgIAlLu,infoLabels=UyixbSVBFHOYKEanhkjefwDtgIAluJ,isFolder=UyixbSVBFHOYKEanhkjefwDtgIAluT,params=UyixbSVBFHOYKEanhkjefwDtgIAlLX)
  xbmcplugin.setContent(UyixbSVBFHOYKEanhkjefwDtgIAlou._addon_handle,'movies')
  xbmcplugin.endOfDirectory(UyixbSVBFHOYKEanhkjefwDtgIAlou._addon_handle,cacheToDisc=UyixbSVBFHOYKEanhkjefwDtgIAluT)
  if args.get('historyyn')=='Y':UyixbSVBFHOYKEanhkjefwDtgIAlou.Save_Searched_List(UyixbSVBFHOYKEanhkjefwDtgIAlcz)
 def Load_List_File(UyixbSVBFHOYKEanhkjefwDtgIAlou,UyixbSVBFHOYKEanhkjefwDtgIAlcM): 
  try:
   if UyixbSVBFHOYKEanhkjefwDtgIAlcM=='search':
    UyixbSVBFHOYKEanhkjefwDtgIAlcR=UyixbSVBFHOYKEanhkjefwDtgIAloc
   elif UyixbSVBFHOYKEanhkjefwDtgIAlcM in['tvshow','movie']:
    UyixbSVBFHOYKEanhkjefwDtgIAlcR=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%UyixbSVBFHOYKEanhkjefwDtgIAlcM))
   else:
    return[]
   fp=UyixbSVBFHOYKEanhkjefwDtgIAlXo(UyixbSVBFHOYKEanhkjefwDtgIAlcR,'r',-1,'utf-8')
   UyixbSVBFHOYKEanhkjefwDtgIAlcG=fp.readlines()
   fp.close()
  except:
   UyixbSVBFHOYKEanhkjefwDtgIAlcG=[]
  return UyixbSVBFHOYKEanhkjefwDtgIAlcG
 def Save_Watched_List(UyixbSVBFHOYKEanhkjefwDtgIAlou,UyixbSVBFHOYKEanhkjefwDtgIAlcM,UyixbSVBFHOYKEanhkjefwDtgIAloM):
  try:
   UyixbSVBFHOYKEanhkjefwDtgIAlcC=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%UyixbSVBFHOYKEanhkjefwDtgIAlcM))
   UyixbSVBFHOYKEanhkjefwDtgIAlcp=UyixbSVBFHOYKEanhkjefwDtgIAlou.Load_List_File(UyixbSVBFHOYKEanhkjefwDtgIAlcM) 
   fp=UyixbSVBFHOYKEanhkjefwDtgIAlXo(UyixbSVBFHOYKEanhkjefwDtgIAlcC,'w',-1,'utf-8')
   UyixbSVBFHOYKEanhkjefwDtgIAlcJ=urllib.parse.urlencode(UyixbSVBFHOYKEanhkjefwDtgIAloM)
   UyixbSVBFHOYKEanhkjefwDtgIAlcJ=UyixbSVBFHOYKEanhkjefwDtgIAlcJ+'\n'
   fp.write(UyixbSVBFHOYKEanhkjefwDtgIAlcJ)
   UyixbSVBFHOYKEanhkjefwDtgIAlcr=0
   for UyixbSVBFHOYKEanhkjefwDtgIAlcT in UyixbSVBFHOYKEanhkjefwDtgIAlcp:
    UyixbSVBFHOYKEanhkjefwDtgIAlcs=UyixbSVBFHOYKEanhkjefwDtgIAluQ(urllib.parse.parse_qsl(UyixbSVBFHOYKEanhkjefwDtgIAlcT))
    UyixbSVBFHOYKEanhkjefwDtgIAlcQ=UyixbSVBFHOYKEanhkjefwDtgIAloM.get('code').strip()
    UyixbSVBFHOYKEanhkjefwDtgIAlcv=UyixbSVBFHOYKEanhkjefwDtgIAlcs.get('code').strip()
    if UyixbSVBFHOYKEanhkjefwDtgIAlcQ!=UyixbSVBFHOYKEanhkjefwDtgIAlcv:
     fp.write(UyixbSVBFHOYKEanhkjefwDtgIAlcT)
     UyixbSVBFHOYKEanhkjefwDtgIAlcr+=1
     if UyixbSVBFHOYKEanhkjefwDtgIAlcr>=50:break
   fp.close()
  except:
   UyixbSVBFHOYKEanhkjefwDtgIAluJ
 def Save_Searched_List(UyixbSVBFHOYKEanhkjefwDtgIAlou,UyixbSVBFHOYKEanhkjefwDtgIAlcz):
  try:
   UyixbSVBFHOYKEanhkjefwDtgIAlcz=UyixbSVBFHOYKEanhkjefwDtgIAlcz.strip()
   UyixbSVBFHOYKEanhkjefwDtgIAlcp=UyixbSVBFHOYKEanhkjefwDtgIAlou.Load_List_File('search') 
   fp=UyixbSVBFHOYKEanhkjefwDtgIAlXo(UyixbSVBFHOYKEanhkjefwDtgIAloc,'w',-1,'utf-8')
   fp.write(UyixbSVBFHOYKEanhkjefwDtgIAlcz+'\n')
   UyixbSVBFHOYKEanhkjefwDtgIAlcr=0
   for UyixbSVBFHOYKEanhkjefwDtgIAlcT in UyixbSVBFHOYKEanhkjefwDtgIAlcp:
    UyixbSVBFHOYKEanhkjefwDtgIAlcT=UyixbSVBFHOYKEanhkjefwDtgIAlcT.strip()
    if UyixbSVBFHOYKEanhkjefwDtgIAlcz!=UyixbSVBFHOYKEanhkjefwDtgIAlcT:
     fp.write(UyixbSVBFHOYKEanhkjefwDtgIAlcT+'\n')
     UyixbSVBFHOYKEanhkjefwDtgIAlcr+=1
     if UyixbSVBFHOYKEanhkjefwDtgIAlcr>=50:break
   fp.close()
  except:
   UyixbSVBFHOYKEanhkjefwDtgIAluJ
 def dp_Search_History(UyixbSVBFHOYKEanhkjefwDtgIAlou,args):
  UyixbSVBFHOYKEanhkjefwDtgIAluo=UyixbSVBFHOYKEanhkjefwDtgIAlou.Load_List_File('search')
  for UyixbSVBFHOYKEanhkjefwDtgIAluL in UyixbSVBFHOYKEanhkjefwDtgIAluo:
   UyixbSVBFHOYKEanhkjefwDtgIAluL=UyixbSVBFHOYKEanhkjefwDtgIAluL.strip()
   UyixbSVBFHOYKEanhkjefwDtgIAlLX={'mode':'LOCAL_SEARCH','search_key':UyixbSVBFHOYKEanhkjefwDtgIAluL,'page':'1','historyyn':'Y',}
   UyixbSVBFHOYKEanhkjefwDtgIAluP={'mode':'SEARCH_REMOVE','stype':'ONE','skey':UyixbSVBFHOYKEanhkjefwDtgIAluL,}
   UyixbSVBFHOYKEanhkjefwDtgIAluN=urllib.parse.urlencode(UyixbSVBFHOYKEanhkjefwDtgIAluP)
   UyixbSVBFHOYKEanhkjefwDtgIAlPQ=[('선택된 검색어 ( %s ) 삭제'%(UyixbSVBFHOYKEanhkjefwDtgIAluL),'RunPlugin(plugin://plugin.video.coupangm/?%s)'%(UyixbSVBFHOYKEanhkjefwDtgIAluN))]
   UyixbSVBFHOYKEanhkjefwDtgIAlou.add_dir(UyixbSVBFHOYKEanhkjefwDtgIAluL,sublabel='',img=UyixbSVBFHOYKEanhkjefwDtgIAluJ,infoLabels=UyixbSVBFHOYKEanhkjefwDtgIAluJ,isFolder=UyixbSVBFHOYKEanhkjefwDtgIAluT,params=UyixbSVBFHOYKEanhkjefwDtgIAlLX,ContextMenu=UyixbSVBFHOYKEanhkjefwDtgIAlPQ)
  UyixbSVBFHOYKEanhkjefwDtgIAlPo={'plot':'검색목록 전체를 삭제합니다.'}
  UyixbSVBFHOYKEanhkjefwDtgIAlLP='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  UyixbSVBFHOYKEanhkjefwDtgIAlLX={'mode':'SEARCH_REMOVE','stype':'ALL','skey':'-',}
  UyixbSVBFHOYKEanhkjefwDtgIAlLu=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  UyixbSVBFHOYKEanhkjefwDtgIAlou.add_dir(UyixbSVBFHOYKEanhkjefwDtgIAlLP,sublabel='',img=UyixbSVBFHOYKEanhkjefwDtgIAlLu,infoLabels=UyixbSVBFHOYKEanhkjefwDtgIAlPo,isFolder=UyixbSVBFHOYKEanhkjefwDtgIAlur,params=UyixbSVBFHOYKEanhkjefwDtgIAlLX,isLink=UyixbSVBFHOYKEanhkjefwDtgIAluT)
  xbmcplugin.endOfDirectory(UyixbSVBFHOYKEanhkjefwDtgIAlou._addon_handle,cacheToDisc=UyixbSVBFHOYKEanhkjefwDtgIAlur)
 def dp_Listfile_Delete(UyixbSVBFHOYKEanhkjefwDtgIAlou,args):
  UyixbSVBFHOYKEanhkjefwDtgIAlcM=args.get('stype')
  UyixbSVBFHOYKEanhkjefwDtgIAluc =args.get('skey')
  UyixbSVBFHOYKEanhkjefwDtgIAloz=xbmcgui.Dialog()
  if UyixbSVBFHOYKEanhkjefwDtgIAlcM=='ALL':
   UyixbSVBFHOYKEanhkjefwDtgIAlLz=UyixbSVBFHOYKEanhkjefwDtgIAloz.yesno(__language__(30911).encode('utf8'),__language__(30906).encode('utf8'))
  elif UyixbSVBFHOYKEanhkjefwDtgIAlcM=='ONE':
   UyixbSVBFHOYKEanhkjefwDtgIAlLz=UyixbSVBFHOYKEanhkjefwDtgIAloz.yesno(__language__(30912).encode('utf8'),__language__(30906).encode('utf8'))
  elif UyixbSVBFHOYKEanhkjefwDtgIAlcM in['tvshow','movie']:
   UyixbSVBFHOYKEanhkjefwDtgIAlLz=UyixbSVBFHOYKEanhkjefwDtgIAloz.yesno(__language__(30913).encode('utf8'),__language__(30906).encode('utf8'))
  if UyixbSVBFHOYKEanhkjefwDtgIAlLz==UyixbSVBFHOYKEanhkjefwDtgIAlur:sys.exit()
  UyixbSVBFHOYKEanhkjefwDtgIAlou.Delete_List_File(UyixbSVBFHOYKEanhkjefwDtgIAlcM,skey=UyixbSVBFHOYKEanhkjefwDtgIAluc)
  xbmc.executebuiltin("Container.Refresh")
 def Delete_List_File(UyixbSVBFHOYKEanhkjefwDtgIAlou,UyixbSVBFHOYKEanhkjefwDtgIAlcM,skey='-'):
  if UyixbSVBFHOYKEanhkjefwDtgIAlcM=='ALL':
   try:
    UyixbSVBFHOYKEanhkjefwDtgIAlcR=UyixbSVBFHOYKEanhkjefwDtgIAloc
    fp=UyixbSVBFHOYKEanhkjefwDtgIAlXo(UyixbSVBFHOYKEanhkjefwDtgIAlcR,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    UyixbSVBFHOYKEanhkjefwDtgIAluJ
  elif UyixbSVBFHOYKEanhkjefwDtgIAlcM=='ONE':
   try:
    UyixbSVBFHOYKEanhkjefwDtgIAlcR=UyixbSVBFHOYKEanhkjefwDtgIAloc
    UyixbSVBFHOYKEanhkjefwDtgIAlcp=UyixbSVBFHOYKEanhkjefwDtgIAlou.Load_List_File('search') 
    fp=UyixbSVBFHOYKEanhkjefwDtgIAlXo(UyixbSVBFHOYKEanhkjefwDtgIAlcR,'w',-1,'utf-8')
    for UyixbSVBFHOYKEanhkjefwDtgIAlcT in UyixbSVBFHOYKEanhkjefwDtgIAlcp:
     if skey!=UyixbSVBFHOYKEanhkjefwDtgIAlcT.strip():
      fp.write(UyixbSVBFHOYKEanhkjefwDtgIAlcT)
    fp.close()
   except:
    UyixbSVBFHOYKEanhkjefwDtgIAluJ
  elif UyixbSVBFHOYKEanhkjefwDtgIAlcM in['tvshow','movie']:
   try:
    UyixbSVBFHOYKEanhkjefwDtgIAlcR=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%UyixbSVBFHOYKEanhkjefwDtgIAlcM))
    fp=UyixbSVBFHOYKEanhkjefwDtgIAlXo(UyixbSVBFHOYKEanhkjefwDtgIAlcR,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    UyixbSVBFHOYKEanhkjefwDtgIAluJ
 def dp_Watch_List(UyixbSVBFHOYKEanhkjefwDtgIAlou,args):
  UyixbSVBFHOYKEanhkjefwDtgIAlcM =args.get('stype')
  if UyixbSVBFHOYKEanhkjefwDtgIAlcM in['',UyixbSVBFHOYKEanhkjefwDtgIAluJ]:
   for UyixbSVBFHOYKEanhkjefwDtgIAluX in UyixbSVBFHOYKEanhkjefwDtgIAloN:
    UyixbSVBFHOYKEanhkjefwDtgIAlLP=UyixbSVBFHOYKEanhkjefwDtgIAluX.get('title')
    UyixbSVBFHOYKEanhkjefwDtgIAlLX={'mode':UyixbSVBFHOYKEanhkjefwDtgIAluX.get('mode'),'stype':UyixbSVBFHOYKEanhkjefwDtgIAluX.get('stype'),}
    UyixbSVBFHOYKEanhkjefwDtgIAlou.add_dir(UyixbSVBFHOYKEanhkjefwDtgIAlLP,sublabel='',img='',infoLabels=UyixbSVBFHOYKEanhkjefwDtgIAluJ,isFolder=UyixbSVBFHOYKEanhkjefwDtgIAluT,params=UyixbSVBFHOYKEanhkjefwDtgIAlLX)
   xbmcplugin.endOfDirectory(UyixbSVBFHOYKEanhkjefwDtgIAlou._addon_handle)
  else:
   UyixbSVBFHOYKEanhkjefwDtgIAlud=UyixbSVBFHOYKEanhkjefwDtgIAlou.Load_List_File(UyixbSVBFHOYKEanhkjefwDtgIAlcM)
   for UyixbSVBFHOYKEanhkjefwDtgIAluM in UyixbSVBFHOYKEanhkjefwDtgIAlud:
    UyixbSVBFHOYKEanhkjefwDtgIAluW=UyixbSVBFHOYKEanhkjefwDtgIAluQ(urllib.parse.parse_qsl(UyixbSVBFHOYKEanhkjefwDtgIAluM))
    UyixbSVBFHOYKEanhkjefwDtgIAlNG =UyixbSVBFHOYKEanhkjefwDtgIAluW.get('code').strip()
    UyixbSVBFHOYKEanhkjefwDtgIAlLP =UyixbSVBFHOYKEanhkjefwDtgIAluW.get('title').strip()
    UyixbSVBFHOYKEanhkjefwDtgIAlPc =UyixbSVBFHOYKEanhkjefwDtgIAluW.get('img').strip()
    UyixbSVBFHOYKEanhkjefwDtgIAlPu =UyixbSVBFHOYKEanhkjefwDtgIAluW.get('asis').strip()
    try:
     UyixbSVBFHOYKEanhkjefwDtgIAlPc=UyixbSVBFHOYKEanhkjefwDtgIAlPc.replace('\'','\"')
     UyixbSVBFHOYKEanhkjefwDtgIAlPc=json.loads(UyixbSVBFHOYKEanhkjefwDtgIAlPc)
    except:
     UyixbSVBFHOYKEanhkjefwDtgIAluJ
    UyixbSVBFHOYKEanhkjefwDtgIAlPo={}
    UyixbSVBFHOYKEanhkjefwDtgIAlPo['plot']=UyixbSVBFHOYKEanhkjefwDtgIAlLP
    if UyixbSVBFHOYKEanhkjefwDtgIAlcM=='movie':
     UyixbSVBFHOYKEanhkjefwDtgIAlPo['mediatype']='movie'
     UyixbSVBFHOYKEanhkjefwDtgIAlLX={'mode':'MOVIE','id':UyixbSVBFHOYKEanhkjefwDtgIAlNG,'asis':UyixbSVBFHOYKEanhkjefwDtgIAlPu,'title':UyixbSVBFHOYKEanhkjefwDtgIAlLP,'thumbnail':UyixbSVBFHOYKEanhkjefwDtgIAlPc,}
     UyixbSVBFHOYKEanhkjefwDtgIAlLd=UyixbSVBFHOYKEanhkjefwDtgIAlur
    else:
     UyixbSVBFHOYKEanhkjefwDtgIAlPo['mediatype']='episode'
     UyixbSVBFHOYKEanhkjefwDtgIAlLX={'mode':'SEASON_LIST','id':UyixbSVBFHOYKEanhkjefwDtgIAlNG,'asis':UyixbSVBFHOYKEanhkjefwDtgIAlPu,'title':UyixbSVBFHOYKEanhkjefwDtgIAlLP,'thumbnail':json.dumps(UyixbSVBFHOYKEanhkjefwDtgIAlPc,separators=(',',':')),}
     UyixbSVBFHOYKEanhkjefwDtgIAlLd=UyixbSVBFHOYKEanhkjefwDtgIAluT
    UyixbSVBFHOYKEanhkjefwDtgIAlou.add_dir(UyixbSVBFHOYKEanhkjefwDtgIAlLP,sublabel='',img=UyixbSVBFHOYKEanhkjefwDtgIAlPc,infoLabels=UyixbSVBFHOYKEanhkjefwDtgIAlPo,isFolder=UyixbSVBFHOYKEanhkjefwDtgIAlLd,params=UyixbSVBFHOYKEanhkjefwDtgIAlLX)
   UyixbSVBFHOYKEanhkjefwDtgIAlPo={'plot':'시청목록을 삭제합니다.'}
   UyixbSVBFHOYKEanhkjefwDtgIAlLP='*** 시청목록 삭제 ***'
   UyixbSVBFHOYKEanhkjefwDtgIAlLX={'mode':'MYVIEW_REMOVE','stype':UyixbSVBFHOYKEanhkjefwDtgIAlcM,'skey':'-',}
   UyixbSVBFHOYKEanhkjefwDtgIAlLu=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   UyixbSVBFHOYKEanhkjefwDtgIAlou.add_dir(UyixbSVBFHOYKEanhkjefwDtgIAlLP,sublabel='',img=UyixbSVBFHOYKEanhkjefwDtgIAlLu,infoLabels=UyixbSVBFHOYKEanhkjefwDtgIAlPo,isFolder=UyixbSVBFHOYKEanhkjefwDtgIAlur,params=UyixbSVBFHOYKEanhkjefwDtgIAlLX,isLink=UyixbSVBFHOYKEanhkjefwDtgIAluT)
   if UyixbSVBFHOYKEanhkjefwDtgIAlcM=='movie':xbmcplugin.setContent(UyixbSVBFHOYKEanhkjefwDtgIAlou._addon_handle,'movies')
   else:xbmcplugin.setContent(UyixbSVBFHOYKEanhkjefwDtgIAlou._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(UyixbSVBFHOYKEanhkjefwDtgIAlou._addon_handle,cacheToDisc=UyixbSVBFHOYKEanhkjefwDtgIAlur)
 def dp_Set_Bookmark(UyixbSVBFHOYKEanhkjefwDtgIAlou,args):
  UyixbSVBFHOYKEanhkjefwDtgIAluz=urllib.parse.unquote(args.get('bm_param'))
  UyixbSVBFHOYKEanhkjefwDtgIAluz=json.loads(UyixbSVBFHOYKEanhkjefwDtgIAluz)
  UyixbSVBFHOYKEanhkjefwDtgIAlum =UyixbSVBFHOYKEanhkjefwDtgIAluz.get('videoid')
  UyixbSVBFHOYKEanhkjefwDtgIAluq =UyixbSVBFHOYKEanhkjefwDtgIAluz.get('vidtype')
  UyixbSVBFHOYKEanhkjefwDtgIAluR =UyixbSVBFHOYKEanhkjefwDtgIAluz.get('vtitle')
  UyixbSVBFHOYKEanhkjefwDtgIAloz=xbmcgui.Dialog()
  UyixbSVBFHOYKEanhkjefwDtgIAlLz=UyixbSVBFHOYKEanhkjefwDtgIAloz.yesno(__language__(30914).encode('utf8'),UyixbSVBFHOYKEanhkjefwDtgIAluR+' \n\n'+__language__(30915))
  if UyixbSVBFHOYKEanhkjefwDtgIAlLz==UyixbSVBFHOYKEanhkjefwDtgIAlur:return
  UyixbSVBFHOYKEanhkjefwDtgIAluG=UyixbSVBFHOYKEanhkjefwDtgIAlou.CoupangObj.GetBookmarkInfo(UyixbSVBFHOYKEanhkjefwDtgIAlum,UyixbSVBFHOYKEanhkjefwDtgIAluq)
  UyixbSVBFHOYKEanhkjefwDtgIAluC=json.dumps(UyixbSVBFHOYKEanhkjefwDtgIAluG)
  UyixbSVBFHOYKEanhkjefwDtgIAluC=urllib.parse.quote(UyixbSVBFHOYKEanhkjefwDtgIAluC)
  UyixbSVBFHOYKEanhkjefwDtgIAlPs ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(UyixbSVBFHOYKEanhkjefwDtgIAluC)
  xbmc.executebuiltin(UyixbSVBFHOYKEanhkjefwDtgIAlPs)
 def coupang_main(UyixbSVBFHOYKEanhkjefwDtgIAlou):
  UyixbSVBFHOYKEanhkjefwDtgIAlPJ=UyixbSVBFHOYKEanhkjefwDtgIAlou.main_params.get('mode',UyixbSVBFHOYKEanhkjefwDtgIAluJ)
  if UyixbSVBFHOYKEanhkjefwDtgIAlPJ=='LOGOUT':
   UyixbSVBFHOYKEanhkjefwDtgIAlou.CP_logout()
   return
  UyixbSVBFHOYKEanhkjefwDtgIAlou.option_check()
  if UyixbSVBFHOYKEanhkjefwDtgIAlPJ is UyixbSVBFHOYKEanhkjefwDtgIAluJ:
   UyixbSVBFHOYKEanhkjefwDtgIAlou.dp_Main_List(UyixbSVBFHOYKEanhkjefwDtgIAlou.main_params)
  elif UyixbSVBFHOYKEanhkjefwDtgIAlPJ=='CATEGORY_GROUPLIST':
   UyixbSVBFHOYKEanhkjefwDtgIAlou.dp_Category_GroupList(UyixbSVBFHOYKEanhkjefwDtgIAlou.main_params)
  elif UyixbSVBFHOYKEanhkjefwDtgIAlPJ=='THEME_GROUPLIST':
   UyixbSVBFHOYKEanhkjefwDtgIAlou.dp_Theme_GroupList(UyixbSVBFHOYKEanhkjefwDtgIAlou.main_params)
  elif UyixbSVBFHOYKEanhkjefwDtgIAlPJ=='EVENT_GROUPLIST':
   UyixbSVBFHOYKEanhkjefwDtgIAlou.dp_Event_GroupList(UyixbSVBFHOYKEanhkjefwDtgIAlou.main_params)
  elif UyixbSVBFHOYKEanhkjefwDtgIAlPJ=='EVENT_GAMELIST':
   UyixbSVBFHOYKEanhkjefwDtgIAlou.dp_Event_GameList(UyixbSVBFHOYKEanhkjefwDtgIAlou.main_params)
  elif UyixbSVBFHOYKEanhkjefwDtgIAlPJ=='EVENT_LIST':
   UyixbSVBFHOYKEanhkjefwDtgIAlou.dp_Event_List(UyixbSVBFHOYKEanhkjefwDtgIAlou.main_params)
  elif UyixbSVBFHOYKEanhkjefwDtgIAlPJ=='CATEGORY_LIST':
   UyixbSVBFHOYKEanhkjefwDtgIAlou.dp_Category_List(UyixbSVBFHOYKEanhkjefwDtgIAlou.main_params)
  elif UyixbSVBFHOYKEanhkjefwDtgIAlPJ=='SEASON_LIST':
   UyixbSVBFHOYKEanhkjefwDtgIAlou.dp_Season_List(UyixbSVBFHOYKEanhkjefwDtgIAlou.main_params)
  elif UyixbSVBFHOYKEanhkjefwDtgIAlPJ=='EPISODE_LIST':
   UyixbSVBFHOYKEanhkjefwDtgIAlou.dp_Episode_List(UyixbSVBFHOYKEanhkjefwDtgIAlou.main_params)
  elif UyixbSVBFHOYKEanhkjefwDtgIAlPJ=='TEST':
   UyixbSVBFHOYKEanhkjefwDtgIAlou.dp_Test(UyixbSVBFHOYKEanhkjefwDtgIAlou.main_params)
  elif UyixbSVBFHOYKEanhkjefwDtgIAlPJ in['MOVIE','VOD','HIGHLIGHT','LIVE']:
   UyixbSVBFHOYKEanhkjefwDtgIAlou.play_VIDEO(UyixbSVBFHOYKEanhkjefwDtgIAlou.main_params)
  elif UyixbSVBFHOYKEanhkjefwDtgIAlPJ=='WATCH':
   UyixbSVBFHOYKEanhkjefwDtgIAlou.dp_Watch_List(UyixbSVBFHOYKEanhkjefwDtgIAlou.main_params)
  elif UyixbSVBFHOYKEanhkjefwDtgIAlPJ=='LOCAL_SEARCH':
   UyixbSVBFHOYKEanhkjefwDtgIAlou.dp_Search_List(UyixbSVBFHOYKEanhkjefwDtgIAlou.main_params)
  elif UyixbSVBFHOYKEanhkjefwDtgIAlPJ=='SEARCH_HISTORY':
   UyixbSVBFHOYKEanhkjefwDtgIAlou.dp_Search_History(UyixbSVBFHOYKEanhkjefwDtgIAlou.main_params)
  elif UyixbSVBFHOYKEanhkjefwDtgIAlPJ in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   UyixbSVBFHOYKEanhkjefwDtgIAlou.dp_Listfile_Delete(UyixbSVBFHOYKEanhkjefwDtgIAlou.main_params)
  elif UyixbSVBFHOYKEanhkjefwDtgIAlPJ in['TOTAL_SEARCH','TOTAL_HISTORY']:
   UyixbSVBFHOYKEanhkjefwDtgIAlou.dp_Global_Search(UyixbSVBFHOYKEanhkjefwDtgIAlou.main_params)
  elif UyixbSVBFHOYKEanhkjefwDtgIAlPJ=='MENU_BOOKMARK':
   UyixbSVBFHOYKEanhkjefwDtgIAlou.dp_Bookmark_Menu(UyixbSVBFHOYKEanhkjefwDtgIAlou.main_params)
  elif UyixbSVBFHOYKEanhkjefwDtgIAlPJ=='SET_BOOKMARK':
   UyixbSVBFHOYKEanhkjefwDtgIAlou.dp_Set_Bookmark(UyixbSVBFHOYKEanhkjefwDtgIAlou.main_params)
  else:
   UyixbSVBFHOYKEanhkjefwDtgIAluJ
# Created by pyminifier (https://github.com/liftoff/pyminifier)
