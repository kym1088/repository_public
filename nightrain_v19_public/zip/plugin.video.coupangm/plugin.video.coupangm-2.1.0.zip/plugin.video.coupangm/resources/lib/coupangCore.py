__author__="NightRain"
iPentRGuNMKQALdmlDgkVyXxTcUOJW=object
iPentRGuNMKQALdmlDgkVyXxTcUOJY=None
iPentRGuNMKQALdmlDgkVyXxTcUOJw=False
iPentRGuNMKQALdmlDgkVyXxTcUOJb=print
iPentRGuNMKQALdmlDgkVyXxTcUOJE=str
iPentRGuNMKQALdmlDgkVyXxTcUOJS=open
iPentRGuNMKQALdmlDgkVyXxTcUOJo=int
iPentRGuNMKQALdmlDgkVyXxTcUOJv=Exception
iPentRGuNMKQALdmlDgkVyXxTcUOJp=id
iPentRGuNMKQALdmlDgkVyXxTcUOJC=True
iPentRGuNMKQALdmlDgkVyXxTcUOJf=len
iPentRGuNMKQALdmlDgkVyXxTcUOJj=range
import urllib
import re
import json
import requests
import datetime
import time
import random
import base64
class iPentRGuNMKQALdmlDgkVyXxTcUOBh(iPentRGuNMKQALdmlDgkVyXxTcUOJW):
 def __init__(iPentRGuNMKQALdmlDgkVyXxTcUOBq):
  iPentRGuNMKQALdmlDgkVyXxTcUOBq.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36 Edg/107.0.1418.62' 
  iPentRGuNMKQALdmlDgkVyXxTcUOBq.MODEL ='Edge_107' 
  iPentRGuNMKQALdmlDgkVyXxTcUOBq.OS_VERSION ='107' 
  iPentRGuNMKQALdmlDgkVyXxTcUOBq.DEFAULT_HEADER ={'user-agent':iPentRGuNMKQALdmlDgkVyXxTcUOBq.USER_AGENT}
  iPentRGuNMKQALdmlDgkVyXxTcUOBq.API_DOMAIN ='https://www.coupangplay.com'
  iPentRGuNMKQALdmlDgkVyXxTcUOBq.API_VIEWURL ='https://discover.coupangstreaming.com'
  iPentRGuNMKQALdmlDgkVyXxTcUOBq.PAGE_LIMIT =40
  iPentRGuNMKQALdmlDgkVyXxTcUOBq.SEARCH_LIMIT =20
  iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP={}
  iPentRGuNMKQALdmlDgkVyXxTcUOBq.Init_CP()
  iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP_DEVICE_FILENAME=''
  iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP_COOKIE_FILENAME=''
 def callRequestCookies(iPentRGuNMKQALdmlDgkVyXxTcUOBq,jobtype,iPentRGuNMKQALdmlDgkVyXxTcUOhJ,payload=iPentRGuNMKQALdmlDgkVyXxTcUOJY,params=iPentRGuNMKQALdmlDgkVyXxTcUOJY,headers=iPentRGuNMKQALdmlDgkVyXxTcUOJY,cookies=iPentRGuNMKQALdmlDgkVyXxTcUOJY,redirects=iPentRGuNMKQALdmlDgkVyXxTcUOJw):
  iPentRGuNMKQALdmlDgkVyXxTcUOBJ=iPentRGuNMKQALdmlDgkVyXxTcUOBq.DEFAULT_HEADER
  if headers:iPentRGuNMKQALdmlDgkVyXxTcUOBJ.update(headers)
  if jobtype=='Get':
   iPentRGuNMKQALdmlDgkVyXxTcUOBI=requests.get(iPentRGuNMKQALdmlDgkVyXxTcUOhJ,params=params,headers=iPentRGuNMKQALdmlDgkVyXxTcUOBJ,cookies=cookies,allow_redirects=redirects)
  else:
   iPentRGuNMKQALdmlDgkVyXxTcUOBI=requests.post(iPentRGuNMKQALdmlDgkVyXxTcUOhJ,data=payload,params=params,headers=iPentRGuNMKQALdmlDgkVyXxTcUOBJ,cookies=cookies,allow_redirects=redirects)
  iPentRGuNMKQALdmlDgkVyXxTcUOJb(iPentRGuNMKQALdmlDgkVyXxTcUOJE(iPentRGuNMKQALdmlDgkVyXxTcUOBI.status_code)+' - '+iPentRGuNMKQALdmlDgkVyXxTcUOJE(iPentRGuNMKQALdmlDgkVyXxTcUOBI.url))
  return iPentRGuNMKQALdmlDgkVyXxTcUOBI
 def callRequestCookies_test(iPentRGuNMKQALdmlDgkVyXxTcUOBq,jobtype,iPentRGuNMKQALdmlDgkVyXxTcUOhJ,payload=iPentRGuNMKQALdmlDgkVyXxTcUOJY,params=iPentRGuNMKQALdmlDgkVyXxTcUOJY,headers=iPentRGuNMKQALdmlDgkVyXxTcUOJY,cookies=iPentRGuNMKQALdmlDgkVyXxTcUOJY,redirects=iPentRGuNMKQALdmlDgkVyXxTcUOJw):
  iPentRGuNMKQALdmlDgkVyXxTcUOBJ=iPentRGuNMKQALdmlDgkVyXxTcUOBq.DEFAULT_HEADER
  if headers:iPentRGuNMKQALdmlDgkVyXxTcUOBJ.update(headers)
  iPentRGuNMKQALdmlDgkVyXxTcUOBI=requests.Request('POST',iPentRGuNMKQALdmlDgkVyXxTcUOhJ,headers=headers,data=payload,params=params,cookies=cookies)
  iPentRGuNMKQALdmlDgkVyXxTcUOBr=iPentRGuNMKQALdmlDgkVyXxTcUOBI.prepare()
  iPentRGuNMKQALdmlDgkVyXxTcUOBq.pretty_print_POST(iPentRGuNMKQALdmlDgkVyXxTcUOBr)
  return iPentRGuNMKQALdmlDgkVyXxTcUOBI
 def pretty_print_POST(iPentRGuNMKQALdmlDgkVyXxTcUOBq,req):
  iPentRGuNMKQALdmlDgkVyXxTcUOJb('{}\n{}\r\n{}\r\n\r\n{}'.format('-----------START-----------',req.method+' '+req.url,'\r\n'.join('{}: {}'.format(k,v)for k,v in req.headers.items()),req.body,))
 def dic_To_jsonfile(iPentRGuNMKQALdmlDgkVyXxTcUOBq,filename,iPentRGuNMKQALdmlDgkVyXxTcUOBH):
  if filename=='':return
  fp=iPentRGuNMKQALdmlDgkVyXxTcUOJS(filename,'w',-1,'utf-8')
  json.dump(iPentRGuNMKQALdmlDgkVyXxTcUOBH,fp,indent=4,ensure_ascii=iPentRGuNMKQALdmlDgkVyXxTcUOJw)
  fp.close()
 def jsonfile_To_dic(iPentRGuNMKQALdmlDgkVyXxTcUOBq,filename):
  if filename=='':return iPentRGuNMKQALdmlDgkVyXxTcUOJY
  try:
   fp=iPentRGuNMKQALdmlDgkVyXxTcUOJS(filename,'r',-1,'utf-8')
   iPentRGuNMKQALdmlDgkVyXxTcUOBF=json.load(fp)
   fp.close()
  except:
   iPentRGuNMKQALdmlDgkVyXxTcUOBF={}
  return iPentRGuNMKQALdmlDgkVyXxTcUOBF
 def convert_TimeStr(iPentRGuNMKQALdmlDgkVyXxTcUOBq,iPentRGuNMKQALdmlDgkVyXxTcUOBz):
  try:
   iPentRGuNMKQALdmlDgkVyXxTcUOBz =iPentRGuNMKQALdmlDgkVyXxTcUOBz[0:16]
   iPentRGuNMKQALdmlDgkVyXxTcUOBs=datetime.datetime.strptime(iPentRGuNMKQALdmlDgkVyXxTcUOBz,'%Y-%m-%dT%H:%M')+datetime.timedelta(hours=9)
   return iPentRGuNMKQALdmlDgkVyXxTcUOBs.strftime('%Y-%m-%d %H:%M')
  except:
   return iPentRGuNMKQALdmlDgkVyXxTcUOJY
 def Get_Now_Datetime(iPentRGuNMKQALdmlDgkVyXxTcUOBq):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetNoCache(iPentRGuNMKQALdmlDgkVyXxTcUOBq):
  iPentRGuNMKQALdmlDgkVyXxTcUOBY =iPentRGuNMKQALdmlDgkVyXxTcUOJo(time.time()*1000)
  return iPentRGuNMKQALdmlDgkVyXxTcUOBY
 def generatePcId(iPentRGuNMKQALdmlDgkVyXxTcUOBq):
  t=iPentRGuNMKQALdmlDgkVyXxTcUOBq.GetNoCache()
  r=random.random()
  iPentRGuNMKQALdmlDgkVyXxTcUOBw=iPentRGuNMKQALdmlDgkVyXxTcUOJE(t)+iPentRGuNMKQALdmlDgkVyXxTcUOJE(r)[2:12]
  return iPentRGuNMKQALdmlDgkVyXxTcUOBw
 def generatePvId(iPentRGuNMKQALdmlDgkVyXxTcUOBq,genType='1'):
  import hashlib
  m=hashlib.md5()
  iPentRGuNMKQALdmlDgkVyXxTcUOBb=iPentRGuNMKQALdmlDgkVyXxTcUOJE(random.random())
  m.update(iPentRGuNMKQALdmlDgkVyXxTcUOBb.encode('utf-8'))
  iPentRGuNMKQALdmlDgkVyXxTcUOBE=iPentRGuNMKQALdmlDgkVyXxTcUOJE(m.hexdigest())
  if genType=='1':
   return '%s-%s-%s-%s-%s'%(iPentRGuNMKQALdmlDgkVyXxTcUOBE[:8],iPentRGuNMKQALdmlDgkVyXxTcUOBE[8:12],iPentRGuNMKQALdmlDgkVyXxTcUOBE[12:16],iPentRGuNMKQALdmlDgkVyXxTcUOBE[16:20],iPentRGuNMKQALdmlDgkVyXxTcUOBE[20:])
  else:
   return iPentRGuNMKQALdmlDgkVyXxTcUOBE
 def Get_DeviceID(iPentRGuNMKQALdmlDgkVyXxTcUOBq):
  iPentRGuNMKQALdmlDgkVyXxTcUOBS=''
  try: 
   fp=iPentRGuNMKQALdmlDgkVyXxTcUOJS(iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP_DEVICE_FILENAME,'r',-1,'utf-8')
   iPentRGuNMKQALdmlDgkVyXxTcUOBo= json.load(fp)
   fp.close()
   iPentRGuNMKQALdmlDgkVyXxTcUOBS=iPentRGuNMKQALdmlDgkVyXxTcUOBo.get('device_id')
  except iPentRGuNMKQALdmlDgkVyXxTcUOJv as exception:
   iPentRGuNMKQALdmlDgkVyXxTcUOJY
  if iPentRGuNMKQALdmlDgkVyXxTcUOBS=='':
   iPentRGuNMKQALdmlDgkVyXxTcUOBS=iPentRGuNMKQALdmlDgkVyXxTcUOBq.generatePvId(genType='1')
   try: 
    fp=iPentRGuNMKQALdmlDgkVyXxTcUOJS(iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP_DEVICE_FILENAME,'w',-1,'utf-8')
    json.dump({'device_id':iPentRGuNMKQALdmlDgkVyXxTcUOBS},fp,indent=4,ensure_ascii=iPentRGuNMKQALdmlDgkVyXxTcUOJw)
    fp.close()
   except iPentRGuNMKQALdmlDgkVyXxTcUOJv as exception:
    return ''
  return iPentRGuNMKQALdmlDgkVyXxTcUOBS
 def Make_authHeader(iPentRGuNMKQALdmlDgkVyXxTcUOBq):
  tr=iPentRGuNMKQALdmlDgkVyXxTcUOBq.generatePvId(genType=2)
  ti=iPentRGuNMKQALdmlDgkVyXxTcUOBq.GetNoCache()
  iPentRGuNMKQALdmlDgkVyXxTcUOJp=iPentRGuNMKQALdmlDgkVyXxTcUOBq.generatePvId(genType=2)[:16]
  iPentRGuNMKQALdmlDgkVyXxTcUOBv='00-%s-%s-01'%(tr,iPentRGuNMKQALdmlDgkVyXxTcUOJp,)
  iPentRGuNMKQALdmlDgkVyXxTcUOBp ='%s@nr=0-1-%s-%s-%s----%s'%(iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['NREUM']['tk'],iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['NREUM']['ac'],iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['NREUM']['ap'],iPentRGuNMKQALdmlDgkVyXxTcUOJp,ti,)
  iPentRGuNMKQALdmlDgkVyXxTcUOBC ='{"v":[0,1],"d":{"ty":"Browser","ac":"%s","ap":"%s","id":"%s","tr":"%s","ti":%s,"tk":"%s"}}'%(iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['NREUM']['ac'],iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['NREUM']['ap'],iPentRGuNMKQALdmlDgkVyXxTcUOJp,tr,ti,iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['NREUM']['tk'],) 
  return iPentRGuNMKQALdmlDgkVyXxTcUOBv,iPentRGuNMKQALdmlDgkVyXxTcUOBp,base64.standard_b64encode(iPentRGuNMKQALdmlDgkVyXxTcUOBC.encode()).decode('utf-8')
 def Init_CP(iPentRGuNMKQALdmlDgkVyXxTcUOBq):
  iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP={}
  iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['ACCOUNT']={'cpid':'','cppw':'','cppf':'0'}
  iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']={}
 def Save_session_acount(iPentRGuNMKQALdmlDgkVyXxTcUOBq,iPentRGuNMKQALdmlDgkVyXxTcUOBf,iPentRGuNMKQALdmlDgkVyXxTcUOBj,iPentRGuNMKQALdmlDgkVyXxTcUOhB):
  iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['ACCOUNT']['cpid']=base64.standard_b64encode(iPentRGuNMKQALdmlDgkVyXxTcUOBf.encode()).decode('utf-8')
  iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['ACCOUNT']['cppw']=base64.standard_b64encode(iPentRGuNMKQALdmlDgkVyXxTcUOBj.encode()).decode('utf-8')
  iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['ACCOUNT']['cppf']=iPentRGuNMKQALdmlDgkVyXxTcUOJE(iPentRGuNMKQALdmlDgkVyXxTcUOhB)
 def Load_session_acount(iPentRGuNMKQALdmlDgkVyXxTcUOBq):
  iPentRGuNMKQALdmlDgkVyXxTcUOBf=base64.standard_b64decode(iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['ACCOUNT']['cpid']).decode('utf-8')
  iPentRGuNMKQALdmlDgkVyXxTcUOBj=base64.standard_b64decode(iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['ACCOUNT']['cppw']).decode('utf-8')
  iPentRGuNMKQALdmlDgkVyXxTcUOhB=iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['ACCOUNT']['cppf']
  return iPentRGuNMKQALdmlDgkVyXxTcUOBf,iPentRGuNMKQALdmlDgkVyXxTcUOBj,iPentRGuNMKQALdmlDgkVyXxTcUOhB
 def make_CP_DefaultCookies(iPentRGuNMKQALdmlDgkVyXxTcUOBq):
  iPentRGuNMKQALdmlDgkVyXxTcUOhq={}
  if 'NEXT_LOCALE' in iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']:iPentRGuNMKQALdmlDgkVyXxTcUOhq['NEXT_LOCALE'] =iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['NEXT_LOCALE']
  if 'ak_bmsc' in iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']:iPentRGuNMKQALdmlDgkVyXxTcUOhq['ak_bmsc'] =iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['ak_bmsc']
  if 'bm_mi' in iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']:iPentRGuNMKQALdmlDgkVyXxTcUOhq['bm_mi'] =iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['bm_mi']
  if 'bm_sv' in iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']:iPentRGuNMKQALdmlDgkVyXxTcUOhq['bm_sv'] =iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['bm_sv']
  if 'PCID' in iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']:iPentRGuNMKQALdmlDgkVyXxTcUOhq['PCID'] =iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['PCID']
  if 'member_srl' in iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']:iPentRGuNMKQALdmlDgkVyXxTcUOhq['member_srl'] =iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['member_srl']
  if 'token' in iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']:iPentRGuNMKQALdmlDgkVyXxTcUOhq['token'] =iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['token']
  if 'session_web_id' in iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']:iPentRGuNMKQALdmlDgkVyXxTcUOhq['session_web_id']=iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['session_web_id']
  if 'device_id' in iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']:iPentRGuNMKQALdmlDgkVyXxTcUOhq['device_id'] =iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['device_id']
  return iPentRGuNMKQALdmlDgkVyXxTcUOhq
 def Get_CP_Login(iPentRGuNMKQALdmlDgkVyXxTcUOBq,userid,userpw,iPentRGuNMKQALdmlDgkVyXxTcUOhw):
  try:
   iPentRGuNMKQALdmlDgkVyXxTcUOhJ=iPentRGuNMKQALdmlDgkVyXxTcUOBq.API_DOMAIN
   iPentRGuNMKQALdmlDgkVyXxTcUOhI=iPentRGuNMKQALdmlDgkVyXxTcUOBq.callRequestCookies('Get',iPentRGuNMKQALdmlDgkVyXxTcUOhJ,payload=iPentRGuNMKQALdmlDgkVyXxTcUOJY,params=iPentRGuNMKQALdmlDgkVyXxTcUOJY,headers=iPentRGuNMKQALdmlDgkVyXxTcUOJY,cookies=iPentRGuNMKQALdmlDgkVyXxTcUOJY,redirects=iPentRGuNMKQALdmlDgkVyXxTcUOJw)
   if iPentRGuNMKQALdmlDgkVyXxTcUOhI.status_code not in[301,302]:return iPentRGuNMKQALdmlDgkVyXxTcUOJw
   for iPentRGuNMKQALdmlDgkVyXxTcUOhr in iPentRGuNMKQALdmlDgkVyXxTcUOhI.cookies:
    iPentRGuNMKQALdmlDgkVyXxTcUOJb(iPentRGuNMKQALdmlDgkVyXxTcUOhr.name,iPentRGuNMKQALdmlDgkVyXxTcUOhr.value) 
    if iPentRGuNMKQALdmlDgkVyXxTcUOhr.name=='NEXT_LOCALE':
     iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['NEXT_LOCALE']=iPentRGuNMKQALdmlDgkVyXxTcUOhr.value
    elif iPentRGuNMKQALdmlDgkVyXxTcUOhr.name=='ak_bmsc':
     iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['ak_bmsc']=iPentRGuNMKQALdmlDgkVyXxTcUOhr.value
   iPentRGuNMKQALdmlDgkVyXxTcUOhq=iPentRGuNMKQALdmlDgkVyXxTcUOBq.make_CP_DefaultCookies()
   iPentRGuNMKQALdmlDgkVyXxTcUOhI=iPentRGuNMKQALdmlDgkVyXxTcUOBq.callRequestCookies('Get',iPentRGuNMKQALdmlDgkVyXxTcUOhJ,payload=iPentRGuNMKQALdmlDgkVyXxTcUOJY,params=iPentRGuNMKQALdmlDgkVyXxTcUOJY,headers=iPentRGuNMKQALdmlDgkVyXxTcUOJY,cookies=iPentRGuNMKQALdmlDgkVyXxTcUOhq,redirects=iPentRGuNMKQALdmlDgkVyXxTcUOJw)
   if iPentRGuNMKQALdmlDgkVyXxTcUOhI.status_code not in[200]:return iPentRGuNMKQALdmlDgkVyXxTcUOJw
   iPentRGuNMKQALdmlDgkVyXxTcUOhH=re.findall('NREUM.loader_config=\{[\w\d\":,-]+\}',iPentRGuNMKQALdmlDgkVyXxTcUOhI.text)[0].split('=')[1]
   iPentRGuNMKQALdmlDgkVyXxTcUOhH=iPentRGuNMKQALdmlDgkVyXxTcUOhH.replace('{','{"').replace(':','":').replace(',',',"')
   iPentRGuNMKQALdmlDgkVyXxTcUOhH=json.loads(iPentRGuNMKQALdmlDgkVyXxTcUOhH)
   iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['NREUM']={'ac':iPentRGuNMKQALdmlDgkVyXxTcUOhH['accountID'],'tk':iPentRGuNMKQALdmlDgkVyXxTcUOhH['trustKey'],'ap':iPentRGuNMKQALdmlDgkVyXxTcUOhH['agentID'],'lk':iPentRGuNMKQALdmlDgkVyXxTcUOhH['licenseKey'],}
   iPentRGuNMKQALdmlDgkVyXxTcUOJb('---')
   for iPentRGuNMKQALdmlDgkVyXxTcUOhr in iPentRGuNMKQALdmlDgkVyXxTcUOhI.cookies:
    iPentRGuNMKQALdmlDgkVyXxTcUOJb(iPentRGuNMKQALdmlDgkVyXxTcUOhr.name,iPentRGuNMKQALdmlDgkVyXxTcUOhr.value) 
    if iPentRGuNMKQALdmlDgkVyXxTcUOhr.name=='bm_mi':
     iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['bm_mi']=iPentRGuNMKQALdmlDgkVyXxTcUOhr.value
    elif iPentRGuNMKQALdmlDgkVyXxTcUOhr.name=='bm_sv':
     iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['bm_sv'] =iPentRGuNMKQALdmlDgkVyXxTcUOhr.value
     iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['bm_sv_ex']=iPentRGuNMKQALdmlDgkVyXxTcUOhr.expires 
    elif iPentRGuNMKQALdmlDgkVyXxTcUOhr.name=='session_web_id':
     iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['session_web_id']=iPentRGuNMKQALdmlDgkVyXxTcUOhr.value
  except iPentRGuNMKQALdmlDgkVyXxTcUOJv as exception:
   iPentRGuNMKQALdmlDgkVyXxTcUOJb(exception)
   return iPentRGuNMKQALdmlDgkVyXxTcUOJw
  try:
   iPentRGuNMKQALdmlDgkVyXxTcUOhJ=iPentRGuNMKQALdmlDgkVyXxTcUOBq.API_DOMAIN+'/api/auth'
   iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['PCID']=iPentRGuNMKQALdmlDgkVyXxTcUOBq.generatePcId()
   iPentRGuNMKQALdmlDgkVyXxTcUOha=iPentRGuNMKQALdmlDgkVyXxTcUOBq.Get_DeviceID()
   iPentRGuNMKQALdmlDgkVyXxTcUOhF =iPentRGuNMKQALdmlDgkVyXxTcUOha.split('-')[0]
   iPentRGuNMKQALdmlDgkVyXxTcUOBv,iPentRGuNMKQALdmlDgkVyXxTcUOBp,iPentRGuNMKQALdmlDgkVyXxTcUOBC=iPentRGuNMKQALdmlDgkVyXxTcUOBq.Make_authHeader()
   iPentRGuNMKQALdmlDgkVyXxTcUOhz={'traceparent':iPentRGuNMKQALdmlDgkVyXxTcUOBv,'tracestate':iPentRGuNMKQALdmlDgkVyXxTcUOBp,'newrelic':iPentRGuNMKQALdmlDgkVyXxTcUOBC,'content-type':'application/json','x-app-version':'1.26.1','x-device-id':'','x-device-os-version':iPentRGuNMKQALdmlDgkVyXxTcUOBq.OS_VERSION,'x-nr-session-id':iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['session_web_id'],'x-pcid':'',}
   iPentRGuNMKQALdmlDgkVyXxTcUOhs={'device':{'deviceId':'web-'+iPentRGuNMKQALdmlDgkVyXxTcUOha,'model':iPentRGuNMKQALdmlDgkVyXxTcUOBq.MODEL,'name':'Edge Desktop '+iPentRGuNMKQALdmlDgkVyXxTcUOhF,'os':'Windows','osVersion':'10','type':'webclient',},'email':userid,'password':userpw,}
   iPentRGuNMKQALdmlDgkVyXxTcUOhs=json.dumps(iPentRGuNMKQALdmlDgkVyXxTcUOhs,separators=(',',':'))
   iPentRGuNMKQALdmlDgkVyXxTcUOhq=iPentRGuNMKQALdmlDgkVyXxTcUOBq.make_CP_DefaultCookies()
   iPentRGuNMKQALdmlDgkVyXxTcUOhI=iPentRGuNMKQALdmlDgkVyXxTcUOBq.callRequestCookies('Post',iPentRGuNMKQALdmlDgkVyXxTcUOhJ,payload=iPentRGuNMKQALdmlDgkVyXxTcUOhs,params=iPentRGuNMKQALdmlDgkVyXxTcUOJY,headers=iPentRGuNMKQALdmlDgkVyXxTcUOhz,cookies=iPentRGuNMKQALdmlDgkVyXxTcUOhq,redirects=iPentRGuNMKQALdmlDgkVyXxTcUOJw)
   if iPentRGuNMKQALdmlDgkVyXxTcUOhI.status_code not in[200]:
    iPentRGuNMKQALdmlDgkVyXxTcUOhW=json.loads(iPentRGuNMKQALdmlDgkVyXxTcUOhI.text)
    if 'error' in iPentRGuNMKQALdmlDgkVyXxTcUOhW:
     iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['error']=iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('error').get('detail')
    return iPentRGuNMKQALdmlDgkVyXxTcUOJw
   iPentRGuNMKQALdmlDgkVyXxTcUOJb('---')
   for iPentRGuNMKQALdmlDgkVyXxTcUOhr in iPentRGuNMKQALdmlDgkVyXxTcUOhI.cookies:
    iPentRGuNMKQALdmlDgkVyXxTcUOJb(iPentRGuNMKQALdmlDgkVyXxTcUOhr.name,iPentRGuNMKQALdmlDgkVyXxTcUOhr.value) 
    if iPentRGuNMKQALdmlDgkVyXxTcUOhr.name=='token':
     iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['token']=iPentRGuNMKQALdmlDgkVyXxTcUOhr.value
    elif iPentRGuNMKQALdmlDgkVyXxTcUOhr.name=='member_srl':
     iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['member_srl']=iPentRGuNMKQALdmlDgkVyXxTcUOhr.value
    elif iPentRGuNMKQALdmlDgkVyXxTcUOhr.name=='bm_sv':
     iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['bm_sv'] =iPentRGuNMKQALdmlDgkVyXxTcUOhr.value
     iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['bm_sv_ex']=iPentRGuNMKQALdmlDgkVyXxTcUOhr.expires 
    elif iPentRGuNMKQALdmlDgkVyXxTcUOhr.name=='device_id':
     iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['device_id']=iPentRGuNMKQALdmlDgkVyXxTcUOhr.value
  except iPentRGuNMKQALdmlDgkVyXxTcUOJv as exception:
   iPentRGuNMKQALdmlDgkVyXxTcUOJb(exception)
   return iPentRGuNMKQALdmlDgkVyXxTcUOJw
  iPentRGuNMKQALdmlDgkVyXxTcUOBq.Save_session_acount(userid,userpw,iPentRGuNMKQALdmlDgkVyXxTcUOhw)
  return iPentRGuNMKQALdmlDgkVyXxTcUOJC
 def Get_CP_profile(iPentRGuNMKQALdmlDgkVyXxTcUOBq,iPentRGuNMKQALdmlDgkVyXxTcUOhw,limit_days=1,re_check=iPentRGuNMKQALdmlDgkVyXxTcUOJw):
  if re_check==iPentRGuNMKQALdmlDgkVyXxTcUOJC:
   if iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['bm_sv_ex']>iPentRGuNMKQALdmlDgkVyXxTcUOJo(time.time()):
    iPentRGuNMKQALdmlDgkVyXxTcUOJb('bm_sv_ex ok')
    return iPentRGuNMKQALdmlDgkVyXxTcUOJC
  try:
   iPentRGuNMKQALdmlDgkVyXxTcUOhJ=iPentRGuNMKQALdmlDgkVyXxTcUOBq.API_DOMAIN+'/api/profiles'
   iPentRGuNMKQALdmlDgkVyXxTcUOBv,iPentRGuNMKQALdmlDgkVyXxTcUOBp,iPentRGuNMKQALdmlDgkVyXxTcUOBC=iPentRGuNMKQALdmlDgkVyXxTcUOBq.Make_authHeader()
   iPentRGuNMKQALdmlDgkVyXxTcUOhz={'traceparent':iPentRGuNMKQALdmlDgkVyXxTcUOBv,'tracestate':iPentRGuNMKQALdmlDgkVyXxTcUOBp,'newrelic':iPentRGuNMKQALdmlDgkVyXxTcUOBC,'x-app-version':'1.26.1','x-device-id':'','x-device-os-version':iPentRGuNMKQALdmlDgkVyXxTcUOBq.OS_VERSION,'x-nr-session-id':iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['session_web_id'],'x-pcid':'',}
   iPentRGuNMKQALdmlDgkVyXxTcUOhq=iPentRGuNMKQALdmlDgkVyXxTcUOBq.make_CP_DefaultCookies()
   iPentRGuNMKQALdmlDgkVyXxTcUOhI=iPentRGuNMKQALdmlDgkVyXxTcUOBq.callRequestCookies('Get',iPentRGuNMKQALdmlDgkVyXxTcUOhJ,payload=iPentRGuNMKQALdmlDgkVyXxTcUOJY,params=iPentRGuNMKQALdmlDgkVyXxTcUOJY,headers=iPentRGuNMKQALdmlDgkVyXxTcUOhz,cookies=iPentRGuNMKQALdmlDgkVyXxTcUOhq,redirects=iPentRGuNMKQALdmlDgkVyXxTcUOJw)
   if iPentRGuNMKQALdmlDgkVyXxTcUOhI.status_code not in[200]:return iPentRGuNMKQALdmlDgkVyXxTcUOJw
   iPentRGuNMKQALdmlDgkVyXxTcUOhW=json.loads(iPentRGuNMKQALdmlDgkVyXxTcUOhI.text)
   iPentRGuNMKQALdmlDgkVyXxTcUOhY=0 
   for iPentRGuNMKQALdmlDgkVyXxTcUOhr in iPentRGuNMKQALdmlDgkVyXxTcUOhI.cookies:
    iPentRGuNMKQALdmlDgkVyXxTcUOJb(iPentRGuNMKQALdmlDgkVyXxTcUOhr.name)
    if iPentRGuNMKQALdmlDgkVyXxTcUOhr.name=='bm_sv':
     iPentRGuNMKQALdmlDgkVyXxTcUOhY=1
     iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['bm_sv'] =iPentRGuNMKQALdmlDgkVyXxTcUOhr.value
     iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['bm_sv_ex']=iPentRGuNMKQALdmlDgkVyXxTcUOhr.expires 
   if iPentRGuNMKQALdmlDgkVyXxTcUOhY==0:
    iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['bm_sv_ex']=iPentRGuNMKQALdmlDgkVyXxTcUOJo(time.time())+60*60*2 
   iPentRGuNMKQALdmlDgkVyXxTcUOhw=iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('data')[iPentRGuNMKQALdmlDgkVyXxTcUOJo(iPentRGuNMKQALdmlDgkVyXxTcUOhw)]
   iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['accountId']=iPentRGuNMKQALdmlDgkVyXxTcUOhw.get('accountId')
   iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['profileId']=iPentRGuNMKQALdmlDgkVyXxTcUOhw.get('profileId')
  except iPentRGuNMKQALdmlDgkVyXxTcUOJv as exception:
   iPentRGuNMKQALdmlDgkVyXxTcUOJb(exception)
   return iPentRGuNMKQALdmlDgkVyXxTcUOJw
  if re_check==iPentRGuNMKQALdmlDgkVyXxTcUOJw:
   iPentRGuNMKQALdmlDgkVyXxTcUOhb =iPentRGuNMKQALdmlDgkVyXxTcUOBq.Get_Now_Datetime()
   iPentRGuNMKQALdmlDgkVyXxTcUOhE=iPentRGuNMKQALdmlDgkVyXxTcUOhb+datetime.timedelta(days=limit_days)
   iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['limitdate']=iPentRGuNMKQALdmlDgkVyXxTcUOhE.strftime('%Y-%m-%d')
  else:
   iPentRGuNMKQALdmlDgkVyXxTcUOJb('re check')
  iPentRGuNMKQALdmlDgkVyXxTcUOBq.dic_To_jsonfile(iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP_COOKIE_FILENAME,iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP)
  return iPentRGuNMKQALdmlDgkVyXxTcUOJC
 def Get_Category_GroupList(iPentRGuNMKQALdmlDgkVyXxTcUOBq,vType):
  iPentRGuNMKQALdmlDgkVyXxTcUOhS=[] 
  try:
   iPentRGuNMKQALdmlDgkVyXxTcUOhJ=iPentRGuNMKQALdmlDgkVyXxTcUOBq.API_VIEWURL+'/v2/discover/feed' 
   iPentRGuNMKQALdmlDgkVyXxTcUOho={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false',}
   iPentRGuNMKQALdmlDgkVyXxTcUOhI=iPentRGuNMKQALdmlDgkVyXxTcUOBq.callRequestCookies('Get',iPentRGuNMKQALdmlDgkVyXxTcUOhJ,payload=iPentRGuNMKQALdmlDgkVyXxTcUOJY,params=iPentRGuNMKQALdmlDgkVyXxTcUOho,headers=iPentRGuNMKQALdmlDgkVyXxTcUOJY,cookies=iPentRGuNMKQALdmlDgkVyXxTcUOJY,redirects=iPentRGuNMKQALdmlDgkVyXxTcUOJC)
   if iPentRGuNMKQALdmlDgkVyXxTcUOhI.status_code not in[200]:return[]
   iPentRGuNMKQALdmlDgkVyXxTcUOhW=json.loads(iPentRGuNMKQALdmlDgkVyXxTcUOhI.text)
   if vType in['TVSHOWS','MOVIES']:
    iPentRGuNMKQALdmlDgkVyXxTcUOhv='Explores' 
   elif vType in['EDUCATION']:
    iPentRGuNMKQALdmlDgkVyXxTcUOhv='Collection-Rails-Curation'
   elif vType in['ALL','KIDS']:
    iPentRGuNMKQALdmlDgkVyXxTcUOhv='Explores-Categories'
   for iPentRGuNMKQALdmlDgkVyXxTcUOhp in iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('data'):
    if iPentRGuNMKQALdmlDgkVyXxTcUOhp.get('type')==iPentRGuNMKQALdmlDgkVyXxTcUOhv:
     for iPentRGuNMKQALdmlDgkVyXxTcUOhC in iPentRGuNMKQALdmlDgkVyXxTcUOhp.get('data'):
      if vType in['TVSHOWS','MOVIES']:
       iPentRGuNMKQALdmlDgkVyXxTcUOhf=iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('collectionId')
      elif vType in['EDUCATION','ALL','KIDS']:
       iPentRGuNMKQALdmlDgkVyXxTcUOhf=iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('id')
      iPentRGuNMKQALdmlDgkVyXxTcUOhj={'collectionId':iPentRGuNMKQALdmlDgkVyXxTcUOhf,'title':iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('name'),'category':iPentRGuNMKQALdmlDgkVyXxTcUOhp.get('category'),'pre_title':'',}
      iPentRGuNMKQALdmlDgkVyXxTcUOhS.append(iPentRGuNMKQALdmlDgkVyXxTcUOhj)
     break
  except iPentRGuNMKQALdmlDgkVyXxTcUOJv as exception:
   iPentRGuNMKQALdmlDgkVyXxTcUOJb(exception)
   return[]
  return iPentRGuNMKQALdmlDgkVyXxTcUOhS
 def Get_Category_List(iPentRGuNMKQALdmlDgkVyXxTcUOBq,vType,iPentRGuNMKQALdmlDgkVyXxTcUOhf,page_int):
  iPentRGuNMKQALdmlDgkVyXxTcUOhS=[] 
  iPentRGuNMKQALdmlDgkVyXxTcUOqB=iPentRGuNMKQALdmlDgkVyXxTcUOJw
  try:
   if vType in['ALL','KIDS']:
    iPentRGuNMKQALdmlDgkVyXxTcUOhz={'x-membersrl':iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['member_srl'],'x-pcid':iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['PCID'],'x-profileid':iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['profileId'],}
    iPentRGuNMKQALdmlDgkVyXxTcUOho={'platform':'WEBCLIENT','page':iPentRGuNMKQALdmlDgkVyXxTcUOJE(page_int),'perPage':iPentRGuNMKQALdmlDgkVyXxTcUOJE(iPentRGuNMKQALdmlDgkVyXxTcUOBq.PAGE_LIMIT),'locale':'ko','sort':'',}
    iPentRGuNMKQALdmlDgkVyXxTcUOhJ=iPentRGuNMKQALdmlDgkVyXxTcUOBq.API_VIEWURL+'/v1/discover/categories/'+iPentRGuNMKQALdmlDgkVyXxTcUOhf+'/titles'
    iPentRGuNMKQALdmlDgkVyXxTcUOhI=iPentRGuNMKQALdmlDgkVyXxTcUOBq.callRequestCookies('Get',iPentRGuNMKQALdmlDgkVyXxTcUOhJ,payload=iPentRGuNMKQALdmlDgkVyXxTcUOJY,params=iPentRGuNMKQALdmlDgkVyXxTcUOho,headers=iPentRGuNMKQALdmlDgkVyXxTcUOhz,cookies=iPentRGuNMKQALdmlDgkVyXxTcUOJY,redirects=iPentRGuNMKQALdmlDgkVyXxTcUOJC)
   else: 
    iPentRGuNMKQALdmlDgkVyXxTcUOho={'platform':'WEBCLIENT','page':iPentRGuNMKQALdmlDgkVyXxTcUOJE(page_int),'perPage':iPentRGuNMKQALdmlDgkVyXxTcUOJE(iPentRGuNMKQALdmlDgkVyXxTcUOBq.PAGE_LIMIT),}
    iPentRGuNMKQALdmlDgkVyXxTcUOhJ=iPentRGuNMKQALdmlDgkVyXxTcUOBq.API_VIEWURL+'/v1/discover/collections/'+iPentRGuNMKQALdmlDgkVyXxTcUOhf+'/titles'
    iPentRGuNMKQALdmlDgkVyXxTcUOhI=iPentRGuNMKQALdmlDgkVyXxTcUOBq.callRequestCookies('Get',iPentRGuNMKQALdmlDgkVyXxTcUOhJ,payload=iPentRGuNMKQALdmlDgkVyXxTcUOJY,params=iPentRGuNMKQALdmlDgkVyXxTcUOho,headers=iPentRGuNMKQALdmlDgkVyXxTcUOJY,cookies=iPentRGuNMKQALdmlDgkVyXxTcUOJY,redirects=iPentRGuNMKQALdmlDgkVyXxTcUOJC)
   if iPentRGuNMKQALdmlDgkVyXxTcUOhI.status_code not in[200]:return[],iPentRGuNMKQALdmlDgkVyXxTcUOJw
   iPentRGuNMKQALdmlDgkVyXxTcUOhW=json.loads(iPentRGuNMKQALdmlDgkVyXxTcUOhI.text)
   if vType in['ALL','KIDS']:
    iPentRGuNMKQALdmlDgkVyXxTcUOqh=iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('data').get('data')
   else:
    iPentRGuNMKQALdmlDgkVyXxTcUOqh=iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('data')
   for iPentRGuNMKQALdmlDgkVyXxTcUOhC in iPentRGuNMKQALdmlDgkVyXxTcUOqh:
    iPentRGuNMKQALdmlDgkVyXxTcUOqJ=iPentRGuNMKQALdmlDgkVyXxTcUOqF=iPentRGuNMKQALdmlDgkVyXxTcUOJa=iPentRGuNMKQALdmlDgkVyXxTcUOJH=''
    if 'poster' in iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('images'):iPentRGuNMKQALdmlDgkVyXxTcUOqJ =iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('images'):iPentRGuNMKQALdmlDgkVyXxTcUOqF =iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('images').get('story-art').get('url') +'?imwidth=600'
    if 'title-treatment' in iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('images'):iPentRGuNMKQALdmlDgkVyXxTcUOJa=iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('images').get('title-treatment').get('url')+'?imwidth=300'
    if 'story-art' in iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('images'):iPentRGuNMKQALdmlDgkVyXxTcUOJH =iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('images').get('story-art').get('url') +'?imwidth=600'
    iPentRGuNMKQALdmlDgkVyXxTcUOqI=''
    if iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('badge')not in[{},iPentRGuNMKQALdmlDgkVyXxTcUOJY]:
     for i in iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('badge').get('text'):
      iPentRGuNMKQALdmlDgkVyXxTcUOqI+=i.get('text')
    iPentRGuNMKQALdmlDgkVyXxTcUOqr=''
    if iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('seasonList')!=iPentRGuNMKQALdmlDgkVyXxTcUOJY:
     iPentRGuNMKQALdmlDgkVyXxTcUOqr=','.join(iPentRGuNMKQALdmlDgkVyXxTcUOJE(e)for e in iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('seasonList'))
    iPentRGuNMKQALdmlDgkVyXxTcUOqH =[]
    for iPentRGuNMKQALdmlDgkVyXxTcUOqa in iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('tags'):
     iPentRGuNMKQALdmlDgkVyXxTcUOqH.append(iPentRGuNMKQALdmlDgkVyXxTcUOqa.get('tag'))
    iPentRGuNMKQALdmlDgkVyXxTcUOhj={'id':iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('id'),'title':iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('title'),'thumbnail':{'poster':iPentRGuNMKQALdmlDgkVyXxTcUOqJ,'thumb':iPentRGuNMKQALdmlDgkVyXxTcUOqF,'clearlogo':iPentRGuNMKQALdmlDgkVyXxTcUOJa,'fanart':iPentRGuNMKQALdmlDgkVyXxTcUOJH},'mpaa':iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('age_rating'),'duration':iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('running_time'),'asis':iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('as'),'badge':iPentRGuNMKQALdmlDgkVyXxTcUOqI,'year':iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('meta').get('releaseYear'),'seasonList':iPentRGuNMKQALdmlDgkVyXxTcUOqr,'genreList':iPentRGuNMKQALdmlDgkVyXxTcUOqH,}
    iPentRGuNMKQALdmlDgkVyXxTcUOhS.append(iPentRGuNMKQALdmlDgkVyXxTcUOhj)
   if iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('pagination').get('totalPages')>page_int:
    iPentRGuNMKQALdmlDgkVyXxTcUOqB=iPentRGuNMKQALdmlDgkVyXxTcUOJC
  except iPentRGuNMKQALdmlDgkVyXxTcUOJv as exception:
   iPentRGuNMKQALdmlDgkVyXxTcUOJb(exception)
   return[],iPentRGuNMKQALdmlDgkVyXxTcUOJw
  return iPentRGuNMKQALdmlDgkVyXxTcUOhS,iPentRGuNMKQALdmlDgkVyXxTcUOqB
 def Get_Episode_List(iPentRGuNMKQALdmlDgkVyXxTcUOBq,programId,season):
  iPentRGuNMKQALdmlDgkVyXxTcUOhS=[] 
  try:
   iPentRGuNMKQALdmlDgkVyXxTcUOhJ=iPentRGuNMKQALdmlDgkVyXxTcUOBq.API_VIEWURL+'/v1/discover/titles/'+programId+'/episodes'
   iPentRGuNMKQALdmlDgkVyXxTcUOho={'season':season,'sort':'true','locale':'ko',}
   iPentRGuNMKQALdmlDgkVyXxTcUOhI=iPentRGuNMKQALdmlDgkVyXxTcUOBq.callRequestCookies('Get',iPentRGuNMKQALdmlDgkVyXxTcUOhJ,payload=iPentRGuNMKQALdmlDgkVyXxTcUOJY,params=iPentRGuNMKQALdmlDgkVyXxTcUOho,headers=iPentRGuNMKQALdmlDgkVyXxTcUOJY,cookies=iPentRGuNMKQALdmlDgkVyXxTcUOJY,redirects=iPentRGuNMKQALdmlDgkVyXxTcUOJC)
   if iPentRGuNMKQALdmlDgkVyXxTcUOhI.status_code not in[200]:return[]
   iPentRGuNMKQALdmlDgkVyXxTcUOhW=json.loads(iPentRGuNMKQALdmlDgkVyXxTcUOhI.text)
   for iPentRGuNMKQALdmlDgkVyXxTcUOhC in iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('data'):
    iPentRGuNMKQALdmlDgkVyXxTcUOqF=''
    if 'story-art' in iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('images'):iPentRGuNMKQALdmlDgkVyXxTcUOqF =iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('images').get('story-art').get('url')+'?imwidth=600'
    iPentRGuNMKQALdmlDgkVyXxTcUOqH =[]
    for iPentRGuNMKQALdmlDgkVyXxTcUOqa in iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('tags'):
     iPentRGuNMKQALdmlDgkVyXxTcUOqH.append(iPentRGuNMKQALdmlDgkVyXxTcUOqa.get('tag'))
    iPentRGuNMKQALdmlDgkVyXxTcUOhj={'id':iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('id'),'title':iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('title'),'thumbnail':{'thumb':iPentRGuNMKQALdmlDgkVyXxTcUOqF,'fanart':iPentRGuNMKQALdmlDgkVyXxTcUOqF},'mpaa':iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('age_rating'),'duration':iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('running_time'),'asis':iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('as'),'year':iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('meta').get('releaseYear'),'episode':iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('episode'),'genreList':iPentRGuNMKQALdmlDgkVyXxTcUOqH,'desc':iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('description'),}
    iPentRGuNMKQALdmlDgkVyXxTcUOhS.append(iPentRGuNMKQALdmlDgkVyXxTcUOhj)
  except iPentRGuNMKQALdmlDgkVyXxTcUOJv as exception:
   iPentRGuNMKQALdmlDgkVyXxTcUOJb(exception)
   return[]
  return iPentRGuNMKQALdmlDgkVyXxTcUOhS
 def Get_vInfo(iPentRGuNMKQALdmlDgkVyXxTcUOBq,titleId):
  try:
   iPentRGuNMKQALdmlDgkVyXxTcUOhJ=iPentRGuNMKQALdmlDgkVyXxTcUOBq.API_VIEWURL+'/v1/discover/titles/'+titleId 
   iPentRGuNMKQALdmlDgkVyXxTcUOho={'platform':'WEBCLIENT','locale':'ko','filterRestrictedContent':'false',}
   iPentRGuNMKQALdmlDgkVyXxTcUOhI=iPentRGuNMKQALdmlDgkVyXxTcUOBq.callRequestCookies('Get',iPentRGuNMKQALdmlDgkVyXxTcUOhJ,payload=iPentRGuNMKQALdmlDgkVyXxTcUOJY,params=iPentRGuNMKQALdmlDgkVyXxTcUOho,headers=iPentRGuNMKQALdmlDgkVyXxTcUOJY,cookies=iPentRGuNMKQALdmlDgkVyXxTcUOJY,redirects=iPentRGuNMKQALdmlDgkVyXxTcUOJC)
   if iPentRGuNMKQALdmlDgkVyXxTcUOhI.status_code not in[200]:return '','',''
   iPentRGuNMKQALdmlDgkVyXxTcUOhW=json.loads(iPentRGuNMKQALdmlDgkVyXxTcUOhI.text).get('data')
   iPentRGuNMKQALdmlDgkVyXxTcUOqr=''
   if iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('seasonList')!=iPentRGuNMKQALdmlDgkVyXxTcUOJY:
    iPentRGuNMKQALdmlDgkVyXxTcUOqr=','.join(iPentRGuNMKQALdmlDgkVyXxTcUOJE(e)for e in iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('seasonList'))
   iPentRGuNMKQALdmlDgkVyXxTcUOqz={'age_rating':iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('age_rating'),'asset_id':iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('asset_id'),'availability':iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('availability'),'deal_id':iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('deal_id'),'downloadable':'true' if iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('downloadable')else 'false','region':iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('region'),'streamable':'true' if iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('streamable')else 'false','asis':iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('as'),'seasonList':iPentRGuNMKQALdmlDgkVyXxTcUOqr}
  except iPentRGuNMKQALdmlDgkVyXxTcUOJv as exception:
   iPentRGuNMKQALdmlDgkVyXxTcUOJb(exception)
   return{}
  return iPentRGuNMKQALdmlDgkVyXxTcUOqz
 def Get_eInfo(iPentRGuNMKQALdmlDgkVyXxTcUOBq,eventId):
  try:
   iPentRGuNMKQALdmlDgkVyXxTcUOhJ=iPentRGuNMKQALdmlDgkVyXxTcUOBq.API_VIEWURL+'/v1/discover/events/'+eventId 
   iPentRGuNMKQALdmlDgkVyXxTcUOho={'locale':'ko'}
   iPentRGuNMKQALdmlDgkVyXxTcUOhI=iPentRGuNMKQALdmlDgkVyXxTcUOBq.callRequestCookies('Get',iPentRGuNMKQALdmlDgkVyXxTcUOhJ,payload=iPentRGuNMKQALdmlDgkVyXxTcUOJY,params=iPentRGuNMKQALdmlDgkVyXxTcUOho,headers=iPentRGuNMKQALdmlDgkVyXxTcUOJY,cookies=iPentRGuNMKQALdmlDgkVyXxTcUOJY,redirects=iPentRGuNMKQALdmlDgkVyXxTcUOJC)
   if iPentRGuNMKQALdmlDgkVyXxTcUOhI.status_code not in[200]:return '','',''
   iPentRGuNMKQALdmlDgkVyXxTcUOhW=json.loads(iPentRGuNMKQALdmlDgkVyXxTcUOhI.text).get('data')
   iPentRGuNMKQALdmlDgkVyXxTcUOqz={'asset_id':iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('asset_id'),'deal_id':iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('deal_id'),'region':iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('region'),'streamable':'true' if iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('streamable')else 'false',}
  except iPentRGuNMKQALdmlDgkVyXxTcUOJv as exception:
   iPentRGuNMKQALdmlDgkVyXxTcUOJb(exception)
   return{}
  return iPentRGuNMKQALdmlDgkVyXxTcUOqz
 def GetBroadURL(iPentRGuNMKQALdmlDgkVyXxTcUOBq,titleId):
  iPentRGuNMKQALdmlDgkVyXxTcUOqs=''
  iPentRGuNMKQALdmlDgkVyXxTcUOqW =''
  iPentRGuNMKQALdmlDgkVyXxTcUOqz=iPentRGuNMKQALdmlDgkVyXxTcUOBq.Get_vInfo(titleId)
  if iPentRGuNMKQALdmlDgkVyXxTcUOqz=={}:return '',''
  try:
   iPentRGuNMKQALdmlDgkVyXxTcUOhJ=iPentRGuNMKQALdmlDgkVyXxTcUOBq.API_DOMAIN+'/api/playback/play' 
   iPentRGuNMKQALdmlDgkVyXxTcUOho={'titleId':titleId}
   iPentRGuNMKQALdmlDgkVyXxTcUOBv,iPentRGuNMKQALdmlDgkVyXxTcUOBp,iPentRGuNMKQALdmlDgkVyXxTcUOBC=iPentRGuNMKQALdmlDgkVyXxTcUOBq.Make_authHeader()
   iPentRGuNMKQALdmlDgkVyXxTcUOhz={'traceparent':iPentRGuNMKQALdmlDgkVyXxTcUOBv,'tracestate':iPentRGuNMKQALdmlDgkVyXxTcUOBp,'newrelic':iPentRGuNMKQALdmlDgkVyXxTcUOBC,'x-drm':'com.microsoft.playready','x-app-version':'1.33.5','x-device-id':'','x-device-os-version':iPentRGuNMKQALdmlDgkVyXxTcUOBq.OS_VERSION,'x-force-raw':'true','x-nr-session-id':iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['session_web_id'],'x-pcid':iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['profileId'],'x-profileType':'standard','x-sessionid':iPentRGuNMKQALdmlDgkVyXxTcUOBq.generatePvId(genType='1'),'x-title-age-rating':iPentRGuNMKQALdmlDgkVyXxTcUOqz.get('age_rating'),'x-title-availability':iPentRGuNMKQALdmlDgkVyXxTcUOqz.get('availability'),'x-title-brightcove-id':iPentRGuNMKQALdmlDgkVyXxTcUOqz.get('asset_id'),'x-title-deal-id':iPentRGuNMKQALdmlDgkVyXxTcUOqz.get('deal_id'),'x-title-downloadable':iPentRGuNMKQALdmlDgkVyXxTcUOqz.get('downloadable'),'x-title-region':iPentRGuNMKQALdmlDgkVyXxTcUOqz.get('region'),'x-title-streamable':iPentRGuNMKQALdmlDgkVyXxTcUOqz.get('streamable'),}
   iPentRGuNMKQALdmlDgkVyXxTcUOhq=iPentRGuNMKQALdmlDgkVyXxTcUOBq.make_CP_DefaultCookies()
   iPentRGuNMKQALdmlDgkVyXxTcUOhI=iPentRGuNMKQALdmlDgkVyXxTcUOBq.callRequestCookies('Get',iPentRGuNMKQALdmlDgkVyXxTcUOhJ,payload=iPentRGuNMKQALdmlDgkVyXxTcUOJY,params=iPentRGuNMKQALdmlDgkVyXxTcUOho,headers=iPentRGuNMKQALdmlDgkVyXxTcUOhz,cookies=iPentRGuNMKQALdmlDgkVyXxTcUOhq,redirects=iPentRGuNMKQALdmlDgkVyXxTcUOJC)
   if iPentRGuNMKQALdmlDgkVyXxTcUOhI.status_code not in[200]:return '',json.loads(iPentRGuNMKQALdmlDgkVyXxTcUOhI.text).get('error').get('detail')
   iPentRGuNMKQALdmlDgkVyXxTcUOhW=json.loads(iPentRGuNMKQALdmlDgkVyXxTcUOhI.text)
   if iPentRGuNMKQALdmlDgkVyXxTcUOqs=='':
    for iPentRGuNMKQALdmlDgkVyXxTcUOhC in iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('data').get('raw').get('sources'):
     if 'key_systems' in iPentRGuNMKQALdmlDgkVyXxTcUOhC and 'codecs' not in iPentRGuNMKQALdmlDgkVyXxTcUOhC:
      if iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('type')=='application/dash+xml' and 'com.widevine.alpha' in iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('key_systems')and iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('src').startswith('https://')==iPentRGuNMKQALdmlDgkVyXxTcUOJC:
       iPentRGuNMKQALdmlDgkVyXxTcUOqs=iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('src')
       iPentRGuNMKQALdmlDgkVyXxTcUOqW =iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if iPentRGuNMKQALdmlDgkVyXxTcUOqs=='':
    for iPentRGuNMKQALdmlDgkVyXxTcUOhC in iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('data').get('raw').get('sources'):
     if 'key_systems' in iPentRGuNMKQALdmlDgkVyXxTcUOhC and 'codecs' not in iPentRGuNMKQALdmlDgkVyXxTcUOhC:
      if iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('key_systems')and iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('src').startswith('https://')==iPentRGuNMKQALdmlDgkVyXxTcUOJC:
       iPentRGuNMKQALdmlDgkVyXxTcUOqs=iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('src')
       iPentRGuNMKQALdmlDgkVyXxTcUOqW =iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if iPentRGuNMKQALdmlDgkVyXxTcUOqs=='':
    for iPentRGuNMKQALdmlDgkVyXxTcUOhC in iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('data').get('raw').get('sources'):
     if 'key_systems' in iPentRGuNMKQALdmlDgkVyXxTcUOhC and 'codecs' in iPentRGuNMKQALdmlDgkVyXxTcUOhC:
      if iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('type')=='application/dash+xml' and 'com.widevine.alpha' in iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('key_systems')and iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('src').startswith('https://')==iPentRGuNMKQALdmlDgkVyXxTcUOJC:
       iPentRGuNMKQALdmlDgkVyXxTcUOqs=iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('src')
       iPentRGuNMKQALdmlDgkVyXxTcUOqW =iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if iPentRGuNMKQALdmlDgkVyXxTcUOqs=='':
    for iPentRGuNMKQALdmlDgkVyXxTcUOhC in iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('data').get('raw').get('sources'):
     if 'key_systems' in iPentRGuNMKQALdmlDgkVyXxTcUOhC and 'codecs' in iPentRGuNMKQALdmlDgkVyXxTcUOhC:
      if iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('key_systems')and iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('src').startswith('https://')==iPentRGuNMKQALdmlDgkVyXxTcUOJC:
       iPentRGuNMKQALdmlDgkVyXxTcUOqs=iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('src')
       iPentRGuNMKQALdmlDgkVyXxTcUOqW =iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
  except iPentRGuNMKQALdmlDgkVyXxTcUOJv as exception:
   iPentRGuNMKQALdmlDgkVyXxTcUOJb(exception)
   return '',''
  return iPentRGuNMKQALdmlDgkVyXxTcUOqs,iPentRGuNMKQALdmlDgkVyXxTcUOqW
 def GetEventURL(iPentRGuNMKQALdmlDgkVyXxTcUOBq,eventId,iPentRGuNMKQALdmlDgkVyXxTcUOJB):
  iPentRGuNMKQALdmlDgkVyXxTcUOqs=''
  iPentRGuNMKQALdmlDgkVyXxTcUOqW =''
  iPentRGuNMKQALdmlDgkVyXxTcUOqz=iPentRGuNMKQALdmlDgkVyXxTcUOBq.Get_eInfo(eventId)
  if iPentRGuNMKQALdmlDgkVyXxTcUOqz=={}:return '',''
  try:
   iPentRGuNMKQALdmlDgkVyXxTcUOhJ=iPentRGuNMKQALdmlDgkVyXxTcUOBq.API_DOMAIN+'/api/playback/play' 
   iPentRGuNMKQALdmlDgkVyXxTcUOho={'titleId':eventId,'titleType':iPentRGuNMKQALdmlDgkVyXxTcUOJB,}
   iPentRGuNMKQALdmlDgkVyXxTcUOBv,iPentRGuNMKQALdmlDgkVyXxTcUOBp,iPentRGuNMKQALdmlDgkVyXxTcUOBC=iPentRGuNMKQALdmlDgkVyXxTcUOBq.Make_authHeader()
   iPentRGuNMKQALdmlDgkVyXxTcUOhz={'traceparent':iPentRGuNMKQALdmlDgkVyXxTcUOBv,'tracestate':iPentRGuNMKQALdmlDgkVyXxTcUOBp,'newrelic':iPentRGuNMKQALdmlDgkVyXxTcUOBC,'x-force-raw':'true','x-pcid':iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':iPentRGuNMKQALdmlDgkVyXxTcUOqz.get('asset_id'),'x-title-deal-id':iPentRGuNMKQALdmlDgkVyXxTcUOqz.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':iPentRGuNMKQALdmlDgkVyXxTcUOqz.get('region'),'x-title-streamable':iPentRGuNMKQALdmlDgkVyXxTcUOqz.get('streamable'),}
   iPentRGuNMKQALdmlDgkVyXxTcUOhq=iPentRGuNMKQALdmlDgkVyXxTcUOBq.make_CP_DefaultCookies()
   iPentRGuNMKQALdmlDgkVyXxTcUOhI=iPentRGuNMKQALdmlDgkVyXxTcUOBq.callRequestCookies('Get',iPentRGuNMKQALdmlDgkVyXxTcUOhJ,payload=iPentRGuNMKQALdmlDgkVyXxTcUOJY,params=iPentRGuNMKQALdmlDgkVyXxTcUOho,headers=iPentRGuNMKQALdmlDgkVyXxTcUOhz,cookies=iPentRGuNMKQALdmlDgkVyXxTcUOhq,redirects=iPentRGuNMKQALdmlDgkVyXxTcUOJC)
   if iPentRGuNMKQALdmlDgkVyXxTcUOhI.status_code not in[200]:return '',json.loads(iPentRGuNMKQALdmlDgkVyXxTcUOhI.text).get('error').get('detail')
   iPentRGuNMKQALdmlDgkVyXxTcUOhW=json.loads(iPentRGuNMKQALdmlDgkVyXxTcUOhI.text)
   for iPentRGuNMKQALdmlDgkVyXxTcUOhC in iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('data').get('raw').get('sources'):
    if iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('type')=='application/dash+xml' and iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('src')[0:8]=='https://':
     iPentRGuNMKQALdmlDgkVyXxTcUOqs=iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('src')
     if 'key_systems' in iPentRGuNMKQALdmlDgkVyXxTcUOhC:
      iPentRGuNMKQALdmlDgkVyXxTcUOqW =iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('key_systems').get('com.widevine.alpha').get('license_url')
     break
  except iPentRGuNMKQALdmlDgkVyXxTcUOJv as exception:
   iPentRGuNMKQALdmlDgkVyXxTcUOJb(exception)
   return '',''
  return iPentRGuNMKQALdmlDgkVyXxTcUOqs,iPentRGuNMKQALdmlDgkVyXxTcUOqW
 def GetEventURL_Live(iPentRGuNMKQALdmlDgkVyXxTcUOBq,eventId,iPentRGuNMKQALdmlDgkVyXxTcUOJB):
  iPentRGuNMKQALdmlDgkVyXxTcUOqs=''
  iPentRGuNMKQALdmlDgkVyXxTcUOqW =''
  iPentRGuNMKQALdmlDgkVyXxTcUOqz=iPentRGuNMKQALdmlDgkVyXxTcUOBq.Get_eInfo(eventId)
  if iPentRGuNMKQALdmlDgkVyXxTcUOqz=={}:return '',''
  try:
   iPentRGuNMKQALdmlDgkVyXxTcUOhJ=iPentRGuNMKQALdmlDgkVyXxTcUOBq.API_DOMAIN+'/api/playback/play' 
   iPentRGuNMKQALdmlDgkVyXxTcUOho={'titleId':eventId,'titleType':iPentRGuNMKQALdmlDgkVyXxTcUOJB,}
   iPentRGuNMKQALdmlDgkVyXxTcUOBv,iPentRGuNMKQALdmlDgkVyXxTcUOBp,iPentRGuNMKQALdmlDgkVyXxTcUOBC=iPentRGuNMKQALdmlDgkVyXxTcUOBq.Make_authHeader()
   iPentRGuNMKQALdmlDgkVyXxTcUOhz={'traceparent':iPentRGuNMKQALdmlDgkVyXxTcUOBv,'tracestate':iPentRGuNMKQALdmlDgkVyXxTcUOBp,'newrelic':iPentRGuNMKQALdmlDgkVyXxTcUOBC,'x-force-raw':'true','x-pcid':iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':iPentRGuNMKQALdmlDgkVyXxTcUOqz.get('asset_id'),'x-title-deal-id':iPentRGuNMKQALdmlDgkVyXxTcUOqz.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':iPentRGuNMKQALdmlDgkVyXxTcUOqz.get('region'),'x-title-streamable':iPentRGuNMKQALdmlDgkVyXxTcUOqz.get('streamable'),}
   iPentRGuNMKQALdmlDgkVyXxTcUOhq=iPentRGuNMKQALdmlDgkVyXxTcUOBq.make_CP_DefaultCookies()
   iPentRGuNMKQALdmlDgkVyXxTcUOhI=iPentRGuNMKQALdmlDgkVyXxTcUOBq.callRequestCookies('Get',iPentRGuNMKQALdmlDgkVyXxTcUOhJ,payload=iPentRGuNMKQALdmlDgkVyXxTcUOJY,params=iPentRGuNMKQALdmlDgkVyXxTcUOho,headers=iPentRGuNMKQALdmlDgkVyXxTcUOhz,cookies=iPentRGuNMKQALdmlDgkVyXxTcUOhq,redirects=iPentRGuNMKQALdmlDgkVyXxTcUOJC)
   if iPentRGuNMKQALdmlDgkVyXxTcUOhI.status_code not in[200]:return '',json.loads(iPentRGuNMKQALdmlDgkVyXxTcUOhI.text).get('error').get('detail')
   iPentRGuNMKQALdmlDgkVyXxTcUOhW=json.loads(iPentRGuNMKQALdmlDgkVyXxTcUOhI.text)
   if iPentRGuNMKQALdmlDgkVyXxTcUOqs=='':
    for iPentRGuNMKQALdmlDgkVyXxTcUOhC in iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('data').get('raw').get('sources'):
     if 'key_systems' in iPentRGuNMKQALdmlDgkVyXxTcUOhC:
      if iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('type')=='application/dash+xml' and 'com.widevine.alpha' in iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('key_systems')and iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('src').startswith('https://')==iPentRGuNMKQALdmlDgkVyXxTcUOJC:
       iPentRGuNMKQALdmlDgkVyXxTcUOqs=iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('src')
       iPentRGuNMKQALdmlDgkVyXxTcUOqW =iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('key_systems').get('com.widevine.alpha').get('license_url')
   if iPentRGuNMKQALdmlDgkVyXxTcUOqs=='':
    for iPentRGuNMKQALdmlDgkVyXxTcUOhC in iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('data').get('raw').get('sources'):
     if 'key_systems' in iPentRGuNMKQALdmlDgkVyXxTcUOhC:
      if iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('key_systems')and iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('src').startswith('https://')==iPentRGuNMKQALdmlDgkVyXxTcUOJC:
       iPentRGuNMKQALdmlDgkVyXxTcUOqs=iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('src')
       iPentRGuNMKQALdmlDgkVyXxTcUOqW =iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('key_systems').get('com.widevine.alpha').get('license_url')
   if iPentRGuNMKQALdmlDgkVyXxTcUOqs=='':
    for iPentRGuNMKQALdmlDgkVyXxTcUOhC in iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('data').get('raw').get('sources'):
     if iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('type')=='application/dash+xml' and iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('src').startswith('https://')==iPentRGuNMKQALdmlDgkVyXxTcUOJC:
      iPentRGuNMKQALdmlDgkVyXxTcUOqs=iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('src')
   if iPentRGuNMKQALdmlDgkVyXxTcUOqs=='':
    for iPentRGuNMKQALdmlDgkVyXxTcUOhC in iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('data').get('raw').get('sources'):
     if iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('type')=='application/x-mpegURL' and iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('src').startswith('https://')==iPentRGuNMKQALdmlDgkVyXxTcUOJC:
      iPentRGuNMKQALdmlDgkVyXxTcUOqs=iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('src')
  except iPentRGuNMKQALdmlDgkVyXxTcUOJv as exception:
   iPentRGuNMKQALdmlDgkVyXxTcUOJb(exception)
   return '',''
  return iPentRGuNMKQALdmlDgkVyXxTcUOqs,iPentRGuNMKQALdmlDgkVyXxTcUOqW
 def Get_Url_PostFix(iPentRGuNMKQALdmlDgkVyXxTcUOBq,in_url):
  iPentRGuNMKQALdmlDgkVyXxTcUOqY=urllib.parse.urlparse(in_url) 
  iPentRGuNMKQALdmlDgkVyXxTcUOqw =iPentRGuNMKQALdmlDgkVyXxTcUOqY.path.strip('/').split('/')
  iPentRGuNMKQALdmlDgkVyXxTcUOqb =iPentRGuNMKQALdmlDgkVyXxTcUOqw[iPentRGuNMKQALdmlDgkVyXxTcUOJf(iPentRGuNMKQALdmlDgkVyXxTcUOqw)-1]
  iPentRGuNMKQALdmlDgkVyXxTcUOqE=iPentRGuNMKQALdmlDgkVyXxTcUOqb.split('.')
  return iPentRGuNMKQALdmlDgkVyXxTcUOqE[iPentRGuNMKQALdmlDgkVyXxTcUOJf(iPentRGuNMKQALdmlDgkVyXxTcUOqE)-1]
 def Get_Theme_GroupList(iPentRGuNMKQALdmlDgkVyXxTcUOBq,vType):
  iPentRGuNMKQALdmlDgkVyXxTcUOhS=[] 
  try:
   iPentRGuNMKQALdmlDgkVyXxTcUOhJ=iPentRGuNMKQALdmlDgkVyXxTcUOBq.API_VIEWURL+'/v2/discover/feed' 
   iPentRGuNMKQALdmlDgkVyXxTcUOho={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':iPentRGuNMKQALdmlDgkVyXxTcUOJE(iPentRGuNMKQALdmlDgkVyXxTcUOBq.PAGE_LIMIT),'filterRestrictedContent':'false',}
   iPentRGuNMKQALdmlDgkVyXxTcUOhI=iPentRGuNMKQALdmlDgkVyXxTcUOBq.callRequestCookies('Get',iPentRGuNMKQALdmlDgkVyXxTcUOhJ,payload=iPentRGuNMKQALdmlDgkVyXxTcUOJY,params=iPentRGuNMKQALdmlDgkVyXxTcUOho,headers=iPentRGuNMKQALdmlDgkVyXxTcUOJY,cookies=iPentRGuNMKQALdmlDgkVyXxTcUOJY,redirects=iPentRGuNMKQALdmlDgkVyXxTcUOJC)
   if iPentRGuNMKQALdmlDgkVyXxTcUOhI.status_code not in[200]:return[]
   iPentRGuNMKQALdmlDgkVyXxTcUOhW=json.loads(iPentRGuNMKQALdmlDgkVyXxTcUOhI.text)
   for iPentRGuNMKQALdmlDgkVyXxTcUOhC in iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('data'):
    if iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('type')=='Title-Rails-Curation':
     iPentRGuNMKQALdmlDgkVyXxTcUOqS =''
     iPentRGuNMKQALdmlDgkVyXxTcUOqo=7
     try:
      for i in iPentRGuNMKQALdmlDgkVyXxTcUOJj(iPentRGuNMKQALdmlDgkVyXxTcUOJf(iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('data'))):
       if i>=iPentRGuNMKQALdmlDgkVyXxTcUOqo:
        iPentRGuNMKQALdmlDgkVyXxTcUOqS=iPentRGuNMKQALdmlDgkVyXxTcUOqS+'...'
        break
       iPentRGuNMKQALdmlDgkVyXxTcUOqS=iPentRGuNMKQALdmlDgkVyXxTcUOqS+iPentRGuNMKQALdmlDgkVyXxTcUOhC['data'][i]['title']+'\n'
     except iPentRGuNMKQALdmlDgkVyXxTcUOJv as exception:
      iPentRGuNMKQALdmlDgkVyXxTcUOJb(exception)
     iPentRGuNMKQALdmlDgkVyXxTcUOhj={'collectionId':iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('obj_id'),'title':iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('row_name'),'category':iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('category'),'pre_title':iPentRGuNMKQALdmlDgkVyXxTcUOqS,}
     iPentRGuNMKQALdmlDgkVyXxTcUOhS.append(iPentRGuNMKQALdmlDgkVyXxTcUOhj)
  except iPentRGuNMKQALdmlDgkVyXxTcUOJv as exception:
   iPentRGuNMKQALdmlDgkVyXxTcUOJb(exception)
   return[]
  return iPentRGuNMKQALdmlDgkVyXxTcUOhS
 def Get_Event_GroupList(iPentRGuNMKQALdmlDgkVyXxTcUOBq):
  iPentRGuNMKQALdmlDgkVyXxTcUOhS=[] 
  try:
   iPentRGuNMKQALdmlDgkVyXxTcUOhJ=iPentRGuNMKQALdmlDgkVyXxTcUOBq.API_VIEWURL+'/v2/discover/feed' 
   iPentRGuNMKQALdmlDgkVyXxTcUOho={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':7,'filterRestrictedContent':'false',}
   iPentRGuNMKQALdmlDgkVyXxTcUOhI=iPentRGuNMKQALdmlDgkVyXxTcUOBq.callRequestCookies('Get',iPentRGuNMKQALdmlDgkVyXxTcUOhJ,payload=iPentRGuNMKQALdmlDgkVyXxTcUOJY,params=iPentRGuNMKQALdmlDgkVyXxTcUOho,headers=iPentRGuNMKQALdmlDgkVyXxTcUOJY,cookies=iPentRGuNMKQALdmlDgkVyXxTcUOJY,redirects=iPentRGuNMKQALdmlDgkVyXxTcUOJC)
   if iPentRGuNMKQALdmlDgkVyXxTcUOhI.status_code not in[200]:return[]
   iPentRGuNMKQALdmlDgkVyXxTcUOhW=json.loads(iPentRGuNMKQALdmlDgkVyXxTcUOhI.text)
   for iPentRGuNMKQALdmlDgkVyXxTcUOhC in iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('data'):
    if iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('row_name').strip()!='':
     iPentRGuNMKQALdmlDgkVyXxTcUOqS =''
     iPentRGuNMKQALdmlDgkVyXxTcUOqo=7
     try:
      for i in iPentRGuNMKQALdmlDgkVyXxTcUOJj(iPentRGuNMKQALdmlDgkVyXxTcUOJf(iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('data'))):
       if i>=iPentRGuNMKQALdmlDgkVyXxTcUOqo:
        iPentRGuNMKQALdmlDgkVyXxTcUOqS=iPentRGuNMKQALdmlDgkVyXxTcUOqS+'...'
        break
       iPentRGuNMKQALdmlDgkVyXxTcUOqS=iPentRGuNMKQALdmlDgkVyXxTcUOqS+iPentRGuNMKQALdmlDgkVyXxTcUOhC['data'][i]['title']+'\n'
     except iPentRGuNMKQALdmlDgkVyXxTcUOJv as exception:
      iPentRGuNMKQALdmlDgkVyXxTcUOJb(exception)
     iPentRGuNMKQALdmlDgkVyXxTcUOhj={'collectionId':iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('obj_id'),'title':iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('row_name'),'category':iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('type'),'pre_title':iPentRGuNMKQALdmlDgkVyXxTcUOqS,}
     iPentRGuNMKQALdmlDgkVyXxTcUOhS.append(iPentRGuNMKQALdmlDgkVyXxTcUOhj)
  except iPentRGuNMKQALdmlDgkVyXxTcUOJv as exception:
   iPentRGuNMKQALdmlDgkVyXxTcUOJb(exception)
   return[]
  return iPentRGuNMKQALdmlDgkVyXxTcUOhS
 def Get_Event_GameList(iPentRGuNMKQALdmlDgkVyXxTcUOBq,iPentRGuNMKQALdmlDgkVyXxTcUOhf):
  iPentRGuNMKQALdmlDgkVyXxTcUOhS=[] 
  try:
   iPentRGuNMKQALdmlDgkVyXxTcUOhJ=iPentRGuNMKQALdmlDgkVyXxTcUOBq.API_VIEWURL+'/v2/discover/feed' 
   iPentRGuNMKQALdmlDgkVyXxTcUOho={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false',}
   iPentRGuNMKQALdmlDgkVyXxTcUOhI=iPentRGuNMKQALdmlDgkVyXxTcUOBq.callRequestCookies('Get',iPentRGuNMKQALdmlDgkVyXxTcUOhJ,payload=iPentRGuNMKQALdmlDgkVyXxTcUOJY,params=iPentRGuNMKQALdmlDgkVyXxTcUOho,headers=iPentRGuNMKQALdmlDgkVyXxTcUOJY,cookies=iPentRGuNMKQALdmlDgkVyXxTcUOJY,redirects=iPentRGuNMKQALdmlDgkVyXxTcUOJC)
   if iPentRGuNMKQALdmlDgkVyXxTcUOhI.status_code not in[200]:return[]
   iPentRGuNMKQALdmlDgkVyXxTcUOhW=json.loads(iPentRGuNMKQALdmlDgkVyXxTcUOhI.text)
   for iPentRGuNMKQALdmlDgkVyXxTcUOhC in iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('data'):
    if iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('obj_id')==iPentRGuNMKQALdmlDgkVyXxTcUOhf:
     for iPentRGuNMKQALdmlDgkVyXxTcUOqv in iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('data'):
      iPentRGuNMKQALdmlDgkVyXxTcUOqJ=iPentRGuNMKQALdmlDgkVyXxTcUOqF=iPentRGuNMKQALdmlDgkVyXxTcUOJH=''
      if 'poster' in iPentRGuNMKQALdmlDgkVyXxTcUOqv.get('images'):iPentRGuNMKQALdmlDgkVyXxTcUOqJ =iPentRGuNMKQALdmlDgkVyXxTcUOqv.get('images').get('poster').get('url') +'?imwidth=350'
      if 'story-art' in iPentRGuNMKQALdmlDgkVyXxTcUOqv.get('images'):iPentRGuNMKQALdmlDgkVyXxTcUOqF =iPentRGuNMKQALdmlDgkVyXxTcUOqv.get('images').get('story-art').get('url')+'?imwidth=600'
      if 'hero' in iPentRGuNMKQALdmlDgkVyXxTcUOqv.get('images'):iPentRGuNMKQALdmlDgkVyXxTcUOJH =iPentRGuNMKQALdmlDgkVyXxTcUOqv.get('images').get('hero').get('url') +'?imwidth=600'
      iPentRGuNMKQALdmlDgkVyXxTcUOqp=iPentRGuNMKQALdmlDgkVyXxTcUOqv.get('meta').get(iPentRGuNMKQALdmlDgkVyXxTcUOqv.get('category')).get(iPentRGuNMKQALdmlDgkVyXxTcUOqv.get('sub_category'))
      if 'league' in iPentRGuNMKQALdmlDgkVyXxTcUOqp:
       iPentRGuNMKQALdmlDgkVyXxTcUOqC=iPentRGuNMKQALdmlDgkVyXxTcUOqp.get('league')
      else:
       iPentRGuNMKQALdmlDgkVyXxTcUOqC=iPentRGuNMKQALdmlDgkVyXxTcUOqp.get('round')
      iPentRGuNMKQALdmlDgkVyXxTcUOhj={'id':iPentRGuNMKQALdmlDgkVyXxTcUOqv.get('id'),'title':iPentRGuNMKQALdmlDgkVyXxTcUOqv.get('title'),'thumbnail':{'poster':iPentRGuNMKQALdmlDgkVyXxTcUOqJ,'thumb':iPentRGuNMKQALdmlDgkVyXxTcUOqF,'fanart':iPentRGuNMKQALdmlDgkVyXxTcUOJH},'asis':iPentRGuNMKQALdmlDgkVyXxTcUOqv.get('type'),'addInfo':iPentRGuNMKQALdmlDgkVyXxTcUOqC,'starttm':iPentRGuNMKQALdmlDgkVyXxTcUOBq.convert_TimeStr(iPentRGuNMKQALdmlDgkVyXxTcUOqv.get('start_at')),}
      iPentRGuNMKQALdmlDgkVyXxTcUOhS.append(iPentRGuNMKQALdmlDgkVyXxTcUOhj)
  except iPentRGuNMKQALdmlDgkVyXxTcUOJv as exception:
   iPentRGuNMKQALdmlDgkVyXxTcUOJb(exception)
   return[]
  return iPentRGuNMKQALdmlDgkVyXxTcUOhS
 def Get_Event_List(iPentRGuNMKQALdmlDgkVyXxTcUOBq,gameId):
  iPentRGuNMKQALdmlDgkVyXxTcUOhS=[] 
  try:
   iPentRGuNMKQALdmlDgkVyXxTcUOhJ=iPentRGuNMKQALdmlDgkVyXxTcUOBq.API_VIEWURL+'/v1/discover/events/'+gameId 
   iPentRGuNMKQALdmlDgkVyXxTcUOho={'platform':'WEBCLIENT','locale':'ko','filterRestrictedContent':'false',}
   iPentRGuNMKQALdmlDgkVyXxTcUOhI=iPentRGuNMKQALdmlDgkVyXxTcUOBq.callRequestCookies('Get',iPentRGuNMKQALdmlDgkVyXxTcUOhJ,payload=iPentRGuNMKQALdmlDgkVyXxTcUOJY,params=iPentRGuNMKQALdmlDgkVyXxTcUOho,headers=iPentRGuNMKQALdmlDgkVyXxTcUOJY,cookies=iPentRGuNMKQALdmlDgkVyXxTcUOJY,redirects=iPentRGuNMKQALdmlDgkVyXxTcUOJC)
   if iPentRGuNMKQALdmlDgkVyXxTcUOhI.status_code not in[200]:return[]
   iPentRGuNMKQALdmlDgkVyXxTcUOhW=json.loads(iPentRGuNMKQALdmlDgkVyXxTcUOhI.text)
   iPentRGuNMKQALdmlDgkVyXxTcUOhC=iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('data')
   iPentRGuNMKQALdmlDgkVyXxTcUOqf=iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('end_at')
   iPentRGuNMKQALdmlDgkVyXxTcUOqf=iPentRGuNMKQALdmlDgkVyXxTcUOqf[0:19].replace('-','').replace(':','').replace('T','')
   iPentRGuNMKQALdmlDgkVyXxTcUOqj=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d%H%M%S')
   if iPentRGuNMKQALdmlDgkVyXxTcUOJo(iPentRGuNMKQALdmlDgkVyXxTcUOqj)<iPentRGuNMKQALdmlDgkVyXxTcUOJo(iPentRGuNMKQALdmlDgkVyXxTcUOqf):
    iPentRGuNMKQALdmlDgkVyXxTcUOqJ=iPentRGuNMKQALdmlDgkVyXxTcUOqF=iPentRGuNMKQALdmlDgkVyXxTcUOJH=''
    if 'poster' in iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('images'):iPentRGuNMKQALdmlDgkVyXxTcUOqJ =iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('images'):iPentRGuNMKQALdmlDgkVyXxTcUOqF =iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('images').get('story-art').get('url')+'?imwidth=600'
    if 'story-art' in iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('images'):iPentRGuNMKQALdmlDgkVyXxTcUOJH =iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('images').get('story-art').get('url')+'?imwidth=600'
    iPentRGuNMKQALdmlDgkVyXxTcUOhj={'id':iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('id'),'title':iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('title'),'thumbnail':{'poster':iPentRGuNMKQALdmlDgkVyXxTcUOqJ,'thumb':iPentRGuNMKQALdmlDgkVyXxTcUOqF,'fanart':iPentRGuNMKQALdmlDgkVyXxTcUOJH},'duration':iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('running_time'),'asis':iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('type'),'starttm':iPentRGuNMKQALdmlDgkVyXxTcUOBq.convert_TimeStr(iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('start_at')),}
    iPentRGuNMKQALdmlDgkVyXxTcUOhS.append(iPentRGuNMKQALdmlDgkVyXxTcUOhj)
  except iPentRGuNMKQALdmlDgkVyXxTcUOJv as exception:
   iPentRGuNMKQALdmlDgkVyXxTcUOJb(exception)
   return[]
  try:
   iPentRGuNMKQALdmlDgkVyXxTcUOhJ=iPentRGuNMKQALdmlDgkVyXxTcUOBq.API_VIEWURL+'/v1/discover/events/'+gameId+'/related' 
   iPentRGuNMKQALdmlDgkVyXxTcUOho={'locale':'ko','page':'1','perPage':'25','platform':'WEBCLIENT','currentPageTracking':'page_discover_title_detail',}
   iPentRGuNMKQALdmlDgkVyXxTcUOhI=iPentRGuNMKQALdmlDgkVyXxTcUOBq.callRequestCookies('Get',iPentRGuNMKQALdmlDgkVyXxTcUOhJ,payload=iPentRGuNMKQALdmlDgkVyXxTcUOJY,params=iPentRGuNMKQALdmlDgkVyXxTcUOho,headers=iPentRGuNMKQALdmlDgkVyXxTcUOJY,cookies=iPentRGuNMKQALdmlDgkVyXxTcUOJY,redirects=iPentRGuNMKQALdmlDgkVyXxTcUOJC)
   if iPentRGuNMKQALdmlDgkVyXxTcUOhI.status_code not in[200]:return[]
   iPentRGuNMKQALdmlDgkVyXxTcUOhW=json.loads(iPentRGuNMKQALdmlDgkVyXxTcUOhI.text)
   for iPentRGuNMKQALdmlDgkVyXxTcUOhC in iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('data').get('data'):
    iPentRGuNMKQALdmlDgkVyXxTcUOqJ=iPentRGuNMKQALdmlDgkVyXxTcUOqF=iPentRGuNMKQALdmlDgkVyXxTcUOJH=''
    if 'poster' in iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('images'):iPentRGuNMKQALdmlDgkVyXxTcUOqJ =iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('images'):iPentRGuNMKQALdmlDgkVyXxTcUOqF =iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('images').get('story-art').get('url')+'?imwidth=600'
    if 'story-art' in iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('images'):iPentRGuNMKQALdmlDgkVyXxTcUOJH =iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('images').get('story-art').get('url')+'?imwidth=600'
    iPentRGuNMKQALdmlDgkVyXxTcUOhj={'id':iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('id'),'title':iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('title'),'thumbnail':{'poster':iPentRGuNMKQALdmlDgkVyXxTcUOqJ,'thumb':iPentRGuNMKQALdmlDgkVyXxTcUOqF,'fanart':iPentRGuNMKQALdmlDgkVyXxTcUOJH},'duration':iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('running_time'),'asis':iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('type'),}
    iPentRGuNMKQALdmlDgkVyXxTcUOhS.append(iPentRGuNMKQALdmlDgkVyXxTcUOhj)
  except iPentRGuNMKQALdmlDgkVyXxTcUOJv as exception:
   iPentRGuNMKQALdmlDgkVyXxTcUOJb(exception)
   return[]
  return iPentRGuNMKQALdmlDgkVyXxTcUOhS
 def Get_Search_List(iPentRGuNMKQALdmlDgkVyXxTcUOBq,search_key,page_int):
  iPentRGuNMKQALdmlDgkVyXxTcUOhS=[] 
  iPentRGuNMKQALdmlDgkVyXxTcUOqB=iPentRGuNMKQALdmlDgkVyXxTcUOJw
  try:
   iPentRGuNMKQALdmlDgkVyXxTcUOhJ=iPentRGuNMKQALdmlDgkVyXxTcUOBq.API_VIEWURL+'/v2/search' 
   iPentRGuNMKQALdmlDgkVyXxTcUOho={'query':search_key,'platform':'WEBCLIENT','page':iPentRGuNMKQALdmlDgkVyXxTcUOJE(page_int),'perPage':iPentRGuNMKQALdmlDgkVyXxTcUOJE(iPentRGuNMKQALdmlDgkVyXxTcUOBq.SEARCH_LIMIT),}
   iPentRGuNMKQALdmlDgkVyXxTcUOhz={'x-membersrl':iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['member_srl'],'x-pcid':iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['PCID'],'x-profileid':iPentRGuNMKQALdmlDgkVyXxTcUOBq.CP['SESSION']['profileId'],}
   iPentRGuNMKQALdmlDgkVyXxTcUOhI=iPentRGuNMKQALdmlDgkVyXxTcUOBq.callRequestCookies('Get',iPentRGuNMKQALdmlDgkVyXxTcUOhJ,payload=iPentRGuNMKQALdmlDgkVyXxTcUOJY,params=iPentRGuNMKQALdmlDgkVyXxTcUOho,headers=iPentRGuNMKQALdmlDgkVyXxTcUOhz,cookies=iPentRGuNMKQALdmlDgkVyXxTcUOJY,redirects=iPentRGuNMKQALdmlDgkVyXxTcUOJC)
   if iPentRGuNMKQALdmlDgkVyXxTcUOhI.status_code not in[200]:return[],iPentRGuNMKQALdmlDgkVyXxTcUOJw
   iPentRGuNMKQALdmlDgkVyXxTcUOhW=json.loads(iPentRGuNMKQALdmlDgkVyXxTcUOhI.text)
   for iPentRGuNMKQALdmlDgkVyXxTcUOhC in iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('data').get('data'):
    iPentRGuNMKQALdmlDgkVyXxTcUOhC=iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('data')
    iPentRGuNMKQALdmlDgkVyXxTcUOqJ=iPentRGuNMKQALdmlDgkVyXxTcUOqF=iPentRGuNMKQALdmlDgkVyXxTcUOJa=iPentRGuNMKQALdmlDgkVyXxTcUOJH=''
    if 'poster' in iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('images'):iPentRGuNMKQALdmlDgkVyXxTcUOqJ =iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('images'):iPentRGuNMKQALdmlDgkVyXxTcUOqF =iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('images').get('story-art').get('url') +'?imwidth=600'
    if 'title-treatment' in iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('images'):iPentRGuNMKQALdmlDgkVyXxTcUOJa=iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('images').get('title-treatment').get('url')+'?imwidth=300'
    if 'story-art' in iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('images'):iPentRGuNMKQALdmlDgkVyXxTcUOJH =iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('images').get('story-art').get('url') +'?imwidth=600'
    iPentRGuNMKQALdmlDgkVyXxTcUOqI=''
    if iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('badge')not in[{},iPentRGuNMKQALdmlDgkVyXxTcUOJY]:
     for i in iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('badge').get('text'):
      if iPentRGuNMKQALdmlDgkVyXxTcUOqI!='':iPentRGuNMKQALdmlDgkVyXxTcUOqI+=' '
      iPentRGuNMKQALdmlDgkVyXxTcUOqI+=i.get('text')
    if 'as' in iPentRGuNMKQALdmlDgkVyXxTcUOhC:
     iPentRGuNMKQALdmlDgkVyXxTcUOJB=iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('as') 
    else:
     iPentRGuNMKQALdmlDgkVyXxTcUOJB=iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('type')
    iPentRGuNMKQALdmlDgkVyXxTcUOhj={'id':iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('id'),'title':iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('title'),'asis':iPentRGuNMKQALdmlDgkVyXxTcUOJB,'thumbnail':{'poster':iPentRGuNMKQALdmlDgkVyXxTcUOqJ,'thumb':iPentRGuNMKQALdmlDgkVyXxTcUOqF,'clearlogo':iPentRGuNMKQALdmlDgkVyXxTcUOJa,'fanart':iPentRGuNMKQALdmlDgkVyXxTcUOJH},'mpaa':iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('age_rating'),'duration':iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('running_time'),'badge':iPentRGuNMKQALdmlDgkVyXxTcUOqI,'year':iPentRGuNMKQALdmlDgkVyXxTcUOhC.get('meta').get('releaseYear'),}
    iPentRGuNMKQALdmlDgkVyXxTcUOhS.append(iPentRGuNMKQALdmlDgkVyXxTcUOhj)
   if iPentRGuNMKQALdmlDgkVyXxTcUOhW.get('pagination').get('totalPages')>page_int:
    iPentRGuNMKQALdmlDgkVyXxTcUOqB=iPentRGuNMKQALdmlDgkVyXxTcUOJC
  except iPentRGuNMKQALdmlDgkVyXxTcUOJv as exception:
   iPentRGuNMKQALdmlDgkVyXxTcUOJb(exception)
   return[],iPentRGuNMKQALdmlDgkVyXxTcUOJw
  return iPentRGuNMKQALdmlDgkVyXxTcUOhS,iPentRGuNMKQALdmlDgkVyXxTcUOqB
 def GetBookmarkInfo(iPentRGuNMKQALdmlDgkVyXxTcUOBq,videoid,vidtype):
  iPentRGuNMKQALdmlDgkVyXxTcUOJh={'indexinfo':{'ott':'coupang','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  iPentRGuNMKQALdmlDgkVyXxTcUOhJ=iPentRGuNMKQALdmlDgkVyXxTcUOBq.API_VIEWURL+'/v1/discover/titles/'+videoid 
  iPentRGuNMKQALdmlDgkVyXxTcUOho={'locale':'ko'}
  iPentRGuNMKQALdmlDgkVyXxTcUOhI=iPentRGuNMKQALdmlDgkVyXxTcUOBq.callRequestCookies('Get',iPentRGuNMKQALdmlDgkVyXxTcUOhJ,payload=iPentRGuNMKQALdmlDgkVyXxTcUOJY,params=iPentRGuNMKQALdmlDgkVyXxTcUOho,headers=iPentRGuNMKQALdmlDgkVyXxTcUOJY,cookies=iPentRGuNMKQALdmlDgkVyXxTcUOJY,redirects=iPentRGuNMKQALdmlDgkVyXxTcUOJC)
  if iPentRGuNMKQALdmlDgkVyXxTcUOhI.status_code not in[200]:return{}
  iPentRGuNMKQALdmlDgkVyXxTcUOJq=json.loads(iPentRGuNMKQALdmlDgkVyXxTcUOhI.text).get('data')
  iPentRGuNMKQALdmlDgkVyXxTcUOJI=iPentRGuNMKQALdmlDgkVyXxTcUOJq.get('title')
  iPentRGuNMKQALdmlDgkVyXxTcUOJr =iPentRGuNMKQALdmlDgkVyXxTcUOJq.get('meta').get('releaseYear')
  iPentRGuNMKQALdmlDgkVyXxTcUOJh['saveinfo']['infoLabels']['title']=iPentRGuNMKQALdmlDgkVyXxTcUOJI
  if vidtype=='movie':
   iPentRGuNMKQALdmlDgkVyXxTcUOJI='%s  (%s)'%(iPentRGuNMKQALdmlDgkVyXxTcUOJI,iPentRGuNMKQALdmlDgkVyXxTcUOJr)
  iPentRGuNMKQALdmlDgkVyXxTcUOJh['saveinfo']['title'] =iPentRGuNMKQALdmlDgkVyXxTcUOJI
  iPentRGuNMKQALdmlDgkVyXxTcUOJh['saveinfo']['infoLabels']['mpaa'] =iPentRGuNMKQALdmlDgkVyXxTcUOJq.get('age_rating')
  iPentRGuNMKQALdmlDgkVyXxTcUOJh['saveinfo']['infoLabels']['plot'] ='%s\n\n%s'%(iPentRGuNMKQALdmlDgkVyXxTcUOJq.get('short_description'),iPentRGuNMKQALdmlDgkVyXxTcUOJq.get('description'))
  iPentRGuNMKQALdmlDgkVyXxTcUOJh['saveinfo']['infoLabels']['year'] =iPentRGuNMKQALdmlDgkVyXxTcUOJr
  if vidtype=='movie':
   iPentRGuNMKQALdmlDgkVyXxTcUOJh['saveinfo']['infoLabels']['duration']=iPentRGuNMKQALdmlDgkVyXxTcUOJq.get('running_time')
  iPentRGuNMKQALdmlDgkVyXxTcUOqJ =''
  iPentRGuNMKQALdmlDgkVyXxTcUOJH =''
  iPentRGuNMKQALdmlDgkVyXxTcUOqF =''
  iPentRGuNMKQALdmlDgkVyXxTcUOJa=''
  if iPentRGuNMKQALdmlDgkVyXxTcUOJq.get('images').get('poster') !=iPentRGuNMKQALdmlDgkVyXxTcUOJY:iPentRGuNMKQALdmlDgkVyXxTcUOqJ =iPentRGuNMKQALdmlDgkVyXxTcUOJq.get('images').get('poster').get('url') +'?imwidth=350'
  if iPentRGuNMKQALdmlDgkVyXxTcUOJq.get('images').get('background') !=iPentRGuNMKQALdmlDgkVyXxTcUOJY:iPentRGuNMKQALdmlDgkVyXxTcUOJH =iPentRGuNMKQALdmlDgkVyXxTcUOJq.get('images').get('background').get('url') +'?imwidth=600'
  if iPentRGuNMKQALdmlDgkVyXxTcUOJq.get('images').get('story-art') !=iPentRGuNMKQALdmlDgkVyXxTcUOJY:iPentRGuNMKQALdmlDgkVyXxTcUOqF =iPentRGuNMKQALdmlDgkVyXxTcUOJq.get('images').get('story-art').get('url') +'?imwidth=600'
  if iPentRGuNMKQALdmlDgkVyXxTcUOJq.get('images').get('title-treatment')!=iPentRGuNMKQALdmlDgkVyXxTcUOJY:iPentRGuNMKQALdmlDgkVyXxTcUOJa=iPentRGuNMKQALdmlDgkVyXxTcUOJq.get('images').get('title-treatment').get('url')+'?imwidth=300'
  if iPentRGuNMKQALdmlDgkVyXxTcUOJH=='':iPentRGuNMKQALdmlDgkVyXxTcUOJH=iPentRGuNMKQALdmlDgkVyXxTcUOqF
  iPentRGuNMKQALdmlDgkVyXxTcUOJh['saveinfo']['thumbnail']['poster']=iPentRGuNMKQALdmlDgkVyXxTcUOqJ
  iPentRGuNMKQALdmlDgkVyXxTcUOJh['saveinfo']['thumbnail']['fanart']=iPentRGuNMKQALdmlDgkVyXxTcUOJH
  iPentRGuNMKQALdmlDgkVyXxTcUOJh['saveinfo']['thumbnail']['thumb']=iPentRGuNMKQALdmlDgkVyXxTcUOqF
  iPentRGuNMKQALdmlDgkVyXxTcUOJh['saveinfo']['thumbnail']['clearlogo']=iPentRGuNMKQALdmlDgkVyXxTcUOJa
  iPentRGuNMKQALdmlDgkVyXxTcUOJF=[]
  for iPentRGuNMKQALdmlDgkVyXxTcUOqa in iPentRGuNMKQALdmlDgkVyXxTcUOJq.get('tags'):iPentRGuNMKQALdmlDgkVyXxTcUOJF.append(iPentRGuNMKQALdmlDgkVyXxTcUOqa.get('tag'))
  if iPentRGuNMKQALdmlDgkVyXxTcUOJf(iPentRGuNMKQALdmlDgkVyXxTcUOJF)>0:
   iPentRGuNMKQALdmlDgkVyXxTcUOJh['saveinfo']['infoLabels']['genre']=iPentRGuNMKQALdmlDgkVyXxTcUOJF
  iPentRGuNMKQALdmlDgkVyXxTcUOJz=[]
  iPentRGuNMKQALdmlDgkVyXxTcUOJs=[]
  for iPentRGuNMKQALdmlDgkVyXxTcUOqa in iPentRGuNMKQALdmlDgkVyXxTcUOJq.get('people'):
   if iPentRGuNMKQALdmlDgkVyXxTcUOqa.get('role')=='CAST' :iPentRGuNMKQALdmlDgkVyXxTcUOJz.append(iPentRGuNMKQALdmlDgkVyXxTcUOqa.get('name'))
   if iPentRGuNMKQALdmlDgkVyXxTcUOqa.get('role')=='DIRECTOR':iPentRGuNMKQALdmlDgkVyXxTcUOJs.append(iPentRGuNMKQALdmlDgkVyXxTcUOqa.get('name'))
  if iPentRGuNMKQALdmlDgkVyXxTcUOJf(iPentRGuNMKQALdmlDgkVyXxTcUOJz)>0:
   iPentRGuNMKQALdmlDgkVyXxTcUOJh['saveinfo']['infoLabels']['cast'] =iPentRGuNMKQALdmlDgkVyXxTcUOJz
  if iPentRGuNMKQALdmlDgkVyXxTcUOJf(iPentRGuNMKQALdmlDgkVyXxTcUOJs)>0:
   iPentRGuNMKQALdmlDgkVyXxTcUOJh['saveinfo']['infoLabels']['director']=iPentRGuNMKQALdmlDgkVyXxTcUOJs
  return iPentRGuNMKQALdmlDgkVyXxTcUOJh
# Created by pyminifier (https://github.com/liftoff/pyminifier)
