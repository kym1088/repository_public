__author__="NightRain"
lzhgNMSdskIFaEDXAtpUxBCrTuVnOK=object
lzhgNMSdskIFaEDXAtpUxBCrTuVnOG=None
lzhgNMSdskIFaEDXAtpUxBCrTuVnOR=False
lzhgNMSdskIFaEDXAtpUxBCrTuVnOc=True
lzhgNMSdskIFaEDXAtpUxBCrTuVnOb=type
lzhgNMSdskIFaEDXAtpUxBCrTuVnOL=dict
lzhgNMSdskIFaEDXAtpUxBCrTuVnOi=int
lzhgNMSdskIFaEDXAtpUxBCrTuVnPm=open
lzhgNMSdskIFaEDXAtpUxBCrTuVnPo=Exception
lzhgNMSdskIFaEDXAtpUxBCrTuVnPQ=str
lzhgNMSdskIFaEDXAtpUxBCrTuVnPw=id
lzhgNMSdskIFaEDXAtpUxBCrTuVnPy=len
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import inputstreamhelper
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
lzhgNMSdskIFaEDXAtpUxBCrTuVnmQ=[{'title':'오직 쿠팡플레이에서','mode':'CATEGORY_LIST','vType':'ORIGINAL','collectionId':'5c33c5ca-ee6f-45f8-a026-dd789a8b63cf'},{'title':'홈   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'ALL'},{'title':'TV   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'MOVIES'},{'title':'키즈 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'KIDS'},{'title':'생중계','mode':'EVENT_GROUPLIST','vType':'LIVE'},{'title':'TV   (테마별)','mode':'THEME_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (테마별)','mode':'THEME_GROUPLIST','vType':'MOVIES'},{'title':'키즈 (테마별)','mode':'THEME_GROUPLIST','vType':'KIDS'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},{'title':'(쿠팡) 검색','mode':'LOCAL_SEARCH','icon':'search.png'},{'title':'(쿠팡) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
lzhgNMSdskIFaEDXAtpUxBCrTuVnmw=[{'title':'시리즈 시청내역','mode':'WATCH','stype':'tvshow'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},]
lzhgNMSdskIFaEDXAtpUxBCrTuVnmy=xbmcvfs.translatePath(os.path.join(__profile__,'coupang_searched.txt'))
from coupangCore import*
class lzhgNMSdskIFaEDXAtpUxBCrTuVnmo(lzhgNMSdskIFaEDXAtpUxBCrTuVnOK):
 def __init__(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO,lzhgNMSdskIFaEDXAtpUxBCrTuVnmP,lzhgNMSdskIFaEDXAtpUxBCrTuVnme,lzhgNMSdskIFaEDXAtpUxBCrTuVnmj):
  lzhgNMSdskIFaEDXAtpUxBCrTuVnmO._addon_url =lzhgNMSdskIFaEDXAtpUxBCrTuVnmP
  lzhgNMSdskIFaEDXAtpUxBCrTuVnmO._addon_handle=lzhgNMSdskIFaEDXAtpUxBCrTuVnme
  lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.main_params =lzhgNMSdskIFaEDXAtpUxBCrTuVnmj
  lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj =iPentRGuNMKQALdmlDgkVyXxTcUOBh() 
  lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.CP_COOKIE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_cookies.json'))
  lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.CP_DEVICE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_device.json'))
 def addon_noti(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO,sting):
  try:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmJ=xbmcgui.Dialog()
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmJ.notification(__addonname__,sting)
  except:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnOG
 def addon_log(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO,string):
  try:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmv=string.encode('utf-8','ignore')
  except:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmv='addonException: addon_log'
  lzhgNMSdskIFaEDXAtpUxBCrTuVnmf=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,lzhgNMSdskIFaEDXAtpUxBCrTuVnmv),level=lzhgNMSdskIFaEDXAtpUxBCrTuVnmf)
 def get_keyboard_input(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO,lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ):
  lzhgNMSdskIFaEDXAtpUxBCrTuVnmH=lzhgNMSdskIFaEDXAtpUxBCrTuVnOG
  kb=xbmc.Keyboard()
  kb.setHeading(lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmH=kb.getText()
  return lzhgNMSdskIFaEDXAtpUxBCrTuVnmH
 def get_settings_account(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO):
  lzhgNMSdskIFaEDXAtpUxBCrTuVnmq=__addon__.getSetting('id')
  lzhgNMSdskIFaEDXAtpUxBCrTuVnmW=__addon__.getSetting('pw')
  lzhgNMSdskIFaEDXAtpUxBCrTuVnmK=__addon__.getSetting('profile')
  return(lzhgNMSdskIFaEDXAtpUxBCrTuVnmq,lzhgNMSdskIFaEDXAtpUxBCrTuVnmW,lzhgNMSdskIFaEDXAtpUxBCrTuVnmK)
 def get_settings_exclusion21(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO):
  lzhgNMSdskIFaEDXAtpUxBCrTuVnmG =__addon__.getSetting('exclusion21')
  if lzhgNMSdskIFaEDXAtpUxBCrTuVnmG=='false':
   return lzhgNMSdskIFaEDXAtpUxBCrTuVnOR
  else:
   return lzhgNMSdskIFaEDXAtpUxBCrTuVnOc
 def get_settings_totalsearch(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO):
  lzhgNMSdskIFaEDXAtpUxBCrTuVnmR =lzhgNMSdskIFaEDXAtpUxBCrTuVnOc if __addon__.getSetting('local_search')=='true' else lzhgNMSdskIFaEDXAtpUxBCrTuVnOR
  lzhgNMSdskIFaEDXAtpUxBCrTuVnmc=lzhgNMSdskIFaEDXAtpUxBCrTuVnOc if __addon__.getSetting('local_history')=='true' else lzhgNMSdskIFaEDXAtpUxBCrTuVnOR
  lzhgNMSdskIFaEDXAtpUxBCrTuVnmb =lzhgNMSdskIFaEDXAtpUxBCrTuVnOc if __addon__.getSetting('total_search')=='true' else lzhgNMSdskIFaEDXAtpUxBCrTuVnOR
  lzhgNMSdskIFaEDXAtpUxBCrTuVnmL=lzhgNMSdskIFaEDXAtpUxBCrTuVnOc if __addon__.getSetting('total_history')=='true' else lzhgNMSdskIFaEDXAtpUxBCrTuVnOR
  lzhgNMSdskIFaEDXAtpUxBCrTuVnmi=lzhgNMSdskIFaEDXAtpUxBCrTuVnOc if __addon__.getSetting('menu_bookmark')=='true' else lzhgNMSdskIFaEDXAtpUxBCrTuVnOR
  return(lzhgNMSdskIFaEDXAtpUxBCrTuVnmR,lzhgNMSdskIFaEDXAtpUxBCrTuVnmc,lzhgNMSdskIFaEDXAtpUxBCrTuVnmb,lzhgNMSdskIFaEDXAtpUxBCrTuVnmL,lzhgNMSdskIFaEDXAtpUxBCrTuVnmi)
 def get_settings_makebookmark(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO):
  return lzhgNMSdskIFaEDXAtpUxBCrTuVnOc if __addon__.getSetting('make_bookmark')=='true' else lzhgNMSdskIFaEDXAtpUxBCrTuVnOR
 def add_dir(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO,label,sublabel='',img='',infoLabels=lzhgNMSdskIFaEDXAtpUxBCrTuVnOG,isFolder=lzhgNMSdskIFaEDXAtpUxBCrTuVnOc,params='',isLink=lzhgNMSdskIFaEDXAtpUxBCrTuVnOR,ContextMenu=lzhgNMSdskIFaEDXAtpUxBCrTuVnOG):
  lzhgNMSdskIFaEDXAtpUxBCrTuVnom='%s?%s'%(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO._addon_url,urllib.parse.urlencode(params))
  if sublabel:lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ='%s < %s >'%(label,sublabel)
  else: lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ=label
  if not img:img='DefaultFolder.png'
  lzhgNMSdskIFaEDXAtpUxBCrTuVnow=xbmcgui.ListItem(lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ)
  if lzhgNMSdskIFaEDXAtpUxBCrTuVnOb(img)==lzhgNMSdskIFaEDXAtpUxBCrTuVnOL:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnow.setArt(img)
  else:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnow.setArt({'thumb':img,'poster':img})
  if infoLabels:lzhgNMSdskIFaEDXAtpUxBCrTuVnow.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnow.setProperty('IsPlayable','true')
  if ContextMenu:lzhgNMSdskIFaEDXAtpUxBCrTuVnow.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO._addon_handle,lzhgNMSdskIFaEDXAtpUxBCrTuVnom,lzhgNMSdskIFaEDXAtpUxBCrTuVnow,isFolder)
 def dp_Main_List(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO,args):
  (lzhgNMSdskIFaEDXAtpUxBCrTuVnmR,lzhgNMSdskIFaEDXAtpUxBCrTuVnmc,lzhgNMSdskIFaEDXAtpUxBCrTuVnmb,lzhgNMSdskIFaEDXAtpUxBCrTuVnmL,lzhgNMSdskIFaEDXAtpUxBCrTuVnmi)=lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.get_settings_totalsearch()
  for lzhgNMSdskIFaEDXAtpUxBCrTuVnoy in lzhgNMSdskIFaEDXAtpUxBCrTuVnmQ:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ=lzhgNMSdskIFaEDXAtpUxBCrTuVnoy.get('title')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoO=''
   if lzhgNMSdskIFaEDXAtpUxBCrTuVnoy.get('mode')=='LOCAL_SEARCH' and lzhgNMSdskIFaEDXAtpUxBCrTuVnmR ==lzhgNMSdskIFaEDXAtpUxBCrTuVnOR:continue
   elif lzhgNMSdskIFaEDXAtpUxBCrTuVnoy.get('mode')=='SEARCH_HISTORY' and lzhgNMSdskIFaEDXAtpUxBCrTuVnmc==lzhgNMSdskIFaEDXAtpUxBCrTuVnOR:continue
   elif lzhgNMSdskIFaEDXAtpUxBCrTuVnoy.get('mode')=='TOTAL_SEARCH' and lzhgNMSdskIFaEDXAtpUxBCrTuVnmb ==lzhgNMSdskIFaEDXAtpUxBCrTuVnOR:continue
   elif lzhgNMSdskIFaEDXAtpUxBCrTuVnoy.get('mode')=='TOTAL_HISTORY' and lzhgNMSdskIFaEDXAtpUxBCrTuVnmL==lzhgNMSdskIFaEDXAtpUxBCrTuVnOR:continue
   elif lzhgNMSdskIFaEDXAtpUxBCrTuVnoy.get('mode')=='MENU_BOOKMARK' and lzhgNMSdskIFaEDXAtpUxBCrTuVnmi==lzhgNMSdskIFaEDXAtpUxBCrTuVnOR:continue
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoP={'mode':lzhgNMSdskIFaEDXAtpUxBCrTuVnoy.get('mode'),'vType':lzhgNMSdskIFaEDXAtpUxBCrTuVnoy.get('vType'),'collectionId':lzhgNMSdskIFaEDXAtpUxBCrTuVnoy.get('collectionId'),'page':'1',}
   if lzhgNMSdskIFaEDXAtpUxBCrTuVnoy.get('mode')=='LOCAL_SEARCH':lzhgNMSdskIFaEDXAtpUxBCrTuVnoP['historyyn']='Y' 
   if lzhgNMSdskIFaEDXAtpUxBCrTuVnoy.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    lzhgNMSdskIFaEDXAtpUxBCrTuVnoe=lzhgNMSdskIFaEDXAtpUxBCrTuVnOR
    lzhgNMSdskIFaEDXAtpUxBCrTuVnoj =lzhgNMSdskIFaEDXAtpUxBCrTuVnOc
   else:
    lzhgNMSdskIFaEDXAtpUxBCrTuVnoe=lzhgNMSdskIFaEDXAtpUxBCrTuVnOc
    lzhgNMSdskIFaEDXAtpUxBCrTuVnoj =lzhgNMSdskIFaEDXAtpUxBCrTuVnOR
   if 'icon' in lzhgNMSdskIFaEDXAtpUxBCrTuVnoy:lzhgNMSdskIFaEDXAtpUxBCrTuVnoO=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',lzhgNMSdskIFaEDXAtpUxBCrTuVnoy.get('icon')) 
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.add_dir(lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ,sublabel='',img=lzhgNMSdskIFaEDXAtpUxBCrTuVnoO,infoLabels=lzhgNMSdskIFaEDXAtpUxBCrTuVnOG,isFolder=lzhgNMSdskIFaEDXAtpUxBCrTuVnoe,params=lzhgNMSdskIFaEDXAtpUxBCrTuVnoP,isLink=lzhgNMSdskIFaEDXAtpUxBCrTuVnoj)
  xbmcplugin.endOfDirectory(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO._addon_handle)
 def dp_Test(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO,args):
  lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.addon_noti('test')
 def CP_logout(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO):
  lzhgNMSdskIFaEDXAtpUxBCrTuVnmJ=xbmcgui.Dialog()
  lzhgNMSdskIFaEDXAtpUxBCrTuVnoJ=lzhgNMSdskIFaEDXAtpUxBCrTuVnmJ.yesno(__language__(30905).encode('utf8'),__language__(30906).encode('utf8'))
  if lzhgNMSdskIFaEDXAtpUxBCrTuVnoJ==lzhgNMSdskIFaEDXAtpUxBCrTuVnOR:return 
  if os.path.isfile(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.CP_COOKIE_FILENAME):os.remove(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.CP_COOKIE_FILENAME)
  lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.addon_noti(__language__(30904).encode('utf-8'))
 def option_check(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO):
  (lzhgNMSdskIFaEDXAtpUxBCrTuVnmq,lzhgNMSdskIFaEDXAtpUxBCrTuVnmW,lzhgNMSdskIFaEDXAtpUxBCrTuVnmK)=lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.get_settings_account()
  if lzhgNMSdskIFaEDXAtpUxBCrTuVnmq=='' or lzhgNMSdskIFaEDXAtpUxBCrTuVnmW=='':
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmJ=xbmcgui.Dialog()
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoJ=lzhgNMSdskIFaEDXAtpUxBCrTuVnmJ.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if lzhgNMSdskIFaEDXAtpUxBCrTuVnoJ==lzhgNMSdskIFaEDXAtpUxBCrTuVnOc:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.cookiefile_check()==lzhgNMSdskIFaEDXAtpUxBCrTuVnOR:
   if lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CP_login(lzhgNMSdskIFaEDXAtpUxBCrTuVnmq,lzhgNMSdskIFaEDXAtpUxBCrTuVnmW,lzhgNMSdskIFaEDXAtpUxBCrTuVnmK)==lzhgNMSdskIFaEDXAtpUxBCrTuVnOR:
    lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.addon_noti(__language__(30903).encode('utf8'))
    sys.exit()
  else:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.Get_CP_profile(lzhgNMSdskIFaEDXAtpUxBCrTuVnmK,limit_days=lzhgNMSdskIFaEDXAtpUxBCrTuVnOi(__addon__.getSetting('cache_ttl')),re_check=lzhgNMSdskIFaEDXAtpUxBCrTuVnOc)
 def cookiefile_check(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO):
  lzhgNMSdskIFaEDXAtpUxBCrTuVnof={}
  try: 
   fp=lzhgNMSdskIFaEDXAtpUxBCrTuVnPm(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.CP_COOKIE_FILENAME,'r',-1,'utf-8')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnof= json.load(fp)
   fp.close()
  except lzhgNMSdskIFaEDXAtpUxBCrTuVnPo as exception:
   return lzhgNMSdskIFaEDXAtpUxBCrTuVnOR
  lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.CP=lzhgNMSdskIFaEDXAtpUxBCrTuVnof
  if 'session_web_id' not in lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.CP.get('SESSION'):
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.Init_CP()
   return lzhgNMSdskIFaEDXAtpUxBCrTuVnOR
  (lzhgNMSdskIFaEDXAtpUxBCrTuVnmq,lzhgNMSdskIFaEDXAtpUxBCrTuVnmW,lzhgNMSdskIFaEDXAtpUxBCrTuVnmK)=lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.get_settings_account()
  (lzhgNMSdskIFaEDXAtpUxBCrTuVnoH,lzhgNMSdskIFaEDXAtpUxBCrTuVnoq,lzhgNMSdskIFaEDXAtpUxBCrTuVnoW)=lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.Load_session_acount()
  if lzhgNMSdskIFaEDXAtpUxBCrTuVnmq!=lzhgNMSdskIFaEDXAtpUxBCrTuVnoH or lzhgNMSdskIFaEDXAtpUxBCrTuVnmW!=lzhgNMSdskIFaEDXAtpUxBCrTuVnoq or lzhgNMSdskIFaEDXAtpUxBCrTuVnmK!=lzhgNMSdskIFaEDXAtpUxBCrTuVnPQ(lzhgNMSdskIFaEDXAtpUxBCrTuVnoW):
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.Init_CP()
   return lzhgNMSdskIFaEDXAtpUxBCrTuVnOR
  lzhgNMSdskIFaEDXAtpUxBCrTuVnoK =lzhgNMSdskIFaEDXAtpUxBCrTuVnOi(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.Get_Now_Datetime().strftime('%Y%m%d'))
  lzhgNMSdskIFaEDXAtpUxBCrTuVnoG=lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.CP['SESSION']['limitdate']
  lzhgNMSdskIFaEDXAtpUxBCrTuVnoR =lzhgNMSdskIFaEDXAtpUxBCrTuVnOi(re.sub('-','',lzhgNMSdskIFaEDXAtpUxBCrTuVnoG))
  if lzhgNMSdskIFaEDXAtpUxBCrTuVnoR<lzhgNMSdskIFaEDXAtpUxBCrTuVnoK:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.Init_CP()
   return lzhgNMSdskIFaEDXAtpUxBCrTuVnOR
  return lzhgNMSdskIFaEDXAtpUxBCrTuVnOc
 def CP_login(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO,lzhgNMSdskIFaEDXAtpUxBCrTuVnmq,lzhgNMSdskIFaEDXAtpUxBCrTuVnmW,lzhgNMSdskIFaEDXAtpUxBCrTuVnmK):
  if lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.Get_CP_Login(lzhgNMSdskIFaEDXAtpUxBCrTuVnmq,lzhgNMSdskIFaEDXAtpUxBCrTuVnmW,lzhgNMSdskIFaEDXAtpUxBCrTuVnmK)==lzhgNMSdskIFaEDXAtpUxBCrTuVnOR:return lzhgNMSdskIFaEDXAtpUxBCrTuVnOR
  if lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.Get_CP_profile(lzhgNMSdskIFaEDXAtpUxBCrTuVnmK,limit_days=lzhgNMSdskIFaEDXAtpUxBCrTuVnOi(__addon__.getSetting('cache_ttl')),re_check=lzhgNMSdskIFaEDXAtpUxBCrTuVnOR)==lzhgNMSdskIFaEDXAtpUxBCrTuVnOR:return lzhgNMSdskIFaEDXAtpUxBCrTuVnOR
  return lzhgNMSdskIFaEDXAtpUxBCrTuVnOc
 def dp_Category_GroupList(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO,args):
  lzhgNMSdskIFaEDXAtpUxBCrTuVnoc =args.get('vType') 
  lzhgNMSdskIFaEDXAtpUxBCrTuVnob=lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.Get_Category_GroupList(lzhgNMSdskIFaEDXAtpUxBCrTuVnoc)
  for lzhgNMSdskIFaEDXAtpUxBCrTuVnoL in lzhgNMSdskIFaEDXAtpUxBCrTuVnob:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ =lzhgNMSdskIFaEDXAtpUxBCrTuVnoL.get('title')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoi=lzhgNMSdskIFaEDXAtpUxBCrTuVnoL.get('pre_title')
   if lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.get_settings_exclusion21()==lzhgNMSdskIFaEDXAtpUxBCrTuVnOc and lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ=='성인':continue
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQm={'mediatype':'tvshow','plot':lzhgNMSdskIFaEDXAtpUxBCrTuVnoi,}
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoP={'mode':'CATEGORY_LIST','collectionId':lzhgNMSdskIFaEDXAtpUxBCrTuVnoL.get('collectionId'),'vType':lzhgNMSdskIFaEDXAtpUxBCrTuVnoL.get('category'),'page':'1',}
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.add_dir(lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ,sublabel='',img='',infoLabels=lzhgNMSdskIFaEDXAtpUxBCrTuVnQm,isFolder=lzhgNMSdskIFaEDXAtpUxBCrTuVnOc,params=lzhgNMSdskIFaEDXAtpUxBCrTuVnoP)
  xbmcplugin.endOfDirectory(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO._addon_handle,cacheToDisc=lzhgNMSdskIFaEDXAtpUxBCrTuVnOR)
 def dp_Theme_GroupList(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO,args):
  lzhgNMSdskIFaEDXAtpUxBCrTuVnoc =args.get('vType') 
  lzhgNMSdskIFaEDXAtpUxBCrTuVnob=lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.Get_Theme_GroupList(lzhgNMSdskIFaEDXAtpUxBCrTuVnoc)
  for lzhgNMSdskIFaEDXAtpUxBCrTuVnoL in lzhgNMSdskIFaEDXAtpUxBCrTuVnob:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ =lzhgNMSdskIFaEDXAtpUxBCrTuVnoL.get('title')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoi=lzhgNMSdskIFaEDXAtpUxBCrTuVnoL.get('pre_title')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQm={'mediatype':'tvshow','plot':lzhgNMSdskIFaEDXAtpUxBCrTuVnoi,}
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoP={'mode':'CATEGORY_LIST','collectionId':lzhgNMSdskIFaEDXAtpUxBCrTuVnoL.get('collectionId'),'vType':lzhgNMSdskIFaEDXAtpUxBCrTuVnoL.get('category'),'page':'1',}
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.add_dir(lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ,sublabel='',img='',infoLabels=lzhgNMSdskIFaEDXAtpUxBCrTuVnQm,isFolder=lzhgNMSdskIFaEDXAtpUxBCrTuVnOc,params=lzhgNMSdskIFaEDXAtpUxBCrTuVnoP)
  xbmcplugin.endOfDirectory(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO._addon_handle,cacheToDisc=lzhgNMSdskIFaEDXAtpUxBCrTuVnOR)
 def dp_Event_GroupList(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO,args):
  lzhgNMSdskIFaEDXAtpUxBCrTuVnob=lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.Get_Event_GroupList()
  for lzhgNMSdskIFaEDXAtpUxBCrTuVnoL in lzhgNMSdskIFaEDXAtpUxBCrTuVnob:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ =lzhgNMSdskIFaEDXAtpUxBCrTuVnoL.get('title')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoi=lzhgNMSdskIFaEDXAtpUxBCrTuVnoL.get('pre_title')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQm={'mediatype':'tvshow','plot':lzhgNMSdskIFaEDXAtpUxBCrTuVnoi,}
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoP={'mode':'EVENT_GAMELIST','collectionId':lzhgNMSdskIFaEDXAtpUxBCrTuVnoL.get('collectionId'),'vType':'LIVE',}
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.add_dir(lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ,sublabel='',img='',infoLabels=lzhgNMSdskIFaEDXAtpUxBCrTuVnQm,isFolder=lzhgNMSdskIFaEDXAtpUxBCrTuVnOc,params=lzhgNMSdskIFaEDXAtpUxBCrTuVnoP)
  xbmcplugin.endOfDirectory(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO._addon_handle,cacheToDisc=lzhgNMSdskIFaEDXAtpUxBCrTuVnOR)
 def dp_Event_GameList(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO,args):
  lzhgNMSdskIFaEDXAtpUxBCrTuVnoc =args.get('vType') 
  lzhgNMSdskIFaEDXAtpUxBCrTuVnQw =args.get('collectionId')
  lzhgNMSdskIFaEDXAtpUxBCrTuVnob=lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.Get_Event_GameList(lzhgNMSdskIFaEDXAtpUxBCrTuVnQw)
  for lzhgNMSdskIFaEDXAtpUxBCrTuVnoL in lzhgNMSdskIFaEDXAtpUxBCrTuVnob:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ =lzhgNMSdskIFaEDXAtpUxBCrTuVnoL.get('title')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnPw =lzhgNMSdskIFaEDXAtpUxBCrTuVnoL.get('id')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQy =lzhgNMSdskIFaEDXAtpUxBCrTuVnoL.get('thumbnail')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQO =lzhgNMSdskIFaEDXAtpUxBCrTuVnoL.get('asis') 
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQP =lzhgNMSdskIFaEDXAtpUxBCrTuVnoL.get('addInfo')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQe =lzhgNMSdskIFaEDXAtpUxBCrTuVnoL.get('starttm')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQm={'mediatype':'tvshow','title':lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ,'plot':lzhgNMSdskIFaEDXAtpUxBCrTuVnQP,}
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoP={'mode':'EVENT_LIST','id':lzhgNMSdskIFaEDXAtpUxBCrTuVnPw,'asis':lzhgNMSdskIFaEDXAtpUxBCrTuVnQO,'title':lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ,}
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.add_dir(lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ,sublabel=lzhgNMSdskIFaEDXAtpUxBCrTuVnQe,img=lzhgNMSdskIFaEDXAtpUxBCrTuVnQy,infoLabels=lzhgNMSdskIFaEDXAtpUxBCrTuVnQm,isFolder=lzhgNMSdskIFaEDXAtpUxBCrTuVnOc,params=lzhgNMSdskIFaEDXAtpUxBCrTuVnoP,ContextMenu=lzhgNMSdskIFaEDXAtpUxBCrTuVnOG)
  xbmcplugin.setContent(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO._addon_handle,cacheToDisc=lzhgNMSdskIFaEDXAtpUxBCrTuVnOR)
 def dp_Event_List(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO,args):
  lzhgNMSdskIFaEDXAtpUxBCrTuVnQj=args.get('id')
  lzhgNMSdskIFaEDXAtpUxBCrTuVnob=lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.Get_Event_List(lzhgNMSdskIFaEDXAtpUxBCrTuVnQj)
  for lzhgNMSdskIFaEDXAtpUxBCrTuVnoL in lzhgNMSdskIFaEDXAtpUxBCrTuVnob:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ =lzhgNMSdskIFaEDXAtpUxBCrTuVnoL.get('title')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnPw =lzhgNMSdskIFaEDXAtpUxBCrTuVnoL.get('id')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQy =lzhgNMSdskIFaEDXAtpUxBCrTuVnoL.get('thumbnail')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQO =lzhgNMSdskIFaEDXAtpUxBCrTuVnoL.get('asis') 
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQY =lzhgNMSdskIFaEDXAtpUxBCrTuVnoL.get('duration')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQe =lzhgNMSdskIFaEDXAtpUxBCrTuVnoL.get('starttm')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQm={'mediatype':'episode','title':lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ,'plot':lzhgNMSdskIFaEDXAtpUxBCrTuVnQO,'duration':lzhgNMSdskIFaEDXAtpUxBCrTuVnQY,}
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoP={'mode':lzhgNMSdskIFaEDXAtpUxBCrTuVnQO,'id':lzhgNMSdskIFaEDXAtpUxBCrTuVnPw,'asis':lzhgNMSdskIFaEDXAtpUxBCrTuVnQO,'title':lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ,}
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.add_dir(lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ,sublabel=lzhgNMSdskIFaEDXAtpUxBCrTuVnQe,img=lzhgNMSdskIFaEDXAtpUxBCrTuVnQy,infoLabels=lzhgNMSdskIFaEDXAtpUxBCrTuVnQm,isFolder=lzhgNMSdskIFaEDXAtpUxBCrTuVnOR,params=lzhgNMSdskIFaEDXAtpUxBCrTuVnoP,ContextMenu=lzhgNMSdskIFaEDXAtpUxBCrTuVnOG)
  xbmcplugin.setContent(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO._addon_handle,cacheToDisc=lzhgNMSdskIFaEDXAtpUxBCrTuVnOR)
 def dp_Category_List(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO,args):
  lzhgNMSdskIFaEDXAtpUxBCrTuVnoc =args.get('vType') 
  lzhgNMSdskIFaEDXAtpUxBCrTuVnQw =args.get('collectionId')
  lzhgNMSdskIFaEDXAtpUxBCrTuVnQJ =lzhgNMSdskIFaEDXAtpUxBCrTuVnOi(args.get('page'))
  lzhgNMSdskIFaEDXAtpUxBCrTuVnob,lzhgNMSdskIFaEDXAtpUxBCrTuVnQv=lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.Get_Category_List(lzhgNMSdskIFaEDXAtpUxBCrTuVnoc,lzhgNMSdskIFaEDXAtpUxBCrTuVnQw,lzhgNMSdskIFaEDXAtpUxBCrTuVnQJ)
  for lzhgNMSdskIFaEDXAtpUxBCrTuVnoL in lzhgNMSdskIFaEDXAtpUxBCrTuVnob:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ =lzhgNMSdskIFaEDXAtpUxBCrTuVnoL.get('title')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnPw =lzhgNMSdskIFaEDXAtpUxBCrTuVnoL.get('id')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQy =lzhgNMSdskIFaEDXAtpUxBCrTuVnoL.get('thumbnail')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQf =lzhgNMSdskIFaEDXAtpUxBCrTuVnoL.get('mpaa')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQY =lzhgNMSdskIFaEDXAtpUxBCrTuVnoL.get('duration')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQO =lzhgNMSdskIFaEDXAtpUxBCrTuVnoL.get('asis')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQH =lzhgNMSdskIFaEDXAtpUxBCrTuVnoL.get('badge')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQq =lzhgNMSdskIFaEDXAtpUxBCrTuVnoL.get('year')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQW=lzhgNMSdskIFaEDXAtpUxBCrTuVnoL.get('seasonList')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQK =lzhgNMSdskIFaEDXAtpUxBCrTuVnoL.get('genreList')
   if lzhgNMSdskIFaEDXAtpUxBCrTuVnQO in['TVSHOW','EDUCATION']: 
    lzhgNMSdskIFaEDXAtpUxBCrTuVnQG ='SEASON_LIST'
    lzhgNMSdskIFaEDXAtpUxBCrTuVnQm={'mediatype':'tvshow','title':lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ,'mpaa':lzhgNMSdskIFaEDXAtpUxBCrTuVnQf,'genre':lzhgNMSdskIFaEDXAtpUxBCrTuVnQK,'year':lzhgNMSdskIFaEDXAtpUxBCrTuVnQq,'plot':'Year : %s\nSeason : %s'%(lzhgNMSdskIFaEDXAtpUxBCrTuVnQq,lzhgNMSdskIFaEDXAtpUxBCrTuVnQW),}
    lzhgNMSdskIFaEDXAtpUxBCrTuVnoe =lzhgNMSdskIFaEDXAtpUxBCrTuVnOc
   else:
    lzhgNMSdskIFaEDXAtpUxBCrTuVnQG ='MOVIE'
    lzhgNMSdskIFaEDXAtpUxBCrTuVnQm={'mediatype':'movie','title':lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ,'mpaa':lzhgNMSdskIFaEDXAtpUxBCrTuVnQf,'genre':lzhgNMSdskIFaEDXAtpUxBCrTuVnQK,'duration':lzhgNMSdskIFaEDXAtpUxBCrTuVnQY,'year':lzhgNMSdskIFaEDXAtpUxBCrTuVnQq,'plot':'(%s)'%(lzhgNMSdskIFaEDXAtpUxBCrTuVnQf),}
    lzhgNMSdskIFaEDXAtpUxBCrTuVnoe =lzhgNMSdskIFaEDXAtpUxBCrTuVnOR
    lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ +=' (%s)'%(lzhgNMSdskIFaEDXAtpUxBCrTuVnPQ(lzhgNMSdskIFaEDXAtpUxBCrTuVnQq))
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoP={'mode':lzhgNMSdskIFaEDXAtpUxBCrTuVnQG,'id':lzhgNMSdskIFaEDXAtpUxBCrTuVnPw,'asis':lzhgNMSdskIFaEDXAtpUxBCrTuVnQO,'seasonList':lzhgNMSdskIFaEDXAtpUxBCrTuVnQW,'title':lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ,'thumbnail':lzhgNMSdskIFaEDXAtpUxBCrTuVnQy,'year':lzhgNMSdskIFaEDXAtpUxBCrTuVnQq,}
   if lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.get_settings_makebookmark():
    lzhgNMSdskIFaEDXAtpUxBCrTuVnQR={'videoid':lzhgNMSdskIFaEDXAtpUxBCrTuVnPw,'vidtype':'movie' if lzhgNMSdskIFaEDXAtpUxBCrTuVnoc=='MOVIES' else 'tvshow','vtitle':lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ,'vsubtitle':'',}
    lzhgNMSdskIFaEDXAtpUxBCrTuVnQc=json.dumps(lzhgNMSdskIFaEDXAtpUxBCrTuVnQR)
    lzhgNMSdskIFaEDXAtpUxBCrTuVnQc=urllib.parse.quote(lzhgNMSdskIFaEDXAtpUxBCrTuVnQc)
    lzhgNMSdskIFaEDXAtpUxBCrTuVnQb='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(lzhgNMSdskIFaEDXAtpUxBCrTuVnQc)
    lzhgNMSdskIFaEDXAtpUxBCrTuVnQL=[('(통합) 찜 영상에 추가',lzhgNMSdskIFaEDXAtpUxBCrTuVnQb)]
   else:
    lzhgNMSdskIFaEDXAtpUxBCrTuVnQL=lzhgNMSdskIFaEDXAtpUxBCrTuVnOG
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.add_dir(lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ,sublabel=lzhgNMSdskIFaEDXAtpUxBCrTuVnQH,img=lzhgNMSdskIFaEDXAtpUxBCrTuVnQy,infoLabels=lzhgNMSdskIFaEDXAtpUxBCrTuVnQm,isFolder=lzhgNMSdskIFaEDXAtpUxBCrTuVnoe,params=lzhgNMSdskIFaEDXAtpUxBCrTuVnoP,ContextMenu=lzhgNMSdskIFaEDXAtpUxBCrTuVnQL)
  if lzhgNMSdskIFaEDXAtpUxBCrTuVnQv:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoP['mode'] ='CATEGORY_LIST' 
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoP['collectionId']=lzhgNMSdskIFaEDXAtpUxBCrTuVnQw 
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoP['vType'] =lzhgNMSdskIFaEDXAtpUxBCrTuVnoc 
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoP['page'] =lzhgNMSdskIFaEDXAtpUxBCrTuVnPQ(lzhgNMSdskIFaEDXAtpUxBCrTuVnQJ+1)
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ='[B]%s >>[/B]'%'다음 페이지'
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQi=lzhgNMSdskIFaEDXAtpUxBCrTuVnPQ(lzhgNMSdskIFaEDXAtpUxBCrTuVnQJ+1)
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoO=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.add_dir(lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ,sublabel=lzhgNMSdskIFaEDXAtpUxBCrTuVnQi,img=lzhgNMSdskIFaEDXAtpUxBCrTuVnoO,infoLabels=lzhgNMSdskIFaEDXAtpUxBCrTuVnOG,isFolder=lzhgNMSdskIFaEDXAtpUxBCrTuVnOc,params=lzhgNMSdskIFaEDXAtpUxBCrTuVnoP)
  if lzhgNMSdskIFaEDXAtpUxBCrTuVnoc=='TVSHOWS':xbmcplugin.setContent(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO._addon_handle,'tvshows')
  else:xbmcplugin.setContent(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO._addon_handle,'movies')
  xbmcplugin.endOfDirectory(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO._addon_handle,cacheToDisc=lzhgNMSdskIFaEDXAtpUxBCrTuVnOR)
 def dp_Season_List(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO,args):
  lzhgNMSdskIFaEDXAtpUxBCrTuVnwm =args.get('title')
  lzhgNMSdskIFaEDXAtpUxBCrTuVnwo =args.get('id')
  lzhgNMSdskIFaEDXAtpUxBCrTuVnQO =args.get('asis')
  lzhgNMSdskIFaEDXAtpUxBCrTuVnQW =args.get('seasonList')
  lzhgNMSdskIFaEDXAtpUxBCrTuVnQy =args.get('thumbnail')
  lzhgNMSdskIFaEDXAtpUxBCrTuVnQq =args.get('year')
  if lzhgNMSdskIFaEDXAtpUxBCrTuVnQW in['',lzhgNMSdskIFaEDXAtpUxBCrTuVnOG]:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQW=lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.Get_vInfo(lzhgNMSdskIFaEDXAtpUxBCrTuVnwo).get('seasonList')
  if lzhgNMSdskIFaEDXAtpUxBCrTuVnPy(lzhgNMSdskIFaEDXAtpUxBCrTuVnQW.split(','))>1:
   for lzhgNMSdskIFaEDXAtpUxBCrTuVnwQ in lzhgNMSdskIFaEDXAtpUxBCrTuVnQW.split(','):
    lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ='시즌 '+lzhgNMSdskIFaEDXAtpUxBCrTuVnwQ
    lzhgNMSdskIFaEDXAtpUxBCrTuVnQm={'mediatype':'tvshow','plot':'%s (%s)'%(lzhgNMSdskIFaEDXAtpUxBCrTuVnwm,lzhgNMSdskIFaEDXAtpUxBCrTuVnQq),}
    lzhgNMSdskIFaEDXAtpUxBCrTuVnoP={'mode':'EPISODE_LIST','programid':lzhgNMSdskIFaEDXAtpUxBCrTuVnwo,'programnm':lzhgNMSdskIFaEDXAtpUxBCrTuVnwm,'season':lzhgNMSdskIFaEDXAtpUxBCrTuVnwQ,'asis':lzhgNMSdskIFaEDXAtpUxBCrTuVnQO,'programimg':lzhgNMSdskIFaEDXAtpUxBCrTuVnQy,}
    lzhgNMSdskIFaEDXAtpUxBCrTuVnwy=lzhgNMSdskIFaEDXAtpUxBCrTuVnQy.replace('\'','\"')
    lzhgNMSdskIFaEDXAtpUxBCrTuVnwy=json.loads(lzhgNMSdskIFaEDXAtpUxBCrTuVnwy)
    lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.add_dir(lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ,sublabel='',img=lzhgNMSdskIFaEDXAtpUxBCrTuVnwy,infoLabels=lzhgNMSdskIFaEDXAtpUxBCrTuVnQm,isFolder=lzhgNMSdskIFaEDXAtpUxBCrTuVnOc,params=lzhgNMSdskIFaEDXAtpUxBCrTuVnoP)
   xbmcplugin.setContent(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO._addon_handle,cacheToDisc=lzhgNMSdskIFaEDXAtpUxBCrTuVnOR)
  else:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnwO={'programid':lzhgNMSdskIFaEDXAtpUxBCrTuVnwo,'programnm':lzhgNMSdskIFaEDXAtpUxBCrTuVnwm,'season':lzhgNMSdskIFaEDXAtpUxBCrTuVnQW,'programimg':lzhgNMSdskIFaEDXAtpUxBCrTuVnQy,}
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.dp_Episode_List(lzhgNMSdskIFaEDXAtpUxBCrTuVnwO)
 def dp_Episode_List(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO,args):
  lzhgNMSdskIFaEDXAtpUxBCrTuVnwo =args.get('programid')
  lzhgNMSdskIFaEDXAtpUxBCrTuVnwm =args.get('programnm')
  lzhgNMSdskIFaEDXAtpUxBCrTuVnwP =args.get('season')
  lzhgNMSdskIFaEDXAtpUxBCrTuVnwe =args.get('programimg')
  lzhgNMSdskIFaEDXAtpUxBCrTuVnwj=lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.Get_Episode_List(lzhgNMSdskIFaEDXAtpUxBCrTuVnwo,lzhgNMSdskIFaEDXAtpUxBCrTuVnwP)
  for lzhgNMSdskIFaEDXAtpUxBCrTuVnwQ in lzhgNMSdskIFaEDXAtpUxBCrTuVnwj:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnwY =lzhgNMSdskIFaEDXAtpUxBCrTuVnwQ.get('title')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnwJ =lzhgNMSdskIFaEDXAtpUxBCrTuVnwQ.get('id')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQO =lzhgNMSdskIFaEDXAtpUxBCrTuVnwQ.get('asis')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQy =lzhgNMSdskIFaEDXAtpUxBCrTuVnwQ.get('thumbnail')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQf =lzhgNMSdskIFaEDXAtpUxBCrTuVnwQ.get('mpaa')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQY =lzhgNMSdskIFaEDXAtpUxBCrTuVnwQ.get('duration')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQq =lzhgNMSdskIFaEDXAtpUxBCrTuVnwQ.get('year')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnwv =lzhgNMSdskIFaEDXAtpUxBCrTuVnwQ.get('episode')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQK =lzhgNMSdskIFaEDXAtpUxBCrTuVnwQ.get('genreList')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnwf =lzhgNMSdskIFaEDXAtpUxBCrTuVnwQ.get('desc')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnwH ='%sx%s'%(lzhgNMSdskIFaEDXAtpUxBCrTuVnwP,lzhgNMSdskIFaEDXAtpUxBCrTuVnwv)
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ ='%s. %s'%(lzhgNMSdskIFaEDXAtpUxBCrTuVnwH,lzhgNMSdskIFaEDXAtpUxBCrTuVnwY)
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQm={'mediatype':'episode','mpaa':lzhgNMSdskIFaEDXAtpUxBCrTuVnQf,'genre':lzhgNMSdskIFaEDXAtpUxBCrTuVnQK,'duration':lzhgNMSdskIFaEDXAtpUxBCrTuVnQY,'year':lzhgNMSdskIFaEDXAtpUxBCrTuVnQq,'plot':'%s (%s)\n\n%s'%(lzhgNMSdskIFaEDXAtpUxBCrTuVnwm,lzhgNMSdskIFaEDXAtpUxBCrTuVnwH,lzhgNMSdskIFaEDXAtpUxBCrTuVnwf),}
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoP={'mode':'VOD','programid':lzhgNMSdskIFaEDXAtpUxBCrTuVnwo,'programnm':lzhgNMSdskIFaEDXAtpUxBCrTuVnwm,'title':lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ,'season':lzhgNMSdskIFaEDXAtpUxBCrTuVnwP,'id':lzhgNMSdskIFaEDXAtpUxBCrTuVnwJ,'asis':lzhgNMSdskIFaEDXAtpUxBCrTuVnQO,'thumbnail':lzhgNMSdskIFaEDXAtpUxBCrTuVnQy,'programimg':lzhgNMSdskIFaEDXAtpUxBCrTuVnwe,}
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.add_dir(lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ,sublabel='',img=lzhgNMSdskIFaEDXAtpUxBCrTuVnQy,infoLabels=lzhgNMSdskIFaEDXAtpUxBCrTuVnQm,isFolder=lzhgNMSdskIFaEDXAtpUxBCrTuVnOR,params=lzhgNMSdskIFaEDXAtpUxBCrTuVnoP)
  xbmcplugin.setContent(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO._addon_handle,cacheToDisc=lzhgNMSdskIFaEDXAtpUxBCrTuVnOR)
 def play_VIDEO(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO,args):
  lzhgNMSdskIFaEDXAtpUxBCrTuVnwq =args.get('id')
  lzhgNMSdskIFaEDXAtpUxBCrTuVnQO =args.get('asis')
  if lzhgNMSdskIFaEDXAtpUxBCrTuVnQO in['HIGHLIGHT']:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnwW,lzhgNMSdskIFaEDXAtpUxBCrTuVnwK=lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.GetEventURL(lzhgNMSdskIFaEDXAtpUxBCrTuVnwq,lzhgNMSdskIFaEDXAtpUxBCrTuVnQO)
  elif lzhgNMSdskIFaEDXAtpUxBCrTuVnQO in['LIVE']:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnwW,lzhgNMSdskIFaEDXAtpUxBCrTuVnwK=lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.GetEventURL_Live(lzhgNMSdskIFaEDXAtpUxBCrTuVnwq,lzhgNMSdskIFaEDXAtpUxBCrTuVnQO)
  else:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnwW,lzhgNMSdskIFaEDXAtpUxBCrTuVnwK=lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.GetBroadURL(lzhgNMSdskIFaEDXAtpUxBCrTuVnwq)
  lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.addon_log('asis, url : %s - %s - %s'%(lzhgNMSdskIFaEDXAtpUxBCrTuVnQO,lzhgNMSdskIFaEDXAtpUxBCrTuVnwq,lzhgNMSdskIFaEDXAtpUxBCrTuVnwW))
  if lzhgNMSdskIFaEDXAtpUxBCrTuVnwW=='':
   if lzhgNMSdskIFaEDXAtpUxBCrTuVnwK=='':
    lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.addon_noti(__language__(30907).encode('utf8'))
   else:
    lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.addon_log('drm_license_1 : %s'%(lzhgNMSdskIFaEDXAtpUxBCrTuVnwK))
    lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.addon_noti(lzhgNMSdskIFaEDXAtpUxBCrTuVnwK)
   return
  else:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.addon_log('drm_license : %s'%(lzhgNMSdskIFaEDXAtpUxBCrTuVnwK))
  lzhgNMSdskIFaEDXAtpUxBCrTuVnwG='PCID=%s;token=%s;member_srl=%s;NEXT_LOCALE=%s;bm_mi=%s;ak_bmsc=%s;bm_sv=%s;session_web_id=%s;device_id=%s'%(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.CP['SESSION']['PCID'],lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.CP['SESSION']['token'],lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.CP['SESSION']['member_srl'],lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.CP['SESSION']['NEXT_LOCALE'],lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.CP['SESSION']['bm_mi'],lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.CP['SESSION']['ak_bmsc'],lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.CP['SESSION']['bm_sv'],lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.CP['SESSION']['session_web_id'],lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.CP['SESSION']['device_id'],)
  if lzhgNMSdskIFaEDXAtpUxBCrTuVnQO in['EPISODE']:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnwR='https://www.coupangplay.com/play/{}/episode?titleId={}&type=EPISODE&sourceType=page_discover_title_detail%3Apage_discover_feed'.format(lzhgNMSdskIFaEDXAtpUxBCrTuVnwq,lzhgNMSdskIFaEDXAtpUxBCrTuVnwq)
  elif lzhgNMSdskIFaEDXAtpUxBCrTuVnQO in['MOVIE']:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnwR='https://www.coupangplay.com/play/{}/movie?sourceType=page_discover_feed'.format(lzhgNMSdskIFaEDXAtpUxBCrTuVnwq)
  else:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnwR='https://www.coupangplay.com/play/'+lzhgNMSdskIFaEDXAtpUxBCrTuVnwq 
  lzhgNMSdskIFaEDXAtpUxBCrTuVnwc,lzhgNMSdskIFaEDXAtpUxBCrTuVnwb,lzhgNMSdskIFaEDXAtpUxBCrTuVnwL=lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.Make_authHeader()
  lzhgNMSdskIFaEDXAtpUxBCrTuVnwi=lzhgNMSdskIFaEDXAtpUxBCrTuVnwW 
  lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.addon_log('tobe, surl : %s'%(lzhgNMSdskIFaEDXAtpUxBCrTuVnwi))
  lzhgNMSdskIFaEDXAtpUxBCrTuVnym=xbmcgui.ListItem(path=lzhgNMSdskIFaEDXAtpUxBCrTuVnwi)
  lzhgNMSdskIFaEDXAtpUxBCrTuVnyo=lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.Get_Url_PostFix(lzhgNMSdskIFaEDXAtpUxBCrTuVnwW) 
  lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.addon_log('post_fix : '+lzhgNMSdskIFaEDXAtpUxBCrTuVnyo)
  if lzhgNMSdskIFaEDXAtpUxBCrTuVnyo=='m3u8':
   lzhgNMSdskIFaEDXAtpUxBCrTuVnyQ ='hls' 
  else:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnyQ ='mpd' 
  if lzhgNMSdskIFaEDXAtpUxBCrTuVnwK:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnyw =lzhgNMSdskIFaEDXAtpUxBCrTuVnwK 
   lzhgNMSdskIFaEDXAtpUxBCrTuVnyO ='com.widevine.alpha'
   lzhgNMSdskIFaEDXAtpUxBCrTuVnyP={'traceparent':lzhgNMSdskIFaEDXAtpUxBCrTuVnwc,'tracestate':lzhgNMSdskIFaEDXAtpUxBCrTuVnwb,'newrelic':lzhgNMSdskIFaEDXAtpUxBCrTuVnwL,'User-Agent':lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.USER_AGENT,'Referer':lzhgNMSdskIFaEDXAtpUxBCrTuVnwR,'Cookie':lzhgNMSdskIFaEDXAtpUxBCrTuVnwG,}
   lzhgNMSdskIFaEDXAtpUxBCrTuVnye=lzhgNMSdskIFaEDXAtpUxBCrTuVnyw+'|'+urllib.parse.urlencode(lzhgNMSdskIFaEDXAtpUxBCrTuVnyP)+'|R{SSM}|'
   lzhgNMSdskIFaEDXAtpUxBCrTuVnym.setProperty('inputstream','inputstream.adaptive')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnym.setProperty('inputstream.adaptive.manifest_type',lzhgNMSdskIFaEDXAtpUxBCrTuVnyQ)
   lzhgNMSdskIFaEDXAtpUxBCrTuVnym.setProperty('inputstream.adaptive.license_type',lzhgNMSdskIFaEDXAtpUxBCrTuVnyO)
   lzhgNMSdskIFaEDXAtpUxBCrTuVnym.setProperty('inputstream.adaptive.license_key',lzhgNMSdskIFaEDXAtpUxBCrTuVnye)
   lzhgNMSdskIFaEDXAtpUxBCrTuVnym.setProperty('inputstream.adaptive.stream_headers','User-Agent={}&Cookie={}&Referer={}&traceparent={}&tracestate={}&newrelic={}'.format(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.USER_AGENT,lzhgNMSdskIFaEDXAtpUxBCrTuVnwG,lzhgNMSdskIFaEDXAtpUxBCrTuVnwR,lzhgNMSdskIFaEDXAtpUxBCrTuVnwc,lzhgNMSdskIFaEDXAtpUxBCrTuVnwb,lzhgNMSdskIFaEDXAtpUxBCrTuVnwL))
   lzhgNMSdskIFaEDXAtpUxBCrTuVnym.setMimeType('application/dash+xml')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnym.setContentLookup(lzhgNMSdskIFaEDXAtpUxBCrTuVnOR)
  else:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnym.setContentLookup(lzhgNMSdskIFaEDXAtpUxBCrTuVnOR)
   lzhgNMSdskIFaEDXAtpUxBCrTuVnym.setMimeType('application/x-mpegURL')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnym.setProperty('inputstream','inputstream.adaptive')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnym.setProperty('inputstream.adaptive.manifest_type',lzhgNMSdskIFaEDXAtpUxBCrTuVnyQ)
   lzhgNMSdskIFaEDXAtpUxBCrTuVnym.setProperty('inputstream.adaptive.stream_headers','User-Agent={}&Cookie={}&Referer={}&traceparent={}&tracestate={}&newrelic={}'.format(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.USER_AGENT,lzhgNMSdskIFaEDXAtpUxBCrTuVnwG,lzhgNMSdskIFaEDXAtpUxBCrTuVnwR,lzhgNMSdskIFaEDXAtpUxBCrTuVnwc,lzhgNMSdskIFaEDXAtpUxBCrTuVnwb,lzhgNMSdskIFaEDXAtpUxBCrTuVnwL))
  xbmcplugin.setResolvedUrl(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO._addon_handle,lzhgNMSdskIFaEDXAtpUxBCrTuVnOc,lzhgNMSdskIFaEDXAtpUxBCrTuVnym)
  try:
   if lzhgNMSdskIFaEDXAtpUxBCrTuVnQO=='MOVIE':
    lzhgNMSdskIFaEDXAtpUxBCrTuVnyj='movie'
    lzhgNMSdskIFaEDXAtpUxBCrTuVnoP={'code':lzhgNMSdskIFaEDXAtpUxBCrTuVnwq,'asis':lzhgNMSdskIFaEDXAtpUxBCrTuVnQO,'title':args.get('title'),'img':args.get('thumbnail'),}
    lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.Save_Watched_List(lzhgNMSdskIFaEDXAtpUxBCrTuVnyj,lzhgNMSdskIFaEDXAtpUxBCrTuVnoP)
   elif lzhgNMSdskIFaEDXAtpUxBCrTuVnQO=='TVSHOW':
    lzhgNMSdskIFaEDXAtpUxBCrTuVnyj='tvshow'
    lzhgNMSdskIFaEDXAtpUxBCrTuVnoP={'code':args.get('programid'),'asis':lzhgNMSdskIFaEDXAtpUxBCrTuVnQO,'title':'%s <%s>'%(args.get('title'),args.get('programnm')),'img':args.get('programimg'),}
    lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.Save_Watched_List(lzhgNMSdskIFaEDXAtpUxBCrTuVnyj,lzhgNMSdskIFaEDXAtpUxBCrTuVnoP)
  except:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnOG
 def dp_Global_Search(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO,args):
  lzhgNMSdskIFaEDXAtpUxBCrTuVnQG=args.get('mode')
  if lzhgNMSdskIFaEDXAtpUxBCrTuVnQG=='TOTAL_SEARCH':
   lzhgNMSdskIFaEDXAtpUxBCrTuVnyY='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnyY='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(lzhgNMSdskIFaEDXAtpUxBCrTuVnyY)
 def dp_Bookmark_Menu(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO,args):
  lzhgNMSdskIFaEDXAtpUxBCrTuVnyY='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(lzhgNMSdskIFaEDXAtpUxBCrTuVnyY)
 def dp_Search_List(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO,args):
  lzhgNMSdskIFaEDXAtpUxBCrTuVnQJ =lzhgNMSdskIFaEDXAtpUxBCrTuVnOi(args.get('page'))
  if 'search_key' in args:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnyJ=args.get('search_key')
  else:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnyJ=lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.get_keyboard_input(__language__(30908).encode('utf-8'))
   if not lzhgNMSdskIFaEDXAtpUxBCrTuVnyJ:
    return
  lzhgNMSdskIFaEDXAtpUxBCrTuVnyv,lzhgNMSdskIFaEDXAtpUxBCrTuVnQv=lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.Get_Search_List(lzhgNMSdskIFaEDXAtpUxBCrTuVnyJ,lzhgNMSdskIFaEDXAtpUxBCrTuVnQJ)
  for lzhgNMSdskIFaEDXAtpUxBCrTuVnyf in lzhgNMSdskIFaEDXAtpUxBCrTuVnyv:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnPw =lzhgNMSdskIFaEDXAtpUxBCrTuVnyf.get('id')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ =lzhgNMSdskIFaEDXAtpUxBCrTuVnyf.get('title')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQO =lzhgNMSdskIFaEDXAtpUxBCrTuVnyf.get('asis')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQy =lzhgNMSdskIFaEDXAtpUxBCrTuVnyf.get('thumbnail')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQf =lzhgNMSdskIFaEDXAtpUxBCrTuVnyf.get('mpaa')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQq =lzhgNMSdskIFaEDXAtpUxBCrTuVnyf.get('year')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQY =lzhgNMSdskIFaEDXAtpUxBCrTuVnyf.get('duration')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQH =lzhgNMSdskIFaEDXAtpUxBCrTuVnyf.get('badge')
   if lzhgNMSdskIFaEDXAtpUxBCrTuVnQO=='TVSHOW': 
    lzhgNMSdskIFaEDXAtpUxBCrTuVnQG ='SEASON_LIST'
    lzhgNMSdskIFaEDXAtpUxBCrTuVnQm={'mediatype':'tvshow','title':lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ,'mpaa':lzhgNMSdskIFaEDXAtpUxBCrTuVnQf,'year':lzhgNMSdskIFaEDXAtpUxBCrTuVnQq,'plot':'Year : %s'%(lzhgNMSdskIFaEDXAtpUxBCrTuVnQq),}
    lzhgNMSdskIFaEDXAtpUxBCrTuVnoe =lzhgNMSdskIFaEDXAtpUxBCrTuVnOc
   elif lzhgNMSdskIFaEDXAtpUxBCrTuVnQO=='MOVIE':
    lzhgNMSdskIFaEDXAtpUxBCrTuVnQG ='MOVIE'
    lzhgNMSdskIFaEDXAtpUxBCrTuVnQm={'mediatype':'movie','title':lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ,'mpaa':lzhgNMSdskIFaEDXAtpUxBCrTuVnQf,'duration':lzhgNMSdskIFaEDXAtpUxBCrTuVnQY,'year':lzhgNMSdskIFaEDXAtpUxBCrTuVnQq,'plot':'(%s)'%(lzhgNMSdskIFaEDXAtpUxBCrTuVnQf),}
    lzhgNMSdskIFaEDXAtpUxBCrTuVnoe =lzhgNMSdskIFaEDXAtpUxBCrTuVnOR
    lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ +=' (%s)'%(lzhgNMSdskIFaEDXAtpUxBCrTuVnPQ(lzhgNMSdskIFaEDXAtpUxBCrTuVnQq))
   elif lzhgNMSdskIFaEDXAtpUxBCrTuVnQO=='HIGHLIGHT':
    lzhgNMSdskIFaEDXAtpUxBCrTuVnQG ='HIGHLIGHT'
    lzhgNMSdskIFaEDXAtpUxBCrTuVnQm={'mediatype':'episode','title':lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ,'duration':lzhgNMSdskIFaEDXAtpUxBCrTuVnQY,'plot':lzhgNMSdskIFaEDXAtpUxBCrTuVnQG,}
    lzhgNMSdskIFaEDXAtpUxBCrTuVnoe =lzhgNMSdskIFaEDXAtpUxBCrTuVnOR
   elif lzhgNMSdskIFaEDXAtpUxBCrTuVnQO=='LIVE':
    lzhgNMSdskIFaEDXAtpUxBCrTuVnQG ='LIVE'
    lzhgNMSdskIFaEDXAtpUxBCrTuVnQm={'mediatype':'episode','title':lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ,'plot':lzhgNMSdskIFaEDXAtpUxBCrTuVnQG,}
    lzhgNMSdskIFaEDXAtpUxBCrTuVnoe =lzhgNMSdskIFaEDXAtpUxBCrTuVnOR
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoP={'mode':lzhgNMSdskIFaEDXAtpUxBCrTuVnQG,'id':lzhgNMSdskIFaEDXAtpUxBCrTuVnPw,'asis':lzhgNMSdskIFaEDXAtpUxBCrTuVnQO,'seasonList':'','title':lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ,'thumbnail':json.dumps(lzhgNMSdskIFaEDXAtpUxBCrTuVnQy,separators=(',',':')),'year':lzhgNMSdskIFaEDXAtpUxBCrTuVnQq,}
   if lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.get_settings_makebookmark()and lzhgNMSdskIFaEDXAtpUxBCrTuVnQO not in['HIGHLIGHT','']:
    lzhgNMSdskIFaEDXAtpUxBCrTuVnQR={'videoid':lzhgNMSdskIFaEDXAtpUxBCrTuVnPw,'vidtype':'movie' if lzhgNMSdskIFaEDXAtpUxBCrTuVnQO=='MOVIE' else 'tvshow','vtitle':lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ,'vsubtitle':'',}
    lzhgNMSdskIFaEDXAtpUxBCrTuVnQc=json.dumps(lzhgNMSdskIFaEDXAtpUxBCrTuVnQR)
    lzhgNMSdskIFaEDXAtpUxBCrTuVnQc=urllib.parse.quote(lzhgNMSdskIFaEDXAtpUxBCrTuVnQc)
    lzhgNMSdskIFaEDXAtpUxBCrTuVnQb='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(lzhgNMSdskIFaEDXAtpUxBCrTuVnQc)
    lzhgNMSdskIFaEDXAtpUxBCrTuVnQL=[('(통합) 찜 영상에 추가',lzhgNMSdskIFaEDXAtpUxBCrTuVnQb)]
   else:
    lzhgNMSdskIFaEDXAtpUxBCrTuVnQL=lzhgNMSdskIFaEDXAtpUxBCrTuVnOG
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.add_dir(lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ,sublabel=lzhgNMSdskIFaEDXAtpUxBCrTuVnQH,img=lzhgNMSdskIFaEDXAtpUxBCrTuVnQy,infoLabels=lzhgNMSdskIFaEDXAtpUxBCrTuVnQm,isFolder=lzhgNMSdskIFaEDXAtpUxBCrTuVnoe,params=lzhgNMSdskIFaEDXAtpUxBCrTuVnoP,ContextMenu=lzhgNMSdskIFaEDXAtpUxBCrTuVnQL)
  if lzhgNMSdskIFaEDXAtpUxBCrTuVnQv:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoP={}
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoP['mode'] ='LOCAL_SEARCH'
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoP['search_key']=lzhgNMSdskIFaEDXAtpUxBCrTuVnyJ
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoP['page'] =lzhgNMSdskIFaEDXAtpUxBCrTuVnPQ(lzhgNMSdskIFaEDXAtpUxBCrTuVnQJ+1)
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ='[B]%s >>[/B]'%'다음 페이지'
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQi=lzhgNMSdskIFaEDXAtpUxBCrTuVnPQ(lzhgNMSdskIFaEDXAtpUxBCrTuVnQJ+1)
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoO=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.add_dir(lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ,sublabel=lzhgNMSdskIFaEDXAtpUxBCrTuVnQi,img=lzhgNMSdskIFaEDXAtpUxBCrTuVnoO,infoLabels=lzhgNMSdskIFaEDXAtpUxBCrTuVnOG,isFolder=lzhgNMSdskIFaEDXAtpUxBCrTuVnOc,params=lzhgNMSdskIFaEDXAtpUxBCrTuVnoP)
  xbmcplugin.setContent(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO._addon_handle,'movies')
  xbmcplugin.endOfDirectory(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO._addon_handle,cacheToDisc=lzhgNMSdskIFaEDXAtpUxBCrTuVnOc)
  if args.get('historyyn')=='Y':lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.Save_Searched_List(lzhgNMSdskIFaEDXAtpUxBCrTuVnyJ)
 def Load_List_File(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO,lzhgNMSdskIFaEDXAtpUxBCrTuVnyj): 
  try:
   if lzhgNMSdskIFaEDXAtpUxBCrTuVnyj=='search':
    lzhgNMSdskIFaEDXAtpUxBCrTuVnyH=lzhgNMSdskIFaEDXAtpUxBCrTuVnmy
   elif lzhgNMSdskIFaEDXAtpUxBCrTuVnyj in['tvshow','movie']:
    lzhgNMSdskIFaEDXAtpUxBCrTuVnyH=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%lzhgNMSdskIFaEDXAtpUxBCrTuVnyj))
   else:
    return[]
   fp=lzhgNMSdskIFaEDXAtpUxBCrTuVnPm(lzhgNMSdskIFaEDXAtpUxBCrTuVnyH,'r',-1,'utf-8')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnyq=fp.readlines()
   fp.close()
  except:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnyq=[]
  return lzhgNMSdskIFaEDXAtpUxBCrTuVnyq
 def Save_Watched_List(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO,lzhgNMSdskIFaEDXAtpUxBCrTuVnyj,lzhgNMSdskIFaEDXAtpUxBCrTuVnmj):
  try:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnyW=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%lzhgNMSdskIFaEDXAtpUxBCrTuVnyj))
   lzhgNMSdskIFaEDXAtpUxBCrTuVnyK=lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.Load_List_File(lzhgNMSdskIFaEDXAtpUxBCrTuVnyj) 
   fp=lzhgNMSdskIFaEDXAtpUxBCrTuVnPm(lzhgNMSdskIFaEDXAtpUxBCrTuVnyW,'w',-1,'utf-8')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnyG=urllib.parse.urlencode(lzhgNMSdskIFaEDXAtpUxBCrTuVnmj)
   lzhgNMSdskIFaEDXAtpUxBCrTuVnyG=lzhgNMSdskIFaEDXAtpUxBCrTuVnyG+'\n'
   fp.write(lzhgNMSdskIFaEDXAtpUxBCrTuVnyG)
   lzhgNMSdskIFaEDXAtpUxBCrTuVnyR=0
   for lzhgNMSdskIFaEDXAtpUxBCrTuVnyc in lzhgNMSdskIFaEDXAtpUxBCrTuVnyK:
    lzhgNMSdskIFaEDXAtpUxBCrTuVnyb=lzhgNMSdskIFaEDXAtpUxBCrTuVnOL(urllib.parse.parse_qsl(lzhgNMSdskIFaEDXAtpUxBCrTuVnyc))
    lzhgNMSdskIFaEDXAtpUxBCrTuVnyL=lzhgNMSdskIFaEDXAtpUxBCrTuVnmj.get('code').strip()
    lzhgNMSdskIFaEDXAtpUxBCrTuVnyi=lzhgNMSdskIFaEDXAtpUxBCrTuVnyb.get('code').strip()
    if lzhgNMSdskIFaEDXAtpUxBCrTuVnyL!=lzhgNMSdskIFaEDXAtpUxBCrTuVnyi:
     fp.write(lzhgNMSdskIFaEDXAtpUxBCrTuVnyc)
     lzhgNMSdskIFaEDXAtpUxBCrTuVnyR+=1
     if lzhgNMSdskIFaEDXAtpUxBCrTuVnyR>=50:break
   fp.close()
  except:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnOG
 def Save_Searched_List(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO,lzhgNMSdskIFaEDXAtpUxBCrTuVnyJ):
  try:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnyJ=lzhgNMSdskIFaEDXAtpUxBCrTuVnyJ.strip()
   lzhgNMSdskIFaEDXAtpUxBCrTuVnyK=lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.Load_List_File('search') 
   fp=lzhgNMSdskIFaEDXAtpUxBCrTuVnPm(lzhgNMSdskIFaEDXAtpUxBCrTuVnmy,'w',-1,'utf-8')
   fp.write(lzhgNMSdskIFaEDXAtpUxBCrTuVnyJ+'\n')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnyR=0
   for lzhgNMSdskIFaEDXAtpUxBCrTuVnyc in lzhgNMSdskIFaEDXAtpUxBCrTuVnyK:
    lzhgNMSdskIFaEDXAtpUxBCrTuVnyc=lzhgNMSdskIFaEDXAtpUxBCrTuVnyc.strip()
    if lzhgNMSdskIFaEDXAtpUxBCrTuVnyJ!=lzhgNMSdskIFaEDXAtpUxBCrTuVnyc:
     fp.write(lzhgNMSdskIFaEDXAtpUxBCrTuVnyc+'\n')
     lzhgNMSdskIFaEDXAtpUxBCrTuVnyR+=1
     if lzhgNMSdskIFaEDXAtpUxBCrTuVnyR>=50:break
   fp.close()
  except:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnOG
 def dp_Search_History(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO,args):
  lzhgNMSdskIFaEDXAtpUxBCrTuVnOm=lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.Load_List_File('search')
  for lzhgNMSdskIFaEDXAtpUxBCrTuVnOo in lzhgNMSdskIFaEDXAtpUxBCrTuVnOm:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnOo=lzhgNMSdskIFaEDXAtpUxBCrTuVnOo.strip()
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoP={'mode':'LOCAL_SEARCH','search_key':lzhgNMSdskIFaEDXAtpUxBCrTuVnOo,'page':'1','historyyn':'Y',}
   lzhgNMSdskIFaEDXAtpUxBCrTuVnOQ={'mode':'SEARCH_REMOVE','stype':'ONE','skey':lzhgNMSdskIFaEDXAtpUxBCrTuVnOo,}
   lzhgNMSdskIFaEDXAtpUxBCrTuVnOw=urllib.parse.urlencode(lzhgNMSdskIFaEDXAtpUxBCrTuVnOQ)
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQL=[('선택된 검색어 ( %s ) 삭제'%(lzhgNMSdskIFaEDXAtpUxBCrTuVnOo),'RunPlugin(plugin://plugin.video.coupangm/?%s)'%(lzhgNMSdskIFaEDXAtpUxBCrTuVnOw))]
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.add_dir(lzhgNMSdskIFaEDXAtpUxBCrTuVnOo,sublabel='',img=lzhgNMSdskIFaEDXAtpUxBCrTuVnOG,infoLabels=lzhgNMSdskIFaEDXAtpUxBCrTuVnOG,isFolder=lzhgNMSdskIFaEDXAtpUxBCrTuVnOc,params=lzhgNMSdskIFaEDXAtpUxBCrTuVnoP,ContextMenu=lzhgNMSdskIFaEDXAtpUxBCrTuVnQL)
  lzhgNMSdskIFaEDXAtpUxBCrTuVnQm={'plot':'검색목록 전체를 삭제합니다.'}
  lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  lzhgNMSdskIFaEDXAtpUxBCrTuVnoP={'mode':'SEARCH_REMOVE','stype':'ALL','skey':'-',}
  lzhgNMSdskIFaEDXAtpUxBCrTuVnoO=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.add_dir(lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ,sublabel='',img=lzhgNMSdskIFaEDXAtpUxBCrTuVnoO,infoLabels=lzhgNMSdskIFaEDXAtpUxBCrTuVnQm,isFolder=lzhgNMSdskIFaEDXAtpUxBCrTuVnOR,params=lzhgNMSdskIFaEDXAtpUxBCrTuVnoP,isLink=lzhgNMSdskIFaEDXAtpUxBCrTuVnOc)
  xbmcplugin.endOfDirectory(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO._addon_handle,cacheToDisc=lzhgNMSdskIFaEDXAtpUxBCrTuVnOR)
 def dp_Listfile_Delete(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO,args):
  lzhgNMSdskIFaEDXAtpUxBCrTuVnyj=args.get('stype')
  lzhgNMSdskIFaEDXAtpUxBCrTuVnOy =args.get('skey')
  lzhgNMSdskIFaEDXAtpUxBCrTuVnmJ=xbmcgui.Dialog()
  if lzhgNMSdskIFaEDXAtpUxBCrTuVnyj=='ALL':
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoJ=lzhgNMSdskIFaEDXAtpUxBCrTuVnmJ.yesno(__language__(30911).encode('utf8'),__language__(30906).encode('utf8'))
  elif lzhgNMSdskIFaEDXAtpUxBCrTuVnyj=='ONE':
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoJ=lzhgNMSdskIFaEDXAtpUxBCrTuVnmJ.yesno(__language__(30912).encode('utf8'),__language__(30906).encode('utf8'))
  elif lzhgNMSdskIFaEDXAtpUxBCrTuVnyj in['tvshow','movie']:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoJ=lzhgNMSdskIFaEDXAtpUxBCrTuVnmJ.yesno(__language__(30913).encode('utf8'),__language__(30906).encode('utf8'))
  if lzhgNMSdskIFaEDXAtpUxBCrTuVnoJ==lzhgNMSdskIFaEDXAtpUxBCrTuVnOR:sys.exit()
  lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.Delete_List_File(lzhgNMSdskIFaEDXAtpUxBCrTuVnyj,skey=lzhgNMSdskIFaEDXAtpUxBCrTuVnOy)
  xbmc.executebuiltin("Container.Refresh")
 def Delete_List_File(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO,lzhgNMSdskIFaEDXAtpUxBCrTuVnyj,skey='-'):
  if lzhgNMSdskIFaEDXAtpUxBCrTuVnyj=='ALL':
   try:
    lzhgNMSdskIFaEDXAtpUxBCrTuVnyH=lzhgNMSdskIFaEDXAtpUxBCrTuVnmy
    fp=lzhgNMSdskIFaEDXAtpUxBCrTuVnPm(lzhgNMSdskIFaEDXAtpUxBCrTuVnyH,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    lzhgNMSdskIFaEDXAtpUxBCrTuVnOG
  elif lzhgNMSdskIFaEDXAtpUxBCrTuVnyj=='ONE':
   try:
    lzhgNMSdskIFaEDXAtpUxBCrTuVnyH=lzhgNMSdskIFaEDXAtpUxBCrTuVnmy
    lzhgNMSdskIFaEDXAtpUxBCrTuVnyK=lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.Load_List_File('search') 
    fp=lzhgNMSdskIFaEDXAtpUxBCrTuVnPm(lzhgNMSdskIFaEDXAtpUxBCrTuVnyH,'w',-1,'utf-8')
    for lzhgNMSdskIFaEDXAtpUxBCrTuVnyc in lzhgNMSdskIFaEDXAtpUxBCrTuVnyK:
     if skey!=lzhgNMSdskIFaEDXAtpUxBCrTuVnyc.strip():
      fp.write(lzhgNMSdskIFaEDXAtpUxBCrTuVnyc)
    fp.close()
   except:
    lzhgNMSdskIFaEDXAtpUxBCrTuVnOG
  elif lzhgNMSdskIFaEDXAtpUxBCrTuVnyj in['tvshow','movie']:
   try:
    lzhgNMSdskIFaEDXAtpUxBCrTuVnyH=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%lzhgNMSdskIFaEDXAtpUxBCrTuVnyj))
    fp=lzhgNMSdskIFaEDXAtpUxBCrTuVnPm(lzhgNMSdskIFaEDXAtpUxBCrTuVnyH,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    lzhgNMSdskIFaEDXAtpUxBCrTuVnOG
 def dp_Watch_List(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO,args):
  lzhgNMSdskIFaEDXAtpUxBCrTuVnyj =args.get('stype')
  if lzhgNMSdskIFaEDXAtpUxBCrTuVnyj in['',lzhgNMSdskIFaEDXAtpUxBCrTuVnOG]:
   for lzhgNMSdskIFaEDXAtpUxBCrTuVnOP in lzhgNMSdskIFaEDXAtpUxBCrTuVnmw:
    lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ=lzhgNMSdskIFaEDXAtpUxBCrTuVnOP.get('title')
    lzhgNMSdskIFaEDXAtpUxBCrTuVnoP={'mode':lzhgNMSdskIFaEDXAtpUxBCrTuVnOP.get('mode'),'stype':lzhgNMSdskIFaEDXAtpUxBCrTuVnOP.get('stype'),}
    lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.add_dir(lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ,sublabel='',img='',infoLabels=lzhgNMSdskIFaEDXAtpUxBCrTuVnOG,isFolder=lzhgNMSdskIFaEDXAtpUxBCrTuVnOc,params=lzhgNMSdskIFaEDXAtpUxBCrTuVnoP)
   xbmcplugin.endOfDirectory(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO._addon_handle)
  else:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnOe=lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.Load_List_File(lzhgNMSdskIFaEDXAtpUxBCrTuVnyj)
   for lzhgNMSdskIFaEDXAtpUxBCrTuVnOj in lzhgNMSdskIFaEDXAtpUxBCrTuVnOe:
    lzhgNMSdskIFaEDXAtpUxBCrTuVnOY=lzhgNMSdskIFaEDXAtpUxBCrTuVnOL(urllib.parse.parse_qsl(lzhgNMSdskIFaEDXAtpUxBCrTuVnOj))
    lzhgNMSdskIFaEDXAtpUxBCrTuVnwq =lzhgNMSdskIFaEDXAtpUxBCrTuVnOY.get('code').strip()
    lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ =lzhgNMSdskIFaEDXAtpUxBCrTuVnOY.get('title').strip()
    lzhgNMSdskIFaEDXAtpUxBCrTuVnQy =lzhgNMSdskIFaEDXAtpUxBCrTuVnOY.get('img').strip()
    lzhgNMSdskIFaEDXAtpUxBCrTuVnQO =lzhgNMSdskIFaEDXAtpUxBCrTuVnOY.get('asis').strip()
    try:
     lzhgNMSdskIFaEDXAtpUxBCrTuVnQy=lzhgNMSdskIFaEDXAtpUxBCrTuVnQy.replace('\'','\"')
     lzhgNMSdskIFaEDXAtpUxBCrTuVnQy=json.loads(lzhgNMSdskIFaEDXAtpUxBCrTuVnQy)
    except:
     lzhgNMSdskIFaEDXAtpUxBCrTuVnOG
    lzhgNMSdskIFaEDXAtpUxBCrTuVnQm={}
    lzhgNMSdskIFaEDXAtpUxBCrTuVnQm['plot']=lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ
    if lzhgNMSdskIFaEDXAtpUxBCrTuVnyj=='movie':
     lzhgNMSdskIFaEDXAtpUxBCrTuVnQm['mediatype']='movie'
     lzhgNMSdskIFaEDXAtpUxBCrTuVnoP={'mode':'MOVIE','id':lzhgNMSdskIFaEDXAtpUxBCrTuVnwq,'asis':lzhgNMSdskIFaEDXAtpUxBCrTuVnQO,'title':lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ,'thumbnail':lzhgNMSdskIFaEDXAtpUxBCrTuVnQy,}
     lzhgNMSdskIFaEDXAtpUxBCrTuVnoe=lzhgNMSdskIFaEDXAtpUxBCrTuVnOR
    else:
     lzhgNMSdskIFaEDXAtpUxBCrTuVnQm['mediatype']='episode'
     lzhgNMSdskIFaEDXAtpUxBCrTuVnoP={'mode':'SEASON_LIST','id':lzhgNMSdskIFaEDXAtpUxBCrTuVnwq,'asis':lzhgNMSdskIFaEDXAtpUxBCrTuVnQO,'title':lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ,'thumbnail':json.dumps(lzhgNMSdskIFaEDXAtpUxBCrTuVnQy,separators=(',',':')),}
     lzhgNMSdskIFaEDXAtpUxBCrTuVnoe=lzhgNMSdskIFaEDXAtpUxBCrTuVnOc
    lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.add_dir(lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ,sublabel='',img=lzhgNMSdskIFaEDXAtpUxBCrTuVnQy,infoLabels=lzhgNMSdskIFaEDXAtpUxBCrTuVnQm,isFolder=lzhgNMSdskIFaEDXAtpUxBCrTuVnoe,params=lzhgNMSdskIFaEDXAtpUxBCrTuVnoP)
   lzhgNMSdskIFaEDXAtpUxBCrTuVnQm={'plot':'시청목록을 삭제합니다.'}
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ='*** 시청목록 삭제 ***'
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoP={'mode':'MYVIEW_REMOVE','stype':lzhgNMSdskIFaEDXAtpUxBCrTuVnyj,'skey':'-',}
   lzhgNMSdskIFaEDXAtpUxBCrTuVnoO=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.add_dir(lzhgNMSdskIFaEDXAtpUxBCrTuVnoQ,sublabel='',img=lzhgNMSdskIFaEDXAtpUxBCrTuVnoO,infoLabels=lzhgNMSdskIFaEDXAtpUxBCrTuVnQm,isFolder=lzhgNMSdskIFaEDXAtpUxBCrTuVnOR,params=lzhgNMSdskIFaEDXAtpUxBCrTuVnoP,isLink=lzhgNMSdskIFaEDXAtpUxBCrTuVnOc)
   if lzhgNMSdskIFaEDXAtpUxBCrTuVnyj=='movie':xbmcplugin.setContent(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO._addon_handle,'movies')
   else:xbmcplugin.setContent(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO._addon_handle,cacheToDisc=lzhgNMSdskIFaEDXAtpUxBCrTuVnOR)
 def dp_Set_Bookmark(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO,args):
  lzhgNMSdskIFaEDXAtpUxBCrTuVnOJ=urllib.parse.unquote(args.get('bm_param'))
  lzhgNMSdskIFaEDXAtpUxBCrTuVnOJ=json.loads(lzhgNMSdskIFaEDXAtpUxBCrTuVnOJ)
  lzhgNMSdskIFaEDXAtpUxBCrTuVnOv =lzhgNMSdskIFaEDXAtpUxBCrTuVnOJ.get('videoid')
  lzhgNMSdskIFaEDXAtpUxBCrTuVnOf =lzhgNMSdskIFaEDXAtpUxBCrTuVnOJ.get('vidtype')
  lzhgNMSdskIFaEDXAtpUxBCrTuVnOH =lzhgNMSdskIFaEDXAtpUxBCrTuVnOJ.get('vtitle')
  lzhgNMSdskIFaEDXAtpUxBCrTuVnmJ=xbmcgui.Dialog()
  lzhgNMSdskIFaEDXAtpUxBCrTuVnoJ=lzhgNMSdskIFaEDXAtpUxBCrTuVnmJ.yesno(__language__(30914).encode('utf8'),lzhgNMSdskIFaEDXAtpUxBCrTuVnOH+' \n\n'+__language__(30915))
  if lzhgNMSdskIFaEDXAtpUxBCrTuVnoJ==lzhgNMSdskIFaEDXAtpUxBCrTuVnOR:return
  lzhgNMSdskIFaEDXAtpUxBCrTuVnOq=lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CoupangObj.GetBookmarkInfo(lzhgNMSdskIFaEDXAtpUxBCrTuVnOv,lzhgNMSdskIFaEDXAtpUxBCrTuVnOf)
  lzhgNMSdskIFaEDXAtpUxBCrTuVnOW=json.dumps(lzhgNMSdskIFaEDXAtpUxBCrTuVnOq)
  lzhgNMSdskIFaEDXAtpUxBCrTuVnOW=urllib.parse.quote(lzhgNMSdskIFaEDXAtpUxBCrTuVnOW)
  lzhgNMSdskIFaEDXAtpUxBCrTuVnQb ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(lzhgNMSdskIFaEDXAtpUxBCrTuVnOW)
  xbmc.executebuiltin(lzhgNMSdskIFaEDXAtpUxBCrTuVnQb)
 def coupang_main(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO):
  lzhgNMSdskIFaEDXAtpUxBCrTuVnQG=lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.main_params.get('mode',lzhgNMSdskIFaEDXAtpUxBCrTuVnOG)
  if lzhgNMSdskIFaEDXAtpUxBCrTuVnQG=='LOGOUT':
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.CP_logout()
   return
  lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.option_check()
  if lzhgNMSdskIFaEDXAtpUxBCrTuVnQG is lzhgNMSdskIFaEDXAtpUxBCrTuVnOG:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.dp_Main_List(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.main_params)
  elif lzhgNMSdskIFaEDXAtpUxBCrTuVnQG=='CATEGORY_GROUPLIST':
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.dp_Category_GroupList(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.main_params)
  elif lzhgNMSdskIFaEDXAtpUxBCrTuVnQG=='THEME_GROUPLIST':
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.dp_Theme_GroupList(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.main_params)
  elif lzhgNMSdskIFaEDXAtpUxBCrTuVnQG=='EVENT_GROUPLIST':
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.dp_Event_GroupList(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.main_params)
  elif lzhgNMSdskIFaEDXAtpUxBCrTuVnQG=='EVENT_GAMELIST':
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.dp_Event_GameList(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.main_params)
  elif lzhgNMSdskIFaEDXAtpUxBCrTuVnQG=='EVENT_LIST':
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.dp_Event_List(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.main_params)
  elif lzhgNMSdskIFaEDXAtpUxBCrTuVnQG=='CATEGORY_LIST':
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.dp_Category_List(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.main_params)
  elif lzhgNMSdskIFaEDXAtpUxBCrTuVnQG=='SEASON_LIST':
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.dp_Season_List(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.main_params)
  elif lzhgNMSdskIFaEDXAtpUxBCrTuVnQG=='EPISODE_LIST':
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.dp_Episode_List(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.main_params)
  elif lzhgNMSdskIFaEDXAtpUxBCrTuVnQG=='TEST':
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.dp_Test(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.main_params)
  elif lzhgNMSdskIFaEDXAtpUxBCrTuVnQG in['MOVIE','VOD','HIGHLIGHT','LIVE']:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.play_VIDEO(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.main_params)
  elif lzhgNMSdskIFaEDXAtpUxBCrTuVnQG=='WATCH':
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.dp_Watch_List(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.main_params)
  elif lzhgNMSdskIFaEDXAtpUxBCrTuVnQG=='LOCAL_SEARCH':
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.dp_Search_List(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.main_params)
  elif lzhgNMSdskIFaEDXAtpUxBCrTuVnQG=='SEARCH_HISTORY':
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.dp_Search_History(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.main_params)
  elif lzhgNMSdskIFaEDXAtpUxBCrTuVnQG in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.dp_Listfile_Delete(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.main_params)
  elif lzhgNMSdskIFaEDXAtpUxBCrTuVnQG in['TOTAL_SEARCH','TOTAL_HISTORY']:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.dp_Global_Search(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.main_params)
  elif lzhgNMSdskIFaEDXAtpUxBCrTuVnQG=='MENU_BOOKMARK':
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.dp_Bookmark_Menu(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.main_params)
  elif lzhgNMSdskIFaEDXAtpUxBCrTuVnQG=='SET_BOOKMARK':
   lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.dp_Set_Bookmark(lzhgNMSdskIFaEDXAtpUxBCrTuVnmO.main_params)
  else:
   lzhgNMSdskIFaEDXAtpUxBCrTuVnOG
# Created by pyminifier (https://github.com/liftoff/pyminifier)
