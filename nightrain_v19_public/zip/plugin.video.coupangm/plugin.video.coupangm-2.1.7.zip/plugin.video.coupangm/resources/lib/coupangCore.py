__author__="NightRain"
folqeUbQJOXiWrIEzxsVNACvjuwgYh=object
folqeUbQJOXiWrIEzxsVNACvjuwgYc=None
folqeUbQJOXiWrIEzxsVNACvjuwgYR=False
folqeUbQJOXiWrIEzxsVNACvjuwgYD=print
folqeUbQJOXiWrIEzxsVNACvjuwgYG=str
folqeUbQJOXiWrIEzxsVNACvjuwgYH=open
folqeUbQJOXiWrIEzxsVNACvjuwgYP=int
folqeUbQJOXiWrIEzxsVNACvjuwgYB=Exception
folqeUbQJOXiWrIEzxsVNACvjuwgYL=len
folqeUbQJOXiWrIEzxsVNACvjuwgmF=id
folqeUbQJOXiWrIEzxsVNACvjuwgmd=True
folqeUbQJOXiWrIEzxsVNACvjuwgmM=range
import urllib
import re
import json
import requests
import datetime
import time
import random
import base64
class folqeUbQJOXiWrIEzxsVNACvjuwgFd(folqeUbQJOXiWrIEzxsVNACvjuwgYh):
 def __init__(folqeUbQJOXiWrIEzxsVNACvjuwgFM):
  folqeUbQJOXiWrIEzxsVNACvjuwgFM.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
  folqeUbQJOXiWrIEzxsVNACvjuwgFM.MODEL ='Chrome_128' 
  folqeUbQJOXiWrIEzxsVNACvjuwgFM.OS_VERSION ='128' 
  folqeUbQJOXiWrIEzxsVNACvjuwgFM.DEFAULT_HEADER ={'user-agent':folqeUbQJOXiWrIEzxsVNACvjuwgFM.USER_AGENT}
  folqeUbQJOXiWrIEzxsVNACvjuwgFM.API_DOMAIN ='https://www.coupangplay.com'
  folqeUbQJOXiWrIEzxsVNACvjuwgFM.API_VIEWURL ='https://discover.coupangstreaming.com'
  folqeUbQJOXiWrIEzxsVNACvjuwgFM.PAGE_LIMIT =40
  folqeUbQJOXiWrIEzxsVNACvjuwgFM.SEARCH_LIMIT =20
  folqeUbQJOXiWrIEzxsVNACvjuwgFM.KodiVersion =20
  folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP={}
  folqeUbQJOXiWrIEzxsVNACvjuwgFM.Init_CP()
  folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP_DEVICE_FILENAME=''
  folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP_COOKIE_FILENAME=''
  folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP_SESSION_COOKIES1=''
 def callRequestCookies(folqeUbQJOXiWrIEzxsVNACvjuwgFM,jobtype,folqeUbQJOXiWrIEzxsVNACvjuwgdS,payload=folqeUbQJOXiWrIEzxsVNACvjuwgYc,params=folqeUbQJOXiWrIEzxsVNACvjuwgYc,headers=folqeUbQJOXiWrIEzxsVNACvjuwgYc,cookies=folqeUbQJOXiWrIEzxsVNACvjuwgYc,redirects=folqeUbQJOXiWrIEzxsVNACvjuwgYR):
  folqeUbQJOXiWrIEzxsVNACvjuwgFY=folqeUbQJOXiWrIEzxsVNACvjuwgFM.DEFAULT_HEADER
  if headers:folqeUbQJOXiWrIEzxsVNACvjuwgFY.update(headers)
  if jobtype=='Get':
   folqeUbQJOXiWrIEzxsVNACvjuwgFm=requests.get(folqeUbQJOXiWrIEzxsVNACvjuwgdS,params=params,headers=folqeUbQJOXiWrIEzxsVNACvjuwgFY,cookies=cookies,allow_redirects=redirects)
  else:
   folqeUbQJOXiWrIEzxsVNACvjuwgFm=requests.post(folqeUbQJOXiWrIEzxsVNACvjuwgdS,data=payload,params=params,headers=folqeUbQJOXiWrIEzxsVNACvjuwgFY,cookies=cookies,allow_redirects=redirects)
  folqeUbQJOXiWrIEzxsVNACvjuwgYD(folqeUbQJOXiWrIEzxsVNACvjuwgYG(folqeUbQJOXiWrIEzxsVNACvjuwgFm.status_code)+' - '+folqeUbQJOXiWrIEzxsVNACvjuwgYG(folqeUbQJOXiWrIEzxsVNACvjuwgFm.url))
  return folqeUbQJOXiWrIEzxsVNACvjuwgFm
 def callRequestCookies_test(folqeUbQJOXiWrIEzxsVNACvjuwgFM,jobtype,folqeUbQJOXiWrIEzxsVNACvjuwgdS,payload=folqeUbQJOXiWrIEzxsVNACvjuwgYc,params=folqeUbQJOXiWrIEzxsVNACvjuwgYc,headers=folqeUbQJOXiWrIEzxsVNACvjuwgYc,cookies=folqeUbQJOXiWrIEzxsVNACvjuwgYc,redirects=folqeUbQJOXiWrIEzxsVNACvjuwgYR):
  folqeUbQJOXiWrIEzxsVNACvjuwgFY=folqeUbQJOXiWrIEzxsVNACvjuwgFM.DEFAULT_HEADER
  if headers:folqeUbQJOXiWrIEzxsVNACvjuwgFY.update(headers)
  folqeUbQJOXiWrIEzxsVNACvjuwgFm=requests.Request('POST',folqeUbQJOXiWrIEzxsVNACvjuwgdS,headers=headers,data=payload,params=params,cookies=cookies)
  folqeUbQJOXiWrIEzxsVNACvjuwgFa=folqeUbQJOXiWrIEzxsVNACvjuwgFm.prepare()
  folqeUbQJOXiWrIEzxsVNACvjuwgFM.pretty_print_POST(folqeUbQJOXiWrIEzxsVNACvjuwgFa)
  return folqeUbQJOXiWrIEzxsVNACvjuwgFm
 def pretty_print_POST(folqeUbQJOXiWrIEzxsVNACvjuwgFM,req):
  folqeUbQJOXiWrIEzxsVNACvjuwgYD('{}\n{}\r\n{}\r\n\r\n{}'.format('-----------START-----------',req.method+' '+req.url,'\r\n'.join('{}: {}'.format(k,v)for k,v in req.headers.items()),req.body,))
 def dic_To_jsonfile(folqeUbQJOXiWrIEzxsVNACvjuwgFM,filename,folqeUbQJOXiWrIEzxsVNACvjuwgFn):
  if filename=='':return
  fp=folqeUbQJOXiWrIEzxsVNACvjuwgYH(filename,'w',-1,'utf-8')
  json.dump(folqeUbQJOXiWrIEzxsVNACvjuwgFn,fp,indent=4,ensure_ascii=folqeUbQJOXiWrIEzxsVNACvjuwgYR)
  fp.close()
 def jsonfile_To_dic(folqeUbQJOXiWrIEzxsVNACvjuwgFM,filename):
  if filename=='':return folqeUbQJOXiWrIEzxsVNACvjuwgYc
  try:
   fp=folqeUbQJOXiWrIEzxsVNACvjuwgYH(filename,'r',-1,'utf-8')
   folqeUbQJOXiWrIEzxsVNACvjuwgFS=json.load(fp)
   fp.close()
  except:
   folqeUbQJOXiWrIEzxsVNACvjuwgFS={}
  return folqeUbQJOXiWrIEzxsVNACvjuwgFS
 def convert_TimeStr(folqeUbQJOXiWrIEzxsVNACvjuwgFM,folqeUbQJOXiWrIEzxsVNACvjuwgFk):
  try:
   folqeUbQJOXiWrIEzxsVNACvjuwgFk =folqeUbQJOXiWrIEzxsVNACvjuwgFk[0:16]
   folqeUbQJOXiWrIEzxsVNACvjuwgFy=datetime.datetime.strptime(folqeUbQJOXiWrIEzxsVNACvjuwgFk,'%Y-%m-%dT%H:%M')+datetime.timedelta(hours=9)
   return folqeUbQJOXiWrIEzxsVNACvjuwgFy.strftime('%Y-%m-%d %H:%M')
  except:
   return folqeUbQJOXiWrIEzxsVNACvjuwgYc
 def Get_Now_Datetime(folqeUbQJOXiWrIEzxsVNACvjuwgFM):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetNoCache(folqeUbQJOXiWrIEzxsVNACvjuwgFM):
  folqeUbQJOXiWrIEzxsVNACvjuwgFt =folqeUbQJOXiWrIEzxsVNACvjuwgYP(time.time()*1000)
  return folqeUbQJOXiWrIEzxsVNACvjuwgFt
 def generatePcId(folqeUbQJOXiWrIEzxsVNACvjuwgFM):
  t=folqeUbQJOXiWrIEzxsVNACvjuwgFM.GetNoCache()
  r=random.random()
  folqeUbQJOXiWrIEzxsVNACvjuwgFT=folqeUbQJOXiWrIEzxsVNACvjuwgYG(t)+folqeUbQJOXiWrIEzxsVNACvjuwgYG(r)[2:12]
  return folqeUbQJOXiWrIEzxsVNACvjuwgFT
 def generatePvId(folqeUbQJOXiWrIEzxsVNACvjuwgFM,genType='1'):
  import hashlib
  m=hashlib.md5()
  folqeUbQJOXiWrIEzxsVNACvjuwgFh=folqeUbQJOXiWrIEzxsVNACvjuwgYG(random.random())
  m.update(folqeUbQJOXiWrIEzxsVNACvjuwgFh.encode('utf-8'))
  folqeUbQJOXiWrIEzxsVNACvjuwgFc=folqeUbQJOXiWrIEzxsVNACvjuwgYG(m.hexdigest())
  if genType=='1':
   return '%s-%s-%s-%s-%s'%(folqeUbQJOXiWrIEzxsVNACvjuwgFc[:8],folqeUbQJOXiWrIEzxsVNACvjuwgFc[8:12],folqeUbQJOXiWrIEzxsVNACvjuwgFc[12:16],folqeUbQJOXiWrIEzxsVNACvjuwgFc[16:20],folqeUbQJOXiWrIEzxsVNACvjuwgFc[20:])
  else:
   return folqeUbQJOXiWrIEzxsVNACvjuwgFc
 def Get_DeviceID(folqeUbQJOXiWrIEzxsVNACvjuwgFM):
  folqeUbQJOXiWrIEzxsVNACvjuwgFR=''
  try: 
   fp=folqeUbQJOXiWrIEzxsVNACvjuwgYH(folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP_DEVICE_FILENAME,'r',-1,'utf-8')
   folqeUbQJOXiWrIEzxsVNACvjuwgFD= json.load(fp)
   fp.close()
   folqeUbQJOXiWrIEzxsVNACvjuwgFR=folqeUbQJOXiWrIEzxsVNACvjuwgFD.get('device_id')
  except folqeUbQJOXiWrIEzxsVNACvjuwgYB as exception:
   folqeUbQJOXiWrIEzxsVNACvjuwgYc
  if folqeUbQJOXiWrIEzxsVNACvjuwgFR=='':
   folqeUbQJOXiWrIEzxsVNACvjuwgFR=folqeUbQJOXiWrIEzxsVNACvjuwgFM.generatePvId(genType='1')
   try: 
    fp=folqeUbQJOXiWrIEzxsVNACvjuwgYH(folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP_DEVICE_FILENAME,'w',-1,'utf-8')
    json.dump({'device_id':folqeUbQJOXiWrIEzxsVNACvjuwgFR},fp,indent=4,ensure_ascii=folqeUbQJOXiWrIEzxsVNACvjuwgYR)
    fp.close()
   except folqeUbQJOXiWrIEzxsVNACvjuwgYB as exception:
    return ''
  return folqeUbQJOXiWrIEzxsVNACvjuwgFR
 def make_stream_header(folqeUbQJOXiWrIEzxsVNACvjuwgFM,folqeUbQJOXiWrIEzxsVNACvjuwgFL,folqeUbQJOXiWrIEzxsVNACvjuwgdk):
  folqeUbQJOXiWrIEzxsVNACvjuwgFG=''
  if folqeUbQJOXiWrIEzxsVNACvjuwgdk not in[{},folqeUbQJOXiWrIEzxsVNACvjuwgYc,'']:
   folqeUbQJOXiWrIEzxsVNACvjuwgFH=folqeUbQJOXiWrIEzxsVNACvjuwgYL(folqeUbQJOXiWrIEzxsVNACvjuwgdk)
   for folqeUbQJOXiWrIEzxsVNACvjuwgFP,folqeUbQJOXiWrIEzxsVNACvjuwgFB in folqeUbQJOXiWrIEzxsVNACvjuwgdk.items():
    folqeUbQJOXiWrIEzxsVNACvjuwgFG+='{}={}'.format(folqeUbQJOXiWrIEzxsVNACvjuwgFP,folqeUbQJOXiWrIEzxsVNACvjuwgFB)
    folqeUbQJOXiWrIEzxsVNACvjuwgFH+=-1
    if folqeUbQJOXiWrIEzxsVNACvjuwgFH>0:folqeUbQJOXiWrIEzxsVNACvjuwgFG+='; '
   folqeUbQJOXiWrIEzxsVNACvjuwgFL['cookie']=folqeUbQJOXiWrIEzxsVNACvjuwgFG
  folqeUbQJOXiWrIEzxsVNACvjuwgdF=''
  i=0
  for folqeUbQJOXiWrIEzxsVNACvjuwgFP,folqeUbQJOXiWrIEzxsVNACvjuwgFB in folqeUbQJOXiWrIEzxsVNACvjuwgFL.items():
   i=i+1
   if i>1:folqeUbQJOXiWrIEzxsVNACvjuwgdF+='&'
   folqeUbQJOXiWrIEzxsVNACvjuwgdF+='{}={}'.format(folqeUbQJOXiWrIEzxsVNACvjuwgFP,urllib.parse.quote(folqeUbQJOXiWrIEzxsVNACvjuwgFB))
  return folqeUbQJOXiWrIEzxsVNACvjuwgdF
 def Make_authHeader(folqeUbQJOXiWrIEzxsVNACvjuwgFM):
  tr=folqeUbQJOXiWrIEzxsVNACvjuwgFM.generatePvId(genType=2)
  ti=folqeUbQJOXiWrIEzxsVNACvjuwgFM.GetNoCache()
  folqeUbQJOXiWrIEzxsVNACvjuwgmF=folqeUbQJOXiWrIEzxsVNACvjuwgFM.generatePvId(genType=2)[:16]
  folqeUbQJOXiWrIEzxsVNACvjuwgdM='00-%s-%s-01'%(tr,folqeUbQJOXiWrIEzxsVNACvjuwgmF,)
  folqeUbQJOXiWrIEzxsVNACvjuwgdY ='%s@nr=0-1-%s-%s-%s----%s'%(folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['SESSION']['NREUM']['tk'],folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['SESSION']['NREUM']['ac'],folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['SESSION']['NREUM']['ap'],folqeUbQJOXiWrIEzxsVNACvjuwgmF,ti,)
  folqeUbQJOXiWrIEzxsVNACvjuwgdm ='{"v":[0,1],"d":{"ty":"Browser","ac":"%s","ap":"%s","id":"%s","tr":"%s","ti":%s,"tk":"%s"}}'%(folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['SESSION']['NREUM']['ac'],folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['SESSION']['NREUM']['ap'],folqeUbQJOXiWrIEzxsVNACvjuwgmF,tr,ti,folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['SESSION']['NREUM']['tk'],) 
  return folqeUbQJOXiWrIEzxsVNACvjuwgdM,folqeUbQJOXiWrIEzxsVNACvjuwgdY,base64.standard_b64encode(folqeUbQJOXiWrIEzxsVNACvjuwgdm.encode()).decode('utf-8')
 def Init_CP(folqeUbQJOXiWrIEzxsVNACvjuwgFM):
  folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP={}
  folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['ACCOUNT']={'cpid':'','cppw':'','cppf':'0'}
  folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['SESSION']={}
  folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['COOKIES']={}
 def Save_session_acount(folqeUbQJOXiWrIEzxsVNACvjuwgFM,folqeUbQJOXiWrIEzxsVNACvjuwgda,folqeUbQJOXiWrIEzxsVNACvjuwgdn,folqeUbQJOXiWrIEzxsVNACvjuwgdp):
  folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['ACCOUNT']['cpid']=base64.standard_b64encode(folqeUbQJOXiWrIEzxsVNACvjuwgda.encode()).decode('utf-8')
  folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['ACCOUNT']['cppw']=base64.standard_b64encode(folqeUbQJOXiWrIEzxsVNACvjuwgdn.encode()).decode('utf-8')
  folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['ACCOUNT']['cppf']=folqeUbQJOXiWrIEzxsVNACvjuwgYG(folqeUbQJOXiWrIEzxsVNACvjuwgdp)
 def Load_session_acount(folqeUbQJOXiWrIEzxsVNACvjuwgFM):
  folqeUbQJOXiWrIEzxsVNACvjuwgda=base64.standard_b64decode(folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['ACCOUNT']['cpid']).decode('utf-8')
  folqeUbQJOXiWrIEzxsVNACvjuwgdn=base64.standard_b64decode(folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['ACCOUNT']['cppw']).decode('utf-8')
  folqeUbQJOXiWrIEzxsVNACvjuwgdp=folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['ACCOUNT']['cppf']
  return folqeUbQJOXiWrIEzxsVNACvjuwgda,folqeUbQJOXiWrIEzxsVNACvjuwgdn,folqeUbQJOXiWrIEzxsVNACvjuwgdp
 def make_CP_DefaultCookies(folqeUbQJOXiWrIEzxsVNACvjuwgFM):
  return folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['COOKIES']
 def Get_CP_Login(folqeUbQJOXiWrIEzxsVNACvjuwgFM,userid,userpw,folqeUbQJOXiWrIEzxsVNACvjuwgdG):
  try:
   folqeUbQJOXiWrIEzxsVNACvjuwgdS=folqeUbQJOXiWrIEzxsVNACvjuwgFM.API_DOMAIN
   folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['COOKIES']['NEXT_LOCALE']='ko'
   folqeUbQJOXiWrIEzxsVNACvjuwgFL={'Accept-Language':'ko-KR,ko;q=0.9','Sec-Ch-Ua-Mobile':'?0','Sec-Ch-Ua-Platform':'"Windows"','Sec-Fetch-Dest':'document','Sec-Fetch-Mode':'navigate','Sec-Fetch-Site':'none','Sec-Fetch-User':'?1','Upgrade-Insecure-Requests':'1',}
   folqeUbQJOXiWrIEzxsVNACvjuwgdk=folqeUbQJOXiWrIEzxsVNACvjuwgFM.make_CP_DefaultCookies()
   folqeUbQJOXiWrIEzxsVNACvjuwgdy=folqeUbQJOXiWrIEzxsVNACvjuwgFM.callRequestCookies('Get',folqeUbQJOXiWrIEzxsVNACvjuwgdS,payload=folqeUbQJOXiWrIEzxsVNACvjuwgYc,params=folqeUbQJOXiWrIEzxsVNACvjuwgYc,headers=folqeUbQJOXiWrIEzxsVNACvjuwgFL,cookies=folqeUbQJOXiWrIEzxsVNACvjuwgdk,redirects=folqeUbQJOXiWrIEzxsVNACvjuwgmd)
   if folqeUbQJOXiWrIEzxsVNACvjuwgdy.status_code not in[200]:return folqeUbQJOXiWrIEzxsVNACvjuwgYR
   for folqeUbQJOXiWrIEzxsVNACvjuwgdK in folqeUbQJOXiWrIEzxsVNACvjuwgdy.cookies:
    folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['COOKIES'][folqeUbQJOXiWrIEzxsVNACvjuwgdK.name]=folqeUbQJOXiWrIEzxsVNACvjuwgdK.value
   folqeUbQJOXiWrIEzxsVNACvjuwgdk=folqeUbQJOXiWrIEzxsVNACvjuwgFM.make_CP_DefaultCookies()
   if folqeUbQJOXiWrIEzxsVNACvjuwgdy.status_code not in[200]:return folqeUbQJOXiWrIEzxsVNACvjuwgYR
   folqeUbQJOXiWrIEzxsVNACvjuwgdt=re.findall('NREUM.loader_config=\{[\w\d\":,-]+\}',folqeUbQJOXiWrIEzxsVNACvjuwgdy.text)[0].split('=')[1]
   folqeUbQJOXiWrIEzxsVNACvjuwgdt=folqeUbQJOXiWrIEzxsVNACvjuwgdt.replace('{','{"').replace(':','":').replace(',',',"')
   folqeUbQJOXiWrIEzxsVNACvjuwgdt=json.loads(folqeUbQJOXiWrIEzxsVNACvjuwgdt)
   folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['SESSION']['NREUM']={'ac':folqeUbQJOXiWrIEzxsVNACvjuwgdt['accountID'],'tk':folqeUbQJOXiWrIEzxsVNACvjuwgdt['trustKey'],'ap':folqeUbQJOXiWrIEzxsVNACvjuwgdt['agentID'],'lk':folqeUbQJOXiWrIEzxsVNACvjuwgdt['licenseKey'],}
  except folqeUbQJOXiWrIEzxsVNACvjuwgYB as exception:
   folqeUbQJOXiWrIEzxsVNACvjuwgYD(exception)
   return folqeUbQJOXiWrIEzxsVNACvjuwgYR
  try:
   folqeUbQJOXiWrIEzxsVNACvjuwgdS=folqeUbQJOXiWrIEzxsVNACvjuwgFM.API_DOMAIN+'/api/auth'
   folqeUbQJOXiWrIEzxsVNACvjuwgdT=folqeUbQJOXiWrIEzxsVNACvjuwgFM.Get_DeviceID()
   folqeUbQJOXiWrIEzxsVNACvjuwgdh =folqeUbQJOXiWrIEzxsVNACvjuwgdT.split('-')[0]
   folqeUbQJOXiWrIEzxsVNACvjuwgdM,folqeUbQJOXiWrIEzxsVNACvjuwgdY,folqeUbQJOXiWrIEzxsVNACvjuwgdm=folqeUbQJOXiWrIEzxsVNACvjuwgFM.Make_authHeader()
   folqeUbQJOXiWrIEzxsVNACvjuwgFL={'traceparent':folqeUbQJOXiWrIEzxsVNACvjuwgdM,'tracestate':folqeUbQJOXiWrIEzxsVNACvjuwgdY,'newrelic':folqeUbQJOXiWrIEzxsVNACvjuwgdm,'content-type':'application/json','x-app-version':'1.26.1','x-device-id':'','x-device-os-version':folqeUbQJOXiWrIEzxsVNACvjuwgFM.OS_VERSION,'x-nr-session-id':folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['COOKIES']['session_web_id'],'x-pcid':'',}
   folqeUbQJOXiWrIEzxsVNACvjuwgdc={'device':{'deviceId':'web-'+folqeUbQJOXiWrIEzxsVNACvjuwgdT,'model':folqeUbQJOXiWrIEzxsVNACvjuwgFM.MODEL,'name':'Chrome Desktop '+folqeUbQJOXiWrIEzxsVNACvjuwgdh,'os':'Windows','osVersion':'10','type':'webclient',},'email':userid,'password':userpw,}
   folqeUbQJOXiWrIEzxsVNACvjuwgdc=json.dumps(folqeUbQJOXiWrIEzxsVNACvjuwgdc,separators=(',',':'))
   folqeUbQJOXiWrIEzxsVNACvjuwgdk=folqeUbQJOXiWrIEzxsVNACvjuwgFM.make_CP_DefaultCookies()
   folqeUbQJOXiWrIEzxsVNACvjuwgdy=folqeUbQJOXiWrIEzxsVNACvjuwgFM.callRequestCookies('Post',folqeUbQJOXiWrIEzxsVNACvjuwgdS,payload=folqeUbQJOXiWrIEzxsVNACvjuwgdc,params=folqeUbQJOXiWrIEzxsVNACvjuwgYc,headers=folqeUbQJOXiWrIEzxsVNACvjuwgFL,cookies=folqeUbQJOXiWrIEzxsVNACvjuwgdk,redirects=folqeUbQJOXiWrIEzxsVNACvjuwgYR)
   if folqeUbQJOXiWrIEzxsVNACvjuwgdy.status_code not in[200]:
    folqeUbQJOXiWrIEzxsVNACvjuwgdR=json.loads(folqeUbQJOXiWrIEzxsVNACvjuwgdy.text)
    if 'error' in folqeUbQJOXiWrIEzxsVNACvjuwgdR:
     folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['SESSION']['error']=folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('error').get('detail')
    return folqeUbQJOXiWrIEzxsVNACvjuwgYR
   folqeUbQJOXiWrIEzxsVNACvjuwgYD('---')
   for folqeUbQJOXiWrIEzxsVNACvjuwgdK in folqeUbQJOXiWrIEzxsVNACvjuwgdy.cookies:
    folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['COOKIES'][folqeUbQJOXiWrIEzxsVNACvjuwgdK.name]=folqeUbQJOXiWrIEzxsVNACvjuwgdK.value
  except folqeUbQJOXiWrIEzxsVNACvjuwgYB as exception:
   folqeUbQJOXiWrIEzxsVNACvjuwgYD(exception)
   return folqeUbQJOXiWrIEzxsVNACvjuwgYR
  folqeUbQJOXiWrIEzxsVNACvjuwgFM.Save_session_acount(userid,userpw,folqeUbQJOXiWrIEzxsVNACvjuwgdG)
  return folqeUbQJOXiWrIEzxsVNACvjuwgmd
 def Get_CP_profile(folqeUbQJOXiWrIEzxsVNACvjuwgFM,folqeUbQJOXiWrIEzxsVNACvjuwgdG,limit_days=1,re_check=folqeUbQJOXiWrIEzxsVNACvjuwgYR):
  if re_check==folqeUbQJOXiWrIEzxsVNACvjuwgmd:
   if folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['SESSION']['bm_sv_ex']>folqeUbQJOXiWrIEzxsVNACvjuwgYP(time.time()):
    folqeUbQJOXiWrIEzxsVNACvjuwgYD('bm_sv_ex ok')
    return folqeUbQJOXiWrIEzxsVNACvjuwgmd
  try:
   folqeUbQJOXiWrIEzxsVNACvjuwgdS=folqeUbQJOXiWrIEzxsVNACvjuwgFM.API_DOMAIN+'/api/profiles'
   folqeUbQJOXiWrIEzxsVNACvjuwgdM,folqeUbQJOXiWrIEzxsVNACvjuwgdY,folqeUbQJOXiWrIEzxsVNACvjuwgdm=folqeUbQJOXiWrIEzxsVNACvjuwgFM.Make_authHeader()
   folqeUbQJOXiWrIEzxsVNACvjuwgFL={'traceparent':folqeUbQJOXiWrIEzxsVNACvjuwgdM,'tracestate':folqeUbQJOXiWrIEzxsVNACvjuwgdY,'newrelic':folqeUbQJOXiWrIEzxsVNACvjuwgdm,'x-app-version':'1.26.1','x-device-id':'','x-device-os-version':folqeUbQJOXiWrIEzxsVNACvjuwgFM.OS_VERSION,'x-nr-session-id':folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['COOKIES']['session_web_id'],'x-pcid':'',}
   folqeUbQJOXiWrIEzxsVNACvjuwgdk=folqeUbQJOXiWrIEzxsVNACvjuwgFM.make_CP_DefaultCookies()
   folqeUbQJOXiWrIEzxsVNACvjuwgdy=folqeUbQJOXiWrIEzxsVNACvjuwgFM.callRequestCookies('Get',folqeUbQJOXiWrIEzxsVNACvjuwgdS,payload=folqeUbQJOXiWrIEzxsVNACvjuwgYc,params=folqeUbQJOXiWrIEzxsVNACvjuwgYc,headers=folqeUbQJOXiWrIEzxsVNACvjuwgFL,cookies=folqeUbQJOXiWrIEzxsVNACvjuwgdk,redirects=folqeUbQJOXiWrIEzxsVNACvjuwgmd)
   if folqeUbQJOXiWrIEzxsVNACvjuwgdy.status_code not in[200]:return folqeUbQJOXiWrIEzxsVNACvjuwgYR
   folqeUbQJOXiWrIEzxsVNACvjuwgdR=json.loads(folqeUbQJOXiWrIEzxsVNACvjuwgdy.text)
   folqeUbQJOXiWrIEzxsVNACvjuwgdD=0
   for folqeUbQJOXiWrIEzxsVNACvjuwgdK in folqeUbQJOXiWrIEzxsVNACvjuwgdy.cookies:
    folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['COOKIES'][folqeUbQJOXiWrIEzxsVNACvjuwgdK.name]=folqeUbQJOXiWrIEzxsVNACvjuwgdK.value
    if folqeUbQJOXiWrIEzxsVNACvjuwgdK.name=='bm_sv':
     folqeUbQJOXiWrIEzxsVNACvjuwgdD=1
     folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['SESSION']['bm_sv_ex']=folqeUbQJOXiWrIEzxsVNACvjuwgdK.expires 
   if folqeUbQJOXiWrIEzxsVNACvjuwgdD==0:
    folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['SESSION']['bm_sv_ex']=folqeUbQJOXiWrIEzxsVNACvjuwgYP(time.time())+60*60*2 
   folqeUbQJOXiWrIEzxsVNACvjuwgdG=folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('data')[folqeUbQJOXiWrIEzxsVNACvjuwgYP(folqeUbQJOXiWrIEzxsVNACvjuwgdG)]
   folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['SESSION']['accountId']=folqeUbQJOXiWrIEzxsVNACvjuwgdG.get('accountId')
   folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['SESSION']['profileId']=folqeUbQJOXiWrIEzxsVNACvjuwgdG.get('profileId')
  except folqeUbQJOXiWrIEzxsVNACvjuwgYB as exception:
   folqeUbQJOXiWrIEzxsVNACvjuwgYD(exception)
   return folqeUbQJOXiWrIEzxsVNACvjuwgYR
  if re_check==folqeUbQJOXiWrIEzxsVNACvjuwgYR:
   folqeUbQJOXiWrIEzxsVNACvjuwgdH =folqeUbQJOXiWrIEzxsVNACvjuwgFM.Get_Now_Datetime()
   folqeUbQJOXiWrIEzxsVNACvjuwgdP=folqeUbQJOXiWrIEzxsVNACvjuwgdH+datetime.timedelta(days=limit_days)
   folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['SESSION']['limitdate']=folqeUbQJOXiWrIEzxsVNACvjuwgdP.strftime('%Y-%m-%d')
  else:
   folqeUbQJOXiWrIEzxsVNACvjuwgYD('re check')
  folqeUbQJOXiWrIEzxsVNACvjuwgFM.dic_To_jsonfile(folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP_COOKIE_FILENAME,folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP)
  return folqeUbQJOXiWrIEzxsVNACvjuwgmd
 def Get_Category_GroupList(folqeUbQJOXiWrIEzxsVNACvjuwgFM,vType):
  folqeUbQJOXiWrIEzxsVNACvjuwgdB=[] 
  try:
   folqeUbQJOXiWrIEzxsVNACvjuwgdS=folqeUbQJOXiWrIEzxsVNACvjuwgFM.API_VIEWURL+'/v3/discover/feed' 
   folqeUbQJOXiWrIEzxsVNACvjuwgdL={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':folqeUbQJOXiWrIEzxsVNACvjuwgYR,'preferRecoFeed':folqeUbQJOXiWrIEzxsVNACvjuwgmd,'preferMultiHeroMixedContentRow':folqeUbQJOXiWrIEzxsVNACvjuwgmd,'shouldIncludeTVOD':folqeUbQJOXiWrIEzxsVNACvjuwgmd,'includeChannelContents':folqeUbQJOXiWrIEzxsVNACvjuwgYR,}
   folqeUbQJOXiWrIEzxsVNACvjuwgdy=folqeUbQJOXiWrIEzxsVNACvjuwgFM.callRequestCookies('Get',folqeUbQJOXiWrIEzxsVNACvjuwgdS,payload=folqeUbQJOXiWrIEzxsVNACvjuwgYc,params=folqeUbQJOXiWrIEzxsVNACvjuwgdL,headers=folqeUbQJOXiWrIEzxsVNACvjuwgYc,cookies=folqeUbQJOXiWrIEzxsVNACvjuwgYc,redirects=folqeUbQJOXiWrIEzxsVNACvjuwgmd)
   if folqeUbQJOXiWrIEzxsVNACvjuwgdy.status_code not in[200]:return[]
   folqeUbQJOXiWrIEzxsVNACvjuwgdR=json.loads(folqeUbQJOXiWrIEzxsVNACvjuwgdy.text)
   if vType in['TVSHOWS','MOVIES']:
    folqeUbQJOXiWrIEzxsVNACvjuwgMF='Explores' 
   elif vType in['EDUCATION']:
    folqeUbQJOXiWrIEzxsVNACvjuwgMF='Collection-Rails-Curation'
   elif vType in['ALL','KIDS']:
    folqeUbQJOXiWrIEzxsVNACvjuwgMF='Explores-Categories'
   for folqeUbQJOXiWrIEzxsVNACvjuwgMd in folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('data'):
    if folqeUbQJOXiWrIEzxsVNACvjuwgMd.get('type')==folqeUbQJOXiWrIEzxsVNACvjuwgMF:
     for folqeUbQJOXiWrIEzxsVNACvjuwgMY in folqeUbQJOXiWrIEzxsVNACvjuwgMd.get('data'):
      if vType in['TVSHOWS','MOVIES']:
       folqeUbQJOXiWrIEzxsVNACvjuwgMm=folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('collectionId')
      elif vType in['EDUCATION','ALL','KIDS']:
       folqeUbQJOXiWrIEzxsVNACvjuwgMm=folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('id')
      folqeUbQJOXiWrIEzxsVNACvjuwgMa={'collectionId':folqeUbQJOXiWrIEzxsVNACvjuwgMm,'title':folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('name'),'category':folqeUbQJOXiWrIEzxsVNACvjuwgMd.get('category'),'pre_title':'',}
      folqeUbQJOXiWrIEzxsVNACvjuwgdB.append(folqeUbQJOXiWrIEzxsVNACvjuwgMa)
     break
  except folqeUbQJOXiWrIEzxsVNACvjuwgYB as exception:
   folqeUbQJOXiWrIEzxsVNACvjuwgYD(exception)
   return[]
  return folqeUbQJOXiWrIEzxsVNACvjuwgdB
 def Get_Category_List(folqeUbQJOXiWrIEzxsVNACvjuwgFM,vType,folqeUbQJOXiWrIEzxsVNACvjuwgMm,page_int):
  folqeUbQJOXiWrIEzxsVNACvjuwgdB=[] 
  folqeUbQJOXiWrIEzxsVNACvjuwgMn=folqeUbQJOXiWrIEzxsVNACvjuwgYR
  try:
   if vType in['ALL','KIDS']:
    folqeUbQJOXiWrIEzxsVNACvjuwgFL={'x-membersrl':folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['COOKIES']['member_srl'],'x-pcid':folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['COOKIES']['PCID'],'x-profileid':folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['SESSION']['profileId'],}
    folqeUbQJOXiWrIEzxsVNACvjuwgdL={'platform':'WEBCLIENT','page':folqeUbQJOXiWrIEzxsVNACvjuwgYG(page_int),'perPage':folqeUbQJOXiWrIEzxsVNACvjuwgYG(folqeUbQJOXiWrIEzxsVNACvjuwgFM.PAGE_LIMIT),'locale':'ko','sort':'',}
    folqeUbQJOXiWrIEzxsVNACvjuwgdS=folqeUbQJOXiWrIEzxsVNACvjuwgFM.API_VIEWURL+'/v1/discover/categories/'+folqeUbQJOXiWrIEzxsVNACvjuwgMm+'/titles'
    folqeUbQJOXiWrIEzxsVNACvjuwgdy=folqeUbQJOXiWrIEzxsVNACvjuwgFM.callRequestCookies('Get',folqeUbQJOXiWrIEzxsVNACvjuwgdS,payload=folqeUbQJOXiWrIEzxsVNACvjuwgYc,params=folqeUbQJOXiWrIEzxsVNACvjuwgdL,headers=folqeUbQJOXiWrIEzxsVNACvjuwgFL,cookies=folqeUbQJOXiWrIEzxsVNACvjuwgYc,redirects=folqeUbQJOXiWrIEzxsVNACvjuwgmd)
   else: 
    folqeUbQJOXiWrIEzxsVNACvjuwgdL={'platform':'WEBCLIENT','page':folqeUbQJOXiWrIEzxsVNACvjuwgYG(page_int),'perPage':folqeUbQJOXiWrIEzxsVNACvjuwgYG(folqeUbQJOXiWrIEzxsVNACvjuwgFM.PAGE_LIMIT),}
    folqeUbQJOXiWrIEzxsVNACvjuwgdS=folqeUbQJOXiWrIEzxsVNACvjuwgFM.API_VIEWURL+'/v1/discover/collections/'+folqeUbQJOXiWrIEzxsVNACvjuwgMm+'/titles'
    folqeUbQJOXiWrIEzxsVNACvjuwgdy=folqeUbQJOXiWrIEzxsVNACvjuwgFM.callRequestCookies('Get',folqeUbQJOXiWrIEzxsVNACvjuwgdS,payload=folqeUbQJOXiWrIEzxsVNACvjuwgYc,params=folqeUbQJOXiWrIEzxsVNACvjuwgdL,headers=folqeUbQJOXiWrIEzxsVNACvjuwgYc,cookies=folqeUbQJOXiWrIEzxsVNACvjuwgYc,redirects=folqeUbQJOXiWrIEzxsVNACvjuwgmd)
   if folqeUbQJOXiWrIEzxsVNACvjuwgdy.status_code not in[200]:return[],folqeUbQJOXiWrIEzxsVNACvjuwgYR
   folqeUbQJOXiWrIEzxsVNACvjuwgdR=json.loads(folqeUbQJOXiWrIEzxsVNACvjuwgdy.text)
   if vType in['ALL','KIDS']:
    folqeUbQJOXiWrIEzxsVNACvjuwgMp=folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('data').get('data')
   else:
    folqeUbQJOXiWrIEzxsVNACvjuwgMp=folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('data')
   for folqeUbQJOXiWrIEzxsVNACvjuwgMY in folqeUbQJOXiWrIEzxsVNACvjuwgMp:
    folqeUbQJOXiWrIEzxsVNACvjuwgMS=folqeUbQJOXiWrIEzxsVNACvjuwgMT=folqeUbQJOXiWrIEzxsVNACvjuwgYy=folqeUbQJOXiWrIEzxsVNACvjuwgYk=''
    if 'poster' in folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('images'):folqeUbQJOXiWrIEzxsVNACvjuwgMS =folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('images'):folqeUbQJOXiWrIEzxsVNACvjuwgMT =folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('images').get('story-art').get('url') +'?imwidth=600'
    if 'title-treatment' in folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('images'):folqeUbQJOXiWrIEzxsVNACvjuwgYy=folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('images').get('title-treatment').get('url')+'?imwidth=300'
    if 'story-art' in folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('images'):folqeUbQJOXiWrIEzxsVNACvjuwgYk =folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('images').get('story-art').get('url') +'?imwidth=600'
    folqeUbQJOXiWrIEzxsVNACvjuwgMk=''
    if folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('badge')not in[{},folqeUbQJOXiWrIEzxsVNACvjuwgYc]:
     for i in folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('badge').get('text'):
      folqeUbQJOXiWrIEzxsVNACvjuwgMk+=i.get('text')
    folqeUbQJOXiWrIEzxsVNACvjuwgMy=''
    if folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('seasonList')!=folqeUbQJOXiWrIEzxsVNACvjuwgYc:
     folqeUbQJOXiWrIEzxsVNACvjuwgMy=','.join(folqeUbQJOXiWrIEzxsVNACvjuwgYG(e)for e in folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('seasonList'))
    folqeUbQJOXiWrIEzxsVNACvjuwgMK =[]
    for folqeUbQJOXiWrIEzxsVNACvjuwgMt in folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('tags'):
     folqeUbQJOXiWrIEzxsVNACvjuwgMK.append(folqeUbQJOXiWrIEzxsVNACvjuwgMt.get('tag'))
    folqeUbQJOXiWrIEzxsVNACvjuwgMa={'id':folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('id'),'title':folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('title'),'thumbnail':{'poster':folqeUbQJOXiWrIEzxsVNACvjuwgMS,'thumb':folqeUbQJOXiWrIEzxsVNACvjuwgMT,'clearlogo':folqeUbQJOXiWrIEzxsVNACvjuwgYy,'fanart':folqeUbQJOXiWrIEzxsVNACvjuwgYk},'mpaa':folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('age_rating'),'duration':folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('running_time'),'asis':folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('as'),'badge':folqeUbQJOXiWrIEzxsVNACvjuwgMk,'year':folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('meta').get('releaseYear'),'seasonList':folqeUbQJOXiWrIEzxsVNACvjuwgMy,'genreList':folqeUbQJOXiWrIEzxsVNACvjuwgMK,}
    folqeUbQJOXiWrIEzxsVNACvjuwgdB.append(folqeUbQJOXiWrIEzxsVNACvjuwgMa)
   if folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('pagination').get('totalPages')>page_int:
    folqeUbQJOXiWrIEzxsVNACvjuwgMn=folqeUbQJOXiWrIEzxsVNACvjuwgmd
  except folqeUbQJOXiWrIEzxsVNACvjuwgYB as exception:
   folqeUbQJOXiWrIEzxsVNACvjuwgYD(exception)
   return[],folqeUbQJOXiWrIEzxsVNACvjuwgYR
  return folqeUbQJOXiWrIEzxsVNACvjuwgdB,folqeUbQJOXiWrIEzxsVNACvjuwgMn
 def Get_Episode_List(folqeUbQJOXiWrIEzxsVNACvjuwgFM,programId,season):
  folqeUbQJOXiWrIEzxsVNACvjuwgdB=[] 
  try:
   folqeUbQJOXiWrIEzxsVNACvjuwgdS=folqeUbQJOXiWrIEzxsVNACvjuwgFM.API_VIEWURL+'/v1/discover/titles/'+programId+'/episodes'
   folqeUbQJOXiWrIEzxsVNACvjuwgdL={'season':season,'sort':'true','locale':'ko',}
   folqeUbQJOXiWrIEzxsVNACvjuwgdy=folqeUbQJOXiWrIEzxsVNACvjuwgFM.callRequestCookies('Get',folqeUbQJOXiWrIEzxsVNACvjuwgdS,payload=folqeUbQJOXiWrIEzxsVNACvjuwgYc,params=folqeUbQJOXiWrIEzxsVNACvjuwgdL,headers=folqeUbQJOXiWrIEzxsVNACvjuwgYc,cookies=folqeUbQJOXiWrIEzxsVNACvjuwgYc,redirects=folqeUbQJOXiWrIEzxsVNACvjuwgmd)
   if folqeUbQJOXiWrIEzxsVNACvjuwgdy.status_code not in[200]:return[]
   folqeUbQJOXiWrIEzxsVNACvjuwgdR=json.loads(folqeUbQJOXiWrIEzxsVNACvjuwgdy.text)
   for folqeUbQJOXiWrIEzxsVNACvjuwgMY in folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('data'):
    folqeUbQJOXiWrIEzxsVNACvjuwgMT=''
    if 'story-art' in folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('images'):folqeUbQJOXiWrIEzxsVNACvjuwgMT =folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('images').get('story-art').get('url')+'?imwidth=600'
    folqeUbQJOXiWrIEzxsVNACvjuwgMK =[]
    for folqeUbQJOXiWrIEzxsVNACvjuwgMt in folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('tags'):
     folqeUbQJOXiWrIEzxsVNACvjuwgMK.append(folqeUbQJOXiWrIEzxsVNACvjuwgMt.get('tag'))
    folqeUbQJOXiWrIEzxsVNACvjuwgMa={'id':folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('id'),'title':folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('title'),'thumbnail':{'thumb':folqeUbQJOXiWrIEzxsVNACvjuwgMT,'fanart':folqeUbQJOXiWrIEzxsVNACvjuwgMT},'mpaa':folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('age_rating'),'duration':folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('running_time'),'asis':folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('as'),'year':folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('meta').get('releaseYear'),'episode':folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('episode'),'genreList':folqeUbQJOXiWrIEzxsVNACvjuwgMK,'desc':folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('description'),}
    folqeUbQJOXiWrIEzxsVNACvjuwgdB.append(folqeUbQJOXiWrIEzxsVNACvjuwgMa)
  except folqeUbQJOXiWrIEzxsVNACvjuwgYB as exception:
   folqeUbQJOXiWrIEzxsVNACvjuwgYD(exception)
   return[]
  return folqeUbQJOXiWrIEzxsVNACvjuwgdB
 def Get_vInfo(folqeUbQJOXiWrIEzxsVNACvjuwgFM,titleId):
  try:
   folqeUbQJOXiWrIEzxsVNACvjuwgdS=folqeUbQJOXiWrIEzxsVNACvjuwgFM.API_VIEWURL+'/v1/discover/titles/'+titleId 
   folqeUbQJOXiWrIEzxsVNACvjuwgdL={'platform':'WEBCLIENT','locale':'ko','filterRestrictedContent':'false',}
   folqeUbQJOXiWrIEzxsVNACvjuwgdy=folqeUbQJOXiWrIEzxsVNACvjuwgFM.callRequestCookies('Get',folqeUbQJOXiWrIEzxsVNACvjuwgdS,payload=folqeUbQJOXiWrIEzxsVNACvjuwgYc,params=folqeUbQJOXiWrIEzxsVNACvjuwgdL,headers=folqeUbQJOXiWrIEzxsVNACvjuwgYc,cookies=folqeUbQJOXiWrIEzxsVNACvjuwgYc,redirects=folqeUbQJOXiWrIEzxsVNACvjuwgmd)
   if folqeUbQJOXiWrIEzxsVNACvjuwgdy.status_code not in[200]:return '','',''
   folqeUbQJOXiWrIEzxsVNACvjuwgdR=json.loads(folqeUbQJOXiWrIEzxsVNACvjuwgdy.text).get('data')
   folqeUbQJOXiWrIEzxsVNACvjuwgMy=''
   if folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('seasonList')!=folqeUbQJOXiWrIEzxsVNACvjuwgYc:
    folqeUbQJOXiWrIEzxsVNACvjuwgMy=','.join(folqeUbQJOXiWrIEzxsVNACvjuwgYG(e)for e in folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('seasonList'))
   folqeUbQJOXiWrIEzxsVNACvjuwgMh={'age_rating':folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('age_rating'),'asset_id':folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('asset_id'),'availability':folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('availability'),'deal_id':folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('deal_id'),'downloadable':'true' if folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('downloadable')else 'false','region':folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('region'),'streamable':'true' if folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('streamable')else 'false','asis':folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('as'),'seasonList':folqeUbQJOXiWrIEzxsVNACvjuwgMy}
  except folqeUbQJOXiWrIEzxsVNACvjuwgYB as exception:
   folqeUbQJOXiWrIEzxsVNACvjuwgYD(exception)
   return{}
  return folqeUbQJOXiWrIEzxsVNACvjuwgMh
 def Get_eInfo(folqeUbQJOXiWrIEzxsVNACvjuwgFM,eventId):
  try:
   folqeUbQJOXiWrIEzxsVNACvjuwgdS=folqeUbQJOXiWrIEzxsVNACvjuwgFM.API_VIEWURL+'/v1/discover/events/'+eventId 
   folqeUbQJOXiWrIEzxsVNACvjuwgdL={'locale':'ko'}
   folqeUbQJOXiWrIEzxsVNACvjuwgdy=folqeUbQJOXiWrIEzxsVNACvjuwgFM.callRequestCookies('Get',folqeUbQJOXiWrIEzxsVNACvjuwgdS,payload=folqeUbQJOXiWrIEzxsVNACvjuwgYc,params=folqeUbQJOXiWrIEzxsVNACvjuwgdL,headers=folqeUbQJOXiWrIEzxsVNACvjuwgYc,cookies=folqeUbQJOXiWrIEzxsVNACvjuwgYc,redirects=folqeUbQJOXiWrIEzxsVNACvjuwgmd)
   if folqeUbQJOXiWrIEzxsVNACvjuwgdy.status_code not in[200]:return '','',''
   folqeUbQJOXiWrIEzxsVNACvjuwgdR=json.loads(folqeUbQJOXiWrIEzxsVNACvjuwgdy.text).get('data')
   folqeUbQJOXiWrIEzxsVNACvjuwgMh={'asset_id':folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('asset_id'),'deal_id':folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('deal_id'),'region':folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('region'),'streamable':'true' if folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('streamable')else 'false',}
  except folqeUbQJOXiWrIEzxsVNACvjuwgYB as exception:
   folqeUbQJOXiWrIEzxsVNACvjuwgYD(exception)
   return{}
  return folqeUbQJOXiWrIEzxsVNACvjuwgMh
 def GetBroadURL(folqeUbQJOXiWrIEzxsVNACvjuwgFM,titleId):
  folqeUbQJOXiWrIEzxsVNACvjuwgMc=''
  folqeUbQJOXiWrIEzxsVNACvjuwgMR =''
  folqeUbQJOXiWrIEzxsVNACvjuwgMh=folqeUbQJOXiWrIEzxsVNACvjuwgFM.Get_vInfo(titleId)
  if folqeUbQJOXiWrIEzxsVNACvjuwgMh=={}:return '',''
  try:
   folqeUbQJOXiWrIEzxsVNACvjuwgdS=folqeUbQJOXiWrIEzxsVNACvjuwgFM.API_DOMAIN+'/api/playback/play' 
   folqeUbQJOXiWrIEzxsVNACvjuwgdL={'titleId':titleId}
   folqeUbQJOXiWrIEzxsVNACvjuwgdM,folqeUbQJOXiWrIEzxsVNACvjuwgdY,folqeUbQJOXiWrIEzxsVNACvjuwgdm=folqeUbQJOXiWrIEzxsVNACvjuwgFM.Make_authHeader()
   folqeUbQJOXiWrIEzxsVNACvjuwgFL={'traceparent':folqeUbQJOXiWrIEzxsVNACvjuwgdM,'tracestate':folqeUbQJOXiWrIEzxsVNACvjuwgdY,'newrelic':folqeUbQJOXiWrIEzxsVNACvjuwgdm,'x-drm':'com.microsoft.playready','x-app-version':'1.33.5','x-device-id':'','x-device-os-version':folqeUbQJOXiWrIEzxsVNACvjuwgFM.OS_VERSION,'x-force-raw':'true','x-nr-session-id':folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['COOKIES']['session_web_id'],'x-pcid':folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['COOKIES']['PCID'],'x-platform':'web','x-profileId':folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['SESSION']['profileId'],'x-profileType':'standard','x-sessionid':folqeUbQJOXiWrIEzxsVNACvjuwgFM.generatePvId(genType='1'),'x-title-age-rating':folqeUbQJOXiWrIEzxsVNACvjuwgMh.get('age_rating'),'x-title-availability':folqeUbQJOXiWrIEzxsVNACvjuwgMh.get('availability'),'x-title-brightcove-id':folqeUbQJOXiWrIEzxsVNACvjuwgMh.get('asset_id'),'x-title-deal-id':folqeUbQJOXiWrIEzxsVNACvjuwgMh.get('deal_id'),'x-title-downloadable':folqeUbQJOXiWrIEzxsVNACvjuwgMh.get('downloadable'),'x-title-region':folqeUbQJOXiWrIEzxsVNACvjuwgMh.get('region'),'x-title-streamable':folqeUbQJOXiWrIEzxsVNACvjuwgMh.get('streamable'),}
   folqeUbQJOXiWrIEzxsVNACvjuwgdk=folqeUbQJOXiWrIEzxsVNACvjuwgFM.make_CP_DefaultCookies()
   folqeUbQJOXiWrIEzxsVNACvjuwgdy=folqeUbQJOXiWrIEzxsVNACvjuwgFM.callRequestCookies('Get',folqeUbQJOXiWrIEzxsVNACvjuwgdS,payload=folqeUbQJOXiWrIEzxsVNACvjuwgYc,params=folqeUbQJOXiWrIEzxsVNACvjuwgdL,headers=folqeUbQJOXiWrIEzxsVNACvjuwgFL,cookies=folqeUbQJOXiWrIEzxsVNACvjuwgdk,redirects=folqeUbQJOXiWrIEzxsVNACvjuwgmd)
   if folqeUbQJOXiWrIEzxsVNACvjuwgdy.status_code not in[200]:return '',json.loads(folqeUbQJOXiWrIEzxsVNACvjuwgdy.text).get('error').get('detail')
   folqeUbQJOXiWrIEzxsVNACvjuwgdR=json.loads(folqeUbQJOXiWrIEzxsVNACvjuwgdy.text)
   if folqeUbQJOXiWrIEzxsVNACvjuwgMc=='':
    for folqeUbQJOXiWrIEzxsVNACvjuwgMY in folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('data').get('raw').get('sources'):
     if 'key_systems' in folqeUbQJOXiWrIEzxsVNACvjuwgMY and 'codecs' not in folqeUbQJOXiWrIEzxsVNACvjuwgMY:
      if folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('type')=='application/dash+xml' and 'com.widevine.alpha' in folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('key_systems')and folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('src').startswith('https://')==folqeUbQJOXiWrIEzxsVNACvjuwgmd:
       folqeUbQJOXiWrIEzxsVNACvjuwgMc=folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('src')
       folqeUbQJOXiWrIEzxsVNACvjuwgMR =folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if folqeUbQJOXiWrIEzxsVNACvjuwgMc=='':
    for folqeUbQJOXiWrIEzxsVNACvjuwgMY in folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('data').get('raw').get('sources'):
     if 'key_systems' in folqeUbQJOXiWrIEzxsVNACvjuwgMY and 'codecs' not in folqeUbQJOXiWrIEzxsVNACvjuwgMY:
      if folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('key_systems')and folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('src').startswith('https://')==folqeUbQJOXiWrIEzxsVNACvjuwgmd:
       folqeUbQJOXiWrIEzxsVNACvjuwgMc=folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('src')
       folqeUbQJOXiWrIEzxsVNACvjuwgMR =folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if folqeUbQJOXiWrIEzxsVNACvjuwgMc=='':
    for folqeUbQJOXiWrIEzxsVNACvjuwgMY in folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('data').get('raw').get('sources'):
     if 'key_systems' in folqeUbQJOXiWrIEzxsVNACvjuwgMY and 'codecs' in folqeUbQJOXiWrIEzxsVNACvjuwgMY:
      if folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('type')=='application/dash+xml' and 'com.widevine.alpha' in folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('key_systems')and folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('src').startswith('https://')==folqeUbQJOXiWrIEzxsVNACvjuwgmd:
       folqeUbQJOXiWrIEzxsVNACvjuwgMc=folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('src')
       folqeUbQJOXiWrIEzxsVNACvjuwgMR =folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if folqeUbQJOXiWrIEzxsVNACvjuwgMc=='':
    for folqeUbQJOXiWrIEzxsVNACvjuwgMY in folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('data').get('raw').get('sources'):
     if 'key_systems' in folqeUbQJOXiWrIEzxsVNACvjuwgMY and 'codecs' in folqeUbQJOXiWrIEzxsVNACvjuwgMY:
      if folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('key_systems')and folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('src').startswith('https://')==folqeUbQJOXiWrIEzxsVNACvjuwgmd:
       folqeUbQJOXiWrIEzxsVNACvjuwgMc=folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('src')
       folqeUbQJOXiWrIEzxsVNACvjuwgMR =folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
  except folqeUbQJOXiWrIEzxsVNACvjuwgYB as exception:
   folqeUbQJOXiWrIEzxsVNACvjuwgYD(exception)
   return '',''
  return folqeUbQJOXiWrIEzxsVNACvjuwgMc,folqeUbQJOXiWrIEzxsVNACvjuwgMR
 def GetEventURL(folqeUbQJOXiWrIEzxsVNACvjuwgFM,eventId,folqeUbQJOXiWrIEzxsVNACvjuwgYm):
  folqeUbQJOXiWrIEzxsVNACvjuwgMc=''
  folqeUbQJOXiWrIEzxsVNACvjuwgMR =''
  folqeUbQJOXiWrIEzxsVNACvjuwgMh=folqeUbQJOXiWrIEzxsVNACvjuwgFM.Get_eInfo(eventId)
  if folqeUbQJOXiWrIEzxsVNACvjuwgMh=={}:return '',''
  try:
   folqeUbQJOXiWrIEzxsVNACvjuwgdS=folqeUbQJOXiWrIEzxsVNACvjuwgFM.API_DOMAIN+'/api/playback/play' 
   folqeUbQJOXiWrIEzxsVNACvjuwgdL={'titleId':eventId,'titleType':folqeUbQJOXiWrIEzxsVNACvjuwgYm,}
   folqeUbQJOXiWrIEzxsVNACvjuwgdM,folqeUbQJOXiWrIEzxsVNACvjuwgdY,folqeUbQJOXiWrIEzxsVNACvjuwgdm=folqeUbQJOXiWrIEzxsVNACvjuwgFM.Make_authHeader()
   folqeUbQJOXiWrIEzxsVNACvjuwgFL={'traceparent':folqeUbQJOXiWrIEzxsVNACvjuwgdM,'tracestate':folqeUbQJOXiWrIEzxsVNACvjuwgdY,'newrelic':folqeUbQJOXiWrIEzxsVNACvjuwgdm,'x-force-raw':'true','x-pcid':folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['COOKIES']['PCID'],'x-platform':'web','x-profileId':folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':folqeUbQJOXiWrIEzxsVNACvjuwgMh.get('asset_id'),'x-title-deal-id':folqeUbQJOXiWrIEzxsVNACvjuwgMh.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':folqeUbQJOXiWrIEzxsVNACvjuwgMh.get('region'),'x-title-streamable':folqeUbQJOXiWrIEzxsVNACvjuwgMh.get('streamable'),}
   folqeUbQJOXiWrIEzxsVNACvjuwgdk=folqeUbQJOXiWrIEzxsVNACvjuwgFM.make_CP_DefaultCookies()
   folqeUbQJOXiWrIEzxsVNACvjuwgdy=folqeUbQJOXiWrIEzxsVNACvjuwgFM.callRequestCookies('Get',folqeUbQJOXiWrIEzxsVNACvjuwgdS,payload=folqeUbQJOXiWrIEzxsVNACvjuwgYc,params=folqeUbQJOXiWrIEzxsVNACvjuwgdL,headers=folqeUbQJOXiWrIEzxsVNACvjuwgFL,cookies=folqeUbQJOXiWrIEzxsVNACvjuwgdk,redirects=folqeUbQJOXiWrIEzxsVNACvjuwgmd)
   if folqeUbQJOXiWrIEzxsVNACvjuwgdy.status_code not in[200]:return '',json.loads(folqeUbQJOXiWrIEzxsVNACvjuwgdy.text).get('error').get('detail')
   folqeUbQJOXiWrIEzxsVNACvjuwgdR=json.loads(folqeUbQJOXiWrIEzxsVNACvjuwgdy.text)
   for folqeUbQJOXiWrIEzxsVNACvjuwgMY in folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('data').get('raw').get('sources'):
    if folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('type')=='application/dash+xml' and folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('src')[0:8]=='https://':
     folqeUbQJOXiWrIEzxsVNACvjuwgMc=folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('src')
     if 'key_systems' in folqeUbQJOXiWrIEzxsVNACvjuwgMY:
      folqeUbQJOXiWrIEzxsVNACvjuwgMR =folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('key_systems').get('com.widevine.alpha').get('license_url')
     break
  except folqeUbQJOXiWrIEzxsVNACvjuwgYB as exception:
   folqeUbQJOXiWrIEzxsVNACvjuwgYD(exception)
   return '',''
  return folqeUbQJOXiWrIEzxsVNACvjuwgMc,folqeUbQJOXiWrIEzxsVNACvjuwgMR
 def GetEventURL_Live(folqeUbQJOXiWrIEzxsVNACvjuwgFM,eventId,folqeUbQJOXiWrIEzxsVNACvjuwgYm):
  folqeUbQJOXiWrIEzxsVNACvjuwgMc=''
  folqeUbQJOXiWrIEzxsVNACvjuwgMR =''
  folqeUbQJOXiWrIEzxsVNACvjuwgMh=folqeUbQJOXiWrIEzxsVNACvjuwgFM.Get_eInfo(eventId)
  if folqeUbQJOXiWrIEzxsVNACvjuwgMh=={}:return '',''
  try:
   folqeUbQJOXiWrIEzxsVNACvjuwgdS=folqeUbQJOXiWrIEzxsVNACvjuwgFM.API_DOMAIN+'/api/playback/play' 
   folqeUbQJOXiWrIEzxsVNACvjuwgdL={'titleId':eventId,'titleType':folqeUbQJOXiWrIEzxsVNACvjuwgYm,}
   folqeUbQJOXiWrIEzxsVNACvjuwgdM,folqeUbQJOXiWrIEzxsVNACvjuwgdY,folqeUbQJOXiWrIEzxsVNACvjuwgdm=folqeUbQJOXiWrIEzxsVNACvjuwgFM.Make_authHeader()
   folqeUbQJOXiWrIEzxsVNACvjuwgFL={'traceparent':folqeUbQJOXiWrIEzxsVNACvjuwgdM,'tracestate':folqeUbQJOXiWrIEzxsVNACvjuwgdY,'newrelic':folqeUbQJOXiWrIEzxsVNACvjuwgdm,'x-force-raw':'true','x-pcid':folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['COOKIES']['PCID'],'x-platform':'web','x-profileId':folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':folqeUbQJOXiWrIEzxsVNACvjuwgMh.get('asset_id'),'x-title-deal-id':folqeUbQJOXiWrIEzxsVNACvjuwgMh.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':folqeUbQJOXiWrIEzxsVNACvjuwgMh.get('region'),'x-title-streamable':folqeUbQJOXiWrIEzxsVNACvjuwgMh.get('streamable'),}
   folqeUbQJOXiWrIEzxsVNACvjuwgdk=folqeUbQJOXiWrIEzxsVNACvjuwgFM.make_CP_DefaultCookies()
   folqeUbQJOXiWrIEzxsVNACvjuwgdy=folqeUbQJOXiWrIEzxsVNACvjuwgFM.callRequestCookies('Get',folqeUbQJOXiWrIEzxsVNACvjuwgdS,payload=folqeUbQJOXiWrIEzxsVNACvjuwgYc,params=folqeUbQJOXiWrIEzxsVNACvjuwgdL,headers=folqeUbQJOXiWrIEzxsVNACvjuwgFL,cookies=folqeUbQJOXiWrIEzxsVNACvjuwgdk,redirects=folqeUbQJOXiWrIEzxsVNACvjuwgmd)
   if folqeUbQJOXiWrIEzxsVNACvjuwgdy.status_code not in[200]:return '',json.loads(folqeUbQJOXiWrIEzxsVNACvjuwgdy.text).get('error').get('detail')
   folqeUbQJOXiWrIEzxsVNACvjuwgdR=json.loads(folqeUbQJOXiWrIEzxsVNACvjuwgdy.text)
   if folqeUbQJOXiWrIEzxsVNACvjuwgMc=='':
    for folqeUbQJOXiWrIEzxsVNACvjuwgMY in folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('data').get('raw').get('sources'):
     if 'key_systems' in folqeUbQJOXiWrIEzxsVNACvjuwgMY:
      if folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('type')=='application/dash+xml' and 'com.widevine.alpha' in folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('key_systems')and folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('src').startswith('https://')==folqeUbQJOXiWrIEzxsVNACvjuwgmd:
       folqeUbQJOXiWrIEzxsVNACvjuwgMc=folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('src')
       folqeUbQJOXiWrIEzxsVNACvjuwgMR =folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('key_systems').get('com.widevine.alpha').get('license_url')
   if folqeUbQJOXiWrIEzxsVNACvjuwgMc=='':
    for folqeUbQJOXiWrIEzxsVNACvjuwgMY in folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('data').get('raw').get('sources'):
     if 'key_systems' in folqeUbQJOXiWrIEzxsVNACvjuwgMY:
      if folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('key_systems')and folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('src').startswith('https://')==folqeUbQJOXiWrIEzxsVNACvjuwgmd:
       folqeUbQJOXiWrIEzxsVNACvjuwgMc=folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('src')
       folqeUbQJOXiWrIEzxsVNACvjuwgMR =folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('key_systems').get('com.widevine.alpha').get('license_url')
   if folqeUbQJOXiWrIEzxsVNACvjuwgMc=='':
    for folqeUbQJOXiWrIEzxsVNACvjuwgMY in folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('data').get('raw').get('sources'):
     if folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('type')=='application/dash+xml' and folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('src').startswith('https://')==folqeUbQJOXiWrIEzxsVNACvjuwgmd:
      folqeUbQJOXiWrIEzxsVNACvjuwgMc=folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('src')
   if folqeUbQJOXiWrIEzxsVNACvjuwgMc=='':
    for folqeUbQJOXiWrIEzxsVNACvjuwgMY in folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('data').get('raw').get('sources'):
     if folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('type')=='application/x-mpegURL' and folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('src').startswith('https://')==folqeUbQJOXiWrIEzxsVNACvjuwgmd:
      folqeUbQJOXiWrIEzxsVNACvjuwgMc=folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('src')
  except folqeUbQJOXiWrIEzxsVNACvjuwgYB as exception:
   folqeUbQJOXiWrIEzxsVNACvjuwgYD(exception)
   return '',''
  return folqeUbQJOXiWrIEzxsVNACvjuwgMc,folqeUbQJOXiWrIEzxsVNACvjuwgMR
 def Get_Url_PostFix(folqeUbQJOXiWrIEzxsVNACvjuwgFM,in_url):
  folqeUbQJOXiWrIEzxsVNACvjuwgMD=urllib.parse.urlparse(in_url) 
  folqeUbQJOXiWrIEzxsVNACvjuwgMG =folqeUbQJOXiWrIEzxsVNACvjuwgMD.path.strip('/').split('/')
  folqeUbQJOXiWrIEzxsVNACvjuwgMH =folqeUbQJOXiWrIEzxsVNACvjuwgMG[folqeUbQJOXiWrIEzxsVNACvjuwgYL(folqeUbQJOXiWrIEzxsVNACvjuwgMG)-1]
  folqeUbQJOXiWrIEzxsVNACvjuwgMP=folqeUbQJOXiWrIEzxsVNACvjuwgMH.split('.')
  return folqeUbQJOXiWrIEzxsVNACvjuwgMP[folqeUbQJOXiWrIEzxsVNACvjuwgYL(folqeUbQJOXiWrIEzxsVNACvjuwgMP)-1]
 def Get_Theme_GroupList(folqeUbQJOXiWrIEzxsVNACvjuwgFM,vType):
  folqeUbQJOXiWrIEzxsVNACvjuwgdB=[] 
  try:
   folqeUbQJOXiWrIEzxsVNACvjuwgdS=folqeUbQJOXiWrIEzxsVNACvjuwgFM.API_VIEWURL+'/v3/discover/feed' 
   folqeUbQJOXiWrIEzxsVNACvjuwgdL={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':folqeUbQJOXiWrIEzxsVNACvjuwgYG(folqeUbQJOXiWrIEzxsVNACvjuwgFM.PAGE_LIMIT),'filterRestrictedContent':folqeUbQJOXiWrIEzxsVNACvjuwgYR,'preferRecoFeed':folqeUbQJOXiWrIEzxsVNACvjuwgmd,'preferMultiHeroMixedContentRow':folqeUbQJOXiWrIEzxsVNACvjuwgmd,'shouldIncludeTVOD':folqeUbQJOXiWrIEzxsVNACvjuwgmd,'includeChannelContents':folqeUbQJOXiWrIEzxsVNACvjuwgYR,}
   folqeUbQJOXiWrIEzxsVNACvjuwgdy=folqeUbQJOXiWrIEzxsVNACvjuwgFM.callRequestCookies('Get',folqeUbQJOXiWrIEzxsVNACvjuwgdS,payload=folqeUbQJOXiWrIEzxsVNACvjuwgYc,params=folqeUbQJOXiWrIEzxsVNACvjuwgdL,headers=folqeUbQJOXiWrIEzxsVNACvjuwgYc,cookies=folqeUbQJOXiWrIEzxsVNACvjuwgYc,redirects=folqeUbQJOXiWrIEzxsVNACvjuwgmd)
   if folqeUbQJOXiWrIEzxsVNACvjuwgdy.status_code not in[200]:return[]
   folqeUbQJOXiWrIEzxsVNACvjuwgdR=json.loads(folqeUbQJOXiWrIEzxsVNACvjuwgdy.text)
   for folqeUbQJOXiWrIEzxsVNACvjuwgMY in folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('data'):
    if folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('type')=='Title-Rails-Curation':
     folqeUbQJOXiWrIEzxsVNACvjuwgMB =''
     folqeUbQJOXiWrIEzxsVNACvjuwgML=7
     try:
      for i in folqeUbQJOXiWrIEzxsVNACvjuwgmM(folqeUbQJOXiWrIEzxsVNACvjuwgYL(folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('data'))):
       if i>=folqeUbQJOXiWrIEzxsVNACvjuwgML:
        folqeUbQJOXiWrIEzxsVNACvjuwgMB=folqeUbQJOXiWrIEzxsVNACvjuwgMB+'...'
        break
       folqeUbQJOXiWrIEzxsVNACvjuwgMB=folqeUbQJOXiWrIEzxsVNACvjuwgMB+folqeUbQJOXiWrIEzxsVNACvjuwgMY['data'][i]['title']+'\n'
     except folqeUbQJOXiWrIEzxsVNACvjuwgYB as exception:
      folqeUbQJOXiWrIEzxsVNACvjuwgYD(exception)
     folqeUbQJOXiWrIEzxsVNACvjuwgMa={'collectionId':folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('obj_id'),'title':folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('row_name'),'category':folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('category'),'pre_title':folqeUbQJOXiWrIEzxsVNACvjuwgMB,}
     folqeUbQJOXiWrIEzxsVNACvjuwgdB.append(folqeUbQJOXiWrIEzxsVNACvjuwgMa)
  except folqeUbQJOXiWrIEzxsVNACvjuwgYB as exception:
   folqeUbQJOXiWrIEzxsVNACvjuwgYD(exception)
   return[]
  return folqeUbQJOXiWrIEzxsVNACvjuwgdB
 def Get_Event_GroupList(folqeUbQJOXiWrIEzxsVNACvjuwgFM):
  folqeUbQJOXiWrIEzxsVNACvjuwgdB=[] 
  try:
   folqeUbQJOXiWrIEzxsVNACvjuwgdS=folqeUbQJOXiWrIEzxsVNACvjuwgFM.API_VIEWURL+'/v3/discover/feed' 
   folqeUbQJOXiWrIEzxsVNACvjuwgdL={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':7,'filterRestrictedContent':folqeUbQJOXiWrIEzxsVNACvjuwgYR,'preferRecoFeed':folqeUbQJOXiWrIEzxsVNACvjuwgmd,'preferMultiHeroMixedContentRow':folqeUbQJOXiWrIEzxsVNACvjuwgmd,'shouldIncludeTVOD':folqeUbQJOXiWrIEzxsVNACvjuwgmd,'includeChannelContents':folqeUbQJOXiWrIEzxsVNACvjuwgYR,}
   folqeUbQJOXiWrIEzxsVNACvjuwgdy=folqeUbQJOXiWrIEzxsVNACvjuwgFM.callRequestCookies('Get',folqeUbQJOXiWrIEzxsVNACvjuwgdS,payload=folqeUbQJOXiWrIEzxsVNACvjuwgYc,params=folqeUbQJOXiWrIEzxsVNACvjuwgdL,headers=folqeUbQJOXiWrIEzxsVNACvjuwgYc,cookies=folqeUbQJOXiWrIEzxsVNACvjuwgYc,redirects=folqeUbQJOXiWrIEzxsVNACvjuwgmd)
   if folqeUbQJOXiWrIEzxsVNACvjuwgdy.status_code not in[200]:return[]
   folqeUbQJOXiWrIEzxsVNACvjuwgdR=json.loads(folqeUbQJOXiWrIEzxsVNACvjuwgdy.text)
   for folqeUbQJOXiWrIEzxsVNACvjuwgMY in folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('data'):
    if folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('row_name').strip()!='':
     folqeUbQJOXiWrIEzxsVNACvjuwgMB =''
     folqeUbQJOXiWrIEzxsVNACvjuwgML=7
     try:
      for i in folqeUbQJOXiWrIEzxsVNACvjuwgmM(folqeUbQJOXiWrIEzxsVNACvjuwgYL(folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('data'))):
       if i>=folqeUbQJOXiWrIEzxsVNACvjuwgML:
        folqeUbQJOXiWrIEzxsVNACvjuwgMB=folqeUbQJOXiWrIEzxsVNACvjuwgMB+'...'
        break
       folqeUbQJOXiWrIEzxsVNACvjuwgMB=folqeUbQJOXiWrIEzxsVNACvjuwgMB+folqeUbQJOXiWrIEzxsVNACvjuwgMY['data'][i]['title']+'\n'
     except folqeUbQJOXiWrIEzxsVNACvjuwgYB as exception:
      folqeUbQJOXiWrIEzxsVNACvjuwgYD(exception)
     folqeUbQJOXiWrIEzxsVNACvjuwgMa={'collectionId':folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('obj_id'),'title':folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('row_name'),'category':folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('type'),'pre_title':folqeUbQJOXiWrIEzxsVNACvjuwgMB,}
     folqeUbQJOXiWrIEzxsVNACvjuwgdB.append(folqeUbQJOXiWrIEzxsVNACvjuwgMa)
  except folqeUbQJOXiWrIEzxsVNACvjuwgYB as exception:
   folqeUbQJOXiWrIEzxsVNACvjuwgYD(exception)
   return[]
  return folqeUbQJOXiWrIEzxsVNACvjuwgdB
 def Get_Event_GameList(folqeUbQJOXiWrIEzxsVNACvjuwgFM,folqeUbQJOXiWrIEzxsVNACvjuwgMm):
  folqeUbQJOXiWrIEzxsVNACvjuwgdB=[] 
  try:
   folqeUbQJOXiWrIEzxsVNACvjuwgdS=folqeUbQJOXiWrIEzxsVNACvjuwgFM.API_VIEWURL+'/v3/discover/feed' 
   folqeUbQJOXiWrIEzxsVNACvjuwgdL={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':7,'filterRestrictedContent':folqeUbQJOXiWrIEzxsVNACvjuwgYR,'preferRecoFeed':folqeUbQJOXiWrIEzxsVNACvjuwgmd,'preferMultiHeroMixedContentRow':folqeUbQJOXiWrIEzxsVNACvjuwgmd,'shouldIncludeTVOD':folqeUbQJOXiWrIEzxsVNACvjuwgmd,'includeChannelContents':folqeUbQJOXiWrIEzxsVNACvjuwgYR,}
   folqeUbQJOXiWrIEzxsVNACvjuwgdy=folqeUbQJOXiWrIEzxsVNACvjuwgFM.callRequestCookies('Get',folqeUbQJOXiWrIEzxsVNACvjuwgdS,payload=folqeUbQJOXiWrIEzxsVNACvjuwgYc,params=folqeUbQJOXiWrIEzxsVNACvjuwgdL,headers=folqeUbQJOXiWrIEzxsVNACvjuwgYc,cookies=folqeUbQJOXiWrIEzxsVNACvjuwgYc,redirects=folqeUbQJOXiWrIEzxsVNACvjuwgmd)
   if folqeUbQJOXiWrIEzxsVNACvjuwgdy.status_code not in[200]:return[]
   folqeUbQJOXiWrIEzxsVNACvjuwgdR=json.loads(folqeUbQJOXiWrIEzxsVNACvjuwgdy.text)
   for folqeUbQJOXiWrIEzxsVNACvjuwgMY in folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('data'):
    if folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('obj_id')==folqeUbQJOXiWrIEzxsVNACvjuwgMm:
     for folqeUbQJOXiWrIEzxsVNACvjuwgYF in folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('data'):
      folqeUbQJOXiWrIEzxsVNACvjuwgMS=folqeUbQJOXiWrIEzxsVNACvjuwgMT=folqeUbQJOXiWrIEzxsVNACvjuwgYk=''
      if 'poster_url' in folqeUbQJOXiWrIEzxsVNACvjuwgYF.get('images'):folqeUbQJOXiWrIEzxsVNACvjuwgMS =folqeUbQJOXiWrIEzxsVNACvjuwgYF.get('images').get('poster_url') +'?imwidth=350'
      if 'story_art_url' in folqeUbQJOXiWrIEzxsVNACvjuwgYF.get('images'):folqeUbQJOXiWrIEzxsVNACvjuwgMT =folqeUbQJOXiWrIEzxsVNACvjuwgYF.get('images').get('story_art_url')+'?imwidth=600'
      if 'hero_url' in folqeUbQJOXiWrIEzxsVNACvjuwgYF.get('images'):folqeUbQJOXiWrIEzxsVNACvjuwgYk =folqeUbQJOXiWrIEzxsVNACvjuwgYF.get('images').get('hero_url') +'?imwidth=600'
      folqeUbQJOXiWrIEzxsVNACvjuwgMa={'id':folqeUbQJOXiWrIEzxsVNACvjuwgYF.get('id'),'title':folqeUbQJOXiWrIEzxsVNACvjuwgYF.get('title'),'thumbnail':{'poster':folqeUbQJOXiWrIEzxsVNACvjuwgMS,'thumb':folqeUbQJOXiWrIEzxsVNACvjuwgMT,'fanart':folqeUbQJOXiWrIEzxsVNACvjuwgYk},'asis':folqeUbQJOXiWrIEzxsVNACvjuwgYF.get('type'),'starttm':folqeUbQJOXiWrIEzxsVNACvjuwgFM.convert_TimeStr(folqeUbQJOXiWrIEzxsVNACvjuwgYF.get('startAt')),}
      folqeUbQJOXiWrIEzxsVNACvjuwgdB.append(folqeUbQJOXiWrIEzxsVNACvjuwgMa)
  except folqeUbQJOXiWrIEzxsVNACvjuwgYB as exception:
   folqeUbQJOXiWrIEzxsVNACvjuwgYD(exception)
   return[]
  return folqeUbQJOXiWrIEzxsVNACvjuwgdB
 def Get_Event_List(folqeUbQJOXiWrIEzxsVNACvjuwgFM,gameId):
  folqeUbQJOXiWrIEzxsVNACvjuwgdB=[] 
  try:
   folqeUbQJOXiWrIEzxsVNACvjuwgdS=folqeUbQJOXiWrIEzxsVNACvjuwgFM.API_VIEWURL+'/v1/discover/events/'+gameId 
   folqeUbQJOXiWrIEzxsVNACvjuwgdL={'platform':'WEBCLIENT','locale':'ko','filterRestrictedContent':'false',}
   folqeUbQJOXiWrIEzxsVNACvjuwgdy=folqeUbQJOXiWrIEzxsVNACvjuwgFM.callRequestCookies('Get',folqeUbQJOXiWrIEzxsVNACvjuwgdS,payload=folqeUbQJOXiWrIEzxsVNACvjuwgYc,params=folqeUbQJOXiWrIEzxsVNACvjuwgdL,headers=folqeUbQJOXiWrIEzxsVNACvjuwgYc,cookies=folqeUbQJOXiWrIEzxsVNACvjuwgYc,redirects=folqeUbQJOXiWrIEzxsVNACvjuwgmd)
   if folqeUbQJOXiWrIEzxsVNACvjuwgdy.status_code not in[200]:return[]
   folqeUbQJOXiWrIEzxsVNACvjuwgdR=json.loads(folqeUbQJOXiWrIEzxsVNACvjuwgdy.text)
   folqeUbQJOXiWrIEzxsVNACvjuwgMY=folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('data')
   folqeUbQJOXiWrIEzxsVNACvjuwgYd=folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('end_at')
   folqeUbQJOXiWrIEzxsVNACvjuwgYd=folqeUbQJOXiWrIEzxsVNACvjuwgYd[0:19].replace('-','').replace(':','').replace('T','')
   folqeUbQJOXiWrIEzxsVNACvjuwgYM=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d%H%M%S')
   if folqeUbQJOXiWrIEzxsVNACvjuwgYP(folqeUbQJOXiWrIEzxsVNACvjuwgYM)<folqeUbQJOXiWrIEzxsVNACvjuwgYP(folqeUbQJOXiWrIEzxsVNACvjuwgYd):
    folqeUbQJOXiWrIEzxsVNACvjuwgMS=folqeUbQJOXiWrIEzxsVNACvjuwgMT=folqeUbQJOXiWrIEzxsVNACvjuwgYk=''
    if 'poster' in folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('images'):folqeUbQJOXiWrIEzxsVNACvjuwgMS =folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('images'):folqeUbQJOXiWrIEzxsVNACvjuwgMT =folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('images').get('story-art').get('url')+'?imwidth=600'
    if 'story-art' in folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('images'):folqeUbQJOXiWrIEzxsVNACvjuwgYk =folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('images').get('story-art').get('url')+'?imwidth=600'
    folqeUbQJOXiWrIEzxsVNACvjuwgMa={'id':folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('id'),'title':folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('title'),'thumbnail':{'poster':folqeUbQJOXiWrIEzxsVNACvjuwgMS,'thumb':folqeUbQJOXiWrIEzxsVNACvjuwgMT,'fanart':folqeUbQJOXiWrIEzxsVNACvjuwgYk},'duration':folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('running_time'),'asis':folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('type'),'starttm':folqeUbQJOXiWrIEzxsVNACvjuwgFM.convert_TimeStr(folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('start_at')),}
    folqeUbQJOXiWrIEzxsVNACvjuwgdB.append(folqeUbQJOXiWrIEzxsVNACvjuwgMa)
  except folqeUbQJOXiWrIEzxsVNACvjuwgYB as exception:
   folqeUbQJOXiWrIEzxsVNACvjuwgYD(exception)
   return[]
  try:
   folqeUbQJOXiWrIEzxsVNACvjuwgdS=folqeUbQJOXiWrIEzxsVNACvjuwgFM.API_VIEWURL+'/v1/discover/events/'+gameId+'/related' 
   folqeUbQJOXiWrIEzxsVNACvjuwgdL={'locale':'ko','page':'1','perPage':'25','platform':'WEBCLIENT','currentPageTracking':'page_discover_title_detail',}
   folqeUbQJOXiWrIEzxsVNACvjuwgdy=folqeUbQJOXiWrIEzxsVNACvjuwgFM.callRequestCookies('Get',folqeUbQJOXiWrIEzxsVNACvjuwgdS,payload=folqeUbQJOXiWrIEzxsVNACvjuwgYc,params=folqeUbQJOXiWrIEzxsVNACvjuwgdL,headers=folqeUbQJOXiWrIEzxsVNACvjuwgYc,cookies=folqeUbQJOXiWrIEzxsVNACvjuwgYc,redirects=folqeUbQJOXiWrIEzxsVNACvjuwgmd)
   if folqeUbQJOXiWrIEzxsVNACvjuwgdy.status_code not in[200]:return[]
   folqeUbQJOXiWrIEzxsVNACvjuwgdR=json.loads(folqeUbQJOXiWrIEzxsVNACvjuwgdy.text)
   for folqeUbQJOXiWrIEzxsVNACvjuwgMY in folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('data').get('data'):
    folqeUbQJOXiWrIEzxsVNACvjuwgMS=folqeUbQJOXiWrIEzxsVNACvjuwgMT=folqeUbQJOXiWrIEzxsVNACvjuwgYk=''
    if 'poster' in folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('images'):folqeUbQJOXiWrIEzxsVNACvjuwgMS =folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('images'):folqeUbQJOXiWrIEzxsVNACvjuwgMT =folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('images').get('story-art').get('url')+'?imwidth=600'
    if 'story-art' in folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('images'):folqeUbQJOXiWrIEzxsVNACvjuwgYk =folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('images').get('story-art').get('url')+'?imwidth=600'
    folqeUbQJOXiWrIEzxsVNACvjuwgMa={'id':folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('id'),'title':folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('title'),'thumbnail':{'poster':folqeUbQJOXiWrIEzxsVNACvjuwgMS,'thumb':folqeUbQJOXiWrIEzxsVNACvjuwgMT,'fanart':folqeUbQJOXiWrIEzxsVNACvjuwgYk},'duration':folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('running_time'),'asis':folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('type'),}
    folqeUbQJOXiWrIEzxsVNACvjuwgdB.append(folqeUbQJOXiWrIEzxsVNACvjuwgMa)
  except folqeUbQJOXiWrIEzxsVNACvjuwgYB as exception:
   folqeUbQJOXiWrIEzxsVNACvjuwgYD(exception)
   return[]
  return folqeUbQJOXiWrIEzxsVNACvjuwgdB
 def Get_Search_List(folqeUbQJOXiWrIEzxsVNACvjuwgFM,search_key,page_int):
  folqeUbQJOXiWrIEzxsVNACvjuwgdB=[] 
  folqeUbQJOXiWrIEzxsVNACvjuwgMn=folqeUbQJOXiWrIEzxsVNACvjuwgYR
  try:
   folqeUbQJOXiWrIEzxsVNACvjuwgdS=folqeUbQJOXiWrIEzxsVNACvjuwgFM.API_VIEWURL+'/v2/search' 
   folqeUbQJOXiWrIEzxsVNACvjuwgdL={'query':search_key,'platform':'WEBCLIENT','page':folqeUbQJOXiWrIEzxsVNACvjuwgYG(page_int),'perPage':folqeUbQJOXiWrIEzxsVNACvjuwgYG(folqeUbQJOXiWrIEzxsVNACvjuwgFM.SEARCH_LIMIT),}
   folqeUbQJOXiWrIEzxsVNACvjuwgFL={'x-membersrl':folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['COOKIES']['member_srl'],'x-pcid':folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['COOKIES']['PCID'],'x-profileid':folqeUbQJOXiWrIEzxsVNACvjuwgFM.CP['SESSION']['profileId'],}
   folqeUbQJOXiWrIEzxsVNACvjuwgdy=folqeUbQJOXiWrIEzxsVNACvjuwgFM.callRequestCookies('Get',folqeUbQJOXiWrIEzxsVNACvjuwgdS,payload=folqeUbQJOXiWrIEzxsVNACvjuwgYc,params=folqeUbQJOXiWrIEzxsVNACvjuwgdL,headers=folqeUbQJOXiWrIEzxsVNACvjuwgFL,cookies=folqeUbQJOXiWrIEzxsVNACvjuwgYc,redirects=folqeUbQJOXiWrIEzxsVNACvjuwgmd)
   if folqeUbQJOXiWrIEzxsVNACvjuwgdy.status_code not in[200]:return[],folqeUbQJOXiWrIEzxsVNACvjuwgYR
   folqeUbQJOXiWrIEzxsVNACvjuwgdR=json.loads(folqeUbQJOXiWrIEzxsVNACvjuwgdy.text)
   for folqeUbQJOXiWrIEzxsVNACvjuwgMY in folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('data').get('data'):
    folqeUbQJOXiWrIEzxsVNACvjuwgMY=folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('data')
    folqeUbQJOXiWrIEzxsVNACvjuwgMS=folqeUbQJOXiWrIEzxsVNACvjuwgMT=folqeUbQJOXiWrIEzxsVNACvjuwgYy=folqeUbQJOXiWrIEzxsVNACvjuwgYk=''
    if 'poster' in folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('images'):folqeUbQJOXiWrIEzxsVNACvjuwgMS =folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('images'):folqeUbQJOXiWrIEzxsVNACvjuwgMT =folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('images').get('story-art').get('url') +'?imwidth=600'
    if 'title-treatment' in folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('images'):folqeUbQJOXiWrIEzxsVNACvjuwgYy=folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('images').get('title-treatment').get('url')+'?imwidth=300'
    if 'story-art' in folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('images'):folqeUbQJOXiWrIEzxsVNACvjuwgYk =folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('images').get('story-art').get('url') +'?imwidth=600'
    folqeUbQJOXiWrIEzxsVNACvjuwgMk=''
    if folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('badge')not in[{},folqeUbQJOXiWrIEzxsVNACvjuwgYc]:
     for i in folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('badge').get('text'):
      if folqeUbQJOXiWrIEzxsVNACvjuwgMk!='':folqeUbQJOXiWrIEzxsVNACvjuwgMk+=' '
      folqeUbQJOXiWrIEzxsVNACvjuwgMk+=i.get('text')
    if 'as' in folqeUbQJOXiWrIEzxsVNACvjuwgMY:
     folqeUbQJOXiWrIEzxsVNACvjuwgYm=folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('as') 
    else:
     folqeUbQJOXiWrIEzxsVNACvjuwgYm=folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('type')
    folqeUbQJOXiWrIEzxsVNACvjuwgMa={'id':folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('id'),'title':folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('title'),'asis':folqeUbQJOXiWrIEzxsVNACvjuwgYm,'thumbnail':{'poster':folqeUbQJOXiWrIEzxsVNACvjuwgMS,'thumb':folqeUbQJOXiWrIEzxsVNACvjuwgMT,'clearlogo':folqeUbQJOXiWrIEzxsVNACvjuwgYy,'fanart':folqeUbQJOXiWrIEzxsVNACvjuwgYk},'mpaa':folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('age_rating'),'duration':folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('running_time'),'badge':folqeUbQJOXiWrIEzxsVNACvjuwgMk,'year':folqeUbQJOXiWrIEzxsVNACvjuwgMY.get('meta').get('releaseYear'),}
    folqeUbQJOXiWrIEzxsVNACvjuwgdB.append(folqeUbQJOXiWrIEzxsVNACvjuwgMa)
   if folqeUbQJOXiWrIEzxsVNACvjuwgdR.get('pagination').get('totalPages')>page_int:
    folqeUbQJOXiWrIEzxsVNACvjuwgMn=folqeUbQJOXiWrIEzxsVNACvjuwgmd
  except folqeUbQJOXiWrIEzxsVNACvjuwgYB as exception:
   folqeUbQJOXiWrIEzxsVNACvjuwgYD(exception)
   return[],folqeUbQJOXiWrIEzxsVNACvjuwgYR
  return folqeUbQJOXiWrIEzxsVNACvjuwgdB,folqeUbQJOXiWrIEzxsVNACvjuwgMn
 def GetBookmarkInfo(folqeUbQJOXiWrIEzxsVNACvjuwgFM,videoid,vidtype):
  folqeUbQJOXiWrIEzxsVNACvjuwgYa={'indexinfo':{'ott':'coupang','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  folqeUbQJOXiWrIEzxsVNACvjuwgdS=folqeUbQJOXiWrIEzxsVNACvjuwgFM.API_VIEWURL+'/v1/discover/titles/'+videoid 
  folqeUbQJOXiWrIEzxsVNACvjuwgdL={'locale':'ko'}
  folqeUbQJOXiWrIEzxsVNACvjuwgdy=folqeUbQJOXiWrIEzxsVNACvjuwgFM.callRequestCookies('Get',folqeUbQJOXiWrIEzxsVNACvjuwgdS,payload=folqeUbQJOXiWrIEzxsVNACvjuwgYc,params=folqeUbQJOXiWrIEzxsVNACvjuwgdL,headers=folqeUbQJOXiWrIEzxsVNACvjuwgYc,cookies=folqeUbQJOXiWrIEzxsVNACvjuwgYc,redirects=folqeUbQJOXiWrIEzxsVNACvjuwgmd)
  if folqeUbQJOXiWrIEzxsVNACvjuwgdy.status_code not in[200]:return{}
  folqeUbQJOXiWrIEzxsVNACvjuwgYn=json.loads(folqeUbQJOXiWrIEzxsVNACvjuwgdy.text).get('data')
  folqeUbQJOXiWrIEzxsVNACvjuwgYp=folqeUbQJOXiWrIEzxsVNACvjuwgYn.get('title')
  folqeUbQJOXiWrIEzxsVNACvjuwgYS =folqeUbQJOXiWrIEzxsVNACvjuwgYn.get('meta').get('releaseYear')
  folqeUbQJOXiWrIEzxsVNACvjuwgYa['saveinfo']['infoLabels']['title']=folqeUbQJOXiWrIEzxsVNACvjuwgYp
  if vidtype=='movie':
   folqeUbQJOXiWrIEzxsVNACvjuwgYp='%s  (%s)'%(folqeUbQJOXiWrIEzxsVNACvjuwgYp,folqeUbQJOXiWrIEzxsVNACvjuwgYS)
  folqeUbQJOXiWrIEzxsVNACvjuwgYa['saveinfo']['title'] =folqeUbQJOXiWrIEzxsVNACvjuwgYp
  folqeUbQJOXiWrIEzxsVNACvjuwgYa['saveinfo']['infoLabels']['mpaa'] =folqeUbQJOXiWrIEzxsVNACvjuwgYn.get('age_rating')
  folqeUbQJOXiWrIEzxsVNACvjuwgYa['saveinfo']['infoLabels']['plot'] ='%s\n\n%s'%(folqeUbQJOXiWrIEzxsVNACvjuwgYn.get('short_description'),folqeUbQJOXiWrIEzxsVNACvjuwgYn.get('description'))
  folqeUbQJOXiWrIEzxsVNACvjuwgYa['saveinfo']['infoLabels']['year'] =folqeUbQJOXiWrIEzxsVNACvjuwgYS
  if vidtype=='movie':
   folqeUbQJOXiWrIEzxsVNACvjuwgYa['saveinfo']['infoLabels']['duration']=folqeUbQJOXiWrIEzxsVNACvjuwgYn.get('running_time')
  folqeUbQJOXiWrIEzxsVNACvjuwgMS =''
  folqeUbQJOXiWrIEzxsVNACvjuwgYk =''
  folqeUbQJOXiWrIEzxsVNACvjuwgMT =''
  folqeUbQJOXiWrIEzxsVNACvjuwgYy=''
  if folqeUbQJOXiWrIEzxsVNACvjuwgYn.get('images').get('poster') !=folqeUbQJOXiWrIEzxsVNACvjuwgYc:folqeUbQJOXiWrIEzxsVNACvjuwgMS =folqeUbQJOXiWrIEzxsVNACvjuwgYn.get('images').get('poster').get('url') +'?imwidth=350'
  if folqeUbQJOXiWrIEzxsVNACvjuwgYn.get('images').get('background') !=folqeUbQJOXiWrIEzxsVNACvjuwgYc:folqeUbQJOXiWrIEzxsVNACvjuwgYk =folqeUbQJOXiWrIEzxsVNACvjuwgYn.get('images').get('background').get('url') +'?imwidth=600'
  if folqeUbQJOXiWrIEzxsVNACvjuwgYn.get('images').get('story-art') !=folqeUbQJOXiWrIEzxsVNACvjuwgYc:folqeUbQJOXiWrIEzxsVNACvjuwgMT =folqeUbQJOXiWrIEzxsVNACvjuwgYn.get('images').get('story-art').get('url') +'?imwidth=600'
  if folqeUbQJOXiWrIEzxsVNACvjuwgYn.get('images').get('title-treatment')!=folqeUbQJOXiWrIEzxsVNACvjuwgYc:folqeUbQJOXiWrIEzxsVNACvjuwgYy=folqeUbQJOXiWrIEzxsVNACvjuwgYn.get('images').get('title-treatment').get('url')+'?imwidth=300'
  if folqeUbQJOXiWrIEzxsVNACvjuwgYk=='':folqeUbQJOXiWrIEzxsVNACvjuwgYk=folqeUbQJOXiWrIEzxsVNACvjuwgMT
  folqeUbQJOXiWrIEzxsVNACvjuwgYa['saveinfo']['thumbnail']['poster']=folqeUbQJOXiWrIEzxsVNACvjuwgMS
  folqeUbQJOXiWrIEzxsVNACvjuwgYa['saveinfo']['thumbnail']['fanart']=folqeUbQJOXiWrIEzxsVNACvjuwgYk
  folqeUbQJOXiWrIEzxsVNACvjuwgYa['saveinfo']['thumbnail']['thumb']=folqeUbQJOXiWrIEzxsVNACvjuwgMT
  folqeUbQJOXiWrIEzxsVNACvjuwgYa['saveinfo']['thumbnail']['clearlogo']=folqeUbQJOXiWrIEzxsVNACvjuwgYy
  folqeUbQJOXiWrIEzxsVNACvjuwgYK=[]
  for folqeUbQJOXiWrIEzxsVNACvjuwgMt in folqeUbQJOXiWrIEzxsVNACvjuwgYn.get('tags'):folqeUbQJOXiWrIEzxsVNACvjuwgYK.append(folqeUbQJOXiWrIEzxsVNACvjuwgMt.get('tag'))
  if folqeUbQJOXiWrIEzxsVNACvjuwgYL(folqeUbQJOXiWrIEzxsVNACvjuwgYK)>0:
   folqeUbQJOXiWrIEzxsVNACvjuwgYa['saveinfo']['infoLabels']['genre']=folqeUbQJOXiWrIEzxsVNACvjuwgYK
  folqeUbQJOXiWrIEzxsVNACvjuwgYt=[]
  folqeUbQJOXiWrIEzxsVNACvjuwgYT=[]
  for folqeUbQJOXiWrIEzxsVNACvjuwgMt in folqeUbQJOXiWrIEzxsVNACvjuwgYn.get('people'):
   if folqeUbQJOXiWrIEzxsVNACvjuwgMt.get('role')=='CAST' :folqeUbQJOXiWrIEzxsVNACvjuwgYt.append(folqeUbQJOXiWrIEzxsVNACvjuwgMt.get('name'))
   if folqeUbQJOXiWrIEzxsVNACvjuwgMt.get('role')=='DIRECTOR':folqeUbQJOXiWrIEzxsVNACvjuwgYT.append(folqeUbQJOXiWrIEzxsVNACvjuwgMt.get('name'))
  if folqeUbQJOXiWrIEzxsVNACvjuwgYL(folqeUbQJOXiWrIEzxsVNACvjuwgYt)>0:
   folqeUbQJOXiWrIEzxsVNACvjuwgYa['saveinfo']['infoLabels']['cast'] =folqeUbQJOXiWrIEzxsVNACvjuwgYt
  if folqeUbQJOXiWrIEzxsVNACvjuwgYL(folqeUbQJOXiWrIEzxsVNACvjuwgYT)>0:
   folqeUbQJOXiWrIEzxsVNACvjuwgYa['saveinfo']['infoLabels']['director']=folqeUbQJOXiWrIEzxsVNACvjuwgYT
  return folqeUbQJOXiWrIEzxsVNACvjuwgYa
# Created by pyminifier (https://github.com/liftoff/pyminifier)
