__author__="NightRain"
qkMdOncHWzaBfGvgeVASjFXCToJlru=object
qkMdOncHWzaBfGvgeVASjFXCToJlry=None
qkMdOncHWzaBfGvgeVASjFXCToJlrL=False
qkMdOncHWzaBfGvgeVASjFXCToJlrI=True
qkMdOncHWzaBfGvgeVASjFXCToJlrR=type
qkMdOncHWzaBfGvgeVASjFXCToJlrb=dict
qkMdOncHWzaBfGvgeVASjFXCToJlrQ=getattr
qkMdOncHWzaBfGvgeVASjFXCToJlrw=int
qkMdOncHWzaBfGvgeVASjFXCToJlrx=list
qkMdOncHWzaBfGvgeVASjFXCToJlrh=open
qkMdOncHWzaBfGvgeVASjFXCToJlrE=Exception
qkMdOncHWzaBfGvgeVASjFXCToJlrY=str
qkMdOncHWzaBfGvgeVASjFXCToJlrD=id
qkMdOncHWzaBfGvgeVASjFXCToJlrN=len
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import inputstreamhelper
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
qkMdOncHWzaBfGvgeVASjFXCToJlUy=[{'title':'오직 쿠팡플레이에서','mode':'CATEGORY_LIST','vType':'ORIGINAL','collectionId':'5c33c5ca-ee6f-45f8-a026-dd789a8b63cf'},{'title':'홈   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'ALL'},{'title':'TV   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'MOVIES'},{'title':'키즈 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'KIDS'},{'title':'생중계','mode':'EVENT_GROUPLIST','vType':'LIVE'},{'title':'TV   (테마별)','mode':'THEME_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (테마별)','mode':'THEME_GROUPLIST','vType':'MOVIES'},{'title':'키즈 (테마별)','mode':'THEME_GROUPLIST','vType':'KIDS'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},{'title':'(쿠팡) 검색','mode':'LOCAL_SEARCH','icon':'search.png'},{'title':'(쿠팡) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
qkMdOncHWzaBfGvgeVASjFXCToJlUL=[{'title':'시리즈 시청내역','mode':'WATCH','stype':'tvshow'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},]
qkMdOncHWzaBfGvgeVASjFXCToJlUI={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
qkMdOncHWzaBfGvgeVASjFXCToJlUR=xbmcvfs.translatePath(os.path.join(__profile__,'coupang_searched.txt'))
from coupangCore import*
class qkMdOncHWzaBfGvgeVASjFXCToJlUu(qkMdOncHWzaBfGvgeVASjFXCToJlru):
 def __init__(qkMdOncHWzaBfGvgeVASjFXCToJlUr,qkMdOncHWzaBfGvgeVASjFXCToJlUb,qkMdOncHWzaBfGvgeVASjFXCToJlUQ,qkMdOncHWzaBfGvgeVASjFXCToJlUw):
  qkMdOncHWzaBfGvgeVASjFXCToJlUr._addon_url =qkMdOncHWzaBfGvgeVASjFXCToJlUb
  qkMdOncHWzaBfGvgeVASjFXCToJlUr._addon_handle=qkMdOncHWzaBfGvgeVASjFXCToJlUQ
  qkMdOncHWzaBfGvgeVASjFXCToJlUr.main_params =qkMdOncHWzaBfGvgeVASjFXCToJlUw
  qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj =folqeUbQJOXiWrIEzxsVNACvjuwgFd() 
  qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.CP_COOKIE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_cookies.json'))
  qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.CP_DEVICE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_device.json'))
 def addon_noti(qkMdOncHWzaBfGvgeVASjFXCToJlUr,sting):
  try:
   qkMdOncHWzaBfGvgeVASjFXCToJlUh=xbmcgui.Dialog()
   qkMdOncHWzaBfGvgeVASjFXCToJlUh.notification(__addonname__,sting)
  except:
   qkMdOncHWzaBfGvgeVASjFXCToJlry
 def addon_log(qkMdOncHWzaBfGvgeVASjFXCToJlUr,string):
  try:
   qkMdOncHWzaBfGvgeVASjFXCToJlUE=string.encode('utf-8','ignore')
  except:
   qkMdOncHWzaBfGvgeVASjFXCToJlUE='addonException: addon_log'
  qkMdOncHWzaBfGvgeVASjFXCToJlUY=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,qkMdOncHWzaBfGvgeVASjFXCToJlUE),level=qkMdOncHWzaBfGvgeVASjFXCToJlUY)
 def get_keyboard_input(qkMdOncHWzaBfGvgeVASjFXCToJlUr,qkMdOncHWzaBfGvgeVASjFXCToJluL):
  qkMdOncHWzaBfGvgeVASjFXCToJlUD=qkMdOncHWzaBfGvgeVASjFXCToJlry
  kb=xbmc.Keyboard()
  kb.setHeading(qkMdOncHWzaBfGvgeVASjFXCToJluL)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   qkMdOncHWzaBfGvgeVASjFXCToJlUD=kb.getText()
  return qkMdOncHWzaBfGvgeVASjFXCToJlUD
 def get_settings_account(qkMdOncHWzaBfGvgeVASjFXCToJlUr):
  qkMdOncHWzaBfGvgeVASjFXCToJlUN=__addon__.getSetting('id')
  qkMdOncHWzaBfGvgeVASjFXCToJlUi=__addon__.getSetting('pw')
  qkMdOncHWzaBfGvgeVASjFXCToJlUP=__addon__.getSetting('profile')
  return(qkMdOncHWzaBfGvgeVASjFXCToJlUN,qkMdOncHWzaBfGvgeVASjFXCToJlUi,qkMdOncHWzaBfGvgeVASjFXCToJlUP)
 def get_settings_exclusion21(qkMdOncHWzaBfGvgeVASjFXCToJlUr):
  qkMdOncHWzaBfGvgeVASjFXCToJlUK =__addon__.getSetting('exclusion21')
  if qkMdOncHWzaBfGvgeVASjFXCToJlUK=='false':
   return qkMdOncHWzaBfGvgeVASjFXCToJlrL
  else:
   return qkMdOncHWzaBfGvgeVASjFXCToJlrI
 def get_settings_totalsearch(qkMdOncHWzaBfGvgeVASjFXCToJlUr):
  qkMdOncHWzaBfGvgeVASjFXCToJlUm =qkMdOncHWzaBfGvgeVASjFXCToJlrI if __addon__.getSetting('local_search')=='true' else qkMdOncHWzaBfGvgeVASjFXCToJlrL
  qkMdOncHWzaBfGvgeVASjFXCToJlUs=qkMdOncHWzaBfGvgeVASjFXCToJlrI if __addon__.getSetting('local_history')=='true' else qkMdOncHWzaBfGvgeVASjFXCToJlrL
  qkMdOncHWzaBfGvgeVASjFXCToJlUt =qkMdOncHWzaBfGvgeVASjFXCToJlrI if __addon__.getSetting('total_search')=='true' else qkMdOncHWzaBfGvgeVASjFXCToJlrL
  qkMdOncHWzaBfGvgeVASjFXCToJlUp=qkMdOncHWzaBfGvgeVASjFXCToJlrI if __addon__.getSetting('total_history')=='true' else qkMdOncHWzaBfGvgeVASjFXCToJlrL
  qkMdOncHWzaBfGvgeVASjFXCToJluU=qkMdOncHWzaBfGvgeVASjFXCToJlrI if __addon__.getSetting('menu_bookmark')=='true' else qkMdOncHWzaBfGvgeVASjFXCToJlrL
  return(qkMdOncHWzaBfGvgeVASjFXCToJlUm,qkMdOncHWzaBfGvgeVASjFXCToJlUs,qkMdOncHWzaBfGvgeVASjFXCToJlUt,qkMdOncHWzaBfGvgeVASjFXCToJlUp,qkMdOncHWzaBfGvgeVASjFXCToJluU)
 def get_settings_makebookmark(qkMdOncHWzaBfGvgeVASjFXCToJlUr):
  return qkMdOncHWzaBfGvgeVASjFXCToJlrI if __addon__.getSetting('make_bookmark')=='true' else qkMdOncHWzaBfGvgeVASjFXCToJlrL
 def add_dir(qkMdOncHWzaBfGvgeVASjFXCToJlUr,label,sublabel='',img='',infoLabels=qkMdOncHWzaBfGvgeVASjFXCToJlry,isFolder=qkMdOncHWzaBfGvgeVASjFXCToJlrI,params='',isLink=qkMdOncHWzaBfGvgeVASjFXCToJlrL,ContextMenu=qkMdOncHWzaBfGvgeVASjFXCToJlry):
  qkMdOncHWzaBfGvgeVASjFXCToJluy='%s?%s'%(qkMdOncHWzaBfGvgeVASjFXCToJlUr._addon_url,urllib.parse.urlencode(params))
  if sublabel:qkMdOncHWzaBfGvgeVASjFXCToJluL='%s < %s >'%(label,sublabel)
  else: qkMdOncHWzaBfGvgeVASjFXCToJluL=label
  if not img:img='DefaultFolder.png'
  qkMdOncHWzaBfGvgeVASjFXCToJluI=xbmcgui.ListItem(qkMdOncHWzaBfGvgeVASjFXCToJluL)
  if qkMdOncHWzaBfGvgeVASjFXCToJlrR(img)==qkMdOncHWzaBfGvgeVASjFXCToJlrb:
   qkMdOncHWzaBfGvgeVASjFXCToJluI.setArt(img)
  else:
   qkMdOncHWzaBfGvgeVASjFXCToJluI.setArt({'thumb':img,'poster':img})
  if qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.KodiVersion>=20:
   if infoLabels:qkMdOncHWzaBfGvgeVASjFXCToJlUr.Set_InfoTag(qkMdOncHWzaBfGvgeVASjFXCToJluI.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:qkMdOncHWzaBfGvgeVASjFXCToJluI.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   qkMdOncHWzaBfGvgeVASjFXCToJluI.setProperty('IsPlayable','true')
  if ContextMenu:qkMdOncHWzaBfGvgeVASjFXCToJluI.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(qkMdOncHWzaBfGvgeVASjFXCToJlUr._addon_handle,qkMdOncHWzaBfGvgeVASjFXCToJluy,qkMdOncHWzaBfGvgeVASjFXCToJluI,isFolder)
 def Set_InfoTag(qkMdOncHWzaBfGvgeVASjFXCToJlUr,video_InfoTag:xbmc.InfoTagVideo,qkMdOncHWzaBfGvgeVASjFXCToJluE):
  for qkMdOncHWzaBfGvgeVASjFXCToJluR,value in qkMdOncHWzaBfGvgeVASjFXCToJluE.items():
   if qkMdOncHWzaBfGvgeVASjFXCToJlUI[qkMdOncHWzaBfGvgeVASjFXCToJluR]['type']=='string':
    qkMdOncHWzaBfGvgeVASjFXCToJlrQ(video_InfoTag,qkMdOncHWzaBfGvgeVASjFXCToJlUI[qkMdOncHWzaBfGvgeVASjFXCToJluR]['func'])(value)
   elif qkMdOncHWzaBfGvgeVASjFXCToJlUI[qkMdOncHWzaBfGvgeVASjFXCToJluR]['type']=='int':
    if qkMdOncHWzaBfGvgeVASjFXCToJlrR(value)==qkMdOncHWzaBfGvgeVASjFXCToJlrw:
     qkMdOncHWzaBfGvgeVASjFXCToJlur=qkMdOncHWzaBfGvgeVASjFXCToJlrw(value)
    else:
     qkMdOncHWzaBfGvgeVASjFXCToJlur=0
    qkMdOncHWzaBfGvgeVASjFXCToJlrQ(video_InfoTag,qkMdOncHWzaBfGvgeVASjFXCToJlUI[qkMdOncHWzaBfGvgeVASjFXCToJluR]['func'])(qkMdOncHWzaBfGvgeVASjFXCToJlur)
   elif qkMdOncHWzaBfGvgeVASjFXCToJlUI[qkMdOncHWzaBfGvgeVASjFXCToJluR]['type']=='actor':
    if value!=[]:
     qkMdOncHWzaBfGvgeVASjFXCToJlrQ(video_InfoTag,qkMdOncHWzaBfGvgeVASjFXCToJlUI[qkMdOncHWzaBfGvgeVASjFXCToJluR]['func'])([xbmc.Actor(name)for name in value])
   elif qkMdOncHWzaBfGvgeVASjFXCToJlUI[qkMdOncHWzaBfGvgeVASjFXCToJluR]['type']=='list':
    if qkMdOncHWzaBfGvgeVASjFXCToJlrR(value)==qkMdOncHWzaBfGvgeVASjFXCToJlrx:
     qkMdOncHWzaBfGvgeVASjFXCToJlrQ(video_InfoTag,qkMdOncHWzaBfGvgeVASjFXCToJlUI[qkMdOncHWzaBfGvgeVASjFXCToJluR]['func'])(value)
    else:
     qkMdOncHWzaBfGvgeVASjFXCToJlrQ(video_InfoTag,qkMdOncHWzaBfGvgeVASjFXCToJlUI[qkMdOncHWzaBfGvgeVASjFXCToJluR]['func'])([value])
 def dp_Main_List(qkMdOncHWzaBfGvgeVASjFXCToJlUr,args):
  (qkMdOncHWzaBfGvgeVASjFXCToJlUm,qkMdOncHWzaBfGvgeVASjFXCToJlUs,qkMdOncHWzaBfGvgeVASjFXCToJlUt,qkMdOncHWzaBfGvgeVASjFXCToJlUp,qkMdOncHWzaBfGvgeVASjFXCToJluU)=qkMdOncHWzaBfGvgeVASjFXCToJlUr.get_settings_totalsearch()
  for qkMdOncHWzaBfGvgeVASjFXCToJlub in qkMdOncHWzaBfGvgeVASjFXCToJlUy:
   qkMdOncHWzaBfGvgeVASjFXCToJluL=qkMdOncHWzaBfGvgeVASjFXCToJlub.get('title')
   qkMdOncHWzaBfGvgeVASjFXCToJluQ=''
   if qkMdOncHWzaBfGvgeVASjFXCToJlub.get('mode')=='LOCAL_SEARCH' and qkMdOncHWzaBfGvgeVASjFXCToJlUm ==qkMdOncHWzaBfGvgeVASjFXCToJlrL:continue
   elif qkMdOncHWzaBfGvgeVASjFXCToJlub.get('mode')=='SEARCH_HISTORY' and qkMdOncHWzaBfGvgeVASjFXCToJlUs==qkMdOncHWzaBfGvgeVASjFXCToJlrL:continue
   elif qkMdOncHWzaBfGvgeVASjFXCToJlub.get('mode')=='TOTAL_SEARCH' and qkMdOncHWzaBfGvgeVASjFXCToJlUt ==qkMdOncHWzaBfGvgeVASjFXCToJlrL:continue
   elif qkMdOncHWzaBfGvgeVASjFXCToJlub.get('mode')=='TOTAL_HISTORY' and qkMdOncHWzaBfGvgeVASjFXCToJlUp==qkMdOncHWzaBfGvgeVASjFXCToJlrL:continue
   elif qkMdOncHWzaBfGvgeVASjFXCToJlub.get('mode')=='MENU_BOOKMARK' and qkMdOncHWzaBfGvgeVASjFXCToJluU==qkMdOncHWzaBfGvgeVASjFXCToJlrL:continue
   qkMdOncHWzaBfGvgeVASjFXCToJluw={'mode':qkMdOncHWzaBfGvgeVASjFXCToJlub.get('mode'),'vType':qkMdOncHWzaBfGvgeVASjFXCToJlub.get('vType'),'collectionId':qkMdOncHWzaBfGvgeVASjFXCToJlub.get('collectionId'),'page':'1',}
   if qkMdOncHWzaBfGvgeVASjFXCToJlub.get('mode')=='LOCAL_SEARCH':qkMdOncHWzaBfGvgeVASjFXCToJluw['historyyn']='Y' 
   if qkMdOncHWzaBfGvgeVASjFXCToJlub.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    qkMdOncHWzaBfGvgeVASjFXCToJlux=qkMdOncHWzaBfGvgeVASjFXCToJlrL
    qkMdOncHWzaBfGvgeVASjFXCToJluh =qkMdOncHWzaBfGvgeVASjFXCToJlrI
   else:
    qkMdOncHWzaBfGvgeVASjFXCToJlux=qkMdOncHWzaBfGvgeVASjFXCToJlrI
    qkMdOncHWzaBfGvgeVASjFXCToJluh =qkMdOncHWzaBfGvgeVASjFXCToJlrL
   qkMdOncHWzaBfGvgeVASjFXCToJluE={'title':qkMdOncHWzaBfGvgeVASjFXCToJluL,'plot':qkMdOncHWzaBfGvgeVASjFXCToJluL}
   if qkMdOncHWzaBfGvgeVASjFXCToJlub.get('mode')=='XXX':qkMdOncHWzaBfGvgeVASjFXCToJluE=qkMdOncHWzaBfGvgeVASjFXCToJlry
   if 'icon' in qkMdOncHWzaBfGvgeVASjFXCToJlub:qkMdOncHWzaBfGvgeVASjFXCToJluQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',qkMdOncHWzaBfGvgeVASjFXCToJlub.get('icon')) 
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.add_dir(qkMdOncHWzaBfGvgeVASjFXCToJluL,sublabel='',img=qkMdOncHWzaBfGvgeVASjFXCToJluQ,infoLabels=qkMdOncHWzaBfGvgeVASjFXCToJluE,isFolder=qkMdOncHWzaBfGvgeVASjFXCToJlux,params=qkMdOncHWzaBfGvgeVASjFXCToJluw,isLink=qkMdOncHWzaBfGvgeVASjFXCToJluh)
  xbmcplugin.endOfDirectory(qkMdOncHWzaBfGvgeVASjFXCToJlUr._addon_handle)
 def dp_Test(qkMdOncHWzaBfGvgeVASjFXCToJlUr,args):
  qkMdOncHWzaBfGvgeVASjFXCToJlUr.addon_noti('test')
 def CP_logout(qkMdOncHWzaBfGvgeVASjFXCToJlUr):
  qkMdOncHWzaBfGvgeVASjFXCToJlUh=xbmcgui.Dialog()
  qkMdOncHWzaBfGvgeVASjFXCToJluD=qkMdOncHWzaBfGvgeVASjFXCToJlUh.yesno(__language__(30905).encode('utf8'),__language__(30906).encode('utf8'))
  if qkMdOncHWzaBfGvgeVASjFXCToJluD==qkMdOncHWzaBfGvgeVASjFXCToJlrL:return 
  if os.path.isfile(qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.CP_COOKIE_FILENAME):os.remove(qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.CP_COOKIE_FILENAME)
  qkMdOncHWzaBfGvgeVASjFXCToJlUr.addon_noti(__language__(30904).encode('utf-8'))
 def option_check(qkMdOncHWzaBfGvgeVASjFXCToJlUr):
  (qkMdOncHWzaBfGvgeVASjFXCToJlUN,qkMdOncHWzaBfGvgeVASjFXCToJlUi,qkMdOncHWzaBfGvgeVASjFXCToJlUP)=qkMdOncHWzaBfGvgeVASjFXCToJlUr.get_settings_account()
  if qkMdOncHWzaBfGvgeVASjFXCToJlUN=='' or qkMdOncHWzaBfGvgeVASjFXCToJlUi=='':
   qkMdOncHWzaBfGvgeVASjFXCToJlUh=xbmcgui.Dialog()
   qkMdOncHWzaBfGvgeVASjFXCToJluD=qkMdOncHWzaBfGvgeVASjFXCToJlUh.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if qkMdOncHWzaBfGvgeVASjFXCToJluD==qkMdOncHWzaBfGvgeVASjFXCToJlrI:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if qkMdOncHWzaBfGvgeVASjFXCToJlUr.cookiefile_check()==qkMdOncHWzaBfGvgeVASjFXCToJlrL:
   if qkMdOncHWzaBfGvgeVASjFXCToJlUr.CP_login(qkMdOncHWzaBfGvgeVASjFXCToJlUN,qkMdOncHWzaBfGvgeVASjFXCToJlUi,qkMdOncHWzaBfGvgeVASjFXCToJlUP)==qkMdOncHWzaBfGvgeVASjFXCToJlrL:
    qkMdOncHWzaBfGvgeVASjFXCToJlUr.addon_noti(__language__(30903).encode('utf8'))
    sys.exit()
  else:
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.Get_CP_profile(qkMdOncHWzaBfGvgeVASjFXCToJlUP,limit_days=qkMdOncHWzaBfGvgeVASjFXCToJlrw(__addon__.getSetting('cache_ttl')),re_check=qkMdOncHWzaBfGvgeVASjFXCToJlrI)
 def cookiefile_check(qkMdOncHWzaBfGvgeVASjFXCToJlUr):
  qkMdOncHWzaBfGvgeVASjFXCToJlui={}
  try: 
   fp=qkMdOncHWzaBfGvgeVASjFXCToJlrh(qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.CP_COOKIE_FILENAME,'r',-1,'utf-8')
   qkMdOncHWzaBfGvgeVASjFXCToJlui= json.load(fp)
   fp.close()
  except qkMdOncHWzaBfGvgeVASjFXCToJlrE as exception:
   return qkMdOncHWzaBfGvgeVASjFXCToJlrL
  qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.CP=qkMdOncHWzaBfGvgeVASjFXCToJlui
  (qkMdOncHWzaBfGvgeVASjFXCToJlUN,qkMdOncHWzaBfGvgeVASjFXCToJlUi,qkMdOncHWzaBfGvgeVASjFXCToJlUP)=qkMdOncHWzaBfGvgeVASjFXCToJlUr.get_settings_account()
  (qkMdOncHWzaBfGvgeVASjFXCToJluP,qkMdOncHWzaBfGvgeVASjFXCToJluK,qkMdOncHWzaBfGvgeVASjFXCToJlum)=qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.Load_session_acount()
  if qkMdOncHWzaBfGvgeVASjFXCToJlUN!=qkMdOncHWzaBfGvgeVASjFXCToJluP or qkMdOncHWzaBfGvgeVASjFXCToJlUi!=qkMdOncHWzaBfGvgeVASjFXCToJluK or qkMdOncHWzaBfGvgeVASjFXCToJlUP!=qkMdOncHWzaBfGvgeVASjFXCToJlrY(qkMdOncHWzaBfGvgeVASjFXCToJlum):
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.Init_CP()
   return qkMdOncHWzaBfGvgeVASjFXCToJlrL
  qkMdOncHWzaBfGvgeVASjFXCToJlus =qkMdOncHWzaBfGvgeVASjFXCToJlrw(qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.Get_Now_Datetime().strftime('%Y%m%d'))
  qkMdOncHWzaBfGvgeVASjFXCToJlut=qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.CP['SESSION']['limitdate']
  qkMdOncHWzaBfGvgeVASjFXCToJlup =qkMdOncHWzaBfGvgeVASjFXCToJlrw(re.sub('-','',qkMdOncHWzaBfGvgeVASjFXCToJlut))
  if qkMdOncHWzaBfGvgeVASjFXCToJlup<qkMdOncHWzaBfGvgeVASjFXCToJlus:
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.Init_CP()
   return qkMdOncHWzaBfGvgeVASjFXCToJlrL
  return qkMdOncHWzaBfGvgeVASjFXCToJlrI
 def CP_login(qkMdOncHWzaBfGvgeVASjFXCToJlUr,qkMdOncHWzaBfGvgeVASjFXCToJlUN,qkMdOncHWzaBfGvgeVASjFXCToJlUi,qkMdOncHWzaBfGvgeVASjFXCToJlUP):
  if qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.Get_CP_Login(qkMdOncHWzaBfGvgeVASjFXCToJlUN,qkMdOncHWzaBfGvgeVASjFXCToJlUi,qkMdOncHWzaBfGvgeVASjFXCToJlUP)==qkMdOncHWzaBfGvgeVASjFXCToJlrL:return qkMdOncHWzaBfGvgeVASjFXCToJlrL
  if qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.Get_CP_profile(qkMdOncHWzaBfGvgeVASjFXCToJlUP,limit_days=qkMdOncHWzaBfGvgeVASjFXCToJlrw(__addon__.getSetting('cache_ttl')),re_check=qkMdOncHWzaBfGvgeVASjFXCToJlrL)==qkMdOncHWzaBfGvgeVASjFXCToJlrL:return qkMdOncHWzaBfGvgeVASjFXCToJlrL
  return qkMdOncHWzaBfGvgeVASjFXCToJlrI
 def dp_Category_GroupList(qkMdOncHWzaBfGvgeVASjFXCToJlUr,args):
  qkMdOncHWzaBfGvgeVASjFXCToJlyU =args.get('vType') 
  qkMdOncHWzaBfGvgeVASjFXCToJlyu=qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.Get_Category_GroupList(qkMdOncHWzaBfGvgeVASjFXCToJlyU)
  for qkMdOncHWzaBfGvgeVASjFXCToJlyL in qkMdOncHWzaBfGvgeVASjFXCToJlyu:
   qkMdOncHWzaBfGvgeVASjFXCToJluL =qkMdOncHWzaBfGvgeVASjFXCToJlyL.get('title')
   qkMdOncHWzaBfGvgeVASjFXCToJlyI=qkMdOncHWzaBfGvgeVASjFXCToJlyL.get('pre_title')
   if qkMdOncHWzaBfGvgeVASjFXCToJlUr.get_settings_exclusion21()==qkMdOncHWzaBfGvgeVASjFXCToJlrI and qkMdOncHWzaBfGvgeVASjFXCToJluL=='성인':continue
   qkMdOncHWzaBfGvgeVASjFXCToJlyR={'mediatype':'tvshow','plot':qkMdOncHWzaBfGvgeVASjFXCToJlyI,}
   qkMdOncHWzaBfGvgeVASjFXCToJluw={'mode':'CATEGORY_LIST','collectionId':qkMdOncHWzaBfGvgeVASjFXCToJlyL.get('collectionId'),'vType':qkMdOncHWzaBfGvgeVASjFXCToJlyL.get('category'),'page':'1',}
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.add_dir(qkMdOncHWzaBfGvgeVASjFXCToJluL,sublabel='',img='',infoLabels=qkMdOncHWzaBfGvgeVASjFXCToJlyR,isFolder=qkMdOncHWzaBfGvgeVASjFXCToJlrI,params=qkMdOncHWzaBfGvgeVASjFXCToJluw)
  xbmcplugin.endOfDirectory(qkMdOncHWzaBfGvgeVASjFXCToJlUr._addon_handle,cacheToDisc=qkMdOncHWzaBfGvgeVASjFXCToJlrL)
 def dp_Theme_GroupList(qkMdOncHWzaBfGvgeVASjFXCToJlUr,args):
  qkMdOncHWzaBfGvgeVASjFXCToJlyU =args.get('vType') 
  qkMdOncHWzaBfGvgeVASjFXCToJlyu=qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.Get_Theme_GroupList(qkMdOncHWzaBfGvgeVASjFXCToJlyU)
  for qkMdOncHWzaBfGvgeVASjFXCToJlyL in qkMdOncHWzaBfGvgeVASjFXCToJlyu:
   qkMdOncHWzaBfGvgeVASjFXCToJluL =qkMdOncHWzaBfGvgeVASjFXCToJlyL.get('title')
   qkMdOncHWzaBfGvgeVASjFXCToJlyI=qkMdOncHWzaBfGvgeVASjFXCToJlyL.get('pre_title')
   qkMdOncHWzaBfGvgeVASjFXCToJlyR={'mediatype':'tvshow','plot':qkMdOncHWzaBfGvgeVASjFXCToJlyI,}
   qkMdOncHWzaBfGvgeVASjFXCToJluw={'mode':'CATEGORY_LIST','collectionId':qkMdOncHWzaBfGvgeVASjFXCToJlyL.get('collectionId'),'vType':qkMdOncHWzaBfGvgeVASjFXCToJlyL.get('category'),'page':'1',}
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.add_dir(qkMdOncHWzaBfGvgeVASjFXCToJluL,sublabel='',img='',infoLabels=qkMdOncHWzaBfGvgeVASjFXCToJlyR,isFolder=qkMdOncHWzaBfGvgeVASjFXCToJlrI,params=qkMdOncHWzaBfGvgeVASjFXCToJluw)
  xbmcplugin.endOfDirectory(qkMdOncHWzaBfGvgeVASjFXCToJlUr._addon_handle,cacheToDisc=qkMdOncHWzaBfGvgeVASjFXCToJlrL)
 def dp_Event_GroupList(qkMdOncHWzaBfGvgeVASjFXCToJlUr,args):
  qkMdOncHWzaBfGvgeVASjFXCToJlyu=qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.Get_Event_GroupList()
  for qkMdOncHWzaBfGvgeVASjFXCToJlyL in qkMdOncHWzaBfGvgeVASjFXCToJlyu:
   qkMdOncHWzaBfGvgeVASjFXCToJluL =qkMdOncHWzaBfGvgeVASjFXCToJlyL.get('title')
   qkMdOncHWzaBfGvgeVASjFXCToJlyI=qkMdOncHWzaBfGvgeVASjFXCToJlyL.get('pre_title')
   qkMdOncHWzaBfGvgeVASjFXCToJlyR={'mediatype':'tvshow','plot':qkMdOncHWzaBfGvgeVASjFXCToJlyI,}
   qkMdOncHWzaBfGvgeVASjFXCToJluw={'mode':'EVENT_GAMELIST','collectionId':qkMdOncHWzaBfGvgeVASjFXCToJlyL.get('collectionId'),'vType':'LIVE',}
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.add_dir(qkMdOncHWzaBfGvgeVASjFXCToJluL,sublabel='',img='',infoLabels=qkMdOncHWzaBfGvgeVASjFXCToJlyR,isFolder=qkMdOncHWzaBfGvgeVASjFXCToJlrI,params=qkMdOncHWzaBfGvgeVASjFXCToJluw)
  xbmcplugin.endOfDirectory(qkMdOncHWzaBfGvgeVASjFXCToJlUr._addon_handle,cacheToDisc=qkMdOncHWzaBfGvgeVASjFXCToJlrL)
 def dp_Event_GameList(qkMdOncHWzaBfGvgeVASjFXCToJlUr,args):
  qkMdOncHWzaBfGvgeVASjFXCToJlyU =args.get('vType') 
  qkMdOncHWzaBfGvgeVASjFXCToJlyb =args.get('collectionId')
  qkMdOncHWzaBfGvgeVASjFXCToJlyu=qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.Get_Event_GameList(qkMdOncHWzaBfGvgeVASjFXCToJlyb)
  for qkMdOncHWzaBfGvgeVASjFXCToJlyL in qkMdOncHWzaBfGvgeVASjFXCToJlyu:
   qkMdOncHWzaBfGvgeVASjFXCToJluL =qkMdOncHWzaBfGvgeVASjFXCToJlyL.get('title')
   qkMdOncHWzaBfGvgeVASjFXCToJlrD =qkMdOncHWzaBfGvgeVASjFXCToJlyL.get('id')
   qkMdOncHWzaBfGvgeVASjFXCToJlyQ =qkMdOncHWzaBfGvgeVASjFXCToJlyL.get('thumbnail')
   qkMdOncHWzaBfGvgeVASjFXCToJlyw =qkMdOncHWzaBfGvgeVASjFXCToJlyL.get('asis') 
   qkMdOncHWzaBfGvgeVASjFXCToJlyx =qkMdOncHWzaBfGvgeVASjFXCToJlyL.get('addInfo')
   qkMdOncHWzaBfGvgeVASjFXCToJlyh =qkMdOncHWzaBfGvgeVASjFXCToJlyL.get('starttm')
   qkMdOncHWzaBfGvgeVASjFXCToJlyR={'mediatype':'tvshow','title':qkMdOncHWzaBfGvgeVASjFXCToJluL,'plot':qkMdOncHWzaBfGvgeVASjFXCToJlyx,}
   qkMdOncHWzaBfGvgeVASjFXCToJluw={'mode':'EVENT_LIST','id':qkMdOncHWzaBfGvgeVASjFXCToJlrD,'asis':qkMdOncHWzaBfGvgeVASjFXCToJlyw,'title':qkMdOncHWzaBfGvgeVASjFXCToJluL,}
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.add_dir(qkMdOncHWzaBfGvgeVASjFXCToJluL,sublabel=qkMdOncHWzaBfGvgeVASjFXCToJlyh,img=qkMdOncHWzaBfGvgeVASjFXCToJlyQ,infoLabels=qkMdOncHWzaBfGvgeVASjFXCToJlyR,isFolder=qkMdOncHWzaBfGvgeVASjFXCToJlrI,params=qkMdOncHWzaBfGvgeVASjFXCToJluw,ContextMenu=qkMdOncHWzaBfGvgeVASjFXCToJlry)
  xbmcplugin.setContent(qkMdOncHWzaBfGvgeVASjFXCToJlUr._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(qkMdOncHWzaBfGvgeVASjFXCToJlUr._addon_handle,cacheToDisc=qkMdOncHWzaBfGvgeVASjFXCToJlrL)
 def dp_Event_List(qkMdOncHWzaBfGvgeVASjFXCToJlUr,args):
  qkMdOncHWzaBfGvgeVASjFXCToJlyE=args.get('id')
  qkMdOncHWzaBfGvgeVASjFXCToJlyu=qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.Get_Event_List(qkMdOncHWzaBfGvgeVASjFXCToJlyE)
  for qkMdOncHWzaBfGvgeVASjFXCToJlyL in qkMdOncHWzaBfGvgeVASjFXCToJlyu:
   qkMdOncHWzaBfGvgeVASjFXCToJluL =qkMdOncHWzaBfGvgeVASjFXCToJlyL.get('title')
   qkMdOncHWzaBfGvgeVASjFXCToJlrD =qkMdOncHWzaBfGvgeVASjFXCToJlyL.get('id')
   qkMdOncHWzaBfGvgeVASjFXCToJlyQ =qkMdOncHWzaBfGvgeVASjFXCToJlyL.get('thumbnail')
   qkMdOncHWzaBfGvgeVASjFXCToJlyw =qkMdOncHWzaBfGvgeVASjFXCToJlyL.get('asis') 
   qkMdOncHWzaBfGvgeVASjFXCToJlyY =qkMdOncHWzaBfGvgeVASjFXCToJlyL.get('duration')
   qkMdOncHWzaBfGvgeVASjFXCToJlyh =qkMdOncHWzaBfGvgeVASjFXCToJlyL.get('starttm')
   qkMdOncHWzaBfGvgeVASjFXCToJlyR={'mediatype':'episode','title':qkMdOncHWzaBfGvgeVASjFXCToJluL,'plot':qkMdOncHWzaBfGvgeVASjFXCToJlyw,'duration':qkMdOncHWzaBfGvgeVASjFXCToJlyY,}
   qkMdOncHWzaBfGvgeVASjFXCToJluw={'mode':qkMdOncHWzaBfGvgeVASjFXCToJlyw,'id':qkMdOncHWzaBfGvgeVASjFXCToJlrD,'asis':qkMdOncHWzaBfGvgeVASjFXCToJlyw,'title':qkMdOncHWzaBfGvgeVASjFXCToJluL,}
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.add_dir(qkMdOncHWzaBfGvgeVASjFXCToJluL,sublabel=qkMdOncHWzaBfGvgeVASjFXCToJlyh,img=qkMdOncHWzaBfGvgeVASjFXCToJlyQ,infoLabels=qkMdOncHWzaBfGvgeVASjFXCToJlyR,isFolder=qkMdOncHWzaBfGvgeVASjFXCToJlrL,params=qkMdOncHWzaBfGvgeVASjFXCToJluw,ContextMenu=qkMdOncHWzaBfGvgeVASjFXCToJlry)
  xbmcplugin.setContent(qkMdOncHWzaBfGvgeVASjFXCToJlUr._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(qkMdOncHWzaBfGvgeVASjFXCToJlUr._addon_handle,cacheToDisc=qkMdOncHWzaBfGvgeVASjFXCToJlrL)
 def dp_Category_List(qkMdOncHWzaBfGvgeVASjFXCToJlUr,args):
  qkMdOncHWzaBfGvgeVASjFXCToJlyU =args.get('vType') 
  qkMdOncHWzaBfGvgeVASjFXCToJlyb =args.get('collectionId')
  qkMdOncHWzaBfGvgeVASjFXCToJlyD =qkMdOncHWzaBfGvgeVASjFXCToJlrw(args.get('page'))
  qkMdOncHWzaBfGvgeVASjFXCToJlyu,qkMdOncHWzaBfGvgeVASjFXCToJlyN=qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.Get_Category_List(qkMdOncHWzaBfGvgeVASjFXCToJlyU,qkMdOncHWzaBfGvgeVASjFXCToJlyb,qkMdOncHWzaBfGvgeVASjFXCToJlyD)
  for qkMdOncHWzaBfGvgeVASjFXCToJlyL in qkMdOncHWzaBfGvgeVASjFXCToJlyu:
   qkMdOncHWzaBfGvgeVASjFXCToJluL =qkMdOncHWzaBfGvgeVASjFXCToJlyL.get('title')
   qkMdOncHWzaBfGvgeVASjFXCToJlrD =qkMdOncHWzaBfGvgeVASjFXCToJlyL.get('id')
   qkMdOncHWzaBfGvgeVASjFXCToJlyQ =qkMdOncHWzaBfGvgeVASjFXCToJlyL.get('thumbnail')
   qkMdOncHWzaBfGvgeVASjFXCToJlyi =qkMdOncHWzaBfGvgeVASjFXCToJlyL.get('mpaa')
   qkMdOncHWzaBfGvgeVASjFXCToJlyY =qkMdOncHWzaBfGvgeVASjFXCToJlyL.get('duration')
   qkMdOncHWzaBfGvgeVASjFXCToJlyw =qkMdOncHWzaBfGvgeVASjFXCToJlyL.get('asis')
   qkMdOncHWzaBfGvgeVASjFXCToJlyP =qkMdOncHWzaBfGvgeVASjFXCToJlyL.get('badge')
   qkMdOncHWzaBfGvgeVASjFXCToJlyK =qkMdOncHWzaBfGvgeVASjFXCToJlyL.get('year')
   qkMdOncHWzaBfGvgeVASjFXCToJlym=qkMdOncHWzaBfGvgeVASjFXCToJlyL.get('seasonList')
   qkMdOncHWzaBfGvgeVASjFXCToJlys =qkMdOncHWzaBfGvgeVASjFXCToJlyL.get('genreList')
   if qkMdOncHWzaBfGvgeVASjFXCToJlyw in['TVSHOW','EDUCATION']: 
    qkMdOncHWzaBfGvgeVASjFXCToJlyt ='SEASON_LIST'
    qkMdOncHWzaBfGvgeVASjFXCToJlyR={'mediatype':'tvshow','title':qkMdOncHWzaBfGvgeVASjFXCToJluL,'mpaa':qkMdOncHWzaBfGvgeVASjFXCToJlyi,'genre':qkMdOncHWzaBfGvgeVASjFXCToJlys,'year':qkMdOncHWzaBfGvgeVASjFXCToJlyK,'plot':'Year : %s\nSeason : %s'%(qkMdOncHWzaBfGvgeVASjFXCToJlyK,qkMdOncHWzaBfGvgeVASjFXCToJlym),}
    qkMdOncHWzaBfGvgeVASjFXCToJlux =qkMdOncHWzaBfGvgeVASjFXCToJlrI
   else:
    qkMdOncHWzaBfGvgeVASjFXCToJlyt ='MOVIE'
    qkMdOncHWzaBfGvgeVASjFXCToJlyR={'mediatype':'movie','title':qkMdOncHWzaBfGvgeVASjFXCToJluL,'mpaa':qkMdOncHWzaBfGvgeVASjFXCToJlyi,'genre':qkMdOncHWzaBfGvgeVASjFXCToJlys,'duration':qkMdOncHWzaBfGvgeVASjFXCToJlyY,'year':qkMdOncHWzaBfGvgeVASjFXCToJlyK,'plot':'(%s)'%(qkMdOncHWzaBfGvgeVASjFXCToJlyi),}
    qkMdOncHWzaBfGvgeVASjFXCToJlux =qkMdOncHWzaBfGvgeVASjFXCToJlrL
    qkMdOncHWzaBfGvgeVASjFXCToJluL +=' (%s)'%(qkMdOncHWzaBfGvgeVASjFXCToJlrY(qkMdOncHWzaBfGvgeVASjFXCToJlyK))
   qkMdOncHWzaBfGvgeVASjFXCToJluw={'mode':qkMdOncHWzaBfGvgeVASjFXCToJlyt,'id':qkMdOncHWzaBfGvgeVASjFXCToJlrD,'asis':qkMdOncHWzaBfGvgeVASjFXCToJlyw,'seasonList':qkMdOncHWzaBfGvgeVASjFXCToJlym,'title':qkMdOncHWzaBfGvgeVASjFXCToJluL,'thumbnail':qkMdOncHWzaBfGvgeVASjFXCToJlyQ,'year':qkMdOncHWzaBfGvgeVASjFXCToJlyK,}
   if qkMdOncHWzaBfGvgeVASjFXCToJlUr.get_settings_makebookmark():
    qkMdOncHWzaBfGvgeVASjFXCToJlyp={'videoid':qkMdOncHWzaBfGvgeVASjFXCToJlrD,'vidtype':'movie' if qkMdOncHWzaBfGvgeVASjFXCToJlyU=='MOVIES' else 'tvshow','vtitle':qkMdOncHWzaBfGvgeVASjFXCToJluL,'vsubtitle':'',}
    qkMdOncHWzaBfGvgeVASjFXCToJlLU=json.dumps(qkMdOncHWzaBfGvgeVASjFXCToJlyp)
    qkMdOncHWzaBfGvgeVASjFXCToJlLU=urllib.parse.quote(qkMdOncHWzaBfGvgeVASjFXCToJlLU)
    qkMdOncHWzaBfGvgeVASjFXCToJlLu='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(qkMdOncHWzaBfGvgeVASjFXCToJlLU)
    qkMdOncHWzaBfGvgeVASjFXCToJlLy=[('(통합) 찜 영상에 추가',qkMdOncHWzaBfGvgeVASjFXCToJlLu)]
   else:
    qkMdOncHWzaBfGvgeVASjFXCToJlLy=qkMdOncHWzaBfGvgeVASjFXCToJlry
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.add_dir(qkMdOncHWzaBfGvgeVASjFXCToJluL,sublabel=qkMdOncHWzaBfGvgeVASjFXCToJlyP,img=qkMdOncHWzaBfGvgeVASjFXCToJlyQ,infoLabels=qkMdOncHWzaBfGvgeVASjFXCToJlyR,isFolder=qkMdOncHWzaBfGvgeVASjFXCToJlux,params=qkMdOncHWzaBfGvgeVASjFXCToJluw,ContextMenu=qkMdOncHWzaBfGvgeVASjFXCToJlLy)
  if qkMdOncHWzaBfGvgeVASjFXCToJlyN:
   qkMdOncHWzaBfGvgeVASjFXCToJluw['mode'] ='CATEGORY_LIST' 
   qkMdOncHWzaBfGvgeVASjFXCToJluw['collectionId']=qkMdOncHWzaBfGvgeVASjFXCToJlyb 
   qkMdOncHWzaBfGvgeVASjFXCToJluw['vType'] =qkMdOncHWzaBfGvgeVASjFXCToJlyU 
   qkMdOncHWzaBfGvgeVASjFXCToJluw['page'] =qkMdOncHWzaBfGvgeVASjFXCToJlrY(qkMdOncHWzaBfGvgeVASjFXCToJlyD+1)
   qkMdOncHWzaBfGvgeVASjFXCToJluL='[B]%s >>[/B]'%'다음 페이지'
   qkMdOncHWzaBfGvgeVASjFXCToJlLI=qkMdOncHWzaBfGvgeVASjFXCToJlrY(qkMdOncHWzaBfGvgeVASjFXCToJlyD+1)
   qkMdOncHWzaBfGvgeVASjFXCToJluQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.add_dir(qkMdOncHWzaBfGvgeVASjFXCToJluL,sublabel=qkMdOncHWzaBfGvgeVASjFXCToJlLI,img=qkMdOncHWzaBfGvgeVASjFXCToJluQ,infoLabels=qkMdOncHWzaBfGvgeVASjFXCToJlry,isFolder=qkMdOncHWzaBfGvgeVASjFXCToJlrI,params=qkMdOncHWzaBfGvgeVASjFXCToJluw)
  if qkMdOncHWzaBfGvgeVASjFXCToJlyU=='TVSHOWS':xbmcplugin.setContent(qkMdOncHWzaBfGvgeVASjFXCToJlUr._addon_handle,'tvshows')
  else:xbmcplugin.setContent(qkMdOncHWzaBfGvgeVASjFXCToJlUr._addon_handle,'movies')
  xbmcplugin.endOfDirectory(qkMdOncHWzaBfGvgeVASjFXCToJlUr._addon_handle,cacheToDisc=qkMdOncHWzaBfGvgeVASjFXCToJlrL)
 def dp_Season_List(qkMdOncHWzaBfGvgeVASjFXCToJlUr,args):
  qkMdOncHWzaBfGvgeVASjFXCToJlLR =args.get('title')
  qkMdOncHWzaBfGvgeVASjFXCToJlLr =args.get('id')
  qkMdOncHWzaBfGvgeVASjFXCToJlyw =args.get('asis')
  qkMdOncHWzaBfGvgeVASjFXCToJlym =args.get('seasonList')
  qkMdOncHWzaBfGvgeVASjFXCToJlyQ =args.get('thumbnail')
  qkMdOncHWzaBfGvgeVASjFXCToJlyK =args.get('year')
  if qkMdOncHWzaBfGvgeVASjFXCToJlym in['',qkMdOncHWzaBfGvgeVASjFXCToJlry]:
   qkMdOncHWzaBfGvgeVASjFXCToJlym=qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.Get_vInfo(qkMdOncHWzaBfGvgeVASjFXCToJlLr).get('seasonList')
  if qkMdOncHWzaBfGvgeVASjFXCToJlrN(qkMdOncHWzaBfGvgeVASjFXCToJlym.split(','))>1:
   for qkMdOncHWzaBfGvgeVASjFXCToJlLb in qkMdOncHWzaBfGvgeVASjFXCToJlym.split(','):
    qkMdOncHWzaBfGvgeVASjFXCToJluL='시즌 '+qkMdOncHWzaBfGvgeVASjFXCToJlLb
    qkMdOncHWzaBfGvgeVASjFXCToJlyR={'mediatype':'tvshow','plot':'%s (%s)'%(qkMdOncHWzaBfGvgeVASjFXCToJlLR,qkMdOncHWzaBfGvgeVASjFXCToJlyK),}
    qkMdOncHWzaBfGvgeVASjFXCToJluw={'mode':'EPISODE_LIST','programid':qkMdOncHWzaBfGvgeVASjFXCToJlLr,'programnm':qkMdOncHWzaBfGvgeVASjFXCToJlLR,'season':qkMdOncHWzaBfGvgeVASjFXCToJlLb,'asis':qkMdOncHWzaBfGvgeVASjFXCToJlyw,'programimg':qkMdOncHWzaBfGvgeVASjFXCToJlyQ,}
    qkMdOncHWzaBfGvgeVASjFXCToJlLQ=qkMdOncHWzaBfGvgeVASjFXCToJlyQ.replace('\'','\"')
    qkMdOncHWzaBfGvgeVASjFXCToJlLQ=json.loads(qkMdOncHWzaBfGvgeVASjFXCToJlLQ)
    qkMdOncHWzaBfGvgeVASjFXCToJlUr.add_dir(qkMdOncHWzaBfGvgeVASjFXCToJluL,sublabel='',img=qkMdOncHWzaBfGvgeVASjFXCToJlLQ,infoLabels=qkMdOncHWzaBfGvgeVASjFXCToJlyR,isFolder=qkMdOncHWzaBfGvgeVASjFXCToJlrI,params=qkMdOncHWzaBfGvgeVASjFXCToJluw)
   xbmcplugin.setContent(qkMdOncHWzaBfGvgeVASjFXCToJlUr._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(qkMdOncHWzaBfGvgeVASjFXCToJlUr._addon_handle,cacheToDisc=qkMdOncHWzaBfGvgeVASjFXCToJlrL)
  else:
   qkMdOncHWzaBfGvgeVASjFXCToJlLw={'programid':qkMdOncHWzaBfGvgeVASjFXCToJlLr,'programnm':qkMdOncHWzaBfGvgeVASjFXCToJlLR,'season':qkMdOncHWzaBfGvgeVASjFXCToJlym,'programimg':qkMdOncHWzaBfGvgeVASjFXCToJlyQ,}
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.dp_Episode_List(qkMdOncHWzaBfGvgeVASjFXCToJlLw)
 def dp_Episode_List(qkMdOncHWzaBfGvgeVASjFXCToJlUr,args):
  qkMdOncHWzaBfGvgeVASjFXCToJlLr =args.get('programid')
  qkMdOncHWzaBfGvgeVASjFXCToJlLR =args.get('programnm')
  qkMdOncHWzaBfGvgeVASjFXCToJlLx =args.get('season')
  qkMdOncHWzaBfGvgeVASjFXCToJlLh =args.get('programimg')
  qkMdOncHWzaBfGvgeVASjFXCToJlLE=qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.Get_Episode_List(qkMdOncHWzaBfGvgeVASjFXCToJlLr,qkMdOncHWzaBfGvgeVASjFXCToJlLx)
  for qkMdOncHWzaBfGvgeVASjFXCToJlLb in qkMdOncHWzaBfGvgeVASjFXCToJlLE:
   qkMdOncHWzaBfGvgeVASjFXCToJlLY =qkMdOncHWzaBfGvgeVASjFXCToJlLb.get('title')
   qkMdOncHWzaBfGvgeVASjFXCToJlLD =qkMdOncHWzaBfGvgeVASjFXCToJlLb.get('id')
   qkMdOncHWzaBfGvgeVASjFXCToJlyw =qkMdOncHWzaBfGvgeVASjFXCToJlLb.get('asis')
   qkMdOncHWzaBfGvgeVASjFXCToJlyQ =qkMdOncHWzaBfGvgeVASjFXCToJlLb.get('thumbnail')
   qkMdOncHWzaBfGvgeVASjFXCToJlyi =qkMdOncHWzaBfGvgeVASjFXCToJlLb.get('mpaa')
   qkMdOncHWzaBfGvgeVASjFXCToJlyY =qkMdOncHWzaBfGvgeVASjFXCToJlLb.get('duration')
   qkMdOncHWzaBfGvgeVASjFXCToJlyK =qkMdOncHWzaBfGvgeVASjFXCToJlLb.get('year')
   qkMdOncHWzaBfGvgeVASjFXCToJlLN =qkMdOncHWzaBfGvgeVASjFXCToJlLb.get('episode')
   qkMdOncHWzaBfGvgeVASjFXCToJlys =qkMdOncHWzaBfGvgeVASjFXCToJlLb.get('genreList')
   qkMdOncHWzaBfGvgeVASjFXCToJlLi =qkMdOncHWzaBfGvgeVASjFXCToJlLb.get('desc')
   qkMdOncHWzaBfGvgeVASjFXCToJlLP ='%sx%s'%(qkMdOncHWzaBfGvgeVASjFXCToJlLx,qkMdOncHWzaBfGvgeVASjFXCToJlLN)
   qkMdOncHWzaBfGvgeVASjFXCToJluL ='%s. %s'%(qkMdOncHWzaBfGvgeVASjFXCToJlLP,qkMdOncHWzaBfGvgeVASjFXCToJlLY)
   qkMdOncHWzaBfGvgeVASjFXCToJlyR={'mediatype':'episode','mpaa':qkMdOncHWzaBfGvgeVASjFXCToJlyi,'genre':qkMdOncHWzaBfGvgeVASjFXCToJlys,'duration':qkMdOncHWzaBfGvgeVASjFXCToJlyY,'year':qkMdOncHWzaBfGvgeVASjFXCToJlyK,'plot':'%s (%s)\n\n%s'%(qkMdOncHWzaBfGvgeVASjFXCToJlLR,qkMdOncHWzaBfGvgeVASjFXCToJlLP,qkMdOncHWzaBfGvgeVASjFXCToJlLi),}
   qkMdOncHWzaBfGvgeVASjFXCToJluw={'mode':'VOD','programid':qkMdOncHWzaBfGvgeVASjFXCToJlLr,'programnm':qkMdOncHWzaBfGvgeVASjFXCToJlLR,'title':qkMdOncHWzaBfGvgeVASjFXCToJluL,'season':qkMdOncHWzaBfGvgeVASjFXCToJlLx,'id':qkMdOncHWzaBfGvgeVASjFXCToJlLD,'asis':qkMdOncHWzaBfGvgeVASjFXCToJlyw,'thumbnail':qkMdOncHWzaBfGvgeVASjFXCToJlyQ,'programimg':qkMdOncHWzaBfGvgeVASjFXCToJlLh,}
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.add_dir(qkMdOncHWzaBfGvgeVASjFXCToJluL,sublabel='',img=qkMdOncHWzaBfGvgeVASjFXCToJlyQ,infoLabels=qkMdOncHWzaBfGvgeVASjFXCToJlyR,isFolder=qkMdOncHWzaBfGvgeVASjFXCToJlrL,params=qkMdOncHWzaBfGvgeVASjFXCToJluw)
  xbmcplugin.setContent(qkMdOncHWzaBfGvgeVASjFXCToJlUr._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(qkMdOncHWzaBfGvgeVASjFXCToJlUr._addon_handle,cacheToDisc=qkMdOncHWzaBfGvgeVASjFXCToJlrL)
 def play_VIDEO(qkMdOncHWzaBfGvgeVASjFXCToJlUr,args):
  qkMdOncHWzaBfGvgeVASjFXCToJlLK =args.get('id')
  qkMdOncHWzaBfGvgeVASjFXCToJlyw =args.get('asis')
  if qkMdOncHWzaBfGvgeVASjFXCToJlyw in['HIGHLIGHT']:
   qkMdOncHWzaBfGvgeVASjFXCToJlLm,qkMdOncHWzaBfGvgeVASjFXCToJlLs=qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.GetEventURL(qkMdOncHWzaBfGvgeVASjFXCToJlLK,qkMdOncHWzaBfGvgeVASjFXCToJlyw)
  elif qkMdOncHWzaBfGvgeVASjFXCToJlyw in['LIVE']:
   qkMdOncHWzaBfGvgeVASjFXCToJlLm,qkMdOncHWzaBfGvgeVASjFXCToJlLs=qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.GetEventURL_Live(qkMdOncHWzaBfGvgeVASjFXCToJlLK,qkMdOncHWzaBfGvgeVASjFXCToJlyw)
  else:
   qkMdOncHWzaBfGvgeVASjFXCToJlLm,qkMdOncHWzaBfGvgeVASjFXCToJlLs=qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.GetBroadURL(qkMdOncHWzaBfGvgeVASjFXCToJlLK)
  qkMdOncHWzaBfGvgeVASjFXCToJlUr.addon_log('asis, url : %s - %s - %s'%(qkMdOncHWzaBfGvgeVASjFXCToJlyw,qkMdOncHWzaBfGvgeVASjFXCToJlLK,qkMdOncHWzaBfGvgeVASjFXCToJlLm))
  if qkMdOncHWzaBfGvgeVASjFXCToJlLm=='':
   if qkMdOncHWzaBfGvgeVASjFXCToJlLs=='':
    qkMdOncHWzaBfGvgeVASjFXCToJlUr.addon_noti(__language__(30907).encode('utf8'))
   else:
    qkMdOncHWzaBfGvgeVASjFXCToJlUr.addon_log('drm_license_1 : %s'%(qkMdOncHWzaBfGvgeVASjFXCToJlLs))
    qkMdOncHWzaBfGvgeVASjFXCToJlUr.addon_noti(qkMdOncHWzaBfGvgeVASjFXCToJlLs)
   return
  else:
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.addon_log('drm_license : %s'%(qkMdOncHWzaBfGvgeVASjFXCToJlLs))
  '''
  tmp_cookie = 'PCID=%s;token=%s;member_srl=%s;NEXT_LOCALE=%s;session_web_id=%s;device_id=%s' % (self.CoupangObj.CP['COOKIES']['PCID'], self.CoupangObj.CP['COOKIES']['token'], self.CoupangObj.CP['COOKIES']['member_srl'], self.CoupangObj.CP['COOKIES']['NEXT_LOCALE'], self.CoupangObj.CP['COOKIES']['session_web_id'], self.CoupangObj.CP['COOKIES']['device_id'], )
  '''  
  if qkMdOncHWzaBfGvgeVASjFXCToJlyw in['EPISODE']:
   qkMdOncHWzaBfGvgeVASjFXCToJlLt='https://www.coupangplay.com/play/{}/episode?titleId={}&type=EPISODE&sourceType=page_discover_title_detail%3Apage_discover_feed'.format(qkMdOncHWzaBfGvgeVASjFXCToJlLK,qkMdOncHWzaBfGvgeVASjFXCToJlLK)
  elif qkMdOncHWzaBfGvgeVASjFXCToJlyw in['MOVIE']:
   qkMdOncHWzaBfGvgeVASjFXCToJlLt='https://www.coupangplay.com/play/{}/movie?sourceType=page_discover_feed'.format(qkMdOncHWzaBfGvgeVASjFXCToJlLK)
  else:
   qkMdOncHWzaBfGvgeVASjFXCToJlLt='https://www.coupangplay.com/play/'+qkMdOncHWzaBfGvgeVASjFXCToJlLK 
  qkMdOncHWzaBfGvgeVASjFXCToJlLp,qkMdOncHWzaBfGvgeVASjFXCToJlIU,qkMdOncHWzaBfGvgeVASjFXCToJlIu=qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.Make_authHeader()
  qkMdOncHWzaBfGvgeVASjFXCToJlIy=qkMdOncHWzaBfGvgeVASjFXCToJlLm 
  qkMdOncHWzaBfGvgeVASjFXCToJlUr.addon_log('tobe, surl : %s'%(qkMdOncHWzaBfGvgeVASjFXCToJlIy))
  qkMdOncHWzaBfGvgeVASjFXCToJlIL=xbmcgui.ListItem(path=qkMdOncHWzaBfGvgeVASjFXCToJlIy)
  qkMdOncHWzaBfGvgeVASjFXCToJlIR=qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.Get_Url_PostFix(qkMdOncHWzaBfGvgeVASjFXCToJlLm) 
  qkMdOncHWzaBfGvgeVASjFXCToJlUr.addon_log('post_fix : '+qkMdOncHWzaBfGvgeVASjFXCToJlIR)
  if qkMdOncHWzaBfGvgeVASjFXCToJlIR=='m3u8':
   qkMdOncHWzaBfGvgeVASjFXCToJlIr ='hls' 
  else:
   qkMdOncHWzaBfGvgeVASjFXCToJlIr ='mpd' 
  qkMdOncHWzaBfGvgeVASjFXCToJlIb={'user-agent':qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.USER_AGENT,'referer':qkMdOncHWzaBfGvgeVASjFXCToJlLt,'traceparent':qkMdOncHWzaBfGvgeVASjFXCToJlLp,'tracestate':qkMdOncHWzaBfGvgeVASjFXCToJlIU,'newrelic':qkMdOncHWzaBfGvgeVASjFXCToJlIu,}
  qkMdOncHWzaBfGvgeVASjFXCToJlIQ =qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.CP['COOKIES']
  qkMdOncHWzaBfGvgeVASjFXCToJlIw=qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.make_stream_header(qkMdOncHWzaBfGvgeVASjFXCToJlIb,qkMdOncHWzaBfGvgeVASjFXCToJlIQ)
  if qkMdOncHWzaBfGvgeVASjFXCToJlLs:
   qkMdOncHWzaBfGvgeVASjFXCToJlIx =qkMdOncHWzaBfGvgeVASjFXCToJlLs 
   qkMdOncHWzaBfGvgeVASjFXCToJlIh ='com.widevine.alpha'
   qkMdOncHWzaBfGvgeVASjFXCToJlIE=qkMdOncHWzaBfGvgeVASjFXCToJlIx+'|'+qkMdOncHWzaBfGvgeVASjFXCToJlIw+'|R{SSM}|'
   inputstreamhelper.Helper(qkMdOncHWzaBfGvgeVASjFXCToJlIr,drm='com.widevine.alpha').check_inputstream()
   qkMdOncHWzaBfGvgeVASjFXCToJlIL.setProperty('inputstream','inputstream.adaptive')
   if qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.KodiVersion<=20:
    qkMdOncHWzaBfGvgeVASjFXCToJlIL.setProperty('inputstream.adaptive.manifest_type',qkMdOncHWzaBfGvgeVASjFXCToJlIr)
   qkMdOncHWzaBfGvgeVASjFXCToJlIL.setProperty('inputstream.adaptive.license_type',qkMdOncHWzaBfGvgeVASjFXCToJlIh)
   qkMdOncHWzaBfGvgeVASjFXCToJlIL.setProperty('inputstream.adaptive.license_key',qkMdOncHWzaBfGvgeVASjFXCToJlIE)
   qkMdOncHWzaBfGvgeVASjFXCToJlIL.setProperty('inputstream.adaptive.stream_headers',qkMdOncHWzaBfGvgeVASjFXCToJlIw)
   qkMdOncHWzaBfGvgeVASjFXCToJlIL.setProperty('inputstream.adaptive.manifest_headers',qkMdOncHWzaBfGvgeVASjFXCToJlIw)
   qkMdOncHWzaBfGvgeVASjFXCToJlIL.setMimeType('application/dash+xml')
   qkMdOncHWzaBfGvgeVASjFXCToJlIL.setContentLookup(qkMdOncHWzaBfGvgeVASjFXCToJlrL)
  else:
   qkMdOncHWzaBfGvgeVASjFXCToJlIL.setContentLookup(qkMdOncHWzaBfGvgeVASjFXCToJlrL)
   qkMdOncHWzaBfGvgeVASjFXCToJlIL.setMimeType('application/x-mpegURL')
   qkMdOncHWzaBfGvgeVASjFXCToJlIL.setProperty('inputstream','inputstream.adaptive')
   if qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.KodiVersion<=20:
    qkMdOncHWzaBfGvgeVASjFXCToJlIL.setProperty('inputstream.adaptive.manifest_type',qkMdOncHWzaBfGvgeVASjFXCToJlIr)
   qkMdOncHWzaBfGvgeVASjFXCToJlIL.setProperty('inputstream.adaptive.stream_headers',qkMdOncHWzaBfGvgeVASjFXCToJlIw)
   qkMdOncHWzaBfGvgeVASjFXCToJlIL.setProperty('inputstream.adaptive.manifest_headers',qkMdOncHWzaBfGvgeVASjFXCToJlIw)
  xbmcplugin.setResolvedUrl(qkMdOncHWzaBfGvgeVASjFXCToJlUr._addon_handle,qkMdOncHWzaBfGvgeVASjFXCToJlrI,qkMdOncHWzaBfGvgeVASjFXCToJlIL)
  try:
   if qkMdOncHWzaBfGvgeVASjFXCToJlyw=='MOVIE':
    qkMdOncHWzaBfGvgeVASjFXCToJlID='movie'
    qkMdOncHWzaBfGvgeVASjFXCToJluw={'code':qkMdOncHWzaBfGvgeVASjFXCToJlLK,'asis':qkMdOncHWzaBfGvgeVASjFXCToJlyw,'title':args.get('title'),'img':args.get('thumbnail'),}
    qkMdOncHWzaBfGvgeVASjFXCToJlUr.Save_Watched_List(qkMdOncHWzaBfGvgeVASjFXCToJlID,qkMdOncHWzaBfGvgeVASjFXCToJluw)
   elif qkMdOncHWzaBfGvgeVASjFXCToJlyw=='EPISODE':
    qkMdOncHWzaBfGvgeVASjFXCToJlID='tvshow'
    qkMdOncHWzaBfGvgeVASjFXCToJluw={'code':args.get('programid'),'asis':qkMdOncHWzaBfGvgeVASjFXCToJlyw,'title':'%s <%s>'%(args.get('title'),args.get('programnm')),'img':args.get('programimg'),}
    qkMdOncHWzaBfGvgeVASjFXCToJlUr.Save_Watched_List(qkMdOncHWzaBfGvgeVASjFXCToJlID,qkMdOncHWzaBfGvgeVASjFXCToJluw)
  except:
   qkMdOncHWzaBfGvgeVASjFXCToJlry
 def dp_Global_Search(qkMdOncHWzaBfGvgeVASjFXCToJlUr,args):
  qkMdOncHWzaBfGvgeVASjFXCToJlyt=args.get('mode')
  if qkMdOncHWzaBfGvgeVASjFXCToJlyt=='TOTAL_SEARCH':
   qkMdOncHWzaBfGvgeVASjFXCToJlIN='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   qkMdOncHWzaBfGvgeVASjFXCToJlIN='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(qkMdOncHWzaBfGvgeVASjFXCToJlIN)
 def dp_Bookmark_Menu(qkMdOncHWzaBfGvgeVASjFXCToJlUr,args):
  qkMdOncHWzaBfGvgeVASjFXCToJlIN='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(qkMdOncHWzaBfGvgeVASjFXCToJlIN)
 def dp_Search_List(qkMdOncHWzaBfGvgeVASjFXCToJlUr,args):
  qkMdOncHWzaBfGvgeVASjFXCToJlyD =qkMdOncHWzaBfGvgeVASjFXCToJlrw(args.get('page'))
  if 'search_key' in args:
   qkMdOncHWzaBfGvgeVASjFXCToJlIi=args.get('search_key')
  else:
   qkMdOncHWzaBfGvgeVASjFXCToJlIi=qkMdOncHWzaBfGvgeVASjFXCToJlUr.get_keyboard_input(__language__(30908).encode('utf-8'))
   if not qkMdOncHWzaBfGvgeVASjFXCToJlIi:
    return
  qkMdOncHWzaBfGvgeVASjFXCToJlIP,qkMdOncHWzaBfGvgeVASjFXCToJlyN=qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.Get_Search_List(qkMdOncHWzaBfGvgeVASjFXCToJlIi,qkMdOncHWzaBfGvgeVASjFXCToJlyD)
  for qkMdOncHWzaBfGvgeVASjFXCToJlIK in qkMdOncHWzaBfGvgeVASjFXCToJlIP:
   qkMdOncHWzaBfGvgeVASjFXCToJlrD =qkMdOncHWzaBfGvgeVASjFXCToJlIK.get('id')
   qkMdOncHWzaBfGvgeVASjFXCToJluL =qkMdOncHWzaBfGvgeVASjFXCToJlIK.get('title')
   qkMdOncHWzaBfGvgeVASjFXCToJlyw =qkMdOncHWzaBfGvgeVASjFXCToJlIK.get('asis')
   qkMdOncHWzaBfGvgeVASjFXCToJlyQ =qkMdOncHWzaBfGvgeVASjFXCToJlIK.get('thumbnail')
   qkMdOncHWzaBfGvgeVASjFXCToJlyi =qkMdOncHWzaBfGvgeVASjFXCToJlIK.get('mpaa')
   qkMdOncHWzaBfGvgeVASjFXCToJlyK =qkMdOncHWzaBfGvgeVASjFXCToJlIK.get('year')
   qkMdOncHWzaBfGvgeVASjFXCToJlyY =qkMdOncHWzaBfGvgeVASjFXCToJlIK.get('duration')
   qkMdOncHWzaBfGvgeVASjFXCToJlyP =qkMdOncHWzaBfGvgeVASjFXCToJlIK.get('badge')
   if qkMdOncHWzaBfGvgeVASjFXCToJlyw=='TVSHOW': 
    qkMdOncHWzaBfGvgeVASjFXCToJlyt ='SEASON_LIST'
    qkMdOncHWzaBfGvgeVASjFXCToJlyR={'mediatype':'tvshow','title':qkMdOncHWzaBfGvgeVASjFXCToJluL,'mpaa':qkMdOncHWzaBfGvgeVASjFXCToJlyi,'year':qkMdOncHWzaBfGvgeVASjFXCToJlyK,'plot':'Year : %s'%(qkMdOncHWzaBfGvgeVASjFXCToJlyK),}
    qkMdOncHWzaBfGvgeVASjFXCToJlux =qkMdOncHWzaBfGvgeVASjFXCToJlrI
   elif qkMdOncHWzaBfGvgeVASjFXCToJlyw=='MOVIE':
    qkMdOncHWzaBfGvgeVASjFXCToJlyt ='MOVIE'
    qkMdOncHWzaBfGvgeVASjFXCToJlyR={'mediatype':'movie','title':qkMdOncHWzaBfGvgeVASjFXCToJluL,'mpaa':qkMdOncHWzaBfGvgeVASjFXCToJlyi,'duration':qkMdOncHWzaBfGvgeVASjFXCToJlyY,'year':qkMdOncHWzaBfGvgeVASjFXCToJlyK,'plot':'(%s)'%(qkMdOncHWzaBfGvgeVASjFXCToJlyi),}
    qkMdOncHWzaBfGvgeVASjFXCToJlux =qkMdOncHWzaBfGvgeVASjFXCToJlrL
    qkMdOncHWzaBfGvgeVASjFXCToJluL +=' (%s)'%(qkMdOncHWzaBfGvgeVASjFXCToJlrY(qkMdOncHWzaBfGvgeVASjFXCToJlyK))
   elif qkMdOncHWzaBfGvgeVASjFXCToJlyw=='HIGHLIGHT':
    qkMdOncHWzaBfGvgeVASjFXCToJlyt ='HIGHLIGHT'
    qkMdOncHWzaBfGvgeVASjFXCToJlyR={'mediatype':'episode','title':qkMdOncHWzaBfGvgeVASjFXCToJluL,'duration':qkMdOncHWzaBfGvgeVASjFXCToJlyY,'plot':qkMdOncHWzaBfGvgeVASjFXCToJlyt,}
    qkMdOncHWzaBfGvgeVASjFXCToJlux =qkMdOncHWzaBfGvgeVASjFXCToJlrL
   elif qkMdOncHWzaBfGvgeVASjFXCToJlyw=='LIVE':
    qkMdOncHWzaBfGvgeVASjFXCToJlyt ='LIVE'
    qkMdOncHWzaBfGvgeVASjFXCToJlyR={'mediatype':'episode','title':qkMdOncHWzaBfGvgeVASjFXCToJluL,'plot':qkMdOncHWzaBfGvgeVASjFXCToJlyt,}
    qkMdOncHWzaBfGvgeVASjFXCToJlux =qkMdOncHWzaBfGvgeVASjFXCToJlrL
   qkMdOncHWzaBfGvgeVASjFXCToJluw={'mode':qkMdOncHWzaBfGvgeVASjFXCToJlyt,'id':qkMdOncHWzaBfGvgeVASjFXCToJlrD,'asis':qkMdOncHWzaBfGvgeVASjFXCToJlyw,'seasonList':'','title':qkMdOncHWzaBfGvgeVASjFXCToJluL,'thumbnail':json.dumps(qkMdOncHWzaBfGvgeVASjFXCToJlyQ,separators=(',',':')),'year':qkMdOncHWzaBfGvgeVASjFXCToJlyK,}
   if qkMdOncHWzaBfGvgeVASjFXCToJlUr.get_settings_makebookmark()and qkMdOncHWzaBfGvgeVASjFXCToJlyw not in['HIGHLIGHT','']:
    qkMdOncHWzaBfGvgeVASjFXCToJlyp={'videoid':qkMdOncHWzaBfGvgeVASjFXCToJlrD,'vidtype':'movie' if qkMdOncHWzaBfGvgeVASjFXCToJlyw=='MOVIE' else 'tvshow','vtitle':qkMdOncHWzaBfGvgeVASjFXCToJluL,'vsubtitle':'',}
    qkMdOncHWzaBfGvgeVASjFXCToJlLU=json.dumps(qkMdOncHWzaBfGvgeVASjFXCToJlyp)
    qkMdOncHWzaBfGvgeVASjFXCToJlLU=urllib.parse.quote(qkMdOncHWzaBfGvgeVASjFXCToJlLU)
    qkMdOncHWzaBfGvgeVASjFXCToJlLu='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(qkMdOncHWzaBfGvgeVASjFXCToJlLU)
    qkMdOncHWzaBfGvgeVASjFXCToJlLy=[('(통합) 찜 영상에 추가',qkMdOncHWzaBfGvgeVASjFXCToJlLu)]
   else:
    qkMdOncHWzaBfGvgeVASjFXCToJlLy=qkMdOncHWzaBfGvgeVASjFXCToJlry
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.add_dir(qkMdOncHWzaBfGvgeVASjFXCToJluL,sublabel=qkMdOncHWzaBfGvgeVASjFXCToJlyP,img=qkMdOncHWzaBfGvgeVASjFXCToJlyQ,infoLabels=qkMdOncHWzaBfGvgeVASjFXCToJlyR,isFolder=qkMdOncHWzaBfGvgeVASjFXCToJlux,params=qkMdOncHWzaBfGvgeVASjFXCToJluw,ContextMenu=qkMdOncHWzaBfGvgeVASjFXCToJlLy)
  if qkMdOncHWzaBfGvgeVASjFXCToJlyN:
   qkMdOncHWzaBfGvgeVASjFXCToJluw={}
   qkMdOncHWzaBfGvgeVASjFXCToJluw['mode'] ='LOCAL_SEARCH'
   qkMdOncHWzaBfGvgeVASjFXCToJluw['search_key']=qkMdOncHWzaBfGvgeVASjFXCToJlIi
   qkMdOncHWzaBfGvgeVASjFXCToJluw['page'] =qkMdOncHWzaBfGvgeVASjFXCToJlrY(qkMdOncHWzaBfGvgeVASjFXCToJlyD+1)
   qkMdOncHWzaBfGvgeVASjFXCToJluL='[B]%s >>[/B]'%'다음 페이지'
   qkMdOncHWzaBfGvgeVASjFXCToJlLI=qkMdOncHWzaBfGvgeVASjFXCToJlrY(qkMdOncHWzaBfGvgeVASjFXCToJlyD+1)
   qkMdOncHWzaBfGvgeVASjFXCToJluQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.add_dir(qkMdOncHWzaBfGvgeVASjFXCToJluL,sublabel=qkMdOncHWzaBfGvgeVASjFXCToJlLI,img=qkMdOncHWzaBfGvgeVASjFXCToJluQ,infoLabels=qkMdOncHWzaBfGvgeVASjFXCToJlry,isFolder=qkMdOncHWzaBfGvgeVASjFXCToJlrI,params=qkMdOncHWzaBfGvgeVASjFXCToJluw)
  xbmcplugin.setContent(qkMdOncHWzaBfGvgeVASjFXCToJlUr._addon_handle,'movies')
  xbmcplugin.endOfDirectory(qkMdOncHWzaBfGvgeVASjFXCToJlUr._addon_handle,cacheToDisc=qkMdOncHWzaBfGvgeVASjFXCToJlrI)
  if args.get('historyyn')=='Y':qkMdOncHWzaBfGvgeVASjFXCToJlUr.Save_Searched_List(qkMdOncHWzaBfGvgeVASjFXCToJlIi)
 def Load_List_File(qkMdOncHWzaBfGvgeVASjFXCToJlUr,qkMdOncHWzaBfGvgeVASjFXCToJlID): 
  try:
   if qkMdOncHWzaBfGvgeVASjFXCToJlID=='search':
    qkMdOncHWzaBfGvgeVASjFXCToJlIm=qkMdOncHWzaBfGvgeVASjFXCToJlUR
   elif qkMdOncHWzaBfGvgeVASjFXCToJlID in['tvshow','movie']:
    qkMdOncHWzaBfGvgeVASjFXCToJlIm=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%qkMdOncHWzaBfGvgeVASjFXCToJlID))
   else:
    return[]
   fp=qkMdOncHWzaBfGvgeVASjFXCToJlrh(qkMdOncHWzaBfGvgeVASjFXCToJlIm,'r',-1,'utf-8')
   qkMdOncHWzaBfGvgeVASjFXCToJlIs=fp.readlines()
   fp.close()
  except:
   qkMdOncHWzaBfGvgeVASjFXCToJlIs=[]
  return qkMdOncHWzaBfGvgeVASjFXCToJlIs
 def Save_Watched_List(qkMdOncHWzaBfGvgeVASjFXCToJlUr,qkMdOncHWzaBfGvgeVASjFXCToJlID,qkMdOncHWzaBfGvgeVASjFXCToJlUw):
  try:
   qkMdOncHWzaBfGvgeVASjFXCToJlIt=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%qkMdOncHWzaBfGvgeVASjFXCToJlID))
   qkMdOncHWzaBfGvgeVASjFXCToJlIp=qkMdOncHWzaBfGvgeVASjFXCToJlUr.Load_List_File(qkMdOncHWzaBfGvgeVASjFXCToJlID) 
   fp=qkMdOncHWzaBfGvgeVASjFXCToJlrh(qkMdOncHWzaBfGvgeVASjFXCToJlIt,'w',-1,'utf-8')
   qkMdOncHWzaBfGvgeVASjFXCToJlRU=urllib.parse.urlencode(qkMdOncHWzaBfGvgeVASjFXCToJlUw)
   qkMdOncHWzaBfGvgeVASjFXCToJlRU=qkMdOncHWzaBfGvgeVASjFXCToJlRU+'\n'
   fp.write(qkMdOncHWzaBfGvgeVASjFXCToJlRU)
   qkMdOncHWzaBfGvgeVASjFXCToJlRu=0
   for qkMdOncHWzaBfGvgeVASjFXCToJlRy in qkMdOncHWzaBfGvgeVASjFXCToJlIp:
    qkMdOncHWzaBfGvgeVASjFXCToJlRL=qkMdOncHWzaBfGvgeVASjFXCToJlrb(urllib.parse.parse_qsl(qkMdOncHWzaBfGvgeVASjFXCToJlRy))
    qkMdOncHWzaBfGvgeVASjFXCToJlRI=qkMdOncHWzaBfGvgeVASjFXCToJlUw.get('code').strip()
    qkMdOncHWzaBfGvgeVASjFXCToJlRr=qkMdOncHWzaBfGvgeVASjFXCToJlRL.get('code').strip()
    if qkMdOncHWzaBfGvgeVASjFXCToJlRI!=qkMdOncHWzaBfGvgeVASjFXCToJlRr:
     fp.write(qkMdOncHWzaBfGvgeVASjFXCToJlRy)
     qkMdOncHWzaBfGvgeVASjFXCToJlRu+=1
     if qkMdOncHWzaBfGvgeVASjFXCToJlRu>=50:break
   fp.close()
  except:
   qkMdOncHWzaBfGvgeVASjFXCToJlry
 def Save_Searched_List(qkMdOncHWzaBfGvgeVASjFXCToJlUr,qkMdOncHWzaBfGvgeVASjFXCToJlIi):
  try:
   qkMdOncHWzaBfGvgeVASjFXCToJlIi=qkMdOncHWzaBfGvgeVASjFXCToJlIi.strip()
   qkMdOncHWzaBfGvgeVASjFXCToJlIp=qkMdOncHWzaBfGvgeVASjFXCToJlUr.Load_List_File('search') 
   fp=qkMdOncHWzaBfGvgeVASjFXCToJlrh(qkMdOncHWzaBfGvgeVASjFXCToJlUR,'w',-1,'utf-8')
   fp.write(qkMdOncHWzaBfGvgeVASjFXCToJlIi+'\n')
   qkMdOncHWzaBfGvgeVASjFXCToJlRu=0
   for qkMdOncHWzaBfGvgeVASjFXCToJlRy in qkMdOncHWzaBfGvgeVASjFXCToJlIp:
    qkMdOncHWzaBfGvgeVASjFXCToJlRy=qkMdOncHWzaBfGvgeVASjFXCToJlRy.strip()
    if qkMdOncHWzaBfGvgeVASjFXCToJlIi!=qkMdOncHWzaBfGvgeVASjFXCToJlRy:
     fp.write(qkMdOncHWzaBfGvgeVASjFXCToJlRy+'\n')
     qkMdOncHWzaBfGvgeVASjFXCToJlRu+=1
     if qkMdOncHWzaBfGvgeVASjFXCToJlRu>=50:break
   fp.close()
  except:
   qkMdOncHWzaBfGvgeVASjFXCToJlry
 def dp_Search_History(qkMdOncHWzaBfGvgeVASjFXCToJlUr,args):
  qkMdOncHWzaBfGvgeVASjFXCToJlRb=qkMdOncHWzaBfGvgeVASjFXCToJlUr.Load_List_File('search')
  for qkMdOncHWzaBfGvgeVASjFXCToJlRQ in qkMdOncHWzaBfGvgeVASjFXCToJlRb:
   qkMdOncHWzaBfGvgeVASjFXCToJlRQ=qkMdOncHWzaBfGvgeVASjFXCToJlRQ.strip()
   qkMdOncHWzaBfGvgeVASjFXCToJluw={'mode':'LOCAL_SEARCH','search_key':qkMdOncHWzaBfGvgeVASjFXCToJlRQ,'page':'1','historyyn':'Y',}
   qkMdOncHWzaBfGvgeVASjFXCToJlRw={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','skey':qkMdOncHWzaBfGvgeVASjFXCToJlRQ,'vType':'-',}
   qkMdOncHWzaBfGvgeVASjFXCToJlRx=urllib.parse.urlencode(qkMdOncHWzaBfGvgeVASjFXCToJlRw)
   qkMdOncHWzaBfGvgeVASjFXCToJlLy=[('선택된 검색어 ( %s ) 삭제'%(qkMdOncHWzaBfGvgeVASjFXCToJlRQ),'RunPlugin(plugin://plugin.video.coupangm/?%s)'%(qkMdOncHWzaBfGvgeVASjFXCToJlRx))]
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.add_dir(qkMdOncHWzaBfGvgeVASjFXCToJlRQ,sublabel='',img=qkMdOncHWzaBfGvgeVASjFXCToJlry,infoLabels=qkMdOncHWzaBfGvgeVASjFXCToJlry,isFolder=qkMdOncHWzaBfGvgeVASjFXCToJlrI,params=qkMdOncHWzaBfGvgeVASjFXCToJluw,ContextMenu=qkMdOncHWzaBfGvgeVASjFXCToJlLy)
  qkMdOncHWzaBfGvgeVASjFXCToJlyR={'plot':'검색목록 전체를 삭제합니다.'}
  qkMdOncHWzaBfGvgeVASjFXCToJluL='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  qkMdOncHWzaBfGvgeVASjFXCToJluw={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  qkMdOncHWzaBfGvgeVASjFXCToJluQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  qkMdOncHWzaBfGvgeVASjFXCToJlUr.add_dir(qkMdOncHWzaBfGvgeVASjFXCToJluL,sublabel='',img=qkMdOncHWzaBfGvgeVASjFXCToJluQ,infoLabels=qkMdOncHWzaBfGvgeVASjFXCToJlyR,isFolder=qkMdOncHWzaBfGvgeVASjFXCToJlrL,params=qkMdOncHWzaBfGvgeVASjFXCToJluw,isLink=qkMdOncHWzaBfGvgeVASjFXCToJlrI)
  xbmcplugin.endOfDirectory(qkMdOncHWzaBfGvgeVASjFXCToJlUr._addon_handle,cacheToDisc=qkMdOncHWzaBfGvgeVASjFXCToJlrL)
 def dp_Listfile_Delete(qkMdOncHWzaBfGvgeVASjFXCToJlUr,args):
  qkMdOncHWzaBfGvgeVASjFXCToJlRh=args.get('delType')
  qkMdOncHWzaBfGvgeVASjFXCToJlRE =args.get('skey')
  qkMdOncHWzaBfGvgeVASjFXCToJlyU =args.get('vType')
  qkMdOncHWzaBfGvgeVASjFXCToJlUh=xbmcgui.Dialog()
  if qkMdOncHWzaBfGvgeVASjFXCToJlRh=='SEARCH_ALL':
   qkMdOncHWzaBfGvgeVASjFXCToJluD=qkMdOncHWzaBfGvgeVASjFXCToJlUh.yesno(__language__(30911).encode('utf8'),__language__(30906).encode('utf8'))
  elif qkMdOncHWzaBfGvgeVASjFXCToJlRh=='SEARCH_ONE':
   qkMdOncHWzaBfGvgeVASjFXCToJluD=qkMdOncHWzaBfGvgeVASjFXCToJlUh.yesno(__language__(30912).encode('utf8'),__language__(30906).encode('utf8'))
  elif qkMdOncHWzaBfGvgeVASjFXCToJlRh=='WATCH_ALL':
   qkMdOncHWzaBfGvgeVASjFXCToJluD=qkMdOncHWzaBfGvgeVASjFXCToJlUh.yesno(__language__(30913).encode('utf8'),__language__(30906).encode('utf8'))
  elif qkMdOncHWzaBfGvgeVASjFXCToJlRh=='WATCH_ONE':
   qkMdOncHWzaBfGvgeVASjFXCToJluD=qkMdOncHWzaBfGvgeVASjFXCToJlUh.yesno(__language__(30916).encode('utf8'),__language__(30906).encode('utf8'))
  if qkMdOncHWzaBfGvgeVASjFXCToJluD==qkMdOncHWzaBfGvgeVASjFXCToJlrL:sys.exit()
  if qkMdOncHWzaBfGvgeVASjFXCToJlRh=='SEARCH_ALL':
   if os.path.isfile(qkMdOncHWzaBfGvgeVASjFXCToJlUR):os.remove(qkMdOncHWzaBfGvgeVASjFXCToJlUR)
  elif qkMdOncHWzaBfGvgeVASjFXCToJlRh=='SEARCH_ONE':
   try:
    qkMdOncHWzaBfGvgeVASjFXCToJlIm=qkMdOncHWzaBfGvgeVASjFXCToJlUR
    qkMdOncHWzaBfGvgeVASjFXCToJlIp=qkMdOncHWzaBfGvgeVASjFXCToJlUr.Load_List_File('search') 
    fp=qkMdOncHWzaBfGvgeVASjFXCToJlrh(qkMdOncHWzaBfGvgeVASjFXCToJlIm,'w',-1,'utf-8')
    for qkMdOncHWzaBfGvgeVASjFXCToJlRy in qkMdOncHWzaBfGvgeVASjFXCToJlIp:
     if qkMdOncHWzaBfGvgeVASjFXCToJlRE!=qkMdOncHWzaBfGvgeVASjFXCToJlRy.strip():
      fp.write(qkMdOncHWzaBfGvgeVASjFXCToJlRy)
    fp.close()
   except:
    qkMdOncHWzaBfGvgeVASjFXCToJlry
  elif qkMdOncHWzaBfGvgeVASjFXCToJlRh=='WATCH_ALL':
   qkMdOncHWzaBfGvgeVASjFXCToJlIm=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%qkMdOncHWzaBfGvgeVASjFXCToJlyU))
   if os.path.isfile(qkMdOncHWzaBfGvgeVASjFXCToJlIm):os.remove(qkMdOncHWzaBfGvgeVASjFXCToJlIm)
  elif qkMdOncHWzaBfGvgeVASjFXCToJlRh=='WATCH_ONE':
   qkMdOncHWzaBfGvgeVASjFXCToJlIm=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%qkMdOncHWzaBfGvgeVASjFXCToJlyU))
   try:
    qkMdOncHWzaBfGvgeVASjFXCToJlIp=qkMdOncHWzaBfGvgeVASjFXCToJlUr.Load_List_File(qkMdOncHWzaBfGvgeVASjFXCToJlyU) 
    fp=qkMdOncHWzaBfGvgeVASjFXCToJlrh(qkMdOncHWzaBfGvgeVASjFXCToJlIm,'w',-1,'utf-8')
    for qkMdOncHWzaBfGvgeVASjFXCToJlRy in qkMdOncHWzaBfGvgeVASjFXCToJlIp:
     qkMdOncHWzaBfGvgeVASjFXCToJlRL=qkMdOncHWzaBfGvgeVASjFXCToJlrb(urllib.parse.parse_qsl(qkMdOncHWzaBfGvgeVASjFXCToJlRy))
     qkMdOncHWzaBfGvgeVASjFXCToJlRY=qkMdOncHWzaBfGvgeVASjFXCToJlRL.get('code').strip()
     if qkMdOncHWzaBfGvgeVASjFXCToJlRE!=qkMdOncHWzaBfGvgeVASjFXCToJlRY:
      fp.write(qkMdOncHWzaBfGvgeVASjFXCToJlRy)
    fp.close()
   except:
    qkMdOncHWzaBfGvgeVASjFXCToJlry
  xbmc.executebuiltin("Container.Refresh")
 def Delete_List_File(qkMdOncHWzaBfGvgeVASjFXCToJlUr,qkMdOncHWzaBfGvgeVASjFXCToJlID,skey='-'):
  if qkMdOncHWzaBfGvgeVASjFXCToJlID=='ALL':
   try:
    qkMdOncHWzaBfGvgeVASjFXCToJlIm=qkMdOncHWzaBfGvgeVASjFXCToJlUR
    fp=qkMdOncHWzaBfGvgeVASjFXCToJlrh(qkMdOncHWzaBfGvgeVASjFXCToJlIm,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    qkMdOncHWzaBfGvgeVASjFXCToJlry
  elif qkMdOncHWzaBfGvgeVASjFXCToJlID=='ONE':
   try:
    qkMdOncHWzaBfGvgeVASjFXCToJlIm=qkMdOncHWzaBfGvgeVASjFXCToJlUR
    qkMdOncHWzaBfGvgeVASjFXCToJlIp=qkMdOncHWzaBfGvgeVASjFXCToJlUr.Load_List_File('search') 
    fp=qkMdOncHWzaBfGvgeVASjFXCToJlrh(qkMdOncHWzaBfGvgeVASjFXCToJlIm,'w',-1,'utf-8')
    for qkMdOncHWzaBfGvgeVASjFXCToJlRy in qkMdOncHWzaBfGvgeVASjFXCToJlIp:
     if skey!=qkMdOncHWzaBfGvgeVASjFXCToJlRy.strip():
      fp.write(qkMdOncHWzaBfGvgeVASjFXCToJlRy)
    fp.close()
   except:
    qkMdOncHWzaBfGvgeVASjFXCToJlry
  elif qkMdOncHWzaBfGvgeVASjFXCToJlID in['tvshow','movie']:
   try:
    qkMdOncHWzaBfGvgeVASjFXCToJlIm=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%qkMdOncHWzaBfGvgeVASjFXCToJlID))
    fp=qkMdOncHWzaBfGvgeVASjFXCToJlrh(qkMdOncHWzaBfGvgeVASjFXCToJlIm,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    qkMdOncHWzaBfGvgeVASjFXCToJlry
 def dp_Watch_List(qkMdOncHWzaBfGvgeVASjFXCToJlUr,args):
  qkMdOncHWzaBfGvgeVASjFXCToJlID =args.get('stype')
  if qkMdOncHWzaBfGvgeVASjFXCToJlID in['',qkMdOncHWzaBfGvgeVASjFXCToJlry]:
   for qkMdOncHWzaBfGvgeVASjFXCToJlRD in qkMdOncHWzaBfGvgeVASjFXCToJlUL:
    qkMdOncHWzaBfGvgeVASjFXCToJluL=qkMdOncHWzaBfGvgeVASjFXCToJlRD.get('title')
    qkMdOncHWzaBfGvgeVASjFXCToJluw={'mode':qkMdOncHWzaBfGvgeVASjFXCToJlRD.get('mode'),'stype':qkMdOncHWzaBfGvgeVASjFXCToJlRD.get('stype'),}
    qkMdOncHWzaBfGvgeVASjFXCToJlUr.add_dir(qkMdOncHWzaBfGvgeVASjFXCToJluL,sublabel='',img='',infoLabels=qkMdOncHWzaBfGvgeVASjFXCToJlry,isFolder=qkMdOncHWzaBfGvgeVASjFXCToJlrI,params=qkMdOncHWzaBfGvgeVASjFXCToJluw)
   xbmcplugin.endOfDirectory(qkMdOncHWzaBfGvgeVASjFXCToJlUr._addon_handle)
  else:
   qkMdOncHWzaBfGvgeVASjFXCToJlRN=qkMdOncHWzaBfGvgeVASjFXCToJlUr.Load_List_File(qkMdOncHWzaBfGvgeVASjFXCToJlID)
   for qkMdOncHWzaBfGvgeVASjFXCToJlRi in qkMdOncHWzaBfGvgeVASjFXCToJlRN:
    qkMdOncHWzaBfGvgeVASjFXCToJlRP=qkMdOncHWzaBfGvgeVASjFXCToJlrb(urllib.parse.parse_qsl(qkMdOncHWzaBfGvgeVASjFXCToJlRi))
    qkMdOncHWzaBfGvgeVASjFXCToJlLK =qkMdOncHWzaBfGvgeVASjFXCToJlRP.get('code').strip()
    qkMdOncHWzaBfGvgeVASjFXCToJluL =qkMdOncHWzaBfGvgeVASjFXCToJlRP.get('title').strip()
    qkMdOncHWzaBfGvgeVASjFXCToJlyQ =qkMdOncHWzaBfGvgeVASjFXCToJlRP.get('img').strip()
    qkMdOncHWzaBfGvgeVASjFXCToJlyw =qkMdOncHWzaBfGvgeVASjFXCToJlRP.get('asis').strip()
    try:
     qkMdOncHWzaBfGvgeVASjFXCToJlyQ=qkMdOncHWzaBfGvgeVASjFXCToJlyQ.replace('\'','\"')
     qkMdOncHWzaBfGvgeVASjFXCToJlyQ=json.loads(qkMdOncHWzaBfGvgeVASjFXCToJlyQ)
    except:
     qkMdOncHWzaBfGvgeVASjFXCToJlry
    qkMdOncHWzaBfGvgeVASjFXCToJlyR={}
    qkMdOncHWzaBfGvgeVASjFXCToJlyR['plot']=qkMdOncHWzaBfGvgeVASjFXCToJluL
    if qkMdOncHWzaBfGvgeVASjFXCToJlID=='movie':
     qkMdOncHWzaBfGvgeVASjFXCToJlyR['mediatype']='movie'
     qkMdOncHWzaBfGvgeVASjFXCToJluw={'mode':'MOVIE','id':qkMdOncHWzaBfGvgeVASjFXCToJlLK,'asis':qkMdOncHWzaBfGvgeVASjFXCToJlyw,'title':qkMdOncHWzaBfGvgeVASjFXCToJluL,'thumbnail':qkMdOncHWzaBfGvgeVASjFXCToJlyQ,}
     qkMdOncHWzaBfGvgeVASjFXCToJlux=qkMdOncHWzaBfGvgeVASjFXCToJlrL
    else:
     qkMdOncHWzaBfGvgeVASjFXCToJlyR['mediatype']='episode'
     qkMdOncHWzaBfGvgeVASjFXCToJluw={'mode':'SEASON_LIST','id':qkMdOncHWzaBfGvgeVASjFXCToJlLK,'asis':qkMdOncHWzaBfGvgeVASjFXCToJlyw,'title':qkMdOncHWzaBfGvgeVASjFXCToJluL,'thumbnail':json.dumps(qkMdOncHWzaBfGvgeVASjFXCToJlyQ,separators=(',',':')),}
     qkMdOncHWzaBfGvgeVASjFXCToJlux=qkMdOncHWzaBfGvgeVASjFXCToJlrI
    qkMdOncHWzaBfGvgeVASjFXCToJlRw={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','skey':qkMdOncHWzaBfGvgeVASjFXCToJlLK,'vType':qkMdOncHWzaBfGvgeVASjFXCToJlID,}
    qkMdOncHWzaBfGvgeVASjFXCToJlRx=urllib.parse.urlencode(qkMdOncHWzaBfGvgeVASjFXCToJlRw)
    qkMdOncHWzaBfGvgeVASjFXCToJlLy=[('선택된 시청이력 ( %s ) 삭제'%(qkMdOncHWzaBfGvgeVASjFXCToJluL),'RunPlugin(plugin://plugin.video.coupangm/?%s)'%(qkMdOncHWzaBfGvgeVASjFXCToJlRx))]
    qkMdOncHWzaBfGvgeVASjFXCToJlUr.add_dir(qkMdOncHWzaBfGvgeVASjFXCToJluL,sublabel='',img=qkMdOncHWzaBfGvgeVASjFXCToJlyQ,infoLabels=qkMdOncHWzaBfGvgeVASjFXCToJlyR,isFolder=qkMdOncHWzaBfGvgeVASjFXCToJlux,params=qkMdOncHWzaBfGvgeVASjFXCToJluw,ContextMenu=qkMdOncHWzaBfGvgeVASjFXCToJlLy)
   qkMdOncHWzaBfGvgeVASjFXCToJlyR={'plot':'시청목록을 삭제합니다.'}
   qkMdOncHWzaBfGvgeVASjFXCToJluL='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   qkMdOncHWzaBfGvgeVASjFXCToJluw={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':qkMdOncHWzaBfGvgeVASjFXCToJlID,}
   qkMdOncHWzaBfGvgeVASjFXCToJluQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.add_dir(qkMdOncHWzaBfGvgeVASjFXCToJluL,sublabel='',img=qkMdOncHWzaBfGvgeVASjFXCToJluQ,infoLabels=qkMdOncHWzaBfGvgeVASjFXCToJlyR,isFolder=qkMdOncHWzaBfGvgeVASjFXCToJlrL,params=qkMdOncHWzaBfGvgeVASjFXCToJluw,isLink=qkMdOncHWzaBfGvgeVASjFXCToJlrI)
   if qkMdOncHWzaBfGvgeVASjFXCToJlID=='movie':xbmcplugin.setContent(qkMdOncHWzaBfGvgeVASjFXCToJlUr._addon_handle,'movies')
   else:xbmcplugin.setContent(qkMdOncHWzaBfGvgeVASjFXCToJlUr._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(qkMdOncHWzaBfGvgeVASjFXCToJlUr._addon_handle,cacheToDisc=qkMdOncHWzaBfGvgeVASjFXCToJlrL)
 def dp_Set_Bookmark(qkMdOncHWzaBfGvgeVASjFXCToJlUr,args):
  qkMdOncHWzaBfGvgeVASjFXCToJlRK=urllib.parse.unquote(args.get('bm_param'))
  qkMdOncHWzaBfGvgeVASjFXCToJlRK=json.loads(qkMdOncHWzaBfGvgeVASjFXCToJlRK)
  qkMdOncHWzaBfGvgeVASjFXCToJlRm =qkMdOncHWzaBfGvgeVASjFXCToJlRK.get('videoid')
  qkMdOncHWzaBfGvgeVASjFXCToJlRs =qkMdOncHWzaBfGvgeVASjFXCToJlRK.get('vidtype')
  qkMdOncHWzaBfGvgeVASjFXCToJlRt =qkMdOncHWzaBfGvgeVASjFXCToJlRK.get('vtitle')
  qkMdOncHWzaBfGvgeVASjFXCToJlUh=xbmcgui.Dialog()
  qkMdOncHWzaBfGvgeVASjFXCToJluD=qkMdOncHWzaBfGvgeVASjFXCToJlUh.yesno(__language__(30914).encode('utf8'),qkMdOncHWzaBfGvgeVASjFXCToJlRt+' \n\n'+__language__(30915))
  if qkMdOncHWzaBfGvgeVASjFXCToJluD==qkMdOncHWzaBfGvgeVASjFXCToJlrL:return
  qkMdOncHWzaBfGvgeVASjFXCToJlRp=qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.GetBookmarkInfo(qkMdOncHWzaBfGvgeVASjFXCToJlRm,qkMdOncHWzaBfGvgeVASjFXCToJlRs)
  qkMdOncHWzaBfGvgeVASjFXCToJlrU=json.dumps(qkMdOncHWzaBfGvgeVASjFXCToJlRp)
  qkMdOncHWzaBfGvgeVASjFXCToJlrU=urllib.parse.quote(qkMdOncHWzaBfGvgeVASjFXCToJlrU)
  qkMdOncHWzaBfGvgeVASjFXCToJlLu ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(qkMdOncHWzaBfGvgeVASjFXCToJlrU)
  xbmc.executebuiltin(qkMdOncHWzaBfGvgeVASjFXCToJlLu)
 def coupang_main(qkMdOncHWzaBfGvgeVASjFXCToJlUr):
  qkMdOncHWzaBfGvgeVASjFXCToJlUr.CoupangObj.KodiVersion=qkMdOncHWzaBfGvgeVASjFXCToJlrw(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  qkMdOncHWzaBfGvgeVASjFXCToJlyt=qkMdOncHWzaBfGvgeVASjFXCToJlUr.main_params.get('mode',qkMdOncHWzaBfGvgeVASjFXCToJlry)
  if qkMdOncHWzaBfGvgeVASjFXCToJlyt=='LOGOUT':
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.CP_logout()
   return
  qkMdOncHWzaBfGvgeVASjFXCToJlUr.option_check()
  if qkMdOncHWzaBfGvgeVASjFXCToJlyt is qkMdOncHWzaBfGvgeVASjFXCToJlry:
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.dp_Main_List(qkMdOncHWzaBfGvgeVASjFXCToJlUr.main_params)
  elif qkMdOncHWzaBfGvgeVASjFXCToJlyt=='CATEGORY_GROUPLIST':
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.dp_Category_GroupList(qkMdOncHWzaBfGvgeVASjFXCToJlUr.main_params)
  elif qkMdOncHWzaBfGvgeVASjFXCToJlyt=='THEME_GROUPLIST':
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.dp_Theme_GroupList(qkMdOncHWzaBfGvgeVASjFXCToJlUr.main_params)
  elif qkMdOncHWzaBfGvgeVASjFXCToJlyt=='EVENT_GROUPLIST':
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.dp_Event_GroupList(qkMdOncHWzaBfGvgeVASjFXCToJlUr.main_params)
  elif qkMdOncHWzaBfGvgeVASjFXCToJlyt=='EVENT_GAMELIST':
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.dp_Event_GameList(qkMdOncHWzaBfGvgeVASjFXCToJlUr.main_params)
  elif qkMdOncHWzaBfGvgeVASjFXCToJlyt=='EVENT_LIST':
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.dp_Event_List(qkMdOncHWzaBfGvgeVASjFXCToJlUr.main_params)
  elif qkMdOncHWzaBfGvgeVASjFXCToJlyt=='CATEGORY_LIST':
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.dp_Category_List(qkMdOncHWzaBfGvgeVASjFXCToJlUr.main_params)
  elif qkMdOncHWzaBfGvgeVASjFXCToJlyt=='SEASON_LIST':
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.dp_Season_List(qkMdOncHWzaBfGvgeVASjFXCToJlUr.main_params)
  elif qkMdOncHWzaBfGvgeVASjFXCToJlyt=='EPISODE_LIST':
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.dp_Episode_List(qkMdOncHWzaBfGvgeVASjFXCToJlUr.main_params)
  elif qkMdOncHWzaBfGvgeVASjFXCToJlyt=='TEST':
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.dp_Test(qkMdOncHWzaBfGvgeVASjFXCToJlUr.main_params)
  elif qkMdOncHWzaBfGvgeVASjFXCToJlyt in['MOVIE','VOD','HIGHLIGHT','LIVE']:
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.play_VIDEO(qkMdOncHWzaBfGvgeVASjFXCToJlUr.main_params)
  elif qkMdOncHWzaBfGvgeVASjFXCToJlyt=='WATCH':
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.dp_Watch_List(qkMdOncHWzaBfGvgeVASjFXCToJlUr.main_params)
  elif qkMdOncHWzaBfGvgeVASjFXCToJlyt=='LOCAL_SEARCH':
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.dp_Search_List(qkMdOncHWzaBfGvgeVASjFXCToJlUr.main_params)
  elif qkMdOncHWzaBfGvgeVASjFXCToJlyt=='SEARCH_HISTORY':
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.dp_Search_History(qkMdOncHWzaBfGvgeVASjFXCToJlUr.main_params)
  elif qkMdOncHWzaBfGvgeVASjFXCToJlyt in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.dp_Listfile_Delete(qkMdOncHWzaBfGvgeVASjFXCToJlUr.main_params)
  elif qkMdOncHWzaBfGvgeVASjFXCToJlyt in['TOTAL_SEARCH','TOTAL_HISTORY']:
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.dp_Global_Search(qkMdOncHWzaBfGvgeVASjFXCToJlUr.main_params)
  elif qkMdOncHWzaBfGvgeVASjFXCToJlyt=='MENU_BOOKMARK':
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.dp_Bookmark_Menu(qkMdOncHWzaBfGvgeVASjFXCToJlUr.main_params)
  elif qkMdOncHWzaBfGvgeVASjFXCToJlyt=='SET_BOOKMARK':
   qkMdOncHWzaBfGvgeVASjFXCToJlUr.dp_Set_Bookmark(qkMdOncHWzaBfGvgeVASjFXCToJlUr.main_params)
  else:
   qkMdOncHWzaBfGvgeVASjFXCToJlry
# Created by pyminifier (https://github.com/liftoff/pyminifier)
