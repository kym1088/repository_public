__author__="NightRain"
yhCbUETeoAPvDOwLFBflSXjuzHgQnJ=object
yhCbUETeoAPvDOwLFBflSXjuzHgQnp=None
yhCbUETeoAPvDOwLFBflSXjuzHgQnM=False
yhCbUETeoAPvDOwLFBflSXjuzHgQnd=True
yhCbUETeoAPvDOwLFBflSXjuzHgQnm=type
yhCbUETeoAPvDOwLFBflSXjuzHgQnI=dict
yhCbUETeoAPvDOwLFBflSXjuzHgQnK=int
yhCbUETeoAPvDOwLFBflSXjuzHgQnq=open
yhCbUETeoAPvDOwLFBflSXjuzHgQRx=Exception
yhCbUETeoAPvDOwLFBflSXjuzHgQRk=str
yhCbUETeoAPvDOwLFBflSXjuzHgQRW=id
yhCbUETeoAPvDOwLFBflSXjuzHgQRs=len
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import inputstreamhelper
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
yhCbUETeoAPvDOwLFBflSXjuzHgQxW=[{'title':'홈   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'ALL'},{'title':'TV   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'MOVIES'},{'title':'교육 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'EDUCATION'},{'title':'생중계','mode':'EVENT_GROUPLIST','vType':'LIVE'},{'title':'TV   (테마별)','mode':'THEME_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (테마별)','mode':'THEME_GROUPLIST','vType':'MOVIES'},{'title':'교육 (테마별)','mode':'THEME_GROUPLIST','vType':'EDUCATION'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},{'title':'(쿠팡) 검색','mode':'LOCAL_SEARCH','icon':'search.png'},{'title':'(쿠팡) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
yhCbUETeoAPvDOwLFBflSXjuzHgQxs=[{'title':'시리즈 시청내역','mode':'WATCH','stype':'tvshow'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},]
yhCbUETeoAPvDOwLFBflSXjuzHgQxa=xbmcvfs.translatePath(os.path.join(__profile__,'coupang_searched.txt'))
from coupangCore import*
class yhCbUETeoAPvDOwLFBflSXjuzHgQxk(yhCbUETeoAPvDOwLFBflSXjuzHgQnJ):
 def __init__(yhCbUETeoAPvDOwLFBflSXjuzHgQxn,yhCbUETeoAPvDOwLFBflSXjuzHgQxR,yhCbUETeoAPvDOwLFBflSXjuzHgQxr,yhCbUETeoAPvDOwLFBflSXjuzHgQxc):
  yhCbUETeoAPvDOwLFBflSXjuzHgQxn._addon_url =yhCbUETeoAPvDOwLFBflSXjuzHgQxR
  yhCbUETeoAPvDOwLFBflSXjuzHgQxn._addon_handle=yhCbUETeoAPvDOwLFBflSXjuzHgQxr
  yhCbUETeoAPvDOwLFBflSXjuzHgQxn.main_params =yhCbUETeoAPvDOwLFBflSXjuzHgQxc
  yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj =NtyUuvFErsfhPRgqKVJTHQIlXACMnd() 
  yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.CP_COOKIE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_cookies.json'))
  yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.CP_DEVICE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_device.json'))
 def addon_noti(yhCbUETeoAPvDOwLFBflSXjuzHgQxn,sting):
  try:
   yhCbUETeoAPvDOwLFBflSXjuzHgQxN=xbmcgui.Dialog()
   yhCbUETeoAPvDOwLFBflSXjuzHgQxN.notification(__addonname__,sting)
  except:
   yhCbUETeoAPvDOwLFBflSXjuzHgQnp
 def addon_log(yhCbUETeoAPvDOwLFBflSXjuzHgQxn,string):
  try:
   yhCbUETeoAPvDOwLFBflSXjuzHgQxV=string.encode('utf-8','ignore')
  except:
   yhCbUETeoAPvDOwLFBflSXjuzHgQxV='addonException: addon_log'
  yhCbUETeoAPvDOwLFBflSXjuzHgQxt=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,yhCbUETeoAPvDOwLFBflSXjuzHgQxV),level=yhCbUETeoAPvDOwLFBflSXjuzHgQxt)
 def get_keyboard_input(yhCbUETeoAPvDOwLFBflSXjuzHgQxn,yhCbUETeoAPvDOwLFBflSXjuzHgQkW):
  yhCbUETeoAPvDOwLFBflSXjuzHgQxY=yhCbUETeoAPvDOwLFBflSXjuzHgQnp
  kb=xbmc.Keyboard()
  kb.setHeading(yhCbUETeoAPvDOwLFBflSXjuzHgQkW)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   yhCbUETeoAPvDOwLFBflSXjuzHgQxY=kb.getText()
  return yhCbUETeoAPvDOwLFBflSXjuzHgQxY
 def get_settings_account(yhCbUETeoAPvDOwLFBflSXjuzHgQxn):
  yhCbUETeoAPvDOwLFBflSXjuzHgQxi=__addon__.getSetting('id')
  yhCbUETeoAPvDOwLFBflSXjuzHgQxJ=__addon__.getSetting('pw')
  yhCbUETeoAPvDOwLFBflSXjuzHgQxp=__addon__.getSetting('profile')
  return(yhCbUETeoAPvDOwLFBflSXjuzHgQxi,yhCbUETeoAPvDOwLFBflSXjuzHgQxJ,yhCbUETeoAPvDOwLFBflSXjuzHgQxp)
 def get_settings_exclusion21(yhCbUETeoAPvDOwLFBflSXjuzHgQxn):
  yhCbUETeoAPvDOwLFBflSXjuzHgQxM =__addon__.getSetting('exclusion21')
  if yhCbUETeoAPvDOwLFBflSXjuzHgQxM=='false':
   return yhCbUETeoAPvDOwLFBflSXjuzHgQnM
  else:
   return yhCbUETeoAPvDOwLFBflSXjuzHgQnd
 def get_settings_totalsearch(yhCbUETeoAPvDOwLFBflSXjuzHgQxn):
  yhCbUETeoAPvDOwLFBflSXjuzHgQxd =yhCbUETeoAPvDOwLFBflSXjuzHgQnd if __addon__.getSetting('local_search')=='true' else yhCbUETeoAPvDOwLFBflSXjuzHgQnM
  yhCbUETeoAPvDOwLFBflSXjuzHgQxm=yhCbUETeoAPvDOwLFBflSXjuzHgQnd if __addon__.getSetting('local_history')=='true' else yhCbUETeoAPvDOwLFBflSXjuzHgQnM
  yhCbUETeoAPvDOwLFBflSXjuzHgQxI =yhCbUETeoAPvDOwLFBflSXjuzHgQnd if __addon__.getSetting('total_search')=='true' else yhCbUETeoAPvDOwLFBflSXjuzHgQnM
  yhCbUETeoAPvDOwLFBflSXjuzHgQxK=yhCbUETeoAPvDOwLFBflSXjuzHgQnd if __addon__.getSetting('total_history')=='true' else yhCbUETeoAPvDOwLFBflSXjuzHgQnM
  yhCbUETeoAPvDOwLFBflSXjuzHgQxq=yhCbUETeoAPvDOwLFBflSXjuzHgQnd if __addon__.getSetting('menu_bookmark')=='true' else yhCbUETeoAPvDOwLFBflSXjuzHgQnM
  return(yhCbUETeoAPvDOwLFBflSXjuzHgQxd,yhCbUETeoAPvDOwLFBflSXjuzHgQxm,yhCbUETeoAPvDOwLFBflSXjuzHgQxI,yhCbUETeoAPvDOwLFBflSXjuzHgQxK,yhCbUETeoAPvDOwLFBflSXjuzHgQxq)
 def get_settings_makebookmark(yhCbUETeoAPvDOwLFBflSXjuzHgQxn):
  return yhCbUETeoAPvDOwLFBflSXjuzHgQnd if __addon__.getSetting('make_bookmark')=='true' else yhCbUETeoAPvDOwLFBflSXjuzHgQnM
 def add_dir(yhCbUETeoAPvDOwLFBflSXjuzHgQxn,label,sublabel='',img='',infoLabels=yhCbUETeoAPvDOwLFBflSXjuzHgQnp,isFolder=yhCbUETeoAPvDOwLFBflSXjuzHgQnd,params='',isLink=yhCbUETeoAPvDOwLFBflSXjuzHgQnM,ContextMenu=yhCbUETeoAPvDOwLFBflSXjuzHgQnp):
  yhCbUETeoAPvDOwLFBflSXjuzHgQkx='%s?%s'%(yhCbUETeoAPvDOwLFBflSXjuzHgQxn._addon_url,urllib.parse.urlencode(params))
  if sublabel:yhCbUETeoAPvDOwLFBflSXjuzHgQkW='%s < %s >'%(label,sublabel)
  else: yhCbUETeoAPvDOwLFBflSXjuzHgQkW=label
  if not img:img='DefaultFolder.png'
  yhCbUETeoAPvDOwLFBflSXjuzHgQks=xbmcgui.ListItem(yhCbUETeoAPvDOwLFBflSXjuzHgQkW)
  if yhCbUETeoAPvDOwLFBflSXjuzHgQnm(img)==yhCbUETeoAPvDOwLFBflSXjuzHgQnI:
   yhCbUETeoAPvDOwLFBflSXjuzHgQks.setArt(img)
  else:
   yhCbUETeoAPvDOwLFBflSXjuzHgQks.setArt({'thumb':img,'poster':img})
  if infoLabels:yhCbUETeoAPvDOwLFBflSXjuzHgQks.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   yhCbUETeoAPvDOwLFBflSXjuzHgQks.setProperty('IsPlayable','true')
  if ContextMenu:yhCbUETeoAPvDOwLFBflSXjuzHgQks.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(yhCbUETeoAPvDOwLFBflSXjuzHgQxn._addon_handle,yhCbUETeoAPvDOwLFBflSXjuzHgQkx,yhCbUETeoAPvDOwLFBflSXjuzHgQks,isFolder)
 def dp_Main_List(yhCbUETeoAPvDOwLFBflSXjuzHgQxn,args):
  (yhCbUETeoAPvDOwLFBflSXjuzHgQxd,yhCbUETeoAPvDOwLFBflSXjuzHgQxm,yhCbUETeoAPvDOwLFBflSXjuzHgQxI,yhCbUETeoAPvDOwLFBflSXjuzHgQxK,yhCbUETeoAPvDOwLFBflSXjuzHgQxq)=yhCbUETeoAPvDOwLFBflSXjuzHgQxn.get_settings_totalsearch()
  for yhCbUETeoAPvDOwLFBflSXjuzHgQka in yhCbUETeoAPvDOwLFBflSXjuzHgQxW:
   yhCbUETeoAPvDOwLFBflSXjuzHgQkW=yhCbUETeoAPvDOwLFBflSXjuzHgQka.get('title')
   yhCbUETeoAPvDOwLFBflSXjuzHgQkn=''
   if yhCbUETeoAPvDOwLFBflSXjuzHgQka.get('mode')=='LOCAL_SEARCH' and yhCbUETeoAPvDOwLFBflSXjuzHgQxd ==yhCbUETeoAPvDOwLFBflSXjuzHgQnM:continue
   elif yhCbUETeoAPvDOwLFBflSXjuzHgQka.get('mode')=='SEARCH_HISTORY' and yhCbUETeoAPvDOwLFBflSXjuzHgQxm==yhCbUETeoAPvDOwLFBflSXjuzHgQnM:continue
   elif yhCbUETeoAPvDOwLFBflSXjuzHgQka.get('mode')=='TOTAL_SEARCH' and yhCbUETeoAPvDOwLFBflSXjuzHgQxI ==yhCbUETeoAPvDOwLFBflSXjuzHgQnM:continue
   elif yhCbUETeoAPvDOwLFBflSXjuzHgQka.get('mode')=='TOTAL_HISTORY' and yhCbUETeoAPvDOwLFBflSXjuzHgQxK==yhCbUETeoAPvDOwLFBflSXjuzHgQnM:continue
   elif yhCbUETeoAPvDOwLFBflSXjuzHgQka.get('mode')=='MENU_BOOKMARK' and yhCbUETeoAPvDOwLFBflSXjuzHgQxq==yhCbUETeoAPvDOwLFBflSXjuzHgQnM:continue
   yhCbUETeoAPvDOwLFBflSXjuzHgQkR={'mode':yhCbUETeoAPvDOwLFBflSXjuzHgQka.get('mode'),'vType':yhCbUETeoAPvDOwLFBflSXjuzHgQka.get('vType'),'page':'1',}
   if yhCbUETeoAPvDOwLFBflSXjuzHgQka.get('mode')=='LOCAL_SEARCH':yhCbUETeoAPvDOwLFBflSXjuzHgQkR['historyyn']='Y' 
   if yhCbUETeoAPvDOwLFBflSXjuzHgQka.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    yhCbUETeoAPvDOwLFBflSXjuzHgQkr=yhCbUETeoAPvDOwLFBflSXjuzHgQnM
    yhCbUETeoAPvDOwLFBflSXjuzHgQkc =yhCbUETeoAPvDOwLFBflSXjuzHgQnd
   else:
    yhCbUETeoAPvDOwLFBflSXjuzHgQkr=yhCbUETeoAPvDOwLFBflSXjuzHgQnd
    yhCbUETeoAPvDOwLFBflSXjuzHgQkc =yhCbUETeoAPvDOwLFBflSXjuzHgQnM
   if 'icon' in yhCbUETeoAPvDOwLFBflSXjuzHgQka:yhCbUETeoAPvDOwLFBflSXjuzHgQkn=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',yhCbUETeoAPvDOwLFBflSXjuzHgQka.get('icon')) 
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.add_dir(yhCbUETeoAPvDOwLFBflSXjuzHgQkW,sublabel='',img=yhCbUETeoAPvDOwLFBflSXjuzHgQkn,infoLabels=yhCbUETeoAPvDOwLFBflSXjuzHgQnp,isFolder=yhCbUETeoAPvDOwLFBflSXjuzHgQkr,params=yhCbUETeoAPvDOwLFBflSXjuzHgQkR,isLink=yhCbUETeoAPvDOwLFBflSXjuzHgQkc)
  xbmcplugin.endOfDirectory(yhCbUETeoAPvDOwLFBflSXjuzHgQxn._addon_handle)
 def dp_Test(yhCbUETeoAPvDOwLFBflSXjuzHgQxn,args):
  yhCbUETeoAPvDOwLFBflSXjuzHgQxn.addon_noti('test')
 def CP_logout(yhCbUETeoAPvDOwLFBflSXjuzHgQxn):
  yhCbUETeoAPvDOwLFBflSXjuzHgQxN=xbmcgui.Dialog()
  yhCbUETeoAPvDOwLFBflSXjuzHgQkN=yhCbUETeoAPvDOwLFBflSXjuzHgQxN.yesno(__language__(30905).encode('utf8'),__language__(30906).encode('utf8'))
  if yhCbUETeoAPvDOwLFBflSXjuzHgQkN==yhCbUETeoAPvDOwLFBflSXjuzHgQnM:return 
  if os.path.isfile(yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.CP_COOKIE_FILENAME):os.remove(yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.CP_COOKIE_FILENAME)
  yhCbUETeoAPvDOwLFBflSXjuzHgQxn.addon_noti(__language__(30904).encode('utf-8'))
 def option_check(yhCbUETeoAPvDOwLFBflSXjuzHgQxn):
  (yhCbUETeoAPvDOwLFBflSXjuzHgQxi,yhCbUETeoAPvDOwLFBflSXjuzHgQxJ,yhCbUETeoAPvDOwLFBflSXjuzHgQxp)=yhCbUETeoAPvDOwLFBflSXjuzHgQxn.get_settings_account()
  if yhCbUETeoAPvDOwLFBflSXjuzHgQxi=='' or yhCbUETeoAPvDOwLFBflSXjuzHgQxJ=='':
   yhCbUETeoAPvDOwLFBflSXjuzHgQxN=xbmcgui.Dialog()
   yhCbUETeoAPvDOwLFBflSXjuzHgQkN=yhCbUETeoAPvDOwLFBflSXjuzHgQxN.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if yhCbUETeoAPvDOwLFBflSXjuzHgQkN==yhCbUETeoAPvDOwLFBflSXjuzHgQnd:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if yhCbUETeoAPvDOwLFBflSXjuzHgQxn.cookiefile_check()==yhCbUETeoAPvDOwLFBflSXjuzHgQnM:
   if yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CP_login(yhCbUETeoAPvDOwLFBflSXjuzHgQxi,yhCbUETeoAPvDOwLFBflSXjuzHgQxJ,yhCbUETeoAPvDOwLFBflSXjuzHgQxp)==yhCbUETeoAPvDOwLFBflSXjuzHgQnM:
    yhCbUETeoAPvDOwLFBflSXjuzHgQxn.addon_noti(__language__(30903).encode('utf8'))
    sys.exit()
  else:
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.Get_CP_profile(yhCbUETeoAPvDOwLFBflSXjuzHgQxp,limit_days=yhCbUETeoAPvDOwLFBflSXjuzHgQnK(__addon__.getSetting('cache_ttl')),re_check=yhCbUETeoAPvDOwLFBflSXjuzHgQnd)
 def cookiefile_check(yhCbUETeoAPvDOwLFBflSXjuzHgQxn):
  yhCbUETeoAPvDOwLFBflSXjuzHgQkt={}
  try: 
   fp=yhCbUETeoAPvDOwLFBflSXjuzHgQnq(yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.CP_COOKIE_FILENAME,'r',-1,'utf-8')
   yhCbUETeoAPvDOwLFBflSXjuzHgQkt= json.load(fp)
   fp.close()
  except yhCbUETeoAPvDOwLFBflSXjuzHgQRx as exception:
   return yhCbUETeoAPvDOwLFBflSXjuzHgQnM
  yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.CP=yhCbUETeoAPvDOwLFBflSXjuzHgQkt
  (yhCbUETeoAPvDOwLFBflSXjuzHgQxi,yhCbUETeoAPvDOwLFBflSXjuzHgQxJ,yhCbUETeoAPvDOwLFBflSXjuzHgQxp)=yhCbUETeoAPvDOwLFBflSXjuzHgQxn.get_settings_account()
  (yhCbUETeoAPvDOwLFBflSXjuzHgQkY,yhCbUETeoAPvDOwLFBflSXjuzHgQki,yhCbUETeoAPvDOwLFBflSXjuzHgQkJ)=yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.Load_session_acount()
  if yhCbUETeoAPvDOwLFBflSXjuzHgQxi!=yhCbUETeoAPvDOwLFBflSXjuzHgQkY or yhCbUETeoAPvDOwLFBflSXjuzHgQxJ!=yhCbUETeoAPvDOwLFBflSXjuzHgQki or yhCbUETeoAPvDOwLFBflSXjuzHgQxp!=yhCbUETeoAPvDOwLFBflSXjuzHgQRk(yhCbUETeoAPvDOwLFBflSXjuzHgQkJ):
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.Init_CP()
   return yhCbUETeoAPvDOwLFBflSXjuzHgQnM
  yhCbUETeoAPvDOwLFBflSXjuzHgQkp =yhCbUETeoAPvDOwLFBflSXjuzHgQnK(yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.Get_Now_Datetime().strftime('%Y%m%d'))
  yhCbUETeoAPvDOwLFBflSXjuzHgQkM=yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.CP['SESSION']['limitdate']
  yhCbUETeoAPvDOwLFBflSXjuzHgQkd =yhCbUETeoAPvDOwLFBflSXjuzHgQnK(re.sub('-','',yhCbUETeoAPvDOwLFBflSXjuzHgQkM))
  if yhCbUETeoAPvDOwLFBflSXjuzHgQkd<yhCbUETeoAPvDOwLFBflSXjuzHgQkp:
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.Init_CP()
   return yhCbUETeoAPvDOwLFBflSXjuzHgQnM
  return yhCbUETeoAPvDOwLFBflSXjuzHgQnd
 def CP_login(yhCbUETeoAPvDOwLFBflSXjuzHgQxn,yhCbUETeoAPvDOwLFBflSXjuzHgQxi,yhCbUETeoAPvDOwLFBflSXjuzHgQxJ,yhCbUETeoAPvDOwLFBflSXjuzHgQxp):
  if yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.Get_CP_Login(yhCbUETeoAPvDOwLFBflSXjuzHgQxi,yhCbUETeoAPvDOwLFBflSXjuzHgQxJ,yhCbUETeoAPvDOwLFBflSXjuzHgQxp)==yhCbUETeoAPvDOwLFBflSXjuzHgQnM:return yhCbUETeoAPvDOwLFBflSXjuzHgQnM
  if yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.Get_CP_profile(yhCbUETeoAPvDOwLFBflSXjuzHgQxp,limit_days=yhCbUETeoAPvDOwLFBflSXjuzHgQnK(__addon__.getSetting('cache_ttl')),re_check=yhCbUETeoAPvDOwLFBflSXjuzHgQnM)==yhCbUETeoAPvDOwLFBflSXjuzHgQnM:return yhCbUETeoAPvDOwLFBflSXjuzHgQnM
  return yhCbUETeoAPvDOwLFBflSXjuzHgQnd
 def dp_Category_GroupList(yhCbUETeoAPvDOwLFBflSXjuzHgQxn,args):
  yhCbUETeoAPvDOwLFBflSXjuzHgQkm =args.get('vType') 
  yhCbUETeoAPvDOwLFBflSXjuzHgQkI=yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.Get_Category_GroupList(yhCbUETeoAPvDOwLFBflSXjuzHgQkm)
  for yhCbUETeoAPvDOwLFBflSXjuzHgQkK in yhCbUETeoAPvDOwLFBflSXjuzHgQkI:
   yhCbUETeoAPvDOwLFBflSXjuzHgQkW =yhCbUETeoAPvDOwLFBflSXjuzHgQkK.get('title')
   yhCbUETeoAPvDOwLFBflSXjuzHgQkq=yhCbUETeoAPvDOwLFBflSXjuzHgQkK.get('pre_title')
   if yhCbUETeoAPvDOwLFBflSXjuzHgQxn.get_settings_exclusion21()==yhCbUETeoAPvDOwLFBflSXjuzHgQnd and yhCbUETeoAPvDOwLFBflSXjuzHgQkW=='성인':continue
   yhCbUETeoAPvDOwLFBflSXjuzHgQWx={'mediatype':'tvshow','plot':yhCbUETeoAPvDOwLFBflSXjuzHgQkq,}
   yhCbUETeoAPvDOwLFBflSXjuzHgQkR={'mode':'CATEGORY_LIST','collectionId':yhCbUETeoAPvDOwLFBflSXjuzHgQkK.get('collectionId'),'vType':yhCbUETeoAPvDOwLFBflSXjuzHgQkK.get('category'),'page':'1',}
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.add_dir(yhCbUETeoAPvDOwLFBflSXjuzHgQkW,sublabel='',img='',infoLabels=yhCbUETeoAPvDOwLFBflSXjuzHgQWx,isFolder=yhCbUETeoAPvDOwLFBflSXjuzHgQnd,params=yhCbUETeoAPvDOwLFBflSXjuzHgQkR)
  xbmcplugin.endOfDirectory(yhCbUETeoAPvDOwLFBflSXjuzHgQxn._addon_handle,cacheToDisc=yhCbUETeoAPvDOwLFBflSXjuzHgQnM)
 def dp_Theme_GroupList(yhCbUETeoAPvDOwLFBflSXjuzHgQxn,args):
  yhCbUETeoAPvDOwLFBflSXjuzHgQkm =args.get('vType') 
  yhCbUETeoAPvDOwLFBflSXjuzHgQkI=yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.Get_Theme_GroupList(yhCbUETeoAPvDOwLFBflSXjuzHgQkm)
  for yhCbUETeoAPvDOwLFBflSXjuzHgQkK in yhCbUETeoAPvDOwLFBflSXjuzHgQkI:
   yhCbUETeoAPvDOwLFBflSXjuzHgQkW =yhCbUETeoAPvDOwLFBflSXjuzHgQkK.get('title')
   yhCbUETeoAPvDOwLFBflSXjuzHgQkq=yhCbUETeoAPvDOwLFBflSXjuzHgQkK.get('pre_title')
   yhCbUETeoAPvDOwLFBflSXjuzHgQWx={'mediatype':'tvshow','plot':yhCbUETeoAPvDOwLFBflSXjuzHgQkq,}
   yhCbUETeoAPvDOwLFBflSXjuzHgQkR={'mode':'CATEGORY_LIST','collectionId':yhCbUETeoAPvDOwLFBflSXjuzHgQkK.get('collectionId'),'vType':yhCbUETeoAPvDOwLFBflSXjuzHgQkK.get('category'),'page':'1',}
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.add_dir(yhCbUETeoAPvDOwLFBflSXjuzHgQkW,sublabel='',img='',infoLabels=yhCbUETeoAPvDOwLFBflSXjuzHgQWx,isFolder=yhCbUETeoAPvDOwLFBflSXjuzHgQnd,params=yhCbUETeoAPvDOwLFBflSXjuzHgQkR)
  xbmcplugin.endOfDirectory(yhCbUETeoAPvDOwLFBflSXjuzHgQxn._addon_handle,cacheToDisc=yhCbUETeoAPvDOwLFBflSXjuzHgQnM)
 def dp_Event_GroupList(yhCbUETeoAPvDOwLFBflSXjuzHgQxn,args):
  yhCbUETeoAPvDOwLFBflSXjuzHgQkI=yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.Get_Event_GroupList()
  for yhCbUETeoAPvDOwLFBflSXjuzHgQkK in yhCbUETeoAPvDOwLFBflSXjuzHgQkI:
   yhCbUETeoAPvDOwLFBflSXjuzHgQkW =yhCbUETeoAPvDOwLFBflSXjuzHgQkK.get('title')
   yhCbUETeoAPvDOwLFBflSXjuzHgQkq=yhCbUETeoAPvDOwLFBflSXjuzHgQkK.get('pre_title')
   yhCbUETeoAPvDOwLFBflSXjuzHgQWx={'mediatype':'tvshow','plot':yhCbUETeoAPvDOwLFBflSXjuzHgQkq,}
   yhCbUETeoAPvDOwLFBflSXjuzHgQkR={'mode':'EVENT_GAMELIST','collectionId':yhCbUETeoAPvDOwLFBflSXjuzHgQkK.get('collectionId'),'vType':'LIVE',}
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.add_dir(yhCbUETeoAPvDOwLFBflSXjuzHgQkW,sublabel='',img='',infoLabels=yhCbUETeoAPvDOwLFBflSXjuzHgQWx,isFolder=yhCbUETeoAPvDOwLFBflSXjuzHgQnd,params=yhCbUETeoAPvDOwLFBflSXjuzHgQkR)
  xbmcplugin.endOfDirectory(yhCbUETeoAPvDOwLFBflSXjuzHgQxn._addon_handle,cacheToDisc=yhCbUETeoAPvDOwLFBflSXjuzHgQnM)
 def dp_Event_GameList(yhCbUETeoAPvDOwLFBflSXjuzHgQxn,args):
  yhCbUETeoAPvDOwLFBflSXjuzHgQkm =args.get('vType') 
  yhCbUETeoAPvDOwLFBflSXjuzHgQWs =args.get('collectionId')
  yhCbUETeoAPvDOwLFBflSXjuzHgQkI=yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.Get_Event_GameList(yhCbUETeoAPvDOwLFBflSXjuzHgQWs)
  for yhCbUETeoAPvDOwLFBflSXjuzHgQkK in yhCbUETeoAPvDOwLFBflSXjuzHgQkI:
   yhCbUETeoAPvDOwLFBflSXjuzHgQkW =yhCbUETeoAPvDOwLFBflSXjuzHgQkK.get('title')
   yhCbUETeoAPvDOwLFBflSXjuzHgQRW =yhCbUETeoAPvDOwLFBflSXjuzHgQkK.get('id')
   yhCbUETeoAPvDOwLFBflSXjuzHgQWa =yhCbUETeoAPvDOwLFBflSXjuzHgQkK.get('thumbnail')
   yhCbUETeoAPvDOwLFBflSXjuzHgQWn =yhCbUETeoAPvDOwLFBflSXjuzHgQkK.get('asis') 
   yhCbUETeoAPvDOwLFBflSXjuzHgQWR =yhCbUETeoAPvDOwLFBflSXjuzHgQkK.get('addInfo')
   yhCbUETeoAPvDOwLFBflSXjuzHgQWr =yhCbUETeoAPvDOwLFBflSXjuzHgQkK.get('starttm')
   yhCbUETeoAPvDOwLFBflSXjuzHgQWx={'mediatype':'tvshow','title':yhCbUETeoAPvDOwLFBflSXjuzHgQkW,'plot':yhCbUETeoAPvDOwLFBflSXjuzHgQWR,}
   yhCbUETeoAPvDOwLFBflSXjuzHgQkR={'mode':'EVENT_LIST','id':yhCbUETeoAPvDOwLFBflSXjuzHgQRW,'asis':yhCbUETeoAPvDOwLFBflSXjuzHgQWn,'title':yhCbUETeoAPvDOwLFBflSXjuzHgQkW,}
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.add_dir(yhCbUETeoAPvDOwLFBflSXjuzHgQkW,sublabel=yhCbUETeoAPvDOwLFBflSXjuzHgQWr,img=yhCbUETeoAPvDOwLFBflSXjuzHgQWa,infoLabels=yhCbUETeoAPvDOwLFBflSXjuzHgQWx,isFolder=yhCbUETeoAPvDOwLFBflSXjuzHgQnd,params=yhCbUETeoAPvDOwLFBflSXjuzHgQkR,ContextMenu=yhCbUETeoAPvDOwLFBflSXjuzHgQnp)
  xbmcplugin.setContent(yhCbUETeoAPvDOwLFBflSXjuzHgQxn._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(yhCbUETeoAPvDOwLFBflSXjuzHgQxn._addon_handle,cacheToDisc=yhCbUETeoAPvDOwLFBflSXjuzHgQnM)
 def dp_Event_List(yhCbUETeoAPvDOwLFBflSXjuzHgQxn,args):
  yhCbUETeoAPvDOwLFBflSXjuzHgQWc=args.get('id')
  yhCbUETeoAPvDOwLFBflSXjuzHgQkI=yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.Get_Event_List(yhCbUETeoAPvDOwLFBflSXjuzHgQWc)
  for yhCbUETeoAPvDOwLFBflSXjuzHgQkK in yhCbUETeoAPvDOwLFBflSXjuzHgQkI:
   yhCbUETeoAPvDOwLFBflSXjuzHgQkW =yhCbUETeoAPvDOwLFBflSXjuzHgQkK.get('title')
   yhCbUETeoAPvDOwLFBflSXjuzHgQRW =yhCbUETeoAPvDOwLFBflSXjuzHgQkK.get('id')
   yhCbUETeoAPvDOwLFBflSXjuzHgQWa =yhCbUETeoAPvDOwLFBflSXjuzHgQkK.get('thumbnail')
   yhCbUETeoAPvDOwLFBflSXjuzHgQWn =yhCbUETeoAPvDOwLFBflSXjuzHgQkK.get('asis') 
   yhCbUETeoAPvDOwLFBflSXjuzHgQWG =yhCbUETeoAPvDOwLFBflSXjuzHgQkK.get('duration')
   yhCbUETeoAPvDOwLFBflSXjuzHgQWr =yhCbUETeoAPvDOwLFBflSXjuzHgQkK.get('starttm')
   yhCbUETeoAPvDOwLFBflSXjuzHgQWx={'mediatype':'episode','title':yhCbUETeoAPvDOwLFBflSXjuzHgQkW,'plot':yhCbUETeoAPvDOwLFBflSXjuzHgQWn,'duration':yhCbUETeoAPvDOwLFBflSXjuzHgQWG,}
   yhCbUETeoAPvDOwLFBflSXjuzHgQkR={'mode':yhCbUETeoAPvDOwLFBflSXjuzHgQWn,'id':yhCbUETeoAPvDOwLFBflSXjuzHgQRW,'asis':yhCbUETeoAPvDOwLFBflSXjuzHgQWn,'title':yhCbUETeoAPvDOwLFBflSXjuzHgQkW,}
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.add_dir(yhCbUETeoAPvDOwLFBflSXjuzHgQkW,sublabel=yhCbUETeoAPvDOwLFBflSXjuzHgQWr,img=yhCbUETeoAPvDOwLFBflSXjuzHgQWa,infoLabels=yhCbUETeoAPvDOwLFBflSXjuzHgQWx,isFolder=yhCbUETeoAPvDOwLFBflSXjuzHgQnM,params=yhCbUETeoAPvDOwLFBflSXjuzHgQkR,ContextMenu=yhCbUETeoAPvDOwLFBflSXjuzHgQnp)
  xbmcplugin.setContent(yhCbUETeoAPvDOwLFBflSXjuzHgQxn._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(yhCbUETeoAPvDOwLFBflSXjuzHgQxn._addon_handle,cacheToDisc=yhCbUETeoAPvDOwLFBflSXjuzHgQnM)
 def dp_Category_List(yhCbUETeoAPvDOwLFBflSXjuzHgQxn,args):
  yhCbUETeoAPvDOwLFBflSXjuzHgQkm =args.get('vType') 
  yhCbUETeoAPvDOwLFBflSXjuzHgQWs =args.get('collectionId')
  yhCbUETeoAPvDOwLFBflSXjuzHgQWN =yhCbUETeoAPvDOwLFBflSXjuzHgQnK(args.get('page'))
  yhCbUETeoAPvDOwLFBflSXjuzHgQkI,yhCbUETeoAPvDOwLFBflSXjuzHgQWV=yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.Get_Category_List(yhCbUETeoAPvDOwLFBflSXjuzHgQkm,yhCbUETeoAPvDOwLFBflSXjuzHgQWs,yhCbUETeoAPvDOwLFBflSXjuzHgQWN)
  for yhCbUETeoAPvDOwLFBflSXjuzHgQkK in yhCbUETeoAPvDOwLFBflSXjuzHgQkI:
   yhCbUETeoAPvDOwLFBflSXjuzHgQkW =yhCbUETeoAPvDOwLFBflSXjuzHgQkK.get('title')
   yhCbUETeoAPvDOwLFBflSXjuzHgQRW =yhCbUETeoAPvDOwLFBflSXjuzHgQkK.get('id')
   yhCbUETeoAPvDOwLFBflSXjuzHgQWa =yhCbUETeoAPvDOwLFBflSXjuzHgQkK.get('thumbnail')
   yhCbUETeoAPvDOwLFBflSXjuzHgQWt =yhCbUETeoAPvDOwLFBflSXjuzHgQkK.get('mpaa')
   yhCbUETeoAPvDOwLFBflSXjuzHgQWG =yhCbUETeoAPvDOwLFBflSXjuzHgQkK.get('duration')
   yhCbUETeoAPvDOwLFBflSXjuzHgQWn =yhCbUETeoAPvDOwLFBflSXjuzHgQkK.get('asis')
   yhCbUETeoAPvDOwLFBflSXjuzHgQWY =yhCbUETeoAPvDOwLFBflSXjuzHgQkK.get('badge')
   yhCbUETeoAPvDOwLFBflSXjuzHgQWi =yhCbUETeoAPvDOwLFBflSXjuzHgQkK.get('year')
   yhCbUETeoAPvDOwLFBflSXjuzHgQWJ=yhCbUETeoAPvDOwLFBflSXjuzHgQkK.get('seasonList')
   yhCbUETeoAPvDOwLFBflSXjuzHgQWp =yhCbUETeoAPvDOwLFBflSXjuzHgQkK.get('genreList')
   if yhCbUETeoAPvDOwLFBflSXjuzHgQWn in['TVSHOW','EDUCATION']: 
    yhCbUETeoAPvDOwLFBflSXjuzHgQWM ='SEASON_LIST'
    yhCbUETeoAPvDOwLFBflSXjuzHgQWx={'mediatype':'tvshow','title':yhCbUETeoAPvDOwLFBflSXjuzHgQkW,'mpaa':yhCbUETeoAPvDOwLFBflSXjuzHgQWt,'genre':yhCbUETeoAPvDOwLFBflSXjuzHgQWp,'year':yhCbUETeoAPvDOwLFBflSXjuzHgQWi,'plot':'Year : %s\nSeason : %s'%(yhCbUETeoAPvDOwLFBflSXjuzHgQWi,yhCbUETeoAPvDOwLFBflSXjuzHgQWJ),}
    yhCbUETeoAPvDOwLFBflSXjuzHgQkr =yhCbUETeoAPvDOwLFBflSXjuzHgQnd
   else:
    yhCbUETeoAPvDOwLFBflSXjuzHgQWM ='MOVIE'
    yhCbUETeoAPvDOwLFBflSXjuzHgQWx={'mediatype':'movie','title':yhCbUETeoAPvDOwLFBflSXjuzHgQkW,'mpaa':yhCbUETeoAPvDOwLFBflSXjuzHgQWt,'genre':yhCbUETeoAPvDOwLFBflSXjuzHgQWp,'duration':yhCbUETeoAPvDOwLFBflSXjuzHgQWG,'year':yhCbUETeoAPvDOwLFBflSXjuzHgQWi,'plot':'(%s)'%(yhCbUETeoAPvDOwLFBflSXjuzHgQWt),}
    yhCbUETeoAPvDOwLFBflSXjuzHgQkr =yhCbUETeoAPvDOwLFBflSXjuzHgQnM
    yhCbUETeoAPvDOwLFBflSXjuzHgQkW +=' (%s)'%(yhCbUETeoAPvDOwLFBflSXjuzHgQRk(yhCbUETeoAPvDOwLFBflSXjuzHgQWi))
   yhCbUETeoAPvDOwLFBflSXjuzHgQkR={'mode':yhCbUETeoAPvDOwLFBflSXjuzHgQWM,'id':yhCbUETeoAPvDOwLFBflSXjuzHgQRW,'asis':yhCbUETeoAPvDOwLFBflSXjuzHgQWn,'seasonList':yhCbUETeoAPvDOwLFBflSXjuzHgQWJ,'title':yhCbUETeoAPvDOwLFBflSXjuzHgQkW,'thumbnail':yhCbUETeoAPvDOwLFBflSXjuzHgQWa,'year':yhCbUETeoAPvDOwLFBflSXjuzHgQWi,}
   if yhCbUETeoAPvDOwLFBflSXjuzHgQxn.get_settings_makebookmark():
    yhCbUETeoAPvDOwLFBflSXjuzHgQWd={'videoid':yhCbUETeoAPvDOwLFBflSXjuzHgQRW,'vidtype':'movie' if yhCbUETeoAPvDOwLFBflSXjuzHgQkm=='MOVIES' else 'tvshow','vtitle':yhCbUETeoAPvDOwLFBflSXjuzHgQkW,'vsubtitle':'',}
    yhCbUETeoAPvDOwLFBflSXjuzHgQWm=json.dumps(yhCbUETeoAPvDOwLFBflSXjuzHgQWd)
    yhCbUETeoAPvDOwLFBflSXjuzHgQWm=urllib.parse.quote(yhCbUETeoAPvDOwLFBflSXjuzHgQWm)
    yhCbUETeoAPvDOwLFBflSXjuzHgQWI='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(yhCbUETeoAPvDOwLFBflSXjuzHgQWm)
    yhCbUETeoAPvDOwLFBflSXjuzHgQWK=[('(통합) 찜 영상에 추가',yhCbUETeoAPvDOwLFBflSXjuzHgQWI)]
   else:
    yhCbUETeoAPvDOwLFBflSXjuzHgQWK=yhCbUETeoAPvDOwLFBflSXjuzHgQnp
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.add_dir(yhCbUETeoAPvDOwLFBflSXjuzHgQkW,sublabel=yhCbUETeoAPvDOwLFBflSXjuzHgQWY,img=yhCbUETeoAPvDOwLFBflSXjuzHgQWa,infoLabels=yhCbUETeoAPvDOwLFBflSXjuzHgQWx,isFolder=yhCbUETeoAPvDOwLFBflSXjuzHgQkr,params=yhCbUETeoAPvDOwLFBflSXjuzHgQkR,ContextMenu=yhCbUETeoAPvDOwLFBflSXjuzHgQWK)
  if yhCbUETeoAPvDOwLFBflSXjuzHgQWV:
   yhCbUETeoAPvDOwLFBflSXjuzHgQkR['mode'] ='CATEGORY_LIST' 
   yhCbUETeoAPvDOwLFBflSXjuzHgQkR['collectionId']=yhCbUETeoAPvDOwLFBflSXjuzHgQWs 
   yhCbUETeoAPvDOwLFBflSXjuzHgQkR['vType'] =yhCbUETeoAPvDOwLFBflSXjuzHgQkm 
   yhCbUETeoAPvDOwLFBflSXjuzHgQkR['page'] =yhCbUETeoAPvDOwLFBflSXjuzHgQRk(yhCbUETeoAPvDOwLFBflSXjuzHgQWN+1)
   yhCbUETeoAPvDOwLFBflSXjuzHgQkW='[B]%s >>[/B]'%'다음 페이지'
   yhCbUETeoAPvDOwLFBflSXjuzHgQWq=yhCbUETeoAPvDOwLFBflSXjuzHgQRk(yhCbUETeoAPvDOwLFBflSXjuzHgQWN+1)
   yhCbUETeoAPvDOwLFBflSXjuzHgQkn=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.add_dir(yhCbUETeoAPvDOwLFBflSXjuzHgQkW,sublabel=yhCbUETeoAPvDOwLFBflSXjuzHgQWq,img=yhCbUETeoAPvDOwLFBflSXjuzHgQkn,infoLabels=yhCbUETeoAPvDOwLFBflSXjuzHgQnp,isFolder=yhCbUETeoAPvDOwLFBflSXjuzHgQnd,params=yhCbUETeoAPvDOwLFBflSXjuzHgQkR)
  if yhCbUETeoAPvDOwLFBflSXjuzHgQkm=='TVSHOWS':xbmcplugin.setContent(yhCbUETeoAPvDOwLFBflSXjuzHgQxn._addon_handle,'tvshows')
  else:xbmcplugin.setContent(yhCbUETeoAPvDOwLFBflSXjuzHgQxn._addon_handle,'movies')
  xbmcplugin.endOfDirectory(yhCbUETeoAPvDOwLFBflSXjuzHgQxn._addon_handle,cacheToDisc=yhCbUETeoAPvDOwLFBflSXjuzHgQnM)
 def dp_Season_List(yhCbUETeoAPvDOwLFBflSXjuzHgQxn,args):
  yhCbUETeoAPvDOwLFBflSXjuzHgQsx =args.get('title')
  yhCbUETeoAPvDOwLFBflSXjuzHgQsk =args.get('id')
  yhCbUETeoAPvDOwLFBflSXjuzHgQWn =args.get('asis')
  yhCbUETeoAPvDOwLFBflSXjuzHgQWJ =args.get('seasonList')
  yhCbUETeoAPvDOwLFBflSXjuzHgQWa =args.get('thumbnail')
  yhCbUETeoAPvDOwLFBflSXjuzHgQWi =args.get('year')
  if yhCbUETeoAPvDOwLFBflSXjuzHgQWJ in['',yhCbUETeoAPvDOwLFBflSXjuzHgQnp]:
   yhCbUETeoAPvDOwLFBflSXjuzHgQWJ=yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.Get_vInfo(yhCbUETeoAPvDOwLFBflSXjuzHgQsk).get('seasonList')
  if yhCbUETeoAPvDOwLFBflSXjuzHgQRs(yhCbUETeoAPvDOwLFBflSXjuzHgQWJ.split(','))>1:
   for yhCbUETeoAPvDOwLFBflSXjuzHgQsW in yhCbUETeoAPvDOwLFBflSXjuzHgQWJ.split(','):
    yhCbUETeoAPvDOwLFBflSXjuzHgQkW='시즌 '+yhCbUETeoAPvDOwLFBflSXjuzHgQsW
    yhCbUETeoAPvDOwLFBflSXjuzHgQWx={'mediatype':'tvshow','plot':'%s (%s)'%(yhCbUETeoAPvDOwLFBflSXjuzHgQsx,yhCbUETeoAPvDOwLFBflSXjuzHgQWi),}
    yhCbUETeoAPvDOwLFBflSXjuzHgQkR={'mode':'EPISODE_LIST','programid':yhCbUETeoAPvDOwLFBflSXjuzHgQsk,'programnm':yhCbUETeoAPvDOwLFBflSXjuzHgQsx,'season':yhCbUETeoAPvDOwLFBflSXjuzHgQsW,'asis':yhCbUETeoAPvDOwLFBflSXjuzHgQWn,'programimg':yhCbUETeoAPvDOwLFBflSXjuzHgQWa,}
    yhCbUETeoAPvDOwLFBflSXjuzHgQsa=yhCbUETeoAPvDOwLFBflSXjuzHgQWa.replace('\'','\"')
    yhCbUETeoAPvDOwLFBflSXjuzHgQsa=json.loads(yhCbUETeoAPvDOwLFBflSXjuzHgQsa)
    yhCbUETeoAPvDOwLFBflSXjuzHgQxn.add_dir(yhCbUETeoAPvDOwLFBflSXjuzHgQkW,sublabel='',img=yhCbUETeoAPvDOwLFBflSXjuzHgQsa,infoLabels=yhCbUETeoAPvDOwLFBflSXjuzHgQWx,isFolder=yhCbUETeoAPvDOwLFBflSXjuzHgQnd,params=yhCbUETeoAPvDOwLFBflSXjuzHgQkR)
   xbmcplugin.setContent(yhCbUETeoAPvDOwLFBflSXjuzHgQxn._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(yhCbUETeoAPvDOwLFBflSXjuzHgQxn._addon_handle,cacheToDisc=yhCbUETeoAPvDOwLFBflSXjuzHgQnM)
  else:
   yhCbUETeoAPvDOwLFBflSXjuzHgQsn={'programid':yhCbUETeoAPvDOwLFBflSXjuzHgQsk,'programnm':yhCbUETeoAPvDOwLFBflSXjuzHgQsx,'season':yhCbUETeoAPvDOwLFBflSXjuzHgQWJ,'programimg':yhCbUETeoAPvDOwLFBflSXjuzHgQWa,}
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.dp_Episode_List(yhCbUETeoAPvDOwLFBflSXjuzHgQsn)
 def dp_Episode_List(yhCbUETeoAPvDOwLFBflSXjuzHgQxn,args):
  yhCbUETeoAPvDOwLFBflSXjuzHgQsk =args.get('programid')
  yhCbUETeoAPvDOwLFBflSXjuzHgQsx =args.get('programnm')
  yhCbUETeoAPvDOwLFBflSXjuzHgQsR =args.get('season')
  yhCbUETeoAPvDOwLFBflSXjuzHgQsr =args.get('programimg')
  yhCbUETeoAPvDOwLFBflSXjuzHgQsc=yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.Get_Episode_List(yhCbUETeoAPvDOwLFBflSXjuzHgQsk,yhCbUETeoAPvDOwLFBflSXjuzHgQsR)
  for yhCbUETeoAPvDOwLFBflSXjuzHgQsW in yhCbUETeoAPvDOwLFBflSXjuzHgQsc:
   yhCbUETeoAPvDOwLFBflSXjuzHgQsG =yhCbUETeoAPvDOwLFBflSXjuzHgQsW.get('title')
   yhCbUETeoAPvDOwLFBflSXjuzHgQsN =yhCbUETeoAPvDOwLFBflSXjuzHgQsW.get('id')
   yhCbUETeoAPvDOwLFBflSXjuzHgQWn =yhCbUETeoAPvDOwLFBflSXjuzHgQsW.get('asis')
   yhCbUETeoAPvDOwLFBflSXjuzHgQWa =yhCbUETeoAPvDOwLFBflSXjuzHgQsW.get('thumbnail')
   yhCbUETeoAPvDOwLFBflSXjuzHgQWt =yhCbUETeoAPvDOwLFBflSXjuzHgQsW.get('mpaa')
   yhCbUETeoAPvDOwLFBflSXjuzHgQWG =yhCbUETeoAPvDOwLFBflSXjuzHgQsW.get('duration')
   yhCbUETeoAPvDOwLFBflSXjuzHgQWi =yhCbUETeoAPvDOwLFBflSXjuzHgQsW.get('year')
   yhCbUETeoAPvDOwLFBflSXjuzHgQsV =yhCbUETeoAPvDOwLFBflSXjuzHgQsW.get('episode')
   yhCbUETeoAPvDOwLFBflSXjuzHgQWp =yhCbUETeoAPvDOwLFBflSXjuzHgQsW.get('genreList')
   yhCbUETeoAPvDOwLFBflSXjuzHgQst =yhCbUETeoAPvDOwLFBflSXjuzHgQsW.get('desc')
   yhCbUETeoAPvDOwLFBflSXjuzHgQsY ='%sx%s'%(yhCbUETeoAPvDOwLFBflSXjuzHgQsR,yhCbUETeoAPvDOwLFBflSXjuzHgQsV)
   yhCbUETeoAPvDOwLFBflSXjuzHgQkW ='%s. %s'%(yhCbUETeoAPvDOwLFBflSXjuzHgQsY,yhCbUETeoAPvDOwLFBflSXjuzHgQsG)
   yhCbUETeoAPvDOwLFBflSXjuzHgQWx={'mediatype':'tvshow','mpaa':yhCbUETeoAPvDOwLFBflSXjuzHgQWt,'genre':yhCbUETeoAPvDOwLFBflSXjuzHgQWp,'duration':yhCbUETeoAPvDOwLFBflSXjuzHgQWG,'year':yhCbUETeoAPvDOwLFBflSXjuzHgQWi,'plot':'%s (%s)\n\n%s'%(yhCbUETeoAPvDOwLFBflSXjuzHgQsx,yhCbUETeoAPvDOwLFBflSXjuzHgQsY,yhCbUETeoAPvDOwLFBflSXjuzHgQst),}
   yhCbUETeoAPvDOwLFBflSXjuzHgQkR={'mode':'VOD','programid':yhCbUETeoAPvDOwLFBflSXjuzHgQsk,'programnm':yhCbUETeoAPvDOwLFBflSXjuzHgQsx,'title':yhCbUETeoAPvDOwLFBflSXjuzHgQkW,'season':yhCbUETeoAPvDOwLFBflSXjuzHgQsR,'id':yhCbUETeoAPvDOwLFBflSXjuzHgQsN,'asis':yhCbUETeoAPvDOwLFBflSXjuzHgQWn,'thumbnail':yhCbUETeoAPvDOwLFBflSXjuzHgQWa,'programimg':yhCbUETeoAPvDOwLFBflSXjuzHgQsr,}
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.add_dir(yhCbUETeoAPvDOwLFBflSXjuzHgQkW,sublabel='',img=yhCbUETeoAPvDOwLFBflSXjuzHgQWa,infoLabels=yhCbUETeoAPvDOwLFBflSXjuzHgQWx,isFolder=yhCbUETeoAPvDOwLFBflSXjuzHgQnM,params=yhCbUETeoAPvDOwLFBflSXjuzHgQkR)
  xbmcplugin.setContent(yhCbUETeoAPvDOwLFBflSXjuzHgQxn._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(yhCbUETeoAPvDOwLFBflSXjuzHgQxn._addon_handle,cacheToDisc=yhCbUETeoAPvDOwLFBflSXjuzHgQnM)
 def play_VIDEO(yhCbUETeoAPvDOwLFBflSXjuzHgQxn,args):
  yhCbUETeoAPvDOwLFBflSXjuzHgQsi =args.get('id')
  yhCbUETeoAPvDOwLFBflSXjuzHgQWn =args.get('asis')
  if yhCbUETeoAPvDOwLFBflSXjuzHgQWn in['HIGHLIGHT']:
   yhCbUETeoAPvDOwLFBflSXjuzHgQsJ,yhCbUETeoAPvDOwLFBflSXjuzHgQsp=yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.GetEventURL(yhCbUETeoAPvDOwLFBflSXjuzHgQsi,yhCbUETeoAPvDOwLFBflSXjuzHgQWn)
  elif yhCbUETeoAPvDOwLFBflSXjuzHgQWn in['LIVE']:
   yhCbUETeoAPvDOwLFBflSXjuzHgQsJ,yhCbUETeoAPvDOwLFBflSXjuzHgQsp=yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.GetEventURL_Live(yhCbUETeoAPvDOwLFBflSXjuzHgQsi,yhCbUETeoAPvDOwLFBflSXjuzHgQWn)
  else:
   yhCbUETeoAPvDOwLFBflSXjuzHgQsJ,yhCbUETeoAPvDOwLFBflSXjuzHgQsp=yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.GetBroadURL(yhCbUETeoAPvDOwLFBflSXjuzHgQsi)
  yhCbUETeoAPvDOwLFBflSXjuzHgQxn.addon_log('asis, url : %s - %s - %s'%(yhCbUETeoAPvDOwLFBflSXjuzHgQWn,yhCbUETeoAPvDOwLFBflSXjuzHgQsi,yhCbUETeoAPvDOwLFBflSXjuzHgQsJ))
  if yhCbUETeoAPvDOwLFBflSXjuzHgQsJ=='':
   if yhCbUETeoAPvDOwLFBflSXjuzHgQsp=='':
    yhCbUETeoAPvDOwLFBflSXjuzHgQxn.addon_noti(__language__(30907).encode('utf8'))
   else:
    yhCbUETeoAPvDOwLFBflSXjuzHgQxn.addon_noti(yhCbUETeoAPvDOwLFBflSXjuzHgQsp)
   return
  yhCbUETeoAPvDOwLFBflSXjuzHgQsM='PCID=%s;token=%s;member_srl=%s;NEXT_LOCALE=%s;bm_mi=%s;ak_bmsc=%s;bm_sv=%s'%(yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.CP['SESSION']['PCID'],yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.CP['SESSION']['token'],yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.CP['SESSION']['member_srl'],yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.CP['SESSION']['NEXT_LOCALE'],yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.CP['SESSION']['bm_mi'],yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.CP['SESSION']['ak_bmsc'],yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.CP['SESSION']['bm_sv'],)
  yhCbUETeoAPvDOwLFBflSXjuzHgQsd='%s|Cookie=%s'%(yhCbUETeoAPvDOwLFBflSXjuzHgQsJ,yhCbUETeoAPvDOwLFBflSXjuzHgQsM)
  yhCbUETeoAPvDOwLFBflSXjuzHgQsm=xbmcgui.ListItem(path=yhCbUETeoAPvDOwLFBflSXjuzHgQsd)
  if yhCbUETeoAPvDOwLFBflSXjuzHgQsp:
   yhCbUETeoAPvDOwLFBflSXjuzHgQsI =yhCbUETeoAPvDOwLFBflSXjuzHgQsp 
   yhCbUETeoAPvDOwLFBflSXjuzHgQsK ='mpd' 
   yhCbUETeoAPvDOwLFBflSXjuzHgQsq ='com.widevine.alpha'
   yhCbUETeoAPvDOwLFBflSXjuzHgQax =inputstreamhelper.Helper(yhCbUETeoAPvDOwLFBflSXjuzHgQsK,drm='widevine')
   if yhCbUETeoAPvDOwLFBflSXjuzHgQax.check_inputstream():
    yhCbUETeoAPvDOwLFBflSXjuzHgQak,yhCbUETeoAPvDOwLFBflSXjuzHgQaW,yhCbUETeoAPvDOwLFBflSXjuzHgQas=yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.Make_authHeader()
    yhCbUETeoAPvDOwLFBflSXjuzHgQan={'traceparent':yhCbUETeoAPvDOwLFBflSXjuzHgQak,'tracestate':yhCbUETeoAPvDOwLFBflSXjuzHgQaW,'newrelic':yhCbUETeoAPvDOwLFBflSXjuzHgQas,'content-type':'application/octet-stream','User-Agent':yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.USER_AGENT,'Cookie':yhCbUETeoAPvDOwLFBflSXjuzHgQsM,}
    yhCbUETeoAPvDOwLFBflSXjuzHgQaR=yhCbUETeoAPvDOwLFBflSXjuzHgQsI+'|'+urllib.parse.urlencode(yhCbUETeoAPvDOwLFBflSXjuzHgQan)+'|R{SSM}|'
    yhCbUETeoAPvDOwLFBflSXjuzHgQsm.setProperty('inputstream',yhCbUETeoAPvDOwLFBflSXjuzHgQax.inputstream_addon)
    yhCbUETeoAPvDOwLFBflSXjuzHgQsm.setProperty('inputstream.adaptive.manifest_type',yhCbUETeoAPvDOwLFBflSXjuzHgQsK)
    yhCbUETeoAPvDOwLFBflSXjuzHgQsm.setProperty('inputstream.adaptive.license_type',yhCbUETeoAPvDOwLFBflSXjuzHgQsq)
    yhCbUETeoAPvDOwLFBflSXjuzHgQsm.setProperty('inputstream.adaptive.license_key',yhCbUETeoAPvDOwLFBflSXjuzHgQaR)
    yhCbUETeoAPvDOwLFBflSXjuzHgQsm.setProperty('inputstream.adaptive.stream_headers','User-Agent=%s&Cookie=%s'%(yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.USER_AGENT,yhCbUETeoAPvDOwLFBflSXjuzHgQsM))
    yhCbUETeoAPvDOwLFBflSXjuzHgQsm.setMimeType('application/dash+xml')
    yhCbUETeoAPvDOwLFBflSXjuzHgQsm.setContentLookup(yhCbUETeoAPvDOwLFBflSXjuzHgQnM)
  xbmcplugin.setResolvedUrl(yhCbUETeoAPvDOwLFBflSXjuzHgQxn._addon_handle,yhCbUETeoAPvDOwLFBflSXjuzHgQnd,yhCbUETeoAPvDOwLFBflSXjuzHgQsm)
  try:
   if yhCbUETeoAPvDOwLFBflSXjuzHgQWn=='MOVIE':
    yhCbUETeoAPvDOwLFBflSXjuzHgQar='movie'
    yhCbUETeoAPvDOwLFBflSXjuzHgQkR={'code':yhCbUETeoAPvDOwLFBflSXjuzHgQsi,'asis':yhCbUETeoAPvDOwLFBflSXjuzHgQWn,'title':args.get('title'),'img':args.get('thumbnail'),}
    yhCbUETeoAPvDOwLFBflSXjuzHgQxn.Save_Watched_List(yhCbUETeoAPvDOwLFBflSXjuzHgQar,yhCbUETeoAPvDOwLFBflSXjuzHgQkR)
   elif yhCbUETeoAPvDOwLFBflSXjuzHgQWn=='TVSHOW':
    yhCbUETeoAPvDOwLFBflSXjuzHgQar='tvshow'
    yhCbUETeoAPvDOwLFBflSXjuzHgQkR={'code':args.get('programid'),'asis':yhCbUETeoAPvDOwLFBflSXjuzHgQWn,'title':'%s <%s>'%(args.get('title'),args.get('programnm')),'img':args.get('programimg'),}
    yhCbUETeoAPvDOwLFBflSXjuzHgQxn.Save_Watched_List(yhCbUETeoAPvDOwLFBflSXjuzHgQar,yhCbUETeoAPvDOwLFBflSXjuzHgQkR)
  except:
   yhCbUETeoAPvDOwLFBflSXjuzHgQnp
 def dp_Global_Search(yhCbUETeoAPvDOwLFBflSXjuzHgQxn,args):
  yhCbUETeoAPvDOwLFBflSXjuzHgQWM=args.get('mode')
  if yhCbUETeoAPvDOwLFBflSXjuzHgQWM=='TOTAL_SEARCH':
   yhCbUETeoAPvDOwLFBflSXjuzHgQac='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   yhCbUETeoAPvDOwLFBflSXjuzHgQac='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(yhCbUETeoAPvDOwLFBflSXjuzHgQac)
 def dp_Bookmark_Menu(yhCbUETeoAPvDOwLFBflSXjuzHgQxn,args):
  yhCbUETeoAPvDOwLFBflSXjuzHgQac='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(yhCbUETeoAPvDOwLFBflSXjuzHgQac)
 def dp_Search_List(yhCbUETeoAPvDOwLFBflSXjuzHgQxn,args):
  yhCbUETeoAPvDOwLFBflSXjuzHgQWN =yhCbUETeoAPvDOwLFBflSXjuzHgQnK(args.get('page'))
  if 'search_key' in args:
   yhCbUETeoAPvDOwLFBflSXjuzHgQaG=args.get('search_key')
  else:
   yhCbUETeoAPvDOwLFBflSXjuzHgQaG=yhCbUETeoAPvDOwLFBflSXjuzHgQxn.get_keyboard_input(__language__(30908).encode('utf-8'))
   if not yhCbUETeoAPvDOwLFBflSXjuzHgQaG:
    return
  yhCbUETeoAPvDOwLFBflSXjuzHgQaN,yhCbUETeoAPvDOwLFBflSXjuzHgQWV=yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.Get_Search_List(yhCbUETeoAPvDOwLFBflSXjuzHgQaG,yhCbUETeoAPvDOwLFBflSXjuzHgQWN)
  for yhCbUETeoAPvDOwLFBflSXjuzHgQaV in yhCbUETeoAPvDOwLFBflSXjuzHgQaN:
   yhCbUETeoAPvDOwLFBflSXjuzHgQRW =yhCbUETeoAPvDOwLFBflSXjuzHgQaV.get('id')
   yhCbUETeoAPvDOwLFBflSXjuzHgQkW =yhCbUETeoAPvDOwLFBflSXjuzHgQaV.get('title')
   yhCbUETeoAPvDOwLFBflSXjuzHgQWn =yhCbUETeoAPvDOwLFBflSXjuzHgQaV.get('asis')
   yhCbUETeoAPvDOwLFBflSXjuzHgQWa =yhCbUETeoAPvDOwLFBflSXjuzHgQaV.get('thumbnail')
   yhCbUETeoAPvDOwLFBflSXjuzHgQWt =yhCbUETeoAPvDOwLFBflSXjuzHgQaV.get('mpaa')
   yhCbUETeoAPvDOwLFBflSXjuzHgQWi =yhCbUETeoAPvDOwLFBflSXjuzHgQaV.get('year')
   yhCbUETeoAPvDOwLFBflSXjuzHgQWG =yhCbUETeoAPvDOwLFBflSXjuzHgQaV.get('duration')
   yhCbUETeoAPvDOwLFBflSXjuzHgQWY =yhCbUETeoAPvDOwLFBflSXjuzHgQaV.get('badge')
   if yhCbUETeoAPvDOwLFBflSXjuzHgQWn=='TVSHOW': 
    yhCbUETeoAPvDOwLFBflSXjuzHgQWM ='SEASON_LIST'
    yhCbUETeoAPvDOwLFBflSXjuzHgQWx={'mediatype':'tvshow','title':yhCbUETeoAPvDOwLFBflSXjuzHgQkW,'mpaa':yhCbUETeoAPvDOwLFBflSXjuzHgQWt,'year':yhCbUETeoAPvDOwLFBflSXjuzHgQWi,'plot':'Year : %s'%(yhCbUETeoAPvDOwLFBflSXjuzHgQWi),}
    yhCbUETeoAPvDOwLFBflSXjuzHgQkr =yhCbUETeoAPvDOwLFBflSXjuzHgQnd
   elif yhCbUETeoAPvDOwLFBflSXjuzHgQWn=='MOVIE':
    yhCbUETeoAPvDOwLFBflSXjuzHgQWM ='MOVIE'
    yhCbUETeoAPvDOwLFBflSXjuzHgQWx={'mediatype':'movie','title':yhCbUETeoAPvDOwLFBflSXjuzHgQkW,'mpaa':yhCbUETeoAPvDOwLFBflSXjuzHgQWt,'duration':yhCbUETeoAPvDOwLFBflSXjuzHgQWG,'year':yhCbUETeoAPvDOwLFBflSXjuzHgQWi,'plot':'(%s)'%(yhCbUETeoAPvDOwLFBflSXjuzHgQWt),}
    yhCbUETeoAPvDOwLFBflSXjuzHgQkr =yhCbUETeoAPvDOwLFBflSXjuzHgQnM
    yhCbUETeoAPvDOwLFBflSXjuzHgQkW +=' (%s)'%(yhCbUETeoAPvDOwLFBflSXjuzHgQRk(yhCbUETeoAPvDOwLFBflSXjuzHgQWi))
   elif yhCbUETeoAPvDOwLFBflSXjuzHgQWn=='HIGHLIGHT':
    yhCbUETeoAPvDOwLFBflSXjuzHgQWM ='HIGHLIGHT'
    yhCbUETeoAPvDOwLFBflSXjuzHgQWx={'mediatype':'episode','title':yhCbUETeoAPvDOwLFBflSXjuzHgQkW,'duration':yhCbUETeoAPvDOwLFBflSXjuzHgQWG,'plot':yhCbUETeoAPvDOwLFBflSXjuzHgQWM,}
    yhCbUETeoAPvDOwLFBflSXjuzHgQkr =yhCbUETeoAPvDOwLFBflSXjuzHgQnM
   elif yhCbUETeoAPvDOwLFBflSXjuzHgQWn=='LIVE':
    yhCbUETeoAPvDOwLFBflSXjuzHgQWM ='LIVE'
    yhCbUETeoAPvDOwLFBflSXjuzHgQWx={'mediatype':'episode','title':yhCbUETeoAPvDOwLFBflSXjuzHgQkW,'plot':yhCbUETeoAPvDOwLFBflSXjuzHgQWM,}
    yhCbUETeoAPvDOwLFBflSXjuzHgQkr =yhCbUETeoAPvDOwLFBflSXjuzHgQnM
   yhCbUETeoAPvDOwLFBflSXjuzHgQkR={'mode':yhCbUETeoAPvDOwLFBflSXjuzHgQWM,'id':yhCbUETeoAPvDOwLFBflSXjuzHgQRW,'asis':yhCbUETeoAPvDOwLFBflSXjuzHgQWn,'seasonList':'','title':yhCbUETeoAPvDOwLFBflSXjuzHgQkW,'thumbnail':json.dumps(yhCbUETeoAPvDOwLFBflSXjuzHgQWa,separators=(',',':')),'year':yhCbUETeoAPvDOwLFBflSXjuzHgQWi,}
   if yhCbUETeoAPvDOwLFBflSXjuzHgQxn.get_settings_makebookmark()and yhCbUETeoAPvDOwLFBflSXjuzHgQWn not in['HIGHLIGHT','']:
    yhCbUETeoAPvDOwLFBflSXjuzHgQWd={'videoid':yhCbUETeoAPvDOwLFBflSXjuzHgQRW,'vidtype':'movie' if yhCbUETeoAPvDOwLFBflSXjuzHgQWn=='MOVIE' else 'tvshow','vtitle':yhCbUETeoAPvDOwLFBflSXjuzHgQkW,'vsubtitle':'',}
    yhCbUETeoAPvDOwLFBflSXjuzHgQWm=json.dumps(yhCbUETeoAPvDOwLFBflSXjuzHgQWd)
    yhCbUETeoAPvDOwLFBflSXjuzHgQWm=urllib.parse.quote(yhCbUETeoAPvDOwLFBflSXjuzHgQWm)
    yhCbUETeoAPvDOwLFBflSXjuzHgQWI='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(yhCbUETeoAPvDOwLFBflSXjuzHgQWm)
    yhCbUETeoAPvDOwLFBflSXjuzHgQWK=[('(통합) 찜 영상에 추가',yhCbUETeoAPvDOwLFBflSXjuzHgQWI)]
   else:
    yhCbUETeoAPvDOwLFBflSXjuzHgQWK=yhCbUETeoAPvDOwLFBflSXjuzHgQnp
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.add_dir(yhCbUETeoAPvDOwLFBflSXjuzHgQkW,sublabel=yhCbUETeoAPvDOwLFBflSXjuzHgQWY,img=yhCbUETeoAPvDOwLFBflSXjuzHgQWa,infoLabels=yhCbUETeoAPvDOwLFBflSXjuzHgQWx,isFolder=yhCbUETeoAPvDOwLFBflSXjuzHgQkr,params=yhCbUETeoAPvDOwLFBflSXjuzHgQkR,ContextMenu=yhCbUETeoAPvDOwLFBflSXjuzHgQWK)
  if yhCbUETeoAPvDOwLFBflSXjuzHgQWV:
   yhCbUETeoAPvDOwLFBflSXjuzHgQkR={}
   yhCbUETeoAPvDOwLFBflSXjuzHgQkR['mode'] ='LOCAL_SEARCH'
   yhCbUETeoAPvDOwLFBflSXjuzHgQkR['search_key']=yhCbUETeoAPvDOwLFBflSXjuzHgQaG
   yhCbUETeoAPvDOwLFBflSXjuzHgQkR['page'] =yhCbUETeoAPvDOwLFBflSXjuzHgQRk(yhCbUETeoAPvDOwLFBflSXjuzHgQWN+1)
   yhCbUETeoAPvDOwLFBflSXjuzHgQkW='[B]%s >>[/B]'%'다음 페이지'
   yhCbUETeoAPvDOwLFBflSXjuzHgQWq=yhCbUETeoAPvDOwLFBflSXjuzHgQRk(yhCbUETeoAPvDOwLFBflSXjuzHgQWN+1)
   yhCbUETeoAPvDOwLFBflSXjuzHgQkn=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.add_dir(yhCbUETeoAPvDOwLFBflSXjuzHgQkW,sublabel=yhCbUETeoAPvDOwLFBflSXjuzHgQWq,img=yhCbUETeoAPvDOwLFBflSXjuzHgQkn,infoLabels=yhCbUETeoAPvDOwLFBflSXjuzHgQnp,isFolder=yhCbUETeoAPvDOwLFBflSXjuzHgQnd,params=yhCbUETeoAPvDOwLFBflSXjuzHgQkR)
  xbmcplugin.setContent(yhCbUETeoAPvDOwLFBflSXjuzHgQxn._addon_handle,'movies')
  xbmcplugin.endOfDirectory(yhCbUETeoAPvDOwLFBflSXjuzHgQxn._addon_handle,cacheToDisc=yhCbUETeoAPvDOwLFBflSXjuzHgQnd)
  if args.get('historyyn')=='Y':yhCbUETeoAPvDOwLFBflSXjuzHgQxn.Save_Searched_List(yhCbUETeoAPvDOwLFBflSXjuzHgQaG)
 def Load_List_File(yhCbUETeoAPvDOwLFBflSXjuzHgQxn,yhCbUETeoAPvDOwLFBflSXjuzHgQar): 
  try:
   if yhCbUETeoAPvDOwLFBflSXjuzHgQar=='search':
    yhCbUETeoAPvDOwLFBflSXjuzHgQat=yhCbUETeoAPvDOwLFBflSXjuzHgQxa
   elif yhCbUETeoAPvDOwLFBflSXjuzHgQar in['tvshow','movie']:
    yhCbUETeoAPvDOwLFBflSXjuzHgQat=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%yhCbUETeoAPvDOwLFBflSXjuzHgQar))
   else:
    return[]
   fp=yhCbUETeoAPvDOwLFBflSXjuzHgQnq(yhCbUETeoAPvDOwLFBflSXjuzHgQat,'r',-1,'utf-8')
   yhCbUETeoAPvDOwLFBflSXjuzHgQaY=fp.readlines()
   fp.close()
  except:
   yhCbUETeoAPvDOwLFBflSXjuzHgQaY=[]
  return yhCbUETeoAPvDOwLFBflSXjuzHgQaY
 def Save_Watched_List(yhCbUETeoAPvDOwLFBflSXjuzHgQxn,yhCbUETeoAPvDOwLFBflSXjuzHgQar,yhCbUETeoAPvDOwLFBflSXjuzHgQxc):
  try:
   yhCbUETeoAPvDOwLFBflSXjuzHgQai=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%yhCbUETeoAPvDOwLFBflSXjuzHgQar))
   yhCbUETeoAPvDOwLFBflSXjuzHgQaJ=yhCbUETeoAPvDOwLFBflSXjuzHgQxn.Load_List_File(yhCbUETeoAPvDOwLFBflSXjuzHgQar) 
   fp=yhCbUETeoAPvDOwLFBflSXjuzHgQnq(yhCbUETeoAPvDOwLFBflSXjuzHgQai,'w',-1,'utf-8')
   yhCbUETeoAPvDOwLFBflSXjuzHgQap=urllib.parse.urlencode(yhCbUETeoAPvDOwLFBflSXjuzHgQxc)
   yhCbUETeoAPvDOwLFBflSXjuzHgQap=yhCbUETeoAPvDOwLFBflSXjuzHgQap+'\n'
   fp.write(yhCbUETeoAPvDOwLFBflSXjuzHgQap)
   yhCbUETeoAPvDOwLFBflSXjuzHgQaM=0
   for yhCbUETeoAPvDOwLFBflSXjuzHgQad in yhCbUETeoAPvDOwLFBflSXjuzHgQaJ:
    yhCbUETeoAPvDOwLFBflSXjuzHgQam=yhCbUETeoAPvDOwLFBflSXjuzHgQnI(urllib.parse.parse_qsl(yhCbUETeoAPvDOwLFBflSXjuzHgQad))
    yhCbUETeoAPvDOwLFBflSXjuzHgQaI=yhCbUETeoAPvDOwLFBflSXjuzHgQxc.get('code').strip()
    yhCbUETeoAPvDOwLFBflSXjuzHgQaK=yhCbUETeoAPvDOwLFBflSXjuzHgQam.get('code').strip()
    if yhCbUETeoAPvDOwLFBflSXjuzHgQaI!=yhCbUETeoAPvDOwLFBflSXjuzHgQaK:
     fp.write(yhCbUETeoAPvDOwLFBflSXjuzHgQad)
     yhCbUETeoAPvDOwLFBflSXjuzHgQaM+=1
     if yhCbUETeoAPvDOwLFBflSXjuzHgQaM>=50:break
   fp.close()
  except:
   yhCbUETeoAPvDOwLFBflSXjuzHgQnp
 def Save_Searched_List(yhCbUETeoAPvDOwLFBflSXjuzHgQxn,yhCbUETeoAPvDOwLFBflSXjuzHgQaG):
  try:
   yhCbUETeoAPvDOwLFBflSXjuzHgQaG=yhCbUETeoAPvDOwLFBflSXjuzHgQaG.strip()
   yhCbUETeoAPvDOwLFBflSXjuzHgQaJ=yhCbUETeoAPvDOwLFBflSXjuzHgQxn.Load_List_File('search') 
   fp=yhCbUETeoAPvDOwLFBflSXjuzHgQnq(yhCbUETeoAPvDOwLFBflSXjuzHgQxa,'w',-1,'utf-8')
   fp.write(yhCbUETeoAPvDOwLFBflSXjuzHgQaG+'\n')
   yhCbUETeoAPvDOwLFBflSXjuzHgQaM=0
   for yhCbUETeoAPvDOwLFBflSXjuzHgQad in yhCbUETeoAPvDOwLFBflSXjuzHgQaJ:
    yhCbUETeoAPvDOwLFBflSXjuzHgQad=yhCbUETeoAPvDOwLFBflSXjuzHgQad.strip()
    if yhCbUETeoAPvDOwLFBflSXjuzHgQaG!=yhCbUETeoAPvDOwLFBflSXjuzHgQad:
     fp.write(yhCbUETeoAPvDOwLFBflSXjuzHgQad+'\n')
     yhCbUETeoAPvDOwLFBflSXjuzHgQaM+=1
     if yhCbUETeoAPvDOwLFBflSXjuzHgQaM>=50:break
   fp.close()
  except:
   yhCbUETeoAPvDOwLFBflSXjuzHgQnp
 def dp_Search_History(yhCbUETeoAPvDOwLFBflSXjuzHgQxn,args):
  yhCbUETeoAPvDOwLFBflSXjuzHgQaq=yhCbUETeoAPvDOwLFBflSXjuzHgQxn.Load_List_File('search')
  for yhCbUETeoAPvDOwLFBflSXjuzHgQnx in yhCbUETeoAPvDOwLFBflSXjuzHgQaq:
   yhCbUETeoAPvDOwLFBflSXjuzHgQnx=yhCbUETeoAPvDOwLFBflSXjuzHgQnx.strip()
   yhCbUETeoAPvDOwLFBflSXjuzHgQkR={'mode':'LOCAL_SEARCH','search_key':yhCbUETeoAPvDOwLFBflSXjuzHgQnx,'page':'1','historyyn':'Y',}
   yhCbUETeoAPvDOwLFBflSXjuzHgQnk={'mode':'SEARCH_REMOVE','stype':'ONE','skey':yhCbUETeoAPvDOwLFBflSXjuzHgQnx,}
   yhCbUETeoAPvDOwLFBflSXjuzHgQnW=urllib.parse.urlencode(yhCbUETeoAPvDOwLFBflSXjuzHgQnk)
   yhCbUETeoAPvDOwLFBflSXjuzHgQWK=[('선택된 검색어 ( %s ) 삭제'%(yhCbUETeoAPvDOwLFBflSXjuzHgQnx),'RunPlugin(plugin://plugin.video.coupangm/?%s)'%(yhCbUETeoAPvDOwLFBflSXjuzHgQnW))]
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.add_dir(yhCbUETeoAPvDOwLFBflSXjuzHgQnx,sublabel='',img=yhCbUETeoAPvDOwLFBflSXjuzHgQnp,infoLabels=yhCbUETeoAPvDOwLFBflSXjuzHgQnp,isFolder=yhCbUETeoAPvDOwLFBflSXjuzHgQnd,params=yhCbUETeoAPvDOwLFBflSXjuzHgQkR,ContextMenu=yhCbUETeoAPvDOwLFBflSXjuzHgQWK)
  yhCbUETeoAPvDOwLFBflSXjuzHgQWx={'plot':'검색목록 전체를 삭제합니다.'}
  yhCbUETeoAPvDOwLFBflSXjuzHgQkW='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  yhCbUETeoAPvDOwLFBflSXjuzHgQkR={'mode':'SEARCH_REMOVE','stype':'ALL','skey':'-',}
  yhCbUETeoAPvDOwLFBflSXjuzHgQkn=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  yhCbUETeoAPvDOwLFBflSXjuzHgQxn.add_dir(yhCbUETeoAPvDOwLFBflSXjuzHgQkW,sublabel='',img=yhCbUETeoAPvDOwLFBflSXjuzHgQkn,infoLabels=yhCbUETeoAPvDOwLFBflSXjuzHgQWx,isFolder=yhCbUETeoAPvDOwLFBflSXjuzHgQnM,params=yhCbUETeoAPvDOwLFBflSXjuzHgQkR,isLink=yhCbUETeoAPvDOwLFBflSXjuzHgQnd)
  xbmcplugin.endOfDirectory(yhCbUETeoAPvDOwLFBflSXjuzHgQxn._addon_handle,cacheToDisc=yhCbUETeoAPvDOwLFBflSXjuzHgQnM)
 def dp_Listfile_Delete(yhCbUETeoAPvDOwLFBflSXjuzHgQxn,args):
  yhCbUETeoAPvDOwLFBflSXjuzHgQar=args.get('stype')
  yhCbUETeoAPvDOwLFBflSXjuzHgQns =args.get('skey')
  yhCbUETeoAPvDOwLFBflSXjuzHgQxN=xbmcgui.Dialog()
  if yhCbUETeoAPvDOwLFBflSXjuzHgQar=='ALL':
   yhCbUETeoAPvDOwLFBflSXjuzHgQkN=yhCbUETeoAPvDOwLFBflSXjuzHgQxN.yesno(__language__(30911).encode('utf8'),__language__(30906).encode('utf8'))
  elif yhCbUETeoAPvDOwLFBflSXjuzHgQar=='ONE':
   yhCbUETeoAPvDOwLFBflSXjuzHgQkN=yhCbUETeoAPvDOwLFBflSXjuzHgQxN.yesno(__language__(30912).encode('utf8'),__language__(30906).encode('utf8'))
  elif yhCbUETeoAPvDOwLFBflSXjuzHgQar in['tvshow','movie']:
   yhCbUETeoAPvDOwLFBflSXjuzHgQkN=yhCbUETeoAPvDOwLFBflSXjuzHgQxN.yesno(__language__(30913).encode('utf8'),__language__(30906).encode('utf8'))
  if yhCbUETeoAPvDOwLFBflSXjuzHgQkN==yhCbUETeoAPvDOwLFBflSXjuzHgQnM:sys.exit()
  yhCbUETeoAPvDOwLFBflSXjuzHgQxn.Delete_List_File(yhCbUETeoAPvDOwLFBflSXjuzHgQar,skey=yhCbUETeoAPvDOwLFBflSXjuzHgQns)
  xbmc.executebuiltin("Container.Refresh")
 def Delete_List_File(yhCbUETeoAPvDOwLFBflSXjuzHgQxn,yhCbUETeoAPvDOwLFBflSXjuzHgQar,skey='-'):
  if yhCbUETeoAPvDOwLFBflSXjuzHgQar=='ALL':
   try:
    yhCbUETeoAPvDOwLFBflSXjuzHgQat=yhCbUETeoAPvDOwLFBflSXjuzHgQxa
    fp=yhCbUETeoAPvDOwLFBflSXjuzHgQnq(yhCbUETeoAPvDOwLFBflSXjuzHgQat,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    yhCbUETeoAPvDOwLFBflSXjuzHgQnp
  elif yhCbUETeoAPvDOwLFBflSXjuzHgQar=='ONE':
   try:
    yhCbUETeoAPvDOwLFBflSXjuzHgQat=yhCbUETeoAPvDOwLFBflSXjuzHgQxa
    yhCbUETeoAPvDOwLFBflSXjuzHgQaJ=yhCbUETeoAPvDOwLFBflSXjuzHgQxn.Load_List_File('search') 
    fp=yhCbUETeoAPvDOwLFBflSXjuzHgQnq(yhCbUETeoAPvDOwLFBflSXjuzHgQat,'w',-1,'utf-8')
    for yhCbUETeoAPvDOwLFBflSXjuzHgQad in yhCbUETeoAPvDOwLFBflSXjuzHgQaJ:
     if skey!=yhCbUETeoAPvDOwLFBflSXjuzHgQad.strip():
      fp.write(yhCbUETeoAPvDOwLFBflSXjuzHgQad)
    fp.close()
   except:
    yhCbUETeoAPvDOwLFBflSXjuzHgQnp
  elif yhCbUETeoAPvDOwLFBflSXjuzHgQar in['tvshow','movie']:
   try:
    yhCbUETeoAPvDOwLFBflSXjuzHgQat=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%yhCbUETeoAPvDOwLFBflSXjuzHgQar))
    fp=yhCbUETeoAPvDOwLFBflSXjuzHgQnq(yhCbUETeoAPvDOwLFBflSXjuzHgQat,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    yhCbUETeoAPvDOwLFBflSXjuzHgQnp
 def dp_Watch_List(yhCbUETeoAPvDOwLFBflSXjuzHgQxn,args):
  yhCbUETeoAPvDOwLFBflSXjuzHgQar =args.get('stype')
  if yhCbUETeoAPvDOwLFBflSXjuzHgQar in['',yhCbUETeoAPvDOwLFBflSXjuzHgQnp]:
   for yhCbUETeoAPvDOwLFBflSXjuzHgQna in yhCbUETeoAPvDOwLFBflSXjuzHgQxs:
    yhCbUETeoAPvDOwLFBflSXjuzHgQkW=yhCbUETeoAPvDOwLFBflSXjuzHgQna.get('title')
    yhCbUETeoAPvDOwLFBflSXjuzHgQkR={'mode':yhCbUETeoAPvDOwLFBflSXjuzHgQna.get('mode'),'stype':yhCbUETeoAPvDOwLFBflSXjuzHgQna.get('stype'),}
    yhCbUETeoAPvDOwLFBflSXjuzHgQxn.add_dir(yhCbUETeoAPvDOwLFBflSXjuzHgQkW,sublabel='',img='',infoLabels=yhCbUETeoAPvDOwLFBflSXjuzHgQnp,isFolder=yhCbUETeoAPvDOwLFBflSXjuzHgQnd,params=yhCbUETeoAPvDOwLFBflSXjuzHgQkR)
   xbmcplugin.endOfDirectory(yhCbUETeoAPvDOwLFBflSXjuzHgQxn._addon_handle)
  else:
   yhCbUETeoAPvDOwLFBflSXjuzHgQnR=yhCbUETeoAPvDOwLFBflSXjuzHgQxn.Load_List_File(yhCbUETeoAPvDOwLFBflSXjuzHgQar)
   for yhCbUETeoAPvDOwLFBflSXjuzHgQnr in yhCbUETeoAPvDOwLFBflSXjuzHgQnR:
    yhCbUETeoAPvDOwLFBflSXjuzHgQnc=yhCbUETeoAPvDOwLFBflSXjuzHgQnI(urllib.parse.parse_qsl(yhCbUETeoAPvDOwLFBflSXjuzHgQnr))
    yhCbUETeoAPvDOwLFBflSXjuzHgQsi =yhCbUETeoAPvDOwLFBflSXjuzHgQnc.get('code').strip()
    yhCbUETeoAPvDOwLFBflSXjuzHgQkW =yhCbUETeoAPvDOwLFBflSXjuzHgQnc.get('title').strip()
    yhCbUETeoAPvDOwLFBflSXjuzHgQWa =yhCbUETeoAPvDOwLFBflSXjuzHgQnc.get('img').strip()
    yhCbUETeoAPvDOwLFBflSXjuzHgQWn =yhCbUETeoAPvDOwLFBflSXjuzHgQnc.get('asis').strip()
    try:
     yhCbUETeoAPvDOwLFBflSXjuzHgQWa=yhCbUETeoAPvDOwLFBflSXjuzHgQWa.replace('\'','\"')
     yhCbUETeoAPvDOwLFBflSXjuzHgQWa=json.loads(yhCbUETeoAPvDOwLFBflSXjuzHgQWa)
    except:
     yhCbUETeoAPvDOwLFBflSXjuzHgQnp
    yhCbUETeoAPvDOwLFBflSXjuzHgQWx={}
    yhCbUETeoAPvDOwLFBflSXjuzHgQWx['plot']=yhCbUETeoAPvDOwLFBflSXjuzHgQkW
    if yhCbUETeoAPvDOwLFBflSXjuzHgQar=='movie':
     yhCbUETeoAPvDOwLFBflSXjuzHgQkR={'mode':'MOVIE','id':yhCbUETeoAPvDOwLFBflSXjuzHgQsi,'asis':yhCbUETeoAPvDOwLFBflSXjuzHgQWn,'title':yhCbUETeoAPvDOwLFBflSXjuzHgQkW,'thumbnail':yhCbUETeoAPvDOwLFBflSXjuzHgQWa,}
     yhCbUETeoAPvDOwLFBflSXjuzHgQkr=yhCbUETeoAPvDOwLFBflSXjuzHgQnM
    else:
     yhCbUETeoAPvDOwLFBflSXjuzHgQkR={'mode':'SEASON_LIST','id':yhCbUETeoAPvDOwLFBflSXjuzHgQsi,'asis':yhCbUETeoAPvDOwLFBflSXjuzHgQWn,'title':yhCbUETeoAPvDOwLFBflSXjuzHgQkW,'thumbnail':json.dumps(yhCbUETeoAPvDOwLFBflSXjuzHgQWa,separators=(',',':')),}
     yhCbUETeoAPvDOwLFBflSXjuzHgQkr=yhCbUETeoAPvDOwLFBflSXjuzHgQnd
    yhCbUETeoAPvDOwLFBflSXjuzHgQxn.add_dir(yhCbUETeoAPvDOwLFBflSXjuzHgQkW,sublabel='',img=yhCbUETeoAPvDOwLFBflSXjuzHgQWa,infoLabels=yhCbUETeoAPvDOwLFBflSXjuzHgQWx,isFolder=yhCbUETeoAPvDOwLFBflSXjuzHgQkr,params=yhCbUETeoAPvDOwLFBflSXjuzHgQkR)
   yhCbUETeoAPvDOwLFBflSXjuzHgQWx={'plot':'시청목록을 삭제합니다.'}
   yhCbUETeoAPvDOwLFBflSXjuzHgQkW='*** 시청목록 삭제 ***'
   yhCbUETeoAPvDOwLFBflSXjuzHgQkR={'mode':'MYVIEW_REMOVE','stype':yhCbUETeoAPvDOwLFBflSXjuzHgQar,'skey':'-',}
   yhCbUETeoAPvDOwLFBflSXjuzHgQkn=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.add_dir(yhCbUETeoAPvDOwLFBflSXjuzHgQkW,sublabel='',img=yhCbUETeoAPvDOwLFBflSXjuzHgQkn,infoLabels=yhCbUETeoAPvDOwLFBflSXjuzHgQWx,isFolder=yhCbUETeoAPvDOwLFBflSXjuzHgQnM,params=yhCbUETeoAPvDOwLFBflSXjuzHgQkR,isLink=yhCbUETeoAPvDOwLFBflSXjuzHgQnd)
   if yhCbUETeoAPvDOwLFBflSXjuzHgQar=='movie':xbmcplugin.setContent(yhCbUETeoAPvDOwLFBflSXjuzHgQxn._addon_handle,'movies')
   else:xbmcplugin.setContent(yhCbUETeoAPvDOwLFBflSXjuzHgQxn._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(yhCbUETeoAPvDOwLFBflSXjuzHgQxn._addon_handle,cacheToDisc=yhCbUETeoAPvDOwLFBflSXjuzHgQnM)
 def dp_Set_Bookmark(yhCbUETeoAPvDOwLFBflSXjuzHgQxn,args):
  yhCbUETeoAPvDOwLFBflSXjuzHgQnG=urllib.parse.unquote(args.get('bm_param'))
  yhCbUETeoAPvDOwLFBflSXjuzHgQnG=json.loads(yhCbUETeoAPvDOwLFBflSXjuzHgQnG)
  yhCbUETeoAPvDOwLFBflSXjuzHgQnN =yhCbUETeoAPvDOwLFBflSXjuzHgQnG.get('videoid')
  yhCbUETeoAPvDOwLFBflSXjuzHgQnV =yhCbUETeoAPvDOwLFBflSXjuzHgQnG.get('vidtype')
  yhCbUETeoAPvDOwLFBflSXjuzHgQnt =yhCbUETeoAPvDOwLFBflSXjuzHgQnG.get('vtitle')
  yhCbUETeoAPvDOwLFBflSXjuzHgQxN=xbmcgui.Dialog()
  yhCbUETeoAPvDOwLFBflSXjuzHgQkN=yhCbUETeoAPvDOwLFBflSXjuzHgQxN.yesno(__language__(30914).encode('utf8'),yhCbUETeoAPvDOwLFBflSXjuzHgQnt+' \n\n'+__language__(30915))
  if yhCbUETeoAPvDOwLFBflSXjuzHgQkN==yhCbUETeoAPvDOwLFBflSXjuzHgQnM:return
  yhCbUETeoAPvDOwLFBflSXjuzHgQnY=yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CoupangObj.GetBookmarkInfo(yhCbUETeoAPvDOwLFBflSXjuzHgQnN,yhCbUETeoAPvDOwLFBflSXjuzHgQnV)
  yhCbUETeoAPvDOwLFBflSXjuzHgQni=json.dumps(yhCbUETeoAPvDOwLFBflSXjuzHgQnY)
  yhCbUETeoAPvDOwLFBflSXjuzHgQni=urllib.parse.quote(yhCbUETeoAPvDOwLFBflSXjuzHgQni)
  yhCbUETeoAPvDOwLFBflSXjuzHgQWI ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(yhCbUETeoAPvDOwLFBflSXjuzHgQni)
  xbmc.executebuiltin(yhCbUETeoAPvDOwLFBflSXjuzHgQWI)
 def coupang_main(yhCbUETeoAPvDOwLFBflSXjuzHgQxn):
  yhCbUETeoAPvDOwLFBflSXjuzHgQWM=yhCbUETeoAPvDOwLFBflSXjuzHgQxn.main_params.get('mode',yhCbUETeoAPvDOwLFBflSXjuzHgQnp)
  if yhCbUETeoAPvDOwLFBflSXjuzHgQWM=='LOGOUT':
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.CP_logout()
   return
  yhCbUETeoAPvDOwLFBflSXjuzHgQxn.option_check()
  if yhCbUETeoAPvDOwLFBflSXjuzHgQWM is yhCbUETeoAPvDOwLFBflSXjuzHgQnp:
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.dp_Main_List(yhCbUETeoAPvDOwLFBflSXjuzHgQxn.main_params)
  elif yhCbUETeoAPvDOwLFBflSXjuzHgQWM=='CATEGORY_GROUPLIST':
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.dp_Category_GroupList(yhCbUETeoAPvDOwLFBflSXjuzHgQxn.main_params)
  elif yhCbUETeoAPvDOwLFBflSXjuzHgQWM=='THEME_GROUPLIST':
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.dp_Theme_GroupList(yhCbUETeoAPvDOwLFBflSXjuzHgQxn.main_params)
  elif yhCbUETeoAPvDOwLFBflSXjuzHgQWM=='EVENT_GROUPLIST':
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.dp_Event_GroupList(yhCbUETeoAPvDOwLFBflSXjuzHgQxn.main_params)
  elif yhCbUETeoAPvDOwLFBflSXjuzHgQWM=='EVENT_GAMELIST':
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.dp_Event_GameList(yhCbUETeoAPvDOwLFBflSXjuzHgQxn.main_params)
  elif yhCbUETeoAPvDOwLFBflSXjuzHgQWM=='EVENT_LIST':
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.dp_Event_List(yhCbUETeoAPvDOwLFBflSXjuzHgQxn.main_params)
  elif yhCbUETeoAPvDOwLFBflSXjuzHgQWM=='CATEGORY_LIST':
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.dp_Category_List(yhCbUETeoAPvDOwLFBflSXjuzHgQxn.main_params)
  elif yhCbUETeoAPvDOwLFBflSXjuzHgQWM=='SEASON_LIST':
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.dp_Season_List(yhCbUETeoAPvDOwLFBflSXjuzHgQxn.main_params)
  elif yhCbUETeoAPvDOwLFBflSXjuzHgQWM=='EPISODE_LIST':
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.dp_Episode_List(yhCbUETeoAPvDOwLFBflSXjuzHgQxn.main_params)
  elif yhCbUETeoAPvDOwLFBflSXjuzHgQWM=='TEST':
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.dp_Test(yhCbUETeoAPvDOwLFBflSXjuzHgQxn.main_params)
  elif yhCbUETeoAPvDOwLFBflSXjuzHgQWM in['MOVIE','VOD','HIGHLIGHT','LIVE']:
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.play_VIDEO(yhCbUETeoAPvDOwLFBflSXjuzHgQxn.main_params)
  elif yhCbUETeoAPvDOwLFBflSXjuzHgQWM=='WATCH':
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.dp_Watch_List(yhCbUETeoAPvDOwLFBflSXjuzHgQxn.main_params)
  elif yhCbUETeoAPvDOwLFBflSXjuzHgQWM=='LOCAL_SEARCH':
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.dp_Search_List(yhCbUETeoAPvDOwLFBflSXjuzHgQxn.main_params)
  elif yhCbUETeoAPvDOwLFBflSXjuzHgQWM=='SEARCH_HISTORY':
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.dp_Search_History(yhCbUETeoAPvDOwLFBflSXjuzHgQxn.main_params)
  elif yhCbUETeoAPvDOwLFBflSXjuzHgQWM in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.dp_Listfile_Delete(yhCbUETeoAPvDOwLFBflSXjuzHgQxn.main_params)
  elif yhCbUETeoAPvDOwLFBflSXjuzHgQWM in['TOTAL_SEARCH','TOTAL_HISTORY']:
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.dp_Global_Search(yhCbUETeoAPvDOwLFBflSXjuzHgQxn.main_params)
  elif yhCbUETeoAPvDOwLFBflSXjuzHgQWM=='MENU_BOOKMARK':
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.dp_Bookmark_Menu(yhCbUETeoAPvDOwLFBflSXjuzHgQxn.main_params)
  elif yhCbUETeoAPvDOwLFBflSXjuzHgQWM=='SET_BOOKMARK':
   yhCbUETeoAPvDOwLFBflSXjuzHgQxn.dp_Set_Bookmark(yhCbUETeoAPvDOwLFBflSXjuzHgQxn.main_params)
  else:
   yhCbUETeoAPvDOwLFBflSXjuzHgQnp
# Created by pyminifier (https://github.com/liftoff/pyminifier)
