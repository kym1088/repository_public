__author__="NightRain"
NtyUuvFErsfhPRgqKVJTHQIlXACMLo=object
NtyUuvFErsfhPRgqKVJTHQIlXACMLc=None
NtyUuvFErsfhPRgqKVJTHQIlXACMLk=False
NtyUuvFErsfhPRgqKVJTHQIlXACMLa=print
NtyUuvFErsfhPRgqKVJTHQIlXACMLO=str
NtyUuvFErsfhPRgqKVJTHQIlXACMLi=open
NtyUuvFErsfhPRgqKVJTHQIlXACMLe=int
NtyUuvFErsfhPRgqKVJTHQIlXACMLb=Exception
NtyUuvFErsfhPRgqKVJTHQIlXACMLz=id
NtyUuvFErsfhPRgqKVJTHQIlXACMLm=True
NtyUuvFErsfhPRgqKVJTHQIlXACMLG=range
NtyUuvFErsfhPRgqKVJTHQIlXACMLW=len
import urllib
import re
import json
import requests
import datetime
import time
import random
import base64
class NtyUuvFErsfhPRgqKVJTHQIlXACMnd(NtyUuvFErsfhPRgqKVJTHQIlXACMLo):
 def __init__(NtyUuvFErsfhPRgqKVJTHQIlXACMnD):
  NtyUuvFErsfhPRgqKVJTHQIlXACMnD.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.82 Safari/537.36'
  NtyUuvFErsfhPRgqKVJTHQIlXACMnD.MODEL ='Chrome_98' 
  NtyUuvFErsfhPRgqKVJTHQIlXACMnD.DEFAULT_HEADER ={'user-agent':NtyUuvFErsfhPRgqKVJTHQIlXACMnD.USER_AGENT}
  NtyUuvFErsfhPRgqKVJTHQIlXACMnD.API_DOMAIN ='https://www.coupangplay.com'
  NtyUuvFErsfhPRgqKVJTHQIlXACMnD.API_VIEWURL ='https://discover.coupangstreaming.com'
  NtyUuvFErsfhPRgqKVJTHQIlXACMnD.PAGE_LIMIT =40
  NtyUuvFErsfhPRgqKVJTHQIlXACMnD.SEARCH_LIMIT =20
  NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP={}
  NtyUuvFErsfhPRgqKVJTHQIlXACMnD.Init_CP()
  NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP_DEVICE_FILENAME=''
  NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP_COOKIE_FILENAME=''
 def callRequestCookies(NtyUuvFErsfhPRgqKVJTHQIlXACMnD,jobtype,NtyUuvFErsfhPRgqKVJTHQIlXACMdL,payload=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,params=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,headers=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,cookies=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,redirects=NtyUuvFErsfhPRgqKVJTHQIlXACMLk):
  NtyUuvFErsfhPRgqKVJTHQIlXACMnL=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.DEFAULT_HEADER
  if headers:NtyUuvFErsfhPRgqKVJTHQIlXACMnL.update(headers)
  if jobtype=='Get':
   NtyUuvFErsfhPRgqKVJTHQIlXACMnY=requests.get(NtyUuvFErsfhPRgqKVJTHQIlXACMdL,params=params,headers=NtyUuvFErsfhPRgqKVJTHQIlXACMnL,cookies=cookies,allow_redirects=redirects)
  else:
   NtyUuvFErsfhPRgqKVJTHQIlXACMnY=requests.post(NtyUuvFErsfhPRgqKVJTHQIlXACMdL,data=payload,params=params,headers=NtyUuvFErsfhPRgqKVJTHQIlXACMnL,cookies=cookies,allow_redirects=redirects)
  NtyUuvFErsfhPRgqKVJTHQIlXACMLa(NtyUuvFErsfhPRgqKVJTHQIlXACMLO(NtyUuvFErsfhPRgqKVJTHQIlXACMnY.status_code)+' - '+NtyUuvFErsfhPRgqKVJTHQIlXACMLO(NtyUuvFErsfhPRgqKVJTHQIlXACMnY.url))
  return NtyUuvFErsfhPRgqKVJTHQIlXACMnY
 def callRequestCookies_test(NtyUuvFErsfhPRgqKVJTHQIlXACMnD,jobtype,NtyUuvFErsfhPRgqKVJTHQIlXACMdL,payload=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,params=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,headers=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,cookies=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,redirects=NtyUuvFErsfhPRgqKVJTHQIlXACMLk):
  NtyUuvFErsfhPRgqKVJTHQIlXACMnL=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.DEFAULT_HEADER
  if headers:NtyUuvFErsfhPRgqKVJTHQIlXACMnL.update(headers)
  NtyUuvFErsfhPRgqKVJTHQIlXACMnY=requests.Request('POST',NtyUuvFErsfhPRgqKVJTHQIlXACMdL,headers=headers,data=payload,params=params,cookies=cookies)
  NtyUuvFErsfhPRgqKVJTHQIlXACMnw=NtyUuvFErsfhPRgqKVJTHQIlXACMnY.prepare()
  NtyUuvFErsfhPRgqKVJTHQIlXACMnD.pretty_print_POST(NtyUuvFErsfhPRgqKVJTHQIlXACMnw)
  return NtyUuvFErsfhPRgqKVJTHQIlXACMnY
 def pretty_print_POST(NtyUuvFErsfhPRgqKVJTHQIlXACMnD,req):
  NtyUuvFErsfhPRgqKVJTHQIlXACMLa('{}\n{}\r\n{}\r\n\r\n{}'.format('-----------START-----------',req.method+' '+req.url,'\r\n'.join('{}: {}'.format(k,v)for k,v in req.headers.items()),req.body,))
 def dic_To_jsonfile(NtyUuvFErsfhPRgqKVJTHQIlXACMnD,filename,NtyUuvFErsfhPRgqKVJTHQIlXACMnS):
  if filename=='':return
  fp=NtyUuvFErsfhPRgqKVJTHQIlXACMLi(filename,'w',-1,'utf-8')
  json.dump(NtyUuvFErsfhPRgqKVJTHQIlXACMnS,fp,indent=4,ensure_ascii=NtyUuvFErsfhPRgqKVJTHQIlXACMLk)
  fp.close()
 def jsonfile_To_dic(NtyUuvFErsfhPRgqKVJTHQIlXACMnD,filename):
  if filename=='':return NtyUuvFErsfhPRgqKVJTHQIlXACMLc
  try:
   fp=NtyUuvFErsfhPRgqKVJTHQIlXACMLi(filename,'r',-1,'utf-8')
   NtyUuvFErsfhPRgqKVJTHQIlXACMnc=json.load(fp)
   fp.close()
  except:
   NtyUuvFErsfhPRgqKVJTHQIlXACMnc={}
  return NtyUuvFErsfhPRgqKVJTHQIlXACMnc
 def convert_TimeStr(NtyUuvFErsfhPRgqKVJTHQIlXACMnD,NtyUuvFErsfhPRgqKVJTHQIlXACMnk):
  try:
   NtyUuvFErsfhPRgqKVJTHQIlXACMnk =NtyUuvFErsfhPRgqKVJTHQIlXACMnk[0:16]
   NtyUuvFErsfhPRgqKVJTHQIlXACMna=datetime.datetime.strptime(NtyUuvFErsfhPRgqKVJTHQIlXACMnk,'%Y-%m-%dT%H:%M')+datetime.timedelta(hours=9)
   return NtyUuvFErsfhPRgqKVJTHQIlXACMna.strftime('%Y-%m-%d %H:%M')
  except:
   return NtyUuvFErsfhPRgqKVJTHQIlXACMLc
 def Get_Now_Datetime(NtyUuvFErsfhPRgqKVJTHQIlXACMnD):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetNoCache(NtyUuvFErsfhPRgqKVJTHQIlXACMnD):
  NtyUuvFErsfhPRgqKVJTHQIlXACMni =NtyUuvFErsfhPRgqKVJTHQIlXACMLe(time.time()*1000)
  return NtyUuvFErsfhPRgqKVJTHQIlXACMni
 def generatePcId(NtyUuvFErsfhPRgqKVJTHQIlXACMnD):
  t=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.GetNoCache()
  r=random.random()
  NtyUuvFErsfhPRgqKVJTHQIlXACMne=NtyUuvFErsfhPRgqKVJTHQIlXACMLO(t)+NtyUuvFErsfhPRgqKVJTHQIlXACMLO(r)[2:12]
  return NtyUuvFErsfhPRgqKVJTHQIlXACMne
 def generatePvId(NtyUuvFErsfhPRgqKVJTHQIlXACMnD,genType='1'):
  import hashlib
  m=hashlib.md5()
  NtyUuvFErsfhPRgqKVJTHQIlXACMnb=NtyUuvFErsfhPRgqKVJTHQIlXACMLO(random.random())
  m.update(NtyUuvFErsfhPRgqKVJTHQIlXACMnb.encode('utf-8'))
  NtyUuvFErsfhPRgqKVJTHQIlXACMnz=NtyUuvFErsfhPRgqKVJTHQIlXACMLO(m.hexdigest())
  if genType=='1':
   return '%s-%s-%s-%s-%s'%(NtyUuvFErsfhPRgqKVJTHQIlXACMnz[:8],NtyUuvFErsfhPRgqKVJTHQIlXACMnz[8:12],NtyUuvFErsfhPRgqKVJTHQIlXACMnz[12:16],NtyUuvFErsfhPRgqKVJTHQIlXACMnz[16:20],NtyUuvFErsfhPRgqKVJTHQIlXACMnz[20:])
  else:
   return NtyUuvFErsfhPRgqKVJTHQIlXACMnz
 def Get_DeviceID(NtyUuvFErsfhPRgqKVJTHQIlXACMnD):
  NtyUuvFErsfhPRgqKVJTHQIlXACMnm=''
  try: 
   fp=NtyUuvFErsfhPRgqKVJTHQIlXACMLi(NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP_DEVICE_FILENAME,'r',-1,'utf-8')
   NtyUuvFErsfhPRgqKVJTHQIlXACMnG= json.load(fp)
   fp.close()
   NtyUuvFErsfhPRgqKVJTHQIlXACMnm=NtyUuvFErsfhPRgqKVJTHQIlXACMnG.get('device_id')
  except NtyUuvFErsfhPRgqKVJTHQIlXACMLb as exception:
   NtyUuvFErsfhPRgqKVJTHQIlXACMLc
  if NtyUuvFErsfhPRgqKVJTHQIlXACMnm=='':
   NtyUuvFErsfhPRgqKVJTHQIlXACMnm=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.generatePvId(genType='1')
   try: 
    fp=NtyUuvFErsfhPRgqKVJTHQIlXACMLi(NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP_DEVICE_FILENAME,'w',-1,'utf-8')
    json.dump({'device_id':NtyUuvFErsfhPRgqKVJTHQIlXACMnm},fp,indent=4,ensure_ascii=NtyUuvFErsfhPRgqKVJTHQIlXACMLk)
    fp.close()
   except NtyUuvFErsfhPRgqKVJTHQIlXACMLb as exception:
    return ''
  return NtyUuvFErsfhPRgqKVJTHQIlXACMnm
 def Make_authHeader(NtyUuvFErsfhPRgqKVJTHQIlXACMnD):
  tr=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.generatePvId(genType=2)
  ti=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.GetNoCache()
  NtyUuvFErsfhPRgqKVJTHQIlXACMLz=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.generatePvId(genType=2)[:16]
  NtyUuvFErsfhPRgqKVJTHQIlXACMnW='00-%s-%s-01'%(tr,NtyUuvFErsfhPRgqKVJTHQIlXACMLz,)
  NtyUuvFErsfhPRgqKVJTHQIlXACMnj ='%s@nr=0-1-%s-%s-%s----%s'%(NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['NREUM']['tk'],NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['NREUM']['ac'],NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['NREUM']['ap'],NtyUuvFErsfhPRgqKVJTHQIlXACMLz,ti,)
  NtyUuvFErsfhPRgqKVJTHQIlXACMnx ='{"v":[0,1],"d":{"ty":"Browser","ac":"%s","ap":"%s","id":"%s","tr":"%s","ti":%s,"tk":"%s"}}'%(NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['NREUM']['ac'],NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['NREUM']['ap'],NtyUuvFErsfhPRgqKVJTHQIlXACMLz,tr,ti,NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['NREUM']['tk'],) 
  return NtyUuvFErsfhPRgqKVJTHQIlXACMnW,NtyUuvFErsfhPRgqKVJTHQIlXACMnj,base64.standard_b64encode(NtyUuvFErsfhPRgqKVJTHQIlXACMnx.encode()).decode('utf-8')
 def Init_CP(NtyUuvFErsfhPRgqKVJTHQIlXACMnD):
  NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP={}
  NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['ACCOUNT']={'cpid':'','cppw':'','cppf':'0'}
  NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']={}
 def Save_session_acount(NtyUuvFErsfhPRgqKVJTHQIlXACMnD,NtyUuvFErsfhPRgqKVJTHQIlXACMnB,NtyUuvFErsfhPRgqKVJTHQIlXACMnp,NtyUuvFErsfhPRgqKVJTHQIlXACMdn):
  NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['ACCOUNT']['cpid']=base64.standard_b64encode(NtyUuvFErsfhPRgqKVJTHQIlXACMnB.encode()).decode('utf-8')
  NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['ACCOUNT']['cppw']=base64.standard_b64encode(NtyUuvFErsfhPRgqKVJTHQIlXACMnp.encode()).decode('utf-8')
  NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['ACCOUNT']['cppf']=NtyUuvFErsfhPRgqKVJTHQIlXACMLO(NtyUuvFErsfhPRgqKVJTHQIlXACMdn)
 def Load_session_acount(NtyUuvFErsfhPRgqKVJTHQIlXACMnD):
  NtyUuvFErsfhPRgqKVJTHQIlXACMnB=base64.standard_b64decode(NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['ACCOUNT']['cpid']).decode('utf-8')
  NtyUuvFErsfhPRgqKVJTHQIlXACMnp=base64.standard_b64decode(NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['ACCOUNT']['cppw']).decode('utf-8')
  NtyUuvFErsfhPRgqKVJTHQIlXACMdn=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['ACCOUNT']['cppf']
  return NtyUuvFErsfhPRgqKVJTHQIlXACMnB,NtyUuvFErsfhPRgqKVJTHQIlXACMnp,NtyUuvFErsfhPRgqKVJTHQIlXACMdn
 def make_CP_DefaultCookies(NtyUuvFErsfhPRgqKVJTHQIlXACMnD):
  NtyUuvFErsfhPRgqKVJTHQIlXACMdD={}
  if 'NEXT_LOCALE' in NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']:NtyUuvFErsfhPRgqKVJTHQIlXACMdD['NEXT_LOCALE']=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['NEXT_LOCALE']
  if 'ak_bmsc' in NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']:NtyUuvFErsfhPRgqKVJTHQIlXACMdD['ak_bmsc'] =NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['ak_bmsc']
  if 'bm_mi' in NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']:NtyUuvFErsfhPRgqKVJTHQIlXACMdD['bm_mi'] =NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['bm_mi']
  if 'bm_sv' in NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']:NtyUuvFErsfhPRgqKVJTHQIlXACMdD['bm_sv'] =NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['bm_sv']
  if 'PCID' in NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']:NtyUuvFErsfhPRgqKVJTHQIlXACMdD['PCID'] =NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['PCID']
  if 'member_srl' in NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']:NtyUuvFErsfhPRgqKVJTHQIlXACMdD['member_srl']=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['member_srl']
  if 'token' in NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']:NtyUuvFErsfhPRgqKVJTHQIlXACMdD['token'] =NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['token']
  return NtyUuvFErsfhPRgqKVJTHQIlXACMdD
 def Get_CP_Login(NtyUuvFErsfhPRgqKVJTHQIlXACMnD,userid,userpw,NtyUuvFErsfhPRgqKVJTHQIlXACMde):
  try:
   NtyUuvFErsfhPRgqKVJTHQIlXACMdL=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.API_DOMAIN
   NtyUuvFErsfhPRgqKVJTHQIlXACMdY=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.callRequestCookies('Get',NtyUuvFErsfhPRgqKVJTHQIlXACMdL,payload=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,params=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,headers=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,cookies=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,redirects=NtyUuvFErsfhPRgqKVJTHQIlXACMLk)
   if NtyUuvFErsfhPRgqKVJTHQIlXACMdY.status_code not in[301,302]:return NtyUuvFErsfhPRgqKVJTHQIlXACMLk
   for NtyUuvFErsfhPRgqKVJTHQIlXACMdw in NtyUuvFErsfhPRgqKVJTHQIlXACMdY.cookies:
    if NtyUuvFErsfhPRgqKVJTHQIlXACMdw.name=='NEXT_LOCALE':
     NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['NEXT_LOCALE']=NtyUuvFErsfhPRgqKVJTHQIlXACMdw.value
    elif NtyUuvFErsfhPRgqKVJTHQIlXACMdw.name=='ak_bmsc':
     NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['ak_bmsc']=NtyUuvFErsfhPRgqKVJTHQIlXACMdw.value
   NtyUuvFErsfhPRgqKVJTHQIlXACMdD={'NEXT_LOCALE':NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['NEXT_LOCALE'],'ak_bmsc':NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['ak_bmsc'],}
   NtyUuvFErsfhPRgqKVJTHQIlXACMdY=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.callRequestCookies('Get',NtyUuvFErsfhPRgqKVJTHQIlXACMdL,payload=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,params=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,headers=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,cookies=NtyUuvFErsfhPRgqKVJTHQIlXACMdD,redirects=NtyUuvFErsfhPRgqKVJTHQIlXACMLk)
   if NtyUuvFErsfhPRgqKVJTHQIlXACMdY.status_code not in[200]:return NtyUuvFErsfhPRgqKVJTHQIlXACMLk
   NtyUuvFErsfhPRgqKVJTHQIlXACMdS=re.findall('NREUM.loader_config=\{[\w\d\":,-]+\}',NtyUuvFErsfhPRgqKVJTHQIlXACMdY.text)[0].split('=')[1]
   NtyUuvFErsfhPRgqKVJTHQIlXACMdS=NtyUuvFErsfhPRgqKVJTHQIlXACMdS.replace('{','{"').replace(':','":').replace(',',',"')
   NtyUuvFErsfhPRgqKVJTHQIlXACMdS=json.loads(NtyUuvFErsfhPRgqKVJTHQIlXACMdS)
   NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['NREUM']={'ac':NtyUuvFErsfhPRgqKVJTHQIlXACMdS['accountID'],'tk':NtyUuvFErsfhPRgqKVJTHQIlXACMdS['trustKey'],'ap':NtyUuvFErsfhPRgqKVJTHQIlXACMdS['agentID'],'lk':NtyUuvFErsfhPRgqKVJTHQIlXACMdS['licenseKey'],}
   for NtyUuvFErsfhPRgqKVJTHQIlXACMdw in NtyUuvFErsfhPRgqKVJTHQIlXACMdY.cookies:
    if NtyUuvFErsfhPRgqKVJTHQIlXACMdw.name=='bm_mi':
     NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['bm_mi']=NtyUuvFErsfhPRgqKVJTHQIlXACMdw.value
    elif NtyUuvFErsfhPRgqKVJTHQIlXACMdw.name=='bm_sv':
     NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['bm_sv'] =NtyUuvFErsfhPRgqKVJTHQIlXACMdw.value
     NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['bm_sv_ex']=NtyUuvFErsfhPRgqKVJTHQIlXACMdw.expires 
  except NtyUuvFErsfhPRgqKVJTHQIlXACMLb as exception:
   NtyUuvFErsfhPRgqKVJTHQIlXACMLa(exception)
   return NtyUuvFErsfhPRgqKVJTHQIlXACMLk
  try:
   NtyUuvFErsfhPRgqKVJTHQIlXACMdL=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.API_DOMAIN+'/api/auth'
   NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['PCID']=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.generatePcId()
   NtyUuvFErsfhPRgqKVJTHQIlXACMdo=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.Get_DeviceID()
   NtyUuvFErsfhPRgqKVJTHQIlXACMdc =NtyUuvFErsfhPRgqKVJTHQIlXACMdo.split('-')[0]
   NtyUuvFErsfhPRgqKVJTHQIlXACMnW,NtyUuvFErsfhPRgqKVJTHQIlXACMnj,NtyUuvFErsfhPRgqKVJTHQIlXACMnx=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.Make_authHeader()
   NtyUuvFErsfhPRgqKVJTHQIlXACMdk={'traceparent':NtyUuvFErsfhPRgqKVJTHQIlXACMnW,'tracestate':NtyUuvFErsfhPRgqKVJTHQIlXACMnj,'newrelic':NtyUuvFErsfhPRgqKVJTHQIlXACMnx,'content-type':'application/json',}
   NtyUuvFErsfhPRgqKVJTHQIlXACMda={'device':{'deviceId':'web-'+NtyUuvFErsfhPRgqKVJTHQIlXACMdo,'model':NtyUuvFErsfhPRgqKVJTHQIlXACMnD.MODEL,'name':'Chrome Desktop '+NtyUuvFErsfhPRgqKVJTHQIlXACMdc,'os':'Windows','osVersion':'10','type':'webclient',},'email':userid,'password':userpw,}
   NtyUuvFErsfhPRgqKVJTHQIlXACMda=json.dumps(NtyUuvFErsfhPRgqKVJTHQIlXACMda,separators=(',',':'))
   NtyUuvFErsfhPRgqKVJTHQIlXACMdD={'NEXT_LOCALE':NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['NEXT_LOCALE'],'ak_bmsc':NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['ak_bmsc'],'bm_mi':NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['bm_mi'],'bm_sv':NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['bm_sv'],'PCID':NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['PCID'],}
   NtyUuvFErsfhPRgqKVJTHQIlXACMdY=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.callRequestCookies('Post',NtyUuvFErsfhPRgqKVJTHQIlXACMdL,payload=NtyUuvFErsfhPRgqKVJTHQIlXACMda,params=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,headers=NtyUuvFErsfhPRgqKVJTHQIlXACMdk,cookies=NtyUuvFErsfhPRgqKVJTHQIlXACMdD,redirects=NtyUuvFErsfhPRgqKVJTHQIlXACMLk)
   if NtyUuvFErsfhPRgqKVJTHQIlXACMdY.status_code not in[200]:
    NtyUuvFErsfhPRgqKVJTHQIlXACMdO=json.loads(NtyUuvFErsfhPRgqKVJTHQIlXACMdY.text)
    if 'error' in NtyUuvFErsfhPRgqKVJTHQIlXACMdO:
     NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['error']=NtyUuvFErsfhPRgqKVJTHQIlXACMdO.get('error').get('detail')
    return NtyUuvFErsfhPRgqKVJTHQIlXACMLk
   for NtyUuvFErsfhPRgqKVJTHQIlXACMdw in NtyUuvFErsfhPRgqKVJTHQIlXACMdY.cookies:
    if NtyUuvFErsfhPRgqKVJTHQIlXACMdw.name=='token':
     NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['token']=NtyUuvFErsfhPRgqKVJTHQIlXACMdw.value
    elif NtyUuvFErsfhPRgqKVJTHQIlXACMdw.name=='member_srl':
     NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['member_srl']=NtyUuvFErsfhPRgqKVJTHQIlXACMdw.value
    elif NtyUuvFErsfhPRgqKVJTHQIlXACMdw.name=='bm_sv':
     NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['bm_sv'] =NtyUuvFErsfhPRgqKVJTHQIlXACMdw.value
     NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['bm_sv_ex']=NtyUuvFErsfhPRgqKVJTHQIlXACMdw.expires 
  except NtyUuvFErsfhPRgqKVJTHQIlXACMLb as exception:
   NtyUuvFErsfhPRgqKVJTHQIlXACMLa(exception)
   return NtyUuvFErsfhPRgqKVJTHQIlXACMLk
  NtyUuvFErsfhPRgqKVJTHQIlXACMnD.Save_session_acount(userid,userpw,NtyUuvFErsfhPRgqKVJTHQIlXACMde)
  return NtyUuvFErsfhPRgqKVJTHQIlXACMLm
 def Get_CP_profile(NtyUuvFErsfhPRgqKVJTHQIlXACMnD,NtyUuvFErsfhPRgqKVJTHQIlXACMde,limit_days=1,re_check=NtyUuvFErsfhPRgqKVJTHQIlXACMLk):
  if re_check==NtyUuvFErsfhPRgqKVJTHQIlXACMLm:
   if NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['bm_sv_ex']>NtyUuvFErsfhPRgqKVJTHQIlXACMLe(time.time()):
    NtyUuvFErsfhPRgqKVJTHQIlXACMLa('bm_sv_ex ok')
    return NtyUuvFErsfhPRgqKVJTHQIlXACMLm
  try:
   NtyUuvFErsfhPRgqKVJTHQIlXACMdL=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.API_DOMAIN+'/api/profiles'
   NtyUuvFErsfhPRgqKVJTHQIlXACMnW,NtyUuvFErsfhPRgqKVJTHQIlXACMnj,NtyUuvFErsfhPRgqKVJTHQIlXACMnx=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.Make_authHeader()
   NtyUuvFErsfhPRgqKVJTHQIlXACMdk={'traceparent':NtyUuvFErsfhPRgqKVJTHQIlXACMnW,'tracestate':NtyUuvFErsfhPRgqKVJTHQIlXACMnj,'newrelic':NtyUuvFErsfhPRgqKVJTHQIlXACMnx,}
   NtyUuvFErsfhPRgqKVJTHQIlXACMdD=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.make_CP_DefaultCookies()
   NtyUuvFErsfhPRgqKVJTHQIlXACMdY=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.callRequestCookies('Get',NtyUuvFErsfhPRgqKVJTHQIlXACMdL,payload=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,params=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,headers=NtyUuvFErsfhPRgqKVJTHQIlXACMdk,cookies=NtyUuvFErsfhPRgqKVJTHQIlXACMdD,redirects=NtyUuvFErsfhPRgqKVJTHQIlXACMLk)
   if NtyUuvFErsfhPRgqKVJTHQIlXACMdY.status_code not in[200]:return NtyUuvFErsfhPRgqKVJTHQIlXACMLk
   NtyUuvFErsfhPRgqKVJTHQIlXACMdO=json.loads(NtyUuvFErsfhPRgqKVJTHQIlXACMdY.text)
   NtyUuvFErsfhPRgqKVJTHQIlXACMdi=0 
   for NtyUuvFErsfhPRgqKVJTHQIlXACMdw in NtyUuvFErsfhPRgqKVJTHQIlXACMdY.cookies:
    NtyUuvFErsfhPRgqKVJTHQIlXACMLa(NtyUuvFErsfhPRgqKVJTHQIlXACMdw.name)
    if NtyUuvFErsfhPRgqKVJTHQIlXACMdw.name=='bm_sv':
     NtyUuvFErsfhPRgqKVJTHQIlXACMdi=1
     NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['bm_sv'] =NtyUuvFErsfhPRgqKVJTHQIlXACMdw.value
     NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['bm_sv_ex']=NtyUuvFErsfhPRgqKVJTHQIlXACMdw.expires 
   if NtyUuvFErsfhPRgqKVJTHQIlXACMdi==0:
    NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['bm_sv_ex']=NtyUuvFErsfhPRgqKVJTHQIlXACMLe(time.time())+60*60*2 
   NtyUuvFErsfhPRgqKVJTHQIlXACMde=NtyUuvFErsfhPRgqKVJTHQIlXACMdO.get('data')[NtyUuvFErsfhPRgqKVJTHQIlXACMLe(NtyUuvFErsfhPRgqKVJTHQIlXACMde)]
   NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['accountId']=NtyUuvFErsfhPRgqKVJTHQIlXACMde.get('accountId')
   NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['profileId']=NtyUuvFErsfhPRgqKVJTHQIlXACMde.get('profileId')
  except NtyUuvFErsfhPRgqKVJTHQIlXACMLb as exception:
   NtyUuvFErsfhPRgqKVJTHQIlXACMLa(exception)
   return NtyUuvFErsfhPRgqKVJTHQIlXACMLk
  if re_check==NtyUuvFErsfhPRgqKVJTHQIlXACMLk:
   NtyUuvFErsfhPRgqKVJTHQIlXACMdb =NtyUuvFErsfhPRgqKVJTHQIlXACMnD.Get_Now_Datetime()
   NtyUuvFErsfhPRgqKVJTHQIlXACMdz=NtyUuvFErsfhPRgqKVJTHQIlXACMdb+datetime.timedelta(days=limit_days)
   NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['limitdate']=NtyUuvFErsfhPRgqKVJTHQIlXACMdz.strftime('%Y-%m-%d')
  else:
   NtyUuvFErsfhPRgqKVJTHQIlXACMLa('re check')
  NtyUuvFErsfhPRgqKVJTHQIlXACMnD.dic_To_jsonfile(NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP_COOKIE_FILENAME,NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP)
  return NtyUuvFErsfhPRgqKVJTHQIlXACMLm
 def Get_Category_GroupList(NtyUuvFErsfhPRgqKVJTHQIlXACMnD,vType):
  NtyUuvFErsfhPRgqKVJTHQIlXACMdm=[] 
  try:
   NtyUuvFErsfhPRgqKVJTHQIlXACMdL=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.API_VIEWURL+'/v2/discover/feed' 
   NtyUuvFErsfhPRgqKVJTHQIlXACMdG={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false',}
   NtyUuvFErsfhPRgqKVJTHQIlXACMdY=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.callRequestCookies('Get',NtyUuvFErsfhPRgqKVJTHQIlXACMdL,payload=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,params=NtyUuvFErsfhPRgqKVJTHQIlXACMdG,headers=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,cookies=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,redirects=NtyUuvFErsfhPRgqKVJTHQIlXACMLm)
   if NtyUuvFErsfhPRgqKVJTHQIlXACMdY.status_code not in[200]:return[]
   NtyUuvFErsfhPRgqKVJTHQIlXACMdO=json.loads(NtyUuvFErsfhPRgqKVJTHQIlXACMdY.text)
   if vType in['TVSHOWS','MOVIES']:
    NtyUuvFErsfhPRgqKVJTHQIlXACMdW='Explores' 
   elif vType in['EDUCATION']:
    NtyUuvFErsfhPRgqKVJTHQIlXACMdW='Collection-Rails-Curation'
   elif vType in['ALL']:
    NtyUuvFErsfhPRgqKVJTHQIlXACMdW='Explores-Categories'
   for NtyUuvFErsfhPRgqKVJTHQIlXACMdj in NtyUuvFErsfhPRgqKVJTHQIlXACMdO.get('data'):
    if NtyUuvFErsfhPRgqKVJTHQIlXACMdj.get('type')==NtyUuvFErsfhPRgqKVJTHQIlXACMdW:
     for NtyUuvFErsfhPRgqKVJTHQIlXACMdx in NtyUuvFErsfhPRgqKVJTHQIlXACMdj.get('data'):
      if vType in['TVSHOWS','MOVIES']:
       NtyUuvFErsfhPRgqKVJTHQIlXACMdB=NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('collectionId')
      elif vType in['EDUCATION','ALL']:
       NtyUuvFErsfhPRgqKVJTHQIlXACMdB=NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('id')
      NtyUuvFErsfhPRgqKVJTHQIlXACMdp={'collectionId':NtyUuvFErsfhPRgqKVJTHQIlXACMdB,'title':NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('name'),'category':NtyUuvFErsfhPRgqKVJTHQIlXACMdj.get('category'),'pre_title':'',}
      NtyUuvFErsfhPRgqKVJTHQIlXACMdm.append(NtyUuvFErsfhPRgqKVJTHQIlXACMdp)
     break
  except NtyUuvFErsfhPRgqKVJTHQIlXACMLb as exception:
   NtyUuvFErsfhPRgqKVJTHQIlXACMLa(exception)
   return[]
  return NtyUuvFErsfhPRgqKVJTHQIlXACMdm
 def Get_Category_List(NtyUuvFErsfhPRgqKVJTHQIlXACMnD,vType,NtyUuvFErsfhPRgqKVJTHQIlXACMdB,page_int):
  NtyUuvFErsfhPRgqKVJTHQIlXACMdm=[] 
  NtyUuvFErsfhPRgqKVJTHQIlXACMDn=NtyUuvFErsfhPRgqKVJTHQIlXACMLk
  try:
   if vType=='ALL':
    NtyUuvFErsfhPRgqKVJTHQIlXACMdk={'x-membersrl':NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['member_srl'],'x-pcid':NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['PCID'],'x-profileid':NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['profileId'],}
    NtyUuvFErsfhPRgqKVJTHQIlXACMdG={'platform':'WEBCLIENT','page':NtyUuvFErsfhPRgqKVJTHQIlXACMLO(page_int),'perPage':NtyUuvFErsfhPRgqKVJTHQIlXACMLO(NtyUuvFErsfhPRgqKVJTHQIlXACMnD.PAGE_LIMIT),'locale':'ko','sort':'',}
    NtyUuvFErsfhPRgqKVJTHQIlXACMdL=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.API_VIEWURL+'/v1/discover/categories/'+NtyUuvFErsfhPRgqKVJTHQIlXACMdB+'/titles'
    NtyUuvFErsfhPRgqKVJTHQIlXACMdY=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.callRequestCookies('Get',NtyUuvFErsfhPRgqKVJTHQIlXACMdL,payload=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,params=NtyUuvFErsfhPRgqKVJTHQIlXACMdG,headers=NtyUuvFErsfhPRgqKVJTHQIlXACMdk,cookies=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,redirects=NtyUuvFErsfhPRgqKVJTHQIlXACMLm)
   else: 
    NtyUuvFErsfhPRgqKVJTHQIlXACMdG={'platform':'WEBCLIENT','page':NtyUuvFErsfhPRgqKVJTHQIlXACMLO(page_int),'perPage':NtyUuvFErsfhPRgqKVJTHQIlXACMLO(NtyUuvFErsfhPRgqKVJTHQIlXACMnD.PAGE_LIMIT),}
    NtyUuvFErsfhPRgqKVJTHQIlXACMdL=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.API_VIEWURL+'/v1/discover/collections/'+NtyUuvFErsfhPRgqKVJTHQIlXACMdB+'/titles'
    NtyUuvFErsfhPRgqKVJTHQIlXACMdY=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.callRequestCookies('Get',NtyUuvFErsfhPRgqKVJTHQIlXACMdL,payload=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,params=NtyUuvFErsfhPRgqKVJTHQIlXACMdG,headers=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,cookies=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,redirects=NtyUuvFErsfhPRgqKVJTHQIlXACMLm)
   if NtyUuvFErsfhPRgqKVJTHQIlXACMdY.status_code not in[200]:return[],NtyUuvFErsfhPRgqKVJTHQIlXACMLk
   NtyUuvFErsfhPRgqKVJTHQIlXACMdO=json.loads(NtyUuvFErsfhPRgqKVJTHQIlXACMdY.text)
   if vType=='ALL':
    NtyUuvFErsfhPRgqKVJTHQIlXACMDd=NtyUuvFErsfhPRgqKVJTHQIlXACMdO.get('data').get('data')
   else:
    NtyUuvFErsfhPRgqKVJTHQIlXACMDd=NtyUuvFErsfhPRgqKVJTHQIlXACMdO.get('data')
   for NtyUuvFErsfhPRgqKVJTHQIlXACMdx in NtyUuvFErsfhPRgqKVJTHQIlXACMDd:
    NtyUuvFErsfhPRgqKVJTHQIlXACMDL=NtyUuvFErsfhPRgqKVJTHQIlXACMDc=NtyUuvFErsfhPRgqKVJTHQIlXACMLD=NtyUuvFErsfhPRgqKVJTHQIlXACMLd=''
    if 'poster' in NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('images'):NtyUuvFErsfhPRgqKVJTHQIlXACMDL =NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('images').get('poster').get('url')
    if 'story-art' in NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('images'):NtyUuvFErsfhPRgqKVJTHQIlXACMDc =NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('images').get('story-art').get('url')
    if 'title-treatment' in NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('images'):NtyUuvFErsfhPRgqKVJTHQIlXACMLD=NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('images').get('title-treatment').get('url')
    if 'story-art' in NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('images'):NtyUuvFErsfhPRgqKVJTHQIlXACMLd =NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('images').get('story-art').get('url')
    NtyUuvFErsfhPRgqKVJTHQIlXACMDY=''
    if NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('badge')not in[{},NtyUuvFErsfhPRgqKVJTHQIlXACMLc]:
     for i in NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('badge').get('text'):
      NtyUuvFErsfhPRgqKVJTHQIlXACMDY+=i.get('text')
    NtyUuvFErsfhPRgqKVJTHQIlXACMDw=''
    if NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('seasonList')!=NtyUuvFErsfhPRgqKVJTHQIlXACMLc:
     NtyUuvFErsfhPRgqKVJTHQIlXACMDw=','.join(NtyUuvFErsfhPRgqKVJTHQIlXACMLO(e)for e in NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('seasonList'))
    NtyUuvFErsfhPRgqKVJTHQIlXACMDS =[]
    for NtyUuvFErsfhPRgqKVJTHQIlXACMDo in NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('tags'):
     NtyUuvFErsfhPRgqKVJTHQIlXACMDS.append(NtyUuvFErsfhPRgqKVJTHQIlXACMDo.get('tag'))
    NtyUuvFErsfhPRgqKVJTHQIlXACMdp={'id':NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('id'),'title':NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('title'),'thumbnail':{'poster':NtyUuvFErsfhPRgqKVJTHQIlXACMDL,'thumb':NtyUuvFErsfhPRgqKVJTHQIlXACMDc,'clearlogo':NtyUuvFErsfhPRgqKVJTHQIlXACMLD,'fanart':NtyUuvFErsfhPRgqKVJTHQIlXACMLd},'mpaa':NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('age_rating'),'duration':NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('running_time'),'asis':NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('as'),'badge':NtyUuvFErsfhPRgqKVJTHQIlXACMDY,'year':NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('meta').get('releaseYear'),'seasonList':NtyUuvFErsfhPRgqKVJTHQIlXACMDw,'genreList':NtyUuvFErsfhPRgqKVJTHQIlXACMDS,}
    NtyUuvFErsfhPRgqKVJTHQIlXACMdm.append(NtyUuvFErsfhPRgqKVJTHQIlXACMdp)
   if NtyUuvFErsfhPRgqKVJTHQIlXACMdO.get('pagination').get('totalPages')>page_int:
    NtyUuvFErsfhPRgqKVJTHQIlXACMDn=NtyUuvFErsfhPRgqKVJTHQIlXACMLm
  except NtyUuvFErsfhPRgqKVJTHQIlXACMLb as exception:
   NtyUuvFErsfhPRgqKVJTHQIlXACMLa(exception)
   return[],NtyUuvFErsfhPRgqKVJTHQIlXACMLk
  return NtyUuvFErsfhPRgqKVJTHQIlXACMdm,NtyUuvFErsfhPRgqKVJTHQIlXACMDn
 def Get_Episode_List(NtyUuvFErsfhPRgqKVJTHQIlXACMnD,programId,season):
  NtyUuvFErsfhPRgqKVJTHQIlXACMdm=[] 
  try:
   NtyUuvFErsfhPRgqKVJTHQIlXACMdL=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.API_VIEWURL+'/v1/discover/titles/'+programId+'/episodes'
   NtyUuvFErsfhPRgqKVJTHQIlXACMdG={'season':season,'sort':'true','locale':'ko',}
   NtyUuvFErsfhPRgqKVJTHQIlXACMdY=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.callRequestCookies('Get',NtyUuvFErsfhPRgqKVJTHQIlXACMdL,payload=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,params=NtyUuvFErsfhPRgqKVJTHQIlXACMdG,headers=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,cookies=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,redirects=NtyUuvFErsfhPRgqKVJTHQIlXACMLm)
   if NtyUuvFErsfhPRgqKVJTHQIlXACMdY.status_code not in[200]:return[]
   NtyUuvFErsfhPRgqKVJTHQIlXACMdO=json.loads(NtyUuvFErsfhPRgqKVJTHQIlXACMdY.text)
   for NtyUuvFErsfhPRgqKVJTHQIlXACMdx in NtyUuvFErsfhPRgqKVJTHQIlXACMdO.get('data'):
    NtyUuvFErsfhPRgqKVJTHQIlXACMDc=''
    if 'story-art' in NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('images'):NtyUuvFErsfhPRgqKVJTHQIlXACMDc =NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('images').get('story-art').get('url')
    NtyUuvFErsfhPRgqKVJTHQIlXACMDS =[]
    for NtyUuvFErsfhPRgqKVJTHQIlXACMDo in NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('tags'):
     NtyUuvFErsfhPRgqKVJTHQIlXACMDS.append(NtyUuvFErsfhPRgqKVJTHQIlXACMDo.get('tag'))
    NtyUuvFErsfhPRgqKVJTHQIlXACMdp={'id':NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('id'),'title':NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('title'),'thumbnail':{'thumb':NtyUuvFErsfhPRgqKVJTHQIlXACMDc,'fanart':NtyUuvFErsfhPRgqKVJTHQIlXACMDc},'mpaa':NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('age_rating'),'duration':NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('running_time'),'asis':NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('as'),'year':NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('meta').get('releaseYear'),'episode':NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('episode'),'genreList':NtyUuvFErsfhPRgqKVJTHQIlXACMDS,'desc':NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('description'),}
    NtyUuvFErsfhPRgqKVJTHQIlXACMdm.append(NtyUuvFErsfhPRgqKVJTHQIlXACMdp)
  except NtyUuvFErsfhPRgqKVJTHQIlXACMLb as exception:
   NtyUuvFErsfhPRgqKVJTHQIlXACMLa(exception)
   return[]
  return NtyUuvFErsfhPRgqKVJTHQIlXACMdm
 def Get_vInfo(NtyUuvFErsfhPRgqKVJTHQIlXACMnD,titleId):
  try:
   NtyUuvFErsfhPRgqKVJTHQIlXACMdL=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.API_VIEWURL+'/v1/discover/titles/'+titleId 
   NtyUuvFErsfhPRgqKVJTHQIlXACMdG={'locale':'ko'}
   NtyUuvFErsfhPRgqKVJTHQIlXACMdY=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.callRequestCookies('Get',NtyUuvFErsfhPRgqKVJTHQIlXACMdL,payload=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,params=NtyUuvFErsfhPRgqKVJTHQIlXACMdG,headers=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,cookies=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,redirects=NtyUuvFErsfhPRgqKVJTHQIlXACMLm)
   if NtyUuvFErsfhPRgqKVJTHQIlXACMdY.status_code not in[200]:return '','',''
   NtyUuvFErsfhPRgqKVJTHQIlXACMdO=json.loads(NtyUuvFErsfhPRgqKVJTHQIlXACMdY.text).get('data')
   NtyUuvFErsfhPRgqKVJTHQIlXACMDw=''
   if NtyUuvFErsfhPRgqKVJTHQIlXACMdO.get('seasonList')!=NtyUuvFErsfhPRgqKVJTHQIlXACMLc:
    NtyUuvFErsfhPRgqKVJTHQIlXACMDw=','.join(NtyUuvFErsfhPRgqKVJTHQIlXACMLO(e)for e in NtyUuvFErsfhPRgqKVJTHQIlXACMdO.get('seasonList'))
   NtyUuvFErsfhPRgqKVJTHQIlXACMDk={'age_rating':NtyUuvFErsfhPRgqKVJTHQIlXACMdO.get('age_rating'),'asset_id':NtyUuvFErsfhPRgqKVJTHQIlXACMdO.get('asset_id'),'availability':NtyUuvFErsfhPRgqKVJTHQIlXACMdO.get('availability'),'deal_id':NtyUuvFErsfhPRgqKVJTHQIlXACMdO.get('deal_id'),'downloadable':'true' if NtyUuvFErsfhPRgqKVJTHQIlXACMdO.get('downloadable')else 'false','region':NtyUuvFErsfhPRgqKVJTHQIlXACMdO.get('region'),'streamable':'true' if NtyUuvFErsfhPRgqKVJTHQIlXACMdO.get('streamable')else 'false','asis':NtyUuvFErsfhPRgqKVJTHQIlXACMdO.get('as'),'seasonList':NtyUuvFErsfhPRgqKVJTHQIlXACMDw}
  except NtyUuvFErsfhPRgqKVJTHQIlXACMLb as exception:
   NtyUuvFErsfhPRgqKVJTHQIlXACMLa(exception)
   return{}
  return NtyUuvFErsfhPRgqKVJTHQIlXACMDk
 def Get_eInfo(NtyUuvFErsfhPRgqKVJTHQIlXACMnD,eventId):
  try:
   NtyUuvFErsfhPRgqKVJTHQIlXACMdL=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.API_VIEWURL+'/v1/discover/events/'+eventId 
   NtyUuvFErsfhPRgqKVJTHQIlXACMdG={'locale':'ko'}
   NtyUuvFErsfhPRgqKVJTHQIlXACMdY=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.callRequestCookies('Get',NtyUuvFErsfhPRgqKVJTHQIlXACMdL,payload=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,params=NtyUuvFErsfhPRgqKVJTHQIlXACMdG,headers=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,cookies=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,redirects=NtyUuvFErsfhPRgqKVJTHQIlXACMLm)
   if NtyUuvFErsfhPRgqKVJTHQIlXACMdY.status_code not in[200]:return '','',''
   NtyUuvFErsfhPRgqKVJTHQIlXACMdO=json.loads(NtyUuvFErsfhPRgqKVJTHQIlXACMdY.text).get('data')
   NtyUuvFErsfhPRgqKVJTHQIlXACMDk={'asset_id':NtyUuvFErsfhPRgqKVJTHQIlXACMdO.get('asset_id'),'deal_id':NtyUuvFErsfhPRgqKVJTHQIlXACMdO.get('deal_id'),'region':NtyUuvFErsfhPRgqKVJTHQIlXACMdO.get('region'),'streamable':'true' if NtyUuvFErsfhPRgqKVJTHQIlXACMdO.get('streamable')else 'false',}
  except NtyUuvFErsfhPRgqKVJTHQIlXACMLb as exception:
   NtyUuvFErsfhPRgqKVJTHQIlXACMLa(exception)
   return{}
  return NtyUuvFErsfhPRgqKVJTHQIlXACMDk
 def GetBroadURL(NtyUuvFErsfhPRgqKVJTHQIlXACMnD,titleId):
  NtyUuvFErsfhPRgqKVJTHQIlXACMDa=''
  NtyUuvFErsfhPRgqKVJTHQIlXACMDO =''
  NtyUuvFErsfhPRgqKVJTHQIlXACMDk=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.Get_vInfo(titleId)
  if NtyUuvFErsfhPRgqKVJTHQIlXACMDk=={}:return '',''
  try:
   NtyUuvFErsfhPRgqKVJTHQIlXACMdL=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.API_DOMAIN+'/api/playback/play' 
   NtyUuvFErsfhPRgqKVJTHQIlXACMdG={'titleId':titleId}
   NtyUuvFErsfhPRgqKVJTHQIlXACMnW,NtyUuvFErsfhPRgqKVJTHQIlXACMnj,NtyUuvFErsfhPRgqKVJTHQIlXACMnx=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.Make_authHeader()
   NtyUuvFErsfhPRgqKVJTHQIlXACMdk={'traceparent':NtyUuvFErsfhPRgqKVJTHQIlXACMnW,'tracestate':NtyUuvFErsfhPRgqKVJTHQIlXACMnj,'newrelic':NtyUuvFErsfhPRgqKVJTHQIlXACMnx,'x-force-raw':'true','x-pcid':NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':NtyUuvFErsfhPRgqKVJTHQIlXACMDk.get('age_rating'),'x-title-availability':NtyUuvFErsfhPRgqKVJTHQIlXACMDk.get('availability'),'x-title-brightcove-id':NtyUuvFErsfhPRgqKVJTHQIlXACMDk.get('asset_id'),'x-title-deal-id':NtyUuvFErsfhPRgqKVJTHQIlXACMDk.get('deal_id'),'x-title-downloadable':NtyUuvFErsfhPRgqKVJTHQIlXACMDk.get('downloadable'),'x-title-region':NtyUuvFErsfhPRgqKVJTHQIlXACMDk.get('region'),'x-title-streamable':NtyUuvFErsfhPRgqKVJTHQIlXACMDk.get('streamable'),}
   NtyUuvFErsfhPRgqKVJTHQIlXACMdD=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.make_CP_DefaultCookies()
   NtyUuvFErsfhPRgqKVJTHQIlXACMdY=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.callRequestCookies('Get',NtyUuvFErsfhPRgqKVJTHQIlXACMdL,payload=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,params=NtyUuvFErsfhPRgqKVJTHQIlXACMdG,headers=NtyUuvFErsfhPRgqKVJTHQIlXACMdk,cookies=NtyUuvFErsfhPRgqKVJTHQIlXACMdD,redirects=NtyUuvFErsfhPRgqKVJTHQIlXACMLm)
   if NtyUuvFErsfhPRgqKVJTHQIlXACMdY.status_code not in[200]:return '',json.loads(NtyUuvFErsfhPRgqKVJTHQIlXACMdY.text).get('error').get('detail')
   NtyUuvFErsfhPRgqKVJTHQIlXACMdO=json.loads(NtyUuvFErsfhPRgqKVJTHQIlXACMdY.text)
   for NtyUuvFErsfhPRgqKVJTHQIlXACMdx in NtyUuvFErsfhPRgqKVJTHQIlXACMdO.get('data').get('raw').get('sources'):
    if NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('type')=='application/dash+xml' and NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('src')[0:8]=='https://':
     NtyUuvFErsfhPRgqKVJTHQIlXACMDa=NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('src')
     if 'key_systems' in NtyUuvFErsfhPRgqKVJTHQIlXACMdx:
      NtyUuvFErsfhPRgqKVJTHQIlXACMDO =NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('key_systems').get('com.widevine.alpha').get('license_url')
     break
  except NtyUuvFErsfhPRgqKVJTHQIlXACMLb as exception:
   NtyUuvFErsfhPRgqKVJTHQIlXACMLa(exception)
   return '',''
  return NtyUuvFErsfhPRgqKVJTHQIlXACMDa,NtyUuvFErsfhPRgqKVJTHQIlXACMDO
 def GetEventURL(NtyUuvFErsfhPRgqKVJTHQIlXACMnD,eventId,NtyUuvFErsfhPRgqKVJTHQIlXACMDj):
  NtyUuvFErsfhPRgqKVJTHQIlXACMDa=''
  NtyUuvFErsfhPRgqKVJTHQIlXACMDO =''
  NtyUuvFErsfhPRgqKVJTHQIlXACMDk=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.Get_eInfo(eventId)
  if NtyUuvFErsfhPRgqKVJTHQIlXACMDk=={}:return '',''
  try:
   NtyUuvFErsfhPRgqKVJTHQIlXACMdL=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.API_DOMAIN+'/api/playback/play' 
   NtyUuvFErsfhPRgqKVJTHQIlXACMdG={'titleId':eventId,'titleType':NtyUuvFErsfhPRgqKVJTHQIlXACMDj,}
   NtyUuvFErsfhPRgqKVJTHQIlXACMnW,NtyUuvFErsfhPRgqKVJTHQIlXACMnj,NtyUuvFErsfhPRgqKVJTHQIlXACMnx=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.Make_authHeader()
   NtyUuvFErsfhPRgqKVJTHQIlXACMdk={'traceparent':NtyUuvFErsfhPRgqKVJTHQIlXACMnW,'tracestate':NtyUuvFErsfhPRgqKVJTHQIlXACMnj,'newrelic':NtyUuvFErsfhPRgqKVJTHQIlXACMnx,'x-force-raw':'true','x-pcid':NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':NtyUuvFErsfhPRgqKVJTHQIlXACMDk.get('asset_id'),'x-title-deal-id':NtyUuvFErsfhPRgqKVJTHQIlXACMDk.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':NtyUuvFErsfhPRgqKVJTHQIlXACMDk.get('region'),'x-title-streamable':NtyUuvFErsfhPRgqKVJTHQIlXACMDk.get('streamable'),}
   NtyUuvFErsfhPRgqKVJTHQIlXACMdD=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.make_CP_DefaultCookies()
   NtyUuvFErsfhPRgqKVJTHQIlXACMdY=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.callRequestCookies('Get',NtyUuvFErsfhPRgqKVJTHQIlXACMdL,payload=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,params=NtyUuvFErsfhPRgqKVJTHQIlXACMdG,headers=NtyUuvFErsfhPRgqKVJTHQIlXACMdk,cookies=NtyUuvFErsfhPRgqKVJTHQIlXACMdD,redirects=NtyUuvFErsfhPRgqKVJTHQIlXACMLm)
   if NtyUuvFErsfhPRgqKVJTHQIlXACMdY.status_code not in[200]:return '',json.loads(NtyUuvFErsfhPRgqKVJTHQIlXACMdY.text).get('error').get('detail')
   NtyUuvFErsfhPRgqKVJTHQIlXACMdO=json.loads(NtyUuvFErsfhPRgqKVJTHQIlXACMdY.text)
   for NtyUuvFErsfhPRgqKVJTHQIlXACMdx in NtyUuvFErsfhPRgqKVJTHQIlXACMdO.get('data').get('raw').get('sources'):
    if NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('type')=='application/dash+xml' and NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('src')[0:8]=='https://':
     NtyUuvFErsfhPRgqKVJTHQIlXACMDa=NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('src')
     if 'key_systems' in NtyUuvFErsfhPRgqKVJTHQIlXACMdx:
      NtyUuvFErsfhPRgqKVJTHQIlXACMDO =NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('key_systems').get('com.widevine.alpha').get('license_url')
     break
  except NtyUuvFErsfhPRgqKVJTHQIlXACMLb as exception:
   NtyUuvFErsfhPRgqKVJTHQIlXACMLa(exception)
   return '',''
  return NtyUuvFErsfhPRgqKVJTHQIlXACMDa,NtyUuvFErsfhPRgqKVJTHQIlXACMDO
 def GetEventURL_Live(NtyUuvFErsfhPRgqKVJTHQIlXACMnD,eventId,NtyUuvFErsfhPRgqKVJTHQIlXACMDj):
  NtyUuvFErsfhPRgqKVJTHQIlXACMDa=''
  NtyUuvFErsfhPRgqKVJTHQIlXACMDO =''
  NtyUuvFErsfhPRgqKVJTHQIlXACMDk=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.Get_eInfo(eventId)
  if NtyUuvFErsfhPRgqKVJTHQIlXACMDk=={}:return '',''
  try:
   NtyUuvFErsfhPRgqKVJTHQIlXACMdL=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.API_DOMAIN+'/api/playback/play' 
   NtyUuvFErsfhPRgqKVJTHQIlXACMdG={'titleId':eventId,'titleType':NtyUuvFErsfhPRgqKVJTHQIlXACMDj,}
   NtyUuvFErsfhPRgqKVJTHQIlXACMnW,NtyUuvFErsfhPRgqKVJTHQIlXACMnj,NtyUuvFErsfhPRgqKVJTHQIlXACMnx=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.Make_authHeader()
   NtyUuvFErsfhPRgqKVJTHQIlXACMdk={'traceparent':NtyUuvFErsfhPRgqKVJTHQIlXACMnW,'tracestate':NtyUuvFErsfhPRgqKVJTHQIlXACMnj,'newrelic':NtyUuvFErsfhPRgqKVJTHQIlXACMnx,'x-force-raw':'true','x-pcid':NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':NtyUuvFErsfhPRgqKVJTHQIlXACMDk.get('asset_id'),'x-title-deal-id':NtyUuvFErsfhPRgqKVJTHQIlXACMDk.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':NtyUuvFErsfhPRgqKVJTHQIlXACMDk.get('region'),'x-title-streamable':NtyUuvFErsfhPRgqKVJTHQIlXACMDk.get('streamable'),}
   NtyUuvFErsfhPRgqKVJTHQIlXACMdD=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.make_CP_DefaultCookies()
   NtyUuvFErsfhPRgqKVJTHQIlXACMdY=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.callRequestCookies('Get',NtyUuvFErsfhPRgqKVJTHQIlXACMdL,payload=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,params=NtyUuvFErsfhPRgqKVJTHQIlXACMdG,headers=NtyUuvFErsfhPRgqKVJTHQIlXACMdk,cookies=NtyUuvFErsfhPRgqKVJTHQIlXACMdD,redirects=NtyUuvFErsfhPRgqKVJTHQIlXACMLm)
   if NtyUuvFErsfhPRgqKVJTHQIlXACMdY.status_code not in[200]:return '',json.loads(NtyUuvFErsfhPRgqKVJTHQIlXACMdY.text).get('error').get('detail')
   NtyUuvFErsfhPRgqKVJTHQIlXACMdO=json.loads(NtyUuvFErsfhPRgqKVJTHQIlXACMdY.text)
   for NtyUuvFErsfhPRgqKVJTHQIlXACMdx in NtyUuvFErsfhPRgqKVJTHQIlXACMdO.get('data').get('raw').get('sources'):
    if NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('type')=='application/dash+xml' and 'com.widevine.alpha' in NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('key_systems')and NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('src')[0:8]=='https://':
     NtyUuvFErsfhPRgqKVJTHQIlXACMDa=NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('src')
     NtyUuvFErsfhPRgqKVJTHQIlXACMDO =NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('key_systems').get('com.widevine.alpha').get('license_url')
  except NtyUuvFErsfhPRgqKVJTHQIlXACMLb as exception:
   NtyUuvFErsfhPRgqKVJTHQIlXACMLa(exception)
   return '',''
  return NtyUuvFErsfhPRgqKVJTHQIlXACMDa,NtyUuvFErsfhPRgqKVJTHQIlXACMDO
 def Get_Theme_GroupList(NtyUuvFErsfhPRgqKVJTHQIlXACMnD,vType):
  NtyUuvFErsfhPRgqKVJTHQIlXACMdm=[] 
  try:
   NtyUuvFErsfhPRgqKVJTHQIlXACMdL=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.API_VIEWURL+'/v2/discover/feed' 
   NtyUuvFErsfhPRgqKVJTHQIlXACMdG={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':NtyUuvFErsfhPRgqKVJTHQIlXACMLO(NtyUuvFErsfhPRgqKVJTHQIlXACMnD.PAGE_LIMIT),'filterRestrictedContent':'false',}
   NtyUuvFErsfhPRgqKVJTHQIlXACMdY=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.callRequestCookies('Get',NtyUuvFErsfhPRgqKVJTHQIlXACMdL,payload=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,params=NtyUuvFErsfhPRgqKVJTHQIlXACMdG,headers=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,cookies=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,redirects=NtyUuvFErsfhPRgqKVJTHQIlXACMLm)
   if NtyUuvFErsfhPRgqKVJTHQIlXACMdY.status_code not in[200]:return[]
   NtyUuvFErsfhPRgqKVJTHQIlXACMdO=json.loads(NtyUuvFErsfhPRgqKVJTHQIlXACMdY.text)
   for NtyUuvFErsfhPRgqKVJTHQIlXACMdx in NtyUuvFErsfhPRgqKVJTHQIlXACMdO.get('data'):
    if NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('type')=='Title-Rails-Curation':
     NtyUuvFErsfhPRgqKVJTHQIlXACMDi =''
     NtyUuvFErsfhPRgqKVJTHQIlXACMDe=7
     try:
      for i in NtyUuvFErsfhPRgqKVJTHQIlXACMLG(NtyUuvFErsfhPRgqKVJTHQIlXACMLW(NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('data'))):
       if i>=NtyUuvFErsfhPRgqKVJTHQIlXACMDe:
        NtyUuvFErsfhPRgqKVJTHQIlXACMDi=NtyUuvFErsfhPRgqKVJTHQIlXACMDi+'...'
        break
       NtyUuvFErsfhPRgqKVJTHQIlXACMDi=NtyUuvFErsfhPRgqKVJTHQIlXACMDi+NtyUuvFErsfhPRgqKVJTHQIlXACMdx['data'][i]['title']+'\n'
     except NtyUuvFErsfhPRgqKVJTHQIlXACMLb as exception:
      NtyUuvFErsfhPRgqKVJTHQIlXACMLa(exception)
     NtyUuvFErsfhPRgqKVJTHQIlXACMdp={'collectionId':NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('obj_id'),'title':NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('row_name'),'category':NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('category'),'pre_title':NtyUuvFErsfhPRgqKVJTHQIlXACMDi,}
     NtyUuvFErsfhPRgqKVJTHQIlXACMdm.append(NtyUuvFErsfhPRgqKVJTHQIlXACMdp)
  except NtyUuvFErsfhPRgqKVJTHQIlXACMLb as exception:
   NtyUuvFErsfhPRgqKVJTHQIlXACMLa(exception)
   return[]
  return NtyUuvFErsfhPRgqKVJTHQIlXACMdm
 def Get_Event_GroupList(NtyUuvFErsfhPRgqKVJTHQIlXACMnD):
  NtyUuvFErsfhPRgqKVJTHQIlXACMdm=[] 
  try:
   NtyUuvFErsfhPRgqKVJTHQIlXACMdL=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.API_VIEWURL+'/v2/discover/feed' 
   NtyUuvFErsfhPRgqKVJTHQIlXACMdG={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':7,'filterRestrictedContent':'false',}
   NtyUuvFErsfhPRgqKVJTHQIlXACMdY=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.callRequestCookies('Get',NtyUuvFErsfhPRgqKVJTHQIlXACMdL,payload=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,params=NtyUuvFErsfhPRgqKVJTHQIlXACMdG,headers=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,cookies=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,redirects=NtyUuvFErsfhPRgqKVJTHQIlXACMLm)
   if NtyUuvFErsfhPRgqKVJTHQIlXACMdY.status_code not in[200]:return[]
   NtyUuvFErsfhPRgqKVJTHQIlXACMdO=json.loads(NtyUuvFErsfhPRgqKVJTHQIlXACMdY.text)
   for NtyUuvFErsfhPRgqKVJTHQIlXACMdx in NtyUuvFErsfhPRgqKVJTHQIlXACMdO.get('data'):
    if NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('row_name').strip()!='':
     NtyUuvFErsfhPRgqKVJTHQIlXACMDi =''
     NtyUuvFErsfhPRgqKVJTHQIlXACMDe=7
     try:
      for i in NtyUuvFErsfhPRgqKVJTHQIlXACMLG(NtyUuvFErsfhPRgqKVJTHQIlXACMLW(NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('data'))):
       if i>=NtyUuvFErsfhPRgqKVJTHQIlXACMDe:
        NtyUuvFErsfhPRgqKVJTHQIlXACMDi=NtyUuvFErsfhPRgqKVJTHQIlXACMDi+'...'
        break
       NtyUuvFErsfhPRgqKVJTHQIlXACMDi=NtyUuvFErsfhPRgqKVJTHQIlXACMDi+NtyUuvFErsfhPRgqKVJTHQIlXACMdx['data'][i]['title']+'\n'
     except NtyUuvFErsfhPRgqKVJTHQIlXACMLb as exception:
      NtyUuvFErsfhPRgqKVJTHQIlXACMLa(exception)
     NtyUuvFErsfhPRgqKVJTHQIlXACMdp={'collectionId':NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('obj_id'),'title':NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('row_name'),'category':NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('type'),'pre_title':NtyUuvFErsfhPRgqKVJTHQIlXACMDi,}
     NtyUuvFErsfhPRgqKVJTHQIlXACMdm.append(NtyUuvFErsfhPRgqKVJTHQIlXACMdp)
  except NtyUuvFErsfhPRgqKVJTHQIlXACMLb as exception:
   NtyUuvFErsfhPRgqKVJTHQIlXACMLa(exception)
   return[]
  return NtyUuvFErsfhPRgqKVJTHQIlXACMdm
 def Get_Event_GameList(NtyUuvFErsfhPRgqKVJTHQIlXACMnD,NtyUuvFErsfhPRgqKVJTHQIlXACMdB):
  NtyUuvFErsfhPRgqKVJTHQIlXACMdm=[] 
  try:
   NtyUuvFErsfhPRgqKVJTHQIlXACMdL=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.API_VIEWURL+'/v2/discover/feed' 
   NtyUuvFErsfhPRgqKVJTHQIlXACMdG={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false',}
   NtyUuvFErsfhPRgqKVJTHQIlXACMdY=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.callRequestCookies('Get',NtyUuvFErsfhPRgqKVJTHQIlXACMdL,payload=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,params=NtyUuvFErsfhPRgqKVJTHQIlXACMdG,headers=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,cookies=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,redirects=NtyUuvFErsfhPRgqKVJTHQIlXACMLm)
   if NtyUuvFErsfhPRgqKVJTHQIlXACMdY.status_code not in[200]:return[]
   NtyUuvFErsfhPRgqKVJTHQIlXACMdO=json.loads(NtyUuvFErsfhPRgqKVJTHQIlXACMdY.text)
   for NtyUuvFErsfhPRgqKVJTHQIlXACMdx in NtyUuvFErsfhPRgqKVJTHQIlXACMdO.get('data'):
    if NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('obj_id')==NtyUuvFErsfhPRgqKVJTHQIlXACMdB:
     for NtyUuvFErsfhPRgqKVJTHQIlXACMDb in NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('data'):
      NtyUuvFErsfhPRgqKVJTHQIlXACMDL=NtyUuvFErsfhPRgqKVJTHQIlXACMDc=NtyUuvFErsfhPRgqKVJTHQIlXACMLd=''
      if 'poster' in NtyUuvFErsfhPRgqKVJTHQIlXACMDb.get('images'):NtyUuvFErsfhPRgqKVJTHQIlXACMDL =NtyUuvFErsfhPRgqKVJTHQIlXACMDb.get('images').get('poster').get('url')
      if 'story-art' in NtyUuvFErsfhPRgqKVJTHQIlXACMDb.get('images'):NtyUuvFErsfhPRgqKVJTHQIlXACMDc =NtyUuvFErsfhPRgqKVJTHQIlXACMDb.get('images').get('story-art').get('url')
      if 'hero' in NtyUuvFErsfhPRgqKVJTHQIlXACMDb.get('images'):NtyUuvFErsfhPRgqKVJTHQIlXACMLd =NtyUuvFErsfhPRgqKVJTHQIlXACMDb.get('images').get('hero').get('url')
      NtyUuvFErsfhPRgqKVJTHQIlXACMDz=NtyUuvFErsfhPRgqKVJTHQIlXACMDb.get('meta').get(NtyUuvFErsfhPRgqKVJTHQIlXACMDb.get('category')).get(NtyUuvFErsfhPRgqKVJTHQIlXACMDb.get('sub_category'))
      if 'league' in NtyUuvFErsfhPRgqKVJTHQIlXACMDz:
       NtyUuvFErsfhPRgqKVJTHQIlXACMDm=NtyUuvFErsfhPRgqKVJTHQIlXACMDz.get('league')
      else:
       NtyUuvFErsfhPRgqKVJTHQIlXACMDm=NtyUuvFErsfhPRgqKVJTHQIlXACMDz.get('round')
      NtyUuvFErsfhPRgqKVJTHQIlXACMdp={'id':NtyUuvFErsfhPRgqKVJTHQIlXACMDb.get('id'),'title':NtyUuvFErsfhPRgqKVJTHQIlXACMDb.get('title'),'thumbnail':{'poster':NtyUuvFErsfhPRgqKVJTHQIlXACMDL,'thumb':NtyUuvFErsfhPRgqKVJTHQIlXACMDc,'fanart':NtyUuvFErsfhPRgqKVJTHQIlXACMLd},'asis':NtyUuvFErsfhPRgqKVJTHQIlXACMDb.get('type'),'addInfo':NtyUuvFErsfhPRgqKVJTHQIlXACMDm,'starttm':NtyUuvFErsfhPRgqKVJTHQIlXACMnD.convert_TimeStr(NtyUuvFErsfhPRgqKVJTHQIlXACMDb.get('start_at')),}
      NtyUuvFErsfhPRgqKVJTHQIlXACMdm.append(NtyUuvFErsfhPRgqKVJTHQIlXACMdp)
  except NtyUuvFErsfhPRgqKVJTHQIlXACMLb as exception:
   NtyUuvFErsfhPRgqKVJTHQIlXACMLa(exception)
   return[]
  return NtyUuvFErsfhPRgqKVJTHQIlXACMdm
 def Get_Event_List(NtyUuvFErsfhPRgqKVJTHQIlXACMnD,gameId):
  NtyUuvFErsfhPRgqKVJTHQIlXACMdm=[] 
  try:
   NtyUuvFErsfhPRgqKVJTHQIlXACMdL=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.API_VIEWURL+'/v1/discover/events/'+gameId 
   NtyUuvFErsfhPRgqKVJTHQIlXACMdG={'platform':'WEBCLIENT','locale':'ko','filterRestrictedContent':'false',}
   NtyUuvFErsfhPRgqKVJTHQIlXACMdY=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.callRequestCookies('Get',NtyUuvFErsfhPRgqKVJTHQIlXACMdL,payload=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,params=NtyUuvFErsfhPRgqKVJTHQIlXACMdG,headers=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,cookies=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,redirects=NtyUuvFErsfhPRgqKVJTHQIlXACMLm)
   if NtyUuvFErsfhPRgqKVJTHQIlXACMdY.status_code not in[200]:return[]
   NtyUuvFErsfhPRgqKVJTHQIlXACMdO=json.loads(NtyUuvFErsfhPRgqKVJTHQIlXACMdY.text)
   NtyUuvFErsfhPRgqKVJTHQIlXACMdx=NtyUuvFErsfhPRgqKVJTHQIlXACMdO.get('data')
   NtyUuvFErsfhPRgqKVJTHQIlXACMDG=NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('end_at')
   NtyUuvFErsfhPRgqKVJTHQIlXACMDG=NtyUuvFErsfhPRgqKVJTHQIlXACMDG[0:19].replace('-','').replace(':','').replace('T','')
   NtyUuvFErsfhPRgqKVJTHQIlXACMDW=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d%H%M%S')
   if NtyUuvFErsfhPRgqKVJTHQIlXACMLe(NtyUuvFErsfhPRgqKVJTHQIlXACMDW)<NtyUuvFErsfhPRgqKVJTHQIlXACMLe(NtyUuvFErsfhPRgqKVJTHQIlXACMDG):
    NtyUuvFErsfhPRgqKVJTHQIlXACMDL=NtyUuvFErsfhPRgqKVJTHQIlXACMDc=NtyUuvFErsfhPRgqKVJTHQIlXACMLd=''
    if 'poster' in NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('images'):NtyUuvFErsfhPRgqKVJTHQIlXACMDL =NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('images').get('poster').get('url')
    if 'story-art' in NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('images'):NtyUuvFErsfhPRgqKVJTHQIlXACMDc =NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('images').get('story-art').get('url')
    if 'story-art' in NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('images'):NtyUuvFErsfhPRgqKVJTHQIlXACMLd =NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('images').get('story-art').get('url')
    NtyUuvFErsfhPRgqKVJTHQIlXACMdp={'id':NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('id'),'title':NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('title'),'thumbnail':{'poster':NtyUuvFErsfhPRgqKVJTHQIlXACMDL,'thumb':NtyUuvFErsfhPRgqKVJTHQIlXACMDc,'fanart':NtyUuvFErsfhPRgqKVJTHQIlXACMLd},'duration':NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('running_time'),'asis':NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('type'),'starttm':NtyUuvFErsfhPRgqKVJTHQIlXACMnD.convert_TimeStr(NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('start_at')),}
    NtyUuvFErsfhPRgqKVJTHQIlXACMdm.append(NtyUuvFErsfhPRgqKVJTHQIlXACMdp)
  except NtyUuvFErsfhPRgqKVJTHQIlXACMLb as exception:
   NtyUuvFErsfhPRgqKVJTHQIlXACMLa(exception)
   return[]
  try:
   NtyUuvFErsfhPRgqKVJTHQIlXACMdL=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.API_VIEWURL+'/v1/discover/events/'+gameId+'/related' 
   NtyUuvFErsfhPRgqKVJTHQIlXACMdG={'locale':'ko','page':'1','perPage':'25','platform':'WEBCLIENT','currentPageTracking':'page_discover_title_detail',}
   NtyUuvFErsfhPRgqKVJTHQIlXACMdY=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.callRequestCookies('Get',NtyUuvFErsfhPRgqKVJTHQIlXACMdL,payload=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,params=NtyUuvFErsfhPRgqKVJTHQIlXACMdG,headers=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,cookies=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,redirects=NtyUuvFErsfhPRgqKVJTHQIlXACMLm)
   if NtyUuvFErsfhPRgqKVJTHQIlXACMdY.status_code not in[200]:return[]
   NtyUuvFErsfhPRgqKVJTHQIlXACMdO=json.loads(NtyUuvFErsfhPRgqKVJTHQIlXACMdY.text)
   for NtyUuvFErsfhPRgqKVJTHQIlXACMdx in NtyUuvFErsfhPRgqKVJTHQIlXACMdO.get('data').get('data'):
    NtyUuvFErsfhPRgqKVJTHQIlXACMDL=NtyUuvFErsfhPRgqKVJTHQIlXACMDc=NtyUuvFErsfhPRgqKVJTHQIlXACMLd=''
    if 'poster' in NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('images'):NtyUuvFErsfhPRgqKVJTHQIlXACMDL =NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('images').get('poster').get('url')
    if 'story-art' in NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('images'):NtyUuvFErsfhPRgqKVJTHQIlXACMDc =NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('images').get('story-art').get('url')
    if 'story-art' in NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('images'):NtyUuvFErsfhPRgqKVJTHQIlXACMLd =NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('images').get('story-art').get('url')
    NtyUuvFErsfhPRgqKVJTHQIlXACMdp={'id':NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('id'),'title':NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('title'),'thumbnail':{'poster':NtyUuvFErsfhPRgqKVJTHQIlXACMDL,'thumb':NtyUuvFErsfhPRgqKVJTHQIlXACMDc,'fanart':NtyUuvFErsfhPRgqKVJTHQIlXACMLd},'duration':NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('running_time'),'asis':NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('type'),}
    NtyUuvFErsfhPRgqKVJTHQIlXACMdm.append(NtyUuvFErsfhPRgqKVJTHQIlXACMdp)
  except NtyUuvFErsfhPRgqKVJTHQIlXACMLb as exception:
   NtyUuvFErsfhPRgqKVJTHQIlXACMLa(exception)
   return[]
  return NtyUuvFErsfhPRgqKVJTHQIlXACMdm
 def Get_Search_List(NtyUuvFErsfhPRgqKVJTHQIlXACMnD,search_key,page_int):
  NtyUuvFErsfhPRgqKVJTHQIlXACMdm=[] 
  NtyUuvFErsfhPRgqKVJTHQIlXACMDn=NtyUuvFErsfhPRgqKVJTHQIlXACMLk
  try:
   NtyUuvFErsfhPRgqKVJTHQIlXACMdL=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.API_VIEWURL+'/v2/search' 
   NtyUuvFErsfhPRgqKVJTHQIlXACMdG={'query':search_key,'platform':'WEBCLIENT','page':NtyUuvFErsfhPRgqKVJTHQIlXACMLO(page_int),'perPage':NtyUuvFErsfhPRgqKVJTHQIlXACMLO(NtyUuvFErsfhPRgqKVJTHQIlXACMnD.SEARCH_LIMIT),}
   NtyUuvFErsfhPRgqKVJTHQIlXACMdk={'x-membersrl':NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['member_srl'],'x-pcid':NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['PCID'],'x-profileid':NtyUuvFErsfhPRgqKVJTHQIlXACMnD.CP['SESSION']['profileId'],}
   NtyUuvFErsfhPRgqKVJTHQIlXACMdY=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.callRequestCookies('Get',NtyUuvFErsfhPRgqKVJTHQIlXACMdL,payload=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,params=NtyUuvFErsfhPRgqKVJTHQIlXACMdG,headers=NtyUuvFErsfhPRgqKVJTHQIlXACMdk,cookies=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,redirects=NtyUuvFErsfhPRgqKVJTHQIlXACMLm)
   if NtyUuvFErsfhPRgqKVJTHQIlXACMdY.status_code not in[200]:return[],NtyUuvFErsfhPRgqKVJTHQIlXACMLk
   NtyUuvFErsfhPRgqKVJTHQIlXACMdO=json.loads(NtyUuvFErsfhPRgqKVJTHQIlXACMdY.text)
   for NtyUuvFErsfhPRgqKVJTHQIlXACMdx in NtyUuvFErsfhPRgqKVJTHQIlXACMdO.get('data').get('data'):
    NtyUuvFErsfhPRgqKVJTHQIlXACMdx=NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('data')
    NtyUuvFErsfhPRgqKVJTHQIlXACMDL=NtyUuvFErsfhPRgqKVJTHQIlXACMDc=NtyUuvFErsfhPRgqKVJTHQIlXACMLD=NtyUuvFErsfhPRgqKVJTHQIlXACMLd=''
    if 'poster' in NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('images'):NtyUuvFErsfhPRgqKVJTHQIlXACMDL =NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('images').get('poster').get('url')
    if 'story-art' in NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('images'):NtyUuvFErsfhPRgqKVJTHQIlXACMDc =NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('images').get('story-art').get('url')
    if 'title-treatment' in NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('images'):NtyUuvFErsfhPRgqKVJTHQIlXACMLD=NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('images').get('title-treatment').get('url')
    if 'story-art' in NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('images'):NtyUuvFErsfhPRgqKVJTHQIlXACMLd =NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('images').get('story-art').get('url')
    NtyUuvFErsfhPRgqKVJTHQIlXACMDY=''
    if NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('badge')not in[{},NtyUuvFErsfhPRgqKVJTHQIlXACMLc]:
     for i in NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('badge').get('text'):
      if NtyUuvFErsfhPRgqKVJTHQIlXACMDY!='':NtyUuvFErsfhPRgqKVJTHQIlXACMDY+=' '
      NtyUuvFErsfhPRgqKVJTHQIlXACMDY+=i.get('text')
    if 'as' in NtyUuvFErsfhPRgqKVJTHQIlXACMdx:
     NtyUuvFErsfhPRgqKVJTHQIlXACMDj=NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('as') 
    else:
     NtyUuvFErsfhPRgqKVJTHQIlXACMDj=NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('type')
    NtyUuvFErsfhPRgqKVJTHQIlXACMdp={'id':NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('id'),'title':NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('title'),'asis':NtyUuvFErsfhPRgqKVJTHQIlXACMDj,'thumbnail':{'poster':NtyUuvFErsfhPRgqKVJTHQIlXACMDL,'thumb':NtyUuvFErsfhPRgqKVJTHQIlXACMDc,'clearlogo':NtyUuvFErsfhPRgqKVJTHQIlXACMLD,'fanart':NtyUuvFErsfhPRgqKVJTHQIlXACMLd},'mpaa':NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('age_rating'),'duration':NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('running_time'),'badge':NtyUuvFErsfhPRgqKVJTHQIlXACMDY,'year':NtyUuvFErsfhPRgqKVJTHQIlXACMdx.get('meta').get('releaseYear'),}
    NtyUuvFErsfhPRgqKVJTHQIlXACMdm.append(NtyUuvFErsfhPRgqKVJTHQIlXACMdp)
   if NtyUuvFErsfhPRgqKVJTHQIlXACMdO.get('pagination').get('totalPages')>page_int:
    NtyUuvFErsfhPRgqKVJTHQIlXACMDn=NtyUuvFErsfhPRgqKVJTHQIlXACMLm
  except NtyUuvFErsfhPRgqKVJTHQIlXACMLb as exception:
   NtyUuvFErsfhPRgqKVJTHQIlXACMLa(exception)
   return[],NtyUuvFErsfhPRgqKVJTHQIlXACMLk
  return NtyUuvFErsfhPRgqKVJTHQIlXACMdm,NtyUuvFErsfhPRgqKVJTHQIlXACMDn
 def GetBookmarkInfo(NtyUuvFErsfhPRgqKVJTHQIlXACMnD,videoid,vidtype):
  NtyUuvFErsfhPRgqKVJTHQIlXACMDx={'indexinfo':{'ott':'coupang','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  NtyUuvFErsfhPRgqKVJTHQIlXACMdL=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.API_VIEWURL+'/v1/discover/titles/'+videoid 
  NtyUuvFErsfhPRgqKVJTHQIlXACMdG={'locale':'ko'}
  NtyUuvFErsfhPRgqKVJTHQIlXACMdY=NtyUuvFErsfhPRgqKVJTHQIlXACMnD.callRequestCookies('Get',NtyUuvFErsfhPRgqKVJTHQIlXACMdL,payload=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,params=NtyUuvFErsfhPRgqKVJTHQIlXACMdG,headers=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,cookies=NtyUuvFErsfhPRgqKVJTHQIlXACMLc,redirects=NtyUuvFErsfhPRgqKVJTHQIlXACMLm)
  if NtyUuvFErsfhPRgqKVJTHQIlXACMdY.status_code not in[200]:return{}
  NtyUuvFErsfhPRgqKVJTHQIlXACMDB=json.loads(NtyUuvFErsfhPRgqKVJTHQIlXACMdY.text).get('data')
  NtyUuvFErsfhPRgqKVJTHQIlXACMDp=NtyUuvFErsfhPRgqKVJTHQIlXACMDB.get('title')
  NtyUuvFErsfhPRgqKVJTHQIlXACMLn =NtyUuvFErsfhPRgqKVJTHQIlXACMDB.get('meta').get('releaseYear')
  NtyUuvFErsfhPRgqKVJTHQIlXACMDx['saveinfo']['infoLabels']['title']=NtyUuvFErsfhPRgqKVJTHQIlXACMDp
  if vidtype=='movie':
   NtyUuvFErsfhPRgqKVJTHQIlXACMDp='%s  (%s)'%(NtyUuvFErsfhPRgqKVJTHQIlXACMDp,NtyUuvFErsfhPRgqKVJTHQIlXACMLn)
  NtyUuvFErsfhPRgqKVJTHQIlXACMDx['saveinfo']['title'] =NtyUuvFErsfhPRgqKVJTHQIlXACMDp
  NtyUuvFErsfhPRgqKVJTHQIlXACMDx['saveinfo']['infoLabels']['mpaa'] =NtyUuvFErsfhPRgqKVJTHQIlXACMDB.get('age_rating')
  NtyUuvFErsfhPRgqKVJTHQIlXACMDx['saveinfo']['infoLabels']['plot'] ='%s\n\n%s'%(NtyUuvFErsfhPRgqKVJTHQIlXACMDB.get('short_description'),NtyUuvFErsfhPRgqKVJTHQIlXACMDB.get('description'))
  NtyUuvFErsfhPRgqKVJTHQIlXACMDx['saveinfo']['infoLabels']['year'] =NtyUuvFErsfhPRgqKVJTHQIlXACMLn
  if vidtype=='movie':
   NtyUuvFErsfhPRgqKVJTHQIlXACMDx['saveinfo']['infoLabels']['duration']=NtyUuvFErsfhPRgqKVJTHQIlXACMDB.get('running_time')
  NtyUuvFErsfhPRgqKVJTHQIlXACMDL =''
  NtyUuvFErsfhPRgqKVJTHQIlXACMLd =''
  NtyUuvFErsfhPRgqKVJTHQIlXACMDc =''
  NtyUuvFErsfhPRgqKVJTHQIlXACMLD=''
  if NtyUuvFErsfhPRgqKVJTHQIlXACMDB.get('images').get('poster') !=NtyUuvFErsfhPRgqKVJTHQIlXACMLc:NtyUuvFErsfhPRgqKVJTHQIlXACMDL =NtyUuvFErsfhPRgqKVJTHQIlXACMDB.get('images').get('poster').get('url')
  if NtyUuvFErsfhPRgqKVJTHQIlXACMDB.get('images').get('background') !=NtyUuvFErsfhPRgqKVJTHQIlXACMLc:NtyUuvFErsfhPRgqKVJTHQIlXACMLd =NtyUuvFErsfhPRgqKVJTHQIlXACMDB.get('images').get('background').get('url')
  if NtyUuvFErsfhPRgqKVJTHQIlXACMDB.get('images').get('story-art') !=NtyUuvFErsfhPRgqKVJTHQIlXACMLc:NtyUuvFErsfhPRgqKVJTHQIlXACMDc =NtyUuvFErsfhPRgqKVJTHQIlXACMDB.get('images').get('story-art').get('url')
  if NtyUuvFErsfhPRgqKVJTHQIlXACMDB.get('images').get('title-treatment')!=NtyUuvFErsfhPRgqKVJTHQIlXACMLc:NtyUuvFErsfhPRgqKVJTHQIlXACMLD=NtyUuvFErsfhPRgqKVJTHQIlXACMDB.get('images').get('title-treatment').get('url')
  if NtyUuvFErsfhPRgqKVJTHQIlXACMLd=='':NtyUuvFErsfhPRgqKVJTHQIlXACMLd=NtyUuvFErsfhPRgqKVJTHQIlXACMDc
  NtyUuvFErsfhPRgqKVJTHQIlXACMDx['saveinfo']['thumbnail']['poster']=NtyUuvFErsfhPRgqKVJTHQIlXACMDL
  NtyUuvFErsfhPRgqKVJTHQIlXACMDx['saveinfo']['thumbnail']['fanart']=NtyUuvFErsfhPRgqKVJTHQIlXACMLd
  NtyUuvFErsfhPRgqKVJTHQIlXACMDx['saveinfo']['thumbnail']['thumb']=NtyUuvFErsfhPRgqKVJTHQIlXACMDc
  NtyUuvFErsfhPRgqKVJTHQIlXACMDx['saveinfo']['thumbnail']['clearlogo']=NtyUuvFErsfhPRgqKVJTHQIlXACMLD
  NtyUuvFErsfhPRgqKVJTHQIlXACMLY=[]
  for NtyUuvFErsfhPRgqKVJTHQIlXACMDo in NtyUuvFErsfhPRgqKVJTHQIlXACMDB.get('tags'):NtyUuvFErsfhPRgqKVJTHQIlXACMLY.append(NtyUuvFErsfhPRgqKVJTHQIlXACMDo.get('tag'))
  if NtyUuvFErsfhPRgqKVJTHQIlXACMLW(NtyUuvFErsfhPRgqKVJTHQIlXACMLY)>0:
   NtyUuvFErsfhPRgqKVJTHQIlXACMDx['saveinfo']['infoLabels']['genre']=NtyUuvFErsfhPRgqKVJTHQIlXACMLY
  NtyUuvFErsfhPRgqKVJTHQIlXACMLw=[]
  NtyUuvFErsfhPRgqKVJTHQIlXACMLS=[]
  for NtyUuvFErsfhPRgqKVJTHQIlXACMDo in NtyUuvFErsfhPRgqKVJTHQIlXACMDB.get('people'):
   if NtyUuvFErsfhPRgqKVJTHQIlXACMDo.get('role')=='CAST' :NtyUuvFErsfhPRgqKVJTHQIlXACMLw.append(NtyUuvFErsfhPRgqKVJTHQIlXACMDo.get('name'))
   if NtyUuvFErsfhPRgqKVJTHQIlXACMDo.get('role')=='DIRECTOR':NtyUuvFErsfhPRgqKVJTHQIlXACMLS.append(NtyUuvFErsfhPRgqKVJTHQIlXACMDo.get('name'))
  if NtyUuvFErsfhPRgqKVJTHQIlXACMLW(NtyUuvFErsfhPRgqKVJTHQIlXACMLw)>0:
   NtyUuvFErsfhPRgqKVJTHQIlXACMDx['saveinfo']['infoLabels']['cast'] =NtyUuvFErsfhPRgqKVJTHQIlXACMLw
  if NtyUuvFErsfhPRgqKVJTHQIlXACMLW(NtyUuvFErsfhPRgqKVJTHQIlXACMLS)>0:
   NtyUuvFErsfhPRgqKVJTHQIlXACMDx['saveinfo']['infoLabels']['director']=NtyUuvFErsfhPRgqKVJTHQIlXACMLS
  return NtyUuvFErsfhPRgqKVJTHQIlXACMDx
# Created by pyminifier (https://github.com/liftoff/pyminifier)
