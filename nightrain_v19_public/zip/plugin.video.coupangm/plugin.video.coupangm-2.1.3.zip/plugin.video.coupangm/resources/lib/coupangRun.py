__author__="NightRain"
rKNpuHsJvWEBmylXAnikzFaDtgbVce=object
rKNpuHsJvWEBmylXAnikzFaDtgbVcx=None
rKNpuHsJvWEBmylXAnikzFaDtgbVcR=False
rKNpuHsJvWEBmylXAnikzFaDtgbVoP=True
rKNpuHsJvWEBmylXAnikzFaDtgbVoq=type
rKNpuHsJvWEBmylXAnikzFaDtgbVoU=dict
rKNpuHsJvWEBmylXAnikzFaDtgbVoh=getattr
rKNpuHsJvWEBmylXAnikzFaDtgbVoC=int
rKNpuHsJvWEBmylXAnikzFaDtgbVoc=list
rKNpuHsJvWEBmylXAnikzFaDtgbVow=open
rKNpuHsJvWEBmylXAnikzFaDtgbVoM=Exception
rKNpuHsJvWEBmylXAnikzFaDtgbVod=str
rKNpuHsJvWEBmylXAnikzFaDtgbVoT=id
rKNpuHsJvWEBmylXAnikzFaDtgbVoI=len
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import inputstreamhelper
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
rKNpuHsJvWEBmylXAnikzFaDtgbVPU=[{'title':'오직 쿠팡플레이에서','mode':'CATEGORY_LIST','vType':'ORIGINAL','collectionId':'5c33c5ca-ee6f-45f8-a026-dd789a8b63cf'},{'title':'홈   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'ALL'},{'title':'TV   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'MOVIES'},{'title':'키즈 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'KIDS'},{'title':'생중계','mode':'EVENT_GROUPLIST','vType':'LIVE'},{'title':'TV   (테마별)','mode':'THEME_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (테마별)','mode':'THEME_GROUPLIST','vType':'MOVIES'},{'title':'키즈 (테마별)','mode':'THEME_GROUPLIST','vType':'KIDS'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},{'title':'(쿠팡) 검색','mode':'LOCAL_SEARCH','icon':'search.png'},{'title':'(쿠팡) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
rKNpuHsJvWEBmylXAnikzFaDtgbVPh=[{'title':'시리즈 시청내역','mode':'WATCH','stype':'tvshow'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},]
rKNpuHsJvWEBmylXAnikzFaDtgbVPC={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
rKNpuHsJvWEBmylXAnikzFaDtgbVPc=xbmcvfs.translatePath(os.path.join(__profile__,'coupang_searched.txt'))
from coupangCore import*
class rKNpuHsJvWEBmylXAnikzFaDtgbVPq(rKNpuHsJvWEBmylXAnikzFaDtgbVce):
 def __init__(rKNpuHsJvWEBmylXAnikzFaDtgbVPo,rKNpuHsJvWEBmylXAnikzFaDtgbVPw,rKNpuHsJvWEBmylXAnikzFaDtgbVPM,rKNpuHsJvWEBmylXAnikzFaDtgbVPd):
  rKNpuHsJvWEBmylXAnikzFaDtgbVPo._addon_url =rKNpuHsJvWEBmylXAnikzFaDtgbVPw
  rKNpuHsJvWEBmylXAnikzFaDtgbVPo._addon_handle=rKNpuHsJvWEBmylXAnikzFaDtgbVPM
  rKNpuHsJvWEBmylXAnikzFaDtgbVPo.main_params =rKNpuHsJvWEBmylXAnikzFaDtgbVPd
  rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj =rPypWKNdoQlAxvIHwbCBqnRgcMTOza() 
  rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.CP_COOKIE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_cookies.json'))
  rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.CP_DEVICE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_device.json'))
 def addon_noti(rKNpuHsJvWEBmylXAnikzFaDtgbVPo,sting):
  try:
   rKNpuHsJvWEBmylXAnikzFaDtgbVPI=xbmcgui.Dialog()
   rKNpuHsJvWEBmylXAnikzFaDtgbVPI.notification(__addonname__,sting)
  except:
   rKNpuHsJvWEBmylXAnikzFaDtgbVcx
 def addon_log(rKNpuHsJvWEBmylXAnikzFaDtgbVPo,string):
  try:
   rKNpuHsJvWEBmylXAnikzFaDtgbVPj=string.encode('utf-8','ignore')
  except:
   rKNpuHsJvWEBmylXAnikzFaDtgbVPj='addonException: addon_log'
  rKNpuHsJvWEBmylXAnikzFaDtgbVPL=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,rKNpuHsJvWEBmylXAnikzFaDtgbVPj),level=rKNpuHsJvWEBmylXAnikzFaDtgbVPL)
 def get_keyboard_input(rKNpuHsJvWEBmylXAnikzFaDtgbVPo,rKNpuHsJvWEBmylXAnikzFaDtgbVqh):
  rKNpuHsJvWEBmylXAnikzFaDtgbVPO=rKNpuHsJvWEBmylXAnikzFaDtgbVcx
  kb=xbmc.Keyboard()
  kb.setHeading(rKNpuHsJvWEBmylXAnikzFaDtgbVqh)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   rKNpuHsJvWEBmylXAnikzFaDtgbVPO=kb.getText()
  return rKNpuHsJvWEBmylXAnikzFaDtgbVPO
 def get_settings_account(rKNpuHsJvWEBmylXAnikzFaDtgbVPo):
  rKNpuHsJvWEBmylXAnikzFaDtgbVPG=__addon__.getSetting('id')
  rKNpuHsJvWEBmylXAnikzFaDtgbVPf=__addon__.getSetting('pw')
  rKNpuHsJvWEBmylXAnikzFaDtgbVPQ=__addon__.getSetting('profile')
  return(rKNpuHsJvWEBmylXAnikzFaDtgbVPG,rKNpuHsJvWEBmylXAnikzFaDtgbVPf,rKNpuHsJvWEBmylXAnikzFaDtgbVPQ)
 def get_settings_exclusion21(rKNpuHsJvWEBmylXAnikzFaDtgbVPo):
  rKNpuHsJvWEBmylXAnikzFaDtgbVPY =__addon__.getSetting('exclusion21')
  if rKNpuHsJvWEBmylXAnikzFaDtgbVPY=='false':
   return rKNpuHsJvWEBmylXAnikzFaDtgbVcR
  else:
   return rKNpuHsJvWEBmylXAnikzFaDtgbVoP
 def get_settings_totalsearch(rKNpuHsJvWEBmylXAnikzFaDtgbVPo):
  rKNpuHsJvWEBmylXAnikzFaDtgbVPS =rKNpuHsJvWEBmylXAnikzFaDtgbVoP if __addon__.getSetting('local_search')=='true' else rKNpuHsJvWEBmylXAnikzFaDtgbVcR
  rKNpuHsJvWEBmylXAnikzFaDtgbVPe=rKNpuHsJvWEBmylXAnikzFaDtgbVoP if __addon__.getSetting('local_history')=='true' else rKNpuHsJvWEBmylXAnikzFaDtgbVcR
  rKNpuHsJvWEBmylXAnikzFaDtgbVPx =rKNpuHsJvWEBmylXAnikzFaDtgbVoP if __addon__.getSetting('total_search')=='true' else rKNpuHsJvWEBmylXAnikzFaDtgbVcR
  rKNpuHsJvWEBmylXAnikzFaDtgbVPR=rKNpuHsJvWEBmylXAnikzFaDtgbVoP if __addon__.getSetting('total_history')=='true' else rKNpuHsJvWEBmylXAnikzFaDtgbVcR
  rKNpuHsJvWEBmylXAnikzFaDtgbVqP=rKNpuHsJvWEBmylXAnikzFaDtgbVoP if __addon__.getSetting('menu_bookmark')=='true' else rKNpuHsJvWEBmylXAnikzFaDtgbVcR
  return(rKNpuHsJvWEBmylXAnikzFaDtgbVPS,rKNpuHsJvWEBmylXAnikzFaDtgbVPe,rKNpuHsJvWEBmylXAnikzFaDtgbVPx,rKNpuHsJvWEBmylXAnikzFaDtgbVPR,rKNpuHsJvWEBmylXAnikzFaDtgbVqP)
 def get_settings_makebookmark(rKNpuHsJvWEBmylXAnikzFaDtgbVPo):
  return rKNpuHsJvWEBmylXAnikzFaDtgbVoP if __addon__.getSetting('make_bookmark')=='true' else rKNpuHsJvWEBmylXAnikzFaDtgbVcR
 def add_dir(rKNpuHsJvWEBmylXAnikzFaDtgbVPo,label,sublabel='',img='',infoLabels=rKNpuHsJvWEBmylXAnikzFaDtgbVcx,isFolder=rKNpuHsJvWEBmylXAnikzFaDtgbVoP,params='',isLink=rKNpuHsJvWEBmylXAnikzFaDtgbVcR,ContextMenu=rKNpuHsJvWEBmylXAnikzFaDtgbVcx):
  rKNpuHsJvWEBmylXAnikzFaDtgbVqU='%s?%s'%(rKNpuHsJvWEBmylXAnikzFaDtgbVPo._addon_url,urllib.parse.urlencode(params))
  if sublabel:rKNpuHsJvWEBmylXAnikzFaDtgbVqh='%s < %s >'%(label,sublabel)
  else: rKNpuHsJvWEBmylXAnikzFaDtgbVqh=label
  if not img:img='DefaultFolder.png'
  rKNpuHsJvWEBmylXAnikzFaDtgbVqC=xbmcgui.ListItem(rKNpuHsJvWEBmylXAnikzFaDtgbVqh)
  if rKNpuHsJvWEBmylXAnikzFaDtgbVoq(img)==rKNpuHsJvWEBmylXAnikzFaDtgbVoU:
   rKNpuHsJvWEBmylXAnikzFaDtgbVqC.setArt(img)
  else:
   rKNpuHsJvWEBmylXAnikzFaDtgbVqC.setArt({'thumb':img,'poster':img})
  if rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.KodiVersion>=20:
   if infoLabels:rKNpuHsJvWEBmylXAnikzFaDtgbVPo.Set_InfoTag(rKNpuHsJvWEBmylXAnikzFaDtgbVqC.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:rKNpuHsJvWEBmylXAnikzFaDtgbVqC.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   rKNpuHsJvWEBmylXAnikzFaDtgbVqC.setProperty('IsPlayable','true')
  if ContextMenu:rKNpuHsJvWEBmylXAnikzFaDtgbVqC.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(rKNpuHsJvWEBmylXAnikzFaDtgbVPo._addon_handle,rKNpuHsJvWEBmylXAnikzFaDtgbVqU,rKNpuHsJvWEBmylXAnikzFaDtgbVqC,isFolder)
 def Set_InfoTag(rKNpuHsJvWEBmylXAnikzFaDtgbVPo,video_InfoTag:xbmc.InfoTagVideo,rKNpuHsJvWEBmylXAnikzFaDtgbVqj):
  for rKNpuHsJvWEBmylXAnikzFaDtgbVqc,value in rKNpuHsJvWEBmylXAnikzFaDtgbVqj.items():
   if rKNpuHsJvWEBmylXAnikzFaDtgbVPC[rKNpuHsJvWEBmylXAnikzFaDtgbVqc]['type']=='string':
    rKNpuHsJvWEBmylXAnikzFaDtgbVoh(video_InfoTag,rKNpuHsJvWEBmylXAnikzFaDtgbVPC[rKNpuHsJvWEBmylXAnikzFaDtgbVqc]['func'])(value)
   elif rKNpuHsJvWEBmylXAnikzFaDtgbVPC[rKNpuHsJvWEBmylXAnikzFaDtgbVqc]['type']=='int':
    if rKNpuHsJvWEBmylXAnikzFaDtgbVoq(value)==rKNpuHsJvWEBmylXAnikzFaDtgbVoC:
     rKNpuHsJvWEBmylXAnikzFaDtgbVqo=rKNpuHsJvWEBmylXAnikzFaDtgbVoC(value)
    else:
     rKNpuHsJvWEBmylXAnikzFaDtgbVqo=0
    rKNpuHsJvWEBmylXAnikzFaDtgbVoh(video_InfoTag,rKNpuHsJvWEBmylXAnikzFaDtgbVPC[rKNpuHsJvWEBmylXAnikzFaDtgbVqc]['func'])(rKNpuHsJvWEBmylXAnikzFaDtgbVqo)
   elif rKNpuHsJvWEBmylXAnikzFaDtgbVPC[rKNpuHsJvWEBmylXAnikzFaDtgbVqc]['type']=='actor':
    if value!=[]:
     rKNpuHsJvWEBmylXAnikzFaDtgbVoh(video_InfoTag,rKNpuHsJvWEBmylXAnikzFaDtgbVPC[rKNpuHsJvWEBmylXAnikzFaDtgbVqc]['func'])([xbmc.Actor(name)for name in value])
   elif rKNpuHsJvWEBmylXAnikzFaDtgbVPC[rKNpuHsJvWEBmylXAnikzFaDtgbVqc]['type']=='list':
    if rKNpuHsJvWEBmylXAnikzFaDtgbVoq(value)==rKNpuHsJvWEBmylXAnikzFaDtgbVoc:
     rKNpuHsJvWEBmylXAnikzFaDtgbVoh(video_InfoTag,rKNpuHsJvWEBmylXAnikzFaDtgbVPC[rKNpuHsJvWEBmylXAnikzFaDtgbVqc]['func'])(value)
    else:
     rKNpuHsJvWEBmylXAnikzFaDtgbVoh(video_InfoTag,rKNpuHsJvWEBmylXAnikzFaDtgbVPC[rKNpuHsJvWEBmylXAnikzFaDtgbVqc]['func'])([value])
 def dp_Main_List(rKNpuHsJvWEBmylXAnikzFaDtgbVPo,args):
  (rKNpuHsJvWEBmylXAnikzFaDtgbVPS,rKNpuHsJvWEBmylXAnikzFaDtgbVPe,rKNpuHsJvWEBmylXAnikzFaDtgbVPx,rKNpuHsJvWEBmylXAnikzFaDtgbVPR,rKNpuHsJvWEBmylXAnikzFaDtgbVqP)=rKNpuHsJvWEBmylXAnikzFaDtgbVPo.get_settings_totalsearch()
  for rKNpuHsJvWEBmylXAnikzFaDtgbVqw in rKNpuHsJvWEBmylXAnikzFaDtgbVPU:
   rKNpuHsJvWEBmylXAnikzFaDtgbVqh=rKNpuHsJvWEBmylXAnikzFaDtgbVqw.get('title')
   rKNpuHsJvWEBmylXAnikzFaDtgbVqM=''
   if rKNpuHsJvWEBmylXAnikzFaDtgbVqw.get('mode')=='LOCAL_SEARCH' and rKNpuHsJvWEBmylXAnikzFaDtgbVPS ==rKNpuHsJvWEBmylXAnikzFaDtgbVcR:continue
   elif rKNpuHsJvWEBmylXAnikzFaDtgbVqw.get('mode')=='SEARCH_HISTORY' and rKNpuHsJvWEBmylXAnikzFaDtgbVPe==rKNpuHsJvWEBmylXAnikzFaDtgbVcR:continue
   elif rKNpuHsJvWEBmylXAnikzFaDtgbVqw.get('mode')=='TOTAL_SEARCH' and rKNpuHsJvWEBmylXAnikzFaDtgbVPx ==rKNpuHsJvWEBmylXAnikzFaDtgbVcR:continue
   elif rKNpuHsJvWEBmylXAnikzFaDtgbVqw.get('mode')=='TOTAL_HISTORY' and rKNpuHsJvWEBmylXAnikzFaDtgbVPR==rKNpuHsJvWEBmylXAnikzFaDtgbVcR:continue
   elif rKNpuHsJvWEBmylXAnikzFaDtgbVqw.get('mode')=='MENU_BOOKMARK' and rKNpuHsJvWEBmylXAnikzFaDtgbVqP==rKNpuHsJvWEBmylXAnikzFaDtgbVcR:continue
   rKNpuHsJvWEBmylXAnikzFaDtgbVqd={'mode':rKNpuHsJvWEBmylXAnikzFaDtgbVqw.get('mode'),'vType':rKNpuHsJvWEBmylXAnikzFaDtgbVqw.get('vType'),'collectionId':rKNpuHsJvWEBmylXAnikzFaDtgbVqw.get('collectionId'),'page':'1',}
   if rKNpuHsJvWEBmylXAnikzFaDtgbVqw.get('mode')=='LOCAL_SEARCH':rKNpuHsJvWEBmylXAnikzFaDtgbVqd['historyyn']='Y' 
   if rKNpuHsJvWEBmylXAnikzFaDtgbVqw.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    rKNpuHsJvWEBmylXAnikzFaDtgbVqT=rKNpuHsJvWEBmylXAnikzFaDtgbVcR
    rKNpuHsJvWEBmylXAnikzFaDtgbVqI =rKNpuHsJvWEBmylXAnikzFaDtgbVoP
   else:
    rKNpuHsJvWEBmylXAnikzFaDtgbVqT=rKNpuHsJvWEBmylXAnikzFaDtgbVoP
    rKNpuHsJvWEBmylXAnikzFaDtgbVqI =rKNpuHsJvWEBmylXAnikzFaDtgbVcR
   rKNpuHsJvWEBmylXAnikzFaDtgbVqj={'title':rKNpuHsJvWEBmylXAnikzFaDtgbVqh,'plot':rKNpuHsJvWEBmylXAnikzFaDtgbVqh}
   if rKNpuHsJvWEBmylXAnikzFaDtgbVqw.get('mode')=='XXX':rKNpuHsJvWEBmylXAnikzFaDtgbVqj=rKNpuHsJvWEBmylXAnikzFaDtgbVcx
   if 'icon' in rKNpuHsJvWEBmylXAnikzFaDtgbVqw:rKNpuHsJvWEBmylXAnikzFaDtgbVqM=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',rKNpuHsJvWEBmylXAnikzFaDtgbVqw.get('icon')) 
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.add_dir(rKNpuHsJvWEBmylXAnikzFaDtgbVqh,sublabel='',img=rKNpuHsJvWEBmylXAnikzFaDtgbVqM,infoLabels=rKNpuHsJvWEBmylXAnikzFaDtgbVqj,isFolder=rKNpuHsJvWEBmylXAnikzFaDtgbVqT,params=rKNpuHsJvWEBmylXAnikzFaDtgbVqd,isLink=rKNpuHsJvWEBmylXAnikzFaDtgbVqI)
  xbmcplugin.endOfDirectory(rKNpuHsJvWEBmylXAnikzFaDtgbVPo._addon_handle)
 def dp_Test(rKNpuHsJvWEBmylXAnikzFaDtgbVPo,args):
  rKNpuHsJvWEBmylXAnikzFaDtgbVPo.addon_noti('test')
 def CP_logout(rKNpuHsJvWEBmylXAnikzFaDtgbVPo):
  rKNpuHsJvWEBmylXAnikzFaDtgbVPI=xbmcgui.Dialog()
  rKNpuHsJvWEBmylXAnikzFaDtgbVqO=rKNpuHsJvWEBmylXAnikzFaDtgbVPI.yesno(__language__(30905).encode('utf8'),__language__(30906).encode('utf8'))
  if rKNpuHsJvWEBmylXAnikzFaDtgbVqO==rKNpuHsJvWEBmylXAnikzFaDtgbVcR:return 
  if os.path.isfile(rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.CP_COOKIE_FILENAME):os.remove(rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.CP_COOKIE_FILENAME)
  rKNpuHsJvWEBmylXAnikzFaDtgbVPo.addon_noti(__language__(30904).encode('utf-8'))
 def option_check(rKNpuHsJvWEBmylXAnikzFaDtgbVPo):
  (rKNpuHsJvWEBmylXAnikzFaDtgbVPG,rKNpuHsJvWEBmylXAnikzFaDtgbVPf,rKNpuHsJvWEBmylXAnikzFaDtgbVPQ)=rKNpuHsJvWEBmylXAnikzFaDtgbVPo.get_settings_account()
  if rKNpuHsJvWEBmylXAnikzFaDtgbVPG=='' or rKNpuHsJvWEBmylXAnikzFaDtgbVPf=='':
   rKNpuHsJvWEBmylXAnikzFaDtgbVPI=xbmcgui.Dialog()
   rKNpuHsJvWEBmylXAnikzFaDtgbVqO=rKNpuHsJvWEBmylXAnikzFaDtgbVPI.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if rKNpuHsJvWEBmylXAnikzFaDtgbVqO==rKNpuHsJvWEBmylXAnikzFaDtgbVoP:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if rKNpuHsJvWEBmylXAnikzFaDtgbVPo.cookiefile_check()==rKNpuHsJvWEBmylXAnikzFaDtgbVcR:
   if rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CP_login(rKNpuHsJvWEBmylXAnikzFaDtgbVPG,rKNpuHsJvWEBmylXAnikzFaDtgbVPf,rKNpuHsJvWEBmylXAnikzFaDtgbVPQ)==rKNpuHsJvWEBmylXAnikzFaDtgbVcR:
    rKNpuHsJvWEBmylXAnikzFaDtgbVPo.addon_noti(__language__(30903).encode('utf8'))
    sys.exit()
  else:
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.Get_CP_profile(rKNpuHsJvWEBmylXAnikzFaDtgbVPQ,limit_days=rKNpuHsJvWEBmylXAnikzFaDtgbVoC(__addon__.getSetting('cache_ttl')),re_check=rKNpuHsJvWEBmylXAnikzFaDtgbVoP)
 def cookiefile_check(rKNpuHsJvWEBmylXAnikzFaDtgbVPo):
  rKNpuHsJvWEBmylXAnikzFaDtgbVqf={}
  try: 
   fp=rKNpuHsJvWEBmylXAnikzFaDtgbVow(rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.CP_COOKIE_FILENAME,'r',-1,'utf-8')
   rKNpuHsJvWEBmylXAnikzFaDtgbVqf= json.load(fp)
   fp.close()
  except rKNpuHsJvWEBmylXAnikzFaDtgbVoM as exception:
   return rKNpuHsJvWEBmylXAnikzFaDtgbVcR
  rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.CP=rKNpuHsJvWEBmylXAnikzFaDtgbVqf
  (rKNpuHsJvWEBmylXAnikzFaDtgbVPG,rKNpuHsJvWEBmylXAnikzFaDtgbVPf,rKNpuHsJvWEBmylXAnikzFaDtgbVPQ)=rKNpuHsJvWEBmylXAnikzFaDtgbVPo.get_settings_account()
  (rKNpuHsJvWEBmylXAnikzFaDtgbVqQ,rKNpuHsJvWEBmylXAnikzFaDtgbVqY,rKNpuHsJvWEBmylXAnikzFaDtgbVqS)=rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.Load_session_acount()
  if rKNpuHsJvWEBmylXAnikzFaDtgbVPG!=rKNpuHsJvWEBmylXAnikzFaDtgbVqQ or rKNpuHsJvWEBmylXAnikzFaDtgbVPf!=rKNpuHsJvWEBmylXAnikzFaDtgbVqY or rKNpuHsJvWEBmylXAnikzFaDtgbVPQ!=rKNpuHsJvWEBmylXAnikzFaDtgbVod(rKNpuHsJvWEBmylXAnikzFaDtgbVqS):
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.Init_CP()
   return rKNpuHsJvWEBmylXAnikzFaDtgbVcR
  rKNpuHsJvWEBmylXAnikzFaDtgbVqe =rKNpuHsJvWEBmylXAnikzFaDtgbVoC(rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.Get_Now_Datetime().strftime('%Y%m%d'))
  rKNpuHsJvWEBmylXAnikzFaDtgbVqx=rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.CP['SESSION']['limitdate']
  rKNpuHsJvWEBmylXAnikzFaDtgbVqR =rKNpuHsJvWEBmylXAnikzFaDtgbVoC(re.sub('-','',rKNpuHsJvWEBmylXAnikzFaDtgbVqx))
  if rKNpuHsJvWEBmylXAnikzFaDtgbVqR<rKNpuHsJvWEBmylXAnikzFaDtgbVqe:
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.Init_CP()
   return rKNpuHsJvWEBmylXAnikzFaDtgbVcR
  return rKNpuHsJvWEBmylXAnikzFaDtgbVoP
 def CP_login(rKNpuHsJvWEBmylXAnikzFaDtgbVPo,rKNpuHsJvWEBmylXAnikzFaDtgbVPG,rKNpuHsJvWEBmylXAnikzFaDtgbVPf,rKNpuHsJvWEBmylXAnikzFaDtgbVPQ):
  if rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.Get_CP_Login(rKNpuHsJvWEBmylXAnikzFaDtgbVPG,rKNpuHsJvWEBmylXAnikzFaDtgbVPf,rKNpuHsJvWEBmylXAnikzFaDtgbVPQ)==rKNpuHsJvWEBmylXAnikzFaDtgbVcR:return rKNpuHsJvWEBmylXAnikzFaDtgbVcR
  if rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.Get_CP_profile(rKNpuHsJvWEBmylXAnikzFaDtgbVPQ,limit_days=rKNpuHsJvWEBmylXAnikzFaDtgbVoC(__addon__.getSetting('cache_ttl')),re_check=rKNpuHsJvWEBmylXAnikzFaDtgbVcR)==rKNpuHsJvWEBmylXAnikzFaDtgbVcR:return rKNpuHsJvWEBmylXAnikzFaDtgbVcR
  return rKNpuHsJvWEBmylXAnikzFaDtgbVoP
 def dp_Category_GroupList(rKNpuHsJvWEBmylXAnikzFaDtgbVPo,args):
  rKNpuHsJvWEBmylXAnikzFaDtgbVUP =args.get('vType') 
  rKNpuHsJvWEBmylXAnikzFaDtgbVUq=rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.Get_Category_GroupList(rKNpuHsJvWEBmylXAnikzFaDtgbVUP)
  for rKNpuHsJvWEBmylXAnikzFaDtgbVUh in rKNpuHsJvWEBmylXAnikzFaDtgbVUq:
   rKNpuHsJvWEBmylXAnikzFaDtgbVqh =rKNpuHsJvWEBmylXAnikzFaDtgbVUh.get('title')
   rKNpuHsJvWEBmylXAnikzFaDtgbVUC=rKNpuHsJvWEBmylXAnikzFaDtgbVUh.get('pre_title')
   if rKNpuHsJvWEBmylXAnikzFaDtgbVPo.get_settings_exclusion21()==rKNpuHsJvWEBmylXAnikzFaDtgbVoP and rKNpuHsJvWEBmylXAnikzFaDtgbVqh=='성인':continue
   rKNpuHsJvWEBmylXAnikzFaDtgbVUc={'mediatype':'tvshow','plot':rKNpuHsJvWEBmylXAnikzFaDtgbVUC,}
   rKNpuHsJvWEBmylXAnikzFaDtgbVqd={'mode':'CATEGORY_LIST','collectionId':rKNpuHsJvWEBmylXAnikzFaDtgbVUh.get('collectionId'),'vType':rKNpuHsJvWEBmylXAnikzFaDtgbVUh.get('category'),'page':'1',}
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.add_dir(rKNpuHsJvWEBmylXAnikzFaDtgbVqh,sublabel='',img='',infoLabels=rKNpuHsJvWEBmylXAnikzFaDtgbVUc,isFolder=rKNpuHsJvWEBmylXAnikzFaDtgbVoP,params=rKNpuHsJvWEBmylXAnikzFaDtgbVqd)
  xbmcplugin.endOfDirectory(rKNpuHsJvWEBmylXAnikzFaDtgbVPo._addon_handle,cacheToDisc=rKNpuHsJvWEBmylXAnikzFaDtgbVcR)
 def dp_Theme_GroupList(rKNpuHsJvWEBmylXAnikzFaDtgbVPo,args):
  rKNpuHsJvWEBmylXAnikzFaDtgbVUP =args.get('vType') 
  rKNpuHsJvWEBmylXAnikzFaDtgbVUq=rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.Get_Theme_GroupList(rKNpuHsJvWEBmylXAnikzFaDtgbVUP)
  for rKNpuHsJvWEBmylXAnikzFaDtgbVUh in rKNpuHsJvWEBmylXAnikzFaDtgbVUq:
   rKNpuHsJvWEBmylXAnikzFaDtgbVqh =rKNpuHsJvWEBmylXAnikzFaDtgbVUh.get('title')
   rKNpuHsJvWEBmylXAnikzFaDtgbVUC=rKNpuHsJvWEBmylXAnikzFaDtgbVUh.get('pre_title')
   rKNpuHsJvWEBmylXAnikzFaDtgbVUc={'mediatype':'tvshow','plot':rKNpuHsJvWEBmylXAnikzFaDtgbVUC,}
   rKNpuHsJvWEBmylXAnikzFaDtgbVqd={'mode':'CATEGORY_LIST','collectionId':rKNpuHsJvWEBmylXAnikzFaDtgbVUh.get('collectionId'),'vType':rKNpuHsJvWEBmylXAnikzFaDtgbVUh.get('category'),'page':'1',}
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.add_dir(rKNpuHsJvWEBmylXAnikzFaDtgbVqh,sublabel='',img='',infoLabels=rKNpuHsJvWEBmylXAnikzFaDtgbVUc,isFolder=rKNpuHsJvWEBmylXAnikzFaDtgbVoP,params=rKNpuHsJvWEBmylXAnikzFaDtgbVqd)
  xbmcplugin.endOfDirectory(rKNpuHsJvWEBmylXAnikzFaDtgbVPo._addon_handle,cacheToDisc=rKNpuHsJvWEBmylXAnikzFaDtgbVcR)
 def dp_Event_GroupList(rKNpuHsJvWEBmylXAnikzFaDtgbVPo,args):
  rKNpuHsJvWEBmylXAnikzFaDtgbVUq=rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.Get_Event_GroupList()
  for rKNpuHsJvWEBmylXAnikzFaDtgbVUh in rKNpuHsJvWEBmylXAnikzFaDtgbVUq:
   rKNpuHsJvWEBmylXAnikzFaDtgbVqh =rKNpuHsJvWEBmylXAnikzFaDtgbVUh.get('title')
   rKNpuHsJvWEBmylXAnikzFaDtgbVUC=rKNpuHsJvWEBmylXAnikzFaDtgbVUh.get('pre_title')
   rKNpuHsJvWEBmylXAnikzFaDtgbVUc={'mediatype':'tvshow','plot':rKNpuHsJvWEBmylXAnikzFaDtgbVUC,}
   rKNpuHsJvWEBmylXAnikzFaDtgbVqd={'mode':'EVENT_GAMELIST','collectionId':rKNpuHsJvWEBmylXAnikzFaDtgbVUh.get('collectionId'),'vType':'LIVE',}
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.add_dir(rKNpuHsJvWEBmylXAnikzFaDtgbVqh,sublabel='',img='',infoLabels=rKNpuHsJvWEBmylXAnikzFaDtgbVUc,isFolder=rKNpuHsJvWEBmylXAnikzFaDtgbVoP,params=rKNpuHsJvWEBmylXAnikzFaDtgbVqd)
  xbmcplugin.endOfDirectory(rKNpuHsJvWEBmylXAnikzFaDtgbVPo._addon_handle,cacheToDisc=rKNpuHsJvWEBmylXAnikzFaDtgbVcR)
 def dp_Event_GameList(rKNpuHsJvWEBmylXAnikzFaDtgbVPo,args):
  rKNpuHsJvWEBmylXAnikzFaDtgbVUP =args.get('vType') 
  rKNpuHsJvWEBmylXAnikzFaDtgbVUw =args.get('collectionId')
  rKNpuHsJvWEBmylXAnikzFaDtgbVUq=rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.Get_Event_GameList(rKNpuHsJvWEBmylXAnikzFaDtgbVUw)
  for rKNpuHsJvWEBmylXAnikzFaDtgbVUh in rKNpuHsJvWEBmylXAnikzFaDtgbVUq:
   rKNpuHsJvWEBmylXAnikzFaDtgbVqh =rKNpuHsJvWEBmylXAnikzFaDtgbVUh.get('title')
   rKNpuHsJvWEBmylXAnikzFaDtgbVoT =rKNpuHsJvWEBmylXAnikzFaDtgbVUh.get('id')
   rKNpuHsJvWEBmylXAnikzFaDtgbVUM =rKNpuHsJvWEBmylXAnikzFaDtgbVUh.get('thumbnail')
   rKNpuHsJvWEBmylXAnikzFaDtgbVUd =rKNpuHsJvWEBmylXAnikzFaDtgbVUh.get('asis') 
   rKNpuHsJvWEBmylXAnikzFaDtgbVUT =rKNpuHsJvWEBmylXAnikzFaDtgbVUh.get('addInfo')
   rKNpuHsJvWEBmylXAnikzFaDtgbVUI =rKNpuHsJvWEBmylXAnikzFaDtgbVUh.get('starttm')
   rKNpuHsJvWEBmylXAnikzFaDtgbVUc={'mediatype':'tvshow','title':rKNpuHsJvWEBmylXAnikzFaDtgbVqh,'plot':rKNpuHsJvWEBmylXAnikzFaDtgbVUT,}
   rKNpuHsJvWEBmylXAnikzFaDtgbVqd={'mode':'EVENT_LIST','id':rKNpuHsJvWEBmylXAnikzFaDtgbVoT,'asis':rKNpuHsJvWEBmylXAnikzFaDtgbVUd,'title':rKNpuHsJvWEBmylXAnikzFaDtgbVqh,}
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.add_dir(rKNpuHsJvWEBmylXAnikzFaDtgbVqh,sublabel=rKNpuHsJvWEBmylXAnikzFaDtgbVUI,img=rKNpuHsJvWEBmylXAnikzFaDtgbVUM,infoLabels=rKNpuHsJvWEBmylXAnikzFaDtgbVUc,isFolder=rKNpuHsJvWEBmylXAnikzFaDtgbVoP,params=rKNpuHsJvWEBmylXAnikzFaDtgbVqd,ContextMenu=rKNpuHsJvWEBmylXAnikzFaDtgbVcx)
  xbmcplugin.setContent(rKNpuHsJvWEBmylXAnikzFaDtgbVPo._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(rKNpuHsJvWEBmylXAnikzFaDtgbVPo._addon_handle,cacheToDisc=rKNpuHsJvWEBmylXAnikzFaDtgbVcR)
 def dp_Event_List(rKNpuHsJvWEBmylXAnikzFaDtgbVPo,args):
  rKNpuHsJvWEBmylXAnikzFaDtgbVUj=args.get('id')
  rKNpuHsJvWEBmylXAnikzFaDtgbVUq=rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.Get_Event_List(rKNpuHsJvWEBmylXAnikzFaDtgbVUj)
  for rKNpuHsJvWEBmylXAnikzFaDtgbVUh in rKNpuHsJvWEBmylXAnikzFaDtgbVUq:
   rKNpuHsJvWEBmylXAnikzFaDtgbVqh =rKNpuHsJvWEBmylXAnikzFaDtgbVUh.get('title')
   rKNpuHsJvWEBmylXAnikzFaDtgbVoT =rKNpuHsJvWEBmylXAnikzFaDtgbVUh.get('id')
   rKNpuHsJvWEBmylXAnikzFaDtgbVUM =rKNpuHsJvWEBmylXAnikzFaDtgbVUh.get('thumbnail')
   rKNpuHsJvWEBmylXAnikzFaDtgbVUd =rKNpuHsJvWEBmylXAnikzFaDtgbVUh.get('asis') 
   rKNpuHsJvWEBmylXAnikzFaDtgbVUL =rKNpuHsJvWEBmylXAnikzFaDtgbVUh.get('duration')
   rKNpuHsJvWEBmylXAnikzFaDtgbVUI =rKNpuHsJvWEBmylXAnikzFaDtgbVUh.get('starttm')
   rKNpuHsJvWEBmylXAnikzFaDtgbVUc={'mediatype':'episode','title':rKNpuHsJvWEBmylXAnikzFaDtgbVqh,'plot':rKNpuHsJvWEBmylXAnikzFaDtgbVUd,'duration':rKNpuHsJvWEBmylXAnikzFaDtgbVUL,}
   rKNpuHsJvWEBmylXAnikzFaDtgbVqd={'mode':rKNpuHsJvWEBmylXAnikzFaDtgbVUd,'id':rKNpuHsJvWEBmylXAnikzFaDtgbVoT,'asis':rKNpuHsJvWEBmylXAnikzFaDtgbVUd,'title':rKNpuHsJvWEBmylXAnikzFaDtgbVqh,}
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.add_dir(rKNpuHsJvWEBmylXAnikzFaDtgbVqh,sublabel=rKNpuHsJvWEBmylXAnikzFaDtgbVUI,img=rKNpuHsJvWEBmylXAnikzFaDtgbVUM,infoLabels=rKNpuHsJvWEBmylXAnikzFaDtgbVUc,isFolder=rKNpuHsJvWEBmylXAnikzFaDtgbVcR,params=rKNpuHsJvWEBmylXAnikzFaDtgbVqd,ContextMenu=rKNpuHsJvWEBmylXAnikzFaDtgbVcx)
  xbmcplugin.setContent(rKNpuHsJvWEBmylXAnikzFaDtgbVPo._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(rKNpuHsJvWEBmylXAnikzFaDtgbVPo._addon_handle,cacheToDisc=rKNpuHsJvWEBmylXAnikzFaDtgbVcR)
 def dp_Category_List(rKNpuHsJvWEBmylXAnikzFaDtgbVPo,args):
  rKNpuHsJvWEBmylXAnikzFaDtgbVUP =args.get('vType') 
  rKNpuHsJvWEBmylXAnikzFaDtgbVUw =args.get('collectionId')
  rKNpuHsJvWEBmylXAnikzFaDtgbVUO =rKNpuHsJvWEBmylXAnikzFaDtgbVoC(args.get('page'))
  rKNpuHsJvWEBmylXAnikzFaDtgbVUq,rKNpuHsJvWEBmylXAnikzFaDtgbVUG=rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.Get_Category_List(rKNpuHsJvWEBmylXAnikzFaDtgbVUP,rKNpuHsJvWEBmylXAnikzFaDtgbVUw,rKNpuHsJvWEBmylXAnikzFaDtgbVUO)
  for rKNpuHsJvWEBmylXAnikzFaDtgbVUh in rKNpuHsJvWEBmylXAnikzFaDtgbVUq:
   rKNpuHsJvWEBmylXAnikzFaDtgbVqh =rKNpuHsJvWEBmylXAnikzFaDtgbVUh.get('title')
   rKNpuHsJvWEBmylXAnikzFaDtgbVoT =rKNpuHsJvWEBmylXAnikzFaDtgbVUh.get('id')
   rKNpuHsJvWEBmylXAnikzFaDtgbVUM =rKNpuHsJvWEBmylXAnikzFaDtgbVUh.get('thumbnail')
   rKNpuHsJvWEBmylXAnikzFaDtgbVUf =rKNpuHsJvWEBmylXAnikzFaDtgbVUh.get('mpaa')
   rKNpuHsJvWEBmylXAnikzFaDtgbVUL =rKNpuHsJvWEBmylXAnikzFaDtgbVUh.get('duration')
   rKNpuHsJvWEBmylXAnikzFaDtgbVUd =rKNpuHsJvWEBmylXAnikzFaDtgbVUh.get('asis')
   rKNpuHsJvWEBmylXAnikzFaDtgbVUQ =rKNpuHsJvWEBmylXAnikzFaDtgbVUh.get('badge')
   rKNpuHsJvWEBmylXAnikzFaDtgbVUY =rKNpuHsJvWEBmylXAnikzFaDtgbVUh.get('year')
   rKNpuHsJvWEBmylXAnikzFaDtgbVUS=rKNpuHsJvWEBmylXAnikzFaDtgbVUh.get('seasonList')
   rKNpuHsJvWEBmylXAnikzFaDtgbVUe =rKNpuHsJvWEBmylXAnikzFaDtgbVUh.get('genreList')
   if rKNpuHsJvWEBmylXAnikzFaDtgbVUd in['TVSHOW','EDUCATION']: 
    rKNpuHsJvWEBmylXAnikzFaDtgbVUx ='SEASON_LIST'
    rKNpuHsJvWEBmylXAnikzFaDtgbVUc={'mediatype':'tvshow','title':rKNpuHsJvWEBmylXAnikzFaDtgbVqh,'mpaa':rKNpuHsJvWEBmylXAnikzFaDtgbVUf,'genre':rKNpuHsJvWEBmylXAnikzFaDtgbVUe,'year':rKNpuHsJvWEBmylXAnikzFaDtgbVUY,'plot':'Year : %s\nSeason : %s'%(rKNpuHsJvWEBmylXAnikzFaDtgbVUY,rKNpuHsJvWEBmylXAnikzFaDtgbVUS),}
    rKNpuHsJvWEBmylXAnikzFaDtgbVqT =rKNpuHsJvWEBmylXAnikzFaDtgbVoP
   else:
    rKNpuHsJvWEBmylXAnikzFaDtgbVUx ='MOVIE'
    rKNpuHsJvWEBmylXAnikzFaDtgbVUc={'mediatype':'movie','title':rKNpuHsJvWEBmylXAnikzFaDtgbVqh,'mpaa':rKNpuHsJvWEBmylXAnikzFaDtgbVUf,'genre':rKNpuHsJvWEBmylXAnikzFaDtgbVUe,'duration':rKNpuHsJvWEBmylXAnikzFaDtgbVUL,'year':rKNpuHsJvWEBmylXAnikzFaDtgbVUY,'plot':'(%s)'%(rKNpuHsJvWEBmylXAnikzFaDtgbVUf),}
    rKNpuHsJvWEBmylXAnikzFaDtgbVqT =rKNpuHsJvWEBmylXAnikzFaDtgbVcR
    rKNpuHsJvWEBmylXAnikzFaDtgbVqh +=' (%s)'%(rKNpuHsJvWEBmylXAnikzFaDtgbVod(rKNpuHsJvWEBmylXAnikzFaDtgbVUY))
   rKNpuHsJvWEBmylXAnikzFaDtgbVqd={'mode':rKNpuHsJvWEBmylXAnikzFaDtgbVUx,'id':rKNpuHsJvWEBmylXAnikzFaDtgbVoT,'asis':rKNpuHsJvWEBmylXAnikzFaDtgbVUd,'seasonList':rKNpuHsJvWEBmylXAnikzFaDtgbVUS,'title':rKNpuHsJvWEBmylXAnikzFaDtgbVqh,'thumbnail':rKNpuHsJvWEBmylXAnikzFaDtgbVUM,'year':rKNpuHsJvWEBmylXAnikzFaDtgbVUY,}
   if rKNpuHsJvWEBmylXAnikzFaDtgbVPo.get_settings_makebookmark():
    rKNpuHsJvWEBmylXAnikzFaDtgbVUR={'videoid':rKNpuHsJvWEBmylXAnikzFaDtgbVoT,'vidtype':'movie' if rKNpuHsJvWEBmylXAnikzFaDtgbVUP=='MOVIES' else 'tvshow','vtitle':rKNpuHsJvWEBmylXAnikzFaDtgbVqh,'vsubtitle':'',}
    rKNpuHsJvWEBmylXAnikzFaDtgbVhP=json.dumps(rKNpuHsJvWEBmylXAnikzFaDtgbVUR)
    rKNpuHsJvWEBmylXAnikzFaDtgbVhP=urllib.parse.quote(rKNpuHsJvWEBmylXAnikzFaDtgbVhP)
    rKNpuHsJvWEBmylXAnikzFaDtgbVhq='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(rKNpuHsJvWEBmylXAnikzFaDtgbVhP)
    rKNpuHsJvWEBmylXAnikzFaDtgbVhU=[('(통합) 찜 영상에 추가',rKNpuHsJvWEBmylXAnikzFaDtgbVhq)]
   else:
    rKNpuHsJvWEBmylXAnikzFaDtgbVhU=rKNpuHsJvWEBmylXAnikzFaDtgbVcx
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.add_dir(rKNpuHsJvWEBmylXAnikzFaDtgbVqh,sublabel=rKNpuHsJvWEBmylXAnikzFaDtgbVUQ,img=rKNpuHsJvWEBmylXAnikzFaDtgbVUM,infoLabels=rKNpuHsJvWEBmylXAnikzFaDtgbVUc,isFolder=rKNpuHsJvWEBmylXAnikzFaDtgbVqT,params=rKNpuHsJvWEBmylXAnikzFaDtgbVqd,ContextMenu=rKNpuHsJvWEBmylXAnikzFaDtgbVhU)
  if rKNpuHsJvWEBmylXAnikzFaDtgbVUG:
   rKNpuHsJvWEBmylXAnikzFaDtgbVqd['mode'] ='CATEGORY_LIST' 
   rKNpuHsJvWEBmylXAnikzFaDtgbVqd['collectionId']=rKNpuHsJvWEBmylXAnikzFaDtgbVUw 
   rKNpuHsJvWEBmylXAnikzFaDtgbVqd['vType'] =rKNpuHsJvWEBmylXAnikzFaDtgbVUP 
   rKNpuHsJvWEBmylXAnikzFaDtgbVqd['page'] =rKNpuHsJvWEBmylXAnikzFaDtgbVod(rKNpuHsJvWEBmylXAnikzFaDtgbVUO+1)
   rKNpuHsJvWEBmylXAnikzFaDtgbVqh='[B]%s >>[/B]'%'다음 페이지'
   rKNpuHsJvWEBmylXAnikzFaDtgbVhC=rKNpuHsJvWEBmylXAnikzFaDtgbVod(rKNpuHsJvWEBmylXAnikzFaDtgbVUO+1)
   rKNpuHsJvWEBmylXAnikzFaDtgbVqM=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.add_dir(rKNpuHsJvWEBmylXAnikzFaDtgbVqh,sublabel=rKNpuHsJvWEBmylXAnikzFaDtgbVhC,img=rKNpuHsJvWEBmylXAnikzFaDtgbVqM,infoLabels=rKNpuHsJvWEBmylXAnikzFaDtgbVcx,isFolder=rKNpuHsJvWEBmylXAnikzFaDtgbVoP,params=rKNpuHsJvWEBmylXAnikzFaDtgbVqd)
  if rKNpuHsJvWEBmylXAnikzFaDtgbVUP=='TVSHOWS':xbmcplugin.setContent(rKNpuHsJvWEBmylXAnikzFaDtgbVPo._addon_handle,'tvshows')
  else:xbmcplugin.setContent(rKNpuHsJvWEBmylXAnikzFaDtgbVPo._addon_handle,'movies')
  xbmcplugin.endOfDirectory(rKNpuHsJvWEBmylXAnikzFaDtgbVPo._addon_handle,cacheToDisc=rKNpuHsJvWEBmylXAnikzFaDtgbVcR)
 def dp_Season_List(rKNpuHsJvWEBmylXAnikzFaDtgbVPo,args):
  rKNpuHsJvWEBmylXAnikzFaDtgbVhc =args.get('title')
  rKNpuHsJvWEBmylXAnikzFaDtgbVho =args.get('id')
  rKNpuHsJvWEBmylXAnikzFaDtgbVUd =args.get('asis')
  rKNpuHsJvWEBmylXAnikzFaDtgbVUS =args.get('seasonList')
  rKNpuHsJvWEBmylXAnikzFaDtgbVUM =args.get('thumbnail')
  rKNpuHsJvWEBmylXAnikzFaDtgbVUY =args.get('year')
  if rKNpuHsJvWEBmylXAnikzFaDtgbVUS in['',rKNpuHsJvWEBmylXAnikzFaDtgbVcx]:
   rKNpuHsJvWEBmylXAnikzFaDtgbVUS=rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.Get_vInfo(rKNpuHsJvWEBmylXAnikzFaDtgbVho).get('seasonList')
  if rKNpuHsJvWEBmylXAnikzFaDtgbVoI(rKNpuHsJvWEBmylXAnikzFaDtgbVUS.split(','))>1:
   for rKNpuHsJvWEBmylXAnikzFaDtgbVhw in rKNpuHsJvWEBmylXAnikzFaDtgbVUS.split(','):
    rKNpuHsJvWEBmylXAnikzFaDtgbVqh='시즌 '+rKNpuHsJvWEBmylXAnikzFaDtgbVhw
    rKNpuHsJvWEBmylXAnikzFaDtgbVUc={'mediatype':'tvshow','plot':'%s (%s)'%(rKNpuHsJvWEBmylXAnikzFaDtgbVhc,rKNpuHsJvWEBmylXAnikzFaDtgbVUY),}
    rKNpuHsJvWEBmylXAnikzFaDtgbVqd={'mode':'EPISODE_LIST','programid':rKNpuHsJvWEBmylXAnikzFaDtgbVho,'programnm':rKNpuHsJvWEBmylXAnikzFaDtgbVhc,'season':rKNpuHsJvWEBmylXAnikzFaDtgbVhw,'asis':rKNpuHsJvWEBmylXAnikzFaDtgbVUd,'programimg':rKNpuHsJvWEBmylXAnikzFaDtgbVUM,}
    rKNpuHsJvWEBmylXAnikzFaDtgbVhM=rKNpuHsJvWEBmylXAnikzFaDtgbVUM.replace('\'','\"')
    rKNpuHsJvWEBmylXAnikzFaDtgbVhM=json.loads(rKNpuHsJvWEBmylXAnikzFaDtgbVhM)
    rKNpuHsJvWEBmylXAnikzFaDtgbVPo.add_dir(rKNpuHsJvWEBmylXAnikzFaDtgbVqh,sublabel='',img=rKNpuHsJvWEBmylXAnikzFaDtgbVhM,infoLabels=rKNpuHsJvWEBmylXAnikzFaDtgbVUc,isFolder=rKNpuHsJvWEBmylXAnikzFaDtgbVoP,params=rKNpuHsJvWEBmylXAnikzFaDtgbVqd)
   xbmcplugin.setContent(rKNpuHsJvWEBmylXAnikzFaDtgbVPo._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(rKNpuHsJvWEBmylXAnikzFaDtgbVPo._addon_handle,cacheToDisc=rKNpuHsJvWEBmylXAnikzFaDtgbVcR)
  else:
   rKNpuHsJvWEBmylXAnikzFaDtgbVhd={'programid':rKNpuHsJvWEBmylXAnikzFaDtgbVho,'programnm':rKNpuHsJvWEBmylXAnikzFaDtgbVhc,'season':rKNpuHsJvWEBmylXAnikzFaDtgbVUS,'programimg':rKNpuHsJvWEBmylXAnikzFaDtgbVUM,}
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.dp_Episode_List(rKNpuHsJvWEBmylXAnikzFaDtgbVhd)
 def dp_Episode_List(rKNpuHsJvWEBmylXAnikzFaDtgbVPo,args):
  rKNpuHsJvWEBmylXAnikzFaDtgbVho =args.get('programid')
  rKNpuHsJvWEBmylXAnikzFaDtgbVhc =args.get('programnm')
  rKNpuHsJvWEBmylXAnikzFaDtgbVhT =args.get('season')
  rKNpuHsJvWEBmylXAnikzFaDtgbVhI =args.get('programimg')
  rKNpuHsJvWEBmylXAnikzFaDtgbVhj=rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.Get_Episode_List(rKNpuHsJvWEBmylXAnikzFaDtgbVho,rKNpuHsJvWEBmylXAnikzFaDtgbVhT)
  for rKNpuHsJvWEBmylXAnikzFaDtgbVhw in rKNpuHsJvWEBmylXAnikzFaDtgbVhj:
   rKNpuHsJvWEBmylXAnikzFaDtgbVhL =rKNpuHsJvWEBmylXAnikzFaDtgbVhw.get('title')
   rKNpuHsJvWEBmylXAnikzFaDtgbVhO =rKNpuHsJvWEBmylXAnikzFaDtgbVhw.get('id')
   rKNpuHsJvWEBmylXAnikzFaDtgbVUd =rKNpuHsJvWEBmylXAnikzFaDtgbVhw.get('asis')
   rKNpuHsJvWEBmylXAnikzFaDtgbVUM =rKNpuHsJvWEBmylXAnikzFaDtgbVhw.get('thumbnail')
   rKNpuHsJvWEBmylXAnikzFaDtgbVUf =rKNpuHsJvWEBmylXAnikzFaDtgbVhw.get('mpaa')
   rKNpuHsJvWEBmylXAnikzFaDtgbVUL =rKNpuHsJvWEBmylXAnikzFaDtgbVhw.get('duration')
   rKNpuHsJvWEBmylXAnikzFaDtgbVUY =rKNpuHsJvWEBmylXAnikzFaDtgbVhw.get('year')
   rKNpuHsJvWEBmylXAnikzFaDtgbVhG =rKNpuHsJvWEBmylXAnikzFaDtgbVhw.get('episode')
   rKNpuHsJvWEBmylXAnikzFaDtgbVUe =rKNpuHsJvWEBmylXAnikzFaDtgbVhw.get('genreList')
   rKNpuHsJvWEBmylXAnikzFaDtgbVhf =rKNpuHsJvWEBmylXAnikzFaDtgbVhw.get('desc')
   rKNpuHsJvWEBmylXAnikzFaDtgbVhQ ='%sx%s'%(rKNpuHsJvWEBmylXAnikzFaDtgbVhT,rKNpuHsJvWEBmylXAnikzFaDtgbVhG)
   rKNpuHsJvWEBmylXAnikzFaDtgbVqh ='%s. %s'%(rKNpuHsJvWEBmylXAnikzFaDtgbVhQ,rKNpuHsJvWEBmylXAnikzFaDtgbVhL)
   rKNpuHsJvWEBmylXAnikzFaDtgbVUc={'mediatype':'episode','mpaa':rKNpuHsJvWEBmylXAnikzFaDtgbVUf,'genre':rKNpuHsJvWEBmylXAnikzFaDtgbVUe,'duration':rKNpuHsJvWEBmylXAnikzFaDtgbVUL,'year':rKNpuHsJvWEBmylXAnikzFaDtgbVUY,'plot':'%s (%s)\n\n%s'%(rKNpuHsJvWEBmylXAnikzFaDtgbVhc,rKNpuHsJvWEBmylXAnikzFaDtgbVhQ,rKNpuHsJvWEBmylXAnikzFaDtgbVhf),}
   rKNpuHsJvWEBmylXAnikzFaDtgbVqd={'mode':'VOD','programid':rKNpuHsJvWEBmylXAnikzFaDtgbVho,'programnm':rKNpuHsJvWEBmylXAnikzFaDtgbVhc,'title':rKNpuHsJvWEBmylXAnikzFaDtgbVqh,'season':rKNpuHsJvWEBmylXAnikzFaDtgbVhT,'id':rKNpuHsJvWEBmylXAnikzFaDtgbVhO,'asis':rKNpuHsJvWEBmylXAnikzFaDtgbVUd,'thumbnail':rKNpuHsJvWEBmylXAnikzFaDtgbVUM,'programimg':rKNpuHsJvWEBmylXAnikzFaDtgbVhI,}
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.add_dir(rKNpuHsJvWEBmylXAnikzFaDtgbVqh,sublabel='',img=rKNpuHsJvWEBmylXAnikzFaDtgbVUM,infoLabels=rKNpuHsJvWEBmylXAnikzFaDtgbVUc,isFolder=rKNpuHsJvWEBmylXAnikzFaDtgbVcR,params=rKNpuHsJvWEBmylXAnikzFaDtgbVqd)
  xbmcplugin.setContent(rKNpuHsJvWEBmylXAnikzFaDtgbVPo._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(rKNpuHsJvWEBmylXAnikzFaDtgbVPo._addon_handle,cacheToDisc=rKNpuHsJvWEBmylXAnikzFaDtgbVcR)
 def play_VIDEO(rKNpuHsJvWEBmylXAnikzFaDtgbVPo,args):
  rKNpuHsJvWEBmylXAnikzFaDtgbVhY =args.get('id')
  rKNpuHsJvWEBmylXAnikzFaDtgbVUd =args.get('asis')
  if rKNpuHsJvWEBmylXAnikzFaDtgbVUd in['HIGHLIGHT']:
   rKNpuHsJvWEBmylXAnikzFaDtgbVhS,rKNpuHsJvWEBmylXAnikzFaDtgbVhe=rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.GetEventURL(rKNpuHsJvWEBmylXAnikzFaDtgbVhY,rKNpuHsJvWEBmylXAnikzFaDtgbVUd)
  elif rKNpuHsJvWEBmylXAnikzFaDtgbVUd in['LIVE']:
   rKNpuHsJvWEBmylXAnikzFaDtgbVhS,rKNpuHsJvWEBmylXAnikzFaDtgbVhe=rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.GetEventURL_Live(rKNpuHsJvWEBmylXAnikzFaDtgbVhY,rKNpuHsJvWEBmylXAnikzFaDtgbVUd)
  else:
   rKNpuHsJvWEBmylXAnikzFaDtgbVhS,rKNpuHsJvWEBmylXAnikzFaDtgbVhe=rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.GetBroadURL(rKNpuHsJvWEBmylXAnikzFaDtgbVhY)
  rKNpuHsJvWEBmylXAnikzFaDtgbVPo.addon_log('asis, url : %s - %s - %s'%(rKNpuHsJvWEBmylXAnikzFaDtgbVUd,rKNpuHsJvWEBmylXAnikzFaDtgbVhY,rKNpuHsJvWEBmylXAnikzFaDtgbVhS))
  if rKNpuHsJvWEBmylXAnikzFaDtgbVhS=='':
   if rKNpuHsJvWEBmylXAnikzFaDtgbVhe=='':
    rKNpuHsJvWEBmylXAnikzFaDtgbVPo.addon_noti(__language__(30907).encode('utf8'))
   else:
    rKNpuHsJvWEBmylXAnikzFaDtgbVPo.addon_log('drm_license_1 : %s'%(rKNpuHsJvWEBmylXAnikzFaDtgbVhe))
    rKNpuHsJvWEBmylXAnikzFaDtgbVPo.addon_noti(rKNpuHsJvWEBmylXAnikzFaDtgbVhe)
   return
  else:
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.addon_log('drm_license : %s'%(rKNpuHsJvWEBmylXAnikzFaDtgbVhe))
  rKNpuHsJvWEBmylXAnikzFaDtgbVhx='PCID=%s;token=%s;member_srl=%s;NEXT_LOCALE=%s;session_web_id=%s;device_id=%s'%(rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.CP['COOKIES']['PCID'],rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.CP['COOKIES']['token'],rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.CP['COOKIES']['member_srl'],rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.CP['COOKIES']['NEXT_LOCALE'],rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.CP['COOKIES']['session_web_id'],rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.CP['COOKIES']['device_id'],)
  if rKNpuHsJvWEBmylXAnikzFaDtgbVUd in['EPISODE']:
   rKNpuHsJvWEBmylXAnikzFaDtgbVhR='https://www.coupangplay.com/play/{}/episode?titleId={}&type=EPISODE&sourceType=page_discover_title_detail%3Apage_discover_feed'.format(rKNpuHsJvWEBmylXAnikzFaDtgbVhY,rKNpuHsJvWEBmylXAnikzFaDtgbVhY)
  elif rKNpuHsJvWEBmylXAnikzFaDtgbVUd in['MOVIE']:
   rKNpuHsJvWEBmylXAnikzFaDtgbVhR='https://www.coupangplay.com/play/{}/movie?sourceType=page_discover_feed'.format(rKNpuHsJvWEBmylXAnikzFaDtgbVhY)
  else:
   rKNpuHsJvWEBmylXAnikzFaDtgbVhR='https://www.coupangplay.com/play/'+rKNpuHsJvWEBmylXAnikzFaDtgbVhY 
  rKNpuHsJvWEBmylXAnikzFaDtgbVCP,rKNpuHsJvWEBmylXAnikzFaDtgbVCq,rKNpuHsJvWEBmylXAnikzFaDtgbVCU=rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.Make_authHeader()
  rKNpuHsJvWEBmylXAnikzFaDtgbVCh=rKNpuHsJvWEBmylXAnikzFaDtgbVhS 
  rKNpuHsJvWEBmylXAnikzFaDtgbVPo.addon_log('tobe, surl : %s'%(rKNpuHsJvWEBmylXAnikzFaDtgbVCh))
  rKNpuHsJvWEBmylXAnikzFaDtgbVCc=xbmcgui.ListItem(path=rKNpuHsJvWEBmylXAnikzFaDtgbVCh)
  rKNpuHsJvWEBmylXAnikzFaDtgbVCo=rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.Get_Url_PostFix(rKNpuHsJvWEBmylXAnikzFaDtgbVhS) 
  rKNpuHsJvWEBmylXAnikzFaDtgbVPo.addon_log('post_fix : '+rKNpuHsJvWEBmylXAnikzFaDtgbVCo)
  if rKNpuHsJvWEBmylXAnikzFaDtgbVCo=='m3u8':
   rKNpuHsJvWEBmylXAnikzFaDtgbVCw ='hls' 
  else:
   rKNpuHsJvWEBmylXAnikzFaDtgbVCw ='mpd' 
  if rKNpuHsJvWEBmylXAnikzFaDtgbVhe:
   rKNpuHsJvWEBmylXAnikzFaDtgbVCM =rKNpuHsJvWEBmylXAnikzFaDtgbVhe 
   rKNpuHsJvWEBmylXAnikzFaDtgbVCd ='com.widevine.alpha'
   rKNpuHsJvWEBmylXAnikzFaDtgbVCT={'traceparent':rKNpuHsJvWEBmylXAnikzFaDtgbVCP,'tracestate':rKNpuHsJvWEBmylXAnikzFaDtgbVCq,'newrelic':rKNpuHsJvWEBmylXAnikzFaDtgbVCU,'User-Agent':rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.USER_AGENT,'Referer':rKNpuHsJvWEBmylXAnikzFaDtgbVhR,'Cookie':rKNpuHsJvWEBmylXAnikzFaDtgbVhx,}
   rKNpuHsJvWEBmylXAnikzFaDtgbVCI=rKNpuHsJvWEBmylXAnikzFaDtgbVCM+'|'+urllib.parse.urlencode(rKNpuHsJvWEBmylXAnikzFaDtgbVCT)+'|R{SSM}|'
   rKNpuHsJvWEBmylXAnikzFaDtgbVCc.setProperty('inputstream','inputstream.adaptive')
   rKNpuHsJvWEBmylXAnikzFaDtgbVCc.setProperty('inputstream.adaptive.manifest_type',rKNpuHsJvWEBmylXAnikzFaDtgbVCw)
   rKNpuHsJvWEBmylXAnikzFaDtgbVCc.setProperty('inputstream.adaptive.license_type',rKNpuHsJvWEBmylXAnikzFaDtgbVCd)
   rKNpuHsJvWEBmylXAnikzFaDtgbVCc.setProperty('inputstream.adaptive.license_key',rKNpuHsJvWEBmylXAnikzFaDtgbVCI)
   rKNpuHsJvWEBmylXAnikzFaDtgbVCc.setProperty('inputstream.adaptive.stream_headers','User-Agent={}&Cookie={}&Referer={}&traceparent={}&tracestate={}&newrelic={}'.format(rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.USER_AGENT,rKNpuHsJvWEBmylXAnikzFaDtgbVhx,rKNpuHsJvWEBmylXAnikzFaDtgbVhR,rKNpuHsJvWEBmylXAnikzFaDtgbVCP,rKNpuHsJvWEBmylXAnikzFaDtgbVCq,rKNpuHsJvWEBmylXAnikzFaDtgbVCU))
   rKNpuHsJvWEBmylXAnikzFaDtgbVCc.setMimeType('application/dash+xml')
   rKNpuHsJvWEBmylXAnikzFaDtgbVCc.setContentLookup(rKNpuHsJvWEBmylXAnikzFaDtgbVcR)
  else:
   rKNpuHsJvWEBmylXAnikzFaDtgbVCc.setContentLookup(rKNpuHsJvWEBmylXAnikzFaDtgbVcR)
   rKNpuHsJvWEBmylXAnikzFaDtgbVCc.setMimeType('application/x-mpegURL')
   rKNpuHsJvWEBmylXAnikzFaDtgbVCc.setProperty('inputstream','inputstream.adaptive')
   rKNpuHsJvWEBmylXAnikzFaDtgbVCc.setProperty('inputstream.adaptive.manifest_type',rKNpuHsJvWEBmylXAnikzFaDtgbVCw)
   rKNpuHsJvWEBmylXAnikzFaDtgbVCc.setProperty('inputstream.adaptive.stream_headers','User-Agent={}&Cookie={}&Referer={}&traceparent={}&tracestate={}&newrelic={}'.format(rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.USER_AGENT,rKNpuHsJvWEBmylXAnikzFaDtgbVhx,rKNpuHsJvWEBmylXAnikzFaDtgbVhR,rKNpuHsJvWEBmylXAnikzFaDtgbVCP,rKNpuHsJvWEBmylXAnikzFaDtgbVCq,rKNpuHsJvWEBmylXAnikzFaDtgbVCU))
  xbmcplugin.setResolvedUrl(rKNpuHsJvWEBmylXAnikzFaDtgbVPo._addon_handle,rKNpuHsJvWEBmylXAnikzFaDtgbVoP,rKNpuHsJvWEBmylXAnikzFaDtgbVCc)
  try:
   if rKNpuHsJvWEBmylXAnikzFaDtgbVUd=='MOVIE':
    rKNpuHsJvWEBmylXAnikzFaDtgbVCj='movie'
    rKNpuHsJvWEBmylXAnikzFaDtgbVqd={'code':rKNpuHsJvWEBmylXAnikzFaDtgbVhY,'asis':rKNpuHsJvWEBmylXAnikzFaDtgbVUd,'title':args.get('title'),'img':args.get('thumbnail'),}
    rKNpuHsJvWEBmylXAnikzFaDtgbVPo.Save_Watched_List(rKNpuHsJvWEBmylXAnikzFaDtgbVCj,rKNpuHsJvWEBmylXAnikzFaDtgbVqd)
   elif rKNpuHsJvWEBmylXAnikzFaDtgbVUd=='TVSHOW':
    rKNpuHsJvWEBmylXAnikzFaDtgbVCj='tvshow'
    rKNpuHsJvWEBmylXAnikzFaDtgbVqd={'code':args.get('programid'),'asis':rKNpuHsJvWEBmylXAnikzFaDtgbVUd,'title':'%s <%s>'%(args.get('title'),args.get('programnm')),'img':args.get('programimg'),}
    rKNpuHsJvWEBmylXAnikzFaDtgbVPo.Save_Watched_List(rKNpuHsJvWEBmylXAnikzFaDtgbVCj,rKNpuHsJvWEBmylXAnikzFaDtgbVqd)
  except:
   rKNpuHsJvWEBmylXAnikzFaDtgbVcx
 def dp_Global_Search(rKNpuHsJvWEBmylXAnikzFaDtgbVPo,args):
  rKNpuHsJvWEBmylXAnikzFaDtgbVUx=args.get('mode')
  if rKNpuHsJvWEBmylXAnikzFaDtgbVUx=='TOTAL_SEARCH':
   rKNpuHsJvWEBmylXAnikzFaDtgbVCL='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   rKNpuHsJvWEBmylXAnikzFaDtgbVCL='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(rKNpuHsJvWEBmylXAnikzFaDtgbVCL)
 def dp_Bookmark_Menu(rKNpuHsJvWEBmylXAnikzFaDtgbVPo,args):
  rKNpuHsJvWEBmylXAnikzFaDtgbVCL='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(rKNpuHsJvWEBmylXAnikzFaDtgbVCL)
 def dp_Search_List(rKNpuHsJvWEBmylXAnikzFaDtgbVPo,args):
  rKNpuHsJvWEBmylXAnikzFaDtgbVUO =rKNpuHsJvWEBmylXAnikzFaDtgbVoC(args.get('page'))
  if 'search_key' in args:
   rKNpuHsJvWEBmylXAnikzFaDtgbVCO=args.get('search_key')
  else:
   rKNpuHsJvWEBmylXAnikzFaDtgbVCO=rKNpuHsJvWEBmylXAnikzFaDtgbVPo.get_keyboard_input(__language__(30908).encode('utf-8'))
   if not rKNpuHsJvWEBmylXAnikzFaDtgbVCO:
    return
  rKNpuHsJvWEBmylXAnikzFaDtgbVCG,rKNpuHsJvWEBmylXAnikzFaDtgbVUG=rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.Get_Search_List(rKNpuHsJvWEBmylXAnikzFaDtgbVCO,rKNpuHsJvWEBmylXAnikzFaDtgbVUO)
  for rKNpuHsJvWEBmylXAnikzFaDtgbVCf in rKNpuHsJvWEBmylXAnikzFaDtgbVCG:
   rKNpuHsJvWEBmylXAnikzFaDtgbVoT =rKNpuHsJvWEBmylXAnikzFaDtgbVCf.get('id')
   rKNpuHsJvWEBmylXAnikzFaDtgbVqh =rKNpuHsJvWEBmylXAnikzFaDtgbVCf.get('title')
   rKNpuHsJvWEBmylXAnikzFaDtgbVUd =rKNpuHsJvWEBmylXAnikzFaDtgbVCf.get('asis')
   rKNpuHsJvWEBmylXAnikzFaDtgbVUM =rKNpuHsJvWEBmylXAnikzFaDtgbVCf.get('thumbnail')
   rKNpuHsJvWEBmylXAnikzFaDtgbVUf =rKNpuHsJvWEBmylXAnikzFaDtgbVCf.get('mpaa')
   rKNpuHsJvWEBmylXAnikzFaDtgbVUY =rKNpuHsJvWEBmylXAnikzFaDtgbVCf.get('year')
   rKNpuHsJvWEBmylXAnikzFaDtgbVUL =rKNpuHsJvWEBmylXAnikzFaDtgbVCf.get('duration')
   rKNpuHsJvWEBmylXAnikzFaDtgbVUQ =rKNpuHsJvWEBmylXAnikzFaDtgbVCf.get('badge')
   if rKNpuHsJvWEBmylXAnikzFaDtgbVUd=='TVSHOW': 
    rKNpuHsJvWEBmylXAnikzFaDtgbVUx ='SEASON_LIST'
    rKNpuHsJvWEBmylXAnikzFaDtgbVUc={'mediatype':'tvshow','title':rKNpuHsJvWEBmylXAnikzFaDtgbVqh,'mpaa':rKNpuHsJvWEBmylXAnikzFaDtgbVUf,'year':rKNpuHsJvWEBmylXAnikzFaDtgbVUY,'plot':'Year : %s'%(rKNpuHsJvWEBmylXAnikzFaDtgbVUY),}
    rKNpuHsJvWEBmylXAnikzFaDtgbVqT =rKNpuHsJvWEBmylXAnikzFaDtgbVoP
   elif rKNpuHsJvWEBmylXAnikzFaDtgbVUd=='MOVIE':
    rKNpuHsJvWEBmylXAnikzFaDtgbVUx ='MOVIE'
    rKNpuHsJvWEBmylXAnikzFaDtgbVUc={'mediatype':'movie','title':rKNpuHsJvWEBmylXAnikzFaDtgbVqh,'mpaa':rKNpuHsJvWEBmylXAnikzFaDtgbVUf,'duration':rKNpuHsJvWEBmylXAnikzFaDtgbVUL,'year':rKNpuHsJvWEBmylXAnikzFaDtgbVUY,'plot':'(%s)'%(rKNpuHsJvWEBmylXAnikzFaDtgbVUf),}
    rKNpuHsJvWEBmylXAnikzFaDtgbVqT =rKNpuHsJvWEBmylXAnikzFaDtgbVcR
    rKNpuHsJvWEBmylXAnikzFaDtgbVqh +=' (%s)'%(rKNpuHsJvWEBmylXAnikzFaDtgbVod(rKNpuHsJvWEBmylXAnikzFaDtgbVUY))
   elif rKNpuHsJvWEBmylXAnikzFaDtgbVUd=='HIGHLIGHT':
    rKNpuHsJvWEBmylXAnikzFaDtgbVUx ='HIGHLIGHT'
    rKNpuHsJvWEBmylXAnikzFaDtgbVUc={'mediatype':'episode','title':rKNpuHsJvWEBmylXAnikzFaDtgbVqh,'duration':rKNpuHsJvWEBmylXAnikzFaDtgbVUL,'plot':rKNpuHsJvWEBmylXAnikzFaDtgbVUx,}
    rKNpuHsJvWEBmylXAnikzFaDtgbVqT =rKNpuHsJvWEBmylXAnikzFaDtgbVcR
   elif rKNpuHsJvWEBmylXAnikzFaDtgbVUd=='LIVE':
    rKNpuHsJvWEBmylXAnikzFaDtgbVUx ='LIVE'
    rKNpuHsJvWEBmylXAnikzFaDtgbVUc={'mediatype':'episode','title':rKNpuHsJvWEBmylXAnikzFaDtgbVqh,'plot':rKNpuHsJvWEBmylXAnikzFaDtgbVUx,}
    rKNpuHsJvWEBmylXAnikzFaDtgbVqT =rKNpuHsJvWEBmylXAnikzFaDtgbVcR
   rKNpuHsJvWEBmylXAnikzFaDtgbVqd={'mode':rKNpuHsJvWEBmylXAnikzFaDtgbVUx,'id':rKNpuHsJvWEBmylXAnikzFaDtgbVoT,'asis':rKNpuHsJvWEBmylXAnikzFaDtgbVUd,'seasonList':'','title':rKNpuHsJvWEBmylXAnikzFaDtgbVqh,'thumbnail':json.dumps(rKNpuHsJvWEBmylXAnikzFaDtgbVUM,separators=(',',':')),'year':rKNpuHsJvWEBmylXAnikzFaDtgbVUY,}
   if rKNpuHsJvWEBmylXAnikzFaDtgbVPo.get_settings_makebookmark()and rKNpuHsJvWEBmylXAnikzFaDtgbVUd not in['HIGHLIGHT','']:
    rKNpuHsJvWEBmylXAnikzFaDtgbVUR={'videoid':rKNpuHsJvWEBmylXAnikzFaDtgbVoT,'vidtype':'movie' if rKNpuHsJvWEBmylXAnikzFaDtgbVUd=='MOVIE' else 'tvshow','vtitle':rKNpuHsJvWEBmylXAnikzFaDtgbVqh,'vsubtitle':'',}
    rKNpuHsJvWEBmylXAnikzFaDtgbVhP=json.dumps(rKNpuHsJvWEBmylXAnikzFaDtgbVUR)
    rKNpuHsJvWEBmylXAnikzFaDtgbVhP=urllib.parse.quote(rKNpuHsJvWEBmylXAnikzFaDtgbVhP)
    rKNpuHsJvWEBmylXAnikzFaDtgbVhq='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(rKNpuHsJvWEBmylXAnikzFaDtgbVhP)
    rKNpuHsJvWEBmylXAnikzFaDtgbVhU=[('(통합) 찜 영상에 추가',rKNpuHsJvWEBmylXAnikzFaDtgbVhq)]
   else:
    rKNpuHsJvWEBmylXAnikzFaDtgbVhU=rKNpuHsJvWEBmylXAnikzFaDtgbVcx
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.add_dir(rKNpuHsJvWEBmylXAnikzFaDtgbVqh,sublabel=rKNpuHsJvWEBmylXAnikzFaDtgbVUQ,img=rKNpuHsJvWEBmylXAnikzFaDtgbVUM,infoLabels=rKNpuHsJvWEBmylXAnikzFaDtgbVUc,isFolder=rKNpuHsJvWEBmylXAnikzFaDtgbVqT,params=rKNpuHsJvWEBmylXAnikzFaDtgbVqd,ContextMenu=rKNpuHsJvWEBmylXAnikzFaDtgbVhU)
  if rKNpuHsJvWEBmylXAnikzFaDtgbVUG:
   rKNpuHsJvWEBmylXAnikzFaDtgbVqd={}
   rKNpuHsJvWEBmylXAnikzFaDtgbVqd['mode'] ='LOCAL_SEARCH'
   rKNpuHsJvWEBmylXAnikzFaDtgbVqd['search_key']=rKNpuHsJvWEBmylXAnikzFaDtgbVCO
   rKNpuHsJvWEBmylXAnikzFaDtgbVqd['page'] =rKNpuHsJvWEBmylXAnikzFaDtgbVod(rKNpuHsJvWEBmylXAnikzFaDtgbVUO+1)
   rKNpuHsJvWEBmylXAnikzFaDtgbVqh='[B]%s >>[/B]'%'다음 페이지'
   rKNpuHsJvWEBmylXAnikzFaDtgbVhC=rKNpuHsJvWEBmylXAnikzFaDtgbVod(rKNpuHsJvWEBmylXAnikzFaDtgbVUO+1)
   rKNpuHsJvWEBmylXAnikzFaDtgbVqM=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.add_dir(rKNpuHsJvWEBmylXAnikzFaDtgbVqh,sublabel=rKNpuHsJvWEBmylXAnikzFaDtgbVhC,img=rKNpuHsJvWEBmylXAnikzFaDtgbVqM,infoLabels=rKNpuHsJvWEBmylXAnikzFaDtgbVcx,isFolder=rKNpuHsJvWEBmylXAnikzFaDtgbVoP,params=rKNpuHsJvWEBmylXAnikzFaDtgbVqd)
  xbmcplugin.setContent(rKNpuHsJvWEBmylXAnikzFaDtgbVPo._addon_handle,'movies')
  xbmcplugin.endOfDirectory(rKNpuHsJvWEBmylXAnikzFaDtgbVPo._addon_handle,cacheToDisc=rKNpuHsJvWEBmylXAnikzFaDtgbVoP)
  if args.get('historyyn')=='Y':rKNpuHsJvWEBmylXAnikzFaDtgbVPo.Save_Searched_List(rKNpuHsJvWEBmylXAnikzFaDtgbVCO)
 def Load_List_File(rKNpuHsJvWEBmylXAnikzFaDtgbVPo,rKNpuHsJvWEBmylXAnikzFaDtgbVCj): 
  try:
   if rKNpuHsJvWEBmylXAnikzFaDtgbVCj=='search':
    rKNpuHsJvWEBmylXAnikzFaDtgbVCQ=rKNpuHsJvWEBmylXAnikzFaDtgbVPc
   elif rKNpuHsJvWEBmylXAnikzFaDtgbVCj in['tvshow','movie']:
    rKNpuHsJvWEBmylXAnikzFaDtgbVCQ=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%rKNpuHsJvWEBmylXAnikzFaDtgbVCj))
   else:
    return[]
   fp=rKNpuHsJvWEBmylXAnikzFaDtgbVow(rKNpuHsJvWEBmylXAnikzFaDtgbVCQ,'r',-1,'utf-8')
   rKNpuHsJvWEBmylXAnikzFaDtgbVCY=fp.readlines()
   fp.close()
  except:
   rKNpuHsJvWEBmylXAnikzFaDtgbVCY=[]
  return rKNpuHsJvWEBmylXAnikzFaDtgbVCY
 def Save_Watched_List(rKNpuHsJvWEBmylXAnikzFaDtgbVPo,rKNpuHsJvWEBmylXAnikzFaDtgbVCj,rKNpuHsJvWEBmylXAnikzFaDtgbVPd):
  try:
   rKNpuHsJvWEBmylXAnikzFaDtgbVCS=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%rKNpuHsJvWEBmylXAnikzFaDtgbVCj))
   rKNpuHsJvWEBmylXAnikzFaDtgbVCe=rKNpuHsJvWEBmylXAnikzFaDtgbVPo.Load_List_File(rKNpuHsJvWEBmylXAnikzFaDtgbVCj) 
   fp=rKNpuHsJvWEBmylXAnikzFaDtgbVow(rKNpuHsJvWEBmylXAnikzFaDtgbVCS,'w',-1,'utf-8')
   rKNpuHsJvWEBmylXAnikzFaDtgbVCx=urllib.parse.urlencode(rKNpuHsJvWEBmylXAnikzFaDtgbVPd)
   rKNpuHsJvWEBmylXAnikzFaDtgbVCx=rKNpuHsJvWEBmylXAnikzFaDtgbVCx+'\n'
   fp.write(rKNpuHsJvWEBmylXAnikzFaDtgbVCx)
   rKNpuHsJvWEBmylXAnikzFaDtgbVCR=0
   for rKNpuHsJvWEBmylXAnikzFaDtgbVcP in rKNpuHsJvWEBmylXAnikzFaDtgbVCe:
    rKNpuHsJvWEBmylXAnikzFaDtgbVcq=rKNpuHsJvWEBmylXAnikzFaDtgbVoU(urllib.parse.parse_qsl(rKNpuHsJvWEBmylXAnikzFaDtgbVcP))
    rKNpuHsJvWEBmylXAnikzFaDtgbVcU=rKNpuHsJvWEBmylXAnikzFaDtgbVPd.get('code').strip()
    rKNpuHsJvWEBmylXAnikzFaDtgbVch=rKNpuHsJvWEBmylXAnikzFaDtgbVcq.get('code').strip()
    if rKNpuHsJvWEBmylXAnikzFaDtgbVcU!=rKNpuHsJvWEBmylXAnikzFaDtgbVch:
     fp.write(rKNpuHsJvWEBmylXAnikzFaDtgbVcP)
     rKNpuHsJvWEBmylXAnikzFaDtgbVCR+=1
     if rKNpuHsJvWEBmylXAnikzFaDtgbVCR>=50:break
   fp.close()
  except:
   rKNpuHsJvWEBmylXAnikzFaDtgbVcx
 def Save_Searched_List(rKNpuHsJvWEBmylXAnikzFaDtgbVPo,rKNpuHsJvWEBmylXAnikzFaDtgbVCO):
  try:
   rKNpuHsJvWEBmylXAnikzFaDtgbVCO=rKNpuHsJvWEBmylXAnikzFaDtgbVCO.strip()
   rKNpuHsJvWEBmylXAnikzFaDtgbVCe=rKNpuHsJvWEBmylXAnikzFaDtgbVPo.Load_List_File('search') 
   fp=rKNpuHsJvWEBmylXAnikzFaDtgbVow(rKNpuHsJvWEBmylXAnikzFaDtgbVPc,'w',-1,'utf-8')
   fp.write(rKNpuHsJvWEBmylXAnikzFaDtgbVCO+'\n')
   rKNpuHsJvWEBmylXAnikzFaDtgbVCR=0
   for rKNpuHsJvWEBmylXAnikzFaDtgbVcP in rKNpuHsJvWEBmylXAnikzFaDtgbVCe:
    rKNpuHsJvWEBmylXAnikzFaDtgbVcP=rKNpuHsJvWEBmylXAnikzFaDtgbVcP.strip()
    if rKNpuHsJvWEBmylXAnikzFaDtgbVCO!=rKNpuHsJvWEBmylXAnikzFaDtgbVcP:
     fp.write(rKNpuHsJvWEBmylXAnikzFaDtgbVcP+'\n')
     rKNpuHsJvWEBmylXAnikzFaDtgbVCR+=1
     if rKNpuHsJvWEBmylXAnikzFaDtgbVCR>=50:break
   fp.close()
  except:
   rKNpuHsJvWEBmylXAnikzFaDtgbVcx
 def dp_Search_History(rKNpuHsJvWEBmylXAnikzFaDtgbVPo,args):
  rKNpuHsJvWEBmylXAnikzFaDtgbVcC=rKNpuHsJvWEBmylXAnikzFaDtgbVPo.Load_List_File('search')
  for rKNpuHsJvWEBmylXAnikzFaDtgbVco in rKNpuHsJvWEBmylXAnikzFaDtgbVcC:
   rKNpuHsJvWEBmylXAnikzFaDtgbVco=rKNpuHsJvWEBmylXAnikzFaDtgbVco.strip()
   rKNpuHsJvWEBmylXAnikzFaDtgbVqd={'mode':'LOCAL_SEARCH','search_key':rKNpuHsJvWEBmylXAnikzFaDtgbVco,'page':'1','historyyn':'Y',}
   rKNpuHsJvWEBmylXAnikzFaDtgbVcw={'mode':'SEARCH_REMOVE','stype':'ONE','skey':rKNpuHsJvWEBmylXAnikzFaDtgbVco,}
   rKNpuHsJvWEBmylXAnikzFaDtgbVcM=urllib.parse.urlencode(rKNpuHsJvWEBmylXAnikzFaDtgbVcw)
   rKNpuHsJvWEBmylXAnikzFaDtgbVhU=[('선택된 검색어 ( %s ) 삭제'%(rKNpuHsJvWEBmylXAnikzFaDtgbVco),'RunPlugin(plugin://plugin.video.coupangm/?%s)'%(rKNpuHsJvWEBmylXAnikzFaDtgbVcM))]
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.add_dir(rKNpuHsJvWEBmylXAnikzFaDtgbVco,sublabel='',img=rKNpuHsJvWEBmylXAnikzFaDtgbVcx,infoLabels=rKNpuHsJvWEBmylXAnikzFaDtgbVcx,isFolder=rKNpuHsJvWEBmylXAnikzFaDtgbVoP,params=rKNpuHsJvWEBmylXAnikzFaDtgbVqd,ContextMenu=rKNpuHsJvWEBmylXAnikzFaDtgbVhU)
  rKNpuHsJvWEBmylXAnikzFaDtgbVUc={'plot':'검색목록 전체를 삭제합니다.'}
  rKNpuHsJvWEBmylXAnikzFaDtgbVqh='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  rKNpuHsJvWEBmylXAnikzFaDtgbVqd={'mode':'SEARCH_REMOVE','stype':'ALL','skey':'-',}
  rKNpuHsJvWEBmylXAnikzFaDtgbVqM=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  rKNpuHsJvWEBmylXAnikzFaDtgbVPo.add_dir(rKNpuHsJvWEBmylXAnikzFaDtgbVqh,sublabel='',img=rKNpuHsJvWEBmylXAnikzFaDtgbVqM,infoLabels=rKNpuHsJvWEBmylXAnikzFaDtgbVUc,isFolder=rKNpuHsJvWEBmylXAnikzFaDtgbVcR,params=rKNpuHsJvWEBmylXAnikzFaDtgbVqd,isLink=rKNpuHsJvWEBmylXAnikzFaDtgbVoP)
  xbmcplugin.endOfDirectory(rKNpuHsJvWEBmylXAnikzFaDtgbVPo._addon_handle,cacheToDisc=rKNpuHsJvWEBmylXAnikzFaDtgbVcR)
 def dp_Listfile_Delete(rKNpuHsJvWEBmylXAnikzFaDtgbVPo,args):
  rKNpuHsJvWEBmylXAnikzFaDtgbVCj=args.get('stype')
  rKNpuHsJvWEBmylXAnikzFaDtgbVcd =args.get('skey')
  rKNpuHsJvWEBmylXAnikzFaDtgbVPI=xbmcgui.Dialog()
  if rKNpuHsJvWEBmylXAnikzFaDtgbVCj=='ALL':
   rKNpuHsJvWEBmylXAnikzFaDtgbVqO=rKNpuHsJvWEBmylXAnikzFaDtgbVPI.yesno(__language__(30911).encode('utf8'),__language__(30906).encode('utf8'))
  elif rKNpuHsJvWEBmylXAnikzFaDtgbVCj=='ONE':
   rKNpuHsJvWEBmylXAnikzFaDtgbVqO=rKNpuHsJvWEBmylXAnikzFaDtgbVPI.yesno(__language__(30912).encode('utf8'),__language__(30906).encode('utf8'))
  elif rKNpuHsJvWEBmylXAnikzFaDtgbVCj in['tvshow','movie']:
   rKNpuHsJvWEBmylXAnikzFaDtgbVqO=rKNpuHsJvWEBmylXAnikzFaDtgbVPI.yesno(__language__(30913).encode('utf8'),__language__(30906).encode('utf8'))
  if rKNpuHsJvWEBmylXAnikzFaDtgbVqO==rKNpuHsJvWEBmylXAnikzFaDtgbVcR:sys.exit()
  rKNpuHsJvWEBmylXAnikzFaDtgbVPo.Delete_List_File(rKNpuHsJvWEBmylXAnikzFaDtgbVCj,skey=rKNpuHsJvWEBmylXAnikzFaDtgbVcd)
  xbmc.executebuiltin("Container.Refresh")
 def Delete_List_File(rKNpuHsJvWEBmylXAnikzFaDtgbVPo,rKNpuHsJvWEBmylXAnikzFaDtgbVCj,skey='-'):
  if rKNpuHsJvWEBmylXAnikzFaDtgbVCj=='ALL':
   try:
    rKNpuHsJvWEBmylXAnikzFaDtgbVCQ=rKNpuHsJvWEBmylXAnikzFaDtgbVPc
    fp=rKNpuHsJvWEBmylXAnikzFaDtgbVow(rKNpuHsJvWEBmylXAnikzFaDtgbVCQ,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    rKNpuHsJvWEBmylXAnikzFaDtgbVcx
  elif rKNpuHsJvWEBmylXAnikzFaDtgbVCj=='ONE':
   try:
    rKNpuHsJvWEBmylXAnikzFaDtgbVCQ=rKNpuHsJvWEBmylXAnikzFaDtgbVPc
    rKNpuHsJvWEBmylXAnikzFaDtgbVCe=rKNpuHsJvWEBmylXAnikzFaDtgbVPo.Load_List_File('search') 
    fp=rKNpuHsJvWEBmylXAnikzFaDtgbVow(rKNpuHsJvWEBmylXAnikzFaDtgbVCQ,'w',-1,'utf-8')
    for rKNpuHsJvWEBmylXAnikzFaDtgbVcP in rKNpuHsJvWEBmylXAnikzFaDtgbVCe:
     if skey!=rKNpuHsJvWEBmylXAnikzFaDtgbVcP.strip():
      fp.write(rKNpuHsJvWEBmylXAnikzFaDtgbVcP)
    fp.close()
   except:
    rKNpuHsJvWEBmylXAnikzFaDtgbVcx
  elif rKNpuHsJvWEBmylXAnikzFaDtgbVCj in['tvshow','movie']:
   try:
    rKNpuHsJvWEBmylXAnikzFaDtgbVCQ=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%rKNpuHsJvWEBmylXAnikzFaDtgbVCj))
    fp=rKNpuHsJvWEBmylXAnikzFaDtgbVow(rKNpuHsJvWEBmylXAnikzFaDtgbVCQ,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    rKNpuHsJvWEBmylXAnikzFaDtgbVcx
 def dp_Watch_List(rKNpuHsJvWEBmylXAnikzFaDtgbVPo,args):
  rKNpuHsJvWEBmylXAnikzFaDtgbVCj =args.get('stype')
  if rKNpuHsJvWEBmylXAnikzFaDtgbVCj in['',rKNpuHsJvWEBmylXAnikzFaDtgbVcx]:
   for rKNpuHsJvWEBmylXAnikzFaDtgbVcT in rKNpuHsJvWEBmylXAnikzFaDtgbVPh:
    rKNpuHsJvWEBmylXAnikzFaDtgbVqh=rKNpuHsJvWEBmylXAnikzFaDtgbVcT.get('title')
    rKNpuHsJvWEBmylXAnikzFaDtgbVqd={'mode':rKNpuHsJvWEBmylXAnikzFaDtgbVcT.get('mode'),'stype':rKNpuHsJvWEBmylXAnikzFaDtgbVcT.get('stype'),}
    rKNpuHsJvWEBmylXAnikzFaDtgbVPo.add_dir(rKNpuHsJvWEBmylXAnikzFaDtgbVqh,sublabel='',img='',infoLabels=rKNpuHsJvWEBmylXAnikzFaDtgbVcx,isFolder=rKNpuHsJvWEBmylXAnikzFaDtgbVoP,params=rKNpuHsJvWEBmylXAnikzFaDtgbVqd)
   xbmcplugin.endOfDirectory(rKNpuHsJvWEBmylXAnikzFaDtgbVPo._addon_handle)
  else:
   rKNpuHsJvWEBmylXAnikzFaDtgbVcI=rKNpuHsJvWEBmylXAnikzFaDtgbVPo.Load_List_File(rKNpuHsJvWEBmylXAnikzFaDtgbVCj)
   for rKNpuHsJvWEBmylXAnikzFaDtgbVcj in rKNpuHsJvWEBmylXAnikzFaDtgbVcI:
    rKNpuHsJvWEBmylXAnikzFaDtgbVcL=rKNpuHsJvWEBmylXAnikzFaDtgbVoU(urllib.parse.parse_qsl(rKNpuHsJvWEBmylXAnikzFaDtgbVcj))
    rKNpuHsJvWEBmylXAnikzFaDtgbVhY =rKNpuHsJvWEBmylXAnikzFaDtgbVcL.get('code').strip()
    rKNpuHsJvWEBmylXAnikzFaDtgbVqh =rKNpuHsJvWEBmylXAnikzFaDtgbVcL.get('title').strip()
    rKNpuHsJvWEBmylXAnikzFaDtgbVUM =rKNpuHsJvWEBmylXAnikzFaDtgbVcL.get('img').strip()
    rKNpuHsJvWEBmylXAnikzFaDtgbVUd =rKNpuHsJvWEBmylXAnikzFaDtgbVcL.get('asis').strip()
    try:
     rKNpuHsJvWEBmylXAnikzFaDtgbVUM=rKNpuHsJvWEBmylXAnikzFaDtgbVUM.replace('\'','\"')
     rKNpuHsJvWEBmylXAnikzFaDtgbVUM=json.loads(rKNpuHsJvWEBmylXAnikzFaDtgbVUM)
    except:
     rKNpuHsJvWEBmylXAnikzFaDtgbVcx
    rKNpuHsJvWEBmylXAnikzFaDtgbVUc={}
    rKNpuHsJvWEBmylXAnikzFaDtgbVUc['plot']=rKNpuHsJvWEBmylXAnikzFaDtgbVqh
    if rKNpuHsJvWEBmylXAnikzFaDtgbVCj=='movie':
     rKNpuHsJvWEBmylXAnikzFaDtgbVUc['mediatype']='movie'
     rKNpuHsJvWEBmylXAnikzFaDtgbVqd={'mode':'MOVIE','id':rKNpuHsJvWEBmylXAnikzFaDtgbVhY,'asis':rKNpuHsJvWEBmylXAnikzFaDtgbVUd,'title':rKNpuHsJvWEBmylXAnikzFaDtgbVqh,'thumbnail':rKNpuHsJvWEBmylXAnikzFaDtgbVUM,}
     rKNpuHsJvWEBmylXAnikzFaDtgbVqT=rKNpuHsJvWEBmylXAnikzFaDtgbVcR
    else:
     rKNpuHsJvWEBmylXAnikzFaDtgbVUc['mediatype']='episode'
     rKNpuHsJvWEBmylXAnikzFaDtgbVqd={'mode':'SEASON_LIST','id':rKNpuHsJvWEBmylXAnikzFaDtgbVhY,'asis':rKNpuHsJvWEBmylXAnikzFaDtgbVUd,'title':rKNpuHsJvWEBmylXAnikzFaDtgbVqh,'thumbnail':json.dumps(rKNpuHsJvWEBmylXAnikzFaDtgbVUM,separators=(',',':')),}
     rKNpuHsJvWEBmylXAnikzFaDtgbVqT=rKNpuHsJvWEBmylXAnikzFaDtgbVoP
    rKNpuHsJvWEBmylXAnikzFaDtgbVPo.add_dir(rKNpuHsJvWEBmylXAnikzFaDtgbVqh,sublabel='',img=rKNpuHsJvWEBmylXAnikzFaDtgbVUM,infoLabels=rKNpuHsJvWEBmylXAnikzFaDtgbVUc,isFolder=rKNpuHsJvWEBmylXAnikzFaDtgbVqT,params=rKNpuHsJvWEBmylXAnikzFaDtgbVqd)
   rKNpuHsJvWEBmylXAnikzFaDtgbVUc={'plot':'시청목록을 삭제합니다.'}
   rKNpuHsJvWEBmylXAnikzFaDtgbVqh='*** 시청목록 삭제 ***'
   rKNpuHsJvWEBmylXAnikzFaDtgbVqd={'mode':'MYVIEW_REMOVE','stype':rKNpuHsJvWEBmylXAnikzFaDtgbVCj,'skey':'-',}
   rKNpuHsJvWEBmylXAnikzFaDtgbVqM=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.add_dir(rKNpuHsJvWEBmylXAnikzFaDtgbVqh,sublabel='',img=rKNpuHsJvWEBmylXAnikzFaDtgbVqM,infoLabels=rKNpuHsJvWEBmylXAnikzFaDtgbVUc,isFolder=rKNpuHsJvWEBmylXAnikzFaDtgbVcR,params=rKNpuHsJvWEBmylXAnikzFaDtgbVqd,isLink=rKNpuHsJvWEBmylXAnikzFaDtgbVoP)
   if rKNpuHsJvWEBmylXAnikzFaDtgbVCj=='movie':xbmcplugin.setContent(rKNpuHsJvWEBmylXAnikzFaDtgbVPo._addon_handle,'movies')
   else:xbmcplugin.setContent(rKNpuHsJvWEBmylXAnikzFaDtgbVPo._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(rKNpuHsJvWEBmylXAnikzFaDtgbVPo._addon_handle,cacheToDisc=rKNpuHsJvWEBmylXAnikzFaDtgbVcR)
 def dp_Set_Bookmark(rKNpuHsJvWEBmylXAnikzFaDtgbVPo,args):
  rKNpuHsJvWEBmylXAnikzFaDtgbVcO=urllib.parse.unquote(args.get('bm_param'))
  rKNpuHsJvWEBmylXAnikzFaDtgbVcO=json.loads(rKNpuHsJvWEBmylXAnikzFaDtgbVcO)
  rKNpuHsJvWEBmylXAnikzFaDtgbVcG =rKNpuHsJvWEBmylXAnikzFaDtgbVcO.get('videoid')
  rKNpuHsJvWEBmylXAnikzFaDtgbVcf =rKNpuHsJvWEBmylXAnikzFaDtgbVcO.get('vidtype')
  rKNpuHsJvWEBmylXAnikzFaDtgbVcQ =rKNpuHsJvWEBmylXAnikzFaDtgbVcO.get('vtitle')
  rKNpuHsJvWEBmylXAnikzFaDtgbVPI=xbmcgui.Dialog()
  rKNpuHsJvWEBmylXAnikzFaDtgbVqO=rKNpuHsJvWEBmylXAnikzFaDtgbVPI.yesno(__language__(30914).encode('utf8'),rKNpuHsJvWEBmylXAnikzFaDtgbVcQ+' \n\n'+__language__(30915))
  if rKNpuHsJvWEBmylXAnikzFaDtgbVqO==rKNpuHsJvWEBmylXAnikzFaDtgbVcR:return
  rKNpuHsJvWEBmylXAnikzFaDtgbVcY=rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.GetBookmarkInfo(rKNpuHsJvWEBmylXAnikzFaDtgbVcG,rKNpuHsJvWEBmylXAnikzFaDtgbVcf)
  rKNpuHsJvWEBmylXAnikzFaDtgbVcS=json.dumps(rKNpuHsJvWEBmylXAnikzFaDtgbVcY)
  rKNpuHsJvWEBmylXAnikzFaDtgbVcS=urllib.parse.quote(rKNpuHsJvWEBmylXAnikzFaDtgbVcS)
  rKNpuHsJvWEBmylXAnikzFaDtgbVhq ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(rKNpuHsJvWEBmylXAnikzFaDtgbVcS)
  xbmc.executebuiltin(rKNpuHsJvWEBmylXAnikzFaDtgbVhq)
 def coupang_main(rKNpuHsJvWEBmylXAnikzFaDtgbVPo):
  rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CoupangObj.KodiVersion=rKNpuHsJvWEBmylXAnikzFaDtgbVoC(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  rKNpuHsJvWEBmylXAnikzFaDtgbVUx=rKNpuHsJvWEBmylXAnikzFaDtgbVPo.main_params.get('mode',rKNpuHsJvWEBmylXAnikzFaDtgbVcx)
  if rKNpuHsJvWEBmylXAnikzFaDtgbVUx=='LOGOUT':
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.CP_logout()
   return
  rKNpuHsJvWEBmylXAnikzFaDtgbVPo.option_check()
  if rKNpuHsJvWEBmylXAnikzFaDtgbVUx is rKNpuHsJvWEBmylXAnikzFaDtgbVcx:
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.dp_Main_List(rKNpuHsJvWEBmylXAnikzFaDtgbVPo.main_params)
  elif rKNpuHsJvWEBmylXAnikzFaDtgbVUx=='CATEGORY_GROUPLIST':
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.dp_Category_GroupList(rKNpuHsJvWEBmylXAnikzFaDtgbVPo.main_params)
  elif rKNpuHsJvWEBmylXAnikzFaDtgbVUx=='THEME_GROUPLIST':
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.dp_Theme_GroupList(rKNpuHsJvWEBmylXAnikzFaDtgbVPo.main_params)
  elif rKNpuHsJvWEBmylXAnikzFaDtgbVUx=='EVENT_GROUPLIST':
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.dp_Event_GroupList(rKNpuHsJvWEBmylXAnikzFaDtgbVPo.main_params)
  elif rKNpuHsJvWEBmylXAnikzFaDtgbVUx=='EVENT_GAMELIST':
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.dp_Event_GameList(rKNpuHsJvWEBmylXAnikzFaDtgbVPo.main_params)
  elif rKNpuHsJvWEBmylXAnikzFaDtgbVUx=='EVENT_LIST':
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.dp_Event_List(rKNpuHsJvWEBmylXAnikzFaDtgbVPo.main_params)
  elif rKNpuHsJvWEBmylXAnikzFaDtgbVUx=='CATEGORY_LIST':
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.dp_Category_List(rKNpuHsJvWEBmylXAnikzFaDtgbVPo.main_params)
  elif rKNpuHsJvWEBmylXAnikzFaDtgbVUx=='SEASON_LIST':
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.dp_Season_List(rKNpuHsJvWEBmylXAnikzFaDtgbVPo.main_params)
  elif rKNpuHsJvWEBmylXAnikzFaDtgbVUx=='EPISODE_LIST':
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.dp_Episode_List(rKNpuHsJvWEBmylXAnikzFaDtgbVPo.main_params)
  elif rKNpuHsJvWEBmylXAnikzFaDtgbVUx=='TEST':
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.dp_Test(rKNpuHsJvWEBmylXAnikzFaDtgbVPo.main_params)
  elif rKNpuHsJvWEBmylXAnikzFaDtgbVUx in['MOVIE','VOD','HIGHLIGHT','LIVE']:
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.play_VIDEO(rKNpuHsJvWEBmylXAnikzFaDtgbVPo.main_params)
  elif rKNpuHsJvWEBmylXAnikzFaDtgbVUx=='WATCH':
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.dp_Watch_List(rKNpuHsJvWEBmylXAnikzFaDtgbVPo.main_params)
  elif rKNpuHsJvWEBmylXAnikzFaDtgbVUx=='LOCAL_SEARCH':
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.dp_Search_List(rKNpuHsJvWEBmylXAnikzFaDtgbVPo.main_params)
  elif rKNpuHsJvWEBmylXAnikzFaDtgbVUx=='SEARCH_HISTORY':
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.dp_Search_History(rKNpuHsJvWEBmylXAnikzFaDtgbVPo.main_params)
  elif rKNpuHsJvWEBmylXAnikzFaDtgbVUx in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.dp_Listfile_Delete(rKNpuHsJvWEBmylXAnikzFaDtgbVPo.main_params)
  elif rKNpuHsJvWEBmylXAnikzFaDtgbVUx in['TOTAL_SEARCH','TOTAL_HISTORY']:
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.dp_Global_Search(rKNpuHsJvWEBmylXAnikzFaDtgbVPo.main_params)
  elif rKNpuHsJvWEBmylXAnikzFaDtgbVUx=='MENU_BOOKMARK':
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.dp_Bookmark_Menu(rKNpuHsJvWEBmylXAnikzFaDtgbVPo.main_params)
  elif rKNpuHsJvWEBmylXAnikzFaDtgbVUx=='SET_BOOKMARK':
   rKNpuHsJvWEBmylXAnikzFaDtgbVPo.dp_Set_Bookmark(rKNpuHsJvWEBmylXAnikzFaDtgbVPo.main_params)
  else:
   rKNpuHsJvWEBmylXAnikzFaDtgbVcx
# Created by pyminifier (https://github.com/liftoff/pyminifier)
