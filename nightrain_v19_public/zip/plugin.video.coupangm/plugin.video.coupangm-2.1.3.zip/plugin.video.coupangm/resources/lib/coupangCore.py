__author__="NightRain"
rPypWKNdoQlAxvIHwbCBqnRgcMTOEf=object
rPypWKNdoQlAxvIHwbCBqnRgcMTOEt=None
rPypWKNdoQlAxvIHwbCBqnRgcMTOEm=False
rPypWKNdoQlAxvIHwbCBqnRgcMTOEL=print
rPypWKNdoQlAxvIHwbCBqnRgcMTOEV=str
rPypWKNdoQlAxvIHwbCBqnRgcMTOEY=open
rPypWKNdoQlAxvIHwbCBqnRgcMTOEh=int
rPypWKNdoQlAxvIHwbCBqnRgcMTOEU=Exception
rPypWKNdoQlAxvIHwbCBqnRgcMTOEi=id
rPypWKNdoQlAxvIHwbCBqnRgcMTOEJ=True
rPypWKNdoQlAxvIHwbCBqnRgcMTOEX=len
rPypWKNdoQlAxvIHwbCBqnRgcMTOEe=range
import urllib
import re
import json
import requests
import datetime
import time
import random
import base64
class rPypWKNdoQlAxvIHwbCBqnRgcMTOza(rPypWKNdoQlAxvIHwbCBqnRgcMTOEf):
 def __init__(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF):
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36'
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.MODEL ='Chrome_119' 
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.OS_VERSION ='119' 
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.DEFAULT_HEADER ={'user-agent':rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.USER_AGENT}
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.API_DOMAIN ='https://www.coupangplay.com'
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.API_VIEWURL ='https://discover.coupangstreaming.com'
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.PAGE_LIMIT =40
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.SEARCH_LIMIT =20
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.KodiVersion =20
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP={}
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.Init_CP()
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP_DEVICE_FILENAME=''
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP_COOKIE_FILENAME=''
 def callRequestCookies(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF,jobtype,rPypWKNdoQlAxvIHwbCBqnRgcMTOaF,payload=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,params=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,headers=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,cookies=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,redirects=rPypWKNdoQlAxvIHwbCBqnRgcMTOEm):
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzE=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.DEFAULT_HEADER
  if headers:rPypWKNdoQlAxvIHwbCBqnRgcMTOzE.update(headers)
  if jobtype=='Get':
   rPypWKNdoQlAxvIHwbCBqnRgcMTOzG=requests.get(rPypWKNdoQlAxvIHwbCBqnRgcMTOaF,params=params,headers=rPypWKNdoQlAxvIHwbCBqnRgcMTOzE,cookies=cookies,allow_redirects=redirects)
  else:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOzG=requests.post(rPypWKNdoQlAxvIHwbCBqnRgcMTOaF,data=payload,params=params,headers=rPypWKNdoQlAxvIHwbCBqnRgcMTOzE,cookies=cookies,allow_redirects=redirects)
  rPypWKNdoQlAxvIHwbCBqnRgcMTOEL(rPypWKNdoQlAxvIHwbCBqnRgcMTOEV(rPypWKNdoQlAxvIHwbCBqnRgcMTOzG.status_code)+' - '+rPypWKNdoQlAxvIHwbCBqnRgcMTOEV(rPypWKNdoQlAxvIHwbCBqnRgcMTOzG.url))
  return rPypWKNdoQlAxvIHwbCBqnRgcMTOzG
 def callRequestCookies_test(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF,jobtype,rPypWKNdoQlAxvIHwbCBqnRgcMTOaF,payload=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,params=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,headers=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,cookies=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,redirects=rPypWKNdoQlAxvIHwbCBqnRgcMTOEm):
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzE=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.DEFAULT_HEADER
  if headers:rPypWKNdoQlAxvIHwbCBqnRgcMTOzE.update(headers)
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzG=requests.Request('POST',rPypWKNdoQlAxvIHwbCBqnRgcMTOaF,headers=headers,data=payload,params=params,cookies=cookies)
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzu=rPypWKNdoQlAxvIHwbCBqnRgcMTOzG.prepare()
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.pretty_print_POST(rPypWKNdoQlAxvIHwbCBqnRgcMTOzu)
  return rPypWKNdoQlAxvIHwbCBqnRgcMTOzG
 def pretty_print_POST(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF,req):
  rPypWKNdoQlAxvIHwbCBqnRgcMTOEL('{}\n{}\r\n{}\r\n\r\n{}'.format('-----------START-----------',req.method+' '+req.url,'\r\n'.join('{}: {}'.format(k,v)for k,v in req.headers.items()),req.body,))
 def dic_To_jsonfile(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF,filename,rPypWKNdoQlAxvIHwbCBqnRgcMTOzS):
  if filename=='':return
  fp=rPypWKNdoQlAxvIHwbCBqnRgcMTOEY(filename,'w',-1,'utf-8')
  json.dump(rPypWKNdoQlAxvIHwbCBqnRgcMTOzS,fp,indent=4,ensure_ascii=rPypWKNdoQlAxvIHwbCBqnRgcMTOEm)
  fp.close()
 def jsonfile_To_dic(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF,filename):
  if filename=='':return rPypWKNdoQlAxvIHwbCBqnRgcMTOEt
  try:
   fp=rPypWKNdoQlAxvIHwbCBqnRgcMTOEY(filename,'r',-1,'utf-8')
   rPypWKNdoQlAxvIHwbCBqnRgcMTOzs=json.load(fp)
   fp.close()
  except:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOzs={}
  return rPypWKNdoQlAxvIHwbCBqnRgcMTOzs
 def convert_TimeStr(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF,rPypWKNdoQlAxvIHwbCBqnRgcMTOzD):
  try:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOzD =rPypWKNdoQlAxvIHwbCBqnRgcMTOzD[0:16]
   rPypWKNdoQlAxvIHwbCBqnRgcMTOzk=datetime.datetime.strptime(rPypWKNdoQlAxvIHwbCBqnRgcMTOzD,'%Y-%m-%dT%H:%M')+datetime.timedelta(hours=9)
   return rPypWKNdoQlAxvIHwbCBqnRgcMTOzk.strftime('%Y-%m-%d %H:%M')
  except:
   return rPypWKNdoQlAxvIHwbCBqnRgcMTOEt
 def Get_Now_Datetime(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetNoCache(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF):
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzt =rPypWKNdoQlAxvIHwbCBqnRgcMTOEh(time.time()*1000)
  return rPypWKNdoQlAxvIHwbCBqnRgcMTOzt
 def generatePcId(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF):
  t=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.GetNoCache()
  r=random.random()
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzm=rPypWKNdoQlAxvIHwbCBqnRgcMTOEV(t)+rPypWKNdoQlAxvIHwbCBqnRgcMTOEV(r)[2:12]
  return rPypWKNdoQlAxvIHwbCBqnRgcMTOzm
 def generatePvId(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF,genType='1'):
  import hashlib
  m=hashlib.md5()
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzL=rPypWKNdoQlAxvIHwbCBqnRgcMTOEV(random.random())
  m.update(rPypWKNdoQlAxvIHwbCBqnRgcMTOzL.encode('utf-8'))
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzV=rPypWKNdoQlAxvIHwbCBqnRgcMTOEV(m.hexdigest())
  if genType=='1':
   return '%s-%s-%s-%s-%s'%(rPypWKNdoQlAxvIHwbCBqnRgcMTOzV[:8],rPypWKNdoQlAxvIHwbCBqnRgcMTOzV[8:12],rPypWKNdoQlAxvIHwbCBqnRgcMTOzV[12:16],rPypWKNdoQlAxvIHwbCBqnRgcMTOzV[16:20],rPypWKNdoQlAxvIHwbCBqnRgcMTOzV[20:])
  else:
   return rPypWKNdoQlAxvIHwbCBqnRgcMTOzV
 def Get_DeviceID(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF):
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzY=''
  try: 
   fp=rPypWKNdoQlAxvIHwbCBqnRgcMTOEY(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP_DEVICE_FILENAME,'r',-1,'utf-8')
   rPypWKNdoQlAxvIHwbCBqnRgcMTOzh= json.load(fp)
   fp.close()
   rPypWKNdoQlAxvIHwbCBqnRgcMTOzY=rPypWKNdoQlAxvIHwbCBqnRgcMTOzh.get('device_id')
  except rPypWKNdoQlAxvIHwbCBqnRgcMTOEU as exception:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOEt
  if rPypWKNdoQlAxvIHwbCBqnRgcMTOzY=='':
   rPypWKNdoQlAxvIHwbCBqnRgcMTOzY=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.generatePvId(genType='1')
   try: 
    fp=rPypWKNdoQlAxvIHwbCBqnRgcMTOEY(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP_DEVICE_FILENAME,'w',-1,'utf-8')
    json.dump({'device_id':rPypWKNdoQlAxvIHwbCBqnRgcMTOzY},fp,indent=4,ensure_ascii=rPypWKNdoQlAxvIHwbCBqnRgcMTOEm)
    fp.close()
   except rPypWKNdoQlAxvIHwbCBqnRgcMTOEU as exception:
    return ''
  return rPypWKNdoQlAxvIHwbCBqnRgcMTOzY
 def Make_authHeader(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF):
  tr=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.generatePvId(genType=2)
  ti=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.GetNoCache()
  rPypWKNdoQlAxvIHwbCBqnRgcMTOEi=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.generatePvId(genType=2)[:16]
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzU='00-%s-%s-01'%(tr,rPypWKNdoQlAxvIHwbCBqnRgcMTOEi,)
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzi ='%s@nr=0-1-%s-%s-%s----%s'%(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['SESSION']['NREUM']['tk'],rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['SESSION']['NREUM']['ac'],rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['SESSION']['NREUM']['ap'],rPypWKNdoQlAxvIHwbCBqnRgcMTOEi,ti,)
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzJ ='{"v":[0,1],"d":{"ty":"Browser","ac":"%s","ap":"%s","id":"%s","tr":"%s","ti":%s,"tk":"%s"}}'%(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['SESSION']['NREUM']['ac'],rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['SESSION']['NREUM']['ap'],rPypWKNdoQlAxvIHwbCBqnRgcMTOEi,tr,ti,rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['SESSION']['NREUM']['tk'],) 
  return rPypWKNdoQlAxvIHwbCBqnRgcMTOzU,rPypWKNdoQlAxvIHwbCBqnRgcMTOzi,base64.standard_b64encode(rPypWKNdoQlAxvIHwbCBqnRgcMTOzJ.encode()).decode('utf-8')
 def Init_CP(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF):
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP={}
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['ACCOUNT']={'cpid':'','cppw':'','cppf':'0'}
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['SESSION']={}
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['COOKIES']={}
 def Save_session_acount(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF,rPypWKNdoQlAxvIHwbCBqnRgcMTOzX,rPypWKNdoQlAxvIHwbCBqnRgcMTOze,rPypWKNdoQlAxvIHwbCBqnRgcMTOaz):
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['ACCOUNT']['cpid']=base64.standard_b64encode(rPypWKNdoQlAxvIHwbCBqnRgcMTOzX.encode()).decode('utf-8')
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['ACCOUNT']['cppw']=base64.standard_b64encode(rPypWKNdoQlAxvIHwbCBqnRgcMTOze.encode()).decode('utf-8')
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['ACCOUNT']['cppf']=rPypWKNdoQlAxvIHwbCBqnRgcMTOEV(rPypWKNdoQlAxvIHwbCBqnRgcMTOaz)
 def Load_session_acount(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF):
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzX=base64.standard_b64decode(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['ACCOUNT']['cpid']).decode('utf-8')
  rPypWKNdoQlAxvIHwbCBqnRgcMTOze=base64.standard_b64decode(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['ACCOUNT']['cppw']).decode('utf-8')
  rPypWKNdoQlAxvIHwbCBqnRgcMTOaz=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['ACCOUNT']['cppf']
  return rPypWKNdoQlAxvIHwbCBqnRgcMTOzX,rPypWKNdoQlAxvIHwbCBqnRgcMTOze,rPypWKNdoQlAxvIHwbCBqnRgcMTOaz
 def make_CP_DefaultCookies(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF):
  return rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['COOKIES']
 def Get_CP_Login(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF,userid,userpw,rPypWKNdoQlAxvIHwbCBqnRgcMTOam):
  try:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaF=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.API_DOMAIN
   rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['COOKIES']['NEXT_LOCALE']='ko'
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaE={'Accept-Language':'ko-KR,ko;q=0.9','Sec-Ch-Ua-Mobile':'?0','Sec-Ch-Ua-Platform':'"Windows"','Sec-Fetch-Dest':'document','Sec-Fetch-Mode':'navigate','Sec-Fetch-Site':'none','Sec-Fetch-User':'?1','Upgrade-Insecure-Requests':'1',}
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaG=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.make_CP_DefaultCookies()
   rPypWKNdoQlAxvIHwbCBqnRgcMTOau=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.callRequestCookies('Get',rPypWKNdoQlAxvIHwbCBqnRgcMTOaF,payload=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,params=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,headers=rPypWKNdoQlAxvIHwbCBqnRgcMTOaE,cookies=rPypWKNdoQlAxvIHwbCBqnRgcMTOaG,redirects=rPypWKNdoQlAxvIHwbCBqnRgcMTOEJ)
   if rPypWKNdoQlAxvIHwbCBqnRgcMTOau.status_code not in[200]:return rPypWKNdoQlAxvIHwbCBqnRgcMTOEm
   for rPypWKNdoQlAxvIHwbCBqnRgcMTOaS in rPypWKNdoQlAxvIHwbCBqnRgcMTOau.cookies:
    rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['COOKIES'][rPypWKNdoQlAxvIHwbCBqnRgcMTOaS.name]=rPypWKNdoQlAxvIHwbCBqnRgcMTOaS.value
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaG=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.make_CP_DefaultCookies()
   if rPypWKNdoQlAxvIHwbCBqnRgcMTOau.status_code not in[200]:return rPypWKNdoQlAxvIHwbCBqnRgcMTOEm
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaj=re.findall('NREUM.loader_config=\{[\w\d\":,-]+\}',rPypWKNdoQlAxvIHwbCBqnRgcMTOau.text)[0].split('=')[1]
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaj=rPypWKNdoQlAxvIHwbCBqnRgcMTOaj.replace('{','{"').replace(':','":').replace(',',',"')
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaj=json.loads(rPypWKNdoQlAxvIHwbCBqnRgcMTOaj)
   rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['SESSION']['NREUM']={'ac':rPypWKNdoQlAxvIHwbCBqnRgcMTOaj['accountID'],'tk':rPypWKNdoQlAxvIHwbCBqnRgcMTOaj['trustKey'],'ap':rPypWKNdoQlAxvIHwbCBqnRgcMTOaj['agentID'],'lk':rPypWKNdoQlAxvIHwbCBqnRgcMTOaj['licenseKey'],}
  except rPypWKNdoQlAxvIHwbCBqnRgcMTOEU as exception:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOEL(exception)
   return rPypWKNdoQlAxvIHwbCBqnRgcMTOEm
  try:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaF=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.API_DOMAIN+'/api/auth'
   rPypWKNdoQlAxvIHwbCBqnRgcMTOas=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.Get_DeviceID()
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaD =rPypWKNdoQlAxvIHwbCBqnRgcMTOas.split('-')[0]
   rPypWKNdoQlAxvIHwbCBqnRgcMTOzU,rPypWKNdoQlAxvIHwbCBqnRgcMTOzi,rPypWKNdoQlAxvIHwbCBqnRgcMTOzJ=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.Make_authHeader()
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaE={'traceparent':rPypWKNdoQlAxvIHwbCBqnRgcMTOzU,'tracestate':rPypWKNdoQlAxvIHwbCBqnRgcMTOzi,'newrelic':rPypWKNdoQlAxvIHwbCBqnRgcMTOzJ,'content-type':'application/json','x-app-version':'1.26.1','x-device-id':'','x-device-os-version':rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.OS_VERSION,'x-nr-session-id':rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['COOKIES']['session_web_id'],'x-pcid':'',}
   rPypWKNdoQlAxvIHwbCBqnRgcMTOak={'device':{'deviceId':'web-'+rPypWKNdoQlAxvIHwbCBqnRgcMTOas,'model':rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.MODEL,'name':'Chrome Desktop '+rPypWKNdoQlAxvIHwbCBqnRgcMTOaD,'os':'Windows','osVersion':'10','type':'webclient',},'email':userid,'password':userpw,}
   rPypWKNdoQlAxvIHwbCBqnRgcMTOak=json.dumps(rPypWKNdoQlAxvIHwbCBqnRgcMTOak,separators=(',',':'))
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaG=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.make_CP_DefaultCookies()
   rPypWKNdoQlAxvIHwbCBqnRgcMTOau=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.callRequestCookies('Post',rPypWKNdoQlAxvIHwbCBqnRgcMTOaF,payload=rPypWKNdoQlAxvIHwbCBqnRgcMTOak,params=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,headers=rPypWKNdoQlAxvIHwbCBqnRgcMTOaE,cookies=rPypWKNdoQlAxvIHwbCBqnRgcMTOaG,redirects=rPypWKNdoQlAxvIHwbCBqnRgcMTOEm)
   if rPypWKNdoQlAxvIHwbCBqnRgcMTOau.status_code not in[200]:
    rPypWKNdoQlAxvIHwbCBqnRgcMTOaf=json.loads(rPypWKNdoQlAxvIHwbCBqnRgcMTOau.text)
    if 'error' in rPypWKNdoQlAxvIHwbCBqnRgcMTOaf:
     rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['SESSION']['error']=rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('error').get('detail')
    return rPypWKNdoQlAxvIHwbCBqnRgcMTOEm
   rPypWKNdoQlAxvIHwbCBqnRgcMTOEL('---')
   for rPypWKNdoQlAxvIHwbCBqnRgcMTOaS in rPypWKNdoQlAxvIHwbCBqnRgcMTOau.cookies:
    rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['COOKIES'][rPypWKNdoQlAxvIHwbCBqnRgcMTOaS.name]=rPypWKNdoQlAxvIHwbCBqnRgcMTOaS.value
  except rPypWKNdoQlAxvIHwbCBqnRgcMTOEU as exception:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOEL(exception)
   return rPypWKNdoQlAxvIHwbCBqnRgcMTOEm
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.Save_session_acount(userid,userpw,rPypWKNdoQlAxvIHwbCBqnRgcMTOam)
  return rPypWKNdoQlAxvIHwbCBqnRgcMTOEJ
 def Get_CP_profile(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF,rPypWKNdoQlAxvIHwbCBqnRgcMTOam,limit_days=1,re_check=rPypWKNdoQlAxvIHwbCBqnRgcMTOEm):
  if re_check==rPypWKNdoQlAxvIHwbCBqnRgcMTOEJ:
   if rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['SESSION']['bm_sv_ex']>rPypWKNdoQlAxvIHwbCBqnRgcMTOEh(time.time()):
    rPypWKNdoQlAxvIHwbCBqnRgcMTOEL('bm_sv_ex ok')
    return rPypWKNdoQlAxvIHwbCBqnRgcMTOEJ
  try:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaF=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.API_DOMAIN+'/api/profiles'
   rPypWKNdoQlAxvIHwbCBqnRgcMTOzU,rPypWKNdoQlAxvIHwbCBqnRgcMTOzi,rPypWKNdoQlAxvIHwbCBqnRgcMTOzJ=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.Make_authHeader()
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaE={'traceparent':rPypWKNdoQlAxvIHwbCBqnRgcMTOzU,'tracestate':rPypWKNdoQlAxvIHwbCBqnRgcMTOzi,'newrelic':rPypWKNdoQlAxvIHwbCBqnRgcMTOzJ,'x-app-version':'1.26.1','x-device-id':'','x-device-os-version':rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.OS_VERSION,'x-nr-session-id':rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['COOKIES']['session_web_id'],'x-pcid':'',}
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaG=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.make_CP_DefaultCookies()
   rPypWKNdoQlAxvIHwbCBqnRgcMTOau=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.callRequestCookies('Get',rPypWKNdoQlAxvIHwbCBqnRgcMTOaF,payload=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,params=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,headers=rPypWKNdoQlAxvIHwbCBqnRgcMTOaE,cookies=rPypWKNdoQlAxvIHwbCBqnRgcMTOaG,redirects=rPypWKNdoQlAxvIHwbCBqnRgcMTOEJ)
   if rPypWKNdoQlAxvIHwbCBqnRgcMTOau.status_code not in[200]:return rPypWKNdoQlAxvIHwbCBqnRgcMTOEm
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaf=json.loads(rPypWKNdoQlAxvIHwbCBqnRgcMTOau.text)
   rPypWKNdoQlAxvIHwbCBqnRgcMTOat=0
   for rPypWKNdoQlAxvIHwbCBqnRgcMTOaS in rPypWKNdoQlAxvIHwbCBqnRgcMTOau.cookies:
    rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['COOKIES'][rPypWKNdoQlAxvIHwbCBqnRgcMTOaS.name]=rPypWKNdoQlAxvIHwbCBqnRgcMTOaS.value
    if rPypWKNdoQlAxvIHwbCBqnRgcMTOaS.name=='bm_sv':
     rPypWKNdoQlAxvIHwbCBqnRgcMTOat=1
     rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['SESSION']['bm_sv_ex']=rPypWKNdoQlAxvIHwbCBqnRgcMTOaS.expires 
   if rPypWKNdoQlAxvIHwbCBqnRgcMTOat==0:
    rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['SESSION']['bm_sv_ex']=rPypWKNdoQlAxvIHwbCBqnRgcMTOEh(time.time())+60*60*2 
   rPypWKNdoQlAxvIHwbCBqnRgcMTOam=rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('data')[rPypWKNdoQlAxvIHwbCBqnRgcMTOEh(rPypWKNdoQlAxvIHwbCBqnRgcMTOam)]
   rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['SESSION']['accountId']=rPypWKNdoQlAxvIHwbCBqnRgcMTOam.get('accountId')
   rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['SESSION']['profileId']=rPypWKNdoQlAxvIHwbCBqnRgcMTOam.get('profileId')
  except rPypWKNdoQlAxvIHwbCBqnRgcMTOEU as exception:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOEL(exception)
   return rPypWKNdoQlAxvIHwbCBqnRgcMTOEm
  if re_check==rPypWKNdoQlAxvIHwbCBqnRgcMTOEm:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaL =rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.Get_Now_Datetime()
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaV=rPypWKNdoQlAxvIHwbCBqnRgcMTOaL+datetime.timedelta(days=limit_days)
   rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['SESSION']['limitdate']=rPypWKNdoQlAxvIHwbCBqnRgcMTOaV.strftime('%Y-%m-%d')
  else:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOEL('re check')
  rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.dic_To_jsonfile(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP_COOKIE_FILENAME,rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP)
  return rPypWKNdoQlAxvIHwbCBqnRgcMTOEJ
 def Get_Category_GroupList(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF,vType):
  rPypWKNdoQlAxvIHwbCBqnRgcMTOaY=[] 
  try:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaF=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.API_VIEWURL+'/v2/discover/feed' 
   rPypWKNdoQlAxvIHwbCBqnRgcMTOah={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false',}
   rPypWKNdoQlAxvIHwbCBqnRgcMTOau=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.callRequestCookies('Get',rPypWKNdoQlAxvIHwbCBqnRgcMTOaF,payload=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,params=rPypWKNdoQlAxvIHwbCBqnRgcMTOah,headers=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,cookies=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,redirects=rPypWKNdoQlAxvIHwbCBqnRgcMTOEJ)
   if rPypWKNdoQlAxvIHwbCBqnRgcMTOau.status_code not in[200]:return[]
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaf=json.loads(rPypWKNdoQlAxvIHwbCBqnRgcMTOau.text)
   if vType in['TVSHOWS','MOVIES']:
    rPypWKNdoQlAxvIHwbCBqnRgcMTOaU='Explores' 
   elif vType in['EDUCATION']:
    rPypWKNdoQlAxvIHwbCBqnRgcMTOaU='Collection-Rails-Curation'
   elif vType in['ALL','KIDS']:
    rPypWKNdoQlAxvIHwbCBqnRgcMTOaU='Explores-Categories'
   for rPypWKNdoQlAxvIHwbCBqnRgcMTOai in rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('data'):
    if rPypWKNdoQlAxvIHwbCBqnRgcMTOai.get('type')==rPypWKNdoQlAxvIHwbCBqnRgcMTOaU:
     for rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ in rPypWKNdoQlAxvIHwbCBqnRgcMTOai.get('data'):
      if vType in['TVSHOWS','MOVIES']:
       rPypWKNdoQlAxvIHwbCBqnRgcMTOaX=rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('collectionId')
      elif vType in['EDUCATION','ALL','KIDS']:
       rPypWKNdoQlAxvIHwbCBqnRgcMTOaX=rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('id')
      rPypWKNdoQlAxvIHwbCBqnRgcMTOae={'collectionId':rPypWKNdoQlAxvIHwbCBqnRgcMTOaX,'title':rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('name'),'category':rPypWKNdoQlAxvIHwbCBqnRgcMTOai.get('category'),'pre_title':'',}
      rPypWKNdoQlAxvIHwbCBqnRgcMTOaY.append(rPypWKNdoQlAxvIHwbCBqnRgcMTOae)
     break
  except rPypWKNdoQlAxvIHwbCBqnRgcMTOEU as exception:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOEL(exception)
   return[]
  return rPypWKNdoQlAxvIHwbCBqnRgcMTOaY
 def Get_Category_List(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF,vType,rPypWKNdoQlAxvIHwbCBqnRgcMTOaX,page_int):
  rPypWKNdoQlAxvIHwbCBqnRgcMTOaY=[] 
  rPypWKNdoQlAxvIHwbCBqnRgcMTOFz=rPypWKNdoQlAxvIHwbCBqnRgcMTOEm
  try:
   if vType in['ALL','KIDS']:
    rPypWKNdoQlAxvIHwbCBqnRgcMTOaE={'x-membersrl':rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['COOKIES']['member_srl'],'x-pcid':rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['COOKIES']['PCID'],'x-profileid':rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['SESSION']['profileId'],}
    rPypWKNdoQlAxvIHwbCBqnRgcMTOah={'platform':'WEBCLIENT','page':rPypWKNdoQlAxvIHwbCBqnRgcMTOEV(page_int),'perPage':rPypWKNdoQlAxvIHwbCBqnRgcMTOEV(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.PAGE_LIMIT),'locale':'ko','sort':'',}
    rPypWKNdoQlAxvIHwbCBqnRgcMTOaF=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.API_VIEWURL+'/v1/discover/categories/'+rPypWKNdoQlAxvIHwbCBqnRgcMTOaX+'/titles'
    rPypWKNdoQlAxvIHwbCBqnRgcMTOau=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.callRequestCookies('Get',rPypWKNdoQlAxvIHwbCBqnRgcMTOaF,payload=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,params=rPypWKNdoQlAxvIHwbCBqnRgcMTOah,headers=rPypWKNdoQlAxvIHwbCBqnRgcMTOaE,cookies=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,redirects=rPypWKNdoQlAxvIHwbCBqnRgcMTOEJ)
   else: 
    rPypWKNdoQlAxvIHwbCBqnRgcMTOah={'platform':'WEBCLIENT','page':rPypWKNdoQlAxvIHwbCBqnRgcMTOEV(page_int),'perPage':rPypWKNdoQlAxvIHwbCBqnRgcMTOEV(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.PAGE_LIMIT),}
    rPypWKNdoQlAxvIHwbCBqnRgcMTOaF=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.API_VIEWURL+'/v1/discover/collections/'+rPypWKNdoQlAxvIHwbCBqnRgcMTOaX+'/titles'
    rPypWKNdoQlAxvIHwbCBqnRgcMTOau=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.callRequestCookies('Get',rPypWKNdoQlAxvIHwbCBqnRgcMTOaF,payload=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,params=rPypWKNdoQlAxvIHwbCBqnRgcMTOah,headers=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,cookies=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,redirects=rPypWKNdoQlAxvIHwbCBqnRgcMTOEJ)
   if rPypWKNdoQlAxvIHwbCBqnRgcMTOau.status_code not in[200]:return[],rPypWKNdoQlAxvIHwbCBqnRgcMTOEm
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaf=json.loads(rPypWKNdoQlAxvIHwbCBqnRgcMTOau.text)
   if vType in['ALL','KIDS']:
    rPypWKNdoQlAxvIHwbCBqnRgcMTOFa=rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('data').get('data')
   else:
    rPypWKNdoQlAxvIHwbCBqnRgcMTOFa=rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('data')
   for rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ in rPypWKNdoQlAxvIHwbCBqnRgcMTOFa:
    rPypWKNdoQlAxvIHwbCBqnRgcMTOFE=rPypWKNdoQlAxvIHwbCBqnRgcMTOFs=rPypWKNdoQlAxvIHwbCBqnRgcMTOEj=rPypWKNdoQlAxvIHwbCBqnRgcMTOES=''
    if 'poster' in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('images'):rPypWKNdoQlAxvIHwbCBqnRgcMTOFE =rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('images'):rPypWKNdoQlAxvIHwbCBqnRgcMTOFs =rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('images').get('story-art').get('url') +'?imwidth=600'
    if 'title-treatment' in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('images'):rPypWKNdoQlAxvIHwbCBqnRgcMTOEj=rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('images').get('title-treatment').get('url')+'?imwidth=300'
    if 'story-art' in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('images'):rPypWKNdoQlAxvIHwbCBqnRgcMTOES =rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('images').get('story-art').get('url') +'?imwidth=600'
    rPypWKNdoQlAxvIHwbCBqnRgcMTOFG=''
    if rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('badge')not in[{},rPypWKNdoQlAxvIHwbCBqnRgcMTOEt]:
     for i in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('badge').get('text'):
      rPypWKNdoQlAxvIHwbCBqnRgcMTOFG+=i.get('text')
    rPypWKNdoQlAxvIHwbCBqnRgcMTOFu=''
    if rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('seasonList')!=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt:
     rPypWKNdoQlAxvIHwbCBqnRgcMTOFu=','.join(rPypWKNdoQlAxvIHwbCBqnRgcMTOEV(e)for e in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('seasonList'))
    rPypWKNdoQlAxvIHwbCBqnRgcMTOFS =[]
    for rPypWKNdoQlAxvIHwbCBqnRgcMTOFj in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('tags'):
     rPypWKNdoQlAxvIHwbCBqnRgcMTOFS.append(rPypWKNdoQlAxvIHwbCBqnRgcMTOFj.get('tag'))
    rPypWKNdoQlAxvIHwbCBqnRgcMTOae={'id':rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('id'),'title':rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('title'),'thumbnail':{'poster':rPypWKNdoQlAxvIHwbCBqnRgcMTOFE,'thumb':rPypWKNdoQlAxvIHwbCBqnRgcMTOFs,'clearlogo':rPypWKNdoQlAxvIHwbCBqnRgcMTOEj,'fanart':rPypWKNdoQlAxvIHwbCBqnRgcMTOES},'mpaa':rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('age_rating'),'duration':rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('running_time'),'asis':rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('as'),'badge':rPypWKNdoQlAxvIHwbCBqnRgcMTOFG,'year':rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('meta').get('releaseYear'),'seasonList':rPypWKNdoQlAxvIHwbCBqnRgcMTOFu,'genreList':rPypWKNdoQlAxvIHwbCBqnRgcMTOFS,}
    rPypWKNdoQlAxvIHwbCBqnRgcMTOaY.append(rPypWKNdoQlAxvIHwbCBqnRgcMTOae)
   if rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('pagination').get('totalPages')>page_int:
    rPypWKNdoQlAxvIHwbCBqnRgcMTOFz=rPypWKNdoQlAxvIHwbCBqnRgcMTOEJ
  except rPypWKNdoQlAxvIHwbCBqnRgcMTOEU as exception:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOEL(exception)
   return[],rPypWKNdoQlAxvIHwbCBqnRgcMTOEm
  return rPypWKNdoQlAxvIHwbCBqnRgcMTOaY,rPypWKNdoQlAxvIHwbCBqnRgcMTOFz
 def Get_Episode_List(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF,programId,season):
  rPypWKNdoQlAxvIHwbCBqnRgcMTOaY=[] 
  try:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaF=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.API_VIEWURL+'/v1/discover/titles/'+programId+'/episodes'
   rPypWKNdoQlAxvIHwbCBqnRgcMTOah={'season':season,'sort':'true','locale':'ko',}
   rPypWKNdoQlAxvIHwbCBqnRgcMTOau=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.callRequestCookies('Get',rPypWKNdoQlAxvIHwbCBqnRgcMTOaF,payload=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,params=rPypWKNdoQlAxvIHwbCBqnRgcMTOah,headers=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,cookies=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,redirects=rPypWKNdoQlAxvIHwbCBqnRgcMTOEJ)
   if rPypWKNdoQlAxvIHwbCBqnRgcMTOau.status_code not in[200]:return[]
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaf=json.loads(rPypWKNdoQlAxvIHwbCBqnRgcMTOau.text)
   for rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ in rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('data'):
    rPypWKNdoQlAxvIHwbCBqnRgcMTOFs=''
    if 'story-art' in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('images'):rPypWKNdoQlAxvIHwbCBqnRgcMTOFs =rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('images').get('story-art').get('url')+'?imwidth=600'
    rPypWKNdoQlAxvIHwbCBqnRgcMTOFS =[]
    for rPypWKNdoQlAxvIHwbCBqnRgcMTOFj in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('tags'):
     rPypWKNdoQlAxvIHwbCBqnRgcMTOFS.append(rPypWKNdoQlAxvIHwbCBqnRgcMTOFj.get('tag'))
    rPypWKNdoQlAxvIHwbCBqnRgcMTOae={'id':rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('id'),'title':rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('title'),'thumbnail':{'thumb':rPypWKNdoQlAxvIHwbCBqnRgcMTOFs,'fanart':rPypWKNdoQlAxvIHwbCBqnRgcMTOFs},'mpaa':rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('age_rating'),'duration':rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('running_time'),'asis':rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('as'),'year':rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('meta').get('releaseYear'),'episode':rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('episode'),'genreList':rPypWKNdoQlAxvIHwbCBqnRgcMTOFS,'desc':rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('description'),}
    rPypWKNdoQlAxvIHwbCBqnRgcMTOaY.append(rPypWKNdoQlAxvIHwbCBqnRgcMTOae)
  except rPypWKNdoQlAxvIHwbCBqnRgcMTOEU as exception:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOEL(exception)
   return[]
  return rPypWKNdoQlAxvIHwbCBqnRgcMTOaY
 def Get_vInfo(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF,titleId):
  try:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaF=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.API_VIEWURL+'/v1/discover/titles/'+titleId 
   rPypWKNdoQlAxvIHwbCBqnRgcMTOah={'platform':'WEBCLIENT','locale':'ko','filterRestrictedContent':'false',}
   rPypWKNdoQlAxvIHwbCBqnRgcMTOau=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.callRequestCookies('Get',rPypWKNdoQlAxvIHwbCBqnRgcMTOaF,payload=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,params=rPypWKNdoQlAxvIHwbCBqnRgcMTOah,headers=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,cookies=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,redirects=rPypWKNdoQlAxvIHwbCBqnRgcMTOEJ)
   if rPypWKNdoQlAxvIHwbCBqnRgcMTOau.status_code not in[200]:return '','',''
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaf=json.loads(rPypWKNdoQlAxvIHwbCBqnRgcMTOau.text).get('data')
   rPypWKNdoQlAxvIHwbCBqnRgcMTOFu=''
   if rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('seasonList')!=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt:
    rPypWKNdoQlAxvIHwbCBqnRgcMTOFu=','.join(rPypWKNdoQlAxvIHwbCBqnRgcMTOEV(e)for e in rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('seasonList'))
   rPypWKNdoQlAxvIHwbCBqnRgcMTOFD={'age_rating':rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('age_rating'),'asset_id':rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('asset_id'),'availability':rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('availability'),'deal_id':rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('deal_id'),'downloadable':'true' if rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('downloadable')else 'false','region':rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('region'),'streamable':'true' if rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('streamable')else 'false','asis':rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('as'),'seasonList':rPypWKNdoQlAxvIHwbCBqnRgcMTOFu}
  except rPypWKNdoQlAxvIHwbCBqnRgcMTOEU as exception:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOEL(exception)
   return{}
  return rPypWKNdoQlAxvIHwbCBqnRgcMTOFD
 def Get_eInfo(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF,eventId):
  try:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaF=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.API_VIEWURL+'/v1/discover/events/'+eventId 
   rPypWKNdoQlAxvIHwbCBqnRgcMTOah={'locale':'ko'}
   rPypWKNdoQlAxvIHwbCBqnRgcMTOau=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.callRequestCookies('Get',rPypWKNdoQlAxvIHwbCBqnRgcMTOaF,payload=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,params=rPypWKNdoQlAxvIHwbCBqnRgcMTOah,headers=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,cookies=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,redirects=rPypWKNdoQlAxvIHwbCBqnRgcMTOEJ)
   if rPypWKNdoQlAxvIHwbCBqnRgcMTOau.status_code not in[200]:return '','',''
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaf=json.loads(rPypWKNdoQlAxvIHwbCBqnRgcMTOau.text).get('data')
   rPypWKNdoQlAxvIHwbCBqnRgcMTOFD={'asset_id':rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('asset_id'),'deal_id':rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('deal_id'),'region':rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('region'),'streamable':'true' if rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('streamable')else 'false',}
  except rPypWKNdoQlAxvIHwbCBqnRgcMTOEU as exception:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOEL(exception)
   return{}
  return rPypWKNdoQlAxvIHwbCBqnRgcMTOFD
 def GetBroadURL(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF,titleId):
  rPypWKNdoQlAxvIHwbCBqnRgcMTOFk=''
  rPypWKNdoQlAxvIHwbCBqnRgcMTOFf =''
  rPypWKNdoQlAxvIHwbCBqnRgcMTOFD=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.Get_vInfo(titleId)
  if rPypWKNdoQlAxvIHwbCBqnRgcMTOFD=={}:return '',''
  try:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaF=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.API_DOMAIN+'/api/playback/play' 
   rPypWKNdoQlAxvIHwbCBqnRgcMTOah={'titleId':titleId}
   rPypWKNdoQlAxvIHwbCBqnRgcMTOzU,rPypWKNdoQlAxvIHwbCBqnRgcMTOzi,rPypWKNdoQlAxvIHwbCBqnRgcMTOzJ=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.Make_authHeader()
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaE={'traceparent':rPypWKNdoQlAxvIHwbCBqnRgcMTOzU,'tracestate':rPypWKNdoQlAxvIHwbCBqnRgcMTOzi,'newrelic':rPypWKNdoQlAxvIHwbCBqnRgcMTOzJ,'x-drm':'com.microsoft.playready','x-app-version':'1.33.5','x-device-id':'','x-device-os-version':rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.OS_VERSION,'x-force-raw':'true','x-nr-session-id':rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['COOKIES']['session_web_id'],'x-pcid':rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['COOKIES']['PCID'],'x-platform':'web','x-profileId':rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['SESSION']['profileId'],'x-profileType':'standard','x-sessionid':rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.generatePvId(genType='1'),'x-title-age-rating':rPypWKNdoQlAxvIHwbCBqnRgcMTOFD.get('age_rating'),'x-title-availability':rPypWKNdoQlAxvIHwbCBqnRgcMTOFD.get('availability'),'x-title-brightcove-id':rPypWKNdoQlAxvIHwbCBqnRgcMTOFD.get('asset_id'),'x-title-deal-id':rPypWKNdoQlAxvIHwbCBqnRgcMTOFD.get('deal_id'),'x-title-downloadable':rPypWKNdoQlAxvIHwbCBqnRgcMTOFD.get('downloadable'),'x-title-region':rPypWKNdoQlAxvIHwbCBqnRgcMTOFD.get('region'),'x-title-streamable':rPypWKNdoQlAxvIHwbCBqnRgcMTOFD.get('streamable'),}
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaG=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.make_CP_DefaultCookies()
   rPypWKNdoQlAxvIHwbCBqnRgcMTOau=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.callRequestCookies('Get',rPypWKNdoQlAxvIHwbCBqnRgcMTOaF,payload=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,params=rPypWKNdoQlAxvIHwbCBqnRgcMTOah,headers=rPypWKNdoQlAxvIHwbCBqnRgcMTOaE,cookies=rPypWKNdoQlAxvIHwbCBqnRgcMTOaG,redirects=rPypWKNdoQlAxvIHwbCBqnRgcMTOEJ)
   if rPypWKNdoQlAxvIHwbCBqnRgcMTOau.status_code not in[200]:return '',json.loads(rPypWKNdoQlAxvIHwbCBqnRgcMTOau.text).get('error').get('detail')
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaf=json.loads(rPypWKNdoQlAxvIHwbCBqnRgcMTOau.text)
   if rPypWKNdoQlAxvIHwbCBqnRgcMTOFk=='':
    for rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ in rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('data').get('raw').get('sources'):
     if 'key_systems' in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ and 'codecs' not in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ:
      if rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('type')=='application/dash+xml' and 'com.widevine.alpha' in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('key_systems')and rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('src').startswith('https://')==rPypWKNdoQlAxvIHwbCBqnRgcMTOEJ:
       rPypWKNdoQlAxvIHwbCBqnRgcMTOFk=rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('src')
       rPypWKNdoQlAxvIHwbCBqnRgcMTOFf =rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if rPypWKNdoQlAxvIHwbCBqnRgcMTOFk=='':
    for rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ in rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('data').get('raw').get('sources'):
     if 'key_systems' in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ and 'codecs' not in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ:
      if rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('key_systems')and rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('src').startswith('https://')==rPypWKNdoQlAxvIHwbCBqnRgcMTOEJ:
       rPypWKNdoQlAxvIHwbCBqnRgcMTOFk=rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('src')
       rPypWKNdoQlAxvIHwbCBqnRgcMTOFf =rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if rPypWKNdoQlAxvIHwbCBqnRgcMTOFk=='':
    for rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ in rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('data').get('raw').get('sources'):
     if 'key_systems' in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ and 'codecs' in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ:
      if rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('type')=='application/dash+xml' and 'com.widevine.alpha' in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('key_systems')and rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('src').startswith('https://')==rPypWKNdoQlAxvIHwbCBqnRgcMTOEJ:
       rPypWKNdoQlAxvIHwbCBqnRgcMTOFk=rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('src')
       rPypWKNdoQlAxvIHwbCBqnRgcMTOFf =rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if rPypWKNdoQlAxvIHwbCBqnRgcMTOFk=='':
    for rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ in rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('data').get('raw').get('sources'):
     if 'key_systems' in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ and 'codecs' in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ:
      if rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('key_systems')and rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('src').startswith('https://')==rPypWKNdoQlAxvIHwbCBqnRgcMTOEJ:
       rPypWKNdoQlAxvIHwbCBqnRgcMTOFk=rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('src')
       rPypWKNdoQlAxvIHwbCBqnRgcMTOFf =rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
  except rPypWKNdoQlAxvIHwbCBqnRgcMTOEU as exception:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOEL(exception)
   return '',''
  return rPypWKNdoQlAxvIHwbCBqnRgcMTOFk,rPypWKNdoQlAxvIHwbCBqnRgcMTOFf
 def GetEventURL(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF,eventId,rPypWKNdoQlAxvIHwbCBqnRgcMTOEz):
  rPypWKNdoQlAxvIHwbCBqnRgcMTOFk=''
  rPypWKNdoQlAxvIHwbCBqnRgcMTOFf =''
  rPypWKNdoQlAxvIHwbCBqnRgcMTOFD=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.Get_eInfo(eventId)
  if rPypWKNdoQlAxvIHwbCBqnRgcMTOFD=={}:return '',''
  try:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaF=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.API_DOMAIN+'/api/playback/play' 
   rPypWKNdoQlAxvIHwbCBqnRgcMTOah={'titleId':eventId,'titleType':rPypWKNdoQlAxvIHwbCBqnRgcMTOEz,}
   rPypWKNdoQlAxvIHwbCBqnRgcMTOzU,rPypWKNdoQlAxvIHwbCBqnRgcMTOzi,rPypWKNdoQlAxvIHwbCBqnRgcMTOzJ=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.Make_authHeader()
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaE={'traceparent':rPypWKNdoQlAxvIHwbCBqnRgcMTOzU,'tracestate':rPypWKNdoQlAxvIHwbCBqnRgcMTOzi,'newrelic':rPypWKNdoQlAxvIHwbCBqnRgcMTOzJ,'x-force-raw':'true','x-pcid':rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['COOKIES']['PCID'],'x-platform':'web','x-profileId':rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':rPypWKNdoQlAxvIHwbCBqnRgcMTOFD.get('asset_id'),'x-title-deal-id':rPypWKNdoQlAxvIHwbCBqnRgcMTOFD.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':rPypWKNdoQlAxvIHwbCBqnRgcMTOFD.get('region'),'x-title-streamable':rPypWKNdoQlAxvIHwbCBqnRgcMTOFD.get('streamable'),}
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaG=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.make_CP_DefaultCookies()
   rPypWKNdoQlAxvIHwbCBqnRgcMTOau=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.callRequestCookies('Get',rPypWKNdoQlAxvIHwbCBqnRgcMTOaF,payload=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,params=rPypWKNdoQlAxvIHwbCBqnRgcMTOah,headers=rPypWKNdoQlAxvIHwbCBqnRgcMTOaE,cookies=rPypWKNdoQlAxvIHwbCBqnRgcMTOaG,redirects=rPypWKNdoQlAxvIHwbCBqnRgcMTOEJ)
   if rPypWKNdoQlAxvIHwbCBqnRgcMTOau.status_code not in[200]:return '',json.loads(rPypWKNdoQlAxvIHwbCBqnRgcMTOau.text).get('error').get('detail')
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaf=json.loads(rPypWKNdoQlAxvIHwbCBqnRgcMTOau.text)
   for rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ in rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('data').get('raw').get('sources'):
    if rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('type')=='application/dash+xml' and rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('src')[0:8]=='https://':
     rPypWKNdoQlAxvIHwbCBqnRgcMTOFk=rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('src')
     if 'key_systems' in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ:
      rPypWKNdoQlAxvIHwbCBqnRgcMTOFf =rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('key_systems').get('com.widevine.alpha').get('license_url')
     break
  except rPypWKNdoQlAxvIHwbCBqnRgcMTOEU as exception:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOEL(exception)
   return '',''
  return rPypWKNdoQlAxvIHwbCBqnRgcMTOFk,rPypWKNdoQlAxvIHwbCBqnRgcMTOFf
 def GetEventURL_Live(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF,eventId,rPypWKNdoQlAxvIHwbCBqnRgcMTOEz):
  rPypWKNdoQlAxvIHwbCBqnRgcMTOFk=''
  rPypWKNdoQlAxvIHwbCBqnRgcMTOFf =''
  rPypWKNdoQlAxvIHwbCBqnRgcMTOFD=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.Get_eInfo(eventId)
  if rPypWKNdoQlAxvIHwbCBqnRgcMTOFD=={}:return '',''
  try:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaF=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.API_DOMAIN+'/api/playback/play' 
   rPypWKNdoQlAxvIHwbCBqnRgcMTOah={'titleId':eventId,'titleType':rPypWKNdoQlAxvIHwbCBqnRgcMTOEz,}
   rPypWKNdoQlAxvIHwbCBqnRgcMTOzU,rPypWKNdoQlAxvIHwbCBqnRgcMTOzi,rPypWKNdoQlAxvIHwbCBqnRgcMTOzJ=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.Make_authHeader()
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaE={'traceparent':rPypWKNdoQlAxvIHwbCBqnRgcMTOzU,'tracestate':rPypWKNdoQlAxvIHwbCBqnRgcMTOzi,'newrelic':rPypWKNdoQlAxvIHwbCBqnRgcMTOzJ,'x-force-raw':'true','x-pcid':rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['COOKIES']['PCID'],'x-platform':'web','x-profileId':rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':rPypWKNdoQlAxvIHwbCBqnRgcMTOFD.get('asset_id'),'x-title-deal-id':rPypWKNdoQlAxvIHwbCBqnRgcMTOFD.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':rPypWKNdoQlAxvIHwbCBqnRgcMTOFD.get('region'),'x-title-streamable':rPypWKNdoQlAxvIHwbCBqnRgcMTOFD.get('streamable'),}
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaG=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.make_CP_DefaultCookies()
   rPypWKNdoQlAxvIHwbCBqnRgcMTOau=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.callRequestCookies('Get',rPypWKNdoQlAxvIHwbCBqnRgcMTOaF,payload=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,params=rPypWKNdoQlAxvIHwbCBqnRgcMTOah,headers=rPypWKNdoQlAxvIHwbCBqnRgcMTOaE,cookies=rPypWKNdoQlAxvIHwbCBqnRgcMTOaG,redirects=rPypWKNdoQlAxvIHwbCBqnRgcMTOEJ)
   if rPypWKNdoQlAxvIHwbCBqnRgcMTOau.status_code not in[200]:return '',json.loads(rPypWKNdoQlAxvIHwbCBqnRgcMTOau.text).get('error').get('detail')
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaf=json.loads(rPypWKNdoQlAxvIHwbCBqnRgcMTOau.text)
   if rPypWKNdoQlAxvIHwbCBqnRgcMTOFk=='':
    for rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ in rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('data').get('raw').get('sources'):
     if 'key_systems' in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ:
      if rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('type')=='application/dash+xml' and 'com.widevine.alpha' in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('key_systems')and rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('src').startswith('https://')==rPypWKNdoQlAxvIHwbCBqnRgcMTOEJ:
       rPypWKNdoQlAxvIHwbCBqnRgcMTOFk=rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('src')
       rPypWKNdoQlAxvIHwbCBqnRgcMTOFf =rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('key_systems').get('com.widevine.alpha').get('license_url')
   if rPypWKNdoQlAxvIHwbCBqnRgcMTOFk=='':
    for rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ in rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('data').get('raw').get('sources'):
     if 'key_systems' in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ:
      if rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('key_systems')and rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('src').startswith('https://')==rPypWKNdoQlAxvIHwbCBqnRgcMTOEJ:
       rPypWKNdoQlAxvIHwbCBqnRgcMTOFk=rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('src')
       rPypWKNdoQlAxvIHwbCBqnRgcMTOFf =rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('key_systems').get('com.widevine.alpha').get('license_url')
   if rPypWKNdoQlAxvIHwbCBqnRgcMTOFk=='':
    for rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ in rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('data').get('raw').get('sources'):
     if rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('type')=='application/dash+xml' and rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('src').startswith('https://')==rPypWKNdoQlAxvIHwbCBqnRgcMTOEJ:
      rPypWKNdoQlAxvIHwbCBqnRgcMTOFk=rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('src')
   if rPypWKNdoQlAxvIHwbCBqnRgcMTOFk=='':
    for rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ in rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('data').get('raw').get('sources'):
     if rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('type')=='application/x-mpegURL' and rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('src').startswith('https://')==rPypWKNdoQlAxvIHwbCBqnRgcMTOEJ:
      rPypWKNdoQlAxvIHwbCBqnRgcMTOFk=rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('src')
  except rPypWKNdoQlAxvIHwbCBqnRgcMTOEU as exception:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOEL(exception)
   return '',''
  return rPypWKNdoQlAxvIHwbCBqnRgcMTOFk,rPypWKNdoQlAxvIHwbCBqnRgcMTOFf
 def Get_Url_PostFix(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF,in_url):
  rPypWKNdoQlAxvIHwbCBqnRgcMTOFt=urllib.parse.urlparse(in_url) 
  rPypWKNdoQlAxvIHwbCBqnRgcMTOFm =rPypWKNdoQlAxvIHwbCBqnRgcMTOFt.path.strip('/').split('/')
  rPypWKNdoQlAxvIHwbCBqnRgcMTOFL =rPypWKNdoQlAxvIHwbCBqnRgcMTOFm[rPypWKNdoQlAxvIHwbCBqnRgcMTOEX(rPypWKNdoQlAxvIHwbCBqnRgcMTOFm)-1]
  rPypWKNdoQlAxvIHwbCBqnRgcMTOFV=rPypWKNdoQlAxvIHwbCBqnRgcMTOFL.split('.')
  return rPypWKNdoQlAxvIHwbCBqnRgcMTOFV[rPypWKNdoQlAxvIHwbCBqnRgcMTOEX(rPypWKNdoQlAxvIHwbCBqnRgcMTOFV)-1]
 def Get_Theme_GroupList(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF,vType):
  rPypWKNdoQlAxvIHwbCBqnRgcMTOaY=[] 
  try:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaF=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.API_VIEWURL+'/v2/discover/feed' 
   rPypWKNdoQlAxvIHwbCBqnRgcMTOah={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':rPypWKNdoQlAxvIHwbCBqnRgcMTOEV(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.PAGE_LIMIT),'filterRestrictedContent':'false',}
   rPypWKNdoQlAxvIHwbCBqnRgcMTOau=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.callRequestCookies('Get',rPypWKNdoQlAxvIHwbCBqnRgcMTOaF,payload=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,params=rPypWKNdoQlAxvIHwbCBqnRgcMTOah,headers=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,cookies=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,redirects=rPypWKNdoQlAxvIHwbCBqnRgcMTOEJ)
   if rPypWKNdoQlAxvIHwbCBqnRgcMTOau.status_code not in[200]:return[]
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaf=json.loads(rPypWKNdoQlAxvIHwbCBqnRgcMTOau.text)
   for rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ in rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('data'):
    if rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('type')=='Title-Rails-Curation':
     rPypWKNdoQlAxvIHwbCBqnRgcMTOFY =''
     rPypWKNdoQlAxvIHwbCBqnRgcMTOFh=7
     try:
      for i in rPypWKNdoQlAxvIHwbCBqnRgcMTOEe(rPypWKNdoQlAxvIHwbCBqnRgcMTOEX(rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('data'))):
       if i>=rPypWKNdoQlAxvIHwbCBqnRgcMTOFh:
        rPypWKNdoQlAxvIHwbCBqnRgcMTOFY=rPypWKNdoQlAxvIHwbCBqnRgcMTOFY+'...'
        break
       rPypWKNdoQlAxvIHwbCBqnRgcMTOFY=rPypWKNdoQlAxvIHwbCBqnRgcMTOFY+rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ['data'][i]['title']+'\n'
     except rPypWKNdoQlAxvIHwbCBqnRgcMTOEU as exception:
      rPypWKNdoQlAxvIHwbCBqnRgcMTOEL(exception)
     rPypWKNdoQlAxvIHwbCBqnRgcMTOae={'collectionId':rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('obj_id'),'title':rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('row_name'),'category':rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('category'),'pre_title':rPypWKNdoQlAxvIHwbCBqnRgcMTOFY,}
     rPypWKNdoQlAxvIHwbCBqnRgcMTOaY.append(rPypWKNdoQlAxvIHwbCBqnRgcMTOae)
  except rPypWKNdoQlAxvIHwbCBqnRgcMTOEU as exception:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOEL(exception)
   return[]
  return rPypWKNdoQlAxvIHwbCBqnRgcMTOaY
 def Get_Event_GroupList(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF):
  rPypWKNdoQlAxvIHwbCBqnRgcMTOaY=[] 
  try:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaF=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.API_VIEWURL+'/v2/discover/feed' 
   rPypWKNdoQlAxvIHwbCBqnRgcMTOah={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':7,'filterRestrictedContent':'false',}
   rPypWKNdoQlAxvIHwbCBqnRgcMTOau=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.callRequestCookies('Get',rPypWKNdoQlAxvIHwbCBqnRgcMTOaF,payload=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,params=rPypWKNdoQlAxvIHwbCBqnRgcMTOah,headers=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,cookies=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,redirects=rPypWKNdoQlAxvIHwbCBqnRgcMTOEJ)
   if rPypWKNdoQlAxvIHwbCBqnRgcMTOau.status_code not in[200]:return[]
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaf=json.loads(rPypWKNdoQlAxvIHwbCBqnRgcMTOau.text)
   for rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ in rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('data'):
    if rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('row_name').strip()!='':
     rPypWKNdoQlAxvIHwbCBqnRgcMTOFY =''
     rPypWKNdoQlAxvIHwbCBqnRgcMTOFh=7
     try:
      for i in rPypWKNdoQlAxvIHwbCBqnRgcMTOEe(rPypWKNdoQlAxvIHwbCBqnRgcMTOEX(rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('data'))):
       if i>=rPypWKNdoQlAxvIHwbCBqnRgcMTOFh:
        rPypWKNdoQlAxvIHwbCBqnRgcMTOFY=rPypWKNdoQlAxvIHwbCBqnRgcMTOFY+'...'
        break
       rPypWKNdoQlAxvIHwbCBqnRgcMTOFY=rPypWKNdoQlAxvIHwbCBqnRgcMTOFY+rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ['data'][i]['title']+'\n'
     except rPypWKNdoQlAxvIHwbCBqnRgcMTOEU as exception:
      rPypWKNdoQlAxvIHwbCBqnRgcMTOEL(exception)
     rPypWKNdoQlAxvIHwbCBqnRgcMTOae={'collectionId':rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('obj_id'),'title':rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('row_name'),'category':rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('type'),'pre_title':rPypWKNdoQlAxvIHwbCBqnRgcMTOFY,}
     rPypWKNdoQlAxvIHwbCBqnRgcMTOaY.append(rPypWKNdoQlAxvIHwbCBqnRgcMTOae)
  except rPypWKNdoQlAxvIHwbCBqnRgcMTOEU as exception:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOEL(exception)
   return[]
  return rPypWKNdoQlAxvIHwbCBqnRgcMTOaY
 def Get_Event_GameList(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF,rPypWKNdoQlAxvIHwbCBqnRgcMTOaX):
  rPypWKNdoQlAxvIHwbCBqnRgcMTOaY=[] 
  try:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaF=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.API_VIEWURL+'/v2/discover/feed' 
   rPypWKNdoQlAxvIHwbCBqnRgcMTOah={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false',}
   rPypWKNdoQlAxvIHwbCBqnRgcMTOau=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.callRequestCookies('Get',rPypWKNdoQlAxvIHwbCBqnRgcMTOaF,payload=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,params=rPypWKNdoQlAxvIHwbCBqnRgcMTOah,headers=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,cookies=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,redirects=rPypWKNdoQlAxvIHwbCBqnRgcMTOEJ)
   if rPypWKNdoQlAxvIHwbCBqnRgcMTOau.status_code not in[200]:return[]
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaf=json.loads(rPypWKNdoQlAxvIHwbCBqnRgcMTOau.text)
   for rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ in rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('data'):
    if rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('obj_id')==rPypWKNdoQlAxvIHwbCBqnRgcMTOaX:
     for rPypWKNdoQlAxvIHwbCBqnRgcMTOFU in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('data'):
      rPypWKNdoQlAxvIHwbCBqnRgcMTOFE=rPypWKNdoQlAxvIHwbCBqnRgcMTOFs=rPypWKNdoQlAxvIHwbCBqnRgcMTOES=''
      if 'poster' in rPypWKNdoQlAxvIHwbCBqnRgcMTOFU.get('images'):rPypWKNdoQlAxvIHwbCBqnRgcMTOFE =rPypWKNdoQlAxvIHwbCBqnRgcMTOFU.get('images').get('poster').get('url') +'?imwidth=350'
      if 'story-art' in rPypWKNdoQlAxvIHwbCBqnRgcMTOFU.get('images'):rPypWKNdoQlAxvIHwbCBqnRgcMTOFs =rPypWKNdoQlAxvIHwbCBqnRgcMTOFU.get('images').get('story-art').get('url')+'?imwidth=600'
      if 'hero' in rPypWKNdoQlAxvIHwbCBqnRgcMTOFU.get('images'):rPypWKNdoQlAxvIHwbCBqnRgcMTOES =rPypWKNdoQlAxvIHwbCBqnRgcMTOFU.get('images').get('hero').get('url') +'?imwidth=600'
      rPypWKNdoQlAxvIHwbCBqnRgcMTOFi=rPypWKNdoQlAxvIHwbCBqnRgcMTOFU.get('meta').get(rPypWKNdoQlAxvIHwbCBqnRgcMTOFU.get('category')).get(rPypWKNdoQlAxvIHwbCBqnRgcMTOFU.get('sub_category'))
      if 'league' in rPypWKNdoQlAxvIHwbCBqnRgcMTOFi:
       rPypWKNdoQlAxvIHwbCBqnRgcMTOFJ=rPypWKNdoQlAxvIHwbCBqnRgcMTOFi.get('league')
      else:
       rPypWKNdoQlAxvIHwbCBqnRgcMTOFJ=rPypWKNdoQlAxvIHwbCBqnRgcMTOFi.get('round')
      rPypWKNdoQlAxvIHwbCBqnRgcMTOae={'id':rPypWKNdoQlAxvIHwbCBqnRgcMTOFU.get('id'),'title':rPypWKNdoQlAxvIHwbCBqnRgcMTOFU.get('title'),'thumbnail':{'poster':rPypWKNdoQlAxvIHwbCBqnRgcMTOFE,'thumb':rPypWKNdoQlAxvIHwbCBqnRgcMTOFs,'fanart':rPypWKNdoQlAxvIHwbCBqnRgcMTOES},'asis':rPypWKNdoQlAxvIHwbCBqnRgcMTOFU.get('type'),'addInfo':rPypWKNdoQlAxvIHwbCBqnRgcMTOFJ,'starttm':rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.convert_TimeStr(rPypWKNdoQlAxvIHwbCBqnRgcMTOFU.get('start_at')),}
      rPypWKNdoQlAxvIHwbCBqnRgcMTOaY.append(rPypWKNdoQlAxvIHwbCBqnRgcMTOae)
  except rPypWKNdoQlAxvIHwbCBqnRgcMTOEU as exception:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOEL(exception)
   return[]
  return rPypWKNdoQlAxvIHwbCBqnRgcMTOaY
 def Get_Event_List(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF,gameId):
  rPypWKNdoQlAxvIHwbCBqnRgcMTOaY=[] 
  try:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaF=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.API_VIEWURL+'/v1/discover/events/'+gameId 
   rPypWKNdoQlAxvIHwbCBqnRgcMTOah={'platform':'WEBCLIENT','locale':'ko','filterRestrictedContent':'false',}
   rPypWKNdoQlAxvIHwbCBqnRgcMTOau=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.callRequestCookies('Get',rPypWKNdoQlAxvIHwbCBqnRgcMTOaF,payload=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,params=rPypWKNdoQlAxvIHwbCBqnRgcMTOah,headers=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,cookies=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,redirects=rPypWKNdoQlAxvIHwbCBqnRgcMTOEJ)
   if rPypWKNdoQlAxvIHwbCBqnRgcMTOau.status_code not in[200]:return[]
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaf=json.loads(rPypWKNdoQlAxvIHwbCBqnRgcMTOau.text)
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ=rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('data')
   rPypWKNdoQlAxvIHwbCBqnRgcMTOFX=rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('end_at')
   rPypWKNdoQlAxvIHwbCBqnRgcMTOFX=rPypWKNdoQlAxvIHwbCBqnRgcMTOFX[0:19].replace('-','').replace(':','').replace('T','')
   rPypWKNdoQlAxvIHwbCBqnRgcMTOFe=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d%H%M%S')
   if rPypWKNdoQlAxvIHwbCBqnRgcMTOEh(rPypWKNdoQlAxvIHwbCBqnRgcMTOFe)<rPypWKNdoQlAxvIHwbCBqnRgcMTOEh(rPypWKNdoQlAxvIHwbCBqnRgcMTOFX):
    rPypWKNdoQlAxvIHwbCBqnRgcMTOFE=rPypWKNdoQlAxvIHwbCBqnRgcMTOFs=rPypWKNdoQlAxvIHwbCBqnRgcMTOES=''
    if 'poster' in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('images'):rPypWKNdoQlAxvIHwbCBqnRgcMTOFE =rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('images'):rPypWKNdoQlAxvIHwbCBqnRgcMTOFs =rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('images').get('story-art').get('url')+'?imwidth=600'
    if 'story-art' in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('images'):rPypWKNdoQlAxvIHwbCBqnRgcMTOES =rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('images').get('story-art').get('url')+'?imwidth=600'
    rPypWKNdoQlAxvIHwbCBqnRgcMTOae={'id':rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('id'),'title':rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('title'),'thumbnail':{'poster':rPypWKNdoQlAxvIHwbCBqnRgcMTOFE,'thumb':rPypWKNdoQlAxvIHwbCBqnRgcMTOFs,'fanart':rPypWKNdoQlAxvIHwbCBqnRgcMTOES},'duration':rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('running_time'),'asis':rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('type'),'starttm':rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.convert_TimeStr(rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('start_at')),}
    rPypWKNdoQlAxvIHwbCBqnRgcMTOaY.append(rPypWKNdoQlAxvIHwbCBqnRgcMTOae)
  except rPypWKNdoQlAxvIHwbCBqnRgcMTOEU as exception:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOEL(exception)
   return[]
  try:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaF=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.API_VIEWURL+'/v1/discover/events/'+gameId+'/related' 
   rPypWKNdoQlAxvIHwbCBqnRgcMTOah={'locale':'ko','page':'1','perPage':'25','platform':'WEBCLIENT','currentPageTracking':'page_discover_title_detail',}
   rPypWKNdoQlAxvIHwbCBqnRgcMTOau=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.callRequestCookies('Get',rPypWKNdoQlAxvIHwbCBqnRgcMTOaF,payload=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,params=rPypWKNdoQlAxvIHwbCBqnRgcMTOah,headers=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,cookies=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,redirects=rPypWKNdoQlAxvIHwbCBqnRgcMTOEJ)
   if rPypWKNdoQlAxvIHwbCBqnRgcMTOau.status_code not in[200]:return[]
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaf=json.loads(rPypWKNdoQlAxvIHwbCBqnRgcMTOau.text)
   for rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ in rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('data').get('data'):
    rPypWKNdoQlAxvIHwbCBqnRgcMTOFE=rPypWKNdoQlAxvIHwbCBqnRgcMTOFs=rPypWKNdoQlAxvIHwbCBqnRgcMTOES=''
    if 'poster' in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('images'):rPypWKNdoQlAxvIHwbCBqnRgcMTOFE =rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('images'):rPypWKNdoQlAxvIHwbCBqnRgcMTOFs =rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('images').get('story-art').get('url')+'?imwidth=600'
    if 'story-art' in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('images'):rPypWKNdoQlAxvIHwbCBqnRgcMTOES =rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('images').get('story-art').get('url')+'?imwidth=600'
    rPypWKNdoQlAxvIHwbCBqnRgcMTOae={'id':rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('id'),'title':rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('title'),'thumbnail':{'poster':rPypWKNdoQlAxvIHwbCBqnRgcMTOFE,'thumb':rPypWKNdoQlAxvIHwbCBqnRgcMTOFs,'fanart':rPypWKNdoQlAxvIHwbCBqnRgcMTOES},'duration':rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('running_time'),'asis':rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('type'),}
    rPypWKNdoQlAxvIHwbCBqnRgcMTOaY.append(rPypWKNdoQlAxvIHwbCBqnRgcMTOae)
  except rPypWKNdoQlAxvIHwbCBqnRgcMTOEU as exception:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOEL(exception)
   return[]
  return rPypWKNdoQlAxvIHwbCBqnRgcMTOaY
 def Get_Search_List(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF,search_key,page_int):
  rPypWKNdoQlAxvIHwbCBqnRgcMTOaY=[] 
  rPypWKNdoQlAxvIHwbCBqnRgcMTOFz=rPypWKNdoQlAxvIHwbCBqnRgcMTOEm
  try:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaF=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.API_VIEWURL+'/v2/search' 
   rPypWKNdoQlAxvIHwbCBqnRgcMTOah={'query':search_key,'platform':'WEBCLIENT','page':rPypWKNdoQlAxvIHwbCBqnRgcMTOEV(page_int),'perPage':rPypWKNdoQlAxvIHwbCBqnRgcMTOEV(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.SEARCH_LIMIT),}
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaE={'x-membersrl':rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['COOKIES']['member_srl'],'x-pcid':rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['COOKIES']['PCID'],'x-profileid':rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.CP['SESSION']['profileId'],}
   rPypWKNdoQlAxvIHwbCBqnRgcMTOau=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.callRequestCookies('Get',rPypWKNdoQlAxvIHwbCBqnRgcMTOaF,payload=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,params=rPypWKNdoQlAxvIHwbCBqnRgcMTOah,headers=rPypWKNdoQlAxvIHwbCBqnRgcMTOaE,cookies=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,redirects=rPypWKNdoQlAxvIHwbCBqnRgcMTOEJ)
   if rPypWKNdoQlAxvIHwbCBqnRgcMTOau.status_code not in[200]:return[],rPypWKNdoQlAxvIHwbCBqnRgcMTOEm
   rPypWKNdoQlAxvIHwbCBqnRgcMTOaf=json.loads(rPypWKNdoQlAxvIHwbCBqnRgcMTOau.text)
   for rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ in rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('data').get('data'):
    rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ=rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('data')
    rPypWKNdoQlAxvIHwbCBqnRgcMTOFE=rPypWKNdoQlAxvIHwbCBqnRgcMTOFs=rPypWKNdoQlAxvIHwbCBqnRgcMTOEj=rPypWKNdoQlAxvIHwbCBqnRgcMTOES=''
    if 'poster' in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('images'):rPypWKNdoQlAxvIHwbCBqnRgcMTOFE =rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('images'):rPypWKNdoQlAxvIHwbCBqnRgcMTOFs =rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('images').get('story-art').get('url') +'?imwidth=600'
    if 'title-treatment' in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('images'):rPypWKNdoQlAxvIHwbCBqnRgcMTOEj=rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('images').get('title-treatment').get('url')+'?imwidth=300'
    if 'story-art' in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('images'):rPypWKNdoQlAxvIHwbCBqnRgcMTOES =rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('images').get('story-art').get('url') +'?imwidth=600'
    rPypWKNdoQlAxvIHwbCBqnRgcMTOFG=''
    if rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('badge')not in[{},rPypWKNdoQlAxvIHwbCBqnRgcMTOEt]:
     for i in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('badge').get('text'):
      if rPypWKNdoQlAxvIHwbCBqnRgcMTOFG!='':rPypWKNdoQlAxvIHwbCBqnRgcMTOFG+=' '
      rPypWKNdoQlAxvIHwbCBqnRgcMTOFG+=i.get('text')
    if 'as' in rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ:
     rPypWKNdoQlAxvIHwbCBqnRgcMTOEz=rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('as') 
    else:
     rPypWKNdoQlAxvIHwbCBqnRgcMTOEz=rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('type')
    rPypWKNdoQlAxvIHwbCBqnRgcMTOae={'id':rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('id'),'title':rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('title'),'asis':rPypWKNdoQlAxvIHwbCBqnRgcMTOEz,'thumbnail':{'poster':rPypWKNdoQlAxvIHwbCBqnRgcMTOFE,'thumb':rPypWKNdoQlAxvIHwbCBqnRgcMTOFs,'clearlogo':rPypWKNdoQlAxvIHwbCBqnRgcMTOEj,'fanart':rPypWKNdoQlAxvIHwbCBqnRgcMTOES},'mpaa':rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('age_rating'),'duration':rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('running_time'),'badge':rPypWKNdoQlAxvIHwbCBqnRgcMTOFG,'year':rPypWKNdoQlAxvIHwbCBqnRgcMTOaJ.get('meta').get('releaseYear'),}
    rPypWKNdoQlAxvIHwbCBqnRgcMTOaY.append(rPypWKNdoQlAxvIHwbCBqnRgcMTOae)
   if rPypWKNdoQlAxvIHwbCBqnRgcMTOaf.get('pagination').get('totalPages')>page_int:
    rPypWKNdoQlAxvIHwbCBqnRgcMTOFz=rPypWKNdoQlAxvIHwbCBqnRgcMTOEJ
  except rPypWKNdoQlAxvIHwbCBqnRgcMTOEU as exception:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOEL(exception)
   return[],rPypWKNdoQlAxvIHwbCBqnRgcMTOEm
  return rPypWKNdoQlAxvIHwbCBqnRgcMTOaY,rPypWKNdoQlAxvIHwbCBqnRgcMTOFz
 def GetBookmarkInfo(rPypWKNdoQlAxvIHwbCBqnRgcMTOzF,videoid,vidtype):
  rPypWKNdoQlAxvIHwbCBqnRgcMTOEa={'indexinfo':{'ott':'coupang','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  rPypWKNdoQlAxvIHwbCBqnRgcMTOaF=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.API_VIEWURL+'/v1/discover/titles/'+videoid 
  rPypWKNdoQlAxvIHwbCBqnRgcMTOah={'locale':'ko'}
  rPypWKNdoQlAxvIHwbCBqnRgcMTOau=rPypWKNdoQlAxvIHwbCBqnRgcMTOzF.callRequestCookies('Get',rPypWKNdoQlAxvIHwbCBqnRgcMTOaF,payload=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,params=rPypWKNdoQlAxvIHwbCBqnRgcMTOah,headers=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,cookies=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt,redirects=rPypWKNdoQlAxvIHwbCBqnRgcMTOEJ)
  if rPypWKNdoQlAxvIHwbCBqnRgcMTOau.status_code not in[200]:return{}
  rPypWKNdoQlAxvIHwbCBqnRgcMTOEF=json.loads(rPypWKNdoQlAxvIHwbCBqnRgcMTOau.text).get('data')
  rPypWKNdoQlAxvIHwbCBqnRgcMTOEG=rPypWKNdoQlAxvIHwbCBqnRgcMTOEF.get('title')
  rPypWKNdoQlAxvIHwbCBqnRgcMTOEu =rPypWKNdoQlAxvIHwbCBqnRgcMTOEF.get('meta').get('releaseYear')
  rPypWKNdoQlAxvIHwbCBqnRgcMTOEa['saveinfo']['infoLabels']['title']=rPypWKNdoQlAxvIHwbCBqnRgcMTOEG
  if vidtype=='movie':
   rPypWKNdoQlAxvIHwbCBqnRgcMTOEG='%s  (%s)'%(rPypWKNdoQlAxvIHwbCBqnRgcMTOEG,rPypWKNdoQlAxvIHwbCBqnRgcMTOEu)
  rPypWKNdoQlAxvIHwbCBqnRgcMTOEa['saveinfo']['title'] =rPypWKNdoQlAxvIHwbCBqnRgcMTOEG
  rPypWKNdoQlAxvIHwbCBqnRgcMTOEa['saveinfo']['infoLabels']['mpaa'] =rPypWKNdoQlAxvIHwbCBqnRgcMTOEF.get('age_rating')
  rPypWKNdoQlAxvIHwbCBqnRgcMTOEa['saveinfo']['infoLabels']['plot'] ='%s\n\n%s'%(rPypWKNdoQlAxvIHwbCBqnRgcMTOEF.get('short_description'),rPypWKNdoQlAxvIHwbCBqnRgcMTOEF.get('description'))
  rPypWKNdoQlAxvIHwbCBqnRgcMTOEa['saveinfo']['infoLabels']['year'] =rPypWKNdoQlAxvIHwbCBqnRgcMTOEu
  if vidtype=='movie':
   rPypWKNdoQlAxvIHwbCBqnRgcMTOEa['saveinfo']['infoLabels']['duration']=rPypWKNdoQlAxvIHwbCBqnRgcMTOEF.get('running_time')
  rPypWKNdoQlAxvIHwbCBqnRgcMTOFE =''
  rPypWKNdoQlAxvIHwbCBqnRgcMTOES =''
  rPypWKNdoQlAxvIHwbCBqnRgcMTOFs =''
  rPypWKNdoQlAxvIHwbCBqnRgcMTOEj=''
  if rPypWKNdoQlAxvIHwbCBqnRgcMTOEF.get('images').get('poster') !=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt:rPypWKNdoQlAxvIHwbCBqnRgcMTOFE =rPypWKNdoQlAxvIHwbCBqnRgcMTOEF.get('images').get('poster').get('url') +'?imwidth=350'
  if rPypWKNdoQlAxvIHwbCBqnRgcMTOEF.get('images').get('background') !=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt:rPypWKNdoQlAxvIHwbCBqnRgcMTOES =rPypWKNdoQlAxvIHwbCBqnRgcMTOEF.get('images').get('background').get('url') +'?imwidth=600'
  if rPypWKNdoQlAxvIHwbCBqnRgcMTOEF.get('images').get('story-art') !=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt:rPypWKNdoQlAxvIHwbCBqnRgcMTOFs =rPypWKNdoQlAxvIHwbCBqnRgcMTOEF.get('images').get('story-art').get('url') +'?imwidth=600'
  if rPypWKNdoQlAxvIHwbCBqnRgcMTOEF.get('images').get('title-treatment')!=rPypWKNdoQlAxvIHwbCBqnRgcMTOEt:rPypWKNdoQlAxvIHwbCBqnRgcMTOEj=rPypWKNdoQlAxvIHwbCBqnRgcMTOEF.get('images').get('title-treatment').get('url')+'?imwidth=300'
  if rPypWKNdoQlAxvIHwbCBqnRgcMTOES=='':rPypWKNdoQlAxvIHwbCBqnRgcMTOES=rPypWKNdoQlAxvIHwbCBqnRgcMTOFs
  rPypWKNdoQlAxvIHwbCBqnRgcMTOEa['saveinfo']['thumbnail']['poster']=rPypWKNdoQlAxvIHwbCBqnRgcMTOFE
  rPypWKNdoQlAxvIHwbCBqnRgcMTOEa['saveinfo']['thumbnail']['fanart']=rPypWKNdoQlAxvIHwbCBqnRgcMTOES
  rPypWKNdoQlAxvIHwbCBqnRgcMTOEa['saveinfo']['thumbnail']['thumb']=rPypWKNdoQlAxvIHwbCBqnRgcMTOFs
  rPypWKNdoQlAxvIHwbCBqnRgcMTOEa['saveinfo']['thumbnail']['clearlogo']=rPypWKNdoQlAxvIHwbCBqnRgcMTOEj
  rPypWKNdoQlAxvIHwbCBqnRgcMTOEs=[]
  for rPypWKNdoQlAxvIHwbCBqnRgcMTOFj in rPypWKNdoQlAxvIHwbCBqnRgcMTOEF.get('tags'):rPypWKNdoQlAxvIHwbCBqnRgcMTOEs.append(rPypWKNdoQlAxvIHwbCBqnRgcMTOFj.get('tag'))
  if rPypWKNdoQlAxvIHwbCBqnRgcMTOEX(rPypWKNdoQlAxvIHwbCBqnRgcMTOEs)>0:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOEa['saveinfo']['infoLabels']['genre']=rPypWKNdoQlAxvIHwbCBqnRgcMTOEs
  rPypWKNdoQlAxvIHwbCBqnRgcMTOED=[]
  rPypWKNdoQlAxvIHwbCBqnRgcMTOEk=[]
  for rPypWKNdoQlAxvIHwbCBqnRgcMTOFj in rPypWKNdoQlAxvIHwbCBqnRgcMTOEF.get('people'):
   if rPypWKNdoQlAxvIHwbCBqnRgcMTOFj.get('role')=='CAST' :rPypWKNdoQlAxvIHwbCBqnRgcMTOED.append(rPypWKNdoQlAxvIHwbCBqnRgcMTOFj.get('name'))
   if rPypWKNdoQlAxvIHwbCBqnRgcMTOFj.get('role')=='DIRECTOR':rPypWKNdoQlAxvIHwbCBqnRgcMTOEk.append(rPypWKNdoQlAxvIHwbCBqnRgcMTOFj.get('name'))
  if rPypWKNdoQlAxvIHwbCBqnRgcMTOEX(rPypWKNdoQlAxvIHwbCBqnRgcMTOED)>0:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOEa['saveinfo']['infoLabels']['cast'] =rPypWKNdoQlAxvIHwbCBqnRgcMTOED
  if rPypWKNdoQlAxvIHwbCBqnRgcMTOEX(rPypWKNdoQlAxvIHwbCBqnRgcMTOEk)>0:
   rPypWKNdoQlAxvIHwbCBqnRgcMTOEa['saveinfo']['infoLabels']['director']=rPypWKNdoQlAxvIHwbCBqnRgcMTOEk
  return rPypWKNdoQlAxvIHwbCBqnRgcMTOEa
# Created by pyminifier (https://github.com/liftoff/pyminifier)
