__author__="NightRain"
DCQUHNYsREPywOtAnKfmWapekuhlLM=object
DCQUHNYsREPywOtAnKfmWapekuhlLj=None
DCQUHNYsREPywOtAnKfmWapekuhlLo=False
DCQUHNYsREPywOtAnKfmWapekuhlLT=print
DCQUHNYsREPywOtAnKfmWapekuhlLg=str
DCQUHNYsREPywOtAnKfmWapekuhlLF=open
DCQUHNYsREPywOtAnKfmWapekuhlLJ=int
DCQUHNYsREPywOtAnKfmWapekuhlLS=Exception
DCQUHNYsREPywOtAnKfmWapekuhlLd=id
DCQUHNYsREPywOtAnKfmWapekuhlLG=True
DCQUHNYsREPywOtAnKfmWapekuhlLq=range
DCQUHNYsREPywOtAnKfmWapekuhlLv=len
import urllib
import re
import json
import requests
import datetime
import time
import random
import base64
class DCQUHNYsREPywOtAnKfmWapekuhlVc(DCQUHNYsREPywOtAnKfmWapekuhlLM):
 def __init__(DCQUHNYsREPywOtAnKfmWapekuhlVi):
  DCQUHNYsREPywOtAnKfmWapekuhlVi.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.82 Safari/537.36'
  DCQUHNYsREPywOtAnKfmWapekuhlVi.MODEL ='Chrome_98' 
  DCQUHNYsREPywOtAnKfmWapekuhlVi.DEFAULT_HEADER ={'user-agent':DCQUHNYsREPywOtAnKfmWapekuhlVi.USER_AGENT}
  DCQUHNYsREPywOtAnKfmWapekuhlVi.API_DOMAIN ='https://www.coupangplay.com'
  DCQUHNYsREPywOtAnKfmWapekuhlVi.API_VIEWURL ='https://discover.coupangstreaming.com'
  DCQUHNYsREPywOtAnKfmWapekuhlVi.PAGE_LIMIT =40
  DCQUHNYsREPywOtAnKfmWapekuhlVi.SEARCH_LIMIT =20
  DCQUHNYsREPywOtAnKfmWapekuhlVi.CP={}
  DCQUHNYsREPywOtAnKfmWapekuhlVi.Init_CP()
  DCQUHNYsREPywOtAnKfmWapekuhlVi.CP_DEVICE_FILENAME=''
  DCQUHNYsREPywOtAnKfmWapekuhlVi.CP_COOKIE_FILENAME=''
 def callRequestCookies(DCQUHNYsREPywOtAnKfmWapekuhlVi,jobtype,DCQUHNYsREPywOtAnKfmWapekuhlcL,payload=DCQUHNYsREPywOtAnKfmWapekuhlLj,params=DCQUHNYsREPywOtAnKfmWapekuhlLj,headers=DCQUHNYsREPywOtAnKfmWapekuhlLj,cookies=DCQUHNYsREPywOtAnKfmWapekuhlLj,redirects=DCQUHNYsREPywOtAnKfmWapekuhlLo):
  DCQUHNYsREPywOtAnKfmWapekuhlVL=DCQUHNYsREPywOtAnKfmWapekuhlVi.DEFAULT_HEADER
  if headers:DCQUHNYsREPywOtAnKfmWapekuhlVL.update(headers)
  if jobtype=='Get':
   DCQUHNYsREPywOtAnKfmWapekuhlVX=requests.get(DCQUHNYsREPywOtAnKfmWapekuhlcL,params=params,headers=DCQUHNYsREPywOtAnKfmWapekuhlVL,cookies=cookies,allow_redirects=redirects)
  else:
   DCQUHNYsREPywOtAnKfmWapekuhlVX=requests.post(DCQUHNYsREPywOtAnKfmWapekuhlcL,data=payload,params=params,headers=DCQUHNYsREPywOtAnKfmWapekuhlVL,cookies=cookies,allow_redirects=redirects)
  DCQUHNYsREPywOtAnKfmWapekuhlLT(DCQUHNYsREPywOtAnKfmWapekuhlLg(DCQUHNYsREPywOtAnKfmWapekuhlVX.status_code)+' - '+DCQUHNYsREPywOtAnKfmWapekuhlLg(DCQUHNYsREPywOtAnKfmWapekuhlVX.url))
  return DCQUHNYsREPywOtAnKfmWapekuhlVX
 def callRequestCookies_test(DCQUHNYsREPywOtAnKfmWapekuhlVi,jobtype,DCQUHNYsREPywOtAnKfmWapekuhlcL,payload=DCQUHNYsREPywOtAnKfmWapekuhlLj,params=DCQUHNYsREPywOtAnKfmWapekuhlLj,headers=DCQUHNYsREPywOtAnKfmWapekuhlLj,cookies=DCQUHNYsREPywOtAnKfmWapekuhlLj,redirects=DCQUHNYsREPywOtAnKfmWapekuhlLo):
  DCQUHNYsREPywOtAnKfmWapekuhlVL=DCQUHNYsREPywOtAnKfmWapekuhlVi.DEFAULT_HEADER
  if headers:DCQUHNYsREPywOtAnKfmWapekuhlVL.update(headers)
  DCQUHNYsREPywOtAnKfmWapekuhlVX=requests.Request('POST',DCQUHNYsREPywOtAnKfmWapekuhlcL,headers=headers,data=payload,params=params,cookies=cookies)
  DCQUHNYsREPywOtAnKfmWapekuhlVr=DCQUHNYsREPywOtAnKfmWapekuhlVX.prepare()
  DCQUHNYsREPywOtAnKfmWapekuhlVi.pretty_print_POST(DCQUHNYsREPywOtAnKfmWapekuhlVr)
  return DCQUHNYsREPywOtAnKfmWapekuhlVX
 def pretty_print_POST(DCQUHNYsREPywOtAnKfmWapekuhlVi,req):
  DCQUHNYsREPywOtAnKfmWapekuhlLT('{}\n{}\r\n{}\r\n\r\n{}'.format('-----------START-----------',req.method+' '+req.url,'\r\n'.join('{}: {}'.format(k,v)for k,v in req.headers.items()),req.body,))
 def dic_To_jsonfile(DCQUHNYsREPywOtAnKfmWapekuhlVi,filename,DCQUHNYsREPywOtAnKfmWapekuhlVI):
  if filename=='':return
  fp=DCQUHNYsREPywOtAnKfmWapekuhlLF(filename,'w',-1,'utf-8')
  json.dump(DCQUHNYsREPywOtAnKfmWapekuhlVI,fp,indent=4,ensure_ascii=DCQUHNYsREPywOtAnKfmWapekuhlLo)
  fp.close()
 def jsonfile_To_dic(DCQUHNYsREPywOtAnKfmWapekuhlVi,filename):
  if filename=='':return DCQUHNYsREPywOtAnKfmWapekuhlLj
  try:
   fp=DCQUHNYsREPywOtAnKfmWapekuhlLF(filename,'r',-1,'utf-8')
   DCQUHNYsREPywOtAnKfmWapekuhlVj=json.load(fp)
   fp.close()
  except:
   DCQUHNYsREPywOtAnKfmWapekuhlVj={}
  return DCQUHNYsREPywOtAnKfmWapekuhlVj
 def convert_TimeStr(DCQUHNYsREPywOtAnKfmWapekuhlVi,DCQUHNYsREPywOtAnKfmWapekuhlVo):
  try:
   DCQUHNYsREPywOtAnKfmWapekuhlVo =DCQUHNYsREPywOtAnKfmWapekuhlVo[0:16]
   DCQUHNYsREPywOtAnKfmWapekuhlVT=datetime.datetime.strptime(DCQUHNYsREPywOtAnKfmWapekuhlVo,'%Y-%m-%dT%H:%M')+datetime.timedelta(hours=9)
   return DCQUHNYsREPywOtAnKfmWapekuhlVT.strftime('%Y-%m-%d %H:%M')
  except:
   return DCQUHNYsREPywOtAnKfmWapekuhlLj
 def Get_Now_Datetime(DCQUHNYsREPywOtAnKfmWapekuhlVi):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetNoCache(DCQUHNYsREPywOtAnKfmWapekuhlVi):
  DCQUHNYsREPywOtAnKfmWapekuhlVF =DCQUHNYsREPywOtAnKfmWapekuhlLJ(time.time()*1000)
  return DCQUHNYsREPywOtAnKfmWapekuhlVF
 def generatePcId(DCQUHNYsREPywOtAnKfmWapekuhlVi):
  t=DCQUHNYsREPywOtAnKfmWapekuhlVi.GetNoCache()
  r=random.random()
  DCQUHNYsREPywOtAnKfmWapekuhlVJ=DCQUHNYsREPywOtAnKfmWapekuhlLg(t)+DCQUHNYsREPywOtAnKfmWapekuhlLg(r)[2:12]
  return DCQUHNYsREPywOtAnKfmWapekuhlVJ
 def generatePvId(DCQUHNYsREPywOtAnKfmWapekuhlVi,genType='1'):
  import hashlib
  m=hashlib.md5()
  DCQUHNYsREPywOtAnKfmWapekuhlVS=DCQUHNYsREPywOtAnKfmWapekuhlLg(random.random())
  m.update(DCQUHNYsREPywOtAnKfmWapekuhlVS.encode('utf-8'))
  DCQUHNYsREPywOtAnKfmWapekuhlVd=DCQUHNYsREPywOtAnKfmWapekuhlLg(m.hexdigest())
  if genType=='1':
   return '%s-%s-%s-%s-%s'%(DCQUHNYsREPywOtAnKfmWapekuhlVd[:8],DCQUHNYsREPywOtAnKfmWapekuhlVd[8:12],DCQUHNYsREPywOtAnKfmWapekuhlVd[12:16],DCQUHNYsREPywOtAnKfmWapekuhlVd[16:20],DCQUHNYsREPywOtAnKfmWapekuhlVd[20:])
  else:
   return DCQUHNYsREPywOtAnKfmWapekuhlVd
 def Get_DeviceID(DCQUHNYsREPywOtAnKfmWapekuhlVi):
  DCQUHNYsREPywOtAnKfmWapekuhlVG=''
  try: 
   fp=DCQUHNYsREPywOtAnKfmWapekuhlLF(DCQUHNYsREPywOtAnKfmWapekuhlVi.CP_DEVICE_FILENAME,'r',-1,'utf-8')
   DCQUHNYsREPywOtAnKfmWapekuhlVq= json.load(fp)
   fp.close()
   DCQUHNYsREPywOtAnKfmWapekuhlVG=DCQUHNYsREPywOtAnKfmWapekuhlVq.get('device_id')
  except DCQUHNYsREPywOtAnKfmWapekuhlLS as exception:
   DCQUHNYsREPywOtAnKfmWapekuhlLj
  if DCQUHNYsREPywOtAnKfmWapekuhlVG=='':
   DCQUHNYsREPywOtAnKfmWapekuhlVG=DCQUHNYsREPywOtAnKfmWapekuhlVi.generatePvId(genType='1')
   try: 
    fp=DCQUHNYsREPywOtAnKfmWapekuhlLF(DCQUHNYsREPywOtAnKfmWapekuhlVi.CP_DEVICE_FILENAME,'w',-1,'utf-8')
    json.dump({'device_id':DCQUHNYsREPywOtAnKfmWapekuhlVG},fp,indent=4,ensure_ascii=DCQUHNYsREPywOtAnKfmWapekuhlLo)
    fp.close()
   except DCQUHNYsREPywOtAnKfmWapekuhlLS as exception:
    return ''
  return DCQUHNYsREPywOtAnKfmWapekuhlVG
 def Make_authHeader(DCQUHNYsREPywOtAnKfmWapekuhlVi):
  tr=DCQUHNYsREPywOtAnKfmWapekuhlVi.generatePvId(genType=2)
  ti=DCQUHNYsREPywOtAnKfmWapekuhlVi.GetNoCache()
  DCQUHNYsREPywOtAnKfmWapekuhlLd=DCQUHNYsREPywOtAnKfmWapekuhlVi.generatePvId(genType=2)[:16]
  DCQUHNYsREPywOtAnKfmWapekuhlVv='00-%s-%s-01'%(tr,DCQUHNYsREPywOtAnKfmWapekuhlLd,)
  DCQUHNYsREPywOtAnKfmWapekuhlVz ='%s@nr=0-1-%s-%s-%s----%s'%(DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['NREUM']['tk'],DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['NREUM']['ac'],DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['NREUM']['ap'],DCQUHNYsREPywOtAnKfmWapekuhlLd,ti,)
  DCQUHNYsREPywOtAnKfmWapekuhlVb ='{"v":[0,1],"d":{"ty":"Browser","ac":"%s","ap":"%s","id":"%s","tr":"%s","ti":%s,"tk":"%s"}}'%(DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['NREUM']['ac'],DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['NREUM']['ap'],DCQUHNYsREPywOtAnKfmWapekuhlLd,tr,ti,DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['NREUM']['tk'],) 
  return DCQUHNYsREPywOtAnKfmWapekuhlVv,DCQUHNYsREPywOtAnKfmWapekuhlVz,base64.standard_b64encode(DCQUHNYsREPywOtAnKfmWapekuhlVb.encode()).decode('utf-8')
 def Init_CP(DCQUHNYsREPywOtAnKfmWapekuhlVi):
  DCQUHNYsREPywOtAnKfmWapekuhlVi.CP={}
  DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['ACCOUNT']={'cpid':'','cppw':'','cppf':'0'}
  DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']={}
 def Save_session_acount(DCQUHNYsREPywOtAnKfmWapekuhlVi,DCQUHNYsREPywOtAnKfmWapekuhlVB,DCQUHNYsREPywOtAnKfmWapekuhlVx,DCQUHNYsREPywOtAnKfmWapekuhlcV):
  DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['ACCOUNT']['cpid']=base64.standard_b64encode(DCQUHNYsREPywOtAnKfmWapekuhlVB.encode()).decode('utf-8')
  DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['ACCOUNT']['cppw']=base64.standard_b64encode(DCQUHNYsREPywOtAnKfmWapekuhlVx.encode()).decode('utf-8')
  DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['ACCOUNT']['cppf']=DCQUHNYsREPywOtAnKfmWapekuhlLg(DCQUHNYsREPywOtAnKfmWapekuhlcV)
 def Load_session_acount(DCQUHNYsREPywOtAnKfmWapekuhlVi):
  DCQUHNYsREPywOtAnKfmWapekuhlVB=base64.standard_b64decode(DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['ACCOUNT']['cpid']).decode('utf-8')
  DCQUHNYsREPywOtAnKfmWapekuhlVx=base64.standard_b64decode(DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['ACCOUNT']['cppw']).decode('utf-8')
  DCQUHNYsREPywOtAnKfmWapekuhlcV=DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['ACCOUNT']['cppf']
  return DCQUHNYsREPywOtAnKfmWapekuhlVB,DCQUHNYsREPywOtAnKfmWapekuhlVx,DCQUHNYsREPywOtAnKfmWapekuhlcV
 def make_CP_DefaultCookies(DCQUHNYsREPywOtAnKfmWapekuhlVi):
  DCQUHNYsREPywOtAnKfmWapekuhlci={}
  if 'NEXT_LOCALE' in DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']:DCQUHNYsREPywOtAnKfmWapekuhlci['NEXT_LOCALE']=DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['NEXT_LOCALE']
  if 'ak_bmsc' in DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']:DCQUHNYsREPywOtAnKfmWapekuhlci['ak_bmsc'] =DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['ak_bmsc']
  if 'bm_mi' in DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']:DCQUHNYsREPywOtAnKfmWapekuhlci['bm_mi'] =DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['bm_mi']
  if 'bm_sv' in DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']:DCQUHNYsREPywOtAnKfmWapekuhlci['bm_sv'] =DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['bm_sv']
  if 'PCID' in DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']:DCQUHNYsREPywOtAnKfmWapekuhlci['PCID'] =DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['PCID']
  if 'member_srl' in DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']:DCQUHNYsREPywOtAnKfmWapekuhlci['member_srl']=DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['member_srl']
  if 'token' in DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']:DCQUHNYsREPywOtAnKfmWapekuhlci['token'] =DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['token']
  return DCQUHNYsREPywOtAnKfmWapekuhlci
 def Get_CP_Login(DCQUHNYsREPywOtAnKfmWapekuhlVi,userid,userpw,DCQUHNYsREPywOtAnKfmWapekuhlcJ):
  try:
   DCQUHNYsREPywOtAnKfmWapekuhlcL=DCQUHNYsREPywOtAnKfmWapekuhlVi.API_DOMAIN
   DCQUHNYsREPywOtAnKfmWapekuhlcX=DCQUHNYsREPywOtAnKfmWapekuhlVi.callRequestCookies('Get',DCQUHNYsREPywOtAnKfmWapekuhlcL,payload=DCQUHNYsREPywOtAnKfmWapekuhlLj,params=DCQUHNYsREPywOtAnKfmWapekuhlLj,headers=DCQUHNYsREPywOtAnKfmWapekuhlLj,cookies=DCQUHNYsREPywOtAnKfmWapekuhlLj,redirects=DCQUHNYsREPywOtAnKfmWapekuhlLo)
   if DCQUHNYsREPywOtAnKfmWapekuhlcX.status_code not in[301,302]:return DCQUHNYsREPywOtAnKfmWapekuhlLo
   for DCQUHNYsREPywOtAnKfmWapekuhlcr in DCQUHNYsREPywOtAnKfmWapekuhlcX.cookies:
    if DCQUHNYsREPywOtAnKfmWapekuhlcr.name=='NEXT_LOCALE':
     DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['NEXT_LOCALE']=DCQUHNYsREPywOtAnKfmWapekuhlcr.value
    elif DCQUHNYsREPywOtAnKfmWapekuhlcr.name=='ak_bmsc':
     DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['ak_bmsc']=DCQUHNYsREPywOtAnKfmWapekuhlcr.value
   DCQUHNYsREPywOtAnKfmWapekuhlci={'NEXT_LOCALE':DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['NEXT_LOCALE'],'ak_bmsc':DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['ak_bmsc'],}
   DCQUHNYsREPywOtAnKfmWapekuhlcX=DCQUHNYsREPywOtAnKfmWapekuhlVi.callRequestCookies('Get',DCQUHNYsREPywOtAnKfmWapekuhlcL,payload=DCQUHNYsREPywOtAnKfmWapekuhlLj,params=DCQUHNYsREPywOtAnKfmWapekuhlLj,headers=DCQUHNYsREPywOtAnKfmWapekuhlLj,cookies=DCQUHNYsREPywOtAnKfmWapekuhlci,redirects=DCQUHNYsREPywOtAnKfmWapekuhlLo)
   if DCQUHNYsREPywOtAnKfmWapekuhlcX.status_code not in[200]:return DCQUHNYsREPywOtAnKfmWapekuhlLo
   DCQUHNYsREPywOtAnKfmWapekuhlcI=re.findall('NREUM.loader_config=\{[\w\d\":,-]+\}',DCQUHNYsREPywOtAnKfmWapekuhlcX.text)[0].split('=')[1]
   DCQUHNYsREPywOtAnKfmWapekuhlcI=DCQUHNYsREPywOtAnKfmWapekuhlcI.replace('{','{"').replace(':','":').replace(',',',"')
   DCQUHNYsREPywOtAnKfmWapekuhlcI=json.loads(DCQUHNYsREPywOtAnKfmWapekuhlcI)
   DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['NREUM']={'ac':DCQUHNYsREPywOtAnKfmWapekuhlcI['accountID'],'tk':DCQUHNYsREPywOtAnKfmWapekuhlcI['trustKey'],'ap':DCQUHNYsREPywOtAnKfmWapekuhlcI['agentID'],'lk':DCQUHNYsREPywOtAnKfmWapekuhlcI['licenseKey'],}
   for DCQUHNYsREPywOtAnKfmWapekuhlcr in DCQUHNYsREPywOtAnKfmWapekuhlcX.cookies:
    if DCQUHNYsREPywOtAnKfmWapekuhlcr.name=='bm_mi':
     DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['bm_mi']=DCQUHNYsREPywOtAnKfmWapekuhlcr.value
    elif DCQUHNYsREPywOtAnKfmWapekuhlcr.name=='bm_sv':
     DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['bm_sv'] =DCQUHNYsREPywOtAnKfmWapekuhlcr.value
     DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['bm_sv_ex']=DCQUHNYsREPywOtAnKfmWapekuhlcr.expires 
  except DCQUHNYsREPywOtAnKfmWapekuhlLS as exception:
   DCQUHNYsREPywOtAnKfmWapekuhlLT(exception)
   return DCQUHNYsREPywOtAnKfmWapekuhlLo
  try:
   DCQUHNYsREPywOtAnKfmWapekuhlcL=DCQUHNYsREPywOtAnKfmWapekuhlVi.API_DOMAIN+'/api/auth'
   DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['PCID']=DCQUHNYsREPywOtAnKfmWapekuhlVi.generatePcId()
   DCQUHNYsREPywOtAnKfmWapekuhlcM=DCQUHNYsREPywOtAnKfmWapekuhlVi.Get_DeviceID()
   DCQUHNYsREPywOtAnKfmWapekuhlcj =DCQUHNYsREPywOtAnKfmWapekuhlcM.split('-')[0]
   DCQUHNYsREPywOtAnKfmWapekuhlVv,DCQUHNYsREPywOtAnKfmWapekuhlVz,DCQUHNYsREPywOtAnKfmWapekuhlVb=DCQUHNYsREPywOtAnKfmWapekuhlVi.Make_authHeader()
   DCQUHNYsREPywOtAnKfmWapekuhlco={'traceparent':DCQUHNYsREPywOtAnKfmWapekuhlVv,'tracestate':DCQUHNYsREPywOtAnKfmWapekuhlVz,'newrelic':DCQUHNYsREPywOtAnKfmWapekuhlVb,'content-type':'application/json',}
   DCQUHNYsREPywOtAnKfmWapekuhlcT={'device':{'deviceId':'web-'+DCQUHNYsREPywOtAnKfmWapekuhlcM,'model':DCQUHNYsREPywOtAnKfmWapekuhlVi.MODEL,'name':'Chrome Desktop '+DCQUHNYsREPywOtAnKfmWapekuhlcj,'os':'Windows','osVersion':'10','type':'webclient',},'email':userid,'password':userpw,}
   DCQUHNYsREPywOtAnKfmWapekuhlcT=json.dumps(DCQUHNYsREPywOtAnKfmWapekuhlcT,separators=(',',':'))
   DCQUHNYsREPywOtAnKfmWapekuhlci={'NEXT_LOCALE':DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['NEXT_LOCALE'],'ak_bmsc':DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['ak_bmsc'],'bm_mi':DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['bm_mi'],'bm_sv':DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['bm_sv'],'PCID':DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['PCID'],}
   DCQUHNYsREPywOtAnKfmWapekuhlcX=DCQUHNYsREPywOtAnKfmWapekuhlVi.callRequestCookies('Post',DCQUHNYsREPywOtAnKfmWapekuhlcL,payload=DCQUHNYsREPywOtAnKfmWapekuhlcT,params=DCQUHNYsREPywOtAnKfmWapekuhlLj,headers=DCQUHNYsREPywOtAnKfmWapekuhlco,cookies=DCQUHNYsREPywOtAnKfmWapekuhlci,redirects=DCQUHNYsREPywOtAnKfmWapekuhlLo)
   if DCQUHNYsREPywOtAnKfmWapekuhlcX.status_code not in[200]:
    DCQUHNYsREPywOtAnKfmWapekuhlcg=json.loads(DCQUHNYsREPywOtAnKfmWapekuhlcX.text)
    if 'error' in DCQUHNYsREPywOtAnKfmWapekuhlcg:
     DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['error']=DCQUHNYsREPywOtAnKfmWapekuhlcg.get('error').get('detail')
    return DCQUHNYsREPywOtAnKfmWapekuhlLo
   for DCQUHNYsREPywOtAnKfmWapekuhlcr in DCQUHNYsREPywOtAnKfmWapekuhlcX.cookies:
    if DCQUHNYsREPywOtAnKfmWapekuhlcr.name=='token':
     DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['token']=DCQUHNYsREPywOtAnKfmWapekuhlcr.value
    elif DCQUHNYsREPywOtAnKfmWapekuhlcr.name=='member_srl':
     DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['member_srl']=DCQUHNYsREPywOtAnKfmWapekuhlcr.value
    elif DCQUHNYsREPywOtAnKfmWapekuhlcr.name=='bm_sv':
     DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['bm_sv'] =DCQUHNYsREPywOtAnKfmWapekuhlcr.value
     DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['bm_sv_ex']=DCQUHNYsREPywOtAnKfmWapekuhlcr.expires 
  except DCQUHNYsREPywOtAnKfmWapekuhlLS as exception:
   DCQUHNYsREPywOtAnKfmWapekuhlLT(exception)
   return DCQUHNYsREPywOtAnKfmWapekuhlLo
  DCQUHNYsREPywOtAnKfmWapekuhlVi.Save_session_acount(userid,userpw,DCQUHNYsREPywOtAnKfmWapekuhlcJ)
  return DCQUHNYsREPywOtAnKfmWapekuhlLG
 def Get_CP_profile(DCQUHNYsREPywOtAnKfmWapekuhlVi,DCQUHNYsREPywOtAnKfmWapekuhlcJ,limit_days=1,re_check=DCQUHNYsREPywOtAnKfmWapekuhlLo):
  if re_check==DCQUHNYsREPywOtAnKfmWapekuhlLG:
   if DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['bm_sv_ex']>DCQUHNYsREPywOtAnKfmWapekuhlLJ(time.time()):
    DCQUHNYsREPywOtAnKfmWapekuhlLT('bm_sv_ex ok')
    return DCQUHNYsREPywOtAnKfmWapekuhlLG
  try:
   DCQUHNYsREPywOtAnKfmWapekuhlcL=DCQUHNYsREPywOtAnKfmWapekuhlVi.API_DOMAIN+'/api/profiles'
   DCQUHNYsREPywOtAnKfmWapekuhlVv,DCQUHNYsREPywOtAnKfmWapekuhlVz,DCQUHNYsREPywOtAnKfmWapekuhlVb=DCQUHNYsREPywOtAnKfmWapekuhlVi.Make_authHeader()
   DCQUHNYsREPywOtAnKfmWapekuhlco={'traceparent':DCQUHNYsREPywOtAnKfmWapekuhlVv,'tracestate':DCQUHNYsREPywOtAnKfmWapekuhlVz,'newrelic':DCQUHNYsREPywOtAnKfmWapekuhlVb,}
   DCQUHNYsREPywOtAnKfmWapekuhlci=DCQUHNYsREPywOtAnKfmWapekuhlVi.make_CP_DefaultCookies()
   DCQUHNYsREPywOtAnKfmWapekuhlcX=DCQUHNYsREPywOtAnKfmWapekuhlVi.callRequestCookies('Get',DCQUHNYsREPywOtAnKfmWapekuhlcL,payload=DCQUHNYsREPywOtAnKfmWapekuhlLj,params=DCQUHNYsREPywOtAnKfmWapekuhlLj,headers=DCQUHNYsREPywOtAnKfmWapekuhlco,cookies=DCQUHNYsREPywOtAnKfmWapekuhlci,redirects=DCQUHNYsREPywOtAnKfmWapekuhlLo)
   if DCQUHNYsREPywOtAnKfmWapekuhlcX.status_code not in[200]:return DCQUHNYsREPywOtAnKfmWapekuhlLo
   DCQUHNYsREPywOtAnKfmWapekuhlcg=json.loads(DCQUHNYsREPywOtAnKfmWapekuhlcX.text)
   DCQUHNYsREPywOtAnKfmWapekuhlcF=0 
   for DCQUHNYsREPywOtAnKfmWapekuhlcr in DCQUHNYsREPywOtAnKfmWapekuhlcX.cookies:
    DCQUHNYsREPywOtAnKfmWapekuhlLT(DCQUHNYsREPywOtAnKfmWapekuhlcr.name)
    if DCQUHNYsREPywOtAnKfmWapekuhlcr.name=='bm_sv':
     DCQUHNYsREPywOtAnKfmWapekuhlcF=1
     DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['bm_sv'] =DCQUHNYsREPywOtAnKfmWapekuhlcr.value
     DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['bm_sv_ex']=DCQUHNYsREPywOtAnKfmWapekuhlcr.expires 
   if DCQUHNYsREPywOtAnKfmWapekuhlcF==0:
    DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['bm_sv_ex']=DCQUHNYsREPywOtAnKfmWapekuhlLJ(time.time())+60*60*2 
   DCQUHNYsREPywOtAnKfmWapekuhlcJ=DCQUHNYsREPywOtAnKfmWapekuhlcg.get('data')[DCQUHNYsREPywOtAnKfmWapekuhlLJ(DCQUHNYsREPywOtAnKfmWapekuhlcJ)]
   DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['accountId']=DCQUHNYsREPywOtAnKfmWapekuhlcJ.get('accountId')
   DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['profileId']=DCQUHNYsREPywOtAnKfmWapekuhlcJ.get('profileId')
  except DCQUHNYsREPywOtAnKfmWapekuhlLS as exception:
   DCQUHNYsREPywOtAnKfmWapekuhlLT(exception)
   return DCQUHNYsREPywOtAnKfmWapekuhlLo
  if re_check==DCQUHNYsREPywOtAnKfmWapekuhlLo:
   DCQUHNYsREPywOtAnKfmWapekuhlcS =DCQUHNYsREPywOtAnKfmWapekuhlVi.Get_Now_Datetime()
   DCQUHNYsREPywOtAnKfmWapekuhlcd=DCQUHNYsREPywOtAnKfmWapekuhlcS+datetime.timedelta(days=limit_days)
   DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['limitdate']=DCQUHNYsREPywOtAnKfmWapekuhlcd.strftime('%Y-%m-%d')
  else:
   DCQUHNYsREPywOtAnKfmWapekuhlLT('re check')
  DCQUHNYsREPywOtAnKfmWapekuhlVi.dic_To_jsonfile(DCQUHNYsREPywOtAnKfmWapekuhlVi.CP_COOKIE_FILENAME,DCQUHNYsREPywOtAnKfmWapekuhlVi.CP)
  return DCQUHNYsREPywOtAnKfmWapekuhlLG
 def Get_Category_GroupList(DCQUHNYsREPywOtAnKfmWapekuhlVi,vType):
  DCQUHNYsREPywOtAnKfmWapekuhlcG=[] 
  try:
   DCQUHNYsREPywOtAnKfmWapekuhlcL=DCQUHNYsREPywOtAnKfmWapekuhlVi.API_VIEWURL+'/v2/discover/feed' 
   DCQUHNYsREPywOtAnKfmWapekuhlcq={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false',}
   DCQUHNYsREPywOtAnKfmWapekuhlcX=DCQUHNYsREPywOtAnKfmWapekuhlVi.callRequestCookies('Get',DCQUHNYsREPywOtAnKfmWapekuhlcL,payload=DCQUHNYsREPywOtAnKfmWapekuhlLj,params=DCQUHNYsREPywOtAnKfmWapekuhlcq,headers=DCQUHNYsREPywOtAnKfmWapekuhlLj,cookies=DCQUHNYsREPywOtAnKfmWapekuhlLj,redirects=DCQUHNYsREPywOtAnKfmWapekuhlLG)
   if DCQUHNYsREPywOtAnKfmWapekuhlcX.status_code not in[200]:return[]
   DCQUHNYsREPywOtAnKfmWapekuhlcg=json.loads(DCQUHNYsREPywOtAnKfmWapekuhlcX.text)
   if vType in['TVSHOWS','MOVIES']:
    DCQUHNYsREPywOtAnKfmWapekuhlcv='Explores' 
   elif vType in['EDUCATION']:
    DCQUHNYsREPywOtAnKfmWapekuhlcv='Collection-Rails-Curation'
   elif vType in['ALL']:
    DCQUHNYsREPywOtAnKfmWapekuhlcv='Explores-Categories'
   for DCQUHNYsREPywOtAnKfmWapekuhlcz in DCQUHNYsREPywOtAnKfmWapekuhlcg.get('data'):
    if DCQUHNYsREPywOtAnKfmWapekuhlcz.get('type')==DCQUHNYsREPywOtAnKfmWapekuhlcv:
     for DCQUHNYsREPywOtAnKfmWapekuhlcb in DCQUHNYsREPywOtAnKfmWapekuhlcz.get('data'):
      if vType in['TVSHOWS','MOVIES']:
       DCQUHNYsREPywOtAnKfmWapekuhlcB=DCQUHNYsREPywOtAnKfmWapekuhlcb.get('collectionId')
      elif vType in['EDUCATION','ALL']:
       DCQUHNYsREPywOtAnKfmWapekuhlcB=DCQUHNYsREPywOtAnKfmWapekuhlcb.get('id')
      DCQUHNYsREPywOtAnKfmWapekuhlcx={'collectionId':DCQUHNYsREPywOtAnKfmWapekuhlcB,'title':DCQUHNYsREPywOtAnKfmWapekuhlcb.get('name'),'category':DCQUHNYsREPywOtAnKfmWapekuhlcz.get('category'),'pre_title':'',}
      DCQUHNYsREPywOtAnKfmWapekuhlcG.append(DCQUHNYsREPywOtAnKfmWapekuhlcx)
     break
  except DCQUHNYsREPywOtAnKfmWapekuhlLS as exception:
   DCQUHNYsREPywOtAnKfmWapekuhlLT(exception)
   return[]
  return DCQUHNYsREPywOtAnKfmWapekuhlcG
 def Get_Category_List(DCQUHNYsREPywOtAnKfmWapekuhlVi,vType,DCQUHNYsREPywOtAnKfmWapekuhlcB,page_int):
  DCQUHNYsREPywOtAnKfmWapekuhlcG=[] 
  DCQUHNYsREPywOtAnKfmWapekuhliV=DCQUHNYsREPywOtAnKfmWapekuhlLo
  try:
   if vType=='ALL':
    DCQUHNYsREPywOtAnKfmWapekuhlco={'x-membersrl':DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['member_srl'],'x-pcid':DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['PCID'],'x-profileid':DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['profileId'],}
    DCQUHNYsREPywOtAnKfmWapekuhlcq={'platform':'WEBCLIENT','page':DCQUHNYsREPywOtAnKfmWapekuhlLg(page_int),'perPage':DCQUHNYsREPywOtAnKfmWapekuhlLg(DCQUHNYsREPywOtAnKfmWapekuhlVi.PAGE_LIMIT),'locale':'ko','sort':'',}
    DCQUHNYsREPywOtAnKfmWapekuhlcL=DCQUHNYsREPywOtAnKfmWapekuhlVi.API_VIEWURL+'/v1/discover/categories/'+DCQUHNYsREPywOtAnKfmWapekuhlcB+'/titles'
    DCQUHNYsREPywOtAnKfmWapekuhlcX=DCQUHNYsREPywOtAnKfmWapekuhlVi.callRequestCookies('Get',DCQUHNYsREPywOtAnKfmWapekuhlcL,payload=DCQUHNYsREPywOtAnKfmWapekuhlLj,params=DCQUHNYsREPywOtAnKfmWapekuhlcq,headers=DCQUHNYsREPywOtAnKfmWapekuhlco,cookies=DCQUHNYsREPywOtAnKfmWapekuhlLj,redirects=DCQUHNYsREPywOtAnKfmWapekuhlLG)
   else: 
    DCQUHNYsREPywOtAnKfmWapekuhlcq={'platform':'WEBCLIENT','page':DCQUHNYsREPywOtAnKfmWapekuhlLg(page_int),'perPage':DCQUHNYsREPywOtAnKfmWapekuhlLg(DCQUHNYsREPywOtAnKfmWapekuhlVi.PAGE_LIMIT),}
    DCQUHNYsREPywOtAnKfmWapekuhlcL=DCQUHNYsREPywOtAnKfmWapekuhlVi.API_VIEWURL+'/v1/discover/collections/'+DCQUHNYsREPywOtAnKfmWapekuhlcB+'/titles'
    DCQUHNYsREPywOtAnKfmWapekuhlcX=DCQUHNYsREPywOtAnKfmWapekuhlVi.callRequestCookies('Get',DCQUHNYsREPywOtAnKfmWapekuhlcL,payload=DCQUHNYsREPywOtAnKfmWapekuhlLj,params=DCQUHNYsREPywOtAnKfmWapekuhlcq,headers=DCQUHNYsREPywOtAnKfmWapekuhlLj,cookies=DCQUHNYsREPywOtAnKfmWapekuhlLj,redirects=DCQUHNYsREPywOtAnKfmWapekuhlLG)
   if DCQUHNYsREPywOtAnKfmWapekuhlcX.status_code not in[200]:return[],DCQUHNYsREPywOtAnKfmWapekuhlLo
   DCQUHNYsREPywOtAnKfmWapekuhlcg=json.loads(DCQUHNYsREPywOtAnKfmWapekuhlcX.text)
   if vType=='ALL':
    DCQUHNYsREPywOtAnKfmWapekuhlic=DCQUHNYsREPywOtAnKfmWapekuhlcg.get('data').get('data')
   else:
    DCQUHNYsREPywOtAnKfmWapekuhlic=DCQUHNYsREPywOtAnKfmWapekuhlcg.get('data')
   for DCQUHNYsREPywOtAnKfmWapekuhlcb in DCQUHNYsREPywOtAnKfmWapekuhlic:
    DCQUHNYsREPywOtAnKfmWapekuhliL=DCQUHNYsREPywOtAnKfmWapekuhlij=DCQUHNYsREPywOtAnKfmWapekuhlLi=DCQUHNYsREPywOtAnKfmWapekuhlLc=''
    if 'poster' in DCQUHNYsREPywOtAnKfmWapekuhlcb.get('images'):DCQUHNYsREPywOtAnKfmWapekuhliL =DCQUHNYsREPywOtAnKfmWapekuhlcb.get('images').get('poster').get('url')
    if 'story-art' in DCQUHNYsREPywOtAnKfmWapekuhlcb.get('images'):DCQUHNYsREPywOtAnKfmWapekuhlij =DCQUHNYsREPywOtAnKfmWapekuhlcb.get('images').get('story-art').get('url')
    if 'title-treatment' in DCQUHNYsREPywOtAnKfmWapekuhlcb.get('images'):DCQUHNYsREPywOtAnKfmWapekuhlLi=DCQUHNYsREPywOtAnKfmWapekuhlcb.get('images').get('title-treatment').get('url')
    if 'story-art' in DCQUHNYsREPywOtAnKfmWapekuhlcb.get('images'):DCQUHNYsREPywOtAnKfmWapekuhlLc =DCQUHNYsREPywOtAnKfmWapekuhlcb.get('images').get('story-art').get('url')
    DCQUHNYsREPywOtAnKfmWapekuhliX=''
    if DCQUHNYsREPywOtAnKfmWapekuhlcb.get('badge')not in[{},DCQUHNYsREPywOtAnKfmWapekuhlLj]:
     for i in DCQUHNYsREPywOtAnKfmWapekuhlcb.get('badge').get('text'):
      DCQUHNYsREPywOtAnKfmWapekuhliX+=i.get('text')
    DCQUHNYsREPywOtAnKfmWapekuhlir=''
    if DCQUHNYsREPywOtAnKfmWapekuhlcb.get('seasonList')!=DCQUHNYsREPywOtAnKfmWapekuhlLj:
     DCQUHNYsREPywOtAnKfmWapekuhlir=','.join(DCQUHNYsREPywOtAnKfmWapekuhlLg(e)for e in DCQUHNYsREPywOtAnKfmWapekuhlcb.get('seasonList'))
    DCQUHNYsREPywOtAnKfmWapekuhliI =[]
    for DCQUHNYsREPywOtAnKfmWapekuhliM in DCQUHNYsREPywOtAnKfmWapekuhlcb.get('tags'):
     DCQUHNYsREPywOtAnKfmWapekuhliI.append(DCQUHNYsREPywOtAnKfmWapekuhliM.get('tag'))
    DCQUHNYsREPywOtAnKfmWapekuhlcx={'id':DCQUHNYsREPywOtAnKfmWapekuhlcb.get('id'),'title':DCQUHNYsREPywOtAnKfmWapekuhlcb.get('title'),'thumbnail':{'poster':DCQUHNYsREPywOtAnKfmWapekuhliL,'thumb':DCQUHNYsREPywOtAnKfmWapekuhlij,'clearlogo':DCQUHNYsREPywOtAnKfmWapekuhlLi,'fanart':DCQUHNYsREPywOtAnKfmWapekuhlLc},'mpaa':DCQUHNYsREPywOtAnKfmWapekuhlcb.get('age_rating'),'duration':DCQUHNYsREPywOtAnKfmWapekuhlcb.get('running_time'),'asis':DCQUHNYsREPywOtAnKfmWapekuhlcb.get('as'),'badge':DCQUHNYsREPywOtAnKfmWapekuhliX,'year':DCQUHNYsREPywOtAnKfmWapekuhlcb.get('meta').get('releaseYear'),'seasonList':DCQUHNYsREPywOtAnKfmWapekuhlir,'genreList':DCQUHNYsREPywOtAnKfmWapekuhliI,}
    DCQUHNYsREPywOtAnKfmWapekuhlcG.append(DCQUHNYsREPywOtAnKfmWapekuhlcx)
   if DCQUHNYsREPywOtAnKfmWapekuhlcg.get('pagination').get('totalPages')>page_int:
    DCQUHNYsREPywOtAnKfmWapekuhliV=DCQUHNYsREPywOtAnKfmWapekuhlLG
  except DCQUHNYsREPywOtAnKfmWapekuhlLS as exception:
   DCQUHNYsREPywOtAnKfmWapekuhlLT(exception)
   return[],DCQUHNYsREPywOtAnKfmWapekuhlLo
  return DCQUHNYsREPywOtAnKfmWapekuhlcG,DCQUHNYsREPywOtAnKfmWapekuhliV
 def Get_Episode_List(DCQUHNYsREPywOtAnKfmWapekuhlVi,programId,season):
  DCQUHNYsREPywOtAnKfmWapekuhlcG=[] 
  try:
   DCQUHNYsREPywOtAnKfmWapekuhlcL=DCQUHNYsREPywOtAnKfmWapekuhlVi.API_VIEWURL+'/v1/discover/titles/'+programId+'/episodes'
   DCQUHNYsREPywOtAnKfmWapekuhlcq={'season':season,'sort':'true','locale':'ko',}
   DCQUHNYsREPywOtAnKfmWapekuhlcX=DCQUHNYsREPywOtAnKfmWapekuhlVi.callRequestCookies('Get',DCQUHNYsREPywOtAnKfmWapekuhlcL,payload=DCQUHNYsREPywOtAnKfmWapekuhlLj,params=DCQUHNYsREPywOtAnKfmWapekuhlcq,headers=DCQUHNYsREPywOtAnKfmWapekuhlLj,cookies=DCQUHNYsREPywOtAnKfmWapekuhlLj,redirects=DCQUHNYsREPywOtAnKfmWapekuhlLG)
   if DCQUHNYsREPywOtAnKfmWapekuhlcX.status_code not in[200]:return[]
   DCQUHNYsREPywOtAnKfmWapekuhlcg=json.loads(DCQUHNYsREPywOtAnKfmWapekuhlcX.text)
   for DCQUHNYsREPywOtAnKfmWapekuhlcb in DCQUHNYsREPywOtAnKfmWapekuhlcg.get('data'):
    DCQUHNYsREPywOtAnKfmWapekuhlij=''
    if 'story-art' in DCQUHNYsREPywOtAnKfmWapekuhlcb.get('images'):DCQUHNYsREPywOtAnKfmWapekuhlij =DCQUHNYsREPywOtAnKfmWapekuhlcb.get('images').get('story-art').get('url')
    DCQUHNYsREPywOtAnKfmWapekuhliI =[]
    for DCQUHNYsREPywOtAnKfmWapekuhliM in DCQUHNYsREPywOtAnKfmWapekuhlcb.get('tags'):
     DCQUHNYsREPywOtAnKfmWapekuhliI.append(DCQUHNYsREPywOtAnKfmWapekuhliM.get('tag'))
    DCQUHNYsREPywOtAnKfmWapekuhlcx={'id':DCQUHNYsREPywOtAnKfmWapekuhlcb.get('id'),'title':DCQUHNYsREPywOtAnKfmWapekuhlcb.get('title'),'thumbnail':{'thumb':DCQUHNYsREPywOtAnKfmWapekuhlij,'fanart':DCQUHNYsREPywOtAnKfmWapekuhlij},'mpaa':DCQUHNYsREPywOtAnKfmWapekuhlcb.get('age_rating'),'duration':DCQUHNYsREPywOtAnKfmWapekuhlcb.get('running_time'),'asis':DCQUHNYsREPywOtAnKfmWapekuhlcb.get('as'),'year':DCQUHNYsREPywOtAnKfmWapekuhlcb.get('meta').get('releaseYear'),'episode':DCQUHNYsREPywOtAnKfmWapekuhlcb.get('episode'),'genreList':DCQUHNYsREPywOtAnKfmWapekuhliI,'desc':DCQUHNYsREPywOtAnKfmWapekuhlcb.get('description'),}
    DCQUHNYsREPywOtAnKfmWapekuhlcG.append(DCQUHNYsREPywOtAnKfmWapekuhlcx)
  except DCQUHNYsREPywOtAnKfmWapekuhlLS as exception:
   DCQUHNYsREPywOtAnKfmWapekuhlLT(exception)
   return[]
  return DCQUHNYsREPywOtAnKfmWapekuhlcG
 def Get_vInfo(DCQUHNYsREPywOtAnKfmWapekuhlVi,titleId):
  try:
   DCQUHNYsREPywOtAnKfmWapekuhlcL=DCQUHNYsREPywOtAnKfmWapekuhlVi.API_VIEWURL+'/v1/discover/titles/'+titleId 
   DCQUHNYsREPywOtAnKfmWapekuhlcq={'locale':'ko'}
   DCQUHNYsREPywOtAnKfmWapekuhlcX=DCQUHNYsREPywOtAnKfmWapekuhlVi.callRequestCookies('Get',DCQUHNYsREPywOtAnKfmWapekuhlcL,payload=DCQUHNYsREPywOtAnKfmWapekuhlLj,params=DCQUHNYsREPywOtAnKfmWapekuhlcq,headers=DCQUHNYsREPywOtAnKfmWapekuhlLj,cookies=DCQUHNYsREPywOtAnKfmWapekuhlLj,redirects=DCQUHNYsREPywOtAnKfmWapekuhlLG)
   if DCQUHNYsREPywOtAnKfmWapekuhlcX.status_code not in[200]:return '','',''
   DCQUHNYsREPywOtAnKfmWapekuhlcg=json.loads(DCQUHNYsREPywOtAnKfmWapekuhlcX.text).get('data')
   DCQUHNYsREPywOtAnKfmWapekuhlir=''
   if DCQUHNYsREPywOtAnKfmWapekuhlcg.get('seasonList')!=DCQUHNYsREPywOtAnKfmWapekuhlLj:
    DCQUHNYsREPywOtAnKfmWapekuhlir=','.join(DCQUHNYsREPywOtAnKfmWapekuhlLg(e)for e in DCQUHNYsREPywOtAnKfmWapekuhlcg.get('seasonList'))
   DCQUHNYsREPywOtAnKfmWapekuhlio={'age_rating':DCQUHNYsREPywOtAnKfmWapekuhlcg.get('age_rating'),'asset_id':DCQUHNYsREPywOtAnKfmWapekuhlcg.get('asset_id'),'availability':DCQUHNYsREPywOtAnKfmWapekuhlcg.get('availability'),'deal_id':DCQUHNYsREPywOtAnKfmWapekuhlcg.get('deal_id'),'downloadable':'true' if DCQUHNYsREPywOtAnKfmWapekuhlcg.get('downloadable')else 'false','region':DCQUHNYsREPywOtAnKfmWapekuhlcg.get('region'),'streamable':'true' if DCQUHNYsREPywOtAnKfmWapekuhlcg.get('streamable')else 'false','asis':DCQUHNYsREPywOtAnKfmWapekuhlcg.get('as'),'seasonList':DCQUHNYsREPywOtAnKfmWapekuhlir}
  except DCQUHNYsREPywOtAnKfmWapekuhlLS as exception:
   DCQUHNYsREPywOtAnKfmWapekuhlLT(exception)
   return{}
  return DCQUHNYsREPywOtAnKfmWapekuhlio
 def Get_eInfo(DCQUHNYsREPywOtAnKfmWapekuhlVi,eventId):
  try:
   DCQUHNYsREPywOtAnKfmWapekuhlcL=DCQUHNYsREPywOtAnKfmWapekuhlVi.API_VIEWURL+'/v1/discover/events/'+eventId 
   DCQUHNYsREPywOtAnKfmWapekuhlcq={'locale':'ko'}
   DCQUHNYsREPywOtAnKfmWapekuhlcX=DCQUHNYsREPywOtAnKfmWapekuhlVi.callRequestCookies('Get',DCQUHNYsREPywOtAnKfmWapekuhlcL,payload=DCQUHNYsREPywOtAnKfmWapekuhlLj,params=DCQUHNYsREPywOtAnKfmWapekuhlcq,headers=DCQUHNYsREPywOtAnKfmWapekuhlLj,cookies=DCQUHNYsREPywOtAnKfmWapekuhlLj,redirects=DCQUHNYsREPywOtAnKfmWapekuhlLG)
   if DCQUHNYsREPywOtAnKfmWapekuhlcX.status_code not in[200]:return '','',''
   DCQUHNYsREPywOtAnKfmWapekuhlcg=json.loads(DCQUHNYsREPywOtAnKfmWapekuhlcX.text).get('data')
   DCQUHNYsREPywOtAnKfmWapekuhlio={'asset_id':DCQUHNYsREPywOtAnKfmWapekuhlcg.get('asset_id'),'deal_id':DCQUHNYsREPywOtAnKfmWapekuhlcg.get('deal_id'),'region':DCQUHNYsREPywOtAnKfmWapekuhlcg.get('region'),'streamable':'true' if DCQUHNYsREPywOtAnKfmWapekuhlcg.get('streamable')else 'false',}
  except DCQUHNYsREPywOtAnKfmWapekuhlLS as exception:
   DCQUHNYsREPywOtAnKfmWapekuhlLT(exception)
   return{}
  return DCQUHNYsREPywOtAnKfmWapekuhlio
 def GetBroadURL(DCQUHNYsREPywOtAnKfmWapekuhlVi,titleId):
  DCQUHNYsREPywOtAnKfmWapekuhliT=''
  DCQUHNYsREPywOtAnKfmWapekuhlig =''
  DCQUHNYsREPywOtAnKfmWapekuhlio=DCQUHNYsREPywOtAnKfmWapekuhlVi.Get_vInfo(titleId)
  if DCQUHNYsREPywOtAnKfmWapekuhlio=={}:return '',''
  try:
   DCQUHNYsREPywOtAnKfmWapekuhlcL=DCQUHNYsREPywOtAnKfmWapekuhlVi.API_DOMAIN+'/api/playback/play' 
   DCQUHNYsREPywOtAnKfmWapekuhlcq={'titleId':titleId}
   DCQUHNYsREPywOtAnKfmWapekuhlVv,DCQUHNYsREPywOtAnKfmWapekuhlVz,DCQUHNYsREPywOtAnKfmWapekuhlVb=DCQUHNYsREPywOtAnKfmWapekuhlVi.Make_authHeader()
   DCQUHNYsREPywOtAnKfmWapekuhlco={'traceparent':DCQUHNYsREPywOtAnKfmWapekuhlVv,'tracestate':DCQUHNYsREPywOtAnKfmWapekuhlVz,'newrelic':DCQUHNYsREPywOtAnKfmWapekuhlVb,'x-force-raw':'true','x-pcid':DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':DCQUHNYsREPywOtAnKfmWapekuhlio.get('age_rating'),'x-title-availability':DCQUHNYsREPywOtAnKfmWapekuhlio.get('availability'),'x-title-brightcove-id':DCQUHNYsREPywOtAnKfmWapekuhlio.get('asset_id'),'x-title-deal-id':DCQUHNYsREPywOtAnKfmWapekuhlio.get('deal_id'),'x-title-downloadable':DCQUHNYsREPywOtAnKfmWapekuhlio.get('downloadable'),'x-title-region':DCQUHNYsREPywOtAnKfmWapekuhlio.get('region'),'x-title-streamable':DCQUHNYsREPywOtAnKfmWapekuhlio.get('streamable'),}
   DCQUHNYsREPywOtAnKfmWapekuhlci=DCQUHNYsREPywOtAnKfmWapekuhlVi.make_CP_DefaultCookies()
   DCQUHNYsREPywOtAnKfmWapekuhlcX=DCQUHNYsREPywOtAnKfmWapekuhlVi.callRequestCookies('Get',DCQUHNYsREPywOtAnKfmWapekuhlcL,payload=DCQUHNYsREPywOtAnKfmWapekuhlLj,params=DCQUHNYsREPywOtAnKfmWapekuhlcq,headers=DCQUHNYsREPywOtAnKfmWapekuhlco,cookies=DCQUHNYsREPywOtAnKfmWapekuhlci,redirects=DCQUHNYsREPywOtAnKfmWapekuhlLG)
   if DCQUHNYsREPywOtAnKfmWapekuhlcX.status_code not in[200]:return '',json.loads(DCQUHNYsREPywOtAnKfmWapekuhlcX.text).get('error').get('detail')
   DCQUHNYsREPywOtAnKfmWapekuhlcg=json.loads(DCQUHNYsREPywOtAnKfmWapekuhlcX.text)
   for DCQUHNYsREPywOtAnKfmWapekuhlcb in DCQUHNYsREPywOtAnKfmWapekuhlcg.get('data').get('raw').get('sources'):
    if DCQUHNYsREPywOtAnKfmWapekuhlcb.get('type')=='application/dash+xml' and DCQUHNYsREPywOtAnKfmWapekuhlcb.get('src')[0:8]=='https://':
     DCQUHNYsREPywOtAnKfmWapekuhliT=DCQUHNYsREPywOtAnKfmWapekuhlcb.get('src')
     if 'key_systems' in DCQUHNYsREPywOtAnKfmWapekuhlcb:
      DCQUHNYsREPywOtAnKfmWapekuhlig =DCQUHNYsREPywOtAnKfmWapekuhlcb.get('key_systems').get('com.widevine.alpha').get('license_url')
     break
  except DCQUHNYsREPywOtAnKfmWapekuhlLS as exception:
   DCQUHNYsREPywOtAnKfmWapekuhlLT(exception)
   return '',''
  return DCQUHNYsREPywOtAnKfmWapekuhliT,DCQUHNYsREPywOtAnKfmWapekuhlig
 def GetEventURL(DCQUHNYsREPywOtAnKfmWapekuhlVi,eventId,DCQUHNYsREPywOtAnKfmWapekuhliz):
  DCQUHNYsREPywOtAnKfmWapekuhliT=''
  DCQUHNYsREPywOtAnKfmWapekuhlig =''
  DCQUHNYsREPywOtAnKfmWapekuhlio=DCQUHNYsREPywOtAnKfmWapekuhlVi.Get_eInfo(eventId)
  if DCQUHNYsREPywOtAnKfmWapekuhlio=={}:return '',''
  try:
   DCQUHNYsREPywOtAnKfmWapekuhlcL=DCQUHNYsREPywOtAnKfmWapekuhlVi.API_DOMAIN+'/api/playback/play' 
   DCQUHNYsREPywOtAnKfmWapekuhlcq={'titleId':eventId,'titleType':DCQUHNYsREPywOtAnKfmWapekuhliz,}
   DCQUHNYsREPywOtAnKfmWapekuhlVv,DCQUHNYsREPywOtAnKfmWapekuhlVz,DCQUHNYsREPywOtAnKfmWapekuhlVb=DCQUHNYsREPywOtAnKfmWapekuhlVi.Make_authHeader()
   DCQUHNYsREPywOtAnKfmWapekuhlco={'traceparent':DCQUHNYsREPywOtAnKfmWapekuhlVv,'tracestate':DCQUHNYsREPywOtAnKfmWapekuhlVz,'newrelic':DCQUHNYsREPywOtAnKfmWapekuhlVb,'x-force-raw':'true','x-pcid':DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':DCQUHNYsREPywOtAnKfmWapekuhlio.get('asset_id'),'x-title-deal-id':DCQUHNYsREPywOtAnKfmWapekuhlio.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':DCQUHNYsREPywOtAnKfmWapekuhlio.get('region'),'x-title-streamable':DCQUHNYsREPywOtAnKfmWapekuhlio.get('streamable'),}
   DCQUHNYsREPywOtAnKfmWapekuhlci=DCQUHNYsREPywOtAnKfmWapekuhlVi.make_CP_DefaultCookies()
   DCQUHNYsREPywOtAnKfmWapekuhlcX=DCQUHNYsREPywOtAnKfmWapekuhlVi.callRequestCookies('Get',DCQUHNYsREPywOtAnKfmWapekuhlcL,payload=DCQUHNYsREPywOtAnKfmWapekuhlLj,params=DCQUHNYsREPywOtAnKfmWapekuhlcq,headers=DCQUHNYsREPywOtAnKfmWapekuhlco,cookies=DCQUHNYsREPywOtAnKfmWapekuhlci,redirects=DCQUHNYsREPywOtAnKfmWapekuhlLG)
   if DCQUHNYsREPywOtAnKfmWapekuhlcX.status_code not in[200]:return '',json.loads(DCQUHNYsREPywOtAnKfmWapekuhlcX.text).get('error').get('detail')
   DCQUHNYsREPywOtAnKfmWapekuhlcg=json.loads(DCQUHNYsREPywOtAnKfmWapekuhlcX.text)
   for DCQUHNYsREPywOtAnKfmWapekuhlcb in DCQUHNYsREPywOtAnKfmWapekuhlcg.get('data').get('raw').get('sources'):
    if DCQUHNYsREPywOtAnKfmWapekuhlcb.get('type')=='application/dash+xml' and DCQUHNYsREPywOtAnKfmWapekuhlcb.get('src')[0:8]=='https://':
     DCQUHNYsREPywOtAnKfmWapekuhliT=DCQUHNYsREPywOtAnKfmWapekuhlcb.get('src')
     if 'key_systems' in DCQUHNYsREPywOtAnKfmWapekuhlcb:
      DCQUHNYsREPywOtAnKfmWapekuhlig =DCQUHNYsREPywOtAnKfmWapekuhlcb.get('key_systems').get('com.widevine.alpha').get('license_url')
     break
  except DCQUHNYsREPywOtAnKfmWapekuhlLS as exception:
   DCQUHNYsREPywOtAnKfmWapekuhlLT(exception)
   return '',''
  return DCQUHNYsREPywOtAnKfmWapekuhliT,DCQUHNYsREPywOtAnKfmWapekuhlig
 def GetEventURL_Live(DCQUHNYsREPywOtAnKfmWapekuhlVi,eventId,DCQUHNYsREPywOtAnKfmWapekuhliz):
  DCQUHNYsREPywOtAnKfmWapekuhliT=''
  DCQUHNYsREPywOtAnKfmWapekuhlig =''
  DCQUHNYsREPywOtAnKfmWapekuhlio=DCQUHNYsREPywOtAnKfmWapekuhlVi.Get_eInfo(eventId)
  if DCQUHNYsREPywOtAnKfmWapekuhlio=={}:return '',''
  try:
   DCQUHNYsREPywOtAnKfmWapekuhlcL=DCQUHNYsREPywOtAnKfmWapekuhlVi.API_DOMAIN+'/api/playback/play' 
   DCQUHNYsREPywOtAnKfmWapekuhlcq={'titleId':eventId,'titleType':DCQUHNYsREPywOtAnKfmWapekuhliz,}
   DCQUHNYsREPywOtAnKfmWapekuhlVv,DCQUHNYsREPywOtAnKfmWapekuhlVz,DCQUHNYsREPywOtAnKfmWapekuhlVb=DCQUHNYsREPywOtAnKfmWapekuhlVi.Make_authHeader()
   DCQUHNYsREPywOtAnKfmWapekuhlco={'traceparent':DCQUHNYsREPywOtAnKfmWapekuhlVv,'tracestate':DCQUHNYsREPywOtAnKfmWapekuhlVz,'newrelic':DCQUHNYsREPywOtAnKfmWapekuhlVb,'x-force-raw':'true','x-pcid':DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':DCQUHNYsREPywOtAnKfmWapekuhlio.get('asset_id'),'x-title-deal-id':DCQUHNYsREPywOtAnKfmWapekuhlio.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':DCQUHNYsREPywOtAnKfmWapekuhlio.get('region'),'x-title-streamable':DCQUHNYsREPywOtAnKfmWapekuhlio.get('streamable'),}
   DCQUHNYsREPywOtAnKfmWapekuhlci=DCQUHNYsREPywOtAnKfmWapekuhlVi.make_CP_DefaultCookies()
   DCQUHNYsREPywOtAnKfmWapekuhlcX=DCQUHNYsREPywOtAnKfmWapekuhlVi.callRequestCookies('Get',DCQUHNYsREPywOtAnKfmWapekuhlcL,payload=DCQUHNYsREPywOtAnKfmWapekuhlLj,params=DCQUHNYsREPywOtAnKfmWapekuhlcq,headers=DCQUHNYsREPywOtAnKfmWapekuhlco,cookies=DCQUHNYsREPywOtAnKfmWapekuhlci,redirects=DCQUHNYsREPywOtAnKfmWapekuhlLG)
   if DCQUHNYsREPywOtAnKfmWapekuhlcX.status_code not in[200]:return '',json.loads(DCQUHNYsREPywOtAnKfmWapekuhlcX.text).get('error').get('detail')
   DCQUHNYsREPywOtAnKfmWapekuhlcg=json.loads(DCQUHNYsREPywOtAnKfmWapekuhlcX.text)
   for DCQUHNYsREPywOtAnKfmWapekuhlcb in DCQUHNYsREPywOtAnKfmWapekuhlcg.get('data').get('raw').get('sources'):
    if DCQUHNYsREPywOtAnKfmWapekuhlcb.get('type')=='application/dash+xml' and 'com.widevine.alpha' in DCQUHNYsREPywOtAnKfmWapekuhlcb.get('key_systems')and DCQUHNYsREPywOtAnKfmWapekuhlcb.get('src')[0:8]=='https://':
     DCQUHNYsREPywOtAnKfmWapekuhliT=DCQUHNYsREPywOtAnKfmWapekuhlcb.get('src')
     DCQUHNYsREPywOtAnKfmWapekuhlig =DCQUHNYsREPywOtAnKfmWapekuhlcb.get('key_systems').get('com.widevine.alpha').get('license_url')
  except DCQUHNYsREPywOtAnKfmWapekuhlLS as exception:
   DCQUHNYsREPywOtAnKfmWapekuhlLT(exception)
   return '',''
  return DCQUHNYsREPywOtAnKfmWapekuhliT,DCQUHNYsREPywOtAnKfmWapekuhlig
 def Get_Theme_GroupList(DCQUHNYsREPywOtAnKfmWapekuhlVi,vType):
  DCQUHNYsREPywOtAnKfmWapekuhlcG=[] 
  try:
   DCQUHNYsREPywOtAnKfmWapekuhlcL=DCQUHNYsREPywOtAnKfmWapekuhlVi.API_VIEWURL+'/v2/discover/feed' 
   DCQUHNYsREPywOtAnKfmWapekuhlcq={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':DCQUHNYsREPywOtAnKfmWapekuhlLg(DCQUHNYsREPywOtAnKfmWapekuhlVi.PAGE_LIMIT),'filterRestrictedContent':'false',}
   DCQUHNYsREPywOtAnKfmWapekuhlcX=DCQUHNYsREPywOtAnKfmWapekuhlVi.callRequestCookies('Get',DCQUHNYsREPywOtAnKfmWapekuhlcL,payload=DCQUHNYsREPywOtAnKfmWapekuhlLj,params=DCQUHNYsREPywOtAnKfmWapekuhlcq,headers=DCQUHNYsREPywOtAnKfmWapekuhlLj,cookies=DCQUHNYsREPywOtAnKfmWapekuhlLj,redirects=DCQUHNYsREPywOtAnKfmWapekuhlLG)
   if DCQUHNYsREPywOtAnKfmWapekuhlcX.status_code not in[200]:return[]
   DCQUHNYsREPywOtAnKfmWapekuhlcg=json.loads(DCQUHNYsREPywOtAnKfmWapekuhlcX.text)
   for DCQUHNYsREPywOtAnKfmWapekuhlcb in DCQUHNYsREPywOtAnKfmWapekuhlcg.get('data'):
    if DCQUHNYsREPywOtAnKfmWapekuhlcb.get('type')=='Title-Rails-Curation':
     DCQUHNYsREPywOtAnKfmWapekuhliF =''
     DCQUHNYsREPywOtAnKfmWapekuhliJ=7
     try:
      for i in DCQUHNYsREPywOtAnKfmWapekuhlLq(DCQUHNYsREPywOtAnKfmWapekuhlLv(DCQUHNYsREPywOtAnKfmWapekuhlcb.get('data'))):
       if i>=DCQUHNYsREPywOtAnKfmWapekuhliJ:
        DCQUHNYsREPywOtAnKfmWapekuhliF=DCQUHNYsREPywOtAnKfmWapekuhliF+'...'
        break
       DCQUHNYsREPywOtAnKfmWapekuhliF=DCQUHNYsREPywOtAnKfmWapekuhliF+DCQUHNYsREPywOtAnKfmWapekuhlcb['data'][i]['title']+'\n'
     except DCQUHNYsREPywOtAnKfmWapekuhlLS as exception:
      DCQUHNYsREPywOtAnKfmWapekuhlLT(exception)
     DCQUHNYsREPywOtAnKfmWapekuhlcx={'collectionId':DCQUHNYsREPywOtAnKfmWapekuhlcb.get('obj_id'),'title':DCQUHNYsREPywOtAnKfmWapekuhlcb.get('row_name'),'category':DCQUHNYsREPywOtAnKfmWapekuhlcb.get('category'),'pre_title':DCQUHNYsREPywOtAnKfmWapekuhliF,}
     DCQUHNYsREPywOtAnKfmWapekuhlcG.append(DCQUHNYsREPywOtAnKfmWapekuhlcx)
  except DCQUHNYsREPywOtAnKfmWapekuhlLS as exception:
   DCQUHNYsREPywOtAnKfmWapekuhlLT(exception)
   return[]
  return DCQUHNYsREPywOtAnKfmWapekuhlcG
 def Get_Event_GroupList(DCQUHNYsREPywOtAnKfmWapekuhlVi):
  DCQUHNYsREPywOtAnKfmWapekuhlcG=[] 
  try:
   DCQUHNYsREPywOtAnKfmWapekuhlcL=DCQUHNYsREPywOtAnKfmWapekuhlVi.API_VIEWURL+'/v2/discover/feed' 
   DCQUHNYsREPywOtAnKfmWapekuhlcq={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':7,'filterRestrictedContent':'false',}
   DCQUHNYsREPywOtAnKfmWapekuhlcX=DCQUHNYsREPywOtAnKfmWapekuhlVi.callRequestCookies('Get',DCQUHNYsREPywOtAnKfmWapekuhlcL,payload=DCQUHNYsREPywOtAnKfmWapekuhlLj,params=DCQUHNYsREPywOtAnKfmWapekuhlcq,headers=DCQUHNYsREPywOtAnKfmWapekuhlLj,cookies=DCQUHNYsREPywOtAnKfmWapekuhlLj,redirects=DCQUHNYsREPywOtAnKfmWapekuhlLG)
   if DCQUHNYsREPywOtAnKfmWapekuhlcX.status_code not in[200]:return[]
   DCQUHNYsREPywOtAnKfmWapekuhlcg=json.loads(DCQUHNYsREPywOtAnKfmWapekuhlcX.text)
   for DCQUHNYsREPywOtAnKfmWapekuhlcb in DCQUHNYsREPywOtAnKfmWapekuhlcg.get('data'):
    if DCQUHNYsREPywOtAnKfmWapekuhlcb.get('row_name').strip()!='':
     DCQUHNYsREPywOtAnKfmWapekuhliF =''
     DCQUHNYsREPywOtAnKfmWapekuhliJ=7
     try:
      for i in DCQUHNYsREPywOtAnKfmWapekuhlLq(DCQUHNYsREPywOtAnKfmWapekuhlLv(DCQUHNYsREPywOtAnKfmWapekuhlcb.get('data'))):
       if i>=DCQUHNYsREPywOtAnKfmWapekuhliJ:
        DCQUHNYsREPywOtAnKfmWapekuhliF=DCQUHNYsREPywOtAnKfmWapekuhliF+'...'
        break
       DCQUHNYsREPywOtAnKfmWapekuhliF=DCQUHNYsREPywOtAnKfmWapekuhliF+DCQUHNYsREPywOtAnKfmWapekuhlcb['data'][i]['title']+'\n'
     except DCQUHNYsREPywOtAnKfmWapekuhlLS as exception:
      DCQUHNYsREPywOtAnKfmWapekuhlLT(exception)
     DCQUHNYsREPywOtAnKfmWapekuhlcx={'collectionId':DCQUHNYsREPywOtAnKfmWapekuhlcb.get('obj_id'),'title':DCQUHNYsREPywOtAnKfmWapekuhlcb.get('row_name'),'category':DCQUHNYsREPywOtAnKfmWapekuhlcb.get('type'),'pre_title':DCQUHNYsREPywOtAnKfmWapekuhliF,}
     DCQUHNYsREPywOtAnKfmWapekuhlcG.append(DCQUHNYsREPywOtAnKfmWapekuhlcx)
  except DCQUHNYsREPywOtAnKfmWapekuhlLS as exception:
   DCQUHNYsREPywOtAnKfmWapekuhlLT(exception)
   return[]
  return DCQUHNYsREPywOtAnKfmWapekuhlcG
 def Get_Event_GameList(DCQUHNYsREPywOtAnKfmWapekuhlVi,DCQUHNYsREPywOtAnKfmWapekuhlcB):
  DCQUHNYsREPywOtAnKfmWapekuhlcG=[] 
  try:
   DCQUHNYsREPywOtAnKfmWapekuhlcL=DCQUHNYsREPywOtAnKfmWapekuhlVi.API_VIEWURL+'/v2/discover/feed' 
   DCQUHNYsREPywOtAnKfmWapekuhlcq={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false',}
   DCQUHNYsREPywOtAnKfmWapekuhlcX=DCQUHNYsREPywOtAnKfmWapekuhlVi.callRequestCookies('Get',DCQUHNYsREPywOtAnKfmWapekuhlcL,payload=DCQUHNYsREPywOtAnKfmWapekuhlLj,params=DCQUHNYsREPywOtAnKfmWapekuhlcq,headers=DCQUHNYsREPywOtAnKfmWapekuhlLj,cookies=DCQUHNYsREPywOtAnKfmWapekuhlLj,redirects=DCQUHNYsREPywOtAnKfmWapekuhlLG)
   if DCQUHNYsREPywOtAnKfmWapekuhlcX.status_code not in[200]:return[]
   DCQUHNYsREPywOtAnKfmWapekuhlcg=json.loads(DCQUHNYsREPywOtAnKfmWapekuhlcX.text)
   for DCQUHNYsREPywOtAnKfmWapekuhlcb in DCQUHNYsREPywOtAnKfmWapekuhlcg.get('data'):
    if DCQUHNYsREPywOtAnKfmWapekuhlcb.get('obj_id')==DCQUHNYsREPywOtAnKfmWapekuhlcB:
     for DCQUHNYsREPywOtAnKfmWapekuhliS in DCQUHNYsREPywOtAnKfmWapekuhlcb.get('data'):
      DCQUHNYsREPywOtAnKfmWapekuhliL=DCQUHNYsREPywOtAnKfmWapekuhlij=DCQUHNYsREPywOtAnKfmWapekuhlLc=''
      if 'poster' in DCQUHNYsREPywOtAnKfmWapekuhliS.get('images'):DCQUHNYsREPywOtAnKfmWapekuhliL =DCQUHNYsREPywOtAnKfmWapekuhliS.get('images').get('poster').get('url')
      if 'story-art' in DCQUHNYsREPywOtAnKfmWapekuhliS.get('images'):DCQUHNYsREPywOtAnKfmWapekuhlij =DCQUHNYsREPywOtAnKfmWapekuhliS.get('images').get('story-art').get('url')
      if 'hero' in DCQUHNYsREPywOtAnKfmWapekuhliS.get('images'):DCQUHNYsREPywOtAnKfmWapekuhlLc =DCQUHNYsREPywOtAnKfmWapekuhliS.get('images').get('hero').get('url')
      DCQUHNYsREPywOtAnKfmWapekuhlid=DCQUHNYsREPywOtAnKfmWapekuhliS.get('meta').get(DCQUHNYsREPywOtAnKfmWapekuhliS.get('category')).get(DCQUHNYsREPywOtAnKfmWapekuhliS.get('sub_category'))
      if 'league' in DCQUHNYsREPywOtAnKfmWapekuhlid:
       DCQUHNYsREPywOtAnKfmWapekuhliG=DCQUHNYsREPywOtAnKfmWapekuhlid.get('league')
      else:
       DCQUHNYsREPywOtAnKfmWapekuhliG=DCQUHNYsREPywOtAnKfmWapekuhlid.get('round')
      DCQUHNYsREPywOtAnKfmWapekuhlcx={'id':DCQUHNYsREPywOtAnKfmWapekuhliS.get('id'),'title':DCQUHNYsREPywOtAnKfmWapekuhliS.get('title'),'thumbnail':{'poster':DCQUHNYsREPywOtAnKfmWapekuhliL,'thumb':DCQUHNYsREPywOtAnKfmWapekuhlij,'fanart':DCQUHNYsREPywOtAnKfmWapekuhlLc},'asis':DCQUHNYsREPywOtAnKfmWapekuhliS.get('type'),'addInfo':DCQUHNYsREPywOtAnKfmWapekuhliG,'starttm':DCQUHNYsREPywOtAnKfmWapekuhlVi.convert_TimeStr(DCQUHNYsREPywOtAnKfmWapekuhliS.get('start_at')),}
      DCQUHNYsREPywOtAnKfmWapekuhlcG.append(DCQUHNYsREPywOtAnKfmWapekuhlcx)
  except DCQUHNYsREPywOtAnKfmWapekuhlLS as exception:
   DCQUHNYsREPywOtAnKfmWapekuhlLT(exception)
   return[]
  return DCQUHNYsREPywOtAnKfmWapekuhlcG
 def Get_Event_List(DCQUHNYsREPywOtAnKfmWapekuhlVi,gameId):
  DCQUHNYsREPywOtAnKfmWapekuhlcG=[] 
  try:
   DCQUHNYsREPywOtAnKfmWapekuhlcL=DCQUHNYsREPywOtAnKfmWapekuhlVi.API_VIEWURL+'/v1/discover/events/'+gameId 
   DCQUHNYsREPywOtAnKfmWapekuhlcq={'platform':'WEBCLIENT','locale':'ko','filterRestrictedContent':'false',}
   DCQUHNYsREPywOtAnKfmWapekuhlcX=DCQUHNYsREPywOtAnKfmWapekuhlVi.callRequestCookies('Get',DCQUHNYsREPywOtAnKfmWapekuhlcL,payload=DCQUHNYsREPywOtAnKfmWapekuhlLj,params=DCQUHNYsREPywOtAnKfmWapekuhlcq,headers=DCQUHNYsREPywOtAnKfmWapekuhlLj,cookies=DCQUHNYsREPywOtAnKfmWapekuhlLj,redirects=DCQUHNYsREPywOtAnKfmWapekuhlLG)
   if DCQUHNYsREPywOtAnKfmWapekuhlcX.status_code not in[200]:return[]
   DCQUHNYsREPywOtAnKfmWapekuhlcg=json.loads(DCQUHNYsREPywOtAnKfmWapekuhlcX.text)
   DCQUHNYsREPywOtAnKfmWapekuhlcb=DCQUHNYsREPywOtAnKfmWapekuhlcg.get('data')
   DCQUHNYsREPywOtAnKfmWapekuhliq=DCQUHNYsREPywOtAnKfmWapekuhlcb.get('end_at')
   DCQUHNYsREPywOtAnKfmWapekuhliq=DCQUHNYsREPywOtAnKfmWapekuhliq[0:19].replace('-','').replace(':','').replace('T','')
   DCQUHNYsREPywOtAnKfmWapekuhliv=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d%H%M%S')
   if DCQUHNYsREPywOtAnKfmWapekuhlLJ(DCQUHNYsREPywOtAnKfmWapekuhliv)<DCQUHNYsREPywOtAnKfmWapekuhlLJ(DCQUHNYsREPywOtAnKfmWapekuhliq):
    DCQUHNYsREPywOtAnKfmWapekuhliL=DCQUHNYsREPywOtAnKfmWapekuhlij=DCQUHNYsREPywOtAnKfmWapekuhlLc=''
    if 'poster' in DCQUHNYsREPywOtAnKfmWapekuhlcb.get('images'):DCQUHNYsREPywOtAnKfmWapekuhliL =DCQUHNYsREPywOtAnKfmWapekuhlcb.get('images').get('poster').get('url')
    if 'story-art' in DCQUHNYsREPywOtAnKfmWapekuhlcb.get('images'):DCQUHNYsREPywOtAnKfmWapekuhlij =DCQUHNYsREPywOtAnKfmWapekuhlcb.get('images').get('story-art').get('url')
    if 'story-art' in DCQUHNYsREPywOtAnKfmWapekuhlcb.get('images'):DCQUHNYsREPywOtAnKfmWapekuhlLc =DCQUHNYsREPywOtAnKfmWapekuhlcb.get('images').get('story-art').get('url')
    DCQUHNYsREPywOtAnKfmWapekuhlcx={'id':DCQUHNYsREPywOtAnKfmWapekuhlcb.get('id'),'title':DCQUHNYsREPywOtAnKfmWapekuhlcb.get('title'),'thumbnail':{'poster':DCQUHNYsREPywOtAnKfmWapekuhliL,'thumb':DCQUHNYsREPywOtAnKfmWapekuhlij,'fanart':DCQUHNYsREPywOtAnKfmWapekuhlLc},'duration':DCQUHNYsREPywOtAnKfmWapekuhlcb.get('running_time'),'asis':DCQUHNYsREPywOtAnKfmWapekuhlcb.get('type'),'starttm':DCQUHNYsREPywOtAnKfmWapekuhlVi.convert_TimeStr(DCQUHNYsREPywOtAnKfmWapekuhlcb.get('start_at')),}
    DCQUHNYsREPywOtAnKfmWapekuhlcG.append(DCQUHNYsREPywOtAnKfmWapekuhlcx)
  except DCQUHNYsREPywOtAnKfmWapekuhlLS as exception:
   DCQUHNYsREPywOtAnKfmWapekuhlLT(exception)
   return[]
  try:
   DCQUHNYsREPywOtAnKfmWapekuhlcL=DCQUHNYsREPywOtAnKfmWapekuhlVi.API_VIEWURL+'/v1/discover/events/'+gameId+'/related' 
   DCQUHNYsREPywOtAnKfmWapekuhlcq={'locale':'ko','page':'1','perPage':'25','platform':'WEBCLIENT','currentPageTracking':'page_discover_title_detail',}
   DCQUHNYsREPywOtAnKfmWapekuhlcX=DCQUHNYsREPywOtAnKfmWapekuhlVi.callRequestCookies('Get',DCQUHNYsREPywOtAnKfmWapekuhlcL,payload=DCQUHNYsREPywOtAnKfmWapekuhlLj,params=DCQUHNYsREPywOtAnKfmWapekuhlcq,headers=DCQUHNYsREPywOtAnKfmWapekuhlLj,cookies=DCQUHNYsREPywOtAnKfmWapekuhlLj,redirects=DCQUHNYsREPywOtAnKfmWapekuhlLG)
   if DCQUHNYsREPywOtAnKfmWapekuhlcX.status_code not in[200]:return[]
   DCQUHNYsREPywOtAnKfmWapekuhlcg=json.loads(DCQUHNYsREPywOtAnKfmWapekuhlcX.text)
   for DCQUHNYsREPywOtAnKfmWapekuhlcb in DCQUHNYsREPywOtAnKfmWapekuhlcg.get('data').get('data'):
    DCQUHNYsREPywOtAnKfmWapekuhliL=DCQUHNYsREPywOtAnKfmWapekuhlij=DCQUHNYsREPywOtAnKfmWapekuhlLc=''
    if 'poster' in DCQUHNYsREPywOtAnKfmWapekuhlcb.get('images'):DCQUHNYsREPywOtAnKfmWapekuhliL =DCQUHNYsREPywOtAnKfmWapekuhlcb.get('images').get('poster').get('url')
    if 'story-art' in DCQUHNYsREPywOtAnKfmWapekuhlcb.get('images'):DCQUHNYsREPywOtAnKfmWapekuhlij =DCQUHNYsREPywOtAnKfmWapekuhlcb.get('images').get('story-art').get('url')
    if 'story-art' in DCQUHNYsREPywOtAnKfmWapekuhlcb.get('images'):DCQUHNYsREPywOtAnKfmWapekuhlLc =DCQUHNYsREPywOtAnKfmWapekuhlcb.get('images').get('story-art').get('url')
    DCQUHNYsREPywOtAnKfmWapekuhlcx={'id':DCQUHNYsREPywOtAnKfmWapekuhlcb.get('id'),'title':DCQUHNYsREPywOtAnKfmWapekuhlcb.get('title'),'thumbnail':{'poster':DCQUHNYsREPywOtAnKfmWapekuhliL,'thumb':DCQUHNYsREPywOtAnKfmWapekuhlij,'fanart':DCQUHNYsREPywOtAnKfmWapekuhlLc},'duration':DCQUHNYsREPywOtAnKfmWapekuhlcb.get('running_time'),'asis':DCQUHNYsREPywOtAnKfmWapekuhlcb.get('type'),}
    DCQUHNYsREPywOtAnKfmWapekuhlcG.append(DCQUHNYsREPywOtAnKfmWapekuhlcx)
  except DCQUHNYsREPywOtAnKfmWapekuhlLS as exception:
   DCQUHNYsREPywOtAnKfmWapekuhlLT(exception)
   return[]
  return DCQUHNYsREPywOtAnKfmWapekuhlcG
 def Get_Search_List(DCQUHNYsREPywOtAnKfmWapekuhlVi,search_key,page_int):
  DCQUHNYsREPywOtAnKfmWapekuhlcG=[] 
  DCQUHNYsREPywOtAnKfmWapekuhliV=DCQUHNYsREPywOtAnKfmWapekuhlLo
  try:
   DCQUHNYsREPywOtAnKfmWapekuhlcL=DCQUHNYsREPywOtAnKfmWapekuhlVi.API_VIEWURL+'/v2/search' 
   DCQUHNYsREPywOtAnKfmWapekuhlcq={'query':search_key,'platform':'WEBCLIENT','page':DCQUHNYsREPywOtAnKfmWapekuhlLg(page_int),'perPage':DCQUHNYsREPywOtAnKfmWapekuhlLg(DCQUHNYsREPywOtAnKfmWapekuhlVi.SEARCH_LIMIT),}
   DCQUHNYsREPywOtAnKfmWapekuhlco={'x-membersrl':DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['member_srl'],'x-pcid':DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['PCID'],'x-profileid':DCQUHNYsREPywOtAnKfmWapekuhlVi.CP['SESSION']['profileId'],}
   DCQUHNYsREPywOtAnKfmWapekuhlcX=DCQUHNYsREPywOtAnKfmWapekuhlVi.callRequestCookies('Get',DCQUHNYsREPywOtAnKfmWapekuhlcL,payload=DCQUHNYsREPywOtAnKfmWapekuhlLj,params=DCQUHNYsREPywOtAnKfmWapekuhlcq,headers=DCQUHNYsREPywOtAnKfmWapekuhlco,cookies=DCQUHNYsREPywOtAnKfmWapekuhlLj,redirects=DCQUHNYsREPywOtAnKfmWapekuhlLG)
   if DCQUHNYsREPywOtAnKfmWapekuhlcX.status_code not in[200]:return[],DCQUHNYsREPywOtAnKfmWapekuhlLo
   DCQUHNYsREPywOtAnKfmWapekuhlcg=json.loads(DCQUHNYsREPywOtAnKfmWapekuhlcX.text)
   for DCQUHNYsREPywOtAnKfmWapekuhlcb in DCQUHNYsREPywOtAnKfmWapekuhlcg.get('data').get('data'):
    DCQUHNYsREPywOtAnKfmWapekuhlcb=DCQUHNYsREPywOtAnKfmWapekuhlcb.get('data')
    DCQUHNYsREPywOtAnKfmWapekuhliL=DCQUHNYsREPywOtAnKfmWapekuhlij=DCQUHNYsREPywOtAnKfmWapekuhlLi=DCQUHNYsREPywOtAnKfmWapekuhlLc=''
    if 'poster' in DCQUHNYsREPywOtAnKfmWapekuhlcb.get('images'):DCQUHNYsREPywOtAnKfmWapekuhliL =DCQUHNYsREPywOtAnKfmWapekuhlcb.get('images').get('poster').get('url')
    if 'story-art' in DCQUHNYsREPywOtAnKfmWapekuhlcb.get('images'):DCQUHNYsREPywOtAnKfmWapekuhlij =DCQUHNYsREPywOtAnKfmWapekuhlcb.get('images').get('story-art').get('url')
    if 'title-treatment' in DCQUHNYsREPywOtAnKfmWapekuhlcb.get('images'):DCQUHNYsREPywOtAnKfmWapekuhlLi=DCQUHNYsREPywOtAnKfmWapekuhlcb.get('images').get('title-treatment').get('url')
    if 'story-art' in DCQUHNYsREPywOtAnKfmWapekuhlcb.get('images'):DCQUHNYsREPywOtAnKfmWapekuhlLc =DCQUHNYsREPywOtAnKfmWapekuhlcb.get('images').get('story-art').get('url')
    DCQUHNYsREPywOtAnKfmWapekuhliX=''
    if DCQUHNYsREPywOtAnKfmWapekuhlcb.get('badge')not in[{},DCQUHNYsREPywOtAnKfmWapekuhlLj]:
     for i in DCQUHNYsREPywOtAnKfmWapekuhlcb.get('badge').get('text'):
      if DCQUHNYsREPywOtAnKfmWapekuhliX!='':DCQUHNYsREPywOtAnKfmWapekuhliX+=' '
      DCQUHNYsREPywOtAnKfmWapekuhliX+=i.get('text')
    if 'as' in DCQUHNYsREPywOtAnKfmWapekuhlcb:
     DCQUHNYsREPywOtAnKfmWapekuhliz=DCQUHNYsREPywOtAnKfmWapekuhlcb.get('as') 
    else:
     DCQUHNYsREPywOtAnKfmWapekuhliz=DCQUHNYsREPywOtAnKfmWapekuhlcb.get('type')
    DCQUHNYsREPywOtAnKfmWapekuhlcx={'id':DCQUHNYsREPywOtAnKfmWapekuhlcb.get('id'),'title':DCQUHNYsREPywOtAnKfmWapekuhlcb.get('title'),'asis':DCQUHNYsREPywOtAnKfmWapekuhliz,'thumbnail':{'poster':DCQUHNYsREPywOtAnKfmWapekuhliL,'thumb':DCQUHNYsREPywOtAnKfmWapekuhlij,'clearlogo':DCQUHNYsREPywOtAnKfmWapekuhlLi,'fanart':DCQUHNYsREPywOtAnKfmWapekuhlLc},'mpaa':DCQUHNYsREPywOtAnKfmWapekuhlcb.get('age_rating'),'duration':DCQUHNYsREPywOtAnKfmWapekuhlcb.get('running_time'),'badge':DCQUHNYsREPywOtAnKfmWapekuhliX,'year':DCQUHNYsREPywOtAnKfmWapekuhlcb.get('meta').get('releaseYear'),}
    DCQUHNYsREPywOtAnKfmWapekuhlcG.append(DCQUHNYsREPywOtAnKfmWapekuhlcx)
   if DCQUHNYsREPywOtAnKfmWapekuhlcg.get('pagination').get('totalPages')>page_int:
    DCQUHNYsREPywOtAnKfmWapekuhliV=DCQUHNYsREPywOtAnKfmWapekuhlLG
  except DCQUHNYsREPywOtAnKfmWapekuhlLS as exception:
   DCQUHNYsREPywOtAnKfmWapekuhlLT(exception)
   return[],DCQUHNYsREPywOtAnKfmWapekuhlLo
  return DCQUHNYsREPywOtAnKfmWapekuhlcG,DCQUHNYsREPywOtAnKfmWapekuhliV
 def GetBookmarkInfo(DCQUHNYsREPywOtAnKfmWapekuhlVi,videoid,vidtype):
  DCQUHNYsREPywOtAnKfmWapekuhlib={'indexinfo':{'ott':'coupang','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  DCQUHNYsREPywOtAnKfmWapekuhlcL=DCQUHNYsREPywOtAnKfmWapekuhlVi.API_VIEWURL+'/v1/discover/titles/'+videoid 
  DCQUHNYsREPywOtAnKfmWapekuhlcq={'locale':'ko'}
  DCQUHNYsREPywOtAnKfmWapekuhlcX=DCQUHNYsREPywOtAnKfmWapekuhlVi.callRequestCookies('Get',DCQUHNYsREPywOtAnKfmWapekuhlcL,payload=DCQUHNYsREPywOtAnKfmWapekuhlLj,params=DCQUHNYsREPywOtAnKfmWapekuhlcq,headers=DCQUHNYsREPywOtAnKfmWapekuhlLj,cookies=DCQUHNYsREPywOtAnKfmWapekuhlLj,redirects=DCQUHNYsREPywOtAnKfmWapekuhlLG)
  if DCQUHNYsREPywOtAnKfmWapekuhlcX.status_code not in[200]:return{}
  DCQUHNYsREPywOtAnKfmWapekuhliB=json.loads(DCQUHNYsREPywOtAnKfmWapekuhlcX.text).get('data')
  DCQUHNYsREPywOtAnKfmWapekuhlix=DCQUHNYsREPywOtAnKfmWapekuhliB.get('title')
  DCQUHNYsREPywOtAnKfmWapekuhlLV =DCQUHNYsREPywOtAnKfmWapekuhliB.get('meta').get('releaseYear')
  DCQUHNYsREPywOtAnKfmWapekuhlib['saveinfo']['infoLabels']['title']=DCQUHNYsREPywOtAnKfmWapekuhlix
  if vidtype=='movie':
   DCQUHNYsREPywOtAnKfmWapekuhlix='%s  (%s)'%(DCQUHNYsREPywOtAnKfmWapekuhlix,DCQUHNYsREPywOtAnKfmWapekuhlLV)
  DCQUHNYsREPywOtAnKfmWapekuhlib['saveinfo']['title'] =DCQUHNYsREPywOtAnKfmWapekuhlix
  DCQUHNYsREPywOtAnKfmWapekuhlib['saveinfo']['infoLabels']['mpaa'] =DCQUHNYsREPywOtAnKfmWapekuhliB.get('age_rating')
  DCQUHNYsREPywOtAnKfmWapekuhlib['saveinfo']['infoLabels']['plot'] ='%s\n\n%s'%(DCQUHNYsREPywOtAnKfmWapekuhliB.get('short_description'),DCQUHNYsREPywOtAnKfmWapekuhliB.get('description'))
  DCQUHNYsREPywOtAnKfmWapekuhlib['saveinfo']['infoLabels']['year'] =DCQUHNYsREPywOtAnKfmWapekuhlLV
  if vidtype=='movie':
   DCQUHNYsREPywOtAnKfmWapekuhlib['saveinfo']['infoLabels']['duration']=DCQUHNYsREPywOtAnKfmWapekuhliB.get('running_time')
  DCQUHNYsREPywOtAnKfmWapekuhliL =''
  DCQUHNYsREPywOtAnKfmWapekuhlLc =''
  DCQUHNYsREPywOtAnKfmWapekuhlij =''
  DCQUHNYsREPywOtAnKfmWapekuhlLi=''
  if DCQUHNYsREPywOtAnKfmWapekuhliB.get('images').get('poster') !=DCQUHNYsREPywOtAnKfmWapekuhlLj:DCQUHNYsREPywOtAnKfmWapekuhliL =DCQUHNYsREPywOtAnKfmWapekuhliB.get('images').get('poster').get('url')
  if DCQUHNYsREPywOtAnKfmWapekuhliB.get('images').get('background') !=DCQUHNYsREPywOtAnKfmWapekuhlLj:DCQUHNYsREPywOtAnKfmWapekuhlLc =DCQUHNYsREPywOtAnKfmWapekuhliB.get('images').get('background').get('url')
  if DCQUHNYsREPywOtAnKfmWapekuhliB.get('images').get('story-art') !=DCQUHNYsREPywOtAnKfmWapekuhlLj:DCQUHNYsREPywOtAnKfmWapekuhlij =DCQUHNYsREPywOtAnKfmWapekuhliB.get('images').get('story-art').get('url')
  if DCQUHNYsREPywOtAnKfmWapekuhliB.get('images').get('title-treatment')!=DCQUHNYsREPywOtAnKfmWapekuhlLj:DCQUHNYsREPywOtAnKfmWapekuhlLi=DCQUHNYsREPywOtAnKfmWapekuhliB.get('images').get('title-treatment').get('url')
  if DCQUHNYsREPywOtAnKfmWapekuhlLc=='':DCQUHNYsREPywOtAnKfmWapekuhlLc=DCQUHNYsREPywOtAnKfmWapekuhlij
  DCQUHNYsREPywOtAnKfmWapekuhlib['saveinfo']['thumbnail']['poster']=DCQUHNYsREPywOtAnKfmWapekuhliL
  DCQUHNYsREPywOtAnKfmWapekuhlib['saveinfo']['thumbnail']['fanart']=DCQUHNYsREPywOtAnKfmWapekuhlLc
  DCQUHNYsREPywOtAnKfmWapekuhlib['saveinfo']['thumbnail']['thumb']=DCQUHNYsREPywOtAnKfmWapekuhlij
  DCQUHNYsREPywOtAnKfmWapekuhlib['saveinfo']['thumbnail']['clearlogo']=DCQUHNYsREPywOtAnKfmWapekuhlLi
  DCQUHNYsREPywOtAnKfmWapekuhlLX=[]
  for DCQUHNYsREPywOtAnKfmWapekuhliM in DCQUHNYsREPywOtAnKfmWapekuhliB.get('tags'):DCQUHNYsREPywOtAnKfmWapekuhlLX.append(DCQUHNYsREPywOtAnKfmWapekuhliM.get('tag'))
  if DCQUHNYsREPywOtAnKfmWapekuhlLv(DCQUHNYsREPywOtAnKfmWapekuhlLX)>0:
   DCQUHNYsREPywOtAnKfmWapekuhlib['saveinfo']['infoLabels']['genre']=DCQUHNYsREPywOtAnKfmWapekuhlLX
  DCQUHNYsREPywOtAnKfmWapekuhlLr=[]
  DCQUHNYsREPywOtAnKfmWapekuhlLI=[]
  for DCQUHNYsREPywOtAnKfmWapekuhliM in DCQUHNYsREPywOtAnKfmWapekuhliB.get('people'):
   if DCQUHNYsREPywOtAnKfmWapekuhliM.get('role')=='CAST' :DCQUHNYsREPywOtAnKfmWapekuhlLr.append(DCQUHNYsREPywOtAnKfmWapekuhliM.get('name'))
   if DCQUHNYsREPywOtAnKfmWapekuhliM.get('role')=='DIRECTOR':DCQUHNYsREPywOtAnKfmWapekuhlLI.append(DCQUHNYsREPywOtAnKfmWapekuhliM.get('name'))
  if DCQUHNYsREPywOtAnKfmWapekuhlLv(DCQUHNYsREPywOtAnKfmWapekuhlLr)>0:
   DCQUHNYsREPywOtAnKfmWapekuhlib['saveinfo']['infoLabels']['cast'] =DCQUHNYsREPywOtAnKfmWapekuhlLr
  if DCQUHNYsREPywOtAnKfmWapekuhlLv(DCQUHNYsREPywOtAnKfmWapekuhlLI)>0:
   DCQUHNYsREPywOtAnKfmWapekuhlib['saveinfo']['infoLabels']['director']=DCQUHNYsREPywOtAnKfmWapekuhlLI
  return DCQUHNYsREPywOtAnKfmWapekuhlib
# Created by pyminifier (https://github.com/liftoff/pyminifier)
