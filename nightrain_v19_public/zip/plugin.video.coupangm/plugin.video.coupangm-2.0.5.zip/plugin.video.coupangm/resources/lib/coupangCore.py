__author__="NightRain"
fJWvkClwdThKOerVHgRzqMpbYsnPXc=object
fJWvkClwdThKOerVHgRzqMpbYsnPXy=None
fJWvkClwdThKOerVHgRzqMpbYsnPXt=False
fJWvkClwdThKOerVHgRzqMpbYsnPXi=print
fJWvkClwdThKOerVHgRzqMpbYsnPXQ=str
fJWvkClwdThKOerVHgRzqMpbYsnPXa=open
fJWvkClwdThKOerVHgRzqMpbYsnPXU=int
fJWvkClwdThKOerVHgRzqMpbYsnPXF=Exception
fJWvkClwdThKOerVHgRzqMpbYsnPXA=id
fJWvkClwdThKOerVHgRzqMpbYsnPXx=True
fJWvkClwdThKOerVHgRzqMpbYsnPXD=range
fJWvkClwdThKOerVHgRzqMpbYsnPXo=len
import urllib
import re
import json
import requests
import datetime
import time
import random
import base64
class fJWvkClwdThKOerVHgRzqMpbYsnPSm(fJWvkClwdThKOerVHgRzqMpbYsnPXc):
 def __init__(fJWvkClwdThKOerVHgRzqMpbYsnPSN):
  fJWvkClwdThKOerVHgRzqMpbYsnPSN.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.82 Safari/537.36'
  fJWvkClwdThKOerVHgRzqMpbYsnPSN.MODEL ='Chrome_98' 
  fJWvkClwdThKOerVHgRzqMpbYsnPSN.DEFAULT_HEADER ={'user-agent':fJWvkClwdThKOerVHgRzqMpbYsnPSN.USER_AGENT}
  fJWvkClwdThKOerVHgRzqMpbYsnPSN.API_DOMAIN ='https://www.coupangplay.com'
  fJWvkClwdThKOerVHgRzqMpbYsnPSN.API_VIEWURL ='https://discover.coupangstreaming.com'
  fJWvkClwdThKOerVHgRzqMpbYsnPSN.PAGE_LIMIT =40
  fJWvkClwdThKOerVHgRzqMpbYsnPSN.SEARCH_LIMIT =20
  fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP={}
  fJWvkClwdThKOerVHgRzqMpbYsnPSN.Init_CP()
  fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP_DEVICE_FILENAME=''
  fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP_COOKIE_FILENAME=''
 def callRequestCookies(fJWvkClwdThKOerVHgRzqMpbYsnPSN,jobtype,fJWvkClwdThKOerVHgRzqMpbYsnPmX,payload=fJWvkClwdThKOerVHgRzqMpbYsnPXy,params=fJWvkClwdThKOerVHgRzqMpbYsnPXy,headers=fJWvkClwdThKOerVHgRzqMpbYsnPXy,cookies=fJWvkClwdThKOerVHgRzqMpbYsnPXy,redirects=fJWvkClwdThKOerVHgRzqMpbYsnPXt):
  fJWvkClwdThKOerVHgRzqMpbYsnPSX=fJWvkClwdThKOerVHgRzqMpbYsnPSN.DEFAULT_HEADER
  if headers:fJWvkClwdThKOerVHgRzqMpbYsnPSX.update(headers)
  if jobtype=='Get':
   fJWvkClwdThKOerVHgRzqMpbYsnPSB=requests.get(fJWvkClwdThKOerVHgRzqMpbYsnPmX,params=params,headers=fJWvkClwdThKOerVHgRzqMpbYsnPSX,cookies=cookies,allow_redirects=redirects)
  else:
   fJWvkClwdThKOerVHgRzqMpbYsnPSB=requests.post(fJWvkClwdThKOerVHgRzqMpbYsnPmX,data=payload,params=params,headers=fJWvkClwdThKOerVHgRzqMpbYsnPSX,cookies=cookies,allow_redirects=redirects)
  fJWvkClwdThKOerVHgRzqMpbYsnPXi(fJWvkClwdThKOerVHgRzqMpbYsnPXQ(fJWvkClwdThKOerVHgRzqMpbYsnPSB.status_code)+' - '+fJWvkClwdThKOerVHgRzqMpbYsnPXQ(fJWvkClwdThKOerVHgRzqMpbYsnPSB.url))
  return fJWvkClwdThKOerVHgRzqMpbYsnPSB
 def callRequestCookies_test(fJWvkClwdThKOerVHgRzqMpbYsnPSN,jobtype,fJWvkClwdThKOerVHgRzqMpbYsnPmX,payload=fJWvkClwdThKOerVHgRzqMpbYsnPXy,params=fJWvkClwdThKOerVHgRzqMpbYsnPXy,headers=fJWvkClwdThKOerVHgRzqMpbYsnPXy,cookies=fJWvkClwdThKOerVHgRzqMpbYsnPXy,redirects=fJWvkClwdThKOerVHgRzqMpbYsnPXt):
  fJWvkClwdThKOerVHgRzqMpbYsnPSX=fJWvkClwdThKOerVHgRzqMpbYsnPSN.DEFAULT_HEADER
  if headers:fJWvkClwdThKOerVHgRzqMpbYsnPSX.update(headers)
  fJWvkClwdThKOerVHgRzqMpbYsnPSB=requests.Request('POST',fJWvkClwdThKOerVHgRzqMpbYsnPmX,headers=headers,data=payload,params=params,cookies=cookies)
  fJWvkClwdThKOerVHgRzqMpbYsnPSL=fJWvkClwdThKOerVHgRzqMpbYsnPSB.prepare()
  fJWvkClwdThKOerVHgRzqMpbYsnPSN.pretty_print_POST(fJWvkClwdThKOerVHgRzqMpbYsnPSL)
  return fJWvkClwdThKOerVHgRzqMpbYsnPSB
 def pretty_print_POST(fJWvkClwdThKOerVHgRzqMpbYsnPSN,req):
  fJWvkClwdThKOerVHgRzqMpbYsnPXi('{}\n{}\r\n{}\r\n\r\n{}'.format('-----------START-----------',req.method+' '+req.url,'\r\n'.join('{}: {}'.format(k,v)for k,v in req.headers.items()),req.body,))
 def dic_To_jsonfile(fJWvkClwdThKOerVHgRzqMpbYsnPSN,filename,fJWvkClwdThKOerVHgRzqMpbYsnPSu):
  if filename=='':return
  fp=fJWvkClwdThKOerVHgRzqMpbYsnPXa(filename,'w',-1,'utf-8')
  json.dump(fJWvkClwdThKOerVHgRzqMpbYsnPSu,fp,indent=4,ensure_ascii=fJWvkClwdThKOerVHgRzqMpbYsnPXt)
  fp.close()
 def jsonfile_To_dic(fJWvkClwdThKOerVHgRzqMpbYsnPSN,filename):
  if filename=='':return fJWvkClwdThKOerVHgRzqMpbYsnPXy
  try:
   fp=fJWvkClwdThKOerVHgRzqMpbYsnPXa(filename,'r',-1,'utf-8')
   fJWvkClwdThKOerVHgRzqMpbYsnPSy=json.load(fp)
   fp.close()
  except:
   fJWvkClwdThKOerVHgRzqMpbYsnPSy={}
  return fJWvkClwdThKOerVHgRzqMpbYsnPSy
 def convert_TimeStr(fJWvkClwdThKOerVHgRzqMpbYsnPSN,fJWvkClwdThKOerVHgRzqMpbYsnPSt):
  try:
   fJWvkClwdThKOerVHgRzqMpbYsnPSt =fJWvkClwdThKOerVHgRzqMpbYsnPSt[0:16]
   fJWvkClwdThKOerVHgRzqMpbYsnPSi=datetime.datetime.strptime(fJWvkClwdThKOerVHgRzqMpbYsnPSt,'%Y-%m-%dT%H:%M')+datetime.timedelta(hours=9)
   return fJWvkClwdThKOerVHgRzqMpbYsnPSi.strftime('%Y-%m-%d %H:%M')
  except:
   return fJWvkClwdThKOerVHgRzqMpbYsnPXy
 def Get_Now_Datetime(fJWvkClwdThKOerVHgRzqMpbYsnPSN):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetNoCache(fJWvkClwdThKOerVHgRzqMpbYsnPSN):
  fJWvkClwdThKOerVHgRzqMpbYsnPSa =fJWvkClwdThKOerVHgRzqMpbYsnPXU(time.time()*1000)
  return fJWvkClwdThKOerVHgRzqMpbYsnPSa
 def generatePcId(fJWvkClwdThKOerVHgRzqMpbYsnPSN):
  t=fJWvkClwdThKOerVHgRzqMpbYsnPSN.GetNoCache()
  r=random.random()
  fJWvkClwdThKOerVHgRzqMpbYsnPSU=fJWvkClwdThKOerVHgRzqMpbYsnPXQ(t)+fJWvkClwdThKOerVHgRzqMpbYsnPXQ(r)[2:12]
  return fJWvkClwdThKOerVHgRzqMpbYsnPSU
 def generatePvId(fJWvkClwdThKOerVHgRzqMpbYsnPSN,genType='1'):
  import hashlib
  m=hashlib.md5()
  fJWvkClwdThKOerVHgRzqMpbYsnPSF=fJWvkClwdThKOerVHgRzqMpbYsnPXQ(random.random())
  m.update(fJWvkClwdThKOerVHgRzqMpbYsnPSF.encode('utf-8'))
  fJWvkClwdThKOerVHgRzqMpbYsnPSA=fJWvkClwdThKOerVHgRzqMpbYsnPXQ(m.hexdigest())
  if genType=='1':
   return '%s-%s-%s-%s-%s'%(fJWvkClwdThKOerVHgRzqMpbYsnPSA[:8],fJWvkClwdThKOerVHgRzqMpbYsnPSA[8:12],fJWvkClwdThKOerVHgRzqMpbYsnPSA[12:16],fJWvkClwdThKOerVHgRzqMpbYsnPSA[16:20],fJWvkClwdThKOerVHgRzqMpbYsnPSA[20:])
  else:
   return fJWvkClwdThKOerVHgRzqMpbYsnPSA
 def Get_DeviceID(fJWvkClwdThKOerVHgRzqMpbYsnPSN):
  fJWvkClwdThKOerVHgRzqMpbYsnPSx=''
  try: 
   fp=fJWvkClwdThKOerVHgRzqMpbYsnPXa(fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP_DEVICE_FILENAME,'r',-1,'utf-8')
   fJWvkClwdThKOerVHgRzqMpbYsnPSD= json.load(fp)
   fp.close()
   fJWvkClwdThKOerVHgRzqMpbYsnPSx=fJWvkClwdThKOerVHgRzqMpbYsnPSD.get('device_id')
  except fJWvkClwdThKOerVHgRzqMpbYsnPXF as exception:
   fJWvkClwdThKOerVHgRzqMpbYsnPXy
  if fJWvkClwdThKOerVHgRzqMpbYsnPSx=='':
   fJWvkClwdThKOerVHgRzqMpbYsnPSx=fJWvkClwdThKOerVHgRzqMpbYsnPSN.generatePvId(genType='1')
   try: 
    fp=fJWvkClwdThKOerVHgRzqMpbYsnPXa(fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP_DEVICE_FILENAME,'w',-1,'utf-8')
    json.dump({'device_id':fJWvkClwdThKOerVHgRzqMpbYsnPSx},fp,indent=4,ensure_ascii=fJWvkClwdThKOerVHgRzqMpbYsnPXt)
    fp.close()
   except fJWvkClwdThKOerVHgRzqMpbYsnPXF as exception:
    return ''
  return fJWvkClwdThKOerVHgRzqMpbYsnPSx
 def Make_authHeader(fJWvkClwdThKOerVHgRzqMpbYsnPSN):
  tr=fJWvkClwdThKOerVHgRzqMpbYsnPSN.generatePvId(genType=2)
  ti=fJWvkClwdThKOerVHgRzqMpbYsnPSN.GetNoCache()
  fJWvkClwdThKOerVHgRzqMpbYsnPXA=fJWvkClwdThKOerVHgRzqMpbYsnPSN.generatePvId(genType=2)[:16]
  fJWvkClwdThKOerVHgRzqMpbYsnPSo='00-%s-%s-01'%(tr,fJWvkClwdThKOerVHgRzqMpbYsnPXA,)
  fJWvkClwdThKOerVHgRzqMpbYsnPSI ='%s@nr=0-1-%s-%s-%s----%s'%(fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['NREUM']['tk'],fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['NREUM']['ac'],fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['NREUM']['ap'],fJWvkClwdThKOerVHgRzqMpbYsnPXA,ti,)
  fJWvkClwdThKOerVHgRzqMpbYsnPSE ='{"v":[0,1],"d":{"ty":"Browser","ac":"%s","ap":"%s","id":"%s","tr":"%s","ti":%s,"tk":"%s"}}'%(fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['NREUM']['ac'],fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['NREUM']['ap'],fJWvkClwdThKOerVHgRzqMpbYsnPXA,tr,ti,fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['NREUM']['tk'],) 
  return fJWvkClwdThKOerVHgRzqMpbYsnPSo,fJWvkClwdThKOerVHgRzqMpbYsnPSI,base64.standard_b64encode(fJWvkClwdThKOerVHgRzqMpbYsnPSE.encode()).decode('utf-8')
 def Init_CP(fJWvkClwdThKOerVHgRzqMpbYsnPSN):
  fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP={}
  fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['ACCOUNT']={'cpid':'','cppw':'','cppf':'0'}
  fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']={}
 def Save_session_acount(fJWvkClwdThKOerVHgRzqMpbYsnPSN,fJWvkClwdThKOerVHgRzqMpbYsnPSG,fJWvkClwdThKOerVHgRzqMpbYsnPSj,fJWvkClwdThKOerVHgRzqMpbYsnPmS):
  fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['ACCOUNT']['cpid']=base64.standard_b64encode(fJWvkClwdThKOerVHgRzqMpbYsnPSG.encode()).decode('utf-8')
  fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['ACCOUNT']['cppw']=base64.standard_b64encode(fJWvkClwdThKOerVHgRzqMpbYsnPSj.encode()).decode('utf-8')
  fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['ACCOUNT']['cppf']=fJWvkClwdThKOerVHgRzqMpbYsnPXQ(fJWvkClwdThKOerVHgRzqMpbYsnPmS)
 def Load_session_acount(fJWvkClwdThKOerVHgRzqMpbYsnPSN):
  fJWvkClwdThKOerVHgRzqMpbYsnPSG=base64.standard_b64decode(fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['ACCOUNT']['cpid']).decode('utf-8')
  fJWvkClwdThKOerVHgRzqMpbYsnPSj=base64.standard_b64decode(fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['ACCOUNT']['cppw']).decode('utf-8')
  fJWvkClwdThKOerVHgRzqMpbYsnPmS=fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['ACCOUNT']['cppf']
  return fJWvkClwdThKOerVHgRzqMpbYsnPSG,fJWvkClwdThKOerVHgRzqMpbYsnPSj,fJWvkClwdThKOerVHgRzqMpbYsnPmS
 def make_CP_DefaultCookies(fJWvkClwdThKOerVHgRzqMpbYsnPSN):
  fJWvkClwdThKOerVHgRzqMpbYsnPmN={}
  if 'NEXT_LOCALE' in fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']:fJWvkClwdThKOerVHgRzqMpbYsnPmN['NEXT_LOCALE']=fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['NEXT_LOCALE']
  if 'ak_bmsc' in fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']:fJWvkClwdThKOerVHgRzqMpbYsnPmN['ak_bmsc'] =fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['ak_bmsc']
  if 'bm_mi' in fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']:fJWvkClwdThKOerVHgRzqMpbYsnPmN['bm_mi'] =fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['bm_mi']
  if 'bm_sv' in fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']:fJWvkClwdThKOerVHgRzqMpbYsnPmN['bm_sv'] =fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['bm_sv']
  if 'PCID' in fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']:fJWvkClwdThKOerVHgRzqMpbYsnPmN['PCID'] =fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['PCID']
  if 'member_srl' in fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']:fJWvkClwdThKOerVHgRzqMpbYsnPmN['member_srl']=fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['member_srl']
  if 'token' in fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']:fJWvkClwdThKOerVHgRzqMpbYsnPmN['token'] =fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['token']
  return fJWvkClwdThKOerVHgRzqMpbYsnPmN
 def Get_CP_Login(fJWvkClwdThKOerVHgRzqMpbYsnPSN,userid,userpw,fJWvkClwdThKOerVHgRzqMpbYsnPmU):
  try:
   fJWvkClwdThKOerVHgRzqMpbYsnPmX=fJWvkClwdThKOerVHgRzqMpbYsnPSN.API_DOMAIN
   fJWvkClwdThKOerVHgRzqMpbYsnPmB=fJWvkClwdThKOerVHgRzqMpbYsnPSN.callRequestCookies('Get',fJWvkClwdThKOerVHgRzqMpbYsnPmX,payload=fJWvkClwdThKOerVHgRzqMpbYsnPXy,params=fJWvkClwdThKOerVHgRzqMpbYsnPXy,headers=fJWvkClwdThKOerVHgRzqMpbYsnPXy,cookies=fJWvkClwdThKOerVHgRzqMpbYsnPXy,redirects=fJWvkClwdThKOerVHgRzqMpbYsnPXt)
   if fJWvkClwdThKOerVHgRzqMpbYsnPmB.status_code not in[301,302]:return fJWvkClwdThKOerVHgRzqMpbYsnPXt
   for fJWvkClwdThKOerVHgRzqMpbYsnPmL in fJWvkClwdThKOerVHgRzqMpbYsnPmB.cookies:
    if fJWvkClwdThKOerVHgRzqMpbYsnPmL.name=='NEXT_LOCALE':
     fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['NEXT_LOCALE']=fJWvkClwdThKOerVHgRzqMpbYsnPmL.value
    elif fJWvkClwdThKOerVHgRzqMpbYsnPmL.name=='ak_bmsc':
     fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['ak_bmsc']=fJWvkClwdThKOerVHgRzqMpbYsnPmL.value
   fJWvkClwdThKOerVHgRzqMpbYsnPmN={'NEXT_LOCALE':fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['NEXT_LOCALE'],'ak_bmsc':fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['ak_bmsc'],}
   fJWvkClwdThKOerVHgRzqMpbYsnPmB=fJWvkClwdThKOerVHgRzqMpbYsnPSN.callRequestCookies('Get',fJWvkClwdThKOerVHgRzqMpbYsnPmX,payload=fJWvkClwdThKOerVHgRzqMpbYsnPXy,params=fJWvkClwdThKOerVHgRzqMpbYsnPXy,headers=fJWvkClwdThKOerVHgRzqMpbYsnPXy,cookies=fJWvkClwdThKOerVHgRzqMpbYsnPmN,redirects=fJWvkClwdThKOerVHgRzqMpbYsnPXt)
   if fJWvkClwdThKOerVHgRzqMpbYsnPmB.status_code not in[200]:return fJWvkClwdThKOerVHgRzqMpbYsnPXt
   fJWvkClwdThKOerVHgRzqMpbYsnPmu=re.findall('NREUM.loader_config=\{[\w\d\":,-]+\}',fJWvkClwdThKOerVHgRzqMpbYsnPmB.text)[0].split('=')[1]
   fJWvkClwdThKOerVHgRzqMpbYsnPmu=fJWvkClwdThKOerVHgRzqMpbYsnPmu.replace('{','{"').replace(':','":').replace(',',',"')
   fJWvkClwdThKOerVHgRzqMpbYsnPmu=json.loads(fJWvkClwdThKOerVHgRzqMpbYsnPmu)
   fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['NREUM']={'ac':fJWvkClwdThKOerVHgRzqMpbYsnPmu['accountID'],'tk':fJWvkClwdThKOerVHgRzqMpbYsnPmu['trustKey'],'ap':fJWvkClwdThKOerVHgRzqMpbYsnPmu['agentID'],'lk':fJWvkClwdThKOerVHgRzqMpbYsnPmu['licenseKey'],}
   for fJWvkClwdThKOerVHgRzqMpbYsnPmL in fJWvkClwdThKOerVHgRzqMpbYsnPmB.cookies:
    if fJWvkClwdThKOerVHgRzqMpbYsnPmL.name=='bm_mi':
     fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['bm_mi']=fJWvkClwdThKOerVHgRzqMpbYsnPmL.value
    elif fJWvkClwdThKOerVHgRzqMpbYsnPmL.name=='bm_sv':
     fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['bm_sv'] =fJWvkClwdThKOerVHgRzqMpbYsnPmL.value
     fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['bm_sv_ex']=fJWvkClwdThKOerVHgRzqMpbYsnPmL.expires 
  except fJWvkClwdThKOerVHgRzqMpbYsnPXF as exception:
   fJWvkClwdThKOerVHgRzqMpbYsnPXi(exception)
   return fJWvkClwdThKOerVHgRzqMpbYsnPXt
  try:
   fJWvkClwdThKOerVHgRzqMpbYsnPmX=fJWvkClwdThKOerVHgRzqMpbYsnPSN.API_DOMAIN+'/api/auth'
   fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['PCID']=fJWvkClwdThKOerVHgRzqMpbYsnPSN.generatePcId()
   fJWvkClwdThKOerVHgRzqMpbYsnPmc=fJWvkClwdThKOerVHgRzqMpbYsnPSN.Get_DeviceID()
   fJWvkClwdThKOerVHgRzqMpbYsnPmy =fJWvkClwdThKOerVHgRzqMpbYsnPmc.split('-')[0]
   fJWvkClwdThKOerVHgRzqMpbYsnPSo,fJWvkClwdThKOerVHgRzqMpbYsnPSI,fJWvkClwdThKOerVHgRzqMpbYsnPSE=fJWvkClwdThKOerVHgRzqMpbYsnPSN.Make_authHeader()
   fJWvkClwdThKOerVHgRzqMpbYsnPmt={'traceparent':fJWvkClwdThKOerVHgRzqMpbYsnPSo,'tracestate':fJWvkClwdThKOerVHgRzqMpbYsnPSI,'newrelic':fJWvkClwdThKOerVHgRzqMpbYsnPSE,'content-type':'application/json',}
   fJWvkClwdThKOerVHgRzqMpbYsnPmi={'device':{'deviceId':'web-'+fJWvkClwdThKOerVHgRzqMpbYsnPmc,'model':fJWvkClwdThKOerVHgRzqMpbYsnPSN.MODEL,'name':'Chrome Desktop '+fJWvkClwdThKOerVHgRzqMpbYsnPmy,'os':'Windows','osVersion':'10','type':'webclient',},'email':userid,'password':userpw,}
   fJWvkClwdThKOerVHgRzqMpbYsnPmi=json.dumps(fJWvkClwdThKOerVHgRzqMpbYsnPmi,separators=(',',':'))
   fJWvkClwdThKOerVHgRzqMpbYsnPmN={'NEXT_LOCALE':fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['NEXT_LOCALE'],'ak_bmsc':fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['ak_bmsc'],'bm_mi':fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['bm_mi'],'bm_sv':fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['bm_sv'],'PCID':fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['PCID'],}
   fJWvkClwdThKOerVHgRzqMpbYsnPmB=fJWvkClwdThKOerVHgRzqMpbYsnPSN.callRequestCookies('Post',fJWvkClwdThKOerVHgRzqMpbYsnPmX,payload=fJWvkClwdThKOerVHgRzqMpbYsnPmi,params=fJWvkClwdThKOerVHgRzqMpbYsnPXy,headers=fJWvkClwdThKOerVHgRzqMpbYsnPmt,cookies=fJWvkClwdThKOerVHgRzqMpbYsnPmN,redirects=fJWvkClwdThKOerVHgRzqMpbYsnPXt)
   if fJWvkClwdThKOerVHgRzqMpbYsnPmB.status_code not in[200]:
    fJWvkClwdThKOerVHgRzqMpbYsnPmQ=json.loads(fJWvkClwdThKOerVHgRzqMpbYsnPmB.text)
    if 'error' in fJWvkClwdThKOerVHgRzqMpbYsnPmQ:
     fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['error']=fJWvkClwdThKOerVHgRzqMpbYsnPmQ.get('error').get('detail')
    return fJWvkClwdThKOerVHgRzqMpbYsnPXt
   for fJWvkClwdThKOerVHgRzqMpbYsnPmL in fJWvkClwdThKOerVHgRzqMpbYsnPmB.cookies:
    if fJWvkClwdThKOerVHgRzqMpbYsnPmL.name=='token':
     fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['token']=fJWvkClwdThKOerVHgRzqMpbYsnPmL.value
    elif fJWvkClwdThKOerVHgRzqMpbYsnPmL.name=='member_srl':
     fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['member_srl']=fJWvkClwdThKOerVHgRzqMpbYsnPmL.value
    elif fJWvkClwdThKOerVHgRzqMpbYsnPmL.name=='bm_sv':
     fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['bm_sv'] =fJWvkClwdThKOerVHgRzqMpbYsnPmL.value
     fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['bm_sv_ex']=fJWvkClwdThKOerVHgRzqMpbYsnPmL.expires 
  except fJWvkClwdThKOerVHgRzqMpbYsnPXF as exception:
   fJWvkClwdThKOerVHgRzqMpbYsnPXi(exception)
   return fJWvkClwdThKOerVHgRzqMpbYsnPXt
  fJWvkClwdThKOerVHgRzqMpbYsnPSN.Save_session_acount(userid,userpw,fJWvkClwdThKOerVHgRzqMpbYsnPmU)
  return fJWvkClwdThKOerVHgRzqMpbYsnPXx
 def Get_CP_profile(fJWvkClwdThKOerVHgRzqMpbYsnPSN,fJWvkClwdThKOerVHgRzqMpbYsnPmU,limit_days=1,re_check=fJWvkClwdThKOerVHgRzqMpbYsnPXt):
  if re_check==fJWvkClwdThKOerVHgRzqMpbYsnPXx:
   if fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['bm_sv_ex']>fJWvkClwdThKOerVHgRzqMpbYsnPXU(time.time()):
    fJWvkClwdThKOerVHgRzqMpbYsnPXi('bm_sv_ex ok')
    return fJWvkClwdThKOerVHgRzqMpbYsnPXx
  try:
   fJWvkClwdThKOerVHgRzqMpbYsnPmX=fJWvkClwdThKOerVHgRzqMpbYsnPSN.API_DOMAIN+'/api/profiles'
   fJWvkClwdThKOerVHgRzqMpbYsnPSo,fJWvkClwdThKOerVHgRzqMpbYsnPSI,fJWvkClwdThKOerVHgRzqMpbYsnPSE=fJWvkClwdThKOerVHgRzqMpbYsnPSN.Make_authHeader()
   fJWvkClwdThKOerVHgRzqMpbYsnPmt={'traceparent':fJWvkClwdThKOerVHgRzqMpbYsnPSo,'tracestate':fJWvkClwdThKOerVHgRzqMpbYsnPSI,'newrelic':fJWvkClwdThKOerVHgRzqMpbYsnPSE,}
   fJWvkClwdThKOerVHgRzqMpbYsnPmN=fJWvkClwdThKOerVHgRzqMpbYsnPSN.make_CP_DefaultCookies()
   fJWvkClwdThKOerVHgRzqMpbYsnPmB=fJWvkClwdThKOerVHgRzqMpbYsnPSN.callRequestCookies('Get',fJWvkClwdThKOerVHgRzqMpbYsnPmX,payload=fJWvkClwdThKOerVHgRzqMpbYsnPXy,params=fJWvkClwdThKOerVHgRzqMpbYsnPXy,headers=fJWvkClwdThKOerVHgRzqMpbYsnPmt,cookies=fJWvkClwdThKOerVHgRzqMpbYsnPmN,redirects=fJWvkClwdThKOerVHgRzqMpbYsnPXt)
   if fJWvkClwdThKOerVHgRzqMpbYsnPmB.status_code not in[200]:return fJWvkClwdThKOerVHgRzqMpbYsnPXt
   fJWvkClwdThKOerVHgRzqMpbYsnPmQ=json.loads(fJWvkClwdThKOerVHgRzqMpbYsnPmB.text)
   fJWvkClwdThKOerVHgRzqMpbYsnPma=0 
   for fJWvkClwdThKOerVHgRzqMpbYsnPmL in fJWvkClwdThKOerVHgRzqMpbYsnPmB.cookies:
    fJWvkClwdThKOerVHgRzqMpbYsnPXi(fJWvkClwdThKOerVHgRzqMpbYsnPmL.name)
    if fJWvkClwdThKOerVHgRzqMpbYsnPmL.name=='bm_sv':
     fJWvkClwdThKOerVHgRzqMpbYsnPma=1
     fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['bm_sv'] =fJWvkClwdThKOerVHgRzqMpbYsnPmL.value
     fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['bm_sv_ex']=fJWvkClwdThKOerVHgRzqMpbYsnPmL.expires 
   if fJWvkClwdThKOerVHgRzqMpbYsnPma==0:
    fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['bm_sv_ex']=fJWvkClwdThKOerVHgRzqMpbYsnPXU(time.time())+60*60*2 
   fJWvkClwdThKOerVHgRzqMpbYsnPmU=fJWvkClwdThKOerVHgRzqMpbYsnPmQ.get('data')[fJWvkClwdThKOerVHgRzqMpbYsnPXU(fJWvkClwdThKOerVHgRzqMpbYsnPmU)]
   fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['accountId']=fJWvkClwdThKOerVHgRzqMpbYsnPmU.get('accountId')
   fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['profileId']=fJWvkClwdThKOerVHgRzqMpbYsnPmU.get('profileId')
  except fJWvkClwdThKOerVHgRzqMpbYsnPXF as exception:
   fJWvkClwdThKOerVHgRzqMpbYsnPXi(exception)
   return fJWvkClwdThKOerVHgRzqMpbYsnPXt
  if re_check==fJWvkClwdThKOerVHgRzqMpbYsnPXt:
   fJWvkClwdThKOerVHgRzqMpbYsnPmF =fJWvkClwdThKOerVHgRzqMpbYsnPSN.Get_Now_Datetime()
   fJWvkClwdThKOerVHgRzqMpbYsnPmA=fJWvkClwdThKOerVHgRzqMpbYsnPmF+datetime.timedelta(days=limit_days)
   fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['limitdate']=fJWvkClwdThKOerVHgRzqMpbYsnPmA.strftime('%Y-%m-%d')
  else:
   fJWvkClwdThKOerVHgRzqMpbYsnPXi('re check')
  fJWvkClwdThKOerVHgRzqMpbYsnPSN.dic_To_jsonfile(fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP_COOKIE_FILENAME,fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP)
  return fJWvkClwdThKOerVHgRzqMpbYsnPXx
 def Get_Category_GroupList(fJWvkClwdThKOerVHgRzqMpbYsnPSN,vType):
  fJWvkClwdThKOerVHgRzqMpbYsnPmx=[] 
  try:
   fJWvkClwdThKOerVHgRzqMpbYsnPmX=fJWvkClwdThKOerVHgRzqMpbYsnPSN.API_VIEWURL+'/v2/discover/feed' 
   fJWvkClwdThKOerVHgRzqMpbYsnPmD={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false',}
   fJWvkClwdThKOerVHgRzqMpbYsnPmB=fJWvkClwdThKOerVHgRzqMpbYsnPSN.callRequestCookies('Get',fJWvkClwdThKOerVHgRzqMpbYsnPmX,payload=fJWvkClwdThKOerVHgRzqMpbYsnPXy,params=fJWvkClwdThKOerVHgRzqMpbYsnPmD,headers=fJWvkClwdThKOerVHgRzqMpbYsnPXy,cookies=fJWvkClwdThKOerVHgRzqMpbYsnPXy,redirects=fJWvkClwdThKOerVHgRzqMpbYsnPXx)
   if fJWvkClwdThKOerVHgRzqMpbYsnPmB.status_code not in[200]:return[]
   fJWvkClwdThKOerVHgRzqMpbYsnPmQ=json.loads(fJWvkClwdThKOerVHgRzqMpbYsnPmB.text)
   if vType in['TVSHOWS','MOVIES']:
    fJWvkClwdThKOerVHgRzqMpbYsnPmo='Explores' 
   elif vType in['EDUCATION']:
    fJWvkClwdThKOerVHgRzqMpbYsnPmo='Collection-Rails-Curation'
   elif vType in['ALL']:
    fJWvkClwdThKOerVHgRzqMpbYsnPmo='Explores-Categories'
   for fJWvkClwdThKOerVHgRzqMpbYsnPmI in fJWvkClwdThKOerVHgRzqMpbYsnPmQ.get('data'):
    if fJWvkClwdThKOerVHgRzqMpbYsnPmI.get('type')==fJWvkClwdThKOerVHgRzqMpbYsnPmo:
     for fJWvkClwdThKOerVHgRzqMpbYsnPmE in fJWvkClwdThKOerVHgRzqMpbYsnPmI.get('data'):
      if vType in['TVSHOWS','MOVIES']:
       fJWvkClwdThKOerVHgRzqMpbYsnPmG=fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('collectionId')
      elif vType in['EDUCATION','ALL']:
       fJWvkClwdThKOerVHgRzqMpbYsnPmG=fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('id')
      fJWvkClwdThKOerVHgRzqMpbYsnPmj={'collectionId':fJWvkClwdThKOerVHgRzqMpbYsnPmG,'title':fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('name'),'category':fJWvkClwdThKOerVHgRzqMpbYsnPmI.get('category'),'pre_title':'',}
      fJWvkClwdThKOerVHgRzqMpbYsnPmx.append(fJWvkClwdThKOerVHgRzqMpbYsnPmj)
     break
  except fJWvkClwdThKOerVHgRzqMpbYsnPXF as exception:
   fJWvkClwdThKOerVHgRzqMpbYsnPXi(exception)
   return[]
  return fJWvkClwdThKOerVHgRzqMpbYsnPmx
 def Get_Category_List(fJWvkClwdThKOerVHgRzqMpbYsnPSN,vType,fJWvkClwdThKOerVHgRzqMpbYsnPmG,page_int):
  fJWvkClwdThKOerVHgRzqMpbYsnPmx=[] 
  fJWvkClwdThKOerVHgRzqMpbYsnPNS=fJWvkClwdThKOerVHgRzqMpbYsnPXt
  try:
   if vType=='ALL':
    fJWvkClwdThKOerVHgRzqMpbYsnPmt={'x-membersrl':fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['member_srl'],'x-pcid':fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['PCID'],'x-profileid':fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['profileId'],}
    fJWvkClwdThKOerVHgRzqMpbYsnPmD={'platform':'WEBCLIENT','page':fJWvkClwdThKOerVHgRzqMpbYsnPXQ(page_int),'perPage':fJWvkClwdThKOerVHgRzqMpbYsnPXQ(fJWvkClwdThKOerVHgRzqMpbYsnPSN.PAGE_LIMIT),'locale':'ko','sort':'',}
    fJWvkClwdThKOerVHgRzqMpbYsnPmX=fJWvkClwdThKOerVHgRzqMpbYsnPSN.API_VIEWURL+'/v1/discover/categories/'+fJWvkClwdThKOerVHgRzqMpbYsnPmG+'/titles'
    fJWvkClwdThKOerVHgRzqMpbYsnPmB=fJWvkClwdThKOerVHgRzqMpbYsnPSN.callRequestCookies('Get',fJWvkClwdThKOerVHgRzqMpbYsnPmX,payload=fJWvkClwdThKOerVHgRzqMpbYsnPXy,params=fJWvkClwdThKOerVHgRzqMpbYsnPmD,headers=fJWvkClwdThKOerVHgRzqMpbYsnPmt,cookies=fJWvkClwdThKOerVHgRzqMpbYsnPXy,redirects=fJWvkClwdThKOerVHgRzqMpbYsnPXx)
   else: 
    fJWvkClwdThKOerVHgRzqMpbYsnPmD={'platform':'WEBCLIENT','page':fJWvkClwdThKOerVHgRzqMpbYsnPXQ(page_int),'perPage':fJWvkClwdThKOerVHgRzqMpbYsnPXQ(fJWvkClwdThKOerVHgRzqMpbYsnPSN.PAGE_LIMIT),}
    fJWvkClwdThKOerVHgRzqMpbYsnPmX=fJWvkClwdThKOerVHgRzqMpbYsnPSN.API_VIEWURL+'/v1/discover/collections/'+fJWvkClwdThKOerVHgRzqMpbYsnPmG+'/titles'
    fJWvkClwdThKOerVHgRzqMpbYsnPmB=fJWvkClwdThKOerVHgRzqMpbYsnPSN.callRequestCookies('Get',fJWvkClwdThKOerVHgRzqMpbYsnPmX,payload=fJWvkClwdThKOerVHgRzqMpbYsnPXy,params=fJWvkClwdThKOerVHgRzqMpbYsnPmD,headers=fJWvkClwdThKOerVHgRzqMpbYsnPXy,cookies=fJWvkClwdThKOerVHgRzqMpbYsnPXy,redirects=fJWvkClwdThKOerVHgRzqMpbYsnPXx)
   if fJWvkClwdThKOerVHgRzqMpbYsnPmB.status_code not in[200]:return[],fJWvkClwdThKOerVHgRzqMpbYsnPXt
   fJWvkClwdThKOerVHgRzqMpbYsnPmQ=json.loads(fJWvkClwdThKOerVHgRzqMpbYsnPmB.text)
   if vType=='ALL':
    fJWvkClwdThKOerVHgRzqMpbYsnPNm=fJWvkClwdThKOerVHgRzqMpbYsnPmQ.get('data').get('data')
   else:
    fJWvkClwdThKOerVHgRzqMpbYsnPNm=fJWvkClwdThKOerVHgRzqMpbYsnPmQ.get('data')
   for fJWvkClwdThKOerVHgRzqMpbYsnPmE in fJWvkClwdThKOerVHgRzqMpbYsnPNm:
    fJWvkClwdThKOerVHgRzqMpbYsnPNX=fJWvkClwdThKOerVHgRzqMpbYsnPNy=fJWvkClwdThKOerVHgRzqMpbYsnPXN=fJWvkClwdThKOerVHgRzqMpbYsnPXm=''
    if 'poster' in fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('images'):fJWvkClwdThKOerVHgRzqMpbYsnPNX =fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('images').get('poster').get('url')
    if 'story-art' in fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('images'):fJWvkClwdThKOerVHgRzqMpbYsnPNy =fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('images').get('story-art').get('url')
    if 'title-treatment' in fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('images'):fJWvkClwdThKOerVHgRzqMpbYsnPXN=fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('images').get('title-treatment').get('url')
    if 'story-art' in fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('images'):fJWvkClwdThKOerVHgRzqMpbYsnPXm =fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('images').get('story-art').get('url')
    fJWvkClwdThKOerVHgRzqMpbYsnPNB=''
    if fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('badge')not in[{},fJWvkClwdThKOerVHgRzqMpbYsnPXy]:
     for i in fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('badge').get('text'):
      fJWvkClwdThKOerVHgRzqMpbYsnPNB+=i.get('text')
    fJWvkClwdThKOerVHgRzqMpbYsnPNL=''
    if fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('seasonList')!=fJWvkClwdThKOerVHgRzqMpbYsnPXy:
     fJWvkClwdThKOerVHgRzqMpbYsnPNL=','.join(fJWvkClwdThKOerVHgRzqMpbYsnPXQ(e)for e in fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('seasonList'))
    fJWvkClwdThKOerVHgRzqMpbYsnPNu =[]
    for fJWvkClwdThKOerVHgRzqMpbYsnPNc in fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('tags'):
     fJWvkClwdThKOerVHgRzqMpbYsnPNu.append(fJWvkClwdThKOerVHgRzqMpbYsnPNc.get('tag'))
    fJWvkClwdThKOerVHgRzqMpbYsnPmj={'id':fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('id'),'title':fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('title'),'thumbnail':{'poster':fJWvkClwdThKOerVHgRzqMpbYsnPNX,'thumb':fJWvkClwdThKOerVHgRzqMpbYsnPNy,'clearlogo':fJWvkClwdThKOerVHgRzqMpbYsnPXN,'fanart':fJWvkClwdThKOerVHgRzqMpbYsnPXm},'mpaa':fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('age_rating'),'duration':fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('running_time'),'asis':fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('as'),'badge':fJWvkClwdThKOerVHgRzqMpbYsnPNB,'year':fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('meta').get('releaseYear'),'seasonList':fJWvkClwdThKOerVHgRzqMpbYsnPNL,'genreList':fJWvkClwdThKOerVHgRzqMpbYsnPNu,}
    fJWvkClwdThKOerVHgRzqMpbYsnPmx.append(fJWvkClwdThKOerVHgRzqMpbYsnPmj)
   if fJWvkClwdThKOerVHgRzqMpbYsnPmQ.get('pagination').get('totalPages')>page_int:
    fJWvkClwdThKOerVHgRzqMpbYsnPNS=fJWvkClwdThKOerVHgRzqMpbYsnPXx
  except fJWvkClwdThKOerVHgRzqMpbYsnPXF as exception:
   fJWvkClwdThKOerVHgRzqMpbYsnPXi(exception)
   return[],fJWvkClwdThKOerVHgRzqMpbYsnPXt
  return fJWvkClwdThKOerVHgRzqMpbYsnPmx,fJWvkClwdThKOerVHgRzqMpbYsnPNS
 def Get_Episode_List(fJWvkClwdThKOerVHgRzqMpbYsnPSN,programId,season):
  fJWvkClwdThKOerVHgRzqMpbYsnPmx=[] 
  try:
   fJWvkClwdThKOerVHgRzqMpbYsnPmX=fJWvkClwdThKOerVHgRzqMpbYsnPSN.API_VIEWURL+'/v1/discover/titles/'+programId+'/episodes'
   fJWvkClwdThKOerVHgRzqMpbYsnPmD={'season':season,'sort':'true','locale':'ko',}
   fJWvkClwdThKOerVHgRzqMpbYsnPmB=fJWvkClwdThKOerVHgRzqMpbYsnPSN.callRequestCookies('Get',fJWvkClwdThKOerVHgRzqMpbYsnPmX,payload=fJWvkClwdThKOerVHgRzqMpbYsnPXy,params=fJWvkClwdThKOerVHgRzqMpbYsnPmD,headers=fJWvkClwdThKOerVHgRzqMpbYsnPXy,cookies=fJWvkClwdThKOerVHgRzqMpbYsnPXy,redirects=fJWvkClwdThKOerVHgRzqMpbYsnPXx)
   if fJWvkClwdThKOerVHgRzqMpbYsnPmB.status_code not in[200]:return[]
   fJWvkClwdThKOerVHgRzqMpbYsnPmQ=json.loads(fJWvkClwdThKOerVHgRzqMpbYsnPmB.text)
   for fJWvkClwdThKOerVHgRzqMpbYsnPmE in fJWvkClwdThKOerVHgRzqMpbYsnPmQ.get('data'):
    fJWvkClwdThKOerVHgRzqMpbYsnPNy=''
    if 'story-art' in fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('images'):fJWvkClwdThKOerVHgRzqMpbYsnPNy =fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('images').get('story-art').get('url')
    fJWvkClwdThKOerVHgRzqMpbYsnPNu =[]
    for fJWvkClwdThKOerVHgRzqMpbYsnPNc in fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('tags'):
     fJWvkClwdThKOerVHgRzqMpbYsnPNu.append(fJWvkClwdThKOerVHgRzqMpbYsnPNc.get('tag'))
    fJWvkClwdThKOerVHgRzqMpbYsnPmj={'id':fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('id'),'title':fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('title'),'thumbnail':{'thumb':fJWvkClwdThKOerVHgRzqMpbYsnPNy,'fanart':fJWvkClwdThKOerVHgRzqMpbYsnPNy},'mpaa':fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('age_rating'),'duration':fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('running_time'),'asis':fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('as'),'year':fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('meta').get('releaseYear'),'episode':fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('episode'),'genreList':fJWvkClwdThKOerVHgRzqMpbYsnPNu,'desc':fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('description'),}
    fJWvkClwdThKOerVHgRzqMpbYsnPmx.append(fJWvkClwdThKOerVHgRzqMpbYsnPmj)
  except fJWvkClwdThKOerVHgRzqMpbYsnPXF as exception:
   fJWvkClwdThKOerVHgRzqMpbYsnPXi(exception)
   return[]
  return fJWvkClwdThKOerVHgRzqMpbYsnPmx
 def Get_vInfo(fJWvkClwdThKOerVHgRzqMpbYsnPSN,titleId):
  try:
   fJWvkClwdThKOerVHgRzqMpbYsnPmX=fJWvkClwdThKOerVHgRzqMpbYsnPSN.API_VIEWURL+'/v1/discover/titles/'+titleId 
   fJWvkClwdThKOerVHgRzqMpbYsnPmD={'locale':'ko'}
   fJWvkClwdThKOerVHgRzqMpbYsnPmB=fJWvkClwdThKOerVHgRzqMpbYsnPSN.callRequestCookies('Get',fJWvkClwdThKOerVHgRzqMpbYsnPmX,payload=fJWvkClwdThKOerVHgRzqMpbYsnPXy,params=fJWvkClwdThKOerVHgRzqMpbYsnPmD,headers=fJWvkClwdThKOerVHgRzqMpbYsnPXy,cookies=fJWvkClwdThKOerVHgRzqMpbYsnPXy,redirects=fJWvkClwdThKOerVHgRzqMpbYsnPXx)
   if fJWvkClwdThKOerVHgRzqMpbYsnPmB.status_code not in[200]:return '','',''
   fJWvkClwdThKOerVHgRzqMpbYsnPmQ=json.loads(fJWvkClwdThKOerVHgRzqMpbYsnPmB.text).get('data')
   fJWvkClwdThKOerVHgRzqMpbYsnPNL=''
   if fJWvkClwdThKOerVHgRzqMpbYsnPmQ.get('seasonList')!=fJWvkClwdThKOerVHgRzqMpbYsnPXy:
    fJWvkClwdThKOerVHgRzqMpbYsnPNL=','.join(fJWvkClwdThKOerVHgRzqMpbYsnPXQ(e)for e in fJWvkClwdThKOerVHgRzqMpbYsnPmQ.get('seasonList'))
   fJWvkClwdThKOerVHgRzqMpbYsnPNt={'age_rating':fJWvkClwdThKOerVHgRzqMpbYsnPmQ.get('age_rating'),'asset_id':fJWvkClwdThKOerVHgRzqMpbYsnPmQ.get('asset_id'),'availability':fJWvkClwdThKOerVHgRzqMpbYsnPmQ.get('availability'),'deal_id':fJWvkClwdThKOerVHgRzqMpbYsnPmQ.get('deal_id'),'downloadable':'true' if fJWvkClwdThKOerVHgRzqMpbYsnPmQ.get('downloadable')else 'false','region':fJWvkClwdThKOerVHgRzqMpbYsnPmQ.get('region'),'streamable':'true' if fJWvkClwdThKOerVHgRzqMpbYsnPmQ.get('streamable')else 'false','asis':fJWvkClwdThKOerVHgRzqMpbYsnPmQ.get('as'),'seasonList':fJWvkClwdThKOerVHgRzqMpbYsnPNL}
  except fJWvkClwdThKOerVHgRzqMpbYsnPXF as exception:
   fJWvkClwdThKOerVHgRzqMpbYsnPXi(exception)
   return{}
  return fJWvkClwdThKOerVHgRzqMpbYsnPNt
 def Get_eInfo(fJWvkClwdThKOerVHgRzqMpbYsnPSN,eventId):
  try:
   fJWvkClwdThKOerVHgRzqMpbYsnPmX=fJWvkClwdThKOerVHgRzqMpbYsnPSN.API_VIEWURL+'/v1/discover/events/'+eventId 
   fJWvkClwdThKOerVHgRzqMpbYsnPmD={'locale':'ko'}
   fJWvkClwdThKOerVHgRzqMpbYsnPmB=fJWvkClwdThKOerVHgRzqMpbYsnPSN.callRequestCookies('Get',fJWvkClwdThKOerVHgRzqMpbYsnPmX,payload=fJWvkClwdThKOerVHgRzqMpbYsnPXy,params=fJWvkClwdThKOerVHgRzqMpbYsnPmD,headers=fJWvkClwdThKOerVHgRzqMpbYsnPXy,cookies=fJWvkClwdThKOerVHgRzqMpbYsnPXy,redirects=fJWvkClwdThKOerVHgRzqMpbYsnPXx)
   if fJWvkClwdThKOerVHgRzqMpbYsnPmB.status_code not in[200]:return '','',''
   fJWvkClwdThKOerVHgRzqMpbYsnPmQ=json.loads(fJWvkClwdThKOerVHgRzqMpbYsnPmB.text).get('data')
   fJWvkClwdThKOerVHgRzqMpbYsnPNt={'asset_id':fJWvkClwdThKOerVHgRzqMpbYsnPmQ.get('asset_id'),'deal_id':fJWvkClwdThKOerVHgRzqMpbYsnPmQ.get('deal_id'),'region':fJWvkClwdThKOerVHgRzqMpbYsnPmQ.get('region'),'streamable':'true' if fJWvkClwdThKOerVHgRzqMpbYsnPmQ.get('streamable')else 'false',}
  except fJWvkClwdThKOerVHgRzqMpbYsnPXF as exception:
   fJWvkClwdThKOerVHgRzqMpbYsnPXi(exception)
   return{}
  return fJWvkClwdThKOerVHgRzqMpbYsnPNt
 def GetBroadURL(fJWvkClwdThKOerVHgRzqMpbYsnPSN,titleId):
  fJWvkClwdThKOerVHgRzqMpbYsnPNi=''
  fJWvkClwdThKOerVHgRzqMpbYsnPNQ =''
  fJWvkClwdThKOerVHgRzqMpbYsnPNt=fJWvkClwdThKOerVHgRzqMpbYsnPSN.Get_vInfo(titleId)
  if fJWvkClwdThKOerVHgRzqMpbYsnPNt=={}:return '',''
  try:
   fJWvkClwdThKOerVHgRzqMpbYsnPmX=fJWvkClwdThKOerVHgRzqMpbYsnPSN.API_DOMAIN+'/api/playback/play' 
   fJWvkClwdThKOerVHgRzqMpbYsnPmD={'titleId':titleId}
   fJWvkClwdThKOerVHgRzqMpbYsnPSo,fJWvkClwdThKOerVHgRzqMpbYsnPSI,fJWvkClwdThKOerVHgRzqMpbYsnPSE=fJWvkClwdThKOerVHgRzqMpbYsnPSN.Make_authHeader()
   fJWvkClwdThKOerVHgRzqMpbYsnPmt={'traceparent':fJWvkClwdThKOerVHgRzqMpbYsnPSo,'tracestate':fJWvkClwdThKOerVHgRzqMpbYsnPSI,'newrelic':fJWvkClwdThKOerVHgRzqMpbYsnPSE,'x-force-raw':'true','x-pcid':fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':fJWvkClwdThKOerVHgRzqMpbYsnPNt.get('age_rating'),'x-title-availability':fJWvkClwdThKOerVHgRzqMpbYsnPNt.get('availability'),'x-title-brightcove-id':fJWvkClwdThKOerVHgRzqMpbYsnPNt.get('asset_id'),'x-title-deal-id':fJWvkClwdThKOerVHgRzqMpbYsnPNt.get('deal_id'),'x-title-downloadable':fJWvkClwdThKOerVHgRzqMpbYsnPNt.get('downloadable'),'x-title-region':fJWvkClwdThKOerVHgRzqMpbYsnPNt.get('region'),'x-title-streamable':fJWvkClwdThKOerVHgRzqMpbYsnPNt.get('streamable'),}
   fJWvkClwdThKOerVHgRzqMpbYsnPmN=fJWvkClwdThKOerVHgRzqMpbYsnPSN.make_CP_DefaultCookies()
   fJWvkClwdThKOerVHgRzqMpbYsnPmB=fJWvkClwdThKOerVHgRzqMpbYsnPSN.callRequestCookies('Get',fJWvkClwdThKOerVHgRzqMpbYsnPmX,payload=fJWvkClwdThKOerVHgRzqMpbYsnPXy,params=fJWvkClwdThKOerVHgRzqMpbYsnPmD,headers=fJWvkClwdThKOerVHgRzqMpbYsnPmt,cookies=fJWvkClwdThKOerVHgRzqMpbYsnPmN,redirects=fJWvkClwdThKOerVHgRzqMpbYsnPXx)
   if fJWvkClwdThKOerVHgRzqMpbYsnPmB.status_code not in[200]:return '',json.loads(fJWvkClwdThKOerVHgRzqMpbYsnPmB.text).get('error').get('detail')
   fJWvkClwdThKOerVHgRzqMpbYsnPmQ=json.loads(fJWvkClwdThKOerVHgRzqMpbYsnPmB.text)
   for fJWvkClwdThKOerVHgRzqMpbYsnPmE in fJWvkClwdThKOerVHgRzqMpbYsnPmQ.get('data').get('raw').get('sources'):
    if fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('type')=='application/dash+xml' and fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('src')[0:8]=='https://':
     fJWvkClwdThKOerVHgRzqMpbYsnPNi=fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('src')
     if 'key_systems' in fJWvkClwdThKOerVHgRzqMpbYsnPmE:
      fJWvkClwdThKOerVHgRzqMpbYsnPNQ =fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('key_systems').get('com.widevine.alpha').get('license_url')
     break
  except fJWvkClwdThKOerVHgRzqMpbYsnPXF as exception:
   fJWvkClwdThKOerVHgRzqMpbYsnPXi(exception)
   return '',''
  return fJWvkClwdThKOerVHgRzqMpbYsnPNi,fJWvkClwdThKOerVHgRzqMpbYsnPNQ
 def GetEventURL(fJWvkClwdThKOerVHgRzqMpbYsnPSN,eventId,fJWvkClwdThKOerVHgRzqMpbYsnPNI):
  fJWvkClwdThKOerVHgRzqMpbYsnPNi=''
  fJWvkClwdThKOerVHgRzqMpbYsnPNQ =''
  fJWvkClwdThKOerVHgRzqMpbYsnPNt=fJWvkClwdThKOerVHgRzqMpbYsnPSN.Get_eInfo(eventId)
  if fJWvkClwdThKOerVHgRzqMpbYsnPNt=={}:return '',''
  try:
   fJWvkClwdThKOerVHgRzqMpbYsnPmX=fJWvkClwdThKOerVHgRzqMpbYsnPSN.API_DOMAIN+'/api/playback/play' 
   fJWvkClwdThKOerVHgRzqMpbYsnPmD={'titleId':eventId,'titleType':fJWvkClwdThKOerVHgRzqMpbYsnPNI,}
   fJWvkClwdThKOerVHgRzqMpbYsnPSo,fJWvkClwdThKOerVHgRzqMpbYsnPSI,fJWvkClwdThKOerVHgRzqMpbYsnPSE=fJWvkClwdThKOerVHgRzqMpbYsnPSN.Make_authHeader()
   fJWvkClwdThKOerVHgRzqMpbYsnPmt={'traceparent':fJWvkClwdThKOerVHgRzqMpbYsnPSo,'tracestate':fJWvkClwdThKOerVHgRzqMpbYsnPSI,'newrelic':fJWvkClwdThKOerVHgRzqMpbYsnPSE,'x-force-raw':'true','x-pcid':fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':fJWvkClwdThKOerVHgRzqMpbYsnPNt.get('asset_id'),'x-title-deal-id':fJWvkClwdThKOerVHgRzqMpbYsnPNt.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':fJWvkClwdThKOerVHgRzqMpbYsnPNt.get('region'),'x-title-streamable':fJWvkClwdThKOerVHgRzqMpbYsnPNt.get('streamable'),}
   fJWvkClwdThKOerVHgRzqMpbYsnPmN=fJWvkClwdThKOerVHgRzqMpbYsnPSN.make_CP_DefaultCookies()
   fJWvkClwdThKOerVHgRzqMpbYsnPmB=fJWvkClwdThKOerVHgRzqMpbYsnPSN.callRequestCookies('Get',fJWvkClwdThKOerVHgRzqMpbYsnPmX,payload=fJWvkClwdThKOerVHgRzqMpbYsnPXy,params=fJWvkClwdThKOerVHgRzqMpbYsnPmD,headers=fJWvkClwdThKOerVHgRzqMpbYsnPmt,cookies=fJWvkClwdThKOerVHgRzqMpbYsnPmN,redirects=fJWvkClwdThKOerVHgRzqMpbYsnPXx)
   if fJWvkClwdThKOerVHgRzqMpbYsnPmB.status_code not in[200]:return '',json.loads(fJWvkClwdThKOerVHgRzqMpbYsnPmB.text).get('error').get('detail')
   fJWvkClwdThKOerVHgRzqMpbYsnPmQ=json.loads(fJWvkClwdThKOerVHgRzqMpbYsnPmB.text)
   for fJWvkClwdThKOerVHgRzqMpbYsnPmE in fJWvkClwdThKOerVHgRzqMpbYsnPmQ.get('data').get('raw').get('sources'):
    if fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('type')=='application/dash+xml' and fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('src')[0:8]=='https://':
     fJWvkClwdThKOerVHgRzqMpbYsnPNi=fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('src')
     if 'key_systems' in fJWvkClwdThKOerVHgRzqMpbYsnPmE:
      fJWvkClwdThKOerVHgRzqMpbYsnPNQ =fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('key_systems').get('com.widevine.alpha').get('license_url')
     break
  except fJWvkClwdThKOerVHgRzqMpbYsnPXF as exception:
   fJWvkClwdThKOerVHgRzqMpbYsnPXi(exception)
   return '',''
  return fJWvkClwdThKOerVHgRzqMpbYsnPNi,fJWvkClwdThKOerVHgRzqMpbYsnPNQ
 def GetEventURL_Live(fJWvkClwdThKOerVHgRzqMpbYsnPSN,eventId,fJWvkClwdThKOerVHgRzqMpbYsnPNI):
  fJWvkClwdThKOerVHgRzqMpbYsnPNi=''
  fJWvkClwdThKOerVHgRzqMpbYsnPNQ =''
  fJWvkClwdThKOerVHgRzqMpbYsnPNt=fJWvkClwdThKOerVHgRzqMpbYsnPSN.Get_eInfo(eventId)
  if fJWvkClwdThKOerVHgRzqMpbYsnPNt=={}:return '',''
  try:
   fJWvkClwdThKOerVHgRzqMpbYsnPmX=fJWvkClwdThKOerVHgRzqMpbYsnPSN.API_DOMAIN+'/api/playback/play' 
   fJWvkClwdThKOerVHgRzqMpbYsnPmD={'titleId':eventId,'titleType':fJWvkClwdThKOerVHgRzqMpbYsnPNI,}
   fJWvkClwdThKOerVHgRzqMpbYsnPSo,fJWvkClwdThKOerVHgRzqMpbYsnPSI,fJWvkClwdThKOerVHgRzqMpbYsnPSE=fJWvkClwdThKOerVHgRzqMpbYsnPSN.Make_authHeader()
   fJWvkClwdThKOerVHgRzqMpbYsnPmt={'traceparent':fJWvkClwdThKOerVHgRzqMpbYsnPSo,'tracestate':fJWvkClwdThKOerVHgRzqMpbYsnPSI,'newrelic':fJWvkClwdThKOerVHgRzqMpbYsnPSE,'x-force-raw':'true','x-pcid':fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':fJWvkClwdThKOerVHgRzqMpbYsnPNt.get('asset_id'),'x-title-deal-id':fJWvkClwdThKOerVHgRzqMpbYsnPNt.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':fJWvkClwdThKOerVHgRzqMpbYsnPNt.get('region'),'x-title-streamable':fJWvkClwdThKOerVHgRzqMpbYsnPNt.get('streamable'),}
   fJWvkClwdThKOerVHgRzqMpbYsnPmN=fJWvkClwdThKOerVHgRzqMpbYsnPSN.make_CP_DefaultCookies()
   fJWvkClwdThKOerVHgRzqMpbYsnPmB=fJWvkClwdThKOerVHgRzqMpbYsnPSN.callRequestCookies('Get',fJWvkClwdThKOerVHgRzqMpbYsnPmX,payload=fJWvkClwdThKOerVHgRzqMpbYsnPXy,params=fJWvkClwdThKOerVHgRzqMpbYsnPmD,headers=fJWvkClwdThKOerVHgRzqMpbYsnPmt,cookies=fJWvkClwdThKOerVHgRzqMpbYsnPmN,redirects=fJWvkClwdThKOerVHgRzqMpbYsnPXx)
   if fJWvkClwdThKOerVHgRzqMpbYsnPmB.status_code not in[200]:return '',json.loads(fJWvkClwdThKOerVHgRzqMpbYsnPmB.text).get('error').get('detail')
   fJWvkClwdThKOerVHgRzqMpbYsnPmQ=json.loads(fJWvkClwdThKOerVHgRzqMpbYsnPmB.text)
   for fJWvkClwdThKOerVHgRzqMpbYsnPmE in fJWvkClwdThKOerVHgRzqMpbYsnPmQ.get('data').get('raw').get('sources'):
    if fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('type')=='application/dash+xml' and 'com.widevine.alpha' in fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('key_systems')and fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('src')[0:8]=='https://':
     fJWvkClwdThKOerVHgRzqMpbYsnPNi=fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('src')
     fJWvkClwdThKOerVHgRzqMpbYsnPNQ =fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('key_systems').get('com.widevine.alpha').get('license_url')
  except fJWvkClwdThKOerVHgRzqMpbYsnPXF as exception:
   fJWvkClwdThKOerVHgRzqMpbYsnPXi(exception)
   return '',''
  return fJWvkClwdThKOerVHgRzqMpbYsnPNi,fJWvkClwdThKOerVHgRzqMpbYsnPNQ
 def Get_Theme_GroupList(fJWvkClwdThKOerVHgRzqMpbYsnPSN,vType):
  fJWvkClwdThKOerVHgRzqMpbYsnPmx=[] 
  try:
   fJWvkClwdThKOerVHgRzqMpbYsnPmX=fJWvkClwdThKOerVHgRzqMpbYsnPSN.API_VIEWURL+'/v2/discover/feed' 
   fJWvkClwdThKOerVHgRzqMpbYsnPmD={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':fJWvkClwdThKOerVHgRzqMpbYsnPXQ(fJWvkClwdThKOerVHgRzqMpbYsnPSN.PAGE_LIMIT),'filterRestrictedContent':'false',}
   fJWvkClwdThKOerVHgRzqMpbYsnPmB=fJWvkClwdThKOerVHgRzqMpbYsnPSN.callRequestCookies('Get',fJWvkClwdThKOerVHgRzqMpbYsnPmX,payload=fJWvkClwdThKOerVHgRzqMpbYsnPXy,params=fJWvkClwdThKOerVHgRzqMpbYsnPmD,headers=fJWvkClwdThKOerVHgRzqMpbYsnPXy,cookies=fJWvkClwdThKOerVHgRzqMpbYsnPXy,redirects=fJWvkClwdThKOerVHgRzqMpbYsnPXx)
   if fJWvkClwdThKOerVHgRzqMpbYsnPmB.status_code not in[200]:return[]
   fJWvkClwdThKOerVHgRzqMpbYsnPmQ=json.loads(fJWvkClwdThKOerVHgRzqMpbYsnPmB.text)
   for fJWvkClwdThKOerVHgRzqMpbYsnPmE in fJWvkClwdThKOerVHgRzqMpbYsnPmQ.get('data'):
    if fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('type')=='Title-Rails-Curation':
     fJWvkClwdThKOerVHgRzqMpbYsnPNa =''
     fJWvkClwdThKOerVHgRzqMpbYsnPNU=7
     try:
      for i in fJWvkClwdThKOerVHgRzqMpbYsnPXD(fJWvkClwdThKOerVHgRzqMpbYsnPXo(fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('data'))):
       if i>=fJWvkClwdThKOerVHgRzqMpbYsnPNU:
        fJWvkClwdThKOerVHgRzqMpbYsnPNa=fJWvkClwdThKOerVHgRzqMpbYsnPNa+'...'
        break
       fJWvkClwdThKOerVHgRzqMpbYsnPNa=fJWvkClwdThKOerVHgRzqMpbYsnPNa+fJWvkClwdThKOerVHgRzqMpbYsnPmE['data'][i]['title']+'\n'
     except fJWvkClwdThKOerVHgRzqMpbYsnPXF as exception:
      fJWvkClwdThKOerVHgRzqMpbYsnPXi(exception)
     fJWvkClwdThKOerVHgRzqMpbYsnPmj={'collectionId':fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('obj_id'),'title':fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('row_name'),'category':fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('category'),'pre_title':fJWvkClwdThKOerVHgRzqMpbYsnPNa,}
     fJWvkClwdThKOerVHgRzqMpbYsnPmx.append(fJWvkClwdThKOerVHgRzqMpbYsnPmj)
  except fJWvkClwdThKOerVHgRzqMpbYsnPXF as exception:
   fJWvkClwdThKOerVHgRzqMpbYsnPXi(exception)
   return[]
  return fJWvkClwdThKOerVHgRzqMpbYsnPmx
 def Get_Event_GroupList(fJWvkClwdThKOerVHgRzqMpbYsnPSN):
  fJWvkClwdThKOerVHgRzqMpbYsnPmx=[] 
  try:
   fJWvkClwdThKOerVHgRzqMpbYsnPmX=fJWvkClwdThKOerVHgRzqMpbYsnPSN.API_VIEWURL+'/v2/discover/feed' 
   fJWvkClwdThKOerVHgRzqMpbYsnPmD={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':7,'filterRestrictedContent':'false',}
   fJWvkClwdThKOerVHgRzqMpbYsnPmB=fJWvkClwdThKOerVHgRzqMpbYsnPSN.callRequestCookies('Get',fJWvkClwdThKOerVHgRzqMpbYsnPmX,payload=fJWvkClwdThKOerVHgRzqMpbYsnPXy,params=fJWvkClwdThKOerVHgRzqMpbYsnPmD,headers=fJWvkClwdThKOerVHgRzqMpbYsnPXy,cookies=fJWvkClwdThKOerVHgRzqMpbYsnPXy,redirects=fJWvkClwdThKOerVHgRzqMpbYsnPXx)
   if fJWvkClwdThKOerVHgRzqMpbYsnPmB.status_code not in[200]:return[]
   fJWvkClwdThKOerVHgRzqMpbYsnPmQ=json.loads(fJWvkClwdThKOerVHgRzqMpbYsnPmB.text)
   for fJWvkClwdThKOerVHgRzqMpbYsnPmE in fJWvkClwdThKOerVHgRzqMpbYsnPmQ.get('data'):
    if fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('row_name').strip()!='':
     fJWvkClwdThKOerVHgRzqMpbYsnPNa =''
     fJWvkClwdThKOerVHgRzqMpbYsnPNU=7
     try:
      for i in fJWvkClwdThKOerVHgRzqMpbYsnPXD(fJWvkClwdThKOerVHgRzqMpbYsnPXo(fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('data'))):
       if i>=fJWvkClwdThKOerVHgRzqMpbYsnPNU:
        fJWvkClwdThKOerVHgRzqMpbYsnPNa=fJWvkClwdThKOerVHgRzqMpbYsnPNa+'...'
        break
       fJWvkClwdThKOerVHgRzqMpbYsnPNa=fJWvkClwdThKOerVHgRzqMpbYsnPNa+fJWvkClwdThKOerVHgRzqMpbYsnPmE['data'][i]['title']+'\n'
     except fJWvkClwdThKOerVHgRzqMpbYsnPXF as exception:
      fJWvkClwdThKOerVHgRzqMpbYsnPXi(exception)
     fJWvkClwdThKOerVHgRzqMpbYsnPmj={'collectionId':fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('obj_id'),'title':fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('row_name'),'category':fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('type'),'pre_title':fJWvkClwdThKOerVHgRzqMpbYsnPNa,}
     fJWvkClwdThKOerVHgRzqMpbYsnPmx.append(fJWvkClwdThKOerVHgRzqMpbYsnPmj)
  except fJWvkClwdThKOerVHgRzqMpbYsnPXF as exception:
   fJWvkClwdThKOerVHgRzqMpbYsnPXi(exception)
   return[]
  return fJWvkClwdThKOerVHgRzqMpbYsnPmx
 def Get_Event_GameList(fJWvkClwdThKOerVHgRzqMpbYsnPSN,fJWvkClwdThKOerVHgRzqMpbYsnPmG):
  fJWvkClwdThKOerVHgRzqMpbYsnPmx=[] 
  try:
   fJWvkClwdThKOerVHgRzqMpbYsnPmX=fJWvkClwdThKOerVHgRzqMpbYsnPSN.API_VIEWURL+'/v2/discover/feed' 
   fJWvkClwdThKOerVHgRzqMpbYsnPmD={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false',}
   fJWvkClwdThKOerVHgRzqMpbYsnPmB=fJWvkClwdThKOerVHgRzqMpbYsnPSN.callRequestCookies('Get',fJWvkClwdThKOerVHgRzqMpbYsnPmX,payload=fJWvkClwdThKOerVHgRzqMpbYsnPXy,params=fJWvkClwdThKOerVHgRzqMpbYsnPmD,headers=fJWvkClwdThKOerVHgRzqMpbYsnPXy,cookies=fJWvkClwdThKOerVHgRzqMpbYsnPXy,redirects=fJWvkClwdThKOerVHgRzqMpbYsnPXx)
   if fJWvkClwdThKOerVHgRzqMpbYsnPmB.status_code not in[200]:return[]
   fJWvkClwdThKOerVHgRzqMpbYsnPmQ=json.loads(fJWvkClwdThKOerVHgRzqMpbYsnPmB.text)
   for fJWvkClwdThKOerVHgRzqMpbYsnPmE in fJWvkClwdThKOerVHgRzqMpbYsnPmQ.get('data'):
    if fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('obj_id')==fJWvkClwdThKOerVHgRzqMpbYsnPmG:
     for fJWvkClwdThKOerVHgRzqMpbYsnPNF in fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('data'):
      fJWvkClwdThKOerVHgRzqMpbYsnPNX=fJWvkClwdThKOerVHgRzqMpbYsnPNy=fJWvkClwdThKOerVHgRzqMpbYsnPXm=''
      if 'poster' in fJWvkClwdThKOerVHgRzqMpbYsnPNF.get('images'):fJWvkClwdThKOerVHgRzqMpbYsnPNX =fJWvkClwdThKOerVHgRzqMpbYsnPNF.get('images').get('poster').get('url')
      if 'story-art' in fJWvkClwdThKOerVHgRzqMpbYsnPNF.get('images'):fJWvkClwdThKOerVHgRzqMpbYsnPNy =fJWvkClwdThKOerVHgRzqMpbYsnPNF.get('images').get('story-art').get('url')
      if 'hero' in fJWvkClwdThKOerVHgRzqMpbYsnPNF.get('images'):fJWvkClwdThKOerVHgRzqMpbYsnPXm =fJWvkClwdThKOerVHgRzqMpbYsnPNF.get('images').get('hero').get('url')
      fJWvkClwdThKOerVHgRzqMpbYsnPNA=fJWvkClwdThKOerVHgRzqMpbYsnPNF.get('meta').get(fJWvkClwdThKOerVHgRzqMpbYsnPNF.get('category')).get(fJWvkClwdThKOerVHgRzqMpbYsnPNF.get('sub_category'))
      if 'league' in fJWvkClwdThKOerVHgRzqMpbYsnPNA:
       fJWvkClwdThKOerVHgRzqMpbYsnPNx=fJWvkClwdThKOerVHgRzqMpbYsnPNA.get('league')
      else:
       fJWvkClwdThKOerVHgRzqMpbYsnPNx=fJWvkClwdThKOerVHgRzqMpbYsnPNA.get('round')
      fJWvkClwdThKOerVHgRzqMpbYsnPmj={'id':fJWvkClwdThKOerVHgRzqMpbYsnPNF.get('id'),'title':fJWvkClwdThKOerVHgRzqMpbYsnPNF.get('title'),'thumbnail':{'poster':fJWvkClwdThKOerVHgRzqMpbYsnPNX,'thumb':fJWvkClwdThKOerVHgRzqMpbYsnPNy,'fanart':fJWvkClwdThKOerVHgRzqMpbYsnPXm},'asis':fJWvkClwdThKOerVHgRzqMpbYsnPNF.get('type'),'addInfo':fJWvkClwdThKOerVHgRzqMpbYsnPNx,'starttm':fJWvkClwdThKOerVHgRzqMpbYsnPSN.convert_TimeStr(fJWvkClwdThKOerVHgRzqMpbYsnPNF.get('start_at')),}
      fJWvkClwdThKOerVHgRzqMpbYsnPmx.append(fJWvkClwdThKOerVHgRzqMpbYsnPmj)
  except fJWvkClwdThKOerVHgRzqMpbYsnPXF as exception:
   fJWvkClwdThKOerVHgRzqMpbYsnPXi(exception)
   return[]
  return fJWvkClwdThKOerVHgRzqMpbYsnPmx
 def Get_Event_List(fJWvkClwdThKOerVHgRzqMpbYsnPSN,gameId):
  fJWvkClwdThKOerVHgRzqMpbYsnPmx=[] 
  try:
   fJWvkClwdThKOerVHgRzqMpbYsnPmX=fJWvkClwdThKOerVHgRzqMpbYsnPSN.API_VIEWURL+'/v1/discover/events/'+gameId 
   fJWvkClwdThKOerVHgRzqMpbYsnPmD={'platform':'WEBCLIENT','locale':'ko','filterRestrictedContent':'false',}
   fJWvkClwdThKOerVHgRzqMpbYsnPmB=fJWvkClwdThKOerVHgRzqMpbYsnPSN.callRequestCookies('Get',fJWvkClwdThKOerVHgRzqMpbYsnPmX,payload=fJWvkClwdThKOerVHgRzqMpbYsnPXy,params=fJWvkClwdThKOerVHgRzqMpbYsnPmD,headers=fJWvkClwdThKOerVHgRzqMpbYsnPXy,cookies=fJWvkClwdThKOerVHgRzqMpbYsnPXy,redirects=fJWvkClwdThKOerVHgRzqMpbYsnPXx)
   if fJWvkClwdThKOerVHgRzqMpbYsnPmB.status_code not in[200]:return[]
   fJWvkClwdThKOerVHgRzqMpbYsnPmQ=json.loads(fJWvkClwdThKOerVHgRzqMpbYsnPmB.text)
   fJWvkClwdThKOerVHgRzqMpbYsnPmE=fJWvkClwdThKOerVHgRzqMpbYsnPmQ.get('data')
   fJWvkClwdThKOerVHgRzqMpbYsnPND=fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('end_at')
   fJWvkClwdThKOerVHgRzqMpbYsnPND=fJWvkClwdThKOerVHgRzqMpbYsnPND[0:19].replace('-','').replace(':','').replace('T','')
   fJWvkClwdThKOerVHgRzqMpbYsnPNo=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d%H%M%S')
   if fJWvkClwdThKOerVHgRzqMpbYsnPXU(fJWvkClwdThKOerVHgRzqMpbYsnPNo)<fJWvkClwdThKOerVHgRzqMpbYsnPXU(fJWvkClwdThKOerVHgRzqMpbYsnPND):
    fJWvkClwdThKOerVHgRzqMpbYsnPNX=fJWvkClwdThKOerVHgRzqMpbYsnPNy=fJWvkClwdThKOerVHgRzqMpbYsnPXm=''
    if 'poster' in fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('images'):fJWvkClwdThKOerVHgRzqMpbYsnPNX =fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('images').get('poster').get('url')
    if 'story-art' in fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('images'):fJWvkClwdThKOerVHgRzqMpbYsnPNy =fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('images').get('story-art').get('url')
    if 'story-art' in fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('images'):fJWvkClwdThKOerVHgRzqMpbYsnPXm =fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('images').get('story-art').get('url')
    fJWvkClwdThKOerVHgRzqMpbYsnPmj={'id':fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('id'),'title':fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('title'),'thumbnail':{'poster':fJWvkClwdThKOerVHgRzqMpbYsnPNX,'thumb':fJWvkClwdThKOerVHgRzqMpbYsnPNy,'fanart':fJWvkClwdThKOerVHgRzqMpbYsnPXm},'duration':fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('running_time'),'asis':fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('type'),'starttm':fJWvkClwdThKOerVHgRzqMpbYsnPSN.convert_TimeStr(fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('start_at')),}
    fJWvkClwdThKOerVHgRzqMpbYsnPmx.append(fJWvkClwdThKOerVHgRzqMpbYsnPmj)
  except fJWvkClwdThKOerVHgRzqMpbYsnPXF as exception:
   fJWvkClwdThKOerVHgRzqMpbYsnPXi(exception)
   return[]
  try:
   fJWvkClwdThKOerVHgRzqMpbYsnPmX=fJWvkClwdThKOerVHgRzqMpbYsnPSN.API_VIEWURL+'/v1/discover/events/'+gameId+'/related' 
   fJWvkClwdThKOerVHgRzqMpbYsnPmD={'locale':'ko','page':'1','perPage':'25','platform':'WEBCLIENT','currentPageTracking':'page_discover_title_detail',}
   fJWvkClwdThKOerVHgRzqMpbYsnPmB=fJWvkClwdThKOerVHgRzqMpbYsnPSN.callRequestCookies('Get',fJWvkClwdThKOerVHgRzqMpbYsnPmX,payload=fJWvkClwdThKOerVHgRzqMpbYsnPXy,params=fJWvkClwdThKOerVHgRzqMpbYsnPmD,headers=fJWvkClwdThKOerVHgRzqMpbYsnPXy,cookies=fJWvkClwdThKOerVHgRzqMpbYsnPXy,redirects=fJWvkClwdThKOerVHgRzqMpbYsnPXx)
   if fJWvkClwdThKOerVHgRzqMpbYsnPmB.status_code not in[200]:return[]
   fJWvkClwdThKOerVHgRzqMpbYsnPmQ=json.loads(fJWvkClwdThKOerVHgRzqMpbYsnPmB.text)
   for fJWvkClwdThKOerVHgRzqMpbYsnPmE in fJWvkClwdThKOerVHgRzqMpbYsnPmQ.get('data').get('data'):
    fJWvkClwdThKOerVHgRzqMpbYsnPNX=fJWvkClwdThKOerVHgRzqMpbYsnPNy=fJWvkClwdThKOerVHgRzqMpbYsnPXm=''
    if 'poster' in fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('images'):fJWvkClwdThKOerVHgRzqMpbYsnPNX =fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('images').get('poster').get('url')
    if 'story-art' in fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('images'):fJWvkClwdThKOerVHgRzqMpbYsnPNy =fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('images').get('story-art').get('url')
    if 'story-art' in fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('images'):fJWvkClwdThKOerVHgRzqMpbYsnPXm =fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('images').get('story-art').get('url')
    fJWvkClwdThKOerVHgRzqMpbYsnPmj={'id':fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('id'),'title':fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('title'),'thumbnail':{'poster':fJWvkClwdThKOerVHgRzqMpbYsnPNX,'thumb':fJWvkClwdThKOerVHgRzqMpbYsnPNy,'fanart':fJWvkClwdThKOerVHgRzqMpbYsnPXm},'duration':fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('running_time'),'asis':fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('type'),}
    fJWvkClwdThKOerVHgRzqMpbYsnPmx.append(fJWvkClwdThKOerVHgRzqMpbYsnPmj)
  except fJWvkClwdThKOerVHgRzqMpbYsnPXF as exception:
   fJWvkClwdThKOerVHgRzqMpbYsnPXi(exception)
   return[]
  return fJWvkClwdThKOerVHgRzqMpbYsnPmx
 def Get_Search_List(fJWvkClwdThKOerVHgRzqMpbYsnPSN,search_key,page_int):
  fJWvkClwdThKOerVHgRzqMpbYsnPmx=[] 
  fJWvkClwdThKOerVHgRzqMpbYsnPNS=fJWvkClwdThKOerVHgRzqMpbYsnPXt
  try:
   fJWvkClwdThKOerVHgRzqMpbYsnPmX=fJWvkClwdThKOerVHgRzqMpbYsnPSN.API_VIEWURL+'/v2/search' 
   fJWvkClwdThKOerVHgRzqMpbYsnPmD={'query':search_key,'platform':'WEBCLIENT','page':fJWvkClwdThKOerVHgRzqMpbYsnPXQ(page_int),'perPage':fJWvkClwdThKOerVHgRzqMpbYsnPXQ(fJWvkClwdThKOerVHgRzqMpbYsnPSN.SEARCH_LIMIT),}
   fJWvkClwdThKOerVHgRzqMpbYsnPmt={'x-membersrl':fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['member_srl'],'x-pcid':fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['PCID'],'x-profileid':fJWvkClwdThKOerVHgRzqMpbYsnPSN.CP['SESSION']['profileId'],}
   fJWvkClwdThKOerVHgRzqMpbYsnPmB=fJWvkClwdThKOerVHgRzqMpbYsnPSN.callRequestCookies('Get',fJWvkClwdThKOerVHgRzqMpbYsnPmX,payload=fJWvkClwdThKOerVHgRzqMpbYsnPXy,params=fJWvkClwdThKOerVHgRzqMpbYsnPmD,headers=fJWvkClwdThKOerVHgRzqMpbYsnPmt,cookies=fJWvkClwdThKOerVHgRzqMpbYsnPXy,redirects=fJWvkClwdThKOerVHgRzqMpbYsnPXx)
   if fJWvkClwdThKOerVHgRzqMpbYsnPmB.status_code not in[200]:return[],fJWvkClwdThKOerVHgRzqMpbYsnPXt
   fJWvkClwdThKOerVHgRzqMpbYsnPmQ=json.loads(fJWvkClwdThKOerVHgRzqMpbYsnPmB.text)
   for fJWvkClwdThKOerVHgRzqMpbYsnPmE in fJWvkClwdThKOerVHgRzqMpbYsnPmQ.get('data').get('data'):
    fJWvkClwdThKOerVHgRzqMpbYsnPmE=fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('data')
    fJWvkClwdThKOerVHgRzqMpbYsnPNX=fJWvkClwdThKOerVHgRzqMpbYsnPNy=fJWvkClwdThKOerVHgRzqMpbYsnPXN=fJWvkClwdThKOerVHgRzqMpbYsnPXm=''
    if 'poster' in fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('images'):fJWvkClwdThKOerVHgRzqMpbYsnPNX =fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('images').get('poster').get('url')
    if 'story-art' in fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('images'):fJWvkClwdThKOerVHgRzqMpbYsnPNy =fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('images').get('story-art').get('url')
    if 'title-treatment' in fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('images'):fJWvkClwdThKOerVHgRzqMpbYsnPXN=fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('images').get('title-treatment').get('url')
    if 'story-art' in fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('images'):fJWvkClwdThKOerVHgRzqMpbYsnPXm =fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('images').get('story-art').get('url')
    fJWvkClwdThKOerVHgRzqMpbYsnPNB=''
    if fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('badge')not in[{},fJWvkClwdThKOerVHgRzqMpbYsnPXy]:
     for i in fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('badge').get('text'):
      if fJWvkClwdThKOerVHgRzqMpbYsnPNB!='':fJWvkClwdThKOerVHgRzqMpbYsnPNB+=' '
      fJWvkClwdThKOerVHgRzqMpbYsnPNB+=i.get('text')
    if 'as' in fJWvkClwdThKOerVHgRzqMpbYsnPmE:
     fJWvkClwdThKOerVHgRzqMpbYsnPNI=fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('as') 
    else:
     fJWvkClwdThKOerVHgRzqMpbYsnPNI=fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('type')
    fJWvkClwdThKOerVHgRzqMpbYsnPmj={'id':fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('id'),'title':fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('title'),'asis':fJWvkClwdThKOerVHgRzqMpbYsnPNI,'thumbnail':{'poster':fJWvkClwdThKOerVHgRzqMpbYsnPNX,'thumb':fJWvkClwdThKOerVHgRzqMpbYsnPNy,'clearlogo':fJWvkClwdThKOerVHgRzqMpbYsnPXN,'fanart':fJWvkClwdThKOerVHgRzqMpbYsnPXm},'mpaa':fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('age_rating'),'duration':fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('running_time'),'badge':fJWvkClwdThKOerVHgRzqMpbYsnPNB,'year':fJWvkClwdThKOerVHgRzqMpbYsnPmE.get('meta').get('releaseYear'),}
    fJWvkClwdThKOerVHgRzqMpbYsnPmx.append(fJWvkClwdThKOerVHgRzqMpbYsnPmj)
   if fJWvkClwdThKOerVHgRzqMpbYsnPmQ.get('pagination').get('totalPages')>page_int:
    fJWvkClwdThKOerVHgRzqMpbYsnPNS=fJWvkClwdThKOerVHgRzqMpbYsnPXx
  except fJWvkClwdThKOerVHgRzqMpbYsnPXF as exception:
   fJWvkClwdThKOerVHgRzqMpbYsnPXi(exception)
   return[],fJWvkClwdThKOerVHgRzqMpbYsnPXt
  return fJWvkClwdThKOerVHgRzqMpbYsnPmx,fJWvkClwdThKOerVHgRzqMpbYsnPNS
 def GetBookmarkInfo(fJWvkClwdThKOerVHgRzqMpbYsnPSN,videoid,vidtype):
  fJWvkClwdThKOerVHgRzqMpbYsnPNE={'indexinfo':{'ott':'coupang','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  fJWvkClwdThKOerVHgRzqMpbYsnPmX=fJWvkClwdThKOerVHgRzqMpbYsnPSN.API_VIEWURL+'/v1/discover/titles/'+videoid 
  fJWvkClwdThKOerVHgRzqMpbYsnPmD={'locale':'ko'}
  fJWvkClwdThKOerVHgRzqMpbYsnPmB=fJWvkClwdThKOerVHgRzqMpbYsnPSN.callRequestCookies('Get',fJWvkClwdThKOerVHgRzqMpbYsnPmX,payload=fJWvkClwdThKOerVHgRzqMpbYsnPXy,params=fJWvkClwdThKOerVHgRzqMpbYsnPmD,headers=fJWvkClwdThKOerVHgRzqMpbYsnPXy,cookies=fJWvkClwdThKOerVHgRzqMpbYsnPXy,redirects=fJWvkClwdThKOerVHgRzqMpbYsnPXx)
  if fJWvkClwdThKOerVHgRzqMpbYsnPmB.status_code not in[200]:return{}
  fJWvkClwdThKOerVHgRzqMpbYsnPNG=json.loads(fJWvkClwdThKOerVHgRzqMpbYsnPmB.text).get('data')
  fJWvkClwdThKOerVHgRzqMpbYsnPNj=fJWvkClwdThKOerVHgRzqMpbYsnPNG.get('title')
  fJWvkClwdThKOerVHgRzqMpbYsnPXS =fJWvkClwdThKOerVHgRzqMpbYsnPNG.get('meta').get('releaseYear')
  fJWvkClwdThKOerVHgRzqMpbYsnPNE['saveinfo']['infoLabels']['title']=fJWvkClwdThKOerVHgRzqMpbYsnPNj
  if vidtype=='movie':
   fJWvkClwdThKOerVHgRzqMpbYsnPNj='%s  (%s)'%(fJWvkClwdThKOerVHgRzqMpbYsnPNj,fJWvkClwdThKOerVHgRzqMpbYsnPXS)
  fJWvkClwdThKOerVHgRzqMpbYsnPNE['saveinfo']['title'] =fJWvkClwdThKOerVHgRzqMpbYsnPNj
  fJWvkClwdThKOerVHgRzqMpbYsnPNE['saveinfo']['infoLabels']['mpaa'] =fJWvkClwdThKOerVHgRzqMpbYsnPNG.get('age_rating')
  fJWvkClwdThKOerVHgRzqMpbYsnPNE['saveinfo']['infoLabels']['plot'] ='%s\n\n%s'%(fJWvkClwdThKOerVHgRzqMpbYsnPNG.get('short_description'),fJWvkClwdThKOerVHgRzqMpbYsnPNG.get('description'))
  fJWvkClwdThKOerVHgRzqMpbYsnPNE['saveinfo']['infoLabels']['year'] =fJWvkClwdThKOerVHgRzqMpbYsnPXS
  if vidtype=='movie':
   fJWvkClwdThKOerVHgRzqMpbYsnPNE['saveinfo']['infoLabels']['duration']=fJWvkClwdThKOerVHgRzqMpbYsnPNG.get('running_time')
  fJWvkClwdThKOerVHgRzqMpbYsnPNX =''
  fJWvkClwdThKOerVHgRzqMpbYsnPXm =''
  fJWvkClwdThKOerVHgRzqMpbYsnPNy =''
  fJWvkClwdThKOerVHgRzqMpbYsnPXN=''
  if fJWvkClwdThKOerVHgRzqMpbYsnPNG.get('images').get('poster') !=fJWvkClwdThKOerVHgRzqMpbYsnPXy:fJWvkClwdThKOerVHgRzqMpbYsnPNX =fJWvkClwdThKOerVHgRzqMpbYsnPNG.get('images').get('poster').get('url')
  if fJWvkClwdThKOerVHgRzqMpbYsnPNG.get('images').get('background') !=fJWvkClwdThKOerVHgRzqMpbYsnPXy:fJWvkClwdThKOerVHgRzqMpbYsnPXm =fJWvkClwdThKOerVHgRzqMpbYsnPNG.get('images').get('background').get('url')
  if fJWvkClwdThKOerVHgRzqMpbYsnPNG.get('images').get('story-art') !=fJWvkClwdThKOerVHgRzqMpbYsnPXy:fJWvkClwdThKOerVHgRzqMpbYsnPNy =fJWvkClwdThKOerVHgRzqMpbYsnPNG.get('images').get('story-art').get('url')
  if fJWvkClwdThKOerVHgRzqMpbYsnPNG.get('images').get('title-treatment')!=fJWvkClwdThKOerVHgRzqMpbYsnPXy:fJWvkClwdThKOerVHgRzqMpbYsnPXN=fJWvkClwdThKOerVHgRzqMpbYsnPNG.get('images').get('title-treatment').get('url')
  if fJWvkClwdThKOerVHgRzqMpbYsnPXm=='':fJWvkClwdThKOerVHgRzqMpbYsnPXm=fJWvkClwdThKOerVHgRzqMpbYsnPNy
  fJWvkClwdThKOerVHgRzqMpbYsnPNE['saveinfo']['thumbnail']['poster']=fJWvkClwdThKOerVHgRzqMpbYsnPNX
  fJWvkClwdThKOerVHgRzqMpbYsnPNE['saveinfo']['thumbnail']['fanart']=fJWvkClwdThKOerVHgRzqMpbYsnPXm
  fJWvkClwdThKOerVHgRzqMpbYsnPNE['saveinfo']['thumbnail']['thumb']=fJWvkClwdThKOerVHgRzqMpbYsnPNy
  fJWvkClwdThKOerVHgRzqMpbYsnPNE['saveinfo']['thumbnail']['clearlogo']=fJWvkClwdThKOerVHgRzqMpbYsnPXN
  fJWvkClwdThKOerVHgRzqMpbYsnPXB=[]
  for fJWvkClwdThKOerVHgRzqMpbYsnPNc in fJWvkClwdThKOerVHgRzqMpbYsnPNG.get('tags'):fJWvkClwdThKOerVHgRzqMpbYsnPXB.append(fJWvkClwdThKOerVHgRzqMpbYsnPNc.get('tag'))
  if fJWvkClwdThKOerVHgRzqMpbYsnPXo(fJWvkClwdThKOerVHgRzqMpbYsnPXB)>0:
   fJWvkClwdThKOerVHgRzqMpbYsnPNE['saveinfo']['infoLabels']['genre']=fJWvkClwdThKOerVHgRzqMpbYsnPXB
  fJWvkClwdThKOerVHgRzqMpbYsnPXL=[]
  fJWvkClwdThKOerVHgRzqMpbYsnPXu=[]
  for fJWvkClwdThKOerVHgRzqMpbYsnPNc in fJWvkClwdThKOerVHgRzqMpbYsnPNG.get('people'):
   if fJWvkClwdThKOerVHgRzqMpbYsnPNc.get('role')=='CAST' :fJWvkClwdThKOerVHgRzqMpbYsnPXL.append(fJWvkClwdThKOerVHgRzqMpbYsnPNc.get('name'))
   if fJWvkClwdThKOerVHgRzqMpbYsnPNc.get('role')=='DIRECTOR':fJWvkClwdThKOerVHgRzqMpbYsnPXu.append(fJWvkClwdThKOerVHgRzqMpbYsnPNc.get('name'))
  if fJWvkClwdThKOerVHgRzqMpbYsnPXo(fJWvkClwdThKOerVHgRzqMpbYsnPXL)>0:
   fJWvkClwdThKOerVHgRzqMpbYsnPNE['saveinfo']['infoLabels']['cast'] =fJWvkClwdThKOerVHgRzqMpbYsnPXL
  if fJWvkClwdThKOerVHgRzqMpbYsnPXo(fJWvkClwdThKOerVHgRzqMpbYsnPXu)>0:
   fJWvkClwdThKOerVHgRzqMpbYsnPNE['saveinfo']['infoLabels']['director']=fJWvkClwdThKOerVHgRzqMpbYsnPXu
  return fJWvkClwdThKOerVHgRzqMpbYsnPNE
# Created by pyminifier (https://github.com/liftoff/pyminifier)
