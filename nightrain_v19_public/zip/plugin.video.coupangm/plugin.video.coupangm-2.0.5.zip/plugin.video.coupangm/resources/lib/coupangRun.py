__author__="NightRain"
GbxeBPsuQYTNgOJRVwFKoUnmIijyfp=object
GbxeBPsuQYTNgOJRVwFKoUnmIijyfh=None
GbxeBPsuQYTNgOJRVwFKoUnmIijyfL=False
GbxeBPsuQYTNgOJRVwFKoUnmIijyfz=True
GbxeBPsuQYTNgOJRVwFKoUnmIijyfl=type
GbxeBPsuQYTNgOJRVwFKoUnmIijyfc=dict
GbxeBPsuQYTNgOJRVwFKoUnmIijyfk=int
GbxeBPsuQYTNgOJRVwFKoUnmIijyfq=open
GbxeBPsuQYTNgOJRVwFKoUnmIijytr=Exception
GbxeBPsuQYTNgOJRVwFKoUnmIijytA=str
GbxeBPsuQYTNgOJRVwFKoUnmIijytE=id
GbxeBPsuQYTNgOJRVwFKoUnmIijyta=len
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import inputstreamhelper
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
GbxeBPsuQYTNgOJRVwFKoUnmIijyrE=[{'title':'홈   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'ALL'},{'title':'TV   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'MOVIES'},{'title':'교육 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'EDUCATION'},{'title':'생중계','mode':'EVENT_GROUPLIST','vType':'LIVE'},{'title':'TV   (테마별)','mode':'THEME_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (테마별)','mode':'THEME_GROUPLIST','vType':'MOVIES'},{'title':'교육 (테마별)','mode':'THEME_GROUPLIST','vType':'EDUCATION'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},{'title':'(쿠팡) 검색','mode':'LOCAL_SEARCH','icon':'search.png'},{'title':'(쿠팡) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
GbxeBPsuQYTNgOJRVwFKoUnmIijyra=[{'title':'시리즈 시청내역','mode':'WATCH','stype':'tvshow'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},]
GbxeBPsuQYTNgOJRVwFKoUnmIijyrd=xbmcvfs.translatePath(os.path.join(__profile__,'coupang_searched.txt'))
from coupangCore import*
class GbxeBPsuQYTNgOJRVwFKoUnmIijyrA(GbxeBPsuQYTNgOJRVwFKoUnmIijyfp):
 def __init__(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf,GbxeBPsuQYTNgOJRVwFKoUnmIijyrt,GbxeBPsuQYTNgOJRVwFKoUnmIijyrD,GbxeBPsuQYTNgOJRVwFKoUnmIijyrW):
  GbxeBPsuQYTNgOJRVwFKoUnmIijyrf._addon_url =GbxeBPsuQYTNgOJRVwFKoUnmIijyrt
  GbxeBPsuQYTNgOJRVwFKoUnmIijyrf._addon_handle=GbxeBPsuQYTNgOJRVwFKoUnmIijyrD
  GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.main_params =GbxeBPsuQYTNgOJRVwFKoUnmIijyrW
  GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj =DCQUHNYsREPywOtAnKfmWapekuhlVc() 
  GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.CP_COOKIE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_cookies.json'))
  GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.CP_DEVICE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_device.json'))
 def addon_noti(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf,sting):
  try:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrX=xbmcgui.Dialog()
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrX.notification(__addonname__,sting)
  except:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyfh
 def addon_log(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf,string):
  try:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrM=string.encode('utf-8','ignore')
  except:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrM='addonException: addon_log'
  GbxeBPsuQYTNgOJRVwFKoUnmIijyrC=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,GbxeBPsuQYTNgOJRVwFKoUnmIijyrM),level=GbxeBPsuQYTNgOJRVwFKoUnmIijyrC)
 def get_keyboard_input(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf,GbxeBPsuQYTNgOJRVwFKoUnmIijyAE):
  GbxeBPsuQYTNgOJRVwFKoUnmIijyrS=GbxeBPsuQYTNgOJRVwFKoUnmIijyfh
  kb=xbmc.Keyboard()
  kb.setHeading(GbxeBPsuQYTNgOJRVwFKoUnmIijyAE)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrS=kb.getText()
  return GbxeBPsuQYTNgOJRVwFKoUnmIijyrS
 def get_settings_account(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf):
  GbxeBPsuQYTNgOJRVwFKoUnmIijyrv=__addon__.getSetting('id')
  GbxeBPsuQYTNgOJRVwFKoUnmIijyrp=__addon__.getSetting('pw')
  GbxeBPsuQYTNgOJRVwFKoUnmIijyrh=__addon__.getSetting('profile')
  return(GbxeBPsuQYTNgOJRVwFKoUnmIijyrv,GbxeBPsuQYTNgOJRVwFKoUnmIijyrp,GbxeBPsuQYTNgOJRVwFKoUnmIijyrh)
 def get_settings_exclusion21(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf):
  GbxeBPsuQYTNgOJRVwFKoUnmIijyrL =__addon__.getSetting('exclusion21')
  if GbxeBPsuQYTNgOJRVwFKoUnmIijyrL=='false':
   return GbxeBPsuQYTNgOJRVwFKoUnmIijyfL
  else:
   return GbxeBPsuQYTNgOJRVwFKoUnmIijyfz
 def get_settings_totalsearch(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf):
  GbxeBPsuQYTNgOJRVwFKoUnmIijyrz =GbxeBPsuQYTNgOJRVwFKoUnmIijyfz if __addon__.getSetting('local_search')=='true' else GbxeBPsuQYTNgOJRVwFKoUnmIijyfL
  GbxeBPsuQYTNgOJRVwFKoUnmIijyrl=GbxeBPsuQYTNgOJRVwFKoUnmIijyfz if __addon__.getSetting('local_history')=='true' else GbxeBPsuQYTNgOJRVwFKoUnmIijyfL
  GbxeBPsuQYTNgOJRVwFKoUnmIijyrc =GbxeBPsuQYTNgOJRVwFKoUnmIijyfz if __addon__.getSetting('total_search')=='true' else GbxeBPsuQYTNgOJRVwFKoUnmIijyfL
  GbxeBPsuQYTNgOJRVwFKoUnmIijyrk=GbxeBPsuQYTNgOJRVwFKoUnmIijyfz if __addon__.getSetting('total_history')=='true' else GbxeBPsuQYTNgOJRVwFKoUnmIijyfL
  GbxeBPsuQYTNgOJRVwFKoUnmIijyrq=GbxeBPsuQYTNgOJRVwFKoUnmIijyfz if __addon__.getSetting('menu_bookmark')=='true' else GbxeBPsuQYTNgOJRVwFKoUnmIijyfL
  return(GbxeBPsuQYTNgOJRVwFKoUnmIijyrz,GbxeBPsuQYTNgOJRVwFKoUnmIijyrl,GbxeBPsuQYTNgOJRVwFKoUnmIijyrc,GbxeBPsuQYTNgOJRVwFKoUnmIijyrk,GbxeBPsuQYTNgOJRVwFKoUnmIijyrq)
 def get_settings_makebookmark(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf):
  return GbxeBPsuQYTNgOJRVwFKoUnmIijyfz if __addon__.getSetting('make_bookmark')=='true' else GbxeBPsuQYTNgOJRVwFKoUnmIijyfL
 def add_dir(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf,label,sublabel='',img='',infoLabels=GbxeBPsuQYTNgOJRVwFKoUnmIijyfh,isFolder=GbxeBPsuQYTNgOJRVwFKoUnmIijyfz,params='',isLink=GbxeBPsuQYTNgOJRVwFKoUnmIijyfL,ContextMenu=GbxeBPsuQYTNgOJRVwFKoUnmIijyfh):
  GbxeBPsuQYTNgOJRVwFKoUnmIijyAr='%s?%s'%(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf._addon_url,urllib.parse.urlencode(params))
  if sublabel:GbxeBPsuQYTNgOJRVwFKoUnmIijyAE='%s < %s >'%(label,sublabel)
  else: GbxeBPsuQYTNgOJRVwFKoUnmIijyAE=label
  if not img:img='DefaultFolder.png'
  GbxeBPsuQYTNgOJRVwFKoUnmIijyAa=xbmcgui.ListItem(GbxeBPsuQYTNgOJRVwFKoUnmIijyAE)
  if GbxeBPsuQYTNgOJRVwFKoUnmIijyfl(img)==GbxeBPsuQYTNgOJRVwFKoUnmIijyfc:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAa.setArt(img)
  else:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAa.setArt({'thumb':img,'poster':img})
  if infoLabels:GbxeBPsuQYTNgOJRVwFKoUnmIijyAa.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAa.setProperty('IsPlayable','true')
  if ContextMenu:GbxeBPsuQYTNgOJRVwFKoUnmIijyAa.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf._addon_handle,GbxeBPsuQYTNgOJRVwFKoUnmIijyAr,GbxeBPsuQYTNgOJRVwFKoUnmIijyAa,isFolder)
 def dp_Main_List(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf,args):
  (GbxeBPsuQYTNgOJRVwFKoUnmIijyrz,GbxeBPsuQYTNgOJRVwFKoUnmIijyrl,GbxeBPsuQYTNgOJRVwFKoUnmIijyrc,GbxeBPsuQYTNgOJRVwFKoUnmIijyrk,GbxeBPsuQYTNgOJRVwFKoUnmIijyrq)=GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.get_settings_totalsearch()
  for GbxeBPsuQYTNgOJRVwFKoUnmIijyAd in GbxeBPsuQYTNgOJRVwFKoUnmIijyrE:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAE=GbxeBPsuQYTNgOJRVwFKoUnmIijyAd.get('title')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAf=''
   if GbxeBPsuQYTNgOJRVwFKoUnmIijyAd.get('mode')=='LOCAL_SEARCH' and GbxeBPsuQYTNgOJRVwFKoUnmIijyrz ==GbxeBPsuQYTNgOJRVwFKoUnmIijyfL:continue
   elif GbxeBPsuQYTNgOJRVwFKoUnmIijyAd.get('mode')=='SEARCH_HISTORY' and GbxeBPsuQYTNgOJRVwFKoUnmIijyrl==GbxeBPsuQYTNgOJRVwFKoUnmIijyfL:continue
   elif GbxeBPsuQYTNgOJRVwFKoUnmIijyAd.get('mode')=='TOTAL_SEARCH' and GbxeBPsuQYTNgOJRVwFKoUnmIijyrc ==GbxeBPsuQYTNgOJRVwFKoUnmIijyfL:continue
   elif GbxeBPsuQYTNgOJRVwFKoUnmIijyAd.get('mode')=='TOTAL_HISTORY' and GbxeBPsuQYTNgOJRVwFKoUnmIijyrk==GbxeBPsuQYTNgOJRVwFKoUnmIijyfL:continue
   elif GbxeBPsuQYTNgOJRVwFKoUnmIijyAd.get('mode')=='MENU_BOOKMARK' and GbxeBPsuQYTNgOJRVwFKoUnmIijyrq==GbxeBPsuQYTNgOJRVwFKoUnmIijyfL:continue
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAt={'mode':GbxeBPsuQYTNgOJRVwFKoUnmIijyAd.get('mode'),'vType':GbxeBPsuQYTNgOJRVwFKoUnmIijyAd.get('vType'),'page':'1',}
   if GbxeBPsuQYTNgOJRVwFKoUnmIijyAd.get('mode')=='LOCAL_SEARCH':GbxeBPsuQYTNgOJRVwFKoUnmIijyAt['historyyn']='Y' 
   if GbxeBPsuQYTNgOJRVwFKoUnmIijyAd.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    GbxeBPsuQYTNgOJRVwFKoUnmIijyAD=GbxeBPsuQYTNgOJRVwFKoUnmIijyfL
    GbxeBPsuQYTNgOJRVwFKoUnmIijyAW =GbxeBPsuQYTNgOJRVwFKoUnmIijyfz
   else:
    GbxeBPsuQYTNgOJRVwFKoUnmIijyAD=GbxeBPsuQYTNgOJRVwFKoUnmIijyfz
    GbxeBPsuQYTNgOJRVwFKoUnmIijyAW =GbxeBPsuQYTNgOJRVwFKoUnmIijyfL
   if 'icon' in GbxeBPsuQYTNgOJRVwFKoUnmIijyAd:GbxeBPsuQYTNgOJRVwFKoUnmIijyAf=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',GbxeBPsuQYTNgOJRVwFKoUnmIijyAd.get('icon')) 
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.add_dir(GbxeBPsuQYTNgOJRVwFKoUnmIijyAE,sublabel='',img=GbxeBPsuQYTNgOJRVwFKoUnmIijyAf,infoLabels=GbxeBPsuQYTNgOJRVwFKoUnmIijyfh,isFolder=GbxeBPsuQYTNgOJRVwFKoUnmIijyAD,params=GbxeBPsuQYTNgOJRVwFKoUnmIijyAt,isLink=GbxeBPsuQYTNgOJRVwFKoUnmIijyAW)
  xbmcplugin.endOfDirectory(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf._addon_handle)
 def dp_Test(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf,args):
  GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.addon_noti('test')
 def CP_logout(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf):
  GbxeBPsuQYTNgOJRVwFKoUnmIijyrX=xbmcgui.Dialog()
  GbxeBPsuQYTNgOJRVwFKoUnmIijyAX=GbxeBPsuQYTNgOJRVwFKoUnmIijyrX.yesno(__language__(30905).encode('utf8'),__language__(30906).encode('utf8'))
  if GbxeBPsuQYTNgOJRVwFKoUnmIijyAX==GbxeBPsuQYTNgOJRVwFKoUnmIijyfL:return 
  if os.path.isfile(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.CP_COOKIE_FILENAME):os.remove(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.CP_COOKIE_FILENAME)
  GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.addon_noti(__language__(30904).encode('utf-8'))
 def option_check(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf):
  (GbxeBPsuQYTNgOJRVwFKoUnmIijyrv,GbxeBPsuQYTNgOJRVwFKoUnmIijyrp,GbxeBPsuQYTNgOJRVwFKoUnmIijyrh)=GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.get_settings_account()
  if GbxeBPsuQYTNgOJRVwFKoUnmIijyrv=='' or GbxeBPsuQYTNgOJRVwFKoUnmIijyrp=='':
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrX=xbmcgui.Dialog()
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAX=GbxeBPsuQYTNgOJRVwFKoUnmIijyrX.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if GbxeBPsuQYTNgOJRVwFKoUnmIijyAX==GbxeBPsuQYTNgOJRVwFKoUnmIijyfz:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.cookiefile_check()==GbxeBPsuQYTNgOJRVwFKoUnmIijyfL:
   if GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CP_login(GbxeBPsuQYTNgOJRVwFKoUnmIijyrv,GbxeBPsuQYTNgOJRVwFKoUnmIijyrp,GbxeBPsuQYTNgOJRVwFKoUnmIijyrh)==GbxeBPsuQYTNgOJRVwFKoUnmIijyfL:
    GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.addon_noti(__language__(30903).encode('utf8'))
    sys.exit()
  else:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.Get_CP_profile(GbxeBPsuQYTNgOJRVwFKoUnmIijyrh,limit_days=GbxeBPsuQYTNgOJRVwFKoUnmIijyfk(__addon__.getSetting('cache_ttl')),re_check=GbxeBPsuQYTNgOJRVwFKoUnmIijyfz)
 def cookiefile_check(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf):
  GbxeBPsuQYTNgOJRVwFKoUnmIijyAC={}
  try: 
   fp=GbxeBPsuQYTNgOJRVwFKoUnmIijyfq(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.CP_COOKIE_FILENAME,'r',-1,'utf-8')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAC= json.load(fp)
   fp.close()
  except GbxeBPsuQYTNgOJRVwFKoUnmIijytr as exception:
   return GbxeBPsuQYTNgOJRVwFKoUnmIijyfL
  GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.CP=GbxeBPsuQYTNgOJRVwFKoUnmIijyAC
  (GbxeBPsuQYTNgOJRVwFKoUnmIijyrv,GbxeBPsuQYTNgOJRVwFKoUnmIijyrp,GbxeBPsuQYTNgOJRVwFKoUnmIijyrh)=GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.get_settings_account()
  (GbxeBPsuQYTNgOJRVwFKoUnmIijyAS,GbxeBPsuQYTNgOJRVwFKoUnmIijyAv,GbxeBPsuQYTNgOJRVwFKoUnmIijyAp)=GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.Load_session_acount()
  if GbxeBPsuQYTNgOJRVwFKoUnmIijyrv!=GbxeBPsuQYTNgOJRVwFKoUnmIijyAS or GbxeBPsuQYTNgOJRVwFKoUnmIijyrp!=GbxeBPsuQYTNgOJRVwFKoUnmIijyAv or GbxeBPsuQYTNgOJRVwFKoUnmIijyrh!=GbxeBPsuQYTNgOJRVwFKoUnmIijytA(GbxeBPsuQYTNgOJRVwFKoUnmIijyAp):
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.Init_CP()
   return GbxeBPsuQYTNgOJRVwFKoUnmIijyfL
  GbxeBPsuQYTNgOJRVwFKoUnmIijyAh =GbxeBPsuQYTNgOJRVwFKoUnmIijyfk(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.Get_Now_Datetime().strftime('%Y%m%d'))
  GbxeBPsuQYTNgOJRVwFKoUnmIijyAL=GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.CP['SESSION']['limitdate']
  GbxeBPsuQYTNgOJRVwFKoUnmIijyAz =GbxeBPsuQYTNgOJRVwFKoUnmIijyfk(re.sub('-','',GbxeBPsuQYTNgOJRVwFKoUnmIijyAL))
  if GbxeBPsuQYTNgOJRVwFKoUnmIijyAz<GbxeBPsuQYTNgOJRVwFKoUnmIijyAh:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.Init_CP()
   return GbxeBPsuQYTNgOJRVwFKoUnmIijyfL
  return GbxeBPsuQYTNgOJRVwFKoUnmIijyfz
 def CP_login(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf,GbxeBPsuQYTNgOJRVwFKoUnmIijyrv,GbxeBPsuQYTNgOJRVwFKoUnmIijyrp,GbxeBPsuQYTNgOJRVwFKoUnmIijyrh):
  if GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.Get_CP_Login(GbxeBPsuQYTNgOJRVwFKoUnmIijyrv,GbxeBPsuQYTNgOJRVwFKoUnmIijyrp,GbxeBPsuQYTNgOJRVwFKoUnmIijyrh)==GbxeBPsuQYTNgOJRVwFKoUnmIijyfL:return GbxeBPsuQYTNgOJRVwFKoUnmIijyfL
  if GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.Get_CP_profile(GbxeBPsuQYTNgOJRVwFKoUnmIijyrh,limit_days=GbxeBPsuQYTNgOJRVwFKoUnmIijyfk(__addon__.getSetting('cache_ttl')),re_check=GbxeBPsuQYTNgOJRVwFKoUnmIijyfL)==GbxeBPsuQYTNgOJRVwFKoUnmIijyfL:return GbxeBPsuQYTNgOJRVwFKoUnmIijyfL
  return GbxeBPsuQYTNgOJRVwFKoUnmIijyfz
 def dp_Category_GroupList(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf,args):
  GbxeBPsuQYTNgOJRVwFKoUnmIijyAl =args.get('vType') 
  GbxeBPsuQYTNgOJRVwFKoUnmIijyAc=GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.Get_Category_GroupList(GbxeBPsuQYTNgOJRVwFKoUnmIijyAl)
  for GbxeBPsuQYTNgOJRVwFKoUnmIijyAk in GbxeBPsuQYTNgOJRVwFKoUnmIijyAc:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAE =GbxeBPsuQYTNgOJRVwFKoUnmIijyAk.get('title')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAq=GbxeBPsuQYTNgOJRVwFKoUnmIijyAk.get('pre_title')
   if GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.get_settings_exclusion21()==GbxeBPsuQYTNgOJRVwFKoUnmIijyfz and GbxeBPsuQYTNgOJRVwFKoUnmIijyAE=='성인':continue
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEr={'mediatype':'tvshow','plot':GbxeBPsuQYTNgOJRVwFKoUnmIijyAq,}
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAt={'mode':'CATEGORY_LIST','collectionId':GbxeBPsuQYTNgOJRVwFKoUnmIijyAk.get('collectionId'),'vType':GbxeBPsuQYTNgOJRVwFKoUnmIijyAk.get('category'),'page':'1',}
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.add_dir(GbxeBPsuQYTNgOJRVwFKoUnmIijyAE,sublabel='',img='',infoLabels=GbxeBPsuQYTNgOJRVwFKoUnmIijyEr,isFolder=GbxeBPsuQYTNgOJRVwFKoUnmIijyfz,params=GbxeBPsuQYTNgOJRVwFKoUnmIijyAt)
  xbmcplugin.endOfDirectory(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf._addon_handle,cacheToDisc=GbxeBPsuQYTNgOJRVwFKoUnmIijyfL)
 def dp_Theme_GroupList(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf,args):
  GbxeBPsuQYTNgOJRVwFKoUnmIijyAl =args.get('vType') 
  GbxeBPsuQYTNgOJRVwFKoUnmIijyAc=GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.Get_Theme_GroupList(GbxeBPsuQYTNgOJRVwFKoUnmIijyAl)
  for GbxeBPsuQYTNgOJRVwFKoUnmIijyAk in GbxeBPsuQYTNgOJRVwFKoUnmIijyAc:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAE =GbxeBPsuQYTNgOJRVwFKoUnmIijyAk.get('title')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAq=GbxeBPsuQYTNgOJRVwFKoUnmIijyAk.get('pre_title')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEr={'mediatype':'tvshow','plot':GbxeBPsuQYTNgOJRVwFKoUnmIijyAq,}
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAt={'mode':'CATEGORY_LIST','collectionId':GbxeBPsuQYTNgOJRVwFKoUnmIijyAk.get('collectionId'),'vType':GbxeBPsuQYTNgOJRVwFKoUnmIijyAk.get('category'),'page':'1',}
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.add_dir(GbxeBPsuQYTNgOJRVwFKoUnmIijyAE,sublabel='',img='',infoLabels=GbxeBPsuQYTNgOJRVwFKoUnmIijyEr,isFolder=GbxeBPsuQYTNgOJRVwFKoUnmIijyfz,params=GbxeBPsuQYTNgOJRVwFKoUnmIijyAt)
  xbmcplugin.endOfDirectory(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf._addon_handle,cacheToDisc=GbxeBPsuQYTNgOJRVwFKoUnmIijyfL)
 def dp_Event_GroupList(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf,args):
  GbxeBPsuQYTNgOJRVwFKoUnmIijyAc=GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.Get_Event_GroupList()
  for GbxeBPsuQYTNgOJRVwFKoUnmIijyAk in GbxeBPsuQYTNgOJRVwFKoUnmIijyAc:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAE =GbxeBPsuQYTNgOJRVwFKoUnmIijyAk.get('title')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAq=GbxeBPsuQYTNgOJRVwFKoUnmIijyAk.get('pre_title')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEr={'mediatype':'tvshow','plot':GbxeBPsuQYTNgOJRVwFKoUnmIijyAq,}
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAt={'mode':'EVENT_GAMELIST','collectionId':GbxeBPsuQYTNgOJRVwFKoUnmIijyAk.get('collectionId'),'vType':'LIVE',}
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.add_dir(GbxeBPsuQYTNgOJRVwFKoUnmIijyAE,sublabel='',img='',infoLabels=GbxeBPsuQYTNgOJRVwFKoUnmIijyEr,isFolder=GbxeBPsuQYTNgOJRVwFKoUnmIijyfz,params=GbxeBPsuQYTNgOJRVwFKoUnmIijyAt)
  xbmcplugin.endOfDirectory(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf._addon_handle,cacheToDisc=GbxeBPsuQYTNgOJRVwFKoUnmIijyfL)
 def dp_Event_GameList(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf,args):
  GbxeBPsuQYTNgOJRVwFKoUnmIijyAl =args.get('vType') 
  GbxeBPsuQYTNgOJRVwFKoUnmIijyEa =args.get('collectionId')
  GbxeBPsuQYTNgOJRVwFKoUnmIijyAc=GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.Get_Event_GameList(GbxeBPsuQYTNgOJRVwFKoUnmIijyEa)
  for GbxeBPsuQYTNgOJRVwFKoUnmIijyAk in GbxeBPsuQYTNgOJRVwFKoUnmIijyAc:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAE =GbxeBPsuQYTNgOJRVwFKoUnmIijyAk.get('title')
   GbxeBPsuQYTNgOJRVwFKoUnmIijytE =GbxeBPsuQYTNgOJRVwFKoUnmIijyAk.get('id')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEd =GbxeBPsuQYTNgOJRVwFKoUnmIijyAk.get('thumbnail')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEf =GbxeBPsuQYTNgOJRVwFKoUnmIijyAk.get('asis') 
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEt =GbxeBPsuQYTNgOJRVwFKoUnmIijyAk.get('addInfo')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyED =GbxeBPsuQYTNgOJRVwFKoUnmIijyAk.get('starttm')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEr={'mediatype':'tvshow','title':GbxeBPsuQYTNgOJRVwFKoUnmIijyAE,'plot':GbxeBPsuQYTNgOJRVwFKoUnmIijyEt,}
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAt={'mode':'EVENT_LIST','id':GbxeBPsuQYTNgOJRVwFKoUnmIijytE,'asis':GbxeBPsuQYTNgOJRVwFKoUnmIijyEf,'title':GbxeBPsuQYTNgOJRVwFKoUnmIijyAE,}
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.add_dir(GbxeBPsuQYTNgOJRVwFKoUnmIijyAE,sublabel=GbxeBPsuQYTNgOJRVwFKoUnmIijyED,img=GbxeBPsuQYTNgOJRVwFKoUnmIijyEd,infoLabels=GbxeBPsuQYTNgOJRVwFKoUnmIijyEr,isFolder=GbxeBPsuQYTNgOJRVwFKoUnmIijyfz,params=GbxeBPsuQYTNgOJRVwFKoUnmIijyAt,ContextMenu=GbxeBPsuQYTNgOJRVwFKoUnmIijyfh)
  xbmcplugin.setContent(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf._addon_handle,cacheToDisc=GbxeBPsuQYTNgOJRVwFKoUnmIijyfL)
 def dp_Event_List(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf,args):
  GbxeBPsuQYTNgOJRVwFKoUnmIijyEW=args.get('id')
  GbxeBPsuQYTNgOJRVwFKoUnmIijyAc=GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.Get_Event_List(GbxeBPsuQYTNgOJRVwFKoUnmIijyEW)
  for GbxeBPsuQYTNgOJRVwFKoUnmIijyAk in GbxeBPsuQYTNgOJRVwFKoUnmIijyAc:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAE =GbxeBPsuQYTNgOJRVwFKoUnmIijyAk.get('title')
   GbxeBPsuQYTNgOJRVwFKoUnmIijytE =GbxeBPsuQYTNgOJRVwFKoUnmIijyAk.get('id')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEd =GbxeBPsuQYTNgOJRVwFKoUnmIijyAk.get('thumbnail')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEf =GbxeBPsuQYTNgOJRVwFKoUnmIijyAk.get('asis') 
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEH =GbxeBPsuQYTNgOJRVwFKoUnmIijyAk.get('duration')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyED =GbxeBPsuQYTNgOJRVwFKoUnmIijyAk.get('starttm')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEr={'mediatype':'episode','title':GbxeBPsuQYTNgOJRVwFKoUnmIijyAE,'plot':GbxeBPsuQYTNgOJRVwFKoUnmIijyEf,'duration':GbxeBPsuQYTNgOJRVwFKoUnmIijyEH,}
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAt={'mode':GbxeBPsuQYTNgOJRVwFKoUnmIijyEf,'id':GbxeBPsuQYTNgOJRVwFKoUnmIijytE,'asis':GbxeBPsuQYTNgOJRVwFKoUnmIijyEf,'title':GbxeBPsuQYTNgOJRVwFKoUnmIijyAE,}
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.add_dir(GbxeBPsuQYTNgOJRVwFKoUnmIijyAE,sublabel=GbxeBPsuQYTNgOJRVwFKoUnmIijyED,img=GbxeBPsuQYTNgOJRVwFKoUnmIijyEd,infoLabels=GbxeBPsuQYTNgOJRVwFKoUnmIijyEr,isFolder=GbxeBPsuQYTNgOJRVwFKoUnmIijyfL,params=GbxeBPsuQYTNgOJRVwFKoUnmIijyAt,ContextMenu=GbxeBPsuQYTNgOJRVwFKoUnmIijyfh)
  xbmcplugin.setContent(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf._addon_handle,cacheToDisc=GbxeBPsuQYTNgOJRVwFKoUnmIijyfL)
 def dp_Category_List(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf,args):
  GbxeBPsuQYTNgOJRVwFKoUnmIijyAl =args.get('vType') 
  GbxeBPsuQYTNgOJRVwFKoUnmIijyEa =args.get('collectionId')
  GbxeBPsuQYTNgOJRVwFKoUnmIijyEX =GbxeBPsuQYTNgOJRVwFKoUnmIijyfk(args.get('page'))
  GbxeBPsuQYTNgOJRVwFKoUnmIijyAc,GbxeBPsuQYTNgOJRVwFKoUnmIijyEM=GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.Get_Category_List(GbxeBPsuQYTNgOJRVwFKoUnmIijyAl,GbxeBPsuQYTNgOJRVwFKoUnmIijyEa,GbxeBPsuQYTNgOJRVwFKoUnmIijyEX)
  for GbxeBPsuQYTNgOJRVwFKoUnmIijyAk in GbxeBPsuQYTNgOJRVwFKoUnmIijyAc:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAE =GbxeBPsuQYTNgOJRVwFKoUnmIijyAk.get('title')
   GbxeBPsuQYTNgOJRVwFKoUnmIijytE =GbxeBPsuQYTNgOJRVwFKoUnmIijyAk.get('id')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEd =GbxeBPsuQYTNgOJRVwFKoUnmIijyAk.get('thumbnail')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEC =GbxeBPsuQYTNgOJRVwFKoUnmIijyAk.get('mpaa')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEH =GbxeBPsuQYTNgOJRVwFKoUnmIijyAk.get('duration')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEf =GbxeBPsuQYTNgOJRVwFKoUnmIijyAk.get('asis')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyES =GbxeBPsuQYTNgOJRVwFKoUnmIijyAk.get('badge')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEv =GbxeBPsuQYTNgOJRVwFKoUnmIijyAk.get('year')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEp=GbxeBPsuQYTNgOJRVwFKoUnmIijyAk.get('seasonList')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEh =GbxeBPsuQYTNgOJRVwFKoUnmIijyAk.get('genreList')
   if GbxeBPsuQYTNgOJRVwFKoUnmIijyEf in['TVSHOW','EDUCATION']: 
    GbxeBPsuQYTNgOJRVwFKoUnmIijyEL ='SEASON_LIST'
    GbxeBPsuQYTNgOJRVwFKoUnmIijyEr={'mediatype':'tvshow','title':GbxeBPsuQYTNgOJRVwFKoUnmIijyAE,'mpaa':GbxeBPsuQYTNgOJRVwFKoUnmIijyEC,'genre':GbxeBPsuQYTNgOJRVwFKoUnmIijyEh,'year':GbxeBPsuQYTNgOJRVwFKoUnmIijyEv,'plot':'Year : %s\nSeason : %s'%(GbxeBPsuQYTNgOJRVwFKoUnmIijyEv,GbxeBPsuQYTNgOJRVwFKoUnmIijyEp),}
    GbxeBPsuQYTNgOJRVwFKoUnmIijyAD =GbxeBPsuQYTNgOJRVwFKoUnmIijyfz
   else:
    GbxeBPsuQYTNgOJRVwFKoUnmIijyEL ='MOVIE'
    GbxeBPsuQYTNgOJRVwFKoUnmIijyEr={'mediatype':'movie','title':GbxeBPsuQYTNgOJRVwFKoUnmIijyAE,'mpaa':GbxeBPsuQYTNgOJRVwFKoUnmIijyEC,'genre':GbxeBPsuQYTNgOJRVwFKoUnmIijyEh,'duration':GbxeBPsuQYTNgOJRVwFKoUnmIijyEH,'year':GbxeBPsuQYTNgOJRVwFKoUnmIijyEv,'plot':'(%s)'%(GbxeBPsuQYTNgOJRVwFKoUnmIijyEC),}
    GbxeBPsuQYTNgOJRVwFKoUnmIijyAD =GbxeBPsuQYTNgOJRVwFKoUnmIijyfL
    GbxeBPsuQYTNgOJRVwFKoUnmIijyAE +=' (%s)'%(GbxeBPsuQYTNgOJRVwFKoUnmIijytA(GbxeBPsuQYTNgOJRVwFKoUnmIijyEv))
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAt={'mode':GbxeBPsuQYTNgOJRVwFKoUnmIijyEL,'id':GbxeBPsuQYTNgOJRVwFKoUnmIijytE,'asis':GbxeBPsuQYTNgOJRVwFKoUnmIijyEf,'seasonList':GbxeBPsuQYTNgOJRVwFKoUnmIijyEp,'title':GbxeBPsuQYTNgOJRVwFKoUnmIijyAE,'thumbnail':GbxeBPsuQYTNgOJRVwFKoUnmIijyEd,'year':GbxeBPsuQYTNgOJRVwFKoUnmIijyEv,}
   if GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.get_settings_makebookmark():
    GbxeBPsuQYTNgOJRVwFKoUnmIijyEz={'videoid':GbxeBPsuQYTNgOJRVwFKoUnmIijytE,'vidtype':'movie' if GbxeBPsuQYTNgOJRVwFKoUnmIijyAl=='MOVIES' else 'tvshow','vtitle':GbxeBPsuQYTNgOJRVwFKoUnmIijyAE,'vsubtitle':'',}
    GbxeBPsuQYTNgOJRVwFKoUnmIijyEl=json.dumps(GbxeBPsuQYTNgOJRVwFKoUnmIijyEz)
    GbxeBPsuQYTNgOJRVwFKoUnmIijyEl=urllib.parse.quote(GbxeBPsuQYTNgOJRVwFKoUnmIijyEl)
    GbxeBPsuQYTNgOJRVwFKoUnmIijyEc='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(GbxeBPsuQYTNgOJRVwFKoUnmIijyEl)
    GbxeBPsuQYTNgOJRVwFKoUnmIijyEk=[('(통합) 찜 영상에 추가',GbxeBPsuQYTNgOJRVwFKoUnmIijyEc)]
   else:
    GbxeBPsuQYTNgOJRVwFKoUnmIijyEk=GbxeBPsuQYTNgOJRVwFKoUnmIijyfh
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.add_dir(GbxeBPsuQYTNgOJRVwFKoUnmIijyAE,sublabel=GbxeBPsuQYTNgOJRVwFKoUnmIijyES,img=GbxeBPsuQYTNgOJRVwFKoUnmIijyEd,infoLabels=GbxeBPsuQYTNgOJRVwFKoUnmIijyEr,isFolder=GbxeBPsuQYTNgOJRVwFKoUnmIijyAD,params=GbxeBPsuQYTNgOJRVwFKoUnmIijyAt,ContextMenu=GbxeBPsuQYTNgOJRVwFKoUnmIijyEk)
  if GbxeBPsuQYTNgOJRVwFKoUnmIijyEM:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAt['mode'] ='CATEGORY_LIST' 
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAt['collectionId']=GbxeBPsuQYTNgOJRVwFKoUnmIijyEa 
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAt['vType'] =GbxeBPsuQYTNgOJRVwFKoUnmIijyAl 
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAt['page'] =GbxeBPsuQYTNgOJRVwFKoUnmIijytA(GbxeBPsuQYTNgOJRVwFKoUnmIijyEX+1)
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAE='[B]%s >>[/B]'%'다음 페이지'
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEq=GbxeBPsuQYTNgOJRVwFKoUnmIijytA(GbxeBPsuQYTNgOJRVwFKoUnmIijyEX+1)
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAf=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.add_dir(GbxeBPsuQYTNgOJRVwFKoUnmIijyAE,sublabel=GbxeBPsuQYTNgOJRVwFKoUnmIijyEq,img=GbxeBPsuQYTNgOJRVwFKoUnmIijyAf,infoLabels=GbxeBPsuQYTNgOJRVwFKoUnmIijyfh,isFolder=GbxeBPsuQYTNgOJRVwFKoUnmIijyfz,params=GbxeBPsuQYTNgOJRVwFKoUnmIijyAt)
  if GbxeBPsuQYTNgOJRVwFKoUnmIijyAl=='TVSHOWS':xbmcplugin.setContent(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf._addon_handle,'tvshows')
  else:xbmcplugin.setContent(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf._addon_handle,'movies')
  xbmcplugin.endOfDirectory(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf._addon_handle,cacheToDisc=GbxeBPsuQYTNgOJRVwFKoUnmIijyfL)
 def dp_Season_List(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf,args):
  GbxeBPsuQYTNgOJRVwFKoUnmIijyar =args.get('title')
  GbxeBPsuQYTNgOJRVwFKoUnmIijyaA =args.get('id')
  GbxeBPsuQYTNgOJRVwFKoUnmIijyEf =args.get('asis')
  GbxeBPsuQYTNgOJRVwFKoUnmIijyEp =args.get('seasonList')
  GbxeBPsuQYTNgOJRVwFKoUnmIijyEd =args.get('thumbnail')
  GbxeBPsuQYTNgOJRVwFKoUnmIijyEv =args.get('year')
  if GbxeBPsuQYTNgOJRVwFKoUnmIijyEp in['',GbxeBPsuQYTNgOJRVwFKoUnmIijyfh]:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEp=GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.Get_vInfo(GbxeBPsuQYTNgOJRVwFKoUnmIijyaA).get('seasonList')
  if GbxeBPsuQYTNgOJRVwFKoUnmIijyta(GbxeBPsuQYTNgOJRVwFKoUnmIijyEp.split(','))>1:
   for GbxeBPsuQYTNgOJRVwFKoUnmIijyaE in GbxeBPsuQYTNgOJRVwFKoUnmIijyEp.split(','):
    GbxeBPsuQYTNgOJRVwFKoUnmIijyAE='시즌 '+GbxeBPsuQYTNgOJRVwFKoUnmIijyaE
    GbxeBPsuQYTNgOJRVwFKoUnmIijyEr={'mediatype':'tvshow','plot':'%s (%s)'%(GbxeBPsuQYTNgOJRVwFKoUnmIijyar,GbxeBPsuQYTNgOJRVwFKoUnmIijyEv),}
    GbxeBPsuQYTNgOJRVwFKoUnmIijyAt={'mode':'EPISODE_LIST','programid':GbxeBPsuQYTNgOJRVwFKoUnmIijyaA,'programnm':GbxeBPsuQYTNgOJRVwFKoUnmIijyar,'season':GbxeBPsuQYTNgOJRVwFKoUnmIijyaE,'asis':GbxeBPsuQYTNgOJRVwFKoUnmIijyEf,'programimg':GbxeBPsuQYTNgOJRVwFKoUnmIijyEd,}
    GbxeBPsuQYTNgOJRVwFKoUnmIijyad=GbxeBPsuQYTNgOJRVwFKoUnmIijyEd.replace('\'','\"')
    GbxeBPsuQYTNgOJRVwFKoUnmIijyad=json.loads(GbxeBPsuQYTNgOJRVwFKoUnmIijyad)
    GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.add_dir(GbxeBPsuQYTNgOJRVwFKoUnmIijyAE,sublabel='',img=GbxeBPsuQYTNgOJRVwFKoUnmIijyad,infoLabels=GbxeBPsuQYTNgOJRVwFKoUnmIijyEr,isFolder=GbxeBPsuQYTNgOJRVwFKoUnmIijyfz,params=GbxeBPsuQYTNgOJRVwFKoUnmIijyAt)
   xbmcplugin.setContent(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf._addon_handle,cacheToDisc=GbxeBPsuQYTNgOJRVwFKoUnmIijyfL)
  else:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyaf={'programid':GbxeBPsuQYTNgOJRVwFKoUnmIijyaA,'programnm':GbxeBPsuQYTNgOJRVwFKoUnmIijyar,'season':GbxeBPsuQYTNgOJRVwFKoUnmIijyEp,'programimg':GbxeBPsuQYTNgOJRVwFKoUnmIijyEd,}
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.dp_Episode_List(GbxeBPsuQYTNgOJRVwFKoUnmIijyaf)
 def dp_Episode_List(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf,args):
  GbxeBPsuQYTNgOJRVwFKoUnmIijyaA =args.get('programid')
  GbxeBPsuQYTNgOJRVwFKoUnmIijyar =args.get('programnm')
  GbxeBPsuQYTNgOJRVwFKoUnmIijyat =args.get('season')
  GbxeBPsuQYTNgOJRVwFKoUnmIijyaD =args.get('programimg')
  GbxeBPsuQYTNgOJRVwFKoUnmIijyaW=GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.Get_Episode_List(GbxeBPsuQYTNgOJRVwFKoUnmIijyaA,GbxeBPsuQYTNgOJRVwFKoUnmIijyat)
  for GbxeBPsuQYTNgOJRVwFKoUnmIijyaE in GbxeBPsuQYTNgOJRVwFKoUnmIijyaW:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyaH =GbxeBPsuQYTNgOJRVwFKoUnmIijyaE.get('title')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyaX =GbxeBPsuQYTNgOJRVwFKoUnmIijyaE.get('id')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEf =GbxeBPsuQYTNgOJRVwFKoUnmIijyaE.get('asis')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEd =GbxeBPsuQYTNgOJRVwFKoUnmIijyaE.get('thumbnail')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEC =GbxeBPsuQYTNgOJRVwFKoUnmIijyaE.get('mpaa')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEH =GbxeBPsuQYTNgOJRVwFKoUnmIijyaE.get('duration')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEv =GbxeBPsuQYTNgOJRVwFKoUnmIijyaE.get('year')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyaM =GbxeBPsuQYTNgOJRVwFKoUnmIijyaE.get('episode')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEh =GbxeBPsuQYTNgOJRVwFKoUnmIijyaE.get('genreList')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyaC =GbxeBPsuQYTNgOJRVwFKoUnmIijyaE.get('desc')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyaS ='%sx%s'%(GbxeBPsuQYTNgOJRVwFKoUnmIijyat,GbxeBPsuQYTNgOJRVwFKoUnmIijyaM)
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAE ='%s. %s'%(GbxeBPsuQYTNgOJRVwFKoUnmIijyaS,GbxeBPsuQYTNgOJRVwFKoUnmIijyaH)
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEr={'mediatype':'episode','mpaa':GbxeBPsuQYTNgOJRVwFKoUnmIijyEC,'genre':GbxeBPsuQYTNgOJRVwFKoUnmIijyEh,'duration':GbxeBPsuQYTNgOJRVwFKoUnmIijyEH,'year':GbxeBPsuQYTNgOJRVwFKoUnmIijyEv,'plot':'%s (%s)\n\n%s'%(GbxeBPsuQYTNgOJRVwFKoUnmIijyar,GbxeBPsuQYTNgOJRVwFKoUnmIijyaS,GbxeBPsuQYTNgOJRVwFKoUnmIijyaC),}
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAt={'mode':'VOD','programid':GbxeBPsuQYTNgOJRVwFKoUnmIijyaA,'programnm':GbxeBPsuQYTNgOJRVwFKoUnmIijyar,'title':GbxeBPsuQYTNgOJRVwFKoUnmIijyAE,'season':GbxeBPsuQYTNgOJRVwFKoUnmIijyat,'id':GbxeBPsuQYTNgOJRVwFKoUnmIijyaX,'asis':GbxeBPsuQYTNgOJRVwFKoUnmIijyEf,'thumbnail':GbxeBPsuQYTNgOJRVwFKoUnmIijyEd,'programimg':GbxeBPsuQYTNgOJRVwFKoUnmIijyaD,}
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.add_dir(GbxeBPsuQYTNgOJRVwFKoUnmIijyAE,sublabel='',img=GbxeBPsuQYTNgOJRVwFKoUnmIijyEd,infoLabels=GbxeBPsuQYTNgOJRVwFKoUnmIijyEr,isFolder=GbxeBPsuQYTNgOJRVwFKoUnmIijyfL,params=GbxeBPsuQYTNgOJRVwFKoUnmIijyAt)
  xbmcplugin.setContent(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf._addon_handle,cacheToDisc=GbxeBPsuQYTNgOJRVwFKoUnmIijyfL)
 def play_VIDEO(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf,args):
  GbxeBPsuQYTNgOJRVwFKoUnmIijyav =args.get('id')
  GbxeBPsuQYTNgOJRVwFKoUnmIijyEf =args.get('asis')
  if GbxeBPsuQYTNgOJRVwFKoUnmIijyEf in['HIGHLIGHT']:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyap,GbxeBPsuQYTNgOJRVwFKoUnmIijyah=GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.GetEventURL(GbxeBPsuQYTNgOJRVwFKoUnmIijyav,GbxeBPsuQYTNgOJRVwFKoUnmIijyEf)
  elif GbxeBPsuQYTNgOJRVwFKoUnmIijyEf in['LIVE']:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyap,GbxeBPsuQYTNgOJRVwFKoUnmIijyah=GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.GetEventURL_Live(GbxeBPsuQYTNgOJRVwFKoUnmIijyav,GbxeBPsuQYTNgOJRVwFKoUnmIijyEf)
  else:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyap,GbxeBPsuQYTNgOJRVwFKoUnmIijyah=GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.GetBroadURL(GbxeBPsuQYTNgOJRVwFKoUnmIijyav)
  GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.addon_log('asis, url : %s - %s - %s'%(GbxeBPsuQYTNgOJRVwFKoUnmIijyEf,GbxeBPsuQYTNgOJRVwFKoUnmIijyav,GbxeBPsuQYTNgOJRVwFKoUnmIijyap))
  if GbxeBPsuQYTNgOJRVwFKoUnmIijyap=='':
   if GbxeBPsuQYTNgOJRVwFKoUnmIijyah=='':
    GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.addon_noti(__language__(30907).encode('utf8'))
   else:
    GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.addon_noti(GbxeBPsuQYTNgOJRVwFKoUnmIijyah)
   return
  GbxeBPsuQYTNgOJRVwFKoUnmIijyaL='PCID=%s;token=%s;member_srl=%s;NEXT_LOCALE=%s;bm_mi=%s;ak_bmsc=%s;bm_sv=%s'%(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.CP['SESSION']['PCID'],GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.CP['SESSION']['token'],GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.CP['SESSION']['member_srl'],GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.CP['SESSION']['NEXT_LOCALE'],GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.CP['SESSION']['bm_mi'],GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.CP['SESSION']['ak_bmsc'],GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.CP['SESSION']['bm_sv'],)
  GbxeBPsuQYTNgOJRVwFKoUnmIijyaz='%s|Cookie=%s'%(GbxeBPsuQYTNgOJRVwFKoUnmIijyap,GbxeBPsuQYTNgOJRVwFKoUnmIijyaL)
  GbxeBPsuQYTNgOJRVwFKoUnmIijyal=xbmcgui.ListItem(path=GbxeBPsuQYTNgOJRVwFKoUnmIijyaz)
  if GbxeBPsuQYTNgOJRVwFKoUnmIijyah:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyac =GbxeBPsuQYTNgOJRVwFKoUnmIijyah 
   GbxeBPsuQYTNgOJRVwFKoUnmIijyak ='mpd' 
   GbxeBPsuQYTNgOJRVwFKoUnmIijyaq ='com.widevine.alpha'
   GbxeBPsuQYTNgOJRVwFKoUnmIijydr =inputstreamhelper.Helper(GbxeBPsuQYTNgOJRVwFKoUnmIijyak,drm='widevine')
   if GbxeBPsuQYTNgOJRVwFKoUnmIijydr.check_inputstream():
    GbxeBPsuQYTNgOJRVwFKoUnmIijydA,GbxeBPsuQYTNgOJRVwFKoUnmIijydE,GbxeBPsuQYTNgOJRVwFKoUnmIijyda=GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.Make_authHeader()
    GbxeBPsuQYTNgOJRVwFKoUnmIijydf={'traceparent':GbxeBPsuQYTNgOJRVwFKoUnmIijydA,'tracestate':GbxeBPsuQYTNgOJRVwFKoUnmIijydE,'newrelic':GbxeBPsuQYTNgOJRVwFKoUnmIijyda,'content-type':'application/octet-stream','User-Agent':GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.USER_AGENT,'Cookie':GbxeBPsuQYTNgOJRVwFKoUnmIijyaL,}
    GbxeBPsuQYTNgOJRVwFKoUnmIijydt=GbxeBPsuQYTNgOJRVwFKoUnmIijyac+'|'+urllib.parse.urlencode(GbxeBPsuQYTNgOJRVwFKoUnmIijydf)+'|R{SSM}|'
    GbxeBPsuQYTNgOJRVwFKoUnmIijyal.setProperty('inputstream',GbxeBPsuQYTNgOJRVwFKoUnmIijydr.inputstream_addon)
    GbxeBPsuQYTNgOJRVwFKoUnmIijyal.setProperty('inputstream.adaptive.manifest_type',GbxeBPsuQYTNgOJRVwFKoUnmIijyak)
    GbxeBPsuQYTNgOJRVwFKoUnmIijyal.setProperty('inputstream.adaptive.license_type',GbxeBPsuQYTNgOJRVwFKoUnmIijyaq)
    GbxeBPsuQYTNgOJRVwFKoUnmIijyal.setProperty('inputstream.adaptive.license_key',GbxeBPsuQYTNgOJRVwFKoUnmIijydt)
    GbxeBPsuQYTNgOJRVwFKoUnmIijyal.setProperty('inputstream.adaptive.stream_headers','User-Agent=%s&Cookie=%s'%(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.USER_AGENT,GbxeBPsuQYTNgOJRVwFKoUnmIijyaL))
    GbxeBPsuQYTNgOJRVwFKoUnmIijyal.setMimeType('application/dash+xml')
    GbxeBPsuQYTNgOJRVwFKoUnmIijyal.setContentLookup(GbxeBPsuQYTNgOJRVwFKoUnmIijyfL)
  xbmcplugin.setResolvedUrl(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf._addon_handle,GbxeBPsuQYTNgOJRVwFKoUnmIijyfz,GbxeBPsuQYTNgOJRVwFKoUnmIijyal)
  try:
   if GbxeBPsuQYTNgOJRVwFKoUnmIijyEf=='MOVIE':
    GbxeBPsuQYTNgOJRVwFKoUnmIijydD='movie'
    GbxeBPsuQYTNgOJRVwFKoUnmIijyAt={'code':GbxeBPsuQYTNgOJRVwFKoUnmIijyav,'asis':GbxeBPsuQYTNgOJRVwFKoUnmIijyEf,'title':args.get('title'),'img':args.get('thumbnail'),}
    GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.Save_Watched_List(GbxeBPsuQYTNgOJRVwFKoUnmIijydD,GbxeBPsuQYTNgOJRVwFKoUnmIijyAt)
   elif GbxeBPsuQYTNgOJRVwFKoUnmIijyEf=='TVSHOW':
    GbxeBPsuQYTNgOJRVwFKoUnmIijydD='tvshow'
    GbxeBPsuQYTNgOJRVwFKoUnmIijyAt={'code':args.get('programid'),'asis':GbxeBPsuQYTNgOJRVwFKoUnmIijyEf,'title':'%s <%s>'%(args.get('title'),args.get('programnm')),'img':args.get('programimg'),}
    GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.Save_Watched_List(GbxeBPsuQYTNgOJRVwFKoUnmIijydD,GbxeBPsuQYTNgOJRVwFKoUnmIijyAt)
  except:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyfh
 def dp_Global_Search(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf,args):
  GbxeBPsuQYTNgOJRVwFKoUnmIijyEL=args.get('mode')
  if GbxeBPsuQYTNgOJRVwFKoUnmIijyEL=='TOTAL_SEARCH':
   GbxeBPsuQYTNgOJRVwFKoUnmIijydW='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   GbxeBPsuQYTNgOJRVwFKoUnmIijydW='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(GbxeBPsuQYTNgOJRVwFKoUnmIijydW)
 def dp_Bookmark_Menu(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf,args):
  GbxeBPsuQYTNgOJRVwFKoUnmIijydW='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(GbxeBPsuQYTNgOJRVwFKoUnmIijydW)
 def dp_Search_List(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf,args):
  GbxeBPsuQYTNgOJRVwFKoUnmIijyEX =GbxeBPsuQYTNgOJRVwFKoUnmIijyfk(args.get('page'))
  if 'search_key' in args:
   GbxeBPsuQYTNgOJRVwFKoUnmIijydH=args.get('search_key')
  else:
   GbxeBPsuQYTNgOJRVwFKoUnmIijydH=GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.get_keyboard_input(__language__(30908).encode('utf-8'))
   if not GbxeBPsuQYTNgOJRVwFKoUnmIijydH:
    return
  GbxeBPsuQYTNgOJRVwFKoUnmIijydX,GbxeBPsuQYTNgOJRVwFKoUnmIijyEM=GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.Get_Search_List(GbxeBPsuQYTNgOJRVwFKoUnmIijydH,GbxeBPsuQYTNgOJRVwFKoUnmIijyEX)
  for GbxeBPsuQYTNgOJRVwFKoUnmIijydM in GbxeBPsuQYTNgOJRVwFKoUnmIijydX:
   GbxeBPsuQYTNgOJRVwFKoUnmIijytE =GbxeBPsuQYTNgOJRVwFKoUnmIijydM.get('id')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAE =GbxeBPsuQYTNgOJRVwFKoUnmIijydM.get('title')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEf =GbxeBPsuQYTNgOJRVwFKoUnmIijydM.get('asis')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEd =GbxeBPsuQYTNgOJRVwFKoUnmIijydM.get('thumbnail')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEC =GbxeBPsuQYTNgOJRVwFKoUnmIijydM.get('mpaa')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEv =GbxeBPsuQYTNgOJRVwFKoUnmIijydM.get('year')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEH =GbxeBPsuQYTNgOJRVwFKoUnmIijydM.get('duration')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyES =GbxeBPsuQYTNgOJRVwFKoUnmIijydM.get('badge')
   if GbxeBPsuQYTNgOJRVwFKoUnmIijyEf=='TVSHOW': 
    GbxeBPsuQYTNgOJRVwFKoUnmIijyEL ='SEASON_LIST'
    GbxeBPsuQYTNgOJRVwFKoUnmIijyEr={'mediatype':'tvshow','title':GbxeBPsuQYTNgOJRVwFKoUnmIijyAE,'mpaa':GbxeBPsuQYTNgOJRVwFKoUnmIijyEC,'year':GbxeBPsuQYTNgOJRVwFKoUnmIijyEv,'plot':'Year : %s'%(GbxeBPsuQYTNgOJRVwFKoUnmIijyEv),}
    GbxeBPsuQYTNgOJRVwFKoUnmIijyAD =GbxeBPsuQYTNgOJRVwFKoUnmIijyfz
   elif GbxeBPsuQYTNgOJRVwFKoUnmIijyEf=='MOVIE':
    GbxeBPsuQYTNgOJRVwFKoUnmIijyEL ='MOVIE'
    GbxeBPsuQYTNgOJRVwFKoUnmIijyEr={'mediatype':'movie','title':GbxeBPsuQYTNgOJRVwFKoUnmIijyAE,'mpaa':GbxeBPsuQYTNgOJRVwFKoUnmIijyEC,'duration':GbxeBPsuQYTNgOJRVwFKoUnmIijyEH,'year':GbxeBPsuQYTNgOJRVwFKoUnmIijyEv,'plot':'(%s)'%(GbxeBPsuQYTNgOJRVwFKoUnmIijyEC),}
    GbxeBPsuQYTNgOJRVwFKoUnmIijyAD =GbxeBPsuQYTNgOJRVwFKoUnmIijyfL
    GbxeBPsuQYTNgOJRVwFKoUnmIijyAE +=' (%s)'%(GbxeBPsuQYTNgOJRVwFKoUnmIijytA(GbxeBPsuQYTNgOJRVwFKoUnmIijyEv))
   elif GbxeBPsuQYTNgOJRVwFKoUnmIijyEf=='HIGHLIGHT':
    GbxeBPsuQYTNgOJRVwFKoUnmIijyEL ='HIGHLIGHT'
    GbxeBPsuQYTNgOJRVwFKoUnmIijyEr={'mediatype':'episode','title':GbxeBPsuQYTNgOJRVwFKoUnmIijyAE,'duration':GbxeBPsuQYTNgOJRVwFKoUnmIijyEH,'plot':GbxeBPsuQYTNgOJRVwFKoUnmIijyEL,}
    GbxeBPsuQYTNgOJRVwFKoUnmIijyAD =GbxeBPsuQYTNgOJRVwFKoUnmIijyfL
   elif GbxeBPsuQYTNgOJRVwFKoUnmIijyEf=='LIVE':
    GbxeBPsuQYTNgOJRVwFKoUnmIijyEL ='LIVE'
    GbxeBPsuQYTNgOJRVwFKoUnmIijyEr={'mediatype':'episode','title':GbxeBPsuQYTNgOJRVwFKoUnmIijyAE,'plot':GbxeBPsuQYTNgOJRVwFKoUnmIijyEL,}
    GbxeBPsuQYTNgOJRVwFKoUnmIijyAD =GbxeBPsuQYTNgOJRVwFKoUnmIijyfL
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAt={'mode':GbxeBPsuQYTNgOJRVwFKoUnmIijyEL,'id':GbxeBPsuQYTNgOJRVwFKoUnmIijytE,'asis':GbxeBPsuQYTNgOJRVwFKoUnmIijyEf,'seasonList':'','title':GbxeBPsuQYTNgOJRVwFKoUnmIijyAE,'thumbnail':json.dumps(GbxeBPsuQYTNgOJRVwFKoUnmIijyEd,separators=(',',':')),'year':GbxeBPsuQYTNgOJRVwFKoUnmIijyEv,}
   if GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.get_settings_makebookmark()and GbxeBPsuQYTNgOJRVwFKoUnmIijyEf not in['HIGHLIGHT','']:
    GbxeBPsuQYTNgOJRVwFKoUnmIijyEz={'videoid':GbxeBPsuQYTNgOJRVwFKoUnmIijytE,'vidtype':'movie' if GbxeBPsuQYTNgOJRVwFKoUnmIijyEf=='MOVIE' else 'tvshow','vtitle':GbxeBPsuQYTNgOJRVwFKoUnmIijyAE,'vsubtitle':'',}
    GbxeBPsuQYTNgOJRVwFKoUnmIijyEl=json.dumps(GbxeBPsuQYTNgOJRVwFKoUnmIijyEz)
    GbxeBPsuQYTNgOJRVwFKoUnmIijyEl=urllib.parse.quote(GbxeBPsuQYTNgOJRVwFKoUnmIijyEl)
    GbxeBPsuQYTNgOJRVwFKoUnmIijyEc='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(GbxeBPsuQYTNgOJRVwFKoUnmIijyEl)
    GbxeBPsuQYTNgOJRVwFKoUnmIijyEk=[('(통합) 찜 영상에 추가',GbxeBPsuQYTNgOJRVwFKoUnmIijyEc)]
   else:
    GbxeBPsuQYTNgOJRVwFKoUnmIijyEk=GbxeBPsuQYTNgOJRVwFKoUnmIijyfh
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.add_dir(GbxeBPsuQYTNgOJRVwFKoUnmIijyAE,sublabel=GbxeBPsuQYTNgOJRVwFKoUnmIijyES,img=GbxeBPsuQYTNgOJRVwFKoUnmIijyEd,infoLabels=GbxeBPsuQYTNgOJRVwFKoUnmIijyEr,isFolder=GbxeBPsuQYTNgOJRVwFKoUnmIijyAD,params=GbxeBPsuQYTNgOJRVwFKoUnmIijyAt,ContextMenu=GbxeBPsuQYTNgOJRVwFKoUnmIijyEk)
  if GbxeBPsuQYTNgOJRVwFKoUnmIijyEM:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAt={}
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAt['mode'] ='LOCAL_SEARCH'
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAt['search_key']=GbxeBPsuQYTNgOJRVwFKoUnmIijydH
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAt['page'] =GbxeBPsuQYTNgOJRVwFKoUnmIijytA(GbxeBPsuQYTNgOJRVwFKoUnmIijyEX+1)
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAE='[B]%s >>[/B]'%'다음 페이지'
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEq=GbxeBPsuQYTNgOJRVwFKoUnmIijytA(GbxeBPsuQYTNgOJRVwFKoUnmIijyEX+1)
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAf=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.add_dir(GbxeBPsuQYTNgOJRVwFKoUnmIijyAE,sublabel=GbxeBPsuQYTNgOJRVwFKoUnmIijyEq,img=GbxeBPsuQYTNgOJRVwFKoUnmIijyAf,infoLabels=GbxeBPsuQYTNgOJRVwFKoUnmIijyfh,isFolder=GbxeBPsuQYTNgOJRVwFKoUnmIijyfz,params=GbxeBPsuQYTNgOJRVwFKoUnmIijyAt)
  xbmcplugin.setContent(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf._addon_handle,'movies')
  xbmcplugin.endOfDirectory(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf._addon_handle,cacheToDisc=GbxeBPsuQYTNgOJRVwFKoUnmIijyfz)
  if args.get('historyyn')=='Y':GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.Save_Searched_List(GbxeBPsuQYTNgOJRVwFKoUnmIijydH)
 def Load_List_File(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf,GbxeBPsuQYTNgOJRVwFKoUnmIijydD): 
  try:
   if GbxeBPsuQYTNgOJRVwFKoUnmIijydD=='search':
    GbxeBPsuQYTNgOJRVwFKoUnmIijydC=GbxeBPsuQYTNgOJRVwFKoUnmIijyrd
   elif GbxeBPsuQYTNgOJRVwFKoUnmIijydD in['tvshow','movie']:
    GbxeBPsuQYTNgOJRVwFKoUnmIijydC=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%GbxeBPsuQYTNgOJRVwFKoUnmIijydD))
   else:
    return[]
   fp=GbxeBPsuQYTNgOJRVwFKoUnmIijyfq(GbxeBPsuQYTNgOJRVwFKoUnmIijydC,'r',-1,'utf-8')
   GbxeBPsuQYTNgOJRVwFKoUnmIijydS=fp.readlines()
   fp.close()
  except:
   GbxeBPsuQYTNgOJRVwFKoUnmIijydS=[]
  return GbxeBPsuQYTNgOJRVwFKoUnmIijydS
 def Save_Watched_List(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf,GbxeBPsuQYTNgOJRVwFKoUnmIijydD,GbxeBPsuQYTNgOJRVwFKoUnmIijyrW):
  try:
   GbxeBPsuQYTNgOJRVwFKoUnmIijydv=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%GbxeBPsuQYTNgOJRVwFKoUnmIijydD))
   GbxeBPsuQYTNgOJRVwFKoUnmIijydp=GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.Load_List_File(GbxeBPsuQYTNgOJRVwFKoUnmIijydD) 
   fp=GbxeBPsuQYTNgOJRVwFKoUnmIijyfq(GbxeBPsuQYTNgOJRVwFKoUnmIijydv,'w',-1,'utf-8')
   GbxeBPsuQYTNgOJRVwFKoUnmIijydh=urllib.parse.urlencode(GbxeBPsuQYTNgOJRVwFKoUnmIijyrW)
   GbxeBPsuQYTNgOJRVwFKoUnmIijydh=GbxeBPsuQYTNgOJRVwFKoUnmIijydh+'\n'
   fp.write(GbxeBPsuQYTNgOJRVwFKoUnmIijydh)
   GbxeBPsuQYTNgOJRVwFKoUnmIijydL=0
   for GbxeBPsuQYTNgOJRVwFKoUnmIijydz in GbxeBPsuQYTNgOJRVwFKoUnmIijydp:
    GbxeBPsuQYTNgOJRVwFKoUnmIijydl=GbxeBPsuQYTNgOJRVwFKoUnmIijyfc(urllib.parse.parse_qsl(GbxeBPsuQYTNgOJRVwFKoUnmIijydz))
    GbxeBPsuQYTNgOJRVwFKoUnmIijydc=GbxeBPsuQYTNgOJRVwFKoUnmIijyrW.get('code').strip()
    GbxeBPsuQYTNgOJRVwFKoUnmIijydk=GbxeBPsuQYTNgOJRVwFKoUnmIijydl.get('code').strip()
    if GbxeBPsuQYTNgOJRVwFKoUnmIijydc!=GbxeBPsuQYTNgOJRVwFKoUnmIijydk:
     fp.write(GbxeBPsuQYTNgOJRVwFKoUnmIijydz)
     GbxeBPsuQYTNgOJRVwFKoUnmIijydL+=1
     if GbxeBPsuQYTNgOJRVwFKoUnmIijydL>=50:break
   fp.close()
  except:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyfh
 def Save_Searched_List(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf,GbxeBPsuQYTNgOJRVwFKoUnmIijydH):
  try:
   GbxeBPsuQYTNgOJRVwFKoUnmIijydH=GbxeBPsuQYTNgOJRVwFKoUnmIijydH.strip()
   GbxeBPsuQYTNgOJRVwFKoUnmIijydp=GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.Load_List_File('search') 
   fp=GbxeBPsuQYTNgOJRVwFKoUnmIijyfq(GbxeBPsuQYTNgOJRVwFKoUnmIijyrd,'w',-1,'utf-8')
   fp.write(GbxeBPsuQYTNgOJRVwFKoUnmIijydH+'\n')
   GbxeBPsuQYTNgOJRVwFKoUnmIijydL=0
   for GbxeBPsuQYTNgOJRVwFKoUnmIijydz in GbxeBPsuQYTNgOJRVwFKoUnmIijydp:
    GbxeBPsuQYTNgOJRVwFKoUnmIijydz=GbxeBPsuQYTNgOJRVwFKoUnmIijydz.strip()
    if GbxeBPsuQYTNgOJRVwFKoUnmIijydH!=GbxeBPsuQYTNgOJRVwFKoUnmIijydz:
     fp.write(GbxeBPsuQYTNgOJRVwFKoUnmIijydz+'\n')
     GbxeBPsuQYTNgOJRVwFKoUnmIijydL+=1
     if GbxeBPsuQYTNgOJRVwFKoUnmIijydL>=50:break
   fp.close()
  except:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyfh
 def dp_Search_History(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf,args):
  GbxeBPsuQYTNgOJRVwFKoUnmIijydq=GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.Load_List_File('search')
  for GbxeBPsuQYTNgOJRVwFKoUnmIijyfr in GbxeBPsuQYTNgOJRVwFKoUnmIijydq:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyfr=GbxeBPsuQYTNgOJRVwFKoUnmIijyfr.strip()
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAt={'mode':'LOCAL_SEARCH','search_key':GbxeBPsuQYTNgOJRVwFKoUnmIijyfr,'page':'1','historyyn':'Y',}
   GbxeBPsuQYTNgOJRVwFKoUnmIijyfA={'mode':'SEARCH_REMOVE','stype':'ONE','skey':GbxeBPsuQYTNgOJRVwFKoUnmIijyfr,}
   GbxeBPsuQYTNgOJRVwFKoUnmIijyfE=urllib.parse.urlencode(GbxeBPsuQYTNgOJRVwFKoUnmIijyfA)
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEk=[('선택된 검색어 ( %s ) 삭제'%(GbxeBPsuQYTNgOJRVwFKoUnmIijyfr),'RunPlugin(plugin://plugin.video.coupangm/?%s)'%(GbxeBPsuQYTNgOJRVwFKoUnmIijyfE))]
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.add_dir(GbxeBPsuQYTNgOJRVwFKoUnmIijyfr,sublabel='',img=GbxeBPsuQYTNgOJRVwFKoUnmIijyfh,infoLabels=GbxeBPsuQYTNgOJRVwFKoUnmIijyfh,isFolder=GbxeBPsuQYTNgOJRVwFKoUnmIijyfz,params=GbxeBPsuQYTNgOJRVwFKoUnmIijyAt,ContextMenu=GbxeBPsuQYTNgOJRVwFKoUnmIijyEk)
  GbxeBPsuQYTNgOJRVwFKoUnmIijyEr={'plot':'검색목록 전체를 삭제합니다.'}
  GbxeBPsuQYTNgOJRVwFKoUnmIijyAE='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  GbxeBPsuQYTNgOJRVwFKoUnmIijyAt={'mode':'SEARCH_REMOVE','stype':'ALL','skey':'-',}
  GbxeBPsuQYTNgOJRVwFKoUnmIijyAf=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.add_dir(GbxeBPsuQYTNgOJRVwFKoUnmIijyAE,sublabel='',img=GbxeBPsuQYTNgOJRVwFKoUnmIijyAf,infoLabels=GbxeBPsuQYTNgOJRVwFKoUnmIijyEr,isFolder=GbxeBPsuQYTNgOJRVwFKoUnmIijyfL,params=GbxeBPsuQYTNgOJRVwFKoUnmIijyAt,isLink=GbxeBPsuQYTNgOJRVwFKoUnmIijyfz)
  xbmcplugin.endOfDirectory(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf._addon_handle,cacheToDisc=GbxeBPsuQYTNgOJRVwFKoUnmIijyfL)
 def dp_Listfile_Delete(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf,args):
  GbxeBPsuQYTNgOJRVwFKoUnmIijydD=args.get('stype')
  GbxeBPsuQYTNgOJRVwFKoUnmIijyfa =args.get('skey')
  GbxeBPsuQYTNgOJRVwFKoUnmIijyrX=xbmcgui.Dialog()
  if GbxeBPsuQYTNgOJRVwFKoUnmIijydD=='ALL':
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAX=GbxeBPsuQYTNgOJRVwFKoUnmIijyrX.yesno(__language__(30911).encode('utf8'),__language__(30906).encode('utf8'))
  elif GbxeBPsuQYTNgOJRVwFKoUnmIijydD=='ONE':
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAX=GbxeBPsuQYTNgOJRVwFKoUnmIijyrX.yesno(__language__(30912).encode('utf8'),__language__(30906).encode('utf8'))
  elif GbxeBPsuQYTNgOJRVwFKoUnmIijydD in['tvshow','movie']:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAX=GbxeBPsuQYTNgOJRVwFKoUnmIijyrX.yesno(__language__(30913).encode('utf8'),__language__(30906).encode('utf8'))
  if GbxeBPsuQYTNgOJRVwFKoUnmIijyAX==GbxeBPsuQYTNgOJRVwFKoUnmIijyfL:sys.exit()
  GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.Delete_List_File(GbxeBPsuQYTNgOJRVwFKoUnmIijydD,skey=GbxeBPsuQYTNgOJRVwFKoUnmIijyfa)
  xbmc.executebuiltin("Container.Refresh")
 def Delete_List_File(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf,GbxeBPsuQYTNgOJRVwFKoUnmIijydD,skey='-'):
  if GbxeBPsuQYTNgOJRVwFKoUnmIijydD=='ALL':
   try:
    GbxeBPsuQYTNgOJRVwFKoUnmIijydC=GbxeBPsuQYTNgOJRVwFKoUnmIijyrd
    fp=GbxeBPsuQYTNgOJRVwFKoUnmIijyfq(GbxeBPsuQYTNgOJRVwFKoUnmIijydC,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    GbxeBPsuQYTNgOJRVwFKoUnmIijyfh
  elif GbxeBPsuQYTNgOJRVwFKoUnmIijydD=='ONE':
   try:
    GbxeBPsuQYTNgOJRVwFKoUnmIijydC=GbxeBPsuQYTNgOJRVwFKoUnmIijyrd
    GbxeBPsuQYTNgOJRVwFKoUnmIijydp=GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.Load_List_File('search') 
    fp=GbxeBPsuQYTNgOJRVwFKoUnmIijyfq(GbxeBPsuQYTNgOJRVwFKoUnmIijydC,'w',-1,'utf-8')
    for GbxeBPsuQYTNgOJRVwFKoUnmIijydz in GbxeBPsuQYTNgOJRVwFKoUnmIijydp:
     if skey!=GbxeBPsuQYTNgOJRVwFKoUnmIijydz.strip():
      fp.write(GbxeBPsuQYTNgOJRVwFKoUnmIijydz)
    fp.close()
   except:
    GbxeBPsuQYTNgOJRVwFKoUnmIijyfh
  elif GbxeBPsuQYTNgOJRVwFKoUnmIijydD in['tvshow','movie']:
   try:
    GbxeBPsuQYTNgOJRVwFKoUnmIijydC=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%GbxeBPsuQYTNgOJRVwFKoUnmIijydD))
    fp=GbxeBPsuQYTNgOJRVwFKoUnmIijyfq(GbxeBPsuQYTNgOJRVwFKoUnmIijydC,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    GbxeBPsuQYTNgOJRVwFKoUnmIijyfh
 def dp_Watch_List(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf,args):
  GbxeBPsuQYTNgOJRVwFKoUnmIijydD =args.get('stype')
  if GbxeBPsuQYTNgOJRVwFKoUnmIijydD in['',GbxeBPsuQYTNgOJRVwFKoUnmIijyfh]:
   for GbxeBPsuQYTNgOJRVwFKoUnmIijyfd in GbxeBPsuQYTNgOJRVwFKoUnmIijyra:
    GbxeBPsuQYTNgOJRVwFKoUnmIijyAE=GbxeBPsuQYTNgOJRVwFKoUnmIijyfd.get('title')
    GbxeBPsuQYTNgOJRVwFKoUnmIijyAt={'mode':GbxeBPsuQYTNgOJRVwFKoUnmIijyfd.get('mode'),'stype':GbxeBPsuQYTNgOJRVwFKoUnmIijyfd.get('stype'),}
    GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.add_dir(GbxeBPsuQYTNgOJRVwFKoUnmIijyAE,sublabel='',img='',infoLabels=GbxeBPsuQYTNgOJRVwFKoUnmIijyfh,isFolder=GbxeBPsuQYTNgOJRVwFKoUnmIijyfz,params=GbxeBPsuQYTNgOJRVwFKoUnmIijyAt)
   xbmcplugin.endOfDirectory(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf._addon_handle)
  else:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyft=GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.Load_List_File(GbxeBPsuQYTNgOJRVwFKoUnmIijydD)
   for GbxeBPsuQYTNgOJRVwFKoUnmIijyfD in GbxeBPsuQYTNgOJRVwFKoUnmIijyft:
    GbxeBPsuQYTNgOJRVwFKoUnmIijyfW=GbxeBPsuQYTNgOJRVwFKoUnmIijyfc(urllib.parse.parse_qsl(GbxeBPsuQYTNgOJRVwFKoUnmIijyfD))
    GbxeBPsuQYTNgOJRVwFKoUnmIijyav =GbxeBPsuQYTNgOJRVwFKoUnmIijyfW.get('code').strip()
    GbxeBPsuQYTNgOJRVwFKoUnmIijyAE =GbxeBPsuQYTNgOJRVwFKoUnmIijyfW.get('title').strip()
    GbxeBPsuQYTNgOJRVwFKoUnmIijyEd =GbxeBPsuQYTNgOJRVwFKoUnmIijyfW.get('img').strip()
    GbxeBPsuQYTNgOJRVwFKoUnmIijyEf =GbxeBPsuQYTNgOJRVwFKoUnmIijyfW.get('asis').strip()
    try:
     GbxeBPsuQYTNgOJRVwFKoUnmIijyEd=GbxeBPsuQYTNgOJRVwFKoUnmIijyEd.replace('\'','\"')
     GbxeBPsuQYTNgOJRVwFKoUnmIijyEd=json.loads(GbxeBPsuQYTNgOJRVwFKoUnmIijyEd)
    except:
     GbxeBPsuQYTNgOJRVwFKoUnmIijyfh
    GbxeBPsuQYTNgOJRVwFKoUnmIijyEr={}
    GbxeBPsuQYTNgOJRVwFKoUnmIijyEr['plot']=GbxeBPsuQYTNgOJRVwFKoUnmIijyAE
    if GbxeBPsuQYTNgOJRVwFKoUnmIijydD=='movie':
     GbxeBPsuQYTNgOJRVwFKoUnmIijyEr['mediatype']='movie'
     GbxeBPsuQYTNgOJRVwFKoUnmIijyAt={'mode':'MOVIE','id':GbxeBPsuQYTNgOJRVwFKoUnmIijyav,'asis':GbxeBPsuQYTNgOJRVwFKoUnmIijyEf,'title':GbxeBPsuQYTNgOJRVwFKoUnmIijyAE,'thumbnail':GbxeBPsuQYTNgOJRVwFKoUnmIijyEd,}
     GbxeBPsuQYTNgOJRVwFKoUnmIijyAD=GbxeBPsuQYTNgOJRVwFKoUnmIijyfL
    else:
     GbxeBPsuQYTNgOJRVwFKoUnmIijyEr['mediatype']='episode'
     GbxeBPsuQYTNgOJRVwFKoUnmIijyAt={'mode':'SEASON_LIST','id':GbxeBPsuQYTNgOJRVwFKoUnmIijyav,'asis':GbxeBPsuQYTNgOJRVwFKoUnmIijyEf,'title':GbxeBPsuQYTNgOJRVwFKoUnmIijyAE,'thumbnail':json.dumps(GbxeBPsuQYTNgOJRVwFKoUnmIijyEd,separators=(',',':')),}
     GbxeBPsuQYTNgOJRVwFKoUnmIijyAD=GbxeBPsuQYTNgOJRVwFKoUnmIijyfz
    GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.add_dir(GbxeBPsuQYTNgOJRVwFKoUnmIijyAE,sublabel='',img=GbxeBPsuQYTNgOJRVwFKoUnmIijyEd,infoLabels=GbxeBPsuQYTNgOJRVwFKoUnmIijyEr,isFolder=GbxeBPsuQYTNgOJRVwFKoUnmIijyAD,params=GbxeBPsuQYTNgOJRVwFKoUnmIijyAt)
   GbxeBPsuQYTNgOJRVwFKoUnmIijyEr={'plot':'시청목록을 삭제합니다.'}
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAE='*** 시청목록 삭제 ***'
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAt={'mode':'MYVIEW_REMOVE','stype':GbxeBPsuQYTNgOJRVwFKoUnmIijydD,'skey':'-',}
   GbxeBPsuQYTNgOJRVwFKoUnmIijyAf=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.add_dir(GbxeBPsuQYTNgOJRVwFKoUnmIijyAE,sublabel='',img=GbxeBPsuQYTNgOJRVwFKoUnmIijyAf,infoLabels=GbxeBPsuQYTNgOJRVwFKoUnmIijyEr,isFolder=GbxeBPsuQYTNgOJRVwFKoUnmIijyfL,params=GbxeBPsuQYTNgOJRVwFKoUnmIijyAt,isLink=GbxeBPsuQYTNgOJRVwFKoUnmIijyfz)
   if GbxeBPsuQYTNgOJRVwFKoUnmIijydD=='movie':xbmcplugin.setContent(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf._addon_handle,'movies')
   else:xbmcplugin.setContent(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf._addon_handle,cacheToDisc=GbxeBPsuQYTNgOJRVwFKoUnmIijyfL)
 def dp_Set_Bookmark(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf,args):
  GbxeBPsuQYTNgOJRVwFKoUnmIijyfH=urllib.parse.unquote(args.get('bm_param'))
  GbxeBPsuQYTNgOJRVwFKoUnmIijyfH=json.loads(GbxeBPsuQYTNgOJRVwFKoUnmIijyfH)
  GbxeBPsuQYTNgOJRVwFKoUnmIijyfX =GbxeBPsuQYTNgOJRVwFKoUnmIijyfH.get('videoid')
  GbxeBPsuQYTNgOJRVwFKoUnmIijyfM =GbxeBPsuQYTNgOJRVwFKoUnmIijyfH.get('vidtype')
  GbxeBPsuQYTNgOJRVwFKoUnmIijyfC =GbxeBPsuQYTNgOJRVwFKoUnmIijyfH.get('vtitle')
  GbxeBPsuQYTNgOJRVwFKoUnmIijyrX=xbmcgui.Dialog()
  GbxeBPsuQYTNgOJRVwFKoUnmIijyAX=GbxeBPsuQYTNgOJRVwFKoUnmIijyrX.yesno(__language__(30914).encode('utf8'),GbxeBPsuQYTNgOJRVwFKoUnmIijyfC+' \n\n'+__language__(30915))
  if GbxeBPsuQYTNgOJRVwFKoUnmIijyAX==GbxeBPsuQYTNgOJRVwFKoUnmIijyfL:return
  GbxeBPsuQYTNgOJRVwFKoUnmIijyfS=GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CoupangObj.GetBookmarkInfo(GbxeBPsuQYTNgOJRVwFKoUnmIijyfX,GbxeBPsuQYTNgOJRVwFKoUnmIijyfM)
  GbxeBPsuQYTNgOJRVwFKoUnmIijyfv=json.dumps(GbxeBPsuQYTNgOJRVwFKoUnmIijyfS)
  GbxeBPsuQYTNgOJRVwFKoUnmIijyfv=urllib.parse.quote(GbxeBPsuQYTNgOJRVwFKoUnmIijyfv)
  GbxeBPsuQYTNgOJRVwFKoUnmIijyEc ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(GbxeBPsuQYTNgOJRVwFKoUnmIijyfv)
  xbmc.executebuiltin(GbxeBPsuQYTNgOJRVwFKoUnmIijyEc)
 def coupang_main(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf):
  GbxeBPsuQYTNgOJRVwFKoUnmIijyEL=GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.main_params.get('mode',GbxeBPsuQYTNgOJRVwFKoUnmIijyfh)
  if GbxeBPsuQYTNgOJRVwFKoUnmIijyEL=='LOGOUT':
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.CP_logout()
   return
  GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.option_check()
  if GbxeBPsuQYTNgOJRVwFKoUnmIijyEL is GbxeBPsuQYTNgOJRVwFKoUnmIijyfh:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.dp_Main_List(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.main_params)
  elif GbxeBPsuQYTNgOJRVwFKoUnmIijyEL=='CATEGORY_GROUPLIST':
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.dp_Category_GroupList(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.main_params)
  elif GbxeBPsuQYTNgOJRVwFKoUnmIijyEL=='THEME_GROUPLIST':
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.dp_Theme_GroupList(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.main_params)
  elif GbxeBPsuQYTNgOJRVwFKoUnmIijyEL=='EVENT_GROUPLIST':
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.dp_Event_GroupList(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.main_params)
  elif GbxeBPsuQYTNgOJRVwFKoUnmIijyEL=='EVENT_GAMELIST':
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.dp_Event_GameList(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.main_params)
  elif GbxeBPsuQYTNgOJRVwFKoUnmIijyEL=='EVENT_LIST':
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.dp_Event_List(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.main_params)
  elif GbxeBPsuQYTNgOJRVwFKoUnmIijyEL=='CATEGORY_LIST':
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.dp_Category_List(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.main_params)
  elif GbxeBPsuQYTNgOJRVwFKoUnmIijyEL=='SEASON_LIST':
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.dp_Season_List(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.main_params)
  elif GbxeBPsuQYTNgOJRVwFKoUnmIijyEL=='EPISODE_LIST':
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.dp_Episode_List(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.main_params)
  elif GbxeBPsuQYTNgOJRVwFKoUnmIijyEL=='TEST':
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.dp_Test(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.main_params)
  elif GbxeBPsuQYTNgOJRVwFKoUnmIijyEL in['MOVIE','VOD','HIGHLIGHT','LIVE']:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.play_VIDEO(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.main_params)
  elif GbxeBPsuQYTNgOJRVwFKoUnmIijyEL=='WATCH':
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.dp_Watch_List(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.main_params)
  elif GbxeBPsuQYTNgOJRVwFKoUnmIijyEL=='LOCAL_SEARCH':
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.dp_Search_List(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.main_params)
  elif GbxeBPsuQYTNgOJRVwFKoUnmIijyEL=='SEARCH_HISTORY':
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.dp_Search_History(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.main_params)
  elif GbxeBPsuQYTNgOJRVwFKoUnmIijyEL in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.dp_Listfile_Delete(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.main_params)
  elif GbxeBPsuQYTNgOJRVwFKoUnmIijyEL in['TOTAL_SEARCH','TOTAL_HISTORY']:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.dp_Global_Search(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.main_params)
  elif GbxeBPsuQYTNgOJRVwFKoUnmIijyEL=='MENU_BOOKMARK':
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.dp_Bookmark_Menu(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.main_params)
  elif GbxeBPsuQYTNgOJRVwFKoUnmIijyEL=='SET_BOOKMARK':
   GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.dp_Set_Bookmark(GbxeBPsuQYTNgOJRVwFKoUnmIijyrf.main_params)
  else:
   GbxeBPsuQYTNgOJRVwFKoUnmIijyfh
# Created by pyminifier (https://github.com/liftoff/pyminifier)
