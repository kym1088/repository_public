__author__="NightRain"
waxtCQihyRnKgHEYrJMbGIBXpmceVl=object
waxtCQihyRnKgHEYrJMbGIBXpmceVT=None
waxtCQihyRnKgHEYrJMbGIBXpmceVU=False
waxtCQihyRnKgHEYrJMbGIBXpmceVu=True
waxtCQihyRnKgHEYrJMbGIBXpmceVs=type
waxtCQihyRnKgHEYrJMbGIBXpmceVN=dict
waxtCQihyRnKgHEYrJMbGIBXpmceVv=int
waxtCQihyRnKgHEYrJMbGIBXpmceVf=open
waxtCQihyRnKgHEYrJMbGIBXpmceFj=Exception
waxtCQihyRnKgHEYrJMbGIBXpmceFk=str
waxtCQihyRnKgHEYrJMbGIBXpmceFz=id
waxtCQihyRnKgHEYrJMbGIBXpmceFA=len
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import inputstreamhelper
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
waxtCQihyRnKgHEYrJMbGIBXpmcejz=[{'title':'홈   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'ALL'},{'title':'TV   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'MOVIES'},{'title':'교육 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'EDUCATION'},{'title':'생중계','mode':'EVENT_GROUPLIST','vType':'LIVE'},{'title':'TV   (테마별)','mode':'THEME_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (테마별)','mode':'THEME_GROUPLIST','vType':'MOVIES'},{'title':'교육 (테마별)','mode':'THEME_GROUPLIST','vType':'EDUCATION'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},{'title':'(쿠팡) 검색','mode':'LOCAL_SEARCH','icon':'search.png'},{'title':'(쿠팡) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
waxtCQihyRnKgHEYrJMbGIBXpmcejA=[{'title':'시리즈 시청내역','mode':'WATCH','stype':'tvshow'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},]
waxtCQihyRnKgHEYrJMbGIBXpmcejP=xbmcvfs.translatePath(os.path.join(__profile__,'coupang_searched.txt'))
from coupangCore import*
class waxtCQihyRnKgHEYrJMbGIBXpmcejk(waxtCQihyRnKgHEYrJMbGIBXpmceVl):
 def __init__(waxtCQihyRnKgHEYrJMbGIBXpmcejV,waxtCQihyRnKgHEYrJMbGIBXpmcejF,waxtCQihyRnKgHEYrJMbGIBXpmcejq,waxtCQihyRnKgHEYrJMbGIBXpmcejO):
  waxtCQihyRnKgHEYrJMbGIBXpmcejV._addon_url =waxtCQihyRnKgHEYrJMbGIBXpmcejF
  waxtCQihyRnKgHEYrJMbGIBXpmcejV._addon_handle=waxtCQihyRnKgHEYrJMbGIBXpmcejq
  waxtCQihyRnKgHEYrJMbGIBXpmcejV.main_params =waxtCQihyRnKgHEYrJMbGIBXpmcejO
  waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj =fJWvkClwdThKOerVHgRzqMpbYsnPSm() 
  waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.CP_COOKIE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_cookies.json'))
  waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.CP_DEVICE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_device.json'))
 def addon_noti(waxtCQihyRnKgHEYrJMbGIBXpmcejV,sting):
  try:
   waxtCQihyRnKgHEYrJMbGIBXpmcejL=xbmcgui.Dialog()
   waxtCQihyRnKgHEYrJMbGIBXpmcejL.notification(__addonname__,sting)
  except:
   waxtCQihyRnKgHEYrJMbGIBXpmceVT
 def addon_log(waxtCQihyRnKgHEYrJMbGIBXpmcejV,string):
  try:
   waxtCQihyRnKgHEYrJMbGIBXpmcejS=string.encode('utf-8','ignore')
  except:
   waxtCQihyRnKgHEYrJMbGIBXpmcejS='addonException: addon_log'
  waxtCQihyRnKgHEYrJMbGIBXpmcejW=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,waxtCQihyRnKgHEYrJMbGIBXpmcejS),level=waxtCQihyRnKgHEYrJMbGIBXpmcejW)
 def get_keyboard_input(waxtCQihyRnKgHEYrJMbGIBXpmcejV,waxtCQihyRnKgHEYrJMbGIBXpmcekz):
  waxtCQihyRnKgHEYrJMbGIBXpmcejd=waxtCQihyRnKgHEYrJMbGIBXpmceVT
  kb=xbmc.Keyboard()
  kb.setHeading(waxtCQihyRnKgHEYrJMbGIBXpmcekz)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   waxtCQihyRnKgHEYrJMbGIBXpmcejd=kb.getText()
  return waxtCQihyRnKgHEYrJMbGIBXpmcejd
 def get_settings_account(waxtCQihyRnKgHEYrJMbGIBXpmcejV):
  waxtCQihyRnKgHEYrJMbGIBXpmcejD=__addon__.getSetting('id')
  waxtCQihyRnKgHEYrJMbGIBXpmcejl=__addon__.getSetting('pw')
  waxtCQihyRnKgHEYrJMbGIBXpmcejT=__addon__.getSetting('profile')
  return(waxtCQihyRnKgHEYrJMbGIBXpmcejD,waxtCQihyRnKgHEYrJMbGIBXpmcejl,waxtCQihyRnKgHEYrJMbGIBXpmcejT)
 def get_settings_exclusion21(waxtCQihyRnKgHEYrJMbGIBXpmcejV):
  waxtCQihyRnKgHEYrJMbGIBXpmcejU =__addon__.getSetting('exclusion21')
  if waxtCQihyRnKgHEYrJMbGIBXpmcejU=='false':
   return waxtCQihyRnKgHEYrJMbGIBXpmceVU
  else:
   return waxtCQihyRnKgHEYrJMbGIBXpmceVu
 def get_settings_totalsearch(waxtCQihyRnKgHEYrJMbGIBXpmcejV):
  waxtCQihyRnKgHEYrJMbGIBXpmceju =waxtCQihyRnKgHEYrJMbGIBXpmceVu if __addon__.getSetting('local_search')=='true' else waxtCQihyRnKgHEYrJMbGIBXpmceVU
  waxtCQihyRnKgHEYrJMbGIBXpmcejs=waxtCQihyRnKgHEYrJMbGIBXpmceVu if __addon__.getSetting('local_history')=='true' else waxtCQihyRnKgHEYrJMbGIBXpmceVU
  waxtCQihyRnKgHEYrJMbGIBXpmcejN =waxtCQihyRnKgHEYrJMbGIBXpmceVu if __addon__.getSetting('total_search')=='true' else waxtCQihyRnKgHEYrJMbGIBXpmceVU
  waxtCQihyRnKgHEYrJMbGIBXpmcejv=waxtCQihyRnKgHEYrJMbGIBXpmceVu if __addon__.getSetting('total_history')=='true' else waxtCQihyRnKgHEYrJMbGIBXpmceVU
  waxtCQihyRnKgHEYrJMbGIBXpmcejf=waxtCQihyRnKgHEYrJMbGIBXpmceVu if __addon__.getSetting('menu_bookmark')=='true' else waxtCQihyRnKgHEYrJMbGIBXpmceVU
  return(waxtCQihyRnKgHEYrJMbGIBXpmceju,waxtCQihyRnKgHEYrJMbGIBXpmcejs,waxtCQihyRnKgHEYrJMbGIBXpmcejN,waxtCQihyRnKgHEYrJMbGIBXpmcejv,waxtCQihyRnKgHEYrJMbGIBXpmcejf)
 def get_settings_makebookmark(waxtCQihyRnKgHEYrJMbGIBXpmcejV):
  return waxtCQihyRnKgHEYrJMbGIBXpmceVu if __addon__.getSetting('make_bookmark')=='true' else waxtCQihyRnKgHEYrJMbGIBXpmceVU
 def add_dir(waxtCQihyRnKgHEYrJMbGIBXpmcejV,label,sublabel='',img='',infoLabels=waxtCQihyRnKgHEYrJMbGIBXpmceVT,isFolder=waxtCQihyRnKgHEYrJMbGIBXpmceVu,params='',isLink=waxtCQihyRnKgHEYrJMbGIBXpmceVU,ContextMenu=waxtCQihyRnKgHEYrJMbGIBXpmceVT):
  waxtCQihyRnKgHEYrJMbGIBXpmcekj='%s?%s'%(waxtCQihyRnKgHEYrJMbGIBXpmcejV._addon_url,urllib.parse.urlencode(params))
  if sublabel:waxtCQihyRnKgHEYrJMbGIBXpmcekz='%s < %s >'%(label,sublabel)
  else: waxtCQihyRnKgHEYrJMbGIBXpmcekz=label
  if not img:img='DefaultFolder.png'
  waxtCQihyRnKgHEYrJMbGIBXpmcekA=xbmcgui.ListItem(waxtCQihyRnKgHEYrJMbGIBXpmcekz)
  if waxtCQihyRnKgHEYrJMbGIBXpmceVs(img)==waxtCQihyRnKgHEYrJMbGIBXpmceVN:
   waxtCQihyRnKgHEYrJMbGIBXpmcekA.setArt(img)
  else:
   waxtCQihyRnKgHEYrJMbGIBXpmcekA.setArt({'thumb':img,'poster':img})
  if infoLabels:waxtCQihyRnKgHEYrJMbGIBXpmcekA.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   waxtCQihyRnKgHEYrJMbGIBXpmcekA.setProperty('IsPlayable','true')
  if ContextMenu:waxtCQihyRnKgHEYrJMbGIBXpmcekA.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(waxtCQihyRnKgHEYrJMbGIBXpmcejV._addon_handle,waxtCQihyRnKgHEYrJMbGIBXpmcekj,waxtCQihyRnKgHEYrJMbGIBXpmcekA,isFolder)
 def dp_Main_List(waxtCQihyRnKgHEYrJMbGIBXpmcejV,args):
  (waxtCQihyRnKgHEYrJMbGIBXpmceju,waxtCQihyRnKgHEYrJMbGIBXpmcejs,waxtCQihyRnKgHEYrJMbGIBXpmcejN,waxtCQihyRnKgHEYrJMbGIBXpmcejv,waxtCQihyRnKgHEYrJMbGIBXpmcejf)=waxtCQihyRnKgHEYrJMbGIBXpmcejV.get_settings_totalsearch()
  for waxtCQihyRnKgHEYrJMbGIBXpmcekP in waxtCQihyRnKgHEYrJMbGIBXpmcejz:
   waxtCQihyRnKgHEYrJMbGIBXpmcekz=waxtCQihyRnKgHEYrJMbGIBXpmcekP.get('title')
   waxtCQihyRnKgHEYrJMbGIBXpmcekV=''
   if waxtCQihyRnKgHEYrJMbGIBXpmcekP.get('mode')=='LOCAL_SEARCH' and waxtCQihyRnKgHEYrJMbGIBXpmceju ==waxtCQihyRnKgHEYrJMbGIBXpmceVU:continue
   elif waxtCQihyRnKgHEYrJMbGIBXpmcekP.get('mode')=='SEARCH_HISTORY' and waxtCQihyRnKgHEYrJMbGIBXpmcejs==waxtCQihyRnKgHEYrJMbGIBXpmceVU:continue
   elif waxtCQihyRnKgHEYrJMbGIBXpmcekP.get('mode')=='TOTAL_SEARCH' and waxtCQihyRnKgHEYrJMbGIBXpmcejN ==waxtCQihyRnKgHEYrJMbGIBXpmceVU:continue
   elif waxtCQihyRnKgHEYrJMbGIBXpmcekP.get('mode')=='TOTAL_HISTORY' and waxtCQihyRnKgHEYrJMbGIBXpmcejv==waxtCQihyRnKgHEYrJMbGIBXpmceVU:continue
   elif waxtCQihyRnKgHEYrJMbGIBXpmcekP.get('mode')=='MENU_BOOKMARK' and waxtCQihyRnKgHEYrJMbGIBXpmcejf==waxtCQihyRnKgHEYrJMbGIBXpmceVU:continue
   waxtCQihyRnKgHEYrJMbGIBXpmcekF={'mode':waxtCQihyRnKgHEYrJMbGIBXpmcekP.get('mode'),'vType':waxtCQihyRnKgHEYrJMbGIBXpmcekP.get('vType'),'page':'1',}
   if waxtCQihyRnKgHEYrJMbGIBXpmcekP.get('mode')=='LOCAL_SEARCH':waxtCQihyRnKgHEYrJMbGIBXpmcekF['historyyn']='Y' 
   if waxtCQihyRnKgHEYrJMbGIBXpmcekP.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    waxtCQihyRnKgHEYrJMbGIBXpmcekq=waxtCQihyRnKgHEYrJMbGIBXpmceVU
    waxtCQihyRnKgHEYrJMbGIBXpmcekO =waxtCQihyRnKgHEYrJMbGIBXpmceVu
   else:
    waxtCQihyRnKgHEYrJMbGIBXpmcekq=waxtCQihyRnKgHEYrJMbGIBXpmceVu
    waxtCQihyRnKgHEYrJMbGIBXpmcekO =waxtCQihyRnKgHEYrJMbGIBXpmceVU
   if 'icon' in waxtCQihyRnKgHEYrJMbGIBXpmcekP:waxtCQihyRnKgHEYrJMbGIBXpmcekV=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',waxtCQihyRnKgHEYrJMbGIBXpmcekP.get('icon')) 
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.add_dir(waxtCQihyRnKgHEYrJMbGIBXpmcekz,sublabel='',img=waxtCQihyRnKgHEYrJMbGIBXpmcekV,infoLabels=waxtCQihyRnKgHEYrJMbGIBXpmceVT,isFolder=waxtCQihyRnKgHEYrJMbGIBXpmcekq,params=waxtCQihyRnKgHEYrJMbGIBXpmcekF,isLink=waxtCQihyRnKgHEYrJMbGIBXpmcekO)
  xbmcplugin.endOfDirectory(waxtCQihyRnKgHEYrJMbGIBXpmcejV._addon_handle)
 def dp_Test(waxtCQihyRnKgHEYrJMbGIBXpmcejV,args):
  waxtCQihyRnKgHEYrJMbGIBXpmcejV.addon_noti('test')
 def CP_logout(waxtCQihyRnKgHEYrJMbGIBXpmcejV):
  waxtCQihyRnKgHEYrJMbGIBXpmcejL=xbmcgui.Dialog()
  waxtCQihyRnKgHEYrJMbGIBXpmcekL=waxtCQihyRnKgHEYrJMbGIBXpmcejL.yesno(__language__(30905).encode('utf8'),__language__(30906).encode('utf8'))
  if waxtCQihyRnKgHEYrJMbGIBXpmcekL==waxtCQihyRnKgHEYrJMbGIBXpmceVU:return 
  if os.path.isfile(waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.CP_COOKIE_FILENAME):os.remove(waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.CP_COOKIE_FILENAME)
  waxtCQihyRnKgHEYrJMbGIBXpmcejV.addon_noti(__language__(30904).encode('utf-8'))
 def option_check(waxtCQihyRnKgHEYrJMbGIBXpmcejV):
  (waxtCQihyRnKgHEYrJMbGIBXpmcejD,waxtCQihyRnKgHEYrJMbGIBXpmcejl,waxtCQihyRnKgHEYrJMbGIBXpmcejT)=waxtCQihyRnKgHEYrJMbGIBXpmcejV.get_settings_account()
  if waxtCQihyRnKgHEYrJMbGIBXpmcejD=='' or waxtCQihyRnKgHEYrJMbGIBXpmcejl=='':
   waxtCQihyRnKgHEYrJMbGIBXpmcejL=xbmcgui.Dialog()
   waxtCQihyRnKgHEYrJMbGIBXpmcekL=waxtCQihyRnKgHEYrJMbGIBXpmcejL.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if waxtCQihyRnKgHEYrJMbGIBXpmcekL==waxtCQihyRnKgHEYrJMbGIBXpmceVu:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if waxtCQihyRnKgHEYrJMbGIBXpmcejV.cookiefile_check()==waxtCQihyRnKgHEYrJMbGIBXpmceVU:
   if waxtCQihyRnKgHEYrJMbGIBXpmcejV.CP_login(waxtCQihyRnKgHEYrJMbGIBXpmcejD,waxtCQihyRnKgHEYrJMbGIBXpmcejl,waxtCQihyRnKgHEYrJMbGIBXpmcejT)==waxtCQihyRnKgHEYrJMbGIBXpmceVU:
    waxtCQihyRnKgHEYrJMbGIBXpmcejV.addon_noti(__language__(30903).encode('utf8'))
    sys.exit()
  else:
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.Get_CP_profile(waxtCQihyRnKgHEYrJMbGIBXpmcejT,limit_days=waxtCQihyRnKgHEYrJMbGIBXpmceVv(__addon__.getSetting('cache_ttl')),re_check=waxtCQihyRnKgHEYrJMbGIBXpmceVu)
 def cookiefile_check(waxtCQihyRnKgHEYrJMbGIBXpmcejV):
  waxtCQihyRnKgHEYrJMbGIBXpmcekW={}
  try: 
   fp=waxtCQihyRnKgHEYrJMbGIBXpmceVf(waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.CP_COOKIE_FILENAME,'r',-1,'utf-8')
   waxtCQihyRnKgHEYrJMbGIBXpmcekW= json.load(fp)
   fp.close()
  except waxtCQihyRnKgHEYrJMbGIBXpmceFj as exception:
   return waxtCQihyRnKgHEYrJMbGIBXpmceVU
  waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.CP=waxtCQihyRnKgHEYrJMbGIBXpmcekW
  (waxtCQihyRnKgHEYrJMbGIBXpmcejD,waxtCQihyRnKgHEYrJMbGIBXpmcejl,waxtCQihyRnKgHEYrJMbGIBXpmcejT)=waxtCQihyRnKgHEYrJMbGIBXpmcejV.get_settings_account()
  (waxtCQihyRnKgHEYrJMbGIBXpmcekd,waxtCQihyRnKgHEYrJMbGIBXpmcekD,waxtCQihyRnKgHEYrJMbGIBXpmcekl)=waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.Load_session_acount()
  if waxtCQihyRnKgHEYrJMbGIBXpmcejD!=waxtCQihyRnKgHEYrJMbGIBXpmcekd or waxtCQihyRnKgHEYrJMbGIBXpmcejl!=waxtCQihyRnKgHEYrJMbGIBXpmcekD or waxtCQihyRnKgHEYrJMbGIBXpmcejT!=waxtCQihyRnKgHEYrJMbGIBXpmceFk(waxtCQihyRnKgHEYrJMbGIBXpmcekl):
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.Init_CP()
   return waxtCQihyRnKgHEYrJMbGIBXpmceVU
  waxtCQihyRnKgHEYrJMbGIBXpmcekT =waxtCQihyRnKgHEYrJMbGIBXpmceVv(waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.Get_Now_Datetime().strftime('%Y%m%d'))
  waxtCQihyRnKgHEYrJMbGIBXpmcekU=waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.CP['SESSION']['limitdate']
  waxtCQihyRnKgHEYrJMbGIBXpmceku =waxtCQihyRnKgHEYrJMbGIBXpmceVv(re.sub('-','',waxtCQihyRnKgHEYrJMbGIBXpmcekU))
  if waxtCQihyRnKgHEYrJMbGIBXpmceku<waxtCQihyRnKgHEYrJMbGIBXpmcekT:
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.Init_CP()
   return waxtCQihyRnKgHEYrJMbGIBXpmceVU
  return waxtCQihyRnKgHEYrJMbGIBXpmceVu
 def CP_login(waxtCQihyRnKgHEYrJMbGIBXpmcejV,waxtCQihyRnKgHEYrJMbGIBXpmcejD,waxtCQihyRnKgHEYrJMbGIBXpmcejl,waxtCQihyRnKgHEYrJMbGIBXpmcejT):
  if waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.Get_CP_Login(waxtCQihyRnKgHEYrJMbGIBXpmcejD,waxtCQihyRnKgHEYrJMbGIBXpmcejl,waxtCQihyRnKgHEYrJMbGIBXpmcejT)==waxtCQihyRnKgHEYrJMbGIBXpmceVU:return waxtCQihyRnKgHEYrJMbGIBXpmceVU
  if waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.Get_CP_profile(waxtCQihyRnKgHEYrJMbGIBXpmcejT,limit_days=waxtCQihyRnKgHEYrJMbGIBXpmceVv(__addon__.getSetting('cache_ttl')),re_check=waxtCQihyRnKgHEYrJMbGIBXpmceVU)==waxtCQihyRnKgHEYrJMbGIBXpmceVU:return waxtCQihyRnKgHEYrJMbGIBXpmceVU
  return waxtCQihyRnKgHEYrJMbGIBXpmceVu
 def dp_Category_GroupList(waxtCQihyRnKgHEYrJMbGIBXpmcejV,args):
  waxtCQihyRnKgHEYrJMbGIBXpmceks =args.get('vType') 
  waxtCQihyRnKgHEYrJMbGIBXpmcekN=waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.Get_Category_GroupList(waxtCQihyRnKgHEYrJMbGIBXpmceks)
  for waxtCQihyRnKgHEYrJMbGIBXpmcekv in waxtCQihyRnKgHEYrJMbGIBXpmcekN:
   waxtCQihyRnKgHEYrJMbGIBXpmcekz =waxtCQihyRnKgHEYrJMbGIBXpmcekv.get('title')
   waxtCQihyRnKgHEYrJMbGIBXpmcekf=waxtCQihyRnKgHEYrJMbGIBXpmcekv.get('pre_title')
   if waxtCQihyRnKgHEYrJMbGIBXpmcejV.get_settings_exclusion21()==waxtCQihyRnKgHEYrJMbGIBXpmceVu and waxtCQihyRnKgHEYrJMbGIBXpmcekz=='성인':continue
   waxtCQihyRnKgHEYrJMbGIBXpmcezj={'mediatype':'tvshow','plot':waxtCQihyRnKgHEYrJMbGIBXpmcekf,}
   waxtCQihyRnKgHEYrJMbGIBXpmcekF={'mode':'CATEGORY_LIST','collectionId':waxtCQihyRnKgHEYrJMbGIBXpmcekv.get('collectionId'),'vType':waxtCQihyRnKgHEYrJMbGIBXpmcekv.get('category'),'page':'1',}
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.add_dir(waxtCQihyRnKgHEYrJMbGIBXpmcekz,sublabel='',img='',infoLabels=waxtCQihyRnKgHEYrJMbGIBXpmcezj,isFolder=waxtCQihyRnKgHEYrJMbGIBXpmceVu,params=waxtCQihyRnKgHEYrJMbGIBXpmcekF)
  xbmcplugin.endOfDirectory(waxtCQihyRnKgHEYrJMbGIBXpmcejV._addon_handle,cacheToDisc=waxtCQihyRnKgHEYrJMbGIBXpmceVU)
 def dp_Theme_GroupList(waxtCQihyRnKgHEYrJMbGIBXpmcejV,args):
  waxtCQihyRnKgHEYrJMbGIBXpmceks =args.get('vType') 
  waxtCQihyRnKgHEYrJMbGIBXpmcekN=waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.Get_Theme_GroupList(waxtCQihyRnKgHEYrJMbGIBXpmceks)
  for waxtCQihyRnKgHEYrJMbGIBXpmcekv in waxtCQihyRnKgHEYrJMbGIBXpmcekN:
   waxtCQihyRnKgHEYrJMbGIBXpmcekz =waxtCQihyRnKgHEYrJMbGIBXpmcekv.get('title')
   waxtCQihyRnKgHEYrJMbGIBXpmcekf=waxtCQihyRnKgHEYrJMbGIBXpmcekv.get('pre_title')
   waxtCQihyRnKgHEYrJMbGIBXpmcezj={'mediatype':'tvshow','plot':waxtCQihyRnKgHEYrJMbGIBXpmcekf,}
   waxtCQihyRnKgHEYrJMbGIBXpmcekF={'mode':'CATEGORY_LIST','collectionId':waxtCQihyRnKgHEYrJMbGIBXpmcekv.get('collectionId'),'vType':waxtCQihyRnKgHEYrJMbGIBXpmcekv.get('category'),'page':'1',}
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.add_dir(waxtCQihyRnKgHEYrJMbGIBXpmcekz,sublabel='',img='',infoLabels=waxtCQihyRnKgHEYrJMbGIBXpmcezj,isFolder=waxtCQihyRnKgHEYrJMbGIBXpmceVu,params=waxtCQihyRnKgHEYrJMbGIBXpmcekF)
  xbmcplugin.endOfDirectory(waxtCQihyRnKgHEYrJMbGIBXpmcejV._addon_handle,cacheToDisc=waxtCQihyRnKgHEYrJMbGIBXpmceVU)
 def dp_Event_GroupList(waxtCQihyRnKgHEYrJMbGIBXpmcejV,args):
  waxtCQihyRnKgHEYrJMbGIBXpmcekN=waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.Get_Event_GroupList()
  for waxtCQihyRnKgHEYrJMbGIBXpmcekv in waxtCQihyRnKgHEYrJMbGIBXpmcekN:
   waxtCQihyRnKgHEYrJMbGIBXpmcekz =waxtCQihyRnKgHEYrJMbGIBXpmcekv.get('title')
   waxtCQihyRnKgHEYrJMbGIBXpmcekf=waxtCQihyRnKgHEYrJMbGIBXpmcekv.get('pre_title')
   waxtCQihyRnKgHEYrJMbGIBXpmcezj={'mediatype':'tvshow','plot':waxtCQihyRnKgHEYrJMbGIBXpmcekf,}
   waxtCQihyRnKgHEYrJMbGIBXpmcekF={'mode':'EVENT_GAMELIST','collectionId':waxtCQihyRnKgHEYrJMbGIBXpmcekv.get('collectionId'),'vType':'LIVE',}
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.add_dir(waxtCQihyRnKgHEYrJMbGIBXpmcekz,sublabel='',img='',infoLabels=waxtCQihyRnKgHEYrJMbGIBXpmcezj,isFolder=waxtCQihyRnKgHEYrJMbGIBXpmceVu,params=waxtCQihyRnKgHEYrJMbGIBXpmcekF)
  xbmcplugin.endOfDirectory(waxtCQihyRnKgHEYrJMbGIBXpmcejV._addon_handle,cacheToDisc=waxtCQihyRnKgHEYrJMbGIBXpmceVU)
 def dp_Event_GameList(waxtCQihyRnKgHEYrJMbGIBXpmcejV,args):
  waxtCQihyRnKgHEYrJMbGIBXpmceks =args.get('vType') 
  waxtCQihyRnKgHEYrJMbGIBXpmcezA =args.get('collectionId')
  waxtCQihyRnKgHEYrJMbGIBXpmcekN=waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.Get_Event_GameList(waxtCQihyRnKgHEYrJMbGIBXpmcezA)
  for waxtCQihyRnKgHEYrJMbGIBXpmcekv in waxtCQihyRnKgHEYrJMbGIBXpmcekN:
   waxtCQihyRnKgHEYrJMbGIBXpmcekz =waxtCQihyRnKgHEYrJMbGIBXpmcekv.get('title')
   waxtCQihyRnKgHEYrJMbGIBXpmceFz =waxtCQihyRnKgHEYrJMbGIBXpmcekv.get('id')
   waxtCQihyRnKgHEYrJMbGIBXpmcezP =waxtCQihyRnKgHEYrJMbGIBXpmcekv.get('thumbnail')
   waxtCQihyRnKgHEYrJMbGIBXpmcezV =waxtCQihyRnKgHEYrJMbGIBXpmcekv.get('asis') 
   waxtCQihyRnKgHEYrJMbGIBXpmcezF =waxtCQihyRnKgHEYrJMbGIBXpmcekv.get('addInfo')
   waxtCQihyRnKgHEYrJMbGIBXpmcezq =waxtCQihyRnKgHEYrJMbGIBXpmcekv.get('starttm')
   waxtCQihyRnKgHEYrJMbGIBXpmcezj={'mediatype':'tvshow','title':waxtCQihyRnKgHEYrJMbGIBXpmcekz,'plot':waxtCQihyRnKgHEYrJMbGIBXpmcezF,}
   waxtCQihyRnKgHEYrJMbGIBXpmcekF={'mode':'EVENT_LIST','id':waxtCQihyRnKgHEYrJMbGIBXpmceFz,'asis':waxtCQihyRnKgHEYrJMbGIBXpmcezV,'title':waxtCQihyRnKgHEYrJMbGIBXpmcekz,}
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.add_dir(waxtCQihyRnKgHEYrJMbGIBXpmcekz,sublabel=waxtCQihyRnKgHEYrJMbGIBXpmcezq,img=waxtCQihyRnKgHEYrJMbGIBXpmcezP,infoLabels=waxtCQihyRnKgHEYrJMbGIBXpmcezj,isFolder=waxtCQihyRnKgHEYrJMbGIBXpmceVu,params=waxtCQihyRnKgHEYrJMbGIBXpmcekF,ContextMenu=waxtCQihyRnKgHEYrJMbGIBXpmceVT)
  xbmcplugin.setContent(waxtCQihyRnKgHEYrJMbGIBXpmcejV._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(waxtCQihyRnKgHEYrJMbGIBXpmcejV._addon_handle,cacheToDisc=waxtCQihyRnKgHEYrJMbGIBXpmceVU)
 def dp_Event_List(waxtCQihyRnKgHEYrJMbGIBXpmcejV,args):
  waxtCQihyRnKgHEYrJMbGIBXpmcezO=args.get('id')
  waxtCQihyRnKgHEYrJMbGIBXpmcekN=waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.Get_Event_List(waxtCQihyRnKgHEYrJMbGIBXpmcezO)
  for waxtCQihyRnKgHEYrJMbGIBXpmcekv in waxtCQihyRnKgHEYrJMbGIBXpmcekN:
   waxtCQihyRnKgHEYrJMbGIBXpmcekz =waxtCQihyRnKgHEYrJMbGIBXpmcekv.get('title')
   waxtCQihyRnKgHEYrJMbGIBXpmceFz =waxtCQihyRnKgHEYrJMbGIBXpmcekv.get('id')
   waxtCQihyRnKgHEYrJMbGIBXpmcezP =waxtCQihyRnKgHEYrJMbGIBXpmcekv.get('thumbnail')
   waxtCQihyRnKgHEYrJMbGIBXpmcezV =waxtCQihyRnKgHEYrJMbGIBXpmcekv.get('asis') 
   waxtCQihyRnKgHEYrJMbGIBXpmcezo =waxtCQihyRnKgHEYrJMbGIBXpmcekv.get('duration')
   waxtCQihyRnKgHEYrJMbGIBXpmcezq =waxtCQihyRnKgHEYrJMbGIBXpmcekv.get('starttm')
   waxtCQihyRnKgHEYrJMbGIBXpmcezj={'mediatype':'episode','title':waxtCQihyRnKgHEYrJMbGIBXpmcekz,'plot':waxtCQihyRnKgHEYrJMbGIBXpmcezV,'duration':waxtCQihyRnKgHEYrJMbGIBXpmcezo,}
   waxtCQihyRnKgHEYrJMbGIBXpmcekF={'mode':waxtCQihyRnKgHEYrJMbGIBXpmcezV,'id':waxtCQihyRnKgHEYrJMbGIBXpmceFz,'asis':waxtCQihyRnKgHEYrJMbGIBXpmcezV,'title':waxtCQihyRnKgHEYrJMbGIBXpmcekz,}
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.add_dir(waxtCQihyRnKgHEYrJMbGIBXpmcekz,sublabel=waxtCQihyRnKgHEYrJMbGIBXpmcezq,img=waxtCQihyRnKgHEYrJMbGIBXpmcezP,infoLabels=waxtCQihyRnKgHEYrJMbGIBXpmcezj,isFolder=waxtCQihyRnKgHEYrJMbGIBXpmceVU,params=waxtCQihyRnKgHEYrJMbGIBXpmcekF,ContextMenu=waxtCQihyRnKgHEYrJMbGIBXpmceVT)
  xbmcplugin.setContent(waxtCQihyRnKgHEYrJMbGIBXpmcejV._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(waxtCQihyRnKgHEYrJMbGIBXpmcejV._addon_handle,cacheToDisc=waxtCQihyRnKgHEYrJMbGIBXpmceVU)
 def dp_Category_List(waxtCQihyRnKgHEYrJMbGIBXpmcejV,args):
  waxtCQihyRnKgHEYrJMbGIBXpmceks =args.get('vType') 
  waxtCQihyRnKgHEYrJMbGIBXpmcezA =args.get('collectionId')
  waxtCQihyRnKgHEYrJMbGIBXpmcezL =waxtCQihyRnKgHEYrJMbGIBXpmceVv(args.get('page'))
  waxtCQihyRnKgHEYrJMbGIBXpmcekN,waxtCQihyRnKgHEYrJMbGIBXpmcezS=waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.Get_Category_List(waxtCQihyRnKgHEYrJMbGIBXpmceks,waxtCQihyRnKgHEYrJMbGIBXpmcezA,waxtCQihyRnKgHEYrJMbGIBXpmcezL)
  for waxtCQihyRnKgHEYrJMbGIBXpmcekv in waxtCQihyRnKgHEYrJMbGIBXpmcekN:
   waxtCQihyRnKgHEYrJMbGIBXpmcekz =waxtCQihyRnKgHEYrJMbGIBXpmcekv.get('title')
   waxtCQihyRnKgHEYrJMbGIBXpmceFz =waxtCQihyRnKgHEYrJMbGIBXpmcekv.get('id')
   waxtCQihyRnKgHEYrJMbGIBXpmcezP =waxtCQihyRnKgHEYrJMbGIBXpmcekv.get('thumbnail')
   waxtCQihyRnKgHEYrJMbGIBXpmcezW =waxtCQihyRnKgHEYrJMbGIBXpmcekv.get('mpaa')
   waxtCQihyRnKgHEYrJMbGIBXpmcezo =waxtCQihyRnKgHEYrJMbGIBXpmcekv.get('duration')
   waxtCQihyRnKgHEYrJMbGIBXpmcezV =waxtCQihyRnKgHEYrJMbGIBXpmcekv.get('asis')
   waxtCQihyRnKgHEYrJMbGIBXpmcezd =waxtCQihyRnKgHEYrJMbGIBXpmcekv.get('badge')
   waxtCQihyRnKgHEYrJMbGIBXpmcezD =waxtCQihyRnKgHEYrJMbGIBXpmcekv.get('year')
   waxtCQihyRnKgHEYrJMbGIBXpmcezl=waxtCQihyRnKgHEYrJMbGIBXpmcekv.get('seasonList')
   waxtCQihyRnKgHEYrJMbGIBXpmcezT =waxtCQihyRnKgHEYrJMbGIBXpmcekv.get('genreList')
   if waxtCQihyRnKgHEYrJMbGIBXpmcezV in['TVSHOW','EDUCATION']: 
    waxtCQihyRnKgHEYrJMbGIBXpmcezU ='SEASON_LIST'
    waxtCQihyRnKgHEYrJMbGIBXpmcezj={'mediatype':'tvshow','title':waxtCQihyRnKgHEYrJMbGIBXpmcekz,'mpaa':waxtCQihyRnKgHEYrJMbGIBXpmcezW,'genre':waxtCQihyRnKgHEYrJMbGIBXpmcezT,'year':waxtCQihyRnKgHEYrJMbGIBXpmcezD,'plot':'Year : %s\nSeason : %s'%(waxtCQihyRnKgHEYrJMbGIBXpmcezD,waxtCQihyRnKgHEYrJMbGIBXpmcezl),}
    waxtCQihyRnKgHEYrJMbGIBXpmcekq =waxtCQihyRnKgHEYrJMbGIBXpmceVu
   else:
    waxtCQihyRnKgHEYrJMbGIBXpmcezU ='MOVIE'
    waxtCQihyRnKgHEYrJMbGIBXpmcezj={'mediatype':'movie','title':waxtCQihyRnKgHEYrJMbGIBXpmcekz,'mpaa':waxtCQihyRnKgHEYrJMbGIBXpmcezW,'genre':waxtCQihyRnKgHEYrJMbGIBXpmcezT,'duration':waxtCQihyRnKgHEYrJMbGIBXpmcezo,'year':waxtCQihyRnKgHEYrJMbGIBXpmcezD,'plot':'(%s)'%(waxtCQihyRnKgHEYrJMbGIBXpmcezW),}
    waxtCQihyRnKgHEYrJMbGIBXpmcekq =waxtCQihyRnKgHEYrJMbGIBXpmceVU
    waxtCQihyRnKgHEYrJMbGIBXpmcekz +=' (%s)'%(waxtCQihyRnKgHEYrJMbGIBXpmceFk(waxtCQihyRnKgHEYrJMbGIBXpmcezD))
   waxtCQihyRnKgHEYrJMbGIBXpmcekF={'mode':waxtCQihyRnKgHEYrJMbGIBXpmcezU,'id':waxtCQihyRnKgHEYrJMbGIBXpmceFz,'asis':waxtCQihyRnKgHEYrJMbGIBXpmcezV,'seasonList':waxtCQihyRnKgHEYrJMbGIBXpmcezl,'title':waxtCQihyRnKgHEYrJMbGIBXpmcekz,'thumbnail':waxtCQihyRnKgHEYrJMbGIBXpmcezP,'year':waxtCQihyRnKgHEYrJMbGIBXpmcezD,}
   if waxtCQihyRnKgHEYrJMbGIBXpmcejV.get_settings_makebookmark():
    waxtCQihyRnKgHEYrJMbGIBXpmcezu={'videoid':waxtCQihyRnKgHEYrJMbGIBXpmceFz,'vidtype':'movie' if waxtCQihyRnKgHEYrJMbGIBXpmceks=='MOVIES' else 'tvshow','vtitle':waxtCQihyRnKgHEYrJMbGIBXpmcekz,'vsubtitle':'',}
    waxtCQihyRnKgHEYrJMbGIBXpmcezs=json.dumps(waxtCQihyRnKgHEYrJMbGIBXpmcezu)
    waxtCQihyRnKgHEYrJMbGIBXpmcezs=urllib.parse.quote(waxtCQihyRnKgHEYrJMbGIBXpmcezs)
    waxtCQihyRnKgHEYrJMbGIBXpmcezN='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(waxtCQihyRnKgHEYrJMbGIBXpmcezs)
    waxtCQihyRnKgHEYrJMbGIBXpmcezv=[('(통합) 찜 영상에 추가',waxtCQihyRnKgHEYrJMbGIBXpmcezN)]
   else:
    waxtCQihyRnKgHEYrJMbGIBXpmcezv=waxtCQihyRnKgHEYrJMbGIBXpmceVT
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.add_dir(waxtCQihyRnKgHEYrJMbGIBXpmcekz,sublabel=waxtCQihyRnKgHEYrJMbGIBXpmcezd,img=waxtCQihyRnKgHEYrJMbGIBXpmcezP,infoLabels=waxtCQihyRnKgHEYrJMbGIBXpmcezj,isFolder=waxtCQihyRnKgHEYrJMbGIBXpmcekq,params=waxtCQihyRnKgHEYrJMbGIBXpmcekF,ContextMenu=waxtCQihyRnKgHEYrJMbGIBXpmcezv)
  if waxtCQihyRnKgHEYrJMbGIBXpmcezS:
   waxtCQihyRnKgHEYrJMbGIBXpmcekF['mode'] ='CATEGORY_LIST' 
   waxtCQihyRnKgHEYrJMbGIBXpmcekF['collectionId']=waxtCQihyRnKgHEYrJMbGIBXpmcezA 
   waxtCQihyRnKgHEYrJMbGIBXpmcekF['vType'] =waxtCQihyRnKgHEYrJMbGIBXpmceks 
   waxtCQihyRnKgHEYrJMbGIBXpmcekF['page'] =waxtCQihyRnKgHEYrJMbGIBXpmceFk(waxtCQihyRnKgHEYrJMbGIBXpmcezL+1)
   waxtCQihyRnKgHEYrJMbGIBXpmcekz='[B]%s >>[/B]'%'다음 페이지'
   waxtCQihyRnKgHEYrJMbGIBXpmcezf=waxtCQihyRnKgHEYrJMbGIBXpmceFk(waxtCQihyRnKgHEYrJMbGIBXpmcezL+1)
   waxtCQihyRnKgHEYrJMbGIBXpmcekV=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.add_dir(waxtCQihyRnKgHEYrJMbGIBXpmcekz,sublabel=waxtCQihyRnKgHEYrJMbGIBXpmcezf,img=waxtCQihyRnKgHEYrJMbGIBXpmcekV,infoLabels=waxtCQihyRnKgHEYrJMbGIBXpmceVT,isFolder=waxtCQihyRnKgHEYrJMbGIBXpmceVu,params=waxtCQihyRnKgHEYrJMbGIBXpmcekF)
  if waxtCQihyRnKgHEYrJMbGIBXpmceks=='TVSHOWS':xbmcplugin.setContent(waxtCQihyRnKgHEYrJMbGIBXpmcejV._addon_handle,'tvshows')
  else:xbmcplugin.setContent(waxtCQihyRnKgHEYrJMbGIBXpmcejV._addon_handle,'movies')
  xbmcplugin.endOfDirectory(waxtCQihyRnKgHEYrJMbGIBXpmcejV._addon_handle,cacheToDisc=waxtCQihyRnKgHEYrJMbGIBXpmceVU)
 def dp_Season_List(waxtCQihyRnKgHEYrJMbGIBXpmcejV,args):
  waxtCQihyRnKgHEYrJMbGIBXpmceAj =args.get('title')
  waxtCQihyRnKgHEYrJMbGIBXpmceAk =args.get('id')
  waxtCQihyRnKgHEYrJMbGIBXpmcezV =args.get('asis')
  waxtCQihyRnKgHEYrJMbGIBXpmcezl =args.get('seasonList')
  waxtCQihyRnKgHEYrJMbGIBXpmcezP =args.get('thumbnail')
  waxtCQihyRnKgHEYrJMbGIBXpmcezD =args.get('year')
  if waxtCQihyRnKgHEYrJMbGIBXpmcezl in['',waxtCQihyRnKgHEYrJMbGIBXpmceVT]:
   waxtCQihyRnKgHEYrJMbGIBXpmcezl=waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.Get_vInfo(waxtCQihyRnKgHEYrJMbGIBXpmceAk).get('seasonList')
  if waxtCQihyRnKgHEYrJMbGIBXpmceFA(waxtCQihyRnKgHEYrJMbGIBXpmcezl.split(','))>1:
   for waxtCQihyRnKgHEYrJMbGIBXpmceAz in waxtCQihyRnKgHEYrJMbGIBXpmcezl.split(','):
    waxtCQihyRnKgHEYrJMbGIBXpmcekz='시즌 '+waxtCQihyRnKgHEYrJMbGIBXpmceAz
    waxtCQihyRnKgHEYrJMbGIBXpmcezj={'mediatype':'tvshow','plot':'%s (%s)'%(waxtCQihyRnKgHEYrJMbGIBXpmceAj,waxtCQihyRnKgHEYrJMbGIBXpmcezD),}
    waxtCQihyRnKgHEYrJMbGIBXpmcekF={'mode':'EPISODE_LIST','programid':waxtCQihyRnKgHEYrJMbGIBXpmceAk,'programnm':waxtCQihyRnKgHEYrJMbGIBXpmceAj,'season':waxtCQihyRnKgHEYrJMbGIBXpmceAz,'asis':waxtCQihyRnKgHEYrJMbGIBXpmcezV,'programimg':waxtCQihyRnKgHEYrJMbGIBXpmcezP,}
    waxtCQihyRnKgHEYrJMbGIBXpmceAP=waxtCQihyRnKgHEYrJMbGIBXpmcezP.replace('\'','\"')
    waxtCQihyRnKgHEYrJMbGIBXpmceAP=json.loads(waxtCQihyRnKgHEYrJMbGIBXpmceAP)
    waxtCQihyRnKgHEYrJMbGIBXpmcejV.add_dir(waxtCQihyRnKgHEYrJMbGIBXpmcekz,sublabel='',img=waxtCQihyRnKgHEYrJMbGIBXpmceAP,infoLabels=waxtCQihyRnKgHEYrJMbGIBXpmcezj,isFolder=waxtCQihyRnKgHEYrJMbGIBXpmceVu,params=waxtCQihyRnKgHEYrJMbGIBXpmcekF)
   xbmcplugin.setContent(waxtCQihyRnKgHEYrJMbGIBXpmcejV._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(waxtCQihyRnKgHEYrJMbGIBXpmcejV._addon_handle,cacheToDisc=waxtCQihyRnKgHEYrJMbGIBXpmceVU)
  else:
   waxtCQihyRnKgHEYrJMbGIBXpmceAV={'programid':waxtCQihyRnKgHEYrJMbGIBXpmceAk,'programnm':waxtCQihyRnKgHEYrJMbGIBXpmceAj,'season':waxtCQihyRnKgHEYrJMbGIBXpmcezl,'programimg':waxtCQihyRnKgHEYrJMbGIBXpmcezP,}
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.dp_Episode_List(waxtCQihyRnKgHEYrJMbGIBXpmceAV)
 def dp_Episode_List(waxtCQihyRnKgHEYrJMbGIBXpmcejV,args):
  waxtCQihyRnKgHEYrJMbGIBXpmceAk =args.get('programid')
  waxtCQihyRnKgHEYrJMbGIBXpmceAj =args.get('programnm')
  waxtCQihyRnKgHEYrJMbGIBXpmceAF =args.get('season')
  waxtCQihyRnKgHEYrJMbGIBXpmceAq =args.get('programimg')
  waxtCQihyRnKgHEYrJMbGIBXpmceAO=waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.Get_Episode_List(waxtCQihyRnKgHEYrJMbGIBXpmceAk,waxtCQihyRnKgHEYrJMbGIBXpmceAF)
  for waxtCQihyRnKgHEYrJMbGIBXpmceAz in waxtCQihyRnKgHEYrJMbGIBXpmceAO:
   waxtCQihyRnKgHEYrJMbGIBXpmceAo =waxtCQihyRnKgHEYrJMbGIBXpmceAz.get('title')
   waxtCQihyRnKgHEYrJMbGIBXpmceAL =waxtCQihyRnKgHEYrJMbGIBXpmceAz.get('id')
   waxtCQihyRnKgHEYrJMbGIBXpmcezV =waxtCQihyRnKgHEYrJMbGIBXpmceAz.get('asis')
   waxtCQihyRnKgHEYrJMbGIBXpmcezP =waxtCQihyRnKgHEYrJMbGIBXpmceAz.get('thumbnail')
   waxtCQihyRnKgHEYrJMbGIBXpmcezW =waxtCQihyRnKgHEYrJMbGIBXpmceAz.get('mpaa')
   waxtCQihyRnKgHEYrJMbGIBXpmcezo =waxtCQihyRnKgHEYrJMbGIBXpmceAz.get('duration')
   waxtCQihyRnKgHEYrJMbGIBXpmcezD =waxtCQihyRnKgHEYrJMbGIBXpmceAz.get('year')
   waxtCQihyRnKgHEYrJMbGIBXpmceAS =waxtCQihyRnKgHEYrJMbGIBXpmceAz.get('episode')
   waxtCQihyRnKgHEYrJMbGIBXpmcezT =waxtCQihyRnKgHEYrJMbGIBXpmceAz.get('genreList')
   waxtCQihyRnKgHEYrJMbGIBXpmceAW =waxtCQihyRnKgHEYrJMbGIBXpmceAz.get('desc')
   waxtCQihyRnKgHEYrJMbGIBXpmceAd ='%sx%s'%(waxtCQihyRnKgHEYrJMbGIBXpmceAF,waxtCQihyRnKgHEYrJMbGIBXpmceAS)
   waxtCQihyRnKgHEYrJMbGIBXpmcekz ='%s. %s'%(waxtCQihyRnKgHEYrJMbGIBXpmceAd,waxtCQihyRnKgHEYrJMbGIBXpmceAo)
   waxtCQihyRnKgHEYrJMbGIBXpmcezj={'mediatype':'episode','mpaa':waxtCQihyRnKgHEYrJMbGIBXpmcezW,'genre':waxtCQihyRnKgHEYrJMbGIBXpmcezT,'duration':waxtCQihyRnKgHEYrJMbGIBXpmcezo,'year':waxtCQihyRnKgHEYrJMbGIBXpmcezD,'plot':'%s (%s)\n\n%s'%(waxtCQihyRnKgHEYrJMbGIBXpmceAj,waxtCQihyRnKgHEYrJMbGIBXpmceAd,waxtCQihyRnKgHEYrJMbGIBXpmceAW),}
   waxtCQihyRnKgHEYrJMbGIBXpmcekF={'mode':'VOD','programid':waxtCQihyRnKgHEYrJMbGIBXpmceAk,'programnm':waxtCQihyRnKgHEYrJMbGIBXpmceAj,'title':waxtCQihyRnKgHEYrJMbGIBXpmcekz,'season':waxtCQihyRnKgHEYrJMbGIBXpmceAF,'id':waxtCQihyRnKgHEYrJMbGIBXpmceAL,'asis':waxtCQihyRnKgHEYrJMbGIBXpmcezV,'thumbnail':waxtCQihyRnKgHEYrJMbGIBXpmcezP,'programimg':waxtCQihyRnKgHEYrJMbGIBXpmceAq,}
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.add_dir(waxtCQihyRnKgHEYrJMbGIBXpmcekz,sublabel='',img=waxtCQihyRnKgHEYrJMbGIBXpmcezP,infoLabels=waxtCQihyRnKgHEYrJMbGIBXpmcezj,isFolder=waxtCQihyRnKgHEYrJMbGIBXpmceVU,params=waxtCQihyRnKgHEYrJMbGIBXpmcekF)
  xbmcplugin.setContent(waxtCQihyRnKgHEYrJMbGIBXpmcejV._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(waxtCQihyRnKgHEYrJMbGIBXpmcejV._addon_handle,cacheToDisc=waxtCQihyRnKgHEYrJMbGIBXpmceVU)
 def play_VIDEO(waxtCQihyRnKgHEYrJMbGIBXpmcejV,args):
  waxtCQihyRnKgHEYrJMbGIBXpmceAD =args.get('id')
  waxtCQihyRnKgHEYrJMbGIBXpmcezV =args.get('asis')
  if waxtCQihyRnKgHEYrJMbGIBXpmcezV in['HIGHLIGHT']:
   waxtCQihyRnKgHEYrJMbGIBXpmceAl,waxtCQihyRnKgHEYrJMbGIBXpmceAT=waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.GetEventURL(waxtCQihyRnKgHEYrJMbGIBXpmceAD,waxtCQihyRnKgHEYrJMbGIBXpmcezV)
  elif waxtCQihyRnKgHEYrJMbGIBXpmcezV in['LIVE']:
   waxtCQihyRnKgHEYrJMbGIBXpmceAl,waxtCQihyRnKgHEYrJMbGIBXpmceAT=waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.GetEventURL_Live(waxtCQihyRnKgHEYrJMbGIBXpmceAD,waxtCQihyRnKgHEYrJMbGIBXpmcezV)
  else:
   waxtCQihyRnKgHEYrJMbGIBXpmceAl,waxtCQihyRnKgHEYrJMbGIBXpmceAT=waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.GetBroadURL(waxtCQihyRnKgHEYrJMbGIBXpmceAD)
  waxtCQihyRnKgHEYrJMbGIBXpmcejV.addon_log('asis, url : %s - %s - %s'%(waxtCQihyRnKgHEYrJMbGIBXpmcezV,waxtCQihyRnKgHEYrJMbGIBXpmceAD,waxtCQihyRnKgHEYrJMbGIBXpmceAl))
  if waxtCQihyRnKgHEYrJMbGIBXpmceAl=='':
   if waxtCQihyRnKgHEYrJMbGIBXpmceAT=='':
    waxtCQihyRnKgHEYrJMbGIBXpmcejV.addon_noti(__language__(30907).encode('utf8'))
   else:
    waxtCQihyRnKgHEYrJMbGIBXpmcejV.addon_noti(waxtCQihyRnKgHEYrJMbGIBXpmceAT)
   return
  waxtCQihyRnKgHEYrJMbGIBXpmceAU='PCID=%s;token=%s;member_srl=%s;NEXT_LOCALE=%s;bm_mi=%s;ak_bmsc=%s;bm_sv=%s'%(waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.CP['SESSION']['PCID'],waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.CP['SESSION']['token'],waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.CP['SESSION']['member_srl'],waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.CP['SESSION']['NEXT_LOCALE'],waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.CP['SESSION']['bm_mi'],waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.CP['SESSION']['ak_bmsc'],waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.CP['SESSION']['bm_sv'],)
  waxtCQihyRnKgHEYrJMbGIBXpmceAu='%s|Cookie=%s'%(waxtCQihyRnKgHEYrJMbGIBXpmceAl,waxtCQihyRnKgHEYrJMbGIBXpmceAU)
  waxtCQihyRnKgHEYrJMbGIBXpmceAs=xbmcgui.ListItem(path=waxtCQihyRnKgHEYrJMbGIBXpmceAu)
  if waxtCQihyRnKgHEYrJMbGIBXpmceAT:
   waxtCQihyRnKgHEYrJMbGIBXpmceAN =waxtCQihyRnKgHEYrJMbGIBXpmceAT 
   waxtCQihyRnKgHEYrJMbGIBXpmceAv ='mpd' 
   waxtCQihyRnKgHEYrJMbGIBXpmceAf ='com.widevine.alpha'
   waxtCQihyRnKgHEYrJMbGIBXpmcePj =inputstreamhelper.Helper(waxtCQihyRnKgHEYrJMbGIBXpmceAv,drm='widevine')
   if waxtCQihyRnKgHEYrJMbGIBXpmcePj.check_inputstream():
    waxtCQihyRnKgHEYrJMbGIBXpmcePk,waxtCQihyRnKgHEYrJMbGIBXpmcePz,waxtCQihyRnKgHEYrJMbGIBXpmcePA=waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.Make_authHeader()
    waxtCQihyRnKgHEYrJMbGIBXpmcePV={'traceparent':waxtCQihyRnKgHEYrJMbGIBXpmcePk,'tracestate':waxtCQihyRnKgHEYrJMbGIBXpmcePz,'newrelic':waxtCQihyRnKgHEYrJMbGIBXpmcePA,'content-type':'application/octet-stream','User-Agent':waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.USER_AGENT,'Cookie':waxtCQihyRnKgHEYrJMbGIBXpmceAU,}
    waxtCQihyRnKgHEYrJMbGIBXpmcePF=waxtCQihyRnKgHEYrJMbGIBXpmceAN+'|'+urllib.parse.urlencode(waxtCQihyRnKgHEYrJMbGIBXpmcePV)+'|R{SSM}|'
    waxtCQihyRnKgHEYrJMbGIBXpmceAs.setProperty('inputstream',waxtCQihyRnKgHEYrJMbGIBXpmcePj.inputstream_addon)
    waxtCQihyRnKgHEYrJMbGIBXpmceAs.setProperty('inputstream.adaptive.manifest_type',waxtCQihyRnKgHEYrJMbGIBXpmceAv)
    waxtCQihyRnKgHEYrJMbGIBXpmceAs.setProperty('inputstream.adaptive.license_type',waxtCQihyRnKgHEYrJMbGIBXpmceAf)
    waxtCQihyRnKgHEYrJMbGIBXpmceAs.setProperty('inputstream.adaptive.license_key',waxtCQihyRnKgHEYrJMbGIBXpmcePF)
    waxtCQihyRnKgHEYrJMbGIBXpmceAs.setProperty('inputstream.adaptive.stream_headers','User-Agent=%s&Cookie=%s'%(waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.USER_AGENT,waxtCQihyRnKgHEYrJMbGIBXpmceAU))
    waxtCQihyRnKgHEYrJMbGIBXpmceAs.setMimeType('application/dash+xml')
    waxtCQihyRnKgHEYrJMbGIBXpmceAs.setContentLookup(waxtCQihyRnKgHEYrJMbGIBXpmceVU)
  xbmcplugin.setResolvedUrl(waxtCQihyRnKgHEYrJMbGIBXpmcejV._addon_handle,waxtCQihyRnKgHEYrJMbGIBXpmceVu,waxtCQihyRnKgHEYrJMbGIBXpmceAs)
  try:
   if waxtCQihyRnKgHEYrJMbGIBXpmcezV=='MOVIE':
    waxtCQihyRnKgHEYrJMbGIBXpmcePq='movie'
    waxtCQihyRnKgHEYrJMbGIBXpmcekF={'code':waxtCQihyRnKgHEYrJMbGIBXpmceAD,'asis':waxtCQihyRnKgHEYrJMbGIBXpmcezV,'title':args.get('title'),'img':args.get('thumbnail'),}
    waxtCQihyRnKgHEYrJMbGIBXpmcejV.Save_Watched_List(waxtCQihyRnKgHEYrJMbGIBXpmcePq,waxtCQihyRnKgHEYrJMbGIBXpmcekF)
   elif waxtCQihyRnKgHEYrJMbGIBXpmcezV=='TVSHOW':
    waxtCQihyRnKgHEYrJMbGIBXpmcePq='tvshow'
    waxtCQihyRnKgHEYrJMbGIBXpmcekF={'code':args.get('programid'),'asis':waxtCQihyRnKgHEYrJMbGIBXpmcezV,'title':'%s <%s>'%(args.get('title'),args.get('programnm')),'img':args.get('programimg'),}
    waxtCQihyRnKgHEYrJMbGIBXpmcejV.Save_Watched_List(waxtCQihyRnKgHEYrJMbGIBXpmcePq,waxtCQihyRnKgHEYrJMbGIBXpmcekF)
  except:
   waxtCQihyRnKgHEYrJMbGIBXpmceVT
 def dp_Global_Search(waxtCQihyRnKgHEYrJMbGIBXpmcejV,args):
  waxtCQihyRnKgHEYrJMbGIBXpmcezU=args.get('mode')
  if waxtCQihyRnKgHEYrJMbGIBXpmcezU=='TOTAL_SEARCH':
   waxtCQihyRnKgHEYrJMbGIBXpmcePO='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   waxtCQihyRnKgHEYrJMbGIBXpmcePO='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(waxtCQihyRnKgHEYrJMbGIBXpmcePO)
 def dp_Bookmark_Menu(waxtCQihyRnKgHEYrJMbGIBXpmcejV,args):
  waxtCQihyRnKgHEYrJMbGIBXpmcePO='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(waxtCQihyRnKgHEYrJMbGIBXpmcePO)
 def dp_Search_List(waxtCQihyRnKgHEYrJMbGIBXpmcejV,args):
  waxtCQihyRnKgHEYrJMbGIBXpmcezL =waxtCQihyRnKgHEYrJMbGIBXpmceVv(args.get('page'))
  if 'search_key' in args:
   waxtCQihyRnKgHEYrJMbGIBXpmcePo=args.get('search_key')
  else:
   waxtCQihyRnKgHEYrJMbGIBXpmcePo=waxtCQihyRnKgHEYrJMbGIBXpmcejV.get_keyboard_input(__language__(30908).encode('utf-8'))
   if not waxtCQihyRnKgHEYrJMbGIBXpmcePo:
    return
  waxtCQihyRnKgHEYrJMbGIBXpmcePL,waxtCQihyRnKgHEYrJMbGIBXpmcezS=waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.Get_Search_List(waxtCQihyRnKgHEYrJMbGIBXpmcePo,waxtCQihyRnKgHEYrJMbGIBXpmcezL)
  for waxtCQihyRnKgHEYrJMbGIBXpmcePS in waxtCQihyRnKgHEYrJMbGIBXpmcePL:
   waxtCQihyRnKgHEYrJMbGIBXpmceFz =waxtCQihyRnKgHEYrJMbGIBXpmcePS.get('id')
   waxtCQihyRnKgHEYrJMbGIBXpmcekz =waxtCQihyRnKgHEYrJMbGIBXpmcePS.get('title')
   waxtCQihyRnKgHEYrJMbGIBXpmcezV =waxtCQihyRnKgHEYrJMbGIBXpmcePS.get('asis')
   waxtCQihyRnKgHEYrJMbGIBXpmcezP =waxtCQihyRnKgHEYrJMbGIBXpmcePS.get('thumbnail')
   waxtCQihyRnKgHEYrJMbGIBXpmcezW =waxtCQihyRnKgHEYrJMbGIBXpmcePS.get('mpaa')
   waxtCQihyRnKgHEYrJMbGIBXpmcezD =waxtCQihyRnKgHEYrJMbGIBXpmcePS.get('year')
   waxtCQihyRnKgHEYrJMbGIBXpmcezo =waxtCQihyRnKgHEYrJMbGIBXpmcePS.get('duration')
   waxtCQihyRnKgHEYrJMbGIBXpmcezd =waxtCQihyRnKgHEYrJMbGIBXpmcePS.get('badge')
   if waxtCQihyRnKgHEYrJMbGIBXpmcezV=='TVSHOW': 
    waxtCQihyRnKgHEYrJMbGIBXpmcezU ='SEASON_LIST'
    waxtCQihyRnKgHEYrJMbGIBXpmcezj={'mediatype':'tvshow','title':waxtCQihyRnKgHEYrJMbGIBXpmcekz,'mpaa':waxtCQihyRnKgHEYrJMbGIBXpmcezW,'year':waxtCQihyRnKgHEYrJMbGIBXpmcezD,'plot':'Year : %s'%(waxtCQihyRnKgHEYrJMbGIBXpmcezD),}
    waxtCQihyRnKgHEYrJMbGIBXpmcekq =waxtCQihyRnKgHEYrJMbGIBXpmceVu
   elif waxtCQihyRnKgHEYrJMbGIBXpmcezV=='MOVIE':
    waxtCQihyRnKgHEYrJMbGIBXpmcezU ='MOVIE'
    waxtCQihyRnKgHEYrJMbGIBXpmcezj={'mediatype':'movie','title':waxtCQihyRnKgHEYrJMbGIBXpmcekz,'mpaa':waxtCQihyRnKgHEYrJMbGIBXpmcezW,'duration':waxtCQihyRnKgHEYrJMbGIBXpmcezo,'year':waxtCQihyRnKgHEYrJMbGIBXpmcezD,'plot':'(%s)'%(waxtCQihyRnKgHEYrJMbGIBXpmcezW),}
    waxtCQihyRnKgHEYrJMbGIBXpmcekq =waxtCQihyRnKgHEYrJMbGIBXpmceVU
    waxtCQihyRnKgHEYrJMbGIBXpmcekz +=' (%s)'%(waxtCQihyRnKgHEYrJMbGIBXpmceFk(waxtCQihyRnKgHEYrJMbGIBXpmcezD))
   elif waxtCQihyRnKgHEYrJMbGIBXpmcezV=='HIGHLIGHT':
    waxtCQihyRnKgHEYrJMbGIBXpmcezU ='HIGHLIGHT'
    waxtCQihyRnKgHEYrJMbGIBXpmcezj={'mediatype':'episode','title':waxtCQihyRnKgHEYrJMbGIBXpmcekz,'duration':waxtCQihyRnKgHEYrJMbGIBXpmcezo,'plot':waxtCQihyRnKgHEYrJMbGIBXpmcezU,}
    waxtCQihyRnKgHEYrJMbGIBXpmcekq =waxtCQihyRnKgHEYrJMbGIBXpmceVU
   elif waxtCQihyRnKgHEYrJMbGIBXpmcezV=='LIVE':
    waxtCQihyRnKgHEYrJMbGIBXpmcezU ='LIVE'
    waxtCQihyRnKgHEYrJMbGIBXpmcezj={'mediatype':'episode','title':waxtCQihyRnKgHEYrJMbGIBXpmcekz,'plot':waxtCQihyRnKgHEYrJMbGIBXpmcezU,}
    waxtCQihyRnKgHEYrJMbGIBXpmcekq =waxtCQihyRnKgHEYrJMbGIBXpmceVU
   waxtCQihyRnKgHEYrJMbGIBXpmcekF={'mode':waxtCQihyRnKgHEYrJMbGIBXpmcezU,'id':waxtCQihyRnKgHEYrJMbGIBXpmceFz,'asis':waxtCQihyRnKgHEYrJMbGIBXpmcezV,'seasonList':'','title':waxtCQihyRnKgHEYrJMbGIBXpmcekz,'thumbnail':json.dumps(waxtCQihyRnKgHEYrJMbGIBXpmcezP,separators=(',',':')),'year':waxtCQihyRnKgHEYrJMbGIBXpmcezD,}
   if waxtCQihyRnKgHEYrJMbGIBXpmcejV.get_settings_makebookmark()and waxtCQihyRnKgHEYrJMbGIBXpmcezV not in['HIGHLIGHT','']:
    waxtCQihyRnKgHEYrJMbGIBXpmcezu={'videoid':waxtCQihyRnKgHEYrJMbGIBXpmceFz,'vidtype':'movie' if waxtCQihyRnKgHEYrJMbGIBXpmcezV=='MOVIE' else 'tvshow','vtitle':waxtCQihyRnKgHEYrJMbGIBXpmcekz,'vsubtitle':'',}
    waxtCQihyRnKgHEYrJMbGIBXpmcezs=json.dumps(waxtCQihyRnKgHEYrJMbGIBXpmcezu)
    waxtCQihyRnKgHEYrJMbGIBXpmcezs=urllib.parse.quote(waxtCQihyRnKgHEYrJMbGIBXpmcezs)
    waxtCQihyRnKgHEYrJMbGIBXpmcezN='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(waxtCQihyRnKgHEYrJMbGIBXpmcezs)
    waxtCQihyRnKgHEYrJMbGIBXpmcezv=[('(통합) 찜 영상에 추가',waxtCQihyRnKgHEYrJMbGIBXpmcezN)]
   else:
    waxtCQihyRnKgHEYrJMbGIBXpmcezv=waxtCQihyRnKgHEYrJMbGIBXpmceVT
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.add_dir(waxtCQihyRnKgHEYrJMbGIBXpmcekz,sublabel=waxtCQihyRnKgHEYrJMbGIBXpmcezd,img=waxtCQihyRnKgHEYrJMbGIBXpmcezP,infoLabels=waxtCQihyRnKgHEYrJMbGIBXpmcezj,isFolder=waxtCQihyRnKgHEYrJMbGIBXpmcekq,params=waxtCQihyRnKgHEYrJMbGIBXpmcekF,ContextMenu=waxtCQihyRnKgHEYrJMbGIBXpmcezv)
  if waxtCQihyRnKgHEYrJMbGIBXpmcezS:
   waxtCQihyRnKgHEYrJMbGIBXpmcekF={}
   waxtCQihyRnKgHEYrJMbGIBXpmcekF['mode'] ='LOCAL_SEARCH'
   waxtCQihyRnKgHEYrJMbGIBXpmcekF['search_key']=waxtCQihyRnKgHEYrJMbGIBXpmcePo
   waxtCQihyRnKgHEYrJMbGIBXpmcekF['page'] =waxtCQihyRnKgHEYrJMbGIBXpmceFk(waxtCQihyRnKgHEYrJMbGIBXpmcezL+1)
   waxtCQihyRnKgHEYrJMbGIBXpmcekz='[B]%s >>[/B]'%'다음 페이지'
   waxtCQihyRnKgHEYrJMbGIBXpmcezf=waxtCQihyRnKgHEYrJMbGIBXpmceFk(waxtCQihyRnKgHEYrJMbGIBXpmcezL+1)
   waxtCQihyRnKgHEYrJMbGIBXpmcekV=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.add_dir(waxtCQihyRnKgHEYrJMbGIBXpmcekz,sublabel=waxtCQihyRnKgHEYrJMbGIBXpmcezf,img=waxtCQihyRnKgHEYrJMbGIBXpmcekV,infoLabels=waxtCQihyRnKgHEYrJMbGIBXpmceVT,isFolder=waxtCQihyRnKgHEYrJMbGIBXpmceVu,params=waxtCQihyRnKgHEYrJMbGIBXpmcekF)
  xbmcplugin.setContent(waxtCQihyRnKgHEYrJMbGIBXpmcejV._addon_handle,'movies')
  xbmcplugin.endOfDirectory(waxtCQihyRnKgHEYrJMbGIBXpmcejV._addon_handle,cacheToDisc=waxtCQihyRnKgHEYrJMbGIBXpmceVu)
  if args.get('historyyn')=='Y':waxtCQihyRnKgHEYrJMbGIBXpmcejV.Save_Searched_List(waxtCQihyRnKgHEYrJMbGIBXpmcePo)
 def Load_List_File(waxtCQihyRnKgHEYrJMbGIBXpmcejV,waxtCQihyRnKgHEYrJMbGIBXpmcePq): 
  try:
   if waxtCQihyRnKgHEYrJMbGIBXpmcePq=='search':
    waxtCQihyRnKgHEYrJMbGIBXpmcePW=waxtCQihyRnKgHEYrJMbGIBXpmcejP
   elif waxtCQihyRnKgHEYrJMbGIBXpmcePq in['tvshow','movie']:
    waxtCQihyRnKgHEYrJMbGIBXpmcePW=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%waxtCQihyRnKgHEYrJMbGIBXpmcePq))
   else:
    return[]
   fp=waxtCQihyRnKgHEYrJMbGIBXpmceVf(waxtCQihyRnKgHEYrJMbGIBXpmcePW,'r',-1,'utf-8')
   waxtCQihyRnKgHEYrJMbGIBXpmcePd=fp.readlines()
   fp.close()
  except:
   waxtCQihyRnKgHEYrJMbGIBXpmcePd=[]
  return waxtCQihyRnKgHEYrJMbGIBXpmcePd
 def Save_Watched_List(waxtCQihyRnKgHEYrJMbGIBXpmcejV,waxtCQihyRnKgHEYrJMbGIBXpmcePq,waxtCQihyRnKgHEYrJMbGIBXpmcejO):
  try:
   waxtCQihyRnKgHEYrJMbGIBXpmcePD=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%waxtCQihyRnKgHEYrJMbGIBXpmcePq))
   waxtCQihyRnKgHEYrJMbGIBXpmcePl=waxtCQihyRnKgHEYrJMbGIBXpmcejV.Load_List_File(waxtCQihyRnKgHEYrJMbGIBXpmcePq) 
   fp=waxtCQihyRnKgHEYrJMbGIBXpmceVf(waxtCQihyRnKgHEYrJMbGIBXpmcePD,'w',-1,'utf-8')
   waxtCQihyRnKgHEYrJMbGIBXpmcePT=urllib.parse.urlencode(waxtCQihyRnKgHEYrJMbGIBXpmcejO)
   waxtCQihyRnKgHEYrJMbGIBXpmcePT=waxtCQihyRnKgHEYrJMbGIBXpmcePT+'\n'
   fp.write(waxtCQihyRnKgHEYrJMbGIBXpmcePT)
   waxtCQihyRnKgHEYrJMbGIBXpmcePU=0
   for waxtCQihyRnKgHEYrJMbGIBXpmcePu in waxtCQihyRnKgHEYrJMbGIBXpmcePl:
    waxtCQihyRnKgHEYrJMbGIBXpmcePs=waxtCQihyRnKgHEYrJMbGIBXpmceVN(urllib.parse.parse_qsl(waxtCQihyRnKgHEYrJMbGIBXpmcePu))
    waxtCQihyRnKgHEYrJMbGIBXpmcePN=waxtCQihyRnKgHEYrJMbGIBXpmcejO.get('code').strip()
    waxtCQihyRnKgHEYrJMbGIBXpmcePv=waxtCQihyRnKgHEYrJMbGIBXpmcePs.get('code').strip()
    if waxtCQihyRnKgHEYrJMbGIBXpmcePN!=waxtCQihyRnKgHEYrJMbGIBXpmcePv:
     fp.write(waxtCQihyRnKgHEYrJMbGIBXpmcePu)
     waxtCQihyRnKgHEYrJMbGIBXpmcePU+=1
     if waxtCQihyRnKgHEYrJMbGIBXpmcePU>=50:break
   fp.close()
  except:
   waxtCQihyRnKgHEYrJMbGIBXpmceVT
 def Save_Searched_List(waxtCQihyRnKgHEYrJMbGIBXpmcejV,waxtCQihyRnKgHEYrJMbGIBXpmcePo):
  try:
   waxtCQihyRnKgHEYrJMbGIBXpmcePo=waxtCQihyRnKgHEYrJMbGIBXpmcePo.strip()
   waxtCQihyRnKgHEYrJMbGIBXpmcePl=waxtCQihyRnKgHEYrJMbGIBXpmcejV.Load_List_File('search') 
   fp=waxtCQihyRnKgHEYrJMbGIBXpmceVf(waxtCQihyRnKgHEYrJMbGIBXpmcejP,'w',-1,'utf-8')
   fp.write(waxtCQihyRnKgHEYrJMbGIBXpmcePo+'\n')
   waxtCQihyRnKgHEYrJMbGIBXpmcePU=0
   for waxtCQihyRnKgHEYrJMbGIBXpmcePu in waxtCQihyRnKgHEYrJMbGIBXpmcePl:
    waxtCQihyRnKgHEYrJMbGIBXpmcePu=waxtCQihyRnKgHEYrJMbGIBXpmcePu.strip()
    if waxtCQihyRnKgHEYrJMbGIBXpmcePo!=waxtCQihyRnKgHEYrJMbGIBXpmcePu:
     fp.write(waxtCQihyRnKgHEYrJMbGIBXpmcePu+'\n')
     waxtCQihyRnKgHEYrJMbGIBXpmcePU+=1
     if waxtCQihyRnKgHEYrJMbGIBXpmcePU>=50:break
   fp.close()
  except:
   waxtCQihyRnKgHEYrJMbGIBXpmceVT
 def dp_Search_History(waxtCQihyRnKgHEYrJMbGIBXpmcejV,args):
  waxtCQihyRnKgHEYrJMbGIBXpmcePf=waxtCQihyRnKgHEYrJMbGIBXpmcejV.Load_List_File('search')
  for waxtCQihyRnKgHEYrJMbGIBXpmceVj in waxtCQihyRnKgHEYrJMbGIBXpmcePf:
   waxtCQihyRnKgHEYrJMbGIBXpmceVj=waxtCQihyRnKgHEYrJMbGIBXpmceVj.strip()
   waxtCQihyRnKgHEYrJMbGIBXpmcekF={'mode':'LOCAL_SEARCH','search_key':waxtCQihyRnKgHEYrJMbGIBXpmceVj,'page':'1','historyyn':'Y',}
   waxtCQihyRnKgHEYrJMbGIBXpmceVk={'mode':'SEARCH_REMOVE','stype':'ONE','skey':waxtCQihyRnKgHEYrJMbGIBXpmceVj,}
   waxtCQihyRnKgHEYrJMbGIBXpmceVz=urllib.parse.urlencode(waxtCQihyRnKgHEYrJMbGIBXpmceVk)
   waxtCQihyRnKgHEYrJMbGIBXpmcezv=[('선택된 검색어 ( %s ) 삭제'%(waxtCQihyRnKgHEYrJMbGIBXpmceVj),'RunPlugin(plugin://plugin.video.coupangm/?%s)'%(waxtCQihyRnKgHEYrJMbGIBXpmceVz))]
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.add_dir(waxtCQihyRnKgHEYrJMbGIBXpmceVj,sublabel='',img=waxtCQihyRnKgHEYrJMbGIBXpmceVT,infoLabels=waxtCQihyRnKgHEYrJMbGIBXpmceVT,isFolder=waxtCQihyRnKgHEYrJMbGIBXpmceVu,params=waxtCQihyRnKgHEYrJMbGIBXpmcekF,ContextMenu=waxtCQihyRnKgHEYrJMbGIBXpmcezv)
  waxtCQihyRnKgHEYrJMbGIBXpmcezj={'plot':'검색목록 전체를 삭제합니다.'}
  waxtCQihyRnKgHEYrJMbGIBXpmcekz='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  waxtCQihyRnKgHEYrJMbGIBXpmcekF={'mode':'SEARCH_REMOVE','stype':'ALL','skey':'-',}
  waxtCQihyRnKgHEYrJMbGIBXpmcekV=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  waxtCQihyRnKgHEYrJMbGIBXpmcejV.add_dir(waxtCQihyRnKgHEYrJMbGIBXpmcekz,sublabel='',img=waxtCQihyRnKgHEYrJMbGIBXpmcekV,infoLabels=waxtCQihyRnKgHEYrJMbGIBXpmcezj,isFolder=waxtCQihyRnKgHEYrJMbGIBXpmceVU,params=waxtCQihyRnKgHEYrJMbGIBXpmcekF,isLink=waxtCQihyRnKgHEYrJMbGIBXpmceVu)
  xbmcplugin.endOfDirectory(waxtCQihyRnKgHEYrJMbGIBXpmcejV._addon_handle,cacheToDisc=waxtCQihyRnKgHEYrJMbGIBXpmceVU)
 def dp_Listfile_Delete(waxtCQihyRnKgHEYrJMbGIBXpmcejV,args):
  waxtCQihyRnKgHEYrJMbGIBXpmcePq=args.get('stype')
  waxtCQihyRnKgHEYrJMbGIBXpmceVA =args.get('skey')
  waxtCQihyRnKgHEYrJMbGIBXpmcejL=xbmcgui.Dialog()
  if waxtCQihyRnKgHEYrJMbGIBXpmcePq=='ALL':
   waxtCQihyRnKgHEYrJMbGIBXpmcekL=waxtCQihyRnKgHEYrJMbGIBXpmcejL.yesno(__language__(30911).encode('utf8'),__language__(30906).encode('utf8'))
  elif waxtCQihyRnKgHEYrJMbGIBXpmcePq=='ONE':
   waxtCQihyRnKgHEYrJMbGIBXpmcekL=waxtCQihyRnKgHEYrJMbGIBXpmcejL.yesno(__language__(30912).encode('utf8'),__language__(30906).encode('utf8'))
  elif waxtCQihyRnKgHEYrJMbGIBXpmcePq in['tvshow','movie']:
   waxtCQihyRnKgHEYrJMbGIBXpmcekL=waxtCQihyRnKgHEYrJMbGIBXpmcejL.yesno(__language__(30913).encode('utf8'),__language__(30906).encode('utf8'))
  if waxtCQihyRnKgHEYrJMbGIBXpmcekL==waxtCQihyRnKgHEYrJMbGIBXpmceVU:sys.exit()
  waxtCQihyRnKgHEYrJMbGIBXpmcejV.Delete_List_File(waxtCQihyRnKgHEYrJMbGIBXpmcePq,skey=waxtCQihyRnKgHEYrJMbGIBXpmceVA)
  xbmc.executebuiltin("Container.Refresh")
 def Delete_List_File(waxtCQihyRnKgHEYrJMbGIBXpmcejV,waxtCQihyRnKgHEYrJMbGIBXpmcePq,skey='-'):
  if waxtCQihyRnKgHEYrJMbGIBXpmcePq=='ALL':
   try:
    waxtCQihyRnKgHEYrJMbGIBXpmcePW=waxtCQihyRnKgHEYrJMbGIBXpmcejP
    fp=waxtCQihyRnKgHEYrJMbGIBXpmceVf(waxtCQihyRnKgHEYrJMbGIBXpmcePW,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    waxtCQihyRnKgHEYrJMbGIBXpmceVT
  elif waxtCQihyRnKgHEYrJMbGIBXpmcePq=='ONE':
   try:
    waxtCQihyRnKgHEYrJMbGIBXpmcePW=waxtCQihyRnKgHEYrJMbGIBXpmcejP
    waxtCQihyRnKgHEYrJMbGIBXpmcePl=waxtCQihyRnKgHEYrJMbGIBXpmcejV.Load_List_File('search') 
    fp=waxtCQihyRnKgHEYrJMbGIBXpmceVf(waxtCQihyRnKgHEYrJMbGIBXpmcePW,'w',-1,'utf-8')
    for waxtCQihyRnKgHEYrJMbGIBXpmcePu in waxtCQihyRnKgHEYrJMbGIBXpmcePl:
     if skey!=waxtCQihyRnKgHEYrJMbGIBXpmcePu.strip():
      fp.write(waxtCQihyRnKgHEYrJMbGIBXpmcePu)
    fp.close()
   except:
    waxtCQihyRnKgHEYrJMbGIBXpmceVT
  elif waxtCQihyRnKgHEYrJMbGIBXpmcePq in['tvshow','movie']:
   try:
    waxtCQihyRnKgHEYrJMbGIBXpmcePW=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%waxtCQihyRnKgHEYrJMbGIBXpmcePq))
    fp=waxtCQihyRnKgHEYrJMbGIBXpmceVf(waxtCQihyRnKgHEYrJMbGIBXpmcePW,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    waxtCQihyRnKgHEYrJMbGIBXpmceVT
 def dp_Watch_List(waxtCQihyRnKgHEYrJMbGIBXpmcejV,args):
  waxtCQihyRnKgHEYrJMbGIBXpmcePq =args.get('stype')
  if waxtCQihyRnKgHEYrJMbGIBXpmcePq in['',waxtCQihyRnKgHEYrJMbGIBXpmceVT]:
   for waxtCQihyRnKgHEYrJMbGIBXpmceVP in waxtCQihyRnKgHEYrJMbGIBXpmcejA:
    waxtCQihyRnKgHEYrJMbGIBXpmcekz=waxtCQihyRnKgHEYrJMbGIBXpmceVP.get('title')
    waxtCQihyRnKgHEYrJMbGIBXpmcekF={'mode':waxtCQihyRnKgHEYrJMbGIBXpmceVP.get('mode'),'stype':waxtCQihyRnKgHEYrJMbGIBXpmceVP.get('stype'),}
    waxtCQihyRnKgHEYrJMbGIBXpmcejV.add_dir(waxtCQihyRnKgHEYrJMbGIBXpmcekz,sublabel='',img='',infoLabels=waxtCQihyRnKgHEYrJMbGIBXpmceVT,isFolder=waxtCQihyRnKgHEYrJMbGIBXpmceVu,params=waxtCQihyRnKgHEYrJMbGIBXpmcekF)
   xbmcplugin.endOfDirectory(waxtCQihyRnKgHEYrJMbGIBXpmcejV._addon_handle)
  else:
   waxtCQihyRnKgHEYrJMbGIBXpmceVF=waxtCQihyRnKgHEYrJMbGIBXpmcejV.Load_List_File(waxtCQihyRnKgHEYrJMbGIBXpmcePq)
   for waxtCQihyRnKgHEYrJMbGIBXpmceVq in waxtCQihyRnKgHEYrJMbGIBXpmceVF:
    waxtCQihyRnKgHEYrJMbGIBXpmceVO=waxtCQihyRnKgHEYrJMbGIBXpmceVN(urllib.parse.parse_qsl(waxtCQihyRnKgHEYrJMbGIBXpmceVq))
    waxtCQihyRnKgHEYrJMbGIBXpmceAD =waxtCQihyRnKgHEYrJMbGIBXpmceVO.get('code').strip()
    waxtCQihyRnKgHEYrJMbGIBXpmcekz =waxtCQihyRnKgHEYrJMbGIBXpmceVO.get('title').strip()
    waxtCQihyRnKgHEYrJMbGIBXpmcezP =waxtCQihyRnKgHEYrJMbGIBXpmceVO.get('img').strip()
    waxtCQihyRnKgHEYrJMbGIBXpmcezV =waxtCQihyRnKgHEYrJMbGIBXpmceVO.get('asis').strip()
    try:
     waxtCQihyRnKgHEYrJMbGIBXpmcezP=waxtCQihyRnKgHEYrJMbGIBXpmcezP.replace('\'','\"')
     waxtCQihyRnKgHEYrJMbGIBXpmcezP=json.loads(waxtCQihyRnKgHEYrJMbGIBXpmcezP)
    except:
     waxtCQihyRnKgHEYrJMbGIBXpmceVT
    waxtCQihyRnKgHEYrJMbGIBXpmcezj={}
    waxtCQihyRnKgHEYrJMbGIBXpmcezj['plot']=waxtCQihyRnKgHEYrJMbGIBXpmcekz
    if waxtCQihyRnKgHEYrJMbGIBXpmcePq=='movie':
     waxtCQihyRnKgHEYrJMbGIBXpmcekF={'mode':'MOVIE','id':waxtCQihyRnKgHEYrJMbGIBXpmceAD,'asis':waxtCQihyRnKgHEYrJMbGIBXpmcezV,'title':waxtCQihyRnKgHEYrJMbGIBXpmcekz,'thumbnail':waxtCQihyRnKgHEYrJMbGIBXpmcezP,}
     waxtCQihyRnKgHEYrJMbGIBXpmcekq=waxtCQihyRnKgHEYrJMbGIBXpmceVU
    else:
     waxtCQihyRnKgHEYrJMbGIBXpmcekF={'mode':'SEASON_LIST','id':waxtCQihyRnKgHEYrJMbGIBXpmceAD,'asis':waxtCQihyRnKgHEYrJMbGIBXpmcezV,'title':waxtCQihyRnKgHEYrJMbGIBXpmcekz,'thumbnail':json.dumps(waxtCQihyRnKgHEYrJMbGIBXpmcezP,separators=(',',':')),}
     waxtCQihyRnKgHEYrJMbGIBXpmcekq=waxtCQihyRnKgHEYrJMbGIBXpmceVu
    waxtCQihyRnKgHEYrJMbGIBXpmcejV.add_dir(waxtCQihyRnKgHEYrJMbGIBXpmcekz,sublabel='',img=waxtCQihyRnKgHEYrJMbGIBXpmcezP,infoLabels=waxtCQihyRnKgHEYrJMbGIBXpmcezj,isFolder=waxtCQihyRnKgHEYrJMbGIBXpmcekq,params=waxtCQihyRnKgHEYrJMbGIBXpmcekF)
   waxtCQihyRnKgHEYrJMbGIBXpmcezj={'plot':'시청목록을 삭제합니다.'}
   waxtCQihyRnKgHEYrJMbGIBXpmcekz='*** 시청목록 삭제 ***'
   waxtCQihyRnKgHEYrJMbGIBXpmcekF={'mode':'MYVIEW_REMOVE','stype':waxtCQihyRnKgHEYrJMbGIBXpmcePq,'skey':'-',}
   waxtCQihyRnKgHEYrJMbGIBXpmcekV=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.add_dir(waxtCQihyRnKgHEYrJMbGIBXpmcekz,sublabel='',img=waxtCQihyRnKgHEYrJMbGIBXpmcekV,infoLabels=waxtCQihyRnKgHEYrJMbGIBXpmcezj,isFolder=waxtCQihyRnKgHEYrJMbGIBXpmceVU,params=waxtCQihyRnKgHEYrJMbGIBXpmcekF,isLink=waxtCQihyRnKgHEYrJMbGIBXpmceVu)
   if waxtCQihyRnKgHEYrJMbGIBXpmcePq=='movie':xbmcplugin.setContent(waxtCQihyRnKgHEYrJMbGIBXpmcejV._addon_handle,'movies')
   else:xbmcplugin.setContent(waxtCQihyRnKgHEYrJMbGIBXpmcejV._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(waxtCQihyRnKgHEYrJMbGIBXpmcejV._addon_handle,cacheToDisc=waxtCQihyRnKgHEYrJMbGIBXpmceVU)
 def dp_Set_Bookmark(waxtCQihyRnKgHEYrJMbGIBXpmcejV,args):
  waxtCQihyRnKgHEYrJMbGIBXpmceVo=urllib.parse.unquote(args.get('bm_param'))
  waxtCQihyRnKgHEYrJMbGIBXpmceVo=json.loads(waxtCQihyRnKgHEYrJMbGIBXpmceVo)
  waxtCQihyRnKgHEYrJMbGIBXpmceVL =waxtCQihyRnKgHEYrJMbGIBXpmceVo.get('videoid')
  waxtCQihyRnKgHEYrJMbGIBXpmceVS =waxtCQihyRnKgHEYrJMbGIBXpmceVo.get('vidtype')
  waxtCQihyRnKgHEYrJMbGIBXpmceVW =waxtCQihyRnKgHEYrJMbGIBXpmceVo.get('vtitle')
  waxtCQihyRnKgHEYrJMbGIBXpmcejL=xbmcgui.Dialog()
  waxtCQihyRnKgHEYrJMbGIBXpmcekL=waxtCQihyRnKgHEYrJMbGIBXpmcejL.yesno(__language__(30914).encode('utf8'),waxtCQihyRnKgHEYrJMbGIBXpmceVW+' \n\n'+__language__(30915))
  if waxtCQihyRnKgHEYrJMbGIBXpmcekL==waxtCQihyRnKgHEYrJMbGIBXpmceVU:return
  waxtCQihyRnKgHEYrJMbGIBXpmceVd=waxtCQihyRnKgHEYrJMbGIBXpmcejV.CoupangObj.GetBookmarkInfo(waxtCQihyRnKgHEYrJMbGIBXpmceVL,waxtCQihyRnKgHEYrJMbGIBXpmceVS)
  waxtCQihyRnKgHEYrJMbGIBXpmceVD=json.dumps(waxtCQihyRnKgHEYrJMbGIBXpmceVd)
  waxtCQihyRnKgHEYrJMbGIBXpmceVD=urllib.parse.quote(waxtCQihyRnKgHEYrJMbGIBXpmceVD)
  waxtCQihyRnKgHEYrJMbGIBXpmcezN ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(waxtCQihyRnKgHEYrJMbGIBXpmceVD)
  xbmc.executebuiltin(waxtCQihyRnKgHEYrJMbGIBXpmcezN)
 def coupang_main(waxtCQihyRnKgHEYrJMbGIBXpmcejV):
  waxtCQihyRnKgHEYrJMbGIBXpmcezU=waxtCQihyRnKgHEYrJMbGIBXpmcejV.main_params.get('mode',waxtCQihyRnKgHEYrJMbGIBXpmceVT)
  if waxtCQihyRnKgHEYrJMbGIBXpmcezU=='LOGOUT':
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.CP_logout()
   return
  waxtCQihyRnKgHEYrJMbGIBXpmcejV.option_check()
  if waxtCQihyRnKgHEYrJMbGIBXpmcezU is waxtCQihyRnKgHEYrJMbGIBXpmceVT:
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.dp_Main_List(waxtCQihyRnKgHEYrJMbGIBXpmcejV.main_params)
  elif waxtCQihyRnKgHEYrJMbGIBXpmcezU=='CATEGORY_GROUPLIST':
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.dp_Category_GroupList(waxtCQihyRnKgHEYrJMbGIBXpmcejV.main_params)
  elif waxtCQihyRnKgHEYrJMbGIBXpmcezU=='THEME_GROUPLIST':
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.dp_Theme_GroupList(waxtCQihyRnKgHEYrJMbGIBXpmcejV.main_params)
  elif waxtCQihyRnKgHEYrJMbGIBXpmcezU=='EVENT_GROUPLIST':
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.dp_Event_GroupList(waxtCQihyRnKgHEYrJMbGIBXpmcejV.main_params)
  elif waxtCQihyRnKgHEYrJMbGIBXpmcezU=='EVENT_GAMELIST':
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.dp_Event_GameList(waxtCQihyRnKgHEYrJMbGIBXpmcejV.main_params)
  elif waxtCQihyRnKgHEYrJMbGIBXpmcezU=='EVENT_LIST':
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.dp_Event_List(waxtCQihyRnKgHEYrJMbGIBXpmcejV.main_params)
  elif waxtCQihyRnKgHEYrJMbGIBXpmcezU=='CATEGORY_LIST':
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.dp_Category_List(waxtCQihyRnKgHEYrJMbGIBXpmcejV.main_params)
  elif waxtCQihyRnKgHEYrJMbGIBXpmcezU=='SEASON_LIST':
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.dp_Season_List(waxtCQihyRnKgHEYrJMbGIBXpmcejV.main_params)
  elif waxtCQihyRnKgHEYrJMbGIBXpmcezU=='EPISODE_LIST':
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.dp_Episode_List(waxtCQihyRnKgHEYrJMbGIBXpmcejV.main_params)
  elif waxtCQihyRnKgHEYrJMbGIBXpmcezU=='TEST':
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.dp_Test(waxtCQihyRnKgHEYrJMbGIBXpmcejV.main_params)
  elif waxtCQihyRnKgHEYrJMbGIBXpmcezU in['MOVIE','VOD','HIGHLIGHT','LIVE']:
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.play_VIDEO(waxtCQihyRnKgHEYrJMbGIBXpmcejV.main_params)
  elif waxtCQihyRnKgHEYrJMbGIBXpmcezU=='WATCH':
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.dp_Watch_List(waxtCQihyRnKgHEYrJMbGIBXpmcejV.main_params)
  elif waxtCQihyRnKgHEYrJMbGIBXpmcezU=='LOCAL_SEARCH':
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.dp_Search_List(waxtCQihyRnKgHEYrJMbGIBXpmcejV.main_params)
  elif waxtCQihyRnKgHEYrJMbGIBXpmcezU=='SEARCH_HISTORY':
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.dp_Search_History(waxtCQihyRnKgHEYrJMbGIBXpmcejV.main_params)
  elif waxtCQihyRnKgHEYrJMbGIBXpmcezU in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.dp_Listfile_Delete(waxtCQihyRnKgHEYrJMbGIBXpmcejV.main_params)
  elif waxtCQihyRnKgHEYrJMbGIBXpmcezU in['TOTAL_SEARCH','TOTAL_HISTORY']:
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.dp_Global_Search(waxtCQihyRnKgHEYrJMbGIBXpmcejV.main_params)
  elif waxtCQihyRnKgHEYrJMbGIBXpmcezU=='MENU_BOOKMARK':
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.dp_Bookmark_Menu(waxtCQihyRnKgHEYrJMbGIBXpmcejV.main_params)
  elif waxtCQihyRnKgHEYrJMbGIBXpmcezU=='SET_BOOKMARK':
   waxtCQihyRnKgHEYrJMbGIBXpmcejV.dp_Set_Bookmark(waxtCQihyRnKgHEYrJMbGIBXpmcejV.main_params)
  else:
   waxtCQihyRnKgHEYrJMbGIBXpmceVT
# Created by pyminifier (https://github.com/liftoff/pyminifier)
