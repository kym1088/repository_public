__author__="NightRain"
bnFpkfAaEHtzrChTwIcmJlsVqYPWjD=object
bnFpkfAaEHtzrChTwIcmJlsVqYPWjO=None
bnFpkfAaEHtzrChTwIcmJlsVqYPWjL=False
bnFpkfAaEHtzrChTwIcmJlsVqYPWjB=True
bnFpkfAaEHtzrChTwIcmJlsVqYPWje=type
bnFpkfAaEHtzrChTwIcmJlsVqYPWju=dict
bnFpkfAaEHtzrChTwIcmJlsVqYPWjy=getattr
bnFpkfAaEHtzrChTwIcmJlsVqYPWjx=int
bnFpkfAaEHtzrChTwIcmJlsVqYPWjX=list
bnFpkfAaEHtzrChTwIcmJlsVqYPWjd=open
bnFpkfAaEHtzrChTwIcmJlsVqYPWjU=Exception
bnFpkfAaEHtzrChTwIcmJlsVqYPWjv=str
bnFpkfAaEHtzrChTwIcmJlsVqYPWjR=id
bnFpkfAaEHtzrChTwIcmJlsVqYPWji=len
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import inputstreamhelper
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
bnFpkfAaEHtzrChTwIcmJlsVqYPWMO=[{'title':'오직 쿠팡플레이에서','mode':'CATEGORY_LIST','vType':'ORIGINAL','collectionId':'5c33c5ca-ee6f-45f8-a026-dd789a8b63cf'},{'title':'홈   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'ALL'},{'title':'TV   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'MOVIES'},{'title':'키즈 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'KIDS'},{'title':'생중계','mode':'EVENT_GROUPLIST','vType':'LIVE'},{'title':'TV   (테마별)','mode':'THEME_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (테마별)','mode':'THEME_GROUPLIST','vType':'MOVIES'},{'title':'키즈 (테마별)','mode':'THEME_GROUPLIST','vType':'KIDS'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},{'title':'(쿠팡) 검색','mode':'LOCAL_SEARCH','icon':'search.png'},{'title':'(쿠팡) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
bnFpkfAaEHtzrChTwIcmJlsVqYPWML=[{'title':'시리즈 시청내역','mode':'WATCH','stype':'tvshow'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},]
bnFpkfAaEHtzrChTwIcmJlsVqYPWMB={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
bnFpkfAaEHtzrChTwIcmJlsVqYPWMe=xbmcvfs.translatePath(os.path.join(__profile__,'coupang_searched.txt'))
from coupangCore import*
class bnFpkfAaEHtzrChTwIcmJlsVqYPWMD(bnFpkfAaEHtzrChTwIcmJlsVqYPWjD):
 def __init__(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj,bnFpkfAaEHtzrChTwIcmJlsVqYPWMu,bnFpkfAaEHtzrChTwIcmJlsVqYPWMy,bnFpkfAaEHtzrChTwIcmJlsVqYPWMx):
  bnFpkfAaEHtzrChTwIcmJlsVqYPWMj._addon_url =bnFpkfAaEHtzrChTwIcmJlsVqYPWMu
  bnFpkfAaEHtzrChTwIcmJlsVqYPWMj._addon_handle=bnFpkfAaEHtzrChTwIcmJlsVqYPWMy
  bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.main_params =bnFpkfAaEHtzrChTwIcmJlsVqYPWMx
  bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj =vekSHJwXmRtWDzKarfosnIlBNgMbTq() 
  bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.CP_COOKIE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_cookies.json'))
  bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.CP_DEVICE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_device.json'))
 def addon_noti(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj,sting):
  try:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMd=xbmcgui.Dialog()
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMd.notification(__addonname__,sting)
  except:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWjO
 def addon_log(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj,string):
  try:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMU=string.encode('utf-8','ignore')
  except:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMU='addonException: addon_log'
  bnFpkfAaEHtzrChTwIcmJlsVqYPWMv=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,bnFpkfAaEHtzrChTwIcmJlsVqYPWMU),level=bnFpkfAaEHtzrChTwIcmJlsVqYPWMv)
 def get_keyboard_input(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj,bnFpkfAaEHtzrChTwIcmJlsVqYPWDL):
  bnFpkfAaEHtzrChTwIcmJlsVqYPWMR=bnFpkfAaEHtzrChTwIcmJlsVqYPWjO
  kb=xbmc.Keyboard()
  kb.setHeading(bnFpkfAaEHtzrChTwIcmJlsVqYPWDL)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMR=kb.getText()
  return bnFpkfAaEHtzrChTwIcmJlsVqYPWMR
 def get_settings_account(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj):
  bnFpkfAaEHtzrChTwIcmJlsVqYPWMi=__addon__.getSetting('id')
  bnFpkfAaEHtzrChTwIcmJlsVqYPWMQ=__addon__.getSetting('pw')
  bnFpkfAaEHtzrChTwIcmJlsVqYPWMK=__addon__.getSetting('profile')
  return(bnFpkfAaEHtzrChTwIcmJlsVqYPWMi,bnFpkfAaEHtzrChTwIcmJlsVqYPWMQ,bnFpkfAaEHtzrChTwIcmJlsVqYPWMK)
 def get_settings_exclusion21(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj):
  bnFpkfAaEHtzrChTwIcmJlsVqYPWMS =__addon__.getSetting('exclusion21')
  if bnFpkfAaEHtzrChTwIcmJlsVqYPWMS=='false':
   return bnFpkfAaEHtzrChTwIcmJlsVqYPWjL
  else:
   return bnFpkfAaEHtzrChTwIcmJlsVqYPWjB
 def get_settings_totalsearch(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj):
  bnFpkfAaEHtzrChTwIcmJlsVqYPWMN =bnFpkfAaEHtzrChTwIcmJlsVqYPWjB if __addon__.getSetting('local_search')=='true' else bnFpkfAaEHtzrChTwIcmJlsVqYPWjL
  bnFpkfAaEHtzrChTwIcmJlsVqYPWMG=bnFpkfAaEHtzrChTwIcmJlsVqYPWjB if __addon__.getSetting('local_history')=='true' else bnFpkfAaEHtzrChTwIcmJlsVqYPWjL
  bnFpkfAaEHtzrChTwIcmJlsVqYPWMg =bnFpkfAaEHtzrChTwIcmJlsVqYPWjB if __addon__.getSetting('total_search')=='true' else bnFpkfAaEHtzrChTwIcmJlsVqYPWjL
  bnFpkfAaEHtzrChTwIcmJlsVqYPWMo=bnFpkfAaEHtzrChTwIcmJlsVqYPWjB if __addon__.getSetting('total_history')=='true' else bnFpkfAaEHtzrChTwIcmJlsVqYPWjL
  bnFpkfAaEHtzrChTwIcmJlsVqYPWDM=bnFpkfAaEHtzrChTwIcmJlsVqYPWjB if __addon__.getSetting('menu_bookmark')=='true' else bnFpkfAaEHtzrChTwIcmJlsVqYPWjL
  return(bnFpkfAaEHtzrChTwIcmJlsVqYPWMN,bnFpkfAaEHtzrChTwIcmJlsVqYPWMG,bnFpkfAaEHtzrChTwIcmJlsVqYPWMg,bnFpkfAaEHtzrChTwIcmJlsVqYPWMo,bnFpkfAaEHtzrChTwIcmJlsVqYPWDM)
 def get_settings_makebookmark(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj):
  return bnFpkfAaEHtzrChTwIcmJlsVqYPWjB if __addon__.getSetting('make_bookmark')=='true' else bnFpkfAaEHtzrChTwIcmJlsVqYPWjL
 def add_dir(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj,label,sublabel='',img='',infoLabels=bnFpkfAaEHtzrChTwIcmJlsVqYPWjO,isFolder=bnFpkfAaEHtzrChTwIcmJlsVqYPWjB,params='',isLink=bnFpkfAaEHtzrChTwIcmJlsVqYPWjL,ContextMenu=bnFpkfAaEHtzrChTwIcmJlsVqYPWjO):
  bnFpkfAaEHtzrChTwIcmJlsVqYPWDO='%s?%s'%(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj._addon_url,urllib.parse.urlencode(params))
  if sublabel:bnFpkfAaEHtzrChTwIcmJlsVqYPWDL='%s < %s >'%(label,sublabel)
  else: bnFpkfAaEHtzrChTwIcmJlsVqYPWDL=label
  if not img:img='DefaultFolder.png'
  bnFpkfAaEHtzrChTwIcmJlsVqYPWDB=xbmcgui.ListItem(bnFpkfAaEHtzrChTwIcmJlsVqYPWDL)
  if bnFpkfAaEHtzrChTwIcmJlsVqYPWje(img)==bnFpkfAaEHtzrChTwIcmJlsVqYPWju:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDB.setArt(img)
  else:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDB.setArt({'thumb':img,'poster':img})
  if bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.KodiVersion>=20:
   if infoLabels:bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.Set_InfoTag(bnFpkfAaEHtzrChTwIcmJlsVqYPWDB.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:bnFpkfAaEHtzrChTwIcmJlsVqYPWDB.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDB.setProperty('IsPlayable','true')
  if ContextMenu:bnFpkfAaEHtzrChTwIcmJlsVqYPWDB.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj._addon_handle,bnFpkfAaEHtzrChTwIcmJlsVqYPWDO,bnFpkfAaEHtzrChTwIcmJlsVqYPWDB,isFolder)
 def Set_InfoTag(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj,video_InfoTag:xbmc.InfoTagVideo,bnFpkfAaEHtzrChTwIcmJlsVqYPWDU):
  for bnFpkfAaEHtzrChTwIcmJlsVqYPWDe,value in bnFpkfAaEHtzrChTwIcmJlsVqYPWDU.items():
   if bnFpkfAaEHtzrChTwIcmJlsVqYPWMB[bnFpkfAaEHtzrChTwIcmJlsVqYPWDe]['type']=='string':
    bnFpkfAaEHtzrChTwIcmJlsVqYPWjy(video_InfoTag,bnFpkfAaEHtzrChTwIcmJlsVqYPWMB[bnFpkfAaEHtzrChTwIcmJlsVqYPWDe]['func'])(value)
   elif bnFpkfAaEHtzrChTwIcmJlsVqYPWMB[bnFpkfAaEHtzrChTwIcmJlsVqYPWDe]['type']=='int':
    if bnFpkfAaEHtzrChTwIcmJlsVqYPWje(value)==bnFpkfAaEHtzrChTwIcmJlsVqYPWjx:
     bnFpkfAaEHtzrChTwIcmJlsVqYPWDj=bnFpkfAaEHtzrChTwIcmJlsVqYPWjx(value)
    else:
     bnFpkfAaEHtzrChTwIcmJlsVqYPWDj=0
    bnFpkfAaEHtzrChTwIcmJlsVqYPWjy(video_InfoTag,bnFpkfAaEHtzrChTwIcmJlsVqYPWMB[bnFpkfAaEHtzrChTwIcmJlsVqYPWDe]['func'])(bnFpkfAaEHtzrChTwIcmJlsVqYPWDj)
   elif bnFpkfAaEHtzrChTwIcmJlsVqYPWMB[bnFpkfAaEHtzrChTwIcmJlsVqYPWDe]['type']=='actor':
    if value!=[]:
     bnFpkfAaEHtzrChTwIcmJlsVqYPWjy(video_InfoTag,bnFpkfAaEHtzrChTwIcmJlsVqYPWMB[bnFpkfAaEHtzrChTwIcmJlsVqYPWDe]['func'])([xbmc.Actor(name)for name in value])
   elif bnFpkfAaEHtzrChTwIcmJlsVqYPWMB[bnFpkfAaEHtzrChTwIcmJlsVqYPWDe]['type']=='list':
    if bnFpkfAaEHtzrChTwIcmJlsVqYPWje(value)==bnFpkfAaEHtzrChTwIcmJlsVqYPWjX:
     bnFpkfAaEHtzrChTwIcmJlsVqYPWjy(video_InfoTag,bnFpkfAaEHtzrChTwIcmJlsVqYPWMB[bnFpkfAaEHtzrChTwIcmJlsVqYPWDe]['func'])(value)
    else:
     bnFpkfAaEHtzrChTwIcmJlsVqYPWjy(video_InfoTag,bnFpkfAaEHtzrChTwIcmJlsVqYPWMB[bnFpkfAaEHtzrChTwIcmJlsVqYPWDe]['func'])([value])
 def dp_Main_List(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj,args):
  (bnFpkfAaEHtzrChTwIcmJlsVqYPWMN,bnFpkfAaEHtzrChTwIcmJlsVqYPWMG,bnFpkfAaEHtzrChTwIcmJlsVqYPWMg,bnFpkfAaEHtzrChTwIcmJlsVqYPWMo,bnFpkfAaEHtzrChTwIcmJlsVqYPWDM)=bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.get_settings_totalsearch()
  for bnFpkfAaEHtzrChTwIcmJlsVqYPWDu in bnFpkfAaEHtzrChTwIcmJlsVqYPWMO:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDL=bnFpkfAaEHtzrChTwIcmJlsVqYPWDu.get('title')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDy=''
   if bnFpkfAaEHtzrChTwIcmJlsVqYPWDu.get('mode')=='LOCAL_SEARCH' and bnFpkfAaEHtzrChTwIcmJlsVqYPWMN ==bnFpkfAaEHtzrChTwIcmJlsVqYPWjL:continue
   elif bnFpkfAaEHtzrChTwIcmJlsVqYPWDu.get('mode')=='SEARCH_HISTORY' and bnFpkfAaEHtzrChTwIcmJlsVqYPWMG==bnFpkfAaEHtzrChTwIcmJlsVqYPWjL:continue
   elif bnFpkfAaEHtzrChTwIcmJlsVqYPWDu.get('mode')=='TOTAL_SEARCH' and bnFpkfAaEHtzrChTwIcmJlsVqYPWMg ==bnFpkfAaEHtzrChTwIcmJlsVqYPWjL:continue
   elif bnFpkfAaEHtzrChTwIcmJlsVqYPWDu.get('mode')=='TOTAL_HISTORY' and bnFpkfAaEHtzrChTwIcmJlsVqYPWMo==bnFpkfAaEHtzrChTwIcmJlsVqYPWjL:continue
   elif bnFpkfAaEHtzrChTwIcmJlsVqYPWDu.get('mode')=='MENU_BOOKMARK' and bnFpkfAaEHtzrChTwIcmJlsVqYPWDM==bnFpkfAaEHtzrChTwIcmJlsVqYPWjL:continue
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDx={'mode':bnFpkfAaEHtzrChTwIcmJlsVqYPWDu.get('mode'),'vType':bnFpkfAaEHtzrChTwIcmJlsVqYPWDu.get('vType'),'collectionId':bnFpkfAaEHtzrChTwIcmJlsVqYPWDu.get('collectionId'),'page':'1',}
   if bnFpkfAaEHtzrChTwIcmJlsVqYPWDu.get('mode')=='LOCAL_SEARCH':bnFpkfAaEHtzrChTwIcmJlsVqYPWDx['historyyn']='Y' 
   if bnFpkfAaEHtzrChTwIcmJlsVqYPWDu.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    bnFpkfAaEHtzrChTwIcmJlsVqYPWDX=bnFpkfAaEHtzrChTwIcmJlsVqYPWjL
    bnFpkfAaEHtzrChTwIcmJlsVqYPWDd =bnFpkfAaEHtzrChTwIcmJlsVqYPWjB
   else:
    bnFpkfAaEHtzrChTwIcmJlsVqYPWDX=bnFpkfAaEHtzrChTwIcmJlsVqYPWjB
    bnFpkfAaEHtzrChTwIcmJlsVqYPWDd =bnFpkfAaEHtzrChTwIcmJlsVqYPWjL
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDU={'title':bnFpkfAaEHtzrChTwIcmJlsVqYPWDL,'plot':bnFpkfAaEHtzrChTwIcmJlsVqYPWDL}
   if bnFpkfAaEHtzrChTwIcmJlsVqYPWDu.get('mode')=='XXX':bnFpkfAaEHtzrChTwIcmJlsVqYPWDU=bnFpkfAaEHtzrChTwIcmJlsVqYPWjO
   if 'icon' in bnFpkfAaEHtzrChTwIcmJlsVqYPWDu:bnFpkfAaEHtzrChTwIcmJlsVqYPWDy=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',bnFpkfAaEHtzrChTwIcmJlsVqYPWDu.get('icon')) 
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.add_dir(bnFpkfAaEHtzrChTwIcmJlsVqYPWDL,sublabel='',img=bnFpkfAaEHtzrChTwIcmJlsVqYPWDy,infoLabels=bnFpkfAaEHtzrChTwIcmJlsVqYPWDU,isFolder=bnFpkfAaEHtzrChTwIcmJlsVqYPWDX,params=bnFpkfAaEHtzrChTwIcmJlsVqYPWDx,isLink=bnFpkfAaEHtzrChTwIcmJlsVqYPWDd)
  xbmcplugin.endOfDirectory(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj._addon_handle)
 def dp_Test(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj,args):
  bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.addon_noti('test')
 def CP_logout(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj):
  bnFpkfAaEHtzrChTwIcmJlsVqYPWMd=xbmcgui.Dialog()
  bnFpkfAaEHtzrChTwIcmJlsVqYPWDR=bnFpkfAaEHtzrChTwIcmJlsVqYPWMd.yesno(__language__(30905).encode('utf8'),__language__(30906).encode('utf8'))
  if bnFpkfAaEHtzrChTwIcmJlsVqYPWDR==bnFpkfAaEHtzrChTwIcmJlsVqYPWjL:return 
  if os.path.isfile(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.CP_COOKIE_FILENAME):os.remove(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.CP_COOKIE_FILENAME)
  bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.addon_noti(__language__(30904).encode('utf-8'))
 def option_check(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj):
  (bnFpkfAaEHtzrChTwIcmJlsVqYPWMi,bnFpkfAaEHtzrChTwIcmJlsVqYPWMQ,bnFpkfAaEHtzrChTwIcmJlsVqYPWMK)=bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.get_settings_account()
  if bnFpkfAaEHtzrChTwIcmJlsVqYPWMi=='' or bnFpkfAaEHtzrChTwIcmJlsVqYPWMQ=='':
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMd=xbmcgui.Dialog()
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDR=bnFpkfAaEHtzrChTwIcmJlsVqYPWMd.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if bnFpkfAaEHtzrChTwIcmJlsVqYPWDR==bnFpkfAaEHtzrChTwIcmJlsVqYPWjB:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.cookiefile_check()==bnFpkfAaEHtzrChTwIcmJlsVqYPWjL:
   if bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CP_login(bnFpkfAaEHtzrChTwIcmJlsVqYPWMi,bnFpkfAaEHtzrChTwIcmJlsVqYPWMQ,bnFpkfAaEHtzrChTwIcmJlsVqYPWMK)==bnFpkfAaEHtzrChTwIcmJlsVqYPWjL:
    bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.addon_noti(__language__(30903).encode('utf8'))
    sys.exit()
  else:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.Get_CP_profile(bnFpkfAaEHtzrChTwIcmJlsVqYPWMK,limit_days=bnFpkfAaEHtzrChTwIcmJlsVqYPWjx(__addon__.getSetting('cache_ttl')),re_check=bnFpkfAaEHtzrChTwIcmJlsVqYPWjB)
 def cookiefile_check(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj):
  bnFpkfAaEHtzrChTwIcmJlsVqYPWDQ={}
  try: 
   fp=bnFpkfAaEHtzrChTwIcmJlsVqYPWjd(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.CP_COOKIE_FILENAME,'r',-1,'utf-8')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDQ= json.load(fp)
   fp.close()
  except bnFpkfAaEHtzrChTwIcmJlsVqYPWjU as exception:
   return bnFpkfAaEHtzrChTwIcmJlsVqYPWjL
  bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.CP=bnFpkfAaEHtzrChTwIcmJlsVqYPWDQ
  (bnFpkfAaEHtzrChTwIcmJlsVqYPWMi,bnFpkfAaEHtzrChTwIcmJlsVqYPWMQ,bnFpkfAaEHtzrChTwIcmJlsVqYPWMK)=bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.get_settings_account()
  (bnFpkfAaEHtzrChTwIcmJlsVqYPWDK,bnFpkfAaEHtzrChTwIcmJlsVqYPWDS,bnFpkfAaEHtzrChTwIcmJlsVqYPWDN)=bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.Load_session_acount()
  if bnFpkfAaEHtzrChTwIcmJlsVqYPWMi!=bnFpkfAaEHtzrChTwIcmJlsVqYPWDK or bnFpkfAaEHtzrChTwIcmJlsVqYPWMQ!=bnFpkfAaEHtzrChTwIcmJlsVqYPWDS or bnFpkfAaEHtzrChTwIcmJlsVqYPWMK!=bnFpkfAaEHtzrChTwIcmJlsVqYPWjv(bnFpkfAaEHtzrChTwIcmJlsVqYPWDN):
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.Init_CP()
   return bnFpkfAaEHtzrChTwIcmJlsVqYPWjL
  bnFpkfAaEHtzrChTwIcmJlsVqYPWDG =bnFpkfAaEHtzrChTwIcmJlsVqYPWjx(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.Get_Now_Datetime().strftime('%Y%m%d'))
  bnFpkfAaEHtzrChTwIcmJlsVqYPWDg=bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.CP['SESSION']['limitdate']
  bnFpkfAaEHtzrChTwIcmJlsVqYPWDo =bnFpkfAaEHtzrChTwIcmJlsVqYPWjx(re.sub('-','',bnFpkfAaEHtzrChTwIcmJlsVqYPWDg))
  if bnFpkfAaEHtzrChTwIcmJlsVqYPWDo<bnFpkfAaEHtzrChTwIcmJlsVqYPWDG:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.Init_CP()
   return bnFpkfAaEHtzrChTwIcmJlsVqYPWjL
  return bnFpkfAaEHtzrChTwIcmJlsVqYPWjB
 def CP_login(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj,bnFpkfAaEHtzrChTwIcmJlsVqYPWMi,bnFpkfAaEHtzrChTwIcmJlsVqYPWMQ,bnFpkfAaEHtzrChTwIcmJlsVqYPWMK):
  if bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.Get_CP_Login(bnFpkfAaEHtzrChTwIcmJlsVqYPWMi,bnFpkfAaEHtzrChTwIcmJlsVqYPWMQ,bnFpkfAaEHtzrChTwIcmJlsVqYPWMK)==bnFpkfAaEHtzrChTwIcmJlsVqYPWjL:return bnFpkfAaEHtzrChTwIcmJlsVqYPWjL
  if bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.Get_CP_profile(bnFpkfAaEHtzrChTwIcmJlsVqYPWMK,limit_days=bnFpkfAaEHtzrChTwIcmJlsVqYPWjx(__addon__.getSetting('cache_ttl')),re_check=bnFpkfAaEHtzrChTwIcmJlsVqYPWjL)==bnFpkfAaEHtzrChTwIcmJlsVqYPWjL:return bnFpkfAaEHtzrChTwIcmJlsVqYPWjL
  return bnFpkfAaEHtzrChTwIcmJlsVqYPWjB
 def dp_Category_GroupList(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj,args):
  bnFpkfAaEHtzrChTwIcmJlsVqYPWOM =args.get('vType') 
  bnFpkfAaEHtzrChTwIcmJlsVqYPWOD=bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.Get_Category_GroupList(bnFpkfAaEHtzrChTwIcmJlsVqYPWOM)
  for bnFpkfAaEHtzrChTwIcmJlsVqYPWOL in bnFpkfAaEHtzrChTwIcmJlsVqYPWOD:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDL =bnFpkfAaEHtzrChTwIcmJlsVqYPWOL.get('title')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOB=bnFpkfAaEHtzrChTwIcmJlsVqYPWOL.get('pre_title')
   if bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.get_settings_exclusion21()==bnFpkfAaEHtzrChTwIcmJlsVqYPWjB and bnFpkfAaEHtzrChTwIcmJlsVqYPWDL=='성인':continue
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOe={'mediatype':'tvshow','plot':bnFpkfAaEHtzrChTwIcmJlsVqYPWOB,}
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDx={'mode':'CATEGORY_LIST','collectionId':bnFpkfAaEHtzrChTwIcmJlsVqYPWOL.get('collectionId'),'vType':bnFpkfAaEHtzrChTwIcmJlsVqYPWOL.get('category'),'page':'1',}
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.add_dir(bnFpkfAaEHtzrChTwIcmJlsVqYPWDL,sublabel='',img='',infoLabels=bnFpkfAaEHtzrChTwIcmJlsVqYPWOe,isFolder=bnFpkfAaEHtzrChTwIcmJlsVqYPWjB,params=bnFpkfAaEHtzrChTwIcmJlsVqYPWDx)
  xbmcplugin.endOfDirectory(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj._addon_handle,cacheToDisc=bnFpkfAaEHtzrChTwIcmJlsVqYPWjL)
 def dp_Theme_GroupList(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj,args):
  bnFpkfAaEHtzrChTwIcmJlsVqYPWOM =args.get('vType') 
  bnFpkfAaEHtzrChTwIcmJlsVqYPWOD=bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.Get_Theme_GroupList(bnFpkfAaEHtzrChTwIcmJlsVqYPWOM)
  for bnFpkfAaEHtzrChTwIcmJlsVqYPWOL in bnFpkfAaEHtzrChTwIcmJlsVqYPWOD:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDL =bnFpkfAaEHtzrChTwIcmJlsVqYPWOL.get('title')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOB=bnFpkfAaEHtzrChTwIcmJlsVqYPWOL.get('pre_title')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOe={'mediatype':'tvshow','plot':bnFpkfAaEHtzrChTwIcmJlsVqYPWOB,}
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDx={'mode':'CATEGORY_LIST','collectionId':bnFpkfAaEHtzrChTwIcmJlsVqYPWOL.get('collectionId'),'vType':bnFpkfAaEHtzrChTwIcmJlsVqYPWOL.get('category'),'page':'1',}
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.add_dir(bnFpkfAaEHtzrChTwIcmJlsVqYPWDL,sublabel='',img='',infoLabels=bnFpkfAaEHtzrChTwIcmJlsVqYPWOe,isFolder=bnFpkfAaEHtzrChTwIcmJlsVqYPWjB,params=bnFpkfAaEHtzrChTwIcmJlsVqYPWDx)
  xbmcplugin.endOfDirectory(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj._addon_handle,cacheToDisc=bnFpkfAaEHtzrChTwIcmJlsVqYPWjL)
 def dp_Event_GroupList(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj,args):
  bnFpkfAaEHtzrChTwIcmJlsVqYPWOD=bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.Get_Event_GroupList()
  for bnFpkfAaEHtzrChTwIcmJlsVqYPWOL in bnFpkfAaEHtzrChTwIcmJlsVqYPWOD:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDL =bnFpkfAaEHtzrChTwIcmJlsVqYPWOL.get('title')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOB=bnFpkfAaEHtzrChTwIcmJlsVqYPWOL.get('pre_title')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOe={'mediatype':'tvshow','plot':bnFpkfAaEHtzrChTwIcmJlsVqYPWOB,}
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDx={'mode':'EVENT_GAMELIST','collectionId':bnFpkfAaEHtzrChTwIcmJlsVqYPWOL.get('collectionId'),'vType':'LIVE',}
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.add_dir(bnFpkfAaEHtzrChTwIcmJlsVqYPWDL,sublabel='',img='',infoLabels=bnFpkfAaEHtzrChTwIcmJlsVqYPWOe,isFolder=bnFpkfAaEHtzrChTwIcmJlsVqYPWjB,params=bnFpkfAaEHtzrChTwIcmJlsVqYPWDx)
  xbmcplugin.endOfDirectory(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj._addon_handle,cacheToDisc=bnFpkfAaEHtzrChTwIcmJlsVqYPWjL)
 def dp_Event_GameList(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj,args):
  bnFpkfAaEHtzrChTwIcmJlsVqYPWOM =args.get('vType') 
  bnFpkfAaEHtzrChTwIcmJlsVqYPWOu =args.get('collectionId')
  bnFpkfAaEHtzrChTwIcmJlsVqYPWOD=bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.Get_Event_GameList(bnFpkfAaEHtzrChTwIcmJlsVqYPWOu)
  for bnFpkfAaEHtzrChTwIcmJlsVqYPWOL in bnFpkfAaEHtzrChTwIcmJlsVqYPWOD:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDL =bnFpkfAaEHtzrChTwIcmJlsVqYPWOL.get('title')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWjR =bnFpkfAaEHtzrChTwIcmJlsVqYPWOL.get('id')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOy =bnFpkfAaEHtzrChTwIcmJlsVqYPWOL.get('thumbnail')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOx =bnFpkfAaEHtzrChTwIcmJlsVqYPWOL.get('asis') 
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOX =bnFpkfAaEHtzrChTwIcmJlsVqYPWOL.get('addInfo')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOd =bnFpkfAaEHtzrChTwIcmJlsVqYPWOL.get('starttm')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOe={'mediatype':'tvshow','title':bnFpkfAaEHtzrChTwIcmJlsVqYPWDL,'plot':bnFpkfAaEHtzrChTwIcmJlsVqYPWOX,}
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDx={'mode':'EVENT_LIST','id':bnFpkfAaEHtzrChTwIcmJlsVqYPWjR,'asis':bnFpkfAaEHtzrChTwIcmJlsVqYPWOx,'title':bnFpkfAaEHtzrChTwIcmJlsVqYPWDL,}
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.add_dir(bnFpkfAaEHtzrChTwIcmJlsVqYPWDL,sublabel=bnFpkfAaEHtzrChTwIcmJlsVqYPWOd,img=bnFpkfAaEHtzrChTwIcmJlsVqYPWOy,infoLabels=bnFpkfAaEHtzrChTwIcmJlsVqYPWOe,isFolder=bnFpkfAaEHtzrChTwIcmJlsVqYPWjB,params=bnFpkfAaEHtzrChTwIcmJlsVqYPWDx,ContextMenu=bnFpkfAaEHtzrChTwIcmJlsVqYPWjO)
  xbmcplugin.setContent(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj._addon_handle,cacheToDisc=bnFpkfAaEHtzrChTwIcmJlsVqYPWjL)
 def dp_Event_List(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj,args):
  bnFpkfAaEHtzrChTwIcmJlsVqYPWOU=args.get('id')
  bnFpkfAaEHtzrChTwIcmJlsVqYPWOD=bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.Get_Event_List(bnFpkfAaEHtzrChTwIcmJlsVqYPWOU)
  for bnFpkfAaEHtzrChTwIcmJlsVqYPWOL in bnFpkfAaEHtzrChTwIcmJlsVqYPWOD:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDL =bnFpkfAaEHtzrChTwIcmJlsVqYPWOL.get('title')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWjR =bnFpkfAaEHtzrChTwIcmJlsVqYPWOL.get('id')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOy =bnFpkfAaEHtzrChTwIcmJlsVqYPWOL.get('thumbnail')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOx =bnFpkfAaEHtzrChTwIcmJlsVqYPWOL.get('asis') 
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOv =bnFpkfAaEHtzrChTwIcmJlsVqYPWOL.get('duration')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOd =bnFpkfAaEHtzrChTwIcmJlsVqYPWOL.get('starttm')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOe={'mediatype':'episode','title':bnFpkfAaEHtzrChTwIcmJlsVqYPWDL,'plot':bnFpkfAaEHtzrChTwIcmJlsVqYPWOx,'duration':bnFpkfAaEHtzrChTwIcmJlsVqYPWOv,}
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDx={'mode':bnFpkfAaEHtzrChTwIcmJlsVqYPWOx,'id':bnFpkfAaEHtzrChTwIcmJlsVqYPWjR,'asis':bnFpkfAaEHtzrChTwIcmJlsVqYPWOx,'title':bnFpkfAaEHtzrChTwIcmJlsVqYPWDL,}
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.add_dir(bnFpkfAaEHtzrChTwIcmJlsVqYPWDL,sublabel=bnFpkfAaEHtzrChTwIcmJlsVqYPWOd,img=bnFpkfAaEHtzrChTwIcmJlsVqYPWOy,infoLabels=bnFpkfAaEHtzrChTwIcmJlsVqYPWOe,isFolder=bnFpkfAaEHtzrChTwIcmJlsVqYPWjL,params=bnFpkfAaEHtzrChTwIcmJlsVqYPWDx,ContextMenu=bnFpkfAaEHtzrChTwIcmJlsVqYPWjO)
  xbmcplugin.setContent(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj._addon_handle,cacheToDisc=bnFpkfAaEHtzrChTwIcmJlsVqYPWjL)
 def dp_Category_List(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj,args):
  bnFpkfAaEHtzrChTwIcmJlsVqYPWOM =args.get('vType') 
  bnFpkfAaEHtzrChTwIcmJlsVqYPWOu =args.get('collectionId')
  bnFpkfAaEHtzrChTwIcmJlsVqYPWOR =bnFpkfAaEHtzrChTwIcmJlsVqYPWjx(args.get('page'))
  bnFpkfAaEHtzrChTwIcmJlsVqYPWOD,bnFpkfAaEHtzrChTwIcmJlsVqYPWOi=bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.Get_Category_List(bnFpkfAaEHtzrChTwIcmJlsVqYPWOM,bnFpkfAaEHtzrChTwIcmJlsVqYPWOu,bnFpkfAaEHtzrChTwIcmJlsVqYPWOR)
  for bnFpkfAaEHtzrChTwIcmJlsVqYPWOL in bnFpkfAaEHtzrChTwIcmJlsVqYPWOD:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDL =bnFpkfAaEHtzrChTwIcmJlsVqYPWOL.get('title')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWjR =bnFpkfAaEHtzrChTwIcmJlsVqYPWOL.get('id')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOy =bnFpkfAaEHtzrChTwIcmJlsVqYPWOL.get('thumbnail')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOQ =bnFpkfAaEHtzrChTwIcmJlsVqYPWOL.get('mpaa')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOv =bnFpkfAaEHtzrChTwIcmJlsVqYPWOL.get('duration')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOx =bnFpkfAaEHtzrChTwIcmJlsVqYPWOL.get('asis')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOK =bnFpkfAaEHtzrChTwIcmJlsVqYPWOL.get('badge')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOS =bnFpkfAaEHtzrChTwIcmJlsVqYPWOL.get('year')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWON=bnFpkfAaEHtzrChTwIcmJlsVqYPWOL.get('seasonList')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOG =bnFpkfAaEHtzrChTwIcmJlsVqYPWOL.get('genreList')
   if bnFpkfAaEHtzrChTwIcmJlsVqYPWOx in['TVSHOW','EDUCATION']: 
    bnFpkfAaEHtzrChTwIcmJlsVqYPWOg ='SEASON_LIST'
    bnFpkfAaEHtzrChTwIcmJlsVqYPWOe={'mediatype':'tvshow','title':bnFpkfAaEHtzrChTwIcmJlsVqYPWDL,'mpaa':bnFpkfAaEHtzrChTwIcmJlsVqYPWOQ,'genre':bnFpkfAaEHtzrChTwIcmJlsVqYPWOG,'year':bnFpkfAaEHtzrChTwIcmJlsVqYPWOS,'plot':'Year : %s\nSeason : %s'%(bnFpkfAaEHtzrChTwIcmJlsVqYPWOS,bnFpkfAaEHtzrChTwIcmJlsVqYPWON),}
    bnFpkfAaEHtzrChTwIcmJlsVqYPWDX =bnFpkfAaEHtzrChTwIcmJlsVqYPWjB
   else:
    bnFpkfAaEHtzrChTwIcmJlsVqYPWOg ='MOVIE'
    bnFpkfAaEHtzrChTwIcmJlsVqYPWOe={'mediatype':'movie','title':bnFpkfAaEHtzrChTwIcmJlsVqYPWDL,'mpaa':bnFpkfAaEHtzrChTwIcmJlsVqYPWOQ,'genre':bnFpkfAaEHtzrChTwIcmJlsVqYPWOG,'duration':bnFpkfAaEHtzrChTwIcmJlsVqYPWOv,'year':bnFpkfAaEHtzrChTwIcmJlsVqYPWOS,'plot':'(%s)'%(bnFpkfAaEHtzrChTwIcmJlsVqYPWOQ),}
    bnFpkfAaEHtzrChTwIcmJlsVqYPWDX =bnFpkfAaEHtzrChTwIcmJlsVqYPWjL
    bnFpkfAaEHtzrChTwIcmJlsVqYPWDL +=' (%s)'%(bnFpkfAaEHtzrChTwIcmJlsVqYPWjv(bnFpkfAaEHtzrChTwIcmJlsVqYPWOS))
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDx={'mode':bnFpkfAaEHtzrChTwIcmJlsVqYPWOg,'id':bnFpkfAaEHtzrChTwIcmJlsVqYPWjR,'asis':bnFpkfAaEHtzrChTwIcmJlsVqYPWOx,'seasonList':bnFpkfAaEHtzrChTwIcmJlsVqYPWON,'title':bnFpkfAaEHtzrChTwIcmJlsVqYPWDL,'thumbnail':bnFpkfAaEHtzrChTwIcmJlsVqYPWOy,'year':bnFpkfAaEHtzrChTwIcmJlsVqYPWOS,}
   if bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.get_settings_makebookmark():
    bnFpkfAaEHtzrChTwIcmJlsVqYPWOo={'videoid':bnFpkfAaEHtzrChTwIcmJlsVqYPWjR,'vidtype':'movie' if bnFpkfAaEHtzrChTwIcmJlsVqYPWOM=='MOVIES' else 'tvshow','vtitle':bnFpkfAaEHtzrChTwIcmJlsVqYPWDL,'vsubtitle':'',}
    bnFpkfAaEHtzrChTwIcmJlsVqYPWLM=json.dumps(bnFpkfAaEHtzrChTwIcmJlsVqYPWOo)
    bnFpkfAaEHtzrChTwIcmJlsVqYPWLM=urllib.parse.quote(bnFpkfAaEHtzrChTwIcmJlsVqYPWLM)
    bnFpkfAaEHtzrChTwIcmJlsVqYPWLD='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(bnFpkfAaEHtzrChTwIcmJlsVqYPWLM)
    bnFpkfAaEHtzrChTwIcmJlsVqYPWLO=[('(통합) 찜 영상에 추가',bnFpkfAaEHtzrChTwIcmJlsVqYPWLD)]
   else:
    bnFpkfAaEHtzrChTwIcmJlsVqYPWLO=bnFpkfAaEHtzrChTwIcmJlsVqYPWjO
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.add_dir(bnFpkfAaEHtzrChTwIcmJlsVqYPWDL,sublabel=bnFpkfAaEHtzrChTwIcmJlsVqYPWOK,img=bnFpkfAaEHtzrChTwIcmJlsVqYPWOy,infoLabels=bnFpkfAaEHtzrChTwIcmJlsVqYPWOe,isFolder=bnFpkfAaEHtzrChTwIcmJlsVqYPWDX,params=bnFpkfAaEHtzrChTwIcmJlsVqYPWDx,ContextMenu=bnFpkfAaEHtzrChTwIcmJlsVqYPWLO)
  if bnFpkfAaEHtzrChTwIcmJlsVqYPWOi:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDx['mode'] ='CATEGORY_LIST' 
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDx['collectionId']=bnFpkfAaEHtzrChTwIcmJlsVqYPWOu 
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDx['vType'] =bnFpkfAaEHtzrChTwIcmJlsVqYPWOM 
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDx['page'] =bnFpkfAaEHtzrChTwIcmJlsVqYPWjv(bnFpkfAaEHtzrChTwIcmJlsVqYPWOR+1)
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDL='[B]%s >>[/B]'%'다음 페이지'
   bnFpkfAaEHtzrChTwIcmJlsVqYPWLB=bnFpkfAaEHtzrChTwIcmJlsVqYPWjv(bnFpkfAaEHtzrChTwIcmJlsVqYPWOR+1)
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDy=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.add_dir(bnFpkfAaEHtzrChTwIcmJlsVqYPWDL,sublabel=bnFpkfAaEHtzrChTwIcmJlsVqYPWLB,img=bnFpkfAaEHtzrChTwIcmJlsVqYPWDy,infoLabels=bnFpkfAaEHtzrChTwIcmJlsVqYPWjO,isFolder=bnFpkfAaEHtzrChTwIcmJlsVqYPWjB,params=bnFpkfAaEHtzrChTwIcmJlsVqYPWDx)
  if bnFpkfAaEHtzrChTwIcmJlsVqYPWOM=='TVSHOWS':xbmcplugin.setContent(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj._addon_handle,'tvshows')
  else:xbmcplugin.setContent(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj._addon_handle,'movies')
  xbmcplugin.endOfDirectory(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj._addon_handle,cacheToDisc=bnFpkfAaEHtzrChTwIcmJlsVqYPWjL)
 def dp_Season_List(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj,args):
  bnFpkfAaEHtzrChTwIcmJlsVqYPWLe =args.get('title')
  bnFpkfAaEHtzrChTwIcmJlsVqYPWLj =args.get('id')
  bnFpkfAaEHtzrChTwIcmJlsVqYPWOx =args.get('asis')
  bnFpkfAaEHtzrChTwIcmJlsVqYPWON =args.get('seasonList')
  bnFpkfAaEHtzrChTwIcmJlsVqYPWOy =args.get('thumbnail')
  bnFpkfAaEHtzrChTwIcmJlsVqYPWOS =args.get('year')
  if bnFpkfAaEHtzrChTwIcmJlsVqYPWON in['',bnFpkfAaEHtzrChTwIcmJlsVqYPWjO]:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWON=bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.Get_vInfo(bnFpkfAaEHtzrChTwIcmJlsVqYPWLj).get('seasonList')
  if bnFpkfAaEHtzrChTwIcmJlsVqYPWji(bnFpkfAaEHtzrChTwIcmJlsVqYPWON.split(','))>1:
   for bnFpkfAaEHtzrChTwIcmJlsVqYPWLu in bnFpkfAaEHtzrChTwIcmJlsVqYPWON.split(','):
    bnFpkfAaEHtzrChTwIcmJlsVqYPWDL='시즌 '+bnFpkfAaEHtzrChTwIcmJlsVqYPWLu
    bnFpkfAaEHtzrChTwIcmJlsVqYPWOe={'mediatype':'tvshow','plot':'%s (%s)'%(bnFpkfAaEHtzrChTwIcmJlsVqYPWLe,bnFpkfAaEHtzrChTwIcmJlsVqYPWOS),}
    bnFpkfAaEHtzrChTwIcmJlsVqYPWDx={'mode':'EPISODE_LIST','programid':bnFpkfAaEHtzrChTwIcmJlsVqYPWLj,'programnm':bnFpkfAaEHtzrChTwIcmJlsVqYPWLe,'season':bnFpkfAaEHtzrChTwIcmJlsVqYPWLu,'asis':bnFpkfAaEHtzrChTwIcmJlsVqYPWOx,'programimg':bnFpkfAaEHtzrChTwIcmJlsVqYPWOy,}
    bnFpkfAaEHtzrChTwIcmJlsVqYPWLy=bnFpkfAaEHtzrChTwIcmJlsVqYPWOy.replace('\'','\"')
    bnFpkfAaEHtzrChTwIcmJlsVqYPWLy=json.loads(bnFpkfAaEHtzrChTwIcmJlsVqYPWLy)
    bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.add_dir(bnFpkfAaEHtzrChTwIcmJlsVqYPWDL,sublabel='',img=bnFpkfAaEHtzrChTwIcmJlsVqYPWLy,infoLabels=bnFpkfAaEHtzrChTwIcmJlsVqYPWOe,isFolder=bnFpkfAaEHtzrChTwIcmJlsVqYPWjB,params=bnFpkfAaEHtzrChTwIcmJlsVqYPWDx)
   xbmcplugin.setContent(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj._addon_handle,cacheToDisc=bnFpkfAaEHtzrChTwIcmJlsVqYPWjL)
  else:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWLx={'programid':bnFpkfAaEHtzrChTwIcmJlsVqYPWLj,'programnm':bnFpkfAaEHtzrChTwIcmJlsVqYPWLe,'season':bnFpkfAaEHtzrChTwIcmJlsVqYPWON,'programimg':bnFpkfAaEHtzrChTwIcmJlsVqYPWOy,}
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.dp_Episode_List(bnFpkfAaEHtzrChTwIcmJlsVqYPWLx)
 def dp_Episode_List(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj,args):
  bnFpkfAaEHtzrChTwIcmJlsVqYPWLj =args.get('programid')
  bnFpkfAaEHtzrChTwIcmJlsVqYPWLe =args.get('programnm')
  bnFpkfAaEHtzrChTwIcmJlsVqYPWLX =args.get('season')
  bnFpkfAaEHtzrChTwIcmJlsVqYPWLd =args.get('programimg')
  bnFpkfAaEHtzrChTwIcmJlsVqYPWLU=bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.Get_Episode_List(bnFpkfAaEHtzrChTwIcmJlsVqYPWLj,bnFpkfAaEHtzrChTwIcmJlsVqYPWLX)
  for bnFpkfAaEHtzrChTwIcmJlsVqYPWLu in bnFpkfAaEHtzrChTwIcmJlsVqYPWLU:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWLv =bnFpkfAaEHtzrChTwIcmJlsVqYPWLu.get('title')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWLR =bnFpkfAaEHtzrChTwIcmJlsVqYPWLu.get('id')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOx =bnFpkfAaEHtzrChTwIcmJlsVqYPWLu.get('asis')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOy =bnFpkfAaEHtzrChTwIcmJlsVqYPWLu.get('thumbnail')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOQ =bnFpkfAaEHtzrChTwIcmJlsVqYPWLu.get('mpaa')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOv =bnFpkfAaEHtzrChTwIcmJlsVqYPWLu.get('duration')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOS =bnFpkfAaEHtzrChTwIcmJlsVqYPWLu.get('year')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWLi =bnFpkfAaEHtzrChTwIcmJlsVqYPWLu.get('episode')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOG =bnFpkfAaEHtzrChTwIcmJlsVqYPWLu.get('genreList')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWLQ =bnFpkfAaEHtzrChTwIcmJlsVqYPWLu.get('desc')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWLK ='%sx%s'%(bnFpkfAaEHtzrChTwIcmJlsVqYPWLX,bnFpkfAaEHtzrChTwIcmJlsVqYPWLi)
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDL ='%s. %s'%(bnFpkfAaEHtzrChTwIcmJlsVqYPWLK,bnFpkfAaEHtzrChTwIcmJlsVqYPWLv)
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOe={'mediatype':'episode','mpaa':bnFpkfAaEHtzrChTwIcmJlsVqYPWOQ,'genre':bnFpkfAaEHtzrChTwIcmJlsVqYPWOG,'duration':bnFpkfAaEHtzrChTwIcmJlsVqYPWOv,'year':bnFpkfAaEHtzrChTwIcmJlsVqYPWOS,'plot':'%s (%s)\n\n%s'%(bnFpkfAaEHtzrChTwIcmJlsVqYPWLe,bnFpkfAaEHtzrChTwIcmJlsVqYPWLK,bnFpkfAaEHtzrChTwIcmJlsVqYPWLQ),}
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDx={'mode':'VOD','programid':bnFpkfAaEHtzrChTwIcmJlsVqYPWLj,'programnm':bnFpkfAaEHtzrChTwIcmJlsVqYPWLe,'title':bnFpkfAaEHtzrChTwIcmJlsVqYPWDL,'season':bnFpkfAaEHtzrChTwIcmJlsVqYPWLX,'id':bnFpkfAaEHtzrChTwIcmJlsVqYPWLR,'asis':bnFpkfAaEHtzrChTwIcmJlsVqYPWOx,'thumbnail':bnFpkfAaEHtzrChTwIcmJlsVqYPWOy,'programimg':bnFpkfAaEHtzrChTwIcmJlsVqYPWLd,}
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.add_dir(bnFpkfAaEHtzrChTwIcmJlsVqYPWDL,sublabel='',img=bnFpkfAaEHtzrChTwIcmJlsVqYPWOy,infoLabels=bnFpkfAaEHtzrChTwIcmJlsVqYPWOe,isFolder=bnFpkfAaEHtzrChTwIcmJlsVqYPWjL,params=bnFpkfAaEHtzrChTwIcmJlsVqYPWDx)
  xbmcplugin.setContent(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj._addon_handle,cacheToDisc=bnFpkfAaEHtzrChTwIcmJlsVqYPWjL)
 def play_VIDEO(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj,args):
  bnFpkfAaEHtzrChTwIcmJlsVqYPWLS =args.get('id')
  bnFpkfAaEHtzrChTwIcmJlsVqYPWOx =args.get('asis')
  if bnFpkfAaEHtzrChTwIcmJlsVqYPWOx in['HIGHLIGHT']:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWLN,bnFpkfAaEHtzrChTwIcmJlsVqYPWLG=bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.GetEventURL(bnFpkfAaEHtzrChTwIcmJlsVqYPWLS,bnFpkfAaEHtzrChTwIcmJlsVqYPWOx)
  elif bnFpkfAaEHtzrChTwIcmJlsVqYPWOx in['LIVE']:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWLN,bnFpkfAaEHtzrChTwIcmJlsVqYPWLG=bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.GetEventURL_Live(bnFpkfAaEHtzrChTwIcmJlsVqYPWLS,bnFpkfAaEHtzrChTwIcmJlsVqYPWOx)
  else:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWLN,bnFpkfAaEHtzrChTwIcmJlsVqYPWLG=bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.GetBroadURL(bnFpkfAaEHtzrChTwIcmJlsVqYPWLS)
  bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.addon_log('asis, url : %s - %s - %s'%(bnFpkfAaEHtzrChTwIcmJlsVqYPWOx,bnFpkfAaEHtzrChTwIcmJlsVqYPWLS,bnFpkfAaEHtzrChTwIcmJlsVqYPWLN))
  if bnFpkfAaEHtzrChTwIcmJlsVqYPWLN=='':
   if bnFpkfAaEHtzrChTwIcmJlsVqYPWLG=='':
    bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.addon_noti(__language__(30907).encode('utf8'))
   else:
    bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.addon_log('drm_license_1 : %s'%(bnFpkfAaEHtzrChTwIcmJlsVqYPWLG))
    bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.addon_noti(bnFpkfAaEHtzrChTwIcmJlsVqYPWLG)
   return
  else:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.addon_log('drm_license : %s'%(bnFpkfAaEHtzrChTwIcmJlsVqYPWLG))
  '''
  tmp_cookie = 'PCID=%s;token=%s;member_srl=%s;NEXT_LOCALE=%s;session_web_id=%s;device_id=%s' % (self.CoupangObj.CP['COOKIES']['PCID'], self.CoupangObj.CP['COOKIES']['token'], self.CoupangObj.CP['COOKIES']['member_srl'], self.CoupangObj.CP['COOKIES']['NEXT_LOCALE'], self.CoupangObj.CP['COOKIES']['session_web_id'], self.CoupangObj.CP['COOKIES']['device_id'], )
  '''  
  if bnFpkfAaEHtzrChTwIcmJlsVqYPWOx in['EPISODE']:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWLg='https://www.coupangplay.com/play/{}/episode?titleId={}&type=EPISODE&sourceType=page_discover_title_detail%3Apage_discover_feed'.format(bnFpkfAaEHtzrChTwIcmJlsVqYPWLS,bnFpkfAaEHtzrChTwIcmJlsVqYPWLS)
  elif bnFpkfAaEHtzrChTwIcmJlsVqYPWOx in['MOVIE']:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWLg='https://www.coupangplay.com/play/{}/movie?sourceType=page_discover_feed'.format(bnFpkfAaEHtzrChTwIcmJlsVqYPWLS)
  else:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWLg='https://www.coupangplay.com/play/'+bnFpkfAaEHtzrChTwIcmJlsVqYPWLS 
  bnFpkfAaEHtzrChTwIcmJlsVqYPWLo,bnFpkfAaEHtzrChTwIcmJlsVqYPWBM,bnFpkfAaEHtzrChTwIcmJlsVqYPWBD=bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.Make_authHeader()
  bnFpkfAaEHtzrChTwIcmJlsVqYPWBO=bnFpkfAaEHtzrChTwIcmJlsVqYPWLN 
  bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.addon_log('tobe, surl : %s'%(bnFpkfAaEHtzrChTwIcmJlsVqYPWBO))
  bnFpkfAaEHtzrChTwIcmJlsVqYPWBL=xbmcgui.ListItem(path=bnFpkfAaEHtzrChTwIcmJlsVqYPWBO)
  bnFpkfAaEHtzrChTwIcmJlsVqYPWBe=bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.Get_Url_PostFix(bnFpkfAaEHtzrChTwIcmJlsVqYPWLN) 
  bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.addon_log('post_fix : '+bnFpkfAaEHtzrChTwIcmJlsVqYPWBe)
  if bnFpkfAaEHtzrChTwIcmJlsVqYPWBe=='m3u8':
   bnFpkfAaEHtzrChTwIcmJlsVqYPWBj ='hls' 
  else:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWBj ='mpd' 
  bnFpkfAaEHtzrChTwIcmJlsVqYPWBu={'user-agent':bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.USER_AGENT,'referer':bnFpkfAaEHtzrChTwIcmJlsVqYPWLg,'traceparent':bnFpkfAaEHtzrChTwIcmJlsVqYPWLo,'tracestate':bnFpkfAaEHtzrChTwIcmJlsVqYPWBM,'newrelic':bnFpkfAaEHtzrChTwIcmJlsVqYPWBD,}
  bnFpkfAaEHtzrChTwIcmJlsVqYPWBy =bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.CP['COOKIES']
  bnFpkfAaEHtzrChTwIcmJlsVqYPWBx=bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.make_stream_header(bnFpkfAaEHtzrChTwIcmJlsVqYPWBu,bnFpkfAaEHtzrChTwIcmJlsVqYPWBy)
  if bnFpkfAaEHtzrChTwIcmJlsVqYPWLG:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWBX =bnFpkfAaEHtzrChTwIcmJlsVqYPWLG 
   bnFpkfAaEHtzrChTwIcmJlsVqYPWBd ='com.widevine.alpha'
   bnFpkfAaEHtzrChTwIcmJlsVqYPWBU=bnFpkfAaEHtzrChTwIcmJlsVqYPWBX+'|'+bnFpkfAaEHtzrChTwIcmJlsVqYPWBx+'|R{SSM}|'
   inputstreamhelper.Helper(bnFpkfAaEHtzrChTwIcmJlsVqYPWBj,drm='com.widevine.alpha').check_inputstream()
   bnFpkfAaEHtzrChTwIcmJlsVqYPWBL.setProperty('inputstream','inputstream.adaptive')
   if bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.KodiVersion<=20:
    bnFpkfAaEHtzrChTwIcmJlsVqYPWBL.setProperty('inputstream.adaptive.manifest_type',bnFpkfAaEHtzrChTwIcmJlsVqYPWBj)
   bnFpkfAaEHtzrChTwIcmJlsVqYPWBL.setProperty('inputstream.adaptive.license_type',bnFpkfAaEHtzrChTwIcmJlsVqYPWBd)
   bnFpkfAaEHtzrChTwIcmJlsVqYPWBL.setProperty('inputstream.adaptive.license_key',bnFpkfAaEHtzrChTwIcmJlsVqYPWBU)
   bnFpkfAaEHtzrChTwIcmJlsVqYPWBL.setProperty('inputstream.adaptive.stream_headers',bnFpkfAaEHtzrChTwIcmJlsVqYPWBx)
   bnFpkfAaEHtzrChTwIcmJlsVqYPWBL.setProperty('inputstream.adaptive.manifest_headers',bnFpkfAaEHtzrChTwIcmJlsVqYPWBx)
   bnFpkfAaEHtzrChTwIcmJlsVqYPWBL.setMimeType('application/dash+xml')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWBL.setContentLookup(bnFpkfAaEHtzrChTwIcmJlsVqYPWjL)
  else:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWBL.setContentLookup(bnFpkfAaEHtzrChTwIcmJlsVqYPWjL)
   bnFpkfAaEHtzrChTwIcmJlsVqYPWBL.setMimeType('application/x-mpegURL')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWBL.setProperty('inputstream','inputstream.adaptive')
   if bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.KodiVersion<=20:
    bnFpkfAaEHtzrChTwIcmJlsVqYPWBL.setProperty('inputstream.adaptive.manifest_type',bnFpkfAaEHtzrChTwIcmJlsVqYPWBj)
   bnFpkfAaEHtzrChTwIcmJlsVqYPWBL.setProperty('inputstream.adaptive.stream_headers',bnFpkfAaEHtzrChTwIcmJlsVqYPWBx)
   bnFpkfAaEHtzrChTwIcmJlsVqYPWBL.setProperty('inputstream.adaptive.manifest_headers',bnFpkfAaEHtzrChTwIcmJlsVqYPWBx)
  xbmcplugin.setResolvedUrl(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj._addon_handle,bnFpkfAaEHtzrChTwIcmJlsVqYPWjB,bnFpkfAaEHtzrChTwIcmJlsVqYPWBL)
  try:
   if bnFpkfAaEHtzrChTwIcmJlsVqYPWOx=='MOVIE':
    bnFpkfAaEHtzrChTwIcmJlsVqYPWBR='movie'
    bnFpkfAaEHtzrChTwIcmJlsVqYPWDx={'code':bnFpkfAaEHtzrChTwIcmJlsVqYPWLS,'asis':bnFpkfAaEHtzrChTwIcmJlsVqYPWOx,'title':args.get('title'),'img':args.get('thumbnail'),}
    bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.Save_Watched_List(bnFpkfAaEHtzrChTwIcmJlsVqYPWBR,bnFpkfAaEHtzrChTwIcmJlsVqYPWDx)
   elif bnFpkfAaEHtzrChTwIcmJlsVqYPWOx=='EPISODE':
    bnFpkfAaEHtzrChTwIcmJlsVqYPWBR='tvshow'
    bnFpkfAaEHtzrChTwIcmJlsVqYPWDx={'code':args.get('programid'),'asis':bnFpkfAaEHtzrChTwIcmJlsVqYPWOx,'title':'%s <%s>'%(args.get('title'),args.get('programnm')),'img':args.get('programimg'),}
    bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.Save_Watched_List(bnFpkfAaEHtzrChTwIcmJlsVqYPWBR,bnFpkfAaEHtzrChTwIcmJlsVqYPWDx)
  except:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWjO
 def dp_Global_Search(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj,args):
  bnFpkfAaEHtzrChTwIcmJlsVqYPWOg=args.get('mode')
  if bnFpkfAaEHtzrChTwIcmJlsVqYPWOg=='TOTAL_SEARCH':
   bnFpkfAaEHtzrChTwIcmJlsVqYPWBi='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWBi='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(bnFpkfAaEHtzrChTwIcmJlsVqYPWBi)
 def dp_Bookmark_Menu(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj,args):
  bnFpkfAaEHtzrChTwIcmJlsVqYPWBi='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(bnFpkfAaEHtzrChTwIcmJlsVqYPWBi)
 def dp_Search_List(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj,args):
  bnFpkfAaEHtzrChTwIcmJlsVqYPWOR =bnFpkfAaEHtzrChTwIcmJlsVqYPWjx(args.get('page'))
  if 'search_key' in args:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWBQ=args.get('search_key')
  else:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWBQ=bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.get_keyboard_input(__language__(30908).encode('utf-8'))
   if not bnFpkfAaEHtzrChTwIcmJlsVqYPWBQ:
    return
  bnFpkfAaEHtzrChTwIcmJlsVqYPWBK,bnFpkfAaEHtzrChTwIcmJlsVqYPWOi=bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.Get_Search_List(bnFpkfAaEHtzrChTwIcmJlsVqYPWBQ,bnFpkfAaEHtzrChTwIcmJlsVqYPWOR)
  for bnFpkfAaEHtzrChTwIcmJlsVqYPWBS in bnFpkfAaEHtzrChTwIcmJlsVqYPWBK:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWjR =bnFpkfAaEHtzrChTwIcmJlsVqYPWBS.get('id')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDL =bnFpkfAaEHtzrChTwIcmJlsVqYPWBS.get('title')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOx =bnFpkfAaEHtzrChTwIcmJlsVqYPWBS.get('asis')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOy =bnFpkfAaEHtzrChTwIcmJlsVqYPWBS.get('thumbnail')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOQ =bnFpkfAaEHtzrChTwIcmJlsVqYPWBS.get('mpaa')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOS =bnFpkfAaEHtzrChTwIcmJlsVqYPWBS.get('year')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOv =bnFpkfAaEHtzrChTwIcmJlsVqYPWBS.get('duration')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOK =bnFpkfAaEHtzrChTwIcmJlsVqYPWBS.get('badge')
   if bnFpkfAaEHtzrChTwIcmJlsVqYPWOx=='TVSHOW': 
    bnFpkfAaEHtzrChTwIcmJlsVqYPWOg ='SEASON_LIST'
    bnFpkfAaEHtzrChTwIcmJlsVqYPWOe={'mediatype':'tvshow','title':bnFpkfAaEHtzrChTwIcmJlsVqYPWDL,'mpaa':bnFpkfAaEHtzrChTwIcmJlsVqYPWOQ,'year':bnFpkfAaEHtzrChTwIcmJlsVqYPWOS,'plot':'Year : %s'%(bnFpkfAaEHtzrChTwIcmJlsVqYPWOS),}
    bnFpkfAaEHtzrChTwIcmJlsVqYPWDX =bnFpkfAaEHtzrChTwIcmJlsVqYPWjB
   elif bnFpkfAaEHtzrChTwIcmJlsVqYPWOx=='MOVIE':
    bnFpkfAaEHtzrChTwIcmJlsVqYPWOg ='MOVIE'
    bnFpkfAaEHtzrChTwIcmJlsVqYPWOe={'mediatype':'movie','title':bnFpkfAaEHtzrChTwIcmJlsVqYPWDL,'mpaa':bnFpkfAaEHtzrChTwIcmJlsVqYPWOQ,'duration':bnFpkfAaEHtzrChTwIcmJlsVqYPWOv,'year':bnFpkfAaEHtzrChTwIcmJlsVqYPWOS,'plot':'(%s)'%(bnFpkfAaEHtzrChTwIcmJlsVqYPWOQ),}
    bnFpkfAaEHtzrChTwIcmJlsVqYPWDX =bnFpkfAaEHtzrChTwIcmJlsVqYPWjL
    bnFpkfAaEHtzrChTwIcmJlsVqYPWDL +=' (%s)'%(bnFpkfAaEHtzrChTwIcmJlsVqYPWjv(bnFpkfAaEHtzrChTwIcmJlsVqYPWOS))
   elif bnFpkfAaEHtzrChTwIcmJlsVqYPWOx=='HIGHLIGHT':
    bnFpkfAaEHtzrChTwIcmJlsVqYPWOg ='HIGHLIGHT'
    bnFpkfAaEHtzrChTwIcmJlsVqYPWOe={'mediatype':'episode','title':bnFpkfAaEHtzrChTwIcmJlsVqYPWDL,'duration':bnFpkfAaEHtzrChTwIcmJlsVqYPWOv,'plot':bnFpkfAaEHtzrChTwIcmJlsVqYPWOg,}
    bnFpkfAaEHtzrChTwIcmJlsVqYPWDX =bnFpkfAaEHtzrChTwIcmJlsVqYPWjL
   elif bnFpkfAaEHtzrChTwIcmJlsVqYPWOx=='LIVE':
    bnFpkfAaEHtzrChTwIcmJlsVqYPWOg ='LIVE'
    bnFpkfAaEHtzrChTwIcmJlsVqYPWOe={'mediatype':'episode','title':bnFpkfAaEHtzrChTwIcmJlsVqYPWDL,'plot':bnFpkfAaEHtzrChTwIcmJlsVqYPWOg,}
    bnFpkfAaEHtzrChTwIcmJlsVqYPWDX =bnFpkfAaEHtzrChTwIcmJlsVqYPWjL
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDx={'mode':bnFpkfAaEHtzrChTwIcmJlsVqYPWOg,'id':bnFpkfAaEHtzrChTwIcmJlsVqYPWjR,'asis':bnFpkfAaEHtzrChTwIcmJlsVqYPWOx,'seasonList':'','title':bnFpkfAaEHtzrChTwIcmJlsVqYPWDL,'thumbnail':json.dumps(bnFpkfAaEHtzrChTwIcmJlsVqYPWOy,separators=(',',':')),'year':bnFpkfAaEHtzrChTwIcmJlsVqYPWOS,}
   if bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.get_settings_makebookmark()and bnFpkfAaEHtzrChTwIcmJlsVqYPWOx not in['HIGHLIGHT','']:
    bnFpkfAaEHtzrChTwIcmJlsVqYPWOo={'videoid':bnFpkfAaEHtzrChTwIcmJlsVqYPWjR,'vidtype':'movie' if bnFpkfAaEHtzrChTwIcmJlsVqYPWOx=='MOVIE' else 'tvshow','vtitle':bnFpkfAaEHtzrChTwIcmJlsVqYPWDL,'vsubtitle':'',}
    bnFpkfAaEHtzrChTwIcmJlsVqYPWLM=json.dumps(bnFpkfAaEHtzrChTwIcmJlsVqYPWOo)
    bnFpkfAaEHtzrChTwIcmJlsVqYPWLM=urllib.parse.quote(bnFpkfAaEHtzrChTwIcmJlsVqYPWLM)
    bnFpkfAaEHtzrChTwIcmJlsVqYPWLD='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(bnFpkfAaEHtzrChTwIcmJlsVqYPWLM)
    bnFpkfAaEHtzrChTwIcmJlsVqYPWLO=[('(통합) 찜 영상에 추가',bnFpkfAaEHtzrChTwIcmJlsVqYPWLD)]
   else:
    bnFpkfAaEHtzrChTwIcmJlsVqYPWLO=bnFpkfAaEHtzrChTwIcmJlsVqYPWjO
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.add_dir(bnFpkfAaEHtzrChTwIcmJlsVqYPWDL,sublabel=bnFpkfAaEHtzrChTwIcmJlsVqYPWOK,img=bnFpkfAaEHtzrChTwIcmJlsVqYPWOy,infoLabels=bnFpkfAaEHtzrChTwIcmJlsVqYPWOe,isFolder=bnFpkfAaEHtzrChTwIcmJlsVqYPWDX,params=bnFpkfAaEHtzrChTwIcmJlsVqYPWDx,ContextMenu=bnFpkfAaEHtzrChTwIcmJlsVqYPWLO)
  if bnFpkfAaEHtzrChTwIcmJlsVqYPWOi:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDx={}
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDx['mode'] ='LOCAL_SEARCH'
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDx['search_key']=bnFpkfAaEHtzrChTwIcmJlsVqYPWBQ
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDx['page'] =bnFpkfAaEHtzrChTwIcmJlsVqYPWjv(bnFpkfAaEHtzrChTwIcmJlsVqYPWOR+1)
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDL='[B]%s >>[/B]'%'다음 페이지'
   bnFpkfAaEHtzrChTwIcmJlsVqYPWLB=bnFpkfAaEHtzrChTwIcmJlsVqYPWjv(bnFpkfAaEHtzrChTwIcmJlsVqYPWOR+1)
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDy=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.add_dir(bnFpkfAaEHtzrChTwIcmJlsVqYPWDL,sublabel=bnFpkfAaEHtzrChTwIcmJlsVqYPWLB,img=bnFpkfAaEHtzrChTwIcmJlsVqYPWDy,infoLabels=bnFpkfAaEHtzrChTwIcmJlsVqYPWjO,isFolder=bnFpkfAaEHtzrChTwIcmJlsVqYPWjB,params=bnFpkfAaEHtzrChTwIcmJlsVqYPWDx)
  xbmcplugin.setContent(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj._addon_handle,'movies')
  xbmcplugin.endOfDirectory(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj._addon_handle,cacheToDisc=bnFpkfAaEHtzrChTwIcmJlsVqYPWjB)
  if args.get('historyyn')=='Y':bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.Save_Searched_List(bnFpkfAaEHtzrChTwIcmJlsVqYPWBQ)
 def Load_List_File(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj,bnFpkfAaEHtzrChTwIcmJlsVqYPWBR): 
  try:
   if bnFpkfAaEHtzrChTwIcmJlsVqYPWBR=='search':
    bnFpkfAaEHtzrChTwIcmJlsVqYPWBN=bnFpkfAaEHtzrChTwIcmJlsVqYPWMe
   elif bnFpkfAaEHtzrChTwIcmJlsVqYPWBR in['tvshow','movie']:
    bnFpkfAaEHtzrChTwIcmJlsVqYPWBN=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%bnFpkfAaEHtzrChTwIcmJlsVqYPWBR))
   else:
    return[]
   fp=bnFpkfAaEHtzrChTwIcmJlsVqYPWjd(bnFpkfAaEHtzrChTwIcmJlsVqYPWBN,'r',-1,'utf-8')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWBG=fp.readlines()
   fp.close()
  except:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWBG=[]
  return bnFpkfAaEHtzrChTwIcmJlsVqYPWBG
 def Save_Watched_List(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj,bnFpkfAaEHtzrChTwIcmJlsVqYPWBR,bnFpkfAaEHtzrChTwIcmJlsVqYPWMx):
  try:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWBg=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%bnFpkfAaEHtzrChTwIcmJlsVqYPWBR))
   bnFpkfAaEHtzrChTwIcmJlsVqYPWBo=bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.Load_List_File(bnFpkfAaEHtzrChTwIcmJlsVqYPWBR) 
   fp=bnFpkfAaEHtzrChTwIcmJlsVqYPWjd(bnFpkfAaEHtzrChTwIcmJlsVqYPWBg,'w',-1,'utf-8')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWeM=urllib.parse.urlencode(bnFpkfAaEHtzrChTwIcmJlsVqYPWMx)
   bnFpkfAaEHtzrChTwIcmJlsVqYPWeM=bnFpkfAaEHtzrChTwIcmJlsVqYPWeM+'\n'
   fp.write(bnFpkfAaEHtzrChTwIcmJlsVqYPWeM)
   bnFpkfAaEHtzrChTwIcmJlsVqYPWeD=0
   for bnFpkfAaEHtzrChTwIcmJlsVqYPWeO in bnFpkfAaEHtzrChTwIcmJlsVqYPWBo:
    bnFpkfAaEHtzrChTwIcmJlsVqYPWeL=bnFpkfAaEHtzrChTwIcmJlsVqYPWju(urllib.parse.parse_qsl(bnFpkfAaEHtzrChTwIcmJlsVqYPWeO))
    bnFpkfAaEHtzrChTwIcmJlsVqYPWeB=bnFpkfAaEHtzrChTwIcmJlsVqYPWMx.get('code').strip()
    bnFpkfAaEHtzrChTwIcmJlsVqYPWej=bnFpkfAaEHtzrChTwIcmJlsVqYPWeL.get('code').strip()
    if bnFpkfAaEHtzrChTwIcmJlsVqYPWeB!=bnFpkfAaEHtzrChTwIcmJlsVqYPWej:
     fp.write(bnFpkfAaEHtzrChTwIcmJlsVqYPWeO)
     bnFpkfAaEHtzrChTwIcmJlsVqYPWeD+=1
     if bnFpkfAaEHtzrChTwIcmJlsVqYPWeD>=50:break
   fp.close()
  except:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWjO
 def Save_Searched_List(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj,bnFpkfAaEHtzrChTwIcmJlsVqYPWBQ):
  try:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWBQ=bnFpkfAaEHtzrChTwIcmJlsVqYPWBQ.strip()
   bnFpkfAaEHtzrChTwIcmJlsVqYPWBo=bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.Load_List_File('search') 
   fp=bnFpkfAaEHtzrChTwIcmJlsVqYPWjd(bnFpkfAaEHtzrChTwIcmJlsVqYPWMe,'w',-1,'utf-8')
   fp.write(bnFpkfAaEHtzrChTwIcmJlsVqYPWBQ+'\n')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWeD=0
   for bnFpkfAaEHtzrChTwIcmJlsVqYPWeO in bnFpkfAaEHtzrChTwIcmJlsVqYPWBo:
    bnFpkfAaEHtzrChTwIcmJlsVqYPWeO=bnFpkfAaEHtzrChTwIcmJlsVqYPWeO.strip()
    if bnFpkfAaEHtzrChTwIcmJlsVqYPWBQ!=bnFpkfAaEHtzrChTwIcmJlsVqYPWeO:
     fp.write(bnFpkfAaEHtzrChTwIcmJlsVqYPWeO+'\n')
     bnFpkfAaEHtzrChTwIcmJlsVqYPWeD+=1
     if bnFpkfAaEHtzrChTwIcmJlsVqYPWeD>=50:break
   fp.close()
  except:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWjO
 def dp_Search_History(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj,args):
  bnFpkfAaEHtzrChTwIcmJlsVqYPWeu=bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.Load_List_File('search')
  for bnFpkfAaEHtzrChTwIcmJlsVqYPWey in bnFpkfAaEHtzrChTwIcmJlsVqYPWeu:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWey=bnFpkfAaEHtzrChTwIcmJlsVqYPWey.strip()
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDx={'mode':'LOCAL_SEARCH','search_key':bnFpkfAaEHtzrChTwIcmJlsVqYPWey,'page':'1','historyyn':'Y',}
   bnFpkfAaEHtzrChTwIcmJlsVqYPWex={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','skey':bnFpkfAaEHtzrChTwIcmJlsVqYPWey,'vType':'-',}
   bnFpkfAaEHtzrChTwIcmJlsVqYPWeX=urllib.parse.urlencode(bnFpkfAaEHtzrChTwIcmJlsVqYPWex)
   bnFpkfAaEHtzrChTwIcmJlsVqYPWLO=[('선택된 검색어 ( %s ) 삭제'%(bnFpkfAaEHtzrChTwIcmJlsVqYPWey),'RunPlugin(plugin://plugin.video.coupangm/?%s)'%(bnFpkfAaEHtzrChTwIcmJlsVqYPWeX))]
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.add_dir(bnFpkfAaEHtzrChTwIcmJlsVqYPWey,sublabel='',img=bnFpkfAaEHtzrChTwIcmJlsVqYPWjO,infoLabels=bnFpkfAaEHtzrChTwIcmJlsVqYPWjO,isFolder=bnFpkfAaEHtzrChTwIcmJlsVqYPWjB,params=bnFpkfAaEHtzrChTwIcmJlsVqYPWDx,ContextMenu=bnFpkfAaEHtzrChTwIcmJlsVqYPWLO)
  bnFpkfAaEHtzrChTwIcmJlsVqYPWOe={'plot':'검색목록 전체를 삭제합니다.'}
  bnFpkfAaEHtzrChTwIcmJlsVqYPWDL='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  bnFpkfAaEHtzrChTwIcmJlsVqYPWDx={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  bnFpkfAaEHtzrChTwIcmJlsVqYPWDy=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.add_dir(bnFpkfAaEHtzrChTwIcmJlsVqYPWDL,sublabel='',img=bnFpkfAaEHtzrChTwIcmJlsVqYPWDy,infoLabels=bnFpkfAaEHtzrChTwIcmJlsVqYPWOe,isFolder=bnFpkfAaEHtzrChTwIcmJlsVqYPWjL,params=bnFpkfAaEHtzrChTwIcmJlsVqYPWDx,isLink=bnFpkfAaEHtzrChTwIcmJlsVqYPWjB)
  xbmcplugin.endOfDirectory(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj._addon_handle,cacheToDisc=bnFpkfAaEHtzrChTwIcmJlsVqYPWjL)
 def dp_Listfile_Delete(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj,args):
  bnFpkfAaEHtzrChTwIcmJlsVqYPWed=args.get('delType')
  bnFpkfAaEHtzrChTwIcmJlsVqYPWeU =args.get('skey')
  bnFpkfAaEHtzrChTwIcmJlsVqYPWOM =args.get('vType')
  bnFpkfAaEHtzrChTwIcmJlsVqYPWMd=xbmcgui.Dialog()
  if bnFpkfAaEHtzrChTwIcmJlsVqYPWed=='SEARCH_ALL':
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDR=bnFpkfAaEHtzrChTwIcmJlsVqYPWMd.yesno(__language__(30911).encode('utf8'),__language__(30906).encode('utf8'))
  elif bnFpkfAaEHtzrChTwIcmJlsVqYPWed=='SEARCH_ONE':
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDR=bnFpkfAaEHtzrChTwIcmJlsVqYPWMd.yesno(__language__(30912).encode('utf8'),__language__(30906).encode('utf8'))
  elif bnFpkfAaEHtzrChTwIcmJlsVqYPWed=='WATCH_ALL':
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDR=bnFpkfAaEHtzrChTwIcmJlsVqYPWMd.yesno(__language__(30913).encode('utf8'),__language__(30906).encode('utf8'))
  elif bnFpkfAaEHtzrChTwIcmJlsVqYPWed=='WATCH_ONE':
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDR=bnFpkfAaEHtzrChTwIcmJlsVqYPWMd.yesno(__language__(30916).encode('utf8'),__language__(30906).encode('utf8'))
  if bnFpkfAaEHtzrChTwIcmJlsVqYPWDR==bnFpkfAaEHtzrChTwIcmJlsVqYPWjL:sys.exit()
  if bnFpkfAaEHtzrChTwIcmJlsVqYPWed=='SEARCH_ALL':
   if os.path.isfile(bnFpkfAaEHtzrChTwIcmJlsVqYPWMe):os.remove(bnFpkfAaEHtzrChTwIcmJlsVqYPWMe)
  elif bnFpkfAaEHtzrChTwIcmJlsVqYPWed=='SEARCH_ONE':
   try:
    bnFpkfAaEHtzrChTwIcmJlsVqYPWBN=bnFpkfAaEHtzrChTwIcmJlsVqYPWMe
    bnFpkfAaEHtzrChTwIcmJlsVqYPWBo=bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.Load_List_File('search') 
    fp=bnFpkfAaEHtzrChTwIcmJlsVqYPWjd(bnFpkfAaEHtzrChTwIcmJlsVqYPWBN,'w',-1,'utf-8')
    for bnFpkfAaEHtzrChTwIcmJlsVqYPWeO in bnFpkfAaEHtzrChTwIcmJlsVqYPWBo:
     if bnFpkfAaEHtzrChTwIcmJlsVqYPWeU!=bnFpkfAaEHtzrChTwIcmJlsVqYPWeO.strip():
      fp.write(bnFpkfAaEHtzrChTwIcmJlsVqYPWeO)
    fp.close()
   except:
    bnFpkfAaEHtzrChTwIcmJlsVqYPWjO
  elif bnFpkfAaEHtzrChTwIcmJlsVqYPWed=='WATCH_ALL':
   bnFpkfAaEHtzrChTwIcmJlsVqYPWBN=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%bnFpkfAaEHtzrChTwIcmJlsVqYPWOM))
   if os.path.isfile(bnFpkfAaEHtzrChTwIcmJlsVqYPWBN):os.remove(bnFpkfAaEHtzrChTwIcmJlsVqYPWBN)
  elif bnFpkfAaEHtzrChTwIcmJlsVqYPWed=='WATCH_ONE':
   bnFpkfAaEHtzrChTwIcmJlsVqYPWBN=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%bnFpkfAaEHtzrChTwIcmJlsVqYPWOM))
   try:
    bnFpkfAaEHtzrChTwIcmJlsVqYPWBo=bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.Load_List_File(bnFpkfAaEHtzrChTwIcmJlsVqYPWOM) 
    fp=bnFpkfAaEHtzrChTwIcmJlsVqYPWjd(bnFpkfAaEHtzrChTwIcmJlsVqYPWBN,'w',-1,'utf-8')
    for bnFpkfAaEHtzrChTwIcmJlsVqYPWeO in bnFpkfAaEHtzrChTwIcmJlsVqYPWBo:
     bnFpkfAaEHtzrChTwIcmJlsVqYPWeL=bnFpkfAaEHtzrChTwIcmJlsVqYPWju(urllib.parse.parse_qsl(bnFpkfAaEHtzrChTwIcmJlsVqYPWeO))
     bnFpkfAaEHtzrChTwIcmJlsVqYPWev=bnFpkfAaEHtzrChTwIcmJlsVqYPWeL.get('code').strip()
     if bnFpkfAaEHtzrChTwIcmJlsVqYPWeU!=bnFpkfAaEHtzrChTwIcmJlsVqYPWev:
      fp.write(bnFpkfAaEHtzrChTwIcmJlsVqYPWeO)
    fp.close()
   except:
    bnFpkfAaEHtzrChTwIcmJlsVqYPWjO
  xbmc.executebuiltin("Container.Refresh")
 def Delete_List_File(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj,bnFpkfAaEHtzrChTwIcmJlsVqYPWBR,skey='-'):
  if bnFpkfAaEHtzrChTwIcmJlsVqYPWBR=='ALL':
   try:
    bnFpkfAaEHtzrChTwIcmJlsVqYPWBN=bnFpkfAaEHtzrChTwIcmJlsVqYPWMe
    fp=bnFpkfAaEHtzrChTwIcmJlsVqYPWjd(bnFpkfAaEHtzrChTwIcmJlsVqYPWBN,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    bnFpkfAaEHtzrChTwIcmJlsVqYPWjO
  elif bnFpkfAaEHtzrChTwIcmJlsVqYPWBR=='ONE':
   try:
    bnFpkfAaEHtzrChTwIcmJlsVqYPWBN=bnFpkfAaEHtzrChTwIcmJlsVqYPWMe
    bnFpkfAaEHtzrChTwIcmJlsVqYPWBo=bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.Load_List_File('search') 
    fp=bnFpkfAaEHtzrChTwIcmJlsVqYPWjd(bnFpkfAaEHtzrChTwIcmJlsVqYPWBN,'w',-1,'utf-8')
    for bnFpkfAaEHtzrChTwIcmJlsVqYPWeO in bnFpkfAaEHtzrChTwIcmJlsVqYPWBo:
     if skey!=bnFpkfAaEHtzrChTwIcmJlsVqYPWeO.strip():
      fp.write(bnFpkfAaEHtzrChTwIcmJlsVqYPWeO)
    fp.close()
   except:
    bnFpkfAaEHtzrChTwIcmJlsVqYPWjO
  elif bnFpkfAaEHtzrChTwIcmJlsVqYPWBR in['tvshow','movie']:
   try:
    bnFpkfAaEHtzrChTwIcmJlsVqYPWBN=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%bnFpkfAaEHtzrChTwIcmJlsVqYPWBR))
    fp=bnFpkfAaEHtzrChTwIcmJlsVqYPWjd(bnFpkfAaEHtzrChTwIcmJlsVqYPWBN,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    bnFpkfAaEHtzrChTwIcmJlsVqYPWjO
 def dp_Watch_List(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj,args):
  bnFpkfAaEHtzrChTwIcmJlsVqYPWBR =args.get('stype')
  if bnFpkfAaEHtzrChTwIcmJlsVqYPWBR in['',bnFpkfAaEHtzrChTwIcmJlsVqYPWjO]:
   for bnFpkfAaEHtzrChTwIcmJlsVqYPWeR in bnFpkfAaEHtzrChTwIcmJlsVqYPWML:
    bnFpkfAaEHtzrChTwIcmJlsVqYPWDL=bnFpkfAaEHtzrChTwIcmJlsVqYPWeR.get('title')
    bnFpkfAaEHtzrChTwIcmJlsVqYPWDx={'mode':bnFpkfAaEHtzrChTwIcmJlsVqYPWeR.get('mode'),'stype':bnFpkfAaEHtzrChTwIcmJlsVqYPWeR.get('stype'),}
    bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.add_dir(bnFpkfAaEHtzrChTwIcmJlsVqYPWDL,sublabel='',img='',infoLabels=bnFpkfAaEHtzrChTwIcmJlsVqYPWjO,isFolder=bnFpkfAaEHtzrChTwIcmJlsVqYPWjB,params=bnFpkfAaEHtzrChTwIcmJlsVqYPWDx)
   xbmcplugin.endOfDirectory(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj._addon_handle)
  else:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWei=bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.Load_List_File(bnFpkfAaEHtzrChTwIcmJlsVqYPWBR)
   for bnFpkfAaEHtzrChTwIcmJlsVqYPWeQ in bnFpkfAaEHtzrChTwIcmJlsVqYPWei:
    bnFpkfAaEHtzrChTwIcmJlsVqYPWeK=bnFpkfAaEHtzrChTwIcmJlsVqYPWju(urllib.parse.parse_qsl(bnFpkfAaEHtzrChTwIcmJlsVqYPWeQ))
    bnFpkfAaEHtzrChTwIcmJlsVqYPWLS =bnFpkfAaEHtzrChTwIcmJlsVqYPWeK.get('code').strip()
    bnFpkfAaEHtzrChTwIcmJlsVqYPWDL =bnFpkfAaEHtzrChTwIcmJlsVqYPWeK.get('title').strip()
    bnFpkfAaEHtzrChTwIcmJlsVqYPWOy =bnFpkfAaEHtzrChTwIcmJlsVqYPWeK.get('img').strip()
    bnFpkfAaEHtzrChTwIcmJlsVqYPWOx =bnFpkfAaEHtzrChTwIcmJlsVqYPWeK.get('asis').strip()
    try:
     bnFpkfAaEHtzrChTwIcmJlsVqYPWOy=bnFpkfAaEHtzrChTwIcmJlsVqYPWOy.replace('\'','\"')
     bnFpkfAaEHtzrChTwIcmJlsVqYPWOy=json.loads(bnFpkfAaEHtzrChTwIcmJlsVqYPWOy)
    except:
     bnFpkfAaEHtzrChTwIcmJlsVqYPWjO
    bnFpkfAaEHtzrChTwIcmJlsVqYPWOe={}
    bnFpkfAaEHtzrChTwIcmJlsVqYPWOe['plot']=bnFpkfAaEHtzrChTwIcmJlsVqYPWDL
    if bnFpkfAaEHtzrChTwIcmJlsVqYPWBR=='movie':
     bnFpkfAaEHtzrChTwIcmJlsVqYPWOe['mediatype']='movie'
     bnFpkfAaEHtzrChTwIcmJlsVqYPWDx={'mode':'MOVIE','id':bnFpkfAaEHtzrChTwIcmJlsVqYPWLS,'asis':bnFpkfAaEHtzrChTwIcmJlsVqYPWOx,'title':bnFpkfAaEHtzrChTwIcmJlsVqYPWDL,'thumbnail':bnFpkfAaEHtzrChTwIcmJlsVqYPWOy,}
     bnFpkfAaEHtzrChTwIcmJlsVqYPWDX=bnFpkfAaEHtzrChTwIcmJlsVqYPWjL
    else:
     bnFpkfAaEHtzrChTwIcmJlsVqYPWOe['mediatype']='episode'
     bnFpkfAaEHtzrChTwIcmJlsVqYPWDx={'mode':'SEASON_LIST','id':bnFpkfAaEHtzrChTwIcmJlsVqYPWLS,'asis':bnFpkfAaEHtzrChTwIcmJlsVqYPWOx,'title':bnFpkfAaEHtzrChTwIcmJlsVqYPWDL,'thumbnail':json.dumps(bnFpkfAaEHtzrChTwIcmJlsVqYPWOy,separators=(',',':')),}
     bnFpkfAaEHtzrChTwIcmJlsVqYPWDX=bnFpkfAaEHtzrChTwIcmJlsVqYPWjB
    bnFpkfAaEHtzrChTwIcmJlsVqYPWex={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','skey':bnFpkfAaEHtzrChTwIcmJlsVqYPWLS,'vType':bnFpkfAaEHtzrChTwIcmJlsVqYPWBR,}
    bnFpkfAaEHtzrChTwIcmJlsVqYPWeX=urllib.parse.urlencode(bnFpkfAaEHtzrChTwIcmJlsVqYPWex)
    bnFpkfAaEHtzrChTwIcmJlsVqYPWLO=[('선택된 시청이력 ( %s ) 삭제'%(bnFpkfAaEHtzrChTwIcmJlsVqYPWDL),'RunPlugin(plugin://plugin.video.coupangm/?%s)'%(bnFpkfAaEHtzrChTwIcmJlsVqYPWeX))]
    bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.add_dir(bnFpkfAaEHtzrChTwIcmJlsVqYPWDL,sublabel='',img=bnFpkfAaEHtzrChTwIcmJlsVqYPWOy,infoLabels=bnFpkfAaEHtzrChTwIcmJlsVqYPWOe,isFolder=bnFpkfAaEHtzrChTwIcmJlsVqYPWDX,params=bnFpkfAaEHtzrChTwIcmJlsVqYPWDx,ContextMenu=bnFpkfAaEHtzrChTwIcmJlsVqYPWLO)
   bnFpkfAaEHtzrChTwIcmJlsVqYPWOe={'plot':'시청목록을 삭제합니다.'}
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDL='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDx={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':bnFpkfAaEHtzrChTwIcmJlsVqYPWBR,}
   bnFpkfAaEHtzrChTwIcmJlsVqYPWDy=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.add_dir(bnFpkfAaEHtzrChTwIcmJlsVqYPWDL,sublabel='',img=bnFpkfAaEHtzrChTwIcmJlsVqYPWDy,infoLabels=bnFpkfAaEHtzrChTwIcmJlsVqYPWOe,isFolder=bnFpkfAaEHtzrChTwIcmJlsVqYPWjL,params=bnFpkfAaEHtzrChTwIcmJlsVqYPWDx,isLink=bnFpkfAaEHtzrChTwIcmJlsVqYPWjB)
   if bnFpkfAaEHtzrChTwIcmJlsVqYPWBR=='movie':xbmcplugin.setContent(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj._addon_handle,'movies')
   else:xbmcplugin.setContent(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj._addon_handle,cacheToDisc=bnFpkfAaEHtzrChTwIcmJlsVqYPWjL)
 def dp_Set_Bookmark(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj,args):
  bnFpkfAaEHtzrChTwIcmJlsVqYPWeS=urllib.parse.unquote(args.get('bm_param'))
  bnFpkfAaEHtzrChTwIcmJlsVqYPWeS=json.loads(bnFpkfAaEHtzrChTwIcmJlsVqYPWeS)
  bnFpkfAaEHtzrChTwIcmJlsVqYPWeN =bnFpkfAaEHtzrChTwIcmJlsVqYPWeS.get('videoid')
  bnFpkfAaEHtzrChTwIcmJlsVqYPWeG =bnFpkfAaEHtzrChTwIcmJlsVqYPWeS.get('vidtype')
  bnFpkfAaEHtzrChTwIcmJlsVqYPWeg =bnFpkfAaEHtzrChTwIcmJlsVqYPWeS.get('vtitle')
  bnFpkfAaEHtzrChTwIcmJlsVqYPWMd=xbmcgui.Dialog()
  bnFpkfAaEHtzrChTwIcmJlsVqYPWDR=bnFpkfAaEHtzrChTwIcmJlsVqYPWMd.yesno(__language__(30914).encode('utf8'),bnFpkfAaEHtzrChTwIcmJlsVqYPWeg+' \n\n'+__language__(30915))
  if bnFpkfAaEHtzrChTwIcmJlsVqYPWDR==bnFpkfAaEHtzrChTwIcmJlsVqYPWjL:return
  bnFpkfAaEHtzrChTwIcmJlsVqYPWeo=bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.GetBookmarkInfo(bnFpkfAaEHtzrChTwIcmJlsVqYPWeN,bnFpkfAaEHtzrChTwIcmJlsVqYPWeG)
  bnFpkfAaEHtzrChTwIcmJlsVqYPWjM=json.dumps(bnFpkfAaEHtzrChTwIcmJlsVqYPWeo)
  bnFpkfAaEHtzrChTwIcmJlsVqYPWjM=urllib.parse.quote(bnFpkfAaEHtzrChTwIcmJlsVqYPWjM)
  bnFpkfAaEHtzrChTwIcmJlsVqYPWLD ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(bnFpkfAaEHtzrChTwIcmJlsVqYPWjM)
  xbmc.executebuiltin(bnFpkfAaEHtzrChTwIcmJlsVqYPWLD)
 def coupang_main(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj):
  bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CoupangObj.KodiVersion=bnFpkfAaEHtzrChTwIcmJlsVqYPWjx(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  bnFpkfAaEHtzrChTwIcmJlsVqYPWOg=bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.main_params.get('mode',bnFpkfAaEHtzrChTwIcmJlsVqYPWjO)
  if bnFpkfAaEHtzrChTwIcmJlsVqYPWOg=='LOGOUT':
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.CP_logout()
   return
  bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.option_check()
  if bnFpkfAaEHtzrChTwIcmJlsVqYPWOg is bnFpkfAaEHtzrChTwIcmJlsVqYPWjO:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.dp_Main_List(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.main_params)
  elif bnFpkfAaEHtzrChTwIcmJlsVqYPWOg=='CATEGORY_GROUPLIST':
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.dp_Category_GroupList(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.main_params)
  elif bnFpkfAaEHtzrChTwIcmJlsVqYPWOg=='THEME_GROUPLIST':
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.dp_Theme_GroupList(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.main_params)
  elif bnFpkfAaEHtzrChTwIcmJlsVqYPWOg=='EVENT_GROUPLIST':
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.dp_Event_GroupList(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.main_params)
  elif bnFpkfAaEHtzrChTwIcmJlsVqYPWOg=='EVENT_GAMELIST':
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.dp_Event_GameList(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.main_params)
  elif bnFpkfAaEHtzrChTwIcmJlsVqYPWOg=='EVENT_LIST':
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.dp_Event_List(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.main_params)
  elif bnFpkfAaEHtzrChTwIcmJlsVqYPWOg=='CATEGORY_LIST':
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.dp_Category_List(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.main_params)
  elif bnFpkfAaEHtzrChTwIcmJlsVqYPWOg=='SEASON_LIST':
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.dp_Season_List(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.main_params)
  elif bnFpkfAaEHtzrChTwIcmJlsVqYPWOg=='EPISODE_LIST':
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.dp_Episode_List(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.main_params)
  elif bnFpkfAaEHtzrChTwIcmJlsVqYPWOg=='TEST':
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.dp_Test(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.main_params)
  elif bnFpkfAaEHtzrChTwIcmJlsVqYPWOg in['MOVIE','VOD','HIGHLIGHT','LIVE']:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.play_VIDEO(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.main_params)
  elif bnFpkfAaEHtzrChTwIcmJlsVqYPWOg=='WATCH':
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.dp_Watch_List(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.main_params)
  elif bnFpkfAaEHtzrChTwIcmJlsVqYPWOg=='LOCAL_SEARCH':
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.dp_Search_List(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.main_params)
  elif bnFpkfAaEHtzrChTwIcmJlsVqYPWOg=='SEARCH_HISTORY':
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.dp_Search_History(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.main_params)
  elif bnFpkfAaEHtzrChTwIcmJlsVqYPWOg in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.dp_Listfile_Delete(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.main_params)
  elif bnFpkfAaEHtzrChTwIcmJlsVqYPWOg in['TOTAL_SEARCH','TOTAL_HISTORY']:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.dp_Global_Search(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.main_params)
  elif bnFpkfAaEHtzrChTwIcmJlsVqYPWOg=='MENU_BOOKMARK':
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.dp_Bookmark_Menu(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.main_params)
  elif bnFpkfAaEHtzrChTwIcmJlsVqYPWOg=='SET_BOOKMARK':
   bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.dp_Set_Bookmark(bnFpkfAaEHtzrChTwIcmJlsVqYPWMj.main_params)
  else:
   bnFpkfAaEHtzrChTwIcmJlsVqYPWjO
# Created by pyminifier (https://github.com/liftoff/pyminifier)
