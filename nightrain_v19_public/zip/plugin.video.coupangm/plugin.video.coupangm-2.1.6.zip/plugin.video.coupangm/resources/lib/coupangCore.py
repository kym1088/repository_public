__author__="NightRain"
vekSHJwXmRtWDzKarfosnIlBNgMbLG=object
vekSHJwXmRtWDzKarfosnIlBNgMbLV=None
vekSHJwXmRtWDzKarfosnIlBNgMbLF=False
vekSHJwXmRtWDzKarfosnIlBNgMbLd=print
vekSHJwXmRtWDzKarfosnIlBNgMbLC=str
vekSHJwXmRtWDzKarfosnIlBNgMbLA=open
vekSHJwXmRtWDzKarfosnIlBNgMbLy=int
vekSHJwXmRtWDzKarfosnIlBNgMbOT=Exception
vekSHJwXmRtWDzKarfosnIlBNgMbOq=len
vekSHJwXmRtWDzKarfosnIlBNgMbOp=id
vekSHJwXmRtWDzKarfosnIlBNgMbOL=True
vekSHJwXmRtWDzKarfosnIlBNgMbOQ=range
import urllib
import re
import json
import requests
import datetime
import time
import random
import base64
class vekSHJwXmRtWDzKarfosnIlBNgMbTq(vekSHJwXmRtWDzKarfosnIlBNgMbLG):
 def __init__(vekSHJwXmRtWDzKarfosnIlBNgMbTp):
  vekSHJwXmRtWDzKarfosnIlBNgMbTp.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
  vekSHJwXmRtWDzKarfosnIlBNgMbTp.MODEL ='Chrome_128' 
  vekSHJwXmRtWDzKarfosnIlBNgMbTp.OS_VERSION ='128' 
  vekSHJwXmRtWDzKarfosnIlBNgMbTp.DEFAULT_HEADER ={'user-agent':vekSHJwXmRtWDzKarfosnIlBNgMbTp.USER_AGENT}
  vekSHJwXmRtWDzKarfosnIlBNgMbTp.API_DOMAIN ='https://www.coupangplay.com'
  vekSHJwXmRtWDzKarfosnIlBNgMbTp.API_VIEWURL ='https://discover.coupangstreaming.com'
  vekSHJwXmRtWDzKarfosnIlBNgMbTp.PAGE_LIMIT =40
  vekSHJwXmRtWDzKarfosnIlBNgMbTp.SEARCH_LIMIT =20
  vekSHJwXmRtWDzKarfosnIlBNgMbTp.KodiVersion =20
  vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP={}
  vekSHJwXmRtWDzKarfosnIlBNgMbTp.Init_CP()
  vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP_DEVICE_FILENAME=''
  vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP_COOKIE_FILENAME=''
 def callRequestCookies(vekSHJwXmRtWDzKarfosnIlBNgMbTp,jobtype,vekSHJwXmRtWDzKarfosnIlBNgMbqi,payload=vekSHJwXmRtWDzKarfosnIlBNgMbLV,params=vekSHJwXmRtWDzKarfosnIlBNgMbLV,headers=vekSHJwXmRtWDzKarfosnIlBNgMbLV,cookies=vekSHJwXmRtWDzKarfosnIlBNgMbLV,redirects=vekSHJwXmRtWDzKarfosnIlBNgMbLF):
  vekSHJwXmRtWDzKarfosnIlBNgMbTL=vekSHJwXmRtWDzKarfosnIlBNgMbTp.DEFAULT_HEADER
  if headers:vekSHJwXmRtWDzKarfosnIlBNgMbTL.update(headers)
  if jobtype=='Get':
   vekSHJwXmRtWDzKarfosnIlBNgMbTO=requests.get(vekSHJwXmRtWDzKarfosnIlBNgMbqi,params=params,headers=vekSHJwXmRtWDzKarfosnIlBNgMbTL,cookies=cookies,allow_redirects=redirects)
  else:
   vekSHJwXmRtWDzKarfosnIlBNgMbTO=requests.post(vekSHJwXmRtWDzKarfosnIlBNgMbqi,data=payload,params=params,headers=vekSHJwXmRtWDzKarfosnIlBNgMbTL,cookies=cookies,allow_redirects=redirects)
  vekSHJwXmRtWDzKarfosnIlBNgMbLd(vekSHJwXmRtWDzKarfosnIlBNgMbLC(vekSHJwXmRtWDzKarfosnIlBNgMbTO.status_code)+' - '+vekSHJwXmRtWDzKarfosnIlBNgMbLC(vekSHJwXmRtWDzKarfosnIlBNgMbTO.url))
  return vekSHJwXmRtWDzKarfosnIlBNgMbTO
 def callRequestCookies_test(vekSHJwXmRtWDzKarfosnIlBNgMbTp,jobtype,vekSHJwXmRtWDzKarfosnIlBNgMbqi,payload=vekSHJwXmRtWDzKarfosnIlBNgMbLV,params=vekSHJwXmRtWDzKarfosnIlBNgMbLV,headers=vekSHJwXmRtWDzKarfosnIlBNgMbLV,cookies=vekSHJwXmRtWDzKarfosnIlBNgMbLV,redirects=vekSHJwXmRtWDzKarfosnIlBNgMbLF):
  vekSHJwXmRtWDzKarfosnIlBNgMbTL=vekSHJwXmRtWDzKarfosnIlBNgMbTp.DEFAULT_HEADER
  if headers:vekSHJwXmRtWDzKarfosnIlBNgMbTL.update(headers)
  vekSHJwXmRtWDzKarfosnIlBNgMbTO=requests.Request('POST',vekSHJwXmRtWDzKarfosnIlBNgMbqi,headers=headers,data=payload,params=params,cookies=cookies)
  vekSHJwXmRtWDzKarfosnIlBNgMbTQ=vekSHJwXmRtWDzKarfosnIlBNgMbTO.prepare()
  vekSHJwXmRtWDzKarfosnIlBNgMbTp.pretty_print_POST(vekSHJwXmRtWDzKarfosnIlBNgMbTQ)
  return vekSHJwXmRtWDzKarfosnIlBNgMbTO
 def pretty_print_POST(vekSHJwXmRtWDzKarfosnIlBNgMbTp,req):
  vekSHJwXmRtWDzKarfosnIlBNgMbLd('{}\n{}\r\n{}\r\n\r\n{}'.format('-----------START-----------',req.method+' '+req.url,'\r\n'.join('{}: {}'.format(k,v)for k,v in req.headers.items()),req.body,))
 def dic_To_jsonfile(vekSHJwXmRtWDzKarfosnIlBNgMbTp,filename,vekSHJwXmRtWDzKarfosnIlBNgMbTP):
  if filename=='':return
  fp=vekSHJwXmRtWDzKarfosnIlBNgMbLA(filename,'w',-1,'utf-8')
  json.dump(vekSHJwXmRtWDzKarfosnIlBNgMbTP,fp,indent=4,ensure_ascii=vekSHJwXmRtWDzKarfosnIlBNgMbLF)
  fp.close()
 def jsonfile_To_dic(vekSHJwXmRtWDzKarfosnIlBNgMbTp,filename):
  if filename=='':return vekSHJwXmRtWDzKarfosnIlBNgMbLV
  try:
   fp=vekSHJwXmRtWDzKarfosnIlBNgMbLA(filename,'r',-1,'utf-8')
   vekSHJwXmRtWDzKarfosnIlBNgMbTi=json.load(fp)
   fp.close()
  except:
   vekSHJwXmRtWDzKarfosnIlBNgMbTi={}
  return vekSHJwXmRtWDzKarfosnIlBNgMbTi
 def convert_TimeStr(vekSHJwXmRtWDzKarfosnIlBNgMbTp,vekSHJwXmRtWDzKarfosnIlBNgMbTY):
  try:
   vekSHJwXmRtWDzKarfosnIlBNgMbTY =vekSHJwXmRtWDzKarfosnIlBNgMbTY[0:16]
   vekSHJwXmRtWDzKarfosnIlBNgMbTh=datetime.datetime.strptime(vekSHJwXmRtWDzKarfosnIlBNgMbTY,'%Y-%m-%dT%H:%M')+datetime.timedelta(hours=9)
   return vekSHJwXmRtWDzKarfosnIlBNgMbTh.strftime('%Y-%m-%d %H:%M')
  except:
   return vekSHJwXmRtWDzKarfosnIlBNgMbLV
 def Get_Now_Datetime(vekSHJwXmRtWDzKarfosnIlBNgMbTp):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetNoCache(vekSHJwXmRtWDzKarfosnIlBNgMbTp):
  vekSHJwXmRtWDzKarfosnIlBNgMbTU =vekSHJwXmRtWDzKarfosnIlBNgMbLy(time.time()*1000)
  return vekSHJwXmRtWDzKarfosnIlBNgMbTU
 def generatePcId(vekSHJwXmRtWDzKarfosnIlBNgMbTp):
  t=vekSHJwXmRtWDzKarfosnIlBNgMbTp.GetNoCache()
  r=random.random()
  vekSHJwXmRtWDzKarfosnIlBNgMbTu=vekSHJwXmRtWDzKarfosnIlBNgMbLC(t)+vekSHJwXmRtWDzKarfosnIlBNgMbLC(r)[2:12]
  return vekSHJwXmRtWDzKarfosnIlBNgMbTu
 def generatePvId(vekSHJwXmRtWDzKarfosnIlBNgMbTp,genType='1'):
  import hashlib
  m=hashlib.md5()
  vekSHJwXmRtWDzKarfosnIlBNgMbTc=vekSHJwXmRtWDzKarfosnIlBNgMbLC(random.random())
  m.update(vekSHJwXmRtWDzKarfosnIlBNgMbTc.encode('utf-8'))
  vekSHJwXmRtWDzKarfosnIlBNgMbTj=vekSHJwXmRtWDzKarfosnIlBNgMbLC(m.hexdigest())
  if genType=='1':
   return '%s-%s-%s-%s-%s'%(vekSHJwXmRtWDzKarfosnIlBNgMbTj[:8],vekSHJwXmRtWDzKarfosnIlBNgMbTj[8:12],vekSHJwXmRtWDzKarfosnIlBNgMbTj[12:16],vekSHJwXmRtWDzKarfosnIlBNgMbTj[16:20],vekSHJwXmRtWDzKarfosnIlBNgMbTj[20:])
  else:
   return vekSHJwXmRtWDzKarfosnIlBNgMbTj
 def Get_DeviceID(vekSHJwXmRtWDzKarfosnIlBNgMbTp):
  vekSHJwXmRtWDzKarfosnIlBNgMbTG=''
  try: 
   fp=vekSHJwXmRtWDzKarfosnIlBNgMbLA(vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP_DEVICE_FILENAME,'r',-1,'utf-8')
   vekSHJwXmRtWDzKarfosnIlBNgMbTV= json.load(fp)
   fp.close()
   vekSHJwXmRtWDzKarfosnIlBNgMbTG=vekSHJwXmRtWDzKarfosnIlBNgMbTV.get('device_id')
  except vekSHJwXmRtWDzKarfosnIlBNgMbOT as exception:
   vekSHJwXmRtWDzKarfosnIlBNgMbLV
  if vekSHJwXmRtWDzKarfosnIlBNgMbTG=='':
   vekSHJwXmRtWDzKarfosnIlBNgMbTG=vekSHJwXmRtWDzKarfosnIlBNgMbTp.generatePvId(genType='1')
   try: 
    fp=vekSHJwXmRtWDzKarfosnIlBNgMbLA(vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP_DEVICE_FILENAME,'w',-1,'utf-8')
    json.dump({'device_id':vekSHJwXmRtWDzKarfosnIlBNgMbTG},fp,indent=4,ensure_ascii=vekSHJwXmRtWDzKarfosnIlBNgMbLF)
    fp.close()
   except vekSHJwXmRtWDzKarfosnIlBNgMbOT as exception:
    return ''
  return vekSHJwXmRtWDzKarfosnIlBNgMbTG
 def make_stream_header(vekSHJwXmRtWDzKarfosnIlBNgMbTp,vekSHJwXmRtWDzKarfosnIlBNgMbTy,vekSHJwXmRtWDzKarfosnIlBNgMbqY):
  vekSHJwXmRtWDzKarfosnIlBNgMbTF=''
  if vekSHJwXmRtWDzKarfosnIlBNgMbqY not in[{},vekSHJwXmRtWDzKarfosnIlBNgMbLV,'']:
   vekSHJwXmRtWDzKarfosnIlBNgMbTd=vekSHJwXmRtWDzKarfosnIlBNgMbOq(vekSHJwXmRtWDzKarfosnIlBNgMbqY)
   for vekSHJwXmRtWDzKarfosnIlBNgMbTC,vekSHJwXmRtWDzKarfosnIlBNgMbTA in vekSHJwXmRtWDzKarfosnIlBNgMbqY.items():
    vekSHJwXmRtWDzKarfosnIlBNgMbTF+='{}={}'.format(vekSHJwXmRtWDzKarfosnIlBNgMbTC,vekSHJwXmRtWDzKarfosnIlBNgMbTA)
    vekSHJwXmRtWDzKarfosnIlBNgMbTd+=-1
    if vekSHJwXmRtWDzKarfosnIlBNgMbTd>0:vekSHJwXmRtWDzKarfosnIlBNgMbTF+='; '
   vekSHJwXmRtWDzKarfosnIlBNgMbTy['cookie']=vekSHJwXmRtWDzKarfosnIlBNgMbTF
  vekSHJwXmRtWDzKarfosnIlBNgMbqT=''
  i=0
  for vekSHJwXmRtWDzKarfosnIlBNgMbTC,vekSHJwXmRtWDzKarfosnIlBNgMbTA in vekSHJwXmRtWDzKarfosnIlBNgMbTy.items():
   i=i+1
   if i>1:vekSHJwXmRtWDzKarfosnIlBNgMbqT+='&'
   vekSHJwXmRtWDzKarfosnIlBNgMbqT+='{}={}'.format(vekSHJwXmRtWDzKarfosnIlBNgMbTC,urllib.parse.quote(vekSHJwXmRtWDzKarfosnIlBNgMbTA))
  return vekSHJwXmRtWDzKarfosnIlBNgMbqT
 def Make_authHeader(vekSHJwXmRtWDzKarfosnIlBNgMbTp):
  tr=vekSHJwXmRtWDzKarfosnIlBNgMbTp.generatePvId(genType=2)
  ti=vekSHJwXmRtWDzKarfosnIlBNgMbTp.GetNoCache()
  vekSHJwXmRtWDzKarfosnIlBNgMbOp=vekSHJwXmRtWDzKarfosnIlBNgMbTp.generatePvId(genType=2)[:16]
  vekSHJwXmRtWDzKarfosnIlBNgMbqp='00-%s-%s-01'%(tr,vekSHJwXmRtWDzKarfosnIlBNgMbOp,)
  vekSHJwXmRtWDzKarfosnIlBNgMbqL ='%s@nr=0-1-%s-%s-%s----%s'%(vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['SESSION']['NREUM']['tk'],vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['SESSION']['NREUM']['ac'],vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['SESSION']['NREUM']['ap'],vekSHJwXmRtWDzKarfosnIlBNgMbOp,ti,)
  vekSHJwXmRtWDzKarfosnIlBNgMbqO ='{"v":[0,1],"d":{"ty":"Browser","ac":"%s","ap":"%s","id":"%s","tr":"%s","ti":%s,"tk":"%s"}}'%(vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['SESSION']['NREUM']['ac'],vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['SESSION']['NREUM']['ap'],vekSHJwXmRtWDzKarfosnIlBNgMbOp,tr,ti,vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['SESSION']['NREUM']['tk'],) 
  return vekSHJwXmRtWDzKarfosnIlBNgMbqp,vekSHJwXmRtWDzKarfosnIlBNgMbqL,base64.standard_b64encode(vekSHJwXmRtWDzKarfosnIlBNgMbqO.encode()).decode('utf-8')
 def Init_CP(vekSHJwXmRtWDzKarfosnIlBNgMbTp):
  vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP={}
  vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['ACCOUNT']={'cpid':'','cppw':'','cppf':'0'}
  vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['SESSION']={}
  vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['COOKIES']={}
 def Save_session_acount(vekSHJwXmRtWDzKarfosnIlBNgMbTp,vekSHJwXmRtWDzKarfosnIlBNgMbqQ,vekSHJwXmRtWDzKarfosnIlBNgMbqP,vekSHJwXmRtWDzKarfosnIlBNgMbqE):
  vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['ACCOUNT']['cpid']=base64.standard_b64encode(vekSHJwXmRtWDzKarfosnIlBNgMbqQ.encode()).decode('utf-8')
  vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['ACCOUNT']['cppw']=base64.standard_b64encode(vekSHJwXmRtWDzKarfosnIlBNgMbqP.encode()).decode('utf-8')
  vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['ACCOUNT']['cppf']=vekSHJwXmRtWDzKarfosnIlBNgMbLC(vekSHJwXmRtWDzKarfosnIlBNgMbqE)
 def Load_session_acount(vekSHJwXmRtWDzKarfosnIlBNgMbTp):
  vekSHJwXmRtWDzKarfosnIlBNgMbqQ=base64.standard_b64decode(vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['ACCOUNT']['cpid']).decode('utf-8')
  vekSHJwXmRtWDzKarfosnIlBNgMbqP=base64.standard_b64decode(vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['ACCOUNT']['cppw']).decode('utf-8')
  vekSHJwXmRtWDzKarfosnIlBNgMbqE=vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['ACCOUNT']['cppf']
  return vekSHJwXmRtWDzKarfosnIlBNgMbqQ,vekSHJwXmRtWDzKarfosnIlBNgMbqP,vekSHJwXmRtWDzKarfosnIlBNgMbqE
 def make_CP_DefaultCookies(vekSHJwXmRtWDzKarfosnIlBNgMbTp):
  return vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['COOKIES']
 def Get_CP_Login(vekSHJwXmRtWDzKarfosnIlBNgMbTp,userid,userpw,vekSHJwXmRtWDzKarfosnIlBNgMbqF):
  try:
   vekSHJwXmRtWDzKarfosnIlBNgMbqi=vekSHJwXmRtWDzKarfosnIlBNgMbTp.API_DOMAIN
   vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['COOKIES']['NEXT_LOCALE']='ko'
   vekSHJwXmRtWDzKarfosnIlBNgMbTy={'Accept-Language':'ko-KR,ko;q=0.9','Sec-Ch-Ua-Mobile':'?0','Sec-Ch-Ua-Platform':'"Windows"','Sec-Fetch-Dest':'document','Sec-Fetch-Mode':'navigate','Sec-Fetch-Site':'none','Sec-Fetch-User':'?1','Upgrade-Insecure-Requests':'1',}
   vekSHJwXmRtWDzKarfosnIlBNgMbqY=vekSHJwXmRtWDzKarfosnIlBNgMbTp.make_CP_DefaultCookies()
   vekSHJwXmRtWDzKarfosnIlBNgMbqh=vekSHJwXmRtWDzKarfosnIlBNgMbTp.callRequestCookies('Get',vekSHJwXmRtWDzKarfosnIlBNgMbqi,payload=vekSHJwXmRtWDzKarfosnIlBNgMbLV,params=vekSHJwXmRtWDzKarfosnIlBNgMbLV,headers=vekSHJwXmRtWDzKarfosnIlBNgMbTy,cookies=vekSHJwXmRtWDzKarfosnIlBNgMbqY,redirects=vekSHJwXmRtWDzKarfosnIlBNgMbOL)
   if vekSHJwXmRtWDzKarfosnIlBNgMbqh.status_code not in[200]:return vekSHJwXmRtWDzKarfosnIlBNgMbLF
   for vekSHJwXmRtWDzKarfosnIlBNgMbqx in vekSHJwXmRtWDzKarfosnIlBNgMbqh.cookies:
    vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['COOKIES'][vekSHJwXmRtWDzKarfosnIlBNgMbqx.name]=vekSHJwXmRtWDzKarfosnIlBNgMbqx.value
   vekSHJwXmRtWDzKarfosnIlBNgMbqY=vekSHJwXmRtWDzKarfosnIlBNgMbTp.make_CP_DefaultCookies()
   if vekSHJwXmRtWDzKarfosnIlBNgMbqh.status_code not in[200]:return vekSHJwXmRtWDzKarfosnIlBNgMbLF
   vekSHJwXmRtWDzKarfosnIlBNgMbqU=re.findall('NREUM.loader_config=\{[\w\d\":,-]+\}',vekSHJwXmRtWDzKarfosnIlBNgMbqh.text)[0].split('=')[1]
   vekSHJwXmRtWDzKarfosnIlBNgMbqU=vekSHJwXmRtWDzKarfosnIlBNgMbqU.replace('{','{"').replace(':','":').replace(',',',"')
   vekSHJwXmRtWDzKarfosnIlBNgMbqU=json.loads(vekSHJwXmRtWDzKarfosnIlBNgMbqU)
   vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['SESSION']['NREUM']={'ac':vekSHJwXmRtWDzKarfosnIlBNgMbqU['accountID'],'tk':vekSHJwXmRtWDzKarfosnIlBNgMbqU['trustKey'],'ap':vekSHJwXmRtWDzKarfosnIlBNgMbqU['agentID'],'lk':vekSHJwXmRtWDzKarfosnIlBNgMbqU['licenseKey'],}
  except vekSHJwXmRtWDzKarfosnIlBNgMbOT as exception:
   vekSHJwXmRtWDzKarfosnIlBNgMbLd(exception)
   return vekSHJwXmRtWDzKarfosnIlBNgMbLF
  try:
   vekSHJwXmRtWDzKarfosnIlBNgMbqi=vekSHJwXmRtWDzKarfosnIlBNgMbTp.API_DOMAIN+'/api/auth'
   vekSHJwXmRtWDzKarfosnIlBNgMbqu=vekSHJwXmRtWDzKarfosnIlBNgMbTp.Get_DeviceID()
   vekSHJwXmRtWDzKarfosnIlBNgMbqc =vekSHJwXmRtWDzKarfosnIlBNgMbqu.split('-')[0]
   vekSHJwXmRtWDzKarfosnIlBNgMbqp,vekSHJwXmRtWDzKarfosnIlBNgMbqL,vekSHJwXmRtWDzKarfosnIlBNgMbqO=vekSHJwXmRtWDzKarfosnIlBNgMbTp.Make_authHeader()
   vekSHJwXmRtWDzKarfosnIlBNgMbTy={'traceparent':vekSHJwXmRtWDzKarfosnIlBNgMbqp,'tracestate':vekSHJwXmRtWDzKarfosnIlBNgMbqL,'newrelic':vekSHJwXmRtWDzKarfosnIlBNgMbqO,'content-type':'application/json','x-app-version':'1.26.1','x-device-id':'','x-device-os-version':vekSHJwXmRtWDzKarfosnIlBNgMbTp.OS_VERSION,'x-nr-session-id':vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['COOKIES']['session_web_id'],'x-pcid':'',}
   vekSHJwXmRtWDzKarfosnIlBNgMbqj={'device':{'deviceId':'web-'+vekSHJwXmRtWDzKarfosnIlBNgMbqu,'model':vekSHJwXmRtWDzKarfosnIlBNgMbTp.MODEL,'name':'Chrome Desktop '+vekSHJwXmRtWDzKarfosnIlBNgMbqc,'os':'Windows','osVersion':'10','type':'webclient',},'email':userid,'password':userpw,}
   vekSHJwXmRtWDzKarfosnIlBNgMbqj=json.dumps(vekSHJwXmRtWDzKarfosnIlBNgMbqj,separators=(',',':'))
   vekSHJwXmRtWDzKarfosnIlBNgMbqY=vekSHJwXmRtWDzKarfosnIlBNgMbTp.make_CP_DefaultCookies()
   vekSHJwXmRtWDzKarfosnIlBNgMbqh=vekSHJwXmRtWDzKarfosnIlBNgMbTp.callRequestCookies('Post',vekSHJwXmRtWDzKarfosnIlBNgMbqi,payload=vekSHJwXmRtWDzKarfosnIlBNgMbqj,params=vekSHJwXmRtWDzKarfosnIlBNgMbLV,headers=vekSHJwXmRtWDzKarfosnIlBNgMbTy,cookies=vekSHJwXmRtWDzKarfosnIlBNgMbqY,redirects=vekSHJwXmRtWDzKarfosnIlBNgMbLF)
   if vekSHJwXmRtWDzKarfosnIlBNgMbqh.status_code not in[200]:
    vekSHJwXmRtWDzKarfosnIlBNgMbqG=json.loads(vekSHJwXmRtWDzKarfosnIlBNgMbqh.text)
    if 'error' in vekSHJwXmRtWDzKarfosnIlBNgMbqG:
     vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['SESSION']['error']=vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('error').get('detail')
    return vekSHJwXmRtWDzKarfosnIlBNgMbLF
   vekSHJwXmRtWDzKarfosnIlBNgMbLd('---')
   for vekSHJwXmRtWDzKarfosnIlBNgMbqx in vekSHJwXmRtWDzKarfosnIlBNgMbqh.cookies:
    vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['COOKIES'][vekSHJwXmRtWDzKarfosnIlBNgMbqx.name]=vekSHJwXmRtWDzKarfosnIlBNgMbqx.value
  except vekSHJwXmRtWDzKarfosnIlBNgMbOT as exception:
   vekSHJwXmRtWDzKarfosnIlBNgMbLd(exception)
   return vekSHJwXmRtWDzKarfosnIlBNgMbLF
  vekSHJwXmRtWDzKarfosnIlBNgMbTp.Save_session_acount(userid,userpw,vekSHJwXmRtWDzKarfosnIlBNgMbqF)
  return vekSHJwXmRtWDzKarfosnIlBNgMbOL
 def Get_CP_profile(vekSHJwXmRtWDzKarfosnIlBNgMbTp,vekSHJwXmRtWDzKarfosnIlBNgMbqF,limit_days=1,re_check=vekSHJwXmRtWDzKarfosnIlBNgMbLF):
  if re_check==vekSHJwXmRtWDzKarfosnIlBNgMbOL:
   if vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['SESSION']['bm_sv_ex']>vekSHJwXmRtWDzKarfosnIlBNgMbLy(time.time()):
    vekSHJwXmRtWDzKarfosnIlBNgMbLd('bm_sv_ex ok')
    return vekSHJwXmRtWDzKarfosnIlBNgMbOL
  try:
   vekSHJwXmRtWDzKarfosnIlBNgMbqi=vekSHJwXmRtWDzKarfosnIlBNgMbTp.API_DOMAIN+'/api/profiles'
   vekSHJwXmRtWDzKarfosnIlBNgMbqp,vekSHJwXmRtWDzKarfosnIlBNgMbqL,vekSHJwXmRtWDzKarfosnIlBNgMbqO=vekSHJwXmRtWDzKarfosnIlBNgMbTp.Make_authHeader()
   vekSHJwXmRtWDzKarfosnIlBNgMbTy={'traceparent':vekSHJwXmRtWDzKarfosnIlBNgMbqp,'tracestate':vekSHJwXmRtWDzKarfosnIlBNgMbqL,'newrelic':vekSHJwXmRtWDzKarfosnIlBNgMbqO,'x-app-version':'1.26.1','x-device-id':'','x-device-os-version':vekSHJwXmRtWDzKarfosnIlBNgMbTp.OS_VERSION,'x-nr-session-id':vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['COOKIES']['session_web_id'],'x-pcid':'',}
   vekSHJwXmRtWDzKarfosnIlBNgMbqY=vekSHJwXmRtWDzKarfosnIlBNgMbTp.make_CP_DefaultCookies()
   vekSHJwXmRtWDzKarfosnIlBNgMbqh=vekSHJwXmRtWDzKarfosnIlBNgMbTp.callRequestCookies('Get',vekSHJwXmRtWDzKarfosnIlBNgMbqi,payload=vekSHJwXmRtWDzKarfosnIlBNgMbLV,params=vekSHJwXmRtWDzKarfosnIlBNgMbLV,headers=vekSHJwXmRtWDzKarfosnIlBNgMbTy,cookies=vekSHJwXmRtWDzKarfosnIlBNgMbqY,redirects=vekSHJwXmRtWDzKarfosnIlBNgMbOL)
   if vekSHJwXmRtWDzKarfosnIlBNgMbqh.status_code not in[200]:return vekSHJwXmRtWDzKarfosnIlBNgMbLF
   vekSHJwXmRtWDzKarfosnIlBNgMbqG=json.loads(vekSHJwXmRtWDzKarfosnIlBNgMbqh.text)
   vekSHJwXmRtWDzKarfosnIlBNgMbqV=0
   for vekSHJwXmRtWDzKarfosnIlBNgMbqx in vekSHJwXmRtWDzKarfosnIlBNgMbqh.cookies:
    vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['COOKIES'][vekSHJwXmRtWDzKarfosnIlBNgMbqx.name]=vekSHJwXmRtWDzKarfosnIlBNgMbqx.value
    if vekSHJwXmRtWDzKarfosnIlBNgMbqx.name=='bm_sv':
     vekSHJwXmRtWDzKarfosnIlBNgMbqV=1
     vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['SESSION']['bm_sv_ex']=vekSHJwXmRtWDzKarfosnIlBNgMbqx.expires 
   if vekSHJwXmRtWDzKarfosnIlBNgMbqV==0:
    vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['SESSION']['bm_sv_ex']=vekSHJwXmRtWDzKarfosnIlBNgMbLy(time.time())+60*60*2 
   vekSHJwXmRtWDzKarfosnIlBNgMbqF=vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('data')[vekSHJwXmRtWDzKarfosnIlBNgMbLy(vekSHJwXmRtWDzKarfosnIlBNgMbqF)]
   vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['SESSION']['accountId']=vekSHJwXmRtWDzKarfosnIlBNgMbqF.get('accountId')
   vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['SESSION']['profileId']=vekSHJwXmRtWDzKarfosnIlBNgMbqF.get('profileId')
  except vekSHJwXmRtWDzKarfosnIlBNgMbOT as exception:
   vekSHJwXmRtWDzKarfosnIlBNgMbLd(exception)
   return vekSHJwXmRtWDzKarfosnIlBNgMbLF
  if re_check==vekSHJwXmRtWDzKarfosnIlBNgMbLF:
   vekSHJwXmRtWDzKarfosnIlBNgMbqd =vekSHJwXmRtWDzKarfosnIlBNgMbTp.Get_Now_Datetime()
   vekSHJwXmRtWDzKarfosnIlBNgMbqC=vekSHJwXmRtWDzKarfosnIlBNgMbqd+datetime.timedelta(days=limit_days)
   vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['SESSION']['limitdate']=vekSHJwXmRtWDzKarfosnIlBNgMbqC.strftime('%Y-%m-%d')
  else:
   vekSHJwXmRtWDzKarfosnIlBNgMbLd('re check')
  vekSHJwXmRtWDzKarfosnIlBNgMbTp.dic_To_jsonfile(vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP_COOKIE_FILENAME,vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP)
  return vekSHJwXmRtWDzKarfosnIlBNgMbOL
 def Get_Category_GroupList(vekSHJwXmRtWDzKarfosnIlBNgMbTp,vType):
  vekSHJwXmRtWDzKarfosnIlBNgMbqA=[] 
  try:
   vekSHJwXmRtWDzKarfosnIlBNgMbqi=vekSHJwXmRtWDzKarfosnIlBNgMbTp.API_VIEWURL+'/v2/discover/feed' 
   vekSHJwXmRtWDzKarfosnIlBNgMbqy={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false',}
   vekSHJwXmRtWDzKarfosnIlBNgMbqh=vekSHJwXmRtWDzKarfosnIlBNgMbTp.callRequestCookies('Get',vekSHJwXmRtWDzKarfosnIlBNgMbqi,payload=vekSHJwXmRtWDzKarfosnIlBNgMbLV,params=vekSHJwXmRtWDzKarfosnIlBNgMbqy,headers=vekSHJwXmRtWDzKarfosnIlBNgMbLV,cookies=vekSHJwXmRtWDzKarfosnIlBNgMbLV,redirects=vekSHJwXmRtWDzKarfosnIlBNgMbOL)
   if vekSHJwXmRtWDzKarfosnIlBNgMbqh.status_code not in[200]:return[]
   vekSHJwXmRtWDzKarfosnIlBNgMbqG=json.loads(vekSHJwXmRtWDzKarfosnIlBNgMbqh.text)
   if vType in['TVSHOWS','MOVIES']:
    vekSHJwXmRtWDzKarfosnIlBNgMbpT='Explores' 
   elif vType in['EDUCATION']:
    vekSHJwXmRtWDzKarfosnIlBNgMbpT='Collection-Rails-Curation'
   elif vType in['ALL','KIDS']:
    vekSHJwXmRtWDzKarfosnIlBNgMbpT='Explores-Categories'
   for vekSHJwXmRtWDzKarfosnIlBNgMbpq in vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('data'):
    if vekSHJwXmRtWDzKarfosnIlBNgMbpq.get('type')==vekSHJwXmRtWDzKarfosnIlBNgMbpT:
     for vekSHJwXmRtWDzKarfosnIlBNgMbpL in vekSHJwXmRtWDzKarfosnIlBNgMbpq.get('data'):
      if vType in['TVSHOWS','MOVIES']:
       vekSHJwXmRtWDzKarfosnIlBNgMbpO=vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('collectionId')
      elif vType in['EDUCATION','ALL','KIDS']:
       vekSHJwXmRtWDzKarfosnIlBNgMbpO=vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('id')
      vekSHJwXmRtWDzKarfosnIlBNgMbpQ={'collectionId':vekSHJwXmRtWDzKarfosnIlBNgMbpO,'title':vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('name'),'category':vekSHJwXmRtWDzKarfosnIlBNgMbpq.get('category'),'pre_title':'',}
      vekSHJwXmRtWDzKarfosnIlBNgMbqA.append(vekSHJwXmRtWDzKarfosnIlBNgMbpQ)
     break
  except vekSHJwXmRtWDzKarfosnIlBNgMbOT as exception:
   vekSHJwXmRtWDzKarfosnIlBNgMbLd(exception)
   return[]
  return vekSHJwXmRtWDzKarfosnIlBNgMbqA
 def Get_Category_List(vekSHJwXmRtWDzKarfosnIlBNgMbTp,vType,vekSHJwXmRtWDzKarfosnIlBNgMbpO,page_int):
  vekSHJwXmRtWDzKarfosnIlBNgMbqA=[] 
  vekSHJwXmRtWDzKarfosnIlBNgMbpP=vekSHJwXmRtWDzKarfosnIlBNgMbLF
  try:
   if vType in['ALL','KIDS']:
    vekSHJwXmRtWDzKarfosnIlBNgMbTy={'x-membersrl':vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['COOKIES']['member_srl'],'x-pcid':vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['COOKIES']['PCID'],'x-profileid':vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['SESSION']['profileId'],}
    vekSHJwXmRtWDzKarfosnIlBNgMbqy={'platform':'WEBCLIENT','page':vekSHJwXmRtWDzKarfosnIlBNgMbLC(page_int),'perPage':vekSHJwXmRtWDzKarfosnIlBNgMbLC(vekSHJwXmRtWDzKarfosnIlBNgMbTp.PAGE_LIMIT),'locale':'ko','sort':'',}
    vekSHJwXmRtWDzKarfosnIlBNgMbqi=vekSHJwXmRtWDzKarfosnIlBNgMbTp.API_VIEWURL+'/v1/discover/categories/'+vekSHJwXmRtWDzKarfosnIlBNgMbpO+'/titles'
    vekSHJwXmRtWDzKarfosnIlBNgMbqh=vekSHJwXmRtWDzKarfosnIlBNgMbTp.callRequestCookies('Get',vekSHJwXmRtWDzKarfosnIlBNgMbqi,payload=vekSHJwXmRtWDzKarfosnIlBNgMbLV,params=vekSHJwXmRtWDzKarfosnIlBNgMbqy,headers=vekSHJwXmRtWDzKarfosnIlBNgMbTy,cookies=vekSHJwXmRtWDzKarfosnIlBNgMbLV,redirects=vekSHJwXmRtWDzKarfosnIlBNgMbOL)
   else: 
    vekSHJwXmRtWDzKarfosnIlBNgMbqy={'platform':'WEBCLIENT','page':vekSHJwXmRtWDzKarfosnIlBNgMbLC(page_int),'perPage':vekSHJwXmRtWDzKarfosnIlBNgMbLC(vekSHJwXmRtWDzKarfosnIlBNgMbTp.PAGE_LIMIT),}
    vekSHJwXmRtWDzKarfosnIlBNgMbqi=vekSHJwXmRtWDzKarfosnIlBNgMbTp.API_VIEWURL+'/v1/discover/collections/'+vekSHJwXmRtWDzKarfosnIlBNgMbpO+'/titles'
    vekSHJwXmRtWDzKarfosnIlBNgMbqh=vekSHJwXmRtWDzKarfosnIlBNgMbTp.callRequestCookies('Get',vekSHJwXmRtWDzKarfosnIlBNgMbqi,payload=vekSHJwXmRtWDzKarfosnIlBNgMbLV,params=vekSHJwXmRtWDzKarfosnIlBNgMbqy,headers=vekSHJwXmRtWDzKarfosnIlBNgMbLV,cookies=vekSHJwXmRtWDzKarfosnIlBNgMbLV,redirects=vekSHJwXmRtWDzKarfosnIlBNgMbOL)
   if vekSHJwXmRtWDzKarfosnIlBNgMbqh.status_code not in[200]:return[],vekSHJwXmRtWDzKarfosnIlBNgMbLF
   vekSHJwXmRtWDzKarfosnIlBNgMbqG=json.loads(vekSHJwXmRtWDzKarfosnIlBNgMbqh.text)
   if vType in['ALL','KIDS']:
    vekSHJwXmRtWDzKarfosnIlBNgMbpE=vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('data').get('data')
   else:
    vekSHJwXmRtWDzKarfosnIlBNgMbpE=vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('data')
   for vekSHJwXmRtWDzKarfosnIlBNgMbpL in vekSHJwXmRtWDzKarfosnIlBNgMbpE:
    vekSHJwXmRtWDzKarfosnIlBNgMbpi=vekSHJwXmRtWDzKarfosnIlBNgMbpu=vekSHJwXmRtWDzKarfosnIlBNgMbLU=vekSHJwXmRtWDzKarfosnIlBNgMbLx=''
    if 'poster' in vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('images'):vekSHJwXmRtWDzKarfosnIlBNgMbpi =vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('images'):vekSHJwXmRtWDzKarfosnIlBNgMbpu =vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('images').get('story-art').get('url') +'?imwidth=600'
    if 'title-treatment' in vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('images'):vekSHJwXmRtWDzKarfosnIlBNgMbLU=vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('images').get('title-treatment').get('url')+'?imwidth=300'
    if 'story-art' in vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('images'):vekSHJwXmRtWDzKarfosnIlBNgMbLx =vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('images').get('story-art').get('url') +'?imwidth=600'
    vekSHJwXmRtWDzKarfosnIlBNgMbpY=''
    if vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('badge')not in[{},vekSHJwXmRtWDzKarfosnIlBNgMbLV]:
     for i in vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('badge').get('text'):
      vekSHJwXmRtWDzKarfosnIlBNgMbpY+=i.get('text')
    vekSHJwXmRtWDzKarfosnIlBNgMbph=''
    if vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('seasonList')!=vekSHJwXmRtWDzKarfosnIlBNgMbLV:
     vekSHJwXmRtWDzKarfosnIlBNgMbph=','.join(vekSHJwXmRtWDzKarfosnIlBNgMbLC(e)for e in vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('seasonList'))
    vekSHJwXmRtWDzKarfosnIlBNgMbpx =[]
    for vekSHJwXmRtWDzKarfosnIlBNgMbpU in vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('tags'):
     vekSHJwXmRtWDzKarfosnIlBNgMbpx.append(vekSHJwXmRtWDzKarfosnIlBNgMbpU.get('tag'))
    vekSHJwXmRtWDzKarfosnIlBNgMbpQ={'id':vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('id'),'title':vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('title'),'thumbnail':{'poster':vekSHJwXmRtWDzKarfosnIlBNgMbpi,'thumb':vekSHJwXmRtWDzKarfosnIlBNgMbpu,'clearlogo':vekSHJwXmRtWDzKarfosnIlBNgMbLU,'fanart':vekSHJwXmRtWDzKarfosnIlBNgMbLx},'mpaa':vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('age_rating'),'duration':vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('running_time'),'asis':vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('as'),'badge':vekSHJwXmRtWDzKarfosnIlBNgMbpY,'year':vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('meta').get('releaseYear'),'seasonList':vekSHJwXmRtWDzKarfosnIlBNgMbph,'genreList':vekSHJwXmRtWDzKarfosnIlBNgMbpx,}
    vekSHJwXmRtWDzKarfosnIlBNgMbqA.append(vekSHJwXmRtWDzKarfosnIlBNgMbpQ)
   if vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('pagination').get('totalPages')>page_int:
    vekSHJwXmRtWDzKarfosnIlBNgMbpP=vekSHJwXmRtWDzKarfosnIlBNgMbOL
  except vekSHJwXmRtWDzKarfosnIlBNgMbOT as exception:
   vekSHJwXmRtWDzKarfosnIlBNgMbLd(exception)
   return[],vekSHJwXmRtWDzKarfosnIlBNgMbLF
  return vekSHJwXmRtWDzKarfosnIlBNgMbqA,vekSHJwXmRtWDzKarfosnIlBNgMbpP
 def Get_Episode_List(vekSHJwXmRtWDzKarfosnIlBNgMbTp,programId,season):
  vekSHJwXmRtWDzKarfosnIlBNgMbqA=[] 
  try:
   vekSHJwXmRtWDzKarfosnIlBNgMbqi=vekSHJwXmRtWDzKarfosnIlBNgMbTp.API_VIEWURL+'/v1/discover/titles/'+programId+'/episodes'
   vekSHJwXmRtWDzKarfosnIlBNgMbqy={'season':season,'sort':'true','locale':'ko',}
   vekSHJwXmRtWDzKarfosnIlBNgMbqh=vekSHJwXmRtWDzKarfosnIlBNgMbTp.callRequestCookies('Get',vekSHJwXmRtWDzKarfosnIlBNgMbqi,payload=vekSHJwXmRtWDzKarfosnIlBNgMbLV,params=vekSHJwXmRtWDzKarfosnIlBNgMbqy,headers=vekSHJwXmRtWDzKarfosnIlBNgMbLV,cookies=vekSHJwXmRtWDzKarfosnIlBNgMbLV,redirects=vekSHJwXmRtWDzKarfosnIlBNgMbOL)
   if vekSHJwXmRtWDzKarfosnIlBNgMbqh.status_code not in[200]:return[]
   vekSHJwXmRtWDzKarfosnIlBNgMbqG=json.loads(vekSHJwXmRtWDzKarfosnIlBNgMbqh.text)
   for vekSHJwXmRtWDzKarfosnIlBNgMbpL in vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('data'):
    vekSHJwXmRtWDzKarfosnIlBNgMbpu=''
    if 'story-art' in vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('images'):vekSHJwXmRtWDzKarfosnIlBNgMbpu =vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('images').get('story-art').get('url')+'?imwidth=600'
    vekSHJwXmRtWDzKarfosnIlBNgMbpx =[]
    for vekSHJwXmRtWDzKarfosnIlBNgMbpU in vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('tags'):
     vekSHJwXmRtWDzKarfosnIlBNgMbpx.append(vekSHJwXmRtWDzKarfosnIlBNgMbpU.get('tag'))
    vekSHJwXmRtWDzKarfosnIlBNgMbpQ={'id':vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('id'),'title':vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('title'),'thumbnail':{'thumb':vekSHJwXmRtWDzKarfosnIlBNgMbpu,'fanart':vekSHJwXmRtWDzKarfosnIlBNgMbpu},'mpaa':vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('age_rating'),'duration':vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('running_time'),'asis':vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('as'),'year':vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('meta').get('releaseYear'),'episode':vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('episode'),'genreList':vekSHJwXmRtWDzKarfosnIlBNgMbpx,'desc':vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('description'),}
    vekSHJwXmRtWDzKarfosnIlBNgMbqA.append(vekSHJwXmRtWDzKarfosnIlBNgMbpQ)
  except vekSHJwXmRtWDzKarfosnIlBNgMbOT as exception:
   vekSHJwXmRtWDzKarfosnIlBNgMbLd(exception)
   return[]
  return vekSHJwXmRtWDzKarfosnIlBNgMbqA
 def Get_vInfo(vekSHJwXmRtWDzKarfosnIlBNgMbTp,titleId):
  try:
   vekSHJwXmRtWDzKarfosnIlBNgMbqi=vekSHJwXmRtWDzKarfosnIlBNgMbTp.API_VIEWURL+'/v1/discover/titles/'+titleId 
   vekSHJwXmRtWDzKarfosnIlBNgMbqy={'platform':'WEBCLIENT','locale':'ko','filterRestrictedContent':'false',}
   vekSHJwXmRtWDzKarfosnIlBNgMbqh=vekSHJwXmRtWDzKarfosnIlBNgMbTp.callRequestCookies('Get',vekSHJwXmRtWDzKarfosnIlBNgMbqi,payload=vekSHJwXmRtWDzKarfosnIlBNgMbLV,params=vekSHJwXmRtWDzKarfosnIlBNgMbqy,headers=vekSHJwXmRtWDzKarfosnIlBNgMbLV,cookies=vekSHJwXmRtWDzKarfosnIlBNgMbLV,redirects=vekSHJwXmRtWDzKarfosnIlBNgMbOL)
   if vekSHJwXmRtWDzKarfosnIlBNgMbqh.status_code not in[200]:return '','',''
   vekSHJwXmRtWDzKarfosnIlBNgMbqG=json.loads(vekSHJwXmRtWDzKarfosnIlBNgMbqh.text).get('data')
   vekSHJwXmRtWDzKarfosnIlBNgMbph=''
   if vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('seasonList')!=vekSHJwXmRtWDzKarfosnIlBNgMbLV:
    vekSHJwXmRtWDzKarfosnIlBNgMbph=','.join(vekSHJwXmRtWDzKarfosnIlBNgMbLC(e)for e in vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('seasonList'))
   vekSHJwXmRtWDzKarfosnIlBNgMbpc={'age_rating':vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('age_rating'),'asset_id':vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('asset_id'),'availability':vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('availability'),'deal_id':vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('deal_id'),'downloadable':'true' if vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('downloadable')else 'false','region':vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('region'),'streamable':'true' if vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('streamable')else 'false','asis':vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('as'),'seasonList':vekSHJwXmRtWDzKarfosnIlBNgMbph}
  except vekSHJwXmRtWDzKarfosnIlBNgMbOT as exception:
   vekSHJwXmRtWDzKarfosnIlBNgMbLd(exception)
   return{}
  return vekSHJwXmRtWDzKarfosnIlBNgMbpc
 def Get_eInfo(vekSHJwXmRtWDzKarfosnIlBNgMbTp,eventId):
  try:
   vekSHJwXmRtWDzKarfosnIlBNgMbqi=vekSHJwXmRtWDzKarfosnIlBNgMbTp.API_VIEWURL+'/v1/discover/events/'+eventId 
   vekSHJwXmRtWDzKarfosnIlBNgMbqy={'locale':'ko'}
   vekSHJwXmRtWDzKarfosnIlBNgMbqh=vekSHJwXmRtWDzKarfosnIlBNgMbTp.callRequestCookies('Get',vekSHJwXmRtWDzKarfosnIlBNgMbqi,payload=vekSHJwXmRtWDzKarfosnIlBNgMbLV,params=vekSHJwXmRtWDzKarfosnIlBNgMbqy,headers=vekSHJwXmRtWDzKarfosnIlBNgMbLV,cookies=vekSHJwXmRtWDzKarfosnIlBNgMbLV,redirects=vekSHJwXmRtWDzKarfosnIlBNgMbOL)
   if vekSHJwXmRtWDzKarfosnIlBNgMbqh.status_code not in[200]:return '','',''
   vekSHJwXmRtWDzKarfosnIlBNgMbqG=json.loads(vekSHJwXmRtWDzKarfosnIlBNgMbqh.text).get('data')
   vekSHJwXmRtWDzKarfosnIlBNgMbpc={'asset_id':vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('asset_id'),'deal_id':vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('deal_id'),'region':vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('region'),'streamable':'true' if vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('streamable')else 'false',}
  except vekSHJwXmRtWDzKarfosnIlBNgMbOT as exception:
   vekSHJwXmRtWDzKarfosnIlBNgMbLd(exception)
   return{}
  return vekSHJwXmRtWDzKarfosnIlBNgMbpc
 def GetBroadURL(vekSHJwXmRtWDzKarfosnIlBNgMbTp,titleId):
  vekSHJwXmRtWDzKarfosnIlBNgMbpj=''
  vekSHJwXmRtWDzKarfosnIlBNgMbpG =''
  vekSHJwXmRtWDzKarfosnIlBNgMbpc=vekSHJwXmRtWDzKarfosnIlBNgMbTp.Get_vInfo(titleId)
  if vekSHJwXmRtWDzKarfosnIlBNgMbpc=={}:return '',''
  try:
   vekSHJwXmRtWDzKarfosnIlBNgMbqi=vekSHJwXmRtWDzKarfosnIlBNgMbTp.API_DOMAIN+'/api/playback/play' 
   vekSHJwXmRtWDzKarfosnIlBNgMbqy={'titleId':titleId}
   vekSHJwXmRtWDzKarfosnIlBNgMbqp,vekSHJwXmRtWDzKarfosnIlBNgMbqL,vekSHJwXmRtWDzKarfosnIlBNgMbqO=vekSHJwXmRtWDzKarfosnIlBNgMbTp.Make_authHeader()
   vekSHJwXmRtWDzKarfosnIlBNgMbTy={'traceparent':vekSHJwXmRtWDzKarfosnIlBNgMbqp,'tracestate':vekSHJwXmRtWDzKarfosnIlBNgMbqL,'newrelic':vekSHJwXmRtWDzKarfosnIlBNgMbqO,'x-drm':'com.microsoft.playready','x-app-version':'1.33.5','x-device-id':'','x-device-os-version':vekSHJwXmRtWDzKarfosnIlBNgMbTp.OS_VERSION,'x-force-raw':'true','x-nr-session-id':vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['COOKIES']['session_web_id'],'x-pcid':vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['COOKIES']['PCID'],'x-platform':'web','x-profileId':vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['SESSION']['profileId'],'x-profileType':'standard','x-sessionid':vekSHJwXmRtWDzKarfosnIlBNgMbTp.generatePvId(genType='1'),'x-title-age-rating':vekSHJwXmRtWDzKarfosnIlBNgMbpc.get('age_rating'),'x-title-availability':vekSHJwXmRtWDzKarfosnIlBNgMbpc.get('availability'),'x-title-brightcove-id':vekSHJwXmRtWDzKarfosnIlBNgMbpc.get('asset_id'),'x-title-deal-id':vekSHJwXmRtWDzKarfosnIlBNgMbpc.get('deal_id'),'x-title-downloadable':vekSHJwXmRtWDzKarfosnIlBNgMbpc.get('downloadable'),'x-title-region':vekSHJwXmRtWDzKarfosnIlBNgMbpc.get('region'),'x-title-streamable':vekSHJwXmRtWDzKarfosnIlBNgMbpc.get('streamable'),}
   vekSHJwXmRtWDzKarfosnIlBNgMbqY=vekSHJwXmRtWDzKarfosnIlBNgMbTp.make_CP_DefaultCookies()
   vekSHJwXmRtWDzKarfosnIlBNgMbqh=vekSHJwXmRtWDzKarfosnIlBNgMbTp.callRequestCookies('Get',vekSHJwXmRtWDzKarfosnIlBNgMbqi,payload=vekSHJwXmRtWDzKarfosnIlBNgMbLV,params=vekSHJwXmRtWDzKarfosnIlBNgMbqy,headers=vekSHJwXmRtWDzKarfosnIlBNgMbTy,cookies=vekSHJwXmRtWDzKarfosnIlBNgMbqY,redirects=vekSHJwXmRtWDzKarfosnIlBNgMbOL)
   if vekSHJwXmRtWDzKarfosnIlBNgMbqh.status_code not in[200]:return '',json.loads(vekSHJwXmRtWDzKarfosnIlBNgMbqh.text).get('error').get('detail')
   vekSHJwXmRtWDzKarfosnIlBNgMbqG=json.loads(vekSHJwXmRtWDzKarfosnIlBNgMbqh.text)
   if vekSHJwXmRtWDzKarfosnIlBNgMbpj=='':
    for vekSHJwXmRtWDzKarfosnIlBNgMbpL in vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('data').get('raw').get('sources'):
     if 'key_systems' in vekSHJwXmRtWDzKarfosnIlBNgMbpL and 'codecs' not in vekSHJwXmRtWDzKarfosnIlBNgMbpL:
      if vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('type')=='application/dash+xml' and 'com.widevine.alpha' in vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('key_systems')and vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('src').startswith('https://')==vekSHJwXmRtWDzKarfosnIlBNgMbOL:
       vekSHJwXmRtWDzKarfosnIlBNgMbpj=vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('src')
       vekSHJwXmRtWDzKarfosnIlBNgMbpG =vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if vekSHJwXmRtWDzKarfosnIlBNgMbpj=='':
    for vekSHJwXmRtWDzKarfosnIlBNgMbpL in vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('data').get('raw').get('sources'):
     if 'key_systems' in vekSHJwXmRtWDzKarfosnIlBNgMbpL and 'codecs' not in vekSHJwXmRtWDzKarfosnIlBNgMbpL:
      if vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('key_systems')and vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('src').startswith('https://')==vekSHJwXmRtWDzKarfosnIlBNgMbOL:
       vekSHJwXmRtWDzKarfosnIlBNgMbpj=vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('src')
       vekSHJwXmRtWDzKarfosnIlBNgMbpG =vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if vekSHJwXmRtWDzKarfosnIlBNgMbpj=='':
    for vekSHJwXmRtWDzKarfosnIlBNgMbpL in vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('data').get('raw').get('sources'):
     if 'key_systems' in vekSHJwXmRtWDzKarfosnIlBNgMbpL and 'codecs' in vekSHJwXmRtWDzKarfosnIlBNgMbpL:
      if vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('type')=='application/dash+xml' and 'com.widevine.alpha' in vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('key_systems')and vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('src').startswith('https://')==vekSHJwXmRtWDzKarfosnIlBNgMbOL:
       vekSHJwXmRtWDzKarfosnIlBNgMbpj=vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('src')
       vekSHJwXmRtWDzKarfosnIlBNgMbpG =vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if vekSHJwXmRtWDzKarfosnIlBNgMbpj=='':
    for vekSHJwXmRtWDzKarfosnIlBNgMbpL in vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('data').get('raw').get('sources'):
     if 'key_systems' in vekSHJwXmRtWDzKarfosnIlBNgMbpL and 'codecs' in vekSHJwXmRtWDzKarfosnIlBNgMbpL:
      if vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('key_systems')and vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('src').startswith('https://')==vekSHJwXmRtWDzKarfosnIlBNgMbOL:
       vekSHJwXmRtWDzKarfosnIlBNgMbpj=vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('src')
       vekSHJwXmRtWDzKarfosnIlBNgMbpG =vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
  except vekSHJwXmRtWDzKarfosnIlBNgMbOT as exception:
   vekSHJwXmRtWDzKarfosnIlBNgMbLd(exception)
   return '',''
  return vekSHJwXmRtWDzKarfosnIlBNgMbpj,vekSHJwXmRtWDzKarfosnIlBNgMbpG
 def GetEventURL(vekSHJwXmRtWDzKarfosnIlBNgMbTp,eventId,vekSHJwXmRtWDzKarfosnIlBNgMbLP):
  vekSHJwXmRtWDzKarfosnIlBNgMbpj=''
  vekSHJwXmRtWDzKarfosnIlBNgMbpG =''
  vekSHJwXmRtWDzKarfosnIlBNgMbpc=vekSHJwXmRtWDzKarfosnIlBNgMbTp.Get_eInfo(eventId)
  if vekSHJwXmRtWDzKarfosnIlBNgMbpc=={}:return '',''
  try:
   vekSHJwXmRtWDzKarfosnIlBNgMbqi=vekSHJwXmRtWDzKarfosnIlBNgMbTp.API_DOMAIN+'/api/playback/play' 
   vekSHJwXmRtWDzKarfosnIlBNgMbqy={'titleId':eventId,'titleType':vekSHJwXmRtWDzKarfosnIlBNgMbLP,}
   vekSHJwXmRtWDzKarfosnIlBNgMbqp,vekSHJwXmRtWDzKarfosnIlBNgMbqL,vekSHJwXmRtWDzKarfosnIlBNgMbqO=vekSHJwXmRtWDzKarfosnIlBNgMbTp.Make_authHeader()
   vekSHJwXmRtWDzKarfosnIlBNgMbTy={'traceparent':vekSHJwXmRtWDzKarfosnIlBNgMbqp,'tracestate':vekSHJwXmRtWDzKarfosnIlBNgMbqL,'newrelic':vekSHJwXmRtWDzKarfosnIlBNgMbqO,'x-force-raw':'true','x-pcid':vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['COOKIES']['PCID'],'x-platform':'web','x-profileId':vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':vekSHJwXmRtWDzKarfosnIlBNgMbpc.get('asset_id'),'x-title-deal-id':vekSHJwXmRtWDzKarfosnIlBNgMbpc.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':vekSHJwXmRtWDzKarfosnIlBNgMbpc.get('region'),'x-title-streamable':vekSHJwXmRtWDzKarfosnIlBNgMbpc.get('streamable'),}
   vekSHJwXmRtWDzKarfosnIlBNgMbqY=vekSHJwXmRtWDzKarfosnIlBNgMbTp.make_CP_DefaultCookies()
   vekSHJwXmRtWDzKarfosnIlBNgMbqh=vekSHJwXmRtWDzKarfosnIlBNgMbTp.callRequestCookies('Get',vekSHJwXmRtWDzKarfosnIlBNgMbqi,payload=vekSHJwXmRtWDzKarfosnIlBNgMbLV,params=vekSHJwXmRtWDzKarfosnIlBNgMbqy,headers=vekSHJwXmRtWDzKarfosnIlBNgMbTy,cookies=vekSHJwXmRtWDzKarfosnIlBNgMbqY,redirects=vekSHJwXmRtWDzKarfosnIlBNgMbOL)
   if vekSHJwXmRtWDzKarfosnIlBNgMbqh.status_code not in[200]:return '',json.loads(vekSHJwXmRtWDzKarfosnIlBNgMbqh.text).get('error').get('detail')
   vekSHJwXmRtWDzKarfosnIlBNgMbqG=json.loads(vekSHJwXmRtWDzKarfosnIlBNgMbqh.text)
   for vekSHJwXmRtWDzKarfosnIlBNgMbpL in vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('data').get('raw').get('sources'):
    if vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('type')=='application/dash+xml' and vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('src')[0:8]=='https://':
     vekSHJwXmRtWDzKarfosnIlBNgMbpj=vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('src')
     if 'key_systems' in vekSHJwXmRtWDzKarfosnIlBNgMbpL:
      vekSHJwXmRtWDzKarfosnIlBNgMbpG =vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('key_systems').get('com.widevine.alpha').get('license_url')
     break
  except vekSHJwXmRtWDzKarfosnIlBNgMbOT as exception:
   vekSHJwXmRtWDzKarfosnIlBNgMbLd(exception)
   return '',''
  return vekSHJwXmRtWDzKarfosnIlBNgMbpj,vekSHJwXmRtWDzKarfosnIlBNgMbpG
 def GetEventURL_Live(vekSHJwXmRtWDzKarfosnIlBNgMbTp,eventId,vekSHJwXmRtWDzKarfosnIlBNgMbLP):
  vekSHJwXmRtWDzKarfosnIlBNgMbpj=''
  vekSHJwXmRtWDzKarfosnIlBNgMbpG =''
  vekSHJwXmRtWDzKarfosnIlBNgMbpc=vekSHJwXmRtWDzKarfosnIlBNgMbTp.Get_eInfo(eventId)
  if vekSHJwXmRtWDzKarfosnIlBNgMbpc=={}:return '',''
  try:
   vekSHJwXmRtWDzKarfosnIlBNgMbqi=vekSHJwXmRtWDzKarfosnIlBNgMbTp.API_DOMAIN+'/api/playback/play' 
   vekSHJwXmRtWDzKarfosnIlBNgMbqy={'titleId':eventId,'titleType':vekSHJwXmRtWDzKarfosnIlBNgMbLP,}
   vekSHJwXmRtWDzKarfosnIlBNgMbqp,vekSHJwXmRtWDzKarfosnIlBNgMbqL,vekSHJwXmRtWDzKarfosnIlBNgMbqO=vekSHJwXmRtWDzKarfosnIlBNgMbTp.Make_authHeader()
   vekSHJwXmRtWDzKarfosnIlBNgMbTy={'traceparent':vekSHJwXmRtWDzKarfosnIlBNgMbqp,'tracestate':vekSHJwXmRtWDzKarfosnIlBNgMbqL,'newrelic':vekSHJwXmRtWDzKarfosnIlBNgMbqO,'x-force-raw':'true','x-pcid':vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['COOKIES']['PCID'],'x-platform':'web','x-profileId':vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':vekSHJwXmRtWDzKarfosnIlBNgMbpc.get('asset_id'),'x-title-deal-id':vekSHJwXmRtWDzKarfosnIlBNgMbpc.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':vekSHJwXmRtWDzKarfosnIlBNgMbpc.get('region'),'x-title-streamable':vekSHJwXmRtWDzKarfosnIlBNgMbpc.get('streamable'),}
   vekSHJwXmRtWDzKarfosnIlBNgMbqY=vekSHJwXmRtWDzKarfosnIlBNgMbTp.make_CP_DefaultCookies()
   vekSHJwXmRtWDzKarfosnIlBNgMbqh=vekSHJwXmRtWDzKarfosnIlBNgMbTp.callRequestCookies('Get',vekSHJwXmRtWDzKarfosnIlBNgMbqi,payload=vekSHJwXmRtWDzKarfosnIlBNgMbLV,params=vekSHJwXmRtWDzKarfosnIlBNgMbqy,headers=vekSHJwXmRtWDzKarfosnIlBNgMbTy,cookies=vekSHJwXmRtWDzKarfosnIlBNgMbqY,redirects=vekSHJwXmRtWDzKarfosnIlBNgMbOL)
   if vekSHJwXmRtWDzKarfosnIlBNgMbqh.status_code not in[200]:return '',json.loads(vekSHJwXmRtWDzKarfosnIlBNgMbqh.text).get('error').get('detail')
   vekSHJwXmRtWDzKarfosnIlBNgMbqG=json.loads(vekSHJwXmRtWDzKarfosnIlBNgMbqh.text)
   if vekSHJwXmRtWDzKarfosnIlBNgMbpj=='':
    for vekSHJwXmRtWDzKarfosnIlBNgMbpL in vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('data').get('raw').get('sources'):
     if 'key_systems' in vekSHJwXmRtWDzKarfosnIlBNgMbpL:
      if vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('type')=='application/dash+xml' and 'com.widevine.alpha' in vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('key_systems')and vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('src').startswith('https://')==vekSHJwXmRtWDzKarfosnIlBNgMbOL:
       vekSHJwXmRtWDzKarfosnIlBNgMbpj=vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('src')
       vekSHJwXmRtWDzKarfosnIlBNgMbpG =vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('key_systems').get('com.widevine.alpha').get('license_url')
   if vekSHJwXmRtWDzKarfosnIlBNgMbpj=='':
    for vekSHJwXmRtWDzKarfosnIlBNgMbpL in vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('data').get('raw').get('sources'):
     if 'key_systems' in vekSHJwXmRtWDzKarfosnIlBNgMbpL:
      if vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('key_systems')and vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('src').startswith('https://')==vekSHJwXmRtWDzKarfosnIlBNgMbOL:
       vekSHJwXmRtWDzKarfosnIlBNgMbpj=vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('src')
       vekSHJwXmRtWDzKarfosnIlBNgMbpG =vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('key_systems').get('com.widevine.alpha').get('license_url')
   if vekSHJwXmRtWDzKarfosnIlBNgMbpj=='':
    for vekSHJwXmRtWDzKarfosnIlBNgMbpL in vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('data').get('raw').get('sources'):
     if vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('type')=='application/dash+xml' and vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('src').startswith('https://')==vekSHJwXmRtWDzKarfosnIlBNgMbOL:
      vekSHJwXmRtWDzKarfosnIlBNgMbpj=vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('src')
   if vekSHJwXmRtWDzKarfosnIlBNgMbpj=='':
    for vekSHJwXmRtWDzKarfosnIlBNgMbpL in vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('data').get('raw').get('sources'):
     if vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('type')=='application/x-mpegURL' and vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('src').startswith('https://')==vekSHJwXmRtWDzKarfosnIlBNgMbOL:
      vekSHJwXmRtWDzKarfosnIlBNgMbpj=vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('src')
  except vekSHJwXmRtWDzKarfosnIlBNgMbOT as exception:
   vekSHJwXmRtWDzKarfosnIlBNgMbLd(exception)
   return '',''
  return vekSHJwXmRtWDzKarfosnIlBNgMbpj,vekSHJwXmRtWDzKarfosnIlBNgMbpG
 def Get_Url_PostFix(vekSHJwXmRtWDzKarfosnIlBNgMbTp,in_url):
  vekSHJwXmRtWDzKarfosnIlBNgMbpV=urllib.parse.urlparse(in_url) 
  vekSHJwXmRtWDzKarfosnIlBNgMbpF =vekSHJwXmRtWDzKarfosnIlBNgMbpV.path.strip('/').split('/')
  vekSHJwXmRtWDzKarfosnIlBNgMbpd =vekSHJwXmRtWDzKarfosnIlBNgMbpF[vekSHJwXmRtWDzKarfosnIlBNgMbOq(vekSHJwXmRtWDzKarfosnIlBNgMbpF)-1]
  vekSHJwXmRtWDzKarfosnIlBNgMbpC=vekSHJwXmRtWDzKarfosnIlBNgMbpd.split('.')
  return vekSHJwXmRtWDzKarfosnIlBNgMbpC[vekSHJwXmRtWDzKarfosnIlBNgMbOq(vekSHJwXmRtWDzKarfosnIlBNgMbpC)-1]
 def Get_Theme_GroupList(vekSHJwXmRtWDzKarfosnIlBNgMbTp,vType):
  vekSHJwXmRtWDzKarfosnIlBNgMbqA=[] 
  try:
   vekSHJwXmRtWDzKarfosnIlBNgMbqi=vekSHJwXmRtWDzKarfosnIlBNgMbTp.API_VIEWURL+'/v2/discover/feed' 
   vekSHJwXmRtWDzKarfosnIlBNgMbqy={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':vekSHJwXmRtWDzKarfosnIlBNgMbLC(vekSHJwXmRtWDzKarfosnIlBNgMbTp.PAGE_LIMIT),'filterRestrictedContent':'false',}
   vekSHJwXmRtWDzKarfosnIlBNgMbqh=vekSHJwXmRtWDzKarfosnIlBNgMbTp.callRequestCookies('Get',vekSHJwXmRtWDzKarfosnIlBNgMbqi,payload=vekSHJwXmRtWDzKarfosnIlBNgMbLV,params=vekSHJwXmRtWDzKarfosnIlBNgMbqy,headers=vekSHJwXmRtWDzKarfosnIlBNgMbLV,cookies=vekSHJwXmRtWDzKarfosnIlBNgMbLV,redirects=vekSHJwXmRtWDzKarfosnIlBNgMbOL)
   if vekSHJwXmRtWDzKarfosnIlBNgMbqh.status_code not in[200]:return[]
   vekSHJwXmRtWDzKarfosnIlBNgMbqG=json.loads(vekSHJwXmRtWDzKarfosnIlBNgMbqh.text)
   for vekSHJwXmRtWDzKarfosnIlBNgMbpL in vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('data'):
    if vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('type')=='Title-Rails-Curation':
     vekSHJwXmRtWDzKarfosnIlBNgMbpA =''
     vekSHJwXmRtWDzKarfosnIlBNgMbpy=7
     try:
      for i in vekSHJwXmRtWDzKarfosnIlBNgMbOQ(vekSHJwXmRtWDzKarfosnIlBNgMbOq(vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('data'))):
       if i>=vekSHJwXmRtWDzKarfosnIlBNgMbpy:
        vekSHJwXmRtWDzKarfosnIlBNgMbpA=vekSHJwXmRtWDzKarfosnIlBNgMbpA+'...'
        break
       vekSHJwXmRtWDzKarfosnIlBNgMbpA=vekSHJwXmRtWDzKarfosnIlBNgMbpA+vekSHJwXmRtWDzKarfosnIlBNgMbpL['data'][i]['title']+'\n'
     except vekSHJwXmRtWDzKarfosnIlBNgMbOT as exception:
      vekSHJwXmRtWDzKarfosnIlBNgMbLd(exception)
     vekSHJwXmRtWDzKarfosnIlBNgMbpQ={'collectionId':vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('obj_id'),'title':vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('row_name'),'category':vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('category'),'pre_title':vekSHJwXmRtWDzKarfosnIlBNgMbpA,}
     vekSHJwXmRtWDzKarfosnIlBNgMbqA.append(vekSHJwXmRtWDzKarfosnIlBNgMbpQ)
  except vekSHJwXmRtWDzKarfosnIlBNgMbOT as exception:
   vekSHJwXmRtWDzKarfosnIlBNgMbLd(exception)
   return[]
  return vekSHJwXmRtWDzKarfosnIlBNgMbqA
 def Get_Event_GroupList(vekSHJwXmRtWDzKarfosnIlBNgMbTp):
  vekSHJwXmRtWDzKarfosnIlBNgMbqA=[] 
  try:
   vekSHJwXmRtWDzKarfosnIlBNgMbqi=vekSHJwXmRtWDzKarfosnIlBNgMbTp.API_VIEWURL+'/v2/discover/feed' 
   vekSHJwXmRtWDzKarfosnIlBNgMbqy={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':7,'filterRestrictedContent':'false',}
   vekSHJwXmRtWDzKarfosnIlBNgMbqh=vekSHJwXmRtWDzKarfosnIlBNgMbTp.callRequestCookies('Get',vekSHJwXmRtWDzKarfosnIlBNgMbqi,payload=vekSHJwXmRtWDzKarfosnIlBNgMbLV,params=vekSHJwXmRtWDzKarfosnIlBNgMbqy,headers=vekSHJwXmRtWDzKarfosnIlBNgMbLV,cookies=vekSHJwXmRtWDzKarfosnIlBNgMbLV,redirects=vekSHJwXmRtWDzKarfosnIlBNgMbOL)
   if vekSHJwXmRtWDzKarfosnIlBNgMbqh.status_code not in[200]:return[]
   vekSHJwXmRtWDzKarfosnIlBNgMbqG=json.loads(vekSHJwXmRtWDzKarfosnIlBNgMbqh.text)
   for vekSHJwXmRtWDzKarfosnIlBNgMbpL in vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('data'):
    if vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('row_name').strip()!='':
     vekSHJwXmRtWDzKarfosnIlBNgMbpA =''
     vekSHJwXmRtWDzKarfosnIlBNgMbpy=7
     try:
      for i in vekSHJwXmRtWDzKarfosnIlBNgMbOQ(vekSHJwXmRtWDzKarfosnIlBNgMbOq(vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('data'))):
       if i>=vekSHJwXmRtWDzKarfosnIlBNgMbpy:
        vekSHJwXmRtWDzKarfosnIlBNgMbpA=vekSHJwXmRtWDzKarfosnIlBNgMbpA+'...'
        break
       vekSHJwXmRtWDzKarfosnIlBNgMbpA=vekSHJwXmRtWDzKarfosnIlBNgMbpA+vekSHJwXmRtWDzKarfosnIlBNgMbpL['data'][i]['title']+'\n'
     except vekSHJwXmRtWDzKarfosnIlBNgMbOT as exception:
      vekSHJwXmRtWDzKarfosnIlBNgMbLd(exception)
     vekSHJwXmRtWDzKarfosnIlBNgMbpQ={'collectionId':vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('obj_id'),'title':vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('row_name'),'category':vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('type'),'pre_title':vekSHJwXmRtWDzKarfosnIlBNgMbpA,}
     vekSHJwXmRtWDzKarfosnIlBNgMbqA.append(vekSHJwXmRtWDzKarfosnIlBNgMbpQ)
  except vekSHJwXmRtWDzKarfosnIlBNgMbOT as exception:
   vekSHJwXmRtWDzKarfosnIlBNgMbLd(exception)
   return[]
  return vekSHJwXmRtWDzKarfosnIlBNgMbqA
 def Get_Event_GameList(vekSHJwXmRtWDzKarfosnIlBNgMbTp,vekSHJwXmRtWDzKarfosnIlBNgMbpO):
  vekSHJwXmRtWDzKarfosnIlBNgMbqA=[] 
  try:
   vekSHJwXmRtWDzKarfosnIlBNgMbqi=vekSHJwXmRtWDzKarfosnIlBNgMbTp.API_VIEWURL+'/v2/discover/feed' 
   vekSHJwXmRtWDzKarfosnIlBNgMbqy={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false',}
   vekSHJwXmRtWDzKarfosnIlBNgMbqh=vekSHJwXmRtWDzKarfosnIlBNgMbTp.callRequestCookies('Get',vekSHJwXmRtWDzKarfosnIlBNgMbqi,payload=vekSHJwXmRtWDzKarfosnIlBNgMbLV,params=vekSHJwXmRtWDzKarfosnIlBNgMbqy,headers=vekSHJwXmRtWDzKarfosnIlBNgMbLV,cookies=vekSHJwXmRtWDzKarfosnIlBNgMbLV,redirects=vekSHJwXmRtWDzKarfosnIlBNgMbOL)
   if vekSHJwXmRtWDzKarfosnIlBNgMbqh.status_code not in[200]:return[]
   vekSHJwXmRtWDzKarfosnIlBNgMbqG=json.loads(vekSHJwXmRtWDzKarfosnIlBNgMbqh.text)
   for vekSHJwXmRtWDzKarfosnIlBNgMbpL in vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('data'):
    if vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('obj_id')==vekSHJwXmRtWDzKarfosnIlBNgMbpO:
     for vekSHJwXmRtWDzKarfosnIlBNgMbLT in vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('data'):
      vekSHJwXmRtWDzKarfosnIlBNgMbpi=vekSHJwXmRtWDzKarfosnIlBNgMbpu=vekSHJwXmRtWDzKarfosnIlBNgMbLx=''
      if 'poster' in vekSHJwXmRtWDzKarfosnIlBNgMbLT.get('images'):vekSHJwXmRtWDzKarfosnIlBNgMbpi =vekSHJwXmRtWDzKarfosnIlBNgMbLT.get('images').get('poster').get('url') +'?imwidth=350'
      if 'story-art' in vekSHJwXmRtWDzKarfosnIlBNgMbLT.get('images'):vekSHJwXmRtWDzKarfosnIlBNgMbpu =vekSHJwXmRtWDzKarfosnIlBNgMbLT.get('images').get('story-art').get('url')+'?imwidth=600'
      if 'hero' in vekSHJwXmRtWDzKarfosnIlBNgMbLT.get('images'):vekSHJwXmRtWDzKarfosnIlBNgMbLx =vekSHJwXmRtWDzKarfosnIlBNgMbLT.get('images').get('hero').get('url') +'?imwidth=600'
      vekSHJwXmRtWDzKarfosnIlBNgMbLq=vekSHJwXmRtWDzKarfosnIlBNgMbLT.get('meta').get(vekSHJwXmRtWDzKarfosnIlBNgMbLT.get('category')).get(vekSHJwXmRtWDzKarfosnIlBNgMbLT.get('sub_category'))
      if 'league' in vekSHJwXmRtWDzKarfosnIlBNgMbLq:
       vekSHJwXmRtWDzKarfosnIlBNgMbLp=vekSHJwXmRtWDzKarfosnIlBNgMbLq.get('league')
      else:
       vekSHJwXmRtWDzKarfosnIlBNgMbLp=vekSHJwXmRtWDzKarfosnIlBNgMbLq.get('round')
      vekSHJwXmRtWDzKarfosnIlBNgMbpQ={'id':vekSHJwXmRtWDzKarfosnIlBNgMbLT.get('id'),'title':vekSHJwXmRtWDzKarfosnIlBNgMbLT.get('title'),'thumbnail':{'poster':vekSHJwXmRtWDzKarfosnIlBNgMbpi,'thumb':vekSHJwXmRtWDzKarfosnIlBNgMbpu,'fanart':vekSHJwXmRtWDzKarfosnIlBNgMbLx},'asis':vekSHJwXmRtWDzKarfosnIlBNgMbLT.get('type'),'addInfo':vekSHJwXmRtWDzKarfosnIlBNgMbLp,'starttm':vekSHJwXmRtWDzKarfosnIlBNgMbTp.convert_TimeStr(vekSHJwXmRtWDzKarfosnIlBNgMbLT.get('start_at')),}
      vekSHJwXmRtWDzKarfosnIlBNgMbqA.append(vekSHJwXmRtWDzKarfosnIlBNgMbpQ)
  except vekSHJwXmRtWDzKarfosnIlBNgMbOT as exception:
   vekSHJwXmRtWDzKarfosnIlBNgMbLd(exception)
   return[]
  return vekSHJwXmRtWDzKarfosnIlBNgMbqA
 def Get_Event_List(vekSHJwXmRtWDzKarfosnIlBNgMbTp,gameId):
  vekSHJwXmRtWDzKarfosnIlBNgMbqA=[] 
  try:
   vekSHJwXmRtWDzKarfosnIlBNgMbqi=vekSHJwXmRtWDzKarfosnIlBNgMbTp.API_VIEWURL+'/v1/discover/events/'+gameId 
   vekSHJwXmRtWDzKarfosnIlBNgMbqy={'platform':'WEBCLIENT','locale':'ko','filterRestrictedContent':'false',}
   vekSHJwXmRtWDzKarfosnIlBNgMbqh=vekSHJwXmRtWDzKarfosnIlBNgMbTp.callRequestCookies('Get',vekSHJwXmRtWDzKarfosnIlBNgMbqi,payload=vekSHJwXmRtWDzKarfosnIlBNgMbLV,params=vekSHJwXmRtWDzKarfosnIlBNgMbqy,headers=vekSHJwXmRtWDzKarfosnIlBNgMbLV,cookies=vekSHJwXmRtWDzKarfosnIlBNgMbLV,redirects=vekSHJwXmRtWDzKarfosnIlBNgMbOL)
   if vekSHJwXmRtWDzKarfosnIlBNgMbqh.status_code not in[200]:return[]
   vekSHJwXmRtWDzKarfosnIlBNgMbqG=json.loads(vekSHJwXmRtWDzKarfosnIlBNgMbqh.text)
   vekSHJwXmRtWDzKarfosnIlBNgMbpL=vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('data')
   vekSHJwXmRtWDzKarfosnIlBNgMbLO=vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('end_at')
   vekSHJwXmRtWDzKarfosnIlBNgMbLO=vekSHJwXmRtWDzKarfosnIlBNgMbLO[0:19].replace('-','').replace(':','').replace('T','')
   vekSHJwXmRtWDzKarfosnIlBNgMbLQ=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d%H%M%S')
   if vekSHJwXmRtWDzKarfosnIlBNgMbLy(vekSHJwXmRtWDzKarfosnIlBNgMbLQ)<vekSHJwXmRtWDzKarfosnIlBNgMbLy(vekSHJwXmRtWDzKarfosnIlBNgMbLO):
    vekSHJwXmRtWDzKarfosnIlBNgMbpi=vekSHJwXmRtWDzKarfosnIlBNgMbpu=vekSHJwXmRtWDzKarfosnIlBNgMbLx=''
    if 'poster' in vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('images'):vekSHJwXmRtWDzKarfosnIlBNgMbpi =vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('images'):vekSHJwXmRtWDzKarfosnIlBNgMbpu =vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('images').get('story-art').get('url')+'?imwidth=600'
    if 'story-art' in vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('images'):vekSHJwXmRtWDzKarfosnIlBNgMbLx =vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('images').get('story-art').get('url')+'?imwidth=600'
    vekSHJwXmRtWDzKarfosnIlBNgMbpQ={'id':vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('id'),'title':vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('title'),'thumbnail':{'poster':vekSHJwXmRtWDzKarfosnIlBNgMbpi,'thumb':vekSHJwXmRtWDzKarfosnIlBNgMbpu,'fanart':vekSHJwXmRtWDzKarfosnIlBNgMbLx},'duration':vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('running_time'),'asis':vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('type'),'starttm':vekSHJwXmRtWDzKarfosnIlBNgMbTp.convert_TimeStr(vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('start_at')),}
    vekSHJwXmRtWDzKarfosnIlBNgMbqA.append(vekSHJwXmRtWDzKarfosnIlBNgMbpQ)
  except vekSHJwXmRtWDzKarfosnIlBNgMbOT as exception:
   vekSHJwXmRtWDzKarfosnIlBNgMbLd(exception)
   return[]
  try:
   vekSHJwXmRtWDzKarfosnIlBNgMbqi=vekSHJwXmRtWDzKarfosnIlBNgMbTp.API_VIEWURL+'/v1/discover/events/'+gameId+'/related' 
   vekSHJwXmRtWDzKarfosnIlBNgMbqy={'locale':'ko','page':'1','perPage':'25','platform':'WEBCLIENT','currentPageTracking':'page_discover_title_detail',}
   vekSHJwXmRtWDzKarfosnIlBNgMbqh=vekSHJwXmRtWDzKarfosnIlBNgMbTp.callRequestCookies('Get',vekSHJwXmRtWDzKarfosnIlBNgMbqi,payload=vekSHJwXmRtWDzKarfosnIlBNgMbLV,params=vekSHJwXmRtWDzKarfosnIlBNgMbqy,headers=vekSHJwXmRtWDzKarfosnIlBNgMbLV,cookies=vekSHJwXmRtWDzKarfosnIlBNgMbLV,redirects=vekSHJwXmRtWDzKarfosnIlBNgMbOL)
   if vekSHJwXmRtWDzKarfosnIlBNgMbqh.status_code not in[200]:return[]
   vekSHJwXmRtWDzKarfosnIlBNgMbqG=json.loads(vekSHJwXmRtWDzKarfosnIlBNgMbqh.text)
   for vekSHJwXmRtWDzKarfosnIlBNgMbpL in vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('data').get('data'):
    vekSHJwXmRtWDzKarfosnIlBNgMbpi=vekSHJwXmRtWDzKarfosnIlBNgMbpu=vekSHJwXmRtWDzKarfosnIlBNgMbLx=''
    if 'poster' in vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('images'):vekSHJwXmRtWDzKarfosnIlBNgMbpi =vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('images'):vekSHJwXmRtWDzKarfosnIlBNgMbpu =vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('images').get('story-art').get('url')+'?imwidth=600'
    if 'story-art' in vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('images'):vekSHJwXmRtWDzKarfosnIlBNgMbLx =vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('images').get('story-art').get('url')+'?imwidth=600'
    vekSHJwXmRtWDzKarfosnIlBNgMbpQ={'id':vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('id'),'title':vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('title'),'thumbnail':{'poster':vekSHJwXmRtWDzKarfosnIlBNgMbpi,'thumb':vekSHJwXmRtWDzKarfosnIlBNgMbpu,'fanart':vekSHJwXmRtWDzKarfosnIlBNgMbLx},'duration':vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('running_time'),'asis':vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('type'),}
    vekSHJwXmRtWDzKarfosnIlBNgMbqA.append(vekSHJwXmRtWDzKarfosnIlBNgMbpQ)
  except vekSHJwXmRtWDzKarfosnIlBNgMbOT as exception:
   vekSHJwXmRtWDzKarfosnIlBNgMbLd(exception)
   return[]
  return vekSHJwXmRtWDzKarfosnIlBNgMbqA
 def Get_Search_List(vekSHJwXmRtWDzKarfosnIlBNgMbTp,search_key,page_int):
  vekSHJwXmRtWDzKarfosnIlBNgMbqA=[] 
  vekSHJwXmRtWDzKarfosnIlBNgMbpP=vekSHJwXmRtWDzKarfosnIlBNgMbLF
  try:
   vekSHJwXmRtWDzKarfosnIlBNgMbqi=vekSHJwXmRtWDzKarfosnIlBNgMbTp.API_VIEWURL+'/v2/search' 
   vekSHJwXmRtWDzKarfosnIlBNgMbqy={'query':search_key,'platform':'WEBCLIENT','page':vekSHJwXmRtWDzKarfosnIlBNgMbLC(page_int),'perPage':vekSHJwXmRtWDzKarfosnIlBNgMbLC(vekSHJwXmRtWDzKarfosnIlBNgMbTp.SEARCH_LIMIT),}
   vekSHJwXmRtWDzKarfosnIlBNgMbTy={'x-membersrl':vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['COOKIES']['member_srl'],'x-pcid':vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['COOKIES']['PCID'],'x-profileid':vekSHJwXmRtWDzKarfosnIlBNgMbTp.CP['SESSION']['profileId'],}
   vekSHJwXmRtWDzKarfosnIlBNgMbqh=vekSHJwXmRtWDzKarfosnIlBNgMbTp.callRequestCookies('Get',vekSHJwXmRtWDzKarfosnIlBNgMbqi,payload=vekSHJwXmRtWDzKarfosnIlBNgMbLV,params=vekSHJwXmRtWDzKarfosnIlBNgMbqy,headers=vekSHJwXmRtWDzKarfosnIlBNgMbTy,cookies=vekSHJwXmRtWDzKarfosnIlBNgMbLV,redirects=vekSHJwXmRtWDzKarfosnIlBNgMbOL)
   if vekSHJwXmRtWDzKarfosnIlBNgMbqh.status_code not in[200]:return[],vekSHJwXmRtWDzKarfosnIlBNgMbLF
   vekSHJwXmRtWDzKarfosnIlBNgMbqG=json.loads(vekSHJwXmRtWDzKarfosnIlBNgMbqh.text)
   for vekSHJwXmRtWDzKarfosnIlBNgMbpL in vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('data').get('data'):
    vekSHJwXmRtWDzKarfosnIlBNgMbpL=vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('data')
    vekSHJwXmRtWDzKarfosnIlBNgMbpi=vekSHJwXmRtWDzKarfosnIlBNgMbpu=vekSHJwXmRtWDzKarfosnIlBNgMbLU=vekSHJwXmRtWDzKarfosnIlBNgMbLx=''
    if 'poster' in vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('images'):vekSHJwXmRtWDzKarfosnIlBNgMbpi =vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('images'):vekSHJwXmRtWDzKarfosnIlBNgMbpu =vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('images').get('story-art').get('url') +'?imwidth=600'
    if 'title-treatment' in vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('images'):vekSHJwXmRtWDzKarfosnIlBNgMbLU=vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('images').get('title-treatment').get('url')+'?imwidth=300'
    if 'story-art' in vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('images'):vekSHJwXmRtWDzKarfosnIlBNgMbLx =vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('images').get('story-art').get('url') +'?imwidth=600'
    vekSHJwXmRtWDzKarfosnIlBNgMbpY=''
    if vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('badge')not in[{},vekSHJwXmRtWDzKarfosnIlBNgMbLV]:
     for i in vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('badge').get('text'):
      if vekSHJwXmRtWDzKarfosnIlBNgMbpY!='':vekSHJwXmRtWDzKarfosnIlBNgMbpY+=' '
      vekSHJwXmRtWDzKarfosnIlBNgMbpY+=i.get('text')
    if 'as' in vekSHJwXmRtWDzKarfosnIlBNgMbpL:
     vekSHJwXmRtWDzKarfosnIlBNgMbLP=vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('as') 
    else:
     vekSHJwXmRtWDzKarfosnIlBNgMbLP=vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('type')
    vekSHJwXmRtWDzKarfosnIlBNgMbpQ={'id':vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('id'),'title':vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('title'),'asis':vekSHJwXmRtWDzKarfosnIlBNgMbLP,'thumbnail':{'poster':vekSHJwXmRtWDzKarfosnIlBNgMbpi,'thumb':vekSHJwXmRtWDzKarfosnIlBNgMbpu,'clearlogo':vekSHJwXmRtWDzKarfosnIlBNgMbLU,'fanart':vekSHJwXmRtWDzKarfosnIlBNgMbLx},'mpaa':vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('age_rating'),'duration':vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('running_time'),'badge':vekSHJwXmRtWDzKarfosnIlBNgMbpY,'year':vekSHJwXmRtWDzKarfosnIlBNgMbpL.get('meta').get('releaseYear'),}
    vekSHJwXmRtWDzKarfosnIlBNgMbqA.append(vekSHJwXmRtWDzKarfosnIlBNgMbpQ)
   if vekSHJwXmRtWDzKarfosnIlBNgMbqG.get('pagination').get('totalPages')>page_int:
    vekSHJwXmRtWDzKarfosnIlBNgMbpP=vekSHJwXmRtWDzKarfosnIlBNgMbOL
  except vekSHJwXmRtWDzKarfosnIlBNgMbOT as exception:
   vekSHJwXmRtWDzKarfosnIlBNgMbLd(exception)
   return[],vekSHJwXmRtWDzKarfosnIlBNgMbLF
  return vekSHJwXmRtWDzKarfosnIlBNgMbqA,vekSHJwXmRtWDzKarfosnIlBNgMbpP
 def GetBookmarkInfo(vekSHJwXmRtWDzKarfosnIlBNgMbTp,videoid,vidtype):
  vekSHJwXmRtWDzKarfosnIlBNgMbLE={'indexinfo':{'ott':'coupang','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  vekSHJwXmRtWDzKarfosnIlBNgMbqi=vekSHJwXmRtWDzKarfosnIlBNgMbTp.API_VIEWURL+'/v1/discover/titles/'+videoid 
  vekSHJwXmRtWDzKarfosnIlBNgMbqy={'locale':'ko'}
  vekSHJwXmRtWDzKarfosnIlBNgMbqh=vekSHJwXmRtWDzKarfosnIlBNgMbTp.callRequestCookies('Get',vekSHJwXmRtWDzKarfosnIlBNgMbqi,payload=vekSHJwXmRtWDzKarfosnIlBNgMbLV,params=vekSHJwXmRtWDzKarfosnIlBNgMbqy,headers=vekSHJwXmRtWDzKarfosnIlBNgMbLV,cookies=vekSHJwXmRtWDzKarfosnIlBNgMbLV,redirects=vekSHJwXmRtWDzKarfosnIlBNgMbOL)
  if vekSHJwXmRtWDzKarfosnIlBNgMbqh.status_code not in[200]:return{}
  vekSHJwXmRtWDzKarfosnIlBNgMbLi=json.loads(vekSHJwXmRtWDzKarfosnIlBNgMbqh.text).get('data')
  vekSHJwXmRtWDzKarfosnIlBNgMbLY=vekSHJwXmRtWDzKarfosnIlBNgMbLi.get('title')
  vekSHJwXmRtWDzKarfosnIlBNgMbLh =vekSHJwXmRtWDzKarfosnIlBNgMbLi.get('meta').get('releaseYear')
  vekSHJwXmRtWDzKarfosnIlBNgMbLE['saveinfo']['infoLabels']['title']=vekSHJwXmRtWDzKarfosnIlBNgMbLY
  if vidtype=='movie':
   vekSHJwXmRtWDzKarfosnIlBNgMbLY='%s  (%s)'%(vekSHJwXmRtWDzKarfosnIlBNgMbLY,vekSHJwXmRtWDzKarfosnIlBNgMbLh)
  vekSHJwXmRtWDzKarfosnIlBNgMbLE['saveinfo']['title'] =vekSHJwXmRtWDzKarfosnIlBNgMbLY
  vekSHJwXmRtWDzKarfosnIlBNgMbLE['saveinfo']['infoLabels']['mpaa'] =vekSHJwXmRtWDzKarfosnIlBNgMbLi.get('age_rating')
  vekSHJwXmRtWDzKarfosnIlBNgMbLE['saveinfo']['infoLabels']['plot'] ='%s\n\n%s'%(vekSHJwXmRtWDzKarfosnIlBNgMbLi.get('short_description'),vekSHJwXmRtWDzKarfosnIlBNgMbLi.get('description'))
  vekSHJwXmRtWDzKarfosnIlBNgMbLE['saveinfo']['infoLabels']['year'] =vekSHJwXmRtWDzKarfosnIlBNgMbLh
  if vidtype=='movie':
   vekSHJwXmRtWDzKarfosnIlBNgMbLE['saveinfo']['infoLabels']['duration']=vekSHJwXmRtWDzKarfosnIlBNgMbLi.get('running_time')
  vekSHJwXmRtWDzKarfosnIlBNgMbpi =''
  vekSHJwXmRtWDzKarfosnIlBNgMbLx =''
  vekSHJwXmRtWDzKarfosnIlBNgMbpu =''
  vekSHJwXmRtWDzKarfosnIlBNgMbLU=''
  if vekSHJwXmRtWDzKarfosnIlBNgMbLi.get('images').get('poster') !=vekSHJwXmRtWDzKarfosnIlBNgMbLV:vekSHJwXmRtWDzKarfosnIlBNgMbpi =vekSHJwXmRtWDzKarfosnIlBNgMbLi.get('images').get('poster').get('url') +'?imwidth=350'
  if vekSHJwXmRtWDzKarfosnIlBNgMbLi.get('images').get('background') !=vekSHJwXmRtWDzKarfosnIlBNgMbLV:vekSHJwXmRtWDzKarfosnIlBNgMbLx =vekSHJwXmRtWDzKarfosnIlBNgMbLi.get('images').get('background').get('url') +'?imwidth=600'
  if vekSHJwXmRtWDzKarfosnIlBNgMbLi.get('images').get('story-art') !=vekSHJwXmRtWDzKarfosnIlBNgMbLV:vekSHJwXmRtWDzKarfosnIlBNgMbpu =vekSHJwXmRtWDzKarfosnIlBNgMbLi.get('images').get('story-art').get('url') +'?imwidth=600'
  if vekSHJwXmRtWDzKarfosnIlBNgMbLi.get('images').get('title-treatment')!=vekSHJwXmRtWDzKarfosnIlBNgMbLV:vekSHJwXmRtWDzKarfosnIlBNgMbLU=vekSHJwXmRtWDzKarfosnIlBNgMbLi.get('images').get('title-treatment').get('url')+'?imwidth=300'
  if vekSHJwXmRtWDzKarfosnIlBNgMbLx=='':vekSHJwXmRtWDzKarfosnIlBNgMbLx=vekSHJwXmRtWDzKarfosnIlBNgMbpu
  vekSHJwXmRtWDzKarfosnIlBNgMbLE['saveinfo']['thumbnail']['poster']=vekSHJwXmRtWDzKarfosnIlBNgMbpi
  vekSHJwXmRtWDzKarfosnIlBNgMbLE['saveinfo']['thumbnail']['fanart']=vekSHJwXmRtWDzKarfosnIlBNgMbLx
  vekSHJwXmRtWDzKarfosnIlBNgMbLE['saveinfo']['thumbnail']['thumb']=vekSHJwXmRtWDzKarfosnIlBNgMbpu
  vekSHJwXmRtWDzKarfosnIlBNgMbLE['saveinfo']['thumbnail']['clearlogo']=vekSHJwXmRtWDzKarfosnIlBNgMbLU
  vekSHJwXmRtWDzKarfosnIlBNgMbLu=[]
  for vekSHJwXmRtWDzKarfosnIlBNgMbpU in vekSHJwXmRtWDzKarfosnIlBNgMbLi.get('tags'):vekSHJwXmRtWDzKarfosnIlBNgMbLu.append(vekSHJwXmRtWDzKarfosnIlBNgMbpU.get('tag'))
  if vekSHJwXmRtWDzKarfosnIlBNgMbOq(vekSHJwXmRtWDzKarfosnIlBNgMbLu)>0:
   vekSHJwXmRtWDzKarfosnIlBNgMbLE['saveinfo']['infoLabels']['genre']=vekSHJwXmRtWDzKarfosnIlBNgMbLu
  vekSHJwXmRtWDzKarfosnIlBNgMbLc=[]
  vekSHJwXmRtWDzKarfosnIlBNgMbLj=[]
  for vekSHJwXmRtWDzKarfosnIlBNgMbpU in vekSHJwXmRtWDzKarfosnIlBNgMbLi.get('people'):
   if vekSHJwXmRtWDzKarfosnIlBNgMbpU.get('role')=='CAST' :vekSHJwXmRtWDzKarfosnIlBNgMbLc.append(vekSHJwXmRtWDzKarfosnIlBNgMbpU.get('name'))
   if vekSHJwXmRtWDzKarfosnIlBNgMbpU.get('role')=='DIRECTOR':vekSHJwXmRtWDzKarfosnIlBNgMbLj.append(vekSHJwXmRtWDzKarfosnIlBNgMbpU.get('name'))
  if vekSHJwXmRtWDzKarfosnIlBNgMbOq(vekSHJwXmRtWDzKarfosnIlBNgMbLc)>0:
   vekSHJwXmRtWDzKarfosnIlBNgMbLE['saveinfo']['infoLabels']['cast'] =vekSHJwXmRtWDzKarfosnIlBNgMbLc
  if vekSHJwXmRtWDzKarfosnIlBNgMbOq(vekSHJwXmRtWDzKarfosnIlBNgMbLj)>0:
   vekSHJwXmRtWDzKarfosnIlBNgMbLE['saveinfo']['infoLabels']['director']=vekSHJwXmRtWDzKarfosnIlBNgMbLj
  return vekSHJwXmRtWDzKarfosnIlBNgMbLE
# Created by pyminifier (https://github.com/liftoff/pyminifier)
