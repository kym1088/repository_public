__author__="NightRain"
JswzYMyjBLHqKiUmGDuvfWgpThdCOS=object
JswzYMyjBLHqKiUmGDuvfWgpThdCOP=None
JswzYMyjBLHqKiUmGDuvfWgpThdCOE=False
JswzYMyjBLHqKiUmGDuvfWgpThdCOa=print
JswzYMyjBLHqKiUmGDuvfWgpThdCOV=str
JswzYMyjBLHqKiUmGDuvfWgpThdCOX=open
JswzYMyjBLHqKiUmGDuvfWgpThdCOc=int
JswzYMyjBLHqKiUmGDuvfWgpThdCOo=Exception
JswzYMyjBLHqKiUmGDuvfWgpThdCOr=id
JswzYMyjBLHqKiUmGDuvfWgpThdCOF=True
JswzYMyjBLHqKiUmGDuvfWgpThdCON=len
JswzYMyjBLHqKiUmGDuvfWgpThdCOR=range
import urllib
import re
import json
import requests
import datetime
import time
import random
import base64
class JswzYMyjBLHqKiUmGDuvfWgpThdCQn(JswzYMyjBLHqKiUmGDuvfWgpThdCOS):
 def __init__(JswzYMyjBLHqKiUmGDuvfWgpThdCQk):
  JswzYMyjBLHqKiUmGDuvfWgpThdCQk.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.1901.183' 
  JswzYMyjBLHqKiUmGDuvfWgpThdCQk.MODEL ='Edge_115' 
  JswzYMyjBLHqKiUmGDuvfWgpThdCQk.OS_VERSION ='115' 
  JswzYMyjBLHqKiUmGDuvfWgpThdCQk.DEFAULT_HEADER ={'user-agent':JswzYMyjBLHqKiUmGDuvfWgpThdCQk.USER_AGENT}
  JswzYMyjBLHqKiUmGDuvfWgpThdCQk.API_DOMAIN ='https://www.coupangplay.com'
  JswzYMyjBLHqKiUmGDuvfWgpThdCQk.API_VIEWURL ='https://discover.coupangstreaming.com'
  JswzYMyjBLHqKiUmGDuvfWgpThdCQk.PAGE_LIMIT =40
  JswzYMyjBLHqKiUmGDuvfWgpThdCQk.SEARCH_LIMIT =20
  JswzYMyjBLHqKiUmGDuvfWgpThdCQk.KodiVersion =20
  JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP={}
  JswzYMyjBLHqKiUmGDuvfWgpThdCQk.Init_CP()
  JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP_DEVICE_FILENAME=''
  JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP_COOKIE_FILENAME=''
 def callRequestCookies(JswzYMyjBLHqKiUmGDuvfWgpThdCQk,jobtype,JswzYMyjBLHqKiUmGDuvfWgpThdCnO,payload=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,params=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,headers=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,cookies=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,redirects=JswzYMyjBLHqKiUmGDuvfWgpThdCOE):
  JswzYMyjBLHqKiUmGDuvfWgpThdCQO=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.DEFAULT_HEADER
  if headers:JswzYMyjBLHqKiUmGDuvfWgpThdCQO.update(headers)
  if jobtype=='Get':
   JswzYMyjBLHqKiUmGDuvfWgpThdCQx=requests.get(JswzYMyjBLHqKiUmGDuvfWgpThdCnO,params=params,headers=JswzYMyjBLHqKiUmGDuvfWgpThdCQO,cookies=cookies,allow_redirects=redirects)
  else:
   JswzYMyjBLHqKiUmGDuvfWgpThdCQx=requests.post(JswzYMyjBLHqKiUmGDuvfWgpThdCnO,data=payload,params=params,headers=JswzYMyjBLHqKiUmGDuvfWgpThdCQO,cookies=cookies,allow_redirects=redirects)
  JswzYMyjBLHqKiUmGDuvfWgpThdCOa(JswzYMyjBLHqKiUmGDuvfWgpThdCOV(JswzYMyjBLHqKiUmGDuvfWgpThdCQx.status_code)+' - '+JswzYMyjBLHqKiUmGDuvfWgpThdCOV(JswzYMyjBLHqKiUmGDuvfWgpThdCQx.url))
  return JswzYMyjBLHqKiUmGDuvfWgpThdCQx
 def callRequestCookies_test(JswzYMyjBLHqKiUmGDuvfWgpThdCQk,jobtype,JswzYMyjBLHqKiUmGDuvfWgpThdCnO,payload=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,params=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,headers=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,cookies=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,redirects=JswzYMyjBLHqKiUmGDuvfWgpThdCOE):
  JswzYMyjBLHqKiUmGDuvfWgpThdCQO=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.DEFAULT_HEADER
  if headers:JswzYMyjBLHqKiUmGDuvfWgpThdCQO.update(headers)
  JswzYMyjBLHqKiUmGDuvfWgpThdCQx=requests.Request('POST',JswzYMyjBLHqKiUmGDuvfWgpThdCnO,headers=headers,data=payload,params=params,cookies=cookies)
  JswzYMyjBLHqKiUmGDuvfWgpThdCQe=JswzYMyjBLHqKiUmGDuvfWgpThdCQx.prepare()
  JswzYMyjBLHqKiUmGDuvfWgpThdCQk.pretty_print_POST(JswzYMyjBLHqKiUmGDuvfWgpThdCQe)
  return JswzYMyjBLHqKiUmGDuvfWgpThdCQx
 def pretty_print_POST(JswzYMyjBLHqKiUmGDuvfWgpThdCQk,req):
  JswzYMyjBLHqKiUmGDuvfWgpThdCOa('{}\n{}\r\n{}\r\n\r\n{}'.format('-----------START-----------',req.method+' '+req.url,'\r\n'.join('{}: {}'.format(k,v)for k,v in req.headers.items()),req.body,))
 def dic_To_jsonfile(JswzYMyjBLHqKiUmGDuvfWgpThdCQk,filename,JswzYMyjBLHqKiUmGDuvfWgpThdCQl):
  if filename=='':return
  fp=JswzYMyjBLHqKiUmGDuvfWgpThdCOX(filename,'w',-1,'utf-8')
  json.dump(JswzYMyjBLHqKiUmGDuvfWgpThdCQl,fp,indent=4,ensure_ascii=JswzYMyjBLHqKiUmGDuvfWgpThdCOE)
  fp.close()
 def jsonfile_To_dic(JswzYMyjBLHqKiUmGDuvfWgpThdCQk,filename):
  if filename=='':return JswzYMyjBLHqKiUmGDuvfWgpThdCOP
  try:
   fp=JswzYMyjBLHqKiUmGDuvfWgpThdCOX(filename,'r',-1,'utf-8')
   JswzYMyjBLHqKiUmGDuvfWgpThdCQA=json.load(fp)
   fp.close()
  except:
   JswzYMyjBLHqKiUmGDuvfWgpThdCQA={}
  return JswzYMyjBLHqKiUmGDuvfWgpThdCQA
 def convert_TimeStr(JswzYMyjBLHqKiUmGDuvfWgpThdCQk,JswzYMyjBLHqKiUmGDuvfWgpThdCQI):
  try:
   JswzYMyjBLHqKiUmGDuvfWgpThdCQI =JswzYMyjBLHqKiUmGDuvfWgpThdCQI[0:16]
   JswzYMyjBLHqKiUmGDuvfWgpThdCQb=datetime.datetime.strptime(JswzYMyjBLHqKiUmGDuvfWgpThdCQI,'%Y-%m-%dT%H:%M')+datetime.timedelta(hours=9)
   return JswzYMyjBLHqKiUmGDuvfWgpThdCQb.strftime('%Y-%m-%d %H:%M')
  except:
   return JswzYMyjBLHqKiUmGDuvfWgpThdCOP
 def Get_Now_Datetime(JswzYMyjBLHqKiUmGDuvfWgpThdCQk):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetNoCache(JswzYMyjBLHqKiUmGDuvfWgpThdCQk):
  JswzYMyjBLHqKiUmGDuvfWgpThdCQP =JswzYMyjBLHqKiUmGDuvfWgpThdCOc(time.time()*1000)
  return JswzYMyjBLHqKiUmGDuvfWgpThdCQP
 def generatePcId(JswzYMyjBLHqKiUmGDuvfWgpThdCQk):
  t=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.GetNoCache()
  r=random.random()
  JswzYMyjBLHqKiUmGDuvfWgpThdCQE=JswzYMyjBLHqKiUmGDuvfWgpThdCOV(t)+JswzYMyjBLHqKiUmGDuvfWgpThdCOV(r)[2:12]
  return JswzYMyjBLHqKiUmGDuvfWgpThdCQE
 def generatePvId(JswzYMyjBLHqKiUmGDuvfWgpThdCQk,genType='1'):
  import hashlib
  m=hashlib.md5()
  JswzYMyjBLHqKiUmGDuvfWgpThdCQa=JswzYMyjBLHqKiUmGDuvfWgpThdCOV(random.random())
  m.update(JswzYMyjBLHqKiUmGDuvfWgpThdCQa.encode('utf-8'))
  JswzYMyjBLHqKiUmGDuvfWgpThdCQV=JswzYMyjBLHqKiUmGDuvfWgpThdCOV(m.hexdigest())
  if genType=='1':
   return '%s-%s-%s-%s-%s'%(JswzYMyjBLHqKiUmGDuvfWgpThdCQV[:8],JswzYMyjBLHqKiUmGDuvfWgpThdCQV[8:12],JswzYMyjBLHqKiUmGDuvfWgpThdCQV[12:16],JswzYMyjBLHqKiUmGDuvfWgpThdCQV[16:20],JswzYMyjBLHqKiUmGDuvfWgpThdCQV[20:])
  else:
   return JswzYMyjBLHqKiUmGDuvfWgpThdCQV
 def Get_DeviceID(JswzYMyjBLHqKiUmGDuvfWgpThdCQk):
  JswzYMyjBLHqKiUmGDuvfWgpThdCQX=''
  try: 
   fp=JswzYMyjBLHqKiUmGDuvfWgpThdCOX(JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP_DEVICE_FILENAME,'r',-1,'utf-8')
   JswzYMyjBLHqKiUmGDuvfWgpThdCQc= json.load(fp)
   fp.close()
   JswzYMyjBLHqKiUmGDuvfWgpThdCQX=JswzYMyjBLHqKiUmGDuvfWgpThdCQc.get('device_id')
  except JswzYMyjBLHqKiUmGDuvfWgpThdCOo as exception:
   JswzYMyjBLHqKiUmGDuvfWgpThdCOP
  if JswzYMyjBLHqKiUmGDuvfWgpThdCQX=='':
   JswzYMyjBLHqKiUmGDuvfWgpThdCQX=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.generatePvId(genType='1')
   try: 
    fp=JswzYMyjBLHqKiUmGDuvfWgpThdCOX(JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP_DEVICE_FILENAME,'w',-1,'utf-8')
    json.dump({'device_id':JswzYMyjBLHqKiUmGDuvfWgpThdCQX},fp,indent=4,ensure_ascii=JswzYMyjBLHqKiUmGDuvfWgpThdCOE)
    fp.close()
   except JswzYMyjBLHqKiUmGDuvfWgpThdCOo as exception:
    return ''
  return JswzYMyjBLHqKiUmGDuvfWgpThdCQX
 def Make_authHeader(JswzYMyjBLHqKiUmGDuvfWgpThdCQk):
  tr=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.generatePvId(genType=2)
  ti=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.GetNoCache()
  JswzYMyjBLHqKiUmGDuvfWgpThdCOr=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.generatePvId(genType=2)[:16]
  JswzYMyjBLHqKiUmGDuvfWgpThdCQo='00-%s-%s-01'%(tr,JswzYMyjBLHqKiUmGDuvfWgpThdCOr,)
  JswzYMyjBLHqKiUmGDuvfWgpThdCQr ='%s@nr=0-1-%s-%s-%s----%s'%(JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['NREUM']['tk'],JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['NREUM']['ac'],JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['NREUM']['ap'],JswzYMyjBLHqKiUmGDuvfWgpThdCOr,ti,)
  JswzYMyjBLHqKiUmGDuvfWgpThdCQF ='{"v":[0,1],"d":{"ty":"Browser","ac":"%s","ap":"%s","id":"%s","tr":"%s","ti":%s,"tk":"%s"}}'%(JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['NREUM']['ac'],JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['NREUM']['ap'],JswzYMyjBLHqKiUmGDuvfWgpThdCOr,tr,ti,JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['NREUM']['tk'],) 
  return JswzYMyjBLHqKiUmGDuvfWgpThdCQo,JswzYMyjBLHqKiUmGDuvfWgpThdCQr,base64.standard_b64encode(JswzYMyjBLHqKiUmGDuvfWgpThdCQF.encode()).decode('utf-8')
 def Init_CP(JswzYMyjBLHqKiUmGDuvfWgpThdCQk):
  JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP={}
  JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['ACCOUNT']={'cpid':'','cppw':'','cppf':'0'}
  JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']={}
 def Save_session_acount(JswzYMyjBLHqKiUmGDuvfWgpThdCQk,JswzYMyjBLHqKiUmGDuvfWgpThdCQN,JswzYMyjBLHqKiUmGDuvfWgpThdCQR,JswzYMyjBLHqKiUmGDuvfWgpThdCnQ):
  JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['ACCOUNT']['cpid']=base64.standard_b64encode(JswzYMyjBLHqKiUmGDuvfWgpThdCQN.encode()).decode('utf-8')
  JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['ACCOUNT']['cppw']=base64.standard_b64encode(JswzYMyjBLHqKiUmGDuvfWgpThdCQR.encode()).decode('utf-8')
  JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['ACCOUNT']['cppf']=JswzYMyjBLHqKiUmGDuvfWgpThdCOV(JswzYMyjBLHqKiUmGDuvfWgpThdCnQ)
 def Load_session_acount(JswzYMyjBLHqKiUmGDuvfWgpThdCQk):
  JswzYMyjBLHqKiUmGDuvfWgpThdCQN=base64.standard_b64decode(JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['ACCOUNT']['cpid']).decode('utf-8')
  JswzYMyjBLHqKiUmGDuvfWgpThdCQR=base64.standard_b64decode(JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['ACCOUNT']['cppw']).decode('utf-8')
  JswzYMyjBLHqKiUmGDuvfWgpThdCnQ=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['ACCOUNT']['cppf']
  return JswzYMyjBLHqKiUmGDuvfWgpThdCQN,JswzYMyjBLHqKiUmGDuvfWgpThdCQR,JswzYMyjBLHqKiUmGDuvfWgpThdCnQ
 def make_CP_DefaultCookies(JswzYMyjBLHqKiUmGDuvfWgpThdCQk):
  JswzYMyjBLHqKiUmGDuvfWgpThdCnk={}
  if 'NEXT_LOCALE' in JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']:JswzYMyjBLHqKiUmGDuvfWgpThdCnk['NEXT_LOCALE'] =JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['NEXT_LOCALE']
  if 'ak_bmsc' in JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']:JswzYMyjBLHqKiUmGDuvfWgpThdCnk['ak_bmsc'] =JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['ak_bmsc']
  if 'bm_mi' in JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']:JswzYMyjBLHqKiUmGDuvfWgpThdCnk['bm_mi'] =JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['bm_mi']
  if 'bm_sv' in JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']:JswzYMyjBLHqKiUmGDuvfWgpThdCnk['bm_sv'] =JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['bm_sv']
  if 'PCID' in JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']:JswzYMyjBLHqKiUmGDuvfWgpThdCnk['PCID'] =JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['PCID']
  if 'member_srl' in JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']:JswzYMyjBLHqKiUmGDuvfWgpThdCnk['member_srl'] =JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['member_srl']
  if 'token' in JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']:JswzYMyjBLHqKiUmGDuvfWgpThdCnk['token'] =JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['token']
  if 'session_web_id' in JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']:JswzYMyjBLHqKiUmGDuvfWgpThdCnk['session_web_id']=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['session_web_id']
  if 'device_id' in JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']:JswzYMyjBLHqKiUmGDuvfWgpThdCnk['device_id'] =JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['device_id']
  return JswzYMyjBLHqKiUmGDuvfWgpThdCnk
 def Get_CP_Login(JswzYMyjBLHqKiUmGDuvfWgpThdCQk,userid,userpw,JswzYMyjBLHqKiUmGDuvfWgpThdCnE):
  try:
   JswzYMyjBLHqKiUmGDuvfWgpThdCnO=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.API_DOMAIN
   JswzYMyjBLHqKiUmGDuvfWgpThdCnx=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.callRequestCookies('Get',JswzYMyjBLHqKiUmGDuvfWgpThdCnO,payload=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,params=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,headers=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,cookies=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,redirects=JswzYMyjBLHqKiUmGDuvfWgpThdCOE)
   if JswzYMyjBLHqKiUmGDuvfWgpThdCnx.status_code not in[301,302]:return JswzYMyjBLHqKiUmGDuvfWgpThdCOE
   for JswzYMyjBLHqKiUmGDuvfWgpThdCne in JswzYMyjBLHqKiUmGDuvfWgpThdCnx.cookies:
    JswzYMyjBLHqKiUmGDuvfWgpThdCOa(JswzYMyjBLHqKiUmGDuvfWgpThdCne.name,JswzYMyjBLHqKiUmGDuvfWgpThdCne.value) 
    if JswzYMyjBLHqKiUmGDuvfWgpThdCne.name=='NEXT_LOCALE':
     JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['NEXT_LOCALE']=JswzYMyjBLHqKiUmGDuvfWgpThdCne.value
    elif JswzYMyjBLHqKiUmGDuvfWgpThdCne.name=='ak_bmsc':
     JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['ak_bmsc']=JswzYMyjBLHqKiUmGDuvfWgpThdCne.value
   JswzYMyjBLHqKiUmGDuvfWgpThdCnk=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.make_CP_DefaultCookies()
   JswzYMyjBLHqKiUmGDuvfWgpThdCnx=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.callRequestCookies('Get',JswzYMyjBLHqKiUmGDuvfWgpThdCnO,payload=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,params=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,headers=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,cookies=JswzYMyjBLHqKiUmGDuvfWgpThdCnk,redirects=JswzYMyjBLHqKiUmGDuvfWgpThdCOE)
   if JswzYMyjBLHqKiUmGDuvfWgpThdCnx.status_code not in[200]:return JswzYMyjBLHqKiUmGDuvfWgpThdCOE
   JswzYMyjBLHqKiUmGDuvfWgpThdCnl=re.findall('NREUM.loader_config=\{[\w\d\":,-]+\}',JswzYMyjBLHqKiUmGDuvfWgpThdCnx.text)[0].split('=')[1]
   JswzYMyjBLHqKiUmGDuvfWgpThdCnl=JswzYMyjBLHqKiUmGDuvfWgpThdCnl.replace('{','{"').replace(':','":').replace(',',',"')
   JswzYMyjBLHqKiUmGDuvfWgpThdCnl=json.loads(JswzYMyjBLHqKiUmGDuvfWgpThdCnl)
   JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['NREUM']={'ac':JswzYMyjBLHqKiUmGDuvfWgpThdCnl['accountID'],'tk':JswzYMyjBLHqKiUmGDuvfWgpThdCnl['trustKey'],'ap':JswzYMyjBLHqKiUmGDuvfWgpThdCnl['agentID'],'lk':JswzYMyjBLHqKiUmGDuvfWgpThdCnl['licenseKey'],}
   JswzYMyjBLHqKiUmGDuvfWgpThdCOa('---')
   for JswzYMyjBLHqKiUmGDuvfWgpThdCne in JswzYMyjBLHqKiUmGDuvfWgpThdCnx.cookies:
    JswzYMyjBLHqKiUmGDuvfWgpThdCOa(JswzYMyjBLHqKiUmGDuvfWgpThdCne.name,JswzYMyjBLHqKiUmGDuvfWgpThdCne.value) 
    if JswzYMyjBLHqKiUmGDuvfWgpThdCne.name=='bm_mi':
     JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['bm_mi']=JswzYMyjBLHqKiUmGDuvfWgpThdCne.value
    elif JswzYMyjBLHqKiUmGDuvfWgpThdCne.name=='bm_sv':
     JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['bm_sv'] =JswzYMyjBLHqKiUmGDuvfWgpThdCne.value
     JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['bm_sv_ex']=JswzYMyjBLHqKiUmGDuvfWgpThdCne.expires 
    elif JswzYMyjBLHqKiUmGDuvfWgpThdCne.name=='session_web_id':
     JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['session_web_id']=JswzYMyjBLHqKiUmGDuvfWgpThdCne.value
  except JswzYMyjBLHqKiUmGDuvfWgpThdCOo as exception:
   JswzYMyjBLHqKiUmGDuvfWgpThdCOa(exception)
   return JswzYMyjBLHqKiUmGDuvfWgpThdCOE
  try:
   JswzYMyjBLHqKiUmGDuvfWgpThdCnO=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.API_DOMAIN+'/api/auth'
   JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['PCID']=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.generatePcId()
   JswzYMyjBLHqKiUmGDuvfWgpThdCnt=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.Get_DeviceID()
   JswzYMyjBLHqKiUmGDuvfWgpThdCnA =JswzYMyjBLHqKiUmGDuvfWgpThdCnt.split('-')[0]
   JswzYMyjBLHqKiUmGDuvfWgpThdCQo,JswzYMyjBLHqKiUmGDuvfWgpThdCQr,JswzYMyjBLHqKiUmGDuvfWgpThdCQF=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.Make_authHeader()
   JswzYMyjBLHqKiUmGDuvfWgpThdCnI={'traceparent':JswzYMyjBLHqKiUmGDuvfWgpThdCQo,'tracestate':JswzYMyjBLHqKiUmGDuvfWgpThdCQr,'newrelic':JswzYMyjBLHqKiUmGDuvfWgpThdCQF,'content-type':'application/json','x-app-version':'1.26.1','x-device-id':'','x-device-os-version':JswzYMyjBLHqKiUmGDuvfWgpThdCQk.OS_VERSION,'x-nr-session-id':JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['session_web_id'],'x-pcid':'',}
   JswzYMyjBLHqKiUmGDuvfWgpThdCnb={'device':{'deviceId':'web-'+JswzYMyjBLHqKiUmGDuvfWgpThdCnt,'model':JswzYMyjBLHqKiUmGDuvfWgpThdCQk.MODEL,'name':'Edge Desktop '+JswzYMyjBLHqKiUmGDuvfWgpThdCnA,'os':'Windows','osVersion':'10','type':'webclient',},'email':userid,'password':userpw,}
   JswzYMyjBLHqKiUmGDuvfWgpThdCnb=json.dumps(JswzYMyjBLHqKiUmGDuvfWgpThdCnb,separators=(',',':'))
   JswzYMyjBLHqKiUmGDuvfWgpThdCnk=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.make_CP_DefaultCookies()
   JswzYMyjBLHqKiUmGDuvfWgpThdCnx=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.callRequestCookies('Post',JswzYMyjBLHqKiUmGDuvfWgpThdCnO,payload=JswzYMyjBLHqKiUmGDuvfWgpThdCnb,params=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,headers=JswzYMyjBLHqKiUmGDuvfWgpThdCnI,cookies=JswzYMyjBLHqKiUmGDuvfWgpThdCnk,redirects=JswzYMyjBLHqKiUmGDuvfWgpThdCOE)
   if JswzYMyjBLHqKiUmGDuvfWgpThdCnx.status_code not in[200]:
    JswzYMyjBLHqKiUmGDuvfWgpThdCnS=json.loads(JswzYMyjBLHqKiUmGDuvfWgpThdCnx.text)
    if 'error' in JswzYMyjBLHqKiUmGDuvfWgpThdCnS:
     JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['error']=JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('error').get('detail')
    return JswzYMyjBLHqKiUmGDuvfWgpThdCOE
   JswzYMyjBLHqKiUmGDuvfWgpThdCOa('---')
   for JswzYMyjBLHqKiUmGDuvfWgpThdCne in JswzYMyjBLHqKiUmGDuvfWgpThdCnx.cookies:
    JswzYMyjBLHqKiUmGDuvfWgpThdCOa(JswzYMyjBLHqKiUmGDuvfWgpThdCne.name,JswzYMyjBLHqKiUmGDuvfWgpThdCne.value) 
    if JswzYMyjBLHqKiUmGDuvfWgpThdCne.name=='token':
     JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['token']=JswzYMyjBLHqKiUmGDuvfWgpThdCne.value
    elif JswzYMyjBLHqKiUmGDuvfWgpThdCne.name=='member_srl':
     JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['member_srl']=JswzYMyjBLHqKiUmGDuvfWgpThdCne.value
    elif JswzYMyjBLHqKiUmGDuvfWgpThdCne.name=='bm_sv':
     JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['bm_sv'] =JswzYMyjBLHqKiUmGDuvfWgpThdCne.value
     JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['bm_sv_ex']=JswzYMyjBLHqKiUmGDuvfWgpThdCne.expires 
    elif JswzYMyjBLHqKiUmGDuvfWgpThdCne.name=='device_id':
     JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['device_id']=JswzYMyjBLHqKiUmGDuvfWgpThdCne.value
  except JswzYMyjBLHqKiUmGDuvfWgpThdCOo as exception:
   JswzYMyjBLHqKiUmGDuvfWgpThdCOa(exception)
   return JswzYMyjBLHqKiUmGDuvfWgpThdCOE
  JswzYMyjBLHqKiUmGDuvfWgpThdCQk.Save_session_acount(userid,userpw,JswzYMyjBLHqKiUmGDuvfWgpThdCnE)
  return JswzYMyjBLHqKiUmGDuvfWgpThdCOF
 def Get_CP_profile(JswzYMyjBLHqKiUmGDuvfWgpThdCQk,JswzYMyjBLHqKiUmGDuvfWgpThdCnE,limit_days=1,re_check=JswzYMyjBLHqKiUmGDuvfWgpThdCOE):
  if re_check==JswzYMyjBLHqKiUmGDuvfWgpThdCOF:
   if JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['bm_sv_ex']>JswzYMyjBLHqKiUmGDuvfWgpThdCOc(time.time()):
    JswzYMyjBLHqKiUmGDuvfWgpThdCOa('bm_sv_ex ok')
    return JswzYMyjBLHqKiUmGDuvfWgpThdCOF
  try:
   JswzYMyjBLHqKiUmGDuvfWgpThdCnO=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.API_DOMAIN+'/api/profiles'
   JswzYMyjBLHqKiUmGDuvfWgpThdCQo,JswzYMyjBLHqKiUmGDuvfWgpThdCQr,JswzYMyjBLHqKiUmGDuvfWgpThdCQF=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.Make_authHeader()
   JswzYMyjBLHqKiUmGDuvfWgpThdCnI={'traceparent':JswzYMyjBLHqKiUmGDuvfWgpThdCQo,'tracestate':JswzYMyjBLHqKiUmGDuvfWgpThdCQr,'newrelic':JswzYMyjBLHqKiUmGDuvfWgpThdCQF,'x-app-version':'1.26.1','x-device-id':'','x-device-os-version':JswzYMyjBLHqKiUmGDuvfWgpThdCQk.OS_VERSION,'x-nr-session-id':JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['session_web_id'],'x-pcid':'',}
   JswzYMyjBLHqKiUmGDuvfWgpThdCnk=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.make_CP_DefaultCookies()
   JswzYMyjBLHqKiUmGDuvfWgpThdCnx=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.callRequestCookies('Get',JswzYMyjBLHqKiUmGDuvfWgpThdCnO,payload=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,params=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,headers=JswzYMyjBLHqKiUmGDuvfWgpThdCnI,cookies=JswzYMyjBLHqKiUmGDuvfWgpThdCnk,redirects=JswzYMyjBLHqKiUmGDuvfWgpThdCOE)
   if JswzYMyjBLHqKiUmGDuvfWgpThdCnx.status_code not in[200]:return JswzYMyjBLHqKiUmGDuvfWgpThdCOE
   JswzYMyjBLHqKiUmGDuvfWgpThdCnS=json.loads(JswzYMyjBLHqKiUmGDuvfWgpThdCnx.text)
   JswzYMyjBLHqKiUmGDuvfWgpThdCnP=0 
   for JswzYMyjBLHqKiUmGDuvfWgpThdCne in JswzYMyjBLHqKiUmGDuvfWgpThdCnx.cookies:
    JswzYMyjBLHqKiUmGDuvfWgpThdCOa(JswzYMyjBLHqKiUmGDuvfWgpThdCne.name)
    if JswzYMyjBLHqKiUmGDuvfWgpThdCne.name=='bm_sv':
     JswzYMyjBLHqKiUmGDuvfWgpThdCnP=1
     JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['bm_sv'] =JswzYMyjBLHqKiUmGDuvfWgpThdCne.value
     JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['bm_sv_ex']=JswzYMyjBLHqKiUmGDuvfWgpThdCne.expires 
   if JswzYMyjBLHqKiUmGDuvfWgpThdCnP==0:
    JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['bm_sv_ex']=JswzYMyjBLHqKiUmGDuvfWgpThdCOc(time.time())+60*60*2 
   JswzYMyjBLHqKiUmGDuvfWgpThdCnE=JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('data')[JswzYMyjBLHqKiUmGDuvfWgpThdCOc(JswzYMyjBLHqKiUmGDuvfWgpThdCnE)]
   JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['accountId']=JswzYMyjBLHqKiUmGDuvfWgpThdCnE.get('accountId')
   JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['profileId']=JswzYMyjBLHqKiUmGDuvfWgpThdCnE.get('profileId')
  except JswzYMyjBLHqKiUmGDuvfWgpThdCOo as exception:
   JswzYMyjBLHqKiUmGDuvfWgpThdCOa(exception)
   return JswzYMyjBLHqKiUmGDuvfWgpThdCOE
  if re_check==JswzYMyjBLHqKiUmGDuvfWgpThdCOE:
   JswzYMyjBLHqKiUmGDuvfWgpThdCna =JswzYMyjBLHqKiUmGDuvfWgpThdCQk.Get_Now_Datetime()
   JswzYMyjBLHqKiUmGDuvfWgpThdCnV=JswzYMyjBLHqKiUmGDuvfWgpThdCna+datetime.timedelta(days=limit_days)
   JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['limitdate']=JswzYMyjBLHqKiUmGDuvfWgpThdCnV.strftime('%Y-%m-%d')
  else:
   JswzYMyjBLHqKiUmGDuvfWgpThdCOa('re check')
  JswzYMyjBLHqKiUmGDuvfWgpThdCQk.dic_To_jsonfile(JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP_COOKIE_FILENAME,JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP)
  return JswzYMyjBLHqKiUmGDuvfWgpThdCOF
 def Get_Category_GroupList(JswzYMyjBLHqKiUmGDuvfWgpThdCQk,vType):
  JswzYMyjBLHqKiUmGDuvfWgpThdCnX=[] 
  try:
   JswzYMyjBLHqKiUmGDuvfWgpThdCnO=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.API_VIEWURL+'/v2/discover/feed' 
   JswzYMyjBLHqKiUmGDuvfWgpThdCnc={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false',}
   JswzYMyjBLHqKiUmGDuvfWgpThdCnx=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.callRequestCookies('Get',JswzYMyjBLHqKiUmGDuvfWgpThdCnO,payload=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,params=JswzYMyjBLHqKiUmGDuvfWgpThdCnc,headers=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,cookies=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,redirects=JswzYMyjBLHqKiUmGDuvfWgpThdCOF)
   if JswzYMyjBLHqKiUmGDuvfWgpThdCnx.status_code not in[200]:return[]
   JswzYMyjBLHqKiUmGDuvfWgpThdCnS=json.loads(JswzYMyjBLHqKiUmGDuvfWgpThdCnx.text)
   if vType in['TVSHOWS','MOVIES']:
    JswzYMyjBLHqKiUmGDuvfWgpThdCno='Explores' 
   elif vType in['EDUCATION']:
    JswzYMyjBLHqKiUmGDuvfWgpThdCno='Collection-Rails-Curation'
   elif vType in['ALL','KIDS']:
    JswzYMyjBLHqKiUmGDuvfWgpThdCno='Explores-Categories'
   for JswzYMyjBLHqKiUmGDuvfWgpThdCnr in JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('data'):
    if JswzYMyjBLHqKiUmGDuvfWgpThdCnr.get('type')==JswzYMyjBLHqKiUmGDuvfWgpThdCno:
     for JswzYMyjBLHqKiUmGDuvfWgpThdCnF in JswzYMyjBLHqKiUmGDuvfWgpThdCnr.get('data'):
      if vType in['TVSHOWS','MOVIES']:
       JswzYMyjBLHqKiUmGDuvfWgpThdCnN=JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('collectionId')
      elif vType in['EDUCATION','ALL','KIDS']:
       JswzYMyjBLHqKiUmGDuvfWgpThdCnN=JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('id')
      JswzYMyjBLHqKiUmGDuvfWgpThdCnR={'collectionId':JswzYMyjBLHqKiUmGDuvfWgpThdCnN,'title':JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('name'),'category':JswzYMyjBLHqKiUmGDuvfWgpThdCnr.get('category'),'pre_title':'',}
      JswzYMyjBLHqKiUmGDuvfWgpThdCnX.append(JswzYMyjBLHqKiUmGDuvfWgpThdCnR)
     break
  except JswzYMyjBLHqKiUmGDuvfWgpThdCOo as exception:
   JswzYMyjBLHqKiUmGDuvfWgpThdCOa(exception)
   return[]
  return JswzYMyjBLHqKiUmGDuvfWgpThdCnX
 def Get_Category_List(JswzYMyjBLHqKiUmGDuvfWgpThdCQk,vType,JswzYMyjBLHqKiUmGDuvfWgpThdCnN,page_int):
  JswzYMyjBLHqKiUmGDuvfWgpThdCnX=[] 
  JswzYMyjBLHqKiUmGDuvfWgpThdCkQ=JswzYMyjBLHqKiUmGDuvfWgpThdCOE
  try:
   if vType in['ALL','KIDS']:
    JswzYMyjBLHqKiUmGDuvfWgpThdCnI={'x-membersrl':JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['member_srl'],'x-pcid':JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['PCID'],'x-profileid':JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['profileId'],}
    JswzYMyjBLHqKiUmGDuvfWgpThdCnc={'platform':'WEBCLIENT','page':JswzYMyjBLHqKiUmGDuvfWgpThdCOV(page_int),'perPage':JswzYMyjBLHqKiUmGDuvfWgpThdCOV(JswzYMyjBLHqKiUmGDuvfWgpThdCQk.PAGE_LIMIT),'locale':'ko','sort':'',}
    JswzYMyjBLHqKiUmGDuvfWgpThdCnO=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.API_VIEWURL+'/v1/discover/categories/'+JswzYMyjBLHqKiUmGDuvfWgpThdCnN+'/titles'
    JswzYMyjBLHqKiUmGDuvfWgpThdCnx=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.callRequestCookies('Get',JswzYMyjBLHqKiUmGDuvfWgpThdCnO,payload=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,params=JswzYMyjBLHqKiUmGDuvfWgpThdCnc,headers=JswzYMyjBLHqKiUmGDuvfWgpThdCnI,cookies=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,redirects=JswzYMyjBLHqKiUmGDuvfWgpThdCOF)
   else: 
    JswzYMyjBLHqKiUmGDuvfWgpThdCnc={'platform':'WEBCLIENT','page':JswzYMyjBLHqKiUmGDuvfWgpThdCOV(page_int),'perPage':JswzYMyjBLHqKiUmGDuvfWgpThdCOV(JswzYMyjBLHqKiUmGDuvfWgpThdCQk.PAGE_LIMIT),}
    JswzYMyjBLHqKiUmGDuvfWgpThdCnO=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.API_VIEWURL+'/v1/discover/collections/'+JswzYMyjBLHqKiUmGDuvfWgpThdCnN+'/titles'
    JswzYMyjBLHqKiUmGDuvfWgpThdCnx=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.callRequestCookies('Get',JswzYMyjBLHqKiUmGDuvfWgpThdCnO,payload=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,params=JswzYMyjBLHqKiUmGDuvfWgpThdCnc,headers=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,cookies=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,redirects=JswzYMyjBLHqKiUmGDuvfWgpThdCOF)
   if JswzYMyjBLHqKiUmGDuvfWgpThdCnx.status_code not in[200]:return[],JswzYMyjBLHqKiUmGDuvfWgpThdCOE
   JswzYMyjBLHqKiUmGDuvfWgpThdCnS=json.loads(JswzYMyjBLHqKiUmGDuvfWgpThdCnx.text)
   if vType in['ALL','KIDS']:
    JswzYMyjBLHqKiUmGDuvfWgpThdCkn=JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('data').get('data')
   else:
    JswzYMyjBLHqKiUmGDuvfWgpThdCkn=JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('data')
   for JswzYMyjBLHqKiUmGDuvfWgpThdCnF in JswzYMyjBLHqKiUmGDuvfWgpThdCkn:
    JswzYMyjBLHqKiUmGDuvfWgpThdCkO=JswzYMyjBLHqKiUmGDuvfWgpThdCkA=JswzYMyjBLHqKiUmGDuvfWgpThdCOt=JswzYMyjBLHqKiUmGDuvfWgpThdCOl=''
    if 'poster' in JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('images'):JswzYMyjBLHqKiUmGDuvfWgpThdCkO =JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('images'):JswzYMyjBLHqKiUmGDuvfWgpThdCkA =JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('images').get('story-art').get('url') +'?imwidth=600'
    if 'title-treatment' in JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('images'):JswzYMyjBLHqKiUmGDuvfWgpThdCOt=JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('images').get('title-treatment').get('url')+'?imwidth=300'
    if 'story-art' in JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('images'):JswzYMyjBLHqKiUmGDuvfWgpThdCOl =JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('images').get('story-art').get('url') +'?imwidth=600'
    JswzYMyjBLHqKiUmGDuvfWgpThdCkx=''
    if JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('badge')not in[{},JswzYMyjBLHqKiUmGDuvfWgpThdCOP]:
     for i in JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('badge').get('text'):
      JswzYMyjBLHqKiUmGDuvfWgpThdCkx+=i.get('text')
    JswzYMyjBLHqKiUmGDuvfWgpThdCke=''
    if JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('seasonList')!=JswzYMyjBLHqKiUmGDuvfWgpThdCOP:
     JswzYMyjBLHqKiUmGDuvfWgpThdCke=','.join(JswzYMyjBLHqKiUmGDuvfWgpThdCOV(e)for e in JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('seasonList'))
    JswzYMyjBLHqKiUmGDuvfWgpThdCkl =[]
    for JswzYMyjBLHqKiUmGDuvfWgpThdCkt in JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('tags'):
     JswzYMyjBLHqKiUmGDuvfWgpThdCkl.append(JswzYMyjBLHqKiUmGDuvfWgpThdCkt.get('tag'))
    JswzYMyjBLHqKiUmGDuvfWgpThdCnR={'id':JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('id'),'title':JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('title'),'thumbnail':{'poster':JswzYMyjBLHqKiUmGDuvfWgpThdCkO,'thumb':JswzYMyjBLHqKiUmGDuvfWgpThdCkA,'clearlogo':JswzYMyjBLHqKiUmGDuvfWgpThdCOt,'fanart':JswzYMyjBLHqKiUmGDuvfWgpThdCOl},'mpaa':JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('age_rating'),'duration':JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('running_time'),'asis':JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('as'),'badge':JswzYMyjBLHqKiUmGDuvfWgpThdCkx,'year':JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('meta').get('releaseYear'),'seasonList':JswzYMyjBLHqKiUmGDuvfWgpThdCke,'genreList':JswzYMyjBLHqKiUmGDuvfWgpThdCkl,}
    JswzYMyjBLHqKiUmGDuvfWgpThdCnX.append(JswzYMyjBLHqKiUmGDuvfWgpThdCnR)
   if JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('pagination').get('totalPages')>page_int:
    JswzYMyjBLHqKiUmGDuvfWgpThdCkQ=JswzYMyjBLHqKiUmGDuvfWgpThdCOF
  except JswzYMyjBLHqKiUmGDuvfWgpThdCOo as exception:
   JswzYMyjBLHqKiUmGDuvfWgpThdCOa(exception)
   return[],JswzYMyjBLHqKiUmGDuvfWgpThdCOE
  return JswzYMyjBLHqKiUmGDuvfWgpThdCnX,JswzYMyjBLHqKiUmGDuvfWgpThdCkQ
 def Get_Episode_List(JswzYMyjBLHqKiUmGDuvfWgpThdCQk,programId,season):
  JswzYMyjBLHqKiUmGDuvfWgpThdCnX=[] 
  try:
   JswzYMyjBLHqKiUmGDuvfWgpThdCnO=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.API_VIEWURL+'/v1/discover/titles/'+programId+'/episodes'
   JswzYMyjBLHqKiUmGDuvfWgpThdCnc={'season':season,'sort':'true','locale':'ko',}
   JswzYMyjBLHqKiUmGDuvfWgpThdCnx=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.callRequestCookies('Get',JswzYMyjBLHqKiUmGDuvfWgpThdCnO,payload=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,params=JswzYMyjBLHqKiUmGDuvfWgpThdCnc,headers=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,cookies=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,redirects=JswzYMyjBLHqKiUmGDuvfWgpThdCOF)
   if JswzYMyjBLHqKiUmGDuvfWgpThdCnx.status_code not in[200]:return[]
   JswzYMyjBLHqKiUmGDuvfWgpThdCnS=json.loads(JswzYMyjBLHqKiUmGDuvfWgpThdCnx.text)
   for JswzYMyjBLHqKiUmGDuvfWgpThdCnF in JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('data'):
    JswzYMyjBLHqKiUmGDuvfWgpThdCkA=''
    if 'story-art' in JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('images'):JswzYMyjBLHqKiUmGDuvfWgpThdCkA =JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('images').get('story-art').get('url')+'?imwidth=600'
    JswzYMyjBLHqKiUmGDuvfWgpThdCkl =[]
    for JswzYMyjBLHqKiUmGDuvfWgpThdCkt in JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('tags'):
     JswzYMyjBLHqKiUmGDuvfWgpThdCkl.append(JswzYMyjBLHqKiUmGDuvfWgpThdCkt.get('tag'))
    JswzYMyjBLHqKiUmGDuvfWgpThdCnR={'id':JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('id'),'title':JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('title'),'thumbnail':{'thumb':JswzYMyjBLHqKiUmGDuvfWgpThdCkA,'fanart':JswzYMyjBLHqKiUmGDuvfWgpThdCkA},'mpaa':JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('age_rating'),'duration':JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('running_time'),'asis':JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('as'),'year':JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('meta').get('releaseYear'),'episode':JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('episode'),'genreList':JswzYMyjBLHqKiUmGDuvfWgpThdCkl,'desc':JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('description'),}
    JswzYMyjBLHqKiUmGDuvfWgpThdCnX.append(JswzYMyjBLHqKiUmGDuvfWgpThdCnR)
  except JswzYMyjBLHqKiUmGDuvfWgpThdCOo as exception:
   JswzYMyjBLHqKiUmGDuvfWgpThdCOa(exception)
   return[]
  return JswzYMyjBLHqKiUmGDuvfWgpThdCnX
 def Get_vInfo(JswzYMyjBLHqKiUmGDuvfWgpThdCQk,titleId):
  try:
   JswzYMyjBLHqKiUmGDuvfWgpThdCnO=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.API_VIEWURL+'/v1/discover/titles/'+titleId 
   JswzYMyjBLHqKiUmGDuvfWgpThdCnc={'platform':'WEBCLIENT','locale':'ko','filterRestrictedContent':'false',}
   JswzYMyjBLHqKiUmGDuvfWgpThdCnx=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.callRequestCookies('Get',JswzYMyjBLHqKiUmGDuvfWgpThdCnO,payload=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,params=JswzYMyjBLHqKiUmGDuvfWgpThdCnc,headers=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,cookies=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,redirects=JswzYMyjBLHqKiUmGDuvfWgpThdCOF)
   if JswzYMyjBLHqKiUmGDuvfWgpThdCnx.status_code not in[200]:return '','',''
   JswzYMyjBLHqKiUmGDuvfWgpThdCnS=json.loads(JswzYMyjBLHqKiUmGDuvfWgpThdCnx.text).get('data')
   JswzYMyjBLHqKiUmGDuvfWgpThdCke=''
   if JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('seasonList')!=JswzYMyjBLHqKiUmGDuvfWgpThdCOP:
    JswzYMyjBLHqKiUmGDuvfWgpThdCke=','.join(JswzYMyjBLHqKiUmGDuvfWgpThdCOV(e)for e in JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('seasonList'))
   JswzYMyjBLHqKiUmGDuvfWgpThdCkI={'age_rating':JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('age_rating'),'asset_id':JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('asset_id'),'availability':JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('availability'),'deal_id':JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('deal_id'),'downloadable':'true' if JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('downloadable')else 'false','region':JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('region'),'streamable':'true' if JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('streamable')else 'false','asis':JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('as'),'seasonList':JswzYMyjBLHqKiUmGDuvfWgpThdCke}
  except JswzYMyjBLHqKiUmGDuvfWgpThdCOo as exception:
   JswzYMyjBLHqKiUmGDuvfWgpThdCOa(exception)
   return{}
  return JswzYMyjBLHqKiUmGDuvfWgpThdCkI
 def Get_eInfo(JswzYMyjBLHqKiUmGDuvfWgpThdCQk,eventId):
  try:
   JswzYMyjBLHqKiUmGDuvfWgpThdCnO=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.API_VIEWURL+'/v1/discover/events/'+eventId 
   JswzYMyjBLHqKiUmGDuvfWgpThdCnc={'locale':'ko'}
   JswzYMyjBLHqKiUmGDuvfWgpThdCnx=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.callRequestCookies('Get',JswzYMyjBLHqKiUmGDuvfWgpThdCnO,payload=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,params=JswzYMyjBLHqKiUmGDuvfWgpThdCnc,headers=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,cookies=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,redirects=JswzYMyjBLHqKiUmGDuvfWgpThdCOF)
   if JswzYMyjBLHqKiUmGDuvfWgpThdCnx.status_code not in[200]:return '','',''
   JswzYMyjBLHqKiUmGDuvfWgpThdCnS=json.loads(JswzYMyjBLHqKiUmGDuvfWgpThdCnx.text).get('data')
   JswzYMyjBLHqKiUmGDuvfWgpThdCkI={'asset_id':JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('asset_id'),'deal_id':JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('deal_id'),'region':JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('region'),'streamable':'true' if JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('streamable')else 'false',}
  except JswzYMyjBLHqKiUmGDuvfWgpThdCOo as exception:
   JswzYMyjBLHqKiUmGDuvfWgpThdCOa(exception)
   return{}
  return JswzYMyjBLHqKiUmGDuvfWgpThdCkI
 def GetBroadURL(JswzYMyjBLHqKiUmGDuvfWgpThdCQk,titleId):
  JswzYMyjBLHqKiUmGDuvfWgpThdCkb=''
  JswzYMyjBLHqKiUmGDuvfWgpThdCkS =''
  JswzYMyjBLHqKiUmGDuvfWgpThdCkI=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.Get_vInfo(titleId)
  if JswzYMyjBLHqKiUmGDuvfWgpThdCkI=={}:return '',''
  try:
   JswzYMyjBLHqKiUmGDuvfWgpThdCnO=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.API_DOMAIN+'/api/playback/play' 
   JswzYMyjBLHqKiUmGDuvfWgpThdCnc={'titleId':titleId}
   JswzYMyjBLHqKiUmGDuvfWgpThdCQo,JswzYMyjBLHqKiUmGDuvfWgpThdCQr,JswzYMyjBLHqKiUmGDuvfWgpThdCQF=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.Make_authHeader()
   JswzYMyjBLHqKiUmGDuvfWgpThdCnI={'traceparent':JswzYMyjBLHqKiUmGDuvfWgpThdCQo,'tracestate':JswzYMyjBLHqKiUmGDuvfWgpThdCQr,'newrelic':JswzYMyjBLHqKiUmGDuvfWgpThdCQF,'x-drm':'com.microsoft.playready','x-app-version':'1.33.5','x-device-id':'','x-device-os-version':JswzYMyjBLHqKiUmGDuvfWgpThdCQk.OS_VERSION,'x-force-raw':'true','x-nr-session-id':JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['session_web_id'],'x-pcid':JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['profileId'],'x-profileType':'standard','x-sessionid':JswzYMyjBLHqKiUmGDuvfWgpThdCQk.generatePvId(genType='1'),'x-title-age-rating':JswzYMyjBLHqKiUmGDuvfWgpThdCkI.get('age_rating'),'x-title-availability':JswzYMyjBLHqKiUmGDuvfWgpThdCkI.get('availability'),'x-title-brightcove-id':JswzYMyjBLHqKiUmGDuvfWgpThdCkI.get('asset_id'),'x-title-deal-id':JswzYMyjBLHqKiUmGDuvfWgpThdCkI.get('deal_id'),'x-title-downloadable':JswzYMyjBLHqKiUmGDuvfWgpThdCkI.get('downloadable'),'x-title-region':JswzYMyjBLHqKiUmGDuvfWgpThdCkI.get('region'),'x-title-streamable':JswzYMyjBLHqKiUmGDuvfWgpThdCkI.get('streamable'),}
   JswzYMyjBLHqKiUmGDuvfWgpThdCnk=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.make_CP_DefaultCookies()
   JswzYMyjBLHqKiUmGDuvfWgpThdCnx=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.callRequestCookies('Get',JswzYMyjBLHqKiUmGDuvfWgpThdCnO,payload=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,params=JswzYMyjBLHqKiUmGDuvfWgpThdCnc,headers=JswzYMyjBLHqKiUmGDuvfWgpThdCnI,cookies=JswzYMyjBLHqKiUmGDuvfWgpThdCnk,redirects=JswzYMyjBLHqKiUmGDuvfWgpThdCOF)
   if JswzYMyjBLHqKiUmGDuvfWgpThdCnx.status_code not in[200]:return '',json.loads(JswzYMyjBLHqKiUmGDuvfWgpThdCnx.text).get('error').get('detail')
   JswzYMyjBLHqKiUmGDuvfWgpThdCnS=json.loads(JswzYMyjBLHqKiUmGDuvfWgpThdCnx.text)
   if JswzYMyjBLHqKiUmGDuvfWgpThdCkb=='':
    for JswzYMyjBLHqKiUmGDuvfWgpThdCnF in JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('data').get('raw').get('sources'):
     if 'key_systems' in JswzYMyjBLHqKiUmGDuvfWgpThdCnF and 'codecs' not in JswzYMyjBLHqKiUmGDuvfWgpThdCnF:
      if JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('type')=='application/dash+xml' and 'com.widevine.alpha' in JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('key_systems')and JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('src').startswith('https://')==JswzYMyjBLHqKiUmGDuvfWgpThdCOF:
       JswzYMyjBLHqKiUmGDuvfWgpThdCkb=JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('src')
       JswzYMyjBLHqKiUmGDuvfWgpThdCkS =JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if JswzYMyjBLHqKiUmGDuvfWgpThdCkb=='':
    for JswzYMyjBLHqKiUmGDuvfWgpThdCnF in JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('data').get('raw').get('sources'):
     if 'key_systems' in JswzYMyjBLHqKiUmGDuvfWgpThdCnF and 'codecs' not in JswzYMyjBLHqKiUmGDuvfWgpThdCnF:
      if JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('key_systems')and JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('src').startswith('https://')==JswzYMyjBLHqKiUmGDuvfWgpThdCOF:
       JswzYMyjBLHqKiUmGDuvfWgpThdCkb=JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('src')
       JswzYMyjBLHqKiUmGDuvfWgpThdCkS =JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if JswzYMyjBLHqKiUmGDuvfWgpThdCkb=='':
    for JswzYMyjBLHqKiUmGDuvfWgpThdCnF in JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('data').get('raw').get('sources'):
     if 'key_systems' in JswzYMyjBLHqKiUmGDuvfWgpThdCnF and 'codecs' in JswzYMyjBLHqKiUmGDuvfWgpThdCnF:
      if JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('type')=='application/dash+xml' and 'com.widevine.alpha' in JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('key_systems')and JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('src').startswith('https://')==JswzYMyjBLHqKiUmGDuvfWgpThdCOF:
       JswzYMyjBLHqKiUmGDuvfWgpThdCkb=JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('src')
       JswzYMyjBLHqKiUmGDuvfWgpThdCkS =JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if JswzYMyjBLHqKiUmGDuvfWgpThdCkb=='':
    for JswzYMyjBLHqKiUmGDuvfWgpThdCnF in JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('data').get('raw').get('sources'):
     if 'key_systems' in JswzYMyjBLHqKiUmGDuvfWgpThdCnF and 'codecs' in JswzYMyjBLHqKiUmGDuvfWgpThdCnF:
      if JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('key_systems')and JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('src').startswith('https://')==JswzYMyjBLHqKiUmGDuvfWgpThdCOF:
       JswzYMyjBLHqKiUmGDuvfWgpThdCkb=JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('src')
       JswzYMyjBLHqKiUmGDuvfWgpThdCkS =JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
  except JswzYMyjBLHqKiUmGDuvfWgpThdCOo as exception:
   JswzYMyjBLHqKiUmGDuvfWgpThdCOa(exception)
   return '',''
  return JswzYMyjBLHqKiUmGDuvfWgpThdCkb,JswzYMyjBLHqKiUmGDuvfWgpThdCkS
 def GetEventURL(JswzYMyjBLHqKiUmGDuvfWgpThdCQk,eventId,JswzYMyjBLHqKiUmGDuvfWgpThdCOQ):
  JswzYMyjBLHqKiUmGDuvfWgpThdCkb=''
  JswzYMyjBLHqKiUmGDuvfWgpThdCkS =''
  JswzYMyjBLHqKiUmGDuvfWgpThdCkI=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.Get_eInfo(eventId)
  if JswzYMyjBLHqKiUmGDuvfWgpThdCkI=={}:return '',''
  try:
   JswzYMyjBLHqKiUmGDuvfWgpThdCnO=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.API_DOMAIN+'/api/playback/play' 
   JswzYMyjBLHqKiUmGDuvfWgpThdCnc={'titleId':eventId,'titleType':JswzYMyjBLHqKiUmGDuvfWgpThdCOQ,}
   JswzYMyjBLHqKiUmGDuvfWgpThdCQo,JswzYMyjBLHqKiUmGDuvfWgpThdCQr,JswzYMyjBLHqKiUmGDuvfWgpThdCQF=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.Make_authHeader()
   JswzYMyjBLHqKiUmGDuvfWgpThdCnI={'traceparent':JswzYMyjBLHqKiUmGDuvfWgpThdCQo,'tracestate':JswzYMyjBLHqKiUmGDuvfWgpThdCQr,'newrelic':JswzYMyjBLHqKiUmGDuvfWgpThdCQF,'x-force-raw':'true','x-pcid':JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':JswzYMyjBLHqKiUmGDuvfWgpThdCkI.get('asset_id'),'x-title-deal-id':JswzYMyjBLHqKiUmGDuvfWgpThdCkI.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':JswzYMyjBLHqKiUmGDuvfWgpThdCkI.get('region'),'x-title-streamable':JswzYMyjBLHqKiUmGDuvfWgpThdCkI.get('streamable'),}
   JswzYMyjBLHqKiUmGDuvfWgpThdCnk=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.make_CP_DefaultCookies()
   JswzYMyjBLHqKiUmGDuvfWgpThdCnx=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.callRequestCookies('Get',JswzYMyjBLHqKiUmGDuvfWgpThdCnO,payload=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,params=JswzYMyjBLHqKiUmGDuvfWgpThdCnc,headers=JswzYMyjBLHqKiUmGDuvfWgpThdCnI,cookies=JswzYMyjBLHqKiUmGDuvfWgpThdCnk,redirects=JswzYMyjBLHqKiUmGDuvfWgpThdCOF)
   if JswzYMyjBLHqKiUmGDuvfWgpThdCnx.status_code not in[200]:return '',json.loads(JswzYMyjBLHqKiUmGDuvfWgpThdCnx.text).get('error').get('detail')
   JswzYMyjBLHqKiUmGDuvfWgpThdCnS=json.loads(JswzYMyjBLHqKiUmGDuvfWgpThdCnx.text)
   for JswzYMyjBLHqKiUmGDuvfWgpThdCnF in JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('data').get('raw').get('sources'):
    if JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('type')=='application/dash+xml' and JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('src')[0:8]=='https://':
     JswzYMyjBLHqKiUmGDuvfWgpThdCkb=JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('src')
     if 'key_systems' in JswzYMyjBLHqKiUmGDuvfWgpThdCnF:
      JswzYMyjBLHqKiUmGDuvfWgpThdCkS =JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('key_systems').get('com.widevine.alpha').get('license_url')
     break
  except JswzYMyjBLHqKiUmGDuvfWgpThdCOo as exception:
   JswzYMyjBLHqKiUmGDuvfWgpThdCOa(exception)
   return '',''
  return JswzYMyjBLHqKiUmGDuvfWgpThdCkb,JswzYMyjBLHqKiUmGDuvfWgpThdCkS
 def GetEventURL_Live(JswzYMyjBLHqKiUmGDuvfWgpThdCQk,eventId,JswzYMyjBLHqKiUmGDuvfWgpThdCOQ):
  JswzYMyjBLHqKiUmGDuvfWgpThdCkb=''
  JswzYMyjBLHqKiUmGDuvfWgpThdCkS =''
  JswzYMyjBLHqKiUmGDuvfWgpThdCkI=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.Get_eInfo(eventId)
  if JswzYMyjBLHqKiUmGDuvfWgpThdCkI=={}:return '',''
  try:
   JswzYMyjBLHqKiUmGDuvfWgpThdCnO=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.API_DOMAIN+'/api/playback/play' 
   JswzYMyjBLHqKiUmGDuvfWgpThdCnc={'titleId':eventId,'titleType':JswzYMyjBLHqKiUmGDuvfWgpThdCOQ,}
   JswzYMyjBLHqKiUmGDuvfWgpThdCQo,JswzYMyjBLHqKiUmGDuvfWgpThdCQr,JswzYMyjBLHqKiUmGDuvfWgpThdCQF=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.Make_authHeader()
   JswzYMyjBLHqKiUmGDuvfWgpThdCnI={'traceparent':JswzYMyjBLHqKiUmGDuvfWgpThdCQo,'tracestate':JswzYMyjBLHqKiUmGDuvfWgpThdCQr,'newrelic':JswzYMyjBLHqKiUmGDuvfWgpThdCQF,'x-force-raw':'true','x-pcid':JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':JswzYMyjBLHqKiUmGDuvfWgpThdCkI.get('asset_id'),'x-title-deal-id':JswzYMyjBLHqKiUmGDuvfWgpThdCkI.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':JswzYMyjBLHqKiUmGDuvfWgpThdCkI.get('region'),'x-title-streamable':JswzYMyjBLHqKiUmGDuvfWgpThdCkI.get('streamable'),}
   JswzYMyjBLHqKiUmGDuvfWgpThdCnk=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.make_CP_DefaultCookies()
   JswzYMyjBLHqKiUmGDuvfWgpThdCnx=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.callRequestCookies('Get',JswzYMyjBLHqKiUmGDuvfWgpThdCnO,payload=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,params=JswzYMyjBLHqKiUmGDuvfWgpThdCnc,headers=JswzYMyjBLHqKiUmGDuvfWgpThdCnI,cookies=JswzYMyjBLHqKiUmGDuvfWgpThdCnk,redirects=JswzYMyjBLHqKiUmGDuvfWgpThdCOF)
   if JswzYMyjBLHqKiUmGDuvfWgpThdCnx.status_code not in[200]:return '',json.loads(JswzYMyjBLHqKiUmGDuvfWgpThdCnx.text).get('error').get('detail')
   JswzYMyjBLHqKiUmGDuvfWgpThdCnS=json.loads(JswzYMyjBLHqKiUmGDuvfWgpThdCnx.text)
   if JswzYMyjBLHqKiUmGDuvfWgpThdCkb=='':
    for JswzYMyjBLHqKiUmGDuvfWgpThdCnF in JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('data').get('raw').get('sources'):
     if 'key_systems' in JswzYMyjBLHqKiUmGDuvfWgpThdCnF:
      if JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('type')=='application/dash+xml' and 'com.widevine.alpha' in JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('key_systems')and JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('src').startswith('https://')==JswzYMyjBLHqKiUmGDuvfWgpThdCOF:
       JswzYMyjBLHqKiUmGDuvfWgpThdCkb=JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('src')
       JswzYMyjBLHqKiUmGDuvfWgpThdCkS =JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('key_systems').get('com.widevine.alpha').get('license_url')
   if JswzYMyjBLHqKiUmGDuvfWgpThdCkb=='':
    for JswzYMyjBLHqKiUmGDuvfWgpThdCnF in JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('data').get('raw').get('sources'):
     if 'key_systems' in JswzYMyjBLHqKiUmGDuvfWgpThdCnF:
      if JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('key_systems')and JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('src').startswith('https://')==JswzYMyjBLHqKiUmGDuvfWgpThdCOF:
       JswzYMyjBLHqKiUmGDuvfWgpThdCkb=JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('src')
       JswzYMyjBLHqKiUmGDuvfWgpThdCkS =JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('key_systems').get('com.widevine.alpha').get('license_url')
   if JswzYMyjBLHqKiUmGDuvfWgpThdCkb=='':
    for JswzYMyjBLHqKiUmGDuvfWgpThdCnF in JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('data').get('raw').get('sources'):
     if JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('type')=='application/dash+xml' and JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('src').startswith('https://')==JswzYMyjBLHqKiUmGDuvfWgpThdCOF:
      JswzYMyjBLHqKiUmGDuvfWgpThdCkb=JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('src')
   if JswzYMyjBLHqKiUmGDuvfWgpThdCkb=='':
    for JswzYMyjBLHqKiUmGDuvfWgpThdCnF in JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('data').get('raw').get('sources'):
     if JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('type')=='application/x-mpegURL' and JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('src').startswith('https://')==JswzYMyjBLHqKiUmGDuvfWgpThdCOF:
      JswzYMyjBLHqKiUmGDuvfWgpThdCkb=JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('src')
  except JswzYMyjBLHqKiUmGDuvfWgpThdCOo as exception:
   JswzYMyjBLHqKiUmGDuvfWgpThdCOa(exception)
   return '',''
  return JswzYMyjBLHqKiUmGDuvfWgpThdCkb,JswzYMyjBLHqKiUmGDuvfWgpThdCkS
 def Get_Url_PostFix(JswzYMyjBLHqKiUmGDuvfWgpThdCQk,in_url):
  JswzYMyjBLHqKiUmGDuvfWgpThdCkP=urllib.parse.urlparse(in_url) 
  JswzYMyjBLHqKiUmGDuvfWgpThdCkE =JswzYMyjBLHqKiUmGDuvfWgpThdCkP.path.strip('/').split('/')
  JswzYMyjBLHqKiUmGDuvfWgpThdCka =JswzYMyjBLHqKiUmGDuvfWgpThdCkE[JswzYMyjBLHqKiUmGDuvfWgpThdCON(JswzYMyjBLHqKiUmGDuvfWgpThdCkE)-1]
  JswzYMyjBLHqKiUmGDuvfWgpThdCkV=JswzYMyjBLHqKiUmGDuvfWgpThdCka.split('.')
  return JswzYMyjBLHqKiUmGDuvfWgpThdCkV[JswzYMyjBLHqKiUmGDuvfWgpThdCON(JswzYMyjBLHqKiUmGDuvfWgpThdCkV)-1]
 def Get_Theme_GroupList(JswzYMyjBLHqKiUmGDuvfWgpThdCQk,vType):
  JswzYMyjBLHqKiUmGDuvfWgpThdCnX=[] 
  try:
   JswzYMyjBLHqKiUmGDuvfWgpThdCnO=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.API_VIEWURL+'/v2/discover/feed' 
   JswzYMyjBLHqKiUmGDuvfWgpThdCnc={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':JswzYMyjBLHqKiUmGDuvfWgpThdCOV(JswzYMyjBLHqKiUmGDuvfWgpThdCQk.PAGE_LIMIT),'filterRestrictedContent':'false',}
   JswzYMyjBLHqKiUmGDuvfWgpThdCnx=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.callRequestCookies('Get',JswzYMyjBLHqKiUmGDuvfWgpThdCnO,payload=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,params=JswzYMyjBLHqKiUmGDuvfWgpThdCnc,headers=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,cookies=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,redirects=JswzYMyjBLHqKiUmGDuvfWgpThdCOF)
   if JswzYMyjBLHqKiUmGDuvfWgpThdCnx.status_code not in[200]:return[]
   JswzYMyjBLHqKiUmGDuvfWgpThdCnS=json.loads(JswzYMyjBLHqKiUmGDuvfWgpThdCnx.text)
   for JswzYMyjBLHqKiUmGDuvfWgpThdCnF in JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('data'):
    if JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('type')=='Title-Rails-Curation':
     JswzYMyjBLHqKiUmGDuvfWgpThdCkX =''
     JswzYMyjBLHqKiUmGDuvfWgpThdCkc=7
     try:
      for i in JswzYMyjBLHqKiUmGDuvfWgpThdCOR(JswzYMyjBLHqKiUmGDuvfWgpThdCON(JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('data'))):
       if i>=JswzYMyjBLHqKiUmGDuvfWgpThdCkc:
        JswzYMyjBLHqKiUmGDuvfWgpThdCkX=JswzYMyjBLHqKiUmGDuvfWgpThdCkX+'...'
        break
       JswzYMyjBLHqKiUmGDuvfWgpThdCkX=JswzYMyjBLHqKiUmGDuvfWgpThdCkX+JswzYMyjBLHqKiUmGDuvfWgpThdCnF['data'][i]['title']+'\n'
     except JswzYMyjBLHqKiUmGDuvfWgpThdCOo as exception:
      JswzYMyjBLHqKiUmGDuvfWgpThdCOa(exception)
     JswzYMyjBLHqKiUmGDuvfWgpThdCnR={'collectionId':JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('obj_id'),'title':JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('row_name'),'category':JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('category'),'pre_title':JswzYMyjBLHqKiUmGDuvfWgpThdCkX,}
     JswzYMyjBLHqKiUmGDuvfWgpThdCnX.append(JswzYMyjBLHqKiUmGDuvfWgpThdCnR)
  except JswzYMyjBLHqKiUmGDuvfWgpThdCOo as exception:
   JswzYMyjBLHqKiUmGDuvfWgpThdCOa(exception)
   return[]
  return JswzYMyjBLHqKiUmGDuvfWgpThdCnX
 def Get_Event_GroupList(JswzYMyjBLHqKiUmGDuvfWgpThdCQk):
  JswzYMyjBLHqKiUmGDuvfWgpThdCnX=[] 
  try:
   JswzYMyjBLHqKiUmGDuvfWgpThdCnO=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.API_VIEWURL+'/v2/discover/feed' 
   JswzYMyjBLHqKiUmGDuvfWgpThdCnc={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':7,'filterRestrictedContent':'false',}
   JswzYMyjBLHqKiUmGDuvfWgpThdCnx=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.callRequestCookies('Get',JswzYMyjBLHqKiUmGDuvfWgpThdCnO,payload=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,params=JswzYMyjBLHqKiUmGDuvfWgpThdCnc,headers=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,cookies=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,redirects=JswzYMyjBLHqKiUmGDuvfWgpThdCOF)
   if JswzYMyjBLHqKiUmGDuvfWgpThdCnx.status_code not in[200]:return[]
   JswzYMyjBLHqKiUmGDuvfWgpThdCnS=json.loads(JswzYMyjBLHqKiUmGDuvfWgpThdCnx.text)
   for JswzYMyjBLHqKiUmGDuvfWgpThdCnF in JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('data'):
    if JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('row_name').strip()!='':
     JswzYMyjBLHqKiUmGDuvfWgpThdCkX =''
     JswzYMyjBLHqKiUmGDuvfWgpThdCkc=7
     try:
      for i in JswzYMyjBLHqKiUmGDuvfWgpThdCOR(JswzYMyjBLHqKiUmGDuvfWgpThdCON(JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('data'))):
       if i>=JswzYMyjBLHqKiUmGDuvfWgpThdCkc:
        JswzYMyjBLHqKiUmGDuvfWgpThdCkX=JswzYMyjBLHqKiUmGDuvfWgpThdCkX+'...'
        break
       JswzYMyjBLHqKiUmGDuvfWgpThdCkX=JswzYMyjBLHqKiUmGDuvfWgpThdCkX+JswzYMyjBLHqKiUmGDuvfWgpThdCnF['data'][i]['title']+'\n'
     except JswzYMyjBLHqKiUmGDuvfWgpThdCOo as exception:
      JswzYMyjBLHqKiUmGDuvfWgpThdCOa(exception)
     JswzYMyjBLHqKiUmGDuvfWgpThdCnR={'collectionId':JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('obj_id'),'title':JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('row_name'),'category':JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('type'),'pre_title':JswzYMyjBLHqKiUmGDuvfWgpThdCkX,}
     JswzYMyjBLHqKiUmGDuvfWgpThdCnX.append(JswzYMyjBLHqKiUmGDuvfWgpThdCnR)
  except JswzYMyjBLHqKiUmGDuvfWgpThdCOo as exception:
   JswzYMyjBLHqKiUmGDuvfWgpThdCOa(exception)
   return[]
  return JswzYMyjBLHqKiUmGDuvfWgpThdCnX
 def Get_Event_GameList(JswzYMyjBLHqKiUmGDuvfWgpThdCQk,JswzYMyjBLHqKiUmGDuvfWgpThdCnN):
  JswzYMyjBLHqKiUmGDuvfWgpThdCnX=[] 
  try:
   JswzYMyjBLHqKiUmGDuvfWgpThdCnO=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.API_VIEWURL+'/v2/discover/feed' 
   JswzYMyjBLHqKiUmGDuvfWgpThdCnc={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false',}
   JswzYMyjBLHqKiUmGDuvfWgpThdCnx=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.callRequestCookies('Get',JswzYMyjBLHqKiUmGDuvfWgpThdCnO,payload=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,params=JswzYMyjBLHqKiUmGDuvfWgpThdCnc,headers=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,cookies=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,redirects=JswzYMyjBLHqKiUmGDuvfWgpThdCOF)
   if JswzYMyjBLHqKiUmGDuvfWgpThdCnx.status_code not in[200]:return[]
   JswzYMyjBLHqKiUmGDuvfWgpThdCnS=json.loads(JswzYMyjBLHqKiUmGDuvfWgpThdCnx.text)
   for JswzYMyjBLHqKiUmGDuvfWgpThdCnF in JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('data'):
    if JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('obj_id')==JswzYMyjBLHqKiUmGDuvfWgpThdCnN:
     for JswzYMyjBLHqKiUmGDuvfWgpThdCko in JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('data'):
      JswzYMyjBLHqKiUmGDuvfWgpThdCkO=JswzYMyjBLHqKiUmGDuvfWgpThdCkA=JswzYMyjBLHqKiUmGDuvfWgpThdCOl=''
      if 'poster' in JswzYMyjBLHqKiUmGDuvfWgpThdCko.get('images'):JswzYMyjBLHqKiUmGDuvfWgpThdCkO =JswzYMyjBLHqKiUmGDuvfWgpThdCko.get('images').get('poster').get('url') +'?imwidth=350'
      if 'story-art' in JswzYMyjBLHqKiUmGDuvfWgpThdCko.get('images'):JswzYMyjBLHqKiUmGDuvfWgpThdCkA =JswzYMyjBLHqKiUmGDuvfWgpThdCko.get('images').get('story-art').get('url')+'?imwidth=600'
      if 'hero' in JswzYMyjBLHqKiUmGDuvfWgpThdCko.get('images'):JswzYMyjBLHqKiUmGDuvfWgpThdCOl =JswzYMyjBLHqKiUmGDuvfWgpThdCko.get('images').get('hero').get('url') +'?imwidth=600'
      JswzYMyjBLHqKiUmGDuvfWgpThdCkr=JswzYMyjBLHqKiUmGDuvfWgpThdCko.get('meta').get(JswzYMyjBLHqKiUmGDuvfWgpThdCko.get('category')).get(JswzYMyjBLHqKiUmGDuvfWgpThdCko.get('sub_category'))
      if 'league' in JswzYMyjBLHqKiUmGDuvfWgpThdCkr:
       JswzYMyjBLHqKiUmGDuvfWgpThdCkF=JswzYMyjBLHqKiUmGDuvfWgpThdCkr.get('league')
      else:
       JswzYMyjBLHqKiUmGDuvfWgpThdCkF=JswzYMyjBLHqKiUmGDuvfWgpThdCkr.get('round')
      JswzYMyjBLHqKiUmGDuvfWgpThdCnR={'id':JswzYMyjBLHqKiUmGDuvfWgpThdCko.get('id'),'title':JswzYMyjBLHqKiUmGDuvfWgpThdCko.get('title'),'thumbnail':{'poster':JswzYMyjBLHqKiUmGDuvfWgpThdCkO,'thumb':JswzYMyjBLHqKiUmGDuvfWgpThdCkA,'fanart':JswzYMyjBLHqKiUmGDuvfWgpThdCOl},'asis':JswzYMyjBLHqKiUmGDuvfWgpThdCko.get('type'),'addInfo':JswzYMyjBLHqKiUmGDuvfWgpThdCkF,'starttm':JswzYMyjBLHqKiUmGDuvfWgpThdCQk.convert_TimeStr(JswzYMyjBLHqKiUmGDuvfWgpThdCko.get('start_at')),}
      JswzYMyjBLHqKiUmGDuvfWgpThdCnX.append(JswzYMyjBLHqKiUmGDuvfWgpThdCnR)
  except JswzYMyjBLHqKiUmGDuvfWgpThdCOo as exception:
   JswzYMyjBLHqKiUmGDuvfWgpThdCOa(exception)
   return[]
  return JswzYMyjBLHqKiUmGDuvfWgpThdCnX
 def Get_Event_List(JswzYMyjBLHqKiUmGDuvfWgpThdCQk,gameId):
  JswzYMyjBLHqKiUmGDuvfWgpThdCnX=[] 
  try:
   JswzYMyjBLHqKiUmGDuvfWgpThdCnO=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.API_VIEWURL+'/v1/discover/events/'+gameId 
   JswzYMyjBLHqKiUmGDuvfWgpThdCnc={'platform':'WEBCLIENT','locale':'ko','filterRestrictedContent':'false',}
   JswzYMyjBLHqKiUmGDuvfWgpThdCnx=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.callRequestCookies('Get',JswzYMyjBLHqKiUmGDuvfWgpThdCnO,payload=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,params=JswzYMyjBLHqKiUmGDuvfWgpThdCnc,headers=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,cookies=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,redirects=JswzYMyjBLHqKiUmGDuvfWgpThdCOF)
   if JswzYMyjBLHqKiUmGDuvfWgpThdCnx.status_code not in[200]:return[]
   JswzYMyjBLHqKiUmGDuvfWgpThdCnS=json.loads(JswzYMyjBLHqKiUmGDuvfWgpThdCnx.text)
   JswzYMyjBLHqKiUmGDuvfWgpThdCnF=JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('data')
   JswzYMyjBLHqKiUmGDuvfWgpThdCkN=JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('end_at')
   JswzYMyjBLHqKiUmGDuvfWgpThdCkN=JswzYMyjBLHqKiUmGDuvfWgpThdCkN[0:19].replace('-','').replace(':','').replace('T','')
   JswzYMyjBLHqKiUmGDuvfWgpThdCkR=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d%H%M%S')
   if JswzYMyjBLHqKiUmGDuvfWgpThdCOc(JswzYMyjBLHqKiUmGDuvfWgpThdCkR)<JswzYMyjBLHqKiUmGDuvfWgpThdCOc(JswzYMyjBLHqKiUmGDuvfWgpThdCkN):
    JswzYMyjBLHqKiUmGDuvfWgpThdCkO=JswzYMyjBLHqKiUmGDuvfWgpThdCkA=JswzYMyjBLHqKiUmGDuvfWgpThdCOl=''
    if 'poster' in JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('images'):JswzYMyjBLHqKiUmGDuvfWgpThdCkO =JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('images'):JswzYMyjBLHqKiUmGDuvfWgpThdCkA =JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('images').get('story-art').get('url')+'?imwidth=600'
    if 'story-art' in JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('images'):JswzYMyjBLHqKiUmGDuvfWgpThdCOl =JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('images').get('story-art').get('url')+'?imwidth=600'
    JswzYMyjBLHqKiUmGDuvfWgpThdCnR={'id':JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('id'),'title':JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('title'),'thumbnail':{'poster':JswzYMyjBLHqKiUmGDuvfWgpThdCkO,'thumb':JswzYMyjBLHqKiUmGDuvfWgpThdCkA,'fanart':JswzYMyjBLHqKiUmGDuvfWgpThdCOl},'duration':JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('running_time'),'asis':JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('type'),'starttm':JswzYMyjBLHqKiUmGDuvfWgpThdCQk.convert_TimeStr(JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('start_at')),}
    JswzYMyjBLHqKiUmGDuvfWgpThdCnX.append(JswzYMyjBLHqKiUmGDuvfWgpThdCnR)
  except JswzYMyjBLHqKiUmGDuvfWgpThdCOo as exception:
   JswzYMyjBLHqKiUmGDuvfWgpThdCOa(exception)
   return[]
  try:
   JswzYMyjBLHqKiUmGDuvfWgpThdCnO=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.API_VIEWURL+'/v1/discover/events/'+gameId+'/related' 
   JswzYMyjBLHqKiUmGDuvfWgpThdCnc={'locale':'ko','page':'1','perPage':'25','platform':'WEBCLIENT','currentPageTracking':'page_discover_title_detail',}
   JswzYMyjBLHqKiUmGDuvfWgpThdCnx=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.callRequestCookies('Get',JswzYMyjBLHqKiUmGDuvfWgpThdCnO,payload=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,params=JswzYMyjBLHqKiUmGDuvfWgpThdCnc,headers=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,cookies=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,redirects=JswzYMyjBLHqKiUmGDuvfWgpThdCOF)
   if JswzYMyjBLHqKiUmGDuvfWgpThdCnx.status_code not in[200]:return[]
   JswzYMyjBLHqKiUmGDuvfWgpThdCnS=json.loads(JswzYMyjBLHqKiUmGDuvfWgpThdCnx.text)
   for JswzYMyjBLHqKiUmGDuvfWgpThdCnF in JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('data').get('data'):
    JswzYMyjBLHqKiUmGDuvfWgpThdCkO=JswzYMyjBLHqKiUmGDuvfWgpThdCkA=JswzYMyjBLHqKiUmGDuvfWgpThdCOl=''
    if 'poster' in JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('images'):JswzYMyjBLHqKiUmGDuvfWgpThdCkO =JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('images'):JswzYMyjBLHqKiUmGDuvfWgpThdCkA =JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('images').get('story-art').get('url')+'?imwidth=600'
    if 'story-art' in JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('images'):JswzYMyjBLHqKiUmGDuvfWgpThdCOl =JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('images').get('story-art').get('url')+'?imwidth=600'
    JswzYMyjBLHqKiUmGDuvfWgpThdCnR={'id':JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('id'),'title':JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('title'),'thumbnail':{'poster':JswzYMyjBLHqKiUmGDuvfWgpThdCkO,'thumb':JswzYMyjBLHqKiUmGDuvfWgpThdCkA,'fanart':JswzYMyjBLHqKiUmGDuvfWgpThdCOl},'duration':JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('running_time'),'asis':JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('type'),}
    JswzYMyjBLHqKiUmGDuvfWgpThdCnX.append(JswzYMyjBLHqKiUmGDuvfWgpThdCnR)
  except JswzYMyjBLHqKiUmGDuvfWgpThdCOo as exception:
   JswzYMyjBLHqKiUmGDuvfWgpThdCOa(exception)
   return[]
  return JswzYMyjBLHqKiUmGDuvfWgpThdCnX
 def Get_Search_List(JswzYMyjBLHqKiUmGDuvfWgpThdCQk,search_key,page_int):
  JswzYMyjBLHqKiUmGDuvfWgpThdCnX=[] 
  JswzYMyjBLHqKiUmGDuvfWgpThdCkQ=JswzYMyjBLHqKiUmGDuvfWgpThdCOE
  try:
   JswzYMyjBLHqKiUmGDuvfWgpThdCnO=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.API_VIEWURL+'/v2/search' 
   JswzYMyjBLHqKiUmGDuvfWgpThdCnc={'query':search_key,'platform':'WEBCLIENT','page':JswzYMyjBLHqKiUmGDuvfWgpThdCOV(page_int),'perPage':JswzYMyjBLHqKiUmGDuvfWgpThdCOV(JswzYMyjBLHqKiUmGDuvfWgpThdCQk.SEARCH_LIMIT),}
   JswzYMyjBLHqKiUmGDuvfWgpThdCnI={'x-membersrl':JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['member_srl'],'x-pcid':JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['PCID'],'x-profileid':JswzYMyjBLHqKiUmGDuvfWgpThdCQk.CP['SESSION']['profileId'],}
   JswzYMyjBLHqKiUmGDuvfWgpThdCnx=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.callRequestCookies('Get',JswzYMyjBLHqKiUmGDuvfWgpThdCnO,payload=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,params=JswzYMyjBLHqKiUmGDuvfWgpThdCnc,headers=JswzYMyjBLHqKiUmGDuvfWgpThdCnI,cookies=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,redirects=JswzYMyjBLHqKiUmGDuvfWgpThdCOF)
   if JswzYMyjBLHqKiUmGDuvfWgpThdCnx.status_code not in[200]:return[],JswzYMyjBLHqKiUmGDuvfWgpThdCOE
   JswzYMyjBLHqKiUmGDuvfWgpThdCnS=json.loads(JswzYMyjBLHqKiUmGDuvfWgpThdCnx.text)
   for JswzYMyjBLHqKiUmGDuvfWgpThdCnF in JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('data').get('data'):
    JswzYMyjBLHqKiUmGDuvfWgpThdCnF=JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('data')
    JswzYMyjBLHqKiUmGDuvfWgpThdCkO=JswzYMyjBLHqKiUmGDuvfWgpThdCkA=JswzYMyjBLHqKiUmGDuvfWgpThdCOt=JswzYMyjBLHqKiUmGDuvfWgpThdCOl=''
    if 'poster' in JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('images'):JswzYMyjBLHqKiUmGDuvfWgpThdCkO =JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('images'):JswzYMyjBLHqKiUmGDuvfWgpThdCkA =JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('images').get('story-art').get('url') +'?imwidth=600'
    if 'title-treatment' in JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('images'):JswzYMyjBLHqKiUmGDuvfWgpThdCOt=JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('images').get('title-treatment').get('url')+'?imwidth=300'
    if 'story-art' in JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('images'):JswzYMyjBLHqKiUmGDuvfWgpThdCOl =JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('images').get('story-art').get('url') +'?imwidth=600'
    JswzYMyjBLHqKiUmGDuvfWgpThdCkx=''
    if JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('badge')not in[{},JswzYMyjBLHqKiUmGDuvfWgpThdCOP]:
     for i in JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('badge').get('text'):
      if JswzYMyjBLHqKiUmGDuvfWgpThdCkx!='':JswzYMyjBLHqKiUmGDuvfWgpThdCkx+=' '
      JswzYMyjBLHqKiUmGDuvfWgpThdCkx+=i.get('text')
    if 'as' in JswzYMyjBLHqKiUmGDuvfWgpThdCnF:
     JswzYMyjBLHqKiUmGDuvfWgpThdCOQ=JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('as') 
    else:
     JswzYMyjBLHqKiUmGDuvfWgpThdCOQ=JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('type')
    JswzYMyjBLHqKiUmGDuvfWgpThdCnR={'id':JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('id'),'title':JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('title'),'asis':JswzYMyjBLHqKiUmGDuvfWgpThdCOQ,'thumbnail':{'poster':JswzYMyjBLHqKiUmGDuvfWgpThdCkO,'thumb':JswzYMyjBLHqKiUmGDuvfWgpThdCkA,'clearlogo':JswzYMyjBLHqKiUmGDuvfWgpThdCOt,'fanart':JswzYMyjBLHqKiUmGDuvfWgpThdCOl},'mpaa':JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('age_rating'),'duration':JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('running_time'),'badge':JswzYMyjBLHqKiUmGDuvfWgpThdCkx,'year':JswzYMyjBLHqKiUmGDuvfWgpThdCnF.get('meta').get('releaseYear'),}
    JswzYMyjBLHqKiUmGDuvfWgpThdCnX.append(JswzYMyjBLHqKiUmGDuvfWgpThdCnR)
   if JswzYMyjBLHqKiUmGDuvfWgpThdCnS.get('pagination').get('totalPages')>page_int:
    JswzYMyjBLHqKiUmGDuvfWgpThdCkQ=JswzYMyjBLHqKiUmGDuvfWgpThdCOF
  except JswzYMyjBLHqKiUmGDuvfWgpThdCOo as exception:
   JswzYMyjBLHqKiUmGDuvfWgpThdCOa(exception)
   return[],JswzYMyjBLHqKiUmGDuvfWgpThdCOE
  return JswzYMyjBLHqKiUmGDuvfWgpThdCnX,JswzYMyjBLHqKiUmGDuvfWgpThdCkQ
 def GetBookmarkInfo(JswzYMyjBLHqKiUmGDuvfWgpThdCQk,videoid,vidtype):
  JswzYMyjBLHqKiUmGDuvfWgpThdCOn={'indexinfo':{'ott':'coupang','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  JswzYMyjBLHqKiUmGDuvfWgpThdCnO=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.API_VIEWURL+'/v1/discover/titles/'+videoid 
  JswzYMyjBLHqKiUmGDuvfWgpThdCnc={'locale':'ko'}
  JswzYMyjBLHqKiUmGDuvfWgpThdCnx=JswzYMyjBLHqKiUmGDuvfWgpThdCQk.callRequestCookies('Get',JswzYMyjBLHqKiUmGDuvfWgpThdCnO,payload=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,params=JswzYMyjBLHqKiUmGDuvfWgpThdCnc,headers=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,cookies=JswzYMyjBLHqKiUmGDuvfWgpThdCOP,redirects=JswzYMyjBLHqKiUmGDuvfWgpThdCOF)
  if JswzYMyjBLHqKiUmGDuvfWgpThdCnx.status_code not in[200]:return{}
  JswzYMyjBLHqKiUmGDuvfWgpThdCOk=json.loads(JswzYMyjBLHqKiUmGDuvfWgpThdCnx.text).get('data')
  JswzYMyjBLHqKiUmGDuvfWgpThdCOx=JswzYMyjBLHqKiUmGDuvfWgpThdCOk.get('title')
  JswzYMyjBLHqKiUmGDuvfWgpThdCOe =JswzYMyjBLHqKiUmGDuvfWgpThdCOk.get('meta').get('releaseYear')
  JswzYMyjBLHqKiUmGDuvfWgpThdCOn['saveinfo']['infoLabels']['title']=JswzYMyjBLHqKiUmGDuvfWgpThdCOx
  if vidtype=='movie':
   JswzYMyjBLHqKiUmGDuvfWgpThdCOx='%s  (%s)'%(JswzYMyjBLHqKiUmGDuvfWgpThdCOx,JswzYMyjBLHqKiUmGDuvfWgpThdCOe)
  JswzYMyjBLHqKiUmGDuvfWgpThdCOn['saveinfo']['title'] =JswzYMyjBLHqKiUmGDuvfWgpThdCOx
  JswzYMyjBLHqKiUmGDuvfWgpThdCOn['saveinfo']['infoLabels']['mpaa'] =JswzYMyjBLHqKiUmGDuvfWgpThdCOk.get('age_rating')
  JswzYMyjBLHqKiUmGDuvfWgpThdCOn['saveinfo']['infoLabels']['plot'] ='%s\n\n%s'%(JswzYMyjBLHqKiUmGDuvfWgpThdCOk.get('short_description'),JswzYMyjBLHqKiUmGDuvfWgpThdCOk.get('description'))
  JswzYMyjBLHqKiUmGDuvfWgpThdCOn['saveinfo']['infoLabels']['year'] =JswzYMyjBLHqKiUmGDuvfWgpThdCOe
  if vidtype=='movie':
   JswzYMyjBLHqKiUmGDuvfWgpThdCOn['saveinfo']['infoLabels']['duration']=JswzYMyjBLHqKiUmGDuvfWgpThdCOk.get('running_time')
  JswzYMyjBLHqKiUmGDuvfWgpThdCkO =''
  JswzYMyjBLHqKiUmGDuvfWgpThdCOl =''
  JswzYMyjBLHqKiUmGDuvfWgpThdCkA =''
  JswzYMyjBLHqKiUmGDuvfWgpThdCOt=''
  if JswzYMyjBLHqKiUmGDuvfWgpThdCOk.get('images').get('poster') !=JswzYMyjBLHqKiUmGDuvfWgpThdCOP:JswzYMyjBLHqKiUmGDuvfWgpThdCkO =JswzYMyjBLHqKiUmGDuvfWgpThdCOk.get('images').get('poster').get('url') +'?imwidth=350'
  if JswzYMyjBLHqKiUmGDuvfWgpThdCOk.get('images').get('background') !=JswzYMyjBLHqKiUmGDuvfWgpThdCOP:JswzYMyjBLHqKiUmGDuvfWgpThdCOl =JswzYMyjBLHqKiUmGDuvfWgpThdCOk.get('images').get('background').get('url') +'?imwidth=600'
  if JswzYMyjBLHqKiUmGDuvfWgpThdCOk.get('images').get('story-art') !=JswzYMyjBLHqKiUmGDuvfWgpThdCOP:JswzYMyjBLHqKiUmGDuvfWgpThdCkA =JswzYMyjBLHqKiUmGDuvfWgpThdCOk.get('images').get('story-art').get('url') +'?imwidth=600'
  if JswzYMyjBLHqKiUmGDuvfWgpThdCOk.get('images').get('title-treatment')!=JswzYMyjBLHqKiUmGDuvfWgpThdCOP:JswzYMyjBLHqKiUmGDuvfWgpThdCOt=JswzYMyjBLHqKiUmGDuvfWgpThdCOk.get('images').get('title-treatment').get('url')+'?imwidth=300'
  if JswzYMyjBLHqKiUmGDuvfWgpThdCOl=='':JswzYMyjBLHqKiUmGDuvfWgpThdCOl=JswzYMyjBLHqKiUmGDuvfWgpThdCkA
  JswzYMyjBLHqKiUmGDuvfWgpThdCOn['saveinfo']['thumbnail']['poster']=JswzYMyjBLHqKiUmGDuvfWgpThdCkO
  JswzYMyjBLHqKiUmGDuvfWgpThdCOn['saveinfo']['thumbnail']['fanart']=JswzYMyjBLHqKiUmGDuvfWgpThdCOl
  JswzYMyjBLHqKiUmGDuvfWgpThdCOn['saveinfo']['thumbnail']['thumb']=JswzYMyjBLHqKiUmGDuvfWgpThdCkA
  JswzYMyjBLHqKiUmGDuvfWgpThdCOn['saveinfo']['thumbnail']['clearlogo']=JswzYMyjBLHqKiUmGDuvfWgpThdCOt
  JswzYMyjBLHqKiUmGDuvfWgpThdCOA=[]
  for JswzYMyjBLHqKiUmGDuvfWgpThdCkt in JswzYMyjBLHqKiUmGDuvfWgpThdCOk.get('tags'):JswzYMyjBLHqKiUmGDuvfWgpThdCOA.append(JswzYMyjBLHqKiUmGDuvfWgpThdCkt.get('tag'))
  if JswzYMyjBLHqKiUmGDuvfWgpThdCON(JswzYMyjBLHqKiUmGDuvfWgpThdCOA)>0:
   JswzYMyjBLHqKiUmGDuvfWgpThdCOn['saveinfo']['infoLabels']['genre']=JswzYMyjBLHqKiUmGDuvfWgpThdCOA
  JswzYMyjBLHqKiUmGDuvfWgpThdCOI=[]
  JswzYMyjBLHqKiUmGDuvfWgpThdCOb=[]
  for JswzYMyjBLHqKiUmGDuvfWgpThdCkt in JswzYMyjBLHqKiUmGDuvfWgpThdCOk.get('people'):
   if JswzYMyjBLHqKiUmGDuvfWgpThdCkt.get('role')=='CAST' :JswzYMyjBLHqKiUmGDuvfWgpThdCOI.append(JswzYMyjBLHqKiUmGDuvfWgpThdCkt.get('name'))
   if JswzYMyjBLHqKiUmGDuvfWgpThdCkt.get('role')=='DIRECTOR':JswzYMyjBLHqKiUmGDuvfWgpThdCOb.append(JswzYMyjBLHqKiUmGDuvfWgpThdCkt.get('name'))
  if JswzYMyjBLHqKiUmGDuvfWgpThdCON(JswzYMyjBLHqKiUmGDuvfWgpThdCOI)>0:
   JswzYMyjBLHqKiUmGDuvfWgpThdCOn['saveinfo']['infoLabels']['cast'] =JswzYMyjBLHqKiUmGDuvfWgpThdCOI
  if JswzYMyjBLHqKiUmGDuvfWgpThdCON(JswzYMyjBLHqKiUmGDuvfWgpThdCOb)>0:
   JswzYMyjBLHqKiUmGDuvfWgpThdCOn['saveinfo']['infoLabels']['director']=JswzYMyjBLHqKiUmGDuvfWgpThdCOb
  return JswzYMyjBLHqKiUmGDuvfWgpThdCOn
# Created by pyminifier (https://github.com/liftoff/pyminifier)
