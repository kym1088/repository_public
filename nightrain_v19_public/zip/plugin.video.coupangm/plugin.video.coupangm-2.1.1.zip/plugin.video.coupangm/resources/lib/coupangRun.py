__author__="NightRain"
AKaLrfeOPzRIYxWSwJDnFctgvdBkEH=object
AKaLrfeOPzRIYxWSwJDnFctgvdBkEV=None
AKaLrfeOPzRIYxWSwJDnFctgvdBkEu=False
AKaLrfeOPzRIYxWSwJDnFctgvdBkjp=True
AKaLrfeOPzRIYxWSwJDnFctgvdBkjX=type
AKaLrfeOPzRIYxWSwJDnFctgvdBkjM=dict
AKaLrfeOPzRIYxWSwJDnFctgvdBkjN=getattr
AKaLrfeOPzRIYxWSwJDnFctgvdBkji=int
AKaLrfeOPzRIYxWSwJDnFctgvdBkjE=list
AKaLrfeOPzRIYxWSwJDnFctgvdBkjy=open
AKaLrfeOPzRIYxWSwJDnFctgvdBkjs=Exception
AKaLrfeOPzRIYxWSwJDnFctgvdBkjo=str
AKaLrfeOPzRIYxWSwJDnFctgvdBkjh=id
AKaLrfeOPzRIYxWSwJDnFctgvdBkjT=len
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import inputstreamhelper
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
AKaLrfeOPzRIYxWSwJDnFctgvdBkpM=[{'title':'오직 쿠팡플레이에서','mode':'CATEGORY_LIST','vType':'ORIGINAL','collectionId':'5c33c5ca-ee6f-45f8-a026-dd789a8b63cf'},{'title':'홈   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'ALL'},{'title':'TV   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'MOVIES'},{'title':'키즈 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'KIDS'},{'title':'생중계','mode':'EVENT_GROUPLIST','vType':'LIVE'},{'title':'TV   (테마별)','mode':'THEME_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (테마별)','mode':'THEME_GROUPLIST','vType':'MOVIES'},{'title':'키즈 (테마별)','mode':'THEME_GROUPLIST','vType':'KIDS'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},{'title':'(쿠팡) 검색','mode':'LOCAL_SEARCH','icon':'search.png'},{'title':'(쿠팡) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
AKaLrfeOPzRIYxWSwJDnFctgvdBkpN=[{'title':'시리즈 시청내역','mode':'WATCH','stype':'tvshow'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},]
AKaLrfeOPzRIYxWSwJDnFctgvdBkpi={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
AKaLrfeOPzRIYxWSwJDnFctgvdBkpE=xbmcvfs.translatePath(os.path.join(__profile__,'coupang_searched.txt'))
from coupangCore import*
class AKaLrfeOPzRIYxWSwJDnFctgvdBkpX(AKaLrfeOPzRIYxWSwJDnFctgvdBkEH):
 def __init__(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj,AKaLrfeOPzRIYxWSwJDnFctgvdBkpy,AKaLrfeOPzRIYxWSwJDnFctgvdBkps,AKaLrfeOPzRIYxWSwJDnFctgvdBkpo):
  AKaLrfeOPzRIYxWSwJDnFctgvdBkpj._addon_url =AKaLrfeOPzRIYxWSwJDnFctgvdBkpy
  AKaLrfeOPzRIYxWSwJDnFctgvdBkpj._addon_handle=AKaLrfeOPzRIYxWSwJDnFctgvdBkps
  AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.main_params =AKaLrfeOPzRIYxWSwJDnFctgvdBkpo
  AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj =JswzYMyjBLHqKiUmGDuvfWgpThdCQn() 
  AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.CP_COOKIE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_cookies.json'))
  AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.CP_DEVICE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_device.json'))
 def addon_noti(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj,sting):
  try:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpT=xbmcgui.Dialog()
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpT.notification(__addonname__,sting)
  except:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkEV
 def addon_log(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj,string):
  try:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpG=string.encode('utf-8','ignore')
  except:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpG='addonException: addon_log'
  AKaLrfeOPzRIYxWSwJDnFctgvdBkpb=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,AKaLrfeOPzRIYxWSwJDnFctgvdBkpG),level=AKaLrfeOPzRIYxWSwJDnFctgvdBkpb)
 def get_keyboard_input(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj,AKaLrfeOPzRIYxWSwJDnFctgvdBkXN):
  AKaLrfeOPzRIYxWSwJDnFctgvdBkpl=AKaLrfeOPzRIYxWSwJDnFctgvdBkEV
  kb=xbmc.Keyboard()
  kb.setHeading(AKaLrfeOPzRIYxWSwJDnFctgvdBkXN)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpl=kb.getText()
  return AKaLrfeOPzRIYxWSwJDnFctgvdBkpl
 def get_settings_account(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj):
  AKaLrfeOPzRIYxWSwJDnFctgvdBkpq=__addon__.getSetting('id')
  AKaLrfeOPzRIYxWSwJDnFctgvdBkpm=__addon__.getSetting('pw')
  AKaLrfeOPzRIYxWSwJDnFctgvdBkpU=__addon__.getSetting('profile')
  return(AKaLrfeOPzRIYxWSwJDnFctgvdBkpq,AKaLrfeOPzRIYxWSwJDnFctgvdBkpm,AKaLrfeOPzRIYxWSwJDnFctgvdBkpU)
 def get_settings_exclusion21(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj):
  AKaLrfeOPzRIYxWSwJDnFctgvdBkpQ =__addon__.getSetting('exclusion21')
  if AKaLrfeOPzRIYxWSwJDnFctgvdBkpQ=='false':
   return AKaLrfeOPzRIYxWSwJDnFctgvdBkEu
  else:
   return AKaLrfeOPzRIYxWSwJDnFctgvdBkjp
 def get_settings_totalsearch(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj):
  AKaLrfeOPzRIYxWSwJDnFctgvdBkpC =AKaLrfeOPzRIYxWSwJDnFctgvdBkjp if __addon__.getSetting('local_search')=='true' else AKaLrfeOPzRIYxWSwJDnFctgvdBkEu
  AKaLrfeOPzRIYxWSwJDnFctgvdBkpH=AKaLrfeOPzRIYxWSwJDnFctgvdBkjp if __addon__.getSetting('local_history')=='true' else AKaLrfeOPzRIYxWSwJDnFctgvdBkEu
  AKaLrfeOPzRIYxWSwJDnFctgvdBkpV =AKaLrfeOPzRIYxWSwJDnFctgvdBkjp if __addon__.getSetting('total_search')=='true' else AKaLrfeOPzRIYxWSwJDnFctgvdBkEu
  AKaLrfeOPzRIYxWSwJDnFctgvdBkpu=AKaLrfeOPzRIYxWSwJDnFctgvdBkjp if __addon__.getSetting('total_history')=='true' else AKaLrfeOPzRIYxWSwJDnFctgvdBkEu
  AKaLrfeOPzRIYxWSwJDnFctgvdBkXp=AKaLrfeOPzRIYxWSwJDnFctgvdBkjp if __addon__.getSetting('menu_bookmark')=='true' else AKaLrfeOPzRIYxWSwJDnFctgvdBkEu
  return(AKaLrfeOPzRIYxWSwJDnFctgvdBkpC,AKaLrfeOPzRIYxWSwJDnFctgvdBkpH,AKaLrfeOPzRIYxWSwJDnFctgvdBkpV,AKaLrfeOPzRIYxWSwJDnFctgvdBkpu,AKaLrfeOPzRIYxWSwJDnFctgvdBkXp)
 def get_settings_makebookmark(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj):
  return AKaLrfeOPzRIYxWSwJDnFctgvdBkjp if __addon__.getSetting('make_bookmark')=='true' else AKaLrfeOPzRIYxWSwJDnFctgvdBkEu
 def add_dir(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj,label,sublabel='',img='',infoLabels=AKaLrfeOPzRIYxWSwJDnFctgvdBkEV,isFolder=AKaLrfeOPzRIYxWSwJDnFctgvdBkjp,params='',isLink=AKaLrfeOPzRIYxWSwJDnFctgvdBkEu,ContextMenu=AKaLrfeOPzRIYxWSwJDnFctgvdBkEV):
  AKaLrfeOPzRIYxWSwJDnFctgvdBkXM='%s?%s'%(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj._addon_url,urllib.parse.urlencode(params))
  if sublabel:AKaLrfeOPzRIYxWSwJDnFctgvdBkXN='%s < %s >'%(label,sublabel)
  else: AKaLrfeOPzRIYxWSwJDnFctgvdBkXN=label
  if not img:img='DefaultFolder.png'
  AKaLrfeOPzRIYxWSwJDnFctgvdBkXi=xbmcgui.ListItem(AKaLrfeOPzRIYxWSwJDnFctgvdBkXN)
  if AKaLrfeOPzRIYxWSwJDnFctgvdBkjX(img)==AKaLrfeOPzRIYxWSwJDnFctgvdBkjM:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXi.setArt(img)
  else:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXi.setArt({'thumb':img,'poster':img})
  if AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.KodiVersion>=20:
   if infoLabels:AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.Set_InfoTag(AKaLrfeOPzRIYxWSwJDnFctgvdBkXi.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:AKaLrfeOPzRIYxWSwJDnFctgvdBkXi.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXi.setProperty('IsPlayable','true')
  if ContextMenu:AKaLrfeOPzRIYxWSwJDnFctgvdBkXi.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj._addon_handle,AKaLrfeOPzRIYxWSwJDnFctgvdBkXM,AKaLrfeOPzRIYxWSwJDnFctgvdBkXi,isFolder)
 def Set_InfoTag(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj,video_InfoTag:xbmc.InfoTagVideo,AKaLrfeOPzRIYxWSwJDnFctgvdBkXG):
  for AKaLrfeOPzRIYxWSwJDnFctgvdBkXE,value in AKaLrfeOPzRIYxWSwJDnFctgvdBkXG.items():
   if AKaLrfeOPzRIYxWSwJDnFctgvdBkpi[AKaLrfeOPzRIYxWSwJDnFctgvdBkXE]['type']=='string':
    AKaLrfeOPzRIYxWSwJDnFctgvdBkjN(video_InfoTag,AKaLrfeOPzRIYxWSwJDnFctgvdBkpi[AKaLrfeOPzRIYxWSwJDnFctgvdBkXE]['func'])(value)
   elif AKaLrfeOPzRIYxWSwJDnFctgvdBkpi[AKaLrfeOPzRIYxWSwJDnFctgvdBkXE]['type']=='int':
    if AKaLrfeOPzRIYxWSwJDnFctgvdBkjX(value)==AKaLrfeOPzRIYxWSwJDnFctgvdBkji:
     AKaLrfeOPzRIYxWSwJDnFctgvdBkXj=AKaLrfeOPzRIYxWSwJDnFctgvdBkji(value)
    else:
     AKaLrfeOPzRIYxWSwJDnFctgvdBkXj=0
    AKaLrfeOPzRIYxWSwJDnFctgvdBkjN(video_InfoTag,AKaLrfeOPzRIYxWSwJDnFctgvdBkpi[AKaLrfeOPzRIYxWSwJDnFctgvdBkXE]['func'])(AKaLrfeOPzRIYxWSwJDnFctgvdBkXj)
   elif AKaLrfeOPzRIYxWSwJDnFctgvdBkpi[AKaLrfeOPzRIYxWSwJDnFctgvdBkXE]['type']=='actor':
    if value!=[]:
     AKaLrfeOPzRIYxWSwJDnFctgvdBkjN(video_InfoTag,AKaLrfeOPzRIYxWSwJDnFctgvdBkpi[AKaLrfeOPzRIYxWSwJDnFctgvdBkXE]['func'])([xbmc.Actor(name)for name in value])
   elif AKaLrfeOPzRIYxWSwJDnFctgvdBkpi[AKaLrfeOPzRIYxWSwJDnFctgvdBkXE]['type']=='list':
    if AKaLrfeOPzRIYxWSwJDnFctgvdBkjX(value)==AKaLrfeOPzRIYxWSwJDnFctgvdBkjE:
     AKaLrfeOPzRIYxWSwJDnFctgvdBkjN(video_InfoTag,AKaLrfeOPzRIYxWSwJDnFctgvdBkpi[AKaLrfeOPzRIYxWSwJDnFctgvdBkXE]['func'])(value)
    else:
     AKaLrfeOPzRIYxWSwJDnFctgvdBkjN(video_InfoTag,AKaLrfeOPzRIYxWSwJDnFctgvdBkpi[AKaLrfeOPzRIYxWSwJDnFctgvdBkXE]['func'])([value])
 def dp_Main_List(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj,args):
  (AKaLrfeOPzRIYxWSwJDnFctgvdBkpC,AKaLrfeOPzRIYxWSwJDnFctgvdBkpH,AKaLrfeOPzRIYxWSwJDnFctgvdBkpV,AKaLrfeOPzRIYxWSwJDnFctgvdBkpu,AKaLrfeOPzRIYxWSwJDnFctgvdBkXp)=AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.get_settings_totalsearch()
  for AKaLrfeOPzRIYxWSwJDnFctgvdBkXy in AKaLrfeOPzRIYxWSwJDnFctgvdBkpM:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXN=AKaLrfeOPzRIYxWSwJDnFctgvdBkXy.get('title')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXs=''
   if AKaLrfeOPzRIYxWSwJDnFctgvdBkXy.get('mode')=='LOCAL_SEARCH' and AKaLrfeOPzRIYxWSwJDnFctgvdBkpC ==AKaLrfeOPzRIYxWSwJDnFctgvdBkEu:continue
   elif AKaLrfeOPzRIYxWSwJDnFctgvdBkXy.get('mode')=='SEARCH_HISTORY' and AKaLrfeOPzRIYxWSwJDnFctgvdBkpH==AKaLrfeOPzRIYxWSwJDnFctgvdBkEu:continue
   elif AKaLrfeOPzRIYxWSwJDnFctgvdBkXy.get('mode')=='TOTAL_SEARCH' and AKaLrfeOPzRIYxWSwJDnFctgvdBkpV ==AKaLrfeOPzRIYxWSwJDnFctgvdBkEu:continue
   elif AKaLrfeOPzRIYxWSwJDnFctgvdBkXy.get('mode')=='TOTAL_HISTORY' and AKaLrfeOPzRIYxWSwJDnFctgvdBkpu==AKaLrfeOPzRIYxWSwJDnFctgvdBkEu:continue
   elif AKaLrfeOPzRIYxWSwJDnFctgvdBkXy.get('mode')=='MENU_BOOKMARK' and AKaLrfeOPzRIYxWSwJDnFctgvdBkXp==AKaLrfeOPzRIYxWSwJDnFctgvdBkEu:continue
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXo={'mode':AKaLrfeOPzRIYxWSwJDnFctgvdBkXy.get('mode'),'vType':AKaLrfeOPzRIYxWSwJDnFctgvdBkXy.get('vType'),'collectionId':AKaLrfeOPzRIYxWSwJDnFctgvdBkXy.get('collectionId'),'page':'1',}
   if AKaLrfeOPzRIYxWSwJDnFctgvdBkXy.get('mode')=='LOCAL_SEARCH':AKaLrfeOPzRIYxWSwJDnFctgvdBkXo['historyyn']='Y' 
   if AKaLrfeOPzRIYxWSwJDnFctgvdBkXy.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    AKaLrfeOPzRIYxWSwJDnFctgvdBkXh=AKaLrfeOPzRIYxWSwJDnFctgvdBkEu
    AKaLrfeOPzRIYxWSwJDnFctgvdBkXT =AKaLrfeOPzRIYxWSwJDnFctgvdBkjp
   else:
    AKaLrfeOPzRIYxWSwJDnFctgvdBkXh=AKaLrfeOPzRIYxWSwJDnFctgvdBkjp
    AKaLrfeOPzRIYxWSwJDnFctgvdBkXT =AKaLrfeOPzRIYxWSwJDnFctgvdBkEu
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXG={'title':AKaLrfeOPzRIYxWSwJDnFctgvdBkXN,'plot':AKaLrfeOPzRIYxWSwJDnFctgvdBkXN}
   if AKaLrfeOPzRIYxWSwJDnFctgvdBkXy.get('mode')=='XXX':AKaLrfeOPzRIYxWSwJDnFctgvdBkXG=AKaLrfeOPzRIYxWSwJDnFctgvdBkEV
   if 'icon' in AKaLrfeOPzRIYxWSwJDnFctgvdBkXy:AKaLrfeOPzRIYxWSwJDnFctgvdBkXs=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',AKaLrfeOPzRIYxWSwJDnFctgvdBkXy.get('icon')) 
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.add_dir(AKaLrfeOPzRIYxWSwJDnFctgvdBkXN,sublabel='',img=AKaLrfeOPzRIYxWSwJDnFctgvdBkXs,infoLabels=AKaLrfeOPzRIYxWSwJDnFctgvdBkXG,isFolder=AKaLrfeOPzRIYxWSwJDnFctgvdBkXh,params=AKaLrfeOPzRIYxWSwJDnFctgvdBkXo,isLink=AKaLrfeOPzRIYxWSwJDnFctgvdBkXT)
  xbmcplugin.endOfDirectory(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj._addon_handle)
 def dp_Test(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj,args):
  AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.addon_noti('test')
 def CP_logout(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj):
  AKaLrfeOPzRIYxWSwJDnFctgvdBkpT=xbmcgui.Dialog()
  AKaLrfeOPzRIYxWSwJDnFctgvdBkXl=AKaLrfeOPzRIYxWSwJDnFctgvdBkpT.yesno(__language__(30905).encode('utf8'),__language__(30906).encode('utf8'))
  if AKaLrfeOPzRIYxWSwJDnFctgvdBkXl==AKaLrfeOPzRIYxWSwJDnFctgvdBkEu:return 
  if os.path.isfile(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.CP_COOKIE_FILENAME):os.remove(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.CP_COOKIE_FILENAME)
  AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.addon_noti(__language__(30904).encode('utf-8'))
 def option_check(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj):
  (AKaLrfeOPzRIYxWSwJDnFctgvdBkpq,AKaLrfeOPzRIYxWSwJDnFctgvdBkpm,AKaLrfeOPzRIYxWSwJDnFctgvdBkpU)=AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.get_settings_account()
  if AKaLrfeOPzRIYxWSwJDnFctgvdBkpq=='' or AKaLrfeOPzRIYxWSwJDnFctgvdBkpm=='':
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpT=xbmcgui.Dialog()
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXl=AKaLrfeOPzRIYxWSwJDnFctgvdBkpT.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if AKaLrfeOPzRIYxWSwJDnFctgvdBkXl==AKaLrfeOPzRIYxWSwJDnFctgvdBkjp:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.cookiefile_check()==AKaLrfeOPzRIYxWSwJDnFctgvdBkEu:
   if AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CP_login(AKaLrfeOPzRIYxWSwJDnFctgvdBkpq,AKaLrfeOPzRIYxWSwJDnFctgvdBkpm,AKaLrfeOPzRIYxWSwJDnFctgvdBkpU)==AKaLrfeOPzRIYxWSwJDnFctgvdBkEu:
    AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.addon_noti(__language__(30903).encode('utf8'))
    sys.exit()
  else:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.Get_CP_profile(AKaLrfeOPzRIYxWSwJDnFctgvdBkpU,limit_days=AKaLrfeOPzRIYxWSwJDnFctgvdBkji(__addon__.getSetting('cache_ttl')),re_check=AKaLrfeOPzRIYxWSwJDnFctgvdBkjp)
 def cookiefile_check(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj):
  AKaLrfeOPzRIYxWSwJDnFctgvdBkXm={}
  try: 
   fp=AKaLrfeOPzRIYxWSwJDnFctgvdBkjy(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.CP_COOKIE_FILENAME,'r',-1,'utf-8')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXm= json.load(fp)
   fp.close()
  except AKaLrfeOPzRIYxWSwJDnFctgvdBkjs as exception:
   return AKaLrfeOPzRIYxWSwJDnFctgvdBkEu
  AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.CP=AKaLrfeOPzRIYxWSwJDnFctgvdBkXm
  if 'session_web_id' not in AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.CP.get('SESSION'):
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.Init_CP()
   return AKaLrfeOPzRIYxWSwJDnFctgvdBkEu
  (AKaLrfeOPzRIYxWSwJDnFctgvdBkpq,AKaLrfeOPzRIYxWSwJDnFctgvdBkpm,AKaLrfeOPzRIYxWSwJDnFctgvdBkpU)=AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.get_settings_account()
  (AKaLrfeOPzRIYxWSwJDnFctgvdBkXU,AKaLrfeOPzRIYxWSwJDnFctgvdBkXQ,AKaLrfeOPzRIYxWSwJDnFctgvdBkXC)=AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.Load_session_acount()
  if AKaLrfeOPzRIYxWSwJDnFctgvdBkpq!=AKaLrfeOPzRIYxWSwJDnFctgvdBkXU or AKaLrfeOPzRIYxWSwJDnFctgvdBkpm!=AKaLrfeOPzRIYxWSwJDnFctgvdBkXQ or AKaLrfeOPzRIYxWSwJDnFctgvdBkpU!=AKaLrfeOPzRIYxWSwJDnFctgvdBkjo(AKaLrfeOPzRIYxWSwJDnFctgvdBkXC):
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.Init_CP()
   return AKaLrfeOPzRIYxWSwJDnFctgvdBkEu
  AKaLrfeOPzRIYxWSwJDnFctgvdBkXH =AKaLrfeOPzRIYxWSwJDnFctgvdBkji(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.Get_Now_Datetime().strftime('%Y%m%d'))
  AKaLrfeOPzRIYxWSwJDnFctgvdBkXV=AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.CP['SESSION']['limitdate']
  AKaLrfeOPzRIYxWSwJDnFctgvdBkXu =AKaLrfeOPzRIYxWSwJDnFctgvdBkji(re.sub('-','',AKaLrfeOPzRIYxWSwJDnFctgvdBkXV))
  if AKaLrfeOPzRIYxWSwJDnFctgvdBkXu<AKaLrfeOPzRIYxWSwJDnFctgvdBkXH:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.Init_CP()
   return AKaLrfeOPzRIYxWSwJDnFctgvdBkEu
  return AKaLrfeOPzRIYxWSwJDnFctgvdBkjp
 def CP_login(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj,AKaLrfeOPzRIYxWSwJDnFctgvdBkpq,AKaLrfeOPzRIYxWSwJDnFctgvdBkpm,AKaLrfeOPzRIYxWSwJDnFctgvdBkpU):
  if AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.Get_CP_Login(AKaLrfeOPzRIYxWSwJDnFctgvdBkpq,AKaLrfeOPzRIYxWSwJDnFctgvdBkpm,AKaLrfeOPzRIYxWSwJDnFctgvdBkpU)==AKaLrfeOPzRIYxWSwJDnFctgvdBkEu:return AKaLrfeOPzRIYxWSwJDnFctgvdBkEu
  if AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.Get_CP_profile(AKaLrfeOPzRIYxWSwJDnFctgvdBkpU,limit_days=AKaLrfeOPzRIYxWSwJDnFctgvdBkji(__addon__.getSetting('cache_ttl')),re_check=AKaLrfeOPzRIYxWSwJDnFctgvdBkEu)==AKaLrfeOPzRIYxWSwJDnFctgvdBkEu:return AKaLrfeOPzRIYxWSwJDnFctgvdBkEu
  return AKaLrfeOPzRIYxWSwJDnFctgvdBkjp
 def dp_Category_GroupList(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj,args):
  AKaLrfeOPzRIYxWSwJDnFctgvdBkMp =args.get('vType') 
  AKaLrfeOPzRIYxWSwJDnFctgvdBkMX=AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.Get_Category_GroupList(AKaLrfeOPzRIYxWSwJDnFctgvdBkMp)
  for AKaLrfeOPzRIYxWSwJDnFctgvdBkMN in AKaLrfeOPzRIYxWSwJDnFctgvdBkMX:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXN =AKaLrfeOPzRIYxWSwJDnFctgvdBkMN.get('title')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkMi=AKaLrfeOPzRIYxWSwJDnFctgvdBkMN.get('pre_title')
   if AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.get_settings_exclusion21()==AKaLrfeOPzRIYxWSwJDnFctgvdBkjp and AKaLrfeOPzRIYxWSwJDnFctgvdBkXN=='성인':continue
   AKaLrfeOPzRIYxWSwJDnFctgvdBkME={'mediatype':'tvshow','plot':AKaLrfeOPzRIYxWSwJDnFctgvdBkMi,}
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXo={'mode':'CATEGORY_LIST','collectionId':AKaLrfeOPzRIYxWSwJDnFctgvdBkMN.get('collectionId'),'vType':AKaLrfeOPzRIYxWSwJDnFctgvdBkMN.get('category'),'page':'1',}
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.add_dir(AKaLrfeOPzRIYxWSwJDnFctgvdBkXN,sublabel='',img='',infoLabels=AKaLrfeOPzRIYxWSwJDnFctgvdBkME,isFolder=AKaLrfeOPzRIYxWSwJDnFctgvdBkjp,params=AKaLrfeOPzRIYxWSwJDnFctgvdBkXo)
  xbmcplugin.endOfDirectory(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj._addon_handle,cacheToDisc=AKaLrfeOPzRIYxWSwJDnFctgvdBkEu)
 def dp_Theme_GroupList(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj,args):
  AKaLrfeOPzRIYxWSwJDnFctgvdBkMp =args.get('vType') 
  AKaLrfeOPzRIYxWSwJDnFctgvdBkMX=AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.Get_Theme_GroupList(AKaLrfeOPzRIYxWSwJDnFctgvdBkMp)
  for AKaLrfeOPzRIYxWSwJDnFctgvdBkMN in AKaLrfeOPzRIYxWSwJDnFctgvdBkMX:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXN =AKaLrfeOPzRIYxWSwJDnFctgvdBkMN.get('title')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkMi=AKaLrfeOPzRIYxWSwJDnFctgvdBkMN.get('pre_title')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkME={'mediatype':'tvshow','plot':AKaLrfeOPzRIYxWSwJDnFctgvdBkMi,}
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXo={'mode':'CATEGORY_LIST','collectionId':AKaLrfeOPzRIYxWSwJDnFctgvdBkMN.get('collectionId'),'vType':AKaLrfeOPzRIYxWSwJDnFctgvdBkMN.get('category'),'page':'1',}
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.add_dir(AKaLrfeOPzRIYxWSwJDnFctgvdBkXN,sublabel='',img='',infoLabels=AKaLrfeOPzRIYxWSwJDnFctgvdBkME,isFolder=AKaLrfeOPzRIYxWSwJDnFctgvdBkjp,params=AKaLrfeOPzRIYxWSwJDnFctgvdBkXo)
  xbmcplugin.endOfDirectory(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj._addon_handle,cacheToDisc=AKaLrfeOPzRIYxWSwJDnFctgvdBkEu)
 def dp_Event_GroupList(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj,args):
  AKaLrfeOPzRIYxWSwJDnFctgvdBkMX=AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.Get_Event_GroupList()
  for AKaLrfeOPzRIYxWSwJDnFctgvdBkMN in AKaLrfeOPzRIYxWSwJDnFctgvdBkMX:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXN =AKaLrfeOPzRIYxWSwJDnFctgvdBkMN.get('title')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkMi=AKaLrfeOPzRIYxWSwJDnFctgvdBkMN.get('pre_title')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkME={'mediatype':'tvshow','plot':AKaLrfeOPzRIYxWSwJDnFctgvdBkMi,}
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXo={'mode':'EVENT_GAMELIST','collectionId':AKaLrfeOPzRIYxWSwJDnFctgvdBkMN.get('collectionId'),'vType':'LIVE',}
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.add_dir(AKaLrfeOPzRIYxWSwJDnFctgvdBkXN,sublabel='',img='',infoLabels=AKaLrfeOPzRIYxWSwJDnFctgvdBkME,isFolder=AKaLrfeOPzRIYxWSwJDnFctgvdBkjp,params=AKaLrfeOPzRIYxWSwJDnFctgvdBkXo)
  xbmcplugin.endOfDirectory(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj._addon_handle,cacheToDisc=AKaLrfeOPzRIYxWSwJDnFctgvdBkEu)
 def dp_Event_GameList(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj,args):
  AKaLrfeOPzRIYxWSwJDnFctgvdBkMp =args.get('vType') 
  AKaLrfeOPzRIYxWSwJDnFctgvdBkMy =args.get('collectionId')
  AKaLrfeOPzRIYxWSwJDnFctgvdBkMX=AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.Get_Event_GameList(AKaLrfeOPzRIYxWSwJDnFctgvdBkMy)
  for AKaLrfeOPzRIYxWSwJDnFctgvdBkMN in AKaLrfeOPzRIYxWSwJDnFctgvdBkMX:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXN =AKaLrfeOPzRIYxWSwJDnFctgvdBkMN.get('title')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkjh =AKaLrfeOPzRIYxWSwJDnFctgvdBkMN.get('id')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkMs =AKaLrfeOPzRIYxWSwJDnFctgvdBkMN.get('thumbnail')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkMo =AKaLrfeOPzRIYxWSwJDnFctgvdBkMN.get('asis') 
   AKaLrfeOPzRIYxWSwJDnFctgvdBkMh =AKaLrfeOPzRIYxWSwJDnFctgvdBkMN.get('addInfo')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkMT =AKaLrfeOPzRIYxWSwJDnFctgvdBkMN.get('starttm')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkME={'mediatype':'tvshow','title':AKaLrfeOPzRIYxWSwJDnFctgvdBkXN,'plot':AKaLrfeOPzRIYxWSwJDnFctgvdBkMh,}
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXo={'mode':'EVENT_LIST','id':AKaLrfeOPzRIYxWSwJDnFctgvdBkjh,'asis':AKaLrfeOPzRIYxWSwJDnFctgvdBkMo,'title':AKaLrfeOPzRIYxWSwJDnFctgvdBkXN,}
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.add_dir(AKaLrfeOPzRIYxWSwJDnFctgvdBkXN,sublabel=AKaLrfeOPzRIYxWSwJDnFctgvdBkMT,img=AKaLrfeOPzRIYxWSwJDnFctgvdBkMs,infoLabels=AKaLrfeOPzRIYxWSwJDnFctgvdBkME,isFolder=AKaLrfeOPzRIYxWSwJDnFctgvdBkjp,params=AKaLrfeOPzRIYxWSwJDnFctgvdBkXo,ContextMenu=AKaLrfeOPzRIYxWSwJDnFctgvdBkEV)
  xbmcplugin.setContent(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj._addon_handle,cacheToDisc=AKaLrfeOPzRIYxWSwJDnFctgvdBkEu)
 def dp_Event_List(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj,args):
  AKaLrfeOPzRIYxWSwJDnFctgvdBkMG=args.get('id')
  AKaLrfeOPzRIYxWSwJDnFctgvdBkMX=AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.Get_Event_List(AKaLrfeOPzRIYxWSwJDnFctgvdBkMG)
  for AKaLrfeOPzRIYxWSwJDnFctgvdBkMN in AKaLrfeOPzRIYxWSwJDnFctgvdBkMX:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXN =AKaLrfeOPzRIYxWSwJDnFctgvdBkMN.get('title')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkjh =AKaLrfeOPzRIYxWSwJDnFctgvdBkMN.get('id')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkMs =AKaLrfeOPzRIYxWSwJDnFctgvdBkMN.get('thumbnail')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkMo =AKaLrfeOPzRIYxWSwJDnFctgvdBkMN.get('asis') 
   AKaLrfeOPzRIYxWSwJDnFctgvdBkMb =AKaLrfeOPzRIYxWSwJDnFctgvdBkMN.get('duration')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkMT =AKaLrfeOPzRIYxWSwJDnFctgvdBkMN.get('starttm')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkME={'mediatype':'episode','title':AKaLrfeOPzRIYxWSwJDnFctgvdBkXN,'plot':AKaLrfeOPzRIYxWSwJDnFctgvdBkMo,'duration':AKaLrfeOPzRIYxWSwJDnFctgvdBkMb,}
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXo={'mode':AKaLrfeOPzRIYxWSwJDnFctgvdBkMo,'id':AKaLrfeOPzRIYxWSwJDnFctgvdBkjh,'asis':AKaLrfeOPzRIYxWSwJDnFctgvdBkMo,'title':AKaLrfeOPzRIYxWSwJDnFctgvdBkXN,}
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.add_dir(AKaLrfeOPzRIYxWSwJDnFctgvdBkXN,sublabel=AKaLrfeOPzRIYxWSwJDnFctgvdBkMT,img=AKaLrfeOPzRIYxWSwJDnFctgvdBkMs,infoLabels=AKaLrfeOPzRIYxWSwJDnFctgvdBkME,isFolder=AKaLrfeOPzRIYxWSwJDnFctgvdBkEu,params=AKaLrfeOPzRIYxWSwJDnFctgvdBkXo,ContextMenu=AKaLrfeOPzRIYxWSwJDnFctgvdBkEV)
  xbmcplugin.setContent(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj._addon_handle,cacheToDisc=AKaLrfeOPzRIYxWSwJDnFctgvdBkEu)
 def dp_Category_List(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj,args):
  AKaLrfeOPzRIYxWSwJDnFctgvdBkMp =args.get('vType') 
  AKaLrfeOPzRIYxWSwJDnFctgvdBkMy =args.get('collectionId')
  AKaLrfeOPzRIYxWSwJDnFctgvdBkMl =AKaLrfeOPzRIYxWSwJDnFctgvdBkji(args.get('page'))
  AKaLrfeOPzRIYxWSwJDnFctgvdBkMX,AKaLrfeOPzRIYxWSwJDnFctgvdBkMq=AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.Get_Category_List(AKaLrfeOPzRIYxWSwJDnFctgvdBkMp,AKaLrfeOPzRIYxWSwJDnFctgvdBkMy,AKaLrfeOPzRIYxWSwJDnFctgvdBkMl)
  for AKaLrfeOPzRIYxWSwJDnFctgvdBkMN in AKaLrfeOPzRIYxWSwJDnFctgvdBkMX:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXN =AKaLrfeOPzRIYxWSwJDnFctgvdBkMN.get('title')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkjh =AKaLrfeOPzRIYxWSwJDnFctgvdBkMN.get('id')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkMs =AKaLrfeOPzRIYxWSwJDnFctgvdBkMN.get('thumbnail')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkMm =AKaLrfeOPzRIYxWSwJDnFctgvdBkMN.get('mpaa')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkMb =AKaLrfeOPzRIYxWSwJDnFctgvdBkMN.get('duration')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkMo =AKaLrfeOPzRIYxWSwJDnFctgvdBkMN.get('asis')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkMU =AKaLrfeOPzRIYxWSwJDnFctgvdBkMN.get('badge')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkMQ =AKaLrfeOPzRIYxWSwJDnFctgvdBkMN.get('year')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkMC=AKaLrfeOPzRIYxWSwJDnFctgvdBkMN.get('seasonList')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkMH =AKaLrfeOPzRIYxWSwJDnFctgvdBkMN.get('genreList')
   if AKaLrfeOPzRIYxWSwJDnFctgvdBkMo in['TVSHOW','EDUCATION']: 
    AKaLrfeOPzRIYxWSwJDnFctgvdBkMV ='SEASON_LIST'
    AKaLrfeOPzRIYxWSwJDnFctgvdBkME={'mediatype':'tvshow','title':AKaLrfeOPzRIYxWSwJDnFctgvdBkXN,'mpaa':AKaLrfeOPzRIYxWSwJDnFctgvdBkMm,'genre':AKaLrfeOPzRIYxWSwJDnFctgvdBkMH,'year':AKaLrfeOPzRIYxWSwJDnFctgvdBkMQ,'plot':'Year : %s\nSeason : %s'%(AKaLrfeOPzRIYxWSwJDnFctgvdBkMQ,AKaLrfeOPzRIYxWSwJDnFctgvdBkMC),}
    AKaLrfeOPzRIYxWSwJDnFctgvdBkXh =AKaLrfeOPzRIYxWSwJDnFctgvdBkjp
   else:
    AKaLrfeOPzRIYxWSwJDnFctgvdBkMV ='MOVIE'
    AKaLrfeOPzRIYxWSwJDnFctgvdBkME={'mediatype':'movie','title':AKaLrfeOPzRIYxWSwJDnFctgvdBkXN,'mpaa':AKaLrfeOPzRIYxWSwJDnFctgvdBkMm,'genre':AKaLrfeOPzRIYxWSwJDnFctgvdBkMH,'duration':AKaLrfeOPzRIYxWSwJDnFctgvdBkMb,'year':AKaLrfeOPzRIYxWSwJDnFctgvdBkMQ,'plot':'(%s)'%(AKaLrfeOPzRIYxWSwJDnFctgvdBkMm),}
    AKaLrfeOPzRIYxWSwJDnFctgvdBkXh =AKaLrfeOPzRIYxWSwJDnFctgvdBkEu
    AKaLrfeOPzRIYxWSwJDnFctgvdBkXN +=' (%s)'%(AKaLrfeOPzRIYxWSwJDnFctgvdBkjo(AKaLrfeOPzRIYxWSwJDnFctgvdBkMQ))
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXo={'mode':AKaLrfeOPzRIYxWSwJDnFctgvdBkMV,'id':AKaLrfeOPzRIYxWSwJDnFctgvdBkjh,'asis':AKaLrfeOPzRIYxWSwJDnFctgvdBkMo,'seasonList':AKaLrfeOPzRIYxWSwJDnFctgvdBkMC,'title':AKaLrfeOPzRIYxWSwJDnFctgvdBkXN,'thumbnail':AKaLrfeOPzRIYxWSwJDnFctgvdBkMs,'year':AKaLrfeOPzRIYxWSwJDnFctgvdBkMQ,}
   if AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.get_settings_makebookmark():
    AKaLrfeOPzRIYxWSwJDnFctgvdBkMu={'videoid':AKaLrfeOPzRIYxWSwJDnFctgvdBkjh,'vidtype':'movie' if AKaLrfeOPzRIYxWSwJDnFctgvdBkMp=='MOVIES' else 'tvshow','vtitle':AKaLrfeOPzRIYxWSwJDnFctgvdBkXN,'vsubtitle':'',}
    AKaLrfeOPzRIYxWSwJDnFctgvdBkNp=json.dumps(AKaLrfeOPzRIYxWSwJDnFctgvdBkMu)
    AKaLrfeOPzRIYxWSwJDnFctgvdBkNp=urllib.parse.quote(AKaLrfeOPzRIYxWSwJDnFctgvdBkNp)
    AKaLrfeOPzRIYxWSwJDnFctgvdBkNX='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(AKaLrfeOPzRIYxWSwJDnFctgvdBkNp)
    AKaLrfeOPzRIYxWSwJDnFctgvdBkNM=[('(통합) 찜 영상에 추가',AKaLrfeOPzRIYxWSwJDnFctgvdBkNX)]
   else:
    AKaLrfeOPzRIYxWSwJDnFctgvdBkNM=AKaLrfeOPzRIYxWSwJDnFctgvdBkEV
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.add_dir(AKaLrfeOPzRIYxWSwJDnFctgvdBkXN,sublabel=AKaLrfeOPzRIYxWSwJDnFctgvdBkMU,img=AKaLrfeOPzRIYxWSwJDnFctgvdBkMs,infoLabels=AKaLrfeOPzRIYxWSwJDnFctgvdBkME,isFolder=AKaLrfeOPzRIYxWSwJDnFctgvdBkXh,params=AKaLrfeOPzRIYxWSwJDnFctgvdBkXo,ContextMenu=AKaLrfeOPzRIYxWSwJDnFctgvdBkNM)
  if AKaLrfeOPzRIYxWSwJDnFctgvdBkMq:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXo['mode'] ='CATEGORY_LIST' 
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXo['collectionId']=AKaLrfeOPzRIYxWSwJDnFctgvdBkMy 
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXo['vType'] =AKaLrfeOPzRIYxWSwJDnFctgvdBkMp 
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXo['page'] =AKaLrfeOPzRIYxWSwJDnFctgvdBkjo(AKaLrfeOPzRIYxWSwJDnFctgvdBkMl+1)
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXN='[B]%s >>[/B]'%'다음 페이지'
   AKaLrfeOPzRIYxWSwJDnFctgvdBkNi=AKaLrfeOPzRIYxWSwJDnFctgvdBkjo(AKaLrfeOPzRIYxWSwJDnFctgvdBkMl+1)
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXs=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.add_dir(AKaLrfeOPzRIYxWSwJDnFctgvdBkXN,sublabel=AKaLrfeOPzRIYxWSwJDnFctgvdBkNi,img=AKaLrfeOPzRIYxWSwJDnFctgvdBkXs,infoLabels=AKaLrfeOPzRIYxWSwJDnFctgvdBkEV,isFolder=AKaLrfeOPzRIYxWSwJDnFctgvdBkjp,params=AKaLrfeOPzRIYxWSwJDnFctgvdBkXo)
  if AKaLrfeOPzRIYxWSwJDnFctgvdBkMp=='TVSHOWS':xbmcplugin.setContent(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj._addon_handle,'tvshows')
  else:xbmcplugin.setContent(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj._addon_handle,'movies')
  xbmcplugin.endOfDirectory(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj._addon_handle,cacheToDisc=AKaLrfeOPzRIYxWSwJDnFctgvdBkEu)
 def dp_Season_List(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj,args):
  AKaLrfeOPzRIYxWSwJDnFctgvdBkNE =args.get('title')
  AKaLrfeOPzRIYxWSwJDnFctgvdBkNj =args.get('id')
  AKaLrfeOPzRIYxWSwJDnFctgvdBkMo =args.get('asis')
  AKaLrfeOPzRIYxWSwJDnFctgvdBkMC =args.get('seasonList')
  AKaLrfeOPzRIYxWSwJDnFctgvdBkMs =args.get('thumbnail')
  AKaLrfeOPzRIYxWSwJDnFctgvdBkMQ =args.get('year')
  if AKaLrfeOPzRIYxWSwJDnFctgvdBkMC in['',AKaLrfeOPzRIYxWSwJDnFctgvdBkEV]:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkMC=AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.Get_vInfo(AKaLrfeOPzRIYxWSwJDnFctgvdBkNj).get('seasonList')
  if AKaLrfeOPzRIYxWSwJDnFctgvdBkjT(AKaLrfeOPzRIYxWSwJDnFctgvdBkMC.split(','))>1:
   for AKaLrfeOPzRIYxWSwJDnFctgvdBkNy in AKaLrfeOPzRIYxWSwJDnFctgvdBkMC.split(','):
    AKaLrfeOPzRIYxWSwJDnFctgvdBkXN='시즌 '+AKaLrfeOPzRIYxWSwJDnFctgvdBkNy
    AKaLrfeOPzRIYxWSwJDnFctgvdBkME={'mediatype':'tvshow','plot':'%s (%s)'%(AKaLrfeOPzRIYxWSwJDnFctgvdBkNE,AKaLrfeOPzRIYxWSwJDnFctgvdBkMQ),}
    AKaLrfeOPzRIYxWSwJDnFctgvdBkXo={'mode':'EPISODE_LIST','programid':AKaLrfeOPzRIYxWSwJDnFctgvdBkNj,'programnm':AKaLrfeOPzRIYxWSwJDnFctgvdBkNE,'season':AKaLrfeOPzRIYxWSwJDnFctgvdBkNy,'asis':AKaLrfeOPzRIYxWSwJDnFctgvdBkMo,'programimg':AKaLrfeOPzRIYxWSwJDnFctgvdBkMs,}
    AKaLrfeOPzRIYxWSwJDnFctgvdBkNs=AKaLrfeOPzRIYxWSwJDnFctgvdBkMs.replace('\'','\"')
    AKaLrfeOPzRIYxWSwJDnFctgvdBkNs=json.loads(AKaLrfeOPzRIYxWSwJDnFctgvdBkNs)
    AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.add_dir(AKaLrfeOPzRIYxWSwJDnFctgvdBkXN,sublabel='',img=AKaLrfeOPzRIYxWSwJDnFctgvdBkNs,infoLabels=AKaLrfeOPzRIYxWSwJDnFctgvdBkME,isFolder=AKaLrfeOPzRIYxWSwJDnFctgvdBkjp,params=AKaLrfeOPzRIYxWSwJDnFctgvdBkXo)
   xbmcplugin.setContent(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj._addon_handle,cacheToDisc=AKaLrfeOPzRIYxWSwJDnFctgvdBkEu)
  else:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkNo={'programid':AKaLrfeOPzRIYxWSwJDnFctgvdBkNj,'programnm':AKaLrfeOPzRIYxWSwJDnFctgvdBkNE,'season':AKaLrfeOPzRIYxWSwJDnFctgvdBkMC,'programimg':AKaLrfeOPzRIYxWSwJDnFctgvdBkMs,}
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.dp_Episode_List(AKaLrfeOPzRIYxWSwJDnFctgvdBkNo)
 def dp_Episode_List(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj,args):
  AKaLrfeOPzRIYxWSwJDnFctgvdBkNj =args.get('programid')
  AKaLrfeOPzRIYxWSwJDnFctgvdBkNE =args.get('programnm')
  AKaLrfeOPzRIYxWSwJDnFctgvdBkNh =args.get('season')
  AKaLrfeOPzRIYxWSwJDnFctgvdBkNT =args.get('programimg')
  AKaLrfeOPzRIYxWSwJDnFctgvdBkNG=AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.Get_Episode_List(AKaLrfeOPzRIYxWSwJDnFctgvdBkNj,AKaLrfeOPzRIYxWSwJDnFctgvdBkNh)
  for AKaLrfeOPzRIYxWSwJDnFctgvdBkNy in AKaLrfeOPzRIYxWSwJDnFctgvdBkNG:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkNb =AKaLrfeOPzRIYxWSwJDnFctgvdBkNy.get('title')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkNl =AKaLrfeOPzRIYxWSwJDnFctgvdBkNy.get('id')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkMo =AKaLrfeOPzRIYxWSwJDnFctgvdBkNy.get('asis')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkMs =AKaLrfeOPzRIYxWSwJDnFctgvdBkNy.get('thumbnail')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkMm =AKaLrfeOPzRIYxWSwJDnFctgvdBkNy.get('mpaa')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkMb =AKaLrfeOPzRIYxWSwJDnFctgvdBkNy.get('duration')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkMQ =AKaLrfeOPzRIYxWSwJDnFctgvdBkNy.get('year')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkNq =AKaLrfeOPzRIYxWSwJDnFctgvdBkNy.get('episode')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkMH =AKaLrfeOPzRIYxWSwJDnFctgvdBkNy.get('genreList')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkNm =AKaLrfeOPzRIYxWSwJDnFctgvdBkNy.get('desc')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkNU ='%sx%s'%(AKaLrfeOPzRIYxWSwJDnFctgvdBkNh,AKaLrfeOPzRIYxWSwJDnFctgvdBkNq)
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXN ='%s. %s'%(AKaLrfeOPzRIYxWSwJDnFctgvdBkNU,AKaLrfeOPzRIYxWSwJDnFctgvdBkNb)
   AKaLrfeOPzRIYxWSwJDnFctgvdBkME={'mediatype':'episode','mpaa':AKaLrfeOPzRIYxWSwJDnFctgvdBkMm,'genre':AKaLrfeOPzRIYxWSwJDnFctgvdBkMH,'duration':AKaLrfeOPzRIYxWSwJDnFctgvdBkMb,'year':AKaLrfeOPzRIYxWSwJDnFctgvdBkMQ,'plot':'%s (%s)\n\n%s'%(AKaLrfeOPzRIYxWSwJDnFctgvdBkNE,AKaLrfeOPzRIYxWSwJDnFctgvdBkNU,AKaLrfeOPzRIYxWSwJDnFctgvdBkNm),}
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXo={'mode':'VOD','programid':AKaLrfeOPzRIYxWSwJDnFctgvdBkNj,'programnm':AKaLrfeOPzRIYxWSwJDnFctgvdBkNE,'title':AKaLrfeOPzRIYxWSwJDnFctgvdBkXN,'season':AKaLrfeOPzRIYxWSwJDnFctgvdBkNh,'id':AKaLrfeOPzRIYxWSwJDnFctgvdBkNl,'asis':AKaLrfeOPzRIYxWSwJDnFctgvdBkMo,'thumbnail':AKaLrfeOPzRIYxWSwJDnFctgvdBkMs,'programimg':AKaLrfeOPzRIYxWSwJDnFctgvdBkNT,}
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.add_dir(AKaLrfeOPzRIYxWSwJDnFctgvdBkXN,sublabel='',img=AKaLrfeOPzRIYxWSwJDnFctgvdBkMs,infoLabels=AKaLrfeOPzRIYxWSwJDnFctgvdBkME,isFolder=AKaLrfeOPzRIYxWSwJDnFctgvdBkEu,params=AKaLrfeOPzRIYxWSwJDnFctgvdBkXo)
  xbmcplugin.setContent(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj._addon_handle,cacheToDisc=AKaLrfeOPzRIYxWSwJDnFctgvdBkEu)
 def play_VIDEO(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj,args):
  AKaLrfeOPzRIYxWSwJDnFctgvdBkNQ =args.get('id')
  AKaLrfeOPzRIYxWSwJDnFctgvdBkMo =args.get('asis')
  if AKaLrfeOPzRIYxWSwJDnFctgvdBkMo in['HIGHLIGHT']:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkNC,AKaLrfeOPzRIYxWSwJDnFctgvdBkNH=AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.GetEventURL(AKaLrfeOPzRIYxWSwJDnFctgvdBkNQ,AKaLrfeOPzRIYxWSwJDnFctgvdBkMo)
  elif AKaLrfeOPzRIYxWSwJDnFctgvdBkMo in['LIVE']:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkNC,AKaLrfeOPzRIYxWSwJDnFctgvdBkNH=AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.GetEventURL_Live(AKaLrfeOPzRIYxWSwJDnFctgvdBkNQ,AKaLrfeOPzRIYxWSwJDnFctgvdBkMo)
  else:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkNC,AKaLrfeOPzRIYxWSwJDnFctgvdBkNH=AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.GetBroadURL(AKaLrfeOPzRIYxWSwJDnFctgvdBkNQ)
  AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.addon_log('asis, url : %s - %s - %s'%(AKaLrfeOPzRIYxWSwJDnFctgvdBkMo,AKaLrfeOPzRIYxWSwJDnFctgvdBkNQ,AKaLrfeOPzRIYxWSwJDnFctgvdBkNC))
  if AKaLrfeOPzRIYxWSwJDnFctgvdBkNC=='':
   if AKaLrfeOPzRIYxWSwJDnFctgvdBkNH=='':
    AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.addon_noti(__language__(30907).encode('utf8'))
   else:
    AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.addon_log('drm_license_1 : %s'%(AKaLrfeOPzRIYxWSwJDnFctgvdBkNH))
    AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.addon_noti(AKaLrfeOPzRIYxWSwJDnFctgvdBkNH)
   return
  else:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.addon_log('drm_license : %s'%(AKaLrfeOPzRIYxWSwJDnFctgvdBkNH))
  AKaLrfeOPzRIYxWSwJDnFctgvdBkNV='PCID=%s;token=%s;member_srl=%s;NEXT_LOCALE=%s;bm_mi=%s;ak_bmsc=%s;bm_sv=%s;session_web_id=%s;device_id=%s'%(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.CP['SESSION']['PCID'],AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.CP['SESSION']['token'],AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.CP['SESSION']['member_srl'],AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.CP['SESSION']['NEXT_LOCALE'],AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.CP['SESSION']['bm_mi'],AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.CP['SESSION']['ak_bmsc'],AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.CP['SESSION']['bm_sv'],AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.CP['SESSION']['session_web_id'],AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.CP['SESSION']['device_id'],)
  if AKaLrfeOPzRIYxWSwJDnFctgvdBkMo in['EPISODE']:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkNu='https://www.coupangplay.com/play/{}/episode?titleId={}&type=EPISODE&sourceType=page_discover_title_detail%3Apage_discover_feed'.format(AKaLrfeOPzRIYxWSwJDnFctgvdBkNQ,AKaLrfeOPzRIYxWSwJDnFctgvdBkNQ)
  elif AKaLrfeOPzRIYxWSwJDnFctgvdBkMo in['MOVIE']:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkNu='https://www.coupangplay.com/play/{}/movie?sourceType=page_discover_feed'.format(AKaLrfeOPzRIYxWSwJDnFctgvdBkNQ)
  else:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkNu='https://www.coupangplay.com/play/'+AKaLrfeOPzRIYxWSwJDnFctgvdBkNQ 
  AKaLrfeOPzRIYxWSwJDnFctgvdBkip,AKaLrfeOPzRIYxWSwJDnFctgvdBkiX,AKaLrfeOPzRIYxWSwJDnFctgvdBkiM=AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.Make_authHeader()
  AKaLrfeOPzRIYxWSwJDnFctgvdBkiN=AKaLrfeOPzRIYxWSwJDnFctgvdBkNC 
  AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.addon_log('tobe, surl : %s'%(AKaLrfeOPzRIYxWSwJDnFctgvdBkiN))
  AKaLrfeOPzRIYxWSwJDnFctgvdBkiE=xbmcgui.ListItem(path=AKaLrfeOPzRIYxWSwJDnFctgvdBkiN)
  AKaLrfeOPzRIYxWSwJDnFctgvdBkij=AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.Get_Url_PostFix(AKaLrfeOPzRIYxWSwJDnFctgvdBkNC) 
  AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.addon_log('post_fix : '+AKaLrfeOPzRIYxWSwJDnFctgvdBkij)
  if AKaLrfeOPzRIYxWSwJDnFctgvdBkij=='m3u8':
   AKaLrfeOPzRIYxWSwJDnFctgvdBkiy ='hls' 
  else:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkiy ='mpd' 
  if AKaLrfeOPzRIYxWSwJDnFctgvdBkNH:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkis =AKaLrfeOPzRIYxWSwJDnFctgvdBkNH 
   AKaLrfeOPzRIYxWSwJDnFctgvdBkio ='com.widevine.alpha'
   AKaLrfeOPzRIYxWSwJDnFctgvdBkih={'traceparent':AKaLrfeOPzRIYxWSwJDnFctgvdBkip,'tracestate':AKaLrfeOPzRIYxWSwJDnFctgvdBkiX,'newrelic':AKaLrfeOPzRIYxWSwJDnFctgvdBkiM,'User-Agent':AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.USER_AGENT,'Referer':AKaLrfeOPzRIYxWSwJDnFctgvdBkNu,'Cookie':AKaLrfeOPzRIYxWSwJDnFctgvdBkNV,}
   AKaLrfeOPzRIYxWSwJDnFctgvdBkiT=AKaLrfeOPzRIYxWSwJDnFctgvdBkis+'|'+urllib.parse.urlencode(AKaLrfeOPzRIYxWSwJDnFctgvdBkih)+'|R{SSM}|'
   AKaLrfeOPzRIYxWSwJDnFctgvdBkiE.setProperty('inputstream','inputstream.adaptive')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkiE.setProperty('inputstream.adaptive.manifest_type',AKaLrfeOPzRIYxWSwJDnFctgvdBkiy)
   AKaLrfeOPzRIYxWSwJDnFctgvdBkiE.setProperty('inputstream.adaptive.license_type',AKaLrfeOPzRIYxWSwJDnFctgvdBkio)
   AKaLrfeOPzRIYxWSwJDnFctgvdBkiE.setProperty('inputstream.adaptive.license_key',AKaLrfeOPzRIYxWSwJDnFctgvdBkiT)
   AKaLrfeOPzRIYxWSwJDnFctgvdBkiE.setProperty('inputstream.adaptive.stream_headers','User-Agent={}&Cookie={}&Referer={}&traceparent={}&tracestate={}&newrelic={}'.format(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.USER_AGENT,AKaLrfeOPzRIYxWSwJDnFctgvdBkNV,AKaLrfeOPzRIYxWSwJDnFctgvdBkNu,AKaLrfeOPzRIYxWSwJDnFctgvdBkip,AKaLrfeOPzRIYxWSwJDnFctgvdBkiX,AKaLrfeOPzRIYxWSwJDnFctgvdBkiM))
   AKaLrfeOPzRIYxWSwJDnFctgvdBkiE.setMimeType('application/dash+xml')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkiE.setContentLookup(AKaLrfeOPzRIYxWSwJDnFctgvdBkEu)
  else:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkiE.setContentLookup(AKaLrfeOPzRIYxWSwJDnFctgvdBkEu)
   AKaLrfeOPzRIYxWSwJDnFctgvdBkiE.setMimeType('application/x-mpegURL')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkiE.setProperty('inputstream','inputstream.adaptive')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkiE.setProperty('inputstream.adaptive.manifest_type',AKaLrfeOPzRIYxWSwJDnFctgvdBkiy)
   AKaLrfeOPzRIYxWSwJDnFctgvdBkiE.setProperty('inputstream.adaptive.stream_headers','User-Agent={}&Cookie={}&Referer={}&traceparent={}&tracestate={}&newrelic={}'.format(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.USER_AGENT,AKaLrfeOPzRIYxWSwJDnFctgvdBkNV,AKaLrfeOPzRIYxWSwJDnFctgvdBkNu,AKaLrfeOPzRIYxWSwJDnFctgvdBkip,AKaLrfeOPzRIYxWSwJDnFctgvdBkiX,AKaLrfeOPzRIYxWSwJDnFctgvdBkiM))
  xbmcplugin.setResolvedUrl(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj._addon_handle,AKaLrfeOPzRIYxWSwJDnFctgvdBkjp,AKaLrfeOPzRIYxWSwJDnFctgvdBkiE)
  try:
   if AKaLrfeOPzRIYxWSwJDnFctgvdBkMo=='MOVIE':
    AKaLrfeOPzRIYxWSwJDnFctgvdBkiG='movie'
    AKaLrfeOPzRIYxWSwJDnFctgvdBkXo={'code':AKaLrfeOPzRIYxWSwJDnFctgvdBkNQ,'asis':AKaLrfeOPzRIYxWSwJDnFctgvdBkMo,'title':args.get('title'),'img':args.get('thumbnail'),}
    AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.Save_Watched_List(AKaLrfeOPzRIYxWSwJDnFctgvdBkiG,AKaLrfeOPzRIYxWSwJDnFctgvdBkXo)
   elif AKaLrfeOPzRIYxWSwJDnFctgvdBkMo=='TVSHOW':
    AKaLrfeOPzRIYxWSwJDnFctgvdBkiG='tvshow'
    AKaLrfeOPzRIYxWSwJDnFctgvdBkXo={'code':args.get('programid'),'asis':AKaLrfeOPzRIYxWSwJDnFctgvdBkMo,'title':'%s <%s>'%(args.get('title'),args.get('programnm')),'img':args.get('programimg'),}
    AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.Save_Watched_List(AKaLrfeOPzRIYxWSwJDnFctgvdBkiG,AKaLrfeOPzRIYxWSwJDnFctgvdBkXo)
  except:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkEV
 def dp_Global_Search(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj,args):
  AKaLrfeOPzRIYxWSwJDnFctgvdBkMV=args.get('mode')
  if AKaLrfeOPzRIYxWSwJDnFctgvdBkMV=='TOTAL_SEARCH':
   AKaLrfeOPzRIYxWSwJDnFctgvdBkib='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkib='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(AKaLrfeOPzRIYxWSwJDnFctgvdBkib)
 def dp_Bookmark_Menu(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj,args):
  AKaLrfeOPzRIYxWSwJDnFctgvdBkib='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(AKaLrfeOPzRIYxWSwJDnFctgvdBkib)
 def dp_Search_List(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj,args):
  AKaLrfeOPzRIYxWSwJDnFctgvdBkMl =AKaLrfeOPzRIYxWSwJDnFctgvdBkji(args.get('page'))
  if 'search_key' in args:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkil=args.get('search_key')
  else:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkil=AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.get_keyboard_input(__language__(30908).encode('utf-8'))
   if not AKaLrfeOPzRIYxWSwJDnFctgvdBkil:
    return
  AKaLrfeOPzRIYxWSwJDnFctgvdBkiq,AKaLrfeOPzRIYxWSwJDnFctgvdBkMq=AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.Get_Search_List(AKaLrfeOPzRIYxWSwJDnFctgvdBkil,AKaLrfeOPzRIYxWSwJDnFctgvdBkMl)
  for AKaLrfeOPzRIYxWSwJDnFctgvdBkim in AKaLrfeOPzRIYxWSwJDnFctgvdBkiq:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkjh =AKaLrfeOPzRIYxWSwJDnFctgvdBkim.get('id')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXN =AKaLrfeOPzRIYxWSwJDnFctgvdBkim.get('title')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkMo =AKaLrfeOPzRIYxWSwJDnFctgvdBkim.get('asis')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkMs =AKaLrfeOPzRIYxWSwJDnFctgvdBkim.get('thumbnail')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkMm =AKaLrfeOPzRIYxWSwJDnFctgvdBkim.get('mpaa')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkMQ =AKaLrfeOPzRIYxWSwJDnFctgvdBkim.get('year')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkMb =AKaLrfeOPzRIYxWSwJDnFctgvdBkim.get('duration')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkMU =AKaLrfeOPzRIYxWSwJDnFctgvdBkim.get('badge')
   if AKaLrfeOPzRIYxWSwJDnFctgvdBkMo=='TVSHOW': 
    AKaLrfeOPzRIYxWSwJDnFctgvdBkMV ='SEASON_LIST'
    AKaLrfeOPzRIYxWSwJDnFctgvdBkME={'mediatype':'tvshow','title':AKaLrfeOPzRIYxWSwJDnFctgvdBkXN,'mpaa':AKaLrfeOPzRIYxWSwJDnFctgvdBkMm,'year':AKaLrfeOPzRIYxWSwJDnFctgvdBkMQ,'plot':'Year : %s'%(AKaLrfeOPzRIYxWSwJDnFctgvdBkMQ),}
    AKaLrfeOPzRIYxWSwJDnFctgvdBkXh =AKaLrfeOPzRIYxWSwJDnFctgvdBkjp
   elif AKaLrfeOPzRIYxWSwJDnFctgvdBkMo=='MOVIE':
    AKaLrfeOPzRIYxWSwJDnFctgvdBkMV ='MOVIE'
    AKaLrfeOPzRIYxWSwJDnFctgvdBkME={'mediatype':'movie','title':AKaLrfeOPzRIYxWSwJDnFctgvdBkXN,'mpaa':AKaLrfeOPzRIYxWSwJDnFctgvdBkMm,'duration':AKaLrfeOPzRIYxWSwJDnFctgvdBkMb,'year':AKaLrfeOPzRIYxWSwJDnFctgvdBkMQ,'plot':'(%s)'%(AKaLrfeOPzRIYxWSwJDnFctgvdBkMm),}
    AKaLrfeOPzRIYxWSwJDnFctgvdBkXh =AKaLrfeOPzRIYxWSwJDnFctgvdBkEu
    AKaLrfeOPzRIYxWSwJDnFctgvdBkXN +=' (%s)'%(AKaLrfeOPzRIYxWSwJDnFctgvdBkjo(AKaLrfeOPzRIYxWSwJDnFctgvdBkMQ))
   elif AKaLrfeOPzRIYxWSwJDnFctgvdBkMo=='HIGHLIGHT':
    AKaLrfeOPzRIYxWSwJDnFctgvdBkMV ='HIGHLIGHT'
    AKaLrfeOPzRIYxWSwJDnFctgvdBkME={'mediatype':'episode','title':AKaLrfeOPzRIYxWSwJDnFctgvdBkXN,'duration':AKaLrfeOPzRIYxWSwJDnFctgvdBkMb,'plot':AKaLrfeOPzRIYxWSwJDnFctgvdBkMV,}
    AKaLrfeOPzRIYxWSwJDnFctgvdBkXh =AKaLrfeOPzRIYxWSwJDnFctgvdBkEu
   elif AKaLrfeOPzRIYxWSwJDnFctgvdBkMo=='LIVE':
    AKaLrfeOPzRIYxWSwJDnFctgvdBkMV ='LIVE'
    AKaLrfeOPzRIYxWSwJDnFctgvdBkME={'mediatype':'episode','title':AKaLrfeOPzRIYxWSwJDnFctgvdBkXN,'plot':AKaLrfeOPzRIYxWSwJDnFctgvdBkMV,}
    AKaLrfeOPzRIYxWSwJDnFctgvdBkXh =AKaLrfeOPzRIYxWSwJDnFctgvdBkEu
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXo={'mode':AKaLrfeOPzRIYxWSwJDnFctgvdBkMV,'id':AKaLrfeOPzRIYxWSwJDnFctgvdBkjh,'asis':AKaLrfeOPzRIYxWSwJDnFctgvdBkMo,'seasonList':'','title':AKaLrfeOPzRIYxWSwJDnFctgvdBkXN,'thumbnail':json.dumps(AKaLrfeOPzRIYxWSwJDnFctgvdBkMs,separators=(',',':')),'year':AKaLrfeOPzRIYxWSwJDnFctgvdBkMQ,}
   if AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.get_settings_makebookmark()and AKaLrfeOPzRIYxWSwJDnFctgvdBkMo not in['HIGHLIGHT','']:
    AKaLrfeOPzRIYxWSwJDnFctgvdBkMu={'videoid':AKaLrfeOPzRIYxWSwJDnFctgvdBkjh,'vidtype':'movie' if AKaLrfeOPzRIYxWSwJDnFctgvdBkMo=='MOVIE' else 'tvshow','vtitle':AKaLrfeOPzRIYxWSwJDnFctgvdBkXN,'vsubtitle':'',}
    AKaLrfeOPzRIYxWSwJDnFctgvdBkNp=json.dumps(AKaLrfeOPzRIYxWSwJDnFctgvdBkMu)
    AKaLrfeOPzRIYxWSwJDnFctgvdBkNp=urllib.parse.quote(AKaLrfeOPzRIYxWSwJDnFctgvdBkNp)
    AKaLrfeOPzRIYxWSwJDnFctgvdBkNX='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(AKaLrfeOPzRIYxWSwJDnFctgvdBkNp)
    AKaLrfeOPzRIYxWSwJDnFctgvdBkNM=[('(통합) 찜 영상에 추가',AKaLrfeOPzRIYxWSwJDnFctgvdBkNX)]
   else:
    AKaLrfeOPzRIYxWSwJDnFctgvdBkNM=AKaLrfeOPzRIYxWSwJDnFctgvdBkEV
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.add_dir(AKaLrfeOPzRIYxWSwJDnFctgvdBkXN,sublabel=AKaLrfeOPzRIYxWSwJDnFctgvdBkMU,img=AKaLrfeOPzRIYxWSwJDnFctgvdBkMs,infoLabels=AKaLrfeOPzRIYxWSwJDnFctgvdBkME,isFolder=AKaLrfeOPzRIYxWSwJDnFctgvdBkXh,params=AKaLrfeOPzRIYxWSwJDnFctgvdBkXo,ContextMenu=AKaLrfeOPzRIYxWSwJDnFctgvdBkNM)
  if AKaLrfeOPzRIYxWSwJDnFctgvdBkMq:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXo={}
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXo['mode'] ='LOCAL_SEARCH'
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXo['search_key']=AKaLrfeOPzRIYxWSwJDnFctgvdBkil
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXo['page'] =AKaLrfeOPzRIYxWSwJDnFctgvdBkjo(AKaLrfeOPzRIYxWSwJDnFctgvdBkMl+1)
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXN='[B]%s >>[/B]'%'다음 페이지'
   AKaLrfeOPzRIYxWSwJDnFctgvdBkNi=AKaLrfeOPzRIYxWSwJDnFctgvdBkjo(AKaLrfeOPzRIYxWSwJDnFctgvdBkMl+1)
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXs=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.add_dir(AKaLrfeOPzRIYxWSwJDnFctgvdBkXN,sublabel=AKaLrfeOPzRIYxWSwJDnFctgvdBkNi,img=AKaLrfeOPzRIYxWSwJDnFctgvdBkXs,infoLabels=AKaLrfeOPzRIYxWSwJDnFctgvdBkEV,isFolder=AKaLrfeOPzRIYxWSwJDnFctgvdBkjp,params=AKaLrfeOPzRIYxWSwJDnFctgvdBkXo)
  xbmcplugin.setContent(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj._addon_handle,'movies')
  xbmcplugin.endOfDirectory(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj._addon_handle,cacheToDisc=AKaLrfeOPzRIYxWSwJDnFctgvdBkjp)
  if args.get('historyyn')=='Y':AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.Save_Searched_List(AKaLrfeOPzRIYxWSwJDnFctgvdBkil)
 def Load_List_File(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj,AKaLrfeOPzRIYxWSwJDnFctgvdBkiG): 
  try:
   if AKaLrfeOPzRIYxWSwJDnFctgvdBkiG=='search':
    AKaLrfeOPzRIYxWSwJDnFctgvdBkiU=AKaLrfeOPzRIYxWSwJDnFctgvdBkpE
   elif AKaLrfeOPzRIYxWSwJDnFctgvdBkiG in['tvshow','movie']:
    AKaLrfeOPzRIYxWSwJDnFctgvdBkiU=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%AKaLrfeOPzRIYxWSwJDnFctgvdBkiG))
   else:
    return[]
   fp=AKaLrfeOPzRIYxWSwJDnFctgvdBkjy(AKaLrfeOPzRIYxWSwJDnFctgvdBkiU,'r',-1,'utf-8')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkiQ=fp.readlines()
   fp.close()
  except:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkiQ=[]
  return AKaLrfeOPzRIYxWSwJDnFctgvdBkiQ
 def Save_Watched_List(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj,AKaLrfeOPzRIYxWSwJDnFctgvdBkiG,AKaLrfeOPzRIYxWSwJDnFctgvdBkpo):
  try:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkiC=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%AKaLrfeOPzRIYxWSwJDnFctgvdBkiG))
   AKaLrfeOPzRIYxWSwJDnFctgvdBkiH=AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.Load_List_File(AKaLrfeOPzRIYxWSwJDnFctgvdBkiG) 
   fp=AKaLrfeOPzRIYxWSwJDnFctgvdBkjy(AKaLrfeOPzRIYxWSwJDnFctgvdBkiC,'w',-1,'utf-8')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkiV=urllib.parse.urlencode(AKaLrfeOPzRIYxWSwJDnFctgvdBkpo)
   AKaLrfeOPzRIYxWSwJDnFctgvdBkiV=AKaLrfeOPzRIYxWSwJDnFctgvdBkiV+'\n'
   fp.write(AKaLrfeOPzRIYxWSwJDnFctgvdBkiV)
   AKaLrfeOPzRIYxWSwJDnFctgvdBkiu=0
   for AKaLrfeOPzRIYxWSwJDnFctgvdBkEp in AKaLrfeOPzRIYxWSwJDnFctgvdBkiH:
    AKaLrfeOPzRIYxWSwJDnFctgvdBkEX=AKaLrfeOPzRIYxWSwJDnFctgvdBkjM(urllib.parse.parse_qsl(AKaLrfeOPzRIYxWSwJDnFctgvdBkEp))
    AKaLrfeOPzRIYxWSwJDnFctgvdBkEM=AKaLrfeOPzRIYxWSwJDnFctgvdBkpo.get('code').strip()
    AKaLrfeOPzRIYxWSwJDnFctgvdBkEN=AKaLrfeOPzRIYxWSwJDnFctgvdBkEX.get('code').strip()
    if AKaLrfeOPzRIYxWSwJDnFctgvdBkEM!=AKaLrfeOPzRIYxWSwJDnFctgvdBkEN:
     fp.write(AKaLrfeOPzRIYxWSwJDnFctgvdBkEp)
     AKaLrfeOPzRIYxWSwJDnFctgvdBkiu+=1
     if AKaLrfeOPzRIYxWSwJDnFctgvdBkiu>=50:break
   fp.close()
  except:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkEV
 def Save_Searched_List(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj,AKaLrfeOPzRIYxWSwJDnFctgvdBkil):
  try:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkil=AKaLrfeOPzRIYxWSwJDnFctgvdBkil.strip()
   AKaLrfeOPzRIYxWSwJDnFctgvdBkiH=AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.Load_List_File('search') 
   fp=AKaLrfeOPzRIYxWSwJDnFctgvdBkjy(AKaLrfeOPzRIYxWSwJDnFctgvdBkpE,'w',-1,'utf-8')
   fp.write(AKaLrfeOPzRIYxWSwJDnFctgvdBkil+'\n')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkiu=0
   for AKaLrfeOPzRIYxWSwJDnFctgvdBkEp in AKaLrfeOPzRIYxWSwJDnFctgvdBkiH:
    AKaLrfeOPzRIYxWSwJDnFctgvdBkEp=AKaLrfeOPzRIYxWSwJDnFctgvdBkEp.strip()
    if AKaLrfeOPzRIYxWSwJDnFctgvdBkil!=AKaLrfeOPzRIYxWSwJDnFctgvdBkEp:
     fp.write(AKaLrfeOPzRIYxWSwJDnFctgvdBkEp+'\n')
     AKaLrfeOPzRIYxWSwJDnFctgvdBkiu+=1
     if AKaLrfeOPzRIYxWSwJDnFctgvdBkiu>=50:break
   fp.close()
  except:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkEV
 def dp_Search_History(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj,args):
  AKaLrfeOPzRIYxWSwJDnFctgvdBkEi=AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.Load_List_File('search')
  for AKaLrfeOPzRIYxWSwJDnFctgvdBkEj in AKaLrfeOPzRIYxWSwJDnFctgvdBkEi:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkEj=AKaLrfeOPzRIYxWSwJDnFctgvdBkEj.strip()
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXo={'mode':'LOCAL_SEARCH','search_key':AKaLrfeOPzRIYxWSwJDnFctgvdBkEj,'page':'1','historyyn':'Y',}
   AKaLrfeOPzRIYxWSwJDnFctgvdBkEy={'mode':'SEARCH_REMOVE','stype':'ONE','skey':AKaLrfeOPzRIYxWSwJDnFctgvdBkEj,}
   AKaLrfeOPzRIYxWSwJDnFctgvdBkEs=urllib.parse.urlencode(AKaLrfeOPzRIYxWSwJDnFctgvdBkEy)
   AKaLrfeOPzRIYxWSwJDnFctgvdBkNM=[('선택된 검색어 ( %s ) 삭제'%(AKaLrfeOPzRIYxWSwJDnFctgvdBkEj),'RunPlugin(plugin://plugin.video.coupangm/?%s)'%(AKaLrfeOPzRIYxWSwJDnFctgvdBkEs))]
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.add_dir(AKaLrfeOPzRIYxWSwJDnFctgvdBkEj,sublabel='',img=AKaLrfeOPzRIYxWSwJDnFctgvdBkEV,infoLabels=AKaLrfeOPzRIYxWSwJDnFctgvdBkEV,isFolder=AKaLrfeOPzRIYxWSwJDnFctgvdBkjp,params=AKaLrfeOPzRIYxWSwJDnFctgvdBkXo,ContextMenu=AKaLrfeOPzRIYxWSwJDnFctgvdBkNM)
  AKaLrfeOPzRIYxWSwJDnFctgvdBkME={'plot':'검색목록 전체를 삭제합니다.'}
  AKaLrfeOPzRIYxWSwJDnFctgvdBkXN='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  AKaLrfeOPzRIYxWSwJDnFctgvdBkXo={'mode':'SEARCH_REMOVE','stype':'ALL','skey':'-',}
  AKaLrfeOPzRIYxWSwJDnFctgvdBkXs=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.add_dir(AKaLrfeOPzRIYxWSwJDnFctgvdBkXN,sublabel='',img=AKaLrfeOPzRIYxWSwJDnFctgvdBkXs,infoLabels=AKaLrfeOPzRIYxWSwJDnFctgvdBkME,isFolder=AKaLrfeOPzRIYxWSwJDnFctgvdBkEu,params=AKaLrfeOPzRIYxWSwJDnFctgvdBkXo,isLink=AKaLrfeOPzRIYxWSwJDnFctgvdBkjp)
  xbmcplugin.endOfDirectory(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj._addon_handle,cacheToDisc=AKaLrfeOPzRIYxWSwJDnFctgvdBkEu)
 def dp_Listfile_Delete(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj,args):
  AKaLrfeOPzRIYxWSwJDnFctgvdBkiG=args.get('stype')
  AKaLrfeOPzRIYxWSwJDnFctgvdBkEo =args.get('skey')
  AKaLrfeOPzRIYxWSwJDnFctgvdBkpT=xbmcgui.Dialog()
  if AKaLrfeOPzRIYxWSwJDnFctgvdBkiG=='ALL':
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXl=AKaLrfeOPzRIYxWSwJDnFctgvdBkpT.yesno(__language__(30911).encode('utf8'),__language__(30906).encode('utf8'))
  elif AKaLrfeOPzRIYxWSwJDnFctgvdBkiG=='ONE':
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXl=AKaLrfeOPzRIYxWSwJDnFctgvdBkpT.yesno(__language__(30912).encode('utf8'),__language__(30906).encode('utf8'))
  elif AKaLrfeOPzRIYxWSwJDnFctgvdBkiG in['tvshow','movie']:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXl=AKaLrfeOPzRIYxWSwJDnFctgvdBkpT.yesno(__language__(30913).encode('utf8'),__language__(30906).encode('utf8'))
  if AKaLrfeOPzRIYxWSwJDnFctgvdBkXl==AKaLrfeOPzRIYxWSwJDnFctgvdBkEu:sys.exit()
  AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.Delete_List_File(AKaLrfeOPzRIYxWSwJDnFctgvdBkiG,skey=AKaLrfeOPzRIYxWSwJDnFctgvdBkEo)
  xbmc.executebuiltin("Container.Refresh")
 def Delete_List_File(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj,AKaLrfeOPzRIYxWSwJDnFctgvdBkiG,skey='-'):
  if AKaLrfeOPzRIYxWSwJDnFctgvdBkiG=='ALL':
   try:
    AKaLrfeOPzRIYxWSwJDnFctgvdBkiU=AKaLrfeOPzRIYxWSwJDnFctgvdBkpE
    fp=AKaLrfeOPzRIYxWSwJDnFctgvdBkjy(AKaLrfeOPzRIYxWSwJDnFctgvdBkiU,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    AKaLrfeOPzRIYxWSwJDnFctgvdBkEV
  elif AKaLrfeOPzRIYxWSwJDnFctgvdBkiG=='ONE':
   try:
    AKaLrfeOPzRIYxWSwJDnFctgvdBkiU=AKaLrfeOPzRIYxWSwJDnFctgvdBkpE
    AKaLrfeOPzRIYxWSwJDnFctgvdBkiH=AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.Load_List_File('search') 
    fp=AKaLrfeOPzRIYxWSwJDnFctgvdBkjy(AKaLrfeOPzRIYxWSwJDnFctgvdBkiU,'w',-1,'utf-8')
    for AKaLrfeOPzRIYxWSwJDnFctgvdBkEp in AKaLrfeOPzRIYxWSwJDnFctgvdBkiH:
     if skey!=AKaLrfeOPzRIYxWSwJDnFctgvdBkEp.strip():
      fp.write(AKaLrfeOPzRIYxWSwJDnFctgvdBkEp)
    fp.close()
   except:
    AKaLrfeOPzRIYxWSwJDnFctgvdBkEV
  elif AKaLrfeOPzRIYxWSwJDnFctgvdBkiG in['tvshow','movie']:
   try:
    AKaLrfeOPzRIYxWSwJDnFctgvdBkiU=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%AKaLrfeOPzRIYxWSwJDnFctgvdBkiG))
    fp=AKaLrfeOPzRIYxWSwJDnFctgvdBkjy(AKaLrfeOPzRIYxWSwJDnFctgvdBkiU,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    AKaLrfeOPzRIYxWSwJDnFctgvdBkEV
 def dp_Watch_List(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj,args):
  AKaLrfeOPzRIYxWSwJDnFctgvdBkiG =args.get('stype')
  if AKaLrfeOPzRIYxWSwJDnFctgvdBkiG in['',AKaLrfeOPzRIYxWSwJDnFctgvdBkEV]:
   for AKaLrfeOPzRIYxWSwJDnFctgvdBkEh in AKaLrfeOPzRIYxWSwJDnFctgvdBkpN:
    AKaLrfeOPzRIYxWSwJDnFctgvdBkXN=AKaLrfeOPzRIYxWSwJDnFctgvdBkEh.get('title')
    AKaLrfeOPzRIYxWSwJDnFctgvdBkXo={'mode':AKaLrfeOPzRIYxWSwJDnFctgvdBkEh.get('mode'),'stype':AKaLrfeOPzRIYxWSwJDnFctgvdBkEh.get('stype'),}
    AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.add_dir(AKaLrfeOPzRIYxWSwJDnFctgvdBkXN,sublabel='',img='',infoLabels=AKaLrfeOPzRIYxWSwJDnFctgvdBkEV,isFolder=AKaLrfeOPzRIYxWSwJDnFctgvdBkjp,params=AKaLrfeOPzRIYxWSwJDnFctgvdBkXo)
   xbmcplugin.endOfDirectory(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj._addon_handle)
  else:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkET=AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.Load_List_File(AKaLrfeOPzRIYxWSwJDnFctgvdBkiG)
   for AKaLrfeOPzRIYxWSwJDnFctgvdBkEG in AKaLrfeOPzRIYxWSwJDnFctgvdBkET:
    AKaLrfeOPzRIYxWSwJDnFctgvdBkEb=AKaLrfeOPzRIYxWSwJDnFctgvdBkjM(urllib.parse.parse_qsl(AKaLrfeOPzRIYxWSwJDnFctgvdBkEG))
    AKaLrfeOPzRIYxWSwJDnFctgvdBkNQ =AKaLrfeOPzRIYxWSwJDnFctgvdBkEb.get('code').strip()
    AKaLrfeOPzRIYxWSwJDnFctgvdBkXN =AKaLrfeOPzRIYxWSwJDnFctgvdBkEb.get('title').strip()
    AKaLrfeOPzRIYxWSwJDnFctgvdBkMs =AKaLrfeOPzRIYxWSwJDnFctgvdBkEb.get('img').strip()
    AKaLrfeOPzRIYxWSwJDnFctgvdBkMo =AKaLrfeOPzRIYxWSwJDnFctgvdBkEb.get('asis').strip()
    try:
     AKaLrfeOPzRIYxWSwJDnFctgvdBkMs=AKaLrfeOPzRIYxWSwJDnFctgvdBkMs.replace('\'','\"')
     AKaLrfeOPzRIYxWSwJDnFctgvdBkMs=json.loads(AKaLrfeOPzRIYxWSwJDnFctgvdBkMs)
    except:
     AKaLrfeOPzRIYxWSwJDnFctgvdBkEV
    AKaLrfeOPzRIYxWSwJDnFctgvdBkME={}
    AKaLrfeOPzRIYxWSwJDnFctgvdBkME['plot']=AKaLrfeOPzRIYxWSwJDnFctgvdBkXN
    if AKaLrfeOPzRIYxWSwJDnFctgvdBkiG=='movie':
     AKaLrfeOPzRIYxWSwJDnFctgvdBkME['mediatype']='movie'
     AKaLrfeOPzRIYxWSwJDnFctgvdBkXo={'mode':'MOVIE','id':AKaLrfeOPzRIYxWSwJDnFctgvdBkNQ,'asis':AKaLrfeOPzRIYxWSwJDnFctgvdBkMo,'title':AKaLrfeOPzRIYxWSwJDnFctgvdBkXN,'thumbnail':AKaLrfeOPzRIYxWSwJDnFctgvdBkMs,}
     AKaLrfeOPzRIYxWSwJDnFctgvdBkXh=AKaLrfeOPzRIYxWSwJDnFctgvdBkEu
    else:
     AKaLrfeOPzRIYxWSwJDnFctgvdBkME['mediatype']='episode'
     AKaLrfeOPzRIYxWSwJDnFctgvdBkXo={'mode':'SEASON_LIST','id':AKaLrfeOPzRIYxWSwJDnFctgvdBkNQ,'asis':AKaLrfeOPzRIYxWSwJDnFctgvdBkMo,'title':AKaLrfeOPzRIYxWSwJDnFctgvdBkXN,'thumbnail':json.dumps(AKaLrfeOPzRIYxWSwJDnFctgvdBkMs,separators=(',',':')),}
     AKaLrfeOPzRIYxWSwJDnFctgvdBkXh=AKaLrfeOPzRIYxWSwJDnFctgvdBkjp
    AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.add_dir(AKaLrfeOPzRIYxWSwJDnFctgvdBkXN,sublabel='',img=AKaLrfeOPzRIYxWSwJDnFctgvdBkMs,infoLabels=AKaLrfeOPzRIYxWSwJDnFctgvdBkME,isFolder=AKaLrfeOPzRIYxWSwJDnFctgvdBkXh,params=AKaLrfeOPzRIYxWSwJDnFctgvdBkXo)
   AKaLrfeOPzRIYxWSwJDnFctgvdBkME={'plot':'시청목록을 삭제합니다.'}
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXN='*** 시청목록 삭제 ***'
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXo={'mode':'MYVIEW_REMOVE','stype':AKaLrfeOPzRIYxWSwJDnFctgvdBkiG,'skey':'-',}
   AKaLrfeOPzRIYxWSwJDnFctgvdBkXs=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.add_dir(AKaLrfeOPzRIYxWSwJDnFctgvdBkXN,sublabel='',img=AKaLrfeOPzRIYxWSwJDnFctgvdBkXs,infoLabels=AKaLrfeOPzRIYxWSwJDnFctgvdBkME,isFolder=AKaLrfeOPzRIYxWSwJDnFctgvdBkEu,params=AKaLrfeOPzRIYxWSwJDnFctgvdBkXo,isLink=AKaLrfeOPzRIYxWSwJDnFctgvdBkjp)
   if AKaLrfeOPzRIYxWSwJDnFctgvdBkiG=='movie':xbmcplugin.setContent(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj._addon_handle,'movies')
   else:xbmcplugin.setContent(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj._addon_handle,cacheToDisc=AKaLrfeOPzRIYxWSwJDnFctgvdBkEu)
 def dp_Set_Bookmark(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj,args):
  AKaLrfeOPzRIYxWSwJDnFctgvdBkEl=urllib.parse.unquote(args.get('bm_param'))
  AKaLrfeOPzRIYxWSwJDnFctgvdBkEl=json.loads(AKaLrfeOPzRIYxWSwJDnFctgvdBkEl)
  AKaLrfeOPzRIYxWSwJDnFctgvdBkEq =AKaLrfeOPzRIYxWSwJDnFctgvdBkEl.get('videoid')
  AKaLrfeOPzRIYxWSwJDnFctgvdBkEm =AKaLrfeOPzRIYxWSwJDnFctgvdBkEl.get('vidtype')
  AKaLrfeOPzRIYxWSwJDnFctgvdBkEU =AKaLrfeOPzRIYxWSwJDnFctgvdBkEl.get('vtitle')
  AKaLrfeOPzRIYxWSwJDnFctgvdBkpT=xbmcgui.Dialog()
  AKaLrfeOPzRIYxWSwJDnFctgvdBkXl=AKaLrfeOPzRIYxWSwJDnFctgvdBkpT.yesno(__language__(30914).encode('utf8'),AKaLrfeOPzRIYxWSwJDnFctgvdBkEU+' \n\n'+__language__(30915))
  if AKaLrfeOPzRIYxWSwJDnFctgvdBkXl==AKaLrfeOPzRIYxWSwJDnFctgvdBkEu:return
  AKaLrfeOPzRIYxWSwJDnFctgvdBkEQ=AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.GetBookmarkInfo(AKaLrfeOPzRIYxWSwJDnFctgvdBkEq,AKaLrfeOPzRIYxWSwJDnFctgvdBkEm)
  AKaLrfeOPzRIYxWSwJDnFctgvdBkEC=json.dumps(AKaLrfeOPzRIYxWSwJDnFctgvdBkEQ)
  AKaLrfeOPzRIYxWSwJDnFctgvdBkEC=urllib.parse.quote(AKaLrfeOPzRIYxWSwJDnFctgvdBkEC)
  AKaLrfeOPzRIYxWSwJDnFctgvdBkNX ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(AKaLrfeOPzRIYxWSwJDnFctgvdBkEC)
  xbmc.executebuiltin(AKaLrfeOPzRIYxWSwJDnFctgvdBkNX)
 def coupang_main(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj):
  AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CoupangObj.KodiVersion=AKaLrfeOPzRIYxWSwJDnFctgvdBkji(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  AKaLrfeOPzRIYxWSwJDnFctgvdBkMV=AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.main_params.get('mode',AKaLrfeOPzRIYxWSwJDnFctgvdBkEV)
  if AKaLrfeOPzRIYxWSwJDnFctgvdBkMV=='LOGOUT':
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.CP_logout()
   return
  AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.option_check()
  if AKaLrfeOPzRIYxWSwJDnFctgvdBkMV is AKaLrfeOPzRIYxWSwJDnFctgvdBkEV:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.dp_Main_List(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.main_params)
  elif AKaLrfeOPzRIYxWSwJDnFctgvdBkMV=='CATEGORY_GROUPLIST':
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.dp_Category_GroupList(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.main_params)
  elif AKaLrfeOPzRIYxWSwJDnFctgvdBkMV=='THEME_GROUPLIST':
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.dp_Theme_GroupList(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.main_params)
  elif AKaLrfeOPzRIYxWSwJDnFctgvdBkMV=='EVENT_GROUPLIST':
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.dp_Event_GroupList(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.main_params)
  elif AKaLrfeOPzRIYxWSwJDnFctgvdBkMV=='EVENT_GAMELIST':
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.dp_Event_GameList(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.main_params)
  elif AKaLrfeOPzRIYxWSwJDnFctgvdBkMV=='EVENT_LIST':
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.dp_Event_List(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.main_params)
  elif AKaLrfeOPzRIYxWSwJDnFctgvdBkMV=='CATEGORY_LIST':
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.dp_Category_List(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.main_params)
  elif AKaLrfeOPzRIYxWSwJDnFctgvdBkMV=='SEASON_LIST':
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.dp_Season_List(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.main_params)
  elif AKaLrfeOPzRIYxWSwJDnFctgvdBkMV=='EPISODE_LIST':
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.dp_Episode_List(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.main_params)
  elif AKaLrfeOPzRIYxWSwJDnFctgvdBkMV=='TEST':
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.dp_Test(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.main_params)
  elif AKaLrfeOPzRIYxWSwJDnFctgvdBkMV in['MOVIE','VOD','HIGHLIGHT','LIVE']:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.play_VIDEO(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.main_params)
  elif AKaLrfeOPzRIYxWSwJDnFctgvdBkMV=='WATCH':
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.dp_Watch_List(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.main_params)
  elif AKaLrfeOPzRIYxWSwJDnFctgvdBkMV=='LOCAL_SEARCH':
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.dp_Search_List(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.main_params)
  elif AKaLrfeOPzRIYxWSwJDnFctgvdBkMV=='SEARCH_HISTORY':
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.dp_Search_History(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.main_params)
  elif AKaLrfeOPzRIYxWSwJDnFctgvdBkMV in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.dp_Listfile_Delete(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.main_params)
  elif AKaLrfeOPzRIYxWSwJDnFctgvdBkMV in['TOTAL_SEARCH','TOTAL_HISTORY']:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.dp_Global_Search(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.main_params)
  elif AKaLrfeOPzRIYxWSwJDnFctgvdBkMV=='MENU_BOOKMARK':
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.dp_Bookmark_Menu(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.main_params)
  elif AKaLrfeOPzRIYxWSwJDnFctgvdBkMV=='SET_BOOKMARK':
   AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.dp_Set_Bookmark(AKaLrfeOPzRIYxWSwJDnFctgvdBkpj.main_params)
  else:
   AKaLrfeOPzRIYxWSwJDnFctgvdBkEV
# Created by pyminifier (https://github.com/liftoff/pyminifier)
