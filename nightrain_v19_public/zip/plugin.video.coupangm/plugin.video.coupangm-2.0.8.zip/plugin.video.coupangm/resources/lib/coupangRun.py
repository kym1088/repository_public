__author__="NightRain"
FQcDyXLCHlfVbevWqJphwMUjdknBKN=object
FQcDyXLCHlfVbevWqJphwMUjdknBKo=None
FQcDyXLCHlfVbevWqJphwMUjdknBKG=False
FQcDyXLCHlfVbevWqJphwMUjdknBKa=True
FQcDyXLCHlfVbevWqJphwMUjdknBKg=type
FQcDyXLCHlfVbevWqJphwMUjdknBKY=dict
FQcDyXLCHlfVbevWqJphwMUjdknBiS=int
FQcDyXLCHlfVbevWqJphwMUjdknBiu=open
FQcDyXLCHlfVbevWqJphwMUjdknBiP=Exception
FQcDyXLCHlfVbevWqJphwMUjdknBiz=str
FQcDyXLCHlfVbevWqJphwMUjdknBim=id
FQcDyXLCHlfVbevWqJphwMUjdknBiK=len
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import inputstreamhelper
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
FQcDyXLCHlfVbevWqJphwMUjdknBSP=[{'title':'홈   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'ALL'},{'title':'TV   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'MOVIES'},{'title':'교육 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'EDUCATION'},{'title':'생중계','mode':'EVENT_GROUPLIST','vType':'LIVE'},{'title':'TV   (테마별)','mode':'THEME_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (테마별)','mode':'THEME_GROUPLIST','vType':'MOVIES'},{'title':'교육 (테마별)','mode':'THEME_GROUPLIST','vType':'EDUCATION'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},{'title':'(쿠팡) 검색','mode':'LOCAL_SEARCH','icon':'search.png'},{'title':'(쿠팡) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
FQcDyXLCHlfVbevWqJphwMUjdknBSz=[{'title':'시리즈 시청내역','mode':'WATCH','stype':'tvshow'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},]
FQcDyXLCHlfVbevWqJphwMUjdknBSm=xbmcvfs.translatePath(os.path.join(__profile__,'coupang_searched.txt'))
from coupangCore import*
class FQcDyXLCHlfVbevWqJphwMUjdknBSu(FQcDyXLCHlfVbevWqJphwMUjdknBKN):
 def __init__(FQcDyXLCHlfVbevWqJphwMUjdknBSK,FQcDyXLCHlfVbevWqJphwMUjdknBSi,FQcDyXLCHlfVbevWqJphwMUjdknBSs,FQcDyXLCHlfVbevWqJphwMUjdknBSt):
  FQcDyXLCHlfVbevWqJphwMUjdknBSK._addon_url =FQcDyXLCHlfVbevWqJphwMUjdknBSi
  FQcDyXLCHlfVbevWqJphwMUjdknBSK._addon_handle=FQcDyXLCHlfVbevWqJphwMUjdknBSs
  FQcDyXLCHlfVbevWqJphwMUjdknBSK.main_params =FQcDyXLCHlfVbevWqJphwMUjdknBSt
  FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj =JVwYHPFkcdDNLamiQOGuEptSKRoevz() 
  FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.CP_COOKIE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_cookies.json'))
  FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.CP_DEVICE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_device.json'))
 def addon_noti(FQcDyXLCHlfVbevWqJphwMUjdknBSK,sting):
  try:
   FQcDyXLCHlfVbevWqJphwMUjdknBSx=xbmcgui.Dialog()
   FQcDyXLCHlfVbevWqJphwMUjdknBSx.notification(__addonname__,sting)
  except:
   FQcDyXLCHlfVbevWqJphwMUjdknBKo
 def addon_log(FQcDyXLCHlfVbevWqJphwMUjdknBSK,string):
  try:
   FQcDyXLCHlfVbevWqJphwMUjdknBSA=string.encode('utf-8','ignore')
  except:
   FQcDyXLCHlfVbevWqJphwMUjdknBSA='addonException: addon_log'
  FQcDyXLCHlfVbevWqJphwMUjdknBST=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,FQcDyXLCHlfVbevWqJphwMUjdknBSA),level=FQcDyXLCHlfVbevWqJphwMUjdknBST)
 def get_keyboard_input(FQcDyXLCHlfVbevWqJphwMUjdknBSK,FQcDyXLCHlfVbevWqJphwMUjdknBuP):
  FQcDyXLCHlfVbevWqJphwMUjdknBSR=FQcDyXLCHlfVbevWqJphwMUjdknBKo
  kb=xbmc.Keyboard()
  kb.setHeading(FQcDyXLCHlfVbevWqJphwMUjdknBuP)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   FQcDyXLCHlfVbevWqJphwMUjdknBSR=kb.getText()
  return FQcDyXLCHlfVbevWqJphwMUjdknBSR
 def get_settings_account(FQcDyXLCHlfVbevWqJphwMUjdknBSK):
  FQcDyXLCHlfVbevWqJphwMUjdknBSr=__addon__.getSetting('id')
  FQcDyXLCHlfVbevWqJphwMUjdknBSO=__addon__.getSetting('pw')
  FQcDyXLCHlfVbevWqJphwMUjdknBSE=__addon__.getSetting('profile')
  return(FQcDyXLCHlfVbevWqJphwMUjdknBSr,FQcDyXLCHlfVbevWqJphwMUjdknBSO,FQcDyXLCHlfVbevWqJphwMUjdknBSE)
 def get_settings_exclusion21(FQcDyXLCHlfVbevWqJphwMUjdknBSK):
  FQcDyXLCHlfVbevWqJphwMUjdknBSN =__addon__.getSetting('exclusion21')
  if FQcDyXLCHlfVbevWqJphwMUjdknBSN=='false':
   return FQcDyXLCHlfVbevWqJphwMUjdknBKG
  else:
   return FQcDyXLCHlfVbevWqJphwMUjdknBKa
 def get_settings_totalsearch(FQcDyXLCHlfVbevWqJphwMUjdknBSK):
  FQcDyXLCHlfVbevWqJphwMUjdknBSo =FQcDyXLCHlfVbevWqJphwMUjdknBKa if __addon__.getSetting('local_search')=='true' else FQcDyXLCHlfVbevWqJphwMUjdknBKG
  FQcDyXLCHlfVbevWqJphwMUjdknBSG=FQcDyXLCHlfVbevWqJphwMUjdknBKa if __addon__.getSetting('local_history')=='true' else FQcDyXLCHlfVbevWqJphwMUjdknBKG
  FQcDyXLCHlfVbevWqJphwMUjdknBSa =FQcDyXLCHlfVbevWqJphwMUjdknBKa if __addon__.getSetting('total_search')=='true' else FQcDyXLCHlfVbevWqJphwMUjdknBKG
  FQcDyXLCHlfVbevWqJphwMUjdknBSg=FQcDyXLCHlfVbevWqJphwMUjdknBKa if __addon__.getSetting('total_history')=='true' else FQcDyXLCHlfVbevWqJphwMUjdknBKG
  FQcDyXLCHlfVbevWqJphwMUjdknBSY=FQcDyXLCHlfVbevWqJphwMUjdknBKa if __addon__.getSetting('menu_bookmark')=='true' else FQcDyXLCHlfVbevWqJphwMUjdknBKG
  return(FQcDyXLCHlfVbevWqJphwMUjdknBSo,FQcDyXLCHlfVbevWqJphwMUjdknBSG,FQcDyXLCHlfVbevWqJphwMUjdknBSa,FQcDyXLCHlfVbevWqJphwMUjdknBSg,FQcDyXLCHlfVbevWqJphwMUjdknBSY)
 def get_settings_makebookmark(FQcDyXLCHlfVbevWqJphwMUjdknBSK):
  return FQcDyXLCHlfVbevWqJphwMUjdknBKa if __addon__.getSetting('make_bookmark')=='true' else FQcDyXLCHlfVbevWqJphwMUjdknBKG
 def add_dir(FQcDyXLCHlfVbevWqJphwMUjdknBSK,label,sublabel='',img='',infoLabels=FQcDyXLCHlfVbevWqJphwMUjdknBKo,isFolder=FQcDyXLCHlfVbevWqJphwMUjdknBKa,params='',isLink=FQcDyXLCHlfVbevWqJphwMUjdknBKG,ContextMenu=FQcDyXLCHlfVbevWqJphwMUjdknBKo):
  FQcDyXLCHlfVbevWqJphwMUjdknBuS='%s?%s'%(FQcDyXLCHlfVbevWqJphwMUjdknBSK._addon_url,urllib.parse.urlencode(params))
  if sublabel:FQcDyXLCHlfVbevWqJphwMUjdknBuP='%s < %s >'%(label,sublabel)
  else: FQcDyXLCHlfVbevWqJphwMUjdknBuP=label
  if not img:img='DefaultFolder.png'
  FQcDyXLCHlfVbevWqJphwMUjdknBuz=xbmcgui.ListItem(FQcDyXLCHlfVbevWqJphwMUjdknBuP)
  if FQcDyXLCHlfVbevWqJphwMUjdknBKg(img)==FQcDyXLCHlfVbevWqJphwMUjdknBKY:
   FQcDyXLCHlfVbevWqJphwMUjdknBuz.setArt(img)
  else:
   FQcDyXLCHlfVbevWqJphwMUjdknBuz.setArt({'thumb':img,'poster':img})
  if infoLabels:FQcDyXLCHlfVbevWqJphwMUjdknBuz.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   FQcDyXLCHlfVbevWqJphwMUjdknBuz.setProperty('IsPlayable','true')
  if ContextMenu:FQcDyXLCHlfVbevWqJphwMUjdknBuz.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(FQcDyXLCHlfVbevWqJphwMUjdknBSK._addon_handle,FQcDyXLCHlfVbevWqJphwMUjdknBuS,FQcDyXLCHlfVbevWqJphwMUjdknBuz,isFolder)
 def dp_Main_List(FQcDyXLCHlfVbevWqJphwMUjdknBSK,args):
  (FQcDyXLCHlfVbevWqJphwMUjdknBSo,FQcDyXLCHlfVbevWqJphwMUjdknBSG,FQcDyXLCHlfVbevWqJphwMUjdknBSa,FQcDyXLCHlfVbevWqJphwMUjdknBSg,FQcDyXLCHlfVbevWqJphwMUjdknBSY)=FQcDyXLCHlfVbevWqJphwMUjdknBSK.get_settings_totalsearch()
  for FQcDyXLCHlfVbevWqJphwMUjdknBum in FQcDyXLCHlfVbevWqJphwMUjdknBSP:
   FQcDyXLCHlfVbevWqJphwMUjdknBuP=FQcDyXLCHlfVbevWqJphwMUjdknBum.get('title')
   FQcDyXLCHlfVbevWqJphwMUjdknBuK=''
   if FQcDyXLCHlfVbevWqJphwMUjdknBum.get('mode')=='LOCAL_SEARCH' and FQcDyXLCHlfVbevWqJphwMUjdknBSo ==FQcDyXLCHlfVbevWqJphwMUjdknBKG:continue
   elif FQcDyXLCHlfVbevWqJphwMUjdknBum.get('mode')=='SEARCH_HISTORY' and FQcDyXLCHlfVbevWqJphwMUjdknBSG==FQcDyXLCHlfVbevWqJphwMUjdknBKG:continue
   elif FQcDyXLCHlfVbevWqJphwMUjdknBum.get('mode')=='TOTAL_SEARCH' and FQcDyXLCHlfVbevWqJphwMUjdknBSa ==FQcDyXLCHlfVbevWqJphwMUjdknBKG:continue
   elif FQcDyXLCHlfVbevWqJphwMUjdknBum.get('mode')=='TOTAL_HISTORY' and FQcDyXLCHlfVbevWqJphwMUjdknBSg==FQcDyXLCHlfVbevWqJphwMUjdknBKG:continue
   elif FQcDyXLCHlfVbevWqJphwMUjdknBum.get('mode')=='MENU_BOOKMARK' and FQcDyXLCHlfVbevWqJphwMUjdknBSY==FQcDyXLCHlfVbevWqJphwMUjdknBKG:continue
   FQcDyXLCHlfVbevWqJphwMUjdknBui={'mode':FQcDyXLCHlfVbevWqJphwMUjdknBum.get('mode'),'vType':FQcDyXLCHlfVbevWqJphwMUjdknBum.get('vType'),'page':'1',}
   if FQcDyXLCHlfVbevWqJphwMUjdknBum.get('mode')=='LOCAL_SEARCH':FQcDyXLCHlfVbevWqJphwMUjdknBui['historyyn']='Y' 
   if FQcDyXLCHlfVbevWqJphwMUjdknBum.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    FQcDyXLCHlfVbevWqJphwMUjdknBus=FQcDyXLCHlfVbevWqJphwMUjdknBKG
    FQcDyXLCHlfVbevWqJphwMUjdknBut =FQcDyXLCHlfVbevWqJphwMUjdknBKa
   else:
    FQcDyXLCHlfVbevWqJphwMUjdknBus=FQcDyXLCHlfVbevWqJphwMUjdknBKa
    FQcDyXLCHlfVbevWqJphwMUjdknBut =FQcDyXLCHlfVbevWqJphwMUjdknBKG
   if 'icon' in FQcDyXLCHlfVbevWqJphwMUjdknBum:FQcDyXLCHlfVbevWqJphwMUjdknBuK=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',FQcDyXLCHlfVbevWqJphwMUjdknBum.get('icon')) 
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.add_dir(FQcDyXLCHlfVbevWqJphwMUjdknBuP,sublabel='',img=FQcDyXLCHlfVbevWqJphwMUjdknBuK,infoLabels=FQcDyXLCHlfVbevWqJphwMUjdknBKo,isFolder=FQcDyXLCHlfVbevWqJphwMUjdknBus,params=FQcDyXLCHlfVbevWqJphwMUjdknBui,isLink=FQcDyXLCHlfVbevWqJphwMUjdknBut)
  xbmcplugin.endOfDirectory(FQcDyXLCHlfVbevWqJphwMUjdknBSK._addon_handle)
 def dp_Test(FQcDyXLCHlfVbevWqJphwMUjdknBSK,args):
  FQcDyXLCHlfVbevWqJphwMUjdknBSK.addon_noti('test')
 def CP_logout(FQcDyXLCHlfVbevWqJphwMUjdknBSK):
  FQcDyXLCHlfVbevWqJphwMUjdknBSx=xbmcgui.Dialog()
  FQcDyXLCHlfVbevWqJphwMUjdknBux=FQcDyXLCHlfVbevWqJphwMUjdknBSx.yesno(__language__(30905).encode('utf8'),__language__(30906).encode('utf8'))
  if FQcDyXLCHlfVbevWqJphwMUjdknBux==FQcDyXLCHlfVbevWqJphwMUjdknBKG:return 
  if os.path.isfile(FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.CP_COOKIE_FILENAME):os.remove(FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.CP_COOKIE_FILENAME)
  FQcDyXLCHlfVbevWqJphwMUjdknBSK.addon_noti(__language__(30904).encode('utf-8'))
 def option_check(FQcDyXLCHlfVbevWqJphwMUjdknBSK):
  (FQcDyXLCHlfVbevWqJphwMUjdknBSr,FQcDyXLCHlfVbevWqJphwMUjdknBSO,FQcDyXLCHlfVbevWqJphwMUjdknBSE)=FQcDyXLCHlfVbevWqJphwMUjdknBSK.get_settings_account()
  if FQcDyXLCHlfVbevWqJphwMUjdknBSr=='' or FQcDyXLCHlfVbevWqJphwMUjdknBSO=='':
   FQcDyXLCHlfVbevWqJphwMUjdknBSx=xbmcgui.Dialog()
   FQcDyXLCHlfVbevWqJphwMUjdknBux=FQcDyXLCHlfVbevWqJphwMUjdknBSx.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if FQcDyXLCHlfVbevWqJphwMUjdknBux==FQcDyXLCHlfVbevWqJphwMUjdknBKa:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if FQcDyXLCHlfVbevWqJphwMUjdknBSK.cookiefile_check()==FQcDyXLCHlfVbevWqJphwMUjdknBKG:
   if FQcDyXLCHlfVbevWqJphwMUjdknBSK.CP_login(FQcDyXLCHlfVbevWqJphwMUjdknBSr,FQcDyXLCHlfVbevWqJphwMUjdknBSO,FQcDyXLCHlfVbevWqJphwMUjdknBSE)==FQcDyXLCHlfVbevWqJphwMUjdknBKG:
    FQcDyXLCHlfVbevWqJphwMUjdknBSK.addon_noti(__language__(30903).encode('utf8'))
    sys.exit()
  else:
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.Get_CP_profile(FQcDyXLCHlfVbevWqJphwMUjdknBSE,limit_days=FQcDyXLCHlfVbevWqJphwMUjdknBiS(__addon__.getSetting('cache_ttl')),re_check=FQcDyXLCHlfVbevWqJphwMUjdknBKa)
 def cookiefile_check(FQcDyXLCHlfVbevWqJphwMUjdknBSK):
  FQcDyXLCHlfVbevWqJphwMUjdknBuT={}
  try: 
   fp=FQcDyXLCHlfVbevWqJphwMUjdknBiu(FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.CP_COOKIE_FILENAME,'r',-1,'utf-8')
   FQcDyXLCHlfVbevWqJphwMUjdknBuT= json.load(fp)
   fp.close()
  except FQcDyXLCHlfVbevWqJphwMUjdknBiP as exception:
   return FQcDyXLCHlfVbevWqJphwMUjdknBKG
  FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.CP=FQcDyXLCHlfVbevWqJphwMUjdknBuT
  (FQcDyXLCHlfVbevWqJphwMUjdknBSr,FQcDyXLCHlfVbevWqJphwMUjdknBSO,FQcDyXLCHlfVbevWqJphwMUjdknBSE)=FQcDyXLCHlfVbevWqJphwMUjdknBSK.get_settings_account()
  (FQcDyXLCHlfVbevWqJphwMUjdknBuR,FQcDyXLCHlfVbevWqJphwMUjdknBur,FQcDyXLCHlfVbevWqJphwMUjdknBuO)=FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.Load_session_acount()
  if FQcDyXLCHlfVbevWqJphwMUjdknBSr!=FQcDyXLCHlfVbevWqJphwMUjdknBuR or FQcDyXLCHlfVbevWqJphwMUjdknBSO!=FQcDyXLCHlfVbevWqJphwMUjdknBur or FQcDyXLCHlfVbevWqJphwMUjdknBSE!=FQcDyXLCHlfVbevWqJphwMUjdknBiz(FQcDyXLCHlfVbevWqJphwMUjdknBuO):
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.Init_CP()
   return FQcDyXLCHlfVbevWqJphwMUjdknBKG
  FQcDyXLCHlfVbevWqJphwMUjdknBuE =FQcDyXLCHlfVbevWqJphwMUjdknBiS(FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.Get_Now_Datetime().strftime('%Y%m%d'))
  FQcDyXLCHlfVbevWqJphwMUjdknBuN=FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.CP['SESSION']['limitdate']
  FQcDyXLCHlfVbevWqJphwMUjdknBuo =FQcDyXLCHlfVbevWqJphwMUjdknBiS(re.sub('-','',FQcDyXLCHlfVbevWqJphwMUjdknBuN))
  if FQcDyXLCHlfVbevWqJphwMUjdknBuo<FQcDyXLCHlfVbevWqJphwMUjdknBuE:
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.Init_CP()
   return FQcDyXLCHlfVbevWqJphwMUjdknBKG
  return FQcDyXLCHlfVbevWqJphwMUjdknBKa
 def CP_login(FQcDyXLCHlfVbevWqJphwMUjdknBSK,FQcDyXLCHlfVbevWqJphwMUjdknBSr,FQcDyXLCHlfVbevWqJphwMUjdknBSO,FQcDyXLCHlfVbevWqJphwMUjdknBSE):
  if FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.Get_CP_Login(FQcDyXLCHlfVbevWqJphwMUjdknBSr,FQcDyXLCHlfVbevWqJphwMUjdknBSO,FQcDyXLCHlfVbevWqJphwMUjdknBSE)==FQcDyXLCHlfVbevWqJphwMUjdknBKG:return FQcDyXLCHlfVbevWqJphwMUjdknBKG
  if FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.Get_CP_profile(FQcDyXLCHlfVbevWqJphwMUjdknBSE,limit_days=FQcDyXLCHlfVbevWqJphwMUjdknBiS(__addon__.getSetting('cache_ttl')),re_check=FQcDyXLCHlfVbevWqJphwMUjdknBKG)==FQcDyXLCHlfVbevWqJphwMUjdknBKG:return FQcDyXLCHlfVbevWqJphwMUjdknBKG
  return FQcDyXLCHlfVbevWqJphwMUjdknBKa
 def dp_Category_GroupList(FQcDyXLCHlfVbevWqJphwMUjdknBSK,args):
  FQcDyXLCHlfVbevWqJphwMUjdknBuG =args.get('vType') 
  FQcDyXLCHlfVbevWqJphwMUjdknBua=FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.Get_Category_GroupList(FQcDyXLCHlfVbevWqJphwMUjdknBuG)
  for FQcDyXLCHlfVbevWqJphwMUjdknBug in FQcDyXLCHlfVbevWqJphwMUjdknBua:
   FQcDyXLCHlfVbevWqJphwMUjdknBuP =FQcDyXLCHlfVbevWqJphwMUjdknBug.get('title')
   FQcDyXLCHlfVbevWqJphwMUjdknBuY=FQcDyXLCHlfVbevWqJphwMUjdknBug.get('pre_title')
   if FQcDyXLCHlfVbevWqJphwMUjdknBSK.get_settings_exclusion21()==FQcDyXLCHlfVbevWqJphwMUjdknBKa and FQcDyXLCHlfVbevWqJphwMUjdknBuP=='성인':continue
   FQcDyXLCHlfVbevWqJphwMUjdknBPS={'mediatype':'tvshow','plot':FQcDyXLCHlfVbevWqJphwMUjdknBuY,}
   FQcDyXLCHlfVbevWqJphwMUjdknBui={'mode':'CATEGORY_LIST','collectionId':FQcDyXLCHlfVbevWqJphwMUjdknBug.get('collectionId'),'vType':FQcDyXLCHlfVbevWqJphwMUjdknBug.get('category'),'page':'1',}
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.add_dir(FQcDyXLCHlfVbevWqJphwMUjdknBuP,sublabel='',img='',infoLabels=FQcDyXLCHlfVbevWqJphwMUjdknBPS,isFolder=FQcDyXLCHlfVbevWqJphwMUjdknBKa,params=FQcDyXLCHlfVbevWqJphwMUjdknBui)
  xbmcplugin.endOfDirectory(FQcDyXLCHlfVbevWqJphwMUjdknBSK._addon_handle,cacheToDisc=FQcDyXLCHlfVbevWqJphwMUjdknBKG)
 def dp_Theme_GroupList(FQcDyXLCHlfVbevWqJphwMUjdknBSK,args):
  FQcDyXLCHlfVbevWqJphwMUjdknBuG =args.get('vType') 
  FQcDyXLCHlfVbevWqJphwMUjdknBua=FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.Get_Theme_GroupList(FQcDyXLCHlfVbevWqJphwMUjdknBuG)
  for FQcDyXLCHlfVbevWqJphwMUjdknBug in FQcDyXLCHlfVbevWqJphwMUjdknBua:
   FQcDyXLCHlfVbevWqJphwMUjdknBuP =FQcDyXLCHlfVbevWqJphwMUjdknBug.get('title')
   FQcDyXLCHlfVbevWqJphwMUjdknBuY=FQcDyXLCHlfVbevWqJphwMUjdknBug.get('pre_title')
   FQcDyXLCHlfVbevWqJphwMUjdknBPS={'mediatype':'tvshow','plot':FQcDyXLCHlfVbevWqJphwMUjdknBuY,}
   FQcDyXLCHlfVbevWqJphwMUjdknBui={'mode':'CATEGORY_LIST','collectionId':FQcDyXLCHlfVbevWqJphwMUjdknBug.get('collectionId'),'vType':FQcDyXLCHlfVbevWqJphwMUjdknBug.get('category'),'page':'1',}
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.add_dir(FQcDyXLCHlfVbevWqJphwMUjdknBuP,sublabel='',img='',infoLabels=FQcDyXLCHlfVbevWqJphwMUjdknBPS,isFolder=FQcDyXLCHlfVbevWqJphwMUjdknBKa,params=FQcDyXLCHlfVbevWqJphwMUjdknBui)
  xbmcplugin.endOfDirectory(FQcDyXLCHlfVbevWqJphwMUjdknBSK._addon_handle,cacheToDisc=FQcDyXLCHlfVbevWqJphwMUjdknBKG)
 def dp_Event_GroupList(FQcDyXLCHlfVbevWqJphwMUjdknBSK,args):
  FQcDyXLCHlfVbevWqJphwMUjdknBua=FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.Get_Event_GroupList()
  for FQcDyXLCHlfVbevWqJphwMUjdknBug in FQcDyXLCHlfVbevWqJphwMUjdknBua:
   FQcDyXLCHlfVbevWqJphwMUjdknBuP =FQcDyXLCHlfVbevWqJphwMUjdknBug.get('title')
   FQcDyXLCHlfVbevWqJphwMUjdknBuY=FQcDyXLCHlfVbevWqJphwMUjdknBug.get('pre_title')
   FQcDyXLCHlfVbevWqJphwMUjdknBPS={'mediatype':'tvshow','plot':FQcDyXLCHlfVbevWqJphwMUjdknBuY,}
   FQcDyXLCHlfVbevWqJphwMUjdknBui={'mode':'EVENT_GAMELIST','collectionId':FQcDyXLCHlfVbevWqJphwMUjdknBug.get('collectionId'),'vType':'LIVE',}
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.add_dir(FQcDyXLCHlfVbevWqJphwMUjdknBuP,sublabel='',img='',infoLabels=FQcDyXLCHlfVbevWqJphwMUjdknBPS,isFolder=FQcDyXLCHlfVbevWqJphwMUjdknBKa,params=FQcDyXLCHlfVbevWqJphwMUjdknBui)
  xbmcplugin.endOfDirectory(FQcDyXLCHlfVbevWqJphwMUjdknBSK._addon_handle,cacheToDisc=FQcDyXLCHlfVbevWqJphwMUjdknBKG)
 def dp_Event_GameList(FQcDyXLCHlfVbevWqJphwMUjdknBSK,args):
  FQcDyXLCHlfVbevWqJphwMUjdknBuG =args.get('vType') 
  FQcDyXLCHlfVbevWqJphwMUjdknBPz =args.get('collectionId')
  FQcDyXLCHlfVbevWqJphwMUjdknBua=FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.Get_Event_GameList(FQcDyXLCHlfVbevWqJphwMUjdknBPz)
  for FQcDyXLCHlfVbevWqJphwMUjdknBug in FQcDyXLCHlfVbevWqJphwMUjdknBua:
   FQcDyXLCHlfVbevWqJphwMUjdknBuP =FQcDyXLCHlfVbevWqJphwMUjdknBug.get('title')
   FQcDyXLCHlfVbevWqJphwMUjdknBim =FQcDyXLCHlfVbevWqJphwMUjdknBug.get('id')
   FQcDyXLCHlfVbevWqJphwMUjdknBPm =FQcDyXLCHlfVbevWqJphwMUjdknBug.get('thumbnail')
   FQcDyXLCHlfVbevWqJphwMUjdknBPK =FQcDyXLCHlfVbevWqJphwMUjdknBug.get('asis') 
   FQcDyXLCHlfVbevWqJphwMUjdknBPi =FQcDyXLCHlfVbevWqJphwMUjdknBug.get('addInfo')
   FQcDyXLCHlfVbevWqJphwMUjdknBPs =FQcDyXLCHlfVbevWqJphwMUjdknBug.get('starttm')
   FQcDyXLCHlfVbevWqJphwMUjdknBPS={'mediatype':'tvshow','title':FQcDyXLCHlfVbevWqJphwMUjdknBuP,'plot':FQcDyXLCHlfVbevWqJphwMUjdknBPi,}
   FQcDyXLCHlfVbevWqJphwMUjdknBui={'mode':'EVENT_LIST','id':FQcDyXLCHlfVbevWqJphwMUjdknBim,'asis':FQcDyXLCHlfVbevWqJphwMUjdknBPK,'title':FQcDyXLCHlfVbevWqJphwMUjdknBuP,}
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.add_dir(FQcDyXLCHlfVbevWqJphwMUjdknBuP,sublabel=FQcDyXLCHlfVbevWqJphwMUjdknBPs,img=FQcDyXLCHlfVbevWqJphwMUjdknBPm,infoLabels=FQcDyXLCHlfVbevWqJphwMUjdknBPS,isFolder=FQcDyXLCHlfVbevWqJphwMUjdknBKa,params=FQcDyXLCHlfVbevWqJphwMUjdknBui,ContextMenu=FQcDyXLCHlfVbevWqJphwMUjdknBKo)
  xbmcplugin.setContent(FQcDyXLCHlfVbevWqJphwMUjdknBSK._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(FQcDyXLCHlfVbevWqJphwMUjdknBSK._addon_handle,cacheToDisc=FQcDyXLCHlfVbevWqJphwMUjdknBKG)
 def dp_Event_List(FQcDyXLCHlfVbevWqJphwMUjdknBSK,args):
  FQcDyXLCHlfVbevWqJphwMUjdknBPt=args.get('id')
  FQcDyXLCHlfVbevWqJphwMUjdknBua=FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.Get_Event_List(FQcDyXLCHlfVbevWqJphwMUjdknBPt)
  for FQcDyXLCHlfVbevWqJphwMUjdknBug in FQcDyXLCHlfVbevWqJphwMUjdknBua:
   FQcDyXLCHlfVbevWqJphwMUjdknBuP =FQcDyXLCHlfVbevWqJphwMUjdknBug.get('title')
   FQcDyXLCHlfVbevWqJphwMUjdknBim =FQcDyXLCHlfVbevWqJphwMUjdknBug.get('id')
   FQcDyXLCHlfVbevWqJphwMUjdknBPm =FQcDyXLCHlfVbevWqJphwMUjdknBug.get('thumbnail')
   FQcDyXLCHlfVbevWqJphwMUjdknBPK =FQcDyXLCHlfVbevWqJphwMUjdknBug.get('asis') 
   FQcDyXLCHlfVbevWqJphwMUjdknBPI =FQcDyXLCHlfVbevWqJphwMUjdknBug.get('duration')
   FQcDyXLCHlfVbevWqJphwMUjdknBPs =FQcDyXLCHlfVbevWqJphwMUjdknBug.get('starttm')
   FQcDyXLCHlfVbevWqJphwMUjdknBPS={'mediatype':'episode','title':FQcDyXLCHlfVbevWqJphwMUjdknBuP,'plot':FQcDyXLCHlfVbevWqJphwMUjdknBPK,'duration':FQcDyXLCHlfVbevWqJphwMUjdknBPI,}
   FQcDyXLCHlfVbevWqJphwMUjdknBui={'mode':FQcDyXLCHlfVbevWqJphwMUjdknBPK,'id':FQcDyXLCHlfVbevWqJphwMUjdknBim,'asis':FQcDyXLCHlfVbevWqJphwMUjdknBPK,'title':FQcDyXLCHlfVbevWqJphwMUjdknBuP,}
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.add_dir(FQcDyXLCHlfVbevWqJphwMUjdknBuP,sublabel=FQcDyXLCHlfVbevWqJphwMUjdknBPs,img=FQcDyXLCHlfVbevWqJphwMUjdknBPm,infoLabels=FQcDyXLCHlfVbevWqJphwMUjdknBPS,isFolder=FQcDyXLCHlfVbevWqJphwMUjdknBKG,params=FQcDyXLCHlfVbevWqJphwMUjdknBui,ContextMenu=FQcDyXLCHlfVbevWqJphwMUjdknBKo)
  xbmcplugin.setContent(FQcDyXLCHlfVbevWqJphwMUjdknBSK._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(FQcDyXLCHlfVbevWqJphwMUjdknBSK._addon_handle,cacheToDisc=FQcDyXLCHlfVbevWqJphwMUjdknBKG)
 def dp_Category_List(FQcDyXLCHlfVbevWqJphwMUjdknBSK,args):
  FQcDyXLCHlfVbevWqJphwMUjdknBuG =args.get('vType') 
  FQcDyXLCHlfVbevWqJphwMUjdknBPz =args.get('collectionId')
  FQcDyXLCHlfVbevWqJphwMUjdknBPx =FQcDyXLCHlfVbevWqJphwMUjdknBiS(args.get('page'))
  FQcDyXLCHlfVbevWqJphwMUjdknBua,FQcDyXLCHlfVbevWqJphwMUjdknBPA=FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.Get_Category_List(FQcDyXLCHlfVbevWqJphwMUjdknBuG,FQcDyXLCHlfVbevWqJphwMUjdknBPz,FQcDyXLCHlfVbevWqJphwMUjdknBPx)
  for FQcDyXLCHlfVbevWqJphwMUjdknBug in FQcDyXLCHlfVbevWqJphwMUjdknBua:
   FQcDyXLCHlfVbevWqJphwMUjdknBuP =FQcDyXLCHlfVbevWqJphwMUjdknBug.get('title')
   FQcDyXLCHlfVbevWqJphwMUjdknBim =FQcDyXLCHlfVbevWqJphwMUjdknBug.get('id')
   FQcDyXLCHlfVbevWqJphwMUjdknBPm =FQcDyXLCHlfVbevWqJphwMUjdknBug.get('thumbnail')
   FQcDyXLCHlfVbevWqJphwMUjdknBPT =FQcDyXLCHlfVbevWqJphwMUjdknBug.get('mpaa')
   FQcDyXLCHlfVbevWqJphwMUjdknBPI =FQcDyXLCHlfVbevWqJphwMUjdknBug.get('duration')
   FQcDyXLCHlfVbevWqJphwMUjdknBPK =FQcDyXLCHlfVbevWqJphwMUjdknBug.get('asis')
   FQcDyXLCHlfVbevWqJphwMUjdknBPR =FQcDyXLCHlfVbevWqJphwMUjdknBug.get('badge')
   FQcDyXLCHlfVbevWqJphwMUjdknBPr =FQcDyXLCHlfVbevWqJphwMUjdknBug.get('year')
   FQcDyXLCHlfVbevWqJphwMUjdknBPO=FQcDyXLCHlfVbevWqJphwMUjdknBug.get('seasonList')
   FQcDyXLCHlfVbevWqJphwMUjdknBPE =FQcDyXLCHlfVbevWqJphwMUjdknBug.get('genreList')
   if FQcDyXLCHlfVbevWqJphwMUjdknBPK in['TVSHOW','EDUCATION']: 
    FQcDyXLCHlfVbevWqJphwMUjdknBPN ='SEASON_LIST'
    FQcDyXLCHlfVbevWqJphwMUjdknBPS={'mediatype':'tvshow','title':FQcDyXLCHlfVbevWqJphwMUjdknBuP,'mpaa':FQcDyXLCHlfVbevWqJphwMUjdknBPT,'genre':FQcDyXLCHlfVbevWqJphwMUjdknBPE,'year':FQcDyXLCHlfVbevWqJphwMUjdknBPr,'plot':'Year : %s\nSeason : %s'%(FQcDyXLCHlfVbevWqJphwMUjdknBPr,FQcDyXLCHlfVbevWqJphwMUjdknBPO),}
    FQcDyXLCHlfVbevWqJphwMUjdknBus =FQcDyXLCHlfVbevWqJphwMUjdknBKa
   else:
    FQcDyXLCHlfVbevWqJphwMUjdknBPN ='MOVIE'
    FQcDyXLCHlfVbevWqJphwMUjdknBPS={'mediatype':'movie','title':FQcDyXLCHlfVbevWqJphwMUjdknBuP,'mpaa':FQcDyXLCHlfVbevWqJphwMUjdknBPT,'genre':FQcDyXLCHlfVbevWqJphwMUjdknBPE,'duration':FQcDyXLCHlfVbevWqJphwMUjdknBPI,'year':FQcDyXLCHlfVbevWqJphwMUjdknBPr,'plot':'(%s)'%(FQcDyXLCHlfVbevWqJphwMUjdknBPT),}
    FQcDyXLCHlfVbevWqJphwMUjdknBus =FQcDyXLCHlfVbevWqJphwMUjdknBKG
    FQcDyXLCHlfVbevWqJphwMUjdknBuP +=' (%s)'%(FQcDyXLCHlfVbevWqJphwMUjdknBiz(FQcDyXLCHlfVbevWqJphwMUjdknBPr))
   FQcDyXLCHlfVbevWqJphwMUjdknBui={'mode':FQcDyXLCHlfVbevWqJphwMUjdknBPN,'id':FQcDyXLCHlfVbevWqJphwMUjdknBim,'asis':FQcDyXLCHlfVbevWqJphwMUjdknBPK,'seasonList':FQcDyXLCHlfVbevWqJphwMUjdknBPO,'title':FQcDyXLCHlfVbevWqJphwMUjdknBuP,'thumbnail':FQcDyXLCHlfVbevWqJphwMUjdknBPm,'year':FQcDyXLCHlfVbevWqJphwMUjdknBPr,}
   if FQcDyXLCHlfVbevWqJphwMUjdknBSK.get_settings_makebookmark():
    FQcDyXLCHlfVbevWqJphwMUjdknBPo={'videoid':FQcDyXLCHlfVbevWqJphwMUjdknBim,'vidtype':'movie' if FQcDyXLCHlfVbevWqJphwMUjdknBuG=='MOVIES' else 'tvshow','vtitle':FQcDyXLCHlfVbevWqJphwMUjdknBuP,'vsubtitle':'',}
    FQcDyXLCHlfVbevWqJphwMUjdknBPG=json.dumps(FQcDyXLCHlfVbevWqJphwMUjdknBPo)
    FQcDyXLCHlfVbevWqJphwMUjdknBPG=urllib.parse.quote(FQcDyXLCHlfVbevWqJphwMUjdknBPG)
    FQcDyXLCHlfVbevWqJphwMUjdknBPa='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(FQcDyXLCHlfVbevWqJphwMUjdknBPG)
    FQcDyXLCHlfVbevWqJphwMUjdknBPg=[('(통합) 찜 영상에 추가',FQcDyXLCHlfVbevWqJphwMUjdknBPa)]
   else:
    FQcDyXLCHlfVbevWqJphwMUjdknBPg=FQcDyXLCHlfVbevWqJphwMUjdknBKo
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.add_dir(FQcDyXLCHlfVbevWqJphwMUjdknBuP,sublabel=FQcDyXLCHlfVbevWqJphwMUjdknBPR,img=FQcDyXLCHlfVbevWqJphwMUjdknBPm,infoLabels=FQcDyXLCHlfVbevWqJphwMUjdknBPS,isFolder=FQcDyXLCHlfVbevWqJphwMUjdknBus,params=FQcDyXLCHlfVbevWqJphwMUjdknBui,ContextMenu=FQcDyXLCHlfVbevWqJphwMUjdknBPg)
  if FQcDyXLCHlfVbevWqJphwMUjdknBPA:
   FQcDyXLCHlfVbevWqJphwMUjdknBui['mode'] ='CATEGORY_LIST' 
   FQcDyXLCHlfVbevWqJphwMUjdknBui['collectionId']=FQcDyXLCHlfVbevWqJphwMUjdknBPz 
   FQcDyXLCHlfVbevWqJphwMUjdknBui['vType'] =FQcDyXLCHlfVbevWqJphwMUjdknBuG 
   FQcDyXLCHlfVbevWqJphwMUjdknBui['page'] =FQcDyXLCHlfVbevWqJphwMUjdknBiz(FQcDyXLCHlfVbevWqJphwMUjdknBPx+1)
   FQcDyXLCHlfVbevWqJphwMUjdknBuP='[B]%s >>[/B]'%'다음 페이지'
   FQcDyXLCHlfVbevWqJphwMUjdknBPY=FQcDyXLCHlfVbevWqJphwMUjdknBiz(FQcDyXLCHlfVbevWqJphwMUjdknBPx+1)
   FQcDyXLCHlfVbevWqJphwMUjdknBuK=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.add_dir(FQcDyXLCHlfVbevWqJphwMUjdknBuP,sublabel=FQcDyXLCHlfVbevWqJphwMUjdknBPY,img=FQcDyXLCHlfVbevWqJphwMUjdknBuK,infoLabels=FQcDyXLCHlfVbevWqJphwMUjdknBKo,isFolder=FQcDyXLCHlfVbevWqJphwMUjdknBKa,params=FQcDyXLCHlfVbevWqJphwMUjdknBui)
  if FQcDyXLCHlfVbevWqJphwMUjdknBuG=='TVSHOWS':xbmcplugin.setContent(FQcDyXLCHlfVbevWqJphwMUjdknBSK._addon_handle,'tvshows')
  else:xbmcplugin.setContent(FQcDyXLCHlfVbevWqJphwMUjdknBSK._addon_handle,'movies')
  xbmcplugin.endOfDirectory(FQcDyXLCHlfVbevWqJphwMUjdknBSK._addon_handle,cacheToDisc=FQcDyXLCHlfVbevWqJphwMUjdknBKG)
 def dp_Season_List(FQcDyXLCHlfVbevWqJphwMUjdknBSK,args):
  FQcDyXLCHlfVbevWqJphwMUjdknBzS =args.get('title')
  FQcDyXLCHlfVbevWqJphwMUjdknBzu =args.get('id')
  FQcDyXLCHlfVbevWqJphwMUjdknBPK =args.get('asis')
  FQcDyXLCHlfVbevWqJphwMUjdknBPO =args.get('seasonList')
  FQcDyXLCHlfVbevWqJphwMUjdknBPm =args.get('thumbnail')
  FQcDyXLCHlfVbevWqJphwMUjdknBPr =args.get('year')
  if FQcDyXLCHlfVbevWqJphwMUjdknBPO in['',FQcDyXLCHlfVbevWqJphwMUjdknBKo]:
   FQcDyXLCHlfVbevWqJphwMUjdknBPO=FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.Get_vInfo(FQcDyXLCHlfVbevWqJphwMUjdknBzu).get('seasonList')
  if FQcDyXLCHlfVbevWqJphwMUjdknBiK(FQcDyXLCHlfVbevWqJphwMUjdknBPO.split(','))>1:
   for FQcDyXLCHlfVbevWqJphwMUjdknBzP in FQcDyXLCHlfVbevWqJphwMUjdknBPO.split(','):
    FQcDyXLCHlfVbevWqJphwMUjdknBuP='시즌 '+FQcDyXLCHlfVbevWqJphwMUjdknBzP
    FQcDyXLCHlfVbevWqJphwMUjdknBPS={'mediatype':'tvshow','plot':'%s (%s)'%(FQcDyXLCHlfVbevWqJphwMUjdknBzS,FQcDyXLCHlfVbevWqJphwMUjdknBPr),}
    FQcDyXLCHlfVbevWqJphwMUjdknBui={'mode':'EPISODE_LIST','programid':FQcDyXLCHlfVbevWqJphwMUjdknBzu,'programnm':FQcDyXLCHlfVbevWqJphwMUjdknBzS,'season':FQcDyXLCHlfVbevWqJphwMUjdknBzP,'asis':FQcDyXLCHlfVbevWqJphwMUjdknBPK,'programimg':FQcDyXLCHlfVbevWqJphwMUjdknBPm,}
    FQcDyXLCHlfVbevWqJphwMUjdknBzm=FQcDyXLCHlfVbevWqJphwMUjdknBPm.replace('\'','\"')
    FQcDyXLCHlfVbevWqJphwMUjdknBzm=json.loads(FQcDyXLCHlfVbevWqJphwMUjdknBzm)
    FQcDyXLCHlfVbevWqJphwMUjdknBSK.add_dir(FQcDyXLCHlfVbevWqJphwMUjdknBuP,sublabel='',img=FQcDyXLCHlfVbevWqJphwMUjdknBzm,infoLabels=FQcDyXLCHlfVbevWqJphwMUjdknBPS,isFolder=FQcDyXLCHlfVbevWqJphwMUjdknBKa,params=FQcDyXLCHlfVbevWqJphwMUjdknBui)
   xbmcplugin.setContent(FQcDyXLCHlfVbevWqJphwMUjdknBSK._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(FQcDyXLCHlfVbevWqJphwMUjdknBSK._addon_handle,cacheToDisc=FQcDyXLCHlfVbevWqJphwMUjdknBKG)
  else:
   FQcDyXLCHlfVbevWqJphwMUjdknBzK={'programid':FQcDyXLCHlfVbevWqJphwMUjdknBzu,'programnm':FQcDyXLCHlfVbevWqJphwMUjdknBzS,'season':FQcDyXLCHlfVbevWqJphwMUjdknBPO,'programimg':FQcDyXLCHlfVbevWqJphwMUjdknBPm,}
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.dp_Episode_List(FQcDyXLCHlfVbevWqJphwMUjdknBzK)
 def dp_Episode_List(FQcDyXLCHlfVbevWqJphwMUjdknBSK,args):
  FQcDyXLCHlfVbevWqJphwMUjdknBzu =args.get('programid')
  FQcDyXLCHlfVbevWqJphwMUjdknBzS =args.get('programnm')
  FQcDyXLCHlfVbevWqJphwMUjdknBzi =args.get('season')
  FQcDyXLCHlfVbevWqJphwMUjdknBzs =args.get('programimg')
  FQcDyXLCHlfVbevWqJphwMUjdknBzt=FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.Get_Episode_List(FQcDyXLCHlfVbevWqJphwMUjdknBzu,FQcDyXLCHlfVbevWqJphwMUjdknBzi)
  for FQcDyXLCHlfVbevWqJphwMUjdknBzP in FQcDyXLCHlfVbevWqJphwMUjdknBzt:
   FQcDyXLCHlfVbevWqJphwMUjdknBzI =FQcDyXLCHlfVbevWqJphwMUjdknBzP.get('title')
   FQcDyXLCHlfVbevWqJphwMUjdknBzx =FQcDyXLCHlfVbevWqJphwMUjdknBzP.get('id')
   FQcDyXLCHlfVbevWqJphwMUjdknBPK =FQcDyXLCHlfVbevWqJphwMUjdknBzP.get('asis')
   FQcDyXLCHlfVbevWqJphwMUjdknBPm =FQcDyXLCHlfVbevWqJphwMUjdknBzP.get('thumbnail')
   FQcDyXLCHlfVbevWqJphwMUjdknBPT =FQcDyXLCHlfVbevWqJphwMUjdknBzP.get('mpaa')
   FQcDyXLCHlfVbevWqJphwMUjdknBPI =FQcDyXLCHlfVbevWqJphwMUjdknBzP.get('duration')
   FQcDyXLCHlfVbevWqJphwMUjdknBPr =FQcDyXLCHlfVbevWqJphwMUjdknBzP.get('year')
   FQcDyXLCHlfVbevWqJphwMUjdknBzA =FQcDyXLCHlfVbevWqJphwMUjdknBzP.get('episode')
   FQcDyXLCHlfVbevWqJphwMUjdknBPE =FQcDyXLCHlfVbevWqJphwMUjdknBzP.get('genreList')
   FQcDyXLCHlfVbevWqJphwMUjdknBzT =FQcDyXLCHlfVbevWqJphwMUjdknBzP.get('desc')
   FQcDyXLCHlfVbevWqJphwMUjdknBzR ='%sx%s'%(FQcDyXLCHlfVbevWqJphwMUjdknBzi,FQcDyXLCHlfVbevWqJphwMUjdknBzA)
   FQcDyXLCHlfVbevWqJphwMUjdknBuP ='%s. %s'%(FQcDyXLCHlfVbevWqJphwMUjdknBzR,FQcDyXLCHlfVbevWqJphwMUjdknBzI)
   FQcDyXLCHlfVbevWqJphwMUjdknBPS={'mediatype':'episode','mpaa':FQcDyXLCHlfVbevWqJphwMUjdknBPT,'genre':FQcDyXLCHlfVbevWqJphwMUjdknBPE,'duration':FQcDyXLCHlfVbevWqJphwMUjdknBPI,'year':FQcDyXLCHlfVbevWqJphwMUjdknBPr,'plot':'%s (%s)\n\n%s'%(FQcDyXLCHlfVbevWqJphwMUjdknBzS,FQcDyXLCHlfVbevWqJphwMUjdknBzR,FQcDyXLCHlfVbevWqJphwMUjdknBzT),}
   FQcDyXLCHlfVbevWqJphwMUjdknBui={'mode':'VOD','programid':FQcDyXLCHlfVbevWqJphwMUjdknBzu,'programnm':FQcDyXLCHlfVbevWqJphwMUjdknBzS,'title':FQcDyXLCHlfVbevWqJphwMUjdknBuP,'season':FQcDyXLCHlfVbevWqJphwMUjdknBzi,'id':FQcDyXLCHlfVbevWqJphwMUjdknBzx,'asis':FQcDyXLCHlfVbevWqJphwMUjdknBPK,'thumbnail':FQcDyXLCHlfVbevWqJphwMUjdknBPm,'programimg':FQcDyXLCHlfVbevWqJphwMUjdknBzs,}
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.add_dir(FQcDyXLCHlfVbevWqJphwMUjdknBuP,sublabel='',img=FQcDyXLCHlfVbevWqJphwMUjdknBPm,infoLabels=FQcDyXLCHlfVbevWqJphwMUjdknBPS,isFolder=FQcDyXLCHlfVbevWqJphwMUjdknBKG,params=FQcDyXLCHlfVbevWqJphwMUjdknBui)
  xbmcplugin.setContent(FQcDyXLCHlfVbevWqJphwMUjdknBSK._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(FQcDyXLCHlfVbevWqJphwMUjdknBSK._addon_handle,cacheToDisc=FQcDyXLCHlfVbevWqJphwMUjdknBKG)
 def play_VIDEO(FQcDyXLCHlfVbevWqJphwMUjdknBSK,args):
  FQcDyXLCHlfVbevWqJphwMUjdknBzr =args.get('id')
  FQcDyXLCHlfVbevWqJphwMUjdknBPK =args.get('asis')
  if FQcDyXLCHlfVbevWqJphwMUjdknBPK in['HIGHLIGHT']:
   FQcDyXLCHlfVbevWqJphwMUjdknBzO,FQcDyXLCHlfVbevWqJphwMUjdknBzE=FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.GetEventURL(FQcDyXLCHlfVbevWqJphwMUjdknBzr,FQcDyXLCHlfVbevWqJphwMUjdknBPK)
  elif FQcDyXLCHlfVbevWqJphwMUjdknBPK in['LIVE']:
   FQcDyXLCHlfVbevWqJphwMUjdknBzO,FQcDyXLCHlfVbevWqJphwMUjdknBzE=FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.GetEventURL_Live(FQcDyXLCHlfVbevWqJphwMUjdknBzr,FQcDyXLCHlfVbevWqJphwMUjdknBPK)
  else:
   FQcDyXLCHlfVbevWqJphwMUjdknBzO,FQcDyXLCHlfVbevWqJphwMUjdknBzE=FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.GetBroadURL(FQcDyXLCHlfVbevWqJphwMUjdknBzr)
  FQcDyXLCHlfVbevWqJphwMUjdknBSK.addon_log('asis, url : %s - %s - %s'%(FQcDyXLCHlfVbevWqJphwMUjdknBPK,FQcDyXLCHlfVbevWqJphwMUjdknBzr,FQcDyXLCHlfVbevWqJphwMUjdknBzO))
  if FQcDyXLCHlfVbevWqJphwMUjdknBzO=='':
   if FQcDyXLCHlfVbevWqJphwMUjdknBzE=='':
    FQcDyXLCHlfVbevWqJphwMUjdknBSK.addon_noti(__language__(30907).encode('utf8'))
   else:
    FQcDyXLCHlfVbevWqJphwMUjdknBSK.addon_noti(FQcDyXLCHlfVbevWqJphwMUjdknBzE)
   return
  FQcDyXLCHlfVbevWqJphwMUjdknBzN='PCID=%s;token=%s;member_srl=%s;NEXT_LOCALE=%s;bm_mi=%s;ak_bmsc=%s;bm_sv=%s'%(FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.CP['SESSION']['PCID'],FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.CP['SESSION']['token'],FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.CP['SESSION']['member_srl'],FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.CP['SESSION']['NEXT_LOCALE'],FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.CP['SESSION']['bm_mi'],FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.CP['SESSION']['ak_bmsc'],FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.CP['SESSION']['bm_sv'],)
  FQcDyXLCHlfVbevWqJphwMUjdknBzo='https://www.coupangplay.com/play/'+FQcDyXLCHlfVbevWqJphwMUjdknBzr 
  FQcDyXLCHlfVbevWqJphwMUjdknBzG,FQcDyXLCHlfVbevWqJphwMUjdknBza,FQcDyXLCHlfVbevWqJphwMUjdknBzg=FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.Make_authHeader()
  FQcDyXLCHlfVbevWqJphwMUjdknBzY=FQcDyXLCHlfVbevWqJphwMUjdknBzO 
  FQcDyXLCHlfVbevWqJphwMUjdknBSK.addon_log('tobe, surl : %s'%(FQcDyXLCHlfVbevWqJphwMUjdknBzY))
  FQcDyXLCHlfVbevWqJphwMUjdknBmS=xbmcgui.ListItem(path=FQcDyXLCHlfVbevWqJphwMUjdknBzY)
  FQcDyXLCHlfVbevWqJphwMUjdknBmu=FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.Get_Url_PostFix(FQcDyXLCHlfVbevWqJphwMUjdknBzO) 
  FQcDyXLCHlfVbevWqJphwMUjdknBSK.addon_log('post_fix : '+FQcDyXLCHlfVbevWqJphwMUjdknBmu)
  if FQcDyXLCHlfVbevWqJphwMUjdknBzE:
   FQcDyXLCHlfVbevWqJphwMUjdknBmP =FQcDyXLCHlfVbevWqJphwMUjdknBzE 
   if FQcDyXLCHlfVbevWqJphwMUjdknBmu=='m3u8':
    FQcDyXLCHlfVbevWqJphwMUjdknBmz ='hls' 
   else:
    FQcDyXLCHlfVbevWqJphwMUjdknBmz ='mpd' 
   FQcDyXLCHlfVbevWqJphwMUjdknBmK ='com.widevine.alpha'
   FQcDyXLCHlfVbevWqJphwMUjdknBmi =inputstreamhelper.Helper(FQcDyXLCHlfVbevWqJphwMUjdknBmz,drm='widevine')
   if FQcDyXLCHlfVbevWqJphwMUjdknBmi.check_inputstream():
    FQcDyXLCHlfVbevWqJphwMUjdknBms={'traceparent':FQcDyXLCHlfVbevWqJphwMUjdknBzG,'tracestate':FQcDyXLCHlfVbevWqJphwMUjdknBza,'newrelic':FQcDyXLCHlfVbevWqJphwMUjdknBzg,'User-Agent':FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.USER_AGENT,'Referer':FQcDyXLCHlfVbevWqJphwMUjdknBzo,'Cookie':FQcDyXLCHlfVbevWqJphwMUjdknBzN,}
    FQcDyXLCHlfVbevWqJphwMUjdknBmt=FQcDyXLCHlfVbevWqJphwMUjdknBmP+'|'+urllib.parse.urlencode(FQcDyXLCHlfVbevWqJphwMUjdknBms)+'|R{SSM}|'
    FQcDyXLCHlfVbevWqJphwMUjdknBmS.setProperty('inputstream',FQcDyXLCHlfVbevWqJphwMUjdknBmi.inputstream_addon)
    FQcDyXLCHlfVbevWqJphwMUjdknBmS.setProperty('inputstream.adaptive.manifest_type',FQcDyXLCHlfVbevWqJphwMUjdknBmz)
    FQcDyXLCHlfVbevWqJphwMUjdknBmS.setProperty('inputstream.adaptive.license_type',FQcDyXLCHlfVbevWqJphwMUjdknBmK)
    FQcDyXLCHlfVbevWqJphwMUjdknBmS.setProperty('inputstream.adaptive.license_key',FQcDyXLCHlfVbevWqJphwMUjdknBmt)
    FQcDyXLCHlfVbevWqJphwMUjdknBmS.setProperty('inputstream.adaptive.stream_headers','User-Agent={}&Cookie={}&Referer={}&traceparent={}&tracestate={}&newrelic={}'.format(FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.USER_AGENT,FQcDyXLCHlfVbevWqJphwMUjdknBzN,FQcDyXLCHlfVbevWqJphwMUjdknBzo,FQcDyXLCHlfVbevWqJphwMUjdknBzG,FQcDyXLCHlfVbevWqJphwMUjdknBza,FQcDyXLCHlfVbevWqJphwMUjdknBzg))
    FQcDyXLCHlfVbevWqJphwMUjdknBmS.setMimeType('application/dash+xml')
    FQcDyXLCHlfVbevWqJphwMUjdknBmS.setContentLookup(FQcDyXLCHlfVbevWqJphwMUjdknBKG)
  else:
   FQcDyXLCHlfVbevWqJphwMUjdknBmS.setContentLookup(FQcDyXLCHlfVbevWqJphwMUjdknBKG)
   FQcDyXLCHlfVbevWqJphwMUjdknBmS.setMimeType('application/x-mpegURL')
   FQcDyXLCHlfVbevWqJphwMUjdknBmS.setProperty('inputstream','inputstream.adaptive')
   if FQcDyXLCHlfVbevWqJphwMUjdknBmu=='m3u8':
    FQcDyXLCHlfVbevWqJphwMUjdknBmS.setProperty('inputstream.adaptive.manifest_type','hls')
   else:
    FQcDyXLCHlfVbevWqJphwMUjdknBmS.setProperty('inputstream.adaptive.manifest_type','mpd')
   FQcDyXLCHlfVbevWqJphwMUjdknBmS.setProperty('inputstream.adaptive.stream_headers','User-Agent={}&Cookie={}&Referer={}&traceparent={}&tracestate={}&newrelic={}'.format(FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.USER_AGENT,FQcDyXLCHlfVbevWqJphwMUjdknBzN,FQcDyXLCHlfVbevWqJphwMUjdknBzo,FQcDyXLCHlfVbevWqJphwMUjdknBzG,FQcDyXLCHlfVbevWqJphwMUjdknBza,FQcDyXLCHlfVbevWqJphwMUjdknBzg))
  xbmcplugin.setResolvedUrl(FQcDyXLCHlfVbevWqJphwMUjdknBSK._addon_handle,FQcDyXLCHlfVbevWqJphwMUjdknBKa,FQcDyXLCHlfVbevWqJphwMUjdknBmS)
  try:
   if FQcDyXLCHlfVbevWqJphwMUjdknBPK=='MOVIE':
    FQcDyXLCHlfVbevWqJphwMUjdknBmI='movie'
    FQcDyXLCHlfVbevWqJphwMUjdknBui={'code':FQcDyXLCHlfVbevWqJphwMUjdknBzr,'asis':FQcDyXLCHlfVbevWqJphwMUjdknBPK,'title':args.get('title'),'img':args.get('thumbnail'),}
    FQcDyXLCHlfVbevWqJphwMUjdknBSK.Save_Watched_List(FQcDyXLCHlfVbevWqJphwMUjdknBmI,FQcDyXLCHlfVbevWqJphwMUjdknBui)
   elif FQcDyXLCHlfVbevWqJphwMUjdknBPK=='TVSHOW':
    FQcDyXLCHlfVbevWqJphwMUjdknBmI='tvshow'
    FQcDyXLCHlfVbevWqJphwMUjdknBui={'code':args.get('programid'),'asis':FQcDyXLCHlfVbevWqJphwMUjdknBPK,'title':'%s <%s>'%(args.get('title'),args.get('programnm')),'img':args.get('programimg'),}
    FQcDyXLCHlfVbevWqJphwMUjdknBSK.Save_Watched_List(FQcDyXLCHlfVbevWqJphwMUjdknBmI,FQcDyXLCHlfVbevWqJphwMUjdknBui)
  except:
   FQcDyXLCHlfVbevWqJphwMUjdknBKo
 def dp_Global_Search(FQcDyXLCHlfVbevWqJphwMUjdknBSK,args):
  FQcDyXLCHlfVbevWqJphwMUjdknBPN=args.get('mode')
  if FQcDyXLCHlfVbevWqJphwMUjdknBPN=='TOTAL_SEARCH':
   FQcDyXLCHlfVbevWqJphwMUjdknBmx='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   FQcDyXLCHlfVbevWqJphwMUjdknBmx='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(FQcDyXLCHlfVbevWqJphwMUjdknBmx)
 def dp_Bookmark_Menu(FQcDyXLCHlfVbevWqJphwMUjdknBSK,args):
  FQcDyXLCHlfVbevWqJphwMUjdknBmx='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(FQcDyXLCHlfVbevWqJphwMUjdknBmx)
 def dp_Search_List(FQcDyXLCHlfVbevWqJphwMUjdknBSK,args):
  FQcDyXLCHlfVbevWqJphwMUjdknBPx =FQcDyXLCHlfVbevWqJphwMUjdknBiS(args.get('page'))
  if 'search_key' in args:
   FQcDyXLCHlfVbevWqJphwMUjdknBmA=args.get('search_key')
  else:
   FQcDyXLCHlfVbevWqJphwMUjdknBmA=FQcDyXLCHlfVbevWqJphwMUjdknBSK.get_keyboard_input(__language__(30908).encode('utf-8'))
   if not FQcDyXLCHlfVbevWqJphwMUjdknBmA:
    return
  FQcDyXLCHlfVbevWqJphwMUjdknBmT,FQcDyXLCHlfVbevWqJphwMUjdknBPA=FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.Get_Search_List(FQcDyXLCHlfVbevWqJphwMUjdknBmA,FQcDyXLCHlfVbevWqJphwMUjdknBPx)
  for FQcDyXLCHlfVbevWqJphwMUjdknBmR in FQcDyXLCHlfVbevWqJphwMUjdknBmT:
   FQcDyXLCHlfVbevWqJphwMUjdknBim =FQcDyXLCHlfVbevWqJphwMUjdknBmR.get('id')
   FQcDyXLCHlfVbevWqJphwMUjdknBuP =FQcDyXLCHlfVbevWqJphwMUjdknBmR.get('title')
   FQcDyXLCHlfVbevWqJphwMUjdknBPK =FQcDyXLCHlfVbevWqJphwMUjdknBmR.get('asis')
   FQcDyXLCHlfVbevWqJphwMUjdknBPm =FQcDyXLCHlfVbevWqJphwMUjdknBmR.get('thumbnail')
   FQcDyXLCHlfVbevWqJphwMUjdknBPT =FQcDyXLCHlfVbevWqJphwMUjdknBmR.get('mpaa')
   FQcDyXLCHlfVbevWqJphwMUjdknBPr =FQcDyXLCHlfVbevWqJphwMUjdknBmR.get('year')
   FQcDyXLCHlfVbevWqJphwMUjdknBPI =FQcDyXLCHlfVbevWqJphwMUjdknBmR.get('duration')
   FQcDyXLCHlfVbevWqJphwMUjdknBPR =FQcDyXLCHlfVbevWqJphwMUjdknBmR.get('badge')
   if FQcDyXLCHlfVbevWqJphwMUjdknBPK=='TVSHOW': 
    FQcDyXLCHlfVbevWqJphwMUjdknBPN ='SEASON_LIST'
    FQcDyXLCHlfVbevWqJphwMUjdknBPS={'mediatype':'tvshow','title':FQcDyXLCHlfVbevWqJphwMUjdknBuP,'mpaa':FQcDyXLCHlfVbevWqJphwMUjdknBPT,'year':FQcDyXLCHlfVbevWqJphwMUjdknBPr,'plot':'Year : %s'%(FQcDyXLCHlfVbevWqJphwMUjdknBPr),}
    FQcDyXLCHlfVbevWqJphwMUjdknBus =FQcDyXLCHlfVbevWqJphwMUjdknBKa
   elif FQcDyXLCHlfVbevWqJphwMUjdknBPK=='MOVIE':
    FQcDyXLCHlfVbevWqJphwMUjdknBPN ='MOVIE'
    FQcDyXLCHlfVbevWqJphwMUjdknBPS={'mediatype':'movie','title':FQcDyXLCHlfVbevWqJphwMUjdknBuP,'mpaa':FQcDyXLCHlfVbevWqJphwMUjdknBPT,'duration':FQcDyXLCHlfVbevWqJphwMUjdknBPI,'year':FQcDyXLCHlfVbevWqJphwMUjdknBPr,'plot':'(%s)'%(FQcDyXLCHlfVbevWqJphwMUjdknBPT),}
    FQcDyXLCHlfVbevWqJphwMUjdknBus =FQcDyXLCHlfVbevWqJphwMUjdknBKG
    FQcDyXLCHlfVbevWqJphwMUjdknBuP +=' (%s)'%(FQcDyXLCHlfVbevWqJphwMUjdknBiz(FQcDyXLCHlfVbevWqJphwMUjdknBPr))
   elif FQcDyXLCHlfVbevWqJphwMUjdknBPK=='HIGHLIGHT':
    FQcDyXLCHlfVbevWqJphwMUjdknBPN ='HIGHLIGHT'
    FQcDyXLCHlfVbevWqJphwMUjdknBPS={'mediatype':'episode','title':FQcDyXLCHlfVbevWqJphwMUjdknBuP,'duration':FQcDyXLCHlfVbevWqJphwMUjdknBPI,'plot':FQcDyXLCHlfVbevWqJphwMUjdknBPN,}
    FQcDyXLCHlfVbevWqJphwMUjdknBus =FQcDyXLCHlfVbevWqJphwMUjdknBKG
   elif FQcDyXLCHlfVbevWqJphwMUjdknBPK=='LIVE':
    FQcDyXLCHlfVbevWqJphwMUjdknBPN ='LIVE'
    FQcDyXLCHlfVbevWqJphwMUjdknBPS={'mediatype':'episode','title':FQcDyXLCHlfVbevWqJphwMUjdknBuP,'plot':FQcDyXLCHlfVbevWqJphwMUjdknBPN,}
    FQcDyXLCHlfVbevWqJphwMUjdknBus =FQcDyXLCHlfVbevWqJphwMUjdknBKG
   FQcDyXLCHlfVbevWqJphwMUjdknBui={'mode':FQcDyXLCHlfVbevWqJphwMUjdknBPN,'id':FQcDyXLCHlfVbevWqJphwMUjdknBim,'asis':FQcDyXLCHlfVbevWqJphwMUjdknBPK,'seasonList':'','title':FQcDyXLCHlfVbevWqJphwMUjdknBuP,'thumbnail':json.dumps(FQcDyXLCHlfVbevWqJphwMUjdknBPm,separators=(',',':')),'year':FQcDyXLCHlfVbevWqJphwMUjdknBPr,}
   if FQcDyXLCHlfVbevWqJphwMUjdknBSK.get_settings_makebookmark()and FQcDyXLCHlfVbevWqJphwMUjdknBPK not in['HIGHLIGHT','']:
    FQcDyXLCHlfVbevWqJphwMUjdknBPo={'videoid':FQcDyXLCHlfVbevWqJphwMUjdknBim,'vidtype':'movie' if FQcDyXLCHlfVbevWqJphwMUjdknBPK=='MOVIE' else 'tvshow','vtitle':FQcDyXLCHlfVbevWqJphwMUjdknBuP,'vsubtitle':'',}
    FQcDyXLCHlfVbevWqJphwMUjdknBPG=json.dumps(FQcDyXLCHlfVbevWqJphwMUjdknBPo)
    FQcDyXLCHlfVbevWqJphwMUjdknBPG=urllib.parse.quote(FQcDyXLCHlfVbevWqJphwMUjdknBPG)
    FQcDyXLCHlfVbevWqJphwMUjdknBPa='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(FQcDyXLCHlfVbevWqJphwMUjdknBPG)
    FQcDyXLCHlfVbevWqJphwMUjdknBPg=[('(통합) 찜 영상에 추가',FQcDyXLCHlfVbevWqJphwMUjdknBPa)]
   else:
    FQcDyXLCHlfVbevWqJphwMUjdknBPg=FQcDyXLCHlfVbevWqJphwMUjdknBKo
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.add_dir(FQcDyXLCHlfVbevWqJphwMUjdknBuP,sublabel=FQcDyXLCHlfVbevWqJphwMUjdknBPR,img=FQcDyXLCHlfVbevWqJphwMUjdknBPm,infoLabels=FQcDyXLCHlfVbevWqJphwMUjdknBPS,isFolder=FQcDyXLCHlfVbevWqJphwMUjdknBus,params=FQcDyXLCHlfVbevWqJphwMUjdknBui,ContextMenu=FQcDyXLCHlfVbevWqJphwMUjdknBPg)
  if FQcDyXLCHlfVbevWqJphwMUjdknBPA:
   FQcDyXLCHlfVbevWqJphwMUjdknBui={}
   FQcDyXLCHlfVbevWqJphwMUjdknBui['mode'] ='LOCAL_SEARCH'
   FQcDyXLCHlfVbevWqJphwMUjdknBui['search_key']=FQcDyXLCHlfVbevWqJphwMUjdknBmA
   FQcDyXLCHlfVbevWqJphwMUjdknBui['page'] =FQcDyXLCHlfVbevWqJphwMUjdknBiz(FQcDyXLCHlfVbevWqJphwMUjdknBPx+1)
   FQcDyXLCHlfVbevWqJphwMUjdknBuP='[B]%s >>[/B]'%'다음 페이지'
   FQcDyXLCHlfVbevWqJphwMUjdknBPY=FQcDyXLCHlfVbevWqJphwMUjdknBiz(FQcDyXLCHlfVbevWqJphwMUjdknBPx+1)
   FQcDyXLCHlfVbevWqJphwMUjdknBuK=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.add_dir(FQcDyXLCHlfVbevWqJphwMUjdknBuP,sublabel=FQcDyXLCHlfVbevWqJphwMUjdknBPY,img=FQcDyXLCHlfVbevWqJphwMUjdknBuK,infoLabels=FQcDyXLCHlfVbevWqJphwMUjdknBKo,isFolder=FQcDyXLCHlfVbevWqJphwMUjdknBKa,params=FQcDyXLCHlfVbevWqJphwMUjdknBui)
  xbmcplugin.setContent(FQcDyXLCHlfVbevWqJphwMUjdknBSK._addon_handle,'movies')
  xbmcplugin.endOfDirectory(FQcDyXLCHlfVbevWqJphwMUjdknBSK._addon_handle,cacheToDisc=FQcDyXLCHlfVbevWqJphwMUjdknBKa)
  if args.get('historyyn')=='Y':FQcDyXLCHlfVbevWqJphwMUjdknBSK.Save_Searched_List(FQcDyXLCHlfVbevWqJphwMUjdknBmA)
 def Load_List_File(FQcDyXLCHlfVbevWqJphwMUjdknBSK,FQcDyXLCHlfVbevWqJphwMUjdknBmI): 
  try:
   if FQcDyXLCHlfVbevWqJphwMUjdknBmI=='search':
    FQcDyXLCHlfVbevWqJphwMUjdknBmr=FQcDyXLCHlfVbevWqJphwMUjdknBSm
   elif FQcDyXLCHlfVbevWqJphwMUjdknBmI in['tvshow','movie']:
    FQcDyXLCHlfVbevWqJphwMUjdknBmr=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%FQcDyXLCHlfVbevWqJphwMUjdknBmI))
   else:
    return[]
   fp=FQcDyXLCHlfVbevWqJphwMUjdknBiu(FQcDyXLCHlfVbevWqJphwMUjdknBmr,'r',-1,'utf-8')
   FQcDyXLCHlfVbevWqJphwMUjdknBmO=fp.readlines()
   fp.close()
  except:
   FQcDyXLCHlfVbevWqJphwMUjdknBmO=[]
  return FQcDyXLCHlfVbevWqJphwMUjdknBmO
 def Save_Watched_List(FQcDyXLCHlfVbevWqJphwMUjdknBSK,FQcDyXLCHlfVbevWqJphwMUjdknBmI,FQcDyXLCHlfVbevWqJphwMUjdknBSt):
  try:
   FQcDyXLCHlfVbevWqJphwMUjdknBmE=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%FQcDyXLCHlfVbevWqJphwMUjdknBmI))
   FQcDyXLCHlfVbevWqJphwMUjdknBmN=FQcDyXLCHlfVbevWqJphwMUjdknBSK.Load_List_File(FQcDyXLCHlfVbevWqJphwMUjdknBmI) 
   fp=FQcDyXLCHlfVbevWqJphwMUjdknBiu(FQcDyXLCHlfVbevWqJphwMUjdknBmE,'w',-1,'utf-8')
   FQcDyXLCHlfVbevWqJphwMUjdknBmo=urllib.parse.urlencode(FQcDyXLCHlfVbevWqJphwMUjdknBSt)
   FQcDyXLCHlfVbevWqJphwMUjdknBmo=FQcDyXLCHlfVbevWqJphwMUjdknBmo+'\n'
   fp.write(FQcDyXLCHlfVbevWqJphwMUjdknBmo)
   FQcDyXLCHlfVbevWqJphwMUjdknBmG=0
   for FQcDyXLCHlfVbevWqJphwMUjdknBma in FQcDyXLCHlfVbevWqJphwMUjdknBmN:
    FQcDyXLCHlfVbevWqJphwMUjdknBmg=FQcDyXLCHlfVbevWqJphwMUjdknBKY(urllib.parse.parse_qsl(FQcDyXLCHlfVbevWqJphwMUjdknBma))
    FQcDyXLCHlfVbevWqJphwMUjdknBmY=FQcDyXLCHlfVbevWqJphwMUjdknBSt.get('code').strip()
    FQcDyXLCHlfVbevWqJphwMUjdknBKS=FQcDyXLCHlfVbevWqJphwMUjdknBmg.get('code').strip()
    if FQcDyXLCHlfVbevWqJphwMUjdknBmY!=FQcDyXLCHlfVbevWqJphwMUjdknBKS:
     fp.write(FQcDyXLCHlfVbevWqJphwMUjdknBma)
     FQcDyXLCHlfVbevWqJphwMUjdknBmG+=1
     if FQcDyXLCHlfVbevWqJphwMUjdknBmG>=50:break
   fp.close()
  except:
   FQcDyXLCHlfVbevWqJphwMUjdknBKo
 def Save_Searched_List(FQcDyXLCHlfVbevWqJphwMUjdknBSK,FQcDyXLCHlfVbevWqJphwMUjdknBmA):
  try:
   FQcDyXLCHlfVbevWqJphwMUjdknBmA=FQcDyXLCHlfVbevWqJphwMUjdknBmA.strip()
   FQcDyXLCHlfVbevWqJphwMUjdknBmN=FQcDyXLCHlfVbevWqJphwMUjdknBSK.Load_List_File('search') 
   fp=FQcDyXLCHlfVbevWqJphwMUjdknBiu(FQcDyXLCHlfVbevWqJphwMUjdknBSm,'w',-1,'utf-8')
   fp.write(FQcDyXLCHlfVbevWqJphwMUjdknBmA+'\n')
   FQcDyXLCHlfVbevWqJphwMUjdknBmG=0
   for FQcDyXLCHlfVbevWqJphwMUjdknBma in FQcDyXLCHlfVbevWqJphwMUjdknBmN:
    FQcDyXLCHlfVbevWqJphwMUjdknBma=FQcDyXLCHlfVbevWqJphwMUjdknBma.strip()
    if FQcDyXLCHlfVbevWqJphwMUjdknBmA!=FQcDyXLCHlfVbevWqJphwMUjdknBma:
     fp.write(FQcDyXLCHlfVbevWqJphwMUjdknBma+'\n')
     FQcDyXLCHlfVbevWqJphwMUjdknBmG+=1
     if FQcDyXLCHlfVbevWqJphwMUjdknBmG>=50:break
   fp.close()
  except:
   FQcDyXLCHlfVbevWqJphwMUjdknBKo
 def dp_Search_History(FQcDyXLCHlfVbevWqJphwMUjdknBSK,args):
  FQcDyXLCHlfVbevWqJphwMUjdknBKu=FQcDyXLCHlfVbevWqJphwMUjdknBSK.Load_List_File('search')
  for FQcDyXLCHlfVbevWqJphwMUjdknBKP in FQcDyXLCHlfVbevWqJphwMUjdknBKu:
   FQcDyXLCHlfVbevWqJphwMUjdknBKP=FQcDyXLCHlfVbevWqJphwMUjdknBKP.strip()
   FQcDyXLCHlfVbevWqJphwMUjdknBui={'mode':'LOCAL_SEARCH','search_key':FQcDyXLCHlfVbevWqJphwMUjdknBKP,'page':'1','historyyn':'Y',}
   FQcDyXLCHlfVbevWqJphwMUjdknBKz={'mode':'SEARCH_REMOVE','stype':'ONE','skey':FQcDyXLCHlfVbevWqJphwMUjdknBKP,}
   FQcDyXLCHlfVbevWqJphwMUjdknBKm=urllib.parse.urlencode(FQcDyXLCHlfVbevWqJphwMUjdknBKz)
   FQcDyXLCHlfVbevWqJphwMUjdknBPg=[('선택된 검색어 ( %s ) 삭제'%(FQcDyXLCHlfVbevWqJphwMUjdknBKP),'RunPlugin(plugin://plugin.video.coupangm/?%s)'%(FQcDyXLCHlfVbevWqJphwMUjdknBKm))]
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.add_dir(FQcDyXLCHlfVbevWqJphwMUjdknBKP,sublabel='',img=FQcDyXLCHlfVbevWqJphwMUjdknBKo,infoLabels=FQcDyXLCHlfVbevWqJphwMUjdknBKo,isFolder=FQcDyXLCHlfVbevWqJphwMUjdknBKa,params=FQcDyXLCHlfVbevWqJphwMUjdknBui,ContextMenu=FQcDyXLCHlfVbevWqJphwMUjdknBPg)
  FQcDyXLCHlfVbevWqJphwMUjdknBPS={'plot':'검색목록 전체를 삭제합니다.'}
  FQcDyXLCHlfVbevWqJphwMUjdknBuP='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  FQcDyXLCHlfVbevWqJphwMUjdknBui={'mode':'SEARCH_REMOVE','stype':'ALL','skey':'-',}
  FQcDyXLCHlfVbevWqJphwMUjdknBuK=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  FQcDyXLCHlfVbevWqJphwMUjdknBSK.add_dir(FQcDyXLCHlfVbevWqJphwMUjdknBuP,sublabel='',img=FQcDyXLCHlfVbevWqJphwMUjdknBuK,infoLabels=FQcDyXLCHlfVbevWqJphwMUjdknBPS,isFolder=FQcDyXLCHlfVbevWqJphwMUjdknBKG,params=FQcDyXLCHlfVbevWqJphwMUjdknBui,isLink=FQcDyXLCHlfVbevWqJphwMUjdknBKa)
  xbmcplugin.endOfDirectory(FQcDyXLCHlfVbevWqJphwMUjdknBSK._addon_handle,cacheToDisc=FQcDyXLCHlfVbevWqJphwMUjdknBKG)
 def dp_Listfile_Delete(FQcDyXLCHlfVbevWqJphwMUjdknBSK,args):
  FQcDyXLCHlfVbevWqJphwMUjdknBmI=args.get('stype')
  FQcDyXLCHlfVbevWqJphwMUjdknBKi =args.get('skey')
  FQcDyXLCHlfVbevWqJphwMUjdknBSx=xbmcgui.Dialog()
  if FQcDyXLCHlfVbevWqJphwMUjdknBmI=='ALL':
   FQcDyXLCHlfVbevWqJphwMUjdknBux=FQcDyXLCHlfVbevWqJphwMUjdknBSx.yesno(__language__(30911).encode('utf8'),__language__(30906).encode('utf8'))
  elif FQcDyXLCHlfVbevWqJphwMUjdknBmI=='ONE':
   FQcDyXLCHlfVbevWqJphwMUjdknBux=FQcDyXLCHlfVbevWqJphwMUjdknBSx.yesno(__language__(30912).encode('utf8'),__language__(30906).encode('utf8'))
  elif FQcDyXLCHlfVbevWqJphwMUjdknBmI in['tvshow','movie']:
   FQcDyXLCHlfVbevWqJphwMUjdknBux=FQcDyXLCHlfVbevWqJphwMUjdknBSx.yesno(__language__(30913).encode('utf8'),__language__(30906).encode('utf8'))
  if FQcDyXLCHlfVbevWqJphwMUjdknBux==FQcDyXLCHlfVbevWqJphwMUjdknBKG:sys.exit()
  FQcDyXLCHlfVbevWqJphwMUjdknBSK.Delete_List_File(FQcDyXLCHlfVbevWqJphwMUjdknBmI,skey=FQcDyXLCHlfVbevWqJphwMUjdknBKi)
  xbmc.executebuiltin("Container.Refresh")
 def Delete_List_File(FQcDyXLCHlfVbevWqJphwMUjdknBSK,FQcDyXLCHlfVbevWqJphwMUjdknBmI,skey='-'):
  if FQcDyXLCHlfVbevWqJphwMUjdknBmI=='ALL':
   try:
    FQcDyXLCHlfVbevWqJphwMUjdknBmr=FQcDyXLCHlfVbevWqJphwMUjdknBSm
    fp=FQcDyXLCHlfVbevWqJphwMUjdknBiu(FQcDyXLCHlfVbevWqJphwMUjdknBmr,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    FQcDyXLCHlfVbevWqJphwMUjdknBKo
  elif FQcDyXLCHlfVbevWqJphwMUjdknBmI=='ONE':
   try:
    FQcDyXLCHlfVbevWqJphwMUjdknBmr=FQcDyXLCHlfVbevWqJphwMUjdknBSm
    FQcDyXLCHlfVbevWqJphwMUjdknBmN=FQcDyXLCHlfVbevWqJphwMUjdknBSK.Load_List_File('search') 
    fp=FQcDyXLCHlfVbevWqJphwMUjdknBiu(FQcDyXLCHlfVbevWqJphwMUjdknBmr,'w',-1,'utf-8')
    for FQcDyXLCHlfVbevWqJphwMUjdknBma in FQcDyXLCHlfVbevWqJphwMUjdknBmN:
     if skey!=FQcDyXLCHlfVbevWqJphwMUjdknBma.strip():
      fp.write(FQcDyXLCHlfVbevWqJphwMUjdknBma)
    fp.close()
   except:
    FQcDyXLCHlfVbevWqJphwMUjdknBKo
  elif FQcDyXLCHlfVbevWqJphwMUjdknBmI in['tvshow','movie']:
   try:
    FQcDyXLCHlfVbevWqJphwMUjdknBmr=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%FQcDyXLCHlfVbevWqJphwMUjdknBmI))
    fp=FQcDyXLCHlfVbevWqJphwMUjdknBiu(FQcDyXLCHlfVbevWqJphwMUjdknBmr,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    FQcDyXLCHlfVbevWqJphwMUjdknBKo
 def dp_Watch_List(FQcDyXLCHlfVbevWqJphwMUjdknBSK,args):
  FQcDyXLCHlfVbevWqJphwMUjdknBmI =args.get('stype')
  if FQcDyXLCHlfVbevWqJphwMUjdknBmI in['',FQcDyXLCHlfVbevWqJphwMUjdknBKo]:
   for FQcDyXLCHlfVbevWqJphwMUjdknBKs in FQcDyXLCHlfVbevWqJphwMUjdknBSz:
    FQcDyXLCHlfVbevWqJphwMUjdknBuP=FQcDyXLCHlfVbevWqJphwMUjdknBKs.get('title')
    FQcDyXLCHlfVbevWqJphwMUjdknBui={'mode':FQcDyXLCHlfVbevWqJphwMUjdknBKs.get('mode'),'stype':FQcDyXLCHlfVbevWqJphwMUjdknBKs.get('stype'),}
    FQcDyXLCHlfVbevWqJphwMUjdknBSK.add_dir(FQcDyXLCHlfVbevWqJphwMUjdknBuP,sublabel='',img='',infoLabels=FQcDyXLCHlfVbevWqJphwMUjdknBKo,isFolder=FQcDyXLCHlfVbevWqJphwMUjdknBKa,params=FQcDyXLCHlfVbevWqJphwMUjdknBui)
   xbmcplugin.endOfDirectory(FQcDyXLCHlfVbevWqJphwMUjdknBSK._addon_handle)
  else:
   FQcDyXLCHlfVbevWqJphwMUjdknBKt=FQcDyXLCHlfVbevWqJphwMUjdknBSK.Load_List_File(FQcDyXLCHlfVbevWqJphwMUjdknBmI)
   for FQcDyXLCHlfVbevWqJphwMUjdknBKI in FQcDyXLCHlfVbevWqJphwMUjdknBKt:
    FQcDyXLCHlfVbevWqJphwMUjdknBKx=FQcDyXLCHlfVbevWqJphwMUjdknBKY(urllib.parse.parse_qsl(FQcDyXLCHlfVbevWqJphwMUjdknBKI))
    FQcDyXLCHlfVbevWqJphwMUjdknBzr =FQcDyXLCHlfVbevWqJphwMUjdknBKx.get('code').strip()
    FQcDyXLCHlfVbevWqJphwMUjdknBuP =FQcDyXLCHlfVbevWqJphwMUjdknBKx.get('title').strip()
    FQcDyXLCHlfVbevWqJphwMUjdknBPm =FQcDyXLCHlfVbevWqJphwMUjdknBKx.get('img').strip()
    FQcDyXLCHlfVbevWqJphwMUjdknBPK =FQcDyXLCHlfVbevWqJphwMUjdknBKx.get('asis').strip()
    try:
     FQcDyXLCHlfVbevWqJphwMUjdknBPm=FQcDyXLCHlfVbevWqJphwMUjdknBPm.replace('\'','\"')
     FQcDyXLCHlfVbevWqJphwMUjdknBPm=json.loads(FQcDyXLCHlfVbevWqJphwMUjdknBPm)
    except:
     FQcDyXLCHlfVbevWqJphwMUjdknBKo
    FQcDyXLCHlfVbevWqJphwMUjdknBPS={}
    FQcDyXLCHlfVbevWqJphwMUjdknBPS['plot']=FQcDyXLCHlfVbevWqJphwMUjdknBuP
    if FQcDyXLCHlfVbevWqJphwMUjdknBmI=='movie':
     FQcDyXLCHlfVbevWqJphwMUjdknBPS['mediatype']='movie'
     FQcDyXLCHlfVbevWqJphwMUjdknBui={'mode':'MOVIE','id':FQcDyXLCHlfVbevWqJphwMUjdknBzr,'asis':FQcDyXLCHlfVbevWqJphwMUjdknBPK,'title':FQcDyXLCHlfVbevWqJphwMUjdknBuP,'thumbnail':FQcDyXLCHlfVbevWqJphwMUjdknBPm,}
     FQcDyXLCHlfVbevWqJphwMUjdknBus=FQcDyXLCHlfVbevWqJphwMUjdknBKG
    else:
     FQcDyXLCHlfVbevWqJphwMUjdknBPS['mediatype']='episode'
     FQcDyXLCHlfVbevWqJphwMUjdknBui={'mode':'SEASON_LIST','id':FQcDyXLCHlfVbevWqJphwMUjdknBzr,'asis':FQcDyXLCHlfVbevWqJphwMUjdknBPK,'title':FQcDyXLCHlfVbevWqJphwMUjdknBuP,'thumbnail':json.dumps(FQcDyXLCHlfVbevWqJphwMUjdknBPm,separators=(',',':')),}
     FQcDyXLCHlfVbevWqJphwMUjdknBus=FQcDyXLCHlfVbevWqJphwMUjdknBKa
    FQcDyXLCHlfVbevWqJphwMUjdknBSK.add_dir(FQcDyXLCHlfVbevWqJphwMUjdknBuP,sublabel='',img=FQcDyXLCHlfVbevWqJphwMUjdknBPm,infoLabels=FQcDyXLCHlfVbevWqJphwMUjdknBPS,isFolder=FQcDyXLCHlfVbevWqJphwMUjdknBus,params=FQcDyXLCHlfVbevWqJphwMUjdknBui)
   FQcDyXLCHlfVbevWqJphwMUjdknBPS={'plot':'시청목록을 삭제합니다.'}
   FQcDyXLCHlfVbevWqJphwMUjdknBuP='*** 시청목록 삭제 ***'
   FQcDyXLCHlfVbevWqJphwMUjdknBui={'mode':'MYVIEW_REMOVE','stype':FQcDyXLCHlfVbevWqJphwMUjdknBmI,'skey':'-',}
   FQcDyXLCHlfVbevWqJphwMUjdknBuK=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.add_dir(FQcDyXLCHlfVbevWqJphwMUjdknBuP,sublabel='',img=FQcDyXLCHlfVbevWqJphwMUjdknBuK,infoLabels=FQcDyXLCHlfVbevWqJphwMUjdknBPS,isFolder=FQcDyXLCHlfVbevWqJphwMUjdknBKG,params=FQcDyXLCHlfVbevWqJphwMUjdknBui,isLink=FQcDyXLCHlfVbevWqJphwMUjdknBKa)
   if FQcDyXLCHlfVbevWqJphwMUjdknBmI=='movie':xbmcplugin.setContent(FQcDyXLCHlfVbevWqJphwMUjdknBSK._addon_handle,'movies')
   else:xbmcplugin.setContent(FQcDyXLCHlfVbevWqJphwMUjdknBSK._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(FQcDyXLCHlfVbevWqJphwMUjdknBSK._addon_handle,cacheToDisc=FQcDyXLCHlfVbevWqJphwMUjdknBKG)
 def dp_Set_Bookmark(FQcDyXLCHlfVbevWqJphwMUjdknBSK,args):
  FQcDyXLCHlfVbevWqJphwMUjdknBKA=urllib.parse.unquote(args.get('bm_param'))
  FQcDyXLCHlfVbevWqJphwMUjdknBKA=json.loads(FQcDyXLCHlfVbevWqJphwMUjdknBKA)
  FQcDyXLCHlfVbevWqJphwMUjdknBKT =FQcDyXLCHlfVbevWqJphwMUjdknBKA.get('videoid')
  FQcDyXLCHlfVbevWqJphwMUjdknBKR =FQcDyXLCHlfVbevWqJphwMUjdknBKA.get('vidtype')
  FQcDyXLCHlfVbevWqJphwMUjdknBKr =FQcDyXLCHlfVbevWqJphwMUjdknBKA.get('vtitle')
  FQcDyXLCHlfVbevWqJphwMUjdknBSx=xbmcgui.Dialog()
  FQcDyXLCHlfVbevWqJphwMUjdknBux=FQcDyXLCHlfVbevWqJphwMUjdknBSx.yesno(__language__(30914).encode('utf8'),FQcDyXLCHlfVbevWqJphwMUjdknBKr+' \n\n'+__language__(30915))
  if FQcDyXLCHlfVbevWqJphwMUjdknBux==FQcDyXLCHlfVbevWqJphwMUjdknBKG:return
  FQcDyXLCHlfVbevWqJphwMUjdknBKO=FQcDyXLCHlfVbevWqJphwMUjdknBSK.CoupangObj.GetBookmarkInfo(FQcDyXLCHlfVbevWqJphwMUjdknBKT,FQcDyXLCHlfVbevWqJphwMUjdknBKR)
  FQcDyXLCHlfVbevWqJphwMUjdknBKE=json.dumps(FQcDyXLCHlfVbevWqJphwMUjdknBKO)
  FQcDyXLCHlfVbevWqJphwMUjdknBKE=urllib.parse.quote(FQcDyXLCHlfVbevWqJphwMUjdknBKE)
  FQcDyXLCHlfVbevWqJphwMUjdknBPa ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(FQcDyXLCHlfVbevWqJphwMUjdknBKE)
  xbmc.executebuiltin(FQcDyXLCHlfVbevWqJphwMUjdknBPa)
 def coupang_main(FQcDyXLCHlfVbevWqJphwMUjdknBSK):
  FQcDyXLCHlfVbevWqJphwMUjdknBPN=FQcDyXLCHlfVbevWqJphwMUjdknBSK.main_params.get('mode',FQcDyXLCHlfVbevWqJphwMUjdknBKo)
  if FQcDyXLCHlfVbevWqJphwMUjdknBPN=='LOGOUT':
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.CP_logout()
   return
  FQcDyXLCHlfVbevWqJphwMUjdknBSK.option_check()
  if FQcDyXLCHlfVbevWqJphwMUjdknBPN is FQcDyXLCHlfVbevWqJphwMUjdknBKo:
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.dp_Main_List(FQcDyXLCHlfVbevWqJphwMUjdknBSK.main_params)
  elif FQcDyXLCHlfVbevWqJphwMUjdknBPN=='CATEGORY_GROUPLIST':
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.dp_Category_GroupList(FQcDyXLCHlfVbevWqJphwMUjdknBSK.main_params)
  elif FQcDyXLCHlfVbevWqJphwMUjdknBPN=='THEME_GROUPLIST':
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.dp_Theme_GroupList(FQcDyXLCHlfVbevWqJphwMUjdknBSK.main_params)
  elif FQcDyXLCHlfVbevWqJphwMUjdknBPN=='EVENT_GROUPLIST':
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.dp_Event_GroupList(FQcDyXLCHlfVbevWqJphwMUjdknBSK.main_params)
  elif FQcDyXLCHlfVbevWqJphwMUjdknBPN=='EVENT_GAMELIST':
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.dp_Event_GameList(FQcDyXLCHlfVbevWqJphwMUjdknBSK.main_params)
  elif FQcDyXLCHlfVbevWqJphwMUjdknBPN=='EVENT_LIST':
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.dp_Event_List(FQcDyXLCHlfVbevWqJphwMUjdknBSK.main_params)
  elif FQcDyXLCHlfVbevWqJphwMUjdknBPN=='CATEGORY_LIST':
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.dp_Category_List(FQcDyXLCHlfVbevWqJphwMUjdknBSK.main_params)
  elif FQcDyXLCHlfVbevWqJphwMUjdknBPN=='SEASON_LIST':
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.dp_Season_List(FQcDyXLCHlfVbevWqJphwMUjdknBSK.main_params)
  elif FQcDyXLCHlfVbevWqJphwMUjdknBPN=='EPISODE_LIST':
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.dp_Episode_List(FQcDyXLCHlfVbevWqJphwMUjdknBSK.main_params)
  elif FQcDyXLCHlfVbevWqJphwMUjdknBPN=='TEST':
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.dp_Test(FQcDyXLCHlfVbevWqJphwMUjdknBSK.main_params)
  elif FQcDyXLCHlfVbevWqJphwMUjdknBPN in['MOVIE','VOD','HIGHLIGHT','LIVE']:
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.play_VIDEO(FQcDyXLCHlfVbevWqJphwMUjdknBSK.main_params)
  elif FQcDyXLCHlfVbevWqJphwMUjdknBPN=='WATCH':
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.dp_Watch_List(FQcDyXLCHlfVbevWqJphwMUjdknBSK.main_params)
  elif FQcDyXLCHlfVbevWqJphwMUjdknBPN=='LOCAL_SEARCH':
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.dp_Search_List(FQcDyXLCHlfVbevWqJphwMUjdknBSK.main_params)
  elif FQcDyXLCHlfVbevWqJphwMUjdknBPN=='SEARCH_HISTORY':
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.dp_Search_History(FQcDyXLCHlfVbevWqJphwMUjdknBSK.main_params)
  elif FQcDyXLCHlfVbevWqJphwMUjdknBPN in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.dp_Listfile_Delete(FQcDyXLCHlfVbevWqJphwMUjdknBSK.main_params)
  elif FQcDyXLCHlfVbevWqJphwMUjdknBPN in['TOTAL_SEARCH','TOTAL_HISTORY']:
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.dp_Global_Search(FQcDyXLCHlfVbevWqJphwMUjdknBSK.main_params)
  elif FQcDyXLCHlfVbevWqJphwMUjdknBPN=='MENU_BOOKMARK':
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.dp_Bookmark_Menu(FQcDyXLCHlfVbevWqJphwMUjdknBSK.main_params)
  elif FQcDyXLCHlfVbevWqJphwMUjdknBPN=='SET_BOOKMARK':
   FQcDyXLCHlfVbevWqJphwMUjdknBSK.dp_Set_Bookmark(FQcDyXLCHlfVbevWqJphwMUjdknBSK.main_params)
  else:
   FQcDyXLCHlfVbevWqJphwMUjdknBKo
# Created by pyminifier (https://github.com/liftoff/pyminifier)
