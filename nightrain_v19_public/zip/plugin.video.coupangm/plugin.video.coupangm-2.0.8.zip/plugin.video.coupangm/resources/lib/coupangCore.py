__author__="NightRain"
JVwYHPFkcdDNLamiQOGuEptSKRoeyb=object
JVwYHPFkcdDNLamiQOGuEptSKRoeyh=None
JVwYHPFkcdDNLamiQOGuEptSKRoeyW=False
JVwYHPFkcdDNLamiQOGuEptSKRoeyI=print
JVwYHPFkcdDNLamiQOGuEptSKRoeyC=str
JVwYHPFkcdDNLamiQOGuEptSKRoeyM=open
JVwYHPFkcdDNLamiQOGuEptSKRoeyT=int
JVwYHPFkcdDNLamiQOGuEptSKRoeyn=Exception
JVwYHPFkcdDNLamiQOGuEptSKRoeyA=id
JVwYHPFkcdDNLamiQOGuEptSKRoeyf=True
JVwYHPFkcdDNLamiQOGuEptSKRoeyg=len
JVwYHPFkcdDNLamiQOGuEptSKRoeyj=range
import urllib
import re
import json
import requests
import datetime
import time
import random
import base64
class JVwYHPFkcdDNLamiQOGuEptSKRoevz(JVwYHPFkcdDNLamiQOGuEptSKRoeyb):
 def __init__(JVwYHPFkcdDNLamiQOGuEptSKRoevB):
  JVwYHPFkcdDNLamiQOGuEptSKRoevB.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.82 Safari/537.36'
  JVwYHPFkcdDNLamiQOGuEptSKRoevB.MODEL ='Chrome_98' 
  JVwYHPFkcdDNLamiQOGuEptSKRoevB.DEFAULT_HEADER ={'user-agent':JVwYHPFkcdDNLamiQOGuEptSKRoevB.USER_AGENT}
  JVwYHPFkcdDNLamiQOGuEptSKRoevB.API_DOMAIN ='https://www.coupangplay.com'
  JVwYHPFkcdDNLamiQOGuEptSKRoevB.API_VIEWURL ='https://discover.coupangstreaming.com'
  JVwYHPFkcdDNLamiQOGuEptSKRoevB.PAGE_LIMIT =40
  JVwYHPFkcdDNLamiQOGuEptSKRoevB.SEARCH_LIMIT =20
  JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP={}
  JVwYHPFkcdDNLamiQOGuEptSKRoevB.Init_CP()
  JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP_DEVICE_FILENAME=''
  JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP_COOKIE_FILENAME=''
 def callRequestCookies(JVwYHPFkcdDNLamiQOGuEptSKRoevB,jobtype,JVwYHPFkcdDNLamiQOGuEptSKRoezy,payload=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,params=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,headers=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,cookies=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,redirects=JVwYHPFkcdDNLamiQOGuEptSKRoeyW):
  JVwYHPFkcdDNLamiQOGuEptSKRoevy=JVwYHPFkcdDNLamiQOGuEptSKRoevB.DEFAULT_HEADER
  if headers:JVwYHPFkcdDNLamiQOGuEptSKRoevy.update(headers)
  if jobtype=='Get':
   JVwYHPFkcdDNLamiQOGuEptSKRoevq=requests.get(JVwYHPFkcdDNLamiQOGuEptSKRoezy,params=params,headers=JVwYHPFkcdDNLamiQOGuEptSKRoevy,cookies=cookies,allow_redirects=redirects)
  else:
   JVwYHPFkcdDNLamiQOGuEptSKRoevq=requests.post(JVwYHPFkcdDNLamiQOGuEptSKRoezy,data=payload,params=params,headers=JVwYHPFkcdDNLamiQOGuEptSKRoevy,cookies=cookies,allow_redirects=redirects)
  JVwYHPFkcdDNLamiQOGuEptSKRoeyI(JVwYHPFkcdDNLamiQOGuEptSKRoeyC(JVwYHPFkcdDNLamiQOGuEptSKRoevq.status_code)+' - '+JVwYHPFkcdDNLamiQOGuEptSKRoeyC(JVwYHPFkcdDNLamiQOGuEptSKRoevq.url))
  return JVwYHPFkcdDNLamiQOGuEptSKRoevq
 def callRequestCookies_test(JVwYHPFkcdDNLamiQOGuEptSKRoevB,jobtype,JVwYHPFkcdDNLamiQOGuEptSKRoezy,payload=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,params=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,headers=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,cookies=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,redirects=JVwYHPFkcdDNLamiQOGuEptSKRoeyW):
  JVwYHPFkcdDNLamiQOGuEptSKRoevy=JVwYHPFkcdDNLamiQOGuEptSKRoevB.DEFAULT_HEADER
  if headers:JVwYHPFkcdDNLamiQOGuEptSKRoevy.update(headers)
  JVwYHPFkcdDNLamiQOGuEptSKRoevq=requests.Request('POST',JVwYHPFkcdDNLamiQOGuEptSKRoezy,headers=headers,data=payload,params=params,cookies=cookies)
  JVwYHPFkcdDNLamiQOGuEptSKRoevx=JVwYHPFkcdDNLamiQOGuEptSKRoevq.prepare()
  JVwYHPFkcdDNLamiQOGuEptSKRoevB.pretty_print_POST(JVwYHPFkcdDNLamiQOGuEptSKRoevx)
  return JVwYHPFkcdDNLamiQOGuEptSKRoevq
 def pretty_print_POST(JVwYHPFkcdDNLamiQOGuEptSKRoevB,req):
  JVwYHPFkcdDNLamiQOGuEptSKRoeyI('{}\n{}\r\n{}\r\n\r\n{}'.format('-----------START-----------',req.method+' '+req.url,'\r\n'.join('{}: {}'.format(k,v)for k,v in req.headers.items()),req.body,))
 def dic_To_jsonfile(JVwYHPFkcdDNLamiQOGuEptSKRoevB,filename,JVwYHPFkcdDNLamiQOGuEptSKRoevU):
  if filename=='':return
  fp=JVwYHPFkcdDNLamiQOGuEptSKRoeyM(filename,'w',-1,'utf-8')
  json.dump(JVwYHPFkcdDNLamiQOGuEptSKRoevU,fp,indent=4,ensure_ascii=JVwYHPFkcdDNLamiQOGuEptSKRoeyW)
  fp.close()
 def jsonfile_To_dic(JVwYHPFkcdDNLamiQOGuEptSKRoevB,filename):
  if filename=='':return JVwYHPFkcdDNLamiQOGuEptSKRoeyh
  try:
   fp=JVwYHPFkcdDNLamiQOGuEptSKRoeyM(filename,'r',-1,'utf-8')
   JVwYHPFkcdDNLamiQOGuEptSKRoevs=json.load(fp)
   fp.close()
  except:
   JVwYHPFkcdDNLamiQOGuEptSKRoevs={}
  return JVwYHPFkcdDNLamiQOGuEptSKRoevs
 def convert_TimeStr(JVwYHPFkcdDNLamiQOGuEptSKRoevB,JVwYHPFkcdDNLamiQOGuEptSKRoevr):
  try:
   JVwYHPFkcdDNLamiQOGuEptSKRoevr =JVwYHPFkcdDNLamiQOGuEptSKRoevr[0:16]
   JVwYHPFkcdDNLamiQOGuEptSKRoevl=datetime.datetime.strptime(JVwYHPFkcdDNLamiQOGuEptSKRoevr,'%Y-%m-%dT%H:%M')+datetime.timedelta(hours=9)
   return JVwYHPFkcdDNLamiQOGuEptSKRoevl.strftime('%Y-%m-%d %H:%M')
  except:
   return JVwYHPFkcdDNLamiQOGuEptSKRoeyh
 def Get_Now_Datetime(JVwYHPFkcdDNLamiQOGuEptSKRoevB):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetNoCache(JVwYHPFkcdDNLamiQOGuEptSKRoevB):
  JVwYHPFkcdDNLamiQOGuEptSKRoevh =JVwYHPFkcdDNLamiQOGuEptSKRoeyT(time.time()*1000)
  return JVwYHPFkcdDNLamiQOGuEptSKRoevh
 def generatePcId(JVwYHPFkcdDNLamiQOGuEptSKRoevB):
  t=JVwYHPFkcdDNLamiQOGuEptSKRoevB.GetNoCache()
  r=random.random()
  JVwYHPFkcdDNLamiQOGuEptSKRoevW=JVwYHPFkcdDNLamiQOGuEptSKRoeyC(t)+JVwYHPFkcdDNLamiQOGuEptSKRoeyC(r)[2:12]
  return JVwYHPFkcdDNLamiQOGuEptSKRoevW
 def generatePvId(JVwYHPFkcdDNLamiQOGuEptSKRoevB,genType='1'):
  import hashlib
  m=hashlib.md5()
  JVwYHPFkcdDNLamiQOGuEptSKRoevI=JVwYHPFkcdDNLamiQOGuEptSKRoeyC(random.random())
  m.update(JVwYHPFkcdDNLamiQOGuEptSKRoevI.encode('utf-8'))
  JVwYHPFkcdDNLamiQOGuEptSKRoevC=JVwYHPFkcdDNLamiQOGuEptSKRoeyC(m.hexdigest())
  if genType=='1':
   return '%s-%s-%s-%s-%s'%(JVwYHPFkcdDNLamiQOGuEptSKRoevC[:8],JVwYHPFkcdDNLamiQOGuEptSKRoevC[8:12],JVwYHPFkcdDNLamiQOGuEptSKRoevC[12:16],JVwYHPFkcdDNLamiQOGuEptSKRoevC[16:20],JVwYHPFkcdDNLamiQOGuEptSKRoevC[20:])
  else:
   return JVwYHPFkcdDNLamiQOGuEptSKRoevC
 def Get_DeviceID(JVwYHPFkcdDNLamiQOGuEptSKRoevB):
  JVwYHPFkcdDNLamiQOGuEptSKRoevM=''
  try: 
   fp=JVwYHPFkcdDNLamiQOGuEptSKRoeyM(JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP_DEVICE_FILENAME,'r',-1,'utf-8')
   JVwYHPFkcdDNLamiQOGuEptSKRoevT= json.load(fp)
   fp.close()
   JVwYHPFkcdDNLamiQOGuEptSKRoevM=JVwYHPFkcdDNLamiQOGuEptSKRoevT.get('device_id')
  except JVwYHPFkcdDNLamiQOGuEptSKRoeyn as exception:
   JVwYHPFkcdDNLamiQOGuEptSKRoeyh
  if JVwYHPFkcdDNLamiQOGuEptSKRoevM=='':
   JVwYHPFkcdDNLamiQOGuEptSKRoevM=JVwYHPFkcdDNLamiQOGuEptSKRoevB.generatePvId(genType='1')
   try: 
    fp=JVwYHPFkcdDNLamiQOGuEptSKRoeyM(JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP_DEVICE_FILENAME,'w',-1,'utf-8')
    json.dump({'device_id':JVwYHPFkcdDNLamiQOGuEptSKRoevM},fp,indent=4,ensure_ascii=JVwYHPFkcdDNLamiQOGuEptSKRoeyW)
    fp.close()
   except JVwYHPFkcdDNLamiQOGuEptSKRoeyn as exception:
    return ''
  return JVwYHPFkcdDNLamiQOGuEptSKRoevM
 def Make_authHeader(JVwYHPFkcdDNLamiQOGuEptSKRoevB):
  tr=JVwYHPFkcdDNLamiQOGuEptSKRoevB.generatePvId(genType=2)
  ti=JVwYHPFkcdDNLamiQOGuEptSKRoevB.GetNoCache()
  JVwYHPFkcdDNLamiQOGuEptSKRoeyA=JVwYHPFkcdDNLamiQOGuEptSKRoevB.generatePvId(genType=2)[:16]
  JVwYHPFkcdDNLamiQOGuEptSKRoevn='00-%s-%s-01'%(tr,JVwYHPFkcdDNLamiQOGuEptSKRoeyA,)
  JVwYHPFkcdDNLamiQOGuEptSKRoevA ='%s@nr=0-1-%s-%s-%s----%s'%(JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['NREUM']['tk'],JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['NREUM']['ac'],JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['NREUM']['ap'],JVwYHPFkcdDNLamiQOGuEptSKRoeyA,ti,)
  JVwYHPFkcdDNLamiQOGuEptSKRoevf ='{"v":[0,1],"d":{"ty":"Browser","ac":"%s","ap":"%s","id":"%s","tr":"%s","ti":%s,"tk":"%s"}}'%(JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['NREUM']['ac'],JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['NREUM']['ap'],JVwYHPFkcdDNLamiQOGuEptSKRoeyA,tr,ti,JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['NREUM']['tk'],) 
  return JVwYHPFkcdDNLamiQOGuEptSKRoevn,JVwYHPFkcdDNLamiQOGuEptSKRoevA,base64.standard_b64encode(JVwYHPFkcdDNLamiQOGuEptSKRoevf.encode()).decode('utf-8')
 def Init_CP(JVwYHPFkcdDNLamiQOGuEptSKRoevB):
  JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP={}
  JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['ACCOUNT']={'cpid':'','cppw':'','cppf':'0'}
  JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']={}
 def Save_session_acount(JVwYHPFkcdDNLamiQOGuEptSKRoevB,JVwYHPFkcdDNLamiQOGuEptSKRoevg,JVwYHPFkcdDNLamiQOGuEptSKRoevj,JVwYHPFkcdDNLamiQOGuEptSKRoezv):
  JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['ACCOUNT']['cpid']=base64.standard_b64encode(JVwYHPFkcdDNLamiQOGuEptSKRoevg.encode()).decode('utf-8')
  JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['ACCOUNT']['cppw']=base64.standard_b64encode(JVwYHPFkcdDNLamiQOGuEptSKRoevj.encode()).decode('utf-8')
  JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['ACCOUNT']['cppf']=JVwYHPFkcdDNLamiQOGuEptSKRoeyC(JVwYHPFkcdDNLamiQOGuEptSKRoezv)
 def Load_session_acount(JVwYHPFkcdDNLamiQOGuEptSKRoevB):
  JVwYHPFkcdDNLamiQOGuEptSKRoevg=base64.standard_b64decode(JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['ACCOUNT']['cpid']).decode('utf-8')
  JVwYHPFkcdDNLamiQOGuEptSKRoevj=base64.standard_b64decode(JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['ACCOUNT']['cppw']).decode('utf-8')
  JVwYHPFkcdDNLamiQOGuEptSKRoezv=JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['ACCOUNT']['cppf']
  return JVwYHPFkcdDNLamiQOGuEptSKRoevg,JVwYHPFkcdDNLamiQOGuEptSKRoevj,JVwYHPFkcdDNLamiQOGuEptSKRoezv
 def make_CP_DefaultCookies(JVwYHPFkcdDNLamiQOGuEptSKRoevB):
  JVwYHPFkcdDNLamiQOGuEptSKRoezB={}
  if 'NEXT_LOCALE' in JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']:JVwYHPFkcdDNLamiQOGuEptSKRoezB['NEXT_LOCALE']=JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['NEXT_LOCALE']
  if 'ak_bmsc' in JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']:JVwYHPFkcdDNLamiQOGuEptSKRoezB['ak_bmsc'] =JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['ak_bmsc']
  if 'bm_mi' in JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']:JVwYHPFkcdDNLamiQOGuEptSKRoezB['bm_mi'] =JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['bm_mi']
  if 'bm_sv' in JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']:JVwYHPFkcdDNLamiQOGuEptSKRoezB['bm_sv'] =JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['bm_sv']
  if 'PCID' in JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']:JVwYHPFkcdDNLamiQOGuEptSKRoezB['PCID'] =JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['PCID']
  if 'member_srl' in JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']:JVwYHPFkcdDNLamiQOGuEptSKRoezB['member_srl']=JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['member_srl']
  if 'token' in JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']:JVwYHPFkcdDNLamiQOGuEptSKRoezB['token'] =JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['token']
  return JVwYHPFkcdDNLamiQOGuEptSKRoezB
 def Get_CP_Login(JVwYHPFkcdDNLamiQOGuEptSKRoevB,userid,userpw,JVwYHPFkcdDNLamiQOGuEptSKRoezW):
  try:
   JVwYHPFkcdDNLamiQOGuEptSKRoezy=JVwYHPFkcdDNLamiQOGuEptSKRoevB.API_DOMAIN
   JVwYHPFkcdDNLamiQOGuEptSKRoezq=JVwYHPFkcdDNLamiQOGuEptSKRoevB.callRequestCookies('Get',JVwYHPFkcdDNLamiQOGuEptSKRoezy,payload=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,params=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,headers=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,cookies=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,redirects=JVwYHPFkcdDNLamiQOGuEptSKRoeyW)
   if JVwYHPFkcdDNLamiQOGuEptSKRoezq.status_code not in[301,302]:return JVwYHPFkcdDNLamiQOGuEptSKRoeyW
   for JVwYHPFkcdDNLamiQOGuEptSKRoezx in JVwYHPFkcdDNLamiQOGuEptSKRoezq.cookies:
    if JVwYHPFkcdDNLamiQOGuEptSKRoezx.name=='NEXT_LOCALE':
     JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['NEXT_LOCALE']=JVwYHPFkcdDNLamiQOGuEptSKRoezx.value
    elif JVwYHPFkcdDNLamiQOGuEptSKRoezx.name=='ak_bmsc':
     JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['ak_bmsc']=JVwYHPFkcdDNLamiQOGuEptSKRoezx.value
   JVwYHPFkcdDNLamiQOGuEptSKRoezB={'NEXT_LOCALE':JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['NEXT_LOCALE'],'ak_bmsc':JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['ak_bmsc'],}
   JVwYHPFkcdDNLamiQOGuEptSKRoezq=JVwYHPFkcdDNLamiQOGuEptSKRoevB.callRequestCookies('Get',JVwYHPFkcdDNLamiQOGuEptSKRoezy,payload=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,params=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,headers=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,cookies=JVwYHPFkcdDNLamiQOGuEptSKRoezB,redirects=JVwYHPFkcdDNLamiQOGuEptSKRoeyW)
   if JVwYHPFkcdDNLamiQOGuEptSKRoezq.status_code not in[200]:return JVwYHPFkcdDNLamiQOGuEptSKRoeyW
   JVwYHPFkcdDNLamiQOGuEptSKRoezU=re.findall('NREUM.loader_config=\{[\w\d\":,-]+\}',JVwYHPFkcdDNLamiQOGuEptSKRoezq.text)[0].split('=')[1]
   JVwYHPFkcdDNLamiQOGuEptSKRoezU=JVwYHPFkcdDNLamiQOGuEptSKRoezU.replace('{','{"').replace(':','":').replace(',',',"')
   JVwYHPFkcdDNLamiQOGuEptSKRoezU=json.loads(JVwYHPFkcdDNLamiQOGuEptSKRoezU)
   JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['NREUM']={'ac':JVwYHPFkcdDNLamiQOGuEptSKRoezU['accountID'],'tk':JVwYHPFkcdDNLamiQOGuEptSKRoezU['trustKey'],'ap':JVwYHPFkcdDNLamiQOGuEptSKRoezU['agentID'],'lk':JVwYHPFkcdDNLamiQOGuEptSKRoezU['licenseKey'],}
   for JVwYHPFkcdDNLamiQOGuEptSKRoezx in JVwYHPFkcdDNLamiQOGuEptSKRoezq.cookies:
    if JVwYHPFkcdDNLamiQOGuEptSKRoezx.name=='bm_mi':
     JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['bm_mi']=JVwYHPFkcdDNLamiQOGuEptSKRoezx.value
    elif JVwYHPFkcdDNLamiQOGuEptSKRoezx.name=='bm_sv':
     JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['bm_sv'] =JVwYHPFkcdDNLamiQOGuEptSKRoezx.value
     JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['bm_sv_ex']=JVwYHPFkcdDNLamiQOGuEptSKRoezx.expires 
  except JVwYHPFkcdDNLamiQOGuEptSKRoeyn as exception:
   JVwYHPFkcdDNLamiQOGuEptSKRoeyI(exception)
   return JVwYHPFkcdDNLamiQOGuEptSKRoeyW
  try:
   JVwYHPFkcdDNLamiQOGuEptSKRoezy=JVwYHPFkcdDNLamiQOGuEptSKRoevB.API_DOMAIN+'/api/auth'
   JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['PCID']=JVwYHPFkcdDNLamiQOGuEptSKRoevB.generatePcId()
   JVwYHPFkcdDNLamiQOGuEptSKRoezX=JVwYHPFkcdDNLamiQOGuEptSKRoevB.Get_DeviceID()
   JVwYHPFkcdDNLamiQOGuEptSKRoezs =JVwYHPFkcdDNLamiQOGuEptSKRoezX.split('-')[0]
   JVwYHPFkcdDNLamiQOGuEptSKRoevn,JVwYHPFkcdDNLamiQOGuEptSKRoevA,JVwYHPFkcdDNLamiQOGuEptSKRoevf=JVwYHPFkcdDNLamiQOGuEptSKRoevB.Make_authHeader()
   JVwYHPFkcdDNLamiQOGuEptSKRoezr={'traceparent':JVwYHPFkcdDNLamiQOGuEptSKRoevn,'tracestate':JVwYHPFkcdDNLamiQOGuEptSKRoevA,'newrelic':JVwYHPFkcdDNLamiQOGuEptSKRoevf,'content-type':'application/json',}
   JVwYHPFkcdDNLamiQOGuEptSKRoezl={'device':{'deviceId':'web-'+JVwYHPFkcdDNLamiQOGuEptSKRoezX,'model':JVwYHPFkcdDNLamiQOGuEptSKRoevB.MODEL,'name':'Chrome Desktop '+JVwYHPFkcdDNLamiQOGuEptSKRoezs,'os':'Windows','osVersion':'10','type':'webclient',},'email':userid,'password':userpw,}
   JVwYHPFkcdDNLamiQOGuEptSKRoezl=json.dumps(JVwYHPFkcdDNLamiQOGuEptSKRoezl,separators=(',',':'))
   JVwYHPFkcdDNLamiQOGuEptSKRoezB={'NEXT_LOCALE':JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['NEXT_LOCALE'],'ak_bmsc':JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['ak_bmsc'],'bm_mi':JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['bm_mi'],'bm_sv':JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['bm_sv'],'PCID':JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['PCID'],}
   JVwYHPFkcdDNLamiQOGuEptSKRoezq=JVwYHPFkcdDNLamiQOGuEptSKRoevB.callRequestCookies('Post',JVwYHPFkcdDNLamiQOGuEptSKRoezy,payload=JVwYHPFkcdDNLamiQOGuEptSKRoezl,params=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,headers=JVwYHPFkcdDNLamiQOGuEptSKRoezr,cookies=JVwYHPFkcdDNLamiQOGuEptSKRoezB,redirects=JVwYHPFkcdDNLamiQOGuEptSKRoeyW)
   if JVwYHPFkcdDNLamiQOGuEptSKRoezq.status_code not in[200]:
    JVwYHPFkcdDNLamiQOGuEptSKRoezb=json.loads(JVwYHPFkcdDNLamiQOGuEptSKRoezq.text)
    if 'error' in JVwYHPFkcdDNLamiQOGuEptSKRoezb:
     JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['error']=JVwYHPFkcdDNLamiQOGuEptSKRoezb.get('error').get('detail')
    return JVwYHPFkcdDNLamiQOGuEptSKRoeyW
   for JVwYHPFkcdDNLamiQOGuEptSKRoezx in JVwYHPFkcdDNLamiQOGuEptSKRoezq.cookies:
    if JVwYHPFkcdDNLamiQOGuEptSKRoezx.name=='token':
     JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['token']=JVwYHPFkcdDNLamiQOGuEptSKRoezx.value
    elif JVwYHPFkcdDNLamiQOGuEptSKRoezx.name=='member_srl':
     JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['member_srl']=JVwYHPFkcdDNLamiQOGuEptSKRoezx.value
    elif JVwYHPFkcdDNLamiQOGuEptSKRoezx.name=='bm_sv':
     JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['bm_sv'] =JVwYHPFkcdDNLamiQOGuEptSKRoezx.value
     JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['bm_sv_ex']=JVwYHPFkcdDNLamiQOGuEptSKRoezx.expires 
  except JVwYHPFkcdDNLamiQOGuEptSKRoeyn as exception:
   JVwYHPFkcdDNLamiQOGuEptSKRoeyI(exception)
   return JVwYHPFkcdDNLamiQOGuEptSKRoeyW
  JVwYHPFkcdDNLamiQOGuEptSKRoevB.Save_session_acount(userid,userpw,JVwYHPFkcdDNLamiQOGuEptSKRoezW)
  return JVwYHPFkcdDNLamiQOGuEptSKRoeyf
 def Get_CP_profile(JVwYHPFkcdDNLamiQOGuEptSKRoevB,JVwYHPFkcdDNLamiQOGuEptSKRoezW,limit_days=1,re_check=JVwYHPFkcdDNLamiQOGuEptSKRoeyW):
  if re_check==JVwYHPFkcdDNLamiQOGuEptSKRoeyf:
   if JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['bm_sv_ex']>JVwYHPFkcdDNLamiQOGuEptSKRoeyT(time.time()):
    JVwYHPFkcdDNLamiQOGuEptSKRoeyI('bm_sv_ex ok')
    return JVwYHPFkcdDNLamiQOGuEptSKRoeyf
  try:
   JVwYHPFkcdDNLamiQOGuEptSKRoezy=JVwYHPFkcdDNLamiQOGuEptSKRoevB.API_DOMAIN+'/api/profiles'
   JVwYHPFkcdDNLamiQOGuEptSKRoevn,JVwYHPFkcdDNLamiQOGuEptSKRoevA,JVwYHPFkcdDNLamiQOGuEptSKRoevf=JVwYHPFkcdDNLamiQOGuEptSKRoevB.Make_authHeader()
   JVwYHPFkcdDNLamiQOGuEptSKRoezr={'traceparent':JVwYHPFkcdDNLamiQOGuEptSKRoevn,'tracestate':JVwYHPFkcdDNLamiQOGuEptSKRoevA,'newrelic':JVwYHPFkcdDNLamiQOGuEptSKRoevf,}
   JVwYHPFkcdDNLamiQOGuEptSKRoezB=JVwYHPFkcdDNLamiQOGuEptSKRoevB.make_CP_DefaultCookies()
   JVwYHPFkcdDNLamiQOGuEptSKRoezq=JVwYHPFkcdDNLamiQOGuEptSKRoevB.callRequestCookies('Get',JVwYHPFkcdDNLamiQOGuEptSKRoezy,payload=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,params=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,headers=JVwYHPFkcdDNLamiQOGuEptSKRoezr,cookies=JVwYHPFkcdDNLamiQOGuEptSKRoezB,redirects=JVwYHPFkcdDNLamiQOGuEptSKRoeyW)
   if JVwYHPFkcdDNLamiQOGuEptSKRoezq.status_code not in[200]:return JVwYHPFkcdDNLamiQOGuEptSKRoeyW
   JVwYHPFkcdDNLamiQOGuEptSKRoezb=json.loads(JVwYHPFkcdDNLamiQOGuEptSKRoezq.text)
   JVwYHPFkcdDNLamiQOGuEptSKRoezh=0 
   for JVwYHPFkcdDNLamiQOGuEptSKRoezx in JVwYHPFkcdDNLamiQOGuEptSKRoezq.cookies:
    JVwYHPFkcdDNLamiQOGuEptSKRoeyI(JVwYHPFkcdDNLamiQOGuEptSKRoezx.name)
    if JVwYHPFkcdDNLamiQOGuEptSKRoezx.name=='bm_sv':
     JVwYHPFkcdDNLamiQOGuEptSKRoezh=1
     JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['bm_sv'] =JVwYHPFkcdDNLamiQOGuEptSKRoezx.value
     JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['bm_sv_ex']=JVwYHPFkcdDNLamiQOGuEptSKRoezx.expires 
   if JVwYHPFkcdDNLamiQOGuEptSKRoezh==0:
    JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['bm_sv_ex']=JVwYHPFkcdDNLamiQOGuEptSKRoeyT(time.time())+60*60*2 
   JVwYHPFkcdDNLamiQOGuEptSKRoezW=JVwYHPFkcdDNLamiQOGuEptSKRoezb.get('data')[JVwYHPFkcdDNLamiQOGuEptSKRoeyT(JVwYHPFkcdDNLamiQOGuEptSKRoezW)]
   JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['accountId']=JVwYHPFkcdDNLamiQOGuEptSKRoezW.get('accountId')
   JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['profileId']=JVwYHPFkcdDNLamiQOGuEptSKRoezW.get('profileId')
  except JVwYHPFkcdDNLamiQOGuEptSKRoeyn as exception:
   JVwYHPFkcdDNLamiQOGuEptSKRoeyI(exception)
   return JVwYHPFkcdDNLamiQOGuEptSKRoeyW
  if re_check==JVwYHPFkcdDNLamiQOGuEptSKRoeyW:
   JVwYHPFkcdDNLamiQOGuEptSKRoezI =JVwYHPFkcdDNLamiQOGuEptSKRoevB.Get_Now_Datetime()
   JVwYHPFkcdDNLamiQOGuEptSKRoezC=JVwYHPFkcdDNLamiQOGuEptSKRoezI+datetime.timedelta(days=limit_days)
   JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['limitdate']=JVwYHPFkcdDNLamiQOGuEptSKRoezC.strftime('%Y-%m-%d')
  else:
   JVwYHPFkcdDNLamiQOGuEptSKRoeyI('re check')
  JVwYHPFkcdDNLamiQOGuEptSKRoevB.dic_To_jsonfile(JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP_COOKIE_FILENAME,JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP)
  return JVwYHPFkcdDNLamiQOGuEptSKRoeyf
 def Get_Category_GroupList(JVwYHPFkcdDNLamiQOGuEptSKRoevB,vType):
  JVwYHPFkcdDNLamiQOGuEptSKRoezM=[] 
  try:
   JVwYHPFkcdDNLamiQOGuEptSKRoezy=JVwYHPFkcdDNLamiQOGuEptSKRoevB.API_VIEWURL+'/v2/discover/feed' 
   JVwYHPFkcdDNLamiQOGuEptSKRoezT={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false',}
   JVwYHPFkcdDNLamiQOGuEptSKRoezq=JVwYHPFkcdDNLamiQOGuEptSKRoevB.callRequestCookies('Get',JVwYHPFkcdDNLamiQOGuEptSKRoezy,payload=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,params=JVwYHPFkcdDNLamiQOGuEptSKRoezT,headers=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,cookies=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,redirects=JVwYHPFkcdDNLamiQOGuEptSKRoeyf)
   if JVwYHPFkcdDNLamiQOGuEptSKRoezq.status_code not in[200]:return[]
   JVwYHPFkcdDNLamiQOGuEptSKRoezb=json.loads(JVwYHPFkcdDNLamiQOGuEptSKRoezq.text)
   if vType in['TVSHOWS','MOVIES']:
    JVwYHPFkcdDNLamiQOGuEptSKRoezn='Explores' 
   elif vType in['EDUCATION']:
    JVwYHPFkcdDNLamiQOGuEptSKRoezn='Collection-Rails-Curation'
   elif vType in['ALL']:
    JVwYHPFkcdDNLamiQOGuEptSKRoezn='Explores-Categories'
   for JVwYHPFkcdDNLamiQOGuEptSKRoezA in JVwYHPFkcdDNLamiQOGuEptSKRoezb.get('data'):
    if JVwYHPFkcdDNLamiQOGuEptSKRoezA.get('type')==JVwYHPFkcdDNLamiQOGuEptSKRoezn:
     for JVwYHPFkcdDNLamiQOGuEptSKRoezf in JVwYHPFkcdDNLamiQOGuEptSKRoezA.get('data'):
      if vType in['TVSHOWS','MOVIES']:
       JVwYHPFkcdDNLamiQOGuEptSKRoezg=JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('collectionId')
      elif vType in['EDUCATION','ALL']:
       JVwYHPFkcdDNLamiQOGuEptSKRoezg=JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('id')
      JVwYHPFkcdDNLamiQOGuEptSKRoezj={'collectionId':JVwYHPFkcdDNLamiQOGuEptSKRoezg,'title':JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('name'),'category':JVwYHPFkcdDNLamiQOGuEptSKRoezA.get('category'),'pre_title':'',}
      JVwYHPFkcdDNLamiQOGuEptSKRoezM.append(JVwYHPFkcdDNLamiQOGuEptSKRoezj)
     break
  except JVwYHPFkcdDNLamiQOGuEptSKRoeyn as exception:
   JVwYHPFkcdDNLamiQOGuEptSKRoeyI(exception)
   return[]
  return JVwYHPFkcdDNLamiQOGuEptSKRoezM
 def Get_Category_List(JVwYHPFkcdDNLamiQOGuEptSKRoevB,vType,JVwYHPFkcdDNLamiQOGuEptSKRoezg,page_int):
  JVwYHPFkcdDNLamiQOGuEptSKRoezM=[] 
  JVwYHPFkcdDNLamiQOGuEptSKRoeBv=JVwYHPFkcdDNLamiQOGuEptSKRoeyW
  try:
   if vType=='ALL':
    JVwYHPFkcdDNLamiQOGuEptSKRoezr={'x-membersrl':JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['member_srl'],'x-pcid':JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['PCID'],'x-profileid':JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['profileId'],}
    JVwYHPFkcdDNLamiQOGuEptSKRoezT={'platform':'WEBCLIENT','page':JVwYHPFkcdDNLamiQOGuEptSKRoeyC(page_int),'perPage':JVwYHPFkcdDNLamiQOGuEptSKRoeyC(JVwYHPFkcdDNLamiQOGuEptSKRoevB.PAGE_LIMIT),'locale':'ko','sort':'',}
    JVwYHPFkcdDNLamiQOGuEptSKRoezy=JVwYHPFkcdDNLamiQOGuEptSKRoevB.API_VIEWURL+'/v1/discover/categories/'+JVwYHPFkcdDNLamiQOGuEptSKRoezg+'/titles'
    JVwYHPFkcdDNLamiQOGuEptSKRoezq=JVwYHPFkcdDNLamiQOGuEptSKRoevB.callRequestCookies('Get',JVwYHPFkcdDNLamiQOGuEptSKRoezy,payload=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,params=JVwYHPFkcdDNLamiQOGuEptSKRoezT,headers=JVwYHPFkcdDNLamiQOGuEptSKRoezr,cookies=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,redirects=JVwYHPFkcdDNLamiQOGuEptSKRoeyf)
   else: 
    JVwYHPFkcdDNLamiQOGuEptSKRoezT={'platform':'WEBCLIENT','page':JVwYHPFkcdDNLamiQOGuEptSKRoeyC(page_int),'perPage':JVwYHPFkcdDNLamiQOGuEptSKRoeyC(JVwYHPFkcdDNLamiQOGuEptSKRoevB.PAGE_LIMIT),}
    JVwYHPFkcdDNLamiQOGuEptSKRoezy=JVwYHPFkcdDNLamiQOGuEptSKRoevB.API_VIEWURL+'/v1/discover/collections/'+JVwYHPFkcdDNLamiQOGuEptSKRoezg+'/titles'
    JVwYHPFkcdDNLamiQOGuEptSKRoezq=JVwYHPFkcdDNLamiQOGuEptSKRoevB.callRequestCookies('Get',JVwYHPFkcdDNLamiQOGuEptSKRoezy,payload=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,params=JVwYHPFkcdDNLamiQOGuEptSKRoezT,headers=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,cookies=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,redirects=JVwYHPFkcdDNLamiQOGuEptSKRoeyf)
   if JVwYHPFkcdDNLamiQOGuEptSKRoezq.status_code not in[200]:return[],JVwYHPFkcdDNLamiQOGuEptSKRoeyW
   JVwYHPFkcdDNLamiQOGuEptSKRoezb=json.loads(JVwYHPFkcdDNLamiQOGuEptSKRoezq.text)
   if vType=='ALL':
    JVwYHPFkcdDNLamiQOGuEptSKRoeBz=JVwYHPFkcdDNLamiQOGuEptSKRoezb.get('data').get('data')
   else:
    JVwYHPFkcdDNLamiQOGuEptSKRoeBz=JVwYHPFkcdDNLamiQOGuEptSKRoezb.get('data')
   for JVwYHPFkcdDNLamiQOGuEptSKRoezf in JVwYHPFkcdDNLamiQOGuEptSKRoeBz:
    JVwYHPFkcdDNLamiQOGuEptSKRoeBy=JVwYHPFkcdDNLamiQOGuEptSKRoeBs=JVwYHPFkcdDNLamiQOGuEptSKRoeyX=JVwYHPFkcdDNLamiQOGuEptSKRoeyU=''
    if 'poster' in JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('images'):JVwYHPFkcdDNLamiQOGuEptSKRoeBy =JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('images').get('poster').get('url')
    if 'story-art' in JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('images'):JVwYHPFkcdDNLamiQOGuEptSKRoeBs =JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('images').get('story-art').get('url')
    if 'title-treatment' in JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('images'):JVwYHPFkcdDNLamiQOGuEptSKRoeyX=JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('images').get('title-treatment').get('url')
    if 'story-art' in JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('images'):JVwYHPFkcdDNLamiQOGuEptSKRoeyU =JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('images').get('story-art').get('url')
    JVwYHPFkcdDNLamiQOGuEptSKRoeBq=''
    if JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('badge')not in[{},JVwYHPFkcdDNLamiQOGuEptSKRoeyh]:
     for i in JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('badge').get('text'):
      JVwYHPFkcdDNLamiQOGuEptSKRoeBq+=i.get('text')
    JVwYHPFkcdDNLamiQOGuEptSKRoeBx=''
    if JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('seasonList')!=JVwYHPFkcdDNLamiQOGuEptSKRoeyh:
     JVwYHPFkcdDNLamiQOGuEptSKRoeBx=','.join(JVwYHPFkcdDNLamiQOGuEptSKRoeyC(e)for e in JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('seasonList'))
    JVwYHPFkcdDNLamiQOGuEptSKRoeBU =[]
    for JVwYHPFkcdDNLamiQOGuEptSKRoeBX in JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('tags'):
     JVwYHPFkcdDNLamiQOGuEptSKRoeBU.append(JVwYHPFkcdDNLamiQOGuEptSKRoeBX.get('tag'))
    JVwYHPFkcdDNLamiQOGuEptSKRoezj={'id':JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('id'),'title':JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('title'),'thumbnail':{'poster':JVwYHPFkcdDNLamiQOGuEptSKRoeBy,'thumb':JVwYHPFkcdDNLamiQOGuEptSKRoeBs,'clearlogo':JVwYHPFkcdDNLamiQOGuEptSKRoeyX,'fanart':JVwYHPFkcdDNLamiQOGuEptSKRoeyU},'mpaa':JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('age_rating'),'duration':JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('running_time'),'asis':JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('as'),'badge':JVwYHPFkcdDNLamiQOGuEptSKRoeBq,'year':JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('meta').get('releaseYear'),'seasonList':JVwYHPFkcdDNLamiQOGuEptSKRoeBx,'genreList':JVwYHPFkcdDNLamiQOGuEptSKRoeBU,}
    JVwYHPFkcdDNLamiQOGuEptSKRoezM.append(JVwYHPFkcdDNLamiQOGuEptSKRoezj)
   if JVwYHPFkcdDNLamiQOGuEptSKRoezb.get('pagination').get('totalPages')>page_int:
    JVwYHPFkcdDNLamiQOGuEptSKRoeBv=JVwYHPFkcdDNLamiQOGuEptSKRoeyf
  except JVwYHPFkcdDNLamiQOGuEptSKRoeyn as exception:
   JVwYHPFkcdDNLamiQOGuEptSKRoeyI(exception)
   return[],JVwYHPFkcdDNLamiQOGuEptSKRoeyW
  return JVwYHPFkcdDNLamiQOGuEptSKRoezM,JVwYHPFkcdDNLamiQOGuEptSKRoeBv
 def Get_Episode_List(JVwYHPFkcdDNLamiQOGuEptSKRoevB,programId,season):
  JVwYHPFkcdDNLamiQOGuEptSKRoezM=[] 
  try:
   JVwYHPFkcdDNLamiQOGuEptSKRoezy=JVwYHPFkcdDNLamiQOGuEptSKRoevB.API_VIEWURL+'/v1/discover/titles/'+programId+'/episodes'
   JVwYHPFkcdDNLamiQOGuEptSKRoezT={'season':season,'sort':'true','locale':'ko',}
   JVwYHPFkcdDNLamiQOGuEptSKRoezq=JVwYHPFkcdDNLamiQOGuEptSKRoevB.callRequestCookies('Get',JVwYHPFkcdDNLamiQOGuEptSKRoezy,payload=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,params=JVwYHPFkcdDNLamiQOGuEptSKRoezT,headers=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,cookies=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,redirects=JVwYHPFkcdDNLamiQOGuEptSKRoeyf)
   if JVwYHPFkcdDNLamiQOGuEptSKRoezq.status_code not in[200]:return[]
   JVwYHPFkcdDNLamiQOGuEptSKRoezb=json.loads(JVwYHPFkcdDNLamiQOGuEptSKRoezq.text)
   for JVwYHPFkcdDNLamiQOGuEptSKRoezf in JVwYHPFkcdDNLamiQOGuEptSKRoezb.get('data'):
    JVwYHPFkcdDNLamiQOGuEptSKRoeBs=''
    if 'story-art' in JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('images'):JVwYHPFkcdDNLamiQOGuEptSKRoeBs =JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('images').get('story-art').get('url')
    JVwYHPFkcdDNLamiQOGuEptSKRoeBU =[]
    for JVwYHPFkcdDNLamiQOGuEptSKRoeBX in JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('tags'):
     JVwYHPFkcdDNLamiQOGuEptSKRoeBU.append(JVwYHPFkcdDNLamiQOGuEptSKRoeBX.get('tag'))
    JVwYHPFkcdDNLamiQOGuEptSKRoezj={'id':JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('id'),'title':JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('title'),'thumbnail':{'thumb':JVwYHPFkcdDNLamiQOGuEptSKRoeBs,'fanart':JVwYHPFkcdDNLamiQOGuEptSKRoeBs},'mpaa':JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('age_rating'),'duration':JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('running_time'),'asis':JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('as'),'year':JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('meta').get('releaseYear'),'episode':JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('episode'),'genreList':JVwYHPFkcdDNLamiQOGuEptSKRoeBU,'desc':JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('description'),}
    JVwYHPFkcdDNLamiQOGuEptSKRoezM.append(JVwYHPFkcdDNLamiQOGuEptSKRoezj)
  except JVwYHPFkcdDNLamiQOGuEptSKRoeyn as exception:
   JVwYHPFkcdDNLamiQOGuEptSKRoeyI(exception)
   return[]
  return JVwYHPFkcdDNLamiQOGuEptSKRoezM
 def Get_vInfo(JVwYHPFkcdDNLamiQOGuEptSKRoevB,titleId):
  try:
   JVwYHPFkcdDNLamiQOGuEptSKRoezy=JVwYHPFkcdDNLamiQOGuEptSKRoevB.API_VIEWURL+'/v1/discover/titles/'+titleId 
   JVwYHPFkcdDNLamiQOGuEptSKRoezT={'locale':'ko'}
   JVwYHPFkcdDNLamiQOGuEptSKRoezq=JVwYHPFkcdDNLamiQOGuEptSKRoevB.callRequestCookies('Get',JVwYHPFkcdDNLamiQOGuEptSKRoezy,payload=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,params=JVwYHPFkcdDNLamiQOGuEptSKRoezT,headers=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,cookies=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,redirects=JVwYHPFkcdDNLamiQOGuEptSKRoeyf)
   if JVwYHPFkcdDNLamiQOGuEptSKRoezq.status_code not in[200]:return '','',''
   JVwYHPFkcdDNLamiQOGuEptSKRoezb=json.loads(JVwYHPFkcdDNLamiQOGuEptSKRoezq.text).get('data')
   JVwYHPFkcdDNLamiQOGuEptSKRoeBx=''
   if JVwYHPFkcdDNLamiQOGuEptSKRoezb.get('seasonList')!=JVwYHPFkcdDNLamiQOGuEptSKRoeyh:
    JVwYHPFkcdDNLamiQOGuEptSKRoeBx=','.join(JVwYHPFkcdDNLamiQOGuEptSKRoeyC(e)for e in JVwYHPFkcdDNLamiQOGuEptSKRoezb.get('seasonList'))
   JVwYHPFkcdDNLamiQOGuEptSKRoeBr={'age_rating':JVwYHPFkcdDNLamiQOGuEptSKRoezb.get('age_rating'),'asset_id':JVwYHPFkcdDNLamiQOGuEptSKRoezb.get('asset_id'),'availability':JVwYHPFkcdDNLamiQOGuEptSKRoezb.get('availability'),'deal_id':JVwYHPFkcdDNLamiQOGuEptSKRoezb.get('deal_id'),'downloadable':'true' if JVwYHPFkcdDNLamiQOGuEptSKRoezb.get('downloadable')else 'false','region':JVwYHPFkcdDNLamiQOGuEptSKRoezb.get('region'),'streamable':'true' if JVwYHPFkcdDNLamiQOGuEptSKRoezb.get('streamable')else 'false','asis':JVwYHPFkcdDNLamiQOGuEptSKRoezb.get('as'),'seasonList':JVwYHPFkcdDNLamiQOGuEptSKRoeBx}
  except JVwYHPFkcdDNLamiQOGuEptSKRoeyn as exception:
   JVwYHPFkcdDNLamiQOGuEptSKRoeyI(exception)
   return{}
  return JVwYHPFkcdDNLamiQOGuEptSKRoeBr
 def Get_eInfo(JVwYHPFkcdDNLamiQOGuEptSKRoevB,eventId):
  try:
   JVwYHPFkcdDNLamiQOGuEptSKRoezy=JVwYHPFkcdDNLamiQOGuEptSKRoevB.API_VIEWURL+'/v1/discover/events/'+eventId 
   JVwYHPFkcdDNLamiQOGuEptSKRoezT={'locale':'ko'}
   JVwYHPFkcdDNLamiQOGuEptSKRoezq=JVwYHPFkcdDNLamiQOGuEptSKRoevB.callRequestCookies('Get',JVwYHPFkcdDNLamiQOGuEptSKRoezy,payload=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,params=JVwYHPFkcdDNLamiQOGuEptSKRoezT,headers=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,cookies=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,redirects=JVwYHPFkcdDNLamiQOGuEptSKRoeyf)
   if JVwYHPFkcdDNLamiQOGuEptSKRoezq.status_code not in[200]:return '','',''
   JVwYHPFkcdDNLamiQOGuEptSKRoezb=json.loads(JVwYHPFkcdDNLamiQOGuEptSKRoezq.text).get('data')
   JVwYHPFkcdDNLamiQOGuEptSKRoeBr={'asset_id':JVwYHPFkcdDNLamiQOGuEptSKRoezb.get('asset_id'),'deal_id':JVwYHPFkcdDNLamiQOGuEptSKRoezb.get('deal_id'),'region':JVwYHPFkcdDNLamiQOGuEptSKRoezb.get('region'),'streamable':'true' if JVwYHPFkcdDNLamiQOGuEptSKRoezb.get('streamable')else 'false',}
  except JVwYHPFkcdDNLamiQOGuEptSKRoeyn as exception:
   JVwYHPFkcdDNLamiQOGuEptSKRoeyI(exception)
   return{}
  return JVwYHPFkcdDNLamiQOGuEptSKRoeBr
 def GetBroadURL(JVwYHPFkcdDNLamiQOGuEptSKRoevB,titleId):
  JVwYHPFkcdDNLamiQOGuEptSKRoeBl=''
  JVwYHPFkcdDNLamiQOGuEptSKRoeBb =''
  JVwYHPFkcdDNLamiQOGuEptSKRoeBr=JVwYHPFkcdDNLamiQOGuEptSKRoevB.Get_vInfo(titleId)
  if JVwYHPFkcdDNLamiQOGuEptSKRoeBr=={}:return '',''
  try:
   JVwYHPFkcdDNLamiQOGuEptSKRoezy=JVwYHPFkcdDNLamiQOGuEptSKRoevB.API_DOMAIN+'/api/playback/play' 
   JVwYHPFkcdDNLamiQOGuEptSKRoezT={'titleId':titleId}
   JVwYHPFkcdDNLamiQOGuEptSKRoevn,JVwYHPFkcdDNLamiQOGuEptSKRoevA,JVwYHPFkcdDNLamiQOGuEptSKRoevf=JVwYHPFkcdDNLamiQOGuEptSKRoevB.Make_authHeader()
   JVwYHPFkcdDNLamiQOGuEptSKRoezr={'traceparent':JVwYHPFkcdDNLamiQOGuEptSKRoevn,'tracestate':JVwYHPFkcdDNLamiQOGuEptSKRoevA,'newrelic':JVwYHPFkcdDNLamiQOGuEptSKRoevf,'x-force-raw':'true','x-pcid':JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':JVwYHPFkcdDNLamiQOGuEptSKRoeBr.get('age_rating'),'x-title-availability':JVwYHPFkcdDNLamiQOGuEptSKRoeBr.get('availability'),'x-title-brightcove-id':JVwYHPFkcdDNLamiQOGuEptSKRoeBr.get('asset_id'),'x-title-deal-id':JVwYHPFkcdDNLamiQOGuEptSKRoeBr.get('deal_id'),'x-title-downloadable':JVwYHPFkcdDNLamiQOGuEptSKRoeBr.get('downloadable'),'x-title-region':JVwYHPFkcdDNLamiQOGuEptSKRoeBr.get('region'),'x-title-streamable':JVwYHPFkcdDNLamiQOGuEptSKRoeBr.get('streamable'),}
   JVwYHPFkcdDNLamiQOGuEptSKRoezB=JVwYHPFkcdDNLamiQOGuEptSKRoevB.make_CP_DefaultCookies()
   JVwYHPFkcdDNLamiQOGuEptSKRoezq=JVwYHPFkcdDNLamiQOGuEptSKRoevB.callRequestCookies('Get',JVwYHPFkcdDNLamiQOGuEptSKRoezy,payload=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,params=JVwYHPFkcdDNLamiQOGuEptSKRoezT,headers=JVwYHPFkcdDNLamiQOGuEptSKRoezr,cookies=JVwYHPFkcdDNLamiQOGuEptSKRoezB,redirects=JVwYHPFkcdDNLamiQOGuEptSKRoeyf)
   if JVwYHPFkcdDNLamiQOGuEptSKRoezq.status_code not in[200]:return '',json.loads(JVwYHPFkcdDNLamiQOGuEptSKRoezq.text).get('error').get('detail')
   JVwYHPFkcdDNLamiQOGuEptSKRoezb=json.loads(JVwYHPFkcdDNLamiQOGuEptSKRoezq.text)
   for JVwYHPFkcdDNLamiQOGuEptSKRoezf in JVwYHPFkcdDNLamiQOGuEptSKRoezb.get('data').get('raw').get('sources'):
    if JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('type')=='application/dash+xml' and JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('src')[0:8]=='https://':
     JVwYHPFkcdDNLamiQOGuEptSKRoeBl=JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('src')
     if 'key_systems' in JVwYHPFkcdDNLamiQOGuEptSKRoezf:
      JVwYHPFkcdDNLamiQOGuEptSKRoeBb =JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('key_systems').get('com.widevine.alpha').get('license_url')
     break
  except JVwYHPFkcdDNLamiQOGuEptSKRoeyn as exception:
   JVwYHPFkcdDNLamiQOGuEptSKRoeyI(exception)
   return '',''
  return JVwYHPFkcdDNLamiQOGuEptSKRoeBl,JVwYHPFkcdDNLamiQOGuEptSKRoeBb
 def GetEventURL(JVwYHPFkcdDNLamiQOGuEptSKRoevB,eventId,JVwYHPFkcdDNLamiQOGuEptSKRoeyv):
  JVwYHPFkcdDNLamiQOGuEptSKRoeBl=''
  JVwYHPFkcdDNLamiQOGuEptSKRoeBb =''
  JVwYHPFkcdDNLamiQOGuEptSKRoeBr=JVwYHPFkcdDNLamiQOGuEptSKRoevB.Get_eInfo(eventId)
  if JVwYHPFkcdDNLamiQOGuEptSKRoeBr=={}:return '',''
  try:
   JVwYHPFkcdDNLamiQOGuEptSKRoezy=JVwYHPFkcdDNLamiQOGuEptSKRoevB.API_DOMAIN+'/api/playback/play' 
   JVwYHPFkcdDNLamiQOGuEptSKRoezT={'titleId':eventId,'titleType':JVwYHPFkcdDNLamiQOGuEptSKRoeyv,}
   JVwYHPFkcdDNLamiQOGuEptSKRoevn,JVwYHPFkcdDNLamiQOGuEptSKRoevA,JVwYHPFkcdDNLamiQOGuEptSKRoevf=JVwYHPFkcdDNLamiQOGuEptSKRoevB.Make_authHeader()
   JVwYHPFkcdDNLamiQOGuEptSKRoezr={'traceparent':JVwYHPFkcdDNLamiQOGuEptSKRoevn,'tracestate':JVwYHPFkcdDNLamiQOGuEptSKRoevA,'newrelic':JVwYHPFkcdDNLamiQOGuEptSKRoevf,'x-force-raw':'true','x-pcid':JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':JVwYHPFkcdDNLamiQOGuEptSKRoeBr.get('asset_id'),'x-title-deal-id':JVwYHPFkcdDNLamiQOGuEptSKRoeBr.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':JVwYHPFkcdDNLamiQOGuEptSKRoeBr.get('region'),'x-title-streamable':JVwYHPFkcdDNLamiQOGuEptSKRoeBr.get('streamable'),}
   JVwYHPFkcdDNLamiQOGuEptSKRoezB=JVwYHPFkcdDNLamiQOGuEptSKRoevB.make_CP_DefaultCookies()
   JVwYHPFkcdDNLamiQOGuEptSKRoezq=JVwYHPFkcdDNLamiQOGuEptSKRoevB.callRequestCookies('Get',JVwYHPFkcdDNLamiQOGuEptSKRoezy,payload=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,params=JVwYHPFkcdDNLamiQOGuEptSKRoezT,headers=JVwYHPFkcdDNLamiQOGuEptSKRoezr,cookies=JVwYHPFkcdDNLamiQOGuEptSKRoezB,redirects=JVwYHPFkcdDNLamiQOGuEptSKRoeyf)
   if JVwYHPFkcdDNLamiQOGuEptSKRoezq.status_code not in[200]:return '',json.loads(JVwYHPFkcdDNLamiQOGuEptSKRoezq.text).get('error').get('detail')
   JVwYHPFkcdDNLamiQOGuEptSKRoezb=json.loads(JVwYHPFkcdDNLamiQOGuEptSKRoezq.text)
   for JVwYHPFkcdDNLamiQOGuEptSKRoezf in JVwYHPFkcdDNLamiQOGuEptSKRoezb.get('data').get('raw').get('sources'):
    if JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('type')=='application/dash+xml' and JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('src')[0:8]=='https://':
     JVwYHPFkcdDNLamiQOGuEptSKRoeBl=JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('src')
     if 'key_systems' in JVwYHPFkcdDNLamiQOGuEptSKRoezf:
      JVwYHPFkcdDNLamiQOGuEptSKRoeBb =JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('key_systems').get('com.widevine.alpha').get('license_url')
     break
  except JVwYHPFkcdDNLamiQOGuEptSKRoeyn as exception:
   JVwYHPFkcdDNLamiQOGuEptSKRoeyI(exception)
   return '',''
  return JVwYHPFkcdDNLamiQOGuEptSKRoeBl,JVwYHPFkcdDNLamiQOGuEptSKRoeBb
 def GetEventURL_Live(JVwYHPFkcdDNLamiQOGuEptSKRoevB,eventId,JVwYHPFkcdDNLamiQOGuEptSKRoeyv):
  JVwYHPFkcdDNLamiQOGuEptSKRoeBl=''
  JVwYHPFkcdDNLamiQOGuEptSKRoeBb =''
  JVwYHPFkcdDNLamiQOGuEptSKRoeBr=JVwYHPFkcdDNLamiQOGuEptSKRoevB.Get_eInfo(eventId)
  if JVwYHPFkcdDNLamiQOGuEptSKRoeBr=={}:return '',''
  try:
   JVwYHPFkcdDNLamiQOGuEptSKRoezy=JVwYHPFkcdDNLamiQOGuEptSKRoevB.API_DOMAIN+'/api/playback/play' 
   JVwYHPFkcdDNLamiQOGuEptSKRoezT={'titleId':eventId,'titleType':JVwYHPFkcdDNLamiQOGuEptSKRoeyv,}
   JVwYHPFkcdDNLamiQOGuEptSKRoevn,JVwYHPFkcdDNLamiQOGuEptSKRoevA,JVwYHPFkcdDNLamiQOGuEptSKRoevf=JVwYHPFkcdDNLamiQOGuEptSKRoevB.Make_authHeader()
   JVwYHPFkcdDNLamiQOGuEptSKRoezr={'traceparent':JVwYHPFkcdDNLamiQOGuEptSKRoevn,'tracestate':JVwYHPFkcdDNLamiQOGuEptSKRoevA,'newrelic':JVwYHPFkcdDNLamiQOGuEptSKRoevf,'x-force-raw':'true','x-pcid':JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':JVwYHPFkcdDNLamiQOGuEptSKRoeBr.get('asset_id'),'x-title-deal-id':JVwYHPFkcdDNLamiQOGuEptSKRoeBr.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':JVwYHPFkcdDNLamiQOGuEptSKRoeBr.get('region'),'x-title-streamable':JVwYHPFkcdDNLamiQOGuEptSKRoeBr.get('streamable'),}
   JVwYHPFkcdDNLamiQOGuEptSKRoezB=JVwYHPFkcdDNLamiQOGuEptSKRoevB.make_CP_DefaultCookies()
   JVwYHPFkcdDNLamiQOGuEptSKRoezq=JVwYHPFkcdDNLamiQOGuEptSKRoevB.callRequestCookies('Get',JVwYHPFkcdDNLamiQOGuEptSKRoezy,payload=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,params=JVwYHPFkcdDNLamiQOGuEptSKRoezT,headers=JVwYHPFkcdDNLamiQOGuEptSKRoezr,cookies=JVwYHPFkcdDNLamiQOGuEptSKRoezB,redirects=JVwYHPFkcdDNLamiQOGuEptSKRoeyf)
   if JVwYHPFkcdDNLamiQOGuEptSKRoezq.status_code not in[200]:return '',json.loads(JVwYHPFkcdDNLamiQOGuEptSKRoezq.text).get('error').get('detail')
   JVwYHPFkcdDNLamiQOGuEptSKRoezb=json.loads(JVwYHPFkcdDNLamiQOGuEptSKRoezq.text)
   for JVwYHPFkcdDNLamiQOGuEptSKRoezf in JVwYHPFkcdDNLamiQOGuEptSKRoezb.get('data').get('raw').get('sources'):
    if 'key_systems' in JVwYHPFkcdDNLamiQOGuEptSKRoezf:
     if JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('type')=='application/dash+xml' and 'com.widevine.alpha' in JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('key_systems')and JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('src').startswith('https://')==JVwYHPFkcdDNLamiQOGuEptSKRoeyf:
      JVwYHPFkcdDNLamiQOGuEptSKRoeBl=JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('src')
      JVwYHPFkcdDNLamiQOGuEptSKRoeBb =JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('key_systems').get('com.widevine.alpha').get('license_url')
   if JVwYHPFkcdDNLamiQOGuEptSKRoeBl=='':
    for JVwYHPFkcdDNLamiQOGuEptSKRoezf in JVwYHPFkcdDNLamiQOGuEptSKRoezb.get('data').get('raw').get('sources'):
     if 'key_systems' in JVwYHPFkcdDNLamiQOGuEptSKRoezf:
      if JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('key_systems')and JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('src').startswith('https://')==JVwYHPFkcdDNLamiQOGuEptSKRoeyf:
       JVwYHPFkcdDNLamiQOGuEptSKRoeBl=JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('src')
       JVwYHPFkcdDNLamiQOGuEptSKRoeBb =JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('key_systems').get('com.widevine.alpha').get('license_url')
   if JVwYHPFkcdDNLamiQOGuEptSKRoeBl=='':
    for JVwYHPFkcdDNLamiQOGuEptSKRoezf in JVwYHPFkcdDNLamiQOGuEptSKRoezb.get('data').get('raw').get('sources'):
     if JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('type')=='application/dash+xml' and JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('src').startswith('https://')==JVwYHPFkcdDNLamiQOGuEptSKRoeyf:
      JVwYHPFkcdDNLamiQOGuEptSKRoeBl=JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('src')
   if JVwYHPFkcdDNLamiQOGuEptSKRoeBl=='':
    for JVwYHPFkcdDNLamiQOGuEptSKRoezf in JVwYHPFkcdDNLamiQOGuEptSKRoezb.get('data').get('raw').get('sources'):
     if JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('type')=='application/x-mpegURL' and JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('src').startswith('https://')==JVwYHPFkcdDNLamiQOGuEptSKRoeyf:
      JVwYHPFkcdDNLamiQOGuEptSKRoeBl=JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('src')
  except JVwYHPFkcdDNLamiQOGuEptSKRoeyn as exception:
   JVwYHPFkcdDNLamiQOGuEptSKRoeyI(exception)
   return '',''
  return JVwYHPFkcdDNLamiQOGuEptSKRoeBl,JVwYHPFkcdDNLamiQOGuEptSKRoeBb
 def Get_Url_PostFix(JVwYHPFkcdDNLamiQOGuEptSKRoevB,in_url):
  JVwYHPFkcdDNLamiQOGuEptSKRoeBh=urllib.parse.urlparse(in_url) 
  JVwYHPFkcdDNLamiQOGuEptSKRoeBW =JVwYHPFkcdDNLamiQOGuEptSKRoeBh.path.strip('/').split('/')
  JVwYHPFkcdDNLamiQOGuEptSKRoeBI =JVwYHPFkcdDNLamiQOGuEptSKRoeBW[JVwYHPFkcdDNLamiQOGuEptSKRoeyg(JVwYHPFkcdDNLamiQOGuEptSKRoeBW)-1]
  JVwYHPFkcdDNLamiQOGuEptSKRoeBC=JVwYHPFkcdDNLamiQOGuEptSKRoeBI.split('.')
  return JVwYHPFkcdDNLamiQOGuEptSKRoeBC[JVwYHPFkcdDNLamiQOGuEptSKRoeyg(JVwYHPFkcdDNLamiQOGuEptSKRoeBC)-1]
 def Get_Theme_GroupList(JVwYHPFkcdDNLamiQOGuEptSKRoevB,vType):
  JVwYHPFkcdDNLamiQOGuEptSKRoezM=[] 
  try:
   JVwYHPFkcdDNLamiQOGuEptSKRoezy=JVwYHPFkcdDNLamiQOGuEptSKRoevB.API_VIEWURL+'/v2/discover/feed' 
   JVwYHPFkcdDNLamiQOGuEptSKRoezT={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':JVwYHPFkcdDNLamiQOGuEptSKRoeyC(JVwYHPFkcdDNLamiQOGuEptSKRoevB.PAGE_LIMIT),'filterRestrictedContent':'false',}
   JVwYHPFkcdDNLamiQOGuEptSKRoezq=JVwYHPFkcdDNLamiQOGuEptSKRoevB.callRequestCookies('Get',JVwYHPFkcdDNLamiQOGuEptSKRoezy,payload=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,params=JVwYHPFkcdDNLamiQOGuEptSKRoezT,headers=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,cookies=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,redirects=JVwYHPFkcdDNLamiQOGuEptSKRoeyf)
   if JVwYHPFkcdDNLamiQOGuEptSKRoezq.status_code not in[200]:return[]
   JVwYHPFkcdDNLamiQOGuEptSKRoezb=json.loads(JVwYHPFkcdDNLamiQOGuEptSKRoezq.text)
   for JVwYHPFkcdDNLamiQOGuEptSKRoezf in JVwYHPFkcdDNLamiQOGuEptSKRoezb.get('data'):
    if JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('type')=='Title-Rails-Curation':
     JVwYHPFkcdDNLamiQOGuEptSKRoeBM =''
     JVwYHPFkcdDNLamiQOGuEptSKRoeBT=7
     try:
      for i in JVwYHPFkcdDNLamiQOGuEptSKRoeyj(JVwYHPFkcdDNLamiQOGuEptSKRoeyg(JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('data'))):
       if i>=JVwYHPFkcdDNLamiQOGuEptSKRoeBT:
        JVwYHPFkcdDNLamiQOGuEptSKRoeBM=JVwYHPFkcdDNLamiQOGuEptSKRoeBM+'...'
        break
       JVwYHPFkcdDNLamiQOGuEptSKRoeBM=JVwYHPFkcdDNLamiQOGuEptSKRoeBM+JVwYHPFkcdDNLamiQOGuEptSKRoezf['data'][i]['title']+'\n'
     except JVwYHPFkcdDNLamiQOGuEptSKRoeyn as exception:
      JVwYHPFkcdDNLamiQOGuEptSKRoeyI(exception)
     JVwYHPFkcdDNLamiQOGuEptSKRoezj={'collectionId':JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('obj_id'),'title':JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('row_name'),'category':JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('category'),'pre_title':JVwYHPFkcdDNLamiQOGuEptSKRoeBM,}
     JVwYHPFkcdDNLamiQOGuEptSKRoezM.append(JVwYHPFkcdDNLamiQOGuEptSKRoezj)
  except JVwYHPFkcdDNLamiQOGuEptSKRoeyn as exception:
   JVwYHPFkcdDNLamiQOGuEptSKRoeyI(exception)
   return[]
  return JVwYHPFkcdDNLamiQOGuEptSKRoezM
 def Get_Event_GroupList(JVwYHPFkcdDNLamiQOGuEptSKRoevB):
  JVwYHPFkcdDNLamiQOGuEptSKRoezM=[] 
  try:
   JVwYHPFkcdDNLamiQOGuEptSKRoezy=JVwYHPFkcdDNLamiQOGuEptSKRoevB.API_VIEWURL+'/v2/discover/feed' 
   JVwYHPFkcdDNLamiQOGuEptSKRoezT={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':7,'filterRestrictedContent':'false',}
   JVwYHPFkcdDNLamiQOGuEptSKRoezq=JVwYHPFkcdDNLamiQOGuEptSKRoevB.callRequestCookies('Get',JVwYHPFkcdDNLamiQOGuEptSKRoezy,payload=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,params=JVwYHPFkcdDNLamiQOGuEptSKRoezT,headers=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,cookies=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,redirects=JVwYHPFkcdDNLamiQOGuEptSKRoeyf)
   if JVwYHPFkcdDNLamiQOGuEptSKRoezq.status_code not in[200]:return[]
   JVwYHPFkcdDNLamiQOGuEptSKRoezb=json.loads(JVwYHPFkcdDNLamiQOGuEptSKRoezq.text)
   for JVwYHPFkcdDNLamiQOGuEptSKRoezf in JVwYHPFkcdDNLamiQOGuEptSKRoezb.get('data'):
    if JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('row_name').strip()!='':
     JVwYHPFkcdDNLamiQOGuEptSKRoeBM =''
     JVwYHPFkcdDNLamiQOGuEptSKRoeBT=7
     try:
      for i in JVwYHPFkcdDNLamiQOGuEptSKRoeyj(JVwYHPFkcdDNLamiQOGuEptSKRoeyg(JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('data'))):
       if i>=JVwYHPFkcdDNLamiQOGuEptSKRoeBT:
        JVwYHPFkcdDNLamiQOGuEptSKRoeBM=JVwYHPFkcdDNLamiQOGuEptSKRoeBM+'...'
        break
       JVwYHPFkcdDNLamiQOGuEptSKRoeBM=JVwYHPFkcdDNLamiQOGuEptSKRoeBM+JVwYHPFkcdDNLamiQOGuEptSKRoezf['data'][i]['title']+'\n'
     except JVwYHPFkcdDNLamiQOGuEptSKRoeyn as exception:
      JVwYHPFkcdDNLamiQOGuEptSKRoeyI(exception)
     JVwYHPFkcdDNLamiQOGuEptSKRoezj={'collectionId':JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('obj_id'),'title':JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('row_name'),'category':JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('type'),'pre_title':JVwYHPFkcdDNLamiQOGuEptSKRoeBM,}
     JVwYHPFkcdDNLamiQOGuEptSKRoezM.append(JVwYHPFkcdDNLamiQOGuEptSKRoezj)
  except JVwYHPFkcdDNLamiQOGuEptSKRoeyn as exception:
   JVwYHPFkcdDNLamiQOGuEptSKRoeyI(exception)
   return[]
  return JVwYHPFkcdDNLamiQOGuEptSKRoezM
 def Get_Event_GameList(JVwYHPFkcdDNLamiQOGuEptSKRoevB,JVwYHPFkcdDNLamiQOGuEptSKRoezg):
  JVwYHPFkcdDNLamiQOGuEptSKRoezM=[] 
  try:
   JVwYHPFkcdDNLamiQOGuEptSKRoezy=JVwYHPFkcdDNLamiQOGuEptSKRoevB.API_VIEWURL+'/v2/discover/feed' 
   JVwYHPFkcdDNLamiQOGuEptSKRoezT={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false',}
   JVwYHPFkcdDNLamiQOGuEptSKRoezq=JVwYHPFkcdDNLamiQOGuEptSKRoevB.callRequestCookies('Get',JVwYHPFkcdDNLamiQOGuEptSKRoezy,payload=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,params=JVwYHPFkcdDNLamiQOGuEptSKRoezT,headers=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,cookies=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,redirects=JVwYHPFkcdDNLamiQOGuEptSKRoeyf)
   if JVwYHPFkcdDNLamiQOGuEptSKRoezq.status_code not in[200]:return[]
   JVwYHPFkcdDNLamiQOGuEptSKRoezb=json.loads(JVwYHPFkcdDNLamiQOGuEptSKRoezq.text)
   for JVwYHPFkcdDNLamiQOGuEptSKRoezf in JVwYHPFkcdDNLamiQOGuEptSKRoezb.get('data'):
    if JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('obj_id')==JVwYHPFkcdDNLamiQOGuEptSKRoezg:
     for JVwYHPFkcdDNLamiQOGuEptSKRoeBn in JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('data'):
      JVwYHPFkcdDNLamiQOGuEptSKRoeBy=JVwYHPFkcdDNLamiQOGuEptSKRoeBs=JVwYHPFkcdDNLamiQOGuEptSKRoeyU=''
      if 'poster' in JVwYHPFkcdDNLamiQOGuEptSKRoeBn.get('images'):JVwYHPFkcdDNLamiQOGuEptSKRoeBy =JVwYHPFkcdDNLamiQOGuEptSKRoeBn.get('images').get('poster').get('url')
      if 'story-art' in JVwYHPFkcdDNLamiQOGuEptSKRoeBn.get('images'):JVwYHPFkcdDNLamiQOGuEptSKRoeBs =JVwYHPFkcdDNLamiQOGuEptSKRoeBn.get('images').get('story-art').get('url')
      if 'hero' in JVwYHPFkcdDNLamiQOGuEptSKRoeBn.get('images'):JVwYHPFkcdDNLamiQOGuEptSKRoeyU =JVwYHPFkcdDNLamiQOGuEptSKRoeBn.get('images').get('hero').get('url')
      JVwYHPFkcdDNLamiQOGuEptSKRoeBA=JVwYHPFkcdDNLamiQOGuEptSKRoeBn.get('meta').get(JVwYHPFkcdDNLamiQOGuEptSKRoeBn.get('category')).get(JVwYHPFkcdDNLamiQOGuEptSKRoeBn.get('sub_category'))
      if 'league' in JVwYHPFkcdDNLamiQOGuEptSKRoeBA:
       JVwYHPFkcdDNLamiQOGuEptSKRoeBf=JVwYHPFkcdDNLamiQOGuEptSKRoeBA.get('league')
      else:
       JVwYHPFkcdDNLamiQOGuEptSKRoeBf=JVwYHPFkcdDNLamiQOGuEptSKRoeBA.get('round')
      JVwYHPFkcdDNLamiQOGuEptSKRoezj={'id':JVwYHPFkcdDNLamiQOGuEptSKRoeBn.get('id'),'title':JVwYHPFkcdDNLamiQOGuEptSKRoeBn.get('title'),'thumbnail':{'poster':JVwYHPFkcdDNLamiQOGuEptSKRoeBy,'thumb':JVwYHPFkcdDNLamiQOGuEptSKRoeBs,'fanart':JVwYHPFkcdDNLamiQOGuEptSKRoeyU},'asis':JVwYHPFkcdDNLamiQOGuEptSKRoeBn.get('type'),'addInfo':JVwYHPFkcdDNLamiQOGuEptSKRoeBf,'starttm':JVwYHPFkcdDNLamiQOGuEptSKRoevB.convert_TimeStr(JVwYHPFkcdDNLamiQOGuEptSKRoeBn.get('start_at')),}
      JVwYHPFkcdDNLamiQOGuEptSKRoezM.append(JVwYHPFkcdDNLamiQOGuEptSKRoezj)
  except JVwYHPFkcdDNLamiQOGuEptSKRoeyn as exception:
   JVwYHPFkcdDNLamiQOGuEptSKRoeyI(exception)
   return[]
  return JVwYHPFkcdDNLamiQOGuEptSKRoezM
 def Get_Event_List(JVwYHPFkcdDNLamiQOGuEptSKRoevB,gameId):
  JVwYHPFkcdDNLamiQOGuEptSKRoezM=[] 
  try:
   JVwYHPFkcdDNLamiQOGuEptSKRoezy=JVwYHPFkcdDNLamiQOGuEptSKRoevB.API_VIEWURL+'/v1/discover/events/'+gameId 
   JVwYHPFkcdDNLamiQOGuEptSKRoezT={'platform':'WEBCLIENT','locale':'ko','filterRestrictedContent':'false',}
   JVwYHPFkcdDNLamiQOGuEptSKRoezq=JVwYHPFkcdDNLamiQOGuEptSKRoevB.callRequestCookies('Get',JVwYHPFkcdDNLamiQOGuEptSKRoezy,payload=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,params=JVwYHPFkcdDNLamiQOGuEptSKRoezT,headers=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,cookies=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,redirects=JVwYHPFkcdDNLamiQOGuEptSKRoeyf)
   if JVwYHPFkcdDNLamiQOGuEptSKRoezq.status_code not in[200]:return[]
   JVwYHPFkcdDNLamiQOGuEptSKRoezb=json.loads(JVwYHPFkcdDNLamiQOGuEptSKRoezq.text)
   JVwYHPFkcdDNLamiQOGuEptSKRoezf=JVwYHPFkcdDNLamiQOGuEptSKRoezb.get('data')
   JVwYHPFkcdDNLamiQOGuEptSKRoeBg=JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('end_at')
   JVwYHPFkcdDNLamiQOGuEptSKRoeBg=JVwYHPFkcdDNLamiQOGuEptSKRoeBg[0:19].replace('-','').replace(':','').replace('T','')
   JVwYHPFkcdDNLamiQOGuEptSKRoeBj=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d%H%M%S')
   if JVwYHPFkcdDNLamiQOGuEptSKRoeyT(JVwYHPFkcdDNLamiQOGuEptSKRoeBj)<JVwYHPFkcdDNLamiQOGuEptSKRoeyT(JVwYHPFkcdDNLamiQOGuEptSKRoeBg):
    JVwYHPFkcdDNLamiQOGuEptSKRoeBy=JVwYHPFkcdDNLamiQOGuEptSKRoeBs=JVwYHPFkcdDNLamiQOGuEptSKRoeyU=''
    if 'poster' in JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('images'):JVwYHPFkcdDNLamiQOGuEptSKRoeBy =JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('images').get('poster').get('url')
    if 'story-art' in JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('images'):JVwYHPFkcdDNLamiQOGuEptSKRoeBs =JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('images').get('story-art').get('url')
    if 'story-art' in JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('images'):JVwYHPFkcdDNLamiQOGuEptSKRoeyU =JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('images').get('story-art').get('url')
    JVwYHPFkcdDNLamiQOGuEptSKRoezj={'id':JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('id'),'title':JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('title'),'thumbnail':{'poster':JVwYHPFkcdDNLamiQOGuEptSKRoeBy,'thumb':JVwYHPFkcdDNLamiQOGuEptSKRoeBs,'fanart':JVwYHPFkcdDNLamiQOGuEptSKRoeyU},'duration':JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('running_time'),'asis':JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('type'),'starttm':JVwYHPFkcdDNLamiQOGuEptSKRoevB.convert_TimeStr(JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('start_at')),}
    JVwYHPFkcdDNLamiQOGuEptSKRoezM.append(JVwYHPFkcdDNLamiQOGuEptSKRoezj)
  except JVwYHPFkcdDNLamiQOGuEptSKRoeyn as exception:
   JVwYHPFkcdDNLamiQOGuEptSKRoeyI(exception)
   return[]
  try:
   JVwYHPFkcdDNLamiQOGuEptSKRoezy=JVwYHPFkcdDNLamiQOGuEptSKRoevB.API_VIEWURL+'/v1/discover/events/'+gameId+'/related' 
   JVwYHPFkcdDNLamiQOGuEptSKRoezT={'locale':'ko','page':'1','perPage':'25','platform':'WEBCLIENT','currentPageTracking':'page_discover_title_detail',}
   JVwYHPFkcdDNLamiQOGuEptSKRoezq=JVwYHPFkcdDNLamiQOGuEptSKRoevB.callRequestCookies('Get',JVwYHPFkcdDNLamiQOGuEptSKRoezy,payload=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,params=JVwYHPFkcdDNLamiQOGuEptSKRoezT,headers=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,cookies=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,redirects=JVwYHPFkcdDNLamiQOGuEptSKRoeyf)
   if JVwYHPFkcdDNLamiQOGuEptSKRoezq.status_code not in[200]:return[]
   JVwYHPFkcdDNLamiQOGuEptSKRoezb=json.loads(JVwYHPFkcdDNLamiQOGuEptSKRoezq.text)
   for JVwYHPFkcdDNLamiQOGuEptSKRoezf in JVwYHPFkcdDNLamiQOGuEptSKRoezb.get('data').get('data'):
    JVwYHPFkcdDNLamiQOGuEptSKRoeBy=JVwYHPFkcdDNLamiQOGuEptSKRoeBs=JVwYHPFkcdDNLamiQOGuEptSKRoeyU=''
    if 'poster' in JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('images'):JVwYHPFkcdDNLamiQOGuEptSKRoeBy =JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('images').get('poster').get('url')
    if 'story-art' in JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('images'):JVwYHPFkcdDNLamiQOGuEptSKRoeBs =JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('images').get('story-art').get('url')
    if 'story-art' in JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('images'):JVwYHPFkcdDNLamiQOGuEptSKRoeyU =JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('images').get('story-art').get('url')
    JVwYHPFkcdDNLamiQOGuEptSKRoezj={'id':JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('id'),'title':JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('title'),'thumbnail':{'poster':JVwYHPFkcdDNLamiQOGuEptSKRoeBy,'thumb':JVwYHPFkcdDNLamiQOGuEptSKRoeBs,'fanart':JVwYHPFkcdDNLamiQOGuEptSKRoeyU},'duration':JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('running_time'),'asis':JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('type'),}
    JVwYHPFkcdDNLamiQOGuEptSKRoezM.append(JVwYHPFkcdDNLamiQOGuEptSKRoezj)
  except JVwYHPFkcdDNLamiQOGuEptSKRoeyn as exception:
   JVwYHPFkcdDNLamiQOGuEptSKRoeyI(exception)
   return[]
  return JVwYHPFkcdDNLamiQOGuEptSKRoezM
 def Get_Search_List(JVwYHPFkcdDNLamiQOGuEptSKRoevB,search_key,page_int):
  JVwYHPFkcdDNLamiQOGuEptSKRoezM=[] 
  JVwYHPFkcdDNLamiQOGuEptSKRoeBv=JVwYHPFkcdDNLamiQOGuEptSKRoeyW
  try:
   JVwYHPFkcdDNLamiQOGuEptSKRoezy=JVwYHPFkcdDNLamiQOGuEptSKRoevB.API_VIEWURL+'/v2/search' 
   JVwYHPFkcdDNLamiQOGuEptSKRoezT={'query':search_key,'platform':'WEBCLIENT','page':JVwYHPFkcdDNLamiQOGuEptSKRoeyC(page_int),'perPage':JVwYHPFkcdDNLamiQOGuEptSKRoeyC(JVwYHPFkcdDNLamiQOGuEptSKRoevB.SEARCH_LIMIT),}
   JVwYHPFkcdDNLamiQOGuEptSKRoezr={'x-membersrl':JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['member_srl'],'x-pcid':JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['PCID'],'x-profileid':JVwYHPFkcdDNLamiQOGuEptSKRoevB.CP['SESSION']['profileId'],}
   JVwYHPFkcdDNLamiQOGuEptSKRoezq=JVwYHPFkcdDNLamiQOGuEptSKRoevB.callRequestCookies('Get',JVwYHPFkcdDNLamiQOGuEptSKRoezy,payload=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,params=JVwYHPFkcdDNLamiQOGuEptSKRoezT,headers=JVwYHPFkcdDNLamiQOGuEptSKRoezr,cookies=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,redirects=JVwYHPFkcdDNLamiQOGuEptSKRoeyf)
   if JVwYHPFkcdDNLamiQOGuEptSKRoezq.status_code not in[200]:return[],JVwYHPFkcdDNLamiQOGuEptSKRoeyW
   JVwYHPFkcdDNLamiQOGuEptSKRoezb=json.loads(JVwYHPFkcdDNLamiQOGuEptSKRoezq.text)
   for JVwYHPFkcdDNLamiQOGuEptSKRoezf in JVwYHPFkcdDNLamiQOGuEptSKRoezb.get('data').get('data'):
    JVwYHPFkcdDNLamiQOGuEptSKRoezf=JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('data')
    JVwYHPFkcdDNLamiQOGuEptSKRoeBy=JVwYHPFkcdDNLamiQOGuEptSKRoeBs=JVwYHPFkcdDNLamiQOGuEptSKRoeyX=JVwYHPFkcdDNLamiQOGuEptSKRoeyU=''
    if 'poster' in JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('images'):JVwYHPFkcdDNLamiQOGuEptSKRoeBy =JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('images').get('poster').get('url')
    if 'story-art' in JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('images'):JVwYHPFkcdDNLamiQOGuEptSKRoeBs =JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('images').get('story-art').get('url')
    if 'title-treatment' in JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('images'):JVwYHPFkcdDNLamiQOGuEptSKRoeyX=JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('images').get('title-treatment').get('url')
    if 'story-art' in JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('images'):JVwYHPFkcdDNLamiQOGuEptSKRoeyU =JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('images').get('story-art').get('url')
    JVwYHPFkcdDNLamiQOGuEptSKRoeBq=''
    if JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('badge')not in[{},JVwYHPFkcdDNLamiQOGuEptSKRoeyh]:
     for i in JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('badge').get('text'):
      if JVwYHPFkcdDNLamiQOGuEptSKRoeBq!='':JVwYHPFkcdDNLamiQOGuEptSKRoeBq+=' '
      JVwYHPFkcdDNLamiQOGuEptSKRoeBq+=i.get('text')
    if 'as' in JVwYHPFkcdDNLamiQOGuEptSKRoezf:
     JVwYHPFkcdDNLamiQOGuEptSKRoeyv=JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('as') 
    else:
     JVwYHPFkcdDNLamiQOGuEptSKRoeyv=JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('type')
    JVwYHPFkcdDNLamiQOGuEptSKRoezj={'id':JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('id'),'title':JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('title'),'asis':JVwYHPFkcdDNLamiQOGuEptSKRoeyv,'thumbnail':{'poster':JVwYHPFkcdDNLamiQOGuEptSKRoeBy,'thumb':JVwYHPFkcdDNLamiQOGuEptSKRoeBs,'clearlogo':JVwYHPFkcdDNLamiQOGuEptSKRoeyX,'fanart':JVwYHPFkcdDNLamiQOGuEptSKRoeyU},'mpaa':JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('age_rating'),'duration':JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('running_time'),'badge':JVwYHPFkcdDNLamiQOGuEptSKRoeBq,'year':JVwYHPFkcdDNLamiQOGuEptSKRoezf.get('meta').get('releaseYear'),}
    JVwYHPFkcdDNLamiQOGuEptSKRoezM.append(JVwYHPFkcdDNLamiQOGuEptSKRoezj)
   if JVwYHPFkcdDNLamiQOGuEptSKRoezb.get('pagination').get('totalPages')>page_int:
    JVwYHPFkcdDNLamiQOGuEptSKRoeBv=JVwYHPFkcdDNLamiQOGuEptSKRoeyf
  except JVwYHPFkcdDNLamiQOGuEptSKRoeyn as exception:
   JVwYHPFkcdDNLamiQOGuEptSKRoeyI(exception)
   return[],JVwYHPFkcdDNLamiQOGuEptSKRoeyW
  return JVwYHPFkcdDNLamiQOGuEptSKRoezM,JVwYHPFkcdDNLamiQOGuEptSKRoeBv
 def GetBookmarkInfo(JVwYHPFkcdDNLamiQOGuEptSKRoevB,videoid,vidtype):
  JVwYHPFkcdDNLamiQOGuEptSKRoeyz={'indexinfo':{'ott':'coupang','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  JVwYHPFkcdDNLamiQOGuEptSKRoezy=JVwYHPFkcdDNLamiQOGuEptSKRoevB.API_VIEWURL+'/v1/discover/titles/'+videoid 
  JVwYHPFkcdDNLamiQOGuEptSKRoezT={'locale':'ko'}
  JVwYHPFkcdDNLamiQOGuEptSKRoezq=JVwYHPFkcdDNLamiQOGuEptSKRoevB.callRequestCookies('Get',JVwYHPFkcdDNLamiQOGuEptSKRoezy,payload=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,params=JVwYHPFkcdDNLamiQOGuEptSKRoezT,headers=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,cookies=JVwYHPFkcdDNLamiQOGuEptSKRoeyh,redirects=JVwYHPFkcdDNLamiQOGuEptSKRoeyf)
  if JVwYHPFkcdDNLamiQOGuEptSKRoezq.status_code not in[200]:return{}
  JVwYHPFkcdDNLamiQOGuEptSKRoeyB=json.loads(JVwYHPFkcdDNLamiQOGuEptSKRoezq.text).get('data')
  JVwYHPFkcdDNLamiQOGuEptSKRoeyq=JVwYHPFkcdDNLamiQOGuEptSKRoeyB.get('title')
  JVwYHPFkcdDNLamiQOGuEptSKRoeyx =JVwYHPFkcdDNLamiQOGuEptSKRoeyB.get('meta').get('releaseYear')
  JVwYHPFkcdDNLamiQOGuEptSKRoeyz['saveinfo']['infoLabels']['title']=JVwYHPFkcdDNLamiQOGuEptSKRoeyq
  if vidtype=='movie':
   JVwYHPFkcdDNLamiQOGuEptSKRoeyq='%s  (%s)'%(JVwYHPFkcdDNLamiQOGuEptSKRoeyq,JVwYHPFkcdDNLamiQOGuEptSKRoeyx)
  JVwYHPFkcdDNLamiQOGuEptSKRoeyz['saveinfo']['title'] =JVwYHPFkcdDNLamiQOGuEptSKRoeyq
  JVwYHPFkcdDNLamiQOGuEptSKRoeyz['saveinfo']['infoLabels']['mpaa'] =JVwYHPFkcdDNLamiQOGuEptSKRoeyB.get('age_rating')
  JVwYHPFkcdDNLamiQOGuEptSKRoeyz['saveinfo']['infoLabels']['plot'] ='%s\n\n%s'%(JVwYHPFkcdDNLamiQOGuEptSKRoeyB.get('short_description'),JVwYHPFkcdDNLamiQOGuEptSKRoeyB.get('description'))
  JVwYHPFkcdDNLamiQOGuEptSKRoeyz['saveinfo']['infoLabels']['year'] =JVwYHPFkcdDNLamiQOGuEptSKRoeyx
  if vidtype=='movie':
   JVwYHPFkcdDNLamiQOGuEptSKRoeyz['saveinfo']['infoLabels']['duration']=JVwYHPFkcdDNLamiQOGuEptSKRoeyB.get('running_time')
  JVwYHPFkcdDNLamiQOGuEptSKRoeBy =''
  JVwYHPFkcdDNLamiQOGuEptSKRoeyU =''
  JVwYHPFkcdDNLamiQOGuEptSKRoeBs =''
  JVwYHPFkcdDNLamiQOGuEptSKRoeyX=''
  if JVwYHPFkcdDNLamiQOGuEptSKRoeyB.get('images').get('poster') !=JVwYHPFkcdDNLamiQOGuEptSKRoeyh:JVwYHPFkcdDNLamiQOGuEptSKRoeBy =JVwYHPFkcdDNLamiQOGuEptSKRoeyB.get('images').get('poster').get('url')
  if JVwYHPFkcdDNLamiQOGuEptSKRoeyB.get('images').get('background') !=JVwYHPFkcdDNLamiQOGuEptSKRoeyh:JVwYHPFkcdDNLamiQOGuEptSKRoeyU =JVwYHPFkcdDNLamiQOGuEptSKRoeyB.get('images').get('background').get('url')
  if JVwYHPFkcdDNLamiQOGuEptSKRoeyB.get('images').get('story-art') !=JVwYHPFkcdDNLamiQOGuEptSKRoeyh:JVwYHPFkcdDNLamiQOGuEptSKRoeBs =JVwYHPFkcdDNLamiQOGuEptSKRoeyB.get('images').get('story-art').get('url')
  if JVwYHPFkcdDNLamiQOGuEptSKRoeyB.get('images').get('title-treatment')!=JVwYHPFkcdDNLamiQOGuEptSKRoeyh:JVwYHPFkcdDNLamiQOGuEptSKRoeyX=JVwYHPFkcdDNLamiQOGuEptSKRoeyB.get('images').get('title-treatment').get('url')
  if JVwYHPFkcdDNLamiQOGuEptSKRoeyU=='':JVwYHPFkcdDNLamiQOGuEptSKRoeyU=JVwYHPFkcdDNLamiQOGuEptSKRoeBs
  JVwYHPFkcdDNLamiQOGuEptSKRoeyz['saveinfo']['thumbnail']['poster']=JVwYHPFkcdDNLamiQOGuEptSKRoeBy
  JVwYHPFkcdDNLamiQOGuEptSKRoeyz['saveinfo']['thumbnail']['fanart']=JVwYHPFkcdDNLamiQOGuEptSKRoeyU
  JVwYHPFkcdDNLamiQOGuEptSKRoeyz['saveinfo']['thumbnail']['thumb']=JVwYHPFkcdDNLamiQOGuEptSKRoeBs
  JVwYHPFkcdDNLamiQOGuEptSKRoeyz['saveinfo']['thumbnail']['clearlogo']=JVwYHPFkcdDNLamiQOGuEptSKRoeyX
  JVwYHPFkcdDNLamiQOGuEptSKRoeys=[]
  for JVwYHPFkcdDNLamiQOGuEptSKRoeBX in JVwYHPFkcdDNLamiQOGuEptSKRoeyB.get('tags'):JVwYHPFkcdDNLamiQOGuEptSKRoeys.append(JVwYHPFkcdDNLamiQOGuEptSKRoeBX.get('tag'))
  if JVwYHPFkcdDNLamiQOGuEptSKRoeyg(JVwYHPFkcdDNLamiQOGuEptSKRoeys)>0:
   JVwYHPFkcdDNLamiQOGuEptSKRoeyz['saveinfo']['infoLabels']['genre']=JVwYHPFkcdDNLamiQOGuEptSKRoeys
  JVwYHPFkcdDNLamiQOGuEptSKRoeyr=[]
  JVwYHPFkcdDNLamiQOGuEptSKRoeyl=[]
  for JVwYHPFkcdDNLamiQOGuEptSKRoeBX in JVwYHPFkcdDNLamiQOGuEptSKRoeyB.get('people'):
   if JVwYHPFkcdDNLamiQOGuEptSKRoeBX.get('role')=='CAST' :JVwYHPFkcdDNLamiQOGuEptSKRoeyr.append(JVwYHPFkcdDNLamiQOGuEptSKRoeBX.get('name'))
   if JVwYHPFkcdDNLamiQOGuEptSKRoeBX.get('role')=='DIRECTOR':JVwYHPFkcdDNLamiQOGuEptSKRoeyl.append(JVwYHPFkcdDNLamiQOGuEptSKRoeBX.get('name'))
  if JVwYHPFkcdDNLamiQOGuEptSKRoeyg(JVwYHPFkcdDNLamiQOGuEptSKRoeyr)>0:
   JVwYHPFkcdDNLamiQOGuEptSKRoeyz['saveinfo']['infoLabels']['cast'] =JVwYHPFkcdDNLamiQOGuEptSKRoeyr
  if JVwYHPFkcdDNLamiQOGuEptSKRoeyg(JVwYHPFkcdDNLamiQOGuEptSKRoeyl)>0:
   JVwYHPFkcdDNLamiQOGuEptSKRoeyz['saveinfo']['infoLabels']['director']=JVwYHPFkcdDNLamiQOGuEptSKRoeyl
  return JVwYHPFkcdDNLamiQOGuEptSKRoeyz
# Created by pyminifier (https://github.com/liftoff/pyminifier)
