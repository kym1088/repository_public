__author__="NightRain"
CoIuVnBpmkQgFRMTWYAJiXOvsejLUc=object
CoIuVnBpmkQgFRMTWYAJiXOvsejLUG=None
CoIuVnBpmkQgFRMTWYAJiXOvsejLUw=False
CoIuVnBpmkQgFRMTWYAJiXOvsejLUf=True
CoIuVnBpmkQgFRMTWYAJiXOvsejLUb=type
CoIuVnBpmkQgFRMTWYAJiXOvsejLUD=dict
CoIuVnBpmkQgFRMTWYAJiXOvsejLUN=int
CoIuVnBpmkQgFRMTWYAJiXOvsejLUE=open
CoIuVnBpmkQgFRMTWYAJiXOvsejLUt=Exception
CoIuVnBpmkQgFRMTWYAJiXOvsejLUq=str
CoIuVnBpmkQgFRMTWYAJiXOvsejLUl=id
CoIuVnBpmkQgFRMTWYAJiXOvsejLdx=len
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import inputstreamhelper
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
CoIuVnBpmkQgFRMTWYAJiXOvsejLxH=[{'title':'홈   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'ALL'},{'title':'TV   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'MOVIES'},{'title':'교육 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'EDUCATION'},{'title':'-----------------','mode':'XXX'},{'title':'TV   (테마별)','mode':'THEME_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (테마별)','mode':'THEME_GROUPLIST','vType':'MOVIES'},{'title':'교육 (테마별)','mode':'THEME_GROUPLIST','vType':'EDUCATION'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},{'title':'(쿠팡) 검색','mode':'LOCAL_SEARCH','icon':'search.png'},{'title':'(쿠팡) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
CoIuVnBpmkQgFRMTWYAJiXOvsejLxy=[{'title':'시리즈 시청내역','mode':'WATCH','stype':'tvshow'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},]
CoIuVnBpmkQgFRMTWYAJiXOvsejLxz=xbmcvfs.translatePath(os.path.join(__profile__,'coupang_searched.txt'))
from coupangCore import*
class CoIuVnBpmkQgFRMTWYAJiXOvsejLxS(CoIuVnBpmkQgFRMTWYAJiXOvsejLUc):
 def __init__(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU,CoIuVnBpmkQgFRMTWYAJiXOvsejLxd,CoIuVnBpmkQgFRMTWYAJiXOvsejLxP,CoIuVnBpmkQgFRMTWYAJiXOvsejLxr):
  CoIuVnBpmkQgFRMTWYAJiXOvsejLxU._addon_url =CoIuVnBpmkQgFRMTWYAJiXOvsejLxd
  CoIuVnBpmkQgFRMTWYAJiXOvsejLxU._addon_handle=CoIuVnBpmkQgFRMTWYAJiXOvsejLxP
  CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.main_params =CoIuVnBpmkQgFRMTWYAJiXOvsejLxr
  CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.CoupangObj =ehgRpUTwClNXmqQEPHfMbvcYBdnWyK() 
  CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.CoupangObj.CP_COOKIE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_cookies.json'))
  CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.CoupangObj.CP_DEVICE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_device.json'))
 def addon_noti(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU,sting):
  try:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxK=xbmcgui.Dialog()
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxK.notification(__addonname__,sting)
  except:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLUG
 def addon_log(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU,string):
  try:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxh=string.encode('utf-8','ignore')
  except:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxh='addonException: addon_log'
  CoIuVnBpmkQgFRMTWYAJiXOvsejLxc=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,CoIuVnBpmkQgFRMTWYAJiXOvsejLxh),level=CoIuVnBpmkQgFRMTWYAJiXOvsejLxc)
 def get_keyboard_input(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU,CoIuVnBpmkQgFRMTWYAJiXOvsejLSH):
  CoIuVnBpmkQgFRMTWYAJiXOvsejLxG=CoIuVnBpmkQgFRMTWYAJiXOvsejLUG
  kb=xbmc.Keyboard()
  kb.setHeading(CoIuVnBpmkQgFRMTWYAJiXOvsejLSH)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxG=kb.getText()
  return CoIuVnBpmkQgFRMTWYAJiXOvsejLxG
 def get_settings_account(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU):
  CoIuVnBpmkQgFRMTWYAJiXOvsejLxw=__addon__.getSetting('id')
  CoIuVnBpmkQgFRMTWYAJiXOvsejLxf=__addon__.getSetting('pw')
  CoIuVnBpmkQgFRMTWYAJiXOvsejLxb=__addon__.getSetting('profile')
  return(CoIuVnBpmkQgFRMTWYAJiXOvsejLxw,CoIuVnBpmkQgFRMTWYAJiXOvsejLxf,CoIuVnBpmkQgFRMTWYAJiXOvsejLxb)
 def get_settings_exclusion21(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU):
  CoIuVnBpmkQgFRMTWYAJiXOvsejLxD =__addon__.getSetting('exclusion21')
  if CoIuVnBpmkQgFRMTWYAJiXOvsejLxD=='false':
   return CoIuVnBpmkQgFRMTWYAJiXOvsejLUw
  else:
   return CoIuVnBpmkQgFRMTWYAJiXOvsejLUf
 def get_settings_totalsearch(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU):
  CoIuVnBpmkQgFRMTWYAJiXOvsejLxN =CoIuVnBpmkQgFRMTWYAJiXOvsejLUf if __addon__.getSetting('local_search')=='true' else CoIuVnBpmkQgFRMTWYAJiXOvsejLUw
  CoIuVnBpmkQgFRMTWYAJiXOvsejLxE=CoIuVnBpmkQgFRMTWYAJiXOvsejLUf if __addon__.getSetting('local_history')=='true' else CoIuVnBpmkQgFRMTWYAJiXOvsejLUw
  CoIuVnBpmkQgFRMTWYAJiXOvsejLxt =CoIuVnBpmkQgFRMTWYAJiXOvsejLUf if __addon__.getSetting('total_search')=='true' else CoIuVnBpmkQgFRMTWYAJiXOvsejLUw
  CoIuVnBpmkQgFRMTWYAJiXOvsejLxq=CoIuVnBpmkQgFRMTWYAJiXOvsejLUf if __addon__.getSetting('total_history')=='true' else CoIuVnBpmkQgFRMTWYAJiXOvsejLUw
  CoIuVnBpmkQgFRMTWYAJiXOvsejLxl=CoIuVnBpmkQgFRMTWYAJiXOvsejLUf if __addon__.getSetting('menu_bookmark')=='true' else CoIuVnBpmkQgFRMTWYAJiXOvsejLUw
  return(CoIuVnBpmkQgFRMTWYAJiXOvsejLxN,CoIuVnBpmkQgFRMTWYAJiXOvsejLxE,CoIuVnBpmkQgFRMTWYAJiXOvsejLxt,CoIuVnBpmkQgFRMTWYAJiXOvsejLxq,CoIuVnBpmkQgFRMTWYAJiXOvsejLxl)
 def get_settings_makebookmark(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU):
  return CoIuVnBpmkQgFRMTWYAJiXOvsejLUf if __addon__.getSetting('make_bookmark')=='true' else CoIuVnBpmkQgFRMTWYAJiXOvsejLUw
 def add_dir(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU,label,sublabel='',img='',infoLabels=CoIuVnBpmkQgFRMTWYAJiXOvsejLUG,isFolder=CoIuVnBpmkQgFRMTWYAJiXOvsejLUf,params='',isLink=CoIuVnBpmkQgFRMTWYAJiXOvsejLUw,ContextMenu=CoIuVnBpmkQgFRMTWYAJiXOvsejLUG):
  CoIuVnBpmkQgFRMTWYAJiXOvsejLSx='%s?%s'%(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU._addon_url,urllib.parse.urlencode(params))
  if sublabel:CoIuVnBpmkQgFRMTWYAJiXOvsejLSH='%s < %s >'%(label,sublabel)
  else: CoIuVnBpmkQgFRMTWYAJiXOvsejLSH=label
  if not img:img='DefaultFolder.png'
  CoIuVnBpmkQgFRMTWYAJiXOvsejLSy=xbmcgui.ListItem(CoIuVnBpmkQgFRMTWYAJiXOvsejLSH)
  if CoIuVnBpmkQgFRMTWYAJiXOvsejLUb(img)==CoIuVnBpmkQgFRMTWYAJiXOvsejLUD:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSy.setArt(img)
  else:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSy.setArt({'thumb':img,'poster':img})
  if infoLabels:CoIuVnBpmkQgFRMTWYAJiXOvsejLSy.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSy.setProperty('IsPlayable','true')
  if ContextMenu:CoIuVnBpmkQgFRMTWYAJiXOvsejLSy.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU._addon_handle,CoIuVnBpmkQgFRMTWYAJiXOvsejLSx,CoIuVnBpmkQgFRMTWYAJiXOvsejLSy,isFolder)
 def dp_Main_List(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU,args):
  (CoIuVnBpmkQgFRMTWYAJiXOvsejLxN,CoIuVnBpmkQgFRMTWYAJiXOvsejLxE,CoIuVnBpmkQgFRMTWYAJiXOvsejLxt,CoIuVnBpmkQgFRMTWYAJiXOvsejLxq,CoIuVnBpmkQgFRMTWYAJiXOvsejLxl)=CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.get_settings_totalsearch()
  for CoIuVnBpmkQgFRMTWYAJiXOvsejLSz in CoIuVnBpmkQgFRMTWYAJiXOvsejLxH:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSH=CoIuVnBpmkQgFRMTWYAJiXOvsejLSz.get('title')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSU=''
   if CoIuVnBpmkQgFRMTWYAJiXOvsejLSz.get('mode')=='LOCAL_SEARCH' and CoIuVnBpmkQgFRMTWYAJiXOvsejLxN ==CoIuVnBpmkQgFRMTWYAJiXOvsejLUw:continue
   elif CoIuVnBpmkQgFRMTWYAJiXOvsejLSz.get('mode')=='SEARCH_HISTORY' and CoIuVnBpmkQgFRMTWYAJiXOvsejLxE==CoIuVnBpmkQgFRMTWYAJiXOvsejLUw:continue
   elif CoIuVnBpmkQgFRMTWYAJiXOvsejLSz.get('mode')=='TOTAL_SEARCH' and CoIuVnBpmkQgFRMTWYAJiXOvsejLxt ==CoIuVnBpmkQgFRMTWYAJiXOvsejLUw:continue
   elif CoIuVnBpmkQgFRMTWYAJiXOvsejLSz.get('mode')=='TOTAL_HISTORY' and CoIuVnBpmkQgFRMTWYAJiXOvsejLxq==CoIuVnBpmkQgFRMTWYAJiXOvsejLUw:continue
   elif CoIuVnBpmkQgFRMTWYAJiXOvsejLSz.get('mode')=='MENU_BOOKMARK' and CoIuVnBpmkQgFRMTWYAJiXOvsejLxl==CoIuVnBpmkQgFRMTWYAJiXOvsejLUw:continue
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSd={'mode':CoIuVnBpmkQgFRMTWYAJiXOvsejLSz.get('mode'),'vType':CoIuVnBpmkQgFRMTWYAJiXOvsejLSz.get('vType'),'page':'1',}
   if CoIuVnBpmkQgFRMTWYAJiXOvsejLSz.get('mode')=='LOCAL_SEARCH':CoIuVnBpmkQgFRMTWYAJiXOvsejLSd['historyyn']='Y' 
   if CoIuVnBpmkQgFRMTWYAJiXOvsejLSz.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    CoIuVnBpmkQgFRMTWYAJiXOvsejLSP=CoIuVnBpmkQgFRMTWYAJiXOvsejLUw
    CoIuVnBpmkQgFRMTWYAJiXOvsejLSr =CoIuVnBpmkQgFRMTWYAJiXOvsejLUf
   else:
    CoIuVnBpmkQgFRMTWYAJiXOvsejLSP=CoIuVnBpmkQgFRMTWYAJiXOvsejLUf
    CoIuVnBpmkQgFRMTWYAJiXOvsejLSr =CoIuVnBpmkQgFRMTWYAJiXOvsejLUw
   if 'icon' in CoIuVnBpmkQgFRMTWYAJiXOvsejLSz:CoIuVnBpmkQgFRMTWYAJiXOvsejLSU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',CoIuVnBpmkQgFRMTWYAJiXOvsejLSz.get('icon')) 
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.add_dir(CoIuVnBpmkQgFRMTWYAJiXOvsejLSH,sublabel='',img=CoIuVnBpmkQgFRMTWYAJiXOvsejLSU,infoLabels=CoIuVnBpmkQgFRMTWYAJiXOvsejLUG,isFolder=CoIuVnBpmkQgFRMTWYAJiXOvsejLSP,params=CoIuVnBpmkQgFRMTWYAJiXOvsejLSd,isLink=CoIuVnBpmkQgFRMTWYAJiXOvsejLSr)
  xbmcplugin.endOfDirectory(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU._addon_handle)
 def dp_Test(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU,args):
  CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.addon_noti('test')
 def CP_logout(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU):
  CoIuVnBpmkQgFRMTWYAJiXOvsejLxK=xbmcgui.Dialog()
  CoIuVnBpmkQgFRMTWYAJiXOvsejLSK=CoIuVnBpmkQgFRMTWYAJiXOvsejLxK.yesno(__language__(30905).encode('utf8'),__language__(30906).encode('utf8'))
  if CoIuVnBpmkQgFRMTWYAJiXOvsejLSK==CoIuVnBpmkQgFRMTWYAJiXOvsejLUw:return 
  if os.path.isfile(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.CoupangObj.CP_COOKIE_FILENAME):os.remove(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.CoupangObj.CP_COOKIE_FILENAME)
  CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.addon_noti(__language__(30904).encode('utf-8'))
 def option_check(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU):
  (CoIuVnBpmkQgFRMTWYAJiXOvsejLxw,CoIuVnBpmkQgFRMTWYAJiXOvsejLxf,CoIuVnBpmkQgFRMTWYAJiXOvsejLxb)=CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.get_settings_account()
  if CoIuVnBpmkQgFRMTWYAJiXOvsejLxw=='' or CoIuVnBpmkQgFRMTWYAJiXOvsejLxf=='':
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxK=xbmcgui.Dialog()
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSK=CoIuVnBpmkQgFRMTWYAJiXOvsejLxK.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if CoIuVnBpmkQgFRMTWYAJiXOvsejLSK==CoIuVnBpmkQgFRMTWYAJiXOvsejLUf:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.cookiefile_check()==CoIuVnBpmkQgFRMTWYAJiXOvsejLUw:
   if CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.CP_login(CoIuVnBpmkQgFRMTWYAJiXOvsejLxw,CoIuVnBpmkQgFRMTWYAJiXOvsejLxf,CoIuVnBpmkQgFRMTWYAJiXOvsejLxb)==CoIuVnBpmkQgFRMTWYAJiXOvsejLUw:
    CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.addon_noti(__language__(30903).encode('utf8'))
    sys.exit()
  else:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.CoupangObj.Get_CP_profile(CoIuVnBpmkQgFRMTWYAJiXOvsejLxb,limit_days=CoIuVnBpmkQgFRMTWYAJiXOvsejLUN(__addon__.getSetting('cache_ttl')),re_check=CoIuVnBpmkQgFRMTWYAJiXOvsejLUf)
 def cookiefile_check(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU):
  CoIuVnBpmkQgFRMTWYAJiXOvsejLSc={}
  try: 
   fp=CoIuVnBpmkQgFRMTWYAJiXOvsejLUE(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.CoupangObj.CP_COOKIE_FILENAME,'r',-1,'utf-8')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSc= json.load(fp)
   fp.close()
  except CoIuVnBpmkQgFRMTWYAJiXOvsejLUt as exception:
   return CoIuVnBpmkQgFRMTWYAJiXOvsejLUw
  CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.CoupangObj.CP=CoIuVnBpmkQgFRMTWYAJiXOvsejLSc
  (CoIuVnBpmkQgFRMTWYAJiXOvsejLxw,CoIuVnBpmkQgFRMTWYAJiXOvsejLxf,CoIuVnBpmkQgFRMTWYAJiXOvsejLxb)=CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.get_settings_account()
  (CoIuVnBpmkQgFRMTWYAJiXOvsejLSG,CoIuVnBpmkQgFRMTWYAJiXOvsejLSw,CoIuVnBpmkQgFRMTWYAJiXOvsejLSf)=CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.CoupangObj.Load_session_acount()
  if CoIuVnBpmkQgFRMTWYAJiXOvsejLxw!=CoIuVnBpmkQgFRMTWYAJiXOvsejLSG or CoIuVnBpmkQgFRMTWYAJiXOvsejLxf!=CoIuVnBpmkQgFRMTWYAJiXOvsejLSw or CoIuVnBpmkQgFRMTWYAJiXOvsejLxb!=CoIuVnBpmkQgFRMTWYAJiXOvsejLUq(CoIuVnBpmkQgFRMTWYAJiXOvsejLSf):
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.CoupangObj.Init_CP()
   return CoIuVnBpmkQgFRMTWYAJiXOvsejLUw
  CoIuVnBpmkQgFRMTWYAJiXOvsejLSb =CoIuVnBpmkQgFRMTWYAJiXOvsejLUN(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.CoupangObj.Get_Now_Datetime().strftime('%Y%m%d'))
  CoIuVnBpmkQgFRMTWYAJiXOvsejLSD=CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.CoupangObj.CP['SESSION']['limitdate']
  CoIuVnBpmkQgFRMTWYAJiXOvsejLSN =CoIuVnBpmkQgFRMTWYAJiXOvsejLUN(re.sub('-','',CoIuVnBpmkQgFRMTWYAJiXOvsejLSD))
  if CoIuVnBpmkQgFRMTWYAJiXOvsejLSN<CoIuVnBpmkQgFRMTWYAJiXOvsejLSb:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.CoupangObj.Init_CP()
   return CoIuVnBpmkQgFRMTWYAJiXOvsejLUw
  return CoIuVnBpmkQgFRMTWYAJiXOvsejLUf
 def CP_login(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU,CoIuVnBpmkQgFRMTWYAJiXOvsejLxw,CoIuVnBpmkQgFRMTWYAJiXOvsejLxf,CoIuVnBpmkQgFRMTWYAJiXOvsejLxb):
  if CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.CoupangObj.Get_CP_Login(CoIuVnBpmkQgFRMTWYAJiXOvsejLxw,CoIuVnBpmkQgFRMTWYAJiXOvsejLxf,CoIuVnBpmkQgFRMTWYAJiXOvsejLxb)==CoIuVnBpmkQgFRMTWYAJiXOvsejLUw:return CoIuVnBpmkQgFRMTWYAJiXOvsejLUw
  if CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.CoupangObj.Get_CP_profile(CoIuVnBpmkQgFRMTWYAJiXOvsejLxb,limit_days=CoIuVnBpmkQgFRMTWYAJiXOvsejLUN(__addon__.getSetting('cache_ttl')),re_check=CoIuVnBpmkQgFRMTWYAJiXOvsejLUw)==CoIuVnBpmkQgFRMTWYAJiXOvsejLUw:return CoIuVnBpmkQgFRMTWYAJiXOvsejLUw
  return CoIuVnBpmkQgFRMTWYAJiXOvsejLUf
 def dp_Category_GroupList(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU,args):
  CoIuVnBpmkQgFRMTWYAJiXOvsejLSE =args.get('vType') 
  CoIuVnBpmkQgFRMTWYAJiXOvsejLSt=CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.CoupangObj.Get_Category_GroupList(CoIuVnBpmkQgFRMTWYAJiXOvsejLSE)
  for CoIuVnBpmkQgFRMTWYAJiXOvsejLSq in CoIuVnBpmkQgFRMTWYAJiXOvsejLSt:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSH =CoIuVnBpmkQgFRMTWYAJiXOvsejLSq.get('title')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSl=CoIuVnBpmkQgFRMTWYAJiXOvsejLSq.get('pre_title')
   if CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.get_settings_exclusion21()==CoIuVnBpmkQgFRMTWYAJiXOvsejLUf and CoIuVnBpmkQgFRMTWYAJiXOvsejLSH=='성인':continue
   CoIuVnBpmkQgFRMTWYAJiXOvsejLHx={'plot':CoIuVnBpmkQgFRMTWYAJiXOvsejLSl,}
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSd={'mode':'CATEGORY_LIST','collectionId':CoIuVnBpmkQgFRMTWYAJiXOvsejLSq.get('collectionId'),'vType':CoIuVnBpmkQgFRMTWYAJiXOvsejLSq.get('category'),'page':'1',}
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.add_dir(CoIuVnBpmkQgFRMTWYAJiXOvsejLSH,sublabel='',img='',infoLabels=CoIuVnBpmkQgFRMTWYAJiXOvsejLHx,isFolder=CoIuVnBpmkQgFRMTWYAJiXOvsejLUf,params=CoIuVnBpmkQgFRMTWYAJiXOvsejLSd)
  xbmcplugin.endOfDirectory(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU._addon_handle,cacheToDisc=CoIuVnBpmkQgFRMTWYAJiXOvsejLUw)
 def dp_Theme_GroupList(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU,args):
  CoIuVnBpmkQgFRMTWYAJiXOvsejLSE =args.get('vType') 
  CoIuVnBpmkQgFRMTWYAJiXOvsejLSt=CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.CoupangObj.Get_Theme_GroupList(CoIuVnBpmkQgFRMTWYAJiXOvsejLSE)
  for CoIuVnBpmkQgFRMTWYAJiXOvsejLSq in CoIuVnBpmkQgFRMTWYAJiXOvsejLSt:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSH =CoIuVnBpmkQgFRMTWYAJiXOvsejLSq.get('title')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSl=CoIuVnBpmkQgFRMTWYAJiXOvsejLSq.get('pre_title')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLHx={'plot':CoIuVnBpmkQgFRMTWYAJiXOvsejLSl,}
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSd={'mode':'CATEGORY_LIST','collectionId':CoIuVnBpmkQgFRMTWYAJiXOvsejLSq.get('collectionId'),'vType':CoIuVnBpmkQgFRMTWYAJiXOvsejLSq.get('category'),'page':'1',}
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.add_dir(CoIuVnBpmkQgFRMTWYAJiXOvsejLSH,sublabel='',img='',infoLabels=CoIuVnBpmkQgFRMTWYAJiXOvsejLHx,isFolder=CoIuVnBpmkQgFRMTWYAJiXOvsejLUf,params=CoIuVnBpmkQgFRMTWYAJiXOvsejLSd)
  xbmcplugin.endOfDirectory(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU._addon_handle,cacheToDisc=CoIuVnBpmkQgFRMTWYAJiXOvsejLUw)
 def dp_Category_List(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU,args):
  CoIuVnBpmkQgFRMTWYAJiXOvsejLSE =args.get('vType') 
  CoIuVnBpmkQgFRMTWYAJiXOvsejLHy =args.get('collectionId')
  CoIuVnBpmkQgFRMTWYAJiXOvsejLHz =CoIuVnBpmkQgFRMTWYAJiXOvsejLUN(args.get('page'))
  CoIuVnBpmkQgFRMTWYAJiXOvsejLSt,CoIuVnBpmkQgFRMTWYAJiXOvsejLHU=CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.CoupangObj.Get_Category_List(CoIuVnBpmkQgFRMTWYAJiXOvsejLSE,CoIuVnBpmkQgFRMTWYAJiXOvsejLHy,CoIuVnBpmkQgFRMTWYAJiXOvsejLHz)
  for CoIuVnBpmkQgFRMTWYAJiXOvsejLSq in CoIuVnBpmkQgFRMTWYAJiXOvsejLSt:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSH =CoIuVnBpmkQgFRMTWYAJiXOvsejLSq.get('title')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLUl =CoIuVnBpmkQgFRMTWYAJiXOvsejLSq.get('id')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLHd =CoIuVnBpmkQgFRMTWYAJiXOvsejLSq.get('thumbnail')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLHP =CoIuVnBpmkQgFRMTWYAJiXOvsejLSq.get('mpaa')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLHr =CoIuVnBpmkQgFRMTWYAJiXOvsejLSq.get('duration')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLHa =CoIuVnBpmkQgFRMTWYAJiXOvsejLSq.get('asis')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLHK =CoIuVnBpmkQgFRMTWYAJiXOvsejLSq.get('badge')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLHh =CoIuVnBpmkQgFRMTWYAJiXOvsejLSq.get('year')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLHc=CoIuVnBpmkQgFRMTWYAJiXOvsejLSq.get('seasonList')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLHG =CoIuVnBpmkQgFRMTWYAJiXOvsejLSq.get('genreList')
   if CoIuVnBpmkQgFRMTWYAJiXOvsejLHa in['TVSHOW','EDUCATION']: 
    CoIuVnBpmkQgFRMTWYAJiXOvsejLHw ='SEASON_LIST'
    CoIuVnBpmkQgFRMTWYAJiXOvsejLHx={'mediatype':'tvshow','title':CoIuVnBpmkQgFRMTWYAJiXOvsejLSH,'mpaa':CoIuVnBpmkQgFRMTWYAJiXOvsejLHP,'genre':CoIuVnBpmkQgFRMTWYAJiXOvsejLHG,'year':CoIuVnBpmkQgFRMTWYAJiXOvsejLHh,'plot':'Year : %s\nSeason : %s'%(CoIuVnBpmkQgFRMTWYAJiXOvsejLHh,CoIuVnBpmkQgFRMTWYAJiXOvsejLHc),}
    CoIuVnBpmkQgFRMTWYAJiXOvsejLSP =CoIuVnBpmkQgFRMTWYAJiXOvsejLUf
   else:
    CoIuVnBpmkQgFRMTWYAJiXOvsejLHw ='MOVIE'
    CoIuVnBpmkQgFRMTWYAJiXOvsejLHx={'mediatype':'movie','title':CoIuVnBpmkQgFRMTWYAJiXOvsejLSH,'mpaa':CoIuVnBpmkQgFRMTWYAJiXOvsejLHP,'genre':CoIuVnBpmkQgFRMTWYAJiXOvsejLHG,'duration':CoIuVnBpmkQgFRMTWYAJiXOvsejLHr,'year':CoIuVnBpmkQgFRMTWYAJiXOvsejLHh,'plot':'(%s)'%(CoIuVnBpmkQgFRMTWYAJiXOvsejLHP),}
    CoIuVnBpmkQgFRMTWYAJiXOvsejLSP =CoIuVnBpmkQgFRMTWYAJiXOvsejLUw
    CoIuVnBpmkQgFRMTWYAJiXOvsejLSH +=' (%s)'%(CoIuVnBpmkQgFRMTWYAJiXOvsejLUq(CoIuVnBpmkQgFRMTWYAJiXOvsejLHh))
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSd={'mode':CoIuVnBpmkQgFRMTWYAJiXOvsejLHw,'id':CoIuVnBpmkQgFRMTWYAJiXOvsejLUl,'asis':CoIuVnBpmkQgFRMTWYAJiXOvsejLHa,'seasonList':CoIuVnBpmkQgFRMTWYAJiXOvsejLHc,'title':CoIuVnBpmkQgFRMTWYAJiXOvsejLSH,'thumbnail':CoIuVnBpmkQgFRMTWYAJiXOvsejLHd,'year':CoIuVnBpmkQgFRMTWYAJiXOvsejLHh,}
   if CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.get_settings_makebookmark():
    CoIuVnBpmkQgFRMTWYAJiXOvsejLHf={'videoid':CoIuVnBpmkQgFRMTWYAJiXOvsejLUl,'vidtype':'movie' if CoIuVnBpmkQgFRMTWYAJiXOvsejLSE=='MOVIES' else 'tvshow','vtitle':CoIuVnBpmkQgFRMTWYAJiXOvsejLSH,'vsubtitle':'',}
    CoIuVnBpmkQgFRMTWYAJiXOvsejLHb=json.dumps(CoIuVnBpmkQgFRMTWYAJiXOvsejLHf)
    CoIuVnBpmkQgFRMTWYAJiXOvsejLHb=urllib.parse.quote(CoIuVnBpmkQgFRMTWYAJiXOvsejLHb)
    CoIuVnBpmkQgFRMTWYAJiXOvsejLHD='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(CoIuVnBpmkQgFRMTWYAJiXOvsejLHb)
    CoIuVnBpmkQgFRMTWYAJiXOvsejLHN=[('(통합) 찜 영상에 추가',CoIuVnBpmkQgFRMTWYAJiXOvsejLHD)]
   else:
    CoIuVnBpmkQgFRMTWYAJiXOvsejLHN=CoIuVnBpmkQgFRMTWYAJiXOvsejLUG
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.add_dir(CoIuVnBpmkQgFRMTWYAJiXOvsejLSH,sublabel=CoIuVnBpmkQgFRMTWYAJiXOvsejLHK,img=CoIuVnBpmkQgFRMTWYAJiXOvsejLHd,infoLabels=CoIuVnBpmkQgFRMTWYAJiXOvsejLHx,isFolder=CoIuVnBpmkQgFRMTWYAJiXOvsejLSP,params=CoIuVnBpmkQgFRMTWYAJiXOvsejLSd,ContextMenu=CoIuVnBpmkQgFRMTWYAJiXOvsejLHN)
  if CoIuVnBpmkQgFRMTWYAJiXOvsejLHU:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSd['mode'] ='CATEGORY_LIST' 
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSd['collectionId']=CoIuVnBpmkQgFRMTWYAJiXOvsejLHy 
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSd['vType'] =CoIuVnBpmkQgFRMTWYAJiXOvsejLSE 
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSd['page'] =CoIuVnBpmkQgFRMTWYAJiXOvsejLUq(CoIuVnBpmkQgFRMTWYAJiXOvsejLHz+1)
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSH='[B]%s >>[/B]'%'다음 페이지'
   CoIuVnBpmkQgFRMTWYAJiXOvsejLHE=CoIuVnBpmkQgFRMTWYAJiXOvsejLUq(CoIuVnBpmkQgFRMTWYAJiXOvsejLHz+1)
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.add_dir(CoIuVnBpmkQgFRMTWYAJiXOvsejLSH,sublabel=CoIuVnBpmkQgFRMTWYAJiXOvsejLHE,img=CoIuVnBpmkQgFRMTWYAJiXOvsejLSU,infoLabels=CoIuVnBpmkQgFRMTWYAJiXOvsejLUG,isFolder=CoIuVnBpmkQgFRMTWYAJiXOvsejLUf,params=CoIuVnBpmkQgFRMTWYAJiXOvsejLSd)
  if CoIuVnBpmkQgFRMTWYAJiXOvsejLSE=='TVSHOWS':xbmcplugin.setContent(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU._addon_handle,'tvshows')
  else:xbmcplugin.setContent(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU._addon_handle,'movies')
  xbmcplugin.endOfDirectory(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU._addon_handle,cacheToDisc=CoIuVnBpmkQgFRMTWYAJiXOvsejLUw)
 def dp_Season_List(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU,args):
  CoIuVnBpmkQgFRMTWYAJiXOvsejLHt =args.get('title')
  CoIuVnBpmkQgFRMTWYAJiXOvsejLHq =args.get('id')
  CoIuVnBpmkQgFRMTWYAJiXOvsejLHa =args.get('asis')
  CoIuVnBpmkQgFRMTWYAJiXOvsejLHc =args.get('seasonList')
  CoIuVnBpmkQgFRMTWYAJiXOvsejLHd =args.get('thumbnail')
  CoIuVnBpmkQgFRMTWYAJiXOvsejLHh =args.get('year')
  if CoIuVnBpmkQgFRMTWYAJiXOvsejLHc in['',CoIuVnBpmkQgFRMTWYAJiXOvsejLUG]:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLHc=CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.CoupangObj.Get_vInfo(CoIuVnBpmkQgFRMTWYAJiXOvsejLHq).get('seasonList')
  if CoIuVnBpmkQgFRMTWYAJiXOvsejLdx(CoIuVnBpmkQgFRMTWYAJiXOvsejLHc.split(','))>1:
   for CoIuVnBpmkQgFRMTWYAJiXOvsejLHl in CoIuVnBpmkQgFRMTWYAJiXOvsejLHc.split(','):
    CoIuVnBpmkQgFRMTWYAJiXOvsejLSH='시즌 '+CoIuVnBpmkQgFRMTWYAJiXOvsejLHl
    CoIuVnBpmkQgFRMTWYAJiXOvsejLHx={'mediatype':'tvshow','plot':'%s (%s)'%(CoIuVnBpmkQgFRMTWYAJiXOvsejLHt,CoIuVnBpmkQgFRMTWYAJiXOvsejLHh),}
    CoIuVnBpmkQgFRMTWYAJiXOvsejLSd={'mode':'EPISODE_LIST','programid':CoIuVnBpmkQgFRMTWYAJiXOvsejLHq,'programnm':CoIuVnBpmkQgFRMTWYAJiXOvsejLHt,'season':CoIuVnBpmkQgFRMTWYAJiXOvsejLHl,'asis':CoIuVnBpmkQgFRMTWYAJiXOvsejLHa,'programimg':CoIuVnBpmkQgFRMTWYAJiXOvsejLHd,}
    CoIuVnBpmkQgFRMTWYAJiXOvsejLyx=CoIuVnBpmkQgFRMTWYAJiXOvsejLHd.replace('\'','\"')
    CoIuVnBpmkQgFRMTWYAJiXOvsejLyx=json.loads(CoIuVnBpmkQgFRMTWYAJiXOvsejLyx)
    CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.add_dir(CoIuVnBpmkQgFRMTWYAJiXOvsejLSH,sublabel='',img=CoIuVnBpmkQgFRMTWYAJiXOvsejLyx,infoLabels=CoIuVnBpmkQgFRMTWYAJiXOvsejLHx,isFolder=CoIuVnBpmkQgFRMTWYAJiXOvsejLUf,params=CoIuVnBpmkQgFRMTWYAJiXOvsejLSd)
   xbmcplugin.setContent(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU._addon_handle,cacheToDisc=CoIuVnBpmkQgFRMTWYAJiXOvsejLUw)
  else:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLyS={'programid':CoIuVnBpmkQgFRMTWYAJiXOvsejLHq,'programnm':CoIuVnBpmkQgFRMTWYAJiXOvsejLHt,'season':CoIuVnBpmkQgFRMTWYAJiXOvsejLHc,'programimg':CoIuVnBpmkQgFRMTWYAJiXOvsejLHd,}
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.dp_Episode_List(CoIuVnBpmkQgFRMTWYAJiXOvsejLyS)
 def dp_Episode_List(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU,args):
  CoIuVnBpmkQgFRMTWYAJiXOvsejLHq =args.get('programid')
  CoIuVnBpmkQgFRMTWYAJiXOvsejLHt =args.get('programnm')
  CoIuVnBpmkQgFRMTWYAJiXOvsejLyH =args.get('season')
  CoIuVnBpmkQgFRMTWYAJiXOvsejLyz =args.get('programimg')
  CoIuVnBpmkQgFRMTWYAJiXOvsejLyU=CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.CoupangObj.Get_Episode_List(CoIuVnBpmkQgFRMTWYAJiXOvsejLHq,CoIuVnBpmkQgFRMTWYAJiXOvsejLyH)
  for CoIuVnBpmkQgFRMTWYAJiXOvsejLHl in CoIuVnBpmkQgFRMTWYAJiXOvsejLyU:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLyd =CoIuVnBpmkQgFRMTWYAJiXOvsejLHl.get('title')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLyP =CoIuVnBpmkQgFRMTWYAJiXOvsejLHl.get('id')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLHa =CoIuVnBpmkQgFRMTWYAJiXOvsejLHl.get('asis')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLHd =CoIuVnBpmkQgFRMTWYAJiXOvsejLHl.get('thumbnail')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLHP =CoIuVnBpmkQgFRMTWYAJiXOvsejLHl.get('mpaa')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLHr =CoIuVnBpmkQgFRMTWYAJiXOvsejLHl.get('duration')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLHh =CoIuVnBpmkQgFRMTWYAJiXOvsejLHl.get('year')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLyr =CoIuVnBpmkQgFRMTWYAJiXOvsejLHl.get('episode')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLHG =CoIuVnBpmkQgFRMTWYAJiXOvsejLHl.get('genreList')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLya =CoIuVnBpmkQgFRMTWYAJiXOvsejLHl.get('desc')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLyK ='%sx%s'%(CoIuVnBpmkQgFRMTWYAJiXOvsejLyH,CoIuVnBpmkQgFRMTWYAJiXOvsejLyr)
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSH ='%s. %s'%(CoIuVnBpmkQgFRMTWYAJiXOvsejLyK,CoIuVnBpmkQgFRMTWYAJiXOvsejLyd)
   CoIuVnBpmkQgFRMTWYAJiXOvsejLHx={'mediatype':'tvshow','mpaa':CoIuVnBpmkQgFRMTWYAJiXOvsejLHP,'genre':CoIuVnBpmkQgFRMTWYAJiXOvsejLHG,'duration':CoIuVnBpmkQgFRMTWYAJiXOvsejLHr,'year':CoIuVnBpmkQgFRMTWYAJiXOvsejLHh,'plot':'%s (%s)\n\n%s'%(CoIuVnBpmkQgFRMTWYAJiXOvsejLHt,CoIuVnBpmkQgFRMTWYAJiXOvsejLyK,CoIuVnBpmkQgFRMTWYAJiXOvsejLya),}
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSd={'mode':'VOD','programid':CoIuVnBpmkQgFRMTWYAJiXOvsejLHq,'programnm':CoIuVnBpmkQgFRMTWYAJiXOvsejLHt,'title':CoIuVnBpmkQgFRMTWYAJiXOvsejLSH,'season':CoIuVnBpmkQgFRMTWYAJiXOvsejLyH,'id':CoIuVnBpmkQgFRMTWYAJiXOvsejLyP,'asis':CoIuVnBpmkQgFRMTWYAJiXOvsejLHa,'thumbnail':CoIuVnBpmkQgFRMTWYAJiXOvsejLHd,'programimg':CoIuVnBpmkQgFRMTWYAJiXOvsejLyz,}
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.add_dir(CoIuVnBpmkQgFRMTWYAJiXOvsejLSH,sublabel='',img=CoIuVnBpmkQgFRMTWYAJiXOvsejLHd,infoLabels=CoIuVnBpmkQgFRMTWYAJiXOvsejLHx,isFolder=CoIuVnBpmkQgFRMTWYAJiXOvsejLUw,params=CoIuVnBpmkQgFRMTWYAJiXOvsejLSd)
  xbmcplugin.setContent(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU._addon_handle,cacheToDisc=CoIuVnBpmkQgFRMTWYAJiXOvsejLUw)
 def play_VIDEO(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU,args):
  CoIuVnBpmkQgFRMTWYAJiXOvsejLyh =args.get('id')
  CoIuVnBpmkQgFRMTWYAJiXOvsejLHa =args.get('asis')
  CoIuVnBpmkQgFRMTWYAJiXOvsejLyc,CoIuVnBpmkQgFRMTWYAJiXOvsejLyG=CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.CoupangObj.GetBroadURL(CoIuVnBpmkQgFRMTWYAJiXOvsejLyh)
  CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.addon_log('asis, url : %s - %s'%(CoIuVnBpmkQgFRMTWYAJiXOvsejLHa,CoIuVnBpmkQgFRMTWYAJiXOvsejLyc))
  if CoIuVnBpmkQgFRMTWYAJiXOvsejLyc=='':
   if CoIuVnBpmkQgFRMTWYAJiXOvsejLyG=='':
    CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.addon_noti(__language__(30907).encode('utf8'))
   else:
    CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.addon_noti(CoIuVnBpmkQgFRMTWYAJiXOvsejLyG)
   return
  CoIuVnBpmkQgFRMTWYAJiXOvsejLyw='PCID=%s;token=%s;member_srl=%s;NEXT_LOCALE=%s;bm_mi=%s;ak_bmsc=%s;bm_sv=%s'%(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.CoupangObj.CP['SESSION']['PCID'],CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.CoupangObj.CP['SESSION']['token'],CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.CoupangObj.CP['SESSION']['member_srl'],CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.CoupangObj.CP['SESSION']['NEXT_LOCALE'],CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.CoupangObj.CP['SESSION']['bm_mi'],CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.CoupangObj.CP['SESSION']['ak_bmsc'],CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.CoupangObj.CP['SESSION']['bm_sv'],)
  CoIuVnBpmkQgFRMTWYAJiXOvsejLyf='%s|Cookie=%s'%(CoIuVnBpmkQgFRMTWYAJiXOvsejLyc,CoIuVnBpmkQgFRMTWYAJiXOvsejLyw)
  CoIuVnBpmkQgFRMTWYAJiXOvsejLyb=xbmcgui.ListItem(path=CoIuVnBpmkQgFRMTWYAJiXOvsejLyf)
  CoIuVnBpmkQgFRMTWYAJiXOvsejLyD =CoIuVnBpmkQgFRMTWYAJiXOvsejLyG 
  CoIuVnBpmkQgFRMTWYAJiXOvsejLyN ='mpd'
  CoIuVnBpmkQgFRMTWYAJiXOvsejLyE ='com.widevine.alpha'
  CoIuVnBpmkQgFRMTWYAJiXOvsejLyt =inputstreamhelper.Helper(CoIuVnBpmkQgFRMTWYAJiXOvsejLyN,drm='widevine')
  if CoIuVnBpmkQgFRMTWYAJiXOvsejLyt.check_inputstream():
   CoIuVnBpmkQgFRMTWYAJiXOvsejLyq,CoIuVnBpmkQgFRMTWYAJiXOvsejLyl,CoIuVnBpmkQgFRMTWYAJiXOvsejLzx=CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.CoupangObj.Make_authHeader()
   CoIuVnBpmkQgFRMTWYAJiXOvsejLzS={'traceparent':CoIuVnBpmkQgFRMTWYAJiXOvsejLyq,'tracestate':CoIuVnBpmkQgFRMTWYAJiXOvsejLyl,'newrelic':CoIuVnBpmkQgFRMTWYAJiXOvsejLzx,'content-type':'application/octet-stream','User-Agent':CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.CoupangObj.USER_AGENT,'Cookie':CoIuVnBpmkQgFRMTWYAJiXOvsejLyw,}
   CoIuVnBpmkQgFRMTWYAJiXOvsejLzH=CoIuVnBpmkQgFRMTWYAJiXOvsejLyD+'|'+urllib.parse.urlencode(CoIuVnBpmkQgFRMTWYAJiXOvsejLzS)+'|R{SSM}|'
   CoIuVnBpmkQgFRMTWYAJiXOvsejLyb.setProperty('inputstream',CoIuVnBpmkQgFRMTWYAJiXOvsejLyt.inputstream_addon)
   CoIuVnBpmkQgFRMTWYAJiXOvsejLyb.setProperty('inputstream.adaptive.manifest_type',CoIuVnBpmkQgFRMTWYAJiXOvsejLyN)
   CoIuVnBpmkQgFRMTWYAJiXOvsejLyb.setProperty('inputstream.adaptive.license_type',CoIuVnBpmkQgFRMTWYAJiXOvsejLyE)
   CoIuVnBpmkQgFRMTWYAJiXOvsejLyb.setProperty('inputstream.adaptive.license_key',CoIuVnBpmkQgFRMTWYAJiXOvsejLzH)
   CoIuVnBpmkQgFRMTWYAJiXOvsejLyb.setMimeType('application/dash+xml')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLyb.setContentLookup(CoIuVnBpmkQgFRMTWYAJiXOvsejLUw)
  xbmcplugin.setResolvedUrl(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU._addon_handle,CoIuVnBpmkQgFRMTWYAJiXOvsejLUf,CoIuVnBpmkQgFRMTWYAJiXOvsejLyb)
  try:
   if CoIuVnBpmkQgFRMTWYAJiXOvsejLHa=='MOVIE':
    CoIuVnBpmkQgFRMTWYAJiXOvsejLzy='movie'
    CoIuVnBpmkQgFRMTWYAJiXOvsejLSd={'code':CoIuVnBpmkQgFRMTWYAJiXOvsejLyh,'asis':CoIuVnBpmkQgFRMTWYAJiXOvsejLHa,'title':args.get('title'),'img':args.get('thumbnail'),}
   else:
    CoIuVnBpmkQgFRMTWYAJiXOvsejLzy='tvshow'
    CoIuVnBpmkQgFRMTWYAJiXOvsejLSd={'code':args.get('programid'),'asis':CoIuVnBpmkQgFRMTWYAJiXOvsejLHa,'title':'%s <%s>'%(args.get('title'),args.get('programnm')),'img':args.get('programimg'),}
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.Save_Watched_List(CoIuVnBpmkQgFRMTWYAJiXOvsejLzy,CoIuVnBpmkQgFRMTWYAJiXOvsejLSd)
  except:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLUG
 def dp_Global_Search(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU,args):
  CoIuVnBpmkQgFRMTWYAJiXOvsejLHw=args.get('mode')
  if CoIuVnBpmkQgFRMTWYAJiXOvsejLHw=='TOTAL_SEARCH':
   CoIuVnBpmkQgFRMTWYAJiXOvsejLzU='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLzU='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(CoIuVnBpmkQgFRMTWYAJiXOvsejLzU)
 def dp_Bookmark_Menu(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU,args):
  CoIuVnBpmkQgFRMTWYAJiXOvsejLzU='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(CoIuVnBpmkQgFRMTWYAJiXOvsejLzU)
 def dp_Search_List(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU,args):
  CoIuVnBpmkQgFRMTWYAJiXOvsejLHz =CoIuVnBpmkQgFRMTWYAJiXOvsejLUN(args.get('page'))
  if 'search_key' in args:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLzd=args.get('search_key')
  else:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLzd=CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.get_keyboard_input(__language__(30908).encode('utf-8'))
   if not CoIuVnBpmkQgFRMTWYAJiXOvsejLzd:
    return
  CoIuVnBpmkQgFRMTWYAJiXOvsejLzP,CoIuVnBpmkQgFRMTWYAJiXOvsejLHU=CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.CoupangObj.Get_Search_List(CoIuVnBpmkQgFRMTWYAJiXOvsejLzd,CoIuVnBpmkQgFRMTWYAJiXOvsejLHz)
  for CoIuVnBpmkQgFRMTWYAJiXOvsejLzr in CoIuVnBpmkQgFRMTWYAJiXOvsejLzP:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLUl =CoIuVnBpmkQgFRMTWYAJiXOvsejLzr.get('id')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSH =CoIuVnBpmkQgFRMTWYAJiXOvsejLzr.get('title')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLHa =CoIuVnBpmkQgFRMTWYAJiXOvsejLzr.get('asis')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLHd =CoIuVnBpmkQgFRMTWYAJiXOvsejLzr.get('thumbnail')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLHP =CoIuVnBpmkQgFRMTWYAJiXOvsejLzr.get('mpaa')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLHh =CoIuVnBpmkQgFRMTWYAJiXOvsejLzr.get('year')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLHr =CoIuVnBpmkQgFRMTWYAJiXOvsejLzr.get('duration')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLHK =CoIuVnBpmkQgFRMTWYAJiXOvsejLzr.get('badge')
   if CoIuVnBpmkQgFRMTWYAJiXOvsejLHa=='TVSHOW': 
    CoIuVnBpmkQgFRMTWYAJiXOvsejLHw ='SEASON_LIST'
    CoIuVnBpmkQgFRMTWYAJiXOvsejLHx={'mediatype':'tvshow','title':CoIuVnBpmkQgFRMTWYAJiXOvsejLSH,'mpaa':CoIuVnBpmkQgFRMTWYAJiXOvsejLHP,'year':CoIuVnBpmkQgFRMTWYAJiXOvsejLHh,'plot':'Year : %s'%(CoIuVnBpmkQgFRMTWYAJiXOvsejLHh),}
    CoIuVnBpmkQgFRMTWYAJiXOvsejLSP =CoIuVnBpmkQgFRMTWYAJiXOvsejLUf
   else: 
    CoIuVnBpmkQgFRMTWYAJiXOvsejLHw ='MOVIE'
    CoIuVnBpmkQgFRMTWYAJiXOvsejLHx={'mediatype':'movie','title':CoIuVnBpmkQgFRMTWYAJiXOvsejLSH,'mpaa':CoIuVnBpmkQgFRMTWYAJiXOvsejLHP,'duration':CoIuVnBpmkQgFRMTWYAJiXOvsejLHr,'year':CoIuVnBpmkQgFRMTWYAJiXOvsejLHh,'plot':'(%s)'%(CoIuVnBpmkQgFRMTWYAJiXOvsejLHP),}
    CoIuVnBpmkQgFRMTWYAJiXOvsejLSP =CoIuVnBpmkQgFRMTWYAJiXOvsejLUw
    CoIuVnBpmkQgFRMTWYAJiXOvsejLSH +=' (%s)'%(CoIuVnBpmkQgFRMTWYAJiXOvsejLUq(CoIuVnBpmkQgFRMTWYAJiXOvsejLHh))
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSd={'mode':CoIuVnBpmkQgFRMTWYAJiXOvsejLHw,'id':CoIuVnBpmkQgFRMTWYAJiXOvsejLUl,'asis':CoIuVnBpmkQgFRMTWYAJiXOvsejLHa,'seasonList':'','title':CoIuVnBpmkQgFRMTWYAJiXOvsejLSH,'thumbnail':json.dumps(CoIuVnBpmkQgFRMTWYAJiXOvsejLHd,separators=(',',':')),'year':CoIuVnBpmkQgFRMTWYAJiXOvsejLHh,}
   if CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.get_settings_makebookmark():
    CoIuVnBpmkQgFRMTWYAJiXOvsejLHf={'videoid':CoIuVnBpmkQgFRMTWYAJiXOvsejLUl,'vidtype':'movie' if CoIuVnBpmkQgFRMTWYAJiXOvsejLHa=='MOVIE' else 'tvshow','vtitle':CoIuVnBpmkQgFRMTWYAJiXOvsejLSH,'vsubtitle':'',}
    CoIuVnBpmkQgFRMTWYAJiXOvsejLHb=json.dumps(CoIuVnBpmkQgFRMTWYAJiXOvsejLHf)
    CoIuVnBpmkQgFRMTWYAJiXOvsejLHb=urllib.parse.quote(CoIuVnBpmkQgFRMTWYAJiXOvsejLHb)
    CoIuVnBpmkQgFRMTWYAJiXOvsejLHD='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(CoIuVnBpmkQgFRMTWYAJiXOvsejLHb)
    CoIuVnBpmkQgFRMTWYAJiXOvsejLHN=[('(통합) 찜 영상에 추가',CoIuVnBpmkQgFRMTWYAJiXOvsejLHD)]
   else:
    CoIuVnBpmkQgFRMTWYAJiXOvsejLHN=CoIuVnBpmkQgFRMTWYAJiXOvsejLUG
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.add_dir(CoIuVnBpmkQgFRMTWYAJiXOvsejLSH,sublabel=CoIuVnBpmkQgFRMTWYAJiXOvsejLHK,img=CoIuVnBpmkQgFRMTWYAJiXOvsejLHd,infoLabels=CoIuVnBpmkQgFRMTWYAJiXOvsejLHx,isFolder=CoIuVnBpmkQgFRMTWYAJiXOvsejLSP,params=CoIuVnBpmkQgFRMTWYAJiXOvsejLSd,ContextMenu=CoIuVnBpmkQgFRMTWYAJiXOvsejLHN)
  if CoIuVnBpmkQgFRMTWYAJiXOvsejLHU:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSd={}
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSd['mode'] ='LOCAL_SEARCH'
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSd['search_key']=CoIuVnBpmkQgFRMTWYAJiXOvsejLzd
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSd['page'] =CoIuVnBpmkQgFRMTWYAJiXOvsejLUq(CoIuVnBpmkQgFRMTWYAJiXOvsejLHz+1)
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSH='[B]%s >>[/B]'%'다음 페이지'
   CoIuVnBpmkQgFRMTWYAJiXOvsejLHE=CoIuVnBpmkQgFRMTWYAJiXOvsejLUq(CoIuVnBpmkQgFRMTWYAJiXOvsejLHz+1)
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.add_dir(CoIuVnBpmkQgFRMTWYAJiXOvsejLSH,sublabel=CoIuVnBpmkQgFRMTWYAJiXOvsejLHE,img=CoIuVnBpmkQgFRMTWYAJiXOvsejLSU,infoLabels=CoIuVnBpmkQgFRMTWYAJiXOvsejLUG,isFolder=CoIuVnBpmkQgFRMTWYAJiXOvsejLUf,params=CoIuVnBpmkQgFRMTWYAJiXOvsejLSd)
  xbmcplugin.setContent(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU._addon_handle,'movies')
  xbmcplugin.endOfDirectory(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU._addon_handle,cacheToDisc=CoIuVnBpmkQgFRMTWYAJiXOvsejLUf)
  if args.get('historyyn')=='Y':CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.Save_Searched_List(CoIuVnBpmkQgFRMTWYAJiXOvsejLzd)
 def Load_List_File(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU,CoIuVnBpmkQgFRMTWYAJiXOvsejLzy): 
  try:
   if CoIuVnBpmkQgFRMTWYAJiXOvsejLzy=='search':
    CoIuVnBpmkQgFRMTWYAJiXOvsejLza=CoIuVnBpmkQgFRMTWYAJiXOvsejLxz
   elif CoIuVnBpmkQgFRMTWYAJiXOvsejLzy in['tvshow','movie']:
    CoIuVnBpmkQgFRMTWYAJiXOvsejLza=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%CoIuVnBpmkQgFRMTWYAJiXOvsejLzy))
   else:
    return[]
   fp=CoIuVnBpmkQgFRMTWYAJiXOvsejLUE(CoIuVnBpmkQgFRMTWYAJiXOvsejLza,'r',-1,'utf-8')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLzK=fp.readlines()
   fp.close()
  except:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLzK=[]
  return CoIuVnBpmkQgFRMTWYAJiXOvsejLzK
 def Save_Watched_List(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU,CoIuVnBpmkQgFRMTWYAJiXOvsejLzy,CoIuVnBpmkQgFRMTWYAJiXOvsejLxr):
  try:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLzh=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%CoIuVnBpmkQgFRMTWYAJiXOvsejLzy))
   CoIuVnBpmkQgFRMTWYAJiXOvsejLzc=CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.Load_List_File(CoIuVnBpmkQgFRMTWYAJiXOvsejLzy) 
   fp=CoIuVnBpmkQgFRMTWYAJiXOvsejLUE(CoIuVnBpmkQgFRMTWYAJiXOvsejLzh,'w',-1,'utf-8')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLzG=urllib.parse.urlencode(CoIuVnBpmkQgFRMTWYAJiXOvsejLxr)
   CoIuVnBpmkQgFRMTWYAJiXOvsejLzG=CoIuVnBpmkQgFRMTWYAJiXOvsejLzG+'\n'
   fp.write(CoIuVnBpmkQgFRMTWYAJiXOvsejLzG)
   CoIuVnBpmkQgFRMTWYAJiXOvsejLzw=0
   for CoIuVnBpmkQgFRMTWYAJiXOvsejLzf in CoIuVnBpmkQgFRMTWYAJiXOvsejLzc:
    CoIuVnBpmkQgFRMTWYAJiXOvsejLzb=CoIuVnBpmkQgFRMTWYAJiXOvsejLUD(urllib.parse.parse_qsl(CoIuVnBpmkQgFRMTWYAJiXOvsejLzf))
    CoIuVnBpmkQgFRMTWYAJiXOvsejLzD=CoIuVnBpmkQgFRMTWYAJiXOvsejLxr.get('code').strip()
    CoIuVnBpmkQgFRMTWYAJiXOvsejLzN=CoIuVnBpmkQgFRMTWYAJiXOvsejLzb.get('code').strip()
    if CoIuVnBpmkQgFRMTWYAJiXOvsejLzD!=CoIuVnBpmkQgFRMTWYAJiXOvsejLzN:
     fp.write(CoIuVnBpmkQgFRMTWYAJiXOvsejLzf)
     CoIuVnBpmkQgFRMTWYAJiXOvsejLzw+=1
     if CoIuVnBpmkQgFRMTWYAJiXOvsejLzw>=50:break
   fp.close()
  except:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLUG
 def Save_Searched_List(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU,CoIuVnBpmkQgFRMTWYAJiXOvsejLzd):
  try:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLzd=CoIuVnBpmkQgFRMTWYAJiXOvsejLzd.strip()
   CoIuVnBpmkQgFRMTWYAJiXOvsejLzc=CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.Load_List_File('search') 
   fp=CoIuVnBpmkQgFRMTWYAJiXOvsejLUE(CoIuVnBpmkQgFRMTWYAJiXOvsejLxz,'w',-1,'utf-8')
   fp.write(CoIuVnBpmkQgFRMTWYAJiXOvsejLzd+'\n')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLzw=0
   for CoIuVnBpmkQgFRMTWYAJiXOvsejLzf in CoIuVnBpmkQgFRMTWYAJiXOvsejLzc:
    CoIuVnBpmkQgFRMTWYAJiXOvsejLzf=CoIuVnBpmkQgFRMTWYAJiXOvsejLzf.strip()
    if CoIuVnBpmkQgFRMTWYAJiXOvsejLzd!=CoIuVnBpmkQgFRMTWYAJiXOvsejLzf:
     fp.write(CoIuVnBpmkQgFRMTWYAJiXOvsejLzf+'\n')
     CoIuVnBpmkQgFRMTWYAJiXOvsejLzw+=1
     if CoIuVnBpmkQgFRMTWYAJiXOvsejLzw>=50:break
   fp.close()
  except:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLUG
 def dp_Search_History(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU,args):
  CoIuVnBpmkQgFRMTWYAJiXOvsejLzE=CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.Load_List_File('search')
  for CoIuVnBpmkQgFRMTWYAJiXOvsejLzt in CoIuVnBpmkQgFRMTWYAJiXOvsejLzE:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLzt=CoIuVnBpmkQgFRMTWYAJiXOvsejLzt.strip()
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSd={'mode':'LOCAL_SEARCH','search_key':CoIuVnBpmkQgFRMTWYAJiXOvsejLzt,'page':'1','historyyn':'Y',}
   CoIuVnBpmkQgFRMTWYAJiXOvsejLzq={'mode':'SEARCH_REMOVE','stype':'ONE','skey':CoIuVnBpmkQgFRMTWYAJiXOvsejLzt,}
   CoIuVnBpmkQgFRMTWYAJiXOvsejLzl=urllib.parse.urlencode(CoIuVnBpmkQgFRMTWYAJiXOvsejLzq)
   CoIuVnBpmkQgFRMTWYAJiXOvsejLHN=[('선택된 검색어 ( %s ) 삭제'%(CoIuVnBpmkQgFRMTWYAJiXOvsejLzt),'RunPlugin(plugin://plugin.video.coupangm/?%s)'%(CoIuVnBpmkQgFRMTWYAJiXOvsejLzl))]
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.add_dir(CoIuVnBpmkQgFRMTWYAJiXOvsejLzt,sublabel='',img=CoIuVnBpmkQgFRMTWYAJiXOvsejLUG,infoLabels=CoIuVnBpmkQgFRMTWYAJiXOvsejLUG,isFolder=CoIuVnBpmkQgFRMTWYAJiXOvsejLUf,params=CoIuVnBpmkQgFRMTWYAJiXOvsejLSd,ContextMenu=CoIuVnBpmkQgFRMTWYAJiXOvsejLHN)
  CoIuVnBpmkQgFRMTWYAJiXOvsejLHx={'plot':'검색목록 전체를 삭제합니다.'}
  CoIuVnBpmkQgFRMTWYAJiXOvsejLSH='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  CoIuVnBpmkQgFRMTWYAJiXOvsejLSd={'mode':'SEARCH_REMOVE','stype':'ALL','skey':'-',}
  CoIuVnBpmkQgFRMTWYAJiXOvsejLSU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.add_dir(CoIuVnBpmkQgFRMTWYAJiXOvsejLSH,sublabel='',img=CoIuVnBpmkQgFRMTWYAJiXOvsejLSU,infoLabels=CoIuVnBpmkQgFRMTWYAJiXOvsejLHx,isFolder=CoIuVnBpmkQgFRMTWYAJiXOvsejLUw,params=CoIuVnBpmkQgFRMTWYAJiXOvsejLSd,isLink=CoIuVnBpmkQgFRMTWYAJiXOvsejLUf)
  xbmcplugin.endOfDirectory(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU._addon_handle,cacheToDisc=CoIuVnBpmkQgFRMTWYAJiXOvsejLUw)
 def dp_Listfile_Delete(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU,args):
  CoIuVnBpmkQgFRMTWYAJiXOvsejLzy=args.get('stype')
  CoIuVnBpmkQgFRMTWYAJiXOvsejLUx =args.get('skey')
  CoIuVnBpmkQgFRMTWYAJiXOvsejLxK=xbmcgui.Dialog()
  if CoIuVnBpmkQgFRMTWYAJiXOvsejLzy=='ALL':
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSK=CoIuVnBpmkQgFRMTWYAJiXOvsejLxK.yesno(__language__(30911).encode('utf8'),__language__(30906).encode('utf8'))
  elif CoIuVnBpmkQgFRMTWYAJiXOvsejLzy=='ONE':
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSK=CoIuVnBpmkQgFRMTWYAJiXOvsejLxK.yesno(__language__(30912).encode('utf8'),__language__(30906).encode('utf8'))
  elif CoIuVnBpmkQgFRMTWYAJiXOvsejLzy in['tvshow','movie']:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSK=CoIuVnBpmkQgFRMTWYAJiXOvsejLxK.yesno(__language__(30913).encode('utf8'),__language__(30906).encode('utf8'))
  if CoIuVnBpmkQgFRMTWYAJiXOvsejLSK==CoIuVnBpmkQgFRMTWYAJiXOvsejLUw:sys.exit()
  CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.Delete_List_File(CoIuVnBpmkQgFRMTWYAJiXOvsejLzy,skey=CoIuVnBpmkQgFRMTWYAJiXOvsejLUx)
  xbmc.executebuiltin("Container.Refresh")
 def Delete_List_File(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU,CoIuVnBpmkQgFRMTWYAJiXOvsejLzy,skey='-'):
  if CoIuVnBpmkQgFRMTWYAJiXOvsejLzy=='ALL':
   try:
    CoIuVnBpmkQgFRMTWYAJiXOvsejLza=CoIuVnBpmkQgFRMTWYAJiXOvsejLxz
    fp=CoIuVnBpmkQgFRMTWYAJiXOvsejLUE(CoIuVnBpmkQgFRMTWYAJiXOvsejLza,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    CoIuVnBpmkQgFRMTWYAJiXOvsejLUG
  elif CoIuVnBpmkQgFRMTWYAJiXOvsejLzy=='ONE':
   try:
    CoIuVnBpmkQgFRMTWYAJiXOvsejLza=CoIuVnBpmkQgFRMTWYAJiXOvsejLxz
    CoIuVnBpmkQgFRMTWYAJiXOvsejLzc=CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.Load_List_File('search') 
    fp=CoIuVnBpmkQgFRMTWYAJiXOvsejLUE(CoIuVnBpmkQgFRMTWYAJiXOvsejLza,'w',-1,'utf-8')
    for CoIuVnBpmkQgFRMTWYAJiXOvsejLzf in CoIuVnBpmkQgFRMTWYAJiXOvsejLzc:
     if skey!=CoIuVnBpmkQgFRMTWYAJiXOvsejLzf.strip():
      fp.write(CoIuVnBpmkQgFRMTWYAJiXOvsejLzf)
    fp.close()
   except:
    CoIuVnBpmkQgFRMTWYAJiXOvsejLUG
  elif CoIuVnBpmkQgFRMTWYAJiXOvsejLzy in['tvshow','movie']:
   try:
    CoIuVnBpmkQgFRMTWYAJiXOvsejLza=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%CoIuVnBpmkQgFRMTWYAJiXOvsejLzy))
    fp=CoIuVnBpmkQgFRMTWYAJiXOvsejLUE(CoIuVnBpmkQgFRMTWYAJiXOvsejLza,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    CoIuVnBpmkQgFRMTWYAJiXOvsejLUG
 def dp_Watch_List(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU,args):
  CoIuVnBpmkQgFRMTWYAJiXOvsejLzy =args.get('stype')
  if CoIuVnBpmkQgFRMTWYAJiXOvsejLzy in['',CoIuVnBpmkQgFRMTWYAJiXOvsejLUG]:
   for CoIuVnBpmkQgFRMTWYAJiXOvsejLUS in CoIuVnBpmkQgFRMTWYAJiXOvsejLxy:
    CoIuVnBpmkQgFRMTWYAJiXOvsejLSH=CoIuVnBpmkQgFRMTWYAJiXOvsejLUS.get('title')
    CoIuVnBpmkQgFRMTWYAJiXOvsejLSd={'mode':CoIuVnBpmkQgFRMTWYAJiXOvsejLUS.get('mode'),'stype':CoIuVnBpmkQgFRMTWYAJiXOvsejLUS.get('stype'),}
    CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.add_dir(CoIuVnBpmkQgFRMTWYAJiXOvsejLSH,sublabel='',img='',infoLabels=CoIuVnBpmkQgFRMTWYAJiXOvsejLUG,isFolder=CoIuVnBpmkQgFRMTWYAJiXOvsejLUf,params=CoIuVnBpmkQgFRMTWYAJiXOvsejLSd)
   xbmcplugin.endOfDirectory(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU._addon_handle)
  else:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLUH=CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.Load_List_File(CoIuVnBpmkQgFRMTWYAJiXOvsejLzy)
   for CoIuVnBpmkQgFRMTWYAJiXOvsejLUy in CoIuVnBpmkQgFRMTWYAJiXOvsejLUH:
    CoIuVnBpmkQgFRMTWYAJiXOvsejLUz=CoIuVnBpmkQgFRMTWYAJiXOvsejLUD(urllib.parse.parse_qsl(CoIuVnBpmkQgFRMTWYAJiXOvsejLUy))
    CoIuVnBpmkQgFRMTWYAJiXOvsejLyh =CoIuVnBpmkQgFRMTWYAJiXOvsejLUz.get('code').strip()
    CoIuVnBpmkQgFRMTWYAJiXOvsejLSH =CoIuVnBpmkQgFRMTWYAJiXOvsejLUz.get('title').strip()
    CoIuVnBpmkQgFRMTWYAJiXOvsejLHd =CoIuVnBpmkQgFRMTWYAJiXOvsejLUz.get('img').strip()
    CoIuVnBpmkQgFRMTWYAJiXOvsejLHa =CoIuVnBpmkQgFRMTWYAJiXOvsejLUz.get('asis').strip()
    try:
     CoIuVnBpmkQgFRMTWYAJiXOvsejLHd=CoIuVnBpmkQgFRMTWYAJiXOvsejLHd.replace('\'','\"')
     CoIuVnBpmkQgFRMTWYAJiXOvsejLHd=json.loads(CoIuVnBpmkQgFRMTWYAJiXOvsejLHd)
    except:
     CoIuVnBpmkQgFRMTWYAJiXOvsejLUG
    CoIuVnBpmkQgFRMTWYAJiXOvsejLHx={}
    CoIuVnBpmkQgFRMTWYAJiXOvsejLHx['plot']=CoIuVnBpmkQgFRMTWYAJiXOvsejLSH
    if CoIuVnBpmkQgFRMTWYAJiXOvsejLzy=='movie':
     CoIuVnBpmkQgFRMTWYAJiXOvsejLSd={'mode':'MOVIE','id':CoIuVnBpmkQgFRMTWYAJiXOvsejLyh,'asis':CoIuVnBpmkQgFRMTWYAJiXOvsejLHa,'title':CoIuVnBpmkQgFRMTWYAJiXOvsejLSH,'thumbnail':CoIuVnBpmkQgFRMTWYAJiXOvsejLHd,}
     CoIuVnBpmkQgFRMTWYAJiXOvsejLSP=CoIuVnBpmkQgFRMTWYAJiXOvsejLUw
    else:
     CoIuVnBpmkQgFRMTWYAJiXOvsejLSd={'mode':'SEASON_LIST','id':CoIuVnBpmkQgFRMTWYAJiXOvsejLyh,'asis':CoIuVnBpmkQgFRMTWYAJiXOvsejLHa,'title':CoIuVnBpmkQgFRMTWYAJiXOvsejLSH,'thumbnail':json.dumps(CoIuVnBpmkQgFRMTWYAJiXOvsejLHd,separators=(',',':')),}
     CoIuVnBpmkQgFRMTWYAJiXOvsejLSP=CoIuVnBpmkQgFRMTWYAJiXOvsejLUf
    CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.add_dir(CoIuVnBpmkQgFRMTWYAJiXOvsejLSH,sublabel='',img=CoIuVnBpmkQgFRMTWYAJiXOvsejLHd,infoLabels=CoIuVnBpmkQgFRMTWYAJiXOvsejLHx,isFolder=CoIuVnBpmkQgFRMTWYAJiXOvsejLSP,params=CoIuVnBpmkQgFRMTWYAJiXOvsejLSd)
   CoIuVnBpmkQgFRMTWYAJiXOvsejLHx={'plot':'시청목록을 삭제합니다.'}
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSH='*** 시청목록 삭제 ***'
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSd={'mode':'MYVIEW_REMOVE','stype':CoIuVnBpmkQgFRMTWYAJiXOvsejLzy,'skey':'-',}
   CoIuVnBpmkQgFRMTWYAJiXOvsejLSU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.add_dir(CoIuVnBpmkQgFRMTWYAJiXOvsejLSH,sublabel='',img=CoIuVnBpmkQgFRMTWYAJiXOvsejLSU,infoLabels=CoIuVnBpmkQgFRMTWYAJiXOvsejLHx,isFolder=CoIuVnBpmkQgFRMTWYAJiXOvsejLUw,params=CoIuVnBpmkQgFRMTWYAJiXOvsejLSd,isLink=CoIuVnBpmkQgFRMTWYAJiXOvsejLUf)
   if CoIuVnBpmkQgFRMTWYAJiXOvsejLzy=='movie':xbmcplugin.setContent(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU._addon_handle,'movies')
   else:xbmcplugin.setContent(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU._addon_handle,cacheToDisc=CoIuVnBpmkQgFRMTWYAJiXOvsejLUw)
 def dp_Set_Bookmark(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU,args):
  CoIuVnBpmkQgFRMTWYAJiXOvsejLUd=urllib.parse.unquote(args.get('bm_param'))
  CoIuVnBpmkQgFRMTWYAJiXOvsejLUd=json.loads(CoIuVnBpmkQgFRMTWYAJiXOvsejLUd)
  CoIuVnBpmkQgFRMTWYAJiXOvsejLUP =CoIuVnBpmkQgFRMTWYAJiXOvsejLUd.get('videoid')
  CoIuVnBpmkQgFRMTWYAJiXOvsejLUr =CoIuVnBpmkQgFRMTWYAJiXOvsejLUd.get('vidtype')
  CoIuVnBpmkQgFRMTWYAJiXOvsejLUa =CoIuVnBpmkQgFRMTWYAJiXOvsejLUd.get('vtitle')
  CoIuVnBpmkQgFRMTWYAJiXOvsejLxK=xbmcgui.Dialog()
  CoIuVnBpmkQgFRMTWYAJiXOvsejLSK=CoIuVnBpmkQgFRMTWYAJiXOvsejLxK.yesno(__language__(30914).encode('utf8'),CoIuVnBpmkQgFRMTWYAJiXOvsejLUa+' \n\n'+__language__(30915))
  if CoIuVnBpmkQgFRMTWYAJiXOvsejLSK==CoIuVnBpmkQgFRMTWYAJiXOvsejLUw:return
  CoIuVnBpmkQgFRMTWYAJiXOvsejLUK=CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.CoupangObj.GetBookmarkInfo(CoIuVnBpmkQgFRMTWYAJiXOvsejLUP,CoIuVnBpmkQgFRMTWYAJiXOvsejLUr)
  CoIuVnBpmkQgFRMTWYAJiXOvsejLUh=json.dumps(CoIuVnBpmkQgFRMTWYAJiXOvsejLUK)
  CoIuVnBpmkQgFRMTWYAJiXOvsejLUh=urllib.parse.quote(CoIuVnBpmkQgFRMTWYAJiXOvsejLUh)
  CoIuVnBpmkQgFRMTWYAJiXOvsejLHD ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(CoIuVnBpmkQgFRMTWYAJiXOvsejLUh)
  xbmc.executebuiltin(CoIuVnBpmkQgFRMTWYAJiXOvsejLHD)
 def coupang_main(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU):
  CoIuVnBpmkQgFRMTWYAJiXOvsejLHw=CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.main_params.get('mode',CoIuVnBpmkQgFRMTWYAJiXOvsejLUG)
  if CoIuVnBpmkQgFRMTWYAJiXOvsejLHw=='LOGOUT':
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.CP_logout()
   return
  CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.option_check()
  if CoIuVnBpmkQgFRMTWYAJiXOvsejLHw is CoIuVnBpmkQgFRMTWYAJiXOvsejLUG:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.dp_Main_List(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.main_params)
  elif CoIuVnBpmkQgFRMTWYAJiXOvsejLHw=='CATEGORY_GROUPLIST':
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.dp_Category_GroupList(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.main_params)
  elif CoIuVnBpmkQgFRMTWYAJiXOvsejLHw=='THEME_GROUPLIST':
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.dp_Theme_GroupList(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.main_params)
  elif CoIuVnBpmkQgFRMTWYAJiXOvsejLHw=='CATEGORY_LIST':
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.dp_Category_List(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.main_params)
  elif CoIuVnBpmkQgFRMTWYAJiXOvsejLHw=='SEASON_LIST':
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.dp_Season_List(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.main_params)
  elif CoIuVnBpmkQgFRMTWYAJiXOvsejLHw=='EPISODE_LIST':
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.dp_Episode_List(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.main_params)
  elif CoIuVnBpmkQgFRMTWYAJiXOvsejLHw=='TEST':
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.dp_Test(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.main_params)
  elif CoIuVnBpmkQgFRMTWYAJiXOvsejLHw in['MOVIE','VOD']:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.play_VIDEO(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.main_params)
  elif CoIuVnBpmkQgFRMTWYAJiXOvsejLHw=='WATCH':
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.dp_Watch_List(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.main_params)
  elif CoIuVnBpmkQgFRMTWYAJiXOvsejLHw=='LOCAL_SEARCH':
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.dp_Search_List(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.main_params)
  elif CoIuVnBpmkQgFRMTWYAJiXOvsejLHw=='SEARCH_HISTORY':
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.dp_Search_History(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.main_params)
  elif CoIuVnBpmkQgFRMTWYAJiXOvsejLHw in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.dp_Listfile_Delete(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.main_params)
  elif CoIuVnBpmkQgFRMTWYAJiXOvsejLHw in['TOTAL_SEARCH','TOTAL_HISTORY']:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.dp_Global_Search(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.main_params)
  elif CoIuVnBpmkQgFRMTWYAJiXOvsejLHw=='MENU_BOOKMARK':
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.dp_Bookmark_Menu(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.main_params)
  elif CoIuVnBpmkQgFRMTWYAJiXOvsejLHw=='SET_BOOKMARK':
   CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.dp_Set_Bookmark(CoIuVnBpmkQgFRMTWYAJiXOvsejLxU.main_params)
  else:
   CoIuVnBpmkQgFRMTWYAJiXOvsejLUG
# Created by pyminifier (https://github.com/liftoff/pyminifier)
