__author__="NightRain"
ehgRpUTwClNXmqQEPHfMbvcYBdnWsF=object
ehgRpUTwClNXmqQEPHfMbvcYBdnWay=None
ehgRpUTwClNXmqQEPHfMbvcYBdnWaK=False
ehgRpUTwClNXmqQEPHfMbvcYBdnWas=print
ehgRpUTwClNXmqQEPHfMbvcYBdnWaJ=str
ehgRpUTwClNXmqQEPHfMbvcYBdnWaL=open
ehgRpUTwClNXmqQEPHfMbvcYBdnWaz=int
ehgRpUTwClNXmqQEPHfMbvcYBdnWar=Exception
ehgRpUTwClNXmqQEPHfMbvcYBdnWaO=id
ehgRpUTwClNXmqQEPHfMbvcYBdnWax=True
ehgRpUTwClNXmqQEPHfMbvcYBdnWaA=range
ehgRpUTwClNXmqQEPHfMbvcYBdnWai=len
import urllib
import re
import json
import requests
import datetime
import time
import random
import base64
class ehgRpUTwClNXmqQEPHfMbvcYBdnWyK(ehgRpUTwClNXmqQEPHfMbvcYBdnWsF):
 def __init__(ehgRpUTwClNXmqQEPHfMbvcYBdnWys):
  ehgRpUTwClNXmqQEPHfMbvcYBdnWys.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36'
  ehgRpUTwClNXmqQEPHfMbvcYBdnWys.MODEL ='Chrome_92' 
  ehgRpUTwClNXmqQEPHfMbvcYBdnWys.DEFAULT_HEADER ={'user-agent':ehgRpUTwClNXmqQEPHfMbvcYBdnWys.USER_AGENT}
  ehgRpUTwClNXmqQEPHfMbvcYBdnWys.API_DOMAIN ='https://www.coupangplay.com'
  ehgRpUTwClNXmqQEPHfMbvcYBdnWys.API_VIEWURL ='https://discover.coupangstreaming.com'
  ehgRpUTwClNXmqQEPHfMbvcYBdnWys.PAGE_LIMIT =40
  ehgRpUTwClNXmqQEPHfMbvcYBdnWys.SEARCH_LIMIT =20
  ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP={}
  ehgRpUTwClNXmqQEPHfMbvcYBdnWys.Init_CP()
  ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP_DEVICE_FILENAME=''
  ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP_COOKIE_FILENAME=''
 def callRequestCookies(ehgRpUTwClNXmqQEPHfMbvcYBdnWys,jobtype,ehgRpUTwClNXmqQEPHfMbvcYBdnWKy,payload=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,params=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,headers=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,cookies=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,redirects=ehgRpUTwClNXmqQEPHfMbvcYBdnWaK):
  ehgRpUTwClNXmqQEPHfMbvcYBdnWya=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.DEFAULT_HEADER
  if headers:ehgRpUTwClNXmqQEPHfMbvcYBdnWya.update(headers)
  if jobtype=='Get':
   ehgRpUTwClNXmqQEPHfMbvcYBdnWyJ=requests.get(ehgRpUTwClNXmqQEPHfMbvcYBdnWKy,params=params,headers=ehgRpUTwClNXmqQEPHfMbvcYBdnWya,cookies=cookies,allow_redirects=redirects)
  else:
   ehgRpUTwClNXmqQEPHfMbvcYBdnWyJ=requests.post(ehgRpUTwClNXmqQEPHfMbvcYBdnWKy,data=payload,params=params,headers=ehgRpUTwClNXmqQEPHfMbvcYBdnWya,cookies=cookies,allow_redirects=redirects)
  ehgRpUTwClNXmqQEPHfMbvcYBdnWas(ehgRpUTwClNXmqQEPHfMbvcYBdnWaJ(ehgRpUTwClNXmqQEPHfMbvcYBdnWyJ.status_code)+' - '+ehgRpUTwClNXmqQEPHfMbvcYBdnWaJ(ehgRpUTwClNXmqQEPHfMbvcYBdnWyJ.url))
  return ehgRpUTwClNXmqQEPHfMbvcYBdnWyJ
 def callRequestCookies_test(ehgRpUTwClNXmqQEPHfMbvcYBdnWys,jobtype,ehgRpUTwClNXmqQEPHfMbvcYBdnWKy,payload=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,params=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,headers=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,cookies=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,redirects=ehgRpUTwClNXmqQEPHfMbvcYBdnWaK):
  ehgRpUTwClNXmqQEPHfMbvcYBdnWya=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.DEFAULT_HEADER
  if headers:ehgRpUTwClNXmqQEPHfMbvcYBdnWya.update(headers)
  ehgRpUTwClNXmqQEPHfMbvcYBdnWyJ=requests.Request('POST',ehgRpUTwClNXmqQEPHfMbvcYBdnWKy,headers=headers,data=payload,params=params,cookies=cookies)
  ehgRpUTwClNXmqQEPHfMbvcYBdnWyL=ehgRpUTwClNXmqQEPHfMbvcYBdnWyJ.prepare()
  ehgRpUTwClNXmqQEPHfMbvcYBdnWys.pretty_print_POST(ehgRpUTwClNXmqQEPHfMbvcYBdnWyL)
  return ehgRpUTwClNXmqQEPHfMbvcYBdnWyJ
 def pretty_print_POST(ehgRpUTwClNXmqQEPHfMbvcYBdnWys,req):
  ehgRpUTwClNXmqQEPHfMbvcYBdnWas('{}\n{}\r\n{}\r\n\r\n{}'.format('-----------START-----------',req.method+' '+req.url,'\r\n'.join('{}: {}'.format(k,v)for k,v in req.headers.items()),req.body,))
 def dic_To_jsonfile(ehgRpUTwClNXmqQEPHfMbvcYBdnWys,filename,ehgRpUTwClNXmqQEPHfMbvcYBdnWyz):
  if filename=='':return
  fp=ehgRpUTwClNXmqQEPHfMbvcYBdnWaL(filename,'w',-1,'utf-8')
  json.dump(ehgRpUTwClNXmqQEPHfMbvcYBdnWyz,fp,indent=4,ensure_ascii=ehgRpUTwClNXmqQEPHfMbvcYBdnWaK)
  fp.close()
 def jsonfile_To_dic(ehgRpUTwClNXmqQEPHfMbvcYBdnWys,filename):
  if filename=='':return ehgRpUTwClNXmqQEPHfMbvcYBdnWay
  try:
   fp=ehgRpUTwClNXmqQEPHfMbvcYBdnWaL(filename,'r',-1,'utf-8')
   ehgRpUTwClNXmqQEPHfMbvcYBdnWyO=json.load(fp)
   fp.close()
  except:
   ehgRpUTwClNXmqQEPHfMbvcYBdnWyO={}
  return ehgRpUTwClNXmqQEPHfMbvcYBdnWyO
 def Get_Now_Datetime(ehgRpUTwClNXmqQEPHfMbvcYBdnWys):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetNoCache(ehgRpUTwClNXmqQEPHfMbvcYBdnWys):
  ehgRpUTwClNXmqQEPHfMbvcYBdnWyA =ehgRpUTwClNXmqQEPHfMbvcYBdnWaz(time.time()*1000)
  return ehgRpUTwClNXmqQEPHfMbvcYBdnWyA
 def generatePcId(ehgRpUTwClNXmqQEPHfMbvcYBdnWys):
  t=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.GetNoCache()
  r=random.random()
  ehgRpUTwClNXmqQEPHfMbvcYBdnWyi=ehgRpUTwClNXmqQEPHfMbvcYBdnWaJ(t)+ehgRpUTwClNXmqQEPHfMbvcYBdnWaJ(r)[2:12]
  return ehgRpUTwClNXmqQEPHfMbvcYBdnWyi
 def generatePvId(ehgRpUTwClNXmqQEPHfMbvcYBdnWys,genType='1'):
  import hashlib
  m=hashlib.md5()
  ehgRpUTwClNXmqQEPHfMbvcYBdnWyI=ehgRpUTwClNXmqQEPHfMbvcYBdnWaJ(random.random())
  m.update(ehgRpUTwClNXmqQEPHfMbvcYBdnWyI.encode('utf-8'))
  ehgRpUTwClNXmqQEPHfMbvcYBdnWyS=ehgRpUTwClNXmqQEPHfMbvcYBdnWaJ(m.hexdigest())
  if genType=='1':
   return '%s-%s-%s-%s-%s'%(ehgRpUTwClNXmqQEPHfMbvcYBdnWyS[:8],ehgRpUTwClNXmqQEPHfMbvcYBdnWyS[8:12],ehgRpUTwClNXmqQEPHfMbvcYBdnWyS[12:16],ehgRpUTwClNXmqQEPHfMbvcYBdnWyS[16:20],ehgRpUTwClNXmqQEPHfMbvcYBdnWyS[20:])
  else:
   return ehgRpUTwClNXmqQEPHfMbvcYBdnWyS
 def Get_DeviceID(ehgRpUTwClNXmqQEPHfMbvcYBdnWys):
  ehgRpUTwClNXmqQEPHfMbvcYBdnWyu=''
  try: 
   fp=ehgRpUTwClNXmqQEPHfMbvcYBdnWaL(ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP_DEVICE_FILENAME,'r',-1,'utf-8')
   ehgRpUTwClNXmqQEPHfMbvcYBdnWyD= json.load(fp)
   fp.close()
   ehgRpUTwClNXmqQEPHfMbvcYBdnWyu=ehgRpUTwClNXmqQEPHfMbvcYBdnWyD.get('device_id')
  except ehgRpUTwClNXmqQEPHfMbvcYBdnWar as exception:
   ehgRpUTwClNXmqQEPHfMbvcYBdnWay
  if ehgRpUTwClNXmqQEPHfMbvcYBdnWyu=='':
   ehgRpUTwClNXmqQEPHfMbvcYBdnWyu=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.generatePvId(genType='1')
   try: 
    fp=ehgRpUTwClNXmqQEPHfMbvcYBdnWaL(ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP_DEVICE_FILENAME,'w',-1,'utf-8')
    json.dump({'device_id':ehgRpUTwClNXmqQEPHfMbvcYBdnWyu},fp,indent=4,ensure_ascii=ehgRpUTwClNXmqQEPHfMbvcYBdnWaK)
    fp.close()
   except ehgRpUTwClNXmqQEPHfMbvcYBdnWar as exception:
    return ''
  return ehgRpUTwClNXmqQEPHfMbvcYBdnWyu
 def Make_authHeader(ehgRpUTwClNXmqQEPHfMbvcYBdnWys):
  tr=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.generatePvId(genType=2)
  ti=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.GetNoCache()
  ehgRpUTwClNXmqQEPHfMbvcYBdnWaO=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.generatePvId(genType=2)[:16]
  ehgRpUTwClNXmqQEPHfMbvcYBdnWyo='00-%s-%s-01'%(tr,ehgRpUTwClNXmqQEPHfMbvcYBdnWaO,)
  ehgRpUTwClNXmqQEPHfMbvcYBdnWyk ='%s@nr=0-1-%s-%s-%s----%s'%(ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['NREUM']['tk'],ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['NREUM']['ac'],ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['NREUM']['ap'],ehgRpUTwClNXmqQEPHfMbvcYBdnWaO,ti,)
  ehgRpUTwClNXmqQEPHfMbvcYBdnWyt ='{"v":[0,1],"d":{"ty":"Browser","ac":"%s","ap":"%s","id":"%s","tr":"%s","ti":%s,"tk":"%s"}}'%(ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['NREUM']['ac'],ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['NREUM']['ap'],ehgRpUTwClNXmqQEPHfMbvcYBdnWaO,tr,ti,ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['NREUM']['tk'],) 
  return ehgRpUTwClNXmqQEPHfMbvcYBdnWyo,ehgRpUTwClNXmqQEPHfMbvcYBdnWyk,base64.standard_b64encode(ehgRpUTwClNXmqQEPHfMbvcYBdnWyt.encode()).decode('utf-8')
 def Init_CP(ehgRpUTwClNXmqQEPHfMbvcYBdnWys):
  ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP={}
  ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['ACCOUNT']={'cpid':'','cppw':'','cppf':'0'}
  ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']={}
 def Save_session_acount(ehgRpUTwClNXmqQEPHfMbvcYBdnWys,ehgRpUTwClNXmqQEPHfMbvcYBdnWyj,ehgRpUTwClNXmqQEPHfMbvcYBdnWyV,ehgRpUTwClNXmqQEPHfMbvcYBdnWyG):
  ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['ACCOUNT']['cpid']=base64.standard_b64encode(ehgRpUTwClNXmqQEPHfMbvcYBdnWyj.encode()).decode('utf-8')
  ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['ACCOUNT']['cppw']=base64.standard_b64encode(ehgRpUTwClNXmqQEPHfMbvcYBdnWyV.encode()).decode('utf-8')
  ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['ACCOUNT']['cppf']=ehgRpUTwClNXmqQEPHfMbvcYBdnWaJ(ehgRpUTwClNXmqQEPHfMbvcYBdnWyG)
 def Load_session_acount(ehgRpUTwClNXmqQEPHfMbvcYBdnWys):
  ehgRpUTwClNXmqQEPHfMbvcYBdnWyj=base64.standard_b64decode(ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['ACCOUNT']['cpid']).decode('utf-8')
  ehgRpUTwClNXmqQEPHfMbvcYBdnWyV=base64.standard_b64decode(ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['ACCOUNT']['cppw']).decode('utf-8')
  ehgRpUTwClNXmqQEPHfMbvcYBdnWyG=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['ACCOUNT']['cppf']
  return ehgRpUTwClNXmqQEPHfMbvcYBdnWyj,ehgRpUTwClNXmqQEPHfMbvcYBdnWyV,ehgRpUTwClNXmqQEPHfMbvcYBdnWyG
 def make_CP_DefaultCookies(ehgRpUTwClNXmqQEPHfMbvcYBdnWys):
  ehgRpUTwClNXmqQEPHfMbvcYBdnWyF={}
  if 'NEXT_LOCALE' in ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']:ehgRpUTwClNXmqQEPHfMbvcYBdnWyF['NEXT_LOCALE']=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['NEXT_LOCALE']
  if 'ak_bmsc' in ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']:ehgRpUTwClNXmqQEPHfMbvcYBdnWyF['ak_bmsc'] =ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['ak_bmsc']
  if 'bm_mi' in ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']:ehgRpUTwClNXmqQEPHfMbvcYBdnWyF['bm_mi'] =ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['bm_mi']
  if 'bm_sv' in ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']:ehgRpUTwClNXmqQEPHfMbvcYBdnWyF['bm_sv'] =ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['bm_sv']
  if 'PCID' in ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']:ehgRpUTwClNXmqQEPHfMbvcYBdnWyF['PCID'] =ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['PCID']
  if 'member_srl' in ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']:ehgRpUTwClNXmqQEPHfMbvcYBdnWyF['member_srl']=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['member_srl']
  if 'token' in ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']:ehgRpUTwClNXmqQEPHfMbvcYBdnWyF['token'] =ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['token']
  return ehgRpUTwClNXmqQEPHfMbvcYBdnWyF
 def Get_CP_Login(ehgRpUTwClNXmqQEPHfMbvcYBdnWys,userid,userpw,ehgRpUTwClNXmqQEPHfMbvcYBdnWKi):
  try:
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKy=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.API_DOMAIN
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKs=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.callRequestCookies('Get',ehgRpUTwClNXmqQEPHfMbvcYBdnWKy,payload=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,params=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,headers=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,cookies=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,redirects=ehgRpUTwClNXmqQEPHfMbvcYBdnWaK)
   if ehgRpUTwClNXmqQEPHfMbvcYBdnWKs.status_code not in[301,302]:return ehgRpUTwClNXmqQEPHfMbvcYBdnWaK
   for ehgRpUTwClNXmqQEPHfMbvcYBdnWKa in ehgRpUTwClNXmqQEPHfMbvcYBdnWKs.cookies:
    if ehgRpUTwClNXmqQEPHfMbvcYBdnWKa.name=='NEXT_LOCALE':
     ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['NEXT_LOCALE']=ehgRpUTwClNXmqQEPHfMbvcYBdnWKa.value
    elif ehgRpUTwClNXmqQEPHfMbvcYBdnWKa.name=='ak_bmsc':
     ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['ak_bmsc']=ehgRpUTwClNXmqQEPHfMbvcYBdnWKa.value
   ehgRpUTwClNXmqQEPHfMbvcYBdnWyF={'NEXT_LOCALE':ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['NEXT_LOCALE'],'ak_bmsc':ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['ak_bmsc'],}
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKs=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.callRequestCookies('Get',ehgRpUTwClNXmqQEPHfMbvcYBdnWKy,payload=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,params=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,headers=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,cookies=ehgRpUTwClNXmqQEPHfMbvcYBdnWyF,redirects=ehgRpUTwClNXmqQEPHfMbvcYBdnWaK)
   if ehgRpUTwClNXmqQEPHfMbvcYBdnWKs.status_code not in[200]:return ehgRpUTwClNXmqQEPHfMbvcYBdnWaK
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKJ=re.findall('NREUM.loader_config=\{[\w\d\":,-]+\}',ehgRpUTwClNXmqQEPHfMbvcYBdnWKs.text)[0].split('=')[1]
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKJ=ehgRpUTwClNXmqQEPHfMbvcYBdnWKJ.replace('{','{"').replace(':','":').replace(',',',"')
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKJ=json.loads(ehgRpUTwClNXmqQEPHfMbvcYBdnWKJ)
   ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['NREUM']={'ac':ehgRpUTwClNXmqQEPHfMbvcYBdnWKJ['accountID'],'tk':ehgRpUTwClNXmqQEPHfMbvcYBdnWKJ['trustKey'],'ap':ehgRpUTwClNXmqQEPHfMbvcYBdnWKJ['agentID'],'lk':ehgRpUTwClNXmqQEPHfMbvcYBdnWKJ['licenseKey'],}
   for ehgRpUTwClNXmqQEPHfMbvcYBdnWKa in ehgRpUTwClNXmqQEPHfMbvcYBdnWKs.cookies:
    if ehgRpUTwClNXmqQEPHfMbvcYBdnWKa.name=='bm_mi':
     ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['bm_mi']=ehgRpUTwClNXmqQEPHfMbvcYBdnWKa.value
    elif ehgRpUTwClNXmqQEPHfMbvcYBdnWKa.name=='bm_sv':
     ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['bm_sv'] =ehgRpUTwClNXmqQEPHfMbvcYBdnWKa.value
     ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['bm_sv_ex']=ehgRpUTwClNXmqQEPHfMbvcYBdnWKa.expires 
  except ehgRpUTwClNXmqQEPHfMbvcYBdnWar as exception:
   ehgRpUTwClNXmqQEPHfMbvcYBdnWas(exception)
   return ehgRpUTwClNXmqQEPHfMbvcYBdnWaK
  try:
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKy=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.API_DOMAIN+'/api/auth'
   ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['PCID']=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.generatePcId()
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKL=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.Get_DeviceID()
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKz =ehgRpUTwClNXmqQEPHfMbvcYBdnWKL.split('-')[0]
   ehgRpUTwClNXmqQEPHfMbvcYBdnWyo,ehgRpUTwClNXmqQEPHfMbvcYBdnWyk,ehgRpUTwClNXmqQEPHfMbvcYBdnWyt=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.Make_authHeader()
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKr={'traceparent':ehgRpUTwClNXmqQEPHfMbvcYBdnWyo,'tracestate':ehgRpUTwClNXmqQEPHfMbvcYBdnWyk,'newrelic':ehgRpUTwClNXmqQEPHfMbvcYBdnWyt,'content-type':'application/json',}
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKO={'device':{'deviceId':'web-'+ehgRpUTwClNXmqQEPHfMbvcYBdnWKL,'model':ehgRpUTwClNXmqQEPHfMbvcYBdnWys.MODEL,'name':'Chrome Desktop '+ehgRpUTwClNXmqQEPHfMbvcYBdnWKz,'os':'Windows','osVersion':'10','type':'webclient',},'email':userid,'password':userpw,}
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKO=json.dumps(ehgRpUTwClNXmqQEPHfMbvcYBdnWKO,separators=(',',':'))
   ehgRpUTwClNXmqQEPHfMbvcYBdnWyF={'NEXT_LOCALE':ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['NEXT_LOCALE'],'ak_bmsc':ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['ak_bmsc'],'bm_mi':ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['bm_mi'],'bm_sv':ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['bm_sv'],'PCID':ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['PCID'],}
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKs=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.callRequestCookies('Post',ehgRpUTwClNXmqQEPHfMbvcYBdnWKy,payload=ehgRpUTwClNXmqQEPHfMbvcYBdnWKO,params=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,headers=ehgRpUTwClNXmqQEPHfMbvcYBdnWKr,cookies=ehgRpUTwClNXmqQEPHfMbvcYBdnWyF,redirects=ehgRpUTwClNXmqQEPHfMbvcYBdnWaK)
   if ehgRpUTwClNXmqQEPHfMbvcYBdnWKs.status_code not in[200]:
    ehgRpUTwClNXmqQEPHfMbvcYBdnWKx=json.loads(ehgRpUTwClNXmqQEPHfMbvcYBdnWKs.text)
    if 'error' in ehgRpUTwClNXmqQEPHfMbvcYBdnWKx:
     ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['error']=ehgRpUTwClNXmqQEPHfMbvcYBdnWKx.get('error').get('detail')
    return ehgRpUTwClNXmqQEPHfMbvcYBdnWaK
   for ehgRpUTwClNXmqQEPHfMbvcYBdnWKa in ehgRpUTwClNXmqQEPHfMbvcYBdnWKs.cookies:
    if ehgRpUTwClNXmqQEPHfMbvcYBdnWKa.name=='token':
     ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['token']=ehgRpUTwClNXmqQEPHfMbvcYBdnWKa.value
    elif ehgRpUTwClNXmqQEPHfMbvcYBdnWKa.name=='member_srl':
     ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['member_srl']=ehgRpUTwClNXmqQEPHfMbvcYBdnWKa.value
    elif ehgRpUTwClNXmqQEPHfMbvcYBdnWKa.name=='bm_sv':
     ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['bm_sv'] =ehgRpUTwClNXmqQEPHfMbvcYBdnWKa.value
     ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['bm_sv_ex']=ehgRpUTwClNXmqQEPHfMbvcYBdnWKa.expires 
  except ehgRpUTwClNXmqQEPHfMbvcYBdnWar as exception:
   ehgRpUTwClNXmqQEPHfMbvcYBdnWas(exception)
   return ehgRpUTwClNXmqQEPHfMbvcYBdnWaK
  ehgRpUTwClNXmqQEPHfMbvcYBdnWys.Save_session_acount(userid,userpw,ehgRpUTwClNXmqQEPHfMbvcYBdnWKi)
  return ehgRpUTwClNXmqQEPHfMbvcYBdnWax
 def Get_CP_profile(ehgRpUTwClNXmqQEPHfMbvcYBdnWys,ehgRpUTwClNXmqQEPHfMbvcYBdnWKi,limit_days=1,re_check=ehgRpUTwClNXmqQEPHfMbvcYBdnWaK):
  if re_check==ehgRpUTwClNXmqQEPHfMbvcYBdnWax:
   if ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['bm_sv_ex']>ehgRpUTwClNXmqQEPHfMbvcYBdnWaz(time.time()):
    ehgRpUTwClNXmqQEPHfMbvcYBdnWas('bm_sv_ex ok')
    return ehgRpUTwClNXmqQEPHfMbvcYBdnWax
  try:
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKy=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.API_DOMAIN+'/api/profiles'
   ehgRpUTwClNXmqQEPHfMbvcYBdnWyo,ehgRpUTwClNXmqQEPHfMbvcYBdnWyk,ehgRpUTwClNXmqQEPHfMbvcYBdnWyt=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.Make_authHeader()
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKr={'traceparent':ehgRpUTwClNXmqQEPHfMbvcYBdnWyo,'tracestate':ehgRpUTwClNXmqQEPHfMbvcYBdnWyk,'newrelic':ehgRpUTwClNXmqQEPHfMbvcYBdnWyt,}
   ehgRpUTwClNXmqQEPHfMbvcYBdnWyF=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.make_CP_DefaultCookies()
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKs=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.callRequestCookies('Get',ehgRpUTwClNXmqQEPHfMbvcYBdnWKy,payload=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,params=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,headers=ehgRpUTwClNXmqQEPHfMbvcYBdnWKr,cookies=ehgRpUTwClNXmqQEPHfMbvcYBdnWyF,redirects=ehgRpUTwClNXmqQEPHfMbvcYBdnWaK)
   if ehgRpUTwClNXmqQEPHfMbvcYBdnWKs.status_code not in[200]:return ehgRpUTwClNXmqQEPHfMbvcYBdnWaK
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKx=json.loads(ehgRpUTwClNXmqQEPHfMbvcYBdnWKs.text)
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKA=0 
   for ehgRpUTwClNXmqQEPHfMbvcYBdnWKa in ehgRpUTwClNXmqQEPHfMbvcYBdnWKs.cookies:
    ehgRpUTwClNXmqQEPHfMbvcYBdnWas(ehgRpUTwClNXmqQEPHfMbvcYBdnWKa.name)
    if ehgRpUTwClNXmqQEPHfMbvcYBdnWKa.name=='bm_sv':
     ehgRpUTwClNXmqQEPHfMbvcYBdnWKA=1
     ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['bm_sv'] =ehgRpUTwClNXmqQEPHfMbvcYBdnWKa.value
     ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['bm_sv_ex']=ehgRpUTwClNXmqQEPHfMbvcYBdnWKa.expires 
   if ehgRpUTwClNXmqQEPHfMbvcYBdnWKA==0:
    ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['bm_sv_ex']=ehgRpUTwClNXmqQEPHfMbvcYBdnWaz(time.time())+60*60*2 
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKi=ehgRpUTwClNXmqQEPHfMbvcYBdnWKx.get('data')[ehgRpUTwClNXmqQEPHfMbvcYBdnWaz(ehgRpUTwClNXmqQEPHfMbvcYBdnWKi)]
   ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['accountId']=ehgRpUTwClNXmqQEPHfMbvcYBdnWKi.get('accountId')
   ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['profileId']=ehgRpUTwClNXmqQEPHfMbvcYBdnWKi.get('profileId')
  except ehgRpUTwClNXmqQEPHfMbvcYBdnWar as exception:
   ehgRpUTwClNXmqQEPHfMbvcYBdnWas(exception)
   return ehgRpUTwClNXmqQEPHfMbvcYBdnWaK
  if re_check==ehgRpUTwClNXmqQEPHfMbvcYBdnWaK:
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKI =ehgRpUTwClNXmqQEPHfMbvcYBdnWys.Get_Now_Datetime()
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKS=ehgRpUTwClNXmqQEPHfMbvcYBdnWKI+datetime.timedelta(days=limit_days)
   ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['limitdate']=ehgRpUTwClNXmqQEPHfMbvcYBdnWKS.strftime('%Y-%m-%d')
  else:
   ehgRpUTwClNXmqQEPHfMbvcYBdnWas('re check')
  ehgRpUTwClNXmqQEPHfMbvcYBdnWys.dic_To_jsonfile(ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP_COOKIE_FILENAME,ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP)
  return ehgRpUTwClNXmqQEPHfMbvcYBdnWax
 def Get_Category_GroupList(ehgRpUTwClNXmqQEPHfMbvcYBdnWys,vType):
  ehgRpUTwClNXmqQEPHfMbvcYBdnWKu=[] 
  try:
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKy=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.API_VIEWURL+'/v2/discover/feed' 
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKD={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false',}
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKs=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.callRequestCookies('Get',ehgRpUTwClNXmqQEPHfMbvcYBdnWKy,payload=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,params=ehgRpUTwClNXmqQEPHfMbvcYBdnWKD,headers=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,cookies=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,redirects=ehgRpUTwClNXmqQEPHfMbvcYBdnWax)
   if ehgRpUTwClNXmqQEPHfMbvcYBdnWKs.status_code not in[200]:return[]
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKx=json.loads(ehgRpUTwClNXmqQEPHfMbvcYBdnWKs.text)
   if vType in['TVSHOWS','MOVIES']:
    ehgRpUTwClNXmqQEPHfMbvcYBdnWKo='Explores' 
   elif vType in['EDUCATION']:
    ehgRpUTwClNXmqQEPHfMbvcYBdnWKo='Collection-Rails-Curation'
   elif vType in['ALL']:
    ehgRpUTwClNXmqQEPHfMbvcYBdnWKo='Explores-Categories'
   for ehgRpUTwClNXmqQEPHfMbvcYBdnWKk in ehgRpUTwClNXmqQEPHfMbvcYBdnWKx.get('data'):
    if ehgRpUTwClNXmqQEPHfMbvcYBdnWKk.get('type')==ehgRpUTwClNXmqQEPHfMbvcYBdnWKo:
     for ehgRpUTwClNXmqQEPHfMbvcYBdnWKt in ehgRpUTwClNXmqQEPHfMbvcYBdnWKk.get('data'):
      if vType in['TVSHOWS','MOVIES']:
       ehgRpUTwClNXmqQEPHfMbvcYBdnWKj=ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('collectionId')
      elif vType in['EDUCATION','ALL']:
       ehgRpUTwClNXmqQEPHfMbvcYBdnWKj=ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('id')
      ehgRpUTwClNXmqQEPHfMbvcYBdnWKV={'collectionId':ehgRpUTwClNXmqQEPHfMbvcYBdnWKj,'title':ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('name'),'category':ehgRpUTwClNXmqQEPHfMbvcYBdnWKk.get('category'),'page':'1','pre_title':'',}
      ehgRpUTwClNXmqQEPHfMbvcYBdnWKu.append(ehgRpUTwClNXmqQEPHfMbvcYBdnWKV)
     break
  except ehgRpUTwClNXmqQEPHfMbvcYBdnWar as exception:
   ehgRpUTwClNXmqQEPHfMbvcYBdnWas(exception)
   return[]
  return ehgRpUTwClNXmqQEPHfMbvcYBdnWKu
 def Get_Category_List(ehgRpUTwClNXmqQEPHfMbvcYBdnWys,vType,ehgRpUTwClNXmqQEPHfMbvcYBdnWKj,page_int):
  ehgRpUTwClNXmqQEPHfMbvcYBdnWKu=[] 
  ehgRpUTwClNXmqQEPHfMbvcYBdnWKG=ehgRpUTwClNXmqQEPHfMbvcYBdnWaK
  try:
   if vType=='ALL':
    ehgRpUTwClNXmqQEPHfMbvcYBdnWKr={'x-membersrl':ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['member_srl'],'x-pcid':ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['PCID'],'x-profileid':ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['profileId'],}
    ehgRpUTwClNXmqQEPHfMbvcYBdnWKD={'platform':'WEBCLIENT','page':ehgRpUTwClNXmqQEPHfMbvcYBdnWaJ(page_int),'perPage':ehgRpUTwClNXmqQEPHfMbvcYBdnWaJ(ehgRpUTwClNXmqQEPHfMbvcYBdnWys.PAGE_LIMIT),'locale':'ko','sort':'',}
    ehgRpUTwClNXmqQEPHfMbvcYBdnWKy=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.API_VIEWURL+'/v1/discover/categories/'+ehgRpUTwClNXmqQEPHfMbvcYBdnWKj+'/titles'
    ehgRpUTwClNXmqQEPHfMbvcYBdnWKs=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.callRequestCookies('Get',ehgRpUTwClNXmqQEPHfMbvcYBdnWKy,payload=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,params=ehgRpUTwClNXmqQEPHfMbvcYBdnWKD,headers=ehgRpUTwClNXmqQEPHfMbvcYBdnWKr,cookies=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,redirects=ehgRpUTwClNXmqQEPHfMbvcYBdnWax)
   else: 
    ehgRpUTwClNXmqQEPHfMbvcYBdnWKD={'platform':'WEBCLIENT','page':ehgRpUTwClNXmqQEPHfMbvcYBdnWaJ(page_int),'perPage':ehgRpUTwClNXmqQEPHfMbvcYBdnWaJ(ehgRpUTwClNXmqQEPHfMbvcYBdnWys.PAGE_LIMIT),}
    ehgRpUTwClNXmqQEPHfMbvcYBdnWKy=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.API_VIEWURL+'/v1/discover/collections/'+ehgRpUTwClNXmqQEPHfMbvcYBdnWKj+'/titles'
    ehgRpUTwClNXmqQEPHfMbvcYBdnWKs=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.callRequestCookies('Get',ehgRpUTwClNXmqQEPHfMbvcYBdnWKy,payload=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,params=ehgRpUTwClNXmqQEPHfMbvcYBdnWKD,headers=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,cookies=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,redirects=ehgRpUTwClNXmqQEPHfMbvcYBdnWax)
   if ehgRpUTwClNXmqQEPHfMbvcYBdnWKs.status_code not in[200]:return[],ehgRpUTwClNXmqQEPHfMbvcYBdnWaK
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKx=json.loads(ehgRpUTwClNXmqQEPHfMbvcYBdnWKs.text)
   if vType=='ALL':
    ehgRpUTwClNXmqQEPHfMbvcYBdnWKF=ehgRpUTwClNXmqQEPHfMbvcYBdnWKx.get('data').get('data')
   else:
    ehgRpUTwClNXmqQEPHfMbvcYBdnWKF=ehgRpUTwClNXmqQEPHfMbvcYBdnWKx.get('data')
   for ehgRpUTwClNXmqQEPHfMbvcYBdnWKt in ehgRpUTwClNXmqQEPHfMbvcYBdnWKF:
    ehgRpUTwClNXmqQEPHfMbvcYBdnWsy=ehgRpUTwClNXmqQEPHfMbvcYBdnWsz=ehgRpUTwClNXmqQEPHfMbvcYBdnWst=ehgRpUTwClNXmqQEPHfMbvcYBdnWsk=''
    if 'poster' in ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('images'):ehgRpUTwClNXmqQEPHfMbvcYBdnWsy =ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('images').get('poster').get('url')
    if 'story-art' in ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('images'):ehgRpUTwClNXmqQEPHfMbvcYBdnWsz =ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('images').get('story-art').get('url')
    if 'title-treatment' in ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('images'):ehgRpUTwClNXmqQEPHfMbvcYBdnWst=ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('images').get('title-treatment').get('url')
    if 'story-art' in ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('images'):ehgRpUTwClNXmqQEPHfMbvcYBdnWsk =ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('images').get('story-art').get('url')
    ehgRpUTwClNXmqQEPHfMbvcYBdnWsK=''
    if ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('badge')not in[{},ehgRpUTwClNXmqQEPHfMbvcYBdnWay]:
     for i in ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('badge').get('text'):
      ehgRpUTwClNXmqQEPHfMbvcYBdnWsK+=i.get('text')
    ehgRpUTwClNXmqQEPHfMbvcYBdnWsa=''
    if ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('seasonList')!=ehgRpUTwClNXmqQEPHfMbvcYBdnWay:
     ehgRpUTwClNXmqQEPHfMbvcYBdnWsa=','.join(ehgRpUTwClNXmqQEPHfMbvcYBdnWaJ(e)for e in ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('seasonList'))
    ehgRpUTwClNXmqQEPHfMbvcYBdnWsJ =[]
    for ehgRpUTwClNXmqQEPHfMbvcYBdnWsL in ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('tags'):
     ehgRpUTwClNXmqQEPHfMbvcYBdnWsJ.append(ehgRpUTwClNXmqQEPHfMbvcYBdnWsL.get('tag'))
    ehgRpUTwClNXmqQEPHfMbvcYBdnWKV={'id':ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('id'),'title':ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('title'),'thumbnail':{'poster':ehgRpUTwClNXmqQEPHfMbvcYBdnWsy,'thumb':ehgRpUTwClNXmqQEPHfMbvcYBdnWsz,'clearlogo':ehgRpUTwClNXmqQEPHfMbvcYBdnWst,'fanart':ehgRpUTwClNXmqQEPHfMbvcYBdnWsk},'mpaa':ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('age_rating'),'duration':ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('running_time'),'asis':ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('as'),'badge':ehgRpUTwClNXmqQEPHfMbvcYBdnWsK,'year':ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('meta').get('releaseYear'),'seasonList':ehgRpUTwClNXmqQEPHfMbvcYBdnWsa,'genreList':ehgRpUTwClNXmqQEPHfMbvcYBdnWsJ,}
    ehgRpUTwClNXmqQEPHfMbvcYBdnWKu.append(ehgRpUTwClNXmqQEPHfMbvcYBdnWKV)
   if ehgRpUTwClNXmqQEPHfMbvcYBdnWKx.get('pagination').get('totalPages')>page_int:
    ehgRpUTwClNXmqQEPHfMbvcYBdnWKG=ehgRpUTwClNXmqQEPHfMbvcYBdnWax
  except ehgRpUTwClNXmqQEPHfMbvcYBdnWar as exception:
   ehgRpUTwClNXmqQEPHfMbvcYBdnWas(exception)
   return[],ehgRpUTwClNXmqQEPHfMbvcYBdnWaK
  return ehgRpUTwClNXmqQEPHfMbvcYBdnWKu,ehgRpUTwClNXmqQEPHfMbvcYBdnWKG
 def Get_Episode_List(ehgRpUTwClNXmqQEPHfMbvcYBdnWys,programId,season):
  ehgRpUTwClNXmqQEPHfMbvcYBdnWKu=[] 
  try:
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKy=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.API_VIEWURL+'/v1/discover/titles/'+programId+'/episodes'
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKD={'season':season,'sort':'true','locale':'ko',}
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKs=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.callRequestCookies('Get',ehgRpUTwClNXmqQEPHfMbvcYBdnWKy,payload=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,params=ehgRpUTwClNXmqQEPHfMbvcYBdnWKD,headers=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,cookies=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,redirects=ehgRpUTwClNXmqQEPHfMbvcYBdnWax)
   if ehgRpUTwClNXmqQEPHfMbvcYBdnWKs.status_code not in[200]:return[]
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKx=json.loads(ehgRpUTwClNXmqQEPHfMbvcYBdnWKs.text)
   for ehgRpUTwClNXmqQEPHfMbvcYBdnWKt in ehgRpUTwClNXmqQEPHfMbvcYBdnWKx.get('data'):
    ehgRpUTwClNXmqQEPHfMbvcYBdnWsz=''
    if 'story-art' in ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('images'):ehgRpUTwClNXmqQEPHfMbvcYBdnWsz =ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('images').get('story-art').get('url')
    ehgRpUTwClNXmqQEPHfMbvcYBdnWsJ =[]
    for ehgRpUTwClNXmqQEPHfMbvcYBdnWsL in ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('tags'):
     ehgRpUTwClNXmqQEPHfMbvcYBdnWsJ.append(ehgRpUTwClNXmqQEPHfMbvcYBdnWsL.get('tag'))
    ehgRpUTwClNXmqQEPHfMbvcYBdnWKV={'id':ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('id'),'title':ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('title'),'thumbnail':{'thumb':ehgRpUTwClNXmqQEPHfMbvcYBdnWsz,'fanart':ehgRpUTwClNXmqQEPHfMbvcYBdnWsz},'mpaa':ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('age_rating'),'duration':ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('running_time'),'asis':ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('as'),'year':ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('meta').get('releaseYear'),'episode':ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('episode'),'genreList':ehgRpUTwClNXmqQEPHfMbvcYBdnWsJ,'desc':ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('description'),}
    ehgRpUTwClNXmqQEPHfMbvcYBdnWKu.append(ehgRpUTwClNXmqQEPHfMbvcYBdnWKV)
  except ehgRpUTwClNXmqQEPHfMbvcYBdnWar as exception:
   ehgRpUTwClNXmqQEPHfMbvcYBdnWas(exception)
   return[]
  return ehgRpUTwClNXmqQEPHfMbvcYBdnWKu
 def Get_vInfo(ehgRpUTwClNXmqQEPHfMbvcYBdnWys,titleId):
  try:
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKy=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.API_VIEWURL+'/v1/discover/titles/'+titleId 
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKD={'locale':'ko'}
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKs=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.callRequestCookies('Get',ehgRpUTwClNXmqQEPHfMbvcYBdnWKy,payload=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,params=ehgRpUTwClNXmqQEPHfMbvcYBdnWKD,headers=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,cookies=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,redirects=ehgRpUTwClNXmqQEPHfMbvcYBdnWax)
   if ehgRpUTwClNXmqQEPHfMbvcYBdnWKs.status_code not in[200]:return '','',''
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKx=json.loads(ehgRpUTwClNXmqQEPHfMbvcYBdnWKs.text).get('data')
   ehgRpUTwClNXmqQEPHfMbvcYBdnWsa=''
   if ehgRpUTwClNXmqQEPHfMbvcYBdnWKx.get('seasonList')!=ehgRpUTwClNXmqQEPHfMbvcYBdnWay:
    ehgRpUTwClNXmqQEPHfMbvcYBdnWsa=','.join(ehgRpUTwClNXmqQEPHfMbvcYBdnWaJ(e)for e in ehgRpUTwClNXmqQEPHfMbvcYBdnWKx.get('seasonList'))
   ehgRpUTwClNXmqQEPHfMbvcYBdnWsr={'age_rating':ehgRpUTwClNXmqQEPHfMbvcYBdnWKx.get('age_rating'),'asset_id':ehgRpUTwClNXmqQEPHfMbvcYBdnWKx.get('asset_id'),'availability':ehgRpUTwClNXmqQEPHfMbvcYBdnWKx.get('availability'),'deal_id':ehgRpUTwClNXmqQEPHfMbvcYBdnWKx.get('deal_id'),'downloadable':'true' if ehgRpUTwClNXmqQEPHfMbvcYBdnWKx.get('downloadable')else 'false','region':ehgRpUTwClNXmqQEPHfMbvcYBdnWKx.get('region'),'streamable':'true' if ehgRpUTwClNXmqQEPHfMbvcYBdnWKx.get('streamable')else 'false','asis':ehgRpUTwClNXmqQEPHfMbvcYBdnWKx.get('as'),'seasonList':ehgRpUTwClNXmqQEPHfMbvcYBdnWsa}
  except ehgRpUTwClNXmqQEPHfMbvcYBdnWar as exception:
   ehgRpUTwClNXmqQEPHfMbvcYBdnWas(exception)
   return{}
  return ehgRpUTwClNXmqQEPHfMbvcYBdnWsr
 def GetBroadURL(ehgRpUTwClNXmqQEPHfMbvcYBdnWys,titleId):
  ehgRpUTwClNXmqQEPHfMbvcYBdnWsO=''
  ehgRpUTwClNXmqQEPHfMbvcYBdnWsx =''
  ehgRpUTwClNXmqQEPHfMbvcYBdnWsr=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.Get_vInfo(titleId)
  if ehgRpUTwClNXmqQEPHfMbvcYBdnWsr=={}:return '',''
  try:
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKy=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.API_DOMAIN+'/api/playback/play' 
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKD={'titleId':titleId}
   ehgRpUTwClNXmqQEPHfMbvcYBdnWyo,ehgRpUTwClNXmqQEPHfMbvcYBdnWyk,ehgRpUTwClNXmqQEPHfMbvcYBdnWyt=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.Make_authHeader()
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKr={'traceparent':ehgRpUTwClNXmqQEPHfMbvcYBdnWyo,'tracestate':ehgRpUTwClNXmqQEPHfMbvcYBdnWyk,'newrelic':ehgRpUTwClNXmqQEPHfMbvcYBdnWyt,'x-force-raw':'true','x-pcid':ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':ehgRpUTwClNXmqQEPHfMbvcYBdnWsr.get('age_rating'),'x-title-availability':ehgRpUTwClNXmqQEPHfMbvcYBdnWsr.get('availability'),'x-title-brightcove-id':ehgRpUTwClNXmqQEPHfMbvcYBdnWsr.get('asset_id'),'x-title-deal-id':ehgRpUTwClNXmqQEPHfMbvcYBdnWsr.get('deal_id'),'x-title-downloadable':ehgRpUTwClNXmqQEPHfMbvcYBdnWsr.get('downloadable'),'x-title-region':ehgRpUTwClNXmqQEPHfMbvcYBdnWsr.get('region'),'x-title-streamable':ehgRpUTwClNXmqQEPHfMbvcYBdnWsr.get('streamable'),}
   ehgRpUTwClNXmqQEPHfMbvcYBdnWyF=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.make_CP_DefaultCookies()
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKs=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.callRequestCookies('Get',ehgRpUTwClNXmqQEPHfMbvcYBdnWKy,payload=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,params=ehgRpUTwClNXmqQEPHfMbvcYBdnWKD,headers=ehgRpUTwClNXmqQEPHfMbvcYBdnWKr,cookies=ehgRpUTwClNXmqQEPHfMbvcYBdnWyF,redirects=ehgRpUTwClNXmqQEPHfMbvcYBdnWax)
   if ehgRpUTwClNXmqQEPHfMbvcYBdnWKs.status_code not in[200]:return '',json.loads(ehgRpUTwClNXmqQEPHfMbvcYBdnWKs.text).get('error').get('detail')
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKx=json.loads(ehgRpUTwClNXmqQEPHfMbvcYBdnWKs.text)
   for ehgRpUTwClNXmqQEPHfMbvcYBdnWKt in ehgRpUTwClNXmqQEPHfMbvcYBdnWKx.get('data').get('raw').get('sources'):
    if ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('type')=='application/dash+xml' and ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('src')[0:8]=='https://':
     ehgRpUTwClNXmqQEPHfMbvcYBdnWsO=ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('src')
     ehgRpUTwClNXmqQEPHfMbvcYBdnWsx =ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('key_systems').get('com.widevine.alpha').get('license_url')
     break
   for ehgRpUTwClNXmqQEPHfMbvcYBdnWKt in ehgRpUTwClNXmqQEPHfMbvcYBdnWKx.get('data').get('raw').get('text_tracks'):
    if ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('mime_type')=='text/webvtt' and ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('src')[0:8]=='https://':
     ehgRpUTwClNXmqQEPHfMbvcYBdnWsA=ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('src')
     break
  except ehgRpUTwClNXmqQEPHfMbvcYBdnWar as exception:
   ehgRpUTwClNXmqQEPHfMbvcYBdnWas(exception)
   return '',''
  return ehgRpUTwClNXmqQEPHfMbvcYBdnWsO,ehgRpUTwClNXmqQEPHfMbvcYBdnWsx
 def Get_Theme_GroupList(ehgRpUTwClNXmqQEPHfMbvcYBdnWys,vType):
  ehgRpUTwClNXmqQEPHfMbvcYBdnWKu=[] 
  try:
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKy=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.API_VIEWURL+'/v2/discover/feed' 
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKD={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':ehgRpUTwClNXmqQEPHfMbvcYBdnWaJ(ehgRpUTwClNXmqQEPHfMbvcYBdnWys.PAGE_LIMIT),'filterRestrictedContent':'false',}
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKs=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.callRequestCookies('Get',ehgRpUTwClNXmqQEPHfMbvcYBdnWKy,payload=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,params=ehgRpUTwClNXmqQEPHfMbvcYBdnWKD,headers=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,cookies=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,redirects=ehgRpUTwClNXmqQEPHfMbvcYBdnWax)
   if ehgRpUTwClNXmqQEPHfMbvcYBdnWKs.status_code not in[200]:return[]
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKx=json.loads(ehgRpUTwClNXmqQEPHfMbvcYBdnWKs.text)
   for ehgRpUTwClNXmqQEPHfMbvcYBdnWKt in ehgRpUTwClNXmqQEPHfMbvcYBdnWKx.get('data'):
    if ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('type')=='Title-Rails-Curation':
     ehgRpUTwClNXmqQEPHfMbvcYBdnWsi =''
     ehgRpUTwClNXmqQEPHfMbvcYBdnWsI=7
     try:
      for i in ehgRpUTwClNXmqQEPHfMbvcYBdnWaA(ehgRpUTwClNXmqQEPHfMbvcYBdnWai(ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('data'))):
       if i>=ehgRpUTwClNXmqQEPHfMbvcYBdnWsI:
        ehgRpUTwClNXmqQEPHfMbvcYBdnWsi=ehgRpUTwClNXmqQEPHfMbvcYBdnWsi+'...'
        break
       ehgRpUTwClNXmqQEPHfMbvcYBdnWsi=ehgRpUTwClNXmqQEPHfMbvcYBdnWsi+ehgRpUTwClNXmqQEPHfMbvcYBdnWKt['data'][i]['title']+'\n'
     except ehgRpUTwClNXmqQEPHfMbvcYBdnWar as exception:
      ehgRpUTwClNXmqQEPHfMbvcYBdnWas(exception)
     ehgRpUTwClNXmqQEPHfMbvcYBdnWKV={'collectionId':ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('obj_id'),'title':ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('row_name'),'category':ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('category'),'page':'1','pre_title':ehgRpUTwClNXmqQEPHfMbvcYBdnWsi,}
     ehgRpUTwClNXmqQEPHfMbvcYBdnWKu.append(ehgRpUTwClNXmqQEPHfMbvcYBdnWKV)
  except ehgRpUTwClNXmqQEPHfMbvcYBdnWar as exception:
   ehgRpUTwClNXmqQEPHfMbvcYBdnWas(exception)
   return[]
  return ehgRpUTwClNXmqQEPHfMbvcYBdnWKu
 def Get_Search_List(ehgRpUTwClNXmqQEPHfMbvcYBdnWys,search_key,page_int):
  ehgRpUTwClNXmqQEPHfMbvcYBdnWKu=[] 
  ehgRpUTwClNXmqQEPHfMbvcYBdnWKG=ehgRpUTwClNXmqQEPHfMbvcYBdnWaK
  try:
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKy=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.API_VIEWURL+'/v2/search' 
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKD={'query':search_key,'platform':'WEBCLIENT','page':ehgRpUTwClNXmqQEPHfMbvcYBdnWaJ(page_int),'perPage':ehgRpUTwClNXmqQEPHfMbvcYBdnWaJ(ehgRpUTwClNXmqQEPHfMbvcYBdnWys.SEARCH_LIMIT),}
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKr={'x-membersrl':ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['member_srl'],'x-pcid':ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['PCID'],'x-profileid':ehgRpUTwClNXmqQEPHfMbvcYBdnWys.CP['SESSION']['profileId'],}
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKs=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.callRequestCookies('Get',ehgRpUTwClNXmqQEPHfMbvcYBdnWKy,payload=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,params=ehgRpUTwClNXmqQEPHfMbvcYBdnWKD,headers=ehgRpUTwClNXmqQEPHfMbvcYBdnWKr,cookies=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,redirects=ehgRpUTwClNXmqQEPHfMbvcYBdnWax)
   if ehgRpUTwClNXmqQEPHfMbvcYBdnWKs.status_code not in[200]:return[],ehgRpUTwClNXmqQEPHfMbvcYBdnWaK
   ehgRpUTwClNXmqQEPHfMbvcYBdnWKx=json.loads(ehgRpUTwClNXmqQEPHfMbvcYBdnWKs.text)
   for ehgRpUTwClNXmqQEPHfMbvcYBdnWKt in ehgRpUTwClNXmqQEPHfMbvcYBdnWKx.get('data').get('data'):
    ehgRpUTwClNXmqQEPHfMbvcYBdnWKt=ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('data')
    ehgRpUTwClNXmqQEPHfMbvcYBdnWsy=ehgRpUTwClNXmqQEPHfMbvcYBdnWsz=ehgRpUTwClNXmqQEPHfMbvcYBdnWst=ehgRpUTwClNXmqQEPHfMbvcYBdnWsk=''
    if 'poster' in ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('images'):ehgRpUTwClNXmqQEPHfMbvcYBdnWsy =ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('images').get('poster').get('url')
    if 'story-art' in ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('images'):ehgRpUTwClNXmqQEPHfMbvcYBdnWsz =ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('images').get('story-art').get('url')
    if 'title-treatment' in ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('images'):ehgRpUTwClNXmqQEPHfMbvcYBdnWst=ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('images').get('title-treatment').get('url')
    if 'story-art' in ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('images'):ehgRpUTwClNXmqQEPHfMbvcYBdnWsk =ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('images').get('story-art').get('url')
    ehgRpUTwClNXmqQEPHfMbvcYBdnWsK=''
    if ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('badge')not in[{},ehgRpUTwClNXmqQEPHfMbvcYBdnWay]:
     for i in ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('badge').get('text'):
      if ehgRpUTwClNXmqQEPHfMbvcYBdnWsK!='':ehgRpUTwClNXmqQEPHfMbvcYBdnWsK+=' '
      ehgRpUTwClNXmqQEPHfMbvcYBdnWsK+=i.get('text')
    ehgRpUTwClNXmqQEPHfMbvcYBdnWKV={'id':ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('id'),'title':ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('title'),'asis':ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('as'),'thumbnail':{'poster':ehgRpUTwClNXmqQEPHfMbvcYBdnWsy,'thumb':ehgRpUTwClNXmqQEPHfMbvcYBdnWsz,'clearlogo':ehgRpUTwClNXmqQEPHfMbvcYBdnWst,'fanart':ehgRpUTwClNXmqQEPHfMbvcYBdnWsk},'mpaa':ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('age_rating'),'duration':ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('running_time'),'badge':ehgRpUTwClNXmqQEPHfMbvcYBdnWsK,'year':ehgRpUTwClNXmqQEPHfMbvcYBdnWKt.get('meta').get('releaseYear'),}
    ehgRpUTwClNXmqQEPHfMbvcYBdnWKu.append(ehgRpUTwClNXmqQEPHfMbvcYBdnWKV)
   if ehgRpUTwClNXmqQEPHfMbvcYBdnWKx.get('pagination').get('totalPages')>page_int:
    ehgRpUTwClNXmqQEPHfMbvcYBdnWKG=ehgRpUTwClNXmqQEPHfMbvcYBdnWax
  except ehgRpUTwClNXmqQEPHfMbvcYBdnWar as exception:
   ehgRpUTwClNXmqQEPHfMbvcYBdnWas(exception)
   return[],ehgRpUTwClNXmqQEPHfMbvcYBdnWaK
  return ehgRpUTwClNXmqQEPHfMbvcYBdnWKu,ehgRpUTwClNXmqQEPHfMbvcYBdnWKG
 def GetBookmarkInfo(ehgRpUTwClNXmqQEPHfMbvcYBdnWys,videoid,vidtype):
  ehgRpUTwClNXmqQEPHfMbvcYBdnWsS={'indexinfo':{'ott':'coupang','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  ehgRpUTwClNXmqQEPHfMbvcYBdnWKy=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.API_VIEWURL+'/v1/discover/titles/'+videoid 
  ehgRpUTwClNXmqQEPHfMbvcYBdnWKD={'locale':'ko'}
  ehgRpUTwClNXmqQEPHfMbvcYBdnWKs=ehgRpUTwClNXmqQEPHfMbvcYBdnWys.callRequestCookies('Get',ehgRpUTwClNXmqQEPHfMbvcYBdnWKy,payload=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,params=ehgRpUTwClNXmqQEPHfMbvcYBdnWKD,headers=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,cookies=ehgRpUTwClNXmqQEPHfMbvcYBdnWay,redirects=ehgRpUTwClNXmqQEPHfMbvcYBdnWax)
  if ehgRpUTwClNXmqQEPHfMbvcYBdnWKs.status_code not in[200]:return{}
  ehgRpUTwClNXmqQEPHfMbvcYBdnWsu=json.loads(ehgRpUTwClNXmqQEPHfMbvcYBdnWKs.text).get('data')
  ehgRpUTwClNXmqQEPHfMbvcYBdnWsD=ehgRpUTwClNXmqQEPHfMbvcYBdnWsu.get('title')
  ehgRpUTwClNXmqQEPHfMbvcYBdnWso =ehgRpUTwClNXmqQEPHfMbvcYBdnWsu.get('meta').get('releaseYear')
  ehgRpUTwClNXmqQEPHfMbvcYBdnWsS['saveinfo']['infoLabels']['title']=ehgRpUTwClNXmqQEPHfMbvcYBdnWsD
  if vidtype=='movie':
   ehgRpUTwClNXmqQEPHfMbvcYBdnWsD='%s  (%s)'%(ehgRpUTwClNXmqQEPHfMbvcYBdnWsD,ehgRpUTwClNXmqQEPHfMbvcYBdnWso)
  ehgRpUTwClNXmqQEPHfMbvcYBdnWsS['saveinfo']['title'] =ehgRpUTwClNXmqQEPHfMbvcYBdnWsD
  ehgRpUTwClNXmqQEPHfMbvcYBdnWsS['saveinfo']['infoLabels']['mpaa'] =ehgRpUTwClNXmqQEPHfMbvcYBdnWsu.get('age_rating')
  ehgRpUTwClNXmqQEPHfMbvcYBdnWsS['saveinfo']['infoLabels']['plot'] ='%s\n\n%s'%(ehgRpUTwClNXmqQEPHfMbvcYBdnWsu.get('short_description'),ehgRpUTwClNXmqQEPHfMbvcYBdnWsu.get('description'))
  ehgRpUTwClNXmqQEPHfMbvcYBdnWsS['saveinfo']['infoLabels']['year'] =ehgRpUTwClNXmqQEPHfMbvcYBdnWso
  if vidtype=='movie':
   ehgRpUTwClNXmqQEPHfMbvcYBdnWsS['saveinfo']['infoLabels']['duration']=ehgRpUTwClNXmqQEPHfMbvcYBdnWsu.get('running_time')
  ehgRpUTwClNXmqQEPHfMbvcYBdnWsy =''
  ehgRpUTwClNXmqQEPHfMbvcYBdnWsk =''
  ehgRpUTwClNXmqQEPHfMbvcYBdnWsz =''
  ehgRpUTwClNXmqQEPHfMbvcYBdnWst=''
  if ehgRpUTwClNXmqQEPHfMbvcYBdnWsu.get('images').get('poster') !=ehgRpUTwClNXmqQEPHfMbvcYBdnWay:ehgRpUTwClNXmqQEPHfMbvcYBdnWsy =ehgRpUTwClNXmqQEPHfMbvcYBdnWsu.get('images').get('poster').get('url')
  if ehgRpUTwClNXmqQEPHfMbvcYBdnWsu.get('images').get('background') !=ehgRpUTwClNXmqQEPHfMbvcYBdnWay:ehgRpUTwClNXmqQEPHfMbvcYBdnWsk =ehgRpUTwClNXmqQEPHfMbvcYBdnWsu.get('images').get('background').get('url')
  if ehgRpUTwClNXmqQEPHfMbvcYBdnWsu.get('images').get('story-art') !=ehgRpUTwClNXmqQEPHfMbvcYBdnWay:ehgRpUTwClNXmqQEPHfMbvcYBdnWsz =ehgRpUTwClNXmqQEPHfMbvcYBdnWsu.get('images').get('story-art').get('url')
  if ehgRpUTwClNXmqQEPHfMbvcYBdnWsu.get('images').get('title-treatment')!=ehgRpUTwClNXmqQEPHfMbvcYBdnWay:ehgRpUTwClNXmqQEPHfMbvcYBdnWst=ehgRpUTwClNXmqQEPHfMbvcYBdnWsu.get('images').get('title-treatment').get('url')
  if ehgRpUTwClNXmqQEPHfMbvcYBdnWsk=='':ehgRpUTwClNXmqQEPHfMbvcYBdnWsk=ehgRpUTwClNXmqQEPHfMbvcYBdnWsz
  ehgRpUTwClNXmqQEPHfMbvcYBdnWsS['saveinfo']['thumbnail']['poster']=ehgRpUTwClNXmqQEPHfMbvcYBdnWsy
  ehgRpUTwClNXmqQEPHfMbvcYBdnWsS['saveinfo']['thumbnail']['fanart']=ehgRpUTwClNXmqQEPHfMbvcYBdnWsk
  ehgRpUTwClNXmqQEPHfMbvcYBdnWsS['saveinfo']['thumbnail']['thumb']=ehgRpUTwClNXmqQEPHfMbvcYBdnWsz
  ehgRpUTwClNXmqQEPHfMbvcYBdnWsS['saveinfo']['thumbnail']['clearlogo']=ehgRpUTwClNXmqQEPHfMbvcYBdnWst
  ehgRpUTwClNXmqQEPHfMbvcYBdnWsj=[]
  for ehgRpUTwClNXmqQEPHfMbvcYBdnWsL in ehgRpUTwClNXmqQEPHfMbvcYBdnWsu.get('tags'):ehgRpUTwClNXmqQEPHfMbvcYBdnWsj.append(ehgRpUTwClNXmqQEPHfMbvcYBdnWsL.get('tag'))
  if ehgRpUTwClNXmqQEPHfMbvcYBdnWai(ehgRpUTwClNXmqQEPHfMbvcYBdnWsj)>0:
   ehgRpUTwClNXmqQEPHfMbvcYBdnWsS['saveinfo']['infoLabels']['genre']=ehgRpUTwClNXmqQEPHfMbvcYBdnWsj
  ehgRpUTwClNXmqQEPHfMbvcYBdnWsV=[]
  ehgRpUTwClNXmqQEPHfMbvcYBdnWsG=[]
  for ehgRpUTwClNXmqQEPHfMbvcYBdnWsL in ehgRpUTwClNXmqQEPHfMbvcYBdnWsu.get('people'):
   if ehgRpUTwClNXmqQEPHfMbvcYBdnWsL.get('role')=='CAST' :ehgRpUTwClNXmqQEPHfMbvcYBdnWsV.append(ehgRpUTwClNXmqQEPHfMbvcYBdnWsL.get('name'))
   if ehgRpUTwClNXmqQEPHfMbvcYBdnWsL.get('role')=='DIRECTOR':ehgRpUTwClNXmqQEPHfMbvcYBdnWsG.append(ehgRpUTwClNXmqQEPHfMbvcYBdnWsL.get('name'))
  if ehgRpUTwClNXmqQEPHfMbvcYBdnWai(ehgRpUTwClNXmqQEPHfMbvcYBdnWsV)>0:
   ehgRpUTwClNXmqQEPHfMbvcYBdnWsS['saveinfo']['infoLabels']['cast'] =ehgRpUTwClNXmqQEPHfMbvcYBdnWsV
  if ehgRpUTwClNXmqQEPHfMbvcYBdnWai(ehgRpUTwClNXmqQEPHfMbvcYBdnWsG)>0:
   ehgRpUTwClNXmqQEPHfMbvcYBdnWsS['saveinfo']['infoLabels']['director']=ehgRpUTwClNXmqQEPHfMbvcYBdnWsG
  return ehgRpUTwClNXmqQEPHfMbvcYBdnWsS
# Created by pyminifier (https://github.com/liftoff/pyminifier)
