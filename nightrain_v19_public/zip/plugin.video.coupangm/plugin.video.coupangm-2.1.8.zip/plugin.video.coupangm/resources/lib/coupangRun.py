__author__="NightRain"
ePrAzmGxltXiEMvqCBpygowWkaNJLh=object
ePrAzmGxltXiEMvqCBpygowWkaNJLI=None
ePrAzmGxltXiEMvqCBpygowWkaNJLV=False
ePrAzmGxltXiEMvqCBpygowWkaNJLj=True
ePrAzmGxltXiEMvqCBpygowWkaNJLT=type
ePrAzmGxltXiEMvqCBpygowWkaNJLn=dict
ePrAzmGxltXiEMvqCBpygowWkaNJLH=getattr
ePrAzmGxltXiEMvqCBpygowWkaNJLU=int
ePrAzmGxltXiEMvqCBpygowWkaNJLd=list
ePrAzmGxltXiEMvqCBpygowWkaNJLR=open
ePrAzmGxltXiEMvqCBpygowWkaNJLs=Exception
ePrAzmGxltXiEMvqCBpygowWkaNJLD=str
ePrAzmGxltXiEMvqCBpygowWkaNJLf=id
ePrAzmGxltXiEMvqCBpygowWkaNJLc=len
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import inputstreamhelper
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
ePrAzmGxltXiEMvqCBpygowWkaNJKh=[{'title':'오직 쿠팡플레이에서','mode':'CATEGORY_LIST','vType':'ORIGINAL','collectionId':'5c33c5ca-ee6f-45f8-a026-dd789a8b63cf'},{'title':'홈   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'ALL'},{'title':'TV   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'MOVIES'},{'title':'키즈 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'KIDS'},{'title':'@ 스포츠','mode':'SPORTS_MAINLIST_LEAGUE'},{'title':'TV   (테마별)','mode':'THEME_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (테마별)','mode':'THEME_GROUPLIST','vType':'MOVIES'},{'title':'키즈 (테마별)','mode':'THEME_GROUPLIST','vType':'KIDS'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},{'title':'(쿠팡) 검색','mode':'LOCAL_SEARCH','icon':'search.png'},{'title':'(쿠팡) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
ePrAzmGxltXiEMvqCBpygowWkaNJKI=[{'title':'시리즈 시청내역','mode':'WATCH','stype':'tvshow'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},]
ePrAzmGxltXiEMvqCBpygowWkaNJKV={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
ePrAzmGxltXiEMvqCBpygowWkaNJKj=xbmcvfs.translatePath(os.path.join(__profile__,'coupang_searched.txt'))
from coupangCore import*
class ePrAzmGxltXiEMvqCBpygowWkaNJKS(ePrAzmGxltXiEMvqCBpygowWkaNJLh):
 def __init__(ePrAzmGxltXiEMvqCBpygowWkaNJKT,ePrAzmGxltXiEMvqCBpygowWkaNJKL,ePrAzmGxltXiEMvqCBpygowWkaNJKn,ePrAzmGxltXiEMvqCBpygowWkaNJKH):
  ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_url =ePrAzmGxltXiEMvqCBpygowWkaNJKL
  ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle=ePrAzmGxltXiEMvqCBpygowWkaNJKn
  ePrAzmGxltXiEMvqCBpygowWkaNJKT.main_params =ePrAzmGxltXiEMvqCBpygowWkaNJKH
  ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj =LEwTuRWoKVFbrBfInQYNXDsPOHkhgz() 
  ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.CP_COOKIE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_cookies.json'))
  ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.CP_DEVICE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_device.json'))
 def addon_noti(ePrAzmGxltXiEMvqCBpygowWkaNJKT,sting):
  try:
   ePrAzmGxltXiEMvqCBpygowWkaNJKd=xbmcgui.Dialog()
   ePrAzmGxltXiEMvqCBpygowWkaNJKd.notification(__addonname__,sting)
  except:
   ePrAzmGxltXiEMvqCBpygowWkaNJLI
 def addon_log(ePrAzmGxltXiEMvqCBpygowWkaNJKT,string):
  try:
   ePrAzmGxltXiEMvqCBpygowWkaNJKR=string.encode('utf-8','ignore')
  except:
   ePrAzmGxltXiEMvqCBpygowWkaNJKR='addonException: addon_log'
  ePrAzmGxltXiEMvqCBpygowWkaNJKs=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,ePrAzmGxltXiEMvqCBpygowWkaNJKR),level=ePrAzmGxltXiEMvqCBpygowWkaNJKs)
 def get_keyboard_input(ePrAzmGxltXiEMvqCBpygowWkaNJKT,ePrAzmGxltXiEMvqCBpygowWkaNJSI):
  ePrAzmGxltXiEMvqCBpygowWkaNJKD=ePrAzmGxltXiEMvqCBpygowWkaNJLI
  kb=xbmc.Keyboard()
  kb.setHeading(ePrAzmGxltXiEMvqCBpygowWkaNJSI)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   ePrAzmGxltXiEMvqCBpygowWkaNJKD=kb.getText()
  return ePrAzmGxltXiEMvqCBpygowWkaNJKD
 def get_settings_account(ePrAzmGxltXiEMvqCBpygowWkaNJKT):
  ePrAzmGxltXiEMvqCBpygowWkaNJKf=__addon__.getSetting('id')
  ePrAzmGxltXiEMvqCBpygowWkaNJKc=__addon__.getSetting('pw')
  ePrAzmGxltXiEMvqCBpygowWkaNJKF=__addon__.getSetting('profile')
  return(ePrAzmGxltXiEMvqCBpygowWkaNJKf,ePrAzmGxltXiEMvqCBpygowWkaNJKc,ePrAzmGxltXiEMvqCBpygowWkaNJKF)
 def get_settings_exclusion21(ePrAzmGxltXiEMvqCBpygowWkaNJKT):
  ePrAzmGxltXiEMvqCBpygowWkaNJKO =__addon__.getSetting('exclusion21')
  if ePrAzmGxltXiEMvqCBpygowWkaNJKO=='false':
   return ePrAzmGxltXiEMvqCBpygowWkaNJLV
  else:
   return ePrAzmGxltXiEMvqCBpygowWkaNJLj
 def get_settings_totalsearch(ePrAzmGxltXiEMvqCBpygowWkaNJKT):
  ePrAzmGxltXiEMvqCBpygowWkaNJKQ =ePrAzmGxltXiEMvqCBpygowWkaNJLj if __addon__.getSetting('local_search')=='true' else ePrAzmGxltXiEMvqCBpygowWkaNJLV
  ePrAzmGxltXiEMvqCBpygowWkaNJKY=ePrAzmGxltXiEMvqCBpygowWkaNJLj if __addon__.getSetting('local_history')=='true' else ePrAzmGxltXiEMvqCBpygowWkaNJLV
  ePrAzmGxltXiEMvqCBpygowWkaNJKb =ePrAzmGxltXiEMvqCBpygowWkaNJLj if __addon__.getSetting('total_search')=='true' else ePrAzmGxltXiEMvqCBpygowWkaNJLV
  ePrAzmGxltXiEMvqCBpygowWkaNJKu=ePrAzmGxltXiEMvqCBpygowWkaNJLj if __addon__.getSetting('total_history')=='true' else ePrAzmGxltXiEMvqCBpygowWkaNJLV
  ePrAzmGxltXiEMvqCBpygowWkaNJSK=ePrAzmGxltXiEMvqCBpygowWkaNJLj if __addon__.getSetting('menu_bookmark')=='true' else ePrAzmGxltXiEMvqCBpygowWkaNJLV
  return(ePrAzmGxltXiEMvqCBpygowWkaNJKQ,ePrAzmGxltXiEMvqCBpygowWkaNJKY,ePrAzmGxltXiEMvqCBpygowWkaNJKb,ePrAzmGxltXiEMvqCBpygowWkaNJKu,ePrAzmGxltXiEMvqCBpygowWkaNJSK)
 def get_settings_makebookmark(ePrAzmGxltXiEMvqCBpygowWkaNJKT):
  return ePrAzmGxltXiEMvqCBpygowWkaNJLj if __addon__.getSetting('make_bookmark')=='true' else ePrAzmGxltXiEMvqCBpygowWkaNJLV
 def add_dir(ePrAzmGxltXiEMvqCBpygowWkaNJKT,label,sublabel='',img='',infoLabels=ePrAzmGxltXiEMvqCBpygowWkaNJLI,isFolder=ePrAzmGxltXiEMvqCBpygowWkaNJLj,params='',isLink=ePrAzmGxltXiEMvqCBpygowWkaNJLV,ContextMenu=ePrAzmGxltXiEMvqCBpygowWkaNJLI):
  ePrAzmGxltXiEMvqCBpygowWkaNJSh='%s?%s'%(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_url,urllib.parse.urlencode(params))
  if sublabel:ePrAzmGxltXiEMvqCBpygowWkaNJSI='%s < %s >'%(label,sublabel)
  else: ePrAzmGxltXiEMvqCBpygowWkaNJSI=label
  if not img:img='DefaultFolder.png'
  ePrAzmGxltXiEMvqCBpygowWkaNJSV=xbmcgui.ListItem(ePrAzmGxltXiEMvqCBpygowWkaNJSI)
  if ePrAzmGxltXiEMvqCBpygowWkaNJLT(img)==ePrAzmGxltXiEMvqCBpygowWkaNJLn:
   ePrAzmGxltXiEMvqCBpygowWkaNJSV.setArt(img)
  else:
   ePrAzmGxltXiEMvqCBpygowWkaNJSV.setArt({'thumb':img,'poster':img})
  if ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.KodiVersion>=20:
   if infoLabels:ePrAzmGxltXiEMvqCBpygowWkaNJKT.Set_InfoTag(ePrAzmGxltXiEMvqCBpygowWkaNJSV.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:ePrAzmGxltXiEMvqCBpygowWkaNJSV.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   ePrAzmGxltXiEMvqCBpygowWkaNJSV.setProperty('IsPlayable','true')
  if ContextMenu:ePrAzmGxltXiEMvqCBpygowWkaNJSV.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,ePrAzmGxltXiEMvqCBpygowWkaNJSh,ePrAzmGxltXiEMvqCBpygowWkaNJSV,isFolder)
 def Set_InfoTag(ePrAzmGxltXiEMvqCBpygowWkaNJKT,video_InfoTag:xbmc.InfoTagVideo,ePrAzmGxltXiEMvqCBpygowWkaNJSR):
  for ePrAzmGxltXiEMvqCBpygowWkaNJSj,value in ePrAzmGxltXiEMvqCBpygowWkaNJSR.items():
   if ePrAzmGxltXiEMvqCBpygowWkaNJKV[ePrAzmGxltXiEMvqCBpygowWkaNJSj]['type']=='string':
    ePrAzmGxltXiEMvqCBpygowWkaNJLH(video_InfoTag,ePrAzmGxltXiEMvqCBpygowWkaNJKV[ePrAzmGxltXiEMvqCBpygowWkaNJSj]['func'])(value)
   elif ePrAzmGxltXiEMvqCBpygowWkaNJKV[ePrAzmGxltXiEMvqCBpygowWkaNJSj]['type']=='int':
    if ePrAzmGxltXiEMvqCBpygowWkaNJLT(value)==ePrAzmGxltXiEMvqCBpygowWkaNJLU:
     ePrAzmGxltXiEMvqCBpygowWkaNJST=ePrAzmGxltXiEMvqCBpygowWkaNJLU(value)
    else:
     ePrAzmGxltXiEMvqCBpygowWkaNJST=0
    ePrAzmGxltXiEMvqCBpygowWkaNJLH(video_InfoTag,ePrAzmGxltXiEMvqCBpygowWkaNJKV[ePrAzmGxltXiEMvqCBpygowWkaNJSj]['func'])(ePrAzmGxltXiEMvqCBpygowWkaNJST)
   elif ePrAzmGxltXiEMvqCBpygowWkaNJKV[ePrAzmGxltXiEMvqCBpygowWkaNJSj]['type']=='actor':
    if value!=[]:
     ePrAzmGxltXiEMvqCBpygowWkaNJLH(video_InfoTag,ePrAzmGxltXiEMvqCBpygowWkaNJKV[ePrAzmGxltXiEMvqCBpygowWkaNJSj]['func'])([xbmc.Actor(name)for name in value])
   elif ePrAzmGxltXiEMvqCBpygowWkaNJKV[ePrAzmGxltXiEMvqCBpygowWkaNJSj]['type']=='list':
    if ePrAzmGxltXiEMvqCBpygowWkaNJLT(value)==ePrAzmGxltXiEMvqCBpygowWkaNJLd:
     ePrAzmGxltXiEMvqCBpygowWkaNJLH(video_InfoTag,ePrAzmGxltXiEMvqCBpygowWkaNJKV[ePrAzmGxltXiEMvqCBpygowWkaNJSj]['func'])(value)
    else:
     ePrAzmGxltXiEMvqCBpygowWkaNJLH(video_InfoTag,ePrAzmGxltXiEMvqCBpygowWkaNJKV[ePrAzmGxltXiEMvqCBpygowWkaNJSj]['func'])([value])
 def dp_Main_List(ePrAzmGxltXiEMvqCBpygowWkaNJKT,args):
  (ePrAzmGxltXiEMvqCBpygowWkaNJKQ,ePrAzmGxltXiEMvqCBpygowWkaNJKY,ePrAzmGxltXiEMvqCBpygowWkaNJKb,ePrAzmGxltXiEMvqCBpygowWkaNJKu,ePrAzmGxltXiEMvqCBpygowWkaNJSK)=ePrAzmGxltXiEMvqCBpygowWkaNJKT.get_settings_totalsearch()
  for ePrAzmGxltXiEMvqCBpygowWkaNJSL in ePrAzmGxltXiEMvqCBpygowWkaNJKh:
   ePrAzmGxltXiEMvqCBpygowWkaNJSI=ePrAzmGxltXiEMvqCBpygowWkaNJSL.get('title')
   ePrAzmGxltXiEMvqCBpygowWkaNJSn=''
   if ePrAzmGxltXiEMvqCBpygowWkaNJSL.get('mode')=='LOCAL_SEARCH' and ePrAzmGxltXiEMvqCBpygowWkaNJKQ ==ePrAzmGxltXiEMvqCBpygowWkaNJLV:continue
   elif ePrAzmGxltXiEMvqCBpygowWkaNJSL.get('mode')=='SEARCH_HISTORY' and ePrAzmGxltXiEMvqCBpygowWkaNJKY==ePrAzmGxltXiEMvqCBpygowWkaNJLV:continue
   elif ePrAzmGxltXiEMvqCBpygowWkaNJSL.get('mode')=='TOTAL_SEARCH' and ePrAzmGxltXiEMvqCBpygowWkaNJKb ==ePrAzmGxltXiEMvqCBpygowWkaNJLV:continue
   elif ePrAzmGxltXiEMvqCBpygowWkaNJSL.get('mode')=='TOTAL_HISTORY' and ePrAzmGxltXiEMvqCBpygowWkaNJKu==ePrAzmGxltXiEMvqCBpygowWkaNJLV:continue
   elif ePrAzmGxltXiEMvqCBpygowWkaNJSL.get('mode')=='MENU_BOOKMARK' and ePrAzmGxltXiEMvqCBpygowWkaNJSK==ePrAzmGxltXiEMvqCBpygowWkaNJLV:continue
   ePrAzmGxltXiEMvqCBpygowWkaNJSH={'mode':ePrAzmGxltXiEMvqCBpygowWkaNJSL.get('mode'),'vType':ePrAzmGxltXiEMvqCBpygowWkaNJSL.get('vType'),'collectionId':ePrAzmGxltXiEMvqCBpygowWkaNJSL.get('collectionId'),'page':'1',}
   if ePrAzmGxltXiEMvqCBpygowWkaNJSL.get('mode')=='LOCAL_SEARCH':ePrAzmGxltXiEMvqCBpygowWkaNJSH['historyyn']='Y' 
   if ePrAzmGxltXiEMvqCBpygowWkaNJSL.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    ePrAzmGxltXiEMvqCBpygowWkaNJSU=ePrAzmGxltXiEMvqCBpygowWkaNJLV
    ePrAzmGxltXiEMvqCBpygowWkaNJSd =ePrAzmGxltXiEMvqCBpygowWkaNJLj
   else:
    ePrAzmGxltXiEMvqCBpygowWkaNJSU=ePrAzmGxltXiEMvqCBpygowWkaNJLj
    ePrAzmGxltXiEMvqCBpygowWkaNJSd =ePrAzmGxltXiEMvqCBpygowWkaNJLV
   ePrAzmGxltXiEMvqCBpygowWkaNJSR={'title':ePrAzmGxltXiEMvqCBpygowWkaNJSI,'plot':ePrAzmGxltXiEMvqCBpygowWkaNJSI}
   if ePrAzmGxltXiEMvqCBpygowWkaNJSL.get('mode')=='XXX':ePrAzmGxltXiEMvqCBpygowWkaNJSR=ePrAzmGxltXiEMvqCBpygowWkaNJLI
   if 'icon' in ePrAzmGxltXiEMvqCBpygowWkaNJSL:ePrAzmGxltXiEMvqCBpygowWkaNJSn=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',ePrAzmGxltXiEMvqCBpygowWkaNJSL.get('icon')) 
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.add_dir(ePrAzmGxltXiEMvqCBpygowWkaNJSI,sublabel='',img=ePrAzmGxltXiEMvqCBpygowWkaNJSn,infoLabels=ePrAzmGxltXiEMvqCBpygowWkaNJSR,isFolder=ePrAzmGxltXiEMvqCBpygowWkaNJSU,params=ePrAzmGxltXiEMvqCBpygowWkaNJSH,isLink=ePrAzmGxltXiEMvqCBpygowWkaNJSd)
  xbmcplugin.endOfDirectory(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle)
 def dp_Test(ePrAzmGxltXiEMvqCBpygowWkaNJKT,args):
  ePrAzmGxltXiEMvqCBpygowWkaNJKT.addon_noti('test')
 def CP_logout(ePrAzmGxltXiEMvqCBpygowWkaNJKT):
  ePrAzmGxltXiEMvqCBpygowWkaNJKd=xbmcgui.Dialog()
  ePrAzmGxltXiEMvqCBpygowWkaNJSD=ePrAzmGxltXiEMvqCBpygowWkaNJKd.yesno(__language__(30905).encode('utf8'),__language__(30906).encode('utf8'))
  if ePrAzmGxltXiEMvqCBpygowWkaNJSD==ePrAzmGxltXiEMvqCBpygowWkaNJLV:return 
  if os.path.isfile(ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.CP_COOKIE_FILENAME):os.remove(ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.CP_COOKIE_FILENAME)
  ePrAzmGxltXiEMvqCBpygowWkaNJKT.addon_noti(__language__(30904).encode('utf-8'))
 def option_check(ePrAzmGxltXiEMvqCBpygowWkaNJKT):
  (ePrAzmGxltXiEMvqCBpygowWkaNJKf,ePrAzmGxltXiEMvqCBpygowWkaNJKc,ePrAzmGxltXiEMvqCBpygowWkaNJKF)=ePrAzmGxltXiEMvqCBpygowWkaNJKT.get_settings_account()
  if ePrAzmGxltXiEMvqCBpygowWkaNJKf=='' or ePrAzmGxltXiEMvqCBpygowWkaNJKc=='':
   ePrAzmGxltXiEMvqCBpygowWkaNJKd=xbmcgui.Dialog()
   ePrAzmGxltXiEMvqCBpygowWkaNJSD=ePrAzmGxltXiEMvqCBpygowWkaNJKd.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if ePrAzmGxltXiEMvqCBpygowWkaNJSD==ePrAzmGxltXiEMvqCBpygowWkaNJLj:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if ePrAzmGxltXiEMvqCBpygowWkaNJKT.cookiefile_check()==ePrAzmGxltXiEMvqCBpygowWkaNJLV:
   if ePrAzmGxltXiEMvqCBpygowWkaNJKT.CP_login(ePrAzmGxltXiEMvqCBpygowWkaNJKf,ePrAzmGxltXiEMvqCBpygowWkaNJKc,ePrAzmGxltXiEMvqCBpygowWkaNJKF)==ePrAzmGxltXiEMvqCBpygowWkaNJLV:
    ePrAzmGxltXiEMvqCBpygowWkaNJKT.addon_noti(__language__(30903).encode('utf8'))
    sys.exit()
  else:
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.Get_CP_profile(ePrAzmGxltXiEMvqCBpygowWkaNJKF,limit_days=ePrAzmGxltXiEMvqCBpygowWkaNJLU(__addon__.getSetting('cache_ttl')),re_check=ePrAzmGxltXiEMvqCBpygowWkaNJLj)
 def cookiefile_check(ePrAzmGxltXiEMvqCBpygowWkaNJKT):
  ePrAzmGxltXiEMvqCBpygowWkaNJSc={}
  try: 
   fp=ePrAzmGxltXiEMvqCBpygowWkaNJLR(ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.CP_COOKIE_FILENAME,'r',-1,'utf-8')
   ePrAzmGxltXiEMvqCBpygowWkaNJSc= json.load(fp)
   fp.close()
  except ePrAzmGxltXiEMvqCBpygowWkaNJLs as exception:
   return ePrAzmGxltXiEMvqCBpygowWkaNJLV
  ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.CP=ePrAzmGxltXiEMvqCBpygowWkaNJSc
  (ePrAzmGxltXiEMvqCBpygowWkaNJKf,ePrAzmGxltXiEMvqCBpygowWkaNJKc,ePrAzmGxltXiEMvqCBpygowWkaNJKF)=ePrAzmGxltXiEMvqCBpygowWkaNJKT.get_settings_account()
  (ePrAzmGxltXiEMvqCBpygowWkaNJSF,ePrAzmGxltXiEMvqCBpygowWkaNJSO,ePrAzmGxltXiEMvqCBpygowWkaNJSQ)=ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.Load_session_acount()
  if ePrAzmGxltXiEMvqCBpygowWkaNJKf!=ePrAzmGxltXiEMvqCBpygowWkaNJSF or ePrAzmGxltXiEMvqCBpygowWkaNJKc!=ePrAzmGxltXiEMvqCBpygowWkaNJSO or ePrAzmGxltXiEMvqCBpygowWkaNJKF!=ePrAzmGxltXiEMvqCBpygowWkaNJLD(ePrAzmGxltXiEMvqCBpygowWkaNJSQ):
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.Init_CP()
   return ePrAzmGxltXiEMvqCBpygowWkaNJLV
  ePrAzmGxltXiEMvqCBpygowWkaNJSY =ePrAzmGxltXiEMvqCBpygowWkaNJLU(ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.Get_Now_Datetime().strftime('%Y%m%d'))
  ePrAzmGxltXiEMvqCBpygowWkaNJSb=ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.CP['SESSION']['limitdate']
  ePrAzmGxltXiEMvqCBpygowWkaNJSu =ePrAzmGxltXiEMvqCBpygowWkaNJLU(re.sub('-','',ePrAzmGxltXiEMvqCBpygowWkaNJSb))
  if ePrAzmGxltXiEMvqCBpygowWkaNJSu<ePrAzmGxltXiEMvqCBpygowWkaNJSY:
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.Init_CP()
   return ePrAzmGxltXiEMvqCBpygowWkaNJLV
  return ePrAzmGxltXiEMvqCBpygowWkaNJLj
 def CP_login(ePrAzmGxltXiEMvqCBpygowWkaNJKT,ePrAzmGxltXiEMvqCBpygowWkaNJKf,ePrAzmGxltXiEMvqCBpygowWkaNJKc,ePrAzmGxltXiEMvqCBpygowWkaNJKF):
  if ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.Get_CP_Login(ePrAzmGxltXiEMvqCBpygowWkaNJKf,ePrAzmGxltXiEMvqCBpygowWkaNJKc,ePrAzmGxltXiEMvqCBpygowWkaNJKF)==ePrAzmGxltXiEMvqCBpygowWkaNJLV:return ePrAzmGxltXiEMvqCBpygowWkaNJLV
  if ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.Get_CP_profile(ePrAzmGxltXiEMvqCBpygowWkaNJKF,limit_days=ePrAzmGxltXiEMvqCBpygowWkaNJLU(__addon__.getSetting('cache_ttl')),re_check=ePrAzmGxltXiEMvqCBpygowWkaNJLV)==ePrAzmGxltXiEMvqCBpygowWkaNJLV:return ePrAzmGxltXiEMvqCBpygowWkaNJLV
  return ePrAzmGxltXiEMvqCBpygowWkaNJLj
 def dp_Category_GroupList(ePrAzmGxltXiEMvqCBpygowWkaNJKT,args):
  ePrAzmGxltXiEMvqCBpygowWkaNJhK =args.get('vType') 
  ePrAzmGxltXiEMvqCBpygowWkaNJhS=ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.Get_Category_GroupList(ePrAzmGxltXiEMvqCBpygowWkaNJhK)
  for ePrAzmGxltXiEMvqCBpygowWkaNJhI in ePrAzmGxltXiEMvqCBpygowWkaNJhS:
   ePrAzmGxltXiEMvqCBpygowWkaNJSI =ePrAzmGxltXiEMvqCBpygowWkaNJhI.get('title')
   ePrAzmGxltXiEMvqCBpygowWkaNJhV=ePrAzmGxltXiEMvqCBpygowWkaNJhI.get('pre_title')
   if ePrAzmGxltXiEMvqCBpygowWkaNJKT.get_settings_exclusion21()==ePrAzmGxltXiEMvqCBpygowWkaNJLj and ePrAzmGxltXiEMvqCBpygowWkaNJSI=='성인':continue
   ePrAzmGxltXiEMvqCBpygowWkaNJhj={'mediatype':'tvshow','plot':ePrAzmGxltXiEMvqCBpygowWkaNJhV,}
   ePrAzmGxltXiEMvqCBpygowWkaNJSH={'mode':'CATEGORY_LIST','collectionId':ePrAzmGxltXiEMvqCBpygowWkaNJhI.get('collectionId'),'vType':ePrAzmGxltXiEMvqCBpygowWkaNJhI.get('category'),'page':'1',}
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.add_dir(ePrAzmGxltXiEMvqCBpygowWkaNJSI,sublabel='',img='',infoLabels=ePrAzmGxltXiEMvqCBpygowWkaNJhj,isFolder=ePrAzmGxltXiEMvqCBpygowWkaNJLj,params=ePrAzmGxltXiEMvqCBpygowWkaNJSH)
  xbmcplugin.endOfDirectory(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,cacheToDisc=ePrAzmGxltXiEMvqCBpygowWkaNJLV)
 def dp_Theme_GroupList(ePrAzmGxltXiEMvqCBpygowWkaNJKT,args):
  ePrAzmGxltXiEMvqCBpygowWkaNJhK =args.get('vType') 
  ePrAzmGxltXiEMvqCBpygowWkaNJhS=ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.Get_Theme_GroupList(ePrAzmGxltXiEMvqCBpygowWkaNJhK)
  for ePrAzmGxltXiEMvqCBpygowWkaNJhI in ePrAzmGxltXiEMvqCBpygowWkaNJhS:
   ePrAzmGxltXiEMvqCBpygowWkaNJSI =ePrAzmGxltXiEMvqCBpygowWkaNJhI.get('title')
   ePrAzmGxltXiEMvqCBpygowWkaNJhV=ePrAzmGxltXiEMvqCBpygowWkaNJhI.get('pre_title')
   ePrAzmGxltXiEMvqCBpygowWkaNJhj={'mediatype':'tvshow','plot':ePrAzmGxltXiEMvqCBpygowWkaNJhV,}
   ePrAzmGxltXiEMvqCBpygowWkaNJSH={'mode':'CATEGORY_LIST','collectionId':ePrAzmGxltXiEMvqCBpygowWkaNJhI.get('collectionId'),'vType':ePrAzmGxltXiEMvqCBpygowWkaNJhI.get('category'),'page':'1',}
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.add_dir(ePrAzmGxltXiEMvqCBpygowWkaNJSI,sublabel='',img='',infoLabels=ePrAzmGxltXiEMvqCBpygowWkaNJhj,isFolder=ePrAzmGxltXiEMvqCBpygowWkaNJLj,params=ePrAzmGxltXiEMvqCBpygowWkaNJSH)
  xbmcplugin.endOfDirectory(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,cacheToDisc=ePrAzmGxltXiEMvqCBpygowWkaNJLV)
 def dp_Event_GroupList(ePrAzmGxltXiEMvqCBpygowWkaNJKT,args):
  ePrAzmGxltXiEMvqCBpygowWkaNJhS=ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.Get_Event_GroupList()
  for ePrAzmGxltXiEMvqCBpygowWkaNJhI in ePrAzmGxltXiEMvqCBpygowWkaNJhS:
   ePrAzmGxltXiEMvqCBpygowWkaNJSI =ePrAzmGxltXiEMvqCBpygowWkaNJhI.get('title')
   ePrAzmGxltXiEMvqCBpygowWkaNJhV=ePrAzmGxltXiEMvqCBpygowWkaNJhI.get('pre_title')
   ePrAzmGxltXiEMvqCBpygowWkaNJhj={'mediatype':'tvshow','plot':ePrAzmGxltXiEMvqCBpygowWkaNJhV,}
   ePrAzmGxltXiEMvqCBpygowWkaNJSH={'mode':'EVENT_GAMELIST','collectionId':ePrAzmGxltXiEMvqCBpygowWkaNJhI.get('collectionId'),'vType':'LIVE',}
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.add_dir(ePrAzmGxltXiEMvqCBpygowWkaNJSI,sublabel='',img='',infoLabels=ePrAzmGxltXiEMvqCBpygowWkaNJhj,isFolder=ePrAzmGxltXiEMvqCBpygowWkaNJLj,params=ePrAzmGxltXiEMvqCBpygowWkaNJSH)
  xbmcplugin.endOfDirectory(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,cacheToDisc=ePrAzmGxltXiEMvqCBpygowWkaNJLV)
 def dp_Event_GameList(ePrAzmGxltXiEMvqCBpygowWkaNJKT,args):
  ePrAzmGxltXiEMvqCBpygowWkaNJhK =args.get('vType') 
  ePrAzmGxltXiEMvqCBpygowWkaNJhL =args.get('collectionId')
  ePrAzmGxltXiEMvqCBpygowWkaNJhS=ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.Get_Event_GameList(ePrAzmGxltXiEMvqCBpygowWkaNJhL)
  for ePrAzmGxltXiEMvqCBpygowWkaNJhI in ePrAzmGxltXiEMvqCBpygowWkaNJhS:
   ePrAzmGxltXiEMvqCBpygowWkaNJSI =ePrAzmGxltXiEMvqCBpygowWkaNJhI.get('title')
   ePrAzmGxltXiEMvqCBpygowWkaNJLf =ePrAzmGxltXiEMvqCBpygowWkaNJhI.get('id')
   ePrAzmGxltXiEMvqCBpygowWkaNJhn =ePrAzmGxltXiEMvqCBpygowWkaNJhI.get('thumbnail')
   ePrAzmGxltXiEMvqCBpygowWkaNJhH =ePrAzmGxltXiEMvqCBpygowWkaNJhI.get('asis') 
   ePrAzmGxltXiEMvqCBpygowWkaNJhU =ePrAzmGxltXiEMvqCBpygowWkaNJhI.get('addInfo')
   ePrAzmGxltXiEMvqCBpygowWkaNJhd =ePrAzmGxltXiEMvqCBpygowWkaNJhI.get('starttm')
   ePrAzmGxltXiEMvqCBpygowWkaNJhj={'mediatype':'tvshow','title':ePrAzmGxltXiEMvqCBpygowWkaNJSI,'plot':ePrAzmGxltXiEMvqCBpygowWkaNJhU,}
   ePrAzmGxltXiEMvqCBpygowWkaNJSH={'mode':'EVENT_LIST','id':ePrAzmGxltXiEMvqCBpygowWkaNJLf,'asis':ePrAzmGxltXiEMvqCBpygowWkaNJhH,'title':ePrAzmGxltXiEMvqCBpygowWkaNJSI,}
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.add_dir(ePrAzmGxltXiEMvqCBpygowWkaNJSI,sublabel=ePrAzmGxltXiEMvqCBpygowWkaNJhd,img=ePrAzmGxltXiEMvqCBpygowWkaNJhn,infoLabels=ePrAzmGxltXiEMvqCBpygowWkaNJhj,isFolder=ePrAzmGxltXiEMvqCBpygowWkaNJLj,params=ePrAzmGxltXiEMvqCBpygowWkaNJSH,ContextMenu=ePrAzmGxltXiEMvqCBpygowWkaNJLI)
  xbmcplugin.setContent(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,cacheToDisc=ePrAzmGxltXiEMvqCBpygowWkaNJLV)
 def dp_Event_List(ePrAzmGxltXiEMvqCBpygowWkaNJKT,args):
  ePrAzmGxltXiEMvqCBpygowWkaNJhR=args.get('id')
  ePrAzmGxltXiEMvqCBpygowWkaNJhS=ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.Get_Event_List(ePrAzmGxltXiEMvqCBpygowWkaNJhR)
  for ePrAzmGxltXiEMvqCBpygowWkaNJhI in ePrAzmGxltXiEMvqCBpygowWkaNJhS:
   ePrAzmGxltXiEMvqCBpygowWkaNJSI =ePrAzmGxltXiEMvqCBpygowWkaNJhI.get('title')
   ePrAzmGxltXiEMvqCBpygowWkaNJLf =ePrAzmGxltXiEMvqCBpygowWkaNJhI.get('id')
   ePrAzmGxltXiEMvqCBpygowWkaNJhn =ePrAzmGxltXiEMvqCBpygowWkaNJhI.get('thumbnail')
   ePrAzmGxltXiEMvqCBpygowWkaNJhH =ePrAzmGxltXiEMvqCBpygowWkaNJhI.get('asis') 
   ePrAzmGxltXiEMvqCBpygowWkaNJhs =ePrAzmGxltXiEMvqCBpygowWkaNJhI.get('duration')
   ePrAzmGxltXiEMvqCBpygowWkaNJhd =ePrAzmGxltXiEMvqCBpygowWkaNJhI.get('starttm')
   ePrAzmGxltXiEMvqCBpygowWkaNJhj={'mediatype':'episode','title':ePrAzmGxltXiEMvqCBpygowWkaNJSI,'plot':ePrAzmGxltXiEMvqCBpygowWkaNJhH,'duration':ePrAzmGxltXiEMvqCBpygowWkaNJhs,}
   ePrAzmGxltXiEMvqCBpygowWkaNJSH={'mode':ePrAzmGxltXiEMvqCBpygowWkaNJhH,'id':ePrAzmGxltXiEMvqCBpygowWkaNJLf,'asis':ePrAzmGxltXiEMvqCBpygowWkaNJhH,'title':ePrAzmGxltXiEMvqCBpygowWkaNJSI,}
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.add_dir(ePrAzmGxltXiEMvqCBpygowWkaNJSI,sublabel=ePrAzmGxltXiEMvqCBpygowWkaNJhd,img=ePrAzmGxltXiEMvqCBpygowWkaNJhn,infoLabels=ePrAzmGxltXiEMvqCBpygowWkaNJhj,isFolder=ePrAzmGxltXiEMvqCBpygowWkaNJLV,params=ePrAzmGxltXiEMvqCBpygowWkaNJSH,ContextMenu=ePrAzmGxltXiEMvqCBpygowWkaNJLI)
  xbmcplugin.setContent(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,cacheToDisc=ePrAzmGxltXiEMvqCBpygowWkaNJLV)
 def dp_Category_List(ePrAzmGxltXiEMvqCBpygowWkaNJKT,args):
  ePrAzmGxltXiEMvqCBpygowWkaNJhK =args.get('vType') 
  ePrAzmGxltXiEMvqCBpygowWkaNJhL =args.get('collectionId')
  ePrAzmGxltXiEMvqCBpygowWkaNJhD =ePrAzmGxltXiEMvqCBpygowWkaNJLU(args.get('page'))
  ePrAzmGxltXiEMvqCBpygowWkaNJhS,ePrAzmGxltXiEMvqCBpygowWkaNJhf=ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.Get_Category_List(ePrAzmGxltXiEMvqCBpygowWkaNJhK,ePrAzmGxltXiEMvqCBpygowWkaNJhL,ePrAzmGxltXiEMvqCBpygowWkaNJhD)
  for ePrAzmGxltXiEMvqCBpygowWkaNJhI in ePrAzmGxltXiEMvqCBpygowWkaNJhS:
   ePrAzmGxltXiEMvqCBpygowWkaNJSI =ePrAzmGxltXiEMvqCBpygowWkaNJhI.get('title')
   ePrAzmGxltXiEMvqCBpygowWkaNJLf =ePrAzmGxltXiEMvqCBpygowWkaNJhI.get('id')
   ePrAzmGxltXiEMvqCBpygowWkaNJhn =ePrAzmGxltXiEMvqCBpygowWkaNJhI.get('thumbnail')
   ePrAzmGxltXiEMvqCBpygowWkaNJhc =ePrAzmGxltXiEMvqCBpygowWkaNJhI.get('mpaa')
   ePrAzmGxltXiEMvqCBpygowWkaNJhs =ePrAzmGxltXiEMvqCBpygowWkaNJhI.get('duration')
   ePrAzmGxltXiEMvqCBpygowWkaNJhH =ePrAzmGxltXiEMvqCBpygowWkaNJhI.get('asis')
   ePrAzmGxltXiEMvqCBpygowWkaNJhF =ePrAzmGxltXiEMvqCBpygowWkaNJhI.get('badge')
   ePrAzmGxltXiEMvqCBpygowWkaNJhO =ePrAzmGxltXiEMvqCBpygowWkaNJhI.get('year')
   ePrAzmGxltXiEMvqCBpygowWkaNJhQ=ePrAzmGxltXiEMvqCBpygowWkaNJhI.get('seasonList')
   ePrAzmGxltXiEMvqCBpygowWkaNJhY =ePrAzmGxltXiEMvqCBpygowWkaNJhI.get('genreList')
   if ePrAzmGxltXiEMvqCBpygowWkaNJhH in['TVSHOW','EDUCATION']: 
    ePrAzmGxltXiEMvqCBpygowWkaNJhb ='SEASON_LIST'
    ePrAzmGxltXiEMvqCBpygowWkaNJhj={'mediatype':'tvshow','title':ePrAzmGxltXiEMvqCBpygowWkaNJSI,'mpaa':ePrAzmGxltXiEMvqCBpygowWkaNJhc,'genre':ePrAzmGxltXiEMvqCBpygowWkaNJhY,'year':ePrAzmGxltXiEMvqCBpygowWkaNJhO,'plot':'Year : %s\nSeason : %s'%(ePrAzmGxltXiEMvqCBpygowWkaNJhO,ePrAzmGxltXiEMvqCBpygowWkaNJhQ),}
    ePrAzmGxltXiEMvqCBpygowWkaNJSU =ePrAzmGxltXiEMvqCBpygowWkaNJLj
   else:
    ePrAzmGxltXiEMvqCBpygowWkaNJhb ='MOVIE'
    ePrAzmGxltXiEMvqCBpygowWkaNJhj={'mediatype':'movie','title':ePrAzmGxltXiEMvqCBpygowWkaNJSI,'mpaa':ePrAzmGxltXiEMvqCBpygowWkaNJhc,'genre':ePrAzmGxltXiEMvqCBpygowWkaNJhY,'duration':ePrAzmGxltXiEMvqCBpygowWkaNJhs,'year':ePrAzmGxltXiEMvqCBpygowWkaNJhO,'plot':'(%s)'%(ePrAzmGxltXiEMvqCBpygowWkaNJhc),}
    ePrAzmGxltXiEMvqCBpygowWkaNJSU =ePrAzmGxltXiEMvqCBpygowWkaNJLV
    ePrAzmGxltXiEMvqCBpygowWkaNJSI +=' (%s)'%(ePrAzmGxltXiEMvqCBpygowWkaNJLD(ePrAzmGxltXiEMvqCBpygowWkaNJhO))
   ePrAzmGxltXiEMvqCBpygowWkaNJSH={'mode':ePrAzmGxltXiEMvqCBpygowWkaNJhb,'id':ePrAzmGxltXiEMvqCBpygowWkaNJLf,'asis':ePrAzmGxltXiEMvqCBpygowWkaNJhH,'seasonList':ePrAzmGxltXiEMvqCBpygowWkaNJhQ,'title':ePrAzmGxltXiEMvqCBpygowWkaNJSI,'thumbnail':ePrAzmGxltXiEMvqCBpygowWkaNJhn,'year':ePrAzmGxltXiEMvqCBpygowWkaNJhO,}
   if ePrAzmGxltXiEMvqCBpygowWkaNJKT.get_settings_makebookmark():
    ePrAzmGxltXiEMvqCBpygowWkaNJhu={'videoid':ePrAzmGxltXiEMvqCBpygowWkaNJLf,'vidtype':'movie' if ePrAzmGxltXiEMvqCBpygowWkaNJhK=='MOVIES' else 'tvshow','vtitle':ePrAzmGxltXiEMvqCBpygowWkaNJSI,'vsubtitle':'',}
    ePrAzmGxltXiEMvqCBpygowWkaNJIK=json.dumps(ePrAzmGxltXiEMvqCBpygowWkaNJhu)
    ePrAzmGxltXiEMvqCBpygowWkaNJIK=urllib.parse.quote(ePrAzmGxltXiEMvqCBpygowWkaNJIK)
    ePrAzmGxltXiEMvqCBpygowWkaNJIS='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(ePrAzmGxltXiEMvqCBpygowWkaNJIK)
    ePrAzmGxltXiEMvqCBpygowWkaNJIh=[('(통합) 찜 영상에 추가',ePrAzmGxltXiEMvqCBpygowWkaNJIS)]
   else:
    ePrAzmGxltXiEMvqCBpygowWkaNJIh=ePrAzmGxltXiEMvqCBpygowWkaNJLI
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.add_dir(ePrAzmGxltXiEMvqCBpygowWkaNJSI,sublabel=ePrAzmGxltXiEMvqCBpygowWkaNJhF,img=ePrAzmGxltXiEMvqCBpygowWkaNJhn,infoLabels=ePrAzmGxltXiEMvqCBpygowWkaNJhj,isFolder=ePrAzmGxltXiEMvqCBpygowWkaNJSU,params=ePrAzmGxltXiEMvqCBpygowWkaNJSH,ContextMenu=ePrAzmGxltXiEMvqCBpygowWkaNJIh)
  if ePrAzmGxltXiEMvqCBpygowWkaNJhf:
   ePrAzmGxltXiEMvqCBpygowWkaNJSH['mode'] ='CATEGORY_LIST' 
   ePrAzmGxltXiEMvqCBpygowWkaNJSH['collectionId']=ePrAzmGxltXiEMvqCBpygowWkaNJhL 
   ePrAzmGxltXiEMvqCBpygowWkaNJSH['vType'] =ePrAzmGxltXiEMvqCBpygowWkaNJhK 
   ePrAzmGxltXiEMvqCBpygowWkaNJSH['page'] =ePrAzmGxltXiEMvqCBpygowWkaNJLD(ePrAzmGxltXiEMvqCBpygowWkaNJhD+1)
   ePrAzmGxltXiEMvqCBpygowWkaNJSI='[B]%s >>[/B]'%'다음 페이지'
   ePrAzmGxltXiEMvqCBpygowWkaNJIV=ePrAzmGxltXiEMvqCBpygowWkaNJLD(ePrAzmGxltXiEMvqCBpygowWkaNJhD+1)
   ePrAzmGxltXiEMvqCBpygowWkaNJSn=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.add_dir(ePrAzmGxltXiEMvqCBpygowWkaNJSI,sublabel=ePrAzmGxltXiEMvqCBpygowWkaNJIV,img=ePrAzmGxltXiEMvqCBpygowWkaNJSn,infoLabels=ePrAzmGxltXiEMvqCBpygowWkaNJLI,isFolder=ePrAzmGxltXiEMvqCBpygowWkaNJLj,params=ePrAzmGxltXiEMvqCBpygowWkaNJSH)
  if ePrAzmGxltXiEMvqCBpygowWkaNJhK=='TVSHOWS':xbmcplugin.setContent(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,'tvshows')
  else:xbmcplugin.setContent(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,'movies')
  xbmcplugin.endOfDirectory(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,cacheToDisc=ePrAzmGxltXiEMvqCBpygowWkaNJLV)
 def dp_Season_List(ePrAzmGxltXiEMvqCBpygowWkaNJKT,args):
  ePrAzmGxltXiEMvqCBpygowWkaNJIj =args.get('title')
  ePrAzmGxltXiEMvqCBpygowWkaNJIT =args.get('id')
  ePrAzmGxltXiEMvqCBpygowWkaNJhH =args.get('asis')
  ePrAzmGxltXiEMvqCBpygowWkaNJhQ =args.get('seasonList')
  ePrAzmGxltXiEMvqCBpygowWkaNJhn =args.get('thumbnail')
  ePrAzmGxltXiEMvqCBpygowWkaNJhO =args.get('year')
  if ePrAzmGxltXiEMvqCBpygowWkaNJhQ in['',ePrAzmGxltXiEMvqCBpygowWkaNJLI]:
   ePrAzmGxltXiEMvqCBpygowWkaNJhQ=ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.Get_vInfo(ePrAzmGxltXiEMvqCBpygowWkaNJIT).get('seasonList')
  if ePrAzmGxltXiEMvqCBpygowWkaNJLc(ePrAzmGxltXiEMvqCBpygowWkaNJhQ.split(','))>1:
   for ePrAzmGxltXiEMvqCBpygowWkaNJIL in ePrAzmGxltXiEMvqCBpygowWkaNJhQ.split(','):
    ePrAzmGxltXiEMvqCBpygowWkaNJSI='시즌 '+ePrAzmGxltXiEMvqCBpygowWkaNJIL
    ePrAzmGxltXiEMvqCBpygowWkaNJhj={'mediatype':'tvshow','plot':'%s (%s)'%(ePrAzmGxltXiEMvqCBpygowWkaNJIj,ePrAzmGxltXiEMvqCBpygowWkaNJhO),}
    ePrAzmGxltXiEMvqCBpygowWkaNJSH={'mode':'EPISODE_LIST','programid':ePrAzmGxltXiEMvqCBpygowWkaNJIT,'programnm':ePrAzmGxltXiEMvqCBpygowWkaNJIj,'season':ePrAzmGxltXiEMvqCBpygowWkaNJIL,'asis':ePrAzmGxltXiEMvqCBpygowWkaNJhH,'programimg':ePrAzmGxltXiEMvqCBpygowWkaNJhn,}
    ePrAzmGxltXiEMvqCBpygowWkaNJIn=ePrAzmGxltXiEMvqCBpygowWkaNJhn.replace('\'','\"')
    ePrAzmGxltXiEMvqCBpygowWkaNJIn=json.loads(ePrAzmGxltXiEMvqCBpygowWkaNJIn)
    ePrAzmGxltXiEMvqCBpygowWkaNJKT.add_dir(ePrAzmGxltXiEMvqCBpygowWkaNJSI,sublabel='',img=ePrAzmGxltXiEMvqCBpygowWkaNJIn,infoLabels=ePrAzmGxltXiEMvqCBpygowWkaNJhj,isFolder=ePrAzmGxltXiEMvqCBpygowWkaNJLj,params=ePrAzmGxltXiEMvqCBpygowWkaNJSH)
   xbmcplugin.setContent(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,cacheToDisc=ePrAzmGxltXiEMvqCBpygowWkaNJLV)
  else:
   ePrAzmGxltXiEMvqCBpygowWkaNJIH={'programid':ePrAzmGxltXiEMvqCBpygowWkaNJIT,'programnm':ePrAzmGxltXiEMvqCBpygowWkaNJIj,'season':ePrAzmGxltXiEMvqCBpygowWkaNJhQ,'programimg':ePrAzmGxltXiEMvqCBpygowWkaNJhn,}
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.dp_Episode_List(ePrAzmGxltXiEMvqCBpygowWkaNJIH)
 def dp_Episode_List(ePrAzmGxltXiEMvqCBpygowWkaNJKT,args):
  ePrAzmGxltXiEMvqCBpygowWkaNJIT =args.get('programid')
  ePrAzmGxltXiEMvqCBpygowWkaNJIj =args.get('programnm')
  ePrAzmGxltXiEMvqCBpygowWkaNJIU =args.get('season')
  ePrAzmGxltXiEMvqCBpygowWkaNJId =args.get('programimg')
  ePrAzmGxltXiEMvqCBpygowWkaNJIR=ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.Get_Episode_List(ePrAzmGxltXiEMvqCBpygowWkaNJIT,ePrAzmGxltXiEMvqCBpygowWkaNJIU)
  for ePrAzmGxltXiEMvqCBpygowWkaNJIL in ePrAzmGxltXiEMvqCBpygowWkaNJIR:
   ePrAzmGxltXiEMvqCBpygowWkaNJIs =ePrAzmGxltXiEMvqCBpygowWkaNJIL.get('title')
   ePrAzmGxltXiEMvqCBpygowWkaNJID =ePrAzmGxltXiEMvqCBpygowWkaNJIL.get('id')
   ePrAzmGxltXiEMvqCBpygowWkaNJhH =ePrAzmGxltXiEMvqCBpygowWkaNJIL.get('asis')
   ePrAzmGxltXiEMvqCBpygowWkaNJhn =ePrAzmGxltXiEMvqCBpygowWkaNJIL.get('thumbnail')
   ePrAzmGxltXiEMvqCBpygowWkaNJhc =ePrAzmGxltXiEMvqCBpygowWkaNJIL.get('mpaa')
   ePrAzmGxltXiEMvqCBpygowWkaNJhs =ePrAzmGxltXiEMvqCBpygowWkaNJIL.get('duration')
   ePrAzmGxltXiEMvqCBpygowWkaNJhO =ePrAzmGxltXiEMvqCBpygowWkaNJIL.get('year')
   ePrAzmGxltXiEMvqCBpygowWkaNJIf =ePrAzmGxltXiEMvqCBpygowWkaNJIL.get('episode')
   ePrAzmGxltXiEMvqCBpygowWkaNJhY =ePrAzmGxltXiEMvqCBpygowWkaNJIL.get('genreList')
   ePrAzmGxltXiEMvqCBpygowWkaNJIc =ePrAzmGxltXiEMvqCBpygowWkaNJIL.get('desc')
   ePrAzmGxltXiEMvqCBpygowWkaNJIF ='%sx%s'%(ePrAzmGxltXiEMvqCBpygowWkaNJIU,ePrAzmGxltXiEMvqCBpygowWkaNJIf)
   ePrAzmGxltXiEMvqCBpygowWkaNJSI ='%s. %s'%(ePrAzmGxltXiEMvqCBpygowWkaNJIF,ePrAzmGxltXiEMvqCBpygowWkaNJIs)
   ePrAzmGxltXiEMvqCBpygowWkaNJhj={'mediatype':'episode','mpaa':ePrAzmGxltXiEMvqCBpygowWkaNJhc,'genre':ePrAzmGxltXiEMvqCBpygowWkaNJhY,'duration':ePrAzmGxltXiEMvqCBpygowWkaNJhs,'year':ePrAzmGxltXiEMvqCBpygowWkaNJhO,'plot':'%s (%s)\n\n%s'%(ePrAzmGxltXiEMvqCBpygowWkaNJIj,ePrAzmGxltXiEMvqCBpygowWkaNJIF,ePrAzmGxltXiEMvqCBpygowWkaNJIc),}
   ePrAzmGxltXiEMvqCBpygowWkaNJSH={'mode':'VOD','programid':ePrAzmGxltXiEMvqCBpygowWkaNJIT,'programnm':ePrAzmGxltXiEMvqCBpygowWkaNJIj,'title':ePrAzmGxltXiEMvqCBpygowWkaNJSI,'season':ePrAzmGxltXiEMvqCBpygowWkaNJIU,'id':ePrAzmGxltXiEMvqCBpygowWkaNJID,'asis':ePrAzmGxltXiEMvqCBpygowWkaNJhH,'thumbnail':ePrAzmGxltXiEMvqCBpygowWkaNJhn,'programimg':ePrAzmGxltXiEMvqCBpygowWkaNJId,}
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.add_dir(ePrAzmGxltXiEMvqCBpygowWkaNJSI,sublabel='',img=ePrAzmGxltXiEMvqCBpygowWkaNJhn,infoLabels=ePrAzmGxltXiEMvqCBpygowWkaNJhj,isFolder=ePrAzmGxltXiEMvqCBpygowWkaNJLV,params=ePrAzmGxltXiEMvqCBpygowWkaNJSH)
  xbmcplugin.setContent(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,cacheToDisc=ePrAzmGxltXiEMvqCBpygowWkaNJLV)
 def play_VIDEO(ePrAzmGxltXiEMvqCBpygowWkaNJKT,args):
  ePrAzmGxltXiEMvqCBpygowWkaNJIO =args.get('id')
  ePrAzmGxltXiEMvqCBpygowWkaNJhH =args.get('asis')
  if ePrAzmGxltXiEMvqCBpygowWkaNJhH in['HIGHLIGHT']:
   ePrAzmGxltXiEMvqCBpygowWkaNJIQ,ePrAzmGxltXiEMvqCBpygowWkaNJIY=ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.GetEventURL(ePrAzmGxltXiEMvqCBpygowWkaNJIO,ePrAzmGxltXiEMvqCBpygowWkaNJhH)
  elif ePrAzmGxltXiEMvqCBpygowWkaNJhH in['LIVE']:
   ePrAzmGxltXiEMvqCBpygowWkaNJIQ,ePrAzmGxltXiEMvqCBpygowWkaNJIY=ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.GetEventURL_Live(ePrAzmGxltXiEMvqCBpygowWkaNJIO,ePrAzmGxltXiEMvqCBpygowWkaNJhH)
  else:
   ePrAzmGxltXiEMvqCBpygowWkaNJIQ,ePrAzmGxltXiEMvqCBpygowWkaNJIY=ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.GetBroadURL(ePrAzmGxltXiEMvqCBpygowWkaNJIO)
  ePrAzmGxltXiEMvqCBpygowWkaNJKT.addon_log('asis, url : %s - %s - %s'%(ePrAzmGxltXiEMvqCBpygowWkaNJhH,ePrAzmGxltXiEMvqCBpygowWkaNJIO,ePrAzmGxltXiEMvqCBpygowWkaNJIQ))
  if ePrAzmGxltXiEMvqCBpygowWkaNJIQ=='':
   if ePrAzmGxltXiEMvqCBpygowWkaNJIY=='':
    ePrAzmGxltXiEMvqCBpygowWkaNJKT.addon_noti(__language__(30907).encode('utf8'))
   else:
    ePrAzmGxltXiEMvqCBpygowWkaNJKT.addon_log('drm_license_1 : %s'%(ePrAzmGxltXiEMvqCBpygowWkaNJIY))
    ePrAzmGxltXiEMvqCBpygowWkaNJKT.addon_noti(ePrAzmGxltXiEMvqCBpygowWkaNJIY)
   return
  else:
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.addon_log('drm_license : %s'%(ePrAzmGxltXiEMvqCBpygowWkaNJIY))
  '''
  tmp_cookie = 'PCID=%s;token=%s;member_srl=%s;NEXT_LOCALE=%s;session_web_id=%s;device_id=%s' % (self.CoupangObj.CP['COOKIES']['PCID'], self.CoupangObj.CP['COOKIES']['token'], self.CoupangObj.CP['COOKIES']['member_srl'], self.CoupangObj.CP['COOKIES']['NEXT_LOCALE'], self.CoupangObj.CP['COOKIES']['session_web_id'], self.CoupangObj.CP['COOKIES']['device_id'], )
  '''  
  if ePrAzmGxltXiEMvqCBpygowWkaNJhH in['EPISODE']:
   ePrAzmGxltXiEMvqCBpygowWkaNJIb='https://www.coupangplay.com/play/{}/episode?titleId={}&type=EPISODE&sourceType=page_discover_title_detail%3Apage_discover_feed'.format(ePrAzmGxltXiEMvqCBpygowWkaNJIO,ePrAzmGxltXiEMvqCBpygowWkaNJIO)
  elif ePrAzmGxltXiEMvqCBpygowWkaNJhH in['MOVIE']:
   ePrAzmGxltXiEMvqCBpygowWkaNJIb='https://www.coupangplay.com/play/{}/movie?sourceType=page_discover_feed'.format(ePrAzmGxltXiEMvqCBpygowWkaNJIO)
  else:
   ePrAzmGxltXiEMvqCBpygowWkaNJIb='https://www.coupangplay.com/play/'+ePrAzmGxltXiEMvqCBpygowWkaNJIO 
  ePrAzmGxltXiEMvqCBpygowWkaNJIu,ePrAzmGxltXiEMvqCBpygowWkaNJVK,ePrAzmGxltXiEMvqCBpygowWkaNJVS=ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.Make_authHeader()
  ePrAzmGxltXiEMvqCBpygowWkaNJVh=ePrAzmGxltXiEMvqCBpygowWkaNJIQ 
  ePrAzmGxltXiEMvqCBpygowWkaNJKT.addon_log('tobe, surl : %s'%(ePrAzmGxltXiEMvqCBpygowWkaNJVh))
  ePrAzmGxltXiEMvqCBpygowWkaNJVI=xbmcgui.ListItem(path=ePrAzmGxltXiEMvqCBpygowWkaNJVh)
  ePrAzmGxltXiEMvqCBpygowWkaNJVj=ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.Get_Url_PostFix(ePrAzmGxltXiEMvqCBpygowWkaNJIQ) 
  ePrAzmGxltXiEMvqCBpygowWkaNJKT.addon_log('post_fix : '+ePrAzmGxltXiEMvqCBpygowWkaNJVj)
  if ePrAzmGxltXiEMvqCBpygowWkaNJVj=='m3u8':
   ePrAzmGxltXiEMvqCBpygowWkaNJVT ='hls' 
  else:
   ePrAzmGxltXiEMvqCBpygowWkaNJVT ='mpd' 
  ePrAzmGxltXiEMvqCBpygowWkaNJVL={'user-agent':ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.USER_AGENT,'referer':ePrAzmGxltXiEMvqCBpygowWkaNJIb,'traceparent':ePrAzmGxltXiEMvqCBpygowWkaNJIu,'tracestate':ePrAzmGxltXiEMvqCBpygowWkaNJVK,'newrelic':ePrAzmGxltXiEMvqCBpygowWkaNJVS,}
  ePrAzmGxltXiEMvqCBpygowWkaNJVn =ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.CP['COOKIES']
  ePrAzmGxltXiEMvqCBpygowWkaNJVH=ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.make_stream_header(ePrAzmGxltXiEMvqCBpygowWkaNJVL,ePrAzmGxltXiEMvqCBpygowWkaNJVn)
  if ePrAzmGxltXiEMvqCBpygowWkaNJIY:
   ePrAzmGxltXiEMvqCBpygowWkaNJVU =ePrAzmGxltXiEMvqCBpygowWkaNJIY 
   ePrAzmGxltXiEMvqCBpygowWkaNJVd ='com.widevine.alpha'
   ePrAzmGxltXiEMvqCBpygowWkaNJVR=ePrAzmGxltXiEMvqCBpygowWkaNJVU+'|'+ePrAzmGxltXiEMvqCBpygowWkaNJVH+'|R{SSM}|'
   inputstreamhelper.Helper(ePrAzmGxltXiEMvqCBpygowWkaNJVT,drm='com.widevine.alpha').check_inputstream()
   ePrAzmGxltXiEMvqCBpygowWkaNJVI.setProperty('inputstream','inputstream.adaptive')
   if ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.KodiVersion<=20:
    ePrAzmGxltXiEMvqCBpygowWkaNJVI.setProperty('inputstream.adaptive.manifest_type',ePrAzmGxltXiEMvqCBpygowWkaNJVT)
   ePrAzmGxltXiEMvqCBpygowWkaNJVI.setProperty('inputstream.adaptive.license_type',ePrAzmGxltXiEMvqCBpygowWkaNJVd)
   ePrAzmGxltXiEMvqCBpygowWkaNJVI.setProperty('inputstream.adaptive.license_key',ePrAzmGxltXiEMvqCBpygowWkaNJVR)
   ePrAzmGxltXiEMvqCBpygowWkaNJVI.setProperty('inputstream.adaptive.stream_headers',ePrAzmGxltXiEMvqCBpygowWkaNJVH)
   ePrAzmGxltXiEMvqCBpygowWkaNJVI.setProperty('inputstream.adaptive.manifest_headers',ePrAzmGxltXiEMvqCBpygowWkaNJVH)
   ePrAzmGxltXiEMvqCBpygowWkaNJVI.setMimeType('application/dash+xml')
   ePrAzmGxltXiEMvqCBpygowWkaNJVI.setContentLookup(ePrAzmGxltXiEMvqCBpygowWkaNJLV)
  else:
   ePrAzmGxltXiEMvqCBpygowWkaNJVI.setContentLookup(ePrAzmGxltXiEMvqCBpygowWkaNJLV)
   ePrAzmGxltXiEMvqCBpygowWkaNJVI.setMimeType('application/x-mpegURL')
   ePrAzmGxltXiEMvqCBpygowWkaNJVI.setProperty('inputstream','inputstream.adaptive')
   if ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.KodiVersion<=20:
    ePrAzmGxltXiEMvqCBpygowWkaNJVI.setProperty('inputstream.adaptive.manifest_type',ePrAzmGxltXiEMvqCBpygowWkaNJVT)
   ePrAzmGxltXiEMvqCBpygowWkaNJVI.setProperty('inputstream.adaptive.stream_headers',ePrAzmGxltXiEMvqCBpygowWkaNJVH)
   ePrAzmGxltXiEMvqCBpygowWkaNJVI.setProperty('inputstream.adaptive.manifest_headers',ePrAzmGxltXiEMvqCBpygowWkaNJVH)
  xbmcplugin.setResolvedUrl(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,ePrAzmGxltXiEMvqCBpygowWkaNJLj,ePrAzmGxltXiEMvqCBpygowWkaNJVI)
  try:
   if ePrAzmGxltXiEMvqCBpygowWkaNJhH=='MOVIE':
    ePrAzmGxltXiEMvqCBpygowWkaNJVD='movie'
    ePrAzmGxltXiEMvqCBpygowWkaNJSH={'code':ePrAzmGxltXiEMvqCBpygowWkaNJIO,'asis':ePrAzmGxltXiEMvqCBpygowWkaNJhH,'title':args.get('title'),'img':args.get('thumbnail'),}
    ePrAzmGxltXiEMvqCBpygowWkaNJKT.Save_Watched_List(ePrAzmGxltXiEMvqCBpygowWkaNJVD,ePrAzmGxltXiEMvqCBpygowWkaNJSH)
   elif ePrAzmGxltXiEMvqCBpygowWkaNJhH=='EPISODE':
    ePrAzmGxltXiEMvqCBpygowWkaNJVD='tvshow'
    ePrAzmGxltXiEMvqCBpygowWkaNJSH={'code':args.get('programid'),'asis':ePrAzmGxltXiEMvqCBpygowWkaNJhH,'title':'%s <%s>'%(args.get('title'),args.get('programnm')),'img':args.get('programimg'),}
    ePrAzmGxltXiEMvqCBpygowWkaNJKT.Save_Watched_List(ePrAzmGxltXiEMvqCBpygowWkaNJVD,ePrAzmGxltXiEMvqCBpygowWkaNJSH)
  except:
   ePrAzmGxltXiEMvqCBpygowWkaNJLI
 def dp_Global_Search(ePrAzmGxltXiEMvqCBpygowWkaNJKT,args):
  ePrAzmGxltXiEMvqCBpygowWkaNJhb=args.get('mode')
  if ePrAzmGxltXiEMvqCBpygowWkaNJhb=='TOTAL_SEARCH':
   ePrAzmGxltXiEMvqCBpygowWkaNJVf='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   ePrAzmGxltXiEMvqCBpygowWkaNJVf='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(ePrAzmGxltXiEMvqCBpygowWkaNJVf)
 def dp_Bookmark_Menu(ePrAzmGxltXiEMvqCBpygowWkaNJKT,args):
  ePrAzmGxltXiEMvqCBpygowWkaNJVf='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(ePrAzmGxltXiEMvqCBpygowWkaNJVf)
 def dp_Search_List(ePrAzmGxltXiEMvqCBpygowWkaNJKT,args):
  ePrAzmGxltXiEMvqCBpygowWkaNJhD =ePrAzmGxltXiEMvqCBpygowWkaNJLU(args.get('page'))
  if 'search_key' in args:
   ePrAzmGxltXiEMvqCBpygowWkaNJVc=args.get('search_key')
  else:
   ePrAzmGxltXiEMvqCBpygowWkaNJVc=ePrAzmGxltXiEMvqCBpygowWkaNJKT.get_keyboard_input(__language__(30908).encode('utf-8'))
   if not ePrAzmGxltXiEMvqCBpygowWkaNJVc:
    return
  ePrAzmGxltXiEMvqCBpygowWkaNJVF,ePrAzmGxltXiEMvqCBpygowWkaNJhf=ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.Get_Search_List(ePrAzmGxltXiEMvqCBpygowWkaNJVc,ePrAzmGxltXiEMvqCBpygowWkaNJhD)
  for ePrAzmGxltXiEMvqCBpygowWkaNJVO in ePrAzmGxltXiEMvqCBpygowWkaNJVF:
   ePrAzmGxltXiEMvqCBpygowWkaNJLf =ePrAzmGxltXiEMvqCBpygowWkaNJVO.get('id')
   ePrAzmGxltXiEMvqCBpygowWkaNJSI =ePrAzmGxltXiEMvqCBpygowWkaNJVO.get('title')
   ePrAzmGxltXiEMvqCBpygowWkaNJhH =ePrAzmGxltXiEMvqCBpygowWkaNJVO.get('asis')
   ePrAzmGxltXiEMvqCBpygowWkaNJhn =ePrAzmGxltXiEMvqCBpygowWkaNJVO.get('thumbnail')
   ePrAzmGxltXiEMvqCBpygowWkaNJhc =ePrAzmGxltXiEMvqCBpygowWkaNJVO.get('mpaa')
   ePrAzmGxltXiEMvqCBpygowWkaNJhO =ePrAzmGxltXiEMvqCBpygowWkaNJVO.get('year')
   ePrAzmGxltXiEMvqCBpygowWkaNJhs =ePrAzmGxltXiEMvqCBpygowWkaNJVO.get('duration')
   ePrAzmGxltXiEMvqCBpygowWkaNJhF =ePrAzmGxltXiEMvqCBpygowWkaNJVO.get('badge')
   if ePrAzmGxltXiEMvqCBpygowWkaNJhH=='TVSHOW': 
    ePrAzmGxltXiEMvqCBpygowWkaNJhb ='SEASON_LIST'
    ePrAzmGxltXiEMvqCBpygowWkaNJhj={'mediatype':'tvshow','title':ePrAzmGxltXiEMvqCBpygowWkaNJSI,'mpaa':ePrAzmGxltXiEMvqCBpygowWkaNJhc,'year':ePrAzmGxltXiEMvqCBpygowWkaNJhO,'plot':'Year : %s'%(ePrAzmGxltXiEMvqCBpygowWkaNJhO),}
    ePrAzmGxltXiEMvqCBpygowWkaNJSU =ePrAzmGxltXiEMvqCBpygowWkaNJLj
   elif ePrAzmGxltXiEMvqCBpygowWkaNJhH=='MOVIE':
    ePrAzmGxltXiEMvqCBpygowWkaNJhb ='MOVIE'
    ePrAzmGxltXiEMvqCBpygowWkaNJhj={'mediatype':'movie','title':ePrAzmGxltXiEMvqCBpygowWkaNJSI,'mpaa':ePrAzmGxltXiEMvqCBpygowWkaNJhc,'duration':ePrAzmGxltXiEMvqCBpygowWkaNJhs,'year':ePrAzmGxltXiEMvqCBpygowWkaNJhO,'plot':'(%s)'%(ePrAzmGxltXiEMvqCBpygowWkaNJhc),}
    ePrAzmGxltXiEMvqCBpygowWkaNJSU =ePrAzmGxltXiEMvqCBpygowWkaNJLV
    ePrAzmGxltXiEMvqCBpygowWkaNJSI +=' (%s)'%(ePrAzmGxltXiEMvqCBpygowWkaNJLD(ePrAzmGxltXiEMvqCBpygowWkaNJhO))
   elif ePrAzmGxltXiEMvqCBpygowWkaNJhH=='HIGHLIGHT':
    ePrAzmGxltXiEMvqCBpygowWkaNJhb ='HIGHLIGHT'
    ePrAzmGxltXiEMvqCBpygowWkaNJhj={'mediatype':'episode','title':ePrAzmGxltXiEMvqCBpygowWkaNJSI,'duration':ePrAzmGxltXiEMvqCBpygowWkaNJhs,'plot':ePrAzmGxltXiEMvqCBpygowWkaNJhb,}
    ePrAzmGxltXiEMvqCBpygowWkaNJSU =ePrAzmGxltXiEMvqCBpygowWkaNJLV
   elif ePrAzmGxltXiEMvqCBpygowWkaNJhH=='LIVE':
    ePrAzmGxltXiEMvqCBpygowWkaNJhb ='LIVE'
    ePrAzmGxltXiEMvqCBpygowWkaNJhj={'mediatype':'episode','title':ePrAzmGxltXiEMvqCBpygowWkaNJSI,'plot':ePrAzmGxltXiEMvqCBpygowWkaNJhb,}
    ePrAzmGxltXiEMvqCBpygowWkaNJSU =ePrAzmGxltXiEMvqCBpygowWkaNJLV
   ePrAzmGxltXiEMvqCBpygowWkaNJSH={'mode':ePrAzmGxltXiEMvqCBpygowWkaNJhb,'id':ePrAzmGxltXiEMvqCBpygowWkaNJLf,'asis':ePrAzmGxltXiEMvqCBpygowWkaNJhH,'seasonList':'','title':ePrAzmGxltXiEMvqCBpygowWkaNJSI,'thumbnail':json.dumps(ePrAzmGxltXiEMvqCBpygowWkaNJhn,separators=(',',':')),'year':ePrAzmGxltXiEMvqCBpygowWkaNJhO,}
   if ePrAzmGxltXiEMvqCBpygowWkaNJKT.get_settings_makebookmark()and ePrAzmGxltXiEMvqCBpygowWkaNJhH not in['HIGHLIGHT','']:
    ePrAzmGxltXiEMvqCBpygowWkaNJhu={'videoid':ePrAzmGxltXiEMvqCBpygowWkaNJLf,'vidtype':'movie' if ePrAzmGxltXiEMvqCBpygowWkaNJhH=='MOVIE' else 'tvshow','vtitle':ePrAzmGxltXiEMvqCBpygowWkaNJSI,'vsubtitle':'',}
    ePrAzmGxltXiEMvqCBpygowWkaNJIK=json.dumps(ePrAzmGxltXiEMvqCBpygowWkaNJhu)
    ePrAzmGxltXiEMvqCBpygowWkaNJIK=urllib.parse.quote(ePrAzmGxltXiEMvqCBpygowWkaNJIK)
    ePrAzmGxltXiEMvqCBpygowWkaNJIS='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(ePrAzmGxltXiEMvqCBpygowWkaNJIK)
    ePrAzmGxltXiEMvqCBpygowWkaNJIh=[('(통합) 찜 영상에 추가',ePrAzmGxltXiEMvqCBpygowWkaNJIS)]
   else:
    ePrAzmGxltXiEMvqCBpygowWkaNJIh=ePrAzmGxltXiEMvqCBpygowWkaNJLI
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.add_dir(ePrAzmGxltXiEMvqCBpygowWkaNJSI,sublabel=ePrAzmGxltXiEMvqCBpygowWkaNJhF,img=ePrAzmGxltXiEMvqCBpygowWkaNJhn,infoLabels=ePrAzmGxltXiEMvqCBpygowWkaNJhj,isFolder=ePrAzmGxltXiEMvqCBpygowWkaNJSU,params=ePrAzmGxltXiEMvqCBpygowWkaNJSH,ContextMenu=ePrAzmGxltXiEMvqCBpygowWkaNJIh)
  if ePrAzmGxltXiEMvqCBpygowWkaNJhf:
   ePrAzmGxltXiEMvqCBpygowWkaNJSH={}
   ePrAzmGxltXiEMvqCBpygowWkaNJSH['mode'] ='LOCAL_SEARCH'
   ePrAzmGxltXiEMvqCBpygowWkaNJSH['search_key']=ePrAzmGxltXiEMvqCBpygowWkaNJVc
   ePrAzmGxltXiEMvqCBpygowWkaNJSH['page'] =ePrAzmGxltXiEMvqCBpygowWkaNJLD(ePrAzmGxltXiEMvqCBpygowWkaNJhD+1)
   ePrAzmGxltXiEMvqCBpygowWkaNJSI='[B]%s >>[/B]'%'다음 페이지'
   ePrAzmGxltXiEMvqCBpygowWkaNJIV=ePrAzmGxltXiEMvqCBpygowWkaNJLD(ePrAzmGxltXiEMvqCBpygowWkaNJhD+1)
   ePrAzmGxltXiEMvqCBpygowWkaNJSn=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.add_dir(ePrAzmGxltXiEMvqCBpygowWkaNJSI,sublabel=ePrAzmGxltXiEMvqCBpygowWkaNJIV,img=ePrAzmGxltXiEMvqCBpygowWkaNJSn,infoLabels=ePrAzmGxltXiEMvqCBpygowWkaNJLI,isFolder=ePrAzmGxltXiEMvqCBpygowWkaNJLj,params=ePrAzmGxltXiEMvqCBpygowWkaNJSH)
  xbmcplugin.setContent(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,'movies')
  xbmcplugin.endOfDirectory(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,cacheToDisc=ePrAzmGxltXiEMvqCBpygowWkaNJLj)
  if args.get('historyyn')=='Y':ePrAzmGxltXiEMvqCBpygowWkaNJKT.Save_Searched_List(ePrAzmGxltXiEMvqCBpygowWkaNJVc)
 def Load_List_File(ePrAzmGxltXiEMvqCBpygowWkaNJKT,ePrAzmGxltXiEMvqCBpygowWkaNJVD): 
  try:
   if ePrAzmGxltXiEMvqCBpygowWkaNJVD=='search':
    ePrAzmGxltXiEMvqCBpygowWkaNJVQ=ePrAzmGxltXiEMvqCBpygowWkaNJKj
   elif ePrAzmGxltXiEMvqCBpygowWkaNJVD in['tvshow','movie']:
    ePrAzmGxltXiEMvqCBpygowWkaNJVQ=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%ePrAzmGxltXiEMvqCBpygowWkaNJVD))
   else:
    return[]
   fp=ePrAzmGxltXiEMvqCBpygowWkaNJLR(ePrAzmGxltXiEMvqCBpygowWkaNJVQ,'r',-1,'utf-8')
   ePrAzmGxltXiEMvqCBpygowWkaNJVY=fp.readlines()
   fp.close()
  except:
   ePrAzmGxltXiEMvqCBpygowWkaNJVY=[]
  return ePrAzmGxltXiEMvqCBpygowWkaNJVY
 def Save_Watched_List(ePrAzmGxltXiEMvqCBpygowWkaNJKT,ePrAzmGxltXiEMvqCBpygowWkaNJVD,ePrAzmGxltXiEMvqCBpygowWkaNJKH):
  try:
   ePrAzmGxltXiEMvqCBpygowWkaNJVb=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%ePrAzmGxltXiEMvqCBpygowWkaNJVD))
   ePrAzmGxltXiEMvqCBpygowWkaNJVu=ePrAzmGxltXiEMvqCBpygowWkaNJKT.Load_List_File(ePrAzmGxltXiEMvqCBpygowWkaNJVD) 
   fp=ePrAzmGxltXiEMvqCBpygowWkaNJLR(ePrAzmGxltXiEMvqCBpygowWkaNJVb,'w',-1,'utf-8')
   ePrAzmGxltXiEMvqCBpygowWkaNJjK=urllib.parse.urlencode(ePrAzmGxltXiEMvqCBpygowWkaNJKH)
   ePrAzmGxltXiEMvqCBpygowWkaNJjK=ePrAzmGxltXiEMvqCBpygowWkaNJjK+'\n'
   fp.write(ePrAzmGxltXiEMvqCBpygowWkaNJjK)
   ePrAzmGxltXiEMvqCBpygowWkaNJjS=0
   for ePrAzmGxltXiEMvqCBpygowWkaNJjh in ePrAzmGxltXiEMvqCBpygowWkaNJVu:
    ePrAzmGxltXiEMvqCBpygowWkaNJjI=ePrAzmGxltXiEMvqCBpygowWkaNJLn(urllib.parse.parse_qsl(ePrAzmGxltXiEMvqCBpygowWkaNJjh))
    ePrAzmGxltXiEMvqCBpygowWkaNJjV=ePrAzmGxltXiEMvqCBpygowWkaNJKH.get('code').strip()
    ePrAzmGxltXiEMvqCBpygowWkaNJjT=ePrAzmGxltXiEMvqCBpygowWkaNJjI.get('code').strip()
    if ePrAzmGxltXiEMvqCBpygowWkaNJjV!=ePrAzmGxltXiEMvqCBpygowWkaNJjT:
     fp.write(ePrAzmGxltXiEMvqCBpygowWkaNJjh)
     ePrAzmGxltXiEMvqCBpygowWkaNJjS+=1
     if ePrAzmGxltXiEMvqCBpygowWkaNJjS>=50:break
   fp.close()
  except:
   ePrAzmGxltXiEMvqCBpygowWkaNJLI
 def Save_Searched_List(ePrAzmGxltXiEMvqCBpygowWkaNJKT,ePrAzmGxltXiEMvqCBpygowWkaNJVc):
  try:
   ePrAzmGxltXiEMvqCBpygowWkaNJVc=ePrAzmGxltXiEMvqCBpygowWkaNJVc.strip()
   ePrAzmGxltXiEMvqCBpygowWkaNJVu=ePrAzmGxltXiEMvqCBpygowWkaNJKT.Load_List_File('search') 
   fp=ePrAzmGxltXiEMvqCBpygowWkaNJLR(ePrAzmGxltXiEMvqCBpygowWkaNJKj,'w',-1,'utf-8')
   fp.write(ePrAzmGxltXiEMvqCBpygowWkaNJVc+'\n')
   ePrAzmGxltXiEMvqCBpygowWkaNJjS=0
   for ePrAzmGxltXiEMvqCBpygowWkaNJjh in ePrAzmGxltXiEMvqCBpygowWkaNJVu:
    ePrAzmGxltXiEMvqCBpygowWkaNJjh=ePrAzmGxltXiEMvqCBpygowWkaNJjh.strip()
    if ePrAzmGxltXiEMvqCBpygowWkaNJVc!=ePrAzmGxltXiEMvqCBpygowWkaNJjh:
     fp.write(ePrAzmGxltXiEMvqCBpygowWkaNJjh+'\n')
     ePrAzmGxltXiEMvqCBpygowWkaNJjS+=1
     if ePrAzmGxltXiEMvqCBpygowWkaNJjS>=50:break
   fp.close()
  except:
   ePrAzmGxltXiEMvqCBpygowWkaNJLI
 def dp_Search_History(ePrAzmGxltXiEMvqCBpygowWkaNJKT,args):
  ePrAzmGxltXiEMvqCBpygowWkaNJjL=ePrAzmGxltXiEMvqCBpygowWkaNJKT.Load_List_File('search')
  for ePrAzmGxltXiEMvqCBpygowWkaNJjn in ePrAzmGxltXiEMvqCBpygowWkaNJjL:
   ePrAzmGxltXiEMvqCBpygowWkaNJjn=ePrAzmGxltXiEMvqCBpygowWkaNJjn.strip()
   ePrAzmGxltXiEMvqCBpygowWkaNJSH={'mode':'LOCAL_SEARCH','search_key':ePrAzmGxltXiEMvqCBpygowWkaNJjn,'page':'1','historyyn':'Y',}
   ePrAzmGxltXiEMvqCBpygowWkaNJjH={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','skey':ePrAzmGxltXiEMvqCBpygowWkaNJjn,'vType':'-',}
   ePrAzmGxltXiEMvqCBpygowWkaNJjU=urllib.parse.urlencode(ePrAzmGxltXiEMvqCBpygowWkaNJjH)
   ePrAzmGxltXiEMvqCBpygowWkaNJIh=[('선택된 검색어 ( %s ) 삭제'%(ePrAzmGxltXiEMvqCBpygowWkaNJjn),'RunPlugin(plugin://plugin.video.coupangm/?%s)'%(ePrAzmGxltXiEMvqCBpygowWkaNJjU))]
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.add_dir(ePrAzmGxltXiEMvqCBpygowWkaNJjn,sublabel='',img=ePrAzmGxltXiEMvqCBpygowWkaNJLI,infoLabels=ePrAzmGxltXiEMvqCBpygowWkaNJLI,isFolder=ePrAzmGxltXiEMvqCBpygowWkaNJLj,params=ePrAzmGxltXiEMvqCBpygowWkaNJSH,ContextMenu=ePrAzmGxltXiEMvqCBpygowWkaNJIh)
  ePrAzmGxltXiEMvqCBpygowWkaNJhj={'plot':'검색목록 전체를 삭제합니다.'}
  ePrAzmGxltXiEMvqCBpygowWkaNJSI='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  ePrAzmGxltXiEMvqCBpygowWkaNJSH={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  ePrAzmGxltXiEMvqCBpygowWkaNJSn=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  ePrAzmGxltXiEMvqCBpygowWkaNJKT.add_dir(ePrAzmGxltXiEMvqCBpygowWkaNJSI,sublabel='',img=ePrAzmGxltXiEMvqCBpygowWkaNJSn,infoLabels=ePrAzmGxltXiEMvqCBpygowWkaNJhj,isFolder=ePrAzmGxltXiEMvqCBpygowWkaNJLV,params=ePrAzmGxltXiEMvqCBpygowWkaNJSH,isLink=ePrAzmGxltXiEMvqCBpygowWkaNJLj)
  xbmcplugin.endOfDirectory(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,cacheToDisc=ePrAzmGxltXiEMvqCBpygowWkaNJLV)
 def dp_Listfile_Delete(ePrAzmGxltXiEMvqCBpygowWkaNJKT,args):
  ePrAzmGxltXiEMvqCBpygowWkaNJjd=args.get('delType')
  ePrAzmGxltXiEMvqCBpygowWkaNJjR =args.get('skey')
  ePrAzmGxltXiEMvqCBpygowWkaNJhK =args.get('vType')
  ePrAzmGxltXiEMvqCBpygowWkaNJKd=xbmcgui.Dialog()
  if ePrAzmGxltXiEMvqCBpygowWkaNJjd=='SEARCH_ALL':
   ePrAzmGxltXiEMvqCBpygowWkaNJSD=ePrAzmGxltXiEMvqCBpygowWkaNJKd.yesno(__language__(30911).encode('utf8'),__language__(30906).encode('utf8'))
  elif ePrAzmGxltXiEMvqCBpygowWkaNJjd=='SEARCH_ONE':
   ePrAzmGxltXiEMvqCBpygowWkaNJSD=ePrAzmGxltXiEMvqCBpygowWkaNJKd.yesno(__language__(30912).encode('utf8'),__language__(30906).encode('utf8'))
  elif ePrAzmGxltXiEMvqCBpygowWkaNJjd=='WATCH_ALL':
   ePrAzmGxltXiEMvqCBpygowWkaNJSD=ePrAzmGxltXiEMvqCBpygowWkaNJKd.yesno(__language__(30913).encode('utf8'),__language__(30906).encode('utf8'))
  elif ePrAzmGxltXiEMvqCBpygowWkaNJjd=='WATCH_ONE':
   ePrAzmGxltXiEMvqCBpygowWkaNJSD=ePrAzmGxltXiEMvqCBpygowWkaNJKd.yesno(__language__(30916).encode('utf8'),__language__(30906).encode('utf8'))
  if ePrAzmGxltXiEMvqCBpygowWkaNJSD==ePrAzmGxltXiEMvqCBpygowWkaNJLV:sys.exit()
  if ePrAzmGxltXiEMvqCBpygowWkaNJjd=='SEARCH_ALL':
   if os.path.isfile(ePrAzmGxltXiEMvqCBpygowWkaNJKj):os.remove(ePrAzmGxltXiEMvqCBpygowWkaNJKj)
  elif ePrAzmGxltXiEMvqCBpygowWkaNJjd=='SEARCH_ONE':
   try:
    ePrAzmGxltXiEMvqCBpygowWkaNJVQ=ePrAzmGxltXiEMvqCBpygowWkaNJKj
    ePrAzmGxltXiEMvqCBpygowWkaNJVu=ePrAzmGxltXiEMvqCBpygowWkaNJKT.Load_List_File('search') 
    fp=ePrAzmGxltXiEMvqCBpygowWkaNJLR(ePrAzmGxltXiEMvqCBpygowWkaNJVQ,'w',-1,'utf-8')
    for ePrAzmGxltXiEMvqCBpygowWkaNJjh in ePrAzmGxltXiEMvqCBpygowWkaNJVu:
     if ePrAzmGxltXiEMvqCBpygowWkaNJjR!=ePrAzmGxltXiEMvqCBpygowWkaNJjh.strip():
      fp.write(ePrAzmGxltXiEMvqCBpygowWkaNJjh)
    fp.close()
   except:
    ePrAzmGxltXiEMvqCBpygowWkaNJLI
  elif ePrAzmGxltXiEMvqCBpygowWkaNJjd=='WATCH_ALL':
   ePrAzmGxltXiEMvqCBpygowWkaNJVQ=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%ePrAzmGxltXiEMvqCBpygowWkaNJhK))
   if os.path.isfile(ePrAzmGxltXiEMvqCBpygowWkaNJVQ):os.remove(ePrAzmGxltXiEMvqCBpygowWkaNJVQ)
  elif ePrAzmGxltXiEMvqCBpygowWkaNJjd=='WATCH_ONE':
   ePrAzmGxltXiEMvqCBpygowWkaNJVQ=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%ePrAzmGxltXiEMvqCBpygowWkaNJhK))
   try:
    ePrAzmGxltXiEMvqCBpygowWkaNJVu=ePrAzmGxltXiEMvqCBpygowWkaNJKT.Load_List_File(ePrAzmGxltXiEMvqCBpygowWkaNJhK) 
    fp=ePrAzmGxltXiEMvqCBpygowWkaNJLR(ePrAzmGxltXiEMvqCBpygowWkaNJVQ,'w',-1,'utf-8')
    for ePrAzmGxltXiEMvqCBpygowWkaNJjh in ePrAzmGxltXiEMvqCBpygowWkaNJVu:
     ePrAzmGxltXiEMvqCBpygowWkaNJjI=ePrAzmGxltXiEMvqCBpygowWkaNJLn(urllib.parse.parse_qsl(ePrAzmGxltXiEMvqCBpygowWkaNJjh))
     ePrAzmGxltXiEMvqCBpygowWkaNJjs=ePrAzmGxltXiEMvqCBpygowWkaNJjI.get('code').strip()
     if ePrAzmGxltXiEMvqCBpygowWkaNJjR!=ePrAzmGxltXiEMvqCBpygowWkaNJjs:
      fp.write(ePrAzmGxltXiEMvqCBpygowWkaNJjh)
    fp.close()
   except:
    ePrAzmGxltXiEMvqCBpygowWkaNJLI
  xbmc.executebuiltin("Container.Refresh")
 def Delete_List_File(ePrAzmGxltXiEMvqCBpygowWkaNJKT,ePrAzmGxltXiEMvqCBpygowWkaNJVD,skey='-'):
  if ePrAzmGxltXiEMvqCBpygowWkaNJVD=='ALL':
   try:
    ePrAzmGxltXiEMvqCBpygowWkaNJVQ=ePrAzmGxltXiEMvqCBpygowWkaNJKj
    fp=ePrAzmGxltXiEMvqCBpygowWkaNJLR(ePrAzmGxltXiEMvqCBpygowWkaNJVQ,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    ePrAzmGxltXiEMvqCBpygowWkaNJLI
  elif ePrAzmGxltXiEMvqCBpygowWkaNJVD=='ONE':
   try:
    ePrAzmGxltXiEMvqCBpygowWkaNJVQ=ePrAzmGxltXiEMvqCBpygowWkaNJKj
    ePrAzmGxltXiEMvqCBpygowWkaNJVu=ePrAzmGxltXiEMvqCBpygowWkaNJKT.Load_List_File('search') 
    fp=ePrAzmGxltXiEMvqCBpygowWkaNJLR(ePrAzmGxltXiEMvqCBpygowWkaNJVQ,'w',-1,'utf-8')
    for ePrAzmGxltXiEMvqCBpygowWkaNJjh in ePrAzmGxltXiEMvqCBpygowWkaNJVu:
     if skey!=ePrAzmGxltXiEMvqCBpygowWkaNJjh.strip():
      fp.write(ePrAzmGxltXiEMvqCBpygowWkaNJjh)
    fp.close()
   except:
    ePrAzmGxltXiEMvqCBpygowWkaNJLI
  elif ePrAzmGxltXiEMvqCBpygowWkaNJVD in['tvshow','movie']:
   try:
    ePrAzmGxltXiEMvqCBpygowWkaNJVQ=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%ePrAzmGxltXiEMvqCBpygowWkaNJVD))
    fp=ePrAzmGxltXiEMvqCBpygowWkaNJLR(ePrAzmGxltXiEMvqCBpygowWkaNJVQ,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    ePrAzmGxltXiEMvqCBpygowWkaNJLI
 def dp_Watch_List(ePrAzmGxltXiEMvqCBpygowWkaNJKT,args):
  ePrAzmGxltXiEMvqCBpygowWkaNJVD =args.get('stype')
  if ePrAzmGxltXiEMvqCBpygowWkaNJVD in['',ePrAzmGxltXiEMvqCBpygowWkaNJLI]:
   for ePrAzmGxltXiEMvqCBpygowWkaNJjD in ePrAzmGxltXiEMvqCBpygowWkaNJKI:
    ePrAzmGxltXiEMvqCBpygowWkaNJSI=ePrAzmGxltXiEMvqCBpygowWkaNJjD.get('title')
    ePrAzmGxltXiEMvqCBpygowWkaNJSH={'mode':ePrAzmGxltXiEMvqCBpygowWkaNJjD.get('mode'),'stype':ePrAzmGxltXiEMvqCBpygowWkaNJjD.get('stype'),}
    ePrAzmGxltXiEMvqCBpygowWkaNJKT.add_dir(ePrAzmGxltXiEMvqCBpygowWkaNJSI,sublabel='',img='',infoLabels=ePrAzmGxltXiEMvqCBpygowWkaNJLI,isFolder=ePrAzmGxltXiEMvqCBpygowWkaNJLj,params=ePrAzmGxltXiEMvqCBpygowWkaNJSH)
   xbmcplugin.endOfDirectory(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle)
  else:
   ePrAzmGxltXiEMvqCBpygowWkaNJjf=ePrAzmGxltXiEMvqCBpygowWkaNJKT.Load_List_File(ePrAzmGxltXiEMvqCBpygowWkaNJVD)
   for ePrAzmGxltXiEMvqCBpygowWkaNJjc in ePrAzmGxltXiEMvqCBpygowWkaNJjf:
    ePrAzmGxltXiEMvqCBpygowWkaNJjF=ePrAzmGxltXiEMvqCBpygowWkaNJLn(urllib.parse.parse_qsl(ePrAzmGxltXiEMvqCBpygowWkaNJjc))
    ePrAzmGxltXiEMvqCBpygowWkaNJIO =ePrAzmGxltXiEMvqCBpygowWkaNJjF.get('code').strip()
    ePrAzmGxltXiEMvqCBpygowWkaNJSI =ePrAzmGxltXiEMvqCBpygowWkaNJjF.get('title').strip()
    ePrAzmGxltXiEMvqCBpygowWkaNJhn =ePrAzmGxltXiEMvqCBpygowWkaNJjF.get('img').strip()
    ePrAzmGxltXiEMvqCBpygowWkaNJhH =ePrAzmGxltXiEMvqCBpygowWkaNJjF.get('asis').strip()
    try:
     ePrAzmGxltXiEMvqCBpygowWkaNJhn=ePrAzmGxltXiEMvqCBpygowWkaNJhn.replace('\'','\"')
     ePrAzmGxltXiEMvqCBpygowWkaNJhn=json.loads(ePrAzmGxltXiEMvqCBpygowWkaNJhn)
    except:
     ePrAzmGxltXiEMvqCBpygowWkaNJLI
    ePrAzmGxltXiEMvqCBpygowWkaNJhj={}
    ePrAzmGxltXiEMvqCBpygowWkaNJhj['plot']=ePrAzmGxltXiEMvqCBpygowWkaNJSI
    if ePrAzmGxltXiEMvqCBpygowWkaNJVD=='movie':
     ePrAzmGxltXiEMvqCBpygowWkaNJhj['mediatype']='movie'
     ePrAzmGxltXiEMvqCBpygowWkaNJSH={'mode':'MOVIE','id':ePrAzmGxltXiEMvqCBpygowWkaNJIO,'asis':ePrAzmGxltXiEMvqCBpygowWkaNJhH,'title':ePrAzmGxltXiEMvqCBpygowWkaNJSI,'thumbnail':ePrAzmGxltXiEMvqCBpygowWkaNJhn,}
     ePrAzmGxltXiEMvqCBpygowWkaNJSU=ePrAzmGxltXiEMvqCBpygowWkaNJLV
    else:
     ePrAzmGxltXiEMvqCBpygowWkaNJhj['mediatype']='episode'
     ePrAzmGxltXiEMvqCBpygowWkaNJSH={'mode':'SEASON_LIST','id':ePrAzmGxltXiEMvqCBpygowWkaNJIO,'asis':ePrAzmGxltXiEMvqCBpygowWkaNJhH,'title':ePrAzmGxltXiEMvqCBpygowWkaNJSI,'thumbnail':json.dumps(ePrAzmGxltXiEMvqCBpygowWkaNJhn,separators=(',',':')),}
     ePrAzmGxltXiEMvqCBpygowWkaNJSU=ePrAzmGxltXiEMvqCBpygowWkaNJLj
    ePrAzmGxltXiEMvqCBpygowWkaNJjH={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','skey':ePrAzmGxltXiEMvqCBpygowWkaNJIO,'vType':ePrAzmGxltXiEMvqCBpygowWkaNJVD,}
    ePrAzmGxltXiEMvqCBpygowWkaNJjU=urllib.parse.urlencode(ePrAzmGxltXiEMvqCBpygowWkaNJjH)
    ePrAzmGxltXiEMvqCBpygowWkaNJIh=[('선택된 시청이력 ( %s ) 삭제'%(ePrAzmGxltXiEMvqCBpygowWkaNJSI),'RunPlugin(plugin://plugin.video.coupangm/?%s)'%(ePrAzmGxltXiEMvqCBpygowWkaNJjU))]
    ePrAzmGxltXiEMvqCBpygowWkaNJKT.add_dir(ePrAzmGxltXiEMvqCBpygowWkaNJSI,sublabel='',img=ePrAzmGxltXiEMvqCBpygowWkaNJhn,infoLabels=ePrAzmGxltXiEMvqCBpygowWkaNJhj,isFolder=ePrAzmGxltXiEMvqCBpygowWkaNJSU,params=ePrAzmGxltXiEMvqCBpygowWkaNJSH,ContextMenu=ePrAzmGxltXiEMvqCBpygowWkaNJIh)
   ePrAzmGxltXiEMvqCBpygowWkaNJhj={'plot':'시청목록을 삭제합니다.'}
   ePrAzmGxltXiEMvqCBpygowWkaNJSI='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   ePrAzmGxltXiEMvqCBpygowWkaNJSH={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':ePrAzmGxltXiEMvqCBpygowWkaNJVD,}
   ePrAzmGxltXiEMvqCBpygowWkaNJSn=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.add_dir(ePrAzmGxltXiEMvqCBpygowWkaNJSI,sublabel='',img=ePrAzmGxltXiEMvqCBpygowWkaNJSn,infoLabels=ePrAzmGxltXiEMvqCBpygowWkaNJhj,isFolder=ePrAzmGxltXiEMvqCBpygowWkaNJLV,params=ePrAzmGxltXiEMvqCBpygowWkaNJSH,isLink=ePrAzmGxltXiEMvqCBpygowWkaNJLj)
   if ePrAzmGxltXiEMvqCBpygowWkaNJVD=='movie':xbmcplugin.setContent(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,'movies')
   else:xbmcplugin.setContent(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,cacheToDisc=ePrAzmGxltXiEMvqCBpygowWkaNJLV)
 def dp_Set_Bookmark(ePrAzmGxltXiEMvqCBpygowWkaNJKT,args):
  ePrAzmGxltXiEMvqCBpygowWkaNJjO=urllib.parse.unquote(args.get('bm_param'))
  ePrAzmGxltXiEMvqCBpygowWkaNJjO=json.loads(ePrAzmGxltXiEMvqCBpygowWkaNJjO)
  ePrAzmGxltXiEMvqCBpygowWkaNJjQ =ePrAzmGxltXiEMvqCBpygowWkaNJjO.get('videoid')
  ePrAzmGxltXiEMvqCBpygowWkaNJjY =ePrAzmGxltXiEMvqCBpygowWkaNJjO.get('vidtype')
  ePrAzmGxltXiEMvqCBpygowWkaNJjb =ePrAzmGxltXiEMvqCBpygowWkaNJjO.get('vtitle')
  ePrAzmGxltXiEMvqCBpygowWkaNJKd=xbmcgui.Dialog()
  ePrAzmGxltXiEMvqCBpygowWkaNJSD=ePrAzmGxltXiEMvqCBpygowWkaNJKd.yesno(__language__(30914).encode('utf8'),ePrAzmGxltXiEMvqCBpygowWkaNJjb+' \n\n'+__language__(30915))
  if ePrAzmGxltXiEMvqCBpygowWkaNJSD==ePrAzmGxltXiEMvqCBpygowWkaNJLV:return
  ePrAzmGxltXiEMvqCBpygowWkaNJju=ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.GetBookmarkInfo(ePrAzmGxltXiEMvqCBpygowWkaNJjQ,ePrAzmGxltXiEMvqCBpygowWkaNJjY)
  ePrAzmGxltXiEMvqCBpygowWkaNJTK=json.dumps(ePrAzmGxltXiEMvqCBpygowWkaNJju)
  ePrAzmGxltXiEMvqCBpygowWkaNJTK=urllib.parse.quote(ePrAzmGxltXiEMvqCBpygowWkaNJTK)
  ePrAzmGxltXiEMvqCBpygowWkaNJIS ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(ePrAzmGxltXiEMvqCBpygowWkaNJTK)
  xbmc.executebuiltin(ePrAzmGxltXiEMvqCBpygowWkaNJIS)
 def sp_MultiHero_LiveList(ePrAzmGxltXiEMvqCBpygowWkaNJKT,args):
  ePrAzmGxltXiEMvqCBpygowWkaNJTS=ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.Sports_MultiHero_LiveList()
  for ePrAzmGxltXiEMvqCBpygowWkaNJTh in ePrAzmGxltXiEMvqCBpygowWkaNJTS:
   ePrAzmGxltXiEMvqCBpygowWkaNJLf =ePrAzmGxltXiEMvqCBpygowWkaNJTh.get('id')
   ePrAzmGxltXiEMvqCBpygowWkaNJSI =ePrAzmGxltXiEMvqCBpygowWkaNJTh.get('title')
   ePrAzmGxltXiEMvqCBpygowWkaNJTI =ePrAzmGxltXiEMvqCBpygowWkaNJTh.get('startDate')
   ePrAzmGxltXiEMvqCBpygowWkaNJTV =ePrAzmGxltXiEMvqCBpygowWkaNJTh.get('image')
   ePrAzmGxltXiEMvqCBpygowWkaNJTj =ePrAzmGxltXiEMvqCBpygowWkaNJTh.get('subType') 
   ePrAzmGxltXiEMvqCBpygowWkaNJSs=ePrAzmGxltXiEMvqCBpygowWkaNJTI
   if ePrAzmGxltXiEMvqCBpygowWkaNJTj:ePrAzmGxltXiEMvqCBpygowWkaNJSs=ePrAzmGxltXiEMvqCBpygowWkaNJSs+', '+ePrAzmGxltXiEMvqCBpygowWkaNJTj
   ePrAzmGxltXiEMvqCBpygowWkaNJhj={'mediatype':'episodes','plot':ePrAzmGxltXiEMvqCBpygowWkaNJSI,}
   ePrAzmGxltXiEMvqCBpygowWkaNJSH={'mode':'LIVE','asis':'LIVE','id':ePrAzmGxltXiEMvqCBpygowWkaNJLf,}
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.add_dir(ePrAzmGxltXiEMvqCBpygowWkaNJSI,sublabel=ePrAzmGxltXiEMvqCBpygowWkaNJSs,img=ePrAzmGxltXiEMvqCBpygowWkaNJTV,infoLabels=ePrAzmGxltXiEMvqCBpygowWkaNJhj,isFolder=ePrAzmGxltXiEMvqCBpygowWkaNJLV,params=ePrAzmGxltXiEMvqCBpygowWkaNJSH)
  xbmcplugin.setContent(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,cacheToDisc=ePrAzmGxltXiEMvqCBpygowWkaNJLV)
 def sp_Mainlist_League(ePrAzmGxltXiEMvqCBpygowWkaNJKT,args):
  ePrAzmGxltXiEMvqCBpygowWkaNJTS=ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.Sports_MultiHero_LiveList()
  if ePrAzmGxltXiEMvqCBpygowWkaNJTS:
   ePrAzmGxltXiEMvqCBpygowWkaNJSI ='@ 주요 예정경기 @'
   ePrAzmGxltXiEMvqCBpygowWkaNJTV =ePrAzmGxltXiEMvqCBpygowWkaNJTS[0]['image']
   ePrAzmGxltXiEMvqCBpygowWkaNJTL =ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.MakeText_FreeList(ePrAzmGxltXiEMvqCBpygowWkaNJTS,titleName='preTitle')
   ePrAzmGxltXiEMvqCBpygowWkaNJhj={'mediatype':'episodes','plot':ePrAzmGxltXiEMvqCBpygowWkaNJTL,}
   ePrAzmGxltXiEMvqCBpygowWkaNJSH={'mode':'SPORTS_MULT_HERO',}
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.add_dir(ePrAzmGxltXiEMvqCBpygowWkaNJSI,sublabel='',img=ePrAzmGxltXiEMvqCBpygowWkaNJTV,infoLabels=ePrAzmGxltXiEMvqCBpygowWkaNJhj,isFolder=ePrAzmGxltXiEMvqCBpygowWkaNJLj,params=ePrAzmGxltXiEMvqCBpygowWkaNJSH)
  ePrAzmGxltXiEMvqCBpygowWkaNJTn=ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.Sports_Mainlist_League()
  for ePrAzmGxltXiEMvqCBpygowWkaNJTH in ePrAzmGxltXiEMvqCBpygowWkaNJTn:
   ePrAzmGxltXiEMvqCBpygowWkaNJTU =ePrAzmGxltXiEMvqCBpygowWkaNJTH.get('league_id') 
   ePrAzmGxltXiEMvqCBpygowWkaNJTd=ePrAzmGxltXiEMvqCBpygowWkaNJTH.get('league_name')
   ePrAzmGxltXiEMvqCBpygowWkaNJTR =ePrAzmGxltXiEMvqCBpygowWkaNJTH.get('logoUrl')
   ePrAzmGxltXiEMvqCBpygowWkaNJhj={'mediatype':'episodes','plot':ePrAzmGxltXiEMvqCBpygowWkaNJTd,}
   ePrAzmGxltXiEMvqCBpygowWkaNJSH={'mode':'SPORTS_LEAGUE_FEEDLIST','league_id':ePrAzmGxltXiEMvqCBpygowWkaNJTU,'league_name':ePrAzmGxltXiEMvqCBpygowWkaNJTd,}
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.add_dir(ePrAzmGxltXiEMvqCBpygowWkaNJTd,sublabel='',img=ePrAzmGxltXiEMvqCBpygowWkaNJTR,infoLabels=ePrAzmGxltXiEMvqCBpygowWkaNJhj,isFolder=ePrAzmGxltXiEMvqCBpygowWkaNJLj,params=ePrAzmGxltXiEMvqCBpygowWkaNJSH)
  xbmcplugin.setContent(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,cacheToDisc=ePrAzmGxltXiEMvqCBpygowWkaNJLV)
 def sp_League_FeedList(ePrAzmGxltXiEMvqCBpygowWkaNJKT,args):
  ePrAzmGxltXiEMvqCBpygowWkaNJTU =args.get('league_id')
  ePrAzmGxltXiEMvqCBpygowWkaNJTd=args.get('league_name')
  ePrAzmGxltXiEMvqCBpygowWkaNJTs=ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.Sports_League_FeedList(ePrAzmGxltXiEMvqCBpygowWkaNJTU)
  for ePrAzmGxltXiEMvqCBpygowWkaNJTH in ePrAzmGxltXiEMvqCBpygowWkaNJTs:
   ePrAzmGxltXiEMvqCBpygowWkaNJTD=ePrAzmGxltXiEMvqCBpygowWkaNJTH.get('row_name')
   ePrAzmGxltXiEMvqCBpygowWkaNJTL =ePrAzmGxltXiEMvqCBpygowWkaNJTH.get('preText')
   ePrAzmGxltXiEMvqCBpygowWkaNJTf =ePrAzmGxltXiEMvqCBpygowWkaNJTH.get('subMode')
   ePrAzmGxltXiEMvqCBpygowWkaNJTc =ePrAzmGxltXiEMvqCBpygowWkaNJTH.get('gameID')
   ePrAzmGxltXiEMvqCBpygowWkaNJTV =ePrAzmGxltXiEMvqCBpygowWkaNJTH.get('image')
   ePrAzmGxltXiEMvqCBpygowWkaNJhj={'mediatype':'episodes','plot':ePrAzmGxltXiEMvqCBpygowWkaNJTd+'\n\n'+ePrAzmGxltXiEMvqCBpygowWkaNJTL,}
   ePrAzmGxltXiEMvqCBpygowWkaNJSH={'mode':'SPORTS_FEED_VOD','subMode':ePrAzmGxltXiEMvqCBpygowWkaNJTf,'league_id':ePrAzmGxltXiEMvqCBpygowWkaNJTU,'game_id':ePrAzmGxltXiEMvqCBpygowWkaNJTc,}
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.add_dir(ePrAzmGxltXiEMvqCBpygowWkaNJTD,sublabel='',img=ePrAzmGxltXiEMvqCBpygowWkaNJTV,infoLabels=ePrAzmGxltXiEMvqCBpygowWkaNJhj,isFolder=ePrAzmGxltXiEMvqCBpygowWkaNJLj,params=ePrAzmGxltXiEMvqCBpygowWkaNJSH)
  ePrAzmGxltXiEMvqCBpygowWkaNJSI='@ 시즌별 동영상 @'
  ePrAzmGxltXiEMvqCBpygowWkaNJhj={'mediatype':'episodes','plot':ePrAzmGxltXiEMvqCBpygowWkaNJSI,}
  ePrAzmGxltXiEMvqCBpygowWkaNJSH={'mode':'SPORTS_SEASON_GROUP','league_id':ePrAzmGxltXiEMvqCBpygowWkaNJTU,}
  ePrAzmGxltXiEMvqCBpygowWkaNJKT.add_dir(ePrAzmGxltXiEMvqCBpygowWkaNJSI,sublabel='',img=ePrAzmGxltXiEMvqCBpygowWkaNJLI,infoLabels=ePrAzmGxltXiEMvqCBpygowWkaNJhj,isFolder=ePrAzmGxltXiEMvqCBpygowWkaNJLj,params=ePrAzmGxltXiEMvqCBpygowWkaNJSH)
  xbmcplugin.setContent(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,cacheToDisc=ePrAzmGxltXiEMvqCBpygowWkaNJLV)
 def sp_League_VodList(ePrAzmGxltXiEMvqCBpygowWkaNJKT,args):
  ePrAzmGxltXiEMvqCBpygowWkaNJTf =args.get('subMode')
  ePrAzmGxltXiEMvqCBpygowWkaNJTU =args.get('league_id')
  ePrAzmGxltXiEMvqCBpygowWkaNJTF =args.get('game_id')
  ePrAzmGxltXiEMvqCBpygowWkaNJKT.addon_log('{} - {}'.format('subMode  ',ePrAzmGxltXiEMvqCBpygowWkaNJTf))
  ePrAzmGxltXiEMvqCBpygowWkaNJKT.addon_log('{} - {}'.format('league_id',ePrAzmGxltXiEMvqCBpygowWkaNJTU))
  ePrAzmGxltXiEMvqCBpygowWkaNJKT.addon_log('{} - {}'.format('game_id  ',ePrAzmGxltXiEMvqCBpygowWkaNJTF))
  ePrAzmGxltXiEMvqCBpygowWkaNJTO=ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.Sports_League_VodList(ePrAzmGxltXiEMvqCBpygowWkaNJTf,ePrAzmGxltXiEMvqCBpygowWkaNJTU,ePrAzmGxltXiEMvqCBpygowWkaNJTF)
  for ePrAzmGxltXiEMvqCBpygowWkaNJTH in ePrAzmGxltXiEMvqCBpygowWkaNJTO:
   ePrAzmGxltXiEMvqCBpygowWkaNJLf =ePrAzmGxltXiEMvqCBpygowWkaNJTH.get('id')
   ePrAzmGxltXiEMvqCBpygowWkaNJSI =ePrAzmGxltXiEMvqCBpygowWkaNJTH.get('title')
   ePrAzmGxltXiEMvqCBpygowWkaNJTV =ePrAzmGxltXiEMvqCBpygowWkaNJTH.get('image')
   ePrAzmGxltXiEMvqCBpygowWkaNJTI =ePrAzmGxltXiEMvqCBpygowWkaNJTH.get('startDate')
   ePrAzmGxltXiEMvqCBpygowWkaNJTj =ePrAzmGxltXiEMvqCBpygowWkaNJTH.get('subType')
   ePrAzmGxltXiEMvqCBpygowWkaNJTQ=ePrAzmGxltXiEMvqCBpygowWkaNJTH.get('running_time')
   ePrAzmGxltXiEMvqCBpygowWkaNJhj={'mediatype':'episodes','plot':ePrAzmGxltXiEMvqCBpygowWkaNJSI,'duration':ePrAzmGxltXiEMvqCBpygowWkaNJTQ,}
   if ePrAzmGxltXiEMvqCBpygowWkaNJTf=='SP_FEED_LIVE':
    ePrAzmGxltXiEMvqCBpygowWkaNJSH={'mode':'LIVE','asis':'LIVE','id':ePrAzmGxltXiEMvqCBpygowWkaNJLf,}
    ePrAzmGxltXiEMvqCBpygowWkaNJSs=ePrAzmGxltXiEMvqCBpygowWkaNJTI
    if ePrAzmGxltXiEMvqCBpygowWkaNJTj:ePrAzmGxltXiEMvqCBpygowWkaNJSs=ePrAzmGxltXiEMvqCBpygowWkaNJSs+', '+ePrAzmGxltXiEMvqCBpygowWkaNJTj
   elif ePrAzmGxltXiEMvqCBpygowWkaNJTf in['SP_FEED_TOP10','SP_FEED_GAME']:
    ePrAzmGxltXiEMvqCBpygowWkaNJSH={'mode':'HIGHLIGHT','asis':'HIGHLIGHT','id':ePrAzmGxltXiEMvqCBpygowWkaNJLf,}
    ePrAzmGxltXiEMvqCBpygowWkaNJSs=ePrAzmGxltXiEMvqCBpygowWkaNJTj
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.add_dir(ePrAzmGxltXiEMvqCBpygowWkaNJSI,sublabel=ePrAzmGxltXiEMvqCBpygowWkaNJSs,img=ePrAzmGxltXiEMvqCBpygowWkaNJTV,infoLabels=ePrAzmGxltXiEMvqCBpygowWkaNJhj,isFolder=ePrAzmGxltXiEMvqCBpygowWkaNJLV,params=ePrAzmGxltXiEMvqCBpygowWkaNJSH)
  xbmcplugin.setContent(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,cacheToDisc=ePrAzmGxltXiEMvqCBpygowWkaNJLV)
 def sp_Season_Group(ePrAzmGxltXiEMvqCBpygowWkaNJKT,args):
  ePrAzmGxltXiEMvqCBpygowWkaNJTU =args.get('league_id')
  ePrAzmGxltXiEMvqCBpygowWkaNJTY=ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.Sports_Season_Group(ePrAzmGxltXiEMvqCBpygowWkaNJTU)
  for ePrAzmGxltXiEMvqCBpygowWkaNJTH in ePrAzmGxltXiEMvqCBpygowWkaNJTY:
   ePrAzmGxltXiEMvqCBpygowWkaNJIU =ePrAzmGxltXiEMvqCBpygowWkaNJTH.get('season')
   ePrAzmGxltXiEMvqCBpygowWkaNJTL =ePrAzmGxltXiEMvqCBpygowWkaNJTH.get('preText')
   ePrAzmGxltXiEMvqCBpygowWkaNJhj={'mediatype':'episodes','plot':ePrAzmGxltXiEMvqCBpygowWkaNJTL,}
   ePrAzmGxltXiEMvqCBpygowWkaNJSH={'mode':'SPORTS_SEASON_GAMELIST','leagueID':ePrAzmGxltXiEMvqCBpygowWkaNJTU,'seasonID':ePrAzmGxltXiEMvqCBpygowWkaNJIU,'page':'1',}
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.add_dir(ePrAzmGxltXiEMvqCBpygowWkaNJIU,sublabel=ePrAzmGxltXiEMvqCBpygowWkaNJLI,img=ePrAzmGxltXiEMvqCBpygowWkaNJLI,infoLabels=ePrAzmGxltXiEMvqCBpygowWkaNJhj,isFolder=ePrAzmGxltXiEMvqCBpygowWkaNJLj,params=ePrAzmGxltXiEMvqCBpygowWkaNJSH)
  xbmcplugin.setContent(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,cacheToDisc=ePrAzmGxltXiEMvqCBpygowWkaNJLV)
 def sp_Season_GameList(ePrAzmGxltXiEMvqCBpygowWkaNJKT,args):
  ePrAzmGxltXiEMvqCBpygowWkaNJTb =args.get('leagueID')
  ePrAzmGxltXiEMvqCBpygowWkaNJTu =args.get('seasonID')
  ePrAzmGxltXiEMvqCBpygowWkaNJhD =ePrAzmGxltXiEMvqCBpygowWkaNJLU(args.get('page'))
  ePrAzmGxltXiEMvqCBpygowWkaNJLK=ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.Sports_Season_GameList(ePrAzmGxltXiEMvqCBpygowWkaNJTb,ePrAzmGxltXiEMvqCBpygowWkaNJTu,ePrAzmGxltXiEMvqCBpygowWkaNJhD)
  ePrAzmGxltXiEMvqCBpygowWkaNJLS=ePrAzmGxltXiEMvqCBpygowWkaNJLc(ePrAzmGxltXiEMvqCBpygowWkaNJLK)
  for ePrAzmGxltXiEMvqCBpygowWkaNJTH in ePrAzmGxltXiEMvqCBpygowWkaNJLK:
   ePrAzmGxltXiEMvqCBpygowWkaNJTc =ePrAzmGxltXiEMvqCBpygowWkaNJTH.get('id')
   ePrAzmGxltXiEMvqCBpygowWkaNJSI =ePrAzmGxltXiEMvqCBpygowWkaNJTH.get('title')
   ePrAzmGxltXiEMvqCBpygowWkaNJTI =ePrAzmGxltXiEMvqCBpygowWkaNJTH.get('startDate')
   ePrAzmGxltXiEMvqCBpygowWkaNJTL =ePrAzmGxltXiEMvqCBpygowWkaNJTH.get('preText')
   ePrAzmGxltXiEMvqCBpygowWkaNJTV =ePrAzmGxltXiEMvqCBpygowWkaNJTH.get('image')
   ePrAzmGxltXiEMvqCBpygowWkaNJhj={'mediatype':'episodes','plot':ePrAzmGxltXiEMvqCBpygowWkaNJTL,}
   ePrAzmGxltXiEMvqCBpygowWkaNJSH={'mode':'SPORTS_SEASON_VODLIST','leagueID':ePrAzmGxltXiEMvqCBpygowWkaNJTb,'seasonID':ePrAzmGxltXiEMvqCBpygowWkaNJTu,'gameID':ePrAzmGxltXiEMvqCBpygowWkaNJTc,'page':args.get('page'),}
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.add_dir(ePrAzmGxltXiEMvqCBpygowWkaNJSI,sublabel=ePrAzmGxltXiEMvqCBpygowWkaNJTI,img=ePrAzmGxltXiEMvqCBpygowWkaNJTV,infoLabels=ePrAzmGxltXiEMvqCBpygowWkaNJhj,isFolder=ePrAzmGxltXiEMvqCBpygowWkaNJLj,params=ePrAzmGxltXiEMvqCBpygowWkaNJSH)
  if ePrAzmGxltXiEMvqCBpygowWkaNJLS>=10:
   ePrAzmGxltXiEMvqCBpygowWkaNJSH['mode'] ='SPORTS_SEASON_GAMELIST' 
   ePrAzmGxltXiEMvqCBpygowWkaNJSH['leagueID']=ePrAzmGxltXiEMvqCBpygowWkaNJTb
   ePrAzmGxltXiEMvqCBpygowWkaNJSH['seasonID']=ePrAzmGxltXiEMvqCBpygowWkaNJTu
   ePrAzmGxltXiEMvqCBpygowWkaNJSH['page'] =ePrAzmGxltXiEMvqCBpygowWkaNJLD(ePrAzmGxltXiEMvqCBpygowWkaNJhD+1)
   ePrAzmGxltXiEMvqCBpygowWkaNJSI='[B]%s >>[/B]'%'다음 페이지'
   ePrAzmGxltXiEMvqCBpygowWkaNJIV=ePrAzmGxltXiEMvqCBpygowWkaNJLD(ePrAzmGxltXiEMvqCBpygowWkaNJhD+1)
   ePrAzmGxltXiEMvqCBpygowWkaNJSn=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.add_dir(ePrAzmGxltXiEMvqCBpygowWkaNJSI,sublabel=ePrAzmGxltXiEMvqCBpygowWkaNJIV,img=ePrAzmGxltXiEMvqCBpygowWkaNJSn,infoLabels=ePrAzmGxltXiEMvqCBpygowWkaNJLI,isFolder=ePrAzmGxltXiEMvqCBpygowWkaNJLj,params=ePrAzmGxltXiEMvqCBpygowWkaNJSH)
  xbmcplugin.setContent(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,cacheToDisc=ePrAzmGxltXiEMvqCBpygowWkaNJLV)
 def sp_Season_VodList(ePrAzmGxltXiEMvqCBpygowWkaNJKT,args):
  ePrAzmGxltXiEMvqCBpygowWkaNJTb =args.get('leagueID')
  ePrAzmGxltXiEMvqCBpygowWkaNJTu =args.get('seasonID')
  ePrAzmGxltXiEMvqCBpygowWkaNJhD =ePrAzmGxltXiEMvqCBpygowWkaNJLU(args.get('page'))
  ePrAzmGxltXiEMvqCBpygowWkaNJTc =args.get('gameID')
  ePrAzmGxltXiEMvqCBpygowWkaNJTO=ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.Sports_Season_GameVod(ePrAzmGxltXiEMvqCBpygowWkaNJTb,ePrAzmGxltXiEMvqCBpygowWkaNJTu,ePrAzmGxltXiEMvqCBpygowWkaNJhD,ePrAzmGxltXiEMvqCBpygowWkaNJTc)
  for ePrAzmGxltXiEMvqCBpygowWkaNJTH in ePrAzmGxltXiEMvqCBpygowWkaNJTO:
   ePrAzmGxltXiEMvqCBpygowWkaNJLf =ePrAzmGxltXiEMvqCBpygowWkaNJTH.get('id')
   ePrAzmGxltXiEMvqCBpygowWkaNJSI =ePrAzmGxltXiEMvqCBpygowWkaNJTH.get('title')
   ePrAzmGxltXiEMvqCBpygowWkaNJTV =ePrAzmGxltXiEMvqCBpygowWkaNJTH.get('image')
   ePrAzmGxltXiEMvqCBpygowWkaNJTj =ePrAzmGxltXiEMvqCBpygowWkaNJTH.get('subType')
   ePrAzmGxltXiEMvqCBpygowWkaNJTQ=ePrAzmGxltXiEMvqCBpygowWkaNJTH.get('running_time')
   ePrAzmGxltXiEMvqCBpygowWkaNJhj={'mediatype':'episodes','plot':ePrAzmGxltXiEMvqCBpygowWkaNJSI,'duration':ePrAzmGxltXiEMvqCBpygowWkaNJTQ,}
   ePrAzmGxltXiEMvqCBpygowWkaNJSH={'mode':'HIGHLIGHT','asis':'HIGHLIGHT','id':ePrAzmGxltXiEMvqCBpygowWkaNJLf,}
   ePrAzmGxltXiEMvqCBpygowWkaNJSs=ePrAzmGxltXiEMvqCBpygowWkaNJTj
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.add_dir(ePrAzmGxltXiEMvqCBpygowWkaNJSI,sublabel=ePrAzmGxltXiEMvqCBpygowWkaNJSs,img=ePrAzmGxltXiEMvqCBpygowWkaNJTV,infoLabels=ePrAzmGxltXiEMvqCBpygowWkaNJhj,isFolder=ePrAzmGxltXiEMvqCBpygowWkaNJLV,params=ePrAzmGxltXiEMvqCBpygowWkaNJSH)
  xbmcplugin.setContent(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(ePrAzmGxltXiEMvqCBpygowWkaNJKT._addon_handle,cacheToDisc=ePrAzmGxltXiEMvqCBpygowWkaNJLV)
 def coupang_main(ePrAzmGxltXiEMvqCBpygowWkaNJKT):
  ePrAzmGxltXiEMvqCBpygowWkaNJKT.CoupangObj.KodiVersion=ePrAzmGxltXiEMvqCBpygowWkaNJLU(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  ePrAzmGxltXiEMvqCBpygowWkaNJhb=ePrAzmGxltXiEMvqCBpygowWkaNJKT.main_params.get('mode',ePrAzmGxltXiEMvqCBpygowWkaNJLI)
  if ePrAzmGxltXiEMvqCBpygowWkaNJhb=='LOGOUT':
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.CP_logout()
   return
  ePrAzmGxltXiEMvqCBpygowWkaNJKT.option_check()
  if ePrAzmGxltXiEMvqCBpygowWkaNJhb is ePrAzmGxltXiEMvqCBpygowWkaNJLI:
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.dp_Main_List(ePrAzmGxltXiEMvqCBpygowWkaNJKT.main_params)
  elif ePrAzmGxltXiEMvqCBpygowWkaNJhb=='CATEGORY_GROUPLIST':
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.dp_Category_GroupList(ePrAzmGxltXiEMvqCBpygowWkaNJKT.main_params)
  elif ePrAzmGxltXiEMvqCBpygowWkaNJhb=='THEME_GROUPLIST':
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.dp_Theme_GroupList(ePrAzmGxltXiEMvqCBpygowWkaNJKT.main_params)
  elif ePrAzmGxltXiEMvqCBpygowWkaNJhb=='EVENT_GROUPLIST':
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.dp_Event_GroupList(ePrAzmGxltXiEMvqCBpygowWkaNJKT.main_params)
  elif ePrAzmGxltXiEMvqCBpygowWkaNJhb=='EVENT_GAMELIST':
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.dp_Event_GameList(ePrAzmGxltXiEMvqCBpygowWkaNJKT.main_params)
  elif ePrAzmGxltXiEMvqCBpygowWkaNJhb=='EVENT_LIST':
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.dp_Event_List(ePrAzmGxltXiEMvqCBpygowWkaNJKT.main_params)
  elif ePrAzmGxltXiEMvqCBpygowWkaNJhb=='CATEGORY_LIST':
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.dp_Category_List(ePrAzmGxltXiEMvqCBpygowWkaNJKT.main_params)
  elif ePrAzmGxltXiEMvqCBpygowWkaNJhb=='SEASON_LIST':
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.dp_Season_List(ePrAzmGxltXiEMvqCBpygowWkaNJKT.main_params)
  elif ePrAzmGxltXiEMvqCBpygowWkaNJhb=='EPISODE_LIST':
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.dp_Episode_List(ePrAzmGxltXiEMvqCBpygowWkaNJKT.main_params)
  elif ePrAzmGxltXiEMvqCBpygowWkaNJhb=='TEST':
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.dp_Test(ePrAzmGxltXiEMvqCBpygowWkaNJKT.main_params)
  elif ePrAzmGxltXiEMvqCBpygowWkaNJhb in['MOVIE','VOD','HIGHLIGHT','LIVE']:
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.play_VIDEO(ePrAzmGxltXiEMvqCBpygowWkaNJKT.main_params)
  elif ePrAzmGxltXiEMvqCBpygowWkaNJhb=='WATCH':
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.dp_Watch_List(ePrAzmGxltXiEMvqCBpygowWkaNJKT.main_params)
  elif ePrAzmGxltXiEMvqCBpygowWkaNJhb=='LOCAL_SEARCH':
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.dp_Search_List(ePrAzmGxltXiEMvqCBpygowWkaNJKT.main_params)
  elif ePrAzmGxltXiEMvqCBpygowWkaNJhb=='SEARCH_HISTORY':
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.dp_Search_History(ePrAzmGxltXiEMvqCBpygowWkaNJKT.main_params)
  elif ePrAzmGxltXiEMvqCBpygowWkaNJhb in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.dp_Listfile_Delete(ePrAzmGxltXiEMvqCBpygowWkaNJKT.main_params)
  elif ePrAzmGxltXiEMvqCBpygowWkaNJhb in['TOTAL_SEARCH','TOTAL_HISTORY']:
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.dp_Global_Search(ePrAzmGxltXiEMvqCBpygowWkaNJKT.main_params)
  elif ePrAzmGxltXiEMvqCBpygowWkaNJhb=='MENU_BOOKMARK':
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.dp_Bookmark_Menu(ePrAzmGxltXiEMvqCBpygowWkaNJKT.main_params)
  elif ePrAzmGxltXiEMvqCBpygowWkaNJhb=='SET_BOOKMARK':
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.dp_Set_Bookmark(ePrAzmGxltXiEMvqCBpygowWkaNJKT.main_params)
  elif ePrAzmGxltXiEMvqCBpygowWkaNJhb=='SPORTS_MAINLIST_LEAGUE':
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.sp_Mainlist_League(ePrAzmGxltXiEMvqCBpygowWkaNJKT.main_params)
  elif ePrAzmGxltXiEMvqCBpygowWkaNJhb=='SPORTS_LEAGUE_FEEDLIST':
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.sp_League_FeedList(ePrAzmGxltXiEMvqCBpygowWkaNJKT.main_params)
  elif ePrAzmGxltXiEMvqCBpygowWkaNJhb=='SPORTS_FEED_VOD':
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.sp_League_VodList(ePrAzmGxltXiEMvqCBpygowWkaNJKT.main_params)
  elif ePrAzmGxltXiEMvqCBpygowWkaNJhb=='SPORTS_MULT_HERO':
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.sp_MultiHero_LiveList(ePrAzmGxltXiEMvqCBpygowWkaNJKT.main_params)
  elif ePrAzmGxltXiEMvqCBpygowWkaNJhb=='SPORTS_SEASON_GROUP':
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.sp_Season_Group(ePrAzmGxltXiEMvqCBpygowWkaNJKT.main_params)
  elif ePrAzmGxltXiEMvqCBpygowWkaNJhb=='SPORTS_SEASON_GAMELIST':
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.sp_Season_GameList(ePrAzmGxltXiEMvqCBpygowWkaNJKT.main_params)
  elif ePrAzmGxltXiEMvqCBpygowWkaNJhb=='SPORTS_SEASON_VODLIST':
   ePrAzmGxltXiEMvqCBpygowWkaNJKT.sp_Season_VodList(ePrAzmGxltXiEMvqCBpygowWkaNJKT.main_params)
  else:
   ePrAzmGxltXiEMvqCBpygowWkaNJLI
# Created by pyminifier (https://github.com/liftoff/pyminifier)
