__author__="NightRain"
LEwTuRWoKVFbrBfInQYNXDsPOHkhmM=object
LEwTuRWoKVFbrBfInQYNXDsPOHkhmA=None
LEwTuRWoKVFbrBfInQYNXDsPOHkhmy=False
LEwTuRWoKVFbrBfInQYNXDsPOHkhmU=print
LEwTuRWoKVFbrBfInQYNXDsPOHkhmv=str
LEwTuRWoKVFbrBfInQYNXDsPOHkhmp=open
LEwTuRWoKVFbrBfInQYNXDsPOHkhmc=int
LEwTuRWoKVFbrBfInQYNXDsPOHkhma=Exception
LEwTuRWoKVFbrBfInQYNXDsPOHkhmJ=len
LEwTuRWoKVFbrBfInQYNXDsPOHkhtg=id
LEwTuRWoKVFbrBfInQYNXDsPOHkhtz=True
LEwTuRWoKVFbrBfInQYNXDsPOHkhtG=range
import urllib
import re
import json
import requests
import datetime
import time
import random
import base64
LEwTuRWoKVFbrBfInQYNXDsPOHkhgG={'LONG_HIGHLIGHT':'하이라이트','SHORT_HIGHLIGHT':'하이라이트','PREVIEW':'프리뷰','FULL_MATCH':'다시보기','KEY_MOMENT':'','OTHER':'프로그램',}
class LEwTuRWoKVFbrBfInQYNXDsPOHkhgz(LEwTuRWoKVFbrBfInQYNXDsPOHkhmM):
 def __init__(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd):
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.MODEL ='Chrome_128' 
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.OS_VERSION ='128' 
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.DEFAULT_HEADER ={'user-agent':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.USER_AGENT}
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.API_DOMAIN ='https://www.coupangplay.com'
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.API_VIEWURL ='https://discover.coupangstreaming.com'
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.PAGE_LIMIT =40
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.SEARCH_LIMIT =20
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.KodiVersion =20
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP={}
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.Init_CP()
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP_DEVICE_FILENAME=''
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP_COOKIE_FILENAME=''
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP_SESSION_COOKIES1=''
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP_SESSION_COOKIES2=''
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP_SESSION_COOKIES3=''
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP_SESSION_COOKIES4=''
 def callRequestCookies(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,jobtype,LEwTuRWoKVFbrBfInQYNXDsPOHkhzl,payload=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,params=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,headers=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,cookies=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,redirects=LEwTuRWoKVFbrBfInQYNXDsPOHkhmy):
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgm=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.DEFAULT_HEADER
  if headers:LEwTuRWoKVFbrBfInQYNXDsPOHkhgm.update(headers)
  if jobtype=='Get':
   LEwTuRWoKVFbrBfInQYNXDsPOHkhgt=requests.get(LEwTuRWoKVFbrBfInQYNXDsPOHkhzl,params=params,headers=LEwTuRWoKVFbrBfInQYNXDsPOHkhgm,cookies=cookies,allow_redirects=redirects)
  else:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhgt=requests.post(LEwTuRWoKVFbrBfInQYNXDsPOHkhzl,data=payload,params=params,headers=LEwTuRWoKVFbrBfInQYNXDsPOHkhgm,cookies=cookies,allow_redirects=redirects)
  LEwTuRWoKVFbrBfInQYNXDsPOHkhmU(LEwTuRWoKVFbrBfInQYNXDsPOHkhmv(LEwTuRWoKVFbrBfInQYNXDsPOHkhgt.status_code)+' - '+LEwTuRWoKVFbrBfInQYNXDsPOHkhmv(LEwTuRWoKVFbrBfInQYNXDsPOHkhgt.url))
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhgt
 def callRequestCookies_test(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,jobtype,LEwTuRWoKVFbrBfInQYNXDsPOHkhzl,payload=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,params=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,headers=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,cookies=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,redirects=LEwTuRWoKVFbrBfInQYNXDsPOHkhmy):
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgm=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.DEFAULT_HEADER
  if headers:LEwTuRWoKVFbrBfInQYNXDsPOHkhgm.update(headers)
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgt=requests.Request('POST',LEwTuRWoKVFbrBfInQYNXDsPOHkhzl,headers=headers,data=payload,params=params,cookies=cookies)
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgx=LEwTuRWoKVFbrBfInQYNXDsPOHkhgt.prepare()
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.pretty_print_POST(LEwTuRWoKVFbrBfInQYNXDsPOHkhgx)
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhgt
 def pretty_print_POST(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,req):
  LEwTuRWoKVFbrBfInQYNXDsPOHkhmU('{}\n{}\r\n{}\r\n\r\n{}'.format('-----------START-----------',req.method+' '+req.url,'\r\n'.join('{}: {}'.format(k,v)for k,v in req.headers.items()),req.body,))
 def dic_To_jsonfile(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,filename,LEwTuRWoKVFbrBfInQYNXDsPOHkhgq):
  if filename=='':return
  fp=LEwTuRWoKVFbrBfInQYNXDsPOHkhmp(filename,'w',-1,'utf-8')
  json.dump(LEwTuRWoKVFbrBfInQYNXDsPOHkhgq,fp,indent=4,ensure_ascii=LEwTuRWoKVFbrBfInQYNXDsPOHkhmy)
  fp.close()
 def jsonfile_To_dic(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,filename):
  if filename=='':return LEwTuRWoKVFbrBfInQYNXDsPOHkhmA
  try:
   fp=LEwTuRWoKVFbrBfInQYNXDsPOHkhmp(filename,'r',-1,'utf-8')
   LEwTuRWoKVFbrBfInQYNXDsPOHkhgC=json.load(fp)
   fp.close()
  except:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhgC={}
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhgC
 def convert_TimeStr(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,LEwTuRWoKVFbrBfInQYNXDsPOHkhgl):
  try:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhgl =LEwTuRWoKVFbrBfInQYNXDsPOHkhgl[0:16]
   LEwTuRWoKVFbrBfInQYNXDsPOHkhgi=datetime.datetime.strptime(LEwTuRWoKVFbrBfInQYNXDsPOHkhgl,'%Y-%m-%dT%H:%M')+datetime.timedelta(hours=9)
   LEwTuRWoKVFbrBfInQYNXDsPOHkhgj=LEwTuRWoKVFbrBfInQYNXDsPOHkhgi.weekday()
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhgj==0:LEwTuRWoKVFbrBfInQYNXDsPOHkhgj='월'
   elif LEwTuRWoKVFbrBfInQYNXDsPOHkhgj==1:LEwTuRWoKVFbrBfInQYNXDsPOHkhgj='화'
   elif LEwTuRWoKVFbrBfInQYNXDsPOHkhgj==2:LEwTuRWoKVFbrBfInQYNXDsPOHkhgj='수'
   elif LEwTuRWoKVFbrBfInQYNXDsPOHkhgj==3:LEwTuRWoKVFbrBfInQYNXDsPOHkhgj='목'
   elif LEwTuRWoKVFbrBfInQYNXDsPOHkhgj==4:LEwTuRWoKVFbrBfInQYNXDsPOHkhgj='금'
   elif LEwTuRWoKVFbrBfInQYNXDsPOHkhgj==5:LEwTuRWoKVFbrBfInQYNXDsPOHkhgj='토'
   elif LEwTuRWoKVFbrBfInQYNXDsPOHkhgj==6:LEwTuRWoKVFbrBfInQYNXDsPOHkhgj='일'
   return LEwTuRWoKVFbrBfInQYNXDsPOHkhgi.strftime('%Y-%m-%d')+'('+ LEwTuRWoKVFbrBfInQYNXDsPOHkhgj+')'+LEwTuRWoKVFbrBfInQYNXDsPOHkhgi.strftime(' %H:%M')
  except:
   return LEwTuRWoKVFbrBfInQYNXDsPOHkhmA
 def convert_DateStr(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,LEwTuRWoKVFbrBfInQYNXDsPOHkhgl):
  try:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhgl =LEwTuRWoKVFbrBfInQYNXDsPOHkhgl[0:16]
   LEwTuRWoKVFbrBfInQYNXDsPOHkhgi=datetime.datetime.strptime(LEwTuRWoKVFbrBfInQYNXDsPOHkhgl,'%Y-%m-%dT%H:%M')+datetime.timedelta(hours=9)
   LEwTuRWoKVFbrBfInQYNXDsPOHkhgj=LEwTuRWoKVFbrBfInQYNXDsPOHkhgi.weekday()
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhgj==0:LEwTuRWoKVFbrBfInQYNXDsPOHkhgj='월'
   elif LEwTuRWoKVFbrBfInQYNXDsPOHkhgj==1:LEwTuRWoKVFbrBfInQYNXDsPOHkhgj='화'
   elif LEwTuRWoKVFbrBfInQYNXDsPOHkhgj==2:LEwTuRWoKVFbrBfInQYNXDsPOHkhgj='수'
   elif LEwTuRWoKVFbrBfInQYNXDsPOHkhgj==3:LEwTuRWoKVFbrBfInQYNXDsPOHkhgj='목'
   elif LEwTuRWoKVFbrBfInQYNXDsPOHkhgj==4:LEwTuRWoKVFbrBfInQYNXDsPOHkhgj='금'
   elif LEwTuRWoKVFbrBfInQYNXDsPOHkhgj==5:LEwTuRWoKVFbrBfInQYNXDsPOHkhgj='토'
   elif LEwTuRWoKVFbrBfInQYNXDsPOHkhgj==6:LEwTuRWoKVFbrBfInQYNXDsPOHkhgj='일'
   return LEwTuRWoKVFbrBfInQYNXDsPOHkhgi.strftime('%Y-%m-%d')+'('+ LEwTuRWoKVFbrBfInQYNXDsPOHkhgj+')'
  except:
   return LEwTuRWoKVFbrBfInQYNXDsPOHkhmA
 def Get_Now_Datetime(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetNoCache(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd):
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgM =LEwTuRWoKVFbrBfInQYNXDsPOHkhmc(time.time()*1000)
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhgM
 def generatePcId(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd):
  t=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.GetNoCache()
  r=random.random()
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgA=LEwTuRWoKVFbrBfInQYNXDsPOHkhmv(t)+LEwTuRWoKVFbrBfInQYNXDsPOHkhmv(r)[2:12]
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhgA
 def generatePvId(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,genType='1'):
  import hashlib
  m=hashlib.md5()
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgy=LEwTuRWoKVFbrBfInQYNXDsPOHkhmv(random.random())
  m.update(LEwTuRWoKVFbrBfInQYNXDsPOHkhgy.encode('utf-8'))
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgU=LEwTuRWoKVFbrBfInQYNXDsPOHkhmv(m.hexdigest())
  if genType=='1':
   return '%s-%s-%s-%s-%s'%(LEwTuRWoKVFbrBfInQYNXDsPOHkhgU[:8],LEwTuRWoKVFbrBfInQYNXDsPOHkhgU[8:12],LEwTuRWoKVFbrBfInQYNXDsPOHkhgU[12:16],LEwTuRWoKVFbrBfInQYNXDsPOHkhgU[16:20],LEwTuRWoKVFbrBfInQYNXDsPOHkhgU[20:])
  else:
   return LEwTuRWoKVFbrBfInQYNXDsPOHkhgU
 def Get_DeviceID(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd):
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgv=''
  try: 
   fp=LEwTuRWoKVFbrBfInQYNXDsPOHkhmp(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP_DEVICE_FILENAME,'r',-1,'utf-8')
   LEwTuRWoKVFbrBfInQYNXDsPOHkhgp= json.load(fp)
   fp.close()
   LEwTuRWoKVFbrBfInQYNXDsPOHkhgv=LEwTuRWoKVFbrBfInQYNXDsPOHkhgp.get('device_id')
  except LEwTuRWoKVFbrBfInQYNXDsPOHkhma as exception:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhmA
  if LEwTuRWoKVFbrBfInQYNXDsPOHkhgv=='':
   LEwTuRWoKVFbrBfInQYNXDsPOHkhgv=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.generatePvId(genType='1')
   try: 
    fp=LEwTuRWoKVFbrBfInQYNXDsPOHkhmp(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP_DEVICE_FILENAME,'w',-1,'utf-8')
    json.dump({'device_id':LEwTuRWoKVFbrBfInQYNXDsPOHkhgv},fp,indent=4,ensure_ascii=LEwTuRWoKVFbrBfInQYNXDsPOHkhmy)
    fp.close()
   except LEwTuRWoKVFbrBfInQYNXDsPOHkhma as exception:
    return ''
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhgv
 def make_stream_header(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,LEwTuRWoKVFbrBfInQYNXDsPOHkhzG,LEwTuRWoKVFbrBfInQYNXDsPOHkhzi):
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgc=''
  if LEwTuRWoKVFbrBfInQYNXDsPOHkhzi not in[{},LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,'']:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhga=LEwTuRWoKVFbrBfInQYNXDsPOHkhmJ(LEwTuRWoKVFbrBfInQYNXDsPOHkhzi)
   for LEwTuRWoKVFbrBfInQYNXDsPOHkhgJ,LEwTuRWoKVFbrBfInQYNXDsPOHkhzg in LEwTuRWoKVFbrBfInQYNXDsPOHkhzi.items():
    LEwTuRWoKVFbrBfInQYNXDsPOHkhgc+='{}={}'.format(LEwTuRWoKVFbrBfInQYNXDsPOHkhgJ,LEwTuRWoKVFbrBfInQYNXDsPOHkhzg)
    LEwTuRWoKVFbrBfInQYNXDsPOHkhga+=-1
    if LEwTuRWoKVFbrBfInQYNXDsPOHkhga>0:LEwTuRWoKVFbrBfInQYNXDsPOHkhgc+='; '
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzG['cookie']=LEwTuRWoKVFbrBfInQYNXDsPOHkhgc
  LEwTuRWoKVFbrBfInQYNXDsPOHkhzd=''
  i=0
  for LEwTuRWoKVFbrBfInQYNXDsPOHkhgJ,LEwTuRWoKVFbrBfInQYNXDsPOHkhzg in LEwTuRWoKVFbrBfInQYNXDsPOHkhzG.items():
   i=i+1
   if i>1:LEwTuRWoKVFbrBfInQYNXDsPOHkhzd+='&'
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzd+='{}={}'.format(LEwTuRWoKVFbrBfInQYNXDsPOHkhgJ,urllib.parse.quote(LEwTuRWoKVFbrBfInQYNXDsPOHkhzg))
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhzd
 def Make_authHeader(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd):
  tr=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.generatePvId(genType=2)
  ti=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.GetNoCache()
  LEwTuRWoKVFbrBfInQYNXDsPOHkhtg=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.generatePvId(genType=2)[:16]
  LEwTuRWoKVFbrBfInQYNXDsPOHkhzm='00-%s-%s-01'%(tr,LEwTuRWoKVFbrBfInQYNXDsPOHkhtg,)
  LEwTuRWoKVFbrBfInQYNXDsPOHkhzt ='%s@nr=0-1-%s-%s-%s----%s'%(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['SESSION']['NREUM']['tk'],LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['SESSION']['NREUM']['ac'],LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['SESSION']['NREUM']['ap'],LEwTuRWoKVFbrBfInQYNXDsPOHkhtg,ti,)
  LEwTuRWoKVFbrBfInQYNXDsPOHkhzx ='{"v":[0,1],"d":{"ty":"Browser","ac":"%s","ap":"%s","id":"%s","tr":"%s","ti":%s,"tk":"%s"}}'%(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['SESSION']['NREUM']['ac'],LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['SESSION']['NREUM']['ap'],LEwTuRWoKVFbrBfInQYNXDsPOHkhtg,tr,ti,LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['SESSION']['NREUM']['tk'],) 
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhzm,LEwTuRWoKVFbrBfInQYNXDsPOHkhzt,base64.standard_b64encode(LEwTuRWoKVFbrBfInQYNXDsPOHkhzx.encode()).decode('utf-8')
 def Init_CP(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd):
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP={}
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['ACCOUNT']={'cpid':'','cppw':'','cppf':'0'}
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['SESSION']={}
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['COOKIES']={}
 def Save_session_acount(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,LEwTuRWoKVFbrBfInQYNXDsPOHkhzq,LEwTuRWoKVFbrBfInQYNXDsPOHkhze,LEwTuRWoKVFbrBfInQYNXDsPOHkhzC):
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['ACCOUNT']['cpid']=base64.standard_b64encode(LEwTuRWoKVFbrBfInQYNXDsPOHkhzq.encode()).decode('utf-8')
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['ACCOUNT']['cppw']=base64.standard_b64encode(LEwTuRWoKVFbrBfInQYNXDsPOHkhze.encode()).decode('utf-8')
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['ACCOUNT']['cppf']=LEwTuRWoKVFbrBfInQYNXDsPOHkhmv(LEwTuRWoKVFbrBfInQYNXDsPOHkhzC)
 def Load_session_acount(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd):
  LEwTuRWoKVFbrBfInQYNXDsPOHkhzq=base64.standard_b64decode(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['ACCOUNT']['cpid']).decode('utf-8')
  LEwTuRWoKVFbrBfInQYNXDsPOHkhze=base64.standard_b64decode(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['ACCOUNT']['cppw']).decode('utf-8')
  LEwTuRWoKVFbrBfInQYNXDsPOHkhzC=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['ACCOUNT']['cppf']
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhzq,LEwTuRWoKVFbrBfInQYNXDsPOHkhze,LEwTuRWoKVFbrBfInQYNXDsPOHkhzC
 def make_CP_DefaultCookies(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd):
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['COOKIES']
 def Get_CP_Login(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,userid,userpw,LEwTuRWoKVFbrBfInQYNXDsPOHkhzc):
  try:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzl=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.API_DOMAIN
   LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['COOKIES']['NEXT_LOCALE']='ko'
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzG={'Accept-Language':'ko-KR,ko;q=0.9','Sec-Ch-Ua-Mobile':'?0','Sec-Ch-Ua-Platform':'"Windows"','Sec-Fetch-Dest':'document','Sec-Fetch-Mode':'navigate','Sec-Fetch-Site':'none','Sec-Fetch-User':'?1','Upgrade-Insecure-Requests':'1',}
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzi=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.make_CP_DefaultCookies()
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzj=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.callRequestCookies('Get',LEwTuRWoKVFbrBfInQYNXDsPOHkhzl,payload=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,params=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,headers=LEwTuRWoKVFbrBfInQYNXDsPOHkhzG,cookies=LEwTuRWoKVFbrBfInQYNXDsPOHkhzi,redirects=LEwTuRWoKVFbrBfInQYNXDsPOHkhtz)
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.status_code not in[200]:return LEwTuRWoKVFbrBfInQYNXDsPOHkhmy
   for LEwTuRWoKVFbrBfInQYNXDsPOHkhzS in LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.cookies:
    LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['COOKIES'][LEwTuRWoKVFbrBfInQYNXDsPOHkhzS.name]=LEwTuRWoKVFbrBfInQYNXDsPOHkhzS.value
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzi=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.make_CP_DefaultCookies()
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.status_code not in[200]:return LEwTuRWoKVFbrBfInQYNXDsPOHkhmy
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzM=re.findall('NREUM.loader_config=\{[\w\d\":,-]+\}',LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.text)[0].split('=')[1]
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzM=LEwTuRWoKVFbrBfInQYNXDsPOHkhzM.replace('{','{"').replace(':','":').replace(',',',"')
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzM=json.loads(LEwTuRWoKVFbrBfInQYNXDsPOHkhzM)
   LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['SESSION']['NREUM']={'ac':LEwTuRWoKVFbrBfInQYNXDsPOHkhzM['accountID'],'tk':LEwTuRWoKVFbrBfInQYNXDsPOHkhzM['trustKey'],'ap':LEwTuRWoKVFbrBfInQYNXDsPOHkhzM['agentID'],'lk':LEwTuRWoKVFbrBfInQYNXDsPOHkhzM['licenseKey'],}
  except LEwTuRWoKVFbrBfInQYNXDsPOHkhma as exception:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhmU(exception)
   return LEwTuRWoKVFbrBfInQYNXDsPOHkhmy
  try:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzl=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.API_DOMAIN+'/api/auth'
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzA=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.Get_DeviceID()
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzy =LEwTuRWoKVFbrBfInQYNXDsPOHkhzA.split('-')[0]
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzm,LEwTuRWoKVFbrBfInQYNXDsPOHkhzt,LEwTuRWoKVFbrBfInQYNXDsPOHkhzx=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.Make_authHeader()
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzG={'traceparent':LEwTuRWoKVFbrBfInQYNXDsPOHkhzm,'tracestate':LEwTuRWoKVFbrBfInQYNXDsPOHkhzt,'newrelic':LEwTuRWoKVFbrBfInQYNXDsPOHkhzx,'content-type':'application/json','x-app-version':'1.59.31','x-device-id':'','x-device-os-version':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.OS_VERSION,'x-nr-session-id':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['COOKIES']['session_web_id'],'x-pcid':'',}
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzU={'device':{'deviceId':'web-'+LEwTuRWoKVFbrBfInQYNXDsPOHkhzA,'model':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.MODEL,'name':'Chrome Desktop '+LEwTuRWoKVFbrBfInQYNXDsPOHkhzy,'os':'Windows','osVersion':'10','type':'webclient',},'email':userid,'password':userpw,}
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzU=json.dumps(LEwTuRWoKVFbrBfInQYNXDsPOHkhzU,separators=(',',':'))
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzi=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.make_CP_DefaultCookies()
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzj=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.callRequestCookies('Post',LEwTuRWoKVFbrBfInQYNXDsPOHkhzl,payload=LEwTuRWoKVFbrBfInQYNXDsPOHkhzU,params=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,headers=LEwTuRWoKVFbrBfInQYNXDsPOHkhzG,cookies=LEwTuRWoKVFbrBfInQYNXDsPOHkhzi,redirects=LEwTuRWoKVFbrBfInQYNXDsPOHkhmy)
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.status_code not in[200]:
    LEwTuRWoKVFbrBfInQYNXDsPOHkhzv=json.loads(LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.text)
    if 'error' in LEwTuRWoKVFbrBfInQYNXDsPOHkhzv:
     LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['SESSION']['error']=LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('error').get('detail')
    return LEwTuRWoKVFbrBfInQYNXDsPOHkhmy
   LEwTuRWoKVFbrBfInQYNXDsPOHkhmU('---')
   for LEwTuRWoKVFbrBfInQYNXDsPOHkhzS in LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.cookies:
    LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['COOKIES'][LEwTuRWoKVFbrBfInQYNXDsPOHkhzS.name]=LEwTuRWoKVFbrBfInQYNXDsPOHkhzS.value
  except LEwTuRWoKVFbrBfInQYNXDsPOHkhma as exception:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhmU(exception)
   return LEwTuRWoKVFbrBfInQYNXDsPOHkhmy
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.Save_session_acount(userid,userpw,LEwTuRWoKVFbrBfInQYNXDsPOHkhzc)
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhtz
 def Get_CP_profile(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,LEwTuRWoKVFbrBfInQYNXDsPOHkhzc,limit_days=1,re_check=LEwTuRWoKVFbrBfInQYNXDsPOHkhmy):
  if re_check==LEwTuRWoKVFbrBfInQYNXDsPOHkhtz:
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['SESSION']['bm_sv_ex']>LEwTuRWoKVFbrBfInQYNXDsPOHkhmc(time.time()):
    LEwTuRWoKVFbrBfInQYNXDsPOHkhmU('bm_sv_ex ok')
    return LEwTuRWoKVFbrBfInQYNXDsPOHkhtz
  try:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzl=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.API_DOMAIN+'/api/profiles'
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzm,LEwTuRWoKVFbrBfInQYNXDsPOHkhzt,LEwTuRWoKVFbrBfInQYNXDsPOHkhzx=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.Make_authHeader()
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzG={'traceparent':LEwTuRWoKVFbrBfInQYNXDsPOHkhzm,'tracestate':LEwTuRWoKVFbrBfInQYNXDsPOHkhzt,'newrelic':LEwTuRWoKVFbrBfInQYNXDsPOHkhzx,'x-app-version':'1.26.1','x-device-id':'','x-device-os-version':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.OS_VERSION,'x-nr-session-id':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['COOKIES']['session_web_id'],'x-pcid':'',}
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzi=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.make_CP_DefaultCookies()
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzj=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.callRequestCookies('Get',LEwTuRWoKVFbrBfInQYNXDsPOHkhzl,payload=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,params=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,headers=LEwTuRWoKVFbrBfInQYNXDsPOHkhzG,cookies=LEwTuRWoKVFbrBfInQYNXDsPOHkhzi,redirects=LEwTuRWoKVFbrBfInQYNXDsPOHkhtz)
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.status_code not in[200]:return LEwTuRWoKVFbrBfInQYNXDsPOHkhmy
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzv=json.loads(LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.text)
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzp=0
   for LEwTuRWoKVFbrBfInQYNXDsPOHkhzS in LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.cookies:
    LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['COOKIES'][LEwTuRWoKVFbrBfInQYNXDsPOHkhzS.name]=LEwTuRWoKVFbrBfInQYNXDsPOHkhzS.value
    if LEwTuRWoKVFbrBfInQYNXDsPOHkhzS.name=='bm_sv':
     LEwTuRWoKVFbrBfInQYNXDsPOHkhzp=1
     LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['SESSION']['bm_sv_ex']=LEwTuRWoKVFbrBfInQYNXDsPOHkhzS.expires 
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhzp==0:
    LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['SESSION']['bm_sv_ex']=LEwTuRWoKVFbrBfInQYNXDsPOHkhmc(time.time())+60*60*2 
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzc=LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('data')[LEwTuRWoKVFbrBfInQYNXDsPOHkhmc(LEwTuRWoKVFbrBfInQYNXDsPOHkhzc)]
   LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['SESSION']['accountId']=LEwTuRWoKVFbrBfInQYNXDsPOHkhzc.get('accountId')
   LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['SESSION']['profileId']=LEwTuRWoKVFbrBfInQYNXDsPOHkhzc.get('profileId')
  except LEwTuRWoKVFbrBfInQYNXDsPOHkhma as exception:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhmU(exception)
   return LEwTuRWoKVFbrBfInQYNXDsPOHkhmy
  if re_check==LEwTuRWoKVFbrBfInQYNXDsPOHkhmy:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhza =LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.Get_Now_Datetime()
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzJ=LEwTuRWoKVFbrBfInQYNXDsPOHkhza+datetime.timedelta(days=limit_days)
   LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['SESSION']['limitdate']=LEwTuRWoKVFbrBfInQYNXDsPOHkhzJ.strftime('%Y-%m-%d')
  else:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhmU('re check')
  LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.dic_To_jsonfile(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP_COOKIE_FILENAME,LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP)
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhtz
 def Get_Category_GroupList(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,vType):
  LEwTuRWoKVFbrBfInQYNXDsPOHkhGg=[] 
  try:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzl=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.API_DOMAIN+'/api-discover/v3/discover/feed' 
   LEwTuRWoKVFbrBfInQYNXDsPOHkhGz={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false','preferRecoFeed':'true','preferMultiHeroMixedContentRow':'true','shouldIncludeTVOD':'true','includeChannelContents':'false',}
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzj=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.callRequestCookies('Get',LEwTuRWoKVFbrBfInQYNXDsPOHkhzl,payload=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,params=LEwTuRWoKVFbrBfInQYNXDsPOHkhGz,headers=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,cookies=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,redirects=LEwTuRWoKVFbrBfInQYNXDsPOHkhtz)
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.status_code not in[200]:return[]
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzv=json.loads(LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.text)
   if vType in['TVSHOWS','MOVIES']:
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGd='Explores' 
   elif vType in['EDUCATION']:
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGd='Collection-Rails-Curation'
   elif vType in['ALL','KIDS']:
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGd='Explores-Categories'
   for LEwTuRWoKVFbrBfInQYNXDsPOHkhGm in LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('data'):
    if LEwTuRWoKVFbrBfInQYNXDsPOHkhGm.get('type')==LEwTuRWoKVFbrBfInQYNXDsPOHkhGd:
     for LEwTuRWoKVFbrBfInQYNXDsPOHkhGt in LEwTuRWoKVFbrBfInQYNXDsPOHkhGm.get('data'):
      if vType in['TVSHOWS','MOVIES']:
       LEwTuRWoKVFbrBfInQYNXDsPOHkhGx=LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('collectionId')
      elif vType in['EDUCATION','ALL','KIDS']:
       LEwTuRWoKVFbrBfInQYNXDsPOHkhGx=LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('id')
      LEwTuRWoKVFbrBfInQYNXDsPOHkhGq={'collectionId':LEwTuRWoKVFbrBfInQYNXDsPOHkhGx,'title':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('name'),'category':LEwTuRWoKVFbrBfInQYNXDsPOHkhGm.get('category'),'pre_title':'',}
      LEwTuRWoKVFbrBfInQYNXDsPOHkhGg.append(LEwTuRWoKVFbrBfInQYNXDsPOHkhGq)
     break
  except LEwTuRWoKVFbrBfInQYNXDsPOHkhma as exception:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhmU(exception)
   return[]
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhGg
 def Get_Category_List(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,vType,LEwTuRWoKVFbrBfInQYNXDsPOHkhGx,page_int):
  LEwTuRWoKVFbrBfInQYNXDsPOHkhGg=[] 
  LEwTuRWoKVFbrBfInQYNXDsPOHkhGe=LEwTuRWoKVFbrBfInQYNXDsPOHkhmy
  try:
   if vType in['ALL','KIDS']:
    LEwTuRWoKVFbrBfInQYNXDsPOHkhzG={'x-membersrl':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['COOKIES']['member_srl'],'x-pcid':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['COOKIES']['PCID'],'x-profileid':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT',}
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGz={'platform':'WEBCLIENT','page':LEwTuRWoKVFbrBfInQYNXDsPOHkhmv(page_int),'perPage':LEwTuRWoKVFbrBfInQYNXDsPOHkhmv(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.PAGE_LIMIT),'locale':'ko','sort':'',}
    LEwTuRWoKVFbrBfInQYNXDsPOHkhzl=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.API_DOMAIN+'/api-discover/v1/discover/categories/'+LEwTuRWoKVFbrBfInQYNXDsPOHkhGx+'/titles' 
    LEwTuRWoKVFbrBfInQYNXDsPOHkhzj=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.callRequestCookies('Get',LEwTuRWoKVFbrBfInQYNXDsPOHkhzl,payload=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,params=LEwTuRWoKVFbrBfInQYNXDsPOHkhGz,headers=LEwTuRWoKVFbrBfInQYNXDsPOHkhzG,cookies=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,redirects=LEwTuRWoKVFbrBfInQYNXDsPOHkhtz)
   else: 
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGz={'platform':'WEBCLIENT','page':LEwTuRWoKVFbrBfInQYNXDsPOHkhmv(page_int),'perPage':LEwTuRWoKVFbrBfInQYNXDsPOHkhmv(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.PAGE_LIMIT),}
    LEwTuRWoKVFbrBfInQYNXDsPOHkhzl=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.API_DOMAIN+'/api-discover/v1/discover/collections/'+LEwTuRWoKVFbrBfInQYNXDsPOHkhGx+'/titles' 
    LEwTuRWoKVFbrBfInQYNXDsPOHkhzj=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.callRequestCookies('Get',LEwTuRWoKVFbrBfInQYNXDsPOHkhzl,payload=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,params=LEwTuRWoKVFbrBfInQYNXDsPOHkhGz,headers=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,cookies=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,redirects=LEwTuRWoKVFbrBfInQYNXDsPOHkhtz)
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.status_code not in[200]:return[],LEwTuRWoKVFbrBfInQYNXDsPOHkhmy
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzv=json.loads(LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.text)
   if vType in['ALL','KIDS']:
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGC=LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('data').get('data')
   else:
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGC=LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('data')
   for LEwTuRWoKVFbrBfInQYNXDsPOHkhGt in LEwTuRWoKVFbrBfInQYNXDsPOHkhGC:
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGl=LEwTuRWoKVFbrBfInQYNXDsPOHkhGA=LEwTuRWoKVFbrBfInQYNXDsPOHkhdj=LEwTuRWoKVFbrBfInQYNXDsPOHkhdi=''
    if 'poster' in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('images'):LEwTuRWoKVFbrBfInQYNXDsPOHkhGl =LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('images'):LEwTuRWoKVFbrBfInQYNXDsPOHkhGA =LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('images').get('story-art').get('url') +'?imwidth=600'
    if 'title-treatment' in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('images'):LEwTuRWoKVFbrBfInQYNXDsPOHkhdj=LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('images').get('title-treatment').get('url')+'?imwidth=300'
    if 'story-art' in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('images'):LEwTuRWoKVFbrBfInQYNXDsPOHkhdi =LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('images').get('story-art').get('url') +'?imwidth=600'
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGi=''
    if LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('badge')not in[{},LEwTuRWoKVFbrBfInQYNXDsPOHkhmA]:
     for i in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('badge').get('text'):
      LEwTuRWoKVFbrBfInQYNXDsPOHkhGi+=i.get('text')
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGj=''
    if LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('seasonList')!=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA:
     LEwTuRWoKVFbrBfInQYNXDsPOHkhGj=','.join(LEwTuRWoKVFbrBfInQYNXDsPOHkhmv(e)for e in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('seasonList'))
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGS =[]
    for LEwTuRWoKVFbrBfInQYNXDsPOHkhGM in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('tags'):
     LEwTuRWoKVFbrBfInQYNXDsPOHkhGS.append(LEwTuRWoKVFbrBfInQYNXDsPOHkhGM.get('tag'))
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGq={'id':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('id'),'title':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('title'),'thumbnail':{'poster':LEwTuRWoKVFbrBfInQYNXDsPOHkhGl,'thumb':LEwTuRWoKVFbrBfInQYNXDsPOHkhGA,'clearlogo':LEwTuRWoKVFbrBfInQYNXDsPOHkhdj,'fanart':LEwTuRWoKVFbrBfInQYNXDsPOHkhdi},'mpaa':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('age_rating'),'duration':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('running_time'),'asis':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('as'),'badge':LEwTuRWoKVFbrBfInQYNXDsPOHkhGi,'year':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('meta').get('releaseYear'),'seasonList':LEwTuRWoKVFbrBfInQYNXDsPOHkhGj,'genreList':LEwTuRWoKVFbrBfInQYNXDsPOHkhGS,}
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGg.append(LEwTuRWoKVFbrBfInQYNXDsPOHkhGq)
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('pagination').get('totalPages')>page_int:
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGe=LEwTuRWoKVFbrBfInQYNXDsPOHkhtz
  except LEwTuRWoKVFbrBfInQYNXDsPOHkhma as exception:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhmU(exception)
   return[],LEwTuRWoKVFbrBfInQYNXDsPOHkhmy
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhGg,LEwTuRWoKVFbrBfInQYNXDsPOHkhGe
 def Get_Episode_List(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,programId,season):
  LEwTuRWoKVFbrBfInQYNXDsPOHkhGg=[] 
  try:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzl=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.API_DOMAIN+'/api-discover/v1/discover/titles/'+programId+'/episodes' 
   LEwTuRWoKVFbrBfInQYNXDsPOHkhGz={'season':season,'sort':'true','locale':'ko',}
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzj=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.callRequestCookies('Get',LEwTuRWoKVFbrBfInQYNXDsPOHkhzl,payload=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,params=LEwTuRWoKVFbrBfInQYNXDsPOHkhGz,headers=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,cookies=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,redirects=LEwTuRWoKVFbrBfInQYNXDsPOHkhtz)
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.status_code not in[200]:return[]
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzv=json.loads(LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.text)
   for LEwTuRWoKVFbrBfInQYNXDsPOHkhGt in LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('data'):
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGA=''
    if 'story-art' in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('images'):LEwTuRWoKVFbrBfInQYNXDsPOHkhGA =LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('images').get('story-art').get('url')+'?imwidth=600'
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGS =[]
    for LEwTuRWoKVFbrBfInQYNXDsPOHkhGM in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('tags'):
     LEwTuRWoKVFbrBfInQYNXDsPOHkhGS.append(LEwTuRWoKVFbrBfInQYNXDsPOHkhGM.get('tag'))
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGq={'id':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('id'),'title':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('title'),'thumbnail':{'thumb':LEwTuRWoKVFbrBfInQYNXDsPOHkhGA,'fanart':LEwTuRWoKVFbrBfInQYNXDsPOHkhGA},'mpaa':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('age_rating'),'duration':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('running_time'),'asis':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('as'),'year':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('meta').get('releaseYear'),'episode':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('episode'),'genreList':LEwTuRWoKVFbrBfInQYNXDsPOHkhGS,'desc':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('description'),}
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGg.append(LEwTuRWoKVFbrBfInQYNXDsPOHkhGq)
  except LEwTuRWoKVFbrBfInQYNXDsPOHkhma as exception:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhmU(exception)
   return[]
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhGg
 def Get_vInfo(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,titleId):
  try:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzl=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.API_DOMAIN+'/api-discover/v1/discover/titles/'+titleId 
   LEwTuRWoKVFbrBfInQYNXDsPOHkhGz={'platform':'WEBCLIENT','locale':'ko','filterRestrictedContent':'false',}
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzj=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.callRequestCookies('Get',LEwTuRWoKVFbrBfInQYNXDsPOHkhzl,payload=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,params=LEwTuRWoKVFbrBfInQYNXDsPOHkhGz,headers=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,cookies=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,redirects=LEwTuRWoKVFbrBfInQYNXDsPOHkhtz)
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.status_code not in[200]:return '','',''
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzv=json.loads(LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.text).get('data')
   LEwTuRWoKVFbrBfInQYNXDsPOHkhGj=''
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('seasonList')!=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA:
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGj=','.join(LEwTuRWoKVFbrBfInQYNXDsPOHkhmv(e)for e in LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('seasonList'))
   LEwTuRWoKVFbrBfInQYNXDsPOHkhGy={'age_rating':LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('age_rating'),'asset_id':LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('asset_id'),'availability':LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('availability'),'deal_id':LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('deal_id'),'downloadable':'true' if LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('downloadable')else 'false','region':LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('region'),'streamable':'true' if LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('streamable')else 'false','asis':LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('as'),'seasonList':LEwTuRWoKVFbrBfInQYNXDsPOHkhGj}
  except LEwTuRWoKVFbrBfInQYNXDsPOHkhma as exception:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhmU(exception)
   return{}
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhGy
 def Get_eInfo(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,eventId):
  try:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzl=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.API_DOMAIN+'/api-discover/v1/discover/events/'+eventId 
   LEwTuRWoKVFbrBfInQYNXDsPOHkhGz={'locale':'ko','platform':'WEBCLIENT','includeSportsChannelContents':'true',}
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzj=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.callRequestCookies('Get',LEwTuRWoKVFbrBfInQYNXDsPOHkhzl,payload=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,params=LEwTuRWoKVFbrBfInQYNXDsPOHkhGz,headers=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,cookies=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,redirects=LEwTuRWoKVFbrBfInQYNXDsPOHkhtz)
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.status_code not in[200]:return '','',''
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzv=json.loads(LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.text).get('data')
   LEwTuRWoKVFbrBfInQYNXDsPOHkhGy={'asset_id':LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('asset_id'),'deal_id':LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('deal_id'),'region':LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('region'),'streamable':'true' if LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('streamable')else 'false',}
  except LEwTuRWoKVFbrBfInQYNXDsPOHkhma as exception:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhmU(exception)
   return{}
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhGy
 def GetBroadURL(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,titleId):
  LEwTuRWoKVFbrBfInQYNXDsPOHkhGU=''
  LEwTuRWoKVFbrBfInQYNXDsPOHkhGv =''
  LEwTuRWoKVFbrBfInQYNXDsPOHkhGy=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.Get_vInfo(titleId)
  if LEwTuRWoKVFbrBfInQYNXDsPOHkhGy=={}:return '',''
  try:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzl=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.API_DOMAIN+'/api/playback/play' 
   LEwTuRWoKVFbrBfInQYNXDsPOHkhGz={'titleId':titleId}
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzm,LEwTuRWoKVFbrBfInQYNXDsPOHkhzt,LEwTuRWoKVFbrBfInQYNXDsPOHkhzx=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.Make_authHeader()
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzG={'traceparent':LEwTuRWoKVFbrBfInQYNXDsPOHkhzm,'tracestate':LEwTuRWoKVFbrBfInQYNXDsPOHkhzt,'newrelic':LEwTuRWoKVFbrBfInQYNXDsPOHkhzx,'x-drm':'com.microsoft.playready','x-app-version':'1.33.5','x-device-id':'','x-device-os-version':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.OS_VERSION,'x-force-raw':'true','x-nr-session-id':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['COOKIES']['session_web_id'],'x-pcid':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['COOKIES']['PCID'],'x-platform':'web','x-profileId':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['SESSION']['profileId'],'x-profileType':'standard','x-sessionid':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.generatePvId(genType='1'),'x-title-age-rating':LEwTuRWoKVFbrBfInQYNXDsPOHkhGy.get('age_rating'),'x-title-availability':LEwTuRWoKVFbrBfInQYNXDsPOHkhGy.get('availability'),'x-title-brightcove-id':LEwTuRWoKVFbrBfInQYNXDsPOHkhGy.get('asset_id'),'x-title-deal-id':LEwTuRWoKVFbrBfInQYNXDsPOHkhGy.get('deal_id'),'x-title-downloadable':LEwTuRWoKVFbrBfInQYNXDsPOHkhGy.get('downloadable'),'x-title-region':LEwTuRWoKVFbrBfInQYNXDsPOHkhGy.get('region'),'x-title-streamable':LEwTuRWoKVFbrBfInQYNXDsPOHkhGy.get('streamable'),}
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzi=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.make_CP_DefaultCookies()
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzj=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.callRequestCookies('Get',LEwTuRWoKVFbrBfInQYNXDsPOHkhzl,payload=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,params=LEwTuRWoKVFbrBfInQYNXDsPOHkhGz,headers=LEwTuRWoKVFbrBfInQYNXDsPOHkhzG,cookies=LEwTuRWoKVFbrBfInQYNXDsPOHkhzi,redirects=LEwTuRWoKVFbrBfInQYNXDsPOHkhtz)
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.status_code not in[200]:return '',json.loads(LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.text).get('error').get('detail')
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzv=json.loads(LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.text)
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhGU=='':
    for LEwTuRWoKVFbrBfInQYNXDsPOHkhGt in LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('data').get('raw').get('sources'):
     if 'key_systems' in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt and 'codecs' not in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt:
      if LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('type')=='application/dash+xml' and 'com.widevine.alpha' in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('key_systems')and LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('src').startswith('https://')==LEwTuRWoKVFbrBfInQYNXDsPOHkhtz:
       LEwTuRWoKVFbrBfInQYNXDsPOHkhGU=LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('src')
       LEwTuRWoKVFbrBfInQYNXDsPOHkhGv =LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhGU=='':
    for LEwTuRWoKVFbrBfInQYNXDsPOHkhGt in LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('data').get('raw').get('sources'):
     if 'key_systems' in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt and 'codecs' not in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt:
      if LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('key_systems')and LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('src').startswith('https://')==LEwTuRWoKVFbrBfInQYNXDsPOHkhtz:
       LEwTuRWoKVFbrBfInQYNXDsPOHkhGU=LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('src')
       LEwTuRWoKVFbrBfInQYNXDsPOHkhGv =LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhGU=='':
    for LEwTuRWoKVFbrBfInQYNXDsPOHkhGt in LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('data').get('raw').get('sources'):
     if 'key_systems' in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt and 'codecs' in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt:
      if LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('type')=='application/dash+xml' and 'com.widevine.alpha' in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('key_systems')and LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('src').startswith('https://')==LEwTuRWoKVFbrBfInQYNXDsPOHkhtz:
       LEwTuRWoKVFbrBfInQYNXDsPOHkhGU=LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('src')
       LEwTuRWoKVFbrBfInQYNXDsPOHkhGv =LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhGU=='':
    for LEwTuRWoKVFbrBfInQYNXDsPOHkhGt in LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('data').get('raw').get('sources'):
     if 'key_systems' in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt and 'codecs' in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt:
      if LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('key_systems')and LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('src').startswith('https://')==LEwTuRWoKVFbrBfInQYNXDsPOHkhtz:
       LEwTuRWoKVFbrBfInQYNXDsPOHkhGU=LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('src')
       LEwTuRWoKVFbrBfInQYNXDsPOHkhGv =LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
  except LEwTuRWoKVFbrBfInQYNXDsPOHkhma as exception:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhmU(exception)
   return '',''
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhGU,LEwTuRWoKVFbrBfInQYNXDsPOHkhGv
 def GetEventURL(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,eventId,LEwTuRWoKVFbrBfInQYNXDsPOHkhdx):
  LEwTuRWoKVFbrBfInQYNXDsPOHkhGU=''
  LEwTuRWoKVFbrBfInQYNXDsPOHkhGv =''
  LEwTuRWoKVFbrBfInQYNXDsPOHkhGy=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.Get_eInfo(eventId)
  if LEwTuRWoKVFbrBfInQYNXDsPOHkhGy=={}:return '',''
  try:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzl=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.API_DOMAIN+'/api/playback/play' 
   LEwTuRWoKVFbrBfInQYNXDsPOHkhGz={'titleId':eventId,'titleType':LEwTuRWoKVFbrBfInQYNXDsPOHkhdx,}
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzm,LEwTuRWoKVFbrBfInQYNXDsPOHkhzt,LEwTuRWoKVFbrBfInQYNXDsPOHkhzx=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.Make_authHeader()
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzG={'traceparent':LEwTuRWoKVFbrBfInQYNXDsPOHkhzm,'tracestate':LEwTuRWoKVFbrBfInQYNXDsPOHkhzt,'newrelic':LEwTuRWoKVFbrBfInQYNXDsPOHkhzx,'x-force-raw':'true','x-pcid':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['COOKIES']['PCID'],'x-platform':'web','x-profileId':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-downloadable':'undefined','x-title-brightcove-id':LEwTuRWoKVFbrBfInQYNXDsPOHkhGy.get('asset_id'),'x-title-deal-id':LEwTuRWoKVFbrBfInQYNXDsPOHkhGy.get('deal_id'),'x-title-region':LEwTuRWoKVFbrBfInQYNXDsPOHkhGy.get('region'),'x-title-streamable':LEwTuRWoKVFbrBfInQYNXDsPOHkhGy.get('streamable'),}
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzi=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.make_CP_DefaultCookies()
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzj=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.callRequestCookies('Get',LEwTuRWoKVFbrBfInQYNXDsPOHkhzl,payload=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,params=LEwTuRWoKVFbrBfInQYNXDsPOHkhGz,headers=LEwTuRWoKVFbrBfInQYNXDsPOHkhzG,cookies=LEwTuRWoKVFbrBfInQYNXDsPOHkhzi,redirects=LEwTuRWoKVFbrBfInQYNXDsPOHkhtz)
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.status_code not in[200]:return '',json.loads(LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.text).get('error').get('detail')
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzv=json.loads(LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.text)
   for LEwTuRWoKVFbrBfInQYNXDsPOHkhGt in LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('data').get('raw').get('sources'):
    if LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('type')=='application/dash+xml' and LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('src')[0:8]=='https://':
     LEwTuRWoKVFbrBfInQYNXDsPOHkhGU=LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('src')
     if 'key_systems' in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt:
      LEwTuRWoKVFbrBfInQYNXDsPOHkhGv =LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('key_systems').get('com.widevine.alpha').get('license_url')
     break
  except LEwTuRWoKVFbrBfInQYNXDsPOHkhma as exception:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhmU(exception)
   return '',''
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhGU,LEwTuRWoKVFbrBfInQYNXDsPOHkhGv
 def GetEventURL_Live(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,eventId,LEwTuRWoKVFbrBfInQYNXDsPOHkhdx):
  LEwTuRWoKVFbrBfInQYNXDsPOHkhGU=''
  LEwTuRWoKVFbrBfInQYNXDsPOHkhGv =''
  LEwTuRWoKVFbrBfInQYNXDsPOHkhGy=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.Get_eInfo(eventId)
  if LEwTuRWoKVFbrBfInQYNXDsPOHkhGy=={}:return '',''
  try:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzl=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.API_DOMAIN+'/api/playback/play' 
   LEwTuRWoKVFbrBfInQYNXDsPOHkhGz={'titleId':eventId,'titleType':LEwTuRWoKVFbrBfInQYNXDsPOHkhdx,}
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzm,LEwTuRWoKVFbrBfInQYNXDsPOHkhzt,LEwTuRWoKVFbrBfInQYNXDsPOHkhzx=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.Make_authHeader()
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzG={'traceparent':LEwTuRWoKVFbrBfInQYNXDsPOHkhzm,'tracestate':LEwTuRWoKVFbrBfInQYNXDsPOHkhzt,'newrelic':LEwTuRWoKVFbrBfInQYNXDsPOHkhzx,'x-force-raw':'true','x-pcid':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['COOKIES']['PCID'],'x-platform':'web','x-profileId':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':LEwTuRWoKVFbrBfInQYNXDsPOHkhGy.get('asset_id'),'x-title-deal-id':LEwTuRWoKVFbrBfInQYNXDsPOHkhGy.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':LEwTuRWoKVFbrBfInQYNXDsPOHkhGy.get('region'),'x-title-streamable':LEwTuRWoKVFbrBfInQYNXDsPOHkhGy.get('streamable'),}
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzi=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.make_CP_DefaultCookies()
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzj=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.callRequestCookies('Get',LEwTuRWoKVFbrBfInQYNXDsPOHkhzl,payload=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,params=LEwTuRWoKVFbrBfInQYNXDsPOHkhGz,headers=LEwTuRWoKVFbrBfInQYNXDsPOHkhzG,cookies=LEwTuRWoKVFbrBfInQYNXDsPOHkhzi,redirects=LEwTuRWoKVFbrBfInQYNXDsPOHkhtz)
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.status_code not in[200]:return '',json.loads(LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.text).get('error').get('detail')
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzv=json.loads(LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.text)
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhGU=='':
    for LEwTuRWoKVFbrBfInQYNXDsPOHkhGt in LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('data').get('raw').get('sources'):
     if 'key_systems' in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt:
      if LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('type')=='application/dash+xml' and 'com.widevine.alpha' in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('key_systems')and LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('src').startswith('https://')==LEwTuRWoKVFbrBfInQYNXDsPOHkhtz:
       LEwTuRWoKVFbrBfInQYNXDsPOHkhGU=LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('src')
       LEwTuRWoKVFbrBfInQYNXDsPOHkhGv =LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('key_systems').get('com.widevine.alpha').get('license_url')
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhGU=='':
    for LEwTuRWoKVFbrBfInQYNXDsPOHkhGt in LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('data').get('raw').get('sources'):
     if 'key_systems' in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt:
      if LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('key_systems')and LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('src').startswith('https://')==LEwTuRWoKVFbrBfInQYNXDsPOHkhtz:
       LEwTuRWoKVFbrBfInQYNXDsPOHkhGU=LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('src')
       LEwTuRWoKVFbrBfInQYNXDsPOHkhGv =LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('key_systems').get('com.widevine.alpha').get('license_url')
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhGU=='':
    for LEwTuRWoKVFbrBfInQYNXDsPOHkhGt in LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('data').get('raw').get('sources'):
     if LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('type')=='application/dash+xml' and LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('src').startswith('https://')==LEwTuRWoKVFbrBfInQYNXDsPOHkhtz:
      LEwTuRWoKVFbrBfInQYNXDsPOHkhGU=LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('src')
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhGU=='':
    for LEwTuRWoKVFbrBfInQYNXDsPOHkhGt in LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('data').get('raw').get('sources'):
     if LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('type')=='application/x-mpegURL' and LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('src').startswith('https://')==LEwTuRWoKVFbrBfInQYNXDsPOHkhtz:
      LEwTuRWoKVFbrBfInQYNXDsPOHkhGU=LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('src')
  except LEwTuRWoKVFbrBfInQYNXDsPOHkhma as exception:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhmU(exception)
   return '',''
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhGU,LEwTuRWoKVFbrBfInQYNXDsPOHkhGv
 def Get_Url_PostFix(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,in_url):
  LEwTuRWoKVFbrBfInQYNXDsPOHkhGp=urllib.parse.urlparse(in_url) 
  LEwTuRWoKVFbrBfInQYNXDsPOHkhGc =LEwTuRWoKVFbrBfInQYNXDsPOHkhGp.path.strip('/').split('/')
  LEwTuRWoKVFbrBfInQYNXDsPOHkhGa =LEwTuRWoKVFbrBfInQYNXDsPOHkhGc[LEwTuRWoKVFbrBfInQYNXDsPOHkhmJ(LEwTuRWoKVFbrBfInQYNXDsPOHkhGc)-1]
  LEwTuRWoKVFbrBfInQYNXDsPOHkhGJ=LEwTuRWoKVFbrBfInQYNXDsPOHkhGa.split('.')
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhGJ[LEwTuRWoKVFbrBfInQYNXDsPOHkhmJ(LEwTuRWoKVFbrBfInQYNXDsPOHkhGJ)-1]
 def Get_Theme_GroupList(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,vType):
  LEwTuRWoKVFbrBfInQYNXDsPOHkhGg=[] 
  try:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzl=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.API_DOMAIN+'/api-discover/v3/discover/feed' 
   LEwTuRWoKVFbrBfInQYNXDsPOHkhGz={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':LEwTuRWoKVFbrBfInQYNXDsPOHkhmv(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.PAGE_LIMIT),'filterRestrictedContent':'false','preferRecoFeed':'true','preferMultiHeroMixedContentRow':'true','shouldIncludeTVOD':'true','includeChannelContents':'false',}
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzj=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.callRequestCookies('Get',LEwTuRWoKVFbrBfInQYNXDsPOHkhzl,payload=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,params=LEwTuRWoKVFbrBfInQYNXDsPOHkhGz,headers=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,cookies=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,redirects=LEwTuRWoKVFbrBfInQYNXDsPOHkhtz)
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.status_code not in[200]:return[]
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzv=json.loads(LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.text)
   for LEwTuRWoKVFbrBfInQYNXDsPOHkhGt in LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('data'):
    if LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('type')=='Title-Rails-Curation':
     LEwTuRWoKVFbrBfInQYNXDsPOHkhdg =''
     LEwTuRWoKVFbrBfInQYNXDsPOHkhdz=7
     try:
      for i in LEwTuRWoKVFbrBfInQYNXDsPOHkhtG(LEwTuRWoKVFbrBfInQYNXDsPOHkhmJ(LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('data'))):
       if i>=LEwTuRWoKVFbrBfInQYNXDsPOHkhdz:
        LEwTuRWoKVFbrBfInQYNXDsPOHkhdg=LEwTuRWoKVFbrBfInQYNXDsPOHkhdg+'...'
        break
       LEwTuRWoKVFbrBfInQYNXDsPOHkhdg=LEwTuRWoKVFbrBfInQYNXDsPOHkhdg+LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['data'][i]['title']+'\n'
     except LEwTuRWoKVFbrBfInQYNXDsPOHkhma as exception:
      LEwTuRWoKVFbrBfInQYNXDsPOHkhmU(exception)
     LEwTuRWoKVFbrBfInQYNXDsPOHkhGq={'collectionId':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('obj_id'),'title':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('row_name'),'category':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('category'),'pre_title':LEwTuRWoKVFbrBfInQYNXDsPOHkhdg,}
     LEwTuRWoKVFbrBfInQYNXDsPOHkhGg.append(LEwTuRWoKVFbrBfInQYNXDsPOHkhGq)
  except LEwTuRWoKVFbrBfInQYNXDsPOHkhma as exception:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhmU(exception)
   return[]
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhGg
 def Get_Event_GroupList(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd):
  LEwTuRWoKVFbrBfInQYNXDsPOHkhGg=[] 
  try:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzl=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.API_DOMAIN+'/api-discover/v3/discover/feed' 
   LEwTuRWoKVFbrBfInQYNXDsPOHkhGz={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':7,'filterRestrictedContent':'false','preferRecoFeed':'true','preferMultiHeroMixedContentRow':'true','shouldIncludeTVOD':'true','includeChannelContents':'false',}
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzj=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.callRequestCookies('Get',LEwTuRWoKVFbrBfInQYNXDsPOHkhzl,payload=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,params=LEwTuRWoKVFbrBfInQYNXDsPOHkhGz,headers=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,cookies=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,redirects=LEwTuRWoKVFbrBfInQYNXDsPOHkhtz)
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.status_code not in[200]:return[]
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzv=json.loads(LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.text)
   for LEwTuRWoKVFbrBfInQYNXDsPOHkhGt in LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('data'):
    if LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('row_name').strip()!='':
     LEwTuRWoKVFbrBfInQYNXDsPOHkhdg =''
     LEwTuRWoKVFbrBfInQYNXDsPOHkhdz=7
     try:
      for i in LEwTuRWoKVFbrBfInQYNXDsPOHkhtG(LEwTuRWoKVFbrBfInQYNXDsPOHkhmJ(LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('data'))):
       if i>=LEwTuRWoKVFbrBfInQYNXDsPOHkhdz:
        LEwTuRWoKVFbrBfInQYNXDsPOHkhdg=LEwTuRWoKVFbrBfInQYNXDsPOHkhdg+'...'
        break
       LEwTuRWoKVFbrBfInQYNXDsPOHkhdg=LEwTuRWoKVFbrBfInQYNXDsPOHkhdg+LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['data'][i]['title']+'\n'
     except LEwTuRWoKVFbrBfInQYNXDsPOHkhma as exception:
      LEwTuRWoKVFbrBfInQYNXDsPOHkhmU(exception)
     LEwTuRWoKVFbrBfInQYNXDsPOHkhGq={'collectionId':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('obj_id'),'title':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('row_name'),'category':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('type'),'pre_title':LEwTuRWoKVFbrBfInQYNXDsPOHkhdg,}
     LEwTuRWoKVFbrBfInQYNXDsPOHkhGg.append(LEwTuRWoKVFbrBfInQYNXDsPOHkhGq)
  except LEwTuRWoKVFbrBfInQYNXDsPOHkhma as exception:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhmU(exception)
   return[]
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhGg
 def Get_Event_GameList(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,LEwTuRWoKVFbrBfInQYNXDsPOHkhGx):
  LEwTuRWoKVFbrBfInQYNXDsPOHkhGg=[] 
  try:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzl=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.API_DOMAIN+'/api-discover/v3/discover/feed' 
   LEwTuRWoKVFbrBfInQYNXDsPOHkhGz={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':7,'filterRestrictedContent':'false','preferRecoFeed':'true','preferMultiHeroMixedContentRow':'true','shouldIncludeTVOD':'true','includeChannelContents':'false',}
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzj=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.callRequestCookies('Get',LEwTuRWoKVFbrBfInQYNXDsPOHkhzl,payload=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,params=LEwTuRWoKVFbrBfInQYNXDsPOHkhGz,headers=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,cookies=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,redirects=LEwTuRWoKVFbrBfInQYNXDsPOHkhtz)
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.status_code not in[200]:return[]
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzv=json.loads(LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.text)
   for LEwTuRWoKVFbrBfInQYNXDsPOHkhGt in LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('data'):
    if LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('obj_id')==LEwTuRWoKVFbrBfInQYNXDsPOHkhGx:
     for LEwTuRWoKVFbrBfInQYNXDsPOHkhdG in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('data'):
      LEwTuRWoKVFbrBfInQYNXDsPOHkhGl=LEwTuRWoKVFbrBfInQYNXDsPOHkhGA=LEwTuRWoKVFbrBfInQYNXDsPOHkhdi=''
      if 'poster_url' in LEwTuRWoKVFbrBfInQYNXDsPOHkhdG.get('images'):LEwTuRWoKVFbrBfInQYNXDsPOHkhGl =LEwTuRWoKVFbrBfInQYNXDsPOHkhdG.get('images').get('poster_url') +'?imwidth=350'
      if 'story_art_url' in LEwTuRWoKVFbrBfInQYNXDsPOHkhdG.get('images'):LEwTuRWoKVFbrBfInQYNXDsPOHkhGA =LEwTuRWoKVFbrBfInQYNXDsPOHkhdG.get('images').get('story_art_url')+'?imwidth=600'
      if 'hero_url' in LEwTuRWoKVFbrBfInQYNXDsPOHkhdG.get('images'):LEwTuRWoKVFbrBfInQYNXDsPOHkhdi =LEwTuRWoKVFbrBfInQYNXDsPOHkhdG.get('images').get('hero_url') +'?imwidth=600'
      LEwTuRWoKVFbrBfInQYNXDsPOHkhGq={'id':LEwTuRWoKVFbrBfInQYNXDsPOHkhdG.get('id'),'title':LEwTuRWoKVFbrBfInQYNXDsPOHkhdG.get('title'),'thumbnail':{'poster':LEwTuRWoKVFbrBfInQYNXDsPOHkhGl,'thumb':LEwTuRWoKVFbrBfInQYNXDsPOHkhGA,'fanart':LEwTuRWoKVFbrBfInQYNXDsPOHkhdi},'asis':LEwTuRWoKVFbrBfInQYNXDsPOHkhdG.get('type'),'starttm':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.convert_TimeStr(LEwTuRWoKVFbrBfInQYNXDsPOHkhdG.get('startAt')),}
      LEwTuRWoKVFbrBfInQYNXDsPOHkhGg.append(LEwTuRWoKVFbrBfInQYNXDsPOHkhGq)
  except LEwTuRWoKVFbrBfInQYNXDsPOHkhma as exception:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhmU(exception)
   return[]
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhGg
 def Get_Event_List(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,gameId):
  LEwTuRWoKVFbrBfInQYNXDsPOHkhGg=[] 
  try:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzl=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.API_DOMAIN+'/api-discover/v1/discover/events/'+gameId 
   LEwTuRWoKVFbrBfInQYNXDsPOHkhGz={'platform':'WEBCLIENT','locale':'ko','filterRestrictedContent':'false',}
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzj=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.callRequestCookies('Get',LEwTuRWoKVFbrBfInQYNXDsPOHkhzl,payload=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,params=LEwTuRWoKVFbrBfInQYNXDsPOHkhGz,headers=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,cookies=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,redirects=LEwTuRWoKVFbrBfInQYNXDsPOHkhtz)
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.status_code not in[200]:return[]
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzv=json.loads(LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.text)
   LEwTuRWoKVFbrBfInQYNXDsPOHkhGt=LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('data')
   LEwTuRWoKVFbrBfInQYNXDsPOHkhdm=LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('end_at')
   LEwTuRWoKVFbrBfInQYNXDsPOHkhdm=LEwTuRWoKVFbrBfInQYNXDsPOHkhdm[0:19].replace('-','').replace(':','').replace('T','')
   LEwTuRWoKVFbrBfInQYNXDsPOHkhdt=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d%H%M%S')
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhmc(LEwTuRWoKVFbrBfInQYNXDsPOHkhdt)<LEwTuRWoKVFbrBfInQYNXDsPOHkhmc(LEwTuRWoKVFbrBfInQYNXDsPOHkhdm):
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGl=LEwTuRWoKVFbrBfInQYNXDsPOHkhGA=LEwTuRWoKVFbrBfInQYNXDsPOHkhdi=''
    if 'poster' in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('images'):LEwTuRWoKVFbrBfInQYNXDsPOHkhGl =LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('images'):LEwTuRWoKVFbrBfInQYNXDsPOHkhGA =LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('images').get('story-art').get('url')+'?imwidth=600'
    if 'story-art' in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('images'):LEwTuRWoKVFbrBfInQYNXDsPOHkhdi =LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('images').get('story-art').get('url')+'?imwidth=600'
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGq={'id':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('id'),'title':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('title'),'thumbnail':{'poster':LEwTuRWoKVFbrBfInQYNXDsPOHkhGl,'thumb':LEwTuRWoKVFbrBfInQYNXDsPOHkhGA,'fanart':LEwTuRWoKVFbrBfInQYNXDsPOHkhdi},'duration':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('running_time'),'asis':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('type'),'starttm':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.convert_TimeStr(LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('start_at')),}
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGg.append(LEwTuRWoKVFbrBfInQYNXDsPOHkhGq)
  except LEwTuRWoKVFbrBfInQYNXDsPOHkhma as exception:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhmU(exception)
   return[]
  try:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzl=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.API_DOMAIN+'/api-discover/v1/discover/events/'+gameId+'/related' 
   LEwTuRWoKVFbrBfInQYNXDsPOHkhGz={'locale':'ko','page':'1','perPage':'25','platform':'WEBCLIENT','currentPageTracking':'page_discover_title_detail',}
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzj=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.callRequestCookies('Get',LEwTuRWoKVFbrBfInQYNXDsPOHkhzl,payload=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,params=LEwTuRWoKVFbrBfInQYNXDsPOHkhGz,headers=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,cookies=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,redirects=LEwTuRWoKVFbrBfInQYNXDsPOHkhtz)
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.status_code not in[200]:return[]
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzv=json.loads(LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.text)
   for LEwTuRWoKVFbrBfInQYNXDsPOHkhGt in LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('data').get('data'):
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGl=LEwTuRWoKVFbrBfInQYNXDsPOHkhGA=LEwTuRWoKVFbrBfInQYNXDsPOHkhdi=''
    if 'poster' in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('images'):LEwTuRWoKVFbrBfInQYNXDsPOHkhGl =LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('images'):LEwTuRWoKVFbrBfInQYNXDsPOHkhGA =LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('images').get('story-art').get('url')+'?imwidth=600'
    if 'story-art' in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('images'):LEwTuRWoKVFbrBfInQYNXDsPOHkhdi =LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('images').get('story-art').get('url')+'?imwidth=600'
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGq={'id':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('id'),'title':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('title'),'thumbnail':{'poster':LEwTuRWoKVFbrBfInQYNXDsPOHkhGl,'thumb':LEwTuRWoKVFbrBfInQYNXDsPOHkhGA,'fanart':LEwTuRWoKVFbrBfInQYNXDsPOHkhdi},'duration':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('running_time'),'asis':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('type'),}
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGg.append(LEwTuRWoKVFbrBfInQYNXDsPOHkhGq)
  except LEwTuRWoKVFbrBfInQYNXDsPOHkhma as exception:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhmU(exception)
   return[]
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhGg
 def Get_Search_List(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,search_key,page_int):
  LEwTuRWoKVFbrBfInQYNXDsPOHkhGg=[] 
  LEwTuRWoKVFbrBfInQYNXDsPOHkhGe=LEwTuRWoKVFbrBfInQYNXDsPOHkhmy
  try:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzl=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.API_DOMAIN+'/api-discover/v2/search' 
   LEwTuRWoKVFbrBfInQYNXDsPOHkhGz={'query':search_key,'platform':'WEBCLIENT','page':LEwTuRWoKVFbrBfInQYNXDsPOHkhmv(page_int),'perPage':LEwTuRWoKVFbrBfInQYNXDsPOHkhmv(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.SEARCH_LIMIT),}
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzG={'x-membersrl':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['COOKIES']['member_srl'],'x-pcid':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['COOKIES']['PCID'],'x-profileid':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT',}
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzj=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.callRequestCookies('Get',LEwTuRWoKVFbrBfInQYNXDsPOHkhzl,payload=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,params=LEwTuRWoKVFbrBfInQYNXDsPOHkhGz,headers=LEwTuRWoKVFbrBfInQYNXDsPOHkhzG,cookies=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,redirects=LEwTuRWoKVFbrBfInQYNXDsPOHkhtz)
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.status_code not in[200]:return[],LEwTuRWoKVFbrBfInQYNXDsPOHkhmy
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzv=json.loads(LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.text)
   for LEwTuRWoKVFbrBfInQYNXDsPOHkhGt in LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('data').get('data'):
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGt=LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('data')
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGl=LEwTuRWoKVFbrBfInQYNXDsPOHkhGA=LEwTuRWoKVFbrBfInQYNXDsPOHkhdj=LEwTuRWoKVFbrBfInQYNXDsPOHkhdi=''
    if 'poster' in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('images'):LEwTuRWoKVFbrBfInQYNXDsPOHkhGl =LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('images'):LEwTuRWoKVFbrBfInQYNXDsPOHkhGA =LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('images').get('story-art').get('url') +'?imwidth=600'
    if 'title-treatment' in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('images'):LEwTuRWoKVFbrBfInQYNXDsPOHkhdj=LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('images').get('title-treatment').get('url')+'?imwidth=300'
    if 'story-art' in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('images'):LEwTuRWoKVFbrBfInQYNXDsPOHkhdi =LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('images').get('story-art').get('url') +'?imwidth=600'
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGi=''
    if LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('badge')not in[{},LEwTuRWoKVFbrBfInQYNXDsPOHkhmA]:
     for i in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('badge').get('text'):
      if LEwTuRWoKVFbrBfInQYNXDsPOHkhGi!='':LEwTuRWoKVFbrBfInQYNXDsPOHkhGi+=' '
      LEwTuRWoKVFbrBfInQYNXDsPOHkhGi+=i.get('text')
    if 'as' in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt:
     LEwTuRWoKVFbrBfInQYNXDsPOHkhdx=LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('as') 
    else:
     LEwTuRWoKVFbrBfInQYNXDsPOHkhdx=LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('type')
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGq={'id':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('id'),'title':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('title'),'asis':LEwTuRWoKVFbrBfInQYNXDsPOHkhdx,'thumbnail':{'poster':LEwTuRWoKVFbrBfInQYNXDsPOHkhGl,'thumb':LEwTuRWoKVFbrBfInQYNXDsPOHkhGA,'clearlogo':LEwTuRWoKVFbrBfInQYNXDsPOHkhdj,'fanart':LEwTuRWoKVFbrBfInQYNXDsPOHkhdi},'mpaa':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('age_rating'),'duration':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('running_time'),'badge':LEwTuRWoKVFbrBfInQYNXDsPOHkhGi,'year':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('meta').get('releaseYear'),}
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGg.append(LEwTuRWoKVFbrBfInQYNXDsPOHkhGq)
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('pagination').get('totalPages')>page_int:
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGe=LEwTuRWoKVFbrBfInQYNXDsPOHkhtz
  except LEwTuRWoKVFbrBfInQYNXDsPOHkhma as exception:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhmU(exception)
   return[],LEwTuRWoKVFbrBfInQYNXDsPOHkhmy
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhGg,LEwTuRWoKVFbrBfInQYNXDsPOHkhGe
 def GetBookmarkInfo(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,videoid,vidtype):
  LEwTuRWoKVFbrBfInQYNXDsPOHkhdq={'indexinfo':{'ott':'coupang','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  LEwTuRWoKVFbrBfInQYNXDsPOHkhzl=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.API_DOMAIN+'/api-discover/v1/discover/titles/'+videoid 
  LEwTuRWoKVFbrBfInQYNXDsPOHkhGz={'locale':'ko'}
  LEwTuRWoKVFbrBfInQYNXDsPOHkhzj=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.callRequestCookies('Get',LEwTuRWoKVFbrBfInQYNXDsPOHkhzl,payload=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,params=LEwTuRWoKVFbrBfInQYNXDsPOHkhGz,headers=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,cookies=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,redirects=LEwTuRWoKVFbrBfInQYNXDsPOHkhtz)
  if LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.status_code not in[200]:return{}
  LEwTuRWoKVFbrBfInQYNXDsPOHkhde=json.loads(LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.text).get('data')
  LEwTuRWoKVFbrBfInQYNXDsPOHkhdC=LEwTuRWoKVFbrBfInQYNXDsPOHkhde.get('title')
  LEwTuRWoKVFbrBfInQYNXDsPOHkhdl =LEwTuRWoKVFbrBfInQYNXDsPOHkhde.get('meta').get('releaseYear')
  LEwTuRWoKVFbrBfInQYNXDsPOHkhdq['saveinfo']['infoLabels']['title']=LEwTuRWoKVFbrBfInQYNXDsPOHkhdC
  if vidtype=='movie':
   LEwTuRWoKVFbrBfInQYNXDsPOHkhdC='%s  (%s)'%(LEwTuRWoKVFbrBfInQYNXDsPOHkhdC,LEwTuRWoKVFbrBfInQYNXDsPOHkhdl)
  LEwTuRWoKVFbrBfInQYNXDsPOHkhdq['saveinfo']['title'] =LEwTuRWoKVFbrBfInQYNXDsPOHkhdC
  LEwTuRWoKVFbrBfInQYNXDsPOHkhdq['saveinfo']['infoLabels']['mpaa'] =LEwTuRWoKVFbrBfInQYNXDsPOHkhde.get('age_rating')
  LEwTuRWoKVFbrBfInQYNXDsPOHkhdq['saveinfo']['infoLabels']['plot'] ='%s\n\n%s'%(LEwTuRWoKVFbrBfInQYNXDsPOHkhde.get('short_description'),LEwTuRWoKVFbrBfInQYNXDsPOHkhde.get('description'))
  LEwTuRWoKVFbrBfInQYNXDsPOHkhdq['saveinfo']['infoLabels']['year'] =LEwTuRWoKVFbrBfInQYNXDsPOHkhdl
  if vidtype=='movie':
   LEwTuRWoKVFbrBfInQYNXDsPOHkhdq['saveinfo']['infoLabels']['duration']=LEwTuRWoKVFbrBfInQYNXDsPOHkhde.get('running_time')
  LEwTuRWoKVFbrBfInQYNXDsPOHkhGl =''
  LEwTuRWoKVFbrBfInQYNXDsPOHkhdi =''
  LEwTuRWoKVFbrBfInQYNXDsPOHkhGA =''
  LEwTuRWoKVFbrBfInQYNXDsPOHkhdj=''
  if LEwTuRWoKVFbrBfInQYNXDsPOHkhde.get('images').get('poster') !=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA:LEwTuRWoKVFbrBfInQYNXDsPOHkhGl =LEwTuRWoKVFbrBfInQYNXDsPOHkhde.get('images').get('poster').get('url') +'?imwidth=350'
  if LEwTuRWoKVFbrBfInQYNXDsPOHkhde.get('images').get('background') !=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA:LEwTuRWoKVFbrBfInQYNXDsPOHkhdi =LEwTuRWoKVFbrBfInQYNXDsPOHkhde.get('images').get('background').get('url') +'?imwidth=600'
  if LEwTuRWoKVFbrBfInQYNXDsPOHkhde.get('images').get('story-art') !=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA:LEwTuRWoKVFbrBfInQYNXDsPOHkhGA =LEwTuRWoKVFbrBfInQYNXDsPOHkhde.get('images').get('story-art').get('url') +'?imwidth=600'
  if LEwTuRWoKVFbrBfInQYNXDsPOHkhde.get('images').get('title-treatment')!=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA:LEwTuRWoKVFbrBfInQYNXDsPOHkhdj=LEwTuRWoKVFbrBfInQYNXDsPOHkhde.get('images').get('title-treatment').get('url')+'?imwidth=300'
  if LEwTuRWoKVFbrBfInQYNXDsPOHkhdi=='':LEwTuRWoKVFbrBfInQYNXDsPOHkhdi=LEwTuRWoKVFbrBfInQYNXDsPOHkhGA
  LEwTuRWoKVFbrBfInQYNXDsPOHkhdq['saveinfo']['thumbnail']['poster']=LEwTuRWoKVFbrBfInQYNXDsPOHkhGl
  LEwTuRWoKVFbrBfInQYNXDsPOHkhdq['saveinfo']['thumbnail']['fanart']=LEwTuRWoKVFbrBfInQYNXDsPOHkhdi
  LEwTuRWoKVFbrBfInQYNXDsPOHkhdq['saveinfo']['thumbnail']['thumb']=LEwTuRWoKVFbrBfInQYNXDsPOHkhGA
  LEwTuRWoKVFbrBfInQYNXDsPOHkhdq['saveinfo']['thumbnail']['clearlogo']=LEwTuRWoKVFbrBfInQYNXDsPOHkhdj
  LEwTuRWoKVFbrBfInQYNXDsPOHkhdS=[]
  for LEwTuRWoKVFbrBfInQYNXDsPOHkhGM in LEwTuRWoKVFbrBfInQYNXDsPOHkhde.get('tags'):LEwTuRWoKVFbrBfInQYNXDsPOHkhdS.append(LEwTuRWoKVFbrBfInQYNXDsPOHkhGM.get('tag'))
  if LEwTuRWoKVFbrBfInQYNXDsPOHkhmJ(LEwTuRWoKVFbrBfInQYNXDsPOHkhdS)>0:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhdq['saveinfo']['infoLabels']['genre']=LEwTuRWoKVFbrBfInQYNXDsPOHkhdS
  LEwTuRWoKVFbrBfInQYNXDsPOHkhdM=[]
  LEwTuRWoKVFbrBfInQYNXDsPOHkhdA=[]
  for LEwTuRWoKVFbrBfInQYNXDsPOHkhGM in LEwTuRWoKVFbrBfInQYNXDsPOHkhde.get('people'):
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhGM.get('role')=='CAST' :LEwTuRWoKVFbrBfInQYNXDsPOHkhdM.append(LEwTuRWoKVFbrBfInQYNXDsPOHkhGM.get('name'))
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhGM.get('role')=='DIRECTOR':LEwTuRWoKVFbrBfInQYNXDsPOHkhdA.append(LEwTuRWoKVFbrBfInQYNXDsPOHkhGM.get('name'))
  if LEwTuRWoKVFbrBfInQYNXDsPOHkhmJ(LEwTuRWoKVFbrBfInQYNXDsPOHkhdM)>0:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhdq['saveinfo']['infoLabels']['cast'] =LEwTuRWoKVFbrBfInQYNXDsPOHkhdM
  if LEwTuRWoKVFbrBfInQYNXDsPOHkhmJ(LEwTuRWoKVFbrBfInQYNXDsPOHkhdA)>0:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhdq['saveinfo']['infoLabels']['director']=LEwTuRWoKVFbrBfInQYNXDsPOHkhdA
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhdq
 def MakeText_FreeList(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,search_list,titleName='title'):
  LEwTuRWoKVFbrBfInQYNXDsPOHkhdy=''
  LEwTuRWoKVFbrBfInQYNXDsPOHkhdU=5
  try:
   for i in LEwTuRWoKVFbrBfInQYNXDsPOHkhtG(LEwTuRWoKVFbrBfInQYNXDsPOHkhmJ(search_list)):
    if i>=LEwTuRWoKVFbrBfInQYNXDsPOHkhdU:
     LEwTuRWoKVFbrBfInQYNXDsPOHkhdy=LEwTuRWoKVFbrBfInQYNXDsPOHkhdy+'...'
     break
    LEwTuRWoKVFbrBfInQYNXDsPOHkhdy=LEwTuRWoKVFbrBfInQYNXDsPOHkhdy+search_list[i][titleName]+'\n'
  except:
   return ''
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhdy
 def Sports_Mainlist_League(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd):
  LEwTuRWoKVFbrBfInQYNXDsPOHkhdv=[] 
  try:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzl='{}/api-discover/v1/sports/leagues/pills'.format(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.API_DOMAIN)
   LEwTuRWoKVFbrBfInQYNXDsPOHkhGz={'platform':'WEBCLIENT','useCircularLogo':'true',}
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzj=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.callRequestCookies('Get',LEwTuRWoKVFbrBfInQYNXDsPOHkhzl,payload=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,params=LEwTuRWoKVFbrBfInQYNXDsPOHkhGz,headers=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,cookies=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA)
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.status_code not in[200]:return[]
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzv=json.loads(LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.text)
   for LEwTuRWoKVFbrBfInQYNXDsPOHkhGt in LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('data'):
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGq={'league_id':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['id'],'league_name':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['name'],'logoUrl':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['logoUrl'],}
    LEwTuRWoKVFbrBfInQYNXDsPOHkhdv.append(LEwTuRWoKVFbrBfInQYNXDsPOHkhGq)
  except LEwTuRWoKVFbrBfInQYNXDsPOHkhma as exception:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhmU(exception)
   return[]
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhdv
 def Sports_League_FeedList(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,leagueID):
  LEwTuRWoKVFbrBfInQYNXDsPOHkhdp=[] 
  try:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzl='{}/api-discover/v1/discover/sports/leagues/{}/feed'.format(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.API_DOMAIN,leagueID)
   LEwTuRWoKVFbrBfInQYNXDsPOHkhGz={'platform':'WEBCLIENT','region':'KR','locale':'ko','includeSportsChannelContents':'true',}
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzj=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.callRequestCookies('Get',LEwTuRWoKVFbrBfInQYNXDsPOHkhzl,payload=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,params=LEwTuRWoKVFbrBfInQYNXDsPOHkhGz,headers=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,cookies=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA)
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.status_code not in[200]:return[]
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzv=json.loads(LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.text).get('data')
   for LEwTuRWoKVFbrBfInQYNXDsPOHkhGt in LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('data'):
    if LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['type']=='Calendar':
     LEwTuRWoKVFbrBfInQYNXDsPOHkhdc =LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.Sports_leagueHome_Livelist(leagueID)
     if LEwTuRWoKVFbrBfInQYNXDsPOHkhdc:
      LEwTuRWoKVFbrBfInQYNXDsPOHkhda =LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.MakeText_FreeList(LEwTuRWoKVFbrBfInQYNXDsPOHkhdc,titleName='preTitle')
      LEwTuRWoKVFbrBfInQYNXDsPOHkhGq={'row_name':'@ 예정 경기 @','preText':LEwTuRWoKVFbrBfInQYNXDsPOHkhda,'subMode':'SP_FEED_LIVE','image':LEwTuRWoKVFbrBfInQYNXDsPOHkhdc[0]['image'],}
      LEwTuRWoKVFbrBfInQYNXDsPOHkhdp.append(LEwTuRWoKVFbrBfInQYNXDsPOHkhGq)
    elif LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['type']=='Live-Events-Curation':
     LEwTuRWoKVFbrBfInQYNXDsPOHkhdc =LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.Sports_LeagueHome_List(data=LEwTuRWoKVFbrBfInQYNXDsPOHkhGt,sType='top10')
     if LEwTuRWoKVFbrBfInQYNXDsPOHkhdc:
      LEwTuRWoKVFbrBfInQYNXDsPOHkhda =LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.MakeText_FreeList(LEwTuRWoKVFbrBfInQYNXDsPOHkhdc,titleName='title')
      LEwTuRWoKVFbrBfInQYNXDsPOHkhGq={'row_name':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['row_name'],'preText':LEwTuRWoKVFbrBfInQYNXDsPOHkhda,'subMode':'SP_FEED_TOP10','image':LEwTuRWoKVFbrBfInQYNXDsPOHkhdc[0]['image'],}
      LEwTuRWoKVFbrBfInQYNXDsPOHkhdp.append(LEwTuRWoKVFbrBfInQYNXDsPOHkhGq)
    elif LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['type']=='Live-Sports-Matches':
     LEwTuRWoKVFbrBfInQYNXDsPOHkhdc =LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.Sports_LeagueHome_List(data=LEwTuRWoKVFbrBfInQYNXDsPOHkhGt,sType='gameVod')
     for LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ in LEwTuRWoKVFbrBfInQYNXDsPOHkhdc:
      LEwTuRWoKVFbrBfInQYNXDsPOHkhGq={'row_name':'{} <{}>'.format(LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ['title'],LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ['startDate']),'preText':LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ['preText'],'subMode':'SP_FEED_GAME','gameID':LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ['id'],'image':LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ['image'],}
      LEwTuRWoKVFbrBfInQYNXDsPOHkhdp.append(LEwTuRWoKVFbrBfInQYNXDsPOHkhGq)
  except LEwTuRWoKVFbrBfInQYNXDsPOHkhma as exception:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhmU(exception)
   return[]
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhdp
 def Sports_League_VodList(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,subMode,leagueID,gameID):
  LEwTuRWoKVFbrBfInQYNXDsPOHkhmg=[] 
  try:
   if subMode=='SP_FEED_LIVE':
    LEwTuRWoKVFbrBfInQYNXDsPOHkhdc =LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.Sports_leagueHome_Livelist(leagueID)
    for LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ in LEwTuRWoKVFbrBfInQYNXDsPOHkhdc:
     LEwTuRWoKVFbrBfInQYNXDsPOHkhGq={'id':LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ.get('event_id'),'title':LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ.get('title'),'image':LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ.get('image'),'startDate':LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ.get('startDate'),'subType':LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ.get('subType'),}
     LEwTuRWoKVFbrBfInQYNXDsPOHkhmg.append(LEwTuRWoKVFbrBfInQYNXDsPOHkhGq)
   elif subMode in['SP_FEED_TOP10','SP_FEED_GAME']:
    LEwTuRWoKVFbrBfInQYNXDsPOHkhzl='{}/api-discover/v1/discover/sports/leagues/{}/feed'.format(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.API_DOMAIN,leagueID)
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGz={'platform':'WEBCLIENT','region':'KR','locale':'ko','includeSportsChannelContents':'true',}
    LEwTuRWoKVFbrBfInQYNXDsPOHkhzj=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.callRequestCookies('Get',LEwTuRWoKVFbrBfInQYNXDsPOHkhzl,payload=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,params=LEwTuRWoKVFbrBfInQYNXDsPOHkhGz,headers=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,cookies=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA)
    if LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.status_code not in[200]:return[]
    LEwTuRWoKVFbrBfInQYNXDsPOHkhzv=json.loads(LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.text).get('data')
    for LEwTuRWoKVFbrBfInQYNXDsPOHkhGt in LEwTuRWoKVFbrBfInQYNXDsPOHkhzv.get('data'):
     if LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['type']=='Live-Events-Curation' and subMode=='SP_FEED_TOP10':
      LEwTuRWoKVFbrBfInQYNXDsPOHkhdc =LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.Sports_LeagueHome_List(data=LEwTuRWoKVFbrBfInQYNXDsPOHkhGt,sType='top10')
      for LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ in LEwTuRWoKVFbrBfInQYNXDsPOHkhdc:
       LEwTuRWoKVFbrBfInQYNXDsPOHkhGq={'id':LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ.get('id'),'title':LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ.get('title'),'image':LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ.get('image'),'startDate':LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ.get('startDate'),'subType':LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ.get('subType'),'running_time':LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ.get('running_time'),}
       LEwTuRWoKVFbrBfInQYNXDsPOHkhmg.append(LEwTuRWoKVFbrBfInQYNXDsPOHkhGq)
     elif LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['type']=='Live-Sports-Matches' and subMode=='SP_FEED_GAME':
      for LEwTuRWoKVFbrBfInQYNXDsPOHkhmz in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['data']:
       if gameID==LEwTuRWoKVFbrBfInQYNXDsPOHkhmz['id']:
        LEwTuRWoKVFbrBfInQYNXDsPOHkhdc =LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.Sports_LeagueHome_SubVods(data=LEwTuRWoKVFbrBfInQYNXDsPOHkhmz)
        for LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ in LEwTuRWoKVFbrBfInQYNXDsPOHkhdc:
         LEwTuRWoKVFbrBfInQYNXDsPOHkhGq={'id':LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ.get('id'),'title':LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ.get('title'),'image':LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ.get('image'),'subType':LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ.get('subType'),'running_time':LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ.get('running_time'),}
         LEwTuRWoKVFbrBfInQYNXDsPOHkhmg.append(LEwTuRWoKVFbrBfInQYNXDsPOHkhGq)
        break
  except LEwTuRWoKVFbrBfInQYNXDsPOHkhma as exception:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhmU(exception)
   return[]
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhmg
 def Sports_LeagueHome_List(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,data,sType=''):
  LEwTuRWoKVFbrBfInQYNXDsPOHkhmG=[]
  try:
   if sType=='top10':
    for LEwTuRWoKVFbrBfInQYNXDsPOHkhGt in data.get('data'):
     LEwTuRWoKVFbrBfInQYNXDsPOHkhmd=''
     if 'channels' in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt:
      LEwTuRWoKVFbrBfInQYNXDsPOHkhmd='패스'
     LEwTuRWoKVFbrBfInQYNXDsPOHkhGq={'id':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['id'],'title':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['title'],'subType':LEwTuRWoKVFbrBfInQYNXDsPOHkhmd,'image':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['images']['story_art_url'],'running_time':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['running_time'],'startDate':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.convert_DateStr(LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['startAt']),}
     LEwTuRWoKVFbrBfInQYNXDsPOHkhmG.append(LEwTuRWoKVFbrBfInQYNXDsPOHkhGq)
   elif sType=='gameVod':
    for LEwTuRWoKVFbrBfInQYNXDsPOHkhGt in data.get('data'):
     if LEwTuRWoKVFbrBfInQYNXDsPOHkhmJ(LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['participants'])>=2:
      LEwTuRWoKVFbrBfInQYNXDsPOHkhmt=LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['participants'][0]['name']
      LEwTuRWoKVFbrBfInQYNXDsPOHkhmx=LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['participants'][1]['name']
      LEwTuRWoKVFbrBfInQYNXDsPOHkhmt=LEwTuRWoKVFbrBfInQYNXDsPOHkhmt+' vs '+LEwTuRWoKVFbrBfInQYNXDsPOHkhmx
     else:
      LEwTuRWoKVFbrBfInQYNXDsPOHkhmt=LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['participants'][0]['name']
     LEwTuRWoKVFbrBfInQYNXDsPOHkhdc=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.Sports_LeagueHome_SubVods(LEwTuRWoKVFbrBfInQYNXDsPOHkhGt)
     LEwTuRWoKVFbrBfInQYNXDsPOHkhda =LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.MakeText_FreeList(LEwTuRWoKVFbrBfInQYNXDsPOHkhdc,titleName='title')
     LEwTuRWoKVFbrBfInQYNXDsPOHkhGq={'id':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['id'],'title':LEwTuRWoKVFbrBfInQYNXDsPOHkhmt,'startDate':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.convert_DateStr(LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['startsAt']),'preText':LEwTuRWoKVFbrBfInQYNXDsPOHkhda,'image':LEwTuRWoKVFbrBfInQYNXDsPOHkhdc[0]['image']}
     LEwTuRWoKVFbrBfInQYNXDsPOHkhmG.append(LEwTuRWoKVFbrBfInQYNXDsPOHkhGq)
  except LEwTuRWoKVFbrBfInQYNXDsPOHkhma as exception:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhmU(exception)
   return[]
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhmG
 def Sports_LeagueHome_SubVods(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,data):
  LEwTuRWoKVFbrBfInQYNXDsPOHkhdc=[]
  try:
   for LEwTuRWoKVFbrBfInQYNXDsPOHkhGt in data.get('highlights'):
    LEwTuRWoKVFbrBfInQYNXDsPOHkhmd=''
    if 'channels' in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt:
     LEwTuRWoKVFbrBfInQYNXDsPOHkhmd='패스'
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGq={'id':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['id'],'title':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['title'],'image':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['images']['story-art']['url'],'subType':LEwTuRWoKVFbrBfInQYNXDsPOHkhmd,'running_time':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['running_time'],}
    LEwTuRWoKVFbrBfInQYNXDsPOHkhdc.append(LEwTuRWoKVFbrBfInQYNXDsPOHkhGq)
  except LEwTuRWoKVFbrBfInQYNXDsPOHkhma as exception:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhmU(exception)
   return[]
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhdc
 def Sports_leagueHome_Livelist(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,leagueID):
  LEwTuRWoKVFbrBfInQYNXDsPOHkhdc=[]
  try:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzl='{}/api-discover/v1/sports/curated-schedule/events'.format(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.API_DOMAIN)
   LEwTuRWoKVFbrBfInQYNXDsPOHkhGz={'league_id':leagueID,'region':'KR','locale':'ko','scope':'live-upcoming','includeHighlights':'false','includeSportsChannelContents':'true',}
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzG={'x-membersrl':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['COOKIES']['member_srl'],'x-pcid':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['COOKIES']['PCID'],'x-profileid':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT',}
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzj=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.callRequestCookies('Get',LEwTuRWoKVFbrBfInQYNXDsPOHkhzl,payload=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,params=LEwTuRWoKVFbrBfInQYNXDsPOHkhGz,headers=LEwTuRWoKVFbrBfInQYNXDsPOHkhzG,cookies=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA)
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.status_code not in[200]:return[]
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzv=json.loads(LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.text).get('data')
   for LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ in LEwTuRWoKVFbrBfInQYNXDsPOHkhzv:
    if LEwTuRWoKVFbrBfInQYNXDsPOHkhmJ(LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ['teams'])>=2:
     LEwTuRWoKVFbrBfInQYNXDsPOHkhmt=LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ['teams'][0]['name']
     LEwTuRWoKVFbrBfInQYNXDsPOHkhmx=LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ['teams'][1]['name']
     LEwTuRWoKVFbrBfInQYNXDsPOHkhmt=LEwTuRWoKVFbrBfInQYNXDsPOHkhmt+' vs '+LEwTuRWoKVFbrBfInQYNXDsPOHkhmx
    else:
     LEwTuRWoKVFbrBfInQYNXDsPOHkhmt=LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ['teams'][0]['name']
    LEwTuRWoKVFbrBfInQYNXDsPOHkhmq=''
    if LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ.get('images'):
     LEwTuRWoKVFbrBfInQYNXDsPOHkhmq=LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ.get('images').get('story_art_url')
    LEwTuRWoKVFbrBfInQYNXDsPOHkhme=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.convert_TimeStr(LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ['start_at'])
    LEwTuRWoKVFbrBfInQYNXDsPOHkhmd=''
    if 'channels' in LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ:
     LEwTuRWoKVFbrBfInQYNXDsPOHkhmd='패스'
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGq={'event_id':LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ['event_id'],'title':LEwTuRWoKVFbrBfInQYNXDsPOHkhmt,'startDate':LEwTuRWoKVFbrBfInQYNXDsPOHkhme,'image':LEwTuRWoKVFbrBfInQYNXDsPOHkhmq,'preTitle':'{} <{}>'.format(LEwTuRWoKVFbrBfInQYNXDsPOHkhmt,LEwTuRWoKVFbrBfInQYNXDsPOHkhme),'subType':LEwTuRWoKVFbrBfInQYNXDsPOHkhmd,}
    LEwTuRWoKVFbrBfInQYNXDsPOHkhdc.append(LEwTuRWoKVFbrBfInQYNXDsPOHkhGq)
  except LEwTuRWoKVFbrBfInQYNXDsPOHkhma as exception:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhmU(exception)
   return[]
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhdc
 def Sports_MultiHero_LiveList(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd):
  LEwTuRWoKVFbrBfInQYNXDsPOHkhmC=[]
  try:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzl='{}/api-discover/v1/sports/feed'.format(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.API_DOMAIN)
   LEwTuRWoKVFbrBfInQYNXDsPOHkhGz={'platform':'WEBCLIENT','region':'KR','locale':'ko','filterRestrictedContent':'false','preferRecoFeed':'true','preferMultiHeroMixedContentRow':'true','category':'LIVE','perPage':'7','allowOtherRailsAboveHero':'true','includeSportsChannelContents':'true','page':'1',}
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzj=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.callRequestCookies('Get',LEwTuRWoKVFbrBfInQYNXDsPOHkhzl,payload=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,params=LEwTuRWoKVFbrBfInQYNXDsPOHkhGz,headers=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,cookies=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA)
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.status_code not in[200]:return[]
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzv=json.loads(LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.text).get('data')
   for LEwTuRWoKVFbrBfInQYNXDsPOHkhGt in LEwTuRWoKVFbrBfInQYNXDsPOHkhzv:
    if LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('type')=='Multi-Hero-Live-Event-Curation':
     for LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('data'):
      LEwTuRWoKVFbrBfInQYNXDsPOHkhme=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.convert_TimeStr(LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ['startAt'])
      LEwTuRWoKVFbrBfInQYNXDsPOHkhmq=''
      if LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ.get('images'):
       if LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ.get('images').get('hero_url'):
        LEwTuRWoKVFbrBfInQYNXDsPOHkhmq=LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ.get('images').get('hero_url')
       elif LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ.get('images').get('sports_hero_mobile_url'):
        LEwTuRWoKVFbrBfInQYNXDsPOHkhmq=LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ.get('images').get('sports_hero_mobile_url')
      LEwTuRWoKVFbrBfInQYNXDsPOHkhmd=''
      if 'channels' in LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ:
       LEwTuRWoKVFbrBfInQYNXDsPOHkhmd='패스'
      LEwTuRWoKVFbrBfInQYNXDsPOHkhGq={'id':LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ['id'],'title':LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ['title'],'startDate':LEwTuRWoKVFbrBfInQYNXDsPOHkhme,'image':LEwTuRWoKVFbrBfInQYNXDsPOHkhmq,'preTitle':'{} <{}>'.format(LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ['title'],LEwTuRWoKVFbrBfInQYNXDsPOHkhme),'subType':LEwTuRWoKVFbrBfInQYNXDsPOHkhmd,}
      LEwTuRWoKVFbrBfInQYNXDsPOHkhmC.append(LEwTuRWoKVFbrBfInQYNXDsPOHkhGq)
     break
  except LEwTuRWoKVFbrBfInQYNXDsPOHkhma as exception:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhmU(exception)
   return[]
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhmC
 def Sports_Season_Group(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,leagueID):
  LEwTuRWoKVFbrBfInQYNXDsPOHkhml=[]
  try:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzl='{}/api-discover/v1/discover/sports/leagues/{}/filters'.format(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.API_DOMAIN,leagueID)
   LEwTuRWoKVFbrBfInQYNXDsPOHkhGz={'platform':'WEBCLIENT','locale':'ko','includeSportsChannelContents':'true',}
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzG={'x-membersrl':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['COOKIES']['member_srl'],'x-pcid':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['COOKIES']['PCID'],'x-profileid':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT',}
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzj=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.callRequestCookies('Get',LEwTuRWoKVFbrBfInQYNXDsPOHkhzl,payload=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,params=LEwTuRWoKVFbrBfInQYNXDsPOHkhGz,headers=LEwTuRWoKVFbrBfInQYNXDsPOHkhzG,cookies=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA)
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.status_code not in[200]:return[]
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzv=json.loads(LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.text).get('data')
   for LEwTuRWoKVFbrBfInQYNXDsPOHkhGt in LEwTuRWoKVFbrBfInQYNXDsPOHkhzv:
    LEwTuRWoKVFbrBfInQYNXDsPOHkhmi=[]
    for LEwTuRWoKVFbrBfInQYNXDsPOHkhmj in LEwTuRWoKVFbrBfInQYNXDsPOHkhGt.get('stages'):
     LEwTuRWoKVFbrBfInQYNXDsPOHkhmS={'title':LEwTuRWoKVFbrBfInQYNXDsPOHkhmj['name'],}
     LEwTuRWoKVFbrBfInQYNXDsPOHkhmi.append(LEwTuRWoKVFbrBfInQYNXDsPOHkhmS)
    LEwTuRWoKVFbrBfInQYNXDsPOHkhda=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.MakeText_FreeList(LEwTuRWoKVFbrBfInQYNXDsPOHkhmi,titleName='title')
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGq={'season':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['season'],'preText':LEwTuRWoKVFbrBfInQYNXDsPOHkhda,}
    LEwTuRWoKVFbrBfInQYNXDsPOHkhml.append(LEwTuRWoKVFbrBfInQYNXDsPOHkhGq)
  except LEwTuRWoKVFbrBfInQYNXDsPOHkhma as exception:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhmU(exception)
   return[]
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhml
 def Sports_Season_GameList(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,leagueID,seasonID,page=1):
  LEwTuRWoKVFbrBfInQYNXDsPOHkhmG=[]
  try:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzl='{}/api-discover/v2/sports/leagues/{}/schedule/previous'.format(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.API_DOMAIN,leagueID)
   LEwTuRWoKVFbrBfInQYNXDsPOHkhGz={'seasons':seasonID,'stageIds':'','teamIds':'','platform':'WEBCLIENT','locale':'ko','region':'KR','perPage':'10','includeSportsChannelContents':'true','page':LEwTuRWoKVFbrBfInQYNXDsPOHkhmv(page),}
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzG={'x-membersrl':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['COOKIES']['member_srl'],'x-pcid':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['COOKIES']['PCID'],'x-profileid':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT',}
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzj=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.callRequestCookies('Get',LEwTuRWoKVFbrBfInQYNXDsPOHkhzl,payload=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,params=LEwTuRWoKVFbrBfInQYNXDsPOHkhGz,headers=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,cookies=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA)
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.status_code not in[200]:return[]
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzv=json.loads(LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.text).get('data')
   for LEwTuRWoKVFbrBfInQYNXDsPOHkhGt in LEwTuRWoKVFbrBfInQYNXDsPOHkhzv:
    if LEwTuRWoKVFbrBfInQYNXDsPOHkhmJ(LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['participants'])>=2:
     LEwTuRWoKVFbrBfInQYNXDsPOHkhmt=LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['participants'][0]['name']
     LEwTuRWoKVFbrBfInQYNXDsPOHkhmx=LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['participants'][1]['name']
     LEwTuRWoKVFbrBfInQYNXDsPOHkhmt=LEwTuRWoKVFbrBfInQYNXDsPOHkhmt+' vs '+LEwTuRWoKVFbrBfInQYNXDsPOHkhmx
    else:
     LEwTuRWoKVFbrBfInQYNXDsPOHkhmt=LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['participants'][0]['name']
    LEwTuRWoKVFbrBfInQYNXDsPOHkhdc=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.Sports_LeagueHome_SubVods(LEwTuRWoKVFbrBfInQYNXDsPOHkhGt)
    LEwTuRWoKVFbrBfInQYNXDsPOHkhda =LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.MakeText_FreeList(LEwTuRWoKVFbrBfInQYNXDsPOHkhdc,titleName='title')
    LEwTuRWoKVFbrBfInQYNXDsPOHkhGq={'id':LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['id'],'title':LEwTuRWoKVFbrBfInQYNXDsPOHkhmt,'startDate':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.convert_DateStr(LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['startsAt']),'preText':LEwTuRWoKVFbrBfInQYNXDsPOHkhda,'image':LEwTuRWoKVFbrBfInQYNXDsPOHkhdc[0]['image']}
    LEwTuRWoKVFbrBfInQYNXDsPOHkhmG.append(LEwTuRWoKVFbrBfInQYNXDsPOHkhGq)
  except LEwTuRWoKVFbrBfInQYNXDsPOHkhma as exception:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhmU(exception)
   return[]
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhmG
 def Sports_Season_GameVod(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd,leagueID,seasonID,page,gameID):
  LEwTuRWoKVFbrBfInQYNXDsPOHkhmg=[]
  try:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzl='{}/api-discover/v2/sports/leagues/{}/schedule/previous'.format(LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.API_DOMAIN,leagueID)
   LEwTuRWoKVFbrBfInQYNXDsPOHkhGz={'seasons':seasonID,'stageIds':'','teamIds':'','platform':'WEBCLIENT','locale':'ko','region':'KR','perPage':'10','includeSportsChannelContents':'true','page':LEwTuRWoKVFbrBfInQYNXDsPOHkhmv(page),}
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzG={'x-membersrl':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['COOKIES']['member_srl'],'x-pcid':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['COOKIES']['PCID'],'x-profileid':LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT',}
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzj=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.callRequestCookies('Get',LEwTuRWoKVFbrBfInQYNXDsPOHkhzl,payload=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,params=LEwTuRWoKVFbrBfInQYNXDsPOHkhGz,headers=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA,cookies=LEwTuRWoKVFbrBfInQYNXDsPOHkhmA)
   if LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.status_code not in[200]:return[]
   LEwTuRWoKVFbrBfInQYNXDsPOHkhzv=json.loads(LEwTuRWoKVFbrBfInQYNXDsPOHkhzj.text).get('data')
   for LEwTuRWoKVFbrBfInQYNXDsPOHkhGt in LEwTuRWoKVFbrBfInQYNXDsPOHkhzv:
    if gameID==LEwTuRWoKVFbrBfInQYNXDsPOHkhGt['id']:
     LEwTuRWoKVFbrBfInQYNXDsPOHkhdc=LEwTuRWoKVFbrBfInQYNXDsPOHkhgd.Sports_LeagueHome_SubVods(LEwTuRWoKVFbrBfInQYNXDsPOHkhGt)
     for LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ in LEwTuRWoKVFbrBfInQYNXDsPOHkhdc:
      LEwTuRWoKVFbrBfInQYNXDsPOHkhGq={'id':LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ.get('id'),'title':LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ.get('title'),'image':LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ.get('image'),'subType':LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ.get('subType'),'running_time':LEwTuRWoKVFbrBfInQYNXDsPOHkhdJ.get('running_time'),}
      LEwTuRWoKVFbrBfInQYNXDsPOHkhmg.append(LEwTuRWoKVFbrBfInQYNXDsPOHkhGq)
  except LEwTuRWoKVFbrBfInQYNXDsPOHkhma as exception:
   LEwTuRWoKVFbrBfInQYNXDsPOHkhmU(exception)
   return[]
  return LEwTuRWoKVFbrBfInQYNXDsPOHkhmg
# Created by pyminifier (https://github.com/liftoff/pyminifier)
