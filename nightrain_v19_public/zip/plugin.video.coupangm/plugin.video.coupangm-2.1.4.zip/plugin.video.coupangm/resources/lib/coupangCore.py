__author__="NightRain"
GEjpyPFHdlabiAVJvIrcwnThkRKMxu=object
GEjpyPFHdlabiAVJvIrcwnThkRKMxt=None
GEjpyPFHdlabiAVJvIrcwnThkRKMxQ=False
GEjpyPFHdlabiAVJvIrcwnThkRKMxg=print
GEjpyPFHdlabiAVJvIrcwnThkRKMxO=str
GEjpyPFHdlabiAVJvIrcwnThkRKMxf=open
GEjpyPFHdlabiAVJvIrcwnThkRKMxL=int
GEjpyPFHdlabiAVJvIrcwnThkRKMxm=Exception
GEjpyPFHdlabiAVJvIrcwnThkRKMxS=id
GEjpyPFHdlabiAVJvIrcwnThkRKMxN=True
GEjpyPFHdlabiAVJvIrcwnThkRKMxY=len
GEjpyPFHdlabiAVJvIrcwnThkRKMxU=range
import urllib
import re
import json
import requests
import datetime
import time
import random
import base64
class GEjpyPFHdlabiAVJvIrcwnThkRKMBq(GEjpyPFHdlabiAVJvIrcwnThkRKMxu):
 def __init__(GEjpyPFHdlabiAVJvIrcwnThkRKMBX):
  GEjpyPFHdlabiAVJvIrcwnThkRKMBX.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36'
  GEjpyPFHdlabiAVJvIrcwnThkRKMBX.MODEL ='Chrome_119' 
  GEjpyPFHdlabiAVJvIrcwnThkRKMBX.OS_VERSION ='119' 
  GEjpyPFHdlabiAVJvIrcwnThkRKMBX.DEFAULT_HEADER ={'user-agent':GEjpyPFHdlabiAVJvIrcwnThkRKMBX.USER_AGENT}
  GEjpyPFHdlabiAVJvIrcwnThkRKMBX.API_DOMAIN ='https://www.coupangplay.com'
  GEjpyPFHdlabiAVJvIrcwnThkRKMBX.API_VIEWURL ='https://discover.coupangstreaming.com'
  GEjpyPFHdlabiAVJvIrcwnThkRKMBX.PAGE_LIMIT =40
  GEjpyPFHdlabiAVJvIrcwnThkRKMBX.SEARCH_LIMIT =20
  GEjpyPFHdlabiAVJvIrcwnThkRKMBX.KodiVersion =20
  GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP={}
  GEjpyPFHdlabiAVJvIrcwnThkRKMBX.Init_CP()
  GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP_DEVICE_FILENAME=''
  GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP_COOKIE_FILENAME=''
 def callRequestCookies(GEjpyPFHdlabiAVJvIrcwnThkRKMBX,jobtype,GEjpyPFHdlabiAVJvIrcwnThkRKMqX,payload=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,params=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,headers=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,cookies=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,redirects=GEjpyPFHdlabiAVJvIrcwnThkRKMxQ):
  GEjpyPFHdlabiAVJvIrcwnThkRKMBx=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.DEFAULT_HEADER
  if headers:GEjpyPFHdlabiAVJvIrcwnThkRKMBx.update(headers)
  if jobtype=='Get':
   GEjpyPFHdlabiAVJvIrcwnThkRKMBW=requests.get(GEjpyPFHdlabiAVJvIrcwnThkRKMqX,params=params,headers=GEjpyPFHdlabiAVJvIrcwnThkRKMBx,cookies=cookies,allow_redirects=redirects)
  else:
   GEjpyPFHdlabiAVJvIrcwnThkRKMBW=requests.post(GEjpyPFHdlabiAVJvIrcwnThkRKMqX,data=payload,params=params,headers=GEjpyPFHdlabiAVJvIrcwnThkRKMBx,cookies=cookies,allow_redirects=redirects)
  GEjpyPFHdlabiAVJvIrcwnThkRKMxg(GEjpyPFHdlabiAVJvIrcwnThkRKMxO(GEjpyPFHdlabiAVJvIrcwnThkRKMBW.status_code)+' - '+GEjpyPFHdlabiAVJvIrcwnThkRKMxO(GEjpyPFHdlabiAVJvIrcwnThkRKMBW.url))
  return GEjpyPFHdlabiAVJvIrcwnThkRKMBW
 def callRequestCookies_test(GEjpyPFHdlabiAVJvIrcwnThkRKMBX,jobtype,GEjpyPFHdlabiAVJvIrcwnThkRKMqX,payload=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,params=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,headers=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,cookies=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,redirects=GEjpyPFHdlabiAVJvIrcwnThkRKMxQ):
  GEjpyPFHdlabiAVJvIrcwnThkRKMBx=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.DEFAULT_HEADER
  if headers:GEjpyPFHdlabiAVJvIrcwnThkRKMBx.update(headers)
  GEjpyPFHdlabiAVJvIrcwnThkRKMBW=requests.Request('POST',GEjpyPFHdlabiAVJvIrcwnThkRKMqX,headers=headers,data=payload,params=params,cookies=cookies)
  GEjpyPFHdlabiAVJvIrcwnThkRKMBz=GEjpyPFHdlabiAVJvIrcwnThkRKMBW.prepare()
  GEjpyPFHdlabiAVJvIrcwnThkRKMBX.pretty_print_POST(GEjpyPFHdlabiAVJvIrcwnThkRKMBz)
  return GEjpyPFHdlabiAVJvIrcwnThkRKMBW
 def pretty_print_POST(GEjpyPFHdlabiAVJvIrcwnThkRKMBX,req):
  GEjpyPFHdlabiAVJvIrcwnThkRKMxg('{}\n{}\r\n{}\r\n\r\n{}'.format('-----------START-----------',req.method+' '+req.url,'\r\n'.join('{}: {}'.format(k,v)for k,v in req.headers.items()),req.body,))
 def dic_To_jsonfile(GEjpyPFHdlabiAVJvIrcwnThkRKMBX,filename,GEjpyPFHdlabiAVJvIrcwnThkRKMBo):
  if filename=='':return
  fp=GEjpyPFHdlabiAVJvIrcwnThkRKMxf(filename,'w',-1,'utf-8')
  json.dump(GEjpyPFHdlabiAVJvIrcwnThkRKMBo,fp,indent=4,ensure_ascii=GEjpyPFHdlabiAVJvIrcwnThkRKMxQ)
  fp.close()
 def jsonfile_To_dic(GEjpyPFHdlabiAVJvIrcwnThkRKMBX,filename):
  if filename=='':return GEjpyPFHdlabiAVJvIrcwnThkRKMxt
  try:
   fp=GEjpyPFHdlabiAVJvIrcwnThkRKMxf(filename,'r',-1,'utf-8')
   GEjpyPFHdlabiAVJvIrcwnThkRKMBD=json.load(fp)
   fp.close()
  except:
   GEjpyPFHdlabiAVJvIrcwnThkRKMBD={}
  return GEjpyPFHdlabiAVJvIrcwnThkRKMBD
 def convert_TimeStr(GEjpyPFHdlabiAVJvIrcwnThkRKMBX,GEjpyPFHdlabiAVJvIrcwnThkRKMBC):
  try:
   GEjpyPFHdlabiAVJvIrcwnThkRKMBC =GEjpyPFHdlabiAVJvIrcwnThkRKMBC[0:16]
   GEjpyPFHdlabiAVJvIrcwnThkRKMBs=datetime.datetime.strptime(GEjpyPFHdlabiAVJvIrcwnThkRKMBC,'%Y-%m-%dT%H:%M')+datetime.timedelta(hours=9)
   return GEjpyPFHdlabiAVJvIrcwnThkRKMBs.strftime('%Y-%m-%d %H:%M')
  except:
   return GEjpyPFHdlabiAVJvIrcwnThkRKMxt
 def Get_Now_Datetime(GEjpyPFHdlabiAVJvIrcwnThkRKMBX):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetNoCache(GEjpyPFHdlabiAVJvIrcwnThkRKMBX):
  GEjpyPFHdlabiAVJvIrcwnThkRKMBt =GEjpyPFHdlabiAVJvIrcwnThkRKMxL(time.time()*1000)
  return GEjpyPFHdlabiAVJvIrcwnThkRKMBt
 def generatePcId(GEjpyPFHdlabiAVJvIrcwnThkRKMBX):
  t=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.GetNoCache()
  r=random.random()
  GEjpyPFHdlabiAVJvIrcwnThkRKMBQ=GEjpyPFHdlabiAVJvIrcwnThkRKMxO(t)+GEjpyPFHdlabiAVJvIrcwnThkRKMxO(r)[2:12]
  return GEjpyPFHdlabiAVJvIrcwnThkRKMBQ
 def generatePvId(GEjpyPFHdlabiAVJvIrcwnThkRKMBX,genType='1'):
  import hashlib
  m=hashlib.md5()
  GEjpyPFHdlabiAVJvIrcwnThkRKMBg=GEjpyPFHdlabiAVJvIrcwnThkRKMxO(random.random())
  m.update(GEjpyPFHdlabiAVJvIrcwnThkRKMBg.encode('utf-8'))
  GEjpyPFHdlabiAVJvIrcwnThkRKMBO=GEjpyPFHdlabiAVJvIrcwnThkRKMxO(m.hexdigest())
  if genType=='1':
   return '%s-%s-%s-%s-%s'%(GEjpyPFHdlabiAVJvIrcwnThkRKMBO[:8],GEjpyPFHdlabiAVJvIrcwnThkRKMBO[8:12],GEjpyPFHdlabiAVJvIrcwnThkRKMBO[12:16],GEjpyPFHdlabiAVJvIrcwnThkRKMBO[16:20],GEjpyPFHdlabiAVJvIrcwnThkRKMBO[20:])
  else:
   return GEjpyPFHdlabiAVJvIrcwnThkRKMBO
 def Get_DeviceID(GEjpyPFHdlabiAVJvIrcwnThkRKMBX):
  GEjpyPFHdlabiAVJvIrcwnThkRKMBf=''
  try: 
   fp=GEjpyPFHdlabiAVJvIrcwnThkRKMxf(GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP_DEVICE_FILENAME,'r',-1,'utf-8')
   GEjpyPFHdlabiAVJvIrcwnThkRKMBL= json.load(fp)
   fp.close()
   GEjpyPFHdlabiAVJvIrcwnThkRKMBf=GEjpyPFHdlabiAVJvIrcwnThkRKMBL.get('device_id')
  except GEjpyPFHdlabiAVJvIrcwnThkRKMxm as exception:
   GEjpyPFHdlabiAVJvIrcwnThkRKMxt
  if GEjpyPFHdlabiAVJvIrcwnThkRKMBf=='':
   GEjpyPFHdlabiAVJvIrcwnThkRKMBf=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.generatePvId(genType='1')
   try: 
    fp=GEjpyPFHdlabiAVJvIrcwnThkRKMxf(GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP_DEVICE_FILENAME,'w',-1,'utf-8')
    json.dump({'device_id':GEjpyPFHdlabiAVJvIrcwnThkRKMBf},fp,indent=4,ensure_ascii=GEjpyPFHdlabiAVJvIrcwnThkRKMxQ)
    fp.close()
   except GEjpyPFHdlabiAVJvIrcwnThkRKMxm as exception:
    return ''
  return GEjpyPFHdlabiAVJvIrcwnThkRKMBf
 def Make_authHeader(GEjpyPFHdlabiAVJvIrcwnThkRKMBX):
  tr=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.generatePvId(genType=2)
  ti=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.GetNoCache()
  GEjpyPFHdlabiAVJvIrcwnThkRKMxS=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.generatePvId(genType=2)[:16]
  GEjpyPFHdlabiAVJvIrcwnThkRKMBm='00-%s-%s-01'%(tr,GEjpyPFHdlabiAVJvIrcwnThkRKMxS,)
  GEjpyPFHdlabiAVJvIrcwnThkRKMBS ='%s@nr=0-1-%s-%s-%s----%s'%(GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['SESSION']['NREUM']['tk'],GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['SESSION']['NREUM']['ac'],GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['SESSION']['NREUM']['ap'],GEjpyPFHdlabiAVJvIrcwnThkRKMxS,ti,)
  GEjpyPFHdlabiAVJvIrcwnThkRKMBN ='{"v":[0,1],"d":{"ty":"Browser","ac":"%s","ap":"%s","id":"%s","tr":"%s","ti":%s,"tk":"%s"}}'%(GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['SESSION']['NREUM']['ac'],GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['SESSION']['NREUM']['ap'],GEjpyPFHdlabiAVJvIrcwnThkRKMxS,tr,ti,GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['SESSION']['NREUM']['tk'],) 
  return GEjpyPFHdlabiAVJvIrcwnThkRKMBm,GEjpyPFHdlabiAVJvIrcwnThkRKMBS,base64.standard_b64encode(GEjpyPFHdlabiAVJvIrcwnThkRKMBN.encode()).decode('utf-8')
 def Init_CP(GEjpyPFHdlabiAVJvIrcwnThkRKMBX):
  GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP={}
  GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['ACCOUNT']={'cpid':'','cppw':'','cppf':'0'}
  GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['SESSION']={}
  GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['COOKIES']={}
 def Save_session_acount(GEjpyPFHdlabiAVJvIrcwnThkRKMBX,GEjpyPFHdlabiAVJvIrcwnThkRKMBY,GEjpyPFHdlabiAVJvIrcwnThkRKMBU,GEjpyPFHdlabiAVJvIrcwnThkRKMqB):
  GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['ACCOUNT']['cpid']=base64.standard_b64encode(GEjpyPFHdlabiAVJvIrcwnThkRKMBY.encode()).decode('utf-8')
  GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['ACCOUNT']['cppw']=base64.standard_b64encode(GEjpyPFHdlabiAVJvIrcwnThkRKMBU.encode()).decode('utf-8')
  GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['ACCOUNT']['cppf']=GEjpyPFHdlabiAVJvIrcwnThkRKMxO(GEjpyPFHdlabiAVJvIrcwnThkRKMqB)
 def Load_session_acount(GEjpyPFHdlabiAVJvIrcwnThkRKMBX):
  GEjpyPFHdlabiAVJvIrcwnThkRKMBY=base64.standard_b64decode(GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['ACCOUNT']['cpid']).decode('utf-8')
  GEjpyPFHdlabiAVJvIrcwnThkRKMBU=base64.standard_b64decode(GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['ACCOUNT']['cppw']).decode('utf-8')
  GEjpyPFHdlabiAVJvIrcwnThkRKMqB=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['ACCOUNT']['cppf']
  return GEjpyPFHdlabiAVJvIrcwnThkRKMBY,GEjpyPFHdlabiAVJvIrcwnThkRKMBU,GEjpyPFHdlabiAVJvIrcwnThkRKMqB
 def make_CP_DefaultCookies(GEjpyPFHdlabiAVJvIrcwnThkRKMBX):
  return GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['COOKIES']
 def Get_CP_Login(GEjpyPFHdlabiAVJvIrcwnThkRKMBX,userid,userpw,GEjpyPFHdlabiAVJvIrcwnThkRKMqQ):
  try:
   GEjpyPFHdlabiAVJvIrcwnThkRKMqX=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.API_DOMAIN
   GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['COOKIES']['NEXT_LOCALE']='ko'
   GEjpyPFHdlabiAVJvIrcwnThkRKMqx={'Accept-Language':'ko-KR,ko;q=0.9','Sec-Ch-Ua-Mobile':'?0','Sec-Ch-Ua-Platform':'"Windows"','Sec-Fetch-Dest':'document','Sec-Fetch-Mode':'navigate','Sec-Fetch-Site':'none','Sec-Fetch-User':'?1','Upgrade-Insecure-Requests':'1',}
   GEjpyPFHdlabiAVJvIrcwnThkRKMqW=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.make_CP_DefaultCookies()
   GEjpyPFHdlabiAVJvIrcwnThkRKMqz=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.callRequestCookies('Get',GEjpyPFHdlabiAVJvIrcwnThkRKMqX,payload=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,params=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,headers=GEjpyPFHdlabiAVJvIrcwnThkRKMqx,cookies=GEjpyPFHdlabiAVJvIrcwnThkRKMqW,redirects=GEjpyPFHdlabiAVJvIrcwnThkRKMxN)
   if GEjpyPFHdlabiAVJvIrcwnThkRKMqz.status_code not in[200]:return GEjpyPFHdlabiAVJvIrcwnThkRKMxQ
   for GEjpyPFHdlabiAVJvIrcwnThkRKMqo in GEjpyPFHdlabiAVJvIrcwnThkRKMqz.cookies:
    GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['COOKIES'][GEjpyPFHdlabiAVJvIrcwnThkRKMqo.name]=GEjpyPFHdlabiAVJvIrcwnThkRKMqo.value
   GEjpyPFHdlabiAVJvIrcwnThkRKMqW=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.make_CP_DefaultCookies()
   if GEjpyPFHdlabiAVJvIrcwnThkRKMqz.status_code not in[200]:return GEjpyPFHdlabiAVJvIrcwnThkRKMxQ
   GEjpyPFHdlabiAVJvIrcwnThkRKMqe=re.findall('NREUM.loader_config=\{[\w\d\":,-]+\}',GEjpyPFHdlabiAVJvIrcwnThkRKMqz.text)[0].split('=')[1]
   GEjpyPFHdlabiAVJvIrcwnThkRKMqe=GEjpyPFHdlabiAVJvIrcwnThkRKMqe.replace('{','{"').replace(':','":').replace(',',',"')
   GEjpyPFHdlabiAVJvIrcwnThkRKMqe=json.loads(GEjpyPFHdlabiAVJvIrcwnThkRKMqe)
   GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['SESSION']['NREUM']={'ac':GEjpyPFHdlabiAVJvIrcwnThkRKMqe['accountID'],'tk':GEjpyPFHdlabiAVJvIrcwnThkRKMqe['trustKey'],'ap':GEjpyPFHdlabiAVJvIrcwnThkRKMqe['agentID'],'lk':GEjpyPFHdlabiAVJvIrcwnThkRKMqe['licenseKey'],}
  except GEjpyPFHdlabiAVJvIrcwnThkRKMxm as exception:
   GEjpyPFHdlabiAVJvIrcwnThkRKMxg(exception)
   return GEjpyPFHdlabiAVJvIrcwnThkRKMxQ
  try:
   GEjpyPFHdlabiAVJvIrcwnThkRKMqX=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.API_DOMAIN+'/api/auth'
   GEjpyPFHdlabiAVJvIrcwnThkRKMqD=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.Get_DeviceID()
   GEjpyPFHdlabiAVJvIrcwnThkRKMqC =GEjpyPFHdlabiAVJvIrcwnThkRKMqD.split('-')[0]
   GEjpyPFHdlabiAVJvIrcwnThkRKMBm,GEjpyPFHdlabiAVJvIrcwnThkRKMBS,GEjpyPFHdlabiAVJvIrcwnThkRKMBN=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.Make_authHeader()
   GEjpyPFHdlabiAVJvIrcwnThkRKMqx={'traceparent':GEjpyPFHdlabiAVJvIrcwnThkRKMBm,'tracestate':GEjpyPFHdlabiAVJvIrcwnThkRKMBS,'newrelic':GEjpyPFHdlabiAVJvIrcwnThkRKMBN,'content-type':'application/json','x-app-version':'1.26.1','x-device-id':'','x-device-os-version':GEjpyPFHdlabiAVJvIrcwnThkRKMBX.OS_VERSION,'x-nr-session-id':GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['COOKIES']['session_web_id'],'x-pcid':'',}
   GEjpyPFHdlabiAVJvIrcwnThkRKMqs={'device':{'deviceId':'web-'+GEjpyPFHdlabiAVJvIrcwnThkRKMqD,'model':GEjpyPFHdlabiAVJvIrcwnThkRKMBX.MODEL,'name':'Chrome Desktop '+GEjpyPFHdlabiAVJvIrcwnThkRKMqC,'os':'Windows','osVersion':'10','type':'webclient',},'email':userid,'password':userpw,}
   GEjpyPFHdlabiAVJvIrcwnThkRKMqs=json.dumps(GEjpyPFHdlabiAVJvIrcwnThkRKMqs,separators=(',',':'))
   GEjpyPFHdlabiAVJvIrcwnThkRKMqW=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.make_CP_DefaultCookies()
   GEjpyPFHdlabiAVJvIrcwnThkRKMqz=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.callRequestCookies('Post',GEjpyPFHdlabiAVJvIrcwnThkRKMqX,payload=GEjpyPFHdlabiAVJvIrcwnThkRKMqs,params=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,headers=GEjpyPFHdlabiAVJvIrcwnThkRKMqx,cookies=GEjpyPFHdlabiAVJvIrcwnThkRKMqW,redirects=GEjpyPFHdlabiAVJvIrcwnThkRKMxQ)
   if GEjpyPFHdlabiAVJvIrcwnThkRKMqz.status_code not in[200]:
    GEjpyPFHdlabiAVJvIrcwnThkRKMqu=json.loads(GEjpyPFHdlabiAVJvIrcwnThkRKMqz.text)
    if 'error' in GEjpyPFHdlabiAVJvIrcwnThkRKMqu:
     GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['SESSION']['error']=GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('error').get('detail')
    return GEjpyPFHdlabiAVJvIrcwnThkRKMxQ
   GEjpyPFHdlabiAVJvIrcwnThkRKMxg('---')
   for GEjpyPFHdlabiAVJvIrcwnThkRKMqo in GEjpyPFHdlabiAVJvIrcwnThkRKMqz.cookies:
    GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['COOKIES'][GEjpyPFHdlabiAVJvIrcwnThkRKMqo.name]=GEjpyPFHdlabiAVJvIrcwnThkRKMqo.value
  except GEjpyPFHdlabiAVJvIrcwnThkRKMxm as exception:
   GEjpyPFHdlabiAVJvIrcwnThkRKMxg(exception)
   return GEjpyPFHdlabiAVJvIrcwnThkRKMxQ
  GEjpyPFHdlabiAVJvIrcwnThkRKMBX.Save_session_acount(userid,userpw,GEjpyPFHdlabiAVJvIrcwnThkRKMqQ)
  return GEjpyPFHdlabiAVJvIrcwnThkRKMxN
 def Get_CP_profile(GEjpyPFHdlabiAVJvIrcwnThkRKMBX,GEjpyPFHdlabiAVJvIrcwnThkRKMqQ,limit_days=1,re_check=GEjpyPFHdlabiAVJvIrcwnThkRKMxQ):
  if re_check==GEjpyPFHdlabiAVJvIrcwnThkRKMxN:
   if GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['SESSION']['bm_sv_ex']>GEjpyPFHdlabiAVJvIrcwnThkRKMxL(time.time()):
    GEjpyPFHdlabiAVJvIrcwnThkRKMxg('bm_sv_ex ok')
    return GEjpyPFHdlabiAVJvIrcwnThkRKMxN
  try:
   GEjpyPFHdlabiAVJvIrcwnThkRKMqX=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.API_DOMAIN+'/api/profiles'
   GEjpyPFHdlabiAVJvIrcwnThkRKMBm,GEjpyPFHdlabiAVJvIrcwnThkRKMBS,GEjpyPFHdlabiAVJvIrcwnThkRKMBN=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.Make_authHeader()
   GEjpyPFHdlabiAVJvIrcwnThkRKMqx={'traceparent':GEjpyPFHdlabiAVJvIrcwnThkRKMBm,'tracestate':GEjpyPFHdlabiAVJvIrcwnThkRKMBS,'newrelic':GEjpyPFHdlabiAVJvIrcwnThkRKMBN,'x-app-version':'1.26.1','x-device-id':'','x-device-os-version':GEjpyPFHdlabiAVJvIrcwnThkRKMBX.OS_VERSION,'x-nr-session-id':GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['COOKIES']['session_web_id'],'x-pcid':'',}
   GEjpyPFHdlabiAVJvIrcwnThkRKMqW=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.make_CP_DefaultCookies()
   GEjpyPFHdlabiAVJvIrcwnThkRKMqz=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.callRequestCookies('Get',GEjpyPFHdlabiAVJvIrcwnThkRKMqX,payload=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,params=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,headers=GEjpyPFHdlabiAVJvIrcwnThkRKMqx,cookies=GEjpyPFHdlabiAVJvIrcwnThkRKMqW,redirects=GEjpyPFHdlabiAVJvIrcwnThkRKMxN)
   if GEjpyPFHdlabiAVJvIrcwnThkRKMqz.status_code not in[200]:return GEjpyPFHdlabiAVJvIrcwnThkRKMxQ
   GEjpyPFHdlabiAVJvIrcwnThkRKMqu=json.loads(GEjpyPFHdlabiAVJvIrcwnThkRKMqz.text)
   GEjpyPFHdlabiAVJvIrcwnThkRKMqt=0
   for GEjpyPFHdlabiAVJvIrcwnThkRKMqo in GEjpyPFHdlabiAVJvIrcwnThkRKMqz.cookies:
    GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['COOKIES'][GEjpyPFHdlabiAVJvIrcwnThkRKMqo.name]=GEjpyPFHdlabiAVJvIrcwnThkRKMqo.value
    if GEjpyPFHdlabiAVJvIrcwnThkRKMqo.name=='bm_sv':
     GEjpyPFHdlabiAVJvIrcwnThkRKMqt=1
     GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['SESSION']['bm_sv_ex']=GEjpyPFHdlabiAVJvIrcwnThkRKMqo.expires 
   if GEjpyPFHdlabiAVJvIrcwnThkRKMqt==0:
    GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['SESSION']['bm_sv_ex']=GEjpyPFHdlabiAVJvIrcwnThkRKMxL(time.time())+60*60*2 
   GEjpyPFHdlabiAVJvIrcwnThkRKMqQ=GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('data')[GEjpyPFHdlabiAVJvIrcwnThkRKMxL(GEjpyPFHdlabiAVJvIrcwnThkRKMqQ)]
   GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['SESSION']['accountId']=GEjpyPFHdlabiAVJvIrcwnThkRKMqQ.get('accountId')
   GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['SESSION']['profileId']=GEjpyPFHdlabiAVJvIrcwnThkRKMqQ.get('profileId')
  except GEjpyPFHdlabiAVJvIrcwnThkRKMxm as exception:
   GEjpyPFHdlabiAVJvIrcwnThkRKMxg(exception)
   return GEjpyPFHdlabiAVJvIrcwnThkRKMxQ
  if re_check==GEjpyPFHdlabiAVJvIrcwnThkRKMxQ:
   GEjpyPFHdlabiAVJvIrcwnThkRKMqg =GEjpyPFHdlabiAVJvIrcwnThkRKMBX.Get_Now_Datetime()
   GEjpyPFHdlabiAVJvIrcwnThkRKMqO=GEjpyPFHdlabiAVJvIrcwnThkRKMqg+datetime.timedelta(days=limit_days)
   GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['SESSION']['limitdate']=GEjpyPFHdlabiAVJvIrcwnThkRKMqO.strftime('%Y-%m-%d')
  else:
   GEjpyPFHdlabiAVJvIrcwnThkRKMxg('re check')
  GEjpyPFHdlabiAVJvIrcwnThkRKMBX.dic_To_jsonfile(GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP_COOKIE_FILENAME,GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP)
  return GEjpyPFHdlabiAVJvIrcwnThkRKMxN
 def Get_Category_GroupList(GEjpyPFHdlabiAVJvIrcwnThkRKMBX,vType):
  GEjpyPFHdlabiAVJvIrcwnThkRKMqf=[] 
  try:
   GEjpyPFHdlabiAVJvIrcwnThkRKMqX=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.API_VIEWURL+'/v2/discover/feed' 
   GEjpyPFHdlabiAVJvIrcwnThkRKMqL={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false',}
   GEjpyPFHdlabiAVJvIrcwnThkRKMqz=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.callRequestCookies('Get',GEjpyPFHdlabiAVJvIrcwnThkRKMqX,payload=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,params=GEjpyPFHdlabiAVJvIrcwnThkRKMqL,headers=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,cookies=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,redirects=GEjpyPFHdlabiAVJvIrcwnThkRKMxN)
   if GEjpyPFHdlabiAVJvIrcwnThkRKMqz.status_code not in[200]:return[]
   GEjpyPFHdlabiAVJvIrcwnThkRKMqu=json.loads(GEjpyPFHdlabiAVJvIrcwnThkRKMqz.text)
   if vType in['TVSHOWS','MOVIES']:
    GEjpyPFHdlabiAVJvIrcwnThkRKMqm='Explores' 
   elif vType in['EDUCATION']:
    GEjpyPFHdlabiAVJvIrcwnThkRKMqm='Collection-Rails-Curation'
   elif vType in['ALL','KIDS']:
    GEjpyPFHdlabiAVJvIrcwnThkRKMqm='Explores-Categories'
   for GEjpyPFHdlabiAVJvIrcwnThkRKMqS in GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('data'):
    if GEjpyPFHdlabiAVJvIrcwnThkRKMqS.get('type')==GEjpyPFHdlabiAVJvIrcwnThkRKMqm:
     for GEjpyPFHdlabiAVJvIrcwnThkRKMqN in GEjpyPFHdlabiAVJvIrcwnThkRKMqS.get('data'):
      if vType in['TVSHOWS','MOVIES']:
       GEjpyPFHdlabiAVJvIrcwnThkRKMqY=GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('collectionId')
      elif vType in['EDUCATION','ALL','KIDS']:
       GEjpyPFHdlabiAVJvIrcwnThkRKMqY=GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('id')
      GEjpyPFHdlabiAVJvIrcwnThkRKMqU={'collectionId':GEjpyPFHdlabiAVJvIrcwnThkRKMqY,'title':GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('name'),'category':GEjpyPFHdlabiAVJvIrcwnThkRKMqS.get('category'),'pre_title':'',}
      GEjpyPFHdlabiAVJvIrcwnThkRKMqf.append(GEjpyPFHdlabiAVJvIrcwnThkRKMqU)
     break
  except GEjpyPFHdlabiAVJvIrcwnThkRKMxm as exception:
   GEjpyPFHdlabiAVJvIrcwnThkRKMxg(exception)
   return[]
  return GEjpyPFHdlabiAVJvIrcwnThkRKMqf
 def Get_Category_List(GEjpyPFHdlabiAVJvIrcwnThkRKMBX,vType,GEjpyPFHdlabiAVJvIrcwnThkRKMqY,page_int):
  GEjpyPFHdlabiAVJvIrcwnThkRKMqf=[] 
  GEjpyPFHdlabiAVJvIrcwnThkRKMXB=GEjpyPFHdlabiAVJvIrcwnThkRKMxQ
  try:
   if vType in['ALL','KIDS']:
    GEjpyPFHdlabiAVJvIrcwnThkRKMqx={'x-membersrl':GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['COOKIES']['member_srl'],'x-pcid':GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['COOKIES']['PCID'],'x-profileid':GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['SESSION']['profileId'],}
    GEjpyPFHdlabiAVJvIrcwnThkRKMqL={'platform':'WEBCLIENT','page':GEjpyPFHdlabiAVJvIrcwnThkRKMxO(page_int),'perPage':GEjpyPFHdlabiAVJvIrcwnThkRKMxO(GEjpyPFHdlabiAVJvIrcwnThkRKMBX.PAGE_LIMIT),'locale':'ko','sort':'',}
    GEjpyPFHdlabiAVJvIrcwnThkRKMqX=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.API_VIEWURL+'/v1/discover/categories/'+GEjpyPFHdlabiAVJvIrcwnThkRKMqY+'/titles'
    GEjpyPFHdlabiAVJvIrcwnThkRKMqz=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.callRequestCookies('Get',GEjpyPFHdlabiAVJvIrcwnThkRKMqX,payload=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,params=GEjpyPFHdlabiAVJvIrcwnThkRKMqL,headers=GEjpyPFHdlabiAVJvIrcwnThkRKMqx,cookies=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,redirects=GEjpyPFHdlabiAVJvIrcwnThkRKMxN)
   else: 
    GEjpyPFHdlabiAVJvIrcwnThkRKMqL={'platform':'WEBCLIENT','page':GEjpyPFHdlabiAVJvIrcwnThkRKMxO(page_int),'perPage':GEjpyPFHdlabiAVJvIrcwnThkRKMxO(GEjpyPFHdlabiAVJvIrcwnThkRKMBX.PAGE_LIMIT),}
    GEjpyPFHdlabiAVJvIrcwnThkRKMqX=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.API_VIEWURL+'/v1/discover/collections/'+GEjpyPFHdlabiAVJvIrcwnThkRKMqY+'/titles'
    GEjpyPFHdlabiAVJvIrcwnThkRKMqz=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.callRequestCookies('Get',GEjpyPFHdlabiAVJvIrcwnThkRKMqX,payload=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,params=GEjpyPFHdlabiAVJvIrcwnThkRKMqL,headers=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,cookies=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,redirects=GEjpyPFHdlabiAVJvIrcwnThkRKMxN)
   if GEjpyPFHdlabiAVJvIrcwnThkRKMqz.status_code not in[200]:return[],GEjpyPFHdlabiAVJvIrcwnThkRKMxQ
   GEjpyPFHdlabiAVJvIrcwnThkRKMqu=json.loads(GEjpyPFHdlabiAVJvIrcwnThkRKMqz.text)
   if vType in['ALL','KIDS']:
    GEjpyPFHdlabiAVJvIrcwnThkRKMXq=GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('data').get('data')
   else:
    GEjpyPFHdlabiAVJvIrcwnThkRKMXq=GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('data')
   for GEjpyPFHdlabiAVJvIrcwnThkRKMqN in GEjpyPFHdlabiAVJvIrcwnThkRKMXq:
    GEjpyPFHdlabiAVJvIrcwnThkRKMXx=GEjpyPFHdlabiAVJvIrcwnThkRKMXD=GEjpyPFHdlabiAVJvIrcwnThkRKMxe=GEjpyPFHdlabiAVJvIrcwnThkRKMxo=''
    if 'poster' in GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('images'):GEjpyPFHdlabiAVJvIrcwnThkRKMXx =GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('images'):GEjpyPFHdlabiAVJvIrcwnThkRKMXD =GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('images').get('story-art').get('url') +'?imwidth=600'
    if 'title-treatment' in GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('images'):GEjpyPFHdlabiAVJvIrcwnThkRKMxe=GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('images').get('title-treatment').get('url')+'?imwidth=300'
    if 'story-art' in GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('images'):GEjpyPFHdlabiAVJvIrcwnThkRKMxo =GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('images').get('story-art').get('url') +'?imwidth=600'
    GEjpyPFHdlabiAVJvIrcwnThkRKMXW=''
    if GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('badge')not in[{},GEjpyPFHdlabiAVJvIrcwnThkRKMxt]:
     for i in GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('badge').get('text'):
      GEjpyPFHdlabiAVJvIrcwnThkRKMXW+=i.get('text')
    GEjpyPFHdlabiAVJvIrcwnThkRKMXz=''
    if GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('seasonList')!=GEjpyPFHdlabiAVJvIrcwnThkRKMxt:
     GEjpyPFHdlabiAVJvIrcwnThkRKMXz=','.join(GEjpyPFHdlabiAVJvIrcwnThkRKMxO(e)for e in GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('seasonList'))
    GEjpyPFHdlabiAVJvIrcwnThkRKMXo =[]
    for GEjpyPFHdlabiAVJvIrcwnThkRKMXe in GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('tags'):
     GEjpyPFHdlabiAVJvIrcwnThkRKMXo.append(GEjpyPFHdlabiAVJvIrcwnThkRKMXe.get('tag'))
    GEjpyPFHdlabiAVJvIrcwnThkRKMqU={'id':GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('id'),'title':GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('title'),'thumbnail':{'poster':GEjpyPFHdlabiAVJvIrcwnThkRKMXx,'thumb':GEjpyPFHdlabiAVJvIrcwnThkRKMXD,'clearlogo':GEjpyPFHdlabiAVJvIrcwnThkRKMxe,'fanart':GEjpyPFHdlabiAVJvIrcwnThkRKMxo},'mpaa':GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('age_rating'),'duration':GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('running_time'),'asis':GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('as'),'badge':GEjpyPFHdlabiAVJvIrcwnThkRKMXW,'year':GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('meta').get('releaseYear'),'seasonList':GEjpyPFHdlabiAVJvIrcwnThkRKMXz,'genreList':GEjpyPFHdlabiAVJvIrcwnThkRKMXo,}
    GEjpyPFHdlabiAVJvIrcwnThkRKMqf.append(GEjpyPFHdlabiAVJvIrcwnThkRKMqU)
   if GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('pagination').get('totalPages')>page_int:
    GEjpyPFHdlabiAVJvIrcwnThkRKMXB=GEjpyPFHdlabiAVJvIrcwnThkRKMxN
  except GEjpyPFHdlabiAVJvIrcwnThkRKMxm as exception:
   GEjpyPFHdlabiAVJvIrcwnThkRKMxg(exception)
   return[],GEjpyPFHdlabiAVJvIrcwnThkRKMxQ
  return GEjpyPFHdlabiAVJvIrcwnThkRKMqf,GEjpyPFHdlabiAVJvIrcwnThkRKMXB
 def Get_Episode_List(GEjpyPFHdlabiAVJvIrcwnThkRKMBX,programId,season):
  GEjpyPFHdlabiAVJvIrcwnThkRKMqf=[] 
  try:
   GEjpyPFHdlabiAVJvIrcwnThkRKMqX=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.API_VIEWURL+'/v1/discover/titles/'+programId+'/episodes'
   GEjpyPFHdlabiAVJvIrcwnThkRKMqL={'season':season,'sort':'true','locale':'ko',}
   GEjpyPFHdlabiAVJvIrcwnThkRKMqz=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.callRequestCookies('Get',GEjpyPFHdlabiAVJvIrcwnThkRKMqX,payload=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,params=GEjpyPFHdlabiAVJvIrcwnThkRKMqL,headers=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,cookies=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,redirects=GEjpyPFHdlabiAVJvIrcwnThkRKMxN)
   if GEjpyPFHdlabiAVJvIrcwnThkRKMqz.status_code not in[200]:return[]
   GEjpyPFHdlabiAVJvIrcwnThkRKMqu=json.loads(GEjpyPFHdlabiAVJvIrcwnThkRKMqz.text)
   for GEjpyPFHdlabiAVJvIrcwnThkRKMqN in GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('data'):
    GEjpyPFHdlabiAVJvIrcwnThkRKMXD=''
    if 'story-art' in GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('images'):GEjpyPFHdlabiAVJvIrcwnThkRKMXD =GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('images').get('story-art').get('url')+'?imwidth=600'
    GEjpyPFHdlabiAVJvIrcwnThkRKMXo =[]
    for GEjpyPFHdlabiAVJvIrcwnThkRKMXe in GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('tags'):
     GEjpyPFHdlabiAVJvIrcwnThkRKMXo.append(GEjpyPFHdlabiAVJvIrcwnThkRKMXe.get('tag'))
    GEjpyPFHdlabiAVJvIrcwnThkRKMqU={'id':GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('id'),'title':GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('title'),'thumbnail':{'thumb':GEjpyPFHdlabiAVJvIrcwnThkRKMXD,'fanart':GEjpyPFHdlabiAVJvIrcwnThkRKMXD},'mpaa':GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('age_rating'),'duration':GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('running_time'),'asis':GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('as'),'year':GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('meta').get('releaseYear'),'episode':GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('episode'),'genreList':GEjpyPFHdlabiAVJvIrcwnThkRKMXo,'desc':GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('description'),}
    GEjpyPFHdlabiAVJvIrcwnThkRKMqf.append(GEjpyPFHdlabiAVJvIrcwnThkRKMqU)
  except GEjpyPFHdlabiAVJvIrcwnThkRKMxm as exception:
   GEjpyPFHdlabiAVJvIrcwnThkRKMxg(exception)
   return[]
  return GEjpyPFHdlabiAVJvIrcwnThkRKMqf
 def Get_vInfo(GEjpyPFHdlabiAVJvIrcwnThkRKMBX,titleId):
  try:
   GEjpyPFHdlabiAVJvIrcwnThkRKMqX=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.API_VIEWURL+'/v1/discover/titles/'+titleId 
   GEjpyPFHdlabiAVJvIrcwnThkRKMqL={'platform':'WEBCLIENT','locale':'ko','filterRestrictedContent':'false',}
   GEjpyPFHdlabiAVJvIrcwnThkRKMqz=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.callRequestCookies('Get',GEjpyPFHdlabiAVJvIrcwnThkRKMqX,payload=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,params=GEjpyPFHdlabiAVJvIrcwnThkRKMqL,headers=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,cookies=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,redirects=GEjpyPFHdlabiAVJvIrcwnThkRKMxN)
   if GEjpyPFHdlabiAVJvIrcwnThkRKMqz.status_code not in[200]:return '','',''
   GEjpyPFHdlabiAVJvIrcwnThkRKMqu=json.loads(GEjpyPFHdlabiAVJvIrcwnThkRKMqz.text).get('data')
   GEjpyPFHdlabiAVJvIrcwnThkRKMXz=''
   if GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('seasonList')!=GEjpyPFHdlabiAVJvIrcwnThkRKMxt:
    GEjpyPFHdlabiAVJvIrcwnThkRKMXz=','.join(GEjpyPFHdlabiAVJvIrcwnThkRKMxO(e)for e in GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('seasonList'))
   GEjpyPFHdlabiAVJvIrcwnThkRKMXC={'age_rating':GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('age_rating'),'asset_id':GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('asset_id'),'availability':GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('availability'),'deal_id':GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('deal_id'),'downloadable':'true' if GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('downloadable')else 'false','region':GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('region'),'streamable':'true' if GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('streamable')else 'false','asis':GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('as'),'seasonList':GEjpyPFHdlabiAVJvIrcwnThkRKMXz}
  except GEjpyPFHdlabiAVJvIrcwnThkRKMxm as exception:
   GEjpyPFHdlabiAVJvIrcwnThkRKMxg(exception)
   return{}
  return GEjpyPFHdlabiAVJvIrcwnThkRKMXC
 def Get_eInfo(GEjpyPFHdlabiAVJvIrcwnThkRKMBX,eventId):
  try:
   GEjpyPFHdlabiAVJvIrcwnThkRKMqX=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.API_VIEWURL+'/v1/discover/events/'+eventId 
   GEjpyPFHdlabiAVJvIrcwnThkRKMqL={'locale':'ko'}
   GEjpyPFHdlabiAVJvIrcwnThkRKMqz=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.callRequestCookies('Get',GEjpyPFHdlabiAVJvIrcwnThkRKMqX,payload=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,params=GEjpyPFHdlabiAVJvIrcwnThkRKMqL,headers=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,cookies=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,redirects=GEjpyPFHdlabiAVJvIrcwnThkRKMxN)
   if GEjpyPFHdlabiAVJvIrcwnThkRKMqz.status_code not in[200]:return '','',''
   GEjpyPFHdlabiAVJvIrcwnThkRKMqu=json.loads(GEjpyPFHdlabiAVJvIrcwnThkRKMqz.text).get('data')
   GEjpyPFHdlabiAVJvIrcwnThkRKMXC={'asset_id':GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('asset_id'),'deal_id':GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('deal_id'),'region':GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('region'),'streamable':'true' if GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('streamable')else 'false',}
  except GEjpyPFHdlabiAVJvIrcwnThkRKMxm as exception:
   GEjpyPFHdlabiAVJvIrcwnThkRKMxg(exception)
   return{}
  return GEjpyPFHdlabiAVJvIrcwnThkRKMXC
 def GetBroadURL(GEjpyPFHdlabiAVJvIrcwnThkRKMBX,titleId):
  GEjpyPFHdlabiAVJvIrcwnThkRKMXs=''
  GEjpyPFHdlabiAVJvIrcwnThkRKMXu =''
  GEjpyPFHdlabiAVJvIrcwnThkRKMXC=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.Get_vInfo(titleId)
  if GEjpyPFHdlabiAVJvIrcwnThkRKMXC=={}:return '',''
  try:
   GEjpyPFHdlabiAVJvIrcwnThkRKMqX=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.API_DOMAIN+'/api/playback/play' 
   GEjpyPFHdlabiAVJvIrcwnThkRKMqL={'titleId':titleId}
   GEjpyPFHdlabiAVJvIrcwnThkRKMBm,GEjpyPFHdlabiAVJvIrcwnThkRKMBS,GEjpyPFHdlabiAVJvIrcwnThkRKMBN=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.Make_authHeader()
   GEjpyPFHdlabiAVJvIrcwnThkRKMqx={'traceparent':GEjpyPFHdlabiAVJvIrcwnThkRKMBm,'tracestate':GEjpyPFHdlabiAVJvIrcwnThkRKMBS,'newrelic':GEjpyPFHdlabiAVJvIrcwnThkRKMBN,'x-drm':'com.microsoft.playready','x-app-version':'1.33.5','x-device-id':'','x-device-os-version':GEjpyPFHdlabiAVJvIrcwnThkRKMBX.OS_VERSION,'x-force-raw':'true','x-nr-session-id':GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['COOKIES']['session_web_id'],'x-pcid':GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['COOKIES']['PCID'],'x-platform':'web','x-profileId':GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['SESSION']['profileId'],'x-profileType':'standard','x-sessionid':GEjpyPFHdlabiAVJvIrcwnThkRKMBX.generatePvId(genType='1'),'x-title-age-rating':GEjpyPFHdlabiAVJvIrcwnThkRKMXC.get('age_rating'),'x-title-availability':GEjpyPFHdlabiAVJvIrcwnThkRKMXC.get('availability'),'x-title-brightcove-id':GEjpyPFHdlabiAVJvIrcwnThkRKMXC.get('asset_id'),'x-title-deal-id':GEjpyPFHdlabiAVJvIrcwnThkRKMXC.get('deal_id'),'x-title-downloadable':GEjpyPFHdlabiAVJvIrcwnThkRKMXC.get('downloadable'),'x-title-region':GEjpyPFHdlabiAVJvIrcwnThkRKMXC.get('region'),'x-title-streamable':GEjpyPFHdlabiAVJvIrcwnThkRKMXC.get('streamable'),}
   GEjpyPFHdlabiAVJvIrcwnThkRKMqW=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.make_CP_DefaultCookies()
   GEjpyPFHdlabiAVJvIrcwnThkRKMqz=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.callRequestCookies('Get',GEjpyPFHdlabiAVJvIrcwnThkRKMqX,payload=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,params=GEjpyPFHdlabiAVJvIrcwnThkRKMqL,headers=GEjpyPFHdlabiAVJvIrcwnThkRKMqx,cookies=GEjpyPFHdlabiAVJvIrcwnThkRKMqW,redirects=GEjpyPFHdlabiAVJvIrcwnThkRKMxN)
   if GEjpyPFHdlabiAVJvIrcwnThkRKMqz.status_code not in[200]:return '',json.loads(GEjpyPFHdlabiAVJvIrcwnThkRKMqz.text).get('error').get('detail')
   GEjpyPFHdlabiAVJvIrcwnThkRKMqu=json.loads(GEjpyPFHdlabiAVJvIrcwnThkRKMqz.text)
   if GEjpyPFHdlabiAVJvIrcwnThkRKMXs=='':
    for GEjpyPFHdlabiAVJvIrcwnThkRKMqN in GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('data').get('raw').get('sources'):
     if 'key_systems' in GEjpyPFHdlabiAVJvIrcwnThkRKMqN and 'codecs' not in GEjpyPFHdlabiAVJvIrcwnThkRKMqN:
      if GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('type')=='application/dash+xml' and 'com.widevine.alpha' in GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('key_systems')and GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('src').startswith('https://')==GEjpyPFHdlabiAVJvIrcwnThkRKMxN:
       GEjpyPFHdlabiAVJvIrcwnThkRKMXs=GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('src')
       GEjpyPFHdlabiAVJvIrcwnThkRKMXu =GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if GEjpyPFHdlabiAVJvIrcwnThkRKMXs=='':
    for GEjpyPFHdlabiAVJvIrcwnThkRKMqN in GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('data').get('raw').get('sources'):
     if 'key_systems' in GEjpyPFHdlabiAVJvIrcwnThkRKMqN and 'codecs' not in GEjpyPFHdlabiAVJvIrcwnThkRKMqN:
      if GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('key_systems')and GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('src').startswith('https://')==GEjpyPFHdlabiAVJvIrcwnThkRKMxN:
       GEjpyPFHdlabiAVJvIrcwnThkRKMXs=GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('src')
       GEjpyPFHdlabiAVJvIrcwnThkRKMXu =GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if GEjpyPFHdlabiAVJvIrcwnThkRKMXs=='':
    for GEjpyPFHdlabiAVJvIrcwnThkRKMqN in GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('data').get('raw').get('sources'):
     if 'key_systems' in GEjpyPFHdlabiAVJvIrcwnThkRKMqN and 'codecs' in GEjpyPFHdlabiAVJvIrcwnThkRKMqN:
      if GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('type')=='application/dash+xml' and 'com.widevine.alpha' in GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('key_systems')and GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('src').startswith('https://')==GEjpyPFHdlabiAVJvIrcwnThkRKMxN:
       GEjpyPFHdlabiAVJvIrcwnThkRKMXs=GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('src')
       GEjpyPFHdlabiAVJvIrcwnThkRKMXu =GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if GEjpyPFHdlabiAVJvIrcwnThkRKMXs=='':
    for GEjpyPFHdlabiAVJvIrcwnThkRKMqN in GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('data').get('raw').get('sources'):
     if 'key_systems' in GEjpyPFHdlabiAVJvIrcwnThkRKMqN and 'codecs' in GEjpyPFHdlabiAVJvIrcwnThkRKMqN:
      if GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('key_systems')and GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('src').startswith('https://')==GEjpyPFHdlabiAVJvIrcwnThkRKMxN:
       GEjpyPFHdlabiAVJvIrcwnThkRKMXs=GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('src')
       GEjpyPFHdlabiAVJvIrcwnThkRKMXu =GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
  except GEjpyPFHdlabiAVJvIrcwnThkRKMxm as exception:
   GEjpyPFHdlabiAVJvIrcwnThkRKMxg(exception)
   return '',''
  return GEjpyPFHdlabiAVJvIrcwnThkRKMXs,GEjpyPFHdlabiAVJvIrcwnThkRKMXu
 def GetEventURL(GEjpyPFHdlabiAVJvIrcwnThkRKMBX,eventId,GEjpyPFHdlabiAVJvIrcwnThkRKMxB):
  GEjpyPFHdlabiAVJvIrcwnThkRKMXs=''
  GEjpyPFHdlabiAVJvIrcwnThkRKMXu =''
  GEjpyPFHdlabiAVJvIrcwnThkRKMXC=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.Get_eInfo(eventId)
  if GEjpyPFHdlabiAVJvIrcwnThkRKMXC=={}:return '',''
  try:
   GEjpyPFHdlabiAVJvIrcwnThkRKMqX=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.API_DOMAIN+'/api/playback/play' 
   GEjpyPFHdlabiAVJvIrcwnThkRKMqL={'titleId':eventId,'titleType':GEjpyPFHdlabiAVJvIrcwnThkRKMxB,}
   GEjpyPFHdlabiAVJvIrcwnThkRKMBm,GEjpyPFHdlabiAVJvIrcwnThkRKMBS,GEjpyPFHdlabiAVJvIrcwnThkRKMBN=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.Make_authHeader()
   GEjpyPFHdlabiAVJvIrcwnThkRKMqx={'traceparent':GEjpyPFHdlabiAVJvIrcwnThkRKMBm,'tracestate':GEjpyPFHdlabiAVJvIrcwnThkRKMBS,'newrelic':GEjpyPFHdlabiAVJvIrcwnThkRKMBN,'x-force-raw':'true','x-pcid':GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['COOKIES']['PCID'],'x-platform':'web','x-profileId':GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':GEjpyPFHdlabiAVJvIrcwnThkRKMXC.get('asset_id'),'x-title-deal-id':GEjpyPFHdlabiAVJvIrcwnThkRKMXC.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':GEjpyPFHdlabiAVJvIrcwnThkRKMXC.get('region'),'x-title-streamable':GEjpyPFHdlabiAVJvIrcwnThkRKMXC.get('streamable'),}
   GEjpyPFHdlabiAVJvIrcwnThkRKMqW=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.make_CP_DefaultCookies()
   GEjpyPFHdlabiAVJvIrcwnThkRKMqz=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.callRequestCookies('Get',GEjpyPFHdlabiAVJvIrcwnThkRKMqX,payload=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,params=GEjpyPFHdlabiAVJvIrcwnThkRKMqL,headers=GEjpyPFHdlabiAVJvIrcwnThkRKMqx,cookies=GEjpyPFHdlabiAVJvIrcwnThkRKMqW,redirects=GEjpyPFHdlabiAVJvIrcwnThkRKMxN)
   if GEjpyPFHdlabiAVJvIrcwnThkRKMqz.status_code not in[200]:return '',json.loads(GEjpyPFHdlabiAVJvIrcwnThkRKMqz.text).get('error').get('detail')
   GEjpyPFHdlabiAVJvIrcwnThkRKMqu=json.loads(GEjpyPFHdlabiAVJvIrcwnThkRKMqz.text)
   for GEjpyPFHdlabiAVJvIrcwnThkRKMqN in GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('data').get('raw').get('sources'):
    if GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('type')=='application/dash+xml' and GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('src')[0:8]=='https://':
     GEjpyPFHdlabiAVJvIrcwnThkRKMXs=GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('src')
     if 'key_systems' in GEjpyPFHdlabiAVJvIrcwnThkRKMqN:
      GEjpyPFHdlabiAVJvIrcwnThkRKMXu =GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('key_systems').get('com.widevine.alpha').get('license_url')
     break
  except GEjpyPFHdlabiAVJvIrcwnThkRKMxm as exception:
   GEjpyPFHdlabiAVJvIrcwnThkRKMxg(exception)
   return '',''
  return GEjpyPFHdlabiAVJvIrcwnThkRKMXs,GEjpyPFHdlabiAVJvIrcwnThkRKMXu
 def GetEventURL_Live(GEjpyPFHdlabiAVJvIrcwnThkRKMBX,eventId,GEjpyPFHdlabiAVJvIrcwnThkRKMxB):
  GEjpyPFHdlabiAVJvIrcwnThkRKMXs=''
  GEjpyPFHdlabiAVJvIrcwnThkRKMXu =''
  GEjpyPFHdlabiAVJvIrcwnThkRKMXC=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.Get_eInfo(eventId)
  if GEjpyPFHdlabiAVJvIrcwnThkRKMXC=={}:return '',''
  try:
   GEjpyPFHdlabiAVJvIrcwnThkRKMqX=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.API_DOMAIN+'/api/playback/play' 
   GEjpyPFHdlabiAVJvIrcwnThkRKMqL={'titleId':eventId,'titleType':GEjpyPFHdlabiAVJvIrcwnThkRKMxB,}
   GEjpyPFHdlabiAVJvIrcwnThkRKMBm,GEjpyPFHdlabiAVJvIrcwnThkRKMBS,GEjpyPFHdlabiAVJvIrcwnThkRKMBN=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.Make_authHeader()
   GEjpyPFHdlabiAVJvIrcwnThkRKMqx={'traceparent':GEjpyPFHdlabiAVJvIrcwnThkRKMBm,'tracestate':GEjpyPFHdlabiAVJvIrcwnThkRKMBS,'newrelic':GEjpyPFHdlabiAVJvIrcwnThkRKMBN,'x-force-raw':'true','x-pcid':GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['COOKIES']['PCID'],'x-platform':'web','x-profileId':GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':GEjpyPFHdlabiAVJvIrcwnThkRKMXC.get('asset_id'),'x-title-deal-id':GEjpyPFHdlabiAVJvIrcwnThkRKMXC.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':GEjpyPFHdlabiAVJvIrcwnThkRKMXC.get('region'),'x-title-streamable':GEjpyPFHdlabiAVJvIrcwnThkRKMXC.get('streamable'),}
   GEjpyPFHdlabiAVJvIrcwnThkRKMqW=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.make_CP_DefaultCookies()
   GEjpyPFHdlabiAVJvIrcwnThkRKMqz=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.callRequestCookies('Get',GEjpyPFHdlabiAVJvIrcwnThkRKMqX,payload=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,params=GEjpyPFHdlabiAVJvIrcwnThkRKMqL,headers=GEjpyPFHdlabiAVJvIrcwnThkRKMqx,cookies=GEjpyPFHdlabiAVJvIrcwnThkRKMqW,redirects=GEjpyPFHdlabiAVJvIrcwnThkRKMxN)
   if GEjpyPFHdlabiAVJvIrcwnThkRKMqz.status_code not in[200]:return '',json.loads(GEjpyPFHdlabiAVJvIrcwnThkRKMqz.text).get('error').get('detail')
   GEjpyPFHdlabiAVJvIrcwnThkRKMqu=json.loads(GEjpyPFHdlabiAVJvIrcwnThkRKMqz.text)
   if GEjpyPFHdlabiAVJvIrcwnThkRKMXs=='':
    for GEjpyPFHdlabiAVJvIrcwnThkRKMqN in GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('data').get('raw').get('sources'):
     if 'key_systems' in GEjpyPFHdlabiAVJvIrcwnThkRKMqN:
      if GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('type')=='application/dash+xml' and 'com.widevine.alpha' in GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('key_systems')and GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('src').startswith('https://')==GEjpyPFHdlabiAVJvIrcwnThkRKMxN:
       GEjpyPFHdlabiAVJvIrcwnThkRKMXs=GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('src')
       GEjpyPFHdlabiAVJvIrcwnThkRKMXu =GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('key_systems').get('com.widevine.alpha').get('license_url')
   if GEjpyPFHdlabiAVJvIrcwnThkRKMXs=='':
    for GEjpyPFHdlabiAVJvIrcwnThkRKMqN in GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('data').get('raw').get('sources'):
     if 'key_systems' in GEjpyPFHdlabiAVJvIrcwnThkRKMqN:
      if GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('key_systems')and GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('src').startswith('https://')==GEjpyPFHdlabiAVJvIrcwnThkRKMxN:
       GEjpyPFHdlabiAVJvIrcwnThkRKMXs=GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('src')
       GEjpyPFHdlabiAVJvIrcwnThkRKMXu =GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('key_systems').get('com.widevine.alpha').get('license_url')
   if GEjpyPFHdlabiAVJvIrcwnThkRKMXs=='':
    for GEjpyPFHdlabiAVJvIrcwnThkRKMqN in GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('data').get('raw').get('sources'):
     if GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('type')=='application/dash+xml' and GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('src').startswith('https://')==GEjpyPFHdlabiAVJvIrcwnThkRKMxN:
      GEjpyPFHdlabiAVJvIrcwnThkRKMXs=GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('src')
   if GEjpyPFHdlabiAVJvIrcwnThkRKMXs=='':
    for GEjpyPFHdlabiAVJvIrcwnThkRKMqN in GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('data').get('raw').get('sources'):
     if GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('type')=='application/x-mpegURL' and GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('src').startswith('https://')==GEjpyPFHdlabiAVJvIrcwnThkRKMxN:
      GEjpyPFHdlabiAVJvIrcwnThkRKMXs=GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('src')
  except GEjpyPFHdlabiAVJvIrcwnThkRKMxm as exception:
   GEjpyPFHdlabiAVJvIrcwnThkRKMxg(exception)
   return '',''
  return GEjpyPFHdlabiAVJvIrcwnThkRKMXs,GEjpyPFHdlabiAVJvIrcwnThkRKMXu
 def Get_Url_PostFix(GEjpyPFHdlabiAVJvIrcwnThkRKMBX,in_url):
  GEjpyPFHdlabiAVJvIrcwnThkRKMXt=urllib.parse.urlparse(in_url) 
  GEjpyPFHdlabiAVJvIrcwnThkRKMXQ =GEjpyPFHdlabiAVJvIrcwnThkRKMXt.path.strip('/').split('/')
  GEjpyPFHdlabiAVJvIrcwnThkRKMXg =GEjpyPFHdlabiAVJvIrcwnThkRKMXQ[GEjpyPFHdlabiAVJvIrcwnThkRKMxY(GEjpyPFHdlabiAVJvIrcwnThkRKMXQ)-1]
  GEjpyPFHdlabiAVJvIrcwnThkRKMXO=GEjpyPFHdlabiAVJvIrcwnThkRKMXg.split('.')
  return GEjpyPFHdlabiAVJvIrcwnThkRKMXO[GEjpyPFHdlabiAVJvIrcwnThkRKMxY(GEjpyPFHdlabiAVJvIrcwnThkRKMXO)-1]
 def Get_Theme_GroupList(GEjpyPFHdlabiAVJvIrcwnThkRKMBX,vType):
  GEjpyPFHdlabiAVJvIrcwnThkRKMqf=[] 
  try:
   GEjpyPFHdlabiAVJvIrcwnThkRKMqX=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.API_VIEWURL+'/v2/discover/feed' 
   GEjpyPFHdlabiAVJvIrcwnThkRKMqL={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':GEjpyPFHdlabiAVJvIrcwnThkRKMxO(GEjpyPFHdlabiAVJvIrcwnThkRKMBX.PAGE_LIMIT),'filterRestrictedContent':'false',}
   GEjpyPFHdlabiAVJvIrcwnThkRKMqz=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.callRequestCookies('Get',GEjpyPFHdlabiAVJvIrcwnThkRKMqX,payload=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,params=GEjpyPFHdlabiAVJvIrcwnThkRKMqL,headers=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,cookies=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,redirects=GEjpyPFHdlabiAVJvIrcwnThkRKMxN)
   if GEjpyPFHdlabiAVJvIrcwnThkRKMqz.status_code not in[200]:return[]
   GEjpyPFHdlabiAVJvIrcwnThkRKMqu=json.loads(GEjpyPFHdlabiAVJvIrcwnThkRKMqz.text)
   for GEjpyPFHdlabiAVJvIrcwnThkRKMqN in GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('data'):
    if GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('type')=='Title-Rails-Curation':
     GEjpyPFHdlabiAVJvIrcwnThkRKMXf =''
     GEjpyPFHdlabiAVJvIrcwnThkRKMXL=7
     try:
      for i in GEjpyPFHdlabiAVJvIrcwnThkRKMxU(GEjpyPFHdlabiAVJvIrcwnThkRKMxY(GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('data'))):
       if i>=GEjpyPFHdlabiAVJvIrcwnThkRKMXL:
        GEjpyPFHdlabiAVJvIrcwnThkRKMXf=GEjpyPFHdlabiAVJvIrcwnThkRKMXf+'...'
        break
       GEjpyPFHdlabiAVJvIrcwnThkRKMXf=GEjpyPFHdlabiAVJvIrcwnThkRKMXf+GEjpyPFHdlabiAVJvIrcwnThkRKMqN['data'][i]['title']+'\n'
     except GEjpyPFHdlabiAVJvIrcwnThkRKMxm as exception:
      GEjpyPFHdlabiAVJvIrcwnThkRKMxg(exception)
     GEjpyPFHdlabiAVJvIrcwnThkRKMqU={'collectionId':GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('obj_id'),'title':GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('row_name'),'category':GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('category'),'pre_title':GEjpyPFHdlabiAVJvIrcwnThkRKMXf,}
     GEjpyPFHdlabiAVJvIrcwnThkRKMqf.append(GEjpyPFHdlabiAVJvIrcwnThkRKMqU)
  except GEjpyPFHdlabiAVJvIrcwnThkRKMxm as exception:
   GEjpyPFHdlabiAVJvIrcwnThkRKMxg(exception)
   return[]
  return GEjpyPFHdlabiAVJvIrcwnThkRKMqf
 def Get_Event_GroupList(GEjpyPFHdlabiAVJvIrcwnThkRKMBX):
  GEjpyPFHdlabiAVJvIrcwnThkRKMqf=[] 
  try:
   GEjpyPFHdlabiAVJvIrcwnThkRKMqX=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.API_VIEWURL+'/v2/discover/feed' 
   GEjpyPFHdlabiAVJvIrcwnThkRKMqL={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':7,'filterRestrictedContent':'false',}
   GEjpyPFHdlabiAVJvIrcwnThkRKMqz=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.callRequestCookies('Get',GEjpyPFHdlabiAVJvIrcwnThkRKMqX,payload=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,params=GEjpyPFHdlabiAVJvIrcwnThkRKMqL,headers=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,cookies=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,redirects=GEjpyPFHdlabiAVJvIrcwnThkRKMxN)
   if GEjpyPFHdlabiAVJvIrcwnThkRKMqz.status_code not in[200]:return[]
   GEjpyPFHdlabiAVJvIrcwnThkRKMqu=json.loads(GEjpyPFHdlabiAVJvIrcwnThkRKMqz.text)
   for GEjpyPFHdlabiAVJvIrcwnThkRKMqN in GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('data'):
    if GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('row_name').strip()!='':
     GEjpyPFHdlabiAVJvIrcwnThkRKMXf =''
     GEjpyPFHdlabiAVJvIrcwnThkRKMXL=7
     try:
      for i in GEjpyPFHdlabiAVJvIrcwnThkRKMxU(GEjpyPFHdlabiAVJvIrcwnThkRKMxY(GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('data'))):
       if i>=GEjpyPFHdlabiAVJvIrcwnThkRKMXL:
        GEjpyPFHdlabiAVJvIrcwnThkRKMXf=GEjpyPFHdlabiAVJvIrcwnThkRKMXf+'...'
        break
       GEjpyPFHdlabiAVJvIrcwnThkRKMXf=GEjpyPFHdlabiAVJvIrcwnThkRKMXf+GEjpyPFHdlabiAVJvIrcwnThkRKMqN['data'][i]['title']+'\n'
     except GEjpyPFHdlabiAVJvIrcwnThkRKMxm as exception:
      GEjpyPFHdlabiAVJvIrcwnThkRKMxg(exception)
     GEjpyPFHdlabiAVJvIrcwnThkRKMqU={'collectionId':GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('obj_id'),'title':GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('row_name'),'category':GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('type'),'pre_title':GEjpyPFHdlabiAVJvIrcwnThkRKMXf,}
     GEjpyPFHdlabiAVJvIrcwnThkRKMqf.append(GEjpyPFHdlabiAVJvIrcwnThkRKMqU)
  except GEjpyPFHdlabiAVJvIrcwnThkRKMxm as exception:
   GEjpyPFHdlabiAVJvIrcwnThkRKMxg(exception)
   return[]
  return GEjpyPFHdlabiAVJvIrcwnThkRKMqf
 def Get_Event_GameList(GEjpyPFHdlabiAVJvIrcwnThkRKMBX,GEjpyPFHdlabiAVJvIrcwnThkRKMqY):
  GEjpyPFHdlabiAVJvIrcwnThkRKMqf=[] 
  try:
   GEjpyPFHdlabiAVJvIrcwnThkRKMqX=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.API_VIEWURL+'/v2/discover/feed' 
   GEjpyPFHdlabiAVJvIrcwnThkRKMqL={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false',}
   GEjpyPFHdlabiAVJvIrcwnThkRKMqz=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.callRequestCookies('Get',GEjpyPFHdlabiAVJvIrcwnThkRKMqX,payload=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,params=GEjpyPFHdlabiAVJvIrcwnThkRKMqL,headers=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,cookies=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,redirects=GEjpyPFHdlabiAVJvIrcwnThkRKMxN)
   if GEjpyPFHdlabiAVJvIrcwnThkRKMqz.status_code not in[200]:return[]
   GEjpyPFHdlabiAVJvIrcwnThkRKMqu=json.loads(GEjpyPFHdlabiAVJvIrcwnThkRKMqz.text)
   for GEjpyPFHdlabiAVJvIrcwnThkRKMqN in GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('data'):
    if GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('obj_id')==GEjpyPFHdlabiAVJvIrcwnThkRKMqY:
     for GEjpyPFHdlabiAVJvIrcwnThkRKMXm in GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('data'):
      GEjpyPFHdlabiAVJvIrcwnThkRKMXx=GEjpyPFHdlabiAVJvIrcwnThkRKMXD=GEjpyPFHdlabiAVJvIrcwnThkRKMxo=''
      if 'poster' in GEjpyPFHdlabiAVJvIrcwnThkRKMXm.get('images'):GEjpyPFHdlabiAVJvIrcwnThkRKMXx =GEjpyPFHdlabiAVJvIrcwnThkRKMXm.get('images').get('poster').get('url') +'?imwidth=350'
      if 'story-art' in GEjpyPFHdlabiAVJvIrcwnThkRKMXm.get('images'):GEjpyPFHdlabiAVJvIrcwnThkRKMXD =GEjpyPFHdlabiAVJvIrcwnThkRKMXm.get('images').get('story-art').get('url')+'?imwidth=600'
      if 'hero' in GEjpyPFHdlabiAVJvIrcwnThkRKMXm.get('images'):GEjpyPFHdlabiAVJvIrcwnThkRKMxo =GEjpyPFHdlabiAVJvIrcwnThkRKMXm.get('images').get('hero').get('url') +'?imwidth=600'
      GEjpyPFHdlabiAVJvIrcwnThkRKMXS=GEjpyPFHdlabiAVJvIrcwnThkRKMXm.get('meta').get(GEjpyPFHdlabiAVJvIrcwnThkRKMXm.get('category')).get(GEjpyPFHdlabiAVJvIrcwnThkRKMXm.get('sub_category'))
      if 'league' in GEjpyPFHdlabiAVJvIrcwnThkRKMXS:
       GEjpyPFHdlabiAVJvIrcwnThkRKMXN=GEjpyPFHdlabiAVJvIrcwnThkRKMXS.get('league')
      else:
       GEjpyPFHdlabiAVJvIrcwnThkRKMXN=GEjpyPFHdlabiAVJvIrcwnThkRKMXS.get('round')
      GEjpyPFHdlabiAVJvIrcwnThkRKMqU={'id':GEjpyPFHdlabiAVJvIrcwnThkRKMXm.get('id'),'title':GEjpyPFHdlabiAVJvIrcwnThkRKMXm.get('title'),'thumbnail':{'poster':GEjpyPFHdlabiAVJvIrcwnThkRKMXx,'thumb':GEjpyPFHdlabiAVJvIrcwnThkRKMXD,'fanart':GEjpyPFHdlabiAVJvIrcwnThkRKMxo},'asis':GEjpyPFHdlabiAVJvIrcwnThkRKMXm.get('type'),'addInfo':GEjpyPFHdlabiAVJvIrcwnThkRKMXN,'starttm':GEjpyPFHdlabiAVJvIrcwnThkRKMBX.convert_TimeStr(GEjpyPFHdlabiAVJvIrcwnThkRKMXm.get('start_at')),}
      GEjpyPFHdlabiAVJvIrcwnThkRKMqf.append(GEjpyPFHdlabiAVJvIrcwnThkRKMqU)
  except GEjpyPFHdlabiAVJvIrcwnThkRKMxm as exception:
   GEjpyPFHdlabiAVJvIrcwnThkRKMxg(exception)
   return[]
  return GEjpyPFHdlabiAVJvIrcwnThkRKMqf
 def Get_Event_List(GEjpyPFHdlabiAVJvIrcwnThkRKMBX,gameId):
  GEjpyPFHdlabiAVJvIrcwnThkRKMqf=[] 
  try:
   GEjpyPFHdlabiAVJvIrcwnThkRKMqX=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.API_VIEWURL+'/v1/discover/events/'+gameId 
   GEjpyPFHdlabiAVJvIrcwnThkRKMqL={'platform':'WEBCLIENT','locale':'ko','filterRestrictedContent':'false',}
   GEjpyPFHdlabiAVJvIrcwnThkRKMqz=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.callRequestCookies('Get',GEjpyPFHdlabiAVJvIrcwnThkRKMqX,payload=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,params=GEjpyPFHdlabiAVJvIrcwnThkRKMqL,headers=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,cookies=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,redirects=GEjpyPFHdlabiAVJvIrcwnThkRKMxN)
   if GEjpyPFHdlabiAVJvIrcwnThkRKMqz.status_code not in[200]:return[]
   GEjpyPFHdlabiAVJvIrcwnThkRKMqu=json.loads(GEjpyPFHdlabiAVJvIrcwnThkRKMqz.text)
   GEjpyPFHdlabiAVJvIrcwnThkRKMqN=GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('data')
   GEjpyPFHdlabiAVJvIrcwnThkRKMXY=GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('end_at')
   GEjpyPFHdlabiAVJvIrcwnThkRKMXY=GEjpyPFHdlabiAVJvIrcwnThkRKMXY[0:19].replace('-','').replace(':','').replace('T','')
   GEjpyPFHdlabiAVJvIrcwnThkRKMXU=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d%H%M%S')
   if GEjpyPFHdlabiAVJvIrcwnThkRKMxL(GEjpyPFHdlabiAVJvIrcwnThkRKMXU)<GEjpyPFHdlabiAVJvIrcwnThkRKMxL(GEjpyPFHdlabiAVJvIrcwnThkRKMXY):
    GEjpyPFHdlabiAVJvIrcwnThkRKMXx=GEjpyPFHdlabiAVJvIrcwnThkRKMXD=GEjpyPFHdlabiAVJvIrcwnThkRKMxo=''
    if 'poster' in GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('images'):GEjpyPFHdlabiAVJvIrcwnThkRKMXx =GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('images'):GEjpyPFHdlabiAVJvIrcwnThkRKMXD =GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('images').get('story-art').get('url')+'?imwidth=600'
    if 'story-art' in GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('images'):GEjpyPFHdlabiAVJvIrcwnThkRKMxo =GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('images').get('story-art').get('url')+'?imwidth=600'
    GEjpyPFHdlabiAVJvIrcwnThkRKMqU={'id':GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('id'),'title':GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('title'),'thumbnail':{'poster':GEjpyPFHdlabiAVJvIrcwnThkRKMXx,'thumb':GEjpyPFHdlabiAVJvIrcwnThkRKMXD,'fanart':GEjpyPFHdlabiAVJvIrcwnThkRKMxo},'duration':GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('running_time'),'asis':GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('type'),'starttm':GEjpyPFHdlabiAVJvIrcwnThkRKMBX.convert_TimeStr(GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('start_at')),}
    GEjpyPFHdlabiAVJvIrcwnThkRKMqf.append(GEjpyPFHdlabiAVJvIrcwnThkRKMqU)
  except GEjpyPFHdlabiAVJvIrcwnThkRKMxm as exception:
   GEjpyPFHdlabiAVJvIrcwnThkRKMxg(exception)
   return[]
  try:
   GEjpyPFHdlabiAVJvIrcwnThkRKMqX=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.API_VIEWURL+'/v1/discover/events/'+gameId+'/related' 
   GEjpyPFHdlabiAVJvIrcwnThkRKMqL={'locale':'ko','page':'1','perPage':'25','platform':'WEBCLIENT','currentPageTracking':'page_discover_title_detail',}
   GEjpyPFHdlabiAVJvIrcwnThkRKMqz=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.callRequestCookies('Get',GEjpyPFHdlabiAVJvIrcwnThkRKMqX,payload=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,params=GEjpyPFHdlabiAVJvIrcwnThkRKMqL,headers=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,cookies=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,redirects=GEjpyPFHdlabiAVJvIrcwnThkRKMxN)
   if GEjpyPFHdlabiAVJvIrcwnThkRKMqz.status_code not in[200]:return[]
   GEjpyPFHdlabiAVJvIrcwnThkRKMqu=json.loads(GEjpyPFHdlabiAVJvIrcwnThkRKMqz.text)
   for GEjpyPFHdlabiAVJvIrcwnThkRKMqN in GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('data').get('data'):
    GEjpyPFHdlabiAVJvIrcwnThkRKMXx=GEjpyPFHdlabiAVJvIrcwnThkRKMXD=GEjpyPFHdlabiAVJvIrcwnThkRKMxo=''
    if 'poster' in GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('images'):GEjpyPFHdlabiAVJvIrcwnThkRKMXx =GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('images'):GEjpyPFHdlabiAVJvIrcwnThkRKMXD =GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('images').get('story-art').get('url')+'?imwidth=600'
    if 'story-art' in GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('images'):GEjpyPFHdlabiAVJvIrcwnThkRKMxo =GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('images').get('story-art').get('url')+'?imwidth=600'
    GEjpyPFHdlabiAVJvIrcwnThkRKMqU={'id':GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('id'),'title':GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('title'),'thumbnail':{'poster':GEjpyPFHdlabiAVJvIrcwnThkRKMXx,'thumb':GEjpyPFHdlabiAVJvIrcwnThkRKMXD,'fanart':GEjpyPFHdlabiAVJvIrcwnThkRKMxo},'duration':GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('running_time'),'asis':GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('type'),}
    GEjpyPFHdlabiAVJvIrcwnThkRKMqf.append(GEjpyPFHdlabiAVJvIrcwnThkRKMqU)
  except GEjpyPFHdlabiAVJvIrcwnThkRKMxm as exception:
   GEjpyPFHdlabiAVJvIrcwnThkRKMxg(exception)
   return[]
  return GEjpyPFHdlabiAVJvIrcwnThkRKMqf
 def Get_Search_List(GEjpyPFHdlabiAVJvIrcwnThkRKMBX,search_key,page_int):
  GEjpyPFHdlabiAVJvIrcwnThkRKMqf=[] 
  GEjpyPFHdlabiAVJvIrcwnThkRKMXB=GEjpyPFHdlabiAVJvIrcwnThkRKMxQ
  try:
   GEjpyPFHdlabiAVJvIrcwnThkRKMqX=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.API_VIEWURL+'/v2/search' 
   GEjpyPFHdlabiAVJvIrcwnThkRKMqL={'query':search_key,'platform':'WEBCLIENT','page':GEjpyPFHdlabiAVJvIrcwnThkRKMxO(page_int),'perPage':GEjpyPFHdlabiAVJvIrcwnThkRKMxO(GEjpyPFHdlabiAVJvIrcwnThkRKMBX.SEARCH_LIMIT),}
   GEjpyPFHdlabiAVJvIrcwnThkRKMqx={'x-membersrl':GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['COOKIES']['member_srl'],'x-pcid':GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['COOKIES']['PCID'],'x-profileid':GEjpyPFHdlabiAVJvIrcwnThkRKMBX.CP['SESSION']['profileId'],}
   GEjpyPFHdlabiAVJvIrcwnThkRKMqz=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.callRequestCookies('Get',GEjpyPFHdlabiAVJvIrcwnThkRKMqX,payload=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,params=GEjpyPFHdlabiAVJvIrcwnThkRKMqL,headers=GEjpyPFHdlabiAVJvIrcwnThkRKMqx,cookies=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,redirects=GEjpyPFHdlabiAVJvIrcwnThkRKMxN)
   if GEjpyPFHdlabiAVJvIrcwnThkRKMqz.status_code not in[200]:return[],GEjpyPFHdlabiAVJvIrcwnThkRKMxQ
   GEjpyPFHdlabiAVJvIrcwnThkRKMqu=json.loads(GEjpyPFHdlabiAVJvIrcwnThkRKMqz.text)
   for GEjpyPFHdlabiAVJvIrcwnThkRKMqN in GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('data').get('data'):
    GEjpyPFHdlabiAVJvIrcwnThkRKMqN=GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('data')
    GEjpyPFHdlabiAVJvIrcwnThkRKMXx=GEjpyPFHdlabiAVJvIrcwnThkRKMXD=GEjpyPFHdlabiAVJvIrcwnThkRKMxe=GEjpyPFHdlabiAVJvIrcwnThkRKMxo=''
    if 'poster' in GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('images'):GEjpyPFHdlabiAVJvIrcwnThkRKMXx =GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('images'):GEjpyPFHdlabiAVJvIrcwnThkRKMXD =GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('images').get('story-art').get('url') +'?imwidth=600'
    if 'title-treatment' in GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('images'):GEjpyPFHdlabiAVJvIrcwnThkRKMxe=GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('images').get('title-treatment').get('url')+'?imwidth=300'
    if 'story-art' in GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('images'):GEjpyPFHdlabiAVJvIrcwnThkRKMxo =GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('images').get('story-art').get('url') +'?imwidth=600'
    GEjpyPFHdlabiAVJvIrcwnThkRKMXW=''
    if GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('badge')not in[{},GEjpyPFHdlabiAVJvIrcwnThkRKMxt]:
     for i in GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('badge').get('text'):
      if GEjpyPFHdlabiAVJvIrcwnThkRKMXW!='':GEjpyPFHdlabiAVJvIrcwnThkRKMXW+=' '
      GEjpyPFHdlabiAVJvIrcwnThkRKMXW+=i.get('text')
    if 'as' in GEjpyPFHdlabiAVJvIrcwnThkRKMqN:
     GEjpyPFHdlabiAVJvIrcwnThkRKMxB=GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('as') 
    else:
     GEjpyPFHdlabiAVJvIrcwnThkRKMxB=GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('type')
    GEjpyPFHdlabiAVJvIrcwnThkRKMqU={'id':GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('id'),'title':GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('title'),'asis':GEjpyPFHdlabiAVJvIrcwnThkRKMxB,'thumbnail':{'poster':GEjpyPFHdlabiAVJvIrcwnThkRKMXx,'thumb':GEjpyPFHdlabiAVJvIrcwnThkRKMXD,'clearlogo':GEjpyPFHdlabiAVJvIrcwnThkRKMxe,'fanart':GEjpyPFHdlabiAVJvIrcwnThkRKMxo},'mpaa':GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('age_rating'),'duration':GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('running_time'),'badge':GEjpyPFHdlabiAVJvIrcwnThkRKMXW,'year':GEjpyPFHdlabiAVJvIrcwnThkRKMqN.get('meta').get('releaseYear'),}
    GEjpyPFHdlabiAVJvIrcwnThkRKMqf.append(GEjpyPFHdlabiAVJvIrcwnThkRKMqU)
   if GEjpyPFHdlabiAVJvIrcwnThkRKMqu.get('pagination').get('totalPages')>page_int:
    GEjpyPFHdlabiAVJvIrcwnThkRKMXB=GEjpyPFHdlabiAVJvIrcwnThkRKMxN
  except GEjpyPFHdlabiAVJvIrcwnThkRKMxm as exception:
   GEjpyPFHdlabiAVJvIrcwnThkRKMxg(exception)
   return[],GEjpyPFHdlabiAVJvIrcwnThkRKMxQ
  return GEjpyPFHdlabiAVJvIrcwnThkRKMqf,GEjpyPFHdlabiAVJvIrcwnThkRKMXB
 def GetBookmarkInfo(GEjpyPFHdlabiAVJvIrcwnThkRKMBX,videoid,vidtype):
  GEjpyPFHdlabiAVJvIrcwnThkRKMxq={'indexinfo':{'ott':'coupang','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  GEjpyPFHdlabiAVJvIrcwnThkRKMqX=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.API_VIEWURL+'/v1/discover/titles/'+videoid 
  GEjpyPFHdlabiAVJvIrcwnThkRKMqL={'locale':'ko'}
  GEjpyPFHdlabiAVJvIrcwnThkRKMqz=GEjpyPFHdlabiAVJvIrcwnThkRKMBX.callRequestCookies('Get',GEjpyPFHdlabiAVJvIrcwnThkRKMqX,payload=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,params=GEjpyPFHdlabiAVJvIrcwnThkRKMqL,headers=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,cookies=GEjpyPFHdlabiAVJvIrcwnThkRKMxt,redirects=GEjpyPFHdlabiAVJvIrcwnThkRKMxN)
  if GEjpyPFHdlabiAVJvIrcwnThkRKMqz.status_code not in[200]:return{}
  GEjpyPFHdlabiAVJvIrcwnThkRKMxX=json.loads(GEjpyPFHdlabiAVJvIrcwnThkRKMqz.text).get('data')
  GEjpyPFHdlabiAVJvIrcwnThkRKMxW=GEjpyPFHdlabiAVJvIrcwnThkRKMxX.get('title')
  GEjpyPFHdlabiAVJvIrcwnThkRKMxz =GEjpyPFHdlabiAVJvIrcwnThkRKMxX.get('meta').get('releaseYear')
  GEjpyPFHdlabiAVJvIrcwnThkRKMxq['saveinfo']['infoLabels']['title']=GEjpyPFHdlabiAVJvIrcwnThkRKMxW
  if vidtype=='movie':
   GEjpyPFHdlabiAVJvIrcwnThkRKMxW='%s  (%s)'%(GEjpyPFHdlabiAVJvIrcwnThkRKMxW,GEjpyPFHdlabiAVJvIrcwnThkRKMxz)
  GEjpyPFHdlabiAVJvIrcwnThkRKMxq['saveinfo']['title'] =GEjpyPFHdlabiAVJvIrcwnThkRKMxW
  GEjpyPFHdlabiAVJvIrcwnThkRKMxq['saveinfo']['infoLabels']['mpaa'] =GEjpyPFHdlabiAVJvIrcwnThkRKMxX.get('age_rating')
  GEjpyPFHdlabiAVJvIrcwnThkRKMxq['saveinfo']['infoLabels']['plot'] ='%s\n\n%s'%(GEjpyPFHdlabiAVJvIrcwnThkRKMxX.get('short_description'),GEjpyPFHdlabiAVJvIrcwnThkRKMxX.get('description'))
  GEjpyPFHdlabiAVJvIrcwnThkRKMxq['saveinfo']['infoLabels']['year'] =GEjpyPFHdlabiAVJvIrcwnThkRKMxz
  if vidtype=='movie':
   GEjpyPFHdlabiAVJvIrcwnThkRKMxq['saveinfo']['infoLabels']['duration']=GEjpyPFHdlabiAVJvIrcwnThkRKMxX.get('running_time')
  GEjpyPFHdlabiAVJvIrcwnThkRKMXx =''
  GEjpyPFHdlabiAVJvIrcwnThkRKMxo =''
  GEjpyPFHdlabiAVJvIrcwnThkRKMXD =''
  GEjpyPFHdlabiAVJvIrcwnThkRKMxe=''
  if GEjpyPFHdlabiAVJvIrcwnThkRKMxX.get('images').get('poster') !=GEjpyPFHdlabiAVJvIrcwnThkRKMxt:GEjpyPFHdlabiAVJvIrcwnThkRKMXx =GEjpyPFHdlabiAVJvIrcwnThkRKMxX.get('images').get('poster').get('url') +'?imwidth=350'
  if GEjpyPFHdlabiAVJvIrcwnThkRKMxX.get('images').get('background') !=GEjpyPFHdlabiAVJvIrcwnThkRKMxt:GEjpyPFHdlabiAVJvIrcwnThkRKMxo =GEjpyPFHdlabiAVJvIrcwnThkRKMxX.get('images').get('background').get('url') +'?imwidth=600'
  if GEjpyPFHdlabiAVJvIrcwnThkRKMxX.get('images').get('story-art') !=GEjpyPFHdlabiAVJvIrcwnThkRKMxt:GEjpyPFHdlabiAVJvIrcwnThkRKMXD =GEjpyPFHdlabiAVJvIrcwnThkRKMxX.get('images').get('story-art').get('url') +'?imwidth=600'
  if GEjpyPFHdlabiAVJvIrcwnThkRKMxX.get('images').get('title-treatment')!=GEjpyPFHdlabiAVJvIrcwnThkRKMxt:GEjpyPFHdlabiAVJvIrcwnThkRKMxe=GEjpyPFHdlabiAVJvIrcwnThkRKMxX.get('images').get('title-treatment').get('url')+'?imwidth=300'
  if GEjpyPFHdlabiAVJvIrcwnThkRKMxo=='':GEjpyPFHdlabiAVJvIrcwnThkRKMxo=GEjpyPFHdlabiAVJvIrcwnThkRKMXD
  GEjpyPFHdlabiAVJvIrcwnThkRKMxq['saveinfo']['thumbnail']['poster']=GEjpyPFHdlabiAVJvIrcwnThkRKMXx
  GEjpyPFHdlabiAVJvIrcwnThkRKMxq['saveinfo']['thumbnail']['fanart']=GEjpyPFHdlabiAVJvIrcwnThkRKMxo
  GEjpyPFHdlabiAVJvIrcwnThkRKMxq['saveinfo']['thumbnail']['thumb']=GEjpyPFHdlabiAVJvIrcwnThkRKMXD
  GEjpyPFHdlabiAVJvIrcwnThkRKMxq['saveinfo']['thumbnail']['clearlogo']=GEjpyPFHdlabiAVJvIrcwnThkRKMxe
  GEjpyPFHdlabiAVJvIrcwnThkRKMxD=[]
  for GEjpyPFHdlabiAVJvIrcwnThkRKMXe in GEjpyPFHdlabiAVJvIrcwnThkRKMxX.get('tags'):GEjpyPFHdlabiAVJvIrcwnThkRKMxD.append(GEjpyPFHdlabiAVJvIrcwnThkRKMXe.get('tag'))
  if GEjpyPFHdlabiAVJvIrcwnThkRKMxY(GEjpyPFHdlabiAVJvIrcwnThkRKMxD)>0:
   GEjpyPFHdlabiAVJvIrcwnThkRKMxq['saveinfo']['infoLabels']['genre']=GEjpyPFHdlabiAVJvIrcwnThkRKMxD
  GEjpyPFHdlabiAVJvIrcwnThkRKMxC=[]
  GEjpyPFHdlabiAVJvIrcwnThkRKMxs=[]
  for GEjpyPFHdlabiAVJvIrcwnThkRKMXe in GEjpyPFHdlabiAVJvIrcwnThkRKMxX.get('people'):
   if GEjpyPFHdlabiAVJvIrcwnThkRKMXe.get('role')=='CAST' :GEjpyPFHdlabiAVJvIrcwnThkRKMxC.append(GEjpyPFHdlabiAVJvIrcwnThkRKMXe.get('name'))
   if GEjpyPFHdlabiAVJvIrcwnThkRKMXe.get('role')=='DIRECTOR':GEjpyPFHdlabiAVJvIrcwnThkRKMxs.append(GEjpyPFHdlabiAVJvIrcwnThkRKMXe.get('name'))
  if GEjpyPFHdlabiAVJvIrcwnThkRKMxY(GEjpyPFHdlabiAVJvIrcwnThkRKMxC)>0:
   GEjpyPFHdlabiAVJvIrcwnThkRKMxq['saveinfo']['infoLabels']['cast'] =GEjpyPFHdlabiAVJvIrcwnThkRKMxC
  if GEjpyPFHdlabiAVJvIrcwnThkRKMxY(GEjpyPFHdlabiAVJvIrcwnThkRKMxs)>0:
   GEjpyPFHdlabiAVJvIrcwnThkRKMxq['saveinfo']['infoLabels']['director']=GEjpyPFHdlabiAVJvIrcwnThkRKMxs
  return GEjpyPFHdlabiAVJvIrcwnThkRKMxq
# Created by pyminifier (https://github.com/liftoff/pyminifier)
