__author__="NightRain"
AKFwENqxJsCbzYtLgeSomTUpriDOjd=object
AKFwENqxJsCbzYtLgeSomTUpriDOPu=None
AKFwENqxJsCbzYtLgeSomTUpriDOPW=False
AKFwENqxJsCbzYtLgeSomTUpriDOPQ=True
AKFwENqxJsCbzYtLgeSomTUpriDOPX=type
AKFwENqxJsCbzYtLgeSomTUpriDOPH=dict
AKFwENqxJsCbzYtLgeSomTUpriDOPj=getattr
AKFwENqxJsCbzYtLgeSomTUpriDOPR=int
AKFwENqxJsCbzYtLgeSomTUpriDOPk=list
AKFwENqxJsCbzYtLgeSomTUpriDOPc=open
AKFwENqxJsCbzYtLgeSomTUpriDOPf=Exception
AKFwENqxJsCbzYtLgeSomTUpriDOPB=str
AKFwENqxJsCbzYtLgeSomTUpriDOPI=id
AKFwENqxJsCbzYtLgeSomTUpriDOPM=len
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import inputstreamhelper
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
AKFwENqxJsCbzYtLgeSomTUpriDOuQ=[{'title':'오직 쿠팡플레이에서','mode':'CATEGORY_LIST','vType':'ORIGINAL','collectionId':'5c33c5ca-ee6f-45f8-a026-dd789a8b63cf'},{'title':'홈   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'ALL'},{'title':'TV   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'MOVIES'},{'title':'키즈 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'KIDS'},{'title':'생중계','mode':'EVENT_GROUPLIST','vType':'LIVE'},{'title':'TV   (테마별)','mode':'THEME_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (테마별)','mode':'THEME_GROUPLIST','vType':'MOVIES'},{'title':'키즈 (테마별)','mode':'THEME_GROUPLIST','vType':'KIDS'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},{'title':'(쿠팡) 검색','mode':'LOCAL_SEARCH','icon':'search.png'},{'title':'(쿠팡) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
AKFwENqxJsCbzYtLgeSomTUpriDOuX=[{'title':'시리즈 시청내역','mode':'WATCH','stype':'tvshow'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},]
AKFwENqxJsCbzYtLgeSomTUpriDOuH={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
AKFwENqxJsCbzYtLgeSomTUpriDOuj=xbmcvfs.translatePath(os.path.join(__profile__,'coupang_searched.txt'))
from coupangCore import*
class AKFwENqxJsCbzYtLgeSomTUpriDOuW(AKFwENqxJsCbzYtLgeSomTUpriDOjd):
 def __init__(AKFwENqxJsCbzYtLgeSomTUpriDOuP,AKFwENqxJsCbzYtLgeSomTUpriDOuR,AKFwENqxJsCbzYtLgeSomTUpriDOuk,AKFwENqxJsCbzYtLgeSomTUpriDOuc):
  AKFwENqxJsCbzYtLgeSomTUpriDOuP._addon_url =AKFwENqxJsCbzYtLgeSomTUpriDOuR
  AKFwENqxJsCbzYtLgeSomTUpriDOuP._addon_handle=AKFwENqxJsCbzYtLgeSomTUpriDOuk
  AKFwENqxJsCbzYtLgeSomTUpriDOuP.main_params =AKFwENqxJsCbzYtLgeSomTUpriDOuc
  AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj =GEjpyPFHdlabiAVJvIrcwnThkRKMBq() 
  AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.CP_COOKIE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_cookies.json'))
  AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.CP_DEVICE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_device.json'))
 def addon_noti(AKFwENqxJsCbzYtLgeSomTUpriDOuP,sting):
  try:
   AKFwENqxJsCbzYtLgeSomTUpriDOuB=xbmcgui.Dialog()
   AKFwENqxJsCbzYtLgeSomTUpriDOuB.notification(__addonname__,sting)
  except:
   AKFwENqxJsCbzYtLgeSomTUpriDOPu
 def addon_log(AKFwENqxJsCbzYtLgeSomTUpriDOuP,string):
  try:
   AKFwENqxJsCbzYtLgeSomTUpriDOuI=string.encode('utf-8','ignore')
  except:
   AKFwENqxJsCbzYtLgeSomTUpriDOuI='addonException: addon_log'
  AKFwENqxJsCbzYtLgeSomTUpriDOuM=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,AKFwENqxJsCbzYtLgeSomTUpriDOuI),level=AKFwENqxJsCbzYtLgeSomTUpriDOuM)
 def get_keyboard_input(AKFwENqxJsCbzYtLgeSomTUpriDOuP,AKFwENqxJsCbzYtLgeSomTUpriDOWX):
  AKFwENqxJsCbzYtLgeSomTUpriDOuv=AKFwENqxJsCbzYtLgeSomTUpriDOPu
  kb=xbmc.Keyboard()
  kb.setHeading(AKFwENqxJsCbzYtLgeSomTUpriDOWX)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   AKFwENqxJsCbzYtLgeSomTUpriDOuv=kb.getText()
  return AKFwENqxJsCbzYtLgeSomTUpriDOuv
 def get_settings_account(AKFwENqxJsCbzYtLgeSomTUpriDOuP):
  AKFwENqxJsCbzYtLgeSomTUpriDOul=__addon__.getSetting('id')
  AKFwENqxJsCbzYtLgeSomTUpriDOuG=__addon__.getSetting('pw')
  AKFwENqxJsCbzYtLgeSomTUpriDOuV=__addon__.getSetting('profile')
  return(AKFwENqxJsCbzYtLgeSomTUpriDOul,AKFwENqxJsCbzYtLgeSomTUpriDOuG,AKFwENqxJsCbzYtLgeSomTUpriDOuV)
 def get_settings_exclusion21(AKFwENqxJsCbzYtLgeSomTUpriDOuP):
  AKFwENqxJsCbzYtLgeSomTUpriDOuh =__addon__.getSetting('exclusion21')
  if AKFwENqxJsCbzYtLgeSomTUpriDOuh=='false':
   return AKFwENqxJsCbzYtLgeSomTUpriDOPW
  else:
   return AKFwENqxJsCbzYtLgeSomTUpriDOPQ
 def get_settings_totalsearch(AKFwENqxJsCbzYtLgeSomTUpriDOuP):
  AKFwENqxJsCbzYtLgeSomTUpriDOuy =AKFwENqxJsCbzYtLgeSomTUpriDOPQ if __addon__.getSetting('local_search')=='true' else AKFwENqxJsCbzYtLgeSomTUpriDOPW
  AKFwENqxJsCbzYtLgeSomTUpriDOun=AKFwENqxJsCbzYtLgeSomTUpriDOPQ if __addon__.getSetting('local_history')=='true' else AKFwENqxJsCbzYtLgeSomTUpriDOPW
  AKFwENqxJsCbzYtLgeSomTUpriDOua =AKFwENqxJsCbzYtLgeSomTUpriDOPQ if __addon__.getSetting('total_search')=='true' else AKFwENqxJsCbzYtLgeSomTUpriDOPW
  AKFwENqxJsCbzYtLgeSomTUpriDOud=AKFwENqxJsCbzYtLgeSomTUpriDOPQ if __addon__.getSetting('total_history')=='true' else AKFwENqxJsCbzYtLgeSomTUpriDOPW
  AKFwENqxJsCbzYtLgeSomTUpriDOWu=AKFwENqxJsCbzYtLgeSomTUpriDOPQ if __addon__.getSetting('menu_bookmark')=='true' else AKFwENqxJsCbzYtLgeSomTUpriDOPW
  return(AKFwENqxJsCbzYtLgeSomTUpriDOuy,AKFwENqxJsCbzYtLgeSomTUpriDOun,AKFwENqxJsCbzYtLgeSomTUpriDOua,AKFwENqxJsCbzYtLgeSomTUpriDOud,AKFwENqxJsCbzYtLgeSomTUpriDOWu)
 def get_settings_makebookmark(AKFwENqxJsCbzYtLgeSomTUpriDOuP):
  return AKFwENqxJsCbzYtLgeSomTUpriDOPQ if __addon__.getSetting('make_bookmark')=='true' else AKFwENqxJsCbzYtLgeSomTUpriDOPW
 def add_dir(AKFwENqxJsCbzYtLgeSomTUpriDOuP,label,sublabel='',img='',infoLabels=AKFwENqxJsCbzYtLgeSomTUpriDOPu,isFolder=AKFwENqxJsCbzYtLgeSomTUpriDOPQ,params='',isLink=AKFwENqxJsCbzYtLgeSomTUpriDOPW,ContextMenu=AKFwENqxJsCbzYtLgeSomTUpriDOPu):
  AKFwENqxJsCbzYtLgeSomTUpriDOWQ='%s?%s'%(AKFwENqxJsCbzYtLgeSomTUpriDOuP._addon_url,urllib.parse.urlencode(params))
  if sublabel:AKFwENqxJsCbzYtLgeSomTUpriDOWX='%s < %s >'%(label,sublabel)
  else: AKFwENqxJsCbzYtLgeSomTUpriDOWX=label
  if not img:img='DefaultFolder.png'
  AKFwENqxJsCbzYtLgeSomTUpriDOWH=xbmcgui.ListItem(AKFwENqxJsCbzYtLgeSomTUpriDOWX)
  if AKFwENqxJsCbzYtLgeSomTUpriDOPX(img)==AKFwENqxJsCbzYtLgeSomTUpriDOPH:
   AKFwENqxJsCbzYtLgeSomTUpriDOWH.setArt(img)
  else:
   AKFwENqxJsCbzYtLgeSomTUpriDOWH.setArt({'thumb':img,'poster':img})
  if AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.KodiVersion>=20:
   if infoLabels:AKFwENqxJsCbzYtLgeSomTUpriDOuP.Set_InfoTag(AKFwENqxJsCbzYtLgeSomTUpriDOWH.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:AKFwENqxJsCbzYtLgeSomTUpriDOWH.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   AKFwENqxJsCbzYtLgeSomTUpriDOWH.setProperty('IsPlayable','true')
  if ContextMenu:AKFwENqxJsCbzYtLgeSomTUpriDOWH.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(AKFwENqxJsCbzYtLgeSomTUpriDOuP._addon_handle,AKFwENqxJsCbzYtLgeSomTUpriDOWQ,AKFwENqxJsCbzYtLgeSomTUpriDOWH,isFolder)
 def Set_InfoTag(AKFwENqxJsCbzYtLgeSomTUpriDOuP,video_InfoTag:xbmc.InfoTagVideo,AKFwENqxJsCbzYtLgeSomTUpriDOWI):
  for AKFwENqxJsCbzYtLgeSomTUpriDOWj,value in AKFwENqxJsCbzYtLgeSomTUpriDOWI.items():
   if AKFwENqxJsCbzYtLgeSomTUpriDOuH[AKFwENqxJsCbzYtLgeSomTUpriDOWj]['type']=='string':
    AKFwENqxJsCbzYtLgeSomTUpriDOPj(video_InfoTag,AKFwENqxJsCbzYtLgeSomTUpriDOuH[AKFwENqxJsCbzYtLgeSomTUpriDOWj]['func'])(value)
   elif AKFwENqxJsCbzYtLgeSomTUpriDOuH[AKFwENqxJsCbzYtLgeSomTUpriDOWj]['type']=='int':
    if AKFwENqxJsCbzYtLgeSomTUpriDOPX(value)==AKFwENqxJsCbzYtLgeSomTUpriDOPR:
     AKFwENqxJsCbzYtLgeSomTUpriDOWP=AKFwENqxJsCbzYtLgeSomTUpriDOPR(value)
    else:
     AKFwENqxJsCbzYtLgeSomTUpriDOWP=0
    AKFwENqxJsCbzYtLgeSomTUpriDOPj(video_InfoTag,AKFwENqxJsCbzYtLgeSomTUpriDOuH[AKFwENqxJsCbzYtLgeSomTUpriDOWj]['func'])(AKFwENqxJsCbzYtLgeSomTUpriDOWP)
   elif AKFwENqxJsCbzYtLgeSomTUpriDOuH[AKFwENqxJsCbzYtLgeSomTUpriDOWj]['type']=='actor':
    if value!=[]:
     AKFwENqxJsCbzYtLgeSomTUpriDOPj(video_InfoTag,AKFwENqxJsCbzYtLgeSomTUpriDOuH[AKFwENqxJsCbzYtLgeSomTUpriDOWj]['func'])([xbmc.Actor(name)for name in value])
   elif AKFwENqxJsCbzYtLgeSomTUpriDOuH[AKFwENqxJsCbzYtLgeSomTUpriDOWj]['type']=='list':
    if AKFwENqxJsCbzYtLgeSomTUpriDOPX(value)==AKFwENqxJsCbzYtLgeSomTUpriDOPk:
     AKFwENqxJsCbzYtLgeSomTUpriDOPj(video_InfoTag,AKFwENqxJsCbzYtLgeSomTUpriDOuH[AKFwENqxJsCbzYtLgeSomTUpriDOWj]['func'])(value)
    else:
     AKFwENqxJsCbzYtLgeSomTUpriDOPj(video_InfoTag,AKFwENqxJsCbzYtLgeSomTUpriDOuH[AKFwENqxJsCbzYtLgeSomTUpriDOWj]['func'])([value])
 def dp_Main_List(AKFwENqxJsCbzYtLgeSomTUpriDOuP,args):
  (AKFwENqxJsCbzYtLgeSomTUpriDOuy,AKFwENqxJsCbzYtLgeSomTUpriDOun,AKFwENqxJsCbzYtLgeSomTUpriDOua,AKFwENqxJsCbzYtLgeSomTUpriDOud,AKFwENqxJsCbzYtLgeSomTUpriDOWu)=AKFwENqxJsCbzYtLgeSomTUpriDOuP.get_settings_totalsearch()
  for AKFwENqxJsCbzYtLgeSomTUpriDOWR in AKFwENqxJsCbzYtLgeSomTUpriDOuQ:
   AKFwENqxJsCbzYtLgeSomTUpriDOWX=AKFwENqxJsCbzYtLgeSomTUpriDOWR.get('title')
   AKFwENqxJsCbzYtLgeSomTUpriDOWk=''
   if AKFwENqxJsCbzYtLgeSomTUpriDOWR.get('mode')=='LOCAL_SEARCH' and AKFwENqxJsCbzYtLgeSomTUpriDOuy ==AKFwENqxJsCbzYtLgeSomTUpriDOPW:continue
   elif AKFwENqxJsCbzYtLgeSomTUpriDOWR.get('mode')=='SEARCH_HISTORY' and AKFwENqxJsCbzYtLgeSomTUpriDOun==AKFwENqxJsCbzYtLgeSomTUpriDOPW:continue
   elif AKFwENqxJsCbzYtLgeSomTUpriDOWR.get('mode')=='TOTAL_SEARCH' and AKFwENqxJsCbzYtLgeSomTUpriDOua ==AKFwENqxJsCbzYtLgeSomTUpriDOPW:continue
   elif AKFwENqxJsCbzYtLgeSomTUpriDOWR.get('mode')=='TOTAL_HISTORY' and AKFwENqxJsCbzYtLgeSomTUpriDOud==AKFwENqxJsCbzYtLgeSomTUpriDOPW:continue
   elif AKFwENqxJsCbzYtLgeSomTUpriDOWR.get('mode')=='MENU_BOOKMARK' and AKFwENqxJsCbzYtLgeSomTUpriDOWu==AKFwENqxJsCbzYtLgeSomTUpriDOPW:continue
   AKFwENqxJsCbzYtLgeSomTUpriDOWc={'mode':AKFwENqxJsCbzYtLgeSomTUpriDOWR.get('mode'),'vType':AKFwENqxJsCbzYtLgeSomTUpriDOWR.get('vType'),'collectionId':AKFwENqxJsCbzYtLgeSomTUpriDOWR.get('collectionId'),'page':'1',}
   if AKFwENqxJsCbzYtLgeSomTUpriDOWR.get('mode')=='LOCAL_SEARCH':AKFwENqxJsCbzYtLgeSomTUpriDOWc['historyyn']='Y' 
   if AKFwENqxJsCbzYtLgeSomTUpriDOWR.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    AKFwENqxJsCbzYtLgeSomTUpriDOWf=AKFwENqxJsCbzYtLgeSomTUpriDOPW
    AKFwENqxJsCbzYtLgeSomTUpriDOWB =AKFwENqxJsCbzYtLgeSomTUpriDOPQ
   else:
    AKFwENqxJsCbzYtLgeSomTUpriDOWf=AKFwENqxJsCbzYtLgeSomTUpriDOPQ
    AKFwENqxJsCbzYtLgeSomTUpriDOWB =AKFwENqxJsCbzYtLgeSomTUpriDOPW
   AKFwENqxJsCbzYtLgeSomTUpriDOWI={'title':AKFwENqxJsCbzYtLgeSomTUpriDOWX,'plot':AKFwENqxJsCbzYtLgeSomTUpriDOWX}
   if AKFwENqxJsCbzYtLgeSomTUpriDOWR.get('mode')=='XXX':AKFwENqxJsCbzYtLgeSomTUpriDOWI=AKFwENqxJsCbzYtLgeSomTUpriDOPu
   if 'icon' in AKFwENqxJsCbzYtLgeSomTUpriDOWR:AKFwENqxJsCbzYtLgeSomTUpriDOWk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',AKFwENqxJsCbzYtLgeSomTUpriDOWR.get('icon')) 
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.add_dir(AKFwENqxJsCbzYtLgeSomTUpriDOWX,sublabel='',img=AKFwENqxJsCbzYtLgeSomTUpriDOWk,infoLabels=AKFwENqxJsCbzYtLgeSomTUpriDOWI,isFolder=AKFwENqxJsCbzYtLgeSomTUpriDOWf,params=AKFwENqxJsCbzYtLgeSomTUpriDOWc,isLink=AKFwENqxJsCbzYtLgeSomTUpriDOWB)
  xbmcplugin.endOfDirectory(AKFwENqxJsCbzYtLgeSomTUpriDOuP._addon_handle)
 def dp_Test(AKFwENqxJsCbzYtLgeSomTUpriDOuP,args):
  AKFwENqxJsCbzYtLgeSomTUpriDOuP.addon_noti('test')
 def CP_logout(AKFwENqxJsCbzYtLgeSomTUpriDOuP):
  AKFwENqxJsCbzYtLgeSomTUpriDOuB=xbmcgui.Dialog()
  AKFwENqxJsCbzYtLgeSomTUpriDOWv=AKFwENqxJsCbzYtLgeSomTUpriDOuB.yesno(__language__(30905).encode('utf8'),__language__(30906).encode('utf8'))
  if AKFwENqxJsCbzYtLgeSomTUpriDOWv==AKFwENqxJsCbzYtLgeSomTUpriDOPW:return 
  if os.path.isfile(AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.CP_COOKIE_FILENAME):os.remove(AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.CP_COOKIE_FILENAME)
  AKFwENqxJsCbzYtLgeSomTUpriDOuP.addon_noti(__language__(30904).encode('utf-8'))
 def option_check(AKFwENqxJsCbzYtLgeSomTUpriDOuP):
  (AKFwENqxJsCbzYtLgeSomTUpriDOul,AKFwENqxJsCbzYtLgeSomTUpriDOuG,AKFwENqxJsCbzYtLgeSomTUpriDOuV)=AKFwENqxJsCbzYtLgeSomTUpriDOuP.get_settings_account()
  if AKFwENqxJsCbzYtLgeSomTUpriDOul=='' or AKFwENqxJsCbzYtLgeSomTUpriDOuG=='':
   AKFwENqxJsCbzYtLgeSomTUpriDOuB=xbmcgui.Dialog()
   AKFwENqxJsCbzYtLgeSomTUpriDOWv=AKFwENqxJsCbzYtLgeSomTUpriDOuB.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if AKFwENqxJsCbzYtLgeSomTUpriDOWv==AKFwENqxJsCbzYtLgeSomTUpriDOPQ:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if AKFwENqxJsCbzYtLgeSomTUpriDOuP.cookiefile_check()==AKFwENqxJsCbzYtLgeSomTUpriDOPW:
   if AKFwENqxJsCbzYtLgeSomTUpriDOuP.CP_login(AKFwENqxJsCbzYtLgeSomTUpriDOul,AKFwENqxJsCbzYtLgeSomTUpriDOuG,AKFwENqxJsCbzYtLgeSomTUpriDOuV)==AKFwENqxJsCbzYtLgeSomTUpriDOPW:
    AKFwENqxJsCbzYtLgeSomTUpriDOuP.addon_noti(__language__(30903).encode('utf8'))
    sys.exit()
  else:
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.Get_CP_profile(AKFwENqxJsCbzYtLgeSomTUpriDOuV,limit_days=AKFwENqxJsCbzYtLgeSomTUpriDOPR(__addon__.getSetting('cache_ttl')),re_check=AKFwENqxJsCbzYtLgeSomTUpriDOPQ)
 def cookiefile_check(AKFwENqxJsCbzYtLgeSomTUpriDOuP):
  AKFwENqxJsCbzYtLgeSomTUpriDOWG={}
  try: 
   fp=AKFwENqxJsCbzYtLgeSomTUpriDOPc(AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.CP_COOKIE_FILENAME,'r',-1,'utf-8')
   AKFwENqxJsCbzYtLgeSomTUpriDOWG= json.load(fp)
   fp.close()
  except AKFwENqxJsCbzYtLgeSomTUpriDOPf as exception:
   return AKFwENqxJsCbzYtLgeSomTUpriDOPW
  AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.CP=AKFwENqxJsCbzYtLgeSomTUpriDOWG
  (AKFwENqxJsCbzYtLgeSomTUpriDOul,AKFwENqxJsCbzYtLgeSomTUpriDOuG,AKFwENqxJsCbzYtLgeSomTUpriDOuV)=AKFwENqxJsCbzYtLgeSomTUpriDOuP.get_settings_account()
  (AKFwENqxJsCbzYtLgeSomTUpriDOWV,AKFwENqxJsCbzYtLgeSomTUpriDOWh,AKFwENqxJsCbzYtLgeSomTUpriDOWy)=AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.Load_session_acount()
  if AKFwENqxJsCbzYtLgeSomTUpriDOul!=AKFwENqxJsCbzYtLgeSomTUpriDOWV or AKFwENqxJsCbzYtLgeSomTUpriDOuG!=AKFwENqxJsCbzYtLgeSomTUpriDOWh or AKFwENqxJsCbzYtLgeSomTUpriDOuV!=AKFwENqxJsCbzYtLgeSomTUpriDOPB(AKFwENqxJsCbzYtLgeSomTUpriDOWy):
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.Init_CP()
   return AKFwENqxJsCbzYtLgeSomTUpriDOPW
  AKFwENqxJsCbzYtLgeSomTUpriDOWn =AKFwENqxJsCbzYtLgeSomTUpriDOPR(AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.Get_Now_Datetime().strftime('%Y%m%d'))
  AKFwENqxJsCbzYtLgeSomTUpriDOWa=AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.CP['SESSION']['limitdate']
  AKFwENqxJsCbzYtLgeSomTUpriDOWd =AKFwENqxJsCbzYtLgeSomTUpriDOPR(re.sub('-','',AKFwENqxJsCbzYtLgeSomTUpriDOWa))
  if AKFwENqxJsCbzYtLgeSomTUpriDOWd<AKFwENqxJsCbzYtLgeSomTUpriDOWn:
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.Init_CP()
   return AKFwENqxJsCbzYtLgeSomTUpriDOPW
  return AKFwENqxJsCbzYtLgeSomTUpriDOPQ
 def CP_login(AKFwENqxJsCbzYtLgeSomTUpriDOuP,AKFwENqxJsCbzYtLgeSomTUpriDOul,AKFwENqxJsCbzYtLgeSomTUpriDOuG,AKFwENqxJsCbzYtLgeSomTUpriDOuV):
  if AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.Get_CP_Login(AKFwENqxJsCbzYtLgeSomTUpriDOul,AKFwENqxJsCbzYtLgeSomTUpriDOuG,AKFwENqxJsCbzYtLgeSomTUpriDOuV)==AKFwENqxJsCbzYtLgeSomTUpriDOPW:return AKFwENqxJsCbzYtLgeSomTUpriDOPW
  if AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.Get_CP_profile(AKFwENqxJsCbzYtLgeSomTUpriDOuV,limit_days=AKFwENqxJsCbzYtLgeSomTUpriDOPR(__addon__.getSetting('cache_ttl')),re_check=AKFwENqxJsCbzYtLgeSomTUpriDOPW)==AKFwENqxJsCbzYtLgeSomTUpriDOPW:return AKFwENqxJsCbzYtLgeSomTUpriDOPW
  return AKFwENqxJsCbzYtLgeSomTUpriDOPQ
 def dp_Category_GroupList(AKFwENqxJsCbzYtLgeSomTUpriDOuP,args):
  AKFwENqxJsCbzYtLgeSomTUpriDOQu =args.get('vType') 
  AKFwENqxJsCbzYtLgeSomTUpriDOQW=AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.Get_Category_GroupList(AKFwENqxJsCbzYtLgeSomTUpriDOQu)
  for AKFwENqxJsCbzYtLgeSomTUpriDOQX in AKFwENqxJsCbzYtLgeSomTUpriDOQW:
   AKFwENqxJsCbzYtLgeSomTUpriDOWX =AKFwENqxJsCbzYtLgeSomTUpriDOQX.get('title')
   AKFwENqxJsCbzYtLgeSomTUpriDOQH=AKFwENqxJsCbzYtLgeSomTUpriDOQX.get('pre_title')
   if AKFwENqxJsCbzYtLgeSomTUpriDOuP.get_settings_exclusion21()==AKFwENqxJsCbzYtLgeSomTUpriDOPQ and AKFwENqxJsCbzYtLgeSomTUpriDOWX=='성인':continue
   AKFwENqxJsCbzYtLgeSomTUpriDOQj={'mediatype':'tvshow','plot':AKFwENqxJsCbzYtLgeSomTUpriDOQH,}
   AKFwENqxJsCbzYtLgeSomTUpriDOWc={'mode':'CATEGORY_LIST','collectionId':AKFwENqxJsCbzYtLgeSomTUpriDOQX.get('collectionId'),'vType':AKFwENqxJsCbzYtLgeSomTUpriDOQX.get('category'),'page':'1',}
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.add_dir(AKFwENqxJsCbzYtLgeSomTUpriDOWX,sublabel='',img='',infoLabels=AKFwENqxJsCbzYtLgeSomTUpriDOQj,isFolder=AKFwENqxJsCbzYtLgeSomTUpriDOPQ,params=AKFwENqxJsCbzYtLgeSomTUpriDOWc)
  xbmcplugin.endOfDirectory(AKFwENqxJsCbzYtLgeSomTUpriDOuP._addon_handle,cacheToDisc=AKFwENqxJsCbzYtLgeSomTUpriDOPW)
 def dp_Theme_GroupList(AKFwENqxJsCbzYtLgeSomTUpriDOuP,args):
  AKFwENqxJsCbzYtLgeSomTUpriDOQu =args.get('vType') 
  AKFwENqxJsCbzYtLgeSomTUpriDOQW=AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.Get_Theme_GroupList(AKFwENqxJsCbzYtLgeSomTUpriDOQu)
  for AKFwENqxJsCbzYtLgeSomTUpriDOQX in AKFwENqxJsCbzYtLgeSomTUpriDOQW:
   AKFwENqxJsCbzYtLgeSomTUpriDOWX =AKFwENqxJsCbzYtLgeSomTUpriDOQX.get('title')
   AKFwENqxJsCbzYtLgeSomTUpriDOQH=AKFwENqxJsCbzYtLgeSomTUpriDOQX.get('pre_title')
   AKFwENqxJsCbzYtLgeSomTUpriDOQj={'mediatype':'tvshow','plot':AKFwENqxJsCbzYtLgeSomTUpriDOQH,}
   AKFwENqxJsCbzYtLgeSomTUpriDOWc={'mode':'CATEGORY_LIST','collectionId':AKFwENqxJsCbzYtLgeSomTUpriDOQX.get('collectionId'),'vType':AKFwENqxJsCbzYtLgeSomTUpriDOQX.get('category'),'page':'1',}
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.add_dir(AKFwENqxJsCbzYtLgeSomTUpriDOWX,sublabel='',img='',infoLabels=AKFwENqxJsCbzYtLgeSomTUpriDOQj,isFolder=AKFwENqxJsCbzYtLgeSomTUpriDOPQ,params=AKFwENqxJsCbzYtLgeSomTUpriDOWc)
  xbmcplugin.endOfDirectory(AKFwENqxJsCbzYtLgeSomTUpriDOuP._addon_handle,cacheToDisc=AKFwENqxJsCbzYtLgeSomTUpriDOPW)
 def dp_Event_GroupList(AKFwENqxJsCbzYtLgeSomTUpriDOuP,args):
  AKFwENqxJsCbzYtLgeSomTUpriDOQW=AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.Get_Event_GroupList()
  for AKFwENqxJsCbzYtLgeSomTUpriDOQX in AKFwENqxJsCbzYtLgeSomTUpriDOQW:
   AKFwENqxJsCbzYtLgeSomTUpriDOWX =AKFwENqxJsCbzYtLgeSomTUpriDOQX.get('title')
   AKFwENqxJsCbzYtLgeSomTUpriDOQH=AKFwENqxJsCbzYtLgeSomTUpriDOQX.get('pre_title')
   AKFwENqxJsCbzYtLgeSomTUpriDOQj={'mediatype':'tvshow','plot':AKFwENqxJsCbzYtLgeSomTUpriDOQH,}
   AKFwENqxJsCbzYtLgeSomTUpriDOWc={'mode':'EVENT_GAMELIST','collectionId':AKFwENqxJsCbzYtLgeSomTUpriDOQX.get('collectionId'),'vType':'LIVE',}
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.add_dir(AKFwENqxJsCbzYtLgeSomTUpriDOWX,sublabel='',img='',infoLabels=AKFwENqxJsCbzYtLgeSomTUpriDOQj,isFolder=AKFwENqxJsCbzYtLgeSomTUpriDOPQ,params=AKFwENqxJsCbzYtLgeSomTUpriDOWc)
  xbmcplugin.endOfDirectory(AKFwENqxJsCbzYtLgeSomTUpriDOuP._addon_handle,cacheToDisc=AKFwENqxJsCbzYtLgeSomTUpriDOPW)
 def dp_Event_GameList(AKFwENqxJsCbzYtLgeSomTUpriDOuP,args):
  AKFwENqxJsCbzYtLgeSomTUpriDOQu =args.get('vType') 
  AKFwENqxJsCbzYtLgeSomTUpriDOQR =args.get('collectionId')
  AKFwENqxJsCbzYtLgeSomTUpriDOQW=AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.Get_Event_GameList(AKFwENqxJsCbzYtLgeSomTUpriDOQR)
  for AKFwENqxJsCbzYtLgeSomTUpriDOQX in AKFwENqxJsCbzYtLgeSomTUpriDOQW:
   AKFwENqxJsCbzYtLgeSomTUpriDOWX =AKFwENqxJsCbzYtLgeSomTUpriDOQX.get('title')
   AKFwENqxJsCbzYtLgeSomTUpriDOPI =AKFwENqxJsCbzYtLgeSomTUpriDOQX.get('id')
   AKFwENqxJsCbzYtLgeSomTUpriDOQk =AKFwENqxJsCbzYtLgeSomTUpriDOQX.get('thumbnail')
   AKFwENqxJsCbzYtLgeSomTUpriDOQc =AKFwENqxJsCbzYtLgeSomTUpriDOQX.get('asis') 
   AKFwENqxJsCbzYtLgeSomTUpriDOQf =AKFwENqxJsCbzYtLgeSomTUpriDOQX.get('addInfo')
   AKFwENqxJsCbzYtLgeSomTUpriDOQB =AKFwENqxJsCbzYtLgeSomTUpriDOQX.get('starttm')
   AKFwENqxJsCbzYtLgeSomTUpriDOQj={'mediatype':'tvshow','title':AKFwENqxJsCbzYtLgeSomTUpriDOWX,'plot':AKFwENqxJsCbzYtLgeSomTUpriDOQf,}
   AKFwENqxJsCbzYtLgeSomTUpriDOWc={'mode':'EVENT_LIST','id':AKFwENqxJsCbzYtLgeSomTUpriDOPI,'asis':AKFwENqxJsCbzYtLgeSomTUpriDOQc,'title':AKFwENqxJsCbzYtLgeSomTUpriDOWX,}
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.add_dir(AKFwENqxJsCbzYtLgeSomTUpriDOWX,sublabel=AKFwENqxJsCbzYtLgeSomTUpriDOQB,img=AKFwENqxJsCbzYtLgeSomTUpriDOQk,infoLabels=AKFwENqxJsCbzYtLgeSomTUpriDOQj,isFolder=AKFwENqxJsCbzYtLgeSomTUpriDOPQ,params=AKFwENqxJsCbzYtLgeSomTUpriDOWc,ContextMenu=AKFwENqxJsCbzYtLgeSomTUpriDOPu)
  xbmcplugin.setContent(AKFwENqxJsCbzYtLgeSomTUpriDOuP._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(AKFwENqxJsCbzYtLgeSomTUpriDOuP._addon_handle,cacheToDisc=AKFwENqxJsCbzYtLgeSomTUpriDOPW)
 def dp_Event_List(AKFwENqxJsCbzYtLgeSomTUpriDOuP,args):
  AKFwENqxJsCbzYtLgeSomTUpriDOQI=args.get('id')
  AKFwENqxJsCbzYtLgeSomTUpriDOQW=AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.Get_Event_List(AKFwENqxJsCbzYtLgeSomTUpriDOQI)
  for AKFwENqxJsCbzYtLgeSomTUpriDOQX in AKFwENqxJsCbzYtLgeSomTUpriDOQW:
   AKFwENqxJsCbzYtLgeSomTUpriDOWX =AKFwENqxJsCbzYtLgeSomTUpriDOQX.get('title')
   AKFwENqxJsCbzYtLgeSomTUpriDOPI =AKFwENqxJsCbzYtLgeSomTUpriDOQX.get('id')
   AKFwENqxJsCbzYtLgeSomTUpriDOQk =AKFwENqxJsCbzYtLgeSomTUpriDOQX.get('thumbnail')
   AKFwENqxJsCbzYtLgeSomTUpriDOQc =AKFwENqxJsCbzYtLgeSomTUpriDOQX.get('asis') 
   AKFwENqxJsCbzYtLgeSomTUpriDOQM =AKFwENqxJsCbzYtLgeSomTUpriDOQX.get('duration')
   AKFwENqxJsCbzYtLgeSomTUpriDOQB =AKFwENqxJsCbzYtLgeSomTUpriDOQX.get('starttm')
   AKFwENqxJsCbzYtLgeSomTUpriDOQj={'mediatype':'episode','title':AKFwENqxJsCbzYtLgeSomTUpriDOWX,'plot':AKFwENqxJsCbzYtLgeSomTUpriDOQc,'duration':AKFwENqxJsCbzYtLgeSomTUpriDOQM,}
   AKFwENqxJsCbzYtLgeSomTUpriDOWc={'mode':AKFwENqxJsCbzYtLgeSomTUpriDOQc,'id':AKFwENqxJsCbzYtLgeSomTUpriDOPI,'asis':AKFwENqxJsCbzYtLgeSomTUpriDOQc,'title':AKFwENqxJsCbzYtLgeSomTUpriDOWX,}
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.add_dir(AKFwENqxJsCbzYtLgeSomTUpriDOWX,sublabel=AKFwENqxJsCbzYtLgeSomTUpriDOQB,img=AKFwENqxJsCbzYtLgeSomTUpriDOQk,infoLabels=AKFwENqxJsCbzYtLgeSomTUpriDOQj,isFolder=AKFwENqxJsCbzYtLgeSomTUpriDOPW,params=AKFwENqxJsCbzYtLgeSomTUpriDOWc,ContextMenu=AKFwENqxJsCbzYtLgeSomTUpriDOPu)
  xbmcplugin.setContent(AKFwENqxJsCbzYtLgeSomTUpriDOuP._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(AKFwENqxJsCbzYtLgeSomTUpriDOuP._addon_handle,cacheToDisc=AKFwENqxJsCbzYtLgeSomTUpriDOPW)
 def dp_Category_List(AKFwENqxJsCbzYtLgeSomTUpriDOuP,args):
  AKFwENqxJsCbzYtLgeSomTUpriDOQu =args.get('vType') 
  AKFwENqxJsCbzYtLgeSomTUpriDOQR =args.get('collectionId')
  AKFwENqxJsCbzYtLgeSomTUpriDOQv =AKFwENqxJsCbzYtLgeSomTUpriDOPR(args.get('page'))
  AKFwENqxJsCbzYtLgeSomTUpriDOQW,AKFwENqxJsCbzYtLgeSomTUpriDOQl=AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.Get_Category_List(AKFwENqxJsCbzYtLgeSomTUpriDOQu,AKFwENqxJsCbzYtLgeSomTUpriDOQR,AKFwENqxJsCbzYtLgeSomTUpriDOQv)
  for AKFwENqxJsCbzYtLgeSomTUpriDOQX in AKFwENqxJsCbzYtLgeSomTUpriDOQW:
   AKFwENqxJsCbzYtLgeSomTUpriDOWX =AKFwENqxJsCbzYtLgeSomTUpriDOQX.get('title')
   AKFwENqxJsCbzYtLgeSomTUpriDOPI =AKFwENqxJsCbzYtLgeSomTUpriDOQX.get('id')
   AKFwENqxJsCbzYtLgeSomTUpriDOQk =AKFwENqxJsCbzYtLgeSomTUpriDOQX.get('thumbnail')
   AKFwENqxJsCbzYtLgeSomTUpriDOQG =AKFwENqxJsCbzYtLgeSomTUpriDOQX.get('mpaa')
   AKFwENqxJsCbzYtLgeSomTUpriDOQM =AKFwENqxJsCbzYtLgeSomTUpriDOQX.get('duration')
   AKFwENqxJsCbzYtLgeSomTUpriDOQc =AKFwENqxJsCbzYtLgeSomTUpriDOQX.get('asis')
   AKFwENqxJsCbzYtLgeSomTUpriDOQV =AKFwENqxJsCbzYtLgeSomTUpriDOQX.get('badge')
   AKFwENqxJsCbzYtLgeSomTUpriDOQh =AKFwENqxJsCbzYtLgeSomTUpriDOQX.get('year')
   AKFwENqxJsCbzYtLgeSomTUpriDOQy=AKFwENqxJsCbzYtLgeSomTUpriDOQX.get('seasonList')
   AKFwENqxJsCbzYtLgeSomTUpriDOQn =AKFwENqxJsCbzYtLgeSomTUpriDOQX.get('genreList')
   if AKFwENqxJsCbzYtLgeSomTUpriDOQc in['TVSHOW','EDUCATION']: 
    AKFwENqxJsCbzYtLgeSomTUpriDOQa ='SEASON_LIST'
    AKFwENqxJsCbzYtLgeSomTUpriDOQj={'mediatype':'tvshow','title':AKFwENqxJsCbzYtLgeSomTUpriDOWX,'mpaa':AKFwENqxJsCbzYtLgeSomTUpriDOQG,'genre':AKFwENqxJsCbzYtLgeSomTUpriDOQn,'year':AKFwENqxJsCbzYtLgeSomTUpriDOQh,'plot':'Year : %s\nSeason : %s'%(AKFwENqxJsCbzYtLgeSomTUpriDOQh,AKFwENqxJsCbzYtLgeSomTUpriDOQy),}
    AKFwENqxJsCbzYtLgeSomTUpriDOWf =AKFwENqxJsCbzYtLgeSomTUpriDOPQ
   else:
    AKFwENqxJsCbzYtLgeSomTUpriDOQa ='MOVIE'
    AKFwENqxJsCbzYtLgeSomTUpriDOQj={'mediatype':'movie','title':AKFwENqxJsCbzYtLgeSomTUpriDOWX,'mpaa':AKFwENqxJsCbzYtLgeSomTUpriDOQG,'genre':AKFwENqxJsCbzYtLgeSomTUpriDOQn,'duration':AKFwENqxJsCbzYtLgeSomTUpriDOQM,'year':AKFwENqxJsCbzYtLgeSomTUpriDOQh,'plot':'(%s)'%(AKFwENqxJsCbzYtLgeSomTUpriDOQG),}
    AKFwENqxJsCbzYtLgeSomTUpriDOWf =AKFwENqxJsCbzYtLgeSomTUpriDOPW
    AKFwENqxJsCbzYtLgeSomTUpriDOWX +=' (%s)'%(AKFwENqxJsCbzYtLgeSomTUpriDOPB(AKFwENqxJsCbzYtLgeSomTUpriDOQh))
   AKFwENqxJsCbzYtLgeSomTUpriDOWc={'mode':AKFwENqxJsCbzYtLgeSomTUpriDOQa,'id':AKFwENqxJsCbzYtLgeSomTUpriDOPI,'asis':AKFwENqxJsCbzYtLgeSomTUpriDOQc,'seasonList':AKFwENqxJsCbzYtLgeSomTUpriDOQy,'title':AKFwENqxJsCbzYtLgeSomTUpriDOWX,'thumbnail':AKFwENqxJsCbzYtLgeSomTUpriDOQk,'year':AKFwENqxJsCbzYtLgeSomTUpriDOQh,}
   if AKFwENqxJsCbzYtLgeSomTUpriDOuP.get_settings_makebookmark():
    AKFwENqxJsCbzYtLgeSomTUpriDOQd={'videoid':AKFwENqxJsCbzYtLgeSomTUpriDOPI,'vidtype':'movie' if AKFwENqxJsCbzYtLgeSomTUpriDOQu=='MOVIES' else 'tvshow','vtitle':AKFwENqxJsCbzYtLgeSomTUpriDOWX,'vsubtitle':'',}
    AKFwENqxJsCbzYtLgeSomTUpriDOXu=json.dumps(AKFwENqxJsCbzYtLgeSomTUpriDOQd)
    AKFwENqxJsCbzYtLgeSomTUpriDOXu=urllib.parse.quote(AKFwENqxJsCbzYtLgeSomTUpriDOXu)
    AKFwENqxJsCbzYtLgeSomTUpriDOXW='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(AKFwENqxJsCbzYtLgeSomTUpriDOXu)
    AKFwENqxJsCbzYtLgeSomTUpriDOXQ=[('(통합) 찜 영상에 추가',AKFwENqxJsCbzYtLgeSomTUpriDOXW)]
   else:
    AKFwENqxJsCbzYtLgeSomTUpriDOXQ=AKFwENqxJsCbzYtLgeSomTUpriDOPu
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.add_dir(AKFwENqxJsCbzYtLgeSomTUpriDOWX,sublabel=AKFwENqxJsCbzYtLgeSomTUpriDOQV,img=AKFwENqxJsCbzYtLgeSomTUpriDOQk,infoLabels=AKFwENqxJsCbzYtLgeSomTUpriDOQj,isFolder=AKFwENqxJsCbzYtLgeSomTUpriDOWf,params=AKFwENqxJsCbzYtLgeSomTUpriDOWc,ContextMenu=AKFwENqxJsCbzYtLgeSomTUpriDOXQ)
  if AKFwENqxJsCbzYtLgeSomTUpriDOQl:
   AKFwENqxJsCbzYtLgeSomTUpriDOWc['mode'] ='CATEGORY_LIST' 
   AKFwENqxJsCbzYtLgeSomTUpriDOWc['collectionId']=AKFwENqxJsCbzYtLgeSomTUpriDOQR 
   AKFwENqxJsCbzYtLgeSomTUpriDOWc['vType'] =AKFwENqxJsCbzYtLgeSomTUpriDOQu 
   AKFwENqxJsCbzYtLgeSomTUpriDOWc['page'] =AKFwENqxJsCbzYtLgeSomTUpriDOPB(AKFwENqxJsCbzYtLgeSomTUpriDOQv+1)
   AKFwENqxJsCbzYtLgeSomTUpriDOWX='[B]%s >>[/B]'%'다음 페이지'
   AKFwENqxJsCbzYtLgeSomTUpriDOXH=AKFwENqxJsCbzYtLgeSomTUpriDOPB(AKFwENqxJsCbzYtLgeSomTUpriDOQv+1)
   AKFwENqxJsCbzYtLgeSomTUpriDOWk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.add_dir(AKFwENqxJsCbzYtLgeSomTUpriDOWX,sublabel=AKFwENqxJsCbzYtLgeSomTUpriDOXH,img=AKFwENqxJsCbzYtLgeSomTUpriDOWk,infoLabels=AKFwENqxJsCbzYtLgeSomTUpriDOPu,isFolder=AKFwENqxJsCbzYtLgeSomTUpriDOPQ,params=AKFwENqxJsCbzYtLgeSomTUpriDOWc)
  if AKFwENqxJsCbzYtLgeSomTUpriDOQu=='TVSHOWS':xbmcplugin.setContent(AKFwENqxJsCbzYtLgeSomTUpriDOuP._addon_handle,'tvshows')
  else:xbmcplugin.setContent(AKFwENqxJsCbzYtLgeSomTUpriDOuP._addon_handle,'movies')
  xbmcplugin.endOfDirectory(AKFwENqxJsCbzYtLgeSomTUpriDOuP._addon_handle,cacheToDisc=AKFwENqxJsCbzYtLgeSomTUpriDOPW)
 def dp_Season_List(AKFwENqxJsCbzYtLgeSomTUpriDOuP,args):
  AKFwENqxJsCbzYtLgeSomTUpriDOXj =args.get('title')
  AKFwENqxJsCbzYtLgeSomTUpriDOXP =args.get('id')
  AKFwENqxJsCbzYtLgeSomTUpriDOQc =args.get('asis')
  AKFwENqxJsCbzYtLgeSomTUpriDOQy =args.get('seasonList')
  AKFwENqxJsCbzYtLgeSomTUpriDOQk =args.get('thumbnail')
  AKFwENqxJsCbzYtLgeSomTUpriDOQh =args.get('year')
  if AKFwENqxJsCbzYtLgeSomTUpriDOQy in['',AKFwENqxJsCbzYtLgeSomTUpriDOPu]:
   AKFwENqxJsCbzYtLgeSomTUpriDOQy=AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.Get_vInfo(AKFwENqxJsCbzYtLgeSomTUpriDOXP).get('seasonList')
  if AKFwENqxJsCbzYtLgeSomTUpriDOPM(AKFwENqxJsCbzYtLgeSomTUpriDOQy.split(','))>1:
   for AKFwENqxJsCbzYtLgeSomTUpriDOXR in AKFwENqxJsCbzYtLgeSomTUpriDOQy.split(','):
    AKFwENqxJsCbzYtLgeSomTUpriDOWX='시즌 '+AKFwENqxJsCbzYtLgeSomTUpriDOXR
    AKFwENqxJsCbzYtLgeSomTUpriDOQj={'mediatype':'tvshow','plot':'%s (%s)'%(AKFwENqxJsCbzYtLgeSomTUpriDOXj,AKFwENqxJsCbzYtLgeSomTUpriDOQh),}
    AKFwENqxJsCbzYtLgeSomTUpriDOWc={'mode':'EPISODE_LIST','programid':AKFwENqxJsCbzYtLgeSomTUpriDOXP,'programnm':AKFwENqxJsCbzYtLgeSomTUpriDOXj,'season':AKFwENqxJsCbzYtLgeSomTUpriDOXR,'asis':AKFwENqxJsCbzYtLgeSomTUpriDOQc,'programimg':AKFwENqxJsCbzYtLgeSomTUpriDOQk,}
    AKFwENqxJsCbzYtLgeSomTUpriDOXk=AKFwENqxJsCbzYtLgeSomTUpriDOQk.replace('\'','\"')
    AKFwENqxJsCbzYtLgeSomTUpriDOXk=json.loads(AKFwENqxJsCbzYtLgeSomTUpriDOXk)
    AKFwENqxJsCbzYtLgeSomTUpriDOuP.add_dir(AKFwENqxJsCbzYtLgeSomTUpriDOWX,sublabel='',img=AKFwENqxJsCbzYtLgeSomTUpriDOXk,infoLabels=AKFwENqxJsCbzYtLgeSomTUpriDOQj,isFolder=AKFwENqxJsCbzYtLgeSomTUpriDOPQ,params=AKFwENqxJsCbzYtLgeSomTUpriDOWc)
   xbmcplugin.setContent(AKFwENqxJsCbzYtLgeSomTUpriDOuP._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(AKFwENqxJsCbzYtLgeSomTUpriDOuP._addon_handle,cacheToDisc=AKFwENqxJsCbzYtLgeSomTUpriDOPW)
  else:
   AKFwENqxJsCbzYtLgeSomTUpriDOXc={'programid':AKFwENqxJsCbzYtLgeSomTUpriDOXP,'programnm':AKFwENqxJsCbzYtLgeSomTUpriDOXj,'season':AKFwENqxJsCbzYtLgeSomTUpriDOQy,'programimg':AKFwENqxJsCbzYtLgeSomTUpriDOQk,}
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.dp_Episode_List(AKFwENqxJsCbzYtLgeSomTUpriDOXc)
 def dp_Episode_List(AKFwENqxJsCbzYtLgeSomTUpriDOuP,args):
  AKFwENqxJsCbzYtLgeSomTUpriDOXP =args.get('programid')
  AKFwENqxJsCbzYtLgeSomTUpriDOXj =args.get('programnm')
  AKFwENqxJsCbzYtLgeSomTUpriDOXf =args.get('season')
  AKFwENqxJsCbzYtLgeSomTUpriDOXB =args.get('programimg')
  AKFwENqxJsCbzYtLgeSomTUpriDOXI=AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.Get_Episode_List(AKFwENqxJsCbzYtLgeSomTUpriDOXP,AKFwENqxJsCbzYtLgeSomTUpriDOXf)
  for AKFwENqxJsCbzYtLgeSomTUpriDOXR in AKFwENqxJsCbzYtLgeSomTUpriDOXI:
   AKFwENqxJsCbzYtLgeSomTUpriDOXM =AKFwENqxJsCbzYtLgeSomTUpriDOXR.get('title')
   AKFwENqxJsCbzYtLgeSomTUpriDOXv =AKFwENqxJsCbzYtLgeSomTUpriDOXR.get('id')
   AKFwENqxJsCbzYtLgeSomTUpriDOQc =AKFwENqxJsCbzYtLgeSomTUpriDOXR.get('asis')
   AKFwENqxJsCbzYtLgeSomTUpriDOQk =AKFwENqxJsCbzYtLgeSomTUpriDOXR.get('thumbnail')
   AKFwENqxJsCbzYtLgeSomTUpriDOQG =AKFwENqxJsCbzYtLgeSomTUpriDOXR.get('mpaa')
   AKFwENqxJsCbzYtLgeSomTUpriDOQM =AKFwENqxJsCbzYtLgeSomTUpriDOXR.get('duration')
   AKFwENqxJsCbzYtLgeSomTUpriDOQh =AKFwENqxJsCbzYtLgeSomTUpriDOXR.get('year')
   AKFwENqxJsCbzYtLgeSomTUpriDOXl =AKFwENqxJsCbzYtLgeSomTUpriDOXR.get('episode')
   AKFwENqxJsCbzYtLgeSomTUpriDOQn =AKFwENqxJsCbzYtLgeSomTUpriDOXR.get('genreList')
   AKFwENqxJsCbzYtLgeSomTUpriDOXG =AKFwENqxJsCbzYtLgeSomTUpriDOXR.get('desc')
   AKFwENqxJsCbzYtLgeSomTUpriDOXV ='%sx%s'%(AKFwENqxJsCbzYtLgeSomTUpriDOXf,AKFwENqxJsCbzYtLgeSomTUpriDOXl)
   AKFwENqxJsCbzYtLgeSomTUpriDOWX ='%s. %s'%(AKFwENqxJsCbzYtLgeSomTUpriDOXV,AKFwENqxJsCbzYtLgeSomTUpriDOXM)
   AKFwENqxJsCbzYtLgeSomTUpriDOQj={'mediatype':'episode','mpaa':AKFwENqxJsCbzYtLgeSomTUpriDOQG,'genre':AKFwENqxJsCbzYtLgeSomTUpriDOQn,'duration':AKFwENqxJsCbzYtLgeSomTUpriDOQM,'year':AKFwENqxJsCbzYtLgeSomTUpriDOQh,'plot':'%s (%s)\n\n%s'%(AKFwENqxJsCbzYtLgeSomTUpriDOXj,AKFwENqxJsCbzYtLgeSomTUpriDOXV,AKFwENqxJsCbzYtLgeSomTUpriDOXG),}
   AKFwENqxJsCbzYtLgeSomTUpriDOWc={'mode':'VOD','programid':AKFwENqxJsCbzYtLgeSomTUpriDOXP,'programnm':AKFwENqxJsCbzYtLgeSomTUpriDOXj,'title':AKFwENqxJsCbzYtLgeSomTUpriDOWX,'season':AKFwENqxJsCbzYtLgeSomTUpriDOXf,'id':AKFwENqxJsCbzYtLgeSomTUpriDOXv,'asis':AKFwENqxJsCbzYtLgeSomTUpriDOQc,'thumbnail':AKFwENqxJsCbzYtLgeSomTUpriDOQk,'programimg':AKFwENqxJsCbzYtLgeSomTUpriDOXB,}
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.add_dir(AKFwENqxJsCbzYtLgeSomTUpriDOWX,sublabel='',img=AKFwENqxJsCbzYtLgeSomTUpriDOQk,infoLabels=AKFwENqxJsCbzYtLgeSomTUpriDOQj,isFolder=AKFwENqxJsCbzYtLgeSomTUpriDOPW,params=AKFwENqxJsCbzYtLgeSomTUpriDOWc)
  xbmcplugin.setContent(AKFwENqxJsCbzYtLgeSomTUpriDOuP._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(AKFwENqxJsCbzYtLgeSomTUpriDOuP._addon_handle,cacheToDisc=AKFwENqxJsCbzYtLgeSomTUpriDOPW)
 def play_VIDEO(AKFwENqxJsCbzYtLgeSomTUpriDOuP,args):
  AKFwENqxJsCbzYtLgeSomTUpriDOXh =args.get('id')
  AKFwENqxJsCbzYtLgeSomTUpriDOQc =args.get('asis')
  if AKFwENqxJsCbzYtLgeSomTUpriDOQc in['HIGHLIGHT']:
   AKFwENqxJsCbzYtLgeSomTUpriDOXy,AKFwENqxJsCbzYtLgeSomTUpriDOXn=AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.GetEventURL(AKFwENqxJsCbzYtLgeSomTUpriDOXh,AKFwENqxJsCbzYtLgeSomTUpriDOQc)
  elif AKFwENqxJsCbzYtLgeSomTUpriDOQc in['LIVE']:
   AKFwENqxJsCbzYtLgeSomTUpriDOXy,AKFwENqxJsCbzYtLgeSomTUpriDOXn=AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.GetEventURL_Live(AKFwENqxJsCbzYtLgeSomTUpriDOXh,AKFwENqxJsCbzYtLgeSomTUpriDOQc)
  else:
   AKFwENqxJsCbzYtLgeSomTUpriDOXy,AKFwENqxJsCbzYtLgeSomTUpriDOXn=AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.GetBroadURL(AKFwENqxJsCbzYtLgeSomTUpriDOXh)
  AKFwENqxJsCbzYtLgeSomTUpriDOuP.addon_log('asis, url : %s - %s - %s'%(AKFwENqxJsCbzYtLgeSomTUpriDOQc,AKFwENqxJsCbzYtLgeSomTUpriDOXh,AKFwENqxJsCbzYtLgeSomTUpriDOXy))
  if AKFwENqxJsCbzYtLgeSomTUpriDOXy=='':
   if AKFwENqxJsCbzYtLgeSomTUpriDOXn=='':
    AKFwENqxJsCbzYtLgeSomTUpriDOuP.addon_noti(__language__(30907).encode('utf8'))
   else:
    AKFwENqxJsCbzYtLgeSomTUpriDOuP.addon_log('drm_license_1 : %s'%(AKFwENqxJsCbzYtLgeSomTUpriDOXn))
    AKFwENqxJsCbzYtLgeSomTUpriDOuP.addon_noti(AKFwENqxJsCbzYtLgeSomTUpriDOXn)
   return
  else:
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.addon_log('drm_license : %s'%(AKFwENqxJsCbzYtLgeSomTUpriDOXn))
  AKFwENqxJsCbzYtLgeSomTUpriDOXa='PCID=%s;token=%s;member_srl=%s;NEXT_LOCALE=%s;session_web_id=%s;device_id=%s'%(AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.CP['COOKIES']['PCID'],AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.CP['COOKIES']['token'],AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.CP['COOKIES']['member_srl'],AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.CP['COOKIES']['NEXT_LOCALE'],AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.CP['COOKIES']['session_web_id'],AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.CP['COOKIES']['device_id'],)
  if AKFwENqxJsCbzYtLgeSomTUpriDOQc in['EPISODE']:
   AKFwENqxJsCbzYtLgeSomTUpriDOXd='https://www.coupangplay.com/play/{}/episode?titleId={}&type=EPISODE&sourceType=page_discover_title_detail%3Apage_discover_feed'.format(AKFwENqxJsCbzYtLgeSomTUpriDOXh,AKFwENqxJsCbzYtLgeSomTUpriDOXh)
  elif AKFwENqxJsCbzYtLgeSomTUpriDOQc in['MOVIE']:
   AKFwENqxJsCbzYtLgeSomTUpriDOXd='https://www.coupangplay.com/play/{}/movie?sourceType=page_discover_feed'.format(AKFwENqxJsCbzYtLgeSomTUpriDOXh)
  else:
   AKFwENqxJsCbzYtLgeSomTUpriDOXd='https://www.coupangplay.com/play/'+AKFwENqxJsCbzYtLgeSomTUpriDOXh 
  AKFwENqxJsCbzYtLgeSomTUpriDOHu,AKFwENqxJsCbzYtLgeSomTUpriDOHW,AKFwENqxJsCbzYtLgeSomTUpriDOHQ=AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.Make_authHeader()
  AKFwENqxJsCbzYtLgeSomTUpriDOHX=AKFwENqxJsCbzYtLgeSomTUpriDOXy 
  AKFwENqxJsCbzYtLgeSomTUpriDOuP.addon_log('tobe, surl : %s'%(AKFwENqxJsCbzYtLgeSomTUpriDOHX))
  AKFwENqxJsCbzYtLgeSomTUpriDOHj=xbmcgui.ListItem(path=AKFwENqxJsCbzYtLgeSomTUpriDOHX)
  AKFwENqxJsCbzYtLgeSomTUpriDOHP=AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.Get_Url_PostFix(AKFwENqxJsCbzYtLgeSomTUpriDOXy) 
  AKFwENqxJsCbzYtLgeSomTUpriDOuP.addon_log('post_fix : '+AKFwENqxJsCbzYtLgeSomTUpriDOHP)
  if AKFwENqxJsCbzYtLgeSomTUpriDOHP=='m3u8':
   AKFwENqxJsCbzYtLgeSomTUpriDOHR ='hls' 
  else:
   AKFwENqxJsCbzYtLgeSomTUpriDOHR ='mpd' 
  if AKFwENqxJsCbzYtLgeSomTUpriDOXn:
   AKFwENqxJsCbzYtLgeSomTUpriDOHk =AKFwENqxJsCbzYtLgeSomTUpriDOXn 
   AKFwENqxJsCbzYtLgeSomTUpriDOHc ='com.widevine.alpha'
   AKFwENqxJsCbzYtLgeSomTUpriDOHf={'traceparent':AKFwENqxJsCbzYtLgeSomTUpriDOHu,'tracestate':AKFwENqxJsCbzYtLgeSomTUpriDOHW,'newrelic':AKFwENqxJsCbzYtLgeSomTUpriDOHQ,'User-Agent':AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.USER_AGENT,'Referer':AKFwENqxJsCbzYtLgeSomTUpriDOXd,'Cookie':AKFwENqxJsCbzYtLgeSomTUpriDOXa,}
   AKFwENqxJsCbzYtLgeSomTUpriDOHB=AKFwENqxJsCbzYtLgeSomTUpriDOHk+'|'+urllib.parse.urlencode(AKFwENqxJsCbzYtLgeSomTUpriDOHf)+'|R{SSM}|'
   AKFwENqxJsCbzYtLgeSomTUpriDOHj.setProperty('inputstream','inputstream.adaptive')
   AKFwENqxJsCbzYtLgeSomTUpriDOHj.setProperty('inputstream.adaptive.manifest_type',AKFwENqxJsCbzYtLgeSomTUpriDOHR)
   AKFwENqxJsCbzYtLgeSomTUpriDOHj.setProperty('inputstream.adaptive.license_type',AKFwENqxJsCbzYtLgeSomTUpriDOHc)
   AKFwENqxJsCbzYtLgeSomTUpriDOHj.setProperty('inputstream.adaptive.license_key',AKFwENqxJsCbzYtLgeSomTUpriDOHB)
   AKFwENqxJsCbzYtLgeSomTUpriDOHj.setProperty('inputstream.adaptive.stream_headers','User-Agent={}&Cookie={}&Referer={}&traceparent={}&tracestate={}&newrelic={}'.format(AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.USER_AGENT,AKFwENqxJsCbzYtLgeSomTUpriDOXa,AKFwENqxJsCbzYtLgeSomTUpriDOXd,AKFwENqxJsCbzYtLgeSomTUpriDOHu,AKFwENqxJsCbzYtLgeSomTUpriDOHW,AKFwENqxJsCbzYtLgeSomTUpriDOHQ))
   AKFwENqxJsCbzYtLgeSomTUpriDOHj.setMimeType('application/dash+xml')
   AKFwENqxJsCbzYtLgeSomTUpriDOHj.setContentLookup(AKFwENqxJsCbzYtLgeSomTUpriDOPW)
  else:
   AKFwENqxJsCbzYtLgeSomTUpriDOHj.setContentLookup(AKFwENqxJsCbzYtLgeSomTUpriDOPW)
   AKFwENqxJsCbzYtLgeSomTUpriDOHj.setMimeType('application/x-mpegURL')
   AKFwENqxJsCbzYtLgeSomTUpriDOHj.setProperty('inputstream','inputstream.adaptive')
   AKFwENqxJsCbzYtLgeSomTUpriDOHj.setProperty('inputstream.adaptive.manifest_type',AKFwENqxJsCbzYtLgeSomTUpriDOHR)
   AKFwENqxJsCbzYtLgeSomTUpriDOHj.setProperty('inputstream.adaptive.stream_headers','User-Agent={}&Cookie={}&Referer={}&traceparent={}&tracestate={}&newrelic={}'.format(AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.USER_AGENT,AKFwENqxJsCbzYtLgeSomTUpriDOXa,AKFwENqxJsCbzYtLgeSomTUpriDOXd,AKFwENqxJsCbzYtLgeSomTUpriDOHu,AKFwENqxJsCbzYtLgeSomTUpriDOHW,AKFwENqxJsCbzYtLgeSomTUpriDOHQ))
  xbmcplugin.setResolvedUrl(AKFwENqxJsCbzYtLgeSomTUpriDOuP._addon_handle,AKFwENqxJsCbzYtLgeSomTUpriDOPQ,AKFwENqxJsCbzYtLgeSomTUpriDOHj)
  try:
   if AKFwENqxJsCbzYtLgeSomTUpriDOQc=='MOVIE':
    AKFwENqxJsCbzYtLgeSomTUpriDOHI='movie'
    AKFwENqxJsCbzYtLgeSomTUpriDOWc={'code':AKFwENqxJsCbzYtLgeSomTUpriDOXh,'asis':AKFwENqxJsCbzYtLgeSomTUpriDOQc,'title':args.get('title'),'img':args.get('thumbnail'),}
    AKFwENqxJsCbzYtLgeSomTUpriDOuP.Save_Watched_List(AKFwENqxJsCbzYtLgeSomTUpriDOHI,AKFwENqxJsCbzYtLgeSomTUpriDOWc)
   elif AKFwENqxJsCbzYtLgeSomTUpriDOQc=='EPISODE':
    AKFwENqxJsCbzYtLgeSomTUpriDOHI='tvshow'
    AKFwENqxJsCbzYtLgeSomTUpriDOWc={'code':args.get('programid'),'asis':AKFwENqxJsCbzYtLgeSomTUpriDOQc,'title':'%s <%s>'%(args.get('title'),args.get('programnm')),'img':args.get('programimg'),}
    AKFwENqxJsCbzYtLgeSomTUpriDOuP.Save_Watched_List(AKFwENqxJsCbzYtLgeSomTUpriDOHI,AKFwENqxJsCbzYtLgeSomTUpriDOWc)
  except:
   AKFwENqxJsCbzYtLgeSomTUpriDOPu
 def dp_Global_Search(AKFwENqxJsCbzYtLgeSomTUpriDOuP,args):
  AKFwENqxJsCbzYtLgeSomTUpriDOQa=args.get('mode')
  if AKFwENqxJsCbzYtLgeSomTUpriDOQa=='TOTAL_SEARCH':
   AKFwENqxJsCbzYtLgeSomTUpriDOHM='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   AKFwENqxJsCbzYtLgeSomTUpriDOHM='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(AKFwENqxJsCbzYtLgeSomTUpriDOHM)
 def dp_Bookmark_Menu(AKFwENqxJsCbzYtLgeSomTUpriDOuP,args):
  AKFwENqxJsCbzYtLgeSomTUpriDOHM='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(AKFwENqxJsCbzYtLgeSomTUpriDOHM)
 def dp_Search_List(AKFwENqxJsCbzYtLgeSomTUpriDOuP,args):
  AKFwENqxJsCbzYtLgeSomTUpriDOQv =AKFwENqxJsCbzYtLgeSomTUpriDOPR(args.get('page'))
  if 'search_key' in args:
   AKFwENqxJsCbzYtLgeSomTUpriDOHv=args.get('search_key')
  else:
   AKFwENqxJsCbzYtLgeSomTUpriDOHv=AKFwENqxJsCbzYtLgeSomTUpriDOuP.get_keyboard_input(__language__(30908).encode('utf-8'))
   if not AKFwENqxJsCbzYtLgeSomTUpriDOHv:
    return
  AKFwENqxJsCbzYtLgeSomTUpriDOHl,AKFwENqxJsCbzYtLgeSomTUpriDOQl=AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.Get_Search_List(AKFwENqxJsCbzYtLgeSomTUpriDOHv,AKFwENqxJsCbzYtLgeSomTUpriDOQv)
  for AKFwENqxJsCbzYtLgeSomTUpriDOHG in AKFwENqxJsCbzYtLgeSomTUpriDOHl:
   AKFwENqxJsCbzYtLgeSomTUpriDOPI =AKFwENqxJsCbzYtLgeSomTUpriDOHG.get('id')
   AKFwENqxJsCbzYtLgeSomTUpriDOWX =AKFwENqxJsCbzYtLgeSomTUpriDOHG.get('title')
   AKFwENqxJsCbzYtLgeSomTUpriDOQc =AKFwENqxJsCbzYtLgeSomTUpriDOHG.get('asis')
   AKFwENqxJsCbzYtLgeSomTUpriDOQk =AKFwENqxJsCbzYtLgeSomTUpriDOHG.get('thumbnail')
   AKFwENqxJsCbzYtLgeSomTUpriDOQG =AKFwENqxJsCbzYtLgeSomTUpriDOHG.get('mpaa')
   AKFwENqxJsCbzYtLgeSomTUpriDOQh =AKFwENqxJsCbzYtLgeSomTUpriDOHG.get('year')
   AKFwENqxJsCbzYtLgeSomTUpriDOQM =AKFwENqxJsCbzYtLgeSomTUpriDOHG.get('duration')
   AKFwENqxJsCbzYtLgeSomTUpriDOQV =AKFwENqxJsCbzYtLgeSomTUpriDOHG.get('badge')
   if AKFwENqxJsCbzYtLgeSomTUpriDOQc=='TVSHOW': 
    AKFwENqxJsCbzYtLgeSomTUpriDOQa ='SEASON_LIST'
    AKFwENqxJsCbzYtLgeSomTUpriDOQj={'mediatype':'tvshow','title':AKFwENqxJsCbzYtLgeSomTUpriDOWX,'mpaa':AKFwENqxJsCbzYtLgeSomTUpriDOQG,'year':AKFwENqxJsCbzYtLgeSomTUpriDOQh,'plot':'Year : %s'%(AKFwENqxJsCbzYtLgeSomTUpriDOQh),}
    AKFwENqxJsCbzYtLgeSomTUpriDOWf =AKFwENqxJsCbzYtLgeSomTUpriDOPQ
   elif AKFwENqxJsCbzYtLgeSomTUpriDOQc=='MOVIE':
    AKFwENqxJsCbzYtLgeSomTUpriDOQa ='MOVIE'
    AKFwENqxJsCbzYtLgeSomTUpriDOQj={'mediatype':'movie','title':AKFwENqxJsCbzYtLgeSomTUpriDOWX,'mpaa':AKFwENqxJsCbzYtLgeSomTUpriDOQG,'duration':AKFwENqxJsCbzYtLgeSomTUpriDOQM,'year':AKFwENqxJsCbzYtLgeSomTUpriDOQh,'plot':'(%s)'%(AKFwENqxJsCbzYtLgeSomTUpriDOQG),}
    AKFwENqxJsCbzYtLgeSomTUpriDOWf =AKFwENqxJsCbzYtLgeSomTUpriDOPW
    AKFwENqxJsCbzYtLgeSomTUpriDOWX +=' (%s)'%(AKFwENqxJsCbzYtLgeSomTUpriDOPB(AKFwENqxJsCbzYtLgeSomTUpriDOQh))
   elif AKFwENqxJsCbzYtLgeSomTUpriDOQc=='HIGHLIGHT':
    AKFwENqxJsCbzYtLgeSomTUpriDOQa ='HIGHLIGHT'
    AKFwENqxJsCbzYtLgeSomTUpriDOQj={'mediatype':'episode','title':AKFwENqxJsCbzYtLgeSomTUpriDOWX,'duration':AKFwENqxJsCbzYtLgeSomTUpriDOQM,'plot':AKFwENqxJsCbzYtLgeSomTUpriDOQa,}
    AKFwENqxJsCbzYtLgeSomTUpriDOWf =AKFwENqxJsCbzYtLgeSomTUpriDOPW
   elif AKFwENqxJsCbzYtLgeSomTUpriDOQc=='LIVE':
    AKFwENqxJsCbzYtLgeSomTUpriDOQa ='LIVE'
    AKFwENqxJsCbzYtLgeSomTUpriDOQj={'mediatype':'episode','title':AKFwENqxJsCbzYtLgeSomTUpriDOWX,'plot':AKFwENqxJsCbzYtLgeSomTUpriDOQa,}
    AKFwENqxJsCbzYtLgeSomTUpriDOWf =AKFwENqxJsCbzYtLgeSomTUpriDOPW
   AKFwENqxJsCbzYtLgeSomTUpriDOWc={'mode':AKFwENqxJsCbzYtLgeSomTUpriDOQa,'id':AKFwENqxJsCbzYtLgeSomTUpriDOPI,'asis':AKFwENqxJsCbzYtLgeSomTUpriDOQc,'seasonList':'','title':AKFwENqxJsCbzYtLgeSomTUpriDOWX,'thumbnail':json.dumps(AKFwENqxJsCbzYtLgeSomTUpriDOQk,separators=(',',':')),'year':AKFwENqxJsCbzYtLgeSomTUpriDOQh,}
   if AKFwENqxJsCbzYtLgeSomTUpriDOuP.get_settings_makebookmark()and AKFwENqxJsCbzYtLgeSomTUpriDOQc not in['HIGHLIGHT','']:
    AKFwENqxJsCbzYtLgeSomTUpriDOQd={'videoid':AKFwENqxJsCbzYtLgeSomTUpriDOPI,'vidtype':'movie' if AKFwENqxJsCbzYtLgeSomTUpriDOQc=='MOVIE' else 'tvshow','vtitle':AKFwENqxJsCbzYtLgeSomTUpriDOWX,'vsubtitle':'',}
    AKFwENqxJsCbzYtLgeSomTUpriDOXu=json.dumps(AKFwENqxJsCbzYtLgeSomTUpriDOQd)
    AKFwENqxJsCbzYtLgeSomTUpriDOXu=urllib.parse.quote(AKFwENqxJsCbzYtLgeSomTUpriDOXu)
    AKFwENqxJsCbzYtLgeSomTUpriDOXW='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(AKFwENqxJsCbzYtLgeSomTUpriDOXu)
    AKFwENqxJsCbzYtLgeSomTUpriDOXQ=[('(통합) 찜 영상에 추가',AKFwENqxJsCbzYtLgeSomTUpriDOXW)]
   else:
    AKFwENqxJsCbzYtLgeSomTUpriDOXQ=AKFwENqxJsCbzYtLgeSomTUpriDOPu
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.add_dir(AKFwENqxJsCbzYtLgeSomTUpriDOWX,sublabel=AKFwENqxJsCbzYtLgeSomTUpriDOQV,img=AKFwENqxJsCbzYtLgeSomTUpriDOQk,infoLabels=AKFwENqxJsCbzYtLgeSomTUpriDOQj,isFolder=AKFwENqxJsCbzYtLgeSomTUpriDOWf,params=AKFwENqxJsCbzYtLgeSomTUpriDOWc,ContextMenu=AKFwENqxJsCbzYtLgeSomTUpriDOXQ)
  if AKFwENqxJsCbzYtLgeSomTUpriDOQl:
   AKFwENqxJsCbzYtLgeSomTUpriDOWc={}
   AKFwENqxJsCbzYtLgeSomTUpriDOWc['mode'] ='LOCAL_SEARCH'
   AKFwENqxJsCbzYtLgeSomTUpriDOWc['search_key']=AKFwENqxJsCbzYtLgeSomTUpriDOHv
   AKFwENqxJsCbzYtLgeSomTUpriDOWc['page'] =AKFwENqxJsCbzYtLgeSomTUpriDOPB(AKFwENqxJsCbzYtLgeSomTUpriDOQv+1)
   AKFwENqxJsCbzYtLgeSomTUpriDOWX='[B]%s >>[/B]'%'다음 페이지'
   AKFwENqxJsCbzYtLgeSomTUpriDOXH=AKFwENqxJsCbzYtLgeSomTUpriDOPB(AKFwENqxJsCbzYtLgeSomTUpriDOQv+1)
   AKFwENqxJsCbzYtLgeSomTUpriDOWk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.add_dir(AKFwENqxJsCbzYtLgeSomTUpriDOWX,sublabel=AKFwENqxJsCbzYtLgeSomTUpriDOXH,img=AKFwENqxJsCbzYtLgeSomTUpriDOWk,infoLabels=AKFwENqxJsCbzYtLgeSomTUpriDOPu,isFolder=AKFwENqxJsCbzYtLgeSomTUpriDOPQ,params=AKFwENqxJsCbzYtLgeSomTUpriDOWc)
  xbmcplugin.setContent(AKFwENqxJsCbzYtLgeSomTUpriDOuP._addon_handle,'movies')
  xbmcplugin.endOfDirectory(AKFwENqxJsCbzYtLgeSomTUpriDOuP._addon_handle,cacheToDisc=AKFwENqxJsCbzYtLgeSomTUpriDOPQ)
  if args.get('historyyn')=='Y':AKFwENqxJsCbzYtLgeSomTUpriDOuP.Save_Searched_List(AKFwENqxJsCbzYtLgeSomTUpriDOHv)
 def Load_List_File(AKFwENqxJsCbzYtLgeSomTUpriDOuP,AKFwENqxJsCbzYtLgeSomTUpriDOHI): 
  try:
   if AKFwENqxJsCbzYtLgeSomTUpriDOHI=='search':
    AKFwENqxJsCbzYtLgeSomTUpriDOHV=AKFwENqxJsCbzYtLgeSomTUpriDOuj
   elif AKFwENqxJsCbzYtLgeSomTUpriDOHI in['tvshow','movie']:
    AKFwENqxJsCbzYtLgeSomTUpriDOHV=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%AKFwENqxJsCbzYtLgeSomTUpriDOHI))
   else:
    return[]
   fp=AKFwENqxJsCbzYtLgeSomTUpriDOPc(AKFwENqxJsCbzYtLgeSomTUpriDOHV,'r',-1,'utf-8')
   AKFwENqxJsCbzYtLgeSomTUpriDOHh=fp.readlines()
   fp.close()
  except:
   AKFwENqxJsCbzYtLgeSomTUpriDOHh=[]
  return AKFwENqxJsCbzYtLgeSomTUpriDOHh
 def Save_Watched_List(AKFwENqxJsCbzYtLgeSomTUpriDOuP,AKFwENqxJsCbzYtLgeSomTUpriDOHI,AKFwENqxJsCbzYtLgeSomTUpriDOuc):
  try:
   AKFwENqxJsCbzYtLgeSomTUpriDOHy=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%AKFwENqxJsCbzYtLgeSomTUpriDOHI))
   AKFwENqxJsCbzYtLgeSomTUpriDOHn=AKFwENqxJsCbzYtLgeSomTUpriDOuP.Load_List_File(AKFwENqxJsCbzYtLgeSomTUpriDOHI) 
   fp=AKFwENqxJsCbzYtLgeSomTUpriDOPc(AKFwENqxJsCbzYtLgeSomTUpriDOHy,'w',-1,'utf-8')
   AKFwENqxJsCbzYtLgeSomTUpriDOHa=urllib.parse.urlencode(AKFwENqxJsCbzYtLgeSomTUpriDOuc)
   AKFwENqxJsCbzYtLgeSomTUpriDOHa=AKFwENqxJsCbzYtLgeSomTUpriDOHa+'\n'
   fp.write(AKFwENqxJsCbzYtLgeSomTUpriDOHa)
   AKFwENqxJsCbzYtLgeSomTUpriDOHd=0
   for AKFwENqxJsCbzYtLgeSomTUpriDOju in AKFwENqxJsCbzYtLgeSomTUpriDOHn:
    AKFwENqxJsCbzYtLgeSomTUpriDOjW=AKFwENqxJsCbzYtLgeSomTUpriDOPH(urllib.parse.parse_qsl(AKFwENqxJsCbzYtLgeSomTUpriDOju))
    AKFwENqxJsCbzYtLgeSomTUpriDOjQ=AKFwENqxJsCbzYtLgeSomTUpriDOuc.get('code').strip()
    AKFwENqxJsCbzYtLgeSomTUpriDOjX=AKFwENqxJsCbzYtLgeSomTUpriDOjW.get('code').strip()
    if AKFwENqxJsCbzYtLgeSomTUpriDOjQ!=AKFwENqxJsCbzYtLgeSomTUpriDOjX:
     fp.write(AKFwENqxJsCbzYtLgeSomTUpriDOju)
     AKFwENqxJsCbzYtLgeSomTUpriDOHd+=1
     if AKFwENqxJsCbzYtLgeSomTUpriDOHd>=50:break
   fp.close()
  except:
   AKFwENqxJsCbzYtLgeSomTUpriDOPu
 def Save_Searched_List(AKFwENqxJsCbzYtLgeSomTUpriDOuP,AKFwENqxJsCbzYtLgeSomTUpriDOHv):
  try:
   AKFwENqxJsCbzYtLgeSomTUpriDOHv=AKFwENqxJsCbzYtLgeSomTUpriDOHv.strip()
   AKFwENqxJsCbzYtLgeSomTUpriDOHn=AKFwENqxJsCbzYtLgeSomTUpriDOuP.Load_List_File('search') 
   fp=AKFwENqxJsCbzYtLgeSomTUpriDOPc(AKFwENqxJsCbzYtLgeSomTUpriDOuj,'w',-1,'utf-8')
   fp.write(AKFwENqxJsCbzYtLgeSomTUpriDOHv+'\n')
   AKFwENqxJsCbzYtLgeSomTUpriDOHd=0
   for AKFwENqxJsCbzYtLgeSomTUpriDOju in AKFwENqxJsCbzYtLgeSomTUpriDOHn:
    AKFwENqxJsCbzYtLgeSomTUpriDOju=AKFwENqxJsCbzYtLgeSomTUpriDOju.strip()
    if AKFwENqxJsCbzYtLgeSomTUpriDOHv!=AKFwENqxJsCbzYtLgeSomTUpriDOju:
     fp.write(AKFwENqxJsCbzYtLgeSomTUpriDOju+'\n')
     AKFwENqxJsCbzYtLgeSomTUpriDOHd+=1
     if AKFwENqxJsCbzYtLgeSomTUpriDOHd>=50:break
   fp.close()
  except:
   AKFwENqxJsCbzYtLgeSomTUpriDOPu
 def dp_Search_History(AKFwENqxJsCbzYtLgeSomTUpriDOuP,args):
  AKFwENqxJsCbzYtLgeSomTUpriDOjH=AKFwENqxJsCbzYtLgeSomTUpriDOuP.Load_List_File('search')
  for AKFwENqxJsCbzYtLgeSomTUpriDOjP in AKFwENqxJsCbzYtLgeSomTUpriDOjH:
   AKFwENqxJsCbzYtLgeSomTUpriDOjP=AKFwENqxJsCbzYtLgeSomTUpriDOjP.strip()
   AKFwENqxJsCbzYtLgeSomTUpriDOWc={'mode':'LOCAL_SEARCH','search_key':AKFwENqxJsCbzYtLgeSomTUpriDOjP,'page':'1','historyyn':'Y',}
   AKFwENqxJsCbzYtLgeSomTUpriDOjR={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','skey':AKFwENqxJsCbzYtLgeSomTUpriDOjP,'vType':'-',}
   AKFwENqxJsCbzYtLgeSomTUpriDOjk=urllib.parse.urlencode(AKFwENqxJsCbzYtLgeSomTUpriDOjR)
   AKFwENqxJsCbzYtLgeSomTUpriDOXQ=[('선택된 검색어 ( %s ) 삭제'%(AKFwENqxJsCbzYtLgeSomTUpriDOjP),'RunPlugin(plugin://plugin.video.coupangm/?%s)'%(AKFwENqxJsCbzYtLgeSomTUpriDOjk))]
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.add_dir(AKFwENqxJsCbzYtLgeSomTUpriDOjP,sublabel='',img=AKFwENqxJsCbzYtLgeSomTUpriDOPu,infoLabels=AKFwENqxJsCbzYtLgeSomTUpriDOPu,isFolder=AKFwENqxJsCbzYtLgeSomTUpriDOPQ,params=AKFwENqxJsCbzYtLgeSomTUpriDOWc,ContextMenu=AKFwENqxJsCbzYtLgeSomTUpriDOXQ)
  AKFwENqxJsCbzYtLgeSomTUpriDOQj={'plot':'검색목록 전체를 삭제합니다.'}
  AKFwENqxJsCbzYtLgeSomTUpriDOWX='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  AKFwENqxJsCbzYtLgeSomTUpriDOWc={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  AKFwENqxJsCbzYtLgeSomTUpriDOWk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  AKFwENqxJsCbzYtLgeSomTUpriDOuP.add_dir(AKFwENqxJsCbzYtLgeSomTUpriDOWX,sublabel='',img=AKFwENqxJsCbzYtLgeSomTUpriDOWk,infoLabels=AKFwENqxJsCbzYtLgeSomTUpriDOQj,isFolder=AKFwENqxJsCbzYtLgeSomTUpriDOPW,params=AKFwENqxJsCbzYtLgeSomTUpriDOWc,isLink=AKFwENqxJsCbzYtLgeSomTUpriDOPQ)
  xbmcplugin.endOfDirectory(AKFwENqxJsCbzYtLgeSomTUpriDOuP._addon_handle,cacheToDisc=AKFwENqxJsCbzYtLgeSomTUpriDOPW)
 def dp_Listfile_Delete(AKFwENqxJsCbzYtLgeSomTUpriDOuP,args):
  AKFwENqxJsCbzYtLgeSomTUpriDOjc=args.get('delType')
  AKFwENqxJsCbzYtLgeSomTUpriDOjf =args.get('skey')
  AKFwENqxJsCbzYtLgeSomTUpriDOQu =args.get('vType')
  AKFwENqxJsCbzYtLgeSomTUpriDOuB=xbmcgui.Dialog()
  if AKFwENqxJsCbzYtLgeSomTUpriDOjc=='SEARCH_ALL':
   AKFwENqxJsCbzYtLgeSomTUpriDOWv=AKFwENqxJsCbzYtLgeSomTUpriDOuB.yesno(__language__(30911).encode('utf8'),__language__(30906).encode('utf8'))
  elif AKFwENqxJsCbzYtLgeSomTUpriDOjc=='SEARCH_ONE':
   AKFwENqxJsCbzYtLgeSomTUpriDOWv=AKFwENqxJsCbzYtLgeSomTUpriDOuB.yesno(__language__(30912).encode('utf8'),__language__(30906).encode('utf8'))
  elif AKFwENqxJsCbzYtLgeSomTUpriDOjc=='WATCH_ALL':
   AKFwENqxJsCbzYtLgeSomTUpriDOWv=AKFwENqxJsCbzYtLgeSomTUpriDOuB.yesno(__language__(30913).encode('utf8'),__language__(30906).encode('utf8'))
  elif AKFwENqxJsCbzYtLgeSomTUpriDOjc=='WATCH_ONE':
   AKFwENqxJsCbzYtLgeSomTUpriDOWv=AKFwENqxJsCbzYtLgeSomTUpriDOuB.yesno(__language__(30916).encode('utf8'),__language__(30906).encode('utf8'))
  if AKFwENqxJsCbzYtLgeSomTUpriDOWv==AKFwENqxJsCbzYtLgeSomTUpriDOPW:sys.exit()
  if AKFwENqxJsCbzYtLgeSomTUpriDOjc=='SEARCH_ALL':
   if os.path.isfile(AKFwENqxJsCbzYtLgeSomTUpriDOuj):os.remove(AKFwENqxJsCbzYtLgeSomTUpriDOuj)
  elif AKFwENqxJsCbzYtLgeSomTUpriDOjc=='SEARCH_ONE':
   try:
    AKFwENqxJsCbzYtLgeSomTUpriDOHV=AKFwENqxJsCbzYtLgeSomTUpriDOuj
    AKFwENqxJsCbzYtLgeSomTUpriDOHn=AKFwENqxJsCbzYtLgeSomTUpriDOuP.Load_List_File('search') 
    fp=AKFwENqxJsCbzYtLgeSomTUpriDOPc(AKFwENqxJsCbzYtLgeSomTUpriDOHV,'w',-1,'utf-8')
    for AKFwENqxJsCbzYtLgeSomTUpriDOju in AKFwENqxJsCbzYtLgeSomTUpriDOHn:
     if AKFwENqxJsCbzYtLgeSomTUpriDOjf!=AKFwENqxJsCbzYtLgeSomTUpriDOju.strip():
      fp.write(AKFwENqxJsCbzYtLgeSomTUpriDOju)
    fp.close()
   except:
    AKFwENqxJsCbzYtLgeSomTUpriDOPu
  elif AKFwENqxJsCbzYtLgeSomTUpriDOjc=='WATCH_ALL':
   AKFwENqxJsCbzYtLgeSomTUpriDOHV=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%AKFwENqxJsCbzYtLgeSomTUpriDOQu))
   if os.path.isfile(AKFwENqxJsCbzYtLgeSomTUpriDOHV):os.remove(AKFwENqxJsCbzYtLgeSomTUpriDOHV)
  elif AKFwENqxJsCbzYtLgeSomTUpriDOjc=='WATCH_ONE':
   AKFwENqxJsCbzYtLgeSomTUpriDOHV=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%AKFwENqxJsCbzYtLgeSomTUpriDOQu))
   try:
    AKFwENqxJsCbzYtLgeSomTUpriDOHn=AKFwENqxJsCbzYtLgeSomTUpriDOuP.Load_List_File(AKFwENqxJsCbzYtLgeSomTUpriDOQu) 
    fp=AKFwENqxJsCbzYtLgeSomTUpriDOPc(AKFwENqxJsCbzYtLgeSomTUpriDOHV,'w',-1,'utf-8')
    for AKFwENqxJsCbzYtLgeSomTUpriDOju in AKFwENqxJsCbzYtLgeSomTUpriDOHn:
     AKFwENqxJsCbzYtLgeSomTUpriDOjW=AKFwENqxJsCbzYtLgeSomTUpriDOPH(urllib.parse.parse_qsl(AKFwENqxJsCbzYtLgeSomTUpriDOju))
     AKFwENqxJsCbzYtLgeSomTUpriDOjB=AKFwENqxJsCbzYtLgeSomTUpriDOjW.get('code').strip()
     if AKFwENqxJsCbzYtLgeSomTUpriDOjf!=AKFwENqxJsCbzYtLgeSomTUpriDOjB:
      fp.write(AKFwENqxJsCbzYtLgeSomTUpriDOju)
    fp.close()
   except:
    AKFwENqxJsCbzYtLgeSomTUpriDOPu
  xbmc.executebuiltin("Container.Refresh")
 def Delete_List_File(AKFwENqxJsCbzYtLgeSomTUpriDOuP,AKFwENqxJsCbzYtLgeSomTUpriDOHI,skey='-'):
  if AKFwENqxJsCbzYtLgeSomTUpriDOHI=='ALL':
   try:
    AKFwENqxJsCbzYtLgeSomTUpriDOHV=AKFwENqxJsCbzYtLgeSomTUpriDOuj
    fp=AKFwENqxJsCbzYtLgeSomTUpriDOPc(AKFwENqxJsCbzYtLgeSomTUpriDOHV,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    AKFwENqxJsCbzYtLgeSomTUpriDOPu
  elif AKFwENqxJsCbzYtLgeSomTUpriDOHI=='ONE':
   try:
    AKFwENqxJsCbzYtLgeSomTUpriDOHV=AKFwENqxJsCbzYtLgeSomTUpriDOuj
    AKFwENqxJsCbzYtLgeSomTUpriDOHn=AKFwENqxJsCbzYtLgeSomTUpriDOuP.Load_List_File('search') 
    fp=AKFwENqxJsCbzYtLgeSomTUpriDOPc(AKFwENqxJsCbzYtLgeSomTUpriDOHV,'w',-1,'utf-8')
    for AKFwENqxJsCbzYtLgeSomTUpriDOju in AKFwENqxJsCbzYtLgeSomTUpriDOHn:
     if skey!=AKFwENqxJsCbzYtLgeSomTUpriDOju.strip():
      fp.write(AKFwENqxJsCbzYtLgeSomTUpriDOju)
    fp.close()
   except:
    AKFwENqxJsCbzYtLgeSomTUpriDOPu
  elif AKFwENqxJsCbzYtLgeSomTUpriDOHI in['tvshow','movie']:
   try:
    AKFwENqxJsCbzYtLgeSomTUpriDOHV=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%AKFwENqxJsCbzYtLgeSomTUpriDOHI))
    fp=AKFwENqxJsCbzYtLgeSomTUpriDOPc(AKFwENqxJsCbzYtLgeSomTUpriDOHV,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    AKFwENqxJsCbzYtLgeSomTUpriDOPu
 def dp_Watch_List(AKFwENqxJsCbzYtLgeSomTUpriDOuP,args):
  AKFwENqxJsCbzYtLgeSomTUpriDOHI =args.get('stype')
  if AKFwENqxJsCbzYtLgeSomTUpriDOHI in['',AKFwENqxJsCbzYtLgeSomTUpriDOPu]:
   for AKFwENqxJsCbzYtLgeSomTUpriDOjI in AKFwENqxJsCbzYtLgeSomTUpriDOuX:
    AKFwENqxJsCbzYtLgeSomTUpriDOWX=AKFwENqxJsCbzYtLgeSomTUpriDOjI.get('title')
    AKFwENqxJsCbzYtLgeSomTUpriDOWc={'mode':AKFwENqxJsCbzYtLgeSomTUpriDOjI.get('mode'),'stype':AKFwENqxJsCbzYtLgeSomTUpriDOjI.get('stype'),}
    AKFwENqxJsCbzYtLgeSomTUpriDOuP.add_dir(AKFwENqxJsCbzYtLgeSomTUpriDOWX,sublabel='',img='',infoLabels=AKFwENqxJsCbzYtLgeSomTUpriDOPu,isFolder=AKFwENqxJsCbzYtLgeSomTUpriDOPQ,params=AKFwENqxJsCbzYtLgeSomTUpriDOWc)
   xbmcplugin.endOfDirectory(AKFwENqxJsCbzYtLgeSomTUpriDOuP._addon_handle)
  else:
   AKFwENqxJsCbzYtLgeSomTUpriDOjM=AKFwENqxJsCbzYtLgeSomTUpriDOuP.Load_List_File(AKFwENqxJsCbzYtLgeSomTUpriDOHI)
   for AKFwENqxJsCbzYtLgeSomTUpriDOjv in AKFwENqxJsCbzYtLgeSomTUpriDOjM:
    AKFwENqxJsCbzYtLgeSomTUpriDOjl=AKFwENqxJsCbzYtLgeSomTUpriDOPH(urllib.parse.parse_qsl(AKFwENqxJsCbzYtLgeSomTUpriDOjv))
    AKFwENqxJsCbzYtLgeSomTUpriDOXh =AKFwENqxJsCbzYtLgeSomTUpriDOjl.get('code').strip()
    AKFwENqxJsCbzYtLgeSomTUpriDOWX =AKFwENqxJsCbzYtLgeSomTUpriDOjl.get('title').strip()
    AKFwENqxJsCbzYtLgeSomTUpriDOQk =AKFwENqxJsCbzYtLgeSomTUpriDOjl.get('img').strip()
    AKFwENqxJsCbzYtLgeSomTUpriDOQc =AKFwENqxJsCbzYtLgeSomTUpriDOjl.get('asis').strip()
    try:
     AKFwENqxJsCbzYtLgeSomTUpriDOQk=AKFwENqxJsCbzYtLgeSomTUpriDOQk.replace('\'','\"')
     AKFwENqxJsCbzYtLgeSomTUpriDOQk=json.loads(AKFwENqxJsCbzYtLgeSomTUpriDOQk)
    except:
     AKFwENqxJsCbzYtLgeSomTUpriDOPu
    AKFwENqxJsCbzYtLgeSomTUpriDOQj={}
    AKFwENqxJsCbzYtLgeSomTUpriDOQj['plot']=AKFwENqxJsCbzYtLgeSomTUpriDOWX
    if AKFwENqxJsCbzYtLgeSomTUpriDOHI=='movie':
     AKFwENqxJsCbzYtLgeSomTUpriDOQj['mediatype']='movie'
     AKFwENqxJsCbzYtLgeSomTUpriDOWc={'mode':'MOVIE','id':AKFwENqxJsCbzYtLgeSomTUpriDOXh,'asis':AKFwENqxJsCbzYtLgeSomTUpriDOQc,'title':AKFwENqxJsCbzYtLgeSomTUpriDOWX,'thumbnail':AKFwENqxJsCbzYtLgeSomTUpriDOQk,}
     AKFwENqxJsCbzYtLgeSomTUpriDOWf=AKFwENqxJsCbzYtLgeSomTUpriDOPW
    else:
     AKFwENqxJsCbzYtLgeSomTUpriDOQj['mediatype']='episode'
     AKFwENqxJsCbzYtLgeSomTUpriDOWc={'mode':'SEASON_LIST','id':AKFwENqxJsCbzYtLgeSomTUpriDOXh,'asis':AKFwENqxJsCbzYtLgeSomTUpriDOQc,'title':AKFwENqxJsCbzYtLgeSomTUpriDOWX,'thumbnail':json.dumps(AKFwENqxJsCbzYtLgeSomTUpriDOQk,separators=(',',':')),}
     AKFwENqxJsCbzYtLgeSomTUpriDOWf=AKFwENqxJsCbzYtLgeSomTUpriDOPQ
    AKFwENqxJsCbzYtLgeSomTUpriDOjR={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','skey':AKFwENqxJsCbzYtLgeSomTUpriDOXh,'vType':AKFwENqxJsCbzYtLgeSomTUpriDOHI,}
    AKFwENqxJsCbzYtLgeSomTUpriDOjk=urllib.parse.urlencode(AKFwENqxJsCbzYtLgeSomTUpriDOjR)
    AKFwENqxJsCbzYtLgeSomTUpriDOXQ=[('선택된 시청이력 ( %s ) 삭제'%(AKFwENqxJsCbzYtLgeSomTUpriDOWX),'RunPlugin(plugin://plugin.video.coupangm/?%s)'%(AKFwENqxJsCbzYtLgeSomTUpriDOjk))]
    AKFwENqxJsCbzYtLgeSomTUpriDOuP.add_dir(AKFwENqxJsCbzYtLgeSomTUpriDOWX,sublabel='',img=AKFwENqxJsCbzYtLgeSomTUpriDOQk,infoLabels=AKFwENqxJsCbzYtLgeSomTUpriDOQj,isFolder=AKFwENqxJsCbzYtLgeSomTUpriDOWf,params=AKFwENqxJsCbzYtLgeSomTUpriDOWc,ContextMenu=AKFwENqxJsCbzYtLgeSomTUpriDOXQ)
   AKFwENqxJsCbzYtLgeSomTUpriDOQj={'plot':'시청목록을 삭제합니다.'}
   AKFwENqxJsCbzYtLgeSomTUpriDOWX='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   AKFwENqxJsCbzYtLgeSomTUpriDOWc={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':AKFwENqxJsCbzYtLgeSomTUpriDOHI,}
   AKFwENqxJsCbzYtLgeSomTUpriDOWk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.add_dir(AKFwENqxJsCbzYtLgeSomTUpriDOWX,sublabel='',img=AKFwENqxJsCbzYtLgeSomTUpriDOWk,infoLabels=AKFwENqxJsCbzYtLgeSomTUpriDOQj,isFolder=AKFwENqxJsCbzYtLgeSomTUpriDOPW,params=AKFwENqxJsCbzYtLgeSomTUpriDOWc,isLink=AKFwENqxJsCbzYtLgeSomTUpriDOPQ)
   if AKFwENqxJsCbzYtLgeSomTUpriDOHI=='movie':xbmcplugin.setContent(AKFwENqxJsCbzYtLgeSomTUpriDOuP._addon_handle,'movies')
   else:xbmcplugin.setContent(AKFwENqxJsCbzYtLgeSomTUpriDOuP._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(AKFwENqxJsCbzYtLgeSomTUpriDOuP._addon_handle,cacheToDisc=AKFwENqxJsCbzYtLgeSomTUpriDOPW)
 def dp_Set_Bookmark(AKFwENqxJsCbzYtLgeSomTUpriDOuP,args):
  AKFwENqxJsCbzYtLgeSomTUpriDOjG=urllib.parse.unquote(args.get('bm_param'))
  AKFwENqxJsCbzYtLgeSomTUpriDOjG=json.loads(AKFwENqxJsCbzYtLgeSomTUpriDOjG)
  AKFwENqxJsCbzYtLgeSomTUpriDOjV =AKFwENqxJsCbzYtLgeSomTUpriDOjG.get('videoid')
  AKFwENqxJsCbzYtLgeSomTUpriDOjh =AKFwENqxJsCbzYtLgeSomTUpriDOjG.get('vidtype')
  AKFwENqxJsCbzYtLgeSomTUpriDOjy =AKFwENqxJsCbzYtLgeSomTUpriDOjG.get('vtitle')
  AKFwENqxJsCbzYtLgeSomTUpriDOuB=xbmcgui.Dialog()
  AKFwENqxJsCbzYtLgeSomTUpriDOWv=AKFwENqxJsCbzYtLgeSomTUpriDOuB.yesno(__language__(30914).encode('utf8'),AKFwENqxJsCbzYtLgeSomTUpriDOjy+' \n\n'+__language__(30915))
  if AKFwENqxJsCbzYtLgeSomTUpriDOWv==AKFwENqxJsCbzYtLgeSomTUpriDOPW:return
  AKFwENqxJsCbzYtLgeSomTUpriDOjn=AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.GetBookmarkInfo(AKFwENqxJsCbzYtLgeSomTUpriDOjV,AKFwENqxJsCbzYtLgeSomTUpriDOjh)
  AKFwENqxJsCbzYtLgeSomTUpriDOja=json.dumps(AKFwENqxJsCbzYtLgeSomTUpriDOjn)
  AKFwENqxJsCbzYtLgeSomTUpriDOja=urllib.parse.quote(AKFwENqxJsCbzYtLgeSomTUpriDOja)
  AKFwENqxJsCbzYtLgeSomTUpriDOXW ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(AKFwENqxJsCbzYtLgeSomTUpriDOja)
  xbmc.executebuiltin(AKFwENqxJsCbzYtLgeSomTUpriDOXW)
 def coupang_main(AKFwENqxJsCbzYtLgeSomTUpriDOuP):
  AKFwENqxJsCbzYtLgeSomTUpriDOuP.CoupangObj.KodiVersion=AKFwENqxJsCbzYtLgeSomTUpriDOPR(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  AKFwENqxJsCbzYtLgeSomTUpriDOQa=AKFwENqxJsCbzYtLgeSomTUpriDOuP.main_params.get('mode',AKFwENqxJsCbzYtLgeSomTUpriDOPu)
  if AKFwENqxJsCbzYtLgeSomTUpriDOQa=='LOGOUT':
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.CP_logout()
   return
  AKFwENqxJsCbzYtLgeSomTUpriDOuP.option_check()
  if AKFwENqxJsCbzYtLgeSomTUpriDOQa is AKFwENqxJsCbzYtLgeSomTUpriDOPu:
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.dp_Main_List(AKFwENqxJsCbzYtLgeSomTUpriDOuP.main_params)
  elif AKFwENqxJsCbzYtLgeSomTUpriDOQa=='CATEGORY_GROUPLIST':
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.dp_Category_GroupList(AKFwENqxJsCbzYtLgeSomTUpriDOuP.main_params)
  elif AKFwENqxJsCbzYtLgeSomTUpriDOQa=='THEME_GROUPLIST':
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.dp_Theme_GroupList(AKFwENqxJsCbzYtLgeSomTUpriDOuP.main_params)
  elif AKFwENqxJsCbzYtLgeSomTUpriDOQa=='EVENT_GROUPLIST':
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.dp_Event_GroupList(AKFwENqxJsCbzYtLgeSomTUpriDOuP.main_params)
  elif AKFwENqxJsCbzYtLgeSomTUpriDOQa=='EVENT_GAMELIST':
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.dp_Event_GameList(AKFwENqxJsCbzYtLgeSomTUpriDOuP.main_params)
  elif AKFwENqxJsCbzYtLgeSomTUpriDOQa=='EVENT_LIST':
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.dp_Event_List(AKFwENqxJsCbzYtLgeSomTUpriDOuP.main_params)
  elif AKFwENqxJsCbzYtLgeSomTUpriDOQa=='CATEGORY_LIST':
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.dp_Category_List(AKFwENqxJsCbzYtLgeSomTUpriDOuP.main_params)
  elif AKFwENqxJsCbzYtLgeSomTUpriDOQa=='SEASON_LIST':
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.dp_Season_List(AKFwENqxJsCbzYtLgeSomTUpriDOuP.main_params)
  elif AKFwENqxJsCbzYtLgeSomTUpriDOQa=='EPISODE_LIST':
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.dp_Episode_List(AKFwENqxJsCbzYtLgeSomTUpriDOuP.main_params)
  elif AKFwENqxJsCbzYtLgeSomTUpriDOQa=='TEST':
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.dp_Test(AKFwENqxJsCbzYtLgeSomTUpriDOuP.main_params)
  elif AKFwENqxJsCbzYtLgeSomTUpriDOQa in['MOVIE','VOD','HIGHLIGHT','LIVE']:
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.play_VIDEO(AKFwENqxJsCbzYtLgeSomTUpriDOuP.main_params)
  elif AKFwENqxJsCbzYtLgeSomTUpriDOQa=='WATCH':
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.dp_Watch_List(AKFwENqxJsCbzYtLgeSomTUpriDOuP.main_params)
  elif AKFwENqxJsCbzYtLgeSomTUpriDOQa=='LOCAL_SEARCH':
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.dp_Search_List(AKFwENqxJsCbzYtLgeSomTUpriDOuP.main_params)
  elif AKFwENqxJsCbzYtLgeSomTUpriDOQa=='SEARCH_HISTORY':
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.dp_Search_History(AKFwENqxJsCbzYtLgeSomTUpriDOuP.main_params)
  elif AKFwENqxJsCbzYtLgeSomTUpriDOQa in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.dp_Listfile_Delete(AKFwENqxJsCbzYtLgeSomTUpriDOuP.main_params)
  elif AKFwENqxJsCbzYtLgeSomTUpriDOQa in['TOTAL_SEARCH','TOTAL_HISTORY']:
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.dp_Global_Search(AKFwENqxJsCbzYtLgeSomTUpriDOuP.main_params)
  elif AKFwENqxJsCbzYtLgeSomTUpriDOQa=='MENU_BOOKMARK':
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.dp_Bookmark_Menu(AKFwENqxJsCbzYtLgeSomTUpriDOuP.main_params)
  elif AKFwENqxJsCbzYtLgeSomTUpriDOQa=='SET_BOOKMARK':
   AKFwENqxJsCbzYtLgeSomTUpriDOuP.dp_Set_Bookmark(AKFwENqxJsCbzYtLgeSomTUpriDOuP.main_params)
  else:
   AKFwENqxJsCbzYtLgeSomTUpriDOPu
# Created by pyminifier (https://github.com/liftoff/pyminifier)
