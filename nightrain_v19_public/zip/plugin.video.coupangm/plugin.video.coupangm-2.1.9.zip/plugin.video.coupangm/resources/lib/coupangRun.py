__author__="NightRain"
AwKqmbxWiSfFtHRLvEdacOsBNQpYUV=object
AwKqmbxWiSfFtHRLvEdacOsBNQpYUM=None
AwKqmbxWiSfFtHRLvEdacOsBNQpYUy=False
AwKqmbxWiSfFtHRLvEdacOsBNQpYUj=True
AwKqmbxWiSfFtHRLvEdacOsBNQpYUG=type
AwKqmbxWiSfFtHRLvEdacOsBNQpYUI=dict
AwKqmbxWiSfFtHRLvEdacOsBNQpYUk=getattr
AwKqmbxWiSfFtHRLvEdacOsBNQpYUe=int
AwKqmbxWiSfFtHRLvEdacOsBNQpYUX=list
AwKqmbxWiSfFtHRLvEdacOsBNQpYUo=open
AwKqmbxWiSfFtHRLvEdacOsBNQpYUP=Exception
AwKqmbxWiSfFtHRLvEdacOsBNQpYUu=str
AwKqmbxWiSfFtHRLvEdacOsBNQpYUz=id
AwKqmbxWiSfFtHRLvEdacOsBNQpYUJ=len
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import inputstreamhelper
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
AwKqmbxWiSfFtHRLvEdacOsBNQpYgT=[{'title':'오직 쿠팡플레이에서','mode':'CATEGORY_LIST','vType':'ORIGINAL','collectionId':'5c33c5ca-ee6f-45f8-a026-dd789a8b63cf'},{'title':'홈   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'ALL'},{'title':'TV   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'MOVIES'},{'title':'(패스) 스포츠','mode':'SPORTS_MAINLIST_LEAGUE'},{'title':'(패스) Paramount+','mode':'PASS_GROUPLIST','collectionId':'1afeaf87-0b7a-4a49-a971-fa5be7aedf4e'},{'title':'(패스) Sony Pictures','mode':'PASS_GROUPLIST','collectionId':'5b37af01-01fb-4361-ba5b-0f23f307d557'},{'title':'TV   (테마별)','mode':'THEME_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (테마별)','mode':'THEME_GROUPLIST','vType':'MOVIES'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},{'title':'(쿠팡) 검색','mode':'LOCAL_SEARCH','icon':'search.png'},{'title':'(쿠팡) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
AwKqmbxWiSfFtHRLvEdacOsBNQpYgl=[{'title':'시리즈 시청내역','mode':'WATCH','stype':'tvshow'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},]
AwKqmbxWiSfFtHRLvEdacOsBNQpYgr={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
AwKqmbxWiSfFtHRLvEdacOsBNQpYgn=xbmcvfs.translatePath(os.path.join(__profile__,'coupang_searched.txt'))
from coupangCore import*
class AwKqmbxWiSfFtHRLvEdacOsBNQpYgD(AwKqmbxWiSfFtHRLvEdacOsBNQpYUV):
 def __init__(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,AwKqmbxWiSfFtHRLvEdacOsBNQpYgU,AwKqmbxWiSfFtHRLvEdacOsBNQpYgM,AwKqmbxWiSfFtHRLvEdacOsBNQpYgy):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_url =AwKqmbxWiSfFtHRLvEdacOsBNQpYgU
  AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle=AwKqmbxWiSfFtHRLvEdacOsBNQpYgM
  AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.main_params =AwKqmbxWiSfFtHRLvEdacOsBNQpYgy
  AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj =ECULefxDBQvAXNgpTlaPKdMqWSOIwF() 
  AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.CP_COOKIE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_cookies.json'))
  AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.CP_DEVICE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_device.json'))
 def addon_noti(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,sting):
  try:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgG=xbmcgui.Dialog()
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgG.notification(__addonname__,sting)
  except:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYUM
 def addon_log(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,string):
  try:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgI=string.encode('utf-8','ignore')
  except:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgI='addonException: addon_log'
  AwKqmbxWiSfFtHRLvEdacOsBNQpYgk=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,AwKqmbxWiSfFtHRLvEdacOsBNQpYgI),level=AwKqmbxWiSfFtHRLvEdacOsBNQpYgk)
 def get_keyboard_input(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,AwKqmbxWiSfFtHRLvEdacOsBNQpYDr):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYge=AwKqmbxWiSfFtHRLvEdacOsBNQpYUM
  kb=xbmc.Keyboard()
  kb.setHeading(AwKqmbxWiSfFtHRLvEdacOsBNQpYDr)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   AwKqmbxWiSfFtHRLvEdacOsBNQpYge=kb.getText()
  return AwKqmbxWiSfFtHRLvEdacOsBNQpYge
 def get_settings_account(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYgX=__addon__.getSetting('id')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYgo=__addon__.getSetting('pw')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYgP=__addon__.getSetting('profile')
  return(AwKqmbxWiSfFtHRLvEdacOsBNQpYgX,AwKqmbxWiSfFtHRLvEdacOsBNQpYgo,AwKqmbxWiSfFtHRLvEdacOsBNQpYgP)
 def get_settings_exclusion21(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYgu =__addon__.getSetting('exclusion21')
  if AwKqmbxWiSfFtHRLvEdacOsBNQpYgu=='false':
   return AwKqmbxWiSfFtHRLvEdacOsBNQpYUy
  else:
   return AwKqmbxWiSfFtHRLvEdacOsBNQpYUj
 def get_settings_totalsearch(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYgz =AwKqmbxWiSfFtHRLvEdacOsBNQpYUj if __addon__.getSetting('local_search')=='true' else AwKqmbxWiSfFtHRLvEdacOsBNQpYUy
  AwKqmbxWiSfFtHRLvEdacOsBNQpYgJ=AwKqmbxWiSfFtHRLvEdacOsBNQpYUj if __addon__.getSetting('local_history')=='true' else AwKqmbxWiSfFtHRLvEdacOsBNQpYUy
  AwKqmbxWiSfFtHRLvEdacOsBNQpYgC =AwKqmbxWiSfFtHRLvEdacOsBNQpYUj if __addon__.getSetting('total_search')=='true' else AwKqmbxWiSfFtHRLvEdacOsBNQpYUy
  AwKqmbxWiSfFtHRLvEdacOsBNQpYgh=AwKqmbxWiSfFtHRLvEdacOsBNQpYUj if __addon__.getSetting('total_history')=='true' else AwKqmbxWiSfFtHRLvEdacOsBNQpYUy
  AwKqmbxWiSfFtHRLvEdacOsBNQpYDg=AwKqmbxWiSfFtHRLvEdacOsBNQpYUj if __addon__.getSetting('menu_bookmark')=='true' else AwKqmbxWiSfFtHRLvEdacOsBNQpYUy
  return(AwKqmbxWiSfFtHRLvEdacOsBNQpYgz,AwKqmbxWiSfFtHRLvEdacOsBNQpYgJ,AwKqmbxWiSfFtHRLvEdacOsBNQpYgC,AwKqmbxWiSfFtHRLvEdacOsBNQpYgh,AwKqmbxWiSfFtHRLvEdacOsBNQpYDg)
 def get_settings_makebookmark(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV):
  return AwKqmbxWiSfFtHRLvEdacOsBNQpYUj if __addon__.getSetting('make_bookmark')=='true' else AwKqmbxWiSfFtHRLvEdacOsBNQpYUy
 def set_winEpisodeOrderby(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,AwKqmbxWiSfFtHRLvEdacOsBNQpYDT):
  __addon__.setSetting('coupang_orderby',AwKqmbxWiSfFtHRLvEdacOsBNQpYDT)
 def get_winEpisodeOrderby(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYDT=__addon__.getSetting('coupang_orderby')
  if AwKqmbxWiSfFtHRLvEdacOsBNQpYDT in['',AwKqmbxWiSfFtHRLvEdacOsBNQpYUM]:AwKqmbxWiSfFtHRLvEdacOsBNQpYDT='asc'
  return AwKqmbxWiSfFtHRLvEdacOsBNQpYDT
 def add_dir(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,label,sublabel='',img='',infoLabels=AwKqmbxWiSfFtHRLvEdacOsBNQpYUM,isFolder=AwKqmbxWiSfFtHRLvEdacOsBNQpYUj,params='',isLink=AwKqmbxWiSfFtHRLvEdacOsBNQpYUy,ContextMenu=AwKqmbxWiSfFtHRLvEdacOsBNQpYUM):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYDl='%s?%s'%(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_url,urllib.parse.urlencode(params))
  if sublabel:AwKqmbxWiSfFtHRLvEdacOsBNQpYDr='%s < %s >'%(label,sublabel)
  else: AwKqmbxWiSfFtHRLvEdacOsBNQpYDr=label
  if not img:img='DefaultFolder.png'
  AwKqmbxWiSfFtHRLvEdacOsBNQpYDn=xbmcgui.ListItem(AwKqmbxWiSfFtHRLvEdacOsBNQpYDr)
  if AwKqmbxWiSfFtHRLvEdacOsBNQpYUG(img)==AwKqmbxWiSfFtHRLvEdacOsBNQpYUI:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDn.setArt(img)
  else:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDn.setArt({'thumb':img,'poster':img})
  if AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.KodiVersion>=20:
   if infoLabels:AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.Set_InfoTag(AwKqmbxWiSfFtHRLvEdacOsBNQpYDn.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:AwKqmbxWiSfFtHRLvEdacOsBNQpYDn.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDn.setProperty('IsPlayable','true')
  if ContextMenu:AwKqmbxWiSfFtHRLvEdacOsBNQpYDn.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,AwKqmbxWiSfFtHRLvEdacOsBNQpYDl,AwKqmbxWiSfFtHRLvEdacOsBNQpYDn,isFolder)
 def Set_InfoTag(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,video_InfoTag:xbmc.InfoTagVideo,AwKqmbxWiSfFtHRLvEdacOsBNQpYDk):
  for AwKqmbxWiSfFtHRLvEdacOsBNQpYDV,value in AwKqmbxWiSfFtHRLvEdacOsBNQpYDk.items():
   if AwKqmbxWiSfFtHRLvEdacOsBNQpYgr[AwKqmbxWiSfFtHRLvEdacOsBNQpYDV]['type']=='string':
    AwKqmbxWiSfFtHRLvEdacOsBNQpYUk(video_InfoTag,AwKqmbxWiSfFtHRLvEdacOsBNQpYgr[AwKqmbxWiSfFtHRLvEdacOsBNQpYDV]['func'])(value)
   elif AwKqmbxWiSfFtHRLvEdacOsBNQpYgr[AwKqmbxWiSfFtHRLvEdacOsBNQpYDV]['type']=='int':
    if AwKqmbxWiSfFtHRLvEdacOsBNQpYUG(value)==AwKqmbxWiSfFtHRLvEdacOsBNQpYUe:
     AwKqmbxWiSfFtHRLvEdacOsBNQpYDU=AwKqmbxWiSfFtHRLvEdacOsBNQpYUe(value)
    else:
     AwKqmbxWiSfFtHRLvEdacOsBNQpYDU=0
    AwKqmbxWiSfFtHRLvEdacOsBNQpYUk(video_InfoTag,AwKqmbxWiSfFtHRLvEdacOsBNQpYgr[AwKqmbxWiSfFtHRLvEdacOsBNQpYDV]['func'])(AwKqmbxWiSfFtHRLvEdacOsBNQpYDU)
   elif AwKqmbxWiSfFtHRLvEdacOsBNQpYgr[AwKqmbxWiSfFtHRLvEdacOsBNQpYDV]['type']=='actor':
    if value!=[]:
     AwKqmbxWiSfFtHRLvEdacOsBNQpYUk(video_InfoTag,AwKqmbxWiSfFtHRLvEdacOsBNQpYgr[AwKqmbxWiSfFtHRLvEdacOsBNQpYDV]['func'])([xbmc.Actor(name)for name in value])
   elif AwKqmbxWiSfFtHRLvEdacOsBNQpYgr[AwKqmbxWiSfFtHRLvEdacOsBNQpYDV]['type']=='list':
    if AwKqmbxWiSfFtHRLvEdacOsBNQpYUG(value)==AwKqmbxWiSfFtHRLvEdacOsBNQpYUX:
     AwKqmbxWiSfFtHRLvEdacOsBNQpYUk(video_InfoTag,AwKqmbxWiSfFtHRLvEdacOsBNQpYgr[AwKqmbxWiSfFtHRLvEdacOsBNQpYDV]['func'])(value)
    else:
     AwKqmbxWiSfFtHRLvEdacOsBNQpYUk(video_InfoTag,AwKqmbxWiSfFtHRLvEdacOsBNQpYgr[AwKqmbxWiSfFtHRLvEdacOsBNQpYDV]['func'])([value])
 def dp_Main_List(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,args):
  (AwKqmbxWiSfFtHRLvEdacOsBNQpYgz,AwKqmbxWiSfFtHRLvEdacOsBNQpYgJ,AwKqmbxWiSfFtHRLvEdacOsBNQpYgC,AwKqmbxWiSfFtHRLvEdacOsBNQpYgh,AwKqmbxWiSfFtHRLvEdacOsBNQpYDg)=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.get_settings_totalsearch()
  for AwKqmbxWiSfFtHRLvEdacOsBNQpYDM in AwKqmbxWiSfFtHRLvEdacOsBNQpYgT:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDr=AwKqmbxWiSfFtHRLvEdacOsBNQpYDM.get('title')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDy=''
   if AwKqmbxWiSfFtHRLvEdacOsBNQpYDM.get('mode')=='LOCAL_SEARCH' and AwKqmbxWiSfFtHRLvEdacOsBNQpYgz ==AwKqmbxWiSfFtHRLvEdacOsBNQpYUy:continue
   elif AwKqmbxWiSfFtHRLvEdacOsBNQpYDM.get('mode')=='SEARCH_HISTORY' and AwKqmbxWiSfFtHRLvEdacOsBNQpYgJ==AwKqmbxWiSfFtHRLvEdacOsBNQpYUy:continue
   elif AwKqmbxWiSfFtHRLvEdacOsBNQpYDM.get('mode')=='TOTAL_SEARCH' and AwKqmbxWiSfFtHRLvEdacOsBNQpYgC ==AwKqmbxWiSfFtHRLvEdacOsBNQpYUy:continue
   elif AwKqmbxWiSfFtHRLvEdacOsBNQpYDM.get('mode')=='TOTAL_HISTORY' and AwKqmbxWiSfFtHRLvEdacOsBNQpYgh==AwKqmbxWiSfFtHRLvEdacOsBNQpYUy:continue
   elif AwKqmbxWiSfFtHRLvEdacOsBNQpYDM.get('mode')=='MENU_BOOKMARK' and AwKqmbxWiSfFtHRLvEdacOsBNQpYDg==AwKqmbxWiSfFtHRLvEdacOsBNQpYUy:continue
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj={'mode':AwKqmbxWiSfFtHRLvEdacOsBNQpYDM.get('mode'),'vType':AwKqmbxWiSfFtHRLvEdacOsBNQpYDM.get('vType'),'collectionId':AwKqmbxWiSfFtHRLvEdacOsBNQpYDM.get('collectionId'),'page':'1',}
   if AwKqmbxWiSfFtHRLvEdacOsBNQpYDM.get('mode')=='LOCAL_SEARCH':AwKqmbxWiSfFtHRLvEdacOsBNQpYDj['historyyn']='Y' 
   if AwKqmbxWiSfFtHRLvEdacOsBNQpYDM.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    AwKqmbxWiSfFtHRLvEdacOsBNQpYDG=AwKqmbxWiSfFtHRLvEdacOsBNQpYUy
    AwKqmbxWiSfFtHRLvEdacOsBNQpYDI =AwKqmbxWiSfFtHRLvEdacOsBNQpYUj
   else:
    AwKqmbxWiSfFtHRLvEdacOsBNQpYDG=AwKqmbxWiSfFtHRLvEdacOsBNQpYUj
    AwKqmbxWiSfFtHRLvEdacOsBNQpYDI =AwKqmbxWiSfFtHRLvEdacOsBNQpYUy
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDk={'title':AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,'plot':AwKqmbxWiSfFtHRLvEdacOsBNQpYDr}
   if AwKqmbxWiSfFtHRLvEdacOsBNQpYDM.get('mode')=='XXX':AwKqmbxWiSfFtHRLvEdacOsBNQpYDk=AwKqmbxWiSfFtHRLvEdacOsBNQpYUM
   if 'icon' in AwKqmbxWiSfFtHRLvEdacOsBNQpYDM:AwKqmbxWiSfFtHRLvEdacOsBNQpYDy=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',AwKqmbxWiSfFtHRLvEdacOsBNQpYDM.get('icon')) 
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.add_dir(AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,sublabel='',img=AwKqmbxWiSfFtHRLvEdacOsBNQpYDy,infoLabels=AwKqmbxWiSfFtHRLvEdacOsBNQpYDk,isFolder=AwKqmbxWiSfFtHRLvEdacOsBNQpYDG,params=AwKqmbxWiSfFtHRLvEdacOsBNQpYDj,isLink=AwKqmbxWiSfFtHRLvEdacOsBNQpYDI)
  xbmcplugin.endOfDirectory(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle)
 def dp_Test(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,args):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.addon_noti('test')
 def CP_logout(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYgG=xbmcgui.Dialog()
  AwKqmbxWiSfFtHRLvEdacOsBNQpYDX=AwKqmbxWiSfFtHRLvEdacOsBNQpYgG.yesno(__language__(30905).encode('utf8'),__language__(30906).encode('utf8'))
  if AwKqmbxWiSfFtHRLvEdacOsBNQpYDX==AwKqmbxWiSfFtHRLvEdacOsBNQpYUy:return 
  if os.path.isfile(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.CP_COOKIE_FILENAME):os.remove(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.CP_COOKIE_FILENAME)
  AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.addon_noti(__language__(30904).encode('utf-8'))
 def option_check(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV):
  (AwKqmbxWiSfFtHRLvEdacOsBNQpYgX,AwKqmbxWiSfFtHRLvEdacOsBNQpYgo,AwKqmbxWiSfFtHRLvEdacOsBNQpYgP)=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.get_settings_account()
  if AwKqmbxWiSfFtHRLvEdacOsBNQpYgX=='' or AwKqmbxWiSfFtHRLvEdacOsBNQpYgo=='':
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgG=xbmcgui.Dialog()
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDX=AwKqmbxWiSfFtHRLvEdacOsBNQpYgG.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if AwKqmbxWiSfFtHRLvEdacOsBNQpYDX==AwKqmbxWiSfFtHRLvEdacOsBNQpYUj:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.cookiefile_check()==AwKqmbxWiSfFtHRLvEdacOsBNQpYUy:
   if AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CP_login(AwKqmbxWiSfFtHRLvEdacOsBNQpYgX,AwKqmbxWiSfFtHRLvEdacOsBNQpYgo,AwKqmbxWiSfFtHRLvEdacOsBNQpYgP)==AwKqmbxWiSfFtHRLvEdacOsBNQpYUy:
    AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.addon_noti(__language__(30903).encode('utf8'))
    sys.exit()
  else:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.Get_CP_profile(AwKqmbxWiSfFtHRLvEdacOsBNQpYgP,limit_days=AwKqmbxWiSfFtHRLvEdacOsBNQpYUe(__addon__.getSetting('cache_ttl')),re_check=AwKqmbxWiSfFtHRLvEdacOsBNQpYUj)
 def cookiefile_check(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYDP={}
  try: 
   fp=AwKqmbxWiSfFtHRLvEdacOsBNQpYUo(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.CP_COOKIE_FILENAME,'r',-1,'utf-8')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDP= json.load(fp)
   fp.close()
  except AwKqmbxWiSfFtHRLvEdacOsBNQpYUP as exception:
   return AwKqmbxWiSfFtHRLvEdacOsBNQpYUy
  AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.CP=AwKqmbxWiSfFtHRLvEdacOsBNQpYDP
  (AwKqmbxWiSfFtHRLvEdacOsBNQpYgX,AwKqmbxWiSfFtHRLvEdacOsBNQpYgo,AwKqmbxWiSfFtHRLvEdacOsBNQpYgP)=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.get_settings_account()
  (AwKqmbxWiSfFtHRLvEdacOsBNQpYDu,AwKqmbxWiSfFtHRLvEdacOsBNQpYDz,AwKqmbxWiSfFtHRLvEdacOsBNQpYDJ)=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.Load_session_acount()
  if AwKqmbxWiSfFtHRLvEdacOsBNQpYgX!=AwKqmbxWiSfFtHRLvEdacOsBNQpYDu or AwKqmbxWiSfFtHRLvEdacOsBNQpYgo!=AwKqmbxWiSfFtHRLvEdacOsBNQpYDz or AwKqmbxWiSfFtHRLvEdacOsBNQpYgP!=AwKqmbxWiSfFtHRLvEdacOsBNQpYUu(AwKqmbxWiSfFtHRLvEdacOsBNQpYDJ):
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.Init_CP()
   return AwKqmbxWiSfFtHRLvEdacOsBNQpYUy
  AwKqmbxWiSfFtHRLvEdacOsBNQpYDC =AwKqmbxWiSfFtHRLvEdacOsBNQpYUe(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.Get_Now_Datetime().strftime('%Y%m%d'))
  AwKqmbxWiSfFtHRLvEdacOsBNQpYDh=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.CP['SESSION']['limitdate']
  AwKqmbxWiSfFtHRLvEdacOsBNQpYTg =AwKqmbxWiSfFtHRLvEdacOsBNQpYUe(re.sub('-','',AwKqmbxWiSfFtHRLvEdacOsBNQpYDh))
  if AwKqmbxWiSfFtHRLvEdacOsBNQpYTg<AwKqmbxWiSfFtHRLvEdacOsBNQpYDC:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.Init_CP()
   return AwKqmbxWiSfFtHRLvEdacOsBNQpYUy
  return AwKqmbxWiSfFtHRLvEdacOsBNQpYUj
 def CP_login(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,AwKqmbxWiSfFtHRLvEdacOsBNQpYgX,AwKqmbxWiSfFtHRLvEdacOsBNQpYgo,AwKqmbxWiSfFtHRLvEdacOsBNQpYgP):
  if AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.Get_CP_Login(AwKqmbxWiSfFtHRLvEdacOsBNQpYgX,AwKqmbxWiSfFtHRLvEdacOsBNQpYgo,AwKqmbxWiSfFtHRLvEdacOsBNQpYgP)==AwKqmbxWiSfFtHRLvEdacOsBNQpYUy:return AwKqmbxWiSfFtHRLvEdacOsBNQpYUy
  if AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.Get_CP_profile(AwKqmbxWiSfFtHRLvEdacOsBNQpYgP,limit_days=AwKqmbxWiSfFtHRLvEdacOsBNQpYUe(__addon__.getSetting('cache_ttl')),re_check=AwKqmbxWiSfFtHRLvEdacOsBNQpYUy)==AwKqmbxWiSfFtHRLvEdacOsBNQpYUy:return AwKqmbxWiSfFtHRLvEdacOsBNQpYUy
  return AwKqmbxWiSfFtHRLvEdacOsBNQpYUj
 def dp_Category_GroupList(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,args):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYTD =args.get('vType') 
  AwKqmbxWiSfFtHRLvEdacOsBNQpYTl=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.Get_Category_GroupList(AwKqmbxWiSfFtHRLvEdacOsBNQpYTD)
  for AwKqmbxWiSfFtHRLvEdacOsBNQpYTr in AwKqmbxWiSfFtHRLvEdacOsBNQpYTl:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDr =AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('title')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTn=AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('pre_title')
   if AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.get_settings_exclusion21()==AwKqmbxWiSfFtHRLvEdacOsBNQpYUj and AwKqmbxWiSfFtHRLvEdacOsBNQpYDr=='성인':continue
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTV={'mediatype':'tvshow','plot':AwKqmbxWiSfFtHRLvEdacOsBNQpYTn,}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj={'mode':'CATEGORY_LIST','collectionId':AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('collectionId'),'vType':AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('category'),'page':'1',}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.add_dir(AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,sublabel='',img='',infoLabels=AwKqmbxWiSfFtHRLvEdacOsBNQpYTV,isFolder=AwKqmbxWiSfFtHRLvEdacOsBNQpYUj,params=AwKqmbxWiSfFtHRLvEdacOsBNQpYDj)
  xbmcplugin.endOfDirectory(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,cacheToDisc=AwKqmbxWiSfFtHRLvEdacOsBNQpYUy)
 def dp_Theme_GroupList(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,args):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYTD =args.get('vType') 
  AwKqmbxWiSfFtHRLvEdacOsBNQpYTl=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.Get_Theme_GroupList(AwKqmbxWiSfFtHRLvEdacOsBNQpYTD)
  for AwKqmbxWiSfFtHRLvEdacOsBNQpYTr in AwKqmbxWiSfFtHRLvEdacOsBNQpYTl:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDr =AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('title')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTn=AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('pre_title')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTV={'mediatype':'tvshow','plot':AwKqmbxWiSfFtHRLvEdacOsBNQpYTn,}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj={'mode':'CATEGORY_LIST','collectionId':AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('collectionId'),'vType':AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('category'),'page':'1',}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.add_dir(AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,sublabel='',img='',infoLabels=AwKqmbxWiSfFtHRLvEdacOsBNQpYTV,isFolder=AwKqmbxWiSfFtHRLvEdacOsBNQpYUj,params=AwKqmbxWiSfFtHRLvEdacOsBNQpYDj)
  xbmcplugin.endOfDirectory(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,cacheToDisc=AwKqmbxWiSfFtHRLvEdacOsBNQpYUy)
 def dp_Event_GroupList(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,args):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYTl=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.Get_Event_GroupList()
  for AwKqmbxWiSfFtHRLvEdacOsBNQpYTr in AwKqmbxWiSfFtHRLvEdacOsBNQpYTl:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDr =AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('title')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTn=AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('pre_title')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTV={'mediatype':'tvshow','plot':AwKqmbxWiSfFtHRLvEdacOsBNQpYTn,}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj={'mode':'EVENT_GAMELIST','collectionId':AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('collectionId'),'vType':'LIVE',}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.add_dir(AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,sublabel='',img='',infoLabels=AwKqmbxWiSfFtHRLvEdacOsBNQpYTV,isFolder=AwKqmbxWiSfFtHRLvEdacOsBNQpYUj,params=AwKqmbxWiSfFtHRLvEdacOsBNQpYDj)
  xbmcplugin.endOfDirectory(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,cacheToDisc=AwKqmbxWiSfFtHRLvEdacOsBNQpYUy)
 def dp_Event_GameList(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,args):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYTD =args.get('vType') 
  AwKqmbxWiSfFtHRLvEdacOsBNQpYTM =args.get('collectionId')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYTl=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.Get_Event_GameList(AwKqmbxWiSfFtHRLvEdacOsBNQpYTM)
  for AwKqmbxWiSfFtHRLvEdacOsBNQpYTr in AwKqmbxWiSfFtHRLvEdacOsBNQpYTl:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDr =AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('title')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYUz =AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('id')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTy =AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('thumbnail')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTj =AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('asis') 
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTG =AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('addInfo')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTI =AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('starttm')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTV={'mediatype':'tvshow','title':AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,'plot':AwKqmbxWiSfFtHRLvEdacOsBNQpYTG,}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj={'mode':'EVENT_LIST','id':AwKqmbxWiSfFtHRLvEdacOsBNQpYUz,'asis':AwKqmbxWiSfFtHRLvEdacOsBNQpYTj,'title':AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.add_dir(AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,sublabel=AwKqmbxWiSfFtHRLvEdacOsBNQpYTI,img=AwKqmbxWiSfFtHRLvEdacOsBNQpYTy,infoLabels=AwKqmbxWiSfFtHRLvEdacOsBNQpYTV,isFolder=AwKqmbxWiSfFtHRLvEdacOsBNQpYUj,params=AwKqmbxWiSfFtHRLvEdacOsBNQpYDj,ContextMenu=AwKqmbxWiSfFtHRLvEdacOsBNQpYUM)
  xbmcplugin.setContent(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,cacheToDisc=AwKqmbxWiSfFtHRLvEdacOsBNQpYUy)
 def dp_Event_List(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,args):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYTk=args.get('id')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYTl=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.Get_Event_List(AwKqmbxWiSfFtHRLvEdacOsBNQpYTk)
  for AwKqmbxWiSfFtHRLvEdacOsBNQpYTr in AwKqmbxWiSfFtHRLvEdacOsBNQpYTl:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDr =AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('title')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYUz =AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('id')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTy =AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('thumbnail')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTj =AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('asis') 
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTe =AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('duration')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTI =AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('starttm')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTV={'mediatype':'episode','title':AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,'plot':AwKqmbxWiSfFtHRLvEdacOsBNQpYTj,'duration':AwKqmbxWiSfFtHRLvEdacOsBNQpYTe,}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj={'mode':AwKqmbxWiSfFtHRLvEdacOsBNQpYTj,'id':AwKqmbxWiSfFtHRLvEdacOsBNQpYUz,'asis':AwKqmbxWiSfFtHRLvEdacOsBNQpYTj,'title':AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.add_dir(AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,sublabel=AwKqmbxWiSfFtHRLvEdacOsBNQpYTI,img=AwKqmbxWiSfFtHRLvEdacOsBNQpYTy,infoLabels=AwKqmbxWiSfFtHRLvEdacOsBNQpYTV,isFolder=AwKqmbxWiSfFtHRLvEdacOsBNQpYUy,params=AwKqmbxWiSfFtHRLvEdacOsBNQpYDj,ContextMenu=AwKqmbxWiSfFtHRLvEdacOsBNQpYUM)
  xbmcplugin.setContent(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,cacheToDisc=AwKqmbxWiSfFtHRLvEdacOsBNQpYUy)
 def dp_Category_List(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,args):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYTD =args.get('vType') 
  AwKqmbxWiSfFtHRLvEdacOsBNQpYTM =args.get('collectionId')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYTX =AwKqmbxWiSfFtHRLvEdacOsBNQpYUe(args.get('page'))
  AwKqmbxWiSfFtHRLvEdacOsBNQpYTl,AwKqmbxWiSfFtHRLvEdacOsBNQpYTo=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.Get_Category_List(AwKqmbxWiSfFtHRLvEdacOsBNQpYTD,AwKqmbxWiSfFtHRLvEdacOsBNQpYTM,AwKqmbxWiSfFtHRLvEdacOsBNQpYTX)
  for AwKqmbxWiSfFtHRLvEdacOsBNQpYTr in AwKqmbxWiSfFtHRLvEdacOsBNQpYTl:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDr =AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('title')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYUz =AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('id')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTy =AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('thumbnail')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTP =AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('mpaa')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTe =AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('duration')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTj =AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('asis')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTu =AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('badge')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTz =AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('year')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTJ=AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('seasonList')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTC =AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('genreList')
   if AwKqmbxWiSfFtHRLvEdacOsBNQpYTj in['TVSHOW','EDUCATION']: 
    AwKqmbxWiSfFtHRLvEdacOsBNQpYTh ='SEASON_LIST'
    AwKqmbxWiSfFtHRLvEdacOsBNQpYTV={'mediatype':'tvshow','title':AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,'mpaa':AwKqmbxWiSfFtHRLvEdacOsBNQpYTP,'genre':AwKqmbxWiSfFtHRLvEdacOsBNQpYTC,'year':AwKqmbxWiSfFtHRLvEdacOsBNQpYTz,'plot':'Year : %s\nSeason : %s'%(AwKqmbxWiSfFtHRLvEdacOsBNQpYTz,AwKqmbxWiSfFtHRLvEdacOsBNQpYTJ),}
    AwKqmbxWiSfFtHRLvEdacOsBNQpYDG =AwKqmbxWiSfFtHRLvEdacOsBNQpYUj
   else:
    AwKqmbxWiSfFtHRLvEdacOsBNQpYTh ='MOVIE'
    AwKqmbxWiSfFtHRLvEdacOsBNQpYTV={'mediatype':'movie','title':AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,'mpaa':AwKqmbxWiSfFtHRLvEdacOsBNQpYTP,'genre':AwKqmbxWiSfFtHRLvEdacOsBNQpYTC,'duration':AwKqmbxWiSfFtHRLvEdacOsBNQpYTe,'year':AwKqmbxWiSfFtHRLvEdacOsBNQpYTz,'plot':'(%s)'%(AwKqmbxWiSfFtHRLvEdacOsBNQpYTP),}
    AwKqmbxWiSfFtHRLvEdacOsBNQpYDG =AwKqmbxWiSfFtHRLvEdacOsBNQpYUy
    AwKqmbxWiSfFtHRLvEdacOsBNQpYDr +=' (%s)'%(AwKqmbxWiSfFtHRLvEdacOsBNQpYUu(AwKqmbxWiSfFtHRLvEdacOsBNQpYTz))
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj={'mode':AwKqmbxWiSfFtHRLvEdacOsBNQpYTh,'id':AwKqmbxWiSfFtHRLvEdacOsBNQpYUz,'asis':AwKqmbxWiSfFtHRLvEdacOsBNQpYTj,'seasonList':AwKqmbxWiSfFtHRLvEdacOsBNQpYTJ,'title':AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,'thumbnail':AwKqmbxWiSfFtHRLvEdacOsBNQpYTy,'year':AwKqmbxWiSfFtHRLvEdacOsBNQpYTz,}
   if AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.get_settings_makebookmark():
    AwKqmbxWiSfFtHRLvEdacOsBNQpYlg={'videoid':AwKqmbxWiSfFtHRLvEdacOsBNQpYUz,'vidtype':'movie' if AwKqmbxWiSfFtHRLvEdacOsBNQpYTD=='MOVIES' else 'tvshow','vtitle':AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,'vsubtitle':'',}
    AwKqmbxWiSfFtHRLvEdacOsBNQpYlD=json.dumps(AwKqmbxWiSfFtHRLvEdacOsBNQpYlg)
    AwKqmbxWiSfFtHRLvEdacOsBNQpYlD=urllib.parse.quote(AwKqmbxWiSfFtHRLvEdacOsBNQpYlD)
    AwKqmbxWiSfFtHRLvEdacOsBNQpYlT='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(AwKqmbxWiSfFtHRLvEdacOsBNQpYlD)
    AwKqmbxWiSfFtHRLvEdacOsBNQpYlr=[('(통합) 찜 영상에 추가',AwKqmbxWiSfFtHRLvEdacOsBNQpYlT)]
   else:
    AwKqmbxWiSfFtHRLvEdacOsBNQpYlr=AwKqmbxWiSfFtHRLvEdacOsBNQpYUM
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.add_dir(AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,sublabel=AwKqmbxWiSfFtHRLvEdacOsBNQpYTu,img=AwKqmbxWiSfFtHRLvEdacOsBNQpYTy,infoLabels=AwKqmbxWiSfFtHRLvEdacOsBNQpYTV,isFolder=AwKqmbxWiSfFtHRLvEdacOsBNQpYDG,params=AwKqmbxWiSfFtHRLvEdacOsBNQpYDj,ContextMenu=AwKqmbxWiSfFtHRLvEdacOsBNQpYlr)
  if AwKqmbxWiSfFtHRLvEdacOsBNQpYTo:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj['mode'] ='CATEGORY_LIST' 
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj['collectionId']=AwKqmbxWiSfFtHRLvEdacOsBNQpYTM 
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj['vType'] =AwKqmbxWiSfFtHRLvEdacOsBNQpYTD 
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj['page'] =AwKqmbxWiSfFtHRLvEdacOsBNQpYUu(AwKqmbxWiSfFtHRLvEdacOsBNQpYTX+1)
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDr='[B]%s >>[/B]'%'다음 페이지'
   AwKqmbxWiSfFtHRLvEdacOsBNQpYln=AwKqmbxWiSfFtHRLvEdacOsBNQpYUu(AwKqmbxWiSfFtHRLvEdacOsBNQpYTX+1)
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDy=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.add_dir(AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,sublabel=AwKqmbxWiSfFtHRLvEdacOsBNQpYln,img=AwKqmbxWiSfFtHRLvEdacOsBNQpYDy,infoLabels=AwKqmbxWiSfFtHRLvEdacOsBNQpYUM,isFolder=AwKqmbxWiSfFtHRLvEdacOsBNQpYUj,params=AwKqmbxWiSfFtHRLvEdacOsBNQpYDj)
  if AwKqmbxWiSfFtHRLvEdacOsBNQpYTD=='TVSHOWS':xbmcplugin.setContent(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,'tvshows')
  else:xbmcplugin.setContent(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,'movies')
  xbmcplugin.endOfDirectory(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,cacheToDisc=AwKqmbxWiSfFtHRLvEdacOsBNQpYUy)
 def dp_Season_List(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,args):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYlV =args.get('title')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYlU =args.get('id')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYTj =args.get('asis')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYTJ =args.get('seasonList')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYTy =args.get('thumbnail')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYTz =args.get('year')
  if AwKqmbxWiSfFtHRLvEdacOsBNQpYTJ in['',AwKqmbxWiSfFtHRLvEdacOsBNQpYUM]:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTJ=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.Get_vInfo(AwKqmbxWiSfFtHRLvEdacOsBNQpYlU).get('seasonList')
  if AwKqmbxWiSfFtHRLvEdacOsBNQpYUJ(AwKqmbxWiSfFtHRLvEdacOsBNQpYTJ.split(','))>1:
   for AwKqmbxWiSfFtHRLvEdacOsBNQpYlM in AwKqmbxWiSfFtHRLvEdacOsBNQpYTJ.split(','):
    AwKqmbxWiSfFtHRLvEdacOsBNQpYDr='시즌 '+AwKqmbxWiSfFtHRLvEdacOsBNQpYlM
    AwKqmbxWiSfFtHRLvEdacOsBNQpYTV={'mediatype':'tvshow','plot':'%s (%s)'%(AwKqmbxWiSfFtHRLvEdacOsBNQpYlV,AwKqmbxWiSfFtHRLvEdacOsBNQpYTz),}
    AwKqmbxWiSfFtHRLvEdacOsBNQpYDj={'mode':'EPISODE_LIST','programid':AwKqmbxWiSfFtHRLvEdacOsBNQpYlU,'programnm':AwKqmbxWiSfFtHRLvEdacOsBNQpYlV,'season':AwKqmbxWiSfFtHRLvEdacOsBNQpYlM,'asis':AwKqmbxWiSfFtHRLvEdacOsBNQpYTj,'programimg':AwKqmbxWiSfFtHRLvEdacOsBNQpYTy,'page':'1',}
    AwKqmbxWiSfFtHRLvEdacOsBNQpYly=AwKqmbxWiSfFtHRLvEdacOsBNQpYTy.replace('\'','\"')
    AwKqmbxWiSfFtHRLvEdacOsBNQpYly=json.loads(AwKqmbxWiSfFtHRLvEdacOsBNQpYly)
    AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.add_dir(AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,sublabel='',img=AwKqmbxWiSfFtHRLvEdacOsBNQpYly,infoLabels=AwKqmbxWiSfFtHRLvEdacOsBNQpYTV,isFolder=AwKqmbxWiSfFtHRLvEdacOsBNQpYUj,params=AwKqmbxWiSfFtHRLvEdacOsBNQpYDj)
   xbmcplugin.setContent(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,cacheToDisc=AwKqmbxWiSfFtHRLvEdacOsBNQpYUy)
  else:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYlj={'programid':AwKqmbxWiSfFtHRLvEdacOsBNQpYlU,'programnm':AwKqmbxWiSfFtHRLvEdacOsBNQpYlV,'season':AwKqmbxWiSfFtHRLvEdacOsBNQpYTJ,'programimg':AwKqmbxWiSfFtHRLvEdacOsBNQpYTy,'page':'1',}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.dp_Episode_List(AwKqmbxWiSfFtHRLvEdacOsBNQpYlj)
 def dp_Episode_List(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,args):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYlU =args.get('programid')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYlV =args.get('programnm')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYlG =args.get('season')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYlI =args.get('programimg')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYTX =AwKqmbxWiSfFtHRLvEdacOsBNQpYUe(args.get('page'))
  AwKqmbxWiSfFtHRLvEdacOsBNQpYlk,AwKqmbxWiSfFtHRLvEdacOsBNQpYTo=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.Get_Episode_List(AwKqmbxWiSfFtHRLvEdacOsBNQpYlU,AwKqmbxWiSfFtHRLvEdacOsBNQpYlG,page=AwKqmbxWiSfFtHRLvEdacOsBNQpYTX,orderby=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.get_winEpisodeOrderby())
  for AwKqmbxWiSfFtHRLvEdacOsBNQpYlM in AwKqmbxWiSfFtHRLvEdacOsBNQpYlk:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYle =AwKqmbxWiSfFtHRLvEdacOsBNQpYlM.get('title')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYlX =AwKqmbxWiSfFtHRLvEdacOsBNQpYlM.get('id')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTj =AwKqmbxWiSfFtHRLvEdacOsBNQpYlM.get('asis')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTy =AwKqmbxWiSfFtHRLvEdacOsBNQpYlM.get('thumbnail')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTP =AwKqmbxWiSfFtHRLvEdacOsBNQpYlM.get('mpaa')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTe =AwKqmbxWiSfFtHRLvEdacOsBNQpYlM.get('duration')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTz =AwKqmbxWiSfFtHRLvEdacOsBNQpYlM.get('year')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYlo =AwKqmbxWiSfFtHRLvEdacOsBNQpYlM.get('episode')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTC =AwKqmbxWiSfFtHRLvEdacOsBNQpYlM.get('genreList')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYlP =AwKqmbxWiSfFtHRLvEdacOsBNQpYlM.get('desc')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYlu ='%sx%s'%(AwKqmbxWiSfFtHRLvEdacOsBNQpYlG,AwKqmbxWiSfFtHRLvEdacOsBNQpYlo)
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDr ='%s. %s'%(AwKqmbxWiSfFtHRLvEdacOsBNQpYlu,AwKqmbxWiSfFtHRLvEdacOsBNQpYle)
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTV={'mediatype':'episode','mpaa':AwKqmbxWiSfFtHRLvEdacOsBNQpYTP,'genre':AwKqmbxWiSfFtHRLvEdacOsBNQpYTC,'duration':AwKqmbxWiSfFtHRLvEdacOsBNQpYTe,'year':AwKqmbxWiSfFtHRLvEdacOsBNQpYTz,'plot':'%s (%s)\n\n%s'%(AwKqmbxWiSfFtHRLvEdacOsBNQpYlV,AwKqmbxWiSfFtHRLvEdacOsBNQpYlu,AwKqmbxWiSfFtHRLvEdacOsBNQpYlP),}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj={'mode':'VOD','programid':AwKqmbxWiSfFtHRLvEdacOsBNQpYlU,'programnm':AwKqmbxWiSfFtHRLvEdacOsBNQpYlV,'title':AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,'season':AwKqmbxWiSfFtHRLvEdacOsBNQpYlG,'id':AwKqmbxWiSfFtHRLvEdacOsBNQpYlX,'asis':AwKqmbxWiSfFtHRLvEdacOsBNQpYTj,'thumbnail':AwKqmbxWiSfFtHRLvEdacOsBNQpYTy,'programimg':AwKqmbxWiSfFtHRLvEdacOsBNQpYlI,}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.add_dir(AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,sublabel='',img=AwKqmbxWiSfFtHRLvEdacOsBNQpYTy,infoLabels=AwKqmbxWiSfFtHRLvEdacOsBNQpYTV,isFolder=AwKqmbxWiSfFtHRLvEdacOsBNQpYUy,params=AwKqmbxWiSfFtHRLvEdacOsBNQpYDj)
  if AwKqmbxWiSfFtHRLvEdacOsBNQpYTX==1:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTV={'plot':'정렬순서를 변경합니다.'}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj={}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj['mode'] ='ORDER_BY' 
   if AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.get_winEpisodeOrderby()=='desc':
    AwKqmbxWiSfFtHRLvEdacOsBNQpYDr='정렬순서변경 : 최신화부터 -> 1회부터'
    AwKqmbxWiSfFtHRLvEdacOsBNQpYDj['orderby']='asc'
   else:
    AwKqmbxWiSfFtHRLvEdacOsBNQpYDr='정렬순서변경 : 1회부터 -> 최신화부터'
    AwKqmbxWiSfFtHRLvEdacOsBNQpYDj['orderby']='desc'
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDy=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.add_dir(AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,sublabel='',img=AwKqmbxWiSfFtHRLvEdacOsBNQpYDy,infoLabels=AwKqmbxWiSfFtHRLvEdacOsBNQpYTV,isFolder=AwKqmbxWiSfFtHRLvEdacOsBNQpYUy,params=AwKqmbxWiSfFtHRLvEdacOsBNQpYDj,isLink=AwKqmbxWiSfFtHRLvEdacOsBNQpYUj)
  if AwKqmbxWiSfFtHRLvEdacOsBNQpYTo:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj={}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj['mode'] ='EPISODE_LIST'
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj['programid'] =AwKqmbxWiSfFtHRLvEdacOsBNQpYlU
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj['programnm'] =AwKqmbxWiSfFtHRLvEdacOsBNQpYlV
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj['season'] =AwKqmbxWiSfFtHRLvEdacOsBNQpYlG
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj['programimg']=AwKqmbxWiSfFtHRLvEdacOsBNQpYlI
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj['page'] =AwKqmbxWiSfFtHRLvEdacOsBNQpYUu(AwKqmbxWiSfFtHRLvEdacOsBNQpYTX+1)
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDr='[B]%s >>[/B]'%'다음 페이지'
   AwKqmbxWiSfFtHRLvEdacOsBNQpYln=AwKqmbxWiSfFtHRLvEdacOsBNQpYUu(AwKqmbxWiSfFtHRLvEdacOsBNQpYTX+1)
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDy=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.add_dir(AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,sublabel=AwKqmbxWiSfFtHRLvEdacOsBNQpYln,img=AwKqmbxWiSfFtHRLvEdacOsBNQpYDy,infoLabels=AwKqmbxWiSfFtHRLvEdacOsBNQpYUM,isFolder=AwKqmbxWiSfFtHRLvEdacOsBNQpYUj,params=AwKqmbxWiSfFtHRLvEdacOsBNQpYDj)
  xbmcplugin.setContent(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,cacheToDisc=AwKqmbxWiSfFtHRLvEdacOsBNQpYUy)
 def play_VIDEO(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,args):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYlz =args.get('id')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYTj =args.get('asis')
  if AwKqmbxWiSfFtHRLvEdacOsBNQpYTj in['HIGHLIGHT']:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYlJ,AwKqmbxWiSfFtHRLvEdacOsBNQpYlC=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.GetEventURL(AwKqmbxWiSfFtHRLvEdacOsBNQpYlz,AwKqmbxWiSfFtHRLvEdacOsBNQpYTj)
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYTj in['LIVE']:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYlJ,AwKqmbxWiSfFtHRLvEdacOsBNQpYlC=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.GetEventURL_Live(AwKqmbxWiSfFtHRLvEdacOsBNQpYlz,AwKqmbxWiSfFtHRLvEdacOsBNQpYTj)
  else:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYlJ,AwKqmbxWiSfFtHRLvEdacOsBNQpYlC=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.GetBroadURL(AwKqmbxWiSfFtHRLvEdacOsBNQpYlz)
  AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.addon_log('asis, url : %s - %s - %s'%(AwKqmbxWiSfFtHRLvEdacOsBNQpYTj,AwKqmbxWiSfFtHRLvEdacOsBNQpYlz,AwKqmbxWiSfFtHRLvEdacOsBNQpYlJ))
  if AwKqmbxWiSfFtHRLvEdacOsBNQpYlJ=='':
   if AwKqmbxWiSfFtHRLvEdacOsBNQpYlC=='':
    AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.addon_noti(__language__(30907).encode('utf8'))
   else:
    AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.addon_log('drm_license_1 : %s'%(AwKqmbxWiSfFtHRLvEdacOsBNQpYlC))
    AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.addon_noti(AwKqmbxWiSfFtHRLvEdacOsBNQpYlC)
   return
  else:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.addon_log('drm_license : %s'%(AwKqmbxWiSfFtHRLvEdacOsBNQpYlC))
  '''
  tmp_cookie = 'PCID=%s;token=%s;member_srl=%s;NEXT_LOCALE=%s;session_web_id=%s;device_id=%s' % (self.CoupangObj.CP['COOKIES']['PCID'], self.CoupangObj.CP['COOKIES']['token'], self.CoupangObj.CP['COOKIES']['member_srl'], self.CoupangObj.CP['COOKIES']['NEXT_LOCALE'], self.CoupangObj.CP['COOKIES']['session_web_id'], self.CoupangObj.CP['COOKIES']['device_id'], )
  '''  
  if AwKqmbxWiSfFtHRLvEdacOsBNQpYTj in['EPISODE']:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYlh='https://www.coupangplay.com/play/{}/episode?titleId={}&type=EPISODE&sourceType=page_discover_title_detail%3Apage_discover_feed'.format(AwKqmbxWiSfFtHRLvEdacOsBNQpYlz,AwKqmbxWiSfFtHRLvEdacOsBNQpYlz)
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYTj in['MOVIE']:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYlh='https://www.coupangplay.com/play/{}/movie?sourceType=page_discover_feed'.format(AwKqmbxWiSfFtHRLvEdacOsBNQpYlz)
  else:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYlh='https://www.coupangplay.com/play/'+AwKqmbxWiSfFtHRLvEdacOsBNQpYlz 
  AwKqmbxWiSfFtHRLvEdacOsBNQpYrg,AwKqmbxWiSfFtHRLvEdacOsBNQpYrD,AwKqmbxWiSfFtHRLvEdacOsBNQpYrT=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.Make_authHeader()
  AwKqmbxWiSfFtHRLvEdacOsBNQpYrl=AwKqmbxWiSfFtHRLvEdacOsBNQpYlJ 
  AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.addon_log('tobe, surl : %s'%(AwKqmbxWiSfFtHRLvEdacOsBNQpYrl))
  AwKqmbxWiSfFtHRLvEdacOsBNQpYrn=xbmcgui.ListItem(path=AwKqmbxWiSfFtHRLvEdacOsBNQpYrl)
  AwKqmbxWiSfFtHRLvEdacOsBNQpYrV=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.Get_Url_PostFix(AwKqmbxWiSfFtHRLvEdacOsBNQpYlJ) 
  AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.addon_log('post_fix : '+AwKqmbxWiSfFtHRLvEdacOsBNQpYrV)
  if AwKqmbxWiSfFtHRLvEdacOsBNQpYrV=='m3u8':
   AwKqmbxWiSfFtHRLvEdacOsBNQpYrU ='hls' 
  else:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYrU ='mpd' 
  AwKqmbxWiSfFtHRLvEdacOsBNQpYrM={'user-agent':AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.USER_AGENT,'referer':AwKqmbxWiSfFtHRLvEdacOsBNQpYlh,'traceparent':AwKqmbxWiSfFtHRLvEdacOsBNQpYrg,'tracestate':AwKqmbxWiSfFtHRLvEdacOsBNQpYrD,'newrelic':AwKqmbxWiSfFtHRLvEdacOsBNQpYrT,}
  AwKqmbxWiSfFtHRLvEdacOsBNQpYry =AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.CP['COOKIES']
  AwKqmbxWiSfFtHRLvEdacOsBNQpYrj=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.make_stream_header(AwKqmbxWiSfFtHRLvEdacOsBNQpYrM,AwKqmbxWiSfFtHRLvEdacOsBNQpYry)
  if AwKqmbxWiSfFtHRLvEdacOsBNQpYlC:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYrG =AwKqmbxWiSfFtHRLvEdacOsBNQpYlC 
   AwKqmbxWiSfFtHRLvEdacOsBNQpYrI ='com.widevine.alpha'
   AwKqmbxWiSfFtHRLvEdacOsBNQpYrk=AwKqmbxWiSfFtHRLvEdacOsBNQpYrG+'|'+AwKqmbxWiSfFtHRLvEdacOsBNQpYrj+'|R{SSM}|'
   inputstreamhelper.Helper(AwKqmbxWiSfFtHRLvEdacOsBNQpYrU,drm='com.widevine.alpha').check_inputstream()
   AwKqmbxWiSfFtHRLvEdacOsBNQpYrn.setProperty('inputstream','inputstream.adaptive')
   if AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.KodiVersion<=20:
    AwKqmbxWiSfFtHRLvEdacOsBNQpYrn.setProperty('inputstream.adaptive.manifest_type',AwKqmbxWiSfFtHRLvEdacOsBNQpYrU)
   AwKqmbxWiSfFtHRLvEdacOsBNQpYrn.setProperty('inputstream.adaptive.license_type',AwKqmbxWiSfFtHRLvEdacOsBNQpYrI)
   AwKqmbxWiSfFtHRLvEdacOsBNQpYrn.setProperty('inputstream.adaptive.license_key',AwKqmbxWiSfFtHRLvEdacOsBNQpYrk)
   AwKqmbxWiSfFtHRLvEdacOsBNQpYrn.setProperty('inputstream.adaptive.stream_headers',AwKqmbxWiSfFtHRLvEdacOsBNQpYrj)
   AwKqmbxWiSfFtHRLvEdacOsBNQpYrn.setProperty('inputstream.adaptive.manifest_headers',AwKqmbxWiSfFtHRLvEdacOsBNQpYrj)
   AwKqmbxWiSfFtHRLvEdacOsBNQpYrn.setMimeType('application/dash+xml')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYrn.setContentLookup(AwKqmbxWiSfFtHRLvEdacOsBNQpYUy)
  else:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYrn.setContentLookup(AwKqmbxWiSfFtHRLvEdacOsBNQpYUy)
   AwKqmbxWiSfFtHRLvEdacOsBNQpYrn.setMimeType('application/x-mpegURL')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYrn.setProperty('inputstream','inputstream.adaptive')
   if AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.KodiVersion<=20:
    AwKqmbxWiSfFtHRLvEdacOsBNQpYrn.setProperty('inputstream.adaptive.manifest_type',AwKqmbxWiSfFtHRLvEdacOsBNQpYrU)
   AwKqmbxWiSfFtHRLvEdacOsBNQpYrn.setProperty('inputstream.adaptive.stream_headers',AwKqmbxWiSfFtHRLvEdacOsBNQpYrj)
   AwKqmbxWiSfFtHRLvEdacOsBNQpYrn.setProperty('inputstream.adaptive.manifest_headers',AwKqmbxWiSfFtHRLvEdacOsBNQpYrj)
  xbmcplugin.setResolvedUrl(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,AwKqmbxWiSfFtHRLvEdacOsBNQpYUj,AwKqmbxWiSfFtHRLvEdacOsBNQpYrn)
  try:
   if AwKqmbxWiSfFtHRLvEdacOsBNQpYTj=='MOVIE':
    AwKqmbxWiSfFtHRLvEdacOsBNQpYrX='movie'
    AwKqmbxWiSfFtHRLvEdacOsBNQpYDj={'code':AwKqmbxWiSfFtHRLvEdacOsBNQpYlz,'asis':AwKqmbxWiSfFtHRLvEdacOsBNQpYTj,'title':args.get('title'),'img':args.get('thumbnail'),}
    AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.Save_Watched_List(AwKqmbxWiSfFtHRLvEdacOsBNQpYrX,AwKqmbxWiSfFtHRLvEdacOsBNQpYDj)
   elif AwKqmbxWiSfFtHRLvEdacOsBNQpYTj=='EPISODE':
    AwKqmbxWiSfFtHRLvEdacOsBNQpYrX='tvshow'
    AwKqmbxWiSfFtHRLvEdacOsBNQpYDj={'code':args.get('programid'),'asis':AwKqmbxWiSfFtHRLvEdacOsBNQpYTj,'title':'%s <%s>'%(args.get('title'),args.get('programnm')),'img':args.get('programimg'),}
    AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.Save_Watched_List(AwKqmbxWiSfFtHRLvEdacOsBNQpYrX,AwKqmbxWiSfFtHRLvEdacOsBNQpYDj)
  except:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYUM
 def dp_Global_Search(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,args):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYTh=args.get('mode')
  if AwKqmbxWiSfFtHRLvEdacOsBNQpYTh=='TOTAL_SEARCH':
   AwKqmbxWiSfFtHRLvEdacOsBNQpYro='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYro='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(AwKqmbxWiSfFtHRLvEdacOsBNQpYro)
 def dp_Bookmark_Menu(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,args):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYro='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(AwKqmbxWiSfFtHRLvEdacOsBNQpYro)
 def dp_Search_List(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,args):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYTX =AwKqmbxWiSfFtHRLvEdacOsBNQpYUe(args.get('page'))
  if 'search_key' in args:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYrP=args.get('search_key')
  else:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYrP=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.get_keyboard_input(__language__(30908).encode('utf-8'))
   if not AwKqmbxWiSfFtHRLvEdacOsBNQpYrP:
    return
  AwKqmbxWiSfFtHRLvEdacOsBNQpYru,AwKqmbxWiSfFtHRLvEdacOsBNQpYTo=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.Get_Search_List(AwKqmbxWiSfFtHRLvEdacOsBNQpYrP,AwKqmbxWiSfFtHRLvEdacOsBNQpYTX)
  for AwKqmbxWiSfFtHRLvEdacOsBNQpYrz in AwKqmbxWiSfFtHRLvEdacOsBNQpYru:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYUz =AwKqmbxWiSfFtHRLvEdacOsBNQpYrz.get('id')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDr =AwKqmbxWiSfFtHRLvEdacOsBNQpYrz.get('title')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTj =AwKqmbxWiSfFtHRLvEdacOsBNQpYrz.get('asis')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTy =AwKqmbxWiSfFtHRLvEdacOsBNQpYrz.get('thumbnail')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTP =AwKqmbxWiSfFtHRLvEdacOsBNQpYrz.get('mpaa')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTz =AwKqmbxWiSfFtHRLvEdacOsBNQpYrz.get('year')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTe =AwKqmbxWiSfFtHRLvEdacOsBNQpYrz.get('duration')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTu =AwKqmbxWiSfFtHRLvEdacOsBNQpYrz.get('badge')
   if AwKqmbxWiSfFtHRLvEdacOsBNQpYTj=='TVSHOW': 
    AwKqmbxWiSfFtHRLvEdacOsBNQpYTh ='SEASON_LIST'
    AwKqmbxWiSfFtHRLvEdacOsBNQpYTV={'mediatype':'tvshow','title':AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,'mpaa':AwKqmbxWiSfFtHRLvEdacOsBNQpYTP,'year':AwKqmbxWiSfFtHRLvEdacOsBNQpYTz,'plot':'Year : %s'%(AwKqmbxWiSfFtHRLvEdacOsBNQpYTz),}
    AwKqmbxWiSfFtHRLvEdacOsBNQpYDG =AwKqmbxWiSfFtHRLvEdacOsBNQpYUj
   elif AwKqmbxWiSfFtHRLvEdacOsBNQpYTj=='MOVIE':
    AwKqmbxWiSfFtHRLvEdacOsBNQpYTh ='MOVIE'
    AwKqmbxWiSfFtHRLvEdacOsBNQpYTV={'mediatype':'movie','title':AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,'mpaa':AwKqmbxWiSfFtHRLvEdacOsBNQpYTP,'duration':AwKqmbxWiSfFtHRLvEdacOsBNQpYTe,'year':AwKqmbxWiSfFtHRLvEdacOsBNQpYTz,'plot':'(%s)'%(AwKqmbxWiSfFtHRLvEdacOsBNQpYTP),}
    AwKqmbxWiSfFtHRLvEdacOsBNQpYDG =AwKqmbxWiSfFtHRLvEdacOsBNQpYUy
    AwKqmbxWiSfFtHRLvEdacOsBNQpYDr +=' (%s)'%(AwKqmbxWiSfFtHRLvEdacOsBNQpYUu(AwKqmbxWiSfFtHRLvEdacOsBNQpYTz))
   elif AwKqmbxWiSfFtHRLvEdacOsBNQpYTj=='HIGHLIGHT':
    AwKqmbxWiSfFtHRLvEdacOsBNQpYTh ='HIGHLIGHT'
    AwKqmbxWiSfFtHRLvEdacOsBNQpYTV={'mediatype':'episode','title':AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,'duration':AwKqmbxWiSfFtHRLvEdacOsBNQpYTe,'plot':AwKqmbxWiSfFtHRLvEdacOsBNQpYTh,}
    AwKqmbxWiSfFtHRLvEdacOsBNQpYDG =AwKqmbxWiSfFtHRLvEdacOsBNQpYUy
   elif AwKqmbxWiSfFtHRLvEdacOsBNQpYTj=='LIVE':
    AwKqmbxWiSfFtHRLvEdacOsBNQpYTh ='LIVE'
    AwKqmbxWiSfFtHRLvEdacOsBNQpYTV={'mediatype':'episode','title':AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,'plot':AwKqmbxWiSfFtHRLvEdacOsBNQpYTh,}
    AwKqmbxWiSfFtHRLvEdacOsBNQpYDG =AwKqmbxWiSfFtHRLvEdacOsBNQpYUy
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj={'mode':AwKqmbxWiSfFtHRLvEdacOsBNQpYTh,'id':AwKqmbxWiSfFtHRLvEdacOsBNQpYUz,'asis':AwKqmbxWiSfFtHRLvEdacOsBNQpYTj,'seasonList':'','title':AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,'thumbnail':json.dumps(AwKqmbxWiSfFtHRLvEdacOsBNQpYTy,separators=(',',':')),'year':AwKqmbxWiSfFtHRLvEdacOsBNQpYTz,}
   if AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.get_settings_makebookmark()and AwKqmbxWiSfFtHRLvEdacOsBNQpYTj not in['HIGHLIGHT','']:
    AwKqmbxWiSfFtHRLvEdacOsBNQpYlg={'videoid':AwKqmbxWiSfFtHRLvEdacOsBNQpYUz,'vidtype':'movie' if AwKqmbxWiSfFtHRLvEdacOsBNQpYTj=='MOVIE' else 'tvshow','vtitle':AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,'vsubtitle':'',}
    AwKqmbxWiSfFtHRLvEdacOsBNQpYlD=json.dumps(AwKqmbxWiSfFtHRLvEdacOsBNQpYlg)
    AwKqmbxWiSfFtHRLvEdacOsBNQpYlD=urllib.parse.quote(AwKqmbxWiSfFtHRLvEdacOsBNQpYlD)
    AwKqmbxWiSfFtHRLvEdacOsBNQpYlT='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(AwKqmbxWiSfFtHRLvEdacOsBNQpYlD)
    AwKqmbxWiSfFtHRLvEdacOsBNQpYlr=[('(통합) 찜 영상에 추가',AwKqmbxWiSfFtHRLvEdacOsBNQpYlT)]
   else:
    AwKqmbxWiSfFtHRLvEdacOsBNQpYlr=AwKqmbxWiSfFtHRLvEdacOsBNQpYUM
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.add_dir(AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,sublabel=AwKqmbxWiSfFtHRLvEdacOsBNQpYTu,img=AwKqmbxWiSfFtHRLvEdacOsBNQpYTy,infoLabels=AwKqmbxWiSfFtHRLvEdacOsBNQpYTV,isFolder=AwKqmbxWiSfFtHRLvEdacOsBNQpYDG,params=AwKqmbxWiSfFtHRLvEdacOsBNQpYDj,ContextMenu=AwKqmbxWiSfFtHRLvEdacOsBNQpYlr)
  if AwKqmbxWiSfFtHRLvEdacOsBNQpYTo:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj={}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj['mode'] ='LOCAL_SEARCH'
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj['search_key']=AwKqmbxWiSfFtHRLvEdacOsBNQpYrP
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj['page'] =AwKqmbxWiSfFtHRLvEdacOsBNQpYUu(AwKqmbxWiSfFtHRLvEdacOsBNQpYTX+1)
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDr='[B]%s >>[/B]'%'다음 페이지'
   AwKqmbxWiSfFtHRLvEdacOsBNQpYln=AwKqmbxWiSfFtHRLvEdacOsBNQpYUu(AwKqmbxWiSfFtHRLvEdacOsBNQpYTX+1)
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDy=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.add_dir(AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,sublabel=AwKqmbxWiSfFtHRLvEdacOsBNQpYln,img=AwKqmbxWiSfFtHRLvEdacOsBNQpYDy,infoLabels=AwKqmbxWiSfFtHRLvEdacOsBNQpYUM,isFolder=AwKqmbxWiSfFtHRLvEdacOsBNQpYUj,params=AwKqmbxWiSfFtHRLvEdacOsBNQpYDj)
  xbmcplugin.setContent(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,'movies')
  xbmcplugin.endOfDirectory(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,cacheToDisc=AwKqmbxWiSfFtHRLvEdacOsBNQpYUj)
  if args.get('historyyn')=='Y':AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.Save_Searched_List(AwKqmbxWiSfFtHRLvEdacOsBNQpYrP)
 def Load_List_File(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,AwKqmbxWiSfFtHRLvEdacOsBNQpYrX): 
  try:
   if AwKqmbxWiSfFtHRLvEdacOsBNQpYrX=='search':
    AwKqmbxWiSfFtHRLvEdacOsBNQpYrJ=AwKqmbxWiSfFtHRLvEdacOsBNQpYgn
   elif AwKqmbxWiSfFtHRLvEdacOsBNQpYrX in['tvshow','movie']:
    AwKqmbxWiSfFtHRLvEdacOsBNQpYrJ=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%AwKqmbxWiSfFtHRLvEdacOsBNQpYrX))
   else:
    return[]
   fp=AwKqmbxWiSfFtHRLvEdacOsBNQpYUo(AwKqmbxWiSfFtHRLvEdacOsBNQpYrJ,'r',-1,'utf-8')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYrC=fp.readlines()
   fp.close()
  except:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYrC=[]
  return AwKqmbxWiSfFtHRLvEdacOsBNQpYrC
 def Save_Watched_List(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,AwKqmbxWiSfFtHRLvEdacOsBNQpYrX,AwKqmbxWiSfFtHRLvEdacOsBNQpYgy):
  try:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYrh=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%AwKqmbxWiSfFtHRLvEdacOsBNQpYrX))
   AwKqmbxWiSfFtHRLvEdacOsBNQpYng=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.Load_List_File(AwKqmbxWiSfFtHRLvEdacOsBNQpYrX) 
   fp=AwKqmbxWiSfFtHRLvEdacOsBNQpYUo(AwKqmbxWiSfFtHRLvEdacOsBNQpYrh,'w',-1,'utf-8')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYnD=urllib.parse.urlencode(AwKqmbxWiSfFtHRLvEdacOsBNQpYgy)
   AwKqmbxWiSfFtHRLvEdacOsBNQpYnD=AwKqmbxWiSfFtHRLvEdacOsBNQpYnD+'\n'
   fp.write(AwKqmbxWiSfFtHRLvEdacOsBNQpYnD)
   AwKqmbxWiSfFtHRLvEdacOsBNQpYnT=0
   for AwKqmbxWiSfFtHRLvEdacOsBNQpYnl in AwKqmbxWiSfFtHRLvEdacOsBNQpYng:
    AwKqmbxWiSfFtHRLvEdacOsBNQpYnr=AwKqmbxWiSfFtHRLvEdacOsBNQpYUI(urllib.parse.parse_qsl(AwKqmbxWiSfFtHRLvEdacOsBNQpYnl))
    AwKqmbxWiSfFtHRLvEdacOsBNQpYnV=AwKqmbxWiSfFtHRLvEdacOsBNQpYgy.get('code').strip()
    AwKqmbxWiSfFtHRLvEdacOsBNQpYnU=AwKqmbxWiSfFtHRLvEdacOsBNQpYnr.get('code').strip()
    if AwKqmbxWiSfFtHRLvEdacOsBNQpYnV!=AwKqmbxWiSfFtHRLvEdacOsBNQpYnU:
     fp.write(AwKqmbxWiSfFtHRLvEdacOsBNQpYnl)
     AwKqmbxWiSfFtHRLvEdacOsBNQpYnT+=1
     if AwKqmbxWiSfFtHRLvEdacOsBNQpYnT>=50:break
   fp.close()
  except:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYUM
 def Save_Searched_List(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,AwKqmbxWiSfFtHRLvEdacOsBNQpYrP):
  try:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYrP=AwKqmbxWiSfFtHRLvEdacOsBNQpYrP.strip()
   AwKqmbxWiSfFtHRLvEdacOsBNQpYng=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.Load_List_File('search') 
   fp=AwKqmbxWiSfFtHRLvEdacOsBNQpYUo(AwKqmbxWiSfFtHRLvEdacOsBNQpYgn,'w',-1,'utf-8')
   fp.write(AwKqmbxWiSfFtHRLvEdacOsBNQpYrP+'\n')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYnT=0
   for AwKqmbxWiSfFtHRLvEdacOsBNQpYnl in AwKqmbxWiSfFtHRLvEdacOsBNQpYng:
    AwKqmbxWiSfFtHRLvEdacOsBNQpYnl=AwKqmbxWiSfFtHRLvEdacOsBNQpYnl.strip()
    if AwKqmbxWiSfFtHRLvEdacOsBNQpYrP!=AwKqmbxWiSfFtHRLvEdacOsBNQpYnl:
     fp.write(AwKqmbxWiSfFtHRLvEdacOsBNQpYnl+'\n')
     AwKqmbxWiSfFtHRLvEdacOsBNQpYnT+=1
     if AwKqmbxWiSfFtHRLvEdacOsBNQpYnT>=50:break
   fp.close()
  except:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYUM
 def dp_Search_History(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,args):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYnM=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.Load_List_File('search')
  for AwKqmbxWiSfFtHRLvEdacOsBNQpYny in AwKqmbxWiSfFtHRLvEdacOsBNQpYnM:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYny=AwKqmbxWiSfFtHRLvEdacOsBNQpYny.strip()
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj={'mode':'LOCAL_SEARCH','search_key':AwKqmbxWiSfFtHRLvEdacOsBNQpYny,'page':'1','historyyn':'Y',}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYnj={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','skey':AwKqmbxWiSfFtHRLvEdacOsBNQpYny,'vType':'-',}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYnG=urllib.parse.urlencode(AwKqmbxWiSfFtHRLvEdacOsBNQpYnj)
   AwKqmbxWiSfFtHRLvEdacOsBNQpYlr=[('선택된 검색어 ( %s ) 삭제'%(AwKqmbxWiSfFtHRLvEdacOsBNQpYny),'RunPlugin(plugin://plugin.video.coupangm/?%s)'%(AwKqmbxWiSfFtHRLvEdacOsBNQpYnG))]
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.add_dir(AwKqmbxWiSfFtHRLvEdacOsBNQpYny,sublabel='',img=AwKqmbxWiSfFtHRLvEdacOsBNQpYUM,infoLabels=AwKqmbxWiSfFtHRLvEdacOsBNQpYUM,isFolder=AwKqmbxWiSfFtHRLvEdacOsBNQpYUj,params=AwKqmbxWiSfFtHRLvEdacOsBNQpYDj,ContextMenu=AwKqmbxWiSfFtHRLvEdacOsBNQpYlr)
  AwKqmbxWiSfFtHRLvEdacOsBNQpYTV={'plot':'검색목록 전체를 삭제합니다.'}
  AwKqmbxWiSfFtHRLvEdacOsBNQpYDr='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  AwKqmbxWiSfFtHRLvEdacOsBNQpYDj={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  AwKqmbxWiSfFtHRLvEdacOsBNQpYDy=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.add_dir(AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,sublabel='',img=AwKqmbxWiSfFtHRLvEdacOsBNQpYDy,infoLabels=AwKqmbxWiSfFtHRLvEdacOsBNQpYTV,isFolder=AwKqmbxWiSfFtHRLvEdacOsBNQpYUy,params=AwKqmbxWiSfFtHRLvEdacOsBNQpYDj,isLink=AwKqmbxWiSfFtHRLvEdacOsBNQpYUj)
  xbmcplugin.endOfDirectory(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,cacheToDisc=AwKqmbxWiSfFtHRLvEdacOsBNQpYUy)
 def dp_Listfile_Delete(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,args):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYnI=args.get('delType')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYnk =args.get('skey')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYTD =args.get('vType')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYgG=xbmcgui.Dialog()
  if AwKqmbxWiSfFtHRLvEdacOsBNQpYnI=='SEARCH_ALL':
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDX=AwKqmbxWiSfFtHRLvEdacOsBNQpYgG.yesno(__language__(30911).encode('utf8'),__language__(30906).encode('utf8'))
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYnI=='SEARCH_ONE':
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDX=AwKqmbxWiSfFtHRLvEdacOsBNQpYgG.yesno(__language__(30912).encode('utf8'),__language__(30906).encode('utf8'))
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYnI=='WATCH_ALL':
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDX=AwKqmbxWiSfFtHRLvEdacOsBNQpYgG.yesno(__language__(30913).encode('utf8'),__language__(30906).encode('utf8'))
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYnI=='WATCH_ONE':
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDX=AwKqmbxWiSfFtHRLvEdacOsBNQpYgG.yesno(__language__(30916).encode('utf8'),__language__(30906).encode('utf8'))
  if AwKqmbxWiSfFtHRLvEdacOsBNQpYDX==AwKqmbxWiSfFtHRLvEdacOsBNQpYUy:sys.exit()
  if AwKqmbxWiSfFtHRLvEdacOsBNQpYnI=='SEARCH_ALL':
   if os.path.isfile(AwKqmbxWiSfFtHRLvEdacOsBNQpYgn):os.remove(AwKqmbxWiSfFtHRLvEdacOsBNQpYgn)
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYnI=='SEARCH_ONE':
   try:
    AwKqmbxWiSfFtHRLvEdacOsBNQpYrJ=AwKqmbxWiSfFtHRLvEdacOsBNQpYgn
    AwKqmbxWiSfFtHRLvEdacOsBNQpYng=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.Load_List_File('search') 
    fp=AwKqmbxWiSfFtHRLvEdacOsBNQpYUo(AwKqmbxWiSfFtHRLvEdacOsBNQpYrJ,'w',-1,'utf-8')
    for AwKqmbxWiSfFtHRLvEdacOsBNQpYnl in AwKqmbxWiSfFtHRLvEdacOsBNQpYng:
     if AwKqmbxWiSfFtHRLvEdacOsBNQpYnk!=AwKqmbxWiSfFtHRLvEdacOsBNQpYnl.strip():
      fp.write(AwKqmbxWiSfFtHRLvEdacOsBNQpYnl)
    fp.close()
   except:
    AwKqmbxWiSfFtHRLvEdacOsBNQpYUM
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYnI=='WATCH_ALL':
   AwKqmbxWiSfFtHRLvEdacOsBNQpYrJ=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%AwKqmbxWiSfFtHRLvEdacOsBNQpYTD))
   if os.path.isfile(AwKqmbxWiSfFtHRLvEdacOsBNQpYrJ):os.remove(AwKqmbxWiSfFtHRLvEdacOsBNQpYrJ)
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYnI=='WATCH_ONE':
   AwKqmbxWiSfFtHRLvEdacOsBNQpYrJ=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%AwKqmbxWiSfFtHRLvEdacOsBNQpYTD))
   try:
    AwKqmbxWiSfFtHRLvEdacOsBNQpYng=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.Load_List_File(AwKqmbxWiSfFtHRLvEdacOsBNQpYTD) 
    fp=AwKqmbxWiSfFtHRLvEdacOsBNQpYUo(AwKqmbxWiSfFtHRLvEdacOsBNQpYrJ,'w',-1,'utf-8')
    for AwKqmbxWiSfFtHRLvEdacOsBNQpYnl in AwKqmbxWiSfFtHRLvEdacOsBNQpYng:
     AwKqmbxWiSfFtHRLvEdacOsBNQpYnr=AwKqmbxWiSfFtHRLvEdacOsBNQpYUI(urllib.parse.parse_qsl(AwKqmbxWiSfFtHRLvEdacOsBNQpYnl))
     AwKqmbxWiSfFtHRLvEdacOsBNQpYne=AwKqmbxWiSfFtHRLvEdacOsBNQpYnr.get('code').strip()
     if AwKqmbxWiSfFtHRLvEdacOsBNQpYnk!=AwKqmbxWiSfFtHRLvEdacOsBNQpYne:
      fp.write(AwKqmbxWiSfFtHRLvEdacOsBNQpYnl)
    fp.close()
   except:
    AwKqmbxWiSfFtHRLvEdacOsBNQpYUM
  xbmc.executebuiltin("Container.Refresh")
 def Delete_List_File(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,AwKqmbxWiSfFtHRLvEdacOsBNQpYrX,skey='-'):
  if AwKqmbxWiSfFtHRLvEdacOsBNQpYrX=='ALL':
   try:
    AwKqmbxWiSfFtHRLvEdacOsBNQpYrJ=AwKqmbxWiSfFtHRLvEdacOsBNQpYgn
    fp=AwKqmbxWiSfFtHRLvEdacOsBNQpYUo(AwKqmbxWiSfFtHRLvEdacOsBNQpYrJ,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    AwKqmbxWiSfFtHRLvEdacOsBNQpYUM
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYrX=='ONE':
   try:
    AwKqmbxWiSfFtHRLvEdacOsBNQpYrJ=AwKqmbxWiSfFtHRLvEdacOsBNQpYgn
    AwKqmbxWiSfFtHRLvEdacOsBNQpYng=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.Load_List_File('search') 
    fp=AwKqmbxWiSfFtHRLvEdacOsBNQpYUo(AwKqmbxWiSfFtHRLvEdacOsBNQpYrJ,'w',-1,'utf-8')
    for AwKqmbxWiSfFtHRLvEdacOsBNQpYnl in AwKqmbxWiSfFtHRLvEdacOsBNQpYng:
     if skey!=AwKqmbxWiSfFtHRLvEdacOsBNQpYnl.strip():
      fp.write(AwKqmbxWiSfFtHRLvEdacOsBNQpYnl)
    fp.close()
   except:
    AwKqmbxWiSfFtHRLvEdacOsBNQpYUM
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYrX in['tvshow','movie']:
   try:
    AwKqmbxWiSfFtHRLvEdacOsBNQpYrJ=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%AwKqmbxWiSfFtHRLvEdacOsBNQpYrX))
    fp=AwKqmbxWiSfFtHRLvEdacOsBNQpYUo(AwKqmbxWiSfFtHRLvEdacOsBNQpYrJ,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    AwKqmbxWiSfFtHRLvEdacOsBNQpYUM
 def dp_Watch_List(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,args):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYrX =args.get('stype')
  if AwKqmbxWiSfFtHRLvEdacOsBNQpYrX in['',AwKqmbxWiSfFtHRLvEdacOsBNQpYUM]:
   for AwKqmbxWiSfFtHRLvEdacOsBNQpYnX in AwKqmbxWiSfFtHRLvEdacOsBNQpYgl:
    AwKqmbxWiSfFtHRLvEdacOsBNQpYDr=AwKqmbxWiSfFtHRLvEdacOsBNQpYnX.get('title')
    AwKqmbxWiSfFtHRLvEdacOsBNQpYDj={'mode':AwKqmbxWiSfFtHRLvEdacOsBNQpYnX.get('mode'),'stype':AwKqmbxWiSfFtHRLvEdacOsBNQpYnX.get('stype'),}
    AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.add_dir(AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,sublabel='',img='',infoLabels=AwKqmbxWiSfFtHRLvEdacOsBNQpYUM,isFolder=AwKqmbxWiSfFtHRLvEdacOsBNQpYUj,params=AwKqmbxWiSfFtHRLvEdacOsBNQpYDj)
   xbmcplugin.endOfDirectory(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle)
  else:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYno=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.Load_List_File(AwKqmbxWiSfFtHRLvEdacOsBNQpYrX)
   for AwKqmbxWiSfFtHRLvEdacOsBNQpYnP in AwKqmbxWiSfFtHRLvEdacOsBNQpYno:
    AwKqmbxWiSfFtHRLvEdacOsBNQpYnu=AwKqmbxWiSfFtHRLvEdacOsBNQpYUI(urllib.parse.parse_qsl(AwKqmbxWiSfFtHRLvEdacOsBNQpYnP))
    AwKqmbxWiSfFtHRLvEdacOsBNQpYlz =AwKqmbxWiSfFtHRLvEdacOsBNQpYnu.get('code').strip()
    AwKqmbxWiSfFtHRLvEdacOsBNQpYDr =AwKqmbxWiSfFtHRLvEdacOsBNQpYnu.get('title').strip()
    AwKqmbxWiSfFtHRLvEdacOsBNQpYTy =AwKqmbxWiSfFtHRLvEdacOsBNQpYnu.get('img').strip()
    AwKqmbxWiSfFtHRLvEdacOsBNQpYTj =AwKqmbxWiSfFtHRLvEdacOsBNQpYnu.get('asis').strip()
    try:
     AwKqmbxWiSfFtHRLvEdacOsBNQpYTy=AwKqmbxWiSfFtHRLvEdacOsBNQpYTy.replace('\'','\"')
     AwKqmbxWiSfFtHRLvEdacOsBNQpYTy=json.loads(AwKqmbxWiSfFtHRLvEdacOsBNQpYTy)
    except:
     AwKqmbxWiSfFtHRLvEdacOsBNQpYUM
    AwKqmbxWiSfFtHRLvEdacOsBNQpYTV={}
    AwKqmbxWiSfFtHRLvEdacOsBNQpYTV['plot']=AwKqmbxWiSfFtHRLvEdacOsBNQpYDr
    if AwKqmbxWiSfFtHRLvEdacOsBNQpYrX=='movie':
     AwKqmbxWiSfFtHRLvEdacOsBNQpYTV['mediatype']='movie'
     AwKqmbxWiSfFtHRLvEdacOsBNQpYDj={'mode':'MOVIE','id':AwKqmbxWiSfFtHRLvEdacOsBNQpYlz,'asis':AwKqmbxWiSfFtHRLvEdacOsBNQpYTj,'title':AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,'thumbnail':AwKqmbxWiSfFtHRLvEdacOsBNQpYTy,}
     AwKqmbxWiSfFtHRLvEdacOsBNQpYDG=AwKqmbxWiSfFtHRLvEdacOsBNQpYUy
    else:
     AwKqmbxWiSfFtHRLvEdacOsBNQpYTV['mediatype']='episode'
     AwKqmbxWiSfFtHRLvEdacOsBNQpYDj={'mode':'SEASON_LIST','id':AwKqmbxWiSfFtHRLvEdacOsBNQpYlz,'asis':AwKqmbxWiSfFtHRLvEdacOsBNQpYTj,'title':AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,'thumbnail':json.dumps(AwKqmbxWiSfFtHRLvEdacOsBNQpYTy,separators=(',',':')),}
     AwKqmbxWiSfFtHRLvEdacOsBNQpYDG=AwKqmbxWiSfFtHRLvEdacOsBNQpYUj
    AwKqmbxWiSfFtHRLvEdacOsBNQpYnj={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','skey':AwKqmbxWiSfFtHRLvEdacOsBNQpYlz,'vType':AwKqmbxWiSfFtHRLvEdacOsBNQpYrX,}
    AwKqmbxWiSfFtHRLvEdacOsBNQpYnG=urllib.parse.urlencode(AwKqmbxWiSfFtHRLvEdacOsBNQpYnj)
    AwKqmbxWiSfFtHRLvEdacOsBNQpYlr=[('선택된 시청이력 ( %s ) 삭제'%(AwKqmbxWiSfFtHRLvEdacOsBNQpYDr),'RunPlugin(plugin://plugin.video.coupangm/?%s)'%(AwKqmbxWiSfFtHRLvEdacOsBNQpYnG))]
    AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.add_dir(AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,sublabel='',img=AwKqmbxWiSfFtHRLvEdacOsBNQpYTy,infoLabels=AwKqmbxWiSfFtHRLvEdacOsBNQpYTV,isFolder=AwKqmbxWiSfFtHRLvEdacOsBNQpYDG,params=AwKqmbxWiSfFtHRLvEdacOsBNQpYDj,ContextMenu=AwKqmbxWiSfFtHRLvEdacOsBNQpYlr)
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTV={'plot':'시청목록을 삭제합니다.'}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDr='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':AwKqmbxWiSfFtHRLvEdacOsBNQpYrX,}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDy=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.add_dir(AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,sublabel='',img=AwKqmbxWiSfFtHRLvEdacOsBNQpYDy,infoLabels=AwKqmbxWiSfFtHRLvEdacOsBNQpYTV,isFolder=AwKqmbxWiSfFtHRLvEdacOsBNQpYUy,params=AwKqmbxWiSfFtHRLvEdacOsBNQpYDj,isLink=AwKqmbxWiSfFtHRLvEdacOsBNQpYUj)
   if AwKqmbxWiSfFtHRLvEdacOsBNQpYrX=='movie':xbmcplugin.setContent(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,'movies')
   else:xbmcplugin.setContent(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,cacheToDisc=AwKqmbxWiSfFtHRLvEdacOsBNQpYUy)
 def dp_Set_Bookmark(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,args):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYnz=urllib.parse.unquote(args.get('bm_param'))
  AwKqmbxWiSfFtHRLvEdacOsBNQpYnz=json.loads(AwKqmbxWiSfFtHRLvEdacOsBNQpYnz)
  AwKqmbxWiSfFtHRLvEdacOsBNQpYnJ =AwKqmbxWiSfFtHRLvEdacOsBNQpYnz.get('videoid')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYnC =AwKqmbxWiSfFtHRLvEdacOsBNQpYnz.get('vidtype')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYnh =AwKqmbxWiSfFtHRLvEdacOsBNQpYnz.get('vtitle')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYgG=xbmcgui.Dialog()
  AwKqmbxWiSfFtHRLvEdacOsBNQpYDX=AwKqmbxWiSfFtHRLvEdacOsBNQpYgG.yesno(__language__(30914).encode('utf8'),AwKqmbxWiSfFtHRLvEdacOsBNQpYnh+' \n\n'+__language__(30915))
  if AwKqmbxWiSfFtHRLvEdacOsBNQpYDX==AwKqmbxWiSfFtHRLvEdacOsBNQpYUy:return
  AwKqmbxWiSfFtHRLvEdacOsBNQpYVg=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.GetBookmarkInfo(AwKqmbxWiSfFtHRLvEdacOsBNQpYnJ,AwKqmbxWiSfFtHRLvEdacOsBNQpYnC)
  AwKqmbxWiSfFtHRLvEdacOsBNQpYVD=json.dumps(AwKqmbxWiSfFtHRLvEdacOsBNQpYVg)
  AwKqmbxWiSfFtHRLvEdacOsBNQpYVD=urllib.parse.quote(AwKqmbxWiSfFtHRLvEdacOsBNQpYVD)
  AwKqmbxWiSfFtHRLvEdacOsBNQpYlT ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(AwKqmbxWiSfFtHRLvEdacOsBNQpYVD)
  xbmc.executebuiltin(AwKqmbxWiSfFtHRLvEdacOsBNQpYlT)
 def sp_MultiHero_LiveList(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,args):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYVT=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.Sports_MultiHero_LiveList()
  for AwKqmbxWiSfFtHRLvEdacOsBNQpYVl in AwKqmbxWiSfFtHRLvEdacOsBNQpYVT:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYUz =AwKqmbxWiSfFtHRLvEdacOsBNQpYVl.get('id')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDr =AwKqmbxWiSfFtHRLvEdacOsBNQpYVl.get('title')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYVr =AwKqmbxWiSfFtHRLvEdacOsBNQpYVl.get('startDate')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYVn =AwKqmbxWiSfFtHRLvEdacOsBNQpYVl.get('image')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYVU =AwKqmbxWiSfFtHRLvEdacOsBNQpYVl.get('subType') 
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDe=AwKqmbxWiSfFtHRLvEdacOsBNQpYVr
   if AwKqmbxWiSfFtHRLvEdacOsBNQpYVU:AwKqmbxWiSfFtHRLvEdacOsBNQpYDe=AwKqmbxWiSfFtHRLvEdacOsBNQpYDe+', '+AwKqmbxWiSfFtHRLvEdacOsBNQpYVU
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTV={'mediatype':'episodes','plot':AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj={'mode':'LIVE','asis':'LIVE','id':AwKqmbxWiSfFtHRLvEdacOsBNQpYUz,}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.add_dir(AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,sublabel=AwKqmbxWiSfFtHRLvEdacOsBNQpYDe,img=AwKqmbxWiSfFtHRLvEdacOsBNQpYVn,infoLabels=AwKqmbxWiSfFtHRLvEdacOsBNQpYTV,isFolder=AwKqmbxWiSfFtHRLvEdacOsBNQpYUy,params=AwKqmbxWiSfFtHRLvEdacOsBNQpYDj)
  xbmcplugin.setContent(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,cacheToDisc=AwKqmbxWiSfFtHRLvEdacOsBNQpYUy)
 def sp_Mainlist_League(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,args):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYVT=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.Sports_MultiHero_LiveList()
  if AwKqmbxWiSfFtHRLvEdacOsBNQpYVT:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDr ='@ 주요 예정경기 @'
   AwKqmbxWiSfFtHRLvEdacOsBNQpYVn =AwKqmbxWiSfFtHRLvEdacOsBNQpYVT[0]['image']
   AwKqmbxWiSfFtHRLvEdacOsBNQpYVM =AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.MakeText_FreeList(AwKqmbxWiSfFtHRLvEdacOsBNQpYVT,titleName='preTitle')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTV={'mediatype':'episodes','plot':AwKqmbxWiSfFtHRLvEdacOsBNQpYVM,}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj={'mode':'SPORTS_MULT_HERO',}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.add_dir(AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,sublabel='',img=AwKqmbxWiSfFtHRLvEdacOsBNQpYVn,infoLabels=AwKqmbxWiSfFtHRLvEdacOsBNQpYTV,isFolder=AwKqmbxWiSfFtHRLvEdacOsBNQpYUj,params=AwKqmbxWiSfFtHRLvEdacOsBNQpYDj)
  AwKqmbxWiSfFtHRLvEdacOsBNQpYVy=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.Sports_Mainlist_League()
  for AwKqmbxWiSfFtHRLvEdacOsBNQpYVj in AwKqmbxWiSfFtHRLvEdacOsBNQpYVy:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYVG =AwKqmbxWiSfFtHRLvEdacOsBNQpYVj.get('league_id') 
   AwKqmbxWiSfFtHRLvEdacOsBNQpYVI=AwKqmbxWiSfFtHRLvEdacOsBNQpYVj.get('league_name')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYVk =AwKqmbxWiSfFtHRLvEdacOsBNQpYVj.get('logoUrl')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTV={'mediatype':'episodes','plot':AwKqmbxWiSfFtHRLvEdacOsBNQpYVI,}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj={'mode':'SPORTS_LEAGUE_FEEDLIST','league_id':AwKqmbxWiSfFtHRLvEdacOsBNQpYVG,'league_name':AwKqmbxWiSfFtHRLvEdacOsBNQpYVI,}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.add_dir(AwKqmbxWiSfFtHRLvEdacOsBNQpYVI,sublabel='',img=AwKqmbxWiSfFtHRLvEdacOsBNQpYVk,infoLabels=AwKqmbxWiSfFtHRLvEdacOsBNQpYTV,isFolder=AwKqmbxWiSfFtHRLvEdacOsBNQpYUj,params=AwKqmbxWiSfFtHRLvEdacOsBNQpYDj)
  xbmcplugin.setContent(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,cacheToDisc=AwKqmbxWiSfFtHRLvEdacOsBNQpYUy)
 def sp_League_FeedList(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,args):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYVG =args.get('league_id')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYVI=args.get('league_name')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYVe=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.Sports_League_FeedList(AwKqmbxWiSfFtHRLvEdacOsBNQpYVG)
  for AwKqmbxWiSfFtHRLvEdacOsBNQpYVj in AwKqmbxWiSfFtHRLvEdacOsBNQpYVe:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYVX=AwKqmbxWiSfFtHRLvEdacOsBNQpYVj.get('row_name')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYVM =AwKqmbxWiSfFtHRLvEdacOsBNQpYVj.get('preText')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYVo =AwKqmbxWiSfFtHRLvEdacOsBNQpYVj.get('subMode')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYVP =AwKqmbxWiSfFtHRLvEdacOsBNQpYVj.get('gameID')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYVn =AwKqmbxWiSfFtHRLvEdacOsBNQpYVj.get('image')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTV={'mediatype':'episodes','plot':AwKqmbxWiSfFtHRLvEdacOsBNQpYVI+'\n\n'+AwKqmbxWiSfFtHRLvEdacOsBNQpYVM,}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj={'mode':'SPORTS_FEED_VOD','subMode':AwKqmbxWiSfFtHRLvEdacOsBNQpYVo,'league_id':AwKqmbxWiSfFtHRLvEdacOsBNQpYVG,'game_id':AwKqmbxWiSfFtHRLvEdacOsBNQpYVP,}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.add_dir(AwKqmbxWiSfFtHRLvEdacOsBNQpYVX,sublabel='',img=AwKqmbxWiSfFtHRLvEdacOsBNQpYVn,infoLabels=AwKqmbxWiSfFtHRLvEdacOsBNQpYTV,isFolder=AwKqmbxWiSfFtHRLvEdacOsBNQpYUj,params=AwKqmbxWiSfFtHRLvEdacOsBNQpYDj)
  AwKqmbxWiSfFtHRLvEdacOsBNQpYDr='@ 시즌별 동영상 @'
  AwKqmbxWiSfFtHRLvEdacOsBNQpYTV={'mediatype':'episodes','plot':AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,}
  AwKqmbxWiSfFtHRLvEdacOsBNQpYDj={'mode':'SPORTS_SEASON_GROUP','league_id':AwKqmbxWiSfFtHRLvEdacOsBNQpYVG,}
  AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.add_dir(AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,sublabel='',img=AwKqmbxWiSfFtHRLvEdacOsBNQpYUM,infoLabels=AwKqmbxWiSfFtHRLvEdacOsBNQpYTV,isFolder=AwKqmbxWiSfFtHRLvEdacOsBNQpYUj,params=AwKqmbxWiSfFtHRLvEdacOsBNQpYDj)
  xbmcplugin.setContent(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,cacheToDisc=AwKqmbxWiSfFtHRLvEdacOsBNQpYUy)
 def sp_League_VodList(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,args):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYVo =args.get('subMode')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYVG =args.get('league_id')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYVu =args.get('game_id')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.addon_log('{} - {}'.format('subMode  ',AwKqmbxWiSfFtHRLvEdacOsBNQpYVo))
  AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.addon_log('{} - {}'.format('league_id',AwKqmbxWiSfFtHRLvEdacOsBNQpYVG))
  AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.addon_log('{} - {}'.format('game_id  ',AwKqmbxWiSfFtHRLvEdacOsBNQpYVu))
  AwKqmbxWiSfFtHRLvEdacOsBNQpYVz=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.Sports_League_VodList(AwKqmbxWiSfFtHRLvEdacOsBNQpYVo,AwKqmbxWiSfFtHRLvEdacOsBNQpYVG,AwKqmbxWiSfFtHRLvEdacOsBNQpYVu)
  for AwKqmbxWiSfFtHRLvEdacOsBNQpYVj in AwKqmbxWiSfFtHRLvEdacOsBNQpYVz:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYUz =AwKqmbxWiSfFtHRLvEdacOsBNQpYVj.get('id')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDr =AwKqmbxWiSfFtHRLvEdacOsBNQpYVj.get('title')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYVn =AwKqmbxWiSfFtHRLvEdacOsBNQpYVj.get('image')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYVr =AwKqmbxWiSfFtHRLvEdacOsBNQpYVj.get('startDate')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYVU =AwKqmbxWiSfFtHRLvEdacOsBNQpYVj.get('subType')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYVJ=AwKqmbxWiSfFtHRLvEdacOsBNQpYVj.get('running_time')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTV={'mediatype':'episodes','plot':AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,'duration':AwKqmbxWiSfFtHRLvEdacOsBNQpYVJ,}
   if AwKqmbxWiSfFtHRLvEdacOsBNQpYVo=='SP_FEED_LIVE':
    AwKqmbxWiSfFtHRLvEdacOsBNQpYDj={'mode':'LIVE','asis':'LIVE','id':AwKqmbxWiSfFtHRLvEdacOsBNQpYUz,}
    AwKqmbxWiSfFtHRLvEdacOsBNQpYDe=AwKqmbxWiSfFtHRLvEdacOsBNQpYVr
    if AwKqmbxWiSfFtHRLvEdacOsBNQpYVU:AwKqmbxWiSfFtHRLvEdacOsBNQpYDe=AwKqmbxWiSfFtHRLvEdacOsBNQpYDe+', '+AwKqmbxWiSfFtHRLvEdacOsBNQpYVU
   elif AwKqmbxWiSfFtHRLvEdacOsBNQpYVo in['SP_FEED_TOP10','SP_FEED_GAME']:
    AwKqmbxWiSfFtHRLvEdacOsBNQpYDj={'mode':'HIGHLIGHT','asis':'HIGHLIGHT','id':AwKqmbxWiSfFtHRLvEdacOsBNQpYUz,}
    AwKqmbxWiSfFtHRLvEdacOsBNQpYDe=AwKqmbxWiSfFtHRLvEdacOsBNQpYVU
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.add_dir(AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,sublabel=AwKqmbxWiSfFtHRLvEdacOsBNQpYDe,img=AwKqmbxWiSfFtHRLvEdacOsBNQpYVn,infoLabels=AwKqmbxWiSfFtHRLvEdacOsBNQpYTV,isFolder=AwKqmbxWiSfFtHRLvEdacOsBNQpYUy,params=AwKqmbxWiSfFtHRLvEdacOsBNQpYDj)
  xbmcplugin.setContent(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,cacheToDisc=AwKqmbxWiSfFtHRLvEdacOsBNQpYUy)
 def sp_Season_Group(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,args):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYVG =args.get('league_id')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYVC=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.Sports_Season_Group(AwKqmbxWiSfFtHRLvEdacOsBNQpYVG)
  for AwKqmbxWiSfFtHRLvEdacOsBNQpYVj in AwKqmbxWiSfFtHRLvEdacOsBNQpYVC:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYlG =AwKqmbxWiSfFtHRLvEdacOsBNQpYVj.get('season')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYVM =AwKqmbxWiSfFtHRLvEdacOsBNQpYVj.get('preText')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTV={'mediatype':'episodes','plot':AwKqmbxWiSfFtHRLvEdacOsBNQpYVM,}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj={'mode':'SPORTS_SEASON_GAMELIST','leagueID':AwKqmbxWiSfFtHRLvEdacOsBNQpYVG,'seasonID':AwKqmbxWiSfFtHRLvEdacOsBNQpYlG,'page':'1',}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.add_dir(AwKqmbxWiSfFtHRLvEdacOsBNQpYlG,sublabel=AwKqmbxWiSfFtHRLvEdacOsBNQpYUM,img=AwKqmbxWiSfFtHRLvEdacOsBNQpYUM,infoLabels=AwKqmbxWiSfFtHRLvEdacOsBNQpYTV,isFolder=AwKqmbxWiSfFtHRLvEdacOsBNQpYUj,params=AwKqmbxWiSfFtHRLvEdacOsBNQpYDj)
  xbmcplugin.setContent(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,cacheToDisc=AwKqmbxWiSfFtHRLvEdacOsBNQpYUy)
 def sp_Season_GameList(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,args):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYVh =args.get('leagueID')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYUg =args.get('seasonID')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYTX =AwKqmbxWiSfFtHRLvEdacOsBNQpYUe(args.get('page'))
  AwKqmbxWiSfFtHRLvEdacOsBNQpYUD=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.Sports_Season_GameList(AwKqmbxWiSfFtHRLvEdacOsBNQpYVh,AwKqmbxWiSfFtHRLvEdacOsBNQpYUg,AwKqmbxWiSfFtHRLvEdacOsBNQpYTX)
  AwKqmbxWiSfFtHRLvEdacOsBNQpYUT=AwKqmbxWiSfFtHRLvEdacOsBNQpYUJ(AwKqmbxWiSfFtHRLvEdacOsBNQpYUD)
  for AwKqmbxWiSfFtHRLvEdacOsBNQpYVj in AwKqmbxWiSfFtHRLvEdacOsBNQpYUD:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYVP =AwKqmbxWiSfFtHRLvEdacOsBNQpYVj.get('id')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDr =AwKqmbxWiSfFtHRLvEdacOsBNQpYVj.get('title')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYVr =AwKqmbxWiSfFtHRLvEdacOsBNQpYVj.get('startDate')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYVM =AwKqmbxWiSfFtHRLvEdacOsBNQpYVj.get('preText')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYVn =AwKqmbxWiSfFtHRLvEdacOsBNQpYVj.get('image')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTV={'mediatype':'episodes','plot':AwKqmbxWiSfFtHRLvEdacOsBNQpYVM,}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj={'mode':'SPORTS_SEASON_VODLIST','leagueID':AwKqmbxWiSfFtHRLvEdacOsBNQpYVh,'seasonID':AwKqmbxWiSfFtHRLvEdacOsBNQpYUg,'gameID':AwKqmbxWiSfFtHRLvEdacOsBNQpYVP,'page':args.get('page'),}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.add_dir(AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,sublabel=AwKqmbxWiSfFtHRLvEdacOsBNQpYVr,img=AwKqmbxWiSfFtHRLvEdacOsBNQpYVn,infoLabels=AwKqmbxWiSfFtHRLvEdacOsBNQpYTV,isFolder=AwKqmbxWiSfFtHRLvEdacOsBNQpYUj,params=AwKqmbxWiSfFtHRLvEdacOsBNQpYDj)
  if AwKqmbxWiSfFtHRLvEdacOsBNQpYUT>=10:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj['mode'] ='SPORTS_SEASON_GAMELIST' 
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj['leagueID']=AwKqmbxWiSfFtHRLvEdacOsBNQpYVh
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj['seasonID']=AwKqmbxWiSfFtHRLvEdacOsBNQpYUg
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj['page'] =AwKqmbxWiSfFtHRLvEdacOsBNQpYUu(AwKqmbxWiSfFtHRLvEdacOsBNQpYTX+1)
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDr='[B]%s >>[/B]'%'다음 페이지'
   AwKqmbxWiSfFtHRLvEdacOsBNQpYln=AwKqmbxWiSfFtHRLvEdacOsBNQpYUu(AwKqmbxWiSfFtHRLvEdacOsBNQpYTX+1)
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDy=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.add_dir(AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,sublabel=AwKqmbxWiSfFtHRLvEdacOsBNQpYln,img=AwKqmbxWiSfFtHRLvEdacOsBNQpYDy,infoLabels=AwKqmbxWiSfFtHRLvEdacOsBNQpYUM,isFolder=AwKqmbxWiSfFtHRLvEdacOsBNQpYUj,params=AwKqmbxWiSfFtHRLvEdacOsBNQpYDj)
  xbmcplugin.setContent(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,cacheToDisc=AwKqmbxWiSfFtHRLvEdacOsBNQpYUy)
 def sp_Season_VodList(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,args):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYVh =args.get('leagueID')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYUg =args.get('seasonID')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYTX =AwKqmbxWiSfFtHRLvEdacOsBNQpYUe(args.get('page'))
  AwKqmbxWiSfFtHRLvEdacOsBNQpYVP =args.get('gameID')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYVz=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.Sports_Season_GameVod(AwKqmbxWiSfFtHRLvEdacOsBNQpYVh,AwKqmbxWiSfFtHRLvEdacOsBNQpYUg,AwKqmbxWiSfFtHRLvEdacOsBNQpYTX,AwKqmbxWiSfFtHRLvEdacOsBNQpYVP)
  for AwKqmbxWiSfFtHRLvEdacOsBNQpYVj in AwKqmbxWiSfFtHRLvEdacOsBNQpYVz:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYUz =AwKqmbxWiSfFtHRLvEdacOsBNQpYVj.get('id')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDr =AwKqmbxWiSfFtHRLvEdacOsBNQpYVj.get('title')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYVn =AwKqmbxWiSfFtHRLvEdacOsBNQpYVj.get('image')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYVU =AwKqmbxWiSfFtHRLvEdacOsBNQpYVj.get('subType')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYVJ=AwKqmbxWiSfFtHRLvEdacOsBNQpYVj.get('running_time')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTV={'mediatype':'episodes','plot':AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,'duration':AwKqmbxWiSfFtHRLvEdacOsBNQpYVJ,}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj={'mode':'HIGHLIGHT','asis':'HIGHLIGHT','id':AwKqmbxWiSfFtHRLvEdacOsBNQpYUz,}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDe=AwKqmbxWiSfFtHRLvEdacOsBNQpYVU
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.add_dir(AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,sublabel=AwKqmbxWiSfFtHRLvEdacOsBNQpYDe,img=AwKqmbxWiSfFtHRLvEdacOsBNQpYVn,infoLabels=AwKqmbxWiSfFtHRLvEdacOsBNQpYTV,isFolder=AwKqmbxWiSfFtHRLvEdacOsBNQpYUy,params=AwKqmbxWiSfFtHRLvEdacOsBNQpYDj)
  xbmcplugin.setContent(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,cacheToDisc=AwKqmbxWiSfFtHRLvEdacOsBNQpYUy)
 def dp_Pass_Group(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,args):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYTM =args.get('collectionId')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYUl=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.Get_Pass_GroupList(AwKqmbxWiSfFtHRLvEdacOsBNQpYTM)
  for AwKqmbxWiSfFtHRLvEdacOsBNQpYVj in AwKqmbxWiSfFtHRLvEdacOsBNQpYUl:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYUr =AwKqmbxWiSfFtHRLvEdacOsBNQpYVj.get('obj_id')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDr =AwKqmbxWiSfFtHRLvEdacOsBNQpYVj.get('title')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYVM =AwKqmbxWiSfFtHRLvEdacOsBNQpYVj.get('preText')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTV={'mediatype':'episodes','plot':AwKqmbxWiSfFtHRLvEdacOsBNQpYVM,}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj={'mode':'PASS_VOD_LIST','collectionId':AwKqmbxWiSfFtHRLvEdacOsBNQpYTM,'obj_id':AwKqmbxWiSfFtHRLvEdacOsBNQpYUr,}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.add_dir(AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,sublabel=AwKqmbxWiSfFtHRLvEdacOsBNQpYUM,img=AwKqmbxWiSfFtHRLvEdacOsBNQpYUM,infoLabels=AwKqmbxWiSfFtHRLvEdacOsBNQpYTV,isFolder=AwKqmbxWiSfFtHRLvEdacOsBNQpYUj,params=AwKqmbxWiSfFtHRLvEdacOsBNQpYDj)
  xbmcplugin.setContent(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,cacheToDisc=AwKqmbxWiSfFtHRLvEdacOsBNQpYUy)
 def dp_Pass_VodList(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,args):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYTM =args.get('collectionId')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYUr =args.get('obj_id')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYTl=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.Get_Pass_VodList(AwKqmbxWiSfFtHRLvEdacOsBNQpYTM,AwKqmbxWiSfFtHRLvEdacOsBNQpYUr)
  for AwKqmbxWiSfFtHRLvEdacOsBNQpYTr in AwKqmbxWiSfFtHRLvEdacOsBNQpYTl:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDr =AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('title')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYUz =AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('id')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTy =AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('thumbnail')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTP =AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('mpaa')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTe =AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('duration')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYUn =AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('sub_type')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTu =AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('badge')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTz =AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('year')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTJ=AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('seasonList')
   AwKqmbxWiSfFtHRLvEdacOsBNQpYTC =AwKqmbxWiSfFtHRLvEdacOsBNQpYTr.get('genreList')
   if AwKqmbxWiSfFtHRLvEdacOsBNQpYUn in['TVSHOW']: 
    AwKqmbxWiSfFtHRLvEdacOsBNQpYTh ='SEASON_LIST'
    AwKqmbxWiSfFtHRLvEdacOsBNQpYTV={'mediatype':'tvshow','title':AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,'mpaa':AwKqmbxWiSfFtHRLvEdacOsBNQpYTP,'genre':AwKqmbxWiSfFtHRLvEdacOsBNQpYTC,'year':AwKqmbxWiSfFtHRLvEdacOsBNQpYTz,'plot':'Year : %s\nSeason : %s'%(AwKqmbxWiSfFtHRLvEdacOsBNQpYTz,AwKqmbxWiSfFtHRLvEdacOsBNQpYTJ),}
    AwKqmbxWiSfFtHRLvEdacOsBNQpYDG =AwKqmbxWiSfFtHRLvEdacOsBNQpYUj
   else:
    AwKqmbxWiSfFtHRLvEdacOsBNQpYTh ='MOVIE'
    AwKqmbxWiSfFtHRLvEdacOsBNQpYTV={'mediatype':'movie','title':AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,'mpaa':AwKqmbxWiSfFtHRLvEdacOsBNQpYTP,'genre':AwKqmbxWiSfFtHRLvEdacOsBNQpYTC,'duration':AwKqmbxWiSfFtHRLvEdacOsBNQpYTe,'year':AwKqmbxWiSfFtHRLvEdacOsBNQpYTz,'plot':'(%s)'%(AwKqmbxWiSfFtHRLvEdacOsBNQpYTP),}
    AwKqmbxWiSfFtHRLvEdacOsBNQpYDG =AwKqmbxWiSfFtHRLvEdacOsBNQpYUy
    AwKqmbxWiSfFtHRLvEdacOsBNQpYDr +=' (%s)'%(AwKqmbxWiSfFtHRLvEdacOsBNQpYUu(AwKqmbxWiSfFtHRLvEdacOsBNQpYTz))
   AwKqmbxWiSfFtHRLvEdacOsBNQpYDj={'mode':AwKqmbxWiSfFtHRLvEdacOsBNQpYTh,'id':AwKqmbxWiSfFtHRLvEdacOsBNQpYUz,'asis':AwKqmbxWiSfFtHRLvEdacOsBNQpYUn,'seasonList':AwKqmbxWiSfFtHRLvEdacOsBNQpYTJ,'title':AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,'thumbnail':AwKqmbxWiSfFtHRLvEdacOsBNQpYTy,'year':AwKqmbxWiSfFtHRLvEdacOsBNQpYTz,}
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.add_dir(AwKqmbxWiSfFtHRLvEdacOsBNQpYDr,sublabel=AwKqmbxWiSfFtHRLvEdacOsBNQpYTu,img=AwKqmbxWiSfFtHRLvEdacOsBNQpYTy,infoLabels=AwKqmbxWiSfFtHRLvEdacOsBNQpYTV,isFolder=AwKqmbxWiSfFtHRLvEdacOsBNQpYDG,params=AwKqmbxWiSfFtHRLvEdacOsBNQpYDj,ContextMenu=AwKqmbxWiSfFtHRLvEdacOsBNQpYUM)
  xbmcplugin.setContent(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV._addon_handle,cacheToDisc=AwKqmbxWiSfFtHRLvEdacOsBNQpYUy)
 def dp_setEpOrderby(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV,args):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYDT =args.get('orderby')
  AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.set_winEpisodeOrderby(AwKqmbxWiSfFtHRLvEdacOsBNQpYDT)
  xbmc.executebuiltin("Container.Refresh")
 def coupang_main(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV):
  AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CoupangObj.KodiVersion=AwKqmbxWiSfFtHRLvEdacOsBNQpYUe(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  AwKqmbxWiSfFtHRLvEdacOsBNQpYTh=AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.main_params.get('mode',AwKqmbxWiSfFtHRLvEdacOsBNQpYUM)
  if AwKqmbxWiSfFtHRLvEdacOsBNQpYTh=='LOGOUT':
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.CP_logout()
   return
  AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.option_check()
  if AwKqmbxWiSfFtHRLvEdacOsBNQpYTh is AwKqmbxWiSfFtHRLvEdacOsBNQpYUM:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.dp_Main_List(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.main_params)
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYTh=='CATEGORY_GROUPLIST':
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.dp_Category_GroupList(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.main_params)
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYTh=='THEME_GROUPLIST':
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.dp_Theme_GroupList(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.main_params)
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYTh=='EVENT_GROUPLIST':
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.dp_Event_GroupList(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.main_params)
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYTh=='EVENT_GAMELIST':
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.dp_Event_GameList(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.main_params)
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYTh=='EVENT_LIST':
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.dp_Event_List(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.main_params)
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYTh=='CATEGORY_LIST':
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.dp_Category_List(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.main_params)
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYTh=='SEASON_LIST':
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.dp_Season_List(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.main_params)
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYTh=='EPISODE_LIST':
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.dp_Episode_List(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.main_params)
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYTh=='TEST':
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.dp_Test(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.main_params)
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYTh in['MOVIE','VOD','HIGHLIGHT','LIVE']:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.play_VIDEO(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.main_params)
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYTh=='WATCH':
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.dp_Watch_List(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.main_params)
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYTh=='LOCAL_SEARCH':
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.dp_Search_List(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.main_params)
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYTh=='SEARCH_HISTORY':
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.dp_Search_History(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.main_params)
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYTh in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.dp_Listfile_Delete(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.main_params)
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYTh in['TOTAL_SEARCH','TOTAL_HISTORY']:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.dp_Global_Search(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.main_params)
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYTh=='MENU_BOOKMARK':
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.dp_Bookmark_Menu(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.main_params)
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYTh=='SET_BOOKMARK':
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.dp_Set_Bookmark(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.main_params)
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYTh=='SPORTS_MAINLIST_LEAGUE':
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.sp_Mainlist_League(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.main_params)
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYTh=='SPORTS_LEAGUE_FEEDLIST':
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.sp_League_FeedList(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.main_params)
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYTh=='SPORTS_FEED_VOD':
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.sp_League_VodList(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.main_params)
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYTh=='SPORTS_MULT_HERO':
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.sp_MultiHero_LiveList(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.main_params)
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYTh=='SPORTS_SEASON_GROUP':
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.sp_Season_Group(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.main_params)
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYTh=='SPORTS_SEASON_GAMELIST':
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.sp_Season_GameList(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.main_params)
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYTh=='SPORTS_SEASON_VODLIST':
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.sp_Season_VodList(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.main_params)
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYTh=='PASS_GROUPLIST':
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.dp_Pass_Group(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.main_params)
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYTh=='PASS_VOD_LIST':
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.dp_Pass_VodList(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.main_params)
  elif AwKqmbxWiSfFtHRLvEdacOsBNQpYTh=='ORDER_BY':
   AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.dp_setEpOrderby(AwKqmbxWiSfFtHRLvEdacOsBNQpYgV.main_params)
  else:
   AwKqmbxWiSfFtHRLvEdacOsBNQpYUM
# Created by pyminifier (https://github.com/liftoff/pyminifier)
