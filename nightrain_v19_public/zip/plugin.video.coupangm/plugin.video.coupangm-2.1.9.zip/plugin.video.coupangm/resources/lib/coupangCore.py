__author__="NightRain"
ECULefxDBQvAXNgpTlaPKdMqWSOIRr=object
ECULefxDBQvAXNgpTlaPKdMqWSOIRs=None
ECULefxDBQvAXNgpTlaPKdMqWSOIRi=False
ECULefxDBQvAXNgpTlaPKdMqWSOIRk=print
ECULefxDBQvAXNgpTlaPKdMqWSOIRz=str
ECULefxDBQvAXNgpTlaPKdMqWSOIRY=open
ECULefxDBQvAXNgpTlaPKdMqWSOIRo=Exception
ECULefxDBQvAXNgpTlaPKdMqWSOIbw=int
ECULefxDBQvAXNgpTlaPKdMqWSOIbF=len
ECULefxDBQvAXNgpTlaPKdMqWSOIbG=id
ECULefxDBQvAXNgpTlaPKdMqWSOIbm=True
ECULefxDBQvAXNgpTlaPKdMqWSOIbR=range
import urllib
import re
import json
import requests
import datetime
import time
import random
import base64
ECULefxDBQvAXNgpTlaPKdMqWSOIwG={'LONG_HIGHLIGHT':'하이라이트','SHORT_HIGHLIGHT':'하이라이트','PREVIEW':'프리뷰','FULL_MATCH':'다시보기','KEY_MOMENT':'','OTHER':'프로그램',}
class ECULefxDBQvAXNgpTlaPKdMqWSOIwF(ECULefxDBQvAXNgpTlaPKdMqWSOIRr):
 def __init__(ECULefxDBQvAXNgpTlaPKdMqWSOIwm):
  ECULefxDBQvAXNgpTlaPKdMqWSOIwm.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36'
  ECULefxDBQvAXNgpTlaPKdMqWSOIwm.MODEL ='Chrome_142' 
  ECULefxDBQvAXNgpTlaPKdMqWSOIwm.OS_VERSION ='142' 
  ECULefxDBQvAXNgpTlaPKdMqWSOIwm.x_app_version ='1.67.19'
  ECULefxDBQvAXNgpTlaPKdMqWSOIwm.DEFAULT_HEADER ={'user-agent':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.USER_AGENT}
  ECULefxDBQvAXNgpTlaPKdMqWSOIwm.API_DOMAIN ='https://www.coupangplay.com'
  ECULefxDBQvAXNgpTlaPKdMqWSOIwm.API_VIEWURL ='https://discover.coupangstreaming.com'
  ECULefxDBQvAXNgpTlaPKdMqWSOIwm.PAGE_LIMIT =50
  ECULefxDBQvAXNgpTlaPKdMqWSOIwm.SEARCH_LIMIT =20
  ECULefxDBQvAXNgpTlaPKdMqWSOIwm.KodiVersion =20
  ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP={}
  ECULefxDBQvAXNgpTlaPKdMqWSOIwm.Init_CP()
  ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP_DEVICE_FILENAME=''
  ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP_COOKIE_FILENAME=''
  ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP_SESSION_COOKIES1=''
  ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP_SESSION_COOKIES2=''
  ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP_SESSION_COOKIES3=''
  ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP_SESSION_COOKIES4=''
 def callRequestCookies(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,jobtype,ECULefxDBQvAXNgpTlaPKdMqWSOIFu,payload=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,params=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,headers=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,cookies=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,redirects=ECULefxDBQvAXNgpTlaPKdMqWSOIRi):
  ECULefxDBQvAXNgpTlaPKdMqWSOIwR=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.DEFAULT_HEADER
  if headers:ECULefxDBQvAXNgpTlaPKdMqWSOIwR.update(headers)
  if jobtype=='Get':
   ECULefxDBQvAXNgpTlaPKdMqWSOIwb=requests.get(ECULefxDBQvAXNgpTlaPKdMqWSOIFu,params=params,headers=ECULefxDBQvAXNgpTlaPKdMqWSOIwR,cookies=cookies,allow_redirects=redirects)
  else:
   ECULefxDBQvAXNgpTlaPKdMqWSOIwb=requests.post(ECULefxDBQvAXNgpTlaPKdMqWSOIFu,data=payload,params=params,headers=ECULefxDBQvAXNgpTlaPKdMqWSOIwR,cookies=cookies,allow_redirects=redirects)
  ECULefxDBQvAXNgpTlaPKdMqWSOIRk(ECULefxDBQvAXNgpTlaPKdMqWSOIRz(ECULefxDBQvAXNgpTlaPKdMqWSOIwb.status_code)+' - '+ECULefxDBQvAXNgpTlaPKdMqWSOIRz(ECULefxDBQvAXNgpTlaPKdMqWSOIwb.url))
  return ECULefxDBQvAXNgpTlaPKdMqWSOIwb
 def callRequestCookies_test(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,jobtype,ECULefxDBQvAXNgpTlaPKdMqWSOIFu,payload=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,params=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,headers=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,cookies=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,redirects=ECULefxDBQvAXNgpTlaPKdMqWSOIRi):
  ECULefxDBQvAXNgpTlaPKdMqWSOIwR=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.DEFAULT_HEADER
  if headers:ECULefxDBQvAXNgpTlaPKdMqWSOIwR.update(headers)
  ECULefxDBQvAXNgpTlaPKdMqWSOIwb=requests.Request('POST',ECULefxDBQvAXNgpTlaPKdMqWSOIFu,headers=headers,data=payload,params=params,cookies=cookies)
  ECULefxDBQvAXNgpTlaPKdMqWSOIwH=ECULefxDBQvAXNgpTlaPKdMqWSOIwb.prepare()
  ECULefxDBQvAXNgpTlaPKdMqWSOIwm.pretty_print_POST(ECULefxDBQvAXNgpTlaPKdMqWSOIwH)
  return ECULefxDBQvAXNgpTlaPKdMqWSOIwb
 def pretty_print_POST(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,req):
  ECULefxDBQvAXNgpTlaPKdMqWSOIRk('{}\n{}\r\n{}\r\n\r\n{}'.format('-----------START-----------',req.method+' '+req.url,'\r\n'.join('{}: {}'.format(k,v)for k,v in req.headers.items()),req.body,))
 def dic_To_jsonfile(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,filename,ECULefxDBQvAXNgpTlaPKdMqWSOIwn):
  if filename=='':return
  fp=ECULefxDBQvAXNgpTlaPKdMqWSOIRY(filename,'w',-1,'utf-8')
  json.dump(ECULefxDBQvAXNgpTlaPKdMqWSOIwn,fp,indent=4,ensure_ascii=ECULefxDBQvAXNgpTlaPKdMqWSOIRi)
  fp.close()
 def jsonfile_To_dic(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,filename):
  if filename=='':return ECULefxDBQvAXNgpTlaPKdMqWSOIRs
  try:
   fp=ECULefxDBQvAXNgpTlaPKdMqWSOIRY(filename,'r',-1,'utf-8')
   ECULefxDBQvAXNgpTlaPKdMqWSOIwc=json.load(fp)
   fp.close()
  except:
   ECULefxDBQvAXNgpTlaPKdMqWSOIwc={}
  return ECULefxDBQvAXNgpTlaPKdMqWSOIwc
 def convert_TimeStr(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,ECULefxDBQvAXNgpTlaPKdMqWSOIwu):
  try:
   ECULefxDBQvAXNgpTlaPKdMqWSOIwu =ECULefxDBQvAXNgpTlaPKdMqWSOIwu[0:16]
   ECULefxDBQvAXNgpTlaPKdMqWSOIwt=datetime.datetime.strptime(ECULefxDBQvAXNgpTlaPKdMqWSOIwu,'%Y-%m-%dT%H:%M')+datetime.timedelta(hours=9)
   ECULefxDBQvAXNgpTlaPKdMqWSOIwh=ECULefxDBQvAXNgpTlaPKdMqWSOIwt.weekday()
   if ECULefxDBQvAXNgpTlaPKdMqWSOIwh==0:ECULefxDBQvAXNgpTlaPKdMqWSOIwh='월'
   elif ECULefxDBQvAXNgpTlaPKdMqWSOIwh==1:ECULefxDBQvAXNgpTlaPKdMqWSOIwh='화'
   elif ECULefxDBQvAXNgpTlaPKdMqWSOIwh==2:ECULefxDBQvAXNgpTlaPKdMqWSOIwh='수'
   elif ECULefxDBQvAXNgpTlaPKdMqWSOIwh==3:ECULefxDBQvAXNgpTlaPKdMqWSOIwh='목'
   elif ECULefxDBQvAXNgpTlaPKdMqWSOIwh==4:ECULefxDBQvAXNgpTlaPKdMqWSOIwh='금'
   elif ECULefxDBQvAXNgpTlaPKdMqWSOIwh==5:ECULefxDBQvAXNgpTlaPKdMqWSOIwh='토'
   elif ECULefxDBQvAXNgpTlaPKdMqWSOIwh==6:ECULefxDBQvAXNgpTlaPKdMqWSOIwh='일'
   return ECULefxDBQvAXNgpTlaPKdMqWSOIwt.strftime('%Y-%m-%d')+'('+ ECULefxDBQvAXNgpTlaPKdMqWSOIwh+')'+ECULefxDBQvAXNgpTlaPKdMqWSOIwt.strftime(' %H:%M')
  except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
   return ECULefxDBQvAXNgpTlaPKdMqWSOIwu
 def convert_DateStr(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,ECULefxDBQvAXNgpTlaPKdMqWSOIwu):
  try:
   ECULefxDBQvAXNgpTlaPKdMqWSOIwu =ECULefxDBQvAXNgpTlaPKdMqWSOIwu[0:16]
   ECULefxDBQvAXNgpTlaPKdMqWSOIwt=datetime.datetime.strptime(ECULefxDBQvAXNgpTlaPKdMqWSOIwu,'%Y-%m-%dT%H:%M')+datetime.timedelta(hours=9)
   ECULefxDBQvAXNgpTlaPKdMqWSOIwh=ECULefxDBQvAXNgpTlaPKdMqWSOIwt.weekday()
   if ECULefxDBQvAXNgpTlaPKdMqWSOIwh==0:ECULefxDBQvAXNgpTlaPKdMqWSOIwh='월'
   elif ECULefxDBQvAXNgpTlaPKdMqWSOIwh==1:ECULefxDBQvAXNgpTlaPKdMqWSOIwh='화'
   elif ECULefxDBQvAXNgpTlaPKdMqWSOIwh==2:ECULefxDBQvAXNgpTlaPKdMqWSOIwh='수'
   elif ECULefxDBQvAXNgpTlaPKdMqWSOIwh==3:ECULefxDBQvAXNgpTlaPKdMqWSOIwh='목'
   elif ECULefxDBQvAXNgpTlaPKdMqWSOIwh==4:ECULefxDBQvAXNgpTlaPKdMqWSOIwh='금'
   elif ECULefxDBQvAXNgpTlaPKdMqWSOIwh==5:ECULefxDBQvAXNgpTlaPKdMqWSOIwh='토'
   elif ECULefxDBQvAXNgpTlaPKdMqWSOIwh==6:ECULefxDBQvAXNgpTlaPKdMqWSOIwh='일'
   return ECULefxDBQvAXNgpTlaPKdMqWSOIwt.strftime('%Y-%m-%d')+'('+ ECULefxDBQvAXNgpTlaPKdMqWSOIwh+')'
  except:
   return ECULefxDBQvAXNgpTlaPKdMqWSOIwu
 def Get_Now_Datetime(ECULefxDBQvAXNgpTlaPKdMqWSOIwm):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetNoCache(ECULefxDBQvAXNgpTlaPKdMqWSOIwm):
  ECULefxDBQvAXNgpTlaPKdMqWSOIwy =ECULefxDBQvAXNgpTlaPKdMqWSOIbw(time.time()*1000)
  return ECULefxDBQvAXNgpTlaPKdMqWSOIwy
 def generatePcId(ECULefxDBQvAXNgpTlaPKdMqWSOIwm):
  t=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.GetNoCache()
  r=random.random()
  ECULefxDBQvAXNgpTlaPKdMqWSOIwV=ECULefxDBQvAXNgpTlaPKdMqWSOIRz(t)+ECULefxDBQvAXNgpTlaPKdMqWSOIRz(r)[2:12]
  return ECULefxDBQvAXNgpTlaPKdMqWSOIwV
 def generatePvId(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,genType='1'):
  import hashlib
  m=hashlib.md5()
  ECULefxDBQvAXNgpTlaPKdMqWSOIwr=ECULefxDBQvAXNgpTlaPKdMqWSOIRz(random.random())
  m.update(ECULefxDBQvAXNgpTlaPKdMqWSOIwr.encode('utf-8'))
  ECULefxDBQvAXNgpTlaPKdMqWSOIws=ECULefxDBQvAXNgpTlaPKdMqWSOIRz(m.hexdigest())
  if genType=='1':
   return '%s-%s-%s-%s-%s'%(ECULefxDBQvAXNgpTlaPKdMqWSOIws[:8],ECULefxDBQvAXNgpTlaPKdMqWSOIws[8:12],ECULefxDBQvAXNgpTlaPKdMqWSOIws[12:16],ECULefxDBQvAXNgpTlaPKdMqWSOIws[16:20],ECULefxDBQvAXNgpTlaPKdMqWSOIws[20:])
  else:
   return ECULefxDBQvAXNgpTlaPKdMqWSOIws
 def Get_DeviceID(ECULefxDBQvAXNgpTlaPKdMqWSOIwm):
  ECULefxDBQvAXNgpTlaPKdMqWSOIwi=''
  try: 
   fp=ECULefxDBQvAXNgpTlaPKdMqWSOIRY(ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP_DEVICE_FILENAME,'r',-1,'utf-8')
   ECULefxDBQvAXNgpTlaPKdMqWSOIwk= json.load(fp)
   fp.close()
   ECULefxDBQvAXNgpTlaPKdMqWSOIwi=ECULefxDBQvAXNgpTlaPKdMqWSOIwk.get('device_id')
  except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
   ECULefxDBQvAXNgpTlaPKdMqWSOIRs
  if ECULefxDBQvAXNgpTlaPKdMqWSOIwi=='':
   ECULefxDBQvAXNgpTlaPKdMqWSOIwi=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.generatePvId(genType='1')
   try: 
    fp=ECULefxDBQvAXNgpTlaPKdMqWSOIRY(ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP_DEVICE_FILENAME,'w',-1,'utf-8')
    json.dump({'device_id':ECULefxDBQvAXNgpTlaPKdMqWSOIwi},fp,indent=4,ensure_ascii=ECULefxDBQvAXNgpTlaPKdMqWSOIRi)
    fp.close()
   except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
    return ''
  return ECULefxDBQvAXNgpTlaPKdMqWSOIwi
 def make_stream_header(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,ECULefxDBQvAXNgpTlaPKdMqWSOIFG,ECULefxDBQvAXNgpTlaPKdMqWSOIFt):
  ECULefxDBQvAXNgpTlaPKdMqWSOIwz=''
  if ECULefxDBQvAXNgpTlaPKdMqWSOIFt not in[{},ECULefxDBQvAXNgpTlaPKdMqWSOIRs,'']:
   ECULefxDBQvAXNgpTlaPKdMqWSOIwY=ECULefxDBQvAXNgpTlaPKdMqWSOIbF(ECULefxDBQvAXNgpTlaPKdMqWSOIFt)
   for ECULefxDBQvAXNgpTlaPKdMqWSOIwo,ECULefxDBQvAXNgpTlaPKdMqWSOIFw in ECULefxDBQvAXNgpTlaPKdMqWSOIFt.items():
    ECULefxDBQvAXNgpTlaPKdMqWSOIwz+='{}={}'.format(ECULefxDBQvAXNgpTlaPKdMqWSOIwo,ECULefxDBQvAXNgpTlaPKdMqWSOIFw)
    ECULefxDBQvAXNgpTlaPKdMqWSOIwY+=-1
    if ECULefxDBQvAXNgpTlaPKdMqWSOIwY>0:ECULefxDBQvAXNgpTlaPKdMqWSOIwz+='; '
   ECULefxDBQvAXNgpTlaPKdMqWSOIFG['cookie']=ECULefxDBQvAXNgpTlaPKdMqWSOIwz
  ECULefxDBQvAXNgpTlaPKdMqWSOIFm=''
  i=0
  for ECULefxDBQvAXNgpTlaPKdMqWSOIwo,ECULefxDBQvAXNgpTlaPKdMqWSOIFw in ECULefxDBQvAXNgpTlaPKdMqWSOIFG.items():
   i=i+1
   if i>1:ECULefxDBQvAXNgpTlaPKdMqWSOIFm+='&'
   ECULefxDBQvAXNgpTlaPKdMqWSOIFm+='{}={}'.format(ECULefxDBQvAXNgpTlaPKdMqWSOIwo,urllib.parse.quote(ECULefxDBQvAXNgpTlaPKdMqWSOIFw))
  return ECULefxDBQvAXNgpTlaPKdMqWSOIFm
 def Make_authHeader(ECULefxDBQvAXNgpTlaPKdMqWSOIwm):
  tr=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.generatePvId(genType=2)
  ti=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.GetNoCache()
  ECULefxDBQvAXNgpTlaPKdMqWSOIbG=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.generatePvId(genType=2)[:16]
  ECULefxDBQvAXNgpTlaPKdMqWSOIFR='00-%s-%s-01'%(tr,ECULefxDBQvAXNgpTlaPKdMqWSOIbG,)
  ECULefxDBQvAXNgpTlaPKdMqWSOIFb ='%s@nr=0-1-%s-%s-%s----%s'%(ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['SESSION']['NREUM']['tk'],ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['SESSION']['NREUM']['ac'],ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['SESSION']['NREUM']['ap'],ECULefxDBQvAXNgpTlaPKdMqWSOIbG,ti,)
  ECULefxDBQvAXNgpTlaPKdMqWSOIFH ='{"v":[0,1],"d":{"ty":"Browser","ac":"%s","ap":"%s","id":"%s","tr":"%s","ti":%s,"tk":"%s"}}'%(ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['SESSION']['NREUM']['ac'],ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['SESSION']['NREUM']['ap'],ECULefxDBQvAXNgpTlaPKdMqWSOIbG,tr,ti,ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['SESSION']['NREUM']['tk'],) 
  return ECULefxDBQvAXNgpTlaPKdMqWSOIFR,ECULefxDBQvAXNgpTlaPKdMqWSOIFb,base64.standard_b64encode(ECULefxDBQvAXNgpTlaPKdMqWSOIFH.encode()).decode('utf-8')
 def Init_CP(ECULefxDBQvAXNgpTlaPKdMqWSOIwm):
  ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP={}
  ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['ACCOUNT']={'cpid':'','cppw':'','cppf':'0'}
  ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['SESSION']={}
  ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['COOKIES']={}
 def Save_session_acount(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,ECULefxDBQvAXNgpTlaPKdMqWSOIFn,ECULefxDBQvAXNgpTlaPKdMqWSOIFj,ECULefxDBQvAXNgpTlaPKdMqWSOIFc):
  ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['ACCOUNT']['cpid']=base64.standard_b64encode(ECULefxDBQvAXNgpTlaPKdMqWSOIFn.encode()).decode('utf-8')
  ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['ACCOUNT']['cppw']=base64.standard_b64encode(ECULefxDBQvAXNgpTlaPKdMqWSOIFj.encode()).decode('utf-8')
  ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['ACCOUNT']['cppf']=ECULefxDBQvAXNgpTlaPKdMqWSOIRz(ECULefxDBQvAXNgpTlaPKdMqWSOIFc)
 def Load_session_acount(ECULefxDBQvAXNgpTlaPKdMqWSOIwm):
  ECULefxDBQvAXNgpTlaPKdMqWSOIFn=base64.standard_b64decode(ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['ACCOUNT']['cpid']).decode('utf-8')
  ECULefxDBQvAXNgpTlaPKdMqWSOIFj=base64.standard_b64decode(ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['ACCOUNT']['cppw']).decode('utf-8')
  ECULefxDBQvAXNgpTlaPKdMqWSOIFc=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['ACCOUNT']['cppf']
  return ECULefxDBQvAXNgpTlaPKdMqWSOIFn,ECULefxDBQvAXNgpTlaPKdMqWSOIFj,ECULefxDBQvAXNgpTlaPKdMqWSOIFc
 def make_CP_DefaultCookies(ECULefxDBQvAXNgpTlaPKdMqWSOIwm):
  return ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['COOKIES']
 def Get_CP_Login(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,userid,userpw,ECULefxDBQvAXNgpTlaPKdMqWSOIFz):
  try:
   ECULefxDBQvAXNgpTlaPKdMqWSOIFu=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.API_DOMAIN
   ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['COOKIES']['NEXT_LOCALE']='ko'
   ECULefxDBQvAXNgpTlaPKdMqWSOIFG={'Accept-Language':'ko-KR,ko;q=0.9','Sec-Ch-Ua-Mobile':'?0','Sec-Ch-Ua-Platform':'"Windows"','Sec-Fetch-Dest':'document','Sec-Fetch-Mode':'navigate','Sec-Fetch-Site':'none','Sec-Fetch-User':'?1','Upgrade-Insecure-Requests':'1',}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFt=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.make_CP_DefaultCookies()
   ECULefxDBQvAXNgpTlaPKdMqWSOIFh=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.callRequestCookies('Get',ECULefxDBQvAXNgpTlaPKdMqWSOIFu,payload=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,params=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,headers=ECULefxDBQvAXNgpTlaPKdMqWSOIFG,cookies=ECULefxDBQvAXNgpTlaPKdMqWSOIFt,redirects=ECULefxDBQvAXNgpTlaPKdMqWSOIbm)
   if ECULefxDBQvAXNgpTlaPKdMqWSOIFh.status_code not in[200]:return ECULefxDBQvAXNgpTlaPKdMqWSOIRi
   for ECULefxDBQvAXNgpTlaPKdMqWSOIFJ in ECULefxDBQvAXNgpTlaPKdMqWSOIFh.cookies:
    ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['COOKIES'][ECULefxDBQvAXNgpTlaPKdMqWSOIFJ.name]=ECULefxDBQvAXNgpTlaPKdMqWSOIFJ.value
   ECULefxDBQvAXNgpTlaPKdMqWSOIFt=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.make_CP_DefaultCookies()
   if ECULefxDBQvAXNgpTlaPKdMqWSOIFh.status_code not in[200]:return ECULefxDBQvAXNgpTlaPKdMqWSOIRi
   ECULefxDBQvAXNgpTlaPKdMqWSOIFy=re.findall('NREUM.loader_config=\{[\w\d\":,-]+\}',ECULefxDBQvAXNgpTlaPKdMqWSOIFh.text)[0].split('=')[1]
   ECULefxDBQvAXNgpTlaPKdMqWSOIFy=ECULefxDBQvAXNgpTlaPKdMqWSOIFy.replace('{','{"').replace(':','":').replace(',',',"')
   ECULefxDBQvAXNgpTlaPKdMqWSOIFy=json.loads(ECULefxDBQvAXNgpTlaPKdMqWSOIFy)
   ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['SESSION']['NREUM']={'ac':ECULefxDBQvAXNgpTlaPKdMqWSOIFy['accountID'],'tk':ECULefxDBQvAXNgpTlaPKdMqWSOIFy['trustKey'],'ap':ECULefxDBQvAXNgpTlaPKdMqWSOIFy['agentID'],'lk':ECULefxDBQvAXNgpTlaPKdMqWSOIFy['licenseKey'],}
  except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
   ECULefxDBQvAXNgpTlaPKdMqWSOIRk(exception)
   return ECULefxDBQvAXNgpTlaPKdMqWSOIRi
  try:
   ECULefxDBQvAXNgpTlaPKdMqWSOIFu=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.API_DOMAIN+'/api/auth'
   ECULefxDBQvAXNgpTlaPKdMqWSOIFV=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.Get_DeviceID()
   ECULefxDBQvAXNgpTlaPKdMqWSOIFr =ECULefxDBQvAXNgpTlaPKdMqWSOIFV.split('-')[0]
   ECULefxDBQvAXNgpTlaPKdMqWSOIFR,ECULefxDBQvAXNgpTlaPKdMqWSOIFb,ECULefxDBQvAXNgpTlaPKdMqWSOIFH=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.Make_authHeader()
   ECULefxDBQvAXNgpTlaPKdMqWSOIFG={'traceparent':ECULefxDBQvAXNgpTlaPKdMqWSOIFR,'tracestate':ECULefxDBQvAXNgpTlaPKdMqWSOIFb,'newrelic':ECULefxDBQvAXNgpTlaPKdMqWSOIFH,'content-type':'application/json','x-app-version':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.x_app_version,'x-device-id':'','x-device-os-version':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.OS_VERSION,'x-nr-session-id':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['COOKIES']['session_web_id'],'x-pcid':'',}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFs={'device':{'deviceId':'web-'+ECULefxDBQvAXNgpTlaPKdMqWSOIFV,'model':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.MODEL,'name':'Chrome Desktop '+ECULefxDBQvAXNgpTlaPKdMqWSOIFr,'os':'Windows','osVersion':'10','type':'webclient',},'email':userid,'password':userpw,}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFs=json.dumps(ECULefxDBQvAXNgpTlaPKdMqWSOIFs,separators=(',',':'))
   ECULefxDBQvAXNgpTlaPKdMqWSOIFt=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.make_CP_DefaultCookies()
   ECULefxDBQvAXNgpTlaPKdMqWSOIFh=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.callRequestCookies('Post',ECULefxDBQvAXNgpTlaPKdMqWSOIFu,payload=ECULefxDBQvAXNgpTlaPKdMqWSOIFs,params=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,headers=ECULefxDBQvAXNgpTlaPKdMqWSOIFG,cookies=ECULefxDBQvAXNgpTlaPKdMqWSOIFt,redirects=ECULefxDBQvAXNgpTlaPKdMqWSOIRi)
   if ECULefxDBQvAXNgpTlaPKdMqWSOIFh.status_code not in[200]:
    ECULefxDBQvAXNgpTlaPKdMqWSOIFi=json.loads(ECULefxDBQvAXNgpTlaPKdMqWSOIFh.text)
    if 'error' in ECULefxDBQvAXNgpTlaPKdMqWSOIFi:
     ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['SESSION']['error']=ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('error').get('detail')
    return ECULefxDBQvAXNgpTlaPKdMqWSOIRi
   ECULefxDBQvAXNgpTlaPKdMqWSOIRk('---')
   for ECULefxDBQvAXNgpTlaPKdMqWSOIFJ in ECULefxDBQvAXNgpTlaPKdMqWSOIFh.cookies:
    ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['COOKIES'][ECULefxDBQvAXNgpTlaPKdMqWSOIFJ.name]=ECULefxDBQvAXNgpTlaPKdMqWSOIFJ.value
  except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
   ECULefxDBQvAXNgpTlaPKdMqWSOIRk(exception)
   return ECULefxDBQvAXNgpTlaPKdMqWSOIRi
  ECULefxDBQvAXNgpTlaPKdMqWSOIwm.Save_session_acount(userid,userpw,ECULefxDBQvAXNgpTlaPKdMqWSOIFz)
  return ECULefxDBQvAXNgpTlaPKdMqWSOIbm
 def Get_CP_profile(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,ECULefxDBQvAXNgpTlaPKdMqWSOIFz,limit_days=1,re_check=ECULefxDBQvAXNgpTlaPKdMqWSOIRi):
  if re_check==ECULefxDBQvAXNgpTlaPKdMqWSOIbm:
   if ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['SESSION']['bm_sv_ex']>ECULefxDBQvAXNgpTlaPKdMqWSOIbw(time.time()):
    ECULefxDBQvAXNgpTlaPKdMqWSOIRk('bm_sv_ex ok')
    return ECULefxDBQvAXNgpTlaPKdMqWSOIbm
  try:
   ECULefxDBQvAXNgpTlaPKdMqWSOIFu=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.API_DOMAIN+'/api/profiles'
   ECULefxDBQvAXNgpTlaPKdMqWSOIFR,ECULefxDBQvAXNgpTlaPKdMqWSOIFb,ECULefxDBQvAXNgpTlaPKdMqWSOIFH=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.Make_authHeader()
   ECULefxDBQvAXNgpTlaPKdMqWSOIFG={'traceparent':ECULefxDBQvAXNgpTlaPKdMqWSOIFR,'tracestate':ECULefxDBQvAXNgpTlaPKdMqWSOIFb,'newrelic':ECULefxDBQvAXNgpTlaPKdMqWSOIFH,'x-app-version':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.x_app_version,'x-device-id':'','x-device-os-version':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.OS_VERSION,'x-nr-session-id':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['COOKIES']['session_web_id'],'x-pcid':'','referer':'https://www.coupangplay.com/home',}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFt=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.make_CP_DefaultCookies()
   ECULefxDBQvAXNgpTlaPKdMqWSOIFh=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.callRequestCookies('Get',ECULefxDBQvAXNgpTlaPKdMqWSOIFu,payload=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,params=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,headers=ECULefxDBQvAXNgpTlaPKdMqWSOIFG,cookies=ECULefxDBQvAXNgpTlaPKdMqWSOIFt,redirects=ECULefxDBQvAXNgpTlaPKdMqWSOIbm)
   if ECULefxDBQvAXNgpTlaPKdMqWSOIFh.status_code not in[200]:return ECULefxDBQvAXNgpTlaPKdMqWSOIRi
   ECULefxDBQvAXNgpTlaPKdMqWSOIFi=json.loads(ECULefxDBQvAXNgpTlaPKdMqWSOIFh.text)
   ECULefxDBQvAXNgpTlaPKdMqWSOIFk=0
   for ECULefxDBQvAXNgpTlaPKdMqWSOIFJ in ECULefxDBQvAXNgpTlaPKdMqWSOIFh.cookies:
    ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['COOKIES'][ECULefxDBQvAXNgpTlaPKdMqWSOIFJ.name]=ECULefxDBQvAXNgpTlaPKdMqWSOIFJ.value
    if ECULefxDBQvAXNgpTlaPKdMqWSOIFJ.name=='bm_sv':
     ECULefxDBQvAXNgpTlaPKdMqWSOIFk=1
     ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['SESSION']['bm_sv_ex']=ECULefxDBQvAXNgpTlaPKdMqWSOIFJ.expires 
   if ECULefxDBQvAXNgpTlaPKdMqWSOIFk==0:
    ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['SESSION']['bm_sv_ex']=ECULefxDBQvAXNgpTlaPKdMqWSOIbw(time.time())+60*60*2 
   ECULefxDBQvAXNgpTlaPKdMqWSOIFz=ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('data')[ECULefxDBQvAXNgpTlaPKdMqWSOIbw(ECULefxDBQvAXNgpTlaPKdMqWSOIFz)]
   ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['SESSION']['accountId']=ECULefxDBQvAXNgpTlaPKdMqWSOIFz.get('accountId')
   ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['SESSION']['profileId']=ECULefxDBQvAXNgpTlaPKdMqWSOIFz.get('profileId')
  except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
   ECULefxDBQvAXNgpTlaPKdMqWSOIRk(exception)
   return ECULefxDBQvAXNgpTlaPKdMqWSOIRi
  if re_check==ECULefxDBQvAXNgpTlaPKdMqWSOIRi:
   ECULefxDBQvAXNgpTlaPKdMqWSOIFY =ECULefxDBQvAXNgpTlaPKdMqWSOIwm.Get_Now_Datetime()
   ECULefxDBQvAXNgpTlaPKdMqWSOIFo=ECULefxDBQvAXNgpTlaPKdMqWSOIFY+datetime.timedelta(days=limit_days)
   ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['SESSION']['limitdate']=ECULefxDBQvAXNgpTlaPKdMqWSOIFo.strftime('%Y-%m-%d')
  else:
   ECULefxDBQvAXNgpTlaPKdMqWSOIRk('re check')
  ECULefxDBQvAXNgpTlaPKdMqWSOIwm.dic_To_jsonfile(ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP_COOKIE_FILENAME,ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP)
  return ECULefxDBQvAXNgpTlaPKdMqWSOIbm
 def Get_Category_GroupList(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,vType):
  ECULefxDBQvAXNgpTlaPKdMqWSOIGw=[] 
  try:
   ECULefxDBQvAXNgpTlaPKdMqWSOIFu=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.API_DOMAIN+'/api-discover/v3/discover/feed' 
   ECULefxDBQvAXNgpTlaPKdMqWSOIGF={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false','preferRecoFeed':'true','preferMultiHeroMixedContentRow':'true','shouldIncludeTVOD':'true',}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFG={'x-membersrl':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['COOKIES']['member_srl'],'x-pcid':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['COOKIES']['PCID'],'x-profileid':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT','x-app-version':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.x_app_version,}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFh=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.callRequestCookies('Get',ECULefxDBQvAXNgpTlaPKdMqWSOIFu,payload=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,params=ECULefxDBQvAXNgpTlaPKdMqWSOIGF,headers=ECULefxDBQvAXNgpTlaPKdMqWSOIFG,cookies=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,redirects=ECULefxDBQvAXNgpTlaPKdMqWSOIbm)
   if ECULefxDBQvAXNgpTlaPKdMqWSOIFh.status_code not in[200]:return[]
   ECULefxDBQvAXNgpTlaPKdMqWSOIFi=json.loads(ECULefxDBQvAXNgpTlaPKdMqWSOIFh.text)
   if vType in['TVSHOWS','MOVIES']:
    ECULefxDBQvAXNgpTlaPKdMqWSOIGm='Explores' 
   elif vType in['EDUCATION']:
    ECULefxDBQvAXNgpTlaPKdMqWSOIGm='Collection-Rails-Curation'
   elif vType in['ALL','KIDS']:
    ECULefxDBQvAXNgpTlaPKdMqWSOIGm='Explores-Categories'
   for ECULefxDBQvAXNgpTlaPKdMqWSOIGR in ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('data'):
    if ECULefxDBQvAXNgpTlaPKdMqWSOIGR.get('type')==ECULefxDBQvAXNgpTlaPKdMqWSOIGm:
     for ECULefxDBQvAXNgpTlaPKdMqWSOIGb in ECULefxDBQvAXNgpTlaPKdMqWSOIGR.get('data'):
      if vType in['TVSHOWS','MOVIES']:
       ECULefxDBQvAXNgpTlaPKdMqWSOIGH=ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('collectionId')
      elif vType in['EDUCATION','ALL','KIDS']:
       ECULefxDBQvAXNgpTlaPKdMqWSOIGH=ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('id')
      ECULefxDBQvAXNgpTlaPKdMqWSOIGn={'collectionId':ECULefxDBQvAXNgpTlaPKdMqWSOIGH,'title':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('name'),'category':ECULefxDBQvAXNgpTlaPKdMqWSOIGR.get('category'),'pre_title':'',}
      ECULefxDBQvAXNgpTlaPKdMqWSOIGw.append(ECULefxDBQvAXNgpTlaPKdMqWSOIGn)
     break
  except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
   ECULefxDBQvAXNgpTlaPKdMqWSOIRk(exception)
   return[]
  return ECULefxDBQvAXNgpTlaPKdMqWSOIGw
 def Get_Category_List(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,vType,ECULefxDBQvAXNgpTlaPKdMqWSOIGH,page_int):
  ECULefxDBQvAXNgpTlaPKdMqWSOIGw=[] 
  ECULefxDBQvAXNgpTlaPKdMqWSOIGj=ECULefxDBQvAXNgpTlaPKdMqWSOIRi
  try:
   if vType in['ALL','#KIDS']:
    ECULefxDBQvAXNgpTlaPKdMqWSOIGF={'platform':'WEBCLIENT','page':ECULefxDBQvAXNgpTlaPKdMqWSOIRz(page_int),'perPage':ECULefxDBQvAXNgpTlaPKdMqWSOIRz(ECULefxDBQvAXNgpTlaPKdMqWSOIwm.PAGE_LIMIT),'locale':'ko','sort':'',}
    ECULefxDBQvAXNgpTlaPKdMqWSOIFG={'x-membersrl':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['COOKIES']['member_srl'],'x-pcid':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['COOKIES']['PCID'],'x-profileid':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT','x-app-version':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.x_app_version,}
    ECULefxDBQvAXNgpTlaPKdMqWSOIFu=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.API_DOMAIN+'/api-discover/v1/discover/categories/'+ECULefxDBQvAXNgpTlaPKdMqWSOIGH+'/titles' 
    ECULefxDBQvAXNgpTlaPKdMqWSOIFh=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.callRequestCookies('Get',ECULefxDBQvAXNgpTlaPKdMqWSOIFu,payload=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,params=ECULefxDBQvAXNgpTlaPKdMqWSOIGF,headers=ECULefxDBQvAXNgpTlaPKdMqWSOIFG,cookies=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,redirects=ECULefxDBQvAXNgpTlaPKdMqWSOIbm)
   else: 
    ECULefxDBQvAXNgpTlaPKdMqWSOIGF={'platform':'WEBCLIENT','page':ECULefxDBQvAXNgpTlaPKdMqWSOIRz(page_int),'perPage':ECULefxDBQvAXNgpTlaPKdMqWSOIRz(ECULefxDBQvAXNgpTlaPKdMqWSOIwm.PAGE_LIMIT),}
    ECULefxDBQvAXNgpTlaPKdMqWSOIFG={'x-membersrl':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['COOKIES']['member_srl'],'x-pcid':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['COOKIES']['PCID'],'x-profileid':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT','x-app-version':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.x_app_version,}
    ECULefxDBQvAXNgpTlaPKdMqWSOIFu=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.API_DOMAIN+'/api-discover/v1/discover/collections/'+ECULefxDBQvAXNgpTlaPKdMqWSOIGH+'/titles' 
    ECULefxDBQvAXNgpTlaPKdMqWSOIFh=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.callRequestCookies('Get',ECULefxDBQvAXNgpTlaPKdMqWSOIFu,payload=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,params=ECULefxDBQvAXNgpTlaPKdMqWSOIGF,headers=ECULefxDBQvAXNgpTlaPKdMqWSOIFG,cookies=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,redirects=ECULefxDBQvAXNgpTlaPKdMqWSOIbm)
   if ECULefxDBQvAXNgpTlaPKdMqWSOIFh.status_code not in[200]:return[],ECULefxDBQvAXNgpTlaPKdMqWSOIRi
   ECULefxDBQvAXNgpTlaPKdMqWSOIFi=json.loads(ECULefxDBQvAXNgpTlaPKdMqWSOIFh.text)
   if vType in['ALL','#KIDS']:
    ECULefxDBQvAXNgpTlaPKdMqWSOIGc=ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('data').get('data')
   else:
    ECULefxDBQvAXNgpTlaPKdMqWSOIGc=ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('data')
   for ECULefxDBQvAXNgpTlaPKdMqWSOIGb in ECULefxDBQvAXNgpTlaPKdMqWSOIGc:
    ECULefxDBQvAXNgpTlaPKdMqWSOIGu=ECULefxDBQvAXNgpTlaPKdMqWSOIGV=ECULefxDBQvAXNgpTlaPKdMqWSOImh=ECULefxDBQvAXNgpTlaPKdMqWSOImt=''
    if 'poster' in ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('images'):ECULefxDBQvAXNgpTlaPKdMqWSOIGu =ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('images'):ECULefxDBQvAXNgpTlaPKdMqWSOIGV =ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('images').get('story-art').get('url') +'?imwidth=600'
    if 'title-treatment' in ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('images'):ECULefxDBQvAXNgpTlaPKdMqWSOImh=ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('images').get('title-treatment').get('url')+'?imwidth=300'
    if 'story-art' in ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('images'):ECULefxDBQvAXNgpTlaPKdMqWSOImt =ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('images').get('story-art').get('url') +'?imwidth=600'
    ECULefxDBQvAXNgpTlaPKdMqWSOIGt=''
    if ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('badge')not in[{},ECULefxDBQvAXNgpTlaPKdMqWSOIRs]:
     for i in ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('badge').get('text'):
      ECULefxDBQvAXNgpTlaPKdMqWSOIGt+=i.get('text')
    ECULefxDBQvAXNgpTlaPKdMqWSOIGh=''
    if ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('seasonList')!=ECULefxDBQvAXNgpTlaPKdMqWSOIRs:
     ECULefxDBQvAXNgpTlaPKdMqWSOIGh=','.join(ECULefxDBQvAXNgpTlaPKdMqWSOIRz(e)for e in ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('seasonList'))
    ECULefxDBQvAXNgpTlaPKdMqWSOIGJ =[]
    for ECULefxDBQvAXNgpTlaPKdMqWSOIGy in ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('tags'):
     ECULefxDBQvAXNgpTlaPKdMqWSOIGJ.append(ECULefxDBQvAXNgpTlaPKdMqWSOIGy.get('tag'))
    ECULefxDBQvAXNgpTlaPKdMqWSOIGn={'id':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('id'),'title':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('title'),'thumbnail':{'poster':ECULefxDBQvAXNgpTlaPKdMqWSOIGu,'thumb':ECULefxDBQvAXNgpTlaPKdMqWSOIGV,'clearlogo':ECULefxDBQvAXNgpTlaPKdMqWSOImh,'fanart':ECULefxDBQvAXNgpTlaPKdMqWSOImt},'mpaa':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('age_rating'),'duration':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('running_time'),'asis':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('as'),'badge':ECULefxDBQvAXNgpTlaPKdMqWSOIGt,'year':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('meta').get('releaseYear'),'seasonList':ECULefxDBQvAXNgpTlaPKdMqWSOIGh,'genreList':ECULefxDBQvAXNgpTlaPKdMqWSOIGJ,}
    ECULefxDBQvAXNgpTlaPKdMqWSOIGw.append(ECULefxDBQvAXNgpTlaPKdMqWSOIGn)
   if ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('pagination').get('totalPages')>page_int:
    ECULefxDBQvAXNgpTlaPKdMqWSOIGj=ECULefxDBQvAXNgpTlaPKdMqWSOIbm
  except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
   ECULefxDBQvAXNgpTlaPKdMqWSOIRk(exception)
   return[],ECULefxDBQvAXNgpTlaPKdMqWSOIRi
  return ECULefxDBQvAXNgpTlaPKdMqWSOIGw,ECULefxDBQvAXNgpTlaPKdMqWSOIGj
 def Get_Episode_List_x(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,programId,season):
  ECULefxDBQvAXNgpTlaPKdMqWSOIGw=[] 
  try:
   ECULefxDBQvAXNgpTlaPKdMqWSOIFu=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.API_DOMAIN+'/api-discover/v1/discover/titles/'+programId+'/episodes' 
   ECULefxDBQvAXNgpTlaPKdMqWSOIGF={'season':season,'sort':'true','locale':'ko',}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFG={'x-membersrl':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['COOKIES']['member_srl'],'x-pcid':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['COOKIES']['PCID'],'x-profileid':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT','x-app-version':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.x_app_version,}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFh=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.callRequestCookies('Get',ECULefxDBQvAXNgpTlaPKdMqWSOIFu,payload=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,params=ECULefxDBQvAXNgpTlaPKdMqWSOIGF,headers=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,cookies=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,redirects=ECULefxDBQvAXNgpTlaPKdMqWSOIbm)
   if ECULefxDBQvAXNgpTlaPKdMqWSOIFh.status_code not in[200]:return[]
   ECULefxDBQvAXNgpTlaPKdMqWSOIFi=json.loads(ECULefxDBQvAXNgpTlaPKdMqWSOIFh.text)
   for ECULefxDBQvAXNgpTlaPKdMqWSOIGb in ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('data'):
    ECULefxDBQvAXNgpTlaPKdMqWSOIGV=''
    if 'story-art' in ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('images'):ECULefxDBQvAXNgpTlaPKdMqWSOIGV =ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('images').get('story-art').get('url')+'?imwidth=600'
    ECULefxDBQvAXNgpTlaPKdMqWSOIGJ =[]
    for ECULefxDBQvAXNgpTlaPKdMqWSOIGy in ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('tags'):
     ECULefxDBQvAXNgpTlaPKdMqWSOIGJ.append(ECULefxDBQvAXNgpTlaPKdMqWSOIGy.get('tag'))
    ECULefxDBQvAXNgpTlaPKdMqWSOIGn={'id':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('id'),'title':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('title'),'thumbnail':{'thumb':ECULefxDBQvAXNgpTlaPKdMqWSOIGV,'fanart':ECULefxDBQvAXNgpTlaPKdMqWSOIGV},'mpaa':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('age_rating'),'duration':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('running_time'),'asis':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('as'),'year':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('meta').get('releaseYear'),'episode':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('episode'),'genreList':ECULefxDBQvAXNgpTlaPKdMqWSOIGJ,'desc':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('description'),}
    ECULefxDBQvAXNgpTlaPKdMqWSOIGw.append(ECULefxDBQvAXNgpTlaPKdMqWSOIGn)
  except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
   ECULefxDBQvAXNgpTlaPKdMqWSOIRk(exception)
   return[]
  return ECULefxDBQvAXNgpTlaPKdMqWSOIGw
 def Get_Episode_List(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,programId,season,page=1,orderby='asc'):
  ECULefxDBQvAXNgpTlaPKdMqWSOIGw=[] 
  ECULefxDBQvAXNgpTlaPKdMqWSOIGj=ECULefxDBQvAXNgpTlaPKdMqWSOIRi
  try:
   ECULefxDBQvAXNgpTlaPKdMqWSOIFu=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.API_DOMAIN+'/api-discover/v2/discover/titles/'+programId+'/episodes'
   ECULefxDBQvAXNgpTlaPKdMqWSOIGF={'seasonRange':'{}~{}'.format(season,season),'page':ECULefxDBQvAXNgpTlaPKdMqWSOIRz(page),'overrideSortOrder':orderby,'titleId':programId,'locale':'ko','perPage':ECULefxDBQvAXNgpTlaPKdMqWSOIRz(ECULefxDBQvAXNgpTlaPKdMqWSOIwm.PAGE_LIMIT),'disableCache':'false','includeChannelContents':'false','platform':'WEBCLIENT','sort':'true',}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFG={'x-membersrl':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['COOKIES']['member_srl'],'x-pcid':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['COOKIES']['PCID'],'x-profileid':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT','x-app-version':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.x_app_version,}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFh=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.callRequestCookies('Get',ECULefxDBQvAXNgpTlaPKdMqWSOIFu,payload=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,params=ECULefxDBQvAXNgpTlaPKdMqWSOIGF,headers=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,cookies=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,redirects=ECULefxDBQvAXNgpTlaPKdMqWSOIbm)
   if ECULefxDBQvAXNgpTlaPKdMqWSOIFh.status_code not in[200]:return[],ECULefxDBQvAXNgpTlaPKdMqWSOIRi
   ECULefxDBQvAXNgpTlaPKdMqWSOIFi=json.loads(ECULefxDBQvAXNgpTlaPKdMqWSOIFh.text)
   for ECULefxDBQvAXNgpTlaPKdMqWSOIGb in ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('data'):
    ECULefxDBQvAXNgpTlaPKdMqWSOIGV=''
    if 'story-art' in ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('images'):ECULefxDBQvAXNgpTlaPKdMqWSOIGV =ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('images').get('story-art').get('url')+'?imwidth=600'
    ECULefxDBQvAXNgpTlaPKdMqWSOIGJ =[]
    for ECULefxDBQvAXNgpTlaPKdMqWSOIGy in ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('tags'):
     ECULefxDBQvAXNgpTlaPKdMqWSOIGJ.append(ECULefxDBQvAXNgpTlaPKdMqWSOIGy.get('tag'))
    ECULefxDBQvAXNgpTlaPKdMqWSOIGn={'id':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('id'),'title':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('title'),'thumbnail':{'thumb':ECULefxDBQvAXNgpTlaPKdMqWSOIGV,'fanart':ECULefxDBQvAXNgpTlaPKdMqWSOIGV},'mpaa':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('age_rating'),'duration':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('running_time'),'asis':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('as'),'year':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('meta').get('releaseYear'),'episode':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('episode'),'genreList':ECULefxDBQvAXNgpTlaPKdMqWSOIGJ,'desc':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('description'),}
    ECULefxDBQvAXNgpTlaPKdMqWSOIGw.append(ECULefxDBQvAXNgpTlaPKdMqWSOIGn)
   if ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('pagination').get('totalPages')>page:
    ECULefxDBQvAXNgpTlaPKdMqWSOIGj=ECULefxDBQvAXNgpTlaPKdMqWSOIbm
  except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
   ECULefxDBQvAXNgpTlaPKdMqWSOIRk(exception)
   return[]
  return ECULefxDBQvAXNgpTlaPKdMqWSOIGw,ECULefxDBQvAXNgpTlaPKdMqWSOIGj
 def Get_vInfo(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,titleId):
  try:
   ECULefxDBQvAXNgpTlaPKdMqWSOIFu=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.API_DOMAIN+'/api-discover/v1/discover/titles/'+titleId 
   ECULefxDBQvAXNgpTlaPKdMqWSOIGF={'platform':'WEBCLIENT','locale':'ko','filterRestrictedContent':'false',}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFh=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.callRequestCookies('Get',ECULefxDBQvAXNgpTlaPKdMqWSOIFu,payload=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,params=ECULefxDBQvAXNgpTlaPKdMqWSOIGF,headers=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,cookies=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,redirects=ECULefxDBQvAXNgpTlaPKdMqWSOIbm)
   if ECULefxDBQvAXNgpTlaPKdMqWSOIFh.status_code not in[200]:return '','',''
   ECULefxDBQvAXNgpTlaPKdMqWSOIFi=json.loads(ECULefxDBQvAXNgpTlaPKdMqWSOIFh.text).get('data')
   ECULefxDBQvAXNgpTlaPKdMqWSOIGh=''
   if ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('seasonList')!=ECULefxDBQvAXNgpTlaPKdMqWSOIRs:
    ECULefxDBQvAXNgpTlaPKdMqWSOIGh=','.join(ECULefxDBQvAXNgpTlaPKdMqWSOIRz(e)for e in ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('seasonList'))
   ECULefxDBQvAXNgpTlaPKdMqWSOIGr={'age_rating':ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('age_rating'),'asset_id':ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('asset_id'),'availability':ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('availability'),'deal_id':ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('deal_id'),'downloadable':'true' if ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('downloadable')else 'false','region':ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('region'),'streamable':'true' if ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('streamable')else 'false','asis':ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('as'),'seasonList':ECULefxDBQvAXNgpTlaPKdMqWSOIGh}
  except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
   ECULefxDBQvAXNgpTlaPKdMqWSOIRk(exception)
   return{}
  return ECULefxDBQvAXNgpTlaPKdMqWSOIGr
 def Get_eInfo(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,eventId):
  try:
   ECULefxDBQvAXNgpTlaPKdMqWSOIFu=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.API_DOMAIN+'/api-discover/v1/discover/events/'+eventId 
   ECULefxDBQvAXNgpTlaPKdMqWSOIGF={'locale':'ko','platform':'WEBCLIENT','includeSportsChannelContents':'true',}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFh=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.callRequestCookies('Get',ECULefxDBQvAXNgpTlaPKdMqWSOIFu,payload=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,params=ECULefxDBQvAXNgpTlaPKdMqWSOIGF,headers=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,cookies=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,redirects=ECULefxDBQvAXNgpTlaPKdMqWSOIbm)
   if ECULefxDBQvAXNgpTlaPKdMqWSOIFh.status_code not in[200]:return '','',''
   ECULefxDBQvAXNgpTlaPKdMqWSOIFi=json.loads(ECULefxDBQvAXNgpTlaPKdMqWSOIFh.text).get('data')
   ECULefxDBQvAXNgpTlaPKdMqWSOIGr={'asset_id':ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('asset_id'),'deal_id':ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('deal_id'),'region':ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('region'),'streamable':'true' if ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('streamable')else 'false',}
  except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
   ECULefxDBQvAXNgpTlaPKdMqWSOIRk(exception)
   return{}
  return ECULefxDBQvAXNgpTlaPKdMqWSOIGr
 def GetBroadURL(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,titleId):
  ECULefxDBQvAXNgpTlaPKdMqWSOIGs=''
  ECULefxDBQvAXNgpTlaPKdMqWSOIGi =''
  ECULefxDBQvAXNgpTlaPKdMqWSOIGr=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.Get_vInfo(titleId)
  if ECULefxDBQvAXNgpTlaPKdMqWSOIGr=={}:return '',''
  try:
   ECULefxDBQvAXNgpTlaPKdMqWSOIFu=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.API_DOMAIN+'/api/playback/play' 
   ECULefxDBQvAXNgpTlaPKdMqWSOIGF={'titleId':titleId}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFR,ECULefxDBQvAXNgpTlaPKdMqWSOIFb,ECULefxDBQvAXNgpTlaPKdMqWSOIFH=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.Make_authHeader()
   ECULefxDBQvAXNgpTlaPKdMqWSOIFG={'traceparent':ECULefxDBQvAXNgpTlaPKdMqWSOIFR,'tracestate':ECULefxDBQvAXNgpTlaPKdMqWSOIFb,'newrelic':ECULefxDBQvAXNgpTlaPKdMqWSOIFH,'x-drm':'com.microsoft.playready','x-app-version':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.x_app_version,'x-device-id':'','x-device-os-version':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.OS_VERSION,'x-force-raw':'true','x-nr-session-id':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['COOKIES']['session_web_id'],'x-pcid':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['COOKIES']['PCID'],'x-platform':'web','x-profileId':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['SESSION']['profileId'],'x-profileType':'standard','x-sessionid':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.generatePvId(genType='1'),'x-title-age-rating':ECULefxDBQvAXNgpTlaPKdMqWSOIGr.get('age_rating'),'x-title-availability':ECULefxDBQvAXNgpTlaPKdMqWSOIGr.get('availability'),'x-title-brightcove-id':ECULefxDBQvAXNgpTlaPKdMqWSOIGr.get('asset_id'),'x-title-deal-id':ECULefxDBQvAXNgpTlaPKdMqWSOIGr.get('deal_id'),'x-title-downloadable':ECULefxDBQvAXNgpTlaPKdMqWSOIGr.get('downloadable'),'x-title-region':ECULefxDBQvAXNgpTlaPKdMqWSOIGr.get('region'),'x-title-streamable':ECULefxDBQvAXNgpTlaPKdMqWSOIGr.get('streamable'),}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFt=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.make_CP_DefaultCookies()
   ECULefxDBQvAXNgpTlaPKdMqWSOIFh=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.callRequestCookies('Get',ECULefxDBQvAXNgpTlaPKdMqWSOIFu,payload=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,params=ECULefxDBQvAXNgpTlaPKdMqWSOIGF,headers=ECULefxDBQvAXNgpTlaPKdMqWSOIFG,cookies=ECULefxDBQvAXNgpTlaPKdMqWSOIFt,redirects=ECULefxDBQvAXNgpTlaPKdMqWSOIbm)
   if ECULefxDBQvAXNgpTlaPKdMqWSOIFh.status_code not in[200]:return '',json.loads(ECULefxDBQvAXNgpTlaPKdMqWSOIFh.text).get('error').get('detail')
   ECULefxDBQvAXNgpTlaPKdMqWSOIFi=json.loads(ECULefxDBQvAXNgpTlaPKdMqWSOIFh.text)
   if ECULefxDBQvAXNgpTlaPKdMqWSOIGs=='':
    for ECULefxDBQvAXNgpTlaPKdMqWSOIGb in ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('data').get('raw').get('sources'):
     if 'key_systems' in ECULefxDBQvAXNgpTlaPKdMqWSOIGb and 'codecs' not in ECULefxDBQvAXNgpTlaPKdMqWSOIGb:
      if ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('type')=='application/dash+xml' and 'com.widevine.alpha' in ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('key_systems')and ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('src').startswith('https://')==ECULefxDBQvAXNgpTlaPKdMqWSOIbm:
       ECULefxDBQvAXNgpTlaPKdMqWSOIGs=ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('src')
       ECULefxDBQvAXNgpTlaPKdMqWSOIGi =ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if ECULefxDBQvAXNgpTlaPKdMqWSOIGs=='':
    for ECULefxDBQvAXNgpTlaPKdMqWSOIGb in ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('data').get('raw').get('sources'):
     if 'key_systems' in ECULefxDBQvAXNgpTlaPKdMqWSOIGb and 'codecs' not in ECULefxDBQvAXNgpTlaPKdMqWSOIGb:
      if ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('key_systems')and ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('src').startswith('https://')==ECULefxDBQvAXNgpTlaPKdMqWSOIbm:
       ECULefxDBQvAXNgpTlaPKdMqWSOIGs=ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('src')
       ECULefxDBQvAXNgpTlaPKdMqWSOIGi =ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if ECULefxDBQvAXNgpTlaPKdMqWSOIGs=='':
    for ECULefxDBQvAXNgpTlaPKdMqWSOIGb in ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('data').get('raw').get('sources'):
     if 'key_systems' in ECULefxDBQvAXNgpTlaPKdMqWSOIGb and 'codecs' in ECULefxDBQvAXNgpTlaPKdMqWSOIGb:
      if ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('type')=='application/dash+xml' and 'com.widevine.alpha' in ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('key_systems')and ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('src').startswith('https://')==ECULefxDBQvAXNgpTlaPKdMqWSOIbm:
       ECULefxDBQvAXNgpTlaPKdMqWSOIGs=ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('src')
       ECULefxDBQvAXNgpTlaPKdMqWSOIGi =ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if ECULefxDBQvAXNgpTlaPKdMqWSOIGs=='':
    for ECULefxDBQvAXNgpTlaPKdMqWSOIGb in ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('data').get('raw').get('sources'):
     if 'key_systems' in ECULefxDBQvAXNgpTlaPKdMqWSOIGb and 'codecs' in ECULefxDBQvAXNgpTlaPKdMqWSOIGb:
      if ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('key_systems')and ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('src').startswith('https://')==ECULefxDBQvAXNgpTlaPKdMqWSOIbm:
       ECULefxDBQvAXNgpTlaPKdMqWSOIGs=ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('src')
       ECULefxDBQvAXNgpTlaPKdMqWSOIGi =ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
  except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
   ECULefxDBQvAXNgpTlaPKdMqWSOIRk(exception)
   return '',''
  return ECULefxDBQvAXNgpTlaPKdMqWSOIGs,ECULefxDBQvAXNgpTlaPKdMqWSOIGi
 def GetEventURL(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,eventId,ECULefxDBQvAXNgpTlaPKdMqWSOImH):
  ECULefxDBQvAXNgpTlaPKdMqWSOIGs=''
  ECULefxDBQvAXNgpTlaPKdMqWSOIGi =''
  ECULefxDBQvAXNgpTlaPKdMqWSOIGr=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.Get_eInfo(eventId)
  if ECULefxDBQvAXNgpTlaPKdMqWSOIGr=={}:return '',''
  try:
   ECULefxDBQvAXNgpTlaPKdMqWSOIFu=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.API_DOMAIN+'/api/playback/play' 
   ECULefxDBQvAXNgpTlaPKdMqWSOIGF={'titleId':eventId,'titleType':ECULefxDBQvAXNgpTlaPKdMqWSOImH,}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFR,ECULefxDBQvAXNgpTlaPKdMqWSOIFb,ECULefxDBQvAXNgpTlaPKdMqWSOIFH=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.Make_authHeader()
   ECULefxDBQvAXNgpTlaPKdMqWSOIFG={'traceparent':ECULefxDBQvAXNgpTlaPKdMqWSOIFR,'tracestate':ECULefxDBQvAXNgpTlaPKdMqWSOIFb,'newrelic':ECULefxDBQvAXNgpTlaPKdMqWSOIFH,'x-force-raw':'true','x-pcid':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['COOKIES']['PCID'],'x-platform':'web','x-profileId':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-downloadable':'undefined','x-title-brightcove-id':ECULefxDBQvAXNgpTlaPKdMqWSOIGr.get('asset_id'),'x-title-deal-id':ECULefxDBQvAXNgpTlaPKdMqWSOIGr.get('deal_id'),'x-title-region':ECULefxDBQvAXNgpTlaPKdMqWSOIGr.get('region'),'x-title-streamable':ECULefxDBQvAXNgpTlaPKdMqWSOIGr.get('streamable'),}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFt=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.make_CP_DefaultCookies()
   ECULefxDBQvAXNgpTlaPKdMqWSOIFh=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.callRequestCookies('Get',ECULefxDBQvAXNgpTlaPKdMqWSOIFu,payload=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,params=ECULefxDBQvAXNgpTlaPKdMqWSOIGF,headers=ECULefxDBQvAXNgpTlaPKdMqWSOIFG,cookies=ECULefxDBQvAXNgpTlaPKdMqWSOIFt,redirects=ECULefxDBQvAXNgpTlaPKdMqWSOIbm)
   if ECULefxDBQvAXNgpTlaPKdMqWSOIFh.status_code not in[200]:return '',json.loads(ECULefxDBQvAXNgpTlaPKdMqWSOIFh.text).get('error').get('detail')
   ECULefxDBQvAXNgpTlaPKdMqWSOIFi=json.loads(ECULefxDBQvAXNgpTlaPKdMqWSOIFh.text)
   for ECULefxDBQvAXNgpTlaPKdMqWSOIGb in ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('data').get('raw').get('sources'):
    if ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('type')=='application/dash+xml' and ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('src')[0:8]=='https://':
     ECULefxDBQvAXNgpTlaPKdMqWSOIGs=ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('src')
     if 'key_systems' in ECULefxDBQvAXNgpTlaPKdMqWSOIGb:
      ECULefxDBQvAXNgpTlaPKdMqWSOIGi =ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('key_systems').get('com.widevine.alpha').get('license_url')
     break
  except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
   ECULefxDBQvAXNgpTlaPKdMqWSOIRk(exception)
   return '',''
  return ECULefxDBQvAXNgpTlaPKdMqWSOIGs,ECULefxDBQvAXNgpTlaPKdMqWSOIGi
 def GetEventURL_Live(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,eventId,ECULefxDBQvAXNgpTlaPKdMqWSOImH):
  ECULefxDBQvAXNgpTlaPKdMqWSOIGs=''
  ECULefxDBQvAXNgpTlaPKdMqWSOIGi =''
  ECULefxDBQvAXNgpTlaPKdMqWSOIGr=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.Get_eInfo(eventId)
  if ECULefxDBQvAXNgpTlaPKdMqWSOIGr=={}:return '',''
  try:
   ECULefxDBQvAXNgpTlaPKdMqWSOIFu=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.API_DOMAIN+'/api/playback/play' 
   ECULefxDBQvAXNgpTlaPKdMqWSOIGF={'titleId':eventId,'titleType':ECULefxDBQvAXNgpTlaPKdMqWSOImH,}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFR,ECULefxDBQvAXNgpTlaPKdMqWSOIFb,ECULefxDBQvAXNgpTlaPKdMqWSOIFH=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.Make_authHeader()
   ECULefxDBQvAXNgpTlaPKdMqWSOIFG={'traceparent':ECULefxDBQvAXNgpTlaPKdMqWSOIFR,'tracestate':ECULefxDBQvAXNgpTlaPKdMqWSOIFb,'newrelic':ECULefxDBQvAXNgpTlaPKdMqWSOIFH,'x-force-raw':'true','x-pcid':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['COOKIES']['PCID'],'x-platform':'web','x-profileId':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':ECULefxDBQvAXNgpTlaPKdMqWSOIGr.get('asset_id'),'x-title-deal-id':ECULefxDBQvAXNgpTlaPKdMqWSOIGr.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':ECULefxDBQvAXNgpTlaPKdMqWSOIGr.get('region'),'x-title-streamable':ECULefxDBQvAXNgpTlaPKdMqWSOIGr.get('streamable'),}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFt=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.make_CP_DefaultCookies()
   ECULefxDBQvAXNgpTlaPKdMqWSOIFh=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.callRequestCookies('Get',ECULefxDBQvAXNgpTlaPKdMqWSOIFu,payload=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,params=ECULefxDBQvAXNgpTlaPKdMqWSOIGF,headers=ECULefxDBQvAXNgpTlaPKdMqWSOIFG,cookies=ECULefxDBQvAXNgpTlaPKdMqWSOIFt,redirects=ECULefxDBQvAXNgpTlaPKdMqWSOIbm)
   if ECULefxDBQvAXNgpTlaPKdMqWSOIFh.status_code not in[200]:return '',json.loads(ECULefxDBQvAXNgpTlaPKdMqWSOIFh.text).get('error').get('detail')
   ECULefxDBQvAXNgpTlaPKdMqWSOIFi=json.loads(ECULefxDBQvAXNgpTlaPKdMqWSOIFh.text)
   if ECULefxDBQvAXNgpTlaPKdMqWSOIGs=='':
    for ECULefxDBQvAXNgpTlaPKdMqWSOIGb in ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('data').get('raw').get('sources'):
     if 'key_systems' in ECULefxDBQvAXNgpTlaPKdMqWSOIGb:
      if ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('type')=='application/dash+xml' and 'com.widevine.alpha' in ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('key_systems')and ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('src').startswith('https://')==ECULefxDBQvAXNgpTlaPKdMqWSOIbm:
       ECULefxDBQvAXNgpTlaPKdMqWSOIGs=ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('src')
       ECULefxDBQvAXNgpTlaPKdMqWSOIGi =ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('key_systems').get('com.widevine.alpha').get('license_url')
   if ECULefxDBQvAXNgpTlaPKdMqWSOIGs=='':
    for ECULefxDBQvAXNgpTlaPKdMqWSOIGb in ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('data').get('raw').get('sources'):
     if 'key_systems' in ECULefxDBQvAXNgpTlaPKdMqWSOIGb:
      if ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('key_systems')and ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('src').startswith('https://')==ECULefxDBQvAXNgpTlaPKdMqWSOIbm:
       ECULefxDBQvAXNgpTlaPKdMqWSOIGs=ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('src')
       ECULefxDBQvAXNgpTlaPKdMqWSOIGi =ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('key_systems').get('com.widevine.alpha').get('license_url')
   if ECULefxDBQvAXNgpTlaPKdMqWSOIGs=='':
    for ECULefxDBQvAXNgpTlaPKdMqWSOIGb in ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('data').get('raw').get('sources'):
     if ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('type')=='application/dash+xml' and ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('src').startswith('https://')==ECULefxDBQvAXNgpTlaPKdMqWSOIbm:
      ECULefxDBQvAXNgpTlaPKdMqWSOIGs=ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('src')
   if ECULefxDBQvAXNgpTlaPKdMqWSOIGs=='':
    for ECULefxDBQvAXNgpTlaPKdMqWSOIGb in ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('data').get('raw').get('sources'):
     if ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('type')=='application/x-mpegURL' and ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('src').startswith('https://')==ECULefxDBQvAXNgpTlaPKdMqWSOIbm:
      ECULefxDBQvAXNgpTlaPKdMqWSOIGs=ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('src')
  except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
   ECULefxDBQvAXNgpTlaPKdMqWSOIRk(exception)
   return '',''
  return ECULefxDBQvAXNgpTlaPKdMqWSOIGs,ECULefxDBQvAXNgpTlaPKdMqWSOIGi
 def Get_Url_PostFix(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,in_url):
  ECULefxDBQvAXNgpTlaPKdMqWSOIGk=urllib.parse.urlparse(in_url) 
  ECULefxDBQvAXNgpTlaPKdMqWSOIGz =ECULefxDBQvAXNgpTlaPKdMqWSOIGk.path.strip('/').split('/')
  ECULefxDBQvAXNgpTlaPKdMqWSOIGY =ECULefxDBQvAXNgpTlaPKdMqWSOIGz[ECULefxDBQvAXNgpTlaPKdMqWSOIbF(ECULefxDBQvAXNgpTlaPKdMqWSOIGz)-1]
  ECULefxDBQvAXNgpTlaPKdMqWSOIGo=ECULefxDBQvAXNgpTlaPKdMqWSOIGY.split('.')
  return ECULefxDBQvAXNgpTlaPKdMqWSOIGo[ECULefxDBQvAXNgpTlaPKdMqWSOIbF(ECULefxDBQvAXNgpTlaPKdMqWSOIGo)-1]
 def Get_Theme_GroupList(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,vType):
  ECULefxDBQvAXNgpTlaPKdMqWSOIGw=[] 
  try:
   ECULefxDBQvAXNgpTlaPKdMqWSOIFu=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.API_DOMAIN+'/api-discover/v3/discover/feed' 
   ECULefxDBQvAXNgpTlaPKdMqWSOIGF={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':ECULefxDBQvAXNgpTlaPKdMqWSOIRz(ECULefxDBQvAXNgpTlaPKdMqWSOIwm.PAGE_LIMIT),'filterRestrictedContent':'false','preferRecoFeed':'true','preferMultiHeroMixedContentRow':'true','shouldIncludeTVOD':'true','includeChannelContents':'false',}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFh=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.callRequestCookies('Get',ECULefxDBQvAXNgpTlaPKdMqWSOIFu,payload=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,params=ECULefxDBQvAXNgpTlaPKdMqWSOIGF,headers=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,cookies=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,redirects=ECULefxDBQvAXNgpTlaPKdMqWSOIbm)
   if ECULefxDBQvAXNgpTlaPKdMqWSOIFh.status_code not in[200]:return[]
   ECULefxDBQvAXNgpTlaPKdMqWSOIFi=json.loads(ECULefxDBQvAXNgpTlaPKdMqWSOIFh.text)
   for ECULefxDBQvAXNgpTlaPKdMqWSOIGb in ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('data'):
    if ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('type')=='Title-Rails-Curation':
     ECULefxDBQvAXNgpTlaPKdMqWSOImw =''
     ECULefxDBQvAXNgpTlaPKdMqWSOImF=7
     try:
      for i in ECULefxDBQvAXNgpTlaPKdMqWSOIbR(ECULefxDBQvAXNgpTlaPKdMqWSOIbF(ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('data'))):
       if i>=ECULefxDBQvAXNgpTlaPKdMqWSOImF:
        ECULefxDBQvAXNgpTlaPKdMqWSOImw=ECULefxDBQvAXNgpTlaPKdMqWSOImw+'...'
        break
       ECULefxDBQvAXNgpTlaPKdMqWSOImw=ECULefxDBQvAXNgpTlaPKdMqWSOImw+ECULefxDBQvAXNgpTlaPKdMqWSOIGb['data'][i]['title']+'\n'
     except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
      ECULefxDBQvAXNgpTlaPKdMqWSOIRk(exception)
     ECULefxDBQvAXNgpTlaPKdMqWSOIGn={'collectionId':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('obj_id'),'title':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('row_name'),'category':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('category'),'pre_title':ECULefxDBQvAXNgpTlaPKdMqWSOImw,}
     ECULefxDBQvAXNgpTlaPKdMqWSOIGw.append(ECULefxDBQvAXNgpTlaPKdMqWSOIGn)
  except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
   ECULefxDBQvAXNgpTlaPKdMqWSOIRk(exception)
   return[]
  return ECULefxDBQvAXNgpTlaPKdMqWSOIGw
 def Get_Event_GroupList(ECULefxDBQvAXNgpTlaPKdMqWSOIwm):
  ECULefxDBQvAXNgpTlaPKdMqWSOIGw=[] 
  try:
   ECULefxDBQvAXNgpTlaPKdMqWSOIFu=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.API_DOMAIN+'/api-discover/v3/discover/feed' 
   ECULefxDBQvAXNgpTlaPKdMqWSOIGF={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':7,'filterRestrictedContent':'false','preferRecoFeed':'true','preferMultiHeroMixedContentRow':'true','shouldIncludeTVOD':'true','includeChannelContents':'false',}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFh=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.callRequestCookies('Get',ECULefxDBQvAXNgpTlaPKdMqWSOIFu,payload=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,params=ECULefxDBQvAXNgpTlaPKdMqWSOIGF,headers=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,cookies=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,redirects=ECULefxDBQvAXNgpTlaPKdMqWSOIbm)
   if ECULefxDBQvAXNgpTlaPKdMqWSOIFh.status_code not in[200]:return[]
   ECULefxDBQvAXNgpTlaPKdMqWSOIFi=json.loads(ECULefxDBQvAXNgpTlaPKdMqWSOIFh.text)
   for ECULefxDBQvAXNgpTlaPKdMqWSOIGb in ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('data'):
    if ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('row_name').strip()!='':
     ECULefxDBQvAXNgpTlaPKdMqWSOImw =''
     ECULefxDBQvAXNgpTlaPKdMqWSOImF=7
     try:
      for i in ECULefxDBQvAXNgpTlaPKdMqWSOIbR(ECULefxDBQvAXNgpTlaPKdMqWSOIbF(ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('data'))):
       if i>=ECULefxDBQvAXNgpTlaPKdMqWSOImF:
        ECULefxDBQvAXNgpTlaPKdMqWSOImw=ECULefxDBQvAXNgpTlaPKdMqWSOImw+'...'
        break
       ECULefxDBQvAXNgpTlaPKdMqWSOImw=ECULefxDBQvAXNgpTlaPKdMqWSOImw+ECULefxDBQvAXNgpTlaPKdMqWSOIGb['data'][i]['title']+'\n'
     except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
      ECULefxDBQvAXNgpTlaPKdMqWSOIRk(exception)
     ECULefxDBQvAXNgpTlaPKdMqWSOIGn={'collectionId':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('obj_id'),'title':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('row_name'),'category':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('type'),'pre_title':ECULefxDBQvAXNgpTlaPKdMqWSOImw,}
     ECULefxDBQvAXNgpTlaPKdMqWSOIGw.append(ECULefxDBQvAXNgpTlaPKdMqWSOIGn)
  except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
   ECULefxDBQvAXNgpTlaPKdMqWSOIRk(exception)
   return[]
  return ECULefxDBQvAXNgpTlaPKdMqWSOIGw
 def Get_Event_GameList(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,ECULefxDBQvAXNgpTlaPKdMqWSOIGH):
  ECULefxDBQvAXNgpTlaPKdMqWSOIGw=[] 
  try:
   ECULefxDBQvAXNgpTlaPKdMqWSOIFu=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.API_DOMAIN+'/api-discover/v3/discover/feed' 
   ECULefxDBQvAXNgpTlaPKdMqWSOIGF={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':7,'filterRestrictedContent':'false','preferRecoFeed':'true','preferMultiHeroMixedContentRow':'true','shouldIncludeTVOD':'true','includeChannelContents':'false',}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFh=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.callRequestCookies('Get',ECULefxDBQvAXNgpTlaPKdMqWSOIFu,payload=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,params=ECULefxDBQvAXNgpTlaPKdMqWSOIGF,headers=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,cookies=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,redirects=ECULefxDBQvAXNgpTlaPKdMqWSOIbm)
   if ECULefxDBQvAXNgpTlaPKdMqWSOIFh.status_code not in[200]:return[]
   ECULefxDBQvAXNgpTlaPKdMqWSOIFi=json.loads(ECULefxDBQvAXNgpTlaPKdMqWSOIFh.text)
   for ECULefxDBQvAXNgpTlaPKdMqWSOIGb in ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('data'):
    if ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('obj_id')==ECULefxDBQvAXNgpTlaPKdMqWSOIGH:
     for ECULefxDBQvAXNgpTlaPKdMqWSOImG in ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('data'):
      ECULefxDBQvAXNgpTlaPKdMqWSOIGu=ECULefxDBQvAXNgpTlaPKdMqWSOIGV=ECULefxDBQvAXNgpTlaPKdMqWSOImt=''
      if 'poster_url' in ECULefxDBQvAXNgpTlaPKdMqWSOImG.get('images'):ECULefxDBQvAXNgpTlaPKdMqWSOIGu =ECULefxDBQvAXNgpTlaPKdMqWSOImG.get('images').get('poster_url') +'?imwidth=350'
      if 'story_art_url' in ECULefxDBQvAXNgpTlaPKdMqWSOImG.get('images'):ECULefxDBQvAXNgpTlaPKdMqWSOIGV =ECULefxDBQvAXNgpTlaPKdMqWSOImG.get('images').get('story_art_url')+'?imwidth=600'
      if 'hero_url' in ECULefxDBQvAXNgpTlaPKdMqWSOImG.get('images'):ECULefxDBQvAXNgpTlaPKdMqWSOImt =ECULefxDBQvAXNgpTlaPKdMqWSOImG.get('images').get('hero_url') +'?imwidth=600'
      ECULefxDBQvAXNgpTlaPKdMqWSOIGn={'id':ECULefxDBQvAXNgpTlaPKdMqWSOImG.get('id'),'title':ECULefxDBQvAXNgpTlaPKdMqWSOImG.get('title'),'thumbnail':{'poster':ECULefxDBQvAXNgpTlaPKdMqWSOIGu,'thumb':ECULefxDBQvAXNgpTlaPKdMqWSOIGV,'fanart':ECULefxDBQvAXNgpTlaPKdMqWSOImt},'asis':ECULefxDBQvAXNgpTlaPKdMqWSOImG.get('type'),'starttm':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.convert_TimeStr(ECULefxDBQvAXNgpTlaPKdMqWSOImG.get('startAt')),}
      ECULefxDBQvAXNgpTlaPKdMqWSOIGw.append(ECULefxDBQvAXNgpTlaPKdMqWSOIGn)
  except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
   ECULefxDBQvAXNgpTlaPKdMqWSOIRk(exception)
   return[]
  return ECULefxDBQvAXNgpTlaPKdMqWSOIGw
 def Get_Event_List(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,gameId):
  ECULefxDBQvAXNgpTlaPKdMqWSOIGw=[] 
  try:
   ECULefxDBQvAXNgpTlaPKdMqWSOIFu=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.API_DOMAIN+'/api-discover/v1/discover/events/'+gameId 
   ECULefxDBQvAXNgpTlaPKdMqWSOIGF={'platform':'WEBCLIENT','locale':'ko','filterRestrictedContent':'false',}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFh=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.callRequestCookies('Get',ECULefxDBQvAXNgpTlaPKdMqWSOIFu,payload=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,params=ECULefxDBQvAXNgpTlaPKdMqWSOIGF,headers=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,cookies=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,redirects=ECULefxDBQvAXNgpTlaPKdMqWSOIbm)
   if ECULefxDBQvAXNgpTlaPKdMqWSOIFh.status_code not in[200]:return[]
   ECULefxDBQvAXNgpTlaPKdMqWSOIFi=json.loads(ECULefxDBQvAXNgpTlaPKdMqWSOIFh.text)
   ECULefxDBQvAXNgpTlaPKdMqWSOIGb=ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('data')
   ECULefxDBQvAXNgpTlaPKdMqWSOImR=ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('end_at')
   ECULefxDBQvAXNgpTlaPKdMqWSOImR=ECULefxDBQvAXNgpTlaPKdMqWSOImR[0:19].replace('-','').replace(':','').replace('T','')
   ECULefxDBQvAXNgpTlaPKdMqWSOImb=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d%H%M%S')
   if ECULefxDBQvAXNgpTlaPKdMqWSOIbw(ECULefxDBQvAXNgpTlaPKdMqWSOImb)<ECULefxDBQvAXNgpTlaPKdMqWSOIbw(ECULefxDBQvAXNgpTlaPKdMqWSOImR):
    ECULefxDBQvAXNgpTlaPKdMqWSOIGu=ECULefxDBQvAXNgpTlaPKdMqWSOIGV=ECULefxDBQvAXNgpTlaPKdMqWSOImt=''
    if 'poster' in ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('images'):ECULefxDBQvAXNgpTlaPKdMqWSOIGu =ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('images'):ECULefxDBQvAXNgpTlaPKdMqWSOIGV =ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('images').get('story-art').get('url')+'?imwidth=600'
    if 'story-art' in ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('images'):ECULefxDBQvAXNgpTlaPKdMqWSOImt =ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('images').get('story-art').get('url')+'?imwidth=600'
    ECULefxDBQvAXNgpTlaPKdMqWSOIGn={'id':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('id'),'title':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('title'),'thumbnail':{'poster':ECULefxDBQvAXNgpTlaPKdMqWSOIGu,'thumb':ECULefxDBQvAXNgpTlaPKdMqWSOIGV,'fanart':ECULefxDBQvAXNgpTlaPKdMqWSOImt},'duration':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('running_time'),'asis':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('type'),'starttm':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.convert_TimeStr(ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('start_at')),}
    ECULefxDBQvAXNgpTlaPKdMqWSOIGw.append(ECULefxDBQvAXNgpTlaPKdMqWSOIGn)
  except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
   ECULefxDBQvAXNgpTlaPKdMqWSOIRk(exception)
   return[]
  try:
   ECULefxDBQvAXNgpTlaPKdMqWSOIFu=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.API_DOMAIN+'/api-discover/v1/discover/events/'+gameId+'/related' 
   ECULefxDBQvAXNgpTlaPKdMqWSOIGF={'locale':'ko','page':'1','perPage':'25','platform':'WEBCLIENT','currentPageTracking':'page_discover_title_detail',}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFh=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.callRequestCookies('Get',ECULefxDBQvAXNgpTlaPKdMqWSOIFu,payload=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,params=ECULefxDBQvAXNgpTlaPKdMqWSOIGF,headers=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,cookies=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,redirects=ECULefxDBQvAXNgpTlaPKdMqWSOIbm)
   if ECULefxDBQvAXNgpTlaPKdMqWSOIFh.status_code not in[200]:return[]
   ECULefxDBQvAXNgpTlaPKdMqWSOIFi=json.loads(ECULefxDBQvAXNgpTlaPKdMqWSOIFh.text)
   for ECULefxDBQvAXNgpTlaPKdMqWSOIGb in ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('data').get('data'):
    ECULefxDBQvAXNgpTlaPKdMqWSOIGu=ECULefxDBQvAXNgpTlaPKdMqWSOIGV=ECULefxDBQvAXNgpTlaPKdMqWSOImt=''
    if 'poster' in ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('images'):ECULefxDBQvAXNgpTlaPKdMqWSOIGu =ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('images'):ECULefxDBQvAXNgpTlaPKdMqWSOIGV =ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('images').get('story-art').get('url')+'?imwidth=600'
    if 'story-art' in ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('images'):ECULefxDBQvAXNgpTlaPKdMqWSOImt =ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('images').get('story-art').get('url')+'?imwidth=600'
    ECULefxDBQvAXNgpTlaPKdMqWSOIGn={'id':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('id'),'title':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('title'),'thumbnail':{'poster':ECULefxDBQvAXNgpTlaPKdMqWSOIGu,'thumb':ECULefxDBQvAXNgpTlaPKdMqWSOIGV,'fanart':ECULefxDBQvAXNgpTlaPKdMqWSOImt},'duration':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('running_time'),'asis':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('type'),}
    ECULefxDBQvAXNgpTlaPKdMqWSOIGw.append(ECULefxDBQvAXNgpTlaPKdMqWSOIGn)
  except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
   ECULefxDBQvAXNgpTlaPKdMqWSOIRk(exception)
   return[]
  return ECULefxDBQvAXNgpTlaPKdMqWSOIGw
 def Get_Search_List(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,search_key,page_int):
  ECULefxDBQvAXNgpTlaPKdMqWSOIGw=[] 
  ECULefxDBQvAXNgpTlaPKdMqWSOIGj=ECULefxDBQvAXNgpTlaPKdMqWSOIRi
  try:
   ECULefxDBQvAXNgpTlaPKdMqWSOIFu=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.API_DOMAIN+'/api-discover/v2/search' 
   ECULefxDBQvAXNgpTlaPKdMqWSOIGF={'query':search_key,'platform':'WEBCLIENT','page':ECULefxDBQvAXNgpTlaPKdMqWSOIRz(page_int),'perPage':ECULefxDBQvAXNgpTlaPKdMqWSOIRz(ECULefxDBQvAXNgpTlaPKdMqWSOIwm.SEARCH_LIMIT),}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFG={'x-membersrl':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['COOKIES']['member_srl'],'x-pcid':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['COOKIES']['PCID'],'x-profileid':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT',}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFh=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.callRequestCookies('Get',ECULefxDBQvAXNgpTlaPKdMqWSOIFu,payload=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,params=ECULefxDBQvAXNgpTlaPKdMqWSOIGF,headers=ECULefxDBQvAXNgpTlaPKdMqWSOIFG,cookies=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,redirects=ECULefxDBQvAXNgpTlaPKdMqWSOIbm)
   if ECULefxDBQvAXNgpTlaPKdMqWSOIFh.status_code not in[200]:return[],ECULefxDBQvAXNgpTlaPKdMqWSOIRi
   ECULefxDBQvAXNgpTlaPKdMqWSOIFi=json.loads(ECULefxDBQvAXNgpTlaPKdMqWSOIFh.text)
   for ECULefxDBQvAXNgpTlaPKdMqWSOIGb in ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('data').get('data'):
    ECULefxDBQvAXNgpTlaPKdMqWSOIGb=ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('data')
    ECULefxDBQvAXNgpTlaPKdMqWSOIGu=ECULefxDBQvAXNgpTlaPKdMqWSOIGV=ECULefxDBQvAXNgpTlaPKdMqWSOImh=ECULefxDBQvAXNgpTlaPKdMqWSOImt=''
    if 'poster' in ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('images'):ECULefxDBQvAXNgpTlaPKdMqWSOIGu =ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('images'):ECULefxDBQvAXNgpTlaPKdMqWSOIGV =ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('images').get('story-art').get('url') +'?imwidth=600'
    if 'title-treatment' in ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('images'):ECULefxDBQvAXNgpTlaPKdMqWSOImh=ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('images').get('title-treatment').get('url')+'?imwidth=300'
    if 'story-art' in ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('images'):ECULefxDBQvAXNgpTlaPKdMqWSOImt =ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('images').get('story-art').get('url') +'?imwidth=600'
    ECULefxDBQvAXNgpTlaPKdMqWSOIGt=''
    if ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('badge')not in[{},ECULefxDBQvAXNgpTlaPKdMqWSOIRs]:
     for i in ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('badge').get('text'):
      if ECULefxDBQvAXNgpTlaPKdMqWSOIGt!='':ECULefxDBQvAXNgpTlaPKdMqWSOIGt+=' '
      ECULefxDBQvAXNgpTlaPKdMqWSOIGt+=i.get('text')
    if 'as' in ECULefxDBQvAXNgpTlaPKdMqWSOIGb:
     ECULefxDBQvAXNgpTlaPKdMqWSOImH=ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('as') 
    else:
     ECULefxDBQvAXNgpTlaPKdMqWSOImH=ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('type')
    ECULefxDBQvAXNgpTlaPKdMqWSOIGn={'id':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('id'),'title':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('title'),'asis':ECULefxDBQvAXNgpTlaPKdMqWSOImH,'thumbnail':{'poster':ECULefxDBQvAXNgpTlaPKdMqWSOIGu,'thumb':ECULefxDBQvAXNgpTlaPKdMqWSOIGV,'clearlogo':ECULefxDBQvAXNgpTlaPKdMqWSOImh,'fanart':ECULefxDBQvAXNgpTlaPKdMqWSOImt},'mpaa':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('age_rating'),'duration':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('running_time'),'badge':ECULefxDBQvAXNgpTlaPKdMqWSOIGt,'year':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('meta').get('releaseYear'),}
    ECULefxDBQvAXNgpTlaPKdMqWSOIGw.append(ECULefxDBQvAXNgpTlaPKdMqWSOIGn)
   if ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('pagination').get('totalPages')>page_int:
    ECULefxDBQvAXNgpTlaPKdMqWSOIGj=ECULefxDBQvAXNgpTlaPKdMqWSOIbm
  except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
   ECULefxDBQvAXNgpTlaPKdMqWSOIRk(exception)
   return[],ECULefxDBQvAXNgpTlaPKdMqWSOIRi
  return ECULefxDBQvAXNgpTlaPKdMqWSOIGw,ECULefxDBQvAXNgpTlaPKdMqWSOIGj
 def GetBookmarkInfo(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,videoid,vidtype):
  ECULefxDBQvAXNgpTlaPKdMqWSOImn={'indexinfo':{'ott':'coupang','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  ECULefxDBQvAXNgpTlaPKdMqWSOIFu=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.API_DOMAIN+'/api-discover/v1/discover/titles/'+videoid 
  ECULefxDBQvAXNgpTlaPKdMqWSOIGF={'locale':'ko'}
  ECULefxDBQvAXNgpTlaPKdMqWSOIFh=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.callRequestCookies('Get',ECULefxDBQvAXNgpTlaPKdMqWSOIFu,payload=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,params=ECULefxDBQvAXNgpTlaPKdMqWSOIGF,headers=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,cookies=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,redirects=ECULefxDBQvAXNgpTlaPKdMqWSOIbm)
  if ECULefxDBQvAXNgpTlaPKdMqWSOIFh.status_code not in[200]:return{}
  ECULefxDBQvAXNgpTlaPKdMqWSOImj=json.loads(ECULefxDBQvAXNgpTlaPKdMqWSOIFh.text).get('data')
  ECULefxDBQvAXNgpTlaPKdMqWSOImc=ECULefxDBQvAXNgpTlaPKdMqWSOImj.get('title')
  ECULefxDBQvAXNgpTlaPKdMqWSOImu =ECULefxDBQvAXNgpTlaPKdMqWSOImj.get('meta').get('releaseYear')
  ECULefxDBQvAXNgpTlaPKdMqWSOImn['saveinfo']['infoLabels']['title']=ECULefxDBQvAXNgpTlaPKdMqWSOImc
  if vidtype=='movie':
   ECULefxDBQvAXNgpTlaPKdMqWSOImc='%s  (%s)'%(ECULefxDBQvAXNgpTlaPKdMqWSOImc,ECULefxDBQvAXNgpTlaPKdMqWSOImu)
  ECULefxDBQvAXNgpTlaPKdMqWSOImn['saveinfo']['title'] =ECULefxDBQvAXNgpTlaPKdMqWSOImc
  ECULefxDBQvAXNgpTlaPKdMqWSOImn['saveinfo']['infoLabels']['mpaa'] =ECULefxDBQvAXNgpTlaPKdMqWSOImj.get('age_rating')
  ECULefxDBQvAXNgpTlaPKdMqWSOImn['saveinfo']['infoLabels']['plot'] ='%s\n\n%s'%(ECULefxDBQvAXNgpTlaPKdMqWSOImj.get('short_description'),ECULefxDBQvAXNgpTlaPKdMqWSOImj.get('description'))
  ECULefxDBQvAXNgpTlaPKdMqWSOImn['saveinfo']['infoLabels']['year'] =ECULefxDBQvAXNgpTlaPKdMqWSOImu
  if vidtype=='movie':
   ECULefxDBQvAXNgpTlaPKdMqWSOImn['saveinfo']['infoLabels']['duration']=ECULefxDBQvAXNgpTlaPKdMqWSOImj.get('running_time')
  ECULefxDBQvAXNgpTlaPKdMqWSOIGu =''
  ECULefxDBQvAXNgpTlaPKdMqWSOImt =''
  ECULefxDBQvAXNgpTlaPKdMqWSOIGV =''
  ECULefxDBQvAXNgpTlaPKdMqWSOImh=''
  if ECULefxDBQvAXNgpTlaPKdMqWSOImj.get('images').get('poster') !=ECULefxDBQvAXNgpTlaPKdMqWSOIRs:ECULefxDBQvAXNgpTlaPKdMqWSOIGu =ECULefxDBQvAXNgpTlaPKdMqWSOImj.get('images').get('poster').get('url') +'?imwidth=350'
  if ECULefxDBQvAXNgpTlaPKdMqWSOImj.get('images').get('background') !=ECULefxDBQvAXNgpTlaPKdMqWSOIRs:ECULefxDBQvAXNgpTlaPKdMqWSOImt =ECULefxDBQvAXNgpTlaPKdMqWSOImj.get('images').get('background').get('url') +'?imwidth=600'
  if ECULefxDBQvAXNgpTlaPKdMqWSOImj.get('images').get('story-art') !=ECULefxDBQvAXNgpTlaPKdMqWSOIRs:ECULefxDBQvAXNgpTlaPKdMqWSOIGV =ECULefxDBQvAXNgpTlaPKdMqWSOImj.get('images').get('story-art').get('url') +'?imwidth=600'
  if ECULefxDBQvAXNgpTlaPKdMqWSOImj.get('images').get('title-treatment')!=ECULefxDBQvAXNgpTlaPKdMqWSOIRs:ECULefxDBQvAXNgpTlaPKdMqWSOImh=ECULefxDBQvAXNgpTlaPKdMqWSOImj.get('images').get('title-treatment').get('url')+'?imwidth=300'
  if ECULefxDBQvAXNgpTlaPKdMqWSOImt=='':ECULefxDBQvAXNgpTlaPKdMqWSOImt=ECULefxDBQvAXNgpTlaPKdMqWSOIGV
  ECULefxDBQvAXNgpTlaPKdMqWSOImn['saveinfo']['thumbnail']['poster']=ECULefxDBQvAXNgpTlaPKdMqWSOIGu
  ECULefxDBQvAXNgpTlaPKdMqWSOImn['saveinfo']['thumbnail']['fanart']=ECULefxDBQvAXNgpTlaPKdMqWSOImt
  ECULefxDBQvAXNgpTlaPKdMqWSOImn['saveinfo']['thumbnail']['thumb']=ECULefxDBQvAXNgpTlaPKdMqWSOIGV
  ECULefxDBQvAXNgpTlaPKdMqWSOImn['saveinfo']['thumbnail']['clearlogo']=ECULefxDBQvAXNgpTlaPKdMqWSOImh
  ECULefxDBQvAXNgpTlaPKdMqWSOImJ=[]
  for ECULefxDBQvAXNgpTlaPKdMqWSOIGy in ECULefxDBQvAXNgpTlaPKdMqWSOImj.get('tags'):ECULefxDBQvAXNgpTlaPKdMqWSOImJ.append(ECULefxDBQvAXNgpTlaPKdMqWSOIGy.get('tag'))
  if ECULefxDBQvAXNgpTlaPKdMqWSOIbF(ECULefxDBQvAXNgpTlaPKdMqWSOImJ)>0:
   ECULefxDBQvAXNgpTlaPKdMqWSOImn['saveinfo']['infoLabels']['genre']=ECULefxDBQvAXNgpTlaPKdMqWSOImJ
  ECULefxDBQvAXNgpTlaPKdMqWSOImy=[]
  ECULefxDBQvAXNgpTlaPKdMqWSOImV=[]
  for ECULefxDBQvAXNgpTlaPKdMqWSOIGy in ECULefxDBQvAXNgpTlaPKdMqWSOImj.get('people'):
   if ECULefxDBQvAXNgpTlaPKdMqWSOIGy.get('role')=='CAST' :ECULefxDBQvAXNgpTlaPKdMqWSOImy.append(ECULefxDBQvAXNgpTlaPKdMqWSOIGy.get('name'))
   if ECULefxDBQvAXNgpTlaPKdMqWSOIGy.get('role')=='DIRECTOR':ECULefxDBQvAXNgpTlaPKdMqWSOImV.append(ECULefxDBQvAXNgpTlaPKdMqWSOIGy.get('name'))
  if ECULefxDBQvAXNgpTlaPKdMqWSOIbF(ECULefxDBQvAXNgpTlaPKdMqWSOImy)>0:
   ECULefxDBQvAXNgpTlaPKdMqWSOImn['saveinfo']['infoLabels']['cast'] =ECULefxDBQvAXNgpTlaPKdMqWSOImy
  if ECULefxDBQvAXNgpTlaPKdMqWSOIbF(ECULefxDBQvAXNgpTlaPKdMqWSOImV)>0:
   ECULefxDBQvAXNgpTlaPKdMqWSOImn['saveinfo']['infoLabels']['director']=ECULefxDBQvAXNgpTlaPKdMqWSOImV
  return ECULefxDBQvAXNgpTlaPKdMqWSOImn
 def MakeText_FreeList(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,search_list,titleName='title'):
  ECULefxDBQvAXNgpTlaPKdMqWSOImr=''
  ECULefxDBQvAXNgpTlaPKdMqWSOIms=5
  try:
   for i in ECULefxDBQvAXNgpTlaPKdMqWSOIbR(ECULefxDBQvAXNgpTlaPKdMqWSOIbF(search_list)):
    if i>=ECULefxDBQvAXNgpTlaPKdMqWSOIms:
     ECULefxDBQvAXNgpTlaPKdMqWSOImr=ECULefxDBQvAXNgpTlaPKdMqWSOImr+'...'
     break
    ECULefxDBQvAXNgpTlaPKdMqWSOImr=ECULefxDBQvAXNgpTlaPKdMqWSOImr+search_list[i][titleName]+'\n'
  except:
   return ''
  return ECULefxDBQvAXNgpTlaPKdMqWSOImr
 def Sports_Mainlist_League(ECULefxDBQvAXNgpTlaPKdMqWSOIwm):
  ECULefxDBQvAXNgpTlaPKdMqWSOImi=[] 
  try:
   ECULefxDBQvAXNgpTlaPKdMqWSOIFu='{}/api-discover/v1/sports/leagues/pills'.format(ECULefxDBQvAXNgpTlaPKdMqWSOIwm.API_DOMAIN)
   ECULefxDBQvAXNgpTlaPKdMqWSOIGF={'platform':'WEBCLIENT','useCircularLogo':'true',}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFh=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.callRequestCookies('Get',ECULefxDBQvAXNgpTlaPKdMqWSOIFu,payload=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,params=ECULefxDBQvAXNgpTlaPKdMqWSOIGF,headers=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,cookies=ECULefxDBQvAXNgpTlaPKdMqWSOIRs)
   if ECULefxDBQvAXNgpTlaPKdMqWSOIFh.status_code not in[200]:return[]
   ECULefxDBQvAXNgpTlaPKdMqWSOIFi=json.loads(ECULefxDBQvAXNgpTlaPKdMqWSOIFh.text)
   for ECULefxDBQvAXNgpTlaPKdMqWSOIGb in ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('data'):
    ECULefxDBQvAXNgpTlaPKdMqWSOIGn={'league_id':ECULefxDBQvAXNgpTlaPKdMqWSOIGb['id'],'league_name':ECULefxDBQvAXNgpTlaPKdMqWSOIGb['name'],'logoUrl':ECULefxDBQvAXNgpTlaPKdMqWSOIGb['logoUrl'],}
    ECULefxDBQvAXNgpTlaPKdMqWSOImi.append(ECULefxDBQvAXNgpTlaPKdMqWSOIGn)
  except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
   ECULefxDBQvAXNgpTlaPKdMqWSOIRk(exception)
   return[]
  return ECULefxDBQvAXNgpTlaPKdMqWSOImi
 def Sports_League_FeedList(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,leagueID):
  ECULefxDBQvAXNgpTlaPKdMqWSOImk=[] 
  try:
   ECULefxDBQvAXNgpTlaPKdMqWSOIFu='{}/api-discover/v1/discover/sports/leagues/{}/feed'.format(ECULefxDBQvAXNgpTlaPKdMqWSOIwm.API_DOMAIN,leagueID)
   ECULefxDBQvAXNgpTlaPKdMqWSOIGF={'platform':'WEBCLIENT','region':'KR','locale':'ko','includeSportsChannelContents':'true',}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFh=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.callRequestCookies('Get',ECULefxDBQvAXNgpTlaPKdMqWSOIFu,payload=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,params=ECULefxDBQvAXNgpTlaPKdMqWSOIGF,headers=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,cookies=ECULefxDBQvAXNgpTlaPKdMqWSOIRs)
   if ECULefxDBQvAXNgpTlaPKdMqWSOIFh.status_code not in[200]:return[]
   ECULefxDBQvAXNgpTlaPKdMqWSOIFi=json.loads(ECULefxDBQvAXNgpTlaPKdMqWSOIFh.text).get('data')
   for ECULefxDBQvAXNgpTlaPKdMqWSOIGb in ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('data'):
    if ECULefxDBQvAXNgpTlaPKdMqWSOIGb['type']=='Calendar':
     ECULefxDBQvAXNgpTlaPKdMqWSOImz =ECULefxDBQvAXNgpTlaPKdMqWSOIwm.Sports_leagueHome_Livelist(leagueID)
     if ECULefxDBQvAXNgpTlaPKdMqWSOImz:
      ECULefxDBQvAXNgpTlaPKdMqWSOImY =ECULefxDBQvAXNgpTlaPKdMqWSOIwm.MakeText_FreeList(ECULefxDBQvAXNgpTlaPKdMqWSOImz,titleName='preTitle')
      ECULefxDBQvAXNgpTlaPKdMqWSOIGn={'row_name':'@ 예정 경기 @','preText':ECULefxDBQvAXNgpTlaPKdMqWSOImY,'subMode':'SP_FEED_LIVE','image':ECULefxDBQvAXNgpTlaPKdMqWSOImz[0]['image'],}
      ECULefxDBQvAXNgpTlaPKdMqWSOImk.append(ECULefxDBQvAXNgpTlaPKdMqWSOIGn)
    elif ECULefxDBQvAXNgpTlaPKdMqWSOIGb['type']=='Live-Events-Curation':
     ECULefxDBQvAXNgpTlaPKdMqWSOImz =ECULefxDBQvAXNgpTlaPKdMqWSOIwm.Sports_LeagueHome_List(data=ECULefxDBQvAXNgpTlaPKdMqWSOIGb,sType='top10')
     if ECULefxDBQvAXNgpTlaPKdMqWSOImz:
      ECULefxDBQvAXNgpTlaPKdMqWSOImY =ECULefxDBQvAXNgpTlaPKdMqWSOIwm.MakeText_FreeList(ECULefxDBQvAXNgpTlaPKdMqWSOImz,titleName='title')
      ECULefxDBQvAXNgpTlaPKdMqWSOIGn={'row_name':ECULefxDBQvAXNgpTlaPKdMqWSOIGb['row_name'],'preText':ECULefxDBQvAXNgpTlaPKdMqWSOImY,'subMode':'SP_FEED_TOP10','image':ECULefxDBQvAXNgpTlaPKdMqWSOImz[0]['image'],}
      ECULefxDBQvAXNgpTlaPKdMqWSOImk.append(ECULefxDBQvAXNgpTlaPKdMqWSOIGn)
    elif ECULefxDBQvAXNgpTlaPKdMqWSOIGb['type']=='Live-Sports-Matches':
     ECULefxDBQvAXNgpTlaPKdMqWSOImz =ECULefxDBQvAXNgpTlaPKdMqWSOIwm.Sports_LeagueHome_List(data=ECULefxDBQvAXNgpTlaPKdMqWSOIGb,sType='gameVod')
     for ECULefxDBQvAXNgpTlaPKdMqWSOImo in ECULefxDBQvAXNgpTlaPKdMqWSOImz:
      ECULefxDBQvAXNgpTlaPKdMqWSOIGn={'row_name':'{} <{}>'.format(ECULefxDBQvAXNgpTlaPKdMqWSOImo['title'],ECULefxDBQvAXNgpTlaPKdMqWSOImo['startDate']),'preText':ECULefxDBQvAXNgpTlaPKdMqWSOImo['preText'],'subMode':'SP_FEED_GAME','gameID':ECULefxDBQvAXNgpTlaPKdMqWSOImo['id'],'image':ECULefxDBQvAXNgpTlaPKdMqWSOImo['image'],}
      ECULefxDBQvAXNgpTlaPKdMqWSOImk.append(ECULefxDBQvAXNgpTlaPKdMqWSOIGn)
  except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
   ECULefxDBQvAXNgpTlaPKdMqWSOIRk(exception)
   return[]
  return ECULefxDBQvAXNgpTlaPKdMqWSOImk
 def Sports_League_VodList(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,subMode,leagueID,gameID):
  ECULefxDBQvAXNgpTlaPKdMqWSOIRw=[] 
  try:
   if subMode=='SP_FEED_LIVE':
    ECULefxDBQvAXNgpTlaPKdMqWSOImz =ECULefxDBQvAXNgpTlaPKdMqWSOIwm.Sports_leagueHome_Livelist(leagueID)
    for ECULefxDBQvAXNgpTlaPKdMqWSOImo in ECULefxDBQvAXNgpTlaPKdMqWSOImz:
     ECULefxDBQvAXNgpTlaPKdMqWSOIGn={'id':ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('event_id'),'title':ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('title'),'image':ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('image'),'startDate':ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('startDate'),'subType':ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('subType'),}
     ECULefxDBQvAXNgpTlaPKdMqWSOIRw.append(ECULefxDBQvAXNgpTlaPKdMqWSOIGn)
   elif subMode in['SP_FEED_TOP10','SP_FEED_GAME']:
    ECULefxDBQvAXNgpTlaPKdMqWSOIFu='{}/api-discover/v1/discover/sports/leagues/{}/feed'.format(ECULefxDBQvAXNgpTlaPKdMqWSOIwm.API_DOMAIN,leagueID)
    ECULefxDBQvAXNgpTlaPKdMqWSOIGF={'platform':'WEBCLIENT','region':'KR','locale':'ko','includeSportsChannelContents':'true',}
    ECULefxDBQvAXNgpTlaPKdMqWSOIFh=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.callRequestCookies('Get',ECULefxDBQvAXNgpTlaPKdMqWSOIFu,payload=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,params=ECULefxDBQvAXNgpTlaPKdMqWSOIGF,headers=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,cookies=ECULefxDBQvAXNgpTlaPKdMqWSOIRs)
    if ECULefxDBQvAXNgpTlaPKdMqWSOIFh.status_code not in[200]:return[]
    ECULefxDBQvAXNgpTlaPKdMqWSOIFi=json.loads(ECULefxDBQvAXNgpTlaPKdMqWSOIFh.text).get('data')
    for ECULefxDBQvAXNgpTlaPKdMqWSOIGb in ECULefxDBQvAXNgpTlaPKdMqWSOIFi.get('data'):
     if ECULefxDBQvAXNgpTlaPKdMqWSOIGb['type']=='Live-Events-Curation' and subMode=='SP_FEED_TOP10':
      ECULefxDBQvAXNgpTlaPKdMqWSOImz =ECULefxDBQvAXNgpTlaPKdMqWSOIwm.Sports_LeagueHome_List(data=ECULefxDBQvAXNgpTlaPKdMqWSOIGb,sType='top10')
      for ECULefxDBQvAXNgpTlaPKdMqWSOImo in ECULefxDBQvAXNgpTlaPKdMqWSOImz:
       ECULefxDBQvAXNgpTlaPKdMqWSOIGn={'id':ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('id'),'title':ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('title'),'image':ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('image'),'startDate':ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('startDate'),'subType':ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('subType'),'running_time':ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('running_time'),}
       ECULefxDBQvAXNgpTlaPKdMqWSOIRw.append(ECULefxDBQvAXNgpTlaPKdMqWSOIGn)
     elif ECULefxDBQvAXNgpTlaPKdMqWSOIGb['type']=='Live-Sports-Matches' and subMode=='SP_FEED_GAME':
      for ECULefxDBQvAXNgpTlaPKdMqWSOIRF in ECULefxDBQvAXNgpTlaPKdMqWSOIGb['data']:
       if gameID==ECULefxDBQvAXNgpTlaPKdMqWSOIRF['id']:
        ECULefxDBQvAXNgpTlaPKdMqWSOImz =ECULefxDBQvAXNgpTlaPKdMqWSOIwm.Sports_LeagueHome_SubVods(data=ECULefxDBQvAXNgpTlaPKdMqWSOIRF)
        for ECULefxDBQvAXNgpTlaPKdMqWSOImo in ECULefxDBQvAXNgpTlaPKdMqWSOImz:
         ECULefxDBQvAXNgpTlaPKdMqWSOIGn={'id':ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('id'),'title':ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('title'),'image':ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('image'),'subType':ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('subType'),'running_time':ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('running_time'),}
         ECULefxDBQvAXNgpTlaPKdMqWSOIRw.append(ECULefxDBQvAXNgpTlaPKdMqWSOIGn)
        break
  except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
   ECULefxDBQvAXNgpTlaPKdMqWSOIRk(exception)
   return[]
  return ECULefxDBQvAXNgpTlaPKdMqWSOIRw
 def Sports_LeagueHome_List(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,data,sType=''):
  ECULefxDBQvAXNgpTlaPKdMqWSOIRG=[]
  try:
   if sType=='top10':
    for ECULefxDBQvAXNgpTlaPKdMqWSOIGb in data.get('data'):
     ECULefxDBQvAXNgpTlaPKdMqWSOIRm=''
     if 'channels' in ECULefxDBQvAXNgpTlaPKdMqWSOIGb:
      ECULefxDBQvAXNgpTlaPKdMqWSOIRm='패스'
     ECULefxDBQvAXNgpTlaPKdMqWSOIGn={'id':ECULefxDBQvAXNgpTlaPKdMqWSOIGb['id'],'title':ECULefxDBQvAXNgpTlaPKdMqWSOIGb['title'],'subType':ECULefxDBQvAXNgpTlaPKdMqWSOIRm,'image':ECULefxDBQvAXNgpTlaPKdMqWSOIGb['images']['story_art_url'],'running_time':ECULefxDBQvAXNgpTlaPKdMqWSOIGb['running_time'],'startDate':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.convert_DateStr(ECULefxDBQvAXNgpTlaPKdMqWSOIGb['startAt']),}
     ECULefxDBQvAXNgpTlaPKdMqWSOIRG.append(ECULefxDBQvAXNgpTlaPKdMqWSOIGn)
   elif sType=='gameVod':
    for ECULefxDBQvAXNgpTlaPKdMqWSOIGb in data.get('data'):
     if ECULefxDBQvAXNgpTlaPKdMqWSOIbF(ECULefxDBQvAXNgpTlaPKdMqWSOIGb['participants'])>=2:
      ECULefxDBQvAXNgpTlaPKdMqWSOIRb=ECULefxDBQvAXNgpTlaPKdMqWSOIGb['participants'][0]['name']
      ECULefxDBQvAXNgpTlaPKdMqWSOIRH=ECULefxDBQvAXNgpTlaPKdMqWSOIGb['participants'][1]['name']
      ECULefxDBQvAXNgpTlaPKdMqWSOIRb=ECULefxDBQvAXNgpTlaPKdMqWSOIRb+' vs '+ECULefxDBQvAXNgpTlaPKdMqWSOIRH
     else:
      ECULefxDBQvAXNgpTlaPKdMqWSOIRb=ECULefxDBQvAXNgpTlaPKdMqWSOIGb['participants'][0]['name']
     ECULefxDBQvAXNgpTlaPKdMqWSOImz=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.Sports_LeagueHome_SubVods(ECULefxDBQvAXNgpTlaPKdMqWSOIGb)
     ECULefxDBQvAXNgpTlaPKdMqWSOImY =ECULefxDBQvAXNgpTlaPKdMqWSOIwm.MakeText_FreeList(ECULefxDBQvAXNgpTlaPKdMqWSOImz,titleName='title')
     ECULefxDBQvAXNgpTlaPKdMqWSOIGn={'id':ECULefxDBQvAXNgpTlaPKdMqWSOIGb['id'],'title':ECULefxDBQvAXNgpTlaPKdMqWSOIRb,'startDate':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.convert_DateStr(ECULefxDBQvAXNgpTlaPKdMqWSOIGb['startsAt']),'preText':ECULefxDBQvAXNgpTlaPKdMqWSOImY,'image':ECULefxDBQvAXNgpTlaPKdMqWSOImz[0]['image']}
     ECULefxDBQvAXNgpTlaPKdMqWSOIRG.append(ECULefxDBQvAXNgpTlaPKdMqWSOIGn)
  except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
   ECULefxDBQvAXNgpTlaPKdMqWSOIRk(exception)
   return[]
  return ECULefxDBQvAXNgpTlaPKdMqWSOIRG
 def Sports_LeagueHome_SubVods(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,data):
  ECULefxDBQvAXNgpTlaPKdMqWSOImz=[]
  try:
   for ECULefxDBQvAXNgpTlaPKdMqWSOIGb in data.get('highlights'):
    ECULefxDBQvAXNgpTlaPKdMqWSOIRm=''
    if 'channels' in ECULefxDBQvAXNgpTlaPKdMqWSOIGb:
     ECULefxDBQvAXNgpTlaPKdMqWSOIRm='패스'
    ECULefxDBQvAXNgpTlaPKdMqWSOIGn={'id':ECULefxDBQvAXNgpTlaPKdMqWSOIGb['id'],'title':ECULefxDBQvAXNgpTlaPKdMqWSOIGb['title'],'image':ECULefxDBQvAXNgpTlaPKdMqWSOIGb['images']['story-art']['url'],'subType':ECULefxDBQvAXNgpTlaPKdMqWSOIRm,'running_time':ECULefxDBQvAXNgpTlaPKdMqWSOIGb['running_time'],}
    ECULefxDBQvAXNgpTlaPKdMqWSOImz.append(ECULefxDBQvAXNgpTlaPKdMqWSOIGn)
  except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
   ECULefxDBQvAXNgpTlaPKdMqWSOIRk(exception)
   return[]
  return ECULefxDBQvAXNgpTlaPKdMqWSOImz
 def Sports_leagueHome_Livelist(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,leagueID):
  ECULefxDBQvAXNgpTlaPKdMqWSOImz=[]
  try:
   ECULefxDBQvAXNgpTlaPKdMqWSOIFu='{}/api-discover/v1/sports/curated-schedule/events'.format(ECULefxDBQvAXNgpTlaPKdMqWSOIwm.API_DOMAIN)
   ECULefxDBQvAXNgpTlaPKdMqWSOIGF={'league_id':leagueID,'region':'KR','locale':'ko','scope':'live-upcoming','includeHighlights':'false','includeSportsChannelContents':'true',}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFG={'x-membersrl':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['COOKIES']['member_srl'],'x-pcid':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['COOKIES']['PCID'],'x-profileid':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT',}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFh=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.callRequestCookies('Get',ECULefxDBQvAXNgpTlaPKdMqWSOIFu,payload=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,params=ECULefxDBQvAXNgpTlaPKdMqWSOIGF,headers=ECULefxDBQvAXNgpTlaPKdMqWSOIFG,cookies=ECULefxDBQvAXNgpTlaPKdMqWSOIRs)
   if ECULefxDBQvAXNgpTlaPKdMqWSOIFh.status_code not in[200]:return[]
   ECULefxDBQvAXNgpTlaPKdMqWSOIFi=json.loads(ECULefxDBQvAXNgpTlaPKdMqWSOIFh.text).get('data')
   for ECULefxDBQvAXNgpTlaPKdMqWSOImo in ECULefxDBQvAXNgpTlaPKdMqWSOIFi:
    if ECULefxDBQvAXNgpTlaPKdMqWSOIbF(ECULefxDBQvAXNgpTlaPKdMqWSOImo['teams'])>=2:
     ECULefxDBQvAXNgpTlaPKdMqWSOIRb=ECULefxDBQvAXNgpTlaPKdMqWSOImo['teams'][0]['name']
     ECULefxDBQvAXNgpTlaPKdMqWSOIRH=ECULefxDBQvAXNgpTlaPKdMqWSOImo['teams'][1]['name']
     ECULefxDBQvAXNgpTlaPKdMqWSOIRb=ECULefxDBQvAXNgpTlaPKdMqWSOIRb+' vs '+ECULefxDBQvAXNgpTlaPKdMqWSOIRH
    else:
     ECULefxDBQvAXNgpTlaPKdMqWSOIRb=ECULefxDBQvAXNgpTlaPKdMqWSOImo['teams'][0]['name']
    ECULefxDBQvAXNgpTlaPKdMqWSOIRn=''
    if ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('images'):
     ECULefxDBQvAXNgpTlaPKdMqWSOIRn=ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('images').get('story_art_url')
    ECULefxDBQvAXNgpTlaPKdMqWSOIRj=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.convert_TimeStr(ECULefxDBQvAXNgpTlaPKdMqWSOImo['start_at'])
    ECULefxDBQvAXNgpTlaPKdMqWSOIRm=''
    if 'channels' in ECULefxDBQvAXNgpTlaPKdMqWSOImo:
     ECULefxDBQvAXNgpTlaPKdMqWSOIRm='패스'
    ECULefxDBQvAXNgpTlaPKdMqWSOIGn={'event_id':ECULefxDBQvAXNgpTlaPKdMqWSOImo['event_id'],'title':ECULefxDBQvAXNgpTlaPKdMqWSOIRb,'startDate':ECULefxDBQvAXNgpTlaPKdMqWSOIRj,'image':ECULefxDBQvAXNgpTlaPKdMqWSOIRn,'preTitle':'{} <{}>'.format(ECULefxDBQvAXNgpTlaPKdMqWSOIRb,ECULefxDBQvAXNgpTlaPKdMqWSOIRj),'subType':ECULefxDBQvAXNgpTlaPKdMqWSOIRm,}
    ECULefxDBQvAXNgpTlaPKdMqWSOImz.append(ECULefxDBQvAXNgpTlaPKdMqWSOIGn)
  except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
   ECULefxDBQvAXNgpTlaPKdMqWSOIRk(exception)
   return[]
  return ECULefxDBQvAXNgpTlaPKdMqWSOImz
 def Sports_MultiHero_LiveList(ECULefxDBQvAXNgpTlaPKdMqWSOIwm):
  ECULefxDBQvAXNgpTlaPKdMqWSOIRc=[]
  try:
   ECULefxDBQvAXNgpTlaPKdMqWSOIFu='{}/api-discover/v1/sports/feed'.format(ECULefxDBQvAXNgpTlaPKdMqWSOIwm.API_DOMAIN)
   ECULefxDBQvAXNgpTlaPKdMqWSOIGF={'platform':'WEBCLIENT','region':'KR','locale':'ko','filterRestrictedContent':'false','preferRecoFeed':'true','preferMultiHeroMixedContentRow':'true','category':'LIVE','perPage':'7','allowOtherRailsAboveHero':'true','includeSportsChannelContents':'true','page':'1',}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFh=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.callRequestCookies('Get',ECULefxDBQvAXNgpTlaPKdMqWSOIFu,payload=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,params=ECULefxDBQvAXNgpTlaPKdMqWSOIGF,headers=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,cookies=ECULefxDBQvAXNgpTlaPKdMqWSOIRs)
   if ECULefxDBQvAXNgpTlaPKdMqWSOIFh.status_code not in[200]:return[]
   ECULefxDBQvAXNgpTlaPKdMqWSOIFi=json.loads(ECULefxDBQvAXNgpTlaPKdMqWSOIFh.text).get('data')
   for ECULefxDBQvAXNgpTlaPKdMqWSOIGb in ECULefxDBQvAXNgpTlaPKdMqWSOIFi:
    if ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('type')=='Multi-Hero-Live-Event-Curation':
     for ECULefxDBQvAXNgpTlaPKdMqWSOImo in ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('data'):
      ECULefxDBQvAXNgpTlaPKdMqWSOIRj=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.convert_TimeStr(ECULefxDBQvAXNgpTlaPKdMqWSOImo['startAt'])
      '''
      try:
       startDate = self.convert_TimeStr(i_vod['startAt'] )
      except Exception as exception:
       aa = 'exception = {}'.format(exception )
       bb = {'aa' : aa }
       self.dic_To_jsonfile('d:\\Naver MYBOX\\sync\\job\\cp_cookies1.json', bb )
      '''      
      ECULefxDBQvAXNgpTlaPKdMqWSOIRn=''
      if ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('images'):
       if ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('images').get('hero_url'):
        ECULefxDBQvAXNgpTlaPKdMqWSOIRn=ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('images').get('hero_url')
       elif ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('images').get('sports_hero_mobile_url'):
        ECULefxDBQvAXNgpTlaPKdMqWSOIRn=ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('images').get('sports_hero_mobile_url')
      ECULefxDBQvAXNgpTlaPKdMqWSOIRm=''
      if 'channels' in ECULefxDBQvAXNgpTlaPKdMqWSOImo:
       ECULefxDBQvAXNgpTlaPKdMqWSOIRm='패스'
      ECULefxDBQvAXNgpTlaPKdMqWSOIGn={'id':ECULefxDBQvAXNgpTlaPKdMqWSOImo['id'],'title':ECULefxDBQvAXNgpTlaPKdMqWSOImo['title'],'startDate':ECULefxDBQvAXNgpTlaPKdMqWSOIRj,'image':ECULefxDBQvAXNgpTlaPKdMqWSOIRn,'preTitle':'{} <{}>'.format(ECULefxDBQvAXNgpTlaPKdMqWSOImo['title'],ECULefxDBQvAXNgpTlaPKdMqWSOIRj),'subType':ECULefxDBQvAXNgpTlaPKdMqWSOIRm,}
      ECULefxDBQvAXNgpTlaPKdMqWSOIRc.append(ECULefxDBQvAXNgpTlaPKdMqWSOIGn)
     break
  except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
   ECULefxDBQvAXNgpTlaPKdMqWSOIRk(exception)
   return[]
  return ECULefxDBQvAXNgpTlaPKdMqWSOIRc
 def Sports_Season_Group(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,leagueID):
  ECULefxDBQvAXNgpTlaPKdMqWSOIRu=[]
  try:
   ECULefxDBQvAXNgpTlaPKdMqWSOIFu='{}/api-discover/v1/discover/sports/leagues/{}/filters'.format(ECULefxDBQvAXNgpTlaPKdMqWSOIwm.API_DOMAIN,leagueID)
   ECULefxDBQvAXNgpTlaPKdMqWSOIGF={'platform':'WEBCLIENT','locale':'ko','includeSportsChannelContents':'true',}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFG={'x-membersrl':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['COOKIES']['member_srl'],'x-pcid':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['COOKIES']['PCID'],'x-profileid':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT',}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFh=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.callRequestCookies('Get',ECULefxDBQvAXNgpTlaPKdMqWSOIFu,payload=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,params=ECULefxDBQvAXNgpTlaPKdMqWSOIGF,headers=ECULefxDBQvAXNgpTlaPKdMqWSOIFG,cookies=ECULefxDBQvAXNgpTlaPKdMqWSOIRs)
   if ECULefxDBQvAXNgpTlaPKdMqWSOIFh.status_code not in[200]:return[]
   ECULefxDBQvAXNgpTlaPKdMqWSOIFi=json.loads(ECULefxDBQvAXNgpTlaPKdMqWSOIFh.text).get('data')
   for ECULefxDBQvAXNgpTlaPKdMqWSOIGb in ECULefxDBQvAXNgpTlaPKdMqWSOIFi:
    ECULefxDBQvAXNgpTlaPKdMqWSOIRt=[]
    for ECULefxDBQvAXNgpTlaPKdMqWSOIRh in ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('stages'):
     ECULefxDBQvAXNgpTlaPKdMqWSOIRJ={'title':ECULefxDBQvAXNgpTlaPKdMqWSOIRh['name'],}
     ECULefxDBQvAXNgpTlaPKdMqWSOIRt.append(ECULefxDBQvAXNgpTlaPKdMqWSOIRJ)
    ECULefxDBQvAXNgpTlaPKdMqWSOImY=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.MakeText_FreeList(ECULefxDBQvAXNgpTlaPKdMqWSOIRt,titleName='title')
    ECULefxDBQvAXNgpTlaPKdMqWSOIGn={'season':ECULefxDBQvAXNgpTlaPKdMqWSOIGb['season'],'preText':ECULefxDBQvAXNgpTlaPKdMqWSOImY,}
    ECULefxDBQvAXNgpTlaPKdMqWSOIRu.append(ECULefxDBQvAXNgpTlaPKdMqWSOIGn)
  except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
   ECULefxDBQvAXNgpTlaPKdMqWSOIRk(exception)
   return[]
  return ECULefxDBQvAXNgpTlaPKdMqWSOIRu
 def Sports_Season_GameList(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,leagueID,seasonID,page=1):
  ECULefxDBQvAXNgpTlaPKdMqWSOIRG=[]
  try:
   ECULefxDBQvAXNgpTlaPKdMqWSOIFu='{}/api-discover/v2/sports/leagues/{}/schedule/previous'.format(ECULefxDBQvAXNgpTlaPKdMqWSOIwm.API_DOMAIN,leagueID)
   ECULefxDBQvAXNgpTlaPKdMqWSOIGF={'seasons':seasonID,'stageIds':'','teamIds':'','platform':'WEBCLIENT','locale':'ko','region':'KR','perPage':'10','includeSportsChannelContents':'true','page':ECULefxDBQvAXNgpTlaPKdMqWSOIRz(page),}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFG={'x-membersrl':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['COOKIES']['member_srl'],'x-pcid':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['COOKIES']['PCID'],'x-profileid':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT',}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFh=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.callRequestCookies('Get',ECULefxDBQvAXNgpTlaPKdMqWSOIFu,payload=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,params=ECULefxDBQvAXNgpTlaPKdMqWSOIGF,headers=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,cookies=ECULefxDBQvAXNgpTlaPKdMqWSOIRs)
   if ECULefxDBQvAXNgpTlaPKdMqWSOIFh.status_code not in[200]:return[]
   ECULefxDBQvAXNgpTlaPKdMqWSOIFi=json.loads(ECULefxDBQvAXNgpTlaPKdMqWSOIFh.text).get('data')
   for ECULefxDBQvAXNgpTlaPKdMqWSOIGb in ECULefxDBQvAXNgpTlaPKdMqWSOIFi:
    if ECULefxDBQvAXNgpTlaPKdMqWSOIbF(ECULefxDBQvAXNgpTlaPKdMqWSOIGb['participants'])>=2:
     ECULefxDBQvAXNgpTlaPKdMqWSOIRb=ECULefxDBQvAXNgpTlaPKdMqWSOIGb['participants'][0]['name']
     ECULefxDBQvAXNgpTlaPKdMqWSOIRH=ECULefxDBQvAXNgpTlaPKdMqWSOIGb['participants'][1]['name']
     ECULefxDBQvAXNgpTlaPKdMqWSOIRb=ECULefxDBQvAXNgpTlaPKdMqWSOIRb+' vs '+ECULefxDBQvAXNgpTlaPKdMqWSOIRH
    else:
     ECULefxDBQvAXNgpTlaPKdMqWSOIRb=ECULefxDBQvAXNgpTlaPKdMqWSOIGb['participants'][0]['name']
    ECULefxDBQvAXNgpTlaPKdMqWSOImz=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.Sports_LeagueHome_SubVods(ECULefxDBQvAXNgpTlaPKdMqWSOIGb)
    ECULefxDBQvAXNgpTlaPKdMqWSOImY =ECULefxDBQvAXNgpTlaPKdMqWSOIwm.MakeText_FreeList(ECULefxDBQvAXNgpTlaPKdMqWSOImz,titleName='title')
    ECULefxDBQvAXNgpTlaPKdMqWSOIGn={'id':ECULefxDBQvAXNgpTlaPKdMqWSOIGb['id'],'title':ECULefxDBQvAXNgpTlaPKdMqWSOIRb,'startDate':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.convert_DateStr(ECULefxDBQvAXNgpTlaPKdMqWSOIGb['startsAt']),'preText':ECULefxDBQvAXNgpTlaPKdMqWSOImY,'image':ECULefxDBQvAXNgpTlaPKdMqWSOImz[0]['image']}
    ECULefxDBQvAXNgpTlaPKdMqWSOIRG.append(ECULefxDBQvAXNgpTlaPKdMqWSOIGn)
  except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
   ECULefxDBQvAXNgpTlaPKdMqWSOIRk(exception)
   return[]
  return ECULefxDBQvAXNgpTlaPKdMqWSOIRG
 def Sports_Season_GameVod(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,leagueID,seasonID,page,gameID):
  ECULefxDBQvAXNgpTlaPKdMqWSOIRw=[]
  try:
   ECULefxDBQvAXNgpTlaPKdMqWSOIFu='{}/api-discover/v2/sports/leagues/{}/schedule/previous'.format(ECULefxDBQvAXNgpTlaPKdMqWSOIwm.API_DOMAIN,leagueID)
   ECULefxDBQvAXNgpTlaPKdMqWSOIGF={'seasons':seasonID,'stageIds':'','teamIds':'','platform':'WEBCLIENT','locale':'ko','region':'KR','perPage':'10','includeSportsChannelContents':'true','page':ECULefxDBQvAXNgpTlaPKdMqWSOIRz(page),}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFG={'x-membersrl':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['COOKIES']['member_srl'],'x-pcid':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['COOKIES']['PCID'],'x-profileid':ECULefxDBQvAXNgpTlaPKdMqWSOIwm.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT',}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFh=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.callRequestCookies('Get',ECULefxDBQvAXNgpTlaPKdMqWSOIFu,payload=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,params=ECULefxDBQvAXNgpTlaPKdMqWSOIGF,headers=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,cookies=ECULefxDBQvAXNgpTlaPKdMqWSOIRs)
   if ECULefxDBQvAXNgpTlaPKdMqWSOIFh.status_code not in[200]:return[]
   ECULefxDBQvAXNgpTlaPKdMqWSOIFi=json.loads(ECULefxDBQvAXNgpTlaPKdMqWSOIFh.text).get('data')
   for ECULefxDBQvAXNgpTlaPKdMqWSOIGb in ECULefxDBQvAXNgpTlaPKdMqWSOIFi:
    if gameID==ECULefxDBQvAXNgpTlaPKdMqWSOIGb['id']:
     ECULefxDBQvAXNgpTlaPKdMqWSOImz=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.Sports_LeagueHome_SubVods(ECULefxDBQvAXNgpTlaPKdMqWSOIGb)
     for ECULefxDBQvAXNgpTlaPKdMqWSOImo in ECULefxDBQvAXNgpTlaPKdMqWSOImz:
      ECULefxDBQvAXNgpTlaPKdMqWSOIGn={'id':ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('id'),'title':ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('title'),'image':ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('image'),'subType':ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('subType'),'running_time':ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('running_time'),}
      ECULefxDBQvAXNgpTlaPKdMqWSOIRw.append(ECULefxDBQvAXNgpTlaPKdMqWSOIGn)
  except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
   ECULefxDBQvAXNgpTlaPKdMqWSOIRk(exception)
   return[]
  return ECULefxDBQvAXNgpTlaPKdMqWSOIRw
 def Get_Pass_GroupList(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,ECULefxDBQvAXNgpTlaPKdMqWSOIGH):
  ECULefxDBQvAXNgpTlaPKdMqWSOIRy=[]
  try:
   ECULefxDBQvAXNgpTlaPKdMqWSOIFu='{}/api-discover/v2/discover/channels/{}/feed'.format(ECULefxDBQvAXNgpTlaPKdMqWSOIwm.API_DOMAIN,ECULefxDBQvAXNgpTlaPKdMqWSOIGH)
   ECULefxDBQvAXNgpTlaPKdMqWSOIGF={'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':ECULefxDBQvAXNgpTlaPKdMqWSOIRz(ECULefxDBQvAXNgpTlaPKdMqWSOIwm.PAGE_LIMIT),'filterRestrictedContent':'false','preferRecoFeed':'true','preferMultiHeroMixedContentRow':'true','shouldIncludeTVOD':'true','category':'ALL',}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFh=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.callRequestCookies('Get',ECULefxDBQvAXNgpTlaPKdMqWSOIFu,payload=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,params=ECULefxDBQvAXNgpTlaPKdMqWSOIGF,headers=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,cookies=ECULefxDBQvAXNgpTlaPKdMqWSOIRs)
   if ECULefxDBQvAXNgpTlaPKdMqWSOIFh.status_code not in[200]:return[]
   ECULefxDBQvAXNgpTlaPKdMqWSOIFi=json.loads(ECULefxDBQvAXNgpTlaPKdMqWSOIFh.text).get('data')
   for ECULefxDBQvAXNgpTlaPKdMqWSOIGb in ECULefxDBQvAXNgpTlaPKdMqWSOIFi:
    if ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('row_name')and ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('obj_id'):
     ECULefxDBQvAXNgpTlaPKdMqWSOImY=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.MakeText_FreeList(ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('data'),titleName='title')
     ECULefxDBQvAXNgpTlaPKdMqWSOIGn={'obj_id':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('obj_id'),'title':ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('row_name'),'preText':ECULefxDBQvAXNgpTlaPKdMqWSOImY,}
     ECULefxDBQvAXNgpTlaPKdMqWSOIRy.append(ECULefxDBQvAXNgpTlaPKdMqWSOIGn)
  except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
   ECULefxDBQvAXNgpTlaPKdMqWSOIRk(exception)
   return[]
  return ECULefxDBQvAXNgpTlaPKdMqWSOIRy
 def Get_Pass_VodList(ECULefxDBQvAXNgpTlaPKdMqWSOIwm,ECULefxDBQvAXNgpTlaPKdMqWSOIGH,obj_id):
  ECULefxDBQvAXNgpTlaPKdMqWSOIRV=[]
  try:
   ECULefxDBQvAXNgpTlaPKdMqWSOIFu='{}/api-discover/v2/discover/channels/{}/feed'.format(ECULefxDBQvAXNgpTlaPKdMqWSOIwm.API_DOMAIN,ECULefxDBQvAXNgpTlaPKdMqWSOIGH)
   ECULefxDBQvAXNgpTlaPKdMqWSOIGF={'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':ECULefxDBQvAXNgpTlaPKdMqWSOIRz(ECULefxDBQvAXNgpTlaPKdMqWSOIwm.PAGE_LIMIT),'filterRestrictedContent':'false','preferRecoFeed':'true','preferMultiHeroMixedContentRow':'true','shouldIncludeTVOD':'true','category':'ALL',}
   ECULefxDBQvAXNgpTlaPKdMqWSOIFh=ECULefxDBQvAXNgpTlaPKdMqWSOIwm.callRequestCookies('Get',ECULefxDBQvAXNgpTlaPKdMqWSOIFu,payload=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,params=ECULefxDBQvAXNgpTlaPKdMqWSOIGF,headers=ECULefxDBQvAXNgpTlaPKdMqWSOIRs,cookies=ECULefxDBQvAXNgpTlaPKdMqWSOIRs)
   if ECULefxDBQvAXNgpTlaPKdMqWSOIFh.status_code not in[200]:return[]
   ECULefxDBQvAXNgpTlaPKdMqWSOIFi=json.loads(ECULefxDBQvAXNgpTlaPKdMqWSOIFh.text).get('data')
   for ECULefxDBQvAXNgpTlaPKdMqWSOIGb in ECULefxDBQvAXNgpTlaPKdMqWSOIFi:
    if ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('obj_id')==obj_id:
     for ECULefxDBQvAXNgpTlaPKdMqWSOImo in ECULefxDBQvAXNgpTlaPKdMqWSOIGb.get('data'):
      ECULefxDBQvAXNgpTlaPKdMqWSOIGu=ECULefxDBQvAXNgpTlaPKdMqWSOIGV=ECULefxDBQvAXNgpTlaPKdMqWSOImh=ECULefxDBQvAXNgpTlaPKdMqWSOImt=''
      if 'poster_url' in ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('images'):ECULefxDBQvAXNgpTlaPKdMqWSOIGu =ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('images').get('poster_url') +'?imwidth=350'
      if 'story_art_url' in ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('images'):ECULefxDBQvAXNgpTlaPKdMqWSOIGV =ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('images').get('story_art_url') +'?imwidth=600'
      if 'title_treatment_url' in ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('images'):ECULefxDBQvAXNgpTlaPKdMqWSOImh=ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('images').get('title_treatment_url')+'?imwidth=300'
      if 'story_art_url' in ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('images'):ECULefxDBQvAXNgpTlaPKdMqWSOImt =ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('images').get('story_art_url') +'?imwidth=600'
      ECULefxDBQvAXNgpTlaPKdMqWSOIGt=''
      if ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('badge')not in[{},ECULefxDBQvAXNgpTlaPKdMqWSOIRs]:
       for i in ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('badge').get('text'):
        ECULefxDBQvAXNgpTlaPKdMqWSOIGt+=i.get('text')
      ECULefxDBQvAXNgpTlaPKdMqWSOIGh=''
      if ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('seasonList')!=ECULefxDBQvAXNgpTlaPKdMqWSOIRs:
       ECULefxDBQvAXNgpTlaPKdMqWSOIGh=','.join(ECULefxDBQvAXNgpTlaPKdMqWSOIRz(e)for e in ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('seasonList'))
      ECULefxDBQvAXNgpTlaPKdMqWSOIGJ =[]
      for ECULefxDBQvAXNgpTlaPKdMqWSOIGy in ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('tags'):
       ECULefxDBQvAXNgpTlaPKdMqWSOIGJ.append(ECULefxDBQvAXNgpTlaPKdMqWSOIGy.get('tag'))
      ECULefxDBQvAXNgpTlaPKdMqWSOIGn={'id':ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('id'),'title':ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('title'),'thumbnail':{'poster':ECULefxDBQvAXNgpTlaPKdMqWSOIGu,'thumb':ECULefxDBQvAXNgpTlaPKdMqWSOIGV,'clearlogo':ECULefxDBQvAXNgpTlaPKdMqWSOImh,'fanart':ECULefxDBQvAXNgpTlaPKdMqWSOImt},'mpaa':ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('ageRating'),'duration':ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('running_time'),'sub_type':ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('sub_type'),'badge':ECULefxDBQvAXNgpTlaPKdMqWSOIGt,'year':ECULefxDBQvAXNgpTlaPKdMqWSOImo.get('releaseYear'),'seasonList':ECULefxDBQvAXNgpTlaPKdMqWSOIGh,'genreList':ECULefxDBQvAXNgpTlaPKdMqWSOIGJ,}
      ECULefxDBQvAXNgpTlaPKdMqWSOIRV.append(ECULefxDBQvAXNgpTlaPKdMqWSOIGn)
     break
  except ECULefxDBQvAXNgpTlaPKdMqWSOIRo as exception:
   ECULefxDBQvAXNgpTlaPKdMqWSOIRk(exception)
   return[]
  return ECULefxDBQvAXNgpTlaPKdMqWSOIRV
# Created by pyminifier (https://github.com/liftoff/pyminifier)
