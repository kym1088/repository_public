__author__="NightRain"
imdFKsoLXrAREnzMvhIqxcltNPQVky=object
imdFKsoLXrAREnzMvhIqxcltNPQVkH=None
imdFKsoLXrAREnzMvhIqxcltNPQVkU=False
imdFKsoLXrAREnzMvhIqxcltNPQVkD=True
imdFKsoLXrAREnzMvhIqxcltNPQVkY=type
imdFKsoLXrAREnzMvhIqxcltNPQVkG=dict
imdFKsoLXrAREnzMvhIqxcltNPQVkC=getattr
imdFKsoLXrAREnzMvhIqxcltNPQVka=int
imdFKsoLXrAREnzMvhIqxcltNPQVkg=list
imdFKsoLXrAREnzMvhIqxcltNPQVkO=open
imdFKsoLXrAREnzMvhIqxcltNPQVkw=Exception
imdFKsoLXrAREnzMvhIqxcltNPQVkW=str
imdFKsoLXrAREnzMvhIqxcltNPQVke=id
imdFKsoLXrAREnzMvhIqxcltNPQVkp=len
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import inputstreamhelper
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
imdFKsoLXrAREnzMvhIqxcltNPQVJj=[{'title':'오직 쿠팡플레이에서','mode':'CATEGORY_LIST','vType':'ORIGINAL','collectionId':'5c33c5ca-ee6f-45f8-a026-dd789a8b63cf'},{'title':'홈   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'ALL'},{'title':'TV   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'MOVIES'},{'title':'(패스) 스포츠','mode':'SPORTS_MAINLIST_LEAGUE'},{'title':'(패스) Paramount+','mode':'PASS_GROUPLIST','collectionId':'1afeaf87-0b7a-4a49-a971-fa5be7aedf4e'},{'title':'(패스) Sony Pictures','mode':'PASS_GROUPLIST','collectionId':'5b37af01-01fb-4361-ba5b-0f23f307d557'},{'title':'TV   (테마별)','mode':'THEME_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (테마별)','mode':'THEME_GROUPLIST','vType':'MOVIES'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},{'title':'(쿠팡) 검색','mode':'LOCAL_SEARCH','icon':'search.png'},{'title':'(쿠팡) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
imdFKsoLXrAREnzMvhIqxcltNPQVJB=[{'title':'시리즈 시청내역','mode':'WATCH','stype':'tvshow'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},]
imdFKsoLXrAREnzMvhIqxcltNPQVJb={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
imdFKsoLXrAREnzMvhIqxcltNPQVJy=xbmcvfs.translatePath(os.path.join(__profile__,'coupang_searched.txt'))
from coupangCore import*
class imdFKsoLXrAREnzMvhIqxcltNPQVJS(imdFKsoLXrAREnzMvhIqxcltNPQVky):
 def __init__(imdFKsoLXrAREnzMvhIqxcltNPQVJH,imdFKsoLXrAREnzMvhIqxcltNPQVJk,imdFKsoLXrAREnzMvhIqxcltNPQVJU,imdFKsoLXrAREnzMvhIqxcltNPQVJD):
  imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_url =imdFKsoLXrAREnzMvhIqxcltNPQVJk
  imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle=imdFKsoLXrAREnzMvhIqxcltNPQVJU
  imdFKsoLXrAREnzMvhIqxcltNPQVJH.main_params =imdFKsoLXrAREnzMvhIqxcltNPQVJD
  imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj =ACRqVdomFTbsvWDhOpkQlUPiEIrMYc() 
  imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.CP_COOKIE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_cookies.json'))
  imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.CP_DEVICE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_device.json'))
 def addon_noti(imdFKsoLXrAREnzMvhIqxcltNPQVJH,sting):
  try:
   imdFKsoLXrAREnzMvhIqxcltNPQVJG=xbmcgui.Dialog()
   imdFKsoLXrAREnzMvhIqxcltNPQVJG.notification(__addonname__,sting)
  except:
   imdFKsoLXrAREnzMvhIqxcltNPQVkH
 def addon_log(imdFKsoLXrAREnzMvhIqxcltNPQVJH,string):
  try:
   imdFKsoLXrAREnzMvhIqxcltNPQVJC=string.encode('utf-8','ignore')
  except:
   imdFKsoLXrAREnzMvhIqxcltNPQVJC='addonException: addon_log'
  imdFKsoLXrAREnzMvhIqxcltNPQVJa=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,imdFKsoLXrAREnzMvhIqxcltNPQVJC),level=imdFKsoLXrAREnzMvhIqxcltNPQVJa)
 def get_keyboard_input(imdFKsoLXrAREnzMvhIqxcltNPQVJH,imdFKsoLXrAREnzMvhIqxcltNPQVSb):
  imdFKsoLXrAREnzMvhIqxcltNPQVJg=imdFKsoLXrAREnzMvhIqxcltNPQVkH
  kb=xbmc.Keyboard()
  kb.setHeading(imdFKsoLXrAREnzMvhIqxcltNPQVSb)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   imdFKsoLXrAREnzMvhIqxcltNPQVJg=kb.getText()
  return imdFKsoLXrAREnzMvhIqxcltNPQVJg
 def get_settings_account(imdFKsoLXrAREnzMvhIqxcltNPQVJH):
  imdFKsoLXrAREnzMvhIqxcltNPQVJO=__addon__.getSetting('id')
  imdFKsoLXrAREnzMvhIqxcltNPQVJw=__addon__.getSetting('pw')
  imdFKsoLXrAREnzMvhIqxcltNPQVJW=__addon__.getSetting('profile')
  return(imdFKsoLXrAREnzMvhIqxcltNPQVJO,imdFKsoLXrAREnzMvhIqxcltNPQVJw,imdFKsoLXrAREnzMvhIqxcltNPQVJW)
 def get_settings_exclusion21(imdFKsoLXrAREnzMvhIqxcltNPQVJH):
  imdFKsoLXrAREnzMvhIqxcltNPQVJe =__addon__.getSetting('exclusion21')
  if imdFKsoLXrAREnzMvhIqxcltNPQVJe=='false':
   return imdFKsoLXrAREnzMvhIqxcltNPQVkU
  else:
   return imdFKsoLXrAREnzMvhIqxcltNPQVkD
 def get_settings_totalsearch(imdFKsoLXrAREnzMvhIqxcltNPQVJH):
  imdFKsoLXrAREnzMvhIqxcltNPQVJp =imdFKsoLXrAREnzMvhIqxcltNPQVkD if __addon__.getSetting('local_search')=='true' else imdFKsoLXrAREnzMvhIqxcltNPQVkU
  imdFKsoLXrAREnzMvhIqxcltNPQVJT=imdFKsoLXrAREnzMvhIqxcltNPQVkD if __addon__.getSetting('local_history')=='true' else imdFKsoLXrAREnzMvhIqxcltNPQVkU
  imdFKsoLXrAREnzMvhIqxcltNPQVJu =imdFKsoLXrAREnzMvhIqxcltNPQVkD if __addon__.getSetting('total_search')=='true' else imdFKsoLXrAREnzMvhIqxcltNPQVkU
  imdFKsoLXrAREnzMvhIqxcltNPQVJf=imdFKsoLXrAREnzMvhIqxcltNPQVkD if __addon__.getSetting('total_history')=='true' else imdFKsoLXrAREnzMvhIqxcltNPQVkU
  imdFKsoLXrAREnzMvhIqxcltNPQVSJ=imdFKsoLXrAREnzMvhIqxcltNPQVkD if __addon__.getSetting('menu_bookmark')=='true' else imdFKsoLXrAREnzMvhIqxcltNPQVkU
  return(imdFKsoLXrAREnzMvhIqxcltNPQVJp,imdFKsoLXrAREnzMvhIqxcltNPQVJT,imdFKsoLXrAREnzMvhIqxcltNPQVJu,imdFKsoLXrAREnzMvhIqxcltNPQVJf,imdFKsoLXrAREnzMvhIqxcltNPQVSJ)
 def get_settings_makebookmark(imdFKsoLXrAREnzMvhIqxcltNPQVJH):
  return imdFKsoLXrAREnzMvhIqxcltNPQVkD if __addon__.getSetting('make_bookmark')=='true' else imdFKsoLXrAREnzMvhIqxcltNPQVkU
 def set_winEpisodeOrderby(imdFKsoLXrAREnzMvhIqxcltNPQVJH,imdFKsoLXrAREnzMvhIqxcltNPQVSj):
  __addon__.setSetting('coupang_orderby',imdFKsoLXrAREnzMvhIqxcltNPQVSj)
 def get_winEpisodeOrderby(imdFKsoLXrAREnzMvhIqxcltNPQVJH):
  imdFKsoLXrAREnzMvhIqxcltNPQVSj=__addon__.getSetting('coupang_orderby')
  if imdFKsoLXrAREnzMvhIqxcltNPQVSj in['',imdFKsoLXrAREnzMvhIqxcltNPQVkH]:imdFKsoLXrAREnzMvhIqxcltNPQVSj='asc'
  return imdFKsoLXrAREnzMvhIqxcltNPQVSj
 def add_dir(imdFKsoLXrAREnzMvhIqxcltNPQVJH,label,sublabel='',img='',infoLabels=imdFKsoLXrAREnzMvhIqxcltNPQVkH,isFolder=imdFKsoLXrAREnzMvhIqxcltNPQVkD,params='',isLink=imdFKsoLXrAREnzMvhIqxcltNPQVkU,ContextMenu=imdFKsoLXrAREnzMvhIqxcltNPQVkH):
  imdFKsoLXrAREnzMvhIqxcltNPQVSB='%s?%s'%(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_url,urllib.parse.urlencode(params))
  if sublabel:imdFKsoLXrAREnzMvhIqxcltNPQVSb='%s < %s >'%(label,sublabel)
  else: imdFKsoLXrAREnzMvhIqxcltNPQVSb=label
  if not img:img='DefaultFolder.png'
  imdFKsoLXrAREnzMvhIqxcltNPQVSy=xbmcgui.ListItem(imdFKsoLXrAREnzMvhIqxcltNPQVSb)
  if imdFKsoLXrAREnzMvhIqxcltNPQVkY(img)==imdFKsoLXrAREnzMvhIqxcltNPQVkG:
   imdFKsoLXrAREnzMvhIqxcltNPQVSy.setArt(img)
  else:
   imdFKsoLXrAREnzMvhIqxcltNPQVSy.setArt({'thumb':img,'poster':img})
  if imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.KodiVersion>=20:
   if infoLabels:imdFKsoLXrAREnzMvhIqxcltNPQVJH.Set_InfoTag(imdFKsoLXrAREnzMvhIqxcltNPQVSy.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:imdFKsoLXrAREnzMvhIqxcltNPQVSy.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   imdFKsoLXrAREnzMvhIqxcltNPQVSy.setProperty('IsPlayable','true')
  if ContextMenu:imdFKsoLXrAREnzMvhIqxcltNPQVSy.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,imdFKsoLXrAREnzMvhIqxcltNPQVSB,imdFKsoLXrAREnzMvhIqxcltNPQVSy,isFolder)
 def Set_InfoTag(imdFKsoLXrAREnzMvhIqxcltNPQVJH,video_InfoTag:xbmc.InfoTagVideo,imdFKsoLXrAREnzMvhIqxcltNPQVSa):
  for imdFKsoLXrAREnzMvhIqxcltNPQVSH,value in imdFKsoLXrAREnzMvhIqxcltNPQVSa.items():
   if imdFKsoLXrAREnzMvhIqxcltNPQVJb[imdFKsoLXrAREnzMvhIqxcltNPQVSH]['type']=='string':
    imdFKsoLXrAREnzMvhIqxcltNPQVkC(video_InfoTag,imdFKsoLXrAREnzMvhIqxcltNPQVJb[imdFKsoLXrAREnzMvhIqxcltNPQVSH]['func'])(value)
   elif imdFKsoLXrAREnzMvhIqxcltNPQVJb[imdFKsoLXrAREnzMvhIqxcltNPQVSH]['type']=='int':
    if imdFKsoLXrAREnzMvhIqxcltNPQVkY(value)==imdFKsoLXrAREnzMvhIqxcltNPQVka:
     imdFKsoLXrAREnzMvhIqxcltNPQVSk=imdFKsoLXrAREnzMvhIqxcltNPQVka(value)
    else:
     imdFKsoLXrAREnzMvhIqxcltNPQVSk=0
    imdFKsoLXrAREnzMvhIqxcltNPQVkC(video_InfoTag,imdFKsoLXrAREnzMvhIqxcltNPQVJb[imdFKsoLXrAREnzMvhIqxcltNPQVSH]['func'])(imdFKsoLXrAREnzMvhIqxcltNPQVSk)
   elif imdFKsoLXrAREnzMvhIqxcltNPQVJb[imdFKsoLXrAREnzMvhIqxcltNPQVSH]['type']=='actor':
    if value!=[]:
     imdFKsoLXrAREnzMvhIqxcltNPQVkC(video_InfoTag,imdFKsoLXrAREnzMvhIqxcltNPQVJb[imdFKsoLXrAREnzMvhIqxcltNPQVSH]['func'])([xbmc.Actor(name)for name in value])
   elif imdFKsoLXrAREnzMvhIqxcltNPQVJb[imdFKsoLXrAREnzMvhIqxcltNPQVSH]['type']=='list':
    if imdFKsoLXrAREnzMvhIqxcltNPQVkY(value)==imdFKsoLXrAREnzMvhIqxcltNPQVkg:
     imdFKsoLXrAREnzMvhIqxcltNPQVkC(video_InfoTag,imdFKsoLXrAREnzMvhIqxcltNPQVJb[imdFKsoLXrAREnzMvhIqxcltNPQVSH]['func'])(value)
    else:
     imdFKsoLXrAREnzMvhIqxcltNPQVkC(video_InfoTag,imdFKsoLXrAREnzMvhIqxcltNPQVJb[imdFKsoLXrAREnzMvhIqxcltNPQVSH]['func'])([value])
 def dp_Main_List(imdFKsoLXrAREnzMvhIqxcltNPQVJH,args):
  (imdFKsoLXrAREnzMvhIqxcltNPQVJp,imdFKsoLXrAREnzMvhIqxcltNPQVJT,imdFKsoLXrAREnzMvhIqxcltNPQVJu,imdFKsoLXrAREnzMvhIqxcltNPQVJf,imdFKsoLXrAREnzMvhIqxcltNPQVSJ)=imdFKsoLXrAREnzMvhIqxcltNPQVJH.get_settings_totalsearch()
  for imdFKsoLXrAREnzMvhIqxcltNPQVSU in imdFKsoLXrAREnzMvhIqxcltNPQVJj:
   imdFKsoLXrAREnzMvhIqxcltNPQVSb=imdFKsoLXrAREnzMvhIqxcltNPQVSU.get('title')
   imdFKsoLXrAREnzMvhIqxcltNPQVSD=''
   if imdFKsoLXrAREnzMvhIqxcltNPQVSU.get('mode')=='LOCAL_SEARCH' and imdFKsoLXrAREnzMvhIqxcltNPQVJp ==imdFKsoLXrAREnzMvhIqxcltNPQVkU:continue
   elif imdFKsoLXrAREnzMvhIqxcltNPQVSU.get('mode')=='SEARCH_HISTORY' and imdFKsoLXrAREnzMvhIqxcltNPQVJT==imdFKsoLXrAREnzMvhIqxcltNPQVkU:continue
   elif imdFKsoLXrAREnzMvhIqxcltNPQVSU.get('mode')=='TOTAL_SEARCH' and imdFKsoLXrAREnzMvhIqxcltNPQVJu ==imdFKsoLXrAREnzMvhIqxcltNPQVkU:continue
   elif imdFKsoLXrAREnzMvhIqxcltNPQVSU.get('mode')=='TOTAL_HISTORY' and imdFKsoLXrAREnzMvhIqxcltNPQVJf==imdFKsoLXrAREnzMvhIqxcltNPQVkU:continue
   elif imdFKsoLXrAREnzMvhIqxcltNPQVSU.get('mode')=='MENU_BOOKMARK' and imdFKsoLXrAREnzMvhIqxcltNPQVSJ==imdFKsoLXrAREnzMvhIqxcltNPQVkU:continue
   imdFKsoLXrAREnzMvhIqxcltNPQVSY={'mode':imdFKsoLXrAREnzMvhIqxcltNPQVSU.get('mode'),'vType':imdFKsoLXrAREnzMvhIqxcltNPQVSU.get('vType'),'collectionId':imdFKsoLXrAREnzMvhIqxcltNPQVSU.get('collectionId'),'page':'1',}
   if imdFKsoLXrAREnzMvhIqxcltNPQVSU.get('mode')=='LOCAL_SEARCH':imdFKsoLXrAREnzMvhIqxcltNPQVSY['historyyn']='Y' 
   if imdFKsoLXrAREnzMvhIqxcltNPQVSU.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    imdFKsoLXrAREnzMvhIqxcltNPQVSG=imdFKsoLXrAREnzMvhIqxcltNPQVkU
    imdFKsoLXrAREnzMvhIqxcltNPQVSC =imdFKsoLXrAREnzMvhIqxcltNPQVkD
   else:
    imdFKsoLXrAREnzMvhIqxcltNPQVSG=imdFKsoLXrAREnzMvhIqxcltNPQVkD
    imdFKsoLXrAREnzMvhIqxcltNPQVSC =imdFKsoLXrAREnzMvhIqxcltNPQVkU
   imdFKsoLXrAREnzMvhIqxcltNPQVSa={'title':imdFKsoLXrAREnzMvhIqxcltNPQVSb,'plot':imdFKsoLXrAREnzMvhIqxcltNPQVSb}
   if imdFKsoLXrAREnzMvhIqxcltNPQVSU.get('mode')=='XXX':imdFKsoLXrAREnzMvhIqxcltNPQVSa=imdFKsoLXrAREnzMvhIqxcltNPQVkH
   if 'icon' in imdFKsoLXrAREnzMvhIqxcltNPQVSU:imdFKsoLXrAREnzMvhIqxcltNPQVSD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',imdFKsoLXrAREnzMvhIqxcltNPQVSU.get('icon')) 
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.add_dir(imdFKsoLXrAREnzMvhIqxcltNPQVSb,sublabel='',img=imdFKsoLXrAREnzMvhIqxcltNPQVSD,infoLabels=imdFKsoLXrAREnzMvhIqxcltNPQVSa,isFolder=imdFKsoLXrAREnzMvhIqxcltNPQVSG,params=imdFKsoLXrAREnzMvhIqxcltNPQVSY,isLink=imdFKsoLXrAREnzMvhIqxcltNPQVSC)
  xbmcplugin.endOfDirectory(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle)
 def dp_Test(imdFKsoLXrAREnzMvhIqxcltNPQVJH,args):
  imdFKsoLXrAREnzMvhIqxcltNPQVJH.addon_noti('test')
 def CP_logout(imdFKsoLXrAREnzMvhIqxcltNPQVJH):
  imdFKsoLXrAREnzMvhIqxcltNPQVJG=xbmcgui.Dialog()
  imdFKsoLXrAREnzMvhIqxcltNPQVSO=imdFKsoLXrAREnzMvhIqxcltNPQVJG.yesno(__language__(30905).encode('utf8'),__language__(30906).encode('utf8'))
  if imdFKsoLXrAREnzMvhIqxcltNPQVSO==imdFKsoLXrAREnzMvhIqxcltNPQVkU:return 
  if os.path.isfile(imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.CP_COOKIE_FILENAME):os.remove(imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.CP_COOKIE_FILENAME)
  imdFKsoLXrAREnzMvhIqxcltNPQVJH.addon_noti(__language__(30904).encode('utf-8'))
 def option_check(imdFKsoLXrAREnzMvhIqxcltNPQVJH):
  (imdFKsoLXrAREnzMvhIqxcltNPQVJO,imdFKsoLXrAREnzMvhIqxcltNPQVJw,imdFKsoLXrAREnzMvhIqxcltNPQVJW)=imdFKsoLXrAREnzMvhIqxcltNPQVJH.get_settings_account()
  if imdFKsoLXrAREnzMvhIqxcltNPQVJO=='' or imdFKsoLXrAREnzMvhIqxcltNPQVJw=='':
   imdFKsoLXrAREnzMvhIqxcltNPQVJG=xbmcgui.Dialog()
   imdFKsoLXrAREnzMvhIqxcltNPQVSO=imdFKsoLXrAREnzMvhIqxcltNPQVJG.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if imdFKsoLXrAREnzMvhIqxcltNPQVSO==imdFKsoLXrAREnzMvhIqxcltNPQVkD:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if imdFKsoLXrAREnzMvhIqxcltNPQVJH.cookiefile_check()==imdFKsoLXrAREnzMvhIqxcltNPQVkU:
   if imdFKsoLXrAREnzMvhIqxcltNPQVJH.CP_login(imdFKsoLXrAREnzMvhIqxcltNPQVJO,imdFKsoLXrAREnzMvhIqxcltNPQVJw,imdFKsoLXrAREnzMvhIqxcltNPQVJW)==imdFKsoLXrAREnzMvhIqxcltNPQVkU:
    imdFKsoLXrAREnzMvhIqxcltNPQVJH.addon_noti(__language__(30903).encode('utf8'))
    sys.exit()
  else:
   if imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.CP['SESSION']['bm_sv_ex']<imdFKsoLXrAREnzMvhIqxcltNPQVka(time.time()):
    if imdFKsoLXrAREnzMvhIqxcltNPQVJH.CP_login(imdFKsoLXrAREnzMvhIqxcltNPQVJO,imdFKsoLXrAREnzMvhIqxcltNPQVJw,imdFKsoLXrAREnzMvhIqxcltNPQVJW)==imdFKsoLXrAREnzMvhIqxcltNPQVkU:
     imdFKsoLXrAREnzMvhIqxcltNPQVJH.addon_noti(__language__(30903).encode('utf8'))
     sys.exit()
 def cookiefile_check(imdFKsoLXrAREnzMvhIqxcltNPQVJH):
  imdFKsoLXrAREnzMvhIqxcltNPQVSw={}
  try: 
   fp=imdFKsoLXrAREnzMvhIqxcltNPQVkO(imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.CP_COOKIE_FILENAME,'r',-1,'utf-8')
   imdFKsoLXrAREnzMvhIqxcltNPQVSw= json.load(fp)
   fp.close()
  except imdFKsoLXrAREnzMvhIqxcltNPQVkw as exception:
   return imdFKsoLXrAREnzMvhIqxcltNPQVkU
  imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.CP=imdFKsoLXrAREnzMvhIqxcltNPQVSw
  (imdFKsoLXrAREnzMvhIqxcltNPQVJO,imdFKsoLXrAREnzMvhIqxcltNPQVJw,imdFKsoLXrAREnzMvhIqxcltNPQVJW)=imdFKsoLXrAREnzMvhIqxcltNPQVJH.get_settings_account()
  (imdFKsoLXrAREnzMvhIqxcltNPQVSW,imdFKsoLXrAREnzMvhIqxcltNPQVSe,imdFKsoLXrAREnzMvhIqxcltNPQVSp)=imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.Load_session_acount()
  if imdFKsoLXrAREnzMvhIqxcltNPQVJO!=imdFKsoLXrAREnzMvhIqxcltNPQVSW or imdFKsoLXrAREnzMvhIqxcltNPQVJw!=imdFKsoLXrAREnzMvhIqxcltNPQVSe or imdFKsoLXrAREnzMvhIqxcltNPQVJW!=imdFKsoLXrAREnzMvhIqxcltNPQVkW(imdFKsoLXrAREnzMvhIqxcltNPQVSp):
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.Init_CP()
   return imdFKsoLXrAREnzMvhIqxcltNPQVkU
  imdFKsoLXrAREnzMvhIqxcltNPQVST =imdFKsoLXrAREnzMvhIqxcltNPQVka(imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.Get_Now_Datetime().strftime('%Y%m%d'))
  imdFKsoLXrAREnzMvhIqxcltNPQVSu=imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.CP['SESSION']['limitdate']
  imdFKsoLXrAREnzMvhIqxcltNPQVSf =imdFKsoLXrAREnzMvhIqxcltNPQVka(re.sub('-','',imdFKsoLXrAREnzMvhIqxcltNPQVSu))
  if imdFKsoLXrAREnzMvhIqxcltNPQVSf<imdFKsoLXrAREnzMvhIqxcltNPQVST:
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.Init_CP()
   return imdFKsoLXrAREnzMvhIqxcltNPQVkU
  return imdFKsoLXrAREnzMvhIqxcltNPQVkD
 def CP_login(imdFKsoLXrAREnzMvhIqxcltNPQVJH,imdFKsoLXrAREnzMvhIqxcltNPQVJO,imdFKsoLXrAREnzMvhIqxcltNPQVJw,imdFKsoLXrAREnzMvhIqxcltNPQVJW):
  imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.Init_CP()
  if imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.Get_CP_Login(imdFKsoLXrAREnzMvhIqxcltNPQVJO,imdFKsoLXrAREnzMvhIqxcltNPQVJw,imdFKsoLXrAREnzMvhIqxcltNPQVJW)==imdFKsoLXrAREnzMvhIqxcltNPQVkU:return imdFKsoLXrAREnzMvhIqxcltNPQVkU
  if imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.Get_CP_profile(imdFKsoLXrAREnzMvhIqxcltNPQVJW,limit_days=imdFKsoLXrAREnzMvhIqxcltNPQVka(__addon__.getSetting('cache_ttl')),re_check=imdFKsoLXrAREnzMvhIqxcltNPQVkU)==imdFKsoLXrAREnzMvhIqxcltNPQVkU:return imdFKsoLXrAREnzMvhIqxcltNPQVkU
  return imdFKsoLXrAREnzMvhIqxcltNPQVkD
 def dp_Category_GroupList(imdFKsoLXrAREnzMvhIqxcltNPQVJH,args):
  imdFKsoLXrAREnzMvhIqxcltNPQVjJ =args.get('vType') 
  imdFKsoLXrAREnzMvhIqxcltNPQVjS=imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.Get_Category_GroupList(imdFKsoLXrAREnzMvhIqxcltNPQVjJ)
  for imdFKsoLXrAREnzMvhIqxcltNPQVjB in imdFKsoLXrAREnzMvhIqxcltNPQVjS:
   imdFKsoLXrAREnzMvhIqxcltNPQVSb =imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('title')
   imdFKsoLXrAREnzMvhIqxcltNPQVjb=imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('pre_title')
   if imdFKsoLXrAREnzMvhIqxcltNPQVJH.get_settings_exclusion21()==imdFKsoLXrAREnzMvhIqxcltNPQVkD and imdFKsoLXrAREnzMvhIqxcltNPQVSb=='성인':continue
   imdFKsoLXrAREnzMvhIqxcltNPQVjy={'mediatype':'tvshow','plot':imdFKsoLXrAREnzMvhIqxcltNPQVjb,}
   imdFKsoLXrAREnzMvhIqxcltNPQVSY={'mode':'CATEGORY_LIST','collectionId':imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('collectionId'),'vType':imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('category'),'page':'1',}
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.add_dir(imdFKsoLXrAREnzMvhIqxcltNPQVSb,sublabel='',img='',infoLabels=imdFKsoLXrAREnzMvhIqxcltNPQVjy,isFolder=imdFKsoLXrAREnzMvhIqxcltNPQVkD,params=imdFKsoLXrAREnzMvhIqxcltNPQVSY)
  xbmcplugin.endOfDirectory(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,cacheToDisc=imdFKsoLXrAREnzMvhIqxcltNPQVkU)
 def dp_Theme_GroupList(imdFKsoLXrAREnzMvhIqxcltNPQVJH,args):
  imdFKsoLXrAREnzMvhIqxcltNPQVjJ =args.get('vType') 
  imdFKsoLXrAREnzMvhIqxcltNPQVjS=imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.Get_Theme_GroupList(imdFKsoLXrAREnzMvhIqxcltNPQVjJ)
  for imdFKsoLXrAREnzMvhIqxcltNPQVjB in imdFKsoLXrAREnzMvhIqxcltNPQVjS:
   imdFKsoLXrAREnzMvhIqxcltNPQVSb =imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('title')
   imdFKsoLXrAREnzMvhIqxcltNPQVjb=imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('pre_title')
   imdFKsoLXrAREnzMvhIqxcltNPQVjy={'mediatype':'tvshow','plot':imdFKsoLXrAREnzMvhIqxcltNPQVjb,}
   imdFKsoLXrAREnzMvhIqxcltNPQVSY={'mode':'CATEGORY_LIST','collectionId':imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('collectionId'),'vType':imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('category'),'page':'1',}
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.add_dir(imdFKsoLXrAREnzMvhIqxcltNPQVSb,sublabel='',img='',infoLabels=imdFKsoLXrAREnzMvhIqxcltNPQVjy,isFolder=imdFKsoLXrAREnzMvhIqxcltNPQVkD,params=imdFKsoLXrAREnzMvhIqxcltNPQVSY)
  xbmcplugin.endOfDirectory(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,cacheToDisc=imdFKsoLXrAREnzMvhIqxcltNPQVkU)
 def dp_Event_GroupList(imdFKsoLXrAREnzMvhIqxcltNPQVJH,args):
  imdFKsoLXrAREnzMvhIqxcltNPQVjS=imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.Get_Event_GroupList()
  for imdFKsoLXrAREnzMvhIqxcltNPQVjB in imdFKsoLXrAREnzMvhIqxcltNPQVjS:
   imdFKsoLXrAREnzMvhIqxcltNPQVSb =imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('title')
   imdFKsoLXrAREnzMvhIqxcltNPQVjb=imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('pre_title')
   imdFKsoLXrAREnzMvhIqxcltNPQVjy={'mediatype':'tvshow','plot':imdFKsoLXrAREnzMvhIqxcltNPQVjb,}
   imdFKsoLXrAREnzMvhIqxcltNPQVSY={'mode':'EVENT_GAMELIST','collectionId':imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('collectionId'),'vType':'LIVE',}
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.add_dir(imdFKsoLXrAREnzMvhIqxcltNPQVSb,sublabel='',img='',infoLabels=imdFKsoLXrAREnzMvhIqxcltNPQVjy,isFolder=imdFKsoLXrAREnzMvhIqxcltNPQVkD,params=imdFKsoLXrAREnzMvhIqxcltNPQVSY)
  xbmcplugin.endOfDirectory(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,cacheToDisc=imdFKsoLXrAREnzMvhIqxcltNPQVkU)
 def dp_Event_GameList(imdFKsoLXrAREnzMvhIqxcltNPQVJH,args):
  imdFKsoLXrAREnzMvhIqxcltNPQVjJ =args.get('vType') 
  imdFKsoLXrAREnzMvhIqxcltNPQVjk =args.get('collectionId')
  imdFKsoLXrAREnzMvhIqxcltNPQVjS=imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.Get_Event_GameList(imdFKsoLXrAREnzMvhIqxcltNPQVjk)
  for imdFKsoLXrAREnzMvhIqxcltNPQVjB in imdFKsoLXrAREnzMvhIqxcltNPQVjS:
   imdFKsoLXrAREnzMvhIqxcltNPQVSb =imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('title')
   imdFKsoLXrAREnzMvhIqxcltNPQVke =imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('id')
   imdFKsoLXrAREnzMvhIqxcltNPQVjU =imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('thumbnail')
   imdFKsoLXrAREnzMvhIqxcltNPQVjD =imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('asis') 
   imdFKsoLXrAREnzMvhIqxcltNPQVjY =imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('addInfo')
   imdFKsoLXrAREnzMvhIqxcltNPQVjG =imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('starttm')
   imdFKsoLXrAREnzMvhIqxcltNPQVjy={'mediatype':'tvshow','title':imdFKsoLXrAREnzMvhIqxcltNPQVSb,'plot':imdFKsoLXrAREnzMvhIqxcltNPQVjY,}
   imdFKsoLXrAREnzMvhIqxcltNPQVSY={'mode':'EVENT_LIST','id':imdFKsoLXrAREnzMvhIqxcltNPQVke,'asis':imdFKsoLXrAREnzMvhIqxcltNPQVjD,'title':imdFKsoLXrAREnzMvhIqxcltNPQVSb,}
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.add_dir(imdFKsoLXrAREnzMvhIqxcltNPQVSb,sublabel=imdFKsoLXrAREnzMvhIqxcltNPQVjG,img=imdFKsoLXrAREnzMvhIqxcltNPQVjU,infoLabels=imdFKsoLXrAREnzMvhIqxcltNPQVjy,isFolder=imdFKsoLXrAREnzMvhIqxcltNPQVkD,params=imdFKsoLXrAREnzMvhIqxcltNPQVSY,ContextMenu=imdFKsoLXrAREnzMvhIqxcltNPQVkH)
  xbmcplugin.setContent(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,cacheToDisc=imdFKsoLXrAREnzMvhIqxcltNPQVkU)
 def dp_Event_List(imdFKsoLXrAREnzMvhIqxcltNPQVJH,args):
  imdFKsoLXrAREnzMvhIqxcltNPQVjC=args.get('id')
  imdFKsoLXrAREnzMvhIqxcltNPQVjS=imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.Get_Event_List(imdFKsoLXrAREnzMvhIqxcltNPQVjC)
  for imdFKsoLXrAREnzMvhIqxcltNPQVjB in imdFKsoLXrAREnzMvhIqxcltNPQVjS:
   imdFKsoLXrAREnzMvhIqxcltNPQVSb =imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('title')
   imdFKsoLXrAREnzMvhIqxcltNPQVke =imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('id')
   imdFKsoLXrAREnzMvhIqxcltNPQVjU =imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('thumbnail')
   imdFKsoLXrAREnzMvhIqxcltNPQVjD =imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('asis') 
   imdFKsoLXrAREnzMvhIqxcltNPQVja =imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('duration')
   imdFKsoLXrAREnzMvhIqxcltNPQVjG =imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('starttm')
   imdFKsoLXrAREnzMvhIqxcltNPQVjy={'mediatype':'episode','title':imdFKsoLXrAREnzMvhIqxcltNPQVSb,'plot':imdFKsoLXrAREnzMvhIqxcltNPQVjD,'duration':imdFKsoLXrAREnzMvhIqxcltNPQVja,}
   imdFKsoLXrAREnzMvhIqxcltNPQVSY={'mode':imdFKsoLXrAREnzMvhIqxcltNPQVjD,'id':imdFKsoLXrAREnzMvhIqxcltNPQVke,'asis':imdFKsoLXrAREnzMvhIqxcltNPQVjD,'title':imdFKsoLXrAREnzMvhIqxcltNPQVSb,}
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.add_dir(imdFKsoLXrAREnzMvhIqxcltNPQVSb,sublabel=imdFKsoLXrAREnzMvhIqxcltNPQVjG,img=imdFKsoLXrAREnzMvhIqxcltNPQVjU,infoLabels=imdFKsoLXrAREnzMvhIqxcltNPQVjy,isFolder=imdFKsoLXrAREnzMvhIqxcltNPQVkU,params=imdFKsoLXrAREnzMvhIqxcltNPQVSY,ContextMenu=imdFKsoLXrAREnzMvhIqxcltNPQVkH)
  xbmcplugin.setContent(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,cacheToDisc=imdFKsoLXrAREnzMvhIqxcltNPQVkU)
 def dp_Category_List(imdFKsoLXrAREnzMvhIqxcltNPQVJH,args):
  imdFKsoLXrAREnzMvhIqxcltNPQVjJ =args.get('vType') 
  imdFKsoLXrAREnzMvhIqxcltNPQVjk =args.get('collectionId')
  imdFKsoLXrAREnzMvhIqxcltNPQVjg =imdFKsoLXrAREnzMvhIqxcltNPQVka(args.get('page'))
  imdFKsoLXrAREnzMvhIqxcltNPQVjS,imdFKsoLXrAREnzMvhIqxcltNPQVjO=imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.Get_Category_List(imdFKsoLXrAREnzMvhIqxcltNPQVjJ,imdFKsoLXrAREnzMvhIqxcltNPQVjk,imdFKsoLXrAREnzMvhIqxcltNPQVjg)
  for imdFKsoLXrAREnzMvhIqxcltNPQVjB in imdFKsoLXrAREnzMvhIqxcltNPQVjS:
   imdFKsoLXrAREnzMvhIqxcltNPQVSb =imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('title')
   imdFKsoLXrAREnzMvhIqxcltNPQVke =imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('id')
   imdFKsoLXrAREnzMvhIqxcltNPQVjU =imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('thumbnail')
   imdFKsoLXrAREnzMvhIqxcltNPQVjw =imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('mpaa')
   imdFKsoLXrAREnzMvhIqxcltNPQVja =imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('duration')
   imdFKsoLXrAREnzMvhIqxcltNPQVjD =imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('asis')
   imdFKsoLXrAREnzMvhIqxcltNPQVjW =imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('badge')
   imdFKsoLXrAREnzMvhIqxcltNPQVje =imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('year')
   imdFKsoLXrAREnzMvhIqxcltNPQVjp=imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('seasonList')
   imdFKsoLXrAREnzMvhIqxcltNPQVjT =imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('genreList')
   if imdFKsoLXrAREnzMvhIqxcltNPQVjD in['TVSHOW','EDUCATION']: 
    imdFKsoLXrAREnzMvhIqxcltNPQVju ='SEASON_LIST'
    imdFKsoLXrAREnzMvhIqxcltNPQVjy={'mediatype':'tvshow','title':imdFKsoLXrAREnzMvhIqxcltNPQVSb,'mpaa':imdFKsoLXrAREnzMvhIqxcltNPQVjw,'genre':imdFKsoLXrAREnzMvhIqxcltNPQVjT,'year':imdFKsoLXrAREnzMvhIqxcltNPQVje,'plot':'Year : %s\nSeason : %s'%(imdFKsoLXrAREnzMvhIqxcltNPQVje,imdFKsoLXrAREnzMvhIqxcltNPQVjp),}
    imdFKsoLXrAREnzMvhIqxcltNPQVSG =imdFKsoLXrAREnzMvhIqxcltNPQVkD
   else:
    imdFKsoLXrAREnzMvhIqxcltNPQVju ='MOVIE'
    imdFKsoLXrAREnzMvhIqxcltNPQVjy={'mediatype':'movie','title':imdFKsoLXrAREnzMvhIqxcltNPQVSb,'mpaa':imdFKsoLXrAREnzMvhIqxcltNPQVjw,'genre':imdFKsoLXrAREnzMvhIqxcltNPQVjT,'duration':imdFKsoLXrAREnzMvhIqxcltNPQVja,'year':imdFKsoLXrAREnzMvhIqxcltNPQVje,'plot':'(%s)'%(imdFKsoLXrAREnzMvhIqxcltNPQVjw),}
    imdFKsoLXrAREnzMvhIqxcltNPQVSG =imdFKsoLXrAREnzMvhIqxcltNPQVkU
    imdFKsoLXrAREnzMvhIqxcltNPQVSb +=' (%s)'%(imdFKsoLXrAREnzMvhIqxcltNPQVkW(imdFKsoLXrAREnzMvhIqxcltNPQVje))
   imdFKsoLXrAREnzMvhIqxcltNPQVSY={'mode':imdFKsoLXrAREnzMvhIqxcltNPQVju,'id':imdFKsoLXrAREnzMvhIqxcltNPQVke,'asis':imdFKsoLXrAREnzMvhIqxcltNPQVjD,'seasonList':imdFKsoLXrAREnzMvhIqxcltNPQVjp,'title':imdFKsoLXrAREnzMvhIqxcltNPQVSb,'thumbnail':imdFKsoLXrAREnzMvhIqxcltNPQVjU,'year':imdFKsoLXrAREnzMvhIqxcltNPQVje,}
   if imdFKsoLXrAREnzMvhIqxcltNPQVJH.get_settings_makebookmark():
    imdFKsoLXrAREnzMvhIqxcltNPQVjf={'videoid':imdFKsoLXrAREnzMvhIqxcltNPQVke,'vidtype':'movie' if imdFKsoLXrAREnzMvhIqxcltNPQVjJ=='MOVIES' else 'tvshow','vtitle':imdFKsoLXrAREnzMvhIqxcltNPQVSb,'vsubtitle':'',}
    imdFKsoLXrAREnzMvhIqxcltNPQVBJ=json.dumps(imdFKsoLXrAREnzMvhIqxcltNPQVjf)
    imdFKsoLXrAREnzMvhIqxcltNPQVBJ=urllib.parse.quote(imdFKsoLXrAREnzMvhIqxcltNPQVBJ)
    imdFKsoLXrAREnzMvhIqxcltNPQVBS='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(imdFKsoLXrAREnzMvhIqxcltNPQVBJ)
    imdFKsoLXrAREnzMvhIqxcltNPQVBj=[('(통합) 찜 영상에 추가',imdFKsoLXrAREnzMvhIqxcltNPQVBS)]
   else:
    imdFKsoLXrAREnzMvhIqxcltNPQVBj=imdFKsoLXrAREnzMvhIqxcltNPQVkH
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.add_dir(imdFKsoLXrAREnzMvhIqxcltNPQVSb,sublabel=imdFKsoLXrAREnzMvhIqxcltNPQVjW,img=imdFKsoLXrAREnzMvhIqxcltNPQVjU,infoLabels=imdFKsoLXrAREnzMvhIqxcltNPQVjy,isFolder=imdFKsoLXrAREnzMvhIqxcltNPQVSG,params=imdFKsoLXrAREnzMvhIqxcltNPQVSY,ContextMenu=imdFKsoLXrAREnzMvhIqxcltNPQVBj)
  if imdFKsoLXrAREnzMvhIqxcltNPQVjO:
   imdFKsoLXrAREnzMvhIqxcltNPQVSY['mode'] ='CATEGORY_LIST' 
   imdFKsoLXrAREnzMvhIqxcltNPQVSY['collectionId']=imdFKsoLXrAREnzMvhIqxcltNPQVjk 
   imdFKsoLXrAREnzMvhIqxcltNPQVSY['vType'] =imdFKsoLXrAREnzMvhIqxcltNPQVjJ 
   imdFKsoLXrAREnzMvhIqxcltNPQVSY['page'] =imdFKsoLXrAREnzMvhIqxcltNPQVkW(imdFKsoLXrAREnzMvhIqxcltNPQVjg+1)
   imdFKsoLXrAREnzMvhIqxcltNPQVSb='[B]%s >>[/B]'%'다음 페이지'
   imdFKsoLXrAREnzMvhIqxcltNPQVBb=imdFKsoLXrAREnzMvhIqxcltNPQVkW(imdFKsoLXrAREnzMvhIqxcltNPQVjg+1)
   imdFKsoLXrAREnzMvhIqxcltNPQVSD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.add_dir(imdFKsoLXrAREnzMvhIqxcltNPQVSb,sublabel=imdFKsoLXrAREnzMvhIqxcltNPQVBb,img=imdFKsoLXrAREnzMvhIqxcltNPQVSD,infoLabels=imdFKsoLXrAREnzMvhIqxcltNPQVkH,isFolder=imdFKsoLXrAREnzMvhIqxcltNPQVkD,params=imdFKsoLXrAREnzMvhIqxcltNPQVSY)
  if imdFKsoLXrAREnzMvhIqxcltNPQVjJ=='TVSHOWS':xbmcplugin.setContent(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,'tvshows')
  else:xbmcplugin.setContent(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,'movies')
  xbmcplugin.endOfDirectory(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,cacheToDisc=imdFKsoLXrAREnzMvhIqxcltNPQVkU)
 def dp_Season_List(imdFKsoLXrAREnzMvhIqxcltNPQVJH,args):
  imdFKsoLXrAREnzMvhIqxcltNPQVBy =args.get('title')
  imdFKsoLXrAREnzMvhIqxcltNPQVBH =args.get('id')
  imdFKsoLXrAREnzMvhIqxcltNPQVjD =args.get('asis')
  imdFKsoLXrAREnzMvhIqxcltNPQVjp =args.get('seasonList')
  imdFKsoLXrAREnzMvhIqxcltNPQVjU =args.get('thumbnail')
  imdFKsoLXrAREnzMvhIqxcltNPQVje =args.get('year')
  if imdFKsoLXrAREnzMvhIqxcltNPQVjp in['',imdFKsoLXrAREnzMvhIqxcltNPQVkH]:
   imdFKsoLXrAREnzMvhIqxcltNPQVjp=imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.Get_vInfo(imdFKsoLXrAREnzMvhIqxcltNPQVBH).get('seasonList')
  if imdFKsoLXrAREnzMvhIqxcltNPQVkp(imdFKsoLXrAREnzMvhIqxcltNPQVjp.split(','))>1:
   for imdFKsoLXrAREnzMvhIqxcltNPQVBk in imdFKsoLXrAREnzMvhIqxcltNPQVjp.split(','):
    imdFKsoLXrAREnzMvhIqxcltNPQVSb='시즌 '+imdFKsoLXrAREnzMvhIqxcltNPQVBk
    imdFKsoLXrAREnzMvhIqxcltNPQVjy={'mediatype':'tvshow','plot':'%s (%s)'%(imdFKsoLXrAREnzMvhIqxcltNPQVBy,imdFKsoLXrAREnzMvhIqxcltNPQVje),}
    imdFKsoLXrAREnzMvhIqxcltNPQVSY={'mode':'EPISODE_LIST','programid':imdFKsoLXrAREnzMvhIqxcltNPQVBH,'programnm':imdFKsoLXrAREnzMvhIqxcltNPQVBy,'season':imdFKsoLXrAREnzMvhIqxcltNPQVBk,'asis':imdFKsoLXrAREnzMvhIqxcltNPQVjD,'programimg':imdFKsoLXrAREnzMvhIqxcltNPQVjU,'page':'1',}
    imdFKsoLXrAREnzMvhIqxcltNPQVBU=imdFKsoLXrAREnzMvhIqxcltNPQVjU.replace('\'','\"')
    imdFKsoLXrAREnzMvhIqxcltNPQVBU=json.loads(imdFKsoLXrAREnzMvhIqxcltNPQVBU)
    imdFKsoLXrAREnzMvhIqxcltNPQVJH.add_dir(imdFKsoLXrAREnzMvhIqxcltNPQVSb,sublabel='',img=imdFKsoLXrAREnzMvhIqxcltNPQVBU,infoLabels=imdFKsoLXrAREnzMvhIqxcltNPQVjy,isFolder=imdFKsoLXrAREnzMvhIqxcltNPQVkD,params=imdFKsoLXrAREnzMvhIqxcltNPQVSY)
   xbmcplugin.setContent(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,cacheToDisc=imdFKsoLXrAREnzMvhIqxcltNPQVkU)
  else:
   imdFKsoLXrAREnzMvhIqxcltNPQVBD={'programid':imdFKsoLXrAREnzMvhIqxcltNPQVBH,'programnm':imdFKsoLXrAREnzMvhIqxcltNPQVBy,'season':imdFKsoLXrAREnzMvhIqxcltNPQVjp,'programimg':imdFKsoLXrAREnzMvhIqxcltNPQVjU,'page':'1',}
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.dp_Episode_List(imdFKsoLXrAREnzMvhIqxcltNPQVBD)
 def dp_Episode_List(imdFKsoLXrAREnzMvhIqxcltNPQVJH,args):
  imdFKsoLXrAREnzMvhIqxcltNPQVBH =args.get('programid')
  imdFKsoLXrAREnzMvhIqxcltNPQVBy =args.get('programnm')
  imdFKsoLXrAREnzMvhIqxcltNPQVBY =args.get('season')
  imdFKsoLXrAREnzMvhIqxcltNPQVBG =args.get('programimg')
  imdFKsoLXrAREnzMvhIqxcltNPQVjg =imdFKsoLXrAREnzMvhIqxcltNPQVka(args.get('page'))
  imdFKsoLXrAREnzMvhIqxcltNPQVBC,imdFKsoLXrAREnzMvhIqxcltNPQVjO=imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.Get_Episode_List(imdFKsoLXrAREnzMvhIqxcltNPQVBH,imdFKsoLXrAREnzMvhIqxcltNPQVBY,page=imdFKsoLXrAREnzMvhIqxcltNPQVjg,orderby=imdFKsoLXrAREnzMvhIqxcltNPQVJH.get_winEpisodeOrderby())
  for imdFKsoLXrAREnzMvhIqxcltNPQVBk in imdFKsoLXrAREnzMvhIqxcltNPQVBC:
   imdFKsoLXrAREnzMvhIqxcltNPQVBa =imdFKsoLXrAREnzMvhIqxcltNPQVBk.get('title')
   imdFKsoLXrAREnzMvhIqxcltNPQVBg =imdFKsoLXrAREnzMvhIqxcltNPQVBk.get('id')
   imdFKsoLXrAREnzMvhIqxcltNPQVjD =imdFKsoLXrAREnzMvhIqxcltNPQVBk.get('asis')
   imdFKsoLXrAREnzMvhIqxcltNPQVjU =imdFKsoLXrAREnzMvhIqxcltNPQVBk.get('thumbnail')
   imdFKsoLXrAREnzMvhIqxcltNPQVjw =imdFKsoLXrAREnzMvhIqxcltNPQVBk.get('mpaa')
   imdFKsoLXrAREnzMvhIqxcltNPQVja =imdFKsoLXrAREnzMvhIqxcltNPQVBk.get('duration')
   imdFKsoLXrAREnzMvhIqxcltNPQVje =imdFKsoLXrAREnzMvhIqxcltNPQVBk.get('year')
   imdFKsoLXrAREnzMvhIqxcltNPQVBO =imdFKsoLXrAREnzMvhIqxcltNPQVBk.get('episode')
   imdFKsoLXrAREnzMvhIqxcltNPQVjT =imdFKsoLXrAREnzMvhIqxcltNPQVBk.get('genreList')
   imdFKsoLXrAREnzMvhIqxcltNPQVBw =imdFKsoLXrAREnzMvhIqxcltNPQVBk.get('desc')
   imdFKsoLXrAREnzMvhIqxcltNPQVBW ='%sx%s'%(imdFKsoLXrAREnzMvhIqxcltNPQVBY,imdFKsoLXrAREnzMvhIqxcltNPQVBO)
   imdFKsoLXrAREnzMvhIqxcltNPQVSb ='%s. %s'%(imdFKsoLXrAREnzMvhIqxcltNPQVBW,imdFKsoLXrAREnzMvhIqxcltNPQVBa)
   imdFKsoLXrAREnzMvhIqxcltNPQVjy={'mediatype':'episode','mpaa':imdFKsoLXrAREnzMvhIqxcltNPQVjw,'genre':imdFKsoLXrAREnzMvhIqxcltNPQVjT,'duration':imdFKsoLXrAREnzMvhIqxcltNPQVja,'year':imdFKsoLXrAREnzMvhIqxcltNPQVje,'plot':'%s (%s)\n\n%s'%(imdFKsoLXrAREnzMvhIqxcltNPQVBy,imdFKsoLXrAREnzMvhIqxcltNPQVBW,imdFKsoLXrAREnzMvhIqxcltNPQVBw),}
   imdFKsoLXrAREnzMvhIqxcltNPQVSY={'mode':'VOD','programid':imdFKsoLXrAREnzMvhIqxcltNPQVBH,'programnm':imdFKsoLXrAREnzMvhIqxcltNPQVBy,'title':imdFKsoLXrAREnzMvhIqxcltNPQVSb,'season':imdFKsoLXrAREnzMvhIqxcltNPQVBY,'id':imdFKsoLXrAREnzMvhIqxcltNPQVBg,'asis':imdFKsoLXrAREnzMvhIqxcltNPQVjD,'thumbnail':imdFKsoLXrAREnzMvhIqxcltNPQVjU,'programimg':imdFKsoLXrAREnzMvhIqxcltNPQVBG,}
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.add_dir(imdFKsoLXrAREnzMvhIqxcltNPQVSb,sublabel='',img=imdFKsoLXrAREnzMvhIqxcltNPQVjU,infoLabels=imdFKsoLXrAREnzMvhIqxcltNPQVjy,isFolder=imdFKsoLXrAREnzMvhIqxcltNPQVkU,params=imdFKsoLXrAREnzMvhIqxcltNPQVSY)
  if imdFKsoLXrAREnzMvhIqxcltNPQVjg==1:
   imdFKsoLXrAREnzMvhIqxcltNPQVjy={'plot':'정렬순서를 변경합니다.'}
   imdFKsoLXrAREnzMvhIqxcltNPQVSY={}
   imdFKsoLXrAREnzMvhIqxcltNPQVSY['mode'] ='ORDER_BY' 
   if imdFKsoLXrAREnzMvhIqxcltNPQVJH.get_winEpisodeOrderby()=='desc':
    imdFKsoLXrAREnzMvhIqxcltNPQVSb='정렬순서변경 : 최신화부터 -> 1회부터'
    imdFKsoLXrAREnzMvhIqxcltNPQVSY['orderby']='asc'
   else:
    imdFKsoLXrAREnzMvhIqxcltNPQVSb='정렬순서변경 : 1회부터 -> 최신화부터'
    imdFKsoLXrAREnzMvhIqxcltNPQVSY['orderby']='desc'
   imdFKsoLXrAREnzMvhIqxcltNPQVSD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.add_dir(imdFKsoLXrAREnzMvhIqxcltNPQVSb,sublabel='',img=imdFKsoLXrAREnzMvhIqxcltNPQVSD,infoLabels=imdFKsoLXrAREnzMvhIqxcltNPQVjy,isFolder=imdFKsoLXrAREnzMvhIqxcltNPQVkU,params=imdFKsoLXrAREnzMvhIqxcltNPQVSY,isLink=imdFKsoLXrAREnzMvhIqxcltNPQVkD)
  if imdFKsoLXrAREnzMvhIqxcltNPQVjO:
   imdFKsoLXrAREnzMvhIqxcltNPQVSY={}
   imdFKsoLXrAREnzMvhIqxcltNPQVSY['mode'] ='EPISODE_LIST'
   imdFKsoLXrAREnzMvhIqxcltNPQVSY['programid'] =imdFKsoLXrAREnzMvhIqxcltNPQVBH
   imdFKsoLXrAREnzMvhIqxcltNPQVSY['programnm'] =imdFKsoLXrAREnzMvhIqxcltNPQVBy
   imdFKsoLXrAREnzMvhIqxcltNPQVSY['season'] =imdFKsoLXrAREnzMvhIqxcltNPQVBY
   imdFKsoLXrAREnzMvhIqxcltNPQVSY['programimg']=imdFKsoLXrAREnzMvhIqxcltNPQVBG
   imdFKsoLXrAREnzMvhIqxcltNPQVSY['page'] =imdFKsoLXrAREnzMvhIqxcltNPQVkW(imdFKsoLXrAREnzMvhIqxcltNPQVjg+1)
   imdFKsoLXrAREnzMvhIqxcltNPQVSb='[B]%s >>[/B]'%'다음 페이지'
   imdFKsoLXrAREnzMvhIqxcltNPQVBb=imdFKsoLXrAREnzMvhIqxcltNPQVkW(imdFKsoLXrAREnzMvhIqxcltNPQVjg+1)
   imdFKsoLXrAREnzMvhIqxcltNPQVSD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.add_dir(imdFKsoLXrAREnzMvhIqxcltNPQVSb,sublabel=imdFKsoLXrAREnzMvhIqxcltNPQVBb,img=imdFKsoLXrAREnzMvhIqxcltNPQVSD,infoLabels=imdFKsoLXrAREnzMvhIqxcltNPQVkH,isFolder=imdFKsoLXrAREnzMvhIqxcltNPQVkD,params=imdFKsoLXrAREnzMvhIqxcltNPQVSY)
  xbmcplugin.setContent(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,cacheToDisc=imdFKsoLXrAREnzMvhIqxcltNPQVkU)
 def play_VIDEO(imdFKsoLXrAREnzMvhIqxcltNPQVJH,args):
  imdFKsoLXrAREnzMvhIqxcltNPQVBe =args.get('id')
  imdFKsoLXrAREnzMvhIqxcltNPQVjD =args.get('asis')
  if imdFKsoLXrAREnzMvhIqxcltNPQVjD in['HIGHLIGHT']:
   imdFKsoLXrAREnzMvhIqxcltNPQVBp,imdFKsoLXrAREnzMvhIqxcltNPQVBT=imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.GetEventURL(imdFKsoLXrAREnzMvhIqxcltNPQVBe,imdFKsoLXrAREnzMvhIqxcltNPQVjD)
  elif imdFKsoLXrAREnzMvhIqxcltNPQVjD in['LIVE']:
   imdFKsoLXrAREnzMvhIqxcltNPQVBp,imdFKsoLXrAREnzMvhIqxcltNPQVBT=imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.GetEventURL_Live(imdFKsoLXrAREnzMvhIqxcltNPQVBe,imdFKsoLXrAREnzMvhIqxcltNPQVjD)
  else:
   imdFKsoLXrAREnzMvhIqxcltNPQVBp,imdFKsoLXrAREnzMvhIqxcltNPQVBT=imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.GetBroadURL(imdFKsoLXrAREnzMvhIqxcltNPQVBe)
  imdFKsoLXrAREnzMvhIqxcltNPQVJH.addon_log('asis, url : %s - %s - %s'%(imdFKsoLXrAREnzMvhIqxcltNPQVjD,imdFKsoLXrAREnzMvhIqxcltNPQVBe,imdFKsoLXrAREnzMvhIqxcltNPQVBp))
  if imdFKsoLXrAREnzMvhIqxcltNPQVBp=='':
   if imdFKsoLXrAREnzMvhIqxcltNPQVBT=='':
    imdFKsoLXrAREnzMvhIqxcltNPQVJH.addon_noti(__language__(30907).encode('utf8'))
   else:
    imdFKsoLXrAREnzMvhIqxcltNPQVJH.addon_log('drm_license_1 : %s'%(imdFKsoLXrAREnzMvhIqxcltNPQVBT))
    imdFKsoLXrAREnzMvhIqxcltNPQVJH.addon_noti(imdFKsoLXrAREnzMvhIqxcltNPQVBT)
   return
  else:
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.addon_log('drm_license : %s'%(imdFKsoLXrAREnzMvhIqxcltNPQVBT))
  '''
  tmp_cookie = 'PCID=%s;token=%s;member_srl=%s;NEXT_LOCALE=%s;session_web_id=%s;device_id=%s' % (self.CoupangObj.CP['COOKIES']['PCID'], self.CoupangObj.CP['COOKIES']['token'], self.CoupangObj.CP['COOKIES']['member_srl'], self.CoupangObj.CP['COOKIES']['NEXT_LOCALE'], self.CoupangObj.CP['COOKIES']['session_web_id'], self.CoupangObj.CP['COOKIES']['device_id'], )
  '''  
  if imdFKsoLXrAREnzMvhIqxcltNPQVjD in['EPISODE']:
   imdFKsoLXrAREnzMvhIqxcltNPQVBu='https://www.coupangplay.com/play/{}/episode?titleId={}&type=EPISODE&sourceType=page_discover_title_detail%3Apage_discover_feed'.format(imdFKsoLXrAREnzMvhIqxcltNPQVBe,imdFKsoLXrAREnzMvhIqxcltNPQVBe)
  elif imdFKsoLXrAREnzMvhIqxcltNPQVjD in['MOVIE']:
   imdFKsoLXrAREnzMvhIqxcltNPQVBu='https://www.coupangplay.com/play/{}/movie?sourceType=page_discover_feed'.format(imdFKsoLXrAREnzMvhIqxcltNPQVBe)
  else:
   imdFKsoLXrAREnzMvhIqxcltNPQVBu='https://www.coupangplay.com/play/'+imdFKsoLXrAREnzMvhIqxcltNPQVBe 
  imdFKsoLXrAREnzMvhIqxcltNPQVBf,imdFKsoLXrAREnzMvhIqxcltNPQVbJ,imdFKsoLXrAREnzMvhIqxcltNPQVbS=imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.Make_authHeader()
  imdFKsoLXrAREnzMvhIqxcltNPQVbj=imdFKsoLXrAREnzMvhIqxcltNPQVBp 
  imdFKsoLXrAREnzMvhIqxcltNPQVJH.addon_log('tobe, surl : %s'%(imdFKsoLXrAREnzMvhIqxcltNPQVbj))
  imdFKsoLXrAREnzMvhIqxcltNPQVbB=xbmcgui.ListItem(path=imdFKsoLXrAREnzMvhIqxcltNPQVbj)
  imdFKsoLXrAREnzMvhIqxcltNPQVby=imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.Get_Url_PostFix(imdFKsoLXrAREnzMvhIqxcltNPQVBp) 
  imdFKsoLXrAREnzMvhIqxcltNPQVJH.addon_log('post_fix : '+imdFKsoLXrAREnzMvhIqxcltNPQVby)
  if imdFKsoLXrAREnzMvhIqxcltNPQVby=='m3u8':
   imdFKsoLXrAREnzMvhIqxcltNPQVbH ='hls' 
  else:
   imdFKsoLXrAREnzMvhIqxcltNPQVbH ='mpd' 
  imdFKsoLXrAREnzMvhIqxcltNPQVbk={'user-agent':imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.USER_AGENT,'referer':imdFKsoLXrAREnzMvhIqxcltNPQVBu,'traceparent':imdFKsoLXrAREnzMvhIqxcltNPQVBf,'tracestate':imdFKsoLXrAREnzMvhIqxcltNPQVbJ,'newrelic':imdFKsoLXrAREnzMvhIqxcltNPQVbS,}
  imdFKsoLXrAREnzMvhIqxcltNPQVbU =imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.CP['COOKIES']
  imdFKsoLXrAREnzMvhIqxcltNPQVbD=imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.make_stream_header(imdFKsoLXrAREnzMvhIqxcltNPQVbk,imdFKsoLXrAREnzMvhIqxcltNPQVbU)
  if imdFKsoLXrAREnzMvhIqxcltNPQVBT:
   imdFKsoLXrAREnzMvhIqxcltNPQVbY =imdFKsoLXrAREnzMvhIqxcltNPQVBT 
   imdFKsoLXrAREnzMvhIqxcltNPQVbG ='com.widevine.alpha'
   imdFKsoLXrAREnzMvhIqxcltNPQVbC=imdFKsoLXrAREnzMvhIqxcltNPQVbY+'|'+imdFKsoLXrAREnzMvhIqxcltNPQVbD+'|R{SSM}|'
   inputstreamhelper.Helper(imdFKsoLXrAREnzMvhIqxcltNPQVbH,drm='com.widevine.alpha').check_inputstream()
   imdFKsoLXrAREnzMvhIqxcltNPQVbB.setProperty('inputstream','inputstream.adaptive')
   if imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.KodiVersion<=20:
    imdFKsoLXrAREnzMvhIqxcltNPQVbB.setProperty('inputstream.adaptive.manifest_type',imdFKsoLXrAREnzMvhIqxcltNPQVbH)
   imdFKsoLXrAREnzMvhIqxcltNPQVbB.setProperty('inputstream.adaptive.license_type',imdFKsoLXrAREnzMvhIqxcltNPQVbG)
   imdFKsoLXrAREnzMvhIqxcltNPQVbB.setProperty('inputstream.adaptive.license_key',imdFKsoLXrAREnzMvhIqxcltNPQVbC)
   imdFKsoLXrAREnzMvhIqxcltNPQVbB.setProperty('inputstream.adaptive.stream_headers',imdFKsoLXrAREnzMvhIqxcltNPQVbD)
   imdFKsoLXrAREnzMvhIqxcltNPQVbB.setProperty('inputstream.adaptive.manifest_headers',imdFKsoLXrAREnzMvhIqxcltNPQVbD)
   imdFKsoLXrAREnzMvhIqxcltNPQVbB.setMimeType('application/dash+xml')
   imdFKsoLXrAREnzMvhIqxcltNPQVbB.setContentLookup(imdFKsoLXrAREnzMvhIqxcltNPQVkU)
  else:
   imdFKsoLXrAREnzMvhIqxcltNPQVbB.setContentLookup(imdFKsoLXrAREnzMvhIqxcltNPQVkU)
   imdFKsoLXrAREnzMvhIqxcltNPQVbB.setMimeType('application/x-mpegURL')
   imdFKsoLXrAREnzMvhIqxcltNPQVbB.setProperty('inputstream','inputstream.adaptive')
   if imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.KodiVersion<=20:
    imdFKsoLXrAREnzMvhIqxcltNPQVbB.setProperty('inputstream.adaptive.manifest_type',imdFKsoLXrAREnzMvhIqxcltNPQVbH)
   imdFKsoLXrAREnzMvhIqxcltNPQVbB.setProperty('inputstream.adaptive.stream_headers',imdFKsoLXrAREnzMvhIqxcltNPQVbD)
   imdFKsoLXrAREnzMvhIqxcltNPQVbB.setProperty('inputstream.adaptive.manifest_headers',imdFKsoLXrAREnzMvhIqxcltNPQVbD)
  xbmcplugin.setResolvedUrl(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,imdFKsoLXrAREnzMvhIqxcltNPQVkD,imdFKsoLXrAREnzMvhIqxcltNPQVbB)
  try:
   if imdFKsoLXrAREnzMvhIqxcltNPQVjD=='MOVIE':
    imdFKsoLXrAREnzMvhIqxcltNPQVbg='movie'
    imdFKsoLXrAREnzMvhIqxcltNPQVSY={'code':imdFKsoLXrAREnzMvhIqxcltNPQVBe,'asis':imdFKsoLXrAREnzMvhIqxcltNPQVjD,'title':args.get('title'),'img':args.get('thumbnail'),}
    imdFKsoLXrAREnzMvhIqxcltNPQVJH.Save_Watched_List(imdFKsoLXrAREnzMvhIqxcltNPQVbg,imdFKsoLXrAREnzMvhIqxcltNPQVSY)
   elif imdFKsoLXrAREnzMvhIqxcltNPQVjD=='EPISODE':
    imdFKsoLXrAREnzMvhIqxcltNPQVbg='tvshow'
    imdFKsoLXrAREnzMvhIqxcltNPQVSY={'code':args.get('programid'),'asis':imdFKsoLXrAREnzMvhIqxcltNPQVjD,'title':'%s <%s>'%(args.get('title'),args.get('programnm')),'img':args.get('programimg'),}
    imdFKsoLXrAREnzMvhIqxcltNPQVJH.Save_Watched_List(imdFKsoLXrAREnzMvhIqxcltNPQVbg,imdFKsoLXrAREnzMvhIqxcltNPQVSY)
  except:
   imdFKsoLXrAREnzMvhIqxcltNPQVkH
 def dp_Global_Search(imdFKsoLXrAREnzMvhIqxcltNPQVJH,args):
  imdFKsoLXrAREnzMvhIqxcltNPQVju=args.get('mode')
  if imdFKsoLXrAREnzMvhIqxcltNPQVju=='TOTAL_SEARCH':
   imdFKsoLXrAREnzMvhIqxcltNPQVbO='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   imdFKsoLXrAREnzMvhIqxcltNPQVbO='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(imdFKsoLXrAREnzMvhIqxcltNPQVbO)
 def dp_Bookmark_Menu(imdFKsoLXrAREnzMvhIqxcltNPQVJH,args):
  imdFKsoLXrAREnzMvhIqxcltNPQVbO='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(imdFKsoLXrAREnzMvhIqxcltNPQVbO)
 def dp_Search_List(imdFKsoLXrAREnzMvhIqxcltNPQVJH,args):
  imdFKsoLXrAREnzMvhIqxcltNPQVjg =imdFKsoLXrAREnzMvhIqxcltNPQVka(args.get('page'))
  if 'search_key' in args:
   imdFKsoLXrAREnzMvhIqxcltNPQVbw=args.get('search_key')
  else:
   imdFKsoLXrAREnzMvhIqxcltNPQVbw=imdFKsoLXrAREnzMvhIqxcltNPQVJH.get_keyboard_input(__language__(30908).encode('utf-8'))
   if not imdFKsoLXrAREnzMvhIqxcltNPQVbw:
    return
  imdFKsoLXrAREnzMvhIqxcltNPQVbW,imdFKsoLXrAREnzMvhIqxcltNPQVjO=imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.Get_Search_List(imdFKsoLXrAREnzMvhIqxcltNPQVbw,imdFKsoLXrAREnzMvhIqxcltNPQVjg)
  for imdFKsoLXrAREnzMvhIqxcltNPQVbe in imdFKsoLXrAREnzMvhIqxcltNPQVbW:
   imdFKsoLXrAREnzMvhIqxcltNPQVke =imdFKsoLXrAREnzMvhIqxcltNPQVbe.get('id')
   imdFKsoLXrAREnzMvhIqxcltNPQVSb =imdFKsoLXrAREnzMvhIqxcltNPQVbe.get('title')
   imdFKsoLXrAREnzMvhIqxcltNPQVjD =imdFKsoLXrAREnzMvhIqxcltNPQVbe.get('asis')
   imdFKsoLXrAREnzMvhIqxcltNPQVjU =imdFKsoLXrAREnzMvhIqxcltNPQVbe.get('thumbnail')
   imdFKsoLXrAREnzMvhIqxcltNPQVjw =imdFKsoLXrAREnzMvhIqxcltNPQVbe.get('mpaa')
   imdFKsoLXrAREnzMvhIqxcltNPQVje =imdFKsoLXrAREnzMvhIqxcltNPQVbe.get('year')
   imdFKsoLXrAREnzMvhIqxcltNPQVja =imdFKsoLXrAREnzMvhIqxcltNPQVbe.get('duration')
   imdFKsoLXrAREnzMvhIqxcltNPQVjW =imdFKsoLXrAREnzMvhIqxcltNPQVbe.get('badge')
   if imdFKsoLXrAREnzMvhIqxcltNPQVjD=='TVSHOW': 
    imdFKsoLXrAREnzMvhIqxcltNPQVju ='SEASON_LIST'
    imdFKsoLXrAREnzMvhIqxcltNPQVjy={'mediatype':'tvshow','title':imdFKsoLXrAREnzMvhIqxcltNPQVSb,'mpaa':imdFKsoLXrAREnzMvhIqxcltNPQVjw,'year':imdFKsoLXrAREnzMvhIqxcltNPQVje,'plot':'Year : %s'%(imdFKsoLXrAREnzMvhIqxcltNPQVje),}
    imdFKsoLXrAREnzMvhIqxcltNPQVSG =imdFKsoLXrAREnzMvhIqxcltNPQVkD
   elif imdFKsoLXrAREnzMvhIqxcltNPQVjD=='MOVIE':
    imdFKsoLXrAREnzMvhIqxcltNPQVju ='MOVIE'
    imdFKsoLXrAREnzMvhIqxcltNPQVjy={'mediatype':'movie','title':imdFKsoLXrAREnzMvhIqxcltNPQVSb,'mpaa':imdFKsoLXrAREnzMvhIqxcltNPQVjw,'duration':imdFKsoLXrAREnzMvhIqxcltNPQVja,'year':imdFKsoLXrAREnzMvhIqxcltNPQVje,'plot':'(%s)'%(imdFKsoLXrAREnzMvhIqxcltNPQVjw),}
    imdFKsoLXrAREnzMvhIqxcltNPQVSG =imdFKsoLXrAREnzMvhIqxcltNPQVkU
    imdFKsoLXrAREnzMvhIqxcltNPQVSb +=' (%s)'%(imdFKsoLXrAREnzMvhIqxcltNPQVkW(imdFKsoLXrAREnzMvhIqxcltNPQVje))
   elif imdFKsoLXrAREnzMvhIqxcltNPQVjD=='HIGHLIGHT':
    imdFKsoLXrAREnzMvhIqxcltNPQVju ='HIGHLIGHT'
    imdFKsoLXrAREnzMvhIqxcltNPQVjy={'mediatype':'episode','title':imdFKsoLXrAREnzMvhIqxcltNPQVSb,'duration':imdFKsoLXrAREnzMvhIqxcltNPQVja,'plot':imdFKsoLXrAREnzMvhIqxcltNPQVju,}
    imdFKsoLXrAREnzMvhIqxcltNPQVSG =imdFKsoLXrAREnzMvhIqxcltNPQVkU
   elif imdFKsoLXrAREnzMvhIqxcltNPQVjD=='LIVE':
    imdFKsoLXrAREnzMvhIqxcltNPQVju ='LIVE'
    imdFKsoLXrAREnzMvhIqxcltNPQVjy={'mediatype':'episode','title':imdFKsoLXrAREnzMvhIqxcltNPQVSb,'plot':imdFKsoLXrAREnzMvhIqxcltNPQVju,}
    imdFKsoLXrAREnzMvhIqxcltNPQVSG =imdFKsoLXrAREnzMvhIqxcltNPQVkU
   imdFKsoLXrAREnzMvhIqxcltNPQVSY={'mode':imdFKsoLXrAREnzMvhIqxcltNPQVju,'id':imdFKsoLXrAREnzMvhIqxcltNPQVke,'asis':imdFKsoLXrAREnzMvhIqxcltNPQVjD,'seasonList':'','title':imdFKsoLXrAREnzMvhIqxcltNPQVSb,'thumbnail':json.dumps(imdFKsoLXrAREnzMvhIqxcltNPQVjU,separators=(',',':')),'year':imdFKsoLXrAREnzMvhIqxcltNPQVje,}
   if imdFKsoLXrAREnzMvhIqxcltNPQVJH.get_settings_makebookmark()and imdFKsoLXrAREnzMvhIqxcltNPQVjD not in['HIGHLIGHT','']:
    imdFKsoLXrAREnzMvhIqxcltNPQVjf={'videoid':imdFKsoLXrAREnzMvhIqxcltNPQVke,'vidtype':'movie' if imdFKsoLXrAREnzMvhIqxcltNPQVjD=='MOVIE' else 'tvshow','vtitle':imdFKsoLXrAREnzMvhIqxcltNPQVSb,'vsubtitle':'',}
    imdFKsoLXrAREnzMvhIqxcltNPQVBJ=json.dumps(imdFKsoLXrAREnzMvhIqxcltNPQVjf)
    imdFKsoLXrAREnzMvhIqxcltNPQVBJ=urllib.parse.quote(imdFKsoLXrAREnzMvhIqxcltNPQVBJ)
    imdFKsoLXrAREnzMvhIqxcltNPQVBS='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(imdFKsoLXrAREnzMvhIqxcltNPQVBJ)
    imdFKsoLXrAREnzMvhIqxcltNPQVBj=[('(통합) 찜 영상에 추가',imdFKsoLXrAREnzMvhIqxcltNPQVBS)]
   else:
    imdFKsoLXrAREnzMvhIqxcltNPQVBj=imdFKsoLXrAREnzMvhIqxcltNPQVkH
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.add_dir(imdFKsoLXrAREnzMvhIqxcltNPQVSb,sublabel=imdFKsoLXrAREnzMvhIqxcltNPQVjW,img=imdFKsoLXrAREnzMvhIqxcltNPQVjU,infoLabels=imdFKsoLXrAREnzMvhIqxcltNPQVjy,isFolder=imdFKsoLXrAREnzMvhIqxcltNPQVSG,params=imdFKsoLXrAREnzMvhIqxcltNPQVSY,ContextMenu=imdFKsoLXrAREnzMvhIqxcltNPQVBj)
  if imdFKsoLXrAREnzMvhIqxcltNPQVjO:
   imdFKsoLXrAREnzMvhIqxcltNPQVSY={}
   imdFKsoLXrAREnzMvhIqxcltNPQVSY['mode'] ='LOCAL_SEARCH'
   imdFKsoLXrAREnzMvhIqxcltNPQVSY['search_key']=imdFKsoLXrAREnzMvhIqxcltNPQVbw
   imdFKsoLXrAREnzMvhIqxcltNPQVSY['page'] =imdFKsoLXrAREnzMvhIqxcltNPQVkW(imdFKsoLXrAREnzMvhIqxcltNPQVjg+1)
   imdFKsoLXrAREnzMvhIqxcltNPQVSb='[B]%s >>[/B]'%'다음 페이지'
   imdFKsoLXrAREnzMvhIqxcltNPQVBb=imdFKsoLXrAREnzMvhIqxcltNPQVkW(imdFKsoLXrAREnzMvhIqxcltNPQVjg+1)
   imdFKsoLXrAREnzMvhIqxcltNPQVSD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.add_dir(imdFKsoLXrAREnzMvhIqxcltNPQVSb,sublabel=imdFKsoLXrAREnzMvhIqxcltNPQVBb,img=imdFKsoLXrAREnzMvhIqxcltNPQVSD,infoLabels=imdFKsoLXrAREnzMvhIqxcltNPQVkH,isFolder=imdFKsoLXrAREnzMvhIqxcltNPQVkD,params=imdFKsoLXrAREnzMvhIqxcltNPQVSY)
  xbmcplugin.setContent(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,'movies')
  xbmcplugin.endOfDirectory(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,cacheToDisc=imdFKsoLXrAREnzMvhIqxcltNPQVkD)
  if args.get('historyyn')=='Y':imdFKsoLXrAREnzMvhIqxcltNPQVJH.Save_Searched_List(imdFKsoLXrAREnzMvhIqxcltNPQVbw)
 def Load_List_File(imdFKsoLXrAREnzMvhIqxcltNPQVJH,imdFKsoLXrAREnzMvhIqxcltNPQVbg): 
  try:
   if imdFKsoLXrAREnzMvhIqxcltNPQVbg=='search':
    imdFKsoLXrAREnzMvhIqxcltNPQVbp=imdFKsoLXrAREnzMvhIqxcltNPQVJy
   elif imdFKsoLXrAREnzMvhIqxcltNPQVbg in['tvshow','movie']:
    imdFKsoLXrAREnzMvhIqxcltNPQVbp=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%imdFKsoLXrAREnzMvhIqxcltNPQVbg))
   else:
    return[]
   fp=imdFKsoLXrAREnzMvhIqxcltNPQVkO(imdFKsoLXrAREnzMvhIqxcltNPQVbp,'r',-1,'utf-8')
   imdFKsoLXrAREnzMvhIqxcltNPQVbT=fp.readlines()
   fp.close()
  except:
   imdFKsoLXrAREnzMvhIqxcltNPQVbT=[]
  return imdFKsoLXrAREnzMvhIqxcltNPQVbT
 def Save_Watched_List(imdFKsoLXrAREnzMvhIqxcltNPQVJH,imdFKsoLXrAREnzMvhIqxcltNPQVbg,imdFKsoLXrAREnzMvhIqxcltNPQVJD):
  try:
   imdFKsoLXrAREnzMvhIqxcltNPQVbu=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%imdFKsoLXrAREnzMvhIqxcltNPQVbg))
   imdFKsoLXrAREnzMvhIqxcltNPQVbf=imdFKsoLXrAREnzMvhIqxcltNPQVJH.Load_List_File(imdFKsoLXrAREnzMvhIqxcltNPQVbg) 
   fp=imdFKsoLXrAREnzMvhIqxcltNPQVkO(imdFKsoLXrAREnzMvhIqxcltNPQVbu,'w',-1,'utf-8')
   imdFKsoLXrAREnzMvhIqxcltNPQVyJ=urllib.parse.urlencode(imdFKsoLXrAREnzMvhIqxcltNPQVJD)
   imdFKsoLXrAREnzMvhIqxcltNPQVyJ=imdFKsoLXrAREnzMvhIqxcltNPQVyJ+'\n'
   fp.write(imdFKsoLXrAREnzMvhIqxcltNPQVyJ)
   imdFKsoLXrAREnzMvhIqxcltNPQVyS=0
   for imdFKsoLXrAREnzMvhIqxcltNPQVyj in imdFKsoLXrAREnzMvhIqxcltNPQVbf:
    imdFKsoLXrAREnzMvhIqxcltNPQVyB=imdFKsoLXrAREnzMvhIqxcltNPQVkG(urllib.parse.parse_qsl(imdFKsoLXrAREnzMvhIqxcltNPQVyj))
    imdFKsoLXrAREnzMvhIqxcltNPQVyb=imdFKsoLXrAREnzMvhIqxcltNPQVJD.get('code').strip()
    imdFKsoLXrAREnzMvhIqxcltNPQVyH=imdFKsoLXrAREnzMvhIqxcltNPQVyB.get('code').strip()
    if imdFKsoLXrAREnzMvhIqxcltNPQVyb!=imdFKsoLXrAREnzMvhIqxcltNPQVyH:
     fp.write(imdFKsoLXrAREnzMvhIqxcltNPQVyj)
     imdFKsoLXrAREnzMvhIqxcltNPQVyS+=1
     if imdFKsoLXrAREnzMvhIqxcltNPQVyS>=50:break
   fp.close()
  except:
   imdFKsoLXrAREnzMvhIqxcltNPQVkH
 def Save_Searched_List(imdFKsoLXrAREnzMvhIqxcltNPQVJH,imdFKsoLXrAREnzMvhIqxcltNPQVbw):
  try:
   imdFKsoLXrAREnzMvhIqxcltNPQVbw=imdFKsoLXrAREnzMvhIqxcltNPQVbw.strip()
   imdFKsoLXrAREnzMvhIqxcltNPQVbf=imdFKsoLXrAREnzMvhIqxcltNPQVJH.Load_List_File('search') 
   fp=imdFKsoLXrAREnzMvhIqxcltNPQVkO(imdFKsoLXrAREnzMvhIqxcltNPQVJy,'w',-1,'utf-8')
   fp.write(imdFKsoLXrAREnzMvhIqxcltNPQVbw+'\n')
   imdFKsoLXrAREnzMvhIqxcltNPQVyS=0
   for imdFKsoLXrAREnzMvhIqxcltNPQVyj in imdFKsoLXrAREnzMvhIqxcltNPQVbf:
    imdFKsoLXrAREnzMvhIqxcltNPQVyj=imdFKsoLXrAREnzMvhIqxcltNPQVyj.strip()
    if imdFKsoLXrAREnzMvhIqxcltNPQVbw!=imdFKsoLXrAREnzMvhIqxcltNPQVyj:
     fp.write(imdFKsoLXrAREnzMvhIqxcltNPQVyj+'\n')
     imdFKsoLXrAREnzMvhIqxcltNPQVyS+=1
     if imdFKsoLXrAREnzMvhIqxcltNPQVyS>=50:break
   fp.close()
  except:
   imdFKsoLXrAREnzMvhIqxcltNPQVkH
 def dp_Search_History(imdFKsoLXrAREnzMvhIqxcltNPQVJH,args):
  imdFKsoLXrAREnzMvhIqxcltNPQVyk=imdFKsoLXrAREnzMvhIqxcltNPQVJH.Load_List_File('search')
  for imdFKsoLXrAREnzMvhIqxcltNPQVyU in imdFKsoLXrAREnzMvhIqxcltNPQVyk:
   imdFKsoLXrAREnzMvhIqxcltNPQVyU=imdFKsoLXrAREnzMvhIqxcltNPQVyU.strip()
   imdFKsoLXrAREnzMvhIqxcltNPQVSY={'mode':'LOCAL_SEARCH','search_key':imdFKsoLXrAREnzMvhIqxcltNPQVyU,'page':'1','historyyn':'Y',}
   imdFKsoLXrAREnzMvhIqxcltNPQVyD={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','skey':imdFKsoLXrAREnzMvhIqxcltNPQVyU,'vType':'-',}
   imdFKsoLXrAREnzMvhIqxcltNPQVyY=urllib.parse.urlencode(imdFKsoLXrAREnzMvhIqxcltNPQVyD)
   imdFKsoLXrAREnzMvhIqxcltNPQVBj=[('선택된 검색어 ( %s ) 삭제'%(imdFKsoLXrAREnzMvhIqxcltNPQVyU),'RunPlugin(plugin://plugin.video.coupangm/?%s)'%(imdFKsoLXrAREnzMvhIqxcltNPQVyY))]
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.add_dir(imdFKsoLXrAREnzMvhIqxcltNPQVyU,sublabel='',img=imdFKsoLXrAREnzMvhIqxcltNPQVkH,infoLabels=imdFKsoLXrAREnzMvhIqxcltNPQVkH,isFolder=imdFKsoLXrAREnzMvhIqxcltNPQVkD,params=imdFKsoLXrAREnzMvhIqxcltNPQVSY,ContextMenu=imdFKsoLXrAREnzMvhIqxcltNPQVBj)
  imdFKsoLXrAREnzMvhIqxcltNPQVjy={'plot':'검색목록 전체를 삭제합니다.'}
  imdFKsoLXrAREnzMvhIqxcltNPQVSb='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  imdFKsoLXrAREnzMvhIqxcltNPQVSY={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  imdFKsoLXrAREnzMvhIqxcltNPQVSD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  imdFKsoLXrAREnzMvhIqxcltNPQVJH.add_dir(imdFKsoLXrAREnzMvhIqxcltNPQVSb,sublabel='',img=imdFKsoLXrAREnzMvhIqxcltNPQVSD,infoLabels=imdFKsoLXrAREnzMvhIqxcltNPQVjy,isFolder=imdFKsoLXrAREnzMvhIqxcltNPQVkU,params=imdFKsoLXrAREnzMvhIqxcltNPQVSY,isLink=imdFKsoLXrAREnzMvhIqxcltNPQVkD)
  xbmcplugin.endOfDirectory(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,cacheToDisc=imdFKsoLXrAREnzMvhIqxcltNPQVkU)
 def dp_Listfile_Delete(imdFKsoLXrAREnzMvhIqxcltNPQVJH,args):
  imdFKsoLXrAREnzMvhIqxcltNPQVyG=args.get('delType')
  imdFKsoLXrAREnzMvhIqxcltNPQVyC =args.get('skey')
  imdFKsoLXrAREnzMvhIqxcltNPQVjJ =args.get('vType')
  imdFKsoLXrAREnzMvhIqxcltNPQVJG=xbmcgui.Dialog()
  if imdFKsoLXrAREnzMvhIqxcltNPQVyG=='SEARCH_ALL':
   imdFKsoLXrAREnzMvhIqxcltNPQVSO=imdFKsoLXrAREnzMvhIqxcltNPQVJG.yesno(__language__(30911).encode('utf8'),__language__(30906).encode('utf8'))
  elif imdFKsoLXrAREnzMvhIqxcltNPQVyG=='SEARCH_ONE':
   imdFKsoLXrAREnzMvhIqxcltNPQVSO=imdFKsoLXrAREnzMvhIqxcltNPQVJG.yesno(__language__(30912).encode('utf8'),__language__(30906).encode('utf8'))
  elif imdFKsoLXrAREnzMvhIqxcltNPQVyG=='WATCH_ALL':
   imdFKsoLXrAREnzMvhIqxcltNPQVSO=imdFKsoLXrAREnzMvhIqxcltNPQVJG.yesno(__language__(30913).encode('utf8'),__language__(30906).encode('utf8'))
  elif imdFKsoLXrAREnzMvhIqxcltNPQVyG=='WATCH_ONE':
   imdFKsoLXrAREnzMvhIqxcltNPQVSO=imdFKsoLXrAREnzMvhIqxcltNPQVJG.yesno(__language__(30916).encode('utf8'),__language__(30906).encode('utf8'))
  if imdFKsoLXrAREnzMvhIqxcltNPQVSO==imdFKsoLXrAREnzMvhIqxcltNPQVkU:sys.exit()
  if imdFKsoLXrAREnzMvhIqxcltNPQVyG=='SEARCH_ALL':
   if os.path.isfile(imdFKsoLXrAREnzMvhIqxcltNPQVJy):os.remove(imdFKsoLXrAREnzMvhIqxcltNPQVJy)
  elif imdFKsoLXrAREnzMvhIqxcltNPQVyG=='SEARCH_ONE':
   try:
    imdFKsoLXrAREnzMvhIqxcltNPQVbp=imdFKsoLXrAREnzMvhIqxcltNPQVJy
    imdFKsoLXrAREnzMvhIqxcltNPQVbf=imdFKsoLXrAREnzMvhIqxcltNPQVJH.Load_List_File('search') 
    fp=imdFKsoLXrAREnzMvhIqxcltNPQVkO(imdFKsoLXrAREnzMvhIqxcltNPQVbp,'w',-1,'utf-8')
    for imdFKsoLXrAREnzMvhIqxcltNPQVyj in imdFKsoLXrAREnzMvhIqxcltNPQVbf:
     if imdFKsoLXrAREnzMvhIqxcltNPQVyC!=imdFKsoLXrAREnzMvhIqxcltNPQVyj.strip():
      fp.write(imdFKsoLXrAREnzMvhIqxcltNPQVyj)
    fp.close()
   except:
    imdFKsoLXrAREnzMvhIqxcltNPQVkH
  elif imdFKsoLXrAREnzMvhIqxcltNPQVyG=='WATCH_ALL':
   imdFKsoLXrAREnzMvhIqxcltNPQVbp=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%imdFKsoLXrAREnzMvhIqxcltNPQVjJ))
   if os.path.isfile(imdFKsoLXrAREnzMvhIqxcltNPQVbp):os.remove(imdFKsoLXrAREnzMvhIqxcltNPQVbp)
  elif imdFKsoLXrAREnzMvhIqxcltNPQVyG=='WATCH_ONE':
   imdFKsoLXrAREnzMvhIqxcltNPQVbp=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%imdFKsoLXrAREnzMvhIqxcltNPQVjJ))
   try:
    imdFKsoLXrAREnzMvhIqxcltNPQVbf=imdFKsoLXrAREnzMvhIqxcltNPQVJH.Load_List_File(imdFKsoLXrAREnzMvhIqxcltNPQVjJ) 
    fp=imdFKsoLXrAREnzMvhIqxcltNPQVkO(imdFKsoLXrAREnzMvhIqxcltNPQVbp,'w',-1,'utf-8')
    for imdFKsoLXrAREnzMvhIqxcltNPQVyj in imdFKsoLXrAREnzMvhIqxcltNPQVbf:
     imdFKsoLXrAREnzMvhIqxcltNPQVyB=imdFKsoLXrAREnzMvhIqxcltNPQVkG(urllib.parse.parse_qsl(imdFKsoLXrAREnzMvhIqxcltNPQVyj))
     imdFKsoLXrAREnzMvhIqxcltNPQVya=imdFKsoLXrAREnzMvhIqxcltNPQVyB.get('code').strip()
     if imdFKsoLXrAREnzMvhIqxcltNPQVyC!=imdFKsoLXrAREnzMvhIqxcltNPQVya:
      fp.write(imdFKsoLXrAREnzMvhIqxcltNPQVyj)
    fp.close()
   except:
    imdFKsoLXrAREnzMvhIqxcltNPQVkH
  xbmc.executebuiltin("Container.Refresh")
 def Delete_List_File(imdFKsoLXrAREnzMvhIqxcltNPQVJH,imdFKsoLXrAREnzMvhIqxcltNPQVbg,skey='-'):
  if imdFKsoLXrAREnzMvhIqxcltNPQVbg=='ALL':
   try:
    imdFKsoLXrAREnzMvhIqxcltNPQVbp=imdFKsoLXrAREnzMvhIqxcltNPQVJy
    fp=imdFKsoLXrAREnzMvhIqxcltNPQVkO(imdFKsoLXrAREnzMvhIqxcltNPQVbp,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    imdFKsoLXrAREnzMvhIqxcltNPQVkH
  elif imdFKsoLXrAREnzMvhIqxcltNPQVbg=='ONE':
   try:
    imdFKsoLXrAREnzMvhIqxcltNPQVbp=imdFKsoLXrAREnzMvhIqxcltNPQVJy
    imdFKsoLXrAREnzMvhIqxcltNPQVbf=imdFKsoLXrAREnzMvhIqxcltNPQVJH.Load_List_File('search') 
    fp=imdFKsoLXrAREnzMvhIqxcltNPQVkO(imdFKsoLXrAREnzMvhIqxcltNPQVbp,'w',-1,'utf-8')
    for imdFKsoLXrAREnzMvhIqxcltNPQVyj in imdFKsoLXrAREnzMvhIqxcltNPQVbf:
     if skey!=imdFKsoLXrAREnzMvhIqxcltNPQVyj.strip():
      fp.write(imdFKsoLXrAREnzMvhIqxcltNPQVyj)
    fp.close()
   except:
    imdFKsoLXrAREnzMvhIqxcltNPQVkH
  elif imdFKsoLXrAREnzMvhIqxcltNPQVbg in['tvshow','movie']:
   try:
    imdFKsoLXrAREnzMvhIqxcltNPQVbp=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%imdFKsoLXrAREnzMvhIqxcltNPQVbg))
    fp=imdFKsoLXrAREnzMvhIqxcltNPQVkO(imdFKsoLXrAREnzMvhIqxcltNPQVbp,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    imdFKsoLXrAREnzMvhIqxcltNPQVkH
 def dp_Watch_List(imdFKsoLXrAREnzMvhIqxcltNPQVJH,args):
  imdFKsoLXrAREnzMvhIqxcltNPQVbg =args.get('stype')
  if imdFKsoLXrAREnzMvhIqxcltNPQVbg in['',imdFKsoLXrAREnzMvhIqxcltNPQVkH]:
   for imdFKsoLXrAREnzMvhIqxcltNPQVyg in imdFKsoLXrAREnzMvhIqxcltNPQVJB:
    imdFKsoLXrAREnzMvhIqxcltNPQVSb=imdFKsoLXrAREnzMvhIqxcltNPQVyg.get('title')
    imdFKsoLXrAREnzMvhIqxcltNPQVSY={'mode':imdFKsoLXrAREnzMvhIqxcltNPQVyg.get('mode'),'stype':imdFKsoLXrAREnzMvhIqxcltNPQVyg.get('stype'),}
    imdFKsoLXrAREnzMvhIqxcltNPQVJH.add_dir(imdFKsoLXrAREnzMvhIqxcltNPQVSb,sublabel='',img='',infoLabels=imdFKsoLXrAREnzMvhIqxcltNPQVkH,isFolder=imdFKsoLXrAREnzMvhIqxcltNPQVkD,params=imdFKsoLXrAREnzMvhIqxcltNPQVSY)
   xbmcplugin.endOfDirectory(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle)
  else:
   imdFKsoLXrAREnzMvhIqxcltNPQVyO=imdFKsoLXrAREnzMvhIqxcltNPQVJH.Load_List_File(imdFKsoLXrAREnzMvhIqxcltNPQVbg)
   for imdFKsoLXrAREnzMvhIqxcltNPQVyw in imdFKsoLXrAREnzMvhIqxcltNPQVyO:
    imdFKsoLXrAREnzMvhIqxcltNPQVyW=imdFKsoLXrAREnzMvhIqxcltNPQVkG(urllib.parse.parse_qsl(imdFKsoLXrAREnzMvhIqxcltNPQVyw))
    imdFKsoLXrAREnzMvhIqxcltNPQVBe =imdFKsoLXrAREnzMvhIqxcltNPQVyW.get('code').strip()
    imdFKsoLXrAREnzMvhIqxcltNPQVSb =imdFKsoLXrAREnzMvhIqxcltNPQVyW.get('title').strip()
    imdFKsoLXrAREnzMvhIqxcltNPQVjU =imdFKsoLXrAREnzMvhIqxcltNPQVyW.get('img').strip()
    imdFKsoLXrAREnzMvhIqxcltNPQVjD =imdFKsoLXrAREnzMvhIqxcltNPQVyW.get('asis').strip()
    try:
     imdFKsoLXrAREnzMvhIqxcltNPQVjU=imdFKsoLXrAREnzMvhIqxcltNPQVjU.replace('\'','\"')
     imdFKsoLXrAREnzMvhIqxcltNPQVjU=json.loads(imdFKsoLXrAREnzMvhIqxcltNPQVjU)
    except:
     imdFKsoLXrAREnzMvhIqxcltNPQVkH
    imdFKsoLXrAREnzMvhIqxcltNPQVjy={}
    imdFKsoLXrAREnzMvhIqxcltNPQVjy['plot']=imdFKsoLXrAREnzMvhIqxcltNPQVSb
    if imdFKsoLXrAREnzMvhIqxcltNPQVbg=='movie':
     imdFKsoLXrAREnzMvhIqxcltNPQVjy['mediatype']='movie'
     imdFKsoLXrAREnzMvhIqxcltNPQVSY={'mode':'MOVIE','id':imdFKsoLXrAREnzMvhIqxcltNPQVBe,'asis':imdFKsoLXrAREnzMvhIqxcltNPQVjD,'title':imdFKsoLXrAREnzMvhIqxcltNPQVSb,'thumbnail':imdFKsoLXrAREnzMvhIqxcltNPQVjU,}
     imdFKsoLXrAREnzMvhIqxcltNPQVSG=imdFKsoLXrAREnzMvhIqxcltNPQVkU
    else:
     imdFKsoLXrAREnzMvhIqxcltNPQVjy['mediatype']='episode'
     imdFKsoLXrAREnzMvhIqxcltNPQVSY={'mode':'SEASON_LIST','id':imdFKsoLXrAREnzMvhIqxcltNPQVBe,'asis':imdFKsoLXrAREnzMvhIqxcltNPQVjD,'title':imdFKsoLXrAREnzMvhIqxcltNPQVSb,'thumbnail':json.dumps(imdFKsoLXrAREnzMvhIqxcltNPQVjU,separators=(',',':')),}
     imdFKsoLXrAREnzMvhIqxcltNPQVSG=imdFKsoLXrAREnzMvhIqxcltNPQVkD
    imdFKsoLXrAREnzMvhIqxcltNPQVyD={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','skey':imdFKsoLXrAREnzMvhIqxcltNPQVBe,'vType':imdFKsoLXrAREnzMvhIqxcltNPQVbg,}
    imdFKsoLXrAREnzMvhIqxcltNPQVyY=urllib.parse.urlencode(imdFKsoLXrAREnzMvhIqxcltNPQVyD)
    imdFKsoLXrAREnzMvhIqxcltNPQVBj=[('선택된 시청이력 ( %s ) 삭제'%(imdFKsoLXrAREnzMvhIqxcltNPQVSb),'RunPlugin(plugin://plugin.video.coupangm/?%s)'%(imdFKsoLXrAREnzMvhIqxcltNPQVyY))]
    imdFKsoLXrAREnzMvhIqxcltNPQVJH.add_dir(imdFKsoLXrAREnzMvhIqxcltNPQVSb,sublabel='',img=imdFKsoLXrAREnzMvhIqxcltNPQVjU,infoLabels=imdFKsoLXrAREnzMvhIqxcltNPQVjy,isFolder=imdFKsoLXrAREnzMvhIqxcltNPQVSG,params=imdFKsoLXrAREnzMvhIqxcltNPQVSY,ContextMenu=imdFKsoLXrAREnzMvhIqxcltNPQVBj)
   imdFKsoLXrAREnzMvhIqxcltNPQVjy={'plot':'시청목록을 삭제합니다.'}
   imdFKsoLXrAREnzMvhIqxcltNPQVSb='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   imdFKsoLXrAREnzMvhIqxcltNPQVSY={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':imdFKsoLXrAREnzMvhIqxcltNPQVbg,}
   imdFKsoLXrAREnzMvhIqxcltNPQVSD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.add_dir(imdFKsoLXrAREnzMvhIqxcltNPQVSb,sublabel='',img=imdFKsoLXrAREnzMvhIqxcltNPQVSD,infoLabels=imdFKsoLXrAREnzMvhIqxcltNPQVjy,isFolder=imdFKsoLXrAREnzMvhIqxcltNPQVkU,params=imdFKsoLXrAREnzMvhIqxcltNPQVSY,isLink=imdFKsoLXrAREnzMvhIqxcltNPQVkD)
   if imdFKsoLXrAREnzMvhIqxcltNPQVbg=='movie':xbmcplugin.setContent(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,'movies')
   else:xbmcplugin.setContent(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,cacheToDisc=imdFKsoLXrAREnzMvhIqxcltNPQVkU)
 def dp_Set_Bookmark(imdFKsoLXrAREnzMvhIqxcltNPQVJH,args):
  imdFKsoLXrAREnzMvhIqxcltNPQVye=urllib.parse.unquote(args.get('bm_param'))
  imdFKsoLXrAREnzMvhIqxcltNPQVye=json.loads(imdFKsoLXrAREnzMvhIqxcltNPQVye)
  imdFKsoLXrAREnzMvhIqxcltNPQVyp =imdFKsoLXrAREnzMvhIqxcltNPQVye.get('videoid')
  imdFKsoLXrAREnzMvhIqxcltNPQVyT =imdFKsoLXrAREnzMvhIqxcltNPQVye.get('vidtype')
  imdFKsoLXrAREnzMvhIqxcltNPQVyu =imdFKsoLXrAREnzMvhIqxcltNPQVye.get('vtitle')
  imdFKsoLXrAREnzMvhIqxcltNPQVJG=xbmcgui.Dialog()
  imdFKsoLXrAREnzMvhIqxcltNPQVSO=imdFKsoLXrAREnzMvhIqxcltNPQVJG.yesno(__language__(30914).encode('utf8'),imdFKsoLXrAREnzMvhIqxcltNPQVyu+' \n\n'+__language__(30915))
  if imdFKsoLXrAREnzMvhIqxcltNPQVSO==imdFKsoLXrAREnzMvhIqxcltNPQVkU:return
  imdFKsoLXrAREnzMvhIqxcltNPQVyf=imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.GetBookmarkInfo(imdFKsoLXrAREnzMvhIqxcltNPQVyp,imdFKsoLXrAREnzMvhIqxcltNPQVyT)
  imdFKsoLXrAREnzMvhIqxcltNPQVHJ=json.dumps(imdFKsoLXrAREnzMvhIqxcltNPQVyf)
  imdFKsoLXrAREnzMvhIqxcltNPQVHJ=urllib.parse.quote(imdFKsoLXrAREnzMvhIqxcltNPQVHJ)
  imdFKsoLXrAREnzMvhIqxcltNPQVBS ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(imdFKsoLXrAREnzMvhIqxcltNPQVHJ)
  xbmc.executebuiltin(imdFKsoLXrAREnzMvhIqxcltNPQVBS)
 def sp_MultiHero_LiveList(imdFKsoLXrAREnzMvhIqxcltNPQVJH,args):
  imdFKsoLXrAREnzMvhIqxcltNPQVHS=imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.Sports_MultiHero_LiveList()
  for imdFKsoLXrAREnzMvhIqxcltNPQVHj in imdFKsoLXrAREnzMvhIqxcltNPQVHS:
   imdFKsoLXrAREnzMvhIqxcltNPQVke =imdFKsoLXrAREnzMvhIqxcltNPQVHj.get('id')
   imdFKsoLXrAREnzMvhIqxcltNPQVSb =imdFKsoLXrAREnzMvhIqxcltNPQVHj.get('title')
   imdFKsoLXrAREnzMvhIqxcltNPQVHB =imdFKsoLXrAREnzMvhIqxcltNPQVHj.get('startDate')
   imdFKsoLXrAREnzMvhIqxcltNPQVHb =imdFKsoLXrAREnzMvhIqxcltNPQVHj.get('image')
   imdFKsoLXrAREnzMvhIqxcltNPQVHy =imdFKsoLXrAREnzMvhIqxcltNPQVHj.get('subType') 
   imdFKsoLXrAREnzMvhIqxcltNPQVSg=imdFKsoLXrAREnzMvhIqxcltNPQVHB
   if imdFKsoLXrAREnzMvhIqxcltNPQVHy:imdFKsoLXrAREnzMvhIqxcltNPQVSg=imdFKsoLXrAREnzMvhIqxcltNPQVSg+', '+imdFKsoLXrAREnzMvhIqxcltNPQVHy
   imdFKsoLXrAREnzMvhIqxcltNPQVjy={'mediatype':'episodes','plot':imdFKsoLXrAREnzMvhIqxcltNPQVSb,}
   imdFKsoLXrAREnzMvhIqxcltNPQVSY={'mode':'LIVE','asis':'LIVE','id':imdFKsoLXrAREnzMvhIqxcltNPQVke,}
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.add_dir(imdFKsoLXrAREnzMvhIqxcltNPQVSb,sublabel=imdFKsoLXrAREnzMvhIqxcltNPQVSg,img=imdFKsoLXrAREnzMvhIqxcltNPQVHb,infoLabels=imdFKsoLXrAREnzMvhIqxcltNPQVjy,isFolder=imdFKsoLXrAREnzMvhIqxcltNPQVkU,params=imdFKsoLXrAREnzMvhIqxcltNPQVSY)
  xbmcplugin.setContent(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,cacheToDisc=imdFKsoLXrAREnzMvhIqxcltNPQVkU)
 def sp_Mainlist_League(imdFKsoLXrAREnzMvhIqxcltNPQVJH,args):
  imdFKsoLXrAREnzMvhIqxcltNPQVHS=imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.Sports_MultiHero_LiveList()
  if imdFKsoLXrAREnzMvhIqxcltNPQVHS:
   imdFKsoLXrAREnzMvhIqxcltNPQVSb ='@ 주요 예정경기 @'
   imdFKsoLXrAREnzMvhIqxcltNPQVHb =imdFKsoLXrAREnzMvhIqxcltNPQVHS[0]['image']
   imdFKsoLXrAREnzMvhIqxcltNPQVHk =imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.MakeText_FreeList(imdFKsoLXrAREnzMvhIqxcltNPQVHS,titleName='preTitle')
   imdFKsoLXrAREnzMvhIqxcltNPQVjy={'mediatype':'episodes','plot':imdFKsoLXrAREnzMvhIqxcltNPQVHk,}
   imdFKsoLXrAREnzMvhIqxcltNPQVSY={'mode':'SPORTS_MULT_HERO',}
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.add_dir(imdFKsoLXrAREnzMvhIqxcltNPQVSb,sublabel='',img=imdFKsoLXrAREnzMvhIqxcltNPQVHb,infoLabels=imdFKsoLXrAREnzMvhIqxcltNPQVjy,isFolder=imdFKsoLXrAREnzMvhIqxcltNPQVkD,params=imdFKsoLXrAREnzMvhIqxcltNPQVSY)
  imdFKsoLXrAREnzMvhIqxcltNPQVHU=imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.Sports_Mainlist_League()
  for imdFKsoLXrAREnzMvhIqxcltNPQVHD in imdFKsoLXrAREnzMvhIqxcltNPQVHU:
   imdFKsoLXrAREnzMvhIqxcltNPQVHY =imdFKsoLXrAREnzMvhIqxcltNPQVHD.get('league_id') 
   imdFKsoLXrAREnzMvhIqxcltNPQVHG=imdFKsoLXrAREnzMvhIqxcltNPQVHD.get('league_name')
   imdFKsoLXrAREnzMvhIqxcltNPQVHC =imdFKsoLXrAREnzMvhIqxcltNPQVHD.get('logoUrl')
   imdFKsoLXrAREnzMvhIqxcltNPQVjy={'mediatype':'episodes','plot':imdFKsoLXrAREnzMvhIqxcltNPQVHG,}
   imdFKsoLXrAREnzMvhIqxcltNPQVSY={'mode':'SPORTS_LEAGUE_FEEDLIST','league_id':imdFKsoLXrAREnzMvhIqxcltNPQVHY,'league_name':imdFKsoLXrAREnzMvhIqxcltNPQVHG,}
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.add_dir(imdFKsoLXrAREnzMvhIqxcltNPQVHG,sublabel='',img=imdFKsoLXrAREnzMvhIqxcltNPQVHC,infoLabels=imdFKsoLXrAREnzMvhIqxcltNPQVjy,isFolder=imdFKsoLXrAREnzMvhIqxcltNPQVkD,params=imdFKsoLXrAREnzMvhIqxcltNPQVSY)
  xbmcplugin.setContent(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,cacheToDisc=imdFKsoLXrAREnzMvhIqxcltNPQVkU)
 def sp_League_FeedList(imdFKsoLXrAREnzMvhIqxcltNPQVJH,args):
  imdFKsoLXrAREnzMvhIqxcltNPQVHY =args.get('league_id')
  imdFKsoLXrAREnzMvhIqxcltNPQVHG=args.get('league_name')
  imdFKsoLXrAREnzMvhIqxcltNPQVHa=imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.Sports_League_FeedList(imdFKsoLXrAREnzMvhIqxcltNPQVHY)
  for imdFKsoLXrAREnzMvhIqxcltNPQVHD in imdFKsoLXrAREnzMvhIqxcltNPQVHa:
   imdFKsoLXrAREnzMvhIqxcltNPQVHg=imdFKsoLXrAREnzMvhIqxcltNPQVHD.get('row_name')
   imdFKsoLXrAREnzMvhIqxcltNPQVHk =imdFKsoLXrAREnzMvhIqxcltNPQVHD.get('preText')
   imdFKsoLXrAREnzMvhIqxcltNPQVHO =imdFKsoLXrAREnzMvhIqxcltNPQVHD.get('subMode')
   imdFKsoLXrAREnzMvhIqxcltNPQVHw =imdFKsoLXrAREnzMvhIqxcltNPQVHD.get('gameID')
   imdFKsoLXrAREnzMvhIqxcltNPQVHb =imdFKsoLXrAREnzMvhIqxcltNPQVHD.get('image')
   imdFKsoLXrAREnzMvhIqxcltNPQVjy={'mediatype':'episodes','plot':imdFKsoLXrAREnzMvhIqxcltNPQVHG+'\n\n'+imdFKsoLXrAREnzMvhIqxcltNPQVHk,}
   imdFKsoLXrAREnzMvhIqxcltNPQVSY={'mode':'SPORTS_FEED_VOD','subMode':imdFKsoLXrAREnzMvhIqxcltNPQVHO,'league_id':imdFKsoLXrAREnzMvhIqxcltNPQVHY,'game_id':imdFKsoLXrAREnzMvhIqxcltNPQVHw,}
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.add_dir(imdFKsoLXrAREnzMvhIqxcltNPQVHg,sublabel='',img=imdFKsoLXrAREnzMvhIqxcltNPQVHb,infoLabels=imdFKsoLXrAREnzMvhIqxcltNPQVjy,isFolder=imdFKsoLXrAREnzMvhIqxcltNPQVkD,params=imdFKsoLXrAREnzMvhIqxcltNPQVSY)
  imdFKsoLXrAREnzMvhIqxcltNPQVSb='@ 시즌별 동영상 @'
  imdFKsoLXrAREnzMvhIqxcltNPQVjy={'mediatype':'episodes','plot':imdFKsoLXrAREnzMvhIqxcltNPQVSb,}
  imdFKsoLXrAREnzMvhIqxcltNPQVSY={'mode':'SPORTS_SEASON_GROUP','league_id':imdFKsoLXrAREnzMvhIqxcltNPQVHY,}
  imdFKsoLXrAREnzMvhIqxcltNPQVJH.add_dir(imdFKsoLXrAREnzMvhIqxcltNPQVSb,sublabel='',img=imdFKsoLXrAREnzMvhIqxcltNPQVkH,infoLabels=imdFKsoLXrAREnzMvhIqxcltNPQVjy,isFolder=imdFKsoLXrAREnzMvhIqxcltNPQVkD,params=imdFKsoLXrAREnzMvhIqxcltNPQVSY)
  xbmcplugin.setContent(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,cacheToDisc=imdFKsoLXrAREnzMvhIqxcltNPQVkU)
 def sp_League_VodList(imdFKsoLXrAREnzMvhIqxcltNPQVJH,args):
  imdFKsoLXrAREnzMvhIqxcltNPQVHO =args.get('subMode')
  imdFKsoLXrAREnzMvhIqxcltNPQVHY =args.get('league_id')
  imdFKsoLXrAREnzMvhIqxcltNPQVHW =args.get('game_id')
  imdFKsoLXrAREnzMvhIqxcltNPQVJH.addon_log('{} - {}'.format('subMode  ',imdFKsoLXrAREnzMvhIqxcltNPQVHO))
  imdFKsoLXrAREnzMvhIqxcltNPQVJH.addon_log('{} - {}'.format('league_id',imdFKsoLXrAREnzMvhIqxcltNPQVHY))
  imdFKsoLXrAREnzMvhIqxcltNPQVJH.addon_log('{} - {}'.format('game_id  ',imdFKsoLXrAREnzMvhIqxcltNPQVHW))
  imdFKsoLXrAREnzMvhIqxcltNPQVHe=imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.Sports_League_VodList(imdFKsoLXrAREnzMvhIqxcltNPQVHO,imdFKsoLXrAREnzMvhIqxcltNPQVHY,imdFKsoLXrAREnzMvhIqxcltNPQVHW)
  for imdFKsoLXrAREnzMvhIqxcltNPQVHD in imdFKsoLXrAREnzMvhIqxcltNPQVHe:
   imdFKsoLXrAREnzMvhIqxcltNPQVke =imdFKsoLXrAREnzMvhIqxcltNPQVHD.get('id')
   imdFKsoLXrAREnzMvhIqxcltNPQVSb =imdFKsoLXrAREnzMvhIqxcltNPQVHD.get('title')
   imdFKsoLXrAREnzMvhIqxcltNPQVHb =imdFKsoLXrAREnzMvhIqxcltNPQVHD.get('image')
   imdFKsoLXrAREnzMvhIqxcltNPQVHB =imdFKsoLXrAREnzMvhIqxcltNPQVHD.get('startDate')
   imdFKsoLXrAREnzMvhIqxcltNPQVHy =imdFKsoLXrAREnzMvhIqxcltNPQVHD.get('subType')
   imdFKsoLXrAREnzMvhIqxcltNPQVHp=imdFKsoLXrAREnzMvhIqxcltNPQVHD.get('running_time')
   imdFKsoLXrAREnzMvhIqxcltNPQVjy={'mediatype':'episodes','plot':imdFKsoLXrAREnzMvhIqxcltNPQVSb,'duration':imdFKsoLXrAREnzMvhIqxcltNPQVHp,}
   if imdFKsoLXrAREnzMvhIqxcltNPQVHO=='SP_FEED_LIVE':
    imdFKsoLXrAREnzMvhIqxcltNPQVSY={'mode':'LIVE','asis':'LIVE','id':imdFKsoLXrAREnzMvhIqxcltNPQVke,}
    imdFKsoLXrAREnzMvhIqxcltNPQVSg=imdFKsoLXrAREnzMvhIqxcltNPQVHB
    if imdFKsoLXrAREnzMvhIqxcltNPQVHy:imdFKsoLXrAREnzMvhIqxcltNPQVSg=imdFKsoLXrAREnzMvhIqxcltNPQVSg+', '+imdFKsoLXrAREnzMvhIqxcltNPQVHy
   elif imdFKsoLXrAREnzMvhIqxcltNPQVHO in['SP_FEED_TOP10','SP_FEED_GAME']:
    imdFKsoLXrAREnzMvhIqxcltNPQVSY={'mode':'HIGHLIGHT','asis':'HIGHLIGHT','id':imdFKsoLXrAREnzMvhIqxcltNPQVke,}
    imdFKsoLXrAREnzMvhIqxcltNPQVSg=imdFKsoLXrAREnzMvhIqxcltNPQVHy
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.add_dir(imdFKsoLXrAREnzMvhIqxcltNPQVSb,sublabel=imdFKsoLXrAREnzMvhIqxcltNPQVSg,img=imdFKsoLXrAREnzMvhIqxcltNPQVHb,infoLabels=imdFKsoLXrAREnzMvhIqxcltNPQVjy,isFolder=imdFKsoLXrAREnzMvhIqxcltNPQVkU,params=imdFKsoLXrAREnzMvhIqxcltNPQVSY)
  xbmcplugin.setContent(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,cacheToDisc=imdFKsoLXrAREnzMvhIqxcltNPQVkU)
 def sp_Season_Group(imdFKsoLXrAREnzMvhIqxcltNPQVJH,args):
  imdFKsoLXrAREnzMvhIqxcltNPQVHY =args.get('league_id')
  imdFKsoLXrAREnzMvhIqxcltNPQVHT=imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.Sports_Season_Group(imdFKsoLXrAREnzMvhIqxcltNPQVHY)
  for imdFKsoLXrAREnzMvhIqxcltNPQVHD in imdFKsoLXrAREnzMvhIqxcltNPQVHT:
   imdFKsoLXrAREnzMvhIqxcltNPQVBY =imdFKsoLXrAREnzMvhIqxcltNPQVHD.get('season')
   imdFKsoLXrAREnzMvhIqxcltNPQVHk =imdFKsoLXrAREnzMvhIqxcltNPQVHD.get('preText')
   imdFKsoLXrAREnzMvhIqxcltNPQVjy={'mediatype':'episodes','plot':imdFKsoLXrAREnzMvhIqxcltNPQVHk,}
   imdFKsoLXrAREnzMvhIqxcltNPQVSY={'mode':'SPORTS_SEASON_GAMELIST','leagueID':imdFKsoLXrAREnzMvhIqxcltNPQVHY,'seasonID':imdFKsoLXrAREnzMvhIqxcltNPQVBY,'page':'1',}
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.add_dir(imdFKsoLXrAREnzMvhIqxcltNPQVBY,sublabel=imdFKsoLXrAREnzMvhIqxcltNPQVkH,img=imdFKsoLXrAREnzMvhIqxcltNPQVkH,infoLabels=imdFKsoLXrAREnzMvhIqxcltNPQVjy,isFolder=imdFKsoLXrAREnzMvhIqxcltNPQVkD,params=imdFKsoLXrAREnzMvhIqxcltNPQVSY)
  xbmcplugin.setContent(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,cacheToDisc=imdFKsoLXrAREnzMvhIqxcltNPQVkU)
 def sp_Season_GameList(imdFKsoLXrAREnzMvhIqxcltNPQVJH,args):
  imdFKsoLXrAREnzMvhIqxcltNPQVHu =args.get('leagueID')
  imdFKsoLXrAREnzMvhIqxcltNPQVHf =args.get('seasonID')
  imdFKsoLXrAREnzMvhIqxcltNPQVjg =imdFKsoLXrAREnzMvhIqxcltNPQVka(args.get('page'))
  imdFKsoLXrAREnzMvhIqxcltNPQVkJ=imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.Sports_Season_GameList(imdFKsoLXrAREnzMvhIqxcltNPQVHu,imdFKsoLXrAREnzMvhIqxcltNPQVHf,imdFKsoLXrAREnzMvhIqxcltNPQVjg)
  imdFKsoLXrAREnzMvhIqxcltNPQVkS=imdFKsoLXrAREnzMvhIqxcltNPQVkp(imdFKsoLXrAREnzMvhIqxcltNPQVkJ)
  for imdFKsoLXrAREnzMvhIqxcltNPQVHD in imdFKsoLXrAREnzMvhIqxcltNPQVkJ:
   imdFKsoLXrAREnzMvhIqxcltNPQVHw =imdFKsoLXrAREnzMvhIqxcltNPQVHD.get('id')
   imdFKsoLXrAREnzMvhIqxcltNPQVSb =imdFKsoLXrAREnzMvhIqxcltNPQVHD.get('title')
   imdFKsoLXrAREnzMvhIqxcltNPQVHB =imdFKsoLXrAREnzMvhIqxcltNPQVHD.get('startDate')
   imdFKsoLXrAREnzMvhIqxcltNPQVHk =imdFKsoLXrAREnzMvhIqxcltNPQVHD.get('preText')
   imdFKsoLXrAREnzMvhIqxcltNPQVHb =imdFKsoLXrAREnzMvhIqxcltNPQVHD.get('image')
   imdFKsoLXrAREnzMvhIqxcltNPQVjy={'mediatype':'episodes','plot':imdFKsoLXrAREnzMvhIqxcltNPQVHk,}
   imdFKsoLXrAREnzMvhIqxcltNPQVSY={'mode':'SPORTS_SEASON_VODLIST','leagueID':imdFKsoLXrAREnzMvhIqxcltNPQVHu,'seasonID':imdFKsoLXrAREnzMvhIqxcltNPQVHf,'gameID':imdFKsoLXrAREnzMvhIqxcltNPQVHw,'page':args.get('page'),}
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.add_dir(imdFKsoLXrAREnzMvhIqxcltNPQVSb,sublabel=imdFKsoLXrAREnzMvhIqxcltNPQVHB,img=imdFKsoLXrAREnzMvhIqxcltNPQVHb,infoLabels=imdFKsoLXrAREnzMvhIqxcltNPQVjy,isFolder=imdFKsoLXrAREnzMvhIqxcltNPQVkD,params=imdFKsoLXrAREnzMvhIqxcltNPQVSY)
  if imdFKsoLXrAREnzMvhIqxcltNPQVkS>=10:
   imdFKsoLXrAREnzMvhIqxcltNPQVSY['mode'] ='SPORTS_SEASON_GAMELIST' 
   imdFKsoLXrAREnzMvhIqxcltNPQVSY['leagueID']=imdFKsoLXrAREnzMvhIqxcltNPQVHu
   imdFKsoLXrAREnzMvhIqxcltNPQVSY['seasonID']=imdFKsoLXrAREnzMvhIqxcltNPQVHf
   imdFKsoLXrAREnzMvhIqxcltNPQVSY['page'] =imdFKsoLXrAREnzMvhIqxcltNPQVkW(imdFKsoLXrAREnzMvhIqxcltNPQVjg+1)
   imdFKsoLXrAREnzMvhIqxcltNPQVSb='[B]%s >>[/B]'%'다음 페이지'
   imdFKsoLXrAREnzMvhIqxcltNPQVBb=imdFKsoLXrAREnzMvhIqxcltNPQVkW(imdFKsoLXrAREnzMvhIqxcltNPQVjg+1)
   imdFKsoLXrAREnzMvhIqxcltNPQVSD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.add_dir(imdFKsoLXrAREnzMvhIqxcltNPQVSb,sublabel=imdFKsoLXrAREnzMvhIqxcltNPQVBb,img=imdFKsoLXrAREnzMvhIqxcltNPQVSD,infoLabels=imdFKsoLXrAREnzMvhIqxcltNPQVkH,isFolder=imdFKsoLXrAREnzMvhIqxcltNPQVkD,params=imdFKsoLXrAREnzMvhIqxcltNPQVSY)
  xbmcplugin.setContent(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,cacheToDisc=imdFKsoLXrAREnzMvhIqxcltNPQVkU)
 def sp_Season_VodList(imdFKsoLXrAREnzMvhIqxcltNPQVJH,args):
  imdFKsoLXrAREnzMvhIqxcltNPQVHu =args.get('leagueID')
  imdFKsoLXrAREnzMvhIqxcltNPQVHf =args.get('seasonID')
  imdFKsoLXrAREnzMvhIqxcltNPQVjg =imdFKsoLXrAREnzMvhIqxcltNPQVka(args.get('page'))
  imdFKsoLXrAREnzMvhIqxcltNPQVHw =args.get('gameID')
  imdFKsoLXrAREnzMvhIqxcltNPQVHe=imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.Sports_Season_GameVod(imdFKsoLXrAREnzMvhIqxcltNPQVHu,imdFKsoLXrAREnzMvhIqxcltNPQVHf,imdFKsoLXrAREnzMvhIqxcltNPQVjg,imdFKsoLXrAREnzMvhIqxcltNPQVHw)
  for imdFKsoLXrAREnzMvhIqxcltNPQVHD in imdFKsoLXrAREnzMvhIqxcltNPQVHe:
   imdFKsoLXrAREnzMvhIqxcltNPQVke =imdFKsoLXrAREnzMvhIqxcltNPQVHD.get('id')
   imdFKsoLXrAREnzMvhIqxcltNPQVSb =imdFKsoLXrAREnzMvhIqxcltNPQVHD.get('title')
   imdFKsoLXrAREnzMvhIqxcltNPQVHb =imdFKsoLXrAREnzMvhIqxcltNPQVHD.get('image')
   imdFKsoLXrAREnzMvhIqxcltNPQVHy =imdFKsoLXrAREnzMvhIqxcltNPQVHD.get('subType')
   imdFKsoLXrAREnzMvhIqxcltNPQVHp=imdFKsoLXrAREnzMvhIqxcltNPQVHD.get('running_time')
   imdFKsoLXrAREnzMvhIqxcltNPQVjy={'mediatype':'episodes','plot':imdFKsoLXrAREnzMvhIqxcltNPQVSb,'duration':imdFKsoLXrAREnzMvhIqxcltNPQVHp,}
   imdFKsoLXrAREnzMvhIqxcltNPQVSY={'mode':'HIGHLIGHT','asis':'HIGHLIGHT','id':imdFKsoLXrAREnzMvhIqxcltNPQVke,}
   imdFKsoLXrAREnzMvhIqxcltNPQVSg=imdFKsoLXrAREnzMvhIqxcltNPQVHy
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.add_dir(imdFKsoLXrAREnzMvhIqxcltNPQVSb,sublabel=imdFKsoLXrAREnzMvhIqxcltNPQVSg,img=imdFKsoLXrAREnzMvhIqxcltNPQVHb,infoLabels=imdFKsoLXrAREnzMvhIqxcltNPQVjy,isFolder=imdFKsoLXrAREnzMvhIqxcltNPQVkU,params=imdFKsoLXrAREnzMvhIqxcltNPQVSY)
  xbmcplugin.setContent(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,cacheToDisc=imdFKsoLXrAREnzMvhIqxcltNPQVkU)
 def dp_Pass_Group(imdFKsoLXrAREnzMvhIqxcltNPQVJH,args):
  imdFKsoLXrAREnzMvhIqxcltNPQVjk =args.get('collectionId')
  imdFKsoLXrAREnzMvhIqxcltNPQVkj=imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.Get_Pass_GroupList(imdFKsoLXrAREnzMvhIqxcltNPQVjk)
  for imdFKsoLXrAREnzMvhIqxcltNPQVHD in imdFKsoLXrAREnzMvhIqxcltNPQVkj:
   imdFKsoLXrAREnzMvhIqxcltNPQVkB =imdFKsoLXrAREnzMvhIqxcltNPQVHD.get('obj_id')
   imdFKsoLXrAREnzMvhIqxcltNPQVSb =imdFKsoLXrAREnzMvhIqxcltNPQVHD.get('title')
   imdFKsoLXrAREnzMvhIqxcltNPQVHk =imdFKsoLXrAREnzMvhIqxcltNPQVHD.get('preText')
   imdFKsoLXrAREnzMvhIqxcltNPQVjy={'mediatype':'episodes','plot':imdFKsoLXrAREnzMvhIqxcltNPQVHk,}
   imdFKsoLXrAREnzMvhIqxcltNPQVSY={'mode':'PASS_VOD_LIST','collectionId':imdFKsoLXrAREnzMvhIqxcltNPQVjk,'obj_id':imdFKsoLXrAREnzMvhIqxcltNPQVkB,}
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.add_dir(imdFKsoLXrAREnzMvhIqxcltNPQVSb,sublabel=imdFKsoLXrAREnzMvhIqxcltNPQVkH,img=imdFKsoLXrAREnzMvhIqxcltNPQVkH,infoLabels=imdFKsoLXrAREnzMvhIqxcltNPQVjy,isFolder=imdFKsoLXrAREnzMvhIqxcltNPQVkD,params=imdFKsoLXrAREnzMvhIqxcltNPQVSY)
  xbmcplugin.setContent(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,cacheToDisc=imdFKsoLXrAREnzMvhIqxcltNPQVkU)
 def dp_Pass_VodList(imdFKsoLXrAREnzMvhIqxcltNPQVJH,args):
  imdFKsoLXrAREnzMvhIqxcltNPQVjk =args.get('collectionId')
  imdFKsoLXrAREnzMvhIqxcltNPQVkB =args.get('obj_id')
  imdFKsoLXrAREnzMvhIqxcltNPQVjS=imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.Get_Pass_VodList(imdFKsoLXrAREnzMvhIqxcltNPQVjk,imdFKsoLXrAREnzMvhIqxcltNPQVkB)
  for imdFKsoLXrAREnzMvhIqxcltNPQVjB in imdFKsoLXrAREnzMvhIqxcltNPQVjS:
   imdFKsoLXrAREnzMvhIqxcltNPQVSb =imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('title')
   imdFKsoLXrAREnzMvhIqxcltNPQVke =imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('id')
   imdFKsoLXrAREnzMvhIqxcltNPQVjU =imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('thumbnail')
   imdFKsoLXrAREnzMvhIqxcltNPQVjw =imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('mpaa')
   imdFKsoLXrAREnzMvhIqxcltNPQVja =imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('duration')
   imdFKsoLXrAREnzMvhIqxcltNPQVkb =imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('sub_type')
   imdFKsoLXrAREnzMvhIqxcltNPQVjW =imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('badge')
   imdFKsoLXrAREnzMvhIqxcltNPQVje =imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('year')
   imdFKsoLXrAREnzMvhIqxcltNPQVjp=imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('seasonList')
   imdFKsoLXrAREnzMvhIqxcltNPQVjT =imdFKsoLXrAREnzMvhIqxcltNPQVjB.get('genreList')
   if imdFKsoLXrAREnzMvhIqxcltNPQVkb in['TVSHOW']: 
    imdFKsoLXrAREnzMvhIqxcltNPQVju ='SEASON_LIST'
    imdFKsoLXrAREnzMvhIqxcltNPQVjy={'mediatype':'tvshow','title':imdFKsoLXrAREnzMvhIqxcltNPQVSb,'mpaa':imdFKsoLXrAREnzMvhIqxcltNPQVjw,'genre':imdFKsoLXrAREnzMvhIqxcltNPQVjT,'year':imdFKsoLXrAREnzMvhIqxcltNPQVje,'plot':'Year : %s\nSeason : %s'%(imdFKsoLXrAREnzMvhIqxcltNPQVje,imdFKsoLXrAREnzMvhIqxcltNPQVjp),}
    imdFKsoLXrAREnzMvhIqxcltNPQVSG =imdFKsoLXrAREnzMvhIqxcltNPQVkD
   else:
    imdFKsoLXrAREnzMvhIqxcltNPQVju ='MOVIE'
    imdFKsoLXrAREnzMvhIqxcltNPQVjy={'mediatype':'movie','title':imdFKsoLXrAREnzMvhIqxcltNPQVSb,'mpaa':imdFKsoLXrAREnzMvhIqxcltNPQVjw,'genre':imdFKsoLXrAREnzMvhIqxcltNPQVjT,'duration':imdFKsoLXrAREnzMvhIqxcltNPQVja,'year':imdFKsoLXrAREnzMvhIqxcltNPQVje,'plot':'(%s)'%(imdFKsoLXrAREnzMvhIqxcltNPQVjw),}
    imdFKsoLXrAREnzMvhIqxcltNPQVSG =imdFKsoLXrAREnzMvhIqxcltNPQVkU
    imdFKsoLXrAREnzMvhIqxcltNPQVSb +=' (%s)'%(imdFKsoLXrAREnzMvhIqxcltNPQVkW(imdFKsoLXrAREnzMvhIqxcltNPQVje))
   imdFKsoLXrAREnzMvhIqxcltNPQVSY={'mode':imdFKsoLXrAREnzMvhIqxcltNPQVju,'id':imdFKsoLXrAREnzMvhIqxcltNPQVke,'asis':imdFKsoLXrAREnzMvhIqxcltNPQVkb,'seasonList':imdFKsoLXrAREnzMvhIqxcltNPQVjp,'title':imdFKsoLXrAREnzMvhIqxcltNPQVSb,'thumbnail':imdFKsoLXrAREnzMvhIqxcltNPQVjU,'year':imdFKsoLXrAREnzMvhIqxcltNPQVje,}
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.add_dir(imdFKsoLXrAREnzMvhIqxcltNPQVSb,sublabel=imdFKsoLXrAREnzMvhIqxcltNPQVjW,img=imdFKsoLXrAREnzMvhIqxcltNPQVjU,infoLabels=imdFKsoLXrAREnzMvhIqxcltNPQVjy,isFolder=imdFKsoLXrAREnzMvhIqxcltNPQVSG,params=imdFKsoLXrAREnzMvhIqxcltNPQVSY,ContextMenu=imdFKsoLXrAREnzMvhIqxcltNPQVkH)
  xbmcplugin.setContent(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(imdFKsoLXrAREnzMvhIqxcltNPQVJH._addon_handle,cacheToDisc=imdFKsoLXrAREnzMvhIqxcltNPQVkU)
 def dp_setEpOrderby(imdFKsoLXrAREnzMvhIqxcltNPQVJH,args):
  imdFKsoLXrAREnzMvhIqxcltNPQVSj =args.get('orderby')
  imdFKsoLXrAREnzMvhIqxcltNPQVJH.set_winEpisodeOrderby(imdFKsoLXrAREnzMvhIqxcltNPQVSj)
  xbmc.executebuiltin("Container.Refresh")
 def coupang_main(imdFKsoLXrAREnzMvhIqxcltNPQVJH):
  imdFKsoLXrAREnzMvhIqxcltNPQVJH.CoupangObj.KodiVersion=imdFKsoLXrAREnzMvhIqxcltNPQVka(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  imdFKsoLXrAREnzMvhIqxcltNPQVju=imdFKsoLXrAREnzMvhIqxcltNPQVJH.main_params.get('mode',imdFKsoLXrAREnzMvhIqxcltNPQVkH)
  if imdFKsoLXrAREnzMvhIqxcltNPQVju=='LOGOUT':
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.CP_logout()
   return
  imdFKsoLXrAREnzMvhIqxcltNPQVJH.option_check()
  if imdFKsoLXrAREnzMvhIqxcltNPQVju is imdFKsoLXrAREnzMvhIqxcltNPQVkH:
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.dp_Main_List(imdFKsoLXrAREnzMvhIqxcltNPQVJH.main_params)
  elif imdFKsoLXrAREnzMvhIqxcltNPQVju=='CATEGORY_GROUPLIST':
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.dp_Category_GroupList(imdFKsoLXrAREnzMvhIqxcltNPQVJH.main_params)
  elif imdFKsoLXrAREnzMvhIqxcltNPQVju=='THEME_GROUPLIST':
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.dp_Theme_GroupList(imdFKsoLXrAREnzMvhIqxcltNPQVJH.main_params)
  elif imdFKsoLXrAREnzMvhIqxcltNPQVju=='EVENT_GROUPLIST':
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.dp_Event_GroupList(imdFKsoLXrAREnzMvhIqxcltNPQVJH.main_params)
  elif imdFKsoLXrAREnzMvhIqxcltNPQVju=='EVENT_GAMELIST':
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.dp_Event_GameList(imdFKsoLXrAREnzMvhIqxcltNPQVJH.main_params)
  elif imdFKsoLXrAREnzMvhIqxcltNPQVju=='EVENT_LIST':
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.dp_Event_List(imdFKsoLXrAREnzMvhIqxcltNPQVJH.main_params)
  elif imdFKsoLXrAREnzMvhIqxcltNPQVju=='CATEGORY_LIST':
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.dp_Category_List(imdFKsoLXrAREnzMvhIqxcltNPQVJH.main_params)
  elif imdFKsoLXrAREnzMvhIqxcltNPQVju=='SEASON_LIST':
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.dp_Season_List(imdFKsoLXrAREnzMvhIqxcltNPQVJH.main_params)
  elif imdFKsoLXrAREnzMvhIqxcltNPQVju=='EPISODE_LIST':
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.dp_Episode_List(imdFKsoLXrAREnzMvhIqxcltNPQVJH.main_params)
  elif imdFKsoLXrAREnzMvhIqxcltNPQVju=='TEST':
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.dp_Test(imdFKsoLXrAREnzMvhIqxcltNPQVJH.main_params)
  elif imdFKsoLXrAREnzMvhIqxcltNPQVju in['MOVIE','VOD','HIGHLIGHT','LIVE']:
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.play_VIDEO(imdFKsoLXrAREnzMvhIqxcltNPQVJH.main_params)
  elif imdFKsoLXrAREnzMvhIqxcltNPQVju=='WATCH':
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.dp_Watch_List(imdFKsoLXrAREnzMvhIqxcltNPQVJH.main_params)
  elif imdFKsoLXrAREnzMvhIqxcltNPQVju=='LOCAL_SEARCH':
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.dp_Search_List(imdFKsoLXrAREnzMvhIqxcltNPQVJH.main_params)
  elif imdFKsoLXrAREnzMvhIqxcltNPQVju=='SEARCH_HISTORY':
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.dp_Search_History(imdFKsoLXrAREnzMvhIqxcltNPQVJH.main_params)
  elif imdFKsoLXrAREnzMvhIqxcltNPQVju in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.dp_Listfile_Delete(imdFKsoLXrAREnzMvhIqxcltNPQVJH.main_params)
  elif imdFKsoLXrAREnzMvhIqxcltNPQVju in['TOTAL_SEARCH','TOTAL_HISTORY']:
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.dp_Global_Search(imdFKsoLXrAREnzMvhIqxcltNPQVJH.main_params)
  elif imdFKsoLXrAREnzMvhIqxcltNPQVju=='MENU_BOOKMARK':
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.dp_Bookmark_Menu(imdFKsoLXrAREnzMvhIqxcltNPQVJH.main_params)
  elif imdFKsoLXrAREnzMvhIqxcltNPQVju=='SET_BOOKMARK':
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.dp_Set_Bookmark(imdFKsoLXrAREnzMvhIqxcltNPQVJH.main_params)
  elif imdFKsoLXrAREnzMvhIqxcltNPQVju=='SPORTS_MAINLIST_LEAGUE':
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.sp_Mainlist_League(imdFKsoLXrAREnzMvhIqxcltNPQVJH.main_params)
  elif imdFKsoLXrAREnzMvhIqxcltNPQVju=='SPORTS_LEAGUE_FEEDLIST':
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.sp_League_FeedList(imdFKsoLXrAREnzMvhIqxcltNPQVJH.main_params)
  elif imdFKsoLXrAREnzMvhIqxcltNPQVju=='SPORTS_FEED_VOD':
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.sp_League_VodList(imdFKsoLXrAREnzMvhIqxcltNPQVJH.main_params)
  elif imdFKsoLXrAREnzMvhIqxcltNPQVju=='SPORTS_MULT_HERO':
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.sp_MultiHero_LiveList(imdFKsoLXrAREnzMvhIqxcltNPQVJH.main_params)
  elif imdFKsoLXrAREnzMvhIqxcltNPQVju=='SPORTS_SEASON_GROUP':
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.sp_Season_Group(imdFKsoLXrAREnzMvhIqxcltNPQVJH.main_params)
  elif imdFKsoLXrAREnzMvhIqxcltNPQVju=='SPORTS_SEASON_GAMELIST':
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.sp_Season_GameList(imdFKsoLXrAREnzMvhIqxcltNPQVJH.main_params)
  elif imdFKsoLXrAREnzMvhIqxcltNPQVju=='SPORTS_SEASON_VODLIST':
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.sp_Season_VodList(imdFKsoLXrAREnzMvhIqxcltNPQVJH.main_params)
  elif imdFKsoLXrAREnzMvhIqxcltNPQVju=='PASS_GROUPLIST':
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.dp_Pass_Group(imdFKsoLXrAREnzMvhIqxcltNPQVJH.main_params)
  elif imdFKsoLXrAREnzMvhIqxcltNPQVju=='PASS_VOD_LIST':
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.dp_Pass_VodList(imdFKsoLXrAREnzMvhIqxcltNPQVJH.main_params)
  elif imdFKsoLXrAREnzMvhIqxcltNPQVju=='ORDER_BY':
   imdFKsoLXrAREnzMvhIqxcltNPQVJH.dp_setEpOrderby(imdFKsoLXrAREnzMvhIqxcltNPQVJH.main_params)
  else:
   imdFKsoLXrAREnzMvhIqxcltNPQVkH
# Created by pyminifier (https://github.com/liftoff/pyminifier)
