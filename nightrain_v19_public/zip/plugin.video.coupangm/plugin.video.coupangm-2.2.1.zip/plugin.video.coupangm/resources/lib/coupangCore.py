__author__="NightRain"
ACRqVdomFTbsvWDhOpkQlUPiEIrMua=object
ACRqVdomFTbsvWDhOpkQlUPiEIrMut=None
ACRqVdomFTbsvWDhOpkQlUPiEIrMuK=False
ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ=print
ACRqVdomFTbsvWDhOpkQlUPiEIrMue=str
ACRqVdomFTbsvWDhOpkQlUPiEIrMuz=open
ACRqVdomFTbsvWDhOpkQlUPiEIrMuy=Exception
ACRqVdomFTbsvWDhOpkQlUPiEIrMnY=int
ACRqVdomFTbsvWDhOpkQlUPiEIrMnc=len
ACRqVdomFTbsvWDhOpkQlUPiEIrMnG=id
ACRqVdomFTbsvWDhOpkQlUPiEIrMnH=True
ACRqVdomFTbsvWDhOpkQlUPiEIrMnu=range
import urllib
import re
import json
import requests
import datetime
import time
import random
import base64
ACRqVdomFTbsvWDhOpkQlUPiEIrMYG={'LONG_HIGHLIGHT':'하이라이트','SHORT_HIGHLIGHT':'하이라이트','PREVIEW':'프리뷰','FULL_MATCH':'다시보기','KEY_MOMENT':'','OTHER':'프로그램',}
class ACRqVdomFTbsvWDhOpkQlUPiEIrMYc(ACRqVdomFTbsvWDhOpkQlUPiEIrMua):
 def __init__(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36'
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.MODEL ='Chrome_142' 
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.OS_VERSION ='142' 
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.x_app_version ='1.67.19'
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.DEFAULT_HEADER ={'user-agent':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.USER_AGENT}
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.API_DOMAIN ='https://www.coupangplay.com'
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.API_VIEWURL ='https://discover.coupangstreaming.com'
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.PAGE_LIMIT =50
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.SEARCH_LIMIT =20
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.KodiVersion =20
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP={}
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.Init_CP()
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP_DEVICE_FILENAME=''
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP_COOKIE_FILENAME=''
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP_SESSION_COOKIES1=''
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP_SESSION_COOKIES2=''
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP_SESSION_COOKIES3=''
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP_SESSION_COOKIES4=''
 def callRequestCookies(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,jobtype,ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,payload=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,params=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,cookies=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,redirects=ACRqVdomFTbsvWDhOpkQlUPiEIrMuK):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYu=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.DEFAULT_HEADER
  if headers:ACRqVdomFTbsvWDhOpkQlUPiEIrMYu.update(headers)
  if jobtype=='Get':
   ACRqVdomFTbsvWDhOpkQlUPiEIrMYn=requests.get(ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,params=params,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMYu,cookies=cookies,allow_redirects=redirects)
  else:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMYn=requests.post(ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,data=payload,params=params,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMYu,cookies=cookies,allow_redirects=redirects)
  ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ(ACRqVdomFTbsvWDhOpkQlUPiEIrMue(ACRqVdomFTbsvWDhOpkQlUPiEIrMYn.status_code)+' - '+ACRqVdomFTbsvWDhOpkQlUPiEIrMue(ACRqVdomFTbsvWDhOpkQlUPiEIrMYn.url))
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMYn
 def callRequestCookies_test(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,jobtype,ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,payload=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,params=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,cookies=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,redirects=ACRqVdomFTbsvWDhOpkQlUPiEIrMuK):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYu=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.DEFAULT_HEADER
  if headers:ACRqVdomFTbsvWDhOpkQlUPiEIrMYu.update(headers)
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYn=requests.Request('POST',ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,headers=headers,data=payload,params=params,cookies=cookies)
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYS=ACRqVdomFTbsvWDhOpkQlUPiEIrMYn.prepare()
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.pretty_print_POST(ACRqVdomFTbsvWDhOpkQlUPiEIrMYS)
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMYn
 def pretty_print_POST(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,req):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ('{}\n{}\r\n{}\r\n\r\n{}'.format('-----------START-----------',req.method+' '+req.url,'\r\n'.join('{}: {}'.format(k,v)for k,v in req.headers.items()),req.body,))
 def dic_To_jsonfile(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,filename,ACRqVdomFTbsvWDhOpkQlUPiEIrMYf):
  if filename=='':return
  fp=ACRqVdomFTbsvWDhOpkQlUPiEIrMuz(filename,'w',-1,'utf-8')
  json.dump(ACRqVdomFTbsvWDhOpkQlUPiEIrMYf,fp,indent=4,ensure_ascii=ACRqVdomFTbsvWDhOpkQlUPiEIrMuK)
  fp.close()
 def jsonfile_To_dic(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,filename):
  if filename=='':return ACRqVdomFTbsvWDhOpkQlUPiEIrMut
  try:
   fp=ACRqVdomFTbsvWDhOpkQlUPiEIrMuz(filename,'r',-1,'utf-8')
   ACRqVdomFTbsvWDhOpkQlUPiEIrMYN=json.load(fp)
   fp.close()
  except:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMYN={}
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMYN
 def convert_TimeStr(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,ACRqVdomFTbsvWDhOpkQlUPiEIrMYg):
  try:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMYg =ACRqVdomFTbsvWDhOpkQlUPiEIrMYg[0:16]
   ACRqVdomFTbsvWDhOpkQlUPiEIrMYL=datetime.datetime.strptime(ACRqVdomFTbsvWDhOpkQlUPiEIrMYg,'%Y-%m-%dT%H:%M')+datetime.timedelta(hours=9)
   ACRqVdomFTbsvWDhOpkQlUPiEIrMYX=ACRqVdomFTbsvWDhOpkQlUPiEIrMYL.weekday()
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMYX==0:ACRqVdomFTbsvWDhOpkQlUPiEIrMYX='월'
   elif ACRqVdomFTbsvWDhOpkQlUPiEIrMYX==1:ACRqVdomFTbsvWDhOpkQlUPiEIrMYX='화'
   elif ACRqVdomFTbsvWDhOpkQlUPiEIrMYX==2:ACRqVdomFTbsvWDhOpkQlUPiEIrMYX='수'
   elif ACRqVdomFTbsvWDhOpkQlUPiEIrMYX==3:ACRqVdomFTbsvWDhOpkQlUPiEIrMYX='목'
   elif ACRqVdomFTbsvWDhOpkQlUPiEIrMYX==4:ACRqVdomFTbsvWDhOpkQlUPiEIrMYX='금'
   elif ACRqVdomFTbsvWDhOpkQlUPiEIrMYX==5:ACRqVdomFTbsvWDhOpkQlUPiEIrMYX='토'
   elif ACRqVdomFTbsvWDhOpkQlUPiEIrMYX==6:ACRqVdomFTbsvWDhOpkQlUPiEIrMYX='일'
   return ACRqVdomFTbsvWDhOpkQlUPiEIrMYL.strftime('%Y-%m-%d')+'('+ ACRqVdomFTbsvWDhOpkQlUPiEIrMYX+')'+ACRqVdomFTbsvWDhOpkQlUPiEIrMYL.strftime(' %H:%M')
  except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
   return ACRqVdomFTbsvWDhOpkQlUPiEIrMYg
 def convert_DateStr(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,ACRqVdomFTbsvWDhOpkQlUPiEIrMYg):
  try:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMYg =ACRqVdomFTbsvWDhOpkQlUPiEIrMYg[0:16]
   ACRqVdomFTbsvWDhOpkQlUPiEIrMYL=datetime.datetime.strptime(ACRqVdomFTbsvWDhOpkQlUPiEIrMYg,'%Y-%m-%dT%H:%M')+datetime.timedelta(hours=9)
   ACRqVdomFTbsvWDhOpkQlUPiEIrMYX=ACRqVdomFTbsvWDhOpkQlUPiEIrMYL.weekday()
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMYX==0:ACRqVdomFTbsvWDhOpkQlUPiEIrMYX='월'
   elif ACRqVdomFTbsvWDhOpkQlUPiEIrMYX==1:ACRqVdomFTbsvWDhOpkQlUPiEIrMYX='화'
   elif ACRqVdomFTbsvWDhOpkQlUPiEIrMYX==2:ACRqVdomFTbsvWDhOpkQlUPiEIrMYX='수'
   elif ACRqVdomFTbsvWDhOpkQlUPiEIrMYX==3:ACRqVdomFTbsvWDhOpkQlUPiEIrMYX='목'
   elif ACRqVdomFTbsvWDhOpkQlUPiEIrMYX==4:ACRqVdomFTbsvWDhOpkQlUPiEIrMYX='금'
   elif ACRqVdomFTbsvWDhOpkQlUPiEIrMYX==5:ACRqVdomFTbsvWDhOpkQlUPiEIrMYX='토'
   elif ACRqVdomFTbsvWDhOpkQlUPiEIrMYX==6:ACRqVdomFTbsvWDhOpkQlUPiEIrMYX='일'
   return ACRqVdomFTbsvWDhOpkQlUPiEIrMYL.strftime('%Y-%m-%d')+'('+ ACRqVdomFTbsvWDhOpkQlUPiEIrMYX+')'
  except:
   return ACRqVdomFTbsvWDhOpkQlUPiEIrMYg
 def Get_Now_Datetime(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetNoCache(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYB =ACRqVdomFTbsvWDhOpkQlUPiEIrMnY(time.time()*1000)
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMYB
 def generatePcId(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH):
  t=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.GetNoCache()
  r=random.random()
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYx=ACRqVdomFTbsvWDhOpkQlUPiEIrMue(t)+ACRqVdomFTbsvWDhOpkQlUPiEIrMue(r)[2:12]
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMYx
 def generatePvId(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,genType='1'):
  import hashlib
  m=hashlib.md5()
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYa=ACRqVdomFTbsvWDhOpkQlUPiEIrMue(random.random())
  m.update(ACRqVdomFTbsvWDhOpkQlUPiEIrMYa.encode('utf-8'))
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYt=ACRqVdomFTbsvWDhOpkQlUPiEIrMue(m.hexdigest())
  if genType=='1':
   return '%s-%s-%s-%s-%s'%(ACRqVdomFTbsvWDhOpkQlUPiEIrMYt[:8],ACRqVdomFTbsvWDhOpkQlUPiEIrMYt[8:12],ACRqVdomFTbsvWDhOpkQlUPiEIrMYt[12:16],ACRqVdomFTbsvWDhOpkQlUPiEIrMYt[16:20],ACRqVdomFTbsvWDhOpkQlUPiEIrMYt[20:])
  else:
   return ACRqVdomFTbsvWDhOpkQlUPiEIrMYt
 def Get_DeviceID(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYK=''
  try: 
   fp=ACRqVdomFTbsvWDhOpkQlUPiEIrMuz(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP_DEVICE_FILENAME,'r',-1,'utf-8')
   ACRqVdomFTbsvWDhOpkQlUPiEIrMYJ= json.load(fp)
   fp.close()
   ACRqVdomFTbsvWDhOpkQlUPiEIrMYK=ACRqVdomFTbsvWDhOpkQlUPiEIrMYJ.get('device_id')
  except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMut
  if ACRqVdomFTbsvWDhOpkQlUPiEIrMYK=='':
   ACRqVdomFTbsvWDhOpkQlUPiEIrMYK=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.generatePvId(genType='1')
   try: 
    fp=ACRqVdomFTbsvWDhOpkQlUPiEIrMuz(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP_DEVICE_FILENAME,'w',-1,'utf-8')
    json.dump({'device_id':ACRqVdomFTbsvWDhOpkQlUPiEIrMYK},fp,indent=4,ensure_ascii=ACRqVdomFTbsvWDhOpkQlUPiEIrMuK)
    fp.close()
   except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
    return ''
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMYK
 def make_stream_header(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,ACRqVdomFTbsvWDhOpkQlUPiEIrMcG,ACRqVdomFTbsvWDhOpkQlUPiEIrMcL):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYe=''
  if ACRqVdomFTbsvWDhOpkQlUPiEIrMcL not in[{},ACRqVdomFTbsvWDhOpkQlUPiEIrMut,'']:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMYz=ACRqVdomFTbsvWDhOpkQlUPiEIrMnc(ACRqVdomFTbsvWDhOpkQlUPiEIrMcL)
   for ACRqVdomFTbsvWDhOpkQlUPiEIrMYy,ACRqVdomFTbsvWDhOpkQlUPiEIrMcY in ACRqVdomFTbsvWDhOpkQlUPiEIrMcL.items():
    ACRqVdomFTbsvWDhOpkQlUPiEIrMYe+='{}={}'.format(ACRqVdomFTbsvWDhOpkQlUPiEIrMYy,ACRqVdomFTbsvWDhOpkQlUPiEIrMcY)
    ACRqVdomFTbsvWDhOpkQlUPiEIrMYz+=-1
    if ACRqVdomFTbsvWDhOpkQlUPiEIrMYz>0:ACRqVdomFTbsvWDhOpkQlUPiEIrMYe+='; '
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcG['cookie']=ACRqVdomFTbsvWDhOpkQlUPiEIrMYe
  ACRqVdomFTbsvWDhOpkQlUPiEIrMcH=''
  i=0
  for ACRqVdomFTbsvWDhOpkQlUPiEIrMYy,ACRqVdomFTbsvWDhOpkQlUPiEIrMcY in ACRqVdomFTbsvWDhOpkQlUPiEIrMcG.items():
   i=i+1
   if i>1:ACRqVdomFTbsvWDhOpkQlUPiEIrMcH+='&'
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcH+='{}={}'.format(ACRqVdomFTbsvWDhOpkQlUPiEIrMYy,urllib.parse.quote(ACRqVdomFTbsvWDhOpkQlUPiEIrMcY))
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMcH
 def Make_authHeader(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH):
  tr=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.generatePvId(genType=2)
  ti=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.GetNoCache()
  ACRqVdomFTbsvWDhOpkQlUPiEIrMnG=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.generatePvId(genType=2)[:16]
  ACRqVdomFTbsvWDhOpkQlUPiEIrMcu='00-%s-%s-01'%(tr,ACRqVdomFTbsvWDhOpkQlUPiEIrMnG,)
  ACRqVdomFTbsvWDhOpkQlUPiEIrMcn ='%s@nr=0-1-%s-%s-%s----%s'%(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['SESSION']['NREUM']['tk'],ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['SESSION']['NREUM']['ac'],ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['SESSION']['NREUM']['ap'],ACRqVdomFTbsvWDhOpkQlUPiEIrMnG,ti,)
  ACRqVdomFTbsvWDhOpkQlUPiEIrMcS ='{"v":[0,1],"d":{"ty":"Browser","ac":"%s","ap":"%s","id":"%s","tr":"%s","ti":%s,"tk":"%s"}}'%(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['SESSION']['NREUM']['ac'],ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['SESSION']['NREUM']['ap'],ACRqVdomFTbsvWDhOpkQlUPiEIrMnG,tr,ti,ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['SESSION']['NREUM']['tk'],) 
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMcu,ACRqVdomFTbsvWDhOpkQlUPiEIrMcn,base64.standard_b64encode(ACRqVdomFTbsvWDhOpkQlUPiEIrMcS.encode()).decode('utf-8')
 def Init_CP(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP={}
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['ACCOUNT']={'cpid':'','cppw':'','cppf':'0'}
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['SESSION']={}
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['COOKIES']={}
 def Save_session_acount(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,ACRqVdomFTbsvWDhOpkQlUPiEIrMcf,ACRqVdomFTbsvWDhOpkQlUPiEIrMcj,ACRqVdomFTbsvWDhOpkQlUPiEIrMcN):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['ACCOUNT']['cpid']=base64.standard_b64encode(ACRqVdomFTbsvWDhOpkQlUPiEIrMcf.encode()).decode('utf-8')
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['ACCOUNT']['cppw']=base64.standard_b64encode(ACRqVdomFTbsvWDhOpkQlUPiEIrMcj.encode()).decode('utf-8')
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['ACCOUNT']['cppf']=ACRqVdomFTbsvWDhOpkQlUPiEIrMue(ACRqVdomFTbsvWDhOpkQlUPiEIrMcN)
 def Load_session_acount(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMcf=base64.standard_b64decode(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['ACCOUNT']['cpid']).decode('utf-8')
  ACRqVdomFTbsvWDhOpkQlUPiEIrMcj=base64.standard_b64decode(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['ACCOUNT']['cppw']).decode('utf-8')
  ACRqVdomFTbsvWDhOpkQlUPiEIrMcN=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['ACCOUNT']['cppf']
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMcf,ACRqVdomFTbsvWDhOpkQlUPiEIrMcj,ACRqVdomFTbsvWDhOpkQlUPiEIrMcN
 def make_CP_DefaultCookies(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH):
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['COOKIES']
 def Get_CP_Login(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,userid,userpw,ACRqVdomFTbsvWDhOpkQlUPiEIrMce):
  try:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcg=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.API_DOMAIN
   ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['COOKIES']['NEXT_LOCALE']='ko'
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcG={'Accept-Language':'ko-KR,ko;q=0.9','Sec-Ch-Ua-Mobile':'?0','Sec-Ch-Ua-Platform':'"Windows"','Sec-Fetch-Dest':'document','Sec-Fetch-Mode':'navigate','Sec-Fetch-Site':'none','Sec-Fetch-User':'?1','Upgrade-Insecure-Requests':'1',}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcL=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.make_CP_DefaultCookies()
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcX=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.callRequestCookies('Get',ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,payload=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,params=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMcG,cookies=ACRqVdomFTbsvWDhOpkQlUPiEIrMcL,redirects=ACRqVdomFTbsvWDhOpkQlUPiEIrMnH)
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.status_code not in[200]:return ACRqVdomFTbsvWDhOpkQlUPiEIrMuK
   for ACRqVdomFTbsvWDhOpkQlUPiEIrMcw in ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.cookies:
    ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['COOKIES'][ACRqVdomFTbsvWDhOpkQlUPiEIrMcw.name]=ACRqVdomFTbsvWDhOpkQlUPiEIrMcw.value
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcB=re.findall('NREUM.loader_config=\{[\w\d\":,-]+\}',ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.text)[0].split('=')[1]
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcB=ACRqVdomFTbsvWDhOpkQlUPiEIrMcB.replace('{','{"').replace(':','":').replace(',',',"')
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcB=json.loads(ACRqVdomFTbsvWDhOpkQlUPiEIrMcB)
   ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['SESSION']['NREUM']={'ac':ACRqVdomFTbsvWDhOpkQlUPiEIrMcB['accountID'],'tk':ACRqVdomFTbsvWDhOpkQlUPiEIrMcB['trustKey'],'ap':ACRqVdomFTbsvWDhOpkQlUPiEIrMcB['agentID'],'lk':ACRqVdomFTbsvWDhOpkQlUPiEIrMcB['licenseKey'],}
  except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ(exception)
   return ACRqVdomFTbsvWDhOpkQlUPiEIrMuK
  try:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcg=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.API_DOMAIN+'/api/auth'
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcx=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.Get_DeviceID()
   ACRqVdomFTbsvWDhOpkQlUPiEIrMca =ACRqVdomFTbsvWDhOpkQlUPiEIrMcx.split('-')[0]
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcu,ACRqVdomFTbsvWDhOpkQlUPiEIrMcn,ACRqVdomFTbsvWDhOpkQlUPiEIrMcS=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.Make_authHeader()
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcG={'traceparent':ACRqVdomFTbsvWDhOpkQlUPiEIrMcu,'tracestate':ACRqVdomFTbsvWDhOpkQlUPiEIrMcn,'newrelic':ACRqVdomFTbsvWDhOpkQlUPiEIrMcS,'content-type':'application/json','x-app-version':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.x_app_version,'x-device-id':'','x-device-os-version':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.OS_VERSION,'x-nr-session-id':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['COOKIES']['session_web_id'],'x-pcid':'',}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMct={'device':{'deviceId':'web-'+ACRqVdomFTbsvWDhOpkQlUPiEIrMcx,'model':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.MODEL,'name':'Chrome Desktop '+ACRqVdomFTbsvWDhOpkQlUPiEIrMca,'os':'Windows','osVersion':'10','type':'webclient',},'email':userid,'password':userpw,}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMct=json.dumps(ACRqVdomFTbsvWDhOpkQlUPiEIrMct,separators=(',',':'))
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcL=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.make_CP_DefaultCookies()
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcX=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.callRequestCookies('Post',ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,payload=ACRqVdomFTbsvWDhOpkQlUPiEIrMct,params=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMcG,cookies=ACRqVdomFTbsvWDhOpkQlUPiEIrMcL,redirects=ACRqVdomFTbsvWDhOpkQlUPiEIrMuK)
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.status_code not in[200]:
    ACRqVdomFTbsvWDhOpkQlUPiEIrMcK=json.loads(ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.text)
    if 'error' in ACRqVdomFTbsvWDhOpkQlUPiEIrMcK:
     ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['SESSION']['error']=ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('error').get('detail')
    return ACRqVdomFTbsvWDhOpkQlUPiEIrMuK
   ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ('---')
   for ACRqVdomFTbsvWDhOpkQlUPiEIrMcw in ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.cookies:
    ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['COOKIES'][ACRqVdomFTbsvWDhOpkQlUPiEIrMcw.name]=ACRqVdomFTbsvWDhOpkQlUPiEIrMcw.value
  except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ(exception)
   return ACRqVdomFTbsvWDhOpkQlUPiEIrMuK
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.Save_session_acount(userid,userpw,ACRqVdomFTbsvWDhOpkQlUPiEIrMce)
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMnH
 def Get_CP_profile(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,ACRqVdomFTbsvWDhOpkQlUPiEIrMce,limit_days=1,re_check=ACRqVdomFTbsvWDhOpkQlUPiEIrMuK):
  if re_check==ACRqVdomFTbsvWDhOpkQlUPiEIrMnH:
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['SESSION']['bm_sv_ex']>ACRqVdomFTbsvWDhOpkQlUPiEIrMnY(time.time()):
    ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ('bm_sv_ex ok')
    return ACRqVdomFTbsvWDhOpkQlUPiEIrMnH
  try:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcg=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.API_DOMAIN+'/api/profiles'
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcu,ACRqVdomFTbsvWDhOpkQlUPiEIrMcn,ACRqVdomFTbsvWDhOpkQlUPiEIrMcS=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.Make_authHeader()
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcG={'traceparent':ACRqVdomFTbsvWDhOpkQlUPiEIrMcu,'tracestate':ACRqVdomFTbsvWDhOpkQlUPiEIrMcn,'newrelic':ACRqVdomFTbsvWDhOpkQlUPiEIrMcS,'x-app-version':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.x_app_version,'x-device-id':'','x-device-os-version':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.OS_VERSION,'x-nr-session-id':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['COOKIES']['session_web_id'],'x-pcid':'','referer':'https://www.coupangplay.com/home',}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcL=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.make_CP_DefaultCookies()
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcX=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.callRequestCookies('Get',ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,payload=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,params=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMcG,cookies=ACRqVdomFTbsvWDhOpkQlUPiEIrMcL,redirects=ACRqVdomFTbsvWDhOpkQlUPiEIrMnH)
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.status_code not in[200]:return ACRqVdomFTbsvWDhOpkQlUPiEIrMuK
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcK=json.loads(ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.text)
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcJ=0
   for ACRqVdomFTbsvWDhOpkQlUPiEIrMcw in ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.cookies:
    ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['COOKIES'][ACRqVdomFTbsvWDhOpkQlUPiEIrMcw.name]=ACRqVdomFTbsvWDhOpkQlUPiEIrMcw.value
    if ACRqVdomFTbsvWDhOpkQlUPiEIrMcw.name=='bm_sv':
     ACRqVdomFTbsvWDhOpkQlUPiEIrMcJ=1
     ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['SESSION']['bm_sv_ex']=ACRqVdomFTbsvWDhOpkQlUPiEIrMcw.expires 
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMcJ==0:
    ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['SESSION']['bm_sv_ex']=ACRqVdomFTbsvWDhOpkQlUPiEIrMnY(time.time())+60*60*2 
   ACRqVdomFTbsvWDhOpkQlUPiEIrMce=ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('data')[ACRqVdomFTbsvWDhOpkQlUPiEIrMnY(ACRqVdomFTbsvWDhOpkQlUPiEIrMce)]
   ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['SESSION']['accountId']=ACRqVdomFTbsvWDhOpkQlUPiEIrMce.get('accountId')
   ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['SESSION']['profileId']=ACRqVdomFTbsvWDhOpkQlUPiEIrMce.get('profileId')
  except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ(exception)
   return ACRqVdomFTbsvWDhOpkQlUPiEIrMuK
  if re_check==ACRqVdomFTbsvWDhOpkQlUPiEIrMuK:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcz =ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.Get_Now_Datetime()
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcy=ACRqVdomFTbsvWDhOpkQlUPiEIrMcz+datetime.timedelta(days=limit_days)
   ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['SESSION']['limitdate']=ACRqVdomFTbsvWDhOpkQlUPiEIrMcy.strftime('%Y-%m-%d')
  else:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ('re check')
  ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.dic_To_jsonfile(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP_COOKIE_FILENAME,ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP)
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMnH
 def Get_Category_GroupList(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,vType):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMGY=[] 
  try:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcg=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.API_DOMAIN+'/api-discover/v3/discover/feed' 
   ACRqVdomFTbsvWDhOpkQlUPiEIrMGc={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false','preferRecoFeed':'true','preferMultiHeroMixedContentRow':'true','shouldIncludeTVOD':'true',}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcG={'x-membersrl':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['COOKIES']['member_srl'],'x-pcid':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['COOKIES']['PCID'],'x-profileid':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT','x-app-version':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.x_app_version,}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcX=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.callRequestCookies('Get',ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,payload=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,params=ACRqVdomFTbsvWDhOpkQlUPiEIrMGc,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMcG,cookies=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,redirects=ACRqVdomFTbsvWDhOpkQlUPiEIrMnH)
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.status_code not in[200]:return[]
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcK=json.loads(ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.text)
   if vType in['TVSHOWS','MOVIES']:
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGH='Explores' 
   elif vType in['EDUCATION']:
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGH='Collection-Rails-Curation'
   elif vType in['ALL','KIDS']:
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGH='Explores-Categories'
   for ACRqVdomFTbsvWDhOpkQlUPiEIrMGu in ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('data'):
    if ACRqVdomFTbsvWDhOpkQlUPiEIrMGu.get('type')==ACRqVdomFTbsvWDhOpkQlUPiEIrMGH:
     for ACRqVdomFTbsvWDhOpkQlUPiEIrMGn in ACRqVdomFTbsvWDhOpkQlUPiEIrMGu.get('data'):
      if vType in['TVSHOWS','MOVIES']:
       ACRqVdomFTbsvWDhOpkQlUPiEIrMGS=ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('collectionId')
      elif vType in['EDUCATION','ALL','KIDS']:
       ACRqVdomFTbsvWDhOpkQlUPiEIrMGS=ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('id')
      ACRqVdomFTbsvWDhOpkQlUPiEIrMGf={'collectionId':ACRqVdomFTbsvWDhOpkQlUPiEIrMGS,'title':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('name'),'category':ACRqVdomFTbsvWDhOpkQlUPiEIrMGu.get('category'),'pre_title':'',}
      ACRqVdomFTbsvWDhOpkQlUPiEIrMGY.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGf)
     break
  except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ(exception)
   return[]
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMGY
 def Get_Category_List(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,vType,ACRqVdomFTbsvWDhOpkQlUPiEIrMGS,page_int):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMGY=[] 
  ACRqVdomFTbsvWDhOpkQlUPiEIrMGj=ACRqVdomFTbsvWDhOpkQlUPiEIrMuK
  try:
   if vType in['ALL','#KIDS']:
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGc={'platform':'WEBCLIENT','page':ACRqVdomFTbsvWDhOpkQlUPiEIrMue(page_int),'perPage':ACRqVdomFTbsvWDhOpkQlUPiEIrMue(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.PAGE_LIMIT),'locale':'ko','sort':'',}
    ACRqVdomFTbsvWDhOpkQlUPiEIrMcG={'x-membersrl':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['COOKIES']['member_srl'],'x-pcid':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['COOKIES']['PCID'],'x-profileid':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT','x-app-version':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.x_app_version,}
    ACRqVdomFTbsvWDhOpkQlUPiEIrMcg=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.API_DOMAIN+'/api-discover/v1/discover/categories/'+ACRqVdomFTbsvWDhOpkQlUPiEIrMGS+'/titles' 
    ACRqVdomFTbsvWDhOpkQlUPiEIrMcX=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.callRequestCookies('Get',ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,payload=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,params=ACRqVdomFTbsvWDhOpkQlUPiEIrMGc,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMcG,cookies=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,redirects=ACRqVdomFTbsvWDhOpkQlUPiEIrMnH)
   else: 
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGc={'platform':'WEBCLIENT','page':ACRqVdomFTbsvWDhOpkQlUPiEIrMue(page_int),'perPage':ACRqVdomFTbsvWDhOpkQlUPiEIrMue(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.PAGE_LIMIT),}
    ACRqVdomFTbsvWDhOpkQlUPiEIrMcG={'x-membersrl':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['COOKIES']['member_srl'],'x-pcid':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['COOKIES']['PCID'],'x-profileid':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT','x-app-version':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.x_app_version,}
    ACRqVdomFTbsvWDhOpkQlUPiEIrMcg=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.API_DOMAIN+'/api-discover/v1/discover/collections/'+ACRqVdomFTbsvWDhOpkQlUPiEIrMGS+'/titles' 
    ACRqVdomFTbsvWDhOpkQlUPiEIrMcX=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.callRequestCookies('Get',ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,payload=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,params=ACRqVdomFTbsvWDhOpkQlUPiEIrMGc,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMcG,cookies=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,redirects=ACRqVdomFTbsvWDhOpkQlUPiEIrMnH)
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.status_code not in[200]:return[],ACRqVdomFTbsvWDhOpkQlUPiEIrMuK
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcK=json.loads(ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.text)
   if vType in['ALL','#KIDS']:
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGN=ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('data').get('data')
   else:
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGN=ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('data')
   for ACRqVdomFTbsvWDhOpkQlUPiEIrMGn in ACRqVdomFTbsvWDhOpkQlUPiEIrMGN:
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGg=ACRqVdomFTbsvWDhOpkQlUPiEIrMGx=ACRqVdomFTbsvWDhOpkQlUPiEIrMHX=ACRqVdomFTbsvWDhOpkQlUPiEIrMHL=''
    if 'poster' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images'):ACRqVdomFTbsvWDhOpkQlUPiEIrMGg =ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images'):ACRqVdomFTbsvWDhOpkQlUPiEIrMGx =ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images').get('story-art').get('url') +'?imwidth=600'
    if 'title-treatment' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images'):ACRqVdomFTbsvWDhOpkQlUPiEIrMHX=ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images').get('title-treatment').get('url')+'?imwidth=300'
    if 'story-art' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images'):ACRqVdomFTbsvWDhOpkQlUPiEIrMHL =ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images').get('story-art').get('url') +'?imwidth=600'
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGL=''
    if ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('badge')not in[{},ACRqVdomFTbsvWDhOpkQlUPiEIrMut]:
     for i in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('badge').get('text'):
      ACRqVdomFTbsvWDhOpkQlUPiEIrMGL+=i.get('text')
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGX=''
    if ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('seasonList')!=ACRqVdomFTbsvWDhOpkQlUPiEIrMut:
     ACRqVdomFTbsvWDhOpkQlUPiEIrMGX=','.join(ACRqVdomFTbsvWDhOpkQlUPiEIrMue(e)for e in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('seasonList'))
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGw =[]
    for ACRqVdomFTbsvWDhOpkQlUPiEIrMGB in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('tags'):
     ACRqVdomFTbsvWDhOpkQlUPiEIrMGw.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGB.get('tag'))
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGf={'id':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('id'),'title':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('title'),'thumbnail':{'poster':ACRqVdomFTbsvWDhOpkQlUPiEIrMGg,'thumb':ACRqVdomFTbsvWDhOpkQlUPiEIrMGx,'clearlogo':ACRqVdomFTbsvWDhOpkQlUPiEIrMHX,'fanart':ACRqVdomFTbsvWDhOpkQlUPiEIrMHL},'mpaa':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('age_rating'),'duration':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('running_time'),'asis':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('as'),'badge':ACRqVdomFTbsvWDhOpkQlUPiEIrMGL,'year':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('meta').get('releaseYear'),'seasonList':ACRqVdomFTbsvWDhOpkQlUPiEIrMGX,'genreList':ACRqVdomFTbsvWDhOpkQlUPiEIrMGw,}
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGY.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGf)
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('pagination').get('totalPages')>page_int:
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGj=ACRqVdomFTbsvWDhOpkQlUPiEIrMnH
  except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ(exception)
   return[],ACRqVdomFTbsvWDhOpkQlUPiEIrMuK
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMGY,ACRqVdomFTbsvWDhOpkQlUPiEIrMGj
 def Get_Episode_List_x(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,programId,season):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMGY=[] 
  try:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcg=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.API_DOMAIN+'/api-discover/v1/discover/titles/'+programId+'/episodes' 
   ACRqVdomFTbsvWDhOpkQlUPiEIrMGc={'season':season,'sort':'true','locale':'ko',}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcG={'x-membersrl':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['COOKIES']['member_srl'],'x-pcid':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['COOKIES']['PCID'],'x-profileid':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT','x-app-version':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.x_app_version,}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcX=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.callRequestCookies('Get',ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,payload=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,params=ACRqVdomFTbsvWDhOpkQlUPiEIrMGc,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,cookies=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,redirects=ACRqVdomFTbsvWDhOpkQlUPiEIrMnH)
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.status_code not in[200]:return[]
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcK=json.loads(ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.text)
   for ACRqVdomFTbsvWDhOpkQlUPiEIrMGn in ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('data'):
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGx=''
    if 'story-art' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images'):ACRqVdomFTbsvWDhOpkQlUPiEIrMGx =ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images').get('story-art').get('url')+'?imwidth=600'
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGw =[]
    for ACRqVdomFTbsvWDhOpkQlUPiEIrMGB in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('tags'):
     ACRqVdomFTbsvWDhOpkQlUPiEIrMGw.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGB.get('tag'))
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGf={'id':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('id'),'title':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('title'),'thumbnail':{'thumb':ACRqVdomFTbsvWDhOpkQlUPiEIrMGx,'fanart':ACRqVdomFTbsvWDhOpkQlUPiEIrMGx},'mpaa':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('age_rating'),'duration':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('running_time'),'asis':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('as'),'year':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('meta').get('releaseYear'),'episode':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('episode'),'genreList':ACRqVdomFTbsvWDhOpkQlUPiEIrMGw,'desc':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('description'),}
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGY.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGf)
  except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ(exception)
   return[]
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMGY
 def Get_Episode_List(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,programId,season,page=1,orderby='asc'):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMGY=[] 
  ACRqVdomFTbsvWDhOpkQlUPiEIrMGj=ACRqVdomFTbsvWDhOpkQlUPiEIrMuK
  try:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcg=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.API_DOMAIN+'/api-discover/v2/discover/titles/'+programId+'/episodes'
   ACRqVdomFTbsvWDhOpkQlUPiEIrMGc={'seasonRange':'{}~{}'.format(season,season),'page':ACRqVdomFTbsvWDhOpkQlUPiEIrMue(page),'overrideSortOrder':orderby,'titleId':programId,'locale':'ko','perPage':ACRqVdomFTbsvWDhOpkQlUPiEIrMue(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.PAGE_LIMIT),'disableCache':'false','includeChannelContents':'false','platform':'WEBCLIENT','sort':'true',}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcG={'x-membersrl':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['COOKIES']['member_srl'],'x-pcid':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['COOKIES']['PCID'],'x-profileid':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT','x-app-version':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.x_app_version,}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcX=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.callRequestCookies('Get',ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,payload=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,params=ACRqVdomFTbsvWDhOpkQlUPiEIrMGc,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,cookies=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,redirects=ACRqVdomFTbsvWDhOpkQlUPiEIrMnH)
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.status_code not in[200]:return[],ACRqVdomFTbsvWDhOpkQlUPiEIrMuK
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcK=json.loads(ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.text)
   for ACRqVdomFTbsvWDhOpkQlUPiEIrMGn in ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('data'):
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGx=''
    if 'story-art' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images'):ACRqVdomFTbsvWDhOpkQlUPiEIrMGx =ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images').get('story-art').get('url')+'?imwidth=600'
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGw =[]
    for ACRqVdomFTbsvWDhOpkQlUPiEIrMGB in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('tags'):
     ACRqVdomFTbsvWDhOpkQlUPiEIrMGw.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGB.get('tag'))
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGf={'id':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('id'),'title':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('title'),'thumbnail':{'thumb':ACRqVdomFTbsvWDhOpkQlUPiEIrMGx,'fanart':ACRqVdomFTbsvWDhOpkQlUPiEIrMGx},'mpaa':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('age_rating'),'duration':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('running_time'),'asis':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('as'),'year':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('meta').get('releaseYear'),'episode':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('episode'),'genreList':ACRqVdomFTbsvWDhOpkQlUPiEIrMGw,'desc':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('description'),}
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGY.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGf)
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('pagination').get('totalPages')>page:
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGj=ACRqVdomFTbsvWDhOpkQlUPiEIrMnH
  except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ(exception)
   return[]
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMGY,ACRqVdomFTbsvWDhOpkQlUPiEIrMGj
 def Get_vInfo(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,titleId):
  try:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcg=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.API_DOMAIN+'/api-discover/v1/discover/titles/'+titleId 
   ACRqVdomFTbsvWDhOpkQlUPiEIrMGc={'platform':'WEBCLIENT','locale':'ko','filterRestrictedContent':'false',}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcX=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.callRequestCookies('Get',ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,payload=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,params=ACRqVdomFTbsvWDhOpkQlUPiEIrMGc,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,cookies=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,redirects=ACRqVdomFTbsvWDhOpkQlUPiEIrMnH)
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.status_code not in[200]:return '','',''
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcK=json.loads(ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.text).get('data')
   ACRqVdomFTbsvWDhOpkQlUPiEIrMGX=''
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('seasonList')!=ACRqVdomFTbsvWDhOpkQlUPiEIrMut:
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGX=','.join(ACRqVdomFTbsvWDhOpkQlUPiEIrMue(e)for e in ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('seasonList'))
   ACRqVdomFTbsvWDhOpkQlUPiEIrMGa={'age_rating':ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('age_rating'),'asset_id':ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('asset_id'),'availability':ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('availability'),'deal_id':ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('deal_id'),'downloadable':'true' if ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('downloadable')else 'false','region':ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('region'),'streamable':'true' if ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('streamable')else 'false','asis':ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('as'),'seasonList':ACRqVdomFTbsvWDhOpkQlUPiEIrMGX}
  except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ(exception)
   return{}
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMGa
 def Get_eInfo(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,eventId):
  try:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcg=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.API_DOMAIN+'/api-discover/v1/discover/events/'+eventId 
   ACRqVdomFTbsvWDhOpkQlUPiEIrMGc={'locale':'ko','platform':'WEBCLIENT','includeSportsChannelContents':'true',}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcX=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.callRequestCookies('Get',ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,payload=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,params=ACRqVdomFTbsvWDhOpkQlUPiEIrMGc,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,cookies=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,redirects=ACRqVdomFTbsvWDhOpkQlUPiEIrMnH)
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.status_code not in[200]:return '','',''
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcK=json.loads(ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.text).get('data')
   ACRqVdomFTbsvWDhOpkQlUPiEIrMGa={'asset_id':ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('asset_id'),'deal_id':ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('deal_id'),'region':ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('region'),'streamable':'true' if ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('streamable')else 'false',}
  except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ(exception)
   return{}
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMGa
 def GetBroadURL(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,titleId):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMGt=''
  ACRqVdomFTbsvWDhOpkQlUPiEIrMGK =''
  ACRqVdomFTbsvWDhOpkQlUPiEIrMGa=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.Get_vInfo(titleId)
  if ACRqVdomFTbsvWDhOpkQlUPiEIrMGa=={}:return '',''
  try:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcg=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.API_DOMAIN+'/api/playback/play' 
   ACRqVdomFTbsvWDhOpkQlUPiEIrMGc={'titleId':titleId}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcu,ACRqVdomFTbsvWDhOpkQlUPiEIrMcn,ACRqVdomFTbsvWDhOpkQlUPiEIrMcS=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.Make_authHeader()
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcG={'traceparent':ACRqVdomFTbsvWDhOpkQlUPiEIrMcu,'tracestate':ACRqVdomFTbsvWDhOpkQlUPiEIrMcn,'newrelic':ACRqVdomFTbsvWDhOpkQlUPiEIrMcS,'x-drm':'com.microsoft.playready','x-app-version':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.x_app_version,'x-device-id':'','x-device-os-version':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.OS_VERSION,'x-force-raw':'true','x-nr-session-id':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['COOKIES']['session_web_id'],'x-pcid':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['COOKIES']['PCID'],'x-platform':'web','x-profileId':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['SESSION']['profileId'],'x-profileType':'standard','x-sessionid':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.generatePvId(genType='1'),'x-title-age-rating':ACRqVdomFTbsvWDhOpkQlUPiEIrMGa.get('age_rating'),'x-title-availability':ACRqVdomFTbsvWDhOpkQlUPiEIrMGa.get('availability'),'x-title-brightcove-id':ACRqVdomFTbsvWDhOpkQlUPiEIrMGa.get('asset_id'),'x-title-deal-id':ACRqVdomFTbsvWDhOpkQlUPiEIrMGa.get('deal_id'),'x-title-downloadable':ACRqVdomFTbsvWDhOpkQlUPiEIrMGa.get('downloadable'),'x-title-region':ACRqVdomFTbsvWDhOpkQlUPiEIrMGa.get('region'),'x-title-streamable':ACRqVdomFTbsvWDhOpkQlUPiEIrMGa.get('streamable'),}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcL=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.make_CP_DefaultCookies()
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcX=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.callRequestCookies('Get',ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,payload=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,params=ACRqVdomFTbsvWDhOpkQlUPiEIrMGc,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMcG,cookies=ACRqVdomFTbsvWDhOpkQlUPiEIrMcL,redirects=ACRqVdomFTbsvWDhOpkQlUPiEIrMnH)
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.status_code not in[200]:return '',json.loads(ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.text).get('error').get('detail')
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcK=json.loads(ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.text)
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMGt=='':
    for ACRqVdomFTbsvWDhOpkQlUPiEIrMGn in ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('data').get('raw').get('sources'):
     if 'key_systems' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn and 'codecs' not in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn:
      if ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('type')=='application/dash+xml' and 'com.widevine.alpha' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('key_systems')and ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('src').startswith('https://')==ACRqVdomFTbsvWDhOpkQlUPiEIrMnH:
       ACRqVdomFTbsvWDhOpkQlUPiEIrMGt=ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('src')
       ACRqVdomFTbsvWDhOpkQlUPiEIrMGK =ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMGt=='':
    for ACRqVdomFTbsvWDhOpkQlUPiEIrMGn in ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('data').get('raw').get('sources'):
     if 'key_systems' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn and 'codecs' not in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn:
      if ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('key_systems')and ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('src').startswith('https://')==ACRqVdomFTbsvWDhOpkQlUPiEIrMnH:
       ACRqVdomFTbsvWDhOpkQlUPiEIrMGt=ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('src')
       ACRqVdomFTbsvWDhOpkQlUPiEIrMGK =ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMGt=='':
    for ACRqVdomFTbsvWDhOpkQlUPiEIrMGn in ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('data').get('raw').get('sources'):
     if 'key_systems' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn and 'codecs' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn:
      if ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('type')=='application/dash+xml' and 'com.widevine.alpha' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('key_systems')and ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('src').startswith('https://')==ACRqVdomFTbsvWDhOpkQlUPiEIrMnH:
       ACRqVdomFTbsvWDhOpkQlUPiEIrMGt=ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('src')
       ACRqVdomFTbsvWDhOpkQlUPiEIrMGK =ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMGt=='':
    for ACRqVdomFTbsvWDhOpkQlUPiEIrMGn in ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('data').get('raw').get('sources'):
     if 'key_systems' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn and 'codecs' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn:
      if ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('key_systems')and ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('src').startswith('https://')==ACRqVdomFTbsvWDhOpkQlUPiEIrMnH:
       ACRqVdomFTbsvWDhOpkQlUPiEIrMGt=ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('src')
       ACRqVdomFTbsvWDhOpkQlUPiEIrMGK =ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
  except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ(exception)
   return '',''
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMGt,ACRqVdomFTbsvWDhOpkQlUPiEIrMGK
 def GetEventURL(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,eventId,ACRqVdomFTbsvWDhOpkQlUPiEIrMHS):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMGt=''
  ACRqVdomFTbsvWDhOpkQlUPiEIrMGK =''
  ACRqVdomFTbsvWDhOpkQlUPiEIrMGa=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.Get_eInfo(eventId)
  if ACRqVdomFTbsvWDhOpkQlUPiEIrMGa=={}:return '',''
  try:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcg=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.API_DOMAIN+'/api/playback/play' 
   ACRqVdomFTbsvWDhOpkQlUPiEIrMGc={'titleId':eventId,'titleType':ACRqVdomFTbsvWDhOpkQlUPiEIrMHS,}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcu,ACRqVdomFTbsvWDhOpkQlUPiEIrMcn,ACRqVdomFTbsvWDhOpkQlUPiEIrMcS=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.Make_authHeader()
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcG={'traceparent':ACRqVdomFTbsvWDhOpkQlUPiEIrMcu,'tracestate':ACRqVdomFTbsvWDhOpkQlUPiEIrMcn,'newrelic':ACRqVdomFTbsvWDhOpkQlUPiEIrMcS,'x-force-raw':'true','x-pcid':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['COOKIES']['PCID'],'x-platform':'web','x-profileId':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-downloadable':'undefined','x-title-brightcove-id':ACRqVdomFTbsvWDhOpkQlUPiEIrMGa.get('asset_id'),'x-title-deal-id':ACRqVdomFTbsvWDhOpkQlUPiEIrMGa.get('deal_id'),'x-title-region':ACRqVdomFTbsvWDhOpkQlUPiEIrMGa.get('region'),'x-title-streamable':ACRqVdomFTbsvWDhOpkQlUPiEIrMGa.get('streamable'),}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcL=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.make_CP_DefaultCookies()
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcX=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.callRequestCookies('Get',ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,payload=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,params=ACRqVdomFTbsvWDhOpkQlUPiEIrMGc,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMcG,cookies=ACRqVdomFTbsvWDhOpkQlUPiEIrMcL,redirects=ACRqVdomFTbsvWDhOpkQlUPiEIrMnH)
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.status_code not in[200]:return '',json.loads(ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.text).get('error').get('detail')
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcK=json.loads(ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.text)
   for ACRqVdomFTbsvWDhOpkQlUPiEIrMGn in ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('data').get('raw').get('sources'):
    if ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('type')=='application/dash+xml' and ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('src')[0:8]=='https://':
     ACRqVdomFTbsvWDhOpkQlUPiEIrMGt=ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('src')
     if 'key_systems' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn:
      ACRqVdomFTbsvWDhOpkQlUPiEIrMGK =ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('key_systems').get('com.widevine.alpha').get('license_url')
     break
  except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ(exception)
   return '',''
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMGt,ACRqVdomFTbsvWDhOpkQlUPiEIrMGK
 def GetEventURL_Live(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,eventId,ACRqVdomFTbsvWDhOpkQlUPiEIrMHS):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMGt=''
  ACRqVdomFTbsvWDhOpkQlUPiEIrMGK =''
  ACRqVdomFTbsvWDhOpkQlUPiEIrMGa=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.Get_eInfo(eventId)
  if ACRqVdomFTbsvWDhOpkQlUPiEIrMGa=={}:return '',''
  try:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcg=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.API_DOMAIN+'/api/playback/play' 
   ACRqVdomFTbsvWDhOpkQlUPiEIrMGc={'titleId':eventId,'titleType':ACRqVdomFTbsvWDhOpkQlUPiEIrMHS,}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcu,ACRqVdomFTbsvWDhOpkQlUPiEIrMcn,ACRqVdomFTbsvWDhOpkQlUPiEIrMcS=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.Make_authHeader()
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcG={'traceparent':ACRqVdomFTbsvWDhOpkQlUPiEIrMcu,'tracestate':ACRqVdomFTbsvWDhOpkQlUPiEIrMcn,'newrelic':ACRqVdomFTbsvWDhOpkQlUPiEIrMcS,'x-force-raw':'true','x-pcid':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['COOKIES']['PCID'],'x-platform':'web','x-profileId':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':ACRqVdomFTbsvWDhOpkQlUPiEIrMGa.get('asset_id'),'x-title-deal-id':ACRqVdomFTbsvWDhOpkQlUPiEIrMGa.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':ACRqVdomFTbsvWDhOpkQlUPiEIrMGa.get('region'),'x-title-streamable':ACRqVdomFTbsvWDhOpkQlUPiEIrMGa.get('streamable'),}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcL=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.make_CP_DefaultCookies()
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcX=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.callRequestCookies('Get',ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,payload=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,params=ACRqVdomFTbsvWDhOpkQlUPiEIrMGc,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMcG,cookies=ACRqVdomFTbsvWDhOpkQlUPiEIrMcL,redirects=ACRqVdomFTbsvWDhOpkQlUPiEIrMnH)
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.status_code not in[200]:return '',json.loads(ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.text).get('error').get('detail')
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcK=json.loads(ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.text)
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMGt=='':
    for ACRqVdomFTbsvWDhOpkQlUPiEIrMGn in ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('data').get('raw').get('sources'):
     if 'key_systems' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn:
      if ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('type')=='application/dash+xml' and 'com.widevine.alpha' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('key_systems')and ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('src').startswith('https://')==ACRqVdomFTbsvWDhOpkQlUPiEIrMnH:
       ACRqVdomFTbsvWDhOpkQlUPiEIrMGt=ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('src')
       ACRqVdomFTbsvWDhOpkQlUPiEIrMGK =ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('key_systems').get('com.widevine.alpha').get('license_url')
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMGt=='':
    for ACRqVdomFTbsvWDhOpkQlUPiEIrMGn in ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('data').get('raw').get('sources'):
     if 'key_systems' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn:
      if ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('key_systems')and ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('src').startswith('https://')==ACRqVdomFTbsvWDhOpkQlUPiEIrMnH:
       ACRqVdomFTbsvWDhOpkQlUPiEIrMGt=ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('src')
       ACRqVdomFTbsvWDhOpkQlUPiEIrMGK =ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('key_systems').get('com.widevine.alpha').get('license_url')
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMGt=='':
    for ACRqVdomFTbsvWDhOpkQlUPiEIrMGn in ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('data').get('raw').get('sources'):
     if ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('type')=='application/dash+xml' and ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('src').startswith('https://')==ACRqVdomFTbsvWDhOpkQlUPiEIrMnH:
      ACRqVdomFTbsvWDhOpkQlUPiEIrMGt=ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('src')
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMGt=='':
    for ACRqVdomFTbsvWDhOpkQlUPiEIrMGn in ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('data').get('raw').get('sources'):
     if ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('type')=='application/x-mpegURL' and ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('src').startswith('https://')==ACRqVdomFTbsvWDhOpkQlUPiEIrMnH:
      ACRqVdomFTbsvWDhOpkQlUPiEIrMGt=ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('src')
  except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ(exception)
   return '',''
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMGt,ACRqVdomFTbsvWDhOpkQlUPiEIrMGK
 def Get_Url_PostFix(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,in_url):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMGJ=urllib.parse.urlparse(in_url) 
  ACRqVdomFTbsvWDhOpkQlUPiEIrMGe =ACRqVdomFTbsvWDhOpkQlUPiEIrMGJ.path.strip('/').split('/')
  ACRqVdomFTbsvWDhOpkQlUPiEIrMGz =ACRqVdomFTbsvWDhOpkQlUPiEIrMGe[ACRqVdomFTbsvWDhOpkQlUPiEIrMnc(ACRqVdomFTbsvWDhOpkQlUPiEIrMGe)-1]
  ACRqVdomFTbsvWDhOpkQlUPiEIrMGy=ACRqVdomFTbsvWDhOpkQlUPiEIrMGz.split('.')
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMGy[ACRqVdomFTbsvWDhOpkQlUPiEIrMnc(ACRqVdomFTbsvWDhOpkQlUPiEIrMGy)-1]
 def Get_Theme_GroupList(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,vType):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMGY=[] 
  try:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcg=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.API_DOMAIN+'/api-discover/v3/discover/feed' 
   ACRqVdomFTbsvWDhOpkQlUPiEIrMGc={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':ACRqVdomFTbsvWDhOpkQlUPiEIrMue(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.PAGE_LIMIT),'filterRestrictedContent':'false','preferRecoFeed':'true','preferMultiHeroMixedContentRow':'true','shouldIncludeTVOD':'true','includeChannelContents':'false',}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcX=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.callRequestCookies('Get',ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,payload=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,params=ACRqVdomFTbsvWDhOpkQlUPiEIrMGc,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,cookies=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,redirects=ACRqVdomFTbsvWDhOpkQlUPiEIrMnH)
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.status_code not in[200]:return[]
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcK=json.loads(ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.text)
   for ACRqVdomFTbsvWDhOpkQlUPiEIrMGn in ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('data'):
    if ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('type')=='Title-Rails-Curation':
     ACRqVdomFTbsvWDhOpkQlUPiEIrMHY =''
     ACRqVdomFTbsvWDhOpkQlUPiEIrMHc=7
     try:
      for i in ACRqVdomFTbsvWDhOpkQlUPiEIrMnu(ACRqVdomFTbsvWDhOpkQlUPiEIrMnc(ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('data'))):
       if i>=ACRqVdomFTbsvWDhOpkQlUPiEIrMHc:
        ACRqVdomFTbsvWDhOpkQlUPiEIrMHY=ACRqVdomFTbsvWDhOpkQlUPiEIrMHY+'...'
        break
       ACRqVdomFTbsvWDhOpkQlUPiEIrMHY=ACRqVdomFTbsvWDhOpkQlUPiEIrMHY+ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['data'][i]['title']+'\n'
     except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
      ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ(exception)
     ACRqVdomFTbsvWDhOpkQlUPiEIrMGf={'collectionId':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('obj_id'),'title':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('row_name'),'category':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('category'),'pre_title':ACRqVdomFTbsvWDhOpkQlUPiEIrMHY,}
     ACRqVdomFTbsvWDhOpkQlUPiEIrMGY.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGf)
  except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ(exception)
   return[]
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMGY
 def Get_Event_GroupList(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMGY=[] 
  try:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcg=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.API_DOMAIN+'/api-discover/v3/discover/feed' 
   ACRqVdomFTbsvWDhOpkQlUPiEIrMGc={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':7,'filterRestrictedContent':'false','preferRecoFeed':'true','preferMultiHeroMixedContentRow':'true','shouldIncludeTVOD':'true','includeChannelContents':'false',}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcX=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.callRequestCookies('Get',ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,payload=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,params=ACRqVdomFTbsvWDhOpkQlUPiEIrMGc,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,cookies=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,redirects=ACRqVdomFTbsvWDhOpkQlUPiEIrMnH)
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.status_code not in[200]:return[]
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcK=json.loads(ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.text)
   for ACRqVdomFTbsvWDhOpkQlUPiEIrMGn in ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('data'):
    if ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('row_name').strip()!='':
     ACRqVdomFTbsvWDhOpkQlUPiEIrMHY =''
     ACRqVdomFTbsvWDhOpkQlUPiEIrMHc=7
     try:
      for i in ACRqVdomFTbsvWDhOpkQlUPiEIrMnu(ACRqVdomFTbsvWDhOpkQlUPiEIrMnc(ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('data'))):
       if i>=ACRqVdomFTbsvWDhOpkQlUPiEIrMHc:
        ACRqVdomFTbsvWDhOpkQlUPiEIrMHY=ACRqVdomFTbsvWDhOpkQlUPiEIrMHY+'...'
        break
       ACRqVdomFTbsvWDhOpkQlUPiEIrMHY=ACRqVdomFTbsvWDhOpkQlUPiEIrMHY+ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['data'][i]['title']+'\n'
     except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
      ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ(exception)
     ACRqVdomFTbsvWDhOpkQlUPiEIrMGf={'collectionId':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('obj_id'),'title':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('row_name'),'category':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('type'),'pre_title':ACRqVdomFTbsvWDhOpkQlUPiEIrMHY,}
     ACRqVdomFTbsvWDhOpkQlUPiEIrMGY.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGf)
  except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ(exception)
   return[]
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMGY
 def Get_Event_GameList(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,ACRqVdomFTbsvWDhOpkQlUPiEIrMGS):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMGY=[] 
  try:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcg=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.API_DOMAIN+'/api-discover/v3/discover/feed' 
   ACRqVdomFTbsvWDhOpkQlUPiEIrMGc={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':7,'filterRestrictedContent':'false','preferRecoFeed':'true','preferMultiHeroMixedContentRow':'true','shouldIncludeTVOD':'true','includeChannelContents':'false',}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcX=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.callRequestCookies('Get',ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,payload=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,params=ACRqVdomFTbsvWDhOpkQlUPiEIrMGc,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,cookies=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,redirects=ACRqVdomFTbsvWDhOpkQlUPiEIrMnH)
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.status_code not in[200]:return[]
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcK=json.loads(ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.text)
   for ACRqVdomFTbsvWDhOpkQlUPiEIrMGn in ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('data'):
    if ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('obj_id')==ACRqVdomFTbsvWDhOpkQlUPiEIrMGS:
     for ACRqVdomFTbsvWDhOpkQlUPiEIrMHG in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('data'):
      ACRqVdomFTbsvWDhOpkQlUPiEIrMGg=ACRqVdomFTbsvWDhOpkQlUPiEIrMGx=ACRqVdomFTbsvWDhOpkQlUPiEIrMHL=''
      if 'poster_url' in ACRqVdomFTbsvWDhOpkQlUPiEIrMHG.get('images'):ACRqVdomFTbsvWDhOpkQlUPiEIrMGg =ACRqVdomFTbsvWDhOpkQlUPiEIrMHG.get('images').get('poster_url') +'?imwidth=350'
      if 'story_art_url' in ACRqVdomFTbsvWDhOpkQlUPiEIrMHG.get('images'):ACRqVdomFTbsvWDhOpkQlUPiEIrMGx =ACRqVdomFTbsvWDhOpkQlUPiEIrMHG.get('images').get('story_art_url')+'?imwidth=600'
      if 'hero_url' in ACRqVdomFTbsvWDhOpkQlUPiEIrMHG.get('images'):ACRqVdomFTbsvWDhOpkQlUPiEIrMHL =ACRqVdomFTbsvWDhOpkQlUPiEIrMHG.get('images').get('hero_url') +'?imwidth=600'
      ACRqVdomFTbsvWDhOpkQlUPiEIrMGf={'id':ACRqVdomFTbsvWDhOpkQlUPiEIrMHG.get('id'),'title':ACRqVdomFTbsvWDhOpkQlUPiEIrMHG.get('title'),'thumbnail':{'poster':ACRqVdomFTbsvWDhOpkQlUPiEIrMGg,'thumb':ACRqVdomFTbsvWDhOpkQlUPiEIrMGx,'fanart':ACRqVdomFTbsvWDhOpkQlUPiEIrMHL},'asis':ACRqVdomFTbsvWDhOpkQlUPiEIrMHG.get('type'),'starttm':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.convert_TimeStr(ACRqVdomFTbsvWDhOpkQlUPiEIrMHG.get('startAt')),}
      ACRqVdomFTbsvWDhOpkQlUPiEIrMGY.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGf)
  except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ(exception)
   return[]
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMGY
 def Get_Event_List(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,gameId):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMGY=[] 
  try:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcg=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.API_DOMAIN+'/api-discover/v1/discover/events/'+gameId 
   ACRqVdomFTbsvWDhOpkQlUPiEIrMGc={'platform':'WEBCLIENT','locale':'ko','filterRestrictedContent':'false',}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcX=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.callRequestCookies('Get',ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,payload=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,params=ACRqVdomFTbsvWDhOpkQlUPiEIrMGc,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,cookies=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,redirects=ACRqVdomFTbsvWDhOpkQlUPiEIrMnH)
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.status_code not in[200]:return[]
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcK=json.loads(ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.text)
   ACRqVdomFTbsvWDhOpkQlUPiEIrMGn=ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('data')
   ACRqVdomFTbsvWDhOpkQlUPiEIrMHu=ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('end_at')
   ACRqVdomFTbsvWDhOpkQlUPiEIrMHu=ACRqVdomFTbsvWDhOpkQlUPiEIrMHu[0:19].replace('-','').replace(':','').replace('T','')
   ACRqVdomFTbsvWDhOpkQlUPiEIrMHn=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d%H%M%S')
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMnY(ACRqVdomFTbsvWDhOpkQlUPiEIrMHn)<ACRqVdomFTbsvWDhOpkQlUPiEIrMnY(ACRqVdomFTbsvWDhOpkQlUPiEIrMHu):
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGg=ACRqVdomFTbsvWDhOpkQlUPiEIrMGx=ACRqVdomFTbsvWDhOpkQlUPiEIrMHL=''
    if 'poster' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images'):ACRqVdomFTbsvWDhOpkQlUPiEIrMGg =ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images'):ACRqVdomFTbsvWDhOpkQlUPiEIrMGx =ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images').get('story-art').get('url')+'?imwidth=600'
    if 'story-art' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images'):ACRqVdomFTbsvWDhOpkQlUPiEIrMHL =ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images').get('story-art').get('url')+'?imwidth=600'
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGf={'id':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('id'),'title':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('title'),'thumbnail':{'poster':ACRqVdomFTbsvWDhOpkQlUPiEIrMGg,'thumb':ACRqVdomFTbsvWDhOpkQlUPiEIrMGx,'fanart':ACRqVdomFTbsvWDhOpkQlUPiEIrMHL},'duration':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('running_time'),'asis':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('type'),'starttm':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.convert_TimeStr(ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('start_at')),}
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGY.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGf)
  except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ(exception)
   return[]
  try:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcg=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.API_DOMAIN+'/api-discover/v1/discover/events/'+gameId+'/related' 
   ACRqVdomFTbsvWDhOpkQlUPiEIrMGc={'locale':'ko','page':'1','perPage':'25','platform':'WEBCLIENT','currentPageTracking':'page_discover_title_detail',}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcX=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.callRequestCookies('Get',ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,payload=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,params=ACRqVdomFTbsvWDhOpkQlUPiEIrMGc,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,cookies=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,redirects=ACRqVdomFTbsvWDhOpkQlUPiEIrMnH)
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.status_code not in[200]:return[]
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcK=json.loads(ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.text)
   for ACRqVdomFTbsvWDhOpkQlUPiEIrMGn in ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('data').get('data'):
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGg=ACRqVdomFTbsvWDhOpkQlUPiEIrMGx=ACRqVdomFTbsvWDhOpkQlUPiEIrMHL=''
    if 'poster' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images'):ACRqVdomFTbsvWDhOpkQlUPiEIrMGg =ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images'):ACRqVdomFTbsvWDhOpkQlUPiEIrMGx =ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images').get('story-art').get('url')+'?imwidth=600'
    if 'story-art' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images'):ACRqVdomFTbsvWDhOpkQlUPiEIrMHL =ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images').get('story-art').get('url')+'?imwidth=600'
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGf={'id':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('id'),'title':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('title'),'thumbnail':{'poster':ACRqVdomFTbsvWDhOpkQlUPiEIrMGg,'thumb':ACRqVdomFTbsvWDhOpkQlUPiEIrMGx,'fanart':ACRqVdomFTbsvWDhOpkQlUPiEIrMHL},'duration':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('running_time'),'asis':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('type'),}
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGY.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGf)
  except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ(exception)
   return[]
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMGY
 def Get_Search_List_back(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,search_key,page_int):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMGY=[] 
  ACRqVdomFTbsvWDhOpkQlUPiEIrMGj=ACRqVdomFTbsvWDhOpkQlUPiEIrMuK
  try:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcg=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.API_DOMAIN+'/api-discover/v2/search' 
   ACRqVdomFTbsvWDhOpkQlUPiEIrMGc={'query':search_key,'platform':'WEBCLIENT','page':ACRqVdomFTbsvWDhOpkQlUPiEIrMue(page_int),'perPage':ACRqVdomFTbsvWDhOpkQlUPiEIrMue(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.SEARCH_LIMIT),}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcG={'x-membersrl':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['COOKIES']['member_srl'],'x-pcid':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['COOKIES']['PCID'],'x-profileid':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT',}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcX=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.callRequestCookies('Get',ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,payload=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,params=ACRqVdomFTbsvWDhOpkQlUPiEIrMGc,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMcG,cookies=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,redirects=ACRqVdomFTbsvWDhOpkQlUPiEIrMnH)
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.status_code not in[200]:return[],ACRqVdomFTbsvWDhOpkQlUPiEIrMuK
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcK=json.loads(ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.text)
   for ACRqVdomFTbsvWDhOpkQlUPiEIrMGn in ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('data').get('data'):
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGn=ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('data')
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGg=ACRqVdomFTbsvWDhOpkQlUPiEIrMGx=ACRqVdomFTbsvWDhOpkQlUPiEIrMHX=ACRqVdomFTbsvWDhOpkQlUPiEIrMHL=''
    if 'poster' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images'):ACRqVdomFTbsvWDhOpkQlUPiEIrMGg =ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images'):ACRqVdomFTbsvWDhOpkQlUPiEIrMGx =ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images').get('story-art').get('url') +'?imwidth=600'
    if 'title-treatment' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images'):ACRqVdomFTbsvWDhOpkQlUPiEIrMHX=ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images').get('title-treatment').get('url')+'?imwidth=300'
    if 'story-art' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images'):ACRqVdomFTbsvWDhOpkQlUPiEIrMHL =ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images').get('story-art').get('url') +'?imwidth=600'
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGL=''
    if ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('badge')not in[{},ACRqVdomFTbsvWDhOpkQlUPiEIrMut]:
     for i in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('badge').get('text'):
      if ACRqVdomFTbsvWDhOpkQlUPiEIrMGL!='':ACRqVdomFTbsvWDhOpkQlUPiEIrMGL+=' '
      ACRqVdomFTbsvWDhOpkQlUPiEIrMGL+=i.get('text')
    if 'as' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn:
     ACRqVdomFTbsvWDhOpkQlUPiEIrMHS=ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('as') 
    else:
     ACRqVdomFTbsvWDhOpkQlUPiEIrMHS=ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('type')
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGf={'id':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('id'),'title':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('title'),'asis':ACRqVdomFTbsvWDhOpkQlUPiEIrMHS,'thumbnail':{'poster':ACRqVdomFTbsvWDhOpkQlUPiEIrMGg,'thumb':ACRqVdomFTbsvWDhOpkQlUPiEIrMGx,'clearlogo':ACRqVdomFTbsvWDhOpkQlUPiEIrMHX,'fanart':ACRqVdomFTbsvWDhOpkQlUPiEIrMHL},'mpaa':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('age_rating'),'duration':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('running_time'),'badge':ACRqVdomFTbsvWDhOpkQlUPiEIrMGL,'year':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('meta').get('releaseYear'),}
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGY.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGf)
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('pagination').get('totalPages')>page_int:
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGj=ACRqVdomFTbsvWDhOpkQlUPiEIrMnH
  except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ(exception)
   return[],ACRqVdomFTbsvWDhOpkQlUPiEIrMuK
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMGY,ACRqVdomFTbsvWDhOpkQlUPiEIrMGj
 def Get_Search_List(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,search_key,page_int):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMGY=[] 
  ACRqVdomFTbsvWDhOpkQlUPiEIrMGj=ACRqVdomFTbsvWDhOpkQlUPiEIrMuK
  try:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcg=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.API_DOMAIN+'/api-discover/v3/search'
   ACRqVdomFTbsvWDhOpkQlUPiEIrMGc={'query':search_key,'platform':'WEBCLIENT','page':ACRqVdomFTbsvWDhOpkQlUPiEIrMue(page_int),'perPage':'48','filterSearchGroupTypes':'','filterSearchGroupType':'TITLES-EVENT_LIVE-EVENT_CHANNELS','includeChannelContents':'true','includeSportsChannelContents':'true',}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcG={'x-membersrl':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['COOKIES']['member_srl'],'x-pcid':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['COOKIES']['PCID'],'x-profileid':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['SESSION']['profileId'],}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcX=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.callRequestCookies('Get',ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,payload=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,params=ACRqVdomFTbsvWDhOpkQlUPiEIrMGc,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMcG,cookies=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,redirects=ACRqVdomFTbsvWDhOpkQlUPiEIrMnH)
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.status_code not in[200]:return[],ACRqVdomFTbsvWDhOpkQlUPiEIrMuK
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcK=json.loads(ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.text)
   for ACRqVdomFTbsvWDhOpkQlUPiEIrMGn in ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('data').get('contents'):
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGg=ACRqVdomFTbsvWDhOpkQlUPiEIrMGx=ACRqVdomFTbsvWDhOpkQlUPiEIrMHX=ACRqVdomFTbsvWDhOpkQlUPiEIrMHL=''
    if 'poster_url' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images'):ACRqVdomFTbsvWDhOpkQlUPiEIrMGg =ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images').get('poster_url') +'?imwidth=350'
    if 'story_art_url' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images'):ACRqVdomFTbsvWDhOpkQlUPiEIrMGx =ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images').get('story_art_url') +'?imwidth=600'
    if 'title_treatment_url' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images'):ACRqVdomFTbsvWDhOpkQlUPiEIrMHX=ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images').get('title_treatment_url')+'?imwidth=300'
    if 'story_art_url' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images'):ACRqVdomFTbsvWDhOpkQlUPiEIrMHL =ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('images').get('story_art_url') +'?imwidth=600'
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGL=''
    if ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('badge')not in[{},ACRqVdomFTbsvWDhOpkQlUPiEIrMut]:
     for i in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('badge').get('text'):
      if ACRqVdomFTbsvWDhOpkQlUPiEIrMGL!='':ACRqVdomFTbsvWDhOpkQlUPiEIrMGL+=' '
      ACRqVdomFTbsvWDhOpkQlUPiEIrMGL+=i.get('text')
    ACRqVdomFTbsvWDhOpkQlUPiEIrMHS=ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('sub_type') 
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGf={'id':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('id'),'title':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('title'),'asis':ACRqVdomFTbsvWDhOpkQlUPiEIrMHS,'thumbnail':{'poster':ACRqVdomFTbsvWDhOpkQlUPiEIrMGg,'thumb':ACRqVdomFTbsvWDhOpkQlUPiEIrMGx,'clearlogo':ACRqVdomFTbsvWDhOpkQlUPiEIrMHX,'fanart':ACRqVdomFTbsvWDhOpkQlUPiEIrMHL},'mpaa':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('ageRatingLocalized'),'duration':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('running_time'),'badge':ACRqVdomFTbsvWDhOpkQlUPiEIrMGL,'year':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('airing_date_friendly')[8:12]}
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGY.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGf)
  except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ(exception)
   return[],ACRqVdomFTbsvWDhOpkQlUPiEIrMuK
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMGY,ACRqVdomFTbsvWDhOpkQlUPiEIrMGj
 def GetBookmarkInfo(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,videoid,vidtype):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMHf={'indexinfo':{'ott':'coupang','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  ACRqVdomFTbsvWDhOpkQlUPiEIrMcg=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.API_DOMAIN+'/api-discover/v1/discover/titles/'+videoid 
  ACRqVdomFTbsvWDhOpkQlUPiEIrMGc={'locale':'ko'}
  ACRqVdomFTbsvWDhOpkQlUPiEIrMcX=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.callRequestCookies('Get',ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,payload=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,params=ACRqVdomFTbsvWDhOpkQlUPiEIrMGc,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,cookies=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,redirects=ACRqVdomFTbsvWDhOpkQlUPiEIrMnH)
  if ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.status_code not in[200]:return{}
  ACRqVdomFTbsvWDhOpkQlUPiEIrMHj=json.loads(ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.text).get('data')
  ACRqVdomFTbsvWDhOpkQlUPiEIrMHN=ACRqVdomFTbsvWDhOpkQlUPiEIrMHj.get('title')
  ACRqVdomFTbsvWDhOpkQlUPiEIrMHg =ACRqVdomFTbsvWDhOpkQlUPiEIrMHj.get('meta').get('releaseYear')
  ACRqVdomFTbsvWDhOpkQlUPiEIrMHf['saveinfo']['infoLabels']['title']=ACRqVdomFTbsvWDhOpkQlUPiEIrMHN
  if vidtype=='movie':
   ACRqVdomFTbsvWDhOpkQlUPiEIrMHN='%s  (%s)'%(ACRqVdomFTbsvWDhOpkQlUPiEIrMHN,ACRqVdomFTbsvWDhOpkQlUPiEIrMHg)
  ACRqVdomFTbsvWDhOpkQlUPiEIrMHf['saveinfo']['title'] =ACRqVdomFTbsvWDhOpkQlUPiEIrMHN
  ACRqVdomFTbsvWDhOpkQlUPiEIrMHf['saveinfo']['infoLabels']['mpaa'] =ACRqVdomFTbsvWDhOpkQlUPiEIrMHj.get('age_rating')
  ACRqVdomFTbsvWDhOpkQlUPiEIrMHf['saveinfo']['infoLabels']['plot'] ='%s\n\n%s'%(ACRqVdomFTbsvWDhOpkQlUPiEIrMHj.get('short_description'),ACRqVdomFTbsvWDhOpkQlUPiEIrMHj.get('description'))
  ACRqVdomFTbsvWDhOpkQlUPiEIrMHf['saveinfo']['infoLabels']['year'] =ACRqVdomFTbsvWDhOpkQlUPiEIrMHg
  if vidtype=='movie':
   ACRqVdomFTbsvWDhOpkQlUPiEIrMHf['saveinfo']['infoLabels']['duration']=ACRqVdomFTbsvWDhOpkQlUPiEIrMHj.get('running_time')
  ACRqVdomFTbsvWDhOpkQlUPiEIrMGg =''
  ACRqVdomFTbsvWDhOpkQlUPiEIrMHL =''
  ACRqVdomFTbsvWDhOpkQlUPiEIrMGx =''
  ACRqVdomFTbsvWDhOpkQlUPiEIrMHX=''
  if ACRqVdomFTbsvWDhOpkQlUPiEIrMHj.get('images').get('poster') !=ACRqVdomFTbsvWDhOpkQlUPiEIrMut:ACRqVdomFTbsvWDhOpkQlUPiEIrMGg =ACRqVdomFTbsvWDhOpkQlUPiEIrMHj.get('images').get('poster').get('url') +'?imwidth=350'
  if ACRqVdomFTbsvWDhOpkQlUPiEIrMHj.get('images').get('background') !=ACRqVdomFTbsvWDhOpkQlUPiEIrMut:ACRqVdomFTbsvWDhOpkQlUPiEIrMHL =ACRqVdomFTbsvWDhOpkQlUPiEIrMHj.get('images').get('background').get('url') +'?imwidth=600'
  if ACRqVdomFTbsvWDhOpkQlUPiEIrMHj.get('images').get('story-art') !=ACRqVdomFTbsvWDhOpkQlUPiEIrMut:ACRqVdomFTbsvWDhOpkQlUPiEIrMGx =ACRqVdomFTbsvWDhOpkQlUPiEIrMHj.get('images').get('story-art').get('url') +'?imwidth=600'
  if ACRqVdomFTbsvWDhOpkQlUPiEIrMHj.get('images').get('title-treatment')!=ACRqVdomFTbsvWDhOpkQlUPiEIrMut:ACRqVdomFTbsvWDhOpkQlUPiEIrMHX=ACRqVdomFTbsvWDhOpkQlUPiEIrMHj.get('images').get('title-treatment').get('url')+'?imwidth=300'
  if ACRqVdomFTbsvWDhOpkQlUPiEIrMHL=='':ACRqVdomFTbsvWDhOpkQlUPiEIrMHL=ACRqVdomFTbsvWDhOpkQlUPiEIrMGx
  ACRqVdomFTbsvWDhOpkQlUPiEIrMHf['saveinfo']['thumbnail']['poster']=ACRqVdomFTbsvWDhOpkQlUPiEIrMGg
  ACRqVdomFTbsvWDhOpkQlUPiEIrMHf['saveinfo']['thumbnail']['fanart']=ACRqVdomFTbsvWDhOpkQlUPiEIrMHL
  ACRqVdomFTbsvWDhOpkQlUPiEIrMHf['saveinfo']['thumbnail']['thumb']=ACRqVdomFTbsvWDhOpkQlUPiEIrMGx
  ACRqVdomFTbsvWDhOpkQlUPiEIrMHf['saveinfo']['thumbnail']['clearlogo']=ACRqVdomFTbsvWDhOpkQlUPiEIrMHX
  ACRqVdomFTbsvWDhOpkQlUPiEIrMHw=[]
  for ACRqVdomFTbsvWDhOpkQlUPiEIrMGB in ACRqVdomFTbsvWDhOpkQlUPiEIrMHj.get('tags'):ACRqVdomFTbsvWDhOpkQlUPiEIrMHw.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGB.get('tag'))
  if ACRqVdomFTbsvWDhOpkQlUPiEIrMnc(ACRqVdomFTbsvWDhOpkQlUPiEIrMHw)>0:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMHf['saveinfo']['infoLabels']['genre']=ACRqVdomFTbsvWDhOpkQlUPiEIrMHw
  ACRqVdomFTbsvWDhOpkQlUPiEIrMHB=[]
  ACRqVdomFTbsvWDhOpkQlUPiEIrMHx=[]
  for ACRqVdomFTbsvWDhOpkQlUPiEIrMGB in ACRqVdomFTbsvWDhOpkQlUPiEIrMHj.get('people'):
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMGB.get('role')=='CAST' :ACRqVdomFTbsvWDhOpkQlUPiEIrMHB.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGB.get('name'))
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMGB.get('role')=='DIRECTOR':ACRqVdomFTbsvWDhOpkQlUPiEIrMHx.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGB.get('name'))
  if ACRqVdomFTbsvWDhOpkQlUPiEIrMnc(ACRqVdomFTbsvWDhOpkQlUPiEIrMHB)>0:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMHf['saveinfo']['infoLabels']['cast'] =ACRqVdomFTbsvWDhOpkQlUPiEIrMHB
  if ACRqVdomFTbsvWDhOpkQlUPiEIrMnc(ACRqVdomFTbsvWDhOpkQlUPiEIrMHx)>0:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMHf['saveinfo']['infoLabels']['director']=ACRqVdomFTbsvWDhOpkQlUPiEIrMHx
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMHf
 def MakeText_FreeList(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,search_list,titleName='title'):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMHa=''
  ACRqVdomFTbsvWDhOpkQlUPiEIrMHt=5
  try:
   for i in ACRqVdomFTbsvWDhOpkQlUPiEIrMnu(ACRqVdomFTbsvWDhOpkQlUPiEIrMnc(search_list)):
    if i>=ACRqVdomFTbsvWDhOpkQlUPiEIrMHt:
     ACRqVdomFTbsvWDhOpkQlUPiEIrMHa=ACRqVdomFTbsvWDhOpkQlUPiEIrMHa+'...'
     break
    ACRqVdomFTbsvWDhOpkQlUPiEIrMHa=ACRqVdomFTbsvWDhOpkQlUPiEIrMHa+search_list[i][titleName]+'\n'
  except:
   return ''
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMHa
 def Sports_Mainlist_League(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMHK=[] 
  try:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcg='{}/api-discover/v1/sports/leagues/pills'.format(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.API_DOMAIN)
   ACRqVdomFTbsvWDhOpkQlUPiEIrMGc={'platform':'WEBCLIENT','useCircularLogo':'true',}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcX=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.callRequestCookies('Get',ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,payload=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,params=ACRqVdomFTbsvWDhOpkQlUPiEIrMGc,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,cookies=ACRqVdomFTbsvWDhOpkQlUPiEIrMut)
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.status_code not in[200]:return[]
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcK=json.loads(ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.text)
   for ACRqVdomFTbsvWDhOpkQlUPiEIrMGn in ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('data'):
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGf={'league_id':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['id'],'league_name':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['name'],'logoUrl':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['logoUrl'],}
    ACRqVdomFTbsvWDhOpkQlUPiEIrMHK.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGf)
  except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ(exception)
   return[]
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMHK
 def Sports_League_FeedList(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,leagueID):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMHJ=[] 
  try:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcg='{}/api-discover/v1/discover/sports/leagues/{}/feed'.format(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.API_DOMAIN,leagueID)
   ACRqVdomFTbsvWDhOpkQlUPiEIrMGc={'platform':'WEBCLIENT','region':'KR','locale':'ko','includeSportsChannelContents':'true',}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcX=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.callRequestCookies('Get',ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,payload=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,params=ACRqVdomFTbsvWDhOpkQlUPiEIrMGc,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,cookies=ACRqVdomFTbsvWDhOpkQlUPiEIrMut)
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.status_code not in[200]:return[]
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcK=json.loads(ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.text).get('data')
   for ACRqVdomFTbsvWDhOpkQlUPiEIrMGn in ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('data'):
    if ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['type']=='Calendar':
     ACRqVdomFTbsvWDhOpkQlUPiEIrMHe =ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.Sports_leagueHome_Livelist(leagueID)
     if ACRqVdomFTbsvWDhOpkQlUPiEIrMHe:
      ACRqVdomFTbsvWDhOpkQlUPiEIrMHz =ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.MakeText_FreeList(ACRqVdomFTbsvWDhOpkQlUPiEIrMHe,titleName='preTitle')
      ACRqVdomFTbsvWDhOpkQlUPiEIrMGf={'row_name':'@ 예정 경기 @','preText':ACRqVdomFTbsvWDhOpkQlUPiEIrMHz,'subMode':'SP_FEED_LIVE','image':ACRqVdomFTbsvWDhOpkQlUPiEIrMHe[0]['image'],}
      ACRqVdomFTbsvWDhOpkQlUPiEIrMHJ.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGf)
    elif ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['type']=='Live-Events-Curation':
     ACRqVdomFTbsvWDhOpkQlUPiEIrMHe =ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.Sports_LeagueHome_List(data=ACRqVdomFTbsvWDhOpkQlUPiEIrMGn,sType='top10')
     if ACRqVdomFTbsvWDhOpkQlUPiEIrMHe:
      ACRqVdomFTbsvWDhOpkQlUPiEIrMHz =ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.MakeText_FreeList(ACRqVdomFTbsvWDhOpkQlUPiEIrMHe,titleName='title')
      ACRqVdomFTbsvWDhOpkQlUPiEIrMGf={'row_name':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['row_name'],'preText':ACRqVdomFTbsvWDhOpkQlUPiEIrMHz,'subMode':'SP_FEED_TOP10','image':ACRqVdomFTbsvWDhOpkQlUPiEIrMHe[0]['image'],}
      ACRqVdomFTbsvWDhOpkQlUPiEIrMHJ.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGf)
    elif ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['type']=='Live-Sports-Matches':
     ACRqVdomFTbsvWDhOpkQlUPiEIrMHe =ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.Sports_LeagueHome_List(data=ACRqVdomFTbsvWDhOpkQlUPiEIrMGn,sType='gameVod')
     for ACRqVdomFTbsvWDhOpkQlUPiEIrMHy in ACRqVdomFTbsvWDhOpkQlUPiEIrMHe:
      ACRqVdomFTbsvWDhOpkQlUPiEIrMGf={'row_name':'{} <{}>'.format(ACRqVdomFTbsvWDhOpkQlUPiEIrMHy['title'],ACRqVdomFTbsvWDhOpkQlUPiEIrMHy['startDate']),'preText':ACRqVdomFTbsvWDhOpkQlUPiEIrMHy['preText'],'subMode':'SP_FEED_GAME','gameID':ACRqVdomFTbsvWDhOpkQlUPiEIrMHy['id'],'image':ACRqVdomFTbsvWDhOpkQlUPiEIrMHy['image'],}
      ACRqVdomFTbsvWDhOpkQlUPiEIrMHJ.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGf)
  except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ(exception)
   return[]
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMHJ
 def Sports_League_VodList(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,subMode,leagueID,gameID):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMuY=[] 
  try:
   if subMode=='SP_FEED_LIVE':
    ACRqVdomFTbsvWDhOpkQlUPiEIrMHe =ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.Sports_leagueHome_Livelist(leagueID)
    for ACRqVdomFTbsvWDhOpkQlUPiEIrMHy in ACRqVdomFTbsvWDhOpkQlUPiEIrMHe:
     ACRqVdomFTbsvWDhOpkQlUPiEIrMGf={'id':ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('event_id'),'title':ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('title'),'image':ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('image'),'startDate':ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('startDate'),'subType':ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('subType'),}
     ACRqVdomFTbsvWDhOpkQlUPiEIrMuY.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGf)
   elif subMode in['SP_FEED_TOP10','SP_FEED_GAME']:
    ACRqVdomFTbsvWDhOpkQlUPiEIrMcg='{}/api-discover/v1/discover/sports/leagues/{}/feed'.format(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.API_DOMAIN,leagueID)
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGc={'platform':'WEBCLIENT','region':'KR','locale':'ko','includeSportsChannelContents':'true',}
    ACRqVdomFTbsvWDhOpkQlUPiEIrMcX=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.callRequestCookies('Get',ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,payload=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,params=ACRqVdomFTbsvWDhOpkQlUPiEIrMGc,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,cookies=ACRqVdomFTbsvWDhOpkQlUPiEIrMut)
    if ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.status_code not in[200]:return[]
    ACRqVdomFTbsvWDhOpkQlUPiEIrMcK=json.loads(ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.text).get('data')
    for ACRqVdomFTbsvWDhOpkQlUPiEIrMGn in ACRqVdomFTbsvWDhOpkQlUPiEIrMcK.get('data'):
     if ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['type']=='Live-Events-Curation' and subMode=='SP_FEED_TOP10':
      ACRqVdomFTbsvWDhOpkQlUPiEIrMHe =ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.Sports_LeagueHome_List(data=ACRqVdomFTbsvWDhOpkQlUPiEIrMGn,sType='top10')
      for ACRqVdomFTbsvWDhOpkQlUPiEIrMHy in ACRqVdomFTbsvWDhOpkQlUPiEIrMHe:
       ACRqVdomFTbsvWDhOpkQlUPiEIrMGf={'id':ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('id'),'title':ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('title'),'image':ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('image'),'startDate':ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('startDate'),'subType':ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('subType'),'running_time':ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('running_time'),}
       ACRqVdomFTbsvWDhOpkQlUPiEIrMuY.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGf)
     elif ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['type']=='Live-Sports-Matches' and subMode=='SP_FEED_GAME':
      for ACRqVdomFTbsvWDhOpkQlUPiEIrMuc in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['data']:
       if gameID==ACRqVdomFTbsvWDhOpkQlUPiEIrMuc['id']:
        ACRqVdomFTbsvWDhOpkQlUPiEIrMHe =ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.Sports_LeagueHome_SubVods(data=ACRqVdomFTbsvWDhOpkQlUPiEIrMuc)
        for ACRqVdomFTbsvWDhOpkQlUPiEIrMHy in ACRqVdomFTbsvWDhOpkQlUPiEIrMHe:
         ACRqVdomFTbsvWDhOpkQlUPiEIrMGf={'id':ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('id'),'title':ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('title'),'image':ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('image'),'subType':ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('subType'),'running_time':ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('running_time'),}
         ACRqVdomFTbsvWDhOpkQlUPiEIrMuY.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGf)
        break
  except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ(exception)
   return[]
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMuY
 def Sports_LeagueHome_List(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,data,sType=''):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMuG=[]
  try:
   if sType=='top10':
    for ACRqVdomFTbsvWDhOpkQlUPiEIrMGn in data.get('data'):
     ACRqVdomFTbsvWDhOpkQlUPiEIrMuH=''
     if 'channels' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn:
      ACRqVdomFTbsvWDhOpkQlUPiEIrMuH='패스'
     ACRqVdomFTbsvWDhOpkQlUPiEIrMGf={'id':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['id'],'title':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['title'],'subType':ACRqVdomFTbsvWDhOpkQlUPiEIrMuH,'image':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['images']['story_art_url'],'running_time':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['running_time'],'startDate':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.convert_DateStr(ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['startAt']),}
     ACRqVdomFTbsvWDhOpkQlUPiEIrMuG.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGf)
   elif sType=='gameVod':
    for ACRqVdomFTbsvWDhOpkQlUPiEIrMGn in data.get('data'):
     if ACRqVdomFTbsvWDhOpkQlUPiEIrMnc(ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['participants'])>=2:
      ACRqVdomFTbsvWDhOpkQlUPiEIrMun=ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['participants'][0]['name']
      ACRqVdomFTbsvWDhOpkQlUPiEIrMuS=ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['participants'][1]['name']
      ACRqVdomFTbsvWDhOpkQlUPiEIrMun=ACRqVdomFTbsvWDhOpkQlUPiEIrMun+' vs '+ACRqVdomFTbsvWDhOpkQlUPiEIrMuS
     else:
      ACRqVdomFTbsvWDhOpkQlUPiEIrMun=ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['participants'][0]['name']
     ACRqVdomFTbsvWDhOpkQlUPiEIrMHe=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.Sports_LeagueHome_SubVods(ACRqVdomFTbsvWDhOpkQlUPiEIrMGn)
     ACRqVdomFTbsvWDhOpkQlUPiEIrMHz =ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.MakeText_FreeList(ACRqVdomFTbsvWDhOpkQlUPiEIrMHe,titleName='title')
     ACRqVdomFTbsvWDhOpkQlUPiEIrMGf={'id':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['id'],'title':ACRqVdomFTbsvWDhOpkQlUPiEIrMun,'startDate':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.convert_DateStr(ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['startsAt']),'preText':ACRqVdomFTbsvWDhOpkQlUPiEIrMHz,'image':ACRqVdomFTbsvWDhOpkQlUPiEIrMHe[0]['image']}
     ACRqVdomFTbsvWDhOpkQlUPiEIrMuG.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGf)
  except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ(exception)
   return[]
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMuG
 def Sports_LeagueHome_SubVods(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,data):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMHe=[]
  try:
   for ACRqVdomFTbsvWDhOpkQlUPiEIrMGn in data.get('highlights'):
    ACRqVdomFTbsvWDhOpkQlUPiEIrMuH=''
    if 'channels' in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn:
     ACRqVdomFTbsvWDhOpkQlUPiEIrMuH='패스'
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGf={'id':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['id'],'title':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['title'],'image':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['images']['story-art']['url'],'subType':ACRqVdomFTbsvWDhOpkQlUPiEIrMuH,'running_time':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['running_time'],}
    ACRqVdomFTbsvWDhOpkQlUPiEIrMHe.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGf)
  except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ(exception)
   return[]
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMHe
 def Sports_leagueHome_Livelist(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,leagueID):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMHe=[]
  try:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcg='{}/api-discover/v1/sports/curated-schedule/events'.format(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.API_DOMAIN)
   ACRqVdomFTbsvWDhOpkQlUPiEIrMGc={'league_id':leagueID,'region':'KR','locale':'ko','scope':'live-upcoming','includeHighlights':'false','includeSportsChannelContents':'true',}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcG={'x-membersrl':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['COOKIES']['member_srl'],'x-pcid':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['COOKIES']['PCID'],'x-profileid':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT',}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcX=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.callRequestCookies('Get',ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,payload=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,params=ACRqVdomFTbsvWDhOpkQlUPiEIrMGc,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMcG,cookies=ACRqVdomFTbsvWDhOpkQlUPiEIrMut)
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.status_code not in[200]:return[]
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcK=json.loads(ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.text).get('data')
   for ACRqVdomFTbsvWDhOpkQlUPiEIrMHy in ACRqVdomFTbsvWDhOpkQlUPiEIrMcK:
    if ACRqVdomFTbsvWDhOpkQlUPiEIrMnc(ACRqVdomFTbsvWDhOpkQlUPiEIrMHy['teams'])>=2:
     ACRqVdomFTbsvWDhOpkQlUPiEIrMun=ACRqVdomFTbsvWDhOpkQlUPiEIrMHy['teams'][0]['name']
     ACRqVdomFTbsvWDhOpkQlUPiEIrMuS=ACRqVdomFTbsvWDhOpkQlUPiEIrMHy['teams'][1]['name']
     ACRqVdomFTbsvWDhOpkQlUPiEIrMun=ACRqVdomFTbsvWDhOpkQlUPiEIrMun+' vs '+ACRqVdomFTbsvWDhOpkQlUPiEIrMuS
    else:
     ACRqVdomFTbsvWDhOpkQlUPiEIrMun=ACRqVdomFTbsvWDhOpkQlUPiEIrMHy['teams'][0]['name']
    ACRqVdomFTbsvWDhOpkQlUPiEIrMuf=''
    if ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('images'):
     ACRqVdomFTbsvWDhOpkQlUPiEIrMuf=ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('images').get('story_art_url')
    ACRqVdomFTbsvWDhOpkQlUPiEIrMuj=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.convert_TimeStr(ACRqVdomFTbsvWDhOpkQlUPiEIrMHy['start_at'])
    ACRqVdomFTbsvWDhOpkQlUPiEIrMuH=''
    if 'channels' in ACRqVdomFTbsvWDhOpkQlUPiEIrMHy:
     ACRqVdomFTbsvWDhOpkQlUPiEIrMuH='패스'
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGf={'event_id':ACRqVdomFTbsvWDhOpkQlUPiEIrMHy['event_id'],'title':ACRqVdomFTbsvWDhOpkQlUPiEIrMun,'startDate':ACRqVdomFTbsvWDhOpkQlUPiEIrMuj,'image':ACRqVdomFTbsvWDhOpkQlUPiEIrMuf,'preTitle':'{} <{}>'.format(ACRqVdomFTbsvWDhOpkQlUPiEIrMun,ACRqVdomFTbsvWDhOpkQlUPiEIrMuj),'subType':ACRqVdomFTbsvWDhOpkQlUPiEIrMuH,}
    ACRqVdomFTbsvWDhOpkQlUPiEIrMHe.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGf)
  except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ(exception)
   return[]
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMHe
 def Sports_MultiHero_LiveList(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMuN=[]
  try:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcg='{}/api-discover/v1/sports/feed'.format(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.API_DOMAIN)
   ACRqVdomFTbsvWDhOpkQlUPiEIrMGc={'platform':'WEBCLIENT','region':'KR','locale':'ko','filterRestrictedContent':'false','preferRecoFeed':'true','preferMultiHeroMixedContentRow':'true','category':'LIVE','perPage':'7','allowOtherRailsAboveHero':'true','includeSportsChannelContents':'true','page':'1',}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcX=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.callRequestCookies('Get',ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,payload=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,params=ACRqVdomFTbsvWDhOpkQlUPiEIrMGc,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,cookies=ACRqVdomFTbsvWDhOpkQlUPiEIrMut)
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.status_code not in[200]:return[]
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcK=json.loads(ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.text).get('data')
   for ACRqVdomFTbsvWDhOpkQlUPiEIrMGn in ACRqVdomFTbsvWDhOpkQlUPiEIrMcK:
    if ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('type')=='Multi-Hero-Live-Event-Curation':
     for ACRqVdomFTbsvWDhOpkQlUPiEIrMHy in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('data'):
      ACRqVdomFTbsvWDhOpkQlUPiEIrMuj=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.convert_TimeStr(ACRqVdomFTbsvWDhOpkQlUPiEIrMHy['startAt'])
      '''
      try:
       startDate = self.convert_TimeStr(i_vod['startAt'] )
      except Exception as exception:
       aa = 'exception = {}'.format(exception )
       bb = {'aa' : aa }
       self.dic_To_jsonfile('d:\\Naver MYBOX\\sync\\job\\cp_cookies1.json', bb )
      '''      
      ACRqVdomFTbsvWDhOpkQlUPiEIrMuf=''
      if ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('images'):
       if ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('images').get('hero_url'):
        ACRqVdomFTbsvWDhOpkQlUPiEIrMuf=ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('images').get('hero_url')
       elif ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('images').get('sports_hero_mobile_url'):
        ACRqVdomFTbsvWDhOpkQlUPiEIrMuf=ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('images').get('sports_hero_mobile_url')
      ACRqVdomFTbsvWDhOpkQlUPiEIrMuH=''
      if 'channels' in ACRqVdomFTbsvWDhOpkQlUPiEIrMHy:
       ACRqVdomFTbsvWDhOpkQlUPiEIrMuH='패스'
      ACRqVdomFTbsvWDhOpkQlUPiEIrMGf={'id':ACRqVdomFTbsvWDhOpkQlUPiEIrMHy['id'],'title':ACRqVdomFTbsvWDhOpkQlUPiEIrMHy['title'],'startDate':ACRqVdomFTbsvWDhOpkQlUPiEIrMuj,'image':ACRqVdomFTbsvWDhOpkQlUPiEIrMuf,'preTitle':'{} <{}>'.format(ACRqVdomFTbsvWDhOpkQlUPiEIrMHy['title'],ACRqVdomFTbsvWDhOpkQlUPiEIrMuj),'subType':ACRqVdomFTbsvWDhOpkQlUPiEIrMuH,}
      ACRqVdomFTbsvWDhOpkQlUPiEIrMuN.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGf)
     break
  except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ(exception)
   return[]
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMuN
 def Sports_Season_Group(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,leagueID):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMug=[]
  try:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcg='{}/api-discover/v1/discover/sports/leagues/{}/filters'.format(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.API_DOMAIN,leagueID)
   ACRqVdomFTbsvWDhOpkQlUPiEIrMGc={'platform':'WEBCLIENT','locale':'ko','includeSportsChannelContents':'true',}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcG={'x-membersrl':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['COOKIES']['member_srl'],'x-pcid':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['COOKIES']['PCID'],'x-profileid':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT',}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcX=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.callRequestCookies('Get',ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,payload=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,params=ACRqVdomFTbsvWDhOpkQlUPiEIrMGc,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMcG,cookies=ACRqVdomFTbsvWDhOpkQlUPiEIrMut)
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.status_code not in[200]:return[]
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcK=json.loads(ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.text).get('data')
   for ACRqVdomFTbsvWDhOpkQlUPiEIrMGn in ACRqVdomFTbsvWDhOpkQlUPiEIrMcK:
    ACRqVdomFTbsvWDhOpkQlUPiEIrMuL=[]
    for ACRqVdomFTbsvWDhOpkQlUPiEIrMuX in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('stages'):
     ACRqVdomFTbsvWDhOpkQlUPiEIrMuw={'title':ACRqVdomFTbsvWDhOpkQlUPiEIrMuX['name'],}
     ACRqVdomFTbsvWDhOpkQlUPiEIrMuL.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMuw)
    ACRqVdomFTbsvWDhOpkQlUPiEIrMHz=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.MakeText_FreeList(ACRqVdomFTbsvWDhOpkQlUPiEIrMuL,titleName='title')
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGf={'season':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['season'],'preText':ACRqVdomFTbsvWDhOpkQlUPiEIrMHz,}
    ACRqVdomFTbsvWDhOpkQlUPiEIrMug.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGf)
  except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ(exception)
   return[]
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMug
 def Sports_Season_GameList(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,leagueID,seasonID,page=1):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMuG=[]
  try:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcg='{}/api-discover/v2/sports/leagues/{}/schedule/previous'.format(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.API_DOMAIN,leagueID)
   ACRqVdomFTbsvWDhOpkQlUPiEIrMGc={'seasons':seasonID,'stageIds':'','teamIds':'','platform':'WEBCLIENT','locale':'ko','region':'KR','perPage':'10','includeSportsChannelContents':'true','page':ACRqVdomFTbsvWDhOpkQlUPiEIrMue(page),}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcG={'x-membersrl':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['COOKIES']['member_srl'],'x-pcid':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['COOKIES']['PCID'],'x-profileid':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT',}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcX=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.callRequestCookies('Get',ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,payload=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,params=ACRqVdomFTbsvWDhOpkQlUPiEIrMGc,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,cookies=ACRqVdomFTbsvWDhOpkQlUPiEIrMut)
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.status_code not in[200]:return[]
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcK=json.loads(ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.text).get('data')
   for ACRqVdomFTbsvWDhOpkQlUPiEIrMGn in ACRqVdomFTbsvWDhOpkQlUPiEIrMcK:
    if ACRqVdomFTbsvWDhOpkQlUPiEIrMnc(ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['participants'])>=2:
     ACRqVdomFTbsvWDhOpkQlUPiEIrMun=ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['participants'][0]['name']
     ACRqVdomFTbsvWDhOpkQlUPiEIrMuS=ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['participants'][1]['name']
     ACRqVdomFTbsvWDhOpkQlUPiEIrMun=ACRqVdomFTbsvWDhOpkQlUPiEIrMun+' vs '+ACRqVdomFTbsvWDhOpkQlUPiEIrMuS
    else:
     ACRqVdomFTbsvWDhOpkQlUPiEIrMun=ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['participants'][0]['name']
    ACRqVdomFTbsvWDhOpkQlUPiEIrMHe=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.Sports_LeagueHome_SubVods(ACRqVdomFTbsvWDhOpkQlUPiEIrMGn)
    ACRqVdomFTbsvWDhOpkQlUPiEIrMHz =ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.MakeText_FreeList(ACRqVdomFTbsvWDhOpkQlUPiEIrMHe,titleName='title')
    ACRqVdomFTbsvWDhOpkQlUPiEIrMGf={'id':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['id'],'title':ACRqVdomFTbsvWDhOpkQlUPiEIrMun,'startDate':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.convert_DateStr(ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['startsAt']),'preText':ACRqVdomFTbsvWDhOpkQlUPiEIrMHz,'image':ACRqVdomFTbsvWDhOpkQlUPiEIrMHe[0]['image']}
    ACRqVdomFTbsvWDhOpkQlUPiEIrMuG.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGf)
  except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ(exception)
   return[]
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMuG
 def Sports_Season_GameVod(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,leagueID,seasonID,page,gameID):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMuY=[]
  try:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcg='{}/api-discover/v2/sports/leagues/{}/schedule/previous'.format(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.API_DOMAIN,leagueID)
   ACRqVdomFTbsvWDhOpkQlUPiEIrMGc={'seasons':seasonID,'stageIds':'','teamIds':'','platform':'WEBCLIENT','locale':'ko','region':'KR','perPage':'10','includeSportsChannelContents':'true','page':ACRqVdomFTbsvWDhOpkQlUPiEIrMue(page),}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcG={'x-membersrl':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['COOKIES']['member_srl'],'x-pcid':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['COOKIES']['PCID'],'x-profileid':ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT',}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcX=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.callRequestCookies('Get',ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,payload=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,params=ACRqVdomFTbsvWDhOpkQlUPiEIrMGc,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,cookies=ACRqVdomFTbsvWDhOpkQlUPiEIrMut)
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.status_code not in[200]:return[]
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcK=json.loads(ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.text).get('data')
   for ACRqVdomFTbsvWDhOpkQlUPiEIrMGn in ACRqVdomFTbsvWDhOpkQlUPiEIrMcK:
    if gameID==ACRqVdomFTbsvWDhOpkQlUPiEIrMGn['id']:
     ACRqVdomFTbsvWDhOpkQlUPiEIrMHe=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.Sports_LeagueHome_SubVods(ACRqVdomFTbsvWDhOpkQlUPiEIrMGn)
     for ACRqVdomFTbsvWDhOpkQlUPiEIrMHy in ACRqVdomFTbsvWDhOpkQlUPiEIrMHe:
      ACRqVdomFTbsvWDhOpkQlUPiEIrMGf={'id':ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('id'),'title':ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('title'),'image':ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('image'),'subType':ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('subType'),'running_time':ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('running_time'),}
      ACRqVdomFTbsvWDhOpkQlUPiEIrMuY.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGf)
  except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ(exception)
   return[]
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMuY
 def Get_Pass_GroupList(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,ACRqVdomFTbsvWDhOpkQlUPiEIrMGS):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMuB=[]
  try:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcg='{}/api-discover/v2/discover/channels/{}/feed'.format(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.API_DOMAIN,ACRqVdomFTbsvWDhOpkQlUPiEIrMGS)
   ACRqVdomFTbsvWDhOpkQlUPiEIrMGc={'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':ACRqVdomFTbsvWDhOpkQlUPiEIrMue(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.PAGE_LIMIT),'filterRestrictedContent':'false','preferRecoFeed':'true','preferMultiHeroMixedContentRow':'true','shouldIncludeTVOD':'true','category':'ALL',}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcX=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.callRequestCookies('Get',ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,payload=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,params=ACRqVdomFTbsvWDhOpkQlUPiEIrMGc,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,cookies=ACRqVdomFTbsvWDhOpkQlUPiEIrMut)
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.status_code not in[200]:return[]
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcK=json.loads(ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.text).get('data')
   for ACRqVdomFTbsvWDhOpkQlUPiEIrMGn in ACRqVdomFTbsvWDhOpkQlUPiEIrMcK:
    if ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('row_name')and ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('obj_id'):
     ACRqVdomFTbsvWDhOpkQlUPiEIrMHz=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.MakeText_FreeList(ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('data'),titleName='title')
     ACRqVdomFTbsvWDhOpkQlUPiEIrMGf={'obj_id':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('obj_id'),'title':ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('row_name'),'preText':ACRqVdomFTbsvWDhOpkQlUPiEIrMHz,}
     ACRqVdomFTbsvWDhOpkQlUPiEIrMuB.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGf)
  except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ(exception)
   return[]
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMuB
 def Get_Pass_VodList(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH,ACRqVdomFTbsvWDhOpkQlUPiEIrMGS,obj_id):
  ACRqVdomFTbsvWDhOpkQlUPiEIrMux=[]
  try:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcg='{}/api-discover/v2/discover/channels/{}/feed'.format(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.API_DOMAIN,ACRqVdomFTbsvWDhOpkQlUPiEIrMGS)
   ACRqVdomFTbsvWDhOpkQlUPiEIrMGc={'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':ACRqVdomFTbsvWDhOpkQlUPiEIrMue(ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.PAGE_LIMIT),'filterRestrictedContent':'false','preferRecoFeed':'true','preferMultiHeroMixedContentRow':'true','shouldIncludeTVOD':'true','category':'ALL',}
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcX=ACRqVdomFTbsvWDhOpkQlUPiEIrMYH.callRequestCookies('Get',ACRqVdomFTbsvWDhOpkQlUPiEIrMcg,payload=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,params=ACRqVdomFTbsvWDhOpkQlUPiEIrMGc,headers=ACRqVdomFTbsvWDhOpkQlUPiEIrMut,cookies=ACRqVdomFTbsvWDhOpkQlUPiEIrMut)
   if ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.status_code not in[200]:return[]
   ACRqVdomFTbsvWDhOpkQlUPiEIrMcK=json.loads(ACRqVdomFTbsvWDhOpkQlUPiEIrMcX.text).get('data')
   for ACRqVdomFTbsvWDhOpkQlUPiEIrMGn in ACRqVdomFTbsvWDhOpkQlUPiEIrMcK:
    if ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('obj_id')==obj_id:
     for ACRqVdomFTbsvWDhOpkQlUPiEIrMHy in ACRqVdomFTbsvWDhOpkQlUPiEIrMGn.get('data'):
      ACRqVdomFTbsvWDhOpkQlUPiEIrMGg=ACRqVdomFTbsvWDhOpkQlUPiEIrMGx=ACRqVdomFTbsvWDhOpkQlUPiEIrMHX=ACRqVdomFTbsvWDhOpkQlUPiEIrMHL=''
      if 'poster_url' in ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('images'):ACRqVdomFTbsvWDhOpkQlUPiEIrMGg =ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('images').get('poster_url') +'?imwidth=350'
      if 'story_art_url' in ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('images'):ACRqVdomFTbsvWDhOpkQlUPiEIrMGx =ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('images').get('story_art_url') +'?imwidth=600'
      if 'title_treatment_url' in ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('images'):ACRqVdomFTbsvWDhOpkQlUPiEIrMHX=ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('images').get('title_treatment_url')+'?imwidth=300'
      if 'story_art_url' in ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('images'):ACRqVdomFTbsvWDhOpkQlUPiEIrMHL =ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('images').get('story_art_url') +'?imwidth=600'
      ACRqVdomFTbsvWDhOpkQlUPiEIrMGL=''
      if ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('badge')not in[{},ACRqVdomFTbsvWDhOpkQlUPiEIrMut]:
       for i in ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('badge').get('text'):
        ACRqVdomFTbsvWDhOpkQlUPiEIrMGL+=i.get('text')
      ACRqVdomFTbsvWDhOpkQlUPiEIrMGX=''
      if ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('seasonList')!=ACRqVdomFTbsvWDhOpkQlUPiEIrMut:
       ACRqVdomFTbsvWDhOpkQlUPiEIrMGX=','.join(ACRqVdomFTbsvWDhOpkQlUPiEIrMue(e)for e in ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('seasonList'))
      ACRqVdomFTbsvWDhOpkQlUPiEIrMGw =[]
      for ACRqVdomFTbsvWDhOpkQlUPiEIrMGB in ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('tags'):
       ACRqVdomFTbsvWDhOpkQlUPiEIrMGw.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGB.get('tag'))
      ACRqVdomFTbsvWDhOpkQlUPiEIrMGf={'id':ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('id'),'title':ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('title'),'thumbnail':{'poster':ACRqVdomFTbsvWDhOpkQlUPiEIrMGg,'thumb':ACRqVdomFTbsvWDhOpkQlUPiEIrMGx,'clearlogo':ACRqVdomFTbsvWDhOpkQlUPiEIrMHX,'fanart':ACRqVdomFTbsvWDhOpkQlUPiEIrMHL},'mpaa':ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('ageRating'),'duration':ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('running_time'),'sub_type':ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('sub_type'),'badge':ACRqVdomFTbsvWDhOpkQlUPiEIrMGL,'year':ACRqVdomFTbsvWDhOpkQlUPiEIrMHy.get('releaseYear'),'seasonList':ACRqVdomFTbsvWDhOpkQlUPiEIrMGX,'genreList':ACRqVdomFTbsvWDhOpkQlUPiEIrMGw,}
      ACRqVdomFTbsvWDhOpkQlUPiEIrMux.append(ACRqVdomFTbsvWDhOpkQlUPiEIrMGf)
     break
  except ACRqVdomFTbsvWDhOpkQlUPiEIrMuy as exception:
   ACRqVdomFTbsvWDhOpkQlUPiEIrMuJ(exception)
   return[]
  return ACRqVdomFTbsvWDhOpkQlUPiEIrMux
# Created by pyminifier (https://github.com/liftoff/pyminifier)
