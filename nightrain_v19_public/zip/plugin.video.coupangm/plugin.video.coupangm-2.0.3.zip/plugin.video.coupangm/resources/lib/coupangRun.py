__author__="NightRain"
QswtibyXRUSVcTIrPpfnYCulGBDHaW=object
QswtibyXRUSVcTIrPpfnYCulGBDHaz=None
QswtibyXRUSVcTIrPpfnYCulGBDHax=False
QswtibyXRUSVcTIrPpfnYCulGBDHad=True
QswtibyXRUSVcTIrPpfnYCulGBDHaO=type
QswtibyXRUSVcTIrPpfnYCulGBDHav=dict
QswtibyXRUSVcTIrPpfnYCulGBDHae=int
QswtibyXRUSVcTIrPpfnYCulGBDHaA=open
QswtibyXRUSVcTIrPpfnYCulGBDHFk=Exception
QswtibyXRUSVcTIrPpfnYCulGBDHFK=str
QswtibyXRUSVcTIrPpfnYCulGBDHFN=id
QswtibyXRUSVcTIrPpfnYCulGBDHFM=len
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import inputstreamhelper
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
QswtibyXRUSVcTIrPpfnYCulGBDHkN=[{'title':'홈   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'ALL'},{'title':'TV   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'MOVIES'},{'title':'교육 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'EDUCATION'},{'title':'생중계','mode':'EVENT_GROUPLIST','vType':'LIVE'},{'title':'TV   (테마별)','mode':'THEME_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (테마별)','mode':'THEME_GROUPLIST','vType':'MOVIES'},{'title':'교육 (테마별)','mode':'THEME_GROUPLIST','vType':'EDUCATION'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},{'title':'(쿠팡) 검색','mode':'LOCAL_SEARCH','icon':'search.png'},{'title':'(쿠팡) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
QswtibyXRUSVcTIrPpfnYCulGBDHkM=[{'title':'시리즈 시청내역','mode':'WATCH','stype':'tvshow'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},]
QswtibyXRUSVcTIrPpfnYCulGBDHkL=xbmcvfs.translatePath(os.path.join(__profile__,'coupang_searched.txt'))
from coupangCore import*
class QswtibyXRUSVcTIrPpfnYCulGBDHkK(QswtibyXRUSVcTIrPpfnYCulGBDHaW):
 def __init__(QswtibyXRUSVcTIrPpfnYCulGBDHka,QswtibyXRUSVcTIrPpfnYCulGBDHkF,QswtibyXRUSVcTIrPpfnYCulGBDHkm,QswtibyXRUSVcTIrPpfnYCulGBDHkq):
  QswtibyXRUSVcTIrPpfnYCulGBDHka._addon_url =QswtibyXRUSVcTIrPpfnYCulGBDHkF
  QswtibyXRUSVcTIrPpfnYCulGBDHka._addon_handle=QswtibyXRUSVcTIrPpfnYCulGBDHkm
  QswtibyXRUSVcTIrPpfnYCulGBDHka.main_params =QswtibyXRUSVcTIrPpfnYCulGBDHkq
  QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj =VfSlQRhAGMomrWtzejyYiIkDFwOqUu() 
  QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.CP_COOKIE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_cookies.json'))
  QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.CP_DEVICE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_device.json'))
 def addon_noti(QswtibyXRUSVcTIrPpfnYCulGBDHka,sting):
  try:
   QswtibyXRUSVcTIrPpfnYCulGBDHko=xbmcgui.Dialog()
   QswtibyXRUSVcTIrPpfnYCulGBDHko.notification(__addonname__,sting)
  except:
   QswtibyXRUSVcTIrPpfnYCulGBDHaz
 def addon_log(QswtibyXRUSVcTIrPpfnYCulGBDHka,string):
  try:
   QswtibyXRUSVcTIrPpfnYCulGBDHkg=string.encode('utf-8','ignore')
  except:
   QswtibyXRUSVcTIrPpfnYCulGBDHkg='addonException: addon_log'
  QswtibyXRUSVcTIrPpfnYCulGBDHkh=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,QswtibyXRUSVcTIrPpfnYCulGBDHkg),level=QswtibyXRUSVcTIrPpfnYCulGBDHkh)
 def get_keyboard_input(QswtibyXRUSVcTIrPpfnYCulGBDHka,QswtibyXRUSVcTIrPpfnYCulGBDHKN):
  QswtibyXRUSVcTIrPpfnYCulGBDHkE=QswtibyXRUSVcTIrPpfnYCulGBDHaz
  kb=xbmc.Keyboard()
  kb.setHeading(QswtibyXRUSVcTIrPpfnYCulGBDHKN)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   QswtibyXRUSVcTIrPpfnYCulGBDHkE=kb.getText()
  return QswtibyXRUSVcTIrPpfnYCulGBDHkE
 def get_settings_account(QswtibyXRUSVcTIrPpfnYCulGBDHka):
  QswtibyXRUSVcTIrPpfnYCulGBDHkJ=__addon__.getSetting('id')
  QswtibyXRUSVcTIrPpfnYCulGBDHkW=__addon__.getSetting('pw')
  QswtibyXRUSVcTIrPpfnYCulGBDHkz=__addon__.getSetting('profile')
  return(QswtibyXRUSVcTIrPpfnYCulGBDHkJ,QswtibyXRUSVcTIrPpfnYCulGBDHkW,QswtibyXRUSVcTIrPpfnYCulGBDHkz)
 def get_settings_exclusion21(QswtibyXRUSVcTIrPpfnYCulGBDHka):
  QswtibyXRUSVcTIrPpfnYCulGBDHkx =__addon__.getSetting('exclusion21')
  if QswtibyXRUSVcTIrPpfnYCulGBDHkx=='false':
   return QswtibyXRUSVcTIrPpfnYCulGBDHax
  else:
   return QswtibyXRUSVcTIrPpfnYCulGBDHad
 def get_settings_totalsearch(QswtibyXRUSVcTIrPpfnYCulGBDHka):
  QswtibyXRUSVcTIrPpfnYCulGBDHkd =QswtibyXRUSVcTIrPpfnYCulGBDHad if __addon__.getSetting('local_search')=='true' else QswtibyXRUSVcTIrPpfnYCulGBDHax
  QswtibyXRUSVcTIrPpfnYCulGBDHkO=QswtibyXRUSVcTIrPpfnYCulGBDHad if __addon__.getSetting('local_history')=='true' else QswtibyXRUSVcTIrPpfnYCulGBDHax
  QswtibyXRUSVcTIrPpfnYCulGBDHkv =QswtibyXRUSVcTIrPpfnYCulGBDHad if __addon__.getSetting('total_search')=='true' else QswtibyXRUSVcTIrPpfnYCulGBDHax
  QswtibyXRUSVcTIrPpfnYCulGBDHke=QswtibyXRUSVcTIrPpfnYCulGBDHad if __addon__.getSetting('total_history')=='true' else QswtibyXRUSVcTIrPpfnYCulGBDHax
  QswtibyXRUSVcTIrPpfnYCulGBDHkA=QswtibyXRUSVcTIrPpfnYCulGBDHad if __addon__.getSetting('menu_bookmark')=='true' else QswtibyXRUSVcTIrPpfnYCulGBDHax
  return(QswtibyXRUSVcTIrPpfnYCulGBDHkd,QswtibyXRUSVcTIrPpfnYCulGBDHkO,QswtibyXRUSVcTIrPpfnYCulGBDHkv,QswtibyXRUSVcTIrPpfnYCulGBDHke,QswtibyXRUSVcTIrPpfnYCulGBDHkA)
 def get_settings_makebookmark(QswtibyXRUSVcTIrPpfnYCulGBDHka):
  return QswtibyXRUSVcTIrPpfnYCulGBDHad if __addon__.getSetting('make_bookmark')=='true' else QswtibyXRUSVcTIrPpfnYCulGBDHax
 def add_dir(QswtibyXRUSVcTIrPpfnYCulGBDHka,label,sublabel='',img='',infoLabels=QswtibyXRUSVcTIrPpfnYCulGBDHaz,isFolder=QswtibyXRUSVcTIrPpfnYCulGBDHad,params='',isLink=QswtibyXRUSVcTIrPpfnYCulGBDHax,ContextMenu=QswtibyXRUSVcTIrPpfnYCulGBDHaz):
  QswtibyXRUSVcTIrPpfnYCulGBDHKk='%s?%s'%(QswtibyXRUSVcTIrPpfnYCulGBDHka._addon_url,urllib.parse.urlencode(params))
  if sublabel:QswtibyXRUSVcTIrPpfnYCulGBDHKN='%s < %s >'%(label,sublabel)
  else: QswtibyXRUSVcTIrPpfnYCulGBDHKN=label
  if not img:img='DefaultFolder.png'
  QswtibyXRUSVcTIrPpfnYCulGBDHKM=xbmcgui.ListItem(QswtibyXRUSVcTIrPpfnYCulGBDHKN)
  if QswtibyXRUSVcTIrPpfnYCulGBDHaO(img)==QswtibyXRUSVcTIrPpfnYCulGBDHav:
   QswtibyXRUSVcTIrPpfnYCulGBDHKM.setArt(img)
  else:
   QswtibyXRUSVcTIrPpfnYCulGBDHKM.setArt({'thumb':img,'poster':img})
  if infoLabels:QswtibyXRUSVcTIrPpfnYCulGBDHKM.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   QswtibyXRUSVcTIrPpfnYCulGBDHKM.setProperty('IsPlayable','true')
  if ContextMenu:QswtibyXRUSVcTIrPpfnYCulGBDHKM.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(QswtibyXRUSVcTIrPpfnYCulGBDHka._addon_handle,QswtibyXRUSVcTIrPpfnYCulGBDHKk,QswtibyXRUSVcTIrPpfnYCulGBDHKM,isFolder)
 def dp_Main_List(QswtibyXRUSVcTIrPpfnYCulGBDHka,args):
  (QswtibyXRUSVcTIrPpfnYCulGBDHkd,QswtibyXRUSVcTIrPpfnYCulGBDHkO,QswtibyXRUSVcTIrPpfnYCulGBDHkv,QswtibyXRUSVcTIrPpfnYCulGBDHke,QswtibyXRUSVcTIrPpfnYCulGBDHkA)=QswtibyXRUSVcTIrPpfnYCulGBDHka.get_settings_totalsearch()
  for QswtibyXRUSVcTIrPpfnYCulGBDHKL in QswtibyXRUSVcTIrPpfnYCulGBDHkN:
   QswtibyXRUSVcTIrPpfnYCulGBDHKN=QswtibyXRUSVcTIrPpfnYCulGBDHKL.get('title')
   QswtibyXRUSVcTIrPpfnYCulGBDHKa=''
   if QswtibyXRUSVcTIrPpfnYCulGBDHKL.get('mode')=='LOCAL_SEARCH' and QswtibyXRUSVcTIrPpfnYCulGBDHkd ==QswtibyXRUSVcTIrPpfnYCulGBDHax:continue
   elif QswtibyXRUSVcTIrPpfnYCulGBDHKL.get('mode')=='SEARCH_HISTORY' and QswtibyXRUSVcTIrPpfnYCulGBDHkO==QswtibyXRUSVcTIrPpfnYCulGBDHax:continue
   elif QswtibyXRUSVcTIrPpfnYCulGBDHKL.get('mode')=='TOTAL_SEARCH' and QswtibyXRUSVcTIrPpfnYCulGBDHkv ==QswtibyXRUSVcTIrPpfnYCulGBDHax:continue
   elif QswtibyXRUSVcTIrPpfnYCulGBDHKL.get('mode')=='TOTAL_HISTORY' and QswtibyXRUSVcTIrPpfnYCulGBDHke==QswtibyXRUSVcTIrPpfnYCulGBDHax:continue
   elif QswtibyXRUSVcTIrPpfnYCulGBDHKL.get('mode')=='MENU_BOOKMARK' and QswtibyXRUSVcTIrPpfnYCulGBDHkA==QswtibyXRUSVcTIrPpfnYCulGBDHax:continue
   QswtibyXRUSVcTIrPpfnYCulGBDHKF={'mode':QswtibyXRUSVcTIrPpfnYCulGBDHKL.get('mode'),'vType':QswtibyXRUSVcTIrPpfnYCulGBDHKL.get('vType'),'page':'1',}
   if QswtibyXRUSVcTIrPpfnYCulGBDHKL.get('mode')=='LOCAL_SEARCH':QswtibyXRUSVcTIrPpfnYCulGBDHKF['historyyn']='Y' 
   if QswtibyXRUSVcTIrPpfnYCulGBDHKL.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    QswtibyXRUSVcTIrPpfnYCulGBDHKm=QswtibyXRUSVcTIrPpfnYCulGBDHax
    QswtibyXRUSVcTIrPpfnYCulGBDHKq =QswtibyXRUSVcTIrPpfnYCulGBDHad
   else:
    QswtibyXRUSVcTIrPpfnYCulGBDHKm=QswtibyXRUSVcTIrPpfnYCulGBDHad
    QswtibyXRUSVcTIrPpfnYCulGBDHKq =QswtibyXRUSVcTIrPpfnYCulGBDHax
   if 'icon' in QswtibyXRUSVcTIrPpfnYCulGBDHKL:QswtibyXRUSVcTIrPpfnYCulGBDHKa=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',QswtibyXRUSVcTIrPpfnYCulGBDHKL.get('icon')) 
   QswtibyXRUSVcTIrPpfnYCulGBDHka.add_dir(QswtibyXRUSVcTIrPpfnYCulGBDHKN,sublabel='',img=QswtibyXRUSVcTIrPpfnYCulGBDHKa,infoLabels=QswtibyXRUSVcTIrPpfnYCulGBDHaz,isFolder=QswtibyXRUSVcTIrPpfnYCulGBDHKm,params=QswtibyXRUSVcTIrPpfnYCulGBDHKF,isLink=QswtibyXRUSVcTIrPpfnYCulGBDHKq)
  xbmcplugin.endOfDirectory(QswtibyXRUSVcTIrPpfnYCulGBDHka._addon_handle)
 def dp_Test(QswtibyXRUSVcTIrPpfnYCulGBDHka,args):
  QswtibyXRUSVcTIrPpfnYCulGBDHka.addon_noti('test')
 def CP_logout(QswtibyXRUSVcTIrPpfnYCulGBDHka):
  QswtibyXRUSVcTIrPpfnYCulGBDHko=xbmcgui.Dialog()
  QswtibyXRUSVcTIrPpfnYCulGBDHKo=QswtibyXRUSVcTIrPpfnYCulGBDHko.yesno(__language__(30905).encode('utf8'),__language__(30906).encode('utf8'))
  if QswtibyXRUSVcTIrPpfnYCulGBDHKo==QswtibyXRUSVcTIrPpfnYCulGBDHax:return 
  if os.path.isfile(QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.CP_COOKIE_FILENAME):os.remove(QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.CP_COOKIE_FILENAME)
  QswtibyXRUSVcTIrPpfnYCulGBDHka.addon_noti(__language__(30904).encode('utf-8'))
 def option_check(QswtibyXRUSVcTIrPpfnYCulGBDHka):
  (QswtibyXRUSVcTIrPpfnYCulGBDHkJ,QswtibyXRUSVcTIrPpfnYCulGBDHkW,QswtibyXRUSVcTIrPpfnYCulGBDHkz)=QswtibyXRUSVcTIrPpfnYCulGBDHka.get_settings_account()
  if QswtibyXRUSVcTIrPpfnYCulGBDHkJ=='' or QswtibyXRUSVcTIrPpfnYCulGBDHkW=='':
   QswtibyXRUSVcTIrPpfnYCulGBDHko=xbmcgui.Dialog()
   QswtibyXRUSVcTIrPpfnYCulGBDHKo=QswtibyXRUSVcTIrPpfnYCulGBDHko.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if QswtibyXRUSVcTIrPpfnYCulGBDHKo==QswtibyXRUSVcTIrPpfnYCulGBDHad:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if QswtibyXRUSVcTIrPpfnYCulGBDHka.cookiefile_check()==QswtibyXRUSVcTIrPpfnYCulGBDHax:
   if QswtibyXRUSVcTIrPpfnYCulGBDHka.CP_login(QswtibyXRUSVcTIrPpfnYCulGBDHkJ,QswtibyXRUSVcTIrPpfnYCulGBDHkW,QswtibyXRUSVcTIrPpfnYCulGBDHkz)==QswtibyXRUSVcTIrPpfnYCulGBDHax:
    QswtibyXRUSVcTIrPpfnYCulGBDHka.addon_noti(__language__(30903).encode('utf8'))
    sys.exit()
  else:
   QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.Get_CP_profile(QswtibyXRUSVcTIrPpfnYCulGBDHkz,limit_days=QswtibyXRUSVcTIrPpfnYCulGBDHae(__addon__.getSetting('cache_ttl')),re_check=QswtibyXRUSVcTIrPpfnYCulGBDHad)
 def cookiefile_check(QswtibyXRUSVcTIrPpfnYCulGBDHka):
  QswtibyXRUSVcTIrPpfnYCulGBDHKh={}
  try: 
   fp=QswtibyXRUSVcTIrPpfnYCulGBDHaA(QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.CP_COOKIE_FILENAME,'r',-1,'utf-8')
   QswtibyXRUSVcTIrPpfnYCulGBDHKh= json.load(fp)
   fp.close()
  except QswtibyXRUSVcTIrPpfnYCulGBDHFk as exception:
   return QswtibyXRUSVcTIrPpfnYCulGBDHax
  QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.CP=QswtibyXRUSVcTIrPpfnYCulGBDHKh
  (QswtibyXRUSVcTIrPpfnYCulGBDHkJ,QswtibyXRUSVcTIrPpfnYCulGBDHkW,QswtibyXRUSVcTIrPpfnYCulGBDHkz)=QswtibyXRUSVcTIrPpfnYCulGBDHka.get_settings_account()
  (QswtibyXRUSVcTIrPpfnYCulGBDHKE,QswtibyXRUSVcTIrPpfnYCulGBDHKJ,QswtibyXRUSVcTIrPpfnYCulGBDHKW)=QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.Load_session_acount()
  if QswtibyXRUSVcTIrPpfnYCulGBDHkJ!=QswtibyXRUSVcTIrPpfnYCulGBDHKE or QswtibyXRUSVcTIrPpfnYCulGBDHkW!=QswtibyXRUSVcTIrPpfnYCulGBDHKJ or QswtibyXRUSVcTIrPpfnYCulGBDHkz!=QswtibyXRUSVcTIrPpfnYCulGBDHFK(QswtibyXRUSVcTIrPpfnYCulGBDHKW):
   QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.Init_CP()
   return QswtibyXRUSVcTIrPpfnYCulGBDHax
  QswtibyXRUSVcTIrPpfnYCulGBDHKz =QswtibyXRUSVcTIrPpfnYCulGBDHae(QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.Get_Now_Datetime().strftime('%Y%m%d'))
  QswtibyXRUSVcTIrPpfnYCulGBDHKx=QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.CP['SESSION']['limitdate']
  QswtibyXRUSVcTIrPpfnYCulGBDHKd =QswtibyXRUSVcTIrPpfnYCulGBDHae(re.sub('-','',QswtibyXRUSVcTIrPpfnYCulGBDHKx))
  if QswtibyXRUSVcTIrPpfnYCulGBDHKd<QswtibyXRUSVcTIrPpfnYCulGBDHKz:
   QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.Init_CP()
   return QswtibyXRUSVcTIrPpfnYCulGBDHax
  return QswtibyXRUSVcTIrPpfnYCulGBDHad
 def CP_login(QswtibyXRUSVcTIrPpfnYCulGBDHka,QswtibyXRUSVcTIrPpfnYCulGBDHkJ,QswtibyXRUSVcTIrPpfnYCulGBDHkW,QswtibyXRUSVcTIrPpfnYCulGBDHkz):
  if QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.Get_CP_Login(QswtibyXRUSVcTIrPpfnYCulGBDHkJ,QswtibyXRUSVcTIrPpfnYCulGBDHkW,QswtibyXRUSVcTIrPpfnYCulGBDHkz)==QswtibyXRUSVcTIrPpfnYCulGBDHax:return QswtibyXRUSVcTIrPpfnYCulGBDHax
  if QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.Get_CP_profile(QswtibyXRUSVcTIrPpfnYCulGBDHkz,limit_days=QswtibyXRUSVcTIrPpfnYCulGBDHae(__addon__.getSetting('cache_ttl')),re_check=QswtibyXRUSVcTIrPpfnYCulGBDHax)==QswtibyXRUSVcTIrPpfnYCulGBDHax:return QswtibyXRUSVcTIrPpfnYCulGBDHax
  return QswtibyXRUSVcTIrPpfnYCulGBDHad
 def dp_Category_GroupList(QswtibyXRUSVcTIrPpfnYCulGBDHka,args):
  QswtibyXRUSVcTIrPpfnYCulGBDHKO =args.get('vType') 
  QswtibyXRUSVcTIrPpfnYCulGBDHKv=QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.Get_Category_GroupList(QswtibyXRUSVcTIrPpfnYCulGBDHKO)
  for QswtibyXRUSVcTIrPpfnYCulGBDHKe in QswtibyXRUSVcTIrPpfnYCulGBDHKv:
   QswtibyXRUSVcTIrPpfnYCulGBDHKN =QswtibyXRUSVcTIrPpfnYCulGBDHKe.get('title')
   QswtibyXRUSVcTIrPpfnYCulGBDHKA=QswtibyXRUSVcTIrPpfnYCulGBDHKe.get('pre_title')
   if QswtibyXRUSVcTIrPpfnYCulGBDHka.get_settings_exclusion21()==QswtibyXRUSVcTIrPpfnYCulGBDHad and QswtibyXRUSVcTIrPpfnYCulGBDHKN=='성인':continue
   QswtibyXRUSVcTIrPpfnYCulGBDHNk={'mediatype':'tvshow','plot':QswtibyXRUSVcTIrPpfnYCulGBDHKA,}
   QswtibyXRUSVcTIrPpfnYCulGBDHKF={'mode':'CATEGORY_LIST','collectionId':QswtibyXRUSVcTIrPpfnYCulGBDHKe.get('collectionId'),'vType':QswtibyXRUSVcTIrPpfnYCulGBDHKe.get('category'),'page':'1',}
   QswtibyXRUSVcTIrPpfnYCulGBDHka.add_dir(QswtibyXRUSVcTIrPpfnYCulGBDHKN,sublabel='',img='',infoLabels=QswtibyXRUSVcTIrPpfnYCulGBDHNk,isFolder=QswtibyXRUSVcTIrPpfnYCulGBDHad,params=QswtibyXRUSVcTIrPpfnYCulGBDHKF)
  xbmcplugin.endOfDirectory(QswtibyXRUSVcTIrPpfnYCulGBDHka._addon_handle,cacheToDisc=QswtibyXRUSVcTIrPpfnYCulGBDHax)
 def dp_Theme_GroupList(QswtibyXRUSVcTIrPpfnYCulGBDHka,args):
  QswtibyXRUSVcTIrPpfnYCulGBDHKO =args.get('vType') 
  QswtibyXRUSVcTIrPpfnYCulGBDHKv=QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.Get_Theme_GroupList(QswtibyXRUSVcTIrPpfnYCulGBDHKO)
  for QswtibyXRUSVcTIrPpfnYCulGBDHKe in QswtibyXRUSVcTIrPpfnYCulGBDHKv:
   QswtibyXRUSVcTIrPpfnYCulGBDHKN =QswtibyXRUSVcTIrPpfnYCulGBDHKe.get('title')
   QswtibyXRUSVcTIrPpfnYCulGBDHKA=QswtibyXRUSVcTIrPpfnYCulGBDHKe.get('pre_title')
   QswtibyXRUSVcTIrPpfnYCulGBDHNk={'mediatype':'tvshow','plot':QswtibyXRUSVcTIrPpfnYCulGBDHKA,}
   QswtibyXRUSVcTIrPpfnYCulGBDHKF={'mode':'CATEGORY_LIST','collectionId':QswtibyXRUSVcTIrPpfnYCulGBDHKe.get('collectionId'),'vType':QswtibyXRUSVcTIrPpfnYCulGBDHKe.get('category'),'page':'1',}
   QswtibyXRUSVcTIrPpfnYCulGBDHka.add_dir(QswtibyXRUSVcTIrPpfnYCulGBDHKN,sublabel='',img='',infoLabels=QswtibyXRUSVcTIrPpfnYCulGBDHNk,isFolder=QswtibyXRUSVcTIrPpfnYCulGBDHad,params=QswtibyXRUSVcTIrPpfnYCulGBDHKF)
  xbmcplugin.endOfDirectory(QswtibyXRUSVcTIrPpfnYCulGBDHka._addon_handle,cacheToDisc=QswtibyXRUSVcTIrPpfnYCulGBDHax)
 def dp_Event_GroupList(QswtibyXRUSVcTIrPpfnYCulGBDHka,args):
  QswtibyXRUSVcTIrPpfnYCulGBDHKv=QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.Get_Event_GroupList()
  for QswtibyXRUSVcTIrPpfnYCulGBDHKe in QswtibyXRUSVcTIrPpfnYCulGBDHKv:
   QswtibyXRUSVcTIrPpfnYCulGBDHKN =QswtibyXRUSVcTIrPpfnYCulGBDHKe.get('title')
   QswtibyXRUSVcTIrPpfnYCulGBDHKA=QswtibyXRUSVcTIrPpfnYCulGBDHKe.get('pre_title')
   QswtibyXRUSVcTIrPpfnYCulGBDHNk={'mediatype':'tvshow','plot':QswtibyXRUSVcTIrPpfnYCulGBDHKA,}
   QswtibyXRUSVcTIrPpfnYCulGBDHKF={'mode':'EVENT_GAMELIST','collectionId':QswtibyXRUSVcTIrPpfnYCulGBDHKe.get('collectionId'),'vType':'LIVE',}
   QswtibyXRUSVcTIrPpfnYCulGBDHka.add_dir(QswtibyXRUSVcTIrPpfnYCulGBDHKN,sublabel='',img='',infoLabels=QswtibyXRUSVcTIrPpfnYCulGBDHNk,isFolder=QswtibyXRUSVcTIrPpfnYCulGBDHad,params=QswtibyXRUSVcTIrPpfnYCulGBDHKF)
  xbmcplugin.endOfDirectory(QswtibyXRUSVcTIrPpfnYCulGBDHka._addon_handle,cacheToDisc=QswtibyXRUSVcTIrPpfnYCulGBDHax)
 def dp_Event_GameList(QswtibyXRUSVcTIrPpfnYCulGBDHka,args):
  QswtibyXRUSVcTIrPpfnYCulGBDHKO =args.get('vType') 
  QswtibyXRUSVcTIrPpfnYCulGBDHNM =args.get('collectionId')
  QswtibyXRUSVcTIrPpfnYCulGBDHKv=QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.Get_Event_GameList(QswtibyXRUSVcTIrPpfnYCulGBDHNM)
  for QswtibyXRUSVcTIrPpfnYCulGBDHKe in QswtibyXRUSVcTIrPpfnYCulGBDHKv:
   QswtibyXRUSVcTIrPpfnYCulGBDHKN =QswtibyXRUSVcTIrPpfnYCulGBDHKe.get('title')
   QswtibyXRUSVcTIrPpfnYCulGBDHFN =QswtibyXRUSVcTIrPpfnYCulGBDHKe.get('id')
   QswtibyXRUSVcTIrPpfnYCulGBDHNL =QswtibyXRUSVcTIrPpfnYCulGBDHKe.get('thumbnail')
   QswtibyXRUSVcTIrPpfnYCulGBDHNa =QswtibyXRUSVcTIrPpfnYCulGBDHKe.get('asis') 
   QswtibyXRUSVcTIrPpfnYCulGBDHNF =QswtibyXRUSVcTIrPpfnYCulGBDHKe.get('addInfo')
   QswtibyXRUSVcTIrPpfnYCulGBDHNm =QswtibyXRUSVcTIrPpfnYCulGBDHKe.get('starttm')
   QswtibyXRUSVcTIrPpfnYCulGBDHNk={'mediatype':'tvshow','title':QswtibyXRUSVcTIrPpfnYCulGBDHKN,'plot':QswtibyXRUSVcTIrPpfnYCulGBDHNF,}
   QswtibyXRUSVcTIrPpfnYCulGBDHKF={'mode':'EVENT_LIST','id':QswtibyXRUSVcTIrPpfnYCulGBDHFN,'asis':QswtibyXRUSVcTIrPpfnYCulGBDHNa,'title':QswtibyXRUSVcTIrPpfnYCulGBDHKN,}
   QswtibyXRUSVcTIrPpfnYCulGBDHka.add_dir(QswtibyXRUSVcTIrPpfnYCulGBDHKN,sublabel=QswtibyXRUSVcTIrPpfnYCulGBDHNm,img=QswtibyXRUSVcTIrPpfnYCulGBDHNL,infoLabels=QswtibyXRUSVcTIrPpfnYCulGBDHNk,isFolder=QswtibyXRUSVcTIrPpfnYCulGBDHad,params=QswtibyXRUSVcTIrPpfnYCulGBDHKF,ContextMenu=QswtibyXRUSVcTIrPpfnYCulGBDHaz)
  xbmcplugin.setContent(QswtibyXRUSVcTIrPpfnYCulGBDHka._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(QswtibyXRUSVcTIrPpfnYCulGBDHka._addon_handle,cacheToDisc=QswtibyXRUSVcTIrPpfnYCulGBDHax)
 def dp_Event_List(QswtibyXRUSVcTIrPpfnYCulGBDHka,args):
  QswtibyXRUSVcTIrPpfnYCulGBDHNq=args.get('id')
  QswtibyXRUSVcTIrPpfnYCulGBDHKv=QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.Get_Event_List(QswtibyXRUSVcTIrPpfnYCulGBDHNq)
  for QswtibyXRUSVcTIrPpfnYCulGBDHKe in QswtibyXRUSVcTIrPpfnYCulGBDHKv:
   QswtibyXRUSVcTIrPpfnYCulGBDHKN =QswtibyXRUSVcTIrPpfnYCulGBDHKe.get('title')
   QswtibyXRUSVcTIrPpfnYCulGBDHFN =QswtibyXRUSVcTIrPpfnYCulGBDHKe.get('id')
   QswtibyXRUSVcTIrPpfnYCulGBDHNL =QswtibyXRUSVcTIrPpfnYCulGBDHKe.get('thumbnail')
   QswtibyXRUSVcTIrPpfnYCulGBDHNa =QswtibyXRUSVcTIrPpfnYCulGBDHKe.get('asis') 
   QswtibyXRUSVcTIrPpfnYCulGBDHNj =QswtibyXRUSVcTIrPpfnYCulGBDHKe.get('duration')
   QswtibyXRUSVcTIrPpfnYCulGBDHNm =QswtibyXRUSVcTIrPpfnYCulGBDHKe.get('starttm')
   QswtibyXRUSVcTIrPpfnYCulGBDHNk={'mediatype':'episode','title':QswtibyXRUSVcTIrPpfnYCulGBDHKN,'plot':QswtibyXRUSVcTIrPpfnYCulGBDHNa,'duration':QswtibyXRUSVcTIrPpfnYCulGBDHNj,}
   QswtibyXRUSVcTIrPpfnYCulGBDHKF={'mode':QswtibyXRUSVcTIrPpfnYCulGBDHNa,'id':QswtibyXRUSVcTIrPpfnYCulGBDHFN,'asis':QswtibyXRUSVcTIrPpfnYCulGBDHNa,'title':QswtibyXRUSVcTIrPpfnYCulGBDHKN,}
   QswtibyXRUSVcTIrPpfnYCulGBDHka.add_dir(QswtibyXRUSVcTIrPpfnYCulGBDHKN,sublabel=QswtibyXRUSVcTIrPpfnYCulGBDHNm,img=QswtibyXRUSVcTIrPpfnYCulGBDHNL,infoLabels=QswtibyXRUSVcTIrPpfnYCulGBDHNk,isFolder=QswtibyXRUSVcTIrPpfnYCulGBDHax,params=QswtibyXRUSVcTIrPpfnYCulGBDHKF,ContextMenu=QswtibyXRUSVcTIrPpfnYCulGBDHaz)
  xbmcplugin.setContent(QswtibyXRUSVcTIrPpfnYCulGBDHka._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(QswtibyXRUSVcTIrPpfnYCulGBDHka._addon_handle,cacheToDisc=QswtibyXRUSVcTIrPpfnYCulGBDHax)
 def dp_Category_List(QswtibyXRUSVcTIrPpfnYCulGBDHka,args):
  QswtibyXRUSVcTIrPpfnYCulGBDHKO =args.get('vType') 
  QswtibyXRUSVcTIrPpfnYCulGBDHNM =args.get('collectionId')
  QswtibyXRUSVcTIrPpfnYCulGBDHNo =QswtibyXRUSVcTIrPpfnYCulGBDHae(args.get('page'))
  QswtibyXRUSVcTIrPpfnYCulGBDHKv,QswtibyXRUSVcTIrPpfnYCulGBDHNg=QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.Get_Category_List(QswtibyXRUSVcTIrPpfnYCulGBDHKO,QswtibyXRUSVcTIrPpfnYCulGBDHNM,QswtibyXRUSVcTIrPpfnYCulGBDHNo)
  for QswtibyXRUSVcTIrPpfnYCulGBDHKe in QswtibyXRUSVcTIrPpfnYCulGBDHKv:
   QswtibyXRUSVcTIrPpfnYCulGBDHKN =QswtibyXRUSVcTIrPpfnYCulGBDHKe.get('title')
   QswtibyXRUSVcTIrPpfnYCulGBDHFN =QswtibyXRUSVcTIrPpfnYCulGBDHKe.get('id')
   QswtibyXRUSVcTIrPpfnYCulGBDHNL =QswtibyXRUSVcTIrPpfnYCulGBDHKe.get('thumbnail')
   QswtibyXRUSVcTIrPpfnYCulGBDHNh =QswtibyXRUSVcTIrPpfnYCulGBDHKe.get('mpaa')
   QswtibyXRUSVcTIrPpfnYCulGBDHNj =QswtibyXRUSVcTIrPpfnYCulGBDHKe.get('duration')
   QswtibyXRUSVcTIrPpfnYCulGBDHNa =QswtibyXRUSVcTIrPpfnYCulGBDHKe.get('asis')
   QswtibyXRUSVcTIrPpfnYCulGBDHNE =QswtibyXRUSVcTIrPpfnYCulGBDHKe.get('badge')
   QswtibyXRUSVcTIrPpfnYCulGBDHNJ =QswtibyXRUSVcTIrPpfnYCulGBDHKe.get('year')
   QswtibyXRUSVcTIrPpfnYCulGBDHNW=QswtibyXRUSVcTIrPpfnYCulGBDHKe.get('seasonList')
   QswtibyXRUSVcTIrPpfnYCulGBDHNz =QswtibyXRUSVcTIrPpfnYCulGBDHKe.get('genreList')
   if QswtibyXRUSVcTIrPpfnYCulGBDHNa in['TVSHOW','EDUCATION']: 
    QswtibyXRUSVcTIrPpfnYCulGBDHNx ='SEASON_LIST'
    QswtibyXRUSVcTIrPpfnYCulGBDHNk={'mediatype':'tvshow','title':QswtibyXRUSVcTIrPpfnYCulGBDHKN,'mpaa':QswtibyXRUSVcTIrPpfnYCulGBDHNh,'genre':QswtibyXRUSVcTIrPpfnYCulGBDHNz,'year':QswtibyXRUSVcTIrPpfnYCulGBDHNJ,'plot':'Year : %s\nSeason : %s'%(QswtibyXRUSVcTIrPpfnYCulGBDHNJ,QswtibyXRUSVcTIrPpfnYCulGBDHNW),}
    QswtibyXRUSVcTIrPpfnYCulGBDHKm =QswtibyXRUSVcTIrPpfnYCulGBDHad
   else:
    QswtibyXRUSVcTIrPpfnYCulGBDHNx ='MOVIE'
    QswtibyXRUSVcTIrPpfnYCulGBDHNk={'mediatype':'movie','title':QswtibyXRUSVcTIrPpfnYCulGBDHKN,'mpaa':QswtibyXRUSVcTIrPpfnYCulGBDHNh,'genre':QswtibyXRUSVcTIrPpfnYCulGBDHNz,'duration':QswtibyXRUSVcTIrPpfnYCulGBDHNj,'year':QswtibyXRUSVcTIrPpfnYCulGBDHNJ,'plot':'(%s)'%(QswtibyXRUSVcTIrPpfnYCulGBDHNh),}
    QswtibyXRUSVcTIrPpfnYCulGBDHKm =QswtibyXRUSVcTIrPpfnYCulGBDHax
    QswtibyXRUSVcTIrPpfnYCulGBDHKN +=' (%s)'%(QswtibyXRUSVcTIrPpfnYCulGBDHFK(QswtibyXRUSVcTIrPpfnYCulGBDHNJ))
   QswtibyXRUSVcTIrPpfnYCulGBDHKF={'mode':QswtibyXRUSVcTIrPpfnYCulGBDHNx,'id':QswtibyXRUSVcTIrPpfnYCulGBDHFN,'asis':QswtibyXRUSVcTIrPpfnYCulGBDHNa,'seasonList':QswtibyXRUSVcTIrPpfnYCulGBDHNW,'title':QswtibyXRUSVcTIrPpfnYCulGBDHKN,'thumbnail':QswtibyXRUSVcTIrPpfnYCulGBDHNL,'year':QswtibyXRUSVcTIrPpfnYCulGBDHNJ,}
   if QswtibyXRUSVcTIrPpfnYCulGBDHka.get_settings_makebookmark():
    QswtibyXRUSVcTIrPpfnYCulGBDHNd={'videoid':QswtibyXRUSVcTIrPpfnYCulGBDHFN,'vidtype':'movie' if QswtibyXRUSVcTIrPpfnYCulGBDHKO=='MOVIES' else 'tvshow','vtitle':QswtibyXRUSVcTIrPpfnYCulGBDHKN,'vsubtitle':'',}
    QswtibyXRUSVcTIrPpfnYCulGBDHNO=json.dumps(QswtibyXRUSVcTIrPpfnYCulGBDHNd)
    QswtibyXRUSVcTIrPpfnYCulGBDHNO=urllib.parse.quote(QswtibyXRUSVcTIrPpfnYCulGBDHNO)
    QswtibyXRUSVcTIrPpfnYCulGBDHNv='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(QswtibyXRUSVcTIrPpfnYCulGBDHNO)
    QswtibyXRUSVcTIrPpfnYCulGBDHNe=[('(통합) 찜 영상에 추가',QswtibyXRUSVcTIrPpfnYCulGBDHNv)]
   else:
    QswtibyXRUSVcTIrPpfnYCulGBDHNe=QswtibyXRUSVcTIrPpfnYCulGBDHaz
   QswtibyXRUSVcTIrPpfnYCulGBDHka.add_dir(QswtibyXRUSVcTIrPpfnYCulGBDHKN,sublabel=QswtibyXRUSVcTIrPpfnYCulGBDHNE,img=QswtibyXRUSVcTIrPpfnYCulGBDHNL,infoLabels=QswtibyXRUSVcTIrPpfnYCulGBDHNk,isFolder=QswtibyXRUSVcTIrPpfnYCulGBDHKm,params=QswtibyXRUSVcTIrPpfnYCulGBDHKF,ContextMenu=QswtibyXRUSVcTIrPpfnYCulGBDHNe)
  if QswtibyXRUSVcTIrPpfnYCulGBDHNg:
   QswtibyXRUSVcTIrPpfnYCulGBDHKF['mode'] ='CATEGORY_LIST' 
   QswtibyXRUSVcTIrPpfnYCulGBDHKF['collectionId']=QswtibyXRUSVcTIrPpfnYCulGBDHNM 
   QswtibyXRUSVcTIrPpfnYCulGBDHKF['vType'] =QswtibyXRUSVcTIrPpfnYCulGBDHKO 
   QswtibyXRUSVcTIrPpfnYCulGBDHKF['page'] =QswtibyXRUSVcTIrPpfnYCulGBDHFK(QswtibyXRUSVcTIrPpfnYCulGBDHNo+1)
   QswtibyXRUSVcTIrPpfnYCulGBDHKN='[B]%s >>[/B]'%'다음 페이지'
   QswtibyXRUSVcTIrPpfnYCulGBDHNA=QswtibyXRUSVcTIrPpfnYCulGBDHFK(QswtibyXRUSVcTIrPpfnYCulGBDHNo+1)
   QswtibyXRUSVcTIrPpfnYCulGBDHKa=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   QswtibyXRUSVcTIrPpfnYCulGBDHka.add_dir(QswtibyXRUSVcTIrPpfnYCulGBDHKN,sublabel=QswtibyXRUSVcTIrPpfnYCulGBDHNA,img=QswtibyXRUSVcTIrPpfnYCulGBDHKa,infoLabels=QswtibyXRUSVcTIrPpfnYCulGBDHaz,isFolder=QswtibyXRUSVcTIrPpfnYCulGBDHad,params=QswtibyXRUSVcTIrPpfnYCulGBDHKF)
  if QswtibyXRUSVcTIrPpfnYCulGBDHKO=='TVSHOWS':xbmcplugin.setContent(QswtibyXRUSVcTIrPpfnYCulGBDHka._addon_handle,'tvshows')
  else:xbmcplugin.setContent(QswtibyXRUSVcTIrPpfnYCulGBDHka._addon_handle,'movies')
  xbmcplugin.endOfDirectory(QswtibyXRUSVcTIrPpfnYCulGBDHka._addon_handle,cacheToDisc=QswtibyXRUSVcTIrPpfnYCulGBDHax)
 def dp_Season_List(QswtibyXRUSVcTIrPpfnYCulGBDHka,args):
  QswtibyXRUSVcTIrPpfnYCulGBDHMk =args.get('title')
  QswtibyXRUSVcTIrPpfnYCulGBDHMK =args.get('id')
  QswtibyXRUSVcTIrPpfnYCulGBDHNa =args.get('asis')
  QswtibyXRUSVcTIrPpfnYCulGBDHNW =args.get('seasonList')
  QswtibyXRUSVcTIrPpfnYCulGBDHNL =args.get('thumbnail')
  QswtibyXRUSVcTIrPpfnYCulGBDHNJ =args.get('year')
  if QswtibyXRUSVcTIrPpfnYCulGBDHNW in['',QswtibyXRUSVcTIrPpfnYCulGBDHaz]:
   QswtibyXRUSVcTIrPpfnYCulGBDHNW=QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.Get_vInfo(QswtibyXRUSVcTIrPpfnYCulGBDHMK).get('seasonList')
  if QswtibyXRUSVcTIrPpfnYCulGBDHFM(QswtibyXRUSVcTIrPpfnYCulGBDHNW.split(','))>1:
   for QswtibyXRUSVcTIrPpfnYCulGBDHMN in QswtibyXRUSVcTIrPpfnYCulGBDHNW.split(','):
    QswtibyXRUSVcTIrPpfnYCulGBDHKN='시즌 '+QswtibyXRUSVcTIrPpfnYCulGBDHMN
    QswtibyXRUSVcTIrPpfnYCulGBDHNk={'mediatype':'tvshow','plot':'%s (%s)'%(QswtibyXRUSVcTIrPpfnYCulGBDHMk,QswtibyXRUSVcTIrPpfnYCulGBDHNJ),}
    QswtibyXRUSVcTIrPpfnYCulGBDHKF={'mode':'EPISODE_LIST','programid':QswtibyXRUSVcTIrPpfnYCulGBDHMK,'programnm':QswtibyXRUSVcTIrPpfnYCulGBDHMk,'season':QswtibyXRUSVcTIrPpfnYCulGBDHMN,'asis':QswtibyXRUSVcTIrPpfnYCulGBDHNa,'programimg':QswtibyXRUSVcTIrPpfnYCulGBDHNL,}
    QswtibyXRUSVcTIrPpfnYCulGBDHML=QswtibyXRUSVcTIrPpfnYCulGBDHNL.replace('\'','\"')
    QswtibyXRUSVcTIrPpfnYCulGBDHML=json.loads(QswtibyXRUSVcTIrPpfnYCulGBDHML)
    QswtibyXRUSVcTIrPpfnYCulGBDHka.add_dir(QswtibyXRUSVcTIrPpfnYCulGBDHKN,sublabel='',img=QswtibyXRUSVcTIrPpfnYCulGBDHML,infoLabels=QswtibyXRUSVcTIrPpfnYCulGBDHNk,isFolder=QswtibyXRUSVcTIrPpfnYCulGBDHad,params=QswtibyXRUSVcTIrPpfnYCulGBDHKF)
   xbmcplugin.setContent(QswtibyXRUSVcTIrPpfnYCulGBDHka._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(QswtibyXRUSVcTIrPpfnYCulGBDHka._addon_handle,cacheToDisc=QswtibyXRUSVcTIrPpfnYCulGBDHax)
  else:
   QswtibyXRUSVcTIrPpfnYCulGBDHMa={'programid':QswtibyXRUSVcTIrPpfnYCulGBDHMK,'programnm':QswtibyXRUSVcTIrPpfnYCulGBDHMk,'season':QswtibyXRUSVcTIrPpfnYCulGBDHNW,'programimg':QswtibyXRUSVcTIrPpfnYCulGBDHNL,}
   QswtibyXRUSVcTIrPpfnYCulGBDHka.dp_Episode_List(QswtibyXRUSVcTIrPpfnYCulGBDHMa)
 def dp_Episode_List(QswtibyXRUSVcTIrPpfnYCulGBDHka,args):
  QswtibyXRUSVcTIrPpfnYCulGBDHMK =args.get('programid')
  QswtibyXRUSVcTIrPpfnYCulGBDHMk =args.get('programnm')
  QswtibyXRUSVcTIrPpfnYCulGBDHMF =args.get('season')
  QswtibyXRUSVcTIrPpfnYCulGBDHMm =args.get('programimg')
  QswtibyXRUSVcTIrPpfnYCulGBDHMq=QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.Get_Episode_List(QswtibyXRUSVcTIrPpfnYCulGBDHMK,QswtibyXRUSVcTIrPpfnYCulGBDHMF)
  for QswtibyXRUSVcTIrPpfnYCulGBDHMN in QswtibyXRUSVcTIrPpfnYCulGBDHMq:
   QswtibyXRUSVcTIrPpfnYCulGBDHMj =QswtibyXRUSVcTIrPpfnYCulGBDHMN.get('title')
   QswtibyXRUSVcTIrPpfnYCulGBDHMo =QswtibyXRUSVcTIrPpfnYCulGBDHMN.get('id')
   QswtibyXRUSVcTIrPpfnYCulGBDHNa =QswtibyXRUSVcTIrPpfnYCulGBDHMN.get('asis')
   QswtibyXRUSVcTIrPpfnYCulGBDHNL =QswtibyXRUSVcTIrPpfnYCulGBDHMN.get('thumbnail')
   QswtibyXRUSVcTIrPpfnYCulGBDHNh =QswtibyXRUSVcTIrPpfnYCulGBDHMN.get('mpaa')
   QswtibyXRUSVcTIrPpfnYCulGBDHNj =QswtibyXRUSVcTIrPpfnYCulGBDHMN.get('duration')
   QswtibyXRUSVcTIrPpfnYCulGBDHNJ =QswtibyXRUSVcTIrPpfnYCulGBDHMN.get('year')
   QswtibyXRUSVcTIrPpfnYCulGBDHMg =QswtibyXRUSVcTIrPpfnYCulGBDHMN.get('episode')
   QswtibyXRUSVcTIrPpfnYCulGBDHNz =QswtibyXRUSVcTIrPpfnYCulGBDHMN.get('genreList')
   QswtibyXRUSVcTIrPpfnYCulGBDHMh =QswtibyXRUSVcTIrPpfnYCulGBDHMN.get('desc')
   QswtibyXRUSVcTIrPpfnYCulGBDHME ='%sx%s'%(QswtibyXRUSVcTIrPpfnYCulGBDHMF,QswtibyXRUSVcTIrPpfnYCulGBDHMg)
   QswtibyXRUSVcTIrPpfnYCulGBDHKN ='%s. %s'%(QswtibyXRUSVcTIrPpfnYCulGBDHME,QswtibyXRUSVcTIrPpfnYCulGBDHMj)
   QswtibyXRUSVcTIrPpfnYCulGBDHNk={'mediatype':'tvshow','mpaa':QswtibyXRUSVcTIrPpfnYCulGBDHNh,'genre':QswtibyXRUSVcTIrPpfnYCulGBDHNz,'duration':QswtibyXRUSVcTIrPpfnYCulGBDHNj,'year':QswtibyXRUSVcTIrPpfnYCulGBDHNJ,'plot':'%s (%s)\n\n%s'%(QswtibyXRUSVcTIrPpfnYCulGBDHMk,QswtibyXRUSVcTIrPpfnYCulGBDHME,QswtibyXRUSVcTIrPpfnYCulGBDHMh),}
   QswtibyXRUSVcTIrPpfnYCulGBDHKF={'mode':'VOD','programid':QswtibyXRUSVcTIrPpfnYCulGBDHMK,'programnm':QswtibyXRUSVcTIrPpfnYCulGBDHMk,'title':QswtibyXRUSVcTIrPpfnYCulGBDHKN,'season':QswtibyXRUSVcTIrPpfnYCulGBDHMF,'id':QswtibyXRUSVcTIrPpfnYCulGBDHMo,'asis':QswtibyXRUSVcTIrPpfnYCulGBDHNa,'thumbnail':QswtibyXRUSVcTIrPpfnYCulGBDHNL,'programimg':QswtibyXRUSVcTIrPpfnYCulGBDHMm,}
   QswtibyXRUSVcTIrPpfnYCulGBDHka.add_dir(QswtibyXRUSVcTIrPpfnYCulGBDHKN,sublabel='',img=QswtibyXRUSVcTIrPpfnYCulGBDHNL,infoLabels=QswtibyXRUSVcTIrPpfnYCulGBDHNk,isFolder=QswtibyXRUSVcTIrPpfnYCulGBDHax,params=QswtibyXRUSVcTIrPpfnYCulGBDHKF)
  xbmcplugin.setContent(QswtibyXRUSVcTIrPpfnYCulGBDHka._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(QswtibyXRUSVcTIrPpfnYCulGBDHka._addon_handle,cacheToDisc=QswtibyXRUSVcTIrPpfnYCulGBDHax)
 def play_VIDEO(QswtibyXRUSVcTIrPpfnYCulGBDHka,args):
  QswtibyXRUSVcTIrPpfnYCulGBDHMJ =args.get('id')
  QswtibyXRUSVcTIrPpfnYCulGBDHNa =args.get('asis')
  if QswtibyXRUSVcTIrPpfnYCulGBDHNa in['HIGHLIGHT']:
   QswtibyXRUSVcTIrPpfnYCulGBDHMW,QswtibyXRUSVcTIrPpfnYCulGBDHMz=QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.GetEventURL(QswtibyXRUSVcTIrPpfnYCulGBDHMJ,QswtibyXRUSVcTIrPpfnYCulGBDHNa)
  elif QswtibyXRUSVcTIrPpfnYCulGBDHNa in['LIVE']:
   QswtibyXRUSVcTIrPpfnYCulGBDHMW,QswtibyXRUSVcTIrPpfnYCulGBDHMz=QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.GetEventURL_Live(QswtibyXRUSVcTIrPpfnYCulGBDHMJ,QswtibyXRUSVcTIrPpfnYCulGBDHNa)
  else:
   QswtibyXRUSVcTIrPpfnYCulGBDHMW,QswtibyXRUSVcTIrPpfnYCulGBDHMz=QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.GetBroadURL(QswtibyXRUSVcTIrPpfnYCulGBDHMJ)
  QswtibyXRUSVcTIrPpfnYCulGBDHka.addon_log('asis, url : %s - %s - %s'%(QswtibyXRUSVcTIrPpfnYCulGBDHNa,QswtibyXRUSVcTIrPpfnYCulGBDHMJ,QswtibyXRUSVcTIrPpfnYCulGBDHMW))
  if QswtibyXRUSVcTIrPpfnYCulGBDHMW=='':
   if QswtibyXRUSVcTIrPpfnYCulGBDHMz=='':
    QswtibyXRUSVcTIrPpfnYCulGBDHka.addon_noti(__language__(30907).encode('utf8'))
   else:
    QswtibyXRUSVcTIrPpfnYCulGBDHka.addon_noti(QswtibyXRUSVcTIrPpfnYCulGBDHMz)
   return
  QswtibyXRUSVcTIrPpfnYCulGBDHMx='PCID=%s;token=%s;member_srl=%s;NEXT_LOCALE=%s;bm_mi=%s;ak_bmsc=%s;bm_sv=%s'%(QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.CP['SESSION']['PCID'],QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.CP['SESSION']['token'],QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.CP['SESSION']['member_srl'],QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.CP['SESSION']['NEXT_LOCALE'],QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.CP['SESSION']['bm_mi'],QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.CP['SESSION']['ak_bmsc'],QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.CP['SESSION']['bm_sv'],)
  QswtibyXRUSVcTIrPpfnYCulGBDHMd='%s|Cookie=%s'%(QswtibyXRUSVcTIrPpfnYCulGBDHMW,QswtibyXRUSVcTIrPpfnYCulGBDHMx)
  QswtibyXRUSVcTIrPpfnYCulGBDHMO=xbmcgui.ListItem(path=QswtibyXRUSVcTIrPpfnYCulGBDHMd)
  if QswtibyXRUSVcTIrPpfnYCulGBDHMz:
   QswtibyXRUSVcTIrPpfnYCulGBDHMv =QswtibyXRUSVcTIrPpfnYCulGBDHMz 
   QswtibyXRUSVcTIrPpfnYCulGBDHMe ='mpd'
   QswtibyXRUSVcTIrPpfnYCulGBDHMA ='com.widevine.alpha'
   QswtibyXRUSVcTIrPpfnYCulGBDHLk =inputstreamhelper.Helper(QswtibyXRUSVcTIrPpfnYCulGBDHMe,drm='widevine')
   if QswtibyXRUSVcTIrPpfnYCulGBDHLk.check_inputstream():
    QswtibyXRUSVcTIrPpfnYCulGBDHLK,QswtibyXRUSVcTIrPpfnYCulGBDHLN,QswtibyXRUSVcTIrPpfnYCulGBDHLM=QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.Make_authHeader()
    QswtibyXRUSVcTIrPpfnYCulGBDHLa={'traceparent':QswtibyXRUSVcTIrPpfnYCulGBDHLK,'tracestate':QswtibyXRUSVcTIrPpfnYCulGBDHLN,'newrelic':QswtibyXRUSVcTIrPpfnYCulGBDHLM,'content-type':'application/octet-stream','User-Agent':QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.USER_AGENT,'Cookie':QswtibyXRUSVcTIrPpfnYCulGBDHMx,}
    QswtibyXRUSVcTIrPpfnYCulGBDHLF=QswtibyXRUSVcTIrPpfnYCulGBDHMv+'|'+urllib.parse.urlencode(QswtibyXRUSVcTIrPpfnYCulGBDHLa)+'|R{SSM}|'
    QswtibyXRUSVcTIrPpfnYCulGBDHMO.setProperty('inputstream',QswtibyXRUSVcTIrPpfnYCulGBDHLk.inputstream_addon)
    QswtibyXRUSVcTIrPpfnYCulGBDHMO.setProperty('inputstream.adaptive.manifest_type',QswtibyXRUSVcTIrPpfnYCulGBDHMe)
    QswtibyXRUSVcTIrPpfnYCulGBDHMO.setProperty('inputstream.adaptive.license_type',QswtibyXRUSVcTIrPpfnYCulGBDHMA)
    QswtibyXRUSVcTIrPpfnYCulGBDHMO.setProperty('inputstream.adaptive.license_key',QswtibyXRUSVcTIrPpfnYCulGBDHLF)
    QswtibyXRUSVcTIrPpfnYCulGBDHMO.setMimeType('application/dash+xml')
    QswtibyXRUSVcTIrPpfnYCulGBDHMO.setContentLookup(QswtibyXRUSVcTIrPpfnYCulGBDHax)
  xbmcplugin.setResolvedUrl(QswtibyXRUSVcTIrPpfnYCulGBDHka._addon_handle,QswtibyXRUSVcTIrPpfnYCulGBDHad,QswtibyXRUSVcTIrPpfnYCulGBDHMO)
  try:
   if QswtibyXRUSVcTIrPpfnYCulGBDHNa=='MOVIE':
    QswtibyXRUSVcTIrPpfnYCulGBDHLm='movie'
    QswtibyXRUSVcTIrPpfnYCulGBDHKF={'code':QswtibyXRUSVcTIrPpfnYCulGBDHMJ,'asis':QswtibyXRUSVcTIrPpfnYCulGBDHNa,'title':args.get('title'),'img':args.get('thumbnail'),}
    QswtibyXRUSVcTIrPpfnYCulGBDHka.Save_Watched_List(QswtibyXRUSVcTIrPpfnYCulGBDHLm,QswtibyXRUSVcTIrPpfnYCulGBDHKF)
   elif QswtibyXRUSVcTIrPpfnYCulGBDHNa=='TVSHOW':
    QswtibyXRUSVcTIrPpfnYCulGBDHLm='tvshow'
    QswtibyXRUSVcTIrPpfnYCulGBDHKF={'code':args.get('programid'),'asis':QswtibyXRUSVcTIrPpfnYCulGBDHNa,'title':'%s <%s>'%(args.get('title'),args.get('programnm')),'img':args.get('programimg'),}
    QswtibyXRUSVcTIrPpfnYCulGBDHka.Save_Watched_List(QswtibyXRUSVcTIrPpfnYCulGBDHLm,QswtibyXRUSVcTIrPpfnYCulGBDHKF)
  except:
   QswtibyXRUSVcTIrPpfnYCulGBDHaz
 def dp_Global_Search(QswtibyXRUSVcTIrPpfnYCulGBDHka,args):
  QswtibyXRUSVcTIrPpfnYCulGBDHNx=args.get('mode')
  if QswtibyXRUSVcTIrPpfnYCulGBDHNx=='TOTAL_SEARCH':
   QswtibyXRUSVcTIrPpfnYCulGBDHLq='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   QswtibyXRUSVcTIrPpfnYCulGBDHLq='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(QswtibyXRUSVcTIrPpfnYCulGBDHLq)
 def dp_Bookmark_Menu(QswtibyXRUSVcTIrPpfnYCulGBDHka,args):
  QswtibyXRUSVcTIrPpfnYCulGBDHLq='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(QswtibyXRUSVcTIrPpfnYCulGBDHLq)
 def dp_Search_List(QswtibyXRUSVcTIrPpfnYCulGBDHka,args):
  QswtibyXRUSVcTIrPpfnYCulGBDHNo =QswtibyXRUSVcTIrPpfnYCulGBDHae(args.get('page'))
  if 'search_key' in args:
   QswtibyXRUSVcTIrPpfnYCulGBDHLj=args.get('search_key')
  else:
   QswtibyXRUSVcTIrPpfnYCulGBDHLj=QswtibyXRUSVcTIrPpfnYCulGBDHka.get_keyboard_input(__language__(30908).encode('utf-8'))
   if not QswtibyXRUSVcTIrPpfnYCulGBDHLj:
    return
  QswtibyXRUSVcTIrPpfnYCulGBDHLo,QswtibyXRUSVcTIrPpfnYCulGBDHNg=QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.Get_Search_List(QswtibyXRUSVcTIrPpfnYCulGBDHLj,QswtibyXRUSVcTIrPpfnYCulGBDHNo)
  for QswtibyXRUSVcTIrPpfnYCulGBDHLg in QswtibyXRUSVcTIrPpfnYCulGBDHLo:
   QswtibyXRUSVcTIrPpfnYCulGBDHFN =QswtibyXRUSVcTIrPpfnYCulGBDHLg.get('id')
   QswtibyXRUSVcTIrPpfnYCulGBDHKN =QswtibyXRUSVcTIrPpfnYCulGBDHLg.get('title')
   QswtibyXRUSVcTIrPpfnYCulGBDHNa =QswtibyXRUSVcTIrPpfnYCulGBDHLg.get('asis')
   QswtibyXRUSVcTIrPpfnYCulGBDHNL =QswtibyXRUSVcTIrPpfnYCulGBDHLg.get('thumbnail')
   QswtibyXRUSVcTIrPpfnYCulGBDHNh =QswtibyXRUSVcTIrPpfnYCulGBDHLg.get('mpaa')
   QswtibyXRUSVcTIrPpfnYCulGBDHNJ =QswtibyXRUSVcTIrPpfnYCulGBDHLg.get('year')
   QswtibyXRUSVcTIrPpfnYCulGBDHNj =QswtibyXRUSVcTIrPpfnYCulGBDHLg.get('duration')
   QswtibyXRUSVcTIrPpfnYCulGBDHNE =QswtibyXRUSVcTIrPpfnYCulGBDHLg.get('badge')
   if QswtibyXRUSVcTIrPpfnYCulGBDHNa=='TVSHOW': 
    QswtibyXRUSVcTIrPpfnYCulGBDHNx ='SEASON_LIST'
    QswtibyXRUSVcTIrPpfnYCulGBDHNk={'mediatype':'tvshow','title':QswtibyXRUSVcTIrPpfnYCulGBDHKN,'mpaa':QswtibyXRUSVcTIrPpfnYCulGBDHNh,'year':QswtibyXRUSVcTIrPpfnYCulGBDHNJ,'plot':'Year : %s'%(QswtibyXRUSVcTIrPpfnYCulGBDHNJ),}
    QswtibyXRUSVcTIrPpfnYCulGBDHKm =QswtibyXRUSVcTIrPpfnYCulGBDHad
   elif QswtibyXRUSVcTIrPpfnYCulGBDHNa=='MOVIE':
    QswtibyXRUSVcTIrPpfnYCulGBDHNx ='MOVIE'
    QswtibyXRUSVcTIrPpfnYCulGBDHNk={'mediatype':'movie','title':QswtibyXRUSVcTIrPpfnYCulGBDHKN,'mpaa':QswtibyXRUSVcTIrPpfnYCulGBDHNh,'duration':QswtibyXRUSVcTIrPpfnYCulGBDHNj,'year':QswtibyXRUSVcTIrPpfnYCulGBDHNJ,'plot':'(%s)'%(QswtibyXRUSVcTIrPpfnYCulGBDHNh),}
    QswtibyXRUSVcTIrPpfnYCulGBDHKm =QswtibyXRUSVcTIrPpfnYCulGBDHax
    QswtibyXRUSVcTIrPpfnYCulGBDHKN +=' (%s)'%(QswtibyXRUSVcTIrPpfnYCulGBDHFK(QswtibyXRUSVcTIrPpfnYCulGBDHNJ))
   elif QswtibyXRUSVcTIrPpfnYCulGBDHNa=='HIGHLIGHT':
    QswtibyXRUSVcTIrPpfnYCulGBDHNx ='HIGHLIGHT'
    QswtibyXRUSVcTIrPpfnYCulGBDHNk={'mediatype':'episode','title':QswtibyXRUSVcTIrPpfnYCulGBDHKN,'duration':QswtibyXRUSVcTIrPpfnYCulGBDHNj,'plot':QswtibyXRUSVcTIrPpfnYCulGBDHNx,}
    QswtibyXRUSVcTIrPpfnYCulGBDHKm =QswtibyXRUSVcTIrPpfnYCulGBDHax
   elif QswtibyXRUSVcTIrPpfnYCulGBDHNa=='LIVE':
    QswtibyXRUSVcTIrPpfnYCulGBDHNx ='LIVE'
    QswtibyXRUSVcTIrPpfnYCulGBDHNk={'mediatype':'episode','title':QswtibyXRUSVcTIrPpfnYCulGBDHKN,'plot':QswtibyXRUSVcTIrPpfnYCulGBDHNx,}
    QswtibyXRUSVcTIrPpfnYCulGBDHKm =QswtibyXRUSVcTIrPpfnYCulGBDHax
   QswtibyXRUSVcTIrPpfnYCulGBDHKF={'mode':QswtibyXRUSVcTIrPpfnYCulGBDHNx,'id':QswtibyXRUSVcTIrPpfnYCulGBDHFN,'asis':QswtibyXRUSVcTIrPpfnYCulGBDHNa,'seasonList':'','title':QswtibyXRUSVcTIrPpfnYCulGBDHKN,'thumbnail':json.dumps(QswtibyXRUSVcTIrPpfnYCulGBDHNL,separators=(',',':')),'year':QswtibyXRUSVcTIrPpfnYCulGBDHNJ,}
   if QswtibyXRUSVcTIrPpfnYCulGBDHka.get_settings_makebookmark()and QswtibyXRUSVcTIrPpfnYCulGBDHNa not in['HIGHLIGHT','']:
    QswtibyXRUSVcTIrPpfnYCulGBDHNd={'videoid':QswtibyXRUSVcTIrPpfnYCulGBDHFN,'vidtype':'movie' if QswtibyXRUSVcTIrPpfnYCulGBDHNa=='MOVIE' else 'tvshow','vtitle':QswtibyXRUSVcTIrPpfnYCulGBDHKN,'vsubtitle':'',}
    QswtibyXRUSVcTIrPpfnYCulGBDHNO=json.dumps(QswtibyXRUSVcTIrPpfnYCulGBDHNd)
    QswtibyXRUSVcTIrPpfnYCulGBDHNO=urllib.parse.quote(QswtibyXRUSVcTIrPpfnYCulGBDHNO)
    QswtibyXRUSVcTIrPpfnYCulGBDHNv='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(QswtibyXRUSVcTIrPpfnYCulGBDHNO)
    QswtibyXRUSVcTIrPpfnYCulGBDHNe=[('(통합) 찜 영상에 추가',QswtibyXRUSVcTIrPpfnYCulGBDHNv)]
   else:
    QswtibyXRUSVcTIrPpfnYCulGBDHNe=QswtibyXRUSVcTIrPpfnYCulGBDHaz
   QswtibyXRUSVcTIrPpfnYCulGBDHka.add_dir(QswtibyXRUSVcTIrPpfnYCulGBDHKN,sublabel=QswtibyXRUSVcTIrPpfnYCulGBDHNE,img=QswtibyXRUSVcTIrPpfnYCulGBDHNL,infoLabels=QswtibyXRUSVcTIrPpfnYCulGBDHNk,isFolder=QswtibyXRUSVcTIrPpfnYCulGBDHKm,params=QswtibyXRUSVcTIrPpfnYCulGBDHKF,ContextMenu=QswtibyXRUSVcTIrPpfnYCulGBDHNe)
  if QswtibyXRUSVcTIrPpfnYCulGBDHNg:
   QswtibyXRUSVcTIrPpfnYCulGBDHKF={}
   QswtibyXRUSVcTIrPpfnYCulGBDHKF['mode'] ='LOCAL_SEARCH'
   QswtibyXRUSVcTIrPpfnYCulGBDHKF['search_key']=QswtibyXRUSVcTIrPpfnYCulGBDHLj
   QswtibyXRUSVcTIrPpfnYCulGBDHKF['page'] =QswtibyXRUSVcTIrPpfnYCulGBDHFK(QswtibyXRUSVcTIrPpfnYCulGBDHNo+1)
   QswtibyXRUSVcTIrPpfnYCulGBDHKN='[B]%s >>[/B]'%'다음 페이지'
   QswtibyXRUSVcTIrPpfnYCulGBDHNA=QswtibyXRUSVcTIrPpfnYCulGBDHFK(QswtibyXRUSVcTIrPpfnYCulGBDHNo+1)
   QswtibyXRUSVcTIrPpfnYCulGBDHKa=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   QswtibyXRUSVcTIrPpfnYCulGBDHka.add_dir(QswtibyXRUSVcTIrPpfnYCulGBDHKN,sublabel=QswtibyXRUSVcTIrPpfnYCulGBDHNA,img=QswtibyXRUSVcTIrPpfnYCulGBDHKa,infoLabels=QswtibyXRUSVcTIrPpfnYCulGBDHaz,isFolder=QswtibyXRUSVcTIrPpfnYCulGBDHad,params=QswtibyXRUSVcTIrPpfnYCulGBDHKF)
  xbmcplugin.setContent(QswtibyXRUSVcTIrPpfnYCulGBDHka._addon_handle,'movies')
  xbmcplugin.endOfDirectory(QswtibyXRUSVcTIrPpfnYCulGBDHka._addon_handle,cacheToDisc=QswtibyXRUSVcTIrPpfnYCulGBDHad)
  if args.get('historyyn')=='Y':QswtibyXRUSVcTIrPpfnYCulGBDHka.Save_Searched_List(QswtibyXRUSVcTIrPpfnYCulGBDHLj)
 def Load_List_File(QswtibyXRUSVcTIrPpfnYCulGBDHka,QswtibyXRUSVcTIrPpfnYCulGBDHLm): 
  try:
   if QswtibyXRUSVcTIrPpfnYCulGBDHLm=='search':
    QswtibyXRUSVcTIrPpfnYCulGBDHLh=QswtibyXRUSVcTIrPpfnYCulGBDHkL
   elif QswtibyXRUSVcTIrPpfnYCulGBDHLm in['tvshow','movie']:
    QswtibyXRUSVcTIrPpfnYCulGBDHLh=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%QswtibyXRUSVcTIrPpfnYCulGBDHLm))
   else:
    return[]
   fp=QswtibyXRUSVcTIrPpfnYCulGBDHaA(QswtibyXRUSVcTIrPpfnYCulGBDHLh,'r',-1,'utf-8')
   QswtibyXRUSVcTIrPpfnYCulGBDHLE=fp.readlines()
   fp.close()
  except:
   QswtibyXRUSVcTIrPpfnYCulGBDHLE=[]
  return QswtibyXRUSVcTIrPpfnYCulGBDHLE
 def Save_Watched_List(QswtibyXRUSVcTIrPpfnYCulGBDHka,QswtibyXRUSVcTIrPpfnYCulGBDHLm,QswtibyXRUSVcTIrPpfnYCulGBDHkq):
  try:
   QswtibyXRUSVcTIrPpfnYCulGBDHLJ=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%QswtibyXRUSVcTIrPpfnYCulGBDHLm))
   QswtibyXRUSVcTIrPpfnYCulGBDHLW=QswtibyXRUSVcTIrPpfnYCulGBDHka.Load_List_File(QswtibyXRUSVcTIrPpfnYCulGBDHLm) 
   fp=QswtibyXRUSVcTIrPpfnYCulGBDHaA(QswtibyXRUSVcTIrPpfnYCulGBDHLJ,'w',-1,'utf-8')
   QswtibyXRUSVcTIrPpfnYCulGBDHLz=urllib.parse.urlencode(QswtibyXRUSVcTIrPpfnYCulGBDHkq)
   QswtibyXRUSVcTIrPpfnYCulGBDHLz=QswtibyXRUSVcTIrPpfnYCulGBDHLz+'\n'
   fp.write(QswtibyXRUSVcTIrPpfnYCulGBDHLz)
   QswtibyXRUSVcTIrPpfnYCulGBDHLx=0
   for QswtibyXRUSVcTIrPpfnYCulGBDHLd in QswtibyXRUSVcTIrPpfnYCulGBDHLW:
    QswtibyXRUSVcTIrPpfnYCulGBDHLO=QswtibyXRUSVcTIrPpfnYCulGBDHav(urllib.parse.parse_qsl(QswtibyXRUSVcTIrPpfnYCulGBDHLd))
    QswtibyXRUSVcTIrPpfnYCulGBDHLv=QswtibyXRUSVcTIrPpfnYCulGBDHkq.get('code').strip()
    QswtibyXRUSVcTIrPpfnYCulGBDHLe=QswtibyXRUSVcTIrPpfnYCulGBDHLO.get('code').strip()
    if QswtibyXRUSVcTIrPpfnYCulGBDHLv!=QswtibyXRUSVcTIrPpfnYCulGBDHLe:
     fp.write(QswtibyXRUSVcTIrPpfnYCulGBDHLd)
     QswtibyXRUSVcTIrPpfnYCulGBDHLx+=1
     if QswtibyXRUSVcTIrPpfnYCulGBDHLx>=50:break
   fp.close()
  except:
   QswtibyXRUSVcTIrPpfnYCulGBDHaz
 def Save_Searched_List(QswtibyXRUSVcTIrPpfnYCulGBDHka,QswtibyXRUSVcTIrPpfnYCulGBDHLj):
  try:
   QswtibyXRUSVcTIrPpfnYCulGBDHLj=QswtibyXRUSVcTIrPpfnYCulGBDHLj.strip()
   QswtibyXRUSVcTIrPpfnYCulGBDHLW=QswtibyXRUSVcTIrPpfnYCulGBDHka.Load_List_File('search') 
   fp=QswtibyXRUSVcTIrPpfnYCulGBDHaA(QswtibyXRUSVcTIrPpfnYCulGBDHkL,'w',-1,'utf-8')
   fp.write(QswtibyXRUSVcTIrPpfnYCulGBDHLj+'\n')
   QswtibyXRUSVcTIrPpfnYCulGBDHLx=0
   for QswtibyXRUSVcTIrPpfnYCulGBDHLd in QswtibyXRUSVcTIrPpfnYCulGBDHLW:
    QswtibyXRUSVcTIrPpfnYCulGBDHLd=QswtibyXRUSVcTIrPpfnYCulGBDHLd.strip()
    if QswtibyXRUSVcTIrPpfnYCulGBDHLj!=QswtibyXRUSVcTIrPpfnYCulGBDHLd:
     fp.write(QswtibyXRUSVcTIrPpfnYCulGBDHLd+'\n')
     QswtibyXRUSVcTIrPpfnYCulGBDHLx+=1
     if QswtibyXRUSVcTIrPpfnYCulGBDHLx>=50:break
   fp.close()
  except:
   QswtibyXRUSVcTIrPpfnYCulGBDHaz
 def dp_Search_History(QswtibyXRUSVcTIrPpfnYCulGBDHka,args):
  QswtibyXRUSVcTIrPpfnYCulGBDHLA=QswtibyXRUSVcTIrPpfnYCulGBDHka.Load_List_File('search')
  for QswtibyXRUSVcTIrPpfnYCulGBDHak in QswtibyXRUSVcTIrPpfnYCulGBDHLA:
   QswtibyXRUSVcTIrPpfnYCulGBDHak=QswtibyXRUSVcTIrPpfnYCulGBDHak.strip()
   QswtibyXRUSVcTIrPpfnYCulGBDHKF={'mode':'LOCAL_SEARCH','search_key':QswtibyXRUSVcTIrPpfnYCulGBDHak,'page':'1','historyyn':'Y',}
   QswtibyXRUSVcTIrPpfnYCulGBDHaK={'mode':'SEARCH_REMOVE','stype':'ONE','skey':QswtibyXRUSVcTIrPpfnYCulGBDHak,}
   QswtibyXRUSVcTIrPpfnYCulGBDHaN=urllib.parse.urlencode(QswtibyXRUSVcTIrPpfnYCulGBDHaK)
   QswtibyXRUSVcTIrPpfnYCulGBDHNe=[('선택된 검색어 ( %s ) 삭제'%(QswtibyXRUSVcTIrPpfnYCulGBDHak),'RunPlugin(plugin://plugin.video.coupangm/?%s)'%(QswtibyXRUSVcTIrPpfnYCulGBDHaN))]
   QswtibyXRUSVcTIrPpfnYCulGBDHka.add_dir(QswtibyXRUSVcTIrPpfnYCulGBDHak,sublabel='',img=QswtibyXRUSVcTIrPpfnYCulGBDHaz,infoLabels=QswtibyXRUSVcTIrPpfnYCulGBDHaz,isFolder=QswtibyXRUSVcTIrPpfnYCulGBDHad,params=QswtibyXRUSVcTIrPpfnYCulGBDHKF,ContextMenu=QswtibyXRUSVcTIrPpfnYCulGBDHNe)
  QswtibyXRUSVcTIrPpfnYCulGBDHNk={'plot':'검색목록 전체를 삭제합니다.'}
  QswtibyXRUSVcTIrPpfnYCulGBDHKN='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  QswtibyXRUSVcTIrPpfnYCulGBDHKF={'mode':'SEARCH_REMOVE','stype':'ALL','skey':'-',}
  QswtibyXRUSVcTIrPpfnYCulGBDHKa=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  QswtibyXRUSVcTIrPpfnYCulGBDHka.add_dir(QswtibyXRUSVcTIrPpfnYCulGBDHKN,sublabel='',img=QswtibyXRUSVcTIrPpfnYCulGBDHKa,infoLabels=QswtibyXRUSVcTIrPpfnYCulGBDHNk,isFolder=QswtibyXRUSVcTIrPpfnYCulGBDHax,params=QswtibyXRUSVcTIrPpfnYCulGBDHKF,isLink=QswtibyXRUSVcTIrPpfnYCulGBDHad)
  xbmcplugin.endOfDirectory(QswtibyXRUSVcTIrPpfnYCulGBDHka._addon_handle,cacheToDisc=QswtibyXRUSVcTIrPpfnYCulGBDHax)
 def dp_Listfile_Delete(QswtibyXRUSVcTIrPpfnYCulGBDHka,args):
  QswtibyXRUSVcTIrPpfnYCulGBDHLm=args.get('stype')
  QswtibyXRUSVcTIrPpfnYCulGBDHaM =args.get('skey')
  QswtibyXRUSVcTIrPpfnYCulGBDHko=xbmcgui.Dialog()
  if QswtibyXRUSVcTIrPpfnYCulGBDHLm=='ALL':
   QswtibyXRUSVcTIrPpfnYCulGBDHKo=QswtibyXRUSVcTIrPpfnYCulGBDHko.yesno(__language__(30911).encode('utf8'),__language__(30906).encode('utf8'))
  elif QswtibyXRUSVcTIrPpfnYCulGBDHLm=='ONE':
   QswtibyXRUSVcTIrPpfnYCulGBDHKo=QswtibyXRUSVcTIrPpfnYCulGBDHko.yesno(__language__(30912).encode('utf8'),__language__(30906).encode('utf8'))
  elif QswtibyXRUSVcTIrPpfnYCulGBDHLm in['tvshow','movie']:
   QswtibyXRUSVcTIrPpfnYCulGBDHKo=QswtibyXRUSVcTIrPpfnYCulGBDHko.yesno(__language__(30913).encode('utf8'),__language__(30906).encode('utf8'))
  if QswtibyXRUSVcTIrPpfnYCulGBDHKo==QswtibyXRUSVcTIrPpfnYCulGBDHax:sys.exit()
  QswtibyXRUSVcTIrPpfnYCulGBDHka.Delete_List_File(QswtibyXRUSVcTIrPpfnYCulGBDHLm,skey=QswtibyXRUSVcTIrPpfnYCulGBDHaM)
  xbmc.executebuiltin("Container.Refresh")
 def Delete_List_File(QswtibyXRUSVcTIrPpfnYCulGBDHka,QswtibyXRUSVcTIrPpfnYCulGBDHLm,skey='-'):
  if QswtibyXRUSVcTIrPpfnYCulGBDHLm=='ALL':
   try:
    QswtibyXRUSVcTIrPpfnYCulGBDHLh=QswtibyXRUSVcTIrPpfnYCulGBDHkL
    fp=QswtibyXRUSVcTIrPpfnYCulGBDHaA(QswtibyXRUSVcTIrPpfnYCulGBDHLh,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    QswtibyXRUSVcTIrPpfnYCulGBDHaz
  elif QswtibyXRUSVcTIrPpfnYCulGBDHLm=='ONE':
   try:
    QswtibyXRUSVcTIrPpfnYCulGBDHLh=QswtibyXRUSVcTIrPpfnYCulGBDHkL
    QswtibyXRUSVcTIrPpfnYCulGBDHLW=QswtibyXRUSVcTIrPpfnYCulGBDHka.Load_List_File('search') 
    fp=QswtibyXRUSVcTIrPpfnYCulGBDHaA(QswtibyXRUSVcTIrPpfnYCulGBDHLh,'w',-1,'utf-8')
    for QswtibyXRUSVcTIrPpfnYCulGBDHLd in QswtibyXRUSVcTIrPpfnYCulGBDHLW:
     if skey!=QswtibyXRUSVcTIrPpfnYCulGBDHLd.strip():
      fp.write(QswtibyXRUSVcTIrPpfnYCulGBDHLd)
    fp.close()
   except:
    QswtibyXRUSVcTIrPpfnYCulGBDHaz
  elif QswtibyXRUSVcTIrPpfnYCulGBDHLm in['tvshow','movie']:
   try:
    QswtibyXRUSVcTIrPpfnYCulGBDHLh=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%QswtibyXRUSVcTIrPpfnYCulGBDHLm))
    fp=QswtibyXRUSVcTIrPpfnYCulGBDHaA(QswtibyXRUSVcTIrPpfnYCulGBDHLh,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    QswtibyXRUSVcTIrPpfnYCulGBDHaz
 def dp_Watch_List(QswtibyXRUSVcTIrPpfnYCulGBDHka,args):
  QswtibyXRUSVcTIrPpfnYCulGBDHLm =args.get('stype')
  if QswtibyXRUSVcTIrPpfnYCulGBDHLm in['',QswtibyXRUSVcTIrPpfnYCulGBDHaz]:
   for QswtibyXRUSVcTIrPpfnYCulGBDHaL in QswtibyXRUSVcTIrPpfnYCulGBDHkM:
    QswtibyXRUSVcTIrPpfnYCulGBDHKN=QswtibyXRUSVcTIrPpfnYCulGBDHaL.get('title')
    QswtibyXRUSVcTIrPpfnYCulGBDHKF={'mode':QswtibyXRUSVcTIrPpfnYCulGBDHaL.get('mode'),'stype':QswtibyXRUSVcTIrPpfnYCulGBDHaL.get('stype'),}
    QswtibyXRUSVcTIrPpfnYCulGBDHka.add_dir(QswtibyXRUSVcTIrPpfnYCulGBDHKN,sublabel='',img='',infoLabels=QswtibyXRUSVcTIrPpfnYCulGBDHaz,isFolder=QswtibyXRUSVcTIrPpfnYCulGBDHad,params=QswtibyXRUSVcTIrPpfnYCulGBDHKF)
   xbmcplugin.endOfDirectory(QswtibyXRUSVcTIrPpfnYCulGBDHka._addon_handle)
  else:
   QswtibyXRUSVcTIrPpfnYCulGBDHaF=QswtibyXRUSVcTIrPpfnYCulGBDHka.Load_List_File(QswtibyXRUSVcTIrPpfnYCulGBDHLm)
   for QswtibyXRUSVcTIrPpfnYCulGBDHam in QswtibyXRUSVcTIrPpfnYCulGBDHaF:
    QswtibyXRUSVcTIrPpfnYCulGBDHaq=QswtibyXRUSVcTIrPpfnYCulGBDHav(urllib.parse.parse_qsl(QswtibyXRUSVcTIrPpfnYCulGBDHam))
    QswtibyXRUSVcTIrPpfnYCulGBDHMJ =QswtibyXRUSVcTIrPpfnYCulGBDHaq.get('code').strip()
    QswtibyXRUSVcTIrPpfnYCulGBDHKN =QswtibyXRUSVcTIrPpfnYCulGBDHaq.get('title').strip()
    QswtibyXRUSVcTIrPpfnYCulGBDHNL =QswtibyXRUSVcTIrPpfnYCulGBDHaq.get('img').strip()
    QswtibyXRUSVcTIrPpfnYCulGBDHNa =QswtibyXRUSVcTIrPpfnYCulGBDHaq.get('asis').strip()
    try:
     QswtibyXRUSVcTIrPpfnYCulGBDHNL=QswtibyXRUSVcTIrPpfnYCulGBDHNL.replace('\'','\"')
     QswtibyXRUSVcTIrPpfnYCulGBDHNL=json.loads(QswtibyXRUSVcTIrPpfnYCulGBDHNL)
    except:
     QswtibyXRUSVcTIrPpfnYCulGBDHaz
    QswtibyXRUSVcTIrPpfnYCulGBDHNk={}
    QswtibyXRUSVcTIrPpfnYCulGBDHNk['plot']=QswtibyXRUSVcTIrPpfnYCulGBDHKN
    if QswtibyXRUSVcTIrPpfnYCulGBDHLm=='movie':
     QswtibyXRUSVcTIrPpfnYCulGBDHKF={'mode':'MOVIE','id':QswtibyXRUSVcTIrPpfnYCulGBDHMJ,'asis':QswtibyXRUSVcTIrPpfnYCulGBDHNa,'title':QswtibyXRUSVcTIrPpfnYCulGBDHKN,'thumbnail':QswtibyXRUSVcTIrPpfnYCulGBDHNL,}
     QswtibyXRUSVcTIrPpfnYCulGBDHKm=QswtibyXRUSVcTIrPpfnYCulGBDHax
    else:
     QswtibyXRUSVcTIrPpfnYCulGBDHKF={'mode':'SEASON_LIST','id':QswtibyXRUSVcTIrPpfnYCulGBDHMJ,'asis':QswtibyXRUSVcTIrPpfnYCulGBDHNa,'title':QswtibyXRUSVcTIrPpfnYCulGBDHKN,'thumbnail':json.dumps(QswtibyXRUSVcTIrPpfnYCulGBDHNL,separators=(',',':')),}
     QswtibyXRUSVcTIrPpfnYCulGBDHKm=QswtibyXRUSVcTIrPpfnYCulGBDHad
    QswtibyXRUSVcTIrPpfnYCulGBDHka.add_dir(QswtibyXRUSVcTIrPpfnYCulGBDHKN,sublabel='',img=QswtibyXRUSVcTIrPpfnYCulGBDHNL,infoLabels=QswtibyXRUSVcTIrPpfnYCulGBDHNk,isFolder=QswtibyXRUSVcTIrPpfnYCulGBDHKm,params=QswtibyXRUSVcTIrPpfnYCulGBDHKF)
   QswtibyXRUSVcTIrPpfnYCulGBDHNk={'plot':'시청목록을 삭제합니다.'}
   QswtibyXRUSVcTIrPpfnYCulGBDHKN='*** 시청목록 삭제 ***'
   QswtibyXRUSVcTIrPpfnYCulGBDHKF={'mode':'MYVIEW_REMOVE','stype':QswtibyXRUSVcTIrPpfnYCulGBDHLm,'skey':'-',}
   QswtibyXRUSVcTIrPpfnYCulGBDHKa=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   QswtibyXRUSVcTIrPpfnYCulGBDHka.add_dir(QswtibyXRUSVcTIrPpfnYCulGBDHKN,sublabel='',img=QswtibyXRUSVcTIrPpfnYCulGBDHKa,infoLabels=QswtibyXRUSVcTIrPpfnYCulGBDHNk,isFolder=QswtibyXRUSVcTIrPpfnYCulGBDHax,params=QswtibyXRUSVcTIrPpfnYCulGBDHKF,isLink=QswtibyXRUSVcTIrPpfnYCulGBDHad)
   if QswtibyXRUSVcTIrPpfnYCulGBDHLm=='movie':xbmcplugin.setContent(QswtibyXRUSVcTIrPpfnYCulGBDHka._addon_handle,'movies')
   else:xbmcplugin.setContent(QswtibyXRUSVcTIrPpfnYCulGBDHka._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(QswtibyXRUSVcTIrPpfnYCulGBDHka._addon_handle,cacheToDisc=QswtibyXRUSVcTIrPpfnYCulGBDHax)
 def dp_Set_Bookmark(QswtibyXRUSVcTIrPpfnYCulGBDHka,args):
  QswtibyXRUSVcTIrPpfnYCulGBDHaj=urllib.parse.unquote(args.get('bm_param'))
  QswtibyXRUSVcTIrPpfnYCulGBDHaj=json.loads(QswtibyXRUSVcTIrPpfnYCulGBDHaj)
  QswtibyXRUSVcTIrPpfnYCulGBDHao =QswtibyXRUSVcTIrPpfnYCulGBDHaj.get('videoid')
  QswtibyXRUSVcTIrPpfnYCulGBDHag =QswtibyXRUSVcTIrPpfnYCulGBDHaj.get('vidtype')
  QswtibyXRUSVcTIrPpfnYCulGBDHah =QswtibyXRUSVcTIrPpfnYCulGBDHaj.get('vtitle')
  QswtibyXRUSVcTIrPpfnYCulGBDHko=xbmcgui.Dialog()
  QswtibyXRUSVcTIrPpfnYCulGBDHKo=QswtibyXRUSVcTIrPpfnYCulGBDHko.yesno(__language__(30914).encode('utf8'),QswtibyXRUSVcTIrPpfnYCulGBDHah+' \n\n'+__language__(30915))
  if QswtibyXRUSVcTIrPpfnYCulGBDHKo==QswtibyXRUSVcTIrPpfnYCulGBDHax:return
  QswtibyXRUSVcTIrPpfnYCulGBDHaE=QswtibyXRUSVcTIrPpfnYCulGBDHka.CoupangObj.GetBookmarkInfo(QswtibyXRUSVcTIrPpfnYCulGBDHao,QswtibyXRUSVcTIrPpfnYCulGBDHag)
  QswtibyXRUSVcTIrPpfnYCulGBDHaJ=json.dumps(QswtibyXRUSVcTIrPpfnYCulGBDHaE)
  QswtibyXRUSVcTIrPpfnYCulGBDHaJ=urllib.parse.quote(QswtibyXRUSVcTIrPpfnYCulGBDHaJ)
  QswtibyXRUSVcTIrPpfnYCulGBDHNv ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(QswtibyXRUSVcTIrPpfnYCulGBDHaJ)
  xbmc.executebuiltin(QswtibyXRUSVcTIrPpfnYCulGBDHNv)
 def coupang_main(QswtibyXRUSVcTIrPpfnYCulGBDHka):
  QswtibyXRUSVcTIrPpfnYCulGBDHNx=QswtibyXRUSVcTIrPpfnYCulGBDHka.main_params.get('mode',QswtibyXRUSVcTIrPpfnYCulGBDHaz)
  if QswtibyXRUSVcTIrPpfnYCulGBDHNx=='LOGOUT':
   QswtibyXRUSVcTIrPpfnYCulGBDHka.CP_logout()
   return
  QswtibyXRUSVcTIrPpfnYCulGBDHka.option_check()
  if QswtibyXRUSVcTIrPpfnYCulGBDHNx is QswtibyXRUSVcTIrPpfnYCulGBDHaz:
   QswtibyXRUSVcTIrPpfnYCulGBDHka.dp_Main_List(QswtibyXRUSVcTIrPpfnYCulGBDHka.main_params)
  elif QswtibyXRUSVcTIrPpfnYCulGBDHNx=='CATEGORY_GROUPLIST':
   QswtibyXRUSVcTIrPpfnYCulGBDHka.dp_Category_GroupList(QswtibyXRUSVcTIrPpfnYCulGBDHka.main_params)
  elif QswtibyXRUSVcTIrPpfnYCulGBDHNx=='THEME_GROUPLIST':
   QswtibyXRUSVcTIrPpfnYCulGBDHka.dp_Theme_GroupList(QswtibyXRUSVcTIrPpfnYCulGBDHka.main_params)
  elif QswtibyXRUSVcTIrPpfnYCulGBDHNx=='EVENT_GROUPLIST':
   QswtibyXRUSVcTIrPpfnYCulGBDHka.dp_Event_GroupList(QswtibyXRUSVcTIrPpfnYCulGBDHka.main_params)
  elif QswtibyXRUSVcTIrPpfnYCulGBDHNx=='EVENT_GAMELIST':
   QswtibyXRUSVcTIrPpfnYCulGBDHka.dp_Event_GameList(QswtibyXRUSVcTIrPpfnYCulGBDHka.main_params)
  elif QswtibyXRUSVcTIrPpfnYCulGBDHNx=='EVENT_LIST':
   QswtibyXRUSVcTIrPpfnYCulGBDHka.dp_Event_List(QswtibyXRUSVcTIrPpfnYCulGBDHka.main_params)
  elif QswtibyXRUSVcTIrPpfnYCulGBDHNx=='CATEGORY_LIST':
   QswtibyXRUSVcTIrPpfnYCulGBDHka.dp_Category_List(QswtibyXRUSVcTIrPpfnYCulGBDHka.main_params)
  elif QswtibyXRUSVcTIrPpfnYCulGBDHNx=='SEASON_LIST':
   QswtibyXRUSVcTIrPpfnYCulGBDHka.dp_Season_List(QswtibyXRUSVcTIrPpfnYCulGBDHka.main_params)
  elif QswtibyXRUSVcTIrPpfnYCulGBDHNx=='EPISODE_LIST':
   QswtibyXRUSVcTIrPpfnYCulGBDHka.dp_Episode_List(QswtibyXRUSVcTIrPpfnYCulGBDHka.main_params)
  elif QswtibyXRUSVcTIrPpfnYCulGBDHNx=='TEST':
   QswtibyXRUSVcTIrPpfnYCulGBDHka.dp_Test(QswtibyXRUSVcTIrPpfnYCulGBDHka.main_params)
  elif QswtibyXRUSVcTIrPpfnYCulGBDHNx in['MOVIE','VOD','HIGHLIGHT','LIVE']:
   QswtibyXRUSVcTIrPpfnYCulGBDHka.play_VIDEO(QswtibyXRUSVcTIrPpfnYCulGBDHka.main_params)
  elif QswtibyXRUSVcTIrPpfnYCulGBDHNx=='WATCH':
   QswtibyXRUSVcTIrPpfnYCulGBDHka.dp_Watch_List(QswtibyXRUSVcTIrPpfnYCulGBDHka.main_params)
  elif QswtibyXRUSVcTIrPpfnYCulGBDHNx=='LOCAL_SEARCH':
   QswtibyXRUSVcTIrPpfnYCulGBDHka.dp_Search_List(QswtibyXRUSVcTIrPpfnYCulGBDHka.main_params)
  elif QswtibyXRUSVcTIrPpfnYCulGBDHNx=='SEARCH_HISTORY':
   QswtibyXRUSVcTIrPpfnYCulGBDHka.dp_Search_History(QswtibyXRUSVcTIrPpfnYCulGBDHka.main_params)
  elif QswtibyXRUSVcTIrPpfnYCulGBDHNx in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   QswtibyXRUSVcTIrPpfnYCulGBDHka.dp_Listfile_Delete(QswtibyXRUSVcTIrPpfnYCulGBDHka.main_params)
  elif QswtibyXRUSVcTIrPpfnYCulGBDHNx in['TOTAL_SEARCH','TOTAL_HISTORY']:
   QswtibyXRUSVcTIrPpfnYCulGBDHka.dp_Global_Search(QswtibyXRUSVcTIrPpfnYCulGBDHka.main_params)
  elif QswtibyXRUSVcTIrPpfnYCulGBDHNx=='MENU_BOOKMARK':
   QswtibyXRUSVcTIrPpfnYCulGBDHka.dp_Bookmark_Menu(QswtibyXRUSVcTIrPpfnYCulGBDHka.main_params)
  elif QswtibyXRUSVcTIrPpfnYCulGBDHNx=='SET_BOOKMARK':
   QswtibyXRUSVcTIrPpfnYCulGBDHka.dp_Set_Bookmark(QswtibyXRUSVcTIrPpfnYCulGBDHka.main_params)
  else:
   QswtibyXRUSVcTIrPpfnYCulGBDHaz
# Created by pyminifier (https://github.com/liftoff/pyminifier)
