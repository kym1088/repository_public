__author__="NightRain"
VfSlQRhAGMomrWtzejyYiIkDFwOqCE=object
VfSlQRhAGMomrWtzejyYiIkDFwOqCb=None
VfSlQRhAGMomrWtzejyYiIkDFwOqCc=False
VfSlQRhAGMomrWtzejyYiIkDFwOqCd=print
VfSlQRhAGMomrWtzejyYiIkDFwOqCa=str
VfSlQRhAGMomrWtzejyYiIkDFwOqCX=open
VfSlQRhAGMomrWtzejyYiIkDFwOqCB=int
VfSlQRhAGMomrWtzejyYiIkDFwOqCJ=Exception
VfSlQRhAGMomrWtzejyYiIkDFwOqCL=id
VfSlQRhAGMomrWtzejyYiIkDFwOqCK=True
VfSlQRhAGMomrWtzejyYiIkDFwOqCH=range
VfSlQRhAGMomrWtzejyYiIkDFwOqCN=len
import urllib
import re
import json
import requests
import datetime
import time
import random
import base64
class VfSlQRhAGMomrWtzejyYiIkDFwOqUu(VfSlQRhAGMomrWtzejyYiIkDFwOqCE):
 def __init__(VfSlQRhAGMomrWtzejyYiIkDFwOqUg):
  VfSlQRhAGMomrWtzejyYiIkDFwOqUg.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36'
  VfSlQRhAGMomrWtzejyYiIkDFwOqUg.MODEL ='Chrome_92' 
  VfSlQRhAGMomrWtzejyYiIkDFwOqUg.DEFAULT_HEADER ={'user-agent':VfSlQRhAGMomrWtzejyYiIkDFwOqUg.USER_AGENT}
  VfSlQRhAGMomrWtzejyYiIkDFwOqUg.API_DOMAIN ='https://www.coupangplay.com'
  VfSlQRhAGMomrWtzejyYiIkDFwOqUg.API_VIEWURL ='https://discover.coupangstreaming.com'
  VfSlQRhAGMomrWtzejyYiIkDFwOqUg.PAGE_LIMIT =40
  VfSlQRhAGMomrWtzejyYiIkDFwOqUg.SEARCH_LIMIT =20
  VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP={}
  VfSlQRhAGMomrWtzejyYiIkDFwOqUg.Init_CP()
  VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP_DEVICE_FILENAME=''
  VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP_COOKIE_FILENAME=''
 def callRequestCookies(VfSlQRhAGMomrWtzejyYiIkDFwOqUg,jobtype,VfSlQRhAGMomrWtzejyYiIkDFwOquC,payload=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,params=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,headers=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,cookies=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,redirects=VfSlQRhAGMomrWtzejyYiIkDFwOqCc):
  VfSlQRhAGMomrWtzejyYiIkDFwOqUC=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.DEFAULT_HEADER
  if headers:VfSlQRhAGMomrWtzejyYiIkDFwOqUC.update(headers)
  if jobtype=='Get':
   VfSlQRhAGMomrWtzejyYiIkDFwOqUv=requests.get(VfSlQRhAGMomrWtzejyYiIkDFwOquC,params=params,headers=VfSlQRhAGMomrWtzejyYiIkDFwOqUC,cookies=cookies,allow_redirects=redirects)
  else:
   VfSlQRhAGMomrWtzejyYiIkDFwOqUv=requests.post(VfSlQRhAGMomrWtzejyYiIkDFwOquC,data=payload,params=params,headers=VfSlQRhAGMomrWtzejyYiIkDFwOqUC,cookies=cookies,allow_redirects=redirects)
  VfSlQRhAGMomrWtzejyYiIkDFwOqCd(VfSlQRhAGMomrWtzejyYiIkDFwOqCa(VfSlQRhAGMomrWtzejyYiIkDFwOqUv.status_code)+' - '+VfSlQRhAGMomrWtzejyYiIkDFwOqCa(VfSlQRhAGMomrWtzejyYiIkDFwOqUv.url))
  return VfSlQRhAGMomrWtzejyYiIkDFwOqUv
 def callRequestCookies_test(VfSlQRhAGMomrWtzejyYiIkDFwOqUg,jobtype,VfSlQRhAGMomrWtzejyYiIkDFwOquC,payload=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,params=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,headers=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,cookies=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,redirects=VfSlQRhAGMomrWtzejyYiIkDFwOqCc):
  VfSlQRhAGMomrWtzejyYiIkDFwOqUC=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.DEFAULT_HEADER
  if headers:VfSlQRhAGMomrWtzejyYiIkDFwOqUC.update(headers)
  VfSlQRhAGMomrWtzejyYiIkDFwOqUv=requests.Request('POST',VfSlQRhAGMomrWtzejyYiIkDFwOquC,headers=headers,data=payload,params=params,cookies=cookies)
  VfSlQRhAGMomrWtzejyYiIkDFwOqUE=VfSlQRhAGMomrWtzejyYiIkDFwOqUv.prepare()
  VfSlQRhAGMomrWtzejyYiIkDFwOqUg.pretty_print_POST(VfSlQRhAGMomrWtzejyYiIkDFwOqUE)
  return VfSlQRhAGMomrWtzejyYiIkDFwOqUv
 def pretty_print_POST(VfSlQRhAGMomrWtzejyYiIkDFwOqUg,req):
  VfSlQRhAGMomrWtzejyYiIkDFwOqCd('{}\n{}\r\n{}\r\n\r\n{}'.format('-----------START-----------',req.method+' '+req.url,'\r\n'.join('{}: {}'.format(k,v)for k,v in req.headers.items()),req.body,))
 def dic_To_jsonfile(VfSlQRhAGMomrWtzejyYiIkDFwOqUg,filename,VfSlQRhAGMomrWtzejyYiIkDFwOqUb):
  if filename=='':return
  fp=VfSlQRhAGMomrWtzejyYiIkDFwOqCX(filename,'w',-1,'utf-8')
  json.dump(VfSlQRhAGMomrWtzejyYiIkDFwOqUb,fp,indent=4,ensure_ascii=VfSlQRhAGMomrWtzejyYiIkDFwOqCc)
  fp.close()
 def jsonfile_To_dic(VfSlQRhAGMomrWtzejyYiIkDFwOqUg,filename):
  if filename=='':return VfSlQRhAGMomrWtzejyYiIkDFwOqCb
  try:
   fp=VfSlQRhAGMomrWtzejyYiIkDFwOqCX(filename,'r',-1,'utf-8')
   VfSlQRhAGMomrWtzejyYiIkDFwOqUd=json.load(fp)
   fp.close()
  except:
   VfSlQRhAGMomrWtzejyYiIkDFwOqUd={}
  return VfSlQRhAGMomrWtzejyYiIkDFwOqUd
 def convert_TimeStr(VfSlQRhAGMomrWtzejyYiIkDFwOqUg,VfSlQRhAGMomrWtzejyYiIkDFwOqUa):
  try:
   VfSlQRhAGMomrWtzejyYiIkDFwOqUa =VfSlQRhAGMomrWtzejyYiIkDFwOqUa[0:16]
   VfSlQRhAGMomrWtzejyYiIkDFwOqUX=datetime.datetime.strptime(VfSlQRhAGMomrWtzejyYiIkDFwOqUa,'%Y-%m-%dT%H:%M')+datetime.timedelta(hours=9)
   return VfSlQRhAGMomrWtzejyYiIkDFwOqUX.strftime('%Y-%m-%d %H:%M')
  except:
   return VfSlQRhAGMomrWtzejyYiIkDFwOqCb
 def Get_Now_Datetime(VfSlQRhAGMomrWtzejyYiIkDFwOqUg):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetNoCache(VfSlQRhAGMomrWtzejyYiIkDFwOqUg):
  VfSlQRhAGMomrWtzejyYiIkDFwOqUJ =VfSlQRhAGMomrWtzejyYiIkDFwOqCB(time.time()*1000)
  return VfSlQRhAGMomrWtzejyYiIkDFwOqUJ
 def generatePcId(VfSlQRhAGMomrWtzejyYiIkDFwOqUg):
  t=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.GetNoCache()
  r=random.random()
  VfSlQRhAGMomrWtzejyYiIkDFwOqUL=VfSlQRhAGMomrWtzejyYiIkDFwOqCa(t)+VfSlQRhAGMomrWtzejyYiIkDFwOqCa(r)[2:12]
  return VfSlQRhAGMomrWtzejyYiIkDFwOqUL
 def generatePvId(VfSlQRhAGMomrWtzejyYiIkDFwOqUg,genType='1'):
  import hashlib
  m=hashlib.md5()
  VfSlQRhAGMomrWtzejyYiIkDFwOqUK=VfSlQRhAGMomrWtzejyYiIkDFwOqCa(random.random())
  m.update(VfSlQRhAGMomrWtzejyYiIkDFwOqUK.encode('utf-8'))
  VfSlQRhAGMomrWtzejyYiIkDFwOqUH=VfSlQRhAGMomrWtzejyYiIkDFwOqCa(m.hexdigest())
  if genType=='1':
   return '%s-%s-%s-%s-%s'%(VfSlQRhAGMomrWtzejyYiIkDFwOqUH[:8],VfSlQRhAGMomrWtzejyYiIkDFwOqUH[8:12],VfSlQRhAGMomrWtzejyYiIkDFwOqUH[12:16],VfSlQRhAGMomrWtzejyYiIkDFwOqUH[16:20],VfSlQRhAGMomrWtzejyYiIkDFwOqUH[20:])
  else:
   return VfSlQRhAGMomrWtzejyYiIkDFwOqUH
 def Get_DeviceID(VfSlQRhAGMomrWtzejyYiIkDFwOqUg):
  VfSlQRhAGMomrWtzejyYiIkDFwOqUN=''
  try: 
   fp=VfSlQRhAGMomrWtzejyYiIkDFwOqCX(VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP_DEVICE_FILENAME,'r',-1,'utf-8')
   VfSlQRhAGMomrWtzejyYiIkDFwOqUn= json.load(fp)
   fp.close()
   VfSlQRhAGMomrWtzejyYiIkDFwOqUN=VfSlQRhAGMomrWtzejyYiIkDFwOqUn.get('device_id')
  except VfSlQRhAGMomrWtzejyYiIkDFwOqCJ as exception:
   VfSlQRhAGMomrWtzejyYiIkDFwOqCb
  if VfSlQRhAGMomrWtzejyYiIkDFwOqUN=='':
   VfSlQRhAGMomrWtzejyYiIkDFwOqUN=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.generatePvId(genType='1')
   try: 
    fp=VfSlQRhAGMomrWtzejyYiIkDFwOqCX(VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP_DEVICE_FILENAME,'w',-1,'utf-8')
    json.dump({'device_id':VfSlQRhAGMomrWtzejyYiIkDFwOqUN},fp,indent=4,ensure_ascii=VfSlQRhAGMomrWtzejyYiIkDFwOqCc)
    fp.close()
   except VfSlQRhAGMomrWtzejyYiIkDFwOqCJ as exception:
    return ''
  return VfSlQRhAGMomrWtzejyYiIkDFwOqUN
 def Make_authHeader(VfSlQRhAGMomrWtzejyYiIkDFwOqUg):
  tr=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.generatePvId(genType=2)
  ti=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.GetNoCache()
  VfSlQRhAGMomrWtzejyYiIkDFwOqCL=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.generatePvId(genType=2)[:16]
  VfSlQRhAGMomrWtzejyYiIkDFwOqUP='00-%s-%s-01'%(tr,VfSlQRhAGMomrWtzejyYiIkDFwOqCL,)
  VfSlQRhAGMomrWtzejyYiIkDFwOqUT ='%s@nr=0-1-%s-%s-%s----%s'%(VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['NREUM']['tk'],VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['NREUM']['ac'],VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['NREUM']['ap'],VfSlQRhAGMomrWtzejyYiIkDFwOqCL,ti,)
  VfSlQRhAGMomrWtzejyYiIkDFwOqUx ='{"v":[0,1],"d":{"ty":"Browser","ac":"%s","ap":"%s","id":"%s","tr":"%s","ti":%s,"tk":"%s"}}'%(VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['NREUM']['ac'],VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['NREUM']['ap'],VfSlQRhAGMomrWtzejyYiIkDFwOqCL,tr,ti,VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['NREUM']['tk'],) 
  return VfSlQRhAGMomrWtzejyYiIkDFwOqUP,VfSlQRhAGMomrWtzejyYiIkDFwOqUT,base64.standard_b64encode(VfSlQRhAGMomrWtzejyYiIkDFwOqUx.encode()).decode('utf-8')
 def Init_CP(VfSlQRhAGMomrWtzejyYiIkDFwOqUg):
  VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP={}
  VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['ACCOUNT']={'cpid':'','cppw':'','cppf':'0'}
  VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']={}
 def Save_session_acount(VfSlQRhAGMomrWtzejyYiIkDFwOqUg,VfSlQRhAGMomrWtzejyYiIkDFwOqUp,VfSlQRhAGMomrWtzejyYiIkDFwOqUs,VfSlQRhAGMomrWtzejyYiIkDFwOquU):
  VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['ACCOUNT']['cpid']=base64.standard_b64encode(VfSlQRhAGMomrWtzejyYiIkDFwOqUp.encode()).decode('utf-8')
  VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['ACCOUNT']['cppw']=base64.standard_b64encode(VfSlQRhAGMomrWtzejyYiIkDFwOqUs.encode()).decode('utf-8')
  VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['ACCOUNT']['cppf']=VfSlQRhAGMomrWtzejyYiIkDFwOqCa(VfSlQRhAGMomrWtzejyYiIkDFwOquU)
 def Load_session_acount(VfSlQRhAGMomrWtzejyYiIkDFwOqUg):
  VfSlQRhAGMomrWtzejyYiIkDFwOqUp=base64.standard_b64decode(VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['ACCOUNT']['cpid']).decode('utf-8')
  VfSlQRhAGMomrWtzejyYiIkDFwOqUs=base64.standard_b64decode(VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['ACCOUNT']['cppw']).decode('utf-8')
  VfSlQRhAGMomrWtzejyYiIkDFwOquU=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['ACCOUNT']['cppf']
  return VfSlQRhAGMomrWtzejyYiIkDFwOqUp,VfSlQRhAGMomrWtzejyYiIkDFwOqUs,VfSlQRhAGMomrWtzejyYiIkDFwOquU
 def make_CP_DefaultCookies(VfSlQRhAGMomrWtzejyYiIkDFwOqUg):
  VfSlQRhAGMomrWtzejyYiIkDFwOqug={}
  if 'NEXT_LOCALE' in VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']:VfSlQRhAGMomrWtzejyYiIkDFwOqug['NEXT_LOCALE']=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['NEXT_LOCALE']
  if 'ak_bmsc' in VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']:VfSlQRhAGMomrWtzejyYiIkDFwOqug['ak_bmsc'] =VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['ak_bmsc']
  if 'bm_mi' in VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']:VfSlQRhAGMomrWtzejyYiIkDFwOqug['bm_mi'] =VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['bm_mi']
  if 'bm_sv' in VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']:VfSlQRhAGMomrWtzejyYiIkDFwOqug['bm_sv'] =VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['bm_sv']
  if 'PCID' in VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']:VfSlQRhAGMomrWtzejyYiIkDFwOqug['PCID'] =VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['PCID']
  if 'member_srl' in VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']:VfSlQRhAGMomrWtzejyYiIkDFwOqug['member_srl']=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['member_srl']
  if 'token' in VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']:VfSlQRhAGMomrWtzejyYiIkDFwOqug['token'] =VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['token']
  return VfSlQRhAGMomrWtzejyYiIkDFwOqug
 def Get_CP_Login(VfSlQRhAGMomrWtzejyYiIkDFwOqUg,userid,userpw,VfSlQRhAGMomrWtzejyYiIkDFwOquL):
  try:
   VfSlQRhAGMomrWtzejyYiIkDFwOquC=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.API_DOMAIN
   VfSlQRhAGMomrWtzejyYiIkDFwOquv=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.callRequestCookies('Get',VfSlQRhAGMomrWtzejyYiIkDFwOquC,payload=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,params=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,headers=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,cookies=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,redirects=VfSlQRhAGMomrWtzejyYiIkDFwOqCc)
   if VfSlQRhAGMomrWtzejyYiIkDFwOquv.status_code not in[301,302]:return VfSlQRhAGMomrWtzejyYiIkDFwOqCc
   for VfSlQRhAGMomrWtzejyYiIkDFwOquE in VfSlQRhAGMomrWtzejyYiIkDFwOquv.cookies:
    if VfSlQRhAGMomrWtzejyYiIkDFwOquE.name=='NEXT_LOCALE':
     VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['NEXT_LOCALE']=VfSlQRhAGMomrWtzejyYiIkDFwOquE.value
    elif VfSlQRhAGMomrWtzejyYiIkDFwOquE.name=='ak_bmsc':
     VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['ak_bmsc']=VfSlQRhAGMomrWtzejyYiIkDFwOquE.value
   VfSlQRhAGMomrWtzejyYiIkDFwOqug={'NEXT_LOCALE':VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['NEXT_LOCALE'],'ak_bmsc':VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['ak_bmsc'],}
   VfSlQRhAGMomrWtzejyYiIkDFwOquv=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.callRequestCookies('Get',VfSlQRhAGMomrWtzejyYiIkDFwOquC,payload=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,params=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,headers=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,cookies=VfSlQRhAGMomrWtzejyYiIkDFwOqug,redirects=VfSlQRhAGMomrWtzejyYiIkDFwOqCc)
   if VfSlQRhAGMomrWtzejyYiIkDFwOquv.status_code not in[200]:return VfSlQRhAGMomrWtzejyYiIkDFwOqCc
   VfSlQRhAGMomrWtzejyYiIkDFwOqub=re.findall('NREUM.loader_config=\{[\w\d\":,-]+\}',VfSlQRhAGMomrWtzejyYiIkDFwOquv.text)[0].split('=')[1]
   VfSlQRhAGMomrWtzejyYiIkDFwOqub=VfSlQRhAGMomrWtzejyYiIkDFwOqub.replace('{','{"').replace(':','":').replace(',',',"')
   VfSlQRhAGMomrWtzejyYiIkDFwOqub=json.loads(VfSlQRhAGMomrWtzejyYiIkDFwOqub)
   VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['NREUM']={'ac':VfSlQRhAGMomrWtzejyYiIkDFwOqub['accountID'],'tk':VfSlQRhAGMomrWtzejyYiIkDFwOqub['trustKey'],'ap':VfSlQRhAGMomrWtzejyYiIkDFwOqub['agentID'],'lk':VfSlQRhAGMomrWtzejyYiIkDFwOqub['licenseKey'],}
   for VfSlQRhAGMomrWtzejyYiIkDFwOquE in VfSlQRhAGMomrWtzejyYiIkDFwOquv.cookies:
    if VfSlQRhAGMomrWtzejyYiIkDFwOquE.name=='bm_mi':
     VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['bm_mi']=VfSlQRhAGMomrWtzejyYiIkDFwOquE.value
    elif VfSlQRhAGMomrWtzejyYiIkDFwOquE.name=='bm_sv':
     VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['bm_sv'] =VfSlQRhAGMomrWtzejyYiIkDFwOquE.value
     VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['bm_sv_ex']=VfSlQRhAGMomrWtzejyYiIkDFwOquE.expires 
  except VfSlQRhAGMomrWtzejyYiIkDFwOqCJ as exception:
   VfSlQRhAGMomrWtzejyYiIkDFwOqCd(exception)
   return VfSlQRhAGMomrWtzejyYiIkDFwOqCc
  try:
   VfSlQRhAGMomrWtzejyYiIkDFwOquC=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.API_DOMAIN+'/api/auth'
   VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['PCID']=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.generatePcId()
   VfSlQRhAGMomrWtzejyYiIkDFwOquc=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.Get_DeviceID()
   VfSlQRhAGMomrWtzejyYiIkDFwOqud =VfSlQRhAGMomrWtzejyYiIkDFwOquc.split('-')[0]
   VfSlQRhAGMomrWtzejyYiIkDFwOqUP,VfSlQRhAGMomrWtzejyYiIkDFwOqUT,VfSlQRhAGMomrWtzejyYiIkDFwOqUx=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.Make_authHeader()
   VfSlQRhAGMomrWtzejyYiIkDFwOqua={'traceparent':VfSlQRhAGMomrWtzejyYiIkDFwOqUP,'tracestate':VfSlQRhAGMomrWtzejyYiIkDFwOqUT,'newrelic':VfSlQRhAGMomrWtzejyYiIkDFwOqUx,'content-type':'application/json',}
   VfSlQRhAGMomrWtzejyYiIkDFwOquX={'device':{'deviceId':'web-'+VfSlQRhAGMomrWtzejyYiIkDFwOquc,'model':VfSlQRhAGMomrWtzejyYiIkDFwOqUg.MODEL,'name':'Chrome Desktop '+VfSlQRhAGMomrWtzejyYiIkDFwOqud,'os':'Windows','osVersion':'10','type':'webclient',},'email':userid,'password':userpw,}
   VfSlQRhAGMomrWtzejyYiIkDFwOquX=json.dumps(VfSlQRhAGMomrWtzejyYiIkDFwOquX,separators=(',',':'))
   VfSlQRhAGMomrWtzejyYiIkDFwOqug={'NEXT_LOCALE':VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['NEXT_LOCALE'],'ak_bmsc':VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['ak_bmsc'],'bm_mi':VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['bm_mi'],'bm_sv':VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['bm_sv'],'PCID':VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['PCID'],}
   VfSlQRhAGMomrWtzejyYiIkDFwOquv=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.callRequestCookies('Post',VfSlQRhAGMomrWtzejyYiIkDFwOquC,payload=VfSlQRhAGMomrWtzejyYiIkDFwOquX,params=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,headers=VfSlQRhAGMomrWtzejyYiIkDFwOqua,cookies=VfSlQRhAGMomrWtzejyYiIkDFwOqug,redirects=VfSlQRhAGMomrWtzejyYiIkDFwOqCc)
   if VfSlQRhAGMomrWtzejyYiIkDFwOquv.status_code not in[200]:
    VfSlQRhAGMomrWtzejyYiIkDFwOquB=json.loads(VfSlQRhAGMomrWtzejyYiIkDFwOquv.text)
    if 'error' in VfSlQRhAGMomrWtzejyYiIkDFwOquB:
     VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['error']=VfSlQRhAGMomrWtzejyYiIkDFwOquB.get('error').get('detail')
    return VfSlQRhAGMomrWtzejyYiIkDFwOqCc
   for VfSlQRhAGMomrWtzejyYiIkDFwOquE in VfSlQRhAGMomrWtzejyYiIkDFwOquv.cookies:
    if VfSlQRhAGMomrWtzejyYiIkDFwOquE.name=='token':
     VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['token']=VfSlQRhAGMomrWtzejyYiIkDFwOquE.value
    elif VfSlQRhAGMomrWtzejyYiIkDFwOquE.name=='member_srl':
     VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['member_srl']=VfSlQRhAGMomrWtzejyYiIkDFwOquE.value
    elif VfSlQRhAGMomrWtzejyYiIkDFwOquE.name=='bm_sv':
     VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['bm_sv'] =VfSlQRhAGMomrWtzejyYiIkDFwOquE.value
     VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['bm_sv_ex']=VfSlQRhAGMomrWtzejyYiIkDFwOquE.expires 
  except VfSlQRhAGMomrWtzejyYiIkDFwOqCJ as exception:
   VfSlQRhAGMomrWtzejyYiIkDFwOqCd(exception)
   return VfSlQRhAGMomrWtzejyYiIkDFwOqCc
  VfSlQRhAGMomrWtzejyYiIkDFwOqUg.Save_session_acount(userid,userpw,VfSlQRhAGMomrWtzejyYiIkDFwOquL)
  return VfSlQRhAGMomrWtzejyYiIkDFwOqCK
 def Get_CP_profile(VfSlQRhAGMomrWtzejyYiIkDFwOqUg,VfSlQRhAGMomrWtzejyYiIkDFwOquL,limit_days=1,re_check=VfSlQRhAGMomrWtzejyYiIkDFwOqCc):
  if re_check==VfSlQRhAGMomrWtzejyYiIkDFwOqCK:
   if VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['bm_sv_ex']>VfSlQRhAGMomrWtzejyYiIkDFwOqCB(time.time()):
    VfSlQRhAGMomrWtzejyYiIkDFwOqCd('bm_sv_ex ok')
    return VfSlQRhAGMomrWtzejyYiIkDFwOqCK
  try:
   VfSlQRhAGMomrWtzejyYiIkDFwOquC=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.API_DOMAIN+'/api/profiles'
   VfSlQRhAGMomrWtzejyYiIkDFwOqUP,VfSlQRhAGMomrWtzejyYiIkDFwOqUT,VfSlQRhAGMomrWtzejyYiIkDFwOqUx=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.Make_authHeader()
   VfSlQRhAGMomrWtzejyYiIkDFwOqua={'traceparent':VfSlQRhAGMomrWtzejyYiIkDFwOqUP,'tracestate':VfSlQRhAGMomrWtzejyYiIkDFwOqUT,'newrelic':VfSlQRhAGMomrWtzejyYiIkDFwOqUx,}
   VfSlQRhAGMomrWtzejyYiIkDFwOqug=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.make_CP_DefaultCookies()
   VfSlQRhAGMomrWtzejyYiIkDFwOquv=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.callRequestCookies('Get',VfSlQRhAGMomrWtzejyYiIkDFwOquC,payload=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,params=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,headers=VfSlQRhAGMomrWtzejyYiIkDFwOqua,cookies=VfSlQRhAGMomrWtzejyYiIkDFwOqug,redirects=VfSlQRhAGMomrWtzejyYiIkDFwOqCc)
   if VfSlQRhAGMomrWtzejyYiIkDFwOquv.status_code not in[200]:return VfSlQRhAGMomrWtzejyYiIkDFwOqCc
   VfSlQRhAGMomrWtzejyYiIkDFwOquB=json.loads(VfSlQRhAGMomrWtzejyYiIkDFwOquv.text)
   VfSlQRhAGMomrWtzejyYiIkDFwOquJ=0 
   for VfSlQRhAGMomrWtzejyYiIkDFwOquE in VfSlQRhAGMomrWtzejyYiIkDFwOquv.cookies:
    VfSlQRhAGMomrWtzejyYiIkDFwOqCd(VfSlQRhAGMomrWtzejyYiIkDFwOquE.name)
    if VfSlQRhAGMomrWtzejyYiIkDFwOquE.name=='bm_sv':
     VfSlQRhAGMomrWtzejyYiIkDFwOquJ=1
     VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['bm_sv'] =VfSlQRhAGMomrWtzejyYiIkDFwOquE.value
     VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['bm_sv_ex']=VfSlQRhAGMomrWtzejyYiIkDFwOquE.expires 
   if VfSlQRhAGMomrWtzejyYiIkDFwOquJ==0:
    VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['bm_sv_ex']=VfSlQRhAGMomrWtzejyYiIkDFwOqCB(time.time())+60*60*2 
   VfSlQRhAGMomrWtzejyYiIkDFwOquL=VfSlQRhAGMomrWtzejyYiIkDFwOquB.get('data')[VfSlQRhAGMomrWtzejyYiIkDFwOqCB(VfSlQRhAGMomrWtzejyYiIkDFwOquL)]
   VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['accountId']=VfSlQRhAGMomrWtzejyYiIkDFwOquL.get('accountId')
   VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['profileId']=VfSlQRhAGMomrWtzejyYiIkDFwOquL.get('profileId')
  except VfSlQRhAGMomrWtzejyYiIkDFwOqCJ as exception:
   VfSlQRhAGMomrWtzejyYiIkDFwOqCd(exception)
   return VfSlQRhAGMomrWtzejyYiIkDFwOqCc
  if re_check==VfSlQRhAGMomrWtzejyYiIkDFwOqCc:
   VfSlQRhAGMomrWtzejyYiIkDFwOquK =VfSlQRhAGMomrWtzejyYiIkDFwOqUg.Get_Now_Datetime()
   VfSlQRhAGMomrWtzejyYiIkDFwOquH=VfSlQRhAGMomrWtzejyYiIkDFwOquK+datetime.timedelta(days=limit_days)
   VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['limitdate']=VfSlQRhAGMomrWtzejyYiIkDFwOquH.strftime('%Y-%m-%d')
  else:
   VfSlQRhAGMomrWtzejyYiIkDFwOqCd('re check')
  VfSlQRhAGMomrWtzejyYiIkDFwOqUg.dic_To_jsonfile(VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP_COOKIE_FILENAME,VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP)
  return VfSlQRhAGMomrWtzejyYiIkDFwOqCK
 def Get_Category_GroupList(VfSlQRhAGMomrWtzejyYiIkDFwOqUg,vType):
  VfSlQRhAGMomrWtzejyYiIkDFwOquN=[] 
  try:
   VfSlQRhAGMomrWtzejyYiIkDFwOquC=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.API_VIEWURL+'/v2/discover/feed' 
   VfSlQRhAGMomrWtzejyYiIkDFwOqun={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false',}
   VfSlQRhAGMomrWtzejyYiIkDFwOquv=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.callRequestCookies('Get',VfSlQRhAGMomrWtzejyYiIkDFwOquC,payload=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,params=VfSlQRhAGMomrWtzejyYiIkDFwOqun,headers=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,cookies=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,redirects=VfSlQRhAGMomrWtzejyYiIkDFwOqCK)
   if VfSlQRhAGMomrWtzejyYiIkDFwOquv.status_code not in[200]:return[]
   VfSlQRhAGMomrWtzejyYiIkDFwOquB=json.loads(VfSlQRhAGMomrWtzejyYiIkDFwOquv.text)
   if vType in['TVSHOWS','MOVIES']:
    VfSlQRhAGMomrWtzejyYiIkDFwOquP='Explores' 
   elif vType in['EDUCATION']:
    VfSlQRhAGMomrWtzejyYiIkDFwOquP='Collection-Rails-Curation'
   elif vType in['ALL']:
    VfSlQRhAGMomrWtzejyYiIkDFwOquP='Explores-Categories'
   for VfSlQRhAGMomrWtzejyYiIkDFwOquT in VfSlQRhAGMomrWtzejyYiIkDFwOquB.get('data'):
    if VfSlQRhAGMomrWtzejyYiIkDFwOquT.get('type')==VfSlQRhAGMomrWtzejyYiIkDFwOquP:
     for VfSlQRhAGMomrWtzejyYiIkDFwOqux in VfSlQRhAGMomrWtzejyYiIkDFwOquT.get('data'):
      if vType in['TVSHOWS','MOVIES']:
       VfSlQRhAGMomrWtzejyYiIkDFwOqup=VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('collectionId')
      elif vType in['EDUCATION','ALL']:
       VfSlQRhAGMomrWtzejyYiIkDFwOqup=VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('id')
      VfSlQRhAGMomrWtzejyYiIkDFwOqus={'collectionId':VfSlQRhAGMomrWtzejyYiIkDFwOqup,'title':VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('name'),'category':VfSlQRhAGMomrWtzejyYiIkDFwOquT.get('category'),'pre_title':'',}
      VfSlQRhAGMomrWtzejyYiIkDFwOquN.append(VfSlQRhAGMomrWtzejyYiIkDFwOqus)
     break
  except VfSlQRhAGMomrWtzejyYiIkDFwOqCJ as exception:
   VfSlQRhAGMomrWtzejyYiIkDFwOqCd(exception)
   return[]
  return VfSlQRhAGMomrWtzejyYiIkDFwOquN
 def Get_Category_List(VfSlQRhAGMomrWtzejyYiIkDFwOqUg,vType,VfSlQRhAGMomrWtzejyYiIkDFwOqup,page_int):
  VfSlQRhAGMomrWtzejyYiIkDFwOquN=[] 
  VfSlQRhAGMomrWtzejyYiIkDFwOqgU=VfSlQRhAGMomrWtzejyYiIkDFwOqCc
  try:
   if vType=='ALL':
    VfSlQRhAGMomrWtzejyYiIkDFwOqua={'x-membersrl':VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['member_srl'],'x-pcid':VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['PCID'],'x-profileid':VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['profileId'],}
    VfSlQRhAGMomrWtzejyYiIkDFwOqun={'platform':'WEBCLIENT','page':VfSlQRhAGMomrWtzejyYiIkDFwOqCa(page_int),'perPage':VfSlQRhAGMomrWtzejyYiIkDFwOqCa(VfSlQRhAGMomrWtzejyYiIkDFwOqUg.PAGE_LIMIT),'locale':'ko','sort':'',}
    VfSlQRhAGMomrWtzejyYiIkDFwOquC=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.API_VIEWURL+'/v1/discover/categories/'+VfSlQRhAGMomrWtzejyYiIkDFwOqup+'/titles'
    VfSlQRhAGMomrWtzejyYiIkDFwOquv=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.callRequestCookies('Get',VfSlQRhAGMomrWtzejyYiIkDFwOquC,payload=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,params=VfSlQRhAGMomrWtzejyYiIkDFwOqun,headers=VfSlQRhAGMomrWtzejyYiIkDFwOqua,cookies=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,redirects=VfSlQRhAGMomrWtzejyYiIkDFwOqCK)
   else: 
    VfSlQRhAGMomrWtzejyYiIkDFwOqun={'platform':'WEBCLIENT','page':VfSlQRhAGMomrWtzejyYiIkDFwOqCa(page_int),'perPage':VfSlQRhAGMomrWtzejyYiIkDFwOqCa(VfSlQRhAGMomrWtzejyYiIkDFwOqUg.PAGE_LIMIT),}
    VfSlQRhAGMomrWtzejyYiIkDFwOquC=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.API_VIEWURL+'/v1/discover/collections/'+VfSlQRhAGMomrWtzejyYiIkDFwOqup+'/titles'
    VfSlQRhAGMomrWtzejyYiIkDFwOquv=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.callRequestCookies('Get',VfSlQRhAGMomrWtzejyYiIkDFwOquC,payload=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,params=VfSlQRhAGMomrWtzejyYiIkDFwOqun,headers=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,cookies=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,redirects=VfSlQRhAGMomrWtzejyYiIkDFwOqCK)
   if VfSlQRhAGMomrWtzejyYiIkDFwOquv.status_code not in[200]:return[],VfSlQRhAGMomrWtzejyYiIkDFwOqCc
   VfSlQRhAGMomrWtzejyYiIkDFwOquB=json.loads(VfSlQRhAGMomrWtzejyYiIkDFwOquv.text)
   if vType=='ALL':
    VfSlQRhAGMomrWtzejyYiIkDFwOqgu=VfSlQRhAGMomrWtzejyYiIkDFwOquB.get('data').get('data')
   else:
    VfSlQRhAGMomrWtzejyYiIkDFwOqgu=VfSlQRhAGMomrWtzejyYiIkDFwOquB.get('data')
   for VfSlQRhAGMomrWtzejyYiIkDFwOqux in VfSlQRhAGMomrWtzejyYiIkDFwOqgu:
    VfSlQRhAGMomrWtzejyYiIkDFwOqgC=VfSlQRhAGMomrWtzejyYiIkDFwOqgd=VfSlQRhAGMomrWtzejyYiIkDFwOqCU=VfSlQRhAGMomrWtzejyYiIkDFwOqgs=''
    if 'poster' in VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('images'):VfSlQRhAGMomrWtzejyYiIkDFwOqgC =VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('images').get('poster').get('url')
    if 'story-art' in VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('images'):VfSlQRhAGMomrWtzejyYiIkDFwOqgd =VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('images').get('story-art').get('url')
    if 'title-treatment' in VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('images'):VfSlQRhAGMomrWtzejyYiIkDFwOqCU=VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('images').get('title-treatment').get('url')
    if 'story-art' in VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('images'):VfSlQRhAGMomrWtzejyYiIkDFwOqgs =VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('images').get('story-art').get('url')
    VfSlQRhAGMomrWtzejyYiIkDFwOqgv=''
    if VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('badge')not in[{},VfSlQRhAGMomrWtzejyYiIkDFwOqCb]:
     for i in VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('badge').get('text'):
      VfSlQRhAGMomrWtzejyYiIkDFwOqgv+=i.get('text')
    VfSlQRhAGMomrWtzejyYiIkDFwOqgE=''
    if VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('seasonList')!=VfSlQRhAGMomrWtzejyYiIkDFwOqCb:
     VfSlQRhAGMomrWtzejyYiIkDFwOqgE=','.join(VfSlQRhAGMomrWtzejyYiIkDFwOqCa(e)for e in VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('seasonList'))
    VfSlQRhAGMomrWtzejyYiIkDFwOqgb =[]
    for VfSlQRhAGMomrWtzejyYiIkDFwOqgc in VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('tags'):
     VfSlQRhAGMomrWtzejyYiIkDFwOqgb.append(VfSlQRhAGMomrWtzejyYiIkDFwOqgc.get('tag'))
    VfSlQRhAGMomrWtzejyYiIkDFwOqus={'id':VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('id'),'title':VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('title'),'thumbnail':{'poster':VfSlQRhAGMomrWtzejyYiIkDFwOqgC,'thumb':VfSlQRhAGMomrWtzejyYiIkDFwOqgd,'clearlogo':VfSlQRhAGMomrWtzejyYiIkDFwOqCU,'fanart':VfSlQRhAGMomrWtzejyYiIkDFwOqgs},'mpaa':VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('age_rating'),'duration':VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('running_time'),'asis':VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('as'),'badge':VfSlQRhAGMomrWtzejyYiIkDFwOqgv,'year':VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('meta').get('releaseYear'),'seasonList':VfSlQRhAGMomrWtzejyYiIkDFwOqgE,'genreList':VfSlQRhAGMomrWtzejyYiIkDFwOqgb,}
    VfSlQRhAGMomrWtzejyYiIkDFwOquN.append(VfSlQRhAGMomrWtzejyYiIkDFwOqus)
   if VfSlQRhAGMomrWtzejyYiIkDFwOquB.get('pagination').get('totalPages')>page_int:
    VfSlQRhAGMomrWtzejyYiIkDFwOqgU=VfSlQRhAGMomrWtzejyYiIkDFwOqCK
  except VfSlQRhAGMomrWtzejyYiIkDFwOqCJ as exception:
   VfSlQRhAGMomrWtzejyYiIkDFwOqCd(exception)
   return[],VfSlQRhAGMomrWtzejyYiIkDFwOqCc
  return VfSlQRhAGMomrWtzejyYiIkDFwOquN,VfSlQRhAGMomrWtzejyYiIkDFwOqgU
 def Get_Episode_List(VfSlQRhAGMomrWtzejyYiIkDFwOqUg,programId,season):
  VfSlQRhAGMomrWtzejyYiIkDFwOquN=[] 
  try:
   VfSlQRhAGMomrWtzejyYiIkDFwOquC=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.API_VIEWURL+'/v1/discover/titles/'+programId+'/episodes'
   VfSlQRhAGMomrWtzejyYiIkDFwOqun={'season':season,'sort':'true','locale':'ko',}
   VfSlQRhAGMomrWtzejyYiIkDFwOquv=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.callRequestCookies('Get',VfSlQRhAGMomrWtzejyYiIkDFwOquC,payload=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,params=VfSlQRhAGMomrWtzejyYiIkDFwOqun,headers=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,cookies=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,redirects=VfSlQRhAGMomrWtzejyYiIkDFwOqCK)
   if VfSlQRhAGMomrWtzejyYiIkDFwOquv.status_code not in[200]:return[]
   VfSlQRhAGMomrWtzejyYiIkDFwOquB=json.loads(VfSlQRhAGMomrWtzejyYiIkDFwOquv.text)
   for VfSlQRhAGMomrWtzejyYiIkDFwOqux in VfSlQRhAGMomrWtzejyYiIkDFwOquB.get('data'):
    VfSlQRhAGMomrWtzejyYiIkDFwOqgd=''
    if 'story-art' in VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('images'):VfSlQRhAGMomrWtzejyYiIkDFwOqgd =VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('images').get('story-art').get('url')
    VfSlQRhAGMomrWtzejyYiIkDFwOqgb =[]
    for VfSlQRhAGMomrWtzejyYiIkDFwOqgc in VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('tags'):
     VfSlQRhAGMomrWtzejyYiIkDFwOqgb.append(VfSlQRhAGMomrWtzejyYiIkDFwOqgc.get('tag'))
    VfSlQRhAGMomrWtzejyYiIkDFwOqus={'id':VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('id'),'title':VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('title'),'thumbnail':{'thumb':VfSlQRhAGMomrWtzejyYiIkDFwOqgd,'fanart':VfSlQRhAGMomrWtzejyYiIkDFwOqgd},'mpaa':VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('age_rating'),'duration':VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('running_time'),'asis':VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('as'),'year':VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('meta').get('releaseYear'),'episode':VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('episode'),'genreList':VfSlQRhAGMomrWtzejyYiIkDFwOqgb,'desc':VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('description'),}
    VfSlQRhAGMomrWtzejyYiIkDFwOquN.append(VfSlQRhAGMomrWtzejyYiIkDFwOqus)
  except VfSlQRhAGMomrWtzejyYiIkDFwOqCJ as exception:
   VfSlQRhAGMomrWtzejyYiIkDFwOqCd(exception)
   return[]
  return VfSlQRhAGMomrWtzejyYiIkDFwOquN
 def Get_vInfo(VfSlQRhAGMomrWtzejyYiIkDFwOqUg,titleId):
  try:
   VfSlQRhAGMomrWtzejyYiIkDFwOquC=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.API_VIEWURL+'/v1/discover/titles/'+titleId 
   VfSlQRhAGMomrWtzejyYiIkDFwOqun={'locale':'ko'}
   VfSlQRhAGMomrWtzejyYiIkDFwOquv=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.callRequestCookies('Get',VfSlQRhAGMomrWtzejyYiIkDFwOquC,payload=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,params=VfSlQRhAGMomrWtzejyYiIkDFwOqun,headers=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,cookies=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,redirects=VfSlQRhAGMomrWtzejyYiIkDFwOqCK)
   if VfSlQRhAGMomrWtzejyYiIkDFwOquv.status_code not in[200]:return '','',''
   VfSlQRhAGMomrWtzejyYiIkDFwOquB=json.loads(VfSlQRhAGMomrWtzejyYiIkDFwOquv.text).get('data')
   VfSlQRhAGMomrWtzejyYiIkDFwOqgE=''
   if VfSlQRhAGMomrWtzejyYiIkDFwOquB.get('seasonList')!=VfSlQRhAGMomrWtzejyYiIkDFwOqCb:
    VfSlQRhAGMomrWtzejyYiIkDFwOqgE=','.join(VfSlQRhAGMomrWtzejyYiIkDFwOqCa(e)for e in VfSlQRhAGMomrWtzejyYiIkDFwOquB.get('seasonList'))
   VfSlQRhAGMomrWtzejyYiIkDFwOqga={'age_rating':VfSlQRhAGMomrWtzejyYiIkDFwOquB.get('age_rating'),'asset_id':VfSlQRhAGMomrWtzejyYiIkDFwOquB.get('asset_id'),'availability':VfSlQRhAGMomrWtzejyYiIkDFwOquB.get('availability'),'deal_id':VfSlQRhAGMomrWtzejyYiIkDFwOquB.get('deal_id'),'downloadable':'true' if VfSlQRhAGMomrWtzejyYiIkDFwOquB.get('downloadable')else 'false','region':VfSlQRhAGMomrWtzejyYiIkDFwOquB.get('region'),'streamable':'true' if VfSlQRhAGMomrWtzejyYiIkDFwOquB.get('streamable')else 'false','asis':VfSlQRhAGMomrWtzejyYiIkDFwOquB.get('as'),'seasonList':VfSlQRhAGMomrWtzejyYiIkDFwOqgE}
  except VfSlQRhAGMomrWtzejyYiIkDFwOqCJ as exception:
   VfSlQRhAGMomrWtzejyYiIkDFwOqCd(exception)
   return{}
  return VfSlQRhAGMomrWtzejyYiIkDFwOqga
 def Get_eInfo(VfSlQRhAGMomrWtzejyYiIkDFwOqUg,eventId):
  try:
   VfSlQRhAGMomrWtzejyYiIkDFwOquC=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.API_VIEWURL+'/v1/discover/events/'+eventId 
   VfSlQRhAGMomrWtzejyYiIkDFwOqun={'locale':'ko'}
   VfSlQRhAGMomrWtzejyYiIkDFwOquv=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.callRequestCookies('Get',VfSlQRhAGMomrWtzejyYiIkDFwOquC,payload=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,params=VfSlQRhAGMomrWtzejyYiIkDFwOqun,headers=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,cookies=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,redirects=VfSlQRhAGMomrWtzejyYiIkDFwOqCK)
   if VfSlQRhAGMomrWtzejyYiIkDFwOquv.status_code not in[200]:return '','',''
   VfSlQRhAGMomrWtzejyYiIkDFwOquB=json.loads(VfSlQRhAGMomrWtzejyYiIkDFwOquv.text).get('data')
   VfSlQRhAGMomrWtzejyYiIkDFwOqga={'asset_id':VfSlQRhAGMomrWtzejyYiIkDFwOquB.get('asset_id'),'deal_id':VfSlQRhAGMomrWtzejyYiIkDFwOquB.get('deal_id'),'region':VfSlQRhAGMomrWtzejyYiIkDFwOquB.get('region'),'streamable':'true' if VfSlQRhAGMomrWtzejyYiIkDFwOquB.get('streamable')else 'false',}
  except VfSlQRhAGMomrWtzejyYiIkDFwOqCJ as exception:
   VfSlQRhAGMomrWtzejyYiIkDFwOqCd(exception)
   return{}
  return VfSlQRhAGMomrWtzejyYiIkDFwOqga
 def GetBroadURL(VfSlQRhAGMomrWtzejyYiIkDFwOqUg,titleId):
  VfSlQRhAGMomrWtzejyYiIkDFwOqgX=''
  VfSlQRhAGMomrWtzejyYiIkDFwOqgB =''
  VfSlQRhAGMomrWtzejyYiIkDFwOqga=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.Get_vInfo(titleId)
  if VfSlQRhAGMomrWtzejyYiIkDFwOqga=={}:return '',''
  try:
   VfSlQRhAGMomrWtzejyYiIkDFwOquC=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.API_DOMAIN+'/api/playback/play' 
   VfSlQRhAGMomrWtzejyYiIkDFwOqun={'titleId':titleId}
   VfSlQRhAGMomrWtzejyYiIkDFwOqUP,VfSlQRhAGMomrWtzejyYiIkDFwOqUT,VfSlQRhAGMomrWtzejyYiIkDFwOqUx=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.Make_authHeader()
   VfSlQRhAGMomrWtzejyYiIkDFwOqua={'traceparent':VfSlQRhAGMomrWtzejyYiIkDFwOqUP,'tracestate':VfSlQRhAGMomrWtzejyYiIkDFwOqUT,'newrelic':VfSlQRhAGMomrWtzejyYiIkDFwOqUx,'x-force-raw':'true','x-pcid':VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':VfSlQRhAGMomrWtzejyYiIkDFwOqga.get('age_rating'),'x-title-availability':VfSlQRhAGMomrWtzejyYiIkDFwOqga.get('availability'),'x-title-brightcove-id':VfSlQRhAGMomrWtzejyYiIkDFwOqga.get('asset_id'),'x-title-deal-id':VfSlQRhAGMomrWtzejyYiIkDFwOqga.get('deal_id'),'x-title-downloadable':VfSlQRhAGMomrWtzejyYiIkDFwOqga.get('downloadable'),'x-title-region':VfSlQRhAGMomrWtzejyYiIkDFwOqga.get('region'),'x-title-streamable':VfSlQRhAGMomrWtzejyYiIkDFwOqga.get('streamable'),}
   VfSlQRhAGMomrWtzejyYiIkDFwOqug=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.make_CP_DefaultCookies()
   VfSlQRhAGMomrWtzejyYiIkDFwOquv=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.callRequestCookies('Get',VfSlQRhAGMomrWtzejyYiIkDFwOquC,payload=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,params=VfSlQRhAGMomrWtzejyYiIkDFwOqun,headers=VfSlQRhAGMomrWtzejyYiIkDFwOqua,cookies=VfSlQRhAGMomrWtzejyYiIkDFwOqug,redirects=VfSlQRhAGMomrWtzejyYiIkDFwOqCK)
   if VfSlQRhAGMomrWtzejyYiIkDFwOquv.status_code not in[200]:return '',json.loads(VfSlQRhAGMomrWtzejyYiIkDFwOquv.text).get('error').get('detail')
   VfSlQRhAGMomrWtzejyYiIkDFwOquB=json.loads(VfSlQRhAGMomrWtzejyYiIkDFwOquv.text)
   for VfSlQRhAGMomrWtzejyYiIkDFwOqux in VfSlQRhAGMomrWtzejyYiIkDFwOquB.get('data').get('raw').get('sources'):
    if VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('type')=='application/dash+xml' and VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('src')[0:8]=='https://':
     VfSlQRhAGMomrWtzejyYiIkDFwOqgX=VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('src')
     if 'key_systems' in VfSlQRhAGMomrWtzejyYiIkDFwOqux:
      VfSlQRhAGMomrWtzejyYiIkDFwOqgB =VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('key_systems').get('com.widevine.alpha').get('license_url')
     break
  except VfSlQRhAGMomrWtzejyYiIkDFwOqCJ as exception:
   VfSlQRhAGMomrWtzejyYiIkDFwOqCd(exception)
   return '',''
  return VfSlQRhAGMomrWtzejyYiIkDFwOqgX,VfSlQRhAGMomrWtzejyYiIkDFwOqgB
 def GetEventURL(VfSlQRhAGMomrWtzejyYiIkDFwOqUg,eventId,VfSlQRhAGMomrWtzejyYiIkDFwOqgn):
  VfSlQRhAGMomrWtzejyYiIkDFwOqgX=''
  VfSlQRhAGMomrWtzejyYiIkDFwOqgB =''
  VfSlQRhAGMomrWtzejyYiIkDFwOqga=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.Get_eInfo(eventId)
  if VfSlQRhAGMomrWtzejyYiIkDFwOqga=={}:return '',''
  try:
   VfSlQRhAGMomrWtzejyYiIkDFwOquC=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.API_DOMAIN+'/api/playback/play' 
   VfSlQRhAGMomrWtzejyYiIkDFwOqun={'titleId':eventId,'titleType':VfSlQRhAGMomrWtzejyYiIkDFwOqgn,}
   VfSlQRhAGMomrWtzejyYiIkDFwOqUP,VfSlQRhAGMomrWtzejyYiIkDFwOqUT,VfSlQRhAGMomrWtzejyYiIkDFwOqUx=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.Make_authHeader()
   VfSlQRhAGMomrWtzejyYiIkDFwOqua={'traceparent':VfSlQRhAGMomrWtzejyYiIkDFwOqUP,'tracestate':VfSlQRhAGMomrWtzejyYiIkDFwOqUT,'newrelic':VfSlQRhAGMomrWtzejyYiIkDFwOqUx,'x-force-raw':'true','x-pcid':VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':VfSlQRhAGMomrWtzejyYiIkDFwOqga.get('asset_id'),'x-title-deal-id':VfSlQRhAGMomrWtzejyYiIkDFwOqga.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':VfSlQRhAGMomrWtzejyYiIkDFwOqga.get('region'),'x-title-streamable':VfSlQRhAGMomrWtzejyYiIkDFwOqga.get('streamable'),}
   VfSlQRhAGMomrWtzejyYiIkDFwOqug=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.make_CP_DefaultCookies()
   VfSlQRhAGMomrWtzejyYiIkDFwOquv=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.callRequestCookies('Get',VfSlQRhAGMomrWtzejyYiIkDFwOquC,payload=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,params=VfSlQRhAGMomrWtzejyYiIkDFwOqun,headers=VfSlQRhAGMomrWtzejyYiIkDFwOqua,cookies=VfSlQRhAGMomrWtzejyYiIkDFwOqug,redirects=VfSlQRhAGMomrWtzejyYiIkDFwOqCK)
   if VfSlQRhAGMomrWtzejyYiIkDFwOquv.status_code not in[200]:return '',json.loads(VfSlQRhAGMomrWtzejyYiIkDFwOquv.text).get('error').get('detail')
   VfSlQRhAGMomrWtzejyYiIkDFwOquB=json.loads(VfSlQRhAGMomrWtzejyYiIkDFwOquv.text)
   for VfSlQRhAGMomrWtzejyYiIkDFwOqux in VfSlQRhAGMomrWtzejyYiIkDFwOquB.get('data').get('raw').get('sources'):
    if VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('type')=='application/dash+xml' and VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('src')[0:8]=='https://':
     VfSlQRhAGMomrWtzejyYiIkDFwOqgX=VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('src')
     if 'key_systems' in VfSlQRhAGMomrWtzejyYiIkDFwOqux:
      VfSlQRhAGMomrWtzejyYiIkDFwOqgB =VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('key_systems').get('com.widevine.alpha').get('license_url')
     break
  except VfSlQRhAGMomrWtzejyYiIkDFwOqCJ as exception:
   VfSlQRhAGMomrWtzejyYiIkDFwOqCd(exception)
   return '',''
  return VfSlQRhAGMomrWtzejyYiIkDFwOqgX,VfSlQRhAGMomrWtzejyYiIkDFwOqgB
 def GetEventURL_Live(VfSlQRhAGMomrWtzejyYiIkDFwOqUg,eventId,VfSlQRhAGMomrWtzejyYiIkDFwOqgn):
  VfSlQRhAGMomrWtzejyYiIkDFwOqgX=''
  VfSlQRhAGMomrWtzejyYiIkDFwOqgB =''
  VfSlQRhAGMomrWtzejyYiIkDFwOqga=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.Get_eInfo(eventId)
  if VfSlQRhAGMomrWtzejyYiIkDFwOqga=={}:return '',''
  try:
   VfSlQRhAGMomrWtzejyYiIkDFwOquC=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.API_DOMAIN+'/api/playback/play' 
   VfSlQRhAGMomrWtzejyYiIkDFwOqun={'titleId':eventId,'titleType':VfSlQRhAGMomrWtzejyYiIkDFwOqgn,}
   VfSlQRhAGMomrWtzejyYiIkDFwOqUP,VfSlQRhAGMomrWtzejyYiIkDFwOqUT,VfSlQRhAGMomrWtzejyYiIkDFwOqUx=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.Make_authHeader()
   VfSlQRhAGMomrWtzejyYiIkDFwOqua={'traceparent':VfSlQRhAGMomrWtzejyYiIkDFwOqUP,'tracestate':VfSlQRhAGMomrWtzejyYiIkDFwOqUT,'newrelic':VfSlQRhAGMomrWtzejyYiIkDFwOqUx,'x-force-raw':'true','x-pcid':VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':VfSlQRhAGMomrWtzejyYiIkDFwOqga.get('asset_id'),'x-title-deal-id':VfSlQRhAGMomrWtzejyYiIkDFwOqga.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':VfSlQRhAGMomrWtzejyYiIkDFwOqga.get('region'),'x-title-streamable':VfSlQRhAGMomrWtzejyYiIkDFwOqga.get('streamable'),}
   VfSlQRhAGMomrWtzejyYiIkDFwOqug=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.make_CP_DefaultCookies()
   VfSlQRhAGMomrWtzejyYiIkDFwOquv=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.callRequestCookies('Get',VfSlQRhAGMomrWtzejyYiIkDFwOquC,payload=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,params=VfSlQRhAGMomrWtzejyYiIkDFwOqun,headers=VfSlQRhAGMomrWtzejyYiIkDFwOqua,cookies=VfSlQRhAGMomrWtzejyYiIkDFwOqug,redirects=VfSlQRhAGMomrWtzejyYiIkDFwOqCK)
   if VfSlQRhAGMomrWtzejyYiIkDFwOquv.status_code not in[200]:return '',json.loads(VfSlQRhAGMomrWtzejyYiIkDFwOquv.text).get('error').get('detail')
   VfSlQRhAGMomrWtzejyYiIkDFwOquB=json.loads(VfSlQRhAGMomrWtzejyYiIkDFwOquv.text)
   for VfSlQRhAGMomrWtzejyYiIkDFwOqux in VfSlQRhAGMomrWtzejyYiIkDFwOquB.get('data').get('raw').get('sources'):
    if VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('type')=='application/x-mpegURL' and VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('src')[0:8]=='https://':
     VfSlQRhAGMomrWtzejyYiIkDFwOqgX=VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('src')
     if 'key_systems' in VfSlQRhAGMomrWtzejyYiIkDFwOqux:
      if 'com.widevine.alpha' not in VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('key_systems'):continue 
      VfSlQRhAGMomrWtzejyYiIkDFwOqgB =VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('key_systems').get('com.widevine.alpha').get('license_url')
     break
  except VfSlQRhAGMomrWtzejyYiIkDFwOqCJ as exception:
   VfSlQRhAGMomrWtzejyYiIkDFwOqCd(exception)
   return '',''
  return VfSlQRhAGMomrWtzejyYiIkDFwOqgX,VfSlQRhAGMomrWtzejyYiIkDFwOqgB
 def Get_Theme_GroupList(VfSlQRhAGMomrWtzejyYiIkDFwOqUg,vType):
  VfSlQRhAGMomrWtzejyYiIkDFwOquN=[] 
  try:
   VfSlQRhAGMomrWtzejyYiIkDFwOquC=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.API_VIEWURL+'/v2/discover/feed' 
   VfSlQRhAGMomrWtzejyYiIkDFwOqun={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':VfSlQRhAGMomrWtzejyYiIkDFwOqCa(VfSlQRhAGMomrWtzejyYiIkDFwOqUg.PAGE_LIMIT),'filterRestrictedContent':'false',}
   VfSlQRhAGMomrWtzejyYiIkDFwOquv=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.callRequestCookies('Get',VfSlQRhAGMomrWtzejyYiIkDFwOquC,payload=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,params=VfSlQRhAGMomrWtzejyYiIkDFwOqun,headers=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,cookies=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,redirects=VfSlQRhAGMomrWtzejyYiIkDFwOqCK)
   if VfSlQRhAGMomrWtzejyYiIkDFwOquv.status_code not in[200]:return[]
   VfSlQRhAGMomrWtzejyYiIkDFwOquB=json.loads(VfSlQRhAGMomrWtzejyYiIkDFwOquv.text)
   for VfSlQRhAGMomrWtzejyYiIkDFwOqux in VfSlQRhAGMomrWtzejyYiIkDFwOquB.get('data'):
    if VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('type')=='Title-Rails-Curation':
     VfSlQRhAGMomrWtzejyYiIkDFwOqgJ =''
     VfSlQRhAGMomrWtzejyYiIkDFwOqgL=7
     try:
      for i in VfSlQRhAGMomrWtzejyYiIkDFwOqCH(VfSlQRhAGMomrWtzejyYiIkDFwOqCN(VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('data'))):
       if i>=VfSlQRhAGMomrWtzejyYiIkDFwOqgL:
        VfSlQRhAGMomrWtzejyYiIkDFwOqgJ=VfSlQRhAGMomrWtzejyYiIkDFwOqgJ+'...'
        break
       VfSlQRhAGMomrWtzejyYiIkDFwOqgJ=VfSlQRhAGMomrWtzejyYiIkDFwOqgJ+VfSlQRhAGMomrWtzejyYiIkDFwOqux['data'][i]['title']+'\n'
     except VfSlQRhAGMomrWtzejyYiIkDFwOqCJ as exception:
      VfSlQRhAGMomrWtzejyYiIkDFwOqCd(exception)
     VfSlQRhAGMomrWtzejyYiIkDFwOqus={'collectionId':VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('obj_id'),'title':VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('row_name'),'category':VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('category'),'pre_title':VfSlQRhAGMomrWtzejyYiIkDFwOqgJ,}
     VfSlQRhAGMomrWtzejyYiIkDFwOquN.append(VfSlQRhAGMomrWtzejyYiIkDFwOqus)
  except VfSlQRhAGMomrWtzejyYiIkDFwOqCJ as exception:
   VfSlQRhAGMomrWtzejyYiIkDFwOqCd(exception)
   return[]
  return VfSlQRhAGMomrWtzejyYiIkDFwOquN
 def Get_Event_GroupList(VfSlQRhAGMomrWtzejyYiIkDFwOqUg):
  VfSlQRhAGMomrWtzejyYiIkDFwOquN=[] 
  try:
   VfSlQRhAGMomrWtzejyYiIkDFwOquC=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.API_VIEWURL+'/v2/discover/feed' 
   VfSlQRhAGMomrWtzejyYiIkDFwOqun={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':7,'filterRestrictedContent':'false',}
   VfSlQRhAGMomrWtzejyYiIkDFwOquv=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.callRequestCookies('Get',VfSlQRhAGMomrWtzejyYiIkDFwOquC,payload=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,params=VfSlQRhAGMomrWtzejyYiIkDFwOqun,headers=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,cookies=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,redirects=VfSlQRhAGMomrWtzejyYiIkDFwOqCK)
   if VfSlQRhAGMomrWtzejyYiIkDFwOquv.status_code not in[200]:return[]
   VfSlQRhAGMomrWtzejyYiIkDFwOquB=json.loads(VfSlQRhAGMomrWtzejyYiIkDFwOquv.text)
   for VfSlQRhAGMomrWtzejyYiIkDFwOqux in VfSlQRhAGMomrWtzejyYiIkDFwOquB.get('data'):
    if VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('row_name').strip()!='':
     VfSlQRhAGMomrWtzejyYiIkDFwOqgJ =''
     VfSlQRhAGMomrWtzejyYiIkDFwOqgL=7
     try:
      for i in VfSlQRhAGMomrWtzejyYiIkDFwOqCH(VfSlQRhAGMomrWtzejyYiIkDFwOqCN(VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('data'))):
       if i>=VfSlQRhAGMomrWtzejyYiIkDFwOqgL:
        VfSlQRhAGMomrWtzejyYiIkDFwOqgJ=VfSlQRhAGMomrWtzejyYiIkDFwOqgJ+'...'
        break
       VfSlQRhAGMomrWtzejyYiIkDFwOqgJ=VfSlQRhAGMomrWtzejyYiIkDFwOqgJ+VfSlQRhAGMomrWtzejyYiIkDFwOqux['data'][i]['title']+'\n'
     except VfSlQRhAGMomrWtzejyYiIkDFwOqCJ as exception:
      VfSlQRhAGMomrWtzejyYiIkDFwOqCd(exception)
     VfSlQRhAGMomrWtzejyYiIkDFwOqus={'collectionId':VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('obj_id'),'title':VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('row_name'),'category':VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('type'),'pre_title':VfSlQRhAGMomrWtzejyYiIkDFwOqgJ,}
     VfSlQRhAGMomrWtzejyYiIkDFwOquN.append(VfSlQRhAGMomrWtzejyYiIkDFwOqus)
  except VfSlQRhAGMomrWtzejyYiIkDFwOqCJ as exception:
   VfSlQRhAGMomrWtzejyYiIkDFwOqCd(exception)
   return[]
  return VfSlQRhAGMomrWtzejyYiIkDFwOquN
 def Get_Event_GameList(VfSlQRhAGMomrWtzejyYiIkDFwOqUg,VfSlQRhAGMomrWtzejyYiIkDFwOqup):
  VfSlQRhAGMomrWtzejyYiIkDFwOquN=[] 
  try:
   VfSlQRhAGMomrWtzejyYiIkDFwOquC=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.API_VIEWURL+'/v2/discover/feed' 
   VfSlQRhAGMomrWtzejyYiIkDFwOqun={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false',}
   VfSlQRhAGMomrWtzejyYiIkDFwOquv=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.callRequestCookies('Get',VfSlQRhAGMomrWtzejyYiIkDFwOquC,payload=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,params=VfSlQRhAGMomrWtzejyYiIkDFwOqun,headers=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,cookies=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,redirects=VfSlQRhAGMomrWtzejyYiIkDFwOqCK)
   if VfSlQRhAGMomrWtzejyYiIkDFwOquv.status_code not in[200]:return[]
   VfSlQRhAGMomrWtzejyYiIkDFwOquB=json.loads(VfSlQRhAGMomrWtzejyYiIkDFwOquv.text)
   for VfSlQRhAGMomrWtzejyYiIkDFwOqux in VfSlQRhAGMomrWtzejyYiIkDFwOquB.get('data'):
    if VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('obj_id')==VfSlQRhAGMomrWtzejyYiIkDFwOqup:
     for VfSlQRhAGMomrWtzejyYiIkDFwOqgK in VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('data'):
      VfSlQRhAGMomrWtzejyYiIkDFwOqgC=VfSlQRhAGMomrWtzejyYiIkDFwOqgd=VfSlQRhAGMomrWtzejyYiIkDFwOqgs=''
      if 'poster' in VfSlQRhAGMomrWtzejyYiIkDFwOqgK.get('images'):VfSlQRhAGMomrWtzejyYiIkDFwOqgC =VfSlQRhAGMomrWtzejyYiIkDFwOqgK.get('images').get('poster').get('url')
      if 'story-art' in VfSlQRhAGMomrWtzejyYiIkDFwOqgK.get('images'):VfSlQRhAGMomrWtzejyYiIkDFwOqgd =VfSlQRhAGMomrWtzejyYiIkDFwOqgK.get('images').get('story-art').get('url')
      if 'hero' in VfSlQRhAGMomrWtzejyYiIkDFwOqgK.get('images'):VfSlQRhAGMomrWtzejyYiIkDFwOqgs =VfSlQRhAGMomrWtzejyYiIkDFwOqgK.get('images').get('hero').get('url')
      VfSlQRhAGMomrWtzejyYiIkDFwOqgH=VfSlQRhAGMomrWtzejyYiIkDFwOqgK.get('meta').get(VfSlQRhAGMomrWtzejyYiIkDFwOqgK.get('category')).get(VfSlQRhAGMomrWtzejyYiIkDFwOqgK.get('sub_category'))
      if 'league' in VfSlQRhAGMomrWtzejyYiIkDFwOqgH:
       VfSlQRhAGMomrWtzejyYiIkDFwOqgN=VfSlQRhAGMomrWtzejyYiIkDFwOqgH.get('league')
      else:
       VfSlQRhAGMomrWtzejyYiIkDFwOqgN=VfSlQRhAGMomrWtzejyYiIkDFwOqgH.get('round')
      VfSlQRhAGMomrWtzejyYiIkDFwOqus={'id':VfSlQRhAGMomrWtzejyYiIkDFwOqgK.get('id'),'title':VfSlQRhAGMomrWtzejyYiIkDFwOqgK.get('title'),'thumbnail':{'poster':VfSlQRhAGMomrWtzejyYiIkDFwOqgC,'thumb':VfSlQRhAGMomrWtzejyYiIkDFwOqgd,'fanart':VfSlQRhAGMomrWtzejyYiIkDFwOqgs},'asis':VfSlQRhAGMomrWtzejyYiIkDFwOqgK.get('type'),'addInfo':VfSlQRhAGMomrWtzejyYiIkDFwOqgN,'starttm':VfSlQRhAGMomrWtzejyYiIkDFwOqUg.convert_TimeStr(VfSlQRhAGMomrWtzejyYiIkDFwOqgK.get('start_at')),}
      VfSlQRhAGMomrWtzejyYiIkDFwOquN.append(VfSlQRhAGMomrWtzejyYiIkDFwOqus)
  except VfSlQRhAGMomrWtzejyYiIkDFwOqCJ as exception:
   VfSlQRhAGMomrWtzejyYiIkDFwOqCd(exception)
   return[]
  return VfSlQRhAGMomrWtzejyYiIkDFwOquN
 def Get_Event_List(VfSlQRhAGMomrWtzejyYiIkDFwOqUg,gameId):
  VfSlQRhAGMomrWtzejyYiIkDFwOquN=[] 
  try:
   VfSlQRhAGMomrWtzejyYiIkDFwOquC=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.API_VIEWURL+'/v1/discover/events/'+gameId 
   VfSlQRhAGMomrWtzejyYiIkDFwOqun={'platform':'WEBCLIENT','locale':'ko',}
   VfSlQRhAGMomrWtzejyYiIkDFwOquv=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.callRequestCookies('Get',VfSlQRhAGMomrWtzejyYiIkDFwOquC,payload=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,params=VfSlQRhAGMomrWtzejyYiIkDFwOqun,headers=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,cookies=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,redirects=VfSlQRhAGMomrWtzejyYiIkDFwOqCK)
   if VfSlQRhAGMomrWtzejyYiIkDFwOquv.status_code not in[200]:return[]
   VfSlQRhAGMomrWtzejyYiIkDFwOquB=json.loads(VfSlQRhAGMomrWtzejyYiIkDFwOquv.text)
   VfSlQRhAGMomrWtzejyYiIkDFwOqux=VfSlQRhAGMomrWtzejyYiIkDFwOquB.get('data')
   VfSlQRhAGMomrWtzejyYiIkDFwOqgC=VfSlQRhAGMomrWtzejyYiIkDFwOqgd=VfSlQRhAGMomrWtzejyYiIkDFwOqgs=''
   if 'poster' in VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('images'):VfSlQRhAGMomrWtzejyYiIkDFwOqgC =VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('images').get('poster').get('url')
   if 'story-art' in VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('images'):VfSlQRhAGMomrWtzejyYiIkDFwOqgd =VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('images').get('story-art').get('url')
   if 'story-art' in VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('images'):VfSlQRhAGMomrWtzejyYiIkDFwOqgs =VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('images').get('story-art').get('url')
   VfSlQRhAGMomrWtzejyYiIkDFwOqus={'id':VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('id'),'title':VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('title'),'thumbnail':{'poster':VfSlQRhAGMomrWtzejyYiIkDFwOqgC,'thumb':VfSlQRhAGMomrWtzejyYiIkDFwOqgd,'fanart':VfSlQRhAGMomrWtzejyYiIkDFwOqgs},'duration':VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('running_time'),'asis':VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('type'),'starttm':VfSlQRhAGMomrWtzejyYiIkDFwOqUg.convert_TimeStr(VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('start_at')),}
   VfSlQRhAGMomrWtzejyYiIkDFwOquN.append(VfSlQRhAGMomrWtzejyYiIkDFwOqus)
  except VfSlQRhAGMomrWtzejyYiIkDFwOqCJ as exception:
   VfSlQRhAGMomrWtzejyYiIkDFwOqCd(exception)
   return[]
  try:
   VfSlQRhAGMomrWtzejyYiIkDFwOquC=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.API_VIEWURL+'/v1/discover/events/'+gameId+'/related' 
   VfSlQRhAGMomrWtzejyYiIkDFwOqun={'locale':'ko','page':'1','perPage':'25','platform':'WEBCLIENT','currentPageTracking':'page_discover_title_detail',}
   VfSlQRhAGMomrWtzejyYiIkDFwOquv=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.callRequestCookies('Get',VfSlQRhAGMomrWtzejyYiIkDFwOquC,payload=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,params=VfSlQRhAGMomrWtzejyYiIkDFwOqun,headers=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,cookies=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,redirects=VfSlQRhAGMomrWtzejyYiIkDFwOqCK)
   if VfSlQRhAGMomrWtzejyYiIkDFwOquv.status_code not in[200]:return[]
   VfSlQRhAGMomrWtzejyYiIkDFwOquB=json.loads(VfSlQRhAGMomrWtzejyYiIkDFwOquv.text)
   for VfSlQRhAGMomrWtzejyYiIkDFwOqux in VfSlQRhAGMomrWtzejyYiIkDFwOquB.get('data').get('data'):
    VfSlQRhAGMomrWtzejyYiIkDFwOqgC=VfSlQRhAGMomrWtzejyYiIkDFwOqgd=VfSlQRhAGMomrWtzejyYiIkDFwOqgs=''
    if 'poster' in VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('images'):VfSlQRhAGMomrWtzejyYiIkDFwOqgC =VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('images').get('poster').get('url')
    if 'story-art' in VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('images'):VfSlQRhAGMomrWtzejyYiIkDFwOqgd =VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('images').get('story-art').get('url')
    if 'story-art' in VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('images'):VfSlQRhAGMomrWtzejyYiIkDFwOqgs =VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('images').get('story-art').get('url')
    VfSlQRhAGMomrWtzejyYiIkDFwOqus={'id':VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('id'),'title':VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('title'),'thumbnail':{'poster':VfSlQRhAGMomrWtzejyYiIkDFwOqgC,'thumb':VfSlQRhAGMomrWtzejyYiIkDFwOqgd,'fanart':VfSlQRhAGMomrWtzejyYiIkDFwOqgs},'duration':VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('running_time'),'asis':VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('type'),}
    VfSlQRhAGMomrWtzejyYiIkDFwOquN.append(VfSlQRhAGMomrWtzejyYiIkDFwOqus)
  except VfSlQRhAGMomrWtzejyYiIkDFwOqCJ as exception:
   VfSlQRhAGMomrWtzejyYiIkDFwOqCd(exception)
   return[]
  return VfSlQRhAGMomrWtzejyYiIkDFwOquN
 def Get_Search_List(VfSlQRhAGMomrWtzejyYiIkDFwOqUg,search_key,page_int):
  VfSlQRhAGMomrWtzejyYiIkDFwOquN=[] 
  VfSlQRhAGMomrWtzejyYiIkDFwOqgU=VfSlQRhAGMomrWtzejyYiIkDFwOqCc
  try:
   VfSlQRhAGMomrWtzejyYiIkDFwOquC=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.API_VIEWURL+'/v2/search' 
   VfSlQRhAGMomrWtzejyYiIkDFwOqun={'query':search_key,'platform':'WEBCLIENT','page':VfSlQRhAGMomrWtzejyYiIkDFwOqCa(page_int),'perPage':VfSlQRhAGMomrWtzejyYiIkDFwOqCa(VfSlQRhAGMomrWtzejyYiIkDFwOqUg.SEARCH_LIMIT),}
   VfSlQRhAGMomrWtzejyYiIkDFwOqua={'x-membersrl':VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['member_srl'],'x-pcid':VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['PCID'],'x-profileid':VfSlQRhAGMomrWtzejyYiIkDFwOqUg.CP['SESSION']['profileId'],}
   VfSlQRhAGMomrWtzejyYiIkDFwOquv=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.callRequestCookies('Get',VfSlQRhAGMomrWtzejyYiIkDFwOquC,payload=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,params=VfSlQRhAGMomrWtzejyYiIkDFwOqun,headers=VfSlQRhAGMomrWtzejyYiIkDFwOqua,cookies=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,redirects=VfSlQRhAGMomrWtzejyYiIkDFwOqCK)
   if VfSlQRhAGMomrWtzejyYiIkDFwOquv.status_code not in[200]:return[],VfSlQRhAGMomrWtzejyYiIkDFwOqCc
   VfSlQRhAGMomrWtzejyYiIkDFwOquB=json.loads(VfSlQRhAGMomrWtzejyYiIkDFwOquv.text)
   for VfSlQRhAGMomrWtzejyYiIkDFwOqux in VfSlQRhAGMomrWtzejyYiIkDFwOquB.get('data').get('data'):
    VfSlQRhAGMomrWtzejyYiIkDFwOqux=VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('data')
    VfSlQRhAGMomrWtzejyYiIkDFwOqgC=VfSlQRhAGMomrWtzejyYiIkDFwOqgd=VfSlQRhAGMomrWtzejyYiIkDFwOqCU=VfSlQRhAGMomrWtzejyYiIkDFwOqgs=''
    if 'poster' in VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('images'):VfSlQRhAGMomrWtzejyYiIkDFwOqgC =VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('images').get('poster').get('url')
    if 'story-art' in VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('images'):VfSlQRhAGMomrWtzejyYiIkDFwOqgd =VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('images').get('story-art').get('url')
    if 'title-treatment' in VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('images'):VfSlQRhAGMomrWtzejyYiIkDFwOqCU=VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('images').get('title-treatment').get('url')
    if 'story-art' in VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('images'):VfSlQRhAGMomrWtzejyYiIkDFwOqgs =VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('images').get('story-art').get('url')
    VfSlQRhAGMomrWtzejyYiIkDFwOqgv=''
    if VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('badge')not in[{},VfSlQRhAGMomrWtzejyYiIkDFwOqCb]:
     for i in VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('badge').get('text'):
      if VfSlQRhAGMomrWtzejyYiIkDFwOqgv!='':VfSlQRhAGMomrWtzejyYiIkDFwOqgv+=' '
      VfSlQRhAGMomrWtzejyYiIkDFwOqgv+=i.get('text')
    if 'as' in VfSlQRhAGMomrWtzejyYiIkDFwOqux:
     VfSlQRhAGMomrWtzejyYiIkDFwOqgn=VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('as') 
    else:
     VfSlQRhAGMomrWtzejyYiIkDFwOqgn=VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('type')
    VfSlQRhAGMomrWtzejyYiIkDFwOqus={'id':VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('id'),'title':VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('title'),'asis':VfSlQRhAGMomrWtzejyYiIkDFwOqgn,'thumbnail':{'poster':VfSlQRhAGMomrWtzejyYiIkDFwOqgC,'thumb':VfSlQRhAGMomrWtzejyYiIkDFwOqgd,'clearlogo':VfSlQRhAGMomrWtzejyYiIkDFwOqCU,'fanart':VfSlQRhAGMomrWtzejyYiIkDFwOqgs},'mpaa':VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('age_rating'),'duration':VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('running_time'),'badge':VfSlQRhAGMomrWtzejyYiIkDFwOqgv,'year':VfSlQRhAGMomrWtzejyYiIkDFwOqux.get('meta').get('releaseYear'),}
    VfSlQRhAGMomrWtzejyYiIkDFwOquN.append(VfSlQRhAGMomrWtzejyYiIkDFwOqus)
   if VfSlQRhAGMomrWtzejyYiIkDFwOquB.get('pagination').get('totalPages')>page_int:
    VfSlQRhAGMomrWtzejyYiIkDFwOqgU=VfSlQRhAGMomrWtzejyYiIkDFwOqCK
  except VfSlQRhAGMomrWtzejyYiIkDFwOqCJ as exception:
   VfSlQRhAGMomrWtzejyYiIkDFwOqCd(exception)
   return[],VfSlQRhAGMomrWtzejyYiIkDFwOqCc
  return VfSlQRhAGMomrWtzejyYiIkDFwOquN,VfSlQRhAGMomrWtzejyYiIkDFwOqgU
 def GetBookmarkInfo(VfSlQRhAGMomrWtzejyYiIkDFwOqUg,videoid,vidtype):
  VfSlQRhAGMomrWtzejyYiIkDFwOqgP={'indexinfo':{'ott':'coupang','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  VfSlQRhAGMomrWtzejyYiIkDFwOquC=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.API_VIEWURL+'/v1/discover/titles/'+videoid 
  VfSlQRhAGMomrWtzejyYiIkDFwOqun={'locale':'ko'}
  VfSlQRhAGMomrWtzejyYiIkDFwOquv=VfSlQRhAGMomrWtzejyYiIkDFwOqUg.callRequestCookies('Get',VfSlQRhAGMomrWtzejyYiIkDFwOquC,payload=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,params=VfSlQRhAGMomrWtzejyYiIkDFwOqun,headers=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,cookies=VfSlQRhAGMomrWtzejyYiIkDFwOqCb,redirects=VfSlQRhAGMomrWtzejyYiIkDFwOqCK)
  if VfSlQRhAGMomrWtzejyYiIkDFwOquv.status_code not in[200]:return{}
  VfSlQRhAGMomrWtzejyYiIkDFwOqgT=json.loads(VfSlQRhAGMomrWtzejyYiIkDFwOquv.text).get('data')
  VfSlQRhAGMomrWtzejyYiIkDFwOqgx=VfSlQRhAGMomrWtzejyYiIkDFwOqgT.get('title')
  VfSlQRhAGMomrWtzejyYiIkDFwOqgp =VfSlQRhAGMomrWtzejyYiIkDFwOqgT.get('meta').get('releaseYear')
  VfSlQRhAGMomrWtzejyYiIkDFwOqgP['saveinfo']['infoLabels']['title']=VfSlQRhAGMomrWtzejyYiIkDFwOqgx
  if vidtype=='movie':
   VfSlQRhAGMomrWtzejyYiIkDFwOqgx='%s  (%s)'%(VfSlQRhAGMomrWtzejyYiIkDFwOqgx,VfSlQRhAGMomrWtzejyYiIkDFwOqgp)
  VfSlQRhAGMomrWtzejyYiIkDFwOqgP['saveinfo']['title'] =VfSlQRhAGMomrWtzejyYiIkDFwOqgx
  VfSlQRhAGMomrWtzejyYiIkDFwOqgP['saveinfo']['infoLabels']['mpaa'] =VfSlQRhAGMomrWtzejyYiIkDFwOqgT.get('age_rating')
  VfSlQRhAGMomrWtzejyYiIkDFwOqgP['saveinfo']['infoLabels']['plot'] ='%s\n\n%s'%(VfSlQRhAGMomrWtzejyYiIkDFwOqgT.get('short_description'),VfSlQRhAGMomrWtzejyYiIkDFwOqgT.get('description'))
  VfSlQRhAGMomrWtzejyYiIkDFwOqgP['saveinfo']['infoLabels']['year'] =VfSlQRhAGMomrWtzejyYiIkDFwOqgp
  if vidtype=='movie':
   VfSlQRhAGMomrWtzejyYiIkDFwOqgP['saveinfo']['infoLabels']['duration']=VfSlQRhAGMomrWtzejyYiIkDFwOqgT.get('running_time')
  VfSlQRhAGMomrWtzejyYiIkDFwOqgC =''
  VfSlQRhAGMomrWtzejyYiIkDFwOqgs =''
  VfSlQRhAGMomrWtzejyYiIkDFwOqgd =''
  VfSlQRhAGMomrWtzejyYiIkDFwOqCU=''
  if VfSlQRhAGMomrWtzejyYiIkDFwOqgT.get('images').get('poster') !=VfSlQRhAGMomrWtzejyYiIkDFwOqCb:VfSlQRhAGMomrWtzejyYiIkDFwOqgC =VfSlQRhAGMomrWtzejyYiIkDFwOqgT.get('images').get('poster').get('url')
  if VfSlQRhAGMomrWtzejyYiIkDFwOqgT.get('images').get('background') !=VfSlQRhAGMomrWtzejyYiIkDFwOqCb:VfSlQRhAGMomrWtzejyYiIkDFwOqgs =VfSlQRhAGMomrWtzejyYiIkDFwOqgT.get('images').get('background').get('url')
  if VfSlQRhAGMomrWtzejyYiIkDFwOqgT.get('images').get('story-art') !=VfSlQRhAGMomrWtzejyYiIkDFwOqCb:VfSlQRhAGMomrWtzejyYiIkDFwOqgd =VfSlQRhAGMomrWtzejyYiIkDFwOqgT.get('images').get('story-art').get('url')
  if VfSlQRhAGMomrWtzejyYiIkDFwOqgT.get('images').get('title-treatment')!=VfSlQRhAGMomrWtzejyYiIkDFwOqCb:VfSlQRhAGMomrWtzejyYiIkDFwOqCU=VfSlQRhAGMomrWtzejyYiIkDFwOqgT.get('images').get('title-treatment').get('url')
  if VfSlQRhAGMomrWtzejyYiIkDFwOqgs=='':VfSlQRhAGMomrWtzejyYiIkDFwOqgs=VfSlQRhAGMomrWtzejyYiIkDFwOqgd
  VfSlQRhAGMomrWtzejyYiIkDFwOqgP['saveinfo']['thumbnail']['poster']=VfSlQRhAGMomrWtzejyYiIkDFwOqgC
  VfSlQRhAGMomrWtzejyYiIkDFwOqgP['saveinfo']['thumbnail']['fanart']=VfSlQRhAGMomrWtzejyYiIkDFwOqgs
  VfSlQRhAGMomrWtzejyYiIkDFwOqgP['saveinfo']['thumbnail']['thumb']=VfSlQRhAGMomrWtzejyYiIkDFwOqgd
  VfSlQRhAGMomrWtzejyYiIkDFwOqgP['saveinfo']['thumbnail']['clearlogo']=VfSlQRhAGMomrWtzejyYiIkDFwOqCU
  VfSlQRhAGMomrWtzejyYiIkDFwOqCu=[]
  for VfSlQRhAGMomrWtzejyYiIkDFwOqgc in VfSlQRhAGMomrWtzejyYiIkDFwOqgT.get('tags'):VfSlQRhAGMomrWtzejyYiIkDFwOqCu.append(VfSlQRhAGMomrWtzejyYiIkDFwOqgc.get('tag'))
  if VfSlQRhAGMomrWtzejyYiIkDFwOqCN(VfSlQRhAGMomrWtzejyYiIkDFwOqCu)>0:
   VfSlQRhAGMomrWtzejyYiIkDFwOqgP['saveinfo']['infoLabels']['genre']=VfSlQRhAGMomrWtzejyYiIkDFwOqCu
  VfSlQRhAGMomrWtzejyYiIkDFwOqCg=[]
  VfSlQRhAGMomrWtzejyYiIkDFwOqCv=[]
  for VfSlQRhAGMomrWtzejyYiIkDFwOqgc in VfSlQRhAGMomrWtzejyYiIkDFwOqgT.get('people'):
   if VfSlQRhAGMomrWtzejyYiIkDFwOqgc.get('role')=='CAST' :VfSlQRhAGMomrWtzejyYiIkDFwOqCg.append(VfSlQRhAGMomrWtzejyYiIkDFwOqgc.get('name'))
   if VfSlQRhAGMomrWtzejyYiIkDFwOqgc.get('role')=='DIRECTOR':VfSlQRhAGMomrWtzejyYiIkDFwOqCv.append(VfSlQRhAGMomrWtzejyYiIkDFwOqgc.get('name'))
  if VfSlQRhAGMomrWtzejyYiIkDFwOqCN(VfSlQRhAGMomrWtzejyYiIkDFwOqCg)>0:
   VfSlQRhAGMomrWtzejyYiIkDFwOqgP['saveinfo']['infoLabels']['cast'] =VfSlQRhAGMomrWtzejyYiIkDFwOqCg
  if VfSlQRhAGMomrWtzejyYiIkDFwOqCN(VfSlQRhAGMomrWtzejyYiIkDFwOqCv)>0:
   VfSlQRhAGMomrWtzejyYiIkDFwOqgP['saveinfo']['infoLabels']['director']=VfSlQRhAGMomrWtzejyYiIkDFwOqCv
  return VfSlQRhAGMomrWtzejyYiIkDFwOqgP
# Created by pyminifier (https://github.com/liftoff/pyminifier)
