__author__="NightRain"
BtLNjxIyaodhKEkCJQAVRscSYMpmGl=object
BtLNjxIyaodhKEkCJQAVRscSYMpmGf=None
BtLNjxIyaodhKEkCJQAVRscSYMpmGW=False
BtLNjxIyaodhKEkCJQAVRscSYMpmGn=True
BtLNjxIyaodhKEkCJQAVRscSYMpmGU=type
BtLNjxIyaodhKEkCJQAVRscSYMpmGH=dict
BtLNjxIyaodhKEkCJQAVRscSYMpmGT=getattr
BtLNjxIyaodhKEkCJQAVRscSYMpmGz=int
BtLNjxIyaodhKEkCJQAVRscSYMpmGX=list
BtLNjxIyaodhKEkCJQAVRscSYMpmGr=open
BtLNjxIyaodhKEkCJQAVRscSYMpmGu=Exception
BtLNjxIyaodhKEkCJQAVRscSYMpmGv=str
BtLNjxIyaodhKEkCJQAVRscSYMpmGw=id
BtLNjxIyaodhKEkCJQAVRscSYMpmGP=len
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import inputstreamhelper
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
BtLNjxIyaodhKEkCJQAVRscSYMpmbg=[{'title':'오직 쿠팡플레이에서','mode':'CATEGORY_LIST','vType':'ORIGINAL','collectionId':'5c33c5ca-ee6f-45f8-a026-dd789a8b63cf'},{'title':'홈   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'ALL'},{'title':'TV   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'MOVIES'},{'title':'(패스) 스포츠','mode':'SPORTS_MAINLIST_LEAGUE'},{'title':'(패스) Paramount+','mode':'PASS_GROUPLIST','collectionId':'1afeaf87-0b7a-4a49-a971-fa5be7aedf4e'},{'title':'(패스) Sony Pictures','mode':'PASS_GROUPLIST','collectionId':'5b37af01-01fb-4361-ba5b-0f23f307d557'},{'title':'TV   (테마별)','mode':'THEME_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (테마별)','mode':'THEME_GROUPLIST','vType':'MOVIES'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},{'title':'(쿠팡) 검색','mode':'LOCAL_SEARCH','icon':'search.png'},{'title':'(쿠팡) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
BtLNjxIyaodhKEkCJQAVRscSYMpmbF=[{'title':'시리즈 시청내역','mode':'WATCH','stype':'tvshow'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},]
BtLNjxIyaodhKEkCJQAVRscSYMpmbe={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
BtLNjxIyaodhKEkCJQAVRscSYMpmbl=xbmcvfs.translatePath(os.path.join(__profile__,'coupang_searched.txt'))
from coupangCore import*
class BtLNjxIyaodhKEkCJQAVRscSYMpmbD(BtLNjxIyaodhKEkCJQAVRscSYMpmGl):
 def __init__(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,BtLNjxIyaodhKEkCJQAVRscSYMpmbG,BtLNjxIyaodhKEkCJQAVRscSYMpmbW,BtLNjxIyaodhKEkCJQAVRscSYMpmbn):
  BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_url =BtLNjxIyaodhKEkCJQAVRscSYMpmbG
  BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle=BtLNjxIyaodhKEkCJQAVRscSYMpmbW
  BtLNjxIyaodhKEkCJQAVRscSYMpmbf.main_params =BtLNjxIyaodhKEkCJQAVRscSYMpmbn
  BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj =AOnquyUgXawJokpcdhzTSfrtWLKQsR() 
  BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.CP_COOKIE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_cookies.json'))
  BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.CP_DEVICE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_device.json'))
 def addon_noti(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,sting):
  try:
   BtLNjxIyaodhKEkCJQAVRscSYMpmbH=xbmcgui.Dialog()
   BtLNjxIyaodhKEkCJQAVRscSYMpmbH.notification(__addonname__,sting)
  except:
   BtLNjxIyaodhKEkCJQAVRscSYMpmGf
 def addon_log(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,string):
  try:
   BtLNjxIyaodhKEkCJQAVRscSYMpmbT=string.encode('utf-8','ignore')
  except:
   BtLNjxIyaodhKEkCJQAVRscSYMpmbT='addonException: addon_log'
  BtLNjxIyaodhKEkCJQAVRscSYMpmbz=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,BtLNjxIyaodhKEkCJQAVRscSYMpmbT),level=BtLNjxIyaodhKEkCJQAVRscSYMpmbz)
 def get_keyboard_input(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,BtLNjxIyaodhKEkCJQAVRscSYMpmDe):
  BtLNjxIyaodhKEkCJQAVRscSYMpmbX=BtLNjxIyaodhKEkCJQAVRscSYMpmGf
  kb=xbmc.Keyboard()
  kb.setHeading(BtLNjxIyaodhKEkCJQAVRscSYMpmDe)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   BtLNjxIyaodhKEkCJQAVRscSYMpmbX=kb.getText()
  return BtLNjxIyaodhKEkCJQAVRscSYMpmbX
 def get_settings_account(BtLNjxIyaodhKEkCJQAVRscSYMpmbf):
  BtLNjxIyaodhKEkCJQAVRscSYMpmbr=__addon__.getSetting('id')
  BtLNjxIyaodhKEkCJQAVRscSYMpmbu=__addon__.getSetting('pw')
  BtLNjxIyaodhKEkCJQAVRscSYMpmbv=__addon__.getSetting('profile')
  return(BtLNjxIyaodhKEkCJQAVRscSYMpmbr,BtLNjxIyaodhKEkCJQAVRscSYMpmbu,BtLNjxIyaodhKEkCJQAVRscSYMpmbv)
 def get_settings_exclusion21(BtLNjxIyaodhKEkCJQAVRscSYMpmbf):
  BtLNjxIyaodhKEkCJQAVRscSYMpmbw =__addon__.getSetting('exclusion21')
  if BtLNjxIyaodhKEkCJQAVRscSYMpmbw=='false':
   return BtLNjxIyaodhKEkCJQAVRscSYMpmGW
  else:
   return BtLNjxIyaodhKEkCJQAVRscSYMpmGn
 def get_settings_totalsearch(BtLNjxIyaodhKEkCJQAVRscSYMpmbf):
  BtLNjxIyaodhKEkCJQAVRscSYMpmbP =BtLNjxIyaodhKEkCJQAVRscSYMpmGn if __addon__.getSetting('local_search')=='true' else BtLNjxIyaodhKEkCJQAVRscSYMpmGW
  BtLNjxIyaodhKEkCJQAVRscSYMpmbq=BtLNjxIyaodhKEkCJQAVRscSYMpmGn if __addon__.getSetting('local_history')=='true' else BtLNjxIyaodhKEkCJQAVRscSYMpmGW
  BtLNjxIyaodhKEkCJQAVRscSYMpmbO =BtLNjxIyaodhKEkCJQAVRscSYMpmGn if __addon__.getSetting('total_search')=='true' else BtLNjxIyaodhKEkCJQAVRscSYMpmGW
  BtLNjxIyaodhKEkCJQAVRscSYMpmbi=BtLNjxIyaodhKEkCJQAVRscSYMpmGn if __addon__.getSetting('total_history')=='true' else BtLNjxIyaodhKEkCJQAVRscSYMpmGW
  BtLNjxIyaodhKEkCJQAVRscSYMpmDb=BtLNjxIyaodhKEkCJQAVRscSYMpmGn if __addon__.getSetting('menu_bookmark')=='true' else BtLNjxIyaodhKEkCJQAVRscSYMpmGW
  return(BtLNjxIyaodhKEkCJQAVRscSYMpmbP,BtLNjxIyaodhKEkCJQAVRscSYMpmbq,BtLNjxIyaodhKEkCJQAVRscSYMpmbO,BtLNjxIyaodhKEkCJQAVRscSYMpmbi,BtLNjxIyaodhKEkCJQAVRscSYMpmDb)
 def get_settings_makebookmark(BtLNjxIyaodhKEkCJQAVRscSYMpmbf):
  return BtLNjxIyaodhKEkCJQAVRscSYMpmGn if __addon__.getSetting('make_bookmark')=='true' else BtLNjxIyaodhKEkCJQAVRscSYMpmGW
 def set_winEpisodeOrderby(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,BtLNjxIyaodhKEkCJQAVRscSYMpmDg):
  __addon__.setSetting('coupang_orderby',BtLNjxIyaodhKEkCJQAVRscSYMpmDg)
 def get_winEpisodeOrderby(BtLNjxIyaodhKEkCJQAVRscSYMpmbf):
  BtLNjxIyaodhKEkCJQAVRscSYMpmDg=__addon__.getSetting('coupang_orderby')
  if BtLNjxIyaodhKEkCJQAVRscSYMpmDg in['',BtLNjxIyaodhKEkCJQAVRscSYMpmGf]:BtLNjxIyaodhKEkCJQAVRscSYMpmDg='asc'
  return BtLNjxIyaodhKEkCJQAVRscSYMpmDg
 def add_dir(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,label,sublabel='',img='',infoLabels=BtLNjxIyaodhKEkCJQAVRscSYMpmGf,isFolder=BtLNjxIyaodhKEkCJQAVRscSYMpmGn,params='',isLink=BtLNjxIyaodhKEkCJQAVRscSYMpmGW,ContextMenu=BtLNjxIyaodhKEkCJQAVRscSYMpmGf):
  BtLNjxIyaodhKEkCJQAVRscSYMpmDF='%s?%s'%(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_url,urllib.parse.urlencode(params))
  if sublabel:BtLNjxIyaodhKEkCJQAVRscSYMpmDe='%s < %s >'%(label,sublabel)
  else: BtLNjxIyaodhKEkCJQAVRscSYMpmDe=label
  if not img:img='DefaultFolder.png'
  BtLNjxIyaodhKEkCJQAVRscSYMpmDl=xbmcgui.ListItem(BtLNjxIyaodhKEkCJQAVRscSYMpmDe)
  if BtLNjxIyaodhKEkCJQAVRscSYMpmGU(img)==BtLNjxIyaodhKEkCJQAVRscSYMpmGH:
   BtLNjxIyaodhKEkCJQAVRscSYMpmDl.setArt(img)
  else:
   BtLNjxIyaodhKEkCJQAVRscSYMpmDl.setArt({'thumb':img,'poster':img})
  if BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.KodiVersion>=20:
   if infoLabels:BtLNjxIyaodhKEkCJQAVRscSYMpmbf.Set_InfoTag(BtLNjxIyaodhKEkCJQAVRscSYMpmDl.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:BtLNjxIyaodhKEkCJQAVRscSYMpmDl.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   BtLNjxIyaodhKEkCJQAVRscSYMpmDl.setProperty('IsPlayable','true')
  if ContextMenu:BtLNjxIyaodhKEkCJQAVRscSYMpmDl.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,BtLNjxIyaodhKEkCJQAVRscSYMpmDF,BtLNjxIyaodhKEkCJQAVRscSYMpmDl,isFolder)
 def Set_InfoTag(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,video_InfoTag:xbmc.InfoTagVideo,BtLNjxIyaodhKEkCJQAVRscSYMpmDz):
  for BtLNjxIyaodhKEkCJQAVRscSYMpmDf,value in BtLNjxIyaodhKEkCJQAVRscSYMpmDz.items():
   if BtLNjxIyaodhKEkCJQAVRscSYMpmbe[BtLNjxIyaodhKEkCJQAVRscSYMpmDf]['type']=='string':
    BtLNjxIyaodhKEkCJQAVRscSYMpmGT(video_InfoTag,BtLNjxIyaodhKEkCJQAVRscSYMpmbe[BtLNjxIyaodhKEkCJQAVRscSYMpmDf]['func'])(value)
   elif BtLNjxIyaodhKEkCJQAVRscSYMpmbe[BtLNjxIyaodhKEkCJQAVRscSYMpmDf]['type']=='int':
    if BtLNjxIyaodhKEkCJQAVRscSYMpmGU(value)==BtLNjxIyaodhKEkCJQAVRscSYMpmGz:
     BtLNjxIyaodhKEkCJQAVRscSYMpmDG=BtLNjxIyaodhKEkCJQAVRscSYMpmGz(value)
    else:
     BtLNjxIyaodhKEkCJQAVRscSYMpmDG=0
    BtLNjxIyaodhKEkCJQAVRscSYMpmGT(video_InfoTag,BtLNjxIyaodhKEkCJQAVRscSYMpmbe[BtLNjxIyaodhKEkCJQAVRscSYMpmDf]['func'])(BtLNjxIyaodhKEkCJQAVRscSYMpmDG)
   elif BtLNjxIyaodhKEkCJQAVRscSYMpmbe[BtLNjxIyaodhKEkCJQAVRscSYMpmDf]['type']=='actor':
    if value!=[]:
     BtLNjxIyaodhKEkCJQAVRscSYMpmGT(video_InfoTag,BtLNjxIyaodhKEkCJQAVRscSYMpmbe[BtLNjxIyaodhKEkCJQAVRscSYMpmDf]['func'])([xbmc.Actor(name)for name in value])
   elif BtLNjxIyaodhKEkCJQAVRscSYMpmbe[BtLNjxIyaodhKEkCJQAVRscSYMpmDf]['type']=='list':
    if BtLNjxIyaodhKEkCJQAVRscSYMpmGU(value)==BtLNjxIyaodhKEkCJQAVRscSYMpmGX:
     BtLNjxIyaodhKEkCJQAVRscSYMpmGT(video_InfoTag,BtLNjxIyaodhKEkCJQAVRscSYMpmbe[BtLNjxIyaodhKEkCJQAVRscSYMpmDf]['func'])(value)
    else:
     BtLNjxIyaodhKEkCJQAVRscSYMpmGT(video_InfoTag,BtLNjxIyaodhKEkCJQAVRscSYMpmbe[BtLNjxIyaodhKEkCJQAVRscSYMpmDf]['func'])([value])
 def dp_Main_List(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,args):
  (BtLNjxIyaodhKEkCJQAVRscSYMpmbP,BtLNjxIyaodhKEkCJQAVRscSYMpmbq,BtLNjxIyaodhKEkCJQAVRscSYMpmbO,BtLNjxIyaodhKEkCJQAVRscSYMpmbi,BtLNjxIyaodhKEkCJQAVRscSYMpmDb)=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.get_settings_totalsearch()
  for BtLNjxIyaodhKEkCJQAVRscSYMpmDW in BtLNjxIyaodhKEkCJQAVRscSYMpmbg:
   BtLNjxIyaodhKEkCJQAVRscSYMpmDe=BtLNjxIyaodhKEkCJQAVRscSYMpmDW.get('title')
   BtLNjxIyaodhKEkCJQAVRscSYMpmDn=''
   if BtLNjxIyaodhKEkCJQAVRscSYMpmDW.get('mode')=='LOCAL_SEARCH' and BtLNjxIyaodhKEkCJQAVRscSYMpmbP ==BtLNjxIyaodhKEkCJQAVRscSYMpmGW:continue
   elif BtLNjxIyaodhKEkCJQAVRscSYMpmDW.get('mode')=='SEARCH_HISTORY' and BtLNjxIyaodhKEkCJQAVRscSYMpmbq==BtLNjxIyaodhKEkCJQAVRscSYMpmGW:continue
   elif BtLNjxIyaodhKEkCJQAVRscSYMpmDW.get('mode')=='TOTAL_SEARCH' and BtLNjxIyaodhKEkCJQAVRscSYMpmbO ==BtLNjxIyaodhKEkCJQAVRscSYMpmGW:continue
   elif BtLNjxIyaodhKEkCJQAVRscSYMpmDW.get('mode')=='TOTAL_HISTORY' and BtLNjxIyaodhKEkCJQAVRscSYMpmbi==BtLNjxIyaodhKEkCJQAVRscSYMpmGW:continue
   elif BtLNjxIyaodhKEkCJQAVRscSYMpmDW.get('mode')=='MENU_BOOKMARK' and BtLNjxIyaodhKEkCJQAVRscSYMpmDb==BtLNjxIyaodhKEkCJQAVRscSYMpmGW:continue
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU={'mode':BtLNjxIyaodhKEkCJQAVRscSYMpmDW.get('mode'),'vType':BtLNjxIyaodhKEkCJQAVRscSYMpmDW.get('vType'),'collectionId':BtLNjxIyaodhKEkCJQAVRscSYMpmDW.get('collectionId'),'page':'1',}
   if BtLNjxIyaodhKEkCJQAVRscSYMpmDW.get('mode')=='LOCAL_SEARCH':BtLNjxIyaodhKEkCJQAVRscSYMpmDU['historyyn']='Y' 
   if BtLNjxIyaodhKEkCJQAVRscSYMpmDW.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    BtLNjxIyaodhKEkCJQAVRscSYMpmDH=BtLNjxIyaodhKEkCJQAVRscSYMpmGW
    BtLNjxIyaodhKEkCJQAVRscSYMpmDT =BtLNjxIyaodhKEkCJQAVRscSYMpmGn
   else:
    BtLNjxIyaodhKEkCJQAVRscSYMpmDH=BtLNjxIyaodhKEkCJQAVRscSYMpmGn
    BtLNjxIyaodhKEkCJQAVRscSYMpmDT =BtLNjxIyaodhKEkCJQAVRscSYMpmGW
   BtLNjxIyaodhKEkCJQAVRscSYMpmDz={'title':BtLNjxIyaodhKEkCJQAVRscSYMpmDe,'plot':BtLNjxIyaodhKEkCJQAVRscSYMpmDe}
   if BtLNjxIyaodhKEkCJQAVRscSYMpmDW.get('mode')=='XXX':BtLNjxIyaodhKEkCJQAVRscSYMpmDz=BtLNjxIyaodhKEkCJQAVRscSYMpmGf
   if 'icon' in BtLNjxIyaodhKEkCJQAVRscSYMpmDW:BtLNjxIyaodhKEkCJQAVRscSYMpmDn=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',BtLNjxIyaodhKEkCJQAVRscSYMpmDW.get('icon')) 
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.add_dir(BtLNjxIyaodhKEkCJQAVRscSYMpmDe,sublabel='',img=BtLNjxIyaodhKEkCJQAVRscSYMpmDn,infoLabels=BtLNjxIyaodhKEkCJQAVRscSYMpmDz,isFolder=BtLNjxIyaodhKEkCJQAVRscSYMpmDH,params=BtLNjxIyaodhKEkCJQAVRscSYMpmDU,isLink=BtLNjxIyaodhKEkCJQAVRscSYMpmDT)
  xbmcplugin.endOfDirectory(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle)
 def dp_Test(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,args):
  BtLNjxIyaodhKEkCJQAVRscSYMpmbf.addon_noti('test')
 def CP_logout(BtLNjxIyaodhKEkCJQAVRscSYMpmbf):
  BtLNjxIyaodhKEkCJQAVRscSYMpmbH=xbmcgui.Dialog()
  BtLNjxIyaodhKEkCJQAVRscSYMpmDr=BtLNjxIyaodhKEkCJQAVRscSYMpmbH.yesno(__language__(30905).encode('utf8'),__language__(30906).encode('utf8'))
  if BtLNjxIyaodhKEkCJQAVRscSYMpmDr==BtLNjxIyaodhKEkCJQAVRscSYMpmGW:return 
  if os.path.isfile(BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.CP_COOKIE_FILENAME):os.remove(BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.CP_COOKIE_FILENAME)
  BtLNjxIyaodhKEkCJQAVRscSYMpmbf.addon_noti(__language__(30904).encode('utf-8'))
 def option_check(BtLNjxIyaodhKEkCJQAVRscSYMpmbf):
  (BtLNjxIyaodhKEkCJQAVRscSYMpmbr,BtLNjxIyaodhKEkCJQAVRscSYMpmbu,BtLNjxIyaodhKEkCJQAVRscSYMpmbv)=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.get_settings_account()
  if BtLNjxIyaodhKEkCJQAVRscSYMpmbr=='' or BtLNjxIyaodhKEkCJQAVRscSYMpmbu=='':
   BtLNjxIyaodhKEkCJQAVRscSYMpmbH=xbmcgui.Dialog()
   BtLNjxIyaodhKEkCJQAVRscSYMpmDr=BtLNjxIyaodhKEkCJQAVRscSYMpmbH.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if BtLNjxIyaodhKEkCJQAVRscSYMpmDr==BtLNjxIyaodhKEkCJQAVRscSYMpmGn:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if BtLNjxIyaodhKEkCJQAVRscSYMpmbf.cookiefile_check()==BtLNjxIyaodhKEkCJQAVRscSYMpmGW:
   if BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CP_login(BtLNjxIyaodhKEkCJQAVRscSYMpmbr,BtLNjxIyaodhKEkCJQAVRscSYMpmbu,BtLNjxIyaodhKEkCJQAVRscSYMpmbv)==BtLNjxIyaodhKEkCJQAVRscSYMpmGW:
    BtLNjxIyaodhKEkCJQAVRscSYMpmbf.addon_noti(__language__(30903).encode('utf8'))
    sys.exit()
  else:
   if BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.CP['SESSION']['bm_sv_ex']<BtLNjxIyaodhKEkCJQAVRscSYMpmGz(time.time()):
    if BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CP_login(BtLNjxIyaodhKEkCJQAVRscSYMpmbr,BtLNjxIyaodhKEkCJQAVRscSYMpmbu,BtLNjxIyaodhKEkCJQAVRscSYMpmbv)==BtLNjxIyaodhKEkCJQAVRscSYMpmGW:
     BtLNjxIyaodhKEkCJQAVRscSYMpmbf.addon_noti(__language__(30903).encode('utf8'))
     sys.exit()
 def cookiefile_check(BtLNjxIyaodhKEkCJQAVRscSYMpmbf):
  BtLNjxIyaodhKEkCJQAVRscSYMpmDu={}
  try: 
   fp=BtLNjxIyaodhKEkCJQAVRscSYMpmGr(BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.CP_COOKIE_FILENAME,'r',-1,'utf-8')
   BtLNjxIyaodhKEkCJQAVRscSYMpmDu= json.load(fp)
   fp.close()
  except BtLNjxIyaodhKEkCJQAVRscSYMpmGu as exception:
   return BtLNjxIyaodhKEkCJQAVRscSYMpmGW
  BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.CP=BtLNjxIyaodhKEkCJQAVRscSYMpmDu
  (BtLNjxIyaodhKEkCJQAVRscSYMpmbr,BtLNjxIyaodhKEkCJQAVRscSYMpmbu,BtLNjxIyaodhKEkCJQAVRscSYMpmbv)=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.get_settings_account()
  (BtLNjxIyaodhKEkCJQAVRscSYMpmDv,BtLNjxIyaodhKEkCJQAVRscSYMpmDw,BtLNjxIyaodhKEkCJQAVRscSYMpmDP)=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.Load_session_acount()
  if BtLNjxIyaodhKEkCJQAVRscSYMpmbr!=BtLNjxIyaodhKEkCJQAVRscSYMpmDv or BtLNjxIyaodhKEkCJQAVRscSYMpmbu!=BtLNjxIyaodhKEkCJQAVRscSYMpmDw or BtLNjxIyaodhKEkCJQAVRscSYMpmbv!=BtLNjxIyaodhKEkCJQAVRscSYMpmGv(BtLNjxIyaodhKEkCJQAVRscSYMpmDP):
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.Init_CP()
   return BtLNjxIyaodhKEkCJQAVRscSYMpmGW
  BtLNjxIyaodhKEkCJQAVRscSYMpmDq =BtLNjxIyaodhKEkCJQAVRscSYMpmGz(BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.Get_Now_Datetime().strftime('%Y%m%d'))
  BtLNjxIyaodhKEkCJQAVRscSYMpmDO=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.CP['SESSION']['limitdate']
  BtLNjxIyaodhKEkCJQAVRscSYMpmDi =BtLNjxIyaodhKEkCJQAVRscSYMpmGz(re.sub('-','',BtLNjxIyaodhKEkCJQAVRscSYMpmDO))
  if BtLNjxIyaodhKEkCJQAVRscSYMpmDi<BtLNjxIyaodhKEkCJQAVRscSYMpmDq:
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.Init_CP()
   return BtLNjxIyaodhKEkCJQAVRscSYMpmGW
  return BtLNjxIyaodhKEkCJQAVRscSYMpmGn
 def CP_login(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,BtLNjxIyaodhKEkCJQAVRscSYMpmbr,BtLNjxIyaodhKEkCJQAVRscSYMpmbu,BtLNjxIyaodhKEkCJQAVRscSYMpmbv):
  BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.Init_CP()
  if BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.Get_CP_Login(BtLNjxIyaodhKEkCJQAVRscSYMpmbr,BtLNjxIyaodhKEkCJQAVRscSYMpmbu,BtLNjxIyaodhKEkCJQAVRscSYMpmbv)==BtLNjxIyaodhKEkCJQAVRscSYMpmGW:return BtLNjxIyaodhKEkCJQAVRscSYMpmGW
  if BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.Get_CP_profile(BtLNjxIyaodhKEkCJQAVRscSYMpmbv,limit_days=BtLNjxIyaodhKEkCJQAVRscSYMpmGz(__addon__.getSetting('cache_ttl')),re_check=BtLNjxIyaodhKEkCJQAVRscSYMpmGW)==BtLNjxIyaodhKEkCJQAVRscSYMpmGW:return BtLNjxIyaodhKEkCJQAVRscSYMpmGW
  return BtLNjxIyaodhKEkCJQAVRscSYMpmGn
 def dp_Category_GroupList(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,args):
  BtLNjxIyaodhKEkCJQAVRscSYMpmgb =args.get('vType') 
  BtLNjxIyaodhKEkCJQAVRscSYMpmgD=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.Get_Category_GroupList(BtLNjxIyaodhKEkCJQAVRscSYMpmgb)
  for BtLNjxIyaodhKEkCJQAVRscSYMpmgF in BtLNjxIyaodhKEkCJQAVRscSYMpmgD:
   BtLNjxIyaodhKEkCJQAVRscSYMpmDe =BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('title')
   BtLNjxIyaodhKEkCJQAVRscSYMpmge=BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('pre_title')
   if BtLNjxIyaodhKEkCJQAVRscSYMpmbf.get_settings_exclusion21()==BtLNjxIyaodhKEkCJQAVRscSYMpmGn and BtLNjxIyaodhKEkCJQAVRscSYMpmDe=='성인':continue
   BtLNjxIyaodhKEkCJQAVRscSYMpmgl={'mediatype':'tvshow','plot':BtLNjxIyaodhKEkCJQAVRscSYMpmge,}
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU={'mode':'CATEGORY_LIST','collectionId':BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('collectionId'),'vType':BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('category'),'page':'1',}
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.add_dir(BtLNjxIyaodhKEkCJQAVRscSYMpmDe,sublabel='',img='',infoLabels=BtLNjxIyaodhKEkCJQAVRscSYMpmgl,isFolder=BtLNjxIyaodhKEkCJQAVRscSYMpmGn,params=BtLNjxIyaodhKEkCJQAVRscSYMpmDU)
  xbmcplugin.endOfDirectory(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,cacheToDisc=BtLNjxIyaodhKEkCJQAVRscSYMpmGW)
 def dp_Theme_GroupList(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,args):
  BtLNjxIyaodhKEkCJQAVRscSYMpmgb =args.get('vType') 
  BtLNjxIyaodhKEkCJQAVRscSYMpmgD=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.Get_Theme_GroupList(BtLNjxIyaodhKEkCJQAVRscSYMpmgb)
  for BtLNjxIyaodhKEkCJQAVRscSYMpmgF in BtLNjxIyaodhKEkCJQAVRscSYMpmgD:
   BtLNjxIyaodhKEkCJQAVRscSYMpmDe =BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('title')
   BtLNjxIyaodhKEkCJQAVRscSYMpmge=BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('pre_title')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgl={'mediatype':'tvshow','plot':BtLNjxIyaodhKEkCJQAVRscSYMpmge,}
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU={'mode':'CATEGORY_LIST','collectionId':BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('collectionId'),'vType':BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('category'),'page':'1',}
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.add_dir(BtLNjxIyaodhKEkCJQAVRscSYMpmDe,sublabel='',img='',infoLabels=BtLNjxIyaodhKEkCJQAVRscSYMpmgl,isFolder=BtLNjxIyaodhKEkCJQAVRscSYMpmGn,params=BtLNjxIyaodhKEkCJQAVRscSYMpmDU)
  xbmcplugin.endOfDirectory(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,cacheToDisc=BtLNjxIyaodhKEkCJQAVRscSYMpmGW)
 def dp_Event_GroupList(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,args):
  BtLNjxIyaodhKEkCJQAVRscSYMpmgD=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.Get_Event_GroupList()
  for BtLNjxIyaodhKEkCJQAVRscSYMpmgF in BtLNjxIyaodhKEkCJQAVRscSYMpmgD:
   BtLNjxIyaodhKEkCJQAVRscSYMpmDe =BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('title')
   BtLNjxIyaodhKEkCJQAVRscSYMpmge=BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('pre_title')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgl={'mediatype':'tvshow','plot':BtLNjxIyaodhKEkCJQAVRscSYMpmge,}
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU={'mode':'EVENT_GAMELIST','collectionId':BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('collectionId'),'vType':'LIVE',}
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.add_dir(BtLNjxIyaodhKEkCJQAVRscSYMpmDe,sublabel='',img='',infoLabels=BtLNjxIyaodhKEkCJQAVRscSYMpmgl,isFolder=BtLNjxIyaodhKEkCJQAVRscSYMpmGn,params=BtLNjxIyaodhKEkCJQAVRscSYMpmDU)
  xbmcplugin.endOfDirectory(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,cacheToDisc=BtLNjxIyaodhKEkCJQAVRscSYMpmGW)
 def dp_Event_GameList(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,args):
  BtLNjxIyaodhKEkCJQAVRscSYMpmgb =args.get('vType') 
  BtLNjxIyaodhKEkCJQAVRscSYMpmgG =args.get('collectionId')
  BtLNjxIyaodhKEkCJQAVRscSYMpmgD=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.Get_Event_GameList(BtLNjxIyaodhKEkCJQAVRscSYMpmgG)
  for BtLNjxIyaodhKEkCJQAVRscSYMpmgF in BtLNjxIyaodhKEkCJQAVRscSYMpmgD:
   BtLNjxIyaodhKEkCJQAVRscSYMpmDe =BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('title')
   BtLNjxIyaodhKEkCJQAVRscSYMpmGw =BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('id')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgW =BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('thumbnail')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgn =BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('asis') 
   BtLNjxIyaodhKEkCJQAVRscSYMpmgU =BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('addInfo')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgH =BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('starttm')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgl={'mediatype':'tvshow','title':BtLNjxIyaodhKEkCJQAVRscSYMpmDe,'plot':BtLNjxIyaodhKEkCJQAVRscSYMpmgU,}
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU={'mode':'EVENT_LIST','id':BtLNjxIyaodhKEkCJQAVRscSYMpmGw,'asis':BtLNjxIyaodhKEkCJQAVRscSYMpmgn,'title':BtLNjxIyaodhKEkCJQAVRscSYMpmDe,}
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.add_dir(BtLNjxIyaodhKEkCJQAVRscSYMpmDe,sublabel=BtLNjxIyaodhKEkCJQAVRscSYMpmgH,img=BtLNjxIyaodhKEkCJQAVRscSYMpmgW,infoLabels=BtLNjxIyaodhKEkCJQAVRscSYMpmgl,isFolder=BtLNjxIyaodhKEkCJQAVRscSYMpmGn,params=BtLNjxIyaodhKEkCJQAVRscSYMpmDU,ContextMenu=BtLNjxIyaodhKEkCJQAVRscSYMpmGf)
  xbmcplugin.setContent(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,cacheToDisc=BtLNjxIyaodhKEkCJQAVRscSYMpmGW)
 def dp_Event_List(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,args):
  BtLNjxIyaodhKEkCJQAVRscSYMpmgT=args.get('id')
  BtLNjxIyaodhKEkCJQAVRscSYMpmgD=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.Get_Event_List(BtLNjxIyaodhKEkCJQAVRscSYMpmgT)
  for BtLNjxIyaodhKEkCJQAVRscSYMpmgF in BtLNjxIyaodhKEkCJQAVRscSYMpmgD:
   BtLNjxIyaodhKEkCJQAVRscSYMpmDe =BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('title')
   BtLNjxIyaodhKEkCJQAVRscSYMpmGw =BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('id')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgW =BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('thumbnail')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgn =BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('asis') 
   BtLNjxIyaodhKEkCJQAVRscSYMpmgz =BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('duration')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgH =BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('starttm')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgl={'mediatype':'episode','title':BtLNjxIyaodhKEkCJQAVRscSYMpmDe,'plot':BtLNjxIyaodhKEkCJQAVRscSYMpmgn,'duration':BtLNjxIyaodhKEkCJQAVRscSYMpmgz,}
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU={'mode':BtLNjxIyaodhKEkCJQAVRscSYMpmgn,'id':BtLNjxIyaodhKEkCJQAVRscSYMpmGw,'asis':BtLNjxIyaodhKEkCJQAVRscSYMpmgn,'title':BtLNjxIyaodhKEkCJQAVRscSYMpmDe,}
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.add_dir(BtLNjxIyaodhKEkCJQAVRscSYMpmDe,sublabel=BtLNjxIyaodhKEkCJQAVRscSYMpmgH,img=BtLNjxIyaodhKEkCJQAVRscSYMpmgW,infoLabels=BtLNjxIyaodhKEkCJQAVRscSYMpmgl,isFolder=BtLNjxIyaodhKEkCJQAVRscSYMpmGW,params=BtLNjxIyaodhKEkCJQAVRscSYMpmDU,ContextMenu=BtLNjxIyaodhKEkCJQAVRscSYMpmGf)
  xbmcplugin.setContent(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,cacheToDisc=BtLNjxIyaodhKEkCJQAVRscSYMpmGW)
 def dp_Category_List(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,args):
  BtLNjxIyaodhKEkCJQAVRscSYMpmgb =args.get('vType') 
  BtLNjxIyaodhKEkCJQAVRscSYMpmgG =args.get('collectionId')
  BtLNjxIyaodhKEkCJQAVRscSYMpmgX =BtLNjxIyaodhKEkCJQAVRscSYMpmGz(args.get('page'))
  BtLNjxIyaodhKEkCJQAVRscSYMpmgD,BtLNjxIyaodhKEkCJQAVRscSYMpmgr=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.Get_Category_List(BtLNjxIyaodhKEkCJQAVRscSYMpmgb,BtLNjxIyaodhKEkCJQAVRscSYMpmgG,BtLNjxIyaodhKEkCJQAVRscSYMpmgX)
  for BtLNjxIyaodhKEkCJQAVRscSYMpmgF in BtLNjxIyaodhKEkCJQAVRscSYMpmgD:
   BtLNjxIyaodhKEkCJQAVRscSYMpmDe =BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('title')
   BtLNjxIyaodhKEkCJQAVRscSYMpmGw =BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('id')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgW =BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('thumbnail')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgu =BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('mpaa')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgz =BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('duration')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgn =BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('asis')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgv =BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('badge')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgw =BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('year')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgP=BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('seasonList')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgq =BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('genreList')
   if BtLNjxIyaodhKEkCJQAVRscSYMpmgn in['TVSHOW','EDUCATION']: 
    BtLNjxIyaodhKEkCJQAVRscSYMpmgO ='SEASON_LIST'
    BtLNjxIyaodhKEkCJQAVRscSYMpmgl={'mediatype':'tvshow','title':BtLNjxIyaodhKEkCJQAVRscSYMpmDe,'mpaa':BtLNjxIyaodhKEkCJQAVRscSYMpmgu,'genre':BtLNjxIyaodhKEkCJQAVRscSYMpmgq,'year':BtLNjxIyaodhKEkCJQAVRscSYMpmgw,'plot':'Year : %s\nSeason : %s'%(BtLNjxIyaodhKEkCJQAVRscSYMpmgw,BtLNjxIyaodhKEkCJQAVRscSYMpmgP),}
    BtLNjxIyaodhKEkCJQAVRscSYMpmDH =BtLNjxIyaodhKEkCJQAVRscSYMpmGn
   else:
    BtLNjxIyaodhKEkCJQAVRscSYMpmgO ='MOVIE'
    BtLNjxIyaodhKEkCJQAVRscSYMpmgl={'mediatype':'movie','title':BtLNjxIyaodhKEkCJQAVRscSYMpmDe,'mpaa':BtLNjxIyaodhKEkCJQAVRscSYMpmgu,'genre':BtLNjxIyaodhKEkCJQAVRscSYMpmgq,'duration':BtLNjxIyaodhKEkCJQAVRscSYMpmgz,'year':BtLNjxIyaodhKEkCJQAVRscSYMpmgw,'plot':'(%s)'%(BtLNjxIyaodhKEkCJQAVRscSYMpmgu),}
    BtLNjxIyaodhKEkCJQAVRscSYMpmDH =BtLNjxIyaodhKEkCJQAVRscSYMpmGW
    BtLNjxIyaodhKEkCJQAVRscSYMpmDe +=' (%s)'%(BtLNjxIyaodhKEkCJQAVRscSYMpmGv(BtLNjxIyaodhKEkCJQAVRscSYMpmgw))
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU={'mode':BtLNjxIyaodhKEkCJQAVRscSYMpmgO,'id':BtLNjxIyaodhKEkCJQAVRscSYMpmGw,'asis':BtLNjxIyaodhKEkCJQAVRscSYMpmgn,'seasonList':BtLNjxIyaodhKEkCJQAVRscSYMpmgP,'title':BtLNjxIyaodhKEkCJQAVRscSYMpmDe,'thumbnail':BtLNjxIyaodhKEkCJQAVRscSYMpmgW,'year':BtLNjxIyaodhKEkCJQAVRscSYMpmgw,}
   if BtLNjxIyaodhKEkCJQAVRscSYMpmbf.get_settings_makebookmark():
    BtLNjxIyaodhKEkCJQAVRscSYMpmgi={'videoid':BtLNjxIyaodhKEkCJQAVRscSYMpmGw,'vidtype':'movie' if BtLNjxIyaodhKEkCJQAVRscSYMpmgb=='MOVIES' else 'tvshow','vtitle':BtLNjxIyaodhKEkCJQAVRscSYMpmDe,'vsubtitle':'',}
    BtLNjxIyaodhKEkCJQAVRscSYMpmFb=json.dumps(BtLNjxIyaodhKEkCJQAVRscSYMpmgi)
    BtLNjxIyaodhKEkCJQAVRscSYMpmFb=urllib.parse.quote(BtLNjxIyaodhKEkCJQAVRscSYMpmFb)
    BtLNjxIyaodhKEkCJQAVRscSYMpmFD='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(BtLNjxIyaodhKEkCJQAVRscSYMpmFb)
    BtLNjxIyaodhKEkCJQAVRscSYMpmFg=[('(통합) 찜 영상에 추가',BtLNjxIyaodhKEkCJQAVRscSYMpmFD)]
   else:
    BtLNjxIyaodhKEkCJQAVRscSYMpmFg=BtLNjxIyaodhKEkCJQAVRscSYMpmGf
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.add_dir(BtLNjxIyaodhKEkCJQAVRscSYMpmDe,sublabel=BtLNjxIyaodhKEkCJQAVRscSYMpmgv,img=BtLNjxIyaodhKEkCJQAVRscSYMpmgW,infoLabels=BtLNjxIyaodhKEkCJQAVRscSYMpmgl,isFolder=BtLNjxIyaodhKEkCJQAVRscSYMpmDH,params=BtLNjxIyaodhKEkCJQAVRscSYMpmDU,ContextMenu=BtLNjxIyaodhKEkCJQAVRscSYMpmFg)
  if BtLNjxIyaodhKEkCJQAVRscSYMpmgr:
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU['mode'] ='CATEGORY_LIST' 
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU['collectionId']=BtLNjxIyaodhKEkCJQAVRscSYMpmgG 
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU['vType'] =BtLNjxIyaodhKEkCJQAVRscSYMpmgb 
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU['page'] =BtLNjxIyaodhKEkCJQAVRscSYMpmGv(BtLNjxIyaodhKEkCJQAVRscSYMpmgX+1)
   BtLNjxIyaodhKEkCJQAVRscSYMpmDe='[B]%s >>[/B]'%'다음 페이지'
   BtLNjxIyaodhKEkCJQAVRscSYMpmFe=BtLNjxIyaodhKEkCJQAVRscSYMpmGv(BtLNjxIyaodhKEkCJQAVRscSYMpmgX+1)
   BtLNjxIyaodhKEkCJQAVRscSYMpmDn=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.add_dir(BtLNjxIyaodhKEkCJQAVRscSYMpmDe,sublabel=BtLNjxIyaodhKEkCJQAVRscSYMpmFe,img=BtLNjxIyaodhKEkCJQAVRscSYMpmDn,infoLabels=BtLNjxIyaodhKEkCJQAVRscSYMpmGf,isFolder=BtLNjxIyaodhKEkCJQAVRscSYMpmGn,params=BtLNjxIyaodhKEkCJQAVRscSYMpmDU)
  if BtLNjxIyaodhKEkCJQAVRscSYMpmgb=='TVSHOWS':xbmcplugin.setContent(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,'tvshows')
  else:xbmcplugin.setContent(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,'movies')
  xbmcplugin.endOfDirectory(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,cacheToDisc=BtLNjxIyaodhKEkCJQAVRscSYMpmGW)
 def dp_Season_List(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,args):
  BtLNjxIyaodhKEkCJQAVRscSYMpmFl =args.get('title')
  BtLNjxIyaodhKEkCJQAVRscSYMpmFf =args.get('id')
  BtLNjxIyaodhKEkCJQAVRscSYMpmgn =args.get('asis')
  BtLNjxIyaodhKEkCJQAVRscSYMpmgP =args.get('seasonList')
  BtLNjxIyaodhKEkCJQAVRscSYMpmgW =args.get('thumbnail')
  BtLNjxIyaodhKEkCJQAVRscSYMpmgw =args.get('year')
  if BtLNjxIyaodhKEkCJQAVRscSYMpmgP in['',BtLNjxIyaodhKEkCJQAVRscSYMpmGf]:
   BtLNjxIyaodhKEkCJQAVRscSYMpmgP=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.Get_vInfo(BtLNjxIyaodhKEkCJQAVRscSYMpmFf).get('seasonList')
  if BtLNjxIyaodhKEkCJQAVRscSYMpmGP(BtLNjxIyaodhKEkCJQAVRscSYMpmgP.split(','))>1:
   for BtLNjxIyaodhKEkCJQAVRscSYMpmFG in BtLNjxIyaodhKEkCJQAVRscSYMpmgP.split(','):
    BtLNjxIyaodhKEkCJQAVRscSYMpmDe='시즌 '+BtLNjxIyaodhKEkCJQAVRscSYMpmFG
    BtLNjxIyaodhKEkCJQAVRscSYMpmgl={'mediatype':'tvshow','plot':'%s (%s)'%(BtLNjxIyaodhKEkCJQAVRscSYMpmFl,BtLNjxIyaodhKEkCJQAVRscSYMpmgw),}
    BtLNjxIyaodhKEkCJQAVRscSYMpmDU={'mode':'EPISODE_LIST','programid':BtLNjxIyaodhKEkCJQAVRscSYMpmFf,'programnm':BtLNjxIyaodhKEkCJQAVRscSYMpmFl,'season':BtLNjxIyaodhKEkCJQAVRscSYMpmFG,'asis':BtLNjxIyaodhKEkCJQAVRscSYMpmgn,'programimg':BtLNjxIyaodhKEkCJQAVRscSYMpmgW,'page':'1',}
    BtLNjxIyaodhKEkCJQAVRscSYMpmFW=BtLNjxIyaodhKEkCJQAVRscSYMpmgW.replace('\'','\"')
    BtLNjxIyaodhKEkCJQAVRscSYMpmFW=json.loads(BtLNjxIyaodhKEkCJQAVRscSYMpmFW)
    BtLNjxIyaodhKEkCJQAVRscSYMpmbf.add_dir(BtLNjxIyaodhKEkCJQAVRscSYMpmDe,sublabel='',img=BtLNjxIyaodhKEkCJQAVRscSYMpmFW,infoLabels=BtLNjxIyaodhKEkCJQAVRscSYMpmgl,isFolder=BtLNjxIyaodhKEkCJQAVRscSYMpmGn,params=BtLNjxIyaodhKEkCJQAVRscSYMpmDU)
   xbmcplugin.setContent(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,cacheToDisc=BtLNjxIyaodhKEkCJQAVRscSYMpmGW)
  else:
   BtLNjxIyaodhKEkCJQAVRscSYMpmFn={'programid':BtLNjxIyaodhKEkCJQAVRscSYMpmFf,'programnm':BtLNjxIyaodhKEkCJQAVRscSYMpmFl,'season':BtLNjxIyaodhKEkCJQAVRscSYMpmgP,'programimg':BtLNjxIyaodhKEkCJQAVRscSYMpmgW,'page':'1',}
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.dp_Episode_List(BtLNjxIyaodhKEkCJQAVRscSYMpmFn)
 def dp_Episode_List(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,args):
  BtLNjxIyaodhKEkCJQAVRscSYMpmFf =args.get('programid')
  BtLNjxIyaodhKEkCJQAVRscSYMpmFl =args.get('programnm')
  BtLNjxIyaodhKEkCJQAVRscSYMpmFU =args.get('season')
  BtLNjxIyaodhKEkCJQAVRscSYMpmFH =args.get('programimg')
  BtLNjxIyaodhKEkCJQAVRscSYMpmgX =BtLNjxIyaodhKEkCJQAVRscSYMpmGz(args.get('page'))
  BtLNjxIyaodhKEkCJQAVRscSYMpmFT,BtLNjxIyaodhKEkCJQAVRscSYMpmgr=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.Get_Episode_List(BtLNjxIyaodhKEkCJQAVRscSYMpmFf,BtLNjxIyaodhKEkCJQAVRscSYMpmFU,page=BtLNjxIyaodhKEkCJQAVRscSYMpmgX,orderby=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.get_winEpisodeOrderby())
  for BtLNjxIyaodhKEkCJQAVRscSYMpmFG in BtLNjxIyaodhKEkCJQAVRscSYMpmFT:
   BtLNjxIyaodhKEkCJQAVRscSYMpmFz =BtLNjxIyaodhKEkCJQAVRscSYMpmFG.get('title')
   BtLNjxIyaodhKEkCJQAVRscSYMpmFX =BtLNjxIyaodhKEkCJQAVRscSYMpmFG.get('id')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgn =BtLNjxIyaodhKEkCJQAVRscSYMpmFG.get('asis')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgW =BtLNjxIyaodhKEkCJQAVRscSYMpmFG.get('thumbnail')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgu =BtLNjxIyaodhKEkCJQAVRscSYMpmFG.get('mpaa')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgz =BtLNjxIyaodhKEkCJQAVRscSYMpmFG.get('duration')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgw =BtLNjxIyaodhKEkCJQAVRscSYMpmFG.get('year')
   BtLNjxIyaodhKEkCJQAVRscSYMpmFr =BtLNjxIyaodhKEkCJQAVRscSYMpmFG.get('episode')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgq =BtLNjxIyaodhKEkCJQAVRscSYMpmFG.get('genreList')
   BtLNjxIyaodhKEkCJQAVRscSYMpmFu =BtLNjxIyaodhKEkCJQAVRscSYMpmFG.get('desc')
   BtLNjxIyaodhKEkCJQAVRscSYMpmFv ='%sx%s'%(BtLNjxIyaodhKEkCJQAVRscSYMpmFU,BtLNjxIyaodhKEkCJQAVRscSYMpmFr)
   BtLNjxIyaodhKEkCJQAVRscSYMpmDe ='%s. %s'%(BtLNjxIyaodhKEkCJQAVRscSYMpmFv,BtLNjxIyaodhKEkCJQAVRscSYMpmFz)
   BtLNjxIyaodhKEkCJQAVRscSYMpmgl={'mediatype':'episode','mpaa':BtLNjxIyaodhKEkCJQAVRscSYMpmgu,'genre':BtLNjxIyaodhKEkCJQAVRscSYMpmgq,'duration':BtLNjxIyaodhKEkCJQAVRscSYMpmgz,'year':BtLNjxIyaodhKEkCJQAVRscSYMpmgw,'plot':'%s (%s)\n\n%s'%(BtLNjxIyaodhKEkCJQAVRscSYMpmFl,BtLNjxIyaodhKEkCJQAVRscSYMpmFv,BtLNjxIyaodhKEkCJQAVRscSYMpmFu),}
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU={'mode':'VOD','programid':BtLNjxIyaodhKEkCJQAVRscSYMpmFf,'programnm':BtLNjxIyaodhKEkCJQAVRscSYMpmFl,'title':BtLNjxIyaodhKEkCJQAVRscSYMpmDe,'season':BtLNjxIyaodhKEkCJQAVRscSYMpmFU,'id':BtLNjxIyaodhKEkCJQAVRscSYMpmFX,'asis':BtLNjxIyaodhKEkCJQAVRscSYMpmgn,'thumbnail':BtLNjxIyaodhKEkCJQAVRscSYMpmgW,'programimg':BtLNjxIyaodhKEkCJQAVRscSYMpmFH,}
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.add_dir(BtLNjxIyaodhKEkCJQAVRscSYMpmDe,sublabel='',img=BtLNjxIyaodhKEkCJQAVRscSYMpmgW,infoLabels=BtLNjxIyaodhKEkCJQAVRscSYMpmgl,isFolder=BtLNjxIyaodhKEkCJQAVRscSYMpmGW,params=BtLNjxIyaodhKEkCJQAVRscSYMpmDU)
  if BtLNjxIyaodhKEkCJQAVRscSYMpmgX==1:
   BtLNjxIyaodhKEkCJQAVRscSYMpmgl={'plot':'정렬순서를 변경합니다.'}
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU={}
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU['mode'] ='ORDER_BY' 
   if BtLNjxIyaodhKEkCJQAVRscSYMpmbf.get_winEpisodeOrderby()=='desc':
    BtLNjxIyaodhKEkCJQAVRscSYMpmDe='정렬순서변경 : 최신화부터 -> 1회부터'
    BtLNjxIyaodhKEkCJQAVRscSYMpmDU['orderby']='asc'
   else:
    BtLNjxIyaodhKEkCJQAVRscSYMpmDe='정렬순서변경 : 1회부터 -> 최신화부터'
    BtLNjxIyaodhKEkCJQAVRscSYMpmDU['orderby']='desc'
   BtLNjxIyaodhKEkCJQAVRscSYMpmDn=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.add_dir(BtLNjxIyaodhKEkCJQAVRscSYMpmDe,sublabel='',img=BtLNjxIyaodhKEkCJQAVRscSYMpmDn,infoLabels=BtLNjxIyaodhKEkCJQAVRscSYMpmgl,isFolder=BtLNjxIyaodhKEkCJQAVRscSYMpmGW,params=BtLNjxIyaodhKEkCJQAVRscSYMpmDU,isLink=BtLNjxIyaodhKEkCJQAVRscSYMpmGn)
  if BtLNjxIyaodhKEkCJQAVRscSYMpmgr:
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU={}
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU['mode'] ='EPISODE_LIST'
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU['programid'] =BtLNjxIyaodhKEkCJQAVRscSYMpmFf
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU['programnm'] =BtLNjxIyaodhKEkCJQAVRscSYMpmFl
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU['season'] =BtLNjxIyaodhKEkCJQAVRscSYMpmFU
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU['programimg']=BtLNjxIyaodhKEkCJQAVRscSYMpmFH
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU['page'] =BtLNjxIyaodhKEkCJQAVRscSYMpmGv(BtLNjxIyaodhKEkCJQAVRscSYMpmgX+1)
   BtLNjxIyaodhKEkCJQAVRscSYMpmDe='[B]%s >>[/B]'%'다음 페이지'
   BtLNjxIyaodhKEkCJQAVRscSYMpmFe=BtLNjxIyaodhKEkCJQAVRscSYMpmGv(BtLNjxIyaodhKEkCJQAVRscSYMpmgX+1)
   BtLNjxIyaodhKEkCJQAVRscSYMpmDn=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.add_dir(BtLNjxIyaodhKEkCJQAVRscSYMpmDe,sublabel=BtLNjxIyaodhKEkCJQAVRscSYMpmFe,img=BtLNjxIyaodhKEkCJQAVRscSYMpmDn,infoLabels=BtLNjxIyaodhKEkCJQAVRscSYMpmGf,isFolder=BtLNjxIyaodhKEkCJQAVRscSYMpmGn,params=BtLNjxIyaodhKEkCJQAVRscSYMpmDU)
  xbmcplugin.setContent(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,cacheToDisc=BtLNjxIyaodhKEkCJQAVRscSYMpmGW)
 def play_VIDEO(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,args):
  BtLNjxIyaodhKEkCJQAVRscSYMpmFw =args.get('id')
  BtLNjxIyaodhKEkCJQAVRscSYMpmgn =args.get('asis')
  if BtLNjxIyaodhKEkCJQAVRscSYMpmgn in['HIGHLIGHT']:
   BtLNjxIyaodhKEkCJQAVRscSYMpmFP,BtLNjxIyaodhKEkCJQAVRscSYMpmFq=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.GetEventURL(BtLNjxIyaodhKEkCJQAVRscSYMpmFw,BtLNjxIyaodhKEkCJQAVRscSYMpmgn)
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmgn in['LIVE']:
   BtLNjxIyaodhKEkCJQAVRscSYMpmFP,BtLNjxIyaodhKEkCJQAVRscSYMpmFq=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.GetEventURL_Live(BtLNjxIyaodhKEkCJQAVRscSYMpmFw,BtLNjxIyaodhKEkCJQAVRscSYMpmgn)
  else:
   BtLNjxIyaodhKEkCJQAVRscSYMpmFP,BtLNjxIyaodhKEkCJQAVRscSYMpmFq=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.GetBroadURL(BtLNjxIyaodhKEkCJQAVRscSYMpmFw)
  BtLNjxIyaodhKEkCJQAVRscSYMpmbf.addon_log('asis, url : %s - %s - %s'%(BtLNjxIyaodhKEkCJQAVRscSYMpmgn,BtLNjxIyaodhKEkCJQAVRscSYMpmFw,BtLNjxIyaodhKEkCJQAVRscSYMpmFP))
  if BtLNjxIyaodhKEkCJQAVRscSYMpmFP=='':
   if BtLNjxIyaodhKEkCJQAVRscSYMpmFq=='':
    BtLNjxIyaodhKEkCJQAVRscSYMpmbf.addon_noti(__language__(30907).encode('utf8'))
   else:
    BtLNjxIyaodhKEkCJQAVRscSYMpmbf.addon_log('drm_license_1 : %s'%(BtLNjxIyaodhKEkCJQAVRscSYMpmFq))
    BtLNjxIyaodhKEkCJQAVRscSYMpmbf.addon_noti(BtLNjxIyaodhKEkCJQAVRscSYMpmFq)
   return
  else:
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.addon_log('drm_license : %s'%(BtLNjxIyaodhKEkCJQAVRscSYMpmFq))
  '''
  tmp_cookie = 'PCID=%s;token=%s;member_srl=%s;NEXT_LOCALE=%s;session_web_id=%s;device_id=%s' % (self.CoupangObj.CP['COOKIES']['PCID'], self.CoupangObj.CP['COOKIES']['token'], self.CoupangObj.CP['COOKIES']['member_srl'], self.CoupangObj.CP['COOKIES']['NEXT_LOCALE'], self.CoupangObj.CP['COOKIES']['session_web_id'], self.CoupangObj.CP['COOKIES']['device_id'], )
  '''  
  if BtLNjxIyaodhKEkCJQAVRscSYMpmgn in['EPISODE']:
   BtLNjxIyaodhKEkCJQAVRscSYMpmFO='https://www.coupangplay.com/play/{}/episode?titleId={}&type=EPISODE&sourceType=page_discover_title_detail%3Apage_discover_feed'.format(BtLNjxIyaodhKEkCJQAVRscSYMpmFw,BtLNjxIyaodhKEkCJQAVRscSYMpmFw)
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmgn in['MOVIE']:
   BtLNjxIyaodhKEkCJQAVRscSYMpmFO='https://www.coupangplay.com/play/{}/movie?sourceType=page_discover_feed'.format(BtLNjxIyaodhKEkCJQAVRscSYMpmFw)
  else:
   BtLNjxIyaodhKEkCJQAVRscSYMpmFO='https://www.coupangplay.com/play/'+BtLNjxIyaodhKEkCJQAVRscSYMpmFw 
  BtLNjxIyaodhKEkCJQAVRscSYMpmFi,BtLNjxIyaodhKEkCJQAVRscSYMpmeb,BtLNjxIyaodhKEkCJQAVRscSYMpmeD=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.Make_authHeader()
  BtLNjxIyaodhKEkCJQAVRscSYMpmeg=BtLNjxIyaodhKEkCJQAVRscSYMpmFP 
  BtLNjxIyaodhKEkCJQAVRscSYMpmbf.addon_log('tobe, surl : %s'%(BtLNjxIyaodhKEkCJQAVRscSYMpmeg))
  BtLNjxIyaodhKEkCJQAVRscSYMpmeF=xbmcgui.ListItem(path=BtLNjxIyaodhKEkCJQAVRscSYMpmeg)
  BtLNjxIyaodhKEkCJQAVRscSYMpmel=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.Get_Url_PostFix(BtLNjxIyaodhKEkCJQAVRscSYMpmFP) 
  BtLNjxIyaodhKEkCJQAVRscSYMpmbf.addon_log('post_fix : '+BtLNjxIyaodhKEkCJQAVRscSYMpmel)
  if BtLNjxIyaodhKEkCJQAVRscSYMpmel=='m3u8':
   BtLNjxIyaodhKEkCJQAVRscSYMpmef ='hls' 
  else:
   BtLNjxIyaodhKEkCJQAVRscSYMpmef ='mpd' 
  BtLNjxIyaodhKEkCJQAVRscSYMpmeG={'user-agent':BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.USER_AGENT,'referer':BtLNjxIyaodhKEkCJQAVRscSYMpmFO,'traceparent':BtLNjxIyaodhKEkCJQAVRscSYMpmFi,'tracestate':BtLNjxIyaodhKEkCJQAVRscSYMpmeb,'newrelic':BtLNjxIyaodhKEkCJQAVRscSYMpmeD,}
  BtLNjxIyaodhKEkCJQAVRscSYMpmeW =BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.CP['COOKIES']
  BtLNjxIyaodhKEkCJQAVRscSYMpmen=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.make_stream_header(BtLNjxIyaodhKEkCJQAVRscSYMpmeG,BtLNjxIyaodhKEkCJQAVRscSYMpmeW)
  if BtLNjxIyaodhKEkCJQAVRscSYMpmFq:
   BtLNjxIyaodhKEkCJQAVRscSYMpmeU =BtLNjxIyaodhKEkCJQAVRscSYMpmFq 
   BtLNjxIyaodhKEkCJQAVRscSYMpmeH ='com.widevine.alpha'
   BtLNjxIyaodhKEkCJQAVRscSYMpmeT=BtLNjxIyaodhKEkCJQAVRscSYMpmeU+'|'+BtLNjxIyaodhKEkCJQAVRscSYMpmen+'|R{SSM}|'
   inputstreamhelper.Helper(BtLNjxIyaodhKEkCJQAVRscSYMpmef,drm='com.widevine.alpha').check_inputstream()
   BtLNjxIyaodhKEkCJQAVRscSYMpmeF.setProperty('inputstream','inputstream.adaptive')
   if BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.KodiVersion<=20:
    BtLNjxIyaodhKEkCJQAVRscSYMpmeF.setProperty('inputstream.adaptive.manifest_type',BtLNjxIyaodhKEkCJQAVRscSYMpmef)
   BtLNjxIyaodhKEkCJQAVRscSYMpmeF.setProperty('inputstream.adaptive.license_type',BtLNjxIyaodhKEkCJQAVRscSYMpmeH)
   BtLNjxIyaodhKEkCJQAVRscSYMpmeF.setProperty('inputstream.adaptive.license_key',BtLNjxIyaodhKEkCJQAVRscSYMpmeT)
   BtLNjxIyaodhKEkCJQAVRscSYMpmeF.setProperty('inputstream.adaptive.stream_headers',BtLNjxIyaodhKEkCJQAVRscSYMpmen)
   BtLNjxIyaodhKEkCJQAVRscSYMpmeF.setProperty('inputstream.adaptive.manifest_headers',BtLNjxIyaodhKEkCJQAVRscSYMpmen)
   BtLNjxIyaodhKEkCJQAVRscSYMpmeF.setMimeType('application/dash+xml')
   BtLNjxIyaodhKEkCJQAVRscSYMpmeF.setContentLookup(BtLNjxIyaodhKEkCJQAVRscSYMpmGW)
  else:
   BtLNjxIyaodhKEkCJQAVRscSYMpmeF.setContentLookup(BtLNjxIyaodhKEkCJQAVRscSYMpmGW)
   BtLNjxIyaodhKEkCJQAVRscSYMpmeF.setMimeType('application/x-mpegURL')
   BtLNjxIyaodhKEkCJQAVRscSYMpmeF.setProperty('inputstream','inputstream.adaptive')
   if BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.KodiVersion<=20:
    BtLNjxIyaodhKEkCJQAVRscSYMpmeF.setProperty('inputstream.adaptive.manifest_type',BtLNjxIyaodhKEkCJQAVRscSYMpmef)
   BtLNjxIyaodhKEkCJQAVRscSYMpmeF.setProperty('inputstream.adaptive.stream_headers',BtLNjxIyaodhKEkCJQAVRscSYMpmen)
   BtLNjxIyaodhKEkCJQAVRscSYMpmeF.setProperty('inputstream.adaptive.manifest_headers',BtLNjxIyaodhKEkCJQAVRscSYMpmen)
  xbmcplugin.setResolvedUrl(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,BtLNjxIyaodhKEkCJQAVRscSYMpmGn,BtLNjxIyaodhKEkCJQAVRscSYMpmeF)
  try:
   if BtLNjxIyaodhKEkCJQAVRscSYMpmgn=='MOVIE':
    BtLNjxIyaodhKEkCJQAVRscSYMpmeX='movie'
    BtLNjxIyaodhKEkCJQAVRscSYMpmDU={'code':BtLNjxIyaodhKEkCJQAVRscSYMpmFw,'asis':BtLNjxIyaodhKEkCJQAVRscSYMpmgn,'title':args.get('title'),'img':args.get('thumbnail'),}
    BtLNjxIyaodhKEkCJQAVRscSYMpmbf.Save_Watched_List(BtLNjxIyaodhKEkCJQAVRscSYMpmeX,BtLNjxIyaodhKEkCJQAVRscSYMpmDU)
   elif BtLNjxIyaodhKEkCJQAVRscSYMpmgn=='EPISODE':
    BtLNjxIyaodhKEkCJQAVRscSYMpmeX='tvshow'
    BtLNjxIyaodhKEkCJQAVRscSYMpmDU={'code':args.get('programid'),'asis':BtLNjxIyaodhKEkCJQAVRscSYMpmgn,'title':'%s <%s>'%(args.get('title'),args.get('programnm')),'img':args.get('programimg'),}
    BtLNjxIyaodhKEkCJQAVRscSYMpmbf.Save_Watched_List(BtLNjxIyaodhKEkCJQAVRscSYMpmeX,BtLNjxIyaodhKEkCJQAVRscSYMpmDU)
  except:
   BtLNjxIyaodhKEkCJQAVRscSYMpmGf
 def dp_Global_Search(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,args):
  BtLNjxIyaodhKEkCJQAVRscSYMpmgO=args.get('mode')
  if BtLNjxIyaodhKEkCJQAVRscSYMpmgO=='TOTAL_SEARCH':
   BtLNjxIyaodhKEkCJQAVRscSYMpmer='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   BtLNjxIyaodhKEkCJQAVRscSYMpmer='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(BtLNjxIyaodhKEkCJQAVRscSYMpmer)
 def dp_Bookmark_Menu(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,args):
  BtLNjxIyaodhKEkCJQAVRscSYMpmer='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(BtLNjxIyaodhKEkCJQAVRscSYMpmer)
 def dp_Search_List(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,args):
  BtLNjxIyaodhKEkCJQAVRscSYMpmgX =BtLNjxIyaodhKEkCJQAVRscSYMpmGz(args.get('page'))
  if 'search_key' in args:
   BtLNjxIyaodhKEkCJQAVRscSYMpmeu=args.get('search_key')
  else:
   BtLNjxIyaodhKEkCJQAVRscSYMpmeu=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.get_keyboard_input(__language__(30908).encode('utf-8'))
   if not BtLNjxIyaodhKEkCJQAVRscSYMpmeu:
    return
  BtLNjxIyaodhKEkCJQAVRscSYMpmev,BtLNjxIyaodhKEkCJQAVRscSYMpmgr=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.Get_Search_List(BtLNjxIyaodhKEkCJQAVRscSYMpmeu,BtLNjxIyaodhKEkCJQAVRscSYMpmgX)
  for BtLNjxIyaodhKEkCJQAVRscSYMpmew in BtLNjxIyaodhKEkCJQAVRscSYMpmev:
   BtLNjxIyaodhKEkCJQAVRscSYMpmGw =BtLNjxIyaodhKEkCJQAVRscSYMpmew.get('id')
   BtLNjxIyaodhKEkCJQAVRscSYMpmDe =BtLNjxIyaodhKEkCJQAVRscSYMpmew.get('title')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgn =BtLNjxIyaodhKEkCJQAVRscSYMpmew.get('asis')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgW =BtLNjxIyaodhKEkCJQAVRscSYMpmew.get('thumbnail')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgu =BtLNjxIyaodhKEkCJQAVRscSYMpmew.get('mpaa')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgw =BtLNjxIyaodhKEkCJQAVRscSYMpmew.get('year')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgz =BtLNjxIyaodhKEkCJQAVRscSYMpmew.get('duration')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgv =BtLNjxIyaodhKEkCJQAVRscSYMpmew.get('badge')
   if BtLNjxIyaodhKEkCJQAVRscSYMpmgn=='TVSHOW': 
    BtLNjxIyaodhKEkCJQAVRscSYMpmgO ='SEASON_LIST'
    BtLNjxIyaodhKEkCJQAVRscSYMpmgl={'mediatype':'tvshow','title':BtLNjxIyaodhKEkCJQAVRscSYMpmDe,'mpaa':BtLNjxIyaodhKEkCJQAVRscSYMpmgu,'year':BtLNjxIyaodhKEkCJQAVRscSYMpmgw,'plot':'Year : %s'%(BtLNjxIyaodhKEkCJQAVRscSYMpmgw),}
    BtLNjxIyaodhKEkCJQAVRscSYMpmDH =BtLNjxIyaodhKEkCJQAVRscSYMpmGn
   elif BtLNjxIyaodhKEkCJQAVRscSYMpmgn=='MOVIE':
    BtLNjxIyaodhKEkCJQAVRscSYMpmgO ='MOVIE'
    BtLNjxIyaodhKEkCJQAVRscSYMpmgl={'mediatype':'movie','title':BtLNjxIyaodhKEkCJQAVRscSYMpmDe,'mpaa':BtLNjxIyaodhKEkCJQAVRscSYMpmgu,'duration':BtLNjxIyaodhKEkCJQAVRscSYMpmgz,'year':BtLNjxIyaodhKEkCJQAVRscSYMpmgw,'plot':'(%s)'%(BtLNjxIyaodhKEkCJQAVRscSYMpmgu),}
    BtLNjxIyaodhKEkCJQAVRscSYMpmDH =BtLNjxIyaodhKEkCJQAVRscSYMpmGW
    BtLNjxIyaodhKEkCJQAVRscSYMpmDe +=' (%s)'%(BtLNjxIyaodhKEkCJQAVRscSYMpmGv(BtLNjxIyaodhKEkCJQAVRscSYMpmgw))
   elif BtLNjxIyaodhKEkCJQAVRscSYMpmgn=='HIGHLIGHT':
    BtLNjxIyaodhKEkCJQAVRscSYMpmgO ='HIGHLIGHT'
    BtLNjxIyaodhKEkCJQAVRscSYMpmgl={'mediatype':'episode','title':BtLNjxIyaodhKEkCJQAVRscSYMpmDe,'duration':BtLNjxIyaodhKEkCJQAVRscSYMpmgz,'plot':BtLNjxIyaodhKEkCJQAVRscSYMpmgO,}
    BtLNjxIyaodhKEkCJQAVRscSYMpmDH =BtLNjxIyaodhKEkCJQAVRscSYMpmGW
   elif BtLNjxIyaodhKEkCJQAVRscSYMpmgn=='LIVE':
    BtLNjxIyaodhKEkCJQAVRscSYMpmgO ='LIVE'
    BtLNjxIyaodhKEkCJQAVRscSYMpmgl={'mediatype':'episode','title':BtLNjxIyaodhKEkCJQAVRscSYMpmDe,'plot':BtLNjxIyaodhKEkCJQAVRscSYMpmgO,}
    BtLNjxIyaodhKEkCJQAVRscSYMpmDH =BtLNjxIyaodhKEkCJQAVRscSYMpmGW
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU={'mode':BtLNjxIyaodhKEkCJQAVRscSYMpmgO,'id':BtLNjxIyaodhKEkCJQAVRscSYMpmGw,'asis':BtLNjxIyaodhKEkCJQAVRscSYMpmgn,'seasonList':'','title':BtLNjxIyaodhKEkCJQAVRscSYMpmDe,'thumbnail':json.dumps(BtLNjxIyaodhKEkCJQAVRscSYMpmgW,separators=(',',':')),'year':BtLNjxIyaodhKEkCJQAVRscSYMpmgw,}
   if BtLNjxIyaodhKEkCJQAVRscSYMpmbf.get_settings_makebookmark()and BtLNjxIyaodhKEkCJQAVRscSYMpmgn not in['HIGHLIGHT','']:
    BtLNjxIyaodhKEkCJQAVRscSYMpmgi={'videoid':BtLNjxIyaodhKEkCJQAVRscSYMpmGw,'vidtype':'movie' if BtLNjxIyaodhKEkCJQAVRscSYMpmgn=='MOVIE' else 'tvshow','vtitle':BtLNjxIyaodhKEkCJQAVRscSYMpmDe,'vsubtitle':'',}
    BtLNjxIyaodhKEkCJQAVRscSYMpmFb=json.dumps(BtLNjxIyaodhKEkCJQAVRscSYMpmgi)
    BtLNjxIyaodhKEkCJQAVRscSYMpmFb=urllib.parse.quote(BtLNjxIyaodhKEkCJQAVRscSYMpmFb)
    BtLNjxIyaodhKEkCJQAVRscSYMpmFD='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(BtLNjxIyaodhKEkCJQAVRscSYMpmFb)
    BtLNjxIyaodhKEkCJQAVRscSYMpmFg=[('(통합) 찜 영상에 추가',BtLNjxIyaodhKEkCJQAVRscSYMpmFD)]
   else:
    BtLNjxIyaodhKEkCJQAVRscSYMpmFg=BtLNjxIyaodhKEkCJQAVRscSYMpmGf
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.add_dir(BtLNjxIyaodhKEkCJQAVRscSYMpmDe,sublabel=BtLNjxIyaodhKEkCJQAVRscSYMpmgv,img=BtLNjxIyaodhKEkCJQAVRscSYMpmgW,infoLabels=BtLNjxIyaodhKEkCJQAVRscSYMpmgl,isFolder=BtLNjxIyaodhKEkCJQAVRscSYMpmDH,params=BtLNjxIyaodhKEkCJQAVRscSYMpmDU,ContextMenu=BtLNjxIyaodhKEkCJQAVRscSYMpmFg)
  if BtLNjxIyaodhKEkCJQAVRscSYMpmgr:
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU={}
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU['mode'] ='LOCAL_SEARCH'
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU['search_key']=BtLNjxIyaodhKEkCJQAVRscSYMpmeu
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU['page'] =BtLNjxIyaodhKEkCJQAVRscSYMpmGv(BtLNjxIyaodhKEkCJQAVRscSYMpmgX+1)
   BtLNjxIyaodhKEkCJQAVRscSYMpmDe='[B]%s >>[/B]'%'다음 페이지'
   BtLNjxIyaodhKEkCJQAVRscSYMpmFe=BtLNjxIyaodhKEkCJQAVRscSYMpmGv(BtLNjxIyaodhKEkCJQAVRscSYMpmgX+1)
   BtLNjxIyaodhKEkCJQAVRscSYMpmDn=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.add_dir(BtLNjxIyaodhKEkCJQAVRscSYMpmDe,sublabel=BtLNjxIyaodhKEkCJQAVRscSYMpmFe,img=BtLNjxIyaodhKEkCJQAVRscSYMpmDn,infoLabels=BtLNjxIyaodhKEkCJQAVRscSYMpmGf,isFolder=BtLNjxIyaodhKEkCJQAVRscSYMpmGn,params=BtLNjxIyaodhKEkCJQAVRscSYMpmDU)
  xbmcplugin.setContent(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,'movies')
  xbmcplugin.endOfDirectory(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,cacheToDisc=BtLNjxIyaodhKEkCJQAVRscSYMpmGn)
  if args.get('historyyn')=='Y':BtLNjxIyaodhKEkCJQAVRscSYMpmbf.Save_Searched_List(BtLNjxIyaodhKEkCJQAVRscSYMpmeu)
 def Load_List_File(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,BtLNjxIyaodhKEkCJQAVRscSYMpmeX): 
  try:
   if BtLNjxIyaodhKEkCJQAVRscSYMpmeX=='search':
    BtLNjxIyaodhKEkCJQAVRscSYMpmeP=BtLNjxIyaodhKEkCJQAVRscSYMpmbl
   elif BtLNjxIyaodhKEkCJQAVRscSYMpmeX in['tvshow','movie']:
    BtLNjxIyaodhKEkCJQAVRscSYMpmeP=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%BtLNjxIyaodhKEkCJQAVRscSYMpmeX))
   else:
    return[]
   fp=BtLNjxIyaodhKEkCJQAVRscSYMpmGr(BtLNjxIyaodhKEkCJQAVRscSYMpmeP,'r',-1,'utf-8')
   BtLNjxIyaodhKEkCJQAVRscSYMpmeq=fp.readlines()
   fp.close()
  except:
   BtLNjxIyaodhKEkCJQAVRscSYMpmeq=[]
  return BtLNjxIyaodhKEkCJQAVRscSYMpmeq
 def Save_Watched_List(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,BtLNjxIyaodhKEkCJQAVRscSYMpmeX,BtLNjxIyaodhKEkCJQAVRscSYMpmbn):
  try:
   BtLNjxIyaodhKEkCJQAVRscSYMpmeO=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%BtLNjxIyaodhKEkCJQAVRscSYMpmeX))
   BtLNjxIyaodhKEkCJQAVRscSYMpmei=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.Load_List_File(BtLNjxIyaodhKEkCJQAVRscSYMpmeX) 
   fp=BtLNjxIyaodhKEkCJQAVRscSYMpmGr(BtLNjxIyaodhKEkCJQAVRscSYMpmeO,'w',-1,'utf-8')
   BtLNjxIyaodhKEkCJQAVRscSYMpmlb=urllib.parse.urlencode(BtLNjxIyaodhKEkCJQAVRscSYMpmbn)
   BtLNjxIyaodhKEkCJQAVRscSYMpmlb=BtLNjxIyaodhKEkCJQAVRscSYMpmlb+'\n'
   fp.write(BtLNjxIyaodhKEkCJQAVRscSYMpmlb)
   BtLNjxIyaodhKEkCJQAVRscSYMpmlD=0
   for BtLNjxIyaodhKEkCJQAVRscSYMpmlg in BtLNjxIyaodhKEkCJQAVRscSYMpmei:
    BtLNjxIyaodhKEkCJQAVRscSYMpmlF=BtLNjxIyaodhKEkCJQAVRscSYMpmGH(urllib.parse.parse_qsl(BtLNjxIyaodhKEkCJQAVRscSYMpmlg))
    BtLNjxIyaodhKEkCJQAVRscSYMpmle=BtLNjxIyaodhKEkCJQAVRscSYMpmbn.get('code').strip()
    BtLNjxIyaodhKEkCJQAVRscSYMpmlf=BtLNjxIyaodhKEkCJQAVRscSYMpmlF.get('code').strip()
    if BtLNjxIyaodhKEkCJQAVRscSYMpmle!=BtLNjxIyaodhKEkCJQAVRscSYMpmlf:
     fp.write(BtLNjxIyaodhKEkCJQAVRscSYMpmlg)
     BtLNjxIyaodhKEkCJQAVRscSYMpmlD+=1
     if BtLNjxIyaodhKEkCJQAVRscSYMpmlD>=50:break
   fp.close()
  except:
   BtLNjxIyaodhKEkCJQAVRscSYMpmGf
 def Save_Searched_List(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,BtLNjxIyaodhKEkCJQAVRscSYMpmeu):
  try:
   BtLNjxIyaodhKEkCJQAVRscSYMpmeu=BtLNjxIyaodhKEkCJQAVRscSYMpmeu.strip()
   BtLNjxIyaodhKEkCJQAVRscSYMpmei=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.Load_List_File('search') 
   fp=BtLNjxIyaodhKEkCJQAVRscSYMpmGr(BtLNjxIyaodhKEkCJQAVRscSYMpmbl,'w',-1,'utf-8')
   fp.write(BtLNjxIyaodhKEkCJQAVRscSYMpmeu+'\n')
   BtLNjxIyaodhKEkCJQAVRscSYMpmlD=0
   for BtLNjxIyaodhKEkCJQAVRscSYMpmlg in BtLNjxIyaodhKEkCJQAVRscSYMpmei:
    BtLNjxIyaodhKEkCJQAVRscSYMpmlg=BtLNjxIyaodhKEkCJQAVRscSYMpmlg.strip()
    if BtLNjxIyaodhKEkCJQAVRscSYMpmeu!=BtLNjxIyaodhKEkCJQAVRscSYMpmlg:
     fp.write(BtLNjxIyaodhKEkCJQAVRscSYMpmlg+'\n')
     BtLNjxIyaodhKEkCJQAVRscSYMpmlD+=1
     if BtLNjxIyaodhKEkCJQAVRscSYMpmlD>=50:break
   fp.close()
  except:
   BtLNjxIyaodhKEkCJQAVRscSYMpmGf
 def dp_Search_History(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,args):
  BtLNjxIyaodhKEkCJQAVRscSYMpmlG=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.Load_List_File('search')
  for BtLNjxIyaodhKEkCJQAVRscSYMpmlW in BtLNjxIyaodhKEkCJQAVRscSYMpmlG:
   BtLNjxIyaodhKEkCJQAVRscSYMpmlW=BtLNjxIyaodhKEkCJQAVRscSYMpmlW.strip()
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU={'mode':'LOCAL_SEARCH','search_key':BtLNjxIyaodhKEkCJQAVRscSYMpmlW,'page':'1','historyyn':'Y',}
   BtLNjxIyaodhKEkCJQAVRscSYMpmln={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','skey':BtLNjxIyaodhKEkCJQAVRscSYMpmlW,'vType':'-',}
   BtLNjxIyaodhKEkCJQAVRscSYMpmlU=urllib.parse.urlencode(BtLNjxIyaodhKEkCJQAVRscSYMpmln)
   BtLNjxIyaodhKEkCJQAVRscSYMpmFg=[('선택된 검색어 ( %s ) 삭제'%(BtLNjxIyaodhKEkCJQAVRscSYMpmlW),'RunPlugin(plugin://plugin.video.coupangm/?%s)'%(BtLNjxIyaodhKEkCJQAVRscSYMpmlU))]
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.add_dir(BtLNjxIyaodhKEkCJQAVRscSYMpmlW,sublabel='',img=BtLNjxIyaodhKEkCJQAVRscSYMpmGf,infoLabels=BtLNjxIyaodhKEkCJQAVRscSYMpmGf,isFolder=BtLNjxIyaodhKEkCJQAVRscSYMpmGn,params=BtLNjxIyaodhKEkCJQAVRscSYMpmDU,ContextMenu=BtLNjxIyaodhKEkCJQAVRscSYMpmFg)
  BtLNjxIyaodhKEkCJQAVRscSYMpmgl={'plot':'검색목록 전체를 삭제합니다.'}
  BtLNjxIyaodhKEkCJQAVRscSYMpmDe='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  BtLNjxIyaodhKEkCJQAVRscSYMpmDU={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  BtLNjxIyaodhKEkCJQAVRscSYMpmDn=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  BtLNjxIyaodhKEkCJQAVRscSYMpmbf.add_dir(BtLNjxIyaodhKEkCJQAVRscSYMpmDe,sublabel='',img=BtLNjxIyaodhKEkCJQAVRscSYMpmDn,infoLabels=BtLNjxIyaodhKEkCJQAVRscSYMpmgl,isFolder=BtLNjxIyaodhKEkCJQAVRscSYMpmGW,params=BtLNjxIyaodhKEkCJQAVRscSYMpmDU,isLink=BtLNjxIyaodhKEkCJQAVRscSYMpmGn)
  xbmcplugin.endOfDirectory(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,cacheToDisc=BtLNjxIyaodhKEkCJQAVRscSYMpmGW)
 def dp_Listfile_Delete(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,args):
  BtLNjxIyaodhKEkCJQAVRscSYMpmlH=args.get('delType')
  BtLNjxIyaodhKEkCJQAVRscSYMpmlT =args.get('skey')
  BtLNjxIyaodhKEkCJQAVRscSYMpmgb =args.get('vType')
  BtLNjxIyaodhKEkCJQAVRscSYMpmbH=xbmcgui.Dialog()
  if BtLNjxIyaodhKEkCJQAVRscSYMpmlH=='SEARCH_ALL':
   BtLNjxIyaodhKEkCJQAVRscSYMpmDr=BtLNjxIyaodhKEkCJQAVRscSYMpmbH.yesno(__language__(30911).encode('utf8'),__language__(30906).encode('utf8'))
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmlH=='SEARCH_ONE':
   BtLNjxIyaodhKEkCJQAVRscSYMpmDr=BtLNjxIyaodhKEkCJQAVRscSYMpmbH.yesno(__language__(30912).encode('utf8'),__language__(30906).encode('utf8'))
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmlH=='WATCH_ALL':
   BtLNjxIyaodhKEkCJQAVRscSYMpmDr=BtLNjxIyaodhKEkCJQAVRscSYMpmbH.yesno(__language__(30913).encode('utf8'),__language__(30906).encode('utf8'))
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmlH=='WATCH_ONE':
   BtLNjxIyaodhKEkCJQAVRscSYMpmDr=BtLNjxIyaodhKEkCJQAVRscSYMpmbH.yesno(__language__(30916).encode('utf8'),__language__(30906).encode('utf8'))
  if BtLNjxIyaodhKEkCJQAVRscSYMpmDr==BtLNjxIyaodhKEkCJQAVRscSYMpmGW:sys.exit()
  if BtLNjxIyaodhKEkCJQAVRscSYMpmlH=='SEARCH_ALL':
   if os.path.isfile(BtLNjxIyaodhKEkCJQAVRscSYMpmbl):os.remove(BtLNjxIyaodhKEkCJQAVRscSYMpmbl)
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmlH=='SEARCH_ONE':
   try:
    BtLNjxIyaodhKEkCJQAVRscSYMpmeP=BtLNjxIyaodhKEkCJQAVRscSYMpmbl
    BtLNjxIyaodhKEkCJQAVRscSYMpmei=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.Load_List_File('search') 
    fp=BtLNjxIyaodhKEkCJQAVRscSYMpmGr(BtLNjxIyaodhKEkCJQAVRscSYMpmeP,'w',-1,'utf-8')
    for BtLNjxIyaodhKEkCJQAVRscSYMpmlg in BtLNjxIyaodhKEkCJQAVRscSYMpmei:
     if BtLNjxIyaodhKEkCJQAVRscSYMpmlT!=BtLNjxIyaodhKEkCJQAVRscSYMpmlg.strip():
      fp.write(BtLNjxIyaodhKEkCJQAVRscSYMpmlg)
    fp.close()
   except:
    BtLNjxIyaodhKEkCJQAVRscSYMpmGf
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmlH=='WATCH_ALL':
   BtLNjxIyaodhKEkCJQAVRscSYMpmeP=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%BtLNjxIyaodhKEkCJQAVRscSYMpmgb))
   if os.path.isfile(BtLNjxIyaodhKEkCJQAVRscSYMpmeP):os.remove(BtLNjxIyaodhKEkCJQAVRscSYMpmeP)
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmlH=='WATCH_ONE':
   BtLNjxIyaodhKEkCJQAVRscSYMpmeP=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%BtLNjxIyaodhKEkCJQAVRscSYMpmgb))
   try:
    BtLNjxIyaodhKEkCJQAVRscSYMpmei=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.Load_List_File(BtLNjxIyaodhKEkCJQAVRscSYMpmgb) 
    fp=BtLNjxIyaodhKEkCJQAVRscSYMpmGr(BtLNjxIyaodhKEkCJQAVRscSYMpmeP,'w',-1,'utf-8')
    for BtLNjxIyaodhKEkCJQAVRscSYMpmlg in BtLNjxIyaodhKEkCJQAVRscSYMpmei:
     BtLNjxIyaodhKEkCJQAVRscSYMpmlF=BtLNjxIyaodhKEkCJQAVRscSYMpmGH(urllib.parse.parse_qsl(BtLNjxIyaodhKEkCJQAVRscSYMpmlg))
     BtLNjxIyaodhKEkCJQAVRscSYMpmlz=BtLNjxIyaodhKEkCJQAVRscSYMpmlF.get('code').strip()
     if BtLNjxIyaodhKEkCJQAVRscSYMpmlT!=BtLNjxIyaodhKEkCJQAVRscSYMpmlz:
      fp.write(BtLNjxIyaodhKEkCJQAVRscSYMpmlg)
    fp.close()
   except:
    BtLNjxIyaodhKEkCJQAVRscSYMpmGf
  xbmc.executebuiltin("Container.Refresh")
 def Delete_List_File(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,BtLNjxIyaodhKEkCJQAVRscSYMpmeX,skey='-'):
  if BtLNjxIyaodhKEkCJQAVRscSYMpmeX=='ALL':
   try:
    BtLNjxIyaodhKEkCJQAVRscSYMpmeP=BtLNjxIyaodhKEkCJQAVRscSYMpmbl
    fp=BtLNjxIyaodhKEkCJQAVRscSYMpmGr(BtLNjxIyaodhKEkCJQAVRscSYMpmeP,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    BtLNjxIyaodhKEkCJQAVRscSYMpmGf
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmeX=='ONE':
   try:
    BtLNjxIyaodhKEkCJQAVRscSYMpmeP=BtLNjxIyaodhKEkCJQAVRscSYMpmbl
    BtLNjxIyaodhKEkCJQAVRscSYMpmei=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.Load_List_File('search') 
    fp=BtLNjxIyaodhKEkCJQAVRscSYMpmGr(BtLNjxIyaodhKEkCJQAVRscSYMpmeP,'w',-1,'utf-8')
    for BtLNjxIyaodhKEkCJQAVRscSYMpmlg in BtLNjxIyaodhKEkCJQAVRscSYMpmei:
     if skey!=BtLNjxIyaodhKEkCJQAVRscSYMpmlg.strip():
      fp.write(BtLNjxIyaodhKEkCJQAVRscSYMpmlg)
    fp.close()
   except:
    BtLNjxIyaodhKEkCJQAVRscSYMpmGf
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmeX in['tvshow','movie']:
   try:
    BtLNjxIyaodhKEkCJQAVRscSYMpmeP=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%BtLNjxIyaodhKEkCJQAVRscSYMpmeX))
    fp=BtLNjxIyaodhKEkCJQAVRscSYMpmGr(BtLNjxIyaodhKEkCJQAVRscSYMpmeP,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    BtLNjxIyaodhKEkCJQAVRscSYMpmGf
 def dp_Watch_List(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,args):
  BtLNjxIyaodhKEkCJQAVRscSYMpmeX =args.get('stype')
  if BtLNjxIyaodhKEkCJQAVRscSYMpmeX in['',BtLNjxIyaodhKEkCJQAVRscSYMpmGf]:
   for BtLNjxIyaodhKEkCJQAVRscSYMpmlX in BtLNjxIyaodhKEkCJQAVRscSYMpmbF:
    BtLNjxIyaodhKEkCJQAVRscSYMpmDe=BtLNjxIyaodhKEkCJQAVRscSYMpmlX.get('title')
    BtLNjxIyaodhKEkCJQAVRscSYMpmDU={'mode':BtLNjxIyaodhKEkCJQAVRscSYMpmlX.get('mode'),'stype':BtLNjxIyaodhKEkCJQAVRscSYMpmlX.get('stype'),}
    BtLNjxIyaodhKEkCJQAVRscSYMpmbf.add_dir(BtLNjxIyaodhKEkCJQAVRscSYMpmDe,sublabel='',img='',infoLabels=BtLNjxIyaodhKEkCJQAVRscSYMpmGf,isFolder=BtLNjxIyaodhKEkCJQAVRscSYMpmGn,params=BtLNjxIyaodhKEkCJQAVRscSYMpmDU)
   xbmcplugin.endOfDirectory(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle)
  else:
   BtLNjxIyaodhKEkCJQAVRscSYMpmlr=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.Load_List_File(BtLNjxIyaodhKEkCJQAVRscSYMpmeX)
   for BtLNjxIyaodhKEkCJQAVRscSYMpmlu in BtLNjxIyaodhKEkCJQAVRscSYMpmlr:
    BtLNjxIyaodhKEkCJQAVRscSYMpmlv=BtLNjxIyaodhKEkCJQAVRscSYMpmGH(urllib.parse.parse_qsl(BtLNjxIyaodhKEkCJQAVRscSYMpmlu))
    BtLNjxIyaodhKEkCJQAVRscSYMpmFw =BtLNjxIyaodhKEkCJQAVRscSYMpmlv.get('code').strip()
    BtLNjxIyaodhKEkCJQAVRscSYMpmDe =BtLNjxIyaodhKEkCJQAVRscSYMpmlv.get('title').strip()
    BtLNjxIyaodhKEkCJQAVRscSYMpmgW =BtLNjxIyaodhKEkCJQAVRscSYMpmlv.get('img').strip()
    BtLNjxIyaodhKEkCJQAVRscSYMpmgn =BtLNjxIyaodhKEkCJQAVRscSYMpmlv.get('asis').strip()
    try:
     BtLNjxIyaodhKEkCJQAVRscSYMpmgW=BtLNjxIyaodhKEkCJQAVRscSYMpmgW.replace('\'','\"')
     BtLNjxIyaodhKEkCJQAVRscSYMpmgW=json.loads(BtLNjxIyaodhKEkCJQAVRscSYMpmgW)
    except:
     BtLNjxIyaodhKEkCJQAVRscSYMpmGf
    BtLNjxIyaodhKEkCJQAVRscSYMpmgl={}
    BtLNjxIyaodhKEkCJQAVRscSYMpmgl['plot']=BtLNjxIyaodhKEkCJQAVRscSYMpmDe
    if BtLNjxIyaodhKEkCJQAVRscSYMpmeX=='movie':
     BtLNjxIyaodhKEkCJQAVRscSYMpmgl['mediatype']='movie'
     BtLNjxIyaodhKEkCJQAVRscSYMpmDU={'mode':'MOVIE','id':BtLNjxIyaodhKEkCJQAVRscSYMpmFw,'asis':BtLNjxIyaodhKEkCJQAVRscSYMpmgn,'title':BtLNjxIyaodhKEkCJQAVRscSYMpmDe,'thumbnail':BtLNjxIyaodhKEkCJQAVRscSYMpmgW,}
     BtLNjxIyaodhKEkCJQAVRscSYMpmDH=BtLNjxIyaodhKEkCJQAVRscSYMpmGW
    else:
     BtLNjxIyaodhKEkCJQAVRscSYMpmgl['mediatype']='episode'
     BtLNjxIyaodhKEkCJQAVRscSYMpmDU={'mode':'SEASON_LIST','id':BtLNjxIyaodhKEkCJQAVRscSYMpmFw,'asis':BtLNjxIyaodhKEkCJQAVRscSYMpmgn,'title':BtLNjxIyaodhKEkCJQAVRscSYMpmDe,'thumbnail':json.dumps(BtLNjxIyaodhKEkCJQAVRscSYMpmgW,separators=(',',':')),}
     BtLNjxIyaodhKEkCJQAVRscSYMpmDH=BtLNjxIyaodhKEkCJQAVRscSYMpmGn
    BtLNjxIyaodhKEkCJQAVRscSYMpmln={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','skey':BtLNjxIyaodhKEkCJQAVRscSYMpmFw,'vType':BtLNjxIyaodhKEkCJQAVRscSYMpmeX,}
    BtLNjxIyaodhKEkCJQAVRscSYMpmlU=urllib.parse.urlencode(BtLNjxIyaodhKEkCJQAVRscSYMpmln)
    BtLNjxIyaodhKEkCJQAVRscSYMpmFg=[('선택된 시청이력 ( %s ) 삭제'%(BtLNjxIyaodhKEkCJQAVRscSYMpmDe),'RunPlugin(plugin://plugin.video.coupangm/?%s)'%(BtLNjxIyaodhKEkCJQAVRscSYMpmlU))]
    BtLNjxIyaodhKEkCJQAVRscSYMpmbf.add_dir(BtLNjxIyaodhKEkCJQAVRscSYMpmDe,sublabel='',img=BtLNjxIyaodhKEkCJQAVRscSYMpmgW,infoLabels=BtLNjxIyaodhKEkCJQAVRscSYMpmgl,isFolder=BtLNjxIyaodhKEkCJQAVRscSYMpmDH,params=BtLNjxIyaodhKEkCJQAVRscSYMpmDU,ContextMenu=BtLNjxIyaodhKEkCJQAVRscSYMpmFg)
   BtLNjxIyaodhKEkCJQAVRscSYMpmgl={'plot':'시청목록을 삭제합니다.'}
   BtLNjxIyaodhKEkCJQAVRscSYMpmDe='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':BtLNjxIyaodhKEkCJQAVRscSYMpmeX,}
   BtLNjxIyaodhKEkCJQAVRscSYMpmDn=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.add_dir(BtLNjxIyaodhKEkCJQAVRscSYMpmDe,sublabel='',img=BtLNjxIyaodhKEkCJQAVRscSYMpmDn,infoLabels=BtLNjxIyaodhKEkCJQAVRscSYMpmgl,isFolder=BtLNjxIyaodhKEkCJQAVRscSYMpmGW,params=BtLNjxIyaodhKEkCJQAVRscSYMpmDU,isLink=BtLNjxIyaodhKEkCJQAVRscSYMpmGn)
   if BtLNjxIyaodhKEkCJQAVRscSYMpmeX=='movie':xbmcplugin.setContent(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,'movies')
   else:xbmcplugin.setContent(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,cacheToDisc=BtLNjxIyaodhKEkCJQAVRscSYMpmGW)
 def dp_Set_Bookmark(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,args):
  BtLNjxIyaodhKEkCJQAVRscSYMpmlw=urllib.parse.unquote(args.get('bm_param'))
  BtLNjxIyaodhKEkCJQAVRscSYMpmlw=json.loads(BtLNjxIyaodhKEkCJQAVRscSYMpmlw)
  BtLNjxIyaodhKEkCJQAVRscSYMpmlP =BtLNjxIyaodhKEkCJQAVRscSYMpmlw.get('videoid')
  BtLNjxIyaodhKEkCJQAVRscSYMpmlq =BtLNjxIyaodhKEkCJQAVRscSYMpmlw.get('vidtype')
  BtLNjxIyaodhKEkCJQAVRscSYMpmlO =BtLNjxIyaodhKEkCJQAVRscSYMpmlw.get('vtitle')
  BtLNjxIyaodhKEkCJQAVRscSYMpmbH=xbmcgui.Dialog()
  BtLNjxIyaodhKEkCJQAVRscSYMpmDr=BtLNjxIyaodhKEkCJQAVRscSYMpmbH.yesno(__language__(30914).encode('utf8'),BtLNjxIyaodhKEkCJQAVRscSYMpmlO+' \n\n'+__language__(30915))
  if BtLNjxIyaodhKEkCJQAVRscSYMpmDr==BtLNjxIyaodhKEkCJQAVRscSYMpmGW:return
  BtLNjxIyaodhKEkCJQAVRscSYMpmli=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.GetBookmarkInfo(BtLNjxIyaodhKEkCJQAVRscSYMpmlP,BtLNjxIyaodhKEkCJQAVRscSYMpmlq)
  BtLNjxIyaodhKEkCJQAVRscSYMpmfb=json.dumps(BtLNjxIyaodhKEkCJQAVRscSYMpmli)
  BtLNjxIyaodhKEkCJQAVRscSYMpmfb=urllib.parse.quote(BtLNjxIyaodhKEkCJQAVRscSYMpmfb)
  BtLNjxIyaodhKEkCJQAVRscSYMpmFD ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(BtLNjxIyaodhKEkCJQAVRscSYMpmfb)
  xbmc.executebuiltin(BtLNjxIyaodhKEkCJQAVRscSYMpmFD)
 def sp_MultiHero_LiveList(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,args):
  BtLNjxIyaodhKEkCJQAVRscSYMpmfD=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.Sports_MultiHero_LiveList()
  for BtLNjxIyaodhKEkCJQAVRscSYMpmfg in BtLNjxIyaodhKEkCJQAVRscSYMpmfD:
   BtLNjxIyaodhKEkCJQAVRscSYMpmGw =BtLNjxIyaodhKEkCJQAVRscSYMpmfg.get('id')
   BtLNjxIyaodhKEkCJQAVRscSYMpmDe =BtLNjxIyaodhKEkCJQAVRscSYMpmfg.get('title')
   BtLNjxIyaodhKEkCJQAVRscSYMpmfF =BtLNjxIyaodhKEkCJQAVRscSYMpmfg.get('startDate')
   BtLNjxIyaodhKEkCJQAVRscSYMpmfe =BtLNjxIyaodhKEkCJQAVRscSYMpmfg.get('image')
   BtLNjxIyaodhKEkCJQAVRscSYMpmfl =BtLNjxIyaodhKEkCJQAVRscSYMpmfg.get('subType') 
   BtLNjxIyaodhKEkCJQAVRscSYMpmDX=BtLNjxIyaodhKEkCJQAVRscSYMpmfF
   if BtLNjxIyaodhKEkCJQAVRscSYMpmfl:BtLNjxIyaodhKEkCJQAVRscSYMpmDX=BtLNjxIyaodhKEkCJQAVRscSYMpmDX+', '+BtLNjxIyaodhKEkCJQAVRscSYMpmfl
   BtLNjxIyaodhKEkCJQAVRscSYMpmgl={'mediatype':'episodes','plot':BtLNjxIyaodhKEkCJQAVRscSYMpmDe,}
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU={'mode':'LIVE','asis':'LIVE','id':BtLNjxIyaodhKEkCJQAVRscSYMpmGw,}
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.add_dir(BtLNjxIyaodhKEkCJQAVRscSYMpmDe,sublabel=BtLNjxIyaodhKEkCJQAVRscSYMpmDX,img=BtLNjxIyaodhKEkCJQAVRscSYMpmfe,infoLabels=BtLNjxIyaodhKEkCJQAVRscSYMpmgl,isFolder=BtLNjxIyaodhKEkCJQAVRscSYMpmGW,params=BtLNjxIyaodhKEkCJQAVRscSYMpmDU)
  xbmcplugin.setContent(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,cacheToDisc=BtLNjxIyaodhKEkCJQAVRscSYMpmGW)
 def sp_Mainlist_League(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,args):
  BtLNjxIyaodhKEkCJQAVRscSYMpmfD=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.Sports_MultiHero_LiveList()
  if BtLNjxIyaodhKEkCJQAVRscSYMpmfD:
   BtLNjxIyaodhKEkCJQAVRscSYMpmDe ='@ 주요 예정경기 @'
   BtLNjxIyaodhKEkCJQAVRscSYMpmfe =BtLNjxIyaodhKEkCJQAVRscSYMpmfD[0]['image']
   BtLNjxIyaodhKEkCJQAVRscSYMpmfG =BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.MakeText_FreeList(BtLNjxIyaodhKEkCJQAVRscSYMpmfD,titleName='preTitle')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgl={'mediatype':'episodes','plot':BtLNjxIyaodhKEkCJQAVRscSYMpmfG,}
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU={'mode':'SPORTS_MULT_HERO',}
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.add_dir(BtLNjxIyaodhKEkCJQAVRscSYMpmDe,sublabel='',img=BtLNjxIyaodhKEkCJQAVRscSYMpmfe,infoLabels=BtLNjxIyaodhKEkCJQAVRscSYMpmgl,isFolder=BtLNjxIyaodhKEkCJQAVRscSYMpmGn,params=BtLNjxIyaodhKEkCJQAVRscSYMpmDU)
  BtLNjxIyaodhKEkCJQAVRscSYMpmfW=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.Sports_Mainlist_League()
  for BtLNjxIyaodhKEkCJQAVRscSYMpmfn in BtLNjxIyaodhKEkCJQAVRscSYMpmfW:
   BtLNjxIyaodhKEkCJQAVRscSYMpmfU =BtLNjxIyaodhKEkCJQAVRscSYMpmfn.get('league_id') 
   BtLNjxIyaodhKEkCJQAVRscSYMpmfH=BtLNjxIyaodhKEkCJQAVRscSYMpmfn.get('league_name')
   BtLNjxIyaodhKEkCJQAVRscSYMpmfT =BtLNjxIyaodhKEkCJQAVRscSYMpmfn.get('logoUrl')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgl={'mediatype':'episodes','plot':BtLNjxIyaodhKEkCJQAVRscSYMpmfH,}
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU={'mode':'SPORTS_LEAGUE_FEEDLIST','league_id':BtLNjxIyaodhKEkCJQAVRscSYMpmfU,'league_name':BtLNjxIyaodhKEkCJQAVRscSYMpmfH,}
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.add_dir(BtLNjxIyaodhKEkCJQAVRscSYMpmfH,sublabel='',img=BtLNjxIyaodhKEkCJQAVRscSYMpmfT,infoLabels=BtLNjxIyaodhKEkCJQAVRscSYMpmgl,isFolder=BtLNjxIyaodhKEkCJQAVRscSYMpmGn,params=BtLNjxIyaodhKEkCJQAVRscSYMpmDU)
  xbmcplugin.setContent(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,cacheToDisc=BtLNjxIyaodhKEkCJQAVRscSYMpmGW)
 def sp_League_FeedList(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,args):
  BtLNjxIyaodhKEkCJQAVRscSYMpmfU =args.get('league_id')
  BtLNjxIyaodhKEkCJQAVRscSYMpmfH=args.get('league_name')
  BtLNjxIyaodhKEkCJQAVRscSYMpmfz=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.Sports_League_FeedList(BtLNjxIyaodhKEkCJQAVRscSYMpmfU)
  for BtLNjxIyaodhKEkCJQAVRscSYMpmfn in BtLNjxIyaodhKEkCJQAVRscSYMpmfz:
   BtLNjxIyaodhKEkCJQAVRscSYMpmfX=BtLNjxIyaodhKEkCJQAVRscSYMpmfn.get('row_name')
   BtLNjxIyaodhKEkCJQAVRscSYMpmfG =BtLNjxIyaodhKEkCJQAVRscSYMpmfn.get('preText')
   BtLNjxIyaodhKEkCJQAVRscSYMpmfr =BtLNjxIyaodhKEkCJQAVRscSYMpmfn.get('subMode')
   BtLNjxIyaodhKEkCJQAVRscSYMpmfu =BtLNjxIyaodhKEkCJQAVRscSYMpmfn.get('gameID')
   BtLNjxIyaodhKEkCJQAVRscSYMpmfe =BtLNjxIyaodhKEkCJQAVRscSYMpmfn.get('image')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgl={'mediatype':'episodes','plot':BtLNjxIyaodhKEkCJQAVRscSYMpmfH+'\n\n'+BtLNjxIyaodhKEkCJQAVRscSYMpmfG,}
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU={'mode':'SPORTS_FEED_VOD','subMode':BtLNjxIyaodhKEkCJQAVRscSYMpmfr,'league_id':BtLNjxIyaodhKEkCJQAVRscSYMpmfU,'game_id':BtLNjxIyaodhKEkCJQAVRscSYMpmfu,}
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.add_dir(BtLNjxIyaodhKEkCJQAVRscSYMpmfX,sublabel='',img=BtLNjxIyaodhKEkCJQAVRscSYMpmfe,infoLabels=BtLNjxIyaodhKEkCJQAVRscSYMpmgl,isFolder=BtLNjxIyaodhKEkCJQAVRscSYMpmGn,params=BtLNjxIyaodhKEkCJQAVRscSYMpmDU)
  BtLNjxIyaodhKEkCJQAVRscSYMpmDe='@ 시즌별 동영상 @'
  BtLNjxIyaodhKEkCJQAVRscSYMpmgl={'mediatype':'episodes','plot':BtLNjxIyaodhKEkCJQAVRscSYMpmDe,}
  BtLNjxIyaodhKEkCJQAVRscSYMpmDU={'mode':'SPORTS_SEASON_GROUP','league_id':BtLNjxIyaodhKEkCJQAVRscSYMpmfU,}
  BtLNjxIyaodhKEkCJQAVRscSYMpmbf.add_dir(BtLNjxIyaodhKEkCJQAVRscSYMpmDe,sublabel='',img=BtLNjxIyaodhKEkCJQAVRscSYMpmGf,infoLabels=BtLNjxIyaodhKEkCJQAVRscSYMpmgl,isFolder=BtLNjxIyaodhKEkCJQAVRscSYMpmGn,params=BtLNjxIyaodhKEkCJQAVRscSYMpmDU)
  xbmcplugin.setContent(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,cacheToDisc=BtLNjxIyaodhKEkCJQAVRscSYMpmGW)
 def sp_League_VodList(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,args):
  BtLNjxIyaodhKEkCJQAVRscSYMpmfr =args.get('subMode')
  BtLNjxIyaodhKEkCJQAVRscSYMpmfU =args.get('league_id')
  BtLNjxIyaodhKEkCJQAVRscSYMpmfv =args.get('game_id')
  BtLNjxIyaodhKEkCJQAVRscSYMpmbf.addon_log('{} - {}'.format('subMode  ',BtLNjxIyaodhKEkCJQAVRscSYMpmfr))
  BtLNjxIyaodhKEkCJQAVRscSYMpmbf.addon_log('{} - {}'.format('league_id',BtLNjxIyaodhKEkCJQAVRscSYMpmfU))
  BtLNjxIyaodhKEkCJQAVRscSYMpmbf.addon_log('{} - {}'.format('game_id  ',BtLNjxIyaodhKEkCJQAVRscSYMpmfv))
  BtLNjxIyaodhKEkCJQAVRscSYMpmfw=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.Sports_League_VodList(BtLNjxIyaodhKEkCJQAVRscSYMpmfr,BtLNjxIyaodhKEkCJQAVRscSYMpmfU,BtLNjxIyaodhKEkCJQAVRscSYMpmfv)
  for BtLNjxIyaodhKEkCJQAVRscSYMpmfn in BtLNjxIyaodhKEkCJQAVRscSYMpmfw:
   BtLNjxIyaodhKEkCJQAVRscSYMpmGw =BtLNjxIyaodhKEkCJQAVRscSYMpmfn.get('id')
   BtLNjxIyaodhKEkCJQAVRscSYMpmDe =BtLNjxIyaodhKEkCJQAVRscSYMpmfn.get('title')
   BtLNjxIyaodhKEkCJQAVRscSYMpmfe =BtLNjxIyaodhKEkCJQAVRscSYMpmfn.get('image')
   BtLNjxIyaodhKEkCJQAVRscSYMpmfF =BtLNjxIyaodhKEkCJQAVRscSYMpmfn.get('startDate')
   BtLNjxIyaodhKEkCJQAVRscSYMpmfl =BtLNjxIyaodhKEkCJQAVRscSYMpmfn.get('subType')
   BtLNjxIyaodhKEkCJQAVRscSYMpmfP=BtLNjxIyaodhKEkCJQAVRscSYMpmfn.get('running_time')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgl={'mediatype':'episodes','plot':BtLNjxIyaodhKEkCJQAVRscSYMpmDe,'duration':BtLNjxIyaodhKEkCJQAVRscSYMpmfP,}
   if BtLNjxIyaodhKEkCJQAVRscSYMpmfr=='SP_FEED_LIVE':
    BtLNjxIyaodhKEkCJQAVRscSYMpmDU={'mode':'LIVE','asis':'LIVE','id':BtLNjxIyaodhKEkCJQAVRscSYMpmGw,}
    BtLNjxIyaodhKEkCJQAVRscSYMpmDX=BtLNjxIyaodhKEkCJQAVRscSYMpmfF
    if BtLNjxIyaodhKEkCJQAVRscSYMpmfl:BtLNjxIyaodhKEkCJQAVRscSYMpmDX=BtLNjxIyaodhKEkCJQAVRscSYMpmDX+', '+BtLNjxIyaodhKEkCJQAVRscSYMpmfl
   elif BtLNjxIyaodhKEkCJQAVRscSYMpmfr in['SP_FEED_TOP10','SP_FEED_GAME']:
    BtLNjxIyaodhKEkCJQAVRscSYMpmDU={'mode':'HIGHLIGHT','asis':'HIGHLIGHT','id':BtLNjxIyaodhKEkCJQAVRscSYMpmGw,}
    BtLNjxIyaodhKEkCJQAVRscSYMpmDX=BtLNjxIyaodhKEkCJQAVRscSYMpmfl
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.add_dir(BtLNjxIyaodhKEkCJQAVRscSYMpmDe,sublabel=BtLNjxIyaodhKEkCJQAVRscSYMpmDX,img=BtLNjxIyaodhKEkCJQAVRscSYMpmfe,infoLabels=BtLNjxIyaodhKEkCJQAVRscSYMpmgl,isFolder=BtLNjxIyaodhKEkCJQAVRscSYMpmGW,params=BtLNjxIyaodhKEkCJQAVRscSYMpmDU)
  xbmcplugin.setContent(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,cacheToDisc=BtLNjxIyaodhKEkCJQAVRscSYMpmGW)
 def sp_Season_Group(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,args):
  BtLNjxIyaodhKEkCJQAVRscSYMpmfU =args.get('league_id')
  BtLNjxIyaodhKEkCJQAVRscSYMpmfq=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.Sports_Season_Group(BtLNjxIyaodhKEkCJQAVRscSYMpmfU)
  for BtLNjxIyaodhKEkCJQAVRscSYMpmfn in BtLNjxIyaodhKEkCJQAVRscSYMpmfq:
   BtLNjxIyaodhKEkCJQAVRscSYMpmFU =BtLNjxIyaodhKEkCJQAVRscSYMpmfn.get('season')
   BtLNjxIyaodhKEkCJQAVRscSYMpmfG =BtLNjxIyaodhKEkCJQAVRscSYMpmfn.get('preText')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgl={'mediatype':'episodes','plot':BtLNjxIyaodhKEkCJQAVRscSYMpmfG,}
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU={'mode':'SPORTS_SEASON_GAMELIST','leagueID':BtLNjxIyaodhKEkCJQAVRscSYMpmfU,'seasonID':BtLNjxIyaodhKEkCJQAVRscSYMpmFU,'page':'1',}
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.add_dir(BtLNjxIyaodhKEkCJQAVRscSYMpmFU,sublabel=BtLNjxIyaodhKEkCJQAVRscSYMpmGf,img=BtLNjxIyaodhKEkCJQAVRscSYMpmGf,infoLabels=BtLNjxIyaodhKEkCJQAVRscSYMpmgl,isFolder=BtLNjxIyaodhKEkCJQAVRscSYMpmGn,params=BtLNjxIyaodhKEkCJQAVRscSYMpmDU)
  xbmcplugin.setContent(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,cacheToDisc=BtLNjxIyaodhKEkCJQAVRscSYMpmGW)
 def sp_Season_GameList(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,args):
  BtLNjxIyaodhKEkCJQAVRscSYMpmfO =args.get('leagueID')
  BtLNjxIyaodhKEkCJQAVRscSYMpmfi =args.get('seasonID')
  BtLNjxIyaodhKEkCJQAVRscSYMpmgX =BtLNjxIyaodhKEkCJQAVRscSYMpmGz(args.get('page'))
  BtLNjxIyaodhKEkCJQAVRscSYMpmGb=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.Sports_Season_GameList(BtLNjxIyaodhKEkCJQAVRscSYMpmfO,BtLNjxIyaodhKEkCJQAVRscSYMpmfi,BtLNjxIyaodhKEkCJQAVRscSYMpmgX)
  BtLNjxIyaodhKEkCJQAVRscSYMpmGD=BtLNjxIyaodhKEkCJQAVRscSYMpmGP(BtLNjxIyaodhKEkCJQAVRscSYMpmGb)
  for BtLNjxIyaodhKEkCJQAVRscSYMpmfn in BtLNjxIyaodhKEkCJQAVRscSYMpmGb:
   BtLNjxIyaodhKEkCJQAVRscSYMpmfu =BtLNjxIyaodhKEkCJQAVRscSYMpmfn.get('id')
   BtLNjxIyaodhKEkCJQAVRscSYMpmDe =BtLNjxIyaodhKEkCJQAVRscSYMpmfn.get('title')
   BtLNjxIyaodhKEkCJQAVRscSYMpmfF =BtLNjxIyaodhKEkCJQAVRscSYMpmfn.get('startDate')
   BtLNjxIyaodhKEkCJQAVRscSYMpmfG =BtLNjxIyaodhKEkCJQAVRscSYMpmfn.get('preText')
   BtLNjxIyaodhKEkCJQAVRscSYMpmfe =BtLNjxIyaodhKEkCJQAVRscSYMpmfn.get('image')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgl={'mediatype':'episodes','plot':BtLNjxIyaodhKEkCJQAVRscSYMpmfG,}
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU={'mode':'SPORTS_SEASON_VODLIST','leagueID':BtLNjxIyaodhKEkCJQAVRscSYMpmfO,'seasonID':BtLNjxIyaodhKEkCJQAVRscSYMpmfi,'gameID':BtLNjxIyaodhKEkCJQAVRscSYMpmfu,'page':args.get('page'),}
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.add_dir(BtLNjxIyaodhKEkCJQAVRscSYMpmDe,sublabel=BtLNjxIyaodhKEkCJQAVRscSYMpmfF,img=BtLNjxIyaodhKEkCJQAVRscSYMpmfe,infoLabels=BtLNjxIyaodhKEkCJQAVRscSYMpmgl,isFolder=BtLNjxIyaodhKEkCJQAVRscSYMpmGn,params=BtLNjxIyaodhKEkCJQAVRscSYMpmDU)
  if BtLNjxIyaodhKEkCJQAVRscSYMpmGD>=10:
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU['mode'] ='SPORTS_SEASON_GAMELIST' 
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU['leagueID']=BtLNjxIyaodhKEkCJQAVRscSYMpmfO
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU['seasonID']=BtLNjxIyaodhKEkCJQAVRscSYMpmfi
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU['page'] =BtLNjxIyaodhKEkCJQAVRscSYMpmGv(BtLNjxIyaodhKEkCJQAVRscSYMpmgX+1)
   BtLNjxIyaodhKEkCJQAVRscSYMpmDe='[B]%s >>[/B]'%'다음 페이지'
   BtLNjxIyaodhKEkCJQAVRscSYMpmFe=BtLNjxIyaodhKEkCJQAVRscSYMpmGv(BtLNjxIyaodhKEkCJQAVRscSYMpmgX+1)
   BtLNjxIyaodhKEkCJQAVRscSYMpmDn=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.add_dir(BtLNjxIyaodhKEkCJQAVRscSYMpmDe,sublabel=BtLNjxIyaodhKEkCJQAVRscSYMpmFe,img=BtLNjxIyaodhKEkCJQAVRscSYMpmDn,infoLabels=BtLNjxIyaodhKEkCJQAVRscSYMpmGf,isFolder=BtLNjxIyaodhKEkCJQAVRscSYMpmGn,params=BtLNjxIyaodhKEkCJQAVRscSYMpmDU)
  xbmcplugin.setContent(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,cacheToDisc=BtLNjxIyaodhKEkCJQAVRscSYMpmGW)
 def sp_Season_VodList(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,args):
  BtLNjxIyaodhKEkCJQAVRscSYMpmfO =args.get('leagueID')
  BtLNjxIyaodhKEkCJQAVRscSYMpmfi =args.get('seasonID')
  BtLNjxIyaodhKEkCJQAVRscSYMpmgX =BtLNjxIyaodhKEkCJQAVRscSYMpmGz(args.get('page'))
  BtLNjxIyaodhKEkCJQAVRscSYMpmfu =args.get('gameID')
  BtLNjxIyaodhKEkCJQAVRscSYMpmfw=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.Sports_Season_GameVod(BtLNjxIyaodhKEkCJQAVRscSYMpmfO,BtLNjxIyaodhKEkCJQAVRscSYMpmfi,BtLNjxIyaodhKEkCJQAVRscSYMpmgX,BtLNjxIyaodhKEkCJQAVRscSYMpmfu)
  for BtLNjxIyaodhKEkCJQAVRscSYMpmfn in BtLNjxIyaodhKEkCJQAVRscSYMpmfw:
   BtLNjxIyaodhKEkCJQAVRscSYMpmGw =BtLNjxIyaodhKEkCJQAVRscSYMpmfn.get('id')
   BtLNjxIyaodhKEkCJQAVRscSYMpmDe =BtLNjxIyaodhKEkCJQAVRscSYMpmfn.get('title')
   BtLNjxIyaodhKEkCJQAVRscSYMpmfe =BtLNjxIyaodhKEkCJQAVRscSYMpmfn.get('image')
   BtLNjxIyaodhKEkCJQAVRscSYMpmfl =BtLNjxIyaodhKEkCJQAVRscSYMpmfn.get('subType')
   BtLNjxIyaodhKEkCJQAVRscSYMpmfP=BtLNjxIyaodhKEkCJQAVRscSYMpmfn.get('running_time')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgl={'mediatype':'episodes','plot':BtLNjxIyaodhKEkCJQAVRscSYMpmDe,'duration':BtLNjxIyaodhKEkCJQAVRscSYMpmfP,}
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU={'mode':'HIGHLIGHT','asis':'HIGHLIGHT','id':BtLNjxIyaodhKEkCJQAVRscSYMpmGw,}
   BtLNjxIyaodhKEkCJQAVRscSYMpmDX=BtLNjxIyaodhKEkCJQAVRscSYMpmfl
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.add_dir(BtLNjxIyaodhKEkCJQAVRscSYMpmDe,sublabel=BtLNjxIyaodhKEkCJQAVRscSYMpmDX,img=BtLNjxIyaodhKEkCJQAVRscSYMpmfe,infoLabels=BtLNjxIyaodhKEkCJQAVRscSYMpmgl,isFolder=BtLNjxIyaodhKEkCJQAVRscSYMpmGW,params=BtLNjxIyaodhKEkCJQAVRscSYMpmDU)
  xbmcplugin.setContent(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,cacheToDisc=BtLNjxIyaodhKEkCJQAVRscSYMpmGW)
 def dp_Pass_Group(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,args):
  BtLNjxIyaodhKEkCJQAVRscSYMpmgG =args.get('collectionId')
  BtLNjxIyaodhKEkCJQAVRscSYMpmGg=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.Get_Pass_GroupList(BtLNjxIyaodhKEkCJQAVRscSYMpmgG)
  for BtLNjxIyaodhKEkCJQAVRscSYMpmfn in BtLNjxIyaodhKEkCJQAVRscSYMpmGg:
   BtLNjxIyaodhKEkCJQAVRscSYMpmGF =BtLNjxIyaodhKEkCJQAVRscSYMpmfn.get('obj_id')
   BtLNjxIyaodhKEkCJQAVRscSYMpmDe =BtLNjxIyaodhKEkCJQAVRscSYMpmfn.get('title')
   BtLNjxIyaodhKEkCJQAVRscSYMpmfG =BtLNjxIyaodhKEkCJQAVRscSYMpmfn.get('preText')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgl={'mediatype':'episodes','plot':BtLNjxIyaodhKEkCJQAVRscSYMpmfG,}
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU={'mode':'PASS_VOD_LIST','collectionId':BtLNjxIyaodhKEkCJQAVRscSYMpmgG,'obj_id':BtLNjxIyaodhKEkCJQAVRscSYMpmGF,}
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.add_dir(BtLNjxIyaodhKEkCJQAVRscSYMpmDe,sublabel=BtLNjxIyaodhKEkCJQAVRscSYMpmGf,img=BtLNjxIyaodhKEkCJQAVRscSYMpmGf,infoLabels=BtLNjxIyaodhKEkCJQAVRscSYMpmgl,isFolder=BtLNjxIyaodhKEkCJQAVRscSYMpmGn,params=BtLNjxIyaodhKEkCJQAVRscSYMpmDU)
  xbmcplugin.setContent(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,cacheToDisc=BtLNjxIyaodhKEkCJQAVRscSYMpmGW)
 def dp_Pass_VodList(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,args):
  BtLNjxIyaodhKEkCJQAVRscSYMpmgG =args.get('collectionId')
  BtLNjxIyaodhKEkCJQAVRscSYMpmGF =args.get('obj_id')
  BtLNjxIyaodhKEkCJQAVRscSYMpmgD=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.Get_Pass_VodList(BtLNjxIyaodhKEkCJQAVRscSYMpmgG,BtLNjxIyaodhKEkCJQAVRscSYMpmGF)
  for BtLNjxIyaodhKEkCJQAVRscSYMpmgF in BtLNjxIyaodhKEkCJQAVRscSYMpmgD:
   BtLNjxIyaodhKEkCJQAVRscSYMpmDe =BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('title')
   BtLNjxIyaodhKEkCJQAVRscSYMpmGw =BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('id')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgW =BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('thumbnail')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgu =BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('mpaa')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgz =BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('duration')
   BtLNjxIyaodhKEkCJQAVRscSYMpmGe =BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('sub_type')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgv =BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('badge')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgw =BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('year')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgP=BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('seasonList')
   BtLNjxIyaodhKEkCJQAVRscSYMpmgq =BtLNjxIyaodhKEkCJQAVRscSYMpmgF.get('genreList')
   if BtLNjxIyaodhKEkCJQAVRscSYMpmGe in['TVSHOW']: 
    BtLNjxIyaodhKEkCJQAVRscSYMpmgO ='SEASON_LIST'
    BtLNjxIyaodhKEkCJQAVRscSYMpmgl={'mediatype':'tvshow','title':BtLNjxIyaodhKEkCJQAVRscSYMpmDe,'mpaa':BtLNjxIyaodhKEkCJQAVRscSYMpmgu,'genre':BtLNjxIyaodhKEkCJQAVRscSYMpmgq,'year':BtLNjxIyaodhKEkCJQAVRscSYMpmgw,'plot':'Year : %s\nSeason : %s'%(BtLNjxIyaodhKEkCJQAVRscSYMpmgw,BtLNjxIyaodhKEkCJQAVRscSYMpmgP),}
    BtLNjxIyaodhKEkCJQAVRscSYMpmDH =BtLNjxIyaodhKEkCJQAVRscSYMpmGn
   else:
    BtLNjxIyaodhKEkCJQAVRscSYMpmgO ='MOVIE'
    BtLNjxIyaodhKEkCJQAVRscSYMpmgl={'mediatype':'movie','title':BtLNjxIyaodhKEkCJQAVRscSYMpmDe,'mpaa':BtLNjxIyaodhKEkCJQAVRscSYMpmgu,'genre':BtLNjxIyaodhKEkCJQAVRscSYMpmgq,'duration':BtLNjxIyaodhKEkCJQAVRscSYMpmgz,'year':BtLNjxIyaodhKEkCJQAVRscSYMpmgw,'plot':'(%s)'%(BtLNjxIyaodhKEkCJQAVRscSYMpmgu),}
    BtLNjxIyaodhKEkCJQAVRscSYMpmDH =BtLNjxIyaodhKEkCJQAVRscSYMpmGW
    BtLNjxIyaodhKEkCJQAVRscSYMpmDe +=' (%s)'%(BtLNjxIyaodhKEkCJQAVRscSYMpmGv(BtLNjxIyaodhKEkCJQAVRscSYMpmgw))
   BtLNjxIyaodhKEkCJQAVRscSYMpmDU={'mode':BtLNjxIyaodhKEkCJQAVRscSYMpmgO,'id':BtLNjxIyaodhKEkCJQAVRscSYMpmGw,'asis':BtLNjxIyaodhKEkCJQAVRscSYMpmGe,'seasonList':BtLNjxIyaodhKEkCJQAVRscSYMpmgP,'title':BtLNjxIyaodhKEkCJQAVRscSYMpmDe,'thumbnail':BtLNjxIyaodhKEkCJQAVRscSYMpmgW,'year':BtLNjxIyaodhKEkCJQAVRscSYMpmgw,}
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.add_dir(BtLNjxIyaodhKEkCJQAVRscSYMpmDe,sublabel=BtLNjxIyaodhKEkCJQAVRscSYMpmgv,img=BtLNjxIyaodhKEkCJQAVRscSYMpmgW,infoLabels=BtLNjxIyaodhKEkCJQAVRscSYMpmgl,isFolder=BtLNjxIyaodhKEkCJQAVRscSYMpmDH,params=BtLNjxIyaodhKEkCJQAVRscSYMpmDU,ContextMenu=BtLNjxIyaodhKEkCJQAVRscSYMpmGf)
  xbmcplugin.setContent(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(BtLNjxIyaodhKEkCJQAVRscSYMpmbf._addon_handle,cacheToDisc=BtLNjxIyaodhKEkCJQAVRscSYMpmGW)
 def dp_setEpOrderby(BtLNjxIyaodhKEkCJQAVRscSYMpmbf,args):
  BtLNjxIyaodhKEkCJQAVRscSYMpmDg =args.get('orderby')
  BtLNjxIyaodhKEkCJQAVRscSYMpmbf.set_winEpisodeOrderby(BtLNjxIyaodhKEkCJQAVRscSYMpmDg)
  xbmc.executebuiltin("Container.Refresh")
 def coupang_main(BtLNjxIyaodhKEkCJQAVRscSYMpmbf):
  BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CoupangObj.KodiVersion=BtLNjxIyaodhKEkCJQAVRscSYMpmGz(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  BtLNjxIyaodhKEkCJQAVRscSYMpmgO=BtLNjxIyaodhKEkCJQAVRscSYMpmbf.main_params.get('mode',BtLNjxIyaodhKEkCJQAVRscSYMpmGf)
  if BtLNjxIyaodhKEkCJQAVRscSYMpmgO=='LOGOUT':
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.CP_logout()
   return
  BtLNjxIyaodhKEkCJQAVRscSYMpmbf.option_check()
  if BtLNjxIyaodhKEkCJQAVRscSYMpmgO is BtLNjxIyaodhKEkCJQAVRscSYMpmGf:
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.dp_Main_List(BtLNjxIyaodhKEkCJQAVRscSYMpmbf.main_params)
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmgO=='CATEGORY_GROUPLIST':
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.dp_Category_GroupList(BtLNjxIyaodhKEkCJQAVRscSYMpmbf.main_params)
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmgO=='THEME_GROUPLIST':
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.dp_Theme_GroupList(BtLNjxIyaodhKEkCJQAVRscSYMpmbf.main_params)
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmgO=='EVENT_GROUPLIST':
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.dp_Event_GroupList(BtLNjxIyaodhKEkCJQAVRscSYMpmbf.main_params)
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmgO=='EVENT_GAMELIST':
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.dp_Event_GameList(BtLNjxIyaodhKEkCJQAVRscSYMpmbf.main_params)
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmgO=='EVENT_LIST':
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.dp_Event_List(BtLNjxIyaodhKEkCJQAVRscSYMpmbf.main_params)
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmgO=='CATEGORY_LIST':
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.dp_Category_List(BtLNjxIyaodhKEkCJQAVRscSYMpmbf.main_params)
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmgO=='SEASON_LIST':
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.dp_Season_List(BtLNjxIyaodhKEkCJQAVRscSYMpmbf.main_params)
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmgO=='EPISODE_LIST':
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.dp_Episode_List(BtLNjxIyaodhKEkCJQAVRscSYMpmbf.main_params)
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmgO=='TEST':
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.dp_Test(BtLNjxIyaodhKEkCJQAVRscSYMpmbf.main_params)
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmgO in['MOVIE','VOD','HIGHLIGHT','LIVE']:
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.play_VIDEO(BtLNjxIyaodhKEkCJQAVRscSYMpmbf.main_params)
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmgO=='WATCH':
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.dp_Watch_List(BtLNjxIyaodhKEkCJQAVRscSYMpmbf.main_params)
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmgO=='LOCAL_SEARCH':
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.dp_Search_List(BtLNjxIyaodhKEkCJQAVRscSYMpmbf.main_params)
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmgO=='SEARCH_HISTORY':
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.dp_Search_History(BtLNjxIyaodhKEkCJQAVRscSYMpmbf.main_params)
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmgO in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.dp_Listfile_Delete(BtLNjxIyaodhKEkCJQAVRscSYMpmbf.main_params)
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmgO in['TOTAL_SEARCH','TOTAL_HISTORY']:
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.dp_Global_Search(BtLNjxIyaodhKEkCJQAVRscSYMpmbf.main_params)
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmgO=='MENU_BOOKMARK':
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.dp_Bookmark_Menu(BtLNjxIyaodhKEkCJQAVRscSYMpmbf.main_params)
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmgO=='SET_BOOKMARK':
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.dp_Set_Bookmark(BtLNjxIyaodhKEkCJQAVRscSYMpmbf.main_params)
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmgO=='SPORTS_MAINLIST_LEAGUE':
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.sp_Mainlist_League(BtLNjxIyaodhKEkCJQAVRscSYMpmbf.main_params)
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmgO=='SPORTS_LEAGUE_FEEDLIST':
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.sp_League_FeedList(BtLNjxIyaodhKEkCJQAVRscSYMpmbf.main_params)
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmgO=='SPORTS_FEED_VOD':
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.sp_League_VodList(BtLNjxIyaodhKEkCJQAVRscSYMpmbf.main_params)
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmgO=='SPORTS_MULT_HERO':
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.sp_MultiHero_LiveList(BtLNjxIyaodhKEkCJQAVRscSYMpmbf.main_params)
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmgO=='SPORTS_SEASON_GROUP':
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.sp_Season_Group(BtLNjxIyaodhKEkCJQAVRscSYMpmbf.main_params)
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmgO=='SPORTS_SEASON_GAMELIST':
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.sp_Season_GameList(BtLNjxIyaodhKEkCJQAVRscSYMpmbf.main_params)
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmgO=='SPORTS_SEASON_VODLIST':
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.sp_Season_VodList(BtLNjxIyaodhKEkCJQAVRscSYMpmbf.main_params)
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmgO=='PASS_GROUPLIST':
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.dp_Pass_Group(BtLNjxIyaodhKEkCJQAVRscSYMpmbf.main_params)
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmgO=='PASS_VOD_LIST':
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.dp_Pass_VodList(BtLNjxIyaodhKEkCJQAVRscSYMpmbf.main_params)
  elif BtLNjxIyaodhKEkCJQAVRscSYMpmgO=='ORDER_BY':
   BtLNjxIyaodhKEkCJQAVRscSYMpmbf.dp_setEpOrderby(BtLNjxIyaodhKEkCJQAVRscSYMpmbf.main_params)
  else:
   BtLNjxIyaodhKEkCJQAVRscSYMpmGf
# Created by pyminifier (https://github.com/liftoff/pyminifier)
