__author__="NightRain"
AOnquyUgXawJokpcdhzTSfrtWLKQmi=object
AOnquyUgXawJokpcdhzTSfrtWLKQmF=None
AOnquyUgXawJokpcdhzTSfrtWLKQmj=False
AOnquyUgXawJokpcdhzTSfrtWLKQmI=print
AOnquyUgXawJokpcdhzTSfrtWLKQmV=str
AOnquyUgXawJokpcdhzTSfrtWLKQme=open
AOnquyUgXawJokpcdhzTSfrtWLKQmE=Exception
AOnquyUgXawJokpcdhzTSfrtWLKQls=int
AOnquyUgXawJokpcdhzTSfrtWLKQlR=len
AOnquyUgXawJokpcdhzTSfrtWLKQlx=id
AOnquyUgXawJokpcdhzTSfrtWLKQlP=True
AOnquyUgXawJokpcdhzTSfrtWLKQlm=range
import urllib
import re
import json
import requests
import datetime
import time
import random
import base64
AOnquyUgXawJokpcdhzTSfrtWLKQsx={'LONG_HIGHLIGHT':'하이라이트','SHORT_HIGHLIGHT':'하이라이트','PREVIEW':'프리뷰','FULL_MATCH':'다시보기','KEY_MOMENT':'','OTHER':'프로그램',}
class AOnquyUgXawJokpcdhzTSfrtWLKQsR(AOnquyUgXawJokpcdhzTSfrtWLKQmi):
 def __init__(AOnquyUgXawJokpcdhzTSfrtWLKQsP):
  AOnquyUgXawJokpcdhzTSfrtWLKQsP.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36'
  AOnquyUgXawJokpcdhzTSfrtWLKQsP.MODEL ='Chrome_142' 
  AOnquyUgXawJokpcdhzTSfrtWLKQsP.OS_VERSION ='142' 
  AOnquyUgXawJokpcdhzTSfrtWLKQsP.x_app_version ='1.67.19'
  AOnquyUgXawJokpcdhzTSfrtWLKQsP.DEFAULT_HEADER ={'user-agent':AOnquyUgXawJokpcdhzTSfrtWLKQsP.USER_AGENT}
  AOnquyUgXawJokpcdhzTSfrtWLKQsP.API_DOMAIN ='https://www.coupangplay.com'
  AOnquyUgXawJokpcdhzTSfrtWLKQsP.API_VIEWURL ='https://discover.coupangstreaming.com'
  AOnquyUgXawJokpcdhzTSfrtWLKQsP.PAGE_LIMIT =50
  AOnquyUgXawJokpcdhzTSfrtWLKQsP.SEARCH_LIMIT =20
  AOnquyUgXawJokpcdhzTSfrtWLKQsP.KodiVersion =20
  AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP={}
  AOnquyUgXawJokpcdhzTSfrtWLKQsP.Init_CP()
  AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP_DEVICE_FILENAME=''
  AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP_COOKIE_FILENAME=''
  AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP_SESSION_COOKIES1=''
  AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP_SESSION_COOKIES2=''
  AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP_SESSION_COOKIES3=''
  AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP_SESSION_COOKIES4=''
 def callRequestCookies(AOnquyUgXawJokpcdhzTSfrtWLKQsP,jobtype,AOnquyUgXawJokpcdhzTSfrtWLKQRH,payload=AOnquyUgXawJokpcdhzTSfrtWLKQmF,params=AOnquyUgXawJokpcdhzTSfrtWLKQmF,headers=AOnquyUgXawJokpcdhzTSfrtWLKQmF,cookies=AOnquyUgXawJokpcdhzTSfrtWLKQmF,redirects=AOnquyUgXawJokpcdhzTSfrtWLKQmj):
  AOnquyUgXawJokpcdhzTSfrtWLKQsm=AOnquyUgXawJokpcdhzTSfrtWLKQsP.DEFAULT_HEADER
  if headers:AOnquyUgXawJokpcdhzTSfrtWLKQsm.update(headers)
  if jobtype=='Get':
   AOnquyUgXawJokpcdhzTSfrtWLKQsl=requests.get(AOnquyUgXawJokpcdhzTSfrtWLKQRH,params=params,headers=AOnquyUgXawJokpcdhzTSfrtWLKQsm,cookies=cookies,allow_redirects=redirects)
  else:
   AOnquyUgXawJokpcdhzTSfrtWLKQsl=requests.post(AOnquyUgXawJokpcdhzTSfrtWLKQRH,data=payload,params=params,headers=AOnquyUgXawJokpcdhzTSfrtWLKQsm,cookies=cookies,allow_redirects=redirects)
  AOnquyUgXawJokpcdhzTSfrtWLKQmI(AOnquyUgXawJokpcdhzTSfrtWLKQmV(AOnquyUgXawJokpcdhzTSfrtWLKQsl.status_code)+' - '+AOnquyUgXawJokpcdhzTSfrtWLKQmV(AOnquyUgXawJokpcdhzTSfrtWLKQsl.url))
  return AOnquyUgXawJokpcdhzTSfrtWLKQsl
 def callRequestCookies_test(AOnquyUgXawJokpcdhzTSfrtWLKQsP,jobtype,AOnquyUgXawJokpcdhzTSfrtWLKQRH,payload=AOnquyUgXawJokpcdhzTSfrtWLKQmF,params=AOnquyUgXawJokpcdhzTSfrtWLKQmF,headers=AOnquyUgXawJokpcdhzTSfrtWLKQmF,cookies=AOnquyUgXawJokpcdhzTSfrtWLKQmF,redirects=AOnquyUgXawJokpcdhzTSfrtWLKQmj):
  AOnquyUgXawJokpcdhzTSfrtWLKQsm=AOnquyUgXawJokpcdhzTSfrtWLKQsP.DEFAULT_HEADER
  if headers:AOnquyUgXawJokpcdhzTSfrtWLKQsm.update(headers)
  AOnquyUgXawJokpcdhzTSfrtWLKQsl=requests.Request('POST',AOnquyUgXawJokpcdhzTSfrtWLKQRH,headers=headers,data=payload,params=params,cookies=cookies)
  AOnquyUgXawJokpcdhzTSfrtWLKQsb=AOnquyUgXawJokpcdhzTSfrtWLKQsl.prepare()
  AOnquyUgXawJokpcdhzTSfrtWLKQsP.pretty_print_POST(AOnquyUgXawJokpcdhzTSfrtWLKQsb)
  return AOnquyUgXawJokpcdhzTSfrtWLKQsl
 def pretty_print_POST(AOnquyUgXawJokpcdhzTSfrtWLKQsP,req):
  AOnquyUgXawJokpcdhzTSfrtWLKQmI('{}\n{}\r\n{}\r\n\r\n{}'.format('-----------START-----------',req.method+' '+req.url,'\r\n'.join('{}: {}'.format(k,v)for k,v in req.headers.items()),req.body,))
 def dic_To_jsonfile(AOnquyUgXawJokpcdhzTSfrtWLKQsP,filename,AOnquyUgXawJokpcdhzTSfrtWLKQsB):
  if filename=='':return
  fp=AOnquyUgXawJokpcdhzTSfrtWLKQme(filename,'w',-1,'utf-8')
  json.dump(AOnquyUgXawJokpcdhzTSfrtWLKQsB,fp,indent=4,ensure_ascii=AOnquyUgXawJokpcdhzTSfrtWLKQmj)
  fp.close()
 def jsonfile_To_dic(AOnquyUgXawJokpcdhzTSfrtWLKQsP,filename):
  if filename=='':return AOnquyUgXawJokpcdhzTSfrtWLKQmF
  try:
   fp=AOnquyUgXawJokpcdhzTSfrtWLKQme(filename,'r',-1,'utf-8')
   AOnquyUgXawJokpcdhzTSfrtWLKQsD=json.load(fp)
   fp.close()
  except:
   AOnquyUgXawJokpcdhzTSfrtWLKQsD={}
  return AOnquyUgXawJokpcdhzTSfrtWLKQsD
 def convert_TimeStr(AOnquyUgXawJokpcdhzTSfrtWLKQsP,AOnquyUgXawJokpcdhzTSfrtWLKQsH):
  try:
   AOnquyUgXawJokpcdhzTSfrtWLKQsH =AOnquyUgXawJokpcdhzTSfrtWLKQsH[0:16]
   AOnquyUgXawJokpcdhzTSfrtWLKQsv=datetime.datetime.strptime(AOnquyUgXawJokpcdhzTSfrtWLKQsH,'%Y-%m-%dT%H:%M')+datetime.timedelta(hours=9)
   AOnquyUgXawJokpcdhzTSfrtWLKQsY=AOnquyUgXawJokpcdhzTSfrtWLKQsv.weekday()
   if AOnquyUgXawJokpcdhzTSfrtWLKQsY==0:AOnquyUgXawJokpcdhzTSfrtWLKQsY='월'
   elif AOnquyUgXawJokpcdhzTSfrtWLKQsY==1:AOnquyUgXawJokpcdhzTSfrtWLKQsY='화'
   elif AOnquyUgXawJokpcdhzTSfrtWLKQsY==2:AOnquyUgXawJokpcdhzTSfrtWLKQsY='수'
   elif AOnquyUgXawJokpcdhzTSfrtWLKQsY==3:AOnquyUgXawJokpcdhzTSfrtWLKQsY='목'
   elif AOnquyUgXawJokpcdhzTSfrtWLKQsY==4:AOnquyUgXawJokpcdhzTSfrtWLKQsY='금'
   elif AOnquyUgXawJokpcdhzTSfrtWLKQsY==5:AOnquyUgXawJokpcdhzTSfrtWLKQsY='토'
   elif AOnquyUgXawJokpcdhzTSfrtWLKQsY==6:AOnquyUgXawJokpcdhzTSfrtWLKQsY='일'
   return AOnquyUgXawJokpcdhzTSfrtWLKQsv.strftime('%Y-%m-%d')+'('+ AOnquyUgXawJokpcdhzTSfrtWLKQsY+')'+AOnquyUgXawJokpcdhzTSfrtWLKQsv.strftime(' %H:%M')
  except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
   return AOnquyUgXawJokpcdhzTSfrtWLKQsH
 def convert_DateStr(AOnquyUgXawJokpcdhzTSfrtWLKQsP,AOnquyUgXawJokpcdhzTSfrtWLKQsH):
  try:
   AOnquyUgXawJokpcdhzTSfrtWLKQsH =AOnquyUgXawJokpcdhzTSfrtWLKQsH[0:16]
   AOnquyUgXawJokpcdhzTSfrtWLKQsv=datetime.datetime.strptime(AOnquyUgXawJokpcdhzTSfrtWLKQsH,'%Y-%m-%dT%H:%M')+datetime.timedelta(hours=9)
   AOnquyUgXawJokpcdhzTSfrtWLKQsY=AOnquyUgXawJokpcdhzTSfrtWLKQsv.weekday()
   if AOnquyUgXawJokpcdhzTSfrtWLKQsY==0:AOnquyUgXawJokpcdhzTSfrtWLKQsY='월'
   elif AOnquyUgXawJokpcdhzTSfrtWLKQsY==1:AOnquyUgXawJokpcdhzTSfrtWLKQsY='화'
   elif AOnquyUgXawJokpcdhzTSfrtWLKQsY==2:AOnquyUgXawJokpcdhzTSfrtWLKQsY='수'
   elif AOnquyUgXawJokpcdhzTSfrtWLKQsY==3:AOnquyUgXawJokpcdhzTSfrtWLKQsY='목'
   elif AOnquyUgXawJokpcdhzTSfrtWLKQsY==4:AOnquyUgXawJokpcdhzTSfrtWLKQsY='금'
   elif AOnquyUgXawJokpcdhzTSfrtWLKQsY==5:AOnquyUgXawJokpcdhzTSfrtWLKQsY='토'
   elif AOnquyUgXawJokpcdhzTSfrtWLKQsY==6:AOnquyUgXawJokpcdhzTSfrtWLKQsY='일'
   return AOnquyUgXawJokpcdhzTSfrtWLKQsv.strftime('%Y-%m-%d')+'('+ AOnquyUgXawJokpcdhzTSfrtWLKQsY+')'
  except:
   return AOnquyUgXawJokpcdhzTSfrtWLKQsH
 def Get_Now_Datetime(AOnquyUgXawJokpcdhzTSfrtWLKQsP):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetNoCache(AOnquyUgXawJokpcdhzTSfrtWLKQsP):
  AOnquyUgXawJokpcdhzTSfrtWLKQsM =AOnquyUgXawJokpcdhzTSfrtWLKQls(time.time()*1000)
  return AOnquyUgXawJokpcdhzTSfrtWLKQsM
 def generatePcId(AOnquyUgXawJokpcdhzTSfrtWLKQsP):
  t=AOnquyUgXawJokpcdhzTSfrtWLKQsP.GetNoCache()
  r=random.random()
  AOnquyUgXawJokpcdhzTSfrtWLKQsG=AOnquyUgXawJokpcdhzTSfrtWLKQmV(t)+AOnquyUgXawJokpcdhzTSfrtWLKQmV(r)[2:12]
  return AOnquyUgXawJokpcdhzTSfrtWLKQsG
 def generatePvId(AOnquyUgXawJokpcdhzTSfrtWLKQsP,genType='1'):
  import hashlib
  m=hashlib.md5()
  AOnquyUgXawJokpcdhzTSfrtWLKQsi=AOnquyUgXawJokpcdhzTSfrtWLKQmV(random.random())
  m.update(AOnquyUgXawJokpcdhzTSfrtWLKQsi.encode('utf-8'))
  AOnquyUgXawJokpcdhzTSfrtWLKQsF=AOnquyUgXawJokpcdhzTSfrtWLKQmV(m.hexdigest())
  if genType=='1':
   return '%s-%s-%s-%s-%s'%(AOnquyUgXawJokpcdhzTSfrtWLKQsF[:8],AOnquyUgXawJokpcdhzTSfrtWLKQsF[8:12],AOnquyUgXawJokpcdhzTSfrtWLKQsF[12:16],AOnquyUgXawJokpcdhzTSfrtWLKQsF[16:20],AOnquyUgXawJokpcdhzTSfrtWLKQsF[20:])
  else:
   return AOnquyUgXawJokpcdhzTSfrtWLKQsF
 def Get_DeviceID(AOnquyUgXawJokpcdhzTSfrtWLKQsP):
  AOnquyUgXawJokpcdhzTSfrtWLKQsj=''
  try: 
   fp=AOnquyUgXawJokpcdhzTSfrtWLKQme(AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP_DEVICE_FILENAME,'r',-1,'utf-8')
   AOnquyUgXawJokpcdhzTSfrtWLKQsI= json.load(fp)
   fp.close()
   AOnquyUgXawJokpcdhzTSfrtWLKQsj=AOnquyUgXawJokpcdhzTSfrtWLKQsI.get('device_id')
  except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
   AOnquyUgXawJokpcdhzTSfrtWLKQmF
  if AOnquyUgXawJokpcdhzTSfrtWLKQsj=='':
   AOnquyUgXawJokpcdhzTSfrtWLKQsj=AOnquyUgXawJokpcdhzTSfrtWLKQsP.generatePvId(genType='1')
   try: 
    fp=AOnquyUgXawJokpcdhzTSfrtWLKQme(AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP_DEVICE_FILENAME,'w',-1,'utf-8')
    json.dump({'device_id':AOnquyUgXawJokpcdhzTSfrtWLKQsj},fp,indent=4,ensure_ascii=AOnquyUgXawJokpcdhzTSfrtWLKQmj)
    fp.close()
   except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
    return ''
  return AOnquyUgXawJokpcdhzTSfrtWLKQsj
 def make_stream_header(AOnquyUgXawJokpcdhzTSfrtWLKQsP,AOnquyUgXawJokpcdhzTSfrtWLKQRx,AOnquyUgXawJokpcdhzTSfrtWLKQRv):
  AOnquyUgXawJokpcdhzTSfrtWLKQsV=''
  if AOnquyUgXawJokpcdhzTSfrtWLKQRv not in[{},AOnquyUgXawJokpcdhzTSfrtWLKQmF,'']:
   AOnquyUgXawJokpcdhzTSfrtWLKQse=AOnquyUgXawJokpcdhzTSfrtWLKQlR(AOnquyUgXawJokpcdhzTSfrtWLKQRv)
   for AOnquyUgXawJokpcdhzTSfrtWLKQsE,AOnquyUgXawJokpcdhzTSfrtWLKQRs in AOnquyUgXawJokpcdhzTSfrtWLKQRv.items():
    AOnquyUgXawJokpcdhzTSfrtWLKQsV+='{}={}'.format(AOnquyUgXawJokpcdhzTSfrtWLKQsE,AOnquyUgXawJokpcdhzTSfrtWLKQRs)
    AOnquyUgXawJokpcdhzTSfrtWLKQse+=-1
    if AOnquyUgXawJokpcdhzTSfrtWLKQse>0:AOnquyUgXawJokpcdhzTSfrtWLKQsV+='; '
   AOnquyUgXawJokpcdhzTSfrtWLKQRx['cookie']=AOnquyUgXawJokpcdhzTSfrtWLKQsV
  AOnquyUgXawJokpcdhzTSfrtWLKQRP=''
  i=0
  for AOnquyUgXawJokpcdhzTSfrtWLKQsE,AOnquyUgXawJokpcdhzTSfrtWLKQRs in AOnquyUgXawJokpcdhzTSfrtWLKQRx.items():
   i=i+1
   if i>1:AOnquyUgXawJokpcdhzTSfrtWLKQRP+='&'
   AOnquyUgXawJokpcdhzTSfrtWLKQRP+='{}={}'.format(AOnquyUgXawJokpcdhzTSfrtWLKQsE,urllib.parse.quote(AOnquyUgXawJokpcdhzTSfrtWLKQRs))
  return AOnquyUgXawJokpcdhzTSfrtWLKQRP
 def Make_authHeader(AOnquyUgXawJokpcdhzTSfrtWLKQsP):
  tr=AOnquyUgXawJokpcdhzTSfrtWLKQsP.generatePvId(genType=2)
  ti=AOnquyUgXawJokpcdhzTSfrtWLKQsP.GetNoCache()
  AOnquyUgXawJokpcdhzTSfrtWLKQlx=AOnquyUgXawJokpcdhzTSfrtWLKQsP.generatePvId(genType=2)[:16]
  AOnquyUgXawJokpcdhzTSfrtWLKQRm='00-%s-%s-01'%(tr,AOnquyUgXawJokpcdhzTSfrtWLKQlx,)
  AOnquyUgXawJokpcdhzTSfrtWLKQRl ='%s@nr=0-1-%s-%s-%s----%s'%(AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['SESSION']['NREUM']['tk'],AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['SESSION']['NREUM']['ac'],AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['SESSION']['NREUM']['ap'],AOnquyUgXawJokpcdhzTSfrtWLKQlx,ti,)
  AOnquyUgXawJokpcdhzTSfrtWLKQRb ='{"v":[0,1],"d":{"ty":"Browser","ac":"%s","ap":"%s","id":"%s","tr":"%s","ti":%s,"tk":"%s"}}'%(AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['SESSION']['NREUM']['ac'],AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['SESSION']['NREUM']['ap'],AOnquyUgXawJokpcdhzTSfrtWLKQlx,tr,ti,AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['SESSION']['NREUM']['tk'],) 
  return AOnquyUgXawJokpcdhzTSfrtWLKQRm,AOnquyUgXawJokpcdhzTSfrtWLKQRl,base64.standard_b64encode(AOnquyUgXawJokpcdhzTSfrtWLKQRb.encode()).decode('utf-8')
 def Init_CP(AOnquyUgXawJokpcdhzTSfrtWLKQsP):
  AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP={}
  AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['ACCOUNT']={'cpid':'','cppw':'','cppf':'0'}
  AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['SESSION']={}
  AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['COOKIES']={}
 def Save_session_acount(AOnquyUgXawJokpcdhzTSfrtWLKQsP,AOnquyUgXawJokpcdhzTSfrtWLKQRB,AOnquyUgXawJokpcdhzTSfrtWLKQRC,AOnquyUgXawJokpcdhzTSfrtWLKQRD):
  AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['ACCOUNT']['cpid']=base64.standard_b64encode(AOnquyUgXawJokpcdhzTSfrtWLKQRB.encode()).decode('utf-8')
  AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['ACCOUNT']['cppw']=base64.standard_b64encode(AOnquyUgXawJokpcdhzTSfrtWLKQRC.encode()).decode('utf-8')
  AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['ACCOUNT']['cppf']=AOnquyUgXawJokpcdhzTSfrtWLKQmV(AOnquyUgXawJokpcdhzTSfrtWLKQRD)
 def Load_session_acount(AOnquyUgXawJokpcdhzTSfrtWLKQsP):
  AOnquyUgXawJokpcdhzTSfrtWLKQRB=base64.standard_b64decode(AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['ACCOUNT']['cpid']).decode('utf-8')
  AOnquyUgXawJokpcdhzTSfrtWLKQRC=base64.standard_b64decode(AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['ACCOUNT']['cppw']).decode('utf-8')
  AOnquyUgXawJokpcdhzTSfrtWLKQRD=AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['ACCOUNT']['cppf']
  return AOnquyUgXawJokpcdhzTSfrtWLKQRB,AOnquyUgXawJokpcdhzTSfrtWLKQRC,AOnquyUgXawJokpcdhzTSfrtWLKQRD
 def make_CP_DefaultCookies(AOnquyUgXawJokpcdhzTSfrtWLKQsP):
  return AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['COOKIES']
 def Get_CP_Login(AOnquyUgXawJokpcdhzTSfrtWLKQsP,userid,userpw,AOnquyUgXawJokpcdhzTSfrtWLKQRV):
  try:
   AOnquyUgXawJokpcdhzTSfrtWLKQRH=AOnquyUgXawJokpcdhzTSfrtWLKQsP.API_DOMAIN
   AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['COOKIES']['NEXT_LOCALE']='ko'
   AOnquyUgXawJokpcdhzTSfrtWLKQRx={'Accept-Language':'ko-KR,ko;q=0.9','Sec-Ch-Ua-Mobile':'?0','Sec-Ch-Ua-Platform':'"Windows"','Sec-Fetch-Dest':'document','Sec-Fetch-Mode':'navigate','Sec-Fetch-Site':'none','Sec-Fetch-User':'?1','Upgrade-Insecure-Requests':'1',}
   AOnquyUgXawJokpcdhzTSfrtWLKQRv=AOnquyUgXawJokpcdhzTSfrtWLKQsP.make_CP_DefaultCookies()
   AOnquyUgXawJokpcdhzTSfrtWLKQRY=AOnquyUgXawJokpcdhzTSfrtWLKQsP.callRequestCookies('Get',AOnquyUgXawJokpcdhzTSfrtWLKQRH,payload=AOnquyUgXawJokpcdhzTSfrtWLKQmF,params=AOnquyUgXawJokpcdhzTSfrtWLKQmF,headers=AOnquyUgXawJokpcdhzTSfrtWLKQRx,cookies=AOnquyUgXawJokpcdhzTSfrtWLKQRv,redirects=AOnquyUgXawJokpcdhzTSfrtWLKQlP)
   if AOnquyUgXawJokpcdhzTSfrtWLKQRY.status_code not in[200]:return AOnquyUgXawJokpcdhzTSfrtWLKQmj
   for AOnquyUgXawJokpcdhzTSfrtWLKQRN in AOnquyUgXawJokpcdhzTSfrtWLKQRY.cookies:
    AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['COOKIES'][AOnquyUgXawJokpcdhzTSfrtWLKQRN.name]=AOnquyUgXawJokpcdhzTSfrtWLKQRN.value
   AOnquyUgXawJokpcdhzTSfrtWLKQRM=re.findall('NREUM.loader_config=\{[\w\d\":,-]+\}',AOnquyUgXawJokpcdhzTSfrtWLKQRY.text)[0].split('=')[1]
   AOnquyUgXawJokpcdhzTSfrtWLKQRM=AOnquyUgXawJokpcdhzTSfrtWLKQRM.replace('{','{"').replace(':','":').replace(',',',"')
   AOnquyUgXawJokpcdhzTSfrtWLKQRM=json.loads(AOnquyUgXawJokpcdhzTSfrtWLKQRM)
   AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['SESSION']['NREUM']={'ac':AOnquyUgXawJokpcdhzTSfrtWLKQRM['accountID'],'tk':AOnquyUgXawJokpcdhzTSfrtWLKQRM['trustKey'],'ap':AOnquyUgXawJokpcdhzTSfrtWLKQRM['agentID'],'lk':AOnquyUgXawJokpcdhzTSfrtWLKQRM['licenseKey'],}
  except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
   AOnquyUgXawJokpcdhzTSfrtWLKQmI(exception)
   return AOnquyUgXawJokpcdhzTSfrtWLKQmj
  try:
   AOnquyUgXawJokpcdhzTSfrtWLKQRH=AOnquyUgXawJokpcdhzTSfrtWLKQsP.API_DOMAIN+'/api/auth'
   AOnquyUgXawJokpcdhzTSfrtWLKQRG=AOnquyUgXawJokpcdhzTSfrtWLKQsP.Get_DeviceID()
   AOnquyUgXawJokpcdhzTSfrtWLKQRi =AOnquyUgXawJokpcdhzTSfrtWLKQRG.split('-')[0]
   AOnquyUgXawJokpcdhzTSfrtWLKQRm,AOnquyUgXawJokpcdhzTSfrtWLKQRl,AOnquyUgXawJokpcdhzTSfrtWLKQRb=AOnquyUgXawJokpcdhzTSfrtWLKQsP.Make_authHeader()
   AOnquyUgXawJokpcdhzTSfrtWLKQRx={'traceparent':AOnquyUgXawJokpcdhzTSfrtWLKQRm,'tracestate':AOnquyUgXawJokpcdhzTSfrtWLKQRl,'newrelic':AOnquyUgXawJokpcdhzTSfrtWLKQRb,'content-type':'application/json','x-app-version':AOnquyUgXawJokpcdhzTSfrtWLKQsP.x_app_version,'x-device-id':'','x-device-os-version':AOnquyUgXawJokpcdhzTSfrtWLKQsP.OS_VERSION,'x-nr-session-id':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['COOKIES']['session_web_id'],'x-pcid':'',}
   AOnquyUgXawJokpcdhzTSfrtWLKQRF={'device':{'deviceId':'web-'+AOnquyUgXawJokpcdhzTSfrtWLKQRG,'model':AOnquyUgXawJokpcdhzTSfrtWLKQsP.MODEL,'name':'Chrome Desktop '+AOnquyUgXawJokpcdhzTSfrtWLKQRi,'os':'Windows','osVersion':'10','type':'webclient',},'email':userid,'password':userpw,}
   AOnquyUgXawJokpcdhzTSfrtWLKQRF=json.dumps(AOnquyUgXawJokpcdhzTSfrtWLKQRF,separators=(',',':'))
   AOnquyUgXawJokpcdhzTSfrtWLKQRv=AOnquyUgXawJokpcdhzTSfrtWLKQsP.make_CP_DefaultCookies()
   AOnquyUgXawJokpcdhzTSfrtWLKQRY=AOnquyUgXawJokpcdhzTSfrtWLKQsP.callRequestCookies('Post',AOnquyUgXawJokpcdhzTSfrtWLKQRH,payload=AOnquyUgXawJokpcdhzTSfrtWLKQRF,params=AOnquyUgXawJokpcdhzTSfrtWLKQmF,headers=AOnquyUgXawJokpcdhzTSfrtWLKQRx,cookies=AOnquyUgXawJokpcdhzTSfrtWLKQRv,redirects=AOnquyUgXawJokpcdhzTSfrtWLKQmj)
   if AOnquyUgXawJokpcdhzTSfrtWLKQRY.status_code not in[200]:
    AOnquyUgXawJokpcdhzTSfrtWLKQRj=json.loads(AOnquyUgXawJokpcdhzTSfrtWLKQRY.text)
    if 'error' in AOnquyUgXawJokpcdhzTSfrtWLKQRj:
     AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['SESSION']['error']=AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('error').get('detail')
    return AOnquyUgXawJokpcdhzTSfrtWLKQmj
   AOnquyUgXawJokpcdhzTSfrtWLKQmI('---')
   for AOnquyUgXawJokpcdhzTSfrtWLKQRN in AOnquyUgXawJokpcdhzTSfrtWLKQRY.cookies:
    AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['COOKIES'][AOnquyUgXawJokpcdhzTSfrtWLKQRN.name]=AOnquyUgXawJokpcdhzTSfrtWLKQRN.value
  except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
   AOnquyUgXawJokpcdhzTSfrtWLKQmI(exception)
   return AOnquyUgXawJokpcdhzTSfrtWLKQmj
  AOnquyUgXawJokpcdhzTSfrtWLKQsP.Save_session_acount(userid,userpw,AOnquyUgXawJokpcdhzTSfrtWLKQRV)
  return AOnquyUgXawJokpcdhzTSfrtWLKQlP
 def Get_CP_profile(AOnquyUgXawJokpcdhzTSfrtWLKQsP,AOnquyUgXawJokpcdhzTSfrtWLKQRV,limit_days=1,re_check=AOnquyUgXawJokpcdhzTSfrtWLKQmj):
  if re_check==AOnquyUgXawJokpcdhzTSfrtWLKQlP:
   if AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['SESSION']['bm_sv_ex']>AOnquyUgXawJokpcdhzTSfrtWLKQls(time.time()):
    AOnquyUgXawJokpcdhzTSfrtWLKQmI('bm_sv_ex ok')
    return AOnquyUgXawJokpcdhzTSfrtWLKQlP
  try:
   AOnquyUgXawJokpcdhzTSfrtWLKQRH=AOnquyUgXawJokpcdhzTSfrtWLKQsP.API_DOMAIN+'/api/profiles'
   AOnquyUgXawJokpcdhzTSfrtWLKQRm,AOnquyUgXawJokpcdhzTSfrtWLKQRl,AOnquyUgXawJokpcdhzTSfrtWLKQRb=AOnquyUgXawJokpcdhzTSfrtWLKQsP.Make_authHeader()
   AOnquyUgXawJokpcdhzTSfrtWLKQRx={'traceparent':AOnquyUgXawJokpcdhzTSfrtWLKQRm,'tracestate':AOnquyUgXawJokpcdhzTSfrtWLKQRl,'newrelic':AOnquyUgXawJokpcdhzTSfrtWLKQRb,'x-app-version':AOnquyUgXawJokpcdhzTSfrtWLKQsP.x_app_version,'x-device-id':'','x-device-os-version':AOnquyUgXawJokpcdhzTSfrtWLKQsP.OS_VERSION,'x-nr-session-id':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['COOKIES']['session_web_id'],'x-pcid':'','referer':'https://www.coupangplay.com/home',}
   AOnquyUgXawJokpcdhzTSfrtWLKQRv=AOnquyUgXawJokpcdhzTSfrtWLKQsP.make_CP_DefaultCookies()
   AOnquyUgXawJokpcdhzTSfrtWLKQRY=AOnquyUgXawJokpcdhzTSfrtWLKQsP.callRequestCookies('Get',AOnquyUgXawJokpcdhzTSfrtWLKQRH,payload=AOnquyUgXawJokpcdhzTSfrtWLKQmF,params=AOnquyUgXawJokpcdhzTSfrtWLKQmF,headers=AOnquyUgXawJokpcdhzTSfrtWLKQRx,cookies=AOnquyUgXawJokpcdhzTSfrtWLKQRv,redirects=AOnquyUgXawJokpcdhzTSfrtWLKQlP)
   if AOnquyUgXawJokpcdhzTSfrtWLKQRY.status_code not in[200]:return AOnquyUgXawJokpcdhzTSfrtWLKQmj
   AOnquyUgXawJokpcdhzTSfrtWLKQRj=json.loads(AOnquyUgXawJokpcdhzTSfrtWLKQRY.text)
   AOnquyUgXawJokpcdhzTSfrtWLKQRI=0
   for AOnquyUgXawJokpcdhzTSfrtWLKQRN in AOnquyUgXawJokpcdhzTSfrtWLKQRY.cookies:
    AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['COOKIES'][AOnquyUgXawJokpcdhzTSfrtWLKQRN.name]=AOnquyUgXawJokpcdhzTSfrtWLKQRN.value
    if AOnquyUgXawJokpcdhzTSfrtWLKQRN.name=='bm_sv':
     AOnquyUgXawJokpcdhzTSfrtWLKQRI=1
     AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['SESSION']['bm_sv_ex']=AOnquyUgXawJokpcdhzTSfrtWLKQRN.expires 
   if AOnquyUgXawJokpcdhzTSfrtWLKQRI==0:
    AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['SESSION']['bm_sv_ex']=AOnquyUgXawJokpcdhzTSfrtWLKQls(time.time())+60*60*2 
   AOnquyUgXawJokpcdhzTSfrtWLKQRV=AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('data')[AOnquyUgXawJokpcdhzTSfrtWLKQls(AOnquyUgXawJokpcdhzTSfrtWLKQRV)]
   AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['SESSION']['accountId']=AOnquyUgXawJokpcdhzTSfrtWLKQRV.get('accountId')
   AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['SESSION']['profileId']=AOnquyUgXawJokpcdhzTSfrtWLKQRV.get('profileId')
  except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
   AOnquyUgXawJokpcdhzTSfrtWLKQmI(exception)
   return AOnquyUgXawJokpcdhzTSfrtWLKQmj
  if re_check==AOnquyUgXawJokpcdhzTSfrtWLKQmj:
   AOnquyUgXawJokpcdhzTSfrtWLKQRe =AOnquyUgXawJokpcdhzTSfrtWLKQsP.Get_Now_Datetime()
   AOnquyUgXawJokpcdhzTSfrtWLKQRE=AOnquyUgXawJokpcdhzTSfrtWLKQRe+datetime.timedelta(days=limit_days)
   AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['SESSION']['limitdate']=AOnquyUgXawJokpcdhzTSfrtWLKQRE.strftime('%Y-%m-%d')
  else:
   AOnquyUgXawJokpcdhzTSfrtWLKQmI('re check')
  AOnquyUgXawJokpcdhzTSfrtWLKQsP.dic_To_jsonfile(AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP_COOKIE_FILENAME,AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP)
  return AOnquyUgXawJokpcdhzTSfrtWLKQlP
 def Get_Category_GroupList(AOnquyUgXawJokpcdhzTSfrtWLKQsP,vType):
  AOnquyUgXawJokpcdhzTSfrtWLKQxs=[] 
  try:
   AOnquyUgXawJokpcdhzTSfrtWLKQRH=AOnquyUgXawJokpcdhzTSfrtWLKQsP.API_DOMAIN+'/api-discover/v3/discover/feed' 
   AOnquyUgXawJokpcdhzTSfrtWLKQxR={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false','preferRecoFeed':'true','preferMultiHeroMixedContentRow':'true','shouldIncludeTVOD':'true',}
   AOnquyUgXawJokpcdhzTSfrtWLKQRx={'x-membersrl':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['COOKIES']['member_srl'],'x-pcid':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['COOKIES']['PCID'],'x-profileid':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT','x-app-version':AOnquyUgXawJokpcdhzTSfrtWLKQsP.x_app_version,}
   AOnquyUgXawJokpcdhzTSfrtWLKQRY=AOnquyUgXawJokpcdhzTSfrtWLKQsP.callRequestCookies('Get',AOnquyUgXawJokpcdhzTSfrtWLKQRH,payload=AOnquyUgXawJokpcdhzTSfrtWLKQmF,params=AOnquyUgXawJokpcdhzTSfrtWLKQxR,headers=AOnquyUgXawJokpcdhzTSfrtWLKQRx,cookies=AOnquyUgXawJokpcdhzTSfrtWLKQmF,redirects=AOnquyUgXawJokpcdhzTSfrtWLKQlP)
   if AOnquyUgXawJokpcdhzTSfrtWLKQRY.status_code not in[200]:return[]
   AOnquyUgXawJokpcdhzTSfrtWLKQRj=json.loads(AOnquyUgXawJokpcdhzTSfrtWLKQRY.text)
   if vType in['TVSHOWS','MOVIES']:
    AOnquyUgXawJokpcdhzTSfrtWLKQxP='Explores' 
   elif vType in['EDUCATION']:
    AOnquyUgXawJokpcdhzTSfrtWLKQxP='Collection-Rails-Curation'
   elif vType in['ALL','KIDS']:
    AOnquyUgXawJokpcdhzTSfrtWLKQxP='Explores-Categories'
   for AOnquyUgXawJokpcdhzTSfrtWLKQxm in AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('data'):
    if AOnquyUgXawJokpcdhzTSfrtWLKQxm.get('type')==AOnquyUgXawJokpcdhzTSfrtWLKQxP:
     for AOnquyUgXawJokpcdhzTSfrtWLKQxl in AOnquyUgXawJokpcdhzTSfrtWLKQxm.get('data'):
      if vType in['TVSHOWS','MOVIES']:
       AOnquyUgXawJokpcdhzTSfrtWLKQxb=AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('collectionId')
      elif vType in['EDUCATION','ALL','KIDS']:
       AOnquyUgXawJokpcdhzTSfrtWLKQxb=AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('id')
      AOnquyUgXawJokpcdhzTSfrtWLKQxB={'collectionId':AOnquyUgXawJokpcdhzTSfrtWLKQxb,'title':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('name'),'category':AOnquyUgXawJokpcdhzTSfrtWLKQxm.get('category'),'pre_title':'',}
      AOnquyUgXawJokpcdhzTSfrtWLKQxs.append(AOnquyUgXawJokpcdhzTSfrtWLKQxB)
     break
  except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
   AOnquyUgXawJokpcdhzTSfrtWLKQmI(exception)
   return[]
  return AOnquyUgXawJokpcdhzTSfrtWLKQxs
 def Get_Category_List(AOnquyUgXawJokpcdhzTSfrtWLKQsP,vType,AOnquyUgXawJokpcdhzTSfrtWLKQxb,page_int):
  AOnquyUgXawJokpcdhzTSfrtWLKQxs=[] 
  AOnquyUgXawJokpcdhzTSfrtWLKQxC=AOnquyUgXawJokpcdhzTSfrtWLKQmj
  try:
   if vType in['ALL','#KIDS']:
    AOnquyUgXawJokpcdhzTSfrtWLKQxR={'platform':'WEBCLIENT','page':AOnquyUgXawJokpcdhzTSfrtWLKQmV(page_int),'perPage':AOnquyUgXawJokpcdhzTSfrtWLKQmV(AOnquyUgXawJokpcdhzTSfrtWLKQsP.PAGE_LIMIT),'locale':'ko','sort':'',}
    AOnquyUgXawJokpcdhzTSfrtWLKQRx={'x-membersrl':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['COOKIES']['member_srl'],'x-pcid':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['COOKIES']['PCID'],'x-profileid':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT','x-app-version':AOnquyUgXawJokpcdhzTSfrtWLKQsP.x_app_version,}
    AOnquyUgXawJokpcdhzTSfrtWLKQRH=AOnquyUgXawJokpcdhzTSfrtWLKQsP.API_DOMAIN+'/api-discover/v1/discover/categories/'+AOnquyUgXawJokpcdhzTSfrtWLKQxb+'/titles' 
    AOnquyUgXawJokpcdhzTSfrtWLKQRY=AOnquyUgXawJokpcdhzTSfrtWLKQsP.callRequestCookies('Get',AOnquyUgXawJokpcdhzTSfrtWLKQRH,payload=AOnquyUgXawJokpcdhzTSfrtWLKQmF,params=AOnquyUgXawJokpcdhzTSfrtWLKQxR,headers=AOnquyUgXawJokpcdhzTSfrtWLKQRx,cookies=AOnquyUgXawJokpcdhzTSfrtWLKQmF,redirects=AOnquyUgXawJokpcdhzTSfrtWLKQlP)
   else: 
    AOnquyUgXawJokpcdhzTSfrtWLKQxR={'platform':'WEBCLIENT','page':AOnquyUgXawJokpcdhzTSfrtWLKQmV(page_int),'perPage':AOnquyUgXawJokpcdhzTSfrtWLKQmV(AOnquyUgXawJokpcdhzTSfrtWLKQsP.PAGE_LIMIT),}
    AOnquyUgXawJokpcdhzTSfrtWLKQRx={'x-membersrl':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['COOKIES']['member_srl'],'x-pcid':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['COOKIES']['PCID'],'x-profileid':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT','x-app-version':AOnquyUgXawJokpcdhzTSfrtWLKQsP.x_app_version,}
    AOnquyUgXawJokpcdhzTSfrtWLKQRH=AOnquyUgXawJokpcdhzTSfrtWLKQsP.API_DOMAIN+'/api-discover/v1/discover/collections/'+AOnquyUgXawJokpcdhzTSfrtWLKQxb+'/titles' 
    AOnquyUgXawJokpcdhzTSfrtWLKQRY=AOnquyUgXawJokpcdhzTSfrtWLKQsP.callRequestCookies('Get',AOnquyUgXawJokpcdhzTSfrtWLKQRH,payload=AOnquyUgXawJokpcdhzTSfrtWLKQmF,params=AOnquyUgXawJokpcdhzTSfrtWLKQxR,headers=AOnquyUgXawJokpcdhzTSfrtWLKQRx,cookies=AOnquyUgXawJokpcdhzTSfrtWLKQmF,redirects=AOnquyUgXawJokpcdhzTSfrtWLKQlP)
   if AOnquyUgXawJokpcdhzTSfrtWLKQRY.status_code not in[200]:return[],AOnquyUgXawJokpcdhzTSfrtWLKQmj
   AOnquyUgXawJokpcdhzTSfrtWLKQRj=json.loads(AOnquyUgXawJokpcdhzTSfrtWLKQRY.text)
   if vType in['ALL','#KIDS']:
    AOnquyUgXawJokpcdhzTSfrtWLKQxD=AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('data').get('data')
   else:
    AOnquyUgXawJokpcdhzTSfrtWLKQxD=AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('data')
   for AOnquyUgXawJokpcdhzTSfrtWLKQxl in AOnquyUgXawJokpcdhzTSfrtWLKQxD:
    AOnquyUgXawJokpcdhzTSfrtWLKQxH=AOnquyUgXawJokpcdhzTSfrtWLKQxG=AOnquyUgXawJokpcdhzTSfrtWLKQPY=AOnquyUgXawJokpcdhzTSfrtWLKQPv=''
    if 'poster' in AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('images'):AOnquyUgXawJokpcdhzTSfrtWLKQxH =AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('images'):AOnquyUgXawJokpcdhzTSfrtWLKQxG =AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('images').get('story-art').get('url') +'?imwidth=600'
    if 'title-treatment' in AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('images'):AOnquyUgXawJokpcdhzTSfrtWLKQPY=AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('images').get('title-treatment').get('url')+'?imwidth=300'
    if 'story-art' in AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('images'):AOnquyUgXawJokpcdhzTSfrtWLKQPv =AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('images').get('story-art').get('url') +'?imwidth=600'
    AOnquyUgXawJokpcdhzTSfrtWLKQxv=''
    if AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('badge')not in[{},AOnquyUgXawJokpcdhzTSfrtWLKQmF]:
     for i in AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('badge').get('text'):
      AOnquyUgXawJokpcdhzTSfrtWLKQxv+=i.get('text')
    AOnquyUgXawJokpcdhzTSfrtWLKQxY=''
    if AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('seasonList')!=AOnquyUgXawJokpcdhzTSfrtWLKQmF:
     AOnquyUgXawJokpcdhzTSfrtWLKQxY=','.join(AOnquyUgXawJokpcdhzTSfrtWLKQmV(e)for e in AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('seasonList'))
    AOnquyUgXawJokpcdhzTSfrtWLKQxN =[]
    for AOnquyUgXawJokpcdhzTSfrtWLKQxM in AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('tags'):
     AOnquyUgXawJokpcdhzTSfrtWLKQxN.append(AOnquyUgXawJokpcdhzTSfrtWLKQxM.get('tag'))
    AOnquyUgXawJokpcdhzTSfrtWLKQxB={'id':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('id'),'title':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('title'),'thumbnail':{'poster':AOnquyUgXawJokpcdhzTSfrtWLKQxH,'thumb':AOnquyUgXawJokpcdhzTSfrtWLKQxG,'clearlogo':AOnquyUgXawJokpcdhzTSfrtWLKQPY,'fanart':AOnquyUgXawJokpcdhzTSfrtWLKQPv},'mpaa':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('age_rating'),'duration':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('running_time'),'asis':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('as'),'badge':AOnquyUgXawJokpcdhzTSfrtWLKQxv,'year':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('meta').get('releaseYear'),'seasonList':AOnquyUgXawJokpcdhzTSfrtWLKQxY,'genreList':AOnquyUgXawJokpcdhzTSfrtWLKQxN,}
    AOnquyUgXawJokpcdhzTSfrtWLKQxs.append(AOnquyUgXawJokpcdhzTSfrtWLKQxB)
   if AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('pagination').get('totalPages')>page_int:
    AOnquyUgXawJokpcdhzTSfrtWLKQxC=AOnquyUgXawJokpcdhzTSfrtWLKQlP
  except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
   AOnquyUgXawJokpcdhzTSfrtWLKQmI(exception)
   return[],AOnquyUgXawJokpcdhzTSfrtWLKQmj
  return AOnquyUgXawJokpcdhzTSfrtWLKQxs,AOnquyUgXawJokpcdhzTSfrtWLKQxC
 def Get_Episode_List_x(AOnquyUgXawJokpcdhzTSfrtWLKQsP,programId,season):
  AOnquyUgXawJokpcdhzTSfrtWLKQxs=[] 
  try:
   AOnquyUgXawJokpcdhzTSfrtWLKQRH=AOnquyUgXawJokpcdhzTSfrtWLKQsP.API_DOMAIN+'/api-discover/v1/discover/titles/'+programId+'/episodes' 
   AOnquyUgXawJokpcdhzTSfrtWLKQxR={'season':season,'sort':'true','locale':'ko',}
   AOnquyUgXawJokpcdhzTSfrtWLKQRx={'x-membersrl':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['COOKIES']['member_srl'],'x-pcid':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['COOKIES']['PCID'],'x-profileid':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT','x-app-version':AOnquyUgXawJokpcdhzTSfrtWLKQsP.x_app_version,}
   AOnquyUgXawJokpcdhzTSfrtWLKQRY=AOnquyUgXawJokpcdhzTSfrtWLKQsP.callRequestCookies('Get',AOnquyUgXawJokpcdhzTSfrtWLKQRH,payload=AOnquyUgXawJokpcdhzTSfrtWLKQmF,params=AOnquyUgXawJokpcdhzTSfrtWLKQxR,headers=AOnquyUgXawJokpcdhzTSfrtWLKQmF,cookies=AOnquyUgXawJokpcdhzTSfrtWLKQmF,redirects=AOnquyUgXawJokpcdhzTSfrtWLKQlP)
   if AOnquyUgXawJokpcdhzTSfrtWLKQRY.status_code not in[200]:return[]
   AOnquyUgXawJokpcdhzTSfrtWLKQRj=json.loads(AOnquyUgXawJokpcdhzTSfrtWLKQRY.text)
   for AOnquyUgXawJokpcdhzTSfrtWLKQxl in AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('data'):
    AOnquyUgXawJokpcdhzTSfrtWLKQxG=''
    if 'story-art' in AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('images'):AOnquyUgXawJokpcdhzTSfrtWLKQxG =AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('images').get('story-art').get('url')+'?imwidth=600'
    AOnquyUgXawJokpcdhzTSfrtWLKQxN =[]
    for AOnquyUgXawJokpcdhzTSfrtWLKQxM in AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('tags'):
     AOnquyUgXawJokpcdhzTSfrtWLKQxN.append(AOnquyUgXawJokpcdhzTSfrtWLKQxM.get('tag'))
    AOnquyUgXawJokpcdhzTSfrtWLKQxB={'id':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('id'),'title':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('title'),'thumbnail':{'thumb':AOnquyUgXawJokpcdhzTSfrtWLKQxG,'fanart':AOnquyUgXawJokpcdhzTSfrtWLKQxG},'mpaa':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('age_rating'),'duration':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('running_time'),'asis':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('as'),'year':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('meta').get('releaseYear'),'episode':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('episode'),'genreList':AOnquyUgXawJokpcdhzTSfrtWLKQxN,'desc':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('description'),}
    AOnquyUgXawJokpcdhzTSfrtWLKQxs.append(AOnquyUgXawJokpcdhzTSfrtWLKQxB)
  except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
   AOnquyUgXawJokpcdhzTSfrtWLKQmI(exception)
   return[]
  return AOnquyUgXawJokpcdhzTSfrtWLKQxs
 def Get_Episode_List(AOnquyUgXawJokpcdhzTSfrtWLKQsP,programId,season,page=1,orderby='asc'):
  AOnquyUgXawJokpcdhzTSfrtWLKQxs=[] 
  AOnquyUgXawJokpcdhzTSfrtWLKQxC=AOnquyUgXawJokpcdhzTSfrtWLKQmj
  try:
   AOnquyUgXawJokpcdhzTSfrtWLKQRH=AOnquyUgXawJokpcdhzTSfrtWLKQsP.API_DOMAIN+'/api-discover/v2/discover/titles/'+programId+'/episodes'
   AOnquyUgXawJokpcdhzTSfrtWLKQxR={'seasonRange':'{}~{}'.format(season,season),'page':AOnquyUgXawJokpcdhzTSfrtWLKQmV(page),'overrideSortOrder':orderby,'titleId':programId,'locale':'ko','perPage':AOnquyUgXawJokpcdhzTSfrtWLKQmV(AOnquyUgXawJokpcdhzTSfrtWLKQsP.PAGE_LIMIT),'disableCache':'false','includeChannelContents':'false','platform':'WEBCLIENT','sort':'true',}
   AOnquyUgXawJokpcdhzTSfrtWLKQRx={'x-membersrl':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['COOKIES']['member_srl'],'x-pcid':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['COOKIES']['PCID'],'x-profileid':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT','x-app-version':AOnquyUgXawJokpcdhzTSfrtWLKQsP.x_app_version,}
   AOnquyUgXawJokpcdhzTSfrtWLKQRY=AOnquyUgXawJokpcdhzTSfrtWLKQsP.callRequestCookies('Get',AOnquyUgXawJokpcdhzTSfrtWLKQRH,payload=AOnquyUgXawJokpcdhzTSfrtWLKQmF,params=AOnquyUgXawJokpcdhzTSfrtWLKQxR,headers=AOnquyUgXawJokpcdhzTSfrtWLKQmF,cookies=AOnquyUgXawJokpcdhzTSfrtWLKQmF,redirects=AOnquyUgXawJokpcdhzTSfrtWLKQlP)
   if AOnquyUgXawJokpcdhzTSfrtWLKQRY.status_code not in[200]:return[],AOnquyUgXawJokpcdhzTSfrtWLKQmj
   AOnquyUgXawJokpcdhzTSfrtWLKQRj=json.loads(AOnquyUgXawJokpcdhzTSfrtWLKQRY.text)
   for AOnquyUgXawJokpcdhzTSfrtWLKQxl in AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('data'):
    AOnquyUgXawJokpcdhzTSfrtWLKQxG=''
    if 'story-art' in AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('images'):AOnquyUgXawJokpcdhzTSfrtWLKQxG =AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('images').get('story-art').get('url')+'?imwidth=600'
    AOnquyUgXawJokpcdhzTSfrtWLKQxN =[]
    for AOnquyUgXawJokpcdhzTSfrtWLKQxM in AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('tags'):
     AOnquyUgXawJokpcdhzTSfrtWLKQxN.append(AOnquyUgXawJokpcdhzTSfrtWLKQxM.get('tag'))
    AOnquyUgXawJokpcdhzTSfrtWLKQxB={'id':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('id'),'title':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('title'),'thumbnail':{'thumb':AOnquyUgXawJokpcdhzTSfrtWLKQxG,'fanart':AOnquyUgXawJokpcdhzTSfrtWLKQxG},'mpaa':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('age_rating'),'duration':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('running_time'),'asis':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('as'),'year':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('meta').get('releaseYear'),'episode':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('episode'),'genreList':AOnquyUgXawJokpcdhzTSfrtWLKQxN,'desc':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('description'),}
    AOnquyUgXawJokpcdhzTSfrtWLKQxs.append(AOnquyUgXawJokpcdhzTSfrtWLKQxB)
   if AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('pagination').get('totalPages')>page:
    AOnquyUgXawJokpcdhzTSfrtWLKQxC=AOnquyUgXawJokpcdhzTSfrtWLKQlP
  except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
   AOnquyUgXawJokpcdhzTSfrtWLKQmI(exception)
   return[]
  return AOnquyUgXawJokpcdhzTSfrtWLKQxs,AOnquyUgXawJokpcdhzTSfrtWLKQxC
 def Get_vInfo(AOnquyUgXawJokpcdhzTSfrtWLKQsP,titleId):
  try:
   AOnquyUgXawJokpcdhzTSfrtWLKQRH=AOnquyUgXawJokpcdhzTSfrtWLKQsP.API_DOMAIN+'/api-discover/v1/discover/titles/'+titleId 
   AOnquyUgXawJokpcdhzTSfrtWLKQxR={'platform':'WEBCLIENT','locale':'ko','filterRestrictedContent':'false',}
   AOnquyUgXawJokpcdhzTSfrtWLKQRY=AOnquyUgXawJokpcdhzTSfrtWLKQsP.callRequestCookies('Get',AOnquyUgXawJokpcdhzTSfrtWLKQRH,payload=AOnquyUgXawJokpcdhzTSfrtWLKQmF,params=AOnquyUgXawJokpcdhzTSfrtWLKQxR,headers=AOnquyUgXawJokpcdhzTSfrtWLKQmF,cookies=AOnquyUgXawJokpcdhzTSfrtWLKQmF,redirects=AOnquyUgXawJokpcdhzTSfrtWLKQlP)
   if AOnquyUgXawJokpcdhzTSfrtWLKQRY.status_code not in[200]:return '','',''
   AOnquyUgXawJokpcdhzTSfrtWLKQRj=json.loads(AOnquyUgXawJokpcdhzTSfrtWLKQRY.text).get('data')
   AOnquyUgXawJokpcdhzTSfrtWLKQxY=''
   if AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('seasonList')!=AOnquyUgXawJokpcdhzTSfrtWLKQmF:
    AOnquyUgXawJokpcdhzTSfrtWLKQxY=','.join(AOnquyUgXawJokpcdhzTSfrtWLKQmV(e)for e in AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('seasonList'))
   AOnquyUgXawJokpcdhzTSfrtWLKQxi={'age_rating':AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('age_rating'),'asset_id':AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('asset_id'),'availability':AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('availability'),'deal_id':AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('deal_id'),'downloadable':'true' if AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('downloadable')else 'false','region':AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('region'),'streamable':'true' if AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('streamable')else 'false','asis':AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('as'),'seasonList':AOnquyUgXawJokpcdhzTSfrtWLKQxY}
  except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
   AOnquyUgXawJokpcdhzTSfrtWLKQmI(exception)
   return{}
  return AOnquyUgXawJokpcdhzTSfrtWLKQxi
 def Get_eInfo(AOnquyUgXawJokpcdhzTSfrtWLKQsP,eventId):
  try:
   AOnquyUgXawJokpcdhzTSfrtWLKQRH=AOnquyUgXawJokpcdhzTSfrtWLKQsP.API_DOMAIN+'/api-discover/v1/discover/events/'+eventId 
   AOnquyUgXawJokpcdhzTSfrtWLKQxR={'locale':'ko','platform':'WEBCLIENT','includeSportsChannelContents':'true',}
   AOnquyUgXawJokpcdhzTSfrtWLKQRY=AOnquyUgXawJokpcdhzTSfrtWLKQsP.callRequestCookies('Get',AOnquyUgXawJokpcdhzTSfrtWLKQRH,payload=AOnquyUgXawJokpcdhzTSfrtWLKQmF,params=AOnquyUgXawJokpcdhzTSfrtWLKQxR,headers=AOnquyUgXawJokpcdhzTSfrtWLKQmF,cookies=AOnquyUgXawJokpcdhzTSfrtWLKQmF,redirects=AOnquyUgXawJokpcdhzTSfrtWLKQlP)
   if AOnquyUgXawJokpcdhzTSfrtWLKQRY.status_code not in[200]:return '','',''
   AOnquyUgXawJokpcdhzTSfrtWLKQRj=json.loads(AOnquyUgXawJokpcdhzTSfrtWLKQRY.text).get('data')
   AOnquyUgXawJokpcdhzTSfrtWLKQxi={'asset_id':AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('asset_id'),'deal_id':AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('deal_id'),'region':AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('region'),'streamable':'true' if AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('streamable')else 'false',}
  except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
   AOnquyUgXawJokpcdhzTSfrtWLKQmI(exception)
   return{}
  return AOnquyUgXawJokpcdhzTSfrtWLKQxi
 def GetBroadURL(AOnquyUgXawJokpcdhzTSfrtWLKQsP,titleId):
  AOnquyUgXawJokpcdhzTSfrtWLKQxF=''
  AOnquyUgXawJokpcdhzTSfrtWLKQxj =''
  AOnquyUgXawJokpcdhzTSfrtWLKQxi=AOnquyUgXawJokpcdhzTSfrtWLKQsP.Get_vInfo(titleId)
  if AOnquyUgXawJokpcdhzTSfrtWLKQxi=={}:return '',''
  try:
   AOnquyUgXawJokpcdhzTSfrtWLKQRH=AOnquyUgXawJokpcdhzTSfrtWLKQsP.API_DOMAIN+'/api/playback/play' 
   AOnquyUgXawJokpcdhzTSfrtWLKQxR={'titleId':titleId}
   AOnquyUgXawJokpcdhzTSfrtWLKQRm,AOnquyUgXawJokpcdhzTSfrtWLKQRl,AOnquyUgXawJokpcdhzTSfrtWLKQRb=AOnquyUgXawJokpcdhzTSfrtWLKQsP.Make_authHeader()
   AOnquyUgXawJokpcdhzTSfrtWLKQRx={'traceparent':AOnquyUgXawJokpcdhzTSfrtWLKQRm,'tracestate':AOnquyUgXawJokpcdhzTSfrtWLKQRl,'newrelic':AOnquyUgXawJokpcdhzTSfrtWLKQRb,'x-drm':'com.microsoft.playready','x-app-version':AOnquyUgXawJokpcdhzTSfrtWLKQsP.x_app_version,'x-device-id':'','x-device-os-version':AOnquyUgXawJokpcdhzTSfrtWLKQsP.OS_VERSION,'x-force-raw':'true','x-nr-session-id':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['COOKIES']['session_web_id'],'x-pcid':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['COOKIES']['PCID'],'x-platform':'web','x-profileId':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['SESSION']['profileId'],'x-profileType':'standard','x-sessionid':AOnquyUgXawJokpcdhzTSfrtWLKQsP.generatePvId(genType='1'),'x-title-age-rating':AOnquyUgXawJokpcdhzTSfrtWLKQxi.get('age_rating'),'x-title-availability':AOnquyUgXawJokpcdhzTSfrtWLKQxi.get('availability'),'x-title-brightcove-id':AOnquyUgXawJokpcdhzTSfrtWLKQxi.get('asset_id'),'x-title-deal-id':AOnquyUgXawJokpcdhzTSfrtWLKQxi.get('deal_id'),'x-title-downloadable':AOnquyUgXawJokpcdhzTSfrtWLKQxi.get('downloadable'),'x-title-region':AOnquyUgXawJokpcdhzTSfrtWLKQxi.get('region'),'x-title-streamable':AOnquyUgXawJokpcdhzTSfrtWLKQxi.get('streamable'),}
   AOnquyUgXawJokpcdhzTSfrtWLKQRv=AOnquyUgXawJokpcdhzTSfrtWLKQsP.make_CP_DefaultCookies()
   AOnquyUgXawJokpcdhzTSfrtWLKQRY=AOnquyUgXawJokpcdhzTSfrtWLKQsP.callRequestCookies('Get',AOnquyUgXawJokpcdhzTSfrtWLKQRH,payload=AOnquyUgXawJokpcdhzTSfrtWLKQmF,params=AOnquyUgXawJokpcdhzTSfrtWLKQxR,headers=AOnquyUgXawJokpcdhzTSfrtWLKQRx,cookies=AOnquyUgXawJokpcdhzTSfrtWLKQRv,redirects=AOnquyUgXawJokpcdhzTSfrtWLKQlP)
   if AOnquyUgXawJokpcdhzTSfrtWLKQRY.status_code not in[200]:return '',json.loads(AOnquyUgXawJokpcdhzTSfrtWLKQRY.text).get('error').get('detail')
   AOnquyUgXawJokpcdhzTSfrtWLKQRj=json.loads(AOnquyUgXawJokpcdhzTSfrtWLKQRY.text)
   if AOnquyUgXawJokpcdhzTSfrtWLKQxF=='':
    for AOnquyUgXawJokpcdhzTSfrtWLKQxl in AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('data').get('raw').get('sources'):
     if 'key_systems' in AOnquyUgXawJokpcdhzTSfrtWLKQxl and 'codecs' not in AOnquyUgXawJokpcdhzTSfrtWLKQxl:
      if AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('type')=='application/dash+xml' and 'com.widevine.alpha' in AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('key_systems')and AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('src').startswith('https://')==AOnquyUgXawJokpcdhzTSfrtWLKQlP:
       AOnquyUgXawJokpcdhzTSfrtWLKQxF=AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('src')
       AOnquyUgXawJokpcdhzTSfrtWLKQxj =AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if AOnquyUgXawJokpcdhzTSfrtWLKQxF=='':
    for AOnquyUgXawJokpcdhzTSfrtWLKQxl in AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('data').get('raw').get('sources'):
     if 'key_systems' in AOnquyUgXawJokpcdhzTSfrtWLKQxl and 'codecs' not in AOnquyUgXawJokpcdhzTSfrtWLKQxl:
      if AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('key_systems')and AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('src').startswith('https://')==AOnquyUgXawJokpcdhzTSfrtWLKQlP:
       AOnquyUgXawJokpcdhzTSfrtWLKQxF=AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('src')
       AOnquyUgXawJokpcdhzTSfrtWLKQxj =AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if AOnquyUgXawJokpcdhzTSfrtWLKQxF=='':
    for AOnquyUgXawJokpcdhzTSfrtWLKQxl in AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('data').get('raw').get('sources'):
     if 'key_systems' in AOnquyUgXawJokpcdhzTSfrtWLKQxl and 'codecs' in AOnquyUgXawJokpcdhzTSfrtWLKQxl:
      if AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('type')=='application/dash+xml' and 'com.widevine.alpha' in AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('key_systems')and AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('src').startswith('https://')==AOnquyUgXawJokpcdhzTSfrtWLKQlP:
       AOnquyUgXawJokpcdhzTSfrtWLKQxF=AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('src')
       AOnquyUgXawJokpcdhzTSfrtWLKQxj =AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if AOnquyUgXawJokpcdhzTSfrtWLKQxF=='':
    for AOnquyUgXawJokpcdhzTSfrtWLKQxl in AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('data').get('raw').get('sources'):
     if 'key_systems' in AOnquyUgXawJokpcdhzTSfrtWLKQxl and 'codecs' in AOnquyUgXawJokpcdhzTSfrtWLKQxl:
      if AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('key_systems')and AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('src').startswith('https://')==AOnquyUgXawJokpcdhzTSfrtWLKQlP:
       AOnquyUgXawJokpcdhzTSfrtWLKQxF=AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('src')
       AOnquyUgXawJokpcdhzTSfrtWLKQxj =AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
  except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
   AOnquyUgXawJokpcdhzTSfrtWLKQmI(exception)
   return '',''
  return AOnquyUgXawJokpcdhzTSfrtWLKQxF,AOnquyUgXawJokpcdhzTSfrtWLKQxj
 def GetEventURL(AOnquyUgXawJokpcdhzTSfrtWLKQsP,eventId,AOnquyUgXawJokpcdhzTSfrtWLKQPb):
  AOnquyUgXawJokpcdhzTSfrtWLKQxF=''
  AOnquyUgXawJokpcdhzTSfrtWLKQxj =''
  AOnquyUgXawJokpcdhzTSfrtWLKQxi=AOnquyUgXawJokpcdhzTSfrtWLKQsP.Get_eInfo(eventId)
  if AOnquyUgXawJokpcdhzTSfrtWLKQxi=={}:return '',''
  try:
   AOnquyUgXawJokpcdhzTSfrtWLKQRH=AOnquyUgXawJokpcdhzTSfrtWLKQsP.API_DOMAIN+'/api/playback/play' 
   AOnquyUgXawJokpcdhzTSfrtWLKQxR={'titleId':eventId,'titleType':AOnquyUgXawJokpcdhzTSfrtWLKQPb,}
   AOnquyUgXawJokpcdhzTSfrtWLKQRm,AOnquyUgXawJokpcdhzTSfrtWLKQRl,AOnquyUgXawJokpcdhzTSfrtWLKQRb=AOnquyUgXawJokpcdhzTSfrtWLKQsP.Make_authHeader()
   AOnquyUgXawJokpcdhzTSfrtWLKQRx={'traceparent':AOnquyUgXawJokpcdhzTSfrtWLKQRm,'tracestate':AOnquyUgXawJokpcdhzTSfrtWLKQRl,'newrelic':AOnquyUgXawJokpcdhzTSfrtWLKQRb,'x-force-raw':'true','x-pcid':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['COOKIES']['PCID'],'x-platform':'web','x-profileId':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-downloadable':'undefined','x-title-brightcove-id':AOnquyUgXawJokpcdhzTSfrtWLKQxi.get('asset_id'),'x-title-deal-id':AOnquyUgXawJokpcdhzTSfrtWLKQxi.get('deal_id'),'x-title-region':AOnquyUgXawJokpcdhzTSfrtWLKQxi.get('region'),'x-title-streamable':AOnquyUgXawJokpcdhzTSfrtWLKQxi.get('streamable'),}
   AOnquyUgXawJokpcdhzTSfrtWLKQRv=AOnquyUgXawJokpcdhzTSfrtWLKQsP.make_CP_DefaultCookies()
   AOnquyUgXawJokpcdhzTSfrtWLKQRY=AOnquyUgXawJokpcdhzTSfrtWLKQsP.callRequestCookies('Get',AOnquyUgXawJokpcdhzTSfrtWLKQRH,payload=AOnquyUgXawJokpcdhzTSfrtWLKQmF,params=AOnquyUgXawJokpcdhzTSfrtWLKQxR,headers=AOnquyUgXawJokpcdhzTSfrtWLKQRx,cookies=AOnquyUgXawJokpcdhzTSfrtWLKQRv,redirects=AOnquyUgXawJokpcdhzTSfrtWLKQlP)
   if AOnquyUgXawJokpcdhzTSfrtWLKQRY.status_code not in[200]:return '',json.loads(AOnquyUgXawJokpcdhzTSfrtWLKQRY.text).get('error').get('detail')
   AOnquyUgXawJokpcdhzTSfrtWLKQRj=json.loads(AOnquyUgXawJokpcdhzTSfrtWLKQRY.text)
   for AOnquyUgXawJokpcdhzTSfrtWLKQxl in AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('data').get('raw').get('sources'):
    if AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('type')=='application/dash+xml' and AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('src')[0:8]=='https://':
     AOnquyUgXawJokpcdhzTSfrtWLKQxF=AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('src')
     if 'key_systems' in AOnquyUgXawJokpcdhzTSfrtWLKQxl:
      AOnquyUgXawJokpcdhzTSfrtWLKQxj =AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('key_systems').get('com.widevine.alpha').get('license_url')
     break
  except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
   AOnquyUgXawJokpcdhzTSfrtWLKQmI(exception)
   return '',''
  return AOnquyUgXawJokpcdhzTSfrtWLKQxF,AOnquyUgXawJokpcdhzTSfrtWLKQxj
 def GetEventURL_Live(AOnquyUgXawJokpcdhzTSfrtWLKQsP,eventId,AOnquyUgXawJokpcdhzTSfrtWLKQPb):
  AOnquyUgXawJokpcdhzTSfrtWLKQxF=''
  AOnquyUgXawJokpcdhzTSfrtWLKQxj =''
  AOnquyUgXawJokpcdhzTSfrtWLKQxi=AOnquyUgXawJokpcdhzTSfrtWLKQsP.Get_eInfo(eventId)
  if AOnquyUgXawJokpcdhzTSfrtWLKQxi=={}:return '',''
  try:
   AOnquyUgXawJokpcdhzTSfrtWLKQRH=AOnquyUgXawJokpcdhzTSfrtWLKQsP.API_DOMAIN+'/api/playback/play' 
   AOnquyUgXawJokpcdhzTSfrtWLKQxR={'titleId':eventId,'titleType':AOnquyUgXawJokpcdhzTSfrtWLKQPb,}
   AOnquyUgXawJokpcdhzTSfrtWLKQRm,AOnquyUgXawJokpcdhzTSfrtWLKQRl,AOnquyUgXawJokpcdhzTSfrtWLKQRb=AOnquyUgXawJokpcdhzTSfrtWLKQsP.Make_authHeader()
   AOnquyUgXawJokpcdhzTSfrtWLKQRx={'traceparent':AOnquyUgXawJokpcdhzTSfrtWLKQRm,'tracestate':AOnquyUgXawJokpcdhzTSfrtWLKQRl,'newrelic':AOnquyUgXawJokpcdhzTSfrtWLKQRb,'x-force-raw':'true','x-pcid':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['COOKIES']['PCID'],'x-platform':'web','x-profileId':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':AOnquyUgXawJokpcdhzTSfrtWLKQxi.get('asset_id'),'x-title-deal-id':AOnquyUgXawJokpcdhzTSfrtWLKQxi.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':AOnquyUgXawJokpcdhzTSfrtWLKQxi.get('region'),'x-title-streamable':AOnquyUgXawJokpcdhzTSfrtWLKQxi.get('streamable'),}
   AOnquyUgXawJokpcdhzTSfrtWLKQRv=AOnquyUgXawJokpcdhzTSfrtWLKQsP.make_CP_DefaultCookies()
   AOnquyUgXawJokpcdhzTSfrtWLKQRY=AOnquyUgXawJokpcdhzTSfrtWLKQsP.callRequestCookies('Get',AOnquyUgXawJokpcdhzTSfrtWLKQRH,payload=AOnquyUgXawJokpcdhzTSfrtWLKQmF,params=AOnquyUgXawJokpcdhzTSfrtWLKQxR,headers=AOnquyUgXawJokpcdhzTSfrtWLKQRx,cookies=AOnquyUgXawJokpcdhzTSfrtWLKQRv,redirects=AOnquyUgXawJokpcdhzTSfrtWLKQlP)
   if AOnquyUgXawJokpcdhzTSfrtWLKQRY.status_code not in[200]:return '',json.loads(AOnquyUgXawJokpcdhzTSfrtWLKQRY.text).get('error').get('detail')
   AOnquyUgXawJokpcdhzTSfrtWLKQRj=json.loads(AOnquyUgXawJokpcdhzTSfrtWLKQRY.text)
   if AOnquyUgXawJokpcdhzTSfrtWLKQxF=='':
    for AOnquyUgXawJokpcdhzTSfrtWLKQxl in AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('data').get('raw').get('sources'):
     if 'key_systems' in AOnquyUgXawJokpcdhzTSfrtWLKQxl:
      if AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('type')=='application/dash+xml' and 'com.widevine.alpha' in AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('key_systems')and AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('src').startswith('https://')==AOnquyUgXawJokpcdhzTSfrtWLKQlP:
       AOnquyUgXawJokpcdhzTSfrtWLKQxF=AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('src')
       AOnquyUgXawJokpcdhzTSfrtWLKQxj =AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('key_systems').get('com.widevine.alpha').get('license_url')
   if AOnquyUgXawJokpcdhzTSfrtWLKQxF=='':
    for AOnquyUgXawJokpcdhzTSfrtWLKQxl in AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('data').get('raw').get('sources'):
     if 'key_systems' in AOnquyUgXawJokpcdhzTSfrtWLKQxl:
      if AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('key_systems')and AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('src').startswith('https://')==AOnquyUgXawJokpcdhzTSfrtWLKQlP:
       AOnquyUgXawJokpcdhzTSfrtWLKQxF=AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('src')
       AOnquyUgXawJokpcdhzTSfrtWLKQxj =AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('key_systems').get('com.widevine.alpha').get('license_url')
   if AOnquyUgXawJokpcdhzTSfrtWLKQxF=='':
    for AOnquyUgXawJokpcdhzTSfrtWLKQxl in AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('data').get('raw').get('sources'):
     if AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('type')=='application/dash+xml' and AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('src').startswith('https://')==AOnquyUgXawJokpcdhzTSfrtWLKQlP:
      AOnquyUgXawJokpcdhzTSfrtWLKQxF=AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('src')
   if AOnquyUgXawJokpcdhzTSfrtWLKQxF=='':
    for AOnquyUgXawJokpcdhzTSfrtWLKQxl in AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('data').get('raw').get('sources'):
     if AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('type')=='application/x-mpegURL' and AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('src').startswith('https://')==AOnquyUgXawJokpcdhzTSfrtWLKQlP:
      AOnquyUgXawJokpcdhzTSfrtWLKQxF=AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('src')
  except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
   AOnquyUgXawJokpcdhzTSfrtWLKQmI(exception)
   return '',''
  return AOnquyUgXawJokpcdhzTSfrtWLKQxF,AOnquyUgXawJokpcdhzTSfrtWLKQxj
 def Get_Url_PostFix(AOnquyUgXawJokpcdhzTSfrtWLKQsP,in_url):
  AOnquyUgXawJokpcdhzTSfrtWLKQxI=urllib.parse.urlparse(in_url) 
  AOnquyUgXawJokpcdhzTSfrtWLKQxV =AOnquyUgXawJokpcdhzTSfrtWLKQxI.path.strip('/').split('/')
  AOnquyUgXawJokpcdhzTSfrtWLKQxe =AOnquyUgXawJokpcdhzTSfrtWLKQxV[AOnquyUgXawJokpcdhzTSfrtWLKQlR(AOnquyUgXawJokpcdhzTSfrtWLKQxV)-1]
  AOnquyUgXawJokpcdhzTSfrtWLKQxE=AOnquyUgXawJokpcdhzTSfrtWLKQxe.split('.')
  return AOnquyUgXawJokpcdhzTSfrtWLKQxE[AOnquyUgXawJokpcdhzTSfrtWLKQlR(AOnquyUgXawJokpcdhzTSfrtWLKQxE)-1]
 def Get_Theme_GroupList(AOnquyUgXawJokpcdhzTSfrtWLKQsP,vType):
  AOnquyUgXawJokpcdhzTSfrtWLKQxs=[] 
  try:
   AOnquyUgXawJokpcdhzTSfrtWLKQRH=AOnquyUgXawJokpcdhzTSfrtWLKQsP.API_DOMAIN+'/api-discover/v3/discover/feed' 
   AOnquyUgXawJokpcdhzTSfrtWLKQxR={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':AOnquyUgXawJokpcdhzTSfrtWLKQmV(AOnquyUgXawJokpcdhzTSfrtWLKQsP.PAGE_LIMIT),'filterRestrictedContent':'false','preferRecoFeed':'true','preferMultiHeroMixedContentRow':'true','shouldIncludeTVOD':'true','includeChannelContents':'false',}
   AOnquyUgXawJokpcdhzTSfrtWLKQRY=AOnquyUgXawJokpcdhzTSfrtWLKQsP.callRequestCookies('Get',AOnquyUgXawJokpcdhzTSfrtWLKQRH,payload=AOnquyUgXawJokpcdhzTSfrtWLKQmF,params=AOnquyUgXawJokpcdhzTSfrtWLKQxR,headers=AOnquyUgXawJokpcdhzTSfrtWLKQmF,cookies=AOnquyUgXawJokpcdhzTSfrtWLKQmF,redirects=AOnquyUgXawJokpcdhzTSfrtWLKQlP)
   if AOnquyUgXawJokpcdhzTSfrtWLKQRY.status_code not in[200]:return[]
   AOnquyUgXawJokpcdhzTSfrtWLKQRj=json.loads(AOnquyUgXawJokpcdhzTSfrtWLKQRY.text)
   for AOnquyUgXawJokpcdhzTSfrtWLKQxl in AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('data'):
    if AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('type')=='Title-Rails-Curation':
     AOnquyUgXawJokpcdhzTSfrtWLKQPs =''
     AOnquyUgXawJokpcdhzTSfrtWLKQPR=7
     try:
      for i in AOnquyUgXawJokpcdhzTSfrtWLKQlm(AOnquyUgXawJokpcdhzTSfrtWLKQlR(AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('data'))):
       if i>=AOnquyUgXawJokpcdhzTSfrtWLKQPR:
        AOnquyUgXawJokpcdhzTSfrtWLKQPs=AOnquyUgXawJokpcdhzTSfrtWLKQPs+'...'
        break
       AOnquyUgXawJokpcdhzTSfrtWLKQPs=AOnquyUgXawJokpcdhzTSfrtWLKQPs+AOnquyUgXawJokpcdhzTSfrtWLKQxl['data'][i]['title']+'\n'
     except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
      AOnquyUgXawJokpcdhzTSfrtWLKQmI(exception)
     AOnquyUgXawJokpcdhzTSfrtWLKQxB={'collectionId':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('obj_id'),'title':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('row_name'),'category':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('category'),'pre_title':AOnquyUgXawJokpcdhzTSfrtWLKQPs,}
     AOnquyUgXawJokpcdhzTSfrtWLKQxs.append(AOnquyUgXawJokpcdhzTSfrtWLKQxB)
  except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
   AOnquyUgXawJokpcdhzTSfrtWLKQmI(exception)
   return[]
  return AOnquyUgXawJokpcdhzTSfrtWLKQxs
 def Get_Event_GroupList(AOnquyUgXawJokpcdhzTSfrtWLKQsP):
  AOnquyUgXawJokpcdhzTSfrtWLKQxs=[] 
  try:
   AOnquyUgXawJokpcdhzTSfrtWLKQRH=AOnquyUgXawJokpcdhzTSfrtWLKQsP.API_DOMAIN+'/api-discover/v3/discover/feed' 
   AOnquyUgXawJokpcdhzTSfrtWLKQxR={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':7,'filterRestrictedContent':'false','preferRecoFeed':'true','preferMultiHeroMixedContentRow':'true','shouldIncludeTVOD':'true','includeChannelContents':'false',}
   AOnquyUgXawJokpcdhzTSfrtWLKQRY=AOnquyUgXawJokpcdhzTSfrtWLKQsP.callRequestCookies('Get',AOnquyUgXawJokpcdhzTSfrtWLKQRH,payload=AOnquyUgXawJokpcdhzTSfrtWLKQmF,params=AOnquyUgXawJokpcdhzTSfrtWLKQxR,headers=AOnquyUgXawJokpcdhzTSfrtWLKQmF,cookies=AOnquyUgXawJokpcdhzTSfrtWLKQmF,redirects=AOnquyUgXawJokpcdhzTSfrtWLKQlP)
   if AOnquyUgXawJokpcdhzTSfrtWLKQRY.status_code not in[200]:return[]
   AOnquyUgXawJokpcdhzTSfrtWLKQRj=json.loads(AOnquyUgXawJokpcdhzTSfrtWLKQRY.text)
   for AOnquyUgXawJokpcdhzTSfrtWLKQxl in AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('data'):
    if AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('row_name').strip()!='':
     AOnquyUgXawJokpcdhzTSfrtWLKQPs =''
     AOnquyUgXawJokpcdhzTSfrtWLKQPR=7
     try:
      for i in AOnquyUgXawJokpcdhzTSfrtWLKQlm(AOnquyUgXawJokpcdhzTSfrtWLKQlR(AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('data'))):
       if i>=AOnquyUgXawJokpcdhzTSfrtWLKQPR:
        AOnquyUgXawJokpcdhzTSfrtWLKQPs=AOnquyUgXawJokpcdhzTSfrtWLKQPs+'...'
        break
       AOnquyUgXawJokpcdhzTSfrtWLKQPs=AOnquyUgXawJokpcdhzTSfrtWLKQPs+AOnquyUgXawJokpcdhzTSfrtWLKQxl['data'][i]['title']+'\n'
     except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
      AOnquyUgXawJokpcdhzTSfrtWLKQmI(exception)
     AOnquyUgXawJokpcdhzTSfrtWLKQxB={'collectionId':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('obj_id'),'title':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('row_name'),'category':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('type'),'pre_title':AOnquyUgXawJokpcdhzTSfrtWLKQPs,}
     AOnquyUgXawJokpcdhzTSfrtWLKQxs.append(AOnquyUgXawJokpcdhzTSfrtWLKQxB)
  except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
   AOnquyUgXawJokpcdhzTSfrtWLKQmI(exception)
   return[]
  return AOnquyUgXawJokpcdhzTSfrtWLKQxs
 def Get_Event_GameList(AOnquyUgXawJokpcdhzTSfrtWLKQsP,AOnquyUgXawJokpcdhzTSfrtWLKQxb):
  AOnquyUgXawJokpcdhzTSfrtWLKQxs=[] 
  try:
   AOnquyUgXawJokpcdhzTSfrtWLKQRH=AOnquyUgXawJokpcdhzTSfrtWLKQsP.API_DOMAIN+'/api-discover/v3/discover/feed' 
   AOnquyUgXawJokpcdhzTSfrtWLKQxR={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':7,'filterRestrictedContent':'false','preferRecoFeed':'true','preferMultiHeroMixedContentRow':'true','shouldIncludeTVOD':'true','includeChannelContents':'false',}
   AOnquyUgXawJokpcdhzTSfrtWLKQRY=AOnquyUgXawJokpcdhzTSfrtWLKQsP.callRequestCookies('Get',AOnquyUgXawJokpcdhzTSfrtWLKQRH,payload=AOnquyUgXawJokpcdhzTSfrtWLKQmF,params=AOnquyUgXawJokpcdhzTSfrtWLKQxR,headers=AOnquyUgXawJokpcdhzTSfrtWLKQmF,cookies=AOnquyUgXawJokpcdhzTSfrtWLKQmF,redirects=AOnquyUgXawJokpcdhzTSfrtWLKQlP)
   if AOnquyUgXawJokpcdhzTSfrtWLKQRY.status_code not in[200]:return[]
   AOnquyUgXawJokpcdhzTSfrtWLKQRj=json.loads(AOnquyUgXawJokpcdhzTSfrtWLKQRY.text)
   for AOnquyUgXawJokpcdhzTSfrtWLKQxl in AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('data'):
    if AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('obj_id')==AOnquyUgXawJokpcdhzTSfrtWLKQxb:
     for AOnquyUgXawJokpcdhzTSfrtWLKQPx in AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('data'):
      AOnquyUgXawJokpcdhzTSfrtWLKQxH=AOnquyUgXawJokpcdhzTSfrtWLKQxG=AOnquyUgXawJokpcdhzTSfrtWLKQPv=''
      if 'poster_url' in AOnquyUgXawJokpcdhzTSfrtWLKQPx.get('images'):AOnquyUgXawJokpcdhzTSfrtWLKQxH =AOnquyUgXawJokpcdhzTSfrtWLKQPx.get('images').get('poster_url') +'?imwidth=350'
      if 'story_art_url' in AOnquyUgXawJokpcdhzTSfrtWLKQPx.get('images'):AOnquyUgXawJokpcdhzTSfrtWLKQxG =AOnquyUgXawJokpcdhzTSfrtWLKQPx.get('images').get('story_art_url')+'?imwidth=600'
      if 'hero_url' in AOnquyUgXawJokpcdhzTSfrtWLKQPx.get('images'):AOnquyUgXawJokpcdhzTSfrtWLKQPv =AOnquyUgXawJokpcdhzTSfrtWLKQPx.get('images').get('hero_url') +'?imwidth=600'
      AOnquyUgXawJokpcdhzTSfrtWLKQxB={'id':AOnquyUgXawJokpcdhzTSfrtWLKQPx.get('id'),'title':AOnquyUgXawJokpcdhzTSfrtWLKQPx.get('title'),'thumbnail':{'poster':AOnquyUgXawJokpcdhzTSfrtWLKQxH,'thumb':AOnquyUgXawJokpcdhzTSfrtWLKQxG,'fanart':AOnquyUgXawJokpcdhzTSfrtWLKQPv},'asis':AOnquyUgXawJokpcdhzTSfrtWLKQPx.get('type'),'starttm':AOnquyUgXawJokpcdhzTSfrtWLKQsP.convert_TimeStr(AOnquyUgXawJokpcdhzTSfrtWLKQPx.get('startAt')),}
      AOnquyUgXawJokpcdhzTSfrtWLKQxs.append(AOnquyUgXawJokpcdhzTSfrtWLKQxB)
  except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
   AOnquyUgXawJokpcdhzTSfrtWLKQmI(exception)
   return[]
  return AOnquyUgXawJokpcdhzTSfrtWLKQxs
 def Get_Event_List(AOnquyUgXawJokpcdhzTSfrtWLKQsP,gameId):
  AOnquyUgXawJokpcdhzTSfrtWLKQxs=[] 
  try:
   AOnquyUgXawJokpcdhzTSfrtWLKQRH=AOnquyUgXawJokpcdhzTSfrtWLKQsP.API_DOMAIN+'/api-discover/v1/discover/events/'+gameId 
   AOnquyUgXawJokpcdhzTSfrtWLKQxR={'platform':'WEBCLIENT','locale':'ko','filterRestrictedContent':'false',}
   AOnquyUgXawJokpcdhzTSfrtWLKQRY=AOnquyUgXawJokpcdhzTSfrtWLKQsP.callRequestCookies('Get',AOnquyUgXawJokpcdhzTSfrtWLKQRH,payload=AOnquyUgXawJokpcdhzTSfrtWLKQmF,params=AOnquyUgXawJokpcdhzTSfrtWLKQxR,headers=AOnquyUgXawJokpcdhzTSfrtWLKQmF,cookies=AOnquyUgXawJokpcdhzTSfrtWLKQmF,redirects=AOnquyUgXawJokpcdhzTSfrtWLKQlP)
   if AOnquyUgXawJokpcdhzTSfrtWLKQRY.status_code not in[200]:return[]
   AOnquyUgXawJokpcdhzTSfrtWLKQRj=json.loads(AOnquyUgXawJokpcdhzTSfrtWLKQRY.text)
   AOnquyUgXawJokpcdhzTSfrtWLKQxl=AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('data')
   AOnquyUgXawJokpcdhzTSfrtWLKQPm=AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('end_at')
   AOnquyUgXawJokpcdhzTSfrtWLKQPm=AOnquyUgXawJokpcdhzTSfrtWLKQPm[0:19].replace('-','').replace(':','').replace('T','')
   AOnquyUgXawJokpcdhzTSfrtWLKQPl=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d%H%M%S')
   if AOnquyUgXawJokpcdhzTSfrtWLKQls(AOnquyUgXawJokpcdhzTSfrtWLKQPl)<AOnquyUgXawJokpcdhzTSfrtWLKQls(AOnquyUgXawJokpcdhzTSfrtWLKQPm):
    AOnquyUgXawJokpcdhzTSfrtWLKQxH=AOnquyUgXawJokpcdhzTSfrtWLKQxG=AOnquyUgXawJokpcdhzTSfrtWLKQPv=''
    if 'poster' in AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('images'):AOnquyUgXawJokpcdhzTSfrtWLKQxH =AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('images'):AOnquyUgXawJokpcdhzTSfrtWLKQxG =AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('images').get('story-art').get('url')+'?imwidth=600'
    if 'story-art' in AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('images'):AOnquyUgXawJokpcdhzTSfrtWLKQPv =AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('images').get('story-art').get('url')+'?imwidth=600'
    AOnquyUgXawJokpcdhzTSfrtWLKQxB={'id':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('id'),'title':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('title'),'thumbnail':{'poster':AOnquyUgXawJokpcdhzTSfrtWLKQxH,'thumb':AOnquyUgXawJokpcdhzTSfrtWLKQxG,'fanart':AOnquyUgXawJokpcdhzTSfrtWLKQPv},'duration':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('running_time'),'asis':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('type'),'starttm':AOnquyUgXawJokpcdhzTSfrtWLKQsP.convert_TimeStr(AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('start_at')),}
    AOnquyUgXawJokpcdhzTSfrtWLKQxs.append(AOnquyUgXawJokpcdhzTSfrtWLKQxB)
  except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
   AOnquyUgXawJokpcdhzTSfrtWLKQmI(exception)
   return[]
  try:
   AOnquyUgXawJokpcdhzTSfrtWLKQRH=AOnquyUgXawJokpcdhzTSfrtWLKQsP.API_DOMAIN+'/api-discover/v1/discover/events/'+gameId+'/related' 
   AOnquyUgXawJokpcdhzTSfrtWLKQxR={'locale':'ko','page':'1','perPage':'25','platform':'WEBCLIENT','currentPageTracking':'page_discover_title_detail',}
   AOnquyUgXawJokpcdhzTSfrtWLKQRY=AOnquyUgXawJokpcdhzTSfrtWLKQsP.callRequestCookies('Get',AOnquyUgXawJokpcdhzTSfrtWLKQRH,payload=AOnquyUgXawJokpcdhzTSfrtWLKQmF,params=AOnquyUgXawJokpcdhzTSfrtWLKQxR,headers=AOnquyUgXawJokpcdhzTSfrtWLKQmF,cookies=AOnquyUgXawJokpcdhzTSfrtWLKQmF,redirects=AOnquyUgXawJokpcdhzTSfrtWLKQlP)
   if AOnquyUgXawJokpcdhzTSfrtWLKQRY.status_code not in[200]:return[]
   AOnquyUgXawJokpcdhzTSfrtWLKQRj=json.loads(AOnquyUgXawJokpcdhzTSfrtWLKQRY.text)
   for AOnquyUgXawJokpcdhzTSfrtWLKQxl in AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('data').get('data'):
    AOnquyUgXawJokpcdhzTSfrtWLKQxH=AOnquyUgXawJokpcdhzTSfrtWLKQxG=AOnquyUgXawJokpcdhzTSfrtWLKQPv=''
    if 'poster' in AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('images'):AOnquyUgXawJokpcdhzTSfrtWLKQxH =AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('images'):AOnquyUgXawJokpcdhzTSfrtWLKQxG =AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('images').get('story-art').get('url')+'?imwidth=600'
    if 'story-art' in AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('images'):AOnquyUgXawJokpcdhzTSfrtWLKQPv =AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('images').get('story-art').get('url')+'?imwidth=600'
    AOnquyUgXawJokpcdhzTSfrtWLKQxB={'id':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('id'),'title':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('title'),'thumbnail':{'poster':AOnquyUgXawJokpcdhzTSfrtWLKQxH,'thumb':AOnquyUgXawJokpcdhzTSfrtWLKQxG,'fanart':AOnquyUgXawJokpcdhzTSfrtWLKQPv},'duration':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('running_time'),'asis':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('type'),}
    AOnquyUgXawJokpcdhzTSfrtWLKQxs.append(AOnquyUgXawJokpcdhzTSfrtWLKQxB)
  except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
   AOnquyUgXawJokpcdhzTSfrtWLKQmI(exception)
   return[]
  return AOnquyUgXawJokpcdhzTSfrtWLKQxs
 def Get_Search_List(AOnquyUgXawJokpcdhzTSfrtWLKQsP,search_key,page_int):
  AOnquyUgXawJokpcdhzTSfrtWLKQxs=[] 
  AOnquyUgXawJokpcdhzTSfrtWLKQxC=AOnquyUgXawJokpcdhzTSfrtWLKQmj
  try:
   AOnquyUgXawJokpcdhzTSfrtWLKQRH=AOnquyUgXawJokpcdhzTSfrtWLKQsP.API_DOMAIN+'/api-discover/v2/search' 
   AOnquyUgXawJokpcdhzTSfrtWLKQxR={'query':search_key,'platform':'WEBCLIENT','page':AOnquyUgXawJokpcdhzTSfrtWLKQmV(page_int),'perPage':AOnquyUgXawJokpcdhzTSfrtWLKQmV(AOnquyUgXawJokpcdhzTSfrtWLKQsP.SEARCH_LIMIT),}
   AOnquyUgXawJokpcdhzTSfrtWLKQRx={'x-membersrl':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['COOKIES']['member_srl'],'x-pcid':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['COOKIES']['PCID'],'x-profileid':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT',}
   AOnquyUgXawJokpcdhzTSfrtWLKQRY=AOnquyUgXawJokpcdhzTSfrtWLKQsP.callRequestCookies('Get',AOnquyUgXawJokpcdhzTSfrtWLKQRH,payload=AOnquyUgXawJokpcdhzTSfrtWLKQmF,params=AOnquyUgXawJokpcdhzTSfrtWLKQxR,headers=AOnquyUgXawJokpcdhzTSfrtWLKQRx,cookies=AOnquyUgXawJokpcdhzTSfrtWLKQmF,redirects=AOnquyUgXawJokpcdhzTSfrtWLKQlP)
   if AOnquyUgXawJokpcdhzTSfrtWLKQRY.status_code not in[200]:return[],AOnquyUgXawJokpcdhzTSfrtWLKQmj
   AOnquyUgXawJokpcdhzTSfrtWLKQRj=json.loads(AOnquyUgXawJokpcdhzTSfrtWLKQRY.text)
   for AOnquyUgXawJokpcdhzTSfrtWLKQxl in AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('data').get('data'):
    AOnquyUgXawJokpcdhzTSfrtWLKQxl=AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('data')
    AOnquyUgXawJokpcdhzTSfrtWLKQxH=AOnquyUgXawJokpcdhzTSfrtWLKQxG=AOnquyUgXawJokpcdhzTSfrtWLKQPY=AOnquyUgXawJokpcdhzTSfrtWLKQPv=''
    if 'poster' in AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('images'):AOnquyUgXawJokpcdhzTSfrtWLKQxH =AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('images'):AOnquyUgXawJokpcdhzTSfrtWLKQxG =AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('images').get('story-art').get('url') +'?imwidth=600'
    if 'title-treatment' in AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('images'):AOnquyUgXawJokpcdhzTSfrtWLKQPY=AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('images').get('title-treatment').get('url')+'?imwidth=300'
    if 'story-art' in AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('images'):AOnquyUgXawJokpcdhzTSfrtWLKQPv =AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('images').get('story-art').get('url') +'?imwidth=600'
    AOnquyUgXawJokpcdhzTSfrtWLKQxv=''
    if AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('badge')not in[{},AOnquyUgXawJokpcdhzTSfrtWLKQmF]:
     for i in AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('badge').get('text'):
      if AOnquyUgXawJokpcdhzTSfrtWLKQxv!='':AOnquyUgXawJokpcdhzTSfrtWLKQxv+=' '
      AOnquyUgXawJokpcdhzTSfrtWLKQxv+=i.get('text')
    if 'as' in AOnquyUgXawJokpcdhzTSfrtWLKQxl:
     AOnquyUgXawJokpcdhzTSfrtWLKQPb=AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('as') 
    else:
     AOnquyUgXawJokpcdhzTSfrtWLKQPb=AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('type')
    AOnquyUgXawJokpcdhzTSfrtWLKQxB={'id':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('id'),'title':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('title'),'asis':AOnquyUgXawJokpcdhzTSfrtWLKQPb,'thumbnail':{'poster':AOnquyUgXawJokpcdhzTSfrtWLKQxH,'thumb':AOnquyUgXawJokpcdhzTSfrtWLKQxG,'clearlogo':AOnquyUgXawJokpcdhzTSfrtWLKQPY,'fanart':AOnquyUgXawJokpcdhzTSfrtWLKQPv},'mpaa':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('age_rating'),'duration':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('running_time'),'badge':AOnquyUgXawJokpcdhzTSfrtWLKQxv,'year':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('meta').get('releaseYear'),}
    AOnquyUgXawJokpcdhzTSfrtWLKQxs.append(AOnquyUgXawJokpcdhzTSfrtWLKQxB)
   if AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('pagination').get('totalPages')>page_int:
    AOnquyUgXawJokpcdhzTSfrtWLKQxC=AOnquyUgXawJokpcdhzTSfrtWLKQlP
  except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
   AOnquyUgXawJokpcdhzTSfrtWLKQmI(exception)
   return[],AOnquyUgXawJokpcdhzTSfrtWLKQmj
  return AOnquyUgXawJokpcdhzTSfrtWLKQxs,AOnquyUgXawJokpcdhzTSfrtWLKQxC
 def GetBookmarkInfo(AOnquyUgXawJokpcdhzTSfrtWLKQsP,videoid,vidtype):
  AOnquyUgXawJokpcdhzTSfrtWLKQPB={'indexinfo':{'ott':'coupang','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  AOnquyUgXawJokpcdhzTSfrtWLKQRH=AOnquyUgXawJokpcdhzTSfrtWLKQsP.API_DOMAIN+'/api-discover/v1/discover/titles/'+videoid 
  AOnquyUgXawJokpcdhzTSfrtWLKQxR={'locale':'ko'}
  AOnquyUgXawJokpcdhzTSfrtWLKQRY=AOnquyUgXawJokpcdhzTSfrtWLKQsP.callRequestCookies('Get',AOnquyUgXawJokpcdhzTSfrtWLKQRH,payload=AOnquyUgXawJokpcdhzTSfrtWLKQmF,params=AOnquyUgXawJokpcdhzTSfrtWLKQxR,headers=AOnquyUgXawJokpcdhzTSfrtWLKQmF,cookies=AOnquyUgXawJokpcdhzTSfrtWLKQmF,redirects=AOnquyUgXawJokpcdhzTSfrtWLKQlP)
  if AOnquyUgXawJokpcdhzTSfrtWLKQRY.status_code not in[200]:return{}
  AOnquyUgXawJokpcdhzTSfrtWLKQPC=json.loads(AOnquyUgXawJokpcdhzTSfrtWLKQRY.text).get('data')
  AOnquyUgXawJokpcdhzTSfrtWLKQPD=AOnquyUgXawJokpcdhzTSfrtWLKQPC.get('title')
  AOnquyUgXawJokpcdhzTSfrtWLKQPH =AOnquyUgXawJokpcdhzTSfrtWLKQPC.get('meta').get('releaseYear')
  AOnquyUgXawJokpcdhzTSfrtWLKQPB['saveinfo']['infoLabels']['title']=AOnquyUgXawJokpcdhzTSfrtWLKQPD
  if vidtype=='movie':
   AOnquyUgXawJokpcdhzTSfrtWLKQPD='%s  (%s)'%(AOnquyUgXawJokpcdhzTSfrtWLKQPD,AOnquyUgXawJokpcdhzTSfrtWLKQPH)
  AOnquyUgXawJokpcdhzTSfrtWLKQPB['saveinfo']['title'] =AOnquyUgXawJokpcdhzTSfrtWLKQPD
  AOnquyUgXawJokpcdhzTSfrtWLKQPB['saveinfo']['infoLabels']['mpaa'] =AOnquyUgXawJokpcdhzTSfrtWLKQPC.get('age_rating')
  AOnquyUgXawJokpcdhzTSfrtWLKQPB['saveinfo']['infoLabels']['plot'] ='%s\n\n%s'%(AOnquyUgXawJokpcdhzTSfrtWLKQPC.get('short_description'),AOnquyUgXawJokpcdhzTSfrtWLKQPC.get('description'))
  AOnquyUgXawJokpcdhzTSfrtWLKQPB['saveinfo']['infoLabels']['year'] =AOnquyUgXawJokpcdhzTSfrtWLKQPH
  if vidtype=='movie':
   AOnquyUgXawJokpcdhzTSfrtWLKQPB['saveinfo']['infoLabels']['duration']=AOnquyUgXawJokpcdhzTSfrtWLKQPC.get('running_time')
  AOnquyUgXawJokpcdhzTSfrtWLKQxH =''
  AOnquyUgXawJokpcdhzTSfrtWLKQPv =''
  AOnquyUgXawJokpcdhzTSfrtWLKQxG =''
  AOnquyUgXawJokpcdhzTSfrtWLKQPY=''
  if AOnquyUgXawJokpcdhzTSfrtWLKQPC.get('images').get('poster') !=AOnquyUgXawJokpcdhzTSfrtWLKQmF:AOnquyUgXawJokpcdhzTSfrtWLKQxH =AOnquyUgXawJokpcdhzTSfrtWLKQPC.get('images').get('poster').get('url') +'?imwidth=350'
  if AOnquyUgXawJokpcdhzTSfrtWLKQPC.get('images').get('background') !=AOnquyUgXawJokpcdhzTSfrtWLKQmF:AOnquyUgXawJokpcdhzTSfrtWLKQPv =AOnquyUgXawJokpcdhzTSfrtWLKQPC.get('images').get('background').get('url') +'?imwidth=600'
  if AOnquyUgXawJokpcdhzTSfrtWLKQPC.get('images').get('story-art') !=AOnquyUgXawJokpcdhzTSfrtWLKQmF:AOnquyUgXawJokpcdhzTSfrtWLKQxG =AOnquyUgXawJokpcdhzTSfrtWLKQPC.get('images').get('story-art').get('url') +'?imwidth=600'
  if AOnquyUgXawJokpcdhzTSfrtWLKQPC.get('images').get('title-treatment')!=AOnquyUgXawJokpcdhzTSfrtWLKQmF:AOnquyUgXawJokpcdhzTSfrtWLKQPY=AOnquyUgXawJokpcdhzTSfrtWLKQPC.get('images').get('title-treatment').get('url')+'?imwidth=300'
  if AOnquyUgXawJokpcdhzTSfrtWLKQPv=='':AOnquyUgXawJokpcdhzTSfrtWLKQPv=AOnquyUgXawJokpcdhzTSfrtWLKQxG
  AOnquyUgXawJokpcdhzTSfrtWLKQPB['saveinfo']['thumbnail']['poster']=AOnquyUgXawJokpcdhzTSfrtWLKQxH
  AOnquyUgXawJokpcdhzTSfrtWLKQPB['saveinfo']['thumbnail']['fanart']=AOnquyUgXawJokpcdhzTSfrtWLKQPv
  AOnquyUgXawJokpcdhzTSfrtWLKQPB['saveinfo']['thumbnail']['thumb']=AOnquyUgXawJokpcdhzTSfrtWLKQxG
  AOnquyUgXawJokpcdhzTSfrtWLKQPB['saveinfo']['thumbnail']['clearlogo']=AOnquyUgXawJokpcdhzTSfrtWLKQPY
  AOnquyUgXawJokpcdhzTSfrtWLKQPN=[]
  for AOnquyUgXawJokpcdhzTSfrtWLKQxM in AOnquyUgXawJokpcdhzTSfrtWLKQPC.get('tags'):AOnquyUgXawJokpcdhzTSfrtWLKQPN.append(AOnquyUgXawJokpcdhzTSfrtWLKQxM.get('tag'))
  if AOnquyUgXawJokpcdhzTSfrtWLKQlR(AOnquyUgXawJokpcdhzTSfrtWLKQPN)>0:
   AOnquyUgXawJokpcdhzTSfrtWLKQPB['saveinfo']['infoLabels']['genre']=AOnquyUgXawJokpcdhzTSfrtWLKQPN
  AOnquyUgXawJokpcdhzTSfrtWLKQPM=[]
  AOnquyUgXawJokpcdhzTSfrtWLKQPG=[]
  for AOnquyUgXawJokpcdhzTSfrtWLKQxM in AOnquyUgXawJokpcdhzTSfrtWLKQPC.get('people'):
   if AOnquyUgXawJokpcdhzTSfrtWLKQxM.get('role')=='CAST' :AOnquyUgXawJokpcdhzTSfrtWLKQPM.append(AOnquyUgXawJokpcdhzTSfrtWLKQxM.get('name'))
   if AOnquyUgXawJokpcdhzTSfrtWLKQxM.get('role')=='DIRECTOR':AOnquyUgXawJokpcdhzTSfrtWLKQPG.append(AOnquyUgXawJokpcdhzTSfrtWLKQxM.get('name'))
  if AOnquyUgXawJokpcdhzTSfrtWLKQlR(AOnquyUgXawJokpcdhzTSfrtWLKQPM)>0:
   AOnquyUgXawJokpcdhzTSfrtWLKQPB['saveinfo']['infoLabels']['cast'] =AOnquyUgXawJokpcdhzTSfrtWLKQPM
  if AOnquyUgXawJokpcdhzTSfrtWLKQlR(AOnquyUgXawJokpcdhzTSfrtWLKQPG)>0:
   AOnquyUgXawJokpcdhzTSfrtWLKQPB['saveinfo']['infoLabels']['director']=AOnquyUgXawJokpcdhzTSfrtWLKQPG
  return AOnquyUgXawJokpcdhzTSfrtWLKQPB
 def MakeText_FreeList(AOnquyUgXawJokpcdhzTSfrtWLKQsP,search_list,titleName='title'):
  AOnquyUgXawJokpcdhzTSfrtWLKQPi=''
  AOnquyUgXawJokpcdhzTSfrtWLKQPF=5
  try:
   for i in AOnquyUgXawJokpcdhzTSfrtWLKQlm(AOnquyUgXawJokpcdhzTSfrtWLKQlR(search_list)):
    if i>=AOnquyUgXawJokpcdhzTSfrtWLKQPF:
     AOnquyUgXawJokpcdhzTSfrtWLKQPi=AOnquyUgXawJokpcdhzTSfrtWLKQPi+'...'
     break
    AOnquyUgXawJokpcdhzTSfrtWLKQPi=AOnquyUgXawJokpcdhzTSfrtWLKQPi+search_list[i][titleName]+'\n'
  except:
   return ''
  return AOnquyUgXawJokpcdhzTSfrtWLKQPi
 def Sports_Mainlist_League(AOnquyUgXawJokpcdhzTSfrtWLKQsP):
  AOnquyUgXawJokpcdhzTSfrtWLKQPj=[] 
  try:
   AOnquyUgXawJokpcdhzTSfrtWLKQRH='{}/api-discover/v1/sports/leagues/pills'.format(AOnquyUgXawJokpcdhzTSfrtWLKQsP.API_DOMAIN)
   AOnquyUgXawJokpcdhzTSfrtWLKQxR={'platform':'WEBCLIENT','useCircularLogo':'true',}
   AOnquyUgXawJokpcdhzTSfrtWLKQRY=AOnquyUgXawJokpcdhzTSfrtWLKQsP.callRequestCookies('Get',AOnquyUgXawJokpcdhzTSfrtWLKQRH,payload=AOnquyUgXawJokpcdhzTSfrtWLKQmF,params=AOnquyUgXawJokpcdhzTSfrtWLKQxR,headers=AOnquyUgXawJokpcdhzTSfrtWLKQmF,cookies=AOnquyUgXawJokpcdhzTSfrtWLKQmF)
   if AOnquyUgXawJokpcdhzTSfrtWLKQRY.status_code not in[200]:return[]
   AOnquyUgXawJokpcdhzTSfrtWLKQRj=json.loads(AOnquyUgXawJokpcdhzTSfrtWLKQRY.text)
   for AOnquyUgXawJokpcdhzTSfrtWLKQxl in AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('data'):
    AOnquyUgXawJokpcdhzTSfrtWLKQxB={'league_id':AOnquyUgXawJokpcdhzTSfrtWLKQxl['id'],'league_name':AOnquyUgXawJokpcdhzTSfrtWLKQxl['name'],'logoUrl':AOnquyUgXawJokpcdhzTSfrtWLKQxl['logoUrl'],}
    AOnquyUgXawJokpcdhzTSfrtWLKQPj.append(AOnquyUgXawJokpcdhzTSfrtWLKQxB)
  except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
   AOnquyUgXawJokpcdhzTSfrtWLKQmI(exception)
   return[]
  return AOnquyUgXawJokpcdhzTSfrtWLKQPj
 def Sports_League_FeedList(AOnquyUgXawJokpcdhzTSfrtWLKQsP,leagueID):
  AOnquyUgXawJokpcdhzTSfrtWLKQPI=[] 
  try:
   AOnquyUgXawJokpcdhzTSfrtWLKQRH='{}/api-discover/v1/discover/sports/leagues/{}/feed'.format(AOnquyUgXawJokpcdhzTSfrtWLKQsP.API_DOMAIN,leagueID)
   AOnquyUgXawJokpcdhzTSfrtWLKQxR={'platform':'WEBCLIENT','region':'KR','locale':'ko','includeSportsChannelContents':'true',}
   AOnquyUgXawJokpcdhzTSfrtWLKQRY=AOnquyUgXawJokpcdhzTSfrtWLKQsP.callRequestCookies('Get',AOnquyUgXawJokpcdhzTSfrtWLKQRH,payload=AOnquyUgXawJokpcdhzTSfrtWLKQmF,params=AOnquyUgXawJokpcdhzTSfrtWLKQxR,headers=AOnquyUgXawJokpcdhzTSfrtWLKQmF,cookies=AOnquyUgXawJokpcdhzTSfrtWLKQmF)
   if AOnquyUgXawJokpcdhzTSfrtWLKQRY.status_code not in[200]:return[]
   AOnquyUgXawJokpcdhzTSfrtWLKQRj=json.loads(AOnquyUgXawJokpcdhzTSfrtWLKQRY.text).get('data')
   for AOnquyUgXawJokpcdhzTSfrtWLKQxl in AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('data'):
    if AOnquyUgXawJokpcdhzTSfrtWLKQxl['type']=='Calendar':
     AOnquyUgXawJokpcdhzTSfrtWLKQPV =AOnquyUgXawJokpcdhzTSfrtWLKQsP.Sports_leagueHome_Livelist(leagueID)
     if AOnquyUgXawJokpcdhzTSfrtWLKQPV:
      AOnquyUgXawJokpcdhzTSfrtWLKQPe =AOnquyUgXawJokpcdhzTSfrtWLKQsP.MakeText_FreeList(AOnquyUgXawJokpcdhzTSfrtWLKQPV,titleName='preTitle')
      AOnquyUgXawJokpcdhzTSfrtWLKQxB={'row_name':'@ 예정 경기 @','preText':AOnquyUgXawJokpcdhzTSfrtWLKQPe,'subMode':'SP_FEED_LIVE','image':AOnquyUgXawJokpcdhzTSfrtWLKQPV[0]['image'],}
      AOnquyUgXawJokpcdhzTSfrtWLKQPI.append(AOnquyUgXawJokpcdhzTSfrtWLKQxB)
    elif AOnquyUgXawJokpcdhzTSfrtWLKQxl['type']=='Live-Events-Curation':
     AOnquyUgXawJokpcdhzTSfrtWLKQPV =AOnquyUgXawJokpcdhzTSfrtWLKQsP.Sports_LeagueHome_List(data=AOnquyUgXawJokpcdhzTSfrtWLKQxl,sType='top10')
     if AOnquyUgXawJokpcdhzTSfrtWLKQPV:
      AOnquyUgXawJokpcdhzTSfrtWLKQPe =AOnquyUgXawJokpcdhzTSfrtWLKQsP.MakeText_FreeList(AOnquyUgXawJokpcdhzTSfrtWLKQPV,titleName='title')
      AOnquyUgXawJokpcdhzTSfrtWLKQxB={'row_name':AOnquyUgXawJokpcdhzTSfrtWLKQxl['row_name'],'preText':AOnquyUgXawJokpcdhzTSfrtWLKQPe,'subMode':'SP_FEED_TOP10','image':AOnquyUgXawJokpcdhzTSfrtWLKQPV[0]['image'],}
      AOnquyUgXawJokpcdhzTSfrtWLKQPI.append(AOnquyUgXawJokpcdhzTSfrtWLKQxB)
    elif AOnquyUgXawJokpcdhzTSfrtWLKQxl['type']=='Live-Sports-Matches':
     AOnquyUgXawJokpcdhzTSfrtWLKQPV =AOnquyUgXawJokpcdhzTSfrtWLKQsP.Sports_LeagueHome_List(data=AOnquyUgXawJokpcdhzTSfrtWLKQxl,sType='gameVod')
     for AOnquyUgXawJokpcdhzTSfrtWLKQPE in AOnquyUgXawJokpcdhzTSfrtWLKQPV:
      AOnquyUgXawJokpcdhzTSfrtWLKQxB={'row_name':'{} <{}>'.format(AOnquyUgXawJokpcdhzTSfrtWLKQPE['title'],AOnquyUgXawJokpcdhzTSfrtWLKQPE['startDate']),'preText':AOnquyUgXawJokpcdhzTSfrtWLKQPE['preText'],'subMode':'SP_FEED_GAME','gameID':AOnquyUgXawJokpcdhzTSfrtWLKQPE['id'],'image':AOnquyUgXawJokpcdhzTSfrtWLKQPE['image'],}
      AOnquyUgXawJokpcdhzTSfrtWLKQPI.append(AOnquyUgXawJokpcdhzTSfrtWLKQxB)
  except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
   AOnquyUgXawJokpcdhzTSfrtWLKQmI(exception)
   return[]
  return AOnquyUgXawJokpcdhzTSfrtWLKQPI
 def Sports_League_VodList(AOnquyUgXawJokpcdhzTSfrtWLKQsP,subMode,leagueID,gameID):
  AOnquyUgXawJokpcdhzTSfrtWLKQms=[] 
  try:
   if subMode=='SP_FEED_LIVE':
    AOnquyUgXawJokpcdhzTSfrtWLKQPV =AOnquyUgXawJokpcdhzTSfrtWLKQsP.Sports_leagueHome_Livelist(leagueID)
    for AOnquyUgXawJokpcdhzTSfrtWLKQPE in AOnquyUgXawJokpcdhzTSfrtWLKQPV:
     AOnquyUgXawJokpcdhzTSfrtWLKQxB={'id':AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('event_id'),'title':AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('title'),'image':AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('image'),'startDate':AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('startDate'),'subType':AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('subType'),}
     AOnquyUgXawJokpcdhzTSfrtWLKQms.append(AOnquyUgXawJokpcdhzTSfrtWLKQxB)
   elif subMode in['SP_FEED_TOP10','SP_FEED_GAME']:
    AOnquyUgXawJokpcdhzTSfrtWLKQRH='{}/api-discover/v1/discover/sports/leagues/{}/feed'.format(AOnquyUgXawJokpcdhzTSfrtWLKQsP.API_DOMAIN,leagueID)
    AOnquyUgXawJokpcdhzTSfrtWLKQxR={'platform':'WEBCLIENT','region':'KR','locale':'ko','includeSportsChannelContents':'true',}
    AOnquyUgXawJokpcdhzTSfrtWLKQRY=AOnquyUgXawJokpcdhzTSfrtWLKQsP.callRequestCookies('Get',AOnquyUgXawJokpcdhzTSfrtWLKQRH,payload=AOnquyUgXawJokpcdhzTSfrtWLKQmF,params=AOnquyUgXawJokpcdhzTSfrtWLKQxR,headers=AOnquyUgXawJokpcdhzTSfrtWLKQmF,cookies=AOnquyUgXawJokpcdhzTSfrtWLKQmF)
    if AOnquyUgXawJokpcdhzTSfrtWLKQRY.status_code not in[200]:return[]
    AOnquyUgXawJokpcdhzTSfrtWLKQRj=json.loads(AOnquyUgXawJokpcdhzTSfrtWLKQRY.text).get('data')
    for AOnquyUgXawJokpcdhzTSfrtWLKQxl in AOnquyUgXawJokpcdhzTSfrtWLKQRj.get('data'):
     if AOnquyUgXawJokpcdhzTSfrtWLKQxl['type']=='Live-Events-Curation' and subMode=='SP_FEED_TOP10':
      AOnquyUgXawJokpcdhzTSfrtWLKQPV =AOnquyUgXawJokpcdhzTSfrtWLKQsP.Sports_LeagueHome_List(data=AOnquyUgXawJokpcdhzTSfrtWLKQxl,sType='top10')
      for AOnquyUgXawJokpcdhzTSfrtWLKQPE in AOnquyUgXawJokpcdhzTSfrtWLKQPV:
       AOnquyUgXawJokpcdhzTSfrtWLKQxB={'id':AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('id'),'title':AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('title'),'image':AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('image'),'startDate':AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('startDate'),'subType':AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('subType'),'running_time':AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('running_time'),}
       AOnquyUgXawJokpcdhzTSfrtWLKQms.append(AOnquyUgXawJokpcdhzTSfrtWLKQxB)
     elif AOnquyUgXawJokpcdhzTSfrtWLKQxl['type']=='Live-Sports-Matches' and subMode=='SP_FEED_GAME':
      for AOnquyUgXawJokpcdhzTSfrtWLKQmR in AOnquyUgXawJokpcdhzTSfrtWLKQxl['data']:
       if gameID==AOnquyUgXawJokpcdhzTSfrtWLKQmR['id']:
        AOnquyUgXawJokpcdhzTSfrtWLKQPV =AOnquyUgXawJokpcdhzTSfrtWLKQsP.Sports_LeagueHome_SubVods(data=AOnquyUgXawJokpcdhzTSfrtWLKQmR)
        for AOnquyUgXawJokpcdhzTSfrtWLKQPE in AOnquyUgXawJokpcdhzTSfrtWLKQPV:
         AOnquyUgXawJokpcdhzTSfrtWLKQxB={'id':AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('id'),'title':AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('title'),'image':AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('image'),'subType':AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('subType'),'running_time':AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('running_time'),}
         AOnquyUgXawJokpcdhzTSfrtWLKQms.append(AOnquyUgXawJokpcdhzTSfrtWLKQxB)
        break
  except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
   AOnquyUgXawJokpcdhzTSfrtWLKQmI(exception)
   return[]
  return AOnquyUgXawJokpcdhzTSfrtWLKQms
 def Sports_LeagueHome_List(AOnquyUgXawJokpcdhzTSfrtWLKQsP,data,sType=''):
  AOnquyUgXawJokpcdhzTSfrtWLKQmx=[]
  try:
   if sType=='top10':
    for AOnquyUgXawJokpcdhzTSfrtWLKQxl in data.get('data'):
     AOnquyUgXawJokpcdhzTSfrtWLKQmP=''
     if 'channels' in AOnquyUgXawJokpcdhzTSfrtWLKQxl:
      AOnquyUgXawJokpcdhzTSfrtWLKQmP='패스'
     AOnquyUgXawJokpcdhzTSfrtWLKQxB={'id':AOnquyUgXawJokpcdhzTSfrtWLKQxl['id'],'title':AOnquyUgXawJokpcdhzTSfrtWLKQxl['title'],'subType':AOnquyUgXawJokpcdhzTSfrtWLKQmP,'image':AOnquyUgXawJokpcdhzTSfrtWLKQxl['images']['story_art_url'],'running_time':AOnquyUgXawJokpcdhzTSfrtWLKQxl['running_time'],'startDate':AOnquyUgXawJokpcdhzTSfrtWLKQsP.convert_DateStr(AOnquyUgXawJokpcdhzTSfrtWLKQxl['startAt']),}
     AOnquyUgXawJokpcdhzTSfrtWLKQmx.append(AOnquyUgXawJokpcdhzTSfrtWLKQxB)
   elif sType=='gameVod':
    for AOnquyUgXawJokpcdhzTSfrtWLKQxl in data.get('data'):
     if AOnquyUgXawJokpcdhzTSfrtWLKQlR(AOnquyUgXawJokpcdhzTSfrtWLKQxl['participants'])>=2:
      AOnquyUgXawJokpcdhzTSfrtWLKQml=AOnquyUgXawJokpcdhzTSfrtWLKQxl['participants'][0]['name']
      AOnquyUgXawJokpcdhzTSfrtWLKQmb=AOnquyUgXawJokpcdhzTSfrtWLKQxl['participants'][1]['name']
      AOnquyUgXawJokpcdhzTSfrtWLKQml=AOnquyUgXawJokpcdhzTSfrtWLKQml+' vs '+AOnquyUgXawJokpcdhzTSfrtWLKQmb
     else:
      AOnquyUgXawJokpcdhzTSfrtWLKQml=AOnquyUgXawJokpcdhzTSfrtWLKQxl['participants'][0]['name']
     AOnquyUgXawJokpcdhzTSfrtWLKQPV=AOnquyUgXawJokpcdhzTSfrtWLKQsP.Sports_LeagueHome_SubVods(AOnquyUgXawJokpcdhzTSfrtWLKQxl)
     AOnquyUgXawJokpcdhzTSfrtWLKQPe =AOnquyUgXawJokpcdhzTSfrtWLKQsP.MakeText_FreeList(AOnquyUgXawJokpcdhzTSfrtWLKQPV,titleName='title')
     AOnquyUgXawJokpcdhzTSfrtWLKQxB={'id':AOnquyUgXawJokpcdhzTSfrtWLKQxl['id'],'title':AOnquyUgXawJokpcdhzTSfrtWLKQml,'startDate':AOnquyUgXawJokpcdhzTSfrtWLKQsP.convert_DateStr(AOnquyUgXawJokpcdhzTSfrtWLKQxl['startsAt']),'preText':AOnquyUgXawJokpcdhzTSfrtWLKQPe,'image':AOnquyUgXawJokpcdhzTSfrtWLKQPV[0]['image']}
     AOnquyUgXawJokpcdhzTSfrtWLKQmx.append(AOnquyUgXawJokpcdhzTSfrtWLKQxB)
  except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
   AOnquyUgXawJokpcdhzTSfrtWLKQmI(exception)
   return[]
  return AOnquyUgXawJokpcdhzTSfrtWLKQmx
 def Sports_LeagueHome_SubVods(AOnquyUgXawJokpcdhzTSfrtWLKQsP,data):
  AOnquyUgXawJokpcdhzTSfrtWLKQPV=[]
  try:
   for AOnquyUgXawJokpcdhzTSfrtWLKQxl in data.get('highlights'):
    AOnquyUgXawJokpcdhzTSfrtWLKQmP=''
    if 'channels' in AOnquyUgXawJokpcdhzTSfrtWLKQxl:
     AOnquyUgXawJokpcdhzTSfrtWLKQmP='패스'
    AOnquyUgXawJokpcdhzTSfrtWLKQxB={'id':AOnquyUgXawJokpcdhzTSfrtWLKQxl['id'],'title':AOnquyUgXawJokpcdhzTSfrtWLKQxl['title'],'image':AOnquyUgXawJokpcdhzTSfrtWLKQxl['images']['story-art']['url'],'subType':AOnquyUgXawJokpcdhzTSfrtWLKQmP,'running_time':AOnquyUgXawJokpcdhzTSfrtWLKQxl['running_time'],}
    AOnquyUgXawJokpcdhzTSfrtWLKQPV.append(AOnquyUgXawJokpcdhzTSfrtWLKQxB)
  except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
   AOnquyUgXawJokpcdhzTSfrtWLKQmI(exception)
   return[]
  return AOnquyUgXawJokpcdhzTSfrtWLKQPV
 def Sports_leagueHome_Livelist(AOnquyUgXawJokpcdhzTSfrtWLKQsP,leagueID):
  AOnquyUgXawJokpcdhzTSfrtWLKQPV=[]
  try:
   AOnquyUgXawJokpcdhzTSfrtWLKQRH='{}/api-discover/v1/sports/curated-schedule/events'.format(AOnquyUgXawJokpcdhzTSfrtWLKQsP.API_DOMAIN)
   AOnquyUgXawJokpcdhzTSfrtWLKQxR={'league_id':leagueID,'region':'KR','locale':'ko','scope':'live-upcoming','includeHighlights':'false','includeSportsChannelContents':'true',}
   AOnquyUgXawJokpcdhzTSfrtWLKQRx={'x-membersrl':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['COOKIES']['member_srl'],'x-pcid':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['COOKIES']['PCID'],'x-profileid':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT',}
   AOnquyUgXawJokpcdhzTSfrtWLKQRY=AOnquyUgXawJokpcdhzTSfrtWLKQsP.callRequestCookies('Get',AOnquyUgXawJokpcdhzTSfrtWLKQRH,payload=AOnquyUgXawJokpcdhzTSfrtWLKQmF,params=AOnquyUgXawJokpcdhzTSfrtWLKQxR,headers=AOnquyUgXawJokpcdhzTSfrtWLKQRx,cookies=AOnquyUgXawJokpcdhzTSfrtWLKQmF)
   if AOnquyUgXawJokpcdhzTSfrtWLKQRY.status_code not in[200]:return[]
   AOnquyUgXawJokpcdhzTSfrtWLKQRj=json.loads(AOnquyUgXawJokpcdhzTSfrtWLKQRY.text).get('data')
   for AOnquyUgXawJokpcdhzTSfrtWLKQPE in AOnquyUgXawJokpcdhzTSfrtWLKQRj:
    if AOnquyUgXawJokpcdhzTSfrtWLKQlR(AOnquyUgXawJokpcdhzTSfrtWLKQPE['teams'])>=2:
     AOnquyUgXawJokpcdhzTSfrtWLKQml=AOnquyUgXawJokpcdhzTSfrtWLKQPE['teams'][0]['name']
     AOnquyUgXawJokpcdhzTSfrtWLKQmb=AOnquyUgXawJokpcdhzTSfrtWLKQPE['teams'][1]['name']
     AOnquyUgXawJokpcdhzTSfrtWLKQml=AOnquyUgXawJokpcdhzTSfrtWLKQml+' vs '+AOnquyUgXawJokpcdhzTSfrtWLKQmb
    else:
     AOnquyUgXawJokpcdhzTSfrtWLKQml=AOnquyUgXawJokpcdhzTSfrtWLKQPE['teams'][0]['name']
    AOnquyUgXawJokpcdhzTSfrtWLKQmB=''
    if AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('images'):
     AOnquyUgXawJokpcdhzTSfrtWLKQmB=AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('images').get('story_art_url')
    AOnquyUgXawJokpcdhzTSfrtWLKQmC=AOnquyUgXawJokpcdhzTSfrtWLKQsP.convert_TimeStr(AOnquyUgXawJokpcdhzTSfrtWLKQPE['start_at'])
    AOnquyUgXawJokpcdhzTSfrtWLKQmP=''
    if 'channels' in AOnquyUgXawJokpcdhzTSfrtWLKQPE:
     AOnquyUgXawJokpcdhzTSfrtWLKQmP='패스'
    AOnquyUgXawJokpcdhzTSfrtWLKQxB={'event_id':AOnquyUgXawJokpcdhzTSfrtWLKQPE['event_id'],'title':AOnquyUgXawJokpcdhzTSfrtWLKQml,'startDate':AOnquyUgXawJokpcdhzTSfrtWLKQmC,'image':AOnquyUgXawJokpcdhzTSfrtWLKQmB,'preTitle':'{} <{}>'.format(AOnquyUgXawJokpcdhzTSfrtWLKQml,AOnquyUgXawJokpcdhzTSfrtWLKQmC),'subType':AOnquyUgXawJokpcdhzTSfrtWLKQmP,}
    AOnquyUgXawJokpcdhzTSfrtWLKQPV.append(AOnquyUgXawJokpcdhzTSfrtWLKQxB)
  except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
   AOnquyUgXawJokpcdhzTSfrtWLKQmI(exception)
   return[]
  return AOnquyUgXawJokpcdhzTSfrtWLKQPV
 def Sports_MultiHero_LiveList(AOnquyUgXawJokpcdhzTSfrtWLKQsP):
  AOnquyUgXawJokpcdhzTSfrtWLKQmD=[]
  try:
   AOnquyUgXawJokpcdhzTSfrtWLKQRH='{}/api-discover/v1/sports/feed'.format(AOnquyUgXawJokpcdhzTSfrtWLKQsP.API_DOMAIN)
   AOnquyUgXawJokpcdhzTSfrtWLKQxR={'platform':'WEBCLIENT','region':'KR','locale':'ko','filterRestrictedContent':'false','preferRecoFeed':'true','preferMultiHeroMixedContentRow':'true','category':'LIVE','perPage':'7','allowOtherRailsAboveHero':'true','includeSportsChannelContents':'true','page':'1',}
   AOnquyUgXawJokpcdhzTSfrtWLKQRY=AOnquyUgXawJokpcdhzTSfrtWLKQsP.callRequestCookies('Get',AOnquyUgXawJokpcdhzTSfrtWLKQRH,payload=AOnquyUgXawJokpcdhzTSfrtWLKQmF,params=AOnquyUgXawJokpcdhzTSfrtWLKQxR,headers=AOnquyUgXawJokpcdhzTSfrtWLKQmF,cookies=AOnquyUgXawJokpcdhzTSfrtWLKQmF)
   if AOnquyUgXawJokpcdhzTSfrtWLKQRY.status_code not in[200]:return[]
   AOnquyUgXawJokpcdhzTSfrtWLKQRj=json.loads(AOnquyUgXawJokpcdhzTSfrtWLKQRY.text).get('data')
   for AOnquyUgXawJokpcdhzTSfrtWLKQxl in AOnquyUgXawJokpcdhzTSfrtWLKQRj:
    if AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('type')=='Multi-Hero-Live-Event-Curation':
     for AOnquyUgXawJokpcdhzTSfrtWLKQPE in AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('data'):
      AOnquyUgXawJokpcdhzTSfrtWLKQmC=AOnquyUgXawJokpcdhzTSfrtWLKQsP.convert_TimeStr(AOnquyUgXawJokpcdhzTSfrtWLKQPE['startAt'])
      '''
      try:
       startDate = self.convert_TimeStr(i_vod['startAt'] )
      except Exception as exception:
       aa = 'exception = {}'.format(exception )
       bb = {'aa' : aa }
       self.dic_To_jsonfile('d:\\Naver MYBOX\\sync\\job\\cp_cookies1.json', bb )
      '''      
      AOnquyUgXawJokpcdhzTSfrtWLKQmB=''
      if AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('images'):
       if AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('images').get('hero_url'):
        AOnquyUgXawJokpcdhzTSfrtWLKQmB=AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('images').get('hero_url')
       elif AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('images').get('sports_hero_mobile_url'):
        AOnquyUgXawJokpcdhzTSfrtWLKQmB=AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('images').get('sports_hero_mobile_url')
      AOnquyUgXawJokpcdhzTSfrtWLKQmP=''
      if 'channels' in AOnquyUgXawJokpcdhzTSfrtWLKQPE:
       AOnquyUgXawJokpcdhzTSfrtWLKQmP='패스'
      AOnquyUgXawJokpcdhzTSfrtWLKQxB={'id':AOnquyUgXawJokpcdhzTSfrtWLKQPE['id'],'title':AOnquyUgXawJokpcdhzTSfrtWLKQPE['title'],'startDate':AOnquyUgXawJokpcdhzTSfrtWLKQmC,'image':AOnquyUgXawJokpcdhzTSfrtWLKQmB,'preTitle':'{} <{}>'.format(AOnquyUgXawJokpcdhzTSfrtWLKQPE['title'],AOnquyUgXawJokpcdhzTSfrtWLKQmC),'subType':AOnquyUgXawJokpcdhzTSfrtWLKQmP,}
      AOnquyUgXawJokpcdhzTSfrtWLKQmD.append(AOnquyUgXawJokpcdhzTSfrtWLKQxB)
     break
  except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
   AOnquyUgXawJokpcdhzTSfrtWLKQmI(exception)
   return[]
  return AOnquyUgXawJokpcdhzTSfrtWLKQmD
 def Sports_Season_Group(AOnquyUgXawJokpcdhzTSfrtWLKQsP,leagueID):
  AOnquyUgXawJokpcdhzTSfrtWLKQmH=[]
  try:
   AOnquyUgXawJokpcdhzTSfrtWLKQRH='{}/api-discover/v1/discover/sports/leagues/{}/filters'.format(AOnquyUgXawJokpcdhzTSfrtWLKQsP.API_DOMAIN,leagueID)
   AOnquyUgXawJokpcdhzTSfrtWLKQxR={'platform':'WEBCLIENT','locale':'ko','includeSportsChannelContents':'true',}
   AOnquyUgXawJokpcdhzTSfrtWLKQRx={'x-membersrl':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['COOKIES']['member_srl'],'x-pcid':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['COOKIES']['PCID'],'x-profileid':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT',}
   AOnquyUgXawJokpcdhzTSfrtWLKQRY=AOnquyUgXawJokpcdhzTSfrtWLKQsP.callRequestCookies('Get',AOnquyUgXawJokpcdhzTSfrtWLKQRH,payload=AOnquyUgXawJokpcdhzTSfrtWLKQmF,params=AOnquyUgXawJokpcdhzTSfrtWLKQxR,headers=AOnquyUgXawJokpcdhzTSfrtWLKQRx,cookies=AOnquyUgXawJokpcdhzTSfrtWLKQmF)
   if AOnquyUgXawJokpcdhzTSfrtWLKQRY.status_code not in[200]:return[]
   AOnquyUgXawJokpcdhzTSfrtWLKQRj=json.loads(AOnquyUgXawJokpcdhzTSfrtWLKQRY.text).get('data')
   for AOnquyUgXawJokpcdhzTSfrtWLKQxl in AOnquyUgXawJokpcdhzTSfrtWLKQRj:
    AOnquyUgXawJokpcdhzTSfrtWLKQmv=[]
    for AOnquyUgXawJokpcdhzTSfrtWLKQmY in AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('stages'):
     AOnquyUgXawJokpcdhzTSfrtWLKQmN={'title':AOnquyUgXawJokpcdhzTSfrtWLKQmY['name'],}
     AOnquyUgXawJokpcdhzTSfrtWLKQmv.append(AOnquyUgXawJokpcdhzTSfrtWLKQmN)
    AOnquyUgXawJokpcdhzTSfrtWLKQPe=AOnquyUgXawJokpcdhzTSfrtWLKQsP.MakeText_FreeList(AOnquyUgXawJokpcdhzTSfrtWLKQmv,titleName='title')
    AOnquyUgXawJokpcdhzTSfrtWLKQxB={'season':AOnquyUgXawJokpcdhzTSfrtWLKQxl['season'],'preText':AOnquyUgXawJokpcdhzTSfrtWLKQPe,}
    AOnquyUgXawJokpcdhzTSfrtWLKQmH.append(AOnquyUgXawJokpcdhzTSfrtWLKQxB)
  except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
   AOnquyUgXawJokpcdhzTSfrtWLKQmI(exception)
   return[]
  return AOnquyUgXawJokpcdhzTSfrtWLKQmH
 def Sports_Season_GameList(AOnquyUgXawJokpcdhzTSfrtWLKQsP,leagueID,seasonID,page=1):
  AOnquyUgXawJokpcdhzTSfrtWLKQmx=[]
  try:
   AOnquyUgXawJokpcdhzTSfrtWLKQRH='{}/api-discover/v2/sports/leagues/{}/schedule/previous'.format(AOnquyUgXawJokpcdhzTSfrtWLKQsP.API_DOMAIN,leagueID)
   AOnquyUgXawJokpcdhzTSfrtWLKQxR={'seasons':seasonID,'stageIds':'','teamIds':'','platform':'WEBCLIENT','locale':'ko','region':'KR','perPage':'10','includeSportsChannelContents':'true','page':AOnquyUgXawJokpcdhzTSfrtWLKQmV(page),}
   AOnquyUgXawJokpcdhzTSfrtWLKQRx={'x-membersrl':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['COOKIES']['member_srl'],'x-pcid':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['COOKIES']['PCID'],'x-profileid':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT',}
   AOnquyUgXawJokpcdhzTSfrtWLKQRY=AOnquyUgXawJokpcdhzTSfrtWLKQsP.callRequestCookies('Get',AOnquyUgXawJokpcdhzTSfrtWLKQRH,payload=AOnquyUgXawJokpcdhzTSfrtWLKQmF,params=AOnquyUgXawJokpcdhzTSfrtWLKQxR,headers=AOnquyUgXawJokpcdhzTSfrtWLKQmF,cookies=AOnquyUgXawJokpcdhzTSfrtWLKQmF)
   if AOnquyUgXawJokpcdhzTSfrtWLKQRY.status_code not in[200]:return[]
   AOnquyUgXawJokpcdhzTSfrtWLKQRj=json.loads(AOnquyUgXawJokpcdhzTSfrtWLKQRY.text).get('data')
   for AOnquyUgXawJokpcdhzTSfrtWLKQxl in AOnquyUgXawJokpcdhzTSfrtWLKQRj:
    if AOnquyUgXawJokpcdhzTSfrtWLKQlR(AOnquyUgXawJokpcdhzTSfrtWLKQxl['participants'])>=2:
     AOnquyUgXawJokpcdhzTSfrtWLKQml=AOnquyUgXawJokpcdhzTSfrtWLKQxl['participants'][0]['name']
     AOnquyUgXawJokpcdhzTSfrtWLKQmb=AOnquyUgXawJokpcdhzTSfrtWLKQxl['participants'][1]['name']
     AOnquyUgXawJokpcdhzTSfrtWLKQml=AOnquyUgXawJokpcdhzTSfrtWLKQml+' vs '+AOnquyUgXawJokpcdhzTSfrtWLKQmb
    else:
     AOnquyUgXawJokpcdhzTSfrtWLKQml=AOnquyUgXawJokpcdhzTSfrtWLKQxl['participants'][0]['name']
    AOnquyUgXawJokpcdhzTSfrtWLKQPV=AOnquyUgXawJokpcdhzTSfrtWLKQsP.Sports_LeagueHome_SubVods(AOnquyUgXawJokpcdhzTSfrtWLKQxl)
    AOnquyUgXawJokpcdhzTSfrtWLKQPe =AOnquyUgXawJokpcdhzTSfrtWLKQsP.MakeText_FreeList(AOnquyUgXawJokpcdhzTSfrtWLKQPV,titleName='title')
    AOnquyUgXawJokpcdhzTSfrtWLKQxB={'id':AOnquyUgXawJokpcdhzTSfrtWLKQxl['id'],'title':AOnquyUgXawJokpcdhzTSfrtWLKQml,'startDate':AOnquyUgXawJokpcdhzTSfrtWLKQsP.convert_DateStr(AOnquyUgXawJokpcdhzTSfrtWLKQxl['startsAt']),'preText':AOnquyUgXawJokpcdhzTSfrtWLKQPe,'image':AOnquyUgXawJokpcdhzTSfrtWLKQPV[0]['image']}
    AOnquyUgXawJokpcdhzTSfrtWLKQmx.append(AOnquyUgXawJokpcdhzTSfrtWLKQxB)
  except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
   AOnquyUgXawJokpcdhzTSfrtWLKQmI(exception)
   return[]
  return AOnquyUgXawJokpcdhzTSfrtWLKQmx
 def Sports_Season_GameVod(AOnquyUgXawJokpcdhzTSfrtWLKQsP,leagueID,seasonID,page,gameID):
  AOnquyUgXawJokpcdhzTSfrtWLKQms=[]
  try:
   AOnquyUgXawJokpcdhzTSfrtWLKQRH='{}/api-discover/v2/sports/leagues/{}/schedule/previous'.format(AOnquyUgXawJokpcdhzTSfrtWLKQsP.API_DOMAIN,leagueID)
   AOnquyUgXawJokpcdhzTSfrtWLKQxR={'seasons':seasonID,'stageIds':'','teamIds':'','platform':'WEBCLIENT','locale':'ko','region':'KR','perPage':'10','includeSportsChannelContents':'true','page':AOnquyUgXawJokpcdhzTSfrtWLKQmV(page),}
   AOnquyUgXawJokpcdhzTSfrtWLKQRx={'x-membersrl':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['COOKIES']['member_srl'],'x-pcid':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['COOKIES']['PCID'],'x-profileid':AOnquyUgXawJokpcdhzTSfrtWLKQsP.CP['SESSION']['profileId'],'x-platform':'WEBCLIENT',}
   AOnquyUgXawJokpcdhzTSfrtWLKQRY=AOnquyUgXawJokpcdhzTSfrtWLKQsP.callRequestCookies('Get',AOnquyUgXawJokpcdhzTSfrtWLKQRH,payload=AOnquyUgXawJokpcdhzTSfrtWLKQmF,params=AOnquyUgXawJokpcdhzTSfrtWLKQxR,headers=AOnquyUgXawJokpcdhzTSfrtWLKQmF,cookies=AOnquyUgXawJokpcdhzTSfrtWLKQmF)
   if AOnquyUgXawJokpcdhzTSfrtWLKQRY.status_code not in[200]:return[]
   AOnquyUgXawJokpcdhzTSfrtWLKQRj=json.loads(AOnquyUgXawJokpcdhzTSfrtWLKQRY.text).get('data')
   for AOnquyUgXawJokpcdhzTSfrtWLKQxl in AOnquyUgXawJokpcdhzTSfrtWLKQRj:
    if gameID==AOnquyUgXawJokpcdhzTSfrtWLKQxl['id']:
     AOnquyUgXawJokpcdhzTSfrtWLKQPV=AOnquyUgXawJokpcdhzTSfrtWLKQsP.Sports_LeagueHome_SubVods(AOnquyUgXawJokpcdhzTSfrtWLKQxl)
     for AOnquyUgXawJokpcdhzTSfrtWLKQPE in AOnquyUgXawJokpcdhzTSfrtWLKQPV:
      AOnquyUgXawJokpcdhzTSfrtWLKQxB={'id':AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('id'),'title':AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('title'),'image':AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('image'),'subType':AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('subType'),'running_time':AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('running_time'),}
      AOnquyUgXawJokpcdhzTSfrtWLKQms.append(AOnquyUgXawJokpcdhzTSfrtWLKQxB)
  except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
   AOnquyUgXawJokpcdhzTSfrtWLKQmI(exception)
   return[]
  return AOnquyUgXawJokpcdhzTSfrtWLKQms
 def Get_Pass_GroupList(AOnquyUgXawJokpcdhzTSfrtWLKQsP,AOnquyUgXawJokpcdhzTSfrtWLKQxb):
  AOnquyUgXawJokpcdhzTSfrtWLKQmM=[]
  try:
   AOnquyUgXawJokpcdhzTSfrtWLKQRH='{}/api-discover/v2/discover/channels/{}/feed'.format(AOnquyUgXawJokpcdhzTSfrtWLKQsP.API_DOMAIN,AOnquyUgXawJokpcdhzTSfrtWLKQxb)
   AOnquyUgXawJokpcdhzTSfrtWLKQxR={'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':AOnquyUgXawJokpcdhzTSfrtWLKQmV(AOnquyUgXawJokpcdhzTSfrtWLKQsP.PAGE_LIMIT),'filterRestrictedContent':'false','preferRecoFeed':'true','preferMultiHeroMixedContentRow':'true','shouldIncludeTVOD':'true','category':'ALL',}
   AOnquyUgXawJokpcdhzTSfrtWLKQRY=AOnquyUgXawJokpcdhzTSfrtWLKQsP.callRequestCookies('Get',AOnquyUgXawJokpcdhzTSfrtWLKQRH,payload=AOnquyUgXawJokpcdhzTSfrtWLKQmF,params=AOnquyUgXawJokpcdhzTSfrtWLKQxR,headers=AOnquyUgXawJokpcdhzTSfrtWLKQmF,cookies=AOnquyUgXawJokpcdhzTSfrtWLKQmF)
   if AOnquyUgXawJokpcdhzTSfrtWLKQRY.status_code not in[200]:return[]
   AOnquyUgXawJokpcdhzTSfrtWLKQRj=json.loads(AOnquyUgXawJokpcdhzTSfrtWLKQRY.text).get('data')
   for AOnquyUgXawJokpcdhzTSfrtWLKQxl in AOnquyUgXawJokpcdhzTSfrtWLKQRj:
    if AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('row_name')and AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('obj_id'):
     AOnquyUgXawJokpcdhzTSfrtWLKQPe=AOnquyUgXawJokpcdhzTSfrtWLKQsP.MakeText_FreeList(AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('data'),titleName='title')
     AOnquyUgXawJokpcdhzTSfrtWLKQxB={'obj_id':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('obj_id'),'title':AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('row_name'),'preText':AOnquyUgXawJokpcdhzTSfrtWLKQPe,}
     AOnquyUgXawJokpcdhzTSfrtWLKQmM.append(AOnquyUgXawJokpcdhzTSfrtWLKQxB)
  except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
   AOnquyUgXawJokpcdhzTSfrtWLKQmI(exception)
   return[]
  return AOnquyUgXawJokpcdhzTSfrtWLKQmM
 def Get_Pass_VodList(AOnquyUgXawJokpcdhzTSfrtWLKQsP,AOnquyUgXawJokpcdhzTSfrtWLKQxb,obj_id):
  AOnquyUgXawJokpcdhzTSfrtWLKQmG=[]
  try:
   AOnquyUgXawJokpcdhzTSfrtWLKQRH='{}/api-discover/v2/discover/channels/{}/feed'.format(AOnquyUgXawJokpcdhzTSfrtWLKQsP.API_DOMAIN,AOnquyUgXawJokpcdhzTSfrtWLKQxb)
   AOnquyUgXawJokpcdhzTSfrtWLKQxR={'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':AOnquyUgXawJokpcdhzTSfrtWLKQmV(AOnquyUgXawJokpcdhzTSfrtWLKQsP.PAGE_LIMIT),'filterRestrictedContent':'false','preferRecoFeed':'true','preferMultiHeroMixedContentRow':'true','shouldIncludeTVOD':'true','category':'ALL',}
   AOnquyUgXawJokpcdhzTSfrtWLKQRY=AOnquyUgXawJokpcdhzTSfrtWLKQsP.callRequestCookies('Get',AOnquyUgXawJokpcdhzTSfrtWLKQRH,payload=AOnquyUgXawJokpcdhzTSfrtWLKQmF,params=AOnquyUgXawJokpcdhzTSfrtWLKQxR,headers=AOnquyUgXawJokpcdhzTSfrtWLKQmF,cookies=AOnquyUgXawJokpcdhzTSfrtWLKQmF)
   if AOnquyUgXawJokpcdhzTSfrtWLKQRY.status_code not in[200]:return[]
   AOnquyUgXawJokpcdhzTSfrtWLKQRj=json.loads(AOnquyUgXawJokpcdhzTSfrtWLKQRY.text).get('data')
   for AOnquyUgXawJokpcdhzTSfrtWLKQxl in AOnquyUgXawJokpcdhzTSfrtWLKQRj:
    if AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('obj_id')==obj_id:
     for AOnquyUgXawJokpcdhzTSfrtWLKQPE in AOnquyUgXawJokpcdhzTSfrtWLKQxl.get('data'):
      AOnquyUgXawJokpcdhzTSfrtWLKQxH=AOnquyUgXawJokpcdhzTSfrtWLKQxG=AOnquyUgXawJokpcdhzTSfrtWLKQPY=AOnquyUgXawJokpcdhzTSfrtWLKQPv=''
      if 'poster_url' in AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('images'):AOnquyUgXawJokpcdhzTSfrtWLKQxH =AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('images').get('poster_url') +'?imwidth=350'
      if 'story_art_url' in AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('images'):AOnquyUgXawJokpcdhzTSfrtWLKQxG =AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('images').get('story_art_url') +'?imwidth=600'
      if 'title_treatment_url' in AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('images'):AOnquyUgXawJokpcdhzTSfrtWLKQPY=AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('images').get('title_treatment_url')+'?imwidth=300'
      if 'story_art_url' in AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('images'):AOnquyUgXawJokpcdhzTSfrtWLKQPv =AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('images').get('story_art_url') +'?imwidth=600'
      AOnquyUgXawJokpcdhzTSfrtWLKQxv=''
      if AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('badge')not in[{},AOnquyUgXawJokpcdhzTSfrtWLKQmF]:
       for i in AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('badge').get('text'):
        AOnquyUgXawJokpcdhzTSfrtWLKQxv+=i.get('text')
      AOnquyUgXawJokpcdhzTSfrtWLKQxY=''
      if AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('seasonList')!=AOnquyUgXawJokpcdhzTSfrtWLKQmF:
       AOnquyUgXawJokpcdhzTSfrtWLKQxY=','.join(AOnquyUgXawJokpcdhzTSfrtWLKQmV(e)for e in AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('seasonList'))
      AOnquyUgXawJokpcdhzTSfrtWLKQxN =[]
      for AOnquyUgXawJokpcdhzTSfrtWLKQxM in AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('tags'):
       AOnquyUgXawJokpcdhzTSfrtWLKQxN.append(AOnquyUgXawJokpcdhzTSfrtWLKQxM.get('tag'))
      AOnquyUgXawJokpcdhzTSfrtWLKQxB={'id':AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('id'),'title':AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('title'),'thumbnail':{'poster':AOnquyUgXawJokpcdhzTSfrtWLKQxH,'thumb':AOnquyUgXawJokpcdhzTSfrtWLKQxG,'clearlogo':AOnquyUgXawJokpcdhzTSfrtWLKQPY,'fanart':AOnquyUgXawJokpcdhzTSfrtWLKQPv},'mpaa':AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('ageRating'),'duration':AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('running_time'),'sub_type':AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('sub_type'),'badge':AOnquyUgXawJokpcdhzTSfrtWLKQxv,'year':AOnquyUgXawJokpcdhzTSfrtWLKQPE.get('releaseYear'),'seasonList':AOnquyUgXawJokpcdhzTSfrtWLKQxY,'genreList':AOnquyUgXawJokpcdhzTSfrtWLKQxN,}
      AOnquyUgXawJokpcdhzTSfrtWLKQmG.append(AOnquyUgXawJokpcdhzTSfrtWLKQxB)
     break
  except AOnquyUgXawJokpcdhzTSfrtWLKQmE as exception:
   AOnquyUgXawJokpcdhzTSfrtWLKQmI(exception)
   return[]
  return AOnquyUgXawJokpcdhzTSfrtWLKQmG
# Created by pyminifier (https://github.com/liftoff/pyminifier)
