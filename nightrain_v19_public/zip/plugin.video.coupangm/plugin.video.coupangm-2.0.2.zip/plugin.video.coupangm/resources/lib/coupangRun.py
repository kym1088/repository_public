__author__="NightRain"
mKzcvkhxDFbuwdiOATGyYqtpLBEfPa=object
mKzcvkhxDFbuwdiOATGyYqtpLBEfPW=None
mKzcvkhxDFbuwdiOATGyYqtpLBEfPN=False
mKzcvkhxDFbuwdiOATGyYqtpLBEfPS=True
mKzcvkhxDFbuwdiOATGyYqtpLBEfPJ=type
mKzcvkhxDFbuwdiOATGyYqtpLBEfPM=dict
mKzcvkhxDFbuwdiOATGyYqtpLBEfPC=int
mKzcvkhxDFbuwdiOATGyYqtpLBEfPn=open
mKzcvkhxDFbuwdiOATGyYqtpLBEfgH=Exception
mKzcvkhxDFbuwdiOATGyYqtpLBEfgR=str
mKzcvkhxDFbuwdiOATGyYqtpLBEfge=id
mKzcvkhxDFbuwdiOATGyYqtpLBEfgU=len
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import inputstreamhelper
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
mKzcvkhxDFbuwdiOATGyYqtpLBEfHe=[{'title':'홈   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'ALL'},{'title':'TV   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'MOVIES'},{'title':'교육 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'EDUCATION'},{'title':'생중계','mode':'EVENT_GROUPLIST','vType':'LIVE'},{'title':'TV   (테마별)','mode':'THEME_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (테마별)','mode':'THEME_GROUPLIST','vType':'MOVIES'},{'title':'교육 (테마별)','mode':'THEME_GROUPLIST','vType':'EDUCATION'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},{'title':'(쿠팡) 검색','mode':'LOCAL_SEARCH','icon':'search.png'},{'title':'(쿠팡) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
mKzcvkhxDFbuwdiOATGyYqtpLBEfHU=[{'title':'시리즈 시청내역','mode':'WATCH','stype':'tvshow'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},]
mKzcvkhxDFbuwdiOATGyYqtpLBEfHj=xbmcvfs.translatePath(os.path.join(__profile__,'coupang_searched.txt'))
from coupangCore import*
class mKzcvkhxDFbuwdiOATGyYqtpLBEfHR(mKzcvkhxDFbuwdiOATGyYqtpLBEfPa):
 def __init__(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP,mKzcvkhxDFbuwdiOATGyYqtpLBEfHg,mKzcvkhxDFbuwdiOATGyYqtpLBEfHX,mKzcvkhxDFbuwdiOATGyYqtpLBEfHV):
  mKzcvkhxDFbuwdiOATGyYqtpLBEfHP._addon_url =mKzcvkhxDFbuwdiOATGyYqtpLBEfHg
  mKzcvkhxDFbuwdiOATGyYqtpLBEfHP._addon_handle=mKzcvkhxDFbuwdiOATGyYqtpLBEfHX
  mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.main_params =mKzcvkhxDFbuwdiOATGyYqtpLBEfHV
  mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj =wLnkoCBTNtsSrPzGFpxaWEJqODyIde() 
  mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.CP_COOKIE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_cookies.json'))
  mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.CP_DEVICE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_device.json'))
 def addon_noti(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP,sting):
  try:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHl=xbmcgui.Dialog()
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHl.notification(__addonname__,sting)
  except:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfPW
 def addon_log(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP,string):
  try:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHI=string.encode('utf-8','ignore')
  except:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHI='addonException: addon_log'
  mKzcvkhxDFbuwdiOATGyYqtpLBEfHs=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,mKzcvkhxDFbuwdiOATGyYqtpLBEfHI),level=mKzcvkhxDFbuwdiOATGyYqtpLBEfHs)
 def get_keyboard_input(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP,mKzcvkhxDFbuwdiOATGyYqtpLBEfRe):
  mKzcvkhxDFbuwdiOATGyYqtpLBEfHQ=mKzcvkhxDFbuwdiOATGyYqtpLBEfPW
  kb=xbmc.Keyboard()
  kb.setHeading(mKzcvkhxDFbuwdiOATGyYqtpLBEfRe)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHQ=kb.getText()
  return mKzcvkhxDFbuwdiOATGyYqtpLBEfHQ
 def get_settings_account(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP):
  mKzcvkhxDFbuwdiOATGyYqtpLBEfHr=__addon__.getSetting('id')
  mKzcvkhxDFbuwdiOATGyYqtpLBEfHa=__addon__.getSetting('pw')
  mKzcvkhxDFbuwdiOATGyYqtpLBEfHW=__addon__.getSetting('profile')
  return(mKzcvkhxDFbuwdiOATGyYqtpLBEfHr,mKzcvkhxDFbuwdiOATGyYqtpLBEfHa,mKzcvkhxDFbuwdiOATGyYqtpLBEfHW)
 def get_settings_exclusion21(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP):
  mKzcvkhxDFbuwdiOATGyYqtpLBEfHN =__addon__.getSetting('exclusion21')
  if mKzcvkhxDFbuwdiOATGyYqtpLBEfHN=='false':
   return mKzcvkhxDFbuwdiOATGyYqtpLBEfPN
  else:
   return mKzcvkhxDFbuwdiOATGyYqtpLBEfPS
 def get_settings_totalsearch(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP):
  mKzcvkhxDFbuwdiOATGyYqtpLBEfHS =mKzcvkhxDFbuwdiOATGyYqtpLBEfPS if __addon__.getSetting('local_search')=='true' else mKzcvkhxDFbuwdiOATGyYqtpLBEfPN
  mKzcvkhxDFbuwdiOATGyYqtpLBEfHJ=mKzcvkhxDFbuwdiOATGyYqtpLBEfPS if __addon__.getSetting('local_history')=='true' else mKzcvkhxDFbuwdiOATGyYqtpLBEfPN
  mKzcvkhxDFbuwdiOATGyYqtpLBEfHM =mKzcvkhxDFbuwdiOATGyYqtpLBEfPS if __addon__.getSetting('total_search')=='true' else mKzcvkhxDFbuwdiOATGyYqtpLBEfPN
  mKzcvkhxDFbuwdiOATGyYqtpLBEfHC=mKzcvkhxDFbuwdiOATGyYqtpLBEfPS if __addon__.getSetting('total_history')=='true' else mKzcvkhxDFbuwdiOATGyYqtpLBEfPN
  mKzcvkhxDFbuwdiOATGyYqtpLBEfHn=mKzcvkhxDFbuwdiOATGyYqtpLBEfPS if __addon__.getSetting('menu_bookmark')=='true' else mKzcvkhxDFbuwdiOATGyYqtpLBEfPN
  return(mKzcvkhxDFbuwdiOATGyYqtpLBEfHS,mKzcvkhxDFbuwdiOATGyYqtpLBEfHJ,mKzcvkhxDFbuwdiOATGyYqtpLBEfHM,mKzcvkhxDFbuwdiOATGyYqtpLBEfHC,mKzcvkhxDFbuwdiOATGyYqtpLBEfHn)
 def get_settings_makebookmark(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP):
  return mKzcvkhxDFbuwdiOATGyYqtpLBEfPS if __addon__.getSetting('make_bookmark')=='true' else mKzcvkhxDFbuwdiOATGyYqtpLBEfPN
 def add_dir(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP,label,sublabel='',img='',infoLabels=mKzcvkhxDFbuwdiOATGyYqtpLBEfPW,isFolder=mKzcvkhxDFbuwdiOATGyYqtpLBEfPS,params='',isLink=mKzcvkhxDFbuwdiOATGyYqtpLBEfPN,ContextMenu=mKzcvkhxDFbuwdiOATGyYqtpLBEfPW):
  mKzcvkhxDFbuwdiOATGyYqtpLBEfRH='%s?%s'%(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP._addon_url,urllib.parse.urlencode(params))
  if sublabel:mKzcvkhxDFbuwdiOATGyYqtpLBEfRe='%s < %s >'%(label,sublabel)
  else: mKzcvkhxDFbuwdiOATGyYqtpLBEfRe=label
  if not img:img='DefaultFolder.png'
  mKzcvkhxDFbuwdiOATGyYqtpLBEfRU=xbmcgui.ListItem(mKzcvkhxDFbuwdiOATGyYqtpLBEfRe)
  if mKzcvkhxDFbuwdiOATGyYqtpLBEfPJ(img)==mKzcvkhxDFbuwdiOATGyYqtpLBEfPM:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRU.setArt(img)
  else:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRU.setArt({'thumb':img,'poster':img})
  if infoLabels:mKzcvkhxDFbuwdiOATGyYqtpLBEfRU.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRU.setProperty('IsPlayable','true')
  if ContextMenu:mKzcvkhxDFbuwdiOATGyYqtpLBEfRU.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP._addon_handle,mKzcvkhxDFbuwdiOATGyYqtpLBEfRH,mKzcvkhxDFbuwdiOATGyYqtpLBEfRU,isFolder)
 def dp_Main_List(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP,args):
  (mKzcvkhxDFbuwdiOATGyYqtpLBEfHS,mKzcvkhxDFbuwdiOATGyYqtpLBEfHJ,mKzcvkhxDFbuwdiOATGyYqtpLBEfHM,mKzcvkhxDFbuwdiOATGyYqtpLBEfHC,mKzcvkhxDFbuwdiOATGyYqtpLBEfHn)=mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.get_settings_totalsearch()
  for mKzcvkhxDFbuwdiOATGyYqtpLBEfRj in mKzcvkhxDFbuwdiOATGyYqtpLBEfHe:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRe=mKzcvkhxDFbuwdiOATGyYqtpLBEfRj.get('title')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRP=''
   if mKzcvkhxDFbuwdiOATGyYqtpLBEfRj.get('mode')=='LOCAL_SEARCH' and mKzcvkhxDFbuwdiOATGyYqtpLBEfHS ==mKzcvkhxDFbuwdiOATGyYqtpLBEfPN:continue
   elif mKzcvkhxDFbuwdiOATGyYqtpLBEfRj.get('mode')=='SEARCH_HISTORY' and mKzcvkhxDFbuwdiOATGyYqtpLBEfHJ==mKzcvkhxDFbuwdiOATGyYqtpLBEfPN:continue
   elif mKzcvkhxDFbuwdiOATGyYqtpLBEfRj.get('mode')=='TOTAL_SEARCH' and mKzcvkhxDFbuwdiOATGyYqtpLBEfHM ==mKzcvkhxDFbuwdiOATGyYqtpLBEfPN:continue
   elif mKzcvkhxDFbuwdiOATGyYqtpLBEfRj.get('mode')=='TOTAL_HISTORY' and mKzcvkhxDFbuwdiOATGyYqtpLBEfHC==mKzcvkhxDFbuwdiOATGyYqtpLBEfPN:continue
   elif mKzcvkhxDFbuwdiOATGyYqtpLBEfRj.get('mode')=='MENU_BOOKMARK' and mKzcvkhxDFbuwdiOATGyYqtpLBEfHn==mKzcvkhxDFbuwdiOATGyYqtpLBEfPN:continue
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRg={'mode':mKzcvkhxDFbuwdiOATGyYqtpLBEfRj.get('mode'),'vType':mKzcvkhxDFbuwdiOATGyYqtpLBEfRj.get('vType'),'page':'1',}
   if mKzcvkhxDFbuwdiOATGyYqtpLBEfRj.get('mode')=='LOCAL_SEARCH':mKzcvkhxDFbuwdiOATGyYqtpLBEfRg['historyyn']='Y' 
   if mKzcvkhxDFbuwdiOATGyYqtpLBEfRj.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    mKzcvkhxDFbuwdiOATGyYqtpLBEfRX=mKzcvkhxDFbuwdiOATGyYqtpLBEfPN
    mKzcvkhxDFbuwdiOATGyYqtpLBEfRV =mKzcvkhxDFbuwdiOATGyYqtpLBEfPS
   else:
    mKzcvkhxDFbuwdiOATGyYqtpLBEfRX=mKzcvkhxDFbuwdiOATGyYqtpLBEfPS
    mKzcvkhxDFbuwdiOATGyYqtpLBEfRV =mKzcvkhxDFbuwdiOATGyYqtpLBEfPN
   if 'icon' in mKzcvkhxDFbuwdiOATGyYqtpLBEfRj:mKzcvkhxDFbuwdiOATGyYqtpLBEfRP=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',mKzcvkhxDFbuwdiOATGyYqtpLBEfRj.get('icon')) 
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.add_dir(mKzcvkhxDFbuwdiOATGyYqtpLBEfRe,sublabel='',img=mKzcvkhxDFbuwdiOATGyYqtpLBEfRP,infoLabels=mKzcvkhxDFbuwdiOATGyYqtpLBEfPW,isFolder=mKzcvkhxDFbuwdiOATGyYqtpLBEfRX,params=mKzcvkhxDFbuwdiOATGyYqtpLBEfRg,isLink=mKzcvkhxDFbuwdiOATGyYqtpLBEfRV)
  xbmcplugin.endOfDirectory(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP._addon_handle)
 def dp_Test(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP,args):
  mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.addon_noti('test')
 def CP_logout(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP):
  mKzcvkhxDFbuwdiOATGyYqtpLBEfHl=xbmcgui.Dialog()
  mKzcvkhxDFbuwdiOATGyYqtpLBEfRl=mKzcvkhxDFbuwdiOATGyYqtpLBEfHl.yesno(__language__(30905).encode('utf8'),__language__(30906).encode('utf8'))
  if mKzcvkhxDFbuwdiOATGyYqtpLBEfRl==mKzcvkhxDFbuwdiOATGyYqtpLBEfPN:return 
  if os.path.isfile(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.CP_COOKIE_FILENAME):os.remove(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.CP_COOKIE_FILENAME)
  mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.addon_noti(__language__(30904).encode('utf-8'))
 def option_check(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP):
  (mKzcvkhxDFbuwdiOATGyYqtpLBEfHr,mKzcvkhxDFbuwdiOATGyYqtpLBEfHa,mKzcvkhxDFbuwdiOATGyYqtpLBEfHW)=mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.get_settings_account()
  if mKzcvkhxDFbuwdiOATGyYqtpLBEfHr=='' or mKzcvkhxDFbuwdiOATGyYqtpLBEfHa=='':
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHl=xbmcgui.Dialog()
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRl=mKzcvkhxDFbuwdiOATGyYqtpLBEfHl.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if mKzcvkhxDFbuwdiOATGyYqtpLBEfRl==mKzcvkhxDFbuwdiOATGyYqtpLBEfPS:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.cookiefile_check()==mKzcvkhxDFbuwdiOATGyYqtpLBEfPN:
   if mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CP_login(mKzcvkhxDFbuwdiOATGyYqtpLBEfHr,mKzcvkhxDFbuwdiOATGyYqtpLBEfHa,mKzcvkhxDFbuwdiOATGyYqtpLBEfHW)==mKzcvkhxDFbuwdiOATGyYqtpLBEfPN:
    mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.addon_noti(__language__(30903).encode('utf8'))
    sys.exit()
  else:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.Get_CP_profile(mKzcvkhxDFbuwdiOATGyYqtpLBEfHW,limit_days=mKzcvkhxDFbuwdiOATGyYqtpLBEfPC(__addon__.getSetting('cache_ttl')),re_check=mKzcvkhxDFbuwdiOATGyYqtpLBEfPS)
 def cookiefile_check(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP):
  mKzcvkhxDFbuwdiOATGyYqtpLBEfRs={}
  try: 
   fp=mKzcvkhxDFbuwdiOATGyYqtpLBEfPn(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.CP_COOKIE_FILENAME,'r',-1,'utf-8')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRs= json.load(fp)
   fp.close()
  except mKzcvkhxDFbuwdiOATGyYqtpLBEfgH as exception:
   return mKzcvkhxDFbuwdiOATGyYqtpLBEfPN
  mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.CP=mKzcvkhxDFbuwdiOATGyYqtpLBEfRs
  (mKzcvkhxDFbuwdiOATGyYqtpLBEfHr,mKzcvkhxDFbuwdiOATGyYqtpLBEfHa,mKzcvkhxDFbuwdiOATGyYqtpLBEfHW)=mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.get_settings_account()
  (mKzcvkhxDFbuwdiOATGyYqtpLBEfRQ,mKzcvkhxDFbuwdiOATGyYqtpLBEfRr,mKzcvkhxDFbuwdiOATGyYqtpLBEfRa)=mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.Load_session_acount()
  if mKzcvkhxDFbuwdiOATGyYqtpLBEfHr!=mKzcvkhxDFbuwdiOATGyYqtpLBEfRQ or mKzcvkhxDFbuwdiOATGyYqtpLBEfHa!=mKzcvkhxDFbuwdiOATGyYqtpLBEfRr or mKzcvkhxDFbuwdiOATGyYqtpLBEfHW!=mKzcvkhxDFbuwdiOATGyYqtpLBEfgR(mKzcvkhxDFbuwdiOATGyYqtpLBEfRa):
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.Init_CP()
   return mKzcvkhxDFbuwdiOATGyYqtpLBEfPN
  mKzcvkhxDFbuwdiOATGyYqtpLBEfRW =mKzcvkhxDFbuwdiOATGyYqtpLBEfPC(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.Get_Now_Datetime().strftime('%Y%m%d'))
  mKzcvkhxDFbuwdiOATGyYqtpLBEfRN=mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.CP['SESSION']['limitdate']
  mKzcvkhxDFbuwdiOATGyYqtpLBEfRS =mKzcvkhxDFbuwdiOATGyYqtpLBEfPC(re.sub('-','',mKzcvkhxDFbuwdiOATGyYqtpLBEfRN))
  if mKzcvkhxDFbuwdiOATGyYqtpLBEfRS<mKzcvkhxDFbuwdiOATGyYqtpLBEfRW:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.Init_CP()
   return mKzcvkhxDFbuwdiOATGyYqtpLBEfPN
  return mKzcvkhxDFbuwdiOATGyYqtpLBEfPS
 def CP_login(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP,mKzcvkhxDFbuwdiOATGyYqtpLBEfHr,mKzcvkhxDFbuwdiOATGyYqtpLBEfHa,mKzcvkhxDFbuwdiOATGyYqtpLBEfHW):
  if mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.Get_CP_Login(mKzcvkhxDFbuwdiOATGyYqtpLBEfHr,mKzcvkhxDFbuwdiOATGyYqtpLBEfHa,mKzcvkhxDFbuwdiOATGyYqtpLBEfHW)==mKzcvkhxDFbuwdiOATGyYqtpLBEfPN:return mKzcvkhxDFbuwdiOATGyYqtpLBEfPN
  if mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.Get_CP_profile(mKzcvkhxDFbuwdiOATGyYqtpLBEfHW,limit_days=mKzcvkhxDFbuwdiOATGyYqtpLBEfPC(__addon__.getSetting('cache_ttl')),re_check=mKzcvkhxDFbuwdiOATGyYqtpLBEfPN)==mKzcvkhxDFbuwdiOATGyYqtpLBEfPN:return mKzcvkhxDFbuwdiOATGyYqtpLBEfPN
  return mKzcvkhxDFbuwdiOATGyYqtpLBEfPS
 def dp_Category_GroupList(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP,args):
  mKzcvkhxDFbuwdiOATGyYqtpLBEfRJ =args.get('vType') 
  mKzcvkhxDFbuwdiOATGyYqtpLBEfRM=mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.Get_Category_GroupList(mKzcvkhxDFbuwdiOATGyYqtpLBEfRJ)
  for mKzcvkhxDFbuwdiOATGyYqtpLBEfRC in mKzcvkhxDFbuwdiOATGyYqtpLBEfRM:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRe =mKzcvkhxDFbuwdiOATGyYqtpLBEfRC.get('title')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRn=mKzcvkhxDFbuwdiOATGyYqtpLBEfRC.get('pre_title')
   if mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.get_settings_exclusion21()==mKzcvkhxDFbuwdiOATGyYqtpLBEfPS and mKzcvkhxDFbuwdiOATGyYqtpLBEfRe=='성인':continue
   mKzcvkhxDFbuwdiOATGyYqtpLBEfeH={'mediatype':'tvshow','plot':mKzcvkhxDFbuwdiOATGyYqtpLBEfRn,}
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRg={'mode':'CATEGORY_LIST','collectionId':mKzcvkhxDFbuwdiOATGyYqtpLBEfRC.get('collectionId'),'vType':mKzcvkhxDFbuwdiOATGyYqtpLBEfRC.get('category'),'page':'1',}
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.add_dir(mKzcvkhxDFbuwdiOATGyYqtpLBEfRe,sublabel='',img='',infoLabels=mKzcvkhxDFbuwdiOATGyYqtpLBEfeH,isFolder=mKzcvkhxDFbuwdiOATGyYqtpLBEfPS,params=mKzcvkhxDFbuwdiOATGyYqtpLBEfRg)
  xbmcplugin.endOfDirectory(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP._addon_handle,cacheToDisc=mKzcvkhxDFbuwdiOATGyYqtpLBEfPN)
 def dp_Theme_GroupList(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP,args):
  mKzcvkhxDFbuwdiOATGyYqtpLBEfRJ =args.get('vType') 
  mKzcvkhxDFbuwdiOATGyYqtpLBEfRM=mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.Get_Theme_GroupList(mKzcvkhxDFbuwdiOATGyYqtpLBEfRJ)
  for mKzcvkhxDFbuwdiOATGyYqtpLBEfRC in mKzcvkhxDFbuwdiOATGyYqtpLBEfRM:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRe =mKzcvkhxDFbuwdiOATGyYqtpLBEfRC.get('title')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRn=mKzcvkhxDFbuwdiOATGyYqtpLBEfRC.get('pre_title')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfeH={'mediatype':'tvshow','plot':mKzcvkhxDFbuwdiOATGyYqtpLBEfRn,}
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRg={'mode':'CATEGORY_LIST','collectionId':mKzcvkhxDFbuwdiOATGyYqtpLBEfRC.get('collectionId'),'vType':mKzcvkhxDFbuwdiOATGyYqtpLBEfRC.get('category'),'page':'1',}
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.add_dir(mKzcvkhxDFbuwdiOATGyYqtpLBEfRe,sublabel='',img='',infoLabels=mKzcvkhxDFbuwdiOATGyYqtpLBEfeH,isFolder=mKzcvkhxDFbuwdiOATGyYqtpLBEfPS,params=mKzcvkhxDFbuwdiOATGyYqtpLBEfRg)
  xbmcplugin.endOfDirectory(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP._addon_handle,cacheToDisc=mKzcvkhxDFbuwdiOATGyYqtpLBEfPN)
 def dp_Event_GroupList(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP,args):
  mKzcvkhxDFbuwdiOATGyYqtpLBEfRM=mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.Get_Event_GroupList()
  for mKzcvkhxDFbuwdiOATGyYqtpLBEfRC in mKzcvkhxDFbuwdiOATGyYqtpLBEfRM:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRe =mKzcvkhxDFbuwdiOATGyYqtpLBEfRC.get('title')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRn=mKzcvkhxDFbuwdiOATGyYqtpLBEfRC.get('pre_title')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfeH={'mediatype':'tvshow','plot':mKzcvkhxDFbuwdiOATGyYqtpLBEfRn,}
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRg={'mode':'EVENT_GAMELIST','collectionId':mKzcvkhxDFbuwdiOATGyYqtpLBEfRC.get('collectionId'),'vType':'LIVE',}
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.add_dir(mKzcvkhxDFbuwdiOATGyYqtpLBEfRe,sublabel='',img='',infoLabels=mKzcvkhxDFbuwdiOATGyYqtpLBEfeH,isFolder=mKzcvkhxDFbuwdiOATGyYqtpLBEfPS,params=mKzcvkhxDFbuwdiOATGyYqtpLBEfRg)
  xbmcplugin.endOfDirectory(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP._addon_handle,cacheToDisc=mKzcvkhxDFbuwdiOATGyYqtpLBEfPN)
 def dp_Event_GameList(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP,args):
  mKzcvkhxDFbuwdiOATGyYqtpLBEfRJ =args.get('vType') 
  mKzcvkhxDFbuwdiOATGyYqtpLBEfeU =args.get('collectionId')
  mKzcvkhxDFbuwdiOATGyYqtpLBEfRM=mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.Get_Event_GameList(mKzcvkhxDFbuwdiOATGyYqtpLBEfeU)
  for mKzcvkhxDFbuwdiOATGyYqtpLBEfRC in mKzcvkhxDFbuwdiOATGyYqtpLBEfRM:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRe =mKzcvkhxDFbuwdiOATGyYqtpLBEfRC.get('title')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfge =mKzcvkhxDFbuwdiOATGyYqtpLBEfRC.get('id')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfej =mKzcvkhxDFbuwdiOATGyYqtpLBEfRC.get('thumbnail')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfeP =mKzcvkhxDFbuwdiOATGyYqtpLBEfRC.get('asis') 
   mKzcvkhxDFbuwdiOATGyYqtpLBEfeg =mKzcvkhxDFbuwdiOATGyYqtpLBEfRC.get('addInfo')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfeX =mKzcvkhxDFbuwdiOATGyYqtpLBEfRC.get('starttm')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfeH={'mediatype':'tvshow','title':mKzcvkhxDFbuwdiOATGyYqtpLBEfRe,'plot':mKzcvkhxDFbuwdiOATGyYqtpLBEfeg,}
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRg={'mode':'EVENT_LIST','id':mKzcvkhxDFbuwdiOATGyYqtpLBEfge,'asis':mKzcvkhxDFbuwdiOATGyYqtpLBEfeP,'title':mKzcvkhxDFbuwdiOATGyYqtpLBEfRe,}
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.add_dir(mKzcvkhxDFbuwdiOATGyYqtpLBEfRe,sublabel=mKzcvkhxDFbuwdiOATGyYqtpLBEfeX,img=mKzcvkhxDFbuwdiOATGyYqtpLBEfej,infoLabels=mKzcvkhxDFbuwdiOATGyYqtpLBEfeH,isFolder=mKzcvkhxDFbuwdiOATGyYqtpLBEfPS,params=mKzcvkhxDFbuwdiOATGyYqtpLBEfRg,ContextMenu=mKzcvkhxDFbuwdiOATGyYqtpLBEfPW)
  xbmcplugin.setContent(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP._addon_handle,cacheToDisc=mKzcvkhxDFbuwdiOATGyYqtpLBEfPN)
 def dp_Event_List(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP,args):
  mKzcvkhxDFbuwdiOATGyYqtpLBEfeV=args.get('id')
  mKzcvkhxDFbuwdiOATGyYqtpLBEfRM=mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.Get_Event_List(mKzcvkhxDFbuwdiOATGyYqtpLBEfeV)
  for mKzcvkhxDFbuwdiOATGyYqtpLBEfRC in mKzcvkhxDFbuwdiOATGyYqtpLBEfRM:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRe =mKzcvkhxDFbuwdiOATGyYqtpLBEfRC.get('title')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfge =mKzcvkhxDFbuwdiOATGyYqtpLBEfRC.get('id')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfej =mKzcvkhxDFbuwdiOATGyYqtpLBEfRC.get('thumbnail')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfeP =mKzcvkhxDFbuwdiOATGyYqtpLBEfRC.get('asis') 
   mKzcvkhxDFbuwdiOATGyYqtpLBEfeo =mKzcvkhxDFbuwdiOATGyYqtpLBEfRC.get('duration')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfeX =mKzcvkhxDFbuwdiOATGyYqtpLBEfRC.get('starttm')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfeH={'mediatype':'episode','title':mKzcvkhxDFbuwdiOATGyYqtpLBEfRe,'plot':mKzcvkhxDFbuwdiOATGyYqtpLBEfeP,'duration':mKzcvkhxDFbuwdiOATGyYqtpLBEfeo,}
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRg={'mode':mKzcvkhxDFbuwdiOATGyYqtpLBEfeP,'id':mKzcvkhxDFbuwdiOATGyYqtpLBEfge,'asis':mKzcvkhxDFbuwdiOATGyYqtpLBEfeP,'title':mKzcvkhxDFbuwdiOATGyYqtpLBEfRe,}
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.add_dir(mKzcvkhxDFbuwdiOATGyYqtpLBEfRe,sublabel=mKzcvkhxDFbuwdiOATGyYqtpLBEfeX,img=mKzcvkhxDFbuwdiOATGyYqtpLBEfej,infoLabels=mKzcvkhxDFbuwdiOATGyYqtpLBEfeH,isFolder=mKzcvkhxDFbuwdiOATGyYqtpLBEfPN,params=mKzcvkhxDFbuwdiOATGyYqtpLBEfRg,ContextMenu=mKzcvkhxDFbuwdiOATGyYqtpLBEfPW)
  xbmcplugin.setContent(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP._addon_handle,cacheToDisc=mKzcvkhxDFbuwdiOATGyYqtpLBEfPN)
 def dp_Category_List(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP,args):
  mKzcvkhxDFbuwdiOATGyYqtpLBEfRJ =args.get('vType') 
  mKzcvkhxDFbuwdiOATGyYqtpLBEfeU =args.get('collectionId')
  mKzcvkhxDFbuwdiOATGyYqtpLBEfel =mKzcvkhxDFbuwdiOATGyYqtpLBEfPC(args.get('page'))
  mKzcvkhxDFbuwdiOATGyYqtpLBEfRM,mKzcvkhxDFbuwdiOATGyYqtpLBEfeI=mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.Get_Category_List(mKzcvkhxDFbuwdiOATGyYqtpLBEfRJ,mKzcvkhxDFbuwdiOATGyYqtpLBEfeU,mKzcvkhxDFbuwdiOATGyYqtpLBEfel)
  for mKzcvkhxDFbuwdiOATGyYqtpLBEfRC in mKzcvkhxDFbuwdiOATGyYqtpLBEfRM:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRe =mKzcvkhxDFbuwdiOATGyYqtpLBEfRC.get('title')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfge =mKzcvkhxDFbuwdiOATGyYqtpLBEfRC.get('id')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfej =mKzcvkhxDFbuwdiOATGyYqtpLBEfRC.get('thumbnail')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfes =mKzcvkhxDFbuwdiOATGyYqtpLBEfRC.get('mpaa')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfeo =mKzcvkhxDFbuwdiOATGyYqtpLBEfRC.get('duration')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfeP =mKzcvkhxDFbuwdiOATGyYqtpLBEfRC.get('asis')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfeQ =mKzcvkhxDFbuwdiOATGyYqtpLBEfRC.get('badge')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfer =mKzcvkhxDFbuwdiOATGyYqtpLBEfRC.get('year')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfea=mKzcvkhxDFbuwdiOATGyYqtpLBEfRC.get('seasonList')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfeW =mKzcvkhxDFbuwdiOATGyYqtpLBEfRC.get('genreList')
   if mKzcvkhxDFbuwdiOATGyYqtpLBEfeP in['TVSHOW','EDUCATION']: 
    mKzcvkhxDFbuwdiOATGyYqtpLBEfeN ='SEASON_LIST'
    mKzcvkhxDFbuwdiOATGyYqtpLBEfeH={'mediatype':'tvshow','title':mKzcvkhxDFbuwdiOATGyYqtpLBEfRe,'mpaa':mKzcvkhxDFbuwdiOATGyYqtpLBEfes,'genre':mKzcvkhxDFbuwdiOATGyYqtpLBEfeW,'year':mKzcvkhxDFbuwdiOATGyYqtpLBEfer,'plot':'Year : %s\nSeason : %s'%(mKzcvkhxDFbuwdiOATGyYqtpLBEfer,mKzcvkhxDFbuwdiOATGyYqtpLBEfea),}
    mKzcvkhxDFbuwdiOATGyYqtpLBEfRX =mKzcvkhxDFbuwdiOATGyYqtpLBEfPS
   else:
    mKzcvkhxDFbuwdiOATGyYqtpLBEfeN ='MOVIE'
    mKzcvkhxDFbuwdiOATGyYqtpLBEfeH={'mediatype':'movie','title':mKzcvkhxDFbuwdiOATGyYqtpLBEfRe,'mpaa':mKzcvkhxDFbuwdiOATGyYqtpLBEfes,'genre':mKzcvkhxDFbuwdiOATGyYqtpLBEfeW,'duration':mKzcvkhxDFbuwdiOATGyYqtpLBEfeo,'year':mKzcvkhxDFbuwdiOATGyYqtpLBEfer,'plot':'(%s)'%(mKzcvkhxDFbuwdiOATGyYqtpLBEfes),}
    mKzcvkhxDFbuwdiOATGyYqtpLBEfRX =mKzcvkhxDFbuwdiOATGyYqtpLBEfPN
    mKzcvkhxDFbuwdiOATGyYqtpLBEfRe +=' (%s)'%(mKzcvkhxDFbuwdiOATGyYqtpLBEfgR(mKzcvkhxDFbuwdiOATGyYqtpLBEfer))
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRg={'mode':mKzcvkhxDFbuwdiOATGyYqtpLBEfeN,'id':mKzcvkhxDFbuwdiOATGyYqtpLBEfge,'asis':mKzcvkhxDFbuwdiOATGyYqtpLBEfeP,'seasonList':mKzcvkhxDFbuwdiOATGyYqtpLBEfea,'title':mKzcvkhxDFbuwdiOATGyYqtpLBEfRe,'thumbnail':mKzcvkhxDFbuwdiOATGyYqtpLBEfej,'year':mKzcvkhxDFbuwdiOATGyYqtpLBEfer,}
   if mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.get_settings_makebookmark():
    mKzcvkhxDFbuwdiOATGyYqtpLBEfeS={'videoid':mKzcvkhxDFbuwdiOATGyYqtpLBEfge,'vidtype':'movie' if mKzcvkhxDFbuwdiOATGyYqtpLBEfRJ=='MOVIES' else 'tvshow','vtitle':mKzcvkhxDFbuwdiOATGyYqtpLBEfRe,'vsubtitle':'',}
    mKzcvkhxDFbuwdiOATGyYqtpLBEfeJ=json.dumps(mKzcvkhxDFbuwdiOATGyYqtpLBEfeS)
    mKzcvkhxDFbuwdiOATGyYqtpLBEfeJ=urllib.parse.quote(mKzcvkhxDFbuwdiOATGyYqtpLBEfeJ)
    mKzcvkhxDFbuwdiOATGyYqtpLBEfeM='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(mKzcvkhxDFbuwdiOATGyYqtpLBEfeJ)
    mKzcvkhxDFbuwdiOATGyYqtpLBEfeC=[('(통합) 찜 영상에 추가',mKzcvkhxDFbuwdiOATGyYqtpLBEfeM)]
   else:
    mKzcvkhxDFbuwdiOATGyYqtpLBEfeC=mKzcvkhxDFbuwdiOATGyYqtpLBEfPW
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.add_dir(mKzcvkhxDFbuwdiOATGyYqtpLBEfRe,sublabel=mKzcvkhxDFbuwdiOATGyYqtpLBEfeQ,img=mKzcvkhxDFbuwdiOATGyYqtpLBEfej,infoLabels=mKzcvkhxDFbuwdiOATGyYqtpLBEfeH,isFolder=mKzcvkhxDFbuwdiOATGyYqtpLBEfRX,params=mKzcvkhxDFbuwdiOATGyYqtpLBEfRg,ContextMenu=mKzcvkhxDFbuwdiOATGyYqtpLBEfeC)
  if mKzcvkhxDFbuwdiOATGyYqtpLBEfeI:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRg['mode'] ='CATEGORY_LIST' 
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRg['collectionId']=mKzcvkhxDFbuwdiOATGyYqtpLBEfeU 
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRg['vType'] =mKzcvkhxDFbuwdiOATGyYqtpLBEfRJ 
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRg['page'] =mKzcvkhxDFbuwdiOATGyYqtpLBEfgR(mKzcvkhxDFbuwdiOATGyYqtpLBEfel+1)
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRe='[B]%s >>[/B]'%'다음 페이지'
   mKzcvkhxDFbuwdiOATGyYqtpLBEfen=mKzcvkhxDFbuwdiOATGyYqtpLBEfgR(mKzcvkhxDFbuwdiOATGyYqtpLBEfel+1)
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRP=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.add_dir(mKzcvkhxDFbuwdiOATGyYqtpLBEfRe,sublabel=mKzcvkhxDFbuwdiOATGyYqtpLBEfen,img=mKzcvkhxDFbuwdiOATGyYqtpLBEfRP,infoLabels=mKzcvkhxDFbuwdiOATGyYqtpLBEfPW,isFolder=mKzcvkhxDFbuwdiOATGyYqtpLBEfPS,params=mKzcvkhxDFbuwdiOATGyYqtpLBEfRg)
  if mKzcvkhxDFbuwdiOATGyYqtpLBEfRJ=='TVSHOWS':xbmcplugin.setContent(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP._addon_handle,'tvshows')
  else:xbmcplugin.setContent(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP._addon_handle,'movies')
  xbmcplugin.endOfDirectory(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP._addon_handle,cacheToDisc=mKzcvkhxDFbuwdiOATGyYqtpLBEfPN)
 def dp_Season_List(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP,args):
  mKzcvkhxDFbuwdiOATGyYqtpLBEfUH =args.get('title')
  mKzcvkhxDFbuwdiOATGyYqtpLBEfUR =args.get('id')
  mKzcvkhxDFbuwdiOATGyYqtpLBEfeP =args.get('asis')
  mKzcvkhxDFbuwdiOATGyYqtpLBEfea =args.get('seasonList')
  mKzcvkhxDFbuwdiOATGyYqtpLBEfej =args.get('thumbnail')
  mKzcvkhxDFbuwdiOATGyYqtpLBEfer =args.get('year')
  if mKzcvkhxDFbuwdiOATGyYqtpLBEfea in['',mKzcvkhxDFbuwdiOATGyYqtpLBEfPW]:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfea=mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.Get_vInfo(mKzcvkhxDFbuwdiOATGyYqtpLBEfUR).get('seasonList')
  if mKzcvkhxDFbuwdiOATGyYqtpLBEfgU(mKzcvkhxDFbuwdiOATGyYqtpLBEfea.split(','))>1:
   for mKzcvkhxDFbuwdiOATGyYqtpLBEfUe in mKzcvkhxDFbuwdiOATGyYqtpLBEfea.split(','):
    mKzcvkhxDFbuwdiOATGyYqtpLBEfRe='시즌 '+mKzcvkhxDFbuwdiOATGyYqtpLBEfUe
    mKzcvkhxDFbuwdiOATGyYqtpLBEfeH={'mediatype':'tvshow','plot':'%s (%s)'%(mKzcvkhxDFbuwdiOATGyYqtpLBEfUH,mKzcvkhxDFbuwdiOATGyYqtpLBEfer),}
    mKzcvkhxDFbuwdiOATGyYqtpLBEfRg={'mode':'EPISODE_LIST','programid':mKzcvkhxDFbuwdiOATGyYqtpLBEfUR,'programnm':mKzcvkhxDFbuwdiOATGyYqtpLBEfUH,'season':mKzcvkhxDFbuwdiOATGyYqtpLBEfUe,'asis':mKzcvkhxDFbuwdiOATGyYqtpLBEfeP,'programimg':mKzcvkhxDFbuwdiOATGyYqtpLBEfej,}
    mKzcvkhxDFbuwdiOATGyYqtpLBEfUj=mKzcvkhxDFbuwdiOATGyYqtpLBEfej.replace('\'','\"')
    mKzcvkhxDFbuwdiOATGyYqtpLBEfUj=json.loads(mKzcvkhxDFbuwdiOATGyYqtpLBEfUj)
    mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.add_dir(mKzcvkhxDFbuwdiOATGyYqtpLBEfRe,sublabel='',img=mKzcvkhxDFbuwdiOATGyYqtpLBEfUj,infoLabels=mKzcvkhxDFbuwdiOATGyYqtpLBEfeH,isFolder=mKzcvkhxDFbuwdiOATGyYqtpLBEfPS,params=mKzcvkhxDFbuwdiOATGyYqtpLBEfRg)
   xbmcplugin.setContent(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP._addon_handle,cacheToDisc=mKzcvkhxDFbuwdiOATGyYqtpLBEfPN)
  else:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfUP={'programid':mKzcvkhxDFbuwdiOATGyYqtpLBEfUR,'programnm':mKzcvkhxDFbuwdiOATGyYqtpLBEfUH,'season':mKzcvkhxDFbuwdiOATGyYqtpLBEfea,'programimg':mKzcvkhxDFbuwdiOATGyYqtpLBEfej,}
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.dp_Episode_List(mKzcvkhxDFbuwdiOATGyYqtpLBEfUP)
 def dp_Episode_List(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP,args):
  mKzcvkhxDFbuwdiOATGyYqtpLBEfUR =args.get('programid')
  mKzcvkhxDFbuwdiOATGyYqtpLBEfUH =args.get('programnm')
  mKzcvkhxDFbuwdiOATGyYqtpLBEfUg =args.get('season')
  mKzcvkhxDFbuwdiOATGyYqtpLBEfUX =args.get('programimg')
  mKzcvkhxDFbuwdiOATGyYqtpLBEfUV=mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.Get_Episode_List(mKzcvkhxDFbuwdiOATGyYqtpLBEfUR,mKzcvkhxDFbuwdiOATGyYqtpLBEfUg)
  for mKzcvkhxDFbuwdiOATGyYqtpLBEfUe in mKzcvkhxDFbuwdiOATGyYqtpLBEfUV:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfUo =mKzcvkhxDFbuwdiOATGyYqtpLBEfUe.get('title')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfUl =mKzcvkhxDFbuwdiOATGyYqtpLBEfUe.get('id')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfeP =mKzcvkhxDFbuwdiOATGyYqtpLBEfUe.get('asis')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfej =mKzcvkhxDFbuwdiOATGyYqtpLBEfUe.get('thumbnail')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfes =mKzcvkhxDFbuwdiOATGyYqtpLBEfUe.get('mpaa')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfeo =mKzcvkhxDFbuwdiOATGyYqtpLBEfUe.get('duration')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfer =mKzcvkhxDFbuwdiOATGyYqtpLBEfUe.get('year')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfUI =mKzcvkhxDFbuwdiOATGyYqtpLBEfUe.get('episode')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfeW =mKzcvkhxDFbuwdiOATGyYqtpLBEfUe.get('genreList')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfUs =mKzcvkhxDFbuwdiOATGyYqtpLBEfUe.get('desc')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfUQ ='%sx%s'%(mKzcvkhxDFbuwdiOATGyYqtpLBEfUg,mKzcvkhxDFbuwdiOATGyYqtpLBEfUI)
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRe ='%s. %s'%(mKzcvkhxDFbuwdiOATGyYqtpLBEfUQ,mKzcvkhxDFbuwdiOATGyYqtpLBEfUo)
   mKzcvkhxDFbuwdiOATGyYqtpLBEfeH={'mediatype':'tvshow','mpaa':mKzcvkhxDFbuwdiOATGyYqtpLBEfes,'genre':mKzcvkhxDFbuwdiOATGyYqtpLBEfeW,'duration':mKzcvkhxDFbuwdiOATGyYqtpLBEfeo,'year':mKzcvkhxDFbuwdiOATGyYqtpLBEfer,'plot':'%s (%s)\n\n%s'%(mKzcvkhxDFbuwdiOATGyYqtpLBEfUH,mKzcvkhxDFbuwdiOATGyYqtpLBEfUQ,mKzcvkhxDFbuwdiOATGyYqtpLBEfUs),}
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRg={'mode':'VOD','programid':mKzcvkhxDFbuwdiOATGyYqtpLBEfUR,'programnm':mKzcvkhxDFbuwdiOATGyYqtpLBEfUH,'title':mKzcvkhxDFbuwdiOATGyYqtpLBEfRe,'season':mKzcvkhxDFbuwdiOATGyYqtpLBEfUg,'id':mKzcvkhxDFbuwdiOATGyYqtpLBEfUl,'asis':mKzcvkhxDFbuwdiOATGyYqtpLBEfeP,'thumbnail':mKzcvkhxDFbuwdiOATGyYqtpLBEfej,'programimg':mKzcvkhxDFbuwdiOATGyYqtpLBEfUX,}
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.add_dir(mKzcvkhxDFbuwdiOATGyYqtpLBEfRe,sublabel='',img=mKzcvkhxDFbuwdiOATGyYqtpLBEfej,infoLabels=mKzcvkhxDFbuwdiOATGyYqtpLBEfeH,isFolder=mKzcvkhxDFbuwdiOATGyYqtpLBEfPN,params=mKzcvkhxDFbuwdiOATGyYqtpLBEfRg)
  xbmcplugin.setContent(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP._addon_handle,cacheToDisc=mKzcvkhxDFbuwdiOATGyYqtpLBEfPN)
 def play_VIDEO(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP,args):
  mKzcvkhxDFbuwdiOATGyYqtpLBEfUr =args.get('id')
  mKzcvkhxDFbuwdiOATGyYqtpLBEfeP =args.get('asis')
  if mKzcvkhxDFbuwdiOATGyYqtpLBEfeP in['HIGHLIGHT']:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfUa,mKzcvkhxDFbuwdiOATGyYqtpLBEfUW=mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.GetEventURL(mKzcvkhxDFbuwdiOATGyYqtpLBEfUr,mKzcvkhxDFbuwdiOATGyYqtpLBEfeP)
  elif mKzcvkhxDFbuwdiOATGyYqtpLBEfeP in['LIVE']:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfUa,mKzcvkhxDFbuwdiOATGyYqtpLBEfUW=mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.GetEventURL_Live(mKzcvkhxDFbuwdiOATGyYqtpLBEfUr,mKzcvkhxDFbuwdiOATGyYqtpLBEfeP)
  else:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfUa,mKzcvkhxDFbuwdiOATGyYqtpLBEfUW=mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.GetBroadURL(mKzcvkhxDFbuwdiOATGyYqtpLBEfUr)
  mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.addon_log('asis, url : %s - %s - %s'%(mKzcvkhxDFbuwdiOATGyYqtpLBEfeP,mKzcvkhxDFbuwdiOATGyYqtpLBEfUr,mKzcvkhxDFbuwdiOATGyYqtpLBEfUa))
  if mKzcvkhxDFbuwdiOATGyYqtpLBEfUa=='':
   if mKzcvkhxDFbuwdiOATGyYqtpLBEfUW=='':
    mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.addon_noti(__language__(30907).encode('utf8'))
   else:
    mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.addon_noti(mKzcvkhxDFbuwdiOATGyYqtpLBEfUW)
   return
  mKzcvkhxDFbuwdiOATGyYqtpLBEfUN='PCID=%s;token=%s;member_srl=%s;NEXT_LOCALE=%s;bm_mi=%s;ak_bmsc=%s;bm_sv=%s'%(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.CP['SESSION']['PCID'],mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.CP['SESSION']['token'],mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.CP['SESSION']['member_srl'],mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.CP['SESSION']['NEXT_LOCALE'],mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.CP['SESSION']['bm_mi'],mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.CP['SESSION']['ak_bmsc'],mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.CP['SESSION']['bm_sv'],)
  mKzcvkhxDFbuwdiOATGyYqtpLBEfUS='%s|Cookie=%s'%(mKzcvkhxDFbuwdiOATGyYqtpLBEfUa,mKzcvkhxDFbuwdiOATGyYqtpLBEfUN)
  mKzcvkhxDFbuwdiOATGyYqtpLBEfUJ=xbmcgui.ListItem(path=mKzcvkhxDFbuwdiOATGyYqtpLBEfUS)
  if mKzcvkhxDFbuwdiOATGyYqtpLBEfUW:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfUM =mKzcvkhxDFbuwdiOATGyYqtpLBEfUW 
   mKzcvkhxDFbuwdiOATGyYqtpLBEfUC ='mpd'
   mKzcvkhxDFbuwdiOATGyYqtpLBEfUn ='com.widevine.alpha'
   mKzcvkhxDFbuwdiOATGyYqtpLBEfjH =inputstreamhelper.Helper(mKzcvkhxDFbuwdiOATGyYqtpLBEfUC,drm='widevine')
   if mKzcvkhxDFbuwdiOATGyYqtpLBEfjH.check_inputstream():
    mKzcvkhxDFbuwdiOATGyYqtpLBEfjR,mKzcvkhxDFbuwdiOATGyYqtpLBEfje,mKzcvkhxDFbuwdiOATGyYqtpLBEfjU=mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.Make_authHeader()
    mKzcvkhxDFbuwdiOATGyYqtpLBEfjP={'traceparent':mKzcvkhxDFbuwdiOATGyYqtpLBEfjR,'tracestate':mKzcvkhxDFbuwdiOATGyYqtpLBEfje,'newrelic':mKzcvkhxDFbuwdiOATGyYqtpLBEfjU,'content-type':'application/octet-stream','User-Agent':mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.USER_AGENT,'Cookie':mKzcvkhxDFbuwdiOATGyYqtpLBEfUN,}
    mKzcvkhxDFbuwdiOATGyYqtpLBEfjg=mKzcvkhxDFbuwdiOATGyYqtpLBEfUM+'|'+urllib.parse.urlencode(mKzcvkhxDFbuwdiOATGyYqtpLBEfjP)+'|R{SSM}|'
    mKzcvkhxDFbuwdiOATGyYqtpLBEfUJ.setProperty('inputstream',mKzcvkhxDFbuwdiOATGyYqtpLBEfjH.inputstream_addon)
    mKzcvkhxDFbuwdiOATGyYqtpLBEfUJ.setProperty('inputstream.adaptive.manifest_type',mKzcvkhxDFbuwdiOATGyYqtpLBEfUC)
    mKzcvkhxDFbuwdiOATGyYqtpLBEfUJ.setProperty('inputstream.adaptive.license_type',mKzcvkhxDFbuwdiOATGyYqtpLBEfUn)
    mKzcvkhxDFbuwdiOATGyYqtpLBEfUJ.setProperty('inputstream.adaptive.license_key',mKzcvkhxDFbuwdiOATGyYqtpLBEfjg)
    mKzcvkhxDFbuwdiOATGyYqtpLBEfUJ.setMimeType('application/dash+xml')
    mKzcvkhxDFbuwdiOATGyYqtpLBEfUJ.setContentLookup(mKzcvkhxDFbuwdiOATGyYqtpLBEfPN)
  xbmcplugin.setResolvedUrl(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP._addon_handle,mKzcvkhxDFbuwdiOATGyYqtpLBEfPS,mKzcvkhxDFbuwdiOATGyYqtpLBEfUJ)
  try:
   if mKzcvkhxDFbuwdiOATGyYqtpLBEfeP=='MOVIE':
    mKzcvkhxDFbuwdiOATGyYqtpLBEfjX='movie'
    mKzcvkhxDFbuwdiOATGyYqtpLBEfRg={'code':mKzcvkhxDFbuwdiOATGyYqtpLBEfUr,'asis':mKzcvkhxDFbuwdiOATGyYqtpLBEfeP,'title':args.get('title'),'img':args.get('thumbnail'),}
    mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.Save_Watched_List(mKzcvkhxDFbuwdiOATGyYqtpLBEfjX,mKzcvkhxDFbuwdiOATGyYqtpLBEfRg)
   elif mKzcvkhxDFbuwdiOATGyYqtpLBEfeP=='TVSHOW':
    mKzcvkhxDFbuwdiOATGyYqtpLBEfjX='tvshow'
    mKzcvkhxDFbuwdiOATGyYqtpLBEfRg={'code':args.get('programid'),'asis':mKzcvkhxDFbuwdiOATGyYqtpLBEfeP,'title':'%s <%s>'%(args.get('title'),args.get('programnm')),'img':args.get('programimg'),}
    mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.Save_Watched_List(mKzcvkhxDFbuwdiOATGyYqtpLBEfjX,mKzcvkhxDFbuwdiOATGyYqtpLBEfRg)
  except:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfPW
 def dp_Global_Search(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP,args):
  mKzcvkhxDFbuwdiOATGyYqtpLBEfeN=args.get('mode')
  if mKzcvkhxDFbuwdiOATGyYqtpLBEfeN=='TOTAL_SEARCH':
   mKzcvkhxDFbuwdiOATGyYqtpLBEfjV='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfjV='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(mKzcvkhxDFbuwdiOATGyYqtpLBEfjV)
 def dp_Bookmark_Menu(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP,args):
  mKzcvkhxDFbuwdiOATGyYqtpLBEfjV='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(mKzcvkhxDFbuwdiOATGyYqtpLBEfjV)
 def dp_Search_List(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP,args):
  mKzcvkhxDFbuwdiOATGyYqtpLBEfel =mKzcvkhxDFbuwdiOATGyYqtpLBEfPC(args.get('page'))
  if 'search_key' in args:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfjo=args.get('search_key')
  else:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfjo=mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.get_keyboard_input(__language__(30908).encode('utf-8'))
   if not mKzcvkhxDFbuwdiOATGyYqtpLBEfjo:
    return
  mKzcvkhxDFbuwdiOATGyYqtpLBEfjl,mKzcvkhxDFbuwdiOATGyYqtpLBEfeI=mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.Get_Search_List(mKzcvkhxDFbuwdiOATGyYqtpLBEfjo,mKzcvkhxDFbuwdiOATGyYqtpLBEfel)
  for mKzcvkhxDFbuwdiOATGyYqtpLBEfjI in mKzcvkhxDFbuwdiOATGyYqtpLBEfjl:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfge =mKzcvkhxDFbuwdiOATGyYqtpLBEfjI.get('id')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRe =mKzcvkhxDFbuwdiOATGyYqtpLBEfjI.get('title')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfeP =mKzcvkhxDFbuwdiOATGyYqtpLBEfjI.get('asis')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfej =mKzcvkhxDFbuwdiOATGyYqtpLBEfjI.get('thumbnail')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfes =mKzcvkhxDFbuwdiOATGyYqtpLBEfjI.get('mpaa')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfer =mKzcvkhxDFbuwdiOATGyYqtpLBEfjI.get('year')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfeo =mKzcvkhxDFbuwdiOATGyYqtpLBEfjI.get('duration')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfeQ =mKzcvkhxDFbuwdiOATGyYqtpLBEfjI.get('badge')
   if mKzcvkhxDFbuwdiOATGyYqtpLBEfeP=='TVSHOW': 
    mKzcvkhxDFbuwdiOATGyYqtpLBEfeN ='SEASON_LIST'
    mKzcvkhxDFbuwdiOATGyYqtpLBEfeH={'mediatype':'tvshow','title':mKzcvkhxDFbuwdiOATGyYqtpLBEfRe,'mpaa':mKzcvkhxDFbuwdiOATGyYqtpLBEfes,'year':mKzcvkhxDFbuwdiOATGyYqtpLBEfer,'plot':'Year : %s'%(mKzcvkhxDFbuwdiOATGyYqtpLBEfer),}
    mKzcvkhxDFbuwdiOATGyYqtpLBEfRX =mKzcvkhxDFbuwdiOATGyYqtpLBEfPS
   elif mKzcvkhxDFbuwdiOATGyYqtpLBEfeP=='MOVIE':
    mKzcvkhxDFbuwdiOATGyYqtpLBEfeN ='MOVIE'
    mKzcvkhxDFbuwdiOATGyYqtpLBEfeH={'mediatype':'movie','title':mKzcvkhxDFbuwdiOATGyYqtpLBEfRe,'mpaa':mKzcvkhxDFbuwdiOATGyYqtpLBEfes,'duration':mKzcvkhxDFbuwdiOATGyYqtpLBEfeo,'year':mKzcvkhxDFbuwdiOATGyYqtpLBEfer,'plot':'(%s)'%(mKzcvkhxDFbuwdiOATGyYqtpLBEfes),}
    mKzcvkhxDFbuwdiOATGyYqtpLBEfRX =mKzcvkhxDFbuwdiOATGyYqtpLBEfPN
    mKzcvkhxDFbuwdiOATGyYqtpLBEfRe +=' (%s)'%(mKzcvkhxDFbuwdiOATGyYqtpLBEfgR(mKzcvkhxDFbuwdiOATGyYqtpLBEfer))
   elif mKzcvkhxDFbuwdiOATGyYqtpLBEfeP=='HIGHLIGHT':
    mKzcvkhxDFbuwdiOATGyYqtpLBEfeN ='HIGHLIGHT'
    mKzcvkhxDFbuwdiOATGyYqtpLBEfeH={'mediatype':'episode','title':mKzcvkhxDFbuwdiOATGyYqtpLBEfRe,'duration':mKzcvkhxDFbuwdiOATGyYqtpLBEfeo,'plot':mKzcvkhxDFbuwdiOATGyYqtpLBEfeN,}
    mKzcvkhxDFbuwdiOATGyYqtpLBEfRX =mKzcvkhxDFbuwdiOATGyYqtpLBEfPN
   elif mKzcvkhxDFbuwdiOATGyYqtpLBEfeP=='LIVE':
    mKzcvkhxDFbuwdiOATGyYqtpLBEfeN ='LIVE'
    mKzcvkhxDFbuwdiOATGyYqtpLBEfeH={'mediatype':'episode','title':mKzcvkhxDFbuwdiOATGyYqtpLBEfRe,'plot':mKzcvkhxDFbuwdiOATGyYqtpLBEfeN,}
    mKzcvkhxDFbuwdiOATGyYqtpLBEfRX =mKzcvkhxDFbuwdiOATGyYqtpLBEfPN
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRg={'mode':mKzcvkhxDFbuwdiOATGyYqtpLBEfeN,'id':mKzcvkhxDFbuwdiOATGyYqtpLBEfge,'asis':mKzcvkhxDFbuwdiOATGyYqtpLBEfeP,'seasonList':'','title':mKzcvkhxDFbuwdiOATGyYqtpLBEfRe,'thumbnail':json.dumps(mKzcvkhxDFbuwdiOATGyYqtpLBEfej,separators=(',',':')),'year':mKzcvkhxDFbuwdiOATGyYqtpLBEfer,}
   if mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.get_settings_makebookmark()and mKzcvkhxDFbuwdiOATGyYqtpLBEfeP not in['HIGHLIGHT','']:
    mKzcvkhxDFbuwdiOATGyYqtpLBEfeS={'videoid':mKzcvkhxDFbuwdiOATGyYqtpLBEfge,'vidtype':'movie' if mKzcvkhxDFbuwdiOATGyYqtpLBEfeP=='MOVIE' else 'tvshow','vtitle':mKzcvkhxDFbuwdiOATGyYqtpLBEfRe,'vsubtitle':'',}
    mKzcvkhxDFbuwdiOATGyYqtpLBEfeJ=json.dumps(mKzcvkhxDFbuwdiOATGyYqtpLBEfeS)
    mKzcvkhxDFbuwdiOATGyYqtpLBEfeJ=urllib.parse.quote(mKzcvkhxDFbuwdiOATGyYqtpLBEfeJ)
    mKzcvkhxDFbuwdiOATGyYqtpLBEfeM='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(mKzcvkhxDFbuwdiOATGyYqtpLBEfeJ)
    mKzcvkhxDFbuwdiOATGyYqtpLBEfeC=[('(통합) 찜 영상에 추가',mKzcvkhxDFbuwdiOATGyYqtpLBEfeM)]
   else:
    mKzcvkhxDFbuwdiOATGyYqtpLBEfeC=mKzcvkhxDFbuwdiOATGyYqtpLBEfPW
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.add_dir(mKzcvkhxDFbuwdiOATGyYqtpLBEfRe,sublabel=mKzcvkhxDFbuwdiOATGyYqtpLBEfeQ,img=mKzcvkhxDFbuwdiOATGyYqtpLBEfej,infoLabels=mKzcvkhxDFbuwdiOATGyYqtpLBEfeH,isFolder=mKzcvkhxDFbuwdiOATGyYqtpLBEfRX,params=mKzcvkhxDFbuwdiOATGyYqtpLBEfRg,ContextMenu=mKzcvkhxDFbuwdiOATGyYqtpLBEfeC)
  if mKzcvkhxDFbuwdiOATGyYqtpLBEfeI:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRg={}
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRg['mode'] ='LOCAL_SEARCH'
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRg['search_key']=mKzcvkhxDFbuwdiOATGyYqtpLBEfjo
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRg['page'] =mKzcvkhxDFbuwdiOATGyYqtpLBEfgR(mKzcvkhxDFbuwdiOATGyYqtpLBEfel+1)
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRe='[B]%s >>[/B]'%'다음 페이지'
   mKzcvkhxDFbuwdiOATGyYqtpLBEfen=mKzcvkhxDFbuwdiOATGyYqtpLBEfgR(mKzcvkhxDFbuwdiOATGyYqtpLBEfel+1)
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRP=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.add_dir(mKzcvkhxDFbuwdiOATGyYqtpLBEfRe,sublabel=mKzcvkhxDFbuwdiOATGyYqtpLBEfen,img=mKzcvkhxDFbuwdiOATGyYqtpLBEfRP,infoLabels=mKzcvkhxDFbuwdiOATGyYqtpLBEfPW,isFolder=mKzcvkhxDFbuwdiOATGyYqtpLBEfPS,params=mKzcvkhxDFbuwdiOATGyYqtpLBEfRg)
  xbmcplugin.setContent(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP._addon_handle,'movies')
  xbmcplugin.endOfDirectory(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP._addon_handle,cacheToDisc=mKzcvkhxDFbuwdiOATGyYqtpLBEfPS)
  if args.get('historyyn')=='Y':mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.Save_Searched_List(mKzcvkhxDFbuwdiOATGyYqtpLBEfjo)
 def Load_List_File(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP,mKzcvkhxDFbuwdiOATGyYqtpLBEfjX): 
  try:
   if mKzcvkhxDFbuwdiOATGyYqtpLBEfjX=='search':
    mKzcvkhxDFbuwdiOATGyYqtpLBEfjs=mKzcvkhxDFbuwdiOATGyYqtpLBEfHj
   elif mKzcvkhxDFbuwdiOATGyYqtpLBEfjX in['tvshow','movie']:
    mKzcvkhxDFbuwdiOATGyYqtpLBEfjs=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%mKzcvkhxDFbuwdiOATGyYqtpLBEfjX))
   else:
    return[]
   fp=mKzcvkhxDFbuwdiOATGyYqtpLBEfPn(mKzcvkhxDFbuwdiOATGyYqtpLBEfjs,'r',-1,'utf-8')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfjQ=fp.readlines()
   fp.close()
  except:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfjQ=[]
  return mKzcvkhxDFbuwdiOATGyYqtpLBEfjQ
 def Save_Watched_List(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP,mKzcvkhxDFbuwdiOATGyYqtpLBEfjX,mKzcvkhxDFbuwdiOATGyYqtpLBEfHV):
  try:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfjr=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%mKzcvkhxDFbuwdiOATGyYqtpLBEfjX))
   mKzcvkhxDFbuwdiOATGyYqtpLBEfja=mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.Load_List_File(mKzcvkhxDFbuwdiOATGyYqtpLBEfjX) 
   fp=mKzcvkhxDFbuwdiOATGyYqtpLBEfPn(mKzcvkhxDFbuwdiOATGyYqtpLBEfjr,'w',-1,'utf-8')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfjW=urllib.parse.urlencode(mKzcvkhxDFbuwdiOATGyYqtpLBEfHV)
   mKzcvkhxDFbuwdiOATGyYqtpLBEfjW=mKzcvkhxDFbuwdiOATGyYqtpLBEfjW+'\n'
   fp.write(mKzcvkhxDFbuwdiOATGyYqtpLBEfjW)
   mKzcvkhxDFbuwdiOATGyYqtpLBEfjN=0
   for mKzcvkhxDFbuwdiOATGyYqtpLBEfjS in mKzcvkhxDFbuwdiOATGyYqtpLBEfja:
    mKzcvkhxDFbuwdiOATGyYqtpLBEfjJ=mKzcvkhxDFbuwdiOATGyYqtpLBEfPM(urllib.parse.parse_qsl(mKzcvkhxDFbuwdiOATGyYqtpLBEfjS))
    mKzcvkhxDFbuwdiOATGyYqtpLBEfjM=mKzcvkhxDFbuwdiOATGyYqtpLBEfHV.get('code').strip()
    mKzcvkhxDFbuwdiOATGyYqtpLBEfjC=mKzcvkhxDFbuwdiOATGyYqtpLBEfjJ.get('code').strip()
    if mKzcvkhxDFbuwdiOATGyYqtpLBEfjM!=mKzcvkhxDFbuwdiOATGyYqtpLBEfjC:
     fp.write(mKzcvkhxDFbuwdiOATGyYqtpLBEfjS)
     mKzcvkhxDFbuwdiOATGyYqtpLBEfjN+=1
     if mKzcvkhxDFbuwdiOATGyYqtpLBEfjN>=50:break
   fp.close()
  except:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfPW
 def Save_Searched_List(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP,mKzcvkhxDFbuwdiOATGyYqtpLBEfjo):
  try:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfjo=mKzcvkhxDFbuwdiOATGyYqtpLBEfjo.strip()
   mKzcvkhxDFbuwdiOATGyYqtpLBEfja=mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.Load_List_File('search') 
   fp=mKzcvkhxDFbuwdiOATGyYqtpLBEfPn(mKzcvkhxDFbuwdiOATGyYqtpLBEfHj,'w',-1,'utf-8')
   fp.write(mKzcvkhxDFbuwdiOATGyYqtpLBEfjo+'\n')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfjN=0
   for mKzcvkhxDFbuwdiOATGyYqtpLBEfjS in mKzcvkhxDFbuwdiOATGyYqtpLBEfja:
    mKzcvkhxDFbuwdiOATGyYqtpLBEfjS=mKzcvkhxDFbuwdiOATGyYqtpLBEfjS.strip()
    if mKzcvkhxDFbuwdiOATGyYqtpLBEfjo!=mKzcvkhxDFbuwdiOATGyYqtpLBEfjS:
     fp.write(mKzcvkhxDFbuwdiOATGyYqtpLBEfjS+'\n')
     mKzcvkhxDFbuwdiOATGyYqtpLBEfjN+=1
     if mKzcvkhxDFbuwdiOATGyYqtpLBEfjN>=50:break
   fp.close()
  except:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfPW
 def dp_Search_History(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP,args):
  mKzcvkhxDFbuwdiOATGyYqtpLBEfjn=mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.Load_List_File('search')
  for mKzcvkhxDFbuwdiOATGyYqtpLBEfPH in mKzcvkhxDFbuwdiOATGyYqtpLBEfjn:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfPH=mKzcvkhxDFbuwdiOATGyYqtpLBEfPH.strip()
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRg={'mode':'LOCAL_SEARCH','search_key':mKzcvkhxDFbuwdiOATGyYqtpLBEfPH,'page':'1','historyyn':'Y',}
   mKzcvkhxDFbuwdiOATGyYqtpLBEfPR={'mode':'SEARCH_REMOVE','stype':'ONE','skey':mKzcvkhxDFbuwdiOATGyYqtpLBEfPH,}
   mKzcvkhxDFbuwdiOATGyYqtpLBEfPe=urllib.parse.urlencode(mKzcvkhxDFbuwdiOATGyYqtpLBEfPR)
   mKzcvkhxDFbuwdiOATGyYqtpLBEfeC=[('선택된 검색어 ( %s ) 삭제'%(mKzcvkhxDFbuwdiOATGyYqtpLBEfPH),'RunPlugin(plugin://plugin.video.coupangm/?%s)'%(mKzcvkhxDFbuwdiOATGyYqtpLBEfPe))]
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.add_dir(mKzcvkhxDFbuwdiOATGyYqtpLBEfPH,sublabel='',img=mKzcvkhxDFbuwdiOATGyYqtpLBEfPW,infoLabels=mKzcvkhxDFbuwdiOATGyYqtpLBEfPW,isFolder=mKzcvkhxDFbuwdiOATGyYqtpLBEfPS,params=mKzcvkhxDFbuwdiOATGyYqtpLBEfRg,ContextMenu=mKzcvkhxDFbuwdiOATGyYqtpLBEfeC)
  mKzcvkhxDFbuwdiOATGyYqtpLBEfeH={'plot':'검색목록 전체를 삭제합니다.'}
  mKzcvkhxDFbuwdiOATGyYqtpLBEfRe='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  mKzcvkhxDFbuwdiOATGyYqtpLBEfRg={'mode':'SEARCH_REMOVE','stype':'ALL','skey':'-',}
  mKzcvkhxDFbuwdiOATGyYqtpLBEfRP=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.add_dir(mKzcvkhxDFbuwdiOATGyYqtpLBEfRe,sublabel='',img=mKzcvkhxDFbuwdiOATGyYqtpLBEfRP,infoLabels=mKzcvkhxDFbuwdiOATGyYqtpLBEfeH,isFolder=mKzcvkhxDFbuwdiOATGyYqtpLBEfPN,params=mKzcvkhxDFbuwdiOATGyYqtpLBEfRg,isLink=mKzcvkhxDFbuwdiOATGyYqtpLBEfPS)
  xbmcplugin.endOfDirectory(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP._addon_handle,cacheToDisc=mKzcvkhxDFbuwdiOATGyYqtpLBEfPN)
 def dp_Listfile_Delete(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP,args):
  mKzcvkhxDFbuwdiOATGyYqtpLBEfjX=args.get('stype')
  mKzcvkhxDFbuwdiOATGyYqtpLBEfPU =args.get('skey')
  mKzcvkhxDFbuwdiOATGyYqtpLBEfHl=xbmcgui.Dialog()
  if mKzcvkhxDFbuwdiOATGyYqtpLBEfjX=='ALL':
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRl=mKzcvkhxDFbuwdiOATGyYqtpLBEfHl.yesno(__language__(30911).encode('utf8'),__language__(30906).encode('utf8'))
  elif mKzcvkhxDFbuwdiOATGyYqtpLBEfjX=='ONE':
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRl=mKzcvkhxDFbuwdiOATGyYqtpLBEfHl.yesno(__language__(30912).encode('utf8'),__language__(30906).encode('utf8'))
  elif mKzcvkhxDFbuwdiOATGyYqtpLBEfjX in['tvshow','movie']:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRl=mKzcvkhxDFbuwdiOATGyYqtpLBEfHl.yesno(__language__(30913).encode('utf8'),__language__(30906).encode('utf8'))
  if mKzcvkhxDFbuwdiOATGyYqtpLBEfRl==mKzcvkhxDFbuwdiOATGyYqtpLBEfPN:sys.exit()
  mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.Delete_List_File(mKzcvkhxDFbuwdiOATGyYqtpLBEfjX,skey=mKzcvkhxDFbuwdiOATGyYqtpLBEfPU)
  xbmc.executebuiltin("Container.Refresh")
 def Delete_List_File(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP,mKzcvkhxDFbuwdiOATGyYqtpLBEfjX,skey='-'):
  if mKzcvkhxDFbuwdiOATGyYqtpLBEfjX=='ALL':
   try:
    mKzcvkhxDFbuwdiOATGyYqtpLBEfjs=mKzcvkhxDFbuwdiOATGyYqtpLBEfHj
    fp=mKzcvkhxDFbuwdiOATGyYqtpLBEfPn(mKzcvkhxDFbuwdiOATGyYqtpLBEfjs,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    mKzcvkhxDFbuwdiOATGyYqtpLBEfPW
  elif mKzcvkhxDFbuwdiOATGyYqtpLBEfjX=='ONE':
   try:
    mKzcvkhxDFbuwdiOATGyYqtpLBEfjs=mKzcvkhxDFbuwdiOATGyYqtpLBEfHj
    mKzcvkhxDFbuwdiOATGyYqtpLBEfja=mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.Load_List_File('search') 
    fp=mKzcvkhxDFbuwdiOATGyYqtpLBEfPn(mKzcvkhxDFbuwdiOATGyYqtpLBEfjs,'w',-1,'utf-8')
    for mKzcvkhxDFbuwdiOATGyYqtpLBEfjS in mKzcvkhxDFbuwdiOATGyYqtpLBEfja:
     if skey!=mKzcvkhxDFbuwdiOATGyYqtpLBEfjS.strip():
      fp.write(mKzcvkhxDFbuwdiOATGyYqtpLBEfjS)
    fp.close()
   except:
    mKzcvkhxDFbuwdiOATGyYqtpLBEfPW
  elif mKzcvkhxDFbuwdiOATGyYqtpLBEfjX in['tvshow','movie']:
   try:
    mKzcvkhxDFbuwdiOATGyYqtpLBEfjs=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%mKzcvkhxDFbuwdiOATGyYqtpLBEfjX))
    fp=mKzcvkhxDFbuwdiOATGyYqtpLBEfPn(mKzcvkhxDFbuwdiOATGyYqtpLBEfjs,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    mKzcvkhxDFbuwdiOATGyYqtpLBEfPW
 def dp_Watch_List(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP,args):
  mKzcvkhxDFbuwdiOATGyYqtpLBEfjX =args.get('stype')
  if mKzcvkhxDFbuwdiOATGyYqtpLBEfjX in['',mKzcvkhxDFbuwdiOATGyYqtpLBEfPW]:
   for mKzcvkhxDFbuwdiOATGyYqtpLBEfPj in mKzcvkhxDFbuwdiOATGyYqtpLBEfHU:
    mKzcvkhxDFbuwdiOATGyYqtpLBEfRe=mKzcvkhxDFbuwdiOATGyYqtpLBEfPj.get('title')
    mKzcvkhxDFbuwdiOATGyYqtpLBEfRg={'mode':mKzcvkhxDFbuwdiOATGyYqtpLBEfPj.get('mode'),'stype':mKzcvkhxDFbuwdiOATGyYqtpLBEfPj.get('stype'),}
    mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.add_dir(mKzcvkhxDFbuwdiOATGyYqtpLBEfRe,sublabel='',img='',infoLabels=mKzcvkhxDFbuwdiOATGyYqtpLBEfPW,isFolder=mKzcvkhxDFbuwdiOATGyYqtpLBEfPS,params=mKzcvkhxDFbuwdiOATGyYqtpLBEfRg)
   xbmcplugin.endOfDirectory(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP._addon_handle)
  else:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfPg=mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.Load_List_File(mKzcvkhxDFbuwdiOATGyYqtpLBEfjX)
   for mKzcvkhxDFbuwdiOATGyYqtpLBEfPX in mKzcvkhxDFbuwdiOATGyYqtpLBEfPg:
    mKzcvkhxDFbuwdiOATGyYqtpLBEfPV=mKzcvkhxDFbuwdiOATGyYqtpLBEfPM(urllib.parse.parse_qsl(mKzcvkhxDFbuwdiOATGyYqtpLBEfPX))
    mKzcvkhxDFbuwdiOATGyYqtpLBEfUr =mKzcvkhxDFbuwdiOATGyYqtpLBEfPV.get('code').strip()
    mKzcvkhxDFbuwdiOATGyYqtpLBEfRe =mKzcvkhxDFbuwdiOATGyYqtpLBEfPV.get('title').strip()
    mKzcvkhxDFbuwdiOATGyYqtpLBEfej =mKzcvkhxDFbuwdiOATGyYqtpLBEfPV.get('img').strip()
    mKzcvkhxDFbuwdiOATGyYqtpLBEfeP =mKzcvkhxDFbuwdiOATGyYqtpLBEfPV.get('asis').strip()
    try:
     mKzcvkhxDFbuwdiOATGyYqtpLBEfej=mKzcvkhxDFbuwdiOATGyYqtpLBEfej.replace('\'','\"')
     mKzcvkhxDFbuwdiOATGyYqtpLBEfej=json.loads(mKzcvkhxDFbuwdiOATGyYqtpLBEfej)
    except:
     mKzcvkhxDFbuwdiOATGyYqtpLBEfPW
    mKzcvkhxDFbuwdiOATGyYqtpLBEfeH={}
    mKzcvkhxDFbuwdiOATGyYqtpLBEfeH['plot']=mKzcvkhxDFbuwdiOATGyYqtpLBEfRe
    if mKzcvkhxDFbuwdiOATGyYqtpLBEfjX=='movie':
     mKzcvkhxDFbuwdiOATGyYqtpLBEfRg={'mode':'MOVIE','id':mKzcvkhxDFbuwdiOATGyYqtpLBEfUr,'asis':mKzcvkhxDFbuwdiOATGyYqtpLBEfeP,'title':mKzcvkhxDFbuwdiOATGyYqtpLBEfRe,'thumbnail':mKzcvkhxDFbuwdiOATGyYqtpLBEfej,}
     mKzcvkhxDFbuwdiOATGyYqtpLBEfRX=mKzcvkhxDFbuwdiOATGyYqtpLBEfPN
    else:
     mKzcvkhxDFbuwdiOATGyYqtpLBEfRg={'mode':'SEASON_LIST','id':mKzcvkhxDFbuwdiOATGyYqtpLBEfUr,'asis':mKzcvkhxDFbuwdiOATGyYqtpLBEfeP,'title':mKzcvkhxDFbuwdiOATGyYqtpLBEfRe,'thumbnail':json.dumps(mKzcvkhxDFbuwdiOATGyYqtpLBEfej,separators=(',',':')),}
     mKzcvkhxDFbuwdiOATGyYqtpLBEfRX=mKzcvkhxDFbuwdiOATGyYqtpLBEfPS
    mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.add_dir(mKzcvkhxDFbuwdiOATGyYqtpLBEfRe,sublabel='',img=mKzcvkhxDFbuwdiOATGyYqtpLBEfej,infoLabels=mKzcvkhxDFbuwdiOATGyYqtpLBEfeH,isFolder=mKzcvkhxDFbuwdiOATGyYqtpLBEfRX,params=mKzcvkhxDFbuwdiOATGyYqtpLBEfRg)
   mKzcvkhxDFbuwdiOATGyYqtpLBEfeH={'plot':'시청목록을 삭제합니다.'}
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRe='*** 시청목록 삭제 ***'
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRg={'mode':'MYVIEW_REMOVE','stype':mKzcvkhxDFbuwdiOATGyYqtpLBEfjX,'skey':'-',}
   mKzcvkhxDFbuwdiOATGyYqtpLBEfRP=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.add_dir(mKzcvkhxDFbuwdiOATGyYqtpLBEfRe,sublabel='',img=mKzcvkhxDFbuwdiOATGyYqtpLBEfRP,infoLabels=mKzcvkhxDFbuwdiOATGyYqtpLBEfeH,isFolder=mKzcvkhxDFbuwdiOATGyYqtpLBEfPN,params=mKzcvkhxDFbuwdiOATGyYqtpLBEfRg,isLink=mKzcvkhxDFbuwdiOATGyYqtpLBEfPS)
   if mKzcvkhxDFbuwdiOATGyYqtpLBEfjX=='movie':xbmcplugin.setContent(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP._addon_handle,'movies')
   else:xbmcplugin.setContent(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP._addon_handle,cacheToDisc=mKzcvkhxDFbuwdiOATGyYqtpLBEfPN)
 def dp_Set_Bookmark(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP,args):
  mKzcvkhxDFbuwdiOATGyYqtpLBEfPo=urllib.parse.unquote(args.get('bm_param'))
  mKzcvkhxDFbuwdiOATGyYqtpLBEfPo=json.loads(mKzcvkhxDFbuwdiOATGyYqtpLBEfPo)
  mKzcvkhxDFbuwdiOATGyYqtpLBEfPl =mKzcvkhxDFbuwdiOATGyYqtpLBEfPo.get('videoid')
  mKzcvkhxDFbuwdiOATGyYqtpLBEfPI =mKzcvkhxDFbuwdiOATGyYqtpLBEfPo.get('vidtype')
  mKzcvkhxDFbuwdiOATGyYqtpLBEfPs =mKzcvkhxDFbuwdiOATGyYqtpLBEfPo.get('vtitle')
  mKzcvkhxDFbuwdiOATGyYqtpLBEfHl=xbmcgui.Dialog()
  mKzcvkhxDFbuwdiOATGyYqtpLBEfRl=mKzcvkhxDFbuwdiOATGyYqtpLBEfHl.yesno(__language__(30914).encode('utf8'),mKzcvkhxDFbuwdiOATGyYqtpLBEfPs+' \n\n'+__language__(30915))
  if mKzcvkhxDFbuwdiOATGyYqtpLBEfRl==mKzcvkhxDFbuwdiOATGyYqtpLBEfPN:return
  mKzcvkhxDFbuwdiOATGyYqtpLBEfPQ=mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CoupangObj.GetBookmarkInfo(mKzcvkhxDFbuwdiOATGyYqtpLBEfPl,mKzcvkhxDFbuwdiOATGyYqtpLBEfPI)
  mKzcvkhxDFbuwdiOATGyYqtpLBEfPr=json.dumps(mKzcvkhxDFbuwdiOATGyYqtpLBEfPQ)
  mKzcvkhxDFbuwdiOATGyYqtpLBEfPr=urllib.parse.quote(mKzcvkhxDFbuwdiOATGyYqtpLBEfPr)
  mKzcvkhxDFbuwdiOATGyYqtpLBEfeM ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(mKzcvkhxDFbuwdiOATGyYqtpLBEfPr)
  xbmc.executebuiltin(mKzcvkhxDFbuwdiOATGyYqtpLBEfeM)
 def coupang_main(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP):
  mKzcvkhxDFbuwdiOATGyYqtpLBEfeN=mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.main_params.get('mode',mKzcvkhxDFbuwdiOATGyYqtpLBEfPW)
  if mKzcvkhxDFbuwdiOATGyYqtpLBEfeN=='LOGOUT':
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.CP_logout()
   return
  mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.option_check()
  if mKzcvkhxDFbuwdiOATGyYqtpLBEfeN is mKzcvkhxDFbuwdiOATGyYqtpLBEfPW:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.dp_Main_List(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.main_params)
  elif mKzcvkhxDFbuwdiOATGyYqtpLBEfeN=='CATEGORY_GROUPLIST':
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.dp_Category_GroupList(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.main_params)
  elif mKzcvkhxDFbuwdiOATGyYqtpLBEfeN=='THEME_GROUPLIST':
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.dp_Theme_GroupList(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.main_params)
  elif mKzcvkhxDFbuwdiOATGyYqtpLBEfeN=='EVENT_GROUPLIST':
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.dp_Event_GroupList(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.main_params)
  elif mKzcvkhxDFbuwdiOATGyYqtpLBEfeN=='EVENT_GAMELIST':
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.dp_Event_GameList(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.main_params)
  elif mKzcvkhxDFbuwdiOATGyYqtpLBEfeN=='EVENT_LIST':
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.dp_Event_List(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.main_params)
  elif mKzcvkhxDFbuwdiOATGyYqtpLBEfeN=='CATEGORY_LIST':
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.dp_Category_List(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.main_params)
  elif mKzcvkhxDFbuwdiOATGyYqtpLBEfeN=='SEASON_LIST':
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.dp_Season_List(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.main_params)
  elif mKzcvkhxDFbuwdiOATGyYqtpLBEfeN=='EPISODE_LIST':
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.dp_Episode_List(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.main_params)
  elif mKzcvkhxDFbuwdiOATGyYqtpLBEfeN=='TEST':
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.dp_Test(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.main_params)
  elif mKzcvkhxDFbuwdiOATGyYqtpLBEfeN in['MOVIE','VOD','HIGHLIGHT','LIVE']:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.play_VIDEO(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.main_params)
  elif mKzcvkhxDFbuwdiOATGyYqtpLBEfeN=='WATCH':
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.dp_Watch_List(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.main_params)
  elif mKzcvkhxDFbuwdiOATGyYqtpLBEfeN=='LOCAL_SEARCH':
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.dp_Search_List(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.main_params)
  elif mKzcvkhxDFbuwdiOATGyYqtpLBEfeN=='SEARCH_HISTORY':
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.dp_Search_History(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.main_params)
  elif mKzcvkhxDFbuwdiOATGyYqtpLBEfeN in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.dp_Listfile_Delete(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.main_params)
  elif mKzcvkhxDFbuwdiOATGyYqtpLBEfeN in['TOTAL_SEARCH','TOTAL_HISTORY']:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.dp_Global_Search(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.main_params)
  elif mKzcvkhxDFbuwdiOATGyYqtpLBEfeN=='MENU_BOOKMARK':
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.dp_Bookmark_Menu(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.main_params)
  elif mKzcvkhxDFbuwdiOATGyYqtpLBEfeN=='SET_BOOKMARK':
   mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.dp_Set_Bookmark(mKzcvkhxDFbuwdiOATGyYqtpLBEfHP.main_params)
  else:
   mKzcvkhxDFbuwdiOATGyYqtpLBEfPW
# Created by pyminifier (https://github.com/liftoff/pyminifier)
