__author__="NightRain"
wLnkoCBTNtsSrPzGFpxaWEJqODyIvc=object
wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ=None
wLnkoCBTNtsSrPzGFpxaWEJqODyIvh=False
wLnkoCBTNtsSrPzGFpxaWEJqODyIvm=print
wLnkoCBTNtsSrPzGFpxaWEJqODyIvl=str
wLnkoCBTNtsSrPzGFpxaWEJqODyIvg=open
wLnkoCBTNtsSrPzGFpxaWEJqODyIvj=int
wLnkoCBTNtsSrPzGFpxaWEJqODyIvA=Exception
wLnkoCBTNtsSrPzGFpxaWEJqODyIvi=id
wLnkoCBTNtsSrPzGFpxaWEJqODyIvb=True
wLnkoCBTNtsSrPzGFpxaWEJqODyIvR=range
wLnkoCBTNtsSrPzGFpxaWEJqODyIvu=len
import urllib
import re
import json
import requests
import datetime
import time
import random
import base64
class wLnkoCBTNtsSrPzGFpxaWEJqODyIde(wLnkoCBTNtsSrPzGFpxaWEJqODyIvc):
 def __init__(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK):
  wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36'
  wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.MODEL ='Chrome_92' 
  wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.DEFAULT_HEADER ={'user-agent':wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.USER_AGENT}
  wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.API_DOMAIN ='https://www.coupangplay.com'
  wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.API_VIEWURL ='https://discover.coupangstreaming.com'
  wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.PAGE_LIMIT =40
  wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.SEARCH_LIMIT =20
  wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP={}
  wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.Init_CP()
  wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP_DEVICE_FILENAME=''
  wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP_COOKIE_FILENAME=''
 def callRequestCookies(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK,jobtype,wLnkoCBTNtsSrPzGFpxaWEJqODyIev,payload=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,params=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,headers=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,cookies=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,redirects=wLnkoCBTNtsSrPzGFpxaWEJqODyIvh):
  wLnkoCBTNtsSrPzGFpxaWEJqODyIdv=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.DEFAULT_HEADER
  if headers:wLnkoCBTNtsSrPzGFpxaWEJqODyIdv.update(headers)
  if jobtype=='Get':
   wLnkoCBTNtsSrPzGFpxaWEJqODyIdY=requests.get(wLnkoCBTNtsSrPzGFpxaWEJqODyIev,params=params,headers=wLnkoCBTNtsSrPzGFpxaWEJqODyIdv,cookies=cookies,allow_redirects=redirects)
  else:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIdY=requests.post(wLnkoCBTNtsSrPzGFpxaWEJqODyIev,data=payload,params=params,headers=wLnkoCBTNtsSrPzGFpxaWEJqODyIdv,cookies=cookies,allow_redirects=redirects)
  wLnkoCBTNtsSrPzGFpxaWEJqODyIvm(wLnkoCBTNtsSrPzGFpxaWEJqODyIvl(wLnkoCBTNtsSrPzGFpxaWEJqODyIdY.status_code)+' - '+wLnkoCBTNtsSrPzGFpxaWEJqODyIvl(wLnkoCBTNtsSrPzGFpxaWEJqODyIdY.url))
  return wLnkoCBTNtsSrPzGFpxaWEJqODyIdY
 def callRequestCookies_test(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK,jobtype,wLnkoCBTNtsSrPzGFpxaWEJqODyIev,payload=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,params=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,headers=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,cookies=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,redirects=wLnkoCBTNtsSrPzGFpxaWEJqODyIvh):
  wLnkoCBTNtsSrPzGFpxaWEJqODyIdv=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.DEFAULT_HEADER
  if headers:wLnkoCBTNtsSrPzGFpxaWEJqODyIdv.update(headers)
  wLnkoCBTNtsSrPzGFpxaWEJqODyIdY=requests.Request('POST',wLnkoCBTNtsSrPzGFpxaWEJqODyIev,headers=headers,data=payload,params=params,cookies=cookies)
  wLnkoCBTNtsSrPzGFpxaWEJqODyIdc=wLnkoCBTNtsSrPzGFpxaWEJqODyIdY.prepare()
  wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.pretty_print_POST(wLnkoCBTNtsSrPzGFpxaWEJqODyIdc)
  return wLnkoCBTNtsSrPzGFpxaWEJqODyIdY
 def pretty_print_POST(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK,req):
  wLnkoCBTNtsSrPzGFpxaWEJqODyIvm('{}\n{}\r\n{}\r\n\r\n{}'.format('-----------START-----------',req.method+' '+req.url,'\r\n'.join('{}: {}'.format(k,v)for k,v in req.headers.items()),req.body,))
 def dic_To_jsonfile(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK,filename,wLnkoCBTNtsSrPzGFpxaWEJqODyIdQ):
  if filename=='':return
  fp=wLnkoCBTNtsSrPzGFpxaWEJqODyIvg(filename,'w',-1,'utf-8')
  json.dump(wLnkoCBTNtsSrPzGFpxaWEJqODyIdQ,fp,indent=4,ensure_ascii=wLnkoCBTNtsSrPzGFpxaWEJqODyIvh)
  fp.close()
 def jsonfile_To_dic(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK,filename):
  if filename=='':return wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ
  try:
   fp=wLnkoCBTNtsSrPzGFpxaWEJqODyIvg(filename,'r',-1,'utf-8')
   wLnkoCBTNtsSrPzGFpxaWEJqODyIdm=json.load(fp)
   fp.close()
  except:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIdm={}
  return wLnkoCBTNtsSrPzGFpxaWEJqODyIdm
 def convert_TimeStr(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK,wLnkoCBTNtsSrPzGFpxaWEJqODyIdl):
  try:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIdl =wLnkoCBTNtsSrPzGFpxaWEJqODyIdl[0:16]
   wLnkoCBTNtsSrPzGFpxaWEJqODyIdg=datetime.datetime.strptime(wLnkoCBTNtsSrPzGFpxaWEJqODyIdl,'%Y-%m-%dT%H:%M')+datetime.timedelta(hours=9)
   return wLnkoCBTNtsSrPzGFpxaWEJqODyIdg.strftime('%Y-%m-%d %H:%M')
  except:
   return wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ
 def Get_Now_Datetime(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetNoCache(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK):
  wLnkoCBTNtsSrPzGFpxaWEJqODyIdA =wLnkoCBTNtsSrPzGFpxaWEJqODyIvj(time.time()*1000)
  return wLnkoCBTNtsSrPzGFpxaWEJqODyIdA
 def generatePcId(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK):
  t=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.GetNoCache()
  r=random.random()
  wLnkoCBTNtsSrPzGFpxaWEJqODyIdi=wLnkoCBTNtsSrPzGFpxaWEJqODyIvl(t)+wLnkoCBTNtsSrPzGFpxaWEJqODyIvl(r)[2:12]
  return wLnkoCBTNtsSrPzGFpxaWEJqODyIdi
 def generatePvId(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK,genType='1'):
  import hashlib
  m=hashlib.md5()
  wLnkoCBTNtsSrPzGFpxaWEJqODyIdb=wLnkoCBTNtsSrPzGFpxaWEJqODyIvl(random.random())
  m.update(wLnkoCBTNtsSrPzGFpxaWEJqODyIdb.encode('utf-8'))
  wLnkoCBTNtsSrPzGFpxaWEJqODyIdR=wLnkoCBTNtsSrPzGFpxaWEJqODyIvl(m.hexdigest())
  if genType=='1':
   return '%s-%s-%s-%s-%s'%(wLnkoCBTNtsSrPzGFpxaWEJqODyIdR[:8],wLnkoCBTNtsSrPzGFpxaWEJqODyIdR[8:12],wLnkoCBTNtsSrPzGFpxaWEJqODyIdR[12:16],wLnkoCBTNtsSrPzGFpxaWEJqODyIdR[16:20],wLnkoCBTNtsSrPzGFpxaWEJqODyIdR[20:])
  else:
   return wLnkoCBTNtsSrPzGFpxaWEJqODyIdR
 def Get_DeviceID(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK):
  wLnkoCBTNtsSrPzGFpxaWEJqODyIdu=''
  try: 
   fp=wLnkoCBTNtsSrPzGFpxaWEJqODyIvg(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP_DEVICE_FILENAME,'r',-1,'utf-8')
   wLnkoCBTNtsSrPzGFpxaWEJqODyIdX= json.load(fp)
   fp.close()
   wLnkoCBTNtsSrPzGFpxaWEJqODyIdu=wLnkoCBTNtsSrPzGFpxaWEJqODyIdX.get('device_id')
  except wLnkoCBTNtsSrPzGFpxaWEJqODyIvA as exception:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ
  if wLnkoCBTNtsSrPzGFpxaWEJqODyIdu=='':
   wLnkoCBTNtsSrPzGFpxaWEJqODyIdu=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.generatePvId(genType='1')
   try: 
    fp=wLnkoCBTNtsSrPzGFpxaWEJqODyIvg(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP_DEVICE_FILENAME,'w',-1,'utf-8')
    json.dump({'device_id':wLnkoCBTNtsSrPzGFpxaWEJqODyIdu},fp,indent=4,ensure_ascii=wLnkoCBTNtsSrPzGFpxaWEJqODyIvh)
    fp.close()
   except wLnkoCBTNtsSrPzGFpxaWEJqODyIvA as exception:
    return ''
  return wLnkoCBTNtsSrPzGFpxaWEJqODyIdu
 def Make_authHeader(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK):
  tr=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.generatePvId(genType=2)
  ti=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.GetNoCache()
  wLnkoCBTNtsSrPzGFpxaWEJqODyIvi=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.generatePvId(genType=2)[:16]
  wLnkoCBTNtsSrPzGFpxaWEJqODyIdH='00-%s-%s-01'%(tr,wLnkoCBTNtsSrPzGFpxaWEJqODyIvi,)
  wLnkoCBTNtsSrPzGFpxaWEJqODyIdf ='%s@nr=0-1-%s-%s-%s----%s'%(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['NREUM']['tk'],wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['NREUM']['ac'],wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['NREUM']['ap'],wLnkoCBTNtsSrPzGFpxaWEJqODyIvi,ti,)
  wLnkoCBTNtsSrPzGFpxaWEJqODyIdM ='{"v":[0,1],"d":{"ty":"Browser","ac":"%s","ap":"%s","id":"%s","tr":"%s","ti":%s,"tk":"%s"}}'%(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['NREUM']['ac'],wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['NREUM']['ap'],wLnkoCBTNtsSrPzGFpxaWEJqODyIvi,tr,ti,wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['NREUM']['tk'],) 
  return wLnkoCBTNtsSrPzGFpxaWEJqODyIdH,wLnkoCBTNtsSrPzGFpxaWEJqODyIdf,base64.standard_b64encode(wLnkoCBTNtsSrPzGFpxaWEJqODyIdM.encode()).decode('utf-8')
 def Init_CP(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK):
  wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP={}
  wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['ACCOUNT']={'cpid':'','cppw':'','cppf':'0'}
  wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']={}
 def Save_session_acount(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK,wLnkoCBTNtsSrPzGFpxaWEJqODyIdU,wLnkoCBTNtsSrPzGFpxaWEJqODyIdV,wLnkoCBTNtsSrPzGFpxaWEJqODyIed):
  wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['ACCOUNT']['cpid']=base64.standard_b64encode(wLnkoCBTNtsSrPzGFpxaWEJqODyIdU.encode()).decode('utf-8')
  wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['ACCOUNT']['cppw']=base64.standard_b64encode(wLnkoCBTNtsSrPzGFpxaWEJqODyIdV.encode()).decode('utf-8')
  wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['ACCOUNT']['cppf']=wLnkoCBTNtsSrPzGFpxaWEJqODyIvl(wLnkoCBTNtsSrPzGFpxaWEJqODyIed)
 def Load_session_acount(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK):
  wLnkoCBTNtsSrPzGFpxaWEJqODyIdU=base64.standard_b64decode(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['ACCOUNT']['cpid']).decode('utf-8')
  wLnkoCBTNtsSrPzGFpxaWEJqODyIdV=base64.standard_b64decode(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['ACCOUNT']['cppw']).decode('utf-8')
  wLnkoCBTNtsSrPzGFpxaWEJqODyIed=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['ACCOUNT']['cppf']
  return wLnkoCBTNtsSrPzGFpxaWEJqODyIdU,wLnkoCBTNtsSrPzGFpxaWEJqODyIdV,wLnkoCBTNtsSrPzGFpxaWEJqODyIed
 def make_CP_DefaultCookies(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK):
  wLnkoCBTNtsSrPzGFpxaWEJqODyIeK={}
  if 'NEXT_LOCALE' in wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']:wLnkoCBTNtsSrPzGFpxaWEJqODyIeK['NEXT_LOCALE']=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['NEXT_LOCALE']
  if 'ak_bmsc' in wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']:wLnkoCBTNtsSrPzGFpxaWEJqODyIeK['ak_bmsc'] =wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['ak_bmsc']
  if 'bm_mi' in wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']:wLnkoCBTNtsSrPzGFpxaWEJqODyIeK['bm_mi'] =wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['bm_mi']
  if 'bm_sv' in wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']:wLnkoCBTNtsSrPzGFpxaWEJqODyIeK['bm_sv'] =wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['bm_sv']
  if 'PCID' in wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']:wLnkoCBTNtsSrPzGFpxaWEJqODyIeK['PCID'] =wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['PCID']
  if 'member_srl' in wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']:wLnkoCBTNtsSrPzGFpxaWEJqODyIeK['member_srl']=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['member_srl']
  if 'token' in wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']:wLnkoCBTNtsSrPzGFpxaWEJqODyIeK['token'] =wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['token']
  return wLnkoCBTNtsSrPzGFpxaWEJqODyIeK
 def Get_CP_Login(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK,userid,userpw,wLnkoCBTNtsSrPzGFpxaWEJqODyIei):
  try:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIev=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.API_DOMAIN
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeY=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.callRequestCookies('Get',wLnkoCBTNtsSrPzGFpxaWEJqODyIev,payload=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,params=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,headers=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,cookies=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,redirects=wLnkoCBTNtsSrPzGFpxaWEJqODyIvh)
   if wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.status_code not in[301,302]:return wLnkoCBTNtsSrPzGFpxaWEJqODyIvh
   for wLnkoCBTNtsSrPzGFpxaWEJqODyIec in wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.cookies:
    if wLnkoCBTNtsSrPzGFpxaWEJqODyIec.name=='NEXT_LOCALE':
     wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['NEXT_LOCALE']=wLnkoCBTNtsSrPzGFpxaWEJqODyIec.value
    elif wLnkoCBTNtsSrPzGFpxaWEJqODyIec.name=='ak_bmsc':
     wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['ak_bmsc']=wLnkoCBTNtsSrPzGFpxaWEJqODyIec.value
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeK={'NEXT_LOCALE':wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['NEXT_LOCALE'],'ak_bmsc':wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['ak_bmsc'],}
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeY=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.callRequestCookies('Get',wLnkoCBTNtsSrPzGFpxaWEJqODyIev,payload=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,params=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,headers=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,cookies=wLnkoCBTNtsSrPzGFpxaWEJqODyIeK,redirects=wLnkoCBTNtsSrPzGFpxaWEJqODyIvh)
   if wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.status_code not in[200]:return wLnkoCBTNtsSrPzGFpxaWEJqODyIvh
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeQ=re.findall('NREUM.loader_config=\{[\w\d\":,-]+\}',wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.text)[0].split('=')[1]
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeQ=wLnkoCBTNtsSrPzGFpxaWEJqODyIeQ.replace('{','{"').replace(':','":').replace(',',',"')
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeQ=json.loads(wLnkoCBTNtsSrPzGFpxaWEJqODyIeQ)
   wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['NREUM']={'ac':wLnkoCBTNtsSrPzGFpxaWEJqODyIeQ['accountID'],'tk':wLnkoCBTNtsSrPzGFpxaWEJqODyIeQ['trustKey'],'ap':wLnkoCBTNtsSrPzGFpxaWEJqODyIeQ['agentID'],'lk':wLnkoCBTNtsSrPzGFpxaWEJqODyIeQ['licenseKey'],}
   for wLnkoCBTNtsSrPzGFpxaWEJqODyIec in wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.cookies:
    if wLnkoCBTNtsSrPzGFpxaWEJqODyIec.name=='bm_mi':
     wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['bm_mi']=wLnkoCBTNtsSrPzGFpxaWEJqODyIec.value
    elif wLnkoCBTNtsSrPzGFpxaWEJqODyIec.name=='bm_sv':
     wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['bm_sv'] =wLnkoCBTNtsSrPzGFpxaWEJqODyIec.value
     wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['bm_sv_ex']=wLnkoCBTNtsSrPzGFpxaWEJqODyIec.expires 
  except wLnkoCBTNtsSrPzGFpxaWEJqODyIvA as exception:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIvm(exception)
   return wLnkoCBTNtsSrPzGFpxaWEJqODyIvh
  try:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIev=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.API_DOMAIN+'/api/auth'
   wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['PCID']=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.generatePcId()
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeh=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.Get_DeviceID()
   wLnkoCBTNtsSrPzGFpxaWEJqODyIem =wLnkoCBTNtsSrPzGFpxaWEJqODyIeh.split('-')[0]
   wLnkoCBTNtsSrPzGFpxaWEJqODyIdH,wLnkoCBTNtsSrPzGFpxaWEJqODyIdf,wLnkoCBTNtsSrPzGFpxaWEJqODyIdM=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.Make_authHeader()
   wLnkoCBTNtsSrPzGFpxaWEJqODyIel={'traceparent':wLnkoCBTNtsSrPzGFpxaWEJqODyIdH,'tracestate':wLnkoCBTNtsSrPzGFpxaWEJqODyIdf,'newrelic':wLnkoCBTNtsSrPzGFpxaWEJqODyIdM,'content-type':'application/json',}
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeg={'device':{'deviceId':'web-'+wLnkoCBTNtsSrPzGFpxaWEJqODyIeh,'model':wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.MODEL,'name':'Chrome Desktop '+wLnkoCBTNtsSrPzGFpxaWEJqODyIem,'os':'Windows','osVersion':'10','type':'webclient',},'email':userid,'password':userpw,}
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeg=json.dumps(wLnkoCBTNtsSrPzGFpxaWEJqODyIeg,separators=(',',':'))
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeK={'NEXT_LOCALE':wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['NEXT_LOCALE'],'ak_bmsc':wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['ak_bmsc'],'bm_mi':wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['bm_mi'],'bm_sv':wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['bm_sv'],'PCID':wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['PCID'],}
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeY=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.callRequestCookies('Post',wLnkoCBTNtsSrPzGFpxaWEJqODyIev,payload=wLnkoCBTNtsSrPzGFpxaWEJqODyIeg,params=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,headers=wLnkoCBTNtsSrPzGFpxaWEJqODyIel,cookies=wLnkoCBTNtsSrPzGFpxaWEJqODyIeK,redirects=wLnkoCBTNtsSrPzGFpxaWEJqODyIvh)
   if wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.status_code not in[200]:
    wLnkoCBTNtsSrPzGFpxaWEJqODyIej=json.loads(wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.text)
    if 'error' in wLnkoCBTNtsSrPzGFpxaWEJqODyIej:
     wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['error']=wLnkoCBTNtsSrPzGFpxaWEJqODyIej.get('error').get('detail')
    return wLnkoCBTNtsSrPzGFpxaWEJqODyIvh
   for wLnkoCBTNtsSrPzGFpxaWEJqODyIec in wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.cookies:
    if wLnkoCBTNtsSrPzGFpxaWEJqODyIec.name=='token':
     wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['token']=wLnkoCBTNtsSrPzGFpxaWEJqODyIec.value
    elif wLnkoCBTNtsSrPzGFpxaWEJqODyIec.name=='member_srl':
     wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['member_srl']=wLnkoCBTNtsSrPzGFpxaWEJqODyIec.value
    elif wLnkoCBTNtsSrPzGFpxaWEJqODyIec.name=='bm_sv':
     wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['bm_sv'] =wLnkoCBTNtsSrPzGFpxaWEJqODyIec.value
     wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['bm_sv_ex']=wLnkoCBTNtsSrPzGFpxaWEJqODyIec.expires 
  except wLnkoCBTNtsSrPzGFpxaWEJqODyIvA as exception:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIvm(exception)
   return wLnkoCBTNtsSrPzGFpxaWEJqODyIvh
  wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.Save_session_acount(userid,userpw,wLnkoCBTNtsSrPzGFpxaWEJqODyIei)
  return wLnkoCBTNtsSrPzGFpxaWEJqODyIvb
 def Get_CP_profile(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK,wLnkoCBTNtsSrPzGFpxaWEJqODyIei,limit_days=1,re_check=wLnkoCBTNtsSrPzGFpxaWEJqODyIvh):
  if re_check==wLnkoCBTNtsSrPzGFpxaWEJqODyIvb:
   if wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['bm_sv_ex']>wLnkoCBTNtsSrPzGFpxaWEJqODyIvj(time.time()):
    wLnkoCBTNtsSrPzGFpxaWEJqODyIvm('bm_sv_ex ok')
    return wLnkoCBTNtsSrPzGFpxaWEJqODyIvb
  try:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIev=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.API_DOMAIN+'/api/profiles'
   wLnkoCBTNtsSrPzGFpxaWEJqODyIdH,wLnkoCBTNtsSrPzGFpxaWEJqODyIdf,wLnkoCBTNtsSrPzGFpxaWEJqODyIdM=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.Make_authHeader()
   wLnkoCBTNtsSrPzGFpxaWEJqODyIel={'traceparent':wLnkoCBTNtsSrPzGFpxaWEJqODyIdH,'tracestate':wLnkoCBTNtsSrPzGFpxaWEJqODyIdf,'newrelic':wLnkoCBTNtsSrPzGFpxaWEJqODyIdM,}
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeK=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.make_CP_DefaultCookies()
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeY=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.callRequestCookies('Get',wLnkoCBTNtsSrPzGFpxaWEJqODyIev,payload=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,params=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,headers=wLnkoCBTNtsSrPzGFpxaWEJqODyIel,cookies=wLnkoCBTNtsSrPzGFpxaWEJqODyIeK,redirects=wLnkoCBTNtsSrPzGFpxaWEJqODyIvh)
   if wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.status_code not in[200]:return wLnkoCBTNtsSrPzGFpxaWEJqODyIvh
   wLnkoCBTNtsSrPzGFpxaWEJqODyIej=json.loads(wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.text)
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeA=0 
   for wLnkoCBTNtsSrPzGFpxaWEJqODyIec in wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.cookies:
    wLnkoCBTNtsSrPzGFpxaWEJqODyIvm(wLnkoCBTNtsSrPzGFpxaWEJqODyIec.name)
    if wLnkoCBTNtsSrPzGFpxaWEJqODyIec.name=='bm_sv':
     wLnkoCBTNtsSrPzGFpxaWEJqODyIeA=1
     wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['bm_sv'] =wLnkoCBTNtsSrPzGFpxaWEJqODyIec.value
     wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['bm_sv_ex']=wLnkoCBTNtsSrPzGFpxaWEJqODyIec.expires 
   if wLnkoCBTNtsSrPzGFpxaWEJqODyIeA==0:
    wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['bm_sv_ex']=wLnkoCBTNtsSrPzGFpxaWEJqODyIvj(time.time())+60*60*2 
   wLnkoCBTNtsSrPzGFpxaWEJqODyIei=wLnkoCBTNtsSrPzGFpxaWEJqODyIej.get('data')[wLnkoCBTNtsSrPzGFpxaWEJqODyIvj(wLnkoCBTNtsSrPzGFpxaWEJqODyIei)]
   wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['accountId']=wLnkoCBTNtsSrPzGFpxaWEJqODyIei.get('accountId')
   wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['profileId']=wLnkoCBTNtsSrPzGFpxaWEJqODyIei.get('profileId')
  except wLnkoCBTNtsSrPzGFpxaWEJqODyIvA as exception:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIvm(exception)
   return wLnkoCBTNtsSrPzGFpxaWEJqODyIvh
  if re_check==wLnkoCBTNtsSrPzGFpxaWEJqODyIvh:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeb =wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.Get_Now_Datetime()
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeR=wLnkoCBTNtsSrPzGFpxaWEJqODyIeb+datetime.timedelta(days=limit_days)
   wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['limitdate']=wLnkoCBTNtsSrPzGFpxaWEJqODyIeR.strftime('%Y-%m-%d')
  else:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIvm('re check')
  wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.dic_To_jsonfile(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP_COOKIE_FILENAME,wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP)
  return wLnkoCBTNtsSrPzGFpxaWEJqODyIvb
 def Get_Category_GroupList(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK,vType):
  wLnkoCBTNtsSrPzGFpxaWEJqODyIeu=[] 
  try:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIev=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.API_VIEWURL+'/v2/discover/feed' 
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeX={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false',}
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeY=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.callRequestCookies('Get',wLnkoCBTNtsSrPzGFpxaWEJqODyIev,payload=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,params=wLnkoCBTNtsSrPzGFpxaWEJqODyIeX,headers=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,cookies=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,redirects=wLnkoCBTNtsSrPzGFpxaWEJqODyIvb)
   if wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.status_code not in[200]:return[]
   wLnkoCBTNtsSrPzGFpxaWEJqODyIej=json.loads(wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.text)
   if vType in['TVSHOWS','MOVIES']:
    wLnkoCBTNtsSrPzGFpxaWEJqODyIeH='Explores' 
   elif vType in['EDUCATION']:
    wLnkoCBTNtsSrPzGFpxaWEJqODyIeH='Collection-Rails-Curation'
   elif vType in['ALL']:
    wLnkoCBTNtsSrPzGFpxaWEJqODyIeH='Explores-Categories'
   for wLnkoCBTNtsSrPzGFpxaWEJqODyIef in wLnkoCBTNtsSrPzGFpxaWEJqODyIej.get('data'):
    if wLnkoCBTNtsSrPzGFpxaWEJqODyIef.get('type')==wLnkoCBTNtsSrPzGFpxaWEJqODyIeH:
     for wLnkoCBTNtsSrPzGFpxaWEJqODyIeM in wLnkoCBTNtsSrPzGFpxaWEJqODyIef.get('data'):
      if vType in['TVSHOWS','MOVIES']:
       wLnkoCBTNtsSrPzGFpxaWEJqODyIeU=wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('collectionId')
      elif vType in['EDUCATION','ALL']:
       wLnkoCBTNtsSrPzGFpxaWEJqODyIeU=wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('id')
      wLnkoCBTNtsSrPzGFpxaWEJqODyIeV={'collectionId':wLnkoCBTNtsSrPzGFpxaWEJqODyIeU,'title':wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('name'),'category':wLnkoCBTNtsSrPzGFpxaWEJqODyIef.get('category'),'pre_title':'',}
      wLnkoCBTNtsSrPzGFpxaWEJqODyIeu.append(wLnkoCBTNtsSrPzGFpxaWEJqODyIeV)
     break
  except wLnkoCBTNtsSrPzGFpxaWEJqODyIvA as exception:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIvm(exception)
   return[]
  return wLnkoCBTNtsSrPzGFpxaWEJqODyIeu
 def Get_Category_List(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK,vType,wLnkoCBTNtsSrPzGFpxaWEJqODyIeU,page_int):
  wLnkoCBTNtsSrPzGFpxaWEJqODyIeu=[] 
  wLnkoCBTNtsSrPzGFpxaWEJqODyIKd=wLnkoCBTNtsSrPzGFpxaWEJqODyIvh
  try:
   if vType=='ALL':
    wLnkoCBTNtsSrPzGFpxaWEJqODyIel={'x-membersrl':wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['member_srl'],'x-pcid':wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['PCID'],'x-profileid':wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['profileId'],}
    wLnkoCBTNtsSrPzGFpxaWEJqODyIeX={'platform':'WEBCLIENT','page':wLnkoCBTNtsSrPzGFpxaWEJqODyIvl(page_int),'perPage':wLnkoCBTNtsSrPzGFpxaWEJqODyIvl(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.PAGE_LIMIT),'locale':'ko','sort':'',}
    wLnkoCBTNtsSrPzGFpxaWEJqODyIev=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.API_VIEWURL+'/v1/discover/categories/'+wLnkoCBTNtsSrPzGFpxaWEJqODyIeU+'/titles'
    wLnkoCBTNtsSrPzGFpxaWEJqODyIeY=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.callRequestCookies('Get',wLnkoCBTNtsSrPzGFpxaWEJqODyIev,payload=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,params=wLnkoCBTNtsSrPzGFpxaWEJqODyIeX,headers=wLnkoCBTNtsSrPzGFpxaWEJqODyIel,cookies=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,redirects=wLnkoCBTNtsSrPzGFpxaWEJqODyIvb)
   else: 
    wLnkoCBTNtsSrPzGFpxaWEJqODyIeX={'platform':'WEBCLIENT','page':wLnkoCBTNtsSrPzGFpxaWEJqODyIvl(page_int),'perPage':wLnkoCBTNtsSrPzGFpxaWEJqODyIvl(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.PAGE_LIMIT),}
    wLnkoCBTNtsSrPzGFpxaWEJqODyIev=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.API_VIEWURL+'/v1/discover/collections/'+wLnkoCBTNtsSrPzGFpxaWEJqODyIeU+'/titles'
    wLnkoCBTNtsSrPzGFpxaWEJqODyIeY=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.callRequestCookies('Get',wLnkoCBTNtsSrPzGFpxaWEJqODyIev,payload=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,params=wLnkoCBTNtsSrPzGFpxaWEJqODyIeX,headers=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,cookies=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,redirects=wLnkoCBTNtsSrPzGFpxaWEJqODyIvb)
   if wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.status_code not in[200]:return[],wLnkoCBTNtsSrPzGFpxaWEJqODyIvh
   wLnkoCBTNtsSrPzGFpxaWEJqODyIej=json.loads(wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.text)
   if vType=='ALL':
    wLnkoCBTNtsSrPzGFpxaWEJqODyIKe=wLnkoCBTNtsSrPzGFpxaWEJqODyIej.get('data').get('data')
   else:
    wLnkoCBTNtsSrPzGFpxaWEJqODyIKe=wLnkoCBTNtsSrPzGFpxaWEJqODyIej.get('data')
   for wLnkoCBTNtsSrPzGFpxaWEJqODyIeM in wLnkoCBTNtsSrPzGFpxaWEJqODyIKe:
    wLnkoCBTNtsSrPzGFpxaWEJqODyIKv=wLnkoCBTNtsSrPzGFpxaWEJqODyIKm=wLnkoCBTNtsSrPzGFpxaWEJqODyIvd=wLnkoCBTNtsSrPzGFpxaWEJqODyIKV=''
    if 'poster' in wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('images'):wLnkoCBTNtsSrPzGFpxaWEJqODyIKv =wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('images').get('poster').get('url')
    if 'story-art' in wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('images'):wLnkoCBTNtsSrPzGFpxaWEJqODyIKm =wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('images').get('story-art').get('url')
    if 'title-treatment' in wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('images'):wLnkoCBTNtsSrPzGFpxaWEJqODyIvd=wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('images').get('title-treatment').get('url')
    if 'story-art' in wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('images'):wLnkoCBTNtsSrPzGFpxaWEJqODyIKV =wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('images').get('story-art').get('url')
    wLnkoCBTNtsSrPzGFpxaWEJqODyIKY=''
    if wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('badge')not in[{},wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ]:
     for i in wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('badge').get('text'):
      wLnkoCBTNtsSrPzGFpxaWEJqODyIKY+=i.get('text')
    wLnkoCBTNtsSrPzGFpxaWEJqODyIKc=''
    if wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('seasonList')!=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ:
     wLnkoCBTNtsSrPzGFpxaWEJqODyIKc=','.join(wLnkoCBTNtsSrPzGFpxaWEJqODyIvl(e)for e in wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('seasonList'))
    wLnkoCBTNtsSrPzGFpxaWEJqODyIKQ =[]
    for wLnkoCBTNtsSrPzGFpxaWEJqODyIKh in wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('tags'):
     wLnkoCBTNtsSrPzGFpxaWEJqODyIKQ.append(wLnkoCBTNtsSrPzGFpxaWEJqODyIKh.get('tag'))
    wLnkoCBTNtsSrPzGFpxaWEJqODyIeV={'id':wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('id'),'title':wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('title'),'thumbnail':{'poster':wLnkoCBTNtsSrPzGFpxaWEJqODyIKv,'thumb':wLnkoCBTNtsSrPzGFpxaWEJqODyIKm,'clearlogo':wLnkoCBTNtsSrPzGFpxaWEJqODyIvd,'fanart':wLnkoCBTNtsSrPzGFpxaWEJqODyIKV},'mpaa':wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('age_rating'),'duration':wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('running_time'),'asis':wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('as'),'badge':wLnkoCBTNtsSrPzGFpxaWEJqODyIKY,'year':wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('meta').get('releaseYear'),'seasonList':wLnkoCBTNtsSrPzGFpxaWEJqODyIKc,'genreList':wLnkoCBTNtsSrPzGFpxaWEJqODyIKQ,}
    wLnkoCBTNtsSrPzGFpxaWEJqODyIeu.append(wLnkoCBTNtsSrPzGFpxaWEJqODyIeV)
   if wLnkoCBTNtsSrPzGFpxaWEJqODyIej.get('pagination').get('totalPages')>page_int:
    wLnkoCBTNtsSrPzGFpxaWEJqODyIKd=wLnkoCBTNtsSrPzGFpxaWEJqODyIvb
  except wLnkoCBTNtsSrPzGFpxaWEJqODyIvA as exception:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIvm(exception)
   return[],wLnkoCBTNtsSrPzGFpxaWEJqODyIvh
  return wLnkoCBTNtsSrPzGFpxaWEJqODyIeu,wLnkoCBTNtsSrPzGFpxaWEJqODyIKd
 def Get_Episode_List(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK,programId,season):
  wLnkoCBTNtsSrPzGFpxaWEJqODyIeu=[] 
  try:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIev=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.API_VIEWURL+'/v1/discover/titles/'+programId+'/episodes'
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeX={'season':season,'sort':'true','locale':'ko',}
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeY=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.callRequestCookies('Get',wLnkoCBTNtsSrPzGFpxaWEJqODyIev,payload=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,params=wLnkoCBTNtsSrPzGFpxaWEJqODyIeX,headers=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,cookies=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,redirects=wLnkoCBTNtsSrPzGFpxaWEJqODyIvb)
   if wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.status_code not in[200]:return[]
   wLnkoCBTNtsSrPzGFpxaWEJqODyIej=json.loads(wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.text)
   for wLnkoCBTNtsSrPzGFpxaWEJqODyIeM in wLnkoCBTNtsSrPzGFpxaWEJqODyIej.get('data'):
    wLnkoCBTNtsSrPzGFpxaWEJqODyIKm=''
    if 'story-art' in wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('images'):wLnkoCBTNtsSrPzGFpxaWEJqODyIKm =wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('images').get('story-art').get('url')
    wLnkoCBTNtsSrPzGFpxaWEJqODyIKQ =[]
    for wLnkoCBTNtsSrPzGFpxaWEJqODyIKh in wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('tags'):
     wLnkoCBTNtsSrPzGFpxaWEJqODyIKQ.append(wLnkoCBTNtsSrPzGFpxaWEJqODyIKh.get('tag'))
    wLnkoCBTNtsSrPzGFpxaWEJqODyIeV={'id':wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('id'),'title':wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('title'),'thumbnail':{'thumb':wLnkoCBTNtsSrPzGFpxaWEJqODyIKm,'fanart':wLnkoCBTNtsSrPzGFpxaWEJqODyIKm},'mpaa':wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('age_rating'),'duration':wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('running_time'),'asis':wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('as'),'year':wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('meta').get('releaseYear'),'episode':wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('episode'),'genreList':wLnkoCBTNtsSrPzGFpxaWEJqODyIKQ,'desc':wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('description'),}
    wLnkoCBTNtsSrPzGFpxaWEJqODyIeu.append(wLnkoCBTNtsSrPzGFpxaWEJqODyIeV)
  except wLnkoCBTNtsSrPzGFpxaWEJqODyIvA as exception:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIvm(exception)
   return[]
  return wLnkoCBTNtsSrPzGFpxaWEJqODyIeu
 def Get_vInfo(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK,titleId):
  try:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIev=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.API_VIEWURL+'/v1/discover/titles/'+titleId 
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeX={'locale':'ko'}
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeY=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.callRequestCookies('Get',wLnkoCBTNtsSrPzGFpxaWEJqODyIev,payload=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,params=wLnkoCBTNtsSrPzGFpxaWEJqODyIeX,headers=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,cookies=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,redirects=wLnkoCBTNtsSrPzGFpxaWEJqODyIvb)
   if wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.status_code not in[200]:return '','',''
   wLnkoCBTNtsSrPzGFpxaWEJqODyIej=json.loads(wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.text).get('data')
   wLnkoCBTNtsSrPzGFpxaWEJqODyIKc=''
   if wLnkoCBTNtsSrPzGFpxaWEJqODyIej.get('seasonList')!=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ:
    wLnkoCBTNtsSrPzGFpxaWEJqODyIKc=','.join(wLnkoCBTNtsSrPzGFpxaWEJqODyIvl(e)for e in wLnkoCBTNtsSrPzGFpxaWEJqODyIej.get('seasonList'))
   wLnkoCBTNtsSrPzGFpxaWEJqODyIKl={'age_rating':wLnkoCBTNtsSrPzGFpxaWEJqODyIej.get('age_rating'),'asset_id':wLnkoCBTNtsSrPzGFpxaWEJqODyIej.get('asset_id'),'availability':wLnkoCBTNtsSrPzGFpxaWEJqODyIej.get('availability'),'deal_id':wLnkoCBTNtsSrPzGFpxaWEJqODyIej.get('deal_id'),'downloadable':'true' if wLnkoCBTNtsSrPzGFpxaWEJqODyIej.get('downloadable')else 'false','region':wLnkoCBTNtsSrPzGFpxaWEJqODyIej.get('region'),'streamable':'true' if wLnkoCBTNtsSrPzGFpxaWEJqODyIej.get('streamable')else 'false','asis':wLnkoCBTNtsSrPzGFpxaWEJqODyIej.get('as'),'seasonList':wLnkoCBTNtsSrPzGFpxaWEJqODyIKc}
  except wLnkoCBTNtsSrPzGFpxaWEJqODyIvA as exception:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIvm(exception)
   return{}
  return wLnkoCBTNtsSrPzGFpxaWEJqODyIKl
 def Get_eInfo(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK,eventId):
  try:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIev=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.API_VIEWURL+'/v1/discover/events/'+eventId 
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeX={'locale':'ko'}
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeY=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.callRequestCookies('Get',wLnkoCBTNtsSrPzGFpxaWEJqODyIev,payload=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,params=wLnkoCBTNtsSrPzGFpxaWEJqODyIeX,headers=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,cookies=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,redirects=wLnkoCBTNtsSrPzGFpxaWEJqODyIvb)
   if wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.status_code not in[200]:return '','',''
   wLnkoCBTNtsSrPzGFpxaWEJqODyIej=json.loads(wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.text).get('data')
   wLnkoCBTNtsSrPzGFpxaWEJqODyIKl={'asset_id':wLnkoCBTNtsSrPzGFpxaWEJqODyIej.get('asset_id'),'deal_id':wLnkoCBTNtsSrPzGFpxaWEJqODyIej.get('deal_id'),'region':wLnkoCBTNtsSrPzGFpxaWEJqODyIej.get('region'),'streamable':'true' if wLnkoCBTNtsSrPzGFpxaWEJqODyIej.get('streamable')else 'false',}
  except wLnkoCBTNtsSrPzGFpxaWEJqODyIvA as exception:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIvm(exception)
   return{}
  return wLnkoCBTNtsSrPzGFpxaWEJqODyIKl
 def GetBroadURL(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK,titleId):
  wLnkoCBTNtsSrPzGFpxaWEJqODyIKg=''
  wLnkoCBTNtsSrPzGFpxaWEJqODyIKj =''
  wLnkoCBTNtsSrPzGFpxaWEJqODyIKl=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.Get_vInfo(titleId)
  if wLnkoCBTNtsSrPzGFpxaWEJqODyIKl=={}:return '',''
  try:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIev=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.API_DOMAIN+'/api/playback/play' 
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeX={'titleId':titleId}
   wLnkoCBTNtsSrPzGFpxaWEJqODyIdH,wLnkoCBTNtsSrPzGFpxaWEJqODyIdf,wLnkoCBTNtsSrPzGFpxaWEJqODyIdM=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.Make_authHeader()
   wLnkoCBTNtsSrPzGFpxaWEJqODyIel={'traceparent':wLnkoCBTNtsSrPzGFpxaWEJqODyIdH,'tracestate':wLnkoCBTNtsSrPzGFpxaWEJqODyIdf,'newrelic':wLnkoCBTNtsSrPzGFpxaWEJqODyIdM,'x-force-raw':'true','x-pcid':wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':wLnkoCBTNtsSrPzGFpxaWEJqODyIKl.get('age_rating'),'x-title-availability':wLnkoCBTNtsSrPzGFpxaWEJqODyIKl.get('availability'),'x-title-brightcove-id':wLnkoCBTNtsSrPzGFpxaWEJqODyIKl.get('asset_id'),'x-title-deal-id':wLnkoCBTNtsSrPzGFpxaWEJqODyIKl.get('deal_id'),'x-title-downloadable':wLnkoCBTNtsSrPzGFpxaWEJqODyIKl.get('downloadable'),'x-title-region':wLnkoCBTNtsSrPzGFpxaWEJqODyIKl.get('region'),'x-title-streamable':wLnkoCBTNtsSrPzGFpxaWEJqODyIKl.get('streamable'),}
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeK=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.make_CP_DefaultCookies()
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeY=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.callRequestCookies('Get',wLnkoCBTNtsSrPzGFpxaWEJqODyIev,payload=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,params=wLnkoCBTNtsSrPzGFpxaWEJqODyIeX,headers=wLnkoCBTNtsSrPzGFpxaWEJqODyIel,cookies=wLnkoCBTNtsSrPzGFpxaWEJqODyIeK,redirects=wLnkoCBTNtsSrPzGFpxaWEJqODyIvb)
   if wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.status_code not in[200]:return '',json.loads(wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.text).get('error').get('detail')
   wLnkoCBTNtsSrPzGFpxaWEJqODyIej=json.loads(wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.text)
   for wLnkoCBTNtsSrPzGFpxaWEJqODyIeM in wLnkoCBTNtsSrPzGFpxaWEJqODyIej.get('data').get('raw').get('sources'):
    if wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('type')=='application/dash+xml' and wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('src')[0:8]=='https://':
     wLnkoCBTNtsSrPzGFpxaWEJqODyIKg=wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('src')
     if 'key_systems' in wLnkoCBTNtsSrPzGFpxaWEJqODyIeM:
      wLnkoCBTNtsSrPzGFpxaWEJqODyIKj =wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('key_systems').get('com.widevine.alpha').get('license_url')
     break
  except wLnkoCBTNtsSrPzGFpxaWEJqODyIvA as exception:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIvm(exception)
   return '',''
  return wLnkoCBTNtsSrPzGFpxaWEJqODyIKg,wLnkoCBTNtsSrPzGFpxaWEJqODyIKj
 def GetEventURL(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK,eventId,wLnkoCBTNtsSrPzGFpxaWEJqODyIKX):
  wLnkoCBTNtsSrPzGFpxaWEJqODyIKg=''
  wLnkoCBTNtsSrPzGFpxaWEJqODyIKj =''
  wLnkoCBTNtsSrPzGFpxaWEJqODyIKl=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.Get_eInfo(eventId)
  if wLnkoCBTNtsSrPzGFpxaWEJqODyIKl=={}:return '',''
  try:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIev=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.API_DOMAIN+'/api/playback/play' 
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeX={'titleId':eventId,'titleType':wLnkoCBTNtsSrPzGFpxaWEJqODyIKX,}
   wLnkoCBTNtsSrPzGFpxaWEJqODyIdH,wLnkoCBTNtsSrPzGFpxaWEJqODyIdf,wLnkoCBTNtsSrPzGFpxaWEJqODyIdM=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.Make_authHeader()
   wLnkoCBTNtsSrPzGFpxaWEJqODyIel={'traceparent':wLnkoCBTNtsSrPzGFpxaWEJqODyIdH,'tracestate':wLnkoCBTNtsSrPzGFpxaWEJqODyIdf,'newrelic':wLnkoCBTNtsSrPzGFpxaWEJqODyIdM,'x-force-raw':'true','x-pcid':wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':wLnkoCBTNtsSrPzGFpxaWEJqODyIKl.get('asset_id'),'x-title-deal-id':wLnkoCBTNtsSrPzGFpxaWEJqODyIKl.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':wLnkoCBTNtsSrPzGFpxaWEJqODyIKl.get('region'),'x-title-streamable':wLnkoCBTNtsSrPzGFpxaWEJqODyIKl.get('streamable'),}
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeK=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.make_CP_DefaultCookies()
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeY=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.callRequestCookies('Get',wLnkoCBTNtsSrPzGFpxaWEJqODyIev,payload=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,params=wLnkoCBTNtsSrPzGFpxaWEJqODyIeX,headers=wLnkoCBTNtsSrPzGFpxaWEJqODyIel,cookies=wLnkoCBTNtsSrPzGFpxaWEJqODyIeK,redirects=wLnkoCBTNtsSrPzGFpxaWEJqODyIvb)
   if wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.status_code not in[200]:return '',json.loads(wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.text).get('error').get('detail')
   wLnkoCBTNtsSrPzGFpxaWEJqODyIej=json.loads(wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.text)
   for wLnkoCBTNtsSrPzGFpxaWEJqODyIeM in wLnkoCBTNtsSrPzGFpxaWEJqODyIej.get('data').get('raw').get('sources'):
    if wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('type')=='application/dash+xml' and wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('src')[0:8]=='https://':
     wLnkoCBTNtsSrPzGFpxaWEJqODyIKg=wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('src')
     if 'key_systems' in wLnkoCBTNtsSrPzGFpxaWEJqODyIeM:
      wLnkoCBTNtsSrPzGFpxaWEJqODyIKj =wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('key_systems').get('com.widevine.alpha').get('license_url')
     break
  except wLnkoCBTNtsSrPzGFpxaWEJqODyIvA as exception:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIvm(exception)
   return '',''
  return wLnkoCBTNtsSrPzGFpxaWEJqODyIKg,wLnkoCBTNtsSrPzGFpxaWEJqODyIKj
 def GetEventURL_Live(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK,eventId,wLnkoCBTNtsSrPzGFpxaWEJqODyIKX):
  wLnkoCBTNtsSrPzGFpxaWEJqODyIKg=''
  wLnkoCBTNtsSrPzGFpxaWEJqODyIKj =''
  wLnkoCBTNtsSrPzGFpxaWEJqODyIKl=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.Get_eInfo(eventId)
  if wLnkoCBTNtsSrPzGFpxaWEJqODyIKl=={}:return '',''
  try:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIev=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.API_DOMAIN+'/api/playback/play' 
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeX={'titleId':eventId,'titleType':wLnkoCBTNtsSrPzGFpxaWEJqODyIKX,}
   wLnkoCBTNtsSrPzGFpxaWEJqODyIdH,wLnkoCBTNtsSrPzGFpxaWEJqODyIdf,wLnkoCBTNtsSrPzGFpxaWEJqODyIdM=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.Make_authHeader()
   wLnkoCBTNtsSrPzGFpxaWEJqODyIel={'traceparent':wLnkoCBTNtsSrPzGFpxaWEJqODyIdH,'tracestate':wLnkoCBTNtsSrPzGFpxaWEJqODyIdf,'newrelic':wLnkoCBTNtsSrPzGFpxaWEJqODyIdM,'x-force-raw':'true','x-pcid':wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['PCID'],'x-platform':'web','x-profileId':wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':wLnkoCBTNtsSrPzGFpxaWEJqODyIKl.get('asset_id'),'x-title-deal-id':wLnkoCBTNtsSrPzGFpxaWEJqODyIKl.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':wLnkoCBTNtsSrPzGFpxaWEJqODyIKl.get('region'),'x-title-streamable':wLnkoCBTNtsSrPzGFpxaWEJqODyIKl.get('streamable'),}
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeK=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.make_CP_DefaultCookies()
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeY=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.callRequestCookies('Get',wLnkoCBTNtsSrPzGFpxaWEJqODyIev,payload=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,params=wLnkoCBTNtsSrPzGFpxaWEJqODyIeX,headers=wLnkoCBTNtsSrPzGFpxaWEJqODyIel,cookies=wLnkoCBTNtsSrPzGFpxaWEJqODyIeK,redirects=wLnkoCBTNtsSrPzGFpxaWEJqODyIvb)
   if wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.status_code not in[200]:return '',json.loads(wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.text).get('error').get('detail')
   wLnkoCBTNtsSrPzGFpxaWEJqODyIej=json.loads(wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.text)
   for wLnkoCBTNtsSrPzGFpxaWEJqODyIeM in wLnkoCBTNtsSrPzGFpxaWEJqODyIej.get('data').get('raw').get('sources'):
    if wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('type')=='application/x-mpegURL' and wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('src')[0:8]=='https://':
     wLnkoCBTNtsSrPzGFpxaWEJqODyIKg=wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('src')
     if 'key_systems' in wLnkoCBTNtsSrPzGFpxaWEJqODyIeM:
      wLnkoCBTNtsSrPzGFpxaWEJqODyIKj =wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('key_systems').get('com.widevine.alpha').get('license_url')
     break
  except wLnkoCBTNtsSrPzGFpxaWEJqODyIvA as exception:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIvm(exception)
   return '',''
  return wLnkoCBTNtsSrPzGFpxaWEJqODyIKg,wLnkoCBTNtsSrPzGFpxaWEJqODyIKj
 def Get_Theme_GroupList(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK,vType):
  wLnkoCBTNtsSrPzGFpxaWEJqODyIeu=[] 
  try:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIev=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.API_VIEWURL+'/v2/discover/feed' 
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeX={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':wLnkoCBTNtsSrPzGFpxaWEJqODyIvl(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.PAGE_LIMIT),'filterRestrictedContent':'false',}
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeY=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.callRequestCookies('Get',wLnkoCBTNtsSrPzGFpxaWEJqODyIev,payload=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,params=wLnkoCBTNtsSrPzGFpxaWEJqODyIeX,headers=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,cookies=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,redirects=wLnkoCBTNtsSrPzGFpxaWEJqODyIvb)
   if wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.status_code not in[200]:return[]
   wLnkoCBTNtsSrPzGFpxaWEJqODyIej=json.loads(wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.text)
   for wLnkoCBTNtsSrPzGFpxaWEJqODyIeM in wLnkoCBTNtsSrPzGFpxaWEJqODyIej.get('data'):
    if wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('type')=='Title-Rails-Curation':
     wLnkoCBTNtsSrPzGFpxaWEJqODyIKA =''
     wLnkoCBTNtsSrPzGFpxaWEJqODyIKi=7
     try:
      for i in wLnkoCBTNtsSrPzGFpxaWEJqODyIvR(wLnkoCBTNtsSrPzGFpxaWEJqODyIvu(wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('data'))):
       if i>=wLnkoCBTNtsSrPzGFpxaWEJqODyIKi:
        wLnkoCBTNtsSrPzGFpxaWEJqODyIKA=wLnkoCBTNtsSrPzGFpxaWEJqODyIKA+'...'
        break
       wLnkoCBTNtsSrPzGFpxaWEJqODyIKA=wLnkoCBTNtsSrPzGFpxaWEJqODyIKA+wLnkoCBTNtsSrPzGFpxaWEJqODyIeM['data'][i]['title']+'\n'
     except wLnkoCBTNtsSrPzGFpxaWEJqODyIvA as exception:
      wLnkoCBTNtsSrPzGFpxaWEJqODyIvm(exception)
     wLnkoCBTNtsSrPzGFpxaWEJqODyIeV={'collectionId':wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('obj_id'),'title':wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('row_name'),'category':wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('category'),'pre_title':wLnkoCBTNtsSrPzGFpxaWEJqODyIKA,}
     wLnkoCBTNtsSrPzGFpxaWEJqODyIeu.append(wLnkoCBTNtsSrPzGFpxaWEJqODyIeV)
  except wLnkoCBTNtsSrPzGFpxaWEJqODyIvA as exception:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIvm(exception)
   return[]
  return wLnkoCBTNtsSrPzGFpxaWEJqODyIeu
 def Get_Event_GroupList(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK):
  wLnkoCBTNtsSrPzGFpxaWEJqODyIeu=[] 
  try:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIev=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.API_VIEWURL+'/v2/discover/feed' 
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeX={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':7,'filterRestrictedContent':'false',}
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeY=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.callRequestCookies('Get',wLnkoCBTNtsSrPzGFpxaWEJqODyIev,payload=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,params=wLnkoCBTNtsSrPzGFpxaWEJqODyIeX,headers=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,cookies=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,redirects=wLnkoCBTNtsSrPzGFpxaWEJqODyIvb)
   if wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.status_code not in[200]:return[]
   wLnkoCBTNtsSrPzGFpxaWEJqODyIej=json.loads(wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.text)
   for wLnkoCBTNtsSrPzGFpxaWEJqODyIeM in wLnkoCBTNtsSrPzGFpxaWEJqODyIej.get('data'):
    if wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('row_name').strip()!='':
     wLnkoCBTNtsSrPzGFpxaWEJqODyIKA =''
     wLnkoCBTNtsSrPzGFpxaWEJqODyIKi=7
     try:
      for i in wLnkoCBTNtsSrPzGFpxaWEJqODyIvR(wLnkoCBTNtsSrPzGFpxaWEJqODyIvu(wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('data'))):
       if i>=wLnkoCBTNtsSrPzGFpxaWEJqODyIKi:
        wLnkoCBTNtsSrPzGFpxaWEJqODyIKA=wLnkoCBTNtsSrPzGFpxaWEJqODyIKA+'...'
        break
       wLnkoCBTNtsSrPzGFpxaWEJqODyIKA=wLnkoCBTNtsSrPzGFpxaWEJqODyIKA+wLnkoCBTNtsSrPzGFpxaWEJqODyIeM['data'][i]['title']+'\n'
     except wLnkoCBTNtsSrPzGFpxaWEJqODyIvA as exception:
      wLnkoCBTNtsSrPzGFpxaWEJqODyIvm(exception)
     wLnkoCBTNtsSrPzGFpxaWEJqODyIeV={'collectionId':wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('obj_id'),'title':wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('row_name'),'category':wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('type'),'pre_title':wLnkoCBTNtsSrPzGFpxaWEJqODyIKA,}
     wLnkoCBTNtsSrPzGFpxaWEJqODyIeu.append(wLnkoCBTNtsSrPzGFpxaWEJqODyIeV)
  except wLnkoCBTNtsSrPzGFpxaWEJqODyIvA as exception:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIvm(exception)
   return[]
  return wLnkoCBTNtsSrPzGFpxaWEJqODyIeu
 def Get_Event_GameList(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK,wLnkoCBTNtsSrPzGFpxaWEJqODyIeU):
  wLnkoCBTNtsSrPzGFpxaWEJqODyIeu=[] 
  try:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIev=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.API_VIEWURL+'/v2/discover/feed' 
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeX={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false',}
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeY=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.callRequestCookies('Get',wLnkoCBTNtsSrPzGFpxaWEJqODyIev,payload=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,params=wLnkoCBTNtsSrPzGFpxaWEJqODyIeX,headers=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,cookies=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,redirects=wLnkoCBTNtsSrPzGFpxaWEJqODyIvb)
   if wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.status_code not in[200]:return[]
   wLnkoCBTNtsSrPzGFpxaWEJqODyIej=json.loads(wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.text)
   for wLnkoCBTNtsSrPzGFpxaWEJqODyIeM in wLnkoCBTNtsSrPzGFpxaWEJqODyIej.get('data'):
    if wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('obj_id')==wLnkoCBTNtsSrPzGFpxaWEJqODyIeU:
     for wLnkoCBTNtsSrPzGFpxaWEJqODyIKb in wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('data'):
      wLnkoCBTNtsSrPzGFpxaWEJqODyIKv=wLnkoCBTNtsSrPzGFpxaWEJqODyIKm=wLnkoCBTNtsSrPzGFpxaWEJqODyIKV=''
      if 'poster' in wLnkoCBTNtsSrPzGFpxaWEJqODyIKb.get('images'):wLnkoCBTNtsSrPzGFpxaWEJqODyIKv =wLnkoCBTNtsSrPzGFpxaWEJqODyIKb.get('images').get('poster').get('url')
      if 'story-art' in wLnkoCBTNtsSrPzGFpxaWEJqODyIKb.get('images'):wLnkoCBTNtsSrPzGFpxaWEJqODyIKm =wLnkoCBTNtsSrPzGFpxaWEJqODyIKb.get('images').get('story-art').get('url')
      if 'hero' in wLnkoCBTNtsSrPzGFpxaWEJqODyIKb.get('images'):wLnkoCBTNtsSrPzGFpxaWEJqODyIKV =wLnkoCBTNtsSrPzGFpxaWEJqODyIKb.get('images').get('hero').get('url')
      wLnkoCBTNtsSrPzGFpxaWEJqODyIKR=wLnkoCBTNtsSrPzGFpxaWEJqODyIKb.get('meta').get(wLnkoCBTNtsSrPzGFpxaWEJqODyIKb.get('category')).get(wLnkoCBTNtsSrPzGFpxaWEJqODyIKb.get('sub_category'))
      if 'league' in wLnkoCBTNtsSrPzGFpxaWEJqODyIKR:
       wLnkoCBTNtsSrPzGFpxaWEJqODyIKu=wLnkoCBTNtsSrPzGFpxaWEJqODyIKR.get('league')
      else:
       wLnkoCBTNtsSrPzGFpxaWEJqODyIKu=wLnkoCBTNtsSrPzGFpxaWEJqODyIKR.get('round')
      wLnkoCBTNtsSrPzGFpxaWEJqODyIeV={'id':wLnkoCBTNtsSrPzGFpxaWEJqODyIKb.get('id'),'title':wLnkoCBTNtsSrPzGFpxaWEJqODyIKb.get('title'),'thumbnail':{'poster':wLnkoCBTNtsSrPzGFpxaWEJqODyIKv,'thumb':wLnkoCBTNtsSrPzGFpxaWEJqODyIKm,'fanart':wLnkoCBTNtsSrPzGFpxaWEJqODyIKV},'asis':wLnkoCBTNtsSrPzGFpxaWEJqODyIKb.get('type'),'addInfo':wLnkoCBTNtsSrPzGFpxaWEJqODyIKu,'starttm':wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.convert_TimeStr(wLnkoCBTNtsSrPzGFpxaWEJqODyIKb.get('start_at')),}
      wLnkoCBTNtsSrPzGFpxaWEJqODyIeu.append(wLnkoCBTNtsSrPzGFpxaWEJqODyIeV)
  except wLnkoCBTNtsSrPzGFpxaWEJqODyIvA as exception:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIvm(exception)
   return[]
  return wLnkoCBTNtsSrPzGFpxaWEJqODyIeu
 def Get_Event_List(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK,gameId):
  wLnkoCBTNtsSrPzGFpxaWEJqODyIeu=[] 
  try:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIev=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.API_VIEWURL+'/v1/discover/events/'+gameId 
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeX={'platform':'WEBCLIENT','locale':'ko',}
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeY=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.callRequestCookies('Get',wLnkoCBTNtsSrPzGFpxaWEJqODyIev,payload=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,params=wLnkoCBTNtsSrPzGFpxaWEJqODyIeX,headers=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,cookies=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,redirects=wLnkoCBTNtsSrPzGFpxaWEJqODyIvb)
   if wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.status_code not in[200]:return[]
   wLnkoCBTNtsSrPzGFpxaWEJqODyIej=json.loads(wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.text)
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeM=wLnkoCBTNtsSrPzGFpxaWEJqODyIej.get('data')
   wLnkoCBTNtsSrPzGFpxaWEJqODyIKv=wLnkoCBTNtsSrPzGFpxaWEJqODyIKm=wLnkoCBTNtsSrPzGFpxaWEJqODyIKV=''
   if 'poster' in wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('images'):wLnkoCBTNtsSrPzGFpxaWEJqODyIKv =wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('images').get('poster').get('url')
   if 'story-art' in wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('images'):wLnkoCBTNtsSrPzGFpxaWEJqODyIKm =wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('images').get('story-art').get('url')
   if 'story-art' in wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('images'):wLnkoCBTNtsSrPzGFpxaWEJqODyIKV =wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('images').get('story-art').get('url')
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeV={'id':wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('id'),'title':wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('title'),'thumbnail':{'poster':wLnkoCBTNtsSrPzGFpxaWEJqODyIKv,'thumb':wLnkoCBTNtsSrPzGFpxaWEJqODyIKm,'fanart':wLnkoCBTNtsSrPzGFpxaWEJqODyIKV},'duration':wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('running_time'),'asis':wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('type'),'starttm':wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.convert_TimeStr(wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('start_at')),}
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeu.append(wLnkoCBTNtsSrPzGFpxaWEJqODyIeV)
  except wLnkoCBTNtsSrPzGFpxaWEJqODyIvA as exception:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIvm(exception)
   return[]
  try:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIev=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.API_VIEWURL+'/v1/discover/events/'+gameId+'/related' 
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeX={'locale':'ko','page':'1','perPage':'25','platform':'WEBCLIENT','currentPageTracking':'page_discover_title_detail',}
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeY=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.callRequestCookies('Get',wLnkoCBTNtsSrPzGFpxaWEJqODyIev,payload=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,params=wLnkoCBTNtsSrPzGFpxaWEJqODyIeX,headers=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,cookies=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,redirects=wLnkoCBTNtsSrPzGFpxaWEJqODyIvb)
   if wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.status_code not in[200]:return[]
   wLnkoCBTNtsSrPzGFpxaWEJqODyIej=json.loads(wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.text)
   for wLnkoCBTNtsSrPzGFpxaWEJqODyIeM in wLnkoCBTNtsSrPzGFpxaWEJqODyIej.get('data').get('data'):
    wLnkoCBTNtsSrPzGFpxaWEJqODyIKv=wLnkoCBTNtsSrPzGFpxaWEJqODyIKm=wLnkoCBTNtsSrPzGFpxaWEJqODyIKV=''
    if 'poster' in wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('images'):wLnkoCBTNtsSrPzGFpxaWEJqODyIKv =wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('images').get('poster').get('url')
    if 'story-art' in wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('images'):wLnkoCBTNtsSrPzGFpxaWEJqODyIKm =wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('images').get('story-art').get('url')
    if 'story-art' in wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('images'):wLnkoCBTNtsSrPzGFpxaWEJqODyIKV =wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('images').get('story-art').get('url')
    wLnkoCBTNtsSrPzGFpxaWEJqODyIeV={'id':wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('id'),'title':wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('title'),'thumbnail':{'poster':wLnkoCBTNtsSrPzGFpxaWEJqODyIKv,'thumb':wLnkoCBTNtsSrPzGFpxaWEJqODyIKm,'fanart':wLnkoCBTNtsSrPzGFpxaWEJqODyIKV},'duration':wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('running_time'),'asis':wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('type'),}
    wLnkoCBTNtsSrPzGFpxaWEJqODyIeu.append(wLnkoCBTNtsSrPzGFpxaWEJqODyIeV)
  except wLnkoCBTNtsSrPzGFpxaWEJqODyIvA as exception:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIvm(exception)
   return[]
  return wLnkoCBTNtsSrPzGFpxaWEJqODyIeu
 def Get_Search_List(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK,search_key,page_int):
  wLnkoCBTNtsSrPzGFpxaWEJqODyIeu=[] 
  wLnkoCBTNtsSrPzGFpxaWEJqODyIKd=wLnkoCBTNtsSrPzGFpxaWEJqODyIvh
  try:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIev=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.API_VIEWURL+'/v2/search' 
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeX={'query':search_key,'platform':'WEBCLIENT','page':wLnkoCBTNtsSrPzGFpxaWEJqODyIvl(page_int),'perPage':wLnkoCBTNtsSrPzGFpxaWEJqODyIvl(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.SEARCH_LIMIT),}
   wLnkoCBTNtsSrPzGFpxaWEJqODyIel={'x-membersrl':wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['member_srl'],'x-pcid':wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['PCID'],'x-profileid':wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.CP['SESSION']['profileId'],}
   wLnkoCBTNtsSrPzGFpxaWEJqODyIeY=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.callRequestCookies('Get',wLnkoCBTNtsSrPzGFpxaWEJqODyIev,payload=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,params=wLnkoCBTNtsSrPzGFpxaWEJqODyIeX,headers=wLnkoCBTNtsSrPzGFpxaWEJqODyIel,cookies=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,redirects=wLnkoCBTNtsSrPzGFpxaWEJqODyIvb)
   if wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.status_code not in[200]:return[],wLnkoCBTNtsSrPzGFpxaWEJqODyIvh
   wLnkoCBTNtsSrPzGFpxaWEJqODyIej=json.loads(wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.text)
   for wLnkoCBTNtsSrPzGFpxaWEJqODyIeM in wLnkoCBTNtsSrPzGFpxaWEJqODyIej.get('data').get('data'):
    wLnkoCBTNtsSrPzGFpxaWEJqODyIeM=wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('data')
    wLnkoCBTNtsSrPzGFpxaWEJqODyIKv=wLnkoCBTNtsSrPzGFpxaWEJqODyIKm=wLnkoCBTNtsSrPzGFpxaWEJqODyIvd=wLnkoCBTNtsSrPzGFpxaWEJqODyIKV=''
    if 'poster' in wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('images'):wLnkoCBTNtsSrPzGFpxaWEJqODyIKv =wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('images').get('poster').get('url')
    if 'story-art' in wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('images'):wLnkoCBTNtsSrPzGFpxaWEJqODyIKm =wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('images').get('story-art').get('url')
    if 'title-treatment' in wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('images'):wLnkoCBTNtsSrPzGFpxaWEJqODyIvd=wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('images').get('title-treatment').get('url')
    if 'story-art' in wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('images'):wLnkoCBTNtsSrPzGFpxaWEJqODyIKV =wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('images').get('story-art').get('url')
    wLnkoCBTNtsSrPzGFpxaWEJqODyIKY=''
    if wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('badge')not in[{},wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ]:
     for i in wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('badge').get('text'):
      if wLnkoCBTNtsSrPzGFpxaWEJqODyIKY!='':wLnkoCBTNtsSrPzGFpxaWEJqODyIKY+=' '
      wLnkoCBTNtsSrPzGFpxaWEJqODyIKY+=i.get('text')
    if 'as' in wLnkoCBTNtsSrPzGFpxaWEJqODyIeM:
     wLnkoCBTNtsSrPzGFpxaWEJqODyIKX=wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('as') 
    else:
     wLnkoCBTNtsSrPzGFpxaWEJqODyIKX=wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('type')
    wLnkoCBTNtsSrPzGFpxaWEJqODyIeV={'id':wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('id'),'title':wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('title'),'asis':wLnkoCBTNtsSrPzGFpxaWEJqODyIKX,'thumbnail':{'poster':wLnkoCBTNtsSrPzGFpxaWEJqODyIKv,'thumb':wLnkoCBTNtsSrPzGFpxaWEJqODyIKm,'clearlogo':wLnkoCBTNtsSrPzGFpxaWEJqODyIvd,'fanart':wLnkoCBTNtsSrPzGFpxaWEJqODyIKV},'mpaa':wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('age_rating'),'duration':wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('running_time'),'badge':wLnkoCBTNtsSrPzGFpxaWEJqODyIKY,'year':wLnkoCBTNtsSrPzGFpxaWEJqODyIeM.get('meta').get('releaseYear'),}
    wLnkoCBTNtsSrPzGFpxaWEJqODyIeu.append(wLnkoCBTNtsSrPzGFpxaWEJqODyIeV)
   if wLnkoCBTNtsSrPzGFpxaWEJqODyIej.get('pagination').get('totalPages')>page_int:
    wLnkoCBTNtsSrPzGFpxaWEJqODyIKd=wLnkoCBTNtsSrPzGFpxaWEJqODyIvb
  except wLnkoCBTNtsSrPzGFpxaWEJqODyIvA as exception:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIvm(exception)
   return[],wLnkoCBTNtsSrPzGFpxaWEJqODyIvh
  return wLnkoCBTNtsSrPzGFpxaWEJqODyIeu,wLnkoCBTNtsSrPzGFpxaWEJqODyIKd
 def GetBookmarkInfo(wLnkoCBTNtsSrPzGFpxaWEJqODyIdK,videoid,vidtype):
  wLnkoCBTNtsSrPzGFpxaWEJqODyIKH={'indexinfo':{'ott':'coupang','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  wLnkoCBTNtsSrPzGFpxaWEJqODyIev=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.API_VIEWURL+'/v1/discover/titles/'+videoid 
  wLnkoCBTNtsSrPzGFpxaWEJqODyIeX={'locale':'ko'}
  wLnkoCBTNtsSrPzGFpxaWEJqODyIeY=wLnkoCBTNtsSrPzGFpxaWEJqODyIdK.callRequestCookies('Get',wLnkoCBTNtsSrPzGFpxaWEJqODyIev,payload=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,params=wLnkoCBTNtsSrPzGFpxaWEJqODyIeX,headers=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,cookies=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ,redirects=wLnkoCBTNtsSrPzGFpxaWEJqODyIvb)
  if wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.status_code not in[200]:return{}
  wLnkoCBTNtsSrPzGFpxaWEJqODyIKf=json.loads(wLnkoCBTNtsSrPzGFpxaWEJqODyIeY.text).get('data')
  wLnkoCBTNtsSrPzGFpxaWEJqODyIKM=wLnkoCBTNtsSrPzGFpxaWEJqODyIKf.get('title')
  wLnkoCBTNtsSrPzGFpxaWEJqODyIKU =wLnkoCBTNtsSrPzGFpxaWEJqODyIKf.get('meta').get('releaseYear')
  wLnkoCBTNtsSrPzGFpxaWEJqODyIKH['saveinfo']['infoLabels']['title']=wLnkoCBTNtsSrPzGFpxaWEJqODyIKM
  if vidtype=='movie':
   wLnkoCBTNtsSrPzGFpxaWEJqODyIKM='%s  (%s)'%(wLnkoCBTNtsSrPzGFpxaWEJqODyIKM,wLnkoCBTNtsSrPzGFpxaWEJqODyIKU)
  wLnkoCBTNtsSrPzGFpxaWEJqODyIKH['saveinfo']['title'] =wLnkoCBTNtsSrPzGFpxaWEJqODyIKM
  wLnkoCBTNtsSrPzGFpxaWEJqODyIKH['saveinfo']['infoLabels']['mpaa'] =wLnkoCBTNtsSrPzGFpxaWEJqODyIKf.get('age_rating')
  wLnkoCBTNtsSrPzGFpxaWEJqODyIKH['saveinfo']['infoLabels']['plot'] ='%s\n\n%s'%(wLnkoCBTNtsSrPzGFpxaWEJqODyIKf.get('short_description'),wLnkoCBTNtsSrPzGFpxaWEJqODyIKf.get('description'))
  wLnkoCBTNtsSrPzGFpxaWEJqODyIKH['saveinfo']['infoLabels']['year'] =wLnkoCBTNtsSrPzGFpxaWEJqODyIKU
  if vidtype=='movie':
   wLnkoCBTNtsSrPzGFpxaWEJqODyIKH['saveinfo']['infoLabels']['duration']=wLnkoCBTNtsSrPzGFpxaWEJqODyIKf.get('running_time')
  wLnkoCBTNtsSrPzGFpxaWEJqODyIKv =''
  wLnkoCBTNtsSrPzGFpxaWEJqODyIKV =''
  wLnkoCBTNtsSrPzGFpxaWEJqODyIKm =''
  wLnkoCBTNtsSrPzGFpxaWEJqODyIvd=''
  if wLnkoCBTNtsSrPzGFpxaWEJqODyIKf.get('images').get('poster') !=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ:wLnkoCBTNtsSrPzGFpxaWEJqODyIKv =wLnkoCBTNtsSrPzGFpxaWEJqODyIKf.get('images').get('poster').get('url')
  if wLnkoCBTNtsSrPzGFpxaWEJqODyIKf.get('images').get('background') !=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ:wLnkoCBTNtsSrPzGFpxaWEJqODyIKV =wLnkoCBTNtsSrPzGFpxaWEJqODyIKf.get('images').get('background').get('url')
  if wLnkoCBTNtsSrPzGFpxaWEJqODyIKf.get('images').get('story-art') !=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ:wLnkoCBTNtsSrPzGFpxaWEJqODyIKm =wLnkoCBTNtsSrPzGFpxaWEJqODyIKf.get('images').get('story-art').get('url')
  if wLnkoCBTNtsSrPzGFpxaWEJqODyIKf.get('images').get('title-treatment')!=wLnkoCBTNtsSrPzGFpxaWEJqODyIvQ:wLnkoCBTNtsSrPzGFpxaWEJqODyIvd=wLnkoCBTNtsSrPzGFpxaWEJqODyIKf.get('images').get('title-treatment').get('url')
  if wLnkoCBTNtsSrPzGFpxaWEJqODyIKV=='':wLnkoCBTNtsSrPzGFpxaWEJqODyIKV=wLnkoCBTNtsSrPzGFpxaWEJqODyIKm
  wLnkoCBTNtsSrPzGFpxaWEJqODyIKH['saveinfo']['thumbnail']['poster']=wLnkoCBTNtsSrPzGFpxaWEJqODyIKv
  wLnkoCBTNtsSrPzGFpxaWEJqODyIKH['saveinfo']['thumbnail']['fanart']=wLnkoCBTNtsSrPzGFpxaWEJqODyIKV
  wLnkoCBTNtsSrPzGFpxaWEJqODyIKH['saveinfo']['thumbnail']['thumb']=wLnkoCBTNtsSrPzGFpxaWEJqODyIKm
  wLnkoCBTNtsSrPzGFpxaWEJqODyIKH['saveinfo']['thumbnail']['clearlogo']=wLnkoCBTNtsSrPzGFpxaWEJqODyIvd
  wLnkoCBTNtsSrPzGFpxaWEJqODyIve=[]
  for wLnkoCBTNtsSrPzGFpxaWEJqODyIKh in wLnkoCBTNtsSrPzGFpxaWEJqODyIKf.get('tags'):wLnkoCBTNtsSrPzGFpxaWEJqODyIve.append(wLnkoCBTNtsSrPzGFpxaWEJqODyIKh.get('tag'))
  if wLnkoCBTNtsSrPzGFpxaWEJqODyIvu(wLnkoCBTNtsSrPzGFpxaWEJqODyIve)>0:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIKH['saveinfo']['infoLabels']['genre']=wLnkoCBTNtsSrPzGFpxaWEJqODyIve
  wLnkoCBTNtsSrPzGFpxaWEJqODyIvK=[]
  wLnkoCBTNtsSrPzGFpxaWEJqODyIvY=[]
  for wLnkoCBTNtsSrPzGFpxaWEJqODyIKh in wLnkoCBTNtsSrPzGFpxaWEJqODyIKf.get('people'):
   if wLnkoCBTNtsSrPzGFpxaWEJqODyIKh.get('role')=='CAST' :wLnkoCBTNtsSrPzGFpxaWEJqODyIvK.append(wLnkoCBTNtsSrPzGFpxaWEJqODyIKh.get('name'))
   if wLnkoCBTNtsSrPzGFpxaWEJqODyIKh.get('role')=='DIRECTOR':wLnkoCBTNtsSrPzGFpxaWEJqODyIvY.append(wLnkoCBTNtsSrPzGFpxaWEJqODyIKh.get('name'))
  if wLnkoCBTNtsSrPzGFpxaWEJqODyIvu(wLnkoCBTNtsSrPzGFpxaWEJqODyIvK)>0:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIKH['saveinfo']['infoLabels']['cast'] =wLnkoCBTNtsSrPzGFpxaWEJqODyIvK
  if wLnkoCBTNtsSrPzGFpxaWEJqODyIvu(wLnkoCBTNtsSrPzGFpxaWEJqODyIvY)>0:
   wLnkoCBTNtsSrPzGFpxaWEJqODyIKH['saveinfo']['infoLabels']['director']=wLnkoCBTNtsSrPzGFpxaWEJqODyIvY
  return wLnkoCBTNtsSrPzGFpxaWEJqODyIKH
# Created by pyminifier (https://github.com/liftoff/pyminifier)
