__author__="NightRain"
cWkSMnfqDbvrxdPOKpmtLhjgQzeVFG=object
cWkSMnfqDbvrxdPOKpmtLhjgQzeVFl=None
cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu=False
cWkSMnfqDbvrxdPOKpmtLhjgQzeVFi=True
cWkSMnfqDbvrxdPOKpmtLhjgQzeVFo=type
cWkSMnfqDbvrxdPOKpmtLhjgQzeVFX=dict
cWkSMnfqDbvrxdPOKpmtLhjgQzeVFa=getattr
cWkSMnfqDbvrxdPOKpmtLhjgQzeVFC=int
cWkSMnfqDbvrxdPOKpmtLhjgQzeVFw=list
cWkSMnfqDbvrxdPOKpmtLhjgQzeVFT=open
cWkSMnfqDbvrxdPOKpmtLhjgQzeVFs=Exception
cWkSMnfqDbvrxdPOKpmtLhjgQzeVFy=str
cWkSMnfqDbvrxdPOKpmtLhjgQzeVFE=id
cWkSMnfqDbvrxdPOKpmtLhjgQzeVFH=len
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import inputstreamhelper
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
cWkSMnfqDbvrxdPOKpmtLhjgQzeVGu=[{'title':'오직 쿠팡플레이에서','mode':'CATEGORY_LIST','vType':'ORIGINAL','collectionId':'5c33c5ca-ee6f-45f8-a026-dd789a8b63cf'},{'title':'홈   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'ALL'},{'title':'TV   (장르별)','mode':'CATEGORY_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'MOVIES'},{'title':'키즈 (장르별)','mode':'CATEGORY_GROUPLIST','vType':'KIDS'},{'title':'생중계','mode':'EVENT_GROUPLIST','vType':'LIVE'},{'title':'TV   (테마별)','mode':'THEME_GROUPLIST','vType':'TVSHOWS'},{'title':'영화 (테마별)','mode':'THEME_GROUPLIST','vType':'MOVIES'},{'title':'키즈 (테마별)','mode':'THEME_GROUPLIST','vType':'KIDS'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},{'title':'(쿠팡) 검색','mode':'LOCAL_SEARCH','icon':'search.png'},{'title':'(쿠팡) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색(웨이브,티빙,왓챠,쿠팡,넷플) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
cWkSMnfqDbvrxdPOKpmtLhjgQzeVGi=[{'title':'시리즈 시청내역','mode':'WATCH','stype':'tvshow'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},]
cWkSMnfqDbvrxdPOKpmtLhjgQzeVGo={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
cWkSMnfqDbvrxdPOKpmtLhjgQzeVGX=xbmcvfs.translatePath(os.path.join(__profile__,'coupang_searched.txt'))
from coupangCore import*
class cWkSMnfqDbvrxdPOKpmtLhjgQzeVGl(cWkSMnfqDbvrxdPOKpmtLhjgQzeVFG):
 def __init__(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF,cWkSMnfqDbvrxdPOKpmtLhjgQzeVGa,cWkSMnfqDbvrxdPOKpmtLhjgQzeVGC,cWkSMnfqDbvrxdPOKpmtLhjgQzeVGw):
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF._addon_url =cWkSMnfqDbvrxdPOKpmtLhjgQzeVGa
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF._addon_handle=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGC
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.main_params =cWkSMnfqDbvrxdPOKpmtLhjgQzeVGw
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj =cxqyGFuLAMzshrIBJHkfgRwQjdTeUX() 
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.CP_COOKIE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_cookies.json'))
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.CP_DEVICE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'cp_device.json'))
 def addon_noti(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF,sting):
  try:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGs=xbmcgui.Dialog()
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGs.notification(__addonname__,sting)
  except:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVFl
 def addon_log(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF,string):
  try:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGy=string.encode('utf-8','ignore')
  except:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGy='addonException: addon_log'
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVGE=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,cWkSMnfqDbvrxdPOKpmtLhjgQzeVGy),level=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGE)
 def get_keyboard_input(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF,cWkSMnfqDbvrxdPOKpmtLhjgQzeVli):
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVGH=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFl
  kb=xbmc.Keyboard()
  kb.setHeading(cWkSMnfqDbvrxdPOKpmtLhjgQzeVli)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGH=kb.getText()
  return cWkSMnfqDbvrxdPOKpmtLhjgQzeVGH
 def get_settings_account(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF):
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVGJ=__addon__.getSetting('id')
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVGR=__addon__.getSetting('pw')
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVGA=__addon__.getSetting('profile')
  return(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGJ,cWkSMnfqDbvrxdPOKpmtLhjgQzeVGR,cWkSMnfqDbvrxdPOKpmtLhjgQzeVGA)
 def get_settings_exclusion21(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF):
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVGN =__addon__.getSetting('exclusion21')
  if cWkSMnfqDbvrxdPOKpmtLhjgQzeVGN=='false':
   return cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu
  else:
   return cWkSMnfqDbvrxdPOKpmtLhjgQzeVFi
 def get_settings_totalsearch(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF):
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVGY =cWkSMnfqDbvrxdPOKpmtLhjgQzeVFi if __addon__.getSetting('local_search')=='true' else cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVGB=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFi if __addon__.getSetting('local_history')=='true' else cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVGU =cWkSMnfqDbvrxdPOKpmtLhjgQzeVFi if __addon__.getSetting('total_search')=='true' else cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVGI=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFi if __addon__.getSetting('total_history')=='true' else cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVlG=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFi if __addon__.getSetting('menu_bookmark')=='true' else cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu
  return(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGY,cWkSMnfqDbvrxdPOKpmtLhjgQzeVGB,cWkSMnfqDbvrxdPOKpmtLhjgQzeVGU,cWkSMnfqDbvrxdPOKpmtLhjgQzeVGI,cWkSMnfqDbvrxdPOKpmtLhjgQzeVlG)
 def get_settings_makebookmark(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF):
  return cWkSMnfqDbvrxdPOKpmtLhjgQzeVFi if __addon__.getSetting('make_bookmark')=='true' else cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu
 def add_dir(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF,label,sublabel='',img='',infoLabels=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFl,isFolder=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFi,params='',isLink=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu,ContextMenu=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFl):
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVlu='%s?%s'%(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF._addon_url,urllib.parse.urlencode(params))
  if sublabel:cWkSMnfqDbvrxdPOKpmtLhjgQzeVli='%s < %s >'%(label,sublabel)
  else: cWkSMnfqDbvrxdPOKpmtLhjgQzeVli=label
  if not img:img='DefaultFolder.png'
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVlo=xbmcgui.ListItem(cWkSMnfqDbvrxdPOKpmtLhjgQzeVli)
  if cWkSMnfqDbvrxdPOKpmtLhjgQzeVFo(img)==cWkSMnfqDbvrxdPOKpmtLhjgQzeVFX:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVlo.setArt(img)
  else:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVlo.setArt({'thumb':img,'poster':img})
  if cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.KodiVersion>=20:
   if infoLabels:cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.Set_InfoTag(cWkSMnfqDbvrxdPOKpmtLhjgQzeVlo.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:cWkSMnfqDbvrxdPOKpmtLhjgQzeVlo.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVlo.setProperty('IsPlayable','true')
  if ContextMenu:cWkSMnfqDbvrxdPOKpmtLhjgQzeVlo.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF._addon_handle,cWkSMnfqDbvrxdPOKpmtLhjgQzeVlu,cWkSMnfqDbvrxdPOKpmtLhjgQzeVlo,isFolder)
 def Set_InfoTag(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF,video_InfoTag:xbmc.InfoTagVideo,cWkSMnfqDbvrxdPOKpmtLhjgQzeVly):
  for cWkSMnfqDbvrxdPOKpmtLhjgQzeVlX,value in cWkSMnfqDbvrxdPOKpmtLhjgQzeVly.items():
   if cWkSMnfqDbvrxdPOKpmtLhjgQzeVGo[cWkSMnfqDbvrxdPOKpmtLhjgQzeVlX]['type']=='string':
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVFa(video_InfoTag,cWkSMnfqDbvrxdPOKpmtLhjgQzeVGo[cWkSMnfqDbvrxdPOKpmtLhjgQzeVlX]['func'])(value)
   elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVGo[cWkSMnfqDbvrxdPOKpmtLhjgQzeVlX]['type']=='int':
    if cWkSMnfqDbvrxdPOKpmtLhjgQzeVFo(value)==cWkSMnfqDbvrxdPOKpmtLhjgQzeVFC:
     cWkSMnfqDbvrxdPOKpmtLhjgQzeVlF=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFC(value)
    else:
     cWkSMnfqDbvrxdPOKpmtLhjgQzeVlF=0
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVFa(video_InfoTag,cWkSMnfqDbvrxdPOKpmtLhjgQzeVGo[cWkSMnfqDbvrxdPOKpmtLhjgQzeVlX]['func'])(cWkSMnfqDbvrxdPOKpmtLhjgQzeVlF)
   elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVGo[cWkSMnfqDbvrxdPOKpmtLhjgQzeVlX]['type']=='actor':
    if value!=[]:
     cWkSMnfqDbvrxdPOKpmtLhjgQzeVFa(video_InfoTag,cWkSMnfqDbvrxdPOKpmtLhjgQzeVGo[cWkSMnfqDbvrxdPOKpmtLhjgQzeVlX]['func'])([xbmc.Actor(name)for name in value])
   elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVGo[cWkSMnfqDbvrxdPOKpmtLhjgQzeVlX]['type']=='list':
    if cWkSMnfqDbvrxdPOKpmtLhjgQzeVFo(value)==cWkSMnfqDbvrxdPOKpmtLhjgQzeVFw:
     cWkSMnfqDbvrxdPOKpmtLhjgQzeVFa(video_InfoTag,cWkSMnfqDbvrxdPOKpmtLhjgQzeVGo[cWkSMnfqDbvrxdPOKpmtLhjgQzeVlX]['func'])(value)
    else:
     cWkSMnfqDbvrxdPOKpmtLhjgQzeVFa(video_InfoTag,cWkSMnfqDbvrxdPOKpmtLhjgQzeVGo[cWkSMnfqDbvrxdPOKpmtLhjgQzeVlX]['func'])([value])
 def dp_Main_List(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF,args):
  (cWkSMnfqDbvrxdPOKpmtLhjgQzeVGY,cWkSMnfqDbvrxdPOKpmtLhjgQzeVGB,cWkSMnfqDbvrxdPOKpmtLhjgQzeVGU,cWkSMnfqDbvrxdPOKpmtLhjgQzeVGI,cWkSMnfqDbvrxdPOKpmtLhjgQzeVlG)=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.get_settings_totalsearch()
  for cWkSMnfqDbvrxdPOKpmtLhjgQzeVla in cWkSMnfqDbvrxdPOKpmtLhjgQzeVGu:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVli=cWkSMnfqDbvrxdPOKpmtLhjgQzeVla.get('title')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVlC=''
   if cWkSMnfqDbvrxdPOKpmtLhjgQzeVla.get('mode')=='LOCAL_SEARCH' and cWkSMnfqDbvrxdPOKpmtLhjgQzeVGY ==cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu:continue
   elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVla.get('mode')=='SEARCH_HISTORY' and cWkSMnfqDbvrxdPOKpmtLhjgQzeVGB==cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu:continue
   elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVla.get('mode')=='TOTAL_SEARCH' and cWkSMnfqDbvrxdPOKpmtLhjgQzeVGU ==cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu:continue
   elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVla.get('mode')=='TOTAL_HISTORY' and cWkSMnfqDbvrxdPOKpmtLhjgQzeVGI==cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu:continue
   elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVla.get('mode')=='MENU_BOOKMARK' and cWkSMnfqDbvrxdPOKpmtLhjgQzeVlG==cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu:continue
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw={'mode':cWkSMnfqDbvrxdPOKpmtLhjgQzeVla.get('mode'),'vType':cWkSMnfqDbvrxdPOKpmtLhjgQzeVla.get('vType'),'collectionId':cWkSMnfqDbvrxdPOKpmtLhjgQzeVla.get('collectionId'),'page':'1',}
   if cWkSMnfqDbvrxdPOKpmtLhjgQzeVla.get('mode')=='LOCAL_SEARCH':cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw['historyyn']='Y' 
   if cWkSMnfqDbvrxdPOKpmtLhjgQzeVla.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVlT=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVls =cWkSMnfqDbvrxdPOKpmtLhjgQzeVFi
   else:
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVlT=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFi
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVls =cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVly={'title':cWkSMnfqDbvrxdPOKpmtLhjgQzeVli,'plot':cWkSMnfqDbvrxdPOKpmtLhjgQzeVli}
   if cWkSMnfqDbvrxdPOKpmtLhjgQzeVla.get('mode')=='XXX':cWkSMnfqDbvrxdPOKpmtLhjgQzeVly=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFl
   if 'icon' in cWkSMnfqDbvrxdPOKpmtLhjgQzeVla:cWkSMnfqDbvrxdPOKpmtLhjgQzeVlC=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',cWkSMnfqDbvrxdPOKpmtLhjgQzeVla.get('icon')) 
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.add_dir(cWkSMnfqDbvrxdPOKpmtLhjgQzeVli,sublabel='',img=cWkSMnfqDbvrxdPOKpmtLhjgQzeVlC,infoLabels=cWkSMnfqDbvrxdPOKpmtLhjgQzeVly,isFolder=cWkSMnfqDbvrxdPOKpmtLhjgQzeVlT,params=cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw,isLink=cWkSMnfqDbvrxdPOKpmtLhjgQzeVls)
  xbmcplugin.endOfDirectory(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF._addon_handle)
 def dp_Test(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF,args):
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.addon_noti('test')
 def CP_logout(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF):
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVGs=xbmcgui.Dialog()
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVlH=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGs.yesno(__language__(30905).encode('utf8'),__language__(30906).encode('utf8'))
  if cWkSMnfqDbvrxdPOKpmtLhjgQzeVlH==cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu:return 
  if os.path.isfile(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.CP_COOKIE_FILENAME):os.remove(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.CP_COOKIE_FILENAME)
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.addon_noti(__language__(30904).encode('utf-8'))
 def option_check(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF):
  (cWkSMnfqDbvrxdPOKpmtLhjgQzeVGJ,cWkSMnfqDbvrxdPOKpmtLhjgQzeVGR,cWkSMnfqDbvrxdPOKpmtLhjgQzeVGA)=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.get_settings_account()
  if cWkSMnfqDbvrxdPOKpmtLhjgQzeVGJ=='' or cWkSMnfqDbvrxdPOKpmtLhjgQzeVGR=='':
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGs=xbmcgui.Dialog()
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVlH=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGs.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if cWkSMnfqDbvrxdPOKpmtLhjgQzeVlH==cWkSMnfqDbvrxdPOKpmtLhjgQzeVFi:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.cookiefile_check()==cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu:
   if cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CP_login(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGJ,cWkSMnfqDbvrxdPOKpmtLhjgQzeVGR,cWkSMnfqDbvrxdPOKpmtLhjgQzeVGA)==cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu:
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.addon_noti(__language__(30903).encode('utf8'))
    sys.exit()
  else:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.Get_CP_profile(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGA,limit_days=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFC(__addon__.getSetting('cache_ttl')),re_check=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFi)
 def cookiefile_check(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF):
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVlR={}
  try: 
   fp=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFT(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.CP_COOKIE_FILENAME,'r',-1,'utf-8')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVlR= json.load(fp)
   fp.close()
  except cWkSMnfqDbvrxdPOKpmtLhjgQzeVFs as exception:
   return cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.CP=cWkSMnfqDbvrxdPOKpmtLhjgQzeVlR
  (cWkSMnfqDbvrxdPOKpmtLhjgQzeVGJ,cWkSMnfqDbvrxdPOKpmtLhjgQzeVGR,cWkSMnfqDbvrxdPOKpmtLhjgQzeVGA)=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.get_settings_account()
  (cWkSMnfqDbvrxdPOKpmtLhjgQzeVlA,cWkSMnfqDbvrxdPOKpmtLhjgQzeVlN,cWkSMnfqDbvrxdPOKpmtLhjgQzeVlY)=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.Load_session_acount()
  if cWkSMnfqDbvrxdPOKpmtLhjgQzeVGJ!=cWkSMnfqDbvrxdPOKpmtLhjgQzeVlA or cWkSMnfqDbvrxdPOKpmtLhjgQzeVGR!=cWkSMnfqDbvrxdPOKpmtLhjgQzeVlN or cWkSMnfqDbvrxdPOKpmtLhjgQzeVGA!=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFy(cWkSMnfqDbvrxdPOKpmtLhjgQzeVlY):
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.Init_CP()
   return cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVlB =cWkSMnfqDbvrxdPOKpmtLhjgQzeVFC(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.Get_Now_Datetime().strftime('%Y%m%d'))
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVlU=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.CP['SESSION']['limitdate']
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVlI =cWkSMnfqDbvrxdPOKpmtLhjgQzeVFC(re.sub('-','',cWkSMnfqDbvrxdPOKpmtLhjgQzeVlU))
  if cWkSMnfqDbvrxdPOKpmtLhjgQzeVlI<cWkSMnfqDbvrxdPOKpmtLhjgQzeVlB:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.Init_CP()
   return cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu
  return cWkSMnfqDbvrxdPOKpmtLhjgQzeVFi
 def CP_login(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF,cWkSMnfqDbvrxdPOKpmtLhjgQzeVGJ,cWkSMnfqDbvrxdPOKpmtLhjgQzeVGR,cWkSMnfqDbvrxdPOKpmtLhjgQzeVGA):
  if cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.Get_CP_Login(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGJ,cWkSMnfqDbvrxdPOKpmtLhjgQzeVGR,cWkSMnfqDbvrxdPOKpmtLhjgQzeVGA)==cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu:return cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu
  if cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.Get_CP_profile(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGA,limit_days=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFC(__addon__.getSetting('cache_ttl')),re_check=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu)==cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu:return cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu
  return cWkSMnfqDbvrxdPOKpmtLhjgQzeVFi
 def dp_Category_GroupList(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF,args):
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVuG =args.get('vType') 
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVul=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.Get_Category_GroupList(cWkSMnfqDbvrxdPOKpmtLhjgQzeVuG)
  for cWkSMnfqDbvrxdPOKpmtLhjgQzeVui in cWkSMnfqDbvrxdPOKpmtLhjgQzeVul:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVli =cWkSMnfqDbvrxdPOKpmtLhjgQzeVui.get('title')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuo=cWkSMnfqDbvrxdPOKpmtLhjgQzeVui.get('pre_title')
   if cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.get_settings_exclusion21()==cWkSMnfqDbvrxdPOKpmtLhjgQzeVFi and cWkSMnfqDbvrxdPOKpmtLhjgQzeVli=='성인':continue
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuX={'mediatype':'tvshow','plot':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuo,}
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw={'mode':'CATEGORY_LIST','collectionId':cWkSMnfqDbvrxdPOKpmtLhjgQzeVui.get('collectionId'),'vType':cWkSMnfqDbvrxdPOKpmtLhjgQzeVui.get('category'),'page':'1',}
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.add_dir(cWkSMnfqDbvrxdPOKpmtLhjgQzeVli,sublabel='',img='',infoLabels=cWkSMnfqDbvrxdPOKpmtLhjgQzeVuX,isFolder=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFi,params=cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw)
  xbmcplugin.endOfDirectory(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF._addon_handle,cacheToDisc=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu)
 def dp_Theme_GroupList(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF,args):
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVuG =args.get('vType') 
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVul=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.Get_Theme_GroupList(cWkSMnfqDbvrxdPOKpmtLhjgQzeVuG)
  for cWkSMnfqDbvrxdPOKpmtLhjgQzeVui in cWkSMnfqDbvrxdPOKpmtLhjgQzeVul:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVli =cWkSMnfqDbvrxdPOKpmtLhjgQzeVui.get('title')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuo=cWkSMnfqDbvrxdPOKpmtLhjgQzeVui.get('pre_title')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuX={'mediatype':'tvshow','plot':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuo,}
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw={'mode':'CATEGORY_LIST','collectionId':cWkSMnfqDbvrxdPOKpmtLhjgQzeVui.get('collectionId'),'vType':cWkSMnfqDbvrxdPOKpmtLhjgQzeVui.get('category'),'page':'1',}
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.add_dir(cWkSMnfqDbvrxdPOKpmtLhjgQzeVli,sublabel='',img='',infoLabels=cWkSMnfqDbvrxdPOKpmtLhjgQzeVuX,isFolder=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFi,params=cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw)
  xbmcplugin.endOfDirectory(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF._addon_handle,cacheToDisc=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu)
 def dp_Event_GroupList(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF,args):
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVul=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.Get_Event_GroupList()
  for cWkSMnfqDbvrxdPOKpmtLhjgQzeVui in cWkSMnfqDbvrxdPOKpmtLhjgQzeVul:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVli =cWkSMnfqDbvrxdPOKpmtLhjgQzeVui.get('title')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuo=cWkSMnfqDbvrxdPOKpmtLhjgQzeVui.get('pre_title')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuX={'mediatype':'tvshow','plot':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuo,}
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw={'mode':'EVENT_GAMELIST','collectionId':cWkSMnfqDbvrxdPOKpmtLhjgQzeVui.get('collectionId'),'vType':'LIVE',}
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.add_dir(cWkSMnfqDbvrxdPOKpmtLhjgQzeVli,sublabel='',img='',infoLabels=cWkSMnfqDbvrxdPOKpmtLhjgQzeVuX,isFolder=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFi,params=cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw)
  xbmcplugin.endOfDirectory(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF._addon_handle,cacheToDisc=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu)
 def dp_Event_GameList(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF,args):
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVuG =args.get('vType') 
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVua =args.get('collectionId')
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVul=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.Get_Event_GameList(cWkSMnfqDbvrxdPOKpmtLhjgQzeVua)
  for cWkSMnfqDbvrxdPOKpmtLhjgQzeVui in cWkSMnfqDbvrxdPOKpmtLhjgQzeVul:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVli =cWkSMnfqDbvrxdPOKpmtLhjgQzeVui.get('title')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVFE =cWkSMnfqDbvrxdPOKpmtLhjgQzeVui.get('id')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuC =cWkSMnfqDbvrxdPOKpmtLhjgQzeVui.get('thumbnail')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw =cWkSMnfqDbvrxdPOKpmtLhjgQzeVui.get('asis') 
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuT =cWkSMnfqDbvrxdPOKpmtLhjgQzeVui.get('addInfo')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVus =cWkSMnfqDbvrxdPOKpmtLhjgQzeVui.get('starttm')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuX={'mediatype':'tvshow','title':cWkSMnfqDbvrxdPOKpmtLhjgQzeVli,'plot':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuT,}
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw={'mode':'EVENT_LIST','id':cWkSMnfqDbvrxdPOKpmtLhjgQzeVFE,'asis':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw,'title':cWkSMnfqDbvrxdPOKpmtLhjgQzeVli,}
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.add_dir(cWkSMnfqDbvrxdPOKpmtLhjgQzeVli,sublabel=cWkSMnfqDbvrxdPOKpmtLhjgQzeVus,img=cWkSMnfqDbvrxdPOKpmtLhjgQzeVuC,infoLabels=cWkSMnfqDbvrxdPOKpmtLhjgQzeVuX,isFolder=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFi,params=cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw,ContextMenu=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFl)
  xbmcplugin.setContent(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF._addon_handle,cacheToDisc=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu)
 def dp_Event_List(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF,args):
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVuy=args.get('id')
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVul=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.Get_Event_List(cWkSMnfqDbvrxdPOKpmtLhjgQzeVuy)
  for cWkSMnfqDbvrxdPOKpmtLhjgQzeVui in cWkSMnfqDbvrxdPOKpmtLhjgQzeVul:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVli =cWkSMnfqDbvrxdPOKpmtLhjgQzeVui.get('title')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVFE =cWkSMnfqDbvrxdPOKpmtLhjgQzeVui.get('id')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuC =cWkSMnfqDbvrxdPOKpmtLhjgQzeVui.get('thumbnail')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw =cWkSMnfqDbvrxdPOKpmtLhjgQzeVui.get('asis') 
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuE =cWkSMnfqDbvrxdPOKpmtLhjgQzeVui.get('duration')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVus =cWkSMnfqDbvrxdPOKpmtLhjgQzeVui.get('starttm')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuX={'mediatype':'episode','title':cWkSMnfqDbvrxdPOKpmtLhjgQzeVli,'plot':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw,'duration':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuE,}
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw={'mode':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw,'id':cWkSMnfqDbvrxdPOKpmtLhjgQzeVFE,'asis':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw,'title':cWkSMnfqDbvrxdPOKpmtLhjgQzeVli,}
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.add_dir(cWkSMnfqDbvrxdPOKpmtLhjgQzeVli,sublabel=cWkSMnfqDbvrxdPOKpmtLhjgQzeVus,img=cWkSMnfqDbvrxdPOKpmtLhjgQzeVuC,infoLabels=cWkSMnfqDbvrxdPOKpmtLhjgQzeVuX,isFolder=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu,params=cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw,ContextMenu=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFl)
  xbmcplugin.setContent(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF._addon_handle,cacheToDisc=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu)
 def dp_Category_List(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF,args):
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVuG =args.get('vType') 
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVua =args.get('collectionId')
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVuH =cWkSMnfqDbvrxdPOKpmtLhjgQzeVFC(args.get('page'))
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVul,cWkSMnfqDbvrxdPOKpmtLhjgQzeVuJ=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.Get_Category_List(cWkSMnfqDbvrxdPOKpmtLhjgQzeVuG,cWkSMnfqDbvrxdPOKpmtLhjgQzeVua,cWkSMnfqDbvrxdPOKpmtLhjgQzeVuH)
  for cWkSMnfqDbvrxdPOKpmtLhjgQzeVui in cWkSMnfqDbvrxdPOKpmtLhjgQzeVul:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVli =cWkSMnfqDbvrxdPOKpmtLhjgQzeVui.get('title')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVFE =cWkSMnfqDbvrxdPOKpmtLhjgQzeVui.get('id')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuC =cWkSMnfqDbvrxdPOKpmtLhjgQzeVui.get('thumbnail')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuR =cWkSMnfqDbvrxdPOKpmtLhjgQzeVui.get('mpaa')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuE =cWkSMnfqDbvrxdPOKpmtLhjgQzeVui.get('duration')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw =cWkSMnfqDbvrxdPOKpmtLhjgQzeVui.get('asis')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuA =cWkSMnfqDbvrxdPOKpmtLhjgQzeVui.get('badge')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuN =cWkSMnfqDbvrxdPOKpmtLhjgQzeVui.get('year')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuY=cWkSMnfqDbvrxdPOKpmtLhjgQzeVui.get('seasonList')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuB =cWkSMnfqDbvrxdPOKpmtLhjgQzeVui.get('genreList')
   if cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw in['TVSHOW','EDUCATION']: 
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVuU ='SEASON_LIST'
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVuX={'mediatype':'tvshow','title':cWkSMnfqDbvrxdPOKpmtLhjgQzeVli,'mpaa':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuR,'genre':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuB,'year':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuN,'plot':'Year : %s\nSeason : %s'%(cWkSMnfqDbvrxdPOKpmtLhjgQzeVuN,cWkSMnfqDbvrxdPOKpmtLhjgQzeVuY),}
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVlT =cWkSMnfqDbvrxdPOKpmtLhjgQzeVFi
   else:
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVuU ='MOVIE'
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVuX={'mediatype':'movie','title':cWkSMnfqDbvrxdPOKpmtLhjgQzeVli,'mpaa':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuR,'genre':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuB,'duration':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuE,'year':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuN,'plot':'(%s)'%(cWkSMnfqDbvrxdPOKpmtLhjgQzeVuR),}
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVlT =cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVli +=' (%s)'%(cWkSMnfqDbvrxdPOKpmtLhjgQzeVFy(cWkSMnfqDbvrxdPOKpmtLhjgQzeVuN))
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw={'mode':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuU,'id':cWkSMnfqDbvrxdPOKpmtLhjgQzeVFE,'asis':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw,'seasonList':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuY,'title':cWkSMnfqDbvrxdPOKpmtLhjgQzeVli,'thumbnail':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuC,'year':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuN,}
   if cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.get_settings_makebookmark():
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVuI={'videoid':cWkSMnfqDbvrxdPOKpmtLhjgQzeVFE,'vidtype':'movie' if cWkSMnfqDbvrxdPOKpmtLhjgQzeVuG=='MOVIES' else 'tvshow','vtitle':cWkSMnfqDbvrxdPOKpmtLhjgQzeVli,'vsubtitle':'',}
    cWkSMnfqDbvrxdPOKpmtLhjgQzeViG=json.dumps(cWkSMnfqDbvrxdPOKpmtLhjgQzeVuI)
    cWkSMnfqDbvrxdPOKpmtLhjgQzeViG=urllib.parse.quote(cWkSMnfqDbvrxdPOKpmtLhjgQzeViG)
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVil='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(cWkSMnfqDbvrxdPOKpmtLhjgQzeViG)
    cWkSMnfqDbvrxdPOKpmtLhjgQzeViu=[('(통합) 찜 영상에 추가',cWkSMnfqDbvrxdPOKpmtLhjgQzeVil)]
   else:
    cWkSMnfqDbvrxdPOKpmtLhjgQzeViu=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFl
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.add_dir(cWkSMnfqDbvrxdPOKpmtLhjgQzeVli,sublabel=cWkSMnfqDbvrxdPOKpmtLhjgQzeVuA,img=cWkSMnfqDbvrxdPOKpmtLhjgQzeVuC,infoLabels=cWkSMnfqDbvrxdPOKpmtLhjgQzeVuX,isFolder=cWkSMnfqDbvrxdPOKpmtLhjgQzeVlT,params=cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw,ContextMenu=cWkSMnfqDbvrxdPOKpmtLhjgQzeViu)
  if cWkSMnfqDbvrxdPOKpmtLhjgQzeVuJ:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw['mode'] ='CATEGORY_LIST' 
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw['collectionId']=cWkSMnfqDbvrxdPOKpmtLhjgQzeVua 
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw['vType'] =cWkSMnfqDbvrxdPOKpmtLhjgQzeVuG 
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw['page'] =cWkSMnfqDbvrxdPOKpmtLhjgQzeVFy(cWkSMnfqDbvrxdPOKpmtLhjgQzeVuH+1)
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVli='[B]%s >>[/B]'%'다음 페이지'
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVio=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFy(cWkSMnfqDbvrxdPOKpmtLhjgQzeVuH+1)
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVlC=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.add_dir(cWkSMnfqDbvrxdPOKpmtLhjgQzeVli,sublabel=cWkSMnfqDbvrxdPOKpmtLhjgQzeVio,img=cWkSMnfqDbvrxdPOKpmtLhjgQzeVlC,infoLabels=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFl,isFolder=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFi,params=cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw)
  if cWkSMnfqDbvrxdPOKpmtLhjgQzeVuG=='TVSHOWS':xbmcplugin.setContent(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF._addon_handle,'tvshows')
  else:xbmcplugin.setContent(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF._addon_handle,'movies')
  xbmcplugin.endOfDirectory(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF._addon_handle,cacheToDisc=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu)
 def dp_Season_List(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF,args):
  cWkSMnfqDbvrxdPOKpmtLhjgQzeViX =args.get('title')
  cWkSMnfqDbvrxdPOKpmtLhjgQzeViF =args.get('id')
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw =args.get('asis')
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVuY =args.get('seasonList')
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVuC =args.get('thumbnail')
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVuN =args.get('year')
  if cWkSMnfqDbvrxdPOKpmtLhjgQzeVuY in['',cWkSMnfqDbvrxdPOKpmtLhjgQzeVFl]:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuY=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.Get_vInfo(cWkSMnfqDbvrxdPOKpmtLhjgQzeViF).get('seasonList')
  if cWkSMnfqDbvrxdPOKpmtLhjgQzeVFH(cWkSMnfqDbvrxdPOKpmtLhjgQzeVuY.split(','))>1:
   for cWkSMnfqDbvrxdPOKpmtLhjgQzeVia in cWkSMnfqDbvrxdPOKpmtLhjgQzeVuY.split(','):
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVli='시즌 '+cWkSMnfqDbvrxdPOKpmtLhjgQzeVia
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVuX={'mediatype':'tvshow','plot':'%s (%s)'%(cWkSMnfqDbvrxdPOKpmtLhjgQzeViX,cWkSMnfqDbvrxdPOKpmtLhjgQzeVuN),}
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw={'mode':'EPISODE_LIST','programid':cWkSMnfqDbvrxdPOKpmtLhjgQzeViF,'programnm':cWkSMnfqDbvrxdPOKpmtLhjgQzeViX,'season':cWkSMnfqDbvrxdPOKpmtLhjgQzeVia,'asis':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw,'programimg':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuC,}
    cWkSMnfqDbvrxdPOKpmtLhjgQzeViC=cWkSMnfqDbvrxdPOKpmtLhjgQzeVuC.replace('\'','\"')
    cWkSMnfqDbvrxdPOKpmtLhjgQzeViC=json.loads(cWkSMnfqDbvrxdPOKpmtLhjgQzeViC)
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.add_dir(cWkSMnfqDbvrxdPOKpmtLhjgQzeVli,sublabel='',img=cWkSMnfqDbvrxdPOKpmtLhjgQzeViC,infoLabels=cWkSMnfqDbvrxdPOKpmtLhjgQzeVuX,isFolder=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFi,params=cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw)
   xbmcplugin.setContent(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF._addon_handle,cacheToDisc=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu)
  else:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeViw={'programid':cWkSMnfqDbvrxdPOKpmtLhjgQzeViF,'programnm':cWkSMnfqDbvrxdPOKpmtLhjgQzeViX,'season':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuY,'programimg':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuC,}
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.dp_Episode_List(cWkSMnfqDbvrxdPOKpmtLhjgQzeViw)
 def dp_Episode_List(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF,args):
  cWkSMnfqDbvrxdPOKpmtLhjgQzeViF =args.get('programid')
  cWkSMnfqDbvrxdPOKpmtLhjgQzeViX =args.get('programnm')
  cWkSMnfqDbvrxdPOKpmtLhjgQzeViT =args.get('season')
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVis =args.get('programimg')
  cWkSMnfqDbvrxdPOKpmtLhjgQzeViy=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.Get_Episode_List(cWkSMnfqDbvrxdPOKpmtLhjgQzeViF,cWkSMnfqDbvrxdPOKpmtLhjgQzeViT)
  for cWkSMnfqDbvrxdPOKpmtLhjgQzeVia in cWkSMnfqDbvrxdPOKpmtLhjgQzeViy:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeViE =cWkSMnfqDbvrxdPOKpmtLhjgQzeVia.get('title')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeViH =cWkSMnfqDbvrxdPOKpmtLhjgQzeVia.get('id')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw =cWkSMnfqDbvrxdPOKpmtLhjgQzeVia.get('asis')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuC =cWkSMnfqDbvrxdPOKpmtLhjgQzeVia.get('thumbnail')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuR =cWkSMnfqDbvrxdPOKpmtLhjgQzeVia.get('mpaa')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuE =cWkSMnfqDbvrxdPOKpmtLhjgQzeVia.get('duration')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuN =cWkSMnfqDbvrxdPOKpmtLhjgQzeVia.get('year')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeViJ =cWkSMnfqDbvrxdPOKpmtLhjgQzeVia.get('episode')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuB =cWkSMnfqDbvrxdPOKpmtLhjgQzeVia.get('genreList')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeViR =cWkSMnfqDbvrxdPOKpmtLhjgQzeVia.get('desc')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeViA ='%sx%s'%(cWkSMnfqDbvrxdPOKpmtLhjgQzeViT,cWkSMnfqDbvrxdPOKpmtLhjgQzeViJ)
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVli ='%s. %s'%(cWkSMnfqDbvrxdPOKpmtLhjgQzeViA,cWkSMnfqDbvrxdPOKpmtLhjgQzeViE)
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuX={'mediatype':'episode','mpaa':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuR,'genre':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuB,'duration':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuE,'year':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuN,'plot':'%s (%s)\n\n%s'%(cWkSMnfqDbvrxdPOKpmtLhjgQzeViX,cWkSMnfqDbvrxdPOKpmtLhjgQzeViA,cWkSMnfqDbvrxdPOKpmtLhjgQzeViR),}
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw={'mode':'VOD','programid':cWkSMnfqDbvrxdPOKpmtLhjgQzeViF,'programnm':cWkSMnfqDbvrxdPOKpmtLhjgQzeViX,'title':cWkSMnfqDbvrxdPOKpmtLhjgQzeVli,'season':cWkSMnfqDbvrxdPOKpmtLhjgQzeViT,'id':cWkSMnfqDbvrxdPOKpmtLhjgQzeViH,'asis':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw,'thumbnail':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuC,'programimg':cWkSMnfqDbvrxdPOKpmtLhjgQzeVis,}
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.add_dir(cWkSMnfqDbvrxdPOKpmtLhjgQzeVli,sublabel='',img=cWkSMnfqDbvrxdPOKpmtLhjgQzeVuC,infoLabels=cWkSMnfqDbvrxdPOKpmtLhjgQzeVuX,isFolder=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu,params=cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw)
  xbmcplugin.setContent(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF._addon_handle,cacheToDisc=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu)
 def play_VIDEO(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF,args):
  cWkSMnfqDbvrxdPOKpmtLhjgQzeViN =args.get('id')
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw =args.get('asis')
  if cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw in['HIGHLIGHT']:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeViY,cWkSMnfqDbvrxdPOKpmtLhjgQzeViB=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.GetEventURL(cWkSMnfqDbvrxdPOKpmtLhjgQzeViN,cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw)
  elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw in['LIVE']:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeViY,cWkSMnfqDbvrxdPOKpmtLhjgQzeViB=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.GetEventURL_Live(cWkSMnfqDbvrxdPOKpmtLhjgQzeViN,cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw)
  else:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeViY,cWkSMnfqDbvrxdPOKpmtLhjgQzeViB=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.GetBroadURL(cWkSMnfqDbvrxdPOKpmtLhjgQzeViN)
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.addon_log('asis, url : %s - %s - %s'%(cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw,cWkSMnfqDbvrxdPOKpmtLhjgQzeViN,cWkSMnfqDbvrxdPOKpmtLhjgQzeViY))
  if cWkSMnfqDbvrxdPOKpmtLhjgQzeViY=='':
   if cWkSMnfqDbvrxdPOKpmtLhjgQzeViB=='':
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.addon_noti(__language__(30907).encode('utf8'))
   else:
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.addon_log('drm_license_1 : %s'%(cWkSMnfqDbvrxdPOKpmtLhjgQzeViB))
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.addon_noti(cWkSMnfqDbvrxdPOKpmtLhjgQzeViB)
   return
  else:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.addon_log('drm_license : %s'%(cWkSMnfqDbvrxdPOKpmtLhjgQzeViB))
  '''
  tmp_cookie = 'PCID=%s;token=%s;member_srl=%s;NEXT_LOCALE=%s;session_web_id=%s;device_id=%s' % (self.CoupangObj.CP['COOKIES']['PCID'], self.CoupangObj.CP['COOKIES']['token'], self.CoupangObj.CP['COOKIES']['member_srl'], self.CoupangObj.CP['COOKIES']['NEXT_LOCALE'], self.CoupangObj.CP['COOKIES']['session_web_id'], self.CoupangObj.CP['COOKIES']['device_id'], )
  '''  
  if cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw in['EPISODE']:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeViU='https://www.coupangplay.com/play/{}/episode?titleId={}&type=EPISODE&sourceType=page_discover_title_detail%3Apage_discover_feed'.format(cWkSMnfqDbvrxdPOKpmtLhjgQzeViN,cWkSMnfqDbvrxdPOKpmtLhjgQzeViN)
  elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw in['MOVIE']:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeViU='https://www.coupangplay.com/play/{}/movie?sourceType=page_discover_feed'.format(cWkSMnfqDbvrxdPOKpmtLhjgQzeViN)
  else:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeViU='https://www.coupangplay.com/play/'+cWkSMnfqDbvrxdPOKpmtLhjgQzeViN 
  cWkSMnfqDbvrxdPOKpmtLhjgQzeViI,cWkSMnfqDbvrxdPOKpmtLhjgQzeVoG,cWkSMnfqDbvrxdPOKpmtLhjgQzeVol=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.Make_authHeader()
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVou=cWkSMnfqDbvrxdPOKpmtLhjgQzeViY 
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.addon_log('tobe, surl : %s'%(cWkSMnfqDbvrxdPOKpmtLhjgQzeVou))
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVoi=xbmcgui.ListItem(path=cWkSMnfqDbvrxdPOKpmtLhjgQzeVou)
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVoX=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.Get_Url_PostFix(cWkSMnfqDbvrxdPOKpmtLhjgQzeViY) 
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.addon_log('post_fix : '+cWkSMnfqDbvrxdPOKpmtLhjgQzeVoX)
  if cWkSMnfqDbvrxdPOKpmtLhjgQzeVoX=='m3u8':
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVoF ='hls' 
  else:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVoF ='mpd' 
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVoa={'user-agent':cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.USER_AGENT,'referer':cWkSMnfqDbvrxdPOKpmtLhjgQzeViU,'traceparent':cWkSMnfqDbvrxdPOKpmtLhjgQzeViI,'tracestate':cWkSMnfqDbvrxdPOKpmtLhjgQzeVoG,'newrelic':cWkSMnfqDbvrxdPOKpmtLhjgQzeVol,}
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVoC =cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.CP['COOKIES']
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVow=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.make_stream_header(cWkSMnfqDbvrxdPOKpmtLhjgQzeVoa,cWkSMnfqDbvrxdPOKpmtLhjgQzeVoC)
  if cWkSMnfqDbvrxdPOKpmtLhjgQzeViB:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVoT =cWkSMnfqDbvrxdPOKpmtLhjgQzeViB 
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVos ='com.widevine.alpha'
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVoy=cWkSMnfqDbvrxdPOKpmtLhjgQzeVoT+'|'+cWkSMnfqDbvrxdPOKpmtLhjgQzeVow+'|R{SSM}|'
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVoi.setProperty('inputstream','inputstream.adaptive')
   if cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.KodiVersion<=20:
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVoi.setProperty('inputstream.adaptive.manifest_type',cWkSMnfqDbvrxdPOKpmtLhjgQzeVoF)
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVoi.setProperty('inputstream.adaptive.license_type',cWkSMnfqDbvrxdPOKpmtLhjgQzeVos)
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVoi.setProperty('inputstream.adaptive.license_key',cWkSMnfqDbvrxdPOKpmtLhjgQzeVoy)
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVoi.setProperty('inputstream.adaptive.stream_headers',cWkSMnfqDbvrxdPOKpmtLhjgQzeVow)
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVoi.setProperty('inputstream.adaptive.manifest_headers',cWkSMnfqDbvrxdPOKpmtLhjgQzeVow)
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVoi.setMimeType('application/dash+xml')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVoi.setContentLookup(cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu)
  else:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVoi.setContentLookup(cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu)
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVoi.setMimeType('application/x-mpegURL')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVoi.setProperty('inputstream','inputstream.adaptive')
   if cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.KodiVersion<=20:
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVoi.setProperty('inputstream.adaptive.manifest_type',cWkSMnfqDbvrxdPOKpmtLhjgQzeVoF)
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVoi.setProperty('inputstream.adaptive.stream_headers',cWkSMnfqDbvrxdPOKpmtLhjgQzeVow)
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVoi.setProperty('inputstream.adaptive.manifest_headers',cWkSMnfqDbvrxdPOKpmtLhjgQzeVow)
  xbmcplugin.setResolvedUrl(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF._addon_handle,cWkSMnfqDbvrxdPOKpmtLhjgQzeVFi,cWkSMnfqDbvrxdPOKpmtLhjgQzeVoi)
  try:
   if cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw=='MOVIE':
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVoE='movie'
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw={'code':cWkSMnfqDbvrxdPOKpmtLhjgQzeViN,'asis':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw,'title':args.get('title'),'img':args.get('thumbnail'),}
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.Save_Watched_List(cWkSMnfqDbvrxdPOKpmtLhjgQzeVoE,cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw)
   elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw=='EPISODE':
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVoE='tvshow'
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw={'code':args.get('programid'),'asis':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw,'title':'%s <%s>'%(args.get('title'),args.get('programnm')),'img':args.get('programimg'),}
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.Save_Watched_List(cWkSMnfqDbvrxdPOKpmtLhjgQzeVoE,cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw)
  except:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVFl
 def dp_Global_Search(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF,args):
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVuU=args.get('mode')
  if cWkSMnfqDbvrxdPOKpmtLhjgQzeVuU=='TOTAL_SEARCH':
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVoH='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVoH='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(cWkSMnfqDbvrxdPOKpmtLhjgQzeVoH)
 def dp_Bookmark_Menu(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF,args):
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVoH='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(cWkSMnfqDbvrxdPOKpmtLhjgQzeVoH)
 def dp_Search_List(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF,args):
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVuH =cWkSMnfqDbvrxdPOKpmtLhjgQzeVFC(args.get('page'))
  if 'search_key' in args:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVoJ=args.get('search_key')
  else:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVoJ=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.get_keyboard_input(__language__(30908).encode('utf-8'))
   if not cWkSMnfqDbvrxdPOKpmtLhjgQzeVoJ:
    return
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVoR,cWkSMnfqDbvrxdPOKpmtLhjgQzeVuJ=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.Get_Search_List(cWkSMnfqDbvrxdPOKpmtLhjgQzeVoJ,cWkSMnfqDbvrxdPOKpmtLhjgQzeVuH)
  for cWkSMnfqDbvrxdPOKpmtLhjgQzeVoA in cWkSMnfqDbvrxdPOKpmtLhjgQzeVoR:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVFE =cWkSMnfqDbvrxdPOKpmtLhjgQzeVoA.get('id')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVli =cWkSMnfqDbvrxdPOKpmtLhjgQzeVoA.get('title')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw =cWkSMnfqDbvrxdPOKpmtLhjgQzeVoA.get('asis')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuC =cWkSMnfqDbvrxdPOKpmtLhjgQzeVoA.get('thumbnail')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuR =cWkSMnfqDbvrxdPOKpmtLhjgQzeVoA.get('mpaa')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuN =cWkSMnfqDbvrxdPOKpmtLhjgQzeVoA.get('year')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuE =cWkSMnfqDbvrxdPOKpmtLhjgQzeVoA.get('duration')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuA =cWkSMnfqDbvrxdPOKpmtLhjgQzeVoA.get('badge')
   if cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw=='TVSHOW': 
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVuU ='SEASON_LIST'
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVuX={'mediatype':'tvshow','title':cWkSMnfqDbvrxdPOKpmtLhjgQzeVli,'mpaa':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuR,'year':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuN,'plot':'Year : %s'%(cWkSMnfqDbvrxdPOKpmtLhjgQzeVuN),}
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVlT =cWkSMnfqDbvrxdPOKpmtLhjgQzeVFi
   elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw=='MOVIE':
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVuU ='MOVIE'
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVuX={'mediatype':'movie','title':cWkSMnfqDbvrxdPOKpmtLhjgQzeVli,'mpaa':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuR,'duration':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuE,'year':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuN,'plot':'(%s)'%(cWkSMnfqDbvrxdPOKpmtLhjgQzeVuR),}
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVlT =cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVli +=' (%s)'%(cWkSMnfqDbvrxdPOKpmtLhjgQzeVFy(cWkSMnfqDbvrxdPOKpmtLhjgQzeVuN))
   elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw=='HIGHLIGHT':
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVuU ='HIGHLIGHT'
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVuX={'mediatype':'episode','title':cWkSMnfqDbvrxdPOKpmtLhjgQzeVli,'duration':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuE,'plot':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuU,}
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVlT =cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu
   elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw=='LIVE':
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVuU ='LIVE'
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVuX={'mediatype':'episode','title':cWkSMnfqDbvrxdPOKpmtLhjgQzeVli,'plot':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuU,}
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVlT =cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw={'mode':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuU,'id':cWkSMnfqDbvrxdPOKpmtLhjgQzeVFE,'asis':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw,'seasonList':'','title':cWkSMnfqDbvrxdPOKpmtLhjgQzeVli,'thumbnail':json.dumps(cWkSMnfqDbvrxdPOKpmtLhjgQzeVuC,separators=(',',':')),'year':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuN,}
   if cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.get_settings_makebookmark()and cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw not in['HIGHLIGHT','']:
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVuI={'videoid':cWkSMnfqDbvrxdPOKpmtLhjgQzeVFE,'vidtype':'movie' if cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw=='MOVIE' else 'tvshow','vtitle':cWkSMnfqDbvrxdPOKpmtLhjgQzeVli,'vsubtitle':'',}
    cWkSMnfqDbvrxdPOKpmtLhjgQzeViG=json.dumps(cWkSMnfqDbvrxdPOKpmtLhjgQzeVuI)
    cWkSMnfqDbvrxdPOKpmtLhjgQzeViG=urllib.parse.quote(cWkSMnfqDbvrxdPOKpmtLhjgQzeViG)
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVil='RunPlugin(plugin://plugin.video.coupangm/?mode=SET_BOOKMARK&bm_param=%s)'%(cWkSMnfqDbvrxdPOKpmtLhjgQzeViG)
    cWkSMnfqDbvrxdPOKpmtLhjgQzeViu=[('(통합) 찜 영상에 추가',cWkSMnfqDbvrxdPOKpmtLhjgQzeVil)]
   else:
    cWkSMnfqDbvrxdPOKpmtLhjgQzeViu=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFl
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.add_dir(cWkSMnfqDbvrxdPOKpmtLhjgQzeVli,sublabel=cWkSMnfqDbvrxdPOKpmtLhjgQzeVuA,img=cWkSMnfqDbvrxdPOKpmtLhjgQzeVuC,infoLabels=cWkSMnfqDbvrxdPOKpmtLhjgQzeVuX,isFolder=cWkSMnfqDbvrxdPOKpmtLhjgQzeVlT,params=cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw,ContextMenu=cWkSMnfqDbvrxdPOKpmtLhjgQzeViu)
  if cWkSMnfqDbvrxdPOKpmtLhjgQzeVuJ:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw={}
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw['mode'] ='LOCAL_SEARCH'
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw['search_key']=cWkSMnfqDbvrxdPOKpmtLhjgQzeVoJ
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw['page'] =cWkSMnfqDbvrxdPOKpmtLhjgQzeVFy(cWkSMnfqDbvrxdPOKpmtLhjgQzeVuH+1)
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVli='[B]%s >>[/B]'%'다음 페이지'
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVio=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFy(cWkSMnfqDbvrxdPOKpmtLhjgQzeVuH+1)
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVlC=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.add_dir(cWkSMnfqDbvrxdPOKpmtLhjgQzeVli,sublabel=cWkSMnfqDbvrxdPOKpmtLhjgQzeVio,img=cWkSMnfqDbvrxdPOKpmtLhjgQzeVlC,infoLabels=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFl,isFolder=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFi,params=cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw)
  xbmcplugin.setContent(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF._addon_handle,'movies')
  xbmcplugin.endOfDirectory(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF._addon_handle,cacheToDisc=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFi)
  if args.get('historyyn')=='Y':cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.Save_Searched_List(cWkSMnfqDbvrxdPOKpmtLhjgQzeVoJ)
 def Load_List_File(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF,cWkSMnfqDbvrxdPOKpmtLhjgQzeVoE): 
  try:
   if cWkSMnfqDbvrxdPOKpmtLhjgQzeVoE=='search':
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVoN=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGX
   elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVoE in['tvshow','movie']:
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVoN=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%cWkSMnfqDbvrxdPOKpmtLhjgQzeVoE))
   else:
    return[]
   fp=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFT(cWkSMnfqDbvrxdPOKpmtLhjgQzeVoN,'r',-1,'utf-8')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVoY=fp.readlines()
   fp.close()
  except:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVoY=[]
  return cWkSMnfqDbvrxdPOKpmtLhjgQzeVoY
 def Save_Watched_List(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF,cWkSMnfqDbvrxdPOKpmtLhjgQzeVoE,cWkSMnfqDbvrxdPOKpmtLhjgQzeVGw):
  try:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVoB=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%cWkSMnfqDbvrxdPOKpmtLhjgQzeVoE))
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVoU=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.Load_List_File(cWkSMnfqDbvrxdPOKpmtLhjgQzeVoE) 
   fp=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFT(cWkSMnfqDbvrxdPOKpmtLhjgQzeVoB,'w',-1,'utf-8')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVoI=urllib.parse.urlencode(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGw)
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVoI=cWkSMnfqDbvrxdPOKpmtLhjgQzeVoI+'\n'
   fp.write(cWkSMnfqDbvrxdPOKpmtLhjgQzeVoI)
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVXG=0
   for cWkSMnfqDbvrxdPOKpmtLhjgQzeVXl in cWkSMnfqDbvrxdPOKpmtLhjgQzeVoU:
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVXu=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFX(urllib.parse.parse_qsl(cWkSMnfqDbvrxdPOKpmtLhjgQzeVXl))
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVXi=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGw.get('code').strip()
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVXo=cWkSMnfqDbvrxdPOKpmtLhjgQzeVXu.get('code').strip()
    if cWkSMnfqDbvrxdPOKpmtLhjgQzeVXi!=cWkSMnfqDbvrxdPOKpmtLhjgQzeVXo:
     fp.write(cWkSMnfqDbvrxdPOKpmtLhjgQzeVXl)
     cWkSMnfqDbvrxdPOKpmtLhjgQzeVXG+=1
     if cWkSMnfqDbvrxdPOKpmtLhjgQzeVXG>=50:break
   fp.close()
  except:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVFl
 def Save_Searched_List(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF,cWkSMnfqDbvrxdPOKpmtLhjgQzeVoJ):
  try:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVoJ=cWkSMnfqDbvrxdPOKpmtLhjgQzeVoJ.strip()
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVoU=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.Load_List_File('search') 
   fp=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFT(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGX,'w',-1,'utf-8')
   fp.write(cWkSMnfqDbvrxdPOKpmtLhjgQzeVoJ+'\n')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVXG=0
   for cWkSMnfqDbvrxdPOKpmtLhjgQzeVXl in cWkSMnfqDbvrxdPOKpmtLhjgQzeVoU:
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVXl=cWkSMnfqDbvrxdPOKpmtLhjgQzeVXl.strip()
    if cWkSMnfqDbvrxdPOKpmtLhjgQzeVoJ!=cWkSMnfqDbvrxdPOKpmtLhjgQzeVXl:
     fp.write(cWkSMnfqDbvrxdPOKpmtLhjgQzeVXl+'\n')
     cWkSMnfqDbvrxdPOKpmtLhjgQzeVXG+=1
     if cWkSMnfqDbvrxdPOKpmtLhjgQzeVXG>=50:break
   fp.close()
  except:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVFl
 def dp_Search_History(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF,args):
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVXF=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.Load_List_File('search')
  for cWkSMnfqDbvrxdPOKpmtLhjgQzeVXa in cWkSMnfqDbvrxdPOKpmtLhjgQzeVXF:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVXa=cWkSMnfqDbvrxdPOKpmtLhjgQzeVXa.strip()
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw={'mode':'LOCAL_SEARCH','search_key':cWkSMnfqDbvrxdPOKpmtLhjgQzeVXa,'page':'1','historyyn':'Y',}
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVXC={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','skey':cWkSMnfqDbvrxdPOKpmtLhjgQzeVXa,'vType':'-',}
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVXw=urllib.parse.urlencode(cWkSMnfqDbvrxdPOKpmtLhjgQzeVXC)
   cWkSMnfqDbvrxdPOKpmtLhjgQzeViu=[('선택된 검색어 ( %s ) 삭제'%(cWkSMnfqDbvrxdPOKpmtLhjgQzeVXa),'RunPlugin(plugin://plugin.video.coupangm/?%s)'%(cWkSMnfqDbvrxdPOKpmtLhjgQzeVXw))]
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.add_dir(cWkSMnfqDbvrxdPOKpmtLhjgQzeVXa,sublabel='',img=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFl,infoLabels=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFl,isFolder=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFi,params=cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw,ContextMenu=cWkSMnfqDbvrxdPOKpmtLhjgQzeViu)
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVuX={'plot':'검색목록 전체를 삭제합니다.'}
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVli='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVlC=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.add_dir(cWkSMnfqDbvrxdPOKpmtLhjgQzeVli,sublabel='',img=cWkSMnfqDbvrxdPOKpmtLhjgQzeVlC,infoLabels=cWkSMnfqDbvrxdPOKpmtLhjgQzeVuX,isFolder=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu,params=cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw,isLink=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFi)
  xbmcplugin.endOfDirectory(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF._addon_handle,cacheToDisc=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu)
 def dp_Listfile_Delete(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF,args):
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVXT=args.get('delType')
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVXs =args.get('skey')
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVuG =args.get('vType')
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVGs=xbmcgui.Dialog()
  if cWkSMnfqDbvrxdPOKpmtLhjgQzeVXT=='SEARCH_ALL':
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVlH=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGs.yesno(__language__(30911).encode('utf8'),__language__(30906).encode('utf8'))
  elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVXT=='SEARCH_ONE':
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVlH=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGs.yesno(__language__(30912).encode('utf8'),__language__(30906).encode('utf8'))
  elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVXT=='WATCH_ALL':
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVlH=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGs.yesno(__language__(30913).encode('utf8'),__language__(30906).encode('utf8'))
  elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVXT=='WATCH_ONE':
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVlH=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGs.yesno(__language__(30916).encode('utf8'),__language__(30906).encode('utf8'))
  if cWkSMnfqDbvrxdPOKpmtLhjgQzeVlH==cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu:sys.exit()
  if cWkSMnfqDbvrxdPOKpmtLhjgQzeVXT=='SEARCH_ALL':
   if os.path.isfile(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGX):os.remove(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGX)
  elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVXT=='SEARCH_ONE':
   try:
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVoN=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGX
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVoU=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.Load_List_File('search') 
    fp=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFT(cWkSMnfqDbvrxdPOKpmtLhjgQzeVoN,'w',-1,'utf-8')
    for cWkSMnfqDbvrxdPOKpmtLhjgQzeVXl in cWkSMnfqDbvrxdPOKpmtLhjgQzeVoU:
     if cWkSMnfqDbvrxdPOKpmtLhjgQzeVXs!=cWkSMnfqDbvrxdPOKpmtLhjgQzeVXl.strip():
      fp.write(cWkSMnfqDbvrxdPOKpmtLhjgQzeVXl)
    fp.close()
   except:
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVFl
  elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVXT=='WATCH_ALL':
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVoN=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%cWkSMnfqDbvrxdPOKpmtLhjgQzeVuG))
   if os.path.isfile(cWkSMnfqDbvrxdPOKpmtLhjgQzeVoN):os.remove(cWkSMnfqDbvrxdPOKpmtLhjgQzeVoN)
  elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVXT=='WATCH_ONE':
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVoN=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%cWkSMnfqDbvrxdPOKpmtLhjgQzeVuG))
   try:
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVoU=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.Load_List_File(cWkSMnfqDbvrxdPOKpmtLhjgQzeVuG) 
    fp=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFT(cWkSMnfqDbvrxdPOKpmtLhjgQzeVoN,'w',-1,'utf-8')
    for cWkSMnfqDbvrxdPOKpmtLhjgQzeVXl in cWkSMnfqDbvrxdPOKpmtLhjgQzeVoU:
     cWkSMnfqDbvrxdPOKpmtLhjgQzeVXu=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFX(urllib.parse.parse_qsl(cWkSMnfqDbvrxdPOKpmtLhjgQzeVXl))
     cWkSMnfqDbvrxdPOKpmtLhjgQzeVXy=cWkSMnfqDbvrxdPOKpmtLhjgQzeVXu.get('code').strip()
     if cWkSMnfqDbvrxdPOKpmtLhjgQzeVXs!=cWkSMnfqDbvrxdPOKpmtLhjgQzeVXy:
      fp.write(cWkSMnfqDbvrxdPOKpmtLhjgQzeVXl)
    fp.close()
   except:
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVFl
  xbmc.executebuiltin("Container.Refresh")
 def Delete_List_File(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF,cWkSMnfqDbvrxdPOKpmtLhjgQzeVoE,skey='-'):
  if cWkSMnfqDbvrxdPOKpmtLhjgQzeVoE=='ALL':
   try:
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVoN=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGX
    fp=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFT(cWkSMnfqDbvrxdPOKpmtLhjgQzeVoN,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVFl
  elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVoE=='ONE':
   try:
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVoN=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGX
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVoU=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.Load_List_File('search') 
    fp=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFT(cWkSMnfqDbvrxdPOKpmtLhjgQzeVoN,'w',-1,'utf-8')
    for cWkSMnfqDbvrxdPOKpmtLhjgQzeVXl in cWkSMnfqDbvrxdPOKpmtLhjgQzeVoU:
     if skey!=cWkSMnfqDbvrxdPOKpmtLhjgQzeVXl.strip():
      fp.write(cWkSMnfqDbvrxdPOKpmtLhjgQzeVXl)
    fp.close()
   except:
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVFl
  elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVoE in['tvshow','movie']:
   try:
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVoN=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%cWkSMnfqDbvrxdPOKpmtLhjgQzeVoE))
    fp=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFT(cWkSMnfqDbvrxdPOKpmtLhjgQzeVoN,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVFl
 def dp_Watch_List(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF,args):
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVoE =args.get('stype')
  if cWkSMnfqDbvrxdPOKpmtLhjgQzeVoE in['',cWkSMnfqDbvrxdPOKpmtLhjgQzeVFl]:
   for cWkSMnfqDbvrxdPOKpmtLhjgQzeVXE in cWkSMnfqDbvrxdPOKpmtLhjgQzeVGi:
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVli=cWkSMnfqDbvrxdPOKpmtLhjgQzeVXE.get('title')
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw={'mode':cWkSMnfqDbvrxdPOKpmtLhjgQzeVXE.get('mode'),'stype':cWkSMnfqDbvrxdPOKpmtLhjgQzeVXE.get('stype'),}
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.add_dir(cWkSMnfqDbvrxdPOKpmtLhjgQzeVli,sublabel='',img='',infoLabels=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFl,isFolder=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFi,params=cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw)
   xbmcplugin.endOfDirectory(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF._addon_handle)
  else:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVXH=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.Load_List_File(cWkSMnfqDbvrxdPOKpmtLhjgQzeVoE)
   for cWkSMnfqDbvrxdPOKpmtLhjgQzeVXJ in cWkSMnfqDbvrxdPOKpmtLhjgQzeVXH:
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVXR=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFX(urllib.parse.parse_qsl(cWkSMnfqDbvrxdPOKpmtLhjgQzeVXJ))
    cWkSMnfqDbvrxdPOKpmtLhjgQzeViN =cWkSMnfqDbvrxdPOKpmtLhjgQzeVXR.get('code').strip()
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVli =cWkSMnfqDbvrxdPOKpmtLhjgQzeVXR.get('title').strip()
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVuC =cWkSMnfqDbvrxdPOKpmtLhjgQzeVXR.get('img').strip()
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw =cWkSMnfqDbvrxdPOKpmtLhjgQzeVXR.get('asis').strip()
    try:
     cWkSMnfqDbvrxdPOKpmtLhjgQzeVuC=cWkSMnfqDbvrxdPOKpmtLhjgQzeVuC.replace('\'','\"')
     cWkSMnfqDbvrxdPOKpmtLhjgQzeVuC=json.loads(cWkSMnfqDbvrxdPOKpmtLhjgQzeVuC)
    except:
     cWkSMnfqDbvrxdPOKpmtLhjgQzeVFl
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVuX={}
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVuX['plot']=cWkSMnfqDbvrxdPOKpmtLhjgQzeVli
    if cWkSMnfqDbvrxdPOKpmtLhjgQzeVoE=='movie':
     cWkSMnfqDbvrxdPOKpmtLhjgQzeVuX['mediatype']='movie'
     cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw={'mode':'MOVIE','id':cWkSMnfqDbvrxdPOKpmtLhjgQzeViN,'asis':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw,'title':cWkSMnfqDbvrxdPOKpmtLhjgQzeVli,'thumbnail':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuC,}
     cWkSMnfqDbvrxdPOKpmtLhjgQzeVlT=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu
    else:
     cWkSMnfqDbvrxdPOKpmtLhjgQzeVuX['mediatype']='episode'
     cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw={'mode':'SEASON_LIST','id':cWkSMnfqDbvrxdPOKpmtLhjgQzeViN,'asis':cWkSMnfqDbvrxdPOKpmtLhjgQzeVuw,'title':cWkSMnfqDbvrxdPOKpmtLhjgQzeVli,'thumbnail':json.dumps(cWkSMnfqDbvrxdPOKpmtLhjgQzeVuC,separators=(',',':')),}
     cWkSMnfqDbvrxdPOKpmtLhjgQzeVlT=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFi
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVXC={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','skey':cWkSMnfqDbvrxdPOKpmtLhjgQzeViN,'vType':cWkSMnfqDbvrxdPOKpmtLhjgQzeVoE,}
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVXw=urllib.parse.urlencode(cWkSMnfqDbvrxdPOKpmtLhjgQzeVXC)
    cWkSMnfqDbvrxdPOKpmtLhjgQzeViu=[('선택된 시청이력 ( %s ) 삭제'%(cWkSMnfqDbvrxdPOKpmtLhjgQzeVli),'RunPlugin(plugin://plugin.video.coupangm/?%s)'%(cWkSMnfqDbvrxdPOKpmtLhjgQzeVXw))]
    cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.add_dir(cWkSMnfqDbvrxdPOKpmtLhjgQzeVli,sublabel='',img=cWkSMnfqDbvrxdPOKpmtLhjgQzeVuC,infoLabels=cWkSMnfqDbvrxdPOKpmtLhjgQzeVuX,isFolder=cWkSMnfqDbvrxdPOKpmtLhjgQzeVlT,params=cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw,ContextMenu=cWkSMnfqDbvrxdPOKpmtLhjgQzeViu)
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVuX={'plot':'시청목록을 삭제합니다.'}
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVli='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':cWkSMnfqDbvrxdPOKpmtLhjgQzeVoE,}
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVlC=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.add_dir(cWkSMnfqDbvrxdPOKpmtLhjgQzeVli,sublabel='',img=cWkSMnfqDbvrxdPOKpmtLhjgQzeVlC,infoLabels=cWkSMnfqDbvrxdPOKpmtLhjgQzeVuX,isFolder=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu,params=cWkSMnfqDbvrxdPOKpmtLhjgQzeVlw,isLink=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFi)
   if cWkSMnfqDbvrxdPOKpmtLhjgQzeVoE=='movie':xbmcplugin.setContent(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF._addon_handle,'movies')
   else:xbmcplugin.setContent(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF._addon_handle,cacheToDisc=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu)
 def dp_Set_Bookmark(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF,args):
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVXA=urllib.parse.unquote(args.get('bm_param'))
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVXA=json.loads(cWkSMnfqDbvrxdPOKpmtLhjgQzeVXA)
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVXN =cWkSMnfqDbvrxdPOKpmtLhjgQzeVXA.get('videoid')
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVXY =cWkSMnfqDbvrxdPOKpmtLhjgQzeVXA.get('vidtype')
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVXB =cWkSMnfqDbvrxdPOKpmtLhjgQzeVXA.get('vtitle')
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVGs=xbmcgui.Dialog()
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVlH=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGs.yesno(__language__(30914).encode('utf8'),cWkSMnfqDbvrxdPOKpmtLhjgQzeVXB+' \n\n'+__language__(30915))
  if cWkSMnfqDbvrxdPOKpmtLhjgQzeVlH==cWkSMnfqDbvrxdPOKpmtLhjgQzeVFu:return
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVXU=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.GetBookmarkInfo(cWkSMnfqDbvrxdPOKpmtLhjgQzeVXN,cWkSMnfqDbvrxdPOKpmtLhjgQzeVXY)
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVXI=json.dumps(cWkSMnfqDbvrxdPOKpmtLhjgQzeVXU)
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVXI=urllib.parse.quote(cWkSMnfqDbvrxdPOKpmtLhjgQzeVXI)
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVil ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(cWkSMnfqDbvrxdPOKpmtLhjgQzeVXI)
  xbmc.executebuiltin(cWkSMnfqDbvrxdPOKpmtLhjgQzeVil)
 def coupang_main(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF):
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CoupangObj.KodiVersion=cWkSMnfqDbvrxdPOKpmtLhjgQzeVFC(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVuU=cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.main_params.get('mode',cWkSMnfqDbvrxdPOKpmtLhjgQzeVFl)
  if cWkSMnfqDbvrxdPOKpmtLhjgQzeVuU=='LOGOUT':
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.CP_logout()
   return
  cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.option_check()
  if cWkSMnfqDbvrxdPOKpmtLhjgQzeVuU is cWkSMnfqDbvrxdPOKpmtLhjgQzeVFl:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.dp_Main_List(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.main_params)
  elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVuU=='CATEGORY_GROUPLIST':
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.dp_Category_GroupList(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.main_params)
  elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVuU=='THEME_GROUPLIST':
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.dp_Theme_GroupList(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.main_params)
  elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVuU=='EVENT_GROUPLIST':
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.dp_Event_GroupList(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.main_params)
  elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVuU=='EVENT_GAMELIST':
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.dp_Event_GameList(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.main_params)
  elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVuU=='EVENT_LIST':
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.dp_Event_List(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.main_params)
  elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVuU=='CATEGORY_LIST':
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.dp_Category_List(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.main_params)
  elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVuU=='SEASON_LIST':
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.dp_Season_List(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.main_params)
  elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVuU=='EPISODE_LIST':
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.dp_Episode_List(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.main_params)
  elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVuU=='TEST':
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.dp_Test(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.main_params)
  elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVuU in['MOVIE','VOD','HIGHLIGHT','LIVE']:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.play_VIDEO(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.main_params)
  elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVuU=='WATCH':
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.dp_Watch_List(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.main_params)
  elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVuU=='LOCAL_SEARCH':
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.dp_Search_List(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.main_params)
  elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVuU=='SEARCH_HISTORY':
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.dp_Search_History(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.main_params)
  elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVuU in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.dp_Listfile_Delete(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.main_params)
  elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVuU in['TOTAL_SEARCH','TOTAL_HISTORY']:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.dp_Global_Search(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.main_params)
  elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVuU=='MENU_BOOKMARK':
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.dp_Bookmark_Menu(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.main_params)
  elif cWkSMnfqDbvrxdPOKpmtLhjgQzeVuU=='SET_BOOKMARK':
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.dp_Set_Bookmark(cWkSMnfqDbvrxdPOKpmtLhjgQzeVGF.main_params)
  else:
   cWkSMnfqDbvrxdPOKpmtLhjgQzeVFl
# Created by pyminifier (https://github.com/liftoff/pyminifier)
