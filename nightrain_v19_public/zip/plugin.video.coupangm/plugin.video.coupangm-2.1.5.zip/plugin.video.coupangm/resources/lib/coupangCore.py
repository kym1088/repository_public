__author__="NightRain"
cxqyGFuLAMzshrIBJHkfgRwQjdTeom=object
cxqyGFuLAMzshrIBJHkfgRwQjdTeon=None
cxqyGFuLAMzshrIBJHkfgRwQjdTeoK=False
cxqyGFuLAMzshrIBJHkfgRwQjdTeol=print
cxqyGFuLAMzshrIBJHkfgRwQjdTeoE=str
cxqyGFuLAMzshrIBJHkfgRwQjdTeop=open
cxqyGFuLAMzshrIBJHkfgRwQjdTeoN=int
cxqyGFuLAMzshrIBJHkfgRwQjdTeVU=Exception
cxqyGFuLAMzshrIBJHkfgRwQjdTeVX=len
cxqyGFuLAMzshrIBJHkfgRwQjdTeVD=id
cxqyGFuLAMzshrIBJHkfgRwQjdTeVo=True
cxqyGFuLAMzshrIBJHkfgRwQjdTeVS=range
import urllib
import re
import json
import requests
import datetime
import time
import random
import base64
class cxqyGFuLAMzshrIBJHkfgRwQjdTeUX(cxqyGFuLAMzshrIBJHkfgRwQjdTeom):
 def __init__(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD):
  cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
  cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.MODEL ='Chrome_124' 
  cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.OS_VERSION ='124' 
  cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.DEFAULT_HEADER ={'user-agent':cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.USER_AGENT}
  cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.API_DOMAIN ='https://www.coupangplay.com'
  cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.API_VIEWURL ='https://discover.coupangstreaming.com'
  cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.PAGE_LIMIT =40
  cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.SEARCH_LIMIT =20
  cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.KodiVersion =20
  cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP={}
  cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.Init_CP()
  cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP_DEVICE_FILENAME=''
  cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP_COOKIE_FILENAME=''
 def callRequestCookies(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD,jobtype,cxqyGFuLAMzshrIBJHkfgRwQjdTeXW,payload=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,params=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,headers=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,cookies=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,redirects=cxqyGFuLAMzshrIBJHkfgRwQjdTeoK):
  cxqyGFuLAMzshrIBJHkfgRwQjdTeUo=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.DEFAULT_HEADER
  if headers:cxqyGFuLAMzshrIBJHkfgRwQjdTeUo.update(headers)
  if jobtype=='Get':
   cxqyGFuLAMzshrIBJHkfgRwQjdTeUV=requests.get(cxqyGFuLAMzshrIBJHkfgRwQjdTeXW,params=params,headers=cxqyGFuLAMzshrIBJHkfgRwQjdTeUo,cookies=cookies,allow_redirects=redirects)
  else:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeUV=requests.post(cxqyGFuLAMzshrIBJHkfgRwQjdTeXW,data=payload,params=params,headers=cxqyGFuLAMzshrIBJHkfgRwQjdTeUo,cookies=cookies,allow_redirects=redirects)
  cxqyGFuLAMzshrIBJHkfgRwQjdTeol(cxqyGFuLAMzshrIBJHkfgRwQjdTeoE(cxqyGFuLAMzshrIBJHkfgRwQjdTeUV.status_code)+' - '+cxqyGFuLAMzshrIBJHkfgRwQjdTeoE(cxqyGFuLAMzshrIBJHkfgRwQjdTeUV.url))
  return cxqyGFuLAMzshrIBJHkfgRwQjdTeUV
 def callRequestCookies_test(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD,jobtype,cxqyGFuLAMzshrIBJHkfgRwQjdTeXW,payload=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,params=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,headers=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,cookies=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,redirects=cxqyGFuLAMzshrIBJHkfgRwQjdTeoK):
  cxqyGFuLAMzshrIBJHkfgRwQjdTeUo=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.DEFAULT_HEADER
  if headers:cxqyGFuLAMzshrIBJHkfgRwQjdTeUo.update(headers)
  cxqyGFuLAMzshrIBJHkfgRwQjdTeUV=requests.Request('POST',cxqyGFuLAMzshrIBJHkfgRwQjdTeXW,headers=headers,data=payload,params=params,cookies=cookies)
  cxqyGFuLAMzshrIBJHkfgRwQjdTeUS=cxqyGFuLAMzshrIBJHkfgRwQjdTeUV.prepare()
  cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.pretty_print_POST(cxqyGFuLAMzshrIBJHkfgRwQjdTeUS)
  return cxqyGFuLAMzshrIBJHkfgRwQjdTeUV
 def pretty_print_POST(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD,req):
  cxqyGFuLAMzshrIBJHkfgRwQjdTeol('{}\n{}\r\n{}\r\n\r\n{}'.format('-----------START-----------',req.method+' '+req.url,'\r\n'.join('{}: {}'.format(k,v)for k,v in req.headers.items()),req.body,))
 def dic_To_jsonfile(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD,filename,cxqyGFuLAMzshrIBJHkfgRwQjdTeUC):
  if filename=='':return
  fp=cxqyGFuLAMzshrIBJHkfgRwQjdTeop(filename,'w',-1,'utf-8')
  json.dump(cxqyGFuLAMzshrIBJHkfgRwQjdTeUC,fp,indent=4,ensure_ascii=cxqyGFuLAMzshrIBJHkfgRwQjdTeoK)
  fp.close()
 def jsonfile_To_dic(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD,filename):
  if filename=='':return cxqyGFuLAMzshrIBJHkfgRwQjdTeon
  try:
   fp=cxqyGFuLAMzshrIBJHkfgRwQjdTeop(filename,'r',-1,'utf-8')
   cxqyGFuLAMzshrIBJHkfgRwQjdTeUW=json.load(fp)
   fp.close()
  except:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeUW={}
  return cxqyGFuLAMzshrIBJHkfgRwQjdTeUW
 def convert_TimeStr(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD,cxqyGFuLAMzshrIBJHkfgRwQjdTeUv):
  try:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeUv =cxqyGFuLAMzshrIBJHkfgRwQjdTeUv[0:16]
   cxqyGFuLAMzshrIBJHkfgRwQjdTeUO=datetime.datetime.strptime(cxqyGFuLAMzshrIBJHkfgRwQjdTeUv,'%Y-%m-%dT%H:%M')+datetime.timedelta(hours=9)
   return cxqyGFuLAMzshrIBJHkfgRwQjdTeUO.strftime('%Y-%m-%d %H:%M')
  except:
   return cxqyGFuLAMzshrIBJHkfgRwQjdTeon
 def Get_Now_Datetime(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetNoCache(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD):
  cxqyGFuLAMzshrIBJHkfgRwQjdTeUt =cxqyGFuLAMzshrIBJHkfgRwQjdTeoN(time.time()*1000)
  return cxqyGFuLAMzshrIBJHkfgRwQjdTeUt
 def generatePcId(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD):
  t=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.GetNoCache()
  r=random.random()
  cxqyGFuLAMzshrIBJHkfgRwQjdTeUP=cxqyGFuLAMzshrIBJHkfgRwQjdTeoE(t)+cxqyGFuLAMzshrIBJHkfgRwQjdTeoE(r)[2:12]
  return cxqyGFuLAMzshrIBJHkfgRwQjdTeUP
 def generatePvId(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD,genType='1'):
  import hashlib
  m=hashlib.md5()
  cxqyGFuLAMzshrIBJHkfgRwQjdTeUa=cxqyGFuLAMzshrIBJHkfgRwQjdTeoE(random.random())
  m.update(cxqyGFuLAMzshrIBJHkfgRwQjdTeUa.encode('utf-8'))
  cxqyGFuLAMzshrIBJHkfgRwQjdTeUY=cxqyGFuLAMzshrIBJHkfgRwQjdTeoE(m.hexdigest())
  if genType=='1':
   return '%s-%s-%s-%s-%s'%(cxqyGFuLAMzshrIBJHkfgRwQjdTeUY[:8],cxqyGFuLAMzshrIBJHkfgRwQjdTeUY[8:12],cxqyGFuLAMzshrIBJHkfgRwQjdTeUY[12:16],cxqyGFuLAMzshrIBJHkfgRwQjdTeUY[16:20],cxqyGFuLAMzshrIBJHkfgRwQjdTeUY[20:])
  else:
   return cxqyGFuLAMzshrIBJHkfgRwQjdTeUY
 def Get_DeviceID(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD):
  cxqyGFuLAMzshrIBJHkfgRwQjdTeUm=''
  try: 
   fp=cxqyGFuLAMzshrIBJHkfgRwQjdTeop(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP_DEVICE_FILENAME,'r',-1,'utf-8')
   cxqyGFuLAMzshrIBJHkfgRwQjdTeUn= json.load(fp)
   fp.close()
   cxqyGFuLAMzshrIBJHkfgRwQjdTeUm=cxqyGFuLAMzshrIBJHkfgRwQjdTeUn.get('device_id')
  except cxqyGFuLAMzshrIBJHkfgRwQjdTeVU as exception:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeon
  if cxqyGFuLAMzshrIBJHkfgRwQjdTeUm=='':
   cxqyGFuLAMzshrIBJHkfgRwQjdTeUm=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.generatePvId(genType='1')
   try: 
    fp=cxqyGFuLAMzshrIBJHkfgRwQjdTeop(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP_DEVICE_FILENAME,'w',-1,'utf-8')
    json.dump({'device_id':cxqyGFuLAMzshrIBJHkfgRwQjdTeUm},fp,indent=4,ensure_ascii=cxqyGFuLAMzshrIBJHkfgRwQjdTeoK)
    fp.close()
   except cxqyGFuLAMzshrIBJHkfgRwQjdTeVU as exception:
    return ''
  return cxqyGFuLAMzshrIBJHkfgRwQjdTeUm
 def make_stream_header(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD,cxqyGFuLAMzshrIBJHkfgRwQjdTeUN,cxqyGFuLAMzshrIBJHkfgRwQjdTeXv):
  cxqyGFuLAMzshrIBJHkfgRwQjdTeUK=''
  if cxqyGFuLAMzshrIBJHkfgRwQjdTeXv not in[{},cxqyGFuLAMzshrIBJHkfgRwQjdTeon,'']:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeUl=cxqyGFuLAMzshrIBJHkfgRwQjdTeVX(cxqyGFuLAMzshrIBJHkfgRwQjdTeXv)
   for cxqyGFuLAMzshrIBJHkfgRwQjdTeUE,cxqyGFuLAMzshrIBJHkfgRwQjdTeUp in cxqyGFuLAMzshrIBJHkfgRwQjdTeXv.items():
    cxqyGFuLAMzshrIBJHkfgRwQjdTeUK+='{}={}'.format(cxqyGFuLAMzshrIBJHkfgRwQjdTeUE,cxqyGFuLAMzshrIBJHkfgRwQjdTeUp)
    cxqyGFuLAMzshrIBJHkfgRwQjdTeUl+=-1
    if cxqyGFuLAMzshrIBJHkfgRwQjdTeUl>0:cxqyGFuLAMzshrIBJHkfgRwQjdTeUK+='; '
   cxqyGFuLAMzshrIBJHkfgRwQjdTeUN['cookie']=cxqyGFuLAMzshrIBJHkfgRwQjdTeUK
  cxqyGFuLAMzshrIBJHkfgRwQjdTeXU=''
  i=0
  for cxqyGFuLAMzshrIBJHkfgRwQjdTeUE,cxqyGFuLAMzshrIBJHkfgRwQjdTeUp in cxqyGFuLAMzshrIBJHkfgRwQjdTeUN.items():
   i=i+1
   if i>1:cxqyGFuLAMzshrIBJHkfgRwQjdTeXU+='&'
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXU+='{}={}'.format(cxqyGFuLAMzshrIBJHkfgRwQjdTeUE,urllib.parse.quote(cxqyGFuLAMzshrIBJHkfgRwQjdTeUp))
  return cxqyGFuLAMzshrIBJHkfgRwQjdTeXU
 def Make_authHeader(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD):
  tr=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.generatePvId(genType=2)
  ti=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.GetNoCache()
  cxqyGFuLAMzshrIBJHkfgRwQjdTeVD=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.generatePvId(genType=2)[:16]
  cxqyGFuLAMzshrIBJHkfgRwQjdTeXD='00-%s-%s-01'%(tr,cxqyGFuLAMzshrIBJHkfgRwQjdTeVD,)
  cxqyGFuLAMzshrIBJHkfgRwQjdTeXo ='%s@nr=0-1-%s-%s-%s----%s'%(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['SESSION']['NREUM']['tk'],cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['SESSION']['NREUM']['ac'],cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['SESSION']['NREUM']['ap'],cxqyGFuLAMzshrIBJHkfgRwQjdTeVD,ti,)
  cxqyGFuLAMzshrIBJHkfgRwQjdTeXV ='{"v":[0,1],"d":{"ty":"Browser","ac":"%s","ap":"%s","id":"%s","tr":"%s","ti":%s,"tk":"%s"}}'%(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['SESSION']['NREUM']['ac'],cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['SESSION']['NREUM']['ap'],cxqyGFuLAMzshrIBJHkfgRwQjdTeVD,tr,ti,cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['SESSION']['NREUM']['tk'],) 
  return cxqyGFuLAMzshrIBJHkfgRwQjdTeXD,cxqyGFuLAMzshrIBJHkfgRwQjdTeXo,base64.standard_b64encode(cxqyGFuLAMzshrIBJHkfgRwQjdTeXV.encode()).decode('utf-8')
 def Init_CP(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD):
  cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP={}
  cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['ACCOUNT']={'cpid':'','cppw':'','cppf':'0'}
  cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['SESSION']={}
  cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['COOKIES']={}
 def Save_session_acount(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD,cxqyGFuLAMzshrIBJHkfgRwQjdTeXS,cxqyGFuLAMzshrIBJHkfgRwQjdTeXC,cxqyGFuLAMzshrIBJHkfgRwQjdTeXi):
  cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['ACCOUNT']['cpid']=base64.standard_b64encode(cxqyGFuLAMzshrIBJHkfgRwQjdTeXS.encode()).decode('utf-8')
  cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['ACCOUNT']['cppw']=base64.standard_b64encode(cxqyGFuLAMzshrIBJHkfgRwQjdTeXC.encode()).decode('utf-8')
  cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['ACCOUNT']['cppf']=cxqyGFuLAMzshrIBJHkfgRwQjdTeoE(cxqyGFuLAMzshrIBJHkfgRwQjdTeXi)
 def Load_session_acount(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD):
  cxqyGFuLAMzshrIBJHkfgRwQjdTeXS=base64.standard_b64decode(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['ACCOUNT']['cpid']).decode('utf-8')
  cxqyGFuLAMzshrIBJHkfgRwQjdTeXC=base64.standard_b64decode(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['ACCOUNT']['cppw']).decode('utf-8')
  cxqyGFuLAMzshrIBJHkfgRwQjdTeXi=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['ACCOUNT']['cppf']
  return cxqyGFuLAMzshrIBJHkfgRwQjdTeXS,cxqyGFuLAMzshrIBJHkfgRwQjdTeXC,cxqyGFuLAMzshrIBJHkfgRwQjdTeXi
 def make_CP_DefaultCookies(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD):
  return cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['COOKIES']
 def Get_CP_Login(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD,userid,userpw,cxqyGFuLAMzshrIBJHkfgRwQjdTeXK):
  try:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXW=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.API_DOMAIN
   cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['COOKIES']['NEXT_LOCALE']='ko'
   cxqyGFuLAMzshrIBJHkfgRwQjdTeUN={'Accept-Language':'ko-KR,ko;q=0.9','Sec-Ch-Ua-Mobile':'?0','Sec-Ch-Ua-Platform':'"Windows"','Sec-Fetch-Dest':'document','Sec-Fetch-Mode':'navigate','Sec-Fetch-Site':'none','Sec-Fetch-User':'?1','Upgrade-Insecure-Requests':'1',}
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXv=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.make_CP_DefaultCookies()
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXO=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.callRequestCookies('Get',cxqyGFuLAMzshrIBJHkfgRwQjdTeXW,payload=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,params=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,headers=cxqyGFuLAMzshrIBJHkfgRwQjdTeUN,cookies=cxqyGFuLAMzshrIBJHkfgRwQjdTeXv,redirects=cxqyGFuLAMzshrIBJHkfgRwQjdTeVo)
   if cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.status_code not in[200]:return cxqyGFuLAMzshrIBJHkfgRwQjdTeoK
   for cxqyGFuLAMzshrIBJHkfgRwQjdTeXb in cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.cookies:
    cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['COOKIES'][cxqyGFuLAMzshrIBJHkfgRwQjdTeXb.name]=cxqyGFuLAMzshrIBJHkfgRwQjdTeXb.value
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXv=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.make_CP_DefaultCookies()
   if cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.status_code not in[200]:return cxqyGFuLAMzshrIBJHkfgRwQjdTeoK
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXt=re.findall('NREUM.loader_config=\{[\w\d\":,-]+\}',cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.text)[0].split('=')[1]
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXt=cxqyGFuLAMzshrIBJHkfgRwQjdTeXt.replace('{','{"').replace(':','":').replace(',',',"')
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXt=json.loads(cxqyGFuLAMzshrIBJHkfgRwQjdTeXt)
   cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['SESSION']['NREUM']={'ac':cxqyGFuLAMzshrIBJHkfgRwQjdTeXt['accountID'],'tk':cxqyGFuLAMzshrIBJHkfgRwQjdTeXt['trustKey'],'ap':cxqyGFuLAMzshrIBJHkfgRwQjdTeXt['agentID'],'lk':cxqyGFuLAMzshrIBJHkfgRwQjdTeXt['licenseKey'],}
  except cxqyGFuLAMzshrIBJHkfgRwQjdTeVU as exception:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeol(exception)
   return cxqyGFuLAMzshrIBJHkfgRwQjdTeoK
  try:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXW=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.API_DOMAIN+'/api/auth'
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXP=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.Get_DeviceID()
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXa =cxqyGFuLAMzshrIBJHkfgRwQjdTeXP.split('-')[0]
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXD,cxqyGFuLAMzshrIBJHkfgRwQjdTeXo,cxqyGFuLAMzshrIBJHkfgRwQjdTeXV=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.Make_authHeader()
   cxqyGFuLAMzshrIBJHkfgRwQjdTeUN={'traceparent':cxqyGFuLAMzshrIBJHkfgRwQjdTeXD,'tracestate':cxqyGFuLAMzshrIBJHkfgRwQjdTeXo,'newrelic':cxqyGFuLAMzshrIBJHkfgRwQjdTeXV,'content-type':'application/json','x-app-version':'1.26.1','x-device-id':'','x-device-os-version':cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.OS_VERSION,'x-nr-session-id':cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['COOKIES']['session_web_id'],'x-pcid':'',}
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXY={'device':{'deviceId':'web-'+cxqyGFuLAMzshrIBJHkfgRwQjdTeXP,'model':cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.MODEL,'name':'Chrome Desktop '+cxqyGFuLAMzshrIBJHkfgRwQjdTeXa,'os':'Windows','osVersion':'10','type':'webclient',},'email':userid,'password':userpw,}
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXY=json.dumps(cxqyGFuLAMzshrIBJHkfgRwQjdTeXY,separators=(',',':'))
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXv=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.make_CP_DefaultCookies()
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXO=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.callRequestCookies('Post',cxqyGFuLAMzshrIBJHkfgRwQjdTeXW,payload=cxqyGFuLAMzshrIBJHkfgRwQjdTeXY,params=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,headers=cxqyGFuLAMzshrIBJHkfgRwQjdTeUN,cookies=cxqyGFuLAMzshrIBJHkfgRwQjdTeXv,redirects=cxqyGFuLAMzshrIBJHkfgRwQjdTeoK)
   if cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.status_code not in[200]:
    cxqyGFuLAMzshrIBJHkfgRwQjdTeXm=json.loads(cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.text)
    if 'error' in cxqyGFuLAMzshrIBJHkfgRwQjdTeXm:
     cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['SESSION']['error']=cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('error').get('detail')
    return cxqyGFuLAMzshrIBJHkfgRwQjdTeoK
   cxqyGFuLAMzshrIBJHkfgRwQjdTeol('---')
   for cxqyGFuLAMzshrIBJHkfgRwQjdTeXb in cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.cookies:
    cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['COOKIES'][cxqyGFuLAMzshrIBJHkfgRwQjdTeXb.name]=cxqyGFuLAMzshrIBJHkfgRwQjdTeXb.value
  except cxqyGFuLAMzshrIBJHkfgRwQjdTeVU as exception:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeol(exception)
   return cxqyGFuLAMzshrIBJHkfgRwQjdTeoK
  cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.Save_session_acount(userid,userpw,cxqyGFuLAMzshrIBJHkfgRwQjdTeXK)
  return cxqyGFuLAMzshrIBJHkfgRwQjdTeVo
 def Get_CP_profile(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD,cxqyGFuLAMzshrIBJHkfgRwQjdTeXK,limit_days=1,re_check=cxqyGFuLAMzshrIBJHkfgRwQjdTeoK):
  if re_check==cxqyGFuLAMzshrIBJHkfgRwQjdTeVo:
   if cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['SESSION']['bm_sv_ex']>cxqyGFuLAMzshrIBJHkfgRwQjdTeoN(time.time()):
    cxqyGFuLAMzshrIBJHkfgRwQjdTeol('bm_sv_ex ok')
    return cxqyGFuLAMzshrIBJHkfgRwQjdTeVo
  try:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXW=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.API_DOMAIN+'/api/profiles'
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXD,cxqyGFuLAMzshrIBJHkfgRwQjdTeXo,cxqyGFuLAMzshrIBJHkfgRwQjdTeXV=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.Make_authHeader()
   cxqyGFuLAMzshrIBJHkfgRwQjdTeUN={'traceparent':cxqyGFuLAMzshrIBJHkfgRwQjdTeXD,'tracestate':cxqyGFuLAMzshrIBJHkfgRwQjdTeXo,'newrelic':cxqyGFuLAMzshrIBJHkfgRwQjdTeXV,'x-app-version':'1.26.1','x-device-id':'','x-device-os-version':cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.OS_VERSION,'x-nr-session-id':cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['COOKIES']['session_web_id'],'x-pcid':'',}
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXv=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.make_CP_DefaultCookies()
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXO=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.callRequestCookies('Get',cxqyGFuLAMzshrIBJHkfgRwQjdTeXW,payload=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,params=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,headers=cxqyGFuLAMzshrIBJHkfgRwQjdTeUN,cookies=cxqyGFuLAMzshrIBJHkfgRwQjdTeXv,redirects=cxqyGFuLAMzshrIBJHkfgRwQjdTeVo)
   if cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.status_code not in[200]:return cxqyGFuLAMzshrIBJHkfgRwQjdTeoK
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXm=json.loads(cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.text)
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXn=0
   for cxqyGFuLAMzshrIBJHkfgRwQjdTeXb in cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.cookies:
    cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['COOKIES'][cxqyGFuLAMzshrIBJHkfgRwQjdTeXb.name]=cxqyGFuLAMzshrIBJHkfgRwQjdTeXb.value
    if cxqyGFuLAMzshrIBJHkfgRwQjdTeXb.name=='bm_sv':
     cxqyGFuLAMzshrIBJHkfgRwQjdTeXn=1
     cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['SESSION']['bm_sv_ex']=cxqyGFuLAMzshrIBJHkfgRwQjdTeXb.expires 
   if cxqyGFuLAMzshrIBJHkfgRwQjdTeXn==0:
    cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['SESSION']['bm_sv_ex']=cxqyGFuLAMzshrIBJHkfgRwQjdTeoN(time.time())+60*60*2 
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXK=cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('data')[cxqyGFuLAMzshrIBJHkfgRwQjdTeoN(cxqyGFuLAMzshrIBJHkfgRwQjdTeXK)]
   cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['SESSION']['accountId']=cxqyGFuLAMzshrIBJHkfgRwQjdTeXK.get('accountId')
   cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['SESSION']['profileId']=cxqyGFuLAMzshrIBJHkfgRwQjdTeXK.get('profileId')
  except cxqyGFuLAMzshrIBJHkfgRwQjdTeVU as exception:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeol(exception)
   return cxqyGFuLAMzshrIBJHkfgRwQjdTeoK
  if re_check==cxqyGFuLAMzshrIBJHkfgRwQjdTeoK:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXl =cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.Get_Now_Datetime()
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXE=cxqyGFuLAMzshrIBJHkfgRwQjdTeXl+datetime.timedelta(days=limit_days)
   cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['SESSION']['limitdate']=cxqyGFuLAMzshrIBJHkfgRwQjdTeXE.strftime('%Y-%m-%d')
  else:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeol('re check')
  cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.dic_To_jsonfile(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP_COOKIE_FILENAME,cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP)
  return cxqyGFuLAMzshrIBJHkfgRwQjdTeVo
 def Get_Category_GroupList(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD,vType):
  cxqyGFuLAMzshrIBJHkfgRwQjdTeXp=[] 
  try:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXW=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.API_VIEWURL+'/v2/discover/feed' 
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXN={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false',}
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXO=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.callRequestCookies('Get',cxqyGFuLAMzshrIBJHkfgRwQjdTeXW,payload=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,params=cxqyGFuLAMzshrIBJHkfgRwQjdTeXN,headers=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,cookies=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,redirects=cxqyGFuLAMzshrIBJHkfgRwQjdTeVo)
   if cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.status_code not in[200]:return[]
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXm=json.loads(cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.text)
   if vType in['TVSHOWS','MOVIES']:
    cxqyGFuLAMzshrIBJHkfgRwQjdTeDU='Explores' 
   elif vType in['EDUCATION']:
    cxqyGFuLAMzshrIBJHkfgRwQjdTeDU='Collection-Rails-Curation'
   elif vType in['ALL','KIDS']:
    cxqyGFuLAMzshrIBJHkfgRwQjdTeDU='Explores-Categories'
   for cxqyGFuLAMzshrIBJHkfgRwQjdTeDX in cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('data'):
    if cxqyGFuLAMzshrIBJHkfgRwQjdTeDX.get('type')==cxqyGFuLAMzshrIBJHkfgRwQjdTeDU:
     for cxqyGFuLAMzshrIBJHkfgRwQjdTeDo in cxqyGFuLAMzshrIBJHkfgRwQjdTeDX.get('data'):
      if vType in['TVSHOWS','MOVIES']:
       cxqyGFuLAMzshrIBJHkfgRwQjdTeDV=cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('collectionId')
      elif vType in['EDUCATION','ALL','KIDS']:
       cxqyGFuLAMzshrIBJHkfgRwQjdTeDV=cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('id')
      cxqyGFuLAMzshrIBJHkfgRwQjdTeDS={'collectionId':cxqyGFuLAMzshrIBJHkfgRwQjdTeDV,'title':cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('name'),'category':cxqyGFuLAMzshrIBJHkfgRwQjdTeDX.get('category'),'pre_title':'',}
      cxqyGFuLAMzshrIBJHkfgRwQjdTeXp.append(cxqyGFuLAMzshrIBJHkfgRwQjdTeDS)
     break
  except cxqyGFuLAMzshrIBJHkfgRwQjdTeVU as exception:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeol(exception)
   return[]
  return cxqyGFuLAMzshrIBJHkfgRwQjdTeXp
 def Get_Category_List(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD,vType,cxqyGFuLAMzshrIBJHkfgRwQjdTeDV,page_int):
  cxqyGFuLAMzshrIBJHkfgRwQjdTeXp=[] 
  cxqyGFuLAMzshrIBJHkfgRwQjdTeDC=cxqyGFuLAMzshrIBJHkfgRwQjdTeoK
  try:
   if vType in['ALL','KIDS']:
    cxqyGFuLAMzshrIBJHkfgRwQjdTeUN={'x-membersrl':cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['COOKIES']['member_srl'],'x-pcid':cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['COOKIES']['PCID'],'x-profileid':cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['SESSION']['profileId'],}
    cxqyGFuLAMzshrIBJHkfgRwQjdTeXN={'platform':'WEBCLIENT','page':cxqyGFuLAMzshrIBJHkfgRwQjdTeoE(page_int),'perPage':cxqyGFuLAMzshrIBJHkfgRwQjdTeoE(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.PAGE_LIMIT),'locale':'ko','sort':'',}
    cxqyGFuLAMzshrIBJHkfgRwQjdTeXW=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.API_VIEWURL+'/v1/discover/categories/'+cxqyGFuLAMzshrIBJHkfgRwQjdTeDV+'/titles'
    cxqyGFuLAMzshrIBJHkfgRwQjdTeXO=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.callRequestCookies('Get',cxqyGFuLAMzshrIBJHkfgRwQjdTeXW,payload=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,params=cxqyGFuLAMzshrIBJHkfgRwQjdTeXN,headers=cxqyGFuLAMzshrIBJHkfgRwQjdTeUN,cookies=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,redirects=cxqyGFuLAMzshrIBJHkfgRwQjdTeVo)
   else: 
    cxqyGFuLAMzshrIBJHkfgRwQjdTeXN={'platform':'WEBCLIENT','page':cxqyGFuLAMzshrIBJHkfgRwQjdTeoE(page_int),'perPage':cxqyGFuLAMzshrIBJHkfgRwQjdTeoE(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.PAGE_LIMIT),}
    cxqyGFuLAMzshrIBJHkfgRwQjdTeXW=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.API_VIEWURL+'/v1/discover/collections/'+cxqyGFuLAMzshrIBJHkfgRwQjdTeDV+'/titles'
    cxqyGFuLAMzshrIBJHkfgRwQjdTeXO=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.callRequestCookies('Get',cxqyGFuLAMzshrIBJHkfgRwQjdTeXW,payload=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,params=cxqyGFuLAMzshrIBJHkfgRwQjdTeXN,headers=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,cookies=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,redirects=cxqyGFuLAMzshrIBJHkfgRwQjdTeVo)
   if cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.status_code not in[200]:return[],cxqyGFuLAMzshrIBJHkfgRwQjdTeoK
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXm=json.loads(cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.text)
   if vType in['ALL','KIDS']:
    cxqyGFuLAMzshrIBJHkfgRwQjdTeDi=cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('data').get('data')
   else:
    cxqyGFuLAMzshrIBJHkfgRwQjdTeDi=cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('data')
   for cxqyGFuLAMzshrIBJHkfgRwQjdTeDo in cxqyGFuLAMzshrIBJHkfgRwQjdTeDi:
    cxqyGFuLAMzshrIBJHkfgRwQjdTeDW=cxqyGFuLAMzshrIBJHkfgRwQjdTeDP=cxqyGFuLAMzshrIBJHkfgRwQjdTeot=cxqyGFuLAMzshrIBJHkfgRwQjdTeob=''
    if 'poster' in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('images'):cxqyGFuLAMzshrIBJHkfgRwQjdTeDW =cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('images'):cxqyGFuLAMzshrIBJHkfgRwQjdTeDP =cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('images').get('story-art').get('url') +'?imwidth=600'
    if 'title-treatment' in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('images'):cxqyGFuLAMzshrIBJHkfgRwQjdTeot=cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('images').get('title-treatment').get('url')+'?imwidth=300'
    if 'story-art' in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('images'):cxqyGFuLAMzshrIBJHkfgRwQjdTeob =cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('images').get('story-art').get('url') +'?imwidth=600'
    cxqyGFuLAMzshrIBJHkfgRwQjdTeDv=''
    if cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('badge')not in[{},cxqyGFuLAMzshrIBJHkfgRwQjdTeon]:
     for i in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('badge').get('text'):
      cxqyGFuLAMzshrIBJHkfgRwQjdTeDv+=i.get('text')
    cxqyGFuLAMzshrIBJHkfgRwQjdTeDO=''
    if cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('seasonList')!=cxqyGFuLAMzshrIBJHkfgRwQjdTeon:
     cxqyGFuLAMzshrIBJHkfgRwQjdTeDO=','.join(cxqyGFuLAMzshrIBJHkfgRwQjdTeoE(e)for e in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('seasonList'))
    cxqyGFuLAMzshrIBJHkfgRwQjdTeDb =[]
    for cxqyGFuLAMzshrIBJHkfgRwQjdTeDt in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('tags'):
     cxqyGFuLAMzshrIBJHkfgRwQjdTeDb.append(cxqyGFuLAMzshrIBJHkfgRwQjdTeDt.get('tag'))
    cxqyGFuLAMzshrIBJHkfgRwQjdTeDS={'id':cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('id'),'title':cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('title'),'thumbnail':{'poster':cxqyGFuLAMzshrIBJHkfgRwQjdTeDW,'thumb':cxqyGFuLAMzshrIBJHkfgRwQjdTeDP,'clearlogo':cxqyGFuLAMzshrIBJHkfgRwQjdTeot,'fanart':cxqyGFuLAMzshrIBJHkfgRwQjdTeob},'mpaa':cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('age_rating'),'duration':cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('running_time'),'asis':cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('as'),'badge':cxqyGFuLAMzshrIBJHkfgRwQjdTeDv,'year':cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('meta').get('releaseYear'),'seasonList':cxqyGFuLAMzshrIBJHkfgRwQjdTeDO,'genreList':cxqyGFuLAMzshrIBJHkfgRwQjdTeDb,}
    cxqyGFuLAMzshrIBJHkfgRwQjdTeXp.append(cxqyGFuLAMzshrIBJHkfgRwQjdTeDS)
   if cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('pagination').get('totalPages')>page_int:
    cxqyGFuLAMzshrIBJHkfgRwQjdTeDC=cxqyGFuLAMzshrIBJHkfgRwQjdTeVo
  except cxqyGFuLAMzshrIBJHkfgRwQjdTeVU as exception:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeol(exception)
   return[],cxqyGFuLAMzshrIBJHkfgRwQjdTeoK
  return cxqyGFuLAMzshrIBJHkfgRwQjdTeXp,cxqyGFuLAMzshrIBJHkfgRwQjdTeDC
 def Get_Episode_List(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD,programId,season):
  cxqyGFuLAMzshrIBJHkfgRwQjdTeXp=[] 
  try:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXW=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.API_VIEWURL+'/v1/discover/titles/'+programId+'/episodes'
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXN={'season':season,'sort':'true','locale':'ko',}
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXO=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.callRequestCookies('Get',cxqyGFuLAMzshrIBJHkfgRwQjdTeXW,payload=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,params=cxqyGFuLAMzshrIBJHkfgRwQjdTeXN,headers=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,cookies=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,redirects=cxqyGFuLAMzshrIBJHkfgRwQjdTeVo)
   if cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.status_code not in[200]:return[]
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXm=json.loads(cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.text)
   for cxqyGFuLAMzshrIBJHkfgRwQjdTeDo in cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('data'):
    cxqyGFuLAMzshrIBJHkfgRwQjdTeDP=''
    if 'story-art' in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('images'):cxqyGFuLAMzshrIBJHkfgRwQjdTeDP =cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('images').get('story-art').get('url')+'?imwidth=600'
    cxqyGFuLAMzshrIBJHkfgRwQjdTeDb =[]
    for cxqyGFuLAMzshrIBJHkfgRwQjdTeDt in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('tags'):
     cxqyGFuLAMzshrIBJHkfgRwQjdTeDb.append(cxqyGFuLAMzshrIBJHkfgRwQjdTeDt.get('tag'))
    cxqyGFuLAMzshrIBJHkfgRwQjdTeDS={'id':cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('id'),'title':cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('title'),'thumbnail':{'thumb':cxqyGFuLAMzshrIBJHkfgRwQjdTeDP,'fanart':cxqyGFuLAMzshrIBJHkfgRwQjdTeDP},'mpaa':cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('age_rating'),'duration':cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('running_time'),'asis':cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('as'),'year':cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('meta').get('releaseYear'),'episode':cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('episode'),'genreList':cxqyGFuLAMzshrIBJHkfgRwQjdTeDb,'desc':cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('description'),}
    cxqyGFuLAMzshrIBJHkfgRwQjdTeXp.append(cxqyGFuLAMzshrIBJHkfgRwQjdTeDS)
  except cxqyGFuLAMzshrIBJHkfgRwQjdTeVU as exception:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeol(exception)
   return[]
  return cxqyGFuLAMzshrIBJHkfgRwQjdTeXp
 def Get_vInfo(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD,titleId):
  try:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXW=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.API_VIEWURL+'/v1/discover/titles/'+titleId 
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXN={'platform':'WEBCLIENT','locale':'ko','filterRestrictedContent':'false',}
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXO=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.callRequestCookies('Get',cxqyGFuLAMzshrIBJHkfgRwQjdTeXW,payload=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,params=cxqyGFuLAMzshrIBJHkfgRwQjdTeXN,headers=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,cookies=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,redirects=cxqyGFuLAMzshrIBJHkfgRwQjdTeVo)
   if cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.status_code not in[200]:return '','',''
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXm=json.loads(cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.text).get('data')
   cxqyGFuLAMzshrIBJHkfgRwQjdTeDO=''
   if cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('seasonList')!=cxqyGFuLAMzshrIBJHkfgRwQjdTeon:
    cxqyGFuLAMzshrIBJHkfgRwQjdTeDO=','.join(cxqyGFuLAMzshrIBJHkfgRwQjdTeoE(e)for e in cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('seasonList'))
   cxqyGFuLAMzshrIBJHkfgRwQjdTeDa={'age_rating':cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('age_rating'),'asset_id':cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('asset_id'),'availability':cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('availability'),'deal_id':cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('deal_id'),'downloadable':'true' if cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('downloadable')else 'false','region':cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('region'),'streamable':'true' if cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('streamable')else 'false','asis':cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('as'),'seasonList':cxqyGFuLAMzshrIBJHkfgRwQjdTeDO}
  except cxqyGFuLAMzshrIBJHkfgRwQjdTeVU as exception:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeol(exception)
   return{}
  return cxqyGFuLAMzshrIBJHkfgRwQjdTeDa
 def Get_eInfo(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD,eventId):
  try:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXW=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.API_VIEWURL+'/v1/discover/events/'+eventId 
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXN={'locale':'ko'}
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXO=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.callRequestCookies('Get',cxqyGFuLAMzshrIBJHkfgRwQjdTeXW,payload=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,params=cxqyGFuLAMzshrIBJHkfgRwQjdTeXN,headers=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,cookies=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,redirects=cxqyGFuLAMzshrIBJHkfgRwQjdTeVo)
   if cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.status_code not in[200]:return '','',''
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXm=json.loads(cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.text).get('data')
   cxqyGFuLAMzshrIBJHkfgRwQjdTeDa={'asset_id':cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('asset_id'),'deal_id':cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('deal_id'),'region':cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('region'),'streamable':'true' if cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('streamable')else 'false',}
  except cxqyGFuLAMzshrIBJHkfgRwQjdTeVU as exception:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeol(exception)
   return{}
  return cxqyGFuLAMzshrIBJHkfgRwQjdTeDa
 def GetBroadURL(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD,titleId):
  cxqyGFuLAMzshrIBJHkfgRwQjdTeDY=''
  cxqyGFuLAMzshrIBJHkfgRwQjdTeDm =''
  cxqyGFuLAMzshrIBJHkfgRwQjdTeDa=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.Get_vInfo(titleId)
  if cxqyGFuLAMzshrIBJHkfgRwQjdTeDa=={}:return '',''
  try:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXW=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.API_DOMAIN+'/api/playback/play' 
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXN={'titleId':titleId}
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXD,cxqyGFuLAMzshrIBJHkfgRwQjdTeXo,cxqyGFuLAMzshrIBJHkfgRwQjdTeXV=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.Make_authHeader()
   cxqyGFuLAMzshrIBJHkfgRwQjdTeUN={'traceparent':cxqyGFuLAMzshrIBJHkfgRwQjdTeXD,'tracestate':cxqyGFuLAMzshrIBJHkfgRwQjdTeXo,'newrelic':cxqyGFuLAMzshrIBJHkfgRwQjdTeXV,'x-drm':'com.microsoft.playready','x-app-version':'1.33.5','x-device-id':'','x-device-os-version':cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.OS_VERSION,'x-force-raw':'true','x-nr-session-id':cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['COOKIES']['session_web_id'],'x-pcid':cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['COOKIES']['PCID'],'x-platform':'web','x-profileId':cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['SESSION']['profileId'],'x-profileType':'standard','x-sessionid':cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.generatePvId(genType='1'),'x-title-age-rating':cxqyGFuLAMzshrIBJHkfgRwQjdTeDa.get('age_rating'),'x-title-availability':cxqyGFuLAMzshrIBJHkfgRwQjdTeDa.get('availability'),'x-title-brightcove-id':cxqyGFuLAMzshrIBJHkfgRwQjdTeDa.get('asset_id'),'x-title-deal-id':cxqyGFuLAMzshrIBJHkfgRwQjdTeDa.get('deal_id'),'x-title-downloadable':cxqyGFuLAMzshrIBJHkfgRwQjdTeDa.get('downloadable'),'x-title-region':cxqyGFuLAMzshrIBJHkfgRwQjdTeDa.get('region'),'x-title-streamable':cxqyGFuLAMzshrIBJHkfgRwQjdTeDa.get('streamable'),}
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXv=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.make_CP_DefaultCookies()
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXO=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.callRequestCookies('Get',cxqyGFuLAMzshrIBJHkfgRwQjdTeXW,payload=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,params=cxqyGFuLAMzshrIBJHkfgRwQjdTeXN,headers=cxqyGFuLAMzshrIBJHkfgRwQjdTeUN,cookies=cxqyGFuLAMzshrIBJHkfgRwQjdTeXv,redirects=cxqyGFuLAMzshrIBJHkfgRwQjdTeVo)
   if cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.status_code not in[200]:return '',json.loads(cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.text).get('error').get('detail')
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXm=json.loads(cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.text)
   if cxqyGFuLAMzshrIBJHkfgRwQjdTeDY=='':
    for cxqyGFuLAMzshrIBJHkfgRwQjdTeDo in cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('data').get('raw').get('sources'):
     if 'key_systems' in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo and 'codecs' not in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo:
      if cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('type')=='application/dash+xml' and 'com.widevine.alpha' in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('key_systems')and cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('src').startswith('https://')==cxqyGFuLAMzshrIBJHkfgRwQjdTeVo:
       cxqyGFuLAMzshrIBJHkfgRwQjdTeDY=cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('src')
       cxqyGFuLAMzshrIBJHkfgRwQjdTeDm =cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if cxqyGFuLAMzshrIBJHkfgRwQjdTeDY=='':
    for cxqyGFuLAMzshrIBJHkfgRwQjdTeDo in cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('data').get('raw').get('sources'):
     if 'key_systems' in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo and 'codecs' not in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo:
      if cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('key_systems')and cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('src').startswith('https://')==cxqyGFuLAMzshrIBJHkfgRwQjdTeVo:
       cxqyGFuLAMzshrIBJHkfgRwQjdTeDY=cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('src')
       cxqyGFuLAMzshrIBJHkfgRwQjdTeDm =cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if cxqyGFuLAMzshrIBJHkfgRwQjdTeDY=='':
    for cxqyGFuLAMzshrIBJHkfgRwQjdTeDo in cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('data').get('raw').get('sources'):
     if 'key_systems' in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo and 'codecs' in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo:
      if cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('type')=='application/dash+xml' and 'com.widevine.alpha' in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('key_systems')and cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('src').startswith('https://')==cxqyGFuLAMzshrIBJHkfgRwQjdTeVo:
       cxqyGFuLAMzshrIBJHkfgRwQjdTeDY=cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('src')
       cxqyGFuLAMzshrIBJHkfgRwQjdTeDm =cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
   if cxqyGFuLAMzshrIBJHkfgRwQjdTeDY=='':
    for cxqyGFuLAMzshrIBJHkfgRwQjdTeDo in cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('data').get('raw').get('sources'):
     if 'key_systems' in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo and 'codecs' in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo:
      if cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('key_systems')and cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('src').startswith('https://')==cxqyGFuLAMzshrIBJHkfgRwQjdTeVo:
       cxqyGFuLAMzshrIBJHkfgRwQjdTeDY=cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('src')
       cxqyGFuLAMzshrIBJHkfgRwQjdTeDm =cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('key_systems').get('com.widevine.alpha').get('license_url')
       break
  except cxqyGFuLAMzshrIBJHkfgRwQjdTeVU as exception:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeol(exception)
   return '',''
  return cxqyGFuLAMzshrIBJHkfgRwQjdTeDY,cxqyGFuLAMzshrIBJHkfgRwQjdTeDm
 def GetEventURL(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD,eventId,cxqyGFuLAMzshrIBJHkfgRwQjdTeoC):
  cxqyGFuLAMzshrIBJHkfgRwQjdTeDY=''
  cxqyGFuLAMzshrIBJHkfgRwQjdTeDm =''
  cxqyGFuLAMzshrIBJHkfgRwQjdTeDa=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.Get_eInfo(eventId)
  if cxqyGFuLAMzshrIBJHkfgRwQjdTeDa=={}:return '',''
  try:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXW=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.API_DOMAIN+'/api/playback/play' 
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXN={'titleId':eventId,'titleType':cxqyGFuLAMzshrIBJHkfgRwQjdTeoC,}
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXD,cxqyGFuLAMzshrIBJHkfgRwQjdTeXo,cxqyGFuLAMzshrIBJHkfgRwQjdTeXV=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.Make_authHeader()
   cxqyGFuLAMzshrIBJHkfgRwQjdTeUN={'traceparent':cxqyGFuLAMzshrIBJHkfgRwQjdTeXD,'tracestate':cxqyGFuLAMzshrIBJHkfgRwQjdTeXo,'newrelic':cxqyGFuLAMzshrIBJHkfgRwQjdTeXV,'x-force-raw':'true','x-pcid':cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['COOKIES']['PCID'],'x-platform':'web','x-profileId':cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':cxqyGFuLAMzshrIBJHkfgRwQjdTeDa.get('asset_id'),'x-title-deal-id':cxqyGFuLAMzshrIBJHkfgRwQjdTeDa.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':cxqyGFuLAMzshrIBJHkfgRwQjdTeDa.get('region'),'x-title-streamable':cxqyGFuLAMzshrIBJHkfgRwQjdTeDa.get('streamable'),}
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXv=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.make_CP_DefaultCookies()
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXO=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.callRequestCookies('Get',cxqyGFuLAMzshrIBJHkfgRwQjdTeXW,payload=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,params=cxqyGFuLAMzshrIBJHkfgRwQjdTeXN,headers=cxqyGFuLAMzshrIBJHkfgRwQjdTeUN,cookies=cxqyGFuLAMzshrIBJHkfgRwQjdTeXv,redirects=cxqyGFuLAMzshrIBJHkfgRwQjdTeVo)
   if cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.status_code not in[200]:return '',json.loads(cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.text).get('error').get('detail')
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXm=json.loads(cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.text)
   for cxqyGFuLAMzshrIBJHkfgRwQjdTeDo in cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('data').get('raw').get('sources'):
    if cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('type')=='application/dash+xml' and cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('src')[0:8]=='https://':
     cxqyGFuLAMzshrIBJHkfgRwQjdTeDY=cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('src')
     if 'key_systems' in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo:
      cxqyGFuLAMzshrIBJHkfgRwQjdTeDm =cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('key_systems').get('com.widevine.alpha').get('license_url')
     break
  except cxqyGFuLAMzshrIBJHkfgRwQjdTeVU as exception:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeol(exception)
   return '',''
  return cxqyGFuLAMzshrIBJHkfgRwQjdTeDY,cxqyGFuLAMzshrIBJHkfgRwQjdTeDm
 def GetEventURL_Live(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD,eventId,cxqyGFuLAMzshrIBJHkfgRwQjdTeoC):
  cxqyGFuLAMzshrIBJHkfgRwQjdTeDY=''
  cxqyGFuLAMzshrIBJHkfgRwQjdTeDm =''
  cxqyGFuLAMzshrIBJHkfgRwQjdTeDa=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.Get_eInfo(eventId)
  if cxqyGFuLAMzshrIBJHkfgRwQjdTeDa=={}:return '',''
  try:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXW=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.API_DOMAIN+'/api/playback/play' 
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXN={'titleId':eventId,'titleType':cxqyGFuLAMzshrIBJHkfgRwQjdTeoC,}
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXD,cxqyGFuLAMzshrIBJHkfgRwQjdTeXo,cxqyGFuLAMzshrIBJHkfgRwQjdTeXV=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.Make_authHeader()
   cxqyGFuLAMzshrIBJHkfgRwQjdTeUN={'traceparent':cxqyGFuLAMzshrIBJHkfgRwQjdTeXD,'tracestate':cxqyGFuLAMzshrIBJHkfgRwQjdTeXo,'newrelic':cxqyGFuLAMzshrIBJHkfgRwQjdTeXV,'x-force-raw':'true','x-pcid':cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['COOKIES']['PCID'],'x-platform':'web','x-profileId':cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['SESSION']['profileId'],'x-profileType':'standard','x-title-age-rating':'undefined','x-title-availability':'undefined','x-title-brightcove-id':cxqyGFuLAMzshrIBJHkfgRwQjdTeDa.get('asset_id'),'x-title-deal-id':cxqyGFuLAMzshrIBJHkfgRwQjdTeDa.get('deal_id'),'x-title-downloadable':'undefined','x-title-region':cxqyGFuLAMzshrIBJHkfgRwQjdTeDa.get('region'),'x-title-streamable':cxqyGFuLAMzshrIBJHkfgRwQjdTeDa.get('streamable'),}
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXv=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.make_CP_DefaultCookies()
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXO=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.callRequestCookies('Get',cxqyGFuLAMzshrIBJHkfgRwQjdTeXW,payload=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,params=cxqyGFuLAMzshrIBJHkfgRwQjdTeXN,headers=cxqyGFuLAMzshrIBJHkfgRwQjdTeUN,cookies=cxqyGFuLAMzshrIBJHkfgRwQjdTeXv,redirects=cxqyGFuLAMzshrIBJHkfgRwQjdTeVo)
   if cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.status_code not in[200]:return '',json.loads(cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.text).get('error').get('detail')
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXm=json.loads(cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.text)
   if cxqyGFuLAMzshrIBJHkfgRwQjdTeDY=='':
    for cxqyGFuLAMzshrIBJHkfgRwQjdTeDo in cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('data').get('raw').get('sources'):
     if 'key_systems' in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo:
      if cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('type')=='application/dash+xml' and 'com.widevine.alpha' in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('key_systems')and cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('src').startswith('https://')==cxqyGFuLAMzshrIBJHkfgRwQjdTeVo:
       cxqyGFuLAMzshrIBJHkfgRwQjdTeDY=cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('src')
       cxqyGFuLAMzshrIBJHkfgRwQjdTeDm =cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('key_systems').get('com.widevine.alpha').get('license_url')
   if cxqyGFuLAMzshrIBJHkfgRwQjdTeDY=='':
    for cxqyGFuLAMzshrIBJHkfgRwQjdTeDo in cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('data').get('raw').get('sources'):
     if 'key_systems' in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo:
      if cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('type')=='application/x-mpegURL' and 'com.widevine.alpha' in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('key_systems')and cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('src').startswith('https://')==cxqyGFuLAMzshrIBJHkfgRwQjdTeVo:
       cxqyGFuLAMzshrIBJHkfgRwQjdTeDY=cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('src')
       cxqyGFuLAMzshrIBJHkfgRwQjdTeDm =cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('key_systems').get('com.widevine.alpha').get('license_url')
   if cxqyGFuLAMzshrIBJHkfgRwQjdTeDY=='':
    for cxqyGFuLAMzshrIBJHkfgRwQjdTeDo in cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('data').get('raw').get('sources'):
     if cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('type')=='application/dash+xml' and cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('src').startswith('https://')==cxqyGFuLAMzshrIBJHkfgRwQjdTeVo:
      cxqyGFuLAMzshrIBJHkfgRwQjdTeDY=cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('src')
   if cxqyGFuLAMzshrIBJHkfgRwQjdTeDY=='':
    for cxqyGFuLAMzshrIBJHkfgRwQjdTeDo in cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('data').get('raw').get('sources'):
     if cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('type')=='application/x-mpegURL' and cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('src').startswith('https://')==cxqyGFuLAMzshrIBJHkfgRwQjdTeVo:
      cxqyGFuLAMzshrIBJHkfgRwQjdTeDY=cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('src')
  except cxqyGFuLAMzshrIBJHkfgRwQjdTeVU as exception:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeol(exception)
   return '',''
  return cxqyGFuLAMzshrIBJHkfgRwQjdTeDY,cxqyGFuLAMzshrIBJHkfgRwQjdTeDm
 def Get_Url_PostFix(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD,in_url):
  cxqyGFuLAMzshrIBJHkfgRwQjdTeDn=urllib.parse.urlparse(in_url) 
  cxqyGFuLAMzshrIBJHkfgRwQjdTeDK =cxqyGFuLAMzshrIBJHkfgRwQjdTeDn.path.strip('/').split('/')
  cxqyGFuLAMzshrIBJHkfgRwQjdTeDl =cxqyGFuLAMzshrIBJHkfgRwQjdTeDK[cxqyGFuLAMzshrIBJHkfgRwQjdTeVX(cxqyGFuLAMzshrIBJHkfgRwQjdTeDK)-1]
  cxqyGFuLAMzshrIBJHkfgRwQjdTeDE=cxqyGFuLAMzshrIBJHkfgRwQjdTeDl.split('.')
  return cxqyGFuLAMzshrIBJHkfgRwQjdTeDE[cxqyGFuLAMzshrIBJHkfgRwQjdTeVX(cxqyGFuLAMzshrIBJHkfgRwQjdTeDE)-1]
 def Get_Theme_GroupList(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD,vType):
  cxqyGFuLAMzshrIBJHkfgRwQjdTeXp=[] 
  try:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXW=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.API_VIEWURL+'/v2/discover/feed' 
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXN={'category':vType,'platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':cxqyGFuLAMzshrIBJHkfgRwQjdTeoE(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.PAGE_LIMIT),'filterRestrictedContent':'false',}
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXO=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.callRequestCookies('Get',cxqyGFuLAMzshrIBJHkfgRwQjdTeXW,payload=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,params=cxqyGFuLAMzshrIBJHkfgRwQjdTeXN,headers=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,cookies=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,redirects=cxqyGFuLAMzshrIBJHkfgRwQjdTeVo)
   if cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.status_code not in[200]:return[]
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXm=json.loads(cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.text)
   for cxqyGFuLAMzshrIBJHkfgRwQjdTeDo in cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('data'):
    if cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('type')=='Title-Rails-Curation':
     cxqyGFuLAMzshrIBJHkfgRwQjdTeDp =''
     cxqyGFuLAMzshrIBJHkfgRwQjdTeDN=7
     try:
      for i in cxqyGFuLAMzshrIBJHkfgRwQjdTeVS(cxqyGFuLAMzshrIBJHkfgRwQjdTeVX(cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('data'))):
       if i>=cxqyGFuLAMzshrIBJHkfgRwQjdTeDN:
        cxqyGFuLAMzshrIBJHkfgRwQjdTeDp=cxqyGFuLAMzshrIBJHkfgRwQjdTeDp+'...'
        break
       cxqyGFuLAMzshrIBJHkfgRwQjdTeDp=cxqyGFuLAMzshrIBJHkfgRwQjdTeDp+cxqyGFuLAMzshrIBJHkfgRwQjdTeDo['data'][i]['title']+'\n'
     except cxqyGFuLAMzshrIBJHkfgRwQjdTeVU as exception:
      cxqyGFuLAMzshrIBJHkfgRwQjdTeol(exception)
     cxqyGFuLAMzshrIBJHkfgRwQjdTeDS={'collectionId':cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('obj_id'),'title':cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('row_name'),'category':cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('category'),'pre_title':cxqyGFuLAMzshrIBJHkfgRwQjdTeDp,}
     cxqyGFuLAMzshrIBJHkfgRwQjdTeXp.append(cxqyGFuLAMzshrIBJHkfgRwQjdTeDS)
  except cxqyGFuLAMzshrIBJHkfgRwQjdTeVU as exception:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeol(exception)
   return[]
  return cxqyGFuLAMzshrIBJHkfgRwQjdTeXp
 def Get_Event_GroupList(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD):
  cxqyGFuLAMzshrIBJHkfgRwQjdTeXp=[] 
  try:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXW=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.API_VIEWURL+'/v2/discover/feed' 
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXN={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':7,'filterRestrictedContent':'false',}
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXO=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.callRequestCookies('Get',cxqyGFuLAMzshrIBJHkfgRwQjdTeXW,payload=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,params=cxqyGFuLAMzshrIBJHkfgRwQjdTeXN,headers=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,cookies=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,redirects=cxqyGFuLAMzshrIBJHkfgRwQjdTeVo)
   if cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.status_code not in[200]:return[]
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXm=json.loads(cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.text)
   for cxqyGFuLAMzshrIBJHkfgRwQjdTeDo in cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('data'):
    if cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('row_name').strip()!='':
     cxqyGFuLAMzshrIBJHkfgRwQjdTeDp =''
     cxqyGFuLAMzshrIBJHkfgRwQjdTeDN=7
     try:
      for i in cxqyGFuLAMzshrIBJHkfgRwQjdTeVS(cxqyGFuLAMzshrIBJHkfgRwQjdTeVX(cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('data'))):
       if i>=cxqyGFuLAMzshrIBJHkfgRwQjdTeDN:
        cxqyGFuLAMzshrIBJHkfgRwQjdTeDp=cxqyGFuLAMzshrIBJHkfgRwQjdTeDp+'...'
        break
       cxqyGFuLAMzshrIBJHkfgRwQjdTeDp=cxqyGFuLAMzshrIBJHkfgRwQjdTeDp+cxqyGFuLAMzshrIBJHkfgRwQjdTeDo['data'][i]['title']+'\n'
     except cxqyGFuLAMzshrIBJHkfgRwQjdTeVU as exception:
      cxqyGFuLAMzshrIBJHkfgRwQjdTeol(exception)
     cxqyGFuLAMzshrIBJHkfgRwQjdTeDS={'collectionId':cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('obj_id'),'title':cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('row_name'),'category':cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('type'),'pre_title':cxqyGFuLAMzshrIBJHkfgRwQjdTeDp,}
     cxqyGFuLAMzshrIBJHkfgRwQjdTeXp.append(cxqyGFuLAMzshrIBJHkfgRwQjdTeDS)
  except cxqyGFuLAMzshrIBJHkfgRwQjdTeVU as exception:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeol(exception)
   return[]
  return cxqyGFuLAMzshrIBJHkfgRwQjdTeXp
 def Get_Event_GameList(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD,cxqyGFuLAMzshrIBJHkfgRwQjdTeDV):
  cxqyGFuLAMzshrIBJHkfgRwQjdTeXp=[] 
  try:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXW=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.API_VIEWURL+'/v2/discover/feed' 
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXN={'category':'LIVE','platform':'WEBCLIENT','region':'KR','locale':'ko','page':'1','perPage':'7','filterRestrictedContent':'false',}
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXO=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.callRequestCookies('Get',cxqyGFuLAMzshrIBJHkfgRwQjdTeXW,payload=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,params=cxqyGFuLAMzshrIBJHkfgRwQjdTeXN,headers=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,cookies=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,redirects=cxqyGFuLAMzshrIBJHkfgRwQjdTeVo)
   if cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.status_code not in[200]:return[]
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXm=json.loads(cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.text)
   for cxqyGFuLAMzshrIBJHkfgRwQjdTeDo in cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('data'):
    if cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('obj_id')==cxqyGFuLAMzshrIBJHkfgRwQjdTeDV:
     for cxqyGFuLAMzshrIBJHkfgRwQjdTeoU in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('data'):
      cxqyGFuLAMzshrIBJHkfgRwQjdTeDW=cxqyGFuLAMzshrIBJHkfgRwQjdTeDP=cxqyGFuLAMzshrIBJHkfgRwQjdTeob=''
      if 'poster' in cxqyGFuLAMzshrIBJHkfgRwQjdTeoU.get('images'):cxqyGFuLAMzshrIBJHkfgRwQjdTeDW =cxqyGFuLAMzshrIBJHkfgRwQjdTeoU.get('images').get('poster').get('url') +'?imwidth=350'
      if 'story-art' in cxqyGFuLAMzshrIBJHkfgRwQjdTeoU.get('images'):cxqyGFuLAMzshrIBJHkfgRwQjdTeDP =cxqyGFuLAMzshrIBJHkfgRwQjdTeoU.get('images').get('story-art').get('url')+'?imwidth=600'
      if 'hero' in cxqyGFuLAMzshrIBJHkfgRwQjdTeoU.get('images'):cxqyGFuLAMzshrIBJHkfgRwQjdTeob =cxqyGFuLAMzshrIBJHkfgRwQjdTeoU.get('images').get('hero').get('url') +'?imwidth=600'
      cxqyGFuLAMzshrIBJHkfgRwQjdTeoX=cxqyGFuLAMzshrIBJHkfgRwQjdTeoU.get('meta').get(cxqyGFuLAMzshrIBJHkfgRwQjdTeoU.get('category')).get(cxqyGFuLAMzshrIBJHkfgRwQjdTeoU.get('sub_category'))
      if 'league' in cxqyGFuLAMzshrIBJHkfgRwQjdTeoX:
       cxqyGFuLAMzshrIBJHkfgRwQjdTeoD=cxqyGFuLAMzshrIBJHkfgRwQjdTeoX.get('league')
      else:
       cxqyGFuLAMzshrIBJHkfgRwQjdTeoD=cxqyGFuLAMzshrIBJHkfgRwQjdTeoX.get('round')
      cxqyGFuLAMzshrIBJHkfgRwQjdTeDS={'id':cxqyGFuLAMzshrIBJHkfgRwQjdTeoU.get('id'),'title':cxqyGFuLAMzshrIBJHkfgRwQjdTeoU.get('title'),'thumbnail':{'poster':cxqyGFuLAMzshrIBJHkfgRwQjdTeDW,'thumb':cxqyGFuLAMzshrIBJHkfgRwQjdTeDP,'fanart':cxqyGFuLAMzshrIBJHkfgRwQjdTeob},'asis':cxqyGFuLAMzshrIBJHkfgRwQjdTeoU.get('type'),'addInfo':cxqyGFuLAMzshrIBJHkfgRwQjdTeoD,'starttm':cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.convert_TimeStr(cxqyGFuLAMzshrIBJHkfgRwQjdTeoU.get('start_at')),}
      cxqyGFuLAMzshrIBJHkfgRwQjdTeXp.append(cxqyGFuLAMzshrIBJHkfgRwQjdTeDS)
  except cxqyGFuLAMzshrIBJHkfgRwQjdTeVU as exception:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeol(exception)
   return[]
  return cxqyGFuLAMzshrIBJHkfgRwQjdTeXp
 def Get_Event_List(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD,gameId):
  cxqyGFuLAMzshrIBJHkfgRwQjdTeXp=[] 
  try:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXW=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.API_VIEWURL+'/v1/discover/events/'+gameId 
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXN={'platform':'WEBCLIENT','locale':'ko','filterRestrictedContent':'false',}
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXO=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.callRequestCookies('Get',cxqyGFuLAMzshrIBJHkfgRwQjdTeXW,payload=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,params=cxqyGFuLAMzshrIBJHkfgRwQjdTeXN,headers=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,cookies=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,redirects=cxqyGFuLAMzshrIBJHkfgRwQjdTeVo)
   if cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.status_code not in[200]:return[]
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXm=json.loads(cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.text)
   cxqyGFuLAMzshrIBJHkfgRwQjdTeDo=cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('data')
   cxqyGFuLAMzshrIBJHkfgRwQjdTeoV=cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('end_at')
   cxqyGFuLAMzshrIBJHkfgRwQjdTeoV=cxqyGFuLAMzshrIBJHkfgRwQjdTeoV[0:19].replace('-','').replace(':','').replace('T','')
   cxqyGFuLAMzshrIBJHkfgRwQjdTeoS=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d%H%M%S')
   if cxqyGFuLAMzshrIBJHkfgRwQjdTeoN(cxqyGFuLAMzshrIBJHkfgRwQjdTeoS)<cxqyGFuLAMzshrIBJHkfgRwQjdTeoN(cxqyGFuLAMzshrIBJHkfgRwQjdTeoV):
    cxqyGFuLAMzshrIBJHkfgRwQjdTeDW=cxqyGFuLAMzshrIBJHkfgRwQjdTeDP=cxqyGFuLAMzshrIBJHkfgRwQjdTeob=''
    if 'poster' in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('images'):cxqyGFuLAMzshrIBJHkfgRwQjdTeDW =cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('images'):cxqyGFuLAMzshrIBJHkfgRwQjdTeDP =cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('images').get('story-art').get('url')+'?imwidth=600'
    if 'story-art' in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('images'):cxqyGFuLAMzshrIBJHkfgRwQjdTeob =cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('images').get('story-art').get('url')+'?imwidth=600'
    cxqyGFuLAMzshrIBJHkfgRwQjdTeDS={'id':cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('id'),'title':cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('title'),'thumbnail':{'poster':cxqyGFuLAMzshrIBJHkfgRwQjdTeDW,'thumb':cxqyGFuLAMzshrIBJHkfgRwQjdTeDP,'fanart':cxqyGFuLAMzshrIBJHkfgRwQjdTeob},'duration':cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('running_time'),'asis':cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('type'),'starttm':cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.convert_TimeStr(cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('start_at')),}
    cxqyGFuLAMzshrIBJHkfgRwQjdTeXp.append(cxqyGFuLAMzshrIBJHkfgRwQjdTeDS)
  except cxqyGFuLAMzshrIBJHkfgRwQjdTeVU as exception:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeol(exception)
   return[]
  try:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXW=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.API_VIEWURL+'/v1/discover/events/'+gameId+'/related' 
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXN={'locale':'ko','page':'1','perPage':'25','platform':'WEBCLIENT','currentPageTracking':'page_discover_title_detail',}
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXO=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.callRequestCookies('Get',cxqyGFuLAMzshrIBJHkfgRwQjdTeXW,payload=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,params=cxqyGFuLAMzshrIBJHkfgRwQjdTeXN,headers=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,cookies=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,redirects=cxqyGFuLAMzshrIBJHkfgRwQjdTeVo)
   if cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.status_code not in[200]:return[]
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXm=json.loads(cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.text)
   for cxqyGFuLAMzshrIBJHkfgRwQjdTeDo in cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('data').get('data'):
    cxqyGFuLAMzshrIBJHkfgRwQjdTeDW=cxqyGFuLAMzshrIBJHkfgRwQjdTeDP=cxqyGFuLAMzshrIBJHkfgRwQjdTeob=''
    if 'poster' in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('images'):cxqyGFuLAMzshrIBJHkfgRwQjdTeDW =cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('images'):cxqyGFuLAMzshrIBJHkfgRwQjdTeDP =cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('images').get('story-art').get('url')+'?imwidth=600'
    if 'story-art' in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('images'):cxqyGFuLAMzshrIBJHkfgRwQjdTeob =cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('images').get('story-art').get('url')+'?imwidth=600'
    cxqyGFuLAMzshrIBJHkfgRwQjdTeDS={'id':cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('id'),'title':cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('title'),'thumbnail':{'poster':cxqyGFuLAMzshrIBJHkfgRwQjdTeDW,'thumb':cxqyGFuLAMzshrIBJHkfgRwQjdTeDP,'fanart':cxqyGFuLAMzshrIBJHkfgRwQjdTeob},'duration':cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('running_time'),'asis':cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('type'),}
    cxqyGFuLAMzshrIBJHkfgRwQjdTeXp.append(cxqyGFuLAMzshrIBJHkfgRwQjdTeDS)
  except cxqyGFuLAMzshrIBJHkfgRwQjdTeVU as exception:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeol(exception)
   return[]
  return cxqyGFuLAMzshrIBJHkfgRwQjdTeXp
 def Get_Search_List(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD,search_key,page_int):
  cxqyGFuLAMzshrIBJHkfgRwQjdTeXp=[] 
  cxqyGFuLAMzshrIBJHkfgRwQjdTeDC=cxqyGFuLAMzshrIBJHkfgRwQjdTeoK
  try:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXW=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.API_VIEWURL+'/v2/search' 
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXN={'query':search_key,'platform':'WEBCLIENT','page':cxqyGFuLAMzshrIBJHkfgRwQjdTeoE(page_int),'perPage':cxqyGFuLAMzshrIBJHkfgRwQjdTeoE(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.SEARCH_LIMIT),}
   cxqyGFuLAMzshrIBJHkfgRwQjdTeUN={'x-membersrl':cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['COOKIES']['member_srl'],'x-pcid':cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['COOKIES']['PCID'],'x-profileid':cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.CP['SESSION']['profileId'],}
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXO=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.callRequestCookies('Get',cxqyGFuLAMzshrIBJHkfgRwQjdTeXW,payload=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,params=cxqyGFuLAMzshrIBJHkfgRwQjdTeXN,headers=cxqyGFuLAMzshrIBJHkfgRwQjdTeUN,cookies=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,redirects=cxqyGFuLAMzshrIBJHkfgRwQjdTeVo)
   if cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.status_code not in[200]:return[],cxqyGFuLAMzshrIBJHkfgRwQjdTeoK
   cxqyGFuLAMzshrIBJHkfgRwQjdTeXm=json.loads(cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.text)
   for cxqyGFuLAMzshrIBJHkfgRwQjdTeDo in cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('data').get('data'):
    cxqyGFuLAMzshrIBJHkfgRwQjdTeDo=cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('data')
    cxqyGFuLAMzshrIBJHkfgRwQjdTeDW=cxqyGFuLAMzshrIBJHkfgRwQjdTeDP=cxqyGFuLAMzshrIBJHkfgRwQjdTeot=cxqyGFuLAMzshrIBJHkfgRwQjdTeob=''
    if 'poster' in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('images'):cxqyGFuLAMzshrIBJHkfgRwQjdTeDW =cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('images').get('poster').get('url') +'?imwidth=350'
    if 'story-art' in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('images'):cxqyGFuLAMzshrIBJHkfgRwQjdTeDP =cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('images').get('story-art').get('url') +'?imwidth=600'
    if 'title-treatment' in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('images'):cxqyGFuLAMzshrIBJHkfgRwQjdTeot=cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('images').get('title-treatment').get('url')+'?imwidth=300'
    if 'story-art' in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('images'):cxqyGFuLAMzshrIBJHkfgRwQjdTeob =cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('images').get('story-art').get('url') +'?imwidth=600'
    cxqyGFuLAMzshrIBJHkfgRwQjdTeDv=''
    if cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('badge')not in[{},cxqyGFuLAMzshrIBJHkfgRwQjdTeon]:
     for i in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('badge').get('text'):
      if cxqyGFuLAMzshrIBJHkfgRwQjdTeDv!='':cxqyGFuLAMzshrIBJHkfgRwQjdTeDv+=' '
      cxqyGFuLAMzshrIBJHkfgRwQjdTeDv+=i.get('text')
    if 'as' in cxqyGFuLAMzshrIBJHkfgRwQjdTeDo:
     cxqyGFuLAMzshrIBJHkfgRwQjdTeoC=cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('as') 
    else:
     cxqyGFuLAMzshrIBJHkfgRwQjdTeoC=cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('type')
    cxqyGFuLAMzshrIBJHkfgRwQjdTeDS={'id':cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('id'),'title':cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('title'),'asis':cxqyGFuLAMzshrIBJHkfgRwQjdTeoC,'thumbnail':{'poster':cxqyGFuLAMzshrIBJHkfgRwQjdTeDW,'thumb':cxqyGFuLAMzshrIBJHkfgRwQjdTeDP,'clearlogo':cxqyGFuLAMzshrIBJHkfgRwQjdTeot,'fanart':cxqyGFuLAMzshrIBJHkfgRwQjdTeob},'mpaa':cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('age_rating'),'duration':cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('running_time'),'badge':cxqyGFuLAMzshrIBJHkfgRwQjdTeDv,'year':cxqyGFuLAMzshrIBJHkfgRwQjdTeDo.get('meta').get('releaseYear'),}
    cxqyGFuLAMzshrIBJHkfgRwQjdTeXp.append(cxqyGFuLAMzshrIBJHkfgRwQjdTeDS)
   if cxqyGFuLAMzshrIBJHkfgRwQjdTeXm.get('pagination').get('totalPages')>page_int:
    cxqyGFuLAMzshrIBJHkfgRwQjdTeDC=cxqyGFuLAMzshrIBJHkfgRwQjdTeVo
  except cxqyGFuLAMzshrIBJHkfgRwQjdTeVU as exception:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeol(exception)
   return[],cxqyGFuLAMzshrIBJHkfgRwQjdTeoK
  return cxqyGFuLAMzshrIBJHkfgRwQjdTeXp,cxqyGFuLAMzshrIBJHkfgRwQjdTeDC
 def GetBookmarkInfo(cxqyGFuLAMzshrIBJHkfgRwQjdTeUD,videoid,vidtype):
  cxqyGFuLAMzshrIBJHkfgRwQjdTeoi={'indexinfo':{'ott':'coupang','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  cxqyGFuLAMzshrIBJHkfgRwQjdTeXW=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.API_VIEWURL+'/v1/discover/titles/'+videoid 
  cxqyGFuLAMzshrIBJHkfgRwQjdTeXN={'locale':'ko'}
  cxqyGFuLAMzshrIBJHkfgRwQjdTeXO=cxqyGFuLAMzshrIBJHkfgRwQjdTeUD.callRequestCookies('Get',cxqyGFuLAMzshrIBJHkfgRwQjdTeXW,payload=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,params=cxqyGFuLAMzshrIBJHkfgRwQjdTeXN,headers=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,cookies=cxqyGFuLAMzshrIBJHkfgRwQjdTeon,redirects=cxqyGFuLAMzshrIBJHkfgRwQjdTeVo)
  if cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.status_code not in[200]:return{}
  cxqyGFuLAMzshrIBJHkfgRwQjdTeoW=json.loads(cxqyGFuLAMzshrIBJHkfgRwQjdTeXO.text).get('data')
  cxqyGFuLAMzshrIBJHkfgRwQjdTeov=cxqyGFuLAMzshrIBJHkfgRwQjdTeoW.get('title')
  cxqyGFuLAMzshrIBJHkfgRwQjdTeoO =cxqyGFuLAMzshrIBJHkfgRwQjdTeoW.get('meta').get('releaseYear')
  cxqyGFuLAMzshrIBJHkfgRwQjdTeoi['saveinfo']['infoLabels']['title']=cxqyGFuLAMzshrIBJHkfgRwQjdTeov
  if vidtype=='movie':
   cxqyGFuLAMzshrIBJHkfgRwQjdTeov='%s  (%s)'%(cxqyGFuLAMzshrIBJHkfgRwQjdTeov,cxqyGFuLAMzshrIBJHkfgRwQjdTeoO)
  cxqyGFuLAMzshrIBJHkfgRwQjdTeoi['saveinfo']['title'] =cxqyGFuLAMzshrIBJHkfgRwQjdTeov
  cxqyGFuLAMzshrIBJHkfgRwQjdTeoi['saveinfo']['infoLabels']['mpaa'] =cxqyGFuLAMzshrIBJHkfgRwQjdTeoW.get('age_rating')
  cxqyGFuLAMzshrIBJHkfgRwQjdTeoi['saveinfo']['infoLabels']['plot'] ='%s\n\n%s'%(cxqyGFuLAMzshrIBJHkfgRwQjdTeoW.get('short_description'),cxqyGFuLAMzshrIBJHkfgRwQjdTeoW.get('description'))
  cxqyGFuLAMzshrIBJHkfgRwQjdTeoi['saveinfo']['infoLabels']['year'] =cxqyGFuLAMzshrIBJHkfgRwQjdTeoO
  if vidtype=='movie':
   cxqyGFuLAMzshrIBJHkfgRwQjdTeoi['saveinfo']['infoLabels']['duration']=cxqyGFuLAMzshrIBJHkfgRwQjdTeoW.get('running_time')
  cxqyGFuLAMzshrIBJHkfgRwQjdTeDW =''
  cxqyGFuLAMzshrIBJHkfgRwQjdTeob =''
  cxqyGFuLAMzshrIBJHkfgRwQjdTeDP =''
  cxqyGFuLAMzshrIBJHkfgRwQjdTeot=''
  if cxqyGFuLAMzshrIBJHkfgRwQjdTeoW.get('images').get('poster') !=cxqyGFuLAMzshrIBJHkfgRwQjdTeon:cxqyGFuLAMzshrIBJHkfgRwQjdTeDW =cxqyGFuLAMzshrIBJHkfgRwQjdTeoW.get('images').get('poster').get('url') +'?imwidth=350'
  if cxqyGFuLAMzshrIBJHkfgRwQjdTeoW.get('images').get('background') !=cxqyGFuLAMzshrIBJHkfgRwQjdTeon:cxqyGFuLAMzshrIBJHkfgRwQjdTeob =cxqyGFuLAMzshrIBJHkfgRwQjdTeoW.get('images').get('background').get('url') +'?imwidth=600'
  if cxqyGFuLAMzshrIBJHkfgRwQjdTeoW.get('images').get('story-art') !=cxqyGFuLAMzshrIBJHkfgRwQjdTeon:cxqyGFuLAMzshrIBJHkfgRwQjdTeDP =cxqyGFuLAMzshrIBJHkfgRwQjdTeoW.get('images').get('story-art').get('url') +'?imwidth=600'
  if cxqyGFuLAMzshrIBJHkfgRwQjdTeoW.get('images').get('title-treatment')!=cxqyGFuLAMzshrIBJHkfgRwQjdTeon:cxqyGFuLAMzshrIBJHkfgRwQjdTeot=cxqyGFuLAMzshrIBJHkfgRwQjdTeoW.get('images').get('title-treatment').get('url')+'?imwidth=300'
  if cxqyGFuLAMzshrIBJHkfgRwQjdTeob=='':cxqyGFuLAMzshrIBJHkfgRwQjdTeob=cxqyGFuLAMzshrIBJHkfgRwQjdTeDP
  cxqyGFuLAMzshrIBJHkfgRwQjdTeoi['saveinfo']['thumbnail']['poster']=cxqyGFuLAMzshrIBJHkfgRwQjdTeDW
  cxqyGFuLAMzshrIBJHkfgRwQjdTeoi['saveinfo']['thumbnail']['fanart']=cxqyGFuLAMzshrIBJHkfgRwQjdTeob
  cxqyGFuLAMzshrIBJHkfgRwQjdTeoi['saveinfo']['thumbnail']['thumb']=cxqyGFuLAMzshrIBJHkfgRwQjdTeDP
  cxqyGFuLAMzshrIBJHkfgRwQjdTeoi['saveinfo']['thumbnail']['clearlogo']=cxqyGFuLAMzshrIBJHkfgRwQjdTeot
  cxqyGFuLAMzshrIBJHkfgRwQjdTeoP=[]
  for cxqyGFuLAMzshrIBJHkfgRwQjdTeDt in cxqyGFuLAMzshrIBJHkfgRwQjdTeoW.get('tags'):cxqyGFuLAMzshrIBJHkfgRwQjdTeoP.append(cxqyGFuLAMzshrIBJHkfgRwQjdTeDt.get('tag'))
  if cxqyGFuLAMzshrIBJHkfgRwQjdTeVX(cxqyGFuLAMzshrIBJHkfgRwQjdTeoP)>0:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeoi['saveinfo']['infoLabels']['genre']=cxqyGFuLAMzshrIBJHkfgRwQjdTeoP
  cxqyGFuLAMzshrIBJHkfgRwQjdTeoa=[]
  cxqyGFuLAMzshrIBJHkfgRwQjdTeoY=[]
  for cxqyGFuLAMzshrIBJHkfgRwQjdTeDt in cxqyGFuLAMzshrIBJHkfgRwQjdTeoW.get('people'):
   if cxqyGFuLAMzshrIBJHkfgRwQjdTeDt.get('role')=='CAST' :cxqyGFuLAMzshrIBJHkfgRwQjdTeoa.append(cxqyGFuLAMzshrIBJHkfgRwQjdTeDt.get('name'))
   if cxqyGFuLAMzshrIBJHkfgRwQjdTeDt.get('role')=='DIRECTOR':cxqyGFuLAMzshrIBJHkfgRwQjdTeoY.append(cxqyGFuLAMzshrIBJHkfgRwQjdTeDt.get('name'))
  if cxqyGFuLAMzshrIBJHkfgRwQjdTeVX(cxqyGFuLAMzshrIBJHkfgRwQjdTeoa)>0:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeoi['saveinfo']['infoLabels']['cast'] =cxqyGFuLAMzshrIBJHkfgRwQjdTeoa
  if cxqyGFuLAMzshrIBJHkfgRwQjdTeVX(cxqyGFuLAMzshrIBJHkfgRwQjdTeoY)>0:
   cxqyGFuLAMzshrIBJHkfgRwQjdTeoi['saveinfo']['infoLabels']['director']=cxqyGFuLAMzshrIBJHkfgRwQjdTeoY
  return cxqyGFuLAMzshrIBJHkfgRwQjdTeoi
# Created by pyminifier (https://github.com/liftoff/pyminifier)
