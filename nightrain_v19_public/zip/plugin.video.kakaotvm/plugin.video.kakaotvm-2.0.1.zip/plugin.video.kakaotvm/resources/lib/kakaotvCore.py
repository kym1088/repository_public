__author__="NightRain"
BLVqMysbnkcwdhmOztjIHoYfCeDQGT=object
BLVqMysbnkcwdhmOztjIHoYfCeDQGu=None
BLVqMysbnkcwdhmOztjIHoYfCeDQGJ=False
BLVqMysbnkcwdhmOztjIHoYfCeDQGl=True
BLVqMysbnkcwdhmOztjIHoYfCeDQGN=str
BLVqMysbnkcwdhmOztjIHoYfCeDQGK=int
BLVqMysbnkcwdhmOztjIHoYfCeDQGX=Exception
BLVqMysbnkcwdhmOztjIHoYfCeDQGa=print
import urllib
import re
import json
import requests
import datetime
import time
from bs4 import BeautifulSoup
class BLVqMysbnkcwdhmOztjIHoYfCeDQpg(BLVqMysbnkcwdhmOztjIHoYfCeDQGT):
 def __init__(BLVqMysbnkcwdhmOztjIHoYfCeDQpG):
  BLVqMysbnkcwdhmOztjIHoYfCeDQpG.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36'
  BLVqMysbnkcwdhmOztjIHoYfCeDQpG.APP_VERSION ='98.0.4758.102' 
  BLVqMysbnkcwdhmOztjIHoYfCeDQpG.DEFAULT_HEADER ={'user-agent':BLVqMysbnkcwdhmOztjIHoYfCeDQpG.USER_AGENT}
  BLVqMysbnkcwdhmOztjIHoYfCeDQpG.API_DOMAIN ='https://tv.kakao.com'
  BLVqMysbnkcwdhmOztjIHoYfCeDQpG.HTTPTAG ='https:'
  BLVqMysbnkcwdhmOztjIHoYfCeDQpG.CHANNEL_LIMIT =21
  BLVqMysbnkcwdhmOztjIHoYfCeDQpG.PAGE_LIMIT =20
  BLVqMysbnkcwdhmOztjIHoYfCeDQpG.KK_SESSION_COOKIES1=''
  BLVqMysbnkcwdhmOztjIHoYfCeDQpG.KK_SESSION_COOKIES2=''
  BLVqMysbnkcwdhmOztjIHoYfCeDQpG.KK_SESSION_COOKIES3=''
 def callRequestCookies(BLVqMysbnkcwdhmOztjIHoYfCeDQpG,jobtype,BLVqMysbnkcwdhmOztjIHoYfCeDQpx,payload=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,params=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,headers=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,cookies=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,redirects=BLVqMysbnkcwdhmOztjIHoYfCeDQGJ):
  BLVqMysbnkcwdhmOztjIHoYfCeDQpi=BLVqMysbnkcwdhmOztjIHoYfCeDQpG.DEFAULT_HEADER
  if headers:BLVqMysbnkcwdhmOztjIHoYfCeDQpi.update(headers)
  if jobtype=='Get':
   BLVqMysbnkcwdhmOztjIHoYfCeDQpr=requests.get(BLVqMysbnkcwdhmOztjIHoYfCeDQpx,params=params,headers=BLVqMysbnkcwdhmOztjIHoYfCeDQpi,cookies=cookies,allow_redirects=redirects)
  else:
   BLVqMysbnkcwdhmOztjIHoYfCeDQpr=requests.post(BLVqMysbnkcwdhmOztjIHoYfCeDQpx,data=payload,params=params,headers=BLVqMysbnkcwdhmOztjIHoYfCeDQpi,cookies=cookies,allow_redirects=redirects)
  return BLVqMysbnkcwdhmOztjIHoYfCeDQpr
 def Get_Now_Datetime(BLVqMysbnkcwdhmOztjIHoYfCeDQpG):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_Channel_Group(BLVqMysbnkcwdhmOztjIHoYfCeDQpG):
  BLVqMysbnkcwdhmOztjIHoYfCeDQpP=[]
  try:
   BLVqMysbnkcwdhmOztjIHoYfCeDQpx=BLVqMysbnkcwdhmOztjIHoYfCeDQpG.API_DOMAIN 
   BLVqMysbnkcwdhmOztjIHoYfCeDQpR=BLVqMysbnkcwdhmOztjIHoYfCeDQpG.callRequestCookies('Get',BLVqMysbnkcwdhmOztjIHoYfCeDQpx,payload=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,params=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,headers=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,cookies=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,redirects=BLVqMysbnkcwdhmOztjIHoYfCeDQGl)
   if BLVqMysbnkcwdhmOztjIHoYfCeDQpR.status_code!=200:return[]
   BLVqMysbnkcwdhmOztjIHoYfCeDQpE=BeautifulSoup(BLVqMysbnkcwdhmOztjIHoYfCeDQpR.text,'html.parser')
   BLVqMysbnkcwdhmOztjIHoYfCeDQpE=BLVqMysbnkcwdhmOztjIHoYfCeDQpE.select_one('#mArticle > div.tv_recommend > div.recommend_tab')
   BLVqMysbnkcwdhmOztjIHoYfCeDQpT=BLVqMysbnkcwdhmOztjIHoYfCeDQpE.findAll('a')
   for BLVqMysbnkcwdhmOztjIHoYfCeDQpu in BLVqMysbnkcwdhmOztjIHoYfCeDQpT:
    BLVqMysbnkcwdhmOztjIHoYfCeDQpP.append(BLVqMysbnkcwdhmOztjIHoYfCeDQpu.text.replace('#',''))
  except:
   return[]
  return BLVqMysbnkcwdhmOztjIHoYfCeDQpP
 def Get_Channel_List(BLVqMysbnkcwdhmOztjIHoYfCeDQpG,categoryNm,page_int):
  BLVqMysbnkcwdhmOztjIHoYfCeDQpJ=[]
  BLVqMysbnkcwdhmOztjIHoYfCeDQpl=BLVqMysbnkcwdhmOztjIHoYfCeDQGJ
  try:
   BLVqMysbnkcwdhmOztjIHoYfCeDQpx=BLVqMysbnkcwdhmOztjIHoYfCeDQpG.API_DOMAIN+'/api/v1/ft/featured/web/top/recommendChannels' 
   BLVqMysbnkcwdhmOztjIHoYfCeDQpN={'tag':categoryNm,'fields':'-category,user,channelSkinData,tagList,-bannerImageUrlHistory,-profileImageUrlHistory','size':BLVqMysbnkcwdhmOztjIHoYfCeDQpG.CHANNEL_LIMIT,'page':BLVqMysbnkcwdhmOztjIHoYfCeDQGN(page_int),}
   BLVqMysbnkcwdhmOztjIHoYfCeDQpR=BLVqMysbnkcwdhmOztjIHoYfCeDQpG.callRequestCookies('Get',BLVqMysbnkcwdhmOztjIHoYfCeDQpx,payload=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,params=BLVqMysbnkcwdhmOztjIHoYfCeDQpN,headers=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,cookies=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,redirects=BLVqMysbnkcwdhmOztjIHoYfCeDQGl)
   if BLVqMysbnkcwdhmOztjIHoYfCeDQpR.status_code!=200:return[],BLVqMysbnkcwdhmOztjIHoYfCeDQGJ
   BLVqMysbnkcwdhmOztjIHoYfCeDQpK=json.loads(BLVqMysbnkcwdhmOztjIHoYfCeDQpR.text)
   if BLVqMysbnkcwdhmOztjIHoYfCeDQpK.get('hasMore')==BLVqMysbnkcwdhmOztjIHoYfCeDQGl:BLVqMysbnkcwdhmOztjIHoYfCeDQpl=BLVqMysbnkcwdhmOztjIHoYfCeDQGl
   BLVqMysbnkcwdhmOztjIHoYfCeDQpX=BLVqMysbnkcwdhmOztjIHoYfCeDQpK.get('list')
   for BLVqMysbnkcwdhmOztjIHoYfCeDQpa in BLVqMysbnkcwdhmOztjIHoYfCeDQpX:
    BLVqMysbnkcwdhmOztjIHoYfCeDQpS =BLVqMysbnkcwdhmOztjIHoYfCeDQpa.get('channelSkinData').get('profileImageUrl').replace('http://','https://')
    BLVqMysbnkcwdhmOztjIHoYfCeDQpW =BLVqMysbnkcwdhmOztjIHoYfCeDQpa.get('channelSkinData').get('bannerImageUrl').replace('http://','https://')
    BLVqMysbnkcwdhmOztjIHoYfCeDQpU={'channelId':BLVqMysbnkcwdhmOztjIHoYfCeDQpa.get('id'),'title':BLVqMysbnkcwdhmOztjIHoYfCeDQpa.get('name'),'synopsis':BLVqMysbnkcwdhmOztjIHoYfCeDQpa.get('description'),'tagList':BLVqMysbnkcwdhmOztjIHoYfCeDQpa.get('tagList'),'thumbnail':{'poster':BLVqMysbnkcwdhmOztjIHoYfCeDQpS,'thumb':BLVqMysbnkcwdhmOztjIHoYfCeDQpS,'fanart':BLVqMysbnkcwdhmOztjIHoYfCeDQpW}}
    BLVqMysbnkcwdhmOztjIHoYfCeDQpJ.append(BLVqMysbnkcwdhmOztjIHoYfCeDQpU)
  except:
   return[],BLVqMysbnkcwdhmOztjIHoYfCeDQGJ
  return BLVqMysbnkcwdhmOztjIHoYfCeDQpJ,BLVqMysbnkcwdhmOztjIHoYfCeDQpl
 def Get_Channel_Playlist(BLVqMysbnkcwdhmOztjIHoYfCeDQpG,BLVqMysbnkcwdhmOztjIHoYfCeDQgA):
  BLVqMysbnkcwdhmOztjIHoYfCeDQpF=[]
  try:
   BLVqMysbnkcwdhmOztjIHoYfCeDQpx=BLVqMysbnkcwdhmOztjIHoYfCeDQpG.API_DOMAIN+'/channel/%s/playlist'%(BLVqMysbnkcwdhmOztjIHoYfCeDQgA)
   BLVqMysbnkcwdhmOztjIHoYfCeDQpR=BLVqMysbnkcwdhmOztjIHoYfCeDQpG.callRequestCookies('Get',BLVqMysbnkcwdhmOztjIHoYfCeDQpx,payload=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,params=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,headers=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,cookies=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,redirects=BLVqMysbnkcwdhmOztjIHoYfCeDQGl)
   if BLVqMysbnkcwdhmOztjIHoYfCeDQpR.status_code!=200:return[]
   BLVqMysbnkcwdhmOztjIHoYfCeDQpE=BeautifulSoup(BLVqMysbnkcwdhmOztjIHoYfCeDQpR.text,'html.parser')
   BLVqMysbnkcwdhmOztjIHoYfCeDQpE=BLVqMysbnkcwdhmOztjIHoYfCeDQpE.select_one('#mArticle > div.inven_cont > ul')
   BLVqMysbnkcwdhmOztjIHoYfCeDQpA=BLVqMysbnkcwdhmOztjIHoYfCeDQpE.findAll('li',{'class':'playlist_content_li'})
   for BLVqMysbnkcwdhmOztjIHoYfCeDQpu in BLVqMysbnkcwdhmOztjIHoYfCeDQpA:
    BLVqMysbnkcwdhmOztjIHoYfCeDQgp=BLVqMysbnkcwdhmOztjIHoYfCeDQpu.get('data-item-id')
    BLVqMysbnkcwdhmOztjIHoYfCeDQgG =BLVqMysbnkcwdhmOztjIHoYfCeDQpu.get('data-count')
    BLVqMysbnkcwdhmOztjIHoYfCeDQgi =BLVqMysbnkcwdhmOztjIHoYfCeDQpu.find('img',{'class':'thumb_img'})
    BLVqMysbnkcwdhmOztjIHoYfCeDQgr=BLVqMysbnkcwdhmOztjIHoYfCeDQgi.get('alt')
    BLVqMysbnkcwdhmOztjIHoYfCeDQgv =BLVqMysbnkcwdhmOztjIHoYfCeDQpG.HTTPTAG+BLVqMysbnkcwdhmOztjIHoYfCeDQgi.get('src')
    BLVqMysbnkcwdhmOztjIHoYfCeDQpU={'playlistId':BLVqMysbnkcwdhmOztjIHoYfCeDQgp,'playlistNm':BLVqMysbnkcwdhmOztjIHoYfCeDQgr,'thumbnail':BLVqMysbnkcwdhmOztjIHoYfCeDQgv.replace('http://','https://'),'vodCount':BLVqMysbnkcwdhmOztjIHoYfCeDQgG,}
    BLVqMysbnkcwdhmOztjIHoYfCeDQpF.append(BLVqMysbnkcwdhmOztjIHoYfCeDQpU)
  except:
   return[]
  return BLVqMysbnkcwdhmOztjIHoYfCeDQpF
 def Get_Episode_List(BLVqMysbnkcwdhmOztjIHoYfCeDQpG,BLVqMysbnkcwdhmOztjIHoYfCeDQgA,BLVqMysbnkcwdhmOztjIHoYfCeDQgp):
  BLVqMysbnkcwdhmOztjIHoYfCeDQgP=[]
  try:
   BLVqMysbnkcwdhmOztjIHoYfCeDQpx=BLVqMysbnkcwdhmOztjIHoYfCeDQpG.API_DOMAIN+'/channel/%s/playlist/%s'%(BLVqMysbnkcwdhmOztjIHoYfCeDQgA,BLVqMysbnkcwdhmOztjIHoYfCeDQgp)
   BLVqMysbnkcwdhmOztjIHoYfCeDQpR=BLVqMysbnkcwdhmOztjIHoYfCeDQpG.callRequestCookies('Get',BLVqMysbnkcwdhmOztjIHoYfCeDQpx,payload=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,params=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,headers=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,cookies=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,redirects=BLVqMysbnkcwdhmOztjIHoYfCeDQGl)
   if BLVqMysbnkcwdhmOztjIHoYfCeDQpR.status_code!=200:return[]
   BLVqMysbnkcwdhmOztjIHoYfCeDQpE=BeautifulSoup(BLVqMysbnkcwdhmOztjIHoYfCeDQpR.text,'html.parser')
   BLVqMysbnkcwdhmOztjIHoYfCeDQpE=BLVqMysbnkcwdhmOztjIHoYfCeDQpE.select_one('#playerPlaylist > ul.list_plist.dev_added_class_clips_plist')
   BLVqMysbnkcwdhmOztjIHoYfCeDQpA=BLVqMysbnkcwdhmOztjIHoYfCeDQpE.findAll('li')
   for BLVqMysbnkcwdhmOztjIHoYfCeDQpu in BLVqMysbnkcwdhmOztjIHoYfCeDQpA:
    BLVqMysbnkcwdhmOztjIHoYfCeDQgx =BLVqMysbnkcwdhmOztjIHoYfCeDQpu.get('data-item-id')
    BLVqMysbnkcwdhmOztjIHoYfCeDQgR=BLVqMysbnkcwdhmOztjIHoYfCeDQpu.get('data-cliplink-id')
    BLVqMysbnkcwdhmOztjIHoYfCeDQgE =BLVqMysbnkcwdhmOztjIHoYfCeDQpu.find('strong',{'class':'tit_item'}).text
    BLVqMysbnkcwdhmOztjIHoYfCeDQgT =BLVqMysbnkcwdhmOztjIHoYfCeDQpu.find('span',{'class':'txt_charge'})
    if BLVqMysbnkcwdhmOztjIHoYfCeDQgT!=BLVqMysbnkcwdhmOztjIHoYfCeDQGu:BLVqMysbnkcwdhmOztjIHoYfCeDQgT=BLVqMysbnkcwdhmOztjIHoYfCeDQgT.text
    else:BLVqMysbnkcwdhmOztjIHoYfCeDQgT=''
    BLVqMysbnkcwdhmOztjIHoYfCeDQgi =BLVqMysbnkcwdhmOztjIHoYfCeDQpu.find('img',{'class':'thumb_img'})
    BLVqMysbnkcwdhmOztjIHoYfCeDQgv =BLVqMysbnkcwdhmOztjIHoYfCeDQpG.HTTPTAG+BLVqMysbnkcwdhmOztjIHoYfCeDQgi.get('src')
    BLVqMysbnkcwdhmOztjIHoYfCeDQpU={'clipLinkId':BLVqMysbnkcwdhmOztjIHoYfCeDQgR,'clipTitle':BLVqMysbnkcwdhmOztjIHoYfCeDQgE,'chargeTxt':BLVqMysbnkcwdhmOztjIHoYfCeDQgT,'thumbnail':BLVqMysbnkcwdhmOztjIHoYfCeDQgv,}
    BLVqMysbnkcwdhmOztjIHoYfCeDQgP.insert(0,BLVqMysbnkcwdhmOztjIHoYfCeDQpU)
  except:
   return[]
  return BLVqMysbnkcwdhmOztjIHoYfCeDQgP
 def GetStreamingURL(BLVqMysbnkcwdhmOztjIHoYfCeDQpG,BLVqMysbnkcwdhmOztjIHoYfCeDQgA,BLVqMysbnkcwdhmOztjIHoYfCeDQgR,quality_str='HIGH4'):
  BLVqMysbnkcwdhmOztjIHoYfCeDQgu={}
  try:
   BLVqMysbnkcwdhmOztjIHoYfCeDQpx=BLVqMysbnkcwdhmOztjIHoYfCeDQpG.API_DOMAIN+'/katz/v3/ft/cliplink/{}/readyNplay'.format(BLVqMysbnkcwdhmOztjIHoYfCeDQgR)
   BLVqMysbnkcwdhmOztjIHoYfCeDQgJ={'accept-encoding':'gzip, deflate, br','cache-control':'no-cache','content-type':'application/x-www-form-urlencoded','pragma':'no-cache',}
   BLVqMysbnkcwdhmOztjIHoYfCeDQpN={'player':'monet_html5','referer':'https://tv.kakao.com/channel/{}/cliplink/{}'.format(BLVqMysbnkcwdhmOztjIHoYfCeDQgA,BLVqMysbnkcwdhmOztjIHoYfCeDQgR),'pageReferer':'','uuid':'','profile':quality_str,'service':'kakao_tv','section':'channel','fields':'seekUrl,abrVideoLocationList','playerVersion':'3.11.19','appVersion':BLVqMysbnkcwdhmOztjIHoYfCeDQpG.APP_VERSION,'startPosition':'0','tid':'','dteType':'PC','continuousPlay':'false','autoPlay':'false','contentType':'','drmType':'widevine','ab':'','literalList':'',BLVqMysbnkcwdhmOztjIHoYfCeDQGN(BLVqMysbnkcwdhmOztjIHoYfCeDQGK(time.time()*1000)):'',}
   '''
   cookies = {'TIARA' : '-kQ5qAhfFcGnT1s2d9fhQ4PV__om8CwwK2PfPI.knY-rBYRVad.qWjubR7eFUmMmKwhHGjQ_-aUoe1j9jnlxQnpXsDrbnTTlGUU.EHrPf110', 'webid' : 'dc1f0f6b34e544f3b99968d2342336fc', 'webid_ts' : '1638145418202', '__T_' : '1', '_T_ANO' : 'N1YTRfCXIK2st9wA9mgCg/bv/RwXPizF0YhBSoUIadyI04uTp8TFo3zFIExtYMPUrP0VxYn2Zw4+DYMNiGhZan/+b7NTHBebNjndxiKoYYyen8wifMMzPS2RuyfZzgKFO8PQ8I8OYafre99M91ti3r6PTHR36xY/vJv8mlssYE3EbQYQaINzAsT8pf6ShaxcWryUGZMJ/m5D8TmXtL4FtHxzBJZVgFalNsUGINSVKZ64UXC3Jz1OqWjqO4fQp5jrAAlR8t7a3SXQIVcZb/xsrpz6v5mLQQfa/9X56Y0mo09SCL3+8oNublM34n7m/Xk6Tl6WzOFBWeFb2KzZHJK2Bg==', }
   '''   
   BLVqMysbnkcwdhmOztjIHoYfCeDQpR=BLVqMysbnkcwdhmOztjIHoYfCeDQpG.callRequestCookies('Get',BLVqMysbnkcwdhmOztjIHoYfCeDQpx,payload=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,params=BLVqMysbnkcwdhmOztjIHoYfCeDQpN,headers=BLVqMysbnkcwdhmOztjIHoYfCeDQgJ,cookies=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,redirects=BLVqMysbnkcwdhmOztjIHoYfCeDQGJ)
   if BLVqMysbnkcwdhmOztjIHoYfCeDQpR.status_code!=200:return '',''
   for BLVqMysbnkcwdhmOztjIHoYfCeDQgl in BLVqMysbnkcwdhmOztjIHoYfCeDQpR.cookies:
    if 'res_cookies' not in BLVqMysbnkcwdhmOztjIHoYfCeDQgu:BLVqMysbnkcwdhmOztjIHoYfCeDQgu['res_cookies']={}
    BLVqMysbnkcwdhmOztjIHoYfCeDQgu['res_cookies'][BLVqMysbnkcwdhmOztjIHoYfCeDQgl.name]=BLVqMysbnkcwdhmOztjIHoYfCeDQgl.value
   BLVqMysbnkcwdhmOztjIHoYfCeDQpK=json.loads(BLVqMysbnkcwdhmOztjIHoYfCeDQpR.text)
   BLVqMysbnkcwdhmOztjIHoYfCeDQgu['contentType'] =BLVqMysbnkcwdhmOztjIHoYfCeDQpK.get('videoLocation').get('contentType')
   BLVqMysbnkcwdhmOztjIHoYfCeDQgu['streaming_url']=BLVqMysbnkcwdhmOztjIHoYfCeDQpK.get('videoLocation').get('url')
   if 'token' in BLVqMysbnkcwdhmOztjIHoYfCeDQpK.get('videoLocation'):
    BLVqMysbnkcwdhmOztjIHoYfCeDQgu['drm_license']=BLVqMysbnkcwdhmOztjIHoYfCeDQpK.get('videoLocation').get('token')
   if 'drm_license' in BLVqMysbnkcwdhmOztjIHoYfCeDQgu:
    BLVqMysbnkcwdhmOztjIHoYfCeDQgN =urllib.parse.urlparse(BLVqMysbnkcwdhmOztjIHoYfCeDQgu['streaming_url']) 
    BLVqMysbnkcwdhmOztjIHoYfCeDQgu['streaming_url']=BLVqMysbnkcwdhmOztjIHoYfCeDQgN.scheme+'://'+BLVqMysbnkcwdhmOztjIHoYfCeDQgN.netloc+BLVqMysbnkcwdhmOztjIHoYfCeDQgN.path
   '''
   parseResult   = urllib.parse.urlparse(streaming_url )  # scheme, netloc, path, params, query, fragment
   if parseResult.query:
    baseParams = dict(urllib.parse.parse_qsl(parseResult.query ) ) 
    if 'px-hash' in baseParams:
     for iKey, iValue in baseParams.items():
      cdn_auth = '{}{}={}~'.format(cdn_auth, iKey, iValue )
     streaming_url = parseResult.scheme + '://' + parseResult.netloc + parseResult.path
     cdn_auth = 'dummy=start~{}dummy=end'.format(cdn_auth )
   '''   
  except BLVqMysbnkcwdhmOztjIHoYfCeDQGX as exception:
   BLVqMysbnkcwdhmOztjIHoYfCeDQGa(exception)
   return{}
  return BLVqMysbnkcwdhmOztjIHoYfCeDQgu
 def GetLicense(BLVqMysbnkcwdhmOztjIHoYfCeDQpG,tokon):
  BLVqMysbnkcwdhmOztjIHoYfCeDQgK=''
  try:
   BLVqMysbnkcwdhmOztjIHoYfCeDQpx='https://drm-license.kakaopage.com/v1/license'
   BLVqMysbnkcwdhmOztjIHoYfCeDQgX={'token':tokon,'provider':'kakaotv','payload':'CAQ=',}
   BLVqMysbnkcwdhmOztjIHoYfCeDQpR=BLVqMysbnkcwdhmOztjIHoYfCeDQpG.callRequestCookies('Post',BLVqMysbnkcwdhmOztjIHoYfCeDQpx,payload=BLVqMysbnkcwdhmOztjIHoYfCeDQgX,params=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,headers=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,cookies=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,redirects=BLVqMysbnkcwdhmOztjIHoYfCeDQGl)
   BLVqMysbnkcwdhmOztjIHoYfCeDQgK=BLVqMysbnkcwdhmOztjIHoYfCeDQpR.json().get('payload')
  except BLVqMysbnkcwdhmOztjIHoYfCeDQGX as exception:
   BLVqMysbnkcwdhmOztjIHoYfCeDQGa(exception)
   return ''
  return BLVqMysbnkcwdhmOztjIHoYfCeDQgK
 def GetLiveURL(BLVqMysbnkcwdhmOztjIHoYfCeDQpG,BLVqMysbnkcwdhmOztjIHoYfCeDQgA,BLVqMysbnkcwdhmOztjIHoYfCeDQGg,quality_str='HIGH4'):
  BLVqMysbnkcwdhmOztjIHoYfCeDQgu={}
  try:
   BLVqMysbnkcwdhmOztjIHoYfCeDQpx=BLVqMysbnkcwdhmOztjIHoYfCeDQpG.API_DOMAIN+'/katz/v2/ft/livelink/{}/readyNplay'.format(BLVqMysbnkcwdhmOztjIHoYfCeDQGg)
   BLVqMysbnkcwdhmOztjIHoYfCeDQpN={'player':'monet_html5','referer':'https://tv.kakao.com/channel/{}/livelink/{}'.format(BLVqMysbnkcwdhmOztjIHoYfCeDQgA,BLVqMysbnkcwdhmOztjIHoYfCeDQGg),'pageReferer':'','uuid':'','service':'kakao_tv','section':'kakao_tv','dteType':'PC','profile':quality_str,'playerVersion':'3.11.19','autoPlay':'false','liveLinkId':BLVqMysbnkcwdhmOztjIHoYfCeDQGg,'contentType':'HLS','password':'','ab':'','literallist':'',BLVqMysbnkcwdhmOztjIHoYfCeDQGN(BLVqMysbnkcwdhmOztjIHoYfCeDQGK(time.time()*1000)):'',}
   BLVqMysbnkcwdhmOztjIHoYfCeDQpR=BLVqMysbnkcwdhmOztjIHoYfCeDQpG.callRequestCookies('Get',BLVqMysbnkcwdhmOztjIHoYfCeDQpx,payload=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,params=BLVqMysbnkcwdhmOztjIHoYfCeDQpN,headers=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,cookies=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,redirects=BLVqMysbnkcwdhmOztjIHoYfCeDQGl)
   if BLVqMysbnkcwdhmOztjIHoYfCeDQpR.status_code!=200:return '',''
   BLVqMysbnkcwdhmOztjIHoYfCeDQpK=json.loads(BLVqMysbnkcwdhmOztjIHoYfCeDQpR.text)
   BLVqMysbnkcwdhmOztjIHoYfCeDQgu['contentType'] =BLVqMysbnkcwdhmOztjIHoYfCeDQpK.get('videoLocation').get('contentType')
   BLVqMysbnkcwdhmOztjIHoYfCeDQgu['streaming_url']=BLVqMysbnkcwdhmOztjIHoYfCeDQpK.get('videoLocation').get('url')
  except BLVqMysbnkcwdhmOztjIHoYfCeDQGX as exception:
   BLVqMysbnkcwdhmOztjIHoYfCeDQGa(exception)
   return{}
  return BLVqMysbnkcwdhmOztjIHoYfCeDQgu 
 def GetLiveURL_2(BLVqMysbnkcwdhmOztjIHoYfCeDQpG,BLVqMysbnkcwdhmOztjIHoYfCeDQgA,BLVqMysbnkcwdhmOztjIHoYfCeDQGg,quality_str='HIGH4'):
  BLVqMysbnkcwdhmOztjIHoYfCeDQgu={}
  try:
   BLVqMysbnkcwdhmOztjIHoYfCeDQpx=BLVqMysbnkcwdhmOztjIHoYfCeDQpG.API_DOMAIN+'/katz/v3/app/livelink/{}/readyNplay'.format(BLVqMysbnkcwdhmOztjIHoYfCeDQGg)
   BLVqMysbnkcwdhmOztjIHoYfCeDQpN={'player':'monet_android','dteType':'ANDROID','playerVersion':'4.0.1','appVersion':'2.0.7','uuid':'7c2b2f80af8c8d01620cd8b2b06ed5ca','service':'playball','section':'player','section2':'','profile':'HIGH4','contentType':'NPP','referer':'','connectionType':'wifi','autoPlay':'false','continuousPlay':'false','drmType':'widevine',}
   BLVqMysbnkcwdhmOztjIHoYfCeDQpR=BLVqMysbnkcwdhmOztjIHoYfCeDQpG.callRequestCookies('Get',BLVqMysbnkcwdhmOztjIHoYfCeDQpx,payload=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,params=BLVqMysbnkcwdhmOztjIHoYfCeDQpN,headers=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,cookies=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,redirects=BLVqMysbnkcwdhmOztjIHoYfCeDQGl)
   BLVqMysbnkcwdhmOztjIHoYfCeDQGa(BLVqMysbnkcwdhmOztjIHoYfCeDQpR)
   if BLVqMysbnkcwdhmOztjIHoYfCeDQpR.status_code!=200:return '',''
   BLVqMysbnkcwdhmOztjIHoYfCeDQpK=json.loads(BLVqMysbnkcwdhmOztjIHoYfCeDQpR.text)
   BLVqMysbnkcwdhmOztjIHoYfCeDQgu['contentType'] =BLVqMysbnkcwdhmOztjIHoYfCeDQpK.get('videoLocation').get('contentType')
   BLVqMysbnkcwdhmOztjIHoYfCeDQgu['streaming_url']=BLVqMysbnkcwdhmOztjIHoYfCeDQpK.get('videoLocation').get('url')
  except BLVqMysbnkcwdhmOztjIHoYfCeDQGX as exception:
   BLVqMysbnkcwdhmOztjIHoYfCeDQGa(exception)
   return{}
  return BLVqMysbnkcwdhmOztjIHoYfCeDQgu 
 def Get_Original_List(BLVqMysbnkcwdhmOztjIHoYfCeDQpG,page_int,lastId):
  BLVqMysbnkcwdhmOztjIHoYfCeDQga=[]
  BLVqMysbnkcwdhmOztjIHoYfCeDQpl=BLVqMysbnkcwdhmOztjIHoYfCeDQGJ
  try:
   BLVqMysbnkcwdhmOztjIHoYfCeDQpx=BLVqMysbnkcwdhmOztjIHoYfCeDQpG.API_DOMAIN+'/api/v1/ft/home/category/original'
   BLVqMysbnkcwdhmOztjIHoYfCeDQpN={'fields':'channel,-user,-clipChapterThumbnailList,-tagList,-service','size':BLVqMysbnkcwdhmOztjIHoYfCeDQGN(BLVqMysbnkcwdhmOztjIHoYfCeDQpG.PAGE_LIMIT),'page':BLVqMysbnkcwdhmOztjIHoYfCeDQGN(page_int),'after':lastId,}
   BLVqMysbnkcwdhmOztjIHoYfCeDQpR=BLVqMysbnkcwdhmOztjIHoYfCeDQpG.callRequestCookies('Get',BLVqMysbnkcwdhmOztjIHoYfCeDQpx,payload=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,params=BLVqMysbnkcwdhmOztjIHoYfCeDQpN,headers=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,cookies=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,redirects=BLVqMysbnkcwdhmOztjIHoYfCeDQGl)
   if BLVqMysbnkcwdhmOztjIHoYfCeDQpR.status_code!=200:return[],BLVqMysbnkcwdhmOztjIHoYfCeDQGJ
   BLVqMysbnkcwdhmOztjIHoYfCeDQpK=json.loads(BLVqMysbnkcwdhmOztjIHoYfCeDQpR.text)
   if BLVqMysbnkcwdhmOztjIHoYfCeDQpK.get('hasMore')==BLVqMysbnkcwdhmOztjIHoYfCeDQGl:BLVqMysbnkcwdhmOztjIHoYfCeDQpl=BLVqMysbnkcwdhmOztjIHoYfCeDQGl
   BLVqMysbnkcwdhmOztjIHoYfCeDQpX=BLVqMysbnkcwdhmOztjIHoYfCeDQpK.get('list')
   for BLVqMysbnkcwdhmOztjIHoYfCeDQpa in BLVqMysbnkcwdhmOztjIHoYfCeDQpX:
    BLVqMysbnkcwdhmOztjIHoYfCeDQgE =BLVqMysbnkcwdhmOztjIHoYfCeDQpa.get('displayTitle')
    BLVqMysbnkcwdhmOztjIHoYfCeDQgS =BLVqMysbnkcwdhmOztjIHoYfCeDQpa.get('clip').get('thumbnailUrl').replace('http://','https://')
    BLVqMysbnkcwdhmOztjIHoYfCeDQgR=BLVqMysbnkcwdhmOztjIHoYfCeDQpa.get('id')
    BLVqMysbnkcwdhmOztjIHoYfCeDQgW =BLVqMysbnkcwdhmOztjIHoYfCeDQpa.get('clip').get('duration')
    BLVqMysbnkcwdhmOztjIHoYfCeDQgU =BLVqMysbnkcwdhmOztjIHoYfCeDQpa.get('channel').get('name')
    BLVqMysbnkcwdhmOztjIHoYfCeDQgF =BLVqMysbnkcwdhmOztjIHoYfCeDQpa.get('channel').get('description')
    BLVqMysbnkcwdhmOztjIHoYfCeDQgA =BLVqMysbnkcwdhmOztjIHoYfCeDQpa.get('channelId')
    BLVqMysbnkcwdhmOztjIHoYfCeDQpU={'clipTitle':BLVqMysbnkcwdhmOztjIHoYfCeDQgE,'thumbnail':BLVqMysbnkcwdhmOztjIHoYfCeDQgS,'clipLinkId':BLVqMysbnkcwdhmOztjIHoYfCeDQgR,'duration':BLVqMysbnkcwdhmOztjIHoYfCeDQgW,'channelNm':BLVqMysbnkcwdhmOztjIHoYfCeDQgU,'channelDs':BLVqMysbnkcwdhmOztjIHoYfCeDQgF,'channelId':BLVqMysbnkcwdhmOztjIHoYfCeDQgA,}
    BLVqMysbnkcwdhmOztjIHoYfCeDQga.append(BLVqMysbnkcwdhmOztjIHoYfCeDQpU)
  except:
   return[],BLVqMysbnkcwdhmOztjIHoYfCeDQGJ
  return BLVqMysbnkcwdhmOztjIHoYfCeDQga,BLVqMysbnkcwdhmOztjIHoYfCeDQpl
 def Get_Live_List(BLVqMysbnkcwdhmOztjIHoYfCeDQpG,page_int):
  BLVqMysbnkcwdhmOztjIHoYfCeDQGp=[]
  BLVqMysbnkcwdhmOztjIHoYfCeDQpl=BLVqMysbnkcwdhmOztjIHoYfCeDQGJ
  try:
   BLVqMysbnkcwdhmOztjIHoYfCeDQpx=BLVqMysbnkcwdhmOztjIHoYfCeDQpG.API_DOMAIN+'/api/v1/ft/home/livelinks'
   BLVqMysbnkcwdhmOztjIHoYfCeDQpN={'tab':'all','fields':'ccuCount,isShowCcuCount,thumbnailUrl,channel,live','sort':'CcuCount','size':BLVqMysbnkcwdhmOztjIHoYfCeDQGN(BLVqMysbnkcwdhmOztjIHoYfCeDQpG.PAGE_LIMIT),'page':BLVqMysbnkcwdhmOztjIHoYfCeDQGN(page_int),}
   BLVqMysbnkcwdhmOztjIHoYfCeDQpR=BLVqMysbnkcwdhmOztjIHoYfCeDQpG.callRequestCookies('Get',BLVqMysbnkcwdhmOztjIHoYfCeDQpx,payload=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,params=BLVqMysbnkcwdhmOztjIHoYfCeDQpN,headers=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,cookies=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,redirects=BLVqMysbnkcwdhmOztjIHoYfCeDQGl)
   if BLVqMysbnkcwdhmOztjIHoYfCeDQpR.status_code!=200:return[],BLVqMysbnkcwdhmOztjIHoYfCeDQGJ
   BLVqMysbnkcwdhmOztjIHoYfCeDQpK=json.loads(BLVqMysbnkcwdhmOztjIHoYfCeDQpR.text)
   if BLVqMysbnkcwdhmOztjIHoYfCeDQpK.get('hasMore')==BLVqMysbnkcwdhmOztjIHoYfCeDQGl:BLVqMysbnkcwdhmOztjIHoYfCeDQpl=BLVqMysbnkcwdhmOztjIHoYfCeDQGl
   BLVqMysbnkcwdhmOztjIHoYfCeDQpX=BLVqMysbnkcwdhmOztjIHoYfCeDQpK.get('list')
   for BLVqMysbnkcwdhmOztjIHoYfCeDQpa in BLVqMysbnkcwdhmOztjIHoYfCeDQpX:
    BLVqMysbnkcwdhmOztjIHoYfCeDQGg =BLVqMysbnkcwdhmOztjIHoYfCeDQpa.get('id')
    BLVqMysbnkcwdhmOztjIHoYfCeDQGi =BLVqMysbnkcwdhmOztjIHoYfCeDQpa.get('displayTitle')
    BLVqMysbnkcwdhmOztjIHoYfCeDQgS =BLVqMysbnkcwdhmOztjIHoYfCeDQpa.get('live').get('thumbnailUrl').replace('http://','https://')
    BLVqMysbnkcwdhmOztjIHoYfCeDQgU=BLVqMysbnkcwdhmOztjIHoYfCeDQpa.get('channel').get('name')
    BLVqMysbnkcwdhmOztjIHoYfCeDQgA=BLVqMysbnkcwdhmOztjIHoYfCeDQpa.get('channelId')
    BLVqMysbnkcwdhmOztjIHoYfCeDQpU={'liveId':BLVqMysbnkcwdhmOztjIHoYfCeDQGg,'liveNm':BLVqMysbnkcwdhmOztjIHoYfCeDQGi,'thumbnail':BLVqMysbnkcwdhmOztjIHoYfCeDQgS,'channelNm':BLVqMysbnkcwdhmOztjIHoYfCeDQgU,'channelId':BLVqMysbnkcwdhmOztjIHoYfCeDQgA,}
    BLVqMysbnkcwdhmOztjIHoYfCeDQGp.append(BLVqMysbnkcwdhmOztjIHoYfCeDQpU)
  except:
   return[],BLVqMysbnkcwdhmOztjIHoYfCeDQGJ
  return BLVqMysbnkcwdhmOztjIHoYfCeDQGp,BLVqMysbnkcwdhmOztjIHoYfCeDQpl
 def GetSearchList(BLVqMysbnkcwdhmOztjIHoYfCeDQpG,search_key,page_int,stype):
  BLVqMysbnkcwdhmOztjIHoYfCeDQGr=[]
  BLVqMysbnkcwdhmOztjIHoYfCeDQpl=BLVqMysbnkcwdhmOztjIHoYfCeDQGJ
  try:
   BLVqMysbnkcwdhmOztjIHoYfCeDQpx=BLVqMysbnkcwdhmOztjIHoYfCeDQpG.API_DOMAIN+'/api/v1/ft/search/'+stype 
   if stype=='channels':
    BLVqMysbnkcwdhmOztjIHoYfCeDQGv='-channelNoticeList,-hasBizChannel,-friendCount,friendChannel'
   else:
    BLVqMysbnkcwdhmOztjIHoYfCeDQGv='-user,-clipChapterThumbnailList,-tagList'
   BLVqMysbnkcwdhmOztjIHoYfCeDQpN={'sort':'Score','q':search_key,'fulllevels':'list','fields':BLVqMysbnkcwdhmOztjIHoYfCeDQGv,'size':BLVqMysbnkcwdhmOztjIHoYfCeDQGN(BLVqMysbnkcwdhmOztjIHoYfCeDQpG.PAGE_LIMIT),'page':BLVqMysbnkcwdhmOztjIHoYfCeDQGN(page_int),}
   BLVqMysbnkcwdhmOztjIHoYfCeDQpR=BLVqMysbnkcwdhmOztjIHoYfCeDQpG.callRequestCookies('Get',BLVqMysbnkcwdhmOztjIHoYfCeDQpx,payload=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,params=BLVqMysbnkcwdhmOztjIHoYfCeDQpN,headers=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,cookies=BLVqMysbnkcwdhmOztjIHoYfCeDQGu,redirects=BLVqMysbnkcwdhmOztjIHoYfCeDQGl)
   if BLVqMysbnkcwdhmOztjIHoYfCeDQpR.status_code!=200:return[],BLVqMysbnkcwdhmOztjIHoYfCeDQGJ
   BLVqMysbnkcwdhmOztjIHoYfCeDQpK=json.loads(BLVqMysbnkcwdhmOztjIHoYfCeDQpR.text)
   if BLVqMysbnkcwdhmOztjIHoYfCeDQpK.get('hasMore')==BLVqMysbnkcwdhmOztjIHoYfCeDQGl:BLVqMysbnkcwdhmOztjIHoYfCeDQpl=BLVqMysbnkcwdhmOztjIHoYfCeDQGl
   BLVqMysbnkcwdhmOztjIHoYfCeDQpX=BLVqMysbnkcwdhmOztjIHoYfCeDQpK.get('list')
   for BLVqMysbnkcwdhmOztjIHoYfCeDQpa in BLVqMysbnkcwdhmOztjIHoYfCeDQpX:
    if stype=='channels':
     BLVqMysbnkcwdhmOztjIHoYfCeDQpS =BLVqMysbnkcwdhmOztjIHoYfCeDQpa.get('channelSkinData').get('profileImageUrl').replace('http://','https://')
     BLVqMysbnkcwdhmOztjIHoYfCeDQpW =BLVqMysbnkcwdhmOztjIHoYfCeDQpa.get('channelSkinData').get('bannerImageUrl').replace('http://','https://')
     BLVqMysbnkcwdhmOztjIHoYfCeDQgA =BLVqMysbnkcwdhmOztjIHoYfCeDQpa.get('id')
     BLVqMysbnkcwdhmOztjIHoYfCeDQGP =BLVqMysbnkcwdhmOztjIHoYfCeDQpa.get('name')
     BLVqMysbnkcwdhmOztjIHoYfCeDQGx =BLVqMysbnkcwdhmOztjIHoYfCeDQpa.get('description')
     BLVqMysbnkcwdhmOztjIHoYfCeDQGR =BLVqMysbnkcwdhmOztjIHoYfCeDQpa.get('tagList')
     BLVqMysbnkcwdhmOztjIHoYfCeDQGE ={'poster':BLVqMysbnkcwdhmOztjIHoYfCeDQpS,'thumb':BLVqMysbnkcwdhmOztjIHoYfCeDQpS,'fanart':BLVqMysbnkcwdhmOztjIHoYfCeDQpW}
     BLVqMysbnkcwdhmOztjIHoYfCeDQpU={'channelId':BLVqMysbnkcwdhmOztjIHoYfCeDQgA,'title':BLVqMysbnkcwdhmOztjIHoYfCeDQGP,'synopsis':BLVqMysbnkcwdhmOztjIHoYfCeDQGx,'tagList':BLVqMysbnkcwdhmOztjIHoYfCeDQGR,'thumbnail':BLVqMysbnkcwdhmOztjIHoYfCeDQGE,}
    else:
     BLVqMysbnkcwdhmOztjIHoYfCeDQgE =BLVqMysbnkcwdhmOztjIHoYfCeDQpa.get('displayTitle')
     BLVqMysbnkcwdhmOztjIHoYfCeDQgS =BLVqMysbnkcwdhmOztjIHoYfCeDQpa.get('clip').get('thumbnailUrl').replace('http://','https://')
     BLVqMysbnkcwdhmOztjIHoYfCeDQgR=BLVqMysbnkcwdhmOztjIHoYfCeDQpa.get('id')
     BLVqMysbnkcwdhmOztjIHoYfCeDQgW =BLVqMysbnkcwdhmOztjIHoYfCeDQpa.get('clip').get('duration')
     BLVqMysbnkcwdhmOztjIHoYfCeDQgU =BLVqMysbnkcwdhmOztjIHoYfCeDQpa.get('channel').get('name')
     BLVqMysbnkcwdhmOztjIHoYfCeDQgF =BLVqMysbnkcwdhmOztjIHoYfCeDQpa.get('channel').get('description')
     BLVqMysbnkcwdhmOztjIHoYfCeDQgA =BLVqMysbnkcwdhmOztjIHoYfCeDQpa.get('channelId')
     BLVqMysbnkcwdhmOztjIHoYfCeDQpU={'title':BLVqMysbnkcwdhmOztjIHoYfCeDQgE,'thumbnail':BLVqMysbnkcwdhmOztjIHoYfCeDQgS,'clipLinkId':BLVqMysbnkcwdhmOztjIHoYfCeDQgR,'duration':BLVqMysbnkcwdhmOztjIHoYfCeDQgW,'channelNm':BLVqMysbnkcwdhmOztjIHoYfCeDQgU,'channelDs':BLVqMysbnkcwdhmOztjIHoYfCeDQgF,'channelId':BLVqMysbnkcwdhmOztjIHoYfCeDQgA,}
    BLVqMysbnkcwdhmOztjIHoYfCeDQGr.append(BLVqMysbnkcwdhmOztjIHoYfCeDQpU)
  except:
   return[],BLVqMysbnkcwdhmOztjIHoYfCeDQGJ
  return BLVqMysbnkcwdhmOztjIHoYfCeDQGr,BLVqMysbnkcwdhmOztjIHoYfCeDQpl
# Created by pyminifier (https://github.com/liftoff/pyminifier)
