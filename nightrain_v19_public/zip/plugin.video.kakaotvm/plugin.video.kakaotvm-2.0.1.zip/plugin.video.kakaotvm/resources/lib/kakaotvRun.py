__author__="NightRain"
XHVvjcSwEdzGnKpFuyJCsoIQghPUOq=object
XHVvjcSwEdzGnKpFuyJCsoIQghPUOA=None
XHVvjcSwEdzGnKpFuyJCsoIQghPUOt=True
XHVvjcSwEdzGnKpFuyJCsoIQghPUOf=False
XHVvjcSwEdzGnKpFuyJCsoIQghPUOm=type
XHVvjcSwEdzGnKpFuyJCsoIQghPUOe=dict
XHVvjcSwEdzGnKpFuyJCsoIQghPUOi=int
XHVvjcSwEdzGnKpFuyJCsoIQghPUOk=str
XHVvjcSwEdzGnKpFuyJCsoIQghPUOL=len
XHVvjcSwEdzGnKpFuyJCsoIQghPUOB=range
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import urllib
import json
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
XHVvjcSwEdzGnKpFuyJCsoIQghPUqt=[{'title':'채널별 보기','mode':'CHANNEL_GROUP','icon':'channel.png'},{'title':'인기 오리지널','mode':'ORIGINAL_LIST','icon':'original.png'},{'title':'인기 라이브 (360P)','mode':'LIVE_LIST','icon':'live.png'},{'title':'-----------------','mode':'XXX'},{'title':'검색','mode':'SEARCH_GROUP','icon':'search.png'},]
XHVvjcSwEdzGnKpFuyJCsoIQghPUqO=['오리지널','스포츠','게임','엔터테인먼트','애니멀','뷰티','푸드','라이프','키즈','뉴스','교양','취미']
XHVvjcSwEdzGnKpFuyJCsoIQghPUqf=[{'title':'채널 검색','mode':'LOCAL_SEARCH','stype':'channels'},{'title':'영상(clip) 검색','mode':'LOCAL_SEARCH','stype':'cliplinks'},]
from kakaotvCore import*
class XHVvjcSwEdzGnKpFuyJCsoIQghPUqA(XHVvjcSwEdzGnKpFuyJCsoIQghPUOq):
 def __init__(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm,XHVvjcSwEdzGnKpFuyJCsoIQghPUqe,XHVvjcSwEdzGnKpFuyJCsoIQghPUqi,XHVvjcSwEdzGnKpFuyJCsoIQghPUqk):
  XHVvjcSwEdzGnKpFuyJCsoIQghPUqm._addon_url =XHVvjcSwEdzGnKpFuyJCsoIQghPUqe
  XHVvjcSwEdzGnKpFuyJCsoIQghPUqm._addon_handle=XHVvjcSwEdzGnKpFuyJCsoIQghPUqi
  XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.main_params =XHVvjcSwEdzGnKpFuyJCsoIQghPUqk
  XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.KakaotvObj =BLVqMysbnkcwdhmOztjIHoYfCeDQpg() 
 def addon_noti(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm,sting):
  try:
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqB=xbmcgui.Dialog()
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqB.notification(__addonname__,sting)
  except:
   XHVvjcSwEdzGnKpFuyJCsoIQghPUOA
 def addon_log(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm,string):
  try:
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqr=string.encode('utf-8','ignore')
  except:
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqr='addonException: addon_log'
  XHVvjcSwEdzGnKpFuyJCsoIQghPUqa=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,XHVvjcSwEdzGnKpFuyJCsoIQghPUqr),level=XHVvjcSwEdzGnKpFuyJCsoIQghPUqa)
 def get_keyboard_input(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm,XHVvjcSwEdzGnKpFuyJCsoIQghPUqY):
  XHVvjcSwEdzGnKpFuyJCsoIQghPUqN=XHVvjcSwEdzGnKpFuyJCsoIQghPUOA
  kb=xbmc.Keyboard()
  kb.setHeading(XHVvjcSwEdzGnKpFuyJCsoIQghPUqY)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqN=kb.getText()
  return XHVvjcSwEdzGnKpFuyJCsoIQghPUqN
 def add_dir(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm,label,sublabel='',img='',infoLabels=XHVvjcSwEdzGnKpFuyJCsoIQghPUOA,isFolder=XHVvjcSwEdzGnKpFuyJCsoIQghPUOt,params='',isLink=XHVvjcSwEdzGnKpFuyJCsoIQghPUOf,ContextMenu=XHVvjcSwEdzGnKpFuyJCsoIQghPUOA):
  XHVvjcSwEdzGnKpFuyJCsoIQghPUqD='%s?%s'%(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm._addon_url,urllib.parse.urlencode(params))
  if sublabel:XHVvjcSwEdzGnKpFuyJCsoIQghPUqY='%s < %s >'%(label,sublabel)
  else: XHVvjcSwEdzGnKpFuyJCsoIQghPUqY=label
  if not img:img='DefaultFolder.png'
  XHVvjcSwEdzGnKpFuyJCsoIQghPUqT=xbmcgui.ListItem(XHVvjcSwEdzGnKpFuyJCsoIQghPUqY)
  if XHVvjcSwEdzGnKpFuyJCsoIQghPUOm(img)==XHVvjcSwEdzGnKpFuyJCsoIQghPUOe:
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqT.setArt(img)
  else:
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqT.setArt({'thumb':img,'poster':img})
  if infoLabels:XHVvjcSwEdzGnKpFuyJCsoIQghPUqT.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqT.setProperty('IsPlayable','true')
  if ContextMenu:XHVvjcSwEdzGnKpFuyJCsoIQghPUqT.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm._addon_handle,XHVvjcSwEdzGnKpFuyJCsoIQghPUqD,XHVvjcSwEdzGnKpFuyJCsoIQghPUqT,isFolder)
 def get_selQuality(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm):
  XHVvjcSwEdzGnKpFuyJCsoIQghPUqW='selected_quality'
  XHVvjcSwEdzGnKpFuyJCsoIQghPUql=['HIGH4','HIGH','MAIN','BASE']
  XHVvjcSwEdzGnKpFuyJCsoIQghPUqR=XHVvjcSwEdzGnKpFuyJCsoIQghPUOi(__addon__.getSetting(XHVvjcSwEdzGnKpFuyJCsoIQghPUqW))
  return XHVvjcSwEdzGnKpFuyJCsoIQghPUql[XHVvjcSwEdzGnKpFuyJCsoIQghPUqR]
 def dp_Main_List(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm,args):
  for XHVvjcSwEdzGnKpFuyJCsoIQghPUqb in XHVvjcSwEdzGnKpFuyJCsoIQghPUqt:
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqY=XHVvjcSwEdzGnKpFuyJCsoIQghPUqb.get('title')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqM=''
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqx={'mode':XHVvjcSwEdzGnKpFuyJCsoIQghPUqb.get('mode'),}
   if XHVvjcSwEdzGnKpFuyJCsoIQghPUqb.get('mode')in['XXX']:
    XHVvjcSwEdzGnKpFuyJCsoIQghPUAq=XHVvjcSwEdzGnKpFuyJCsoIQghPUOf
    XHVvjcSwEdzGnKpFuyJCsoIQghPUAt =XHVvjcSwEdzGnKpFuyJCsoIQghPUOt
   else:
    XHVvjcSwEdzGnKpFuyJCsoIQghPUAq=XHVvjcSwEdzGnKpFuyJCsoIQghPUOt
    XHVvjcSwEdzGnKpFuyJCsoIQghPUAt =XHVvjcSwEdzGnKpFuyJCsoIQghPUOf
   if 'icon' in XHVvjcSwEdzGnKpFuyJCsoIQghPUqb:XHVvjcSwEdzGnKpFuyJCsoIQghPUqM=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',XHVvjcSwEdzGnKpFuyJCsoIQghPUqb.get('icon')) 
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.add_dir(XHVvjcSwEdzGnKpFuyJCsoIQghPUqY,sublabel='',img=XHVvjcSwEdzGnKpFuyJCsoIQghPUqM,infoLabels=XHVvjcSwEdzGnKpFuyJCsoIQghPUOA,isFolder=XHVvjcSwEdzGnKpFuyJCsoIQghPUAq,params=XHVvjcSwEdzGnKpFuyJCsoIQghPUqx,isLink=XHVvjcSwEdzGnKpFuyJCsoIQghPUAt)
  xbmcplugin.endOfDirectory(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm._addon_handle)
 def dp_Channel_GroupList(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm,args):
  XHVvjcSwEdzGnKpFuyJCsoIQghPUAf=XHVvjcSwEdzGnKpFuyJCsoIQghPUqO
  for XHVvjcSwEdzGnKpFuyJCsoIQghPUAm in XHVvjcSwEdzGnKpFuyJCsoIQghPUAf:
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqx={'mode':'CHANNEL_LIST','groupNm':XHVvjcSwEdzGnKpFuyJCsoIQghPUAm,'page':'1',}
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.add_dir(XHVvjcSwEdzGnKpFuyJCsoIQghPUAm,sublabel='',img='',infoLabels=XHVvjcSwEdzGnKpFuyJCsoIQghPUOA,isFolder=XHVvjcSwEdzGnKpFuyJCsoIQghPUOt,params=XHVvjcSwEdzGnKpFuyJCsoIQghPUqx)
  xbmcplugin.endOfDirectory(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm._addon_handle,cacheToDisc=XHVvjcSwEdzGnKpFuyJCsoIQghPUOt)
 def dp_Channel_List(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm,args):
  XHVvjcSwEdzGnKpFuyJCsoIQghPUAi =args.get('groupNm')
  XHVvjcSwEdzGnKpFuyJCsoIQghPUAk =XHVvjcSwEdzGnKpFuyJCsoIQghPUOi(args.get('page'))
  XHVvjcSwEdzGnKpFuyJCsoIQghPUAf,XHVvjcSwEdzGnKpFuyJCsoIQghPUAL=XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.KakaotvObj.Get_Channel_List(XHVvjcSwEdzGnKpFuyJCsoIQghPUAi,XHVvjcSwEdzGnKpFuyJCsoIQghPUAk)
  for XHVvjcSwEdzGnKpFuyJCsoIQghPUAm in XHVvjcSwEdzGnKpFuyJCsoIQghPUAf:
   XHVvjcSwEdzGnKpFuyJCsoIQghPUAB=XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('channelId')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqY =XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('title')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUAr =XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('synopsis')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUAa =XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('tagList')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUAN=XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('thumbnail')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUAD={'mediatype':'tvshow','title':XHVvjcSwEdzGnKpFuyJCsoIQghPUqY,'genre':XHVvjcSwEdzGnKpFuyJCsoIQghPUAa,'plot':XHVvjcSwEdzGnKpFuyJCsoIQghPUAr,}
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqx={'mode':'CH_PLAY_LIST','channelId':XHVvjcSwEdzGnKpFuyJCsoIQghPUAB,'page':'1',}
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.add_dir(XHVvjcSwEdzGnKpFuyJCsoIQghPUqY,sublabel='',img=XHVvjcSwEdzGnKpFuyJCsoIQghPUAN,infoLabels=XHVvjcSwEdzGnKpFuyJCsoIQghPUAD,isFolder=XHVvjcSwEdzGnKpFuyJCsoIQghPUOt,params=XHVvjcSwEdzGnKpFuyJCsoIQghPUqx)
  if XHVvjcSwEdzGnKpFuyJCsoIQghPUAL:
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqx['mode'] ='CHANNEL_LIST' 
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqx['groupNm'] =XHVvjcSwEdzGnKpFuyJCsoIQghPUAi
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqx['page'] =XHVvjcSwEdzGnKpFuyJCsoIQghPUOk(XHVvjcSwEdzGnKpFuyJCsoIQghPUAk+1)
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqY='[B]%s >>[/B]'%'다음 페이지'
   XHVvjcSwEdzGnKpFuyJCsoIQghPUAY=XHVvjcSwEdzGnKpFuyJCsoIQghPUOk(XHVvjcSwEdzGnKpFuyJCsoIQghPUAk+1)
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqM=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.add_dir(XHVvjcSwEdzGnKpFuyJCsoIQghPUqY,sublabel=XHVvjcSwEdzGnKpFuyJCsoIQghPUAY,img=XHVvjcSwEdzGnKpFuyJCsoIQghPUqM,infoLabels=XHVvjcSwEdzGnKpFuyJCsoIQghPUOA,isFolder=XHVvjcSwEdzGnKpFuyJCsoIQghPUOt,params=XHVvjcSwEdzGnKpFuyJCsoIQghPUqx)
  xbmcplugin.setContent(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm._addon_handle,cacheToDisc=XHVvjcSwEdzGnKpFuyJCsoIQghPUOt)
 def dp_Channel_Playlist(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm,args):
  XHVvjcSwEdzGnKpFuyJCsoIQghPUAB =args.get('channelId')
  XHVvjcSwEdzGnKpFuyJCsoIQghPUAf=XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.KakaotvObj.Get_Channel_Playlist(XHVvjcSwEdzGnKpFuyJCsoIQghPUAB)
  for XHVvjcSwEdzGnKpFuyJCsoIQghPUAm in XHVvjcSwEdzGnKpFuyJCsoIQghPUAf:
   XHVvjcSwEdzGnKpFuyJCsoIQghPUAT=XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('playlistId')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUAW=XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('playlistNm')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUAl =XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('vodCount')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUAN =XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('thumbnail')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUAN ={'thumb':XHVvjcSwEdzGnKpFuyJCsoIQghPUAN,'fanart':XHVvjcSwEdzGnKpFuyJCsoIQghPUAN}
   XHVvjcSwEdzGnKpFuyJCsoIQghPUAD={'mediatype':'tvshow','title':XHVvjcSwEdzGnKpFuyJCsoIQghPUAW,'plot':'영상 목록 : %s 개'%(XHVvjcSwEdzGnKpFuyJCsoIQghPUAl),}
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqx={'mode':'EPISODE_LIST','channelId':XHVvjcSwEdzGnKpFuyJCsoIQghPUAB,'playlistId':XHVvjcSwEdzGnKpFuyJCsoIQghPUAT,}
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.add_dir(XHVvjcSwEdzGnKpFuyJCsoIQghPUAW,sublabel='',img=XHVvjcSwEdzGnKpFuyJCsoIQghPUAN,infoLabels=XHVvjcSwEdzGnKpFuyJCsoIQghPUAD,isFolder=XHVvjcSwEdzGnKpFuyJCsoIQghPUOt,params=XHVvjcSwEdzGnKpFuyJCsoIQghPUqx)
  xbmcplugin.setContent(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm._addon_handle,cacheToDisc=XHVvjcSwEdzGnKpFuyJCsoIQghPUOt)
 def dp_Episode_List(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm,args):
  XHVvjcSwEdzGnKpFuyJCsoIQghPUAB =args.get('channelId')
  XHVvjcSwEdzGnKpFuyJCsoIQghPUAT =args.get('playlistId')
  XHVvjcSwEdzGnKpFuyJCsoIQghPUAf=XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.KakaotvObj.Get_Episode_List(XHVvjcSwEdzGnKpFuyJCsoIQghPUAB,XHVvjcSwEdzGnKpFuyJCsoIQghPUAT)
  for XHVvjcSwEdzGnKpFuyJCsoIQghPUAm in XHVvjcSwEdzGnKpFuyJCsoIQghPUAf:
   XHVvjcSwEdzGnKpFuyJCsoIQghPUAR=XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('clipLinkId')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUAb =XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('clipTitle')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUAM =XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('chargeTxt')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUAN =XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('thumbnail')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUAN ={'thumb':XHVvjcSwEdzGnKpFuyJCsoIQghPUAN,'fanart':XHVvjcSwEdzGnKpFuyJCsoIQghPUAN}
   XHVvjcSwEdzGnKpFuyJCsoIQghPUAD={'mediatype':'episode','title':XHVvjcSwEdzGnKpFuyJCsoIQghPUAb,'plot':'%s\n\n%s'%(XHVvjcSwEdzGnKpFuyJCsoIQghPUAb,XHVvjcSwEdzGnKpFuyJCsoIQghPUAM)}
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqx={'mode':'VOD','channelId':XHVvjcSwEdzGnKpFuyJCsoIQghPUAB,'playlistId':XHVvjcSwEdzGnKpFuyJCsoIQghPUAT,'clipLinkId':XHVvjcSwEdzGnKpFuyJCsoIQghPUAR,}
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.add_dir(XHVvjcSwEdzGnKpFuyJCsoIQghPUAb,sublabel=XHVvjcSwEdzGnKpFuyJCsoIQghPUAM,img=XHVvjcSwEdzGnKpFuyJCsoIQghPUAN,infoLabels=XHVvjcSwEdzGnKpFuyJCsoIQghPUAD,isFolder=XHVvjcSwEdzGnKpFuyJCsoIQghPUOf,params=XHVvjcSwEdzGnKpFuyJCsoIQghPUqx)
  xbmcplugin.setContent(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm._addon_handle,cacheToDisc=XHVvjcSwEdzGnKpFuyJCsoIQghPUOt)
 def play_VIDEO(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm,args):
  XHVvjcSwEdzGnKpFuyJCsoIQghPUAx =args.get('mode')
  XHVvjcSwEdzGnKpFuyJCsoIQghPUAB =args.get('channelId')
  XHVvjcSwEdzGnKpFuyJCsoIQghPUAR =args.get('clipLinkId')
  XHVvjcSwEdzGnKpFuyJCsoIQghPUtq =XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.get_selQuality()
  XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.addon_log('channelId  = '+XHVvjcSwEdzGnKpFuyJCsoIQghPUAB)
  XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.addon_log('clipLinkId = '+XHVvjcSwEdzGnKpFuyJCsoIQghPUAR)
  if XHVvjcSwEdzGnKpFuyJCsoIQghPUAx=='VOD':
   XHVvjcSwEdzGnKpFuyJCsoIQghPUtA=XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.KakaotvObj.GetStreamingURL(XHVvjcSwEdzGnKpFuyJCsoIQghPUAB,XHVvjcSwEdzGnKpFuyJCsoIQghPUAR,XHVvjcSwEdzGnKpFuyJCsoIQghPUtq)
  else:
   XHVvjcSwEdzGnKpFuyJCsoIQghPUtA=XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.KakaotvObj.GetLiveURL(XHVvjcSwEdzGnKpFuyJCsoIQghPUAB,XHVvjcSwEdzGnKpFuyJCsoIQghPUAR,XHVvjcSwEdzGnKpFuyJCsoIQghPUtq)
  if 'streaming_url' not in XHVvjcSwEdzGnKpFuyJCsoIQghPUtA:
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.addon_noti(__language__(30901).encode('utf8'))
   return
  if 'res_cookies' in XHVvjcSwEdzGnKpFuyJCsoIQghPUtA and 'drm_license' in XHVvjcSwEdzGnKpFuyJCsoIQghPUtA:
   XHVvjcSwEdzGnKpFuyJCsoIQghPUtO=''
   for XHVvjcSwEdzGnKpFuyJCsoIQghPUtf,i_value in XHVvjcSwEdzGnKpFuyJCsoIQghPUtA['res_cookies'].items():
    if XHVvjcSwEdzGnKpFuyJCsoIQghPUtO=='':
     XHVvjcSwEdzGnKpFuyJCsoIQghPUtO='{}={}'.format(XHVvjcSwEdzGnKpFuyJCsoIQghPUtf,urllib.parse.quote_plus(i_value))
    else:
     XHVvjcSwEdzGnKpFuyJCsoIQghPUtO='{};{}={}'.format(XHVvjcSwEdzGnKpFuyJCsoIQghPUtO,XHVvjcSwEdzGnKpFuyJCsoIQghPUtf,urllib.parse.quote_plus(i_value))
   XHVvjcSwEdzGnKpFuyJCsoIQghPUtA['streaming_url']='{}|Cookie={}'.format(XHVvjcSwEdzGnKpFuyJCsoIQghPUtA['streaming_url'],XHVvjcSwEdzGnKpFuyJCsoIQghPUtO)
  XHVvjcSwEdzGnKpFuyJCsoIQghPUtm=xbmcgui.ListItem(path=XHVvjcSwEdzGnKpFuyJCsoIQghPUtA['streaming_url'])
  XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.addon_log('contentType = '+XHVvjcSwEdzGnKpFuyJCsoIQghPUtA['contentType'])
  XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.addon_log(XHVvjcSwEdzGnKpFuyJCsoIQghPUtA['streaming_url'])
  if XHVvjcSwEdzGnKpFuyJCsoIQghPUAx=='VOD' and 'drm_license' in XHVvjcSwEdzGnKpFuyJCsoIQghPUtA:
   XHVvjcSwEdzGnKpFuyJCsoIQghPUte ='https://drm-license.kakaopage.com/v1/license'
   XHVvjcSwEdzGnKpFuyJCsoIQghPUti ='Content-Type=application%2Fx-www-form-urlencoded'
   XHVvjcSwEdzGnKpFuyJCsoIQghPUtk ='token={}&provider=kakaotv&payload={}'.format(XHVvjcSwEdzGnKpFuyJCsoIQghPUtA['drm_license'],'B{SSM}')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUtL='{}|{}&Cookie={}|{}|JBpayload'.format(XHVvjcSwEdzGnKpFuyJCsoIQghPUte,XHVvjcSwEdzGnKpFuyJCsoIQghPUti,XHVvjcSwEdzGnKpFuyJCsoIQghPUtO,XHVvjcSwEdzGnKpFuyJCsoIQghPUtk)
   XHVvjcSwEdzGnKpFuyJCsoIQghPUtm.setProperty('inputstream','inputstream.adaptive')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUtm.setProperty('inputstream.adaptive.manifest_type','mpd')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUtm.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUtm.setProperty('inputstream.adaptive.license_key',XHVvjcSwEdzGnKpFuyJCsoIQghPUtL)
   XHVvjcSwEdzGnKpFuyJCsoIQghPUtm.setProperty('inputstream.adaptive.stream_headers','User-Agent={}&Cookie={}'.format(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.KakaotvObj.USER_AGENT,XHVvjcSwEdzGnKpFuyJCsoIQghPUtO))
   XHVvjcSwEdzGnKpFuyJCsoIQghPUtm.setMimeType('application/dash+xml')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUtm.setContentLookup(XHVvjcSwEdzGnKpFuyJCsoIQghPUOf)
  else:
   XHVvjcSwEdzGnKpFuyJCsoIQghPUtm.setMimeType('video/mp4')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUtm.setProperty('inputstream','inputstream.ffmpegdirect')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUtm.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUtm.setProperty('inputstream.ffmpegdirect.mime_type','video/mp4')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUtm.setContentLookup(XHVvjcSwEdzGnKpFuyJCsoIQghPUOf)
  xbmcplugin.setResolvedUrl(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm._addon_handle,XHVvjcSwEdzGnKpFuyJCsoIQghPUOt,XHVvjcSwEdzGnKpFuyJCsoIQghPUtm)
 def dp_Original_List(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm,args):
  XHVvjcSwEdzGnKpFuyJCsoIQghPUtB =args.get('page')
  XHVvjcSwEdzGnKpFuyJCsoIQghPUtr =args.get('lastId')
  if XHVvjcSwEdzGnKpFuyJCsoIQghPUtB ==XHVvjcSwEdzGnKpFuyJCsoIQghPUOA:XHVvjcSwEdzGnKpFuyJCsoIQghPUtB='1'
  if XHVvjcSwEdzGnKpFuyJCsoIQghPUtr==XHVvjcSwEdzGnKpFuyJCsoIQghPUOA:XHVvjcSwEdzGnKpFuyJCsoIQghPUtr=''
  XHVvjcSwEdzGnKpFuyJCsoIQghPUAk=XHVvjcSwEdzGnKpFuyJCsoIQghPUOi(XHVvjcSwEdzGnKpFuyJCsoIQghPUtB)
  XHVvjcSwEdzGnKpFuyJCsoIQghPUAf,XHVvjcSwEdzGnKpFuyJCsoIQghPUAL=XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.KakaotvObj.Get_Original_List(XHVvjcSwEdzGnKpFuyJCsoIQghPUAk,XHVvjcSwEdzGnKpFuyJCsoIQghPUtr)
  for XHVvjcSwEdzGnKpFuyJCsoIQghPUAm in XHVvjcSwEdzGnKpFuyJCsoIQghPUAf:
   XHVvjcSwEdzGnKpFuyJCsoIQghPUAb =XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('clipTitle')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUAR=XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('clipLinkId')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUta =XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('duration')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUtN =XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('channelNm')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUtD =XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('channelDs')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUAB =XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('channelId')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUAN=XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('thumbnail')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUAN={'thumb':XHVvjcSwEdzGnKpFuyJCsoIQghPUAN,'fanart':XHVvjcSwEdzGnKpFuyJCsoIQghPUAN}
   XHVvjcSwEdzGnKpFuyJCsoIQghPUAD={'mediatype':'episode','title':XHVvjcSwEdzGnKpFuyJCsoIQghPUAb,'plot':'%s\n\n\n[ %s ]\n\n%s'%(XHVvjcSwEdzGnKpFuyJCsoIQghPUAb,XHVvjcSwEdzGnKpFuyJCsoIQghPUtN,XHVvjcSwEdzGnKpFuyJCsoIQghPUtD),'duration':XHVvjcSwEdzGnKpFuyJCsoIQghPUta,}
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqx={'mode':'VOD','channelId':XHVvjcSwEdzGnKpFuyJCsoIQghPUAB,'clipLinkId':XHVvjcSwEdzGnKpFuyJCsoIQghPUAR,}
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.add_dir(XHVvjcSwEdzGnKpFuyJCsoIQghPUAb,sublabel='',img=XHVvjcSwEdzGnKpFuyJCsoIQghPUAN,infoLabels=XHVvjcSwEdzGnKpFuyJCsoIQghPUAD,isFolder=XHVvjcSwEdzGnKpFuyJCsoIQghPUOf,params=XHVvjcSwEdzGnKpFuyJCsoIQghPUqx)
   XHVvjcSwEdzGnKpFuyJCsoIQghPUtr=XHVvjcSwEdzGnKpFuyJCsoIQghPUAR 
  if XHVvjcSwEdzGnKpFuyJCsoIQghPUAL:
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqx['mode'] ='ORIGINAL_LIST' 
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqx['lastId'] =XHVvjcSwEdzGnKpFuyJCsoIQghPUtr
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqx['page'] =XHVvjcSwEdzGnKpFuyJCsoIQghPUOk(XHVvjcSwEdzGnKpFuyJCsoIQghPUAk+1)
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqY='[B]%s >>[/B]'%'다음 페이지'
   XHVvjcSwEdzGnKpFuyJCsoIQghPUAY=XHVvjcSwEdzGnKpFuyJCsoIQghPUOk(XHVvjcSwEdzGnKpFuyJCsoIQghPUAk+1)
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqM=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.add_dir(XHVvjcSwEdzGnKpFuyJCsoIQghPUqY,sublabel=XHVvjcSwEdzGnKpFuyJCsoIQghPUAY,img=XHVvjcSwEdzGnKpFuyJCsoIQghPUqM,infoLabels=XHVvjcSwEdzGnKpFuyJCsoIQghPUOA,isFolder=XHVvjcSwEdzGnKpFuyJCsoIQghPUOt,params=XHVvjcSwEdzGnKpFuyJCsoIQghPUqx)
  xbmcplugin.setContent(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm._addon_handle,cacheToDisc=XHVvjcSwEdzGnKpFuyJCsoIQghPUOf)
 def Get_Live_List(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm,args):
  XHVvjcSwEdzGnKpFuyJCsoIQghPUtB =args.get('page')
  if XHVvjcSwEdzGnKpFuyJCsoIQghPUtB ==XHVvjcSwEdzGnKpFuyJCsoIQghPUOA:XHVvjcSwEdzGnKpFuyJCsoIQghPUtB='1'
  XHVvjcSwEdzGnKpFuyJCsoIQghPUAk=XHVvjcSwEdzGnKpFuyJCsoIQghPUOi(XHVvjcSwEdzGnKpFuyJCsoIQghPUtB)
  XHVvjcSwEdzGnKpFuyJCsoIQghPUAf,XHVvjcSwEdzGnKpFuyJCsoIQghPUAL=XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.KakaotvObj.Get_Live_List(XHVvjcSwEdzGnKpFuyJCsoIQghPUAk)
  for XHVvjcSwEdzGnKpFuyJCsoIQghPUAm in XHVvjcSwEdzGnKpFuyJCsoIQghPUAf:
   XHVvjcSwEdzGnKpFuyJCsoIQghPUtY =XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('liveId')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUtT =XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('liveNm')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUtN=XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('channelNm')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUAB=XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('channelId')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUAN=XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('thumbnail')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUAN={'thumb':XHVvjcSwEdzGnKpFuyJCsoIQghPUAN,'fanart':XHVvjcSwEdzGnKpFuyJCsoIQghPUAN}
   XHVvjcSwEdzGnKpFuyJCsoIQghPUAD={'mediatype':'episode','title':XHVvjcSwEdzGnKpFuyJCsoIQghPUtT,'plot':'[ %s ]\n\n%s'%(XHVvjcSwEdzGnKpFuyJCsoIQghPUtN,XHVvjcSwEdzGnKpFuyJCsoIQghPUtT),}
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqx={'mode':'LIVE','clipLinkId':XHVvjcSwEdzGnKpFuyJCsoIQghPUtY,'channelId':XHVvjcSwEdzGnKpFuyJCsoIQghPUAB,}
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.add_dir(XHVvjcSwEdzGnKpFuyJCsoIQghPUtT,sublabel='',img=XHVvjcSwEdzGnKpFuyJCsoIQghPUAN,infoLabels=XHVvjcSwEdzGnKpFuyJCsoIQghPUAD,isFolder=XHVvjcSwEdzGnKpFuyJCsoIQghPUOf,params=XHVvjcSwEdzGnKpFuyJCsoIQghPUqx)
  if XHVvjcSwEdzGnKpFuyJCsoIQghPUAL:
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqx['mode'] ='LIVE_LIST' 
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqx['page'] =XHVvjcSwEdzGnKpFuyJCsoIQghPUOk(XHVvjcSwEdzGnKpFuyJCsoIQghPUAk+1)
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqY='[B]%s >>[/B]'%'다음 페이지'
   XHVvjcSwEdzGnKpFuyJCsoIQghPUAY=XHVvjcSwEdzGnKpFuyJCsoIQghPUOk(XHVvjcSwEdzGnKpFuyJCsoIQghPUAk+1)
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqM=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.add_dir(XHVvjcSwEdzGnKpFuyJCsoIQghPUqY,sublabel=XHVvjcSwEdzGnKpFuyJCsoIQghPUAY,img=XHVvjcSwEdzGnKpFuyJCsoIQghPUqM,infoLabels=XHVvjcSwEdzGnKpFuyJCsoIQghPUOA,isFolder=XHVvjcSwEdzGnKpFuyJCsoIQghPUOt,params=XHVvjcSwEdzGnKpFuyJCsoIQghPUqx)
  xbmcplugin.endOfDirectory(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm._addon_handle,cacheToDisc=XHVvjcSwEdzGnKpFuyJCsoIQghPUOf)
 def dp_Search_Group(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm,args):
  if 'search_key' in args:
   XHVvjcSwEdzGnKpFuyJCsoIQghPUtW=args.get('search_key')
  else:
   XHVvjcSwEdzGnKpFuyJCsoIQghPUtW=XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not XHVvjcSwEdzGnKpFuyJCsoIQghPUtW:
    return
  for XHVvjcSwEdzGnKpFuyJCsoIQghPUAm in XHVvjcSwEdzGnKpFuyJCsoIQghPUqf:
   XHVvjcSwEdzGnKpFuyJCsoIQghPUAx =XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('mode')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUtl=XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('stype')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqY=XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('title')
   (XHVvjcSwEdzGnKpFuyJCsoIQghPUtR,XHVvjcSwEdzGnKpFuyJCsoIQghPUAL)=XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.KakaotvObj.GetSearchList(XHVvjcSwEdzGnKpFuyJCsoIQghPUtW,1,XHVvjcSwEdzGnKpFuyJCsoIQghPUtl)
   XHVvjcSwEdzGnKpFuyJCsoIQghPUtb={'plot':'검색어 : '+XHVvjcSwEdzGnKpFuyJCsoIQghPUtW+'\n\n'+XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.Search_FreeList(XHVvjcSwEdzGnKpFuyJCsoIQghPUtR)}
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqx={'mode':XHVvjcSwEdzGnKpFuyJCsoIQghPUAx,'stype':XHVvjcSwEdzGnKpFuyJCsoIQghPUtl,'search_key':XHVvjcSwEdzGnKpFuyJCsoIQghPUtW,'page':'1',}
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.add_dir(XHVvjcSwEdzGnKpFuyJCsoIQghPUqY,sublabel='',img='',infoLabels=XHVvjcSwEdzGnKpFuyJCsoIQghPUtb,isFolder=XHVvjcSwEdzGnKpFuyJCsoIQghPUOt,params=XHVvjcSwEdzGnKpFuyJCsoIQghPUqx)
  if XHVvjcSwEdzGnKpFuyJCsoIQghPUOL(XHVvjcSwEdzGnKpFuyJCsoIQghPUqf)>0:xbmcplugin.endOfDirectory(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm._addon_handle,cacheToDisc=XHVvjcSwEdzGnKpFuyJCsoIQghPUOt)
 def Search_FreeList(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm,search_list):
  XHVvjcSwEdzGnKpFuyJCsoIQghPUtM=''
  XHVvjcSwEdzGnKpFuyJCsoIQghPUtx=7
  try:
   if XHVvjcSwEdzGnKpFuyJCsoIQghPUOL(search_list)==0:return '검색결과 없음'
   for i in XHVvjcSwEdzGnKpFuyJCsoIQghPUOB(XHVvjcSwEdzGnKpFuyJCsoIQghPUOL(search_list)):
    if i>=XHVvjcSwEdzGnKpFuyJCsoIQghPUtx:
     XHVvjcSwEdzGnKpFuyJCsoIQghPUtM=XHVvjcSwEdzGnKpFuyJCsoIQghPUtM+'...'
     break
    XHVvjcSwEdzGnKpFuyJCsoIQghPUtM=XHVvjcSwEdzGnKpFuyJCsoIQghPUtM+search_list[i]['title']+'\n'
  except:
   return ''
  return XHVvjcSwEdzGnKpFuyJCsoIQghPUtM
 def dp_Search_List(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm,args):
  XHVvjcSwEdzGnKpFuyJCsoIQghPUtW=args.get('search_key')
  XHVvjcSwEdzGnKpFuyJCsoIQghPUAk =XHVvjcSwEdzGnKpFuyJCsoIQghPUOi(args.get('page'))
  XHVvjcSwEdzGnKpFuyJCsoIQghPUtl =args.get('stype')
  XHVvjcSwEdzGnKpFuyJCsoIQghPUtR,XHVvjcSwEdzGnKpFuyJCsoIQghPUAL=XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.KakaotvObj.GetSearchList(XHVvjcSwEdzGnKpFuyJCsoIQghPUtW,XHVvjcSwEdzGnKpFuyJCsoIQghPUAk,XHVvjcSwEdzGnKpFuyJCsoIQghPUtl)
  for XHVvjcSwEdzGnKpFuyJCsoIQghPUAm in XHVvjcSwEdzGnKpFuyJCsoIQghPUtR:
   if XHVvjcSwEdzGnKpFuyJCsoIQghPUtl=='channels': 
    XHVvjcSwEdzGnKpFuyJCsoIQghPUAB=XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('channelId')
    XHVvjcSwEdzGnKpFuyJCsoIQghPUqY =XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('title')
    XHVvjcSwEdzGnKpFuyJCsoIQghPUAr =XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('synopsis')
    XHVvjcSwEdzGnKpFuyJCsoIQghPUAa =XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('tagList')
    XHVvjcSwEdzGnKpFuyJCsoIQghPUAN=XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('thumbnail')
    XHVvjcSwEdzGnKpFuyJCsoIQghPUAD={'mediatype':'tvshow','title':XHVvjcSwEdzGnKpFuyJCsoIQghPUqY,'genre':XHVvjcSwEdzGnKpFuyJCsoIQghPUAa,'plot':XHVvjcSwEdzGnKpFuyJCsoIQghPUAr,}
    XHVvjcSwEdzGnKpFuyJCsoIQghPUqx={'mode':'CH_PLAY_LIST','channelId':XHVvjcSwEdzGnKpFuyJCsoIQghPUAB,'page':'1',}
    XHVvjcSwEdzGnKpFuyJCsoIQghPUAq=XHVvjcSwEdzGnKpFuyJCsoIQghPUOt
   else:
    XHVvjcSwEdzGnKpFuyJCsoIQghPUqY =XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('title')
    XHVvjcSwEdzGnKpFuyJCsoIQghPUAR=XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('clipLinkId')
    XHVvjcSwEdzGnKpFuyJCsoIQghPUta =XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('duration')
    XHVvjcSwEdzGnKpFuyJCsoIQghPUtN =XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('channelNm')
    XHVvjcSwEdzGnKpFuyJCsoIQghPUtD =XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('channelDs')
    XHVvjcSwEdzGnKpFuyJCsoIQghPUAB =XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('channelId')
    XHVvjcSwEdzGnKpFuyJCsoIQghPUAN =XHVvjcSwEdzGnKpFuyJCsoIQghPUAm.get('thumbnail')
    XHVvjcSwEdzGnKpFuyJCsoIQghPUAN ={'thumb':XHVvjcSwEdzGnKpFuyJCsoIQghPUAN,'fanart':XHVvjcSwEdzGnKpFuyJCsoIQghPUAN}
    XHVvjcSwEdzGnKpFuyJCsoIQghPUAD={'mediatype':'episode','title':XHVvjcSwEdzGnKpFuyJCsoIQghPUqY,'plot':'%s\n\n\n[ %s ]\n\n%s'%(XHVvjcSwEdzGnKpFuyJCsoIQghPUqY,XHVvjcSwEdzGnKpFuyJCsoIQghPUtN,XHVvjcSwEdzGnKpFuyJCsoIQghPUtD),'duration':XHVvjcSwEdzGnKpFuyJCsoIQghPUta,}
    XHVvjcSwEdzGnKpFuyJCsoIQghPUqx={'mode':'VOD','channelId':XHVvjcSwEdzGnKpFuyJCsoIQghPUAB,'clipLinkId':XHVvjcSwEdzGnKpFuyJCsoIQghPUAR,}
    XHVvjcSwEdzGnKpFuyJCsoIQghPUAq=XHVvjcSwEdzGnKpFuyJCsoIQghPUOf
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.add_dir(XHVvjcSwEdzGnKpFuyJCsoIQghPUqY,sublabel='',img=XHVvjcSwEdzGnKpFuyJCsoIQghPUAN,infoLabels=XHVvjcSwEdzGnKpFuyJCsoIQghPUAD,isFolder=XHVvjcSwEdzGnKpFuyJCsoIQghPUAq,params=XHVvjcSwEdzGnKpFuyJCsoIQghPUqx)
  if XHVvjcSwEdzGnKpFuyJCsoIQghPUAL:
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqx['mode'] ='LOCAL_SEARCH' 
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqx['search_key']=XHVvjcSwEdzGnKpFuyJCsoIQghPUtW
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqx['page'] =XHVvjcSwEdzGnKpFuyJCsoIQghPUOk(XHVvjcSwEdzGnKpFuyJCsoIQghPUAk+1)
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqx['stype'] =XHVvjcSwEdzGnKpFuyJCsoIQghPUtl
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqY='[B]%s >>[/B]'%'다음 페이지'
   XHVvjcSwEdzGnKpFuyJCsoIQghPUAY=XHVvjcSwEdzGnKpFuyJCsoIQghPUOk(XHVvjcSwEdzGnKpFuyJCsoIQghPUAk+1)
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqM=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.add_dir(XHVvjcSwEdzGnKpFuyJCsoIQghPUqY,sublabel=XHVvjcSwEdzGnKpFuyJCsoIQghPUAY,img=XHVvjcSwEdzGnKpFuyJCsoIQghPUqM,infoLabels=XHVvjcSwEdzGnKpFuyJCsoIQghPUOA,isFolder=XHVvjcSwEdzGnKpFuyJCsoIQghPUOt,params=XHVvjcSwEdzGnKpFuyJCsoIQghPUqx)
  if XHVvjcSwEdzGnKpFuyJCsoIQghPUtl=='channels':xbmcplugin.setContent(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm._addon_handle,'tvshows')
  else:xbmcplugin.setContent(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm._addon_handle,cacheToDisc=XHVvjcSwEdzGnKpFuyJCsoIQghPUOf) 
 def kakaotv_main(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm):
  XHVvjcSwEdzGnKpFuyJCsoIQghPUAx=XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.main_params.get('mode',XHVvjcSwEdzGnKpFuyJCsoIQghPUOA)
  if XHVvjcSwEdzGnKpFuyJCsoIQghPUAx is XHVvjcSwEdzGnKpFuyJCsoIQghPUOA:
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.dp_Main_List(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.main_params)
  elif XHVvjcSwEdzGnKpFuyJCsoIQghPUAx=='CHANNEL_GROUP':
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.dp_Channel_GroupList(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.main_params)
  elif XHVvjcSwEdzGnKpFuyJCsoIQghPUAx=='CHANNEL_LIST':
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.dp_Channel_List(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.main_params)
  elif XHVvjcSwEdzGnKpFuyJCsoIQghPUAx=='CH_PLAY_LIST':
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.dp_Channel_Playlist(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.main_params)
  elif XHVvjcSwEdzGnKpFuyJCsoIQghPUAx=='EPISODE_LIST':
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.dp_Episode_List(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.main_params)
  elif XHVvjcSwEdzGnKpFuyJCsoIQghPUAx in['VOD','LIVE']:
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.play_VIDEO(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.main_params)
  elif XHVvjcSwEdzGnKpFuyJCsoIQghPUAx=='ORIGINAL_LIST':
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.dp_Original_List(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.main_params)
  elif XHVvjcSwEdzGnKpFuyJCsoIQghPUAx=='LIVE_LIST':
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.Get_Live_List(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.main_params)
  elif XHVvjcSwEdzGnKpFuyJCsoIQghPUAx=='SEARCH_GROUP':
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.dp_Search_Group(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.main_params)
  elif XHVvjcSwEdzGnKpFuyJCsoIQghPUAx=='LOCAL_SEARCH':
   XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.dp_Search_List(XHVvjcSwEdzGnKpFuyJCsoIQghPUqm.main_params)
  else:
   XHVvjcSwEdzGnKpFuyJCsoIQghPUOA
# Created by pyminifier (https://github.com/liftoff/pyminifier)
