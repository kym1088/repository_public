__author__="NightRain"
JpegojktaKMfGixSuYXVUmRFEHLcbW=object
JpegojktaKMfGixSuYXVUmRFEHLcbw=None
JpegojktaKMfGixSuYXVUmRFEHLcbQ=False
JpegojktaKMfGixSuYXVUmRFEHLcbd=True
JpegojktaKMfGixSuYXVUmRFEHLcbA=str
JpegojktaKMfGixSuYXVUmRFEHLcbq=Exception
JpegojktaKMfGixSuYXVUmRFEHLcbv=print
import urllib
import re
import json
import requests
import datetime
from bs4 import BeautifulSoup
class JpegojktaKMfGixSuYXVUmRFEHLcBl(JpegojktaKMfGixSuYXVUmRFEHLcbW):
 def __init__(JpegojktaKMfGixSuYXVUmRFEHLcBb):
  JpegojktaKMfGixSuYXVUmRFEHLcBb.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.106 Safari/537.36'
  JpegojktaKMfGixSuYXVUmRFEHLcBb.APP_VERSION ='91.0.4472.106' 
  JpegojktaKMfGixSuYXVUmRFEHLcBb.DEFAULT_HEADER ={'user-agent':JpegojktaKMfGixSuYXVUmRFEHLcBb.USER_AGENT}
  JpegojktaKMfGixSuYXVUmRFEHLcBb.API_DOMAIN ='https://tv.kakao.com'
  JpegojktaKMfGixSuYXVUmRFEHLcBb.HTTPTAG ='https:'
  JpegojktaKMfGixSuYXVUmRFEHLcBb.CHANNEL_LIMIT =21
  JpegojktaKMfGixSuYXVUmRFEHLcBb.PAGE_LIMIT =20
 def callRequestCookies(JpegojktaKMfGixSuYXVUmRFEHLcBb,jobtype,JpegojktaKMfGixSuYXVUmRFEHLcBw,payload=JpegojktaKMfGixSuYXVUmRFEHLcbw,params=JpegojktaKMfGixSuYXVUmRFEHLcbw,headers=JpegojktaKMfGixSuYXVUmRFEHLcbw,cookies=JpegojktaKMfGixSuYXVUmRFEHLcbw,redirects=JpegojktaKMfGixSuYXVUmRFEHLcbQ):
  JpegojktaKMfGixSuYXVUmRFEHLcBr=JpegojktaKMfGixSuYXVUmRFEHLcBb.DEFAULT_HEADER
  if headers:JpegojktaKMfGixSuYXVUmRFEHLcBr.update(headers)
  if jobtype=='Get':
   JpegojktaKMfGixSuYXVUmRFEHLcBs=requests.get(JpegojktaKMfGixSuYXVUmRFEHLcBw,params=params,headers=JpegojktaKMfGixSuYXVUmRFEHLcBr,cookies=cookies,allow_redirects=redirects)
  else:
   JpegojktaKMfGixSuYXVUmRFEHLcBs=requests.post(JpegojktaKMfGixSuYXVUmRFEHLcBw,data=payload,params=params,headers=JpegojktaKMfGixSuYXVUmRFEHLcBr,cookies=cookies,allow_redirects=redirects)
  return JpegojktaKMfGixSuYXVUmRFEHLcBs
 def Get_Now_Datetime(JpegojktaKMfGixSuYXVUmRFEHLcBb):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_Channel_Group(JpegojktaKMfGixSuYXVUmRFEHLcBb):
  JpegojktaKMfGixSuYXVUmRFEHLcBW=[]
  try:
   JpegojktaKMfGixSuYXVUmRFEHLcBw=JpegojktaKMfGixSuYXVUmRFEHLcBb.API_DOMAIN 
   JpegojktaKMfGixSuYXVUmRFEHLcBQ=JpegojktaKMfGixSuYXVUmRFEHLcBb.callRequestCookies('Get',JpegojktaKMfGixSuYXVUmRFEHLcBw,payload=JpegojktaKMfGixSuYXVUmRFEHLcbw,params=JpegojktaKMfGixSuYXVUmRFEHLcbw,headers=JpegojktaKMfGixSuYXVUmRFEHLcbw,cookies=JpegojktaKMfGixSuYXVUmRFEHLcbw,redirects=JpegojktaKMfGixSuYXVUmRFEHLcbd)
   if JpegojktaKMfGixSuYXVUmRFEHLcBQ.status_code!=200:return[]
   JpegojktaKMfGixSuYXVUmRFEHLcBd=BeautifulSoup(JpegojktaKMfGixSuYXVUmRFEHLcBQ.text,'html.parser')
   JpegojktaKMfGixSuYXVUmRFEHLcBd=JpegojktaKMfGixSuYXVUmRFEHLcBd.select_one('#mArticle > div.tv_recommend > div.recommend_tab')
   JpegojktaKMfGixSuYXVUmRFEHLcBA=JpegojktaKMfGixSuYXVUmRFEHLcBd.findAll('a')
   for JpegojktaKMfGixSuYXVUmRFEHLcBq in JpegojktaKMfGixSuYXVUmRFEHLcBA:
    JpegojktaKMfGixSuYXVUmRFEHLcBW.append(JpegojktaKMfGixSuYXVUmRFEHLcBq.text.replace('#',''))
  except:
   return[]
  return JpegojktaKMfGixSuYXVUmRFEHLcBW
 def Get_Channel_List(JpegojktaKMfGixSuYXVUmRFEHLcBb,categoryNm,page_int):
  JpegojktaKMfGixSuYXVUmRFEHLcBv=[]
  JpegojktaKMfGixSuYXVUmRFEHLcBN=JpegojktaKMfGixSuYXVUmRFEHLcbQ
  try:
   JpegojktaKMfGixSuYXVUmRFEHLcBw=JpegojktaKMfGixSuYXVUmRFEHLcBb.API_DOMAIN+'/api/v1/ft/featured/web/top/recommendChannels' 
   JpegojktaKMfGixSuYXVUmRFEHLcBI={'tag':categoryNm,'fields':'-category,user,channelSkinData,tagList,-bannerImageUrlHistory,-profileImageUrlHistory','size':JpegojktaKMfGixSuYXVUmRFEHLcBb.CHANNEL_LIMIT,'page':JpegojktaKMfGixSuYXVUmRFEHLcbA(page_int),}
   JpegojktaKMfGixSuYXVUmRFEHLcBQ=JpegojktaKMfGixSuYXVUmRFEHLcBb.callRequestCookies('Get',JpegojktaKMfGixSuYXVUmRFEHLcBw,payload=JpegojktaKMfGixSuYXVUmRFEHLcbw,params=JpegojktaKMfGixSuYXVUmRFEHLcBI,headers=JpegojktaKMfGixSuYXVUmRFEHLcbw,cookies=JpegojktaKMfGixSuYXVUmRFEHLcbw,redirects=JpegojktaKMfGixSuYXVUmRFEHLcbd)
   if JpegojktaKMfGixSuYXVUmRFEHLcBQ.status_code!=200:return[],JpegojktaKMfGixSuYXVUmRFEHLcbQ
   JpegojktaKMfGixSuYXVUmRFEHLcBP=json.loads(JpegojktaKMfGixSuYXVUmRFEHLcBQ.text)
   if JpegojktaKMfGixSuYXVUmRFEHLcBP.get('hasMore')==JpegojktaKMfGixSuYXVUmRFEHLcbd:JpegojktaKMfGixSuYXVUmRFEHLcBN=JpegojktaKMfGixSuYXVUmRFEHLcbd
   JpegojktaKMfGixSuYXVUmRFEHLcBT=JpegojktaKMfGixSuYXVUmRFEHLcBP.get('list')
   for JpegojktaKMfGixSuYXVUmRFEHLcBn in JpegojktaKMfGixSuYXVUmRFEHLcBT:
    JpegojktaKMfGixSuYXVUmRFEHLcBO =JpegojktaKMfGixSuYXVUmRFEHLcBn.get('channelSkinData').get('profileImageUrl').replace('http://','https://')
    JpegojktaKMfGixSuYXVUmRFEHLcBC =JpegojktaKMfGixSuYXVUmRFEHLcBn.get('channelSkinData').get('bannerImageUrl').replace('http://','https://')
    JpegojktaKMfGixSuYXVUmRFEHLcBD={'channelId':JpegojktaKMfGixSuYXVUmRFEHLcBn.get('id'),'title':JpegojktaKMfGixSuYXVUmRFEHLcBn.get('name'),'synopsis':JpegojktaKMfGixSuYXVUmRFEHLcBn.get('description'),'tagList':JpegojktaKMfGixSuYXVUmRFEHLcBn.get('tagList'),'thumbnail':{'poster':JpegojktaKMfGixSuYXVUmRFEHLcBO,'thumb':JpegojktaKMfGixSuYXVUmRFEHLcBO,'fanart':JpegojktaKMfGixSuYXVUmRFEHLcBC}}
    JpegojktaKMfGixSuYXVUmRFEHLcBv.append(JpegojktaKMfGixSuYXVUmRFEHLcBD)
  except:
   return[],JpegojktaKMfGixSuYXVUmRFEHLcbQ
  return JpegojktaKMfGixSuYXVUmRFEHLcBv,JpegojktaKMfGixSuYXVUmRFEHLcBN
 def Get_Channel_Playlist(JpegojktaKMfGixSuYXVUmRFEHLcBb,JpegojktaKMfGixSuYXVUmRFEHLcbB):
  JpegojktaKMfGixSuYXVUmRFEHLcBh=[]
  try:
   JpegojktaKMfGixSuYXVUmRFEHLcBw=JpegojktaKMfGixSuYXVUmRFEHLcBb.API_DOMAIN+'/channel/%s/playlist'%(JpegojktaKMfGixSuYXVUmRFEHLcbB)
   JpegojktaKMfGixSuYXVUmRFEHLcBQ=JpegojktaKMfGixSuYXVUmRFEHLcBb.callRequestCookies('Get',JpegojktaKMfGixSuYXVUmRFEHLcBw,payload=JpegojktaKMfGixSuYXVUmRFEHLcbw,params=JpegojktaKMfGixSuYXVUmRFEHLcbw,headers=JpegojktaKMfGixSuYXVUmRFEHLcbw,cookies=JpegojktaKMfGixSuYXVUmRFEHLcbw,redirects=JpegojktaKMfGixSuYXVUmRFEHLcbd)
   if JpegojktaKMfGixSuYXVUmRFEHLcBQ.status_code!=200:return[]
   JpegojktaKMfGixSuYXVUmRFEHLcBd=BeautifulSoup(JpegojktaKMfGixSuYXVUmRFEHLcBQ.text,'html.parser')
   JpegojktaKMfGixSuYXVUmRFEHLcBd=JpegojktaKMfGixSuYXVUmRFEHLcBd.select_one('#mArticle > div.inven_cont > ul')
   JpegojktaKMfGixSuYXVUmRFEHLcBz=JpegojktaKMfGixSuYXVUmRFEHLcBd.findAll('li',{'class':'playlist_content_li'})
   for JpegojktaKMfGixSuYXVUmRFEHLcBq in JpegojktaKMfGixSuYXVUmRFEHLcBz:
    JpegojktaKMfGixSuYXVUmRFEHLclB=JpegojktaKMfGixSuYXVUmRFEHLcBq.get('data-item-id')
    JpegojktaKMfGixSuYXVUmRFEHLclb =JpegojktaKMfGixSuYXVUmRFEHLcBq.get('data-count')
    JpegojktaKMfGixSuYXVUmRFEHLclr =JpegojktaKMfGixSuYXVUmRFEHLcBq.find('img',{'class':'thumb_img'})
    JpegojktaKMfGixSuYXVUmRFEHLcls=JpegojktaKMfGixSuYXVUmRFEHLclr.get('alt')
    JpegojktaKMfGixSuYXVUmRFEHLcly =JpegojktaKMfGixSuYXVUmRFEHLcBb.HTTPTAG+JpegojktaKMfGixSuYXVUmRFEHLclr.get('src')
    JpegojktaKMfGixSuYXVUmRFEHLcBD={'playlistId':JpegojktaKMfGixSuYXVUmRFEHLclB,'playlistNm':JpegojktaKMfGixSuYXVUmRFEHLcls,'thumbnail':JpegojktaKMfGixSuYXVUmRFEHLcly.replace('http://','https://'),'vodCount':JpegojktaKMfGixSuYXVUmRFEHLclb,}
    JpegojktaKMfGixSuYXVUmRFEHLcBh.append(JpegojktaKMfGixSuYXVUmRFEHLcBD)
  except:
   return[]
  return JpegojktaKMfGixSuYXVUmRFEHLcBh
 def Get_Episode_List(JpegojktaKMfGixSuYXVUmRFEHLcBb,JpegojktaKMfGixSuYXVUmRFEHLcbB,JpegojktaKMfGixSuYXVUmRFEHLclB):
  JpegojktaKMfGixSuYXVUmRFEHLclW=[]
  try:
   JpegojktaKMfGixSuYXVUmRFEHLcBw=JpegojktaKMfGixSuYXVUmRFEHLcBb.API_DOMAIN+'/channel/%s/playlist/%s'%(JpegojktaKMfGixSuYXVUmRFEHLcbB,JpegojktaKMfGixSuYXVUmRFEHLclB)
   JpegojktaKMfGixSuYXVUmRFEHLcBQ=JpegojktaKMfGixSuYXVUmRFEHLcBb.callRequestCookies('Get',JpegojktaKMfGixSuYXVUmRFEHLcBw,payload=JpegojktaKMfGixSuYXVUmRFEHLcbw,params=JpegojktaKMfGixSuYXVUmRFEHLcbw,headers=JpegojktaKMfGixSuYXVUmRFEHLcbw,cookies=JpegojktaKMfGixSuYXVUmRFEHLcbw,redirects=JpegojktaKMfGixSuYXVUmRFEHLcbd)
   if JpegojktaKMfGixSuYXVUmRFEHLcBQ.status_code!=200:return[]
   JpegojktaKMfGixSuYXVUmRFEHLcBd=BeautifulSoup(JpegojktaKMfGixSuYXVUmRFEHLcBQ.text,'html.parser')
   JpegojktaKMfGixSuYXVUmRFEHLcBd=JpegojktaKMfGixSuYXVUmRFEHLcBd.select_one('#playerPlaylist > ul.list_plist.dev_added_class_clips_plist')
   JpegojktaKMfGixSuYXVUmRFEHLcBz=JpegojktaKMfGixSuYXVUmRFEHLcBd.findAll('li')
   for JpegojktaKMfGixSuYXVUmRFEHLcBq in JpegojktaKMfGixSuYXVUmRFEHLcBz:
    JpegojktaKMfGixSuYXVUmRFEHLclw =JpegojktaKMfGixSuYXVUmRFEHLcBq.get('data-item-id')
    JpegojktaKMfGixSuYXVUmRFEHLclQ=JpegojktaKMfGixSuYXVUmRFEHLcBq.get('data-cliplink-id')
    JpegojktaKMfGixSuYXVUmRFEHLcld =JpegojktaKMfGixSuYXVUmRFEHLcBq.find('strong',{'class':'tit_item'}).text
    JpegojktaKMfGixSuYXVUmRFEHLclA =JpegojktaKMfGixSuYXVUmRFEHLcBq.find('span',{'class':'txt_charge'})
    if JpegojktaKMfGixSuYXVUmRFEHLclA!=JpegojktaKMfGixSuYXVUmRFEHLcbw:JpegojktaKMfGixSuYXVUmRFEHLclA=JpegojktaKMfGixSuYXVUmRFEHLclA.text
    else:JpegojktaKMfGixSuYXVUmRFEHLclA=''
    JpegojktaKMfGixSuYXVUmRFEHLclr =JpegojktaKMfGixSuYXVUmRFEHLcBq.find('img',{'class':'thumb_img'})
    JpegojktaKMfGixSuYXVUmRFEHLcly =JpegojktaKMfGixSuYXVUmRFEHLcBb.HTTPTAG+JpegojktaKMfGixSuYXVUmRFEHLclr.get('src')
    JpegojktaKMfGixSuYXVUmRFEHLcBD={'clipLinkId':JpegojktaKMfGixSuYXVUmRFEHLclQ,'clipTitle':JpegojktaKMfGixSuYXVUmRFEHLcld,'chargeTxt':JpegojktaKMfGixSuYXVUmRFEHLclA,'thumbnail':JpegojktaKMfGixSuYXVUmRFEHLcly,}
    JpegojktaKMfGixSuYXVUmRFEHLclW.insert(0,JpegojktaKMfGixSuYXVUmRFEHLcBD)
  except:
   return[]
  return JpegojktaKMfGixSuYXVUmRFEHLclW
 def GetStreamingURL(JpegojktaKMfGixSuYXVUmRFEHLcBb,JpegojktaKMfGixSuYXVUmRFEHLclQ,quality_str='HIGH4'):
  JpegojktaKMfGixSuYXVUmRFEHLclq=''
  JpegojktaKMfGixSuYXVUmRFEHLclv =''
  try:
   JpegojktaKMfGixSuYXVUmRFEHLcBw=JpegojktaKMfGixSuYXVUmRFEHLcBb.API_DOMAIN+'/katz/v3/ft/cliplink/%s/readyNplay'%(JpegojktaKMfGixSuYXVUmRFEHLclQ)
   JpegojktaKMfGixSuYXVUmRFEHLcBI={'player':'monet_html5','referer':'','pageReferer':'','uuid':'','profile':quality_str,'service':'kakao_tv','section':'channel','fields':'seekUrl,abrVideoLocationList','playerVersion':'3.10.21','appVersion':JpegojktaKMfGixSuYXVUmRFEHLcBb.APP_VERSION,'startPosition':'0','tid':'','dteType':'PC','continuousPlay':'false','contentType':'','drmType':'widevine',}
   JpegojktaKMfGixSuYXVUmRFEHLcBQ=JpegojktaKMfGixSuYXVUmRFEHLcBb.callRequestCookies('Get',JpegojktaKMfGixSuYXVUmRFEHLcBw,payload=JpegojktaKMfGixSuYXVUmRFEHLcbw,params=JpegojktaKMfGixSuYXVUmRFEHLcBI,headers=JpegojktaKMfGixSuYXVUmRFEHLcbw,cookies=JpegojktaKMfGixSuYXVUmRFEHLcbw,redirects=JpegojktaKMfGixSuYXVUmRFEHLcbd)
   if JpegojktaKMfGixSuYXVUmRFEHLcBQ.status_code!=200:return '',''
   JpegojktaKMfGixSuYXVUmRFEHLcBP=json.loads(JpegojktaKMfGixSuYXVUmRFEHLcBQ.text)
   JpegojktaKMfGixSuYXVUmRFEHLclq=JpegojktaKMfGixSuYXVUmRFEHLcBP.get('videoLocation').get('url')
  except JpegojktaKMfGixSuYXVUmRFEHLcbq as exception:
   JpegojktaKMfGixSuYXVUmRFEHLcbv(exception)
   return '',''
  return JpegojktaKMfGixSuYXVUmRFEHLclq,JpegojktaKMfGixSuYXVUmRFEHLclv
 def GetLiveURL(JpegojktaKMfGixSuYXVUmRFEHLcBb,JpegojktaKMfGixSuYXVUmRFEHLclC,quality_str='HIGH4'):
  JpegojktaKMfGixSuYXVUmRFEHLclq=''
  JpegojktaKMfGixSuYXVUmRFEHLclv =''
  try:
   JpegojktaKMfGixSuYXVUmRFEHLcBw=JpegojktaKMfGixSuYXVUmRFEHLcBb.API_DOMAIN+'/katz/v2/ft/livelink/%s/readyNplay'%(JpegojktaKMfGixSuYXVUmRFEHLclC)
   JpegojktaKMfGixSuYXVUmRFEHLcBI={'player':'monet_html5','referer':'','pageReferer':'','uuid':'','service':'kakao_tv','section':'kakao_tv','dteType':'PC','profile':quality_str,'playerVersion':'3.10.21','liveLinkId':JpegojktaKMfGixSuYXVUmRFEHLclC,'contentType':'HLS','password':'',}
   JpegojktaKMfGixSuYXVUmRFEHLcBQ=JpegojktaKMfGixSuYXVUmRFEHLcBb.callRequestCookies('Get',JpegojktaKMfGixSuYXVUmRFEHLcBw,payload=JpegojktaKMfGixSuYXVUmRFEHLcbw,params=JpegojktaKMfGixSuYXVUmRFEHLcBI,headers=JpegojktaKMfGixSuYXVUmRFEHLcbw,cookies=JpegojktaKMfGixSuYXVUmRFEHLcbw,redirects=JpegojktaKMfGixSuYXVUmRFEHLcbd)
   if JpegojktaKMfGixSuYXVUmRFEHLcBQ.status_code!=200:return '',''
   JpegojktaKMfGixSuYXVUmRFEHLcBP=json.loads(JpegojktaKMfGixSuYXVUmRFEHLcBQ.text)
   JpegojktaKMfGixSuYXVUmRFEHLclq=JpegojktaKMfGixSuYXVUmRFEHLcBP.get('videoLocation').get('url')
  except JpegojktaKMfGixSuYXVUmRFEHLcbq as exception:
   JpegojktaKMfGixSuYXVUmRFEHLcbv(exception)
   return '',''
  return JpegojktaKMfGixSuYXVUmRFEHLclq,JpegojktaKMfGixSuYXVUmRFEHLclv
 def Get_Original_List(JpegojktaKMfGixSuYXVUmRFEHLcBb,page_int,lastId):
  JpegojktaKMfGixSuYXVUmRFEHLclN=[]
  JpegojktaKMfGixSuYXVUmRFEHLcBN=JpegojktaKMfGixSuYXVUmRFEHLcbQ
  try:
   JpegojktaKMfGixSuYXVUmRFEHLcBw=JpegojktaKMfGixSuYXVUmRFEHLcBb.API_DOMAIN+'/api/v1/ft/home/category/original'
   JpegojktaKMfGixSuYXVUmRFEHLcBI={'fields':'channel,-user,-clipChapterThumbnailList,-tagList,-service','size':JpegojktaKMfGixSuYXVUmRFEHLcbA(JpegojktaKMfGixSuYXVUmRFEHLcBb.PAGE_LIMIT),'page':JpegojktaKMfGixSuYXVUmRFEHLcbA(page_int),'after':lastId,}
   JpegojktaKMfGixSuYXVUmRFEHLcBQ=JpegojktaKMfGixSuYXVUmRFEHLcBb.callRequestCookies('Get',JpegojktaKMfGixSuYXVUmRFEHLcBw,payload=JpegojktaKMfGixSuYXVUmRFEHLcbw,params=JpegojktaKMfGixSuYXVUmRFEHLcBI,headers=JpegojktaKMfGixSuYXVUmRFEHLcbw,cookies=JpegojktaKMfGixSuYXVUmRFEHLcbw,redirects=JpegojktaKMfGixSuYXVUmRFEHLcbd)
   if JpegojktaKMfGixSuYXVUmRFEHLcBQ.status_code!=200:return[],JpegojktaKMfGixSuYXVUmRFEHLcbQ
   JpegojktaKMfGixSuYXVUmRFEHLcBP=json.loads(JpegojktaKMfGixSuYXVUmRFEHLcBQ.text)
   if JpegojktaKMfGixSuYXVUmRFEHLcBP.get('hasMore')==JpegojktaKMfGixSuYXVUmRFEHLcbd:JpegojktaKMfGixSuYXVUmRFEHLcBN=JpegojktaKMfGixSuYXVUmRFEHLcbd
   JpegojktaKMfGixSuYXVUmRFEHLcBT=JpegojktaKMfGixSuYXVUmRFEHLcBP.get('list')
   for JpegojktaKMfGixSuYXVUmRFEHLcBn in JpegojktaKMfGixSuYXVUmRFEHLcBT:
    JpegojktaKMfGixSuYXVUmRFEHLcld =JpegojktaKMfGixSuYXVUmRFEHLcBn.get('displayTitle')
    JpegojktaKMfGixSuYXVUmRFEHLclI =JpegojktaKMfGixSuYXVUmRFEHLcBn.get('clip').get('thumbnailUrl').replace('http://','https://')
    JpegojktaKMfGixSuYXVUmRFEHLclQ=JpegojktaKMfGixSuYXVUmRFEHLcBn.get('id')
    JpegojktaKMfGixSuYXVUmRFEHLclP =JpegojktaKMfGixSuYXVUmRFEHLcBn.get('clip').get('duration')
    JpegojktaKMfGixSuYXVUmRFEHLclT =JpegojktaKMfGixSuYXVUmRFEHLcBn.get('channel').get('name')
    JpegojktaKMfGixSuYXVUmRFEHLcln =JpegojktaKMfGixSuYXVUmRFEHLcBn.get('channel').get('description')
    JpegojktaKMfGixSuYXVUmRFEHLcBD={'clipTitle':JpegojktaKMfGixSuYXVUmRFEHLcld,'thumbnail':JpegojktaKMfGixSuYXVUmRFEHLclI,'clipLinkId':JpegojktaKMfGixSuYXVUmRFEHLclQ,'duration':JpegojktaKMfGixSuYXVUmRFEHLclP,'channelNm':JpegojktaKMfGixSuYXVUmRFEHLclT,'channelDs':JpegojktaKMfGixSuYXVUmRFEHLcln,}
    JpegojktaKMfGixSuYXVUmRFEHLclN.append(JpegojktaKMfGixSuYXVUmRFEHLcBD)
  except:
   return[],JpegojktaKMfGixSuYXVUmRFEHLcbQ
  return JpegojktaKMfGixSuYXVUmRFEHLclN,JpegojktaKMfGixSuYXVUmRFEHLcBN
 def Get_Live_List(JpegojktaKMfGixSuYXVUmRFEHLcBb,page_int):
  JpegojktaKMfGixSuYXVUmRFEHLclO=[]
  JpegojktaKMfGixSuYXVUmRFEHLcBN=JpegojktaKMfGixSuYXVUmRFEHLcbQ
  try:
   JpegojktaKMfGixSuYXVUmRFEHLcBw=JpegojktaKMfGixSuYXVUmRFEHLcBb.API_DOMAIN+'/api/v1/ft/home/livelinks'
   JpegojktaKMfGixSuYXVUmRFEHLcBI={'tab':'all','fields':'ccuCount,isShowCcuCount,thumbnailUrl,channel,live','sort':'CcuCount','size':JpegojktaKMfGixSuYXVUmRFEHLcbA(JpegojktaKMfGixSuYXVUmRFEHLcBb.PAGE_LIMIT),'page':JpegojktaKMfGixSuYXVUmRFEHLcbA(page_int),}
   JpegojktaKMfGixSuYXVUmRFEHLcBQ=JpegojktaKMfGixSuYXVUmRFEHLcBb.callRequestCookies('Get',JpegojktaKMfGixSuYXVUmRFEHLcBw,payload=JpegojktaKMfGixSuYXVUmRFEHLcbw,params=JpegojktaKMfGixSuYXVUmRFEHLcBI,headers=JpegojktaKMfGixSuYXVUmRFEHLcbw,cookies=JpegojktaKMfGixSuYXVUmRFEHLcbw,redirects=JpegojktaKMfGixSuYXVUmRFEHLcbd)
   if JpegojktaKMfGixSuYXVUmRFEHLcBQ.status_code!=200:return[],JpegojktaKMfGixSuYXVUmRFEHLcbQ
   JpegojktaKMfGixSuYXVUmRFEHLcBP=json.loads(JpegojktaKMfGixSuYXVUmRFEHLcBQ.text)
   if JpegojktaKMfGixSuYXVUmRFEHLcBP.get('hasMore')==JpegojktaKMfGixSuYXVUmRFEHLcbd:JpegojktaKMfGixSuYXVUmRFEHLcBN=JpegojktaKMfGixSuYXVUmRFEHLcbd
   JpegojktaKMfGixSuYXVUmRFEHLcBT=JpegojktaKMfGixSuYXVUmRFEHLcBP.get('list')
   for JpegojktaKMfGixSuYXVUmRFEHLcBn in JpegojktaKMfGixSuYXVUmRFEHLcBT:
    JpegojktaKMfGixSuYXVUmRFEHLclC =JpegojktaKMfGixSuYXVUmRFEHLcBn.get('id')
    JpegojktaKMfGixSuYXVUmRFEHLclD =JpegojktaKMfGixSuYXVUmRFEHLcBn.get('displayTitle')
    JpegojktaKMfGixSuYXVUmRFEHLclI =JpegojktaKMfGixSuYXVUmRFEHLcBn.get('live').get('thumbnailUrl').replace('http://','https://')
    JpegojktaKMfGixSuYXVUmRFEHLclT=JpegojktaKMfGixSuYXVUmRFEHLcBn.get('channel').get('name')
    JpegojktaKMfGixSuYXVUmRFEHLcBD={'liveId':JpegojktaKMfGixSuYXVUmRFEHLclC,'liveNm':JpegojktaKMfGixSuYXVUmRFEHLclD,'thumbnail':JpegojktaKMfGixSuYXVUmRFEHLclI,'channelNm':JpegojktaKMfGixSuYXVUmRFEHLclT,}
    JpegojktaKMfGixSuYXVUmRFEHLclO.append(JpegojktaKMfGixSuYXVUmRFEHLcBD)
  except:
   return[],JpegojktaKMfGixSuYXVUmRFEHLcbQ
  return JpegojktaKMfGixSuYXVUmRFEHLclO,JpegojktaKMfGixSuYXVUmRFEHLcBN
 def GetSearchList(JpegojktaKMfGixSuYXVUmRFEHLcBb,search_key,page_int,stype):
  JpegojktaKMfGixSuYXVUmRFEHLclh=[]
  JpegojktaKMfGixSuYXVUmRFEHLcBN=JpegojktaKMfGixSuYXVUmRFEHLcbQ
  try:
   JpegojktaKMfGixSuYXVUmRFEHLcBw=JpegojktaKMfGixSuYXVUmRFEHLcBb.API_DOMAIN+'/api/v1/ft/search/'+stype 
   if stype=='channels':
    JpegojktaKMfGixSuYXVUmRFEHLclz='-channelNoticeList,-hasBizChannel,-friendCount,friendChannel'
   else:
    JpegojktaKMfGixSuYXVUmRFEHLclz='-user,-clipChapterThumbnailList,-tagList'
   JpegojktaKMfGixSuYXVUmRFEHLcBI={'sort':'Score','q':search_key,'fulllevels':'list','fields':JpegojktaKMfGixSuYXVUmRFEHLclz,'size':JpegojktaKMfGixSuYXVUmRFEHLcbA(JpegojktaKMfGixSuYXVUmRFEHLcBb.PAGE_LIMIT),'page':JpegojktaKMfGixSuYXVUmRFEHLcbA(page_int),}
   JpegojktaKMfGixSuYXVUmRFEHLcBQ=JpegojktaKMfGixSuYXVUmRFEHLcBb.callRequestCookies('Get',JpegojktaKMfGixSuYXVUmRFEHLcBw,payload=JpegojktaKMfGixSuYXVUmRFEHLcbw,params=JpegojktaKMfGixSuYXVUmRFEHLcBI,headers=JpegojktaKMfGixSuYXVUmRFEHLcbw,cookies=JpegojktaKMfGixSuYXVUmRFEHLcbw,redirects=JpegojktaKMfGixSuYXVUmRFEHLcbd)
   if JpegojktaKMfGixSuYXVUmRFEHLcBQ.status_code!=200:return[],JpegojktaKMfGixSuYXVUmRFEHLcbQ
   JpegojktaKMfGixSuYXVUmRFEHLcBP=json.loads(JpegojktaKMfGixSuYXVUmRFEHLcBQ.text)
   if JpegojktaKMfGixSuYXVUmRFEHLcBP.get('hasMore')==JpegojktaKMfGixSuYXVUmRFEHLcbd:JpegojktaKMfGixSuYXVUmRFEHLcBN=JpegojktaKMfGixSuYXVUmRFEHLcbd
   JpegojktaKMfGixSuYXVUmRFEHLcBT=JpegojktaKMfGixSuYXVUmRFEHLcBP.get('list')
   for JpegojktaKMfGixSuYXVUmRFEHLcBn in JpegojktaKMfGixSuYXVUmRFEHLcBT:
    if stype=='channels':
     JpegojktaKMfGixSuYXVUmRFEHLcBO =JpegojktaKMfGixSuYXVUmRFEHLcBn.get('channelSkinData').get('profileImageUrl').replace('http://','https://')
     JpegojktaKMfGixSuYXVUmRFEHLcBC =JpegojktaKMfGixSuYXVUmRFEHLcBn.get('channelSkinData').get('bannerImageUrl').replace('http://','https://')
     JpegojktaKMfGixSuYXVUmRFEHLcbB =JpegojktaKMfGixSuYXVUmRFEHLcBn.get('id')
     JpegojktaKMfGixSuYXVUmRFEHLcbl =JpegojktaKMfGixSuYXVUmRFEHLcBn.get('name')
     JpegojktaKMfGixSuYXVUmRFEHLcbr =JpegojktaKMfGixSuYXVUmRFEHLcBn.get('description')
     JpegojktaKMfGixSuYXVUmRFEHLcbs =JpegojktaKMfGixSuYXVUmRFEHLcBn.get('tagList')
     JpegojktaKMfGixSuYXVUmRFEHLcby ={'poster':JpegojktaKMfGixSuYXVUmRFEHLcBO,'thumb':JpegojktaKMfGixSuYXVUmRFEHLcBO,'fanart':JpegojktaKMfGixSuYXVUmRFEHLcBC}
     JpegojktaKMfGixSuYXVUmRFEHLcBD={'channelId':JpegojktaKMfGixSuYXVUmRFEHLcbB,'title':JpegojktaKMfGixSuYXVUmRFEHLcbl,'synopsis':JpegojktaKMfGixSuYXVUmRFEHLcbr,'tagList':JpegojktaKMfGixSuYXVUmRFEHLcbs,'thumbnail':JpegojktaKMfGixSuYXVUmRFEHLcby,}
    else:
     JpegojktaKMfGixSuYXVUmRFEHLcld =JpegojktaKMfGixSuYXVUmRFEHLcBn.get('displayTitle')
     JpegojktaKMfGixSuYXVUmRFEHLclI =JpegojktaKMfGixSuYXVUmRFEHLcBn.get('clip').get('thumbnailUrl').replace('http://','https://')
     JpegojktaKMfGixSuYXVUmRFEHLclQ=JpegojktaKMfGixSuYXVUmRFEHLcBn.get('id')
     JpegojktaKMfGixSuYXVUmRFEHLclP =JpegojktaKMfGixSuYXVUmRFEHLcBn.get('clip').get('duration')
     JpegojktaKMfGixSuYXVUmRFEHLclT =JpegojktaKMfGixSuYXVUmRFEHLcBn.get('channel').get('name')
     JpegojktaKMfGixSuYXVUmRFEHLcln =JpegojktaKMfGixSuYXVUmRFEHLcBn.get('channel').get('description') 
     JpegojktaKMfGixSuYXVUmRFEHLcBD={'title':JpegojktaKMfGixSuYXVUmRFEHLcld,'thumbnail':JpegojktaKMfGixSuYXVUmRFEHLclI,'clipLinkId':JpegojktaKMfGixSuYXVUmRFEHLclQ,'duration':JpegojktaKMfGixSuYXVUmRFEHLclP,'channelNm':JpegojktaKMfGixSuYXVUmRFEHLclT,'channelDs':JpegojktaKMfGixSuYXVUmRFEHLcln,}
    JpegojktaKMfGixSuYXVUmRFEHLclh.append(JpegojktaKMfGixSuYXVUmRFEHLcBD)
  except:
   return[],JpegojktaKMfGixSuYXVUmRFEHLcbQ
  return JpegojktaKMfGixSuYXVUmRFEHLclh,JpegojktaKMfGixSuYXVUmRFEHLcBN
# Created by pyminifier (https://github.com/liftoff/pyminifier)
