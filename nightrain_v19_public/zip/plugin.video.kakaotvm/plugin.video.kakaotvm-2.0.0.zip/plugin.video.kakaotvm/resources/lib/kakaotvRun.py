__author__="NightRain"
EahPquDoNKMJedTcFGpSkOQXlifyLj=object
EahPquDoNKMJedTcFGpSkOQXlifyLC=None
EahPquDoNKMJedTcFGpSkOQXlifyLV=True
EahPquDoNKMJedTcFGpSkOQXlifyLs=False
EahPquDoNKMJedTcFGpSkOQXlifyLH=type
EahPquDoNKMJedTcFGpSkOQXlifyBW=dict
EahPquDoNKMJedTcFGpSkOQXlifyBw=int
EahPquDoNKMJedTcFGpSkOQXlifyBL=str
EahPquDoNKMJedTcFGpSkOQXlifyBm=len
EahPquDoNKMJedTcFGpSkOQXlifyBR=range
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
EahPquDoNKMJedTcFGpSkOQXlifyWL=[{'title':'채널별 보기','mode':'CHANNEL_GROUP','icon':'channel.png'},{'title':'인기 오리지널','mode':'ORIGINAL_LIST','icon':'original.png'},{'title':'인기 라이브 (360P)','mode':'LIVE_LIST','icon':'live.png'},{'title':'-----------------','mode':'XXX'},{'title':'검색','mode':'SEARCH_GROUP','icon':'search.png'},]
EahPquDoNKMJedTcFGpSkOQXlifyWB=['오리지널','스포츠','게임','엔터테인먼트','애니멀','뷰티','푸드','라이프','키즈','뉴스','교양','취미']
EahPquDoNKMJedTcFGpSkOQXlifyWm=[{'title':'채널 검색','mode':'LOCAL_SEARCH','stype':'channels'},{'title':'영상(clip) 검색','mode':'LOCAL_SEARCH','stype':'cliplinks'},]
from kakaotvCore import*
class EahPquDoNKMJedTcFGpSkOQXlifyWw(EahPquDoNKMJedTcFGpSkOQXlifyLj):
 def __init__(EahPquDoNKMJedTcFGpSkOQXlifyWR,EahPquDoNKMJedTcFGpSkOQXlifyWn,EahPquDoNKMJedTcFGpSkOQXlifyWg,EahPquDoNKMJedTcFGpSkOQXlifyWA):
  EahPquDoNKMJedTcFGpSkOQXlifyWR._addon_url =EahPquDoNKMJedTcFGpSkOQXlifyWn
  EahPquDoNKMJedTcFGpSkOQXlifyWR._addon_handle=EahPquDoNKMJedTcFGpSkOQXlifyWg
  EahPquDoNKMJedTcFGpSkOQXlifyWR.main_params =EahPquDoNKMJedTcFGpSkOQXlifyWA
  EahPquDoNKMJedTcFGpSkOQXlifyWR.KakaotvObj =JpegojktaKMfGixSuYXVUmRFEHLcBl() 
 def addon_noti(EahPquDoNKMJedTcFGpSkOQXlifyWR,sting):
  try:
   EahPquDoNKMJedTcFGpSkOQXlifyWb=xbmcgui.Dialog()
   EahPquDoNKMJedTcFGpSkOQXlifyWb.notification(__addonname__,sting)
  except:
   EahPquDoNKMJedTcFGpSkOQXlifyLC
 def addon_log(EahPquDoNKMJedTcFGpSkOQXlifyWR,string):
  try:
   EahPquDoNKMJedTcFGpSkOQXlifyWt=string.encode('utf-8','ignore')
  except:
   EahPquDoNKMJedTcFGpSkOQXlifyWt='addonException: addon_log'
  EahPquDoNKMJedTcFGpSkOQXlifyWx=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,EahPquDoNKMJedTcFGpSkOQXlifyWt),level=EahPquDoNKMJedTcFGpSkOQXlifyWx)
 def get_keyboard_input(EahPquDoNKMJedTcFGpSkOQXlifyWR,EahPquDoNKMJedTcFGpSkOQXlifyWY):
  EahPquDoNKMJedTcFGpSkOQXlifyWU=EahPquDoNKMJedTcFGpSkOQXlifyLC
  kb=xbmc.Keyboard()
  kb.setHeading(EahPquDoNKMJedTcFGpSkOQXlifyWY)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   EahPquDoNKMJedTcFGpSkOQXlifyWU=kb.getText()
  return EahPquDoNKMJedTcFGpSkOQXlifyWU
 def add_dir(EahPquDoNKMJedTcFGpSkOQXlifyWR,label,sublabel='',img='',infoLabels=EahPquDoNKMJedTcFGpSkOQXlifyLC,isFolder=EahPquDoNKMJedTcFGpSkOQXlifyLV,params='',isLink=EahPquDoNKMJedTcFGpSkOQXlifyLs,ContextMenu=EahPquDoNKMJedTcFGpSkOQXlifyLC):
  EahPquDoNKMJedTcFGpSkOQXlifyWz='%s?%s'%(EahPquDoNKMJedTcFGpSkOQXlifyWR._addon_url,urllib.parse.urlencode(params))
  if sublabel:EahPquDoNKMJedTcFGpSkOQXlifyWY='%s < %s >'%(label,sublabel)
  else: EahPquDoNKMJedTcFGpSkOQXlifyWY=label
  if not img:img='DefaultFolder.png'
  EahPquDoNKMJedTcFGpSkOQXlifyWr=xbmcgui.ListItem(EahPquDoNKMJedTcFGpSkOQXlifyWY)
  if EahPquDoNKMJedTcFGpSkOQXlifyLH(img)==EahPquDoNKMJedTcFGpSkOQXlifyBW:
   EahPquDoNKMJedTcFGpSkOQXlifyWr.setArt(img)
  else:
   EahPquDoNKMJedTcFGpSkOQXlifyWr.setArt({'thumb':img,'poster':img})
  if infoLabels:EahPquDoNKMJedTcFGpSkOQXlifyWr.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   EahPquDoNKMJedTcFGpSkOQXlifyWr.setProperty('IsPlayable','true')
  if ContextMenu:EahPquDoNKMJedTcFGpSkOQXlifyWr.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(EahPquDoNKMJedTcFGpSkOQXlifyWR._addon_handle,EahPquDoNKMJedTcFGpSkOQXlifyWz,EahPquDoNKMJedTcFGpSkOQXlifyWr,isFolder)
 def get_selQuality(EahPquDoNKMJedTcFGpSkOQXlifyWR):
  EahPquDoNKMJedTcFGpSkOQXlifyWv='selected_quality'
  EahPquDoNKMJedTcFGpSkOQXlifyWj=['HIGH4','HIGH','MAIN','BASE']
  EahPquDoNKMJedTcFGpSkOQXlifyWC=EahPquDoNKMJedTcFGpSkOQXlifyBw(__addon__.getSetting(EahPquDoNKMJedTcFGpSkOQXlifyWv))
  return EahPquDoNKMJedTcFGpSkOQXlifyWj[EahPquDoNKMJedTcFGpSkOQXlifyWC]
 def dp_Main_List(EahPquDoNKMJedTcFGpSkOQXlifyWR,args):
  for EahPquDoNKMJedTcFGpSkOQXlifyWV in EahPquDoNKMJedTcFGpSkOQXlifyWL:
   EahPquDoNKMJedTcFGpSkOQXlifyWY=EahPquDoNKMJedTcFGpSkOQXlifyWV.get('title')
   EahPquDoNKMJedTcFGpSkOQXlifyWs=''
   EahPquDoNKMJedTcFGpSkOQXlifyWH={'mode':EahPquDoNKMJedTcFGpSkOQXlifyWV.get('mode'),}
   if EahPquDoNKMJedTcFGpSkOQXlifyWV.get('mode')in['XXX']:
    EahPquDoNKMJedTcFGpSkOQXlifywW=EahPquDoNKMJedTcFGpSkOQXlifyLs
    EahPquDoNKMJedTcFGpSkOQXlifywL =EahPquDoNKMJedTcFGpSkOQXlifyLV
   else:
    EahPquDoNKMJedTcFGpSkOQXlifywW=EahPquDoNKMJedTcFGpSkOQXlifyLV
    EahPquDoNKMJedTcFGpSkOQXlifywL =EahPquDoNKMJedTcFGpSkOQXlifyLs
   if 'icon' in EahPquDoNKMJedTcFGpSkOQXlifyWV:EahPquDoNKMJedTcFGpSkOQXlifyWs=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',EahPquDoNKMJedTcFGpSkOQXlifyWV.get('icon')) 
   EahPquDoNKMJedTcFGpSkOQXlifyWR.add_dir(EahPquDoNKMJedTcFGpSkOQXlifyWY,sublabel='',img=EahPquDoNKMJedTcFGpSkOQXlifyWs,infoLabels=EahPquDoNKMJedTcFGpSkOQXlifyLC,isFolder=EahPquDoNKMJedTcFGpSkOQXlifywW,params=EahPquDoNKMJedTcFGpSkOQXlifyWH,isLink=EahPquDoNKMJedTcFGpSkOQXlifywL)
  xbmcplugin.endOfDirectory(EahPquDoNKMJedTcFGpSkOQXlifyWR._addon_handle)
 def dp_Channel_GroupList(EahPquDoNKMJedTcFGpSkOQXlifyWR,args):
  EahPquDoNKMJedTcFGpSkOQXlifywm=EahPquDoNKMJedTcFGpSkOQXlifyWB
  for EahPquDoNKMJedTcFGpSkOQXlifywR in EahPquDoNKMJedTcFGpSkOQXlifywm:
   EahPquDoNKMJedTcFGpSkOQXlifyWH={'mode':'CHANNEL_LIST','groupNm':EahPquDoNKMJedTcFGpSkOQXlifywR,'page':'1',}
   EahPquDoNKMJedTcFGpSkOQXlifyWR.add_dir(EahPquDoNKMJedTcFGpSkOQXlifywR,sublabel='',img='',infoLabels=EahPquDoNKMJedTcFGpSkOQXlifyLC,isFolder=EahPquDoNKMJedTcFGpSkOQXlifyLV,params=EahPquDoNKMJedTcFGpSkOQXlifyWH)
  xbmcplugin.endOfDirectory(EahPquDoNKMJedTcFGpSkOQXlifyWR._addon_handle,cacheToDisc=EahPquDoNKMJedTcFGpSkOQXlifyLV)
 def dp_Channel_List(EahPquDoNKMJedTcFGpSkOQXlifyWR,args):
  EahPquDoNKMJedTcFGpSkOQXlifywg =args.get('groupNm')
  EahPquDoNKMJedTcFGpSkOQXlifywA =EahPquDoNKMJedTcFGpSkOQXlifyBw(args.get('page'))
  EahPquDoNKMJedTcFGpSkOQXlifywm,EahPquDoNKMJedTcFGpSkOQXlifywI=EahPquDoNKMJedTcFGpSkOQXlifyWR.KakaotvObj.Get_Channel_List(EahPquDoNKMJedTcFGpSkOQXlifywg,EahPquDoNKMJedTcFGpSkOQXlifywA)
  for EahPquDoNKMJedTcFGpSkOQXlifywR in EahPquDoNKMJedTcFGpSkOQXlifywm:
   EahPquDoNKMJedTcFGpSkOQXlifywb=EahPquDoNKMJedTcFGpSkOQXlifywR.get('channelId')
   EahPquDoNKMJedTcFGpSkOQXlifyWY =EahPquDoNKMJedTcFGpSkOQXlifywR.get('title')
   EahPquDoNKMJedTcFGpSkOQXlifywt =EahPquDoNKMJedTcFGpSkOQXlifywR.get('synopsis')
   EahPquDoNKMJedTcFGpSkOQXlifywx =EahPquDoNKMJedTcFGpSkOQXlifywR.get('tagList')
   EahPquDoNKMJedTcFGpSkOQXlifywU=EahPquDoNKMJedTcFGpSkOQXlifywR.get('thumbnail')
   EahPquDoNKMJedTcFGpSkOQXlifywz={'mediatype':'tvshow','title':EahPquDoNKMJedTcFGpSkOQXlifyWY,'genre':EahPquDoNKMJedTcFGpSkOQXlifywx,'plot':EahPquDoNKMJedTcFGpSkOQXlifywt,}
   EahPquDoNKMJedTcFGpSkOQXlifyWH={'mode':'CH_PLAY_LIST','channelId':EahPquDoNKMJedTcFGpSkOQXlifywb,'page':'1',}
   EahPquDoNKMJedTcFGpSkOQXlifyWR.add_dir(EahPquDoNKMJedTcFGpSkOQXlifyWY,sublabel='',img=EahPquDoNKMJedTcFGpSkOQXlifywU,infoLabels=EahPquDoNKMJedTcFGpSkOQXlifywz,isFolder=EahPquDoNKMJedTcFGpSkOQXlifyLV,params=EahPquDoNKMJedTcFGpSkOQXlifyWH)
  if EahPquDoNKMJedTcFGpSkOQXlifywI:
   EahPquDoNKMJedTcFGpSkOQXlifyWH['mode'] ='CHANNEL_LIST' 
   EahPquDoNKMJedTcFGpSkOQXlifyWH['groupNm'] =EahPquDoNKMJedTcFGpSkOQXlifywg
   EahPquDoNKMJedTcFGpSkOQXlifyWH['page'] =EahPquDoNKMJedTcFGpSkOQXlifyBL(EahPquDoNKMJedTcFGpSkOQXlifywA+1)
   EahPquDoNKMJedTcFGpSkOQXlifyWY='[B]%s >>[/B]'%'다음 페이지'
   EahPquDoNKMJedTcFGpSkOQXlifywY=EahPquDoNKMJedTcFGpSkOQXlifyBL(EahPquDoNKMJedTcFGpSkOQXlifywA+1)
   EahPquDoNKMJedTcFGpSkOQXlifyWs=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   EahPquDoNKMJedTcFGpSkOQXlifyWR.add_dir(EahPquDoNKMJedTcFGpSkOQXlifyWY,sublabel=EahPquDoNKMJedTcFGpSkOQXlifywY,img=EahPquDoNKMJedTcFGpSkOQXlifyWs,infoLabels=EahPquDoNKMJedTcFGpSkOQXlifyLC,isFolder=EahPquDoNKMJedTcFGpSkOQXlifyLV,params=EahPquDoNKMJedTcFGpSkOQXlifyWH)
  xbmcplugin.setContent(EahPquDoNKMJedTcFGpSkOQXlifyWR._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(EahPquDoNKMJedTcFGpSkOQXlifyWR._addon_handle,cacheToDisc=EahPquDoNKMJedTcFGpSkOQXlifyLV)
 def dp_Channel_Playlist(EahPquDoNKMJedTcFGpSkOQXlifyWR,args):
  EahPquDoNKMJedTcFGpSkOQXlifywb =args.get('channelId')
  EahPquDoNKMJedTcFGpSkOQXlifywm=EahPquDoNKMJedTcFGpSkOQXlifyWR.KakaotvObj.Get_Channel_Playlist(EahPquDoNKMJedTcFGpSkOQXlifywb)
  for EahPquDoNKMJedTcFGpSkOQXlifywR in EahPquDoNKMJedTcFGpSkOQXlifywm:
   EahPquDoNKMJedTcFGpSkOQXlifywr=EahPquDoNKMJedTcFGpSkOQXlifywR.get('playlistId')
   EahPquDoNKMJedTcFGpSkOQXlifywv=EahPquDoNKMJedTcFGpSkOQXlifywR.get('playlistNm')
   EahPquDoNKMJedTcFGpSkOQXlifywj =EahPquDoNKMJedTcFGpSkOQXlifywR.get('vodCount')
   EahPquDoNKMJedTcFGpSkOQXlifywU =EahPquDoNKMJedTcFGpSkOQXlifywR.get('thumbnail')
   EahPquDoNKMJedTcFGpSkOQXlifywU ={'thumb':EahPquDoNKMJedTcFGpSkOQXlifywU,'fanart':EahPquDoNKMJedTcFGpSkOQXlifywU}
   EahPquDoNKMJedTcFGpSkOQXlifywz={'mediatype':'tvshow','title':EahPquDoNKMJedTcFGpSkOQXlifywv,'plot':'영상 목록 : %s 개'%(EahPquDoNKMJedTcFGpSkOQXlifywj),}
   EahPquDoNKMJedTcFGpSkOQXlifyWH={'mode':'EPISODE_LIST','channelId':EahPquDoNKMJedTcFGpSkOQXlifywb,'playlistId':EahPquDoNKMJedTcFGpSkOQXlifywr,}
   EahPquDoNKMJedTcFGpSkOQXlifyWR.add_dir(EahPquDoNKMJedTcFGpSkOQXlifywv,sublabel='',img=EahPquDoNKMJedTcFGpSkOQXlifywU,infoLabels=EahPquDoNKMJedTcFGpSkOQXlifywz,isFolder=EahPquDoNKMJedTcFGpSkOQXlifyLV,params=EahPquDoNKMJedTcFGpSkOQXlifyWH)
  xbmcplugin.setContent(EahPquDoNKMJedTcFGpSkOQXlifyWR._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(EahPquDoNKMJedTcFGpSkOQXlifyWR._addon_handle,cacheToDisc=EahPquDoNKMJedTcFGpSkOQXlifyLV)
 def dp_Episode_List(EahPquDoNKMJedTcFGpSkOQXlifyWR,args):
  EahPquDoNKMJedTcFGpSkOQXlifywb =args.get('channelId')
  EahPquDoNKMJedTcFGpSkOQXlifywr =args.get('playlistId')
  EahPquDoNKMJedTcFGpSkOQXlifywm=EahPquDoNKMJedTcFGpSkOQXlifyWR.KakaotvObj.Get_Episode_List(EahPquDoNKMJedTcFGpSkOQXlifywb,EahPquDoNKMJedTcFGpSkOQXlifywr)
  for EahPquDoNKMJedTcFGpSkOQXlifywR in EahPquDoNKMJedTcFGpSkOQXlifywm:
   EahPquDoNKMJedTcFGpSkOQXlifywC=EahPquDoNKMJedTcFGpSkOQXlifywR.get('clipLinkId')
   EahPquDoNKMJedTcFGpSkOQXlifywV =EahPquDoNKMJedTcFGpSkOQXlifywR.get('clipTitle')
   EahPquDoNKMJedTcFGpSkOQXlifyws =EahPquDoNKMJedTcFGpSkOQXlifywR.get('chargeTxt')
   EahPquDoNKMJedTcFGpSkOQXlifywU =EahPquDoNKMJedTcFGpSkOQXlifywR.get('thumbnail')
   EahPquDoNKMJedTcFGpSkOQXlifywU ={'thumb':EahPquDoNKMJedTcFGpSkOQXlifywU,'fanart':EahPquDoNKMJedTcFGpSkOQXlifywU}
   EahPquDoNKMJedTcFGpSkOQXlifywz={'mediatype':'episode','title':EahPquDoNKMJedTcFGpSkOQXlifywV,'plot':'%s\n\n%s'%(EahPquDoNKMJedTcFGpSkOQXlifywV,EahPquDoNKMJedTcFGpSkOQXlifyws)}
   EahPquDoNKMJedTcFGpSkOQXlifyWH={'mode':'VOD','channelId':EahPquDoNKMJedTcFGpSkOQXlifywb,'playlistId':EahPquDoNKMJedTcFGpSkOQXlifywr,'clipLinkId':EahPquDoNKMJedTcFGpSkOQXlifywC,}
   EahPquDoNKMJedTcFGpSkOQXlifyWR.add_dir(EahPquDoNKMJedTcFGpSkOQXlifywV,sublabel=EahPquDoNKMJedTcFGpSkOQXlifyws,img=EahPquDoNKMJedTcFGpSkOQXlifywU,infoLabels=EahPquDoNKMJedTcFGpSkOQXlifywz,isFolder=EahPquDoNKMJedTcFGpSkOQXlifyLs,params=EahPquDoNKMJedTcFGpSkOQXlifyWH)
  xbmcplugin.setContent(EahPquDoNKMJedTcFGpSkOQXlifyWR._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(EahPquDoNKMJedTcFGpSkOQXlifyWR._addon_handle,cacheToDisc=EahPquDoNKMJedTcFGpSkOQXlifyLV)
 def play_VIDEO(EahPquDoNKMJedTcFGpSkOQXlifyWR,args):
  EahPquDoNKMJedTcFGpSkOQXlifywH =args.get('mode')
  EahPquDoNKMJedTcFGpSkOQXlifywC =args.get('clipLinkId')
  EahPquDoNKMJedTcFGpSkOQXlifyLW =EahPquDoNKMJedTcFGpSkOQXlifyWR.get_selQuality()
  if EahPquDoNKMJedTcFGpSkOQXlifywH=='VOD':
   EahPquDoNKMJedTcFGpSkOQXlifyLw,EahPquDoNKMJedTcFGpSkOQXlifyLB=EahPquDoNKMJedTcFGpSkOQXlifyWR.KakaotvObj.GetStreamingURL(EahPquDoNKMJedTcFGpSkOQXlifywC,EahPquDoNKMJedTcFGpSkOQXlifyLW)
  else:
   EahPquDoNKMJedTcFGpSkOQXlifyLw,EahPquDoNKMJedTcFGpSkOQXlifyLB=EahPquDoNKMJedTcFGpSkOQXlifyWR.KakaotvObj.GetLiveURL(EahPquDoNKMJedTcFGpSkOQXlifywC,EahPquDoNKMJedTcFGpSkOQXlifyLW)
  if EahPquDoNKMJedTcFGpSkOQXlifyLw=='':
   EahPquDoNKMJedTcFGpSkOQXlifyWR.addon_noti(__language__(30901).encode('utf8'))
   return
  EahPquDoNKMJedTcFGpSkOQXlifyLm=xbmcgui.ListItem(path=EahPquDoNKMJedTcFGpSkOQXlifyLw)
  EahPquDoNKMJedTcFGpSkOQXlifyWR.addon_log(EahPquDoNKMJedTcFGpSkOQXlifyLw)
  if EahPquDoNKMJedTcFGpSkOQXlifywH=='VOD':
   EahPquDoNKMJedTcFGpSkOQXlifyLm.setContentLookup(EahPquDoNKMJedTcFGpSkOQXlifyLs)
   EahPquDoNKMJedTcFGpSkOQXlifyLm.setMimeType('video/mp4')
   EahPquDoNKMJedTcFGpSkOQXlifyLm.setProperty('inputstream','inputstream.ffmpegdirect')
   EahPquDoNKMJedTcFGpSkOQXlifyLm.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   EahPquDoNKMJedTcFGpSkOQXlifyLm.setProperty('inputstream.ffmpegdirect.mime_type','video/mp4')
  xbmcplugin.setResolvedUrl(EahPquDoNKMJedTcFGpSkOQXlifyWR._addon_handle,EahPquDoNKMJedTcFGpSkOQXlifyLV,EahPquDoNKMJedTcFGpSkOQXlifyLm)
 def dp_Original_List(EahPquDoNKMJedTcFGpSkOQXlifyWR,args):
  EahPquDoNKMJedTcFGpSkOQXlifyLR =args.get('page')
  EahPquDoNKMJedTcFGpSkOQXlifyLn =args.get('lastId')
  if EahPquDoNKMJedTcFGpSkOQXlifyLR ==EahPquDoNKMJedTcFGpSkOQXlifyLC:EahPquDoNKMJedTcFGpSkOQXlifyLR='1'
  if EahPquDoNKMJedTcFGpSkOQXlifyLn==EahPquDoNKMJedTcFGpSkOQXlifyLC:EahPquDoNKMJedTcFGpSkOQXlifyLn=''
  EahPquDoNKMJedTcFGpSkOQXlifywA=EahPquDoNKMJedTcFGpSkOQXlifyBw(EahPquDoNKMJedTcFGpSkOQXlifyLR)
  EahPquDoNKMJedTcFGpSkOQXlifywm,EahPquDoNKMJedTcFGpSkOQXlifywI=EahPquDoNKMJedTcFGpSkOQXlifyWR.KakaotvObj.Get_Original_List(EahPquDoNKMJedTcFGpSkOQXlifywA,EahPquDoNKMJedTcFGpSkOQXlifyLn)
  for EahPquDoNKMJedTcFGpSkOQXlifywR in EahPquDoNKMJedTcFGpSkOQXlifywm:
   EahPquDoNKMJedTcFGpSkOQXlifywV =EahPquDoNKMJedTcFGpSkOQXlifywR.get('clipTitle')
   EahPquDoNKMJedTcFGpSkOQXlifywC=EahPquDoNKMJedTcFGpSkOQXlifywR.get('clipLinkId')
   EahPquDoNKMJedTcFGpSkOQXlifyLg =EahPquDoNKMJedTcFGpSkOQXlifywR.get('duration')
   EahPquDoNKMJedTcFGpSkOQXlifyLA =EahPquDoNKMJedTcFGpSkOQXlifywR.get('channelNm')
   EahPquDoNKMJedTcFGpSkOQXlifyLI =EahPquDoNKMJedTcFGpSkOQXlifywR.get('channelDs')
   EahPquDoNKMJedTcFGpSkOQXlifywU=EahPquDoNKMJedTcFGpSkOQXlifywR.get('thumbnail')
   EahPquDoNKMJedTcFGpSkOQXlifywU={'thumb':EahPquDoNKMJedTcFGpSkOQXlifywU,'fanart':EahPquDoNKMJedTcFGpSkOQXlifywU}
   EahPquDoNKMJedTcFGpSkOQXlifywz={'mediatype':'episode','title':EahPquDoNKMJedTcFGpSkOQXlifywV,'plot':'%s\n\n\n[ %s ]\n\n%s'%(EahPquDoNKMJedTcFGpSkOQXlifywV,EahPquDoNKMJedTcFGpSkOQXlifyLA,EahPquDoNKMJedTcFGpSkOQXlifyLI),'duration':EahPquDoNKMJedTcFGpSkOQXlifyLg,}
   EahPquDoNKMJedTcFGpSkOQXlifyWH={'mode':'VOD','clipLinkId':EahPquDoNKMJedTcFGpSkOQXlifywC,}
   EahPquDoNKMJedTcFGpSkOQXlifyWR.add_dir(EahPquDoNKMJedTcFGpSkOQXlifywV,sublabel='',img=EahPquDoNKMJedTcFGpSkOQXlifywU,infoLabels=EahPquDoNKMJedTcFGpSkOQXlifywz,isFolder=EahPquDoNKMJedTcFGpSkOQXlifyLs,params=EahPquDoNKMJedTcFGpSkOQXlifyWH)
   EahPquDoNKMJedTcFGpSkOQXlifyLn=EahPquDoNKMJedTcFGpSkOQXlifywC 
  if EahPquDoNKMJedTcFGpSkOQXlifywI:
   EahPquDoNKMJedTcFGpSkOQXlifyWH['mode'] ='ORIGINAL_LIST' 
   EahPquDoNKMJedTcFGpSkOQXlifyWH['lastId'] =EahPquDoNKMJedTcFGpSkOQXlifyLn
   EahPquDoNKMJedTcFGpSkOQXlifyWH['page'] =EahPquDoNKMJedTcFGpSkOQXlifyBL(EahPquDoNKMJedTcFGpSkOQXlifywA+1)
   EahPquDoNKMJedTcFGpSkOQXlifyWY='[B]%s >>[/B]'%'다음 페이지'
   EahPquDoNKMJedTcFGpSkOQXlifywY=EahPquDoNKMJedTcFGpSkOQXlifyBL(EahPquDoNKMJedTcFGpSkOQXlifywA+1)
   EahPquDoNKMJedTcFGpSkOQXlifyWs=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   EahPquDoNKMJedTcFGpSkOQXlifyWR.add_dir(EahPquDoNKMJedTcFGpSkOQXlifyWY,sublabel=EahPquDoNKMJedTcFGpSkOQXlifywY,img=EahPquDoNKMJedTcFGpSkOQXlifyWs,infoLabels=EahPquDoNKMJedTcFGpSkOQXlifyLC,isFolder=EahPquDoNKMJedTcFGpSkOQXlifyLV,params=EahPquDoNKMJedTcFGpSkOQXlifyWH)
  xbmcplugin.setContent(EahPquDoNKMJedTcFGpSkOQXlifyWR._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(EahPquDoNKMJedTcFGpSkOQXlifyWR._addon_handle,cacheToDisc=EahPquDoNKMJedTcFGpSkOQXlifyLs)
 def Get_Live_List(EahPquDoNKMJedTcFGpSkOQXlifyWR,args):
  EahPquDoNKMJedTcFGpSkOQXlifyLR =args.get('page')
  if EahPquDoNKMJedTcFGpSkOQXlifyLR ==EahPquDoNKMJedTcFGpSkOQXlifyLC:EahPquDoNKMJedTcFGpSkOQXlifyLR='1'
  EahPquDoNKMJedTcFGpSkOQXlifywA=EahPquDoNKMJedTcFGpSkOQXlifyBw(EahPquDoNKMJedTcFGpSkOQXlifyLR)
  EahPquDoNKMJedTcFGpSkOQXlifywm,EahPquDoNKMJedTcFGpSkOQXlifywI=EahPquDoNKMJedTcFGpSkOQXlifyWR.KakaotvObj.Get_Live_List(EahPquDoNKMJedTcFGpSkOQXlifywA)
  for EahPquDoNKMJedTcFGpSkOQXlifywR in EahPquDoNKMJedTcFGpSkOQXlifywm:
   EahPquDoNKMJedTcFGpSkOQXlifyLb =EahPquDoNKMJedTcFGpSkOQXlifywR.get('liveId')
   EahPquDoNKMJedTcFGpSkOQXlifyLt =EahPquDoNKMJedTcFGpSkOQXlifywR.get('liveNm')
   EahPquDoNKMJedTcFGpSkOQXlifyLA=EahPquDoNKMJedTcFGpSkOQXlifywR.get('channelNm')
   EahPquDoNKMJedTcFGpSkOQXlifywU=EahPquDoNKMJedTcFGpSkOQXlifywR.get('thumbnail')
   EahPquDoNKMJedTcFGpSkOQXlifywU={'thumb':EahPquDoNKMJedTcFGpSkOQXlifywU,'fanart':EahPquDoNKMJedTcFGpSkOQXlifywU}
   EahPquDoNKMJedTcFGpSkOQXlifywz={'mediatype':'episode','title':EahPquDoNKMJedTcFGpSkOQXlifyLt,'plot':'[ %s ]\n\n%s'%(EahPquDoNKMJedTcFGpSkOQXlifyLA,EahPquDoNKMJedTcFGpSkOQXlifyLt),}
   EahPquDoNKMJedTcFGpSkOQXlifyWH={'mode':'LIVE','clipLinkId':EahPquDoNKMJedTcFGpSkOQXlifyLb,}
   EahPquDoNKMJedTcFGpSkOQXlifyWR.add_dir(EahPquDoNKMJedTcFGpSkOQXlifyLt,sublabel='',img=EahPquDoNKMJedTcFGpSkOQXlifywU,infoLabels=EahPquDoNKMJedTcFGpSkOQXlifywz,isFolder=EahPquDoNKMJedTcFGpSkOQXlifyLs,params=EahPquDoNKMJedTcFGpSkOQXlifyWH)
  if EahPquDoNKMJedTcFGpSkOQXlifywI:
   EahPquDoNKMJedTcFGpSkOQXlifyWH['mode'] ='LIVE_LIST' 
   EahPquDoNKMJedTcFGpSkOQXlifyWH['page'] =EahPquDoNKMJedTcFGpSkOQXlifyBL(EahPquDoNKMJedTcFGpSkOQXlifywA+1)
   EahPquDoNKMJedTcFGpSkOQXlifyWY='[B]%s >>[/B]'%'다음 페이지'
   EahPquDoNKMJedTcFGpSkOQXlifywY=EahPquDoNKMJedTcFGpSkOQXlifyBL(EahPquDoNKMJedTcFGpSkOQXlifywA+1)
   EahPquDoNKMJedTcFGpSkOQXlifyWs=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   EahPquDoNKMJedTcFGpSkOQXlifyWR.add_dir(EahPquDoNKMJedTcFGpSkOQXlifyWY,sublabel=EahPquDoNKMJedTcFGpSkOQXlifywY,img=EahPquDoNKMJedTcFGpSkOQXlifyWs,infoLabels=EahPquDoNKMJedTcFGpSkOQXlifyLC,isFolder=EahPquDoNKMJedTcFGpSkOQXlifyLV,params=EahPquDoNKMJedTcFGpSkOQXlifyWH)
  xbmcplugin.endOfDirectory(EahPquDoNKMJedTcFGpSkOQXlifyWR._addon_handle,cacheToDisc=EahPquDoNKMJedTcFGpSkOQXlifyLs)
 def dp_Search_Group(EahPquDoNKMJedTcFGpSkOQXlifyWR,args):
  if 'search_key' in args:
   EahPquDoNKMJedTcFGpSkOQXlifyLx=args.get('search_key')
  else:
   EahPquDoNKMJedTcFGpSkOQXlifyLx=EahPquDoNKMJedTcFGpSkOQXlifyWR.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not EahPquDoNKMJedTcFGpSkOQXlifyLx:
    return
  for EahPquDoNKMJedTcFGpSkOQXlifywR in EahPquDoNKMJedTcFGpSkOQXlifyWm:
   EahPquDoNKMJedTcFGpSkOQXlifywH =EahPquDoNKMJedTcFGpSkOQXlifywR.get('mode')
   EahPquDoNKMJedTcFGpSkOQXlifyLU=EahPquDoNKMJedTcFGpSkOQXlifywR.get('stype')
   EahPquDoNKMJedTcFGpSkOQXlifyWY=EahPquDoNKMJedTcFGpSkOQXlifywR.get('title')
   (EahPquDoNKMJedTcFGpSkOQXlifyLz,EahPquDoNKMJedTcFGpSkOQXlifywI)=EahPquDoNKMJedTcFGpSkOQXlifyWR.KakaotvObj.GetSearchList(EahPquDoNKMJedTcFGpSkOQXlifyLx,1,EahPquDoNKMJedTcFGpSkOQXlifyLU)
   EahPquDoNKMJedTcFGpSkOQXlifyLY={'plot':'검색어 : '+EahPquDoNKMJedTcFGpSkOQXlifyLx+'\n\n'+EahPquDoNKMJedTcFGpSkOQXlifyWR.Search_FreeList(EahPquDoNKMJedTcFGpSkOQXlifyLz)}
   EahPquDoNKMJedTcFGpSkOQXlifyWH={'mode':EahPquDoNKMJedTcFGpSkOQXlifywH,'stype':EahPquDoNKMJedTcFGpSkOQXlifyLU,'search_key':EahPquDoNKMJedTcFGpSkOQXlifyLx,'page':'1',}
   EahPquDoNKMJedTcFGpSkOQXlifyWR.add_dir(EahPquDoNKMJedTcFGpSkOQXlifyWY,sublabel='',img='',infoLabels=EahPquDoNKMJedTcFGpSkOQXlifyLY,isFolder=EahPquDoNKMJedTcFGpSkOQXlifyLV,params=EahPquDoNKMJedTcFGpSkOQXlifyWH)
  if EahPquDoNKMJedTcFGpSkOQXlifyBm(EahPquDoNKMJedTcFGpSkOQXlifyWm)>0:xbmcplugin.endOfDirectory(EahPquDoNKMJedTcFGpSkOQXlifyWR._addon_handle,cacheToDisc=EahPquDoNKMJedTcFGpSkOQXlifyLV)
 def Search_FreeList(EahPquDoNKMJedTcFGpSkOQXlifyWR,search_list):
  EahPquDoNKMJedTcFGpSkOQXlifyLr=''
  EahPquDoNKMJedTcFGpSkOQXlifyLv=7
  try:
   if EahPquDoNKMJedTcFGpSkOQXlifyBm(search_list)==0:return '검색결과 없음'
   for i in EahPquDoNKMJedTcFGpSkOQXlifyBR(EahPquDoNKMJedTcFGpSkOQXlifyBm(search_list)):
    if i>=EahPquDoNKMJedTcFGpSkOQXlifyLv:
     EahPquDoNKMJedTcFGpSkOQXlifyLr=EahPquDoNKMJedTcFGpSkOQXlifyLr+'...'
     break
    EahPquDoNKMJedTcFGpSkOQXlifyLr=EahPquDoNKMJedTcFGpSkOQXlifyLr+search_list[i]['title']+'\n'
  except:
   return ''
  return EahPquDoNKMJedTcFGpSkOQXlifyLr
 def dp_Search_List(EahPquDoNKMJedTcFGpSkOQXlifyWR,args):
  EahPquDoNKMJedTcFGpSkOQXlifyLx=args.get('search_key')
  EahPquDoNKMJedTcFGpSkOQXlifywA =EahPquDoNKMJedTcFGpSkOQXlifyBw(args.get('page'))
  EahPquDoNKMJedTcFGpSkOQXlifyLU =args.get('stype')
  EahPquDoNKMJedTcFGpSkOQXlifyLz,EahPquDoNKMJedTcFGpSkOQXlifywI=EahPquDoNKMJedTcFGpSkOQXlifyWR.KakaotvObj.GetSearchList(EahPquDoNKMJedTcFGpSkOQXlifyLx,EahPquDoNKMJedTcFGpSkOQXlifywA,EahPquDoNKMJedTcFGpSkOQXlifyLU)
  for EahPquDoNKMJedTcFGpSkOQXlifywR in EahPquDoNKMJedTcFGpSkOQXlifyLz:
   if EahPquDoNKMJedTcFGpSkOQXlifyLU=='channels': 
    EahPquDoNKMJedTcFGpSkOQXlifywb=EahPquDoNKMJedTcFGpSkOQXlifywR.get('channelId')
    EahPquDoNKMJedTcFGpSkOQXlifyWY =EahPquDoNKMJedTcFGpSkOQXlifywR.get('title')
    EahPquDoNKMJedTcFGpSkOQXlifywt =EahPquDoNKMJedTcFGpSkOQXlifywR.get('synopsis')
    EahPquDoNKMJedTcFGpSkOQXlifywx =EahPquDoNKMJedTcFGpSkOQXlifywR.get('tagList')
    EahPquDoNKMJedTcFGpSkOQXlifywU=EahPquDoNKMJedTcFGpSkOQXlifywR.get('thumbnail')
    EahPquDoNKMJedTcFGpSkOQXlifywz={'mediatype':'tvshow','title':EahPquDoNKMJedTcFGpSkOQXlifyWY,'genre':EahPquDoNKMJedTcFGpSkOQXlifywx,'plot':EahPquDoNKMJedTcFGpSkOQXlifywt,}
    EahPquDoNKMJedTcFGpSkOQXlifyWH={'mode':'CH_PLAY_LIST','channelId':EahPquDoNKMJedTcFGpSkOQXlifywb,'page':'1',}
    EahPquDoNKMJedTcFGpSkOQXlifywW=EahPquDoNKMJedTcFGpSkOQXlifyLV
   else:
    EahPquDoNKMJedTcFGpSkOQXlifyWY =EahPquDoNKMJedTcFGpSkOQXlifywR.get('title')
    EahPquDoNKMJedTcFGpSkOQXlifywC=EahPquDoNKMJedTcFGpSkOQXlifywR.get('clipLinkId')
    EahPquDoNKMJedTcFGpSkOQXlifyLg =EahPquDoNKMJedTcFGpSkOQXlifywR.get('duration')
    EahPquDoNKMJedTcFGpSkOQXlifyLA =EahPquDoNKMJedTcFGpSkOQXlifywR.get('channelNm')
    EahPquDoNKMJedTcFGpSkOQXlifyLI =EahPquDoNKMJedTcFGpSkOQXlifywR.get('channelDs')
    EahPquDoNKMJedTcFGpSkOQXlifywU =EahPquDoNKMJedTcFGpSkOQXlifywR.get('thumbnail')
    EahPquDoNKMJedTcFGpSkOQXlifywU ={'thumb':EahPquDoNKMJedTcFGpSkOQXlifywU,'fanart':EahPquDoNKMJedTcFGpSkOQXlifywU}
    EahPquDoNKMJedTcFGpSkOQXlifywz={'mediatype':'episode','title':EahPquDoNKMJedTcFGpSkOQXlifyWY,'plot':'%s\n\n\n[ %s ]\n\n%s'%(EahPquDoNKMJedTcFGpSkOQXlifyWY,EahPquDoNKMJedTcFGpSkOQXlifyLA,EahPquDoNKMJedTcFGpSkOQXlifyLI),'duration':EahPquDoNKMJedTcFGpSkOQXlifyLg,}
    EahPquDoNKMJedTcFGpSkOQXlifyWH={'mode':'VOD','clipLinkId':EahPquDoNKMJedTcFGpSkOQXlifywC,}
    EahPquDoNKMJedTcFGpSkOQXlifywW=EahPquDoNKMJedTcFGpSkOQXlifyLs
   EahPquDoNKMJedTcFGpSkOQXlifyWR.add_dir(EahPquDoNKMJedTcFGpSkOQXlifyWY,sublabel='',img=EahPquDoNKMJedTcFGpSkOQXlifywU,infoLabels=EahPquDoNKMJedTcFGpSkOQXlifywz,isFolder=EahPquDoNKMJedTcFGpSkOQXlifywW,params=EahPquDoNKMJedTcFGpSkOQXlifyWH)
  if EahPquDoNKMJedTcFGpSkOQXlifywI:
   EahPquDoNKMJedTcFGpSkOQXlifyWH['mode'] ='LOCAL_SEARCH' 
   EahPquDoNKMJedTcFGpSkOQXlifyWH['search_key']=EahPquDoNKMJedTcFGpSkOQXlifyLx
   EahPquDoNKMJedTcFGpSkOQXlifyWH['page'] =EahPquDoNKMJedTcFGpSkOQXlifyBL(EahPquDoNKMJedTcFGpSkOQXlifywA+1)
   EahPquDoNKMJedTcFGpSkOQXlifyWH['stype'] =EahPquDoNKMJedTcFGpSkOQXlifyLU
   EahPquDoNKMJedTcFGpSkOQXlifyWY='[B]%s >>[/B]'%'다음 페이지'
   EahPquDoNKMJedTcFGpSkOQXlifywY=EahPquDoNKMJedTcFGpSkOQXlifyBL(EahPquDoNKMJedTcFGpSkOQXlifywA+1)
   EahPquDoNKMJedTcFGpSkOQXlifyWs=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   EahPquDoNKMJedTcFGpSkOQXlifyWR.add_dir(EahPquDoNKMJedTcFGpSkOQXlifyWY,sublabel=EahPquDoNKMJedTcFGpSkOQXlifywY,img=EahPquDoNKMJedTcFGpSkOQXlifyWs,infoLabels=EahPquDoNKMJedTcFGpSkOQXlifyLC,isFolder=EahPquDoNKMJedTcFGpSkOQXlifyLV,params=EahPquDoNKMJedTcFGpSkOQXlifyWH)
  if EahPquDoNKMJedTcFGpSkOQXlifyLU=='channels':xbmcplugin.setContent(EahPquDoNKMJedTcFGpSkOQXlifyWR._addon_handle,'tvshows')
  else:xbmcplugin.setContent(EahPquDoNKMJedTcFGpSkOQXlifyWR._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(EahPquDoNKMJedTcFGpSkOQXlifyWR._addon_handle,cacheToDisc=EahPquDoNKMJedTcFGpSkOQXlifyLs) 
 def kakaotv_main(EahPquDoNKMJedTcFGpSkOQXlifyWR):
  EahPquDoNKMJedTcFGpSkOQXlifywH=EahPquDoNKMJedTcFGpSkOQXlifyWR.main_params.get('mode',EahPquDoNKMJedTcFGpSkOQXlifyLC)
  if EahPquDoNKMJedTcFGpSkOQXlifywH is EahPquDoNKMJedTcFGpSkOQXlifyLC:
   EahPquDoNKMJedTcFGpSkOQXlifyWR.dp_Main_List(EahPquDoNKMJedTcFGpSkOQXlifyWR.main_params)
  elif EahPquDoNKMJedTcFGpSkOQXlifywH=='CHANNEL_GROUP':
   EahPquDoNKMJedTcFGpSkOQXlifyWR.dp_Channel_GroupList(EahPquDoNKMJedTcFGpSkOQXlifyWR.main_params)
  elif EahPquDoNKMJedTcFGpSkOQXlifywH=='CHANNEL_LIST':
   EahPquDoNKMJedTcFGpSkOQXlifyWR.dp_Channel_List(EahPquDoNKMJedTcFGpSkOQXlifyWR.main_params)
  elif EahPquDoNKMJedTcFGpSkOQXlifywH=='CH_PLAY_LIST':
   EahPquDoNKMJedTcFGpSkOQXlifyWR.dp_Channel_Playlist(EahPquDoNKMJedTcFGpSkOQXlifyWR.main_params)
  elif EahPquDoNKMJedTcFGpSkOQXlifywH=='EPISODE_LIST':
   EahPquDoNKMJedTcFGpSkOQXlifyWR.dp_Episode_List(EahPquDoNKMJedTcFGpSkOQXlifyWR.main_params)
  elif EahPquDoNKMJedTcFGpSkOQXlifywH in['VOD','LIVE']:
   EahPquDoNKMJedTcFGpSkOQXlifyWR.play_VIDEO(EahPquDoNKMJedTcFGpSkOQXlifyWR.main_params)
  elif EahPquDoNKMJedTcFGpSkOQXlifywH=='ORIGINAL_LIST':
   EahPquDoNKMJedTcFGpSkOQXlifyWR.dp_Original_List(EahPquDoNKMJedTcFGpSkOQXlifyWR.main_params)
  elif EahPquDoNKMJedTcFGpSkOQXlifywH=='LIVE_LIST':
   EahPquDoNKMJedTcFGpSkOQXlifyWR.Get_Live_List(EahPquDoNKMJedTcFGpSkOQXlifyWR.main_params)
  elif EahPquDoNKMJedTcFGpSkOQXlifywH=='SEARCH_GROUP':
   EahPquDoNKMJedTcFGpSkOQXlifyWR.dp_Search_Group(EahPquDoNKMJedTcFGpSkOQXlifyWR.main_params)
  elif EahPquDoNKMJedTcFGpSkOQXlifywH=='LOCAL_SEARCH':
   EahPquDoNKMJedTcFGpSkOQXlifyWR.dp_Search_List(EahPquDoNKMJedTcFGpSkOQXlifyWR.main_params)
  else:
   EahPquDoNKMJedTcFGpSkOQXlifyLC
# Created by pyminifier (https://github.com/liftoff/pyminifier)
