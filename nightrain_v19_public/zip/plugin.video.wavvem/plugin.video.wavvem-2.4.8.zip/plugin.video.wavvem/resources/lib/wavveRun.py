__author__="NightRain"
dCwFqlOWuKvtzcjbIDaieLSTHUVYpX=object
dCwFqlOWuKvtzcjbIDaieLSTHUVYpn=None
dCwFqlOWuKvtzcjbIDaieLSTHUVYpy=int
dCwFqlOWuKvtzcjbIDaieLSTHUVYpN=True
dCwFqlOWuKvtzcjbIDaieLSTHUVYpB=False
dCwFqlOWuKvtzcjbIDaieLSTHUVYpr=type
dCwFqlOWuKvtzcjbIDaieLSTHUVYpo=dict
dCwFqlOWuKvtzcjbIDaieLSTHUVYph=getattr
dCwFqlOWuKvtzcjbIDaieLSTHUVYpA=list
dCwFqlOWuKvtzcjbIDaieLSTHUVYpM=len
dCwFqlOWuKvtzcjbIDaieLSTHUVYpG=range
dCwFqlOWuKvtzcjbIDaieLSTHUVYpQ=str
dCwFqlOWuKvtzcjbIDaieLSTHUVYpP=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import json
dCwFqlOWuKvtzcjbIDaieLSTHUVYRs=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://apis.wavve.com/v1/multiband/GN51','icon':'home.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&uicode=VN500','page':'1','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/allprograms?WeekDay=all&broadcastid=VN1000&came=MainCategory&contenttype=program&genre=01&uicode=VN1000&uiparent=GN56&uirank=21&uitype=VN1000','page':'1','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/allprograms?WeekDay=all&adult=n&broadcastid=VN1001&came=MainCategory&contenttype=program&genre=02&subgenre=all&uicode=VN1001&uiparent=GN57&uirank=17&uitype=VN1001','page':'1','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'CN21','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'vod09','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'vod09','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'4','sType':'movie','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'4','sType':'movie','orderby':'modifydate','ordernm':'업데이트순','icon':''},{'title':'프로야구 - 경기중 시청가능','mode':'GAME_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'(웨이브) 검색','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'(웨이브) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
dCwFqlOWuKvtzcjbIDaieLSTHUVYRk=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
dCwFqlOWuKvtzcjbIDaieLSTHUVYRf=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
dCwFqlOWuKvtzcjbIDaieLSTHUVYRJ={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
dCwFqlOWuKvtzcjbIDaieLSTHUVYRx =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
dCwFqlOWuKvtzcjbIDaieLSTHUVYRp=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_searched.txt'))
from wavveCore import*
class dCwFqlOWuKvtzcjbIDaieLSTHUVYRg(dCwFqlOWuKvtzcjbIDaieLSTHUVYpX):
 def __init__(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm,dCwFqlOWuKvtzcjbIDaieLSTHUVYRE,dCwFqlOWuKvtzcjbIDaieLSTHUVYRX,dCwFqlOWuKvtzcjbIDaieLSTHUVYRn):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRm._addon_url =dCwFqlOWuKvtzcjbIDaieLSTHUVYRE
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRm._addon_handle=dCwFqlOWuKvtzcjbIDaieLSTHUVYRX
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.main_params =dCwFqlOWuKvtzcjbIDaieLSTHUVYRn
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj =pLQXibtYgWrVGHjchkOqPDmTvNxSCy() 
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.WV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_stream(mpd,m3u8)'))
 def addon_noti(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm,sting):
  try:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRN=xbmcgui.Dialog()
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRN.notification(__addonname__,sting)
  except:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYpn
 def addon_log(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm,string):
  try:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRB=string.encode('utf-8','ignore')
  except:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRB='addonException: addon_log'
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRr=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,dCwFqlOWuKvtzcjbIDaieLSTHUVYRB),level=dCwFqlOWuKvtzcjbIDaieLSTHUVYRr)
 def get_keyboard_input(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm,dCwFqlOWuKvtzcjbIDaieLSTHUVYgy):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRo=dCwFqlOWuKvtzcjbIDaieLSTHUVYpn
  kb=xbmc.Keyboard()
  kb.setHeading(dCwFqlOWuKvtzcjbIDaieLSTHUVYgy)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRo=kb.getText()
  return dCwFqlOWuKvtzcjbIDaieLSTHUVYRo
 def get_settings_account(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRh =__addon__.getSetting('id')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRA =__addon__.getSetting('pw')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRM=dCwFqlOWuKvtzcjbIDaieLSTHUVYpy(__addon__.getSetting('selected_profile'))
  return(dCwFqlOWuKvtzcjbIDaieLSTHUVYRh,dCwFqlOWuKvtzcjbIDaieLSTHUVYRA,dCwFqlOWuKvtzcjbIDaieLSTHUVYRM)
 def get_settings_totalsearch(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRG =dCwFqlOWuKvtzcjbIDaieLSTHUVYpN if __addon__.getSetting('local_search')=='true' else dCwFqlOWuKvtzcjbIDaieLSTHUVYpB
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRQ=dCwFqlOWuKvtzcjbIDaieLSTHUVYpN if __addon__.getSetting('local_history')=='true' else dCwFqlOWuKvtzcjbIDaieLSTHUVYpB
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRP =dCwFqlOWuKvtzcjbIDaieLSTHUVYpN if __addon__.getSetting('total_search')=='true' else dCwFqlOWuKvtzcjbIDaieLSTHUVYpB
  dCwFqlOWuKvtzcjbIDaieLSTHUVYgR=dCwFqlOWuKvtzcjbIDaieLSTHUVYpN if __addon__.getSetting('total_history')=='true' else dCwFqlOWuKvtzcjbIDaieLSTHUVYpB
  dCwFqlOWuKvtzcjbIDaieLSTHUVYgs=dCwFqlOWuKvtzcjbIDaieLSTHUVYpN if __addon__.getSetting('menu_bookmark')=='true' else dCwFqlOWuKvtzcjbIDaieLSTHUVYpB
  return(dCwFqlOWuKvtzcjbIDaieLSTHUVYRG,dCwFqlOWuKvtzcjbIDaieLSTHUVYRQ,dCwFqlOWuKvtzcjbIDaieLSTHUVYRP,dCwFqlOWuKvtzcjbIDaieLSTHUVYgR,dCwFqlOWuKvtzcjbIDaieLSTHUVYgs)
 def get_settings_makebookmark(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm):
  return dCwFqlOWuKvtzcjbIDaieLSTHUVYpN if __addon__.getSetting('make_bookmark')=='true' else dCwFqlOWuKvtzcjbIDaieLSTHUVYpB
 def get_settings_play(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYgk={'enable_hdr':dCwFqlOWuKvtzcjbIDaieLSTHUVYpN if __addon__.getSetting('enable_hdr')=='true' else dCwFqlOWuKvtzcjbIDaieLSTHUVYpB,'enable_uhd':dCwFqlOWuKvtzcjbIDaieLSTHUVYpN if __addon__.getSetting('enable_uhd')=='true' else dCwFqlOWuKvtzcjbIDaieLSTHUVYpB,'streamFilename':dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.WV_STREAM_FILENAME,}
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.get_selQuality()<1080:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgk['enable_hdr']=dCwFqlOWuKvtzcjbIDaieLSTHUVYpB
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgk['enable_uhd']=dCwFqlOWuKvtzcjbIDaieLSTHUVYpB
  return(dCwFqlOWuKvtzcjbIDaieLSTHUVYgk)
 def get_settings_proxyport(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYgf =dCwFqlOWuKvtzcjbIDaieLSTHUVYpN if __addon__.getSetting('proxyYn')=='true' else dCwFqlOWuKvtzcjbIDaieLSTHUVYpB
  dCwFqlOWuKvtzcjbIDaieLSTHUVYgJ=dCwFqlOWuKvtzcjbIDaieLSTHUVYpy(__addon__.getSetting('proxyPort'))
  return dCwFqlOWuKvtzcjbIDaieLSTHUVYgf,dCwFqlOWuKvtzcjbIDaieLSTHUVYgJ
 def get_selQuality(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm):
  try:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgx=[1080,720,480,360]
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgp=dCwFqlOWuKvtzcjbIDaieLSTHUVYpy(__addon__.getSetting('selected_quality'))
   return dCwFqlOWuKvtzcjbIDaieLSTHUVYgx[dCwFqlOWuKvtzcjbIDaieLSTHUVYgp]
  except:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYpn
  return 1080 
 def get_settings_exclusion21(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYgm =__addon__.getSetting('exclusion21')
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYgm=='false':
   return dCwFqlOWuKvtzcjbIDaieLSTHUVYpB
  else:
   return dCwFqlOWuKvtzcjbIDaieLSTHUVYpN
 def get_settings_direct_replay(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYgE=dCwFqlOWuKvtzcjbIDaieLSTHUVYpy(__addon__.getSetting('direct_replay'))
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYgE==0:
   return dCwFqlOWuKvtzcjbIDaieLSTHUVYpB
  else:
   return dCwFqlOWuKvtzcjbIDaieLSTHUVYpN
 def set_winEpisodeOrderby(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm,dCwFqlOWuKvtzcjbIDaieLSTHUVYgX):
  __addon__.setSetting('wavve_orderby',dCwFqlOWuKvtzcjbIDaieLSTHUVYgX)
 def get_winEpisodeOrderby(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYgX=__addon__.getSetting('wavve_orderby')
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYgX in['',dCwFqlOWuKvtzcjbIDaieLSTHUVYpn]:dCwFqlOWuKvtzcjbIDaieLSTHUVYgX='desc'
  return dCwFqlOWuKvtzcjbIDaieLSTHUVYgX
 def add_dir(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm,label,sublabel='',img='',infoLabels=dCwFqlOWuKvtzcjbIDaieLSTHUVYpn,isFolder=dCwFqlOWuKvtzcjbIDaieLSTHUVYpN,params='',isLink=dCwFqlOWuKvtzcjbIDaieLSTHUVYpB,ContextMenu=dCwFqlOWuKvtzcjbIDaieLSTHUVYpn):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYgn='%s?%s'%(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm._addon_url,urllib.parse.urlencode(params))
  if sublabel:dCwFqlOWuKvtzcjbIDaieLSTHUVYgy='%s < %s >'%(label,sublabel)
  else: dCwFqlOWuKvtzcjbIDaieLSTHUVYgy=label
  if not img:img='DefaultFolder.png'
  dCwFqlOWuKvtzcjbIDaieLSTHUVYgN=xbmcgui.ListItem(dCwFqlOWuKvtzcjbIDaieLSTHUVYgy)
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYpr(img)==dCwFqlOWuKvtzcjbIDaieLSTHUVYpo:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgN.setArt(img)
  else:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgN.setArt({'thumb':img,'poster':img})
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.KodiVersion>=20:
   if infoLabels:dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.Set_InfoTag(dCwFqlOWuKvtzcjbIDaieLSTHUVYgN.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:dCwFqlOWuKvtzcjbIDaieLSTHUVYgN.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgN.setProperty('IsPlayable','true')
  if ContextMenu:dCwFqlOWuKvtzcjbIDaieLSTHUVYgN.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm._addon_handle,dCwFqlOWuKvtzcjbIDaieLSTHUVYgn,dCwFqlOWuKvtzcjbIDaieLSTHUVYgN,isFolder)
 def Set_InfoTag(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm,video_InfoTag:xbmc.InfoTagVideo,dCwFqlOWuKvtzcjbIDaieLSTHUVYgQ):
  for dCwFqlOWuKvtzcjbIDaieLSTHUVYgB,value in dCwFqlOWuKvtzcjbIDaieLSTHUVYgQ.items():
   if dCwFqlOWuKvtzcjbIDaieLSTHUVYRJ[dCwFqlOWuKvtzcjbIDaieLSTHUVYgB]['type']=='string':
    dCwFqlOWuKvtzcjbIDaieLSTHUVYph(video_InfoTag,dCwFqlOWuKvtzcjbIDaieLSTHUVYRJ[dCwFqlOWuKvtzcjbIDaieLSTHUVYgB]['func'])(value)
   elif dCwFqlOWuKvtzcjbIDaieLSTHUVYRJ[dCwFqlOWuKvtzcjbIDaieLSTHUVYgB]['type']=='int':
    if dCwFqlOWuKvtzcjbIDaieLSTHUVYpr(value)==dCwFqlOWuKvtzcjbIDaieLSTHUVYpy:
     dCwFqlOWuKvtzcjbIDaieLSTHUVYgr=dCwFqlOWuKvtzcjbIDaieLSTHUVYpy(value)
    else:
     dCwFqlOWuKvtzcjbIDaieLSTHUVYgr=0
    dCwFqlOWuKvtzcjbIDaieLSTHUVYph(video_InfoTag,dCwFqlOWuKvtzcjbIDaieLSTHUVYRJ[dCwFqlOWuKvtzcjbIDaieLSTHUVYgB]['func'])(dCwFqlOWuKvtzcjbIDaieLSTHUVYgr)
   elif dCwFqlOWuKvtzcjbIDaieLSTHUVYRJ[dCwFqlOWuKvtzcjbIDaieLSTHUVYgB]['type']=='actor':
    if value!=[]:
     dCwFqlOWuKvtzcjbIDaieLSTHUVYph(video_InfoTag,dCwFqlOWuKvtzcjbIDaieLSTHUVYRJ[dCwFqlOWuKvtzcjbIDaieLSTHUVYgB]['func'])([xbmc.Actor(name)for name in value])
   elif dCwFqlOWuKvtzcjbIDaieLSTHUVYRJ[dCwFqlOWuKvtzcjbIDaieLSTHUVYgB]['type']=='list':
    if dCwFqlOWuKvtzcjbIDaieLSTHUVYpr(value)==dCwFqlOWuKvtzcjbIDaieLSTHUVYpA:
     dCwFqlOWuKvtzcjbIDaieLSTHUVYph(video_InfoTag,dCwFqlOWuKvtzcjbIDaieLSTHUVYRJ[dCwFqlOWuKvtzcjbIDaieLSTHUVYgB]['func'])(value)
    else:
     dCwFqlOWuKvtzcjbIDaieLSTHUVYph(video_InfoTag,dCwFqlOWuKvtzcjbIDaieLSTHUVYRJ[dCwFqlOWuKvtzcjbIDaieLSTHUVYgB]['func'])([value])
 def dp_Main_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm):
  (dCwFqlOWuKvtzcjbIDaieLSTHUVYRG,dCwFqlOWuKvtzcjbIDaieLSTHUVYRQ,dCwFqlOWuKvtzcjbIDaieLSTHUVYRP,dCwFqlOWuKvtzcjbIDaieLSTHUVYgR,dCwFqlOWuKvtzcjbIDaieLSTHUVYgs)=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.get_settings_totalsearch()
  for dCwFqlOWuKvtzcjbIDaieLSTHUVYgo in dCwFqlOWuKvtzcjbIDaieLSTHUVYRs:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgy=dCwFqlOWuKvtzcjbIDaieLSTHUVYgo.get('title')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgh=''
   if dCwFqlOWuKvtzcjbIDaieLSTHUVYgo.get('mode')=='SEARCH_GROUP' and dCwFqlOWuKvtzcjbIDaieLSTHUVYRG ==dCwFqlOWuKvtzcjbIDaieLSTHUVYpB:continue
   elif dCwFqlOWuKvtzcjbIDaieLSTHUVYgo.get('mode')=='SEARCH_HISTORY' and dCwFqlOWuKvtzcjbIDaieLSTHUVYRQ==dCwFqlOWuKvtzcjbIDaieLSTHUVYpB:continue
   elif dCwFqlOWuKvtzcjbIDaieLSTHUVYgo.get('mode')=='TOTAL_SEARCH' and dCwFqlOWuKvtzcjbIDaieLSTHUVYRP ==dCwFqlOWuKvtzcjbIDaieLSTHUVYpB:continue
   elif dCwFqlOWuKvtzcjbIDaieLSTHUVYgo.get('mode')=='TOTAL_HISTORY' and dCwFqlOWuKvtzcjbIDaieLSTHUVYgR==dCwFqlOWuKvtzcjbIDaieLSTHUVYpB:continue
   elif dCwFqlOWuKvtzcjbIDaieLSTHUVYgo.get('mode')=='MENU_BOOKMARK' and dCwFqlOWuKvtzcjbIDaieLSTHUVYgs==dCwFqlOWuKvtzcjbIDaieLSTHUVYpB:continue
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA={'mode':dCwFqlOWuKvtzcjbIDaieLSTHUVYgo.get('mode'),'sCode':dCwFqlOWuKvtzcjbIDaieLSTHUVYgo.get('sCode'),'sIndex':dCwFqlOWuKvtzcjbIDaieLSTHUVYgo.get('sIndex'),'sType':dCwFqlOWuKvtzcjbIDaieLSTHUVYgo.get('sType'),'suburl':dCwFqlOWuKvtzcjbIDaieLSTHUVYgo.get('suburl'),'subapi':dCwFqlOWuKvtzcjbIDaieLSTHUVYgo.get('subapi'),'page':dCwFqlOWuKvtzcjbIDaieLSTHUVYgo.get('page'),'orderby':dCwFqlOWuKvtzcjbIDaieLSTHUVYgo.get('orderby'),'ordernm':dCwFqlOWuKvtzcjbIDaieLSTHUVYgo.get('ordernm')}
   if dCwFqlOWuKvtzcjbIDaieLSTHUVYgo.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    dCwFqlOWuKvtzcjbIDaieLSTHUVYgM=dCwFqlOWuKvtzcjbIDaieLSTHUVYpB
    dCwFqlOWuKvtzcjbIDaieLSTHUVYgG =dCwFqlOWuKvtzcjbIDaieLSTHUVYpN
   else:
    dCwFqlOWuKvtzcjbIDaieLSTHUVYgM=dCwFqlOWuKvtzcjbIDaieLSTHUVYpN
    dCwFqlOWuKvtzcjbIDaieLSTHUVYgG =dCwFqlOWuKvtzcjbIDaieLSTHUVYpB
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgQ={'title':dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,'plot':dCwFqlOWuKvtzcjbIDaieLSTHUVYgy}
   if dCwFqlOWuKvtzcjbIDaieLSTHUVYgo.get('mode')=='XXX':dCwFqlOWuKvtzcjbIDaieLSTHUVYgQ=dCwFqlOWuKvtzcjbIDaieLSTHUVYpn
   if 'icon' in dCwFqlOWuKvtzcjbIDaieLSTHUVYgo:dCwFqlOWuKvtzcjbIDaieLSTHUVYgh=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',dCwFqlOWuKvtzcjbIDaieLSTHUVYgo.get('icon')) 
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.add_dir(dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,sublabel='',img=dCwFqlOWuKvtzcjbIDaieLSTHUVYgh,infoLabels=dCwFqlOWuKvtzcjbIDaieLSTHUVYgQ,isFolder=dCwFqlOWuKvtzcjbIDaieLSTHUVYgM,params=dCwFqlOWuKvtzcjbIDaieLSTHUVYgA,isLink=dCwFqlOWuKvtzcjbIDaieLSTHUVYgG)
  xbmcplugin.endOfDirectory(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm._addon_handle,cacheToDisc=dCwFqlOWuKvtzcjbIDaieLSTHUVYpN)
 def dp_Search_Group(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm,args):
  if 'search_key' in args:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsg=args.get('search_key')
  else:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsg=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not dCwFqlOWuKvtzcjbIDaieLSTHUVYsg:
    return
  for dCwFqlOWuKvtzcjbIDaieLSTHUVYsk in dCwFqlOWuKvtzcjbIDaieLSTHUVYRk:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsf =dCwFqlOWuKvtzcjbIDaieLSTHUVYsk.get('mode')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsJ=dCwFqlOWuKvtzcjbIDaieLSTHUVYsk.get('sType')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgy=dCwFqlOWuKvtzcjbIDaieLSTHUVYsk.get('title')
   (dCwFqlOWuKvtzcjbIDaieLSTHUVYsx,dCwFqlOWuKvtzcjbIDaieLSTHUVYsp)=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.Get_Search_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYsg,dCwFqlOWuKvtzcjbIDaieLSTHUVYsJ,1,exclusion21=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.get_settings_exclusion21())
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgQ={'plot':'검색어 : '+dCwFqlOWuKvtzcjbIDaieLSTHUVYsg+'\n\n'+dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.Search_FreeList(dCwFqlOWuKvtzcjbIDaieLSTHUVYsx)}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA={'mode':dCwFqlOWuKvtzcjbIDaieLSTHUVYsf,'sType':dCwFqlOWuKvtzcjbIDaieLSTHUVYsJ,'search_key':dCwFqlOWuKvtzcjbIDaieLSTHUVYsg,'page':'1',}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.add_dir(dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,sublabel='',img='',infoLabels=dCwFqlOWuKvtzcjbIDaieLSTHUVYgQ,isFolder=dCwFqlOWuKvtzcjbIDaieLSTHUVYpN,params=dCwFqlOWuKvtzcjbIDaieLSTHUVYgA)
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYpM(dCwFqlOWuKvtzcjbIDaieLSTHUVYRk)>0:xbmcplugin.endOfDirectory(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm._addon_handle,cacheToDisc=dCwFqlOWuKvtzcjbIDaieLSTHUVYpN)
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.Save_Searched_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYsg)
 def Search_FreeList(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm,search_list):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYsm=''
  dCwFqlOWuKvtzcjbIDaieLSTHUVYsE=7
  try:
   if dCwFqlOWuKvtzcjbIDaieLSTHUVYpM(search_list)==0:return '검색결과 없음'
   for i in dCwFqlOWuKvtzcjbIDaieLSTHUVYpG(dCwFqlOWuKvtzcjbIDaieLSTHUVYpM(search_list)):
    if i>=dCwFqlOWuKvtzcjbIDaieLSTHUVYsE:
     dCwFqlOWuKvtzcjbIDaieLSTHUVYsm=dCwFqlOWuKvtzcjbIDaieLSTHUVYsm+'...'
     break
    dCwFqlOWuKvtzcjbIDaieLSTHUVYsm=dCwFqlOWuKvtzcjbIDaieLSTHUVYsm+search_list[i]['title']+'\n'
  except:
   return ''
  return dCwFqlOWuKvtzcjbIDaieLSTHUVYsm
 def dp_Watch_Group(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm,args):
  for dCwFqlOWuKvtzcjbIDaieLSTHUVYsX in dCwFqlOWuKvtzcjbIDaieLSTHUVYRf:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgy=dCwFqlOWuKvtzcjbIDaieLSTHUVYsX.get('title')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA={'mode':dCwFqlOWuKvtzcjbIDaieLSTHUVYsX.get('mode'),'sType':dCwFqlOWuKvtzcjbIDaieLSTHUVYsX.get('sType')}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.add_dir(dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,sublabel='',img='',infoLabels=dCwFqlOWuKvtzcjbIDaieLSTHUVYpn,isFolder=dCwFqlOWuKvtzcjbIDaieLSTHUVYpN,params=dCwFqlOWuKvtzcjbIDaieLSTHUVYgA)
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYpM(dCwFqlOWuKvtzcjbIDaieLSTHUVYRf)>0:xbmcplugin.endOfDirectory(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm._addon_handle,cacheToDisc=dCwFqlOWuKvtzcjbIDaieLSTHUVYpN)
 def dp_Search_History(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm,args):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYsn=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.Load_List_File('search')
  for dCwFqlOWuKvtzcjbIDaieLSTHUVYsy in dCwFqlOWuKvtzcjbIDaieLSTHUVYsn:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsN=dCwFqlOWuKvtzcjbIDaieLSTHUVYpo(urllib.parse.parse_qsl(dCwFqlOWuKvtzcjbIDaieLSTHUVYsy))
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsB=dCwFqlOWuKvtzcjbIDaieLSTHUVYsN.get('skey').strip()
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA={'mode':'SEARCH_GROUP','search_key':dCwFqlOWuKvtzcjbIDaieLSTHUVYsB,}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsr={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':dCwFqlOWuKvtzcjbIDaieLSTHUVYsB,'vType':'-',}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYso=urllib.parse.urlencode(dCwFqlOWuKvtzcjbIDaieLSTHUVYsr)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsh=[('선택된 검색어 ( %s ) 삭제'%(dCwFqlOWuKvtzcjbIDaieLSTHUVYsB),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(dCwFqlOWuKvtzcjbIDaieLSTHUVYso))]
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.add_dir(dCwFqlOWuKvtzcjbIDaieLSTHUVYsB,sublabel='',img=dCwFqlOWuKvtzcjbIDaieLSTHUVYpn,infoLabels=dCwFqlOWuKvtzcjbIDaieLSTHUVYpn,isFolder=dCwFqlOWuKvtzcjbIDaieLSTHUVYpN,params=dCwFqlOWuKvtzcjbIDaieLSTHUVYgA,ContextMenu=dCwFqlOWuKvtzcjbIDaieLSTHUVYsh)
  dCwFqlOWuKvtzcjbIDaieLSTHUVYsA={'plot':'검색목록 전체를 삭제합니다.'}
  dCwFqlOWuKvtzcjbIDaieLSTHUVYgy='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  dCwFqlOWuKvtzcjbIDaieLSTHUVYgA={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  dCwFqlOWuKvtzcjbIDaieLSTHUVYgh=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.add_dir(dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,sublabel='',img=dCwFqlOWuKvtzcjbIDaieLSTHUVYgh,infoLabels=dCwFqlOWuKvtzcjbIDaieLSTHUVYsA,isFolder=dCwFqlOWuKvtzcjbIDaieLSTHUVYpB,params=dCwFqlOWuKvtzcjbIDaieLSTHUVYgA,isLink=dCwFqlOWuKvtzcjbIDaieLSTHUVYpN)
  xbmcplugin.endOfDirectory(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm._addon_handle,cacheToDisc=dCwFqlOWuKvtzcjbIDaieLSTHUVYpB)
 def dp_Search_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm,args):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYsJ =args.get('sType')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYsM =dCwFqlOWuKvtzcjbIDaieLSTHUVYpy(args.get('page'))
  if 'search_key' in args:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsg=args.get('search_key')
  else:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsg=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not dCwFqlOWuKvtzcjbIDaieLSTHUVYsg:
    xbmcplugin.endOfDirectory(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm._addon_handle)
    return
  dCwFqlOWuKvtzcjbIDaieLSTHUVYsG,dCwFqlOWuKvtzcjbIDaieLSTHUVYsp=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.Get_Search_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYsg,dCwFqlOWuKvtzcjbIDaieLSTHUVYsJ,dCwFqlOWuKvtzcjbIDaieLSTHUVYsM,exclusion21=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.get_settings_exclusion21())
  for dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ in dCwFqlOWuKvtzcjbIDaieLSTHUVYsG:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsP =dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('videoid')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkR =dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('vidtype')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgy =dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('title')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkg=dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('thumbnail')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYks =dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('age')
   if dCwFqlOWuKvtzcjbIDaieLSTHUVYks=='18' or dCwFqlOWuKvtzcjbIDaieLSTHUVYks=='19' or dCwFqlOWuKvtzcjbIDaieLSTHUVYks=='21':dCwFqlOWuKvtzcjbIDaieLSTHUVYgy+=' (%s)'%(dCwFqlOWuKvtzcjbIDaieLSTHUVYks)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsA={'mediatype':'tvshow' if dCwFqlOWuKvtzcjbIDaieLSTHUVYsJ=='vod' else 'movie','mpaa':dCwFqlOWuKvtzcjbIDaieLSTHUVYks,'title':dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,'plot':dCwFqlOWuKvtzcjbIDaieLSTHUVYgy}
   if dCwFqlOWuKvtzcjbIDaieLSTHUVYsJ=='vod':
    dCwFqlOWuKvtzcjbIDaieLSTHUVYgA={'mode':'EPISODE_LIST','seasonid':dCwFqlOWuKvtzcjbIDaieLSTHUVYsP,'page':'1',}
    dCwFqlOWuKvtzcjbIDaieLSTHUVYgM=dCwFqlOWuKvtzcjbIDaieLSTHUVYpN
   else:
    dCwFqlOWuKvtzcjbIDaieLSTHUVYgA={'mode':'MOVIE','contentid':dCwFqlOWuKvtzcjbIDaieLSTHUVYsP,'title':dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,'thumbnail':dCwFqlOWuKvtzcjbIDaieLSTHUVYkg,'age':dCwFqlOWuKvtzcjbIDaieLSTHUVYks,}
    dCwFqlOWuKvtzcjbIDaieLSTHUVYgM=dCwFqlOWuKvtzcjbIDaieLSTHUVYpB
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsh=[]
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkf={'mode':'VIEW_DETAIL','values':{'videoid':dCwFqlOWuKvtzcjbIDaieLSTHUVYsP,'vidtype':'tvshow' if dCwFqlOWuKvtzcjbIDaieLSTHUVYsJ=='vod' else 'movie','contenttype':dCwFqlOWuKvtzcjbIDaieLSTHUVYkR,}}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkJ=json.dumps(dCwFqlOWuKvtzcjbIDaieLSTHUVYkf,separators=(',',':'))
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkJ=base64.standard_b64encode(dCwFqlOWuKvtzcjbIDaieLSTHUVYkJ.encode()).decode('utf-8')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkJ=dCwFqlOWuKvtzcjbIDaieLSTHUVYkJ.replace('+','%2B')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkx='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(dCwFqlOWuKvtzcjbIDaieLSTHUVYkJ)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsh.append(('상세정보 조회',dCwFqlOWuKvtzcjbIDaieLSTHUVYkx))
   if dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.get_settings_makebookmark():
    dCwFqlOWuKvtzcjbIDaieLSTHUVYkf={'videoid':dCwFqlOWuKvtzcjbIDaieLSTHUVYsP,'vidtype':'tvshow' if dCwFqlOWuKvtzcjbIDaieLSTHUVYsJ=='vod' else 'movie','vtitle':dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,'vsubtitle':'','contenttype':dCwFqlOWuKvtzcjbIDaieLSTHUVYkR,}
    dCwFqlOWuKvtzcjbIDaieLSTHUVYkp=json.dumps(dCwFqlOWuKvtzcjbIDaieLSTHUVYkf)
    dCwFqlOWuKvtzcjbIDaieLSTHUVYkp=urllib.parse.quote(dCwFqlOWuKvtzcjbIDaieLSTHUVYkp)
    dCwFqlOWuKvtzcjbIDaieLSTHUVYkx='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(dCwFqlOWuKvtzcjbIDaieLSTHUVYkp)
    dCwFqlOWuKvtzcjbIDaieLSTHUVYsh.append(('(통합) 찜 영상에 추가',dCwFqlOWuKvtzcjbIDaieLSTHUVYkx))
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.add_dir(dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,sublabel='',img=dCwFqlOWuKvtzcjbIDaieLSTHUVYkg,infoLabels=dCwFqlOWuKvtzcjbIDaieLSTHUVYsA,isFolder=dCwFqlOWuKvtzcjbIDaieLSTHUVYgM,params=dCwFqlOWuKvtzcjbIDaieLSTHUVYgA,ContextMenu=dCwFqlOWuKvtzcjbIDaieLSTHUVYsh)
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYsp:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA['mode'] ='SEARCH_LIST' 
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA['sType']=dCwFqlOWuKvtzcjbIDaieLSTHUVYsJ 
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA['page'] =dCwFqlOWuKvtzcjbIDaieLSTHUVYpQ(dCwFqlOWuKvtzcjbIDaieLSTHUVYsM+1)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA['search_key']=dCwFqlOWuKvtzcjbIDaieLSTHUVYsg
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgy='[B]%s >>[/B]'%'다음 페이지'
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkm=dCwFqlOWuKvtzcjbIDaieLSTHUVYpQ(dCwFqlOWuKvtzcjbIDaieLSTHUVYsM+1)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgh=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.add_dir(dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,sublabel=dCwFqlOWuKvtzcjbIDaieLSTHUVYkm,img=dCwFqlOWuKvtzcjbIDaieLSTHUVYgh,infoLabels=dCwFqlOWuKvtzcjbIDaieLSTHUVYpn,isFolder=dCwFqlOWuKvtzcjbIDaieLSTHUVYpN,params=dCwFqlOWuKvtzcjbIDaieLSTHUVYgA)
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYsJ=='movie':xbmcplugin.setContent(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm._addon_handle,'movies')
  else:xbmcplugin.setContent(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm._addon_handle,cacheToDisc=dCwFqlOWuKvtzcjbIDaieLSTHUVYpB)
 def dp_Watch_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm,args):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYsJ =args.get('sType')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYgE=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.get_settings_direct_replay()
  dCwFqlOWuKvtzcjbIDaieLSTHUVYsG=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.Load_List_File(dCwFqlOWuKvtzcjbIDaieLSTHUVYsJ)
  for dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ in dCwFqlOWuKvtzcjbIDaieLSTHUVYsG:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsN=dCwFqlOWuKvtzcjbIDaieLSTHUVYpo(urllib.parse.parse_qsl(dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ))
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkE =dCwFqlOWuKvtzcjbIDaieLSTHUVYsN.get('code').strip()
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgy =dCwFqlOWuKvtzcjbIDaieLSTHUVYsN.get('title').strip()
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkm =dCwFqlOWuKvtzcjbIDaieLSTHUVYsN.get('subtitle').strip()
   if dCwFqlOWuKvtzcjbIDaieLSTHUVYkm=='None':dCwFqlOWuKvtzcjbIDaieLSTHUVYkm=''
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkg=dCwFqlOWuKvtzcjbIDaieLSTHUVYsN.get('img').strip()
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsP =dCwFqlOWuKvtzcjbIDaieLSTHUVYsN.get('videoid').strip()
   try:
    dCwFqlOWuKvtzcjbIDaieLSTHUVYkg=dCwFqlOWuKvtzcjbIDaieLSTHUVYkg.replace('\'','\"')
    dCwFqlOWuKvtzcjbIDaieLSTHUVYkg=json.loads(dCwFqlOWuKvtzcjbIDaieLSTHUVYkg)
   except:
    dCwFqlOWuKvtzcjbIDaieLSTHUVYpn
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsA={'plot':'%s\n%s'%(dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,dCwFqlOWuKvtzcjbIDaieLSTHUVYkm)}
   if dCwFqlOWuKvtzcjbIDaieLSTHUVYsJ=='vod':
    if dCwFqlOWuKvtzcjbIDaieLSTHUVYgE==dCwFqlOWuKvtzcjbIDaieLSTHUVYpB or dCwFqlOWuKvtzcjbIDaieLSTHUVYsP==dCwFqlOWuKvtzcjbIDaieLSTHUVYpn:
     dCwFqlOWuKvtzcjbIDaieLSTHUVYsA['mediatype']='tvshow'
     dCwFqlOWuKvtzcjbIDaieLSTHUVYgA={'mode':'SEASON_LIST','videoid':dCwFqlOWuKvtzcjbIDaieLSTHUVYsP,'vidtype':'contentid',}
     dCwFqlOWuKvtzcjbIDaieLSTHUVYgM=dCwFqlOWuKvtzcjbIDaieLSTHUVYpN
    else:
     dCwFqlOWuKvtzcjbIDaieLSTHUVYsA['mediatype']='episode'
     dCwFqlOWuKvtzcjbIDaieLSTHUVYgA={'mode':'VOD','programid':dCwFqlOWuKvtzcjbIDaieLSTHUVYkE,'contentid':dCwFqlOWuKvtzcjbIDaieLSTHUVYsP,'title':dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,'subtitle':dCwFqlOWuKvtzcjbIDaieLSTHUVYkm,'thumbnail':dCwFqlOWuKvtzcjbIDaieLSTHUVYkg}
     dCwFqlOWuKvtzcjbIDaieLSTHUVYgM=dCwFqlOWuKvtzcjbIDaieLSTHUVYpB
   else:
    dCwFqlOWuKvtzcjbIDaieLSTHUVYsA['mediatype']='movie'
    dCwFqlOWuKvtzcjbIDaieLSTHUVYgA={'mode':'MOVIE','contentid':dCwFqlOWuKvtzcjbIDaieLSTHUVYkE,'title':dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,'subtitle':dCwFqlOWuKvtzcjbIDaieLSTHUVYkm,'thumbnail':dCwFqlOWuKvtzcjbIDaieLSTHUVYkg}
    dCwFqlOWuKvtzcjbIDaieLSTHUVYgM=dCwFqlOWuKvtzcjbIDaieLSTHUVYpB
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsr={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':dCwFqlOWuKvtzcjbIDaieLSTHUVYkE,'vType':dCwFqlOWuKvtzcjbIDaieLSTHUVYsJ,}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYso=urllib.parse.urlencode(dCwFqlOWuKvtzcjbIDaieLSTHUVYsr)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsh=[('선택된 시청이력 ( %s ) 삭제'%(dCwFqlOWuKvtzcjbIDaieLSTHUVYgy),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(dCwFqlOWuKvtzcjbIDaieLSTHUVYso))]
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.add_dir(dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,sublabel=dCwFqlOWuKvtzcjbIDaieLSTHUVYkm,img=dCwFqlOWuKvtzcjbIDaieLSTHUVYkg,infoLabels=dCwFqlOWuKvtzcjbIDaieLSTHUVYsA,isFolder=dCwFqlOWuKvtzcjbIDaieLSTHUVYgM,params=dCwFqlOWuKvtzcjbIDaieLSTHUVYgA,ContextMenu=dCwFqlOWuKvtzcjbIDaieLSTHUVYsh)
  dCwFqlOWuKvtzcjbIDaieLSTHUVYsA={'plot':'시청목록을 삭제합니다.'}
  dCwFqlOWuKvtzcjbIDaieLSTHUVYgy='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  dCwFqlOWuKvtzcjbIDaieLSTHUVYgA={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':dCwFqlOWuKvtzcjbIDaieLSTHUVYsJ,}
  dCwFqlOWuKvtzcjbIDaieLSTHUVYgh=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.add_dir(dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,sublabel='',img=dCwFqlOWuKvtzcjbIDaieLSTHUVYgh,infoLabels=dCwFqlOWuKvtzcjbIDaieLSTHUVYsA,isFolder=dCwFqlOWuKvtzcjbIDaieLSTHUVYpB,params=dCwFqlOWuKvtzcjbIDaieLSTHUVYgA,isLink=dCwFqlOWuKvtzcjbIDaieLSTHUVYpN)
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYsJ=='movie':xbmcplugin.setContent(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm._addon_handle,'movies')
  else:xbmcplugin.setContent(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm._addon_handle,cacheToDisc=dCwFqlOWuKvtzcjbIDaieLSTHUVYpB)
 def Load_List_File(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm,stype): 
  try:
   if stype=='search':
    dCwFqlOWuKvtzcjbIDaieLSTHUVYkX=dCwFqlOWuKvtzcjbIDaieLSTHUVYRp
   elif stype in['vod','movie']:
    dCwFqlOWuKvtzcjbIDaieLSTHUVYkX=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   else:
    return[]
   fp=dCwFqlOWuKvtzcjbIDaieLSTHUVYpP(dCwFqlOWuKvtzcjbIDaieLSTHUVYkX,'r',-1,'utf-8')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkn=fp.readlines()
   fp.close()
  except:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkn=[]
  return dCwFqlOWuKvtzcjbIDaieLSTHUVYkn
 def Save_Watched_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm,dCwFqlOWuKvtzcjbIDaieLSTHUVYxA,dCwFqlOWuKvtzcjbIDaieLSTHUVYRn):
  try:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYky=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%dCwFqlOWuKvtzcjbIDaieLSTHUVYxA))
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkN=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.Load_List_File(dCwFqlOWuKvtzcjbIDaieLSTHUVYxA) 
   fp=dCwFqlOWuKvtzcjbIDaieLSTHUVYpP(dCwFqlOWuKvtzcjbIDaieLSTHUVYky,'w',-1,'utf-8')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkB=urllib.parse.urlencode(dCwFqlOWuKvtzcjbIDaieLSTHUVYRn)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkB=dCwFqlOWuKvtzcjbIDaieLSTHUVYkB+'\n'
   fp.write(dCwFqlOWuKvtzcjbIDaieLSTHUVYkB)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkr=0
   for dCwFqlOWuKvtzcjbIDaieLSTHUVYko in dCwFqlOWuKvtzcjbIDaieLSTHUVYkN:
    dCwFqlOWuKvtzcjbIDaieLSTHUVYkh=dCwFqlOWuKvtzcjbIDaieLSTHUVYpo(urllib.parse.parse_qsl(dCwFqlOWuKvtzcjbIDaieLSTHUVYko))
    dCwFqlOWuKvtzcjbIDaieLSTHUVYkA=dCwFqlOWuKvtzcjbIDaieLSTHUVYRn.get('code').strip()
    dCwFqlOWuKvtzcjbIDaieLSTHUVYkM=dCwFqlOWuKvtzcjbIDaieLSTHUVYkh.get('code').strip()
    if dCwFqlOWuKvtzcjbIDaieLSTHUVYxA=='vod' and dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.get_settings_direct_replay()==dCwFqlOWuKvtzcjbIDaieLSTHUVYpN:
     dCwFqlOWuKvtzcjbIDaieLSTHUVYkA=dCwFqlOWuKvtzcjbIDaieLSTHUVYRn.get('videoid').strip()
     dCwFqlOWuKvtzcjbIDaieLSTHUVYkM=dCwFqlOWuKvtzcjbIDaieLSTHUVYkh.get('videoid').strip()if dCwFqlOWuKvtzcjbIDaieLSTHUVYkM!=dCwFqlOWuKvtzcjbIDaieLSTHUVYpn else '-'
    if dCwFqlOWuKvtzcjbIDaieLSTHUVYkA!=dCwFqlOWuKvtzcjbIDaieLSTHUVYkM:
     fp.write(dCwFqlOWuKvtzcjbIDaieLSTHUVYko)
     dCwFqlOWuKvtzcjbIDaieLSTHUVYkr+=1
     if dCwFqlOWuKvtzcjbIDaieLSTHUVYkr>=50:break
   fp.close()
  except:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYpn
 def dp_History_Remove(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm,args):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYkG=args.get('delType')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYkQ =args.get('sKey')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYkP =args.get('vType')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRN=xbmcgui.Dialog()
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYkG=='SEARCH_ALL':
   dCwFqlOWuKvtzcjbIDaieLSTHUVYfR=dCwFqlOWuKvtzcjbIDaieLSTHUVYRN.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif dCwFqlOWuKvtzcjbIDaieLSTHUVYkG=='SEARCH_ONE':
   dCwFqlOWuKvtzcjbIDaieLSTHUVYfR=dCwFqlOWuKvtzcjbIDaieLSTHUVYRN.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif dCwFqlOWuKvtzcjbIDaieLSTHUVYkG=='WATCH_ALL':
   dCwFqlOWuKvtzcjbIDaieLSTHUVYfR=dCwFqlOWuKvtzcjbIDaieLSTHUVYRN.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif dCwFqlOWuKvtzcjbIDaieLSTHUVYkG=='WATCH_ONE':
   dCwFqlOWuKvtzcjbIDaieLSTHUVYfR=dCwFqlOWuKvtzcjbIDaieLSTHUVYRN.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYfR==dCwFqlOWuKvtzcjbIDaieLSTHUVYpB:sys.exit()
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYkG=='SEARCH_ALL':
   if os.path.isfile(dCwFqlOWuKvtzcjbIDaieLSTHUVYRp):os.remove(dCwFqlOWuKvtzcjbIDaieLSTHUVYRp)
  elif dCwFqlOWuKvtzcjbIDaieLSTHUVYkG=='SEARCH_ONE':
   try:
    dCwFqlOWuKvtzcjbIDaieLSTHUVYkX=dCwFqlOWuKvtzcjbIDaieLSTHUVYRp
    dCwFqlOWuKvtzcjbIDaieLSTHUVYkN=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.Load_List_File('search') 
    fp=dCwFqlOWuKvtzcjbIDaieLSTHUVYpP(dCwFqlOWuKvtzcjbIDaieLSTHUVYkX,'w',-1,'utf-8')
    for dCwFqlOWuKvtzcjbIDaieLSTHUVYko in dCwFqlOWuKvtzcjbIDaieLSTHUVYkN:
     dCwFqlOWuKvtzcjbIDaieLSTHUVYkh=dCwFqlOWuKvtzcjbIDaieLSTHUVYpo(urllib.parse.parse_qsl(dCwFqlOWuKvtzcjbIDaieLSTHUVYko))
     dCwFqlOWuKvtzcjbIDaieLSTHUVYfg=dCwFqlOWuKvtzcjbIDaieLSTHUVYkh.get('skey').strip()
     if dCwFqlOWuKvtzcjbIDaieLSTHUVYkQ!=dCwFqlOWuKvtzcjbIDaieLSTHUVYfg:
      fp.write(dCwFqlOWuKvtzcjbIDaieLSTHUVYko)
    fp.close()
   except:
    dCwFqlOWuKvtzcjbIDaieLSTHUVYpn
  elif dCwFqlOWuKvtzcjbIDaieLSTHUVYkG=='WATCH_ALL':
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkX=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%dCwFqlOWuKvtzcjbIDaieLSTHUVYkP))
   if os.path.isfile(dCwFqlOWuKvtzcjbIDaieLSTHUVYkX):os.remove(dCwFqlOWuKvtzcjbIDaieLSTHUVYkX)
  elif dCwFqlOWuKvtzcjbIDaieLSTHUVYkG=='WATCH_ONE':
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkX=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%dCwFqlOWuKvtzcjbIDaieLSTHUVYkP))
   try:
    dCwFqlOWuKvtzcjbIDaieLSTHUVYkN=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.Load_List_File(dCwFqlOWuKvtzcjbIDaieLSTHUVYkP) 
    fp=dCwFqlOWuKvtzcjbIDaieLSTHUVYpP(dCwFqlOWuKvtzcjbIDaieLSTHUVYkX,'w',-1,'utf-8')
    for dCwFqlOWuKvtzcjbIDaieLSTHUVYko in dCwFqlOWuKvtzcjbIDaieLSTHUVYkN:
     dCwFqlOWuKvtzcjbIDaieLSTHUVYkh=dCwFqlOWuKvtzcjbIDaieLSTHUVYpo(urllib.parse.parse_qsl(dCwFqlOWuKvtzcjbIDaieLSTHUVYko))
     dCwFqlOWuKvtzcjbIDaieLSTHUVYfg=dCwFqlOWuKvtzcjbIDaieLSTHUVYkh.get('code').strip()
     if dCwFqlOWuKvtzcjbIDaieLSTHUVYkQ!=dCwFqlOWuKvtzcjbIDaieLSTHUVYfg:
      fp.write(dCwFqlOWuKvtzcjbIDaieLSTHUVYko)
    fp.close()
   except:
    dCwFqlOWuKvtzcjbIDaieLSTHUVYpn
  xbmc.executebuiltin("Container.Refresh")
 def Save_Searched_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm,dCwFqlOWuKvtzcjbIDaieLSTHUVYsg):
  try:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYfs=dCwFqlOWuKvtzcjbIDaieLSTHUVYRp
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkN=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.Load_List_File('search') 
   dCwFqlOWuKvtzcjbIDaieLSTHUVYfk={'skey':dCwFqlOWuKvtzcjbIDaieLSTHUVYsg.strip()}
   fp=dCwFqlOWuKvtzcjbIDaieLSTHUVYpP(dCwFqlOWuKvtzcjbIDaieLSTHUVYfs,'w',-1,'utf-8')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkB=urllib.parse.urlencode(dCwFqlOWuKvtzcjbIDaieLSTHUVYfk)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkB=dCwFqlOWuKvtzcjbIDaieLSTHUVYkB+'\n'
   fp.write(dCwFqlOWuKvtzcjbIDaieLSTHUVYkB)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkr=0
   for dCwFqlOWuKvtzcjbIDaieLSTHUVYko in dCwFqlOWuKvtzcjbIDaieLSTHUVYkN:
    dCwFqlOWuKvtzcjbIDaieLSTHUVYkh=dCwFqlOWuKvtzcjbIDaieLSTHUVYpo(urllib.parse.parse_qsl(dCwFqlOWuKvtzcjbIDaieLSTHUVYko))
    dCwFqlOWuKvtzcjbIDaieLSTHUVYkA=dCwFqlOWuKvtzcjbIDaieLSTHUVYfk.get('skey').strip()
    dCwFqlOWuKvtzcjbIDaieLSTHUVYkM=dCwFqlOWuKvtzcjbIDaieLSTHUVYkh.get('skey').strip()
    if dCwFqlOWuKvtzcjbIDaieLSTHUVYkA!=dCwFqlOWuKvtzcjbIDaieLSTHUVYkM:
     fp.write(dCwFqlOWuKvtzcjbIDaieLSTHUVYko)
     dCwFqlOWuKvtzcjbIDaieLSTHUVYkr+=1
     if dCwFqlOWuKvtzcjbIDaieLSTHUVYkr>=50:break
   fp.close()
  except:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYpn
 def dp_Global_Search(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm,args):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYsf=args.get('mode')
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYsf=='TOTAL_SEARCH':
   dCwFqlOWuKvtzcjbIDaieLSTHUVYfJ='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYfJ='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(dCwFqlOWuKvtzcjbIDaieLSTHUVYfJ)
 def dp_Bookmark_Menu(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm,args):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYfJ='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(dCwFqlOWuKvtzcjbIDaieLSTHUVYfJ)
 def login_main(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm):
  (dCwFqlOWuKvtzcjbIDaieLSTHUVYfx,dCwFqlOWuKvtzcjbIDaieLSTHUVYfp,dCwFqlOWuKvtzcjbIDaieLSTHUVYfm)=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.get_settings_account()
  if not(dCwFqlOWuKvtzcjbIDaieLSTHUVYfx and dCwFqlOWuKvtzcjbIDaieLSTHUVYfp):
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRN=xbmcgui.Dialog()
   dCwFqlOWuKvtzcjbIDaieLSTHUVYfR=dCwFqlOWuKvtzcjbIDaieLSTHUVYRN.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if dCwFqlOWuKvtzcjbIDaieLSTHUVYfR==dCwFqlOWuKvtzcjbIDaieLSTHUVYpN:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.cookiefile_check()==dCwFqlOWuKvtzcjbIDaieLSTHUVYpN:return
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   dCwFqlOWuKvtzcjbIDaieLSTHUVYfE=0
   while dCwFqlOWuKvtzcjbIDaieLSTHUVYpN:
    dCwFqlOWuKvtzcjbIDaieLSTHUVYfE+=1
    time.sleep(0.05)
    if dCwFqlOWuKvtzcjbIDaieLSTHUVYfE>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYfX=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.GetCredential(dCwFqlOWuKvtzcjbIDaieLSTHUVYfx,dCwFqlOWuKvtzcjbIDaieLSTHUVYfp,dCwFqlOWuKvtzcjbIDaieLSTHUVYfm)
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYfX:dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYfX==dCwFqlOWuKvtzcjbIDaieLSTHUVYpB:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_setEpOrderby(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm,args):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYgX =args.get('orderby')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.set_winEpisodeOrderby(dCwFqlOWuKvtzcjbIDaieLSTHUVYgX)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm,args):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYsf =args.get('mode')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYfn =args.get('contentid')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYfy =args.get('pvrmode')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYfN=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.get_selQuality()
  dCwFqlOWuKvtzcjbIDaieLSTHUVYgk =dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.get_settings_play()
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.addon_log(dCwFqlOWuKvtzcjbIDaieLSTHUVYfn+' - '+dCwFqlOWuKvtzcjbIDaieLSTHUVYsf)
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYsf=='SPORTS':
   dCwFqlOWuKvtzcjbIDaieLSTHUVYfB=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.GetSportsURL(dCwFqlOWuKvtzcjbIDaieLSTHUVYfn,dCwFqlOWuKvtzcjbIDaieLSTHUVYfN)
  else:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYfB=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.GetStreamingURL(dCwFqlOWuKvtzcjbIDaieLSTHUVYsf,dCwFqlOWuKvtzcjbIDaieLSTHUVYfn,dCwFqlOWuKvtzcjbIDaieLSTHUVYfN,dCwFqlOWuKvtzcjbIDaieLSTHUVYfy,playOption=dCwFqlOWuKvtzcjbIDaieLSTHUVYgk)
  dCwFqlOWuKvtzcjbIDaieLSTHUVYfr={'user-agent':dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.USER_AGENT}
  dCwFqlOWuKvtzcjbIDaieLSTHUVYfo=dCwFqlOWuKvtzcjbIDaieLSTHUVYfB['stream_cookie'] 
  dCwFqlOWuKvtzcjbIDaieLSTHUVYfh=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.make_stream_header(dCwFqlOWuKvtzcjbIDaieLSTHUVYfr,dCwFqlOWuKvtzcjbIDaieLSTHUVYfo)
  dCwFqlOWuKvtzcjbIDaieLSTHUVYfA='{}|{}'.format(dCwFqlOWuKvtzcjbIDaieLSTHUVYfB['stream_url'],dCwFqlOWuKvtzcjbIDaieLSTHUVYfh)
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.addon_log('surl : '+dCwFqlOWuKvtzcjbIDaieLSTHUVYfA)
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYfB['stream_url']=='':
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.addon_noti(__language__(30907).encode('utf8'))
   return
  dCwFqlOWuKvtzcjbIDaieLSTHUVYgf,dCwFqlOWuKvtzcjbIDaieLSTHUVYgJ=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.get_settings_proxyport()
  dCwFqlOWuKvtzcjbIDaieLSTHUVYfM=urllib.parse.urlparse(dCwFqlOWuKvtzcjbIDaieLSTHUVYfB['stream_url'])
  dCwFqlOWuKvtzcjbIDaieLSTHUVYfM=dCwFqlOWuKvtzcjbIDaieLSTHUVYfM.path.strip('/').split('/')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYfM=dCwFqlOWuKvtzcjbIDaieLSTHUVYfM[dCwFqlOWuKvtzcjbIDaieLSTHUVYpM(dCwFqlOWuKvtzcjbIDaieLSTHUVYfM)-1] 
  if (dCwFqlOWuKvtzcjbIDaieLSTHUVYgf==dCwFqlOWuKvtzcjbIDaieLSTHUVYpN and args.get('mode')in['VOD','MOVIE']and(dCwFqlOWuKvtzcjbIDaieLSTHUVYfB['playParam']['hdr']=='hdr' or dCwFqlOWuKvtzcjbIDaieLSTHUVYfB['playParam']['uhd']=='uhd')):
   if dCwFqlOWuKvtzcjbIDaieLSTHUVYfM.split('.')[1]=='mpd':
    dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.Wavve_Parse_mpd(dCwFqlOWuKvtzcjbIDaieLSTHUVYfB)
   else:
    dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.Wavve_Parse_m3u8(dCwFqlOWuKvtzcjbIDaieLSTHUVYfB)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYfG={'addon':'wavvem','playOption':dCwFqlOWuKvtzcjbIDaieLSTHUVYgk,}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYfG=json.dumps(dCwFqlOWuKvtzcjbIDaieLSTHUVYfG,separators=(',',':'))
   dCwFqlOWuKvtzcjbIDaieLSTHUVYfG=base64.standard_b64encode(dCwFqlOWuKvtzcjbIDaieLSTHUVYfG.encode()).decode('utf-8')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYfA ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(dCwFqlOWuKvtzcjbIDaieLSTHUVYgJ,dCwFqlOWuKvtzcjbIDaieLSTHUVYfA,dCwFqlOWuKvtzcjbIDaieLSTHUVYfG)
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.addon_log('surl : '+dCwFqlOWuKvtzcjbIDaieLSTHUVYfA)
  dCwFqlOWuKvtzcjbIDaieLSTHUVYfQ=xbmcgui.ListItem(path=dCwFqlOWuKvtzcjbIDaieLSTHUVYfA)
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYfB['stream_drm']:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.addon_log('!!streaming_drm!!')
   inputstreamhelper.Helper('mpd',drm='com.widevine.alpha').check_inputstream()
   if 'licensetoken' in dCwFqlOWuKvtzcjbIDaieLSTHUVYfB['stream_drm']:
    dCwFqlOWuKvtzcjbIDaieLSTHUVYJR=dCwFqlOWuKvtzcjbIDaieLSTHUVYfB['stream_drm']['licensetoken']
    dCwFqlOWuKvtzcjbIDaieLSTHUVYJg =dCwFqlOWuKvtzcjbIDaieLSTHUVYfB['stream_drm']['licenseurl']
    if dCwFqlOWuKvtzcjbIDaieLSTHUVYsf=='MOVIE':
     dCwFqlOWuKvtzcjbIDaieLSTHUVYJs='https://www.wavve.com/player/movie?movieid=%s'%dCwFqlOWuKvtzcjbIDaieLSTHUVYfn
    else:
     dCwFqlOWuKvtzcjbIDaieLSTHUVYJs='https://www.wavve.com/player/vod?programid=%s&page=1'%dCwFqlOWuKvtzcjbIDaieLSTHUVYfn
    dCwFqlOWuKvtzcjbIDaieLSTHUVYJk={'content-type':'application/octet-stream','origin':'https://www.wavve.com','License-Token':dCwFqlOWuKvtzcjbIDaieLSTHUVYJR,'referer':dCwFqlOWuKvtzcjbIDaieLSTHUVYJs,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.USER_AGENT,}
   else:
    dCwFqlOWuKvtzcjbIDaieLSTHUVYJR=dCwFqlOWuKvtzcjbIDaieLSTHUVYfB['stream_drm']['customdata']
    dCwFqlOWuKvtzcjbIDaieLSTHUVYJg =dCwFqlOWuKvtzcjbIDaieLSTHUVYfB['stream_drm']['drmhost']
    if dCwFqlOWuKvtzcjbIDaieLSTHUVYsf=='MOVIE':
     dCwFqlOWuKvtzcjbIDaieLSTHUVYJs='https://www.wavve.com/player/movie?movieid=%s'%dCwFqlOWuKvtzcjbIDaieLSTHUVYfn
    else:
     dCwFqlOWuKvtzcjbIDaieLSTHUVYJs='https://www.wavve.com/player/vod?programid=%s&page=1'%dCwFqlOWuKvtzcjbIDaieLSTHUVYfn
    dCwFqlOWuKvtzcjbIDaieLSTHUVYJk={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':dCwFqlOWuKvtzcjbIDaieLSTHUVYJR,'referer':dCwFqlOWuKvtzcjbIDaieLSTHUVYJs,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.USER_AGENT,}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYJf=dCwFqlOWuKvtzcjbIDaieLSTHUVYJg+'|'+urllib.parse.urlencode(dCwFqlOWuKvtzcjbIDaieLSTHUVYJk)+'|R{SSM}|'
   dCwFqlOWuKvtzcjbIDaieLSTHUVYfQ.setProperty('inputstream','inputstream.adaptive')
   if dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.KodiVersion<=20:
    dCwFqlOWuKvtzcjbIDaieLSTHUVYfQ.setProperty('inputstream.adaptive.manifest_type','mpd')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYfQ.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYfQ.setProperty('inputstream.adaptive.license_key',dCwFqlOWuKvtzcjbIDaieLSTHUVYJf)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYfQ.setProperty('inputstream.adaptive.stream_headers',dCwFqlOWuKvtzcjbIDaieLSTHUVYfh)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYfQ.setProperty('inputstream.adaptive.manifest_headers',dCwFqlOWuKvtzcjbIDaieLSTHUVYfh)
  elif dCwFqlOWuKvtzcjbIDaieLSTHUVYsf in['VOD','MOVIE']:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYfQ.setContentLookup(dCwFqlOWuKvtzcjbIDaieLSTHUVYpB)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYfQ.setMimeType('application/x-mpegURL')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYfQ.setProperty('inputstream','inputstream.adaptive')
   if dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.KodiVersion<=20:
    if dCwFqlOWuKvtzcjbIDaieLSTHUVYfB['stream_action']=='hls':
     dCwFqlOWuKvtzcjbIDaieLSTHUVYfQ.setProperty('inputstream.adaptive.manifest_type','hls')
    else:
     dCwFqlOWuKvtzcjbIDaieLSTHUVYfQ.setProperty('inputstream.adaptive.manifest_type','mpd')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYfQ.setProperty('inputstream.adaptive.stream_headers',dCwFqlOWuKvtzcjbIDaieLSTHUVYfh)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYfQ.setProperty('inputstream.adaptive.manifest_headers',dCwFqlOWuKvtzcjbIDaieLSTHUVYfh)
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYfB['stream_vtt']:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYfQ.setSubtitles([dCwFqlOWuKvtzcjbIDaieLSTHUVYfB['stream_vtt']])
  xbmcplugin.setResolvedUrl(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm._addon_handle,dCwFqlOWuKvtzcjbIDaieLSTHUVYpN,dCwFqlOWuKvtzcjbIDaieLSTHUVYfQ)
  dCwFqlOWuKvtzcjbIDaieLSTHUVYJx=dCwFqlOWuKvtzcjbIDaieLSTHUVYpB
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYfB['stream_preview']:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.addon_noti(dCwFqlOWuKvtzcjbIDaieLSTHUVYfB['stream_preview'].encode('utf-8'))
   dCwFqlOWuKvtzcjbIDaieLSTHUVYJx=dCwFqlOWuKvtzcjbIDaieLSTHUVYpN
  else:
   if '/preview.' in urllib.parse.urlsplit(dCwFqlOWuKvtzcjbIDaieLSTHUVYfB['stream_url']).path:
    dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.addon_noti(__language__(30908).encode('utf8'))
    dCwFqlOWuKvtzcjbIDaieLSTHUVYJx=dCwFqlOWuKvtzcjbIDaieLSTHUVYpN
  try:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYJp=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and dCwFqlOWuKvtzcjbIDaieLSTHUVYJx==dCwFqlOWuKvtzcjbIDaieLSTHUVYpB and dCwFqlOWuKvtzcjbIDaieLSTHUVYJp!='-':
    dCwFqlOWuKvtzcjbIDaieLSTHUVYgA={'code':dCwFqlOWuKvtzcjbIDaieLSTHUVYJp,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.Save_Watched_List(args.get('mode').lower(),dCwFqlOWuKvtzcjbIDaieLSTHUVYgA)
  except:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYpn
 def logout(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRN=xbmcgui.Dialog()
  dCwFqlOWuKvtzcjbIDaieLSTHUVYfR=dCwFqlOWuKvtzcjbIDaieLSTHUVYRN.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYfR==dCwFqlOWuKvtzcjbIDaieLSTHUVYpB:sys.exit()
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.Init_WV_Total()
  if os.path.isfile(dCwFqlOWuKvtzcjbIDaieLSTHUVYRx):os.remove(dCwFqlOWuKvtzcjbIDaieLSTHUVYRx)
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYJm =dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.Get_Now_Datetime()
  dCwFqlOWuKvtzcjbIDaieLSTHUVYJE=dCwFqlOWuKvtzcjbIDaieLSTHUVYJm+datetime.timedelta(days=dCwFqlOWuKvtzcjbIDaieLSTHUVYpy(__addon__.getSetting('cache_ttl')))
  (dCwFqlOWuKvtzcjbIDaieLSTHUVYfx,dCwFqlOWuKvtzcjbIDaieLSTHUVYfp,dCwFqlOWuKvtzcjbIDaieLSTHUVYfm)=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.get_settings_account()
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.Save_session_acount(dCwFqlOWuKvtzcjbIDaieLSTHUVYfx,dCwFqlOWuKvtzcjbIDaieLSTHUVYfp,dCwFqlOWuKvtzcjbIDaieLSTHUVYfm)
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.WV['account']['token_limit']=dCwFqlOWuKvtzcjbIDaieLSTHUVYJE.strftime('%Y%m%d')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.JsonFile_Save(dCwFqlOWuKvtzcjbIDaieLSTHUVYRx,dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.WV)
 def cookiefile_check(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.WV=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.JsonFile_Load(dCwFqlOWuKvtzcjbIDaieLSTHUVYRx)
  if 'account' not in dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.WV:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.Init_WV_Total()
   return dCwFqlOWuKvtzcjbIDaieLSTHUVYpB
  if 'uuid' not in dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.WV.get('cookies'):
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.Init_WV_Total()
   return dCwFqlOWuKvtzcjbIDaieLSTHUVYpB
  (dCwFqlOWuKvtzcjbIDaieLSTHUVYJX,dCwFqlOWuKvtzcjbIDaieLSTHUVYJn,dCwFqlOWuKvtzcjbIDaieLSTHUVYJy)=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.get_settings_account()
  (dCwFqlOWuKvtzcjbIDaieLSTHUVYJN,dCwFqlOWuKvtzcjbIDaieLSTHUVYJB,dCwFqlOWuKvtzcjbIDaieLSTHUVYJr)=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.Load_session_acount()
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYJX!=dCwFqlOWuKvtzcjbIDaieLSTHUVYJN or dCwFqlOWuKvtzcjbIDaieLSTHUVYJn!=dCwFqlOWuKvtzcjbIDaieLSTHUVYJB or dCwFqlOWuKvtzcjbIDaieLSTHUVYJy!=dCwFqlOWuKvtzcjbIDaieLSTHUVYJr:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.Init_WV_Total()
   return dCwFqlOWuKvtzcjbIDaieLSTHUVYpB
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYpy(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))>dCwFqlOWuKvtzcjbIDaieLSTHUVYpy(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.WV['account']['token_limit']):
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.Init_WV_Total()
   return dCwFqlOWuKvtzcjbIDaieLSTHUVYpB
  return dCwFqlOWuKvtzcjbIDaieLSTHUVYpN
 def dp_LiveCatagory_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm,args):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYJo =args.get('sCode')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYJh=args.get('sIndex')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYsG,dCwFqlOWuKvtzcjbIDaieLSTHUVYJA=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.Get_LiveCatagory_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYJo,dCwFqlOWuKvtzcjbIDaieLSTHUVYJh)
  for dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ in dCwFqlOWuKvtzcjbIDaieLSTHUVYsG:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgy =dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('title')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA={'mode':'LIVE_LIST','genre':dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('genre'),'baseapi':dCwFqlOWuKvtzcjbIDaieLSTHUVYJA}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgQ={'title':dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,'plot':dCwFqlOWuKvtzcjbIDaieLSTHUVYgy}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.add_dir(dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,sublabel='',img='',infoLabels=dCwFqlOWuKvtzcjbIDaieLSTHUVYgQ,isFolder=dCwFqlOWuKvtzcjbIDaieLSTHUVYpN,params=dCwFqlOWuKvtzcjbIDaieLSTHUVYgA)
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYpM(dCwFqlOWuKvtzcjbIDaieLSTHUVYsG)>0:xbmcplugin.endOfDirectory(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm._addon_handle,cacheToDisc=dCwFqlOWuKvtzcjbIDaieLSTHUVYpB)
 def dp_MainCatagory_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm,args):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYJo =args.get('sCode')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYJh=args.get('sIndex')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYsJ =args.get('sType')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYsG=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.Get_MainCatagory_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYJo,dCwFqlOWuKvtzcjbIDaieLSTHUVYJh,dCwFqlOWuKvtzcjbIDaieLSTHUVYsJ)
  for dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ in dCwFqlOWuKvtzcjbIDaieLSTHUVYsG:
   if dCwFqlOWuKvtzcjbIDaieLSTHUVYsJ in['vod','vod09']:
    if dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('subtype')=='catagory':
     dCwFqlOWuKvtzcjbIDaieLSTHUVYsf='PROGRAM_LIST'
    else:
     dCwFqlOWuKvtzcjbIDaieLSTHUVYsf='SUPERSECTION_LIST'
   elif dCwFqlOWuKvtzcjbIDaieLSTHUVYsJ=='movie':
    dCwFqlOWuKvtzcjbIDaieLSTHUVYsf='MOVIE_LIST'
   else:
    dCwFqlOWuKvtzcjbIDaieLSTHUVYsf=''
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgy='%s (%s)'%(dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('title'),args.get('ordernm'))
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA={'mode':dCwFqlOWuKvtzcjbIDaieLSTHUVYsf,'suburl':dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('suburl'),'subapi':dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.get_settings_exclusion21():
    if dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('title')=='성인' or dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('title')=='성인+' or dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('title')=='에로티시즘' or dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('title')=='19':continue
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgQ={'title':dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,'plot':dCwFqlOWuKvtzcjbIDaieLSTHUVYgy}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.add_dir(dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,sublabel='',img='',infoLabels=dCwFqlOWuKvtzcjbIDaieLSTHUVYgQ,isFolder=dCwFqlOWuKvtzcjbIDaieLSTHUVYpN,params=dCwFqlOWuKvtzcjbIDaieLSTHUVYgA)
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYpM(dCwFqlOWuKvtzcjbIDaieLSTHUVYsG)>0:xbmcplugin.endOfDirectory(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm._addon_handle,cacheToDisc=dCwFqlOWuKvtzcjbIDaieLSTHUVYpB)
 def dp_Program_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm,args):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYJM =args.get('subapi')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYsM=dCwFqlOWuKvtzcjbIDaieLSTHUVYpy(args.get('page'))
  dCwFqlOWuKvtzcjbIDaieLSTHUVYgX =args.get('orderby')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.addon_log('dp_Program_List')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.addon_log(dCwFqlOWuKvtzcjbIDaieLSTHUVYJM)
  dCwFqlOWuKvtzcjbIDaieLSTHUVYsG,dCwFqlOWuKvtzcjbIDaieLSTHUVYsp=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.Get_Program_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYJM,dCwFqlOWuKvtzcjbIDaieLSTHUVYsM,dCwFqlOWuKvtzcjbIDaieLSTHUVYgX)
  for dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ in dCwFqlOWuKvtzcjbIDaieLSTHUVYsG:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsP =dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('videoid')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkR =dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('vidtype')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgy =dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('title')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkg=dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('thumbnail')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYks =dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('age')
   if dCwFqlOWuKvtzcjbIDaieLSTHUVYks=='18' or dCwFqlOWuKvtzcjbIDaieLSTHUVYks=='19' or dCwFqlOWuKvtzcjbIDaieLSTHUVYks=='21':dCwFqlOWuKvtzcjbIDaieLSTHUVYgy+=' (%s)'%(dCwFqlOWuKvtzcjbIDaieLSTHUVYks)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgQ={'plot':dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,'mpaa':dCwFqlOWuKvtzcjbIDaieLSTHUVYks,'mediatype':'tvshow','title':dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA={'mode':'SEASON_LIST','videoid':dCwFqlOWuKvtzcjbIDaieLSTHUVYsP,'vidtype':dCwFqlOWuKvtzcjbIDaieLSTHUVYkR,}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsh=[]
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkf={'mode':'VIEW_DETAIL','values':{'videoid':dCwFqlOWuKvtzcjbIDaieLSTHUVYsP,'vidtype':'tvshow','contenttype':dCwFqlOWuKvtzcjbIDaieLSTHUVYkR,}}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkJ=json.dumps(dCwFqlOWuKvtzcjbIDaieLSTHUVYkf,separators=(',',':'))
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkJ=base64.standard_b64encode(dCwFqlOWuKvtzcjbIDaieLSTHUVYkJ.encode()).decode('utf-8')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkJ=dCwFqlOWuKvtzcjbIDaieLSTHUVYkJ.replace('+','%2B')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkx='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(dCwFqlOWuKvtzcjbIDaieLSTHUVYkJ)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsh.append(('상세정보 조회',dCwFqlOWuKvtzcjbIDaieLSTHUVYkx))
   if dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.get_settings_makebookmark():
    dCwFqlOWuKvtzcjbIDaieLSTHUVYkf={'videoid':dCwFqlOWuKvtzcjbIDaieLSTHUVYsP,'vidtype':'tvshow','vtitle':dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,'vsubtitle':'','contenttype':dCwFqlOWuKvtzcjbIDaieLSTHUVYkR,}
    dCwFqlOWuKvtzcjbIDaieLSTHUVYkp=json.dumps(dCwFqlOWuKvtzcjbIDaieLSTHUVYkf)
    dCwFqlOWuKvtzcjbIDaieLSTHUVYkp=urllib.parse.quote(dCwFqlOWuKvtzcjbIDaieLSTHUVYkp)
    dCwFqlOWuKvtzcjbIDaieLSTHUVYkx='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(dCwFqlOWuKvtzcjbIDaieLSTHUVYkp)
    dCwFqlOWuKvtzcjbIDaieLSTHUVYsh.append(('(통합) 찜 영상에 추가',dCwFqlOWuKvtzcjbIDaieLSTHUVYkx))
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.add_dir(dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,sublabel='',img=dCwFqlOWuKvtzcjbIDaieLSTHUVYkg,infoLabels=dCwFqlOWuKvtzcjbIDaieLSTHUVYgQ,isFolder=dCwFqlOWuKvtzcjbIDaieLSTHUVYpN,params=dCwFqlOWuKvtzcjbIDaieLSTHUVYgA,ContextMenu=dCwFqlOWuKvtzcjbIDaieLSTHUVYsh)
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYsp:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA={}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA['mode'] ='PROGRAM_LIST' 
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA['subapi']=dCwFqlOWuKvtzcjbIDaieLSTHUVYJM 
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA['page'] =dCwFqlOWuKvtzcjbIDaieLSTHUVYpQ(dCwFqlOWuKvtzcjbIDaieLSTHUVYsM+1)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgy='[B]%s >>[/B]'%'다음 페이지'
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkm=dCwFqlOWuKvtzcjbIDaieLSTHUVYpQ(dCwFqlOWuKvtzcjbIDaieLSTHUVYsM+1)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgh=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.add_dir(dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,sublabel=dCwFqlOWuKvtzcjbIDaieLSTHUVYkm,img=dCwFqlOWuKvtzcjbIDaieLSTHUVYgh,infoLabels=dCwFqlOWuKvtzcjbIDaieLSTHUVYpn,isFolder=dCwFqlOWuKvtzcjbIDaieLSTHUVYpN,params=dCwFqlOWuKvtzcjbIDaieLSTHUVYgA)
  xbmcplugin.setContent(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm._addon_handle,'tvshows')
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYpM(dCwFqlOWuKvtzcjbIDaieLSTHUVYsG)>0:xbmcplugin.endOfDirectory(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm._addon_handle,cacheToDisc=dCwFqlOWuKvtzcjbIDaieLSTHUVYpB)
 def dp_Season_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm,args):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYsP=args.get('videoid')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYkR=args.get('vidtype')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.addon_log('videoid : '+dCwFqlOWuKvtzcjbIDaieLSTHUVYsP)
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.addon_log('vidtype : '+dCwFqlOWuKvtzcjbIDaieLSTHUVYkR)
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYkR=='contentid':
   dCwFqlOWuKvtzcjbIDaieLSTHUVYfn=dCwFqlOWuKvtzcjbIDaieLSTHUVYsP
   dCwFqlOWuKvtzcjbIDaieLSTHUVYJG =dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.ContentidToSeasonid(dCwFqlOWuKvtzcjbIDaieLSTHUVYsP)
  else:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYfn=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.ProgramidToContentid(dCwFqlOWuKvtzcjbIDaieLSTHUVYsP)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYJG =dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.ContentidToSeasonid(dCwFqlOWuKvtzcjbIDaieLSTHUVYfn)
  dCwFqlOWuKvtzcjbIDaieLSTHUVYJQ=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.Get_Season_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYJG)
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYpM(dCwFqlOWuKvtzcjbIDaieLSTHUVYJQ)>1:
   for dCwFqlOWuKvtzcjbIDaieLSTHUVYJP in dCwFqlOWuKvtzcjbIDaieLSTHUVYJQ:
    dCwFqlOWuKvtzcjbIDaieLSTHUVYxR=dCwFqlOWuKvtzcjbIDaieLSTHUVYJP.get('season_Id')
    dCwFqlOWuKvtzcjbIDaieLSTHUVYxg=dCwFqlOWuKvtzcjbIDaieLSTHUVYJP.get('season_Nm')
    dCwFqlOWuKvtzcjbIDaieLSTHUVYxs=dCwFqlOWuKvtzcjbIDaieLSTHUVYJP.get('programNm')
    dCwFqlOWuKvtzcjbIDaieLSTHUVYkg=dCwFqlOWuKvtzcjbIDaieLSTHUVYJP.get('thumbnail')
    dCwFqlOWuKvtzcjbIDaieLSTHUVYxk =dCwFqlOWuKvtzcjbIDaieLSTHUVYJP.get('synopsis')
    dCwFqlOWuKvtzcjbIDaieLSTHUVYsA={'mediatype':'tvshow','title':dCwFqlOWuKvtzcjbIDaieLSTHUVYxg,'plot':dCwFqlOWuKvtzcjbIDaieLSTHUVYxk,}
    dCwFqlOWuKvtzcjbIDaieLSTHUVYgA={'mode':'EPISODE_LIST','seasonid':dCwFqlOWuKvtzcjbIDaieLSTHUVYxR,'page':'1',}
    dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.add_dir(dCwFqlOWuKvtzcjbIDaieLSTHUVYxg,sublabel=dCwFqlOWuKvtzcjbIDaieLSTHUVYxs,img=dCwFqlOWuKvtzcjbIDaieLSTHUVYkg,infoLabels=dCwFqlOWuKvtzcjbIDaieLSTHUVYsA,isFolder=dCwFqlOWuKvtzcjbIDaieLSTHUVYpN,params=dCwFqlOWuKvtzcjbIDaieLSTHUVYgA,ContextMenu=dCwFqlOWuKvtzcjbIDaieLSTHUVYpn)
   xbmcplugin.setContent(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm._addon_handle,'seasons')
   xbmcplugin.endOfDirectory(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm._addon_handle,cacheToDisc=dCwFqlOWuKvtzcjbIDaieLSTHUVYpB)
  else:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYxf={'seasonid':dCwFqlOWuKvtzcjbIDaieLSTHUVYJG,'page':'1',}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.dp_Episode_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYxf)
 def dp_Episode_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm,args):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYJG =args.get('seasonid')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYsM =dCwFqlOWuKvtzcjbIDaieLSTHUVYpy(args.get('page'))
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.addon_log('seasonid : '+dCwFqlOWuKvtzcjbIDaieLSTHUVYJG)
  dCwFqlOWuKvtzcjbIDaieLSTHUVYsG,dCwFqlOWuKvtzcjbIDaieLSTHUVYsp=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.Get_Episode_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYJG,dCwFqlOWuKvtzcjbIDaieLSTHUVYsM,orderby=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.get_winEpisodeOrderby())
  for dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ in dCwFqlOWuKvtzcjbIDaieLSTHUVYsG:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkm=dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('episodenumber')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYxJ ='[%s]\n\n%s'%(dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('episodetitle'),dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('synopsis'))
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsA={'mediatype':'episode','title':dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('programtitle'),'plot':dCwFqlOWuKvtzcjbIDaieLSTHUVYxJ,'cast':dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('episodeactors'),}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA={'mode':'VOD','programid':dCwFqlOWuKvtzcjbIDaieLSTHUVYJG,'contentid':dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('contentid'),'thumbnail':dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('thumbnail'),'title':dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('programtitle'),'subtitle':dCwFqlOWuKvtzcjbIDaieLSTHUVYkm,}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.add_dir(dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('programtitle'),sublabel=dCwFqlOWuKvtzcjbIDaieLSTHUVYkm,img=dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('thumbnail'),infoLabels=dCwFqlOWuKvtzcjbIDaieLSTHUVYsA,isFolder=dCwFqlOWuKvtzcjbIDaieLSTHUVYpB,params=dCwFqlOWuKvtzcjbIDaieLSTHUVYgA)
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYsM==1:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsA={'plot':'정렬순서를 변경합니다.'}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA={}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA['mode'] ='ORDER_BY' 
   if dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.get_winEpisodeOrderby()=='desc':
    dCwFqlOWuKvtzcjbIDaieLSTHUVYgy='정렬순서변경 : 최신화부터 -> 1회부터'
    dCwFqlOWuKvtzcjbIDaieLSTHUVYgA['orderby']='asc'
   else:
    dCwFqlOWuKvtzcjbIDaieLSTHUVYgy='정렬순서변경 : 1회부터 -> 최신화부터'
    dCwFqlOWuKvtzcjbIDaieLSTHUVYgA['orderby']='desc'
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgh=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.add_dir(dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,sublabel='',img=dCwFqlOWuKvtzcjbIDaieLSTHUVYgh,infoLabels=dCwFqlOWuKvtzcjbIDaieLSTHUVYsA,isFolder=dCwFqlOWuKvtzcjbIDaieLSTHUVYpB,params=dCwFqlOWuKvtzcjbIDaieLSTHUVYgA,isLink=dCwFqlOWuKvtzcjbIDaieLSTHUVYpN)
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYsp:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA={}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA['mode'] ='EPISODE_LIST' 
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA['seasonid']=dCwFqlOWuKvtzcjbIDaieLSTHUVYJG
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA['page'] =dCwFqlOWuKvtzcjbIDaieLSTHUVYpQ(dCwFqlOWuKvtzcjbIDaieLSTHUVYsM+1)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgy='[B]%s >>[/B]'%'다음 페이지'
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkm=dCwFqlOWuKvtzcjbIDaieLSTHUVYpQ(dCwFqlOWuKvtzcjbIDaieLSTHUVYsM+1)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgh=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.add_dir(dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,sublabel=dCwFqlOWuKvtzcjbIDaieLSTHUVYkm,img=dCwFqlOWuKvtzcjbIDaieLSTHUVYgh,infoLabels=dCwFqlOWuKvtzcjbIDaieLSTHUVYpn,isFolder=dCwFqlOWuKvtzcjbIDaieLSTHUVYpN,params=dCwFqlOWuKvtzcjbIDaieLSTHUVYgA)
  xbmcplugin.setContent(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm._addon_handle,'episodes')
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYpM(dCwFqlOWuKvtzcjbIDaieLSTHUVYsG)>0:xbmcplugin.endOfDirectory(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm._addon_handle,cacheToDisc=dCwFqlOWuKvtzcjbIDaieLSTHUVYpB)
 def dp_SuperSection_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm,args):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYxp =args.get('suburl')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYJM =args.get('subapi')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.addon_log('dp_SuperSection_List')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.addon_log('suburl : '+dCwFqlOWuKvtzcjbIDaieLSTHUVYxp)
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.addon_log('subapi : '+dCwFqlOWuKvtzcjbIDaieLSTHUVYJM)
  dCwFqlOWuKvtzcjbIDaieLSTHUVYsG=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.Get_SuperMultiSection_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYxp)
  for dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ in dCwFqlOWuKvtzcjbIDaieLSTHUVYsG:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgy =dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('title')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYJM =dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('subapi')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYxm=dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('cell_type')
   if dCwFqlOWuKvtzcjbIDaieLSTHUVYJM.find('contenttype=movie')>=0 or dCwFqlOWuKvtzcjbIDaieLSTHUVYJM.find('mtype=svod')>=0:
    dCwFqlOWuKvtzcjbIDaieLSTHUVYsf='MOVIE_LIST'
   elif re.search('themes/2\d{4}',dCwFqlOWuKvtzcjbIDaieLSTHUVYJM)or re.search('themes-band/9\d{4}',dCwFqlOWuKvtzcjbIDaieLSTHUVYJM):
    dCwFqlOWuKvtzcjbIDaieLSTHUVYsf='MOVIE_LIST'
   else:
    dCwFqlOWuKvtzcjbIDaieLSTHUVYsf='PROGRAM_LIST'
   '''
   if subapi.find('mtype=svod') >= 0 or subapi.find('mtype=ppv') >= 0 or subapi.find('contenttype=movie') >= 0: #영화 #20201107
    mode = 'MOVIE_LIST'
   elif subapi.find('contenttype=program') >= 0:
    mode = 'PROGRAM_LIST'
   elif cell_type == 'band_71': # band_71 #20201107
    mode   = 'SUPERSECTION_LIST'
    (temp_url, temp_api) = self.WavveObj.Baseapi_Parse(subapi)
    suburl = temp_api.get('api')
    subapi = ''
   elif cell_type == 'band_2': # band_2
    mode = 'BAND2SECTION_LIST'
   elif cell_type == 'band_live':
    mode = 'BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}', subapi) :
    mode = 'MOVIE_LIST'
   else: # band_10
    mode = 'PROGRAM_LIST'
   '''   
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsA={'plot':dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,'mediatype':'tvshow',}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA={'mode':dCwFqlOWuKvtzcjbIDaieLSTHUVYsf,'suburl':dCwFqlOWuKvtzcjbIDaieLSTHUVYxp,'subapi':dCwFqlOWuKvtzcjbIDaieLSTHUVYJM,'page':'1',}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.add_dir(dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,sublabel='',img=dCwFqlOWuKvtzcjbIDaieLSTHUVYpn,infoLabels=dCwFqlOWuKvtzcjbIDaieLSTHUVYsA,isFolder=dCwFqlOWuKvtzcjbIDaieLSTHUVYpN,params=dCwFqlOWuKvtzcjbIDaieLSTHUVYgA)
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYpM(dCwFqlOWuKvtzcjbIDaieLSTHUVYsG)>0:xbmcplugin.endOfDirectory(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm._addon_handle,cacheToDisc=dCwFqlOWuKvtzcjbIDaieLSTHUVYpB)
 def dp_BandLiveSection_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm,args):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYJM =args.get('subapi')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYsM=dCwFqlOWuKvtzcjbIDaieLSTHUVYpy(args.get('page'))
  dCwFqlOWuKvtzcjbIDaieLSTHUVYsG,dCwFqlOWuKvtzcjbIDaieLSTHUVYsp=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.Get_BandLiveSection_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYJM,dCwFqlOWuKvtzcjbIDaieLSTHUVYsM)
  for dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ in dCwFqlOWuKvtzcjbIDaieLSTHUVYsG:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYxE =dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('channelid')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYxX =dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('studio')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYxn=dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('tvshowtitle')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkg =dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('thumbnail')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYks =dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('age')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsA={'mediatype':'tvshow','mpaa':dCwFqlOWuKvtzcjbIDaieLSTHUVYks,'title':'%s < %s >'%(dCwFqlOWuKvtzcjbIDaieLSTHUVYxX,dCwFqlOWuKvtzcjbIDaieLSTHUVYxn),'tvshowtitle':dCwFqlOWuKvtzcjbIDaieLSTHUVYxn,'studio':dCwFqlOWuKvtzcjbIDaieLSTHUVYxX,'plot':dCwFqlOWuKvtzcjbIDaieLSTHUVYxX}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA={'mode':'LIVE','contentid':dCwFqlOWuKvtzcjbIDaieLSTHUVYxE}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.add_dir(dCwFqlOWuKvtzcjbIDaieLSTHUVYxX,sublabel=dCwFqlOWuKvtzcjbIDaieLSTHUVYxn,img=dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('thumbnail'),infoLabels=dCwFqlOWuKvtzcjbIDaieLSTHUVYsA,isFolder=dCwFqlOWuKvtzcjbIDaieLSTHUVYpB,params=dCwFqlOWuKvtzcjbIDaieLSTHUVYgA)
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYsp:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA={}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA['mode'] ='BANDLIVESECTION_LIST' 
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA['subapi']=dCwFqlOWuKvtzcjbIDaieLSTHUVYJM
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA['page'] =dCwFqlOWuKvtzcjbIDaieLSTHUVYpQ(dCwFqlOWuKvtzcjbIDaieLSTHUVYsM+1)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgy='[B]%s >>[/B]'%'다음 페이지'
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkm=dCwFqlOWuKvtzcjbIDaieLSTHUVYpQ(dCwFqlOWuKvtzcjbIDaieLSTHUVYsM+1)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgh=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.add_dir(dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,sublabel=dCwFqlOWuKvtzcjbIDaieLSTHUVYkm,img=dCwFqlOWuKvtzcjbIDaieLSTHUVYgh,infoLabels=dCwFqlOWuKvtzcjbIDaieLSTHUVYpn,isFolder=dCwFqlOWuKvtzcjbIDaieLSTHUVYpN,params=dCwFqlOWuKvtzcjbIDaieLSTHUVYgA)
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYpM(dCwFqlOWuKvtzcjbIDaieLSTHUVYsG)>0:xbmcplugin.endOfDirectory(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm._addon_handle,cacheToDisc=dCwFqlOWuKvtzcjbIDaieLSTHUVYpB)
 def dp_Band2Section_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm,args):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYJM =args.get('subapi')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYsM=dCwFqlOWuKvtzcjbIDaieLSTHUVYpy(args.get('page'))
  dCwFqlOWuKvtzcjbIDaieLSTHUVYsG,dCwFqlOWuKvtzcjbIDaieLSTHUVYsp=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.Get_Band2Section_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYJM,dCwFqlOWuKvtzcjbIDaieLSTHUVYsM)
  for dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ in dCwFqlOWuKvtzcjbIDaieLSTHUVYsG:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgy =dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('programtitle')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkm =dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('episodetitle')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsA={'plot':dCwFqlOWuKvtzcjbIDaieLSTHUVYgy+'\n\n'+dCwFqlOWuKvtzcjbIDaieLSTHUVYkm,'mpaa':dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('age'),'mediatype':'episode'}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA={'mode':'VOD','programid':'-','contentid':dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('videoid'),'thumbnail':dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('thumbnail'),'title':dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,'subtitle':dCwFqlOWuKvtzcjbIDaieLSTHUVYkm}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.add_dir(dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,sublabel=dCwFqlOWuKvtzcjbIDaieLSTHUVYkm,img=dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('thumbnail'),infoLabels=dCwFqlOWuKvtzcjbIDaieLSTHUVYsA,isFolder=dCwFqlOWuKvtzcjbIDaieLSTHUVYpB,params=dCwFqlOWuKvtzcjbIDaieLSTHUVYgA)
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYsp:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA={}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA['mode'] ='BAND2SECTION_LIST' 
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA['subapi']=dCwFqlOWuKvtzcjbIDaieLSTHUVYJM
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA['page'] =dCwFqlOWuKvtzcjbIDaieLSTHUVYpQ(dCwFqlOWuKvtzcjbIDaieLSTHUVYsM+1)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgy='[B]%s >>[/B]'%'다음 페이지'
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkm=dCwFqlOWuKvtzcjbIDaieLSTHUVYpQ(dCwFqlOWuKvtzcjbIDaieLSTHUVYsM+1)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgh=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.add_dir(dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,sublabel=dCwFqlOWuKvtzcjbIDaieLSTHUVYkm,img=dCwFqlOWuKvtzcjbIDaieLSTHUVYgh,infoLabels=dCwFqlOWuKvtzcjbIDaieLSTHUVYpn,isFolder=dCwFqlOWuKvtzcjbIDaieLSTHUVYpN,params=dCwFqlOWuKvtzcjbIDaieLSTHUVYgA)
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYpM(dCwFqlOWuKvtzcjbIDaieLSTHUVYsG)>0:xbmcplugin.endOfDirectory(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm._addon_handle,cacheToDisc=dCwFqlOWuKvtzcjbIDaieLSTHUVYpB)
 def dp_Movie_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm,args):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYJM =args.get('subapi')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYsM=dCwFqlOWuKvtzcjbIDaieLSTHUVYpy(args.get('page'))
  dCwFqlOWuKvtzcjbIDaieLSTHUVYgX =args.get('orderby')or '-'
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.addon_log('dp_Movie_List')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.addon_log(dCwFqlOWuKvtzcjbIDaieLSTHUVYJM)
  dCwFqlOWuKvtzcjbIDaieLSTHUVYsG,dCwFqlOWuKvtzcjbIDaieLSTHUVYsp=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.Get_Movie_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYJM,dCwFqlOWuKvtzcjbIDaieLSTHUVYsM,dCwFqlOWuKvtzcjbIDaieLSTHUVYgX)
  for dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ in dCwFqlOWuKvtzcjbIDaieLSTHUVYsG:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsP =dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('videoid')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkR =dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('vidtype')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgy =dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('title')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkg=dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('thumbnail')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYks =dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('age')
   if dCwFqlOWuKvtzcjbIDaieLSTHUVYks=='18' or dCwFqlOWuKvtzcjbIDaieLSTHUVYks=='19' or dCwFqlOWuKvtzcjbIDaieLSTHUVYks=='21':dCwFqlOWuKvtzcjbIDaieLSTHUVYgy+=' (%s)'%(dCwFqlOWuKvtzcjbIDaieLSTHUVYks)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsA={'plot':dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,'mpaa':dCwFqlOWuKvtzcjbIDaieLSTHUVYks,'mediatype':'movie'}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA={'mode':'MOVIE','contentid':dCwFqlOWuKvtzcjbIDaieLSTHUVYsP,'title':dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,'thumbnail':dCwFqlOWuKvtzcjbIDaieLSTHUVYkg,'age':dCwFqlOWuKvtzcjbIDaieLSTHUVYks,}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsh=[]
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkf={'mode':'VIEW_DETAIL','values':{'videoid':dCwFqlOWuKvtzcjbIDaieLSTHUVYsP,'vidtype':'movie','contenttype':dCwFqlOWuKvtzcjbIDaieLSTHUVYkR,}}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkJ=json.dumps(dCwFqlOWuKvtzcjbIDaieLSTHUVYkf,separators=(',',':'))
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkJ=base64.standard_b64encode(dCwFqlOWuKvtzcjbIDaieLSTHUVYkJ.encode()).decode('utf-8')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkJ=dCwFqlOWuKvtzcjbIDaieLSTHUVYkJ.replace('+','%2B')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkx='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(dCwFqlOWuKvtzcjbIDaieLSTHUVYkJ)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsh.append(('상세정보 조회',dCwFqlOWuKvtzcjbIDaieLSTHUVYkx))
   if dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.get_settings_makebookmark():
    dCwFqlOWuKvtzcjbIDaieLSTHUVYkf={'videoid':dCwFqlOWuKvtzcjbIDaieLSTHUVYsP,'vidtype':'movie','vtitle':dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,'vsubtitle':'','contenttype':'programid',}
    dCwFqlOWuKvtzcjbIDaieLSTHUVYkp=json.dumps(dCwFqlOWuKvtzcjbIDaieLSTHUVYkf)
    dCwFqlOWuKvtzcjbIDaieLSTHUVYkp=urllib.parse.quote(dCwFqlOWuKvtzcjbIDaieLSTHUVYkp)
    dCwFqlOWuKvtzcjbIDaieLSTHUVYkx='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(dCwFqlOWuKvtzcjbIDaieLSTHUVYkp)
    dCwFqlOWuKvtzcjbIDaieLSTHUVYsh.append(('(통합) 찜 영상에 추가',dCwFqlOWuKvtzcjbIDaieLSTHUVYkx))
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.add_dir(dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,sublabel='',img=dCwFqlOWuKvtzcjbIDaieLSTHUVYkg,infoLabels=dCwFqlOWuKvtzcjbIDaieLSTHUVYsA,isFolder=dCwFqlOWuKvtzcjbIDaieLSTHUVYpB,params=dCwFqlOWuKvtzcjbIDaieLSTHUVYgA,ContextMenu=dCwFqlOWuKvtzcjbIDaieLSTHUVYsh)
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYsp:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA={}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA['mode'] ='MOVIE_LIST' 
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA['subapi']=dCwFqlOWuKvtzcjbIDaieLSTHUVYJM 
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA['page'] =dCwFqlOWuKvtzcjbIDaieLSTHUVYpQ(dCwFqlOWuKvtzcjbIDaieLSTHUVYsM+1)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA['orderby']=dCwFqlOWuKvtzcjbIDaieLSTHUVYgX
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgy='[B]%s >>[/B]'%'다음 페이지'
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkm=dCwFqlOWuKvtzcjbIDaieLSTHUVYpQ(dCwFqlOWuKvtzcjbIDaieLSTHUVYsM+1)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgh=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.add_dir(dCwFqlOWuKvtzcjbIDaieLSTHUVYgy,sublabel=dCwFqlOWuKvtzcjbIDaieLSTHUVYkm,img=dCwFqlOWuKvtzcjbIDaieLSTHUVYgh,infoLabels=dCwFqlOWuKvtzcjbIDaieLSTHUVYpn,isFolder=dCwFqlOWuKvtzcjbIDaieLSTHUVYpN,params=dCwFqlOWuKvtzcjbIDaieLSTHUVYgA)
  xbmcplugin.setContent(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm._addon_handle,'movies')
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYpM(dCwFqlOWuKvtzcjbIDaieLSTHUVYsG)>0:xbmcplugin.endOfDirectory(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm._addon_handle,cacheToDisc=dCwFqlOWuKvtzcjbIDaieLSTHUVYpB)
 def dp_Set_Bookmark(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm,args):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYxy=urllib.parse.unquote(args.get('bm_param'))
  dCwFqlOWuKvtzcjbIDaieLSTHUVYxy=json.loads(dCwFqlOWuKvtzcjbIDaieLSTHUVYxy)
  dCwFqlOWuKvtzcjbIDaieLSTHUVYsP =dCwFqlOWuKvtzcjbIDaieLSTHUVYxy.get('videoid')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYkR =dCwFqlOWuKvtzcjbIDaieLSTHUVYxy.get('vidtype')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYxN =dCwFqlOWuKvtzcjbIDaieLSTHUVYxy.get('vtitle')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYxB =dCwFqlOWuKvtzcjbIDaieLSTHUVYxy.get('vsubtitle')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYxr=dCwFqlOWuKvtzcjbIDaieLSTHUVYxy.get('contenttype')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRN=xbmcgui.Dialog()
  dCwFqlOWuKvtzcjbIDaieLSTHUVYfR=dCwFqlOWuKvtzcjbIDaieLSTHUVYRN.yesno(__language__(30913).encode('utf8'),dCwFqlOWuKvtzcjbIDaieLSTHUVYxN+' \n\n'+__language__(30914))
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYfR==dCwFqlOWuKvtzcjbIDaieLSTHUVYpB:return
  dCwFqlOWuKvtzcjbIDaieLSTHUVYxo=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.GetBookmarkInfo(dCwFqlOWuKvtzcjbIDaieLSTHUVYsP,dCwFqlOWuKvtzcjbIDaieLSTHUVYkR,dCwFqlOWuKvtzcjbIDaieLSTHUVYxr)
  dCwFqlOWuKvtzcjbIDaieLSTHUVYxh=json.dumps(dCwFqlOWuKvtzcjbIDaieLSTHUVYxo)
  dCwFqlOWuKvtzcjbIDaieLSTHUVYxh=urllib.parse.quote(dCwFqlOWuKvtzcjbIDaieLSTHUVYxh)
  dCwFqlOWuKvtzcjbIDaieLSTHUVYkx ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(dCwFqlOWuKvtzcjbIDaieLSTHUVYxh)
  xbmc.executebuiltin(dCwFqlOWuKvtzcjbIDaieLSTHUVYkx)
 def dp_LiveChannel_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm,args):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYxA =args.get('genre')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYJA=args.get('baseapi')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYsG=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.Get_LiveChannel_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYxA,dCwFqlOWuKvtzcjbIDaieLSTHUVYJA)
  for dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ in dCwFqlOWuKvtzcjbIDaieLSTHUVYsG:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYxE =dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('channelid')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYxX =dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('studio')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYxn=dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('tvshowtitle')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYkg =dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('thumbnail')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYks =dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('age')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYxM =dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('epg')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsA={'mediatype':'episode','mpaa':dCwFqlOWuKvtzcjbIDaieLSTHUVYks,'title':'%s < %s >'%(dCwFqlOWuKvtzcjbIDaieLSTHUVYxX,dCwFqlOWuKvtzcjbIDaieLSTHUVYxn),'tvshowtitle':dCwFqlOWuKvtzcjbIDaieLSTHUVYxn,'studio':dCwFqlOWuKvtzcjbIDaieLSTHUVYxX,'plot':'%s\n\n%s'%(dCwFqlOWuKvtzcjbIDaieLSTHUVYxX,dCwFqlOWuKvtzcjbIDaieLSTHUVYxM)}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA={'mode':'LIVE','contentid':dCwFqlOWuKvtzcjbIDaieLSTHUVYxE}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.add_dir(dCwFqlOWuKvtzcjbIDaieLSTHUVYxX,sublabel=dCwFqlOWuKvtzcjbIDaieLSTHUVYxn,img=dCwFqlOWuKvtzcjbIDaieLSTHUVYkg,infoLabels=dCwFqlOWuKvtzcjbIDaieLSTHUVYsA,isFolder=dCwFqlOWuKvtzcjbIDaieLSTHUVYpB,params=dCwFqlOWuKvtzcjbIDaieLSTHUVYgA)
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYpM(dCwFqlOWuKvtzcjbIDaieLSTHUVYsG)>0:xbmcplugin.endOfDirectory(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm._addon_handle,cacheToDisc=dCwFqlOWuKvtzcjbIDaieLSTHUVYpB)
 def dp_Sports_GameList(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm,args):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYsG=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.Get_Sports_Gamelist()
  for dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ in dCwFqlOWuKvtzcjbIDaieLSTHUVYsG:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYxG =dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('game_date')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYxQ =dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('game_time')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYxP =dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('svc_id')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYpR =dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('away_team')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYpg =dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('home_team')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYps=dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('game_status')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYpk =dCwFqlOWuKvtzcjbIDaieLSTHUVYsQ.get('game_place')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYpf ='%s vs %s (%s)'%(dCwFqlOWuKvtzcjbIDaieLSTHUVYpR,dCwFqlOWuKvtzcjbIDaieLSTHUVYpg,dCwFqlOWuKvtzcjbIDaieLSTHUVYpk)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYpJ =dCwFqlOWuKvtzcjbIDaieLSTHUVYxG+' '+dCwFqlOWuKvtzcjbIDaieLSTHUVYxQ
   if dCwFqlOWuKvtzcjbIDaieLSTHUVYps=='LIVE':
    dCwFqlOWuKvtzcjbIDaieLSTHUVYps='~경기중~'
   elif dCwFqlOWuKvtzcjbIDaieLSTHUVYps=='END':
    dCwFqlOWuKvtzcjbIDaieLSTHUVYps='경기종료'
   elif dCwFqlOWuKvtzcjbIDaieLSTHUVYps=='CANCEL':
    dCwFqlOWuKvtzcjbIDaieLSTHUVYps='취소'
   else:
    dCwFqlOWuKvtzcjbIDaieLSTHUVYps=''
   if dCwFqlOWuKvtzcjbIDaieLSTHUVYps=='':
    dCwFqlOWuKvtzcjbIDaieLSTHUVYkm=dCwFqlOWuKvtzcjbIDaieLSTHUVYpf
   else:
    dCwFqlOWuKvtzcjbIDaieLSTHUVYkm=dCwFqlOWuKvtzcjbIDaieLSTHUVYpf+'  '+dCwFqlOWuKvtzcjbIDaieLSTHUVYps
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsA={'mediatype':'episode','title':dCwFqlOWuKvtzcjbIDaieLSTHUVYpf,'plot':'%s\n\n%s\n\n%s'%(dCwFqlOWuKvtzcjbIDaieLSTHUVYpJ,dCwFqlOWuKvtzcjbIDaieLSTHUVYpf,dCwFqlOWuKvtzcjbIDaieLSTHUVYps)}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA={'mode':'SPORTS','contentid':dCwFqlOWuKvtzcjbIDaieLSTHUVYxP}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.add_dir(dCwFqlOWuKvtzcjbIDaieLSTHUVYpJ,sublabel=dCwFqlOWuKvtzcjbIDaieLSTHUVYkm,img='',infoLabels=dCwFqlOWuKvtzcjbIDaieLSTHUVYsA,isFolder=dCwFqlOWuKvtzcjbIDaieLSTHUVYpB,params=dCwFqlOWuKvtzcjbIDaieLSTHUVYgA)
  xbmcplugin.endOfDirectory(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm._addon_handle,cacheToDisc=dCwFqlOWuKvtzcjbIDaieLSTHUVYpB)
 def dp_View_Detail(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm,dCwFqlOWuKvtzcjbIDaieLSTHUVYpE):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYsP =dCwFqlOWuKvtzcjbIDaieLSTHUVYpE.get('videoid')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYkR =dCwFqlOWuKvtzcjbIDaieLSTHUVYpE.get('vidtype') 
  dCwFqlOWuKvtzcjbIDaieLSTHUVYxr=dCwFqlOWuKvtzcjbIDaieLSTHUVYpE.get('contenttype')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.addon_log(dCwFqlOWuKvtzcjbIDaieLSTHUVYsP)
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.addon_log(dCwFqlOWuKvtzcjbIDaieLSTHUVYkR)
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.addon_log(dCwFqlOWuKvtzcjbIDaieLSTHUVYxr)
  dCwFqlOWuKvtzcjbIDaieLSTHUVYxo=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.GetBookmarkInfo(dCwFqlOWuKvtzcjbIDaieLSTHUVYsP,dCwFqlOWuKvtzcjbIDaieLSTHUVYkR,dCwFqlOWuKvtzcjbIDaieLSTHUVYxr)
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYkR=='tvshow':
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA={'mode':'SEASON_LIST','videoid':dCwFqlOWuKvtzcjbIDaieLSTHUVYxo['indexinfo']['videoid'],'vidtype':dCwFqlOWuKvtzcjbIDaieLSTHUVYxo['indexinfo']['vidtype'],}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYfJ='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(dCwFqlOWuKvtzcjbIDaieLSTHUVYgA))
  else:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgA={'mode':'MOVIE','contentid':dCwFqlOWuKvtzcjbIDaieLSTHUVYxo['indexinfo']['videoid'],'title':dCwFqlOWuKvtzcjbIDaieLSTHUVYxo['saveinfo']['infoLabels']['title'],'thumbnail':dCwFqlOWuKvtzcjbIDaieLSTHUVYxo['saveinfo']['thumbnail'],'age':dCwFqlOWuKvtzcjbIDaieLSTHUVYxo['saveinfo']['infoLabels']['mpaa'],}
   dCwFqlOWuKvtzcjbIDaieLSTHUVYfJ='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(dCwFqlOWuKvtzcjbIDaieLSTHUVYgA))
  dCwFqlOWuKvtzcjbIDaieLSTHUVYgN=xbmcgui.ListItem(label=dCwFqlOWuKvtzcjbIDaieLSTHUVYxo['saveinfo']['title'],path=dCwFqlOWuKvtzcjbIDaieLSTHUVYfJ)
  dCwFqlOWuKvtzcjbIDaieLSTHUVYgN.setArt(dCwFqlOWuKvtzcjbIDaieLSTHUVYxo['saveinfo']['thumbnail'])
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.Set_InfoTag(dCwFqlOWuKvtzcjbIDaieLSTHUVYgN.getVideoInfoTag(),dCwFqlOWuKvtzcjbIDaieLSTHUVYxo['saveinfo']['infoLabels'])
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYkR=='movie':
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgN.setIsFolder(dCwFqlOWuKvtzcjbIDaieLSTHUVYpB)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgN.setProperty('IsPlayable','true')
  else:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgN.setIsFolder(dCwFqlOWuKvtzcjbIDaieLSTHUVYpN)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYgN.setProperty('IsPlayable','false')
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRN=xbmcgui.Dialog()
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRN.info(dCwFqlOWuKvtzcjbIDaieLSTHUVYgN)
 def wavve_main(dCwFqlOWuKvtzcjbIDaieLSTHUVYRm):
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.WavveObj.KodiVersion=dCwFqlOWuKvtzcjbIDaieLSTHUVYpy(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  dCwFqlOWuKvtzcjbIDaieLSTHUVYpx=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.main_params.get('params')
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYpx:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYpm =base64.standard_b64decode(dCwFqlOWuKvtzcjbIDaieLSTHUVYpx).decode('utf-8')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYpm =json.loads(dCwFqlOWuKvtzcjbIDaieLSTHUVYpm)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsf =dCwFqlOWuKvtzcjbIDaieLSTHUVYpm.get('mode')
   dCwFqlOWuKvtzcjbIDaieLSTHUVYpE =dCwFqlOWuKvtzcjbIDaieLSTHUVYpm.get('values')
  else:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYsf=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.main_params.get('mode',dCwFqlOWuKvtzcjbIDaieLSTHUVYpn)
   dCwFqlOWuKvtzcjbIDaieLSTHUVYpE=dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.main_params
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYsf=='LOGOUT':
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.logout()
   return
  dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.login_main()
  if dCwFqlOWuKvtzcjbIDaieLSTHUVYsf is dCwFqlOWuKvtzcjbIDaieLSTHUVYpn:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.dp_Main_List()
  elif dCwFqlOWuKvtzcjbIDaieLSTHUVYsf in['LIVE','VOD','MOVIE','SPORTS']:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.play_VIDEO(dCwFqlOWuKvtzcjbIDaieLSTHUVYpE)
  elif dCwFqlOWuKvtzcjbIDaieLSTHUVYsf=='LIVE_CATAGORY':
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.dp_LiveCatagory_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYpE)
  elif dCwFqlOWuKvtzcjbIDaieLSTHUVYsf=='MAIN_CATAGORY':
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.dp_MainCatagory_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYpE)
  elif dCwFqlOWuKvtzcjbIDaieLSTHUVYsf=='SUPERSECTION_LIST':
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.dp_SuperSection_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYpE)
  elif dCwFqlOWuKvtzcjbIDaieLSTHUVYsf=='BANDLIVESECTION_LIST':
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.dp_BandLiveSection_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYpE)
  elif dCwFqlOWuKvtzcjbIDaieLSTHUVYsf=='BAND2SECTION_LIST':
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.dp_Band2Section_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYpE)
  elif dCwFqlOWuKvtzcjbIDaieLSTHUVYsf=='PROGRAM_LIST':
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.dp_Program_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYpE)
  elif dCwFqlOWuKvtzcjbIDaieLSTHUVYsf=='SEASON_LIST':
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.dp_Season_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYpE)
  elif dCwFqlOWuKvtzcjbIDaieLSTHUVYsf=='EPISODE_LIST':
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.dp_Episode_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYpE)
  elif dCwFqlOWuKvtzcjbIDaieLSTHUVYsf=='MOVIE_LIST':
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.dp_Movie_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYpE)
  elif dCwFqlOWuKvtzcjbIDaieLSTHUVYsf=='LIVE_LIST':
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.dp_LiveChannel_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYpE)
  elif dCwFqlOWuKvtzcjbIDaieLSTHUVYsf=='ORDER_BY':
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.dp_setEpOrderby(dCwFqlOWuKvtzcjbIDaieLSTHUVYpE)
  elif dCwFqlOWuKvtzcjbIDaieLSTHUVYsf=='SEARCH_GROUP':
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.dp_Search_Group(dCwFqlOWuKvtzcjbIDaieLSTHUVYpE)
  elif dCwFqlOWuKvtzcjbIDaieLSTHUVYsf in['SEARCH_LIST','LOCAL_SEARCH']:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.dp_Search_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYpE)
  elif dCwFqlOWuKvtzcjbIDaieLSTHUVYsf=='WATCH_GROUP':
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.dp_Watch_Group(dCwFqlOWuKvtzcjbIDaieLSTHUVYpE)
  elif dCwFqlOWuKvtzcjbIDaieLSTHUVYsf=='WATCH_LIST':
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.dp_Watch_List(dCwFqlOWuKvtzcjbIDaieLSTHUVYpE)
  elif dCwFqlOWuKvtzcjbIDaieLSTHUVYsf=='SET_BOOKMARK':
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.dp_Set_Bookmark(dCwFqlOWuKvtzcjbIDaieLSTHUVYpE)
  elif dCwFqlOWuKvtzcjbIDaieLSTHUVYsf in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.dp_History_Remove(dCwFqlOWuKvtzcjbIDaieLSTHUVYpE)
  elif dCwFqlOWuKvtzcjbIDaieLSTHUVYsf in['TOTAL_SEARCH','TOTAL_HISTORY']:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.dp_Global_Search(dCwFqlOWuKvtzcjbIDaieLSTHUVYpE)
  elif dCwFqlOWuKvtzcjbIDaieLSTHUVYsf=='SEARCH_HISTORY':
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.dp_Search_History(dCwFqlOWuKvtzcjbIDaieLSTHUVYpE)
  elif dCwFqlOWuKvtzcjbIDaieLSTHUVYsf=='MENU_BOOKMARK':
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.dp_Bookmark_Menu(dCwFqlOWuKvtzcjbIDaieLSTHUVYpE)
  elif dCwFqlOWuKvtzcjbIDaieLSTHUVYsf=='GAME_LIST':
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.dp_Sports_GameList(dCwFqlOWuKvtzcjbIDaieLSTHUVYpE)
  elif dCwFqlOWuKvtzcjbIDaieLSTHUVYsf=='VIEW_DETAIL':
   dCwFqlOWuKvtzcjbIDaieLSTHUVYRm.dp_View_Detail(dCwFqlOWuKvtzcjbIDaieLSTHUVYpE)
  else:
   dCwFqlOWuKvtzcjbIDaieLSTHUVYpn
# Created by pyminifier (https://github.com/liftoff/pyminifier)
