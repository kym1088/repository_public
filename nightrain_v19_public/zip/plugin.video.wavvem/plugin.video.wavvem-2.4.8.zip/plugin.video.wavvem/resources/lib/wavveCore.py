__author__="NightRain"
pLQXibtYgWrVGHjchkOqPDmTvNxSFo=object
pLQXibtYgWrVGHjchkOqPDmTvNxSFf=None
pLQXibtYgWrVGHjchkOqPDmTvNxSFz=False
pLQXibtYgWrVGHjchkOqPDmTvNxSFe=print
pLQXibtYgWrVGHjchkOqPDmTvNxSJC=str
pLQXibtYgWrVGHjchkOqPDmTvNxSJy=open
pLQXibtYgWrVGHjchkOqPDmTvNxSJM=True
pLQXibtYgWrVGHjchkOqPDmTvNxSJw=range
pLQXibtYgWrVGHjchkOqPDmTvNxSJa=len
pLQXibtYgWrVGHjchkOqPDmTvNxSJE=Exception
pLQXibtYgWrVGHjchkOqPDmTvNxSJF=dict
pLQXibtYgWrVGHjchkOqPDmTvNxSJs=int
import urllib
import re
import json
import sys
import requests
import datetime
import base64
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
pLQXibtYgWrVGHjchkOqPDmTvNxSCM =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
class pLQXibtYgWrVGHjchkOqPDmTvNxSCy(pLQXibtYgWrVGHjchkOqPDmTvNxSFo):
 def __init__(pLQXibtYgWrVGHjchkOqPDmTvNxSCw):
  pLQXibtYgWrVGHjchkOqPDmTvNxSCw.API_DOMAIN='https://apis.wavve.com'
  pLQXibtYgWrVGHjchkOqPDmTvNxSCw.WV ={}
  pLQXibtYgWrVGHjchkOqPDmTvNxSCw.Init_WV_Total()
  pLQXibtYgWrVGHjchkOqPDmTvNxSCw.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  pLQXibtYgWrVGHjchkOqPDmTvNxSCw.DEVICE ='pc'
  pLQXibtYgWrVGHjchkOqPDmTvNxSCw.DRM ='wm'
  pLQXibtYgWrVGHjchkOqPDmTvNxSCw.PARTNER ='pooq'
  pLQXibtYgWrVGHjchkOqPDmTvNxSCw.POOQZONE ='none'
  pLQXibtYgWrVGHjchkOqPDmTvNxSCw.REGION ='kor'
  pLQXibtYgWrVGHjchkOqPDmTvNxSCw.TARGETAGE ='all'
  pLQXibtYgWrVGHjchkOqPDmTvNxSCw.HTTPTAG ='https://'
  pLQXibtYgWrVGHjchkOqPDmTvNxSCw.LIST_LIMIT=30 
  pLQXibtYgWrVGHjchkOqPDmTvNxSCw.EP_LIMIT =30 
  pLQXibtYgWrVGHjchkOqPDmTvNxSCw.MV_LIMIT =24 
  pLQXibtYgWrVGHjchkOqPDmTvNxSCw.SEARCH_LIMIT=20 
  pLQXibtYgWrVGHjchkOqPDmTvNxSCw.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36'
  pLQXibtYgWrVGHjchkOqPDmTvNxSCw.DEFAULT_HEADER={'user-agent':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.USER_AGENT}
  pLQXibtYgWrVGHjchkOqPDmTvNxSCw.KodiVersion=20
  pLQXibtYgWrVGHjchkOqPDmTvNxSCw.WV_SESSION_COOKIES1=''
  pLQXibtYgWrVGHjchkOqPDmTvNxSCw.WV_SESSION_COOKIES2=''
  pLQXibtYgWrVGHjchkOqPDmTvNxSCw.COOKIE_FILE_NAME =''
  pLQXibtYgWrVGHjchkOqPDmTvNxSCw.WV_STREAM_FILENAME =''
 def Init_WV_Total(pLQXibtYgWrVGHjchkOqPDmTvNxSCw):
  pLQXibtYgWrVGHjchkOqPDmTvNxSCw.WV={'account':{},'cookies':{},}
 def callRequestCookies(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,jobtype,pLQXibtYgWrVGHjchkOqPDmTvNxSyU,payload=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,params=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,headers=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,cookies=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,redirects=pLQXibtYgWrVGHjchkOqPDmTvNxSFz):
  pLQXibtYgWrVGHjchkOqPDmTvNxSCa=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.DEFAULT_HEADER
  if headers:pLQXibtYgWrVGHjchkOqPDmTvNxSCa.update(headers)
  if jobtype=='Get':
   pLQXibtYgWrVGHjchkOqPDmTvNxSCE=requests.get(pLQXibtYgWrVGHjchkOqPDmTvNxSyU,params=params,headers=pLQXibtYgWrVGHjchkOqPDmTvNxSCa,cookies=cookies,allow_redirects=redirects)
  else:
   pLQXibtYgWrVGHjchkOqPDmTvNxSCE=requests.post(pLQXibtYgWrVGHjchkOqPDmTvNxSyU,json=payload,params=params,headers=pLQXibtYgWrVGHjchkOqPDmTvNxSCa,cookies=cookies,allow_redirects=redirects)
  pLQXibtYgWrVGHjchkOqPDmTvNxSFe(pLQXibtYgWrVGHjchkOqPDmTvNxSJC(pLQXibtYgWrVGHjchkOqPDmTvNxSCE.status_code)+' - '+pLQXibtYgWrVGHjchkOqPDmTvNxSJC(pLQXibtYgWrVGHjchkOqPDmTvNxSCE.url))
  return pLQXibtYgWrVGHjchkOqPDmTvNxSCE
 def JsonFile_Save(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,filename,pLQXibtYgWrVGHjchkOqPDmTvNxSCF):
  if filename=='':return pLQXibtYgWrVGHjchkOqPDmTvNxSFz
  try:
   fp=pLQXibtYgWrVGHjchkOqPDmTvNxSJy(filename,'w',-1,'utf-8')
   json.dump(pLQXibtYgWrVGHjchkOqPDmTvNxSCF,fp,indent=4,ensure_ascii=pLQXibtYgWrVGHjchkOqPDmTvNxSFz)
   fp.close()
  except:
   return pLQXibtYgWrVGHjchkOqPDmTvNxSFz
  return pLQXibtYgWrVGHjchkOqPDmTvNxSJM
 def JsonFile_Load(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,filename):
  if filename=='':return{}
  try:
   fp=pLQXibtYgWrVGHjchkOqPDmTvNxSJy(filename,'r',-1,'utf-8')
   pLQXibtYgWrVGHjchkOqPDmTvNxSCs=json.load(fp)
   fp.close()
  except:
   return{}
  return pLQXibtYgWrVGHjchkOqPDmTvNxSCs
 def TextFile_Save(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,filename,resText):
  if filename=='':return pLQXibtYgWrVGHjchkOqPDmTvNxSFz
  try:
   fp=pLQXibtYgWrVGHjchkOqPDmTvNxSJy(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return pLQXibtYgWrVGHjchkOqPDmTvNxSFz
  return pLQXibtYgWrVGHjchkOqPDmTvNxSJM
 def Save_session_acount(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,pLQXibtYgWrVGHjchkOqPDmTvNxSCI,pLQXibtYgWrVGHjchkOqPDmTvNxSCU,pLQXibtYgWrVGHjchkOqPDmTvNxSCd):
  pLQXibtYgWrVGHjchkOqPDmTvNxSCw.WV['account']['wvid']=base64.standard_b64encode(pLQXibtYgWrVGHjchkOqPDmTvNxSCI.encode()).decode('utf-8')
  pLQXibtYgWrVGHjchkOqPDmTvNxSCw.WV['account']['wvpw']=base64.standard_b64encode(pLQXibtYgWrVGHjchkOqPDmTvNxSCU.encode()).decode('utf-8')
  pLQXibtYgWrVGHjchkOqPDmTvNxSCw.WV['account']['wvpf']=pLQXibtYgWrVGHjchkOqPDmTvNxSCd 
 def Load_session_acount(pLQXibtYgWrVGHjchkOqPDmTvNxSCw):
  try:
   pLQXibtYgWrVGHjchkOqPDmTvNxSCI=base64.standard_b64decode(pLQXibtYgWrVGHjchkOqPDmTvNxSCw.WV['account']['wvid']).decode('utf-8')
   pLQXibtYgWrVGHjchkOqPDmTvNxSCU=base64.standard_b64decode(pLQXibtYgWrVGHjchkOqPDmTvNxSCw.WV['account']['wvpw']).decode('utf-8')
   pLQXibtYgWrVGHjchkOqPDmTvNxSCd=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.WV['account']['wvpf']
  except:
   return '','',0
  return pLQXibtYgWrVGHjchkOqPDmTvNxSCI,pLQXibtYgWrVGHjchkOqPDmTvNxSCU,pLQXibtYgWrVGHjchkOqPDmTvNxSCd
 def GetDefaultParams(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,login=pLQXibtYgWrVGHjchkOqPDmTvNxSJM):
  pLQXibtYgWrVGHjchkOqPDmTvNxSCK={'apikey':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.APIKEY,'credential':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.WV['cookies']['credential']if login else 'none','device':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.DEVICE,'drm':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.DRM,'partner':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.PARTNER,'pooqzone':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.POOQZONE,'region':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.REGION,'targetage':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.TARGETAGE,'client_version':'6.0.1',}
  return pLQXibtYgWrVGHjchkOqPDmTvNxSCK
 def GetDefaultParams_AND(pLQXibtYgWrVGHjchkOqPDmTvNxSCw):
  pLQXibtYgWrVGHjchkOqPDmTvNxSCK={'apikey':'6A87455D54481A536DFB8AD397C5EC4D','credential':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.WV['cookies']['credential'],'device':'ott','drm':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.DRM,'partner':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.PARTNER,'pooqzone':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.POOQZONE,'region':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.REGION,'targetage':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.TARGETAGE,}
  return pLQXibtYgWrVGHjchkOqPDmTvNxSCK
 def GetGUID(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   pLQXibtYgWrVGHjchkOqPDmTvNxSCB=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   pLQXibtYgWrVGHjchkOqPDmTvNxSCA=GenerateRandomString(5)
   pLQXibtYgWrVGHjchkOqPDmTvNxSCR=pLQXibtYgWrVGHjchkOqPDmTvNxSCA+media+pLQXibtYgWrVGHjchkOqPDmTvNxSCB
   return pLQXibtYgWrVGHjchkOqPDmTvNxSCR
  def GenerateRandomString(num):
   from random import randint
   pLQXibtYgWrVGHjchkOqPDmTvNxSCn=""
   for i in pLQXibtYgWrVGHjchkOqPDmTvNxSJw(0,num):
    s=pLQXibtYgWrVGHjchkOqPDmTvNxSJC(randint(1,5))
    pLQXibtYgWrVGHjchkOqPDmTvNxSCn+=s
   return pLQXibtYgWrVGHjchkOqPDmTvNxSCn
  if guidType==3:
   pLQXibtYgWrVGHjchkOqPDmTvNxSCR=guid_str
  else:
   pLQXibtYgWrVGHjchkOqPDmTvNxSCR=GenerateID(guid_str)
  pLQXibtYgWrVGHjchkOqPDmTvNxSCu=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.GetHash(pLQXibtYgWrVGHjchkOqPDmTvNxSCR)
  if guidType in[2,3]:
   pLQXibtYgWrVGHjchkOqPDmTvNxSCu='%s-%s-%s-%s-%s'%(pLQXibtYgWrVGHjchkOqPDmTvNxSCu[:8],pLQXibtYgWrVGHjchkOqPDmTvNxSCu[8:12],pLQXibtYgWrVGHjchkOqPDmTvNxSCu[12:16],pLQXibtYgWrVGHjchkOqPDmTvNxSCu[16:20],pLQXibtYgWrVGHjchkOqPDmTvNxSCu[20:])
  return pLQXibtYgWrVGHjchkOqPDmTvNxSCu
 def GetHash(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return pLQXibtYgWrVGHjchkOqPDmTvNxSJC(m.hexdigest())
 def CheckQuality(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,sel_qt,qt_list):
  pLQXibtYgWrVGHjchkOqPDmTvNxSCl=0
  for pLQXibtYgWrVGHjchkOqPDmTvNxSCo in qt_list:
   if sel_qt>=pLQXibtYgWrVGHjchkOqPDmTvNxSCo:return pLQXibtYgWrVGHjchkOqPDmTvNxSCo
   pLQXibtYgWrVGHjchkOqPDmTvNxSCl=pLQXibtYgWrVGHjchkOqPDmTvNxSCo
  return pLQXibtYgWrVGHjchkOqPDmTvNxSCl
 def Get_Now_Datetime(pLQXibtYgWrVGHjchkOqPDmTvNxSCw):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,in_text):
  pLQXibtYgWrVGHjchkOqPDmTvNxSCz=in_text.replace('&lt;','<').replace('&gt;','>')
  pLQXibtYgWrVGHjchkOqPDmTvNxSCz=pLQXibtYgWrVGHjchkOqPDmTvNxSCz.replace('<br>','\n')
  pLQXibtYgWrVGHjchkOqPDmTvNxSCz=pLQXibtYgWrVGHjchkOqPDmTvNxSCz.replace('$O$','')
  pLQXibtYgWrVGHjchkOqPDmTvNxSCz=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',pLQXibtYgWrVGHjchkOqPDmTvNxSCz)
  pLQXibtYgWrVGHjchkOqPDmTvNxSCz=pLQXibtYgWrVGHjchkOqPDmTvNxSCz.lstrip('#')
  return pLQXibtYgWrVGHjchkOqPDmTvNxSCz
 def make_str_ToCookie(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,cookieStr):
  pLQXibtYgWrVGHjchkOqPDmTvNxSCe={}
  for pLQXibtYgWrVGHjchkOqPDmTvNxSyC in cookieStr.split(';'):
   pLQXibtYgWrVGHjchkOqPDmTvNxSyM=pLQXibtYgWrVGHjchkOqPDmTvNxSyC.split('=')
   pLQXibtYgWrVGHjchkOqPDmTvNxSCe[pLQXibtYgWrVGHjchkOqPDmTvNxSyM[0]]=pLQXibtYgWrVGHjchkOqPDmTvNxSyM[1]
  return pLQXibtYgWrVGHjchkOqPDmTvNxSCe 
 def make_stream_header(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,pLQXibtYgWrVGHjchkOqPDmTvNxSyJ,pLQXibtYgWrVGHjchkOqPDmTvNxSCe):
  pLQXibtYgWrVGHjchkOqPDmTvNxSyw=''
  if pLQXibtYgWrVGHjchkOqPDmTvNxSCe not in[{},pLQXibtYgWrVGHjchkOqPDmTvNxSFf,'']:
   pLQXibtYgWrVGHjchkOqPDmTvNxSya=pLQXibtYgWrVGHjchkOqPDmTvNxSJa(pLQXibtYgWrVGHjchkOqPDmTvNxSCe)
   for pLQXibtYgWrVGHjchkOqPDmTvNxSyE,pLQXibtYgWrVGHjchkOqPDmTvNxSyF in pLQXibtYgWrVGHjchkOqPDmTvNxSCe.items():
    pLQXibtYgWrVGHjchkOqPDmTvNxSyw+='{}={}'.format(pLQXibtYgWrVGHjchkOqPDmTvNxSyE,pLQXibtYgWrVGHjchkOqPDmTvNxSyF)
    pLQXibtYgWrVGHjchkOqPDmTvNxSya+=-1
    if pLQXibtYgWrVGHjchkOqPDmTvNxSya>0:pLQXibtYgWrVGHjchkOqPDmTvNxSyw+='; '
   pLQXibtYgWrVGHjchkOqPDmTvNxSyJ['cookie']=pLQXibtYgWrVGHjchkOqPDmTvNxSyw
  pLQXibtYgWrVGHjchkOqPDmTvNxSys=''
  i=0
  for pLQXibtYgWrVGHjchkOqPDmTvNxSyE,pLQXibtYgWrVGHjchkOqPDmTvNxSyF in pLQXibtYgWrVGHjchkOqPDmTvNxSyJ.items():
   i=i+1
   if i>1:pLQXibtYgWrVGHjchkOqPDmTvNxSys+='&'
   pLQXibtYgWrVGHjchkOqPDmTvNxSys+='{}={}'.format(pLQXibtYgWrVGHjchkOqPDmTvNxSyE,urllib.parse.quote(pLQXibtYgWrVGHjchkOqPDmTvNxSyF))
  return pLQXibtYgWrVGHjchkOqPDmTvNxSys
 def GetCredential(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,user_id,user_pw,user_pf):
  pLQXibtYgWrVGHjchkOqPDmTvNxSyI=pLQXibtYgWrVGHjchkOqPDmTvNxSFz
  try:
   pLQXibtYgWrVGHjchkOqPDmTvNxSyU=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.API_DOMAIN+ '/login'
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.GetDefaultParams(login=pLQXibtYgWrVGHjchkOqPDmTvNxSFz)
   pLQXibtYgWrVGHjchkOqPDmTvNxSyd={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   pLQXibtYgWrVGHjchkOqPDmTvNxSyK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.callRequestCookies('Post',pLQXibtYgWrVGHjchkOqPDmTvNxSyU,payload=pLQXibtYgWrVGHjchkOqPDmTvNxSyd,params=pLQXibtYgWrVGHjchkOqPDmTvNxSCK,headers=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,cookies=pLQXibtYgWrVGHjchkOqPDmTvNxSFf)
   pLQXibtYgWrVGHjchkOqPDmTvNxSyB=json.loads(pLQXibtYgWrVGHjchkOqPDmTvNxSyK.text)
   pLQXibtYgWrVGHjchkOqPDmTvNxSCw.WV['cookies']['credential']=pLQXibtYgWrVGHjchkOqPDmTvNxSyB['credential']
   if user_pf!=0:
    pLQXibtYgWrVGHjchkOqPDmTvNxSyd={'id':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.WV['cookies']['credential'],'password':'','profile':pLQXibtYgWrVGHjchkOqPDmTvNxSJC(user_pf),'pushid':'','type':'credential'}
    pLQXibtYgWrVGHjchkOqPDmTvNxSCK =pLQXibtYgWrVGHjchkOqPDmTvNxSCw.GetDefaultParams(login=pLQXibtYgWrVGHjchkOqPDmTvNxSJM) 
    pLQXibtYgWrVGHjchkOqPDmTvNxSyK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.callRequestCookies('Post',pLQXibtYgWrVGHjchkOqPDmTvNxSyU,payload=pLQXibtYgWrVGHjchkOqPDmTvNxSyd,params=pLQXibtYgWrVGHjchkOqPDmTvNxSCK,headers=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,cookies=pLQXibtYgWrVGHjchkOqPDmTvNxSFf)
    pLQXibtYgWrVGHjchkOqPDmTvNxSyB=json.loads(pLQXibtYgWrVGHjchkOqPDmTvNxSyK.text)
    pLQXibtYgWrVGHjchkOqPDmTvNxSCw.WV['cookies']['credential']=pLQXibtYgWrVGHjchkOqPDmTvNxSyB['credential']
   pLQXibtYgWrVGHjchkOqPDmTvNxSyA=user_id+pLQXibtYgWrVGHjchkOqPDmTvNxSJC(user_pf) 
   pLQXibtYgWrVGHjchkOqPDmTvNxSCw.WV['cookies']['uuid']=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.GetGUID(guid_str=pLQXibtYgWrVGHjchkOqPDmTvNxSyA,guidType=3)
   pLQXibtYgWrVGHjchkOqPDmTvNxSyI=pLQXibtYgWrVGHjchkOqPDmTvNxSJM
  except pLQXibtYgWrVGHjchkOqPDmTvNxSJE as exception:
   pLQXibtYgWrVGHjchkOqPDmTvNxSFe(exception)
   pLQXibtYgWrVGHjchkOqPDmTvNxSCw.Init_WV_Total()
  return pLQXibtYgWrVGHjchkOqPDmTvNxSyI
 def GetIssue(pLQXibtYgWrVGHjchkOqPDmTvNxSCw):
  pLQXibtYgWrVGHjchkOqPDmTvNxSyR=pLQXibtYgWrVGHjchkOqPDmTvNxSFz
  try:
   pLQXibtYgWrVGHjchkOqPDmTvNxSyU=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.API_DOMAIN+'/guid/issue'
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.GetDefaultParams()
   pLQXibtYgWrVGHjchkOqPDmTvNxSyK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.callRequestCookies('Get',pLQXibtYgWrVGHjchkOqPDmTvNxSyU,payload=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,params=pLQXibtYgWrVGHjchkOqPDmTvNxSCK,headers=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,cookies=pLQXibtYgWrVGHjchkOqPDmTvNxSFf)
   pLQXibtYgWrVGHjchkOqPDmTvNxSyB=json.loads(pLQXibtYgWrVGHjchkOqPDmTvNxSyK.text)
   pLQXibtYgWrVGHjchkOqPDmTvNxSyn=pLQXibtYgWrVGHjchkOqPDmTvNxSyB['guid']
   pLQXibtYgWrVGHjchkOqPDmTvNxSyu=pLQXibtYgWrVGHjchkOqPDmTvNxSyB['guidtimestamp']
   if pLQXibtYgWrVGHjchkOqPDmTvNxSyn:pLQXibtYgWrVGHjchkOqPDmTvNxSyR=pLQXibtYgWrVGHjchkOqPDmTvNxSJM
  except pLQXibtYgWrVGHjchkOqPDmTvNxSJE as exception:
   pLQXibtYgWrVGHjchkOqPDmTvNxSFe(exception)
   pLQXibtYgWrVGHjchkOqPDmTvNxSyn='none'
   pLQXibtYgWrVGHjchkOqPDmTvNxSyu='none' 
  pLQXibtYgWrVGHjchkOqPDmTvNxSCw.guid=pLQXibtYgWrVGHjchkOqPDmTvNxSyn
  pLQXibtYgWrVGHjchkOqPDmTvNxSCw.guidtimestamp=pLQXibtYgWrVGHjchkOqPDmTvNxSyu
  return pLQXibtYgWrVGHjchkOqPDmTvNxSyR
 def Baseapi_Parse(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,pLQXibtYgWrVGHjchkOqPDmTvNxSyz):
  try:
   pLQXibtYgWrVGHjchkOqPDmTvNxSyl =urllib.parse.urlsplit(pLQXibtYgWrVGHjchkOqPDmTvNxSyz)
   if pLQXibtYgWrVGHjchkOqPDmTvNxSyl.netloc=='':
    pLQXibtYgWrVGHjchkOqPDmTvNxSyU=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.HTTPTAG+pLQXibtYgWrVGHjchkOqPDmTvNxSyl.netloc+pLQXibtYgWrVGHjchkOqPDmTvNxSyl.path
   else:
    pLQXibtYgWrVGHjchkOqPDmTvNxSyU=pLQXibtYgWrVGHjchkOqPDmTvNxSyl.scheme+'://'+pLQXibtYgWrVGHjchkOqPDmTvNxSyl.netloc+pLQXibtYgWrVGHjchkOqPDmTvNxSyl.path
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK=pLQXibtYgWrVGHjchkOqPDmTvNxSJF(urllib.parse.parse_qsl(pLQXibtYgWrVGHjchkOqPDmTvNxSyl.query))
  except pLQXibtYgWrVGHjchkOqPDmTvNxSJE as exception:
   pLQXibtYgWrVGHjchkOqPDmTvNxSFe(exception)
   return '',{}
  return pLQXibtYgWrVGHjchkOqPDmTvNxSyU,pLQXibtYgWrVGHjchkOqPDmTvNxSCK
 def GetSupermultiUrl(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,sCode,sIndex='0'):
  try:
   pLQXibtYgWrVGHjchkOqPDmTvNxSyU=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.API_DOMAIN+'/cf/supermultisections/'+sCode
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.GetDefaultParams(login=pLQXibtYgWrVGHjchkOqPDmTvNxSFz)
   pLQXibtYgWrVGHjchkOqPDmTvNxSyK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.callRequestCookies('Get',pLQXibtYgWrVGHjchkOqPDmTvNxSyU,payload=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,params=pLQXibtYgWrVGHjchkOqPDmTvNxSCK,headers=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,cookies=pLQXibtYgWrVGHjchkOqPDmTvNxSFf)
   pLQXibtYgWrVGHjchkOqPDmTvNxSyB=json.loads(pLQXibtYgWrVGHjchkOqPDmTvNxSyK.text)
   pLQXibtYgWrVGHjchkOqPDmTvNxSyo=pLQXibtYgWrVGHjchkOqPDmTvNxSyB['multisectionlist'][pLQXibtYgWrVGHjchkOqPDmTvNxSJs(sIndex)]['eventlist'][1]['url']
  except pLQXibtYgWrVGHjchkOqPDmTvNxSJE as exception:
   pLQXibtYgWrVGHjchkOqPDmTvNxSFe(exception)
   return ''
  return pLQXibtYgWrVGHjchkOqPDmTvNxSyo
 def Get_LiveCatagory_List(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,sCode,sIndex='0'):
  pLQXibtYgWrVGHjchkOqPDmTvNxSyf=[]
  pLQXibtYgWrVGHjchkOqPDmTvNxSyz =pLQXibtYgWrVGHjchkOqPDmTvNxSCw.GetSupermultiUrl(sCode,sIndex)
  (pLQXibtYgWrVGHjchkOqPDmTvNxSyU,pLQXibtYgWrVGHjchkOqPDmTvNxSCK)=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.Baseapi_Parse(pLQXibtYgWrVGHjchkOqPDmTvNxSyz)
  if pLQXibtYgWrVGHjchkOqPDmTvNxSyU=='':return pLQXibtYgWrVGHjchkOqPDmTvNxSyf,''
  try:
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK.update(pLQXibtYgWrVGHjchkOqPDmTvNxSCw.GetDefaultParams(login=pLQXibtYgWrVGHjchkOqPDmTvNxSFz))
   pLQXibtYgWrVGHjchkOqPDmTvNxSyK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.callRequestCookies('Get',pLQXibtYgWrVGHjchkOqPDmTvNxSyU,payload=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,params=pLQXibtYgWrVGHjchkOqPDmTvNxSCK,headers=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,cookies=pLQXibtYgWrVGHjchkOqPDmTvNxSFf)
   pLQXibtYgWrVGHjchkOqPDmTvNxSyB=json.loads(pLQXibtYgWrVGHjchkOqPDmTvNxSyK.text)
   if not('filter_item_list' in pLQXibtYgWrVGHjchkOqPDmTvNxSyB['filter']['filterlist'][0]):return[],''
   pLQXibtYgWrVGHjchkOqPDmTvNxSMC=pLQXibtYgWrVGHjchkOqPDmTvNxSyB['filter']['filterlist'][0]['filter_item_list']
   for pLQXibtYgWrVGHjchkOqPDmTvNxSMy in pLQXibtYgWrVGHjchkOqPDmTvNxSMC:
    pLQXibtYgWrVGHjchkOqPDmTvNxSMw={'title':pLQXibtYgWrVGHjchkOqPDmTvNxSMy['title'],'genre':pLQXibtYgWrVGHjchkOqPDmTvNxSMy['api_parameters'][pLQXibtYgWrVGHjchkOqPDmTvNxSMy['api_parameters'].index('=')+1:]}
    pLQXibtYgWrVGHjchkOqPDmTvNxSyf.append(pLQXibtYgWrVGHjchkOqPDmTvNxSMw)
  except pLQXibtYgWrVGHjchkOqPDmTvNxSJE as exception:
   pLQXibtYgWrVGHjchkOqPDmTvNxSFe(exception)
   return[],''
  return pLQXibtYgWrVGHjchkOqPDmTvNxSyf,pLQXibtYgWrVGHjchkOqPDmTvNxSyz
 def Get_MainCatagory_List(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,sCode,sIndex,sType):
  pLQXibtYgWrVGHjchkOqPDmTvNxSyf=[]
  pLQXibtYgWrVGHjchkOqPDmTvNxSyU='https://apis.wavve.com/es/category/launcher-band'
  pLQXibtYgWrVGHjchkOqPDmTvNxSCK={'uitype':sCode,'uiparent':'GN52-'+sCode,'uirank':sIndex,'broadcastid':sCode,'offset':'0','limit':'20','uicode':sCode,'mtype':'N','ctype':sType,'orderby':'default',}
  try:
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK.update(pLQXibtYgWrVGHjchkOqPDmTvNxSCw.GetDefaultParams(login=pLQXibtYgWrVGHjchkOqPDmTvNxSFz))
   pLQXibtYgWrVGHjchkOqPDmTvNxSyK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.callRequestCookies('Get',pLQXibtYgWrVGHjchkOqPDmTvNxSyU,payload=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,params=pLQXibtYgWrVGHjchkOqPDmTvNxSCK,headers=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,cookies=pLQXibtYgWrVGHjchkOqPDmTvNxSFf)
   pLQXibtYgWrVGHjchkOqPDmTvNxSyB=json.loads(pLQXibtYgWrVGHjchkOqPDmTvNxSyK.text)
   if not('celllist' in pLQXibtYgWrVGHjchkOqPDmTvNxSyB['band']):return[]
   pLQXibtYgWrVGHjchkOqPDmTvNxSMC=pLQXibtYgWrVGHjchkOqPDmTvNxSyB['band']['celllist']
   for pLQXibtYgWrVGHjchkOqPDmTvNxSMy in pLQXibtYgWrVGHjchkOqPDmTvNxSMC:
    pLQXibtYgWrVGHjchkOqPDmTvNxSMa =pLQXibtYgWrVGHjchkOqPDmTvNxSMy['event_list'][1]['url']
    (pLQXibtYgWrVGHjchkOqPDmTvNxSME,pLQXibtYgWrVGHjchkOqPDmTvNxSMF)=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.Baseapi_Parse(pLQXibtYgWrVGHjchkOqPDmTvNxSMa)
    pLQXibtYgWrVGHjchkOqPDmTvNxSMw={'title':pLQXibtYgWrVGHjchkOqPDmTvNxSMy['title_list'][0]['text'],'suburl':pLQXibtYgWrVGHjchkOqPDmTvNxSME,'subapi':pLQXibtYgWrVGHjchkOqPDmTvNxSMF.get('api'),'subtype':'catagory' if pLQXibtYgWrVGHjchkOqPDmTvNxSMF else 'supersection'}
    pLQXibtYgWrVGHjchkOqPDmTvNxSyf.append(pLQXibtYgWrVGHjchkOqPDmTvNxSMw)
  except pLQXibtYgWrVGHjchkOqPDmTvNxSJE as exception:
   pLQXibtYgWrVGHjchkOqPDmTvNxSFe(exception)
   return[]
  return pLQXibtYgWrVGHjchkOqPDmTvNxSyf
 def Get_SuperMultiSection_List(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,subapi_text):
  pLQXibtYgWrVGHjchkOqPDmTvNxSyf=[]
  if '/multiband/' in subapi_text: 
   pLQXibtYgWrVGHjchkOqPDmTvNxSyU=subapi_text 
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK={'client':'40'}
  else:
   pLQXibtYgWrVGHjchkOqPDmTvNxSyU=subapi_text 
   pLQXibtYgWrVGHjchkOqPDmTvNxSyU=pLQXibtYgWrVGHjchkOqPDmTvNxSyU.replace('www.wavve.com','apis.wavve.com').replace('supermultisection','v1/multiband')
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK={}
  try:
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK.update(pLQXibtYgWrVGHjchkOqPDmTvNxSCw.GetDefaultParams(login=pLQXibtYgWrVGHjchkOqPDmTvNxSFz))
   pLQXibtYgWrVGHjchkOqPDmTvNxSyK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.callRequestCookies('Get',pLQXibtYgWrVGHjchkOqPDmTvNxSyU,payload=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,params=pLQXibtYgWrVGHjchkOqPDmTvNxSCK,headers=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,cookies=pLQXibtYgWrVGHjchkOqPDmTvNxSFf)
   pLQXibtYgWrVGHjchkOqPDmTvNxSyB=json.loads(pLQXibtYgWrVGHjchkOqPDmTvNxSyK.text)
   if not('multisectionlist' in pLQXibtYgWrVGHjchkOqPDmTvNxSyB):return[]
   pLQXibtYgWrVGHjchkOqPDmTvNxSMC=pLQXibtYgWrVGHjchkOqPDmTvNxSyB['multisectionlist']
   for pLQXibtYgWrVGHjchkOqPDmTvNxSMy in pLQXibtYgWrVGHjchkOqPDmTvNxSMC:
    pLQXibtYgWrVGHjchkOqPDmTvNxSMJ=pLQXibtYgWrVGHjchkOqPDmTvNxSMy['title']
    if pLQXibtYgWrVGHjchkOqPDmTvNxSJa(pLQXibtYgWrVGHjchkOqPDmTvNxSMJ)==0:continue
    if pLQXibtYgWrVGHjchkOqPDmTvNxSMJ=='minor':continue
    if re.search(u'베너',pLQXibtYgWrVGHjchkOqPDmTvNxSMJ):continue
    if re.search(u'배너',pLQXibtYgWrVGHjchkOqPDmTvNxSMJ):continue 
    if pLQXibtYgWrVGHjchkOqPDmTvNxSMy['force_refresh']=='y':continue
    if pLQXibtYgWrVGHjchkOqPDmTvNxSJa(pLQXibtYgWrVGHjchkOqPDmTvNxSMy['eventlist'])>=3:
     pLQXibtYgWrVGHjchkOqPDmTvNxSMF =pLQXibtYgWrVGHjchkOqPDmTvNxSMy['eventlist'][2]['url']
    else:
     pLQXibtYgWrVGHjchkOqPDmTvNxSMF =pLQXibtYgWrVGHjchkOqPDmTvNxSMy['eventlist'][1]['url']
    pLQXibtYgWrVGHjchkOqPDmTvNxSMs=pLQXibtYgWrVGHjchkOqPDmTvNxSMy['cell_type']
    if pLQXibtYgWrVGHjchkOqPDmTvNxSMs=='band_2':
     if pLQXibtYgWrVGHjchkOqPDmTvNxSMF.find('channellist=')>=0:
      pLQXibtYgWrVGHjchkOqPDmTvNxSMs='band_live'
    pLQXibtYgWrVGHjchkOqPDmTvNxSMw={'title':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.Get_ChangeText(pLQXibtYgWrVGHjchkOqPDmTvNxSMJ),'subapi':pLQXibtYgWrVGHjchkOqPDmTvNxSMF,'cell_type':pLQXibtYgWrVGHjchkOqPDmTvNxSMs}
    pLQXibtYgWrVGHjchkOqPDmTvNxSyf.append(pLQXibtYgWrVGHjchkOqPDmTvNxSMw)
  except pLQXibtYgWrVGHjchkOqPDmTvNxSJE as exception:
   pLQXibtYgWrVGHjchkOqPDmTvNxSFe(exception)
   return[]
  return pLQXibtYgWrVGHjchkOqPDmTvNxSyf
 def Get_BandLiveSection_List(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,pLQXibtYgWrVGHjchkOqPDmTvNxSyz,page_int=1):
  pLQXibtYgWrVGHjchkOqPDmTvNxSMI=[]
  pLQXibtYgWrVGHjchkOqPDmTvNxSMU=pLQXibtYgWrVGHjchkOqPDmTvNxSMn=1
  pLQXibtYgWrVGHjchkOqPDmTvNxSMd=pLQXibtYgWrVGHjchkOqPDmTvNxSFz
  try:
   (pLQXibtYgWrVGHjchkOqPDmTvNxSyU,pLQXibtYgWrVGHjchkOqPDmTvNxSCK)=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.Baseapi_Parse(pLQXibtYgWrVGHjchkOqPDmTvNxSyz)
  except pLQXibtYgWrVGHjchkOqPDmTvNxSJE as exception:
   pLQXibtYgWrVGHjchkOqPDmTvNxSFe(exception)
   return[],pLQXibtYgWrVGHjchkOqPDmTvNxSFz
  try:
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK['limit']=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.LIST_LIMIT
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK['offset']=pLQXibtYgWrVGHjchkOqPDmTvNxSJC((page_int-1)*pLQXibtYgWrVGHjchkOqPDmTvNxSCw.LIST_LIMIT)
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK.update(pLQXibtYgWrVGHjchkOqPDmTvNxSCw.GetDefaultParams(login=pLQXibtYgWrVGHjchkOqPDmTvNxSFz))
   pLQXibtYgWrVGHjchkOqPDmTvNxSyK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.callRequestCookies('Get',pLQXibtYgWrVGHjchkOqPDmTvNxSyU,payload=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,params=pLQXibtYgWrVGHjchkOqPDmTvNxSCK,headers=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,cookies=pLQXibtYgWrVGHjchkOqPDmTvNxSFf)
   pLQXibtYgWrVGHjchkOqPDmTvNxSyB=json.loads(pLQXibtYgWrVGHjchkOqPDmTvNxSyK.text)
   if not('celllist' in pLQXibtYgWrVGHjchkOqPDmTvNxSyB['cell_toplist']):return[],pLQXibtYgWrVGHjchkOqPDmTvNxSFz
   pLQXibtYgWrVGHjchkOqPDmTvNxSMC=pLQXibtYgWrVGHjchkOqPDmTvNxSyB['cell_toplist']['celllist']
   for pLQXibtYgWrVGHjchkOqPDmTvNxSMy in pLQXibtYgWrVGHjchkOqPDmTvNxSMC:
    pLQXibtYgWrVGHjchkOqPDmTvNxSMK =pLQXibtYgWrVGHjchkOqPDmTvNxSMy['event_list'][1]['url']
    pLQXibtYgWrVGHjchkOqPDmTvNxSMB=urllib.parse.urlsplit(pLQXibtYgWrVGHjchkOqPDmTvNxSMK).query
    pLQXibtYgWrVGHjchkOqPDmTvNxSMB=pLQXibtYgWrVGHjchkOqPDmTvNxSJF(urllib.parse.parse_qsl(pLQXibtYgWrVGHjchkOqPDmTvNxSMB))
    pLQXibtYgWrVGHjchkOqPDmTvNxSMA='channelid'
    pLQXibtYgWrVGHjchkOqPDmTvNxSMR=pLQXibtYgWrVGHjchkOqPDmTvNxSMB[pLQXibtYgWrVGHjchkOqPDmTvNxSMA]
    pLQXibtYgWrVGHjchkOqPDmTvNxSMw={'studio':pLQXibtYgWrVGHjchkOqPDmTvNxSMy['title_list'][0]['text'],'tvshowtitle':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.Get_ChangeText(pLQXibtYgWrVGHjchkOqPDmTvNxSMy['title_list'][1]['text']),'channelid':pLQXibtYgWrVGHjchkOqPDmTvNxSMR,'age':pLQXibtYgWrVGHjchkOqPDmTvNxSMy.get('age'),'thumbnail':'https://%s'%pLQXibtYgWrVGHjchkOqPDmTvNxSMy.get('thumbnail')}
    pLQXibtYgWrVGHjchkOqPDmTvNxSMI.append(pLQXibtYgWrVGHjchkOqPDmTvNxSMw)
   pLQXibtYgWrVGHjchkOqPDmTvNxSMU=pLQXibtYgWrVGHjchkOqPDmTvNxSJs(pLQXibtYgWrVGHjchkOqPDmTvNxSyB['cell_toplist']['pagecount'])
   if pLQXibtYgWrVGHjchkOqPDmTvNxSyB['cell_toplist']['count']:pLQXibtYgWrVGHjchkOqPDmTvNxSMn =pLQXibtYgWrVGHjchkOqPDmTvNxSJs(pLQXibtYgWrVGHjchkOqPDmTvNxSyB['cell_toplist']['count'])
   else:pLQXibtYgWrVGHjchkOqPDmTvNxSMn=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.LIST_LIMIT*page_int
   pLQXibtYgWrVGHjchkOqPDmTvNxSMd=pLQXibtYgWrVGHjchkOqPDmTvNxSMU>pLQXibtYgWrVGHjchkOqPDmTvNxSMn
  except pLQXibtYgWrVGHjchkOqPDmTvNxSJE as exception:
   pLQXibtYgWrVGHjchkOqPDmTvNxSFe(exception)
   return[],pLQXibtYgWrVGHjchkOqPDmTvNxSFz
  return pLQXibtYgWrVGHjchkOqPDmTvNxSMI,pLQXibtYgWrVGHjchkOqPDmTvNxSMd
 def Get_Band2Section_List(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,pLQXibtYgWrVGHjchkOqPDmTvNxSyz,page_int=1):
  pLQXibtYgWrVGHjchkOqPDmTvNxSMu=[]
  pLQXibtYgWrVGHjchkOqPDmTvNxSMU=pLQXibtYgWrVGHjchkOqPDmTvNxSMn=1
  pLQXibtYgWrVGHjchkOqPDmTvNxSMd=pLQXibtYgWrVGHjchkOqPDmTvNxSFz
  try:
   (pLQXibtYgWrVGHjchkOqPDmTvNxSyU,pLQXibtYgWrVGHjchkOqPDmTvNxSCK)=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.Baseapi_Parse(pLQXibtYgWrVGHjchkOqPDmTvNxSyz)
  except pLQXibtYgWrVGHjchkOqPDmTvNxSJE as exception:
   pLQXibtYgWrVGHjchkOqPDmTvNxSFe(exception)
   return[],pLQXibtYgWrVGHjchkOqPDmTvNxSFz
  try:
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK['came'] ='BandView'
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK['limit']=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.LIST_LIMIT
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK['offset']=pLQXibtYgWrVGHjchkOqPDmTvNxSJC((page_int-1)*pLQXibtYgWrVGHjchkOqPDmTvNxSCw.LIST_LIMIT)
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK.update(pLQXibtYgWrVGHjchkOqPDmTvNxSCw.GetDefaultParams(login=pLQXibtYgWrVGHjchkOqPDmTvNxSFz))
   pLQXibtYgWrVGHjchkOqPDmTvNxSyK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.callRequestCookies('Get',pLQXibtYgWrVGHjchkOqPDmTvNxSyU,payload=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,params=pLQXibtYgWrVGHjchkOqPDmTvNxSCK,headers=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,cookies=pLQXibtYgWrVGHjchkOqPDmTvNxSFf)
   pLQXibtYgWrVGHjchkOqPDmTvNxSyB=json.loads(pLQXibtYgWrVGHjchkOqPDmTvNxSyK.text)
   if not('celllist' in pLQXibtYgWrVGHjchkOqPDmTvNxSyB['cell_toplist']):return[],pLQXibtYgWrVGHjchkOqPDmTvNxSFz
   pLQXibtYgWrVGHjchkOqPDmTvNxSMC=pLQXibtYgWrVGHjchkOqPDmTvNxSyB['cell_toplist']['celllist']
   for pLQXibtYgWrVGHjchkOqPDmTvNxSMy in pLQXibtYgWrVGHjchkOqPDmTvNxSMC:
    pLQXibtYgWrVGHjchkOqPDmTvNxSMK =pLQXibtYgWrVGHjchkOqPDmTvNxSMy['event_list'][1]['url']
    pLQXibtYgWrVGHjchkOqPDmTvNxSMB=urllib.parse.urlsplit(pLQXibtYgWrVGHjchkOqPDmTvNxSMK).query
    pLQXibtYgWrVGHjchkOqPDmTvNxSMB=pLQXibtYgWrVGHjchkOqPDmTvNxSJF(urllib.parse.parse_qsl(pLQXibtYgWrVGHjchkOqPDmTvNxSMB))
    pLQXibtYgWrVGHjchkOqPDmTvNxSMA='contentid'
    pLQXibtYgWrVGHjchkOqPDmTvNxSMR=pLQXibtYgWrVGHjchkOqPDmTvNxSMB[pLQXibtYgWrVGHjchkOqPDmTvNxSMA]
    pLQXibtYgWrVGHjchkOqPDmTvNxSMw={'programtitle':pLQXibtYgWrVGHjchkOqPDmTvNxSMy['title_list'][0]['text'],'episodetitle':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.Get_ChangeText(pLQXibtYgWrVGHjchkOqPDmTvNxSMy['title_list'][1]['text']),'age':pLQXibtYgWrVGHjchkOqPDmTvNxSMy.get('age'),'thumbnail':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.HTTPTAG+pLQXibtYgWrVGHjchkOqPDmTvNxSMy.get('thumbnail'),'vidtype':pLQXibtYgWrVGHjchkOqPDmTvNxSMA,'videoid':pLQXibtYgWrVGHjchkOqPDmTvNxSMR}
    pLQXibtYgWrVGHjchkOqPDmTvNxSMu.append(pLQXibtYgWrVGHjchkOqPDmTvNxSMw)
   pLQXibtYgWrVGHjchkOqPDmTvNxSMU=pLQXibtYgWrVGHjchkOqPDmTvNxSJs(pLQXibtYgWrVGHjchkOqPDmTvNxSyB['cell_toplist']['pagecount'])
   if pLQXibtYgWrVGHjchkOqPDmTvNxSyB['cell_toplist']['count']:pLQXibtYgWrVGHjchkOqPDmTvNxSMn =pLQXibtYgWrVGHjchkOqPDmTvNxSJs(pLQXibtYgWrVGHjchkOqPDmTvNxSyB['cell_toplist']['count'])
   else:pLQXibtYgWrVGHjchkOqPDmTvNxSMn=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.LIST_LIMIT*page_int
   pLQXibtYgWrVGHjchkOqPDmTvNxSMd=pLQXibtYgWrVGHjchkOqPDmTvNxSMU>pLQXibtYgWrVGHjchkOqPDmTvNxSMn
  except pLQXibtYgWrVGHjchkOqPDmTvNxSJE as exception:
   pLQXibtYgWrVGHjchkOqPDmTvNxSFe(exception)
   return[],pLQXibtYgWrVGHjchkOqPDmTvNxSFz
  return pLQXibtYgWrVGHjchkOqPDmTvNxSMu,pLQXibtYgWrVGHjchkOqPDmTvNxSMd
 def Get_Program_List(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,pLQXibtYgWrVGHjchkOqPDmTvNxSyz,page_int=1,orderby='-'):
  pLQXibtYgWrVGHjchkOqPDmTvNxSMl=[]
  pLQXibtYgWrVGHjchkOqPDmTvNxSMU=pLQXibtYgWrVGHjchkOqPDmTvNxSMn=1
  pLQXibtYgWrVGHjchkOqPDmTvNxSMd=pLQXibtYgWrVGHjchkOqPDmTvNxSFz
  (pLQXibtYgWrVGHjchkOqPDmTvNxSyU,pLQXibtYgWrVGHjchkOqPDmTvNxSCK)=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.Baseapi_Parse(pLQXibtYgWrVGHjchkOqPDmTvNxSyz)
  if pLQXibtYgWrVGHjchkOqPDmTvNxSyU=='':return pLQXibtYgWrVGHjchkOqPDmTvNxSMl,pLQXibtYgWrVGHjchkOqPDmTvNxSMd
  try:
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK['limit'] =pLQXibtYgWrVGHjchkOqPDmTvNxSCw.LIST_LIMIT
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK['offset']=pLQXibtYgWrVGHjchkOqPDmTvNxSJC((page_int-1)*pLQXibtYgWrVGHjchkOqPDmTvNxSCw.LIST_LIMIT)
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK['page'] =pLQXibtYgWrVGHjchkOqPDmTvNxSJC(page_int)
   if pLQXibtYgWrVGHjchkOqPDmTvNxSCK.get('orderby')!='' and pLQXibtYgWrVGHjchkOqPDmTvNxSCK.get('orderby')!='regdatefirst' and orderby!='-':
    pLQXibtYgWrVGHjchkOqPDmTvNxSCK['orderby']=orderby 
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK.update(pLQXibtYgWrVGHjchkOqPDmTvNxSCw.GetDefaultParams(login=pLQXibtYgWrVGHjchkOqPDmTvNxSFz))
   pLQXibtYgWrVGHjchkOqPDmTvNxSyK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.callRequestCookies('Get',pLQXibtYgWrVGHjchkOqPDmTvNxSyU,payload=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,params=pLQXibtYgWrVGHjchkOqPDmTvNxSCK,headers=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,cookies=pLQXibtYgWrVGHjchkOqPDmTvNxSFf)
   pLQXibtYgWrVGHjchkOqPDmTvNxSyB=json.loads(pLQXibtYgWrVGHjchkOqPDmTvNxSyK.text)
   if pLQXibtYgWrVGHjchkOqPDmTvNxSyB.get('cell_toplist')not in[{},pLQXibtYgWrVGHjchkOqPDmTvNxSFf,'']:
    pLQXibtYgWrVGHjchkOqPDmTvNxSMC=pLQXibtYgWrVGHjchkOqPDmTvNxSyB['cell_toplist']['celllist']
   elif pLQXibtYgWrVGHjchkOqPDmTvNxSyB.get('band')not in[{},pLQXibtYgWrVGHjchkOqPDmTvNxSFf,'']:
    pLQXibtYgWrVGHjchkOqPDmTvNxSMC=pLQXibtYgWrVGHjchkOqPDmTvNxSyB['band']['celllist']
   else:
    return pLQXibtYgWrVGHjchkOqPDmTvNxSMl,pLQXibtYgWrVGHjchkOqPDmTvNxSMd
   for pLQXibtYgWrVGHjchkOqPDmTvNxSMy in pLQXibtYgWrVGHjchkOqPDmTvNxSMC:
    for pLQXibtYgWrVGHjchkOqPDmTvNxSMo in pLQXibtYgWrVGHjchkOqPDmTvNxSMy['event_list']:
     if pLQXibtYgWrVGHjchkOqPDmTvNxSMo.get('type')=='on-navigation':
      pLQXibtYgWrVGHjchkOqPDmTvNxSMK =pLQXibtYgWrVGHjchkOqPDmTvNxSMo['url']
    pLQXibtYgWrVGHjchkOqPDmTvNxSMB=urllib.parse.urlsplit(pLQXibtYgWrVGHjchkOqPDmTvNxSMK).query
    pLQXibtYgWrVGHjchkOqPDmTvNxSMA=pLQXibtYgWrVGHjchkOqPDmTvNxSMB[0:pLQXibtYgWrVGHjchkOqPDmTvNxSMB.find('=')]
    pLQXibtYgWrVGHjchkOqPDmTvNxSMf=pLQXibtYgWrVGHjchkOqPDmTvNxSJF(urllib.parse.parse_qsl(pLQXibtYgWrVGHjchkOqPDmTvNxSMB))
    pLQXibtYgWrVGHjchkOqPDmTvNxSMR=pLQXibtYgWrVGHjchkOqPDmTvNxSMf.get(pLQXibtYgWrVGHjchkOqPDmTvNxSMA)
    pLQXibtYgWrVGHjchkOqPDmTvNxSMw={'title':pLQXibtYgWrVGHjchkOqPDmTvNxSMy.get('alt')or pLQXibtYgWrVGHjchkOqPDmTvNxSMy.get('title_list')[0].get('text'),'age':pLQXibtYgWrVGHjchkOqPDmTvNxSMy.get('age'),'thumbnail':pLQXibtYgWrVGHjchkOqPDmTvNxSMy.get('thumbnail'),'videoid':pLQXibtYgWrVGHjchkOqPDmTvNxSMR,'vidtype':pLQXibtYgWrVGHjchkOqPDmTvNxSMA,}
    if not pLQXibtYgWrVGHjchkOqPDmTvNxSMw.get('thumbnail').startswith('http'):
     pLQXibtYgWrVGHjchkOqPDmTvNxSMw['thumbnail']='https://%s'%pLQXibtYgWrVGHjchkOqPDmTvNxSMw['thumbnail']
    pLQXibtYgWrVGHjchkOqPDmTvNxSMl.append(pLQXibtYgWrVGHjchkOqPDmTvNxSMw)
   if pLQXibtYgWrVGHjchkOqPDmTvNxSyB.get('cell_toplist')not in[{},pLQXibtYgWrVGHjchkOqPDmTvNxSFf,'']:
    pLQXibtYgWrVGHjchkOqPDmTvNxSMU=pLQXibtYgWrVGHjchkOqPDmTvNxSJs(pLQXibtYgWrVGHjchkOqPDmTvNxSyB['cell_toplist']['pagecount'])
    if pLQXibtYgWrVGHjchkOqPDmTvNxSyB['cell_toplist']['count']:pLQXibtYgWrVGHjchkOqPDmTvNxSMn =pLQXibtYgWrVGHjchkOqPDmTvNxSJs(pLQXibtYgWrVGHjchkOqPDmTvNxSyB['cell_toplist']['count'])
    else:pLQXibtYgWrVGHjchkOqPDmTvNxSMn=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.LIST_LIMIT*page_int
    pLQXibtYgWrVGHjchkOqPDmTvNxSMd=pLQXibtYgWrVGHjchkOqPDmTvNxSMU>pLQXibtYgWrVGHjchkOqPDmTvNxSMn
  except pLQXibtYgWrVGHjchkOqPDmTvNxSJE as exception:
   pLQXibtYgWrVGHjchkOqPDmTvNxSFe(exception)
   return[],pLQXibtYgWrVGHjchkOqPDmTvNxSFz
  return pLQXibtYgWrVGHjchkOqPDmTvNxSMl,pLQXibtYgWrVGHjchkOqPDmTvNxSMd
 def Get_Movie_List(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,pLQXibtYgWrVGHjchkOqPDmTvNxSyz,page_int=1,orderby='-'):
  pLQXibtYgWrVGHjchkOqPDmTvNxSMz=[]
  pLQXibtYgWrVGHjchkOqPDmTvNxSMU=pLQXibtYgWrVGHjchkOqPDmTvNxSMn=1
  pLQXibtYgWrVGHjchkOqPDmTvNxSMd=pLQXibtYgWrVGHjchkOqPDmTvNxSFz
  (pLQXibtYgWrVGHjchkOqPDmTvNxSyU,pLQXibtYgWrVGHjchkOqPDmTvNxSCK)=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.Baseapi_Parse(pLQXibtYgWrVGHjchkOqPDmTvNxSyz)
  if pLQXibtYgWrVGHjchkOqPDmTvNxSyU=='':return pLQXibtYgWrVGHjchkOqPDmTvNxSMz,pLQXibtYgWrVGHjchkOqPDmTvNxSMd
  try:
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK['limit']=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.MV_LIMIT
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK['offset']=pLQXibtYgWrVGHjchkOqPDmTvNxSJC((page_int-1)*pLQXibtYgWrVGHjchkOqPDmTvNxSCw.MV_LIMIT)
   if pLQXibtYgWrVGHjchkOqPDmTvNxSCK.get('orderby')!='' and pLQXibtYgWrVGHjchkOqPDmTvNxSCK.get('orderby')!='regdatefirst' and orderby!='-':
    pLQXibtYgWrVGHjchkOqPDmTvNxSCK['orderby']=orderby 
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK.update(pLQXibtYgWrVGHjchkOqPDmTvNxSCw.GetDefaultParams(login=pLQXibtYgWrVGHjchkOqPDmTvNxSFz))
   pLQXibtYgWrVGHjchkOqPDmTvNxSyK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.callRequestCookies('Get',pLQXibtYgWrVGHjchkOqPDmTvNxSyU,payload=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,params=pLQXibtYgWrVGHjchkOqPDmTvNxSCK,headers=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,cookies=pLQXibtYgWrVGHjchkOqPDmTvNxSFf)
   pLQXibtYgWrVGHjchkOqPDmTvNxSyB=json.loads(pLQXibtYgWrVGHjchkOqPDmTvNxSyK.text)
   if pLQXibtYgWrVGHjchkOqPDmTvNxSyB.get('cell_toplist')not in[{},pLQXibtYgWrVGHjchkOqPDmTvNxSFf,'']:
    pLQXibtYgWrVGHjchkOqPDmTvNxSMC=pLQXibtYgWrVGHjchkOqPDmTvNxSyB['cell_toplist']['celllist']
   elif pLQXibtYgWrVGHjchkOqPDmTvNxSyB.get('band')not in[{},pLQXibtYgWrVGHjchkOqPDmTvNxSFf,'']:
    pLQXibtYgWrVGHjchkOqPDmTvNxSMC=pLQXibtYgWrVGHjchkOqPDmTvNxSyB['band']['celllist']
   else:
    return pLQXibtYgWrVGHjchkOqPDmTvNxSMz,pLQXibtYgWrVGHjchkOqPDmTvNxSMd
   for pLQXibtYgWrVGHjchkOqPDmTvNxSMy in pLQXibtYgWrVGHjchkOqPDmTvNxSMC:
    pLQXibtYgWrVGHjchkOqPDmTvNxSMK =pLQXibtYgWrVGHjchkOqPDmTvNxSMy['event_list'][1]['url']
    pLQXibtYgWrVGHjchkOqPDmTvNxSMB=urllib.parse.urlsplit(pLQXibtYgWrVGHjchkOqPDmTvNxSMK).query
    pLQXibtYgWrVGHjchkOqPDmTvNxSMA=pLQXibtYgWrVGHjchkOqPDmTvNxSMB[0:pLQXibtYgWrVGHjchkOqPDmTvNxSMB.find('=')]
    pLQXibtYgWrVGHjchkOqPDmTvNxSMf=pLQXibtYgWrVGHjchkOqPDmTvNxSJF(urllib.parse.parse_qsl(pLQXibtYgWrVGHjchkOqPDmTvNxSMB))
    pLQXibtYgWrVGHjchkOqPDmTvNxSMR=pLQXibtYgWrVGHjchkOqPDmTvNxSMf.get(pLQXibtYgWrVGHjchkOqPDmTvNxSMA)
    pLQXibtYgWrVGHjchkOqPDmTvNxSMw={'title':pLQXibtYgWrVGHjchkOqPDmTvNxSMy.get('alt')or pLQXibtYgWrVGHjchkOqPDmTvNxSMy.get('title_list')[0].get('text'),'age':pLQXibtYgWrVGHjchkOqPDmTvNxSMy.get('age'),'thumbnail':pLQXibtYgWrVGHjchkOqPDmTvNxSMy.get('thumbnail'),'videoid':pLQXibtYgWrVGHjchkOqPDmTvNxSMR,'vidtype':pLQXibtYgWrVGHjchkOqPDmTvNxSMA,}
    if not pLQXibtYgWrVGHjchkOqPDmTvNxSMw.get('thumbnail').startswith('http'):
     pLQXibtYgWrVGHjchkOqPDmTvNxSMw['thumbnail']='https://%s'%pLQXibtYgWrVGHjchkOqPDmTvNxSMw['thumbnail']
    pLQXibtYgWrVGHjchkOqPDmTvNxSMz.append(pLQXibtYgWrVGHjchkOqPDmTvNxSMw)
   if pLQXibtYgWrVGHjchkOqPDmTvNxSyB.get('cell_toplist')not in[{},pLQXibtYgWrVGHjchkOqPDmTvNxSFf,'']:
    pLQXibtYgWrVGHjchkOqPDmTvNxSMU=pLQXibtYgWrVGHjchkOqPDmTvNxSJs(pLQXibtYgWrVGHjchkOqPDmTvNxSyB['cell_toplist']['pagecount'])
    if pLQXibtYgWrVGHjchkOqPDmTvNxSyB['cell_toplist']['count']:pLQXibtYgWrVGHjchkOqPDmTvNxSMn =pLQXibtYgWrVGHjchkOqPDmTvNxSJs(pLQXibtYgWrVGHjchkOqPDmTvNxSyB['cell_toplist']['count'])
    else:pLQXibtYgWrVGHjchkOqPDmTvNxSMn=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.MV_LIMIT*page_int
    pLQXibtYgWrVGHjchkOqPDmTvNxSMd=pLQXibtYgWrVGHjchkOqPDmTvNxSMU>pLQXibtYgWrVGHjchkOqPDmTvNxSMn
  except pLQXibtYgWrVGHjchkOqPDmTvNxSJE as exception:
   pLQXibtYgWrVGHjchkOqPDmTvNxSFe(exception)
   return[],pLQXibtYgWrVGHjchkOqPDmTvNxSFz
  return pLQXibtYgWrVGHjchkOqPDmTvNxSMz,pLQXibtYgWrVGHjchkOqPDmTvNxSMd
 def ProgramidToContentid(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,pLQXibtYgWrVGHjchkOqPDmTvNxSwy):
  pLQXibtYgWrVGHjchkOqPDmTvNxSMe=''
  try:
   pLQXibtYgWrVGHjchkOqPDmTvNxSyU =pLQXibtYgWrVGHjchkOqPDmTvNxSCw.API_DOMAIN+'/vod/programs-contentid/'+pLQXibtYgWrVGHjchkOqPDmTvNxSwy
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.GetDefaultParams(login=pLQXibtYgWrVGHjchkOqPDmTvNxSFz)
   pLQXibtYgWrVGHjchkOqPDmTvNxSyK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.callRequestCookies('Get',pLQXibtYgWrVGHjchkOqPDmTvNxSyU,payload=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,params=pLQXibtYgWrVGHjchkOqPDmTvNxSCK,headers=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,cookies=pLQXibtYgWrVGHjchkOqPDmTvNxSFf)
   pLQXibtYgWrVGHjchkOqPDmTvNxSwC=json.loads(pLQXibtYgWrVGHjchkOqPDmTvNxSyK.text)
   if not('contentid' in pLQXibtYgWrVGHjchkOqPDmTvNxSwC):return pLQXibtYgWrVGHjchkOqPDmTvNxSMe 
   pLQXibtYgWrVGHjchkOqPDmTvNxSMe=pLQXibtYgWrVGHjchkOqPDmTvNxSwC['contentid']
  except pLQXibtYgWrVGHjchkOqPDmTvNxSJE as exception:
   pLQXibtYgWrVGHjchkOqPDmTvNxSFe(exception)
  return pLQXibtYgWrVGHjchkOqPDmTvNxSMe
 def ContentidToSeasonid(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,pLQXibtYgWrVGHjchkOqPDmTvNxSMe):
  pLQXibtYgWrVGHjchkOqPDmTvNxSwy=''
  try:
   pLQXibtYgWrVGHjchkOqPDmTvNxSyU =pLQXibtYgWrVGHjchkOqPDmTvNxSCw.API_DOMAIN+'/fz/vod/contents/'+pLQXibtYgWrVGHjchkOqPDmTvNxSMe
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.GetDefaultParams(login=pLQXibtYgWrVGHjchkOqPDmTvNxSFz)
   pLQXibtYgWrVGHjchkOqPDmTvNxSyK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.callRequestCookies('Get',pLQXibtYgWrVGHjchkOqPDmTvNxSyU,payload=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,params=pLQXibtYgWrVGHjchkOqPDmTvNxSCK,headers=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,cookies=pLQXibtYgWrVGHjchkOqPDmTvNxSFf)
   pLQXibtYgWrVGHjchkOqPDmTvNxSwC=json.loads(pLQXibtYgWrVGHjchkOqPDmTvNxSyK.text)
   if not('programid' in pLQXibtYgWrVGHjchkOqPDmTvNxSwC):return pLQXibtYgWrVGHjchkOqPDmTvNxSwy 
   pLQXibtYgWrVGHjchkOqPDmTvNxSwy=pLQXibtYgWrVGHjchkOqPDmTvNxSwC['programid']
  except pLQXibtYgWrVGHjchkOqPDmTvNxSJE as exception:
   pLQXibtYgWrVGHjchkOqPDmTvNxSFe(exception)
  return pLQXibtYgWrVGHjchkOqPDmTvNxSwy
 def GetProgramInfo(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,pLQXibtYgWrVGHjchkOqPDmTvNxSMe):
  pLQXibtYgWrVGHjchkOqPDmTvNxSwM={}
  try:
   pLQXibtYgWrVGHjchkOqPDmTvNxSyU=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.API_DOMAIN+'/fz/vod/contents/'+pLQXibtYgWrVGHjchkOqPDmTvNxSMe
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.GetDefaultParams(login=pLQXibtYgWrVGHjchkOqPDmTvNxSFz)
   pLQXibtYgWrVGHjchkOqPDmTvNxSyK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.callRequestCookies('Get',pLQXibtYgWrVGHjchkOqPDmTvNxSyU,payload=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,params=pLQXibtYgWrVGHjchkOqPDmTvNxSCK,headers=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,cookies=pLQXibtYgWrVGHjchkOqPDmTvNxSFf)
   pLQXibtYgWrVGHjchkOqPDmTvNxSwC=json.loads(pLQXibtYgWrVGHjchkOqPDmTvNxSyK.text)
   pLQXibtYgWrVGHjchkOqPDmTvNxSwa=img_fanart=pLQXibtYgWrVGHjchkOqPDmTvNxSwE=''
   if pLQXibtYgWrVGHjchkOqPDmTvNxSwC.get('programposterimage')!='':pLQXibtYgWrVGHjchkOqPDmTvNxSwa =pLQXibtYgWrVGHjchkOqPDmTvNxSCw.HTTPTAG+pLQXibtYgWrVGHjchkOqPDmTvNxSwC.get('programposterimage')
   if pLQXibtYgWrVGHjchkOqPDmTvNxSwC.get('programimage') !='':img_fanart =pLQXibtYgWrVGHjchkOqPDmTvNxSCw.HTTPTAG+pLQXibtYgWrVGHjchkOqPDmTvNxSwC.get('programimage')
   if pLQXibtYgWrVGHjchkOqPDmTvNxSwC.get('programcircleimage')!='':pLQXibtYgWrVGHjchkOqPDmTvNxSwE=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.HTTPTAG+pLQXibtYgWrVGHjchkOqPDmTvNxSwC.get('programcircleimage')
   if 'poster_default' in pLQXibtYgWrVGHjchkOqPDmTvNxSwa:
    pLQXibtYgWrVGHjchkOqPDmTvNxSwa =img_fanart
    pLQXibtYgWrVGHjchkOqPDmTvNxSwE=''
   pLQXibtYgWrVGHjchkOqPDmTvNxSwM={'imgPoster':pLQXibtYgWrVGHjchkOqPDmTvNxSwa,'imgFanart':img_fanart,'imgClearlogo':pLQXibtYgWrVGHjchkOqPDmTvNxSwE,'programtitle':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.Get_ChangeText(pLQXibtYgWrVGHjchkOqPDmTvNxSwC.get('programtitle')),'programid':pLQXibtYgWrVGHjchkOqPDmTvNxSwC.get('programid'),'synopsis':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.Get_ChangeText(pLQXibtYgWrVGHjchkOqPDmTvNxSwC.get('programsynopsis')),}
  except pLQXibtYgWrVGHjchkOqPDmTvNxSJE as exception:
   pLQXibtYgWrVGHjchkOqPDmTvNxSFe(exception)
  return pLQXibtYgWrVGHjchkOqPDmTvNxSwM
 def Get_Season_List(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,seasonid):
  pLQXibtYgWrVGHjchkOqPDmTvNxSwF=[]
  pLQXibtYgWrVGHjchkOqPDmTvNxSMe=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.ProgramidToContentid(seasonid)
  pLQXibtYgWrVGHjchkOqPDmTvNxSwJ=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.GetProgramInfo(pLQXibtYgWrVGHjchkOqPDmTvNxSMe)
  pLQXibtYgWrVGHjchkOqPDmTvNxSws={'poster':pLQXibtYgWrVGHjchkOqPDmTvNxSwJ.get('imgPoster'),'fanart':pLQXibtYgWrVGHjchkOqPDmTvNxSwJ.get('imgFanart'),'clearlogo':pLQXibtYgWrVGHjchkOqPDmTvNxSwJ.get('imgClearlogo'),}
  try:
   pLQXibtYgWrVGHjchkOqPDmTvNxSyU=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.API_DOMAIN+'/fz/vod/programs-contents/'+seasonid
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK={'limit':'10','offset':'0','orderby':'new',}
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK.update(pLQXibtYgWrVGHjchkOqPDmTvNxSCw.GetDefaultParams(login=pLQXibtYgWrVGHjchkOqPDmTvNxSFz))
   pLQXibtYgWrVGHjchkOqPDmTvNxSyK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.callRequestCookies('Get',pLQXibtYgWrVGHjchkOqPDmTvNxSyU,payload=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,params=pLQXibtYgWrVGHjchkOqPDmTvNxSCK,headers=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,cookies=pLQXibtYgWrVGHjchkOqPDmTvNxSFf)
   pLQXibtYgWrVGHjchkOqPDmTvNxSyB=json.loads(pLQXibtYgWrVGHjchkOqPDmTvNxSyK.text)
   for pLQXibtYgWrVGHjchkOqPDmTvNxSwI in pLQXibtYgWrVGHjchkOqPDmTvNxSyB['filter']['filterlist'][0]['filter_item_list']:
    pLQXibtYgWrVGHjchkOqPDmTvNxSMw={'season_Nm':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.Get_ChangeText(pLQXibtYgWrVGHjchkOqPDmTvNxSwI.get('title')),'season_Id':pLQXibtYgWrVGHjchkOqPDmTvNxSwI.get('api_path'),'thumbnail':pLQXibtYgWrVGHjchkOqPDmTvNxSws,'programNm':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.Get_ChangeText(pLQXibtYgWrVGHjchkOqPDmTvNxSwJ.get('programtitle')),'synopsis':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.Get_ChangeText(pLQXibtYgWrVGHjchkOqPDmTvNxSwJ.get('synopsis')),}
    pLQXibtYgWrVGHjchkOqPDmTvNxSwF.append(pLQXibtYgWrVGHjchkOqPDmTvNxSMw)
  except pLQXibtYgWrVGHjchkOqPDmTvNxSJE as exception:
   pLQXibtYgWrVGHjchkOqPDmTvNxSFe(exception)
   return[]
  return pLQXibtYgWrVGHjchkOqPDmTvNxSwF
 def Get_Episode_List(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,seasionid,page_int=1,orderby='desc'):
  pLQXibtYgWrVGHjchkOqPDmTvNxSwU=[]
  pLQXibtYgWrVGHjchkOqPDmTvNxSMU=pLQXibtYgWrVGHjchkOqPDmTvNxSMn=1
  pLQXibtYgWrVGHjchkOqPDmTvNxSMd=pLQXibtYgWrVGHjchkOqPDmTvNxSFz
  pLQXibtYgWrVGHjchkOqPDmTvNxSwJ={}
  pLQXibtYgWrVGHjchkOqPDmTvNxSMe=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.ProgramidToContentid(seasionid)
  pLQXibtYgWrVGHjchkOqPDmTvNxSwJ=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.GetProgramInfo(pLQXibtYgWrVGHjchkOqPDmTvNxSMe)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   pLQXibtYgWrVGHjchkOqPDmTvNxSyU=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.API_DOMAIN+'/fz/vod/programs-contents/'+seasionid
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK={'limit':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.EP_LIMIT,'offset':pLQXibtYgWrVGHjchkOqPDmTvNxSJC((page_int-1)*pLQXibtYgWrVGHjchkOqPDmTvNxSCw.EP_LIMIT),'orderby':orderby,}
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK.update(pLQXibtYgWrVGHjchkOqPDmTvNxSCw.GetDefaultParams(login=pLQXibtYgWrVGHjchkOqPDmTvNxSFz))
   pLQXibtYgWrVGHjchkOqPDmTvNxSyK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.callRequestCookies('Get',pLQXibtYgWrVGHjchkOqPDmTvNxSyU,payload=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,params=pLQXibtYgWrVGHjchkOqPDmTvNxSCK,headers=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,cookies=pLQXibtYgWrVGHjchkOqPDmTvNxSFf)
   pLQXibtYgWrVGHjchkOqPDmTvNxSyB=json.loads(pLQXibtYgWrVGHjchkOqPDmTvNxSyK.text)
   pLQXibtYgWrVGHjchkOqPDmTvNxSMC=pLQXibtYgWrVGHjchkOqPDmTvNxSyB['cell_toplist']['celllist']
   for pLQXibtYgWrVGHjchkOqPDmTvNxSMy in pLQXibtYgWrVGHjchkOqPDmTvNxSMC:
    pLQXibtYgWrVGHjchkOqPDmTvNxSwK=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',pLQXibtYgWrVGHjchkOqPDmTvNxSMy.get('synopsis'))
    pLQXibtYgWrVGHjchkOqPDmTvNxSwB=pLQXibtYgWrVGHjchkOqPDmTvNxSMy.get('thumbnail')
    if not pLQXibtYgWrVGHjchkOqPDmTvNxSwB.startswith('http'):
     pLQXibtYgWrVGHjchkOqPDmTvNxSwB=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.HTTPTAG+pLQXibtYgWrVGHjchkOqPDmTvNxSwB
    pLQXibtYgWrVGHjchkOqPDmTvNxSwA=pLQXibtYgWrVGHjchkOqPDmTvNxSwR=pLQXibtYgWrVGHjchkOqPDmTvNxSwn=''
    pLQXibtYgWrVGHjchkOqPDmTvNxSwA =pLQXibtYgWrVGHjchkOqPDmTvNxSwJ.get('imgPoster')
    pLQXibtYgWrVGHjchkOqPDmTvNxSwR =pLQXibtYgWrVGHjchkOqPDmTvNxSwJ.get('imgFanart')
    pLQXibtYgWrVGHjchkOqPDmTvNxSwn =pLQXibtYgWrVGHjchkOqPDmTvNxSwJ.get('imgClearlogo')
    pLQXibtYgWrVGHjchkOqPDmTvNxSwu=pLQXibtYgWrVGHjchkOqPDmTvNxSwJ.get('programtitle')
    pLQXibtYgWrVGHjchkOqPDmTvNxSws={'thumb':pLQXibtYgWrVGHjchkOqPDmTvNxSwB,'poster':pLQXibtYgWrVGHjchkOqPDmTvNxSwA,'fanart':pLQXibtYgWrVGHjchkOqPDmTvNxSwR,'clearlogo':pLQXibtYgWrVGHjchkOqPDmTvNxSwn}
    pLQXibtYgWrVGHjchkOqPDmTvNxSMw={'programtitle':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.Get_ChangeText(pLQXibtYgWrVGHjchkOqPDmTvNxSwu),'episodetitle':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.Get_ChangeText(pLQXibtYgWrVGHjchkOqPDmTvNxSMy['title_list'][0]['text']),'episodenumber':pLQXibtYgWrVGHjchkOqPDmTvNxSMy['title_list'][1]['text'].replace('$O$',''),'contentid':pLQXibtYgWrVGHjchkOqPDmTvNxSMy['contentid'],'synopsis':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.Get_ChangeText(pLQXibtYgWrVGHjchkOqPDmTvNxSwK),'episodeactors':pLQXibtYgWrVGHjchkOqPDmTvNxSMy.get('actors').split(',')if pLQXibtYgWrVGHjchkOqPDmTvNxSMy.get('actors')!='' else[],'thumbnail':pLQXibtYgWrVGHjchkOqPDmTvNxSws,}
    pLQXibtYgWrVGHjchkOqPDmTvNxSwU.append(pLQXibtYgWrVGHjchkOqPDmTvNxSMw)
   pLQXibtYgWrVGHjchkOqPDmTvNxSMU=pLQXibtYgWrVGHjchkOqPDmTvNxSJs(pLQXibtYgWrVGHjchkOqPDmTvNxSyB['cell_toplist']['pagecount'])
   if pLQXibtYgWrVGHjchkOqPDmTvNxSyB['cell_toplist']['count']:pLQXibtYgWrVGHjchkOqPDmTvNxSMn =pLQXibtYgWrVGHjchkOqPDmTvNxSJs(pLQXibtYgWrVGHjchkOqPDmTvNxSyB['cell_toplist']['count'])
   else:pLQXibtYgWrVGHjchkOqPDmTvNxSMn=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.EP_LIMIT*page_int
   pLQXibtYgWrVGHjchkOqPDmTvNxSMd=pLQXibtYgWrVGHjchkOqPDmTvNxSMU>pLQXibtYgWrVGHjchkOqPDmTvNxSMn
  except pLQXibtYgWrVGHjchkOqPDmTvNxSJE as exception:
   pLQXibtYgWrVGHjchkOqPDmTvNxSFe(exception)
   return[],pLQXibtYgWrVGHjchkOqPDmTvNxSFz
  return pLQXibtYgWrVGHjchkOqPDmTvNxSwU,pLQXibtYgWrVGHjchkOqPDmTvNxSMd
 def GetEPGList(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,genre):
  pLQXibtYgWrVGHjchkOqPDmTvNxSwl={}
  try:
   pLQXibtYgWrVGHjchkOqPDmTvNxSwo=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.Get_Now_Datetime()
   if genre=='all':
    pLQXibtYgWrVGHjchkOqPDmTvNxSwf =pLQXibtYgWrVGHjchkOqPDmTvNxSwo+datetime.timedelta(hours=3)
   else:
    pLQXibtYgWrVGHjchkOqPDmTvNxSwf =pLQXibtYgWrVGHjchkOqPDmTvNxSwo+datetime.timedelta(hours=3)
   pLQXibtYgWrVGHjchkOqPDmTvNxSyU=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.API_DOMAIN+'/live/epgs'
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK={'limit':'100','offset':'0','genre':genre,'startdatetime':pLQXibtYgWrVGHjchkOqPDmTvNxSwo.strftime('%Y-%m-%d %H:00'),'enddatetime':pLQXibtYgWrVGHjchkOqPDmTvNxSwf.strftime('%Y-%m-%d %H:00')}
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK.update(pLQXibtYgWrVGHjchkOqPDmTvNxSCw.GetDefaultParams(login=pLQXibtYgWrVGHjchkOqPDmTvNxSFz))
   pLQXibtYgWrVGHjchkOqPDmTvNxSyK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.callRequestCookies('Get',pLQXibtYgWrVGHjchkOqPDmTvNxSyU,payload=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,params=pLQXibtYgWrVGHjchkOqPDmTvNxSCK,headers=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,cookies=pLQXibtYgWrVGHjchkOqPDmTvNxSFf)
   pLQXibtYgWrVGHjchkOqPDmTvNxSyB=json.loads(pLQXibtYgWrVGHjchkOqPDmTvNxSyK.text)
   pLQXibtYgWrVGHjchkOqPDmTvNxSwz=pLQXibtYgWrVGHjchkOqPDmTvNxSyB['list']
   for pLQXibtYgWrVGHjchkOqPDmTvNxSMy in pLQXibtYgWrVGHjchkOqPDmTvNxSwz:
    pLQXibtYgWrVGHjchkOqPDmTvNxSwe=''
    for pLQXibtYgWrVGHjchkOqPDmTvNxSaC in pLQXibtYgWrVGHjchkOqPDmTvNxSMy['list']:
     if pLQXibtYgWrVGHjchkOqPDmTvNxSwe:pLQXibtYgWrVGHjchkOqPDmTvNxSwe+='\n'
     pLQXibtYgWrVGHjchkOqPDmTvNxSwe+=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.Get_ChangeText(pLQXibtYgWrVGHjchkOqPDmTvNxSaC['title'])+'\n'
     pLQXibtYgWrVGHjchkOqPDmTvNxSwe+=' [%s ~ %s]'%(pLQXibtYgWrVGHjchkOqPDmTvNxSaC['starttime'][-5:],pLQXibtYgWrVGHjchkOqPDmTvNxSaC['endtime'][-5:])+'\n'
    pLQXibtYgWrVGHjchkOqPDmTvNxSwl[pLQXibtYgWrVGHjchkOqPDmTvNxSMy['channelid']]=pLQXibtYgWrVGHjchkOqPDmTvNxSwe
  except pLQXibtYgWrVGHjchkOqPDmTvNxSJE as exception:
   pLQXibtYgWrVGHjchkOqPDmTvNxSFe(exception)
  return pLQXibtYgWrVGHjchkOqPDmTvNxSwl
 def Get_LiveChannel_List(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,genre,pLQXibtYgWrVGHjchkOqPDmTvNxSyz):
  pLQXibtYgWrVGHjchkOqPDmTvNxSMI=[]
  (pLQXibtYgWrVGHjchkOqPDmTvNxSyU,pLQXibtYgWrVGHjchkOqPDmTvNxSCK)=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.Baseapi_Parse(pLQXibtYgWrVGHjchkOqPDmTvNxSyz)
  if pLQXibtYgWrVGHjchkOqPDmTvNxSyU=='':return pLQXibtYgWrVGHjchkOqPDmTvNxSMI
  pLQXibtYgWrVGHjchkOqPDmTvNxSay=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.GetEPGList(genre)
  try:
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK.update(pLQXibtYgWrVGHjchkOqPDmTvNxSCw.GetDefaultParams(login=pLQXibtYgWrVGHjchkOqPDmTvNxSFz))
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK['genre']=genre
   pLQXibtYgWrVGHjchkOqPDmTvNxSyK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.callRequestCookies('Get',pLQXibtYgWrVGHjchkOqPDmTvNxSyU,payload=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,params=pLQXibtYgWrVGHjchkOqPDmTvNxSCK,headers=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,cookies=pLQXibtYgWrVGHjchkOqPDmTvNxSFf)
   pLQXibtYgWrVGHjchkOqPDmTvNxSyB=json.loads(pLQXibtYgWrVGHjchkOqPDmTvNxSyK.text)
   if not('celllist' in pLQXibtYgWrVGHjchkOqPDmTvNxSyB['cell_toplist']):return[]
   pLQXibtYgWrVGHjchkOqPDmTvNxSMC=pLQXibtYgWrVGHjchkOqPDmTvNxSyB['cell_toplist']['celllist']
   for pLQXibtYgWrVGHjchkOqPDmTvNxSMy in pLQXibtYgWrVGHjchkOqPDmTvNxSMC:
    pLQXibtYgWrVGHjchkOqPDmTvNxSMe=pLQXibtYgWrVGHjchkOqPDmTvNxSMy['contentid']
    if pLQXibtYgWrVGHjchkOqPDmTvNxSMe in pLQXibtYgWrVGHjchkOqPDmTvNxSay:
     pLQXibtYgWrVGHjchkOqPDmTvNxSaM=pLQXibtYgWrVGHjchkOqPDmTvNxSay[pLQXibtYgWrVGHjchkOqPDmTvNxSMe]
    else:
     pLQXibtYgWrVGHjchkOqPDmTvNxSaM=''
    pLQXibtYgWrVGHjchkOqPDmTvNxSMw={'studio':pLQXibtYgWrVGHjchkOqPDmTvNxSMy['title_list'][0]['text'],'tvshowtitle':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.Get_ChangeText(pLQXibtYgWrVGHjchkOqPDmTvNxSMy['title_list'][1]['text']),'channelid':pLQXibtYgWrVGHjchkOqPDmTvNxSMe,'age':pLQXibtYgWrVGHjchkOqPDmTvNxSMy['age'],'thumbnail':'https://%s'%pLQXibtYgWrVGHjchkOqPDmTvNxSMy.get('thumbnail'),'epg':pLQXibtYgWrVGHjchkOqPDmTvNxSaM}
    pLQXibtYgWrVGHjchkOqPDmTvNxSMI.append(pLQXibtYgWrVGHjchkOqPDmTvNxSMw)
  except pLQXibtYgWrVGHjchkOqPDmTvNxSJE as exception:
   pLQXibtYgWrVGHjchkOqPDmTvNxSFe(exception)
   return[]
  return pLQXibtYgWrVGHjchkOqPDmTvNxSMI
 def Get_Search_List(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,search_key,sType,page_int,exclusion21=pLQXibtYgWrVGHjchkOqPDmTvNxSFz):
  pLQXibtYgWrVGHjchkOqPDmTvNxSaw=[]
  pLQXibtYgWrVGHjchkOqPDmTvNxSMU=pLQXibtYgWrVGHjchkOqPDmTvNxSMn=1
  pLQXibtYgWrVGHjchkOqPDmTvNxSMd=pLQXibtYgWrVGHjchkOqPDmTvNxSFz
  try:
   pLQXibtYgWrVGHjchkOqPDmTvNxSyU=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.API_DOMAIN+'/fz/search/band.js'
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':pLQXibtYgWrVGHjchkOqPDmTvNxSJC((page_int-1)*pLQXibtYgWrVGHjchkOqPDmTvNxSCw.SEARCH_LIMIT),'limit':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.SEARCH_LIMIT,'orderby':'score','mtype':'svod',}
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK.update(pLQXibtYgWrVGHjchkOqPDmTvNxSCw.GetDefaultParams(login=pLQXibtYgWrVGHjchkOqPDmTvNxSFz))
   pLQXibtYgWrVGHjchkOqPDmTvNxSyK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.callRequestCookies('Get',pLQXibtYgWrVGHjchkOqPDmTvNxSyU,payload=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,params=pLQXibtYgWrVGHjchkOqPDmTvNxSCK,headers=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,cookies=pLQXibtYgWrVGHjchkOqPDmTvNxSFf)
   pLQXibtYgWrVGHjchkOqPDmTvNxSwC=json.loads(pLQXibtYgWrVGHjchkOqPDmTvNxSyK.text)
   if not('celllist' in pLQXibtYgWrVGHjchkOqPDmTvNxSwC['band']):return pLQXibtYgWrVGHjchkOqPDmTvNxSaw,pLQXibtYgWrVGHjchkOqPDmTvNxSMd
   pLQXibtYgWrVGHjchkOqPDmTvNxSMC=pLQXibtYgWrVGHjchkOqPDmTvNxSwC['band']['celllist']
   for pLQXibtYgWrVGHjchkOqPDmTvNxSMy in pLQXibtYgWrVGHjchkOqPDmTvNxSMC:
    pLQXibtYgWrVGHjchkOqPDmTvNxSMK =pLQXibtYgWrVGHjchkOqPDmTvNxSMy['event_list'][1]['url']
    pLQXibtYgWrVGHjchkOqPDmTvNxSMB=urllib.parse.urlsplit(pLQXibtYgWrVGHjchkOqPDmTvNxSMK).query
    pLQXibtYgWrVGHjchkOqPDmTvNxSMA=pLQXibtYgWrVGHjchkOqPDmTvNxSMB[0:pLQXibtYgWrVGHjchkOqPDmTvNxSMB.find('=')]
    pLQXibtYgWrVGHjchkOqPDmTvNxSMf=pLQXibtYgWrVGHjchkOqPDmTvNxSJF(urllib.parse.parse_qsl(pLQXibtYgWrVGHjchkOqPDmTvNxSMB))
    pLQXibtYgWrVGHjchkOqPDmTvNxSMR=pLQXibtYgWrVGHjchkOqPDmTvNxSMf.get(pLQXibtYgWrVGHjchkOqPDmTvNxSMA)
    pLQXibtYgWrVGHjchkOqPDmTvNxSMw={'title':pLQXibtYgWrVGHjchkOqPDmTvNxSMy['title_list'][0]['text'],'age':pLQXibtYgWrVGHjchkOqPDmTvNxSMy['age'],'thumbnail':'https://%s'%pLQXibtYgWrVGHjchkOqPDmTvNxSMy.get('thumbnail'),'videoid':pLQXibtYgWrVGHjchkOqPDmTvNxSMR,'vidtype':pLQXibtYgWrVGHjchkOqPDmTvNxSMA,}
    pLQXibtYgWrVGHjchkOqPDmTvNxSaE=pLQXibtYgWrVGHjchkOqPDmTvNxSFz
    for pLQXibtYgWrVGHjchkOqPDmTvNxSaF in pLQXibtYgWrVGHjchkOqPDmTvNxSMy['bottom_taglist']:
     if pLQXibtYgWrVGHjchkOqPDmTvNxSaF=='won':
      pLQXibtYgWrVGHjchkOqPDmTvNxSaE=pLQXibtYgWrVGHjchkOqPDmTvNxSJM
      break
    if pLQXibtYgWrVGHjchkOqPDmTvNxSaE==pLQXibtYgWrVGHjchkOqPDmTvNxSJM: 
     pLQXibtYgWrVGHjchkOqPDmTvNxSMw['title']=pLQXibtYgWrVGHjchkOqPDmTvNxSMw['title']+' [개별구매]'
    if exclusion21==pLQXibtYgWrVGHjchkOqPDmTvNxSFz or pLQXibtYgWrVGHjchkOqPDmTvNxSMy.get('age')!='21':
     pLQXibtYgWrVGHjchkOqPDmTvNxSaw.append(pLQXibtYgWrVGHjchkOqPDmTvNxSMw)
   pLQXibtYgWrVGHjchkOqPDmTvNxSMU=pLQXibtYgWrVGHjchkOqPDmTvNxSJs(pLQXibtYgWrVGHjchkOqPDmTvNxSwC['band']['pagecount'])
   if pLQXibtYgWrVGHjchkOqPDmTvNxSwC['band']['count']:pLQXibtYgWrVGHjchkOqPDmTvNxSMn =pLQXibtYgWrVGHjchkOqPDmTvNxSJs(pLQXibtYgWrVGHjchkOqPDmTvNxSwC['band']['count'])
   else:pLQXibtYgWrVGHjchkOqPDmTvNxSMn=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.LIST_LIMIT
   pLQXibtYgWrVGHjchkOqPDmTvNxSMd=pLQXibtYgWrVGHjchkOqPDmTvNxSMU>pLQXibtYgWrVGHjchkOqPDmTvNxSMn
  except pLQXibtYgWrVGHjchkOqPDmTvNxSJE as exception:
   pLQXibtYgWrVGHjchkOqPDmTvNxSFe(exception)
  return pLQXibtYgWrVGHjchkOqPDmTvNxSaw,pLQXibtYgWrVGHjchkOqPDmTvNxSMd 
 def GetSecureToken(pLQXibtYgWrVGHjchkOqPDmTvNxSCw):
  pLQXibtYgWrVGHjchkOqPDmTvNxSyU=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.API_DOMAIN+'/ip'
  pLQXibtYgWrVGHjchkOqPDmTvNxSCK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.GetDefaultParams(login=pLQXibtYgWrVGHjchkOqPDmTvNxSFz)
  pLQXibtYgWrVGHjchkOqPDmTvNxSyK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.callRequestCookies('Get',pLQXibtYgWrVGHjchkOqPDmTvNxSyU,payload=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,params=pLQXibtYgWrVGHjchkOqPDmTvNxSCK,headers=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,cookies=pLQXibtYgWrVGHjchkOqPDmTvNxSFf)
  pLQXibtYgWrVGHjchkOqPDmTvNxSyB=json.loads(pLQXibtYgWrVGHjchkOqPDmTvNxSyK.text)
  return pLQXibtYgWrVGHjchkOqPDmTvNxSyB['securetoken']
 def Wavve_Parse_m3u8(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,pLQXibtYgWrVGHjchkOqPDmTvNxSEJ):
  try:
   pLQXibtYgWrVGHjchkOqPDmTvNxSyJ={'user-agent':'pooqV2/5.6.0 (Linux;Android 10) ExoPlayerLib/2.13.3'}
   pLQXibtYgWrVGHjchkOqPDmTvNxSyK=requests.get(url=pLQXibtYgWrVGHjchkOqPDmTvNxSEJ['stream_url'],headers=pLQXibtYgWrVGHjchkOqPDmTvNxSyJ,cookies=pLQXibtYgWrVGHjchkOqPDmTvNxSEJ['stream_cookie'])
   pLQXibtYgWrVGHjchkOqPDmTvNxSaJ=pLQXibtYgWrVGHjchkOqPDmTvNxSyK.content.decode('utf-8')
   if '#EXTM3U' not in pLQXibtYgWrVGHjchkOqPDmTvNxSaJ:
    return pLQXibtYgWrVGHjchkOqPDmTvNxSFz
   if '#EXT-X-STREAM-INF' not in pLQXibtYgWrVGHjchkOqPDmTvNxSaJ: 
    return pLQXibtYgWrVGHjchkOqPDmTvNxSFz
   pLQXibtYgWrVGHjchkOqPDmTvNxSas=0
   for pLQXibtYgWrVGHjchkOqPDmTvNxSaI in pLQXibtYgWrVGHjchkOqPDmTvNxSaJ.splitlines():
    if pLQXibtYgWrVGHjchkOqPDmTvNxSaI.startswith('#EXT-X-STREAM-INF'):
     pLQXibtYgWrVGHjchkOqPDmTvNxSaU=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.MediaLine_Parse(pLQXibtYgWrVGHjchkOqPDmTvNxSaI,'#EXT-X-STREAM-INF')
     if pLQXibtYgWrVGHjchkOqPDmTvNxSas<pLQXibtYgWrVGHjchkOqPDmTvNxSJs(pLQXibtYgWrVGHjchkOqPDmTvNxSaU.get('BANDWIDTH')):
      pLQXibtYgWrVGHjchkOqPDmTvNxSas=pLQXibtYgWrVGHjchkOqPDmTvNxSJs(pLQXibtYgWrVGHjchkOqPDmTvNxSaU.get('BANDWIDTH'))
   pLQXibtYgWrVGHjchkOqPDmTvNxSad=[]
   pLQXibtYgWrVGHjchkOqPDmTvNxSaK=pLQXibtYgWrVGHjchkOqPDmTvNxSFz
   for pLQXibtYgWrVGHjchkOqPDmTvNxSaI in pLQXibtYgWrVGHjchkOqPDmTvNxSaJ.splitlines():
    if pLQXibtYgWrVGHjchkOqPDmTvNxSaK==pLQXibtYgWrVGHjchkOqPDmTvNxSJM:
     pLQXibtYgWrVGHjchkOqPDmTvNxSaK=pLQXibtYgWrVGHjchkOqPDmTvNxSFz
     continue
    if pLQXibtYgWrVGHjchkOqPDmTvNxSaI.startswith('#EXT-X-STREAM-INF'):
     pLQXibtYgWrVGHjchkOqPDmTvNxSaU=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.MediaLine_Parse(pLQXibtYgWrVGHjchkOqPDmTvNxSaI,'#EXT-X-STREAM-INF')
     if pLQXibtYgWrVGHjchkOqPDmTvNxSas!=pLQXibtYgWrVGHjchkOqPDmTvNxSJs(pLQXibtYgWrVGHjchkOqPDmTvNxSaU.get('BANDWIDTH')):
      pLQXibtYgWrVGHjchkOqPDmTvNxSaK=pLQXibtYgWrVGHjchkOqPDmTvNxSJM
      continue
    pLQXibtYgWrVGHjchkOqPDmTvNxSad.append(pLQXibtYgWrVGHjchkOqPDmTvNxSaI)
  except pLQXibtYgWrVGHjchkOqPDmTvNxSJE as exception:
   pLQXibtYgWrVGHjchkOqPDmTvNxSFe(exception)
   return pLQXibtYgWrVGHjchkOqPDmTvNxSFz
  pLQXibtYgWrVGHjchkOqPDmTvNxSaB='\n'.join(pLQXibtYgWrVGHjchkOqPDmTvNxSad)
  pLQXibtYgWrVGHjchkOqPDmTvNxSCw.TextFile_Save(pLQXibtYgWrVGHjchkOqPDmTvNxSCw.WV_STREAM_FILENAME,pLQXibtYgWrVGHjchkOqPDmTvNxSaB)
  return pLQXibtYgWrVGHjchkOqPDmTvNxSJM
 def Wavve_Parse_mpd(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,pLQXibtYgWrVGHjchkOqPDmTvNxSEJ):
  pLQXibtYgWrVGHjchkOqPDmTvNxSyJ={'user-agent':'pooqV2/5.6.0 (Linux;Android 10) ExoPlayerLib/2.13.3'}
  pLQXibtYgWrVGHjchkOqPDmTvNxSyK=requests.get(url=pLQXibtYgWrVGHjchkOqPDmTvNxSEJ['stream_url'],headers=pLQXibtYgWrVGHjchkOqPDmTvNxSyJ,cookies=pLQXibtYgWrVGHjchkOqPDmTvNxSEJ['stream_cookie'])
  pLQXibtYgWrVGHjchkOqPDmTvNxSaA=pLQXibtYgWrVGHjchkOqPDmTvNxSyK.content.decode('utf-8')
  pLQXibtYgWrVGHjchkOqPDmTvNxSaR =ET.ElementTree(ET.fromstring(pLQXibtYgWrVGHjchkOqPDmTvNxSaA))
  pLQXibtYgWrVGHjchkOqPDmTvNxSan =pLQXibtYgWrVGHjchkOqPDmTvNxSaR.getroot()
  pLQXibtYgWrVGHjchkOqPDmTvNxSau=re.match(r'\{.*\}',pLQXibtYgWrVGHjchkOqPDmTvNxSan.tag)[0] 
  pLQXibtYgWrVGHjchkOqPDmTvNxSal=pLQXibtYgWrVGHjchkOqPDmTvNxSJF([node for _,node in ET.iterparse(io.StringIO(pLQXibtYgWrVGHjchkOqPDmTvNxSaA),events=['start-ns'])])
  for pLQXibtYgWrVGHjchkOqPDmTvNxSyE,pLQXibtYgWrVGHjchkOqPDmTvNxSEF in pLQXibtYgWrVGHjchkOqPDmTvNxSal.items():
   ET.register_namespace(pLQXibtYgWrVGHjchkOqPDmTvNxSyE,pLQXibtYgWrVGHjchkOqPDmTvNxSEF)
  pLQXibtYgWrVGHjchkOqPDmTvNxSao=pLQXibtYgWrVGHjchkOqPDmTvNxSan.find(pLQXibtYgWrVGHjchkOqPDmTvNxSau+'Period')
  for pLQXibtYgWrVGHjchkOqPDmTvNxSaf in pLQXibtYgWrVGHjchkOqPDmTvNxSao.findall(pLQXibtYgWrVGHjchkOqPDmTvNxSau+'AdaptationSet'):
   if pLQXibtYgWrVGHjchkOqPDmTvNxSaf.attrib.get('mimeType')=='video/mp4':
    pLQXibtYgWrVGHjchkOqPDmTvNxSaz=0
    for pLQXibtYgWrVGHjchkOqPDmTvNxSae in pLQXibtYgWrVGHjchkOqPDmTvNxSaf.findall(pLQXibtYgWrVGHjchkOqPDmTvNxSau+'Representation'):
     pLQXibtYgWrVGHjchkOqPDmTvNxSEC=pLQXibtYgWrVGHjchkOqPDmTvNxSJs(pLQXibtYgWrVGHjchkOqPDmTvNxSae.attrib.get('bandwidth'))
     if pLQXibtYgWrVGHjchkOqPDmTvNxSaz<pLQXibtYgWrVGHjchkOqPDmTvNxSEC:pLQXibtYgWrVGHjchkOqPDmTvNxSaz=pLQXibtYgWrVGHjchkOqPDmTvNxSEC
    for pLQXibtYgWrVGHjchkOqPDmTvNxSae in pLQXibtYgWrVGHjchkOqPDmTvNxSaf.findall(pLQXibtYgWrVGHjchkOqPDmTvNxSau+'Representation'):
     if pLQXibtYgWrVGHjchkOqPDmTvNxSaz>pLQXibtYgWrVGHjchkOqPDmTvNxSJs(pLQXibtYgWrVGHjchkOqPDmTvNxSae.attrib.get('bandwidth')):
      pLQXibtYgWrVGHjchkOqPDmTvNxSaf.remove(pLQXibtYgWrVGHjchkOqPDmTvNxSae)
   elif pLQXibtYgWrVGHjchkOqPDmTvNxSaf.attrib.get('mimeType')=='audio/mp4':
    pLQXibtYgWrVGHjchkOqPDmTvNxSaz=0
    for pLQXibtYgWrVGHjchkOqPDmTvNxSae in pLQXibtYgWrVGHjchkOqPDmTvNxSaf.findall(pLQXibtYgWrVGHjchkOqPDmTvNxSau+'Representation'):
     pLQXibtYgWrVGHjchkOqPDmTvNxSEC=pLQXibtYgWrVGHjchkOqPDmTvNxSJs(pLQXibtYgWrVGHjchkOqPDmTvNxSae.attrib.get('bandwidth'))
     if pLQXibtYgWrVGHjchkOqPDmTvNxSaz<pLQXibtYgWrVGHjchkOqPDmTvNxSEC:pLQXibtYgWrVGHjchkOqPDmTvNxSaz=pLQXibtYgWrVGHjchkOqPDmTvNxSEC
    for pLQXibtYgWrVGHjchkOqPDmTvNxSae in pLQXibtYgWrVGHjchkOqPDmTvNxSaf.findall(pLQXibtYgWrVGHjchkOqPDmTvNxSau+'Representation'):
     if pLQXibtYgWrVGHjchkOqPDmTvNxSaz>pLQXibtYgWrVGHjchkOqPDmTvNxSJs(pLQXibtYgWrVGHjchkOqPDmTvNxSae.attrib.get('bandwidth')):
      pLQXibtYgWrVGHjchkOqPDmTvNxSaf.remove(pLQXibtYgWrVGHjchkOqPDmTvNxSae)
   else:
    continue
  pLQXibtYgWrVGHjchkOqPDmTvNxSEy=ET.tostring(pLQXibtYgWrVGHjchkOqPDmTvNxSan).decode('utf-8')
  pLQXibtYgWrVGHjchkOqPDmTvNxSEM='<?xml version="1.0" encoding="UTF-8"?>\n'
  pLQXibtYgWrVGHjchkOqPDmTvNxSCw.TextFile_Save(pLQXibtYgWrVGHjchkOqPDmTvNxSCw.WV_STREAM_FILENAME,pLQXibtYgWrVGHjchkOqPDmTvNxSEM+pLQXibtYgWrVGHjchkOqPDmTvNxSEy)
  return pLQXibtYgWrVGHjchkOqPDmTvNxSJM
 def MediaLine_Parse(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,pLQXibtYgWrVGHjchkOqPDmTvNxSaI,prefix):
  pLQXibtYgWrVGHjchkOqPDmTvNxSaU={}
  for pLQXibtYgWrVGHjchkOqPDmTvNxSEw in pLQXibtYgWrVGHjchkOqPDmTvNxSCM.split(pLQXibtYgWrVGHjchkOqPDmTvNxSaI.replace(prefix+':',''))[1::2]:
   pLQXibtYgWrVGHjchkOqPDmTvNxSEa,pLQXibtYgWrVGHjchkOqPDmTvNxSEF=pLQXibtYgWrVGHjchkOqPDmTvNxSEw.split('=',1)
   pLQXibtYgWrVGHjchkOqPDmTvNxSaU[pLQXibtYgWrVGHjchkOqPDmTvNxSEa.upper()]=pLQXibtYgWrVGHjchkOqPDmTvNxSEF.replace('"','').strip()
  return pLQXibtYgWrVGHjchkOqPDmTvNxSaU
 def GetStreamingURL(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,mode,pLQXibtYgWrVGHjchkOqPDmTvNxSMe,quality_int,pvrmode='-',playOption={}):
  pLQXibtYgWrVGHjchkOqPDmTvNxSEJ ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  pLQXibtYgWrVGHjchkOqPDmTvNxSEs=[]
  if mode=='LIVE':
   pLQXibtYgWrVGHjchkOqPDmTvNxSyU =pLQXibtYgWrVGHjchkOqPDmTvNxSCw.API_DOMAIN+'/live/channels/'+pLQXibtYgWrVGHjchkOqPDmTvNxSMe
   pLQXibtYgWrVGHjchkOqPDmTvNxSEI='live'
  elif mode=='VOD':
   pLQXibtYgWrVGHjchkOqPDmTvNxSyU =pLQXibtYgWrVGHjchkOqPDmTvNxSCw.API_DOMAIN+'/fz/vod/contents-detail/'+pLQXibtYgWrVGHjchkOqPDmTvNxSMe 
   pLQXibtYgWrVGHjchkOqPDmTvNxSEI='vod'
  elif mode=='MOVIE':
   pLQXibtYgWrVGHjchkOqPDmTvNxSyU =pLQXibtYgWrVGHjchkOqPDmTvNxSCw.API_DOMAIN+'/fz/movie/contents/'+pLQXibtYgWrVGHjchkOqPDmTvNxSMe
   pLQXibtYgWrVGHjchkOqPDmTvNxSEI='movie'
  pLQXibtYgWrVGHjchkOqPDmTvNxSEU={'hdr':'sdr','uhd':'-',}
  try:
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.GetDefaultParams(login=pLQXibtYgWrVGHjchkOqPDmTvNxSFz)
   pLQXibtYgWrVGHjchkOqPDmTvNxSyK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.callRequestCookies('Get',pLQXibtYgWrVGHjchkOqPDmTvNxSyU,payload=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,params=pLQXibtYgWrVGHjchkOqPDmTvNxSCK,headers=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,cookies=pLQXibtYgWrVGHjchkOqPDmTvNxSFf)
   pLQXibtYgWrVGHjchkOqPDmTvNxSyB=json.loads(pLQXibtYgWrVGHjchkOqPDmTvNxSyK.text)
   pLQXibtYgWrVGHjchkOqPDmTvNxSEd=pLQXibtYgWrVGHjchkOqPDmTvNxSyB['qualities']['list']
   if pLQXibtYgWrVGHjchkOqPDmTvNxSEd==pLQXibtYgWrVGHjchkOqPDmTvNxSFf:return pLQXibtYgWrVGHjchkOqPDmTvNxSEJ
   for pLQXibtYgWrVGHjchkOqPDmTvNxSEK in pLQXibtYgWrVGHjchkOqPDmTvNxSEd:
    pLQXibtYgWrVGHjchkOqPDmTvNxSEs.append(pLQXibtYgWrVGHjchkOqPDmTvNxSJs(pLQXibtYgWrVGHjchkOqPDmTvNxSEK.get('id').rstrip('p')))
   if 'type' in pLQXibtYgWrVGHjchkOqPDmTvNxSyB:
    if pLQXibtYgWrVGHjchkOqPDmTvNxSyB['type']=='onair':
     pLQXibtYgWrVGHjchkOqPDmTvNxSEI='onairvod'
   if 'drms' in pLQXibtYgWrVGHjchkOqPDmTvNxSyB:
    if pLQXibtYgWrVGHjchkOqPDmTvNxSyB['drms']:
     pLQXibtYgWrVGHjchkOqPDmTvNxSEJ['stream_action']='dash' 
   if playOption.get('enable_hdr'):
    if 'mediatypes' in pLQXibtYgWrVGHjchkOqPDmTvNxSyB.get('qualities'):
     for pLQXibtYgWrVGHjchkOqPDmTvNxSEB in pLQXibtYgWrVGHjchkOqPDmTvNxSyB.get('qualities').get('mediatypes'):
      if pLQXibtYgWrVGHjchkOqPDmTvNxSEB=='HDR10':
       pLQXibtYgWrVGHjchkOqPDmTvNxSEU['hdr']='hdr'
       pLQXibtYgWrVGHjchkOqPDmTvNxSEJ['stream_action']='dash'
       break
   if playOption.get('enable_uhd'):
    for pLQXibtYgWrVGHjchkOqPDmTvNxSEB in pLQXibtYgWrVGHjchkOqPDmTvNxSyB.get('qualities').get('list'):
     if pLQXibtYgWrVGHjchkOqPDmTvNxSEB.get('name')=='UHD':
      pLQXibtYgWrVGHjchkOqPDmTvNxSEU['uhd']='uhd'
      break
  except pLQXibtYgWrVGHjchkOqPDmTvNxSJE as exception:
   pLQXibtYgWrVGHjchkOqPDmTvNxSFe(exception)
   return pLQXibtYgWrVGHjchkOqPDmTvNxSEJ
  pLQXibtYgWrVGHjchkOqPDmTvNxSFe('stream_action : '+pLQXibtYgWrVGHjchkOqPDmTvNxSEJ['stream_action'])
  try:
   pLQXibtYgWrVGHjchkOqPDmTvNxSEA=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.CheckQuality(quality_int,pLQXibtYgWrVGHjchkOqPDmTvNxSEs)
   pLQXibtYgWrVGHjchkOqPDmTvNxSFe(pLQXibtYgWrVGHjchkOqPDmTvNxSEA)
   if pLQXibtYgWrVGHjchkOqPDmTvNxSEA<1080:
    pLQXibtYgWrVGHjchkOqPDmTvNxSEU['uhd']='-'
    pLQXibtYgWrVGHjchkOqPDmTvNxSEU['hdr']='sdr'
   if pLQXibtYgWrVGHjchkOqPDmTvNxSEU['uhd']=='uhd':pLQXibtYgWrVGHjchkOqPDmTvNxSEA=2160 
   pLQXibtYgWrVGHjchkOqPDmTvNxSER=pLQXibtYgWrVGHjchkOqPDmTvNxSJC(pLQXibtYgWrVGHjchkOqPDmTvNxSEA)+'p'
   pLQXibtYgWrVGHjchkOqPDmTvNxSFe(pLQXibtYgWrVGHjchkOqPDmTvNxSER)
   pLQXibtYgWrVGHjchkOqPDmTvNxSyU='https://delivery.wavve.com/v1/streaming/{}'.format(pLQXibtYgWrVGHjchkOqPDmTvNxSEI)
   if pLQXibtYgWrVGHjchkOqPDmTvNxSEU['hdr']=='hdr' or pLQXibtYgWrVGHjchkOqPDmTvNxSEU['uhd']=='uhd':
    pLQXibtYgWrVGHjchkOqPDmTvNxSCK={'service':'wavve','contentid':pLQXibtYgWrVGHjchkOqPDmTvNxSMe,'audioChannel':'2ch','contenttype':pLQXibtYgWrVGHjchkOqPDmTvNxSEI,'hdr':'HDR10','videocodec':'HEVC','audiocodec':'AAC','issurround':'y','format':'normal','withinsubtitle':'n','action':pLQXibtYgWrVGHjchkOqPDmTvNxSEJ['stream_action'],'protocol':pLQXibtYgWrVGHjchkOqPDmTvNxSEJ['stream_action'],'quality':pLQXibtYgWrVGHjchkOqPDmTvNxSER,'modelid':'SHIELD Android TV','guid':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n',}
    pLQXibtYgWrVGHjchkOqPDmTvNxSCK.update(pLQXibtYgWrVGHjchkOqPDmTvNxSCw.GetDefaultParams_AND())
   else:
    pLQXibtYgWrVGHjchkOqPDmTvNxSCK={'service':'wavve','contentid':pLQXibtYgWrVGHjchkOqPDmTvNxSMe,'audioChannel':'2ch','contenttype':pLQXibtYgWrVGHjchkOqPDmTvNxSEI,'hdr':'sdr','videocodec':'avc','audiocodec':'aac','issurround':'n','format':'normal','withinsubtitle':'n','action':pLQXibtYgWrVGHjchkOqPDmTvNxSEJ['stream_action'],'protocol':pLQXibtYgWrVGHjchkOqPDmTvNxSEJ['stream_action'],'quality':pLQXibtYgWrVGHjchkOqPDmTvNxSER,'deviceModelId':'Windows 10','guid':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n',}
    '''
    params = {'contentid' : contentid, 'contenttype' : contenttype, 'quality' : quality_param, ###### if login=False : 체크 미비 (auto, 1080p) ###### 'deviceModelId' : 'Windows 10', 'guid' : self.WV['cookies']['uuid'], # self.GetGUID(guidType=2), 'lastplayid' : '', #self.guid 'authtype' : 'cookie', 'isabr' : 'y', 'ishevc' : 'n', 'action' : url_info['stream_action'], # 기본 hls / DRM dash ##### 'protocol' : url_info['stream_action'], # hls ? 확인필요 'hdr' : 'sdr', # hdr 'videocodec' : 'avc', 'audiocodec' : 'aac', 'issurround' : 'n', 'format' : 'normal', 'withinsubtitle' : 'n', }
    '''    
    pLQXibtYgWrVGHjchkOqPDmTvNxSCK.update(pLQXibtYgWrVGHjchkOqPDmTvNxSCw.GetDefaultParams(login=pLQXibtYgWrVGHjchkOqPDmTvNxSJM))
   pLQXibtYgWrVGHjchkOqPDmTvNxSyJ={'wavve-credential':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.WV['cookies']['credential'],}
   pLQXibtYgWrVGHjchkOqPDmTvNxSyK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.callRequestCookies('Get',pLQXibtYgWrVGHjchkOqPDmTvNxSyU,payload=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,params=pLQXibtYgWrVGHjchkOqPDmTvNxSCK,headers=pLQXibtYgWrVGHjchkOqPDmTvNxSyJ,cookies=pLQXibtYgWrVGHjchkOqPDmTvNxSFf)
   pLQXibtYgWrVGHjchkOqPDmTvNxSyB=json.loads(pLQXibtYgWrVGHjchkOqPDmTvNxSyK.text)
   pLQXibtYgWrVGHjchkOqPDmTvNxSEJ['stream_url']=pLQXibtYgWrVGHjchkOqPDmTvNxSyB['playurl']
   if pLQXibtYgWrVGHjchkOqPDmTvNxSEJ['stream_url']==pLQXibtYgWrVGHjchkOqPDmTvNxSFf:return pLQXibtYgWrVGHjchkOqPDmTvNxSEJ
   pLQXibtYgWrVGHjchkOqPDmTvNxSEJ['stream_cookie']=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.make_str_ToCookie(pLQXibtYgWrVGHjchkOqPDmTvNxSyB['awscookie'])
   pLQXibtYgWrVGHjchkOqPDmTvNxSEJ['stream_drm'] =pLQXibtYgWrVGHjchkOqPDmTvNxSyB['drm']
   if 'previewmsg' in pLQXibtYgWrVGHjchkOqPDmTvNxSyB['preview']:pLQXibtYgWrVGHjchkOqPDmTvNxSEJ['stream_preview']=pLQXibtYgWrVGHjchkOqPDmTvNxSyB['preview']['previewmsg']
   if 'subtitles' in pLQXibtYgWrVGHjchkOqPDmTvNxSyB:
    for pLQXibtYgWrVGHjchkOqPDmTvNxSEn in pLQXibtYgWrVGHjchkOqPDmTvNxSyB['subtitles']:
     if pLQXibtYgWrVGHjchkOqPDmTvNxSEn.get('languagecode')=='ko':
      pLQXibtYgWrVGHjchkOqPDmTvNxSEJ['stream_vtt']=pLQXibtYgWrVGHjchkOqPDmTvNxSEn.get('url')
      break
    if pLQXibtYgWrVGHjchkOqPDmTvNxSEJ['stream_vtt']=='':
     for pLQXibtYgWrVGHjchkOqPDmTvNxSEn in pLQXibtYgWrVGHjchkOqPDmTvNxSyB['subtitles']:
      if pLQXibtYgWrVGHjchkOqPDmTvNxSEn.get('languagecode')=='ko_cc':
       pLQXibtYgWrVGHjchkOqPDmTvNxSEJ['stream_vtt']=pLQXibtYgWrVGHjchkOqPDmTvNxSEn.get('url')
       break
   pLQXibtYgWrVGHjchkOqPDmTvNxSEJ['playParam']=pLQXibtYgWrVGHjchkOqPDmTvNxSEU 
  except pLQXibtYgWrVGHjchkOqPDmTvNxSJE as exception:
   pLQXibtYgWrVGHjchkOqPDmTvNxSFe(exception)
  return pLQXibtYgWrVGHjchkOqPDmTvNxSEJ 
 def GetSportsURL(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,pLQXibtYgWrVGHjchkOqPDmTvNxSMe,quality_int):
  pLQXibtYgWrVGHjchkOqPDmTvNxSEJ ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  pLQXibtYgWrVGHjchkOqPDmTvNxSEs=[]
  try:
   pLQXibtYgWrVGHjchkOqPDmTvNxSyU=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.API_DOMAIN+'/streaming/other'
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK={'contentid':pLQXibtYgWrVGHjchkOqPDmTvNxSMe,'contenttype':'live','action':pLQXibtYgWrVGHjchkOqPDmTvNxSEJ['stream_action'],'quality':pLQXibtYgWrVGHjchkOqPDmTvNxSJC(quality_int)+'p','deviceModelId':'Windows 10','guid':pLQXibtYgWrVGHjchkOqPDmTvNxSCw.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n',}
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK.update(pLQXibtYgWrVGHjchkOqPDmTvNxSCw.GetDefaultParams(login=pLQXibtYgWrVGHjchkOqPDmTvNxSJM))
   pLQXibtYgWrVGHjchkOqPDmTvNxSyK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.callRequestCookies('Get',pLQXibtYgWrVGHjchkOqPDmTvNxSyU,payload=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,params=pLQXibtYgWrVGHjchkOqPDmTvNxSCK,headers=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,cookies=pLQXibtYgWrVGHjchkOqPDmTvNxSFf)
   pLQXibtYgWrVGHjchkOqPDmTvNxSyB=json.loads(pLQXibtYgWrVGHjchkOqPDmTvNxSyK.text)
   pLQXibtYgWrVGHjchkOqPDmTvNxSEJ['stream_url']=pLQXibtYgWrVGHjchkOqPDmTvNxSyB['playurl']
   if pLQXibtYgWrVGHjchkOqPDmTvNxSEJ['stream_url']==pLQXibtYgWrVGHjchkOqPDmTvNxSFf:return pLQXibtYgWrVGHjchkOqPDmTvNxSEJ
   pLQXibtYgWrVGHjchkOqPDmTvNxSEJ['stream_cookie']=pLQXibtYgWrVGHjchkOqPDmTvNxSyB['awscookie']
  except pLQXibtYgWrVGHjchkOqPDmTvNxSJE as exception:
   pLQXibtYgWrVGHjchkOqPDmTvNxSFe(exception)
  return pLQXibtYgWrVGHjchkOqPDmTvNxSEJ
 def make_viewdate(pLQXibtYgWrVGHjchkOqPDmTvNxSCw):
  pLQXibtYgWrVGHjchkOqPDmTvNxSEu =pLQXibtYgWrVGHjchkOqPDmTvNxSCw.Get_Now_Datetime()
  pLQXibtYgWrVGHjchkOqPDmTvNxSEl =pLQXibtYgWrVGHjchkOqPDmTvNxSEu+datetime.timedelta(days=-1)
  pLQXibtYgWrVGHjchkOqPDmTvNxSEo =pLQXibtYgWrVGHjchkOqPDmTvNxSEu+datetime.timedelta(days=1)
  pLQXibtYgWrVGHjchkOqPDmTvNxSEf=[pLQXibtYgWrVGHjchkOqPDmTvNxSEu.strftime('%Y%m%d'),pLQXibtYgWrVGHjchkOqPDmTvNxSEo.strftime('%Y%m%d'),]
  return pLQXibtYgWrVGHjchkOqPDmTvNxSEf
 def Get_Sports_Gamelist(pLQXibtYgWrVGHjchkOqPDmTvNxSCw):
  pLQXibtYgWrVGHjchkOqPDmTvNxSEz =pLQXibtYgWrVGHjchkOqPDmTvNxSCw.make_viewdate()
  pLQXibtYgWrVGHjchkOqPDmTvNxSEe=[]
  pLQXibtYgWrVGHjchkOqPDmTvNxSFC =[]
  for pLQXibtYgWrVGHjchkOqPDmTvNxSFy in pLQXibtYgWrVGHjchkOqPDmTvNxSEz:
   pLQXibtYgWrVGHjchkOqPDmTvNxSFM=pLQXibtYgWrVGHjchkOqPDmTvNxSFy[:6]
   if pLQXibtYgWrVGHjchkOqPDmTvNxSFM not in pLQXibtYgWrVGHjchkOqPDmTvNxSEe:
    pLQXibtYgWrVGHjchkOqPDmTvNxSEe.append(pLQXibtYgWrVGHjchkOqPDmTvNxSFM)
  try:
   pLQXibtYgWrVGHjchkOqPDmTvNxSyU='https://annexapi.wavve.com/skb/baseball/teammonthlycalendarlist'
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK={'IF':'IF-PORG-002','m':'getTeamCalendarListBand','response_format':'json','spo_itm_cd':'KBO','teamcd':'all','tgroup':'B','tvalue':'BC123','ver':'2.0',}
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK.update(pLQXibtYgWrVGHjchkOqPDmTvNxSCw.GetDefaultParams(login=pLQXibtYgWrVGHjchkOqPDmTvNxSFz))
   for pLQXibtYgWrVGHjchkOqPDmTvNxSFw in pLQXibtYgWrVGHjchkOqPDmTvNxSEe:
    pLQXibtYgWrVGHjchkOqPDmTvNxSCK['date']=pLQXibtYgWrVGHjchkOqPDmTvNxSFw
    pLQXibtYgWrVGHjchkOqPDmTvNxSyK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.callRequestCookies('Get',pLQXibtYgWrVGHjchkOqPDmTvNxSyU,payload=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,params=pLQXibtYgWrVGHjchkOqPDmTvNxSCK,headers=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,cookies=pLQXibtYgWrVGHjchkOqPDmTvNxSFf)
    pLQXibtYgWrVGHjchkOqPDmTvNxSyB=json.loads(pLQXibtYgWrVGHjchkOqPDmTvNxSyK.text)
    pLQXibtYgWrVGHjchkOqPDmTvNxSMC=pLQXibtYgWrVGHjchkOqPDmTvNxSyB['cell_toplist']['celllist']
    for pLQXibtYgWrVGHjchkOqPDmTvNxSMy in pLQXibtYgWrVGHjchkOqPDmTvNxSMC:
     pLQXibtYgWrVGHjchkOqPDmTvNxSFa=pLQXibtYgWrVGHjchkOqPDmTvNxSMy.get('game_date')
     pLQXibtYgWrVGHjchkOqPDmTvNxSFE =pLQXibtYgWrVGHjchkOqPDmTvNxSMy.get('svc_id')
     if pLQXibtYgWrVGHjchkOqPDmTvNxSFE=='':continue
     if pLQXibtYgWrVGHjchkOqPDmTvNxSFa in pLQXibtYgWrVGHjchkOqPDmTvNxSEz:
      pLQXibtYgWrVGHjchkOqPDmTvNxSFJ=pLQXibtYgWrVGHjchkOqPDmTvNxSMy.get('game_status') 
      pLQXibtYgWrVGHjchkOqPDmTvNxSFs =pLQXibtYgWrVGHjchkOqPDmTvNxSMy.get('title_list')[0].get('text')
      pLQXibtYgWrVGHjchkOqPDmTvNxSFa =pLQXibtYgWrVGHjchkOqPDmTvNxSFa[:4]+'-'+pLQXibtYgWrVGHjchkOqPDmTvNxSFa[4:6]+'-'+pLQXibtYgWrVGHjchkOqPDmTvNxSFa[-2:]
      pLQXibtYgWrVGHjchkOqPDmTvNxSFI =pLQXibtYgWrVGHjchkOqPDmTvNxSMy.get('game_time')
      pLQXibtYgWrVGHjchkOqPDmTvNxSFI =pLQXibtYgWrVGHjchkOqPDmTvNxSFI[:2]+':'+pLQXibtYgWrVGHjchkOqPDmTvNxSFI[-2:]
      pLQXibtYgWrVGHjchkOqPDmTvNxSMw={'game_date':pLQXibtYgWrVGHjchkOqPDmTvNxSFa,'game_time':pLQXibtYgWrVGHjchkOqPDmTvNxSFI,'svc_id':pLQXibtYgWrVGHjchkOqPDmTvNxSFE,'away_team':pLQXibtYgWrVGHjchkOqPDmTvNxSMy.get('away_team').get('team_name'),'home_team':pLQXibtYgWrVGHjchkOqPDmTvNxSMy.get('home_team').get('team_name'),'game_status':pLQXibtYgWrVGHjchkOqPDmTvNxSFJ,'game_place':pLQXibtYgWrVGHjchkOqPDmTvNxSMy.get('game_place'),}
      pLQXibtYgWrVGHjchkOqPDmTvNxSFC.append(pLQXibtYgWrVGHjchkOqPDmTvNxSMw)
  except pLQXibtYgWrVGHjchkOqPDmTvNxSJE as exception:
   pLQXibtYgWrVGHjchkOqPDmTvNxSFe(exception)
   return[]
  pLQXibtYgWrVGHjchkOqPDmTvNxSFU=[]
  for i in pLQXibtYgWrVGHjchkOqPDmTvNxSJw(2):
   for pLQXibtYgWrVGHjchkOqPDmTvNxSMy in pLQXibtYgWrVGHjchkOqPDmTvNxSFC:
    if i==0 and pLQXibtYgWrVGHjchkOqPDmTvNxSMy.get('game_status')=='LIVE':
     pLQXibtYgWrVGHjchkOqPDmTvNxSFU.append(pLQXibtYgWrVGHjchkOqPDmTvNxSMy)
    elif i==1 and pLQXibtYgWrVGHjchkOqPDmTvNxSMy.get('game_status')!='LIVE':
     pLQXibtYgWrVGHjchkOqPDmTvNxSFU.append(pLQXibtYgWrVGHjchkOqPDmTvNxSMy)
  return pLQXibtYgWrVGHjchkOqPDmTvNxSFU
 def GetBookmarkInfo(pLQXibtYgWrVGHjchkOqPDmTvNxSCw,pLQXibtYgWrVGHjchkOqPDmTvNxSMR,pLQXibtYgWrVGHjchkOqPDmTvNxSMA,pLQXibtYgWrVGHjchkOqPDmTvNxSEI):
  if pLQXibtYgWrVGHjchkOqPDmTvNxSMA=='tvshow':
   if pLQXibtYgWrVGHjchkOqPDmTvNxSEI=='contentid':
    pLQXibtYgWrVGHjchkOqPDmTvNxSMe=pLQXibtYgWrVGHjchkOqPDmTvNxSMR
    pLQXibtYgWrVGHjchkOqPDmTvNxSMR =pLQXibtYgWrVGHjchkOqPDmTvNxSCw.ContentidToSeasonid(pLQXibtYgWrVGHjchkOqPDmTvNxSMe)
   else:
    pLQXibtYgWrVGHjchkOqPDmTvNxSMe=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.ProgramidToContentid(pLQXibtYgWrVGHjchkOqPDmTvNxSMR)
  else:
   pLQXibtYgWrVGHjchkOqPDmTvNxSMe=''
  pLQXibtYgWrVGHjchkOqPDmTvNxSFd={'indexinfo':{'ott':'wavve','videoid':pLQXibtYgWrVGHjchkOqPDmTvNxSMR,'vidtype':pLQXibtYgWrVGHjchkOqPDmTvNxSMA,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':pLQXibtYgWrVGHjchkOqPDmTvNxSMA,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if pLQXibtYgWrVGHjchkOqPDmTvNxSMA=='tvshow':
   pLQXibtYgWrVGHjchkOqPDmTvNxSyU=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.API_DOMAIN+'/fz/vod/contents/'+pLQXibtYgWrVGHjchkOqPDmTvNxSMe 
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.GetDefaultParams(login=pLQXibtYgWrVGHjchkOqPDmTvNxSFz)
   pLQXibtYgWrVGHjchkOqPDmTvNxSyK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.callRequestCookies('Get',pLQXibtYgWrVGHjchkOqPDmTvNxSyU,payload=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,params=pLQXibtYgWrVGHjchkOqPDmTvNxSCK,headers=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,cookies=pLQXibtYgWrVGHjchkOqPDmTvNxSFf)
   pLQXibtYgWrVGHjchkOqPDmTvNxSyB=json.loads(pLQXibtYgWrVGHjchkOqPDmTvNxSyK.text)
   if not('programtitle' in pLQXibtYgWrVGHjchkOqPDmTvNxSyB):return{}
   pLQXibtYgWrVGHjchkOqPDmTvNxSFK=pLQXibtYgWrVGHjchkOqPDmTvNxSyB
   pLQXibtYgWrVGHjchkOqPDmTvNxSFB=pLQXibtYgWrVGHjchkOqPDmTvNxSFK.get('programtitle')
   pLQXibtYgWrVGHjchkOqPDmTvNxSFd['saveinfo']['infoLabels']['title']=pLQXibtYgWrVGHjchkOqPDmTvNxSFB
   if pLQXibtYgWrVGHjchkOqPDmTvNxSFK.get('targetage')=='18' or pLQXibtYgWrVGHjchkOqPDmTvNxSFK.get('targetage')=='19' or pLQXibtYgWrVGHjchkOqPDmTvNxSFK.get('targetage')=='21':
    pLQXibtYgWrVGHjchkOqPDmTvNxSFB +=u' (%s)'%(pLQXibtYgWrVGHjchkOqPDmTvNxSFK.get('targetage'))
   pLQXibtYgWrVGHjchkOqPDmTvNxSFd['saveinfo']['title'] =pLQXibtYgWrVGHjchkOqPDmTvNxSFB
   pLQXibtYgWrVGHjchkOqPDmTvNxSFd['saveinfo']['infoLabels']['mpaa'] =pLQXibtYgWrVGHjchkOqPDmTvNxSFK.get('targetage')
   pLQXibtYgWrVGHjchkOqPDmTvNxSFd['saveinfo']['infoLabels']['plot'] =pLQXibtYgWrVGHjchkOqPDmTvNxSCw.Get_ChangeText(pLQXibtYgWrVGHjchkOqPDmTvNxSFK.get('programsynopsis'))
   pLQXibtYgWrVGHjchkOqPDmTvNxSFd['saveinfo']['infoLabels']['studio'] =pLQXibtYgWrVGHjchkOqPDmTvNxSFK.get('channelname')
   if pLQXibtYgWrVGHjchkOqPDmTvNxSFK.get('firstreleaseyear')!='':pLQXibtYgWrVGHjchkOqPDmTvNxSFd['saveinfo']['infoLabels']['year'] =pLQXibtYgWrVGHjchkOqPDmTvNxSFK.get('firstreleaseyear')
   if pLQXibtYgWrVGHjchkOqPDmTvNxSFK.get('firstreleasedate')!='':pLQXibtYgWrVGHjchkOqPDmTvNxSFd['saveinfo']['infoLabels']['premiered']=pLQXibtYgWrVGHjchkOqPDmTvNxSFK.get('firstreleasedate')
   if pLQXibtYgWrVGHjchkOqPDmTvNxSFK.get('genretext') !='':pLQXibtYgWrVGHjchkOqPDmTvNxSFd['saveinfo']['infoLabels']['genre'] =[pLQXibtYgWrVGHjchkOqPDmTvNxSFK.get('genretext')]
   pLQXibtYgWrVGHjchkOqPDmTvNxSFA=[]
   for pLQXibtYgWrVGHjchkOqPDmTvNxSFR in pLQXibtYgWrVGHjchkOqPDmTvNxSFK['actors']['list']:pLQXibtYgWrVGHjchkOqPDmTvNxSFA.append(pLQXibtYgWrVGHjchkOqPDmTvNxSFR.get('text'))
   if pLQXibtYgWrVGHjchkOqPDmTvNxSJa(pLQXibtYgWrVGHjchkOqPDmTvNxSFA)>0:
    if pLQXibtYgWrVGHjchkOqPDmTvNxSFA[0]!='':pLQXibtYgWrVGHjchkOqPDmTvNxSFd['saveinfo']['infoLabels']['cast']=pLQXibtYgWrVGHjchkOqPDmTvNxSFA
   pLQXibtYgWrVGHjchkOqPDmTvNxSwA =''
   pLQXibtYgWrVGHjchkOqPDmTvNxSwR =''
   pLQXibtYgWrVGHjchkOqPDmTvNxSwn=''
   if pLQXibtYgWrVGHjchkOqPDmTvNxSFK.get('programposterimage')!='':pLQXibtYgWrVGHjchkOqPDmTvNxSwA =pLQXibtYgWrVGHjchkOqPDmTvNxSCw.HTTPTAG+pLQXibtYgWrVGHjchkOqPDmTvNxSFK.get('programposterimage')
   if pLQXibtYgWrVGHjchkOqPDmTvNxSFK.get('programimage') !='':pLQXibtYgWrVGHjchkOqPDmTvNxSwR =pLQXibtYgWrVGHjchkOqPDmTvNxSCw.HTTPTAG+pLQXibtYgWrVGHjchkOqPDmTvNxSFK.get('programimage')
   if pLQXibtYgWrVGHjchkOqPDmTvNxSFK.get('programcircleimage')!='':pLQXibtYgWrVGHjchkOqPDmTvNxSwn=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.HTTPTAG+pLQXibtYgWrVGHjchkOqPDmTvNxSFK.get('programcircleimage')
   if 'poster_default' in pLQXibtYgWrVGHjchkOqPDmTvNxSwA:
    pLQXibtYgWrVGHjchkOqPDmTvNxSwA =pLQXibtYgWrVGHjchkOqPDmTvNxSwR
    pLQXibtYgWrVGHjchkOqPDmTvNxSwn=''
   pLQXibtYgWrVGHjchkOqPDmTvNxSFd['saveinfo']['thumbnail']['poster']=pLQXibtYgWrVGHjchkOqPDmTvNxSwA
   pLQXibtYgWrVGHjchkOqPDmTvNxSFd['saveinfo']['thumbnail']['thumb']=pLQXibtYgWrVGHjchkOqPDmTvNxSwR
   pLQXibtYgWrVGHjchkOqPDmTvNxSFd['saveinfo']['thumbnail']['clearlogo']=pLQXibtYgWrVGHjchkOqPDmTvNxSwn
   pLQXibtYgWrVGHjchkOqPDmTvNxSFd['saveinfo']['thumbnail']['fanart']=pLQXibtYgWrVGHjchkOqPDmTvNxSwR
  else:
   pLQXibtYgWrVGHjchkOqPDmTvNxSyU=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.API_DOMAIN+'/movie/contents/'+pLQXibtYgWrVGHjchkOqPDmTvNxSMR 
   pLQXibtYgWrVGHjchkOqPDmTvNxSCK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.GetDefaultParams(login=pLQXibtYgWrVGHjchkOqPDmTvNxSFz)
   pLQXibtYgWrVGHjchkOqPDmTvNxSyK=pLQXibtYgWrVGHjchkOqPDmTvNxSCw.callRequestCookies('Get',pLQXibtYgWrVGHjchkOqPDmTvNxSyU,payload=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,params=pLQXibtYgWrVGHjchkOqPDmTvNxSCK,headers=pLQXibtYgWrVGHjchkOqPDmTvNxSFf,cookies=pLQXibtYgWrVGHjchkOqPDmTvNxSFf)
   pLQXibtYgWrVGHjchkOqPDmTvNxSyB=json.loads(pLQXibtYgWrVGHjchkOqPDmTvNxSyK.text)
   if not('title' in pLQXibtYgWrVGHjchkOqPDmTvNxSyB):return{}
   pLQXibtYgWrVGHjchkOqPDmTvNxSFK=pLQXibtYgWrVGHjchkOqPDmTvNxSyB
   pLQXibtYgWrVGHjchkOqPDmTvNxSFB=pLQXibtYgWrVGHjchkOqPDmTvNxSFK.get('title')
   pLQXibtYgWrVGHjchkOqPDmTvNxSFd['saveinfo']['infoLabels']['title']=pLQXibtYgWrVGHjchkOqPDmTvNxSFB
   if pLQXibtYgWrVGHjchkOqPDmTvNxSFK.get('targetage')=='18' or pLQXibtYgWrVGHjchkOqPDmTvNxSFK.get('targetage')=='19' or pLQXibtYgWrVGHjchkOqPDmTvNxSFK.get('targetage')=='21':
    pLQXibtYgWrVGHjchkOqPDmTvNxSFB +=u' (%s)'%(pLQXibtYgWrVGHjchkOqPDmTvNxSFK.get('targetage'))
   pLQXibtYgWrVGHjchkOqPDmTvNxSFd['saveinfo']['title'] =pLQXibtYgWrVGHjchkOqPDmTvNxSFB
   pLQXibtYgWrVGHjchkOqPDmTvNxSFd['saveinfo']['infoLabels']['mpaa'] =pLQXibtYgWrVGHjchkOqPDmTvNxSFK.get('targetage')
   pLQXibtYgWrVGHjchkOqPDmTvNxSFd['saveinfo']['infoLabels']['plot'] =pLQXibtYgWrVGHjchkOqPDmTvNxSCw.Get_ChangeText(pLQXibtYgWrVGHjchkOqPDmTvNxSFK.get('synopsis'))
   pLQXibtYgWrVGHjchkOqPDmTvNxSFd['saveinfo']['infoLabels']['duration']=pLQXibtYgWrVGHjchkOqPDmTvNxSFK.get('playtime')
   pLQXibtYgWrVGHjchkOqPDmTvNxSFd['saveinfo']['infoLabels']['country']=pLQXibtYgWrVGHjchkOqPDmTvNxSFK.get('country')
   pLQXibtYgWrVGHjchkOqPDmTvNxSFd['saveinfo']['infoLabels']['studio'] =pLQXibtYgWrVGHjchkOqPDmTvNxSFK.get('cpname')
   if pLQXibtYgWrVGHjchkOqPDmTvNxSFK.get('releasedate')!='':
    pLQXibtYgWrVGHjchkOqPDmTvNxSFd['saveinfo']['infoLabels']['year'] =pLQXibtYgWrVGHjchkOqPDmTvNxSFK.get('releasedate')[:4]
    pLQXibtYgWrVGHjchkOqPDmTvNxSFd['saveinfo']['infoLabels']['premiered']=pLQXibtYgWrVGHjchkOqPDmTvNxSFK.get('releasedate')
   pLQXibtYgWrVGHjchkOqPDmTvNxSFA=[]
   for pLQXibtYgWrVGHjchkOqPDmTvNxSFR in pLQXibtYgWrVGHjchkOqPDmTvNxSFK['actors']['list']:pLQXibtYgWrVGHjchkOqPDmTvNxSFA.append(pLQXibtYgWrVGHjchkOqPDmTvNxSFR.get('text'))
   if pLQXibtYgWrVGHjchkOqPDmTvNxSJa(pLQXibtYgWrVGHjchkOqPDmTvNxSFA)>0:
    if pLQXibtYgWrVGHjchkOqPDmTvNxSFA[0]!='':pLQXibtYgWrVGHjchkOqPDmTvNxSFd['saveinfo']['infoLabels']['cast']=pLQXibtYgWrVGHjchkOqPDmTvNxSFA
   pLQXibtYgWrVGHjchkOqPDmTvNxSFn=[]
   for pLQXibtYgWrVGHjchkOqPDmTvNxSFu in pLQXibtYgWrVGHjchkOqPDmTvNxSFK['directors']['list']:pLQXibtYgWrVGHjchkOqPDmTvNxSFn.append(pLQXibtYgWrVGHjchkOqPDmTvNxSFu.get('text'))
   if pLQXibtYgWrVGHjchkOqPDmTvNxSJa(pLQXibtYgWrVGHjchkOqPDmTvNxSFn)>0:
    if pLQXibtYgWrVGHjchkOqPDmTvNxSFn[0]!='':pLQXibtYgWrVGHjchkOqPDmTvNxSFd['saveinfo']['infoLabels']['director']=pLQXibtYgWrVGHjchkOqPDmTvNxSFn
   pLQXibtYgWrVGHjchkOqPDmTvNxSyf=[]
   for pLQXibtYgWrVGHjchkOqPDmTvNxSFl in pLQXibtYgWrVGHjchkOqPDmTvNxSFK['genre']['list']:pLQXibtYgWrVGHjchkOqPDmTvNxSyf.append(pLQXibtYgWrVGHjchkOqPDmTvNxSFl.get('text'))
   if pLQXibtYgWrVGHjchkOqPDmTvNxSJa(pLQXibtYgWrVGHjchkOqPDmTvNxSyf)>0:
    if pLQXibtYgWrVGHjchkOqPDmTvNxSyf[0]!='':pLQXibtYgWrVGHjchkOqPDmTvNxSFd['saveinfo']['infoLabels']['genre']=pLQXibtYgWrVGHjchkOqPDmTvNxSyf
   pLQXibtYgWrVGHjchkOqPDmTvNxSwA ='https://%s'%pLQXibtYgWrVGHjchkOqPDmTvNxSFK['image']
   pLQXibtYgWrVGHjchkOqPDmTvNxSFd['saveinfo']['thumbnail']['poster'] =pLQXibtYgWrVGHjchkOqPDmTvNxSwA
   pLQXibtYgWrVGHjchkOqPDmTvNxSFd['saveinfo']['thumbnail']['thumb'] =pLQXibtYgWrVGHjchkOqPDmTvNxSwA
  return pLQXibtYgWrVGHjchkOqPDmTvNxSFd
# Created by pyminifier (https://github.com/liftoff/pyminifier)
