__author__="NightRain"
JOtndkvQesSAHPrqouiLhTXEUfDMmF=object
JOtndkvQesSAHPrqouiLhTXEUfDMmI=None
JOtndkvQesSAHPrqouiLhTXEUfDMmx=True
JOtndkvQesSAHPrqouiLhTXEUfDMmy=False
JOtndkvQesSAHPrqouiLhTXEUfDMmW=int
JOtndkvQesSAHPrqouiLhTXEUfDMmc=type
JOtndkvQesSAHPrqouiLhTXEUfDMmV=dict
JOtndkvQesSAHPrqouiLhTXEUfDMmB=len
JOtndkvQesSAHPrqouiLhTXEUfDMmj=range
JOtndkvQesSAHPrqouiLhTXEUfDMmN=str
JOtndkvQesSAHPrqouiLhTXEUfDMmC=open
JOtndkvQesSAHPrqouiLhTXEUfDMmp=Exception
JOtndkvQesSAHPrqouiLhTXEUfDMgG=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
JOtndkvQesSAHPrqouiLhTXEUfDMGK=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://www.wavve.com/supermultisection/GN51','icon':'home.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&offset=0&limit=20&uicode=VN500','page':'1','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=01&WeekDay=all&uitype=VN4&uiparent=FN0&uirank=0&broadcastid=847243&uicode=VN4','page':'1','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=02&WeekDay=all&uitype=VN3&uiparent=FN0&uirank=0&broadcastid=783664&uicode=VN3','page':'1','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'1','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'paid','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'displaystart','ordernm':'업데이트순','icon':''},{'title':'프로야구 - 경기중 시청가능','mode':'GAME_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'(웨이브) 검색','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'(웨이브) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
JOtndkvQesSAHPrqouiLhTXEUfDMGR=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
JOtndkvQesSAHPrqouiLhTXEUfDMGz=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
JOtndkvQesSAHPrqouiLhTXEUfDMGa =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
JOtndkvQesSAHPrqouiLhTXEUfDMGm=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_searched.txt'))
from wavveCore import*
class JOtndkvQesSAHPrqouiLhTXEUfDMGb(JOtndkvQesSAHPrqouiLhTXEUfDMmF):
 def __init__(JOtndkvQesSAHPrqouiLhTXEUfDMGg,JOtndkvQesSAHPrqouiLhTXEUfDMGY,JOtndkvQesSAHPrqouiLhTXEUfDMGl,JOtndkvQesSAHPrqouiLhTXEUfDMGw):
  JOtndkvQesSAHPrqouiLhTXEUfDMGg._addon_url =JOtndkvQesSAHPrqouiLhTXEUfDMGY
  JOtndkvQesSAHPrqouiLhTXEUfDMGg._addon_handle=JOtndkvQesSAHPrqouiLhTXEUfDMGl
  JOtndkvQesSAHPrqouiLhTXEUfDMGg.main_params =JOtndkvQesSAHPrqouiLhTXEUfDMGw
  JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj =qKMpfsYkovyVIPnedzhFQORwTbHjNl() 
 def addon_noti(JOtndkvQesSAHPrqouiLhTXEUfDMGg,sting):
  try:
   JOtndkvQesSAHPrqouiLhTXEUfDMGI=xbmcgui.Dialog()
   JOtndkvQesSAHPrqouiLhTXEUfDMGI.notification(__addonname__,sting)
  except:
   JOtndkvQesSAHPrqouiLhTXEUfDMmI
 def addon_log(JOtndkvQesSAHPrqouiLhTXEUfDMGg,string):
  try:
   JOtndkvQesSAHPrqouiLhTXEUfDMGx=string.encode('utf-8','ignore')
  except:
   JOtndkvQesSAHPrqouiLhTXEUfDMGx='addonException: addon_log'
  JOtndkvQesSAHPrqouiLhTXEUfDMGy=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,JOtndkvQesSAHPrqouiLhTXEUfDMGx),level=JOtndkvQesSAHPrqouiLhTXEUfDMGy)
 def get_keyboard_input(JOtndkvQesSAHPrqouiLhTXEUfDMGg,JOtndkvQesSAHPrqouiLhTXEUfDMbY):
  JOtndkvQesSAHPrqouiLhTXEUfDMGW=JOtndkvQesSAHPrqouiLhTXEUfDMmI
  kb=xbmc.Keyboard()
  kb.setHeading(JOtndkvQesSAHPrqouiLhTXEUfDMbY)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   JOtndkvQesSAHPrqouiLhTXEUfDMGW=kb.getText()
  return JOtndkvQesSAHPrqouiLhTXEUfDMGW
 def get_settings_login_info(JOtndkvQesSAHPrqouiLhTXEUfDMGg):
  JOtndkvQesSAHPrqouiLhTXEUfDMGc =__addon__.getSetting('id')
  JOtndkvQesSAHPrqouiLhTXEUfDMGV =__addon__.getSetting('pw')
  JOtndkvQesSAHPrqouiLhTXEUfDMGB=__addon__.getSetting('selected_profile')
  return(JOtndkvQesSAHPrqouiLhTXEUfDMGc,JOtndkvQesSAHPrqouiLhTXEUfDMGV,JOtndkvQesSAHPrqouiLhTXEUfDMGB)
 def get_settings_totalsearch(JOtndkvQesSAHPrqouiLhTXEUfDMGg):
  JOtndkvQesSAHPrqouiLhTXEUfDMGj =JOtndkvQesSAHPrqouiLhTXEUfDMmx if __addon__.getSetting('local_search')=='true' else JOtndkvQesSAHPrqouiLhTXEUfDMmy
  JOtndkvQesSAHPrqouiLhTXEUfDMGN=JOtndkvQesSAHPrqouiLhTXEUfDMmx if __addon__.getSetting('local_history')=='true' else JOtndkvQesSAHPrqouiLhTXEUfDMmy
  JOtndkvQesSAHPrqouiLhTXEUfDMGC =JOtndkvQesSAHPrqouiLhTXEUfDMmx if __addon__.getSetting('total_search')=='true' else JOtndkvQesSAHPrqouiLhTXEUfDMmy
  JOtndkvQesSAHPrqouiLhTXEUfDMGp=JOtndkvQesSAHPrqouiLhTXEUfDMmx if __addon__.getSetting('total_history')=='true' else JOtndkvQesSAHPrqouiLhTXEUfDMmy
  JOtndkvQesSAHPrqouiLhTXEUfDMbG=JOtndkvQesSAHPrqouiLhTXEUfDMmx if __addon__.getSetting('menu_bookmark')=='true' else JOtndkvQesSAHPrqouiLhTXEUfDMmy
  return(JOtndkvQesSAHPrqouiLhTXEUfDMGj,JOtndkvQesSAHPrqouiLhTXEUfDMGN,JOtndkvQesSAHPrqouiLhTXEUfDMGC,JOtndkvQesSAHPrqouiLhTXEUfDMGp,JOtndkvQesSAHPrqouiLhTXEUfDMbG)
 def get_settings_makebookmark(JOtndkvQesSAHPrqouiLhTXEUfDMGg):
  return JOtndkvQesSAHPrqouiLhTXEUfDMmx if __addon__.getSetting('make_bookmark')=='true' else JOtndkvQesSAHPrqouiLhTXEUfDMmy
 def get_selQuality(JOtndkvQesSAHPrqouiLhTXEUfDMGg):
  try:
   JOtndkvQesSAHPrqouiLhTXEUfDMbK=[1080,720,480,360]
   JOtndkvQesSAHPrqouiLhTXEUfDMbR=JOtndkvQesSAHPrqouiLhTXEUfDMmW(__addon__.getSetting('selected_quality'))
   return JOtndkvQesSAHPrqouiLhTXEUfDMbK[JOtndkvQesSAHPrqouiLhTXEUfDMbR]
  except:
   JOtndkvQesSAHPrqouiLhTXEUfDMmI
  return 1080 
 def get_settings_exclusion21(JOtndkvQesSAHPrqouiLhTXEUfDMGg):
  JOtndkvQesSAHPrqouiLhTXEUfDMbz =__addon__.getSetting('exclusion21')
  if JOtndkvQesSAHPrqouiLhTXEUfDMbz=='false':
   return JOtndkvQesSAHPrqouiLhTXEUfDMmy
  else:
   return JOtndkvQesSAHPrqouiLhTXEUfDMmx
 def get_settings_direct_replay(JOtndkvQesSAHPrqouiLhTXEUfDMGg):
  JOtndkvQesSAHPrqouiLhTXEUfDMba=JOtndkvQesSAHPrqouiLhTXEUfDMmW(__addon__.getSetting('direct_replay'))
  if JOtndkvQesSAHPrqouiLhTXEUfDMba==0:
   return JOtndkvQesSAHPrqouiLhTXEUfDMmy
  else:
   return JOtndkvQesSAHPrqouiLhTXEUfDMmx
 def set_winCredential(JOtndkvQesSAHPrqouiLhTXEUfDMGg,credential):
  JOtndkvQesSAHPrqouiLhTXEUfDMbm=xbmcgui.Window(10000)
  JOtndkvQesSAHPrqouiLhTXEUfDMbm.setProperty('WAVVE_M_CREDENTIAL',credential)
  JOtndkvQesSAHPrqouiLhTXEUfDMbm.setProperty('WAVVE_M_LOGINTIME',JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(JOtndkvQesSAHPrqouiLhTXEUfDMGg):
  JOtndkvQesSAHPrqouiLhTXEUfDMbm=xbmcgui.Window(10000)
  return JOtndkvQesSAHPrqouiLhTXEUfDMbm.getProperty('WAVVE_M_CREDENTIAL')
 def set_winEpisodeOrderby(JOtndkvQesSAHPrqouiLhTXEUfDMGg,JOtndkvQesSAHPrqouiLhTXEUfDMzb):
  JOtndkvQesSAHPrqouiLhTXEUfDMbm=xbmcgui.Window(10000)
  JOtndkvQesSAHPrqouiLhTXEUfDMbm.setProperty('WAVVE_M_ORDERBY',JOtndkvQesSAHPrqouiLhTXEUfDMzb)
 def get_winEpisodeOrderby(JOtndkvQesSAHPrqouiLhTXEUfDMGg):
  JOtndkvQesSAHPrqouiLhTXEUfDMbm=xbmcgui.Window(10000)
  return JOtndkvQesSAHPrqouiLhTXEUfDMbm.getProperty('WAVVE_M_ORDERBY')
 def add_dir(JOtndkvQesSAHPrqouiLhTXEUfDMGg,label,sublabel='',img='',infoLabels=JOtndkvQesSAHPrqouiLhTXEUfDMmI,isFolder=JOtndkvQesSAHPrqouiLhTXEUfDMmx,params='',isLink=JOtndkvQesSAHPrqouiLhTXEUfDMmy,ContextMenu=JOtndkvQesSAHPrqouiLhTXEUfDMmI):
  JOtndkvQesSAHPrqouiLhTXEUfDMbg='%s?%s'%(JOtndkvQesSAHPrqouiLhTXEUfDMGg._addon_url,urllib.parse.urlencode(params))
  if sublabel:JOtndkvQesSAHPrqouiLhTXEUfDMbY='%s < %s >'%(label,sublabel)
  else: JOtndkvQesSAHPrqouiLhTXEUfDMbY=label
  if not img:img='DefaultFolder.png'
  JOtndkvQesSAHPrqouiLhTXEUfDMbl=xbmcgui.ListItem(JOtndkvQesSAHPrqouiLhTXEUfDMbY)
  if JOtndkvQesSAHPrqouiLhTXEUfDMmc(img)==JOtndkvQesSAHPrqouiLhTXEUfDMmV:
   JOtndkvQesSAHPrqouiLhTXEUfDMbl.setArt(img)
  else:
   JOtndkvQesSAHPrqouiLhTXEUfDMbl.setArt({'thumb':img,'poster':img})
  if infoLabels:JOtndkvQesSAHPrqouiLhTXEUfDMbl.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   JOtndkvQesSAHPrqouiLhTXEUfDMbl.setProperty('IsPlayable','true')
  if ContextMenu:JOtndkvQesSAHPrqouiLhTXEUfDMbl.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(JOtndkvQesSAHPrqouiLhTXEUfDMGg._addon_handle,JOtndkvQesSAHPrqouiLhTXEUfDMbg,JOtndkvQesSAHPrqouiLhTXEUfDMbl,isFolder)
 def dp_Main_List(JOtndkvQesSAHPrqouiLhTXEUfDMGg):
  (JOtndkvQesSAHPrqouiLhTXEUfDMGj,JOtndkvQesSAHPrqouiLhTXEUfDMGN,JOtndkvQesSAHPrqouiLhTXEUfDMGC,JOtndkvQesSAHPrqouiLhTXEUfDMGp,JOtndkvQesSAHPrqouiLhTXEUfDMbG)=JOtndkvQesSAHPrqouiLhTXEUfDMGg.get_settings_totalsearch()
  for JOtndkvQesSAHPrqouiLhTXEUfDMbw in JOtndkvQesSAHPrqouiLhTXEUfDMGK:
   JOtndkvQesSAHPrqouiLhTXEUfDMbY=JOtndkvQesSAHPrqouiLhTXEUfDMbw.get('title')
   JOtndkvQesSAHPrqouiLhTXEUfDMbF=''
   if JOtndkvQesSAHPrqouiLhTXEUfDMbw.get('mode')=='SEARCH_GROUP' and JOtndkvQesSAHPrqouiLhTXEUfDMGj ==JOtndkvQesSAHPrqouiLhTXEUfDMmy:continue
   elif JOtndkvQesSAHPrqouiLhTXEUfDMbw.get('mode')=='SEARCH_HISTORY' and JOtndkvQesSAHPrqouiLhTXEUfDMGN==JOtndkvQesSAHPrqouiLhTXEUfDMmy:continue
   elif JOtndkvQesSAHPrqouiLhTXEUfDMbw.get('mode')=='TOTAL_SEARCH' and JOtndkvQesSAHPrqouiLhTXEUfDMGC ==JOtndkvQesSAHPrqouiLhTXEUfDMmy:continue
   elif JOtndkvQesSAHPrqouiLhTXEUfDMbw.get('mode')=='TOTAL_HISTORY' and JOtndkvQesSAHPrqouiLhTXEUfDMGp==JOtndkvQesSAHPrqouiLhTXEUfDMmy:continue
   elif JOtndkvQesSAHPrqouiLhTXEUfDMbw.get('mode')=='MENU_BOOKMARK' and JOtndkvQesSAHPrqouiLhTXEUfDMbG==JOtndkvQesSAHPrqouiLhTXEUfDMmy:continue
   JOtndkvQesSAHPrqouiLhTXEUfDMbI={'mode':JOtndkvQesSAHPrqouiLhTXEUfDMbw.get('mode'),'sCode':JOtndkvQesSAHPrqouiLhTXEUfDMbw.get('sCode'),'sIndex':JOtndkvQesSAHPrqouiLhTXEUfDMbw.get('sIndex'),'sType':JOtndkvQesSAHPrqouiLhTXEUfDMbw.get('sType'),'suburl':JOtndkvQesSAHPrqouiLhTXEUfDMbw.get('suburl'),'subapi':JOtndkvQesSAHPrqouiLhTXEUfDMbw.get('subapi'),'page':JOtndkvQesSAHPrqouiLhTXEUfDMbw.get('page'),'orderby':JOtndkvQesSAHPrqouiLhTXEUfDMbw.get('orderby'),'ordernm':JOtndkvQesSAHPrqouiLhTXEUfDMbw.get('ordernm')}
   if JOtndkvQesSAHPrqouiLhTXEUfDMbw.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    JOtndkvQesSAHPrqouiLhTXEUfDMbx=JOtndkvQesSAHPrqouiLhTXEUfDMmy
    JOtndkvQesSAHPrqouiLhTXEUfDMby =JOtndkvQesSAHPrqouiLhTXEUfDMmx
   else:
    JOtndkvQesSAHPrqouiLhTXEUfDMbx=JOtndkvQesSAHPrqouiLhTXEUfDMmx
    JOtndkvQesSAHPrqouiLhTXEUfDMby =JOtndkvQesSAHPrqouiLhTXEUfDMmy
   if 'icon' in JOtndkvQesSAHPrqouiLhTXEUfDMbw:JOtndkvQesSAHPrqouiLhTXEUfDMbF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',JOtndkvQesSAHPrqouiLhTXEUfDMbw.get('icon')) 
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.add_dir(JOtndkvQesSAHPrqouiLhTXEUfDMbY,sublabel='',img=JOtndkvQesSAHPrqouiLhTXEUfDMbF,infoLabels=JOtndkvQesSAHPrqouiLhTXEUfDMmI,isFolder=JOtndkvQesSAHPrqouiLhTXEUfDMbx,params=JOtndkvQesSAHPrqouiLhTXEUfDMbI,isLink=JOtndkvQesSAHPrqouiLhTXEUfDMby)
  xbmcplugin.endOfDirectory(JOtndkvQesSAHPrqouiLhTXEUfDMGg._addon_handle,cacheToDisc=JOtndkvQesSAHPrqouiLhTXEUfDMmx)
 def dp_Search_Group(JOtndkvQesSAHPrqouiLhTXEUfDMGg,args):
  if 'search_key' in args:
   JOtndkvQesSAHPrqouiLhTXEUfDMbV=args.get('search_key')
  else:
   JOtndkvQesSAHPrqouiLhTXEUfDMbV=JOtndkvQesSAHPrqouiLhTXEUfDMGg.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not JOtndkvQesSAHPrqouiLhTXEUfDMbV:
    return
  for JOtndkvQesSAHPrqouiLhTXEUfDMbB in JOtndkvQesSAHPrqouiLhTXEUfDMGR:
   JOtndkvQesSAHPrqouiLhTXEUfDMbj =JOtndkvQesSAHPrqouiLhTXEUfDMbB.get('mode')
   JOtndkvQesSAHPrqouiLhTXEUfDMbN=JOtndkvQesSAHPrqouiLhTXEUfDMbB.get('sType')
   JOtndkvQesSAHPrqouiLhTXEUfDMbY=JOtndkvQesSAHPrqouiLhTXEUfDMbB.get('title')
   (JOtndkvQesSAHPrqouiLhTXEUfDMbC,JOtndkvQesSAHPrqouiLhTXEUfDMbp)=JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.Get_Search_List(JOtndkvQesSAHPrqouiLhTXEUfDMbV,JOtndkvQesSAHPrqouiLhTXEUfDMbN,1,exclusion21=JOtndkvQesSAHPrqouiLhTXEUfDMGg.get_settings_exclusion21())
   JOtndkvQesSAHPrqouiLhTXEUfDMKG={'plot':'검색어 : '+JOtndkvQesSAHPrqouiLhTXEUfDMbV+'\n\n'+JOtndkvQesSAHPrqouiLhTXEUfDMGg.Search_FreeList(JOtndkvQesSAHPrqouiLhTXEUfDMbC)}
   JOtndkvQesSAHPrqouiLhTXEUfDMbI={'mode':JOtndkvQesSAHPrqouiLhTXEUfDMbj,'sType':JOtndkvQesSAHPrqouiLhTXEUfDMbN,'search_key':JOtndkvQesSAHPrqouiLhTXEUfDMbV,'page':'1',}
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.add_dir(JOtndkvQesSAHPrqouiLhTXEUfDMbY,sublabel='',img='',infoLabels=JOtndkvQesSAHPrqouiLhTXEUfDMKG,isFolder=JOtndkvQesSAHPrqouiLhTXEUfDMmx,params=JOtndkvQesSAHPrqouiLhTXEUfDMbI)
  if JOtndkvQesSAHPrqouiLhTXEUfDMmB(JOtndkvQesSAHPrqouiLhTXEUfDMGR)>0:xbmcplugin.endOfDirectory(JOtndkvQesSAHPrqouiLhTXEUfDMGg._addon_handle,cacheToDisc=JOtndkvQesSAHPrqouiLhTXEUfDMmx)
  JOtndkvQesSAHPrqouiLhTXEUfDMGg.Save_Searched_List(JOtndkvQesSAHPrqouiLhTXEUfDMbV)
 def Search_FreeList(JOtndkvQesSAHPrqouiLhTXEUfDMGg,search_list):
  JOtndkvQesSAHPrqouiLhTXEUfDMKb=''
  JOtndkvQesSAHPrqouiLhTXEUfDMKR=7
  try:
   if JOtndkvQesSAHPrqouiLhTXEUfDMmB(search_list)==0:return '검색결과 없음'
   for i in JOtndkvQesSAHPrqouiLhTXEUfDMmj(JOtndkvQesSAHPrqouiLhTXEUfDMmB(search_list)):
    if i>=JOtndkvQesSAHPrqouiLhTXEUfDMKR:
     JOtndkvQesSAHPrqouiLhTXEUfDMKb=JOtndkvQesSAHPrqouiLhTXEUfDMKb+'...'
     break
    JOtndkvQesSAHPrqouiLhTXEUfDMKb=JOtndkvQesSAHPrqouiLhTXEUfDMKb+search_list[i]['title']+'\n'
  except:
   return ''
  return JOtndkvQesSAHPrqouiLhTXEUfDMKb
 def dp_Watch_Group(JOtndkvQesSAHPrqouiLhTXEUfDMGg,args):
  for JOtndkvQesSAHPrqouiLhTXEUfDMKz in JOtndkvQesSAHPrqouiLhTXEUfDMGz:
   JOtndkvQesSAHPrqouiLhTXEUfDMbY=JOtndkvQesSAHPrqouiLhTXEUfDMKz.get('title')
   JOtndkvQesSAHPrqouiLhTXEUfDMbI={'mode':JOtndkvQesSAHPrqouiLhTXEUfDMKz.get('mode'),'sType':JOtndkvQesSAHPrqouiLhTXEUfDMKz.get('sType')}
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.add_dir(JOtndkvQesSAHPrqouiLhTXEUfDMbY,sublabel='',img='',infoLabels=JOtndkvQesSAHPrqouiLhTXEUfDMmI,isFolder=JOtndkvQesSAHPrqouiLhTXEUfDMmx,params=JOtndkvQesSAHPrqouiLhTXEUfDMbI)
  if JOtndkvQesSAHPrqouiLhTXEUfDMmB(JOtndkvQesSAHPrqouiLhTXEUfDMGz)>0:xbmcplugin.endOfDirectory(JOtndkvQesSAHPrqouiLhTXEUfDMGg._addon_handle,cacheToDisc=JOtndkvQesSAHPrqouiLhTXEUfDMmx)
 def dp_Search_History(JOtndkvQesSAHPrqouiLhTXEUfDMGg,args):
  JOtndkvQesSAHPrqouiLhTXEUfDMKa=JOtndkvQesSAHPrqouiLhTXEUfDMGg.Load_List_File('search')
  for JOtndkvQesSAHPrqouiLhTXEUfDMKm in JOtndkvQesSAHPrqouiLhTXEUfDMKa:
   JOtndkvQesSAHPrqouiLhTXEUfDMKg=JOtndkvQesSAHPrqouiLhTXEUfDMmV(urllib.parse.parse_qsl(JOtndkvQesSAHPrqouiLhTXEUfDMKm))
   JOtndkvQesSAHPrqouiLhTXEUfDMKY=JOtndkvQesSAHPrqouiLhTXEUfDMKg.get('skey').strip()
   JOtndkvQesSAHPrqouiLhTXEUfDMbI={'mode':'SEARCH_GROUP','search_key':JOtndkvQesSAHPrqouiLhTXEUfDMKY,}
   JOtndkvQesSAHPrqouiLhTXEUfDMKl={'mode':'SEARCH_REMOVE','sType':'ONE','skey':JOtndkvQesSAHPrqouiLhTXEUfDMKY,}
   JOtndkvQesSAHPrqouiLhTXEUfDMKw=urllib.parse.urlencode(JOtndkvQesSAHPrqouiLhTXEUfDMKl)
   JOtndkvQesSAHPrqouiLhTXEUfDMKF=[('선택된 검색어 ( %s ) 삭제'%(JOtndkvQesSAHPrqouiLhTXEUfDMKY),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(JOtndkvQesSAHPrqouiLhTXEUfDMKw))]
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.add_dir(JOtndkvQesSAHPrqouiLhTXEUfDMKY,sublabel='',img=JOtndkvQesSAHPrqouiLhTXEUfDMmI,infoLabels=JOtndkvQesSAHPrqouiLhTXEUfDMmI,isFolder=JOtndkvQesSAHPrqouiLhTXEUfDMmx,params=JOtndkvQesSAHPrqouiLhTXEUfDMbI,ContextMenu=JOtndkvQesSAHPrqouiLhTXEUfDMKF)
  JOtndkvQesSAHPrqouiLhTXEUfDMKI={'plot':'검색목록 전체를 삭제합니다.'}
  JOtndkvQesSAHPrqouiLhTXEUfDMbY='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  JOtndkvQesSAHPrqouiLhTXEUfDMbI={'mode':'SEARCH_REMOVE','sType':'ALL','skey':'-',}
  JOtndkvQesSAHPrqouiLhTXEUfDMbF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  JOtndkvQesSAHPrqouiLhTXEUfDMGg.add_dir(JOtndkvQesSAHPrqouiLhTXEUfDMbY,sublabel='',img=JOtndkvQesSAHPrqouiLhTXEUfDMbF,infoLabels=JOtndkvQesSAHPrqouiLhTXEUfDMKI,isFolder=JOtndkvQesSAHPrqouiLhTXEUfDMmy,params=JOtndkvQesSAHPrqouiLhTXEUfDMbI,isLink=JOtndkvQesSAHPrqouiLhTXEUfDMmx)
  xbmcplugin.endOfDirectory(JOtndkvQesSAHPrqouiLhTXEUfDMGg._addon_handle,cacheToDisc=JOtndkvQesSAHPrqouiLhTXEUfDMmy)
 def dp_Search_List(JOtndkvQesSAHPrqouiLhTXEUfDMGg,args):
  JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.SaveCredential(JOtndkvQesSAHPrqouiLhTXEUfDMGg.get_winCredential())
  JOtndkvQesSAHPrqouiLhTXEUfDMbN =args.get('sType')
  JOtndkvQesSAHPrqouiLhTXEUfDMKx =JOtndkvQesSAHPrqouiLhTXEUfDMmW(args.get('page'))
  if 'search_key' in args:
   JOtndkvQesSAHPrqouiLhTXEUfDMbV=args.get('search_key')
  else:
   JOtndkvQesSAHPrqouiLhTXEUfDMbV=JOtndkvQesSAHPrqouiLhTXEUfDMGg.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not JOtndkvQesSAHPrqouiLhTXEUfDMbV:
    xbmcplugin.endOfDirectory(JOtndkvQesSAHPrqouiLhTXEUfDMGg._addon_handle)
    return
  JOtndkvQesSAHPrqouiLhTXEUfDMKy,JOtndkvQesSAHPrqouiLhTXEUfDMbp=JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.Get_Search_List(JOtndkvQesSAHPrqouiLhTXEUfDMbV,JOtndkvQesSAHPrqouiLhTXEUfDMbN,JOtndkvQesSAHPrqouiLhTXEUfDMKx,exclusion21=JOtndkvQesSAHPrqouiLhTXEUfDMGg.get_settings_exclusion21())
  for JOtndkvQesSAHPrqouiLhTXEUfDMKW in JOtndkvQesSAHPrqouiLhTXEUfDMKy:
   JOtndkvQesSAHPrqouiLhTXEUfDMbY =JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('title')
   JOtndkvQesSAHPrqouiLhTXEUfDMKc=JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('thumbnail')
   JOtndkvQesSAHPrqouiLhTXEUfDMKV =JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('age')
   if JOtndkvQesSAHPrqouiLhTXEUfDMKV=='18' or JOtndkvQesSAHPrqouiLhTXEUfDMKV=='19' or JOtndkvQesSAHPrqouiLhTXEUfDMKV=='21':JOtndkvQesSAHPrqouiLhTXEUfDMbY+=' (%s)'%(JOtndkvQesSAHPrqouiLhTXEUfDMKV)
   JOtndkvQesSAHPrqouiLhTXEUfDMKI={'mediatype':'tvshow' if JOtndkvQesSAHPrqouiLhTXEUfDMbN=='vod' else 'movie','mpaa':JOtndkvQesSAHPrqouiLhTXEUfDMKV,'title':JOtndkvQesSAHPrqouiLhTXEUfDMbY,'plot':JOtndkvQesSAHPrqouiLhTXEUfDMbY}
   if JOtndkvQesSAHPrqouiLhTXEUfDMbN=='vod':
    JOtndkvQesSAHPrqouiLhTXEUfDMbI={'mode':'EPISODE_LIST','videoid':JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('videoid'),'vidtype':JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('vidtype'),'page':'1'}
    JOtndkvQesSAHPrqouiLhTXEUfDMbx=JOtndkvQesSAHPrqouiLhTXEUfDMmx
   else:
    JOtndkvQesSAHPrqouiLhTXEUfDMbI={'mode':'MOVIE','contentid':JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('videoid'),'title':JOtndkvQesSAHPrqouiLhTXEUfDMbY,'thumbnail':JOtndkvQesSAHPrqouiLhTXEUfDMKc,'age':JOtndkvQesSAHPrqouiLhTXEUfDMKV}
    JOtndkvQesSAHPrqouiLhTXEUfDMbx=JOtndkvQesSAHPrqouiLhTXEUfDMmy
   if JOtndkvQesSAHPrqouiLhTXEUfDMGg.get_settings_makebookmark():
    JOtndkvQesSAHPrqouiLhTXEUfDMKB={'videoid':JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('videoid'),'vidtype':'tvshow' if JOtndkvQesSAHPrqouiLhTXEUfDMbN=='vod' else 'movie','vtitle':JOtndkvQesSAHPrqouiLhTXEUfDMbY,'vsubtitle':'','contenttype':JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('vidtype'),}
    JOtndkvQesSAHPrqouiLhTXEUfDMKj=json.dumps(JOtndkvQesSAHPrqouiLhTXEUfDMKB)
    JOtndkvQesSAHPrqouiLhTXEUfDMKj=urllib.parse.quote(JOtndkvQesSAHPrqouiLhTXEUfDMKj)
    JOtndkvQesSAHPrqouiLhTXEUfDMKN='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(JOtndkvQesSAHPrqouiLhTXEUfDMKj)
    JOtndkvQesSAHPrqouiLhTXEUfDMKF=[('(통합) 찜 영상에 추가',JOtndkvQesSAHPrqouiLhTXEUfDMKN)]
   else:
    JOtndkvQesSAHPrqouiLhTXEUfDMKF=JOtndkvQesSAHPrqouiLhTXEUfDMmI
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.add_dir(JOtndkvQesSAHPrqouiLhTXEUfDMbY,sublabel='',img=JOtndkvQesSAHPrqouiLhTXEUfDMKc,infoLabels=JOtndkvQesSAHPrqouiLhTXEUfDMKI,isFolder=JOtndkvQesSAHPrqouiLhTXEUfDMbx,params=JOtndkvQesSAHPrqouiLhTXEUfDMbI,ContextMenu=JOtndkvQesSAHPrqouiLhTXEUfDMKF)
  if JOtndkvQesSAHPrqouiLhTXEUfDMbp:
   JOtndkvQesSAHPrqouiLhTXEUfDMbI['mode'] ='SEARCH_LIST' 
   JOtndkvQesSAHPrqouiLhTXEUfDMbI['sType']=JOtndkvQesSAHPrqouiLhTXEUfDMbN 
   JOtndkvQesSAHPrqouiLhTXEUfDMbI['page'] =JOtndkvQesSAHPrqouiLhTXEUfDMmN(JOtndkvQesSAHPrqouiLhTXEUfDMKx+1)
   JOtndkvQesSAHPrqouiLhTXEUfDMbI['search_key']=JOtndkvQesSAHPrqouiLhTXEUfDMbV
   JOtndkvQesSAHPrqouiLhTXEUfDMbY='[B]%s >>[/B]'%'다음 페이지'
   JOtndkvQesSAHPrqouiLhTXEUfDMKC=JOtndkvQesSAHPrqouiLhTXEUfDMmN(JOtndkvQesSAHPrqouiLhTXEUfDMKx+1)
   JOtndkvQesSAHPrqouiLhTXEUfDMbF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.add_dir(JOtndkvQesSAHPrqouiLhTXEUfDMbY,sublabel=JOtndkvQesSAHPrqouiLhTXEUfDMKC,img=JOtndkvQesSAHPrqouiLhTXEUfDMbF,infoLabels=JOtndkvQesSAHPrqouiLhTXEUfDMmI,isFolder=JOtndkvQesSAHPrqouiLhTXEUfDMmx,params=JOtndkvQesSAHPrqouiLhTXEUfDMbI)
  if JOtndkvQesSAHPrqouiLhTXEUfDMbN=='movie':xbmcplugin.setContent(JOtndkvQesSAHPrqouiLhTXEUfDMGg._addon_handle,'movies')
  else:xbmcplugin.setContent(JOtndkvQesSAHPrqouiLhTXEUfDMGg._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(JOtndkvQesSAHPrqouiLhTXEUfDMGg._addon_handle,cacheToDisc=JOtndkvQesSAHPrqouiLhTXEUfDMmy)
 def dp_Watch_List(JOtndkvQesSAHPrqouiLhTXEUfDMGg,args):
  JOtndkvQesSAHPrqouiLhTXEUfDMbN =args.get('sType')
  JOtndkvQesSAHPrqouiLhTXEUfDMba=JOtndkvQesSAHPrqouiLhTXEUfDMGg.get_settings_direct_replay()
  JOtndkvQesSAHPrqouiLhTXEUfDMKy=JOtndkvQesSAHPrqouiLhTXEUfDMGg.Load_List_File(JOtndkvQesSAHPrqouiLhTXEUfDMbN)
  for JOtndkvQesSAHPrqouiLhTXEUfDMKW in JOtndkvQesSAHPrqouiLhTXEUfDMKy:
   JOtndkvQesSAHPrqouiLhTXEUfDMKg=JOtndkvQesSAHPrqouiLhTXEUfDMmV(urllib.parse.parse_qsl(JOtndkvQesSAHPrqouiLhTXEUfDMKW))
   JOtndkvQesSAHPrqouiLhTXEUfDMKp =JOtndkvQesSAHPrqouiLhTXEUfDMKg.get('code').strip()
   JOtndkvQesSAHPrqouiLhTXEUfDMbY =JOtndkvQesSAHPrqouiLhTXEUfDMKg.get('title').strip()
   JOtndkvQesSAHPrqouiLhTXEUfDMKC =JOtndkvQesSAHPrqouiLhTXEUfDMKg.get('subtitle').strip()
   if JOtndkvQesSAHPrqouiLhTXEUfDMKC=='None':JOtndkvQesSAHPrqouiLhTXEUfDMKC=''
   JOtndkvQesSAHPrqouiLhTXEUfDMKc=JOtndkvQesSAHPrqouiLhTXEUfDMKg.get('img').strip()
   JOtndkvQesSAHPrqouiLhTXEUfDMRG =JOtndkvQesSAHPrqouiLhTXEUfDMKg.get('videoid').strip()
   try:
    JOtndkvQesSAHPrqouiLhTXEUfDMKc=JOtndkvQesSAHPrqouiLhTXEUfDMKc.replace('\'','\"')
    JOtndkvQesSAHPrqouiLhTXEUfDMKc=json.loads(JOtndkvQesSAHPrqouiLhTXEUfDMKc)
   except:
    JOtndkvQesSAHPrqouiLhTXEUfDMmI
   JOtndkvQesSAHPrqouiLhTXEUfDMKI={'plot':'%s\n%s'%(JOtndkvQesSAHPrqouiLhTXEUfDMbY,JOtndkvQesSAHPrqouiLhTXEUfDMKC)}
   if JOtndkvQesSAHPrqouiLhTXEUfDMbN=='vod':
    if JOtndkvQesSAHPrqouiLhTXEUfDMba==JOtndkvQesSAHPrqouiLhTXEUfDMmy or JOtndkvQesSAHPrqouiLhTXEUfDMRG==JOtndkvQesSAHPrqouiLhTXEUfDMmI:
     JOtndkvQesSAHPrqouiLhTXEUfDMbI={'mode':'EPISODE_LIST','videoid':JOtndkvQesSAHPrqouiLhTXEUfDMKp,'vidtype':'programid','page':'1'}
     JOtndkvQesSAHPrqouiLhTXEUfDMbx=JOtndkvQesSAHPrqouiLhTXEUfDMmx
    else:
     JOtndkvQesSAHPrqouiLhTXEUfDMbI={'mode':'VOD','programid':JOtndkvQesSAHPrqouiLhTXEUfDMKp,'contentid':JOtndkvQesSAHPrqouiLhTXEUfDMRG,'title':JOtndkvQesSAHPrqouiLhTXEUfDMbY,'subtitle':JOtndkvQesSAHPrqouiLhTXEUfDMKC,'thumbnail':JOtndkvQesSAHPrqouiLhTXEUfDMKc}
     JOtndkvQesSAHPrqouiLhTXEUfDMbx=JOtndkvQesSAHPrqouiLhTXEUfDMmy
   else:
    JOtndkvQesSAHPrqouiLhTXEUfDMbI={'mode':'MOVIE','contentid':JOtndkvQesSAHPrqouiLhTXEUfDMKp,'title':JOtndkvQesSAHPrqouiLhTXEUfDMbY,'subtitle':JOtndkvQesSAHPrqouiLhTXEUfDMKC,'thumbnail':JOtndkvQesSAHPrqouiLhTXEUfDMKc}
    JOtndkvQesSAHPrqouiLhTXEUfDMbx=JOtndkvQesSAHPrqouiLhTXEUfDMmy
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.add_dir(JOtndkvQesSAHPrqouiLhTXEUfDMbY,sublabel=JOtndkvQesSAHPrqouiLhTXEUfDMKC,img=JOtndkvQesSAHPrqouiLhTXEUfDMKc,infoLabels=JOtndkvQesSAHPrqouiLhTXEUfDMKI,isFolder=JOtndkvQesSAHPrqouiLhTXEUfDMbx,params=JOtndkvQesSAHPrqouiLhTXEUfDMbI)
  JOtndkvQesSAHPrqouiLhTXEUfDMKI={'plot':'시청목록을 삭제합니다.'}
  JOtndkvQesSAHPrqouiLhTXEUfDMbY='*** 시청목록 삭제 ***'
  JOtndkvQesSAHPrqouiLhTXEUfDMbI={'mode':'MYVIEW_REMOVE','sType':JOtndkvQesSAHPrqouiLhTXEUfDMbN,'skey':'-',}
  JOtndkvQesSAHPrqouiLhTXEUfDMbF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  JOtndkvQesSAHPrqouiLhTXEUfDMGg.add_dir(JOtndkvQesSAHPrqouiLhTXEUfDMbY,sublabel='',img=JOtndkvQesSAHPrqouiLhTXEUfDMbF,infoLabels=JOtndkvQesSAHPrqouiLhTXEUfDMKI,isFolder=JOtndkvQesSAHPrqouiLhTXEUfDMmy,params=JOtndkvQesSAHPrqouiLhTXEUfDMbI,isLink=JOtndkvQesSAHPrqouiLhTXEUfDMmx)
  if JOtndkvQesSAHPrqouiLhTXEUfDMbN=='movie':xbmcplugin.setContent(JOtndkvQesSAHPrqouiLhTXEUfDMGg._addon_handle,'movies')
  else:xbmcplugin.setContent(JOtndkvQesSAHPrqouiLhTXEUfDMGg._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(JOtndkvQesSAHPrqouiLhTXEUfDMGg._addon_handle,cacheToDisc=JOtndkvQesSAHPrqouiLhTXEUfDMmy)
 def Load_List_File(JOtndkvQesSAHPrqouiLhTXEUfDMGg,JOtndkvQesSAHPrqouiLhTXEUfDMRx): 
  try:
   if JOtndkvQesSAHPrqouiLhTXEUfDMRx=='search':
    JOtndkvQesSAHPrqouiLhTXEUfDMRb=JOtndkvQesSAHPrqouiLhTXEUfDMGm
   elif JOtndkvQesSAHPrqouiLhTXEUfDMRx in['vod','movie']:
    JOtndkvQesSAHPrqouiLhTXEUfDMRb=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%JOtndkvQesSAHPrqouiLhTXEUfDMRx))
   else:
    return[]
   fp=JOtndkvQesSAHPrqouiLhTXEUfDMmC(JOtndkvQesSAHPrqouiLhTXEUfDMRb,'r',-1,'utf-8')
   JOtndkvQesSAHPrqouiLhTXEUfDMRK=fp.readlines()
   fp.close()
  except:
   JOtndkvQesSAHPrqouiLhTXEUfDMRK=[]
  return JOtndkvQesSAHPrqouiLhTXEUfDMRK
 def Save_Watched_List(JOtndkvQesSAHPrqouiLhTXEUfDMGg,JOtndkvQesSAHPrqouiLhTXEUfDMap,JOtndkvQesSAHPrqouiLhTXEUfDMGw):
  try:
   JOtndkvQesSAHPrqouiLhTXEUfDMRz=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%JOtndkvQesSAHPrqouiLhTXEUfDMap))
   JOtndkvQesSAHPrqouiLhTXEUfDMRa=JOtndkvQesSAHPrqouiLhTXEUfDMGg.Load_List_File(JOtndkvQesSAHPrqouiLhTXEUfDMap) 
   fp=JOtndkvQesSAHPrqouiLhTXEUfDMmC(JOtndkvQesSAHPrqouiLhTXEUfDMRz,'w',-1,'utf-8')
   JOtndkvQesSAHPrqouiLhTXEUfDMRm=urllib.parse.urlencode(JOtndkvQesSAHPrqouiLhTXEUfDMGw)
   JOtndkvQesSAHPrqouiLhTXEUfDMRm=JOtndkvQesSAHPrqouiLhTXEUfDMRm+'\n'
   fp.write(JOtndkvQesSAHPrqouiLhTXEUfDMRm)
   JOtndkvQesSAHPrqouiLhTXEUfDMRg=0
   for JOtndkvQesSAHPrqouiLhTXEUfDMRY in JOtndkvQesSAHPrqouiLhTXEUfDMRa:
    JOtndkvQesSAHPrqouiLhTXEUfDMRl=JOtndkvQesSAHPrqouiLhTXEUfDMmV(urllib.parse.parse_qsl(JOtndkvQesSAHPrqouiLhTXEUfDMRY))
    JOtndkvQesSAHPrqouiLhTXEUfDMRw=JOtndkvQesSAHPrqouiLhTXEUfDMGw.get('code').strip()
    JOtndkvQesSAHPrqouiLhTXEUfDMRF=JOtndkvQesSAHPrqouiLhTXEUfDMRl.get('code').strip()
    if JOtndkvQesSAHPrqouiLhTXEUfDMap=='vod' and JOtndkvQesSAHPrqouiLhTXEUfDMGg.get_settings_direct_replay()==JOtndkvQesSAHPrqouiLhTXEUfDMmx:
     JOtndkvQesSAHPrqouiLhTXEUfDMRw=JOtndkvQesSAHPrqouiLhTXEUfDMGw.get('videoid').strip()
     JOtndkvQesSAHPrqouiLhTXEUfDMRF=JOtndkvQesSAHPrqouiLhTXEUfDMRl.get('videoid').strip()if JOtndkvQesSAHPrqouiLhTXEUfDMRF!=JOtndkvQesSAHPrqouiLhTXEUfDMmI else '-'
    if JOtndkvQesSAHPrqouiLhTXEUfDMRw!=JOtndkvQesSAHPrqouiLhTXEUfDMRF:
     fp.write(JOtndkvQesSAHPrqouiLhTXEUfDMRY)
     JOtndkvQesSAHPrqouiLhTXEUfDMRg+=1
     if JOtndkvQesSAHPrqouiLhTXEUfDMRg>=50:break
   fp.close()
  except:
   JOtndkvQesSAHPrqouiLhTXEUfDMmI
 def Delete_List_File(JOtndkvQesSAHPrqouiLhTXEUfDMGg,JOtndkvQesSAHPrqouiLhTXEUfDMRx,skey='-'):
  if JOtndkvQesSAHPrqouiLhTXEUfDMRx=='ALL':
   try:
    JOtndkvQesSAHPrqouiLhTXEUfDMRb=JOtndkvQesSAHPrqouiLhTXEUfDMGm
    fp=JOtndkvQesSAHPrqouiLhTXEUfDMmC(JOtndkvQesSAHPrqouiLhTXEUfDMRb,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    JOtndkvQesSAHPrqouiLhTXEUfDMmI
  elif JOtndkvQesSAHPrqouiLhTXEUfDMRx=='ONE':
   try:
    JOtndkvQesSAHPrqouiLhTXEUfDMRb=JOtndkvQesSAHPrqouiLhTXEUfDMGm
    JOtndkvQesSAHPrqouiLhTXEUfDMRa=JOtndkvQesSAHPrqouiLhTXEUfDMGg.Load_List_File('search') 
    fp=JOtndkvQesSAHPrqouiLhTXEUfDMmC(JOtndkvQesSAHPrqouiLhTXEUfDMRb,'w',-1,'utf-8')
    for JOtndkvQesSAHPrqouiLhTXEUfDMRY in JOtndkvQesSAHPrqouiLhTXEUfDMRa:
     JOtndkvQesSAHPrqouiLhTXEUfDMRl=JOtndkvQesSAHPrqouiLhTXEUfDMmV(urllib.parse.parse_qsl(JOtndkvQesSAHPrqouiLhTXEUfDMRY))
     JOtndkvQesSAHPrqouiLhTXEUfDMRI=JOtndkvQesSAHPrqouiLhTXEUfDMRl.get('skey').strip()
     if skey!=JOtndkvQesSAHPrqouiLhTXEUfDMRI:
      fp.write(JOtndkvQesSAHPrqouiLhTXEUfDMRY)
    fp.close()
   except:
    JOtndkvQesSAHPrqouiLhTXEUfDMmI
  elif JOtndkvQesSAHPrqouiLhTXEUfDMRx in['vod','movie']:
   try:
    JOtndkvQesSAHPrqouiLhTXEUfDMRb=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%JOtndkvQesSAHPrqouiLhTXEUfDMRx))
    fp=JOtndkvQesSAHPrqouiLhTXEUfDMmC(JOtndkvQesSAHPrqouiLhTXEUfDMRb,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    JOtndkvQesSAHPrqouiLhTXEUfDMmI
 def dp_Listfile_Delete(JOtndkvQesSAHPrqouiLhTXEUfDMGg,args):
  JOtndkvQesSAHPrqouiLhTXEUfDMRx=args.get('sType')
  JOtndkvQesSAHPrqouiLhTXEUfDMKY =args.get('skey')
  JOtndkvQesSAHPrqouiLhTXEUfDMGI=xbmcgui.Dialog()
  if JOtndkvQesSAHPrqouiLhTXEUfDMRx=='ALL':
   JOtndkvQesSAHPrqouiLhTXEUfDMRy=JOtndkvQesSAHPrqouiLhTXEUfDMGI.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif JOtndkvQesSAHPrqouiLhTXEUfDMRx=='ONE':
   JOtndkvQesSAHPrqouiLhTXEUfDMRy=JOtndkvQesSAHPrqouiLhTXEUfDMGI.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif JOtndkvQesSAHPrqouiLhTXEUfDMRx in['vod','movie']:
   JOtndkvQesSAHPrqouiLhTXEUfDMRy=JOtndkvQesSAHPrqouiLhTXEUfDMGI.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if JOtndkvQesSAHPrqouiLhTXEUfDMRy==JOtndkvQesSAHPrqouiLhTXEUfDMmy:sys.exit()
  JOtndkvQesSAHPrqouiLhTXEUfDMGg.Delete_List_File(JOtndkvQesSAHPrqouiLhTXEUfDMRx,skey=JOtndkvQesSAHPrqouiLhTXEUfDMKY)
  xbmc.executebuiltin("Container.Refresh")
 def Save_Searched_List(JOtndkvQesSAHPrqouiLhTXEUfDMGg,JOtndkvQesSAHPrqouiLhTXEUfDMbV):
  try:
   JOtndkvQesSAHPrqouiLhTXEUfDMRW=JOtndkvQesSAHPrqouiLhTXEUfDMGm
   JOtndkvQesSAHPrqouiLhTXEUfDMRa=JOtndkvQesSAHPrqouiLhTXEUfDMGg.Load_List_File('search') 
   JOtndkvQesSAHPrqouiLhTXEUfDMRc={'skey':JOtndkvQesSAHPrqouiLhTXEUfDMbV.strip()}
   fp=JOtndkvQesSAHPrqouiLhTXEUfDMmC(JOtndkvQesSAHPrqouiLhTXEUfDMRW,'w',-1,'utf-8')
   JOtndkvQesSAHPrqouiLhTXEUfDMRm=urllib.parse.urlencode(JOtndkvQesSAHPrqouiLhTXEUfDMRc)
   JOtndkvQesSAHPrqouiLhTXEUfDMRm=JOtndkvQesSAHPrqouiLhTXEUfDMRm+'\n'
   fp.write(JOtndkvQesSAHPrqouiLhTXEUfDMRm)
   JOtndkvQesSAHPrqouiLhTXEUfDMRg=0
   for JOtndkvQesSAHPrqouiLhTXEUfDMRY in JOtndkvQesSAHPrqouiLhTXEUfDMRa:
    JOtndkvQesSAHPrqouiLhTXEUfDMRl=JOtndkvQesSAHPrqouiLhTXEUfDMmV(urllib.parse.parse_qsl(JOtndkvQesSAHPrqouiLhTXEUfDMRY))
    JOtndkvQesSAHPrqouiLhTXEUfDMRw=JOtndkvQesSAHPrqouiLhTXEUfDMRc.get('skey').strip()
    JOtndkvQesSAHPrqouiLhTXEUfDMRF=JOtndkvQesSAHPrqouiLhTXEUfDMRl.get('skey').strip()
    if JOtndkvQesSAHPrqouiLhTXEUfDMRw!=JOtndkvQesSAHPrqouiLhTXEUfDMRF:
     fp.write(JOtndkvQesSAHPrqouiLhTXEUfDMRY)
     JOtndkvQesSAHPrqouiLhTXEUfDMRg+=1
     if JOtndkvQesSAHPrqouiLhTXEUfDMRg>=50:break
   fp.close()
  except:
   JOtndkvQesSAHPrqouiLhTXEUfDMmI
 def dp_Global_Search(JOtndkvQesSAHPrqouiLhTXEUfDMGg,args):
  JOtndkvQesSAHPrqouiLhTXEUfDMbj=args.get('mode')
  if JOtndkvQesSAHPrqouiLhTXEUfDMbj=='TOTAL_SEARCH':
   JOtndkvQesSAHPrqouiLhTXEUfDMRV='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   JOtndkvQesSAHPrqouiLhTXEUfDMRV='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(JOtndkvQesSAHPrqouiLhTXEUfDMRV)
 def dp_Bookmark_Menu(JOtndkvQesSAHPrqouiLhTXEUfDMGg,args):
  JOtndkvQesSAHPrqouiLhTXEUfDMRV='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(JOtndkvQesSAHPrqouiLhTXEUfDMRV)
 def login_main(JOtndkvQesSAHPrqouiLhTXEUfDMGg):
  (JOtndkvQesSAHPrqouiLhTXEUfDMRB,JOtndkvQesSAHPrqouiLhTXEUfDMRj,JOtndkvQesSAHPrqouiLhTXEUfDMRN)=JOtndkvQesSAHPrqouiLhTXEUfDMGg.get_settings_login_info()
  if not(JOtndkvQesSAHPrqouiLhTXEUfDMRB and JOtndkvQesSAHPrqouiLhTXEUfDMRj):
   JOtndkvQesSAHPrqouiLhTXEUfDMGI=xbmcgui.Dialog()
   JOtndkvQesSAHPrqouiLhTXEUfDMRy=JOtndkvQesSAHPrqouiLhTXEUfDMGI.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if JOtndkvQesSAHPrqouiLhTXEUfDMRy==JOtndkvQesSAHPrqouiLhTXEUfDMmx:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if JOtndkvQesSAHPrqouiLhTXEUfDMGg.get_winEpisodeOrderby()=='':
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.set_winEpisodeOrderby('desc')
  if JOtndkvQesSAHPrqouiLhTXEUfDMGg.cookiefile_check():return
  JOtndkvQesSAHPrqouiLhTXEUfDMRC =JOtndkvQesSAHPrqouiLhTXEUfDMmW(JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  JOtndkvQesSAHPrqouiLhTXEUfDMRp=xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINTIME')
  if JOtndkvQesSAHPrqouiLhTXEUfDMRp==JOtndkvQesSAHPrqouiLhTXEUfDMmI or JOtndkvQesSAHPrqouiLhTXEUfDMRp=='':
   JOtndkvQesSAHPrqouiLhTXEUfDMRp=JOtndkvQesSAHPrqouiLhTXEUfDMmW('19000101')
  else:
   JOtndkvQesSAHPrqouiLhTXEUfDMRp=JOtndkvQesSAHPrqouiLhTXEUfDMmW(re.sub('-','',JOtndkvQesSAHPrqouiLhTXEUfDMRp))
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   JOtndkvQesSAHPrqouiLhTXEUfDMzG=0
   while JOtndkvQesSAHPrqouiLhTXEUfDMmx:
    JOtndkvQesSAHPrqouiLhTXEUfDMzG+=1
    time.sleep(0.05)
    if JOtndkvQesSAHPrqouiLhTXEUfDMRp>=JOtndkvQesSAHPrqouiLhTXEUfDMRC:return
    if JOtndkvQesSAHPrqouiLhTXEUfDMzG>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  if JOtndkvQesSAHPrqouiLhTXEUfDMRp>=JOtndkvQesSAHPrqouiLhTXEUfDMRC:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   return
  if not JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.GetCredential(JOtndkvQesSAHPrqouiLhTXEUfDMRB,JOtndkvQesSAHPrqouiLhTXEUfDMRj,JOtndkvQesSAHPrqouiLhTXEUfDMRN):
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   sys.exit()
  JOtndkvQesSAHPrqouiLhTXEUfDMGg.set_winCredential(JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.LoadCredential())
  JOtndkvQesSAHPrqouiLhTXEUfDMGg.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
 def dp_setEpOrderby(JOtndkvQesSAHPrqouiLhTXEUfDMGg,args):
  JOtndkvQesSAHPrqouiLhTXEUfDMzb =args.get('orderby')
  JOtndkvQesSAHPrqouiLhTXEUfDMGg.set_winEpisodeOrderby(JOtndkvQesSAHPrqouiLhTXEUfDMzb)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(JOtndkvQesSAHPrqouiLhTXEUfDMGg,args):
  JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.SaveCredential(JOtndkvQesSAHPrqouiLhTXEUfDMGg.get_winCredential())
  JOtndkvQesSAHPrqouiLhTXEUfDMbj =args.get('mode')
  JOtndkvQesSAHPrqouiLhTXEUfDMzK =args.get('contentid')
  JOtndkvQesSAHPrqouiLhTXEUfDMzR =args.get('pvrmode')
  JOtndkvQesSAHPrqouiLhTXEUfDMza=JOtndkvQesSAHPrqouiLhTXEUfDMGg.get_selQuality()
  JOtndkvQesSAHPrqouiLhTXEUfDMGg.addon_log(JOtndkvQesSAHPrqouiLhTXEUfDMzK+' - '+JOtndkvQesSAHPrqouiLhTXEUfDMbj)
  if JOtndkvQesSAHPrqouiLhTXEUfDMbj=='SPORTS':
   JOtndkvQesSAHPrqouiLhTXEUfDMzm,JOtndkvQesSAHPrqouiLhTXEUfDMzg=JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.GetSportsURL(JOtndkvQesSAHPrqouiLhTXEUfDMzK,JOtndkvQesSAHPrqouiLhTXEUfDMza)
   JOtndkvQesSAHPrqouiLhTXEUfDMzY =''
   JOtndkvQesSAHPrqouiLhTXEUfDMzl=''
  else:
   JOtndkvQesSAHPrqouiLhTXEUfDMzm,JOtndkvQesSAHPrqouiLhTXEUfDMzg,JOtndkvQesSAHPrqouiLhTXEUfDMzY,JOtndkvQesSAHPrqouiLhTXEUfDMzl=JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.GetStreamingURL(JOtndkvQesSAHPrqouiLhTXEUfDMbj,JOtndkvQesSAHPrqouiLhTXEUfDMzK,JOtndkvQesSAHPrqouiLhTXEUfDMza,JOtndkvQesSAHPrqouiLhTXEUfDMzR)
  JOtndkvQesSAHPrqouiLhTXEUfDMzw='%s|Cookie=%s'%(JOtndkvQesSAHPrqouiLhTXEUfDMzm,JOtndkvQesSAHPrqouiLhTXEUfDMzg)
  JOtndkvQesSAHPrqouiLhTXEUfDMGg.addon_log(JOtndkvQesSAHPrqouiLhTXEUfDMzw)
  if JOtndkvQesSAHPrqouiLhTXEUfDMzm=='':
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.addon_noti(__language__(30907).encode('utf8'))
   return
  JOtndkvQesSAHPrqouiLhTXEUfDMzF=xbmcgui.ListItem(path=JOtndkvQesSAHPrqouiLhTXEUfDMzw)
  if JOtndkvQesSAHPrqouiLhTXEUfDMzY:
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.addon_log('!!streaming_drm!!')
   JOtndkvQesSAHPrqouiLhTXEUfDMzI=JOtndkvQesSAHPrqouiLhTXEUfDMzY['customdata']
   JOtndkvQesSAHPrqouiLhTXEUfDMzx =JOtndkvQesSAHPrqouiLhTXEUfDMzY['drmhost']
   JOtndkvQesSAHPrqouiLhTXEUfDMzy =inputstreamhelper.Helper('mpd',drm='widevine')
   if JOtndkvQesSAHPrqouiLhTXEUfDMzy.check_inputstream():
    if JOtndkvQesSAHPrqouiLhTXEUfDMbj=='MOVIE':
     JOtndkvQesSAHPrqouiLhTXEUfDMzW='https://www.wavve.com/player/movie?movieid=%s'%JOtndkvQesSAHPrqouiLhTXEUfDMzK
    else:
     JOtndkvQesSAHPrqouiLhTXEUfDMzW='https://www.wavve.com/player/vod?programid=%s&page=1'%JOtndkvQesSAHPrqouiLhTXEUfDMzK
    JOtndkvQesSAHPrqouiLhTXEUfDMzc={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':JOtndkvQesSAHPrqouiLhTXEUfDMzI,'referer':JOtndkvQesSAHPrqouiLhTXEUfDMzW,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.USER_AGENT}
    JOtndkvQesSAHPrqouiLhTXEUfDMzV=JOtndkvQesSAHPrqouiLhTXEUfDMzx+'|'+urllib.parse.urlencode(JOtndkvQesSAHPrqouiLhTXEUfDMzc)+'|R{SSM}|'
    JOtndkvQesSAHPrqouiLhTXEUfDMzF.setProperty('inputstream',JOtndkvQesSAHPrqouiLhTXEUfDMzy.inputstream_addon)
    JOtndkvQesSAHPrqouiLhTXEUfDMzF.setProperty('inputstream.adaptive.manifest_type','mpd')
    JOtndkvQesSAHPrqouiLhTXEUfDMzF.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    JOtndkvQesSAHPrqouiLhTXEUfDMzF.setProperty('inputstream.adaptive.license_key',JOtndkvQesSAHPrqouiLhTXEUfDMzV)
    JOtndkvQesSAHPrqouiLhTXEUfDMzF.setProperty('inputstream.adaptive.stream_headers','user-agent=%s&Cookie=%s'%(JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.USER_AGENT,JOtndkvQesSAHPrqouiLhTXEUfDMzg))
  else:
   JOtndkvQesSAHPrqouiLhTXEUfDMzF.setContentLookup(JOtndkvQesSAHPrqouiLhTXEUfDMmy)
   JOtndkvQesSAHPrqouiLhTXEUfDMzF.setMimeType('application/x-mpegURL')
   JOtndkvQesSAHPrqouiLhTXEUfDMzF.setProperty('inputstream','inputstream.ffmpegdirect')
   JOtndkvQesSAHPrqouiLhTXEUfDMzF.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   JOtndkvQesSAHPrqouiLhTXEUfDMzF.setProperty('inputstream.ffmpegdirect.mime_type','hls')
  xbmcplugin.setResolvedUrl(JOtndkvQesSAHPrqouiLhTXEUfDMGg._addon_handle,JOtndkvQesSAHPrqouiLhTXEUfDMmx,JOtndkvQesSAHPrqouiLhTXEUfDMzF)
  JOtndkvQesSAHPrqouiLhTXEUfDMzB=JOtndkvQesSAHPrqouiLhTXEUfDMmy
  if JOtndkvQesSAHPrqouiLhTXEUfDMzl:
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.addon_noti(JOtndkvQesSAHPrqouiLhTXEUfDMzl.encode('utf-8'))
   JOtndkvQesSAHPrqouiLhTXEUfDMzB=JOtndkvQesSAHPrqouiLhTXEUfDMmx
  else:
   if '/preview.' in urllib.parse.urlsplit(JOtndkvQesSAHPrqouiLhTXEUfDMzm).path:
    JOtndkvQesSAHPrqouiLhTXEUfDMGg.addon_noti(__language__(30908).encode('utf8'))
    JOtndkvQesSAHPrqouiLhTXEUfDMzB=JOtndkvQesSAHPrqouiLhTXEUfDMmx
  try:
   JOtndkvQesSAHPrqouiLhTXEUfDMzj=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and JOtndkvQesSAHPrqouiLhTXEUfDMzB==JOtndkvQesSAHPrqouiLhTXEUfDMmy and JOtndkvQesSAHPrqouiLhTXEUfDMzj!='-':
    JOtndkvQesSAHPrqouiLhTXEUfDMbI={'code':JOtndkvQesSAHPrqouiLhTXEUfDMzj,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    JOtndkvQesSAHPrqouiLhTXEUfDMGg.Save_Watched_List(args.get('mode').lower(),JOtndkvQesSAHPrqouiLhTXEUfDMbI)
  except:
   JOtndkvQesSAHPrqouiLhTXEUfDMmI
 def logout(JOtndkvQesSAHPrqouiLhTXEUfDMGg):
  JOtndkvQesSAHPrqouiLhTXEUfDMGI=xbmcgui.Dialog()
  JOtndkvQesSAHPrqouiLhTXEUfDMRy=JOtndkvQesSAHPrqouiLhTXEUfDMGI.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if JOtndkvQesSAHPrqouiLhTXEUfDMRy==JOtndkvQesSAHPrqouiLhTXEUfDMmy:sys.exit()
  JOtndkvQesSAHPrqouiLhTXEUfDMGg.wininfo_clear()
  if os.path.isfile(JOtndkvQesSAHPrqouiLhTXEUfDMGa):os.remove(JOtndkvQesSAHPrqouiLhTXEUfDMGa)
  JOtndkvQesSAHPrqouiLhTXEUfDMGg.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(JOtndkvQesSAHPrqouiLhTXEUfDMGg):
  JOtndkvQesSAHPrqouiLhTXEUfDMbm=xbmcgui.Window(10000)
  JOtndkvQesSAHPrqouiLhTXEUfDMbm.setProperty('WAVVE_M_CREDENTIAL','')
  JOtndkvQesSAHPrqouiLhTXEUfDMbm.setProperty('WAVVE_M_LOGINTIME','')
 def cookiefile_save(JOtndkvQesSAHPrqouiLhTXEUfDMGg):
  JOtndkvQesSAHPrqouiLhTXEUfDMzN =JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.Get_Now_Datetime()
  JOtndkvQesSAHPrqouiLhTXEUfDMzC=JOtndkvQesSAHPrqouiLhTXEUfDMzN+datetime.timedelta(days=JOtndkvQesSAHPrqouiLhTXEUfDMmW(__addon__.getSetting('cache_ttl')))
  JOtndkvQesSAHPrqouiLhTXEUfDMbm=xbmcgui.Window(10000)
  JOtndkvQesSAHPrqouiLhTXEUfDMzp={'wavve_token':JOtndkvQesSAHPrqouiLhTXEUfDMbm.getProperty('WAVVE_M_CREDENTIAL'),'wavve_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'wavve_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'wavve_profile':__addon__.getSetting('selected_profile'),'wavve_limitdate':JOtndkvQesSAHPrqouiLhTXEUfDMzC.strftime('%Y-%m-%d')}
  try: 
   fp=JOtndkvQesSAHPrqouiLhTXEUfDMmC(JOtndkvQesSAHPrqouiLhTXEUfDMGa,'w',-1,'utf-8')
   json.dump(JOtndkvQesSAHPrqouiLhTXEUfDMzp,fp)
   fp.close()
  except JOtndkvQesSAHPrqouiLhTXEUfDMmp as exception:
   JOtndkvQesSAHPrqouiLhTXEUfDMgG(exception)
 def cookiefile_check(JOtndkvQesSAHPrqouiLhTXEUfDMGg):
  JOtndkvQesSAHPrqouiLhTXEUfDMzp={}
  try: 
   fp=JOtndkvQesSAHPrqouiLhTXEUfDMmC(JOtndkvQesSAHPrqouiLhTXEUfDMGa,'r',-1,'utf-8')
   JOtndkvQesSAHPrqouiLhTXEUfDMzp= json.load(fp)
   fp.close()
  except JOtndkvQesSAHPrqouiLhTXEUfDMmp as exception:
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.wininfo_clear()
   return JOtndkvQesSAHPrqouiLhTXEUfDMmy
  JOtndkvQesSAHPrqouiLhTXEUfDMRB =__addon__.getSetting('id')
  JOtndkvQesSAHPrqouiLhTXEUfDMRj =__addon__.getSetting('pw')
  JOtndkvQesSAHPrqouiLhTXEUfDMaG =__addon__.getSetting('selected_profile')
  JOtndkvQesSAHPrqouiLhTXEUfDMzp['wavve_id']=base64.standard_b64decode(JOtndkvQesSAHPrqouiLhTXEUfDMzp['wavve_id']).decode('utf-8')
  JOtndkvQesSAHPrqouiLhTXEUfDMzp['wavve_pw']=base64.standard_b64decode(JOtndkvQesSAHPrqouiLhTXEUfDMzp['wavve_pw']).decode('utf-8')
  if JOtndkvQesSAHPrqouiLhTXEUfDMRB!=JOtndkvQesSAHPrqouiLhTXEUfDMzp['wavve_id']or JOtndkvQesSAHPrqouiLhTXEUfDMRj!=JOtndkvQesSAHPrqouiLhTXEUfDMzp['wavve_pw']or JOtndkvQesSAHPrqouiLhTXEUfDMaG!=JOtndkvQesSAHPrqouiLhTXEUfDMzp['wavve_profile']:
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.wininfo_clear()
   return JOtndkvQesSAHPrqouiLhTXEUfDMmy
  JOtndkvQesSAHPrqouiLhTXEUfDMRC =JOtndkvQesSAHPrqouiLhTXEUfDMmW(JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  JOtndkvQesSAHPrqouiLhTXEUfDMab=JOtndkvQesSAHPrqouiLhTXEUfDMzp['wavve_limitdate']
  JOtndkvQesSAHPrqouiLhTXEUfDMRp =JOtndkvQesSAHPrqouiLhTXEUfDMmW(re.sub('-','',JOtndkvQesSAHPrqouiLhTXEUfDMab))
  if JOtndkvQesSAHPrqouiLhTXEUfDMRp<JOtndkvQesSAHPrqouiLhTXEUfDMRC:
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.wininfo_clear()
   return JOtndkvQesSAHPrqouiLhTXEUfDMmy
  JOtndkvQesSAHPrqouiLhTXEUfDMbm=xbmcgui.Window(10000)
  JOtndkvQesSAHPrqouiLhTXEUfDMbm.setProperty('WAVVE_M_CREDENTIAL',JOtndkvQesSAHPrqouiLhTXEUfDMzp['wavve_token'])
  JOtndkvQesSAHPrqouiLhTXEUfDMbm.setProperty('WAVVE_M_LOGINTIME',JOtndkvQesSAHPrqouiLhTXEUfDMab)
  return JOtndkvQesSAHPrqouiLhTXEUfDMmx
 def dp_LiveCatagory_List(JOtndkvQesSAHPrqouiLhTXEUfDMGg,args):
  JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.SaveCredential(JOtndkvQesSAHPrqouiLhTXEUfDMGg.get_winCredential())
  JOtndkvQesSAHPrqouiLhTXEUfDMaK =args.get('sCode')
  JOtndkvQesSAHPrqouiLhTXEUfDMaR=args.get('sIndex')
  JOtndkvQesSAHPrqouiLhTXEUfDMKy,JOtndkvQesSAHPrqouiLhTXEUfDMaz=JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.Get_LiveCatagory_List(JOtndkvQesSAHPrqouiLhTXEUfDMaK,JOtndkvQesSAHPrqouiLhTXEUfDMaR)
  for JOtndkvQesSAHPrqouiLhTXEUfDMKW in JOtndkvQesSAHPrqouiLhTXEUfDMKy:
   JOtndkvQesSAHPrqouiLhTXEUfDMbY =JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('title')
   JOtndkvQesSAHPrqouiLhTXEUfDMbI={'mode':'LIVE_LIST','genre':JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('genre'),'baseapi':JOtndkvQesSAHPrqouiLhTXEUfDMaz}
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.add_dir(JOtndkvQesSAHPrqouiLhTXEUfDMbY,sublabel='',img='',infoLabels=JOtndkvQesSAHPrqouiLhTXEUfDMmI,isFolder=JOtndkvQesSAHPrqouiLhTXEUfDMmx,params=JOtndkvQesSAHPrqouiLhTXEUfDMbI)
  if JOtndkvQesSAHPrqouiLhTXEUfDMmB(JOtndkvQesSAHPrqouiLhTXEUfDMKy)>0:xbmcplugin.endOfDirectory(JOtndkvQesSAHPrqouiLhTXEUfDMGg._addon_handle,cacheToDisc=JOtndkvQesSAHPrqouiLhTXEUfDMmy)
 def dp_MainCatagory_List(JOtndkvQesSAHPrqouiLhTXEUfDMGg,args):
  JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.SaveCredential(JOtndkvQesSAHPrqouiLhTXEUfDMGg.get_winCredential())
  JOtndkvQesSAHPrqouiLhTXEUfDMaK =args.get('sCode')
  JOtndkvQesSAHPrqouiLhTXEUfDMaR=args.get('sIndex')
  JOtndkvQesSAHPrqouiLhTXEUfDMbN =args.get('sType')
  JOtndkvQesSAHPrqouiLhTXEUfDMKy=JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.Get_MainCatagory_List(JOtndkvQesSAHPrqouiLhTXEUfDMaK,JOtndkvQesSAHPrqouiLhTXEUfDMaR)
  for JOtndkvQesSAHPrqouiLhTXEUfDMKW in JOtndkvQesSAHPrqouiLhTXEUfDMKy:
   if JOtndkvQesSAHPrqouiLhTXEUfDMbN=='vod':
    if JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('subtype')=='catagory':
     JOtndkvQesSAHPrqouiLhTXEUfDMbj='PROGRAM_LIST'
    else:
     JOtndkvQesSAHPrqouiLhTXEUfDMbj='SUPERSECTION_LIST'
   elif JOtndkvQesSAHPrqouiLhTXEUfDMbN=='movie':
    JOtndkvQesSAHPrqouiLhTXEUfDMbj='MOVIE_LIST'
   else:
    JOtndkvQesSAHPrqouiLhTXEUfDMbj=''
   JOtndkvQesSAHPrqouiLhTXEUfDMbY='%s (%s)'%(JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('title'),args.get('ordernm'))
   JOtndkvQesSAHPrqouiLhTXEUfDMbI={'mode':JOtndkvQesSAHPrqouiLhTXEUfDMbj,'suburl':JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('suburl'),'subapi':JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if JOtndkvQesSAHPrqouiLhTXEUfDMGg.get_settings_exclusion21():
    if JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('title')=='성인' or JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('title')=='성인+':continue
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.add_dir(JOtndkvQesSAHPrqouiLhTXEUfDMbY,sublabel='',img='',infoLabels=JOtndkvQesSAHPrqouiLhTXEUfDMmI,isFolder=JOtndkvQesSAHPrqouiLhTXEUfDMmx,params=JOtndkvQesSAHPrqouiLhTXEUfDMbI)
  if JOtndkvQesSAHPrqouiLhTXEUfDMmB(JOtndkvQesSAHPrqouiLhTXEUfDMKy)>0:xbmcplugin.endOfDirectory(JOtndkvQesSAHPrqouiLhTXEUfDMGg._addon_handle,cacheToDisc=JOtndkvQesSAHPrqouiLhTXEUfDMmy)
 def dp_Program_List(JOtndkvQesSAHPrqouiLhTXEUfDMGg,args):
  JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.SaveCredential(JOtndkvQesSAHPrqouiLhTXEUfDMGg.get_winCredential())
  JOtndkvQesSAHPrqouiLhTXEUfDMam =args.get('subapi')
  JOtndkvQesSAHPrqouiLhTXEUfDMKx=JOtndkvQesSAHPrqouiLhTXEUfDMmW(args.get('page'))
  JOtndkvQesSAHPrqouiLhTXEUfDMzb =args.get('orderby')
  JOtndkvQesSAHPrqouiLhTXEUfDMKy,JOtndkvQesSAHPrqouiLhTXEUfDMbp=JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.Get_Program_List(JOtndkvQesSAHPrqouiLhTXEUfDMam,JOtndkvQesSAHPrqouiLhTXEUfDMKx,JOtndkvQesSAHPrqouiLhTXEUfDMzb)
  for JOtndkvQesSAHPrqouiLhTXEUfDMKW in JOtndkvQesSAHPrqouiLhTXEUfDMKy:
   JOtndkvQesSAHPrqouiLhTXEUfDMbY =JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('title')
   JOtndkvQesSAHPrqouiLhTXEUfDMKc=JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('thumbnail')
   JOtndkvQesSAHPrqouiLhTXEUfDMKV =JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('age')
   if JOtndkvQesSAHPrqouiLhTXEUfDMKV=='18' or JOtndkvQesSAHPrqouiLhTXEUfDMKV=='19' or JOtndkvQesSAHPrqouiLhTXEUfDMKV=='21':JOtndkvQesSAHPrqouiLhTXEUfDMbY+=' (%s)'%(JOtndkvQesSAHPrqouiLhTXEUfDMKV)
   JOtndkvQesSAHPrqouiLhTXEUfDMKI={'plot':JOtndkvQesSAHPrqouiLhTXEUfDMbY,'mpaa':JOtndkvQesSAHPrqouiLhTXEUfDMKV,'mediatype':'tvshow'}
   JOtndkvQesSAHPrqouiLhTXEUfDMbI={'mode':'EPISODE_LIST','videoid':JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('videoid'),'vidtype':JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('vidtype'),'page':'1'}
   if JOtndkvQesSAHPrqouiLhTXEUfDMGg.get_settings_makebookmark():
    JOtndkvQesSAHPrqouiLhTXEUfDMKB={'videoid':JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('videoid'),'vidtype':'tvshow','vtitle':JOtndkvQesSAHPrqouiLhTXEUfDMbY,'vsubtitle':'','contenttype':JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('vidtype'),}
    JOtndkvQesSAHPrqouiLhTXEUfDMKj=json.dumps(JOtndkvQesSAHPrqouiLhTXEUfDMKB)
    JOtndkvQesSAHPrqouiLhTXEUfDMKj=urllib.parse.quote(JOtndkvQesSAHPrqouiLhTXEUfDMKj)
    JOtndkvQesSAHPrqouiLhTXEUfDMKN='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(JOtndkvQesSAHPrqouiLhTXEUfDMKj)
    JOtndkvQesSAHPrqouiLhTXEUfDMKF=[('(통합) 찜 영상에 추가',JOtndkvQesSAHPrqouiLhTXEUfDMKN)]
   else:
    JOtndkvQesSAHPrqouiLhTXEUfDMKF=JOtndkvQesSAHPrqouiLhTXEUfDMmI
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.add_dir(JOtndkvQesSAHPrqouiLhTXEUfDMbY,sublabel='',img=JOtndkvQesSAHPrqouiLhTXEUfDMKc,infoLabels=JOtndkvQesSAHPrqouiLhTXEUfDMKI,isFolder=JOtndkvQesSAHPrqouiLhTXEUfDMmx,params=JOtndkvQesSAHPrqouiLhTXEUfDMbI,ContextMenu=JOtndkvQesSAHPrqouiLhTXEUfDMKF)
  if JOtndkvQesSAHPrqouiLhTXEUfDMbp:
   JOtndkvQesSAHPrqouiLhTXEUfDMbI={}
   JOtndkvQesSAHPrqouiLhTXEUfDMbI['mode'] ='PROGRAM_LIST' 
   JOtndkvQesSAHPrqouiLhTXEUfDMbI['subapi']=JOtndkvQesSAHPrqouiLhTXEUfDMam 
   JOtndkvQesSAHPrqouiLhTXEUfDMbI['page'] =JOtndkvQesSAHPrqouiLhTXEUfDMmN(JOtndkvQesSAHPrqouiLhTXEUfDMKx+1)
   JOtndkvQesSAHPrqouiLhTXEUfDMbY='[B]%s >>[/B]'%'다음 페이지'
   JOtndkvQesSAHPrqouiLhTXEUfDMKC=JOtndkvQesSAHPrqouiLhTXEUfDMmN(JOtndkvQesSAHPrqouiLhTXEUfDMKx+1)
   JOtndkvQesSAHPrqouiLhTXEUfDMbF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.add_dir(JOtndkvQesSAHPrqouiLhTXEUfDMbY,sublabel=JOtndkvQesSAHPrqouiLhTXEUfDMKC,img=JOtndkvQesSAHPrqouiLhTXEUfDMbF,infoLabels=JOtndkvQesSAHPrqouiLhTXEUfDMmI,isFolder=JOtndkvQesSAHPrqouiLhTXEUfDMmx,params=JOtndkvQesSAHPrqouiLhTXEUfDMbI)
  xbmcplugin.setContent(JOtndkvQesSAHPrqouiLhTXEUfDMGg._addon_handle,'tvshows')
  if JOtndkvQesSAHPrqouiLhTXEUfDMmB(JOtndkvQesSAHPrqouiLhTXEUfDMKy)>0:xbmcplugin.endOfDirectory(JOtndkvQesSAHPrqouiLhTXEUfDMGg._addon_handle,cacheToDisc=JOtndkvQesSAHPrqouiLhTXEUfDMmy)
 def dp_SuperSection_List(JOtndkvQesSAHPrqouiLhTXEUfDMGg,args):
  JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.SaveCredential(JOtndkvQesSAHPrqouiLhTXEUfDMGg.get_winCredential())
  JOtndkvQesSAHPrqouiLhTXEUfDMag =args.get('suburl')
  JOtndkvQesSAHPrqouiLhTXEUfDMKy=JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.Get_SuperMultiSection_List(JOtndkvQesSAHPrqouiLhTXEUfDMag)
  for JOtndkvQesSAHPrqouiLhTXEUfDMKW in JOtndkvQesSAHPrqouiLhTXEUfDMKy:
   JOtndkvQesSAHPrqouiLhTXEUfDMbY =JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('title')
   JOtndkvQesSAHPrqouiLhTXEUfDMam =JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('subapi')
   JOtndkvQesSAHPrqouiLhTXEUfDMaY=JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('cell_type')
   if JOtndkvQesSAHPrqouiLhTXEUfDMam.find('mtype=svod')>=0 or JOtndkvQesSAHPrqouiLhTXEUfDMam.find('mtype=ppv')>=0:
    JOtndkvQesSAHPrqouiLhTXEUfDMbj='MOVIE_LIST'
   elif JOtndkvQesSAHPrqouiLhTXEUfDMaY=='band_71':
    JOtndkvQesSAHPrqouiLhTXEUfDMbj ='SUPERSECTION_LIST'
    (JOtndkvQesSAHPrqouiLhTXEUfDMal,JOtndkvQesSAHPrqouiLhTXEUfDMaw)=JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.Baseapi_Parse(JOtndkvQesSAHPrqouiLhTXEUfDMam)
    JOtndkvQesSAHPrqouiLhTXEUfDMag=JOtndkvQesSAHPrqouiLhTXEUfDMaw.get('api')
    JOtndkvQesSAHPrqouiLhTXEUfDMam=''
   elif JOtndkvQesSAHPrqouiLhTXEUfDMaY=='band_2':
    JOtndkvQesSAHPrqouiLhTXEUfDMbj='BAND2SECTION_LIST'
   elif JOtndkvQesSAHPrqouiLhTXEUfDMaY=='band_live':
    JOtndkvQesSAHPrqouiLhTXEUfDMbj='BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}',JOtndkvQesSAHPrqouiLhTXEUfDMam):
    JOtndkvQesSAHPrqouiLhTXEUfDMbj='MOVIE_LIST'
   else:
    JOtndkvQesSAHPrqouiLhTXEUfDMbj='PROGRAM_LIST'
   JOtndkvQesSAHPrqouiLhTXEUfDMKI={'plot':JOtndkvQesSAHPrqouiLhTXEUfDMbY,'mediatype':'tvshow'}
   JOtndkvQesSAHPrqouiLhTXEUfDMbI={'mode':JOtndkvQesSAHPrqouiLhTXEUfDMbj,'suburl':JOtndkvQesSAHPrqouiLhTXEUfDMag,'subapi':JOtndkvQesSAHPrqouiLhTXEUfDMam,'page':'1'}
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.add_dir(JOtndkvQesSAHPrqouiLhTXEUfDMbY,sublabel='',img=JOtndkvQesSAHPrqouiLhTXEUfDMmI,infoLabels=JOtndkvQesSAHPrqouiLhTXEUfDMKI,isFolder=JOtndkvQesSAHPrqouiLhTXEUfDMmx,params=JOtndkvQesSAHPrqouiLhTXEUfDMbI)
  if JOtndkvQesSAHPrqouiLhTXEUfDMmB(JOtndkvQesSAHPrqouiLhTXEUfDMKy)>0:xbmcplugin.endOfDirectory(JOtndkvQesSAHPrqouiLhTXEUfDMGg._addon_handle,cacheToDisc=JOtndkvQesSAHPrqouiLhTXEUfDMmy)
 def dp_BandLiveSection_List(JOtndkvQesSAHPrqouiLhTXEUfDMGg,args):
  JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.SaveCredential(JOtndkvQesSAHPrqouiLhTXEUfDMGg.get_winCredential())
  JOtndkvQesSAHPrqouiLhTXEUfDMam =args.get('subapi')
  JOtndkvQesSAHPrqouiLhTXEUfDMKx=JOtndkvQesSAHPrqouiLhTXEUfDMmW(args.get('page'))
  JOtndkvQesSAHPrqouiLhTXEUfDMKy,JOtndkvQesSAHPrqouiLhTXEUfDMbp=JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.Get_BandLiveSection_List(JOtndkvQesSAHPrqouiLhTXEUfDMam,JOtndkvQesSAHPrqouiLhTXEUfDMKx)
  for JOtndkvQesSAHPrqouiLhTXEUfDMKW in JOtndkvQesSAHPrqouiLhTXEUfDMKy:
   JOtndkvQesSAHPrqouiLhTXEUfDMaF =JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('channelid')
   JOtndkvQesSAHPrqouiLhTXEUfDMaI =JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('studio')
   JOtndkvQesSAHPrqouiLhTXEUfDMax=JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('tvshowtitle')
   JOtndkvQesSAHPrqouiLhTXEUfDMKc =JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('thumbnail')
   JOtndkvQesSAHPrqouiLhTXEUfDMKV =JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('age')
   JOtndkvQesSAHPrqouiLhTXEUfDMKI={'mediatype':'tvshow','mpaa':JOtndkvQesSAHPrqouiLhTXEUfDMKV,'title':'%s < %s >'%(JOtndkvQesSAHPrqouiLhTXEUfDMaI,JOtndkvQesSAHPrqouiLhTXEUfDMax),'tvshowtitle':JOtndkvQesSAHPrqouiLhTXEUfDMax,'studio':JOtndkvQesSAHPrqouiLhTXEUfDMaI,'plot':JOtndkvQesSAHPrqouiLhTXEUfDMaI}
   JOtndkvQesSAHPrqouiLhTXEUfDMbI={'mode':'LIVE','contentid':JOtndkvQesSAHPrqouiLhTXEUfDMaF}
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.add_dir(JOtndkvQesSAHPrqouiLhTXEUfDMaI,sublabel=JOtndkvQesSAHPrqouiLhTXEUfDMax,img=JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('thumbnail'),infoLabels=JOtndkvQesSAHPrqouiLhTXEUfDMKI,isFolder=JOtndkvQesSAHPrqouiLhTXEUfDMmy,params=JOtndkvQesSAHPrqouiLhTXEUfDMbI)
  if JOtndkvQesSAHPrqouiLhTXEUfDMbp:
   JOtndkvQesSAHPrqouiLhTXEUfDMbI={}
   JOtndkvQesSAHPrqouiLhTXEUfDMbI['mode'] ='BANDLIVESECTION_LIST' 
   JOtndkvQesSAHPrqouiLhTXEUfDMbI['subapi']=JOtndkvQesSAHPrqouiLhTXEUfDMam
   JOtndkvQesSAHPrqouiLhTXEUfDMbI['page'] =JOtndkvQesSAHPrqouiLhTXEUfDMmN(JOtndkvQesSAHPrqouiLhTXEUfDMKx+1)
   JOtndkvQesSAHPrqouiLhTXEUfDMbY='[B]%s >>[/B]'%'다음 페이지'
   JOtndkvQesSAHPrqouiLhTXEUfDMKC=JOtndkvQesSAHPrqouiLhTXEUfDMmN(JOtndkvQesSAHPrqouiLhTXEUfDMKx+1)
   JOtndkvQesSAHPrqouiLhTXEUfDMbF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.add_dir(JOtndkvQesSAHPrqouiLhTXEUfDMbY,sublabel=JOtndkvQesSAHPrqouiLhTXEUfDMKC,img=JOtndkvQesSAHPrqouiLhTXEUfDMbF,infoLabels=JOtndkvQesSAHPrqouiLhTXEUfDMmI,isFolder=JOtndkvQesSAHPrqouiLhTXEUfDMmx,params=JOtndkvQesSAHPrqouiLhTXEUfDMbI)
  if JOtndkvQesSAHPrqouiLhTXEUfDMmB(JOtndkvQesSAHPrqouiLhTXEUfDMKy)>0:xbmcplugin.endOfDirectory(JOtndkvQesSAHPrqouiLhTXEUfDMGg._addon_handle,cacheToDisc=JOtndkvQesSAHPrqouiLhTXEUfDMmy)
 def dp_Band2Section_List(JOtndkvQesSAHPrqouiLhTXEUfDMGg,args):
  JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.SaveCredential(JOtndkvQesSAHPrqouiLhTXEUfDMGg.get_winCredential())
  JOtndkvQesSAHPrqouiLhTXEUfDMam =args.get('subapi')
  JOtndkvQesSAHPrqouiLhTXEUfDMKx=JOtndkvQesSAHPrqouiLhTXEUfDMmW(args.get('page'))
  JOtndkvQesSAHPrqouiLhTXEUfDMKy,JOtndkvQesSAHPrqouiLhTXEUfDMbp=JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.Get_Band2Section_List(JOtndkvQesSAHPrqouiLhTXEUfDMam,JOtndkvQesSAHPrqouiLhTXEUfDMKx)
  for JOtndkvQesSAHPrqouiLhTXEUfDMKW in JOtndkvQesSAHPrqouiLhTXEUfDMKy:
   JOtndkvQesSAHPrqouiLhTXEUfDMbY =JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('programtitle')
   JOtndkvQesSAHPrqouiLhTXEUfDMKC =JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('episodetitle')
   JOtndkvQesSAHPrqouiLhTXEUfDMKI={'plot':JOtndkvQesSAHPrqouiLhTXEUfDMbY+'\n\n'+JOtndkvQesSAHPrqouiLhTXEUfDMKC,'mpaa':JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('age'),'mediatype':'episode'}
   JOtndkvQesSAHPrqouiLhTXEUfDMbI={'mode':'VOD','programid':'-','contentid':JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('videoid'),'thumbnail':JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('thumbnail'),'title':JOtndkvQesSAHPrqouiLhTXEUfDMbY,'subtitle':JOtndkvQesSAHPrqouiLhTXEUfDMKC}
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.add_dir(JOtndkvQesSAHPrqouiLhTXEUfDMbY,sublabel=JOtndkvQesSAHPrqouiLhTXEUfDMKC,img=JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('thumbnail'),infoLabels=JOtndkvQesSAHPrqouiLhTXEUfDMKI,isFolder=JOtndkvQesSAHPrqouiLhTXEUfDMmy,params=JOtndkvQesSAHPrqouiLhTXEUfDMbI)
  if JOtndkvQesSAHPrqouiLhTXEUfDMbp:
   JOtndkvQesSAHPrqouiLhTXEUfDMbI={}
   JOtndkvQesSAHPrqouiLhTXEUfDMbI['mode'] ='BAND2SECTION_LIST' 
   JOtndkvQesSAHPrqouiLhTXEUfDMbI['subapi']=JOtndkvQesSAHPrqouiLhTXEUfDMam
   JOtndkvQesSAHPrqouiLhTXEUfDMbI['page'] =JOtndkvQesSAHPrqouiLhTXEUfDMmN(JOtndkvQesSAHPrqouiLhTXEUfDMKx+1)
   JOtndkvQesSAHPrqouiLhTXEUfDMbY='[B]%s >>[/B]'%'다음 페이지'
   JOtndkvQesSAHPrqouiLhTXEUfDMKC=JOtndkvQesSAHPrqouiLhTXEUfDMmN(JOtndkvQesSAHPrqouiLhTXEUfDMKx+1)
   JOtndkvQesSAHPrqouiLhTXEUfDMbF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.add_dir(JOtndkvQesSAHPrqouiLhTXEUfDMbY,sublabel=JOtndkvQesSAHPrqouiLhTXEUfDMKC,img=JOtndkvQesSAHPrqouiLhTXEUfDMbF,infoLabels=JOtndkvQesSAHPrqouiLhTXEUfDMmI,isFolder=JOtndkvQesSAHPrqouiLhTXEUfDMmx,params=JOtndkvQesSAHPrqouiLhTXEUfDMbI)
  if JOtndkvQesSAHPrqouiLhTXEUfDMmB(JOtndkvQesSAHPrqouiLhTXEUfDMKy)>0:xbmcplugin.endOfDirectory(JOtndkvQesSAHPrqouiLhTXEUfDMGg._addon_handle,cacheToDisc=JOtndkvQesSAHPrqouiLhTXEUfDMmy)
 def dp_Movie_List(JOtndkvQesSAHPrqouiLhTXEUfDMGg,args):
  JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.SaveCredential(JOtndkvQesSAHPrqouiLhTXEUfDMGg.get_winCredential())
  JOtndkvQesSAHPrqouiLhTXEUfDMam =args.get('subapi')
  JOtndkvQesSAHPrqouiLhTXEUfDMKx=JOtndkvQesSAHPrqouiLhTXEUfDMmW(args.get('page'))
  JOtndkvQesSAHPrqouiLhTXEUfDMKy,JOtndkvQesSAHPrqouiLhTXEUfDMbp=JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.Get_Movie_List(JOtndkvQesSAHPrqouiLhTXEUfDMam,JOtndkvQesSAHPrqouiLhTXEUfDMKx)
  for JOtndkvQesSAHPrqouiLhTXEUfDMKW in JOtndkvQesSAHPrqouiLhTXEUfDMKy:
   JOtndkvQesSAHPrqouiLhTXEUfDMbY =JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('title')
   JOtndkvQesSAHPrqouiLhTXEUfDMKc=JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('thumbnail')
   JOtndkvQesSAHPrqouiLhTXEUfDMKV =JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('age')
   if JOtndkvQesSAHPrqouiLhTXEUfDMKV=='18' or JOtndkvQesSAHPrqouiLhTXEUfDMKV=='19' or JOtndkvQesSAHPrqouiLhTXEUfDMKV=='21':JOtndkvQesSAHPrqouiLhTXEUfDMbY+=' (%s)'%(JOtndkvQesSAHPrqouiLhTXEUfDMKV)
   JOtndkvQesSAHPrqouiLhTXEUfDMKI={'plot':JOtndkvQesSAHPrqouiLhTXEUfDMbY,'mpaa':JOtndkvQesSAHPrqouiLhTXEUfDMKV,'mediatype':'movie'}
   JOtndkvQesSAHPrqouiLhTXEUfDMbI={'mode':'MOVIE','contentid':JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('videoid'),'title':JOtndkvQesSAHPrqouiLhTXEUfDMbY,'thumbnail':JOtndkvQesSAHPrqouiLhTXEUfDMKc,'age':JOtndkvQesSAHPrqouiLhTXEUfDMKV}
   if JOtndkvQesSAHPrqouiLhTXEUfDMGg.get_settings_makebookmark():
    JOtndkvQesSAHPrqouiLhTXEUfDMKB={'videoid':JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('videoid'),'vidtype':'movie','vtitle':JOtndkvQesSAHPrqouiLhTXEUfDMbY,'vsubtitle':'','contenttype':'programid',}
    JOtndkvQesSAHPrqouiLhTXEUfDMKj=json.dumps(JOtndkvQesSAHPrqouiLhTXEUfDMKB)
    JOtndkvQesSAHPrqouiLhTXEUfDMKj=urllib.parse.quote(JOtndkvQesSAHPrqouiLhTXEUfDMKj)
    JOtndkvQesSAHPrqouiLhTXEUfDMKN='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(JOtndkvQesSAHPrqouiLhTXEUfDMKj)
    JOtndkvQesSAHPrqouiLhTXEUfDMKF=[('(통합) 찜 영상에 추가',JOtndkvQesSAHPrqouiLhTXEUfDMKN)]
   else:
    JOtndkvQesSAHPrqouiLhTXEUfDMKF=JOtndkvQesSAHPrqouiLhTXEUfDMmI
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.add_dir(JOtndkvQesSAHPrqouiLhTXEUfDMbY,sublabel='',img=JOtndkvQesSAHPrqouiLhTXEUfDMKc,infoLabels=JOtndkvQesSAHPrqouiLhTXEUfDMKI,isFolder=JOtndkvQesSAHPrqouiLhTXEUfDMmy,params=JOtndkvQesSAHPrqouiLhTXEUfDMbI,ContextMenu=JOtndkvQesSAHPrqouiLhTXEUfDMKF)
  if JOtndkvQesSAHPrqouiLhTXEUfDMbp:
   JOtndkvQesSAHPrqouiLhTXEUfDMbI={}
   JOtndkvQesSAHPrqouiLhTXEUfDMbI['mode'] ='MOVIE_LIST' 
   JOtndkvQesSAHPrqouiLhTXEUfDMbI['subapi']=JOtndkvQesSAHPrqouiLhTXEUfDMam 
   JOtndkvQesSAHPrqouiLhTXEUfDMbI['page'] =JOtndkvQesSAHPrqouiLhTXEUfDMmN(JOtndkvQesSAHPrqouiLhTXEUfDMKx+1)
   JOtndkvQesSAHPrqouiLhTXEUfDMbY='[B]%s >>[/B]'%'다음 페이지'
   JOtndkvQesSAHPrqouiLhTXEUfDMKC=JOtndkvQesSAHPrqouiLhTXEUfDMmN(JOtndkvQesSAHPrqouiLhTXEUfDMKx+1)
   JOtndkvQesSAHPrqouiLhTXEUfDMbF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.add_dir(JOtndkvQesSAHPrqouiLhTXEUfDMbY,sublabel=JOtndkvQesSAHPrqouiLhTXEUfDMKC,img=JOtndkvQesSAHPrqouiLhTXEUfDMbF,infoLabels=JOtndkvQesSAHPrqouiLhTXEUfDMmI,isFolder=JOtndkvQesSAHPrqouiLhTXEUfDMmx,params=JOtndkvQesSAHPrqouiLhTXEUfDMbI)
  xbmcplugin.setContent(JOtndkvQesSAHPrqouiLhTXEUfDMGg._addon_handle,'movies')
  if JOtndkvQesSAHPrqouiLhTXEUfDMmB(JOtndkvQesSAHPrqouiLhTXEUfDMKy)>0:xbmcplugin.endOfDirectory(JOtndkvQesSAHPrqouiLhTXEUfDMGg._addon_handle,cacheToDisc=JOtndkvQesSAHPrqouiLhTXEUfDMmy)
 def dp_Set_Bookmark(JOtndkvQesSAHPrqouiLhTXEUfDMGg,args):
  JOtndkvQesSAHPrqouiLhTXEUfDMay=urllib.parse.unquote(args.get('bm_param'))
  JOtndkvQesSAHPrqouiLhTXEUfDMay=json.loads(JOtndkvQesSAHPrqouiLhTXEUfDMay)
  JOtndkvQesSAHPrqouiLhTXEUfDMRG =JOtndkvQesSAHPrqouiLhTXEUfDMay.get('videoid')
  JOtndkvQesSAHPrqouiLhTXEUfDMaW =JOtndkvQesSAHPrqouiLhTXEUfDMay.get('vidtype')
  JOtndkvQesSAHPrqouiLhTXEUfDMac =JOtndkvQesSAHPrqouiLhTXEUfDMay.get('vtitle')
  JOtndkvQesSAHPrqouiLhTXEUfDMaV =JOtndkvQesSAHPrqouiLhTXEUfDMay.get('vsubtitle')
  JOtndkvQesSAHPrqouiLhTXEUfDMaB=JOtndkvQesSAHPrqouiLhTXEUfDMay.get('contenttype')
  JOtndkvQesSAHPrqouiLhTXEUfDMGI=xbmcgui.Dialog()
  JOtndkvQesSAHPrqouiLhTXEUfDMRy=JOtndkvQesSAHPrqouiLhTXEUfDMGI.yesno(__language__(30913).encode('utf8'),JOtndkvQesSAHPrqouiLhTXEUfDMac+' \n\n'+__language__(30914))
  if JOtndkvQesSAHPrqouiLhTXEUfDMRy==JOtndkvQesSAHPrqouiLhTXEUfDMmy:return
  JOtndkvQesSAHPrqouiLhTXEUfDMaj=JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.GetBookmarkInfo(JOtndkvQesSAHPrqouiLhTXEUfDMRG,JOtndkvQesSAHPrqouiLhTXEUfDMaW,JOtndkvQesSAHPrqouiLhTXEUfDMaB)
  JOtndkvQesSAHPrqouiLhTXEUfDMaN=json.dumps(JOtndkvQesSAHPrqouiLhTXEUfDMaj)
  JOtndkvQesSAHPrqouiLhTXEUfDMaN=urllib.parse.quote(JOtndkvQesSAHPrqouiLhTXEUfDMaN)
  JOtndkvQesSAHPrqouiLhTXEUfDMKN ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(JOtndkvQesSAHPrqouiLhTXEUfDMaN)
  xbmc.executebuiltin(JOtndkvQesSAHPrqouiLhTXEUfDMKN)
 def dp_Episode_List(JOtndkvQesSAHPrqouiLhTXEUfDMGg,args):
  JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.SaveCredential(JOtndkvQesSAHPrqouiLhTXEUfDMGg.get_winCredential())
  JOtndkvQesSAHPrqouiLhTXEUfDMRG =args.get('videoid')
  JOtndkvQesSAHPrqouiLhTXEUfDMaW =args.get('vidtype')
  JOtndkvQesSAHPrqouiLhTXEUfDMKx=JOtndkvQesSAHPrqouiLhTXEUfDMmW(args.get('page'))
  JOtndkvQesSAHPrqouiLhTXEUfDMKy,JOtndkvQesSAHPrqouiLhTXEUfDMbp=JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.Get_Episode_List(JOtndkvQesSAHPrqouiLhTXEUfDMRG,JOtndkvQesSAHPrqouiLhTXEUfDMaW,JOtndkvQesSAHPrqouiLhTXEUfDMKx,orderby=JOtndkvQesSAHPrqouiLhTXEUfDMGg.get_winEpisodeOrderby())
  for JOtndkvQesSAHPrqouiLhTXEUfDMKW in JOtndkvQesSAHPrqouiLhTXEUfDMKy:
   JOtndkvQesSAHPrqouiLhTXEUfDMKC='%s회, %s(%s)'%(JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('episodenumber'),JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('releasedate'),JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('releaseweekday'))
   JOtndkvQesSAHPrqouiLhTXEUfDMaC ='[%s]\n\n%s'%(JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('episodetitle'),JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('synopsis'))
   JOtndkvQesSAHPrqouiLhTXEUfDMKI={'mediatype':'episode','title':JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('programtitle'),'year':JOtndkvQesSAHPrqouiLhTXEUfDMmW(JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('releasedate')[:4]),'aired':JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('releasedate'),'mpaa':JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('age'),'episode':JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('episodenumber'),'duration':JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('playtime'),'plot':JOtndkvQesSAHPrqouiLhTXEUfDMaC,'cast':JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('episodeactors')}
   JOtndkvQesSAHPrqouiLhTXEUfDMbI={'mode':'VOD','programid':JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('programid'),'contentid':JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('contentid'),'thumbnail':JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('thumbnail'),'title':JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('programtitle'),'subtitle':JOtndkvQesSAHPrqouiLhTXEUfDMKC}
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.add_dir(JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('programtitle'),sublabel=JOtndkvQesSAHPrqouiLhTXEUfDMKC,img=JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('thumbnail'),infoLabels=JOtndkvQesSAHPrqouiLhTXEUfDMKI,isFolder=JOtndkvQesSAHPrqouiLhTXEUfDMmy,params=JOtndkvQesSAHPrqouiLhTXEUfDMbI)
  if JOtndkvQesSAHPrqouiLhTXEUfDMKx==1:
   JOtndkvQesSAHPrqouiLhTXEUfDMKI={'plot':'정렬순서를 변경합니다.'}
   JOtndkvQesSAHPrqouiLhTXEUfDMbI={}
   JOtndkvQesSAHPrqouiLhTXEUfDMbI['mode'] ='ORDER_BY' 
   if JOtndkvQesSAHPrqouiLhTXEUfDMGg.get_winEpisodeOrderby()=='desc':
    JOtndkvQesSAHPrqouiLhTXEUfDMbY='정렬순서변경 : 최신화부터 -> 1회부터'
    JOtndkvQesSAHPrqouiLhTXEUfDMbI['orderby']='asc'
   else:
    JOtndkvQesSAHPrqouiLhTXEUfDMbY='정렬순서변경 : 1회부터 -> 최신화부터'
    JOtndkvQesSAHPrqouiLhTXEUfDMbI['orderby']='desc'
   JOtndkvQesSAHPrqouiLhTXEUfDMbF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.add_dir(JOtndkvQesSAHPrqouiLhTXEUfDMbY,sublabel='',img=JOtndkvQesSAHPrqouiLhTXEUfDMbF,infoLabels=JOtndkvQesSAHPrqouiLhTXEUfDMKI,isFolder=JOtndkvQesSAHPrqouiLhTXEUfDMmy,params=JOtndkvQesSAHPrqouiLhTXEUfDMbI,isLink=JOtndkvQesSAHPrqouiLhTXEUfDMmx)
  if JOtndkvQesSAHPrqouiLhTXEUfDMbp:
   JOtndkvQesSAHPrqouiLhTXEUfDMbI={}
   JOtndkvQesSAHPrqouiLhTXEUfDMbI['mode'] ='EPISODE_LIST' 
   JOtndkvQesSAHPrqouiLhTXEUfDMbI['videoid']=JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('programid')
   JOtndkvQesSAHPrqouiLhTXEUfDMbI['vidtype']='programid'
   JOtndkvQesSAHPrqouiLhTXEUfDMbI['page'] =JOtndkvQesSAHPrqouiLhTXEUfDMmN(JOtndkvQesSAHPrqouiLhTXEUfDMKx+1)
   JOtndkvQesSAHPrqouiLhTXEUfDMbY='[B]%s >>[/B]'%'다음 페이지'
   JOtndkvQesSAHPrqouiLhTXEUfDMKC=JOtndkvQesSAHPrqouiLhTXEUfDMmN(JOtndkvQesSAHPrqouiLhTXEUfDMKx+1)
   JOtndkvQesSAHPrqouiLhTXEUfDMbF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.add_dir(JOtndkvQesSAHPrqouiLhTXEUfDMbY,sublabel=JOtndkvQesSAHPrqouiLhTXEUfDMKC,img=JOtndkvQesSAHPrqouiLhTXEUfDMbF,infoLabels=JOtndkvQesSAHPrqouiLhTXEUfDMmI,isFolder=JOtndkvQesSAHPrqouiLhTXEUfDMmx,params=JOtndkvQesSAHPrqouiLhTXEUfDMbI)
  xbmcplugin.setContent(JOtndkvQesSAHPrqouiLhTXEUfDMGg._addon_handle,'episodes')
  if JOtndkvQesSAHPrqouiLhTXEUfDMmB(JOtndkvQesSAHPrqouiLhTXEUfDMKy)>0:xbmcplugin.endOfDirectory(JOtndkvQesSAHPrqouiLhTXEUfDMGg._addon_handle,cacheToDisc=JOtndkvQesSAHPrqouiLhTXEUfDMmy)
 def dp_LiveChannel_List(JOtndkvQesSAHPrqouiLhTXEUfDMGg,args):
  JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.SaveCredential(JOtndkvQesSAHPrqouiLhTXEUfDMGg.get_winCredential())
  JOtndkvQesSAHPrqouiLhTXEUfDMap =args.get('genre')
  JOtndkvQesSAHPrqouiLhTXEUfDMaz=args.get('baseapi')
  JOtndkvQesSAHPrqouiLhTXEUfDMKy=JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.Get_LiveChannel_List(JOtndkvQesSAHPrqouiLhTXEUfDMap,JOtndkvQesSAHPrqouiLhTXEUfDMaz)
  for JOtndkvQesSAHPrqouiLhTXEUfDMKW in JOtndkvQesSAHPrqouiLhTXEUfDMKy:
   JOtndkvQesSAHPrqouiLhTXEUfDMaF =JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('channelid')
   JOtndkvQesSAHPrqouiLhTXEUfDMaI =JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('studio')
   JOtndkvQesSAHPrqouiLhTXEUfDMax=JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('tvshowtitle')
   JOtndkvQesSAHPrqouiLhTXEUfDMKc =JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('thumbnail')
   JOtndkvQesSAHPrqouiLhTXEUfDMKV =JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('age')
   JOtndkvQesSAHPrqouiLhTXEUfDMmG =JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('epg')
   JOtndkvQesSAHPrqouiLhTXEUfDMKI={'mediatype':'episode','mpaa':JOtndkvQesSAHPrqouiLhTXEUfDMKV,'title':'%s < %s >'%(JOtndkvQesSAHPrqouiLhTXEUfDMaI,JOtndkvQesSAHPrqouiLhTXEUfDMax),'tvshowtitle':JOtndkvQesSAHPrqouiLhTXEUfDMax,'studio':JOtndkvQesSAHPrqouiLhTXEUfDMaI,'plot':'%s\n\n%s'%(JOtndkvQesSAHPrqouiLhTXEUfDMaI,JOtndkvQesSAHPrqouiLhTXEUfDMmG)}
   JOtndkvQesSAHPrqouiLhTXEUfDMbI={'mode':'LIVE','contentid':JOtndkvQesSAHPrqouiLhTXEUfDMaF}
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.add_dir(JOtndkvQesSAHPrqouiLhTXEUfDMaI,sublabel=JOtndkvQesSAHPrqouiLhTXEUfDMax,img=JOtndkvQesSAHPrqouiLhTXEUfDMKc,infoLabels=JOtndkvQesSAHPrqouiLhTXEUfDMKI,isFolder=JOtndkvQesSAHPrqouiLhTXEUfDMmy,params=JOtndkvQesSAHPrqouiLhTXEUfDMbI)
  if JOtndkvQesSAHPrqouiLhTXEUfDMmB(JOtndkvQesSAHPrqouiLhTXEUfDMKy)>0:xbmcplugin.endOfDirectory(JOtndkvQesSAHPrqouiLhTXEUfDMGg._addon_handle,cacheToDisc=JOtndkvQesSAHPrqouiLhTXEUfDMmy)
 def dp_Sports_GameList(JOtndkvQesSAHPrqouiLhTXEUfDMGg,args):
  JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.SaveCredential(JOtndkvQesSAHPrqouiLhTXEUfDMGg.get_winCredential())
  JOtndkvQesSAHPrqouiLhTXEUfDMKy=JOtndkvQesSAHPrqouiLhTXEUfDMGg.WavveObj.Get_Sports_Gamelist()
  for JOtndkvQesSAHPrqouiLhTXEUfDMKW in JOtndkvQesSAHPrqouiLhTXEUfDMKy:
   JOtndkvQesSAHPrqouiLhTXEUfDMmb =JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('game_date')
   JOtndkvQesSAHPrqouiLhTXEUfDMmK =JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('game_time')
   JOtndkvQesSAHPrqouiLhTXEUfDMmR =JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('svc_id')
   JOtndkvQesSAHPrqouiLhTXEUfDMmz =JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('away_team')
   JOtndkvQesSAHPrqouiLhTXEUfDMma =JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('home_team')
   JOtndkvQesSAHPrqouiLhTXEUfDMmg=JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('game_status')
   JOtndkvQesSAHPrqouiLhTXEUfDMmY =JOtndkvQesSAHPrqouiLhTXEUfDMKW.get('game_place')
   JOtndkvQesSAHPrqouiLhTXEUfDMml ='%s vs %s (%s)'%(JOtndkvQesSAHPrqouiLhTXEUfDMmz,JOtndkvQesSAHPrqouiLhTXEUfDMma,JOtndkvQesSAHPrqouiLhTXEUfDMmY)
   JOtndkvQesSAHPrqouiLhTXEUfDMmw =JOtndkvQesSAHPrqouiLhTXEUfDMmb+' '+JOtndkvQesSAHPrqouiLhTXEUfDMmK
   if JOtndkvQesSAHPrqouiLhTXEUfDMmg=='LIVE':
    JOtndkvQesSAHPrqouiLhTXEUfDMmg='~경기중~'
   elif JOtndkvQesSAHPrqouiLhTXEUfDMmg=='END':
    JOtndkvQesSAHPrqouiLhTXEUfDMmg='경기종료'
   elif JOtndkvQesSAHPrqouiLhTXEUfDMmg=='CANCEL':
    JOtndkvQesSAHPrqouiLhTXEUfDMmg='취소'
   else:
    JOtndkvQesSAHPrqouiLhTXEUfDMmg=''
   if JOtndkvQesSAHPrqouiLhTXEUfDMmg=='':
    JOtndkvQesSAHPrqouiLhTXEUfDMKC=JOtndkvQesSAHPrqouiLhTXEUfDMml
   else:
    JOtndkvQesSAHPrqouiLhTXEUfDMKC=JOtndkvQesSAHPrqouiLhTXEUfDMml+'  '+JOtndkvQesSAHPrqouiLhTXEUfDMmg
   JOtndkvQesSAHPrqouiLhTXEUfDMKI={'mediatype':'episode','title':JOtndkvQesSAHPrqouiLhTXEUfDMml,'plot':'%s\n\n%s\n\n%s'%(JOtndkvQesSAHPrqouiLhTXEUfDMmw,JOtndkvQesSAHPrqouiLhTXEUfDMml,JOtndkvQesSAHPrqouiLhTXEUfDMmg)}
   JOtndkvQesSAHPrqouiLhTXEUfDMbI={'mode':'SPORTS','contentid':JOtndkvQesSAHPrqouiLhTXEUfDMmR}
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.add_dir(JOtndkvQesSAHPrqouiLhTXEUfDMmw,sublabel=JOtndkvQesSAHPrqouiLhTXEUfDMKC,img='',infoLabels=JOtndkvQesSAHPrqouiLhTXEUfDMKI,isFolder=JOtndkvQesSAHPrqouiLhTXEUfDMmy,params=JOtndkvQesSAHPrqouiLhTXEUfDMbI)
  xbmcplugin.endOfDirectory(JOtndkvQesSAHPrqouiLhTXEUfDMGg._addon_handle,cacheToDisc=JOtndkvQesSAHPrqouiLhTXEUfDMmy)
 def wavve_main(JOtndkvQesSAHPrqouiLhTXEUfDMGg):
  JOtndkvQesSAHPrqouiLhTXEUfDMbj=JOtndkvQesSAHPrqouiLhTXEUfDMGg.main_params.get('mode',JOtndkvQesSAHPrqouiLhTXEUfDMmI)
  if JOtndkvQesSAHPrqouiLhTXEUfDMbj=='LOGOUT':
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.logout()
   return
  JOtndkvQesSAHPrqouiLhTXEUfDMGg.login_main()
  if JOtndkvQesSAHPrqouiLhTXEUfDMbj is JOtndkvQesSAHPrqouiLhTXEUfDMmI:
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.dp_Main_List()
  elif JOtndkvQesSAHPrqouiLhTXEUfDMbj in['LIVE','VOD','MOVIE','SPORTS']:
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.play_VIDEO(JOtndkvQesSAHPrqouiLhTXEUfDMGg.main_params)
  elif JOtndkvQesSAHPrqouiLhTXEUfDMbj=='LIVE_CATAGORY':
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.dp_LiveCatagory_List(JOtndkvQesSAHPrqouiLhTXEUfDMGg.main_params)
  elif JOtndkvQesSAHPrqouiLhTXEUfDMbj=='MAIN_CATAGORY':
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.dp_MainCatagory_List(JOtndkvQesSAHPrqouiLhTXEUfDMGg.main_params)
  elif JOtndkvQesSAHPrqouiLhTXEUfDMbj=='SUPERSECTION_LIST':
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.dp_SuperSection_List(JOtndkvQesSAHPrqouiLhTXEUfDMGg.main_params)
  elif JOtndkvQesSAHPrqouiLhTXEUfDMbj=='BANDLIVESECTION_LIST':
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.dp_BandLiveSection_List(JOtndkvQesSAHPrqouiLhTXEUfDMGg.main_params)
  elif JOtndkvQesSAHPrqouiLhTXEUfDMbj=='BAND2SECTION_LIST':
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.dp_Band2Section_List(JOtndkvQesSAHPrqouiLhTXEUfDMGg.main_params)
  elif JOtndkvQesSAHPrqouiLhTXEUfDMbj=='PROGRAM_LIST':
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.dp_Program_List(JOtndkvQesSAHPrqouiLhTXEUfDMGg.main_params)
  elif JOtndkvQesSAHPrqouiLhTXEUfDMbj=='EPISODE_LIST':
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.dp_Episode_List(JOtndkvQesSAHPrqouiLhTXEUfDMGg.main_params)
  elif JOtndkvQesSAHPrqouiLhTXEUfDMbj=='MOVIE_LIST':
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.dp_Movie_List(JOtndkvQesSAHPrqouiLhTXEUfDMGg.main_params)
  elif JOtndkvQesSAHPrqouiLhTXEUfDMbj=='LIVE_LIST':
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.dp_LiveChannel_List(JOtndkvQesSAHPrqouiLhTXEUfDMGg.main_params)
  elif JOtndkvQesSAHPrqouiLhTXEUfDMbj=='ORDER_BY':
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.dp_setEpOrderby(JOtndkvQesSAHPrqouiLhTXEUfDMGg.main_params)
  elif JOtndkvQesSAHPrqouiLhTXEUfDMbj=='SEARCH_GROUP':
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.dp_Search_Group(JOtndkvQesSAHPrqouiLhTXEUfDMGg.main_params)
  elif JOtndkvQesSAHPrqouiLhTXEUfDMbj in['SEARCH_LIST','LOCAL_SEARCH']:
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.dp_Search_List(JOtndkvQesSAHPrqouiLhTXEUfDMGg.main_params)
  elif JOtndkvQesSAHPrqouiLhTXEUfDMbj=='WATCH_GROUP':
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.dp_Watch_Group(JOtndkvQesSAHPrqouiLhTXEUfDMGg.main_params)
  elif JOtndkvQesSAHPrqouiLhTXEUfDMbj=='WATCH_LIST':
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.dp_Watch_List(JOtndkvQesSAHPrqouiLhTXEUfDMGg.main_params)
  elif JOtndkvQesSAHPrqouiLhTXEUfDMbj=='SET_BOOKMARK':
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.dp_Set_Bookmark(JOtndkvQesSAHPrqouiLhTXEUfDMGg.main_params)
  elif JOtndkvQesSAHPrqouiLhTXEUfDMbj in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.dp_Listfile_Delete(JOtndkvQesSAHPrqouiLhTXEUfDMGg.main_params)
  elif JOtndkvQesSAHPrqouiLhTXEUfDMbj in['TOTAL_SEARCH','TOTAL_HISTORY']:
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.dp_Global_Search(JOtndkvQesSAHPrqouiLhTXEUfDMGg.main_params)
  elif JOtndkvQesSAHPrqouiLhTXEUfDMbj=='SEARCH_HISTORY':
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.dp_Search_History(JOtndkvQesSAHPrqouiLhTXEUfDMGg.main_params)
  elif JOtndkvQesSAHPrqouiLhTXEUfDMbj=='MENU_BOOKMARK':
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.dp_Bookmark_Menu(JOtndkvQesSAHPrqouiLhTXEUfDMGg.main_params)
  elif JOtndkvQesSAHPrqouiLhTXEUfDMbj=='GAME_LIST':
   JOtndkvQesSAHPrqouiLhTXEUfDMGg.dp_Sports_GameList(JOtndkvQesSAHPrqouiLhTXEUfDMGg.main_params)
  else:
   JOtndkvQesSAHPrqouiLhTXEUfDMmI
# Created by pyminifier (https://github.com/liftoff/pyminifier)
