__author__="NightRain"
qKMpfsYkovyVIPnedzhFQORwTbHjai=object
qKMpfsYkovyVIPnedzhFQORwTbHjaA=None
qKMpfsYkovyVIPnedzhFQORwTbHjaB=False
qKMpfsYkovyVIPnedzhFQORwTbHjaC=True
qKMpfsYkovyVIPnedzhFQORwTbHjJN=range
qKMpfsYkovyVIPnedzhFQORwTbHjJl=str
qKMpfsYkovyVIPnedzhFQORwTbHjJE=Exception
qKMpfsYkovyVIPnedzhFQORwTbHjJL=print
qKMpfsYkovyVIPnedzhFQORwTbHjJa=dict
qKMpfsYkovyVIPnedzhFQORwTbHjJG=int
qKMpfsYkovyVIPnedzhFQORwTbHjJW=len
import urllib
import re
import json
import sys
import requests
import datetime
class qKMpfsYkovyVIPnedzhFQORwTbHjNl(qKMpfsYkovyVIPnedzhFQORwTbHjai):
 def __init__(qKMpfsYkovyVIPnedzhFQORwTbHjNE):
  qKMpfsYkovyVIPnedzhFQORwTbHjNE.API_DOMAIN='https://apis.wavve.com'
  qKMpfsYkovyVIPnedzhFQORwTbHjNE.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  qKMpfsYkovyVIPnedzhFQORwTbHjNE.CREDENTIAL='none'
  qKMpfsYkovyVIPnedzhFQORwTbHjNE.DEVICE ='pc'
  qKMpfsYkovyVIPnedzhFQORwTbHjNE.DRM ='wm'
  qKMpfsYkovyVIPnedzhFQORwTbHjNE.PARTNER ='pooq'
  qKMpfsYkovyVIPnedzhFQORwTbHjNE.POOQZONE ='none'
  qKMpfsYkovyVIPnedzhFQORwTbHjNE.REGION ='kor'
  qKMpfsYkovyVIPnedzhFQORwTbHjNE.TARGETAGE ='all'
  qKMpfsYkovyVIPnedzhFQORwTbHjNE.HTTPTAG ='https://'
  qKMpfsYkovyVIPnedzhFQORwTbHjNE.LIST_LIMIT=30 
  qKMpfsYkovyVIPnedzhFQORwTbHjNE.EP_LIMIT =30 
  qKMpfsYkovyVIPnedzhFQORwTbHjNE.MV_LIMIT =24 
  qKMpfsYkovyVIPnedzhFQORwTbHjNE.SEARCH_LIMIT=20 
  qKMpfsYkovyVIPnedzhFQORwTbHjNE.guid ='none' 
  qKMpfsYkovyVIPnedzhFQORwTbHjNE.guidtimestamp='none' 
  qKMpfsYkovyVIPnedzhFQORwTbHjNE.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  qKMpfsYkovyVIPnedzhFQORwTbHjNE.DEFAULT_HEADER={'user-agent':qKMpfsYkovyVIPnedzhFQORwTbHjNE.USER_AGENT}
 def callRequestCookies(qKMpfsYkovyVIPnedzhFQORwTbHjNE,jobtype,qKMpfsYkovyVIPnedzhFQORwTbHjNU,payload=qKMpfsYkovyVIPnedzhFQORwTbHjaA,params=qKMpfsYkovyVIPnedzhFQORwTbHjaA,headers=qKMpfsYkovyVIPnedzhFQORwTbHjaA,cookies=qKMpfsYkovyVIPnedzhFQORwTbHjaA,redirects=qKMpfsYkovyVIPnedzhFQORwTbHjaB):
  qKMpfsYkovyVIPnedzhFQORwTbHjNL=qKMpfsYkovyVIPnedzhFQORwTbHjNE.DEFAULT_HEADER
  if headers:qKMpfsYkovyVIPnedzhFQORwTbHjNL.update(headers)
  if jobtype=='Get':
   qKMpfsYkovyVIPnedzhFQORwTbHjNa=requests.get(qKMpfsYkovyVIPnedzhFQORwTbHjNU,params=params,headers=qKMpfsYkovyVIPnedzhFQORwTbHjNL,cookies=cookies,allow_redirects=redirects)
  else:
   qKMpfsYkovyVIPnedzhFQORwTbHjNa=requests.post(qKMpfsYkovyVIPnedzhFQORwTbHjNU,data=payload,params=params,headers=qKMpfsYkovyVIPnedzhFQORwTbHjNL,cookies=cookies,allow_redirects=redirects)
  return qKMpfsYkovyVIPnedzhFQORwTbHjNa
 def SaveCredential(qKMpfsYkovyVIPnedzhFQORwTbHjNE,qKMpfsYkovyVIPnedzhFQORwTbHjNJ):
  qKMpfsYkovyVIPnedzhFQORwTbHjNE.CREDENTIAL=qKMpfsYkovyVIPnedzhFQORwTbHjNJ
 def LoadCredential(qKMpfsYkovyVIPnedzhFQORwTbHjNE):
  return qKMpfsYkovyVIPnedzhFQORwTbHjNE.CREDENTIAL
 def GetDefaultParams(qKMpfsYkovyVIPnedzhFQORwTbHjNE,login=qKMpfsYkovyVIPnedzhFQORwTbHjaC):
  qKMpfsYkovyVIPnedzhFQORwTbHjNG={'apikey':qKMpfsYkovyVIPnedzhFQORwTbHjNE.APIKEY,'credential':qKMpfsYkovyVIPnedzhFQORwTbHjNE.CREDENTIAL if login else 'none','device':qKMpfsYkovyVIPnedzhFQORwTbHjNE.DEVICE,'drm':qKMpfsYkovyVIPnedzhFQORwTbHjNE.DRM,'partner':qKMpfsYkovyVIPnedzhFQORwTbHjNE.PARTNER,'pooqzone':qKMpfsYkovyVIPnedzhFQORwTbHjNE.POOQZONE,'region':qKMpfsYkovyVIPnedzhFQORwTbHjNE.REGION,'targetage':qKMpfsYkovyVIPnedzhFQORwTbHjNE.TARGETAGE}
  return qKMpfsYkovyVIPnedzhFQORwTbHjNG
 def GetGUID(qKMpfsYkovyVIPnedzhFQORwTbHjNE,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   qKMpfsYkovyVIPnedzhFQORwTbHjNW=qKMpfsYkovyVIPnedzhFQORwTbHjNE.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   qKMpfsYkovyVIPnedzhFQORwTbHjNc=GenerateRandomString(5)
   qKMpfsYkovyVIPnedzhFQORwTbHjNt=qKMpfsYkovyVIPnedzhFQORwTbHjNc+media+qKMpfsYkovyVIPnedzhFQORwTbHjNW
   return qKMpfsYkovyVIPnedzhFQORwTbHjNt
  def GenerateRandomString(num):
   from random import randint
   qKMpfsYkovyVIPnedzhFQORwTbHjNm=""
   for i in qKMpfsYkovyVIPnedzhFQORwTbHjJN(0,num):
    s=qKMpfsYkovyVIPnedzhFQORwTbHjJl(randint(1,5))
    qKMpfsYkovyVIPnedzhFQORwTbHjNm+=s
   return qKMpfsYkovyVIPnedzhFQORwTbHjNm
  qKMpfsYkovyVIPnedzhFQORwTbHjNt=GenerateID(guid_str)
  qKMpfsYkovyVIPnedzhFQORwTbHjNr=qKMpfsYkovyVIPnedzhFQORwTbHjNE.GetHash(qKMpfsYkovyVIPnedzhFQORwTbHjNt)
  if guidType==2:
   qKMpfsYkovyVIPnedzhFQORwTbHjNr='%s-%s-%s-%s-%s'%(qKMpfsYkovyVIPnedzhFQORwTbHjNr[:8],qKMpfsYkovyVIPnedzhFQORwTbHjNr[8:12],qKMpfsYkovyVIPnedzhFQORwTbHjNr[12:16],qKMpfsYkovyVIPnedzhFQORwTbHjNr[16:20],qKMpfsYkovyVIPnedzhFQORwTbHjNr[20:])
  return qKMpfsYkovyVIPnedzhFQORwTbHjNr
 def GetHash(qKMpfsYkovyVIPnedzhFQORwTbHjNE,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return qKMpfsYkovyVIPnedzhFQORwTbHjJl(m.hexdigest())
 def CheckQuality(qKMpfsYkovyVIPnedzhFQORwTbHjNE,sel_qt,qt_list):
  qKMpfsYkovyVIPnedzhFQORwTbHjNS=0
  for qKMpfsYkovyVIPnedzhFQORwTbHjNX in qt_list:
   if sel_qt>=qKMpfsYkovyVIPnedzhFQORwTbHjNX:return qKMpfsYkovyVIPnedzhFQORwTbHjNX
   qKMpfsYkovyVIPnedzhFQORwTbHjNS=qKMpfsYkovyVIPnedzhFQORwTbHjNX
  return qKMpfsYkovyVIPnedzhFQORwTbHjNS
 def Get_Now_Datetime(qKMpfsYkovyVIPnedzhFQORwTbHjNE):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(qKMpfsYkovyVIPnedzhFQORwTbHjNE,in_text):
  qKMpfsYkovyVIPnedzhFQORwTbHjNx=in_text.replace('&lt;','<').replace('&gt;','>')
  qKMpfsYkovyVIPnedzhFQORwTbHjNx=qKMpfsYkovyVIPnedzhFQORwTbHjNx.replace('$O$','')
  qKMpfsYkovyVIPnedzhFQORwTbHjNx=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',qKMpfsYkovyVIPnedzhFQORwTbHjNx)
  qKMpfsYkovyVIPnedzhFQORwTbHjNx=qKMpfsYkovyVIPnedzhFQORwTbHjNx.lstrip('#')
  return qKMpfsYkovyVIPnedzhFQORwTbHjNx
 def GetCredential(qKMpfsYkovyVIPnedzhFQORwTbHjNE,user_id,user_pw,user_pf):
  qKMpfsYkovyVIPnedzhFQORwTbHjND=qKMpfsYkovyVIPnedzhFQORwTbHjaB
  try:
   qKMpfsYkovyVIPnedzhFQORwTbHjNU=qKMpfsYkovyVIPnedzhFQORwTbHjNE.API_DOMAIN+ '/login'
   qKMpfsYkovyVIPnedzhFQORwTbHjNG=qKMpfsYkovyVIPnedzhFQORwTbHjNE.GetDefaultParams()
   qKMpfsYkovyVIPnedzhFQORwTbHjNu={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   qKMpfsYkovyVIPnedzhFQORwTbHjNi=qKMpfsYkovyVIPnedzhFQORwTbHjNE.callRequestCookies('Post',qKMpfsYkovyVIPnedzhFQORwTbHjNU,payload=qKMpfsYkovyVIPnedzhFQORwTbHjNu,params=qKMpfsYkovyVIPnedzhFQORwTbHjNG,headers=qKMpfsYkovyVIPnedzhFQORwTbHjaA,cookies=qKMpfsYkovyVIPnedzhFQORwTbHjaA)
   qKMpfsYkovyVIPnedzhFQORwTbHjNA=json.loads(qKMpfsYkovyVIPnedzhFQORwTbHjNi.text)
   qKMpfsYkovyVIPnedzhFQORwTbHjNJ=qKMpfsYkovyVIPnedzhFQORwTbHjNA['credential']
   if user_pf!=0:
    qKMpfsYkovyVIPnedzhFQORwTbHjNu={'id':qKMpfsYkovyVIPnedzhFQORwTbHjNJ,'password':'','profile':qKMpfsYkovyVIPnedzhFQORwTbHjJl(user_pf),'pushid':'','type':'credential'}
    qKMpfsYkovyVIPnedzhFQORwTbHjNG['credential']=qKMpfsYkovyVIPnedzhFQORwTbHjNJ 
    qKMpfsYkovyVIPnedzhFQORwTbHjNi=qKMpfsYkovyVIPnedzhFQORwTbHjNE.callRequestCookies('Post',qKMpfsYkovyVIPnedzhFQORwTbHjNU,payload=qKMpfsYkovyVIPnedzhFQORwTbHjNu,params=qKMpfsYkovyVIPnedzhFQORwTbHjNG,headers=qKMpfsYkovyVIPnedzhFQORwTbHjaA,cookies=qKMpfsYkovyVIPnedzhFQORwTbHjaA)
    qKMpfsYkovyVIPnedzhFQORwTbHjNA=json.loads(qKMpfsYkovyVIPnedzhFQORwTbHjNi.text)
    qKMpfsYkovyVIPnedzhFQORwTbHjNJ=qKMpfsYkovyVIPnedzhFQORwTbHjNA['credential']
   if qKMpfsYkovyVIPnedzhFQORwTbHjNJ:qKMpfsYkovyVIPnedzhFQORwTbHjND=qKMpfsYkovyVIPnedzhFQORwTbHjaC
  except qKMpfsYkovyVIPnedzhFQORwTbHjJE as exception:
   qKMpfsYkovyVIPnedzhFQORwTbHjJL(exception)
   qKMpfsYkovyVIPnedzhFQORwTbHjNJ='none' 
  qKMpfsYkovyVIPnedzhFQORwTbHjNE.SaveCredential(qKMpfsYkovyVIPnedzhFQORwTbHjNJ)
  return qKMpfsYkovyVIPnedzhFQORwTbHjND
 def GetIssue(qKMpfsYkovyVIPnedzhFQORwTbHjNE):
  qKMpfsYkovyVIPnedzhFQORwTbHjNB=qKMpfsYkovyVIPnedzhFQORwTbHjaB
  try:
   qKMpfsYkovyVIPnedzhFQORwTbHjNU=qKMpfsYkovyVIPnedzhFQORwTbHjNE.API_DOMAIN+'/guid/issue'
   qKMpfsYkovyVIPnedzhFQORwTbHjNG=qKMpfsYkovyVIPnedzhFQORwTbHjNE.GetDefaultParams()
   qKMpfsYkovyVIPnedzhFQORwTbHjNi=qKMpfsYkovyVIPnedzhFQORwTbHjNE.callRequestCookies('Get',qKMpfsYkovyVIPnedzhFQORwTbHjNU,payload=qKMpfsYkovyVIPnedzhFQORwTbHjaA,params=qKMpfsYkovyVIPnedzhFQORwTbHjNG,headers=qKMpfsYkovyVIPnedzhFQORwTbHjaA,cookies=qKMpfsYkovyVIPnedzhFQORwTbHjaA)
   qKMpfsYkovyVIPnedzhFQORwTbHjNA=json.loads(qKMpfsYkovyVIPnedzhFQORwTbHjNi.text)
   qKMpfsYkovyVIPnedzhFQORwTbHjNC=qKMpfsYkovyVIPnedzhFQORwTbHjNA['guid']
   qKMpfsYkovyVIPnedzhFQORwTbHjlN=qKMpfsYkovyVIPnedzhFQORwTbHjNA['guidtimestamp']
   if qKMpfsYkovyVIPnedzhFQORwTbHjNC:qKMpfsYkovyVIPnedzhFQORwTbHjNB=qKMpfsYkovyVIPnedzhFQORwTbHjaC
  except qKMpfsYkovyVIPnedzhFQORwTbHjJE as exception:
   qKMpfsYkovyVIPnedzhFQORwTbHjJL(exception)
   qKMpfsYkovyVIPnedzhFQORwTbHjNC='none'
   qKMpfsYkovyVIPnedzhFQORwTbHjlN='none' 
  qKMpfsYkovyVIPnedzhFQORwTbHjNE.guid=qKMpfsYkovyVIPnedzhFQORwTbHjNC
  qKMpfsYkovyVIPnedzhFQORwTbHjNE.guidtimestamp=qKMpfsYkovyVIPnedzhFQORwTbHjlN
  return qKMpfsYkovyVIPnedzhFQORwTbHjNB
 def Baseapi_Parse(qKMpfsYkovyVIPnedzhFQORwTbHjNE,qKMpfsYkovyVIPnedzhFQORwTbHjlJ):
  try:
   qKMpfsYkovyVIPnedzhFQORwTbHjlE =urllib.parse.urlsplit(qKMpfsYkovyVIPnedzhFQORwTbHjlJ)
   if qKMpfsYkovyVIPnedzhFQORwTbHjlE.netloc=='':
    qKMpfsYkovyVIPnedzhFQORwTbHjNU=qKMpfsYkovyVIPnedzhFQORwTbHjNE.HTTPTAG+qKMpfsYkovyVIPnedzhFQORwTbHjlE.netloc+qKMpfsYkovyVIPnedzhFQORwTbHjlE.path
   else:
    qKMpfsYkovyVIPnedzhFQORwTbHjNU=qKMpfsYkovyVIPnedzhFQORwTbHjlE.scheme+'://'+qKMpfsYkovyVIPnedzhFQORwTbHjlE.netloc+qKMpfsYkovyVIPnedzhFQORwTbHjlE.path
   qKMpfsYkovyVIPnedzhFQORwTbHjNG=qKMpfsYkovyVIPnedzhFQORwTbHjJa(urllib.parse.parse_qsl(qKMpfsYkovyVIPnedzhFQORwTbHjlE.query))
  except:
   qKMpfsYkovyVIPnedzhFQORwTbHjJL(exception)
   return '',{}
  return qKMpfsYkovyVIPnedzhFQORwTbHjNU,qKMpfsYkovyVIPnedzhFQORwTbHjNG
 def GetSupermultiUrl(qKMpfsYkovyVIPnedzhFQORwTbHjNE,sCode,sIndex='0'):
  try:
   qKMpfsYkovyVIPnedzhFQORwTbHjNU=qKMpfsYkovyVIPnedzhFQORwTbHjNE.API_DOMAIN+'/cf/supermultisections/'+sCode
   qKMpfsYkovyVIPnedzhFQORwTbHjNG=qKMpfsYkovyVIPnedzhFQORwTbHjNE.GetDefaultParams(login=qKMpfsYkovyVIPnedzhFQORwTbHjaB)
   qKMpfsYkovyVIPnedzhFQORwTbHjNi=qKMpfsYkovyVIPnedzhFQORwTbHjNE.callRequestCookies('Get',qKMpfsYkovyVIPnedzhFQORwTbHjNU,payload=qKMpfsYkovyVIPnedzhFQORwTbHjaA,params=qKMpfsYkovyVIPnedzhFQORwTbHjNG,headers=qKMpfsYkovyVIPnedzhFQORwTbHjaA,cookies=qKMpfsYkovyVIPnedzhFQORwTbHjaA)
   qKMpfsYkovyVIPnedzhFQORwTbHjNA=json.loads(qKMpfsYkovyVIPnedzhFQORwTbHjNi.text)
   qKMpfsYkovyVIPnedzhFQORwTbHjlL=qKMpfsYkovyVIPnedzhFQORwTbHjNA['multisectionlist'][qKMpfsYkovyVIPnedzhFQORwTbHjJG(sIndex)]['eventlist'][1]['url']
  except qKMpfsYkovyVIPnedzhFQORwTbHjJE as exception:
   qKMpfsYkovyVIPnedzhFQORwTbHjJL(exception)
   return ''
  return qKMpfsYkovyVIPnedzhFQORwTbHjlL
 def Get_LiveCatagory_List(qKMpfsYkovyVIPnedzhFQORwTbHjNE,sCode,sIndex='0'):
  qKMpfsYkovyVIPnedzhFQORwTbHjla=[]
  qKMpfsYkovyVIPnedzhFQORwTbHjlJ =qKMpfsYkovyVIPnedzhFQORwTbHjNE.GetSupermultiUrl(sCode,sIndex)
  (qKMpfsYkovyVIPnedzhFQORwTbHjNU,qKMpfsYkovyVIPnedzhFQORwTbHjNG)=qKMpfsYkovyVIPnedzhFQORwTbHjNE.Baseapi_Parse(qKMpfsYkovyVIPnedzhFQORwTbHjlJ)
  if qKMpfsYkovyVIPnedzhFQORwTbHjNU=='':return qKMpfsYkovyVIPnedzhFQORwTbHjla,''
  try:
   qKMpfsYkovyVIPnedzhFQORwTbHjNG.update(qKMpfsYkovyVIPnedzhFQORwTbHjNE.GetDefaultParams(login=qKMpfsYkovyVIPnedzhFQORwTbHjaB))
   qKMpfsYkovyVIPnedzhFQORwTbHjNi=qKMpfsYkovyVIPnedzhFQORwTbHjNE.callRequestCookies('Get',qKMpfsYkovyVIPnedzhFQORwTbHjNU,payload=qKMpfsYkovyVIPnedzhFQORwTbHjaA,params=qKMpfsYkovyVIPnedzhFQORwTbHjNG,headers=qKMpfsYkovyVIPnedzhFQORwTbHjaA,cookies=qKMpfsYkovyVIPnedzhFQORwTbHjaA)
   qKMpfsYkovyVIPnedzhFQORwTbHjNA=json.loads(qKMpfsYkovyVIPnedzhFQORwTbHjNi.text)
   if not('filter_item_list' in qKMpfsYkovyVIPnedzhFQORwTbHjNA['filter']['filterlist'][0]):return[],''
   qKMpfsYkovyVIPnedzhFQORwTbHjlW=qKMpfsYkovyVIPnedzhFQORwTbHjNA['filter']['filterlist'][0]['filter_item_list']
   for qKMpfsYkovyVIPnedzhFQORwTbHjlc in qKMpfsYkovyVIPnedzhFQORwTbHjlW:
    qKMpfsYkovyVIPnedzhFQORwTbHjlt={'title':qKMpfsYkovyVIPnedzhFQORwTbHjlc['title'],'genre':qKMpfsYkovyVIPnedzhFQORwTbHjlc['api_parameters'][qKMpfsYkovyVIPnedzhFQORwTbHjlc['api_parameters'].index('=')+1:]}
    qKMpfsYkovyVIPnedzhFQORwTbHjla.append(qKMpfsYkovyVIPnedzhFQORwTbHjlt)
  except qKMpfsYkovyVIPnedzhFQORwTbHjJE as exception:
   qKMpfsYkovyVIPnedzhFQORwTbHjJL(exception)
   return[],''
  return qKMpfsYkovyVIPnedzhFQORwTbHjla,qKMpfsYkovyVIPnedzhFQORwTbHjlJ
 def Get_MainCatagory_List(qKMpfsYkovyVIPnedzhFQORwTbHjNE,sCode,sIndex='0'):
  qKMpfsYkovyVIPnedzhFQORwTbHjla=[]
  qKMpfsYkovyVIPnedzhFQORwTbHjlJ =qKMpfsYkovyVIPnedzhFQORwTbHjNE.GetSupermultiUrl(sCode,sIndex)
  (qKMpfsYkovyVIPnedzhFQORwTbHjNU,qKMpfsYkovyVIPnedzhFQORwTbHjNG)=qKMpfsYkovyVIPnedzhFQORwTbHjNE.Baseapi_Parse(qKMpfsYkovyVIPnedzhFQORwTbHjlJ)
  if qKMpfsYkovyVIPnedzhFQORwTbHjNU=='':return qKMpfsYkovyVIPnedzhFQORwTbHjla
  try:
   qKMpfsYkovyVIPnedzhFQORwTbHjNG.update(qKMpfsYkovyVIPnedzhFQORwTbHjNE.GetDefaultParams(login=qKMpfsYkovyVIPnedzhFQORwTbHjaB))
   qKMpfsYkovyVIPnedzhFQORwTbHjNi=qKMpfsYkovyVIPnedzhFQORwTbHjNE.callRequestCookies('Get',qKMpfsYkovyVIPnedzhFQORwTbHjNU,payload=qKMpfsYkovyVIPnedzhFQORwTbHjaA,params=qKMpfsYkovyVIPnedzhFQORwTbHjNG,headers=qKMpfsYkovyVIPnedzhFQORwTbHjaA,cookies=qKMpfsYkovyVIPnedzhFQORwTbHjaA)
   qKMpfsYkovyVIPnedzhFQORwTbHjNA=json.loads(qKMpfsYkovyVIPnedzhFQORwTbHjNi.text)
   if not('celllist' in qKMpfsYkovyVIPnedzhFQORwTbHjNA['band']):return[]
   qKMpfsYkovyVIPnedzhFQORwTbHjlW=qKMpfsYkovyVIPnedzhFQORwTbHjNA['band']['celllist']
   for qKMpfsYkovyVIPnedzhFQORwTbHjlc in qKMpfsYkovyVIPnedzhFQORwTbHjlW:
    qKMpfsYkovyVIPnedzhFQORwTbHjlm =qKMpfsYkovyVIPnedzhFQORwTbHjlc['event_list'][1]['url']
    (qKMpfsYkovyVIPnedzhFQORwTbHjlr,qKMpfsYkovyVIPnedzhFQORwTbHjlS)=qKMpfsYkovyVIPnedzhFQORwTbHjNE.Baseapi_Parse(qKMpfsYkovyVIPnedzhFQORwTbHjlm)
    qKMpfsYkovyVIPnedzhFQORwTbHjlt={'title':qKMpfsYkovyVIPnedzhFQORwTbHjlc['title_list'][0]['text'],'suburl':qKMpfsYkovyVIPnedzhFQORwTbHjlr,'subapi':qKMpfsYkovyVIPnedzhFQORwTbHjlS.get('api'),'subtype':'catagory' if qKMpfsYkovyVIPnedzhFQORwTbHjlS else 'supersection'}
    qKMpfsYkovyVIPnedzhFQORwTbHjla.append(qKMpfsYkovyVIPnedzhFQORwTbHjlt)
  except qKMpfsYkovyVIPnedzhFQORwTbHjJE as exception:
   qKMpfsYkovyVIPnedzhFQORwTbHjJL(exception)
   return[]
  return qKMpfsYkovyVIPnedzhFQORwTbHjla
 def Get_SuperMultiSection_List(qKMpfsYkovyVIPnedzhFQORwTbHjNE,subapi_text):
  qKMpfsYkovyVIPnedzhFQORwTbHjla=[]
  qKMpfsYkovyVIPnedzhFQORwTbHjNG={}
  try:
   qKMpfsYkovyVIPnedzhFQORwTbHjlE =urllib.parse.urlsplit(subapi_text)
   if qKMpfsYkovyVIPnedzhFQORwTbHjlE.path.find('apis.wavve.com')>=0: 
    qKMpfsYkovyVIPnedzhFQORwTbHjNU=qKMpfsYkovyVIPnedzhFQORwTbHjNE.HTTPTAG+qKMpfsYkovyVIPnedzhFQORwTbHjlE.path 
    qKMpfsYkovyVIPnedzhFQORwTbHjNG=qKMpfsYkovyVIPnedzhFQORwTbHjJa(urllib.parse.parse_qsl(qKMpfsYkovyVIPnedzhFQORwTbHjlE.query))
   else:
    qKMpfsYkovyVIPnedzhFQORwTbHjNU=qKMpfsYkovyVIPnedzhFQORwTbHjNE.API_DOMAIN+'/cf'+qKMpfsYkovyVIPnedzhFQORwTbHjlE.path 
   qKMpfsYkovyVIPnedzhFQORwTbHjNU=qKMpfsYkovyVIPnedzhFQORwTbHjNU.replace('supermultisection/','supermultisections/')
  except qKMpfsYkovyVIPnedzhFQORwTbHjJE as exception:
   qKMpfsYkovyVIPnedzhFQORwTbHjJL(exception)
   return[]
  try:
   qKMpfsYkovyVIPnedzhFQORwTbHjNG.update(qKMpfsYkovyVIPnedzhFQORwTbHjNE.GetDefaultParams(login=qKMpfsYkovyVIPnedzhFQORwTbHjaB))
   qKMpfsYkovyVIPnedzhFQORwTbHjNi=qKMpfsYkovyVIPnedzhFQORwTbHjNE.callRequestCookies('Get',qKMpfsYkovyVIPnedzhFQORwTbHjNU,payload=qKMpfsYkovyVIPnedzhFQORwTbHjaA,params=qKMpfsYkovyVIPnedzhFQORwTbHjaA,headers=qKMpfsYkovyVIPnedzhFQORwTbHjaA,cookies=qKMpfsYkovyVIPnedzhFQORwTbHjaA)
   qKMpfsYkovyVIPnedzhFQORwTbHjNA=json.loads(qKMpfsYkovyVIPnedzhFQORwTbHjNi.text)
   if not('multisectionlist' in qKMpfsYkovyVIPnedzhFQORwTbHjNA):return[]
   qKMpfsYkovyVIPnedzhFQORwTbHjlW=qKMpfsYkovyVIPnedzhFQORwTbHjNA['multisectionlist']
   for qKMpfsYkovyVIPnedzhFQORwTbHjlc in qKMpfsYkovyVIPnedzhFQORwTbHjlW:
    qKMpfsYkovyVIPnedzhFQORwTbHjlX=qKMpfsYkovyVIPnedzhFQORwTbHjlc['title']
    if qKMpfsYkovyVIPnedzhFQORwTbHjJW(qKMpfsYkovyVIPnedzhFQORwTbHjlX)==0:continue
    if qKMpfsYkovyVIPnedzhFQORwTbHjlX=='minor':continue
    if re.search(u'베너',qKMpfsYkovyVIPnedzhFQORwTbHjlX):continue
    if re.search(u'배너',qKMpfsYkovyVIPnedzhFQORwTbHjlX):continue 
    if qKMpfsYkovyVIPnedzhFQORwTbHjJW(qKMpfsYkovyVIPnedzhFQORwTbHjlc['eventlist'])>=3:
     qKMpfsYkovyVIPnedzhFQORwTbHjlS =qKMpfsYkovyVIPnedzhFQORwTbHjlc['eventlist'][2]['url']
    else:
     qKMpfsYkovyVIPnedzhFQORwTbHjlS =qKMpfsYkovyVIPnedzhFQORwTbHjlc['eventlist'][1]['url']
    qKMpfsYkovyVIPnedzhFQORwTbHjlg=qKMpfsYkovyVIPnedzhFQORwTbHjlc['cell_type']
    if qKMpfsYkovyVIPnedzhFQORwTbHjlg=='band_2':
     if qKMpfsYkovyVIPnedzhFQORwTbHjlS.find('channellist=')>=0:
      qKMpfsYkovyVIPnedzhFQORwTbHjlg='band_live'
    qKMpfsYkovyVIPnedzhFQORwTbHjlt={'title':qKMpfsYkovyVIPnedzhFQORwTbHjNE.Get_ChangeText(qKMpfsYkovyVIPnedzhFQORwTbHjlX),'subapi':qKMpfsYkovyVIPnedzhFQORwTbHjlS,'cell_type':qKMpfsYkovyVIPnedzhFQORwTbHjlg}
    qKMpfsYkovyVIPnedzhFQORwTbHjla.append(qKMpfsYkovyVIPnedzhFQORwTbHjlt)
  except qKMpfsYkovyVIPnedzhFQORwTbHjJE as exception:
   qKMpfsYkovyVIPnedzhFQORwTbHjJL(exception)
   return[]
  return qKMpfsYkovyVIPnedzhFQORwTbHjla
 def Get_BandLiveSection_List(qKMpfsYkovyVIPnedzhFQORwTbHjNE,qKMpfsYkovyVIPnedzhFQORwTbHjlJ,page_int=1):
  qKMpfsYkovyVIPnedzhFQORwTbHjlx=[]
  qKMpfsYkovyVIPnedzhFQORwTbHjlD=qKMpfsYkovyVIPnedzhFQORwTbHjlC=1
  qKMpfsYkovyVIPnedzhFQORwTbHjlU=qKMpfsYkovyVIPnedzhFQORwTbHjaB
  try:
   (qKMpfsYkovyVIPnedzhFQORwTbHjNU,qKMpfsYkovyVIPnedzhFQORwTbHjNG)=qKMpfsYkovyVIPnedzhFQORwTbHjNE.Baseapi_Parse(qKMpfsYkovyVIPnedzhFQORwTbHjlJ)
  except qKMpfsYkovyVIPnedzhFQORwTbHjJE as exception:
   qKMpfsYkovyVIPnedzhFQORwTbHjJL(exception)
   return[],qKMpfsYkovyVIPnedzhFQORwTbHjaB
  try:
   qKMpfsYkovyVIPnedzhFQORwTbHjNG['limit']=qKMpfsYkovyVIPnedzhFQORwTbHjNE.LIST_LIMIT
   qKMpfsYkovyVIPnedzhFQORwTbHjNG['offset']=qKMpfsYkovyVIPnedzhFQORwTbHjJl((page_int-1)*qKMpfsYkovyVIPnedzhFQORwTbHjNE.LIST_LIMIT)
   qKMpfsYkovyVIPnedzhFQORwTbHjNG.update(qKMpfsYkovyVIPnedzhFQORwTbHjNE.GetDefaultParams(login=qKMpfsYkovyVIPnedzhFQORwTbHjaB))
   qKMpfsYkovyVIPnedzhFQORwTbHjNi=qKMpfsYkovyVIPnedzhFQORwTbHjNE.callRequestCookies('Get',qKMpfsYkovyVIPnedzhFQORwTbHjNU,payload=qKMpfsYkovyVIPnedzhFQORwTbHjaA,params=qKMpfsYkovyVIPnedzhFQORwTbHjNG,headers=qKMpfsYkovyVIPnedzhFQORwTbHjaA,cookies=qKMpfsYkovyVIPnedzhFQORwTbHjaA)
   qKMpfsYkovyVIPnedzhFQORwTbHjNA=json.loads(qKMpfsYkovyVIPnedzhFQORwTbHjNi.text)
   if not('celllist' in qKMpfsYkovyVIPnedzhFQORwTbHjNA['cell_toplist']):return[],qKMpfsYkovyVIPnedzhFQORwTbHjaB
   qKMpfsYkovyVIPnedzhFQORwTbHjlW=qKMpfsYkovyVIPnedzhFQORwTbHjNA['cell_toplist']['celllist']
   for qKMpfsYkovyVIPnedzhFQORwTbHjlc in qKMpfsYkovyVIPnedzhFQORwTbHjlW:
    qKMpfsYkovyVIPnedzhFQORwTbHjlu =qKMpfsYkovyVIPnedzhFQORwTbHjlc['event_list'][1]['url']
    qKMpfsYkovyVIPnedzhFQORwTbHjli=urllib.parse.urlsplit(qKMpfsYkovyVIPnedzhFQORwTbHjlu).query
    qKMpfsYkovyVIPnedzhFQORwTbHjli=qKMpfsYkovyVIPnedzhFQORwTbHjJa(urllib.parse.parse_qsl(qKMpfsYkovyVIPnedzhFQORwTbHjli))
    qKMpfsYkovyVIPnedzhFQORwTbHjlA='channelid'
    qKMpfsYkovyVIPnedzhFQORwTbHjlB=qKMpfsYkovyVIPnedzhFQORwTbHjli[qKMpfsYkovyVIPnedzhFQORwTbHjlA]
    qKMpfsYkovyVIPnedzhFQORwTbHjlt={'studio':qKMpfsYkovyVIPnedzhFQORwTbHjlc['title_list'][0]['text'],'tvshowtitle':qKMpfsYkovyVIPnedzhFQORwTbHjNE.Get_ChangeText(qKMpfsYkovyVIPnedzhFQORwTbHjlc['title_list'][1]['text']),'channelid':qKMpfsYkovyVIPnedzhFQORwTbHjlB,'age':qKMpfsYkovyVIPnedzhFQORwTbHjlc.get('age'),'thumbnail':'https://%s'%qKMpfsYkovyVIPnedzhFQORwTbHjlc.get('thumbnail')}
    qKMpfsYkovyVIPnedzhFQORwTbHjlx.append(qKMpfsYkovyVIPnedzhFQORwTbHjlt)
   qKMpfsYkovyVIPnedzhFQORwTbHjlD=qKMpfsYkovyVIPnedzhFQORwTbHjJG(qKMpfsYkovyVIPnedzhFQORwTbHjNA['cell_toplist']['pagecount'])
   if qKMpfsYkovyVIPnedzhFQORwTbHjNA['cell_toplist']['count']:qKMpfsYkovyVIPnedzhFQORwTbHjlC =qKMpfsYkovyVIPnedzhFQORwTbHjJG(qKMpfsYkovyVIPnedzhFQORwTbHjNA['cell_toplist']['count'])
   else:qKMpfsYkovyVIPnedzhFQORwTbHjlC=qKMpfsYkovyVIPnedzhFQORwTbHjNE.LIST_LIMIT*page_int
   qKMpfsYkovyVIPnedzhFQORwTbHjlU=qKMpfsYkovyVIPnedzhFQORwTbHjlD>qKMpfsYkovyVIPnedzhFQORwTbHjlC
  except qKMpfsYkovyVIPnedzhFQORwTbHjJE as exception:
   qKMpfsYkovyVIPnedzhFQORwTbHjJL(exception)
   return[],qKMpfsYkovyVIPnedzhFQORwTbHjaB
  return qKMpfsYkovyVIPnedzhFQORwTbHjlx,qKMpfsYkovyVIPnedzhFQORwTbHjlU
 def Get_Band2Section_List(qKMpfsYkovyVIPnedzhFQORwTbHjNE,qKMpfsYkovyVIPnedzhFQORwTbHjlJ,page_int=1):
  qKMpfsYkovyVIPnedzhFQORwTbHjEN=[]
  qKMpfsYkovyVIPnedzhFQORwTbHjlD=qKMpfsYkovyVIPnedzhFQORwTbHjlC=1
  qKMpfsYkovyVIPnedzhFQORwTbHjlU=qKMpfsYkovyVIPnedzhFQORwTbHjaB
  try:
   (qKMpfsYkovyVIPnedzhFQORwTbHjNU,qKMpfsYkovyVIPnedzhFQORwTbHjNG)=qKMpfsYkovyVIPnedzhFQORwTbHjNE.Baseapi_Parse(qKMpfsYkovyVIPnedzhFQORwTbHjlJ)
  except qKMpfsYkovyVIPnedzhFQORwTbHjJE as exception:
   qKMpfsYkovyVIPnedzhFQORwTbHjJL(exception)
   return[],qKMpfsYkovyVIPnedzhFQORwTbHjaB
  try:
   qKMpfsYkovyVIPnedzhFQORwTbHjNG['came'] ='BandView'
   qKMpfsYkovyVIPnedzhFQORwTbHjNG['limit']=qKMpfsYkovyVIPnedzhFQORwTbHjNE.LIST_LIMIT
   qKMpfsYkovyVIPnedzhFQORwTbHjNG['offset']=qKMpfsYkovyVIPnedzhFQORwTbHjJl((page_int-1)*qKMpfsYkovyVIPnedzhFQORwTbHjNE.LIST_LIMIT)
   qKMpfsYkovyVIPnedzhFQORwTbHjNG.update(qKMpfsYkovyVIPnedzhFQORwTbHjNE.GetDefaultParams(login=qKMpfsYkovyVIPnedzhFQORwTbHjaB))
   qKMpfsYkovyVIPnedzhFQORwTbHjNi=qKMpfsYkovyVIPnedzhFQORwTbHjNE.callRequestCookies('Get',qKMpfsYkovyVIPnedzhFQORwTbHjNU,payload=qKMpfsYkovyVIPnedzhFQORwTbHjaA,params=qKMpfsYkovyVIPnedzhFQORwTbHjNG,headers=qKMpfsYkovyVIPnedzhFQORwTbHjaA,cookies=qKMpfsYkovyVIPnedzhFQORwTbHjaA)
   qKMpfsYkovyVIPnedzhFQORwTbHjNA=json.loads(qKMpfsYkovyVIPnedzhFQORwTbHjNi.text)
   if not('celllist' in qKMpfsYkovyVIPnedzhFQORwTbHjNA['cell_toplist']):return[],qKMpfsYkovyVIPnedzhFQORwTbHjaB
   qKMpfsYkovyVIPnedzhFQORwTbHjlW=qKMpfsYkovyVIPnedzhFQORwTbHjNA['cell_toplist']['celllist']
   for qKMpfsYkovyVIPnedzhFQORwTbHjlc in qKMpfsYkovyVIPnedzhFQORwTbHjlW:
    qKMpfsYkovyVIPnedzhFQORwTbHjlu =qKMpfsYkovyVIPnedzhFQORwTbHjlc['event_list'][1]['url']
    qKMpfsYkovyVIPnedzhFQORwTbHjli=urllib.parse.urlsplit(qKMpfsYkovyVIPnedzhFQORwTbHjlu).query
    qKMpfsYkovyVIPnedzhFQORwTbHjli=qKMpfsYkovyVIPnedzhFQORwTbHjJa(urllib.parse.parse_qsl(qKMpfsYkovyVIPnedzhFQORwTbHjli))
    qKMpfsYkovyVIPnedzhFQORwTbHjlA='contentid'
    qKMpfsYkovyVIPnedzhFQORwTbHjlB=qKMpfsYkovyVIPnedzhFQORwTbHjli[qKMpfsYkovyVIPnedzhFQORwTbHjlA]
    qKMpfsYkovyVIPnedzhFQORwTbHjlt={'programtitle':qKMpfsYkovyVIPnedzhFQORwTbHjlc['title_list'][0]['text'],'episodetitle':qKMpfsYkovyVIPnedzhFQORwTbHjNE.Get_ChangeText(qKMpfsYkovyVIPnedzhFQORwTbHjlc['title_list'][1]['text']),'age':qKMpfsYkovyVIPnedzhFQORwTbHjlc.get('age'),'thumbnail':qKMpfsYkovyVIPnedzhFQORwTbHjNE.HTTPTAG+qKMpfsYkovyVIPnedzhFQORwTbHjlc.get('thumbnail'),'vidtype':qKMpfsYkovyVIPnedzhFQORwTbHjlA,'videoid':qKMpfsYkovyVIPnedzhFQORwTbHjlB}
    qKMpfsYkovyVIPnedzhFQORwTbHjEN.append(qKMpfsYkovyVIPnedzhFQORwTbHjlt)
   qKMpfsYkovyVIPnedzhFQORwTbHjlD=qKMpfsYkovyVIPnedzhFQORwTbHjJG(qKMpfsYkovyVIPnedzhFQORwTbHjNA['cell_toplist']['pagecount'])
   if qKMpfsYkovyVIPnedzhFQORwTbHjNA['cell_toplist']['count']:qKMpfsYkovyVIPnedzhFQORwTbHjlC =qKMpfsYkovyVIPnedzhFQORwTbHjJG(qKMpfsYkovyVIPnedzhFQORwTbHjNA['cell_toplist']['count'])
   else:qKMpfsYkovyVIPnedzhFQORwTbHjlC=qKMpfsYkovyVIPnedzhFQORwTbHjNE.LIST_LIMIT*page_int
   qKMpfsYkovyVIPnedzhFQORwTbHjlU=qKMpfsYkovyVIPnedzhFQORwTbHjlD>qKMpfsYkovyVIPnedzhFQORwTbHjlC
  except qKMpfsYkovyVIPnedzhFQORwTbHjJE as exception:
   qKMpfsYkovyVIPnedzhFQORwTbHjJL(exception)
   return[],qKMpfsYkovyVIPnedzhFQORwTbHjaB
  return qKMpfsYkovyVIPnedzhFQORwTbHjEN,qKMpfsYkovyVIPnedzhFQORwTbHjlU
 def Get_Program_List(qKMpfsYkovyVIPnedzhFQORwTbHjNE,qKMpfsYkovyVIPnedzhFQORwTbHjlJ,page_int=1,orderby='-'):
  qKMpfsYkovyVIPnedzhFQORwTbHjEl=[]
  qKMpfsYkovyVIPnedzhFQORwTbHjlD=qKMpfsYkovyVIPnedzhFQORwTbHjlC=1
  qKMpfsYkovyVIPnedzhFQORwTbHjlU=qKMpfsYkovyVIPnedzhFQORwTbHjaB
  (qKMpfsYkovyVIPnedzhFQORwTbHjNU,qKMpfsYkovyVIPnedzhFQORwTbHjNG)=qKMpfsYkovyVIPnedzhFQORwTbHjNE.Baseapi_Parse(qKMpfsYkovyVIPnedzhFQORwTbHjlJ)
  if qKMpfsYkovyVIPnedzhFQORwTbHjNU=='':return qKMpfsYkovyVIPnedzhFQORwTbHjEl,qKMpfsYkovyVIPnedzhFQORwTbHjlU
  try:
   qKMpfsYkovyVIPnedzhFQORwTbHjNG['limit'] =qKMpfsYkovyVIPnedzhFQORwTbHjNE.LIST_LIMIT
   qKMpfsYkovyVIPnedzhFQORwTbHjNG['offset']=qKMpfsYkovyVIPnedzhFQORwTbHjJl((page_int-1)*qKMpfsYkovyVIPnedzhFQORwTbHjNE.LIST_LIMIT)
   qKMpfsYkovyVIPnedzhFQORwTbHjNG['page'] =qKMpfsYkovyVIPnedzhFQORwTbHjJl(page_int)
   if qKMpfsYkovyVIPnedzhFQORwTbHjNG.get('orderby')!='' and qKMpfsYkovyVIPnedzhFQORwTbHjNG.get('orderby')!='regdatefirst' and orderby!='-':
    qKMpfsYkovyVIPnedzhFQORwTbHjNG['orderby']=orderby 
   qKMpfsYkovyVIPnedzhFQORwTbHjNG.update(qKMpfsYkovyVIPnedzhFQORwTbHjNE.GetDefaultParams(login=qKMpfsYkovyVIPnedzhFQORwTbHjaB))
   qKMpfsYkovyVIPnedzhFQORwTbHjNi=qKMpfsYkovyVIPnedzhFQORwTbHjNE.callRequestCookies('Get',qKMpfsYkovyVIPnedzhFQORwTbHjNU,payload=qKMpfsYkovyVIPnedzhFQORwTbHjaA,params=qKMpfsYkovyVIPnedzhFQORwTbHjNG,headers=qKMpfsYkovyVIPnedzhFQORwTbHjaA,cookies=qKMpfsYkovyVIPnedzhFQORwTbHjaA)
   qKMpfsYkovyVIPnedzhFQORwTbHjNA=json.loads(qKMpfsYkovyVIPnedzhFQORwTbHjNi.text)
   if qKMpfsYkovyVIPnedzhFQORwTbHjlJ.find('instantplay')>=0:
    if not('celllist' in qKMpfsYkovyVIPnedzhFQORwTbHjNA['band']):return qKMpfsYkovyVIPnedzhFQORwTbHjEl,qKMpfsYkovyVIPnedzhFQORwTbHjlU
    qKMpfsYkovyVIPnedzhFQORwTbHjlW=qKMpfsYkovyVIPnedzhFQORwTbHjNA['band']['celllist']
   else:
    if not('celllist' in qKMpfsYkovyVIPnedzhFQORwTbHjNA['cell_toplist']):return qKMpfsYkovyVIPnedzhFQORwTbHjEl,qKMpfsYkovyVIPnedzhFQORwTbHjlU
    qKMpfsYkovyVIPnedzhFQORwTbHjlW=qKMpfsYkovyVIPnedzhFQORwTbHjNA['cell_toplist']['celllist']
   for qKMpfsYkovyVIPnedzhFQORwTbHjlc in qKMpfsYkovyVIPnedzhFQORwTbHjlW:
    for qKMpfsYkovyVIPnedzhFQORwTbHjEL in qKMpfsYkovyVIPnedzhFQORwTbHjlc['event_list']:
     if qKMpfsYkovyVIPnedzhFQORwTbHjEL.get('type')=='on-navigation':
      qKMpfsYkovyVIPnedzhFQORwTbHjlu =qKMpfsYkovyVIPnedzhFQORwTbHjEL['url']
    qKMpfsYkovyVIPnedzhFQORwTbHjli=urllib.parse.urlsplit(qKMpfsYkovyVIPnedzhFQORwTbHjlu).query
    qKMpfsYkovyVIPnedzhFQORwTbHjlA=qKMpfsYkovyVIPnedzhFQORwTbHjli[0:qKMpfsYkovyVIPnedzhFQORwTbHjli.find('=')]
    qKMpfsYkovyVIPnedzhFQORwTbHjlB=qKMpfsYkovyVIPnedzhFQORwTbHjli[qKMpfsYkovyVIPnedzhFQORwTbHjli.find('=')+1:]
    qKMpfsYkovyVIPnedzhFQORwTbHjlt={'title':qKMpfsYkovyVIPnedzhFQORwTbHjlc['title_list'][0]['text'],'age':qKMpfsYkovyVIPnedzhFQORwTbHjlc['age'],'thumbnail':'https://%s'%qKMpfsYkovyVIPnedzhFQORwTbHjlc.get('thumbnail'),'videoid':qKMpfsYkovyVIPnedzhFQORwTbHjlB,'vidtype':qKMpfsYkovyVIPnedzhFQORwTbHjlA}
    qKMpfsYkovyVIPnedzhFQORwTbHjEl.append(qKMpfsYkovyVIPnedzhFQORwTbHjlt)
   if qKMpfsYkovyVIPnedzhFQORwTbHjlJ.find('instantplay')<0:
    qKMpfsYkovyVIPnedzhFQORwTbHjlD=qKMpfsYkovyVIPnedzhFQORwTbHjJG(qKMpfsYkovyVIPnedzhFQORwTbHjNA['cell_toplist']['pagecount'])
    if qKMpfsYkovyVIPnedzhFQORwTbHjNA['cell_toplist']['count']:qKMpfsYkovyVIPnedzhFQORwTbHjlC =qKMpfsYkovyVIPnedzhFQORwTbHjJG(qKMpfsYkovyVIPnedzhFQORwTbHjNA['cell_toplist']['count'])
    else:qKMpfsYkovyVIPnedzhFQORwTbHjlC=qKMpfsYkovyVIPnedzhFQORwTbHjNE.LIST_LIMIT*page_int
    qKMpfsYkovyVIPnedzhFQORwTbHjlU=qKMpfsYkovyVIPnedzhFQORwTbHjlD>qKMpfsYkovyVIPnedzhFQORwTbHjlC
  except qKMpfsYkovyVIPnedzhFQORwTbHjJE as exception:
   qKMpfsYkovyVIPnedzhFQORwTbHjJL(exception)
   return[],qKMpfsYkovyVIPnedzhFQORwTbHjaB
  return qKMpfsYkovyVIPnedzhFQORwTbHjEl,qKMpfsYkovyVIPnedzhFQORwTbHjlU
 def Get_Movie_List(qKMpfsYkovyVIPnedzhFQORwTbHjNE,qKMpfsYkovyVIPnedzhFQORwTbHjlJ,page_int=1):
  qKMpfsYkovyVIPnedzhFQORwTbHjEa=[]
  qKMpfsYkovyVIPnedzhFQORwTbHjlD=qKMpfsYkovyVIPnedzhFQORwTbHjlC=1
  qKMpfsYkovyVIPnedzhFQORwTbHjlU=qKMpfsYkovyVIPnedzhFQORwTbHjaB
  (qKMpfsYkovyVIPnedzhFQORwTbHjNU,qKMpfsYkovyVIPnedzhFQORwTbHjNG)=qKMpfsYkovyVIPnedzhFQORwTbHjNE.Baseapi_Parse(qKMpfsYkovyVIPnedzhFQORwTbHjlJ)
  if qKMpfsYkovyVIPnedzhFQORwTbHjNU=='':return qKMpfsYkovyVIPnedzhFQORwTbHjEa,qKMpfsYkovyVIPnedzhFQORwTbHjlU
  try:
   qKMpfsYkovyVIPnedzhFQORwTbHjNG['limit']=qKMpfsYkovyVIPnedzhFQORwTbHjNE.MV_LIMIT
   qKMpfsYkovyVIPnedzhFQORwTbHjNG['offset']=qKMpfsYkovyVIPnedzhFQORwTbHjJl((page_int-1)*qKMpfsYkovyVIPnedzhFQORwTbHjNE.MV_LIMIT)
   qKMpfsYkovyVIPnedzhFQORwTbHjNG.update(qKMpfsYkovyVIPnedzhFQORwTbHjNE.GetDefaultParams(login=qKMpfsYkovyVIPnedzhFQORwTbHjaB))
   qKMpfsYkovyVIPnedzhFQORwTbHjNi=qKMpfsYkovyVIPnedzhFQORwTbHjNE.callRequestCookies('Get',qKMpfsYkovyVIPnedzhFQORwTbHjNU,payload=qKMpfsYkovyVIPnedzhFQORwTbHjaA,params=qKMpfsYkovyVIPnedzhFQORwTbHjNG,headers=qKMpfsYkovyVIPnedzhFQORwTbHjaA,cookies=qKMpfsYkovyVIPnedzhFQORwTbHjaA)
   qKMpfsYkovyVIPnedzhFQORwTbHjNA=json.loads(qKMpfsYkovyVIPnedzhFQORwTbHjNi.text)
   if not('celllist' in qKMpfsYkovyVIPnedzhFQORwTbHjNA['cell_toplist']):return qKMpfsYkovyVIPnedzhFQORwTbHjEa,qKMpfsYkovyVIPnedzhFQORwTbHjlU
   qKMpfsYkovyVIPnedzhFQORwTbHjlW=qKMpfsYkovyVIPnedzhFQORwTbHjNA['cell_toplist']['celllist']
   for qKMpfsYkovyVIPnedzhFQORwTbHjlc in qKMpfsYkovyVIPnedzhFQORwTbHjlW:
    qKMpfsYkovyVIPnedzhFQORwTbHjlu =qKMpfsYkovyVIPnedzhFQORwTbHjlc['event_list'][1]['url']
    qKMpfsYkovyVIPnedzhFQORwTbHjli=urllib.parse.urlsplit(qKMpfsYkovyVIPnedzhFQORwTbHjlu).query
    qKMpfsYkovyVIPnedzhFQORwTbHjlA=qKMpfsYkovyVIPnedzhFQORwTbHjli[0:qKMpfsYkovyVIPnedzhFQORwTbHjli.find('=')]
    qKMpfsYkovyVIPnedzhFQORwTbHjlB=qKMpfsYkovyVIPnedzhFQORwTbHjli[qKMpfsYkovyVIPnedzhFQORwTbHjli.find('=')+1:]
    qKMpfsYkovyVIPnedzhFQORwTbHjlt={'title':qKMpfsYkovyVIPnedzhFQORwTbHjlc['title_list'][0]['text'],'age':qKMpfsYkovyVIPnedzhFQORwTbHjlc['age'],'thumbnail':'https://%s'%qKMpfsYkovyVIPnedzhFQORwTbHjlc.get('thumbnail'),'videoid':qKMpfsYkovyVIPnedzhFQORwTbHjlB,'vidtype':qKMpfsYkovyVIPnedzhFQORwTbHjlA}
    qKMpfsYkovyVIPnedzhFQORwTbHjEa.append(qKMpfsYkovyVIPnedzhFQORwTbHjlt)
   qKMpfsYkovyVIPnedzhFQORwTbHjlD=qKMpfsYkovyVIPnedzhFQORwTbHjJG(qKMpfsYkovyVIPnedzhFQORwTbHjNA['cell_toplist']['pagecount'])
   if qKMpfsYkovyVIPnedzhFQORwTbHjNA['cell_toplist']['count']:qKMpfsYkovyVIPnedzhFQORwTbHjlC =qKMpfsYkovyVIPnedzhFQORwTbHjJG(qKMpfsYkovyVIPnedzhFQORwTbHjNA['cell_toplist']['count'])
   else:qKMpfsYkovyVIPnedzhFQORwTbHjlC=qKMpfsYkovyVIPnedzhFQORwTbHjNE.MV_LIMIT*page_int
   qKMpfsYkovyVIPnedzhFQORwTbHjlU=qKMpfsYkovyVIPnedzhFQORwTbHjlD>qKMpfsYkovyVIPnedzhFQORwTbHjlC
  except qKMpfsYkovyVIPnedzhFQORwTbHjJE as exception:
   qKMpfsYkovyVIPnedzhFQORwTbHjJL(exception)
   return[],qKMpfsYkovyVIPnedzhFQORwTbHjaB
  return qKMpfsYkovyVIPnedzhFQORwTbHjEa,qKMpfsYkovyVIPnedzhFQORwTbHjlU
 def ProgramidToContentid(qKMpfsYkovyVIPnedzhFQORwTbHjNE,qKMpfsYkovyVIPnedzhFQORwTbHjEW):
  qKMpfsYkovyVIPnedzhFQORwTbHjEJ=''
  try:
   qKMpfsYkovyVIPnedzhFQORwTbHjNU =qKMpfsYkovyVIPnedzhFQORwTbHjNE.API_DOMAIN+'/vod/programs-contentid/'+qKMpfsYkovyVIPnedzhFQORwTbHjEW
   qKMpfsYkovyVIPnedzhFQORwTbHjNG=qKMpfsYkovyVIPnedzhFQORwTbHjNE.GetDefaultParams(login=qKMpfsYkovyVIPnedzhFQORwTbHjaB)
   qKMpfsYkovyVIPnedzhFQORwTbHjNi=qKMpfsYkovyVIPnedzhFQORwTbHjNE.callRequestCookies('Get',qKMpfsYkovyVIPnedzhFQORwTbHjNU,payload=qKMpfsYkovyVIPnedzhFQORwTbHjaA,params=qKMpfsYkovyVIPnedzhFQORwTbHjNG,headers=qKMpfsYkovyVIPnedzhFQORwTbHjaA,cookies=qKMpfsYkovyVIPnedzhFQORwTbHjaA)
   qKMpfsYkovyVIPnedzhFQORwTbHjEG=json.loads(qKMpfsYkovyVIPnedzhFQORwTbHjNi.text)
   if not('contentid' in qKMpfsYkovyVIPnedzhFQORwTbHjEG):return qKMpfsYkovyVIPnedzhFQORwTbHjEJ 
   qKMpfsYkovyVIPnedzhFQORwTbHjEJ=qKMpfsYkovyVIPnedzhFQORwTbHjEG['contentid']
  except qKMpfsYkovyVIPnedzhFQORwTbHjJE as exception:
   qKMpfsYkovyVIPnedzhFQORwTbHjJL(exception)
  return qKMpfsYkovyVIPnedzhFQORwTbHjEJ
 def ContentidToProgramid(qKMpfsYkovyVIPnedzhFQORwTbHjNE,qKMpfsYkovyVIPnedzhFQORwTbHjEJ):
  qKMpfsYkovyVIPnedzhFQORwTbHjEW=''
  try:
   qKMpfsYkovyVIPnedzhFQORwTbHjNU =qKMpfsYkovyVIPnedzhFQORwTbHjNE.API_DOMAIN+'/cf/vod/contents/'+qKMpfsYkovyVIPnedzhFQORwTbHjEJ
   qKMpfsYkovyVIPnedzhFQORwTbHjNG=qKMpfsYkovyVIPnedzhFQORwTbHjNE.GetDefaultParams(login=qKMpfsYkovyVIPnedzhFQORwTbHjaB)
   qKMpfsYkovyVIPnedzhFQORwTbHjNi=qKMpfsYkovyVIPnedzhFQORwTbHjNE.callRequestCookies('Get',qKMpfsYkovyVIPnedzhFQORwTbHjNU,payload=qKMpfsYkovyVIPnedzhFQORwTbHjaA,params=qKMpfsYkovyVIPnedzhFQORwTbHjNG,headers=qKMpfsYkovyVIPnedzhFQORwTbHjaA,cookies=qKMpfsYkovyVIPnedzhFQORwTbHjaA)
   qKMpfsYkovyVIPnedzhFQORwTbHjEG=json.loads(qKMpfsYkovyVIPnedzhFQORwTbHjNi.text)
   if not('programid' in qKMpfsYkovyVIPnedzhFQORwTbHjEG):return qKMpfsYkovyVIPnedzhFQORwTbHjEW 
   qKMpfsYkovyVIPnedzhFQORwTbHjEW=qKMpfsYkovyVIPnedzhFQORwTbHjEG['programid']
  except qKMpfsYkovyVIPnedzhFQORwTbHjJE as exception:
   qKMpfsYkovyVIPnedzhFQORwTbHjJL(exception)
  return qKMpfsYkovyVIPnedzhFQORwTbHjEW
 def GetProgramInfo(qKMpfsYkovyVIPnedzhFQORwTbHjNE,program_code):
  qKMpfsYkovyVIPnedzhFQORwTbHjEc={}
  try:
   qKMpfsYkovyVIPnedzhFQORwTbHjNU=qKMpfsYkovyVIPnedzhFQORwTbHjNE.API_DOMAIN+'/cf/vod/contents/'+program_code
   qKMpfsYkovyVIPnedzhFQORwTbHjNG=qKMpfsYkovyVIPnedzhFQORwTbHjNE.GetDefaultParams(login=qKMpfsYkovyVIPnedzhFQORwTbHjaB)
   qKMpfsYkovyVIPnedzhFQORwTbHjNi=qKMpfsYkovyVIPnedzhFQORwTbHjNE.callRequestCookies('Get',qKMpfsYkovyVIPnedzhFQORwTbHjNU,payload=qKMpfsYkovyVIPnedzhFQORwTbHjaA,params=qKMpfsYkovyVIPnedzhFQORwTbHjNG,headers=qKMpfsYkovyVIPnedzhFQORwTbHjaA,cookies=qKMpfsYkovyVIPnedzhFQORwTbHjaA)
   qKMpfsYkovyVIPnedzhFQORwTbHjEG=json.loads(qKMpfsYkovyVIPnedzhFQORwTbHjNi.text)
   qKMpfsYkovyVIPnedzhFQORwTbHjJL(qKMpfsYkovyVIPnedzhFQORwTbHjEG)
   qKMpfsYkovyVIPnedzhFQORwTbHjEt=img_fanart=qKMpfsYkovyVIPnedzhFQORwTbHjEm=''
   if qKMpfsYkovyVIPnedzhFQORwTbHjEG.get('programposterimage')!='':qKMpfsYkovyVIPnedzhFQORwTbHjEt =qKMpfsYkovyVIPnedzhFQORwTbHjNE.HTTPTAG+qKMpfsYkovyVIPnedzhFQORwTbHjEG.get('programposterimage')
   if qKMpfsYkovyVIPnedzhFQORwTbHjEG.get('programimage') !='':img_fanart =qKMpfsYkovyVIPnedzhFQORwTbHjNE.HTTPTAG+qKMpfsYkovyVIPnedzhFQORwTbHjEG.get('programimage')
   if qKMpfsYkovyVIPnedzhFQORwTbHjEG.get('programcirlceimage')!='':qKMpfsYkovyVIPnedzhFQORwTbHjEm=qKMpfsYkovyVIPnedzhFQORwTbHjNE.HTTPTAG+qKMpfsYkovyVIPnedzhFQORwTbHjEG.get('programcirlceimage')
   if 'poster_default' in qKMpfsYkovyVIPnedzhFQORwTbHjEt:
    qKMpfsYkovyVIPnedzhFQORwTbHjEt =img_fanart
    qKMpfsYkovyVIPnedzhFQORwTbHjEm=''
   qKMpfsYkovyVIPnedzhFQORwTbHjEc={'imgPoster':qKMpfsYkovyVIPnedzhFQORwTbHjEt,'imgFanart':img_fanart,'imgClearlogo':qKMpfsYkovyVIPnedzhFQORwTbHjEm}
  except qKMpfsYkovyVIPnedzhFQORwTbHjJE as exception:
   qKMpfsYkovyVIPnedzhFQORwTbHjJL(exception)
  return qKMpfsYkovyVIPnedzhFQORwTbHjEc
 def Get_Episode_List(qKMpfsYkovyVIPnedzhFQORwTbHjNE,qKMpfsYkovyVIPnedzhFQORwTbHjlB,qKMpfsYkovyVIPnedzhFQORwTbHjlA,page_int=1,orderby='desc'):
  qKMpfsYkovyVIPnedzhFQORwTbHjEr=[]
  qKMpfsYkovyVIPnedzhFQORwTbHjlD=qKMpfsYkovyVIPnedzhFQORwTbHjlC=1
  qKMpfsYkovyVIPnedzhFQORwTbHjlU=qKMpfsYkovyVIPnedzhFQORwTbHjaB
  qKMpfsYkovyVIPnedzhFQORwTbHjES={}
  if qKMpfsYkovyVIPnedzhFQORwTbHjlA=='contentid':
   qKMpfsYkovyVIPnedzhFQORwTbHjEW=qKMpfsYkovyVIPnedzhFQORwTbHjNE.ContentidToProgramid(qKMpfsYkovyVIPnedzhFQORwTbHjlB)
   qKMpfsYkovyVIPnedzhFQORwTbHjES=qKMpfsYkovyVIPnedzhFQORwTbHjNE.GetProgramInfo(qKMpfsYkovyVIPnedzhFQORwTbHjlB)
  else:
   qKMpfsYkovyVIPnedzhFQORwTbHjEW=qKMpfsYkovyVIPnedzhFQORwTbHjlB
   qKMpfsYkovyVIPnedzhFQORwTbHjEJ=qKMpfsYkovyVIPnedzhFQORwTbHjNE.ProgramidToContentid(qKMpfsYkovyVIPnedzhFQORwTbHjlB)
   if qKMpfsYkovyVIPnedzhFQORwTbHjEJ!='':qKMpfsYkovyVIPnedzhFQORwTbHjES=qKMpfsYkovyVIPnedzhFQORwTbHjNE.GetProgramInfo(qKMpfsYkovyVIPnedzhFQORwTbHjEJ)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   qKMpfsYkovyVIPnedzhFQORwTbHjNU=qKMpfsYkovyVIPnedzhFQORwTbHjNE.API_DOMAIN+'/vod/programs-contents/'+qKMpfsYkovyVIPnedzhFQORwTbHjEW
   qKMpfsYkovyVIPnedzhFQORwTbHjNG={}
   qKMpfsYkovyVIPnedzhFQORwTbHjNG['limit'] =qKMpfsYkovyVIPnedzhFQORwTbHjNE.EP_LIMIT
   qKMpfsYkovyVIPnedzhFQORwTbHjNG['offset']=qKMpfsYkovyVIPnedzhFQORwTbHjJl((page_int-1)*qKMpfsYkovyVIPnedzhFQORwTbHjNE.EP_LIMIT)
   qKMpfsYkovyVIPnedzhFQORwTbHjNG['orderby']=orderby 
   qKMpfsYkovyVIPnedzhFQORwTbHjNG.update(qKMpfsYkovyVIPnedzhFQORwTbHjNE.GetDefaultParams(login=qKMpfsYkovyVIPnedzhFQORwTbHjaB))
   qKMpfsYkovyVIPnedzhFQORwTbHjNi=qKMpfsYkovyVIPnedzhFQORwTbHjNE.callRequestCookies('Get',qKMpfsYkovyVIPnedzhFQORwTbHjNU,payload=qKMpfsYkovyVIPnedzhFQORwTbHjaA,params=qKMpfsYkovyVIPnedzhFQORwTbHjNG,headers=qKMpfsYkovyVIPnedzhFQORwTbHjaA,cookies=qKMpfsYkovyVIPnedzhFQORwTbHjaA)
   qKMpfsYkovyVIPnedzhFQORwTbHjNA=json.loads(qKMpfsYkovyVIPnedzhFQORwTbHjNi.text)
   qKMpfsYkovyVIPnedzhFQORwTbHjlW=qKMpfsYkovyVIPnedzhFQORwTbHjNA['list']
   for qKMpfsYkovyVIPnedzhFQORwTbHjlc in qKMpfsYkovyVIPnedzhFQORwTbHjlW:
    qKMpfsYkovyVIPnedzhFQORwTbHjEg=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',qKMpfsYkovyVIPnedzhFQORwTbHjlc.get('synopsis'))
    qKMpfsYkovyVIPnedzhFQORwTbHjEx=qKMpfsYkovyVIPnedzhFQORwTbHjNE.HTTPTAG+qKMpfsYkovyVIPnedzhFQORwTbHjlc.get('image')
    qKMpfsYkovyVIPnedzhFQORwTbHjED=qKMpfsYkovyVIPnedzhFQORwTbHjEU=qKMpfsYkovyVIPnedzhFQORwTbHjEu=''
    if qKMpfsYkovyVIPnedzhFQORwTbHjES!={}:
     qKMpfsYkovyVIPnedzhFQORwTbHjED =qKMpfsYkovyVIPnedzhFQORwTbHjES.get('imgPoster')
     qKMpfsYkovyVIPnedzhFQORwTbHjEU =qKMpfsYkovyVIPnedzhFQORwTbHjES.get('imgFanart')
     qKMpfsYkovyVIPnedzhFQORwTbHjEu=qKMpfsYkovyVIPnedzhFQORwTbHjES.get('imgClearlogo')
     qKMpfsYkovyVIPnedzhFQORwTbHjEi={'thumb':qKMpfsYkovyVIPnedzhFQORwTbHjEx,'poster':qKMpfsYkovyVIPnedzhFQORwTbHjED,'fanart':qKMpfsYkovyVIPnedzhFQORwTbHjEU,'clearlogo':qKMpfsYkovyVIPnedzhFQORwTbHjEu}
    else:
     qKMpfsYkovyVIPnedzhFQORwTbHjEi=qKMpfsYkovyVIPnedzhFQORwTbHjEx
    qKMpfsYkovyVIPnedzhFQORwTbHjlt={'programtitle':qKMpfsYkovyVIPnedzhFQORwTbHjlc.get('programtitle'),'episodetitle':qKMpfsYkovyVIPnedzhFQORwTbHjlc.get('episodetitle'),'episodenumber':qKMpfsYkovyVIPnedzhFQORwTbHjlc.get('episodenumber'),'releasedate':qKMpfsYkovyVIPnedzhFQORwTbHjlc.get('releasedate'),'releaseweekday':qKMpfsYkovyVIPnedzhFQORwTbHjlc.get('releaseweekday'),'programid':qKMpfsYkovyVIPnedzhFQORwTbHjlc.get('programid'),'contentid':qKMpfsYkovyVIPnedzhFQORwTbHjlc.get('contentid'),'age':qKMpfsYkovyVIPnedzhFQORwTbHjlc.get('targetage'),'playtime':qKMpfsYkovyVIPnedzhFQORwTbHjlc.get('playtime'),'synopsis':qKMpfsYkovyVIPnedzhFQORwTbHjEg,'episodeactors':qKMpfsYkovyVIPnedzhFQORwTbHjlc.get('episodeactors').split(',')if qKMpfsYkovyVIPnedzhFQORwTbHjlc.get('episodeactors')!='' else[],'thumbnail':qKMpfsYkovyVIPnedzhFQORwTbHjEi}
    qKMpfsYkovyVIPnedzhFQORwTbHjEr.append(qKMpfsYkovyVIPnedzhFQORwTbHjlt)
   qKMpfsYkovyVIPnedzhFQORwTbHjlD=qKMpfsYkovyVIPnedzhFQORwTbHjJG(qKMpfsYkovyVIPnedzhFQORwTbHjNA['pagecount'])
   if qKMpfsYkovyVIPnedzhFQORwTbHjNA['count']:qKMpfsYkovyVIPnedzhFQORwTbHjlC =qKMpfsYkovyVIPnedzhFQORwTbHjJG(qKMpfsYkovyVIPnedzhFQORwTbHjNA['count'])
   else:qKMpfsYkovyVIPnedzhFQORwTbHjlC=qKMpfsYkovyVIPnedzhFQORwTbHjNE.EP_LIMIT*page_int
   qKMpfsYkovyVIPnedzhFQORwTbHjlU=qKMpfsYkovyVIPnedzhFQORwTbHjlD>qKMpfsYkovyVIPnedzhFQORwTbHjlC
  except qKMpfsYkovyVIPnedzhFQORwTbHjJE as exception:
   qKMpfsYkovyVIPnedzhFQORwTbHjJL(exception)
   return[],qKMpfsYkovyVIPnedzhFQORwTbHjaB
  return qKMpfsYkovyVIPnedzhFQORwTbHjEr,qKMpfsYkovyVIPnedzhFQORwTbHjlU
 def GetEPGList(qKMpfsYkovyVIPnedzhFQORwTbHjNE,genre):
  qKMpfsYkovyVIPnedzhFQORwTbHjEA={}
  try:
   qKMpfsYkovyVIPnedzhFQORwTbHjEB=qKMpfsYkovyVIPnedzhFQORwTbHjNE.Get_Now_Datetime()
   if genre=='all':
    qKMpfsYkovyVIPnedzhFQORwTbHjEC =qKMpfsYkovyVIPnedzhFQORwTbHjEB+datetime.timedelta(hours=3)
   else:
    qKMpfsYkovyVIPnedzhFQORwTbHjEC =qKMpfsYkovyVIPnedzhFQORwTbHjEB+datetime.timedelta(hours=3)
   qKMpfsYkovyVIPnedzhFQORwTbHjNU=qKMpfsYkovyVIPnedzhFQORwTbHjNE.API_DOMAIN+'/live/epgs'
   qKMpfsYkovyVIPnedzhFQORwTbHjNG={'limit':'100','offset':'0','genre':genre,'startdatetime':qKMpfsYkovyVIPnedzhFQORwTbHjEB.strftime('%Y-%m-%d %H:00'),'enddatetime':qKMpfsYkovyVIPnedzhFQORwTbHjEC.strftime('%Y-%m-%d %H:00')}
   qKMpfsYkovyVIPnedzhFQORwTbHjNG.update(qKMpfsYkovyVIPnedzhFQORwTbHjNE.GetDefaultParams(login=qKMpfsYkovyVIPnedzhFQORwTbHjaB))
   qKMpfsYkovyVIPnedzhFQORwTbHjNi=qKMpfsYkovyVIPnedzhFQORwTbHjNE.callRequestCookies('Get',qKMpfsYkovyVIPnedzhFQORwTbHjNU,payload=qKMpfsYkovyVIPnedzhFQORwTbHjaA,params=qKMpfsYkovyVIPnedzhFQORwTbHjNG,headers=qKMpfsYkovyVIPnedzhFQORwTbHjaA,cookies=qKMpfsYkovyVIPnedzhFQORwTbHjaA)
   qKMpfsYkovyVIPnedzhFQORwTbHjNA=json.loads(qKMpfsYkovyVIPnedzhFQORwTbHjNi.text)
   qKMpfsYkovyVIPnedzhFQORwTbHjLN=qKMpfsYkovyVIPnedzhFQORwTbHjNA['list']
   for qKMpfsYkovyVIPnedzhFQORwTbHjlc in qKMpfsYkovyVIPnedzhFQORwTbHjLN:
    qKMpfsYkovyVIPnedzhFQORwTbHjLl=''
    for qKMpfsYkovyVIPnedzhFQORwTbHjLE in qKMpfsYkovyVIPnedzhFQORwTbHjlc['list']:
     if qKMpfsYkovyVIPnedzhFQORwTbHjLl:qKMpfsYkovyVIPnedzhFQORwTbHjLl+='\n'
     qKMpfsYkovyVIPnedzhFQORwTbHjLl+=qKMpfsYkovyVIPnedzhFQORwTbHjNE.Get_ChangeText(qKMpfsYkovyVIPnedzhFQORwTbHjLE['title'])+'\n'
     qKMpfsYkovyVIPnedzhFQORwTbHjLl+=' [%s ~ %s]'%(qKMpfsYkovyVIPnedzhFQORwTbHjLE['starttime'][-5:],qKMpfsYkovyVIPnedzhFQORwTbHjLE['endtime'][-5:])+'\n'
    qKMpfsYkovyVIPnedzhFQORwTbHjEA[qKMpfsYkovyVIPnedzhFQORwTbHjlc['channelid']]=qKMpfsYkovyVIPnedzhFQORwTbHjLl
  except qKMpfsYkovyVIPnedzhFQORwTbHjJE as exception:
   qKMpfsYkovyVIPnedzhFQORwTbHjJL(exception)
  return qKMpfsYkovyVIPnedzhFQORwTbHjEA
 def Get_LiveChannel_List(qKMpfsYkovyVIPnedzhFQORwTbHjNE,genre,qKMpfsYkovyVIPnedzhFQORwTbHjlJ):
  qKMpfsYkovyVIPnedzhFQORwTbHjlx=[]
  (qKMpfsYkovyVIPnedzhFQORwTbHjNU,qKMpfsYkovyVIPnedzhFQORwTbHjNG)=qKMpfsYkovyVIPnedzhFQORwTbHjNE.Baseapi_Parse(qKMpfsYkovyVIPnedzhFQORwTbHjlJ)
  if qKMpfsYkovyVIPnedzhFQORwTbHjNU=='':return qKMpfsYkovyVIPnedzhFQORwTbHjlx
  qKMpfsYkovyVIPnedzhFQORwTbHjLa=qKMpfsYkovyVIPnedzhFQORwTbHjNE.GetEPGList(genre)
  try:
   qKMpfsYkovyVIPnedzhFQORwTbHjNG.update(qKMpfsYkovyVIPnedzhFQORwTbHjNE.GetDefaultParams(login=qKMpfsYkovyVIPnedzhFQORwTbHjaB))
   qKMpfsYkovyVIPnedzhFQORwTbHjNG['genre']=genre
   qKMpfsYkovyVIPnedzhFQORwTbHjNi=qKMpfsYkovyVIPnedzhFQORwTbHjNE.callRequestCookies('Get',qKMpfsYkovyVIPnedzhFQORwTbHjNU,payload=qKMpfsYkovyVIPnedzhFQORwTbHjaA,params=qKMpfsYkovyVIPnedzhFQORwTbHjNG,headers=qKMpfsYkovyVIPnedzhFQORwTbHjaA,cookies=qKMpfsYkovyVIPnedzhFQORwTbHjaA)
   qKMpfsYkovyVIPnedzhFQORwTbHjNA=json.loads(qKMpfsYkovyVIPnedzhFQORwTbHjNi.text)
   if not('celllist' in qKMpfsYkovyVIPnedzhFQORwTbHjNA['cell_toplist']):return[]
   qKMpfsYkovyVIPnedzhFQORwTbHjlW=qKMpfsYkovyVIPnedzhFQORwTbHjNA['cell_toplist']['celllist']
   for qKMpfsYkovyVIPnedzhFQORwTbHjlc in qKMpfsYkovyVIPnedzhFQORwTbHjlW:
    qKMpfsYkovyVIPnedzhFQORwTbHjEJ=qKMpfsYkovyVIPnedzhFQORwTbHjlc['contentid']
    if qKMpfsYkovyVIPnedzhFQORwTbHjEJ in qKMpfsYkovyVIPnedzhFQORwTbHjLa:
     qKMpfsYkovyVIPnedzhFQORwTbHjLJ=qKMpfsYkovyVIPnedzhFQORwTbHjLa[qKMpfsYkovyVIPnedzhFQORwTbHjEJ]
    else:
     qKMpfsYkovyVIPnedzhFQORwTbHjLJ=''
    qKMpfsYkovyVIPnedzhFQORwTbHjlt={'studio':qKMpfsYkovyVIPnedzhFQORwTbHjlc['title_list'][0]['text'],'tvshowtitle':qKMpfsYkovyVIPnedzhFQORwTbHjNE.Get_ChangeText(qKMpfsYkovyVIPnedzhFQORwTbHjlc['title_list'][1]['text']),'channelid':qKMpfsYkovyVIPnedzhFQORwTbHjEJ,'age':qKMpfsYkovyVIPnedzhFQORwTbHjlc['age'],'thumbnail':'https://%s'%qKMpfsYkovyVIPnedzhFQORwTbHjlc.get('thumbnail'),'epg':qKMpfsYkovyVIPnedzhFQORwTbHjLJ}
    qKMpfsYkovyVIPnedzhFQORwTbHjlx.append(qKMpfsYkovyVIPnedzhFQORwTbHjlt)
  except qKMpfsYkovyVIPnedzhFQORwTbHjJE as exception:
   qKMpfsYkovyVIPnedzhFQORwTbHjJL(exception)
   return[]
  return qKMpfsYkovyVIPnedzhFQORwTbHjlx
 def Get_Search_List(qKMpfsYkovyVIPnedzhFQORwTbHjNE,search_key,sType,page_int,exclusion21=qKMpfsYkovyVIPnedzhFQORwTbHjaB):
  qKMpfsYkovyVIPnedzhFQORwTbHjLG=[]
  qKMpfsYkovyVIPnedzhFQORwTbHjlD=qKMpfsYkovyVIPnedzhFQORwTbHjlC=1
  qKMpfsYkovyVIPnedzhFQORwTbHjlU=qKMpfsYkovyVIPnedzhFQORwTbHjaB
  try:
   qKMpfsYkovyVIPnedzhFQORwTbHjNU=qKMpfsYkovyVIPnedzhFQORwTbHjNE.API_DOMAIN+'/cf/search/list.js'
   qKMpfsYkovyVIPnedzhFQORwTbHjNG={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':qKMpfsYkovyVIPnedzhFQORwTbHjJl((page_int-1)*qKMpfsYkovyVIPnedzhFQORwTbHjNE.SEARCH_LIMIT),'limit':qKMpfsYkovyVIPnedzhFQORwTbHjNE.SEARCH_LIMIT,'orderby':'score'}
   qKMpfsYkovyVIPnedzhFQORwTbHjNG.update(qKMpfsYkovyVIPnedzhFQORwTbHjNE.GetDefaultParams(login=qKMpfsYkovyVIPnedzhFQORwTbHjaB))
   qKMpfsYkovyVIPnedzhFQORwTbHjNi=qKMpfsYkovyVIPnedzhFQORwTbHjNE.callRequestCookies('Get',qKMpfsYkovyVIPnedzhFQORwTbHjNU,payload=qKMpfsYkovyVIPnedzhFQORwTbHjaA,params=qKMpfsYkovyVIPnedzhFQORwTbHjNG,headers=qKMpfsYkovyVIPnedzhFQORwTbHjaA,cookies=qKMpfsYkovyVIPnedzhFQORwTbHjaA)
   qKMpfsYkovyVIPnedzhFQORwTbHjEG=json.loads(qKMpfsYkovyVIPnedzhFQORwTbHjNi.text)
   if not('celllist' in qKMpfsYkovyVIPnedzhFQORwTbHjEG['cell_toplist']):return qKMpfsYkovyVIPnedzhFQORwTbHjLG,qKMpfsYkovyVIPnedzhFQORwTbHjlU
   qKMpfsYkovyVIPnedzhFQORwTbHjlW=qKMpfsYkovyVIPnedzhFQORwTbHjEG['cell_toplist']['celllist']
   for qKMpfsYkovyVIPnedzhFQORwTbHjlc in qKMpfsYkovyVIPnedzhFQORwTbHjlW:
    qKMpfsYkovyVIPnedzhFQORwTbHjlu =qKMpfsYkovyVIPnedzhFQORwTbHjlc['event_list'][1]['url']
    qKMpfsYkovyVIPnedzhFQORwTbHjli=urllib.parse.urlsplit(qKMpfsYkovyVIPnedzhFQORwTbHjlu).query
    qKMpfsYkovyVIPnedzhFQORwTbHjlA=qKMpfsYkovyVIPnedzhFQORwTbHjli[0:qKMpfsYkovyVIPnedzhFQORwTbHjli.find('=')]
    qKMpfsYkovyVIPnedzhFQORwTbHjlB=qKMpfsYkovyVIPnedzhFQORwTbHjli[qKMpfsYkovyVIPnedzhFQORwTbHjli.find('=')+1:]
    qKMpfsYkovyVIPnedzhFQORwTbHjlt={'title':qKMpfsYkovyVIPnedzhFQORwTbHjlc['title_list'][0]['text'],'age':qKMpfsYkovyVIPnedzhFQORwTbHjlc['age'],'thumbnail':'https://%s'%qKMpfsYkovyVIPnedzhFQORwTbHjlc.get('thumbnail'),'videoid':qKMpfsYkovyVIPnedzhFQORwTbHjlB,'vidtype':qKMpfsYkovyVIPnedzhFQORwTbHjlA}
    if exclusion21==qKMpfsYkovyVIPnedzhFQORwTbHjaB or qKMpfsYkovyVIPnedzhFQORwTbHjlc.get('age')!='21':
     qKMpfsYkovyVIPnedzhFQORwTbHjLG.append(qKMpfsYkovyVIPnedzhFQORwTbHjlt)
   qKMpfsYkovyVIPnedzhFQORwTbHjlD=qKMpfsYkovyVIPnedzhFQORwTbHjJG(qKMpfsYkovyVIPnedzhFQORwTbHjEG['cell_toplist']['pagecount'])
   if qKMpfsYkovyVIPnedzhFQORwTbHjEG['cell_toplist']['count']:qKMpfsYkovyVIPnedzhFQORwTbHjlC =qKMpfsYkovyVIPnedzhFQORwTbHjJG(qKMpfsYkovyVIPnedzhFQORwTbHjEG['cell_toplist']['count'])
   else:qKMpfsYkovyVIPnedzhFQORwTbHjlC=qKMpfsYkovyVIPnedzhFQORwTbHjNE.LIST_LIMIT
   qKMpfsYkovyVIPnedzhFQORwTbHjlU=qKMpfsYkovyVIPnedzhFQORwTbHjlD>qKMpfsYkovyVIPnedzhFQORwTbHjlC
  except qKMpfsYkovyVIPnedzhFQORwTbHjJE as exception:
   qKMpfsYkovyVIPnedzhFQORwTbHjJL(exception)
  return qKMpfsYkovyVIPnedzhFQORwTbHjLG,qKMpfsYkovyVIPnedzhFQORwTbHjlU 
 def GetStreamingURL(qKMpfsYkovyVIPnedzhFQORwTbHjNE,mode,qKMpfsYkovyVIPnedzhFQORwTbHjEJ,quality_int,pvrmode='-'):
  qKMpfsYkovyVIPnedzhFQORwTbHjLW=qKMpfsYkovyVIPnedzhFQORwTbHjLx=qKMpfsYkovyVIPnedzhFQORwTbHjLD=streaming_preview=''
  qKMpfsYkovyVIPnedzhFQORwTbHjLc=[]
  qKMpfsYkovyVIPnedzhFQORwTbHjLt='hls'
  if mode=='LIVE':
   qKMpfsYkovyVIPnedzhFQORwTbHjNU =qKMpfsYkovyVIPnedzhFQORwTbHjNE.API_DOMAIN+'/live/channels/'+qKMpfsYkovyVIPnedzhFQORwTbHjEJ
   qKMpfsYkovyVIPnedzhFQORwTbHjLm='live'
  elif mode=='VOD':
   qKMpfsYkovyVIPnedzhFQORwTbHjNU =qKMpfsYkovyVIPnedzhFQORwTbHjNE.API_DOMAIN+'/cf/vod/contents/'+qKMpfsYkovyVIPnedzhFQORwTbHjEJ
   qKMpfsYkovyVIPnedzhFQORwTbHjLm='vod'
  elif mode=='MOVIE':
   qKMpfsYkovyVIPnedzhFQORwTbHjNU =qKMpfsYkovyVIPnedzhFQORwTbHjNE.API_DOMAIN+'/cf/movie/contents/'+qKMpfsYkovyVIPnedzhFQORwTbHjEJ
   qKMpfsYkovyVIPnedzhFQORwTbHjLm='movie'
  try:
   if mode!='LIVE' or pvrmode=='-':
    qKMpfsYkovyVIPnedzhFQORwTbHjNG=qKMpfsYkovyVIPnedzhFQORwTbHjNE.GetDefaultParams(login=qKMpfsYkovyVIPnedzhFQORwTbHjaB)
    qKMpfsYkovyVIPnedzhFQORwTbHjNi=qKMpfsYkovyVIPnedzhFQORwTbHjNE.callRequestCookies('Get',qKMpfsYkovyVIPnedzhFQORwTbHjNU,payload=qKMpfsYkovyVIPnedzhFQORwTbHjaA,params=qKMpfsYkovyVIPnedzhFQORwTbHjNG,headers=qKMpfsYkovyVIPnedzhFQORwTbHjaA,cookies=qKMpfsYkovyVIPnedzhFQORwTbHjaA)
    qKMpfsYkovyVIPnedzhFQORwTbHjNA=json.loads(qKMpfsYkovyVIPnedzhFQORwTbHjNi.text)
    qKMpfsYkovyVIPnedzhFQORwTbHjLr=qKMpfsYkovyVIPnedzhFQORwTbHjNA['qualities']['list']
    if qKMpfsYkovyVIPnedzhFQORwTbHjLr==qKMpfsYkovyVIPnedzhFQORwTbHjaA:return(qKMpfsYkovyVIPnedzhFQORwTbHjLW,qKMpfsYkovyVIPnedzhFQORwTbHjLx,qKMpfsYkovyVIPnedzhFQORwTbHjLD,streaming_preview)
    for qKMpfsYkovyVIPnedzhFQORwTbHjLS in qKMpfsYkovyVIPnedzhFQORwTbHjLr:
     qKMpfsYkovyVIPnedzhFQORwTbHjLc.append(qKMpfsYkovyVIPnedzhFQORwTbHjJG(qKMpfsYkovyVIPnedzhFQORwTbHjLS.get('id').rstrip('p')))
    if 'type' in qKMpfsYkovyVIPnedzhFQORwTbHjNA:
     if qKMpfsYkovyVIPnedzhFQORwTbHjNA['type']=='onair':
      qKMpfsYkovyVIPnedzhFQORwTbHjLm='onairvod'
    if 'drms' in qKMpfsYkovyVIPnedzhFQORwTbHjNA:
     if qKMpfsYkovyVIPnedzhFQORwTbHjNA['drms']:
      qKMpfsYkovyVIPnedzhFQORwTbHjLt='dash'
  except qKMpfsYkovyVIPnedzhFQORwTbHjJE as exception:
   qKMpfsYkovyVIPnedzhFQORwTbHjJL(exception)
   return(qKMpfsYkovyVIPnedzhFQORwTbHjLW,qKMpfsYkovyVIPnedzhFQORwTbHjLx,qKMpfsYkovyVIPnedzhFQORwTbHjLD,streaming_preview)
  try:
   qKMpfsYkovyVIPnedzhFQORwTbHjLX=qKMpfsYkovyVIPnedzhFQORwTbHjNE.CheckQuality(quality_int,qKMpfsYkovyVIPnedzhFQORwTbHjLc)
   if mode=='LIVE' and pvrmode!='-':
    qKMpfsYkovyVIPnedzhFQORwTbHjLg='auto'
   else:
    qKMpfsYkovyVIPnedzhFQORwTbHjLg=qKMpfsYkovyVIPnedzhFQORwTbHjJl(qKMpfsYkovyVIPnedzhFQORwTbHjLX)+'p'
   qKMpfsYkovyVIPnedzhFQORwTbHjNU=qKMpfsYkovyVIPnedzhFQORwTbHjNE.API_DOMAIN+'/streaming'
   qKMpfsYkovyVIPnedzhFQORwTbHjNG={'contentid':qKMpfsYkovyVIPnedzhFQORwTbHjEJ,'contenttype':qKMpfsYkovyVIPnedzhFQORwTbHjLm,'action':qKMpfsYkovyVIPnedzhFQORwTbHjLt,'quality':qKMpfsYkovyVIPnedzhFQORwTbHjLg,'deviceModelId':'Windows 10','guid':qKMpfsYkovyVIPnedzhFQORwTbHjNE.GetGUID(guidType=2),'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n'}
   qKMpfsYkovyVIPnedzhFQORwTbHjNG.update(qKMpfsYkovyVIPnedzhFQORwTbHjNE.GetDefaultParams(login=qKMpfsYkovyVIPnedzhFQORwTbHjaC))
   qKMpfsYkovyVIPnedzhFQORwTbHjNi=qKMpfsYkovyVIPnedzhFQORwTbHjNE.callRequestCookies('Get',qKMpfsYkovyVIPnedzhFQORwTbHjNU,payload=qKMpfsYkovyVIPnedzhFQORwTbHjaA,params=qKMpfsYkovyVIPnedzhFQORwTbHjNG,headers=qKMpfsYkovyVIPnedzhFQORwTbHjaA,cookies=qKMpfsYkovyVIPnedzhFQORwTbHjaA)
   qKMpfsYkovyVIPnedzhFQORwTbHjNA=json.loads(qKMpfsYkovyVIPnedzhFQORwTbHjNi.text)
   qKMpfsYkovyVIPnedzhFQORwTbHjLW=qKMpfsYkovyVIPnedzhFQORwTbHjNA['playurl']
   if qKMpfsYkovyVIPnedzhFQORwTbHjLW==qKMpfsYkovyVIPnedzhFQORwTbHjaA:return(qKMpfsYkovyVIPnedzhFQORwTbHjLW,qKMpfsYkovyVIPnedzhFQORwTbHjLx,qKMpfsYkovyVIPnedzhFQORwTbHjLD,streaming_preview)
   qKMpfsYkovyVIPnedzhFQORwTbHjLx=qKMpfsYkovyVIPnedzhFQORwTbHjNA['awscookie']
   qKMpfsYkovyVIPnedzhFQORwTbHjLD =qKMpfsYkovyVIPnedzhFQORwTbHjNA['drm']
   if 'previewmsg' in qKMpfsYkovyVIPnedzhFQORwTbHjNA['preview']:streaming_preview=qKMpfsYkovyVIPnedzhFQORwTbHjNA['preview']['previewmsg']
  except qKMpfsYkovyVIPnedzhFQORwTbHjJE as exception:
   qKMpfsYkovyVIPnedzhFQORwTbHjJL(exception)
  return(qKMpfsYkovyVIPnedzhFQORwTbHjLW,qKMpfsYkovyVIPnedzhFQORwTbHjLx,qKMpfsYkovyVIPnedzhFQORwTbHjLD,streaming_preview) 
 def GetSportsURL(qKMpfsYkovyVIPnedzhFQORwTbHjNE,qKMpfsYkovyVIPnedzhFQORwTbHjEJ,quality_int):
  qKMpfsYkovyVIPnedzhFQORwTbHjLW=qKMpfsYkovyVIPnedzhFQORwTbHjLx=''
  qKMpfsYkovyVIPnedzhFQORwTbHjLc=[]
  try:
   qKMpfsYkovyVIPnedzhFQORwTbHjNU=qKMpfsYkovyVIPnedzhFQORwTbHjNE.API_DOMAIN+'/streaming/other'
   qKMpfsYkovyVIPnedzhFQORwTbHjNG={'contentid':qKMpfsYkovyVIPnedzhFQORwTbHjEJ,'contenttype':'live','action':'hls','quality':qKMpfsYkovyVIPnedzhFQORwTbHjJl(quality_int)+'p','deviceModelId':'Windows 10','guid':qKMpfsYkovyVIPnedzhFQORwTbHjNE.GetGUID(guidType=2),'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n'}
   qKMpfsYkovyVIPnedzhFQORwTbHjNG.update(qKMpfsYkovyVIPnedzhFQORwTbHjNE.GetDefaultParams(login=qKMpfsYkovyVIPnedzhFQORwTbHjaC))
   qKMpfsYkovyVIPnedzhFQORwTbHjNi=qKMpfsYkovyVIPnedzhFQORwTbHjNE.callRequestCookies('Get',qKMpfsYkovyVIPnedzhFQORwTbHjNU,payload=qKMpfsYkovyVIPnedzhFQORwTbHjaA,params=qKMpfsYkovyVIPnedzhFQORwTbHjNG,headers=qKMpfsYkovyVIPnedzhFQORwTbHjaA,cookies=qKMpfsYkovyVIPnedzhFQORwTbHjaA)
   qKMpfsYkovyVIPnedzhFQORwTbHjNA=json.loads(qKMpfsYkovyVIPnedzhFQORwTbHjNi.text)
   qKMpfsYkovyVIPnedzhFQORwTbHjLW=qKMpfsYkovyVIPnedzhFQORwTbHjNA['playurl']
   if qKMpfsYkovyVIPnedzhFQORwTbHjLW==qKMpfsYkovyVIPnedzhFQORwTbHjaA:return(qKMpfsYkovyVIPnedzhFQORwTbHjLW,qKMpfsYkovyVIPnedzhFQORwTbHjLx)
   qKMpfsYkovyVIPnedzhFQORwTbHjLx=qKMpfsYkovyVIPnedzhFQORwTbHjNA['awscookie']
  except qKMpfsYkovyVIPnedzhFQORwTbHjJE as exception:
   qKMpfsYkovyVIPnedzhFQORwTbHjJL(exception)
  return(qKMpfsYkovyVIPnedzhFQORwTbHjLW,qKMpfsYkovyVIPnedzhFQORwTbHjLx) 
 def make_viewdate(qKMpfsYkovyVIPnedzhFQORwTbHjNE):
  qKMpfsYkovyVIPnedzhFQORwTbHjLU =qKMpfsYkovyVIPnedzhFQORwTbHjNE.Get_Now_Datetime()
  qKMpfsYkovyVIPnedzhFQORwTbHjLu =qKMpfsYkovyVIPnedzhFQORwTbHjLU+datetime.timedelta(days=-1)
  qKMpfsYkovyVIPnedzhFQORwTbHjLi =qKMpfsYkovyVIPnedzhFQORwTbHjLU+datetime.timedelta(days=1)
  qKMpfsYkovyVIPnedzhFQORwTbHjLA=[qKMpfsYkovyVIPnedzhFQORwTbHjLU.strftime('%Y%m%d'),qKMpfsYkovyVIPnedzhFQORwTbHjLi.strftime('%Y%m%d'),]
  return qKMpfsYkovyVIPnedzhFQORwTbHjLA
 def Get_Sports_Gamelist(qKMpfsYkovyVIPnedzhFQORwTbHjNE):
  qKMpfsYkovyVIPnedzhFQORwTbHjLB =qKMpfsYkovyVIPnedzhFQORwTbHjNE.make_viewdate()
  qKMpfsYkovyVIPnedzhFQORwTbHjLC=[]
  qKMpfsYkovyVIPnedzhFQORwTbHjaN =[]
  for qKMpfsYkovyVIPnedzhFQORwTbHjal in qKMpfsYkovyVIPnedzhFQORwTbHjLB:
   qKMpfsYkovyVIPnedzhFQORwTbHjaE=qKMpfsYkovyVIPnedzhFQORwTbHjal[:6]
   if qKMpfsYkovyVIPnedzhFQORwTbHjaE not in qKMpfsYkovyVIPnedzhFQORwTbHjLC:
    qKMpfsYkovyVIPnedzhFQORwTbHjLC.append(qKMpfsYkovyVIPnedzhFQORwTbHjaE)
  try:
   qKMpfsYkovyVIPnedzhFQORwTbHjNU='https://annexapi.wavve.com/skb/baseball/teammonthlycalendarlist'
   qKMpfsYkovyVIPnedzhFQORwTbHjNG={'IF':'IF-PORG-002','m':'getTeamCalendarListBand','response_format':'json','spo_itm_cd':'KBO','teamcd':'all','tgroup':'B','tvalue':'BC123','ver':'2.0',}
   qKMpfsYkovyVIPnedzhFQORwTbHjNG.update(qKMpfsYkovyVIPnedzhFQORwTbHjNE.GetDefaultParams(login=qKMpfsYkovyVIPnedzhFQORwTbHjaB))
   for qKMpfsYkovyVIPnedzhFQORwTbHjaL in qKMpfsYkovyVIPnedzhFQORwTbHjLC:
    qKMpfsYkovyVIPnedzhFQORwTbHjNG['date']=qKMpfsYkovyVIPnedzhFQORwTbHjaL
    qKMpfsYkovyVIPnedzhFQORwTbHjNi=qKMpfsYkovyVIPnedzhFQORwTbHjNE.callRequestCookies('Get',qKMpfsYkovyVIPnedzhFQORwTbHjNU,payload=qKMpfsYkovyVIPnedzhFQORwTbHjaA,params=qKMpfsYkovyVIPnedzhFQORwTbHjNG,headers=qKMpfsYkovyVIPnedzhFQORwTbHjaA,cookies=qKMpfsYkovyVIPnedzhFQORwTbHjaA)
    qKMpfsYkovyVIPnedzhFQORwTbHjNA=json.loads(qKMpfsYkovyVIPnedzhFQORwTbHjNi.text)
    qKMpfsYkovyVIPnedzhFQORwTbHjlW=qKMpfsYkovyVIPnedzhFQORwTbHjNA['cell_toplist']['celllist']
    for qKMpfsYkovyVIPnedzhFQORwTbHjlc in qKMpfsYkovyVIPnedzhFQORwTbHjlW:
     qKMpfsYkovyVIPnedzhFQORwTbHjaJ=qKMpfsYkovyVIPnedzhFQORwTbHjlc.get('game_date')
     qKMpfsYkovyVIPnedzhFQORwTbHjaG =qKMpfsYkovyVIPnedzhFQORwTbHjlc.get('svc_id')
     if qKMpfsYkovyVIPnedzhFQORwTbHjaG=='':continue
     if qKMpfsYkovyVIPnedzhFQORwTbHjaJ in qKMpfsYkovyVIPnedzhFQORwTbHjLB:
      qKMpfsYkovyVIPnedzhFQORwTbHjaW=qKMpfsYkovyVIPnedzhFQORwTbHjlc.get('game_status') 
      qKMpfsYkovyVIPnedzhFQORwTbHjac =qKMpfsYkovyVIPnedzhFQORwTbHjlc.get('title_list')[0].get('text')
      qKMpfsYkovyVIPnedzhFQORwTbHjaJ =qKMpfsYkovyVIPnedzhFQORwTbHjaJ[:4]+'-'+qKMpfsYkovyVIPnedzhFQORwTbHjaJ[4:6]+'-'+qKMpfsYkovyVIPnedzhFQORwTbHjaJ[-2:]
      qKMpfsYkovyVIPnedzhFQORwTbHjat =qKMpfsYkovyVIPnedzhFQORwTbHjlc.get('game_time')
      qKMpfsYkovyVIPnedzhFQORwTbHjat =qKMpfsYkovyVIPnedzhFQORwTbHjat[:2]+':'+qKMpfsYkovyVIPnedzhFQORwTbHjat[-2:]
      qKMpfsYkovyVIPnedzhFQORwTbHjlt={'game_date':qKMpfsYkovyVIPnedzhFQORwTbHjaJ,'game_time':qKMpfsYkovyVIPnedzhFQORwTbHjat,'svc_id':qKMpfsYkovyVIPnedzhFQORwTbHjaG,'away_team':qKMpfsYkovyVIPnedzhFQORwTbHjlc.get('away_team').get('team_name'),'home_team':qKMpfsYkovyVIPnedzhFQORwTbHjlc.get('home_team').get('team_name'),'game_status':qKMpfsYkovyVIPnedzhFQORwTbHjaW,'game_place':qKMpfsYkovyVIPnedzhFQORwTbHjlc.get('game_place'),}
      qKMpfsYkovyVIPnedzhFQORwTbHjaN.append(qKMpfsYkovyVIPnedzhFQORwTbHjlt)
  except qKMpfsYkovyVIPnedzhFQORwTbHjJE as exception:
   qKMpfsYkovyVIPnedzhFQORwTbHjJL(exception)
   return[]
  qKMpfsYkovyVIPnedzhFQORwTbHjam=[]
  for i in qKMpfsYkovyVIPnedzhFQORwTbHjJN(2):
   for qKMpfsYkovyVIPnedzhFQORwTbHjlc in qKMpfsYkovyVIPnedzhFQORwTbHjaN:
    if i==0 and qKMpfsYkovyVIPnedzhFQORwTbHjlc.get('game_status')=='LIVE':
     qKMpfsYkovyVIPnedzhFQORwTbHjam.append(qKMpfsYkovyVIPnedzhFQORwTbHjlc)
    elif i==1 and qKMpfsYkovyVIPnedzhFQORwTbHjlc.get('game_status')!='LIVE':
     qKMpfsYkovyVIPnedzhFQORwTbHjam.append(qKMpfsYkovyVIPnedzhFQORwTbHjlc)
  return qKMpfsYkovyVIPnedzhFQORwTbHjam
 def GetBookmarkInfo(qKMpfsYkovyVIPnedzhFQORwTbHjNE,qKMpfsYkovyVIPnedzhFQORwTbHjlB,qKMpfsYkovyVIPnedzhFQORwTbHjlA,qKMpfsYkovyVIPnedzhFQORwTbHjLm):
  if qKMpfsYkovyVIPnedzhFQORwTbHjlA=='tvshow':
   if qKMpfsYkovyVIPnedzhFQORwTbHjLm=='contentid':
    qKMpfsYkovyVIPnedzhFQORwTbHjEJ=qKMpfsYkovyVIPnedzhFQORwTbHjlB
    qKMpfsYkovyVIPnedzhFQORwTbHjlB =qKMpfsYkovyVIPnedzhFQORwTbHjNE.ContentidToProgramid(qKMpfsYkovyVIPnedzhFQORwTbHjEJ)
   else:
    qKMpfsYkovyVIPnedzhFQORwTbHjEJ=qKMpfsYkovyVIPnedzhFQORwTbHjNE.ProgramidToContentid(qKMpfsYkovyVIPnedzhFQORwTbHjlB)
  else:
   qKMpfsYkovyVIPnedzhFQORwTbHjEJ=''
  qKMpfsYkovyVIPnedzhFQORwTbHjar={'indexinfo':{'ott':'wavve','videoid':qKMpfsYkovyVIPnedzhFQORwTbHjlB,'vidtype':qKMpfsYkovyVIPnedzhFQORwTbHjlA,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':qKMpfsYkovyVIPnedzhFQORwTbHjlA,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if qKMpfsYkovyVIPnedzhFQORwTbHjlA=='tvshow':
   qKMpfsYkovyVIPnedzhFQORwTbHjNU=qKMpfsYkovyVIPnedzhFQORwTbHjNE.API_DOMAIN+'/cf/vod/contents/'+qKMpfsYkovyVIPnedzhFQORwTbHjEJ 
   qKMpfsYkovyVIPnedzhFQORwTbHjNG=qKMpfsYkovyVIPnedzhFQORwTbHjNE.GetDefaultParams(login=qKMpfsYkovyVIPnedzhFQORwTbHjaB)
   qKMpfsYkovyVIPnedzhFQORwTbHjNi=qKMpfsYkovyVIPnedzhFQORwTbHjNE.callRequestCookies('Get',qKMpfsYkovyVIPnedzhFQORwTbHjNU,payload=qKMpfsYkovyVIPnedzhFQORwTbHjaA,params=qKMpfsYkovyVIPnedzhFQORwTbHjNG,headers=qKMpfsYkovyVIPnedzhFQORwTbHjaA,cookies=qKMpfsYkovyVIPnedzhFQORwTbHjaA)
   qKMpfsYkovyVIPnedzhFQORwTbHjNA=json.loads(qKMpfsYkovyVIPnedzhFQORwTbHjNi.text)
   if not('programtitle' in qKMpfsYkovyVIPnedzhFQORwTbHjNA):return{}
   qKMpfsYkovyVIPnedzhFQORwTbHjaS=qKMpfsYkovyVIPnedzhFQORwTbHjNA
   qKMpfsYkovyVIPnedzhFQORwTbHjaX=qKMpfsYkovyVIPnedzhFQORwTbHjaS.get('programtitle')
   qKMpfsYkovyVIPnedzhFQORwTbHjar['saveinfo']['infoLabels']['title']=qKMpfsYkovyVIPnedzhFQORwTbHjaX
   if qKMpfsYkovyVIPnedzhFQORwTbHjaS.get('targetage')=='18' or qKMpfsYkovyVIPnedzhFQORwTbHjaS.get('targetage')=='19' or qKMpfsYkovyVIPnedzhFQORwTbHjaS.get('targetage')=='21':
    qKMpfsYkovyVIPnedzhFQORwTbHjaX +=u' (%s)'%(qKMpfsYkovyVIPnedzhFQORwTbHjaS.get('targetage'))
   qKMpfsYkovyVIPnedzhFQORwTbHjar['saveinfo']['title'] =qKMpfsYkovyVIPnedzhFQORwTbHjaX
   qKMpfsYkovyVIPnedzhFQORwTbHjar['saveinfo']['infoLabels']['mpaa'] =qKMpfsYkovyVIPnedzhFQORwTbHjaS.get('targetage')
   qKMpfsYkovyVIPnedzhFQORwTbHjar['saveinfo']['infoLabels']['plot'] =qKMpfsYkovyVIPnedzhFQORwTbHjaS.get('programsynopsis').replace('<br>','\n')
   qKMpfsYkovyVIPnedzhFQORwTbHjar['saveinfo']['infoLabels']['studio'] =qKMpfsYkovyVIPnedzhFQORwTbHjaS.get('channelname')
   if qKMpfsYkovyVIPnedzhFQORwTbHjaS.get('firstreleaseyear')!='':qKMpfsYkovyVIPnedzhFQORwTbHjar['saveinfo']['infoLabels']['year'] =qKMpfsYkovyVIPnedzhFQORwTbHjaS.get('firstreleaseyear')
   if qKMpfsYkovyVIPnedzhFQORwTbHjaS.get('firstreleasedate')!='':qKMpfsYkovyVIPnedzhFQORwTbHjar['saveinfo']['infoLabels']['premiered']=qKMpfsYkovyVIPnedzhFQORwTbHjaS.get('firstreleasedate')
   if qKMpfsYkovyVIPnedzhFQORwTbHjaS.get('genretext') !='':qKMpfsYkovyVIPnedzhFQORwTbHjar['saveinfo']['infoLabels']['genre'] =[qKMpfsYkovyVIPnedzhFQORwTbHjaS.get('genretext')]
   qKMpfsYkovyVIPnedzhFQORwTbHjag=[]
   for qKMpfsYkovyVIPnedzhFQORwTbHjax in qKMpfsYkovyVIPnedzhFQORwTbHjaS['actors']['list']:qKMpfsYkovyVIPnedzhFQORwTbHjag.append(qKMpfsYkovyVIPnedzhFQORwTbHjax.get('text'))
   if qKMpfsYkovyVIPnedzhFQORwTbHjJW(qKMpfsYkovyVIPnedzhFQORwTbHjag)>0:
    if qKMpfsYkovyVIPnedzhFQORwTbHjag[0]!='':qKMpfsYkovyVIPnedzhFQORwTbHjar['saveinfo']['infoLabels']['cast']=qKMpfsYkovyVIPnedzhFQORwTbHjag
   qKMpfsYkovyVIPnedzhFQORwTbHjED =''
   qKMpfsYkovyVIPnedzhFQORwTbHjEU =''
   qKMpfsYkovyVIPnedzhFQORwTbHjEu=''
   if qKMpfsYkovyVIPnedzhFQORwTbHjaS.get('programposterimage')!='':qKMpfsYkovyVIPnedzhFQORwTbHjED =qKMpfsYkovyVIPnedzhFQORwTbHjNE.HTTPTAG+qKMpfsYkovyVIPnedzhFQORwTbHjaS.get('programposterimage')
   if qKMpfsYkovyVIPnedzhFQORwTbHjaS.get('programimage') !='':qKMpfsYkovyVIPnedzhFQORwTbHjEU =qKMpfsYkovyVIPnedzhFQORwTbHjNE.HTTPTAG+qKMpfsYkovyVIPnedzhFQORwTbHjaS.get('programimage')
   if qKMpfsYkovyVIPnedzhFQORwTbHjaS.get('programcirlceimage')!='':qKMpfsYkovyVIPnedzhFQORwTbHjEu=qKMpfsYkovyVIPnedzhFQORwTbHjNE.HTTPTAG+qKMpfsYkovyVIPnedzhFQORwTbHjaS.get('programcirlceimage')
   if 'poster_default' in qKMpfsYkovyVIPnedzhFQORwTbHjED:
    qKMpfsYkovyVIPnedzhFQORwTbHjED =qKMpfsYkovyVIPnedzhFQORwTbHjEU
    qKMpfsYkovyVIPnedzhFQORwTbHjEu=''
   qKMpfsYkovyVIPnedzhFQORwTbHjar['saveinfo']['thumbnail']['poster']=qKMpfsYkovyVIPnedzhFQORwTbHjED
   qKMpfsYkovyVIPnedzhFQORwTbHjar['saveinfo']['thumbnail']['thumb']=qKMpfsYkovyVIPnedzhFQORwTbHjEU
   qKMpfsYkovyVIPnedzhFQORwTbHjar['saveinfo']['thumbnail']['clearlogo']=qKMpfsYkovyVIPnedzhFQORwTbHjEu
   qKMpfsYkovyVIPnedzhFQORwTbHjar['saveinfo']['thumbnail']['fanart']=qKMpfsYkovyVIPnedzhFQORwTbHjEU
  else:
   qKMpfsYkovyVIPnedzhFQORwTbHjNU=qKMpfsYkovyVIPnedzhFQORwTbHjNE.API_DOMAIN+'/movie/contents/'+qKMpfsYkovyVIPnedzhFQORwTbHjlB 
   qKMpfsYkovyVIPnedzhFQORwTbHjNG=qKMpfsYkovyVIPnedzhFQORwTbHjNE.GetDefaultParams(login=qKMpfsYkovyVIPnedzhFQORwTbHjaB)
   qKMpfsYkovyVIPnedzhFQORwTbHjNi=qKMpfsYkovyVIPnedzhFQORwTbHjNE.callRequestCookies('Get',qKMpfsYkovyVIPnedzhFQORwTbHjNU,payload=qKMpfsYkovyVIPnedzhFQORwTbHjaA,params=qKMpfsYkovyVIPnedzhFQORwTbHjNG,headers=qKMpfsYkovyVIPnedzhFQORwTbHjaA,cookies=qKMpfsYkovyVIPnedzhFQORwTbHjaA)
   qKMpfsYkovyVIPnedzhFQORwTbHjNA=json.loads(qKMpfsYkovyVIPnedzhFQORwTbHjNi.text)
   if not('title' in qKMpfsYkovyVIPnedzhFQORwTbHjNA):return{}
   qKMpfsYkovyVIPnedzhFQORwTbHjaS=qKMpfsYkovyVIPnedzhFQORwTbHjNA
   qKMpfsYkovyVIPnedzhFQORwTbHjaX=qKMpfsYkovyVIPnedzhFQORwTbHjaS.get('title')
   qKMpfsYkovyVIPnedzhFQORwTbHjar['saveinfo']['infoLabels']['title']=qKMpfsYkovyVIPnedzhFQORwTbHjaX
   if qKMpfsYkovyVIPnedzhFQORwTbHjaS.get('targetage')=='18' or qKMpfsYkovyVIPnedzhFQORwTbHjaS.get('targetage')=='19' or qKMpfsYkovyVIPnedzhFQORwTbHjaS.get('targetage')=='21':
    qKMpfsYkovyVIPnedzhFQORwTbHjaX +=u' (%s)'%(qKMpfsYkovyVIPnedzhFQORwTbHjaS.get('targetage'))
   qKMpfsYkovyVIPnedzhFQORwTbHjar['saveinfo']['title'] =qKMpfsYkovyVIPnedzhFQORwTbHjaX
   qKMpfsYkovyVIPnedzhFQORwTbHjar['saveinfo']['infoLabels']['mpaa'] =qKMpfsYkovyVIPnedzhFQORwTbHjaS.get('targetage')
   qKMpfsYkovyVIPnedzhFQORwTbHjar['saveinfo']['infoLabels']['plot'] =qKMpfsYkovyVIPnedzhFQORwTbHjaS.get('synopsis').replace('<br>','\n')
   qKMpfsYkovyVIPnedzhFQORwTbHjar['saveinfo']['infoLabels']['duration']=qKMpfsYkovyVIPnedzhFQORwTbHjaS.get('playtime')
   qKMpfsYkovyVIPnedzhFQORwTbHjar['saveinfo']['infoLabels']['country']=qKMpfsYkovyVIPnedzhFQORwTbHjaS.get('country')
   qKMpfsYkovyVIPnedzhFQORwTbHjar['saveinfo']['infoLabels']['studio'] =qKMpfsYkovyVIPnedzhFQORwTbHjaS.get('cpname')
   if qKMpfsYkovyVIPnedzhFQORwTbHjaS.get('releasedate')!='':
    qKMpfsYkovyVIPnedzhFQORwTbHjar['saveinfo']['infoLabels']['year'] =qKMpfsYkovyVIPnedzhFQORwTbHjaS.get('releasedate')[:4]
    qKMpfsYkovyVIPnedzhFQORwTbHjar['saveinfo']['infoLabels']['premiered']=qKMpfsYkovyVIPnedzhFQORwTbHjaS.get('releasedate')
   qKMpfsYkovyVIPnedzhFQORwTbHjag=[]
   for qKMpfsYkovyVIPnedzhFQORwTbHjax in qKMpfsYkovyVIPnedzhFQORwTbHjaS['actors']['list']:qKMpfsYkovyVIPnedzhFQORwTbHjag.append(qKMpfsYkovyVIPnedzhFQORwTbHjax.get('text'))
   if qKMpfsYkovyVIPnedzhFQORwTbHjJW(qKMpfsYkovyVIPnedzhFQORwTbHjag)>0:
    if qKMpfsYkovyVIPnedzhFQORwTbHjag[0]!='':qKMpfsYkovyVIPnedzhFQORwTbHjar['saveinfo']['infoLabels']['cast']=qKMpfsYkovyVIPnedzhFQORwTbHjag
   qKMpfsYkovyVIPnedzhFQORwTbHjaD=[]
   for qKMpfsYkovyVIPnedzhFQORwTbHjaU in qKMpfsYkovyVIPnedzhFQORwTbHjaS['directors']['list']:qKMpfsYkovyVIPnedzhFQORwTbHjaD.append(qKMpfsYkovyVIPnedzhFQORwTbHjaU.get('text'))
   if qKMpfsYkovyVIPnedzhFQORwTbHjJW(qKMpfsYkovyVIPnedzhFQORwTbHjaD)>0:
    if qKMpfsYkovyVIPnedzhFQORwTbHjaD[0]!='':qKMpfsYkovyVIPnedzhFQORwTbHjar['saveinfo']['infoLabels']['director']=qKMpfsYkovyVIPnedzhFQORwTbHjaD
   qKMpfsYkovyVIPnedzhFQORwTbHjla=[]
   for qKMpfsYkovyVIPnedzhFQORwTbHjau in qKMpfsYkovyVIPnedzhFQORwTbHjaS['genre']['list']:qKMpfsYkovyVIPnedzhFQORwTbHjla.append(qKMpfsYkovyVIPnedzhFQORwTbHjau.get('text'))
   if qKMpfsYkovyVIPnedzhFQORwTbHjJW(qKMpfsYkovyVIPnedzhFQORwTbHjla)>0:
    if qKMpfsYkovyVIPnedzhFQORwTbHjla[0]!='':qKMpfsYkovyVIPnedzhFQORwTbHjar['saveinfo']['infoLabels']['genre']=qKMpfsYkovyVIPnedzhFQORwTbHjla
   qKMpfsYkovyVIPnedzhFQORwTbHjED ='https://%s'%qKMpfsYkovyVIPnedzhFQORwTbHjaS['image']
   qKMpfsYkovyVIPnedzhFQORwTbHjar['saveinfo']['thumbnail']['poster'] =qKMpfsYkovyVIPnedzhFQORwTbHjED
   qKMpfsYkovyVIPnedzhFQORwTbHjar['saveinfo']['thumbnail']['thumb'] =qKMpfsYkovyVIPnedzhFQORwTbHjED
  return qKMpfsYkovyVIPnedzhFQORwTbHjar
# Created by pyminifier (https://github.com/liftoff/pyminifier)
