# wavveM-v19
웨이브 애드온 for Kodi19

###
# kodi19용은 저장소를 통해서만 업데이트 됩니다.
* [Korea OTT Package for Kodi 18 (public)-18.0.0.zip](https://github.com/kym1088/repository_public/raw/master/repository.nightrain_v18_public.zip)
* [Korea OTT Package for Kodi 19 (public)-19.0.0.zip](https://github.com/kym1088/repository_public/raw/master/repository.nightrain_v19_public.zip)
###

## Version 2.2.4 (2021.07.03)
- 라디오

## Version 2.2.3 (2021.06.28)
- ffmpegdirect

## Version 2.2.2 (2021.05.18)
- 프로야구 추가

## Version 2.2.1 (2021.03.12)
- 통합 찜하기 기능 추가

## Version 2.2.0 (2021.03.07)
- contentType, 찜하기

## Version 2.1.7 (2021.02.23)
- 검색수정, 검색이력

## Version 2.1.6 (2021.02.14)
- 통합검색 추가

## Version 2.1.5 (2021.01.24)
- 검색오류 수정

## Version 2.1.4 (2021.01.16)
- 포스터 추가

## Version 2.1.3 (2020.12.25)
- 썸네일 누락

## Version 2.1.2 (2020.12.12)
- 지금 핫한 프로그램 추가

## Version 2.1.1 (2020.11.07)
- live 채널 오류 수정

## Version 2.1.0 (2020.10.29)
- 웨이브 메뉴변경 적용

## Version 2.0.4 (2020.10.08)
- alpha_2 오류 수정

## Version 2.0.3 (2020.09.16)
- 재접속 오류수정

## Version 2.0.2 (2020.09.09)
- timezone

## Version 2.0.1 (2020.09.08)
- 특정스킨 오류 수정

## Version 2.0.0 (2020.08.29)
- python3(kodi 19) 전환



