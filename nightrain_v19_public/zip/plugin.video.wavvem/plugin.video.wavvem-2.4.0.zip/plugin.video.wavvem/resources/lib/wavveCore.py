__author__="NightRain"
qbynAlwuUtXQSJEDjROdLgpYPifvKG=object
qbynAlwuUtXQSJEDjROdLgpYPifvKc=None
qbynAlwuUtXQSJEDjROdLgpYPifvKm=False
qbynAlwuUtXQSJEDjROdLgpYPifvKs=open
qbynAlwuUtXQSJEDjROdLgpYPifvKz=True
qbynAlwuUtXQSJEDjROdLgpYPifvKh=range
qbynAlwuUtXQSJEDjROdLgpYPifvKV=str
qbynAlwuUtXQSJEDjROdLgpYPifvKI=Exception
qbynAlwuUtXQSJEDjROdLgpYPifvKk=print
qbynAlwuUtXQSJEDjROdLgpYPifvKa=dict
qbynAlwuUtXQSJEDjROdLgpYPifvKT=int
qbynAlwuUtXQSJEDjROdLgpYPifvKB=len
import urllib
import re
import json
import sys
import requests
import datetime
import base64
class qbynAlwuUtXQSJEDjROdLgpYPifvCr(qbynAlwuUtXQSJEDjROdLgpYPifvKG):
 def __init__(qbynAlwuUtXQSJEDjROdLgpYPifvCF):
  qbynAlwuUtXQSJEDjROdLgpYPifvCF.API_DOMAIN='https://apis.wavve.com'
  qbynAlwuUtXQSJEDjROdLgpYPifvCF.WV ={}
  qbynAlwuUtXQSJEDjROdLgpYPifvCF.Init_WV_Total()
  qbynAlwuUtXQSJEDjROdLgpYPifvCF.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  qbynAlwuUtXQSJEDjROdLgpYPifvCF.DEVICE ='pc'
  qbynAlwuUtXQSJEDjROdLgpYPifvCF.DRM ='wm'
  qbynAlwuUtXQSJEDjROdLgpYPifvCF.PARTNER ='pooq'
  qbynAlwuUtXQSJEDjROdLgpYPifvCF.POOQZONE ='none'
  qbynAlwuUtXQSJEDjROdLgpYPifvCF.REGION ='kor'
  qbynAlwuUtXQSJEDjROdLgpYPifvCF.TARGETAGE ='all'
  qbynAlwuUtXQSJEDjROdLgpYPifvCF.HTTPTAG ='https://'
  qbynAlwuUtXQSJEDjROdLgpYPifvCF.LIST_LIMIT=30 
  qbynAlwuUtXQSJEDjROdLgpYPifvCF.EP_LIMIT =30 
  qbynAlwuUtXQSJEDjROdLgpYPifvCF.MV_LIMIT =24 
  qbynAlwuUtXQSJEDjROdLgpYPifvCF.SEARCH_LIMIT=20 
  qbynAlwuUtXQSJEDjROdLgpYPifvCF.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36'
  qbynAlwuUtXQSJEDjROdLgpYPifvCF.DEFAULT_HEADER={'user-agent':qbynAlwuUtXQSJEDjROdLgpYPifvCF.USER_AGENT}
  qbynAlwuUtXQSJEDjROdLgpYPifvCF.KodiVersion=20
 def Init_WV_Total(qbynAlwuUtXQSJEDjROdLgpYPifvCF):
  qbynAlwuUtXQSJEDjROdLgpYPifvCF.WV={'account':{},'cookies':{},}
 def callRequestCookies(qbynAlwuUtXQSJEDjROdLgpYPifvCF,jobtype,qbynAlwuUtXQSJEDjROdLgpYPifvCo,payload=qbynAlwuUtXQSJEDjROdLgpYPifvKc,params=qbynAlwuUtXQSJEDjROdLgpYPifvKc,headers=qbynAlwuUtXQSJEDjROdLgpYPifvKc,cookies=qbynAlwuUtXQSJEDjROdLgpYPifvKc,redirects=qbynAlwuUtXQSJEDjROdLgpYPifvKm):
  qbynAlwuUtXQSJEDjROdLgpYPifvCW=qbynAlwuUtXQSJEDjROdLgpYPifvCF.DEFAULT_HEADER
  if headers:qbynAlwuUtXQSJEDjROdLgpYPifvCW.update(headers)
  if jobtype=='Get':
   qbynAlwuUtXQSJEDjROdLgpYPifvCH=requests.get(qbynAlwuUtXQSJEDjROdLgpYPifvCo,params=params,headers=qbynAlwuUtXQSJEDjROdLgpYPifvCW,cookies=cookies,allow_redirects=redirects)
  else:
   qbynAlwuUtXQSJEDjROdLgpYPifvCH=requests.post(qbynAlwuUtXQSJEDjROdLgpYPifvCo,json=payload,params=params,headers=qbynAlwuUtXQSJEDjROdLgpYPifvCW,cookies=cookies,allow_redirects=redirects)
  return qbynAlwuUtXQSJEDjROdLgpYPifvCH
 def JsonFile_Save(qbynAlwuUtXQSJEDjROdLgpYPifvCF,filename,qbynAlwuUtXQSJEDjROdLgpYPifvCK):
  if filename=='':return qbynAlwuUtXQSJEDjROdLgpYPifvKm
  try:
   fp=qbynAlwuUtXQSJEDjROdLgpYPifvKs(filename,'w',-1,'utf-8')
   json.dump(qbynAlwuUtXQSJEDjROdLgpYPifvCK,fp,indent=4,ensure_ascii=qbynAlwuUtXQSJEDjROdLgpYPifvKm)
   fp.close()
  except:
   return qbynAlwuUtXQSJEDjROdLgpYPifvKm
  return qbynAlwuUtXQSJEDjROdLgpYPifvKz
 def JsonFile_Load(qbynAlwuUtXQSJEDjROdLgpYPifvCF,filename):
  if filename=='':return{}
  try:
   fp=qbynAlwuUtXQSJEDjROdLgpYPifvKs(filename,'r',-1,'utf-8')
   qbynAlwuUtXQSJEDjROdLgpYPifvCe=json.load(fp)
   fp.close()
  except:
   return{}
  return qbynAlwuUtXQSJEDjROdLgpYPifvCe
 def Save_session_acount(qbynAlwuUtXQSJEDjROdLgpYPifvCF,qbynAlwuUtXQSJEDjROdLgpYPifvCN,qbynAlwuUtXQSJEDjROdLgpYPifvCG,qbynAlwuUtXQSJEDjROdLgpYPifvCc):
  qbynAlwuUtXQSJEDjROdLgpYPifvCF.WV['account']['wvid']=base64.standard_b64encode(qbynAlwuUtXQSJEDjROdLgpYPifvCN.encode()).decode('utf-8')
  qbynAlwuUtXQSJEDjROdLgpYPifvCF.WV['account']['wvpw']=base64.standard_b64encode(qbynAlwuUtXQSJEDjROdLgpYPifvCG.encode()).decode('utf-8')
  qbynAlwuUtXQSJEDjROdLgpYPifvCF.WV['account']['wvpf']=qbynAlwuUtXQSJEDjROdLgpYPifvCc 
 def Load_session_acount(qbynAlwuUtXQSJEDjROdLgpYPifvCF):
  try:
   qbynAlwuUtXQSJEDjROdLgpYPifvCN=base64.standard_b64decode(qbynAlwuUtXQSJEDjROdLgpYPifvCF.WV['account']['wvid']).decode('utf-8')
   qbynAlwuUtXQSJEDjROdLgpYPifvCG=base64.standard_b64decode(qbynAlwuUtXQSJEDjROdLgpYPifvCF.WV['account']['wvpw']).decode('utf-8')
   qbynAlwuUtXQSJEDjROdLgpYPifvCc=qbynAlwuUtXQSJEDjROdLgpYPifvCF.WV['account']['wvpf']
  except:
   return '','',0
  return qbynAlwuUtXQSJEDjROdLgpYPifvCN,qbynAlwuUtXQSJEDjROdLgpYPifvCG,qbynAlwuUtXQSJEDjROdLgpYPifvCc
 def GetDefaultParams(qbynAlwuUtXQSJEDjROdLgpYPifvCF,login=qbynAlwuUtXQSJEDjROdLgpYPifvKz):
  qbynAlwuUtXQSJEDjROdLgpYPifvCm={'apikey':qbynAlwuUtXQSJEDjROdLgpYPifvCF.APIKEY,'credential':qbynAlwuUtXQSJEDjROdLgpYPifvCF.WV['cookies']['credential']if login else 'none','device':qbynAlwuUtXQSJEDjROdLgpYPifvCF.DEVICE,'drm':qbynAlwuUtXQSJEDjROdLgpYPifvCF.DRM,'partner':qbynAlwuUtXQSJEDjROdLgpYPifvCF.PARTNER,'pooqzone':qbynAlwuUtXQSJEDjROdLgpYPifvCF.POOQZONE,'region':qbynAlwuUtXQSJEDjROdLgpYPifvCF.REGION,'targetage':qbynAlwuUtXQSJEDjROdLgpYPifvCF.TARGETAGE,}
  return qbynAlwuUtXQSJEDjROdLgpYPifvCm
 def GetDefaultParams_AND(qbynAlwuUtXQSJEDjROdLgpYPifvCF):
  qbynAlwuUtXQSJEDjROdLgpYPifvCm={'apikey':'6A87455D54481A536DFB8AD397C5EC4D','credential':qbynAlwuUtXQSJEDjROdLgpYPifvCF.WV['cookies']['credential'],'device':'ott','drm':qbynAlwuUtXQSJEDjROdLgpYPifvCF.DRM,'partner':qbynAlwuUtXQSJEDjROdLgpYPifvCF.PARTNER,'pooqzone':qbynAlwuUtXQSJEDjROdLgpYPifvCF.POOQZONE,'region':qbynAlwuUtXQSJEDjROdLgpYPifvCF.REGION,'targetage':qbynAlwuUtXQSJEDjROdLgpYPifvCF.TARGETAGE,}
  return qbynAlwuUtXQSJEDjROdLgpYPifvCm
 def GetGUID(qbynAlwuUtXQSJEDjROdLgpYPifvCF,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   qbynAlwuUtXQSJEDjROdLgpYPifvCs=qbynAlwuUtXQSJEDjROdLgpYPifvCF.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   qbynAlwuUtXQSJEDjROdLgpYPifvCz=GenerateRandomString(5)
   qbynAlwuUtXQSJEDjROdLgpYPifvCh=qbynAlwuUtXQSJEDjROdLgpYPifvCz+media+qbynAlwuUtXQSJEDjROdLgpYPifvCs
   return qbynAlwuUtXQSJEDjROdLgpYPifvCh
  def GenerateRandomString(num):
   from random import randint
   qbynAlwuUtXQSJEDjROdLgpYPifvCV=""
   for i in qbynAlwuUtXQSJEDjROdLgpYPifvKh(0,num):
    s=qbynAlwuUtXQSJEDjROdLgpYPifvKV(randint(1,5))
    qbynAlwuUtXQSJEDjROdLgpYPifvCV+=s
   return qbynAlwuUtXQSJEDjROdLgpYPifvCV
  if guidType==3:
   qbynAlwuUtXQSJEDjROdLgpYPifvCh=guid_str
  else:
   qbynAlwuUtXQSJEDjROdLgpYPifvCh=GenerateID(guid_str)
  qbynAlwuUtXQSJEDjROdLgpYPifvCI=qbynAlwuUtXQSJEDjROdLgpYPifvCF.GetHash(qbynAlwuUtXQSJEDjROdLgpYPifvCh)
  if guidType in[2,3]:
   qbynAlwuUtXQSJEDjROdLgpYPifvCI='%s-%s-%s-%s-%s'%(qbynAlwuUtXQSJEDjROdLgpYPifvCI[:8],qbynAlwuUtXQSJEDjROdLgpYPifvCI[8:12],qbynAlwuUtXQSJEDjROdLgpYPifvCI[12:16],qbynAlwuUtXQSJEDjROdLgpYPifvCI[16:20],qbynAlwuUtXQSJEDjROdLgpYPifvCI[20:])
  return qbynAlwuUtXQSJEDjROdLgpYPifvCI
 def GetHash(qbynAlwuUtXQSJEDjROdLgpYPifvCF,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return qbynAlwuUtXQSJEDjROdLgpYPifvKV(m.hexdigest())
 def CheckQuality(qbynAlwuUtXQSJEDjROdLgpYPifvCF,sel_qt,qt_list):
  qbynAlwuUtXQSJEDjROdLgpYPifvCk=0
  for qbynAlwuUtXQSJEDjROdLgpYPifvCa in qt_list:
   if sel_qt>=qbynAlwuUtXQSJEDjROdLgpYPifvCa:return qbynAlwuUtXQSJEDjROdLgpYPifvCa
   qbynAlwuUtXQSJEDjROdLgpYPifvCk=qbynAlwuUtXQSJEDjROdLgpYPifvCa
  return qbynAlwuUtXQSJEDjROdLgpYPifvCk
 def Get_Now_Datetime(qbynAlwuUtXQSJEDjROdLgpYPifvCF):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(qbynAlwuUtXQSJEDjROdLgpYPifvCF,in_text):
  qbynAlwuUtXQSJEDjROdLgpYPifvCB=in_text.replace('&lt;','<').replace('&gt;','>')
  qbynAlwuUtXQSJEDjROdLgpYPifvCB=qbynAlwuUtXQSJEDjROdLgpYPifvCB.replace('$O$','')
  qbynAlwuUtXQSJEDjROdLgpYPifvCB=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',qbynAlwuUtXQSJEDjROdLgpYPifvCB)
  qbynAlwuUtXQSJEDjROdLgpYPifvCB=qbynAlwuUtXQSJEDjROdLgpYPifvCB.lstrip('#')
  return qbynAlwuUtXQSJEDjROdLgpYPifvCB
 def GetCredential(qbynAlwuUtXQSJEDjROdLgpYPifvCF,user_id,user_pw,user_pf):
  qbynAlwuUtXQSJEDjROdLgpYPifvCM=qbynAlwuUtXQSJEDjROdLgpYPifvKm
  try:
   qbynAlwuUtXQSJEDjROdLgpYPifvCo=qbynAlwuUtXQSJEDjROdLgpYPifvCF.API_DOMAIN+ '/login'
   qbynAlwuUtXQSJEDjROdLgpYPifvCm=qbynAlwuUtXQSJEDjROdLgpYPifvCF.GetDefaultParams(login=qbynAlwuUtXQSJEDjROdLgpYPifvKm)
   qbynAlwuUtXQSJEDjROdLgpYPifvrC={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   qbynAlwuUtXQSJEDjROdLgpYPifvrF=qbynAlwuUtXQSJEDjROdLgpYPifvCF.callRequestCookies('Post',qbynAlwuUtXQSJEDjROdLgpYPifvCo,payload=qbynAlwuUtXQSJEDjROdLgpYPifvrC,params=qbynAlwuUtXQSJEDjROdLgpYPifvCm,headers=qbynAlwuUtXQSJEDjROdLgpYPifvKc,cookies=qbynAlwuUtXQSJEDjROdLgpYPifvKc)
   qbynAlwuUtXQSJEDjROdLgpYPifvrW=json.loads(qbynAlwuUtXQSJEDjROdLgpYPifvrF.text)
   qbynAlwuUtXQSJEDjROdLgpYPifvCF.WV['cookies']['credential']=qbynAlwuUtXQSJEDjROdLgpYPifvrW['credential']
   if user_pf!=0:
    qbynAlwuUtXQSJEDjROdLgpYPifvrC={'id':qbynAlwuUtXQSJEDjROdLgpYPifvCF.WV['cookies']['credential'],'password':'','profile':qbynAlwuUtXQSJEDjROdLgpYPifvKV(user_pf),'pushid':'','type':'credential'}
    qbynAlwuUtXQSJEDjROdLgpYPifvCm =qbynAlwuUtXQSJEDjROdLgpYPifvCF.GetDefaultParams(login=qbynAlwuUtXQSJEDjROdLgpYPifvKz) 
    qbynAlwuUtXQSJEDjROdLgpYPifvrF=qbynAlwuUtXQSJEDjROdLgpYPifvCF.callRequestCookies('Post',qbynAlwuUtXQSJEDjROdLgpYPifvCo,payload=qbynAlwuUtXQSJEDjROdLgpYPifvrC,params=qbynAlwuUtXQSJEDjROdLgpYPifvCm,headers=qbynAlwuUtXQSJEDjROdLgpYPifvKc,cookies=qbynAlwuUtXQSJEDjROdLgpYPifvKc)
    qbynAlwuUtXQSJEDjROdLgpYPifvrW=json.loads(qbynAlwuUtXQSJEDjROdLgpYPifvrF.text)
    qbynAlwuUtXQSJEDjROdLgpYPifvCF.WV['cookies']['credential']=qbynAlwuUtXQSJEDjROdLgpYPifvrW['credential']
   qbynAlwuUtXQSJEDjROdLgpYPifvrH=user_id+qbynAlwuUtXQSJEDjROdLgpYPifvKV(user_pf) 
   qbynAlwuUtXQSJEDjROdLgpYPifvCF.WV['cookies']['uuid']=qbynAlwuUtXQSJEDjROdLgpYPifvCF.GetGUID(guid_str=qbynAlwuUtXQSJEDjROdLgpYPifvrH,guidType=3)
   qbynAlwuUtXQSJEDjROdLgpYPifvCM=qbynAlwuUtXQSJEDjROdLgpYPifvKz
  except qbynAlwuUtXQSJEDjROdLgpYPifvKI as exception:
   qbynAlwuUtXQSJEDjROdLgpYPifvKk(exception)
   qbynAlwuUtXQSJEDjROdLgpYPifvCF.Init_WV_Total()
  return qbynAlwuUtXQSJEDjROdLgpYPifvCM
 def GetIssue(qbynAlwuUtXQSJEDjROdLgpYPifvCF):
  qbynAlwuUtXQSJEDjROdLgpYPifvrK=qbynAlwuUtXQSJEDjROdLgpYPifvKm
  try:
   qbynAlwuUtXQSJEDjROdLgpYPifvCo=qbynAlwuUtXQSJEDjROdLgpYPifvCF.API_DOMAIN+'/guid/issue'
   qbynAlwuUtXQSJEDjROdLgpYPifvCm=qbynAlwuUtXQSJEDjROdLgpYPifvCF.GetDefaultParams()
   qbynAlwuUtXQSJEDjROdLgpYPifvrF=qbynAlwuUtXQSJEDjROdLgpYPifvCF.callRequestCookies('Get',qbynAlwuUtXQSJEDjROdLgpYPifvCo,payload=qbynAlwuUtXQSJEDjROdLgpYPifvKc,params=qbynAlwuUtXQSJEDjROdLgpYPifvCm,headers=qbynAlwuUtXQSJEDjROdLgpYPifvKc,cookies=qbynAlwuUtXQSJEDjROdLgpYPifvKc)
   qbynAlwuUtXQSJEDjROdLgpYPifvrW=json.loads(qbynAlwuUtXQSJEDjROdLgpYPifvrF.text)
   qbynAlwuUtXQSJEDjROdLgpYPifvrx=qbynAlwuUtXQSJEDjROdLgpYPifvrW['guid']
   qbynAlwuUtXQSJEDjROdLgpYPifvre=qbynAlwuUtXQSJEDjROdLgpYPifvrW['guidtimestamp']
   if qbynAlwuUtXQSJEDjROdLgpYPifvrx:qbynAlwuUtXQSJEDjROdLgpYPifvrK=qbynAlwuUtXQSJEDjROdLgpYPifvKz
  except qbynAlwuUtXQSJEDjROdLgpYPifvKI as exception:
   qbynAlwuUtXQSJEDjROdLgpYPifvKk(exception)
   qbynAlwuUtXQSJEDjROdLgpYPifvrx='none'
   qbynAlwuUtXQSJEDjROdLgpYPifvre='none' 
  qbynAlwuUtXQSJEDjROdLgpYPifvCF.guid=qbynAlwuUtXQSJEDjROdLgpYPifvrx
  qbynAlwuUtXQSJEDjROdLgpYPifvCF.guidtimestamp=qbynAlwuUtXQSJEDjROdLgpYPifvre
  return qbynAlwuUtXQSJEDjROdLgpYPifvrK
 def Baseapi_Parse(qbynAlwuUtXQSJEDjROdLgpYPifvCF,qbynAlwuUtXQSJEDjROdLgpYPifvrm):
  try:
   qbynAlwuUtXQSJEDjROdLgpYPifvrN =urllib.parse.urlsplit(qbynAlwuUtXQSJEDjROdLgpYPifvrm)
   if qbynAlwuUtXQSJEDjROdLgpYPifvrN.netloc=='':
    qbynAlwuUtXQSJEDjROdLgpYPifvCo=qbynAlwuUtXQSJEDjROdLgpYPifvCF.HTTPTAG+qbynAlwuUtXQSJEDjROdLgpYPifvrN.netloc+qbynAlwuUtXQSJEDjROdLgpYPifvrN.path
   else:
    qbynAlwuUtXQSJEDjROdLgpYPifvCo=qbynAlwuUtXQSJEDjROdLgpYPifvrN.scheme+'://'+qbynAlwuUtXQSJEDjROdLgpYPifvrN.netloc+qbynAlwuUtXQSJEDjROdLgpYPifvrN.path
   qbynAlwuUtXQSJEDjROdLgpYPifvCm=qbynAlwuUtXQSJEDjROdLgpYPifvKa(urllib.parse.parse_qsl(qbynAlwuUtXQSJEDjROdLgpYPifvrN.query))
  except qbynAlwuUtXQSJEDjROdLgpYPifvKI as exception:
   qbynAlwuUtXQSJEDjROdLgpYPifvKk(exception)
   return '',{}
  return qbynAlwuUtXQSJEDjROdLgpYPifvCo,qbynAlwuUtXQSJEDjROdLgpYPifvCm
 def GetSupermultiUrl(qbynAlwuUtXQSJEDjROdLgpYPifvCF,sCode,sIndex='0'):
  try:
   qbynAlwuUtXQSJEDjROdLgpYPifvCo=qbynAlwuUtXQSJEDjROdLgpYPifvCF.API_DOMAIN+'/cf/supermultisections/'+sCode
   qbynAlwuUtXQSJEDjROdLgpYPifvCm=qbynAlwuUtXQSJEDjROdLgpYPifvCF.GetDefaultParams(login=qbynAlwuUtXQSJEDjROdLgpYPifvKm)
   qbynAlwuUtXQSJEDjROdLgpYPifvrF=qbynAlwuUtXQSJEDjROdLgpYPifvCF.callRequestCookies('Get',qbynAlwuUtXQSJEDjROdLgpYPifvCo,payload=qbynAlwuUtXQSJEDjROdLgpYPifvKc,params=qbynAlwuUtXQSJEDjROdLgpYPifvCm,headers=qbynAlwuUtXQSJEDjROdLgpYPifvKc,cookies=qbynAlwuUtXQSJEDjROdLgpYPifvKc)
   qbynAlwuUtXQSJEDjROdLgpYPifvrW=json.loads(qbynAlwuUtXQSJEDjROdLgpYPifvrF.text)
   qbynAlwuUtXQSJEDjROdLgpYPifvrG=qbynAlwuUtXQSJEDjROdLgpYPifvrW['multisectionlist'][qbynAlwuUtXQSJEDjROdLgpYPifvKT(sIndex)]['eventlist'][1]['url']
  except qbynAlwuUtXQSJEDjROdLgpYPifvKI as exception:
   qbynAlwuUtXQSJEDjROdLgpYPifvKk(exception)
   return ''
  return qbynAlwuUtXQSJEDjROdLgpYPifvrG
 def Get_LiveCatagory_List(qbynAlwuUtXQSJEDjROdLgpYPifvCF,sCode,sIndex='0'):
  qbynAlwuUtXQSJEDjROdLgpYPifvrc=[]
  qbynAlwuUtXQSJEDjROdLgpYPifvrm =qbynAlwuUtXQSJEDjROdLgpYPifvCF.GetSupermultiUrl(sCode,sIndex)
  (qbynAlwuUtXQSJEDjROdLgpYPifvCo,qbynAlwuUtXQSJEDjROdLgpYPifvCm)=qbynAlwuUtXQSJEDjROdLgpYPifvCF.Baseapi_Parse(qbynAlwuUtXQSJEDjROdLgpYPifvrm)
  if qbynAlwuUtXQSJEDjROdLgpYPifvCo=='':return qbynAlwuUtXQSJEDjROdLgpYPifvrc,''
  try:
   qbynAlwuUtXQSJEDjROdLgpYPifvCm.update(qbynAlwuUtXQSJEDjROdLgpYPifvCF.GetDefaultParams(login=qbynAlwuUtXQSJEDjROdLgpYPifvKm))
   qbynAlwuUtXQSJEDjROdLgpYPifvrF=qbynAlwuUtXQSJEDjROdLgpYPifvCF.callRequestCookies('Get',qbynAlwuUtXQSJEDjROdLgpYPifvCo,payload=qbynAlwuUtXQSJEDjROdLgpYPifvKc,params=qbynAlwuUtXQSJEDjROdLgpYPifvCm,headers=qbynAlwuUtXQSJEDjROdLgpYPifvKc,cookies=qbynAlwuUtXQSJEDjROdLgpYPifvKc)
   qbynAlwuUtXQSJEDjROdLgpYPifvrW=json.loads(qbynAlwuUtXQSJEDjROdLgpYPifvrF.text)
   if not('filter_item_list' in qbynAlwuUtXQSJEDjROdLgpYPifvrW['filter']['filterlist'][0]):return[],''
   qbynAlwuUtXQSJEDjROdLgpYPifvrz=qbynAlwuUtXQSJEDjROdLgpYPifvrW['filter']['filterlist'][0]['filter_item_list']
   for qbynAlwuUtXQSJEDjROdLgpYPifvrh in qbynAlwuUtXQSJEDjROdLgpYPifvrz:
    qbynAlwuUtXQSJEDjROdLgpYPifvrV={'title':qbynAlwuUtXQSJEDjROdLgpYPifvrh['title'],'genre':qbynAlwuUtXQSJEDjROdLgpYPifvrh['api_parameters'][qbynAlwuUtXQSJEDjROdLgpYPifvrh['api_parameters'].index('=')+1:]}
    qbynAlwuUtXQSJEDjROdLgpYPifvrc.append(qbynAlwuUtXQSJEDjROdLgpYPifvrV)
  except qbynAlwuUtXQSJEDjROdLgpYPifvKI as exception:
   qbynAlwuUtXQSJEDjROdLgpYPifvKk(exception)
   return[],''
  return qbynAlwuUtXQSJEDjROdLgpYPifvrc,qbynAlwuUtXQSJEDjROdLgpYPifvrm
 def Get_MainCatagory_List(qbynAlwuUtXQSJEDjROdLgpYPifvCF,sCode,sIndex,sType):
  qbynAlwuUtXQSJEDjROdLgpYPifvrc=[]
  qbynAlwuUtXQSJEDjROdLgpYPifvCo='https://apis.wavve.com/es/category/launcher-band'
  qbynAlwuUtXQSJEDjROdLgpYPifvCm={'uitype':sCode,'uiparent':'GN52-'+sCode,'uirank':sIndex,'broadcastid':sCode,'offset':'0','limit':'20','uicode':sCode,'mtype':'N','ctype':sType,'orderby':'default',}
  try:
   qbynAlwuUtXQSJEDjROdLgpYPifvCm.update(qbynAlwuUtXQSJEDjROdLgpYPifvCF.GetDefaultParams(login=qbynAlwuUtXQSJEDjROdLgpYPifvKm))
   qbynAlwuUtXQSJEDjROdLgpYPifvrF=qbynAlwuUtXQSJEDjROdLgpYPifvCF.callRequestCookies('Get',qbynAlwuUtXQSJEDjROdLgpYPifvCo,payload=qbynAlwuUtXQSJEDjROdLgpYPifvKc,params=qbynAlwuUtXQSJEDjROdLgpYPifvCm,headers=qbynAlwuUtXQSJEDjROdLgpYPifvKc,cookies=qbynAlwuUtXQSJEDjROdLgpYPifvKc)
   qbynAlwuUtXQSJEDjROdLgpYPifvrW=json.loads(qbynAlwuUtXQSJEDjROdLgpYPifvrF.text)
   if not('celllist' in qbynAlwuUtXQSJEDjROdLgpYPifvrW['band']):return[]
   qbynAlwuUtXQSJEDjROdLgpYPifvrz=qbynAlwuUtXQSJEDjROdLgpYPifvrW['band']['celllist']
   for qbynAlwuUtXQSJEDjROdLgpYPifvrh in qbynAlwuUtXQSJEDjROdLgpYPifvrz:
    qbynAlwuUtXQSJEDjROdLgpYPifvrI =qbynAlwuUtXQSJEDjROdLgpYPifvrh['event_list'][1]['url']
    (qbynAlwuUtXQSJEDjROdLgpYPifvrk,qbynAlwuUtXQSJEDjROdLgpYPifvra)=qbynAlwuUtXQSJEDjROdLgpYPifvCF.Baseapi_Parse(qbynAlwuUtXQSJEDjROdLgpYPifvrI)
    qbynAlwuUtXQSJEDjROdLgpYPifvrV={'title':qbynAlwuUtXQSJEDjROdLgpYPifvrh['title_list'][0]['text'],'suburl':qbynAlwuUtXQSJEDjROdLgpYPifvrk,'subapi':qbynAlwuUtXQSJEDjROdLgpYPifvra.get('api'),'subtype':'catagory' if qbynAlwuUtXQSJEDjROdLgpYPifvra else 'supersection'}
    qbynAlwuUtXQSJEDjROdLgpYPifvrc.append(qbynAlwuUtXQSJEDjROdLgpYPifvrV)
  except qbynAlwuUtXQSJEDjROdLgpYPifvKI as exception:
   qbynAlwuUtXQSJEDjROdLgpYPifvKk(exception)
   return[]
  return qbynAlwuUtXQSJEDjROdLgpYPifvrc
 def Get_SuperMultiSection_List(qbynAlwuUtXQSJEDjROdLgpYPifvCF,subapi_text):
  qbynAlwuUtXQSJEDjROdLgpYPifvrc=[]
  if '/multiband/' in subapi_text: 
   qbynAlwuUtXQSJEDjROdLgpYPifvCo=subapi_text 
   qbynAlwuUtXQSJEDjROdLgpYPifvCm={'client':'40'}
  else:
   qbynAlwuUtXQSJEDjROdLgpYPifvCo=subapi_text 
   qbynAlwuUtXQSJEDjROdLgpYPifvCo=qbynAlwuUtXQSJEDjROdLgpYPifvCo.replace('www.wavve.com','apis.wavve.com').replace('supermultisection','v1/multiband')
   qbynAlwuUtXQSJEDjROdLgpYPifvCm={}
  try:
   qbynAlwuUtXQSJEDjROdLgpYPifvCm.update(qbynAlwuUtXQSJEDjROdLgpYPifvCF.GetDefaultParams(login=qbynAlwuUtXQSJEDjROdLgpYPifvKm))
   qbynAlwuUtXQSJEDjROdLgpYPifvrF=qbynAlwuUtXQSJEDjROdLgpYPifvCF.callRequestCookies('Get',qbynAlwuUtXQSJEDjROdLgpYPifvCo,payload=qbynAlwuUtXQSJEDjROdLgpYPifvKc,params=qbynAlwuUtXQSJEDjROdLgpYPifvCm,headers=qbynAlwuUtXQSJEDjROdLgpYPifvKc,cookies=qbynAlwuUtXQSJEDjROdLgpYPifvKc)
   qbynAlwuUtXQSJEDjROdLgpYPifvrW=json.loads(qbynAlwuUtXQSJEDjROdLgpYPifvrF.text)
   if not('multisectionlist' in qbynAlwuUtXQSJEDjROdLgpYPifvrW):return[]
   qbynAlwuUtXQSJEDjROdLgpYPifvrz=qbynAlwuUtXQSJEDjROdLgpYPifvrW['multisectionlist']
   for qbynAlwuUtXQSJEDjROdLgpYPifvrh in qbynAlwuUtXQSJEDjROdLgpYPifvrz:
    qbynAlwuUtXQSJEDjROdLgpYPifvrT=qbynAlwuUtXQSJEDjROdLgpYPifvrh['title']
    if qbynAlwuUtXQSJEDjROdLgpYPifvKB(qbynAlwuUtXQSJEDjROdLgpYPifvrT)==0:continue
    if qbynAlwuUtXQSJEDjROdLgpYPifvrT=='minor':continue
    if re.search(u'베너',qbynAlwuUtXQSJEDjROdLgpYPifvrT):continue
    if re.search(u'배너',qbynAlwuUtXQSJEDjROdLgpYPifvrT):continue 
    if qbynAlwuUtXQSJEDjROdLgpYPifvrh['force_refresh']=='y':continue
    if qbynAlwuUtXQSJEDjROdLgpYPifvKB(qbynAlwuUtXQSJEDjROdLgpYPifvrh['eventlist'])>=3:
     qbynAlwuUtXQSJEDjROdLgpYPifvra =qbynAlwuUtXQSJEDjROdLgpYPifvrh['eventlist'][2]['url']
    else:
     qbynAlwuUtXQSJEDjROdLgpYPifvra =qbynAlwuUtXQSJEDjROdLgpYPifvrh['eventlist'][1]['url']
    qbynAlwuUtXQSJEDjROdLgpYPifvrB=qbynAlwuUtXQSJEDjROdLgpYPifvrh['cell_type']
    if qbynAlwuUtXQSJEDjROdLgpYPifvrB=='band_2':
     if qbynAlwuUtXQSJEDjROdLgpYPifvra.find('channellist=')>=0:
      qbynAlwuUtXQSJEDjROdLgpYPifvrB='band_live'
    qbynAlwuUtXQSJEDjROdLgpYPifvrV={'title':qbynAlwuUtXQSJEDjROdLgpYPifvCF.Get_ChangeText(qbynAlwuUtXQSJEDjROdLgpYPifvrT),'subapi':qbynAlwuUtXQSJEDjROdLgpYPifvra,'cell_type':qbynAlwuUtXQSJEDjROdLgpYPifvrB}
    qbynAlwuUtXQSJEDjROdLgpYPifvrc.append(qbynAlwuUtXQSJEDjROdLgpYPifvrV)
  except qbynAlwuUtXQSJEDjROdLgpYPifvKI as exception:
   qbynAlwuUtXQSJEDjROdLgpYPifvKk(exception)
   return[]
  return qbynAlwuUtXQSJEDjROdLgpYPifvrc
 def Get_BandLiveSection_List(qbynAlwuUtXQSJEDjROdLgpYPifvCF,qbynAlwuUtXQSJEDjROdLgpYPifvrm,page_int=1):
  qbynAlwuUtXQSJEDjROdLgpYPifvrM=[]
  qbynAlwuUtXQSJEDjROdLgpYPifvro=qbynAlwuUtXQSJEDjROdLgpYPifvFx=1
  qbynAlwuUtXQSJEDjROdLgpYPifvFC=qbynAlwuUtXQSJEDjROdLgpYPifvKm
  try:
   (qbynAlwuUtXQSJEDjROdLgpYPifvCo,qbynAlwuUtXQSJEDjROdLgpYPifvCm)=qbynAlwuUtXQSJEDjROdLgpYPifvCF.Baseapi_Parse(qbynAlwuUtXQSJEDjROdLgpYPifvrm)
  except qbynAlwuUtXQSJEDjROdLgpYPifvKI as exception:
   qbynAlwuUtXQSJEDjROdLgpYPifvKk(exception)
   return[],qbynAlwuUtXQSJEDjROdLgpYPifvKm
  try:
   qbynAlwuUtXQSJEDjROdLgpYPifvCm['limit']=qbynAlwuUtXQSJEDjROdLgpYPifvCF.LIST_LIMIT
   qbynAlwuUtXQSJEDjROdLgpYPifvCm['offset']=qbynAlwuUtXQSJEDjROdLgpYPifvKV((page_int-1)*qbynAlwuUtXQSJEDjROdLgpYPifvCF.LIST_LIMIT)
   qbynAlwuUtXQSJEDjROdLgpYPifvCm.update(qbynAlwuUtXQSJEDjROdLgpYPifvCF.GetDefaultParams(login=qbynAlwuUtXQSJEDjROdLgpYPifvKm))
   qbynAlwuUtXQSJEDjROdLgpYPifvrF=qbynAlwuUtXQSJEDjROdLgpYPifvCF.callRequestCookies('Get',qbynAlwuUtXQSJEDjROdLgpYPifvCo,payload=qbynAlwuUtXQSJEDjROdLgpYPifvKc,params=qbynAlwuUtXQSJEDjROdLgpYPifvCm,headers=qbynAlwuUtXQSJEDjROdLgpYPifvKc,cookies=qbynAlwuUtXQSJEDjROdLgpYPifvKc)
   qbynAlwuUtXQSJEDjROdLgpYPifvrW=json.loads(qbynAlwuUtXQSJEDjROdLgpYPifvrF.text)
   if not('celllist' in qbynAlwuUtXQSJEDjROdLgpYPifvrW['cell_toplist']):return[],qbynAlwuUtXQSJEDjROdLgpYPifvKm
   qbynAlwuUtXQSJEDjROdLgpYPifvrz=qbynAlwuUtXQSJEDjROdLgpYPifvrW['cell_toplist']['celllist']
   for qbynAlwuUtXQSJEDjROdLgpYPifvrh in qbynAlwuUtXQSJEDjROdLgpYPifvrz:
    qbynAlwuUtXQSJEDjROdLgpYPifvFr =qbynAlwuUtXQSJEDjROdLgpYPifvrh['event_list'][1]['url']
    qbynAlwuUtXQSJEDjROdLgpYPifvFW=urllib.parse.urlsplit(qbynAlwuUtXQSJEDjROdLgpYPifvFr).query
    qbynAlwuUtXQSJEDjROdLgpYPifvFW=qbynAlwuUtXQSJEDjROdLgpYPifvKa(urllib.parse.parse_qsl(qbynAlwuUtXQSJEDjROdLgpYPifvFW))
    qbynAlwuUtXQSJEDjROdLgpYPifvFH='channelid'
    qbynAlwuUtXQSJEDjROdLgpYPifvFK=qbynAlwuUtXQSJEDjROdLgpYPifvFW[qbynAlwuUtXQSJEDjROdLgpYPifvFH]
    qbynAlwuUtXQSJEDjROdLgpYPifvrV={'studio':qbynAlwuUtXQSJEDjROdLgpYPifvrh['title_list'][0]['text'],'tvshowtitle':qbynAlwuUtXQSJEDjROdLgpYPifvCF.Get_ChangeText(qbynAlwuUtXQSJEDjROdLgpYPifvrh['title_list'][1]['text']),'channelid':qbynAlwuUtXQSJEDjROdLgpYPifvFK,'age':qbynAlwuUtXQSJEDjROdLgpYPifvrh.get('age'),'thumbnail':'https://%s'%qbynAlwuUtXQSJEDjROdLgpYPifvrh.get('thumbnail')}
    qbynAlwuUtXQSJEDjROdLgpYPifvrM.append(qbynAlwuUtXQSJEDjROdLgpYPifvrV)
   qbynAlwuUtXQSJEDjROdLgpYPifvro=qbynAlwuUtXQSJEDjROdLgpYPifvKT(qbynAlwuUtXQSJEDjROdLgpYPifvrW['cell_toplist']['pagecount'])
   if qbynAlwuUtXQSJEDjROdLgpYPifvrW['cell_toplist']['count']:qbynAlwuUtXQSJEDjROdLgpYPifvFx =qbynAlwuUtXQSJEDjROdLgpYPifvKT(qbynAlwuUtXQSJEDjROdLgpYPifvrW['cell_toplist']['count'])
   else:qbynAlwuUtXQSJEDjROdLgpYPifvFx=qbynAlwuUtXQSJEDjROdLgpYPifvCF.LIST_LIMIT*page_int
   qbynAlwuUtXQSJEDjROdLgpYPifvFC=qbynAlwuUtXQSJEDjROdLgpYPifvro>qbynAlwuUtXQSJEDjROdLgpYPifvFx
  except qbynAlwuUtXQSJEDjROdLgpYPifvKI as exception:
   qbynAlwuUtXQSJEDjROdLgpYPifvKk(exception)
   return[],qbynAlwuUtXQSJEDjROdLgpYPifvKm
  return qbynAlwuUtXQSJEDjROdLgpYPifvrM,qbynAlwuUtXQSJEDjROdLgpYPifvFC
 def Get_Band2Section_List(qbynAlwuUtXQSJEDjROdLgpYPifvCF,qbynAlwuUtXQSJEDjROdLgpYPifvrm,page_int=1):
  qbynAlwuUtXQSJEDjROdLgpYPifvFe=[]
  qbynAlwuUtXQSJEDjROdLgpYPifvro=qbynAlwuUtXQSJEDjROdLgpYPifvFx=1
  qbynAlwuUtXQSJEDjROdLgpYPifvFC=qbynAlwuUtXQSJEDjROdLgpYPifvKm
  try:
   (qbynAlwuUtXQSJEDjROdLgpYPifvCo,qbynAlwuUtXQSJEDjROdLgpYPifvCm)=qbynAlwuUtXQSJEDjROdLgpYPifvCF.Baseapi_Parse(qbynAlwuUtXQSJEDjROdLgpYPifvrm)
  except qbynAlwuUtXQSJEDjROdLgpYPifvKI as exception:
   qbynAlwuUtXQSJEDjROdLgpYPifvKk(exception)
   return[],qbynAlwuUtXQSJEDjROdLgpYPifvKm
  try:
   qbynAlwuUtXQSJEDjROdLgpYPifvCm['came'] ='BandView'
   qbynAlwuUtXQSJEDjROdLgpYPifvCm['limit']=qbynAlwuUtXQSJEDjROdLgpYPifvCF.LIST_LIMIT
   qbynAlwuUtXQSJEDjROdLgpYPifvCm['offset']=qbynAlwuUtXQSJEDjROdLgpYPifvKV((page_int-1)*qbynAlwuUtXQSJEDjROdLgpYPifvCF.LIST_LIMIT)
   qbynAlwuUtXQSJEDjROdLgpYPifvCm.update(qbynAlwuUtXQSJEDjROdLgpYPifvCF.GetDefaultParams(login=qbynAlwuUtXQSJEDjROdLgpYPifvKm))
   qbynAlwuUtXQSJEDjROdLgpYPifvrF=qbynAlwuUtXQSJEDjROdLgpYPifvCF.callRequestCookies('Get',qbynAlwuUtXQSJEDjROdLgpYPifvCo,payload=qbynAlwuUtXQSJEDjROdLgpYPifvKc,params=qbynAlwuUtXQSJEDjROdLgpYPifvCm,headers=qbynAlwuUtXQSJEDjROdLgpYPifvKc,cookies=qbynAlwuUtXQSJEDjROdLgpYPifvKc)
   qbynAlwuUtXQSJEDjROdLgpYPifvrW=json.loads(qbynAlwuUtXQSJEDjROdLgpYPifvrF.text)
   if not('celllist' in qbynAlwuUtXQSJEDjROdLgpYPifvrW['cell_toplist']):return[],qbynAlwuUtXQSJEDjROdLgpYPifvKm
   qbynAlwuUtXQSJEDjROdLgpYPifvrz=qbynAlwuUtXQSJEDjROdLgpYPifvrW['cell_toplist']['celllist']
   for qbynAlwuUtXQSJEDjROdLgpYPifvrh in qbynAlwuUtXQSJEDjROdLgpYPifvrz:
    qbynAlwuUtXQSJEDjROdLgpYPifvFr =qbynAlwuUtXQSJEDjROdLgpYPifvrh['event_list'][1]['url']
    qbynAlwuUtXQSJEDjROdLgpYPifvFW=urllib.parse.urlsplit(qbynAlwuUtXQSJEDjROdLgpYPifvFr).query
    qbynAlwuUtXQSJEDjROdLgpYPifvFW=qbynAlwuUtXQSJEDjROdLgpYPifvKa(urllib.parse.parse_qsl(qbynAlwuUtXQSJEDjROdLgpYPifvFW))
    qbynAlwuUtXQSJEDjROdLgpYPifvFH='contentid'
    qbynAlwuUtXQSJEDjROdLgpYPifvFK=qbynAlwuUtXQSJEDjROdLgpYPifvFW[qbynAlwuUtXQSJEDjROdLgpYPifvFH]
    qbynAlwuUtXQSJEDjROdLgpYPifvrV={'programtitle':qbynAlwuUtXQSJEDjROdLgpYPifvrh['title_list'][0]['text'],'episodetitle':qbynAlwuUtXQSJEDjROdLgpYPifvCF.Get_ChangeText(qbynAlwuUtXQSJEDjROdLgpYPifvrh['title_list'][1]['text']),'age':qbynAlwuUtXQSJEDjROdLgpYPifvrh.get('age'),'thumbnail':qbynAlwuUtXQSJEDjROdLgpYPifvCF.HTTPTAG+qbynAlwuUtXQSJEDjROdLgpYPifvrh.get('thumbnail'),'vidtype':qbynAlwuUtXQSJEDjROdLgpYPifvFH,'videoid':qbynAlwuUtXQSJEDjROdLgpYPifvFK}
    qbynAlwuUtXQSJEDjROdLgpYPifvFe.append(qbynAlwuUtXQSJEDjROdLgpYPifvrV)
   qbynAlwuUtXQSJEDjROdLgpYPifvro=qbynAlwuUtXQSJEDjROdLgpYPifvKT(qbynAlwuUtXQSJEDjROdLgpYPifvrW['cell_toplist']['pagecount'])
   if qbynAlwuUtXQSJEDjROdLgpYPifvrW['cell_toplist']['count']:qbynAlwuUtXQSJEDjROdLgpYPifvFx =qbynAlwuUtXQSJEDjROdLgpYPifvKT(qbynAlwuUtXQSJEDjROdLgpYPifvrW['cell_toplist']['count'])
   else:qbynAlwuUtXQSJEDjROdLgpYPifvFx=qbynAlwuUtXQSJEDjROdLgpYPifvCF.LIST_LIMIT*page_int
   qbynAlwuUtXQSJEDjROdLgpYPifvFC=qbynAlwuUtXQSJEDjROdLgpYPifvro>qbynAlwuUtXQSJEDjROdLgpYPifvFx
  except qbynAlwuUtXQSJEDjROdLgpYPifvKI as exception:
   qbynAlwuUtXQSJEDjROdLgpYPifvKk(exception)
   return[],qbynAlwuUtXQSJEDjROdLgpYPifvKm
  return qbynAlwuUtXQSJEDjROdLgpYPifvFe,qbynAlwuUtXQSJEDjROdLgpYPifvFC
 def Get_Program_List(qbynAlwuUtXQSJEDjROdLgpYPifvCF,qbynAlwuUtXQSJEDjROdLgpYPifvrm,page_int=1,orderby='-'):
  qbynAlwuUtXQSJEDjROdLgpYPifvFN=[]
  qbynAlwuUtXQSJEDjROdLgpYPifvro=qbynAlwuUtXQSJEDjROdLgpYPifvFx=1
  qbynAlwuUtXQSJEDjROdLgpYPifvFC=qbynAlwuUtXQSJEDjROdLgpYPifvKm
  (qbynAlwuUtXQSJEDjROdLgpYPifvCo,qbynAlwuUtXQSJEDjROdLgpYPifvCm)=qbynAlwuUtXQSJEDjROdLgpYPifvCF.Baseapi_Parse(qbynAlwuUtXQSJEDjROdLgpYPifvrm)
  if qbynAlwuUtXQSJEDjROdLgpYPifvCo=='':return qbynAlwuUtXQSJEDjROdLgpYPifvFN,qbynAlwuUtXQSJEDjROdLgpYPifvFC
  try:
   qbynAlwuUtXQSJEDjROdLgpYPifvCm['limit'] =qbynAlwuUtXQSJEDjROdLgpYPifvCF.LIST_LIMIT
   qbynAlwuUtXQSJEDjROdLgpYPifvCm['offset']=qbynAlwuUtXQSJEDjROdLgpYPifvKV((page_int-1)*qbynAlwuUtXQSJEDjROdLgpYPifvCF.LIST_LIMIT)
   qbynAlwuUtXQSJEDjROdLgpYPifvCm['page'] =qbynAlwuUtXQSJEDjROdLgpYPifvKV(page_int)
   if qbynAlwuUtXQSJEDjROdLgpYPifvCm.get('orderby')!='' and qbynAlwuUtXQSJEDjROdLgpYPifvCm.get('orderby')!='regdatefirst' and orderby!='-':
    qbynAlwuUtXQSJEDjROdLgpYPifvCm['orderby']=orderby 
   qbynAlwuUtXQSJEDjROdLgpYPifvCm.update(qbynAlwuUtXQSJEDjROdLgpYPifvCF.GetDefaultParams(login=qbynAlwuUtXQSJEDjROdLgpYPifvKm))
   qbynAlwuUtXQSJEDjROdLgpYPifvrF=qbynAlwuUtXQSJEDjROdLgpYPifvCF.callRequestCookies('Get',qbynAlwuUtXQSJEDjROdLgpYPifvCo,payload=qbynAlwuUtXQSJEDjROdLgpYPifvKc,params=qbynAlwuUtXQSJEDjROdLgpYPifvCm,headers=qbynAlwuUtXQSJEDjROdLgpYPifvKc,cookies=qbynAlwuUtXQSJEDjROdLgpYPifvKc)
   qbynAlwuUtXQSJEDjROdLgpYPifvrW=json.loads(qbynAlwuUtXQSJEDjROdLgpYPifvrF.text)
   if qbynAlwuUtXQSJEDjROdLgpYPifvrW.get('cell_toplist')not in[{},qbynAlwuUtXQSJEDjROdLgpYPifvKc,'']:
    qbynAlwuUtXQSJEDjROdLgpYPifvrz=qbynAlwuUtXQSJEDjROdLgpYPifvrW['cell_toplist']['celllist']
   elif qbynAlwuUtXQSJEDjROdLgpYPifvrW.get('band')not in[{},qbynAlwuUtXQSJEDjROdLgpYPifvKc,'']:
    qbynAlwuUtXQSJEDjROdLgpYPifvrz=qbynAlwuUtXQSJEDjROdLgpYPifvrW['band']['celllist']
   else:
    return qbynAlwuUtXQSJEDjROdLgpYPifvFN,qbynAlwuUtXQSJEDjROdLgpYPifvFC
   for qbynAlwuUtXQSJEDjROdLgpYPifvrh in qbynAlwuUtXQSJEDjROdLgpYPifvrz:
    for qbynAlwuUtXQSJEDjROdLgpYPifvFG in qbynAlwuUtXQSJEDjROdLgpYPifvrh['event_list']:
     if qbynAlwuUtXQSJEDjROdLgpYPifvFG.get('type')=='on-navigation':
      qbynAlwuUtXQSJEDjROdLgpYPifvFr =qbynAlwuUtXQSJEDjROdLgpYPifvFG['url']
    qbynAlwuUtXQSJEDjROdLgpYPifvFW=urllib.parse.urlsplit(qbynAlwuUtXQSJEDjROdLgpYPifvFr).query
    qbynAlwuUtXQSJEDjROdLgpYPifvFH=qbynAlwuUtXQSJEDjROdLgpYPifvFW[0:qbynAlwuUtXQSJEDjROdLgpYPifvFW.find('=')]
    qbynAlwuUtXQSJEDjROdLgpYPifvFc=qbynAlwuUtXQSJEDjROdLgpYPifvKa(urllib.parse.parse_qsl(qbynAlwuUtXQSJEDjROdLgpYPifvFW))
    qbynAlwuUtXQSJEDjROdLgpYPifvFK=qbynAlwuUtXQSJEDjROdLgpYPifvFc.get(qbynAlwuUtXQSJEDjROdLgpYPifvFH)
    qbynAlwuUtXQSJEDjROdLgpYPifvrV={'title':qbynAlwuUtXQSJEDjROdLgpYPifvrh.get('alt')or qbynAlwuUtXQSJEDjROdLgpYPifvrh.get('title_list')[0].get('text'),'age':qbynAlwuUtXQSJEDjROdLgpYPifvrh.get('age'),'thumbnail':qbynAlwuUtXQSJEDjROdLgpYPifvrh.get('thumbnail'),'videoid':qbynAlwuUtXQSJEDjROdLgpYPifvFK,'vidtype':qbynAlwuUtXQSJEDjROdLgpYPifvFH,}
    if not qbynAlwuUtXQSJEDjROdLgpYPifvrV.get('thumbnail').startswith('http'):
     qbynAlwuUtXQSJEDjROdLgpYPifvrV['thumbnail']='https://%s'%qbynAlwuUtXQSJEDjROdLgpYPifvrV['thumbnail']
    qbynAlwuUtXQSJEDjROdLgpYPifvFN.append(qbynAlwuUtXQSJEDjROdLgpYPifvrV)
   if qbynAlwuUtXQSJEDjROdLgpYPifvrW.get('cell_toplist')not in[{},qbynAlwuUtXQSJEDjROdLgpYPifvKc,'']:
    qbynAlwuUtXQSJEDjROdLgpYPifvro=qbynAlwuUtXQSJEDjROdLgpYPifvKT(qbynAlwuUtXQSJEDjROdLgpYPifvrW['cell_toplist']['pagecount'])
    if qbynAlwuUtXQSJEDjROdLgpYPifvrW['cell_toplist']['count']:qbynAlwuUtXQSJEDjROdLgpYPifvFx =qbynAlwuUtXQSJEDjROdLgpYPifvKT(qbynAlwuUtXQSJEDjROdLgpYPifvrW['cell_toplist']['count'])
    else:qbynAlwuUtXQSJEDjROdLgpYPifvFx=qbynAlwuUtXQSJEDjROdLgpYPifvCF.LIST_LIMIT*page_int
    qbynAlwuUtXQSJEDjROdLgpYPifvFC=qbynAlwuUtXQSJEDjROdLgpYPifvro>qbynAlwuUtXQSJEDjROdLgpYPifvFx
  except qbynAlwuUtXQSJEDjROdLgpYPifvKI as exception:
   qbynAlwuUtXQSJEDjROdLgpYPifvKk(exception)
   return[],qbynAlwuUtXQSJEDjROdLgpYPifvKm
  return qbynAlwuUtXQSJEDjROdLgpYPifvFN,qbynAlwuUtXQSJEDjROdLgpYPifvFC
 def Get_Movie_List(qbynAlwuUtXQSJEDjROdLgpYPifvCF,qbynAlwuUtXQSJEDjROdLgpYPifvrm,page_int=1,orderby='-'):
  qbynAlwuUtXQSJEDjROdLgpYPifvFm=[]
  qbynAlwuUtXQSJEDjROdLgpYPifvro=qbynAlwuUtXQSJEDjROdLgpYPifvFx=1
  qbynAlwuUtXQSJEDjROdLgpYPifvFC=qbynAlwuUtXQSJEDjROdLgpYPifvKm
  (qbynAlwuUtXQSJEDjROdLgpYPifvCo,qbynAlwuUtXQSJEDjROdLgpYPifvCm)=qbynAlwuUtXQSJEDjROdLgpYPifvCF.Baseapi_Parse(qbynAlwuUtXQSJEDjROdLgpYPifvrm)
  if qbynAlwuUtXQSJEDjROdLgpYPifvCo=='':return qbynAlwuUtXQSJEDjROdLgpYPifvFm,qbynAlwuUtXQSJEDjROdLgpYPifvFC
  try:
   qbynAlwuUtXQSJEDjROdLgpYPifvCm['limit']=qbynAlwuUtXQSJEDjROdLgpYPifvCF.MV_LIMIT
   qbynAlwuUtXQSJEDjROdLgpYPifvCm['offset']=qbynAlwuUtXQSJEDjROdLgpYPifvKV((page_int-1)*qbynAlwuUtXQSJEDjROdLgpYPifvCF.MV_LIMIT)
   if qbynAlwuUtXQSJEDjROdLgpYPifvCm.get('orderby')!='' and qbynAlwuUtXQSJEDjROdLgpYPifvCm.get('orderby')!='regdatefirst' and orderby!='-':
    qbynAlwuUtXQSJEDjROdLgpYPifvCm['orderby']=orderby 
   qbynAlwuUtXQSJEDjROdLgpYPifvCm.update(qbynAlwuUtXQSJEDjROdLgpYPifvCF.GetDefaultParams(login=qbynAlwuUtXQSJEDjROdLgpYPifvKm))
   qbynAlwuUtXQSJEDjROdLgpYPifvrF=qbynAlwuUtXQSJEDjROdLgpYPifvCF.callRequestCookies('Get',qbynAlwuUtXQSJEDjROdLgpYPifvCo,payload=qbynAlwuUtXQSJEDjROdLgpYPifvKc,params=qbynAlwuUtXQSJEDjROdLgpYPifvCm,headers=qbynAlwuUtXQSJEDjROdLgpYPifvKc,cookies=qbynAlwuUtXQSJEDjROdLgpYPifvKc)
   qbynAlwuUtXQSJEDjROdLgpYPifvrW=json.loads(qbynAlwuUtXQSJEDjROdLgpYPifvrF.text)
   if qbynAlwuUtXQSJEDjROdLgpYPifvrW.get('cell_toplist')not in[{},qbynAlwuUtXQSJEDjROdLgpYPifvKc,'']:
    qbynAlwuUtXQSJEDjROdLgpYPifvrz=qbynAlwuUtXQSJEDjROdLgpYPifvrW['cell_toplist']['celllist']
   elif qbynAlwuUtXQSJEDjROdLgpYPifvrW.get('band')not in[{},qbynAlwuUtXQSJEDjROdLgpYPifvKc,'']:
    qbynAlwuUtXQSJEDjROdLgpYPifvrz=qbynAlwuUtXQSJEDjROdLgpYPifvrW['band']['celllist']
   else:
    return qbynAlwuUtXQSJEDjROdLgpYPifvFm,qbynAlwuUtXQSJEDjROdLgpYPifvFC
   for qbynAlwuUtXQSJEDjROdLgpYPifvrh in qbynAlwuUtXQSJEDjROdLgpYPifvrz:
    qbynAlwuUtXQSJEDjROdLgpYPifvFr =qbynAlwuUtXQSJEDjROdLgpYPifvrh['event_list'][1]['url']
    qbynAlwuUtXQSJEDjROdLgpYPifvFW=urllib.parse.urlsplit(qbynAlwuUtXQSJEDjROdLgpYPifvFr).query
    qbynAlwuUtXQSJEDjROdLgpYPifvFH=qbynAlwuUtXQSJEDjROdLgpYPifvFW[0:qbynAlwuUtXQSJEDjROdLgpYPifvFW.find('=')]
    qbynAlwuUtXQSJEDjROdLgpYPifvFc=qbynAlwuUtXQSJEDjROdLgpYPifvKa(urllib.parse.parse_qsl(qbynAlwuUtXQSJEDjROdLgpYPifvFW))
    qbynAlwuUtXQSJEDjROdLgpYPifvFK=qbynAlwuUtXQSJEDjROdLgpYPifvFc.get(qbynAlwuUtXQSJEDjROdLgpYPifvFH)
    qbynAlwuUtXQSJEDjROdLgpYPifvrV={'title':qbynAlwuUtXQSJEDjROdLgpYPifvrh.get('alt')or qbynAlwuUtXQSJEDjROdLgpYPifvrh.get('title_list')[0].get('text'),'age':qbynAlwuUtXQSJEDjROdLgpYPifvrh.get('age'),'thumbnail':qbynAlwuUtXQSJEDjROdLgpYPifvrh.get('thumbnail'),'videoid':qbynAlwuUtXQSJEDjROdLgpYPifvFK,'vidtype':qbynAlwuUtXQSJEDjROdLgpYPifvFH,}
    if not qbynAlwuUtXQSJEDjROdLgpYPifvrV.get('thumbnail').startswith('http'):
     qbynAlwuUtXQSJEDjROdLgpYPifvrV['thumbnail']='https://%s'%qbynAlwuUtXQSJEDjROdLgpYPifvrV['thumbnail']
    qbynAlwuUtXQSJEDjROdLgpYPifvFm.append(qbynAlwuUtXQSJEDjROdLgpYPifvrV)
   if qbynAlwuUtXQSJEDjROdLgpYPifvrW.get('cell_toplist')not in[{},qbynAlwuUtXQSJEDjROdLgpYPifvKc,'']:
    qbynAlwuUtXQSJEDjROdLgpYPifvro=qbynAlwuUtXQSJEDjROdLgpYPifvKT(qbynAlwuUtXQSJEDjROdLgpYPifvrW['cell_toplist']['pagecount'])
    if qbynAlwuUtXQSJEDjROdLgpYPifvrW['cell_toplist']['count']:qbynAlwuUtXQSJEDjROdLgpYPifvFx =qbynAlwuUtXQSJEDjROdLgpYPifvKT(qbynAlwuUtXQSJEDjROdLgpYPifvrW['cell_toplist']['count'])
    else:qbynAlwuUtXQSJEDjROdLgpYPifvFx=qbynAlwuUtXQSJEDjROdLgpYPifvCF.MV_LIMIT*page_int
    qbynAlwuUtXQSJEDjROdLgpYPifvFC=qbynAlwuUtXQSJEDjROdLgpYPifvro>qbynAlwuUtXQSJEDjROdLgpYPifvFx
  except qbynAlwuUtXQSJEDjROdLgpYPifvKI as exception:
   qbynAlwuUtXQSJEDjROdLgpYPifvKk(exception)
   return[],qbynAlwuUtXQSJEDjROdLgpYPifvKm
  return qbynAlwuUtXQSJEDjROdLgpYPifvFm,qbynAlwuUtXQSJEDjROdLgpYPifvFC
 def ProgramidToContentid(qbynAlwuUtXQSJEDjROdLgpYPifvCF,qbynAlwuUtXQSJEDjROdLgpYPifvFh):
  qbynAlwuUtXQSJEDjROdLgpYPifvFs=''
  try:
   qbynAlwuUtXQSJEDjROdLgpYPifvCo =qbynAlwuUtXQSJEDjROdLgpYPifvCF.API_DOMAIN+'/vod/programs-contentid/'+qbynAlwuUtXQSJEDjROdLgpYPifvFh
   qbynAlwuUtXQSJEDjROdLgpYPifvCm=qbynAlwuUtXQSJEDjROdLgpYPifvCF.GetDefaultParams(login=qbynAlwuUtXQSJEDjROdLgpYPifvKm)
   qbynAlwuUtXQSJEDjROdLgpYPifvrF=qbynAlwuUtXQSJEDjROdLgpYPifvCF.callRequestCookies('Get',qbynAlwuUtXQSJEDjROdLgpYPifvCo,payload=qbynAlwuUtXQSJEDjROdLgpYPifvKc,params=qbynAlwuUtXQSJEDjROdLgpYPifvCm,headers=qbynAlwuUtXQSJEDjROdLgpYPifvKc,cookies=qbynAlwuUtXQSJEDjROdLgpYPifvKc)
   qbynAlwuUtXQSJEDjROdLgpYPifvFz=json.loads(qbynAlwuUtXQSJEDjROdLgpYPifvrF.text)
   if not('contentid' in qbynAlwuUtXQSJEDjROdLgpYPifvFz):return qbynAlwuUtXQSJEDjROdLgpYPifvFs 
   qbynAlwuUtXQSJEDjROdLgpYPifvFs=qbynAlwuUtXQSJEDjROdLgpYPifvFz['contentid']
  except qbynAlwuUtXQSJEDjROdLgpYPifvKI as exception:
   qbynAlwuUtXQSJEDjROdLgpYPifvKk(exception)
  return qbynAlwuUtXQSJEDjROdLgpYPifvFs
 def ContentidToSeasonid(qbynAlwuUtXQSJEDjROdLgpYPifvCF,qbynAlwuUtXQSJEDjROdLgpYPifvFs):
  qbynAlwuUtXQSJEDjROdLgpYPifvFh=''
  try:
   qbynAlwuUtXQSJEDjROdLgpYPifvCo =qbynAlwuUtXQSJEDjROdLgpYPifvCF.API_DOMAIN+'/fz/vod/contents/'+qbynAlwuUtXQSJEDjROdLgpYPifvFs
   qbynAlwuUtXQSJEDjROdLgpYPifvCm=qbynAlwuUtXQSJEDjROdLgpYPifvCF.GetDefaultParams(login=qbynAlwuUtXQSJEDjROdLgpYPifvKm)
   qbynAlwuUtXQSJEDjROdLgpYPifvrF=qbynAlwuUtXQSJEDjROdLgpYPifvCF.callRequestCookies('Get',qbynAlwuUtXQSJEDjROdLgpYPifvCo,payload=qbynAlwuUtXQSJEDjROdLgpYPifvKc,params=qbynAlwuUtXQSJEDjROdLgpYPifvCm,headers=qbynAlwuUtXQSJEDjROdLgpYPifvKc,cookies=qbynAlwuUtXQSJEDjROdLgpYPifvKc)
   qbynAlwuUtXQSJEDjROdLgpYPifvFz=json.loads(qbynAlwuUtXQSJEDjROdLgpYPifvrF.text)
   if not('programid' in qbynAlwuUtXQSJEDjROdLgpYPifvFz):return qbynAlwuUtXQSJEDjROdLgpYPifvFh 
   qbynAlwuUtXQSJEDjROdLgpYPifvFh=qbynAlwuUtXQSJEDjROdLgpYPifvFz['programid']
  except qbynAlwuUtXQSJEDjROdLgpYPifvKI as exception:
   qbynAlwuUtXQSJEDjROdLgpYPifvKk(exception)
  return qbynAlwuUtXQSJEDjROdLgpYPifvFh
 def GetProgramInfo(qbynAlwuUtXQSJEDjROdLgpYPifvCF,qbynAlwuUtXQSJEDjROdLgpYPifvFs):
  qbynAlwuUtXQSJEDjROdLgpYPifvFV={}
  try:
   qbynAlwuUtXQSJEDjROdLgpYPifvCo=qbynAlwuUtXQSJEDjROdLgpYPifvCF.API_DOMAIN+'/fz/vod/contents/'+qbynAlwuUtXQSJEDjROdLgpYPifvFs
   qbynAlwuUtXQSJEDjROdLgpYPifvCm=qbynAlwuUtXQSJEDjROdLgpYPifvCF.GetDefaultParams(login=qbynAlwuUtXQSJEDjROdLgpYPifvKm)
   qbynAlwuUtXQSJEDjROdLgpYPifvrF=qbynAlwuUtXQSJEDjROdLgpYPifvCF.callRequestCookies('Get',qbynAlwuUtXQSJEDjROdLgpYPifvCo,payload=qbynAlwuUtXQSJEDjROdLgpYPifvKc,params=qbynAlwuUtXQSJEDjROdLgpYPifvCm,headers=qbynAlwuUtXQSJEDjROdLgpYPifvKc,cookies=qbynAlwuUtXQSJEDjROdLgpYPifvKc)
   qbynAlwuUtXQSJEDjROdLgpYPifvFz=json.loads(qbynAlwuUtXQSJEDjROdLgpYPifvrF.text)
   qbynAlwuUtXQSJEDjROdLgpYPifvFI=img_fanart=qbynAlwuUtXQSJEDjROdLgpYPifvFk=''
   if qbynAlwuUtXQSJEDjROdLgpYPifvFz.get('programposterimage')!='':qbynAlwuUtXQSJEDjROdLgpYPifvFI =qbynAlwuUtXQSJEDjROdLgpYPifvCF.HTTPTAG+qbynAlwuUtXQSJEDjROdLgpYPifvFz.get('programposterimage')
   if qbynAlwuUtXQSJEDjROdLgpYPifvFz.get('programimage') !='':img_fanart =qbynAlwuUtXQSJEDjROdLgpYPifvCF.HTTPTAG+qbynAlwuUtXQSJEDjROdLgpYPifvFz.get('programimage')
   if qbynAlwuUtXQSJEDjROdLgpYPifvFz.get('programcircleimage')!='':qbynAlwuUtXQSJEDjROdLgpYPifvFk=qbynAlwuUtXQSJEDjROdLgpYPifvCF.HTTPTAG+qbynAlwuUtXQSJEDjROdLgpYPifvFz.get('programcircleimage')
   if 'poster_default' in qbynAlwuUtXQSJEDjROdLgpYPifvFI:
    qbynAlwuUtXQSJEDjROdLgpYPifvFI =img_fanart
    qbynAlwuUtXQSJEDjROdLgpYPifvFk=''
   qbynAlwuUtXQSJEDjROdLgpYPifvFV={'imgPoster':qbynAlwuUtXQSJEDjROdLgpYPifvFI,'imgFanart':img_fanart,'imgClearlogo':qbynAlwuUtXQSJEDjROdLgpYPifvFk,'programtitle':qbynAlwuUtXQSJEDjROdLgpYPifvFz.get('programtitle'),'programid':qbynAlwuUtXQSJEDjROdLgpYPifvFz.get('programid'),'synopsis':qbynAlwuUtXQSJEDjROdLgpYPifvFz.get('programsynopsis').replace('<br>','\n'),}
  except qbynAlwuUtXQSJEDjROdLgpYPifvKI as exception:
   qbynAlwuUtXQSJEDjROdLgpYPifvKk(exception)
  return qbynAlwuUtXQSJEDjROdLgpYPifvFV
 def Get_Season_List(qbynAlwuUtXQSJEDjROdLgpYPifvCF,seasonid):
  qbynAlwuUtXQSJEDjROdLgpYPifvFa=[]
  qbynAlwuUtXQSJEDjROdLgpYPifvFs=qbynAlwuUtXQSJEDjROdLgpYPifvCF.ProgramidToContentid(seasonid)
  qbynAlwuUtXQSJEDjROdLgpYPifvFT=qbynAlwuUtXQSJEDjROdLgpYPifvCF.GetProgramInfo(qbynAlwuUtXQSJEDjROdLgpYPifvFs)
  qbynAlwuUtXQSJEDjROdLgpYPifvFB={'poster':qbynAlwuUtXQSJEDjROdLgpYPifvFT.get('imgPoster'),'fanart':qbynAlwuUtXQSJEDjROdLgpYPifvFT.get('imgFanart'),'clearlogo':qbynAlwuUtXQSJEDjROdLgpYPifvFT.get('imgClearlogo'),}
  try:
   qbynAlwuUtXQSJEDjROdLgpYPifvCo=qbynAlwuUtXQSJEDjROdLgpYPifvCF.API_DOMAIN+'/fz/vod/programs-contents/'+seasonid
   qbynAlwuUtXQSJEDjROdLgpYPifvCm={'limit':'10','offset':'0','orderby':'new',}
   qbynAlwuUtXQSJEDjROdLgpYPifvCm.update(qbynAlwuUtXQSJEDjROdLgpYPifvCF.GetDefaultParams(login=qbynAlwuUtXQSJEDjROdLgpYPifvKm))
   qbynAlwuUtXQSJEDjROdLgpYPifvrF=qbynAlwuUtXQSJEDjROdLgpYPifvCF.callRequestCookies('Get',qbynAlwuUtXQSJEDjROdLgpYPifvCo,payload=qbynAlwuUtXQSJEDjROdLgpYPifvKc,params=qbynAlwuUtXQSJEDjROdLgpYPifvCm,headers=qbynAlwuUtXQSJEDjROdLgpYPifvKc,cookies=qbynAlwuUtXQSJEDjROdLgpYPifvKc)
   qbynAlwuUtXQSJEDjROdLgpYPifvrW=json.loads(qbynAlwuUtXQSJEDjROdLgpYPifvrF.text)
   for qbynAlwuUtXQSJEDjROdLgpYPifvFM in qbynAlwuUtXQSJEDjROdLgpYPifvrW['filter']['filterlist'][0]['filter_item_list']:
    qbynAlwuUtXQSJEDjROdLgpYPifvrV={'season_Nm':qbynAlwuUtXQSJEDjROdLgpYPifvFM.get('title'),'season_Id':qbynAlwuUtXQSJEDjROdLgpYPifvFM.get('api_path'),'thumbnail':qbynAlwuUtXQSJEDjROdLgpYPifvFB,'programNm':qbynAlwuUtXQSJEDjROdLgpYPifvFT.get('programtitle'),'synopsis':qbynAlwuUtXQSJEDjROdLgpYPifvFT.get('synopsis'),}
    qbynAlwuUtXQSJEDjROdLgpYPifvFa.append(qbynAlwuUtXQSJEDjROdLgpYPifvrV)
  except qbynAlwuUtXQSJEDjROdLgpYPifvKI as exception:
   qbynAlwuUtXQSJEDjROdLgpYPifvKk(exception)
   return[]
  return qbynAlwuUtXQSJEDjROdLgpYPifvFa
 def Get_Episode_List(qbynAlwuUtXQSJEDjROdLgpYPifvCF,seasionid,page_int=1,orderby='desc'):
  qbynAlwuUtXQSJEDjROdLgpYPifvFo=[]
  qbynAlwuUtXQSJEDjROdLgpYPifvro=qbynAlwuUtXQSJEDjROdLgpYPifvFx=1
  qbynAlwuUtXQSJEDjROdLgpYPifvFC=qbynAlwuUtXQSJEDjROdLgpYPifvKm
  qbynAlwuUtXQSJEDjROdLgpYPifvFT={}
  qbynAlwuUtXQSJEDjROdLgpYPifvFs=qbynAlwuUtXQSJEDjROdLgpYPifvCF.ProgramidToContentid(seasionid)
  qbynAlwuUtXQSJEDjROdLgpYPifvFT=qbynAlwuUtXQSJEDjROdLgpYPifvCF.GetProgramInfo(qbynAlwuUtXQSJEDjROdLgpYPifvFs)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   qbynAlwuUtXQSJEDjROdLgpYPifvCo=qbynAlwuUtXQSJEDjROdLgpYPifvCF.API_DOMAIN+'/fz/vod/programs-contents/'+seasionid
   qbynAlwuUtXQSJEDjROdLgpYPifvCm={'limit':qbynAlwuUtXQSJEDjROdLgpYPifvCF.EP_LIMIT,'offset':qbynAlwuUtXQSJEDjROdLgpYPifvKV((page_int-1)*qbynAlwuUtXQSJEDjROdLgpYPifvCF.EP_LIMIT),'orderby':orderby,}
   qbynAlwuUtXQSJEDjROdLgpYPifvCm.update(qbynAlwuUtXQSJEDjROdLgpYPifvCF.GetDefaultParams(login=qbynAlwuUtXQSJEDjROdLgpYPifvKm))
   qbynAlwuUtXQSJEDjROdLgpYPifvrF=qbynAlwuUtXQSJEDjROdLgpYPifvCF.callRequestCookies('Get',qbynAlwuUtXQSJEDjROdLgpYPifvCo,payload=qbynAlwuUtXQSJEDjROdLgpYPifvKc,params=qbynAlwuUtXQSJEDjROdLgpYPifvCm,headers=qbynAlwuUtXQSJEDjROdLgpYPifvKc,cookies=qbynAlwuUtXQSJEDjROdLgpYPifvKc)
   qbynAlwuUtXQSJEDjROdLgpYPifvrW=json.loads(qbynAlwuUtXQSJEDjROdLgpYPifvrF.text)
   qbynAlwuUtXQSJEDjROdLgpYPifvrz=qbynAlwuUtXQSJEDjROdLgpYPifvrW['cell_toplist']['celllist']
   for qbynAlwuUtXQSJEDjROdLgpYPifvrh in qbynAlwuUtXQSJEDjROdLgpYPifvrz:
    qbynAlwuUtXQSJEDjROdLgpYPifvWr=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',qbynAlwuUtXQSJEDjROdLgpYPifvrh.get('synopsis'))
    qbynAlwuUtXQSJEDjROdLgpYPifvWF=qbynAlwuUtXQSJEDjROdLgpYPifvCF.HTTPTAG+qbynAlwuUtXQSJEDjROdLgpYPifvrh.get('thumbnail')
    qbynAlwuUtXQSJEDjROdLgpYPifvWH=qbynAlwuUtXQSJEDjROdLgpYPifvWK=qbynAlwuUtXQSJEDjROdLgpYPifvWx=''
    qbynAlwuUtXQSJEDjROdLgpYPifvWH =qbynAlwuUtXQSJEDjROdLgpYPifvFT.get('imgPoster')
    qbynAlwuUtXQSJEDjROdLgpYPifvWK =qbynAlwuUtXQSJEDjROdLgpYPifvFT.get('imgFanart')
    qbynAlwuUtXQSJEDjROdLgpYPifvWx =qbynAlwuUtXQSJEDjROdLgpYPifvFT.get('imgClearlogo')
    qbynAlwuUtXQSJEDjROdLgpYPifvWe=qbynAlwuUtXQSJEDjROdLgpYPifvFT.get('programtitle')
    qbynAlwuUtXQSJEDjROdLgpYPifvFB={'thumb':qbynAlwuUtXQSJEDjROdLgpYPifvWF,'poster':qbynAlwuUtXQSJEDjROdLgpYPifvWH,'fanart':qbynAlwuUtXQSJEDjROdLgpYPifvWK,'clearlogo':qbynAlwuUtXQSJEDjROdLgpYPifvWx}
    qbynAlwuUtXQSJEDjROdLgpYPifvrV={'programtitle':qbynAlwuUtXQSJEDjROdLgpYPifvWe,'episodetitle':qbynAlwuUtXQSJEDjROdLgpYPifvrh['title_list'][0]['text'],'episodenumber':qbynAlwuUtXQSJEDjROdLgpYPifvrh['title_list'][1]['text'].replace('$O$',''),'contentid':qbynAlwuUtXQSJEDjROdLgpYPifvrh['contentid'],'synopsis':qbynAlwuUtXQSJEDjROdLgpYPifvWr,'episodeactors':qbynAlwuUtXQSJEDjROdLgpYPifvrh.get('actors').split(',')if qbynAlwuUtXQSJEDjROdLgpYPifvrh.get('actors')!='' else[],'thumbnail':qbynAlwuUtXQSJEDjROdLgpYPifvFB,}
    qbynAlwuUtXQSJEDjROdLgpYPifvFo.append(qbynAlwuUtXQSJEDjROdLgpYPifvrV)
   qbynAlwuUtXQSJEDjROdLgpYPifvro=qbynAlwuUtXQSJEDjROdLgpYPifvKT(qbynAlwuUtXQSJEDjROdLgpYPifvrW['cell_toplist']['pagecount'])
   if qbynAlwuUtXQSJEDjROdLgpYPifvrW['cell_toplist']['count']:qbynAlwuUtXQSJEDjROdLgpYPifvFx =qbynAlwuUtXQSJEDjROdLgpYPifvKT(qbynAlwuUtXQSJEDjROdLgpYPifvrW['cell_toplist']['count'])
   else:qbynAlwuUtXQSJEDjROdLgpYPifvFx=qbynAlwuUtXQSJEDjROdLgpYPifvCF.EP_LIMIT*page_int
   qbynAlwuUtXQSJEDjROdLgpYPifvFC=qbynAlwuUtXQSJEDjROdLgpYPifvro>qbynAlwuUtXQSJEDjROdLgpYPifvFx
  except qbynAlwuUtXQSJEDjROdLgpYPifvKI as exception:
   qbynAlwuUtXQSJEDjROdLgpYPifvKk(exception)
   return[],qbynAlwuUtXQSJEDjROdLgpYPifvKm
  return qbynAlwuUtXQSJEDjROdLgpYPifvFo,qbynAlwuUtXQSJEDjROdLgpYPifvFC
 def GetEPGList(qbynAlwuUtXQSJEDjROdLgpYPifvCF,genre):
  qbynAlwuUtXQSJEDjROdLgpYPifvWN={}
  try:
   qbynAlwuUtXQSJEDjROdLgpYPifvWG=qbynAlwuUtXQSJEDjROdLgpYPifvCF.Get_Now_Datetime()
   if genre=='all':
    qbynAlwuUtXQSJEDjROdLgpYPifvWc =qbynAlwuUtXQSJEDjROdLgpYPifvWG+datetime.timedelta(hours=3)
   else:
    qbynAlwuUtXQSJEDjROdLgpYPifvWc =qbynAlwuUtXQSJEDjROdLgpYPifvWG+datetime.timedelta(hours=3)
   qbynAlwuUtXQSJEDjROdLgpYPifvCo=qbynAlwuUtXQSJEDjROdLgpYPifvCF.API_DOMAIN+'/live/epgs'
   qbynAlwuUtXQSJEDjROdLgpYPifvCm={'limit':'100','offset':'0','genre':genre,'startdatetime':qbynAlwuUtXQSJEDjROdLgpYPifvWG.strftime('%Y-%m-%d %H:00'),'enddatetime':qbynAlwuUtXQSJEDjROdLgpYPifvWc.strftime('%Y-%m-%d %H:00')}
   qbynAlwuUtXQSJEDjROdLgpYPifvCm.update(qbynAlwuUtXQSJEDjROdLgpYPifvCF.GetDefaultParams(login=qbynAlwuUtXQSJEDjROdLgpYPifvKm))
   qbynAlwuUtXQSJEDjROdLgpYPifvrF=qbynAlwuUtXQSJEDjROdLgpYPifvCF.callRequestCookies('Get',qbynAlwuUtXQSJEDjROdLgpYPifvCo,payload=qbynAlwuUtXQSJEDjROdLgpYPifvKc,params=qbynAlwuUtXQSJEDjROdLgpYPifvCm,headers=qbynAlwuUtXQSJEDjROdLgpYPifvKc,cookies=qbynAlwuUtXQSJEDjROdLgpYPifvKc)
   qbynAlwuUtXQSJEDjROdLgpYPifvrW=json.loads(qbynAlwuUtXQSJEDjROdLgpYPifvrF.text)
   qbynAlwuUtXQSJEDjROdLgpYPifvWm=qbynAlwuUtXQSJEDjROdLgpYPifvrW['list']
   for qbynAlwuUtXQSJEDjROdLgpYPifvrh in qbynAlwuUtXQSJEDjROdLgpYPifvWm:
    qbynAlwuUtXQSJEDjROdLgpYPifvWs=''
    for qbynAlwuUtXQSJEDjROdLgpYPifvWz in qbynAlwuUtXQSJEDjROdLgpYPifvrh['list']:
     if qbynAlwuUtXQSJEDjROdLgpYPifvWs:qbynAlwuUtXQSJEDjROdLgpYPifvWs+='\n'
     qbynAlwuUtXQSJEDjROdLgpYPifvWs+=qbynAlwuUtXQSJEDjROdLgpYPifvCF.Get_ChangeText(qbynAlwuUtXQSJEDjROdLgpYPifvWz['title'])+'\n'
     qbynAlwuUtXQSJEDjROdLgpYPifvWs+=' [%s ~ %s]'%(qbynAlwuUtXQSJEDjROdLgpYPifvWz['starttime'][-5:],qbynAlwuUtXQSJEDjROdLgpYPifvWz['endtime'][-5:])+'\n'
    qbynAlwuUtXQSJEDjROdLgpYPifvWN[qbynAlwuUtXQSJEDjROdLgpYPifvrh['channelid']]=qbynAlwuUtXQSJEDjROdLgpYPifvWs
  except qbynAlwuUtXQSJEDjROdLgpYPifvKI as exception:
   qbynAlwuUtXQSJEDjROdLgpYPifvKk(exception)
  return qbynAlwuUtXQSJEDjROdLgpYPifvWN
 def Get_LiveChannel_List(qbynAlwuUtXQSJEDjROdLgpYPifvCF,genre,qbynAlwuUtXQSJEDjROdLgpYPifvrm):
  qbynAlwuUtXQSJEDjROdLgpYPifvrM=[]
  (qbynAlwuUtXQSJEDjROdLgpYPifvCo,qbynAlwuUtXQSJEDjROdLgpYPifvCm)=qbynAlwuUtXQSJEDjROdLgpYPifvCF.Baseapi_Parse(qbynAlwuUtXQSJEDjROdLgpYPifvrm)
  if qbynAlwuUtXQSJEDjROdLgpYPifvCo=='':return qbynAlwuUtXQSJEDjROdLgpYPifvrM
  qbynAlwuUtXQSJEDjROdLgpYPifvWh=qbynAlwuUtXQSJEDjROdLgpYPifvCF.GetEPGList(genre)
  try:
   qbynAlwuUtXQSJEDjROdLgpYPifvCm.update(qbynAlwuUtXQSJEDjROdLgpYPifvCF.GetDefaultParams(login=qbynAlwuUtXQSJEDjROdLgpYPifvKm))
   qbynAlwuUtXQSJEDjROdLgpYPifvCm['genre']=genre
   qbynAlwuUtXQSJEDjROdLgpYPifvrF=qbynAlwuUtXQSJEDjROdLgpYPifvCF.callRequestCookies('Get',qbynAlwuUtXQSJEDjROdLgpYPifvCo,payload=qbynAlwuUtXQSJEDjROdLgpYPifvKc,params=qbynAlwuUtXQSJEDjROdLgpYPifvCm,headers=qbynAlwuUtXQSJEDjROdLgpYPifvKc,cookies=qbynAlwuUtXQSJEDjROdLgpYPifvKc)
   qbynAlwuUtXQSJEDjROdLgpYPifvrW=json.loads(qbynAlwuUtXQSJEDjROdLgpYPifvrF.text)
   if not('celllist' in qbynAlwuUtXQSJEDjROdLgpYPifvrW['cell_toplist']):return[]
   qbynAlwuUtXQSJEDjROdLgpYPifvrz=qbynAlwuUtXQSJEDjROdLgpYPifvrW['cell_toplist']['celllist']
   for qbynAlwuUtXQSJEDjROdLgpYPifvrh in qbynAlwuUtXQSJEDjROdLgpYPifvrz:
    qbynAlwuUtXQSJEDjROdLgpYPifvFs=qbynAlwuUtXQSJEDjROdLgpYPifvrh['contentid']
    if qbynAlwuUtXQSJEDjROdLgpYPifvFs in qbynAlwuUtXQSJEDjROdLgpYPifvWh:
     qbynAlwuUtXQSJEDjROdLgpYPifvWV=qbynAlwuUtXQSJEDjROdLgpYPifvWh[qbynAlwuUtXQSJEDjROdLgpYPifvFs]
    else:
     qbynAlwuUtXQSJEDjROdLgpYPifvWV=''
    qbynAlwuUtXQSJEDjROdLgpYPifvrV={'studio':qbynAlwuUtXQSJEDjROdLgpYPifvrh['title_list'][0]['text'],'tvshowtitle':qbynAlwuUtXQSJEDjROdLgpYPifvCF.Get_ChangeText(qbynAlwuUtXQSJEDjROdLgpYPifvrh['title_list'][1]['text']),'channelid':qbynAlwuUtXQSJEDjROdLgpYPifvFs,'age':qbynAlwuUtXQSJEDjROdLgpYPifvrh['age'],'thumbnail':'https://%s'%qbynAlwuUtXQSJEDjROdLgpYPifvrh.get('thumbnail'),'epg':qbynAlwuUtXQSJEDjROdLgpYPifvWV}
    qbynAlwuUtXQSJEDjROdLgpYPifvrM.append(qbynAlwuUtXQSJEDjROdLgpYPifvrV)
  except qbynAlwuUtXQSJEDjROdLgpYPifvKI as exception:
   qbynAlwuUtXQSJEDjROdLgpYPifvKk(exception)
   return[]
  return qbynAlwuUtXQSJEDjROdLgpYPifvrM
 def Get_Search_List(qbynAlwuUtXQSJEDjROdLgpYPifvCF,search_key,sType,page_int,exclusion21=qbynAlwuUtXQSJEDjROdLgpYPifvKm):
  qbynAlwuUtXQSJEDjROdLgpYPifvWI=[]
  qbynAlwuUtXQSJEDjROdLgpYPifvro=qbynAlwuUtXQSJEDjROdLgpYPifvFx=1
  qbynAlwuUtXQSJEDjROdLgpYPifvFC=qbynAlwuUtXQSJEDjROdLgpYPifvKm
  try:
   qbynAlwuUtXQSJEDjROdLgpYPifvCo=qbynAlwuUtXQSJEDjROdLgpYPifvCF.API_DOMAIN+'/fz/search/band.js'
   qbynAlwuUtXQSJEDjROdLgpYPifvCm={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':qbynAlwuUtXQSJEDjROdLgpYPifvKV((page_int-1)*qbynAlwuUtXQSJEDjROdLgpYPifvCF.SEARCH_LIMIT),'limit':qbynAlwuUtXQSJEDjROdLgpYPifvCF.SEARCH_LIMIT,'orderby':'score','mtype':'svod',}
   qbynAlwuUtXQSJEDjROdLgpYPifvCm.update(qbynAlwuUtXQSJEDjROdLgpYPifvCF.GetDefaultParams(login=qbynAlwuUtXQSJEDjROdLgpYPifvKm))
   qbynAlwuUtXQSJEDjROdLgpYPifvrF=qbynAlwuUtXQSJEDjROdLgpYPifvCF.callRequestCookies('Get',qbynAlwuUtXQSJEDjROdLgpYPifvCo,payload=qbynAlwuUtXQSJEDjROdLgpYPifvKc,params=qbynAlwuUtXQSJEDjROdLgpYPifvCm,headers=qbynAlwuUtXQSJEDjROdLgpYPifvKc,cookies=qbynAlwuUtXQSJEDjROdLgpYPifvKc)
   qbynAlwuUtXQSJEDjROdLgpYPifvFz=json.loads(qbynAlwuUtXQSJEDjROdLgpYPifvrF.text)
   if not('celllist' in qbynAlwuUtXQSJEDjROdLgpYPifvFz['band']):return qbynAlwuUtXQSJEDjROdLgpYPifvWI,qbynAlwuUtXQSJEDjROdLgpYPifvFC
   qbynAlwuUtXQSJEDjROdLgpYPifvrz=qbynAlwuUtXQSJEDjROdLgpYPifvFz['band']['celllist']
   for qbynAlwuUtXQSJEDjROdLgpYPifvrh in qbynAlwuUtXQSJEDjROdLgpYPifvrz:
    qbynAlwuUtXQSJEDjROdLgpYPifvFr =qbynAlwuUtXQSJEDjROdLgpYPifvrh['event_list'][1]['url']
    qbynAlwuUtXQSJEDjROdLgpYPifvFW=urllib.parse.urlsplit(qbynAlwuUtXQSJEDjROdLgpYPifvFr).query
    qbynAlwuUtXQSJEDjROdLgpYPifvFH=qbynAlwuUtXQSJEDjROdLgpYPifvFW[0:qbynAlwuUtXQSJEDjROdLgpYPifvFW.find('=')]
    qbynAlwuUtXQSJEDjROdLgpYPifvFc=qbynAlwuUtXQSJEDjROdLgpYPifvKa(urllib.parse.parse_qsl(qbynAlwuUtXQSJEDjROdLgpYPifvFW))
    qbynAlwuUtXQSJEDjROdLgpYPifvFK=qbynAlwuUtXQSJEDjROdLgpYPifvFc.get(qbynAlwuUtXQSJEDjROdLgpYPifvFH)
    qbynAlwuUtXQSJEDjROdLgpYPifvrV={'title':qbynAlwuUtXQSJEDjROdLgpYPifvrh['title_list'][0]['text'],'age':qbynAlwuUtXQSJEDjROdLgpYPifvrh['age'],'thumbnail':'https://%s'%qbynAlwuUtXQSJEDjROdLgpYPifvrh.get('thumbnail'),'videoid':qbynAlwuUtXQSJEDjROdLgpYPifvFK,'vidtype':qbynAlwuUtXQSJEDjROdLgpYPifvFH,}
    qbynAlwuUtXQSJEDjROdLgpYPifvWk=qbynAlwuUtXQSJEDjROdLgpYPifvKm
    for qbynAlwuUtXQSJEDjROdLgpYPifvWa in qbynAlwuUtXQSJEDjROdLgpYPifvrh['bottom_taglist']:
     if qbynAlwuUtXQSJEDjROdLgpYPifvWa=='won':
      qbynAlwuUtXQSJEDjROdLgpYPifvWk=qbynAlwuUtXQSJEDjROdLgpYPifvKz
      break
    if qbynAlwuUtXQSJEDjROdLgpYPifvWk==qbynAlwuUtXQSJEDjROdLgpYPifvKz: 
     qbynAlwuUtXQSJEDjROdLgpYPifvrV['title']=qbynAlwuUtXQSJEDjROdLgpYPifvrV['title']+' [개별구매]'
    if exclusion21==qbynAlwuUtXQSJEDjROdLgpYPifvKm or qbynAlwuUtXQSJEDjROdLgpYPifvrh.get('age')!='21':
     qbynAlwuUtXQSJEDjROdLgpYPifvWI.append(qbynAlwuUtXQSJEDjROdLgpYPifvrV)
   qbynAlwuUtXQSJEDjROdLgpYPifvro=qbynAlwuUtXQSJEDjROdLgpYPifvKT(qbynAlwuUtXQSJEDjROdLgpYPifvFz['band']['pagecount'])
   if qbynAlwuUtXQSJEDjROdLgpYPifvFz['band']['count']:qbynAlwuUtXQSJEDjROdLgpYPifvFx =qbynAlwuUtXQSJEDjROdLgpYPifvKT(qbynAlwuUtXQSJEDjROdLgpYPifvFz['band']['count'])
   else:qbynAlwuUtXQSJEDjROdLgpYPifvFx=qbynAlwuUtXQSJEDjROdLgpYPifvCF.LIST_LIMIT
   qbynAlwuUtXQSJEDjROdLgpYPifvFC=qbynAlwuUtXQSJEDjROdLgpYPifvro>qbynAlwuUtXQSJEDjROdLgpYPifvFx
  except qbynAlwuUtXQSJEDjROdLgpYPifvKI as exception:
   qbynAlwuUtXQSJEDjROdLgpYPifvKk(exception)
  return qbynAlwuUtXQSJEDjROdLgpYPifvWI,qbynAlwuUtXQSJEDjROdLgpYPifvFC 
 def GetSecureToken(qbynAlwuUtXQSJEDjROdLgpYPifvCF):
  qbynAlwuUtXQSJEDjROdLgpYPifvCo=qbynAlwuUtXQSJEDjROdLgpYPifvCF.API_DOMAIN+'/ip'
  qbynAlwuUtXQSJEDjROdLgpYPifvCm=qbynAlwuUtXQSJEDjROdLgpYPifvCF.GetDefaultParams(login=qbynAlwuUtXQSJEDjROdLgpYPifvKm)
  qbynAlwuUtXQSJEDjROdLgpYPifvrF=qbynAlwuUtXQSJEDjROdLgpYPifvCF.callRequestCookies('Get',qbynAlwuUtXQSJEDjROdLgpYPifvCo,payload=qbynAlwuUtXQSJEDjROdLgpYPifvKc,params=qbynAlwuUtXQSJEDjROdLgpYPifvCm,headers=qbynAlwuUtXQSJEDjROdLgpYPifvKc,cookies=qbynAlwuUtXQSJEDjROdLgpYPifvKc)
  qbynAlwuUtXQSJEDjROdLgpYPifvrW=json.loads(qbynAlwuUtXQSJEDjROdLgpYPifvrF.text)
  return qbynAlwuUtXQSJEDjROdLgpYPifvrW['securetoken']
 def GetStreamingURL(qbynAlwuUtXQSJEDjROdLgpYPifvCF,mode,qbynAlwuUtXQSJEDjROdLgpYPifvFs,quality_int,pvrmode='-',playOption={}):
  qbynAlwuUtXQSJEDjROdLgpYPifvWT ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  qbynAlwuUtXQSJEDjROdLgpYPifvWB=[]
  if mode=='LIVE':
   qbynAlwuUtXQSJEDjROdLgpYPifvCo =qbynAlwuUtXQSJEDjROdLgpYPifvCF.API_DOMAIN+'/live/channels/'+qbynAlwuUtXQSJEDjROdLgpYPifvFs
   qbynAlwuUtXQSJEDjROdLgpYPifvWM='live'
  elif mode=='VOD':
   qbynAlwuUtXQSJEDjROdLgpYPifvCo =qbynAlwuUtXQSJEDjROdLgpYPifvCF.API_DOMAIN+'/fz/vod/contents-detail/'+qbynAlwuUtXQSJEDjROdLgpYPifvFs 
   qbynAlwuUtXQSJEDjROdLgpYPifvWM='vod'
  elif mode=='MOVIE':
   qbynAlwuUtXQSJEDjROdLgpYPifvCo =qbynAlwuUtXQSJEDjROdLgpYPifvCF.API_DOMAIN+'/fz/movie/contents/'+qbynAlwuUtXQSJEDjROdLgpYPifvFs
   qbynAlwuUtXQSJEDjROdLgpYPifvWM='movie'
  qbynAlwuUtXQSJEDjROdLgpYPifvWo={'hdr':'sdr',}
  try:
   qbynAlwuUtXQSJEDjROdLgpYPifvCm=qbynAlwuUtXQSJEDjROdLgpYPifvCF.GetDefaultParams(login=qbynAlwuUtXQSJEDjROdLgpYPifvKm)
   qbynAlwuUtXQSJEDjROdLgpYPifvrF=qbynAlwuUtXQSJEDjROdLgpYPifvCF.callRequestCookies('Get',qbynAlwuUtXQSJEDjROdLgpYPifvCo,payload=qbynAlwuUtXQSJEDjROdLgpYPifvKc,params=qbynAlwuUtXQSJEDjROdLgpYPifvCm,headers=qbynAlwuUtXQSJEDjROdLgpYPifvKc,cookies=qbynAlwuUtXQSJEDjROdLgpYPifvKc)
   qbynAlwuUtXQSJEDjROdLgpYPifvrW=json.loads(qbynAlwuUtXQSJEDjROdLgpYPifvrF.text)
   qbynAlwuUtXQSJEDjROdLgpYPifvHC=qbynAlwuUtXQSJEDjROdLgpYPifvrW['qualities']['list']
   if qbynAlwuUtXQSJEDjROdLgpYPifvHC==qbynAlwuUtXQSJEDjROdLgpYPifvKc:return qbynAlwuUtXQSJEDjROdLgpYPifvWT
   for qbynAlwuUtXQSJEDjROdLgpYPifvHr in qbynAlwuUtXQSJEDjROdLgpYPifvHC:
    qbynAlwuUtXQSJEDjROdLgpYPifvWB.append(qbynAlwuUtXQSJEDjROdLgpYPifvKT(qbynAlwuUtXQSJEDjROdLgpYPifvHr.get('id').rstrip('p')))
   if 'type' in qbynAlwuUtXQSJEDjROdLgpYPifvrW:
    if qbynAlwuUtXQSJEDjROdLgpYPifvrW['type']=='onair':
     qbynAlwuUtXQSJEDjROdLgpYPifvWM='onairvod'
   if 'drms' in qbynAlwuUtXQSJEDjROdLgpYPifvrW:
    if qbynAlwuUtXQSJEDjROdLgpYPifvrW['drms']:
     qbynAlwuUtXQSJEDjROdLgpYPifvWT['stream_action']='dash' 
   if playOption.get('enable_hdr'):
    if 'mediatypes' in qbynAlwuUtXQSJEDjROdLgpYPifvrW.get('qualities'):
     for qbynAlwuUtXQSJEDjROdLgpYPifvHF in qbynAlwuUtXQSJEDjROdLgpYPifvrW.get('qualities').get('mediatypes'):
      if qbynAlwuUtXQSJEDjROdLgpYPifvHF=='HDR10':
       qbynAlwuUtXQSJEDjROdLgpYPifvWo['hdr']='hdr'
       qbynAlwuUtXQSJEDjROdLgpYPifvWT['stream_action']='dash'
       break
  except qbynAlwuUtXQSJEDjROdLgpYPifvKI as exception:
   qbynAlwuUtXQSJEDjROdLgpYPifvKk(exception)
   return qbynAlwuUtXQSJEDjROdLgpYPifvWT
  qbynAlwuUtXQSJEDjROdLgpYPifvKk('stream_action : '+qbynAlwuUtXQSJEDjROdLgpYPifvWT['stream_action'])
  try:
   qbynAlwuUtXQSJEDjROdLgpYPifvHW=qbynAlwuUtXQSJEDjROdLgpYPifvCF.CheckQuality(quality_int,qbynAlwuUtXQSJEDjROdLgpYPifvWB)
   qbynAlwuUtXQSJEDjROdLgpYPifvHK=qbynAlwuUtXQSJEDjROdLgpYPifvKV(qbynAlwuUtXQSJEDjROdLgpYPifvHW)+'p'
   qbynAlwuUtXQSJEDjROdLgpYPifvKk(qbynAlwuUtXQSJEDjROdLgpYPifvHK)
   qbynAlwuUtXQSJEDjROdLgpYPifvCo=qbynAlwuUtXQSJEDjROdLgpYPifvCF.API_DOMAIN+'/fz/streaming'
   if qbynAlwuUtXQSJEDjROdLgpYPifvWo['hdr']=='hdr':
    qbynAlwuUtXQSJEDjROdLgpYPifvKk('playParam : hdr')
    qbynAlwuUtXQSJEDjROdLgpYPifvCm={'contentid':qbynAlwuUtXQSJEDjROdLgpYPifvFs,'contenttype':qbynAlwuUtXQSJEDjROdLgpYPifvWM,'quality':qbynAlwuUtXQSJEDjROdLgpYPifvHK,'modelid':'SHIELD Android TV','guid':qbynAlwuUtXQSJEDjROdLgpYPifvCF.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n','protocol':qbynAlwuUtXQSJEDjROdLgpYPifvWT['stream_action'],'hdr':'HDR10','videocodec':'HEVC','audiocodec':'AAC','issurround':'y','format':'normal','withinsubtitle':'n',}
    qbynAlwuUtXQSJEDjROdLgpYPifvCm.update(qbynAlwuUtXQSJEDjROdLgpYPifvCF.GetDefaultParams_AND())
   else:
    qbynAlwuUtXQSJEDjROdLgpYPifvCm={'contentid':qbynAlwuUtXQSJEDjROdLgpYPifvFs,'contenttype':qbynAlwuUtXQSJEDjROdLgpYPifvWM,'quality':qbynAlwuUtXQSJEDjROdLgpYPifvHK,'deviceModelId':'Windows 10','guid':qbynAlwuUtXQSJEDjROdLgpYPifvCF.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n','action':qbynAlwuUtXQSJEDjROdLgpYPifvWT['stream_action'],'protocol':qbynAlwuUtXQSJEDjROdLgpYPifvWT['stream_action'],'hdr':'sdr','videocodec':'avc','audiocodec':'aac','issurround':'n','format':'normal','withinsubtitle':'n',}
    qbynAlwuUtXQSJEDjROdLgpYPifvCm.update(qbynAlwuUtXQSJEDjROdLgpYPifvCF.GetDefaultParams(login=qbynAlwuUtXQSJEDjROdLgpYPifvKz))
   qbynAlwuUtXQSJEDjROdLgpYPifvrF=qbynAlwuUtXQSJEDjROdLgpYPifvCF.callRequestCookies('Get',qbynAlwuUtXQSJEDjROdLgpYPifvCo,payload=qbynAlwuUtXQSJEDjROdLgpYPifvKc,params=qbynAlwuUtXQSJEDjROdLgpYPifvCm,headers=qbynAlwuUtXQSJEDjROdLgpYPifvKc,cookies=qbynAlwuUtXQSJEDjROdLgpYPifvKc)
   qbynAlwuUtXQSJEDjROdLgpYPifvrW=json.loads(qbynAlwuUtXQSJEDjROdLgpYPifvrF.text)
   qbynAlwuUtXQSJEDjROdLgpYPifvWT['stream_url']=qbynAlwuUtXQSJEDjROdLgpYPifvrW['playurl']
   if qbynAlwuUtXQSJEDjROdLgpYPifvWT['stream_url']==qbynAlwuUtXQSJEDjROdLgpYPifvKc:return qbynAlwuUtXQSJEDjROdLgpYPifvWT
   qbynAlwuUtXQSJEDjROdLgpYPifvWT['stream_cookie']=qbynAlwuUtXQSJEDjROdLgpYPifvrW['awscookie']
   qbynAlwuUtXQSJEDjROdLgpYPifvWT['stream_drm'] =qbynAlwuUtXQSJEDjROdLgpYPifvrW['drm']
   if 'previewmsg' in qbynAlwuUtXQSJEDjROdLgpYPifvrW['preview']:qbynAlwuUtXQSJEDjROdLgpYPifvWT['stream_preview']=qbynAlwuUtXQSJEDjROdLgpYPifvrW['preview']['previewmsg']
   if 'subtitles' in qbynAlwuUtXQSJEDjROdLgpYPifvrW:
    for qbynAlwuUtXQSJEDjROdLgpYPifvHx in qbynAlwuUtXQSJEDjROdLgpYPifvrW['subtitles']:
     if qbynAlwuUtXQSJEDjROdLgpYPifvHx.get('languagecode')=='ko':
      qbynAlwuUtXQSJEDjROdLgpYPifvWT['stream_vtt']=qbynAlwuUtXQSJEDjROdLgpYPifvHx.get('url')
      break
    if qbynAlwuUtXQSJEDjROdLgpYPifvWT['stream_vtt']=='':
     for qbynAlwuUtXQSJEDjROdLgpYPifvHx in qbynAlwuUtXQSJEDjROdLgpYPifvrW['subtitles']:
      if qbynAlwuUtXQSJEDjROdLgpYPifvHx.get('languagecode')=='ko_cc':
       qbynAlwuUtXQSJEDjROdLgpYPifvWT['stream_vtt']=qbynAlwuUtXQSJEDjROdLgpYPifvHx.get('url')
       break
  except qbynAlwuUtXQSJEDjROdLgpYPifvKI as exception:
   qbynAlwuUtXQSJEDjROdLgpYPifvKk(exception)
  return qbynAlwuUtXQSJEDjROdLgpYPifvWT 
 def GetSportsURL(qbynAlwuUtXQSJEDjROdLgpYPifvCF,qbynAlwuUtXQSJEDjROdLgpYPifvFs,quality_int):
  qbynAlwuUtXQSJEDjROdLgpYPifvWT ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  qbynAlwuUtXQSJEDjROdLgpYPifvWB=[]
  try:
   qbynAlwuUtXQSJEDjROdLgpYPifvCo=qbynAlwuUtXQSJEDjROdLgpYPifvCF.API_DOMAIN+'/streaming/other'
   qbynAlwuUtXQSJEDjROdLgpYPifvCm={'contentid':qbynAlwuUtXQSJEDjROdLgpYPifvFs,'contenttype':'live','action':qbynAlwuUtXQSJEDjROdLgpYPifvWT['stream_action'],'quality':qbynAlwuUtXQSJEDjROdLgpYPifvKV(quality_int)+'p','deviceModelId':'Windows 10','guid':qbynAlwuUtXQSJEDjROdLgpYPifvCF.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n',}
   qbynAlwuUtXQSJEDjROdLgpYPifvCm.update(qbynAlwuUtXQSJEDjROdLgpYPifvCF.GetDefaultParams(login=qbynAlwuUtXQSJEDjROdLgpYPifvKz))
   qbynAlwuUtXQSJEDjROdLgpYPifvrF=qbynAlwuUtXQSJEDjROdLgpYPifvCF.callRequestCookies('Get',qbynAlwuUtXQSJEDjROdLgpYPifvCo,payload=qbynAlwuUtXQSJEDjROdLgpYPifvKc,params=qbynAlwuUtXQSJEDjROdLgpYPifvCm,headers=qbynAlwuUtXQSJEDjROdLgpYPifvKc,cookies=qbynAlwuUtXQSJEDjROdLgpYPifvKc)
   qbynAlwuUtXQSJEDjROdLgpYPifvrW=json.loads(qbynAlwuUtXQSJEDjROdLgpYPifvrF.text)
   qbynAlwuUtXQSJEDjROdLgpYPifvWT['stream_url']=qbynAlwuUtXQSJEDjROdLgpYPifvrW['playurl']
   if qbynAlwuUtXQSJEDjROdLgpYPifvWT['stream_url']==qbynAlwuUtXQSJEDjROdLgpYPifvKc:return qbynAlwuUtXQSJEDjROdLgpYPifvWT
   qbynAlwuUtXQSJEDjROdLgpYPifvWT['stream_cookie']=qbynAlwuUtXQSJEDjROdLgpYPifvrW['awscookie']
  except qbynAlwuUtXQSJEDjROdLgpYPifvKI as exception:
   qbynAlwuUtXQSJEDjROdLgpYPifvKk(exception)
  return qbynAlwuUtXQSJEDjROdLgpYPifvWT
 def make_viewdate(qbynAlwuUtXQSJEDjROdLgpYPifvCF):
  qbynAlwuUtXQSJEDjROdLgpYPifvHe =qbynAlwuUtXQSJEDjROdLgpYPifvCF.Get_Now_Datetime()
  qbynAlwuUtXQSJEDjROdLgpYPifvHN =qbynAlwuUtXQSJEDjROdLgpYPifvHe+datetime.timedelta(days=-1)
  qbynAlwuUtXQSJEDjROdLgpYPifvHG =qbynAlwuUtXQSJEDjROdLgpYPifvHe+datetime.timedelta(days=1)
  qbynAlwuUtXQSJEDjROdLgpYPifvHc=[qbynAlwuUtXQSJEDjROdLgpYPifvHe.strftime('%Y%m%d'),qbynAlwuUtXQSJEDjROdLgpYPifvHG.strftime('%Y%m%d'),]
  return qbynAlwuUtXQSJEDjROdLgpYPifvHc
 def Get_Sports_Gamelist(qbynAlwuUtXQSJEDjROdLgpYPifvCF):
  qbynAlwuUtXQSJEDjROdLgpYPifvHm =qbynAlwuUtXQSJEDjROdLgpYPifvCF.make_viewdate()
  qbynAlwuUtXQSJEDjROdLgpYPifvHs=[]
  qbynAlwuUtXQSJEDjROdLgpYPifvHz =[]
  for qbynAlwuUtXQSJEDjROdLgpYPifvHh in qbynAlwuUtXQSJEDjROdLgpYPifvHm:
   qbynAlwuUtXQSJEDjROdLgpYPifvHV=qbynAlwuUtXQSJEDjROdLgpYPifvHh[:6]
   if qbynAlwuUtXQSJEDjROdLgpYPifvHV not in qbynAlwuUtXQSJEDjROdLgpYPifvHs:
    qbynAlwuUtXQSJEDjROdLgpYPifvHs.append(qbynAlwuUtXQSJEDjROdLgpYPifvHV)
  try:
   qbynAlwuUtXQSJEDjROdLgpYPifvCo='https://annexapi.wavve.com/skb/baseball/teammonthlycalendarlist'
   qbynAlwuUtXQSJEDjROdLgpYPifvCm={'IF':'IF-PORG-002','m':'getTeamCalendarListBand','response_format':'json','spo_itm_cd':'KBO','teamcd':'all','tgroup':'B','tvalue':'BC123','ver':'2.0',}
   qbynAlwuUtXQSJEDjROdLgpYPifvCm.update(qbynAlwuUtXQSJEDjROdLgpYPifvCF.GetDefaultParams(login=qbynAlwuUtXQSJEDjROdLgpYPifvKm))
   for qbynAlwuUtXQSJEDjROdLgpYPifvHI in qbynAlwuUtXQSJEDjROdLgpYPifvHs:
    qbynAlwuUtXQSJEDjROdLgpYPifvCm['date']=qbynAlwuUtXQSJEDjROdLgpYPifvHI
    qbynAlwuUtXQSJEDjROdLgpYPifvrF=qbynAlwuUtXQSJEDjROdLgpYPifvCF.callRequestCookies('Get',qbynAlwuUtXQSJEDjROdLgpYPifvCo,payload=qbynAlwuUtXQSJEDjROdLgpYPifvKc,params=qbynAlwuUtXQSJEDjROdLgpYPifvCm,headers=qbynAlwuUtXQSJEDjROdLgpYPifvKc,cookies=qbynAlwuUtXQSJEDjROdLgpYPifvKc)
    qbynAlwuUtXQSJEDjROdLgpYPifvrW=json.loads(qbynAlwuUtXQSJEDjROdLgpYPifvrF.text)
    qbynAlwuUtXQSJEDjROdLgpYPifvrz=qbynAlwuUtXQSJEDjROdLgpYPifvrW['cell_toplist']['celllist']
    for qbynAlwuUtXQSJEDjROdLgpYPifvrh in qbynAlwuUtXQSJEDjROdLgpYPifvrz:
     qbynAlwuUtXQSJEDjROdLgpYPifvHk=qbynAlwuUtXQSJEDjROdLgpYPifvrh.get('game_date')
     qbynAlwuUtXQSJEDjROdLgpYPifvHa =qbynAlwuUtXQSJEDjROdLgpYPifvrh.get('svc_id')
     if qbynAlwuUtXQSJEDjROdLgpYPifvHa=='':continue
     if qbynAlwuUtXQSJEDjROdLgpYPifvHk in qbynAlwuUtXQSJEDjROdLgpYPifvHm:
      qbynAlwuUtXQSJEDjROdLgpYPifvHT=qbynAlwuUtXQSJEDjROdLgpYPifvrh.get('game_status') 
      qbynAlwuUtXQSJEDjROdLgpYPifvHB =qbynAlwuUtXQSJEDjROdLgpYPifvrh.get('title_list')[0].get('text')
      qbynAlwuUtXQSJEDjROdLgpYPifvHk =qbynAlwuUtXQSJEDjROdLgpYPifvHk[:4]+'-'+qbynAlwuUtXQSJEDjROdLgpYPifvHk[4:6]+'-'+qbynAlwuUtXQSJEDjROdLgpYPifvHk[-2:]
      qbynAlwuUtXQSJEDjROdLgpYPifvHM =qbynAlwuUtXQSJEDjROdLgpYPifvrh.get('game_time')
      qbynAlwuUtXQSJEDjROdLgpYPifvHM =qbynAlwuUtXQSJEDjROdLgpYPifvHM[:2]+':'+qbynAlwuUtXQSJEDjROdLgpYPifvHM[-2:]
      qbynAlwuUtXQSJEDjROdLgpYPifvrV={'game_date':qbynAlwuUtXQSJEDjROdLgpYPifvHk,'game_time':qbynAlwuUtXQSJEDjROdLgpYPifvHM,'svc_id':qbynAlwuUtXQSJEDjROdLgpYPifvHa,'away_team':qbynAlwuUtXQSJEDjROdLgpYPifvrh.get('away_team').get('team_name'),'home_team':qbynAlwuUtXQSJEDjROdLgpYPifvrh.get('home_team').get('team_name'),'game_status':qbynAlwuUtXQSJEDjROdLgpYPifvHT,'game_place':qbynAlwuUtXQSJEDjROdLgpYPifvrh.get('game_place'),}
      qbynAlwuUtXQSJEDjROdLgpYPifvHz.append(qbynAlwuUtXQSJEDjROdLgpYPifvrV)
  except qbynAlwuUtXQSJEDjROdLgpYPifvKI as exception:
   qbynAlwuUtXQSJEDjROdLgpYPifvKk(exception)
   return[]
  qbynAlwuUtXQSJEDjROdLgpYPifvHo=[]
  for i in qbynAlwuUtXQSJEDjROdLgpYPifvKh(2):
   for qbynAlwuUtXQSJEDjROdLgpYPifvrh in qbynAlwuUtXQSJEDjROdLgpYPifvHz:
    if i==0 and qbynAlwuUtXQSJEDjROdLgpYPifvrh.get('game_status')=='LIVE':
     qbynAlwuUtXQSJEDjROdLgpYPifvHo.append(qbynAlwuUtXQSJEDjROdLgpYPifvrh)
    elif i==1 and qbynAlwuUtXQSJEDjROdLgpYPifvrh.get('game_status')!='LIVE':
     qbynAlwuUtXQSJEDjROdLgpYPifvHo.append(qbynAlwuUtXQSJEDjROdLgpYPifvrh)
  return qbynAlwuUtXQSJEDjROdLgpYPifvHo
 def GetBookmarkInfo(qbynAlwuUtXQSJEDjROdLgpYPifvCF,qbynAlwuUtXQSJEDjROdLgpYPifvFK,qbynAlwuUtXQSJEDjROdLgpYPifvFH,qbynAlwuUtXQSJEDjROdLgpYPifvWM):
  if qbynAlwuUtXQSJEDjROdLgpYPifvFH=='tvshow':
   if qbynAlwuUtXQSJEDjROdLgpYPifvWM=='contentid':
    qbynAlwuUtXQSJEDjROdLgpYPifvFs=qbynAlwuUtXQSJEDjROdLgpYPifvFK
    qbynAlwuUtXQSJEDjROdLgpYPifvFK =qbynAlwuUtXQSJEDjROdLgpYPifvCF.ContentidToSeasonid(qbynAlwuUtXQSJEDjROdLgpYPifvFs)
   else:
    qbynAlwuUtXQSJEDjROdLgpYPifvFs=qbynAlwuUtXQSJEDjROdLgpYPifvCF.ProgramidToContentid(qbynAlwuUtXQSJEDjROdLgpYPifvFK)
  else:
   qbynAlwuUtXQSJEDjROdLgpYPifvFs=''
  qbynAlwuUtXQSJEDjROdLgpYPifvKC={'indexinfo':{'ott':'wavve','videoid':qbynAlwuUtXQSJEDjROdLgpYPifvFK,'vidtype':qbynAlwuUtXQSJEDjROdLgpYPifvFH,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':qbynAlwuUtXQSJEDjROdLgpYPifvFH,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if qbynAlwuUtXQSJEDjROdLgpYPifvFH=='tvshow':
   qbynAlwuUtXQSJEDjROdLgpYPifvCo=qbynAlwuUtXQSJEDjROdLgpYPifvCF.API_DOMAIN+'/fz/vod/contents/'+qbynAlwuUtXQSJEDjROdLgpYPifvFs 
   qbynAlwuUtXQSJEDjROdLgpYPifvCm=qbynAlwuUtXQSJEDjROdLgpYPifvCF.GetDefaultParams(login=qbynAlwuUtXQSJEDjROdLgpYPifvKm)
   qbynAlwuUtXQSJEDjROdLgpYPifvrF=qbynAlwuUtXQSJEDjROdLgpYPifvCF.callRequestCookies('Get',qbynAlwuUtXQSJEDjROdLgpYPifvCo,payload=qbynAlwuUtXQSJEDjROdLgpYPifvKc,params=qbynAlwuUtXQSJEDjROdLgpYPifvCm,headers=qbynAlwuUtXQSJEDjROdLgpYPifvKc,cookies=qbynAlwuUtXQSJEDjROdLgpYPifvKc)
   qbynAlwuUtXQSJEDjROdLgpYPifvrW=json.loads(qbynAlwuUtXQSJEDjROdLgpYPifvrF.text)
   if not('programtitle' in qbynAlwuUtXQSJEDjROdLgpYPifvrW):return{}
   qbynAlwuUtXQSJEDjROdLgpYPifvKr=qbynAlwuUtXQSJEDjROdLgpYPifvrW
   qbynAlwuUtXQSJEDjROdLgpYPifvKF=qbynAlwuUtXQSJEDjROdLgpYPifvKr.get('programtitle')
   qbynAlwuUtXQSJEDjROdLgpYPifvKC['saveinfo']['infoLabels']['title']=qbynAlwuUtXQSJEDjROdLgpYPifvKF
   if qbynAlwuUtXQSJEDjROdLgpYPifvKr.get('targetage')=='18' or qbynAlwuUtXQSJEDjROdLgpYPifvKr.get('targetage')=='19' or qbynAlwuUtXQSJEDjROdLgpYPifvKr.get('targetage')=='21':
    qbynAlwuUtXQSJEDjROdLgpYPifvKF +=u' (%s)'%(qbynAlwuUtXQSJEDjROdLgpYPifvKr.get('targetage'))
   qbynAlwuUtXQSJEDjROdLgpYPifvKC['saveinfo']['title'] =qbynAlwuUtXQSJEDjROdLgpYPifvKF
   qbynAlwuUtXQSJEDjROdLgpYPifvKC['saveinfo']['infoLabels']['mpaa'] =qbynAlwuUtXQSJEDjROdLgpYPifvKr.get('targetage')
   qbynAlwuUtXQSJEDjROdLgpYPifvKC['saveinfo']['infoLabels']['plot'] =qbynAlwuUtXQSJEDjROdLgpYPifvKr.get('programsynopsis').replace('<br>','\n')
   qbynAlwuUtXQSJEDjROdLgpYPifvKC['saveinfo']['infoLabels']['studio'] =qbynAlwuUtXQSJEDjROdLgpYPifvKr.get('channelname')
   if qbynAlwuUtXQSJEDjROdLgpYPifvKr.get('firstreleaseyear')!='':qbynAlwuUtXQSJEDjROdLgpYPifvKC['saveinfo']['infoLabels']['year'] =qbynAlwuUtXQSJEDjROdLgpYPifvKr.get('firstreleaseyear')
   if qbynAlwuUtXQSJEDjROdLgpYPifvKr.get('firstreleasedate')!='':qbynAlwuUtXQSJEDjROdLgpYPifvKC['saveinfo']['infoLabels']['premiered']=qbynAlwuUtXQSJEDjROdLgpYPifvKr.get('firstreleasedate')
   if qbynAlwuUtXQSJEDjROdLgpYPifvKr.get('genretext') !='':qbynAlwuUtXQSJEDjROdLgpYPifvKC['saveinfo']['infoLabels']['genre'] =[qbynAlwuUtXQSJEDjROdLgpYPifvKr.get('genretext')]
   qbynAlwuUtXQSJEDjROdLgpYPifvKW=[]
   for qbynAlwuUtXQSJEDjROdLgpYPifvKH in qbynAlwuUtXQSJEDjROdLgpYPifvKr['actors']['list']:qbynAlwuUtXQSJEDjROdLgpYPifvKW.append(qbynAlwuUtXQSJEDjROdLgpYPifvKH.get('text'))
   if qbynAlwuUtXQSJEDjROdLgpYPifvKB(qbynAlwuUtXQSJEDjROdLgpYPifvKW)>0:
    if qbynAlwuUtXQSJEDjROdLgpYPifvKW[0]!='':qbynAlwuUtXQSJEDjROdLgpYPifvKC['saveinfo']['infoLabels']['cast']=qbynAlwuUtXQSJEDjROdLgpYPifvKW
   qbynAlwuUtXQSJEDjROdLgpYPifvWH =''
   qbynAlwuUtXQSJEDjROdLgpYPifvWK =''
   qbynAlwuUtXQSJEDjROdLgpYPifvWx=''
   if qbynAlwuUtXQSJEDjROdLgpYPifvKr.get('programposterimage')!='':qbynAlwuUtXQSJEDjROdLgpYPifvWH =qbynAlwuUtXQSJEDjROdLgpYPifvCF.HTTPTAG+qbynAlwuUtXQSJEDjROdLgpYPifvKr.get('programposterimage')
   if qbynAlwuUtXQSJEDjROdLgpYPifvKr.get('programimage') !='':qbynAlwuUtXQSJEDjROdLgpYPifvWK =qbynAlwuUtXQSJEDjROdLgpYPifvCF.HTTPTAG+qbynAlwuUtXQSJEDjROdLgpYPifvKr.get('programimage')
   if qbynAlwuUtXQSJEDjROdLgpYPifvKr.get('programcircleimage')!='':qbynAlwuUtXQSJEDjROdLgpYPifvWx=qbynAlwuUtXQSJEDjROdLgpYPifvCF.HTTPTAG+qbynAlwuUtXQSJEDjROdLgpYPifvKr.get('programcircleimage')
   if 'poster_default' in qbynAlwuUtXQSJEDjROdLgpYPifvWH:
    qbynAlwuUtXQSJEDjROdLgpYPifvWH =qbynAlwuUtXQSJEDjROdLgpYPifvWK
    qbynAlwuUtXQSJEDjROdLgpYPifvWx=''
   qbynAlwuUtXQSJEDjROdLgpYPifvKC['saveinfo']['thumbnail']['poster']=qbynAlwuUtXQSJEDjROdLgpYPifvWH
   qbynAlwuUtXQSJEDjROdLgpYPifvKC['saveinfo']['thumbnail']['thumb']=qbynAlwuUtXQSJEDjROdLgpYPifvWK
   qbynAlwuUtXQSJEDjROdLgpYPifvKC['saveinfo']['thumbnail']['clearlogo']=qbynAlwuUtXQSJEDjROdLgpYPifvWx
   qbynAlwuUtXQSJEDjROdLgpYPifvKC['saveinfo']['thumbnail']['fanart']=qbynAlwuUtXQSJEDjROdLgpYPifvWK
  else:
   qbynAlwuUtXQSJEDjROdLgpYPifvCo=qbynAlwuUtXQSJEDjROdLgpYPifvCF.API_DOMAIN+'/movie/contents/'+qbynAlwuUtXQSJEDjROdLgpYPifvFK 
   qbynAlwuUtXQSJEDjROdLgpYPifvCm=qbynAlwuUtXQSJEDjROdLgpYPifvCF.GetDefaultParams(login=qbynAlwuUtXQSJEDjROdLgpYPifvKm)
   qbynAlwuUtXQSJEDjROdLgpYPifvrF=qbynAlwuUtXQSJEDjROdLgpYPifvCF.callRequestCookies('Get',qbynAlwuUtXQSJEDjROdLgpYPifvCo,payload=qbynAlwuUtXQSJEDjROdLgpYPifvKc,params=qbynAlwuUtXQSJEDjROdLgpYPifvCm,headers=qbynAlwuUtXQSJEDjROdLgpYPifvKc,cookies=qbynAlwuUtXQSJEDjROdLgpYPifvKc)
   qbynAlwuUtXQSJEDjROdLgpYPifvrW=json.loads(qbynAlwuUtXQSJEDjROdLgpYPifvrF.text)
   if not('title' in qbynAlwuUtXQSJEDjROdLgpYPifvrW):return{}
   qbynAlwuUtXQSJEDjROdLgpYPifvKr=qbynAlwuUtXQSJEDjROdLgpYPifvrW
   qbynAlwuUtXQSJEDjROdLgpYPifvKF=qbynAlwuUtXQSJEDjROdLgpYPifvKr.get('title')
   qbynAlwuUtXQSJEDjROdLgpYPifvKC['saveinfo']['infoLabels']['title']=qbynAlwuUtXQSJEDjROdLgpYPifvKF
   if qbynAlwuUtXQSJEDjROdLgpYPifvKr.get('targetage')=='18' or qbynAlwuUtXQSJEDjROdLgpYPifvKr.get('targetage')=='19' or qbynAlwuUtXQSJEDjROdLgpYPifvKr.get('targetage')=='21':
    qbynAlwuUtXQSJEDjROdLgpYPifvKF +=u' (%s)'%(qbynAlwuUtXQSJEDjROdLgpYPifvKr.get('targetage'))
   qbynAlwuUtXQSJEDjROdLgpYPifvKC['saveinfo']['title'] =qbynAlwuUtXQSJEDjROdLgpYPifvKF
   qbynAlwuUtXQSJEDjROdLgpYPifvKC['saveinfo']['infoLabels']['mpaa'] =qbynAlwuUtXQSJEDjROdLgpYPifvKr.get('targetage')
   qbynAlwuUtXQSJEDjROdLgpYPifvKC['saveinfo']['infoLabels']['plot'] =qbynAlwuUtXQSJEDjROdLgpYPifvKr.get('synopsis').replace('<br>','\n')
   qbynAlwuUtXQSJEDjROdLgpYPifvKC['saveinfo']['infoLabels']['duration']=qbynAlwuUtXQSJEDjROdLgpYPifvKr.get('playtime')
   qbynAlwuUtXQSJEDjROdLgpYPifvKC['saveinfo']['infoLabels']['country']=qbynAlwuUtXQSJEDjROdLgpYPifvKr.get('country')
   qbynAlwuUtXQSJEDjROdLgpYPifvKC['saveinfo']['infoLabels']['studio'] =qbynAlwuUtXQSJEDjROdLgpYPifvKr.get('cpname')
   if qbynAlwuUtXQSJEDjROdLgpYPifvKr.get('releasedate')!='':
    qbynAlwuUtXQSJEDjROdLgpYPifvKC['saveinfo']['infoLabels']['year'] =qbynAlwuUtXQSJEDjROdLgpYPifvKr.get('releasedate')[:4]
    qbynAlwuUtXQSJEDjROdLgpYPifvKC['saveinfo']['infoLabels']['premiered']=qbynAlwuUtXQSJEDjROdLgpYPifvKr.get('releasedate')
   qbynAlwuUtXQSJEDjROdLgpYPifvKW=[]
   for qbynAlwuUtXQSJEDjROdLgpYPifvKH in qbynAlwuUtXQSJEDjROdLgpYPifvKr['actors']['list']:qbynAlwuUtXQSJEDjROdLgpYPifvKW.append(qbynAlwuUtXQSJEDjROdLgpYPifvKH.get('text'))
   if qbynAlwuUtXQSJEDjROdLgpYPifvKB(qbynAlwuUtXQSJEDjROdLgpYPifvKW)>0:
    if qbynAlwuUtXQSJEDjROdLgpYPifvKW[0]!='':qbynAlwuUtXQSJEDjROdLgpYPifvKC['saveinfo']['infoLabels']['cast']=qbynAlwuUtXQSJEDjROdLgpYPifvKW
   qbynAlwuUtXQSJEDjROdLgpYPifvKx=[]
   for qbynAlwuUtXQSJEDjROdLgpYPifvKe in qbynAlwuUtXQSJEDjROdLgpYPifvKr['directors']['list']:qbynAlwuUtXQSJEDjROdLgpYPifvKx.append(qbynAlwuUtXQSJEDjROdLgpYPifvKe.get('text'))
   if qbynAlwuUtXQSJEDjROdLgpYPifvKB(qbynAlwuUtXQSJEDjROdLgpYPifvKx)>0:
    if qbynAlwuUtXQSJEDjROdLgpYPifvKx[0]!='':qbynAlwuUtXQSJEDjROdLgpYPifvKC['saveinfo']['infoLabels']['director']=qbynAlwuUtXQSJEDjROdLgpYPifvKx
   qbynAlwuUtXQSJEDjROdLgpYPifvrc=[]
   for qbynAlwuUtXQSJEDjROdLgpYPifvKN in qbynAlwuUtXQSJEDjROdLgpYPifvKr['genre']['list']:qbynAlwuUtXQSJEDjROdLgpYPifvrc.append(qbynAlwuUtXQSJEDjROdLgpYPifvKN.get('text'))
   if qbynAlwuUtXQSJEDjROdLgpYPifvKB(qbynAlwuUtXQSJEDjROdLgpYPifvrc)>0:
    if qbynAlwuUtXQSJEDjROdLgpYPifvrc[0]!='':qbynAlwuUtXQSJEDjROdLgpYPifvKC['saveinfo']['infoLabels']['genre']=qbynAlwuUtXQSJEDjROdLgpYPifvrc
   qbynAlwuUtXQSJEDjROdLgpYPifvWH ='https://%s'%qbynAlwuUtXQSJEDjROdLgpYPifvKr['image']
   qbynAlwuUtXQSJEDjROdLgpYPifvKC['saveinfo']['thumbnail']['poster'] =qbynAlwuUtXQSJEDjROdLgpYPifvWH
   qbynAlwuUtXQSJEDjROdLgpYPifvKC['saveinfo']['thumbnail']['thumb'] =qbynAlwuUtXQSJEDjROdLgpYPifvWH
  return qbynAlwuUtXQSJEDjROdLgpYPifvKC
# Created by pyminifier (https://github.com/liftoff/pyminifier)
