__author__="NightRain"
tLTOdjFWEvQrRDNXlCxgMbVozIkfaU=object
tLTOdjFWEvQrRDNXlCxgMbVozIkfaK=None
tLTOdjFWEvQrRDNXlCxgMbVozIkfaq=int
tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ=True
tLTOdjFWEvQrRDNXlCxgMbVozIkfaA=False
tLTOdjFWEvQrRDNXlCxgMbVozIkfaH=type
tLTOdjFWEvQrRDNXlCxgMbVozIkfas=dict
tLTOdjFWEvQrRDNXlCxgMbVozIkfam=getattr
tLTOdjFWEvQrRDNXlCxgMbVozIkfaP=list
tLTOdjFWEvQrRDNXlCxgMbVozIkfau=len
tLTOdjFWEvQrRDNXlCxgMbVozIkfaS=range
tLTOdjFWEvQrRDNXlCxgMbVozIkfae=str
tLTOdjFWEvQrRDNXlCxgMbVozIkfaB=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import json
tLTOdjFWEvQrRDNXlCxgMbVozIkfYc=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://apis.wavve.com/v1/multiband/GN51','icon':'home.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&uicode=VN500','page':'1','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?WeekDay=all&broadcastid=1390539&contenttype=vod&genre=01&orderby=viewtime&uicode=VN4&uiparent=FN0&uirank=0&uitype=VN4','page':'1','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?WeekDay=all&broadcastid=1311034&contenttype=vod&genre=02&orderby=viewtime&uicode=VN3&uiparent=FN0&uirank=0&uitype=VN3','page':'1','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'CN21','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'vod09','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'vod09','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'4','sType':'movie','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'4','sType':'movie','orderby':'modifydate','ordernm':'업데이트순','icon':''},{'title':'프로야구 - 경기중 시청가능','mode':'GAME_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'(웨이브) 검색','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'(웨이브) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
tLTOdjFWEvQrRDNXlCxgMbVozIkfYU=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
tLTOdjFWEvQrRDNXlCxgMbVozIkfYK=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
tLTOdjFWEvQrRDNXlCxgMbVozIkfYq={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
tLTOdjFWEvQrRDNXlCxgMbVozIkfYJ =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
tLTOdjFWEvQrRDNXlCxgMbVozIkfYa=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_searched.txt'))
from wavveCore import*
class tLTOdjFWEvQrRDNXlCxgMbVozIkfYn(tLTOdjFWEvQrRDNXlCxgMbVozIkfaU):
 def __init__(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA,tLTOdjFWEvQrRDNXlCxgMbVozIkfYH,tLTOdjFWEvQrRDNXlCxgMbVozIkfYs,tLTOdjFWEvQrRDNXlCxgMbVozIkfYm):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYA._addon_url =tLTOdjFWEvQrRDNXlCxgMbVozIkfYH
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYA._addon_handle=tLTOdjFWEvQrRDNXlCxgMbVozIkfYs
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.main_params =tLTOdjFWEvQrRDNXlCxgMbVozIkfYm
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj =qbynAlwuUtXQSJEDjROdLgpYPifvCr() 
 def addon_noti(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA,sting):
  try:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYu=xbmcgui.Dialog()
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYu.notification(__addonname__,sting)
  except:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfaK
 def addon_log(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA,string):
  try:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYS=string.encode('utf-8','ignore')
  except:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYS='addonException: addon_log'
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYe=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,tLTOdjFWEvQrRDNXlCxgMbVozIkfYS),level=tLTOdjFWEvQrRDNXlCxgMbVozIkfYe)
 def get_keyboard_input(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA,tLTOdjFWEvQrRDNXlCxgMbVozIkfns):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYB=tLTOdjFWEvQrRDNXlCxgMbVozIkfaK
  kb=xbmc.Keyboard()
  kb.setHeading(tLTOdjFWEvQrRDNXlCxgMbVozIkfns)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYB=kb.getText()
  return tLTOdjFWEvQrRDNXlCxgMbVozIkfYB
 def get_settings_account(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYG =__addon__.getSetting('id')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYy =__addon__.getSetting('pw')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYp=tLTOdjFWEvQrRDNXlCxgMbVozIkfaq(__addon__.getSetting('selected_profile'))
  return(tLTOdjFWEvQrRDNXlCxgMbVozIkfYG,tLTOdjFWEvQrRDNXlCxgMbVozIkfYy,tLTOdjFWEvQrRDNXlCxgMbVozIkfYp)
 def get_settings_totalsearch(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYi =tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ if __addon__.getSetting('local_search')=='true' else tLTOdjFWEvQrRDNXlCxgMbVozIkfaA
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYw=tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ if __addon__.getSetting('local_history')=='true' else tLTOdjFWEvQrRDNXlCxgMbVozIkfaA
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYh =tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ if __addon__.getSetting('total_search')=='true' else tLTOdjFWEvQrRDNXlCxgMbVozIkfaA
  tLTOdjFWEvQrRDNXlCxgMbVozIkfnY=tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ if __addon__.getSetting('total_history')=='true' else tLTOdjFWEvQrRDNXlCxgMbVozIkfaA
  tLTOdjFWEvQrRDNXlCxgMbVozIkfnc=tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ if __addon__.getSetting('menu_bookmark')=='true' else tLTOdjFWEvQrRDNXlCxgMbVozIkfaA
  return(tLTOdjFWEvQrRDNXlCxgMbVozIkfYi,tLTOdjFWEvQrRDNXlCxgMbVozIkfYw,tLTOdjFWEvQrRDNXlCxgMbVozIkfYh,tLTOdjFWEvQrRDNXlCxgMbVozIkfnY,tLTOdjFWEvQrRDNXlCxgMbVozIkfnc)
 def get_settings_makebookmark(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA):
  return tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ if __addon__.getSetting('make_bookmark')=='true' else tLTOdjFWEvQrRDNXlCxgMbVozIkfaA
 def get_settings_play(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfnU={'enable_hdr':tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ if __addon__.getSetting('enable_hdr')=='true' else tLTOdjFWEvQrRDNXlCxgMbVozIkfaA,}
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfnU['enable_hdr']==tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ:
   if tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.get_selQuality()<1080:tLTOdjFWEvQrRDNXlCxgMbVozIkfnU['enable_hdr']=tLTOdjFWEvQrRDNXlCxgMbVozIkfaA
  return(tLTOdjFWEvQrRDNXlCxgMbVozIkfnU)
 def get_selQuality(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA):
  try:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnK=[1080,720,480,360]
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnq=tLTOdjFWEvQrRDNXlCxgMbVozIkfaq(__addon__.getSetting('selected_quality'))
   return tLTOdjFWEvQrRDNXlCxgMbVozIkfnK[tLTOdjFWEvQrRDNXlCxgMbVozIkfnq]
  except:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfaK
  return 1080 
 def get_settings_exclusion21(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfnJ =__addon__.getSetting('exclusion21')
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfnJ=='false':
   return tLTOdjFWEvQrRDNXlCxgMbVozIkfaA
  else:
   return tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ
 def get_settings_direct_replay(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfna=tLTOdjFWEvQrRDNXlCxgMbVozIkfaq(__addon__.getSetting('direct_replay'))
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfna==0:
   return tLTOdjFWEvQrRDNXlCxgMbVozIkfaA
  else:
   return tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ
 def set_winEpisodeOrderby(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA,tLTOdjFWEvQrRDNXlCxgMbVozIkfnA):
  __addon__.setSetting('wavve_orderby',tLTOdjFWEvQrRDNXlCxgMbVozIkfnA)
 def get_winEpisodeOrderby(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfnA=__addon__.getSetting('wavve_orderby')
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfnA in['',tLTOdjFWEvQrRDNXlCxgMbVozIkfaK]:tLTOdjFWEvQrRDNXlCxgMbVozIkfnA='desc'
  return tLTOdjFWEvQrRDNXlCxgMbVozIkfnA
 def add_dir(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA,label,sublabel='',img='',infoLabels=tLTOdjFWEvQrRDNXlCxgMbVozIkfaK,isFolder=tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ,params='',isLink=tLTOdjFWEvQrRDNXlCxgMbVozIkfaA,ContextMenu=tLTOdjFWEvQrRDNXlCxgMbVozIkfaK):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfnH='%s?%s'%(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA._addon_url,urllib.parse.urlencode(params))
  if sublabel:tLTOdjFWEvQrRDNXlCxgMbVozIkfns='%s < %s >'%(label,sublabel)
  else: tLTOdjFWEvQrRDNXlCxgMbVozIkfns=label
  if not img:img='DefaultFolder.png'
  tLTOdjFWEvQrRDNXlCxgMbVozIkfnm=xbmcgui.ListItem(tLTOdjFWEvQrRDNXlCxgMbVozIkfns)
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfaH(img)==tLTOdjFWEvQrRDNXlCxgMbVozIkfas:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnm.setArt(img)
  else:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnm.setArt({'thumb':img,'poster':img})
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.KodiVersion>=20:
   if infoLabels:tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.Set_InfoTag(tLTOdjFWEvQrRDNXlCxgMbVozIkfnm.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:tLTOdjFWEvQrRDNXlCxgMbVozIkfnm.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnm.setProperty('IsPlayable','true')
  if ContextMenu:tLTOdjFWEvQrRDNXlCxgMbVozIkfnm.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA._addon_handle,tLTOdjFWEvQrRDNXlCxgMbVozIkfnH,tLTOdjFWEvQrRDNXlCxgMbVozIkfnm,isFolder)
 def Set_InfoTag(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA,video_InfoTag:xbmc.InfoTagVideo,tLTOdjFWEvQrRDNXlCxgMbVozIkfnp):
  for tLTOdjFWEvQrRDNXlCxgMbVozIkfnP,value in tLTOdjFWEvQrRDNXlCxgMbVozIkfnp.items():
   if tLTOdjFWEvQrRDNXlCxgMbVozIkfYq[tLTOdjFWEvQrRDNXlCxgMbVozIkfnP]['type']=='string':
    tLTOdjFWEvQrRDNXlCxgMbVozIkfam(video_InfoTag,tLTOdjFWEvQrRDNXlCxgMbVozIkfYq[tLTOdjFWEvQrRDNXlCxgMbVozIkfnP]['func'])(value)
   elif tLTOdjFWEvQrRDNXlCxgMbVozIkfYq[tLTOdjFWEvQrRDNXlCxgMbVozIkfnP]['type']=='int':
    if tLTOdjFWEvQrRDNXlCxgMbVozIkfaH(value)==tLTOdjFWEvQrRDNXlCxgMbVozIkfaq:
     tLTOdjFWEvQrRDNXlCxgMbVozIkfnu=tLTOdjFWEvQrRDNXlCxgMbVozIkfaq(value)
    else:
     tLTOdjFWEvQrRDNXlCxgMbVozIkfnu=0
    tLTOdjFWEvQrRDNXlCxgMbVozIkfam(video_InfoTag,tLTOdjFWEvQrRDNXlCxgMbVozIkfYq[tLTOdjFWEvQrRDNXlCxgMbVozIkfnP]['func'])(tLTOdjFWEvQrRDNXlCxgMbVozIkfnu)
   elif tLTOdjFWEvQrRDNXlCxgMbVozIkfYq[tLTOdjFWEvQrRDNXlCxgMbVozIkfnP]['type']=='actor':
    if value!=[]:
     tLTOdjFWEvQrRDNXlCxgMbVozIkfam(video_InfoTag,tLTOdjFWEvQrRDNXlCxgMbVozIkfYq[tLTOdjFWEvQrRDNXlCxgMbVozIkfnP]['func'])([xbmc.Actor(name)for name in value])
   elif tLTOdjFWEvQrRDNXlCxgMbVozIkfYq[tLTOdjFWEvQrRDNXlCxgMbVozIkfnP]['type']=='list':
    if tLTOdjFWEvQrRDNXlCxgMbVozIkfaH(value)==tLTOdjFWEvQrRDNXlCxgMbVozIkfaP:
     tLTOdjFWEvQrRDNXlCxgMbVozIkfam(video_InfoTag,tLTOdjFWEvQrRDNXlCxgMbVozIkfYq[tLTOdjFWEvQrRDNXlCxgMbVozIkfnP]['func'])(value)
    else:
     tLTOdjFWEvQrRDNXlCxgMbVozIkfam(video_InfoTag,tLTOdjFWEvQrRDNXlCxgMbVozIkfYq[tLTOdjFWEvQrRDNXlCxgMbVozIkfnP]['func'])([value])
 def dp_Main_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA):
  (tLTOdjFWEvQrRDNXlCxgMbVozIkfYi,tLTOdjFWEvQrRDNXlCxgMbVozIkfYw,tLTOdjFWEvQrRDNXlCxgMbVozIkfYh,tLTOdjFWEvQrRDNXlCxgMbVozIkfnY,tLTOdjFWEvQrRDNXlCxgMbVozIkfnc)=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.get_settings_totalsearch()
  for tLTOdjFWEvQrRDNXlCxgMbVozIkfnS in tLTOdjFWEvQrRDNXlCxgMbVozIkfYc:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfns=tLTOdjFWEvQrRDNXlCxgMbVozIkfnS.get('title')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfne=''
   if tLTOdjFWEvQrRDNXlCxgMbVozIkfnS.get('mode')=='SEARCH_GROUP' and tLTOdjFWEvQrRDNXlCxgMbVozIkfYi ==tLTOdjFWEvQrRDNXlCxgMbVozIkfaA:continue
   elif tLTOdjFWEvQrRDNXlCxgMbVozIkfnS.get('mode')=='SEARCH_HISTORY' and tLTOdjFWEvQrRDNXlCxgMbVozIkfYw==tLTOdjFWEvQrRDNXlCxgMbVozIkfaA:continue
   elif tLTOdjFWEvQrRDNXlCxgMbVozIkfnS.get('mode')=='TOTAL_SEARCH' and tLTOdjFWEvQrRDNXlCxgMbVozIkfYh ==tLTOdjFWEvQrRDNXlCxgMbVozIkfaA:continue
   elif tLTOdjFWEvQrRDNXlCxgMbVozIkfnS.get('mode')=='TOTAL_HISTORY' and tLTOdjFWEvQrRDNXlCxgMbVozIkfnY==tLTOdjFWEvQrRDNXlCxgMbVozIkfaA:continue
   elif tLTOdjFWEvQrRDNXlCxgMbVozIkfnS.get('mode')=='MENU_BOOKMARK' and tLTOdjFWEvQrRDNXlCxgMbVozIkfnc==tLTOdjFWEvQrRDNXlCxgMbVozIkfaA:continue
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB={'mode':tLTOdjFWEvQrRDNXlCxgMbVozIkfnS.get('mode'),'sCode':tLTOdjFWEvQrRDNXlCxgMbVozIkfnS.get('sCode'),'sIndex':tLTOdjFWEvQrRDNXlCxgMbVozIkfnS.get('sIndex'),'sType':tLTOdjFWEvQrRDNXlCxgMbVozIkfnS.get('sType'),'suburl':tLTOdjFWEvQrRDNXlCxgMbVozIkfnS.get('suburl'),'subapi':tLTOdjFWEvQrRDNXlCxgMbVozIkfnS.get('subapi'),'page':tLTOdjFWEvQrRDNXlCxgMbVozIkfnS.get('page'),'orderby':tLTOdjFWEvQrRDNXlCxgMbVozIkfnS.get('orderby'),'ordernm':tLTOdjFWEvQrRDNXlCxgMbVozIkfnS.get('ordernm')}
   if tLTOdjFWEvQrRDNXlCxgMbVozIkfnS.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    tLTOdjFWEvQrRDNXlCxgMbVozIkfnG=tLTOdjFWEvQrRDNXlCxgMbVozIkfaA
    tLTOdjFWEvQrRDNXlCxgMbVozIkfny =tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ
   else:
    tLTOdjFWEvQrRDNXlCxgMbVozIkfnG=tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ
    tLTOdjFWEvQrRDNXlCxgMbVozIkfny =tLTOdjFWEvQrRDNXlCxgMbVozIkfaA
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnp={'title':tLTOdjFWEvQrRDNXlCxgMbVozIkfns,'plot':tLTOdjFWEvQrRDNXlCxgMbVozIkfns}
   if tLTOdjFWEvQrRDNXlCxgMbVozIkfnS.get('mode')=='XXX':tLTOdjFWEvQrRDNXlCxgMbVozIkfnp=tLTOdjFWEvQrRDNXlCxgMbVozIkfaK
   if 'icon' in tLTOdjFWEvQrRDNXlCxgMbVozIkfnS:tLTOdjFWEvQrRDNXlCxgMbVozIkfne=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',tLTOdjFWEvQrRDNXlCxgMbVozIkfnS.get('icon')) 
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.add_dir(tLTOdjFWEvQrRDNXlCxgMbVozIkfns,sublabel='',img=tLTOdjFWEvQrRDNXlCxgMbVozIkfne,infoLabels=tLTOdjFWEvQrRDNXlCxgMbVozIkfnp,isFolder=tLTOdjFWEvQrRDNXlCxgMbVozIkfnG,params=tLTOdjFWEvQrRDNXlCxgMbVozIkfnB,isLink=tLTOdjFWEvQrRDNXlCxgMbVozIkfny)
  xbmcplugin.endOfDirectory(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA._addon_handle,cacheToDisc=tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ)
 def dp_Search_Group(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA,args):
  if 'search_key' in args:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnh=args.get('search_key')
  else:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnh=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not tLTOdjFWEvQrRDNXlCxgMbVozIkfnh:
    return
  for tLTOdjFWEvQrRDNXlCxgMbVozIkfcY in tLTOdjFWEvQrRDNXlCxgMbVozIkfYU:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfcn =tLTOdjFWEvQrRDNXlCxgMbVozIkfcY.get('mode')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfcU=tLTOdjFWEvQrRDNXlCxgMbVozIkfcY.get('sType')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfns=tLTOdjFWEvQrRDNXlCxgMbVozIkfcY.get('title')
   (tLTOdjFWEvQrRDNXlCxgMbVozIkfcK,tLTOdjFWEvQrRDNXlCxgMbVozIkfcq)=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.Get_Search_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfnh,tLTOdjFWEvQrRDNXlCxgMbVozIkfcU,1,exclusion21=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.get_settings_exclusion21())
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnp={'plot':'검색어 : '+tLTOdjFWEvQrRDNXlCxgMbVozIkfnh+'\n\n'+tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.Search_FreeList(tLTOdjFWEvQrRDNXlCxgMbVozIkfcK)}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB={'mode':tLTOdjFWEvQrRDNXlCxgMbVozIkfcn,'sType':tLTOdjFWEvQrRDNXlCxgMbVozIkfcU,'search_key':tLTOdjFWEvQrRDNXlCxgMbVozIkfnh,'page':'1',}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.add_dir(tLTOdjFWEvQrRDNXlCxgMbVozIkfns,sublabel='',img='',infoLabels=tLTOdjFWEvQrRDNXlCxgMbVozIkfnp,isFolder=tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ,params=tLTOdjFWEvQrRDNXlCxgMbVozIkfnB)
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfau(tLTOdjFWEvQrRDNXlCxgMbVozIkfYU)>0:xbmcplugin.endOfDirectory(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA._addon_handle,cacheToDisc=tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ)
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.Save_Searched_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfnh)
 def Search_FreeList(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA,search_list):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfcJ=''
  tLTOdjFWEvQrRDNXlCxgMbVozIkfca=7
  try:
   if tLTOdjFWEvQrRDNXlCxgMbVozIkfau(search_list)==0:return '검색결과 없음'
   for i in tLTOdjFWEvQrRDNXlCxgMbVozIkfaS(tLTOdjFWEvQrRDNXlCxgMbVozIkfau(search_list)):
    if i>=tLTOdjFWEvQrRDNXlCxgMbVozIkfca:
     tLTOdjFWEvQrRDNXlCxgMbVozIkfcJ=tLTOdjFWEvQrRDNXlCxgMbVozIkfcJ+'...'
     break
    tLTOdjFWEvQrRDNXlCxgMbVozIkfcJ=tLTOdjFWEvQrRDNXlCxgMbVozIkfcJ+search_list[i]['title']+'\n'
  except:
   return ''
  return tLTOdjFWEvQrRDNXlCxgMbVozIkfcJ
 def dp_Watch_Group(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA,args):
  for tLTOdjFWEvQrRDNXlCxgMbVozIkfcA in tLTOdjFWEvQrRDNXlCxgMbVozIkfYK:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfns=tLTOdjFWEvQrRDNXlCxgMbVozIkfcA.get('title')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB={'mode':tLTOdjFWEvQrRDNXlCxgMbVozIkfcA.get('mode'),'sType':tLTOdjFWEvQrRDNXlCxgMbVozIkfcA.get('sType')}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.add_dir(tLTOdjFWEvQrRDNXlCxgMbVozIkfns,sublabel='',img='',infoLabels=tLTOdjFWEvQrRDNXlCxgMbVozIkfaK,isFolder=tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ,params=tLTOdjFWEvQrRDNXlCxgMbVozIkfnB)
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfau(tLTOdjFWEvQrRDNXlCxgMbVozIkfYK)>0:xbmcplugin.endOfDirectory(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA._addon_handle,cacheToDisc=tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ)
 def dp_Search_History(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA,args):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfcH=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.Load_List_File('search')
  for tLTOdjFWEvQrRDNXlCxgMbVozIkfcs in tLTOdjFWEvQrRDNXlCxgMbVozIkfcH:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfcm=tLTOdjFWEvQrRDNXlCxgMbVozIkfas(urllib.parse.parse_qsl(tLTOdjFWEvQrRDNXlCxgMbVozIkfcs))
   tLTOdjFWEvQrRDNXlCxgMbVozIkfcP=tLTOdjFWEvQrRDNXlCxgMbVozIkfcm.get('skey').strip()
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB={'mode':'SEARCH_GROUP','search_key':tLTOdjFWEvQrRDNXlCxgMbVozIkfcP,}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfcu={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':tLTOdjFWEvQrRDNXlCxgMbVozIkfcP,'vType':'-',}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfcS=urllib.parse.urlencode(tLTOdjFWEvQrRDNXlCxgMbVozIkfcu)
   tLTOdjFWEvQrRDNXlCxgMbVozIkfce=[('선택된 검색어 ( %s ) 삭제'%(tLTOdjFWEvQrRDNXlCxgMbVozIkfcP),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(tLTOdjFWEvQrRDNXlCxgMbVozIkfcS))]
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.add_dir(tLTOdjFWEvQrRDNXlCxgMbVozIkfcP,sublabel='',img=tLTOdjFWEvQrRDNXlCxgMbVozIkfaK,infoLabels=tLTOdjFWEvQrRDNXlCxgMbVozIkfaK,isFolder=tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ,params=tLTOdjFWEvQrRDNXlCxgMbVozIkfnB,ContextMenu=tLTOdjFWEvQrRDNXlCxgMbVozIkfce)
  tLTOdjFWEvQrRDNXlCxgMbVozIkfcB={'plot':'검색목록 전체를 삭제합니다.'}
  tLTOdjFWEvQrRDNXlCxgMbVozIkfns='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  tLTOdjFWEvQrRDNXlCxgMbVozIkfnB={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  tLTOdjFWEvQrRDNXlCxgMbVozIkfne=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.add_dir(tLTOdjFWEvQrRDNXlCxgMbVozIkfns,sublabel='',img=tLTOdjFWEvQrRDNXlCxgMbVozIkfne,infoLabels=tLTOdjFWEvQrRDNXlCxgMbVozIkfcB,isFolder=tLTOdjFWEvQrRDNXlCxgMbVozIkfaA,params=tLTOdjFWEvQrRDNXlCxgMbVozIkfnB,isLink=tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ)
  xbmcplugin.endOfDirectory(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA._addon_handle,cacheToDisc=tLTOdjFWEvQrRDNXlCxgMbVozIkfaA)
 def dp_Search_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA,args):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfcU =args.get('sType')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfcG =tLTOdjFWEvQrRDNXlCxgMbVozIkfaq(args.get('page'))
  if 'search_key' in args:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnh=args.get('search_key')
  else:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnh=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not tLTOdjFWEvQrRDNXlCxgMbVozIkfnh:
    xbmcplugin.endOfDirectory(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA._addon_handle)
    return
  tLTOdjFWEvQrRDNXlCxgMbVozIkfcy,tLTOdjFWEvQrRDNXlCxgMbVozIkfcq=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.Get_Search_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfnh,tLTOdjFWEvQrRDNXlCxgMbVozIkfcU,tLTOdjFWEvQrRDNXlCxgMbVozIkfcG,exclusion21=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.get_settings_exclusion21())
  for tLTOdjFWEvQrRDNXlCxgMbVozIkfcp in tLTOdjFWEvQrRDNXlCxgMbVozIkfcy:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfci =tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('videoid')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfcw =tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('vidtype')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfns =tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('title')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfch=tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('thumbnail')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUY =tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('age')
   if tLTOdjFWEvQrRDNXlCxgMbVozIkfUY=='18' or tLTOdjFWEvQrRDNXlCxgMbVozIkfUY=='19' or tLTOdjFWEvQrRDNXlCxgMbVozIkfUY=='21':tLTOdjFWEvQrRDNXlCxgMbVozIkfns+=' (%s)'%(tLTOdjFWEvQrRDNXlCxgMbVozIkfUY)
   tLTOdjFWEvQrRDNXlCxgMbVozIkfcB={'mediatype':'tvshow' if tLTOdjFWEvQrRDNXlCxgMbVozIkfcU=='vod' else 'movie','mpaa':tLTOdjFWEvQrRDNXlCxgMbVozIkfUY,'title':tLTOdjFWEvQrRDNXlCxgMbVozIkfns,'plot':tLTOdjFWEvQrRDNXlCxgMbVozIkfns}
   if tLTOdjFWEvQrRDNXlCxgMbVozIkfcU=='vod':
    tLTOdjFWEvQrRDNXlCxgMbVozIkfnB={'mode':'EPISODE_LIST','seasonid':tLTOdjFWEvQrRDNXlCxgMbVozIkfci,'page':'1',}
    tLTOdjFWEvQrRDNXlCxgMbVozIkfnG=tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ
   else:
    tLTOdjFWEvQrRDNXlCxgMbVozIkfnB={'mode':'MOVIE','contentid':tLTOdjFWEvQrRDNXlCxgMbVozIkfci,'title':tLTOdjFWEvQrRDNXlCxgMbVozIkfns,'thumbnail':tLTOdjFWEvQrRDNXlCxgMbVozIkfch,'age':tLTOdjFWEvQrRDNXlCxgMbVozIkfUY,}
    tLTOdjFWEvQrRDNXlCxgMbVozIkfnG=tLTOdjFWEvQrRDNXlCxgMbVozIkfaA
   tLTOdjFWEvQrRDNXlCxgMbVozIkfce=[]
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUn={'mode':'VIEW_DETAIL','values':{'videoid':tLTOdjFWEvQrRDNXlCxgMbVozIkfci,'vidtype':'tvshow' if tLTOdjFWEvQrRDNXlCxgMbVozIkfcU=='vod' else 'movie','contenttype':tLTOdjFWEvQrRDNXlCxgMbVozIkfcw,}}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUc=json.dumps(tLTOdjFWEvQrRDNXlCxgMbVozIkfUn,separators=(',',':'))
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUc=base64.standard_b64encode(tLTOdjFWEvQrRDNXlCxgMbVozIkfUc.encode()).decode('utf-8')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUc=tLTOdjFWEvQrRDNXlCxgMbVozIkfUc.replace('+','%2B')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUK='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(tLTOdjFWEvQrRDNXlCxgMbVozIkfUc)
   tLTOdjFWEvQrRDNXlCxgMbVozIkfce.append(('상세정보 조회',tLTOdjFWEvQrRDNXlCxgMbVozIkfUK))
   if tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.get_settings_makebookmark():
    tLTOdjFWEvQrRDNXlCxgMbVozIkfUn={'videoid':tLTOdjFWEvQrRDNXlCxgMbVozIkfci,'vidtype':'tvshow' if tLTOdjFWEvQrRDNXlCxgMbVozIkfcU=='vod' else 'movie','vtitle':tLTOdjFWEvQrRDNXlCxgMbVozIkfns,'vsubtitle':'','contenttype':tLTOdjFWEvQrRDNXlCxgMbVozIkfcw,}
    tLTOdjFWEvQrRDNXlCxgMbVozIkfUq=json.dumps(tLTOdjFWEvQrRDNXlCxgMbVozIkfUn)
    tLTOdjFWEvQrRDNXlCxgMbVozIkfUq=urllib.parse.quote(tLTOdjFWEvQrRDNXlCxgMbVozIkfUq)
    tLTOdjFWEvQrRDNXlCxgMbVozIkfUK='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(tLTOdjFWEvQrRDNXlCxgMbVozIkfUq)
    tLTOdjFWEvQrRDNXlCxgMbVozIkfce.append(('(통합) 찜 영상에 추가',tLTOdjFWEvQrRDNXlCxgMbVozIkfUK))
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.add_dir(tLTOdjFWEvQrRDNXlCxgMbVozIkfns,sublabel='',img=tLTOdjFWEvQrRDNXlCxgMbVozIkfch,infoLabels=tLTOdjFWEvQrRDNXlCxgMbVozIkfcB,isFolder=tLTOdjFWEvQrRDNXlCxgMbVozIkfnG,params=tLTOdjFWEvQrRDNXlCxgMbVozIkfnB,ContextMenu=tLTOdjFWEvQrRDNXlCxgMbVozIkfce)
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfcq:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB['mode'] ='SEARCH_LIST' 
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB['sType']=tLTOdjFWEvQrRDNXlCxgMbVozIkfcU 
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB['page'] =tLTOdjFWEvQrRDNXlCxgMbVozIkfae(tLTOdjFWEvQrRDNXlCxgMbVozIkfcG+1)
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB['search_key']=tLTOdjFWEvQrRDNXlCxgMbVozIkfnh
   tLTOdjFWEvQrRDNXlCxgMbVozIkfns='[B]%s >>[/B]'%'다음 페이지'
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUJ=tLTOdjFWEvQrRDNXlCxgMbVozIkfae(tLTOdjFWEvQrRDNXlCxgMbVozIkfcG+1)
   tLTOdjFWEvQrRDNXlCxgMbVozIkfne=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.add_dir(tLTOdjFWEvQrRDNXlCxgMbVozIkfns,sublabel=tLTOdjFWEvQrRDNXlCxgMbVozIkfUJ,img=tLTOdjFWEvQrRDNXlCxgMbVozIkfne,infoLabels=tLTOdjFWEvQrRDNXlCxgMbVozIkfaK,isFolder=tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ,params=tLTOdjFWEvQrRDNXlCxgMbVozIkfnB)
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfcU=='movie':xbmcplugin.setContent(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA._addon_handle,'movies')
  else:xbmcplugin.setContent(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA._addon_handle,cacheToDisc=tLTOdjFWEvQrRDNXlCxgMbVozIkfaA)
 def dp_Watch_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA,args):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfcU =args.get('sType')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfna=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.get_settings_direct_replay()
  tLTOdjFWEvQrRDNXlCxgMbVozIkfcy=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.Load_List_File(tLTOdjFWEvQrRDNXlCxgMbVozIkfcU)
  for tLTOdjFWEvQrRDNXlCxgMbVozIkfcp in tLTOdjFWEvQrRDNXlCxgMbVozIkfcy:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfcm=tLTOdjFWEvQrRDNXlCxgMbVozIkfas(urllib.parse.parse_qsl(tLTOdjFWEvQrRDNXlCxgMbVozIkfcp))
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUa =tLTOdjFWEvQrRDNXlCxgMbVozIkfcm.get('code').strip()
   tLTOdjFWEvQrRDNXlCxgMbVozIkfns =tLTOdjFWEvQrRDNXlCxgMbVozIkfcm.get('title').strip()
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUJ =tLTOdjFWEvQrRDNXlCxgMbVozIkfcm.get('subtitle').strip()
   if tLTOdjFWEvQrRDNXlCxgMbVozIkfUJ=='None':tLTOdjFWEvQrRDNXlCxgMbVozIkfUJ=''
   tLTOdjFWEvQrRDNXlCxgMbVozIkfch=tLTOdjFWEvQrRDNXlCxgMbVozIkfcm.get('img').strip()
   tLTOdjFWEvQrRDNXlCxgMbVozIkfci =tLTOdjFWEvQrRDNXlCxgMbVozIkfcm.get('videoid').strip()
   try:
    tLTOdjFWEvQrRDNXlCxgMbVozIkfch=tLTOdjFWEvQrRDNXlCxgMbVozIkfch.replace('\'','\"')
    tLTOdjFWEvQrRDNXlCxgMbVozIkfch=json.loads(tLTOdjFWEvQrRDNXlCxgMbVozIkfch)
   except:
    tLTOdjFWEvQrRDNXlCxgMbVozIkfaK
   tLTOdjFWEvQrRDNXlCxgMbVozIkfcB={'plot':'%s\n%s'%(tLTOdjFWEvQrRDNXlCxgMbVozIkfns,tLTOdjFWEvQrRDNXlCxgMbVozIkfUJ)}
   if tLTOdjFWEvQrRDNXlCxgMbVozIkfcU=='vod':
    if tLTOdjFWEvQrRDNXlCxgMbVozIkfna==tLTOdjFWEvQrRDNXlCxgMbVozIkfaA or tLTOdjFWEvQrRDNXlCxgMbVozIkfci==tLTOdjFWEvQrRDNXlCxgMbVozIkfaK:
     tLTOdjFWEvQrRDNXlCxgMbVozIkfcB['mediatype']='tvshow'
     tLTOdjFWEvQrRDNXlCxgMbVozIkfnB={'mode':'SEASON_LIST','videoid':tLTOdjFWEvQrRDNXlCxgMbVozIkfci,'vidtype':'contentid',}
     tLTOdjFWEvQrRDNXlCxgMbVozIkfnG=tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ
    else:
     tLTOdjFWEvQrRDNXlCxgMbVozIkfcB['mediatype']='episode'
     tLTOdjFWEvQrRDNXlCxgMbVozIkfnB={'mode':'VOD','programid':tLTOdjFWEvQrRDNXlCxgMbVozIkfUa,'contentid':tLTOdjFWEvQrRDNXlCxgMbVozIkfci,'title':tLTOdjFWEvQrRDNXlCxgMbVozIkfns,'subtitle':tLTOdjFWEvQrRDNXlCxgMbVozIkfUJ,'thumbnail':tLTOdjFWEvQrRDNXlCxgMbVozIkfch}
     tLTOdjFWEvQrRDNXlCxgMbVozIkfnG=tLTOdjFWEvQrRDNXlCxgMbVozIkfaA
   else:
    tLTOdjFWEvQrRDNXlCxgMbVozIkfcB['mediatype']='movie'
    tLTOdjFWEvQrRDNXlCxgMbVozIkfnB={'mode':'MOVIE','contentid':tLTOdjFWEvQrRDNXlCxgMbVozIkfUa,'title':tLTOdjFWEvQrRDNXlCxgMbVozIkfns,'subtitle':tLTOdjFWEvQrRDNXlCxgMbVozIkfUJ,'thumbnail':tLTOdjFWEvQrRDNXlCxgMbVozIkfch}
    tLTOdjFWEvQrRDNXlCxgMbVozIkfnG=tLTOdjFWEvQrRDNXlCxgMbVozIkfaA
   tLTOdjFWEvQrRDNXlCxgMbVozIkfcu={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':tLTOdjFWEvQrRDNXlCxgMbVozIkfUa,'vType':tLTOdjFWEvQrRDNXlCxgMbVozIkfcU,}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfcS=urllib.parse.urlencode(tLTOdjFWEvQrRDNXlCxgMbVozIkfcu)
   tLTOdjFWEvQrRDNXlCxgMbVozIkfce=[('선택된 시청이력 ( %s ) 삭제'%(tLTOdjFWEvQrRDNXlCxgMbVozIkfns),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(tLTOdjFWEvQrRDNXlCxgMbVozIkfcS))]
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.add_dir(tLTOdjFWEvQrRDNXlCxgMbVozIkfns,sublabel=tLTOdjFWEvQrRDNXlCxgMbVozIkfUJ,img=tLTOdjFWEvQrRDNXlCxgMbVozIkfch,infoLabels=tLTOdjFWEvQrRDNXlCxgMbVozIkfcB,isFolder=tLTOdjFWEvQrRDNXlCxgMbVozIkfnG,params=tLTOdjFWEvQrRDNXlCxgMbVozIkfnB,ContextMenu=tLTOdjFWEvQrRDNXlCxgMbVozIkfce)
  tLTOdjFWEvQrRDNXlCxgMbVozIkfcB={'plot':'시청목록을 삭제합니다.'}
  tLTOdjFWEvQrRDNXlCxgMbVozIkfns='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  tLTOdjFWEvQrRDNXlCxgMbVozIkfnB={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':tLTOdjFWEvQrRDNXlCxgMbVozIkfcU,}
  tLTOdjFWEvQrRDNXlCxgMbVozIkfne=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.add_dir(tLTOdjFWEvQrRDNXlCxgMbVozIkfns,sublabel='',img=tLTOdjFWEvQrRDNXlCxgMbVozIkfne,infoLabels=tLTOdjFWEvQrRDNXlCxgMbVozIkfcB,isFolder=tLTOdjFWEvQrRDNXlCxgMbVozIkfaA,params=tLTOdjFWEvQrRDNXlCxgMbVozIkfnB,isLink=tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ)
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfcU=='movie':xbmcplugin.setContent(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA._addon_handle,'movies')
  else:xbmcplugin.setContent(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA._addon_handle,cacheToDisc=tLTOdjFWEvQrRDNXlCxgMbVozIkfaA)
 def Load_List_File(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA,stype): 
  try:
   if stype=='search':
    tLTOdjFWEvQrRDNXlCxgMbVozIkfUA=tLTOdjFWEvQrRDNXlCxgMbVozIkfYa
   elif stype in['vod','movie']:
    tLTOdjFWEvQrRDNXlCxgMbVozIkfUA=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   else:
    return[]
   fp=tLTOdjFWEvQrRDNXlCxgMbVozIkfaB(tLTOdjFWEvQrRDNXlCxgMbVozIkfUA,'r',-1,'utf-8')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUH=fp.readlines()
   fp.close()
  except:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUH=[]
  return tLTOdjFWEvQrRDNXlCxgMbVozIkfUH
 def Save_Watched_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA,tLTOdjFWEvQrRDNXlCxgMbVozIkfJP,tLTOdjFWEvQrRDNXlCxgMbVozIkfYm):
  try:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUs=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%tLTOdjFWEvQrRDNXlCxgMbVozIkfJP))
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUm=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.Load_List_File(tLTOdjFWEvQrRDNXlCxgMbVozIkfJP) 
   fp=tLTOdjFWEvQrRDNXlCxgMbVozIkfaB(tLTOdjFWEvQrRDNXlCxgMbVozIkfUs,'w',-1,'utf-8')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUP=urllib.parse.urlencode(tLTOdjFWEvQrRDNXlCxgMbVozIkfYm)
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUP=tLTOdjFWEvQrRDNXlCxgMbVozIkfUP+'\n'
   fp.write(tLTOdjFWEvQrRDNXlCxgMbVozIkfUP)
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUu=0
   for tLTOdjFWEvQrRDNXlCxgMbVozIkfUS in tLTOdjFWEvQrRDNXlCxgMbVozIkfUm:
    tLTOdjFWEvQrRDNXlCxgMbVozIkfUe=tLTOdjFWEvQrRDNXlCxgMbVozIkfas(urllib.parse.parse_qsl(tLTOdjFWEvQrRDNXlCxgMbVozIkfUS))
    tLTOdjFWEvQrRDNXlCxgMbVozIkfUB=tLTOdjFWEvQrRDNXlCxgMbVozIkfYm.get('code').strip()
    tLTOdjFWEvQrRDNXlCxgMbVozIkfUG=tLTOdjFWEvQrRDNXlCxgMbVozIkfUe.get('code').strip()
    if tLTOdjFWEvQrRDNXlCxgMbVozIkfJP=='vod' and tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.get_settings_direct_replay()==tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ:
     tLTOdjFWEvQrRDNXlCxgMbVozIkfUB=tLTOdjFWEvQrRDNXlCxgMbVozIkfYm.get('videoid').strip()
     tLTOdjFWEvQrRDNXlCxgMbVozIkfUG=tLTOdjFWEvQrRDNXlCxgMbVozIkfUe.get('videoid').strip()if tLTOdjFWEvQrRDNXlCxgMbVozIkfUG!=tLTOdjFWEvQrRDNXlCxgMbVozIkfaK else '-'
    if tLTOdjFWEvQrRDNXlCxgMbVozIkfUB!=tLTOdjFWEvQrRDNXlCxgMbVozIkfUG:
     fp.write(tLTOdjFWEvQrRDNXlCxgMbVozIkfUS)
     tLTOdjFWEvQrRDNXlCxgMbVozIkfUu+=1
     if tLTOdjFWEvQrRDNXlCxgMbVozIkfUu>=50:break
   fp.close()
  except:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfaK
 def dp_History_Remove(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA,args):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfUy=args.get('delType')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfUp =args.get('sKey')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfUi =args.get('vType')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYu=xbmcgui.Dialog()
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfUy=='SEARCH_ALL':
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUw=tLTOdjFWEvQrRDNXlCxgMbVozIkfYu.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif tLTOdjFWEvQrRDNXlCxgMbVozIkfUy=='SEARCH_ONE':
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUw=tLTOdjFWEvQrRDNXlCxgMbVozIkfYu.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif tLTOdjFWEvQrRDNXlCxgMbVozIkfUy=='WATCH_ALL':
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUw=tLTOdjFWEvQrRDNXlCxgMbVozIkfYu.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif tLTOdjFWEvQrRDNXlCxgMbVozIkfUy=='WATCH_ONE':
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUw=tLTOdjFWEvQrRDNXlCxgMbVozIkfYu.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfUw==tLTOdjFWEvQrRDNXlCxgMbVozIkfaA:sys.exit()
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfUy=='SEARCH_ALL':
   if os.path.isfile(tLTOdjFWEvQrRDNXlCxgMbVozIkfYa):os.remove(tLTOdjFWEvQrRDNXlCxgMbVozIkfYa)
  elif tLTOdjFWEvQrRDNXlCxgMbVozIkfUy=='SEARCH_ONE':
   try:
    tLTOdjFWEvQrRDNXlCxgMbVozIkfUA=tLTOdjFWEvQrRDNXlCxgMbVozIkfYa
    tLTOdjFWEvQrRDNXlCxgMbVozIkfUm=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.Load_List_File('search') 
    fp=tLTOdjFWEvQrRDNXlCxgMbVozIkfaB(tLTOdjFWEvQrRDNXlCxgMbVozIkfUA,'w',-1,'utf-8')
    for tLTOdjFWEvQrRDNXlCxgMbVozIkfUS in tLTOdjFWEvQrRDNXlCxgMbVozIkfUm:
     tLTOdjFWEvQrRDNXlCxgMbVozIkfUe=tLTOdjFWEvQrRDNXlCxgMbVozIkfas(urllib.parse.parse_qsl(tLTOdjFWEvQrRDNXlCxgMbVozIkfUS))
     tLTOdjFWEvQrRDNXlCxgMbVozIkfUh=tLTOdjFWEvQrRDNXlCxgMbVozIkfUe.get('skey').strip()
     if tLTOdjFWEvQrRDNXlCxgMbVozIkfUp!=tLTOdjFWEvQrRDNXlCxgMbVozIkfUh:
      fp.write(tLTOdjFWEvQrRDNXlCxgMbVozIkfUS)
    fp.close()
   except:
    tLTOdjFWEvQrRDNXlCxgMbVozIkfaK
  elif tLTOdjFWEvQrRDNXlCxgMbVozIkfUy=='WATCH_ALL':
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUA=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%tLTOdjFWEvQrRDNXlCxgMbVozIkfUi))
   if os.path.isfile(tLTOdjFWEvQrRDNXlCxgMbVozIkfUA):os.remove(tLTOdjFWEvQrRDNXlCxgMbVozIkfUA)
  elif tLTOdjFWEvQrRDNXlCxgMbVozIkfUy=='WATCH_ONE':
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUA=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%tLTOdjFWEvQrRDNXlCxgMbVozIkfUi))
   try:
    tLTOdjFWEvQrRDNXlCxgMbVozIkfUm=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.Load_List_File(tLTOdjFWEvQrRDNXlCxgMbVozIkfUi) 
    fp=tLTOdjFWEvQrRDNXlCxgMbVozIkfaB(tLTOdjFWEvQrRDNXlCxgMbVozIkfUA,'w',-1,'utf-8')
    for tLTOdjFWEvQrRDNXlCxgMbVozIkfUS in tLTOdjFWEvQrRDNXlCxgMbVozIkfUm:
     tLTOdjFWEvQrRDNXlCxgMbVozIkfUe=tLTOdjFWEvQrRDNXlCxgMbVozIkfas(urllib.parse.parse_qsl(tLTOdjFWEvQrRDNXlCxgMbVozIkfUS))
     tLTOdjFWEvQrRDNXlCxgMbVozIkfUh=tLTOdjFWEvQrRDNXlCxgMbVozIkfUe.get('code').strip()
     if tLTOdjFWEvQrRDNXlCxgMbVozIkfUp!=tLTOdjFWEvQrRDNXlCxgMbVozIkfUh:
      fp.write(tLTOdjFWEvQrRDNXlCxgMbVozIkfUS)
    fp.close()
   except:
    tLTOdjFWEvQrRDNXlCxgMbVozIkfaK
  xbmc.executebuiltin("Container.Refresh")
 def Save_Searched_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA,tLTOdjFWEvQrRDNXlCxgMbVozIkfnh):
  try:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfKY=tLTOdjFWEvQrRDNXlCxgMbVozIkfYa
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUm=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.Load_List_File('search') 
   tLTOdjFWEvQrRDNXlCxgMbVozIkfKn={'skey':tLTOdjFWEvQrRDNXlCxgMbVozIkfnh.strip()}
   fp=tLTOdjFWEvQrRDNXlCxgMbVozIkfaB(tLTOdjFWEvQrRDNXlCxgMbVozIkfKY,'w',-1,'utf-8')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUP=urllib.parse.urlencode(tLTOdjFWEvQrRDNXlCxgMbVozIkfKn)
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUP=tLTOdjFWEvQrRDNXlCxgMbVozIkfUP+'\n'
   fp.write(tLTOdjFWEvQrRDNXlCxgMbVozIkfUP)
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUu=0
   for tLTOdjFWEvQrRDNXlCxgMbVozIkfUS in tLTOdjFWEvQrRDNXlCxgMbVozIkfUm:
    tLTOdjFWEvQrRDNXlCxgMbVozIkfUe=tLTOdjFWEvQrRDNXlCxgMbVozIkfas(urllib.parse.parse_qsl(tLTOdjFWEvQrRDNXlCxgMbVozIkfUS))
    tLTOdjFWEvQrRDNXlCxgMbVozIkfUB=tLTOdjFWEvQrRDNXlCxgMbVozIkfKn.get('skey').strip()
    tLTOdjFWEvQrRDNXlCxgMbVozIkfUG=tLTOdjFWEvQrRDNXlCxgMbVozIkfUe.get('skey').strip()
    if tLTOdjFWEvQrRDNXlCxgMbVozIkfUB!=tLTOdjFWEvQrRDNXlCxgMbVozIkfUG:
     fp.write(tLTOdjFWEvQrRDNXlCxgMbVozIkfUS)
     tLTOdjFWEvQrRDNXlCxgMbVozIkfUu+=1
     if tLTOdjFWEvQrRDNXlCxgMbVozIkfUu>=50:break
   fp.close()
  except:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfaK
 def dp_Global_Search(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA,args):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfcn=args.get('mode')
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfcn=='TOTAL_SEARCH':
   tLTOdjFWEvQrRDNXlCxgMbVozIkfKc='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfKc='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(tLTOdjFWEvQrRDNXlCxgMbVozIkfKc)
 def dp_Bookmark_Menu(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA,args):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfKc='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(tLTOdjFWEvQrRDNXlCxgMbVozIkfKc)
 def login_main(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA):
  (tLTOdjFWEvQrRDNXlCxgMbVozIkfKU,tLTOdjFWEvQrRDNXlCxgMbVozIkfKq,tLTOdjFWEvQrRDNXlCxgMbVozIkfKJ)=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.get_settings_account()
  if not(tLTOdjFWEvQrRDNXlCxgMbVozIkfKU and tLTOdjFWEvQrRDNXlCxgMbVozIkfKq):
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYu=xbmcgui.Dialog()
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUw=tLTOdjFWEvQrRDNXlCxgMbVozIkfYu.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if tLTOdjFWEvQrRDNXlCxgMbVozIkfUw==tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.cookiefile_check()==tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ:return
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   tLTOdjFWEvQrRDNXlCxgMbVozIkfKa=0
   while tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ:
    tLTOdjFWEvQrRDNXlCxgMbVozIkfKa+=1
    time.sleep(0.05)
    if tLTOdjFWEvQrRDNXlCxgMbVozIkfKa>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfKA=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.GetCredential(tLTOdjFWEvQrRDNXlCxgMbVozIkfKU,tLTOdjFWEvQrRDNXlCxgMbVozIkfKq,tLTOdjFWEvQrRDNXlCxgMbVozIkfKJ)
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfKA:tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfKA==tLTOdjFWEvQrRDNXlCxgMbVozIkfaA:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_setEpOrderby(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA,args):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfnA =args.get('orderby')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.set_winEpisodeOrderby(tLTOdjFWEvQrRDNXlCxgMbVozIkfnA)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA,args):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfcn =args.get('mode')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfKH =args.get('contentid')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfKs =args.get('pvrmode')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfKm=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.get_selQuality()
  tLTOdjFWEvQrRDNXlCxgMbVozIkfnU =tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.get_settings_play()
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.addon_log(tLTOdjFWEvQrRDNXlCxgMbVozIkfKH+' - '+tLTOdjFWEvQrRDNXlCxgMbVozIkfcn)
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfcn=='SPORTS':
   tLTOdjFWEvQrRDNXlCxgMbVozIkfKP=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.GetSportsURL(tLTOdjFWEvQrRDNXlCxgMbVozIkfKH,tLTOdjFWEvQrRDNXlCxgMbVozIkfKm)
  else:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfKP=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.GetStreamingURL(tLTOdjFWEvQrRDNXlCxgMbVozIkfcn,tLTOdjFWEvQrRDNXlCxgMbVozIkfKH,tLTOdjFWEvQrRDNXlCxgMbVozIkfKm,tLTOdjFWEvQrRDNXlCxgMbVozIkfKs,playOption=tLTOdjFWEvQrRDNXlCxgMbVozIkfnU)
  tLTOdjFWEvQrRDNXlCxgMbVozIkfKu=tLTOdjFWEvQrRDNXlCxgMbVozIkfKP['stream_cookie']
  tLTOdjFWEvQrRDNXlCxgMbVozIkfKS='{}|Cookie={}'.format(tLTOdjFWEvQrRDNXlCxgMbVozIkfKP['stream_url'],tLTOdjFWEvQrRDNXlCxgMbVozIkfKu)
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.addon_log(tLTOdjFWEvQrRDNXlCxgMbVozIkfKS)
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfKP['stream_url']=='':
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.addon_noti(__language__(30907).encode('utf8'))
   return
  tLTOdjFWEvQrRDNXlCxgMbVozIkfKe=xbmcgui.ListItem(path=tLTOdjFWEvQrRDNXlCxgMbVozIkfKS)
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfKP['stream_drm']:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.addon_log('!!streaming_drm!!')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfKB =inputstreamhelper.Helper('mpd',drm='widevine')
   if 'licensetoken' in tLTOdjFWEvQrRDNXlCxgMbVozIkfKP['stream_drm']:
    tLTOdjFWEvQrRDNXlCxgMbVozIkfKG=tLTOdjFWEvQrRDNXlCxgMbVozIkfKP['stream_drm']['licensetoken']
    tLTOdjFWEvQrRDNXlCxgMbVozIkfKy =tLTOdjFWEvQrRDNXlCxgMbVozIkfKP['stream_drm']['licenseurl']
    if tLTOdjFWEvQrRDNXlCxgMbVozIkfcn=='MOVIE':
     tLTOdjFWEvQrRDNXlCxgMbVozIkfKp='https://www.wavve.com/player/movie?movieid=%s'%tLTOdjFWEvQrRDNXlCxgMbVozIkfKH
    else:
     tLTOdjFWEvQrRDNXlCxgMbVozIkfKp='https://www.wavve.com/player/vod?programid=%s&page=1'%tLTOdjFWEvQrRDNXlCxgMbVozIkfKH
    tLTOdjFWEvQrRDNXlCxgMbVozIkfKi={'content-type':'application/octet-stream','origin':'https://www.wavve.com','License-Token':tLTOdjFWEvQrRDNXlCxgMbVozIkfKG,'referer':tLTOdjFWEvQrRDNXlCxgMbVozIkfKp,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.USER_AGENT,}
   else:
    tLTOdjFWEvQrRDNXlCxgMbVozIkfKG=tLTOdjFWEvQrRDNXlCxgMbVozIkfKP['stream_drm']['customdata']
    tLTOdjFWEvQrRDNXlCxgMbVozIkfKy =tLTOdjFWEvQrRDNXlCxgMbVozIkfKP['stream_drm']['drmhost']
    if tLTOdjFWEvQrRDNXlCxgMbVozIkfcn=='MOVIE':
     tLTOdjFWEvQrRDNXlCxgMbVozIkfKp='https://www.wavve.com/player/movie?movieid=%s'%tLTOdjFWEvQrRDNXlCxgMbVozIkfKH
    else:
     tLTOdjFWEvQrRDNXlCxgMbVozIkfKp='https://www.wavve.com/player/vod?programid=%s&page=1'%tLTOdjFWEvQrRDNXlCxgMbVozIkfKH
    tLTOdjFWEvQrRDNXlCxgMbVozIkfKi={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':tLTOdjFWEvQrRDNXlCxgMbVozIkfKG,'referer':tLTOdjFWEvQrRDNXlCxgMbVozIkfKp,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.USER_AGENT,}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfKw=tLTOdjFWEvQrRDNXlCxgMbVozIkfKy+'|'+urllib.parse.urlencode(tLTOdjFWEvQrRDNXlCxgMbVozIkfKi)+'|R{SSM}|'
   tLTOdjFWEvQrRDNXlCxgMbVozIkfKe.setProperty('inputstream',tLTOdjFWEvQrRDNXlCxgMbVozIkfKB.inputstream_addon)
   tLTOdjFWEvQrRDNXlCxgMbVozIkfKe.setProperty('inputstream.adaptive.manifest_type','mpd')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfKe.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfKe.setProperty('inputstream.adaptive.license_key',tLTOdjFWEvQrRDNXlCxgMbVozIkfKw)
   tLTOdjFWEvQrRDNXlCxgMbVozIkfKe.setProperty('inputstream.adaptive.stream_headers','user-agent={}&Cookie={}'.format(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.USER_AGENT,tLTOdjFWEvQrRDNXlCxgMbVozIkfKu))
  elif tLTOdjFWEvQrRDNXlCxgMbVozIkfcn in['VOD','MOVIE']:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfKe.setContentLookup(tLTOdjFWEvQrRDNXlCxgMbVozIkfaA)
   tLTOdjFWEvQrRDNXlCxgMbVozIkfKe.setMimeType('application/x-mpegURL')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfKe.setProperty('inputstream','inputstream.adaptive')
   if tLTOdjFWEvQrRDNXlCxgMbVozIkfKP['stream_action']=='hls':
    tLTOdjFWEvQrRDNXlCxgMbVozIkfKe.setProperty('inputstream.adaptive.manifest_type','hls')
   else:
    tLTOdjFWEvQrRDNXlCxgMbVozIkfKe.setProperty('inputstream.adaptive.manifest_type','mpd')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfKe.setProperty('inputstream.adaptive.stream_headers','user-agent={}&Cookie={}'.format(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.USER_AGENT,tLTOdjFWEvQrRDNXlCxgMbVozIkfKu))
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfKP['stream_vtt']:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfKe.setSubtitles([tLTOdjFWEvQrRDNXlCxgMbVozIkfKP['stream_vtt']])
  xbmcplugin.setResolvedUrl(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA._addon_handle,tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ,tLTOdjFWEvQrRDNXlCxgMbVozIkfKe)
  tLTOdjFWEvQrRDNXlCxgMbVozIkfKh=tLTOdjFWEvQrRDNXlCxgMbVozIkfaA
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfKP['stream_preview']:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.addon_noti(tLTOdjFWEvQrRDNXlCxgMbVozIkfKP['stream_preview'].encode('utf-8'))
   tLTOdjFWEvQrRDNXlCxgMbVozIkfKh=tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ
  else:
   if '/preview.' in urllib.parse.urlsplit(tLTOdjFWEvQrRDNXlCxgMbVozIkfKP['stream_url']).path:
    tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.addon_noti(__language__(30908).encode('utf8'))
    tLTOdjFWEvQrRDNXlCxgMbVozIkfKh=tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ
  try:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfqY=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and tLTOdjFWEvQrRDNXlCxgMbVozIkfKh==tLTOdjFWEvQrRDNXlCxgMbVozIkfaA and tLTOdjFWEvQrRDNXlCxgMbVozIkfqY!='-':
    tLTOdjFWEvQrRDNXlCxgMbVozIkfnB={'code':tLTOdjFWEvQrRDNXlCxgMbVozIkfqY,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.Save_Watched_List(args.get('mode').lower(),tLTOdjFWEvQrRDNXlCxgMbVozIkfnB)
  except:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfaK
 def logout(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYu=xbmcgui.Dialog()
  tLTOdjFWEvQrRDNXlCxgMbVozIkfUw=tLTOdjFWEvQrRDNXlCxgMbVozIkfYu.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfUw==tLTOdjFWEvQrRDNXlCxgMbVozIkfaA:sys.exit()
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.Init_WV_Total()
  if os.path.isfile(tLTOdjFWEvQrRDNXlCxgMbVozIkfYJ):os.remove(tLTOdjFWEvQrRDNXlCxgMbVozIkfYJ)
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfqn =tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.Get_Now_Datetime()
  tLTOdjFWEvQrRDNXlCxgMbVozIkfqc=tLTOdjFWEvQrRDNXlCxgMbVozIkfqn+datetime.timedelta(days=tLTOdjFWEvQrRDNXlCxgMbVozIkfaq(__addon__.getSetting('cache_ttl')))
  (tLTOdjFWEvQrRDNXlCxgMbVozIkfKU,tLTOdjFWEvQrRDNXlCxgMbVozIkfKq,tLTOdjFWEvQrRDNXlCxgMbVozIkfKJ)=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.get_settings_account()
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.Save_session_acount(tLTOdjFWEvQrRDNXlCxgMbVozIkfKU,tLTOdjFWEvQrRDNXlCxgMbVozIkfKq,tLTOdjFWEvQrRDNXlCxgMbVozIkfKJ)
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.WV['account']['token_limit']=tLTOdjFWEvQrRDNXlCxgMbVozIkfqc.strftime('%Y%m%d')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.JsonFile_Save(tLTOdjFWEvQrRDNXlCxgMbVozIkfYJ,tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.WV)
 def cookiefile_check(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.WV=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.JsonFile_Load(tLTOdjFWEvQrRDNXlCxgMbVozIkfYJ)
  if 'account' not in tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.WV:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.Init_WV_Total()
   return tLTOdjFWEvQrRDNXlCxgMbVozIkfaA
  if 'uuid' not in tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.WV.get('cookies'):
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.Init_WV_Total()
   return tLTOdjFWEvQrRDNXlCxgMbVozIkfaA
  (tLTOdjFWEvQrRDNXlCxgMbVozIkfqU,tLTOdjFWEvQrRDNXlCxgMbVozIkfqK,tLTOdjFWEvQrRDNXlCxgMbVozIkfqJ)=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.get_settings_account()
  (tLTOdjFWEvQrRDNXlCxgMbVozIkfqa,tLTOdjFWEvQrRDNXlCxgMbVozIkfqA,tLTOdjFWEvQrRDNXlCxgMbVozIkfqH)=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.Load_session_acount()
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfqU!=tLTOdjFWEvQrRDNXlCxgMbVozIkfqa or tLTOdjFWEvQrRDNXlCxgMbVozIkfqK!=tLTOdjFWEvQrRDNXlCxgMbVozIkfqA or tLTOdjFWEvQrRDNXlCxgMbVozIkfqJ!=tLTOdjFWEvQrRDNXlCxgMbVozIkfqH:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.Init_WV_Total()
   return tLTOdjFWEvQrRDNXlCxgMbVozIkfaA
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfaq(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))>tLTOdjFWEvQrRDNXlCxgMbVozIkfaq(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.WV['account']['token_limit']):
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.Init_WV_Total()
   return tLTOdjFWEvQrRDNXlCxgMbVozIkfaA
  return tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ
 def dp_LiveCatagory_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA,args):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfqs =args.get('sCode')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfqm=args.get('sIndex')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfcy,tLTOdjFWEvQrRDNXlCxgMbVozIkfqP=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.Get_LiveCatagory_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfqs,tLTOdjFWEvQrRDNXlCxgMbVozIkfqm)
  for tLTOdjFWEvQrRDNXlCxgMbVozIkfcp in tLTOdjFWEvQrRDNXlCxgMbVozIkfcy:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfns =tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('title')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB={'mode':'LIVE_LIST','genre':tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('genre'),'baseapi':tLTOdjFWEvQrRDNXlCxgMbVozIkfqP}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnp={'title':tLTOdjFWEvQrRDNXlCxgMbVozIkfns,'plot':tLTOdjFWEvQrRDNXlCxgMbVozIkfns}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.add_dir(tLTOdjFWEvQrRDNXlCxgMbVozIkfns,sublabel='',img='',infoLabels=tLTOdjFWEvQrRDNXlCxgMbVozIkfnp,isFolder=tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ,params=tLTOdjFWEvQrRDNXlCxgMbVozIkfnB)
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfau(tLTOdjFWEvQrRDNXlCxgMbVozIkfcy)>0:xbmcplugin.endOfDirectory(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA._addon_handle,cacheToDisc=tLTOdjFWEvQrRDNXlCxgMbVozIkfaA)
 def dp_MainCatagory_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA,args):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfqs =args.get('sCode')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfqm=args.get('sIndex')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfcU =args.get('sType')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfcy=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.Get_MainCatagory_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfqs,tLTOdjFWEvQrRDNXlCxgMbVozIkfqm,tLTOdjFWEvQrRDNXlCxgMbVozIkfcU)
  for tLTOdjFWEvQrRDNXlCxgMbVozIkfcp in tLTOdjFWEvQrRDNXlCxgMbVozIkfcy:
   if tLTOdjFWEvQrRDNXlCxgMbVozIkfcU in['vod','vod09']:
    if tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('subtype')=='catagory':
     tLTOdjFWEvQrRDNXlCxgMbVozIkfcn='PROGRAM_LIST'
    else:
     tLTOdjFWEvQrRDNXlCxgMbVozIkfcn='SUPERSECTION_LIST'
   elif tLTOdjFWEvQrRDNXlCxgMbVozIkfcU=='movie':
    tLTOdjFWEvQrRDNXlCxgMbVozIkfcn='MOVIE_LIST'
   else:
    tLTOdjFWEvQrRDNXlCxgMbVozIkfcn=''
   tLTOdjFWEvQrRDNXlCxgMbVozIkfns='%s (%s)'%(tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('title'),args.get('ordernm'))
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB={'mode':tLTOdjFWEvQrRDNXlCxgMbVozIkfcn,'suburl':tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('suburl'),'subapi':tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.get_settings_exclusion21():
    if tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('title')=='성인' or tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('title')=='성인+' or tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('title')=='에로티시즘' or tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('title')=='19':continue
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnp={'title':tLTOdjFWEvQrRDNXlCxgMbVozIkfns,'plot':tLTOdjFWEvQrRDNXlCxgMbVozIkfns}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.add_dir(tLTOdjFWEvQrRDNXlCxgMbVozIkfns,sublabel='',img='',infoLabels=tLTOdjFWEvQrRDNXlCxgMbVozIkfnp,isFolder=tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ,params=tLTOdjFWEvQrRDNXlCxgMbVozIkfnB)
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfau(tLTOdjFWEvQrRDNXlCxgMbVozIkfcy)>0:xbmcplugin.endOfDirectory(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA._addon_handle,cacheToDisc=tLTOdjFWEvQrRDNXlCxgMbVozIkfaA)
 def dp_Program_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA,args):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfqu =args.get('subapi')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfcG=tLTOdjFWEvQrRDNXlCxgMbVozIkfaq(args.get('page'))
  tLTOdjFWEvQrRDNXlCxgMbVozIkfnA =args.get('orderby')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.addon_log('dp_Program_List')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.addon_log(tLTOdjFWEvQrRDNXlCxgMbVozIkfqu)
  tLTOdjFWEvQrRDNXlCxgMbVozIkfcy,tLTOdjFWEvQrRDNXlCxgMbVozIkfcq=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.Get_Program_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfqu,tLTOdjFWEvQrRDNXlCxgMbVozIkfcG,tLTOdjFWEvQrRDNXlCxgMbVozIkfnA)
  for tLTOdjFWEvQrRDNXlCxgMbVozIkfcp in tLTOdjFWEvQrRDNXlCxgMbVozIkfcy:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfci =tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('videoid')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfcw =tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('vidtype')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfns =tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('title')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfch=tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('thumbnail')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUY =tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('age')
   if tLTOdjFWEvQrRDNXlCxgMbVozIkfUY=='18' or tLTOdjFWEvQrRDNXlCxgMbVozIkfUY=='19' or tLTOdjFWEvQrRDNXlCxgMbVozIkfUY=='21':tLTOdjFWEvQrRDNXlCxgMbVozIkfns+=' (%s)'%(tLTOdjFWEvQrRDNXlCxgMbVozIkfUY)
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnp={'plot':tLTOdjFWEvQrRDNXlCxgMbVozIkfns,'mpaa':tLTOdjFWEvQrRDNXlCxgMbVozIkfUY,'mediatype':'tvshow','title':tLTOdjFWEvQrRDNXlCxgMbVozIkfns,}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB={'mode':'SEASON_LIST','videoid':tLTOdjFWEvQrRDNXlCxgMbVozIkfci,'vidtype':tLTOdjFWEvQrRDNXlCxgMbVozIkfcw,}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfce=[]
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUn={'mode':'VIEW_DETAIL','values':{'videoid':tLTOdjFWEvQrRDNXlCxgMbVozIkfci,'vidtype':'tvshow','contenttype':tLTOdjFWEvQrRDNXlCxgMbVozIkfcw,}}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUc=json.dumps(tLTOdjFWEvQrRDNXlCxgMbVozIkfUn,separators=(',',':'))
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUc=base64.standard_b64encode(tLTOdjFWEvQrRDNXlCxgMbVozIkfUc.encode()).decode('utf-8')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUc=tLTOdjFWEvQrRDNXlCxgMbVozIkfUc.replace('+','%2B')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUK='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(tLTOdjFWEvQrRDNXlCxgMbVozIkfUc)
   tLTOdjFWEvQrRDNXlCxgMbVozIkfce.append(('상세정보 조회',tLTOdjFWEvQrRDNXlCxgMbVozIkfUK))
   if tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.get_settings_makebookmark():
    tLTOdjFWEvQrRDNXlCxgMbVozIkfUn={'videoid':tLTOdjFWEvQrRDNXlCxgMbVozIkfci,'vidtype':'tvshow','vtitle':tLTOdjFWEvQrRDNXlCxgMbVozIkfns,'vsubtitle':'','contenttype':tLTOdjFWEvQrRDNXlCxgMbVozIkfcw,}
    tLTOdjFWEvQrRDNXlCxgMbVozIkfUq=json.dumps(tLTOdjFWEvQrRDNXlCxgMbVozIkfUn)
    tLTOdjFWEvQrRDNXlCxgMbVozIkfUq=urllib.parse.quote(tLTOdjFWEvQrRDNXlCxgMbVozIkfUq)
    tLTOdjFWEvQrRDNXlCxgMbVozIkfUK='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(tLTOdjFWEvQrRDNXlCxgMbVozIkfUq)
    tLTOdjFWEvQrRDNXlCxgMbVozIkfce.append(('(통합) 찜 영상에 추가',tLTOdjFWEvQrRDNXlCxgMbVozIkfUK))
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.add_dir(tLTOdjFWEvQrRDNXlCxgMbVozIkfns,sublabel='',img=tLTOdjFWEvQrRDNXlCxgMbVozIkfch,infoLabels=tLTOdjFWEvQrRDNXlCxgMbVozIkfnp,isFolder=tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ,params=tLTOdjFWEvQrRDNXlCxgMbVozIkfnB,ContextMenu=tLTOdjFWEvQrRDNXlCxgMbVozIkfce)
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfcq:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB={}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB['mode'] ='PROGRAM_LIST' 
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB['subapi']=tLTOdjFWEvQrRDNXlCxgMbVozIkfqu 
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB['page'] =tLTOdjFWEvQrRDNXlCxgMbVozIkfae(tLTOdjFWEvQrRDNXlCxgMbVozIkfcG+1)
   tLTOdjFWEvQrRDNXlCxgMbVozIkfns='[B]%s >>[/B]'%'다음 페이지'
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUJ=tLTOdjFWEvQrRDNXlCxgMbVozIkfae(tLTOdjFWEvQrRDNXlCxgMbVozIkfcG+1)
   tLTOdjFWEvQrRDNXlCxgMbVozIkfne=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.add_dir(tLTOdjFWEvQrRDNXlCxgMbVozIkfns,sublabel=tLTOdjFWEvQrRDNXlCxgMbVozIkfUJ,img=tLTOdjFWEvQrRDNXlCxgMbVozIkfne,infoLabels=tLTOdjFWEvQrRDNXlCxgMbVozIkfaK,isFolder=tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ,params=tLTOdjFWEvQrRDNXlCxgMbVozIkfnB)
  xbmcplugin.setContent(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA._addon_handle,'tvshows')
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfau(tLTOdjFWEvQrRDNXlCxgMbVozIkfcy)>0:xbmcplugin.endOfDirectory(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA._addon_handle,cacheToDisc=tLTOdjFWEvQrRDNXlCxgMbVozIkfaA)
 def dp_Season_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA,args):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfci=args.get('videoid')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfcw=args.get('vidtype')
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfcw=='contentid':
   tLTOdjFWEvQrRDNXlCxgMbVozIkfKH=tLTOdjFWEvQrRDNXlCxgMbVozIkfci
   tLTOdjFWEvQrRDNXlCxgMbVozIkfqS =tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.ContentidToSeasonid(tLTOdjFWEvQrRDNXlCxgMbVozIkfci)
  else:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfKH=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.ProgramidToContentid(tLTOdjFWEvQrRDNXlCxgMbVozIkfci)
   tLTOdjFWEvQrRDNXlCxgMbVozIkfqS =tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.ContentidToSeasonid(tLTOdjFWEvQrRDNXlCxgMbVozIkfKH)
  tLTOdjFWEvQrRDNXlCxgMbVozIkfqe=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.Get_Season_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfqS)
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfau(tLTOdjFWEvQrRDNXlCxgMbVozIkfqe)>1:
   for tLTOdjFWEvQrRDNXlCxgMbVozIkfqB in tLTOdjFWEvQrRDNXlCxgMbVozIkfqe:
    tLTOdjFWEvQrRDNXlCxgMbVozIkfqG=tLTOdjFWEvQrRDNXlCxgMbVozIkfqB.get('season_Id')
    tLTOdjFWEvQrRDNXlCxgMbVozIkfqy=tLTOdjFWEvQrRDNXlCxgMbVozIkfqB.get('season_Nm')
    tLTOdjFWEvQrRDNXlCxgMbVozIkfqp=tLTOdjFWEvQrRDNXlCxgMbVozIkfqB.get('programNm')
    tLTOdjFWEvQrRDNXlCxgMbVozIkfch=tLTOdjFWEvQrRDNXlCxgMbVozIkfqB.get('thumbnail')
    tLTOdjFWEvQrRDNXlCxgMbVozIkfqi =tLTOdjFWEvQrRDNXlCxgMbVozIkfqB.get('synopsis')
    tLTOdjFWEvQrRDNXlCxgMbVozIkfcB={'mediatype':'tvshow','title':tLTOdjFWEvQrRDNXlCxgMbVozIkfqy,'plot':tLTOdjFWEvQrRDNXlCxgMbVozIkfqi,}
    tLTOdjFWEvQrRDNXlCxgMbVozIkfnB={'mode':'EPISODE_LIST','seasonid':tLTOdjFWEvQrRDNXlCxgMbVozIkfqG,'page':'1',}
    tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.add_dir(tLTOdjFWEvQrRDNXlCxgMbVozIkfqy,sublabel=tLTOdjFWEvQrRDNXlCxgMbVozIkfqp,img=tLTOdjFWEvQrRDNXlCxgMbVozIkfch,infoLabels=tLTOdjFWEvQrRDNXlCxgMbVozIkfcB,isFolder=tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ,params=tLTOdjFWEvQrRDNXlCxgMbVozIkfnB,ContextMenu=tLTOdjFWEvQrRDNXlCxgMbVozIkfaK)
   xbmcplugin.setContent(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA._addon_handle,'seasons')
   xbmcplugin.endOfDirectory(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA._addon_handle,cacheToDisc=tLTOdjFWEvQrRDNXlCxgMbVozIkfaA)
  else:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfqw={'seasonid':tLTOdjFWEvQrRDNXlCxgMbVozIkfqS,'page':'1',}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.dp_Episode_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfqw)
 def dp_Episode_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA,args):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfqS =args.get('seasonid')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfcG =tLTOdjFWEvQrRDNXlCxgMbVozIkfaq(args.get('page'))
  tLTOdjFWEvQrRDNXlCxgMbVozIkfcy,tLTOdjFWEvQrRDNXlCxgMbVozIkfcq=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.Get_Episode_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfqS,tLTOdjFWEvQrRDNXlCxgMbVozIkfcG,orderby=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.get_winEpisodeOrderby())
  for tLTOdjFWEvQrRDNXlCxgMbVozIkfcp in tLTOdjFWEvQrRDNXlCxgMbVozIkfcy:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUJ=tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('episodenumber')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfqh ='[%s]\n\n%s'%(tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('episodetitle'),tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('synopsis'))
   tLTOdjFWEvQrRDNXlCxgMbVozIkfcB={'mediatype':'episode','title':tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('programtitle'),'plot':tLTOdjFWEvQrRDNXlCxgMbVozIkfqh,'cast':tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('episodeactors'),}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB={'mode':'VOD','programid':tLTOdjFWEvQrRDNXlCxgMbVozIkfqS,'contentid':tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('contentid'),'thumbnail':tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('thumbnail'),'title':tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('programtitle'),'subtitle':tLTOdjFWEvQrRDNXlCxgMbVozIkfUJ,}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.add_dir(tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('programtitle'),sublabel=tLTOdjFWEvQrRDNXlCxgMbVozIkfUJ,img=tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('thumbnail'),infoLabels=tLTOdjFWEvQrRDNXlCxgMbVozIkfcB,isFolder=tLTOdjFWEvQrRDNXlCxgMbVozIkfaA,params=tLTOdjFWEvQrRDNXlCxgMbVozIkfnB)
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfcG==1:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfcB={'plot':'정렬순서를 변경합니다.'}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB={}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB['mode'] ='ORDER_BY' 
   if tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.get_winEpisodeOrderby()=='desc':
    tLTOdjFWEvQrRDNXlCxgMbVozIkfns='정렬순서변경 : 최신화부터 -> 1회부터'
    tLTOdjFWEvQrRDNXlCxgMbVozIkfnB['orderby']='asc'
   else:
    tLTOdjFWEvQrRDNXlCxgMbVozIkfns='정렬순서변경 : 1회부터 -> 최신화부터'
    tLTOdjFWEvQrRDNXlCxgMbVozIkfnB['orderby']='desc'
   tLTOdjFWEvQrRDNXlCxgMbVozIkfne=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.add_dir(tLTOdjFWEvQrRDNXlCxgMbVozIkfns,sublabel='',img=tLTOdjFWEvQrRDNXlCxgMbVozIkfne,infoLabels=tLTOdjFWEvQrRDNXlCxgMbVozIkfcB,isFolder=tLTOdjFWEvQrRDNXlCxgMbVozIkfaA,params=tLTOdjFWEvQrRDNXlCxgMbVozIkfnB,isLink=tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ)
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfcq:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB={}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB['mode'] ='EPISODE_LIST' 
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB['seasonid']=tLTOdjFWEvQrRDNXlCxgMbVozIkfqS
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB['page'] =tLTOdjFWEvQrRDNXlCxgMbVozIkfae(tLTOdjFWEvQrRDNXlCxgMbVozIkfcG+1)
   tLTOdjFWEvQrRDNXlCxgMbVozIkfns='[B]%s >>[/B]'%'다음 페이지'
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUJ=tLTOdjFWEvQrRDNXlCxgMbVozIkfae(tLTOdjFWEvQrRDNXlCxgMbVozIkfcG+1)
   tLTOdjFWEvQrRDNXlCxgMbVozIkfne=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.add_dir(tLTOdjFWEvQrRDNXlCxgMbVozIkfns,sublabel=tLTOdjFWEvQrRDNXlCxgMbVozIkfUJ,img=tLTOdjFWEvQrRDNXlCxgMbVozIkfne,infoLabels=tLTOdjFWEvQrRDNXlCxgMbVozIkfaK,isFolder=tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ,params=tLTOdjFWEvQrRDNXlCxgMbVozIkfnB)
  xbmcplugin.setContent(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA._addon_handle,'episodes')
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfau(tLTOdjFWEvQrRDNXlCxgMbVozIkfcy)>0:xbmcplugin.endOfDirectory(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA._addon_handle,cacheToDisc=tLTOdjFWEvQrRDNXlCxgMbVozIkfaA)
 def dp_SuperSection_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA,args):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfJY =args.get('suburl')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfqu =args.get('subapi')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.addon_log('dp_SuperSection_List')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.addon_log('suburl : '+tLTOdjFWEvQrRDNXlCxgMbVozIkfJY)
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.addon_log('subapi : '+tLTOdjFWEvQrRDNXlCxgMbVozIkfqu)
  tLTOdjFWEvQrRDNXlCxgMbVozIkfcy=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.Get_SuperMultiSection_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfJY)
  for tLTOdjFWEvQrRDNXlCxgMbVozIkfcp in tLTOdjFWEvQrRDNXlCxgMbVozIkfcy:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfns =tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('title')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfqu =tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('subapi')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfJn=tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('cell_type')
   if tLTOdjFWEvQrRDNXlCxgMbVozIkfqu.find('contenttype=movie')>=0 or tLTOdjFWEvQrRDNXlCxgMbVozIkfqu.find('mtype=svod')>=0:
    tLTOdjFWEvQrRDNXlCxgMbVozIkfcn='MOVIE_LIST'
   elif re.search('themes/2\d{4}',tLTOdjFWEvQrRDNXlCxgMbVozIkfqu)or re.search('themes-band/9\d{4}',tLTOdjFWEvQrRDNXlCxgMbVozIkfqu):
    tLTOdjFWEvQrRDNXlCxgMbVozIkfcn='MOVIE_LIST'
   else:
    tLTOdjFWEvQrRDNXlCxgMbVozIkfcn='PROGRAM_LIST'
   '''
   if subapi.find('mtype=svod') >= 0 or subapi.find('mtype=ppv') >= 0 or subapi.find('contenttype=movie') >= 0: #영화 #20201107
    mode = 'MOVIE_LIST'
   elif subapi.find('contenttype=program') >= 0:
    mode = 'PROGRAM_LIST'
   elif cell_type == 'band_71': # band_71 #20201107
    mode   = 'SUPERSECTION_LIST'
    (temp_url, temp_api) = self.WavveObj.Baseapi_Parse(subapi)
    suburl = temp_api.get('api')
    subapi = ''
   elif cell_type == 'band_2': # band_2
    mode = 'BAND2SECTION_LIST'
   elif cell_type == 'band_live':
    mode = 'BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}', subapi) :
    mode = 'MOVIE_LIST'
   else: # band_10
    mode = 'PROGRAM_LIST'
   '''   
   tLTOdjFWEvQrRDNXlCxgMbVozIkfcB={'plot':tLTOdjFWEvQrRDNXlCxgMbVozIkfns,'mediatype':'tvshow',}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB={'mode':tLTOdjFWEvQrRDNXlCxgMbVozIkfcn,'suburl':tLTOdjFWEvQrRDNXlCxgMbVozIkfJY,'subapi':tLTOdjFWEvQrRDNXlCxgMbVozIkfqu,'page':'1',}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.add_dir(tLTOdjFWEvQrRDNXlCxgMbVozIkfns,sublabel='',img=tLTOdjFWEvQrRDNXlCxgMbVozIkfaK,infoLabels=tLTOdjFWEvQrRDNXlCxgMbVozIkfcB,isFolder=tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ,params=tLTOdjFWEvQrRDNXlCxgMbVozIkfnB)
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfau(tLTOdjFWEvQrRDNXlCxgMbVozIkfcy)>0:xbmcplugin.endOfDirectory(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA._addon_handle,cacheToDisc=tLTOdjFWEvQrRDNXlCxgMbVozIkfaA)
 def dp_BandLiveSection_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA,args):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfqu =args.get('subapi')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfcG=tLTOdjFWEvQrRDNXlCxgMbVozIkfaq(args.get('page'))
  tLTOdjFWEvQrRDNXlCxgMbVozIkfcy,tLTOdjFWEvQrRDNXlCxgMbVozIkfcq=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.Get_BandLiveSection_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfqu,tLTOdjFWEvQrRDNXlCxgMbVozIkfcG)
  for tLTOdjFWEvQrRDNXlCxgMbVozIkfcp in tLTOdjFWEvQrRDNXlCxgMbVozIkfcy:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfJc =tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('channelid')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfJU =tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('studio')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfJK=tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('tvshowtitle')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfch =tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('thumbnail')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUY =tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('age')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfcB={'mediatype':'tvshow','mpaa':tLTOdjFWEvQrRDNXlCxgMbVozIkfUY,'title':'%s < %s >'%(tLTOdjFWEvQrRDNXlCxgMbVozIkfJU,tLTOdjFWEvQrRDNXlCxgMbVozIkfJK),'tvshowtitle':tLTOdjFWEvQrRDNXlCxgMbVozIkfJK,'studio':tLTOdjFWEvQrRDNXlCxgMbVozIkfJU,'plot':tLTOdjFWEvQrRDNXlCxgMbVozIkfJU}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB={'mode':'LIVE','contentid':tLTOdjFWEvQrRDNXlCxgMbVozIkfJc}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.add_dir(tLTOdjFWEvQrRDNXlCxgMbVozIkfJU,sublabel=tLTOdjFWEvQrRDNXlCxgMbVozIkfJK,img=tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('thumbnail'),infoLabels=tLTOdjFWEvQrRDNXlCxgMbVozIkfcB,isFolder=tLTOdjFWEvQrRDNXlCxgMbVozIkfaA,params=tLTOdjFWEvQrRDNXlCxgMbVozIkfnB)
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfcq:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB={}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB['mode'] ='BANDLIVESECTION_LIST' 
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB['subapi']=tLTOdjFWEvQrRDNXlCxgMbVozIkfqu
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB['page'] =tLTOdjFWEvQrRDNXlCxgMbVozIkfae(tLTOdjFWEvQrRDNXlCxgMbVozIkfcG+1)
   tLTOdjFWEvQrRDNXlCxgMbVozIkfns='[B]%s >>[/B]'%'다음 페이지'
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUJ=tLTOdjFWEvQrRDNXlCxgMbVozIkfae(tLTOdjFWEvQrRDNXlCxgMbVozIkfcG+1)
   tLTOdjFWEvQrRDNXlCxgMbVozIkfne=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.add_dir(tLTOdjFWEvQrRDNXlCxgMbVozIkfns,sublabel=tLTOdjFWEvQrRDNXlCxgMbVozIkfUJ,img=tLTOdjFWEvQrRDNXlCxgMbVozIkfne,infoLabels=tLTOdjFWEvQrRDNXlCxgMbVozIkfaK,isFolder=tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ,params=tLTOdjFWEvQrRDNXlCxgMbVozIkfnB)
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfau(tLTOdjFWEvQrRDNXlCxgMbVozIkfcy)>0:xbmcplugin.endOfDirectory(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA._addon_handle,cacheToDisc=tLTOdjFWEvQrRDNXlCxgMbVozIkfaA)
 def dp_Band2Section_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA,args):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfqu =args.get('subapi')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfcG=tLTOdjFWEvQrRDNXlCxgMbVozIkfaq(args.get('page'))
  tLTOdjFWEvQrRDNXlCxgMbVozIkfcy,tLTOdjFWEvQrRDNXlCxgMbVozIkfcq=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.Get_Band2Section_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfqu,tLTOdjFWEvQrRDNXlCxgMbVozIkfcG)
  for tLTOdjFWEvQrRDNXlCxgMbVozIkfcp in tLTOdjFWEvQrRDNXlCxgMbVozIkfcy:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfns =tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('programtitle')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUJ =tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('episodetitle')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfcB={'plot':tLTOdjFWEvQrRDNXlCxgMbVozIkfns+'\n\n'+tLTOdjFWEvQrRDNXlCxgMbVozIkfUJ,'mpaa':tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('age'),'mediatype':'episode'}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB={'mode':'VOD','programid':'-','contentid':tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('videoid'),'thumbnail':tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('thumbnail'),'title':tLTOdjFWEvQrRDNXlCxgMbVozIkfns,'subtitle':tLTOdjFWEvQrRDNXlCxgMbVozIkfUJ}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.add_dir(tLTOdjFWEvQrRDNXlCxgMbVozIkfns,sublabel=tLTOdjFWEvQrRDNXlCxgMbVozIkfUJ,img=tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('thumbnail'),infoLabels=tLTOdjFWEvQrRDNXlCxgMbVozIkfcB,isFolder=tLTOdjFWEvQrRDNXlCxgMbVozIkfaA,params=tLTOdjFWEvQrRDNXlCxgMbVozIkfnB)
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfcq:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB={}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB['mode'] ='BAND2SECTION_LIST' 
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB['subapi']=tLTOdjFWEvQrRDNXlCxgMbVozIkfqu
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB['page'] =tLTOdjFWEvQrRDNXlCxgMbVozIkfae(tLTOdjFWEvQrRDNXlCxgMbVozIkfcG+1)
   tLTOdjFWEvQrRDNXlCxgMbVozIkfns='[B]%s >>[/B]'%'다음 페이지'
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUJ=tLTOdjFWEvQrRDNXlCxgMbVozIkfae(tLTOdjFWEvQrRDNXlCxgMbVozIkfcG+1)
   tLTOdjFWEvQrRDNXlCxgMbVozIkfne=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.add_dir(tLTOdjFWEvQrRDNXlCxgMbVozIkfns,sublabel=tLTOdjFWEvQrRDNXlCxgMbVozIkfUJ,img=tLTOdjFWEvQrRDNXlCxgMbVozIkfne,infoLabels=tLTOdjFWEvQrRDNXlCxgMbVozIkfaK,isFolder=tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ,params=tLTOdjFWEvQrRDNXlCxgMbVozIkfnB)
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfau(tLTOdjFWEvQrRDNXlCxgMbVozIkfcy)>0:xbmcplugin.endOfDirectory(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA._addon_handle,cacheToDisc=tLTOdjFWEvQrRDNXlCxgMbVozIkfaA)
 def dp_Movie_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA,args):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfqu =args.get('subapi')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfcG=tLTOdjFWEvQrRDNXlCxgMbVozIkfaq(args.get('page'))
  tLTOdjFWEvQrRDNXlCxgMbVozIkfnA =args.get('orderby')or '-'
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.addon_log('dp_Movie_List')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.addon_log(tLTOdjFWEvQrRDNXlCxgMbVozIkfqu)
  tLTOdjFWEvQrRDNXlCxgMbVozIkfcy,tLTOdjFWEvQrRDNXlCxgMbVozIkfcq=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.Get_Movie_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfqu,tLTOdjFWEvQrRDNXlCxgMbVozIkfcG,tLTOdjFWEvQrRDNXlCxgMbVozIkfnA)
  for tLTOdjFWEvQrRDNXlCxgMbVozIkfcp in tLTOdjFWEvQrRDNXlCxgMbVozIkfcy:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfci =tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('videoid')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfcw =tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('vidtype')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfns =tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('title')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfch=tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('thumbnail')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUY =tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('age')
   if tLTOdjFWEvQrRDNXlCxgMbVozIkfUY=='18' or tLTOdjFWEvQrRDNXlCxgMbVozIkfUY=='19' or tLTOdjFWEvQrRDNXlCxgMbVozIkfUY=='21':tLTOdjFWEvQrRDNXlCxgMbVozIkfns+=' (%s)'%(tLTOdjFWEvQrRDNXlCxgMbVozIkfUY)
   tLTOdjFWEvQrRDNXlCxgMbVozIkfcB={'plot':tLTOdjFWEvQrRDNXlCxgMbVozIkfns,'mpaa':tLTOdjFWEvQrRDNXlCxgMbVozIkfUY,'mediatype':'movie'}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB={'mode':'MOVIE','contentid':tLTOdjFWEvQrRDNXlCxgMbVozIkfci,'title':tLTOdjFWEvQrRDNXlCxgMbVozIkfns,'thumbnail':tLTOdjFWEvQrRDNXlCxgMbVozIkfch,'age':tLTOdjFWEvQrRDNXlCxgMbVozIkfUY,}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfce=[]
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUn={'mode':'VIEW_DETAIL','values':{'videoid':tLTOdjFWEvQrRDNXlCxgMbVozIkfci,'vidtype':'movie','contenttype':tLTOdjFWEvQrRDNXlCxgMbVozIkfcw,}}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUc=json.dumps(tLTOdjFWEvQrRDNXlCxgMbVozIkfUn,separators=(',',':'))
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUc=base64.standard_b64encode(tLTOdjFWEvQrRDNXlCxgMbVozIkfUc.encode()).decode('utf-8')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUc=tLTOdjFWEvQrRDNXlCxgMbVozIkfUc.replace('+','%2B')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUK='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(tLTOdjFWEvQrRDNXlCxgMbVozIkfUc)
   tLTOdjFWEvQrRDNXlCxgMbVozIkfce.append(('상세정보 조회',tLTOdjFWEvQrRDNXlCxgMbVozIkfUK))
   if tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.get_settings_makebookmark():
    tLTOdjFWEvQrRDNXlCxgMbVozIkfUn={'videoid':tLTOdjFWEvQrRDNXlCxgMbVozIkfci,'vidtype':'movie','vtitle':tLTOdjFWEvQrRDNXlCxgMbVozIkfns,'vsubtitle':'','contenttype':'programid',}
    tLTOdjFWEvQrRDNXlCxgMbVozIkfUq=json.dumps(tLTOdjFWEvQrRDNXlCxgMbVozIkfUn)
    tLTOdjFWEvQrRDNXlCxgMbVozIkfUq=urllib.parse.quote(tLTOdjFWEvQrRDNXlCxgMbVozIkfUq)
    tLTOdjFWEvQrRDNXlCxgMbVozIkfUK='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(tLTOdjFWEvQrRDNXlCxgMbVozIkfUq)
    tLTOdjFWEvQrRDNXlCxgMbVozIkfce.append(('(통합) 찜 영상에 추가',tLTOdjFWEvQrRDNXlCxgMbVozIkfUK))
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.add_dir(tLTOdjFWEvQrRDNXlCxgMbVozIkfns,sublabel='',img=tLTOdjFWEvQrRDNXlCxgMbVozIkfch,infoLabels=tLTOdjFWEvQrRDNXlCxgMbVozIkfcB,isFolder=tLTOdjFWEvQrRDNXlCxgMbVozIkfaA,params=tLTOdjFWEvQrRDNXlCxgMbVozIkfnB,ContextMenu=tLTOdjFWEvQrRDNXlCxgMbVozIkfce)
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfcq:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB={}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB['mode'] ='MOVIE_LIST' 
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB['subapi']=tLTOdjFWEvQrRDNXlCxgMbVozIkfqu 
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB['page'] =tLTOdjFWEvQrRDNXlCxgMbVozIkfae(tLTOdjFWEvQrRDNXlCxgMbVozIkfcG+1)
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB['orderby']=tLTOdjFWEvQrRDNXlCxgMbVozIkfnA
   tLTOdjFWEvQrRDNXlCxgMbVozIkfns='[B]%s >>[/B]'%'다음 페이지'
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUJ=tLTOdjFWEvQrRDNXlCxgMbVozIkfae(tLTOdjFWEvQrRDNXlCxgMbVozIkfcG+1)
   tLTOdjFWEvQrRDNXlCxgMbVozIkfne=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.add_dir(tLTOdjFWEvQrRDNXlCxgMbVozIkfns,sublabel=tLTOdjFWEvQrRDNXlCxgMbVozIkfUJ,img=tLTOdjFWEvQrRDNXlCxgMbVozIkfne,infoLabels=tLTOdjFWEvQrRDNXlCxgMbVozIkfaK,isFolder=tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ,params=tLTOdjFWEvQrRDNXlCxgMbVozIkfnB)
  xbmcplugin.setContent(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA._addon_handle,'movies')
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfau(tLTOdjFWEvQrRDNXlCxgMbVozIkfcy)>0:xbmcplugin.endOfDirectory(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA._addon_handle,cacheToDisc=tLTOdjFWEvQrRDNXlCxgMbVozIkfaA)
 def dp_Set_Bookmark(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA,args):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfJq=urllib.parse.unquote(args.get('bm_param'))
  tLTOdjFWEvQrRDNXlCxgMbVozIkfJq=json.loads(tLTOdjFWEvQrRDNXlCxgMbVozIkfJq)
  tLTOdjFWEvQrRDNXlCxgMbVozIkfci =tLTOdjFWEvQrRDNXlCxgMbVozIkfJq.get('videoid')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfcw =tLTOdjFWEvQrRDNXlCxgMbVozIkfJq.get('vidtype')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfJa =tLTOdjFWEvQrRDNXlCxgMbVozIkfJq.get('vtitle')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfJA =tLTOdjFWEvQrRDNXlCxgMbVozIkfJq.get('vsubtitle')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfJH=tLTOdjFWEvQrRDNXlCxgMbVozIkfJq.get('contenttype')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYu=xbmcgui.Dialog()
  tLTOdjFWEvQrRDNXlCxgMbVozIkfUw=tLTOdjFWEvQrRDNXlCxgMbVozIkfYu.yesno(__language__(30913).encode('utf8'),tLTOdjFWEvQrRDNXlCxgMbVozIkfJa+' \n\n'+__language__(30914))
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfUw==tLTOdjFWEvQrRDNXlCxgMbVozIkfaA:return
  tLTOdjFWEvQrRDNXlCxgMbVozIkfJs=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.GetBookmarkInfo(tLTOdjFWEvQrRDNXlCxgMbVozIkfci,tLTOdjFWEvQrRDNXlCxgMbVozIkfcw,tLTOdjFWEvQrRDNXlCxgMbVozIkfJH)
  tLTOdjFWEvQrRDNXlCxgMbVozIkfJm=json.dumps(tLTOdjFWEvQrRDNXlCxgMbVozIkfJs)
  tLTOdjFWEvQrRDNXlCxgMbVozIkfJm=urllib.parse.quote(tLTOdjFWEvQrRDNXlCxgMbVozIkfJm)
  tLTOdjFWEvQrRDNXlCxgMbVozIkfUK ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(tLTOdjFWEvQrRDNXlCxgMbVozIkfJm)
  xbmc.executebuiltin(tLTOdjFWEvQrRDNXlCxgMbVozIkfUK)
 def dp_LiveChannel_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA,args):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfJP =args.get('genre')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfqP=args.get('baseapi')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfcy=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.Get_LiveChannel_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfJP,tLTOdjFWEvQrRDNXlCxgMbVozIkfqP)
  for tLTOdjFWEvQrRDNXlCxgMbVozIkfcp in tLTOdjFWEvQrRDNXlCxgMbVozIkfcy:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfJc =tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('channelid')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfJU =tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('studio')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfJK=tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('tvshowtitle')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfch =tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('thumbnail')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfUY =tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('age')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfJu =tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('epg')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfcB={'mediatype':'episode','mpaa':tLTOdjFWEvQrRDNXlCxgMbVozIkfUY,'title':'%s < %s >'%(tLTOdjFWEvQrRDNXlCxgMbVozIkfJU,tLTOdjFWEvQrRDNXlCxgMbVozIkfJK),'tvshowtitle':tLTOdjFWEvQrRDNXlCxgMbVozIkfJK,'studio':tLTOdjFWEvQrRDNXlCxgMbVozIkfJU,'plot':'%s\n\n%s'%(tLTOdjFWEvQrRDNXlCxgMbVozIkfJU,tLTOdjFWEvQrRDNXlCxgMbVozIkfJu)}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB={'mode':'LIVE','contentid':tLTOdjFWEvQrRDNXlCxgMbVozIkfJc}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.add_dir(tLTOdjFWEvQrRDNXlCxgMbVozIkfJU,sublabel=tLTOdjFWEvQrRDNXlCxgMbVozIkfJK,img=tLTOdjFWEvQrRDNXlCxgMbVozIkfch,infoLabels=tLTOdjFWEvQrRDNXlCxgMbVozIkfcB,isFolder=tLTOdjFWEvQrRDNXlCxgMbVozIkfaA,params=tLTOdjFWEvQrRDNXlCxgMbVozIkfnB)
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfau(tLTOdjFWEvQrRDNXlCxgMbVozIkfcy)>0:xbmcplugin.endOfDirectory(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA._addon_handle,cacheToDisc=tLTOdjFWEvQrRDNXlCxgMbVozIkfaA)
 def dp_Sports_GameList(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA,args):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfcy=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.Get_Sports_Gamelist()
  for tLTOdjFWEvQrRDNXlCxgMbVozIkfcp in tLTOdjFWEvQrRDNXlCxgMbVozIkfcy:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfJS =tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('game_date')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfJe =tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('game_time')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfJB =tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('svc_id')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfJG =tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('away_team')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfJy =tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('home_team')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfJp=tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('game_status')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfJi =tLTOdjFWEvQrRDNXlCxgMbVozIkfcp.get('game_place')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfJw ='%s vs %s (%s)'%(tLTOdjFWEvQrRDNXlCxgMbVozIkfJG,tLTOdjFWEvQrRDNXlCxgMbVozIkfJy,tLTOdjFWEvQrRDNXlCxgMbVozIkfJi)
   tLTOdjFWEvQrRDNXlCxgMbVozIkfJh =tLTOdjFWEvQrRDNXlCxgMbVozIkfJS+' '+tLTOdjFWEvQrRDNXlCxgMbVozIkfJe
   if tLTOdjFWEvQrRDNXlCxgMbVozIkfJp=='LIVE':
    tLTOdjFWEvQrRDNXlCxgMbVozIkfJp='~경기중~'
   elif tLTOdjFWEvQrRDNXlCxgMbVozIkfJp=='END':
    tLTOdjFWEvQrRDNXlCxgMbVozIkfJp='경기종료'
   elif tLTOdjFWEvQrRDNXlCxgMbVozIkfJp=='CANCEL':
    tLTOdjFWEvQrRDNXlCxgMbVozIkfJp='취소'
   else:
    tLTOdjFWEvQrRDNXlCxgMbVozIkfJp=''
   if tLTOdjFWEvQrRDNXlCxgMbVozIkfJp=='':
    tLTOdjFWEvQrRDNXlCxgMbVozIkfUJ=tLTOdjFWEvQrRDNXlCxgMbVozIkfJw
   else:
    tLTOdjFWEvQrRDNXlCxgMbVozIkfUJ=tLTOdjFWEvQrRDNXlCxgMbVozIkfJw+'  '+tLTOdjFWEvQrRDNXlCxgMbVozIkfJp
   tLTOdjFWEvQrRDNXlCxgMbVozIkfcB={'mediatype':'episode','title':tLTOdjFWEvQrRDNXlCxgMbVozIkfJw,'plot':'%s\n\n%s\n\n%s'%(tLTOdjFWEvQrRDNXlCxgMbVozIkfJh,tLTOdjFWEvQrRDNXlCxgMbVozIkfJw,tLTOdjFWEvQrRDNXlCxgMbVozIkfJp)}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB={'mode':'SPORTS','contentid':tLTOdjFWEvQrRDNXlCxgMbVozIkfJB}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.add_dir(tLTOdjFWEvQrRDNXlCxgMbVozIkfJh,sublabel=tLTOdjFWEvQrRDNXlCxgMbVozIkfUJ,img='',infoLabels=tLTOdjFWEvQrRDNXlCxgMbVozIkfcB,isFolder=tLTOdjFWEvQrRDNXlCxgMbVozIkfaA,params=tLTOdjFWEvQrRDNXlCxgMbVozIkfnB)
  xbmcplugin.endOfDirectory(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA._addon_handle,cacheToDisc=tLTOdjFWEvQrRDNXlCxgMbVozIkfaA)
 def dp_View_Detail(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA,tLTOdjFWEvQrRDNXlCxgMbVozIkfac):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfci =tLTOdjFWEvQrRDNXlCxgMbVozIkfac.get('videoid')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfcw =tLTOdjFWEvQrRDNXlCxgMbVozIkfac.get('vidtype') 
  tLTOdjFWEvQrRDNXlCxgMbVozIkfJH=tLTOdjFWEvQrRDNXlCxgMbVozIkfac.get('contenttype')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.addon_log(tLTOdjFWEvQrRDNXlCxgMbVozIkfci)
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.addon_log(tLTOdjFWEvQrRDNXlCxgMbVozIkfcw)
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.addon_log(tLTOdjFWEvQrRDNXlCxgMbVozIkfJH)
  tLTOdjFWEvQrRDNXlCxgMbVozIkfJs=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.GetBookmarkInfo(tLTOdjFWEvQrRDNXlCxgMbVozIkfci,tLTOdjFWEvQrRDNXlCxgMbVozIkfcw,tLTOdjFWEvQrRDNXlCxgMbVozIkfJH)
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfcw=='tvshow':
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB={'mode':'SEASON_LIST','videoid':tLTOdjFWEvQrRDNXlCxgMbVozIkfJs['indexinfo']['videoid'],'vidtype':tLTOdjFWEvQrRDNXlCxgMbVozIkfJs['indexinfo']['vidtype'],}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfKc='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(tLTOdjFWEvQrRDNXlCxgMbVozIkfnB))
  else:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnB={'mode':'MOVIE','contentid':tLTOdjFWEvQrRDNXlCxgMbVozIkfJs['indexinfo']['videoid'],'title':tLTOdjFWEvQrRDNXlCxgMbVozIkfJs['saveinfo']['infoLabels']['title'],'thumbnail':tLTOdjFWEvQrRDNXlCxgMbVozIkfJs['saveinfo']['thumbnail'],'age':tLTOdjFWEvQrRDNXlCxgMbVozIkfJs['saveinfo']['infoLabels']['mpaa'],}
   tLTOdjFWEvQrRDNXlCxgMbVozIkfKc='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(tLTOdjFWEvQrRDNXlCxgMbVozIkfnB))
  tLTOdjFWEvQrRDNXlCxgMbVozIkfnm=xbmcgui.ListItem(label=tLTOdjFWEvQrRDNXlCxgMbVozIkfJs['saveinfo']['title'],path=tLTOdjFWEvQrRDNXlCxgMbVozIkfKc)
  tLTOdjFWEvQrRDNXlCxgMbVozIkfnm.setArt(tLTOdjFWEvQrRDNXlCxgMbVozIkfJs['saveinfo']['thumbnail'])
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.Set_InfoTag(tLTOdjFWEvQrRDNXlCxgMbVozIkfnm.getVideoInfoTag(),tLTOdjFWEvQrRDNXlCxgMbVozIkfJs['saveinfo']['infoLabels'])
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfcw=='movie':
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnm.setIsFolder(tLTOdjFWEvQrRDNXlCxgMbVozIkfaA)
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnm.setProperty('IsPlayable','true')
  else:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnm.setIsFolder(tLTOdjFWEvQrRDNXlCxgMbVozIkfaJ)
   tLTOdjFWEvQrRDNXlCxgMbVozIkfnm.setProperty('IsPlayable','false')
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYu=xbmcgui.Dialog()
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYu.info(tLTOdjFWEvQrRDNXlCxgMbVozIkfnm)
 def wavve_main(tLTOdjFWEvQrRDNXlCxgMbVozIkfYA):
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.WavveObj.KodiVersion=tLTOdjFWEvQrRDNXlCxgMbVozIkfaq(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  tLTOdjFWEvQrRDNXlCxgMbVozIkfaY=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.main_params.get('params')
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfaY:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfan =base64.standard_b64decode(tLTOdjFWEvQrRDNXlCxgMbVozIkfaY).decode('utf-8')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfan =json.loads(tLTOdjFWEvQrRDNXlCxgMbVozIkfan)
   tLTOdjFWEvQrRDNXlCxgMbVozIkfcn =tLTOdjFWEvQrRDNXlCxgMbVozIkfan.get('mode')
   tLTOdjFWEvQrRDNXlCxgMbVozIkfac =tLTOdjFWEvQrRDNXlCxgMbVozIkfan.get('values')
  else:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfcn=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.main_params.get('mode',tLTOdjFWEvQrRDNXlCxgMbVozIkfaK)
   tLTOdjFWEvQrRDNXlCxgMbVozIkfac=tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.main_params
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfcn=='LOGOUT':
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.logout()
   return
  tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.login_main()
  if tLTOdjFWEvQrRDNXlCxgMbVozIkfcn is tLTOdjFWEvQrRDNXlCxgMbVozIkfaK:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.dp_Main_List()
  elif tLTOdjFWEvQrRDNXlCxgMbVozIkfcn in['LIVE','VOD','MOVIE','SPORTS']:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.play_VIDEO(tLTOdjFWEvQrRDNXlCxgMbVozIkfac)
  elif tLTOdjFWEvQrRDNXlCxgMbVozIkfcn=='LIVE_CATAGORY':
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.dp_LiveCatagory_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfac)
  elif tLTOdjFWEvQrRDNXlCxgMbVozIkfcn=='MAIN_CATAGORY':
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.dp_MainCatagory_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfac)
  elif tLTOdjFWEvQrRDNXlCxgMbVozIkfcn=='SUPERSECTION_LIST':
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.dp_SuperSection_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfac)
  elif tLTOdjFWEvQrRDNXlCxgMbVozIkfcn=='BANDLIVESECTION_LIST':
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.dp_BandLiveSection_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfac)
  elif tLTOdjFWEvQrRDNXlCxgMbVozIkfcn=='BAND2SECTION_LIST':
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.dp_Band2Section_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfac)
  elif tLTOdjFWEvQrRDNXlCxgMbVozIkfcn=='PROGRAM_LIST':
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.dp_Program_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfac)
  elif tLTOdjFWEvQrRDNXlCxgMbVozIkfcn=='SEASON_LIST':
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.dp_Season_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfac)
  elif tLTOdjFWEvQrRDNXlCxgMbVozIkfcn=='EPISODE_LIST':
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.dp_Episode_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfac)
  elif tLTOdjFWEvQrRDNXlCxgMbVozIkfcn=='MOVIE_LIST':
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.dp_Movie_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfac)
  elif tLTOdjFWEvQrRDNXlCxgMbVozIkfcn=='LIVE_LIST':
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.dp_LiveChannel_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfac)
  elif tLTOdjFWEvQrRDNXlCxgMbVozIkfcn=='ORDER_BY':
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.dp_setEpOrderby(tLTOdjFWEvQrRDNXlCxgMbVozIkfac)
  elif tLTOdjFWEvQrRDNXlCxgMbVozIkfcn=='SEARCH_GROUP':
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.dp_Search_Group(tLTOdjFWEvQrRDNXlCxgMbVozIkfac)
  elif tLTOdjFWEvQrRDNXlCxgMbVozIkfcn in['SEARCH_LIST','LOCAL_SEARCH']:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.dp_Search_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfac)
  elif tLTOdjFWEvQrRDNXlCxgMbVozIkfcn=='WATCH_GROUP':
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.dp_Watch_Group(tLTOdjFWEvQrRDNXlCxgMbVozIkfac)
  elif tLTOdjFWEvQrRDNXlCxgMbVozIkfcn=='WATCH_LIST':
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.dp_Watch_List(tLTOdjFWEvQrRDNXlCxgMbVozIkfac)
  elif tLTOdjFWEvQrRDNXlCxgMbVozIkfcn=='SET_BOOKMARK':
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.dp_Set_Bookmark(tLTOdjFWEvQrRDNXlCxgMbVozIkfac)
  elif tLTOdjFWEvQrRDNXlCxgMbVozIkfcn in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.dp_History_Remove(tLTOdjFWEvQrRDNXlCxgMbVozIkfac)
  elif tLTOdjFWEvQrRDNXlCxgMbVozIkfcn in['TOTAL_SEARCH','TOTAL_HISTORY']:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.dp_Global_Search(tLTOdjFWEvQrRDNXlCxgMbVozIkfac)
  elif tLTOdjFWEvQrRDNXlCxgMbVozIkfcn=='SEARCH_HISTORY':
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.dp_Search_History(tLTOdjFWEvQrRDNXlCxgMbVozIkfac)
  elif tLTOdjFWEvQrRDNXlCxgMbVozIkfcn=='MENU_BOOKMARK':
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.dp_Bookmark_Menu(tLTOdjFWEvQrRDNXlCxgMbVozIkfac)
  elif tLTOdjFWEvQrRDNXlCxgMbVozIkfcn=='GAME_LIST':
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.dp_Sports_GameList(tLTOdjFWEvQrRDNXlCxgMbVozIkfac)
  elif tLTOdjFWEvQrRDNXlCxgMbVozIkfcn=='VIEW_DETAIL':
   tLTOdjFWEvQrRDNXlCxgMbVozIkfYA.dp_View_Detail(tLTOdjFWEvQrRDNXlCxgMbVozIkfac)
  else:
   tLTOdjFWEvQrRDNXlCxgMbVozIkfaK
# Created by pyminifier (https://github.com/liftoff/pyminifier)
