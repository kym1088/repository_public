# wavveM-v19
웨이브 애드온 for Kodi19


## Version 2.0.0 (2020.10.01)
- python3(kodi 19) 전환



