__author__="NightRain"
eRJTBQCpyAklYDnrUGhIcvSgidKzMj=object
eRJTBQCpyAklYDnrUGhIcvSgidKzMF=None
eRJTBQCpyAklYDnrUGhIcvSgidKzMx=False
eRJTBQCpyAklYDnrUGhIcvSgidKzMf=range
eRJTBQCpyAklYDnrUGhIcvSgidKzMH=str
eRJTBQCpyAklYDnrUGhIcvSgidKzMO=True
eRJTBQCpyAklYDnrUGhIcvSgidKzMN=Exception
eRJTBQCpyAklYDnrUGhIcvSgidKzMX=print
eRJTBQCpyAklYDnrUGhIcvSgidKzMu=len
eRJTBQCpyAklYDnrUGhIcvSgidKzMV=dict
eRJTBQCpyAklYDnrUGhIcvSgidKzMW=int
import urllib
import http.cookiejar 
import re
import json
import sys
import requests
eRJTBQCpyAklYDnrUGhIcvSgidKzaj='Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'
class eRJTBQCpyAklYDnrUGhIcvSgidKzaq(eRJTBQCpyAklYDnrUGhIcvSgidKzMj):
 def __init__(eRJTBQCpyAklYDnrUGhIcvSgidKzaF):
  eRJTBQCpyAklYDnrUGhIcvSgidKzaF.API_DOMAIN='https://apis.pooq.co.kr'
  eRJTBQCpyAklYDnrUGhIcvSgidKzaF.APIKEY='E5F3E0D30947AA5440556471321BB6D9'
  eRJTBQCpyAklYDnrUGhIcvSgidKzaF.CREDENTIAL='none'
  eRJTBQCpyAklYDnrUGhIcvSgidKzaF.DEVICE='pc'
  eRJTBQCpyAklYDnrUGhIcvSgidKzaF.DRM='wm'
  eRJTBQCpyAklYDnrUGhIcvSgidKzaF.PARTNER='pooq'
  eRJTBQCpyAklYDnrUGhIcvSgidKzaF.POOQZONE='none'
  eRJTBQCpyAklYDnrUGhIcvSgidKzaF.REGION='kor'
  eRJTBQCpyAklYDnrUGhIcvSgidKzaF.TARGETAGE ='all'
  eRJTBQCpyAklYDnrUGhIcvSgidKzaF.HTTPTAG='https://'
  eRJTBQCpyAklYDnrUGhIcvSgidKzaF.LIST_LIMIT=30 
  eRJTBQCpyAklYDnrUGhIcvSgidKzaF.EP_LIMIT=30 
  eRJTBQCpyAklYDnrUGhIcvSgidKzaF.MV_LIMIT=24 
  eRJTBQCpyAklYDnrUGhIcvSgidKzaF.guid='none' 
  eRJTBQCpyAklYDnrUGhIcvSgidKzaF.guidtimestamp='none' 
  eRJTBQCpyAklYDnrUGhIcvSgidKzaF.DEFAULT_HEADER={'user-agent':eRJTBQCpyAklYDnrUGhIcvSgidKzaj}
 def callRequestCookies(eRJTBQCpyAklYDnrUGhIcvSgidKzaF,jobtype,eRJTBQCpyAklYDnrUGhIcvSgidKzaO,payload=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,params=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,headers=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,cookies=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,redirects=eRJTBQCpyAklYDnrUGhIcvSgidKzMx):
  eRJTBQCpyAklYDnrUGhIcvSgidKzaM=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.DEFAULT_HEADER
  if headers:eRJTBQCpyAklYDnrUGhIcvSgidKzaM.update(headers)
  if jobtype=='Get':
   eRJTBQCpyAklYDnrUGhIcvSgidKzax=requests.get(eRJTBQCpyAklYDnrUGhIcvSgidKzaO,params=params,headers=eRJTBQCpyAklYDnrUGhIcvSgidKzaM,cookies=cookies,allow_redirects=redirects)
  else:
   eRJTBQCpyAklYDnrUGhIcvSgidKzax=requests.post(eRJTBQCpyAklYDnrUGhIcvSgidKzaO,data=payload,params=params,headers=eRJTBQCpyAklYDnrUGhIcvSgidKzaM,cookies=cookies,allow_redirects=redirects)
  return eRJTBQCpyAklYDnrUGhIcvSgidKzax
 def SaveCredential(eRJTBQCpyAklYDnrUGhIcvSgidKzaF,eRJTBQCpyAklYDnrUGhIcvSgidKzaf):
  eRJTBQCpyAklYDnrUGhIcvSgidKzaF.CREDENTIAL=eRJTBQCpyAklYDnrUGhIcvSgidKzaf
 def LoadCredential(eRJTBQCpyAklYDnrUGhIcvSgidKzaF):
  return eRJTBQCpyAklYDnrUGhIcvSgidKzaF.CREDENTIAL
 def GetDefaultParams(eRJTBQCpyAklYDnrUGhIcvSgidKzaF):
  eRJTBQCpyAklYDnrUGhIcvSgidKzaH={'apikey':eRJTBQCpyAklYDnrUGhIcvSgidKzaF.APIKEY,'credential':eRJTBQCpyAklYDnrUGhIcvSgidKzaF.CREDENTIAL,'device':eRJTBQCpyAklYDnrUGhIcvSgidKzaF.DEVICE,'drm':eRJTBQCpyAklYDnrUGhIcvSgidKzaF.DRM,'partner':eRJTBQCpyAklYDnrUGhIcvSgidKzaF.PARTNER,'pooqzone':eRJTBQCpyAklYDnrUGhIcvSgidKzaF.POOQZONE,'region':eRJTBQCpyAklYDnrUGhIcvSgidKzaF.REGION,'targetage':eRJTBQCpyAklYDnrUGhIcvSgidKzaF.TARGETAGE}
  return eRJTBQCpyAklYDnrUGhIcvSgidKzaH
 def makeurl(eRJTBQCpyAklYDnrUGhIcvSgidKzaF,domain,path,query1=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,query2=eRJTBQCpyAklYDnrUGhIcvSgidKzMF):
  eRJTBQCpyAklYDnrUGhIcvSgidKzaO=domain+path
  if query1:
   eRJTBQCpyAklYDnrUGhIcvSgidKzaO+='?%s'%urllib.parse.urlencode(query1)
  if query2:
   eRJTBQCpyAklYDnrUGhIcvSgidKzaO+='&%s'%urllib.parse.urlencode(query2)
  return eRJTBQCpyAklYDnrUGhIcvSgidKzaO
 def GetGUID(eRJTBQCpyAklYDnrUGhIcvSgidKzaF,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   from datetime import datetime
   eRJTBQCpyAklYDnrUGhIcvSgidKzau=datetime.now().strftime('%Y%m%d%H%M%S')
   eRJTBQCpyAklYDnrUGhIcvSgidKzaV=GenerateRandomString(5)
   eRJTBQCpyAklYDnrUGhIcvSgidKzaW=eRJTBQCpyAklYDnrUGhIcvSgidKzaV+media+eRJTBQCpyAklYDnrUGhIcvSgidKzau
   return eRJTBQCpyAklYDnrUGhIcvSgidKzaW
  def GenerateRandomString(num):
   from random import randint
   eRJTBQCpyAklYDnrUGhIcvSgidKzam=""
   for i in eRJTBQCpyAklYDnrUGhIcvSgidKzMf(0,num):
    s=eRJTBQCpyAklYDnrUGhIcvSgidKzMH(randint(1,5))
    eRJTBQCpyAklYDnrUGhIcvSgidKzam+=s
   return eRJTBQCpyAklYDnrUGhIcvSgidKzam
  eRJTBQCpyAklYDnrUGhIcvSgidKzaW=GenerateID(guid_str)
  eRJTBQCpyAklYDnrUGhIcvSgidKzaL=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.GetHash(eRJTBQCpyAklYDnrUGhIcvSgidKzaW)
  if guidType==2:
   eRJTBQCpyAklYDnrUGhIcvSgidKzaL='%s-%s-%s-%s-%s'%(eRJTBQCpyAklYDnrUGhIcvSgidKzaL[:8],eRJTBQCpyAklYDnrUGhIcvSgidKzaL[8:12],eRJTBQCpyAklYDnrUGhIcvSgidKzaL[12:16],eRJTBQCpyAklYDnrUGhIcvSgidKzaL[16:20],eRJTBQCpyAklYDnrUGhIcvSgidKzaL[20:])
  return eRJTBQCpyAklYDnrUGhIcvSgidKzaL
 def GetHash(eRJTBQCpyAklYDnrUGhIcvSgidKzaF,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return eRJTBQCpyAklYDnrUGhIcvSgidKzMH(m.hexdigest())
 def CheckQuality(eRJTBQCpyAklYDnrUGhIcvSgidKzaF,sel_qt,qt_list):
  eRJTBQCpyAklYDnrUGhIcvSgidKzaE=0
  for eRJTBQCpyAklYDnrUGhIcvSgidKzao in qt_list:
   if sel_qt>=eRJTBQCpyAklYDnrUGhIcvSgidKzao:return eRJTBQCpyAklYDnrUGhIcvSgidKzao
   eRJTBQCpyAklYDnrUGhIcvSgidKzaE=eRJTBQCpyAklYDnrUGhIcvSgidKzao
  return eRJTBQCpyAklYDnrUGhIcvSgidKzaE
 def GetCredential(eRJTBQCpyAklYDnrUGhIcvSgidKzaF,user_id,user_pw,user_pf):
  eRJTBQCpyAklYDnrUGhIcvSgidKzat=eRJTBQCpyAklYDnrUGhIcvSgidKzMx
  try:
   eRJTBQCpyAklYDnrUGhIcvSgidKzab='/login'
   eRJTBQCpyAklYDnrUGhIcvSgidKzaH=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.GetDefaultParams()
   eRJTBQCpyAklYDnrUGhIcvSgidKzaP={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   eRJTBQCpyAklYDnrUGhIcvSgidKzaO=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.makeurl(eRJTBQCpyAklYDnrUGhIcvSgidKzaF.API_DOMAIN,eRJTBQCpyAklYDnrUGhIcvSgidKzab)
   eRJTBQCpyAklYDnrUGhIcvSgidKzaw=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.callRequestCookies('Post',eRJTBQCpyAklYDnrUGhIcvSgidKzaO,payload=eRJTBQCpyAklYDnrUGhIcvSgidKzaP,params=eRJTBQCpyAklYDnrUGhIcvSgidKzaH,headers=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,cookies=eRJTBQCpyAklYDnrUGhIcvSgidKzMF)
   eRJTBQCpyAklYDnrUGhIcvSgidKzas=json.loads(eRJTBQCpyAklYDnrUGhIcvSgidKzaw.text)
   eRJTBQCpyAklYDnrUGhIcvSgidKzaf=eRJTBQCpyAklYDnrUGhIcvSgidKzas['credential']
   if user_pf!=0:
    eRJTBQCpyAklYDnrUGhIcvSgidKzaP={'id':eRJTBQCpyAklYDnrUGhIcvSgidKzaf,'password':'','profile':eRJTBQCpyAklYDnrUGhIcvSgidKzMH(user_pf),'pushid':'','type':'credential'}
    eRJTBQCpyAklYDnrUGhIcvSgidKzaH['credential']=eRJTBQCpyAklYDnrUGhIcvSgidKzaf 
    eRJTBQCpyAklYDnrUGhIcvSgidKzaw=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.callRequestCookies('Post',eRJTBQCpyAklYDnrUGhIcvSgidKzaO,payload=eRJTBQCpyAklYDnrUGhIcvSgidKzaP,params=eRJTBQCpyAklYDnrUGhIcvSgidKzaH,headers=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,cookies=eRJTBQCpyAklYDnrUGhIcvSgidKzMF)
    eRJTBQCpyAklYDnrUGhIcvSgidKzas=json.loads(eRJTBQCpyAklYDnrUGhIcvSgidKzaw.text)
    eRJTBQCpyAklYDnrUGhIcvSgidKzaf=eRJTBQCpyAklYDnrUGhIcvSgidKzas['credential']
   if eRJTBQCpyAklYDnrUGhIcvSgidKzaf:eRJTBQCpyAklYDnrUGhIcvSgidKzat=eRJTBQCpyAklYDnrUGhIcvSgidKzMO
  except eRJTBQCpyAklYDnrUGhIcvSgidKzMN as exception:
   eRJTBQCpyAklYDnrUGhIcvSgidKzMX(exception)
   eRJTBQCpyAklYDnrUGhIcvSgidKzaf='none' 
  eRJTBQCpyAklYDnrUGhIcvSgidKzaF.SaveCredential(eRJTBQCpyAklYDnrUGhIcvSgidKzaf)
  return eRJTBQCpyAklYDnrUGhIcvSgidKzat
 def GetIssue(eRJTBQCpyAklYDnrUGhIcvSgidKzaF):
  eRJTBQCpyAklYDnrUGhIcvSgidKzqa=eRJTBQCpyAklYDnrUGhIcvSgidKzMx
  try:
   eRJTBQCpyAklYDnrUGhIcvSgidKzab='/guid/issue'
   eRJTBQCpyAklYDnrUGhIcvSgidKzaH=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.GetDefaultParams()
   eRJTBQCpyAklYDnrUGhIcvSgidKzaO=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.makeurl(eRJTBQCpyAklYDnrUGhIcvSgidKzaF.API_DOMAIN,eRJTBQCpyAklYDnrUGhIcvSgidKzab)
   eRJTBQCpyAklYDnrUGhIcvSgidKzaw=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.callRequestCookies('Get',eRJTBQCpyAklYDnrUGhIcvSgidKzaO,payload=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,params=eRJTBQCpyAklYDnrUGhIcvSgidKzaH,headers=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,cookies=eRJTBQCpyAklYDnrUGhIcvSgidKzMF)
   eRJTBQCpyAklYDnrUGhIcvSgidKzas=json.loads(eRJTBQCpyAklYDnrUGhIcvSgidKzaw.text)
   eRJTBQCpyAklYDnrUGhIcvSgidKzqj=eRJTBQCpyAklYDnrUGhIcvSgidKzas['guid']
   eRJTBQCpyAklYDnrUGhIcvSgidKzqF=eRJTBQCpyAklYDnrUGhIcvSgidKzas['guidtimestamp']
   if eRJTBQCpyAklYDnrUGhIcvSgidKzqj:eRJTBQCpyAklYDnrUGhIcvSgidKzqa=eRJTBQCpyAklYDnrUGhIcvSgidKzMO
  except eRJTBQCpyAklYDnrUGhIcvSgidKzMN as exception:
   eRJTBQCpyAklYDnrUGhIcvSgidKzMX(exception)
   eRJTBQCpyAklYDnrUGhIcvSgidKzqj='none'
   eRJTBQCpyAklYDnrUGhIcvSgidKzqF='none' 
  eRJTBQCpyAklYDnrUGhIcvSgidKzaF.guid=eRJTBQCpyAklYDnrUGhIcvSgidKzqj
  eRJTBQCpyAklYDnrUGhIcvSgidKzaF.guidtimestamp=eRJTBQCpyAklYDnrUGhIcvSgidKzqF
  return eRJTBQCpyAklYDnrUGhIcvSgidKzqa
 def GetGnList(eRJTBQCpyAklYDnrUGhIcvSgidKzaF,gn_str):
  eRJTBQCpyAklYDnrUGhIcvSgidKzqM=[]
  try:
   eRJTBQCpyAklYDnrUGhIcvSgidKzab='/cf/supermultisections/'+gn_str
   eRJTBQCpyAklYDnrUGhIcvSgidKzaH=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.GetDefaultParams()
   eRJTBQCpyAklYDnrUGhIcvSgidKzaO=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.makeurl(eRJTBQCpyAklYDnrUGhIcvSgidKzaF.API_DOMAIN,eRJTBQCpyAklYDnrUGhIcvSgidKzab)
   eRJTBQCpyAklYDnrUGhIcvSgidKzaw=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.callRequestCookies('Get',eRJTBQCpyAklYDnrUGhIcvSgidKzaO,payload=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,params=eRJTBQCpyAklYDnrUGhIcvSgidKzaH,headers=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,cookies=eRJTBQCpyAklYDnrUGhIcvSgidKzMF)
   eRJTBQCpyAklYDnrUGhIcvSgidKzas=json.loads(eRJTBQCpyAklYDnrUGhIcvSgidKzaw.text)
   if not('multisectionlist' in eRJTBQCpyAklYDnrUGhIcvSgidKzas):return eRJTBQCpyAklYDnrUGhIcvSgidKzMF 
   eRJTBQCpyAklYDnrUGhIcvSgidKzqx=eRJTBQCpyAklYDnrUGhIcvSgidKzas['multisectionlist']
   for eRJTBQCpyAklYDnrUGhIcvSgidKzqf in eRJTBQCpyAklYDnrUGhIcvSgidKzqx:
    eRJTBQCpyAklYDnrUGhIcvSgidKzqH=eRJTBQCpyAklYDnrUGhIcvSgidKzqf['title']
    if eRJTBQCpyAklYDnrUGhIcvSgidKzMu(eRJTBQCpyAklYDnrUGhIcvSgidKzqH)==0:continue
    if eRJTBQCpyAklYDnrUGhIcvSgidKzqH=='minor':continue 
    if re.search(u'베너',eRJTBQCpyAklYDnrUGhIcvSgidKzqH):continue
    eRJTBQCpyAklYDnrUGhIcvSgidKzqH=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',eRJTBQCpyAklYDnrUGhIcvSgidKzqH)
    eRJTBQCpyAklYDnrUGhIcvSgidKzqH=eRJTBQCpyAklYDnrUGhIcvSgidKzqH.lstrip('#')
    for eRJTBQCpyAklYDnrUGhIcvSgidKzqO in eRJTBQCpyAklYDnrUGhIcvSgidKzqf['eventlist'][0]['bodylist']:
     if re.search(r'uicode:',eRJTBQCpyAklYDnrUGhIcvSgidKzqO):
      eRJTBQCpyAklYDnrUGhIcvSgidKzqN={'title':eRJTBQCpyAklYDnrUGhIcvSgidKzqH,'uicode':re.sub(r'uicode:','',eRJTBQCpyAklYDnrUGhIcvSgidKzqO)}
      eRJTBQCpyAklYDnrUGhIcvSgidKzqM.append(eRJTBQCpyAklYDnrUGhIcvSgidKzqN)
      break
  except eRJTBQCpyAklYDnrUGhIcvSgidKzMN as exception:
   eRJTBQCpyAklYDnrUGhIcvSgidKzMX(exception)
  return eRJTBQCpyAklYDnrUGhIcvSgidKzqM
 def GetDeeplinkList(eRJTBQCpyAklYDnrUGhIcvSgidKzaF,gn_str,came_str,page_int,addinfoyn=eRJTBQCpyAklYDnrUGhIcvSgidKzMx):
  eRJTBQCpyAklYDnrUGhIcvSgidKzqX=[]
  eRJTBQCpyAklYDnrUGhIcvSgidKzqu=eRJTBQCpyAklYDnrUGhIcvSgidKzjf=1
  eRJTBQCpyAklYDnrUGhIcvSgidKzqV='quick'
  eRJTBQCpyAklYDnrUGhIcvSgidKzqW=eRJTBQCpyAklYDnrUGhIcvSgidKzjF=eRJTBQCpyAklYDnrUGhIcvSgidKzjM=''
  eRJTBQCpyAklYDnrUGhIcvSgidKzqm=eRJTBQCpyAklYDnrUGhIcvSgidKzMx
  eRJTBQCpyAklYDnrUGhIcvSgidKzqL={}
  try:
   eRJTBQCpyAklYDnrUGhIcvSgidKzab='/cf/deeplink/'+gn_str
   eRJTBQCpyAklYDnrUGhIcvSgidKzaH=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.GetDefaultParams()
   eRJTBQCpyAklYDnrUGhIcvSgidKzaO=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.makeurl(eRJTBQCpyAklYDnrUGhIcvSgidKzaF.API_DOMAIN,eRJTBQCpyAklYDnrUGhIcvSgidKzab)
   eRJTBQCpyAklYDnrUGhIcvSgidKzaw=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.callRequestCookies('Get',eRJTBQCpyAklYDnrUGhIcvSgidKzaO,payload=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,params=eRJTBQCpyAklYDnrUGhIcvSgidKzaH,headers=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,cookies=eRJTBQCpyAklYDnrUGhIcvSgidKzMF)
   eRJTBQCpyAklYDnrUGhIcvSgidKzas=json.loads(eRJTBQCpyAklYDnrUGhIcvSgidKzaw.text)
   if not('url' in eRJTBQCpyAklYDnrUGhIcvSgidKzas):return eRJTBQCpyAklYDnrUGhIcvSgidKzMF 
   eRJTBQCpyAklYDnrUGhIcvSgidKzqE=eRJTBQCpyAklYDnrUGhIcvSgidKzas['url']
   eRJTBQCpyAklYDnrUGhIcvSgidKzab=urllib.parse.urlsplit(eRJTBQCpyAklYDnrUGhIcvSgidKzqE).path
   eRJTBQCpyAklYDnrUGhIcvSgidKzqo=eRJTBQCpyAklYDnrUGhIcvSgidKzMV(urllib.parse.parse_qsl(urllib.parse.urlsplit(eRJTBQCpyAklYDnrUGhIcvSgidKzqE).query))
   eRJTBQCpyAklYDnrUGhIcvSgidKzqo['came']=came_str 
   eRJTBQCpyAklYDnrUGhIcvSgidKzqo['limit']=eRJTBQCpyAklYDnrUGhIcvSgidKzMH(eRJTBQCpyAklYDnrUGhIcvSgidKzaF.LIST_LIMIT)
   if 'contenttype' in eRJTBQCpyAklYDnrUGhIcvSgidKzqo:eRJTBQCpyAklYDnrUGhIcvSgidKzqV=eRJTBQCpyAklYDnrUGhIcvSgidKzqo['contenttype']
   if came_str=='movie':eRJTBQCpyAklYDnrUGhIcvSgidKzqo['mtype']='svod'
   if page_int!=1:
    eRJTBQCpyAklYDnrUGhIcvSgidKzqo['offset']=eRJTBQCpyAklYDnrUGhIcvSgidKzMH((page_int-1)*eRJTBQCpyAklYDnrUGhIcvSgidKzaF.LIST_LIMIT)
    eRJTBQCpyAklYDnrUGhIcvSgidKzqo['page'] =eRJTBQCpyAklYDnrUGhIcvSgidKzMH(page_int)
   eRJTBQCpyAklYDnrUGhIcvSgidKzaO=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.HTTPTAG+eRJTBQCpyAklYDnrUGhIcvSgidKzab
   eRJTBQCpyAklYDnrUGhIcvSgidKzqo.update(eRJTBQCpyAklYDnrUGhIcvSgidKzaH)
   eRJTBQCpyAklYDnrUGhIcvSgidKzaw=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.callRequestCookies('Get',eRJTBQCpyAklYDnrUGhIcvSgidKzaO,payload=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,params=eRJTBQCpyAklYDnrUGhIcvSgidKzqo,headers=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,cookies=eRJTBQCpyAklYDnrUGhIcvSgidKzMF)
   eRJTBQCpyAklYDnrUGhIcvSgidKzas=json.loads(eRJTBQCpyAklYDnrUGhIcvSgidKzaw.text)
   if not('celllist' in eRJTBQCpyAklYDnrUGhIcvSgidKzas['cell_toplist']):return eRJTBQCpyAklYDnrUGhIcvSgidKzqX,eRJTBQCpyAklYDnrUGhIcvSgidKzqm 
   eRJTBQCpyAklYDnrUGhIcvSgidKzqt=eRJTBQCpyAklYDnrUGhIcvSgidKzas['cell_toplist']['celllist']
   if(eRJTBQCpyAklYDnrUGhIcvSgidKzqV=='channel' and came_str=='live'):
    if('genre' in eRJTBQCpyAklYDnrUGhIcvSgidKzqo):
     eRJTBQCpyAklYDnrUGhIcvSgidKzqb=eRJTBQCpyAklYDnrUGhIcvSgidKzqo['genre']
    else:
     eRJTBQCpyAklYDnrUGhIcvSgidKzqb='all'
    eRJTBQCpyAklYDnrUGhIcvSgidKzMX("*epgcall*")
    eRJTBQCpyAklYDnrUGhIcvSgidKzqL=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.GetEPGList(eRJTBQCpyAklYDnrUGhIcvSgidKzqb)
   for eRJTBQCpyAklYDnrUGhIcvSgidKzqf in eRJTBQCpyAklYDnrUGhIcvSgidKzqt:
    eRJTBQCpyAklYDnrUGhIcvSgidKzqP=eRJTBQCpyAklYDnrUGhIcvSgidKzqs=thumbnail=''
    eRJTBQCpyAklYDnrUGhIcvSgidKzqP=eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('title_list')[0].get('text')
    if(eRJTBQCpyAklYDnrUGhIcvSgidKzMu(eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('title_list'))>1):
     if(eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('title_list')[1].get('text').startswith('@')):
      for eRJTBQCpyAklYDnrUGhIcvSgidKzqw in eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('bottom_taglist'):
       if eRJTBQCpyAklYDnrUGhIcvSgidKzqw=='playy' or eRJTBQCpyAklYDnrUGhIcvSgidKzqw=='won':eRJTBQCpyAklYDnrUGhIcvSgidKzqs=eRJTBQCpyAklYDnrUGhIcvSgidKzqw
     else:
      eRJTBQCpyAklYDnrUGhIcvSgidKzqs=eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('title_list')[1].get('text')
      eRJTBQCpyAklYDnrUGhIcvSgidKzqs=re.sub(r'(\$O\$)|(\&[a-z]{2}\;)','',eRJTBQCpyAklYDnrUGhIcvSgidKzqs)
    if(eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('thumbnail')!=''):thumbnail='https://%s'%eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('thumbnail')
    eRJTBQCpyAklYDnrUGhIcvSgidKzja=eRJTBQCpyAklYDnrUGhIcvSgidKzqf['event_list'][1].get('url')
    eRJTBQCpyAklYDnrUGhIcvSgidKzjq=eRJTBQCpyAklYDnrUGhIcvSgidKzMV(urllib.parse.parse_qsl(urllib.parse.urlsplit(eRJTBQCpyAklYDnrUGhIcvSgidKzja).query))
    if re.search(u'programid=\&',eRJTBQCpyAklYDnrUGhIcvSgidKzja)and('contentid' in eRJTBQCpyAklYDnrUGhIcvSgidKzjq):
     eRJTBQCpyAklYDnrUGhIcvSgidKzqW=eRJTBQCpyAklYDnrUGhIcvSgidKzjq['contentid']
     eRJTBQCpyAklYDnrUGhIcvSgidKzjF='direct'
    elif('contentid' in eRJTBQCpyAklYDnrUGhIcvSgidKzjq):
     eRJTBQCpyAklYDnrUGhIcvSgidKzqW=eRJTBQCpyAklYDnrUGhIcvSgidKzjq['contentid']
     eRJTBQCpyAklYDnrUGhIcvSgidKzjF='contentid'
    elif('programid' in eRJTBQCpyAklYDnrUGhIcvSgidKzjq):
     eRJTBQCpyAklYDnrUGhIcvSgidKzqW=eRJTBQCpyAklYDnrUGhIcvSgidKzjq['programid']
     eRJTBQCpyAklYDnrUGhIcvSgidKzjF='programid'
     eRJTBQCpyAklYDnrUGhIcvSgidKzqV ='program' 
    elif('channelid' in eRJTBQCpyAklYDnrUGhIcvSgidKzjq):
     eRJTBQCpyAklYDnrUGhIcvSgidKzqW=eRJTBQCpyAklYDnrUGhIcvSgidKzjq['channelid']
     eRJTBQCpyAklYDnrUGhIcvSgidKzjF='channelid'
     if eRJTBQCpyAklYDnrUGhIcvSgidKzqW in eRJTBQCpyAklYDnrUGhIcvSgidKzqL:
      eRJTBQCpyAklYDnrUGhIcvSgidKzjM=eRJTBQCpyAklYDnrUGhIcvSgidKzqL[eRJTBQCpyAklYDnrUGhIcvSgidKzqW]
     else:
      eRJTBQCpyAklYDnrUGhIcvSgidKzjM=''
    elif('movieid' in eRJTBQCpyAklYDnrUGhIcvSgidKzjq):
     eRJTBQCpyAklYDnrUGhIcvSgidKzqW=eRJTBQCpyAklYDnrUGhIcvSgidKzjq['movieid']
     eRJTBQCpyAklYDnrUGhIcvSgidKzjF='movieid'
     eRJTBQCpyAklYDnrUGhIcvSgidKzqV='movie' 
    else:
     eRJTBQCpyAklYDnrUGhIcvSgidKzqW ='-'
     eRJTBQCpyAklYDnrUGhIcvSgidKzjF='-'
    eRJTBQCpyAklYDnrUGhIcvSgidKzjx={}
    eRJTBQCpyAklYDnrUGhIcvSgidKzjx['mpaa'] =eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('age')
    try:
     if('channelid' in eRJTBQCpyAklYDnrUGhIcvSgidKzjq):
      eRJTBQCpyAklYDnrUGhIcvSgidKzjx['mediatype'] ='video'
      eRJTBQCpyAklYDnrUGhIcvSgidKzjx['title'] ='%s < %s >'%(eRJTBQCpyAklYDnrUGhIcvSgidKzqP,eRJTBQCpyAklYDnrUGhIcvSgidKzqs)
      eRJTBQCpyAklYDnrUGhIcvSgidKzjx['tvshowtitle']=eRJTBQCpyAklYDnrUGhIcvSgidKzqs
      eRJTBQCpyAklYDnrUGhIcvSgidKzjx['studio'] =eRJTBQCpyAklYDnrUGhIcvSgidKzqP
     elif('movieid' in eRJTBQCpyAklYDnrUGhIcvSgidKzjq):
      eRJTBQCpyAklYDnrUGhIcvSgidKzjx['mediatype'] ='movie'
      eRJTBQCpyAklYDnrUGhIcvSgidKzjx['title'] =title_list
     else:
      eRJTBQCpyAklYDnrUGhIcvSgidKzjx['mediatype'] ='episode'
      eRJTBQCpyAklYDnrUGhIcvSgidKzjx['title'] =title_list
    except:
     eRJTBQCpyAklYDnrUGhIcvSgidKzMF
    eRJTBQCpyAklYDnrUGhIcvSgidKzqN={'title':eRJTBQCpyAklYDnrUGhIcvSgidKzqP,'subtitle':eRJTBQCpyAklYDnrUGhIcvSgidKzqs,'thumbnail':thumbnail,'uicode':eRJTBQCpyAklYDnrUGhIcvSgidKzqV,'contentid':eRJTBQCpyAklYDnrUGhIcvSgidKzqW,'contentidType':eRJTBQCpyAklYDnrUGhIcvSgidKzjF,'viewage':eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('age'),'channelepg':eRJTBQCpyAklYDnrUGhIcvSgidKzjM,'info':eRJTBQCpyAklYDnrUGhIcvSgidKzjx}
    eRJTBQCpyAklYDnrUGhIcvSgidKzqX.append(eRJTBQCpyAklYDnrUGhIcvSgidKzqN)
   eRJTBQCpyAklYDnrUGhIcvSgidKzqu=eRJTBQCpyAklYDnrUGhIcvSgidKzMW(eRJTBQCpyAklYDnrUGhIcvSgidKzas['cell_toplist']['pagecount'])
   if eRJTBQCpyAklYDnrUGhIcvSgidKzas['cell_toplist']['count']:eRJTBQCpyAklYDnrUGhIcvSgidKzjf =eRJTBQCpyAklYDnrUGhIcvSgidKzMW(eRJTBQCpyAklYDnrUGhIcvSgidKzas['cell_toplist']['count'])
   else:eRJTBQCpyAklYDnrUGhIcvSgidKzjf=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.LIST_LIMIT
   eRJTBQCpyAklYDnrUGhIcvSgidKzqm=eRJTBQCpyAklYDnrUGhIcvSgidKzqu>eRJTBQCpyAklYDnrUGhIcvSgidKzjf
  except eRJTBQCpyAklYDnrUGhIcvSgidKzMN as exception:
   eRJTBQCpyAklYDnrUGhIcvSgidKzMX(exception)
  try:
   if eRJTBQCpyAklYDnrUGhIcvSgidKzqX[0].get('contentidType')=='movieid' and addinfoyn==eRJTBQCpyAklYDnrUGhIcvSgidKzMO:
    eRJTBQCpyAklYDnrUGhIcvSgidKzjH=[]
    eRJTBQCpyAklYDnrUGhIcvSgidKzjO={}
    for eRJTBQCpyAklYDnrUGhIcvSgidKzjN in eRJTBQCpyAklYDnrUGhIcvSgidKzqX:eRJTBQCpyAklYDnrUGhIcvSgidKzjH.append(eRJTBQCpyAklYDnrUGhIcvSgidKzjN.get('contentid'))
    eRJTBQCpyAklYDnrUGhIcvSgidKzjO=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.GetMovieInfoList(eRJTBQCpyAklYDnrUGhIcvSgidKzjH)
    for i in eRJTBQCpyAklYDnrUGhIcvSgidKzMf(eRJTBQCpyAklYDnrUGhIcvSgidKzMu(eRJTBQCpyAklYDnrUGhIcvSgidKzqX)):
     eRJTBQCpyAklYDnrUGhIcvSgidKzqX[i]['info']=eRJTBQCpyAklYDnrUGhIcvSgidKzjO.get(eRJTBQCpyAklYDnrUGhIcvSgidKzqX[i]['contentid'])
  except:
   eRJTBQCpyAklYDnrUGhIcvSgidKzMF
  return(eRJTBQCpyAklYDnrUGhIcvSgidKzqX,eRJTBQCpyAklYDnrUGhIcvSgidKzqm)
 def GetEpisodeList(eRJTBQCpyAklYDnrUGhIcvSgidKzaF,eRJTBQCpyAklYDnrUGhIcvSgidKzqW,eRJTBQCpyAklYDnrUGhIcvSgidKzqV,eRJTBQCpyAklYDnrUGhIcvSgidKzjF,page_int,orderby='desc'):
  eRJTBQCpyAklYDnrUGhIcvSgidKzjX=[]
  eRJTBQCpyAklYDnrUGhIcvSgidKzqu=eRJTBQCpyAklYDnrUGhIcvSgidKzjf=1
  eRJTBQCpyAklYDnrUGhIcvSgidKzqm=eRJTBQCpyAklYDnrUGhIcvSgidKzMx
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   eRJTBQCpyAklYDnrUGhIcvSgidKzaH=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.GetDefaultParams()
   if eRJTBQCpyAklYDnrUGhIcvSgidKzjF=='contentid':
    eRJTBQCpyAklYDnrUGhIcvSgidKzab='/cf/vod/contents/'+eRJTBQCpyAklYDnrUGhIcvSgidKzqW
    eRJTBQCpyAklYDnrUGhIcvSgidKzaO=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.makeurl(eRJTBQCpyAklYDnrUGhIcvSgidKzaF.API_DOMAIN,eRJTBQCpyAklYDnrUGhIcvSgidKzab)
    eRJTBQCpyAklYDnrUGhIcvSgidKzaw=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.callRequestCookies('Get',eRJTBQCpyAklYDnrUGhIcvSgidKzaO,payload=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,params=eRJTBQCpyAklYDnrUGhIcvSgidKzaH,headers=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,cookies=eRJTBQCpyAklYDnrUGhIcvSgidKzMF)
    eRJTBQCpyAklYDnrUGhIcvSgidKzas=json.loads(eRJTBQCpyAklYDnrUGhIcvSgidKzaw.text)
    if not('programid' in eRJTBQCpyAklYDnrUGhIcvSgidKzas):return eRJTBQCpyAklYDnrUGhIcvSgidKzMF 
    eRJTBQCpyAklYDnrUGhIcvSgidKzjV=eRJTBQCpyAklYDnrUGhIcvSgidKzas['programid']
   else:
    eRJTBQCpyAklYDnrUGhIcvSgidKzjV=eRJTBQCpyAklYDnrUGhIcvSgidKzqW
   eRJTBQCpyAklYDnrUGhIcvSgidKzab='/vod/programs-contents/'+eRJTBQCpyAklYDnrUGhIcvSgidKzjV
   eRJTBQCpyAklYDnrUGhIcvSgidKzqo={'limit':eRJTBQCpyAklYDnrUGhIcvSgidKzaF.EP_LIMIT,'offset':eRJTBQCpyAklYDnrUGhIcvSgidKzMH((page_int-1)*eRJTBQCpyAklYDnrUGhIcvSgidKzaF.EP_LIMIT),'orderby':orderby}
   eRJTBQCpyAklYDnrUGhIcvSgidKzaO=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.makeurl(eRJTBQCpyAklYDnrUGhIcvSgidKzaF.API_DOMAIN,eRJTBQCpyAklYDnrUGhIcvSgidKzab)
   eRJTBQCpyAklYDnrUGhIcvSgidKzqo.update(eRJTBQCpyAklYDnrUGhIcvSgidKzaH)
   eRJTBQCpyAklYDnrUGhIcvSgidKzaw=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.callRequestCookies('Get',eRJTBQCpyAklYDnrUGhIcvSgidKzaO,payload=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,params=eRJTBQCpyAklYDnrUGhIcvSgidKzqo,headers=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,cookies=eRJTBQCpyAklYDnrUGhIcvSgidKzMF)
   eRJTBQCpyAklYDnrUGhIcvSgidKzas=json.loads(eRJTBQCpyAklYDnrUGhIcvSgidKzaw.text)
   if not('list' in eRJTBQCpyAklYDnrUGhIcvSgidKzas):return eRJTBQCpyAklYDnrUGhIcvSgidKzMF 
   eRJTBQCpyAklYDnrUGhIcvSgidKzjW=eRJTBQCpyAklYDnrUGhIcvSgidKzas['list']
   for eRJTBQCpyAklYDnrUGhIcvSgidKzqf in eRJTBQCpyAklYDnrUGhIcvSgidKzjW:
    eRJTBQCpyAklYDnrUGhIcvSgidKzjm =eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('programtitle')
    eRJTBQCpyAklYDnrUGhIcvSgidKzjL ='%s회, %s(%s)'%(eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('episodenumber'),eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('releasedate'),eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('releaseweekday'))
    if(eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('image')!=''):tmp_thumbnail='https://%s'%eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('image')
    eRJTBQCpyAklYDnrUGhIcvSgidKzjE=eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('synopsis')
    eRJTBQCpyAklYDnrUGhIcvSgidKzjE=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',eRJTBQCpyAklYDnrUGhIcvSgidKzjE)
    eRJTBQCpyAklYDnrUGhIcvSgidKzjx={}
    eRJTBQCpyAklYDnrUGhIcvSgidKzjx['title'] =eRJTBQCpyAklYDnrUGhIcvSgidKzjm
    eRJTBQCpyAklYDnrUGhIcvSgidKzjx['mediatype']='episode' 
    eRJTBQCpyAklYDnrUGhIcvSgidKzjx['mpaa'] =eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('targetage')
    try:
     if 'episodenumber' in eRJTBQCpyAklYDnrUGhIcvSgidKzqf:eRJTBQCpyAklYDnrUGhIcvSgidKzjx['episode'] =eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('episodenumber')
     if 'releasedate' in eRJTBQCpyAklYDnrUGhIcvSgidKzqf:eRJTBQCpyAklYDnrUGhIcvSgidKzjx['year'] =eRJTBQCpyAklYDnrUGhIcvSgidKzMW(eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('releasedate')[:4])
     if 'releasedate' in eRJTBQCpyAklYDnrUGhIcvSgidKzqf:eRJTBQCpyAklYDnrUGhIcvSgidKzjx['aired'] =eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('releasedate')
     if 'playtime' in eRJTBQCpyAklYDnrUGhIcvSgidKzqf:eRJTBQCpyAklYDnrUGhIcvSgidKzjx['duration']=eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('playtime')
     if 'episodeactors' in eRJTBQCpyAklYDnrUGhIcvSgidKzqf:
      if eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('episodeactors')!='':eRJTBQCpyAklYDnrUGhIcvSgidKzjx['cast']=eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('episodeactors').split(',')
    except:
     eRJTBQCpyAklYDnrUGhIcvSgidKzMF
    eRJTBQCpyAklYDnrUGhIcvSgidKzjo={'title':eRJTBQCpyAklYDnrUGhIcvSgidKzjm,'subtitle':eRJTBQCpyAklYDnrUGhIcvSgidKzjL,'thumbnail':tmp_thumbnail,'uicode':eRJTBQCpyAklYDnrUGhIcvSgidKzqV,'contentid':eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('contentid'),'programid':eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('programid'),'synopsis':eRJTBQCpyAklYDnrUGhIcvSgidKzjE,'viewage':eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('targetage'),'info':eRJTBQCpyAklYDnrUGhIcvSgidKzjx}
    eRJTBQCpyAklYDnrUGhIcvSgidKzjX.append(eRJTBQCpyAklYDnrUGhIcvSgidKzjo)
   eRJTBQCpyAklYDnrUGhIcvSgidKzqu=eRJTBQCpyAklYDnrUGhIcvSgidKzMW(eRJTBQCpyAklYDnrUGhIcvSgidKzas['pagecount'])
   if eRJTBQCpyAklYDnrUGhIcvSgidKzas['count']:eRJTBQCpyAklYDnrUGhIcvSgidKzjf =eRJTBQCpyAklYDnrUGhIcvSgidKzMW(eRJTBQCpyAklYDnrUGhIcvSgidKzas['count'])
   else:eRJTBQCpyAklYDnrUGhIcvSgidKzjf=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.EP_LIMIT
   eRJTBQCpyAklYDnrUGhIcvSgidKzqm=eRJTBQCpyAklYDnrUGhIcvSgidKzqu>eRJTBQCpyAklYDnrUGhIcvSgidKzjf
  except eRJTBQCpyAklYDnrUGhIcvSgidKzMN as exception:
   eRJTBQCpyAklYDnrUGhIcvSgidKzMX(exception)
  return(eRJTBQCpyAklYDnrUGhIcvSgidKzjX,eRJTBQCpyAklYDnrUGhIcvSgidKzqm)
 def GetMyviewList(eRJTBQCpyAklYDnrUGhIcvSgidKzaF,eRJTBQCpyAklYDnrUGhIcvSgidKzqV,page_int,addinfoyn=eRJTBQCpyAklYDnrUGhIcvSgidKzMx):
  eRJTBQCpyAklYDnrUGhIcvSgidKzjt=[]
  eRJTBQCpyAklYDnrUGhIcvSgidKzqu=eRJTBQCpyAklYDnrUGhIcvSgidKzjf=1
  eRJTBQCpyAklYDnrUGhIcvSgidKzqm=eRJTBQCpyAklYDnrUGhIcvSgidKzMx
  try:
   eRJTBQCpyAklYDnrUGhIcvSgidKzaH=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.GetDefaultParams()
   eRJTBQCpyAklYDnrUGhIcvSgidKzab='/myview/contents'
   eRJTBQCpyAklYDnrUGhIcvSgidKzqo={'contenttype':eRJTBQCpyAklYDnrUGhIcvSgidKzqV,'limit':eRJTBQCpyAklYDnrUGhIcvSgidKzaF.MV_LIMIT,'offset':eRJTBQCpyAklYDnrUGhIcvSgidKzMH((page_int-1)*eRJTBQCpyAklYDnrUGhIcvSgidKzaF.MV_LIMIT),'orderby':'new'}
   eRJTBQCpyAklYDnrUGhIcvSgidKzaO=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.makeurl(eRJTBQCpyAklYDnrUGhIcvSgidKzaF.API_DOMAIN,eRJTBQCpyAklYDnrUGhIcvSgidKzab)
   eRJTBQCpyAklYDnrUGhIcvSgidKzqo.update(eRJTBQCpyAklYDnrUGhIcvSgidKzaH)
   eRJTBQCpyAklYDnrUGhIcvSgidKzaw=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.callRequestCookies('Get',eRJTBQCpyAklYDnrUGhIcvSgidKzaO,payload=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,params=eRJTBQCpyAklYDnrUGhIcvSgidKzqo,headers=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,cookies=eRJTBQCpyAklYDnrUGhIcvSgidKzMF)
   eRJTBQCpyAklYDnrUGhIcvSgidKzas=json.loads(eRJTBQCpyAklYDnrUGhIcvSgidKzaw.text)
   if not('list' in eRJTBQCpyAklYDnrUGhIcvSgidKzas[0]):return eRJTBQCpyAklYDnrUGhIcvSgidKzMF 
   eRJTBQCpyAklYDnrUGhIcvSgidKzjb=eRJTBQCpyAklYDnrUGhIcvSgidKzas[0]['list']
   for eRJTBQCpyAklYDnrUGhIcvSgidKzqf in eRJTBQCpyAklYDnrUGhIcvSgidKzjb:
    eRJTBQCpyAklYDnrUGhIcvSgidKzjx={}
    if eRJTBQCpyAklYDnrUGhIcvSgidKzqV=='vod':
     eRJTBQCpyAklYDnrUGhIcvSgidKzjm =eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('programtitle')
     eRJTBQCpyAklYDnrUGhIcvSgidKzjL='%s회, %s'%(eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('episodenumber'),eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('releasedate'))
     eRJTBQCpyAklYDnrUGhIcvSgidKzqW=eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('contentid')
     eRJTBQCpyAklYDnrUGhIcvSgidKzjV=eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('programid')
     eRJTBQCpyAklYDnrUGhIcvSgidKzjx['title'] =eRJTBQCpyAklYDnrUGhIcvSgidKzjm
     eRJTBQCpyAklYDnrUGhIcvSgidKzjx['mediatype']='episode' 
     eRJTBQCpyAklYDnrUGhIcvSgidKzjx['mpaa'] =eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('targetage')
     try:
      eRJTBQCpyAklYDnrUGhIcvSgidKzjx['studio'] =eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('channelname')
     except:
      eRJTBQCpyAklYDnrUGhIcvSgidKzMF
     try:
      if 'releasedate' in eRJTBQCpyAklYDnrUGhIcvSgidKzqf:eRJTBQCpyAklYDnrUGhIcvSgidKzjx['year'] =eRJTBQCpyAklYDnrUGhIcvSgidKzMW(eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('releasedate')[:4])
      if 'releasedate' in eRJTBQCpyAklYDnrUGhIcvSgidKzqf:eRJTBQCpyAklYDnrUGhIcvSgidKzjx['aired'] =eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('releasedate')
     except:
      eRJTBQCpyAklYDnrUGhIcvSgidKzMF
    else:
     eRJTBQCpyAklYDnrUGhIcvSgidKzjm =eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('title')
     eRJTBQCpyAklYDnrUGhIcvSgidKzjL='' 
     eRJTBQCpyAklYDnrUGhIcvSgidKzqW=eRJTBQCpyAklYDnrUGhIcvSgidKzjV=eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('movieid')
     eRJTBQCpyAklYDnrUGhIcvSgidKzjx['title'] =eRJTBQCpyAklYDnrUGhIcvSgidKzjm
     eRJTBQCpyAklYDnrUGhIcvSgidKzjx['mediatype']='movie' 
     eRJTBQCpyAklYDnrUGhIcvSgidKzjx['mpaa'] =eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('targetage')
     try:
      if 'releasedate' in eRJTBQCpyAklYDnrUGhIcvSgidKzqf:eRJTBQCpyAklYDnrUGhIcvSgidKzjx['year'] =eRJTBQCpyAklYDnrUGhIcvSgidKzMW(eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('releasedate')[:4])
      if 'releasedate' in eRJTBQCpyAklYDnrUGhIcvSgidKzqf:eRJTBQCpyAklYDnrUGhIcvSgidKzjx['aired'] =eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('releasedate')
     except:
      eRJTBQCpyAklYDnrUGhIcvSgidKzMF
    if(eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('image')!=''):tmp_thumbnail='https://%s'%eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('image')
    eRJTBQCpyAklYDnrUGhIcvSgidKzjP={'title':eRJTBQCpyAklYDnrUGhIcvSgidKzjm,'subtitle':eRJTBQCpyAklYDnrUGhIcvSgidKzjL,'thumbnail':tmp_thumbnail,'uicode':eRJTBQCpyAklYDnrUGhIcvSgidKzqV,'contentid':eRJTBQCpyAklYDnrUGhIcvSgidKzqW,'programid':eRJTBQCpyAklYDnrUGhIcvSgidKzjV,'viewage':eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('targetage'),'info':eRJTBQCpyAklYDnrUGhIcvSgidKzjx}
    eRJTBQCpyAklYDnrUGhIcvSgidKzjt.append(eRJTBQCpyAklYDnrUGhIcvSgidKzjP)
   eRJTBQCpyAklYDnrUGhIcvSgidKzqu=eRJTBQCpyAklYDnrUGhIcvSgidKzMW(eRJTBQCpyAklYDnrUGhIcvSgidKzas[0]['pagecount'])
   if eRJTBQCpyAklYDnrUGhIcvSgidKzas[0]['count']:eRJTBQCpyAklYDnrUGhIcvSgidKzjf =eRJTBQCpyAklYDnrUGhIcvSgidKzMW(eRJTBQCpyAklYDnrUGhIcvSgidKzas[0]['count'])
   else:eRJTBQCpyAklYDnrUGhIcvSgidKzjf=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.MV_LIMIT
   eRJTBQCpyAklYDnrUGhIcvSgidKzqm=eRJTBQCpyAklYDnrUGhIcvSgidKzqu>eRJTBQCpyAklYDnrUGhIcvSgidKzjf
  except eRJTBQCpyAklYDnrUGhIcvSgidKzMN as exception:
   eRJTBQCpyAklYDnrUGhIcvSgidKzMX(exception)
  try:
   if eRJTBQCpyAklYDnrUGhIcvSgidKzqV=='movie' and addinfoyn==eRJTBQCpyAklYDnrUGhIcvSgidKzMO:
    eRJTBQCpyAklYDnrUGhIcvSgidKzjH=[]
    eRJTBQCpyAklYDnrUGhIcvSgidKzjO={}
    for eRJTBQCpyAklYDnrUGhIcvSgidKzjN in eRJTBQCpyAklYDnrUGhIcvSgidKzjt:eRJTBQCpyAklYDnrUGhIcvSgidKzjH.append(eRJTBQCpyAklYDnrUGhIcvSgidKzjN.get('contentid'))
    eRJTBQCpyAklYDnrUGhIcvSgidKzjO=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.GetMovieInfoList(eRJTBQCpyAklYDnrUGhIcvSgidKzjH)
    for i in eRJTBQCpyAklYDnrUGhIcvSgidKzMf(eRJTBQCpyAklYDnrUGhIcvSgidKzMu(eRJTBQCpyAklYDnrUGhIcvSgidKzjt)):
     eRJTBQCpyAklYDnrUGhIcvSgidKzjt[i]['info']=eRJTBQCpyAklYDnrUGhIcvSgidKzjO.get(eRJTBQCpyAklYDnrUGhIcvSgidKzjt[i]['contentid'])
  except:
   eRJTBQCpyAklYDnrUGhIcvSgidKzMF
  return eRJTBQCpyAklYDnrUGhIcvSgidKzjt,eRJTBQCpyAklYDnrUGhIcvSgidKzqm
 def GetSearchList(eRJTBQCpyAklYDnrUGhIcvSgidKzaF,search_key,genre,page_int,exclusion21=eRJTBQCpyAklYDnrUGhIcvSgidKzMx,addinfoyn=eRJTBQCpyAklYDnrUGhIcvSgidKzMx):
  eRJTBQCpyAklYDnrUGhIcvSgidKzjw=[]
  eRJTBQCpyAklYDnrUGhIcvSgidKzqu=eRJTBQCpyAklYDnrUGhIcvSgidKzjf=1
  eRJTBQCpyAklYDnrUGhIcvSgidKzqm=eRJTBQCpyAklYDnrUGhIcvSgidKzMx
  try:
   eRJTBQCpyAklYDnrUGhIcvSgidKzaH=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.GetDefaultParams()
   eRJTBQCpyAklYDnrUGhIcvSgidKzab='/cf/search/list.js'
   eRJTBQCpyAklYDnrUGhIcvSgidKzqo={'type':'program' if genre=='vod' else 'movie','keyword':search_key,'offset':eRJTBQCpyAklYDnrUGhIcvSgidKzMH((page_int-1)*eRJTBQCpyAklYDnrUGhIcvSgidKzaF.LIST_LIMIT),'limit':eRJTBQCpyAklYDnrUGhIcvSgidKzaF.LIST_LIMIT,'orderby':'score','isplayymovie':'y'}
   eRJTBQCpyAklYDnrUGhIcvSgidKzaO=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.makeurl(eRJTBQCpyAklYDnrUGhIcvSgidKzaF.API_DOMAIN,eRJTBQCpyAklYDnrUGhIcvSgidKzab)
   eRJTBQCpyAklYDnrUGhIcvSgidKzqo.update(eRJTBQCpyAklYDnrUGhIcvSgidKzaH)
   eRJTBQCpyAklYDnrUGhIcvSgidKzaw=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.callRequestCookies('Get',eRJTBQCpyAklYDnrUGhIcvSgidKzaO,payload=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,params=eRJTBQCpyAklYDnrUGhIcvSgidKzqo,headers=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,cookies=eRJTBQCpyAklYDnrUGhIcvSgidKzMF)
   eRJTBQCpyAklYDnrUGhIcvSgidKzas=json.loads(eRJTBQCpyAklYDnrUGhIcvSgidKzaw.text)
   if not('celllist' in eRJTBQCpyAklYDnrUGhIcvSgidKzas['cell_toplist']):return eRJTBQCpyAklYDnrUGhIcvSgidKzjw,eRJTBQCpyAklYDnrUGhIcvSgidKzqm
   eRJTBQCpyAklYDnrUGhIcvSgidKzjs=eRJTBQCpyAklYDnrUGhIcvSgidKzas['cell_toplist']['celllist']
   for eRJTBQCpyAklYDnrUGhIcvSgidKzqf in eRJTBQCpyAklYDnrUGhIcvSgidKzjs:
    eRJTBQCpyAklYDnrUGhIcvSgidKzjx={}
    eRJTBQCpyAklYDnrUGhIcvSgidKzjm =eRJTBQCpyAklYDnrUGhIcvSgidKzqf['title_list'][0]['text']
    if(eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('thumbnail')!=''):tmp_thumbnail='https://%s'%eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('thumbnail')
    for eRJTBQCpyAklYDnrUGhIcvSgidKzqO in eRJTBQCpyAklYDnrUGhIcvSgidKzqf['event_list'][0]['bodylist']:
     if re.search(r'uicode:',eRJTBQCpyAklYDnrUGhIcvSgidKzqO):
      if genre=='vod':
       eRJTBQCpyAklYDnrUGhIcvSgidKzqW=''
       eRJTBQCpyAklYDnrUGhIcvSgidKzjV=re.sub(r'uicode:','',eRJTBQCpyAklYDnrUGhIcvSgidKzqO)
       eRJTBQCpyAklYDnrUGhIcvSgidKzjx['mediatype']='episode' 
      else:
       eRJTBQCpyAklYDnrUGhIcvSgidKzqW=re.sub(r'uicode:','',eRJTBQCpyAklYDnrUGhIcvSgidKzqO)
       eRJTBQCpyAklYDnrUGhIcvSgidKzjV=''
       if eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('bottom_taglist')[0]=='playy':
        eRJTBQCpyAklYDnrUGhIcvSgidKzjm+=' [playy]'
       eRJTBQCpyAklYDnrUGhIcvSgidKzjx['mediatype']='movie' 
      eRJTBQCpyAklYDnrUGhIcvSgidKzjx['title'] =eRJTBQCpyAklYDnrUGhIcvSgidKzqf['title_list'][0]['text']
      eRJTBQCpyAklYDnrUGhIcvSgidKzjx['mpaa'] =eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('age')
      eRJTBQCpyAklYDnrUGhIcvSgidKzjP={'title':eRJTBQCpyAklYDnrUGhIcvSgidKzjm,'thumbnail':tmp_thumbnail,'uicode':genre,'contentid':eRJTBQCpyAklYDnrUGhIcvSgidKzqW,'programid':eRJTBQCpyAklYDnrUGhIcvSgidKzjV,'viewage':eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('age'),'info':eRJTBQCpyAklYDnrUGhIcvSgidKzjx}
    if exclusion21==eRJTBQCpyAklYDnrUGhIcvSgidKzMx or eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('age')!='21':
     eRJTBQCpyAklYDnrUGhIcvSgidKzjw.append(eRJTBQCpyAklYDnrUGhIcvSgidKzjP)
   eRJTBQCpyAklYDnrUGhIcvSgidKzqu=eRJTBQCpyAklYDnrUGhIcvSgidKzMW(eRJTBQCpyAklYDnrUGhIcvSgidKzas['cell_toplist']['pagecount'])
   if eRJTBQCpyAklYDnrUGhIcvSgidKzas['cell_toplist']['count']:eRJTBQCpyAklYDnrUGhIcvSgidKzjf =eRJTBQCpyAklYDnrUGhIcvSgidKzMW(eRJTBQCpyAklYDnrUGhIcvSgidKzas['cell_toplist']['count'])
   else:eRJTBQCpyAklYDnrUGhIcvSgidKzjf=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.LIST_LIMIT
   eRJTBQCpyAklYDnrUGhIcvSgidKzqm=eRJTBQCpyAklYDnrUGhIcvSgidKzqu>eRJTBQCpyAklYDnrUGhIcvSgidKzjf
  except eRJTBQCpyAklYDnrUGhIcvSgidKzMN as exception:
   eRJTBQCpyAklYDnrUGhIcvSgidKzMX(exception)
  try:
   if genre=='movie' and addinfoyn==eRJTBQCpyAklYDnrUGhIcvSgidKzMO:
    eRJTBQCpyAklYDnrUGhIcvSgidKzjH=[]
    eRJTBQCpyAklYDnrUGhIcvSgidKzjO={}
    for eRJTBQCpyAklYDnrUGhIcvSgidKzjN in eRJTBQCpyAklYDnrUGhIcvSgidKzjw:eRJTBQCpyAklYDnrUGhIcvSgidKzjH.append(eRJTBQCpyAklYDnrUGhIcvSgidKzjN.get('contentid'))
    eRJTBQCpyAklYDnrUGhIcvSgidKzjO=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.GetMovieInfoList(eRJTBQCpyAklYDnrUGhIcvSgidKzjH)
    for i in eRJTBQCpyAklYDnrUGhIcvSgidKzMf(eRJTBQCpyAklYDnrUGhIcvSgidKzMu(eRJTBQCpyAklYDnrUGhIcvSgidKzjw)):
     eRJTBQCpyAklYDnrUGhIcvSgidKzjw[i]['info']=eRJTBQCpyAklYDnrUGhIcvSgidKzjO.get(eRJTBQCpyAklYDnrUGhIcvSgidKzjw[i]['contentid'])
  except:
   eRJTBQCpyAklYDnrUGhIcvSgidKzMF
  return eRJTBQCpyAklYDnrUGhIcvSgidKzjw,eRJTBQCpyAklYDnrUGhIcvSgidKzqm 
 def GetGenreGroup(eRJTBQCpyAklYDnrUGhIcvSgidKzaF,maintype,subtype,eRJTBQCpyAklYDnrUGhIcvSgidKzju,ordernm,exclusion21=eRJTBQCpyAklYDnrUGhIcvSgidKzMx):
  eRJTBQCpyAklYDnrUGhIcvSgidKzFa=[]
  try:
   eRJTBQCpyAklYDnrUGhIcvSgidKzaH=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.GetDefaultParams()
   eRJTBQCpyAklYDnrUGhIcvSgidKzab='/cf/filters'
   eRJTBQCpyAklYDnrUGhIcvSgidKzqo={'type':maintype}
   eRJTBQCpyAklYDnrUGhIcvSgidKzaO=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.makeurl(eRJTBQCpyAklYDnrUGhIcvSgidKzaF.API_DOMAIN,eRJTBQCpyAklYDnrUGhIcvSgidKzab)
   eRJTBQCpyAklYDnrUGhIcvSgidKzqo.update(eRJTBQCpyAklYDnrUGhIcvSgidKzaH)
   eRJTBQCpyAklYDnrUGhIcvSgidKzaw=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.callRequestCookies('Get',eRJTBQCpyAklYDnrUGhIcvSgidKzaO,payload=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,params=eRJTBQCpyAklYDnrUGhIcvSgidKzqo,headers=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,cookies=eRJTBQCpyAklYDnrUGhIcvSgidKzMF)
   eRJTBQCpyAklYDnrUGhIcvSgidKzas=json.loads(eRJTBQCpyAklYDnrUGhIcvSgidKzaw.text)
   if not(maintype in eRJTBQCpyAklYDnrUGhIcvSgidKzas):return eRJTBQCpyAklYDnrUGhIcvSgidKzMF 
   eRJTBQCpyAklYDnrUGhIcvSgidKzFq=eRJTBQCpyAklYDnrUGhIcvSgidKzas[maintype]
   if subtype=='-':
    for eRJTBQCpyAklYDnrUGhIcvSgidKzqf in eRJTBQCpyAklYDnrUGhIcvSgidKzFq:
     eRJTBQCpyAklYDnrUGhIcvSgidKzFj=eRJTBQCpyAklYDnrUGhIcvSgidKzMV(urllib.parse.parse_qsl(urllib.parse.urlsplit(eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('url')).query))
     eRJTBQCpyAklYDnrUGhIcvSgidKzjP={'title':eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('text'),'genre':eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('id'),'subgenre':'-','adult':eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('adult'),'broadcastid':eRJTBQCpyAklYDnrUGhIcvSgidKzFj.get('broadcastid'),'contenttype':eRJTBQCpyAklYDnrUGhIcvSgidKzFj.get('contenttype'),'uiparent':eRJTBQCpyAklYDnrUGhIcvSgidKzFj.get('uiparent'),'uirank':eRJTBQCpyAklYDnrUGhIcvSgidKzFj.get('uirank'),'uitype':eRJTBQCpyAklYDnrUGhIcvSgidKzFj.get('uitype'),'orderby':eRJTBQCpyAklYDnrUGhIcvSgidKzju,'ordernm':ordernm}
     if exclusion21==eRJTBQCpyAklYDnrUGhIcvSgidKzMx or eRJTBQCpyAklYDnrUGhIcvSgidKzjP.get('adult')=='n':
      eRJTBQCpyAklYDnrUGhIcvSgidKzFa.append(eRJTBQCpyAklYDnrUGhIcvSgidKzjP)
   else:
    for eRJTBQCpyAklYDnrUGhIcvSgidKzqf in eRJTBQCpyAklYDnrUGhIcvSgidKzFq:
     if eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('id')==subtype:
      for tt in eRJTBQCpyAklYDnrUGhIcvSgidKzqf['sublist']:
       eRJTBQCpyAklYDnrUGhIcvSgidKzFj=eRJTBQCpyAklYDnrUGhIcvSgidKzMV(urlparse.parse_qsl(urlparse.urlsplit(tt.get('url')).query))
       eRJTBQCpyAklYDnrUGhIcvSgidKzjP={'title':tt.get('text'),'genre':subtype,'subgenre':tt.get('id'),'adult':tt.get('adult'),'broadcastid':eRJTBQCpyAklYDnrUGhIcvSgidKzFj.get('broadcastid'),'contenttype':eRJTBQCpyAklYDnrUGhIcvSgidKzFj.get('contenttype'),'uiparent':eRJTBQCpyAklYDnrUGhIcvSgidKzFj.get('uiparent'),'uirank':eRJTBQCpyAklYDnrUGhIcvSgidKzFj.get('uirank'),'uitype':eRJTBQCpyAklYDnrUGhIcvSgidKzFj.get('uitype'),'orderby':eRJTBQCpyAklYDnrUGhIcvSgidKzju,'ordernm':ordernm}
       eRJTBQCpyAklYDnrUGhIcvSgidKzFa.append(eRJTBQCpyAklYDnrUGhIcvSgidKzjP)
      break
  except eRJTBQCpyAklYDnrUGhIcvSgidKzMN as exception:
   eRJTBQCpyAklYDnrUGhIcvSgidKzMX(exception)
  return eRJTBQCpyAklYDnrUGhIcvSgidKzFa
 def GetGenreGroup_sub(eRJTBQCpyAklYDnrUGhIcvSgidKzaF,in_params):
  eRJTBQCpyAklYDnrUGhIcvSgidKzFa=[]
  try:
   eRJTBQCpyAklYDnrUGhIcvSgidKzaH=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.GetDefaultParams()
   eRJTBQCpyAklYDnrUGhIcvSgidKzab='/cf/vod/newcontents'
   eRJTBQCpyAklYDnrUGhIcvSgidKzqo={'WeekDay':'all','limit':'20','offset':'0','orderby':in_params.get('orderby'),'adult':in_params.get('adult'),'broadcastid':in_params.get('broadcastid'),'contenttype':in_params.get('contenttype'),'genre':in_params.get('genre'),'uiparent':in_params.get('uiparent'),'uirank':in_params.get('uirank'),'uitype':in_params.get('uitype')}
   eRJTBQCpyAklYDnrUGhIcvSgidKzaO=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.makeurl(eRJTBQCpyAklYDnrUGhIcvSgidKzaF.API_DOMAIN,eRJTBQCpyAklYDnrUGhIcvSgidKzab)
   eRJTBQCpyAklYDnrUGhIcvSgidKzqo.update(eRJTBQCpyAklYDnrUGhIcvSgidKzaH)
   eRJTBQCpyAklYDnrUGhIcvSgidKzaw=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.callRequestCookies('Get',eRJTBQCpyAklYDnrUGhIcvSgidKzaO,payload=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,params=eRJTBQCpyAklYDnrUGhIcvSgidKzqo,headers=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,cookies=eRJTBQCpyAklYDnrUGhIcvSgidKzMF)
   eRJTBQCpyAklYDnrUGhIcvSgidKzas=json.loads(eRJTBQCpyAklYDnrUGhIcvSgidKzaw.text)
   if not('filter_item_list' in eRJTBQCpyAklYDnrUGhIcvSgidKzas['filter']['filterlist'][1]):return eRJTBQCpyAklYDnrUGhIcvSgidKzMF 
   eRJTBQCpyAklYDnrUGhIcvSgidKzFq=eRJTBQCpyAklYDnrUGhIcvSgidKzas['filter']['filterlist'][1]['filter_item_list']
   for eRJTBQCpyAklYDnrUGhIcvSgidKzqf in eRJTBQCpyAklYDnrUGhIcvSgidKzFq:
    eRJTBQCpyAklYDnrUGhIcvSgidKzjP={'broadcastid':in_params.get('broadcastid'),'contenttype':in_params.get('contenttype'),'genre':in_params.get('genre'),'uiparent':in_params.get('uiparent'),'uirank':in_params.get('uirank'),'uitype':in_params.get('uitype'),'adult':eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('adult'),'title':eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('title'),'subgenre':eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('api_parameters')[eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('api_parameters').find('=')+1:],'orderby':in_params.get('orderby')}
    eRJTBQCpyAklYDnrUGhIcvSgidKzFa.append(eRJTBQCpyAklYDnrUGhIcvSgidKzjP)
  except eRJTBQCpyAklYDnrUGhIcvSgidKzMN as exception:
   eRJTBQCpyAklYDnrUGhIcvSgidKzMX(exception)
  return eRJTBQCpyAklYDnrUGhIcvSgidKzFa
 def GetGenreList(eRJTBQCpyAklYDnrUGhIcvSgidKzaF,genre,in_params,page_int,addinfoyn=eRJTBQCpyAklYDnrUGhIcvSgidKzMx):
  eRJTBQCpyAklYDnrUGhIcvSgidKzFa=[]
  eRJTBQCpyAklYDnrUGhIcvSgidKzqu=eRJTBQCpyAklYDnrUGhIcvSgidKzjf=1
  eRJTBQCpyAklYDnrUGhIcvSgidKzqm=eRJTBQCpyAklYDnrUGhIcvSgidKzMx
  try:
   eRJTBQCpyAklYDnrUGhIcvSgidKzaH=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.GetDefaultParams()
   eRJTBQCpyAklYDnrUGhIcvSgidKzqo={'WeekDay':'all','adult':in_params.get('adult'),'broadcastid':in_params.get('broadcastid'),'contenttype':in_params.get('contenttype'),'genre':in_params.get('genre'),'orderby':in_params.get('orderby'),'uiparent':in_params.get('uiparent'),'uirank':in_params.get('uirank'),'uitype':in_params.get('uitype')}
   if genre=='vodgenre':
    eRJTBQCpyAklYDnrUGhIcvSgidKzab='/cf/vod/newcontents'
    if in_params.get('subgenre')!='-':
     eRJTBQCpyAklYDnrUGhIcvSgidKzqo['subgenre']=in_params.get('subgenre')
   else:
    eRJTBQCpyAklYDnrUGhIcvSgidKzab='/cf/movie/contents'
    eRJTBQCpyAklYDnrUGhIcvSgidKzqo['price'] ='all'
    eRJTBQCpyAklYDnrUGhIcvSgidKzqo['sptheme']='svod' 
   eRJTBQCpyAklYDnrUGhIcvSgidKzqo['limit']=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.LIST_LIMIT
   eRJTBQCpyAklYDnrUGhIcvSgidKzqo['offset']=eRJTBQCpyAklYDnrUGhIcvSgidKzMH((page_int-1)*eRJTBQCpyAklYDnrUGhIcvSgidKzaF.LIST_LIMIT)
   eRJTBQCpyAklYDnrUGhIcvSgidKzqo['page'] =eRJTBQCpyAklYDnrUGhIcvSgidKzMH(page_int)
   eRJTBQCpyAklYDnrUGhIcvSgidKzaO=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.makeurl(eRJTBQCpyAklYDnrUGhIcvSgidKzaF.API_DOMAIN,eRJTBQCpyAklYDnrUGhIcvSgidKzab)
   eRJTBQCpyAklYDnrUGhIcvSgidKzqo.update(eRJTBQCpyAklYDnrUGhIcvSgidKzaH)
   eRJTBQCpyAklYDnrUGhIcvSgidKzaw=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.callRequestCookies('Get',eRJTBQCpyAklYDnrUGhIcvSgidKzaO,payload=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,params=eRJTBQCpyAklYDnrUGhIcvSgidKzqo,headers=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,cookies=eRJTBQCpyAklYDnrUGhIcvSgidKzMF)
   eRJTBQCpyAklYDnrUGhIcvSgidKzas=json.loads(eRJTBQCpyAklYDnrUGhIcvSgidKzaw.text)
   if not('celllist' in eRJTBQCpyAklYDnrUGhIcvSgidKzas['cell_toplist']):return eRJTBQCpyAklYDnrUGhIcvSgidKzMF 
   eRJTBQCpyAklYDnrUGhIcvSgidKzFq=eRJTBQCpyAklYDnrUGhIcvSgidKzas['cell_toplist']['celllist']
   for eRJTBQCpyAklYDnrUGhIcvSgidKzqf in eRJTBQCpyAklYDnrUGhIcvSgidKzFq:
    eRJTBQCpyAklYDnrUGhIcvSgidKzjx={}
    eRJTBQCpyAklYDnrUGhIcvSgidKzjm=tmp_thumbnail=''
    eRJTBQCpyAklYDnrUGhIcvSgidKzjm =eRJTBQCpyAklYDnrUGhIcvSgidKzqf['title_list'][0]['text']
    if(eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('thumbnail')!=''):tmp_thumbnail='https://%s'%eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('thumbnail')
    for eRJTBQCpyAklYDnrUGhIcvSgidKzqO in eRJTBQCpyAklYDnrUGhIcvSgidKzqf['event_list'][0]['bodylist']:
     if re.search(r'uicode:',eRJTBQCpyAklYDnrUGhIcvSgidKzqO):
      eRJTBQCpyAklYDnrUGhIcvSgidKzjx['title'] =eRJTBQCpyAklYDnrUGhIcvSgidKzjm
      eRJTBQCpyAklYDnrUGhIcvSgidKzjx['mpaa'] =eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('age')
      if genre=='moviegenre_svod':
       eRJTBQCpyAklYDnrUGhIcvSgidKzjx['mediatype']='movie' 
      else:
       eRJTBQCpyAklYDnrUGhIcvSgidKzjx['mediatype']='episode' 
      eRJTBQCpyAklYDnrUGhIcvSgidKzjP={'title':eRJTBQCpyAklYDnrUGhIcvSgidKzjm,'uicode':re.sub(r'uicode:','',eRJTBQCpyAklYDnrUGhIcvSgidKzqO),'thumbnail':tmp_thumbnail,'viewage':eRJTBQCpyAklYDnrUGhIcvSgidKzqf.get('age'),'info':eRJTBQCpyAklYDnrUGhIcvSgidKzjx}
    eRJTBQCpyAklYDnrUGhIcvSgidKzFa.append(eRJTBQCpyAklYDnrUGhIcvSgidKzjP)
   eRJTBQCpyAklYDnrUGhIcvSgidKzqu=eRJTBQCpyAklYDnrUGhIcvSgidKzMW(eRJTBQCpyAklYDnrUGhIcvSgidKzas['cell_toplist']['pagecount'])
   if eRJTBQCpyAklYDnrUGhIcvSgidKzas['cell_toplist']['count']:eRJTBQCpyAklYDnrUGhIcvSgidKzjf =eRJTBQCpyAklYDnrUGhIcvSgidKzMW(eRJTBQCpyAklYDnrUGhIcvSgidKzas['cell_toplist']['count'])
   else:eRJTBQCpyAklYDnrUGhIcvSgidKzjf=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.LIST_LIMIT
   eRJTBQCpyAklYDnrUGhIcvSgidKzqm=eRJTBQCpyAklYDnrUGhIcvSgidKzqu>eRJTBQCpyAklYDnrUGhIcvSgidKzjf
  except eRJTBQCpyAklYDnrUGhIcvSgidKzMN as exception:
   eRJTBQCpyAklYDnrUGhIcvSgidKzMX(exception)
  try:
   if genre=='moviegenre_svod' and addinfoyn==eRJTBQCpyAklYDnrUGhIcvSgidKzMO:
    eRJTBQCpyAklYDnrUGhIcvSgidKzjH=[]
    eRJTBQCpyAklYDnrUGhIcvSgidKzjO={}
    for eRJTBQCpyAklYDnrUGhIcvSgidKzjN in eRJTBQCpyAklYDnrUGhIcvSgidKzFa:eRJTBQCpyAklYDnrUGhIcvSgidKzjH.append(eRJTBQCpyAklYDnrUGhIcvSgidKzjN.get('uicode'))
    eRJTBQCpyAklYDnrUGhIcvSgidKzjO=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.GetMovieInfoList(eRJTBQCpyAklYDnrUGhIcvSgidKzjH)
    for i in eRJTBQCpyAklYDnrUGhIcvSgidKzMf(eRJTBQCpyAklYDnrUGhIcvSgidKzMu(eRJTBQCpyAklYDnrUGhIcvSgidKzFa)):
     eRJTBQCpyAklYDnrUGhIcvSgidKzFa[i]['info']=eRJTBQCpyAklYDnrUGhIcvSgidKzjO.get(eRJTBQCpyAklYDnrUGhIcvSgidKzFa[i]['uicode'])
  except:
   eRJTBQCpyAklYDnrUGhIcvSgidKzMF
  return eRJTBQCpyAklYDnrUGhIcvSgidKzFa,eRJTBQCpyAklYDnrUGhIcvSgidKzqm
 def GetEPGList(eRJTBQCpyAklYDnrUGhIcvSgidKzaF,genre):
  eRJTBQCpyAklYDnrUGhIcvSgidKzFM={}
  try:
   import datetime
   eRJTBQCpyAklYDnrUGhIcvSgidKzFx=datetime.datetime.now()
   if genre=='all':
    eRJTBQCpyAklYDnrUGhIcvSgidKzFf =eRJTBQCpyAklYDnrUGhIcvSgidKzFx+datetime.timedelta(hours=2)
   else:
    eRJTBQCpyAklYDnrUGhIcvSgidKzFf =eRJTBQCpyAklYDnrUGhIcvSgidKzFx+datetime.timedelta(hours=3)
   eRJTBQCpyAklYDnrUGhIcvSgidKzaH=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.GetDefaultParams()
   eRJTBQCpyAklYDnrUGhIcvSgidKzqo={'limit':'100','offset':'0','genre':genre,'startdatetime':eRJTBQCpyAklYDnrUGhIcvSgidKzFx.strftime('%Y-%m-%d %H:%M'),'enddatetime':eRJTBQCpyAklYDnrUGhIcvSgidKzFf.strftime('%Y-%m-%d %H:%M')}
   eRJTBQCpyAklYDnrUGhIcvSgidKzab='/live/epgs'
   eRJTBQCpyAklYDnrUGhIcvSgidKzaO=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.makeurl(eRJTBQCpyAklYDnrUGhIcvSgidKzaF.API_DOMAIN,eRJTBQCpyAklYDnrUGhIcvSgidKzab)
   eRJTBQCpyAklYDnrUGhIcvSgidKzqo.update(eRJTBQCpyAklYDnrUGhIcvSgidKzaH)
   eRJTBQCpyAklYDnrUGhIcvSgidKzaw=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.callRequestCookies('Get',eRJTBQCpyAklYDnrUGhIcvSgidKzaO,payload=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,params=eRJTBQCpyAklYDnrUGhIcvSgidKzqo,headers=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,cookies=eRJTBQCpyAklYDnrUGhIcvSgidKzMF)
   eRJTBQCpyAklYDnrUGhIcvSgidKzas=json.loads(eRJTBQCpyAklYDnrUGhIcvSgidKzaw.text)
   eRJTBQCpyAklYDnrUGhIcvSgidKzFH=eRJTBQCpyAklYDnrUGhIcvSgidKzas['list']
   for eRJTBQCpyAklYDnrUGhIcvSgidKzqf in eRJTBQCpyAklYDnrUGhIcvSgidKzFH:
    eRJTBQCpyAklYDnrUGhIcvSgidKzFO=''
    for eRJTBQCpyAklYDnrUGhIcvSgidKzFN in eRJTBQCpyAklYDnrUGhIcvSgidKzqf['list']:
     if eRJTBQCpyAklYDnrUGhIcvSgidKzFO:eRJTBQCpyAklYDnrUGhIcvSgidKzFO+='\n'
     eRJTBQCpyAklYDnrUGhIcvSgidKzFO+=eRJTBQCpyAklYDnrUGhIcvSgidKzFN['title']+'\n'
     eRJTBQCpyAklYDnrUGhIcvSgidKzFO+=' [%s ~ %s]'%(eRJTBQCpyAklYDnrUGhIcvSgidKzFN['starttime'][-5:],eRJTBQCpyAklYDnrUGhIcvSgidKzFN['endtime'][-5:])+'\n'
    eRJTBQCpyAklYDnrUGhIcvSgidKzFM[eRJTBQCpyAklYDnrUGhIcvSgidKzqf['channelid']]=eRJTBQCpyAklYDnrUGhIcvSgidKzFO
  except eRJTBQCpyAklYDnrUGhIcvSgidKzMN as exception:
   eRJTBQCpyAklYDnrUGhIcvSgidKzMX(exception)
  return eRJTBQCpyAklYDnrUGhIcvSgidKzFM
 def GetMovieInfoList(eRJTBQCpyAklYDnrUGhIcvSgidKzaF,movie_list):
  eRJTBQCpyAklYDnrUGhIcvSgidKzFX={}
  try:
   eRJTBQCpyAklYDnrUGhIcvSgidKzaH =eRJTBQCpyAklYDnrUGhIcvSgidKzaF.GetDefaultParams()
   eRJTBQCpyAklYDnrUGhIcvSgidKzab=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.API_DOMAIN+'/movie/contents/'
   for eRJTBQCpyAklYDnrUGhIcvSgidKzjN in movie_list:
    eRJTBQCpyAklYDnrUGhIcvSgidKzaO=eRJTBQCpyAklYDnrUGhIcvSgidKzab+eRJTBQCpyAklYDnrUGhIcvSgidKzjN
    eRJTBQCpyAklYDnrUGhIcvSgidKzaw=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.callRequestCookies('Get',eRJTBQCpyAklYDnrUGhIcvSgidKzaO,payload=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,params=eRJTBQCpyAklYDnrUGhIcvSgidKzaH,headers=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,cookies=eRJTBQCpyAklYDnrUGhIcvSgidKzMF)
    eRJTBQCpyAklYDnrUGhIcvSgidKzas=json.loads(eRJTBQCpyAklYDnrUGhIcvSgidKzaw.text)
    eRJTBQCpyAklYDnrUGhIcvSgidKzjx={}
    eRJTBQCpyAklYDnrUGhIcvSgidKzjx['mediatype']='movie'
    eRJTBQCpyAklYDnrUGhIcvSgidKzFu=[]
    for eRJTBQCpyAklYDnrUGhIcvSgidKzFV in eRJTBQCpyAklYDnrUGhIcvSgidKzas['actors']['list']:eRJTBQCpyAklYDnrUGhIcvSgidKzFu.append(eRJTBQCpyAklYDnrUGhIcvSgidKzFV.get('text'))
    if eRJTBQCpyAklYDnrUGhIcvSgidKzFu[0]!='':eRJTBQCpyAklYDnrUGhIcvSgidKzjx['cast']=eRJTBQCpyAklYDnrUGhIcvSgidKzFu
    eRJTBQCpyAklYDnrUGhIcvSgidKzFW=[]
    for eRJTBQCpyAklYDnrUGhIcvSgidKzFm in eRJTBQCpyAklYDnrUGhIcvSgidKzas['directors']['list']:eRJTBQCpyAklYDnrUGhIcvSgidKzFW.append(eRJTBQCpyAklYDnrUGhIcvSgidKzFm.get('text'))
    if eRJTBQCpyAklYDnrUGhIcvSgidKzFW[0]!='':eRJTBQCpyAklYDnrUGhIcvSgidKzjx['director']=eRJTBQCpyAklYDnrUGhIcvSgidKzFW
    eRJTBQCpyAklYDnrUGhIcvSgidKzFa=[]
    for eRJTBQCpyAklYDnrUGhIcvSgidKzFL in eRJTBQCpyAklYDnrUGhIcvSgidKzas['genre']['list']:eRJTBQCpyAklYDnrUGhIcvSgidKzFa.append(eRJTBQCpyAklYDnrUGhIcvSgidKzFL.get('text'))
    if eRJTBQCpyAklYDnrUGhIcvSgidKzFa[0]!='':eRJTBQCpyAklYDnrUGhIcvSgidKzjx['genre']=eRJTBQCpyAklYDnrUGhIcvSgidKzFa
    if eRJTBQCpyAklYDnrUGhIcvSgidKzas.get('releasedate')!='':
     eRJTBQCpyAklYDnrUGhIcvSgidKzjx['year'] =eRJTBQCpyAklYDnrUGhIcvSgidKzas['releasedate'][:4]
     eRJTBQCpyAklYDnrUGhIcvSgidKzjx['aired'] =eRJTBQCpyAklYDnrUGhIcvSgidKzas['releasedate']
    eRJTBQCpyAklYDnrUGhIcvSgidKzjx['country']=eRJTBQCpyAklYDnrUGhIcvSgidKzas['country']
    eRJTBQCpyAklYDnrUGhIcvSgidKzjx['duration']=eRJTBQCpyAklYDnrUGhIcvSgidKzas['playtime']
    eRJTBQCpyAklYDnrUGhIcvSgidKzjx['title'] =eRJTBQCpyAklYDnrUGhIcvSgidKzas['title']
    eRJTBQCpyAklYDnrUGhIcvSgidKzjx['mpaa'] =eRJTBQCpyAklYDnrUGhIcvSgidKzas['targetage']
    eRJTBQCpyAklYDnrUGhIcvSgidKzjx['plot'] =eRJTBQCpyAklYDnrUGhIcvSgidKzas['synopsis']
    eRJTBQCpyAklYDnrUGhIcvSgidKzFX[eRJTBQCpyAklYDnrUGhIcvSgidKzjN]=eRJTBQCpyAklYDnrUGhIcvSgidKzjx
  except eRJTBQCpyAklYDnrUGhIcvSgidKzMN as exception:
   return{}
  return eRJTBQCpyAklYDnrUGhIcvSgidKzFX
 def GetStreamingURL(eRJTBQCpyAklYDnrUGhIcvSgidKzaF,eRJTBQCpyAklYDnrUGhIcvSgidKzqW,eRJTBQCpyAklYDnrUGhIcvSgidKzqV,quality_int):
  eRJTBQCpyAklYDnrUGhIcvSgidKzFE=eRJTBQCpyAklYDnrUGhIcvSgidKzMa=eRJTBQCpyAklYDnrUGhIcvSgidKzMq=streaming_preview=''
  eRJTBQCpyAklYDnrUGhIcvSgidKzFo=[]
  try:
   if eRJTBQCpyAklYDnrUGhIcvSgidKzqV=='channel':
    eRJTBQCpyAklYDnrUGhIcvSgidKzab='/live/channels/'+eRJTBQCpyAklYDnrUGhIcvSgidKzqW
    eRJTBQCpyAklYDnrUGhIcvSgidKzFt='live'
   elif eRJTBQCpyAklYDnrUGhIcvSgidKzqV=='movie':
    eRJTBQCpyAklYDnrUGhIcvSgidKzab='/cf/movie/contents/'+eRJTBQCpyAklYDnrUGhIcvSgidKzqW
    eRJTBQCpyAklYDnrUGhIcvSgidKzFt='movie'
   else: 
    eRJTBQCpyAklYDnrUGhIcvSgidKzab='/cf/vod/contents/'+eRJTBQCpyAklYDnrUGhIcvSgidKzqW
    eRJTBQCpyAklYDnrUGhIcvSgidKzFt='vod'
   eRJTBQCpyAklYDnrUGhIcvSgidKzaH=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.GetDefaultParams()
   eRJTBQCpyAklYDnrUGhIcvSgidKzaO=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.makeurl(eRJTBQCpyAklYDnrUGhIcvSgidKzaF.API_DOMAIN,eRJTBQCpyAklYDnrUGhIcvSgidKzab)
   eRJTBQCpyAklYDnrUGhIcvSgidKzaw=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.callRequestCookies('Get',eRJTBQCpyAklYDnrUGhIcvSgidKzaO,payload=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,params=eRJTBQCpyAklYDnrUGhIcvSgidKzaH,headers=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,cookies=eRJTBQCpyAklYDnrUGhIcvSgidKzMF)
   eRJTBQCpyAklYDnrUGhIcvSgidKzas=json.loads(eRJTBQCpyAklYDnrUGhIcvSgidKzaw.text)
   eRJTBQCpyAklYDnrUGhIcvSgidKzFb=eRJTBQCpyAklYDnrUGhIcvSgidKzas['qualities']['list']
   if eRJTBQCpyAklYDnrUGhIcvSgidKzFb==eRJTBQCpyAklYDnrUGhIcvSgidKzMF:return(eRJTBQCpyAklYDnrUGhIcvSgidKzFE,eRJTBQCpyAklYDnrUGhIcvSgidKzMa,eRJTBQCpyAklYDnrUGhIcvSgidKzMq,streaming_preview)
   eRJTBQCpyAklYDnrUGhIcvSgidKzFP='hls'
   if 'drms' in eRJTBQCpyAklYDnrUGhIcvSgidKzas:
    if eRJTBQCpyAklYDnrUGhIcvSgidKzas['drms']:
     eRJTBQCpyAklYDnrUGhIcvSgidKzFP='dash'
   if 'type' in eRJTBQCpyAklYDnrUGhIcvSgidKzas:
    if eRJTBQCpyAklYDnrUGhIcvSgidKzas['type']=='onair':
     eRJTBQCpyAklYDnrUGhIcvSgidKzFt='onairvod'
   for eRJTBQCpyAklYDnrUGhIcvSgidKzFw in eRJTBQCpyAklYDnrUGhIcvSgidKzFb:
    eRJTBQCpyAklYDnrUGhIcvSgidKzFo.append(eRJTBQCpyAklYDnrUGhIcvSgidKzMW(eRJTBQCpyAklYDnrUGhIcvSgidKzFw.get('id').rstrip('p')))
  except eRJTBQCpyAklYDnrUGhIcvSgidKzMN as exception:
   return(eRJTBQCpyAklYDnrUGhIcvSgidKzFE,eRJTBQCpyAklYDnrUGhIcvSgidKzMa,eRJTBQCpyAklYDnrUGhIcvSgidKzMq,streaming_preview)
  try:
   eRJTBQCpyAklYDnrUGhIcvSgidKzFs=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.CheckQuality(quality_int,eRJTBQCpyAklYDnrUGhIcvSgidKzFo)
   eRJTBQCpyAklYDnrUGhIcvSgidKzab='/streaming'
   eRJTBQCpyAklYDnrUGhIcvSgidKzqo={'contentid':eRJTBQCpyAklYDnrUGhIcvSgidKzqW,'contenttype':eRJTBQCpyAklYDnrUGhIcvSgidKzFt,'action':eRJTBQCpyAklYDnrUGhIcvSgidKzFP,'quality':eRJTBQCpyAklYDnrUGhIcvSgidKzMH(eRJTBQCpyAklYDnrUGhIcvSgidKzFs)+'p','deviceModelId':'Windows 10','guid':eRJTBQCpyAklYDnrUGhIcvSgidKzaF.GetGUID(guidType=2),'lastplayid':eRJTBQCpyAklYDnrUGhIcvSgidKzaF.guid,'authtype':'cookie','isabr':'y','ishevc':'n'}
   eRJTBQCpyAklYDnrUGhIcvSgidKzaO=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.makeurl(eRJTBQCpyAklYDnrUGhIcvSgidKzaF.API_DOMAIN,eRJTBQCpyAklYDnrUGhIcvSgidKzab)
   eRJTBQCpyAklYDnrUGhIcvSgidKzqo.update(eRJTBQCpyAklYDnrUGhIcvSgidKzaH)
   eRJTBQCpyAklYDnrUGhIcvSgidKzaw=eRJTBQCpyAklYDnrUGhIcvSgidKzaF.callRequestCookies('Get',eRJTBQCpyAklYDnrUGhIcvSgidKzaO,payload=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,params=eRJTBQCpyAklYDnrUGhIcvSgidKzqo,headers=eRJTBQCpyAklYDnrUGhIcvSgidKzMF,cookies=eRJTBQCpyAklYDnrUGhIcvSgidKzMF)
   eRJTBQCpyAklYDnrUGhIcvSgidKzas=json.loads(eRJTBQCpyAklYDnrUGhIcvSgidKzaw.text)
   eRJTBQCpyAklYDnrUGhIcvSgidKzFE=eRJTBQCpyAklYDnrUGhIcvSgidKzas['playurl']
   if eRJTBQCpyAklYDnrUGhIcvSgidKzFE==eRJTBQCpyAklYDnrUGhIcvSgidKzMF:return eRJTBQCpyAklYDnrUGhIcvSgidKzMF
   eRJTBQCpyAklYDnrUGhIcvSgidKzMa=eRJTBQCpyAklYDnrUGhIcvSgidKzas['awscookie']
   eRJTBQCpyAklYDnrUGhIcvSgidKzMq =eRJTBQCpyAklYDnrUGhIcvSgidKzas['drm']
   if 'previewmsg' in eRJTBQCpyAklYDnrUGhIcvSgidKzas['preview']:streaming_preview=eRJTBQCpyAklYDnrUGhIcvSgidKzas['preview']['previewmsg']
  except eRJTBQCpyAklYDnrUGhIcvSgidKzMN as exception:
   eRJTBQCpyAklYDnrUGhIcvSgidKzMX(exception)
  eRJTBQCpyAklYDnrUGhIcvSgidKzFE=eRJTBQCpyAklYDnrUGhIcvSgidKzFE.replace('pooq.co.kr','wavve.com')
  return(eRJTBQCpyAklYDnrUGhIcvSgidKzFE,eRJTBQCpyAklYDnrUGhIcvSgidKzMa,eRJTBQCpyAklYDnrUGhIcvSgidKzMq,streaming_preview) 
# Created by pyminifier (https://github.com/liftoff/pyminifier)
