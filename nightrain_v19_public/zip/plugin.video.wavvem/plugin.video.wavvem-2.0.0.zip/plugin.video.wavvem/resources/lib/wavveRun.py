__author__="NightRain"
OGdvXBPaUQrfxsSApMHwJKqhcDLmlC=object
OGdvXBPaUQrfxsSApMHwJKqhcDLmlR=None
OGdvXBPaUQrfxsSApMHwJKqhcDLmly=False
OGdvXBPaUQrfxsSApMHwJKqhcDLmlE=int
OGdvXBPaUQrfxsSApMHwJKqhcDLmlz=True
OGdvXBPaUQrfxsSApMHwJKqhcDLmNI=len
OGdvXBPaUQrfxsSApMHwJKqhcDLmNY=TypeError
OGdvXBPaUQrfxsSApMHwJKqhcDLmNe=str
OGdvXBPaUQrfxsSApMHwJKqhcDLmNt=dict
OGdvXBPaUQrfxsSApMHwJKqhcDLmNl=open
OGdvXBPaUQrfxsSApMHwJKqhcDLmNi=Exception
OGdvXBPaUQrfxsSApMHwJKqhcDLmNj=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
OGdvXBPaUQrfxsSApMHwJKqhcDLmIe=[{'title':'홈','uicode':'GN1','came':'home'},{'title':'LIVE 채널','uicode':'GN3','came':'live'},{'title':'VOD 방송','uicode':'GN2','came':'broadcast'},{'title':'영화(Movie)','uicode':'GN17','came':'movie'},{'title':'해외시리즈','uicode':'GN12','came':'global'},{'title':'분류별 - 방송(VOD) - 인기순','uicode':'GENRE','came':'vodgenre','orderby':'viewtime','ordernm':'인기순'},{'title':'분류별 - 방송(VOD) - 최신순','uicode':'GENRE','came':'vodgenre','orderby':'new','ordernm':'최신순'},{'title':'분류별 - 영화(Movie) - 인기순','uicode':'GENRE','came':'moviegenre_svod','orderby':'paid','ordernm':'인기순'},{'title':'분류별 - 영화(Movie) - 업데이트순','uicode':'GENRE','came':'moviegenre_svod','orderby':'displaystart','ordernm':'업데이트순'},{'title':'검색','uicode':'SEARCH','came':'-'},{'title':'Watched(시청목록)','uicode':'WATCH','came':'-'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmc.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
OGdvXBPaUQrfxsSApMHwJKqhcDLmIt='Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'
OGdvXBPaUQrfxsSApMHwJKqhcDLmIl=xbmc.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
from wavveCore import*
class OGdvXBPaUQrfxsSApMHwJKqhcDLmIY(OGdvXBPaUQrfxsSApMHwJKqhcDLmlC):
 def __init__(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN,OGdvXBPaUQrfxsSApMHwJKqhcDLmIi,OGdvXBPaUQrfxsSApMHwJKqhcDLmIj,OGdvXBPaUQrfxsSApMHwJKqhcDLmIg):
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIN._addon_url =OGdvXBPaUQrfxsSApMHwJKqhcDLmIi
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIN._addon_handle=OGdvXBPaUQrfxsSApMHwJKqhcDLmIj
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.main_params =OGdvXBPaUQrfxsSApMHwJKqhcDLmIg
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.WavveObj =eRJTBQCpyAklYDnrUGhIcvSgidKzaq() 
 def addon_noti(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN,sting):
  try:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIo=xbmcgui.Dialog()
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIo.notification(__addonname__,sting)
  except:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmlR
 def addon_log(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN,string,isDebug=OGdvXBPaUQrfxsSApMHwJKqhcDLmly):
  try:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIu=string.encode('utf-8','ignore')
  except:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIu='addonException: addon_log'
  if isDebug:OGdvXBPaUQrfxsSApMHwJKqhcDLmIb=xbmc.LOGDEBUG
  else:OGdvXBPaUQrfxsSApMHwJKqhcDLmIb=xbmc.LOGNOTICE
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,OGdvXBPaUQrfxsSApMHwJKqhcDLmIu),level=OGdvXBPaUQrfxsSApMHwJKqhcDLmIb)
 def get_keyboard_input(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN,OGdvXBPaUQrfxsSApMHwJKqhcDLmYt):
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIF=OGdvXBPaUQrfxsSApMHwJKqhcDLmlR
  kb=xbmc.Keyboard()
  kb.setHeading(OGdvXBPaUQrfxsSApMHwJKqhcDLmYt)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIF=kb.getText()
  return OGdvXBPaUQrfxsSApMHwJKqhcDLmIF
 def get_settings_login_info(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN):
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIW =__addon__.getSetting('id')
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIT =__addon__.getSetting('pw')
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIV=__addon__.getSetting('selected_profile')
  return(OGdvXBPaUQrfxsSApMHwJKqhcDLmIW,OGdvXBPaUQrfxsSApMHwJKqhcDLmIT,OGdvXBPaUQrfxsSApMHwJKqhcDLmIV)
 def get_selQuality(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN):
  try:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIk=[1080,720,480,360]
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIC=OGdvXBPaUQrfxsSApMHwJKqhcDLmlE(__addon__.getSetting('selected_quality'))
   return OGdvXBPaUQrfxsSApMHwJKqhcDLmIk[OGdvXBPaUQrfxsSApMHwJKqhcDLmIC]
  except:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmlR
  return 1080 
 def get_settings_exclusion21(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN):
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIR =__addon__.getSetting('exclusion21')
  if OGdvXBPaUQrfxsSApMHwJKqhcDLmIR=='false':
   return OGdvXBPaUQrfxsSApMHwJKqhcDLmly
  else:
   return OGdvXBPaUQrfxsSApMHwJKqhcDLmlz
 def get_settings_direct_replay(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN):
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIy=OGdvXBPaUQrfxsSApMHwJKqhcDLmlE(__addon__.getSetting('direct_replay'))
  if OGdvXBPaUQrfxsSApMHwJKqhcDLmIy==0:
   return OGdvXBPaUQrfxsSApMHwJKqhcDLmly
  else:
   return OGdvXBPaUQrfxsSApMHwJKqhcDLmlz
 def get_settings_addinfo(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN):
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIE =__addon__.getSetting('add_infoyn')
  if OGdvXBPaUQrfxsSApMHwJKqhcDLmIE=='false':
   return OGdvXBPaUQrfxsSApMHwJKqhcDLmly
  else:
   return OGdvXBPaUQrfxsSApMHwJKqhcDLmlz
 def get_settings_thumbnail_landyn(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN):
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIz =OGdvXBPaUQrfxsSApMHwJKqhcDLmlE(__addon__.getSetting('thumbnail_way'))
  if OGdvXBPaUQrfxsSApMHwJKqhcDLmIz==0:
   return OGdvXBPaUQrfxsSApMHwJKqhcDLmlz
  else:
   return OGdvXBPaUQrfxsSApMHwJKqhcDLmly
 def set_winCredential(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN,credential):
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYI=xbmcgui.Window(10000)
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYI.setProperty('WAVVE_M_CREDENTIAL',credential)
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYI.setProperty('WAVVE_M_LOGINTIME',datetime.datetime.now().strftime('%Y-%m-%d'))
 def get_winCredential(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN):
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYI=xbmcgui.Window(10000)
  return OGdvXBPaUQrfxsSApMHwJKqhcDLmYI.getProperty('WAVVE_M_CREDENTIAL')
 def set_winEpisodeOrderby(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN,OGdvXBPaUQrfxsSApMHwJKqhcDLmYV):
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYI=xbmcgui.Window(10000)
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYI.setProperty('WAVVE_M_ORDERBY',OGdvXBPaUQrfxsSApMHwJKqhcDLmYV)
 def get_winEpisodeOrderby(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN):
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYI=xbmcgui.Window(10000)
  return OGdvXBPaUQrfxsSApMHwJKqhcDLmYI.getProperty('WAVVE_M_ORDERBY')
 def add_dir(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN,label,sublabel='',img='',infoLabels=OGdvXBPaUQrfxsSApMHwJKqhcDLmlR,isFolder=OGdvXBPaUQrfxsSApMHwJKqhcDLmlz,params=''):
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYe='%s?%s'%(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN._addon_url,urllib.parse.urlencode(params))
  if sublabel:OGdvXBPaUQrfxsSApMHwJKqhcDLmYt='%s < %s >'%(label,sublabel)
  else: OGdvXBPaUQrfxsSApMHwJKqhcDLmYt=label
  if not img:img='DefaultFolder.png'
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYl=xbmcgui.ListItem(OGdvXBPaUQrfxsSApMHwJKqhcDLmYt)
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYl.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:OGdvXBPaUQrfxsSApMHwJKqhcDLmYl.setInfo(type="video",infoLabels=infoLabels)
  if not isFolder:OGdvXBPaUQrfxsSApMHwJKqhcDLmYl.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN._addon_handle,OGdvXBPaUQrfxsSApMHwJKqhcDLmYe,OGdvXBPaUQrfxsSApMHwJKqhcDLmYl,isFolder)
 def dp_Main_List(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN):
  for OGdvXBPaUQrfxsSApMHwJKqhcDLmYN in OGdvXBPaUQrfxsSApMHwJKqhcDLmIe:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYt=OGdvXBPaUQrfxsSApMHwJKqhcDLmYN.get('title')
   if OGdvXBPaUQrfxsSApMHwJKqhcDLmYN.get('uicode')=='GENRE':
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYi={'mode':'GENRE','uicode':OGdvXBPaUQrfxsSApMHwJKqhcDLmYN.get('came'),'genre':'-','subgenre':'-','orderby':OGdvXBPaUQrfxsSApMHwJKqhcDLmYN.get('orderby'),'ordernm':OGdvXBPaUQrfxsSApMHwJKqhcDLmYN.get('ordernm')}
   elif OGdvXBPaUQrfxsSApMHwJKqhcDLmYN.get('uicode')=='WATCH':
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYi={'mode':'WATCH','genre':'-'}
   elif OGdvXBPaUQrfxsSApMHwJKqhcDLmYN.get('uicode')=='SEARCH':
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYi={'mode':'SEARCH','genre':'-'}
   else:
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYi={'mode':'GNB_LIST','uicode':OGdvXBPaUQrfxsSApMHwJKqhcDLmYN.get('uicode'),'came':OGdvXBPaUQrfxsSApMHwJKqhcDLmYN.get('came')}
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYj=OGdvXBPaUQrfxsSApMHwJKqhcDLmlz
   if OGdvXBPaUQrfxsSApMHwJKqhcDLmYN.get('uicode')=='XXX':
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYi['mode']='XXX'
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYj=OGdvXBPaUQrfxsSApMHwJKqhcDLmly
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.add_dir(OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,sublabel='',img='',infoLabels=OGdvXBPaUQrfxsSApMHwJKqhcDLmlR,isFolder=OGdvXBPaUQrfxsSApMHwJKqhcDLmYj,params=OGdvXBPaUQrfxsSApMHwJKqhcDLmYi)
  if OGdvXBPaUQrfxsSApMHwJKqhcDLmNI(OGdvXBPaUQrfxsSApMHwJKqhcDLmIe)>0:xbmcplugin.endOfDirectory(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN._addon_handle)
 def login_main(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN):
  (OGdvXBPaUQrfxsSApMHwJKqhcDLmYn,OGdvXBPaUQrfxsSApMHwJKqhcDLmYo,OGdvXBPaUQrfxsSApMHwJKqhcDLmYu)=OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.get_settings_login_info()
  if not(OGdvXBPaUQrfxsSApMHwJKqhcDLmYn and OGdvXBPaUQrfxsSApMHwJKqhcDLmYo):
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIo=xbmcgui.Dialog()
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYb=OGdvXBPaUQrfxsSApMHwJKqhcDLmIo.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if OGdvXBPaUQrfxsSApMHwJKqhcDLmYb==OGdvXBPaUQrfxsSApMHwJKqhcDLmlz:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.get_winEpisodeOrderby()=='':
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.set_winEpisodeOrderby('desc')
  if OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.cookiefile_check():return
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYF =datetime.datetime.now().date()
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYW=xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINTIME')
  if OGdvXBPaUQrfxsSApMHwJKqhcDLmYW==OGdvXBPaUQrfxsSApMHwJKqhcDLmlR or OGdvXBPaUQrfxsSApMHwJKqhcDLmYW=='':OGdvXBPaUQrfxsSApMHwJKqhcDLmYW='1900-01-01'
  try:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYW=datetime.datetime.strptime(OGdvXBPaUQrfxsSApMHwJKqhcDLmYW,'%Y-%m-%d').date()
  except OGdvXBPaUQrfxsSApMHwJKqhcDLmNY:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYW=datetime.datetime(*(time.strptime(OGdvXBPaUQrfxsSApMHwJKqhcDLmYW,'%Y-%m-%d')[0:6])).date()
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYT=0
   while OGdvXBPaUQrfxsSApMHwJKqhcDLmlz:
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYT+=1
    time.sleep(0.05)
    if OGdvXBPaUQrfxsSApMHwJKqhcDLmYW>=OGdvXBPaUQrfxsSApMHwJKqhcDLmYF:return
    if OGdvXBPaUQrfxsSApMHwJKqhcDLmYT>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  if OGdvXBPaUQrfxsSApMHwJKqhcDLmYW>=OGdvXBPaUQrfxsSApMHwJKqhcDLmYF:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   return
  if not OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.WavveObj.GetCredential(OGdvXBPaUQrfxsSApMHwJKqhcDLmYn,OGdvXBPaUQrfxsSApMHwJKqhcDLmYo,OGdvXBPaUQrfxsSApMHwJKqhcDLmYu):
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   sys.exit()
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.set_winCredential(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.WavveObj.LoadCredential())
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
 def dp_setEpOrderby(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN,args):
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYV =args.get('orderby')
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.set_winEpisodeOrderby(OGdvXBPaUQrfxsSApMHwJKqhcDLmYV)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Gnb_List(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN,args):
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.WavveObj.SaveCredential(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.get_winCredential())
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYk=OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.WavveObj.GetGnList(args.get('uicode'))
  for OGdvXBPaUQrfxsSApMHwJKqhcDLmYC in OGdvXBPaUQrfxsSApMHwJKqhcDLmYk:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYt=OGdvXBPaUQrfxsSApMHwJKqhcDLmYC.get('title')
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYi={'mode':'GN_LIST' if OGdvXBPaUQrfxsSApMHwJKqhcDLmYC.get('uicode')!='CY1' else 'GN_MYVIEW','uicode':OGdvXBPaUQrfxsSApMHwJKqhcDLmYC.get('uicode'),'came':args.get('came'),'page':'1'}
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.add_dir(OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,sublabel='',img='',infoLabels=OGdvXBPaUQrfxsSApMHwJKqhcDLmlR,isFolder=OGdvXBPaUQrfxsSApMHwJKqhcDLmlz,params=OGdvXBPaUQrfxsSApMHwJKqhcDLmYi)
  if OGdvXBPaUQrfxsSApMHwJKqhcDLmNI(OGdvXBPaUQrfxsSApMHwJKqhcDLmYk)>0:xbmcplugin.endOfDirectory(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN._addon_handle,cacheToDisc=OGdvXBPaUQrfxsSApMHwJKqhcDLmly)
 def dp_Myview_Group(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN,args):
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYt='VOD 시청내역'
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYi={'mode':'MYVIEW_LIST','uicode':'vod','page':'1'}
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.add_dir(OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,sublabel='',img='',infoLabels=OGdvXBPaUQrfxsSApMHwJKqhcDLmlR,isFolder=OGdvXBPaUQrfxsSApMHwJKqhcDLmlz,params=OGdvXBPaUQrfxsSApMHwJKqhcDLmYi)
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYt='영화 시청내역'
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYi['uicode']='movie'
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.add_dir(OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,sublabel='',img='',infoLabels=OGdvXBPaUQrfxsSApMHwJKqhcDLmlR,isFolder=OGdvXBPaUQrfxsSApMHwJKqhcDLmlz,params=OGdvXBPaUQrfxsSApMHwJKqhcDLmYi)
  xbmcplugin.endOfDirectory(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN._addon_handle)
 def dp_Myview_List(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN,args):
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.WavveObj.SaveCredential(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.get_winCredential())
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYR =OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.get_settings_addinfo()
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYy=args.get('uicode')
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYE =OGdvXBPaUQrfxsSApMHwJKqhcDLmlE(args.get('page'))
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYz,OGdvXBPaUQrfxsSApMHwJKqhcDLmeI=OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.WavveObj.GetMyviewList(OGdvXBPaUQrfxsSApMHwJKqhcDLmYy,OGdvXBPaUQrfxsSApMHwJKqhcDLmYE,addinfoyn=OGdvXBPaUQrfxsSApMHwJKqhcDLmYR)
  for OGdvXBPaUQrfxsSApMHwJKqhcDLmeY in OGdvXBPaUQrfxsSApMHwJKqhcDLmYz:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYt =OGdvXBPaUQrfxsSApMHwJKqhcDLmeY.get('title')
   OGdvXBPaUQrfxsSApMHwJKqhcDLmet =OGdvXBPaUQrfxsSApMHwJKqhcDLmeY.get('subtitle')
   OGdvXBPaUQrfxsSApMHwJKqhcDLmel=OGdvXBPaUQrfxsSApMHwJKqhcDLmeY.get('thumbnail')
   OGdvXBPaUQrfxsSApMHwJKqhcDLmeN=OGdvXBPaUQrfxsSApMHwJKqhcDLmeY.get('info')
   if OGdvXBPaUQrfxsSApMHwJKqhcDLmYy=='movie' and OGdvXBPaUQrfxsSApMHwJKqhcDLmYR==OGdvXBPaUQrfxsSApMHwJKqhcDLmlz:
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYt='%s (%s)'%(OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,OGdvXBPaUQrfxsSApMHwJKqhcDLmNe(OGdvXBPaUQrfxsSApMHwJKqhcDLmeN.get('year')))
   else:
    OGdvXBPaUQrfxsSApMHwJKqhcDLmeN['plot']=OGdvXBPaUQrfxsSApMHwJKqhcDLmYt
   if OGdvXBPaUQrfxsSApMHwJKqhcDLmYy=='vod':
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYi={'mode':'DEEP_LIST','contentid':OGdvXBPaUQrfxsSApMHwJKqhcDLmeY.get('programid'),'contentidType':'programid','uicode':'vod','page':'1','title':OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,'subtitle':OGdvXBPaUQrfxsSApMHwJKqhcDLmet,'thumbnail':OGdvXBPaUQrfxsSApMHwJKqhcDLmel,'viewage':OGdvXBPaUQrfxsSApMHwJKqhcDLmeY.get('viewage')}
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYj=OGdvXBPaUQrfxsSApMHwJKqhcDLmlz
   else:
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYi={'mode':'MOVIE','contentid':OGdvXBPaUQrfxsSApMHwJKqhcDLmeY.get('contentid'),'contentidType':'contentid','uicode':'movie','page':'1','title':OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,'subtitle':OGdvXBPaUQrfxsSApMHwJKqhcDLmet,'thumbnail':OGdvXBPaUQrfxsSApMHwJKqhcDLmel,'viewage':OGdvXBPaUQrfxsSApMHwJKqhcDLmeY.get('viewage')}
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYj=OGdvXBPaUQrfxsSApMHwJKqhcDLmly
   if OGdvXBPaUQrfxsSApMHwJKqhcDLmeY.get('viewage')=='21':OGdvXBPaUQrfxsSApMHwJKqhcDLmet+=' (%s)'%(OGdvXBPaUQrfxsSApMHwJKqhcDLmeY.get('viewage'))
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.add_dir(OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,sublabel=OGdvXBPaUQrfxsSApMHwJKqhcDLmet,img=OGdvXBPaUQrfxsSApMHwJKqhcDLmel,infoLabels=OGdvXBPaUQrfxsSApMHwJKqhcDLmeN,isFolder=OGdvXBPaUQrfxsSApMHwJKqhcDLmYj,params=OGdvXBPaUQrfxsSApMHwJKqhcDLmYi)
  if OGdvXBPaUQrfxsSApMHwJKqhcDLmeI:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYi['mode'] ='MYVIEW_LIST' 
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYi['uicode']=OGdvXBPaUQrfxsSApMHwJKqhcDLmYy 
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYi['page'] =OGdvXBPaUQrfxsSApMHwJKqhcDLmNe(OGdvXBPaUQrfxsSApMHwJKqhcDLmYE+1)
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYt='[B]%s >>[/B]'%'다음 페이지'
   OGdvXBPaUQrfxsSApMHwJKqhcDLmet=OGdvXBPaUQrfxsSApMHwJKqhcDLmNe(OGdvXBPaUQrfxsSApMHwJKqhcDLmYE+1)
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.add_dir(OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,sublabel=OGdvXBPaUQrfxsSApMHwJKqhcDLmet,img='',infoLabels=OGdvXBPaUQrfxsSApMHwJKqhcDLmlR,isFolder=OGdvXBPaUQrfxsSApMHwJKqhcDLmlz,params=OGdvXBPaUQrfxsSApMHwJKqhcDLmYi)
  if OGdvXBPaUQrfxsSApMHwJKqhcDLmNI(OGdvXBPaUQrfxsSApMHwJKqhcDLmYz)>0:xbmcplugin.endOfDirectory(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN._addon_handle,cacheToDisc=OGdvXBPaUQrfxsSApMHwJKqhcDLmly)
 def dp_Genre_Group(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN,args):
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.WavveObj.SaveCredential(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.get_winCredential())
  OGdvXBPaUQrfxsSApMHwJKqhcDLmei =args.get('mode') 
  OGdvXBPaUQrfxsSApMHwJKqhcDLmej =args.get('uicode')
  OGdvXBPaUQrfxsSApMHwJKqhcDLmeg =args.get('genre') 
  OGdvXBPaUQrfxsSApMHwJKqhcDLmen=args.get('subgenre')
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYV =args.get('orderby')
  OGdvXBPaUQrfxsSApMHwJKqhcDLmeo =args.get('ordernm')
  if OGdvXBPaUQrfxsSApMHwJKqhcDLmeg=='-':
   OGdvXBPaUQrfxsSApMHwJKqhcDLmeu=OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.WavveObj.GetGenreGroup(OGdvXBPaUQrfxsSApMHwJKqhcDLmej,OGdvXBPaUQrfxsSApMHwJKqhcDLmeg,OGdvXBPaUQrfxsSApMHwJKqhcDLmYV,OGdvXBPaUQrfxsSApMHwJKqhcDLmeo,exclusion21=OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.get_settings_exclusion21())
  else:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmeb={'adult':args.get('adult'),'broadcastid':args.get('broadcastid'),'contenttype':args.get('contenttype'),'genre':args.get('genre'),'uiparent':args.get('uiparent'),'uirank':args.get('uirank'),'uitype':args.get('uitype'),'orderby':OGdvXBPaUQrfxsSApMHwJKqhcDLmYV,'ordernm':OGdvXBPaUQrfxsSApMHwJKqhcDLmeo}
   OGdvXBPaUQrfxsSApMHwJKqhcDLmeu=OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.WavveObj.GetGenreGroup_sub(OGdvXBPaUQrfxsSApMHwJKqhcDLmeb)
  for OGdvXBPaUQrfxsSApMHwJKqhcDLmeF in OGdvXBPaUQrfxsSApMHwJKqhcDLmeu:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYt =OGdvXBPaUQrfxsSApMHwJKqhcDLmeF.get('title')+'  ('+OGdvXBPaUQrfxsSApMHwJKqhcDLmeo+')'
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYi={'mode':OGdvXBPaUQrfxsSApMHwJKqhcDLmei,'uicode':OGdvXBPaUQrfxsSApMHwJKqhcDLmej,'genre':OGdvXBPaUQrfxsSApMHwJKqhcDLmeF.get('genre'),'subgenre':OGdvXBPaUQrfxsSApMHwJKqhcDLmeF.get('subgenre'),'adult':OGdvXBPaUQrfxsSApMHwJKqhcDLmeF.get('adult'),'page':'1','broadcastid':OGdvXBPaUQrfxsSApMHwJKqhcDLmeF.get('broadcastid'),'contenttype':OGdvXBPaUQrfxsSApMHwJKqhcDLmeF.get('contenttype'),'uiparent':OGdvXBPaUQrfxsSApMHwJKqhcDLmeF.get('uiparent'),'uirank':OGdvXBPaUQrfxsSApMHwJKqhcDLmeF.get('uirank'),'uitype':OGdvXBPaUQrfxsSApMHwJKqhcDLmeF.get('uitype'),'orderby':OGdvXBPaUQrfxsSApMHwJKqhcDLmYV,'ordernm':OGdvXBPaUQrfxsSApMHwJKqhcDLmeo}
   if OGdvXBPaUQrfxsSApMHwJKqhcDLmej=='moviegenre' or OGdvXBPaUQrfxsSApMHwJKqhcDLmej=='moviegenre_svod' or OGdvXBPaUQrfxsSApMHwJKqhcDLmej=='moviegenre_ppv' or OGdvXBPaUQrfxsSApMHwJKqhcDLmeF.get('subgenre')!='-':
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYi['mode'] ='GENRE_LIST'
   else:
    OGdvXBPaUQrfxsSApMHwJKqhcDLmlR
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.add_dir(OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,sublabel='',img='',infoLabels=OGdvXBPaUQrfxsSApMHwJKqhcDLmlR,isFolder=OGdvXBPaUQrfxsSApMHwJKqhcDLmlz,params=OGdvXBPaUQrfxsSApMHwJKqhcDLmYi)
  if OGdvXBPaUQrfxsSApMHwJKqhcDLmNI(OGdvXBPaUQrfxsSApMHwJKqhcDLmeu)>0:xbmcplugin.endOfDirectory(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN._addon_handle,cacheToDisc=OGdvXBPaUQrfxsSApMHwJKqhcDLmly)
 def dp_Genre_List(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN,args):
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.WavveObj.SaveCredential(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.get_winCredential())
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYR=OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.get_settings_addinfo()
  OGdvXBPaUQrfxsSApMHwJKqhcDLmej =args.get('uicode')
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYE=OGdvXBPaUQrfxsSApMHwJKqhcDLmlE(args.get('page'))
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYi={'adult':args.get('adult'),'broadcastid':args.get('broadcastid'),'contenttype':args.get('contenttype'),'genre':args.get('genre'),'subgenre':args.get('subgenre'),'uiparent':args.get('uiparent'),'uirank':args.get('uirank'),'uitype':args.get('uitype'),'orderby':args.get('orderby')}
  if args.get('genre')==args.get('subgenre'):
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYi['subgenre']='all'
  OGdvXBPaUQrfxsSApMHwJKqhcDLmeu,OGdvXBPaUQrfxsSApMHwJKqhcDLmeI=OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.WavveObj.GetGenreList(OGdvXBPaUQrfxsSApMHwJKqhcDLmej,OGdvXBPaUQrfxsSApMHwJKqhcDLmYi,OGdvXBPaUQrfxsSApMHwJKqhcDLmYE,addinfoyn=OGdvXBPaUQrfxsSApMHwJKqhcDLmYR)
  for OGdvXBPaUQrfxsSApMHwJKqhcDLmeF in OGdvXBPaUQrfxsSApMHwJKqhcDLmeu:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYt =OGdvXBPaUQrfxsSApMHwJKqhcDLmeF.get('title')
   OGdvXBPaUQrfxsSApMHwJKqhcDLmel=OGdvXBPaUQrfxsSApMHwJKqhcDLmeF.get('thumbnail')
   OGdvXBPaUQrfxsSApMHwJKqhcDLmeN=OGdvXBPaUQrfxsSApMHwJKqhcDLmeF.get('info')
   if OGdvXBPaUQrfxsSApMHwJKqhcDLmej=='moviegenre_svod' and OGdvXBPaUQrfxsSApMHwJKqhcDLmYR==OGdvXBPaUQrfxsSApMHwJKqhcDLmlz:
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYt='%s (%s)'%(OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,OGdvXBPaUQrfxsSApMHwJKqhcDLmNe(OGdvXBPaUQrfxsSApMHwJKqhcDLmeN.get('year')))
   else:
    OGdvXBPaUQrfxsSApMHwJKqhcDLmeN['plot']=OGdvXBPaUQrfxsSApMHwJKqhcDLmYt
   if OGdvXBPaUQrfxsSApMHwJKqhcDLmej=='vodgenre':
    OGdvXBPaUQrfxsSApMHwJKqhcDLmeW={'mode':'DEEP_LIST','contentid':OGdvXBPaUQrfxsSApMHwJKqhcDLmeF.get('uicode'),'contentidType':'contentid','uicode':'vod','page':'1','title':OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,'subtitle':'','thumbnail':OGdvXBPaUQrfxsSApMHwJKqhcDLmel,'viewage':OGdvXBPaUQrfxsSApMHwJKqhcDLmeF.get('viewage')}
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYj=OGdvXBPaUQrfxsSApMHwJKqhcDLmlz
   else:
    OGdvXBPaUQrfxsSApMHwJKqhcDLmeW={'mode':'MOVIE','contentid':OGdvXBPaUQrfxsSApMHwJKqhcDLmeF.get('uicode'),'contentidType':'contentid','uicode':'movie','page':'1','title':OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,'subtitle':'','thumbnail':OGdvXBPaUQrfxsSApMHwJKqhcDLmel,'viewage':OGdvXBPaUQrfxsSApMHwJKqhcDLmeF.get('viewage')}
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYj=OGdvXBPaUQrfxsSApMHwJKqhcDLmly
   if OGdvXBPaUQrfxsSApMHwJKqhcDLmeW.get('viewage')=='21':OGdvXBPaUQrfxsSApMHwJKqhcDLmYt+=' (%s)'%(OGdvXBPaUQrfxsSApMHwJKqhcDLmeW.get('viewage'))
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.add_dir(OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,sublabel='',img=OGdvXBPaUQrfxsSApMHwJKqhcDLmel,infoLabels=OGdvXBPaUQrfxsSApMHwJKqhcDLmeN,isFolder=OGdvXBPaUQrfxsSApMHwJKqhcDLmYj,params=OGdvXBPaUQrfxsSApMHwJKqhcDLmeW)
  if OGdvXBPaUQrfxsSApMHwJKqhcDLmeI:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYi['mode'] ='GENRE_LIST' 
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYi['uicode']=OGdvXBPaUQrfxsSApMHwJKqhcDLmej 
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYi['page'] =OGdvXBPaUQrfxsSApMHwJKqhcDLmNe(OGdvXBPaUQrfxsSApMHwJKqhcDLmYE+1)
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYt='[B]%s >>[/B]'%'다음 페이지'
   OGdvXBPaUQrfxsSApMHwJKqhcDLmet=OGdvXBPaUQrfxsSApMHwJKqhcDLmNe(OGdvXBPaUQrfxsSApMHwJKqhcDLmYE+1)
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.add_dir(OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,sublabel=OGdvXBPaUQrfxsSApMHwJKqhcDLmet,img='',infoLabels=OGdvXBPaUQrfxsSApMHwJKqhcDLmlR,isFolder=OGdvXBPaUQrfxsSApMHwJKqhcDLmlz,params=OGdvXBPaUQrfxsSApMHwJKqhcDLmYi)
  if OGdvXBPaUQrfxsSApMHwJKqhcDLmNI(OGdvXBPaUQrfxsSApMHwJKqhcDLmeu)>0:xbmcplugin.endOfDirectory(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN._addon_handle,cacheToDisc=OGdvXBPaUQrfxsSApMHwJKqhcDLmly)
 def dp_Deeplink_List(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN,args):
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.WavveObj.SaveCredential(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.get_winCredential())
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYR=OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.get_settings_addinfo()
  OGdvXBPaUQrfxsSApMHwJKqhcDLmej =args.get('uicode')
  OGdvXBPaUQrfxsSApMHwJKqhcDLmeT =args.get('came')
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYE=OGdvXBPaUQrfxsSApMHwJKqhcDLmlE(args.get('page'))
  OGdvXBPaUQrfxsSApMHwJKqhcDLmeV,OGdvXBPaUQrfxsSApMHwJKqhcDLmeI=OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.WavveObj.GetDeeplinkList(OGdvXBPaUQrfxsSApMHwJKqhcDLmej,OGdvXBPaUQrfxsSApMHwJKqhcDLmeT,OGdvXBPaUQrfxsSApMHwJKqhcDLmYE,addinfoyn=OGdvXBPaUQrfxsSApMHwJKqhcDLmYR)
  for OGdvXBPaUQrfxsSApMHwJKqhcDLmek in OGdvXBPaUQrfxsSApMHwJKqhcDLmeV:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYt =OGdvXBPaUQrfxsSApMHwJKqhcDLmek.get('title')
   OGdvXBPaUQrfxsSApMHwJKqhcDLmet =OGdvXBPaUQrfxsSApMHwJKqhcDLmek.get('subtitle')
   OGdvXBPaUQrfxsSApMHwJKqhcDLmel=OGdvXBPaUQrfxsSApMHwJKqhcDLmek.get('thumbnail')
   OGdvXBPaUQrfxsSApMHwJKqhcDLmeC=OGdvXBPaUQrfxsSApMHwJKqhcDLmek.get('uicode')
   OGdvXBPaUQrfxsSApMHwJKqhcDLmeR=OGdvXBPaUQrfxsSApMHwJKqhcDLmek.get('channelepg')
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYi={'uicode':OGdvXBPaUQrfxsSApMHwJKqhcDLmeC,'came':OGdvXBPaUQrfxsSApMHwJKqhcDLmeT,'contentid':OGdvXBPaUQrfxsSApMHwJKqhcDLmek.get('contentid'),'contentidType':OGdvXBPaUQrfxsSApMHwJKqhcDLmek.get('contentidType'),'page':'1','title':OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,'subtitle':OGdvXBPaUQrfxsSApMHwJKqhcDLmet,'thumbnail':OGdvXBPaUQrfxsSApMHwJKqhcDLmel,'viewage':OGdvXBPaUQrfxsSApMHwJKqhcDLmek.get('viewage')}
   if OGdvXBPaUQrfxsSApMHwJKqhcDLmeC=='channel':
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYi['mode'] ='LIVE'
   elif OGdvXBPaUQrfxsSApMHwJKqhcDLmeC=='movie':
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYi['mode'] ='MOVIE'
   else:
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYi['mode'] ='DEEP_LIST'
   OGdvXBPaUQrfxsSApMHwJKqhcDLmeN=OGdvXBPaUQrfxsSApMHwJKqhcDLmek.get('info')
   if OGdvXBPaUQrfxsSApMHwJKqhcDLmeR:
    OGdvXBPaUQrfxsSApMHwJKqhcDLmeN['plot']='%s\n\n%s'%(OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,OGdvXBPaUQrfxsSApMHwJKqhcDLmeR)
   elif OGdvXBPaUQrfxsSApMHwJKqhcDLmeC=='movie' and OGdvXBPaUQrfxsSApMHwJKqhcDLmYR==OGdvXBPaUQrfxsSApMHwJKqhcDLmlz:
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYt='%s (%s)'%(OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,OGdvXBPaUQrfxsSApMHwJKqhcDLmNe(OGdvXBPaUQrfxsSApMHwJKqhcDLmeN.get('year')))
   else:
    OGdvXBPaUQrfxsSApMHwJKqhcDLmeN['plot']='%s\n\n%s'%(OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,OGdvXBPaUQrfxsSApMHwJKqhcDLmet)
   if OGdvXBPaUQrfxsSApMHwJKqhcDLmek.get('viewage')=='21':OGdvXBPaUQrfxsSApMHwJKqhcDLmet+=' (%s)'%(OGdvXBPaUQrfxsSApMHwJKqhcDLmek.get('viewage'))
   if OGdvXBPaUQrfxsSApMHwJKqhcDLmeC in['channel','movie']:
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYj=OGdvXBPaUQrfxsSApMHwJKqhcDLmly
   elif OGdvXBPaUQrfxsSApMHwJKqhcDLmYi['contentidType']=='direct':
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYj=OGdvXBPaUQrfxsSApMHwJKqhcDLmly
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYi['mode']='VOD'
   else:
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYj=OGdvXBPaUQrfxsSApMHwJKqhcDLmlz
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.add_dir(OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,sublabel=OGdvXBPaUQrfxsSApMHwJKqhcDLmet,img=OGdvXBPaUQrfxsSApMHwJKqhcDLmel,infoLabels=OGdvXBPaUQrfxsSApMHwJKqhcDLmeN,isFolder=OGdvXBPaUQrfxsSApMHwJKqhcDLmYj,params=OGdvXBPaUQrfxsSApMHwJKqhcDLmYi)
  if OGdvXBPaUQrfxsSApMHwJKqhcDLmeI:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYi['mode'] ='GN_LIST' 
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYi['uicode']=OGdvXBPaUQrfxsSApMHwJKqhcDLmej 
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYi['page'] =OGdvXBPaUQrfxsSApMHwJKqhcDLmNe(OGdvXBPaUQrfxsSApMHwJKqhcDLmYE+1)
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYt='[B]%s >>[/B]'%'다음 페이지'
   OGdvXBPaUQrfxsSApMHwJKqhcDLmet=OGdvXBPaUQrfxsSApMHwJKqhcDLmNe(OGdvXBPaUQrfxsSApMHwJKqhcDLmYE+1)
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.add_dir(OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,sublabel=OGdvXBPaUQrfxsSApMHwJKqhcDLmet,img='',infoLabels=OGdvXBPaUQrfxsSApMHwJKqhcDLmlR,isFolder=OGdvXBPaUQrfxsSApMHwJKqhcDLmlz,params=OGdvXBPaUQrfxsSApMHwJKqhcDLmYi)
  if OGdvXBPaUQrfxsSApMHwJKqhcDLmNI(OGdvXBPaUQrfxsSApMHwJKqhcDLmeV)>0:xbmcplugin.endOfDirectory(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN._addon_handle,cacheToDisc=OGdvXBPaUQrfxsSApMHwJKqhcDLmly)
 def dp_Episodelink_List(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN,args):
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.WavveObj.SaveCredential(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.get_winCredential())
  OGdvXBPaUQrfxsSApMHwJKqhcDLmey =args.get('contentid')
  OGdvXBPaUQrfxsSApMHwJKqhcDLmeE=args.get('contentidType')
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYy =args.get('uicode')
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYE =OGdvXBPaUQrfxsSApMHwJKqhcDLmlE(args.get('page'))
  OGdvXBPaUQrfxsSApMHwJKqhcDLmez,OGdvXBPaUQrfxsSApMHwJKqhcDLmeI=OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.WavveObj.GetEpisodeList(OGdvXBPaUQrfxsSApMHwJKqhcDLmey,OGdvXBPaUQrfxsSApMHwJKqhcDLmYy,OGdvXBPaUQrfxsSApMHwJKqhcDLmeE,OGdvXBPaUQrfxsSApMHwJKqhcDLmYE,orderby=OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.get_winEpisodeOrderby())
  for OGdvXBPaUQrfxsSApMHwJKqhcDLmtI in OGdvXBPaUQrfxsSApMHwJKqhcDLmez:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYt =OGdvXBPaUQrfxsSApMHwJKqhcDLmtI.get('title')
   OGdvXBPaUQrfxsSApMHwJKqhcDLmet =OGdvXBPaUQrfxsSApMHwJKqhcDLmtI.get('subtitle')
   OGdvXBPaUQrfxsSApMHwJKqhcDLmel=OGdvXBPaUQrfxsSApMHwJKqhcDLmtI.get('thumbnail')
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYi={'mode':'VOD','uicode':OGdvXBPaUQrfxsSApMHwJKqhcDLmtI.get('uicode'),'contentid':OGdvXBPaUQrfxsSApMHwJKqhcDLmtI.get('contentid'),'programid':OGdvXBPaUQrfxsSApMHwJKqhcDLmtI.get('programid'),'title':OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,'subtitle':OGdvXBPaUQrfxsSApMHwJKqhcDLmet,'thumbnail':OGdvXBPaUQrfxsSApMHwJKqhcDLmel,'viewage':OGdvXBPaUQrfxsSApMHwJKqhcDLmtI.get('viewage')}
   if OGdvXBPaUQrfxsSApMHwJKqhcDLmtI.get('viewage')=='21':OGdvXBPaUQrfxsSApMHwJKqhcDLmet+=' (%s)'%(OGdvXBPaUQrfxsSApMHwJKqhcDLmtI.get('viewage'))
   OGdvXBPaUQrfxsSApMHwJKqhcDLmtY=OGdvXBPaUQrfxsSApMHwJKqhcDLmtI.get('info')
   OGdvXBPaUQrfxsSApMHwJKqhcDLmtY['plot']=OGdvXBPaUQrfxsSApMHwJKqhcDLmtI.get('synopsis')
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.add_dir(OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,sublabel=OGdvXBPaUQrfxsSApMHwJKqhcDLmet,img=OGdvXBPaUQrfxsSApMHwJKqhcDLmel,infoLabels=OGdvXBPaUQrfxsSApMHwJKqhcDLmtY,isFolder=OGdvXBPaUQrfxsSApMHwJKqhcDLmly,params=OGdvXBPaUQrfxsSApMHwJKqhcDLmYi)
  if OGdvXBPaUQrfxsSApMHwJKqhcDLmYE==1:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmeN={'plot':'정렬순서를 변경합니다.'}
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYi={}
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYi['mode'] ='ORDER_BY' 
   if OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.get_winEpisodeOrderby()=='desc':
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYt='정렬순서변경 : 최신화부터 -> 1회부터'
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYi['orderby']='asc'
   else:
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYt='정렬순서변경 : 1회부터 -> 최신화부터'
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYi['orderby']='desc'
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.add_dir(OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,sublabel='',img='',infoLabels=OGdvXBPaUQrfxsSApMHwJKqhcDLmeN,isFolder=OGdvXBPaUQrfxsSApMHwJKqhcDLmly,params=OGdvXBPaUQrfxsSApMHwJKqhcDLmYi)
  if OGdvXBPaUQrfxsSApMHwJKqhcDLmeI:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYi['mode'] ='DEEP_LIST' 
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYi['uicode'] =OGdvXBPaUQrfxsSApMHwJKqhcDLmYy 
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYi['contentid'] =OGdvXBPaUQrfxsSApMHwJKqhcDLmey 
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYi['contentidType']=OGdvXBPaUQrfxsSApMHwJKqhcDLmeE 
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYi['page'] =OGdvXBPaUQrfxsSApMHwJKqhcDLmNe(OGdvXBPaUQrfxsSApMHwJKqhcDLmYE+1)
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYt='[B]%s >>[/B]'%'다음 페이지'
   OGdvXBPaUQrfxsSApMHwJKqhcDLmet=OGdvXBPaUQrfxsSApMHwJKqhcDLmNe(OGdvXBPaUQrfxsSApMHwJKqhcDLmYE+1)
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.add_dir(OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,sublabel=OGdvXBPaUQrfxsSApMHwJKqhcDLmet,img='',infoLabels=OGdvXBPaUQrfxsSApMHwJKqhcDLmlR,isFolder=OGdvXBPaUQrfxsSApMHwJKqhcDLmlz,params=OGdvXBPaUQrfxsSApMHwJKqhcDLmYi)
  if OGdvXBPaUQrfxsSApMHwJKqhcDLmNI(OGdvXBPaUQrfxsSApMHwJKqhcDLmez)>0:xbmcplugin.endOfDirectory(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN._addon_handle,cacheToDisc=OGdvXBPaUQrfxsSApMHwJKqhcDLmlz)
 def play_VIDEO(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN,args):
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.WavveObj.SaveCredential(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.get_winCredential())
  OGdvXBPaUQrfxsSApMHwJKqhcDLmey =args.get('contentid')
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYy=args.get('uicode')
  OGdvXBPaUQrfxsSApMHwJKqhcDLmte=OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.get_selQuality()
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.addon_log(OGdvXBPaUQrfxsSApMHwJKqhcDLmey+' - '+OGdvXBPaUQrfxsSApMHwJKqhcDLmYy,OGdvXBPaUQrfxsSApMHwJKqhcDLmly)
  OGdvXBPaUQrfxsSApMHwJKqhcDLmtl,OGdvXBPaUQrfxsSApMHwJKqhcDLmtN,OGdvXBPaUQrfxsSApMHwJKqhcDLmti,OGdvXBPaUQrfxsSApMHwJKqhcDLmtj=OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.WavveObj.GetStreamingURL(OGdvXBPaUQrfxsSApMHwJKqhcDLmey,OGdvXBPaUQrfxsSApMHwJKqhcDLmYy,OGdvXBPaUQrfxsSApMHwJKqhcDLmte)
  OGdvXBPaUQrfxsSApMHwJKqhcDLmtg='%s|Cookie=%s'%(OGdvXBPaUQrfxsSApMHwJKqhcDLmtl,OGdvXBPaUQrfxsSApMHwJKqhcDLmtN)
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.addon_log(OGdvXBPaUQrfxsSApMHwJKqhcDLmtg,OGdvXBPaUQrfxsSApMHwJKqhcDLmly)
  if OGdvXBPaUQrfxsSApMHwJKqhcDLmtl=='':
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.addon_noti(__language__(30907).encode('utf8'))
   return
  OGdvXBPaUQrfxsSApMHwJKqhcDLmtn=xbmcgui.ListItem(path=OGdvXBPaUQrfxsSApMHwJKqhcDLmtg)
  if OGdvXBPaUQrfxsSApMHwJKqhcDLmti:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmto=OGdvXBPaUQrfxsSApMHwJKqhcDLmti['customdata']
   OGdvXBPaUQrfxsSApMHwJKqhcDLmtu =OGdvXBPaUQrfxsSApMHwJKqhcDLmti['drmhost']
   OGdvXBPaUQrfxsSApMHwJKqhcDLmtb =inputstreamhelper.Helper('mpd',drm='widevine')
   if OGdvXBPaUQrfxsSApMHwJKqhcDLmtb.check_inputstream():
    if OGdvXBPaUQrfxsSApMHwJKqhcDLmYy=='movie':
     OGdvXBPaUQrfxsSApMHwJKqhcDLmtF='https://www.wavve.com/player/movie?movieid=%s'%OGdvXBPaUQrfxsSApMHwJKqhcDLmey
    else:
     OGdvXBPaUQrfxsSApMHwJKqhcDLmtF='https://www.wavve.com/player/vod?programid=%s&page=1'%OGdvXBPaUQrfxsSApMHwJKqhcDLmey
    OGdvXBPaUQrfxsSApMHwJKqhcDLmtW={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':OGdvXBPaUQrfxsSApMHwJKqhcDLmto,'referer':OGdvXBPaUQrfxsSApMHwJKqhcDLmtF,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':OGdvXBPaUQrfxsSApMHwJKqhcDLmIt}
    OGdvXBPaUQrfxsSApMHwJKqhcDLmtT=OGdvXBPaUQrfxsSApMHwJKqhcDLmtu+'|'+urllib.parse.urlencode(OGdvXBPaUQrfxsSApMHwJKqhcDLmtW)+'|R{SSM}|'
    OGdvXBPaUQrfxsSApMHwJKqhcDLmtn.setProperty('inputstream',OGdvXBPaUQrfxsSApMHwJKqhcDLmtb.inputstream_addon)
    OGdvXBPaUQrfxsSApMHwJKqhcDLmtn.setProperty('inputstream.adaptive.manifest_type','mpd')
    OGdvXBPaUQrfxsSApMHwJKqhcDLmtn.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    OGdvXBPaUQrfxsSApMHwJKqhcDLmtn.setProperty('inputstream.adaptive.license_key',OGdvXBPaUQrfxsSApMHwJKqhcDLmtT)
    OGdvXBPaUQrfxsSApMHwJKqhcDLmtn.setProperty('inputstream.adaptive.stream_headers','user-agent=%s&Cookie=%s'%(OGdvXBPaUQrfxsSApMHwJKqhcDLmIt,OGdvXBPaUQrfxsSApMHwJKqhcDLmtN))
  xbmcplugin.setResolvedUrl(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN._addon_handle,OGdvXBPaUQrfxsSApMHwJKqhcDLmlz,OGdvXBPaUQrfxsSApMHwJKqhcDLmtn)
  if OGdvXBPaUQrfxsSApMHwJKqhcDLmtj:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.addon_noti(OGdvXBPaUQrfxsSApMHwJKqhcDLmtj.encode('utf-8'))
  else:
   if '/preview.' in urllib.parse.urlsplit(OGdvXBPaUQrfxsSApMHwJKqhcDLmtl).path:OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.addon_noti(__language__(30908).encode('utf8'))
  try:
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('viewage')!='21':
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYi={'code':args.get('programid')if args.get('mode')=='VOD' else args.get('contentid'),'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.Save_Watched_List(args.get('mode').lower(),OGdvXBPaUQrfxsSApMHwJKqhcDLmYi)
  except:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmlR
 def dp_Watch_List(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN,args):
  OGdvXBPaUQrfxsSApMHwJKqhcDLmeg =args.get('genre')
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIy=OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.get_settings_direct_replay()
  if OGdvXBPaUQrfxsSApMHwJKqhcDLmeg=='-':
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYt='VOD 시청내역'
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYi={'mode':'WATCH','genre':'vod'}
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.add_dir(OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,sublabel='',img='',infoLabels=OGdvXBPaUQrfxsSApMHwJKqhcDLmlR,isFolder=OGdvXBPaUQrfxsSApMHwJKqhcDLmlz,params=OGdvXBPaUQrfxsSApMHwJKqhcDLmYi)
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYt='영화 시청내역'
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYi['genre']='movie'
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.add_dir(OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,sublabel='',img='',infoLabels=OGdvXBPaUQrfxsSApMHwJKqhcDLmlR,isFolder=OGdvXBPaUQrfxsSApMHwJKqhcDLmlz,params=OGdvXBPaUQrfxsSApMHwJKqhcDLmYi)
   xbmcplugin.endOfDirectory(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN._addon_handle)
  else:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmtV=OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.Load_Watched_List(OGdvXBPaUQrfxsSApMHwJKqhcDLmeg)
   for OGdvXBPaUQrfxsSApMHwJKqhcDLmtk in OGdvXBPaUQrfxsSApMHwJKqhcDLmtV:
    OGdvXBPaUQrfxsSApMHwJKqhcDLmtC=OGdvXBPaUQrfxsSApMHwJKqhcDLmNt(urllib.parse.parse_qsl(OGdvXBPaUQrfxsSApMHwJKqhcDLmtk))
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYt =OGdvXBPaUQrfxsSApMHwJKqhcDLmtC.get('title').strip()
    OGdvXBPaUQrfxsSApMHwJKqhcDLmet =OGdvXBPaUQrfxsSApMHwJKqhcDLmtC.get('subtitle').strip()
    if OGdvXBPaUQrfxsSApMHwJKqhcDLmet=='None':OGdvXBPaUQrfxsSApMHwJKqhcDLmet=''
    OGdvXBPaUQrfxsSApMHwJKqhcDLmel=OGdvXBPaUQrfxsSApMHwJKqhcDLmtC.get('img')
    OGdvXBPaUQrfxsSApMHwJKqhcDLmtR =OGdvXBPaUQrfxsSApMHwJKqhcDLmtC.get('videoid')
    OGdvXBPaUQrfxsSApMHwJKqhcDLmeN={}
    if OGdvXBPaUQrfxsSApMHwJKqhcDLmeg=='movie' and OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.get_settings_addinfo()==OGdvXBPaUQrfxsSApMHwJKqhcDLmlz:
     OGdvXBPaUQrfxsSApMHwJKqhcDLmty=OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.WavveObj.GetMovieInfoList([OGdvXBPaUQrfxsSApMHwJKqhcDLmtC.get('code')])
     OGdvXBPaUQrfxsSApMHwJKqhcDLmeN=OGdvXBPaUQrfxsSApMHwJKqhcDLmty.get(OGdvXBPaUQrfxsSApMHwJKqhcDLmtC.get('code'))
    else:
     OGdvXBPaUQrfxsSApMHwJKqhcDLmeN['plot']='%s\n%s'%(OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,OGdvXBPaUQrfxsSApMHwJKqhcDLmet)
    if OGdvXBPaUQrfxsSApMHwJKqhcDLmeg=='vod':
     if OGdvXBPaUQrfxsSApMHwJKqhcDLmIy==OGdvXBPaUQrfxsSApMHwJKqhcDLmly or OGdvXBPaUQrfxsSApMHwJKqhcDLmtR==OGdvXBPaUQrfxsSApMHwJKqhcDLmlR:
      OGdvXBPaUQrfxsSApMHwJKqhcDLmYi={'mode':'DEEP_LIST','contentid':OGdvXBPaUQrfxsSApMHwJKqhcDLmtC.get('code'),'contentidType':'programid','uicode':'vod','page':'1'}
      OGdvXBPaUQrfxsSApMHwJKqhcDLmYj=OGdvXBPaUQrfxsSApMHwJKqhcDLmlz
     else:
      OGdvXBPaUQrfxsSApMHwJKqhcDLmYi={'mode':'VOD','contentid':OGdvXBPaUQrfxsSApMHwJKqhcDLmtR,'contentidType':'contentid','programid':OGdvXBPaUQrfxsSApMHwJKqhcDLmtC.get('code'),'uicode':'vod','title':OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,'subtitle':OGdvXBPaUQrfxsSApMHwJKqhcDLmet,'thumbnail':OGdvXBPaUQrfxsSApMHwJKqhcDLmel}
      OGdvXBPaUQrfxsSApMHwJKqhcDLmYj=OGdvXBPaUQrfxsSApMHwJKqhcDLmly
    else:
     OGdvXBPaUQrfxsSApMHwJKqhcDLmYi={'mode':'MOVIE','contentid':OGdvXBPaUQrfxsSApMHwJKqhcDLmtC.get('code'),'contentidType':'contentid','uicode':'movie','title':OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,'thumbnail':OGdvXBPaUQrfxsSApMHwJKqhcDLmel}
     OGdvXBPaUQrfxsSApMHwJKqhcDLmYj=OGdvXBPaUQrfxsSApMHwJKqhcDLmly
    OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.add_dir(OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,sublabel=OGdvXBPaUQrfxsSApMHwJKqhcDLmet,img=OGdvXBPaUQrfxsSApMHwJKqhcDLmel,infoLabels=OGdvXBPaUQrfxsSApMHwJKqhcDLmeN,isFolder=OGdvXBPaUQrfxsSApMHwJKqhcDLmYj,params=OGdvXBPaUQrfxsSApMHwJKqhcDLmYi)
   OGdvXBPaUQrfxsSApMHwJKqhcDLmeN={'plot':'시청목록을 삭제합니다.'}
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYt='*** 시청목록 삭제 ***'
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYi={'mode':'MYVIEW_REMOVE','genre':OGdvXBPaUQrfxsSApMHwJKqhcDLmeg}
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.add_dir(OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,sublabel='',img='',infoLabels=OGdvXBPaUQrfxsSApMHwJKqhcDLmeN,isFolder=OGdvXBPaUQrfxsSApMHwJKqhcDLmly,params=OGdvXBPaUQrfxsSApMHwJKqhcDLmYi)
   xbmcplugin.endOfDirectory(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN._addon_handle,cacheToDisc=OGdvXBPaUQrfxsSApMHwJKqhcDLmly)
 def dp_Search_Group(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN,args):
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYt='VOD 검색'
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYi={'mode':'SEARCH_LIST','genre':'vod','page':'1'}
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.add_dir(OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,sublabel='',img='',infoLabels=OGdvXBPaUQrfxsSApMHwJKqhcDLmlR,isFolder=OGdvXBPaUQrfxsSApMHwJKqhcDLmlz,params=OGdvXBPaUQrfxsSApMHwJKqhcDLmYi)
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYt='영화 검색'
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYi['genre']='movie'
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.add_dir(OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,sublabel='',img='',infoLabels=OGdvXBPaUQrfxsSApMHwJKqhcDLmlR,isFolder=OGdvXBPaUQrfxsSApMHwJKqhcDLmlz,params=OGdvXBPaUQrfxsSApMHwJKqhcDLmYi)
  xbmcplugin.endOfDirectory(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN._addon_handle)
 def dp_Search_List(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN,args):
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.WavveObj.SaveCredential(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.get_winCredential())
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYR=OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.get_settings_addinfo()
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYy=args.get('genre')
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYE =OGdvXBPaUQrfxsSApMHwJKqhcDLmlE(args.get('page'))
  if 'search_key' in args:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmtz=args.get('search_key')
  else:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmtz=OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not OGdvXBPaUQrfxsSApMHwJKqhcDLmtz:return
  OGdvXBPaUQrfxsSApMHwJKqhcDLmlI,OGdvXBPaUQrfxsSApMHwJKqhcDLmeI=OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.WavveObj.GetSearchList(OGdvXBPaUQrfxsSApMHwJKqhcDLmtz,OGdvXBPaUQrfxsSApMHwJKqhcDLmYy,OGdvXBPaUQrfxsSApMHwJKqhcDLmYE,exclusion21=OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.get_settings_exclusion21(),addinfoyn=OGdvXBPaUQrfxsSApMHwJKqhcDLmYR)
  for OGdvXBPaUQrfxsSApMHwJKqhcDLmlY in OGdvXBPaUQrfxsSApMHwJKqhcDLmlI:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYt =OGdvXBPaUQrfxsSApMHwJKqhcDLmlY.get('title')
   OGdvXBPaUQrfxsSApMHwJKqhcDLmel=OGdvXBPaUQrfxsSApMHwJKqhcDLmlY.get('thumbnail')
   OGdvXBPaUQrfxsSApMHwJKqhcDLmeN=OGdvXBPaUQrfxsSApMHwJKqhcDLmlY.get('info')
   if OGdvXBPaUQrfxsSApMHwJKqhcDLmYy=='movie' and OGdvXBPaUQrfxsSApMHwJKqhcDLmYR==OGdvXBPaUQrfxsSApMHwJKqhcDLmlz:
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYt='%s (%s)'%(OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,OGdvXBPaUQrfxsSApMHwJKqhcDLmNe(OGdvXBPaUQrfxsSApMHwJKqhcDLmeN.get('year')))
   else:
    OGdvXBPaUQrfxsSApMHwJKqhcDLmeN['plot']=OGdvXBPaUQrfxsSApMHwJKqhcDLmYt
   if OGdvXBPaUQrfxsSApMHwJKqhcDLmYy=='vod':
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYi={'mode':'DEEP_LIST','contentid':OGdvXBPaUQrfxsSApMHwJKqhcDLmlY.get('programid'),'contentidType':'programid','uicode':'vod','page':'1','title':OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,'subtitle':'','thumbnail':OGdvXBPaUQrfxsSApMHwJKqhcDLmel,'viewage':OGdvXBPaUQrfxsSApMHwJKqhcDLmlY.get('viewage')}
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYj=OGdvXBPaUQrfxsSApMHwJKqhcDLmlz
   else:
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYi={'mode':'MOVIE','contentid':OGdvXBPaUQrfxsSApMHwJKqhcDLmlY.get('contentid'),'contentidType':'contentid','uicode':'movie','page':'1','title':OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,'subtitle':'','thumbnail':OGdvXBPaUQrfxsSApMHwJKqhcDLmel,'viewage':OGdvXBPaUQrfxsSApMHwJKqhcDLmlY.get('viewage')}
    OGdvXBPaUQrfxsSApMHwJKqhcDLmYj=OGdvXBPaUQrfxsSApMHwJKqhcDLmly
   if OGdvXBPaUQrfxsSApMHwJKqhcDLmYi.get('viewage')=='21':OGdvXBPaUQrfxsSApMHwJKqhcDLmYt+=' (%s)'%(OGdvXBPaUQrfxsSApMHwJKqhcDLmYi.get('viewage'))
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.add_dir(OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,sublabel='',img=OGdvXBPaUQrfxsSApMHwJKqhcDLmel,infoLabels=OGdvXBPaUQrfxsSApMHwJKqhcDLmeN,isFolder=OGdvXBPaUQrfxsSApMHwJKqhcDLmYj,params=OGdvXBPaUQrfxsSApMHwJKqhcDLmYi)
  if OGdvXBPaUQrfxsSApMHwJKqhcDLmeI:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYi['mode'] ='SEARCH_LIST' 
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYi['genre']=OGdvXBPaUQrfxsSApMHwJKqhcDLmYy 
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYi['page'] =OGdvXBPaUQrfxsSApMHwJKqhcDLmNe(OGdvXBPaUQrfxsSApMHwJKqhcDLmYE+1)
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYi['search_key']=OGdvXBPaUQrfxsSApMHwJKqhcDLmtz
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYt='[B]%s >>[/B]'%'다음 페이지'
   OGdvXBPaUQrfxsSApMHwJKqhcDLmet=OGdvXBPaUQrfxsSApMHwJKqhcDLmNe(OGdvXBPaUQrfxsSApMHwJKqhcDLmYE+1)
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.add_dir(OGdvXBPaUQrfxsSApMHwJKqhcDLmYt,sublabel=OGdvXBPaUQrfxsSApMHwJKqhcDLmet,img='',infoLabels=OGdvXBPaUQrfxsSApMHwJKqhcDLmlR,isFolder=OGdvXBPaUQrfxsSApMHwJKqhcDLmlz,params=OGdvXBPaUQrfxsSApMHwJKqhcDLmYi)
  if OGdvXBPaUQrfxsSApMHwJKqhcDLmNI(OGdvXBPaUQrfxsSApMHwJKqhcDLmlI)>0:xbmcplugin.endOfDirectory(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN._addon_handle)
 def Load_Watched_List(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN,OGdvXBPaUQrfxsSApMHwJKqhcDLmeg):
  try:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmle=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%OGdvXBPaUQrfxsSApMHwJKqhcDLmeg))
   with OGdvXBPaUQrfxsSApMHwJKqhcDLmNl(OGdvXBPaUQrfxsSApMHwJKqhcDLmle,'r',-1,'utf-8')as fp:
    OGdvXBPaUQrfxsSApMHwJKqhcDLmlt=fp.readlines()
  except:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmlt=[]
  return OGdvXBPaUQrfxsSApMHwJKqhcDLmlt
 def Save_Watched_List(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN,OGdvXBPaUQrfxsSApMHwJKqhcDLmeg,OGdvXBPaUQrfxsSApMHwJKqhcDLmIg):
  try:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmle=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%OGdvXBPaUQrfxsSApMHwJKqhcDLmeg))
   OGdvXBPaUQrfxsSApMHwJKqhcDLmlN=OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.Load_Watched_List(OGdvXBPaUQrfxsSApMHwJKqhcDLmeg) 
   with OGdvXBPaUQrfxsSApMHwJKqhcDLmNl(OGdvXBPaUQrfxsSApMHwJKqhcDLmle,'w',-1,'utf-8')as fp:
    OGdvXBPaUQrfxsSApMHwJKqhcDLmli=urllib.parse.urlencode(OGdvXBPaUQrfxsSApMHwJKqhcDLmIg)
    OGdvXBPaUQrfxsSApMHwJKqhcDLmli=OGdvXBPaUQrfxsSApMHwJKqhcDLmli+'\n'
    fp.write(OGdvXBPaUQrfxsSApMHwJKqhcDLmli)
    OGdvXBPaUQrfxsSApMHwJKqhcDLmlj=0
    for OGdvXBPaUQrfxsSApMHwJKqhcDLmlg in OGdvXBPaUQrfxsSApMHwJKqhcDLmlN:
     OGdvXBPaUQrfxsSApMHwJKqhcDLmln=OGdvXBPaUQrfxsSApMHwJKqhcDLmNt(urllib.parse.parse_qsl(OGdvXBPaUQrfxsSApMHwJKqhcDLmlg))
     OGdvXBPaUQrfxsSApMHwJKqhcDLmlo=OGdvXBPaUQrfxsSApMHwJKqhcDLmIg.get('code')
     OGdvXBPaUQrfxsSApMHwJKqhcDLmlu=OGdvXBPaUQrfxsSApMHwJKqhcDLmln.get('code')
     if OGdvXBPaUQrfxsSApMHwJKqhcDLmeg=='vod' and OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.get_settings_direct_replay()==OGdvXBPaUQrfxsSApMHwJKqhcDLmlz:
      OGdvXBPaUQrfxsSApMHwJKqhcDLmlo=OGdvXBPaUQrfxsSApMHwJKqhcDLmIg.get('videoid')
      OGdvXBPaUQrfxsSApMHwJKqhcDLmlu=OGdvXBPaUQrfxsSApMHwJKqhcDLmln.get('videoid')if OGdvXBPaUQrfxsSApMHwJKqhcDLmlu!=OGdvXBPaUQrfxsSApMHwJKqhcDLmlR else '-'
     if OGdvXBPaUQrfxsSApMHwJKqhcDLmlo!=OGdvXBPaUQrfxsSApMHwJKqhcDLmlu:
      fp.write(OGdvXBPaUQrfxsSApMHwJKqhcDLmlg)
      OGdvXBPaUQrfxsSApMHwJKqhcDLmlj+=1
      if OGdvXBPaUQrfxsSApMHwJKqhcDLmlj>=50:break
  except:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmlR
 def Delete_Watched_List(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN,OGdvXBPaUQrfxsSApMHwJKqhcDLmeg):
  try:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmle=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%OGdvXBPaUQrfxsSApMHwJKqhcDLmeg))
   with OGdvXBPaUQrfxsSApMHwJKqhcDLmNl(OGdvXBPaUQrfxsSApMHwJKqhcDLmle,'w',-1,'utf-8')as fp:
    fp.write('')
  except:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmlR
 def dp_WatchList_Delete(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN,args):
  OGdvXBPaUQrfxsSApMHwJKqhcDLmeg=args.get('genre')
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIo=xbmcgui.Dialog()
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYb=OGdvXBPaUQrfxsSApMHwJKqhcDLmIo.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if OGdvXBPaUQrfxsSApMHwJKqhcDLmYb==OGdvXBPaUQrfxsSApMHwJKqhcDLmly:sys.exit()
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.Delete_Watched_List(OGdvXBPaUQrfxsSApMHwJKqhcDLmeg)
  xbmc.executebuiltin("Container.Refresh")
 def logout(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN):
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIo=xbmcgui.Dialog()
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYb=OGdvXBPaUQrfxsSApMHwJKqhcDLmIo.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if OGdvXBPaUQrfxsSApMHwJKqhcDLmYb==OGdvXBPaUQrfxsSApMHwJKqhcDLmly:sys.exit()
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.wininfo_clear()
  if os.path.isfile(OGdvXBPaUQrfxsSApMHwJKqhcDLmIl):os.remove(OGdvXBPaUQrfxsSApMHwJKqhcDLmIl)
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN):
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYI=xbmcgui.Window(10000)
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYI.setProperty('WAVVE_M_CREDENTIAL','')
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYI.setProperty('WAVVE_M_LOGINTIME','')
 def cookiefile_save(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN):
  OGdvXBPaUQrfxsSApMHwJKqhcDLmlb =datetime.datetime.now()
  OGdvXBPaUQrfxsSApMHwJKqhcDLmlF=OGdvXBPaUQrfxsSApMHwJKqhcDLmlb+datetime.timedelta(days=OGdvXBPaUQrfxsSApMHwJKqhcDLmlE(__addon__.getSetting('cache_ttl')))
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYI=xbmcgui.Window(10000)
  OGdvXBPaUQrfxsSApMHwJKqhcDLmlW={'wavve_token':OGdvXBPaUQrfxsSApMHwJKqhcDLmYI.getProperty('WAVVE_M_CREDENTIAL'),'wavve_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'wavve_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'wavve_profile':__addon__.getSetting('selected_profile'),'wavve_limitdate':OGdvXBPaUQrfxsSApMHwJKqhcDLmlF.strftime('%Y-%m-%d')}
  try: 
   with OGdvXBPaUQrfxsSApMHwJKqhcDLmNl(OGdvXBPaUQrfxsSApMHwJKqhcDLmIl,'w',-1,'utf-8')as fp:
    OGdvXBPaUQrfxsSApMHwJKqhcDLmlT.dump(OGdvXBPaUQrfxsSApMHwJKqhcDLmlW,fp)
  except OGdvXBPaUQrfxsSApMHwJKqhcDLmNi as exception:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmNj(exception)
 def cookiefile_check(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN):
  OGdvXBPaUQrfxsSApMHwJKqhcDLmlW={}
  try: 
   with OGdvXBPaUQrfxsSApMHwJKqhcDLmNl(OGdvXBPaUQrfxsSApMHwJKqhcDLmIl,'r',-1,'utf-8')as fp:
    OGdvXBPaUQrfxsSApMHwJKqhcDLmlW= OGdvXBPaUQrfxsSApMHwJKqhcDLmlT.load(fp)
  except OGdvXBPaUQrfxsSApMHwJKqhcDLmNi as exception:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.wininfo_clear()
   return OGdvXBPaUQrfxsSApMHwJKqhcDLmly
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYn =__addon__.getSetting('id')
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYo =__addon__.getSetting('pw')
  OGdvXBPaUQrfxsSApMHwJKqhcDLmlV =__addon__.getSetting('selected_profile')
  OGdvXBPaUQrfxsSApMHwJKqhcDLmlW['wavve_id']=base64.standard_b64decode(OGdvXBPaUQrfxsSApMHwJKqhcDLmlW['wavve_id']).decode('utf-8')
  OGdvXBPaUQrfxsSApMHwJKqhcDLmlW['wavve_pw']=base64.standard_b64decode(OGdvXBPaUQrfxsSApMHwJKqhcDLmlW['wavve_pw']).decode('utf-8')
  if OGdvXBPaUQrfxsSApMHwJKqhcDLmYn!=OGdvXBPaUQrfxsSApMHwJKqhcDLmlW['wavve_id']or OGdvXBPaUQrfxsSApMHwJKqhcDLmYo!=OGdvXBPaUQrfxsSApMHwJKqhcDLmlW['wavve_pw']or OGdvXBPaUQrfxsSApMHwJKqhcDLmlV!=OGdvXBPaUQrfxsSApMHwJKqhcDLmlW['wavve_profile']:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.wininfo_clear()
   return OGdvXBPaUQrfxsSApMHwJKqhcDLmly
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYF =datetime.datetime.now().date()
  OGdvXBPaUQrfxsSApMHwJKqhcDLmlk =OGdvXBPaUQrfxsSApMHwJKqhcDLmlW['wavve_limitdate']
  try:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYW=datetime.datetime.strptime(OGdvXBPaUQrfxsSApMHwJKqhcDLmlk,'%Y-%m-%d').date()
  except OGdvXBPaUQrfxsSApMHwJKqhcDLmNY:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYW=datetime.datetime(*(time.strptime(OGdvXBPaUQrfxsSApMHwJKqhcDLmlk,'%Y-%m-%d')[0:6])).date()
  if OGdvXBPaUQrfxsSApMHwJKqhcDLmYW<OGdvXBPaUQrfxsSApMHwJKqhcDLmYF:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.wininfo_clear()
   return OGdvXBPaUQrfxsSApMHwJKqhcDLmly
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYI=xbmcgui.Window(10000)
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYI.setProperty('WAVVE_M_CREDENTIAL',OGdvXBPaUQrfxsSApMHwJKqhcDLmlW['wavve_token'])
  OGdvXBPaUQrfxsSApMHwJKqhcDLmYI.setProperty('WAVVE_M_LOGINTIME',OGdvXBPaUQrfxsSApMHwJKqhcDLmlk)
  return OGdvXBPaUQrfxsSApMHwJKqhcDLmlz
 def wavve_main(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN):
  OGdvXBPaUQrfxsSApMHwJKqhcDLmei=OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.main_params.get('mode',OGdvXBPaUQrfxsSApMHwJKqhcDLmlR)
  OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.login_main()
  if OGdvXBPaUQrfxsSApMHwJKqhcDLmei is OGdvXBPaUQrfxsSApMHwJKqhcDLmlR:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.dp_Main_List()
  elif OGdvXBPaUQrfxsSApMHwJKqhcDLmei=='GNB_LIST':
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.dp_Gnb_List(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.main_params)
  elif OGdvXBPaUQrfxsSApMHwJKqhcDLmei=='GN_LIST':
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.dp_Deeplink_List(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.main_params)
  elif OGdvXBPaUQrfxsSApMHwJKqhcDLmei=='DEEP_LIST':
   OGdvXBPaUQrfxsSApMHwJKqhcDLmYy=OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.main_params.get('uicode',OGdvXBPaUQrfxsSApMHwJKqhcDLmlR)
   if OGdvXBPaUQrfxsSApMHwJKqhcDLmYy in['quick','vod','program','x']:
    OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.dp_Episodelink_List(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.main_params)
   else:OGdvXBPaUQrfxsSApMHwJKqhcDLmlR
  elif OGdvXBPaUQrfxsSApMHwJKqhcDLmei in['LIVE','VOD','MOVIE']:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.play_VIDEO(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.main_params)
   time.sleep(0.1)
  elif OGdvXBPaUQrfxsSApMHwJKqhcDLmei=='GN_MYVIEW':
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.dp_Myview_Group(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.main_params)
  elif OGdvXBPaUQrfxsSApMHwJKqhcDLmei=='MYVIEW_LIST':
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.dp_Myview_List(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.main_params)
  elif OGdvXBPaUQrfxsSApMHwJKqhcDLmei=='GENRE':
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.dp_Genre_Group(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.main_params)
  elif OGdvXBPaUQrfxsSApMHwJKqhcDLmei=='GENRE_LIST':
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.dp_Genre_List(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.main_params)
  elif OGdvXBPaUQrfxsSApMHwJKqhcDLmei=='WATCH':
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.dp_Watch_List(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.main_params)
  elif OGdvXBPaUQrfxsSApMHwJKqhcDLmei=='MYVIEW_REMOVE':
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.dp_WatchList_Delete(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.main_params)
  elif OGdvXBPaUQrfxsSApMHwJKqhcDLmei=='SEARCH':
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.dp_Search_Group(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.main_params)
  elif OGdvXBPaUQrfxsSApMHwJKqhcDLmei=='SEARCH_LIST':
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.dp_Search_List(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.main_params)
  elif OGdvXBPaUQrfxsSApMHwJKqhcDLmei=='ORDER_BY':
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.dp_setEpOrderby(OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.main_params)
  elif OGdvXBPaUQrfxsSApMHwJKqhcDLmei=='LOGOUT':
   OGdvXBPaUQrfxsSApMHwJKqhcDLmIN.logout()
  else:
   OGdvXBPaUQrfxsSApMHwJKqhcDLmlR
# Created by pyminifier (https://github.com/liftoff/pyminifier)
