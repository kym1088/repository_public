__author__="NightRain"
qvFbHfCkKQLMhdwYmVazcGBpAIxgRD=object
qvFbHfCkKQLMhdwYmVazcGBpAIxgRl=None
qvFbHfCkKQLMhdwYmVazcGBpAIxgRi=False
qvFbHfCkKQLMhdwYmVazcGBpAIxgRS=True
qvFbHfCkKQLMhdwYmVazcGBpAIxgRN=range
qvFbHfCkKQLMhdwYmVazcGBpAIxgRu=str
qvFbHfCkKQLMhdwYmVazcGBpAIxgRo=Exception
qvFbHfCkKQLMhdwYmVazcGBpAIxgRT=print
qvFbHfCkKQLMhdwYmVazcGBpAIxgRO=dict
qvFbHfCkKQLMhdwYmVazcGBpAIxgRe=int
qvFbHfCkKQLMhdwYmVazcGBpAIxgRn=len
import urllib
import re
import json
import sys
import requests
import datetime
class qvFbHfCkKQLMhdwYmVazcGBpAIxgrP(qvFbHfCkKQLMhdwYmVazcGBpAIxgRD):
 def __init__(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD):
  qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.API_DOMAIN='https://apis.wavve.com'
  qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.CREDENTIAL='none'
  qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.DEVICE ='pc'
  qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.DRM ='wm'
  qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.PARTNER ='pooq'
  qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.POOQZONE ='none'
  qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.REGION ='kor'
  qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.TARGETAGE ='all'
  qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.HTTPTAG ='https://'
  qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.LIST_LIMIT=30 
  qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.EP_LIMIT =30 
  qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.MV_LIMIT =24 
  qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.SEARCH_LIMIT=20 
  qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.guid ='none' 
  qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.guidtimestamp='none' 
  qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.DEFAULT_HEADER={'user-agent':qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.USER_AGENT}
 def callRequestCookies(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD,jobtype,qvFbHfCkKQLMhdwYmVazcGBpAIxgrW,payload=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,params=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,headers=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,cookies=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,redirects=qvFbHfCkKQLMhdwYmVazcGBpAIxgRi):
  qvFbHfCkKQLMhdwYmVazcGBpAIxgrl=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.DEFAULT_HEADER
  if headers:qvFbHfCkKQLMhdwYmVazcGBpAIxgrl.update(headers)
  if jobtype=='Get':
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrR=requests.get(qvFbHfCkKQLMhdwYmVazcGBpAIxgrW,params=params,headers=qvFbHfCkKQLMhdwYmVazcGBpAIxgrl,cookies=cookies,allow_redirects=redirects)
  else:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrR=requests.post(qvFbHfCkKQLMhdwYmVazcGBpAIxgrW,data=payload,params=params,headers=qvFbHfCkKQLMhdwYmVazcGBpAIxgrl,cookies=cookies,allow_redirects=redirects)
  return qvFbHfCkKQLMhdwYmVazcGBpAIxgrR
 def SaveCredential(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD,qvFbHfCkKQLMhdwYmVazcGBpAIxgri):
  qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.CREDENTIAL=qvFbHfCkKQLMhdwYmVazcGBpAIxgri
 def LoadCredential(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD):
  return qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.CREDENTIAL
 def GetDefaultParams(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD,login=qvFbHfCkKQLMhdwYmVazcGBpAIxgRS):
  qvFbHfCkKQLMhdwYmVazcGBpAIxgrS={'apikey':qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.APIKEY,'credential':qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.CREDENTIAL if login else 'none','device':qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.DEVICE,'drm':qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.DRM,'partner':qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.PARTNER,'pooqzone':qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.POOQZONE,'region':qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.REGION,'targetage':qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.TARGETAGE}
  return qvFbHfCkKQLMhdwYmVazcGBpAIxgrS
 def GetGUID(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrN=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   qvFbHfCkKQLMhdwYmVazcGBpAIxgru=GenerateRandomString(5)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgro=qvFbHfCkKQLMhdwYmVazcGBpAIxgru+media+qvFbHfCkKQLMhdwYmVazcGBpAIxgrN
   return qvFbHfCkKQLMhdwYmVazcGBpAIxgro
  def GenerateRandomString(num):
   from random import randint
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrT=""
   for i in qvFbHfCkKQLMhdwYmVazcGBpAIxgRN(0,num):
    s=qvFbHfCkKQLMhdwYmVazcGBpAIxgRu(randint(1,5))
    qvFbHfCkKQLMhdwYmVazcGBpAIxgrT+=s
   return qvFbHfCkKQLMhdwYmVazcGBpAIxgrT
  qvFbHfCkKQLMhdwYmVazcGBpAIxgro=GenerateID(guid_str)
  qvFbHfCkKQLMhdwYmVazcGBpAIxgrO=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.GetHash(qvFbHfCkKQLMhdwYmVazcGBpAIxgro)
  if guidType==2:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrO='%s-%s-%s-%s-%s'%(qvFbHfCkKQLMhdwYmVazcGBpAIxgrO[:8],qvFbHfCkKQLMhdwYmVazcGBpAIxgrO[8:12],qvFbHfCkKQLMhdwYmVazcGBpAIxgrO[12:16],qvFbHfCkKQLMhdwYmVazcGBpAIxgrO[16:20],qvFbHfCkKQLMhdwYmVazcGBpAIxgrO[20:])
  return qvFbHfCkKQLMhdwYmVazcGBpAIxgrO
 def GetHash(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return qvFbHfCkKQLMhdwYmVazcGBpAIxgRu(m.hexdigest())
 def CheckQuality(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD,sel_qt,qt_list):
  qvFbHfCkKQLMhdwYmVazcGBpAIxgre=0
  for qvFbHfCkKQLMhdwYmVazcGBpAIxgrn in qt_list:
   if sel_qt>=qvFbHfCkKQLMhdwYmVazcGBpAIxgrn:return qvFbHfCkKQLMhdwYmVazcGBpAIxgrn
   qvFbHfCkKQLMhdwYmVazcGBpAIxgre=qvFbHfCkKQLMhdwYmVazcGBpAIxgrn
  return qvFbHfCkKQLMhdwYmVazcGBpAIxgre
 def Get_Now_Datetime(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD,in_text):
  qvFbHfCkKQLMhdwYmVazcGBpAIxgrs=in_text.replace('&lt;','<').replace('&gt;','>')
  qvFbHfCkKQLMhdwYmVazcGBpAIxgrs=qvFbHfCkKQLMhdwYmVazcGBpAIxgrs.replace('$O$','')
  qvFbHfCkKQLMhdwYmVazcGBpAIxgrs=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',qvFbHfCkKQLMhdwYmVazcGBpAIxgrs)
  qvFbHfCkKQLMhdwYmVazcGBpAIxgrs=qvFbHfCkKQLMhdwYmVazcGBpAIxgrs.lstrip('#')
  return qvFbHfCkKQLMhdwYmVazcGBpAIxgrs
 def GetCredential(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD,user_id,user_pw,user_pf):
  qvFbHfCkKQLMhdwYmVazcGBpAIxgry=qvFbHfCkKQLMhdwYmVazcGBpAIxgRi
  try:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrW=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.API_DOMAIN+ '/login'
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.GetDefaultParams()
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrE={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrj=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.callRequestCookies('Post',qvFbHfCkKQLMhdwYmVazcGBpAIxgrW,payload=qvFbHfCkKQLMhdwYmVazcGBpAIxgrE,params=qvFbHfCkKQLMhdwYmVazcGBpAIxgrS,headers=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,cookies=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrU=json.loads(qvFbHfCkKQLMhdwYmVazcGBpAIxgrj.text)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgri=qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['credential']
   if user_pf!=0:
    qvFbHfCkKQLMhdwYmVazcGBpAIxgrE={'id':qvFbHfCkKQLMhdwYmVazcGBpAIxgri,'password':'','profile':qvFbHfCkKQLMhdwYmVazcGBpAIxgRu(user_pf),'pushid':'','type':'credential'}
    qvFbHfCkKQLMhdwYmVazcGBpAIxgrS['credential']=qvFbHfCkKQLMhdwYmVazcGBpAIxgri 
    qvFbHfCkKQLMhdwYmVazcGBpAIxgrj=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.callRequestCookies('Post',qvFbHfCkKQLMhdwYmVazcGBpAIxgrW,payload=qvFbHfCkKQLMhdwYmVazcGBpAIxgrE,params=qvFbHfCkKQLMhdwYmVazcGBpAIxgrS,headers=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,cookies=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl)
    qvFbHfCkKQLMhdwYmVazcGBpAIxgrU=json.loads(qvFbHfCkKQLMhdwYmVazcGBpAIxgrj.text)
    qvFbHfCkKQLMhdwYmVazcGBpAIxgri=qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['credential']
   if qvFbHfCkKQLMhdwYmVazcGBpAIxgri:qvFbHfCkKQLMhdwYmVazcGBpAIxgry=qvFbHfCkKQLMhdwYmVazcGBpAIxgRS
  except qvFbHfCkKQLMhdwYmVazcGBpAIxgRo as exception:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgRT(exception)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgri='none' 
  qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.SaveCredential(qvFbHfCkKQLMhdwYmVazcGBpAIxgri)
  return qvFbHfCkKQLMhdwYmVazcGBpAIxgry
 def GetIssue(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD):
  qvFbHfCkKQLMhdwYmVazcGBpAIxgrX=qvFbHfCkKQLMhdwYmVazcGBpAIxgRi
  try:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrW=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.API_DOMAIN+'/guid/issue'
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.GetDefaultParams()
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrj=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.callRequestCookies('Get',qvFbHfCkKQLMhdwYmVazcGBpAIxgrW,payload=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,params=qvFbHfCkKQLMhdwYmVazcGBpAIxgrS,headers=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,cookies=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrU=json.loads(qvFbHfCkKQLMhdwYmVazcGBpAIxgrj.text)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrJ=qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['guid']
   qvFbHfCkKQLMhdwYmVazcGBpAIxgPr=qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['guidtimestamp']
   if qvFbHfCkKQLMhdwYmVazcGBpAIxgrJ:qvFbHfCkKQLMhdwYmVazcGBpAIxgrX=qvFbHfCkKQLMhdwYmVazcGBpAIxgRS
  except qvFbHfCkKQLMhdwYmVazcGBpAIxgRo as exception:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgRT(exception)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrJ='none'
   qvFbHfCkKQLMhdwYmVazcGBpAIxgPr='none' 
  qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.guid=qvFbHfCkKQLMhdwYmVazcGBpAIxgrJ
  qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.guidtimestamp=qvFbHfCkKQLMhdwYmVazcGBpAIxgPr
  return qvFbHfCkKQLMhdwYmVazcGBpAIxgrX
 def Baseapi_Parse(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD,qvFbHfCkKQLMhdwYmVazcGBpAIxgPi):
  try:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgPD =urllib.parse.urlsplit(qvFbHfCkKQLMhdwYmVazcGBpAIxgPi)
   if qvFbHfCkKQLMhdwYmVazcGBpAIxgPD.netloc=='':
    qvFbHfCkKQLMhdwYmVazcGBpAIxgrW=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.HTTPTAG+qvFbHfCkKQLMhdwYmVazcGBpAIxgPD.netloc+qvFbHfCkKQLMhdwYmVazcGBpAIxgPD.path
   else:
    qvFbHfCkKQLMhdwYmVazcGBpAIxgrW=qvFbHfCkKQLMhdwYmVazcGBpAIxgPD.scheme+'://'+qvFbHfCkKQLMhdwYmVazcGBpAIxgPD.netloc+qvFbHfCkKQLMhdwYmVazcGBpAIxgPD.path
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS=qvFbHfCkKQLMhdwYmVazcGBpAIxgRO(urllib.parse.parse_qsl(qvFbHfCkKQLMhdwYmVazcGBpAIxgPD.query))
  except:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgRT(exception)
   return '',{}
  return qvFbHfCkKQLMhdwYmVazcGBpAIxgrW,qvFbHfCkKQLMhdwYmVazcGBpAIxgrS
 def GetSupermultiUrl(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD,sCode,sIndex='0'):
  try:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrW=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.API_DOMAIN+'/cf/supermultisections/'+sCode
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.GetDefaultParams(login=qvFbHfCkKQLMhdwYmVazcGBpAIxgRi)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrj=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.callRequestCookies('Get',qvFbHfCkKQLMhdwYmVazcGBpAIxgrW,payload=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,params=qvFbHfCkKQLMhdwYmVazcGBpAIxgrS,headers=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,cookies=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrU=json.loads(qvFbHfCkKQLMhdwYmVazcGBpAIxgrj.text)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgPl=qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['multisectionlist'][qvFbHfCkKQLMhdwYmVazcGBpAIxgRe(sIndex)]['eventlist'][1]['url']
  except qvFbHfCkKQLMhdwYmVazcGBpAIxgRo as exception:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgRT(exception)
   return ''
  return qvFbHfCkKQLMhdwYmVazcGBpAIxgPl
 def Get_LiveCatagory_List(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD,sCode,sIndex='0'):
  qvFbHfCkKQLMhdwYmVazcGBpAIxgPR=[]
  qvFbHfCkKQLMhdwYmVazcGBpAIxgPi =qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.GetSupermultiUrl(sCode,sIndex)
  (qvFbHfCkKQLMhdwYmVazcGBpAIxgrW,qvFbHfCkKQLMhdwYmVazcGBpAIxgrS)=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.Baseapi_Parse(qvFbHfCkKQLMhdwYmVazcGBpAIxgPi)
  if qvFbHfCkKQLMhdwYmVazcGBpAIxgrW=='':return qvFbHfCkKQLMhdwYmVazcGBpAIxgPR,''
  try:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS.update(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.GetDefaultParams(login=qvFbHfCkKQLMhdwYmVazcGBpAIxgRi))
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrj=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.callRequestCookies('Get',qvFbHfCkKQLMhdwYmVazcGBpAIxgrW,payload=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,params=qvFbHfCkKQLMhdwYmVazcGBpAIxgrS,headers=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,cookies=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrU=json.loads(qvFbHfCkKQLMhdwYmVazcGBpAIxgrj.text)
   if not('filter_item_list' in qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['filter']['filterlist'][0]):return[],''
   qvFbHfCkKQLMhdwYmVazcGBpAIxgPN=qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['filter']['filterlist'][0]['filter_item_list']
   for qvFbHfCkKQLMhdwYmVazcGBpAIxgPu in qvFbHfCkKQLMhdwYmVazcGBpAIxgPN:
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPo={'title':qvFbHfCkKQLMhdwYmVazcGBpAIxgPu['title'],'genre':qvFbHfCkKQLMhdwYmVazcGBpAIxgPu['api_parameters'][qvFbHfCkKQLMhdwYmVazcGBpAIxgPu['api_parameters'].index('=')+1:]}
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPR.append(qvFbHfCkKQLMhdwYmVazcGBpAIxgPo)
  except qvFbHfCkKQLMhdwYmVazcGBpAIxgRo as exception:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgRT(exception)
   return[],''
  return qvFbHfCkKQLMhdwYmVazcGBpAIxgPR,qvFbHfCkKQLMhdwYmVazcGBpAIxgPi
 def Get_MainCatagory_List(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD,sCode,sIndex='0'):
  qvFbHfCkKQLMhdwYmVazcGBpAIxgPR=[]
  qvFbHfCkKQLMhdwYmVazcGBpAIxgPi =qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.GetSupermultiUrl(sCode,sIndex)
  (qvFbHfCkKQLMhdwYmVazcGBpAIxgrW,qvFbHfCkKQLMhdwYmVazcGBpAIxgrS)=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.Baseapi_Parse(qvFbHfCkKQLMhdwYmVazcGBpAIxgPi)
  if qvFbHfCkKQLMhdwYmVazcGBpAIxgrW=='':return qvFbHfCkKQLMhdwYmVazcGBpAIxgPR
  try:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS.update(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.GetDefaultParams(login=qvFbHfCkKQLMhdwYmVazcGBpAIxgRi))
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrj=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.callRequestCookies('Get',qvFbHfCkKQLMhdwYmVazcGBpAIxgrW,payload=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,params=qvFbHfCkKQLMhdwYmVazcGBpAIxgrS,headers=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,cookies=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrU=json.loads(qvFbHfCkKQLMhdwYmVazcGBpAIxgrj.text)
   if not('celllist' in qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['band']):return[]
   qvFbHfCkKQLMhdwYmVazcGBpAIxgPN=qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['band']['celllist']
   for qvFbHfCkKQLMhdwYmVazcGBpAIxgPu in qvFbHfCkKQLMhdwYmVazcGBpAIxgPN:
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPT =qvFbHfCkKQLMhdwYmVazcGBpAIxgPu['event_list'][1]['url']
    (qvFbHfCkKQLMhdwYmVazcGBpAIxgPO,qvFbHfCkKQLMhdwYmVazcGBpAIxgPe)=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.Baseapi_Parse(qvFbHfCkKQLMhdwYmVazcGBpAIxgPT)
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPo={'title':qvFbHfCkKQLMhdwYmVazcGBpAIxgPu['title_list'][0]['text'],'suburl':qvFbHfCkKQLMhdwYmVazcGBpAIxgPO,'subapi':qvFbHfCkKQLMhdwYmVazcGBpAIxgPe.get('api'),'subtype':'catagory' if qvFbHfCkKQLMhdwYmVazcGBpAIxgPe else 'supersection'}
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPR.append(qvFbHfCkKQLMhdwYmVazcGBpAIxgPo)
  except qvFbHfCkKQLMhdwYmVazcGBpAIxgRo as exception:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgRT(exception)
   return[]
  return qvFbHfCkKQLMhdwYmVazcGBpAIxgPR
 def Get_SuperMultiSection_List(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD,subapi_text):
  qvFbHfCkKQLMhdwYmVazcGBpAIxgPR=[]
  qvFbHfCkKQLMhdwYmVazcGBpAIxgrS={}
  try:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgPD =urllib.parse.urlsplit(subapi_text)
   if qvFbHfCkKQLMhdwYmVazcGBpAIxgPD.path.find('apis.wavve.com')>=0: 
    qvFbHfCkKQLMhdwYmVazcGBpAIxgrW=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.HTTPTAG+qvFbHfCkKQLMhdwYmVazcGBpAIxgPD.path 
    qvFbHfCkKQLMhdwYmVazcGBpAIxgrS=qvFbHfCkKQLMhdwYmVazcGBpAIxgRO(urllib.parse.parse_qsl(qvFbHfCkKQLMhdwYmVazcGBpAIxgPD.query))
   else:
    qvFbHfCkKQLMhdwYmVazcGBpAIxgrW=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.API_DOMAIN+'/cf'+qvFbHfCkKQLMhdwYmVazcGBpAIxgPD.path 
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrW=qvFbHfCkKQLMhdwYmVazcGBpAIxgrW.replace('supermultisection/','supermultisections/')
  except qvFbHfCkKQLMhdwYmVazcGBpAIxgRo as exception:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgRT(exception)
   return[]
  try:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS.update(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.GetDefaultParams(login=qvFbHfCkKQLMhdwYmVazcGBpAIxgRi))
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrj=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.callRequestCookies('Get',qvFbHfCkKQLMhdwYmVazcGBpAIxgrW,payload=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,params=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,headers=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,cookies=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrU=json.loads(qvFbHfCkKQLMhdwYmVazcGBpAIxgrj.text)
   if not('multisectionlist' in qvFbHfCkKQLMhdwYmVazcGBpAIxgrU):return[]
   qvFbHfCkKQLMhdwYmVazcGBpAIxgPN=qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['multisectionlist']
   for qvFbHfCkKQLMhdwYmVazcGBpAIxgPu in qvFbHfCkKQLMhdwYmVazcGBpAIxgPN:
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPn=qvFbHfCkKQLMhdwYmVazcGBpAIxgPu['title']
    if qvFbHfCkKQLMhdwYmVazcGBpAIxgRn(qvFbHfCkKQLMhdwYmVazcGBpAIxgPn)==0:continue
    if qvFbHfCkKQLMhdwYmVazcGBpAIxgPn=='minor':continue
    if re.search(u'베너',qvFbHfCkKQLMhdwYmVazcGBpAIxgPn):continue
    if re.search(u'배너',qvFbHfCkKQLMhdwYmVazcGBpAIxgPn):continue 
    if qvFbHfCkKQLMhdwYmVazcGBpAIxgRn(qvFbHfCkKQLMhdwYmVazcGBpAIxgPu['eventlist'])>=3:
     qvFbHfCkKQLMhdwYmVazcGBpAIxgPe =qvFbHfCkKQLMhdwYmVazcGBpAIxgPu['eventlist'][2]['url']
    else:
     qvFbHfCkKQLMhdwYmVazcGBpAIxgPe =qvFbHfCkKQLMhdwYmVazcGBpAIxgPu['eventlist'][1]['url']
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPt=qvFbHfCkKQLMhdwYmVazcGBpAIxgPu['cell_type']
    if qvFbHfCkKQLMhdwYmVazcGBpAIxgPt=='band_2':
     if qvFbHfCkKQLMhdwYmVazcGBpAIxgPe.find('channellist=')>=0:
      qvFbHfCkKQLMhdwYmVazcGBpAIxgPt='band_live'
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPo={'title':qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.Get_ChangeText(qvFbHfCkKQLMhdwYmVazcGBpAIxgPn),'subapi':qvFbHfCkKQLMhdwYmVazcGBpAIxgPe,'cell_type':qvFbHfCkKQLMhdwYmVazcGBpAIxgPt}
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPR.append(qvFbHfCkKQLMhdwYmVazcGBpAIxgPo)
  except qvFbHfCkKQLMhdwYmVazcGBpAIxgRo as exception:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgRT(exception)
   return[]
  return qvFbHfCkKQLMhdwYmVazcGBpAIxgPR
 def Get_BandLiveSection_List(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD,qvFbHfCkKQLMhdwYmVazcGBpAIxgPi,page_int=1):
  qvFbHfCkKQLMhdwYmVazcGBpAIxgPs=[]
  qvFbHfCkKQLMhdwYmVazcGBpAIxgPy=qvFbHfCkKQLMhdwYmVazcGBpAIxgPJ=1
  qvFbHfCkKQLMhdwYmVazcGBpAIxgPW=qvFbHfCkKQLMhdwYmVazcGBpAIxgRi
  try:
   (qvFbHfCkKQLMhdwYmVazcGBpAIxgrW,qvFbHfCkKQLMhdwYmVazcGBpAIxgrS)=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.Baseapi_Parse(qvFbHfCkKQLMhdwYmVazcGBpAIxgPi)
  except qvFbHfCkKQLMhdwYmVazcGBpAIxgRo as exception:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgRT(exception)
   return[],qvFbHfCkKQLMhdwYmVazcGBpAIxgRi
  try:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS['limit']=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.LIST_LIMIT
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS['offset']=qvFbHfCkKQLMhdwYmVazcGBpAIxgRu((page_int-1)*qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.LIST_LIMIT)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS.update(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.GetDefaultParams(login=qvFbHfCkKQLMhdwYmVazcGBpAIxgRi))
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrj=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.callRequestCookies('Get',qvFbHfCkKQLMhdwYmVazcGBpAIxgrW,payload=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,params=qvFbHfCkKQLMhdwYmVazcGBpAIxgrS,headers=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,cookies=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrU=json.loads(qvFbHfCkKQLMhdwYmVazcGBpAIxgrj.text)
   if not('celllist' in qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['cell_toplist']):return[],qvFbHfCkKQLMhdwYmVazcGBpAIxgRi
   qvFbHfCkKQLMhdwYmVazcGBpAIxgPN=qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['cell_toplist']['celllist']
   for qvFbHfCkKQLMhdwYmVazcGBpAIxgPu in qvFbHfCkKQLMhdwYmVazcGBpAIxgPN:
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPE =qvFbHfCkKQLMhdwYmVazcGBpAIxgPu['event_list'][1]['url']
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPj=urllib.parse.urlsplit(qvFbHfCkKQLMhdwYmVazcGBpAIxgPE).query
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPj=qvFbHfCkKQLMhdwYmVazcGBpAIxgRO(urllib.parse.parse_qsl(qvFbHfCkKQLMhdwYmVazcGBpAIxgPj))
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPU='channelid'
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPX=qvFbHfCkKQLMhdwYmVazcGBpAIxgPj[qvFbHfCkKQLMhdwYmVazcGBpAIxgPU]
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPo={'studio':qvFbHfCkKQLMhdwYmVazcGBpAIxgPu['title_list'][0]['text'],'tvshowtitle':qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.Get_ChangeText(qvFbHfCkKQLMhdwYmVazcGBpAIxgPu['title_list'][1]['text']),'channelid':qvFbHfCkKQLMhdwYmVazcGBpAIxgPX,'age':qvFbHfCkKQLMhdwYmVazcGBpAIxgPu.get('age'),'thumbnail':'https://%s'%qvFbHfCkKQLMhdwYmVazcGBpAIxgPu.get('thumbnail')}
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPs.append(qvFbHfCkKQLMhdwYmVazcGBpAIxgPo)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgPy=qvFbHfCkKQLMhdwYmVazcGBpAIxgRe(qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['cell_toplist']['pagecount'])
   if qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['cell_toplist']['count']:qvFbHfCkKQLMhdwYmVazcGBpAIxgPJ =qvFbHfCkKQLMhdwYmVazcGBpAIxgRe(qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['cell_toplist']['count'])
   else:qvFbHfCkKQLMhdwYmVazcGBpAIxgPJ=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.LIST_LIMIT*page_int
   qvFbHfCkKQLMhdwYmVazcGBpAIxgPW=qvFbHfCkKQLMhdwYmVazcGBpAIxgPy>qvFbHfCkKQLMhdwYmVazcGBpAIxgPJ
  except qvFbHfCkKQLMhdwYmVazcGBpAIxgRo as exception:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgRT(exception)
   return[],qvFbHfCkKQLMhdwYmVazcGBpAIxgRi
  return qvFbHfCkKQLMhdwYmVazcGBpAIxgPs,qvFbHfCkKQLMhdwYmVazcGBpAIxgPW
 def Get_Band2Section_List(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD,qvFbHfCkKQLMhdwYmVazcGBpAIxgPi,page_int=1):
  qvFbHfCkKQLMhdwYmVazcGBpAIxgDr=[]
  qvFbHfCkKQLMhdwYmVazcGBpAIxgPy=qvFbHfCkKQLMhdwYmVazcGBpAIxgPJ=1
  qvFbHfCkKQLMhdwYmVazcGBpAIxgPW=qvFbHfCkKQLMhdwYmVazcGBpAIxgRi
  try:
   (qvFbHfCkKQLMhdwYmVazcGBpAIxgrW,qvFbHfCkKQLMhdwYmVazcGBpAIxgrS)=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.Baseapi_Parse(qvFbHfCkKQLMhdwYmVazcGBpAIxgPi)
  except qvFbHfCkKQLMhdwYmVazcGBpAIxgRo as exception:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgRT(exception)
   return[],qvFbHfCkKQLMhdwYmVazcGBpAIxgRi
  try:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS['came'] ='BandView'
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS['limit']=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.LIST_LIMIT
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS['offset']=qvFbHfCkKQLMhdwYmVazcGBpAIxgRu((page_int-1)*qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.LIST_LIMIT)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS.update(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.GetDefaultParams(login=qvFbHfCkKQLMhdwYmVazcGBpAIxgRi))
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrj=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.callRequestCookies('Get',qvFbHfCkKQLMhdwYmVazcGBpAIxgrW,payload=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,params=qvFbHfCkKQLMhdwYmVazcGBpAIxgrS,headers=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,cookies=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrU=json.loads(qvFbHfCkKQLMhdwYmVazcGBpAIxgrj.text)
   if not('celllist' in qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['cell_toplist']):return[],qvFbHfCkKQLMhdwYmVazcGBpAIxgRi
   qvFbHfCkKQLMhdwYmVazcGBpAIxgPN=qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['cell_toplist']['celllist']
   for qvFbHfCkKQLMhdwYmVazcGBpAIxgPu in qvFbHfCkKQLMhdwYmVazcGBpAIxgPN:
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPE =qvFbHfCkKQLMhdwYmVazcGBpAIxgPu['event_list'][1]['url']
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPj=urllib.parse.urlsplit(qvFbHfCkKQLMhdwYmVazcGBpAIxgPE).query
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPj=qvFbHfCkKQLMhdwYmVazcGBpAIxgRO(urllib.parse.parse_qsl(qvFbHfCkKQLMhdwYmVazcGBpAIxgPj))
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPU='contentid'
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPX=qvFbHfCkKQLMhdwYmVazcGBpAIxgPj[qvFbHfCkKQLMhdwYmVazcGBpAIxgPU]
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPo={'programtitle':qvFbHfCkKQLMhdwYmVazcGBpAIxgPu['title_list'][0]['text'],'episodetitle':qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.Get_ChangeText(qvFbHfCkKQLMhdwYmVazcGBpAIxgPu['title_list'][1]['text']),'age':qvFbHfCkKQLMhdwYmVazcGBpAIxgPu.get('age'),'thumbnail':qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.HTTPTAG+qvFbHfCkKQLMhdwYmVazcGBpAIxgPu.get('thumbnail'),'vidtype':qvFbHfCkKQLMhdwYmVazcGBpAIxgPU,'videoid':qvFbHfCkKQLMhdwYmVazcGBpAIxgPX}
    qvFbHfCkKQLMhdwYmVazcGBpAIxgDr.append(qvFbHfCkKQLMhdwYmVazcGBpAIxgPo)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgPy=qvFbHfCkKQLMhdwYmVazcGBpAIxgRe(qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['cell_toplist']['pagecount'])
   if qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['cell_toplist']['count']:qvFbHfCkKQLMhdwYmVazcGBpAIxgPJ =qvFbHfCkKQLMhdwYmVazcGBpAIxgRe(qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['cell_toplist']['count'])
   else:qvFbHfCkKQLMhdwYmVazcGBpAIxgPJ=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.LIST_LIMIT*page_int
   qvFbHfCkKQLMhdwYmVazcGBpAIxgPW=qvFbHfCkKQLMhdwYmVazcGBpAIxgPy>qvFbHfCkKQLMhdwYmVazcGBpAIxgPJ
  except qvFbHfCkKQLMhdwYmVazcGBpAIxgRo as exception:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgRT(exception)
   return[],qvFbHfCkKQLMhdwYmVazcGBpAIxgRi
  return qvFbHfCkKQLMhdwYmVazcGBpAIxgDr,qvFbHfCkKQLMhdwYmVazcGBpAIxgPW
 def Get_Program_List(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD,qvFbHfCkKQLMhdwYmVazcGBpAIxgPi,page_int=1,orderby='-'):
  qvFbHfCkKQLMhdwYmVazcGBpAIxgDP=[]
  qvFbHfCkKQLMhdwYmVazcGBpAIxgPy=qvFbHfCkKQLMhdwYmVazcGBpAIxgPJ=1
  qvFbHfCkKQLMhdwYmVazcGBpAIxgPW=qvFbHfCkKQLMhdwYmVazcGBpAIxgRi
  (qvFbHfCkKQLMhdwYmVazcGBpAIxgrW,qvFbHfCkKQLMhdwYmVazcGBpAIxgrS)=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.Baseapi_Parse(qvFbHfCkKQLMhdwYmVazcGBpAIxgPi)
  if qvFbHfCkKQLMhdwYmVazcGBpAIxgrW=='':return qvFbHfCkKQLMhdwYmVazcGBpAIxgDP,qvFbHfCkKQLMhdwYmVazcGBpAIxgPW
  try:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS['limit'] =qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.LIST_LIMIT
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS['offset']=qvFbHfCkKQLMhdwYmVazcGBpAIxgRu((page_int-1)*qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.LIST_LIMIT)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS['page'] =qvFbHfCkKQLMhdwYmVazcGBpAIxgRu(page_int)
   if qvFbHfCkKQLMhdwYmVazcGBpAIxgrS.get('orderby')!='' and qvFbHfCkKQLMhdwYmVazcGBpAIxgrS.get('orderby')!='regdatefirst' and orderby!='-':
    qvFbHfCkKQLMhdwYmVazcGBpAIxgrS['orderby']=orderby 
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS.update(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.GetDefaultParams(login=qvFbHfCkKQLMhdwYmVazcGBpAIxgRi))
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrj=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.callRequestCookies('Get',qvFbHfCkKQLMhdwYmVazcGBpAIxgrW,payload=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,params=qvFbHfCkKQLMhdwYmVazcGBpAIxgrS,headers=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,cookies=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrU=json.loads(qvFbHfCkKQLMhdwYmVazcGBpAIxgrj.text)
   if qvFbHfCkKQLMhdwYmVazcGBpAIxgPi.find('instantplay')>=0:
    if not('celllist' in qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['band']):return qvFbHfCkKQLMhdwYmVazcGBpAIxgDP,qvFbHfCkKQLMhdwYmVazcGBpAIxgPW
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPN=qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['band']['celllist']
   else:
    if not('celllist' in qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['cell_toplist']):return qvFbHfCkKQLMhdwYmVazcGBpAIxgDP,qvFbHfCkKQLMhdwYmVazcGBpAIxgPW
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPN=qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['cell_toplist']['celllist']
   for qvFbHfCkKQLMhdwYmVazcGBpAIxgPu in qvFbHfCkKQLMhdwYmVazcGBpAIxgPN:
    for qvFbHfCkKQLMhdwYmVazcGBpAIxgDl in qvFbHfCkKQLMhdwYmVazcGBpAIxgPu['event_list']:
     if qvFbHfCkKQLMhdwYmVazcGBpAIxgDl.get('type')=='on-navigation':
      qvFbHfCkKQLMhdwYmVazcGBpAIxgPE =qvFbHfCkKQLMhdwYmVazcGBpAIxgDl['url']
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPj=urllib.parse.urlsplit(qvFbHfCkKQLMhdwYmVazcGBpAIxgPE).query
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPU=qvFbHfCkKQLMhdwYmVazcGBpAIxgPj[0:qvFbHfCkKQLMhdwYmVazcGBpAIxgPj.find('=')]
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPX=qvFbHfCkKQLMhdwYmVazcGBpAIxgPj[qvFbHfCkKQLMhdwYmVazcGBpAIxgPj.find('=')+1:]
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPo={'title':qvFbHfCkKQLMhdwYmVazcGBpAIxgPu['title_list'][0]['text'],'age':qvFbHfCkKQLMhdwYmVazcGBpAIxgPu['age'],'thumbnail':'https://%s'%qvFbHfCkKQLMhdwYmVazcGBpAIxgPu.get('thumbnail'),'videoid':qvFbHfCkKQLMhdwYmVazcGBpAIxgPX,'vidtype':qvFbHfCkKQLMhdwYmVazcGBpAIxgPU}
    qvFbHfCkKQLMhdwYmVazcGBpAIxgDP.append(qvFbHfCkKQLMhdwYmVazcGBpAIxgPo)
   if qvFbHfCkKQLMhdwYmVazcGBpAIxgPi.find('instantplay')<0:
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPy=qvFbHfCkKQLMhdwYmVazcGBpAIxgRe(qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['cell_toplist']['pagecount'])
    if qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['cell_toplist']['count']:qvFbHfCkKQLMhdwYmVazcGBpAIxgPJ =qvFbHfCkKQLMhdwYmVazcGBpAIxgRe(qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['cell_toplist']['count'])
    else:qvFbHfCkKQLMhdwYmVazcGBpAIxgPJ=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.LIST_LIMIT*page_int
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPW=qvFbHfCkKQLMhdwYmVazcGBpAIxgPy>qvFbHfCkKQLMhdwYmVazcGBpAIxgPJ
  except qvFbHfCkKQLMhdwYmVazcGBpAIxgRo as exception:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgRT(exception)
   return[],qvFbHfCkKQLMhdwYmVazcGBpAIxgRi
  return qvFbHfCkKQLMhdwYmVazcGBpAIxgDP,qvFbHfCkKQLMhdwYmVazcGBpAIxgPW
 def Get_Movie_List(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD,qvFbHfCkKQLMhdwYmVazcGBpAIxgPi,page_int=1):
  qvFbHfCkKQLMhdwYmVazcGBpAIxgDR=[]
  qvFbHfCkKQLMhdwYmVazcGBpAIxgPy=qvFbHfCkKQLMhdwYmVazcGBpAIxgPJ=1
  qvFbHfCkKQLMhdwYmVazcGBpAIxgPW=qvFbHfCkKQLMhdwYmVazcGBpAIxgRi
  (qvFbHfCkKQLMhdwYmVazcGBpAIxgrW,qvFbHfCkKQLMhdwYmVazcGBpAIxgrS)=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.Baseapi_Parse(qvFbHfCkKQLMhdwYmVazcGBpAIxgPi)
  if qvFbHfCkKQLMhdwYmVazcGBpAIxgrW=='':return qvFbHfCkKQLMhdwYmVazcGBpAIxgDR,qvFbHfCkKQLMhdwYmVazcGBpAIxgPW
  try:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS['limit']=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.MV_LIMIT
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS['offset']=qvFbHfCkKQLMhdwYmVazcGBpAIxgRu((page_int-1)*qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.MV_LIMIT)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS.update(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.GetDefaultParams(login=qvFbHfCkKQLMhdwYmVazcGBpAIxgRi))
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrj=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.callRequestCookies('Get',qvFbHfCkKQLMhdwYmVazcGBpAIxgrW,payload=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,params=qvFbHfCkKQLMhdwYmVazcGBpAIxgrS,headers=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,cookies=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrU=json.loads(qvFbHfCkKQLMhdwYmVazcGBpAIxgrj.text)
   if not('celllist' in qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['cell_toplist']):return qvFbHfCkKQLMhdwYmVazcGBpAIxgDR,qvFbHfCkKQLMhdwYmVazcGBpAIxgPW
   qvFbHfCkKQLMhdwYmVazcGBpAIxgPN=qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['cell_toplist']['celllist']
   for qvFbHfCkKQLMhdwYmVazcGBpAIxgPu in qvFbHfCkKQLMhdwYmVazcGBpAIxgPN:
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPE =qvFbHfCkKQLMhdwYmVazcGBpAIxgPu['event_list'][1]['url']
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPj=urllib.parse.urlsplit(qvFbHfCkKQLMhdwYmVazcGBpAIxgPE).query
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPU=qvFbHfCkKQLMhdwYmVazcGBpAIxgPj[0:qvFbHfCkKQLMhdwYmVazcGBpAIxgPj.find('=')]
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPX=qvFbHfCkKQLMhdwYmVazcGBpAIxgPj[qvFbHfCkKQLMhdwYmVazcGBpAIxgPj.find('=')+1:]
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPo={'title':qvFbHfCkKQLMhdwYmVazcGBpAIxgPu['title_list'][0]['text'],'age':qvFbHfCkKQLMhdwYmVazcGBpAIxgPu['age'],'thumbnail':'https://%s'%qvFbHfCkKQLMhdwYmVazcGBpAIxgPu.get('thumbnail'),'videoid':qvFbHfCkKQLMhdwYmVazcGBpAIxgPX,'vidtype':qvFbHfCkKQLMhdwYmVazcGBpAIxgPU}
    qvFbHfCkKQLMhdwYmVazcGBpAIxgDR.append(qvFbHfCkKQLMhdwYmVazcGBpAIxgPo)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgPy=qvFbHfCkKQLMhdwYmVazcGBpAIxgRe(qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['cell_toplist']['pagecount'])
   if qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['cell_toplist']['count']:qvFbHfCkKQLMhdwYmVazcGBpAIxgPJ =qvFbHfCkKQLMhdwYmVazcGBpAIxgRe(qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['cell_toplist']['count'])
   else:qvFbHfCkKQLMhdwYmVazcGBpAIxgPJ=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.MV_LIMIT*page_int
   qvFbHfCkKQLMhdwYmVazcGBpAIxgPW=qvFbHfCkKQLMhdwYmVazcGBpAIxgPy>qvFbHfCkKQLMhdwYmVazcGBpAIxgPJ
  except qvFbHfCkKQLMhdwYmVazcGBpAIxgRo as exception:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgRT(exception)
   return[],qvFbHfCkKQLMhdwYmVazcGBpAIxgRi
  return qvFbHfCkKQLMhdwYmVazcGBpAIxgDR,qvFbHfCkKQLMhdwYmVazcGBpAIxgPW
 def ProgramidToContentid(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD,qvFbHfCkKQLMhdwYmVazcGBpAIxgDN):
  qvFbHfCkKQLMhdwYmVazcGBpAIxgDi=''
  try:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrW =qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.API_DOMAIN+'/vod/programs-contentid/'+qvFbHfCkKQLMhdwYmVazcGBpAIxgDN
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.GetDefaultParams(login=qvFbHfCkKQLMhdwYmVazcGBpAIxgRi)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrj=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.callRequestCookies('Get',qvFbHfCkKQLMhdwYmVazcGBpAIxgrW,payload=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,params=qvFbHfCkKQLMhdwYmVazcGBpAIxgrS,headers=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,cookies=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgDS=json.loads(qvFbHfCkKQLMhdwYmVazcGBpAIxgrj.text)
   if not('contentid' in qvFbHfCkKQLMhdwYmVazcGBpAIxgDS):return qvFbHfCkKQLMhdwYmVazcGBpAIxgDi 
   qvFbHfCkKQLMhdwYmVazcGBpAIxgDi=qvFbHfCkKQLMhdwYmVazcGBpAIxgDS['contentid']
  except qvFbHfCkKQLMhdwYmVazcGBpAIxgRo as exception:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgRT(exception)
  return qvFbHfCkKQLMhdwYmVazcGBpAIxgDi
 def ContentidToProgramid(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD,qvFbHfCkKQLMhdwYmVazcGBpAIxgDi):
  qvFbHfCkKQLMhdwYmVazcGBpAIxgDN=''
  try:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrW =qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.API_DOMAIN+'/cf/vod/contents/'+qvFbHfCkKQLMhdwYmVazcGBpAIxgDi
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.GetDefaultParams(login=qvFbHfCkKQLMhdwYmVazcGBpAIxgRi)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrj=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.callRequestCookies('Get',qvFbHfCkKQLMhdwYmVazcGBpAIxgrW,payload=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,params=qvFbHfCkKQLMhdwYmVazcGBpAIxgrS,headers=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,cookies=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgDS=json.loads(qvFbHfCkKQLMhdwYmVazcGBpAIxgrj.text)
   if not('programid' in qvFbHfCkKQLMhdwYmVazcGBpAIxgDS):return qvFbHfCkKQLMhdwYmVazcGBpAIxgDN 
   qvFbHfCkKQLMhdwYmVazcGBpAIxgDN=qvFbHfCkKQLMhdwYmVazcGBpAIxgDS['programid']
  except qvFbHfCkKQLMhdwYmVazcGBpAIxgRo as exception:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgRT(exception)
  return qvFbHfCkKQLMhdwYmVazcGBpAIxgDN
 def GetProgramInfo(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD,program_code):
  qvFbHfCkKQLMhdwYmVazcGBpAIxgDu={}
  try:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrW=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.API_DOMAIN+'/cf/vod/contents/'+program_code
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.GetDefaultParams(login=qvFbHfCkKQLMhdwYmVazcGBpAIxgRi)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrj=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.callRequestCookies('Get',qvFbHfCkKQLMhdwYmVazcGBpAIxgrW,payload=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,params=qvFbHfCkKQLMhdwYmVazcGBpAIxgrS,headers=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,cookies=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgDS=json.loads(qvFbHfCkKQLMhdwYmVazcGBpAIxgrj.text)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgRT(qvFbHfCkKQLMhdwYmVazcGBpAIxgDS)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgDo=img_fanart=qvFbHfCkKQLMhdwYmVazcGBpAIxgDT=''
   if qvFbHfCkKQLMhdwYmVazcGBpAIxgDS.get('programposterimage')!='':qvFbHfCkKQLMhdwYmVazcGBpAIxgDo =qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.HTTPTAG+qvFbHfCkKQLMhdwYmVazcGBpAIxgDS.get('programposterimage')
   if qvFbHfCkKQLMhdwYmVazcGBpAIxgDS.get('programimage') !='':img_fanart =qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.HTTPTAG+qvFbHfCkKQLMhdwYmVazcGBpAIxgDS.get('programimage')
   if qvFbHfCkKQLMhdwYmVazcGBpAIxgDS.get('programcirlceimage')!='':qvFbHfCkKQLMhdwYmVazcGBpAIxgDT=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.HTTPTAG+qvFbHfCkKQLMhdwYmVazcGBpAIxgDS.get('programcirlceimage')
   if 'poster_default' in qvFbHfCkKQLMhdwYmVazcGBpAIxgDo:
    qvFbHfCkKQLMhdwYmVazcGBpAIxgDo =img_fanart
    qvFbHfCkKQLMhdwYmVazcGBpAIxgDT=''
   qvFbHfCkKQLMhdwYmVazcGBpAIxgDu={'imgPoster':qvFbHfCkKQLMhdwYmVazcGBpAIxgDo,'imgFanart':img_fanart,'imgClearlogo':qvFbHfCkKQLMhdwYmVazcGBpAIxgDT}
  except qvFbHfCkKQLMhdwYmVazcGBpAIxgRo as exception:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgRT(exception)
  return qvFbHfCkKQLMhdwYmVazcGBpAIxgDu
 def Get_Episode_List(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD,qvFbHfCkKQLMhdwYmVazcGBpAIxgPX,qvFbHfCkKQLMhdwYmVazcGBpAIxgPU,page_int=1,orderby='desc'):
  qvFbHfCkKQLMhdwYmVazcGBpAIxgDO=[]
  qvFbHfCkKQLMhdwYmVazcGBpAIxgPy=qvFbHfCkKQLMhdwYmVazcGBpAIxgPJ=1
  qvFbHfCkKQLMhdwYmVazcGBpAIxgPW=qvFbHfCkKQLMhdwYmVazcGBpAIxgRi
  qvFbHfCkKQLMhdwYmVazcGBpAIxgDe={}
  if qvFbHfCkKQLMhdwYmVazcGBpAIxgPU=='contentid':
   qvFbHfCkKQLMhdwYmVazcGBpAIxgDN=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.ContentidToProgramid(qvFbHfCkKQLMhdwYmVazcGBpAIxgPX)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgDe=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.GetProgramInfo(qvFbHfCkKQLMhdwYmVazcGBpAIxgPX)
  else:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgDN=qvFbHfCkKQLMhdwYmVazcGBpAIxgPX
   qvFbHfCkKQLMhdwYmVazcGBpAIxgDi=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.ProgramidToContentid(qvFbHfCkKQLMhdwYmVazcGBpAIxgPX)
   if qvFbHfCkKQLMhdwYmVazcGBpAIxgDi!='':qvFbHfCkKQLMhdwYmVazcGBpAIxgDe=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.GetProgramInfo(qvFbHfCkKQLMhdwYmVazcGBpAIxgDi)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrW=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.API_DOMAIN+'/vod/programs-contents/'+qvFbHfCkKQLMhdwYmVazcGBpAIxgDN
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS={}
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS['limit'] =qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.EP_LIMIT
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS['offset']=qvFbHfCkKQLMhdwYmVazcGBpAIxgRu((page_int-1)*qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.EP_LIMIT)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS['orderby']=orderby 
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS.update(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.GetDefaultParams(login=qvFbHfCkKQLMhdwYmVazcGBpAIxgRi))
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrj=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.callRequestCookies('Get',qvFbHfCkKQLMhdwYmVazcGBpAIxgrW,payload=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,params=qvFbHfCkKQLMhdwYmVazcGBpAIxgrS,headers=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,cookies=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrU=json.loads(qvFbHfCkKQLMhdwYmVazcGBpAIxgrj.text)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgPN=qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['list']
   for qvFbHfCkKQLMhdwYmVazcGBpAIxgPu in qvFbHfCkKQLMhdwYmVazcGBpAIxgPN:
    qvFbHfCkKQLMhdwYmVazcGBpAIxgDt=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',qvFbHfCkKQLMhdwYmVazcGBpAIxgPu.get('synopsis'))
    qvFbHfCkKQLMhdwYmVazcGBpAIxgDs=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.HTTPTAG+qvFbHfCkKQLMhdwYmVazcGBpAIxgPu.get('image')
    qvFbHfCkKQLMhdwYmVazcGBpAIxgDy=qvFbHfCkKQLMhdwYmVazcGBpAIxgDW=qvFbHfCkKQLMhdwYmVazcGBpAIxgDE=''
    if qvFbHfCkKQLMhdwYmVazcGBpAIxgDe!={}:
     qvFbHfCkKQLMhdwYmVazcGBpAIxgDy =qvFbHfCkKQLMhdwYmVazcGBpAIxgDe.get('imgPoster')
     qvFbHfCkKQLMhdwYmVazcGBpAIxgDW =qvFbHfCkKQLMhdwYmVazcGBpAIxgDe.get('imgFanart')
     qvFbHfCkKQLMhdwYmVazcGBpAIxgDE=qvFbHfCkKQLMhdwYmVazcGBpAIxgDe.get('imgClearlogo')
     qvFbHfCkKQLMhdwYmVazcGBpAIxgDj={'thumb':qvFbHfCkKQLMhdwYmVazcGBpAIxgDs,'poster':qvFbHfCkKQLMhdwYmVazcGBpAIxgDy,'fanart':qvFbHfCkKQLMhdwYmVazcGBpAIxgDW,'clearlogo':qvFbHfCkKQLMhdwYmVazcGBpAIxgDE}
    else:
     qvFbHfCkKQLMhdwYmVazcGBpAIxgDj=qvFbHfCkKQLMhdwYmVazcGBpAIxgDs
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPo={'programtitle':qvFbHfCkKQLMhdwYmVazcGBpAIxgPu.get('programtitle'),'episodetitle':qvFbHfCkKQLMhdwYmVazcGBpAIxgPu.get('episodetitle'),'episodenumber':qvFbHfCkKQLMhdwYmVazcGBpAIxgPu.get('episodenumber'),'releasedate':qvFbHfCkKQLMhdwYmVazcGBpAIxgPu.get('releasedate'),'releaseweekday':qvFbHfCkKQLMhdwYmVazcGBpAIxgPu.get('releaseweekday'),'programid':qvFbHfCkKQLMhdwYmVazcGBpAIxgPu.get('programid'),'contentid':qvFbHfCkKQLMhdwYmVazcGBpAIxgPu.get('contentid'),'age':qvFbHfCkKQLMhdwYmVazcGBpAIxgPu.get('targetage'),'playtime':qvFbHfCkKQLMhdwYmVazcGBpAIxgPu.get('playtime'),'synopsis':qvFbHfCkKQLMhdwYmVazcGBpAIxgDt,'episodeactors':qvFbHfCkKQLMhdwYmVazcGBpAIxgPu.get('episodeactors').split(',')if qvFbHfCkKQLMhdwYmVazcGBpAIxgPu.get('episodeactors')!='' else[],'thumbnail':qvFbHfCkKQLMhdwYmVazcGBpAIxgDj}
    qvFbHfCkKQLMhdwYmVazcGBpAIxgDO.append(qvFbHfCkKQLMhdwYmVazcGBpAIxgPo)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgPy=qvFbHfCkKQLMhdwYmVazcGBpAIxgRe(qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['pagecount'])
   if qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['count']:qvFbHfCkKQLMhdwYmVazcGBpAIxgPJ =qvFbHfCkKQLMhdwYmVazcGBpAIxgRe(qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['count'])
   else:qvFbHfCkKQLMhdwYmVazcGBpAIxgPJ=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.EP_LIMIT*page_int
   qvFbHfCkKQLMhdwYmVazcGBpAIxgPW=qvFbHfCkKQLMhdwYmVazcGBpAIxgPy>qvFbHfCkKQLMhdwYmVazcGBpAIxgPJ
  except qvFbHfCkKQLMhdwYmVazcGBpAIxgRo as exception:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgRT(exception)
   return[],qvFbHfCkKQLMhdwYmVazcGBpAIxgRi
  return qvFbHfCkKQLMhdwYmVazcGBpAIxgDO,qvFbHfCkKQLMhdwYmVazcGBpAIxgPW
 def GetEPGList(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD,genre):
  qvFbHfCkKQLMhdwYmVazcGBpAIxgDU={}
  try:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgDX=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.Get_Now_Datetime()
   if genre=='all':
    qvFbHfCkKQLMhdwYmVazcGBpAIxgDJ =qvFbHfCkKQLMhdwYmVazcGBpAIxgDX+datetime.timedelta(hours=3)
   else:
    qvFbHfCkKQLMhdwYmVazcGBpAIxgDJ =qvFbHfCkKQLMhdwYmVazcGBpAIxgDX+datetime.timedelta(hours=3)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrW=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.API_DOMAIN+'/live/epgs'
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS={'limit':'100','offset':'0','genre':genre,'startdatetime':qvFbHfCkKQLMhdwYmVazcGBpAIxgDX.strftime('%Y-%m-%d %H:00'),'enddatetime':qvFbHfCkKQLMhdwYmVazcGBpAIxgDJ.strftime('%Y-%m-%d %H:00')}
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS.update(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.GetDefaultParams(login=qvFbHfCkKQLMhdwYmVazcGBpAIxgRi))
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrj=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.callRequestCookies('Get',qvFbHfCkKQLMhdwYmVazcGBpAIxgrW,payload=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,params=qvFbHfCkKQLMhdwYmVazcGBpAIxgrS,headers=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,cookies=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrU=json.loads(qvFbHfCkKQLMhdwYmVazcGBpAIxgrj.text)
   qvFbHfCkKQLMhdwYmVazcGBpAIxglr=qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['list']
   for qvFbHfCkKQLMhdwYmVazcGBpAIxgPu in qvFbHfCkKQLMhdwYmVazcGBpAIxglr:
    qvFbHfCkKQLMhdwYmVazcGBpAIxglP=''
    for qvFbHfCkKQLMhdwYmVazcGBpAIxglD in qvFbHfCkKQLMhdwYmVazcGBpAIxgPu['list']:
     if qvFbHfCkKQLMhdwYmVazcGBpAIxglP:qvFbHfCkKQLMhdwYmVazcGBpAIxglP+='\n'
     qvFbHfCkKQLMhdwYmVazcGBpAIxglP+=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.Get_ChangeText(qvFbHfCkKQLMhdwYmVazcGBpAIxglD['title'])+'\n'
     qvFbHfCkKQLMhdwYmVazcGBpAIxglP+=' [%s ~ %s]'%(qvFbHfCkKQLMhdwYmVazcGBpAIxglD['starttime'][-5:],qvFbHfCkKQLMhdwYmVazcGBpAIxglD['endtime'][-5:])+'\n'
    qvFbHfCkKQLMhdwYmVazcGBpAIxgDU[qvFbHfCkKQLMhdwYmVazcGBpAIxgPu['channelid']]=qvFbHfCkKQLMhdwYmVazcGBpAIxglP
  except qvFbHfCkKQLMhdwYmVazcGBpAIxgRo as exception:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgRT(exception)
  return qvFbHfCkKQLMhdwYmVazcGBpAIxgDU
 def Get_LiveChannel_List(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD,genre,qvFbHfCkKQLMhdwYmVazcGBpAIxgPi):
  qvFbHfCkKQLMhdwYmVazcGBpAIxgPs=[]
  (qvFbHfCkKQLMhdwYmVazcGBpAIxgrW,qvFbHfCkKQLMhdwYmVazcGBpAIxgrS)=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.Baseapi_Parse(qvFbHfCkKQLMhdwYmVazcGBpAIxgPi)
  if qvFbHfCkKQLMhdwYmVazcGBpAIxgrW=='':return qvFbHfCkKQLMhdwYmVazcGBpAIxgPs
  qvFbHfCkKQLMhdwYmVazcGBpAIxglR=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.GetEPGList(genre)
  try:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS.update(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.GetDefaultParams(login=qvFbHfCkKQLMhdwYmVazcGBpAIxgRi))
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS['genre']=genre
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrj=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.callRequestCookies('Get',qvFbHfCkKQLMhdwYmVazcGBpAIxgrW,payload=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,params=qvFbHfCkKQLMhdwYmVazcGBpAIxgrS,headers=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,cookies=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrU=json.loads(qvFbHfCkKQLMhdwYmVazcGBpAIxgrj.text)
   if not('celllist' in qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['cell_toplist']):return[]
   qvFbHfCkKQLMhdwYmVazcGBpAIxgPN=qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['cell_toplist']['celllist']
   for qvFbHfCkKQLMhdwYmVazcGBpAIxgPu in qvFbHfCkKQLMhdwYmVazcGBpAIxgPN:
    qvFbHfCkKQLMhdwYmVazcGBpAIxgDi=qvFbHfCkKQLMhdwYmVazcGBpAIxgPu['contentid']
    if qvFbHfCkKQLMhdwYmVazcGBpAIxgDi in qvFbHfCkKQLMhdwYmVazcGBpAIxglR:
     qvFbHfCkKQLMhdwYmVazcGBpAIxgli=qvFbHfCkKQLMhdwYmVazcGBpAIxglR[qvFbHfCkKQLMhdwYmVazcGBpAIxgDi]
    else:
     qvFbHfCkKQLMhdwYmVazcGBpAIxgli=''
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPo={'studio':qvFbHfCkKQLMhdwYmVazcGBpAIxgPu['title_list'][0]['text'],'tvshowtitle':qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.Get_ChangeText(qvFbHfCkKQLMhdwYmVazcGBpAIxgPu['title_list'][1]['text']),'channelid':qvFbHfCkKQLMhdwYmVazcGBpAIxgDi,'age':qvFbHfCkKQLMhdwYmVazcGBpAIxgPu['age'],'thumbnail':'https://%s'%qvFbHfCkKQLMhdwYmVazcGBpAIxgPu.get('thumbnail'),'epg':qvFbHfCkKQLMhdwYmVazcGBpAIxgli}
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPs.append(qvFbHfCkKQLMhdwYmVazcGBpAIxgPo)
  except qvFbHfCkKQLMhdwYmVazcGBpAIxgRo as exception:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgRT(exception)
   return[]
  return qvFbHfCkKQLMhdwYmVazcGBpAIxgPs
 def Get_Search_List(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD,search_key,sType,page_int,exclusion21=qvFbHfCkKQLMhdwYmVazcGBpAIxgRi):
  qvFbHfCkKQLMhdwYmVazcGBpAIxglS=[]
  qvFbHfCkKQLMhdwYmVazcGBpAIxgPy=qvFbHfCkKQLMhdwYmVazcGBpAIxgPJ=1
  qvFbHfCkKQLMhdwYmVazcGBpAIxgPW=qvFbHfCkKQLMhdwYmVazcGBpAIxgRi
  try:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrW=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.API_DOMAIN+'/cf/search/list.js'
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':qvFbHfCkKQLMhdwYmVazcGBpAIxgRu((page_int-1)*qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.SEARCH_LIMIT),'limit':qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.SEARCH_LIMIT,'orderby':'score'}
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS.update(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.GetDefaultParams(login=qvFbHfCkKQLMhdwYmVazcGBpAIxgRi))
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrj=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.callRequestCookies('Get',qvFbHfCkKQLMhdwYmVazcGBpAIxgrW,payload=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,params=qvFbHfCkKQLMhdwYmVazcGBpAIxgrS,headers=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,cookies=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgDS=json.loads(qvFbHfCkKQLMhdwYmVazcGBpAIxgrj.text)
   if not('celllist' in qvFbHfCkKQLMhdwYmVazcGBpAIxgDS['cell_toplist']):return qvFbHfCkKQLMhdwYmVazcGBpAIxglS,qvFbHfCkKQLMhdwYmVazcGBpAIxgPW
   qvFbHfCkKQLMhdwYmVazcGBpAIxgPN=qvFbHfCkKQLMhdwYmVazcGBpAIxgDS['cell_toplist']['celllist']
   for qvFbHfCkKQLMhdwYmVazcGBpAIxgPu in qvFbHfCkKQLMhdwYmVazcGBpAIxgPN:
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPE =qvFbHfCkKQLMhdwYmVazcGBpAIxgPu['event_list'][1]['url']
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPj=urllib.parse.urlsplit(qvFbHfCkKQLMhdwYmVazcGBpAIxgPE).query
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPU=qvFbHfCkKQLMhdwYmVazcGBpAIxgPj[0:qvFbHfCkKQLMhdwYmVazcGBpAIxgPj.find('=')]
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPX=qvFbHfCkKQLMhdwYmVazcGBpAIxgPj[qvFbHfCkKQLMhdwYmVazcGBpAIxgPj.find('=')+1:]
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPo={'title':qvFbHfCkKQLMhdwYmVazcGBpAIxgPu['title_list'][0]['text'],'age':qvFbHfCkKQLMhdwYmVazcGBpAIxgPu['age'],'thumbnail':'https://%s'%qvFbHfCkKQLMhdwYmVazcGBpAIxgPu.get('thumbnail'),'videoid':qvFbHfCkKQLMhdwYmVazcGBpAIxgPX,'vidtype':qvFbHfCkKQLMhdwYmVazcGBpAIxgPU}
    if exclusion21==qvFbHfCkKQLMhdwYmVazcGBpAIxgRi or qvFbHfCkKQLMhdwYmVazcGBpAIxgPu.get('age')!='21':
     qvFbHfCkKQLMhdwYmVazcGBpAIxglS.append(qvFbHfCkKQLMhdwYmVazcGBpAIxgPo)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgPy=qvFbHfCkKQLMhdwYmVazcGBpAIxgRe(qvFbHfCkKQLMhdwYmVazcGBpAIxgDS['cell_toplist']['pagecount'])
   if qvFbHfCkKQLMhdwYmVazcGBpAIxgDS['cell_toplist']['count']:qvFbHfCkKQLMhdwYmVazcGBpAIxgPJ =qvFbHfCkKQLMhdwYmVazcGBpAIxgRe(qvFbHfCkKQLMhdwYmVazcGBpAIxgDS['cell_toplist']['count'])
   else:qvFbHfCkKQLMhdwYmVazcGBpAIxgPJ=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.LIST_LIMIT
   qvFbHfCkKQLMhdwYmVazcGBpAIxgPW=qvFbHfCkKQLMhdwYmVazcGBpAIxgPy>qvFbHfCkKQLMhdwYmVazcGBpAIxgPJ
  except qvFbHfCkKQLMhdwYmVazcGBpAIxgRo as exception:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgRT(exception)
  return qvFbHfCkKQLMhdwYmVazcGBpAIxglS,qvFbHfCkKQLMhdwYmVazcGBpAIxgPW 
 def GetStreamingURL(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD,mode,qvFbHfCkKQLMhdwYmVazcGBpAIxgDi,quality_int,pvrmode='-'):
  qvFbHfCkKQLMhdwYmVazcGBpAIxglN=qvFbHfCkKQLMhdwYmVazcGBpAIxgls=qvFbHfCkKQLMhdwYmVazcGBpAIxgly=streaming_preview=''
  qvFbHfCkKQLMhdwYmVazcGBpAIxglu=[]
  qvFbHfCkKQLMhdwYmVazcGBpAIxglo='hls'
  if mode=='LIVE':
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrW =qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.API_DOMAIN+'/live/channels/'+qvFbHfCkKQLMhdwYmVazcGBpAIxgDi
   qvFbHfCkKQLMhdwYmVazcGBpAIxglT='live'
  elif mode=='VOD':
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrW =qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.API_DOMAIN+'/cf/vod/contents/'+qvFbHfCkKQLMhdwYmVazcGBpAIxgDi
   qvFbHfCkKQLMhdwYmVazcGBpAIxglT='vod'
  elif mode=='MOVIE':
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrW =qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.API_DOMAIN+'/cf/movie/contents/'+qvFbHfCkKQLMhdwYmVazcGBpAIxgDi
   qvFbHfCkKQLMhdwYmVazcGBpAIxglT='movie'
  try:
   if mode!='LIVE' or pvrmode=='-':
    qvFbHfCkKQLMhdwYmVazcGBpAIxgrS=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.GetDefaultParams(login=qvFbHfCkKQLMhdwYmVazcGBpAIxgRi)
    qvFbHfCkKQLMhdwYmVazcGBpAIxgrj=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.callRequestCookies('Get',qvFbHfCkKQLMhdwYmVazcGBpAIxgrW,payload=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,params=qvFbHfCkKQLMhdwYmVazcGBpAIxgrS,headers=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,cookies=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl)
    qvFbHfCkKQLMhdwYmVazcGBpAIxgrU=json.loads(qvFbHfCkKQLMhdwYmVazcGBpAIxgrj.text)
    qvFbHfCkKQLMhdwYmVazcGBpAIxglO=qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['qualities']['list']
    if qvFbHfCkKQLMhdwYmVazcGBpAIxglO==qvFbHfCkKQLMhdwYmVazcGBpAIxgRl:return(qvFbHfCkKQLMhdwYmVazcGBpAIxglN,qvFbHfCkKQLMhdwYmVazcGBpAIxgls,qvFbHfCkKQLMhdwYmVazcGBpAIxgly,streaming_preview)
    for qvFbHfCkKQLMhdwYmVazcGBpAIxgle in qvFbHfCkKQLMhdwYmVazcGBpAIxglO:
     qvFbHfCkKQLMhdwYmVazcGBpAIxglu.append(qvFbHfCkKQLMhdwYmVazcGBpAIxgRe(qvFbHfCkKQLMhdwYmVazcGBpAIxgle.get('id').rstrip('p')))
    if 'type' in qvFbHfCkKQLMhdwYmVazcGBpAIxgrU:
     if qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['type']=='onair':
      qvFbHfCkKQLMhdwYmVazcGBpAIxglT='onairvod'
    if 'drms' in qvFbHfCkKQLMhdwYmVazcGBpAIxgrU:
     if qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['drms']:
      qvFbHfCkKQLMhdwYmVazcGBpAIxglo='dash'
  except qvFbHfCkKQLMhdwYmVazcGBpAIxgRo as exception:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgRT(exception)
   return(qvFbHfCkKQLMhdwYmVazcGBpAIxglN,qvFbHfCkKQLMhdwYmVazcGBpAIxgls,qvFbHfCkKQLMhdwYmVazcGBpAIxgly,streaming_preview)
  try:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgln=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.CheckQuality(quality_int,qvFbHfCkKQLMhdwYmVazcGBpAIxglu)
   if mode=='LIVE' and pvrmode!='-':
    qvFbHfCkKQLMhdwYmVazcGBpAIxglt='auto'
   else:
    qvFbHfCkKQLMhdwYmVazcGBpAIxglt=qvFbHfCkKQLMhdwYmVazcGBpAIxgRu(qvFbHfCkKQLMhdwYmVazcGBpAIxgln)+'p'
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrW=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.API_DOMAIN+'/streaming'
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS={'contentid':qvFbHfCkKQLMhdwYmVazcGBpAIxgDi,'contenttype':qvFbHfCkKQLMhdwYmVazcGBpAIxglT,'action':qvFbHfCkKQLMhdwYmVazcGBpAIxglo,'quality':qvFbHfCkKQLMhdwYmVazcGBpAIxglt,'deviceModelId':'Windows 10','guid':qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.GetGUID(guidType=2),'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n'}
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS.update(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.GetDefaultParams(login=qvFbHfCkKQLMhdwYmVazcGBpAIxgRS))
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrj=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.callRequestCookies('Get',qvFbHfCkKQLMhdwYmVazcGBpAIxgrW,payload=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,params=qvFbHfCkKQLMhdwYmVazcGBpAIxgrS,headers=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,cookies=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrU=json.loads(qvFbHfCkKQLMhdwYmVazcGBpAIxgrj.text)
   qvFbHfCkKQLMhdwYmVazcGBpAIxglN=qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['playurl']
   if qvFbHfCkKQLMhdwYmVazcGBpAIxglN==qvFbHfCkKQLMhdwYmVazcGBpAIxgRl:return(qvFbHfCkKQLMhdwYmVazcGBpAIxglN,qvFbHfCkKQLMhdwYmVazcGBpAIxgls,qvFbHfCkKQLMhdwYmVazcGBpAIxgly,streaming_preview)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgls=qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['awscookie']
   qvFbHfCkKQLMhdwYmVazcGBpAIxgly =qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['drm']
   if 'previewmsg' in qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['preview']:streaming_preview=qvFbHfCkKQLMhdwYmVazcGBpAIxgrU['preview']['previewmsg']
  except qvFbHfCkKQLMhdwYmVazcGBpAIxgRo as exception:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgRT(exception)
  return(qvFbHfCkKQLMhdwYmVazcGBpAIxglN,qvFbHfCkKQLMhdwYmVazcGBpAIxgls,qvFbHfCkKQLMhdwYmVazcGBpAIxgly,streaming_preview) 
 def GetBookmarkInfo(qvFbHfCkKQLMhdwYmVazcGBpAIxgrD,qvFbHfCkKQLMhdwYmVazcGBpAIxgPX,qvFbHfCkKQLMhdwYmVazcGBpAIxgPU,qvFbHfCkKQLMhdwYmVazcGBpAIxglT):
  if qvFbHfCkKQLMhdwYmVazcGBpAIxgPU=='tvshow':
   if qvFbHfCkKQLMhdwYmVazcGBpAIxglT=='contentid':
    qvFbHfCkKQLMhdwYmVazcGBpAIxgDi=qvFbHfCkKQLMhdwYmVazcGBpAIxgPX
    qvFbHfCkKQLMhdwYmVazcGBpAIxgPX =qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.ContentidToProgramid(qvFbHfCkKQLMhdwYmVazcGBpAIxgDi)
   else:
    qvFbHfCkKQLMhdwYmVazcGBpAIxgDi=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.ProgramidToContentid(qvFbHfCkKQLMhdwYmVazcGBpAIxgPX)
  else:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgDi=''
  qvFbHfCkKQLMhdwYmVazcGBpAIxglW={'indexinfo':{'ott':'wavve','videoid':qvFbHfCkKQLMhdwYmVazcGBpAIxgPX,'vidtype':qvFbHfCkKQLMhdwYmVazcGBpAIxgPU,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':qvFbHfCkKQLMhdwYmVazcGBpAIxgPU,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if qvFbHfCkKQLMhdwYmVazcGBpAIxgPU=='tvshow':
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrW=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.API_DOMAIN+'/cf/vod/contents/'+qvFbHfCkKQLMhdwYmVazcGBpAIxgDi 
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.GetDefaultParams(login=qvFbHfCkKQLMhdwYmVazcGBpAIxgRi)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrj=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.callRequestCookies('Get',qvFbHfCkKQLMhdwYmVazcGBpAIxgrW,payload=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,params=qvFbHfCkKQLMhdwYmVazcGBpAIxgrS,headers=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,cookies=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrU=json.loads(qvFbHfCkKQLMhdwYmVazcGBpAIxgrj.text)
   if not('programtitle' in qvFbHfCkKQLMhdwYmVazcGBpAIxgrU):return{}
   qvFbHfCkKQLMhdwYmVazcGBpAIxglE=qvFbHfCkKQLMhdwYmVazcGBpAIxgrU
   qvFbHfCkKQLMhdwYmVazcGBpAIxglj=qvFbHfCkKQLMhdwYmVazcGBpAIxglE.get('programtitle')
   qvFbHfCkKQLMhdwYmVazcGBpAIxglW['saveinfo']['infoLabels']['title']=qvFbHfCkKQLMhdwYmVazcGBpAIxglj
   if qvFbHfCkKQLMhdwYmVazcGBpAIxglE.get('targetage')=='18' or qvFbHfCkKQLMhdwYmVazcGBpAIxglE.get('targetage')=='19' or qvFbHfCkKQLMhdwYmVazcGBpAIxglE.get('targetage')=='21':
    qvFbHfCkKQLMhdwYmVazcGBpAIxglj +=u' (%s)'%(qvFbHfCkKQLMhdwYmVazcGBpAIxglE.get('targetage'))
   qvFbHfCkKQLMhdwYmVazcGBpAIxglW['saveinfo']['title'] =qvFbHfCkKQLMhdwYmVazcGBpAIxglj
   qvFbHfCkKQLMhdwYmVazcGBpAIxglW['saveinfo']['infoLabels']['mpaa'] =qvFbHfCkKQLMhdwYmVazcGBpAIxglE.get('targetage')
   qvFbHfCkKQLMhdwYmVazcGBpAIxglW['saveinfo']['infoLabels']['plot'] =qvFbHfCkKQLMhdwYmVazcGBpAIxglE.get('programsynopsis').replace('<br>','\n')
   qvFbHfCkKQLMhdwYmVazcGBpAIxglW['saveinfo']['infoLabels']['studio'] =qvFbHfCkKQLMhdwYmVazcGBpAIxglE.get('channelname')
   if qvFbHfCkKQLMhdwYmVazcGBpAIxglE.get('firstreleaseyear')!='':qvFbHfCkKQLMhdwYmVazcGBpAIxglW['saveinfo']['infoLabels']['year'] =qvFbHfCkKQLMhdwYmVazcGBpAIxglE.get('firstreleaseyear')
   if qvFbHfCkKQLMhdwYmVazcGBpAIxglE.get('firstreleasedate')!='':qvFbHfCkKQLMhdwYmVazcGBpAIxglW['saveinfo']['infoLabels']['premiered']=qvFbHfCkKQLMhdwYmVazcGBpAIxglE.get('firstreleasedate')
   if qvFbHfCkKQLMhdwYmVazcGBpAIxglE.get('genretext') !='':qvFbHfCkKQLMhdwYmVazcGBpAIxglW['saveinfo']['infoLabels']['genre'] =[qvFbHfCkKQLMhdwYmVazcGBpAIxglE.get('genretext')]
   qvFbHfCkKQLMhdwYmVazcGBpAIxglU=[]
   for qvFbHfCkKQLMhdwYmVazcGBpAIxglX in qvFbHfCkKQLMhdwYmVazcGBpAIxglE['actors']['list']:qvFbHfCkKQLMhdwYmVazcGBpAIxglU.append(qvFbHfCkKQLMhdwYmVazcGBpAIxglX.get('text'))
   if qvFbHfCkKQLMhdwYmVazcGBpAIxgRn(qvFbHfCkKQLMhdwYmVazcGBpAIxglU)>0:
    if qvFbHfCkKQLMhdwYmVazcGBpAIxglU[0]!='':qvFbHfCkKQLMhdwYmVazcGBpAIxglW['saveinfo']['infoLabels']['cast']=qvFbHfCkKQLMhdwYmVazcGBpAIxglU
   qvFbHfCkKQLMhdwYmVazcGBpAIxgDy =''
   qvFbHfCkKQLMhdwYmVazcGBpAIxgDW =''
   qvFbHfCkKQLMhdwYmVazcGBpAIxgDE=''
   if qvFbHfCkKQLMhdwYmVazcGBpAIxglE.get('programposterimage')!='':qvFbHfCkKQLMhdwYmVazcGBpAIxgDy =qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.HTTPTAG+qvFbHfCkKQLMhdwYmVazcGBpAIxglE.get('programposterimage')
   if qvFbHfCkKQLMhdwYmVazcGBpAIxglE.get('programimage') !='':qvFbHfCkKQLMhdwYmVazcGBpAIxgDW =qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.HTTPTAG+qvFbHfCkKQLMhdwYmVazcGBpAIxglE.get('programimage')
   if qvFbHfCkKQLMhdwYmVazcGBpAIxglE.get('programcirlceimage')!='':qvFbHfCkKQLMhdwYmVazcGBpAIxgDE=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.HTTPTAG+qvFbHfCkKQLMhdwYmVazcGBpAIxglE.get('programcirlceimage')
   if 'poster_default' in qvFbHfCkKQLMhdwYmVazcGBpAIxgDy:
    qvFbHfCkKQLMhdwYmVazcGBpAIxgDy =qvFbHfCkKQLMhdwYmVazcGBpAIxgDW
    qvFbHfCkKQLMhdwYmVazcGBpAIxgDE=''
   qvFbHfCkKQLMhdwYmVazcGBpAIxglW['saveinfo']['thumbnail']['poster']=qvFbHfCkKQLMhdwYmVazcGBpAIxgDy
   qvFbHfCkKQLMhdwYmVazcGBpAIxglW['saveinfo']['thumbnail']['thumb']=qvFbHfCkKQLMhdwYmVazcGBpAIxgDW
   qvFbHfCkKQLMhdwYmVazcGBpAIxglW['saveinfo']['thumbnail']['clearlogo']=qvFbHfCkKQLMhdwYmVazcGBpAIxgDE
   qvFbHfCkKQLMhdwYmVazcGBpAIxglW['saveinfo']['thumbnail']['fanart']=qvFbHfCkKQLMhdwYmVazcGBpAIxgDW
  else:
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrW=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.API_DOMAIN+'/movie/contents/'+qvFbHfCkKQLMhdwYmVazcGBpAIxgPX 
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrS=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.GetDefaultParams(login=qvFbHfCkKQLMhdwYmVazcGBpAIxgRi)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrj=qvFbHfCkKQLMhdwYmVazcGBpAIxgrD.callRequestCookies('Get',qvFbHfCkKQLMhdwYmVazcGBpAIxgrW,payload=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,params=qvFbHfCkKQLMhdwYmVazcGBpAIxgrS,headers=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl,cookies=qvFbHfCkKQLMhdwYmVazcGBpAIxgRl)
   qvFbHfCkKQLMhdwYmVazcGBpAIxgrU=json.loads(qvFbHfCkKQLMhdwYmVazcGBpAIxgrj.text)
   if not('title' in qvFbHfCkKQLMhdwYmVazcGBpAIxgrU):return{}
   qvFbHfCkKQLMhdwYmVazcGBpAIxglE=qvFbHfCkKQLMhdwYmVazcGBpAIxgrU
   qvFbHfCkKQLMhdwYmVazcGBpAIxglj=qvFbHfCkKQLMhdwYmVazcGBpAIxglE.get('title')
   qvFbHfCkKQLMhdwYmVazcGBpAIxglW['saveinfo']['infoLabels']['title']=qvFbHfCkKQLMhdwYmVazcGBpAIxglj
   if qvFbHfCkKQLMhdwYmVazcGBpAIxglE.get('targetage')=='18' or qvFbHfCkKQLMhdwYmVazcGBpAIxglE.get('targetage')=='19' or qvFbHfCkKQLMhdwYmVazcGBpAIxglE.get('targetage')=='21':
    qvFbHfCkKQLMhdwYmVazcGBpAIxglj +=u' (%s)'%(qvFbHfCkKQLMhdwYmVazcGBpAIxglE.get('targetage'))
   qvFbHfCkKQLMhdwYmVazcGBpAIxglW['saveinfo']['title'] =qvFbHfCkKQLMhdwYmVazcGBpAIxglj
   qvFbHfCkKQLMhdwYmVazcGBpAIxglW['saveinfo']['infoLabels']['mpaa'] =qvFbHfCkKQLMhdwYmVazcGBpAIxglE.get('targetage')
   qvFbHfCkKQLMhdwYmVazcGBpAIxglW['saveinfo']['infoLabels']['plot'] =qvFbHfCkKQLMhdwYmVazcGBpAIxglE.get('synopsis').replace('<br>','\n')
   qvFbHfCkKQLMhdwYmVazcGBpAIxglW['saveinfo']['infoLabels']['duration']=qvFbHfCkKQLMhdwYmVazcGBpAIxglE.get('playtime')
   qvFbHfCkKQLMhdwYmVazcGBpAIxglW['saveinfo']['infoLabels']['country']=qvFbHfCkKQLMhdwYmVazcGBpAIxglE.get('country')
   qvFbHfCkKQLMhdwYmVazcGBpAIxglW['saveinfo']['infoLabels']['studio'] =qvFbHfCkKQLMhdwYmVazcGBpAIxglE.get('cpname')
   if qvFbHfCkKQLMhdwYmVazcGBpAIxglE.get('releasedate')!='':
    qvFbHfCkKQLMhdwYmVazcGBpAIxglW['saveinfo']['infoLabels']['year'] =qvFbHfCkKQLMhdwYmVazcGBpAIxglE.get('releasedate')[:4]
    qvFbHfCkKQLMhdwYmVazcGBpAIxglW['saveinfo']['infoLabels']['premiered']=qvFbHfCkKQLMhdwYmVazcGBpAIxglE.get('releasedate')
   qvFbHfCkKQLMhdwYmVazcGBpAIxglU=[]
   for qvFbHfCkKQLMhdwYmVazcGBpAIxglX in qvFbHfCkKQLMhdwYmVazcGBpAIxglE['actors']['list']:qvFbHfCkKQLMhdwYmVazcGBpAIxglU.append(qvFbHfCkKQLMhdwYmVazcGBpAIxglX.get('text'))
   if qvFbHfCkKQLMhdwYmVazcGBpAIxgRn(qvFbHfCkKQLMhdwYmVazcGBpAIxglU)>0:
    if qvFbHfCkKQLMhdwYmVazcGBpAIxglU[0]!='':qvFbHfCkKQLMhdwYmVazcGBpAIxglW['saveinfo']['infoLabels']['cast']=qvFbHfCkKQLMhdwYmVazcGBpAIxglU
   qvFbHfCkKQLMhdwYmVazcGBpAIxglJ=[]
   for qvFbHfCkKQLMhdwYmVazcGBpAIxgRr in qvFbHfCkKQLMhdwYmVazcGBpAIxglE['directors']['list']:qvFbHfCkKQLMhdwYmVazcGBpAIxglJ.append(qvFbHfCkKQLMhdwYmVazcGBpAIxgRr.get('text'))
   if qvFbHfCkKQLMhdwYmVazcGBpAIxgRn(qvFbHfCkKQLMhdwYmVazcGBpAIxglJ)>0:
    if qvFbHfCkKQLMhdwYmVazcGBpAIxglJ[0]!='':qvFbHfCkKQLMhdwYmVazcGBpAIxglW['saveinfo']['infoLabels']['director']=qvFbHfCkKQLMhdwYmVazcGBpAIxglJ
   qvFbHfCkKQLMhdwYmVazcGBpAIxgPR=[]
   for qvFbHfCkKQLMhdwYmVazcGBpAIxgRP in qvFbHfCkKQLMhdwYmVazcGBpAIxglE['genre']['list']:qvFbHfCkKQLMhdwYmVazcGBpAIxgPR.append(qvFbHfCkKQLMhdwYmVazcGBpAIxgRP.get('text'))
   if qvFbHfCkKQLMhdwYmVazcGBpAIxgRn(qvFbHfCkKQLMhdwYmVazcGBpAIxgPR)>0:
    if qvFbHfCkKQLMhdwYmVazcGBpAIxgPR[0]!='':qvFbHfCkKQLMhdwYmVazcGBpAIxglW['saveinfo']['infoLabels']['genre']=qvFbHfCkKQLMhdwYmVazcGBpAIxgPR
   qvFbHfCkKQLMhdwYmVazcGBpAIxgDy ='https://%s'%qvFbHfCkKQLMhdwYmVazcGBpAIxglE['image']
   qvFbHfCkKQLMhdwYmVazcGBpAIxglW['saveinfo']['thumbnail']['poster'] =qvFbHfCkKQLMhdwYmVazcGBpAIxgDy
   qvFbHfCkKQLMhdwYmVazcGBpAIxglW['saveinfo']['thumbnail']['thumb'] =qvFbHfCkKQLMhdwYmVazcGBpAIxgDy
  return qvFbHfCkKQLMhdwYmVazcGBpAIxglW
# Created by pyminifier (https://github.com/liftoff/pyminifier)
