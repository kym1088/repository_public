__author__="NightRain"
OJcpkLfhyXrzneUaFbYSjxTomlMAwg=object
OJcpkLfhyXrzneUaFbYSjxTomlMAws=None
OJcpkLfhyXrzneUaFbYSjxTomlMAwC=True
OJcpkLfhyXrzneUaFbYSjxTomlMAwq=False
OJcpkLfhyXrzneUaFbYSjxTomlMAwv=int
OJcpkLfhyXrzneUaFbYSjxTomlMAwI=type
OJcpkLfhyXrzneUaFbYSjxTomlMAwV=dict
OJcpkLfhyXrzneUaFbYSjxTomlMAwR=len
OJcpkLfhyXrzneUaFbYSjxTomlMAwN=range
OJcpkLfhyXrzneUaFbYSjxTomlMAwH=str
OJcpkLfhyXrzneUaFbYSjxTomlMAwD=open
OJcpkLfhyXrzneUaFbYSjxTomlMAwG=Exception
OJcpkLfhyXrzneUaFbYSjxTomlMAwQ=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
OJcpkLfhyXrzneUaFbYSjxTomlMAEs=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://www.wavve.com/supermultisection/GN51','icon':'home.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&offset=0&limit=20&uicode=VN500','page':'1','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=01&WeekDay=all&uitype=VN4&uiparent=FN0&uirank=0&broadcastid=847243&uicode=VN4','page':'1','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=02&WeekDay=all&uitype=VN3&uiparent=FN0&uirank=0&broadcastid=783664&uicode=VN3','page':'1','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'1','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'paid','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'displaystart','ordernm':'업데이트순','icon':''},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'(웨이브) 검색','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'(웨이브) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
OJcpkLfhyXrzneUaFbYSjxTomlMAEC=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
OJcpkLfhyXrzneUaFbYSjxTomlMAEq=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
OJcpkLfhyXrzneUaFbYSjxTomlMAEv =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
OJcpkLfhyXrzneUaFbYSjxTomlMAEw=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_searched.txt'))
from wavveCore import*
class OJcpkLfhyXrzneUaFbYSjxTomlMAEg(OJcpkLfhyXrzneUaFbYSjxTomlMAwg):
 def __init__(OJcpkLfhyXrzneUaFbYSjxTomlMAEI,OJcpkLfhyXrzneUaFbYSjxTomlMAEV,OJcpkLfhyXrzneUaFbYSjxTomlMAER,OJcpkLfhyXrzneUaFbYSjxTomlMAEN):
  OJcpkLfhyXrzneUaFbYSjxTomlMAEI._addon_url =OJcpkLfhyXrzneUaFbYSjxTomlMAEV
  OJcpkLfhyXrzneUaFbYSjxTomlMAEI._addon_handle=OJcpkLfhyXrzneUaFbYSjxTomlMAER
  OJcpkLfhyXrzneUaFbYSjxTomlMAEI.main_params =OJcpkLfhyXrzneUaFbYSjxTomlMAEN
  OJcpkLfhyXrzneUaFbYSjxTomlMAEI.WavveObj =qvFbHfCkKQLMhdwYmVazcGBpAIxgrP() 
 def addon_noti(OJcpkLfhyXrzneUaFbYSjxTomlMAEI,sting):
  try:
   OJcpkLfhyXrzneUaFbYSjxTomlMAED=xbmcgui.Dialog()
   OJcpkLfhyXrzneUaFbYSjxTomlMAED.notification(__addonname__,sting)
  except:
   OJcpkLfhyXrzneUaFbYSjxTomlMAws
 def addon_log(OJcpkLfhyXrzneUaFbYSjxTomlMAEI,string):
  try:
   OJcpkLfhyXrzneUaFbYSjxTomlMAEG=string.encode('utf-8','ignore')
  except:
   OJcpkLfhyXrzneUaFbYSjxTomlMAEG='addonException: addon_log'
  OJcpkLfhyXrzneUaFbYSjxTomlMAEQ=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,OJcpkLfhyXrzneUaFbYSjxTomlMAEG),level=OJcpkLfhyXrzneUaFbYSjxTomlMAEQ)
 def get_keyboard_input(OJcpkLfhyXrzneUaFbYSjxTomlMAEI,OJcpkLfhyXrzneUaFbYSjxTomlMAgV):
  OJcpkLfhyXrzneUaFbYSjxTomlMAEd=OJcpkLfhyXrzneUaFbYSjxTomlMAws
  kb=xbmc.Keyboard()
  kb.setHeading(OJcpkLfhyXrzneUaFbYSjxTomlMAgV)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   OJcpkLfhyXrzneUaFbYSjxTomlMAEd=kb.getText()
  return OJcpkLfhyXrzneUaFbYSjxTomlMAEd
 def get_settings_login_info(OJcpkLfhyXrzneUaFbYSjxTomlMAEI):
  OJcpkLfhyXrzneUaFbYSjxTomlMAEt =__addon__.getSetting('id')
  OJcpkLfhyXrzneUaFbYSjxTomlMAEK =__addon__.getSetting('pw')
  OJcpkLfhyXrzneUaFbYSjxTomlMAEW=__addon__.getSetting('selected_profile')
  return(OJcpkLfhyXrzneUaFbYSjxTomlMAEt,OJcpkLfhyXrzneUaFbYSjxTomlMAEK,OJcpkLfhyXrzneUaFbYSjxTomlMAEW)
 def get_settings_totalsearch(OJcpkLfhyXrzneUaFbYSjxTomlMAEI):
  OJcpkLfhyXrzneUaFbYSjxTomlMAEi =OJcpkLfhyXrzneUaFbYSjxTomlMAwC if __addon__.getSetting('local_search')=='true' else OJcpkLfhyXrzneUaFbYSjxTomlMAwq
  OJcpkLfhyXrzneUaFbYSjxTomlMAEP=OJcpkLfhyXrzneUaFbYSjxTomlMAwC if __addon__.getSetting('local_history')=='true' else OJcpkLfhyXrzneUaFbYSjxTomlMAwq
  OJcpkLfhyXrzneUaFbYSjxTomlMAEu =OJcpkLfhyXrzneUaFbYSjxTomlMAwC if __addon__.getSetting('total_search')=='true' else OJcpkLfhyXrzneUaFbYSjxTomlMAwq
  OJcpkLfhyXrzneUaFbYSjxTomlMAEB=OJcpkLfhyXrzneUaFbYSjxTomlMAwC if __addon__.getSetting('total_history')=='true' else OJcpkLfhyXrzneUaFbYSjxTomlMAwq
  OJcpkLfhyXrzneUaFbYSjxTomlMAgE=OJcpkLfhyXrzneUaFbYSjxTomlMAwC if __addon__.getSetting('menu_bookmark')=='true' else OJcpkLfhyXrzneUaFbYSjxTomlMAwq
  return(OJcpkLfhyXrzneUaFbYSjxTomlMAEi,OJcpkLfhyXrzneUaFbYSjxTomlMAEP,OJcpkLfhyXrzneUaFbYSjxTomlMAEu,OJcpkLfhyXrzneUaFbYSjxTomlMAEB,OJcpkLfhyXrzneUaFbYSjxTomlMAgE)
 def get_settings_makebookmark(OJcpkLfhyXrzneUaFbYSjxTomlMAEI):
  return OJcpkLfhyXrzneUaFbYSjxTomlMAwC if __addon__.getSetting('make_bookmark')=='true' else OJcpkLfhyXrzneUaFbYSjxTomlMAwq
 def get_selQuality(OJcpkLfhyXrzneUaFbYSjxTomlMAEI):
  try:
   OJcpkLfhyXrzneUaFbYSjxTomlMAgs=[1080,720,480,360]
   OJcpkLfhyXrzneUaFbYSjxTomlMAgC=OJcpkLfhyXrzneUaFbYSjxTomlMAwv(__addon__.getSetting('selected_quality'))
   return OJcpkLfhyXrzneUaFbYSjxTomlMAgs[OJcpkLfhyXrzneUaFbYSjxTomlMAgC]
  except:
   OJcpkLfhyXrzneUaFbYSjxTomlMAws
  return 1080 
 def get_settings_exclusion21(OJcpkLfhyXrzneUaFbYSjxTomlMAEI):
  OJcpkLfhyXrzneUaFbYSjxTomlMAgq =__addon__.getSetting('exclusion21')
  if OJcpkLfhyXrzneUaFbYSjxTomlMAgq=='false':
   return OJcpkLfhyXrzneUaFbYSjxTomlMAwq
  else:
   return OJcpkLfhyXrzneUaFbYSjxTomlMAwC
 def get_settings_direct_replay(OJcpkLfhyXrzneUaFbYSjxTomlMAEI):
  OJcpkLfhyXrzneUaFbYSjxTomlMAgv=OJcpkLfhyXrzneUaFbYSjxTomlMAwv(__addon__.getSetting('direct_replay'))
  if OJcpkLfhyXrzneUaFbYSjxTomlMAgv==0:
   return OJcpkLfhyXrzneUaFbYSjxTomlMAwq
  else:
   return OJcpkLfhyXrzneUaFbYSjxTomlMAwC
 def set_winCredential(OJcpkLfhyXrzneUaFbYSjxTomlMAEI,credential):
  OJcpkLfhyXrzneUaFbYSjxTomlMAgw=xbmcgui.Window(10000)
  OJcpkLfhyXrzneUaFbYSjxTomlMAgw.setProperty('WAVVE_M_CREDENTIAL',credential)
  OJcpkLfhyXrzneUaFbYSjxTomlMAgw.setProperty('WAVVE_M_LOGINTIME',OJcpkLfhyXrzneUaFbYSjxTomlMAEI.WavveObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(OJcpkLfhyXrzneUaFbYSjxTomlMAEI):
  OJcpkLfhyXrzneUaFbYSjxTomlMAgw=xbmcgui.Window(10000)
  return OJcpkLfhyXrzneUaFbYSjxTomlMAgw.getProperty('WAVVE_M_CREDENTIAL')
 def set_winEpisodeOrderby(OJcpkLfhyXrzneUaFbYSjxTomlMAEI,OJcpkLfhyXrzneUaFbYSjxTomlMAqg):
  OJcpkLfhyXrzneUaFbYSjxTomlMAgw=xbmcgui.Window(10000)
  OJcpkLfhyXrzneUaFbYSjxTomlMAgw.setProperty('WAVVE_M_ORDERBY',OJcpkLfhyXrzneUaFbYSjxTomlMAqg)
 def get_winEpisodeOrderby(OJcpkLfhyXrzneUaFbYSjxTomlMAEI):
  OJcpkLfhyXrzneUaFbYSjxTomlMAgw=xbmcgui.Window(10000)
  return OJcpkLfhyXrzneUaFbYSjxTomlMAgw.getProperty('WAVVE_M_ORDERBY')
 def add_dir(OJcpkLfhyXrzneUaFbYSjxTomlMAEI,label,sublabel='',img='',infoLabels=OJcpkLfhyXrzneUaFbYSjxTomlMAws,isFolder=OJcpkLfhyXrzneUaFbYSjxTomlMAwC,params='',isLink=OJcpkLfhyXrzneUaFbYSjxTomlMAwq,ContextMenu=OJcpkLfhyXrzneUaFbYSjxTomlMAws):
  OJcpkLfhyXrzneUaFbYSjxTomlMAgI='%s?%s'%(OJcpkLfhyXrzneUaFbYSjxTomlMAEI._addon_url,urllib.parse.urlencode(params))
  if sublabel:OJcpkLfhyXrzneUaFbYSjxTomlMAgV='%s < %s >'%(label,sublabel)
  else: OJcpkLfhyXrzneUaFbYSjxTomlMAgV=label
  if not img:img='DefaultFolder.png'
  OJcpkLfhyXrzneUaFbYSjxTomlMAgR=xbmcgui.ListItem(OJcpkLfhyXrzneUaFbYSjxTomlMAgV)
  if OJcpkLfhyXrzneUaFbYSjxTomlMAwI(img)==OJcpkLfhyXrzneUaFbYSjxTomlMAwV:
   OJcpkLfhyXrzneUaFbYSjxTomlMAgR.setArt(img)
  else:
   OJcpkLfhyXrzneUaFbYSjxTomlMAgR.setArt({'thumb':img,'poster':img})
  if infoLabels:OJcpkLfhyXrzneUaFbYSjxTomlMAgR.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   OJcpkLfhyXrzneUaFbYSjxTomlMAgR.setProperty('IsPlayable','true')
  if ContextMenu:OJcpkLfhyXrzneUaFbYSjxTomlMAgR.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(OJcpkLfhyXrzneUaFbYSjxTomlMAEI._addon_handle,OJcpkLfhyXrzneUaFbYSjxTomlMAgI,OJcpkLfhyXrzneUaFbYSjxTomlMAgR,isFolder)
 def dp_Main_List(OJcpkLfhyXrzneUaFbYSjxTomlMAEI):
  (OJcpkLfhyXrzneUaFbYSjxTomlMAEi,OJcpkLfhyXrzneUaFbYSjxTomlMAEP,OJcpkLfhyXrzneUaFbYSjxTomlMAEu,OJcpkLfhyXrzneUaFbYSjxTomlMAEB,OJcpkLfhyXrzneUaFbYSjxTomlMAgE)=OJcpkLfhyXrzneUaFbYSjxTomlMAEI.get_settings_totalsearch()
  for OJcpkLfhyXrzneUaFbYSjxTomlMAgN in OJcpkLfhyXrzneUaFbYSjxTomlMAEs:
   OJcpkLfhyXrzneUaFbYSjxTomlMAgV=OJcpkLfhyXrzneUaFbYSjxTomlMAgN.get('title')
   OJcpkLfhyXrzneUaFbYSjxTomlMAgH=''
   if OJcpkLfhyXrzneUaFbYSjxTomlMAgN.get('mode')=='SEARCH_GROUP' and OJcpkLfhyXrzneUaFbYSjxTomlMAEi ==OJcpkLfhyXrzneUaFbYSjxTomlMAwq:continue
   elif OJcpkLfhyXrzneUaFbYSjxTomlMAgN.get('mode')=='SEARCH_HISTORY' and OJcpkLfhyXrzneUaFbYSjxTomlMAEP==OJcpkLfhyXrzneUaFbYSjxTomlMAwq:continue
   elif OJcpkLfhyXrzneUaFbYSjxTomlMAgN.get('mode')=='TOTAL_SEARCH' and OJcpkLfhyXrzneUaFbYSjxTomlMAEu ==OJcpkLfhyXrzneUaFbYSjxTomlMAwq:continue
   elif OJcpkLfhyXrzneUaFbYSjxTomlMAgN.get('mode')=='TOTAL_HISTORY' and OJcpkLfhyXrzneUaFbYSjxTomlMAEB==OJcpkLfhyXrzneUaFbYSjxTomlMAwq:continue
   elif OJcpkLfhyXrzneUaFbYSjxTomlMAgN.get('mode')=='MENU_BOOKMARK' and OJcpkLfhyXrzneUaFbYSjxTomlMAgE==OJcpkLfhyXrzneUaFbYSjxTomlMAwq:continue
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD={'mode':OJcpkLfhyXrzneUaFbYSjxTomlMAgN.get('mode'),'sCode':OJcpkLfhyXrzneUaFbYSjxTomlMAgN.get('sCode'),'sIndex':OJcpkLfhyXrzneUaFbYSjxTomlMAgN.get('sIndex'),'sType':OJcpkLfhyXrzneUaFbYSjxTomlMAgN.get('sType'),'suburl':OJcpkLfhyXrzneUaFbYSjxTomlMAgN.get('suburl'),'subapi':OJcpkLfhyXrzneUaFbYSjxTomlMAgN.get('subapi'),'page':OJcpkLfhyXrzneUaFbYSjxTomlMAgN.get('page'),'orderby':OJcpkLfhyXrzneUaFbYSjxTomlMAgN.get('orderby'),'ordernm':OJcpkLfhyXrzneUaFbYSjxTomlMAgN.get('ordernm')}
   if OJcpkLfhyXrzneUaFbYSjxTomlMAgN.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    OJcpkLfhyXrzneUaFbYSjxTomlMAgG=OJcpkLfhyXrzneUaFbYSjxTomlMAwq
    OJcpkLfhyXrzneUaFbYSjxTomlMAgQ =OJcpkLfhyXrzneUaFbYSjxTomlMAwC
   else:
    OJcpkLfhyXrzneUaFbYSjxTomlMAgG=OJcpkLfhyXrzneUaFbYSjxTomlMAwC
    OJcpkLfhyXrzneUaFbYSjxTomlMAgQ =OJcpkLfhyXrzneUaFbYSjxTomlMAwq
   if 'icon' in OJcpkLfhyXrzneUaFbYSjxTomlMAgN:OJcpkLfhyXrzneUaFbYSjxTomlMAgH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',OJcpkLfhyXrzneUaFbYSjxTomlMAgN.get('icon')) 
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.add_dir(OJcpkLfhyXrzneUaFbYSjxTomlMAgV,sublabel='',img=OJcpkLfhyXrzneUaFbYSjxTomlMAgH,infoLabels=OJcpkLfhyXrzneUaFbYSjxTomlMAws,isFolder=OJcpkLfhyXrzneUaFbYSjxTomlMAgG,params=OJcpkLfhyXrzneUaFbYSjxTomlMAgD,isLink=OJcpkLfhyXrzneUaFbYSjxTomlMAgQ)
  xbmcplugin.endOfDirectory(OJcpkLfhyXrzneUaFbYSjxTomlMAEI._addon_handle,cacheToDisc=OJcpkLfhyXrzneUaFbYSjxTomlMAwC)
 def dp_Search_Group(OJcpkLfhyXrzneUaFbYSjxTomlMAEI,args):
  if 'search_key' in args:
   OJcpkLfhyXrzneUaFbYSjxTomlMAgK=args.get('search_key')
  else:
   OJcpkLfhyXrzneUaFbYSjxTomlMAgK=OJcpkLfhyXrzneUaFbYSjxTomlMAEI.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not OJcpkLfhyXrzneUaFbYSjxTomlMAgK:
    return
  for OJcpkLfhyXrzneUaFbYSjxTomlMAgW in OJcpkLfhyXrzneUaFbYSjxTomlMAEC:
   OJcpkLfhyXrzneUaFbYSjxTomlMAgi =OJcpkLfhyXrzneUaFbYSjxTomlMAgW.get('mode')
   OJcpkLfhyXrzneUaFbYSjxTomlMAgP=OJcpkLfhyXrzneUaFbYSjxTomlMAgW.get('sType')
   OJcpkLfhyXrzneUaFbYSjxTomlMAgV=OJcpkLfhyXrzneUaFbYSjxTomlMAgW.get('title')
   (OJcpkLfhyXrzneUaFbYSjxTomlMAgu,OJcpkLfhyXrzneUaFbYSjxTomlMAgB)=OJcpkLfhyXrzneUaFbYSjxTomlMAEI.WavveObj.Get_Search_List(OJcpkLfhyXrzneUaFbYSjxTomlMAgK,OJcpkLfhyXrzneUaFbYSjxTomlMAgP,1,exclusion21=OJcpkLfhyXrzneUaFbYSjxTomlMAEI.get_settings_exclusion21())
   OJcpkLfhyXrzneUaFbYSjxTomlMAsE={'plot':'검색어 : '+OJcpkLfhyXrzneUaFbYSjxTomlMAgK+'\n\n'+OJcpkLfhyXrzneUaFbYSjxTomlMAEI.Search_FreeList(OJcpkLfhyXrzneUaFbYSjxTomlMAgu)}
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD={'mode':OJcpkLfhyXrzneUaFbYSjxTomlMAgi,'sType':OJcpkLfhyXrzneUaFbYSjxTomlMAgP,'search_key':OJcpkLfhyXrzneUaFbYSjxTomlMAgK,'page':'1',}
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.add_dir(OJcpkLfhyXrzneUaFbYSjxTomlMAgV,sublabel='',img='',infoLabels=OJcpkLfhyXrzneUaFbYSjxTomlMAsE,isFolder=OJcpkLfhyXrzneUaFbYSjxTomlMAwC,params=OJcpkLfhyXrzneUaFbYSjxTomlMAgD)
  if OJcpkLfhyXrzneUaFbYSjxTomlMAwR(OJcpkLfhyXrzneUaFbYSjxTomlMAEC)>0:xbmcplugin.endOfDirectory(OJcpkLfhyXrzneUaFbYSjxTomlMAEI._addon_handle,cacheToDisc=OJcpkLfhyXrzneUaFbYSjxTomlMAwC)
  OJcpkLfhyXrzneUaFbYSjxTomlMAEI.Save_Searched_List(OJcpkLfhyXrzneUaFbYSjxTomlMAgK)
 def Search_FreeList(OJcpkLfhyXrzneUaFbYSjxTomlMAEI,search_list):
  OJcpkLfhyXrzneUaFbYSjxTomlMAsg=''
  OJcpkLfhyXrzneUaFbYSjxTomlMAsC=7
  try:
   if OJcpkLfhyXrzneUaFbYSjxTomlMAwR(search_list)==0:return '검색결과 없음'
   for i in OJcpkLfhyXrzneUaFbYSjxTomlMAwN(OJcpkLfhyXrzneUaFbYSjxTomlMAwR(search_list)):
    if i>=OJcpkLfhyXrzneUaFbYSjxTomlMAsC:
     OJcpkLfhyXrzneUaFbYSjxTomlMAsg=OJcpkLfhyXrzneUaFbYSjxTomlMAsg+'...'
     break
    OJcpkLfhyXrzneUaFbYSjxTomlMAsg=OJcpkLfhyXrzneUaFbYSjxTomlMAsg+search_list[i]['title']+'\n'
  except:
   return ''
  return OJcpkLfhyXrzneUaFbYSjxTomlMAsg
 def dp_Watch_Group(OJcpkLfhyXrzneUaFbYSjxTomlMAEI,args):
  for OJcpkLfhyXrzneUaFbYSjxTomlMAsq in OJcpkLfhyXrzneUaFbYSjxTomlMAEq:
   OJcpkLfhyXrzneUaFbYSjxTomlMAgV=OJcpkLfhyXrzneUaFbYSjxTomlMAsq.get('title')
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD={'mode':OJcpkLfhyXrzneUaFbYSjxTomlMAsq.get('mode'),'sType':OJcpkLfhyXrzneUaFbYSjxTomlMAsq.get('sType')}
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.add_dir(OJcpkLfhyXrzneUaFbYSjxTomlMAgV,sublabel='',img='',infoLabels=OJcpkLfhyXrzneUaFbYSjxTomlMAws,isFolder=OJcpkLfhyXrzneUaFbYSjxTomlMAwC,params=OJcpkLfhyXrzneUaFbYSjxTomlMAgD)
  if OJcpkLfhyXrzneUaFbYSjxTomlMAwR(OJcpkLfhyXrzneUaFbYSjxTomlMAEq)>0:xbmcplugin.endOfDirectory(OJcpkLfhyXrzneUaFbYSjxTomlMAEI._addon_handle,cacheToDisc=OJcpkLfhyXrzneUaFbYSjxTomlMAwC)
 def dp_Search_History(OJcpkLfhyXrzneUaFbYSjxTomlMAEI,args):
  OJcpkLfhyXrzneUaFbYSjxTomlMAsv=OJcpkLfhyXrzneUaFbYSjxTomlMAEI.Load_List_File('search')
  for OJcpkLfhyXrzneUaFbYSjxTomlMAsw in OJcpkLfhyXrzneUaFbYSjxTomlMAsv:
   OJcpkLfhyXrzneUaFbYSjxTomlMAsI=OJcpkLfhyXrzneUaFbYSjxTomlMAwV(urllib.parse.parse_qsl(OJcpkLfhyXrzneUaFbYSjxTomlMAsw))
   OJcpkLfhyXrzneUaFbYSjxTomlMAsV=OJcpkLfhyXrzneUaFbYSjxTomlMAsI.get('skey').strip()
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD={'mode':'SEARCH_GROUP','search_key':OJcpkLfhyXrzneUaFbYSjxTomlMAsV,}
   OJcpkLfhyXrzneUaFbYSjxTomlMAsR={'mode':'SEARCH_REMOVE','sType':'ONE','skey':OJcpkLfhyXrzneUaFbYSjxTomlMAsV,}
   OJcpkLfhyXrzneUaFbYSjxTomlMAsN=urllib.parse.urlencode(OJcpkLfhyXrzneUaFbYSjxTomlMAsR)
   OJcpkLfhyXrzneUaFbYSjxTomlMAsH=[('선택된 검색어 ( %s ) 삭제'%(OJcpkLfhyXrzneUaFbYSjxTomlMAsV),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(OJcpkLfhyXrzneUaFbYSjxTomlMAsN))]
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.add_dir(OJcpkLfhyXrzneUaFbYSjxTomlMAsV,sublabel='',img=OJcpkLfhyXrzneUaFbYSjxTomlMAws,infoLabels=OJcpkLfhyXrzneUaFbYSjxTomlMAws,isFolder=OJcpkLfhyXrzneUaFbYSjxTomlMAwC,params=OJcpkLfhyXrzneUaFbYSjxTomlMAgD,ContextMenu=OJcpkLfhyXrzneUaFbYSjxTomlMAsH)
  OJcpkLfhyXrzneUaFbYSjxTomlMAsD={'plot':'검색목록 전체를 삭제합니다.'}
  OJcpkLfhyXrzneUaFbYSjxTomlMAgV='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  OJcpkLfhyXrzneUaFbYSjxTomlMAgD={'mode':'SEARCH_REMOVE','sType':'ALL','skey':'-',}
  OJcpkLfhyXrzneUaFbYSjxTomlMAgH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  OJcpkLfhyXrzneUaFbYSjxTomlMAEI.add_dir(OJcpkLfhyXrzneUaFbYSjxTomlMAgV,sublabel='',img=OJcpkLfhyXrzneUaFbYSjxTomlMAgH,infoLabels=OJcpkLfhyXrzneUaFbYSjxTomlMAsD,isFolder=OJcpkLfhyXrzneUaFbYSjxTomlMAwq,params=OJcpkLfhyXrzneUaFbYSjxTomlMAgD,isLink=OJcpkLfhyXrzneUaFbYSjxTomlMAwC)
  xbmcplugin.endOfDirectory(OJcpkLfhyXrzneUaFbYSjxTomlMAEI._addon_handle,cacheToDisc=OJcpkLfhyXrzneUaFbYSjxTomlMAwq)
 def dp_Search_List(OJcpkLfhyXrzneUaFbYSjxTomlMAEI,args):
  OJcpkLfhyXrzneUaFbYSjxTomlMAEI.WavveObj.SaveCredential(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.get_winCredential())
  OJcpkLfhyXrzneUaFbYSjxTomlMAgP =args.get('sType')
  OJcpkLfhyXrzneUaFbYSjxTomlMAsG =OJcpkLfhyXrzneUaFbYSjxTomlMAwv(args.get('page'))
  if 'search_key' in args:
   OJcpkLfhyXrzneUaFbYSjxTomlMAgK=args.get('search_key')
  else:
   OJcpkLfhyXrzneUaFbYSjxTomlMAgK=OJcpkLfhyXrzneUaFbYSjxTomlMAEI.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not OJcpkLfhyXrzneUaFbYSjxTomlMAgK:
    xbmcplugin.endOfDirectory(OJcpkLfhyXrzneUaFbYSjxTomlMAEI._addon_handle)
    return
  OJcpkLfhyXrzneUaFbYSjxTomlMAsQ,OJcpkLfhyXrzneUaFbYSjxTomlMAgB=OJcpkLfhyXrzneUaFbYSjxTomlMAEI.WavveObj.Get_Search_List(OJcpkLfhyXrzneUaFbYSjxTomlMAgK,OJcpkLfhyXrzneUaFbYSjxTomlMAgP,OJcpkLfhyXrzneUaFbYSjxTomlMAsG,exclusion21=OJcpkLfhyXrzneUaFbYSjxTomlMAEI.get_settings_exclusion21())
  for OJcpkLfhyXrzneUaFbYSjxTomlMAsd in OJcpkLfhyXrzneUaFbYSjxTomlMAsQ:
   OJcpkLfhyXrzneUaFbYSjxTomlMAgV =OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('title')
   OJcpkLfhyXrzneUaFbYSjxTomlMAst=OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('thumbnail')
   OJcpkLfhyXrzneUaFbYSjxTomlMAsK =OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('age')
   if OJcpkLfhyXrzneUaFbYSjxTomlMAsK=='18' or OJcpkLfhyXrzneUaFbYSjxTomlMAsK=='19' or OJcpkLfhyXrzneUaFbYSjxTomlMAsK=='21':OJcpkLfhyXrzneUaFbYSjxTomlMAgV+=' (%s)'%(OJcpkLfhyXrzneUaFbYSjxTomlMAsK)
   OJcpkLfhyXrzneUaFbYSjxTomlMAsD={'mediatype':'tvshow' if OJcpkLfhyXrzneUaFbYSjxTomlMAgP=='vod' else 'movie','mpaa':OJcpkLfhyXrzneUaFbYSjxTomlMAsK,'title':OJcpkLfhyXrzneUaFbYSjxTomlMAgV,'plot':OJcpkLfhyXrzneUaFbYSjxTomlMAgV}
   if OJcpkLfhyXrzneUaFbYSjxTomlMAgP=='vod':
    OJcpkLfhyXrzneUaFbYSjxTomlMAgD={'mode':'EPISODE_LIST','videoid':OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('videoid'),'vidtype':OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('vidtype'),'page':'1'}
    OJcpkLfhyXrzneUaFbYSjxTomlMAgG=OJcpkLfhyXrzneUaFbYSjxTomlMAwC
   else:
    OJcpkLfhyXrzneUaFbYSjxTomlMAgD={'mode':'MOVIE','contentid':OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('videoid'),'title':OJcpkLfhyXrzneUaFbYSjxTomlMAgV,'thumbnail':OJcpkLfhyXrzneUaFbYSjxTomlMAst,'age':OJcpkLfhyXrzneUaFbYSjxTomlMAsK}
    OJcpkLfhyXrzneUaFbYSjxTomlMAgG=OJcpkLfhyXrzneUaFbYSjxTomlMAwq
   if OJcpkLfhyXrzneUaFbYSjxTomlMAEI.get_settings_makebookmark():
    OJcpkLfhyXrzneUaFbYSjxTomlMAsW={'videoid':OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('videoid'),'vidtype':'tvshow' if OJcpkLfhyXrzneUaFbYSjxTomlMAgP=='vod' else 'movie','vtitle':OJcpkLfhyXrzneUaFbYSjxTomlMAgV,'vsubtitle':'','contenttype':OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('vidtype'),}
    OJcpkLfhyXrzneUaFbYSjxTomlMAsi=json.dumps(OJcpkLfhyXrzneUaFbYSjxTomlMAsW)
    OJcpkLfhyXrzneUaFbYSjxTomlMAsi=urllib.parse.quote(OJcpkLfhyXrzneUaFbYSjxTomlMAsi)
    OJcpkLfhyXrzneUaFbYSjxTomlMAsP='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(OJcpkLfhyXrzneUaFbYSjxTomlMAsi)
    OJcpkLfhyXrzneUaFbYSjxTomlMAsH=[('(통합) 찜 영상에 추가',OJcpkLfhyXrzneUaFbYSjxTomlMAsP)]
   else:
    OJcpkLfhyXrzneUaFbYSjxTomlMAsH=OJcpkLfhyXrzneUaFbYSjxTomlMAws
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.add_dir(OJcpkLfhyXrzneUaFbYSjxTomlMAgV,sublabel='',img=OJcpkLfhyXrzneUaFbYSjxTomlMAst,infoLabels=OJcpkLfhyXrzneUaFbYSjxTomlMAsD,isFolder=OJcpkLfhyXrzneUaFbYSjxTomlMAgG,params=OJcpkLfhyXrzneUaFbYSjxTomlMAgD,ContextMenu=OJcpkLfhyXrzneUaFbYSjxTomlMAsH)
  if OJcpkLfhyXrzneUaFbYSjxTomlMAgB:
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD['mode'] ='SEARCH_LIST' 
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD['sType']=OJcpkLfhyXrzneUaFbYSjxTomlMAgP 
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD['page'] =OJcpkLfhyXrzneUaFbYSjxTomlMAwH(OJcpkLfhyXrzneUaFbYSjxTomlMAsG+1)
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD['search_key']=OJcpkLfhyXrzneUaFbYSjxTomlMAgK
   OJcpkLfhyXrzneUaFbYSjxTomlMAgV='[B]%s >>[/B]'%'다음 페이지'
   OJcpkLfhyXrzneUaFbYSjxTomlMAsu=OJcpkLfhyXrzneUaFbYSjxTomlMAwH(OJcpkLfhyXrzneUaFbYSjxTomlMAsG+1)
   OJcpkLfhyXrzneUaFbYSjxTomlMAgH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.add_dir(OJcpkLfhyXrzneUaFbYSjxTomlMAgV,sublabel=OJcpkLfhyXrzneUaFbYSjxTomlMAsu,img=OJcpkLfhyXrzneUaFbYSjxTomlMAgH,infoLabels=OJcpkLfhyXrzneUaFbYSjxTomlMAws,isFolder=OJcpkLfhyXrzneUaFbYSjxTomlMAwC,params=OJcpkLfhyXrzneUaFbYSjxTomlMAgD)
  if OJcpkLfhyXrzneUaFbYSjxTomlMAgP=='movie':xbmcplugin.setContent(OJcpkLfhyXrzneUaFbYSjxTomlMAEI._addon_handle,'movies')
  else:xbmcplugin.setContent(OJcpkLfhyXrzneUaFbYSjxTomlMAEI._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(OJcpkLfhyXrzneUaFbYSjxTomlMAEI._addon_handle,cacheToDisc=OJcpkLfhyXrzneUaFbYSjxTomlMAwq)
 def dp_Watch_List(OJcpkLfhyXrzneUaFbYSjxTomlMAEI,args):
  OJcpkLfhyXrzneUaFbYSjxTomlMAgP =args.get('sType')
  OJcpkLfhyXrzneUaFbYSjxTomlMAgv=OJcpkLfhyXrzneUaFbYSjxTomlMAEI.get_settings_direct_replay()
  OJcpkLfhyXrzneUaFbYSjxTomlMAsQ=OJcpkLfhyXrzneUaFbYSjxTomlMAEI.Load_List_File(OJcpkLfhyXrzneUaFbYSjxTomlMAgP)
  for OJcpkLfhyXrzneUaFbYSjxTomlMAsd in OJcpkLfhyXrzneUaFbYSjxTomlMAsQ:
   OJcpkLfhyXrzneUaFbYSjxTomlMAsI=OJcpkLfhyXrzneUaFbYSjxTomlMAwV(urllib.parse.parse_qsl(OJcpkLfhyXrzneUaFbYSjxTomlMAsd))
   OJcpkLfhyXrzneUaFbYSjxTomlMAsB =OJcpkLfhyXrzneUaFbYSjxTomlMAsI.get('code').strip()
   OJcpkLfhyXrzneUaFbYSjxTomlMAgV =OJcpkLfhyXrzneUaFbYSjxTomlMAsI.get('title').strip()
   OJcpkLfhyXrzneUaFbYSjxTomlMAsu =OJcpkLfhyXrzneUaFbYSjxTomlMAsI.get('subtitle').strip()
   if OJcpkLfhyXrzneUaFbYSjxTomlMAsu=='None':OJcpkLfhyXrzneUaFbYSjxTomlMAsu=''
   OJcpkLfhyXrzneUaFbYSjxTomlMAst=OJcpkLfhyXrzneUaFbYSjxTomlMAsI.get('img').strip()
   OJcpkLfhyXrzneUaFbYSjxTomlMACE =OJcpkLfhyXrzneUaFbYSjxTomlMAsI.get('videoid').strip()
   try:
    OJcpkLfhyXrzneUaFbYSjxTomlMAst=OJcpkLfhyXrzneUaFbYSjxTomlMAst.replace('\'','\"')
    OJcpkLfhyXrzneUaFbYSjxTomlMAst=json.loads(OJcpkLfhyXrzneUaFbYSjxTomlMAst)
   except:
    OJcpkLfhyXrzneUaFbYSjxTomlMAws
   OJcpkLfhyXrzneUaFbYSjxTomlMAsD={'plot':'%s\n%s'%(OJcpkLfhyXrzneUaFbYSjxTomlMAgV,OJcpkLfhyXrzneUaFbYSjxTomlMAsu)}
   if OJcpkLfhyXrzneUaFbYSjxTomlMAgP=='vod':
    if OJcpkLfhyXrzneUaFbYSjxTomlMAgv==OJcpkLfhyXrzneUaFbYSjxTomlMAwq or OJcpkLfhyXrzneUaFbYSjxTomlMACE==OJcpkLfhyXrzneUaFbYSjxTomlMAws:
     OJcpkLfhyXrzneUaFbYSjxTomlMAgD={'mode':'EPISODE_LIST','videoid':OJcpkLfhyXrzneUaFbYSjxTomlMAsB,'vidtype':'programid','page':'1'}
     OJcpkLfhyXrzneUaFbYSjxTomlMAgG=OJcpkLfhyXrzneUaFbYSjxTomlMAwC
    else:
     OJcpkLfhyXrzneUaFbYSjxTomlMAgD={'mode':'VOD','programid':OJcpkLfhyXrzneUaFbYSjxTomlMAsB,'contentid':OJcpkLfhyXrzneUaFbYSjxTomlMACE,'title':OJcpkLfhyXrzneUaFbYSjxTomlMAgV,'subtitle':OJcpkLfhyXrzneUaFbYSjxTomlMAsu,'thumbnail':OJcpkLfhyXrzneUaFbYSjxTomlMAst}
     OJcpkLfhyXrzneUaFbYSjxTomlMAgG=OJcpkLfhyXrzneUaFbYSjxTomlMAwq
   else:
    OJcpkLfhyXrzneUaFbYSjxTomlMAgD={'mode':'MOVIE','contentid':OJcpkLfhyXrzneUaFbYSjxTomlMAsB,'title':OJcpkLfhyXrzneUaFbYSjxTomlMAgV,'subtitle':OJcpkLfhyXrzneUaFbYSjxTomlMAsu,'thumbnail':OJcpkLfhyXrzneUaFbYSjxTomlMAst}
    OJcpkLfhyXrzneUaFbYSjxTomlMAgG=OJcpkLfhyXrzneUaFbYSjxTomlMAwq
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.add_dir(OJcpkLfhyXrzneUaFbYSjxTomlMAgV,sublabel=OJcpkLfhyXrzneUaFbYSjxTomlMAsu,img=OJcpkLfhyXrzneUaFbYSjxTomlMAst,infoLabels=OJcpkLfhyXrzneUaFbYSjxTomlMAsD,isFolder=OJcpkLfhyXrzneUaFbYSjxTomlMAgG,params=OJcpkLfhyXrzneUaFbYSjxTomlMAgD)
  OJcpkLfhyXrzneUaFbYSjxTomlMAsD={'plot':'시청목록을 삭제합니다.'}
  OJcpkLfhyXrzneUaFbYSjxTomlMAgV='*** 시청목록 삭제 ***'
  OJcpkLfhyXrzneUaFbYSjxTomlMAgD={'mode':'MYVIEW_REMOVE','sType':OJcpkLfhyXrzneUaFbYSjxTomlMAgP,'skey':'-',}
  OJcpkLfhyXrzneUaFbYSjxTomlMAgH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  OJcpkLfhyXrzneUaFbYSjxTomlMAEI.add_dir(OJcpkLfhyXrzneUaFbYSjxTomlMAgV,sublabel='',img=OJcpkLfhyXrzneUaFbYSjxTomlMAgH,infoLabels=OJcpkLfhyXrzneUaFbYSjxTomlMAsD,isFolder=OJcpkLfhyXrzneUaFbYSjxTomlMAwq,params=OJcpkLfhyXrzneUaFbYSjxTomlMAgD,isLink=OJcpkLfhyXrzneUaFbYSjxTomlMAwC)
  if OJcpkLfhyXrzneUaFbYSjxTomlMAgP=='movie':xbmcplugin.setContent(OJcpkLfhyXrzneUaFbYSjxTomlMAEI._addon_handle,'movies')
  else:xbmcplugin.setContent(OJcpkLfhyXrzneUaFbYSjxTomlMAEI._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(OJcpkLfhyXrzneUaFbYSjxTomlMAEI._addon_handle,cacheToDisc=OJcpkLfhyXrzneUaFbYSjxTomlMAwq)
 def Load_List_File(OJcpkLfhyXrzneUaFbYSjxTomlMAEI,OJcpkLfhyXrzneUaFbYSjxTomlMACG): 
  try:
   if OJcpkLfhyXrzneUaFbYSjxTomlMACG=='search':
    OJcpkLfhyXrzneUaFbYSjxTomlMACg=OJcpkLfhyXrzneUaFbYSjxTomlMAEw
   elif OJcpkLfhyXrzneUaFbYSjxTomlMACG in['vod','movie']:
    OJcpkLfhyXrzneUaFbYSjxTomlMACg=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%OJcpkLfhyXrzneUaFbYSjxTomlMACG))
   else:
    return[]
   fp=OJcpkLfhyXrzneUaFbYSjxTomlMAwD(OJcpkLfhyXrzneUaFbYSjxTomlMACg,'r',-1,'utf-8')
   OJcpkLfhyXrzneUaFbYSjxTomlMACs=fp.readlines()
   fp.close()
  except:
   OJcpkLfhyXrzneUaFbYSjxTomlMACs=[]
  return OJcpkLfhyXrzneUaFbYSjxTomlMACs
 def Save_Watched_List(OJcpkLfhyXrzneUaFbYSjxTomlMAEI,OJcpkLfhyXrzneUaFbYSjxTomlMAvB,OJcpkLfhyXrzneUaFbYSjxTomlMAEN):
  try:
   OJcpkLfhyXrzneUaFbYSjxTomlMACq=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%OJcpkLfhyXrzneUaFbYSjxTomlMAvB))
   OJcpkLfhyXrzneUaFbYSjxTomlMACv=OJcpkLfhyXrzneUaFbYSjxTomlMAEI.Load_List_File(OJcpkLfhyXrzneUaFbYSjxTomlMAvB) 
   fp=OJcpkLfhyXrzneUaFbYSjxTomlMAwD(OJcpkLfhyXrzneUaFbYSjxTomlMACq,'w',-1,'utf-8')
   OJcpkLfhyXrzneUaFbYSjxTomlMACw=urllib.parse.urlencode(OJcpkLfhyXrzneUaFbYSjxTomlMAEN)
   OJcpkLfhyXrzneUaFbYSjxTomlMACw=OJcpkLfhyXrzneUaFbYSjxTomlMACw+'\n'
   fp.write(OJcpkLfhyXrzneUaFbYSjxTomlMACw)
   OJcpkLfhyXrzneUaFbYSjxTomlMACI=0
   for OJcpkLfhyXrzneUaFbYSjxTomlMACV in OJcpkLfhyXrzneUaFbYSjxTomlMACv:
    OJcpkLfhyXrzneUaFbYSjxTomlMACR=OJcpkLfhyXrzneUaFbYSjxTomlMAwV(urllib.parse.parse_qsl(OJcpkLfhyXrzneUaFbYSjxTomlMACV))
    OJcpkLfhyXrzneUaFbYSjxTomlMACN=OJcpkLfhyXrzneUaFbYSjxTomlMAEN.get('code').strip()
    OJcpkLfhyXrzneUaFbYSjxTomlMACH=OJcpkLfhyXrzneUaFbYSjxTomlMACR.get('code').strip()
    if OJcpkLfhyXrzneUaFbYSjxTomlMAvB=='vod' and OJcpkLfhyXrzneUaFbYSjxTomlMAEI.get_settings_direct_replay()==OJcpkLfhyXrzneUaFbYSjxTomlMAwC:
     OJcpkLfhyXrzneUaFbYSjxTomlMACN=OJcpkLfhyXrzneUaFbYSjxTomlMAEN.get('videoid').strip()
     OJcpkLfhyXrzneUaFbYSjxTomlMACH=OJcpkLfhyXrzneUaFbYSjxTomlMACR.get('videoid').strip()if OJcpkLfhyXrzneUaFbYSjxTomlMACH!=OJcpkLfhyXrzneUaFbYSjxTomlMAws else '-'
    if OJcpkLfhyXrzneUaFbYSjxTomlMACN!=OJcpkLfhyXrzneUaFbYSjxTomlMACH:
     fp.write(OJcpkLfhyXrzneUaFbYSjxTomlMACV)
     OJcpkLfhyXrzneUaFbYSjxTomlMACI+=1
     if OJcpkLfhyXrzneUaFbYSjxTomlMACI>=50:break
   fp.close()
  except:
   OJcpkLfhyXrzneUaFbYSjxTomlMAws
 def Delete_List_File(OJcpkLfhyXrzneUaFbYSjxTomlMAEI,OJcpkLfhyXrzneUaFbYSjxTomlMACG,skey='-'):
  if OJcpkLfhyXrzneUaFbYSjxTomlMACG=='ALL':
   try:
    OJcpkLfhyXrzneUaFbYSjxTomlMACg=OJcpkLfhyXrzneUaFbYSjxTomlMAEw
    fp=OJcpkLfhyXrzneUaFbYSjxTomlMAwD(OJcpkLfhyXrzneUaFbYSjxTomlMACg,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    OJcpkLfhyXrzneUaFbYSjxTomlMAws
  elif OJcpkLfhyXrzneUaFbYSjxTomlMACG=='ONE':
   try:
    OJcpkLfhyXrzneUaFbYSjxTomlMACg=OJcpkLfhyXrzneUaFbYSjxTomlMAEw
    OJcpkLfhyXrzneUaFbYSjxTomlMACv=OJcpkLfhyXrzneUaFbYSjxTomlMAEI.Load_List_File('search') 
    fp=OJcpkLfhyXrzneUaFbYSjxTomlMAwD(OJcpkLfhyXrzneUaFbYSjxTomlMACg,'w',-1,'utf-8')
    for OJcpkLfhyXrzneUaFbYSjxTomlMACV in OJcpkLfhyXrzneUaFbYSjxTomlMACv:
     OJcpkLfhyXrzneUaFbYSjxTomlMACR=OJcpkLfhyXrzneUaFbYSjxTomlMAwV(urllib.parse.parse_qsl(OJcpkLfhyXrzneUaFbYSjxTomlMACV))
     OJcpkLfhyXrzneUaFbYSjxTomlMACD=OJcpkLfhyXrzneUaFbYSjxTomlMACR.get('skey').strip()
     if skey!=OJcpkLfhyXrzneUaFbYSjxTomlMACD:
      fp.write(OJcpkLfhyXrzneUaFbYSjxTomlMACV)
    fp.close()
   except:
    OJcpkLfhyXrzneUaFbYSjxTomlMAws
  elif OJcpkLfhyXrzneUaFbYSjxTomlMACG in['vod','movie']:
   try:
    OJcpkLfhyXrzneUaFbYSjxTomlMACg=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%OJcpkLfhyXrzneUaFbYSjxTomlMACG))
    fp=OJcpkLfhyXrzneUaFbYSjxTomlMAwD(OJcpkLfhyXrzneUaFbYSjxTomlMACg,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    OJcpkLfhyXrzneUaFbYSjxTomlMAws
 def dp_Listfile_Delete(OJcpkLfhyXrzneUaFbYSjxTomlMAEI,args):
  OJcpkLfhyXrzneUaFbYSjxTomlMACG=args.get('sType')
  OJcpkLfhyXrzneUaFbYSjxTomlMAsV =args.get('skey')
  OJcpkLfhyXrzneUaFbYSjxTomlMAED=xbmcgui.Dialog()
  if OJcpkLfhyXrzneUaFbYSjxTomlMACG=='ALL':
   OJcpkLfhyXrzneUaFbYSjxTomlMACQ=OJcpkLfhyXrzneUaFbYSjxTomlMAED.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif OJcpkLfhyXrzneUaFbYSjxTomlMACG=='ONE':
   OJcpkLfhyXrzneUaFbYSjxTomlMACQ=OJcpkLfhyXrzneUaFbYSjxTomlMAED.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif OJcpkLfhyXrzneUaFbYSjxTomlMACG in['vod','movie']:
   OJcpkLfhyXrzneUaFbYSjxTomlMACQ=OJcpkLfhyXrzneUaFbYSjxTomlMAED.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if OJcpkLfhyXrzneUaFbYSjxTomlMACQ==OJcpkLfhyXrzneUaFbYSjxTomlMAwq:sys.exit()
  OJcpkLfhyXrzneUaFbYSjxTomlMAEI.Delete_List_File(OJcpkLfhyXrzneUaFbYSjxTomlMACG,skey=OJcpkLfhyXrzneUaFbYSjxTomlMAsV)
  xbmc.executebuiltin("Container.Refresh")
 def Save_Searched_List(OJcpkLfhyXrzneUaFbYSjxTomlMAEI,OJcpkLfhyXrzneUaFbYSjxTomlMAgK):
  try:
   OJcpkLfhyXrzneUaFbYSjxTomlMACd=OJcpkLfhyXrzneUaFbYSjxTomlMAEw
   OJcpkLfhyXrzneUaFbYSjxTomlMACv=OJcpkLfhyXrzneUaFbYSjxTomlMAEI.Load_List_File('search') 
   OJcpkLfhyXrzneUaFbYSjxTomlMACt={'skey':OJcpkLfhyXrzneUaFbYSjxTomlMAgK.strip()}
   fp=OJcpkLfhyXrzneUaFbYSjxTomlMAwD(OJcpkLfhyXrzneUaFbYSjxTomlMACd,'w',-1,'utf-8')
   OJcpkLfhyXrzneUaFbYSjxTomlMACw=urllib.parse.urlencode(OJcpkLfhyXrzneUaFbYSjxTomlMACt)
   OJcpkLfhyXrzneUaFbYSjxTomlMACw=OJcpkLfhyXrzneUaFbYSjxTomlMACw+'\n'
   fp.write(OJcpkLfhyXrzneUaFbYSjxTomlMACw)
   OJcpkLfhyXrzneUaFbYSjxTomlMACI=0
   for OJcpkLfhyXrzneUaFbYSjxTomlMACV in OJcpkLfhyXrzneUaFbYSjxTomlMACv:
    OJcpkLfhyXrzneUaFbYSjxTomlMACR=OJcpkLfhyXrzneUaFbYSjxTomlMAwV(urllib.parse.parse_qsl(OJcpkLfhyXrzneUaFbYSjxTomlMACV))
    OJcpkLfhyXrzneUaFbYSjxTomlMACN=OJcpkLfhyXrzneUaFbYSjxTomlMACt.get('skey').strip()
    OJcpkLfhyXrzneUaFbYSjxTomlMACH=OJcpkLfhyXrzneUaFbYSjxTomlMACR.get('skey').strip()
    if OJcpkLfhyXrzneUaFbYSjxTomlMACN!=OJcpkLfhyXrzneUaFbYSjxTomlMACH:
     fp.write(OJcpkLfhyXrzneUaFbYSjxTomlMACV)
     OJcpkLfhyXrzneUaFbYSjxTomlMACI+=1
     if OJcpkLfhyXrzneUaFbYSjxTomlMACI>=50:break
   fp.close()
  except:
   OJcpkLfhyXrzneUaFbYSjxTomlMAws
 def dp_Global_Search(OJcpkLfhyXrzneUaFbYSjxTomlMAEI,args):
  OJcpkLfhyXrzneUaFbYSjxTomlMAgi=args.get('mode')
  if OJcpkLfhyXrzneUaFbYSjxTomlMAgi=='TOTAL_SEARCH':
   OJcpkLfhyXrzneUaFbYSjxTomlMACK='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   OJcpkLfhyXrzneUaFbYSjxTomlMACK='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(OJcpkLfhyXrzneUaFbYSjxTomlMACK)
 def dp_Bookmark_Menu(OJcpkLfhyXrzneUaFbYSjxTomlMAEI,args):
  OJcpkLfhyXrzneUaFbYSjxTomlMACK='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(OJcpkLfhyXrzneUaFbYSjxTomlMACK)
 def login_main(OJcpkLfhyXrzneUaFbYSjxTomlMAEI):
  (OJcpkLfhyXrzneUaFbYSjxTomlMACW,OJcpkLfhyXrzneUaFbYSjxTomlMACi,OJcpkLfhyXrzneUaFbYSjxTomlMACP)=OJcpkLfhyXrzneUaFbYSjxTomlMAEI.get_settings_login_info()
  if not(OJcpkLfhyXrzneUaFbYSjxTomlMACW and OJcpkLfhyXrzneUaFbYSjxTomlMACi):
   OJcpkLfhyXrzneUaFbYSjxTomlMAED=xbmcgui.Dialog()
   OJcpkLfhyXrzneUaFbYSjxTomlMACQ=OJcpkLfhyXrzneUaFbYSjxTomlMAED.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if OJcpkLfhyXrzneUaFbYSjxTomlMACQ==OJcpkLfhyXrzneUaFbYSjxTomlMAwC:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if OJcpkLfhyXrzneUaFbYSjxTomlMAEI.get_winEpisodeOrderby()=='':
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.set_winEpisodeOrderby('desc')
  if OJcpkLfhyXrzneUaFbYSjxTomlMAEI.cookiefile_check():return
  OJcpkLfhyXrzneUaFbYSjxTomlMACu =OJcpkLfhyXrzneUaFbYSjxTomlMAwv(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  OJcpkLfhyXrzneUaFbYSjxTomlMACB=xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINTIME')
  if OJcpkLfhyXrzneUaFbYSjxTomlMACB==OJcpkLfhyXrzneUaFbYSjxTomlMAws or OJcpkLfhyXrzneUaFbYSjxTomlMACB=='':
   OJcpkLfhyXrzneUaFbYSjxTomlMACB=OJcpkLfhyXrzneUaFbYSjxTomlMAwv('19000101')
  else:
   OJcpkLfhyXrzneUaFbYSjxTomlMACB=OJcpkLfhyXrzneUaFbYSjxTomlMAwv(re.sub('-','',OJcpkLfhyXrzneUaFbYSjxTomlMACB))
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   OJcpkLfhyXrzneUaFbYSjxTomlMAqE=0
   while OJcpkLfhyXrzneUaFbYSjxTomlMAwC:
    OJcpkLfhyXrzneUaFbYSjxTomlMAqE+=1
    time.sleep(0.05)
    if OJcpkLfhyXrzneUaFbYSjxTomlMACB>=OJcpkLfhyXrzneUaFbYSjxTomlMACu:return
    if OJcpkLfhyXrzneUaFbYSjxTomlMAqE>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  if OJcpkLfhyXrzneUaFbYSjxTomlMACB>=OJcpkLfhyXrzneUaFbYSjxTomlMACu:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   return
  if not OJcpkLfhyXrzneUaFbYSjxTomlMAEI.WavveObj.GetCredential(OJcpkLfhyXrzneUaFbYSjxTomlMACW,OJcpkLfhyXrzneUaFbYSjxTomlMACi,OJcpkLfhyXrzneUaFbYSjxTomlMACP):
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   sys.exit()
  OJcpkLfhyXrzneUaFbYSjxTomlMAEI.set_winCredential(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.WavveObj.LoadCredential())
  OJcpkLfhyXrzneUaFbYSjxTomlMAEI.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
 def dp_setEpOrderby(OJcpkLfhyXrzneUaFbYSjxTomlMAEI,args):
  OJcpkLfhyXrzneUaFbYSjxTomlMAqg =args.get('orderby')
  OJcpkLfhyXrzneUaFbYSjxTomlMAEI.set_winEpisodeOrderby(OJcpkLfhyXrzneUaFbYSjxTomlMAqg)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(OJcpkLfhyXrzneUaFbYSjxTomlMAEI,args):
  OJcpkLfhyXrzneUaFbYSjxTomlMAEI.WavveObj.SaveCredential(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.get_winCredential())
  OJcpkLfhyXrzneUaFbYSjxTomlMAgi =args.get('mode')
  OJcpkLfhyXrzneUaFbYSjxTomlMAqs =args.get('contentid')
  OJcpkLfhyXrzneUaFbYSjxTomlMAqC =args.get('pvrmode')
  OJcpkLfhyXrzneUaFbYSjxTomlMAqv=OJcpkLfhyXrzneUaFbYSjxTomlMAEI.get_selQuality()
  OJcpkLfhyXrzneUaFbYSjxTomlMAEI.addon_log(OJcpkLfhyXrzneUaFbYSjxTomlMAqs+' - '+OJcpkLfhyXrzneUaFbYSjxTomlMAgi)
  OJcpkLfhyXrzneUaFbYSjxTomlMAqw,OJcpkLfhyXrzneUaFbYSjxTomlMAqI,OJcpkLfhyXrzneUaFbYSjxTomlMAqV,OJcpkLfhyXrzneUaFbYSjxTomlMAqR=OJcpkLfhyXrzneUaFbYSjxTomlMAEI.WavveObj.GetStreamingURL(OJcpkLfhyXrzneUaFbYSjxTomlMAgi,OJcpkLfhyXrzneUaFbYSjxTomlMAqs,OJcpkLfhyXrzneUaFbYSjxTomlMAqv,OJcpkLfhyXrzneUaFbYSjxTomlMAqC)
  OJcpkLfhyXrzneUaFbYSjxTomlMAqN='%s|Cookie=%s'%(OJcpkLfhyXrzneUaFbYSjxTomlMAqw,OJcpkLfhyXrzneUaFbYSjxTomlMAqI)
  OJcpkLfhyXrzneUaFbYSjxTomlMAEI.addon_log(OJcpkLfhyXrzneUaFbYSjxTomlMAqN)
  if OJcpkLfhyXrzneUaFbYSjxTomlMAqw=='':
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.addon_noti(__language__(30907).encode('utf8'))
   return
  OJcpkLfhyXrzneUaFbYSjxTomlMAqH=xbmcgui.ListItem(path=OJcpkLfhyXrzneUaFbYSjxTomlMAqN)
  if OJcpkLfhyXrzneUaFbYSjxTomlMAqV:
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.addon_log('!!streaming_drm!!')
   OJcpkLfhyXrzneUaFbYSjxTomlMAqD=OJcpkLfhyXrzneUaFbYSjxTomlMAqV['customdata']
   OJcpkLfhyXrzneUaFbYSjxTomlMAqG =OJcpkLfhyXrzneUaFbYSjxTomlMAqV['drmhost']
   OJcpkLfhyXrzneUaFbYSjxTomlMAqQ =inputstreamhelper.Helper('mpd',drm='widevine')
   if OJcpkLfhyXrzneUaFbYSjxTomlMAqQ.check_inputstream():
    if OJcpkLfhyXrzneUaFbYSjxTomlMAgi=='MOVIE':
     OJcpkLfhyXrzneUaFbYSjxTomlMAqd='https://www.wavve.com/player/movie?movieid=%s'%OJcpkLfhyXrzneUaFbYSjxTomlMAqs
    else:
     OJcpkLfhyXrzneUaFbYSjxTomlMAqd='https://www.wavve.com/player/vod?programid=%s&page=1'%OJcpkLfhyXrzneUaFbYSjxTomlMAqs
    OJcpkLfhyXrzneUaFbYSjxTomlMAqt={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':OJcpkLfhyXrzneUaFbYSjxTomlMAqD,'referer':OJcpkLfhyXrzneUaFbYSjxTomlMAqd,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':OJcpkLfhyXrzneUaFbYSjxTomlMAEI.WavveObj.USER_AGENT}
    OJcpkLfhyXrzneUaFbYSjxTomlMAqK=OJcpkLfhyXrzneUaFbYSjxTomlMAqG+'|'+urllib.parse.urlencode(OJcpkLfhyXrzneUaFbYSjxTomlMAqt)+'|R{SSM}|'
    OJcpkLfhyXrzneUaFbYSjxTomlMAqH.setProperty('inputstream',OJcpkLfhyXrzneUaFbYSjxTomlMAqQ.inputstream_addon)
    OJcpkLfhyXrzneUaFbYSjxTomlMAqH.setProperty('inputstream.adaptive.manifest_type','mpd')
    OJcpkLfhyXrzneUaFbYSjxTomlMAqH.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    OJcpkLfhyXrzneUaFbYSjxTomlMAqH.setProperty('inputstream.adaptive.license_key',OJcpkLfhyXrzneUaFbYSjxTomlMAqK)
    OJcpkLfhyXrzneUaFbYSjxTomlMAqH.setProperty('inputstream.adaptive.stream_headers','user-agent=%s&Cookie=%s'%(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.WavveObj.USER_AGENT,OJcpkLfhyXrzneUaFbYSjxTomlMAqI))
  xbmcplugin.setResolvedUrl(OJcpkLfhyXrzneUaFbYSjxTomlMAEI._addon_handle,OJcpkLfhyXrzneUaFbYSjxTomlMAwC,OJcpkLfhyXrzneUaFbYSjxTomlMAqH)
  OJcpkLfhyXrzneUaFbYSjxTomlMAqW=OJcpkLfhyXrzneUaFbYSjxTomlMAwq
  if OJcpkLfhyXrzneUaFbYSjxTomlMAqR:
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.addon_noti(OJcpkLfhyXrzneUaFbYSjxTomlMAqR.encode('utf-8'))
   OJcpkLfhyXrzneUaFbYSjxTomlMAqW=OJcpkLfhyXrzneUaFbYSjxTomlMAwC
  else:
   if '/preview.' in urllib.parse.urlsplit(OJcpkLfhyXrzneUaFbYSjxTomlMAqw).path:
    OJcpkLfhyXrzneUaFbYSjxTomlMAEI.addon_noti(__language__(30908).encode('utf8'))
    OJcpkLfhyXrzneUaFbYSjxTomlMAqW=OJcpkLfhyXrzneUaFbYSjxTomlMAwC
  try:
   OJcpkLfhyXrzneUaFbYSjxTomlMAqi=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and OJcpkLfhyXrzneUaFbYSjxTomlMAqW==OJcpkLfhyXrzneUaFbYSjxTomlMAwq and OJcpkLfhyXrzneUaFbYSjxTomlMAqi!='-':
    OJcpkLfhyXrzneUaFbYSjxTomlMAgD={'code':OJcpkLfhyXrzneUaFbYSjxTomlMAqi,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    OJcpkLfhyXrzneUaFbYSjxTomlMAEI.Save_Watched_List(args.get('mode').lower(),OJcpkLfhyXrzneUaFbYSjxTomlMAgD)
  except:
   OJcpkLfhyXrzneUaFbYSjxTomlMAws
 def logout(OJcpkLfhyXrzneUaFbYSjxTomlMAEI):
  OJcpkLfhyXrzneUaFbYSjxTomlMAED=xbmcgui.Dialog()
  OJcpkLfhyXrzneUaFbYSjxTomlMACQ=OJcpkLfhyXrzneUaFbYSjxTomlMAED.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if OJcpkLfhyXrzneUaFbYSjxTomlMACQ==OJcpkLfhyXrzneUaFbYSjxTomlMAwq:sys.exit()
  OJcpkLfhyXrzneUaFbYSjxTomlMAEI.wininfo_clear()
  if os.path.isfile(OJcpkLfhyXrzneUaFbYSjxTomlMAEv):os.remove(OJcpkLfhyXrzneUaFbYSjxTomlMAEv)
  OJcpkLfhyXrzneUaFbYSjxTomlMAEI.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(OJcpkLfhyXrzneUaFbYSjxTomlMAEI):
  OJcpkLfhyXrzneUaFbYSjxTomlMAgw=xbmcgui.Window(10000)
  OJcpkLfhyXrzneUaFbYSjxTomlMAgw.setProperty('WAVVE_M_CREDENTIAL','')
  OJcpkLfhyXrzneUaFbYSjxTomlMAgw.setProperty('WAVVE_M_LOGINTIME','')
 def cookiefile_save(OJcpkLfhyXrzneUaFbYSjxTomlMAEI):
  OJcpkLfhyXrzneUaFbYSjxTomlMAqP =OJcpkLfhyXrzneUaFbYSjxTomlMAEI.WavveObj.Get_Now_Datetime()
  OJcpkLfhyXrzneUaFbYSjxTomlMAqu=OJcpkLfhyXrzneUaFbYSjxTomlMAqP+datetime.timedelta(days=OJcpkLfhyXrzneUaFbYSjxTomlMAwv(__addon__.getSetting('cache_ttl')))
  OJcpkLfhyXrzneUaFbYSjxTomlMAgw=xbmcgui.Window(10000)
  OJcpkLfhyXrzneUaFbYSjxTomlMAqB={'wavve_token':OJcpkLfhyXrzneUaFbYSjxTomlMAgw.getProperty('WAVVE_M_CREDENTIAL'),'wavve_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'wavve_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'wavve_profile':__addon__.getSetting('selected_profile'),'wavve_limitdate':OJcpkLfhyXrzneUaFbYSjxTomlMAqu.strftime('%Y-%m-%d')}
  try: 
   fp=OJcpkLfhyXrzneUaFbYSjxTomlMAwD(OJcpkLfhyXrzneUaFbYSjxTomlMAEv,'w',-1,'utf-8')
   json.dump(OJcpkLfhyXrzneUaFbYSjxTomlMAqB,fp)
   fp.close()
  except OJcpkLfhyXrzneUaFbYSjxTomlMAwG as exception:
   OJcpkLfhyXrzneUaFbYSjxTomlMAwQ(exception)
 def cookiefile_check(OJcpkLfhyXrzneUaFbYSjxTomlMAEI):
  OJcpkLfhyXrzneUaFbYSjxTomlMAqB={}
  try: 
   fp=OJcpkLfhyXrzneUaFbYSjxTomlMAwD(OJcpkLfhyXrzneUaFbYSjxTomlMAEv,'r',-1,'utf-8')
   OJcpkLfhyXrzneUaFbYSjxTomlMAqB= json.load(fp)
   fp.close()
  except OJcpkLfhyXrzneUaFbYSjxTomlMAwG as exception:
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.wininfo_clear()
   return OJcpkLfhyXrzneUaFbYSjxTomlMAwq
  OJcpkLfhyXrzneUaFbYSjxTomlMACW =__addon__.getSetting('id')
  OJcpkLfhyXrzneUaFbYSjxTomlMACi =__addon__.getSetting('pw')
  OJcpkLfhyXrzneUaFbYSjxTomlMAvE =__addon__.getSetting('selected_profile')
  OJcpkLfhyXrzneUaFbYSjxTomlMAqB['wavve_id']=base64.standard_b64decode(OJcpkLfhyXrzneUaFbYSjxTomlMAqB['wavve_id']).decode('utf-8')
  OJcpkLfhyXrzneUaFbYSjxTomlMAqB['wavve_pw']=base64.standard_b64decode(OJcpkLfhyXrzneUaFbYSjxTomlMAqB['wavve_pw']).decode('utf-8')
  if OJcpkLfhyXrzneUaFbYSjxTomlMACW!=OJcpkLfhyXrzneUaFbYSjxTomlMAqB['wavve_id']or OJcpkLfhyXrzneUaFbYSjxTomlMACi!=OJcpkLfhyXrzneUaFbYSjxTomlMAqB['wavve_pw']or OJcpkLfhyXrzneUaFbYSjxTomlMAvE!=OJcpkLfhyXrzneUaFbYSjxTomlMAqB['wavve_profile']:
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.wininfo_clear()
   return OJcpkLfhyXrzneUaFbYSjxTomlMAwq
  OJcpkLfhyXrzneUaFbYSjxTomlMACu =OJcpkLfhyXrzneUaFbYSjxTomlMAwv(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  OJcpkLfhyXrzneUaFbYSjxTomlMAvg=OJcpkLfhyXrzneUaFbYSjxTomlMAqB['wavve_limitdate']
  OJcpkLfhyXrzneUaFbYSjxTomlMACB =OJcpkLfhyXrzneUaFbYSjxTomlMAwv(re.sub('-','',OJcpkLfhyXrzneUaFbYSjxTomlMAvg))
  if OJcpkLfhyXrzneUaFbYSjxTomlMACB<OJcpkLfhyXrzneUaFbYSjxTomlMACu:
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.wininfo_clear()
   return OJcpkLfhyXrzneUaFbYSjxTomlMAwq
  OJcpkLfhyXrzneUaFbYSjxTomlMAgw=xbmcgui.Window(10000)
  OJcpkLfhyXrzneUaFbYSjxTomlMAgw.setProperty('WAVVE_M_CREDENTIAL',OJcpkLfhyXrzneUaFbYSjxTomlMAqB['wavve_token'])
  OJcpkLfhyXrzneUaFbYSjxTomlMAgw.setProperty('WAVVE_M_LOGINTIME',OJcpkLfhyXrzneUaFbYSjxTomlMAvg)
  return OJcpkLfhyXrzneUaFbYSjxTomlMAwC
 def dp_LiveCatagory_List(OJcpkLfhyXrzneUaFbYSjxTomlMAEI,args):
  OJcpkLfhyXrzneUaFbYSjxTomlMAEI.WavveObj.SaveCredential(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.get_winCredential())
  OJcpkLfhyXrzneUaFbYSjxTomlMAvs =args.get('sCode')
  OJcpkLfhyXrzneUaFbYSjxTomlMAvC=args.get('sIndex')
  OJcpkLfhyXrzneUaFbYSjxTomlMAsQ,OJcpkLfhyXrzneUaFbYSjxTomlMAvq=OJcpkLfhyXrzneUaFbYSjxTomlMAEI.WavveObj.Get_LiveCatagory_List(OJcpkLfhyXrzneUaFbYSjxTomlMAvs,OJcpkLfhyXrzneUaFbYSjxTomlMAvC)
  for OJcpkLfhyXrzneUaFbYSjxTomlMAsd in OJcpkLfhyXrzneUaFbYSjxTomlMAsQ:
   OJcpkLfhyXrzneUaFbYSjxTomlMAgV =OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('title')
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD={'mode':'LIVE_LIST','genre':OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('genre'),'baseapi':OJcpkLfhyXrzneUaFbYSjxTomlMAvq}
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.add_dir(OJcpkLfhyXrzneUaFbYSjxTomlMAgV,sublabel='',img='',infoLabels=OJcpkLfhyXrzneUaFbYSjxTomlMAws,isFolder=OJcpkLfhyXrzneUaFbYSjxTomlMAwC,params=OJcpkLfhyXrzneUaFbYSjxTomlMAgD)
  if OJcpkLfhyXrzneUaFbYSjxTomlMAwR(OJcpkLfhyXrzneUaFbYSjxTomlMAsQ)>0:xbmcplugin.endOfDirectory(OJcpkLfhyXrzneUaFbYSjxTomlMAEI._addon_handle,cacheToDisc=OJcpkLfhyXrzneUaFbYSjxTomlMAwq)
 def dp_MainCatagory_List(OJcpkLfhyXrzneUaFbYSjxTomlMAEI,args):
  OJcpkLfhyXrzneUaFbYSjxTomlMAEI.WavveObj.SaveCredential(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.get_winCredential())
  OJcpkLfhyXrzneUaFbYSjxTomlMAvs =args.get('sCode')
  OJcpkLfhyXrzneUaFbYSjxTomlMAvC=args.get('sIndex')
  OJcpkLfhyXrzneUaFbYSjxTomlMAgP =args.get('sType')
  OJcpkLfhyXrzneUaFbYSjxTomlMAsQ=OJcpkLfhyXrzneUaFbYSjxTomlMAEI.WavveObj.Get_MainCatagory_List(OJcpkLfhyXrzneUaFbYSjxTomlMAvs,OJcpkLfhyXrzneUaFbYSjxTomlMAvC)
  for OJcpkLfhyXrzneUaFbYSjxTomlMAsd in OJcpkLfhyXrzneUaFbYSjxTomlMAsQ:
   if OJcpkLfhyXrzneUaFbYSjxTomlMAgP=='vod':
    if OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('subtype')=='catagory':
     OJcpkLfhyXrzneUaFbYSjxTomlMAgi='PROGRAM_LIST'
    else:
     OJcpkLfhyXrzneUaFbYSjxTomlMAgi='SUPERSECTION_LIST'
   elif OJcpkLfhyXrzneUaFbYSjxTomlMAgP=='movie':
    OJcpkLfhyXrzneUaFbYSjxTomlMAgi='MOVIE_LIST'
   else:
    OJcpkLfhyXrzneUaFbYSjxTomlMAgi=''
   OJcpkLfhyXrzneUaFbYSjxTomlMAgV='%s (%s)'%(OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('title'),args.get('ordernm'))
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD={'mode':OJcpkLfhyXrzneUaFbYSjxTomlMAgi,'suburl':OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('suburl'),'subapi':OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if OJcpkLfhyXrzneUaFbYSjxTomlMAEI.get_settings_exclusion21():
    if OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('title')=='성인' or OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('title')=='성인+':continue
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.add_dir(OJcpkLfhyXrzneUaFbYSjxTomlMAgV,sublabel='',img='',infoLabels=OJcpkLfhyXrzneUaFbYSjxTomlMAws,isFolder=OJcpkLfhyXrzneUaFbYSjxTomlMAwC,params=OJcpkLfhyXrzneUaFbYSjxTomlMAgD)
  if OJcpkLfhyXrzneUaFbYSjxTomlMAwR(OJcpkLfhyXrzneUaFbYSjxTomlMAsQ)>0:xbmcplugin.endOfDirectory(OJcpkLfhyXrzneUaFbYSjxTomlMAEI._addon_handle,cacheToDisc=OJcpkLfhyXrzneUaFbYSjxTomlMAwq)
 def dp_Program_List(OJcpkLfhyXrzneUaFbYSjxTomlMAEI,args):
  OJcpkLfhyXrzneUaFbYSjxTomlMAEI.WavveObj.SaveCredential(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.get_winCredential())
  OJcpkLfhyXrzneUaFbYSjxTomlMAvw =args.get('subapi')
  OJcpkLfhyXrzneUaFbYSjxTomlMAsG=OJcpkLfhyXrzneUaFbYSjxTomlMAwv(args.get('page'))
  OJcpkLfhyXrzneUaFbYSjxTomlMAqg =args.get('orderby')
  OJcpkLfhyXrzneUaFbYSjxTomlMAsQ,OJcpkLfhyXrzneUaFbYSjxTomlMAgB=OJcpkLfhyXrzneUaFbYSjxTomlMAEI.WavveObj.Get_Program_List(OJcpkLfhyXrzneUaFbYSjxTomlMAvw,OJcpkLfhyXrzneUaFbYSjxTomlMAsG,OJcpkLfhyXrzneUaFbYSjxTomlMAqg)
  for OJcpkLfhyXrzneUaFbYSjxTomlMAsd in OJcpkLfhyXrzneUaFbYSjxTomlMAsQ:
   OJcpkLfhyXrzneUaFbYSjxTomlMAgV =OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('title')
   OJcpkLfhyXrzneUaFbYSjxTomlMAst=OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('thumbnail')
   OJcpkLfhyXrzneUaFbYSjxTomlMAsK =OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('age')
   if OJcpkLfhyXrzneUaFbYSjxTomlMAsK=='18' or OJcpkLfhyXrzneUaFbYSjxTomlMAsK=='19' or OJcpkLfhyXrzneUaFbYSjxTomlMAsK=='21':OJcpkLfhyXrzneUaFbYSjxTomlMAgV+=' (%s)'%(OJcpkLfhyXrzneUaFbYSjxTomlMAsK)
   OJcpkLfhyXrzneUaFbYSjxTomlMAsD={'plot':OJcpkLfhyXrzneUaFbYSjxTomlMAgV,'mpaa':OJcpkLfhyXrzneUaFbYSjxTomlMAsK,'mediatype':'tvshow'}
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD={'mode':'EPISODE_LIST','videoid':OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('videoid'),'vidtype':OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('vidtype'),'page':'1'}
   if OJcpkLfhyXrzneUaFbYSjxTomlMAEI.get_settings_makebookmark():
    OJcpkLfhyXrzneUaFbYSjxTomlMAsW={'videoid':OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('videoid'),'vidtype':'tvshow','vtitle':OJcpkLfhyXrzneUaFbYSjxTomlMAgV,'vsubtitle':'','contenttype':OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('vidtype'),}
    OJcpkLfhyXrzneUaFbYSjxTomlMAsi=json.dumps(OJcpkLfhyXrzneUaFbYSjxTomlMAsW)
    OJcpkLfhyXrzneUaFbYSjxTomlMAsi=urllib.parse.quote(OJcpkLfhyXrzneUaFbYSjxTomlMAsi)
    OJcpkLfhyXrzneUaFbYSjxTomlMAsP='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(OJcpkLfhyXrzneUaFbYSjxTomlMAsi)
    OJcpkLfhyXrzneUaFbYSjxTomlMAsH=[('(통합) 찜 영상에 추가',OJcpkLfhyXrzneUaFbYSjxTomlMAsP)]
   else:
    OJcpkLfhyXrzneUaFbYSjxTomlMAsH=OJcpkLfhyXrzneUaFbYSjxTomlMAws
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.add_dir(OJcpkLfhyXrzneUaFbYSjxTomlMAgV,sublabel='',img=OJcpkLfhyXrzneUaFbYSjxTomlMAst,infoLabels=OJcpkLfhyXrzneUaFbYSjxTomlMAsD,isFolder=OJcpkLfhyXrzneUaFbYSjxTomlMAwC,params=OJcpkLfhyXrzneUaFbYSjxTomlMAgD,ContextMenu=OJcpkLfhyXrzneUaFbYSjxTomlMAsH)
  if OJcpkLfhyXrzneUaFbYSjxTomlMAgB:
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD={}
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD['mode'] ='PROGRAM_LIST' 
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD['subapi']=OJcpkLfhyXrzneUaFbYSjxTomlMAvw 
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD['page'] =OJcpkLfhyXrzneUaFbYSjxTomlMAwH(OJcpkLfhyXrzneUaFbYSjxTomlMAsG+1)
   OJcpkLfhyXrzneUaFbYSjxTomlMAgV='[B]%s >>[/B]'%'다음 페이지'
   OJcpkLfhyXrzneUaFbYSjxTomlMAsu=OJcpkLfhyXrzneUaFbYSjxTomlMAwH(OJcpkLfhyXrzneUaFbYSjxTomlMAsG+1)
   OJcpkLfhyXrzneUaFbYSjxTomlMAgH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.add_dir(OJcpkLfhyXrzneUaFbYSjxTomlMAgV,sublabel=OJcpkLfhyXrzneUaFbYSjxTomlMAsu,img=OJcpkLfhyXrzneUaFbYSjxTomlMAgH,infoLabels=OJcpkLfhyXrzneUaFbYSjxTomlMAws,isFolder=OJcpkLfhyXrzneUaFbYSjxTomlMAwC,params=OJcpkLfhyXrzneUaFbYSjxTomlMAgD)
  xbmcplugin.setContent(OJcpkLfhyXrzneUaFbYSjxTomlMAEI._addon_handle,'tvshows')
  if OJcpkLfhyXrzneUaFbYSjxTomlMAwR(OJcpkLfhyXrzneUaFbYSjxTomlMAsQ)>0:xbmcplugin.endOfDirectory(OJcpkLfhyXrzneUaFbYSjxTomlMAEI._addon_handle,cacheToDisc=OJcpkLfhyXrzneUaFbYSjxTomlMAwq)
 def dp_SuperSection_List(OJcpkLfhyXrzneUaFbYSjxTomlMAEI,args):
  OJcpkLfhyXrzneUaFbYSjxTomlMAEI.WavveObj.SaveCredential(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.get_winCredential())
  OJcpkLfhyXrzneUaFbYSjxTomlMAvI =args.get('suburl')
  OJcpkLfhyXrzneUaFbYSjxTomlMAsQ=OJcpkLfhyXrzneUaFbYSjxTomlMAEI.WavveObj.Get_SuperMultiSection_List(OJcpkLfhyXrzneUaFbYSjxTomlMAvI)
  for OJcpkLfhyXrzneUaFbYSjxTomlMAsd in OJcpkLfhyXrzneUaFbYSjxTomlMAsQ:
   OJcpkLfhyXrzneUaFbYSjxTomlMAgV =OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('title')
   OJcpkLfhyXrzneUaFbYSjxTomlMAvw =OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('subapi')
   OJcpkLfhyXrzneUaFbYSjxTomlMAvV=OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('cell_type')
   if OJcpkLfhyXrzneUaFbYSjxTomlMAvw.find('mtype=svod')>=0 or OJcpkLfhyXrzneUaFbYSjxTomlMAvw.find('mtype=ppv')>=0:
    OJcpkLfhyXrzneUaFbYSjxTomlMAgi='MOVIE_LIST'
   elif OJcpkLfhyXrzneUaFbYSjxTomlMAvV=='band_71':
    OJcpkLfhyXrzneUaFbYSjxTomlMAgi ='SUPERSECTION_LIST'
    (OJcpkLfhyXrzneUaFbYSjxTomlMAvR,OJcpkLfhyXrzneUaFbYSjxTomlMAvN)=OJcpkLfhyXrzneUaFbYSjxTomlMAEI.WavveObj.Baseapi_Parse(OJcpkLfhyXrzneUaFbYSjxTomlMAvw)
    OJcpkLfhyXrzneUaFbYSjxTomlMAvI=OJcpkLfhyXrzneUaFbYSjxTomlMAvN.get('api')
    OJcpkLfhyXrzneUaFbYSjxTomlMAvw=''
   elif OJcpkLfhyXrzneUaFbYSjxTomlMAvV=='band_2':
    OJcpkLfhyXrzneUaFbYSjxTomlMAgi='BAND2SECTION_LIST'
   elif OJcpkLfhyXrzneUaFbYSjxTomlMAvV=='band_live':
    OJcpkLfhyXrzneUaFbYSjxTomlMAgi='BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}',OJcpkLfhyXrzneUaFbYSjxTomlMAvw):
    OJcpkLfhyXrzneUaFbYSjxTomlMAgi='MOVIE_LIST'
   else:
    OJcpkLfhyXrzneUaFbYSjxTomlMAgi='PROGRAM_LIST'
   OJcpkLfhyXrzneUaFbYSjxTomlMAsD={'plot':OJcpkLfhyXrzneUaFbYSjxTomlMAgV,'mediatype':'tvshow'}
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD={'mode':OJcpkLfhyXrzneUaFbYSjxTomlMAgi,'suburl':OJcpkLfhyXrzneUaFbYSjxTomlMAvI,'subapi':OJcpkLfhyXrzneUaFbYSjxTomlMAvw,'page':'1'}
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.add_dir(OJcpkLfhyXrzneUaFbYSjxTomlMAgV,sublabel='',img=OJcpkLfhyXrzneUaFbYSjxTomlMAws,infoLabels=OJcpkLfhyXrzneUaFbYSjxTomlMAsD,isFolder=OJcpkLfhyXrzneUaFbYSjxTomlMAwC,params=OJcpkLfhyXrzneUaFbYSjxTomlMAgD)
  if OJcpkLfhyXrzneUaFbYSjxTomlMAwR(OJcpkLfhyXrzneUaFbYSjxTomlMAsQ)>0:xbmcplugin.endOfDirectory(OJcpkLfhyXrzneUaFbYSjxTomlMAEI._addon_handle,cacheToDisc=OJcpkLfhyXrzneUaFbYSjxTomlMAwq)
 def dp_BandLiveSection_List(OJcpkLfhyXrzneUaFbYSjxTomlMAEI,args):
  OJcpkLfhyXrzneUaFbYSjxTomlMAEI.WavveObj.SaveCredential(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.get_winCredential())
  OJcpkLfhyXrzneUaFbYSjxTomlMAvw =args.get('subapi')
  OJcpkLfhyXrzneUaFbYSjxTomlMAsG=OJcpkLfhyXrzneUaFbYSjxTomlMAwv(args.get('page'))
  OJcpkLfhyXrzneUaFbYSjxTomlMAsQ,OJcpkLfhyXrzneUaFbYSjxTomlMAgB=OJcpkLfhyXrzneUaFbYSjxTomlMAEI.WavveObj.Get_BandLiveSection_List(OJcpkLfhyXrzneUaFbYSjxTomlMAvw,OJcpkLfhyXrzneUaFbYSjxTomlMAsG)
  for OJcpkLfhyXrzneUaFbYSjxTomlMAsd in OJcpkLfhyXrzneUaFbYSjxTomlMAsQ:
   OJcpkLfhyXrzneUaFbYSjxTomlMAvH =OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('channelid')
   OJcpkLfhyXrzneUaFbYSjxTomlMAvD =OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('studio')
   OJcpkLfhyXrzneUaFbYSjxTomlMAvG=OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('tvshowtitle')
   OJcpkLfhyXrzneUaFbYSjxTomlMAst =OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('thumbnail')
   OJcpkLfhyXrzneUaFbYSjxTomlMAsK =OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('age')
   OJcpkLfhyXrzneUaFbYSjxTomlMAsD={'mediatype':'tvshow','mpaa':OJcpkLfhyXrzneUaFbYSjxTomlMAsK,'title':'%s < %s >'%(OJcpkLfhyXrzneUaFbYSjxTomlMAvD,OJcpkLfhyXrzneUaFbYSjxTomlMAvG),'tvshowtitle':OJcpkLfhyXrzneUaFbYSjxTomlMAvG,'studio':OJcpkLfhyXrzneUaFbYSjxTomlMAvD,'plot':OJcpkLfhyXrzneUaFbYSjxTomlMAvD}
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD={'mode':'LIVE','contentid':OJcpkLfhyXrzneUaFbYSjxTomlMAvH}
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.add_dir(OJcpkLfhyXrzneUaFbYSjxTomlMAvD,sublabel=OJcpkLfhyXrzneUaFbYSjxTomlMAvG,img=OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('thumbnail'),infoLabels=OJcpkLfhyXrzneUaFbYSjxTomlMAsD,isFolder=OJcpkLfhyXrzneUaFbYSjxTomlMAwq,params=OJcpkLfhyXrzneUaFbYSjxTomlMAgD)
  if OJcpkLfhyXrzneUaFbYSjxTomlMAgB:
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD={}
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD['mode'] ='BANDLIVESECTION_LIST' 
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD['subapi']=OJcpkLfhyXrzneUaFbYSjxTomlMAvw
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD['page'] =OJcpkLfhyXrzneUaFbYSjxTomlMAwH(OJcpkLfhyXrzneUaFbYSjxTomlMAsG+1)
   OJcpkLfhyXrzneUaFbYSjxTomlMAgV='[B]%s >>[/B]'%'다음 페이지'
   OJcpkLfhyXrzneUaFbYSjxTomlMAsu=OJcpkLfhyXrzneUaFbYSjxTomlMAwH(OJcpkLfhyXrzneUaFbYSjxTomlMAsG+1)
   OJcpkLfhyXrzneUaFbYSjxTomlMAgH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.add_dir(OJcpkLfhyXrzneUaFbYSjxTomlMAgV,sublabel=OJcpkLfhyXrzneUaFbYSjxTomlMAsu,img=OJcpkLfhyXrzneUaFbYSjxTomlMAgH,infoLabels=OJcpkLfhyXrzneUaFbYSjxTomlMAws,isFolder=OJcpkLfhyXrzneUaFbYSjxTomlMAwC,params=OJcpkLfhyXrzneUaFbYSjxTomlMAgD)
  if OJcpkLfhyXrzneUaFbYSjxTomlMAwR(OJcpkLfhyXrzneUaFbYSjxTomlMAsQ)>0:xbmcplugin.endOfDirectory(OJcpkLfhyXrzneUaFbYSjxTomlMAEI._addon_handle,cacheToDisc=OJcpkLfhyXrzneUaFbYSjxTomlMAwq)
 def dp_Band2Section_List(OJcpkLfhyXrzneUaFbYSjxTomlMAEI,args):
  OJcpkLfhyXrzneUaFbYSjxTomlMAEI.WavveObj.SaveCredential(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.get_winCredential())
  OJcpkLfhyXrzneUaFbYSjxTomlMAvw =args.get('subapi')
  OJcpkLfhyXrzneUaFbYSjxTomlMAsG=OJcpkLfhyXrzneUaFbYSjxTomlMAwv(args.get('page'))
  OJcpkLfhyXrzneUaFbYSjxTomlMAsQ,OJcpkLfhyXrzneUaFbYSjxTomlMAgB=OJcpkLfhyXrzneUaFbYSjxTomlMAEI.WavveObj.Get_Band2Section_List(OJcpkLfhyXrzneUaFbYSjxTomlMAvw,OJcpkLfhyXrzneUaFbYSjxTomlMAsG)
  for OJcpkLfhyXrzneUaFbYSjxTomlMAsd in OJcpkLfhyXrzneUaFbYSjxTomlMAsQ:
   OJcpkLfhyXrzneUaFbYSjxTomlMAgV =OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('programtitle')
   OJcpkLfhyXrzneUaFbYSjxTomlMAsu =OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('episodetitle')
   OJcpkLfhyXrzneUaFbYSjxTomlMAsD={'plot':OJcpkLfhyXrzneUaFbYSjxTomlMAgV+'\n\n'+OJcpkLfhyXrzneUaFbYSjxTomlMAsu,'mpaa':OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('age'),'mediatype':'episode'}
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD={'mode':'VOD','programid':'-','contentid':OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('videoid'),'thumbnail':OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('thumbnail'),'title':OJcpkLfhyXrzneUaFbYSjxTomlMAgV,'subtitle':OJcpkLfhyXrzneUaFbYSjxTomlMAsu}
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.add_dir(OJcpkLfhyXrzneUaFbYSjxTomlMAgV,sublabel=OJcpkLfhyXrzneUaFbYSjxTomlMAsu,img=OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('thumbnail'),infoLabels=OJcpkLfhyXrzneUaFbYSjxTomlMAsD,isFolder=OJcpkLfhyXrzneUaFbYSjxTomlMAwq,params=OJcpkLfhyXrzneUaFbYSjxTomlMAgD)
  if OJcpkLfhyXrzneUaFbYSjxTomlMAgB:
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD={}
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD['mode'] ='BAND2SECTION_LIST' 
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD['subapi']=OJcpkLfhyXrzneUaFbYSjxTomlMAvw
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD['page'] =OJcpkLfhyXrzneUaFbYSjxTomlMAwH(OJcpkLfhyXrzneUaFbYSjxTomlMAsG+1)
   OJcpkLfhyXrzneUaFbYSjxTomlMAgV='[B]%s >>[/B]'%'다음 페이지'
   OJcpkLfhyXrzneUaFbYSjxTomlMAsu=OJcpkLfhyXrzneUaFbYSjxTomlMAwH(OJcpkLfhyXrzneUaFbYSjxTomlMAsG+1)
   OJcpkLfhyXrzneUaFbYSjxTomlMAgH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.add_dir(OJcpkLfhyXrzneUaFbYSjxTomlMAgV,sublabel=OJcpkLfhyXrzneUaFbYSjxTomlMAsu,img=OJcpkLfhyXrzneUaFbYSjxTomlMAgH,infoLabels=OJcpkLfhyXrzneUaFbYSjxTomlMAws,isFolder=OJcpkLfhyXrzneUaFbYSjxTomlMAwC,params=OJcpkLfhyXrzneUaFbYSjxTomlMAgD)
  if OJcpkLfhyXrzneUaFbYSjxTomlMAwR(OJcpkLfhyXrzneUaFbYSjxTomlMAsQ)>0:xbmcplugin.endOfDirectory(OJcpkLfhyXrzneUaFbYSjxTomlMAEI._addon_handle,cacheToDisc=OJcpkLfhyXrzneUaFbYSjxTomlMAwq)
 def dp_Movie_List(OJcpkLfhyXrzneUaFbYSjxTomlMAEI,args):
  OJcpkLfhyXrzneUaFbYSjxTomlMAEI.WavveObj.SaveCredential(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.get_winCredential())
  OJcpkLfhyXrzneUaFbYSjxTomlMAvw =args.get('subapi')
  OJcpkLfhyXrzneUaFbYSjxTomlMAsG=OJcpkLfhyXrzneUaFbYSjxTomlMAwv(args.get('page'))
  OJcpkLfhyXrzneUaFbYSjxTomlMAsQ,OJcpkLfhyXrzneUaFbYSjxTomlMAgB=OJcpkLfhyXrzneUaFbYSjxTomlMAEI.WavveObj.Get_Movie_List(OJcpkLfhyXrzneUaFbYSjxTomlMAvw,OJcpkLfhyXrzneUaFbYSjxTomlMAsG)
  for OJcpkLfhyXrzneUaFbYSjxTomlMAsd in OJcpkLfhyXrzneUaFbYSjxTomlMAsQ:
   OJcpkLfhyXrzneUaFbYSjxTomlMAgV =OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('title')
   OJcpkLfhyXrzneUaFbYSjxTomlMAst=OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('thumbnail')
   OJcpkLfhyXrzneUaFbYSjxTomlMAsK =OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('age')
   if OJcpkLfhyXrzneUaFbYSjxTomlMAsK=='18' or OJcpkLfhyXrzneUaFbYSjxTomlMAsK=='19' or OJcpkLfhyXrzneUaFbYSjxTomlMAsK=='21':OJcpkLfhyXrzneUaFbYSjxTomlMAgV+=' (%s)'%(OJcpkLfhyXrzneUaFbYSjxTomlMAsK)
   OJcpkLfhyXrzneUaFbYSjxTomlMAsD={'plot':OJcpkLfhyXrzneUaFbYSjxTomlMAgV,'mpaa':OJcpkLfhyXrzneUaFbYSjxTomlMAsK,'mediatype':'movie'}
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD={'mode':'MOVIE','contentid':OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('videoid'),'title':OJcpkLfhyXrzneUaFbYSjxTomlMAgV,'thumbnail':OJcpkLfhyXrzneUaFbYSjxTomlMAst,'age':OJcpkLfhyXrzneUaFbYSjxTomlMAsK}
   if OJcpkLfhyXrzneUaFbYSjxTomlMAEI.get_settings_makebookmark():
    OJcpkLfhyXrzneUaFbYSjxTomlMAsW={'videoid':OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('videoid'),'vidtype':'movie','vtitle':OJcpkLfhyXrzneUaFbYSjxTomlMAgV,'vsubtitle':'','contenttype':'programid',}
    OJcpkLfhyXrzneUaFbYSjxTomlMAsi=json.dumps(OJcpkLfhyXrzneUaFbYSjxTomlMAsW)
    OJcpkLfhyXrzneUaFbYSjxTomlMAsi=urllib.parse.quote(OJcpkLfhyXrzneUaFbYSjxTomlMAsi)
    OJcpkLfhyXrzneUaFbYSjxTomlMAsP='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(OJcpkLfhyXrzneUaFbYSjxTomlMAsi)
    OJcpkLfhyXrzneUaFbYSjxTomlMAsH=[('(통합) 찜 영상에 추가',OJcpkLfhyXrzneUaFbYSjxTomlMAsP)]
   else:
    OJcpkLfhyXrzneUaFbYSjxTomlMAsH=OJcpkLfhyXrzneUaFbYSjxTomlMAws
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.add_dir(OJcpkLfhyXrzneUaFbYSjxTomlMAgV,sublabel='',img=OJcpkLfhyXrzneUaFbYSjxTomlMAst,infoLabels=OJcpkLfhyXrzneUaFbYSjxTomlMAsD,isFolder=OJcpkLfhyXrzneUaFbYSjxTomlMAwq,params=OJcpkLfhyXrzneUaFbYSjxTomlMAgD,ContextMenu=OJcpkLfhyXrzneUaFbYSjxTomlMAsH)
  if OJcpkLfhyXrzneUaFbYSjxTomlMAgB:
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD={}
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD['mode'] ='MOVIE_LIST' 
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD['subapi']=OJcpkLfhyXrzneUaFbYSjxTomlMAvw 
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD['page'] =OJcpkLfhyXrzneUaFbYSjxTomlMAwH(OJcpkLfhyXrzneUaFbYSjxTomlMAsG+1)
   OJcpkLfhyXrzneUaFbYSjxTomlMAgV='[B]%s >>[/B]'%'다음 페이지'
   OJcpkLfhyXrzneUaFbYSjxTomlMAsu=OJcpkLfhyXrzneUaFbYSjxTomlMAwH(OJcpkLfhyXrzneUaFbYSjxTomlMAsG+1)
   OJcpkLfhyXrzneUaFbYSjxTomlMAgH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.add_dir(OJcpkLfhyXrzneUaFbYSjxTomlMAgV,sublabel=OJcpkLfhyXrzneUaFbYSjxTomlMAsu,img=OJcpkLfhyXrzneUaFbYSjxTomlMAgH,infoLabels=OJcpkLfhyXrzneUaFbYSjxTomlMAws,isFolder=OJcpkLfhyXrzneUaFbYSjxTomlMAwC,params=OJcpkLfhyXrzneUaFbYSjxTomlMAgD)
  xbmcplugin.setContent(OJcpkLfhyXrzneUaFbYSjxTomlMAEI._addon_handle,'movies')
  if OJcpkLfhyXrzneUaFbYSjxTomlMAwR(OJcpkLfhyXrzneUaFbYSjxTomlMAsQ)>0:xbmcplugin.endOfDirectory(OJcpkLfhyXrzneUaFbYSjxTomlMAEI._addon_handle,cacheToDisc=OJcpkLfhyXrzneUaFbYSjxTomlMAwq)
 def dp_Set_Bookmark(OJcpkLfhyXrzneUaFbYSjxTomlMAEI,args):
  OJcpkLfhyXrzneUaFbYSjxTomlMAvQ=urllib.parse.unquote(args.get('bm_param'))
  OJcpkLfhyXrzneUaFbYSjxTomlMAvQ=json.loads(OJcpkLfhyXrzneUaFbYSjxTomlMAvQ)
  OJcpkLfhyXrzneUaFbYSjxTomlMACE =OJcpkLfhyXrzneUaFbYSjxTomlMAvQ.get('videoid')
  OJcpkLfhyXrzneUaFbYSjxTomlMAvd =OJcpkLfhyXrzneUaFbYSjxTomlMAvQ.get('vidtype')
  OJcpkLfhyXrzneUaFbYSjxTomlMAvt =OJcpkLfhyXrzneUaFbYSjxTomlMAvQ.get('vtitle')
  OJcpkLfhyXrzneUaFbYSjxTomlMAvK =OJcpkLfhyXrzneUaFbYSjxTomlMAvQ.get('vsubtitle')
  OJcpkLfhyXrzneUaFbYSjxTomlMAvW=OJcpkLfhyXrzneUaFbYSjxTomlMAvQ.get('contenttype')
  OJcpkLfhyXrzneUaFbYSjxTomlMAED=xbmcgui.Dialog()
  OJcpkLfhyXrzneUaFbYSjxTomlMACQ=OJcpkLfhyXrzneUaFbYSjxTomlMAED.yesno(__language__(30913).encode('utf8'),OJcpkLfhyXrzneUaFbYSjxTomlMAvt+' \n\n'+__language__(30914))
  if OJcpkLfhyXrzneUaFbYSjxTomlMACQ==OJcpkLfhyXrzneUaFbYSjxTomlMAwq:return
  OJcpkLfhyXrzneUaFbYSjxTomlMAvi=OJcpkLfhyXrzneUaFbYSjxTomlMAEI.WavveObj.GetBookmarkInfo(OJcpkLfhyXrzneUaFbYSjxTomlMACE,OJcpkLfhyXrzneUaFbYSjxTomlMAvd,OJcpkLfhyXrzneUaFbYSjxTomlMAvW)
  OJcpkLfhyXrzneUaFbYSjxTomlMAvP=json.dumps(OJcpkLfhyXrzneUaFbYSjxTomlMAvi)
  OJcpkLfhyXrzneUaFbYSjxTomlMAvP=urllib.parse.quote(OJcpkLfhyXrzneUaFbYSjxTomlMAvP)
  OJcpkLfhyXrzneUaFbYSjxTomlMAsP ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(OJcpkLfhyXrzneUaFbYSjxTomlMAvP)
  xbmc.executebuiltin(OJcpkLfhyXrzneUaFbYSjxTomlMAsP)
 def dp_Episode_List(OJcpkLfhyXrzneUaFbYSjxTomlMAEI,args):
  OJcpkLfhyXrzneUaFbYSjxTomlMAEI.WavveObj.SaveCredential(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.get_winCredential())
  OJcpkLfhyXrzneUaFbYSjxTomlMACE =args.get('videoid')
  OJcpkLfhyXrzneUaFbYSjxTomlMAvd =args.get('vidtype')
  OJcpkLfhyXrzneUaFbYSjxTomlMAsG=OJcpkLfhyXrzneUaFbYSjxTomlMAwv(args.get('page'))
  OJcpkLfhyXrzneUaFbYSjxTomlMAsQ,OJcpkLfhyXrzneUaFbYSjxTomlMAgB=OJcpkLfhyXrzneUaFbYSjxTomlMAEI.WavveObj.Get_Episode_List(OJcpkLfhyXrzneUaFbYSjxTomlMACE,OJcpkLfhyXrzneUaFbYSjxTomlMAvd,OJcpkLfhyXrzneUaFbYSjxTomlMAsG,orderby=OJcpkLfhyXrzneUaFbYSjxTomlMAEI.get_winEpisodeOrderby())
  for OJcpkLfhyXrzneUaFbYSjxTomlMAsd in OJcpkLfhyXrzneUaFbYSjxTomlMAsQ:
   OJcpkLfhyXrzneUaFbYSjxTomlMAsu='%s회, %s(%s)'%(OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('episodenumber'),OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('releasedate'),OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('releaseweekday'))
   OJcpkLfhyXrzneUaFbYSjxTomlMAvu ='[%s]\n\n%s'%(OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('episodetitle'),OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('synopsis'))
   OJcpkLfhyXrzneUaFbYSjxTomlMAsD={'mediatype':'episode','title':OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('programtitle'),'year':OJcpkLfhyXrzneUaFbYSjxTomlMAwv(OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('releasedate')[:4]),'aired':OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('releasedate'),'mpaa':OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('age'),'episode':OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('episodenumber'),'duration':OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('playtime'),'plot':OJcpkLfhyXrzneUaFbYSjxTomlMAvu,'cast':OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('episodeactors')}
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD={'mode':'VOD','programid':OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('programid'),'contentid':OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('contentid'),'thumbnail':OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('thumbnail'),'title':OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('programtitle'),'subtitle':OJcpkLfhyXrzneUaFbYSjxTomlMAsu}
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.add_dir(OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('programtitle'),sublabel=OJcpkLfhyXrzneUaFbYSjxTomlMAsu,img=OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('thumbnail'),infoLabels=OJcpkLfhyXrzneUaFbYSjxTomlMAsD,isFolder=OJcpkLfhyXrzneUaFbYSjxTomlMAwq,params=OJcpkLfhyXrzneUaFbYSjxTomlMAgD)
  if OJcpkLfhyXrzneUaFbYSjxTomlMAsG==1:
   OJcpkLfhyXrzneUaFbYSjxTomlMAsD={'plot':'정렬순서를 변경합니다.'}
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD={}
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD['mode'] ='ORDER_BY' 
   if OJcpkLfhyXrzneUaFbYSjxTomlMAEI.get_winEpisodeOrderby()=='desc':
    OJcpkLfhyXrzneUaFbYSjxTomlMAgV='정렬순서변경 : 최신화부터 -> 1회부터'
    OJcpkLfhyXrzneUaFbYSjxTomlMAgD['orderby']='asc'
   else:
    OJcpkLfhyXrzneUaFbYSjxTomlMAgV='정렬순서변경 : 1회부터 -> 최신화부터'
    OJcpkLfhyXrzneUaFbYSjxTomlMAgD['orderby']='desc'
   OJcpkLfhyXrzneUaFbYSjxTomlMAgH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.add_dir(OJcpkLfhyXrzneUaFbYSjxTomlMAgV,sublabel='',img=OJcpkLfhyXrzneUaFbYSjxTomlMAgH,infoLabels=OJcpkLfhyXrzneUaFbYSjxTomlMAsD,isFolder=OJcpkLfhyXrzneUaFbYSjxTomlMAwq,params=OJcpkLfhyXrzneUaFbYSjxTomlMAgD,isLink=OJcpkLfhyXrzneUaFbYSjxTomlMAwC)
  if OJcpkLfhyXrzneUaFbYSjxTomlMAgB:
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD={}
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD['mode'] ='EPISODE_LIST' 
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD['videoid']=OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('programid')
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD['vidtype']='programid'
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD['page'] =OJcpkLfhyXrzneUaFbYSjxTomlMAwH(OJcpkLfhyXrzneUaFbYSjxTomlMAsG+1)
   OJcpkLfhyXrzneUaFbYSjxTomlMAgV='[B]%s >>[/B]'%'다음 페이지'
   OJcpkLfhyXrzneUaFbYSjxTomlMAsu=OJcpkLfhyXrzneUaFbYSjxTomlMAwH(OJcpkLfhyXrzneUaFbYSjxTomlMAsG+1)
   OJcpkLfhyXrzneUaFbYSjxTomlMAgH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.add_dir(OJcpkLfhyXrzneUaFbYSjxTomlMAgV,sublabel=OJcpkLfhyXrzneUaFbYSjxTomlMAsu,img=OJcpkLfhyXrzneUaFbYSjxTomlMAgH,infoLabels=OJcpkLfhyXrzneUaFbYSjxTomlMAws,isFolder=OJcpkLfhyXrzneUaFbYSjxTomlMAwC,params=OJcpkLfhyXrzneUaFbYSjxTomlMAgD)
  xbmcplugin.setContent(OJcpkLfhyXrzneUaFbYSjxTomlMAEI._addon_handle,'episodes')
  if OJcpkLfhyXrzneUaFbYSjxTomlMAwR(OJcpkLfhyXrzneUaFbYSjxTomlMAsQ)>0:xbmcplugin.endOfDirectory(OJcpkLfhyXrzneUaFbYSjxTomlMAEI._addon_handle,cacheToDisc=OJcpkLfhyXrzneUaFbYSjxTomlMAwq)
 def dp_LiveChannel_List(OJcpkLfhyXrzneUaFbYSjxTomlMAEI,args):
  OJcpkLfhyXrzneUaFbYSjxTomlMAEI.WavveObj.SaveCredential(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.get_winCredential())
  OJcpkLfhyXrzneUaFbYSjxTomlMAvB =args.get('genre')
  OJcpkLfhyXrzneUaFbYSjxTomlMAvq=args.get('baseapi')
  OJcpkLfhyXrzneUaFbYSjxTomlMAsQ=OJcpkLfhyXrzneUaFbYSjxTomlMAEI.WavveObj.Get_LiveChannel_List(OJcpkLfhyXrzneUaFbYSjxTomlMAvB,OJcpkLfhyXrzneUaFbYSjxTomlMAvq)
  for OJcpkLfhyXrzneUaFbYSjxTomlMAsd in OJcpkLfhyXrzneUaFbYSjxTomlMAsQ:
   OJcpkLfhyXrzneUaFbYSjxTomlMAvH =OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('channelid')
   OJcpkLfhyXrzneUaFbYSjxTomlMAvD =OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('studio')
   OJcpkLfhyXrzneUaFbYSjxTomlMAvG=OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('tvshowtitle')
   OJcpkLfhyXrzneUaFbYSjxTomlMAst =OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('thumbnail')
   OJcpkLfhyXrzneUaFbYSjxTomlMAsK =OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('age')
   OJcpkLfhyXrzneUaFbYSjxTomlMAwE =OJcpkLfhyXrzneUaFbYSjxTomlMAsd.get('epg')
   OJcpkLfhyXrzneUaFbYSjxTomlMAsD={'mediatype':'episode','mpaa':OJcpkLfhyXrzneUaFbYSjxTomlMAsK,'title':'%s < %s >'%(OJcpkLfhyXrzneUaFbYSjxTomlMAvD,OJcpkLfhyXrzneUaFbYSjxTomlMAvG),'tvshowtitle':OJcpkLfhyXrzneUaFbYSjxTomlMAvG,'studio':OJcpkLfhyXrzneUaFbYSjxTomlMAvD,'plot':'%s\n\n%s'%(OJcpkLfhyXrzneUaFbYSjxTomlMAvD,OJcpkLfhyXrzneUaFbYSjxTomlMAwE)}
   OJcpkLfhyXrzneUaFbYSjxTomlMAgD={'mode':'LIVE','contentid':OJcpkLfhyXrzneUaFbYSjxTomlMAvH}
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.add_dir(OJcpkLfhyXrzneUaFbYSjxTomlMAvD,sublabel=OJcpkLfhyXrzneUaFbYSjxTomlMAvG,img=OJcpkLfhyXrzneUaFbYSjxTomlMAst,infoLabels=OJcpkLfhyXrzneUaFbYSjxTomlMAsD,isFolder=OJcpkLfhyXrzneUaFbYSjxTomlMAwq,params=OJcpkLfhyXrzneUaFbYSjxTomlMAgD)
  if OJcpkLfhyXrzneUaFbYSjxTomlMAwR(OJcpkLfhyXrzneUaFbYSjxTomlMAsQ)>0:xbmcplugin.endOfDirectory(OJcpkLfhyXrzneUaFbYSjxTomlMAEI._addon_handle,cacheToDisc=OJcpkLfhyXrzneUaFbYSjxTomlMAwq)
 def wavve_main(OJcpkLfhyXrzneUaFbYSjxTomlMAEI):
  OJcpkLfhyXrzneUaFbYSjxTomlMAgi=OJcpkLfhyXrzneUaFbYSjxTomlMAEI.main_params.get('mode',OJcpkLfhyXrzneUaFbYSjxTomlMAws)
  if OJcpkLfhyXrzneUaFbYSjxTomlMAgi=='LOGOUT':
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.logout()
   return
  OJcpkLfhyXrzneUaFbYSjxTomlMAEI.login_main()
  if OJcpkLfhyXrzneUaFbYSjxTomlMAgi is OJcpkLfhyXrzneUaFbYSjxTomlMAws:
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.dp_Main_List()
  elif OJcpkLfhyXrzneUaFbYSjxTomlMAgi in['LIVE','VOD','MOVIE']:
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.play_VIDEO(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.main_params)
  elif OJcpkLfhyXrzneUaFbYSjxTomlMAgi=='LIVE_CATAGORY':
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.dp_LiveCatagory_List(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.main_params)
  elif OJcpkLfhyXrzneUaFbYSjxTomlMAgi=='MAIN_CATAGORY':
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.dp_MainCatagory_List(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.main_params)
  elif OJcpkLfhyXrzneUaFbYSjxTomlMAgi=='SUPERSECTION_LIST':
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.dp_SuperSection_List(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.main_params)
  elif OJcpkLfhyXrzneUaFbYSjxTomlMAgi=='BANDLIVESECTION_LIST':
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.dp_BandLiveSection_List(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.main_params)
  elif OJcpkLfhyXrzneUaFbYSjxTomlMAgi=='BAND2SECTION_LIST':
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.dp_Band2Section_List(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.main_params)
  elif OJcpkLfhyXrzneUaFbYSjxTomlMAgi=='PROGRAM_LIST':
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.dp_Program_List(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.main_params)
  elif OJcpkLfhyXrzneUaFbYSjxTomlMAgi=='EPISODE_LIST':
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.dp_Episode_List(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.main_params)
  elif OJcpkLfhyXrzneUaFbYSjxTomlMAgi=='MOVIE_LIST':
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.dp_Movie_List(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.main_params)
  elif OJcpkLfhyXrzneUaFbYSjxTomlMAgi=='LIVE_LIST':
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.dp_LiveChannel_List(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.main_params)
  elif OJcpkLfhyXrzneUaFbYSjxTomlMAgi=='ORDER_BY':
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.dp_setEpOrderby(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.main_params)
  elif OJcpkLfhyXrzneUaFbYSjxTomlMAgi=='SEARCH_GROUP':
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.dp_Search_Group(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.main_params)
  elif OJcpkLfhyXrzneUaFbYSjxTomlMAgi in['SEARCH_LIST','LOCAL_SEARCH']:
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.dp_Search_List(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.main_params)
  elif OJcpkLfhyXrzneUaFbYSjxTomlMAgi=='WATCH_GROUP':
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.dp_Watch_Group(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.main_params)
  elif OJcpkLfhyXrzneUaFbYSjxTomlMAgi=='WATCH_LIST':
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.dp_Watch_List(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.main_params)
  elif OJcpkLfhyXrzneUaFbYSjxTomlMAgi=='SET_BOOKMARK':
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.dp_Set_Bookmark(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.main_params)
  elif OJcpkLfhyXrzneUaFbYSjxTomlMAgi in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.dp_Listfile_Delete(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.main_params)
  elif OJcpkLfhyXrzneUaFbYSjxTomlMAgi in['TOTAL_SEARCH','TOTAL_HISTORY']:
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.dp_Global_Search(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.main_params)
  elif OJcpkLfhyXrzneUaFbYSjxTomlMAgi=='SEARCH_HISTORY':
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.dp_Search_History(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.main_params)
  elif OJcpkLfhyXrzneUaFbYSjxTomlMAgi=='MENU_BOOKMARK':
   OJcpkLfhyXrzneUaFbYSjxTomlMAEI.dp_Bookmark_Menu(OJcpkLfhyXrzneUaFbYSjxTomlMAEI.main_params)
  else:
   OJcpkLfhyXrzneUaFbYSjxTomlMAws
# Created by pyminifier (https://github.com/liftoff/pyminifier)
