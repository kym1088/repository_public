__author__="NightRain"
VjzgNqcRxQlpWBuOyXAwivMmUsoEKd=object
VjzgNqcRxQlpWBuOyXAwivMmUsoEKb=None
VjzgNqcRxQlpWBuOyXAwivMmUsoEKa=int
VjzgNqcRxQlpWBuOyXAwivMmUsoEKI=True
VjzgNqcRxQlpWBuOyXAwivMmUsoEKY=False
VjzgNqcRxQlpWBuOyXAwivMmUsoEKk=type
VjzgNqcRxQlpWBuOyXAwivMmUsoEKT=dict
VjzgNqcRxQlpWBuOyXAwivMmUsoEKf=len
VjzgNqcRxQlpWBuOyXAwivMmUsoESe=range
VjzgNqcRxQlpWBuOyXAwivMmUsoESL=str
VjzgNqcRxQlpWBuOyXAwivMmUsoESG=open
VjzgNqcRxQlpWBuOyXAwivMmUsoESD=Exception
VjzgNqcRxQlpWBuOyXAwivMmUsoESn=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import json
VjzgNqcRxQlpWBuOyXAwivMmUsoEeG=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://www.wavve.com/supermultisection/GN51','icon':'home.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&offset=0&limit=20&uicode=VN500','page':'1','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=01&WeekDay=all&uitype=VN4&uiparent=FN0&uirank=0&broadcastid=847243&uicode=VN4','page':'1','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=02&WeekDay=all&uitype=VN3&uiparent=FN0&uirank=0&broadcastid=783664&uicode=VN3','page':'1','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'1','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'paid','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'displaystart','ordernm':'업데이트순','icon':''},{'title':'프로야구 - 경기중 시청가능','mode':'GAME_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'(웨이브) 검색','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'(웨이브) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
VjzgNqcRxQlpWBuOyXAwivMmUsoEeD=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
VjzgNqcRxQlpWBuOyXAwivMmUsoEen=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
VjzgNqcRxQlpWBuOyXAwivMmUsoEer =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
VjzgNqcRxQlpWBuOyXAwivMmUsoEeK=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_searched.txt'))
from wavveCore import*
class VjzgNqcRxQlpWBuOyXAwivMmUsoEeL(VjzgNqcRxQlpWBuOyXAwivMmUsoEKd):
 def __init__(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS,VjzgNqcRxQlpWBuOyXAwivMmUsoEeC,VjzgNqcRxQlpWBuOyXAwivMmUsoEet,VjzgNqcRxQlpWBuOyXAwivMmUsoEeH):
  VjzgNqcRxQlpWBuOyXAwivMmUsoEeS._addon_url =VjzgNqcRxQlpWBuOyXAwivMmUsoEeC
  VjzgNqcRxQlpWBuOyXAwivMmUsoEeS._addon_handle=VjzgNqcRxQlpWBuOyXAwivMmUsoEet
  VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.main_params =VjzgNqcRxQlpWBuOyXAwivMmUsoEeH
  VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.WavveObj =aerFXvzkPtSBTNwjlUohROxGJDIKCQ() 
 def addon_noti(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS,sting):
  try:
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeJ=xbmcgui.Dialog()
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeJ.notification(__addonname__,sting)
  except:
   VjzgNqcRxQlpWBuOyXAwivMmUsoEKb
 def addon_log(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS,string):
  try:
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeh=string.encode('utf-8','ignore')
  except:
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeh='addonException: addon_log'
  VjzgNqcRxQlpWBuOyXAwivMmUsoEeP=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,VjzgNqcRxQlpWBuOyXAwivMmUsoEeh),level=VjzgNqcRxQlpWBuOyXAwivMmUsoEeP)
 def get_keyboard_input(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS,VjzgNqcRxQlpWBuOyXAwivMmUsoELC):
  VjzgNqcRxQlpWBuOyXAwivMmUsoEed=VjzgNqcRxQlpWBuOyXAwivMmUsoEKb
  kb=xbmc.Keyboard()
  kb.setHeading(VjzgNqcRxQlpWBuOyXAwivMmUsoELC)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   VjzgNqcRxQlpWBuOyXAwivMmUsoEed=kb.getText()
  return VjzgNqcRxQlpWBuOyXAwivMmUsoEed
 def get_settings_account(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS):
  VjzgNqcRxQlpWBuOyXAwivMmUsoEeb =__addon__.getSetting('id')
  VjzgNqcRxQlpWBuOyXAwivMmUsoEea =__addon__.getSetting('pw')
  VjzgNqcRxQlpWBuOyXAwivMmUsoEeI=VjzgNqcRxQlpWBuOyXAwivMmUsoEKa(__addon__.getSetting('selected_profile'))
  return(VjzgNqcRxQlpWBuOyXAwivMmUsoEeb,VjzgNqcRxQlpWBuOyXAwivMmUsoEea,VjzgNqcRxQlpWBuOyXAwivMmUsoEeI)
 def get_settings_totalsearch(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS):
  VjzgNqcRxQlpWBuOyXAwivMmUsoEeY =VjzgNqcRxQlpWBuOyXAwivMmUsoEKI if __addon__.getSetting('local_search')=='true' else VjzgNqcRxQlpWBuOyXAwivMmUsoEKY
  VjzgNqcRxQlpWBuOyXAwivMmUsoEek=VjzgNqcRxQlpWBuOyXAwivMmUsoEKI if __addon__.getSetting('local_history')=='true' else VjzgNqcRxQlpWBuOyXAwivMmUsoEKY
  VjzgNqcRxQlpWBuOyXAwivMmUsoEeT =VjzgNqcRxQlpWBuOyXAwivMmUsoEKI if __addon__.getSetting('total_search')=='true' else VjzgNqcRxQlpWBuOyXAwivMmUsoEKY
  VjzgNqcRxQlpWBuOyXAwivMmUsoEef=VjzgNqcRxQlpWBuOyXAwivMmUsoEKI if __addon__.getSetting('total_history')=='true' else VjzgNqcRxQlpWBuOyXAwivMmUsoEKY
  VjzgNqcRxQlpWBuOyXAwivMmUsoELe=VjzgNqcRxQlpWBuOyXAwivMmUsoEKI if __addon__.getSetting('menu_bookmark')=='true' else VjzgNqcRxQlpWBuOyXAwivMmUsoEKY
  return(VjzgNqcRxQlpWBuOyXAwivMmUsoEeY,VjzgNqcRxQlpWBuOyXAwivMmUsoEek,VjzgNqcRxQlpWBuOyXAwivMmUsoEeT,VjzgNqcRxQlpWBuOyXAwivMmUsoEef,VjzgNqcRxQlpWBuOyXAwivMmUsoELe)
 def get_settings_makebookmark(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS):
  return VjzgNqcRxQlpWBuOyXAwivMmUsoEKI if __addon__.getSetting('make_bookmark')=='true' else VjzgNqcRxQlpWBuOyXAwivMmUsoEKY
 def get_selQuality(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS):
  try:
   VjzgNqcRxQlpWBuOyXAwivMmUsoELG=[1080,720,480,360]
   VjzgNqcRxQlpWBuOyXAwivMmUsoELD=VjzgNqcRxQlpWBuOyXAwivMmUsoEKa(__addon__.getSetting('selected_quality'))
   return VjzgNqcRxQlpWBuOyXAwivMmUsoELG[VjzgNqcRxQlpWBuOyXAwivMmUsoELD]
  except:
   VjzgNqcRxQlpWBuOyXAwivMmUsoEKb
  return 1080 
 def get_settings_exclusion21(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS):
  VjzgNqcRxQlpWBuOyXAwivMmUsoELn =__addon__.getSetting('exclusion21')
  if VjzgNqcRxQlpWBuOyXAwivMmUsoELn=='false':
   return VjzgNqcRxQlpWBuOyXAwivMmUsoEKY
  else:
   return VjzgNqcRxQlpWBuOyXAwivMmUsoEKI
 def get_settings_direct_replay(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS):
  VjzgNqcRxQlpWBuOyXAwivMmUsoELr=VjzgNqcRxQlpWBuOyXAwivMmUsoEKa(__addon__.getSetting('direct_replay'))
  if VjzgNqcRxQlpWBuOyXAwivMmUsoELr==0:
   return VjzgNqcRxQlpWBuOyXAwivMmUsoEKY
  else:
   return VjzgNqcRxQlpWBuOyXAwivMmUsoEKI
 def set_winEpisodeOrderby(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS,VjzgNqcRxQlpWBuOyXAwivMmUsoELK):
  __addon__.setSetting('wavve_orderby',VjzgNqcRxQlpWBuOyXAwivMmUsoELK)
 def get_winEpisodeOrderby(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS):
  VjzgNqcRxQlpWBuOyXAwivMmUsoELK=__addon__.getSetting('wavve_orderby')
  if VjzgNqcRxQlpWBuOyXAwivMmUsoELK in['',VjzgNqcRxQlpWBuOyXAwivMmUsoEKb]:VjzgNqcRxQlpWBuOyXAwivMmUsoELK='desc'
  return VjzgNqcRxQlpWBuOyXAwivMmUsoELK
 def add_dir(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS,label,sublabel='',img='',infoLabels=VjzgNqcRxQlpWBuOyXAwivMmUsoEKb,isFolder=VjzgNqcRxQlpWBuOyXAwivMmUsoEKI,params='',isLink=VjzgNqcRxQlpWBuOyXAwivMmUsoEKY,ContextMenu=VjzgNqcRxQlpWBuOyXAwivMmUsoEKb):
  VjzgNqcRxQlpWBuOyXAwivMmUsoELS='%s?%s'%(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS._addon_url,urllib.parse.urlencode(params))
  if sublabel:VjzgNqcRxQlpWBuOyXAwivMmUsoELC='%s < %s >'%(label,sublabel)
  else: VjzgNqcRxQlpWBuOyXAwivMmUsoELC=label
  if not img:img='DefaultFolder.png'
  VjzgNqcRxQlpWBuOyXAwivMmUsoELt=xbmcgui.ListItem(VjzgNqcRxQlpWBuOyXAwivMmUsoELC)
  if VjzgNqcRxQlpWBuOyXAwivMmUsoEKk(img)==VjzgNqcRxQlpWBuOyXAwivMmUsoEKT:
   VjzgNqcRxQlpWBuOyXAwivMmUsoELt.setArt(img)
  else:
   VjzgNqcRxQlpWBuOyXAwivMmUsoELt.setArt({'thumb':img,'poster':img})
  if infoLabels:VjzgNqcRxQlpWBuOyXAwivMmUsoELt.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   VjzgNqcRxQlpWBuOyXAwivMmUsoELt.setProperty('IsPlayable','true')
  if ContextMenu:VjzgNqcRxQlpWBuOyXAwivMmUsoELt.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS._addon_handle,VjzgNqcRxQlpWBuOyXAwivMmUsoELS,VjzgNqcRxQlpWBuOyXAwivMmUsoELt,isFolder)
 def dp_Main_List(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS):
  (VjzgNqcRxQlpWBuOyXAwivMmUsoEeY,VjzgNqcRxQlpWBuOyXAwivMmUsoEek,VjzgNqcRxQlpWBuOyXAwivMmUsoEeT,VjzgNqcRxQlpWBuOyXAwivMmUsoEef,VjzgNqcRxQlpWBuOyXAwivMmUsoELe)=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.get_settings_totalsearch()
  for VjzgNqcRxQlpWBuOyXAwivMmUsoELH in VjzgNqcRxQlpWBuOyXAwivMmUsoEeG:
   VjzgNqcRxQlpWBuOyXAwivMmUsoELC=VjzgNqcRxQlpWBuOyXAwivMmUsoELH.get('title')
   VjzgNqcRxQlpWBuOyXAwivMmUsoELF=''
   if VjzgNqcRxQlpWBuOyXAwivMmUsoELH.get('mode')=='SEARCH_GROUP' and VjzgNqcRxQlpWBuOyXAwivMmUsoEeY ==VjzgNqcRxQlpWBuOyXAwivMmUsoEKY:continue
   elif VjzgNqcRxQlpWBuOyXAwivMmUsoELH.get('mode')=='SEARCH_HISTORY' and VjzgNqcRxQlpWBuOyXAwivMmUsoEek==VjzgNqcRxQlpWBuOyXAwivMmUsoEKY:continue
   elif VjzgNqcRxQlpWBuOyXAwivMmUsoELH.get('mode')=='TOTAL_SEARCH' and VjzgNqcRxQlpWBuOyXAwivMmUsoEeT ==VjzgNqcRxQlpWBuOyXAwivMmUsoEKY:continue
   elif VjzgNqcRxQlpWBuOyXAwivMmUsoELH.get('mode')=='TOTAL_HISTORY' and VjzgNqcRxQlpWBuOyXAwivMmUsoEef==VjzgNqcRxQlpWBuOyXAwivMmUsoEKY:continue
   elif VjzgNqcRxQlpWBuOyXAwivMmUsoELH.get('mode')=='MENU_BOOKMARK' and VjzgNqcRxQlpWBuOyXAwivMmUsoELe==VjzgNqcRxQlpWBuOyXAwivMmUsoEKY:continue
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ={'mode':VjzgNqcRxQlpWBuOyXAwivMmUsoELH.get('mode'),'sCode':VjzgNqcRxQlpWBuOyXAwivMmUsoELH.get('sCode'),'sIndex':VjzgNqcRxQlpWBuOyXAwivMmUsoELH.get('sIndex'),'sType':VjzgNqcRxQlpWBuOyXAwivMmUsoELH.get('sType'),'suburl':VjzgNqcRxQlpWBuOyXAwivMmUsoELH.get('suburl'),'subapi':VjzgNqcRxQlpWBuOyXAwivMmUsoELH.get('subapi'),'page':VjzgNqcRxQlpWBuOyXAwivMmUsoELH.get('page'),'orderby':VjzgNqcRxQlpWBuOyXAwivMmUsoELH.get('orderby'),'ordernm':VjzgNqcRxQlpWBuOyXAwivMmUsoELH.get('ordernm')}
   if VjzgNqcRxQlpWBuOyXAwivMmUsoELH.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    VjzgNqcRxQlpWBuOyXAwivMmUsoELh=VjzgNqcRxQlpWBuOyXAwivMmUsoEKY
    VjzgNqcRxQlpWBuOyXAwivMmUsoELP =VjzgNqcRxQlpWBuOyXAwivMmUsoEKI
   else:
    VjzgNqcRxQlpWBuOyXAwivMmUsoELh=VjzgNqcRxQlpWBuOyXAwivMmUsoEKI
    VjzgNqcRxQlpWBuOyXAwivMmUsoELP =VjzgNqcRxQlpWBuOyXAwivMmUsoEKY
   if 'icon' in VjzgNqcRxQlpWBuOyXAwivMmUsoELH:VjzgNqcRxQlpWBuOyXAwivMmUsoELF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',VjzgNqcRxQlpWBuOyXAwivMmUsoELH.get('icon')) 
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.add_dir(VjzgNqcRxQlpWBuOyXAwivMmUsoELC,sublabel='',img=VjzgNqcRxQlpWBuOyXAwivMmUsoELF,infoLabels=VjzgNqcRxQlpWBuOyXAwivMmUsoEKb,isFolder=VjzgNqcRxQlpWBuOyXAwivMmUsoELh,params=VjzgNqcRxQlpWBuOyXAwivMmUsoELJ,isLink=VjzgNqcRxQlpWBuOyXAwivMmUsoELP)
  xbmcplugin.endOfDirectory(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS._addon_handle,cacheToDisc=VjzgNqcRxQlpWBuOyXAwivMmUsoEKI)
 def dp_Search_Group(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS,args):
  if 'search_key' in args:
   VjzgNqcRxQlpWBuOyXAwivMmUsoELa=args.get('search_key')
  else:
   VjzgNqcRxQlpWBuOyXAwivMmUsoELa=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not VjzgNqcRxQlpWBuOyXAwivMmUsoELa:
    return
  for VjzgNqcRxQlpWBuOyXAwivMmUsoELI in VjzgNqcRxQlpWBuOyXAwivMmUsoEeD:
   VjzgNqcRxQlpWBuOyXAwivMmUsoELY =VjzgNqcRxQlpWBuOyXAwivMmUsoELI.get('mode')
   VjzgNqcRxQlpWBuOyXAwivMmUsoELk=VjzgNqcRxQlpWBuOyXAwivMmUsoELI.get('sType')
   VjzgNqcRxQlpWBuOyXAwivMmUsoELC=VjzgNqcRxQlpWBuOyXAwivMmUsoELI.get('title')
   (VjzgNqcRxQlpWBuOyXAwivMmUsoELT,VjzgNqcRxQlpWBuOyXAwivMmUsoELf)=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.WavveObj.Get_Search_List(VjzgNqcRxQlpWBuOyXAwivMmUsoELa,VjzgNqcRxQlpWBuOyXAwivMmUsoELk,1,exclusion21=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.get_settings_exclusion21())
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGe={'plot':'검색어 : '+VjzgNqcRxQlpWBuOyXAwivMmUsoELa+'\n\n'+VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.Search_FreeList(VjzgNqcRxQlpWBuOyXAwivMmUsoELT)}
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ={'mode':VjzgNqcRxQlpWBuOyXAwivMmUsoELY,'sType':VjzgNqcRxQlpWBuOyXAwivMmUsoELk,'search_key':VjzgNqcRxQlpWBuOyXAwivMmUsoELa,'page':'1',}
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.add_dir(VjzgNqcRxQlpWBuOyXAwivMmUsoELC,sublabel='',img='',infoLabels=VjzgNqcRxQlpWBuOyXAwivMmUsoEGe,isFolder=VjzgNqcRxQlpWBuOyXAwivMmUsoEKI,params=VjzgNqcRxQlpWBuOyXAwivMmUsoELJ)
  if VjzgNqcRxQlpWBuOyXAwivMmUsoEKf(VjzgNqcRxQlpWBuOyXAwivMmUsoEeD)>0:xbmcplugin.endOfDirectory(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS._addon_handle,cacheToDisc=VjzgNqcRxQlpWBuOyXAwivMmUsoEKI)
  VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.Save_Searched_List(VjzgNqcRxQlpWBuOyXAwivMmUsoELa)
 def Search_FreeList(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS,search_list):
  VjzgNqcRxQlpWBuOyXAwivMmUsoEGL=''
  VjzgNqcRxQlpWBuOyXAwivMmUsoEGD=7
  try:
   if VjzgNqcRxQlpWBuOyXAwivMmUsoEKf(search_list)==0:return '검색결과 없음'
   for i in VjzgNqcRxQlpWBuOyXAwivMmUsoESe(VjzgNqcRxQlpWBuOyXAwivMmUsoEKf(search_list)):
    if i>=VjzgNqcRxQlpWBuOyXAwivMmUsoEGD:
     VjzgNqcRxQlpWBuOyXAwivMmUsoEGL=VjzgNqcRxQlpWBuOyXAwivMmUsoEGL+'...'
     break
    VjzgNqcRxQlpWBuOyXAwivMmUsoEGL=VjzgNqcRxQlpWBuOyXAwivMmUsoEGL+search_list[i]['title']+'\n'
  except:
   return ''
  return VjzgNqcRxQlpWBuOyXAwivMmUsoEGL
 def dp_Watch_Group(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS,args):
  for VjzgNqcRxQlpWBuOyXAwivMmUsoEGn in VjzgNqcRxQlpWBuOyXAwivMmUsoEen:
   VjzgNqcRxQlpWBuOyXAwivMmUsoELC=VjzgNqcRxQlpWBuOyXAwivMmUsoEGn.get('title')
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ={'mode':VjzgNqcRxQlpWBuOyXAwivMmUsoEGn.get('mode'),'sType':VjzgNqcRxQlpWBuOyXAwivMmUsoEGn.get('sType')}
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.add_dir(VjzgNqcRxQlpWBuOyXAwivMmUsoELC,sublabel='',img='',infoLabels=VjzgNqcRxQlpWBuOyXAwivMmUsoEKb,isFolder=VjzgNqcRxQlpWBuOyXAwivMmUsoEKI,params=VjzgNqcRxQlpWBuOyXAwivMmUsoELJ)
  if VjzgNqcRxQlpWBuOyXAwivMmUsoEKf(VjzgNqcRxQlpWBuOyXAwivMmUsoEen)>0:xbmcplugin.endOfDirectory(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS._addon_handle,cacheToDisc=VjzgNqcRxQlpWBuOyXAwivMmUsoEKI)
 def dp_Search_History(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS,args):
  VjzgNqcRxQlpWBuOyXAwivMmUsoEGr=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.Load_List_File('search')
  for VjzgNqcRxQlpWBuOyXAwivMmUsoEGK in VjzgNqcRxQlpWBuOyXAwivMmUsoEGr:
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGS=VjzgNqcRxQlpWBuOyXAwivMmUsoEKT(urllib.parse.parse_qsl(VjzgNqcRxQlpWBuOyXAwivMmUsoEGK))
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGC=VjzgNqcRxQlpWBuOyXAwivMmUsoEGS.get('skey').strip()
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ={'mode':'SEARCH_GROUP','search_key':VjzgNqcRxQlpWBuOyXAwivMmUsoEGC,}
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGt={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':VjzgNqcRxQlpWBuOyXAwivMmUsoEGC,'vType':'-',}
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGH=urllib.parse.urlencode(VjzgNqcRxQlpWBuOyXAwivMmUsoEGt)
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGF=[('선택된 검색어 ( %s ) 삭제'%(VjzgNqcRxQlpWBuOyXAwivMmUsoEGC),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(VjzgNqcRxQlpWBuOyXAwivMmUsoEGH))]
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.add_dir(VjzgNqcRxQlpWBuOyXAwivMmUsoEGC,sublabel='',img=VjzgNqcRxQlpWBuOyXAwivMmUsoEKb,infoLabels=VjzgNqcRxQlpWBuOyXAwivMmUsoEKb,isFolder=VjzgNqcRxQlpWBuOyXAwivMmUsoEKI,params=VjzgNqcRxQlpWBuOyXAwivMmUsoELJ,ContextMenu=VjzgNqcRxQlpWBuOyXAwivMmUsoEGF)
  VjzgNqcRxQlpWBuOyXAwivMmUsoEGJ={'plot':'검색목록 전체를 삭제합니다.'}
  VjzgNqcRxQlpWBuOyXAwivMmUsoELC='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  VjzgNqcRxQlpWBuOyXAwivMmUsoELJ={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  VjzgNqcRxQlpWBuOyXAwivMmUsoELF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.add_dir(VjzgNqcRxQlpWBuOyXAwivMmUsoELC,sublabel='',img=VjzgNqcRxQlpWBuOyXAwivMmUsoELF,infoLabels=VjzgNqcRxQlpWBuOyXAwivMmUsoEGJ,isFolder=VjzgNqcRxQlpWBuOyXAwivMmUsoEKY,params=VjzgNqcRxQlpWBuOyXAwivMmUsoELJ,isLink=VjzgNqcRxQlpWBuOyXAwivMmUsoEKI)
  xbmcplugin.endOfDirectory(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS._addon_handle,cacheToDisc=VjzgNqcRxQlpWBuOyXAwivMmUsoEKY)
 def dp_Search_List(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS,args):
  VjzgNqcRxQlpWBuOyXAwivMmUsoELk =args.get('sType')
  VjzgNqcRxQlpWBuOyXAwivMmUsoEGh =VjzgNqcRxQlpWBuOyXAwivMmUsoEKa(args.get('page'))
  if 'search_key' in args:
   VjzgNqcRxQlpWBuOyXAwivMmUsoELa=args.get('search_key')
  else:
   VjzgNqcRxQlpWBuOyXAwivMmUsoELa=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not VjzgNqcRxQlpWBuOyXAwivMmUsoELa:
    xbmcplugin.endOfDirectory(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS._addon_handle)
    return
  VjzgNqcRxQlpWBuOyXAwivMmUsoEGP,VjzgNqcRxQlpWBuOyXAwivMmUsoELf=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.WavveObj.Get_Search_List(VjzgNqcRxQlpWBuOyXAwivMmUsoELa,VjzgNqcRxQlpWBuOyXAwivMmUsoELk,VjzgNqcRxQlpWBuOyXAwivMmUsoEGh,exclusion21=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.get_settings_exclusion21())
  for VjzgNqcRxQlpWBuOyXAwivMmUsoEGd in VjzgNqcRxQlpWBuOyXAwivMmUsoEGP:
   VjzgNqcRxQlpWBuOyXAwivMmUsoELC =VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('title')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGb=VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('thumbnail')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGa =VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('age')
   if VjzgNqcRxQlpWBuOyXAwivMmUsoEGa=='18' or VjzgNqcRxQlpWBuOyXAwivMmUsoEGa=='19' or VjzgNqcRxQlpWBuOyXAwivMmUsoEGa=='21':VjzgNqcRxQlpWBuOyXAwivMmUsoELC+=' (%s)'%(VjzgNqcRxQlpWBuOyXAwivMmUsoEGa)
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGJ={'mediatype':'tvshow' if VjzgNqcRxQlpWBuOyXAwivMmUsoELk=='vod' else 'movie','mpaa':VjzgNqcRxQlpWBuOyXAwivMmUsoEGa,'title':VjzgNqcRxQlpWBuOyXAwivMmUsoELC,'plot':VjzgNqcRxQlpWBuOyXAwivMmUsoELC}
   if VjzgNqcRxQlpWBuOyXAwivMmUsoELk=='vod':
    VjzgNqcRxQlpWBuOyXAwivMmUsoELJ={'mode':'EPISODE_LIST','videoid':VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('videoid'),'vidtype':VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('vidtype'),'page':'1'}
    VjzgNqcRxQlpWBuOyXAwivMmUsoELh=VjzgNqcRxQlpWBuOyXAwivMmUsoEKI
   else:
    VjzgNqcRxQlpWBuOyXAwivMmUsoELJ={'mode':'MOVIE','contentid':VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('videoid'),'title':VjzgNqcRxQlpWBuOyXAwivMmUsoELC,'thumbnail':VjzgNqcRxQlpWBuOyXAwivMmUsoEGb,'age':VjzgNqcRxQlpWBuOyXAwivMmUsoEGa}
    VjzgNqcRxQlpWBuOyXAwivMmUsoELh=VjzgNqcRxQlpWBuOyXAwivMmUsoEKY
   if VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.get_settings_makebookmark():
    VjzgNqcRxQlpWBuOyXAwivMmUsoEGI={'videoid':VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('videoid'),'vidtype':'tvshow' if VjzgNqcRxQlpWBuOyXAwivMmUsoELk=='vod' else 'movie','vtitle':VjzgNqcRxQlpWBuOyXAwivMmUsoELC,'vsubtitle':'','contenttype':VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('vidtype'),}
    VjzgNqcRxQlpWBuOyXAwivMmUsoEGY=json.dumps(VjzgNqcRxQlpWBuOyXAwivMmUsoEGI)
    VjzgNqcRxQlpWBuOyXAwivMmUsoEGY=urllib.parse.quote(VjzgNqcRxQlpWBuOyXAwivMmUsoEGY)
    VjzgNqcRxQlpWBuOyXAwivMmUsoEGk='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(VjzgNqcRxQlpWBuOyXAwivMmUsoEGY)
    VjzgNqcRxQlpWBuOyXAwivMmUsoEGF=[('(통합) 찜 영상에 추가',VjzgNqcRxQlpWBuOyXAwivMmUsoEGk)]
   else:
    VjzgNqcRxQlpWBuOyXAwivMmUsoEGF=VjzgNqcRxQlpWBuOyXAwivMmUsoEKb
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.add_dir(VjzgNqcRxQlpWBuOyXAwivMmUsoELC,sublabel='',img=VjzgNqcRxQlpWBuOyXAwivMmUsoEGb,infoLabels=VjzgNqcRxQlpWBuOyXAwivMmUsoEGJ,isFolder=VjzgNqcRxQlpWBuOyXAwivMmUsoELh,params=VjzgNqcRxQlpWBuOyXAwivMmUsoELJ,ContextMenu=VjzgNqcRxQlpWBuOyXAwivMmUsoEGF)
  if VjzgNqcRxQlpWBuOyXAwivMmUsoELf:
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ['mode'] ='SEARCH_LIST' 
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ['sType']=VjzgNqcRxQlpWBuOyXAwivMmUsoELk 
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ['page'] =VjzgNqcRxQlpWBuOyXAwivMmUsoESL(VjzgNqcRxQlpWBuOyXAwivMmUsoEGh+1)
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ['search_key']=VjzgNqcRxQlpWBuOyXAwivMmUsoELa
   VjzgNqcRxQlpWBuOyXAwivMmUsoELC='[B]%s >>[/B]'%'다음 페이지'
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGT=VjzgNqcRxQlpWBuOyXAwivMmUsoESL(VjzgNqcRxQlpWBuOyXAwivMmUsoEGh+1)
   VjzgNqcRxQlpWBuOyXAwivMmUsoELF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.add_dir(VjzgNqcRxQlpWBuOyXAwivMmUsoELC,sublabel=VjzgNqcRxQlpWBuOyXAwivMmUsoEGT,img=VjzgNqcRxQlpWBuOyXAwivMmUsoELF,infoLabels=VjzgNqcRxQlpWBuOyXAwivMmUsoEKb,isFolder=VjzgNqcRxQlpWBuOyXAwivMmUsoEKI,params=VjzgNqcRxQlpWBuOyXAwivMmUsoELJ)
  if VjzgNqcRxQlpWBuOyXAwivMmUsoELk=='movie':xbmcplugin.setContent(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS._addon_handle,'movies')
  else:xbmcplugin.setContent(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS._addon_handle,cacheToDisc=VjzgNqcRxQlpWBuOyXAwivMmUsoEKY)
 def dp_Watch_List(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS,args):
  VjzgNqcRxQlpWBuOyXAwivMmUsoELk =args.get('sType')
  VjzgNqcRxQlpWBuOyXAwivMmUsoELr=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.get_settings_direct_replay()
  VjzgNqcRxQlpWBuOyXAwivMmUsoEGP=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.Load_List_File(VjzgNqcRxQlpWBuOyXAwivMmUsoELk)
  for VjzgNqcRxQlpWBuOyXAwivMmUsoEGd in VjzgNqcRxQlpWBuOyXAwivMmUsoEGP:
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGS=VjzgNqcRxQlpWBuOyXAwivMmUsoEKT(urllib.parse.parse_qsl(VjzgNqcRxQlpWBuOyXAwivMmUsoEGd))
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGf =VjzgNqcRxQlpWBuOyXAwivMmUsoEGS.get('code').strip()
   VjzgNqcRxQlpWBuOyXAwivMmUsoELC =VjzgNqcRxQlpWBuOyXAwivMmUsoEGS.get('title').strip()
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGT =VjzgNqcRxQlpWBuOyXAwivMmUsoEGS.get('subtitle').strip()
   if VjzgNqcRxQlpWBuOyXAwivMmUsoEGT=='None':VjzgNqcRxQlpWBuOyXAwivMmUsoEGT=''
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGb=VjzgNqcRxQlpWBuOyXAwivMmUsoEGS.get('img').strip()
   VjzgNqcRxQlpWBuOyXAwivMmUsoEDe =VjzgNqcRxQlpWBuOyXAwivMmUsoEGS.get('videoid').strip()
   try:
    VjzgNqcRxQlpWBuOyXAwivMmUsoEGb=VjzgNqcRxQlpWBuOyXAwivMmUsoEGb.replace('\'','\"')
    VjzgNqcRxQlpWBuOyXAwivMmUsoEGb=json.loads(VjzgNqcRxQlpWBuOyXAwivMmUsoEGb)
   except:
    VjzgNqcRxQlpWBuOyXAwivMmUsoEKb
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGJ={'plot':'%s\n%s'%(VjzgNqcRxQlpWBuOyXAwivMmUsoELC,VjzgNqcRxQlpWBuOyXAwivMmUsoEGT)}
   if VjzgNqcRxQlpWBuOyXAwivMmUsoELk=='vod':
    if VjzgNqcRxQlpWBuOyXAwivMmUsoELr==VjzgNqcRxQlpWBuOyXAwivMmUsoEKY or VjzgNqcRxQlpWBuOyXAwivMmUsoEDe==VjzgNqcRxQlpWBuOyXAwivMmUsoEKb:
     VjzgNqcRxQlpWBuOyXAwivMmUsoELJ={'mode':'EPISODE_LIST','videoid':VjzgNqcRxQlpWBuOyXAwivMmUsoEGf,'vidtype':'programid','page':'1'}
     VjzgNqcRxQlpWBuOyXAwivMmUsoELh=VjzgNqcRxQlpWBuOyXAwivMmUsoEKI
    else:
     VjzgNqcRxQlpWBuOyXAwivMmUsoELJ={'mode':'VOD','programid':VjzgNqcRxQlpWBuOyXAwivMmUsoEGf,'contentid':VjzgNqcRxQlpWBuOyXAwivMmUsoEDe,'title':VjzgNqcRxQlpWBuOyXAwivMmUsoELC,'subtitle':VjzgNqcRxQlpWBuOyXAwivMmUsoEGT,'thumbnail':VjzgNqcRxQlpWBuOyXAwivMmUsoEGb}
     VjzgNqcRxQlpWBuOyXAwivMmUsoELh=VjzgNqcRxQlpWBuOyXAwivMmUsoEKY
   else:
    VjzgNqcRxQlpWBuOyXAwivMmUsoELJ={'mode':'MOVIE','contentid':VjzgNqcRxQlpWBuOyXAwivMmUsoEGf,'title':VjzgNqcRxQlpWBuOyXAwivMmUsoELC,'subtitle':VjzgNqcRxQlpWBuOyXAwivMmUsoEGT,'thumbnail':VjzgNqcRxQlpWBuOyXAwivMmUsoEGb}
    VjzgNqcRxQlpWBuOyXAwivMmUsoELh=VjzgNqcRxQlpWBuOyXAwivMmUsoEKY
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGt={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':VjzgNqcRxQlpWBuOyXAwivMmUsoEGf,'vType':VjzgNqcRxQlpWBuOyXAwivMmUsoELk,}
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGH=urllib.parse.urlencode(VjzgNqcRxQlpWBuOyXAwivMmUsoEGt)
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGF=[('선택된 시청이력 ( %s ) 삭제'%(VjzgNqcRxQlpWBuOyXAwivMmUsoELC),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(VjzgNqcRxQlpWBuOyXAwivMmUsoEGH))]
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.add_dir(VjzgNqcRxQlpWBuOyXAwivMmUsoELC,sublabel=VjzgNqcRxQlpWBuOyXAwivMmUsoEGT,img=VjzgNqcRxQlpWBuOyXAwivMmUsoEGb,infoLabels=VjzgNqcRxQlpWBuOyXAwivMmUsoEGJ,isFolder=VjzgNqcRxQlpWBuOyXAwivMmUsoELh,params=VjzgNqcRxQlpWBuOyXAwivMmUsoELJ,ContextMenu=VjzgNqcRxQlpWBuOyXAwivMmUsoEGF)
  VjzgNqcRxQlpWBuOyXAwivMmUsoEGJ={'plot':'시청목록을 삭제합니다.'}
  VjzgNqcRxQlpWBuOyXAwivMmUsoELC='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  VjzgNqcRxQlpWBuOyXAwivMmUsoELJ={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':VjzgNqcRxQlpWBuOyXAwivMmUsoELk,}
  VjzgNqcRxQlpWBuOyXAwivMmUsoELF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.add_dir(VjzgNqcRxQlpWBuOyXAwivMmUsoELC,sublabel='',img=VjzgNqcRxQlpWBuOyXAwivMmUsoELF,infoLabels=VjzgNqcRxQlpWBuOyXAwivMmUsoEGJ,isFolder=VjzgNqcRxQlpWBuOyXAwivMmUsoEKY,params=VjzgNqcRxQlpWBuOyXAwivMmUsoELJ,isLink=VjzgNqcRxQlpWBuOyXAwivMmUsoEKI)
  if VjzgNqcRxQlpWBuOyXAwivMmUsoELk=='movie':xbmcplugin.setContent(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS._addon_handle,'movies')
  else:xbmcplugin.setContent(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS._addon_handle,cacheToDisc=VjzgNqcRxQlpWBuOyXAwivMmUsoEKY)
 def Load_List_File(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS,stype): 
  try:
   if stype=='search':
    VjzgNqcRxQlpWBuOyXAwivMmUsoEDL=VjzgNqcRxQlpWBuOyXAwivMmUsoEeK
   elif stype in['vod','movie']:
    VjzgNqcRxQlpWBuOyXAwivMmUsoEDL=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   else:
    return[]
   fp=VjzgNqcRxQlpWBuOyXAwivMmUsoESG(VjzgNqcRxQlpWBuOyXAwivMmUsoEDL,'r',-1,'utf-8')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEDG=fp.readlines()
   fp.close()
  except:
   VjzgNqcRxQlpWBuOyXAwivMmUsoEDG=[]
  return VjzgNqcRxQlpWBuOyXAwivMmUsoEDG
 def Save_Watched_List(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS,VjzgNqcRxQlpWBuOyXAwivMmUsoEKD,VjzgNqcRxQlpWBuOyXAwivMmUsoEeH):
  try:
   VjzgNqcRxQlpWBuOyXAwivMmUsoEDn=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%VjzgNqcRxQlpWBuOyXAwivMmUsoEKD))
   VjzgNqcRxQlpWBuOyXAwivMmUsoEDr=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.Load_List_File(VjzgNqcRxQlpWBuOyXAwivMmUsoEKD) 
   fp=VjzgNqcRxQlpWBuOyXAwivMmUsoESG(VjzgNqcRxQlpWBuOyXAwivMmUsoEDn,'w',-1,'utf-8')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEDK=urllib.parse.urlencode(VjzgNqcRxQlpWBuOyXAwivMmUsoEeH)
   VjzgNqcRxQlpWBuOyXAwivMmUsoEDK=VjzgNqcRxQlpWBuOyXAwivMmUsoEDK+'\n'
   fp.write(VjzgNqcRxQlpWBuOyXAwivMmUsoEDK)
   VjzgNqcRxQlpWBuOyXAwivMmUsoEDS=0
   for VjzgNqcRxQlpWBuOyXAwivMmUsoEDC in VjzgNqcRxQlpWBuOyXAwivMmUsoEDr:
    VjzgNqcRxQlpWBuOyXAwivMmUsoEDt=VjzgNqcRxQlpWBuOyXAwivMmUsoEKT(urllib.parse.parse_qsl(VjzgNqcRxQlpWBuOyXAwivMmUsoEDC))
    VjzgNqcRxQlpWBuOyXAwivMmUsoEDH=VjzgNqcRxQlpWBuOyXAwivMmUsoEeH.get('code').strip()
    VjzgNqcRxQlpWBuOyXAwivMmUsoEDF=VjzgNqcRxQlpWBuOyXAwivMmUsoEDt.get('code').strip()
    if VjzgNqcRxQlpWBuOyXAwivMmUsoEKD=='vod' and VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.get_settings_direct_replay()==VjzgNqcRxQlpWBuOyXAwivMmUsoEKI:
     VjzgNqcRxQlpWBuOyXAwivMmUsoEDH=VjzgNqcRxQlpWBuOyXAwivMmUsoEeH.get('videoid').strip()
     VjzgNqcRxQlpWBuOyXAwivMmUsoEDF=VjzgNqcRxQlpWBuOyXAwivMmUsoEDt.get('videoid').strip()if VjzgNqcRxQlpWBuOyXAwivMmUsoEDF!=VjzgNqcRxQlpWBuOyXAwivMmUsoEKb else '-'
    if VjzgNqcRxQlpWBuOyXAwivMmUsoEDH!=VjzgNqcRxQlpWBuOyXAwivMmUsoEDF:
     fp.write(VjzgNqcRxQlpWBuOyXAwivMmUsoEDC)
     VjzgNqcRxQlpWBuOyXAwivMmUsoEDS+=1
     if VjzgNqcRxQlpWBuOyXAwivMmUsoEDS>=50:break
   fp.close()
  except:
   VjzgNqcRxQlpWBuOyXAwivMmUsoEKb
 def dp_History_Remove(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS,args):
  VjzgNqcRxQlpWBuOyXAwivMmUsoEDJ=args.get('delType')
  VjzgNqcRxQlpWBuOyXAwivMmUsoEDh =args.get('sKey')
  VjzgNqcRxQlpWBuOyXAwivMmUsoEDP =args.get('vType')
  VjzgNqcRxQlpWBuOyXAwivMmUsoEeJ=xbmcgui.Dialog()
  if VjzgNqcRxQlpWBuOyXAwivMmUsoEDJ=='SEARCH_ALL':
   VjzgNqcRxQlpWBuOyXAwivMmUsoEDd=VjzgNqcRxQlpWBuOyXAwivMmUsoEeJ.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif VjzgNqcRxQlpWBuOyXAwivMmUsoEDJ=='SEARCH_ONE':
   VjzgNqcRxQlpWBuOyXAwivMmUsoEDd=VjzgNqcRxQlpWBuOyXAwivMmUsoEeJ.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif VjzgNqcRxQlpWBuOyXAwivMmUsoEDJ=='WATCH_ALL':
   VjzgNqcRxQlpWBuOyXAwivMmUsoEDd=VjzgNqcRxQlpWBuOyXAwivMmUsoEeJ.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif VjzgNqcRxQlpWBuOyXAwivMmUsoEDJ=='WATCH_ONE':
   VjzgNqcRxQlpWBuOyXAwivMmUsoEDd=VjzgNqcRxQlpWBuOyXAwivMmUsoEeJ.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if VjzgNqcRxQlpWBuOyXAwivMmUsoEDd==VjzgNqcRxQlpWBuOyXAwivMmUsoEKY:sys.exit()
  if VjzgNqcRxQlpWBuOyXAwivMmUsoEDJ=='SEARCH_ALL':
   if os.path.isfile(VjzgNqcRxQlpWBuOyXAwivMmUsoEeK):os.remove(VjzgNqcRxQlpWBuOyXAwivMmUsoEeK)
  elif VjzgNqcRxQlpWBuOyXAwivMmUsoEDJ=='SEARCH_ONE':
   try:
    VjzgNqcRxQlpWBuOyXAwivMmUsoEDL=VjzgNqcRxQlpWBuOyXAwivMmUsoEeK
    VjzgNqcRxQlpWBuOyXAwivMmUsoEDr=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.Load_List_File('search') 
    fp=VjzgNqcRxQlpWBuOyXAwivMmUsoESG(VjzgNqcRxQlpWBuOyXAwivMmUsoEDL,'w',-1,'utf-8')
    for VjzgNqcRxQlpWBuOyXAwivMmUsoEDC in VjzgNqcRxQlpWBuOyXAwivMmUsoEDr:
     VjzgNqcRxQlpWBuOyXAwivMmUsoEDt=VjzgNqcRxQlpWBuOyXAwivMmUsoEKT(urllib.parse.parse_qsl(VjzgNqcRxQlpWBuOyXAwivMmUsoEDC))
     VjzgNqcRxQlpWBuOyXAwivMmUsoEDb=VjzgNqcRxQlpWBuOyXAwivMmUsoEDt.get('skey').strip()
     if VjzgNqcRxQlpWBuOyXAwivMmUsoEDh!=VjzgNqcRxQlpWBuOyXAwivMmUsoEDb:
      fp.write(VjzgNqcRxQlpWBuOyXAwivMmUsoEDC)
    fp.close()
   except:
    VjzgNqcRxQlpWBuOyXAwivMmUsoEKb
  elif VjzgNqcRxQlpWBuOyXAwivMmUsoEDJ=='WATCH_ALL':
   VjzgNqcRxQlpWBuOyXAwivMmUsoEDL=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%VjzgNqcRxQlpWBuOyXAwivMmUsoEDP))
   if os.path.isfile(VjzgNqcRxQlpWBuOyXAwivMmUsoEDL):os.remove(VjzgNqcRxQlpWBuOyXAwivMmUsoEDL)
  elif VjzgNqcRxQlpWBuOyXAwivMmUsoEDJ=='WATCH_ONE':
   VjzgNqcRxQlpWBuOyXAwivMmUsoEDL=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%VjzgNqcRxQlpWBuOyXAwivMmUsoEDP))
   try:
    VjzgNqcRxQlpWBuOyXAwivMmUsoEDr=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.Load_List_File(VjzgNqcRxQlpWBuOyXAwivMmUsoEDP) 
    fp=VjzgNqcRxQlpWBuOyXAwivMmUsoESG(VjzgNqcRxQlpWBuOyXAwivMmUsoEDL,'w',-1,'utf-8')
    for VjzgNqcRxQlpWBuOyXAwivMmUsoEDC in VjzgNqcRxQlpWBuOyXAwivMmUsoEDr:
     VjzgNqcRxQlpWBuOyXAwivMmUsoEDt=VjzgNqcRxQlpWBuOyXAwivMmUsoEKT(urllib.parse.parse_qsl(VjzgNqcRxQlpWBuOyXAwivMmUsoEDC))
     VjzgNqcRxQlpWBuOyXAwivMmUsoEDb=VjzgNqcRxQlpWBuOyXAwivMmUsoEDt.get('code').strip()
     if VjzgNqcRxQlpWBuOyXAwivMmUsoEDh!=VjzgNqcRxQlpWBuOyXAwivMmUsoEDb:
      fp.write(VjzgNqcRxQlpWBuOyXAwivMmUsoEDC)
    fp.close()
   except:
    VjzgNqcRxQlpWBuOyXAwivMmUsoEKb
  xbmc.executebuiltin("Container.Refresh")
 def Save_Searched_List(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS,VjzgNqcRxQlpWBuOyXAwivMmUsoELa):
  try:
   VjzgNqcRxQlpWBuOyXAwivMmUsoEDa=VjzgNqcRxQlpWBuOyXAwivMmUsoEeK
   VjzgNqcRxQlpWBuOyXAwivMmUsoEDr=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.Load_List_File('search') 
   VjzgNqcRxQlpWBuOyXAwivMmUsoEDI={'skey':VjzgNqcRxQlpWBuOyXAwivMmUsoELa.strip()}
   fp=VjzgNqcRxQlpWBuOyXAwivMmUsoESG(VjzgNqcRxQlpWBuOyXAwivMmUsoEDa,'w',-1,'utf-8')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEDK=urllib.parse.urlencode(VjzgNqcRxQlpWBuOyXAwivMmUsoEDI)
   VjzgNqcRxQlpWBuOyXAwivMmUsoEDK=VjzgNqcRxQlpWBuOyXAwivMmUsoEDK+'\n'
   fp.write(VjzgNqcRxQlpWBuOyXAwivMmUsoEDK)
   VjzgNqcRxQlpWBuOyXAwivMmUsoEDS=0
   for VjzgNqcRxQlpWBuOyXAwivMmUsoEDC in VjzgNqcRxQlpWBuOyXAwivMmUsoEDr:
    VjzgNqcRxQlpWBuOyXAwivMmUsoEDt=VjzgNqcRxQlpWBuOyXAwivMmUsoEKT(urllib.parse.parse_qsl(VjzgNqcRxQlpWBuOyXAwivMmUsoEDC))
    VjzgNqcRxQlpWBuOyXAwivMmUsoEDH=VjzgNqcRxQlpWBuOyXAwivMmUsoEDI.get('skey').strip()
    VjzgNqcRxQlpWBuOyXAwivMmUsoEDF=VjzgNqcRxQlpWBuOyXAwivMmUsoEDt.get('skey').strip()
    if VjzgNqcRxQlpWBuOyXAwivMmUsoEDH!=VjzgNqcRxQlpWBuOyXAwivMmUsoEDF:
     fp.write(VjzgNqcRxQlpWBuOyXAwivMmUsoEDC)
     VjzgNqcRxQlpWBuOyXAwivMmUsoEDS+=1
     if VjzgNqcRxQlpWBuOyXAwivMmUsoEDS>=50:break
   fp.close()
  except:
   VjzgNqcRxQlpWBuOyXAwivMmUsoEKb
 def dp_Global_Search(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS,args):
  VjzgNqcRxQlpWBuOyXAwivMmUsoELY=args.get('mode')
  if VjzgNqcRxQlpWBuOyXAwivMmUsoELY=='TOTAL_SEARCH':
   VjzgNqcRxQlpWBuOyXAwivMmUsoEDY='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   VjzgNqcRxQlpWBuOyXAwivMmUsoEDY='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(VjzgNqcRxQlpWBuOyXAwivMmUsoEDY)
 def dp_Bookmark_Menu(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS,args):
  VjzgNqcRxQlpWBuOyXAwivMmUsoEDY='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(VjzgNqcRxQlpWBuOyXAwivMmUsoEDY)
 def login_main(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS):
  (VjzgNqcRxQlpWBuOyXAwivMmUsoEDk,VjzgNqcRxQlpWBuOyXAwivMmUsoEDT,VjzgNqcRxQlpWBuOyXAwivMmUsoEDf)=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.get_settings_account()
  if not(VjzgNqcRxQlpWBuOyXAwivMmUsoEDk and VjzgNqcRxQlpWBuOyXAwivMmUsoEDT):
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeJ=xbmcgui.Dialog()
   VjzgNqcRxQlpWBuOyXAwivMmUsoEDd=VjzgNqcRxQlpWBuOyXAwivMmUsoEeJ.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if VjzgNqcRxQlpWBuOyXAwivMmUsoEDd==VjzgNqcRxQlpWBuOyXAwivMmUsoEKI:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.cookiefile_check()==VjzgNqcRxQlpWBuOyXAwivMmUsoEKI:return
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   VjzgNqcRxQlpWBuOyXAwivMmUsoEne=0
   while VjzgNqcRxQlpWBuOyXAwivMmUsoEKI:
    VjzgNqcRxQlpWBuOyXAwivMmUsoEne+=1
    time.sleep(0.05)
    if VjzgNqcRxQlpWBuOyXAwivMmUsoEne>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  VjzgNqcRxQlpWBuOyXAwivMmUsoEnL=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.WavveObj.GetCredential(VjzgNqcRxQlpWBuOyXAwivMmUsoEDk,VjzgNqcRxQlpWBuOyXAwivMmUsoEDT,VjzgNqcRxQlpWBuOyXAwivMmUsoEDf)
  if VjzgNqcRxQlpWBuOyXAwivMmUsoEnL:VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
  if VjzgNqcRxQlpWBuOyXAwivMmUsoEnL==VjzgNqcRxQlpWBuOyXAwivMmUsoEKY:
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_setEpOrderby(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS,args):
  VjzgNqcRxQlpWBuOyXAwivMmUsoELK =args.get('orderby')
  VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.set_winEpisodeOrderby(VjzgNqcRxQlpWBuOyXAwivMmUsoELK)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS,args):
  VjzgNqcRxQlpWBuOyXAwivMmUsoELY =args.get('mode')
  VjzgNqcRxQlpWBuOyXAwivMmUsoEnG =args.get('contentid')
  VjzgNqcRxQlpWBuOyXAwivMmUsoEnD =args.get('pvrmode')
  VjzgNqcRxQlpWBuOyXAwivMmUsoEnr=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.get_selQuality()
  VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.addon_log(VjzgNqcRxQlpWBuOyXAwivMmUsoEnG+' - '+VjzgNqcRxQlpWBuOyXAwivMmUsoELY)
  if VjzgNqcRxQlpWBuOyXAwivMmUsoELY=='SPORTS':
   VjzgNqcRxQlpWBuOyXAwivMmUsoEnK,VjzgNqcRxQlpWBuOyXAwivMmUsoEnS=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.WavveObj.GetSportsURL(VjzgNqcRxQlpWBuOyXAwivMmUsoEnG,VjzgNqcRxQlpWBuOyXAwivMmUsoEnr)
   VjzgNqcRxQlpWBuOyXAwivMmUsoEnC =''
   VjzgNqcRxQlpWBuOyXAwivMmUsoEnt=''
  else:
   VjzgNqcRxQlpWBuOyXAwivMmUsoEnK,VjzgNqcRxQlpWBuOyXAwivMmUsoEnS,VjzgNqcRxQlpWBuOyXAwivMmUsoEnC,VjzgNqcRxQlpWBuOyXAwivMmUsoEnt=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.WavveObj.GetStreamingURL(VjzgNqcRxQlpWBuOyXAwivMmUsoELY,VjzgNqcRxQlpWBuOyXAwivMmUsoEnG,VjzgNqcRxQlpWBuOyXAwivMmUsoEnr,VjzgNqcRxQlpWBuOyXAwivMmUsoEnD)
  VjzgNqcRxQlpWBuOyXAwivMmUsoEnH='%s|Cookie=%s'%(VjzgNqcRxQlpWBuOyXAwivMmUsoEnK,VjzgNqcRxQlpWBuOyXAwivMmUsoEnS)
  VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.addon_log(VjzgNqcRxQlpWBuOyXAwivMmUsoEnH)
  if VjzgNqcRxQlpWBuOyXAwivMmUsoEnK=='':
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.addon_noti(__language__(30907).encode('utf8'))
   return
  VjzgNqcRxQlpWBuOyXAwivMmUsoEnF=xbmcgui.ListItem(path=VjzgNqcRxQlpWBuOyXAwivMmUsoEnH)
  if VjzgNqcRxQlpWBuOyXAwivMmUsoEnC:
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.addon_log('!!streaming_drm!!')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEnJ=VjzgNqcRxQlpWBuOyXAwivMmUsoEnC['customdata']
   VjzgNqcRxQlpWBuOyXAwivMmUsoEnh =VjzgNqcRxQlpWBuOyXAwivMmUsoEnC['drmhost']
   VjzgNqcRxQlpWBuOyXAwivMmUsoEnP =inputstreamhelper.Helper('mpd',drm='widevine')
   if VjzgNqcRxQlpWBuOyXAwivMmUsoEnP.check_inputstream():
    if VjzgNqcRxQlpWBuOyXAwivMmUsoELY=='MOVIE':
     VjzgNqcRxQlpWBuOyXAwivMmUsoEnd='https://www.wavve.com/player/movie?movieid=%s'%VjzgNqcRxQlpWBuOyXAwivMmUsoEnG
    else:
     VjzgNqcRxQlpWBuOyXAwivMmUsoEnd='https://www.wavve.com/player/vod?programid=%s&page=1'%VjzgNqcRxQlpWBuOyXAwivMmUsoEnG
    VjzgNqcRxQlpWBuOyXAwivMmUsoEnb={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':VjzgNqcRxQlpWBuOyXAwivMmUsoEnJ,'referer':VjzgNqcRxQlpWBuOyXAwivMmUsoEnd,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.WavveObj.USER_AGENT}
    VjzgNqcRxQlpWBuOyXAwivMmUsoEna=VjzgNqcRxQlpWBuOyXAwivMmUsoEnh+'|'+urllib.parse.urlencode(VjzgNqcRxQlpWBuOyXAwivMmUsoEnb)+'|R{SSM}|'
    VjzgNqcRxQlpWBuOyXAwivMmUsoEnF.setProperty('inputstream',VjzgNqcRxQlpWBuOyXAwivMmUsoEnP.inputstream_addon)
    VjzgNqcRxQlpWBuOyXAwivMmUsoEnF.setProperty('inputstream.adaptive.manifest_type','mpd')
    VjzgNqcRxQlpWBuOyXAwivMmUsoEnF.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    VjzgNqcRxQlpWBuOyXAwivMmUsoEnF.setProperty('inputstream.adaptive.license_key',VjzgNqcRxQlpWBuOyXAwivMmUsoEna)
    VjzgNqcRxQlpWBuOyXAwivMmUsoEnF.setProperty('inputstream.adaptive.stream_headers','user-agent=%s&Cookie=%s'%(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.WavveObj.USER_AGENT,VjzgNqcRxQlpWBuOyXAwivMmUsoEnS))
  xbmcplugin.setResolvedUrl(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS._addon_handle,VjzgNqcRxQlpWBuOyXAwivMmUsoEKI,VjzgNqcRxQlpWBuOyXAwivMmUsoEnF)
  VjzgNqcRxQlpWBuOyXAwivMmUsoEnI=VjzgNqcRxQlpWBuOyXAwivMmUsoEKY
  if VjzgNqcRxQlpWBuOyXAwivMmUsoEnt:
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.addon_noti(VjzgNqcRxQlpWBuOyXAwivMmUsoEnt.encode('utf-8'))
   VjzgNqcRxQlpWBuOyXAwivMmUsoEnI=VjzgNqcRxQlpWBuOyXAwivMmUsoEKI
  else:
   if '/preview.' in urllib.parse.urlsplit(VjzgNqcRxQlpWBuOyXAwivMmUsoEnK).path:
    VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.addon_noti(__language__(30908).encode('utf8'))
    VjzgNqcRxQlpWBuOyXAwivMmUsoEnI=VjzgNqcRxQlpWBuOyXAwivMmUsoEKI
  try:
   VjzgNqcRxQlpWBuOyXAwivMmUsoEnY=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and VjzgNqcRxQlpWBuOyXAwivMmUsoEnI==VjzgNqcRxQlpWBuOyXAwivMmUsoEKY and VjzgNqcRxQlpWBuOyXAwivMmUsoEnY!='-':
    VjzgNqcRxQlpWBuOyXAwivMmUsoELJ={'code':VjzgNqcRxQlpWBuOyXAwivMmUsoEnY,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.Save_Watched_List(args.get('mode').lower(),VjzgNqcRxQlpWBuOyXAwivMmUsoELJ)
  except:
   VjzgNqcRxQlpWBuOyXAwivMmUsoEKb
 def logout(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS):
  VjzgNqcRxQlpWBuOyXAwivMmUsoEeJ=xbmcgui.Dialog()
  VjzgNqcRxQlpWBuOyXAwivMmUsoEDd=VjzgNqcRxQlpWBuOyXAwivMmUsoEeJ.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if VjzgNqcRxQlpWBuOyXAwivMmUsoEDd==VjzgNqcRxQlpWBuOyXAwivMmUsoEKY:sys.exit()
  VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.wininfo_clear()
  if os.path.isfile(VjzgNqcRxQlpWBuOyXAwivMmUsoEer):os.remove(VjzgNqcRxQlpWBuOyXAwivMmUsoEer)
  VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS):
  VjzgNqcRxQlpWBuOyXAwivMmUsoEnk =VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.WavveObj.Get_Now_Datetime()
  VjzgNqcRxQlpWBuOyXAwivMmUsoEnT=VjzgNqcRxQlpWBuOyXAwivMmUsoEnk+datetime.timedelta(days=VjzgNqcRxQlpWBuOyXAwivMmUsoEKa(__addon__.getSetting('cache_ttl')))
  (VjzgNqcRxQlpWBuOyXAwivMmUsoEDk,VjzgNqcRxQlpWBuOyXAwivMmUsoEDT,VjzgNqcRxQlpWBuOyXAwivMmUsoEDf)=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.get_settings_account()
  VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.WavveObj.Save_session_acount(VjzgNqcRxQlpWBuOyXAwivMmUsoEDk,VjzgNqcRxQlpWBuOyXAwivMmUsoEDT,VjzgNqcRxQlpWBuOyXAwivMmUsoEDf)
  VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.WavveObj.WV['account']['token_limit']=VjzgNqcRxQlpWBuOyXAwivMmUsoEnT.strftime('%Y%m%d')
  try: 
   fp=VjzgNqcRxQlpWBuOyXAwivMmUsoESG(VjzgNqcRxQlpWBuOyXAwivMmUsoEer,'w',-1,'utf-8')
   json.dump(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.WavveObj.WV,fp,indent=4,ensure_ascii=VjzgNqcRxQlpWBuOyXAwivMmUsoEKY)
   fp.close()
  except VjzgNqcRxQlpWBuOyXAwivMmUsoESD as exception:
   VjzgNqcRxQlpWBuOyXAwivMmUsoESn(exception)
 def cookiefile_check(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS):
  VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.WavveObj.WV=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.WavveObj.JsonFile_Load(VjzgNqcRxQlpWBuOyXAwivMmUsoEer)
  if 'account' not in VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.WavveObj.WV:
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.WavveObj.Init_WV_Total()
   return VjzgNqcRxQlpWBuOyXAwivMmUsoEKY
  (VjzgNqcRxQlpWBuOyXAwivMmUsoEre,VjzgNqcRxQlpWBuOyXAwivMmUsoErL,VjzgNqcRxQlpWBuOyXAwivMmUsoErG)=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.get_settings_account()
  (VjzgNqcRxQlpWBuOyXAwivMmUsoErD,VjzgNqcRxQlpWBuOyXAwivMmUsoErn,VjzgNqcRxQlpWBuOyXAwivMmUsoErK)=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.WavveObj.Load_session_acount()
  if VjzgNqcRxQlpWBuOyXAwivMmUsoEre!=VjzgNqcRxQlpWBuOyXAwivMmUsoErD or VjzgNqcRxQlpWBuOyXAwivMmUsoErL!=VjzgNqcRxQlpWBuOyXAwivMmUsoErn or VjzgNqcRxQlpWBuOyXAwivMmUsoErG!=VjzgNqcRxQlpWBuOyXAwivMmUsoErK:
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.WavveObj.Init_WV_Total()
   return VjzgNqcRxQlpWBuOyXAwivMmUsoEKY
  if VjzgNqcRxQlpWBuOyXAwivMmUsoEKa(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))>VjzgNqcRxQlpWBuOyXAwivMmUsoEKa(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.WavveObj.WV['account']['token_limit']):
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.WavveObj.Init_WV_Total()
   return VjzgNqcRxQlpWBuOyXAwivMmUsoEKY
  return VjzgNqcRxQlpWBuOyXAwivMmUsoEKI
 def dp_LiveCatagory_List(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS,args):
  VjzgNqcRxQlpWBuOyXAwivMmUsoErS =args.get('sCode')
  VjzgNqcRxQlpWBuOyXAwivMmUsoErC=args.get('sIndex')
  VjzgNqcRxQlpWBuOyXAwivMmUsoEGP,VjzgNqcRxQlpWBuOyXAwivMmUsoErt=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.WavveObj.Get_LiveCatagory_List(VjzgNqcRxQlpWBuOyXAwivMmUsoErS,VjzgNqcRxQlpWBuOyXAwivMmUsoErC)
  for VjzgNqcRxQlpWBuOyXAwivMmUsoEGd in VjzgNqcRxQlpWBuOyXAwivMmUsoEGP:
   VjzgNqcRxQlpWBuOyXAwivMmUsoELC =VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('title')
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ={'mode':'LIVE_LIST','genre':VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('genre'),'baseapi':VjzgNqcRxQlpWBuOyXAwivMmUsoErt}
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.add_dir(VjzgNqcRxQlpWBuOyXAwivMmUsoELC,sublabel='',img='',infoLabels=VjzgNqcRxQlpWBuOyXAwivMmUsoEKb,isFolder=VjzgNqcRxQlpWBuOyXAwivMmUsoEKI,params=VjzgNqcRxQlpWBuOyXAwivMmUsoELJ)
  if VjzgNqcRxQlpWBuOyXAwivMmUsoEKf(VjzgNqcRxQlpWBuOyXAwivMmUsoEGP)>0:xbmcplugin.endOfDirectory(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS._addon_handle,cacheToDisc=VjzgNqcRxQlpWBuOyXAwivMmUsoEKY)
 def dp_MainCatagory_List(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS,args):
  VjzgNqcRxQlpWBuOyXAwivMmUsoErS =args.get('sCode')
  VjzgNqcRxQlpWBuOyXAwivMmUsoErC=args.get('sIndex')
  VjzgNqcRxQlpWBuOyXAwivMmUsoELk =args.get('sType')
  VjzgNqcRxQlpWBuOyXAwivMmUsoEGP=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.WavveObj.Get_MainCatagory_List(VjzgNqcRxQlpWBuOyXAwivMmUsoErS,VjzgNqcRxQlpWBuOyXAwivMmUsoErC)
  for VjzgNqcRxQlpWBuOyXAwivMmUsoEGd in VjzgNqcRxQlpWBuOyXAwivMmUsoEGP:
   if VjzgNqcRxQlpWBuOyXAwivMmUsoELk=='vod':
    if VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('subtype')=='catagory':
     VjzgNqcRxQlpWBuOyXAwivMmUsoELY='PROGRAM_LIST'
    else:
     VjzgNqcRxQlpWBuOyXAwivMmUsoELY='SUPERSECTION_LIST'
   elif VjzgNqcRxQlpWBuOyXAwivMmUsoELk=='movie':
    VjzgNqcRxQlpWBuOyXAwivMmUsoELY='MOVIE_LIST'
   else:
    VjzgNqcRxQlpWBuOyXAwivMmUsoELY=''
   VjzgNqcRxQlpWBuOyXAwivMmUsoELC='%s (%s)'%(VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('title'),args.get('ordernm'))
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ={'mode':VjzgNqcRxQlpWBuOyXAwivMmUsoELY,'suburl':VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('suburl'),'subapi':VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.get_settings_exclusion21():
    if VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('title')=='성인' or VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('title')=='성인+' or VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('title')=='에로티시즘' or VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('title')=='19':continue
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.add_dir(VjzgNqcRxQlpWBuOyXAwivMmUsoELC,sublabel='',img='',infoLabels=VjzgNqcRxQlpWBuOyXAwivMmUsoEKb,isFolder=VjzgNqcRxQlpWBuOyXAwivMmUsoEKI,params=VjzgNqcRxQlpWBuOyXAwivMmUsoELJ)
  if VjzgNqcRxQlpWBuOyXAwivMmUsoEKf(VjzgNqcRxQlpWBuOyXAwivMmUsoEGP)>0:xbmcplugin.endOfDirectory(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS._addon_handle,cacheToDisc=VjzgNqcRxQlpWBuOyXAwivMmUsoEKY)
 def dp_Program_List(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS,args):
  VjzgNqcRxQlpWBuOyXAwivMmUsoErH =args.get('subapi')
  VjzgNqcRxQlpWBuOyXAwivMmUsoEGh=VjzgNqcRxQlpWBuOyXAwivMmUsoEKa(args.get('page'))
  VjzgNqcRxQlpWBuOyXAwivMmUsoELK =args.get('orderby')
  VjzgNqcRxQlpWBuOyXAwivMmUsoEGP,VjzgNqcRxQlpWBuOyXAwivMmUsoELf=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.WavveObj.Get_Program_List(VjzgNqcRxQlpWBuOyXAwivMmUsoErH,VjzgNqcRxQlpWBuOyXAwivMmUsoEGh,VjzgNqcRxQlpWBuOyXAwivMmUsoELK)
  for VjzgNqcRxQlpWBuOyXAwivMmUsoEGd in VjzgNqcRxQlpWBuOyXAwivMmUsoEGP:
   VjzgNqcRxQlpWBuOyXAwivMmUsoELC =VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('title')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGb=VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('thumbnail')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGa =VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('age')
   if VjzgNqcRxQlpWBuOyXAwivMmUsoEGa=='18' or VjzgNqcRxQlpWBuOyXAwivMmUsoEGa=='19' or VjzgNqcRxQlpWBuOyXAwivMmUsoEGa=='21':VjzgNqcRxQlpWBuOyXAwivMmUsoELC+=' (%s)'%(VjzgNqcRxQlpWBuOyXAwivMmUsoEGa)
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGJ={'plot':VjzgNqcRxQlpWBuOyXAwivMmUsoELC,'mpaa':VjzgNqcRxQlpWBuOyXAwivMmUsoEGa,'mediatype':'tvshow'}
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ={'mode':'EPISODE_LIST','videoid':VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('videoid'),'vidtype':VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('vidtype'),'page':'1'}
   if VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.get_settings_makebookmark():
    VjzgNqcRxQlpWBuOyXAwivMmUsoEGI={'videoid':VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('videoid'),'vidtype':'tvshow','vtitle':VjzgNqcRxQlpWBuOyXAwivMmUsoELC,'vsubtitle':'','contenttype':VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('vidtype'),}
    VjzgNqcRxQlpWBuOyXAwivMmUsoEGY=json.dumps(VjzgNqcRxQlpWBuOyXAwivMmUsoEGI)
    VjzgNqcRxQlpWBuOyXAwivMmUsoEGY=urllib.parse.quote(VjzgNqcRxQlpWBuOyXAwivMmUsoEGY)
    VjzgNqcRxQlpWBuOyXAwivMmUsoEGk='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(VjzgNqcRxQlpWBuOyXAwivMmUsoEGY)
    VjzgNqcRxQlpWBuOyXAwivMmUsoEGF=[('(통합) 찜 영상에 추가',VjzgNqcRxQlpWBuOyXAwivMmUsoEGk)]
   else:
    VjzgNqcRxQlpWBuOyXAwivMmUsoEGF=VjzgNqcRxQlpWBuOyXAwivMmUsoEKb
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.add_dir(VjzgNqcRxQlpWBuOyXAwivMmUsoELC,sublabel='',img=VjzgNqcRxQlpWBuOyXAwivMmUsoEGb,infoLabels=VjzgNqcRxQlpWBuOyXAwivMmUsoEGJ,isFolder=VjzgNqcRxQlpWBuOyXAwivMmUsoEKI,params=VjzgNqcRxQlpWBuOyXAwivMmUsoELJ,ContextMenu=VjzgNqcRxQlpWBuOyXAwivMmUsoEGF)
  if VjzgNqcRxQlpWBuOyXAwivMmUsoELf:
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ={}
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ['mode'] ='PROGRAM_LIST' 
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ['subapi']=VjzgNqcRxQlpWBuOyXAwivMmUsoErH 
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ['page'] =VjzgNqcRxQlpWBuOyXAwivMmUsoESL(VjzgNqcRxQlpWBuOyXAwivMmUsoEGh+1)
   VjzgNqcRxQlpWBuOyXAwivMmUsoELC='[B]%s >>[/B]'%'다음 페이지'
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGT=VjzgNqcRxQlpWBuOyXAwivMmUsoESL(VjzgNqcRxQlpWBuOyXAwivMmUsoEGh+1)
   VjzgNqcRxQlpWBuOyXAwivMmUsoELF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.add_dir(VjzgNqcRxQlpWBuOyXAwivMmUsoELC,sublabel=VjzgNqcRxQlpWBuOyXAwivMmUsoEGT,img=VjzgNqcRxQlpWBuOyXAwivMmUsoELF,infoLabels=VjzgNqcRxQlpWBuOyXAwivMmUsoEKb,isFolder=VjzgNqcRxQlpWBuOyXAwivMmUsoEKI,params=VjzgNqcRxQlpWBuOyXAwivMmUsoELJ)
  xbmcplugin.setContent(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS._addon_handle,'tvshows')
  if VjzgNqcRxQlpWBuOyXAwivMmUsoEKf(VjzgNqcRxQlpWBuOyXAwivMmUsoEGP)>0:xbmcplugin.endOfDirectory(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS._addon_handle,cacheToDisc=VjzgNqcRxQlpWBuOyXAwivMmUsoEKY)
 def dp_SuperSection_List(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS,args):
  VjzgNqcRxQlpWBuOyXAwivMmUsoErF =args.get('suburl')
  VjzgNqcRxQlpWBuOyXAwivMmUsoEGP=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.WavveObj.Get_SuperMultiSection_List(VjzgNqcRxQlpWBuOyXAwivMmUsoErF)
  for VjzgNqcRxQlpWBuOyXAwivMmUsoEGd in VjzgNqcRxQlpWBuOyXAwivMmUsoEGP:
   VjzgNqcRxQlpWBuOyXAwivMmUsoELC =VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('title')
   VjzgNqcRxQlpWBuOyXAwivMmUsoErH =VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('subapi')
   VjzgNqcRxQlpWBuOyXAwivMmUsoErJ=VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('cell_type')
   if VjzgNqcRxQlpWBuOyXAwivMmUsoErH.find('mtype=svod')>=0 or VjzgNqcRxQlpWBuOyXAwivMmUsoErH.find('mtype=ppv')>=0:
    VjzgNqcRxQlpWBuOyXAwivMmUsoELY='MOVIE_LIST'
   elif VjzgNqcRxQlpWBuOyXAwivMmUsoErJ=='band_71':
    VjzgNqcRxQlpWBuOyXAwivMmUsoELY ='SUPERSECTION_LIST'
    (VjzgNqcRxQlpWBuOyXAwivMmUsoErh,VjzgNqcRxQlpWBuOyXAwivMmUsoErP)=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.WavveObj.Baseapi_Parse(VjzgNqcRxQlpWBuOyXAwivMmUsoErH)
    VjzgNqcRxQlpWBuOyXAwivMmUsoErF=VjzgNqcRxQlpWBuOyXAwivMmUsoErP.get('api')
    VjzgNqcRxQlpWBuOyXAwivMmUsoErH=''
   elif VjzgNqcRxQlpWBuOyXAwivMmUsoErJ=='band_2':
    VjzgNqcRxQlpWBuOyXAwivMmUsoELY='BAND2SECTION_LIST'
   elif VjzgNqcRxQlpWBuOyXAwivMmUsoErJ=='band_live':
    VjzgNqcRxQlpWBuOyXAwivMmUsoELY='BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}',VjzgNqcRxQlpWBuOyXAwivMmUsoErH):
    VjzgNqcRxQlpWBuOyXAwivMmUsoELY='MOVIE_LIST'
   else:
    VjzgNqcRxQlpWBuOyXAwivMmUsoELY='PROGRAM_LIST'
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGJ={'plot':VjzgNqcRxQlpWBuOyXAwivMmUsoELC,'mediatype':'tvshow'}
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ={'mode':VjzgNqcRxQlpWBuOyXAwivMmUsoELY,'suburl':VjzgNqcRxQlpWBuOyXAwivMmUsoErF,'subapi':VjzgNqcRxQlpWBuOyXAwivMmUsoErH,'page':'1'}
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.add_dir(VjzgNqcRxQlpWBuOyXAwivMmUsoELC,sublabel='',img=VjzgNqcRxQlpWBuOyXAwivMmUsoEKb,infoLabels=VjzgNqcRxQlpWBuOyXAwivMmUsoEGJ,isFolder=VjzgNqcRxQlpWBuOyXAwivMmUsoEKI,params=VjzgNqcRxQlpWBuOyXAwivMmUsoELJ)
  if VjzgNqcRxQlpWBuOyXAwivMmUsoEKf(VjzgNqcRxQlpWBuOyXAwivMmUsoEGP)>0:xbmcplugin.endOfDirectory(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS._addon_handle,cacheToDisc=VjzgNqcRxQlpWBuOyXAwivMmUsoEKY)
 def dp_BandLiveSection_List(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS,args):
  VjzgNqcRxQlpWBuOyXAwivMmUsoErH =args.get('subapi')
  VjzgNqcRxQlpWBuOyXAwivMmUsoEGh=VjzgNqcRxQlpWBuOyXAwivMmUsoEKa(args.get('page'))
  VjzgNqcRxQlpWBuOyXAwivMmUsoEGP,VjzgNqcRxQlpWBuOyXAwivMmUsoELf=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.WavveObj.Get_BandLiveSection_List(VjzgNqcRxQlpWBuOyXAwivMmUsoErH,VjzgNqcRxQlpWBuOyXAwivMmUsoEGh)
  for VjzgNqcRxQlpWBuOyXAwivMmUsoEGd in VjzgNqcRxQlpWBuOyXAwivMmUsoEGP:
   VjzgNqcRxQlpWBuOyXAwivMmUsoErd =VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('channelid')
   VjzgNqcRxQlpWBuOyXAwivMmUsoErb =VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('studio')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEra=VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('tvshowtitle')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGb =VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('thumbnail')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGa =VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('age')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGJ={'mediatype':'tvshow','mpaa':VjzgNqcRxQlpWBuOyXAwivMmUsoEGa,'title':'%s < %s >'%(VjzgNqcRxQlpWBuOyXAwivMmUsoErb,VjzgNqcRxQlpWBuOyXAwivMmUsoEra),'tvshowtitle':VjzgNqcRxQlpWBuOyXAwivMmUsoEra,'studio':VjzgNqcRxQlpWBuOyXAwivMmUsoErb,'plot':VjzgNqcRxQlpWBuOyXAwivMmUsoErb}
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ={'mode':'LIVE','contentid':VjzgNqcRxQlpWBuOyXAwivMmUsoErd}
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.add_dir(VjzgNqcRxQlpWBuOyXAwivMmUsoErb,sublabel=VjzgNqcRxQlpWBuOyXAwivMmUsoEra,img=VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('thumbnail'),infoLabels=VjzgNqcRxQlpWBuOyXAwivMmUsoEGJ,isFolder=VjzgNqcRxQlpWBuOyXAwivMmUsoEKY,params=VjzgNqcRxQlpWBuOyXAwivMmUsoELJ)
  if VjzgNqcRxQlpWBuOyXAwivMmUsoELf:
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ={}
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ['mode'] ='BANDLIVESECTION_LIST' 
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ['subapi']=VjzgNqcRxQlpWBuOyXAwivMmUsoErH
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ['page'] =VjzgNqcRxQlpWBuOyXAwivMmUsoESL(VjzgNqcRxQlpWBuOyXAwivMmUsoEGh+1)
   VjzgNqcRxQlpWBuOyXAwivMmUsoELC='[B]%s >>[/B]'%'다음 페이지'
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGT=VjzgNqcRxQlpWBuOyXAwivMmUsoESL(VjzgNqcRxQlpWBuOyXAwivMmUsoEGh+1)
   VjzgNqcRxQlpWBuOyXAwivMmUsoELF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.add_dir(VjzgNqcRxQlpWBuOyXAwivMmUsoELC,sublabel=VjzgNqcRxQlpWBuOyXAwivMmUsoEGT,img=VjzgNqcRxQlpWBuOyXAwivMmUsoELF,infoLabels=VjzgNqcRxQlpWBuOyXAwivMmUsoEKb,isFolder=VjzgNqcRxQlpWBuOyXAwivMmUsoEKI,params=VjzgNqcRxQlpWBuOyXAwivMmUsoELJ)
  if VjzgNqcRxQlpWBuOyXAwivMmUsoEKf(VjzgNqcRxQlpWBuOyXAwivMmUsoEGP)>0:xbmcplugin.endOfDirectory(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS._addon_handle,cacheToDisc=VjzgNqcRxQlpWBuOyXAwivMmUsoEKY)
 def dp_Band2Section_List(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS,args):
  VjzgNqcRxQlpWBuOyXAwivMmUsoErH =args.get('subapi')
  VjzgNqcRxQlpWBuOyXAwivMmUsoEGh=VjzgNqcRxQlpWBuOyXAwivMmUsoEKa(args.get('page'))
  VjzgNqcRxQlpWBuOyXAwivMmUsoEGP,VjzgNqcRxQlpWBuOyXAwivMmUsoELf=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.WavveObj.Get_Band2Section_List(VjzgNqcRxQlpWBuOyXAwivMmUsoErH,VjzgNqcRxQlpWBuOyXAwivMmUsoEGh)
  for VjzgNqcRxQlpWBuOyXAwivMmUsoEGd in VjzgNqcRxQlpWBuOyXAwivMmUsoEGP:
   VjzgNqcRxQlpWBuOyXAwivMmUsoELC =VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('programtitle')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGT =VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('episodetitle')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGJ={'plot':VjzgNqcRxQlpWBuOyXAwivMmUsoELC+'\n\n'+VjzgNqcRxQlpWBuOyXAwivMmUsoEGT,'mpaa':VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('age'),'mediatype':'episode'}
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ={'mode':'VOD','programid':'-','contentid':VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('videoid'),'thumbnail':VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('thumbnail'),'title':VjzgNqcRxQlpWBuOyXAwivMmUsoELC,'subtitle':VjzgNqcRxQlpWBuOyXAwivMmUsoEGT}
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.add_dir(VjzgNqcRxQlpWBuOyXAwivMmUsoELC,sublabel=VjzgNqcRxQlpWBuOyXAwivMmUsoEGT,img=VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('thumbnail'),infoLabels=VjzgNqcRxQlpWBuOyXAwivMmUsoEGJ,isFolder=VjzgNqcRxQlpWBuOyXAwivMmUsoEKY,params=VjzgNqcRxQlpWBuOyXAwivMmUsoELJ)
  if VjzgNqcRxQlpWBuOyXAwivMmUsoELf:
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ={}
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ['mode'] ='BAND2SECTION_LIST' 
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ['subapi']=VjzgNqcRxQlpWBuOyXAwivMmUsoErH
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ['page'] =VjzgNqcRxQlpWBuOyXAwivMmUsoESL(VjzgNqcRxQlpWBuOyXAwivMmUsoEGh+1)
   VjzgNqcRxQlpWBuOyXAwivMmUsoELC='[B]%s >>[/B]'%'다음 페이지'
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGT=VjzgNqcRxQlpWBuOyXAwivMmUsoESL(VjzgNqcRxQlpWBuOyXAwivMmUsoEGh+1)
   VjzgNqcRxQlpWBuOyXAwivMmUsoELF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.add_dir(VjzgNqcRxQlpWBuOyXAwivMmUsoELC,sublabel=VjzgNqcRxQlpWBuOyXAwivMmUsoEGT,img=VjzgNqcRxQlpWBuOyXAwivMmUsoELF,infoLabels=VjzgNqcRxQlpWBuOyXAwivMmUsoEKb,isFolder=VjzgNqcRxQlpWBuOyXAwivMmUsoEKI,params=VjzgNqcRxQlpWBuOyXAwivMmUsoELJ)
  if VjzgNqcRxQlpWBuOyXAwivMmUsoEKf(VjzgNqcRxQlpWBuOyXAwivMmUsoEGP)>0:xbmcplugin.endOfDirectory(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS._addon_handle,cacheToDisc=VjzgNqcRxQlpWBuOyXAwivMmUsoEKY)
 def dp_Movie_List(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS,args):
  VjzgNqcRxQlpWBuOyXAwivMmUsoErH =args.get('subapi')
  VjzgNqcRxQlpWBuOyXAwivMmUsoEGh=VjzgNqcRxQlpWBuOyXAwivMmUsoEKa(args.get('page'))
  VjzgNqcRxQlpWBuOyXAwivMmUsoEGP,VjzgNqcRxQlpWBuOyXAwivMmUsoELf=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.WavveObj.Get_Movie_List(VjzgNqcRxQlpWBuOyXAwivMmUsoErH,VjzgNqcRxQlpWBuOyXAwivMmUsoEGh)
  for VjzgNqcRxQlpWBuOyXAwivMmUsoEGd in VjzgNqcRxQlpWBuOyXAwivMmUsoEGP:
   VjzgNqcRxQlpWBuOyXAwivMmUsoELC =VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('title')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGb=VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('thumbnail')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGa =VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('age')
   if VjzgNqcRxQlpWBuOyXAwivMmUsoEGa=='18' or VjzgNqcRxQlpWBuOyXAwivMmUsoEGa=='19' or VjzgNqcRxQlpWBuOyXAwivMmUsoEGa=='21':VjzgNqcRxQlpWBuOyXAwivMmUsoELC+=' (%s)'%(VjzgNqcRxQlpWBuOyXAwivMmUsoEGa)
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGJ={'plot':VjzgNqcRxQlpWBuOyXAwivMmUsoELC,'mpaa':VjzgNqcRxQlpWBuOyXAwivMmUsoEGa,'mediatype':'movie'}
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ={'mode':'MOVIE','contentid':VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('videoid'),'title':VjzgNqcRxQlpWBuOyXAwivMmUsoELC,'thumbnail':VjzgNqcRxQlpWBuOyXAwivMmUsoEGb,'age':VjzgNqcRxQlpWBuOyXAwivMmUsoEGa}
   if VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.get_settings_makebookmark():
    VjzgNqcRxQlpWBuOyXAwivMmUsoEGI={'videoid':VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('videoid'),'vidtype':'movie','vtitle':VjzgNqcRxQlpWBuOyXAwivMmUsoELC,'vsubtitle':'','contenttype':'programid',}
    VjzgNqcRxQlpWBuOyXAwivMmUsoEGY=json.dumps(VjzgNqcRxQlpWBuOyXAwivMmUsoEGI)
    VjzgNqcRxQlpWBuOyXAwivMmUsoEGY=urllib.parse.quote(VjzgNqcRxQlpWBuOyXAwivMmUsoEGY)
    VjzgNqcRxQlpWBuOyXAwivMmUsoEGk='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(VjzgNqcRxQlpWBuOyXAwivMmUsoEGY)
    VjzgNqcRxQlpWBuOyXAwivMmUsoEGF=[('(통합) 찜 영상에 추가',VjzgNqcRxQlpWBuOyXAwivMmUsoEGk)]
   else:
    VjzgNqcRxQlpWBuOyXAwivMmUsoEGF=VjzgNqcRxQlpWBuOyXAwivMmUsoEKb
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.add_dir(VjzgNqcRxQlpWBuOyXAwivMmUsoELC,sublabel='',img=VjzgNqcRxQlpWBuOyXAwivMmUsoEGb,infoLabels=VjzgNqcRxQlpWBuOyXAwivMmUsoEGJ,isFolder=VjzgNqcRxQlpWBuOyXAwivMmUsoEKY,params=VjzgNqcRxQlpWBuOyXAwivMmUsoELJ,ContextMenu=VjzgNqcRxQlpWBuOyXAwivMmUsoEGF)
  if VjzgNqcRxQlpWBuOyXAwivMmUsoELf:
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ={}
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ['mode'] ='MOVIE_LIST' 
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ['subapi']=VjzgNqcRxQlpWBuOyXAwivMmUsoErH 
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ['page'] =VjzgNqcRxQlpWBuOyXAwivMmUsoESL(VjzgNqcRxQlpWBuOyXAwivMmUsoEGh+1)
   VjzgNqcRxQlpWBuOyXAwivMmUsoELC='[B]%s >>[/B]'%'다음 페이지'
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGT=VjzgNqcRxQlpWBuOyXAwivMmUsoESL(VjzgNqcRxQlpWBuOyXAwivMmUsoEGh+1)
   VjzgNqcRxQlpWBuOyXAwivMmUsoELF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.add_dir(VjzgNqcRxQlpWBuOyXAwivMmUsoELC,sublabel=VjzgNqcRxQlpWBuOyXAwivMmUsoEGT,img=VjzgNqcRxQlpWBuOyXAwivMmUsoELF,infoLabels=VjzgNqcRxQlpWBuOyXAwivMmUsoEKb,isFolder=VjzgNqcRxQlpWBuOyXAwivMmUsoEKI,params=VjzgNqcRxQlpWBuOyXAwivMmUsoELJ)
  xbmcplugin.setContent(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS._addon_handle,'movies')
  if VjzgNqcRxQlpWBuOyXAwivMmUsoEKf(VjzgNqcRxQlpWBuOyXAwivMmUsoEGP)>0:xbmcplugin.endOfDirectory(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS._addon_handle,cacheToDisc=VjzgNqcRxQlpWBuOyXAwivMmUsoEKY)
 def dp_Set_Bookmark(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS,args):
  VjzgNqcRxQlpWBuOyXAwivMmUsoErI=urllib.parse.unquote(args.get('bm_param'))
  VjzgNqcRxQlpWBuOyXAwivMmUsoErI=json.loads(VjzgNqcRxQlpWBuOyXAwivMmUsoErI)
  VjzgNqcRxQlpWBuOyXAwivMmUsoEDe =VjzgNqcRxQlpWBuOyXAwivMmUsoErI.get('videoid')
  VjzgNqcRxQlpWBuOyXAwivMmUsoErY =VjzgNqcRxQlpWBuOyXAwivMmUsoErI.get('vidtype')
  VjzgNqcRxQlpWBuOyXAwivMmUsoErk =VjzgNqcRxQlpWBuOyXAwivMmUsoErI.get('vtitle')
  VjzgNqcRxQlpWBuOyXAwivMmUsoErT =VjzgNqcRxQlpWBuOyXAwivMmUsoErI.get('vsubtitle')
  VjzgNqcRxQlpWBuOyXAwivMmUsoErf=VjzgNqcRxQlpWBuOyXAwivMmUsoErI.get('contenttype')
  VjzgNqcRxQlpWBuOyXAwivMmUsoEeJ=xbmcgui.Dialog()
  VjzgNqcRxQlpWBuOyXAwivMmUsoEDd=VjzgNqcRxQlpWBuOyXAwivMmUsoEeJ.yesno(__language__(30913).encode('utf8'),VjzgNqcRxQlpWBuOyXAwivMmUsoErk+' \n\n'+__language__(30914))
  if VjzgNqcRxQlpWBuOyXAwivMmUsoEDd==VjzgNqcRxQlpWBuOyXAwivMmUsoEKY:return
  VjzgNqcRxQlpWBuOyXAwivMmUsoEKe=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.WavveObj.GetBookmarkInfo(VjzgNqcRxQlpWBuOyXAwivMmUsoEDe,VjzgNqcRxQlpWBuOyXAwivMmUsoErY,VjzgNqcRxQlpWBuOyXAwivMmUsoErf)
  VjzgNqcRxQlpWBuOyXAwivMmUsoEKL=json.dumps(VjzgNqcRxQlpWBuOyXAwivMmUsoEKe)
  VjzgNqcRxQlpWBuOyXAwivMmUsoEKL=urllib.parse.quote(VjzgNqcRxQlpWBuOyXAwivMmUsoEKL)
  VjzgNqcRxQlpWBuOyXAwivMmUsoEGk ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(VjzgNqcRxQlpWBuOyXAwivMmUsoEKL)
  xbmc.executebuiltin(VjzgNqcRxQlpWBuOyXAwivMmUsoEGk)
 def dp_Episode_List(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS,args):
  VjzgNqcRxQlpWBuOyXAwivMmUsoEDe =args.get('videoid')
  VjzgNqcRxQlpWBuOyXAwivMmUsoErY =args.get('vidtype')
  VjzgNqcRxQlpWBuOyXAwivMmUsoEGh=VjzgNqcRxQlpWBuOyXAwivMmUsoEKa(args.get('page'))
  VjzgNqcRxQlpWBuOyXAwivMmUsoEGP,VjzgNqcRxQlpWBuOyXAwivMmUsoELf=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.WavveObj.Get_Episode_List(VjzgNqcRxQlpWBuOyXAwivMmUsoEDe,VjzgNqcRxQlpWBuOyXAwivMmUsoErY,VjzgNqcRxQlpWBuOyXAwivMmUsoEGh,orderby=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.get_winEpisodeOrderby())
  for VjzgNqcRxQlpWBuOyXAwivMmUsoEGd in VjzgNqcRxQlpWBuOyXAwivMmUsoEGP:
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGT='%s회, %s(%s)'%(VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('episodenumber'),VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('releasedate'),VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('releaseweekday'))
   VjzgNqcRxQlpWBuOyXAwivMmUsoEKG ='[%s]\n\n%s'%(VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('episodetitle'),VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('synopsis'))
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGJ={'mediatype':'episode','title':VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('programtitle'),'year':VjzgNqcRxQlpWBuOyXAwivMmUsoEKa(VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('releasedate')[:4]),'aired':VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('releasedate'),'mpaa':VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('age'),'episode':VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('episodenumber'),'duration':VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('playtime'),'plot':VjzgNqcRxQlpWBuOyXAwivMmUsoEKG,'cast':VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('episodeactors')}
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ={'mode':'VOD','programid':VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('programid'),'contentid':VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('contentid'),'thumbnail':VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('thumbnail'),'title':VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('programtitle'),'subtitle':VjzgNqcRxQlpWBuOyXAwivMmUsoEGT}
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.add_dir(VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('programtitle'),sublabel=VjzgNqcRxQlpWBuOyXAwivMmUsoEGT,img=VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('thumbnail'),infoLabels=VjzgNqcRxQlpWBuOyXAwivMmUsoEGJ,isFolder=VjzgNqcRxQlpWBuOyXAwivMmUsoEKY,params=VjzgNqcRxQlpWBuOyXAwivMmUsoELJ)
  if VjzgNqcRxQlpWBuOyXAwivMmUsoEGh==1:
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGJ={'plot':'정렬순서를 변경합니다.'}
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ={}
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ['mode'] ='ORDER_BY' 
   if VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.get_winEpisodeOrderby()=='desc':
    VjzgNqcRxQlpWBuOyXAwivMmUsoELC='정렬순서변경 : 최신화부터 -> 1회부터'
    VjzgNqcRxQlpWBuOyXAwivMmUsoELJ['orderby']='asc'
   else:
    VjzgNqcRxQlpWBuOyXAwivMmUsoELC='정렬순서변경 : 1회부터 -> 최신화부터'
    VjzgNqcRxQlpWBuOyXAwivMmUsoELJ['orderby']='desc'
   VjzgNqcRxQlpWBuOyXAwivMmUsoELF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.add_dir(VjzgNqcRxQlpWBuOyXAwivMmUsoELC,sublabel='',img=VjzgNqcRxQlpWBuOyXAwivMmUsoELF,infoLabels=VjzgNqcRxQlpWBuOyXAwivMmUsoEGJ,isFolder=VjzgNqcRxQlpWBuOyXAwivMmUsoEKY,params=VjzgNqcRxQlpWBuOyXAwivMmUsoELJ,isLink=VjzgNqcRxQlpWBuOyXAwivMmUsoEKI)
  if VjzgNqcRxQlpWBuOyXAwivMmUsoELf:
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ={}
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ['mode'] ='EPISODE_LIST' 
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ['videoid']=VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('programid')
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ['vidtype']='programid'
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ['page'] =VjzgNqcRxQlpWBuOyXAwivMmUsoESL(VjzgNqcRxQlpWBuOyXAwivMmUsoEGh+1)
   VjzgNqcRxQlpWBuOyXAwivMmUsoELC='[B]%s >>[/B]'%'다음 페이지'
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGT=VjzgNqcRxQlpWBuOyXAwivMmUsoESL(VjzgNqcRxQlpWBuOyXAwivMmUsoEGh+1)
   VjzgNqcRxQlpWBuOyXAwivMmUsoELF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.add_dir(VjzgNqcRxQlpWBuOyXAwivMmUsoELC,sublabel=VjzgNqcRxQlpWBuOyXAwivMmUsoEGT,img=VjzgNqcRxQlpWBuOyXAwivMmUsoELF,infoLabels=VjzgNqcRxQlpWBuOyXAwivMmUsoEKb,isFolder=VjzgNqcRxQlpWBuOyXAwivMmUsoEKI,params=VjzgNqcRxQlpWBuOyXAwivMmUsoELJ)
  xbmcplugin.setContent(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS._addon_handle,'episodes')
  if VjzgNqcRxQlpWBuOyXAwivMmUsoEKf(VjzgNqcRxQlpWBuOyXAwivMmUsoEGP)>0:xbmcplugin.endOfDirectory(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS._addon_handle,cacheToDisc=VjzgNqcRxQlpWBuOyXAwivMmUsoEKY)
 def dp_LiveChannel_List(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS,args):
  VjzgNqcRxQlpWBuOyXAwivMmUsoEKD =args.get('genre')
  VjzgNqcRxQlpWBuOyXAwivMmUsoErt=args.get('baseapi')
  VjzgNqcRxQlpWBuOyXAwivMmUsoEGP=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.WavveObj.Get_LiveChannel_List(VjzgNqcRxQlpWBuOyXAwivMmUsoEKD,VjzgNqcRxQlpWBuOyXAwivMmUsoErt)
  for VjzgNqcRxQlpWBuOyXAwivMmUsoEGd in VjzgNqcRxQlpWBuOyXAwivMmUsoEGP:
   VjzgNqcRxQlpWBuOyXAwivMmUsoErd =VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('channelid')
   VjzgNqcRxQlpWBuOyXAwivMmUsoErb =VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('studio')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEra=VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('tvshowtitle')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGb =VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('thumbnail')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGa =VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('age')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEKn =VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('epg')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGJ={'mediatype':'episode','mpaa':VjzgNqcRxQlpWBuOyXAwivMmUsoEGa,'title':'%s < %s >'%(VjzgNqcRxQlpWBuOyXAwivMmUsoErb,VjzgNqcRxQlpWBuOyXAwivMmUsoEra),'tvshowtitle':VjzgNqcRxQlpWBuOyXAwivMmUsoEra,'studio':VjzgNqcRxQlpWBuOyXAwivMmUsoErb,'plot':'%s\n\n%s'%(VjzgNqcRxQlpWBuOyXAwivMmUsoErb,VjzgNqcRxQlpWBuOyXAwivMmUsoEKn)}
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ={'mode':'LIVE','contentid':VjzgNqcRxQlpWBuOyXAwivMmUsoErd}
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.add_dir(VjzgNqcRxQlpWBuOyXAwivMmUsoErb,sublabel=VjzgNqcRxQlpWBuOyXAwivMmUsoEra,img=VjzgNqcRxQlpWBuOyXAwivMmUsoEGb,infoLabels=VjzgNqcRxQlpWBuOyXAwivMmUsoEGJ,isFolder=VjzgNqcRxQlpWBuOyXAwivMmUsoEKY,params=VjzgNqcRxQlpWBuOyXAwivMmUsoELJ)
  if VjzgNqcRxQlpWBuOyXAwivMmUsoEKf(VjzgNqcRxQlpWBuOyXAwivMmUsoEGP)>0:xbmcplugin.endOfDirectory(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS._addon_handle,cacheToDisc=VjzgNqcRxQlpWBuOyXAwivMmUsoEKY)
 def dp_Sports_GameList(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS,args):
  VjzgNqcRxQlpWBuOyXAwivMmUsoEGP=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.WavveObj.Get_Sports_Gamelist()
  for VjzgNqcRxQlpWBuOyXAwivMmUsoEGd in VjzgNqcRxQlpWBuOyXAwivMmUsoEGP:
   VjzgNqcRxQlpWBuOyXAwivMmUsoEKr =VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('game_date')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEKS =VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('game_time')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEKC =VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('svc_id')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEKt =VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('away_team')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEKH =VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('home_team')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEKF=VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('game_status')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEKJ =VjzgNqcRxQlpWBuOyXAwivMmUsoEGd.get('game_place')
   VjzgNqcRxQlpWBuOyXAwivMmUsoEKh ='%s vs %s (%s)'%(VjzgNqcRxQlpWBuOyXAwivMmUsoEKt,VjzgNqcRxQlpWBuOyXAwivMmUsoEKH,VjzgNqcRxQlpWBuOyXAwivMmUsoEKJ)
   VjzgNqcRxQlpWBuOyXAwivMmUsoEKP =VjzgNqcRxQlpWBuOyXAwivMmUsoEKr+' '+VjzgNqcRxQlpWBuOyXAwivMmUsoEKS
   if VjzgNqcRxQlpWBuOyXAwivMmUsoEKF=='LIVE':
    VjzgNqcRxQlpWBuOyXAwivMmUsoEKF='~경기중~'
   elif VjzgNqcRxQlpWBuOyXAwivMmUsoEKF=='END':
    VjzgNqcRxQlpWBuOyXAwivMmUsoEKF='경기종료'
   elif VjzgNqcRxQlpWBuOyXAwivMmUsoEKF=='CANCEL':
    VjzgNqcRxQlpWBuOyXAwivMmUsoEKF='취소'
   else:
    VjzgNqcRxQlpWBuOyXAwivMmUsoEKF=''
   if VjzgNqcRxQlpWBuOyXAwivMmUsoEKF=='':
    VjzgNqcRxQlpWBuOyXAwivMmUsoEGT=VjzgNqcRxQlpWBuOyXAwivMmUsoEKh
   else:
    VjzgNqcRxQlpWBuOyXAwivMmUsoEGT=VjzgNqcRxQlpWBuOyXAwivMmUsoEKh+'  '+VjzgNqcRxQlpWBuOyXAwivMmUsoEKF
   VjzgNqcRxQlpWBuOyXAwivMmUsoEGJ={'mediatype':'episode','title':VjzgNqcRxQlpWBuOyXAwivMmUsoEKh,'plot':'%s\n\n%s\n\n%s'%(VjzgNqcRxQlpWBuOyXAwivMmUsoEKP,VjzgNqcRxQlpWBuOyXAwivMmUsoEKh,VjzgNqcRxQlpWBuOyXAwivMmUsoEKF)}
   VjzgNqcRxQlpWBuOyXAwivMmUsoELJ={'mode':'SPORTS','contentid':VjzgNqcRxQlpWBuOyXAwivMmUsoEKC}
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.add_dir(VjzgNqcRxQlpWBuOyXAwivMmUsoEKP,sublabel=VjzgNqcRxQlpWBuOyXAwivMmUsoEGT,img='',infoLabels=VjzgNqcRxQlpWBuOyXAwivMmUsoEGJ,isFolder=VjzgNqcRxQlpWBuOyXAwivMmUsoEKY,params=VjzgNqcRxQlpWBuOyXAwivMmUsoELJ)
  xbmcplugin.endOfDirectory(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS._addon_handle,cacheToDisc=VjzgNqcRxQlpWBuOyXAwivMmUsoEKY)
 def wavve_main(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS):
  VjzgNqcRxQlpWBuOyXAwivMmUsoELY=VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.main_params.get('mode',VjzgNqcRxQlpWBuOyXAwivMmUsoEKb)
  if VjzgNqcRxQlpWBuOyXAwivMmUsoELY=='LOGOUT':
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.logout()
   return
  VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.login_main()
  if VjzgNqcRxQlpWBuOyXAwivMmUsoELY is VjzgNqcRxQlpWBuOyXAwivMmUsoEKb:
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.dp_Main_List()
  elif VjzgNqcRxQlpWBuOyXAwivMmUsoELY in['LIVE','VOD','MOVIE','SPORTS']:
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.play_VIDEO(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.main_params)
  elif VjzgNqcRxQlpWBuOyXAwivMmUsoELY=='LIVE_CATAGORY':
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.dp_LiveCatagory_List(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.main_params)
  elif VjzgNqcRxQlpWBuOyXAwivMmUsoELY=='MAIN_CATAGORY':
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.dp_MainCatagory_List(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.main_params)
  elif VjzgNqcRxQlpWBuOyXAwivMmUsoELY=='SUPERSECTION_LIST':
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.dp_SuperSection_List(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.main_params)
  elif VjzgNqcRxQlpWBuOyXAwivMmUsoELY=='BANDLIVESECTION_LIST':
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.dp_BandLiveSection_List(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.main_params)
  elif VjzgNqcRxQlpWBuOyXAwivMmUsoELY=='BAND2SECTION_LIST':
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.dp_Band2Section_List(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.main_params)
  elif VjzgNqcRxQlpWBuOyXAwivMmUsoELY=='PROGRAM_LIST':
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.dp_Program_List(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.main_params)
  elif VjzgNqcRxQlpWBuOyXAwivMmUsoELY=='EPISODE_LIST':
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.dp_Episode_List(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.main_params)
  elif VjzgNqcRxQlpWBuOyXAwivMmUsoELY=='MOVIE_LIST':
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.dp_Movie_List(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.main_params)
  elif VjzgNqcRxQlpWBuOyXAwivMmUsoELY=='LIVE_LIST':
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.dp_LiveChannel_List(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.main_params)
  elif VjzgNqcRxQlpWBuOyXAwivMmUsoELY=='ORDER_BY':
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.dp_setEpOrderby(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.main_params)
  elif VjzgNqcRxQlpWBuOyXAwivMmUsoELY=='SEARCH_GROUP':
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.dp_Search_Group(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.main_params)
  elif VjzgNqcRxQlpWBuOyXAwivMmUsoELY in['SEARCH_LIST','LOCAL_SEARCH']:
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.dp_Search_List(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.main_params)
  elif VjzgNqcRxQlpWBuOyXAwivMmUsoELY=='WATCH_GROUP':
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.dp_Watch_Group(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.main_params)
  elif VjzgNqcRxQlpWBuOyXAwivMmUsoELY=='WATCH_LIST':
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.dp_Watch_List(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.main_params)
  elif VjzgNqcRxQlpWBuOyXAwivMmUsoELY=='SET_BOOKMARK':
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.dp_Set_Bookmark(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.main_params)
  elif VjzgNqcRxQlpWBuOyXAwivMmUsoELY in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.dp_History_Remove(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.main_params)
  elif VjzgNqcRxQlpWBuOyXAwivMmUsoELY in['TOTAL_SEARCH','TOTAL_HISTORY']:
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.dp_Global_Search(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.main_params)
  elif VjzgNqcRxQlpWBuOyXAwivMmUsoELY=='SEARCH_HISTORY':
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.dp_Search_History(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.main_params)
  elif VjzgNqcRxQlpWBuOyXAwivMmUsoELY=='MENU_BOOKMARK':
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.dp_Bookmark_Menu(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.main_params)
  elif VjzgNqcRxQlpWBuOyXAwivMmUsoELY=='GAME_LIST':
   VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.dp_Sports_GameList(VjzgNqcRxQlpWBuOyXAwivMmUsoEeS.main_params)
  else:
   VjzgNqcRxQlpWBuOyXAwivMmUsoEKb
# Created by pyminifier (https://github.com/liftoff/pyminifier)
