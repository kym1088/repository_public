__author__="NightRain"
aerFXvzkPtSBTNwjlUohROxGJDIKbQ=object
aerFXvzkPtSBTNwjlUohROxGJDIKbp=None
aerFXvzkPtSBTNwjlUohROxGJDIKbi=False
aerFXvzkPtSBTNwjlUohROxGJDIKbE=open
aerFXvzkPtSBTNwjlUohROxGJDIKbA=True
aerFXvzkPtSBTNwjlUohROxGJDIKbH=range
aerFXvzkPtSBTNwjlUohROxGJDIKbM=str
aerFXvzkPtSBTNwjlUohROxGJDIKbc=Exception
aerFXvzkPtSBTNwjlUohROxGJDIKbL=print
aerFXvzkPtSBTNwjlUohROxGJDIKbn=dict
aerFXvzkPtSBTNwjlUohROxGJDIKbV=int
aerFXvzkPtSBTNwjlUohROxGJDIKbu=len
import urllib
import re
import json
import sys
import requests
import datetime
import base64
class aerFXvzkPtSBTNwjlUohROxGJDIKCQ(aerFXvzkPtSBTNwjlUohROxGJDIKbQ):
 def __init__(aerFXvzkPtSBTNwjlUohROxGJDIKCp):
  aerFXvzkPtSBTNwjlUohROxGJDIKCp.API_DOMAIN='https://apis.wavve.com'
  aerFXvzkPtSBTNwjlUohROxGJDIKCp.WV ={}
  aerFXvzkPtSBTNwjlUohROxGJDIKCp.Init_WV_Total()
  aerFXvzkPtSBTNwjlUohROxGJDIKCp.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  aerFXvzkPtSBTNwjlUohROxGJDIKCp.DEVICE ='pc'
  aerFXvzkPtSBTNwjlUohROxGJDIKCp.DRM ='wm'
  aerFXvzkPtSBTNwjlUohROxGJDIKCp.PARTNER ='pooq'
  aerFXvzkPtSBTNwjlUohROxGJDIKCp.POOQZONE ='none'
  aerFXvzkPtSBTNwjlUohROxGJDIKCp.REGION ='kor'
  aerFXvzkPtSBTNwjlUohROxGJDIKCp.TARGETAGE ='all'
  aerFXvzkPtSBTNwjlUohROxGJDIKCp.HTTPTAG ='https://'
  aerFXvzkPtSBTNwjlUohROxGJDIKCp.LIST_LIMIT=30 
  aerFXvzkPtSBTNwjlUohROxGJDIKCp.EP_LIMIT =30 
  aerFXvzkPtSBTNwjlUohROxGJDIKCp.MV_LIMIT =24 
  aerFXvzkPtSBTNwjlUohROxGJDIKCp.SEARCH_LIMIT=20 
  aerFXvzkPtSBTNwjlUohROxGJDIKCp.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36'
  aerFXvzkPtSBTNwjlUohROxGJDIKCp.DEFAULT_HEADER={'user-agent':aerFXvzkPtSBTNwjlUohROxGJDIKCp.USER_AGENT}
 def Init_WV_Total(aerFXvzkPtSBTNwjlUohROxGJDIKCp):
  aerFXvzkPtSBTNwjlUohROxGJDIKCp.WV={'account':{},'cookies':{},}
 def callRequestCookies(aerFXvzkPtSBTNwjlUohROxGJDIKCp,jobtype,aerFXvzkPtSBTNwjlUohROxGJDIKCq,payload=aerFXvzkPtSBTNwjlUohROxGJDIKbp,params=aerFXvzkPtSBTNwjlUohROxGJDIKbp,headers=aerFXvzkPtSBTNwjlUohROxGJDIKbp,cookies=aerFXvzkPtSBTNwjlUohROxGJDIKbp,redirects=aerFXvzkPtSBTNwjlUohROxGJDIKbi):
  aerFXvzkPtSBTNwjlUohROxGJDIKCi=aerFXvzkPtSBTNwjlUohROxGJDIKCp.DEFAULT_HEADER
  if headers:aerFXvzkPtSBTNwjlUohROxGJDIKCi.update(headers)
  if jobtype=='Get':
   aerFXvzkPtSBTNwjlUohROxGJDIKCE=requests.get(aerFXvzkPtSBTNwjlUohROxGJDIKCq,params=params,headers=aerFXvzkPtSBTNwjlUohROxGJDIKCi,cookies=cookies,allow_redirects=redirects)
  else:
   aerFXvzkPtSBTNwjlUohROxGJDIKCE=requests.post(aerFXvzkPtSBTNwjlUohROxGJDIKCq,data=payload,params=params,headers=aerFXvzkPtSBTNwjlUohROxGJDIKCi,cookies=cookies,allow_redirects=redirects)
  return aerFXvzkPtSBTNwjlUohROxGJDIKCE
 def JsonFile_Save(aerFXvzkPtSBTNwjlUohROxGJDIKCp,filename,aerFXvzkPtSBTNwjlUohROxGJDIKCb):
  if filename=='':return aerFXvzkPtSBTNwjlUohROxGJDIKbi
  try:
   fp=aerFXvzkPtSBTNwjlUohROxGJDIKbE(filename,'w',-1,'utf-8')
   json.dump(aerFXvzkPtSBTNwjlUohROxGJDIKCb,fp,indent=4,ensure_ascii=aerFXvzkPtSBTNwjlUohROxGJDIKbi)
   fp.close()
  except:
   return aerFXvzkPtSBTNwjlUohROxGJDIKbi
  return aerFXvzkPtSBTNwjlUohROxGJDIKbA
 def JsonFile_Load(aerFXvzkPtSBTNwjlUohROxGJDIKCp,filename):
  if filename=='':return{}
  try:
   fp=aerFXvzkPtSBTNwjlUohROxGJDIKbE(filename,'r',-1,'utf-8')
   aerFXvzkPtSBTNwjlUohROxGJDIKCH=json.load(fp)
   fp.close()
  except:
   return{}
  return aerFXvzkPtSBTNwjlUohROxGJDIKCH
 def Save_session_acount(aerFXvzkPtSBTNwjlUohROxGJDIKCp,aerFXvzkPtSBTNwjlUohROxGJDIKCM,aerFXvzkPtSBTNwjlUohROxGJDIKCc,aerFXvzkPtSBTNwjlUohROxGJDIKCL):
  aerFXvzkPtSBTNwjlUohROxGJDIKCp.WV['account']['wvid']=base64.standard_b64encode(aerFXvzkPtSBTNwjlUohROxGJDIKCM.encode()).decode('utf-8')
  aerFXvzkPtSBTNwjlUohROxGJDIKCp.WV['account']['wvpw']=base64.standard_b64encode(aerFXvzkPtSBTNwjlUohROxGJDIKCc.encode()).decode('utf-8')
  aerFXvzkPtSBTNwjlUohROxGJDIKCp.WV['account']['wvpf']=aerFXvzkPtSBTNwjlUohROxGJDIKCL 
 def Load_session_acount(aerFXvzkPtSBTNwjlUohROxGJDIKCp):
  try:
   aerFXvzkPtSBTNwjlUohROxGJDIKCM=base64.standard_b64decode(aerFXvzkPtSBTNwjlUohROxGJDIKCp.WV['account']['wvid']).decode('utf-8')
   aerFXvzkPtSBTNwjlUohROxGJDIKCc=base64.standard_b64decode(aerFXvzkPtSBTNwjlUohROxGJDIKCp.WV['account']['wvpw']).decode('utf-8')
   aerFXvzkPtSBTNwjlUohROxGJDIKCL=aerFXvzkPtSBTNwjlUohROxGJDIKCp.WV['account']['wvpf']
  except:
   return '','',0
  return aerFXvzkPtSBTNwjlUohROxGJDIKCM,aerFXvzkPtSBTNwjlUohROxGJDIKCc,aerFXvzkPtSBTNwjlUohROxGJDIKCL
 def GetDefaultParams(aerFXvzkPtSBTNwjlUohROxGJDIKCp,login=aerFXvzkPtSBTNwjlUohROxGJDIKbA):
  aerFXvzkPtSBTNwjlUohROxGJDIKCn={'apikey':aerFXvzkPtSBTNwjlUohROxGJDIKCp.APIKEY,'credential':aerFXvzkPtSBTNwjlUohROxGJDIKCp.WV['cookies']['credential']if login else 'none','device':aerFXvzkPtSBTNwjlUohROxGJDIKCp.DEVICE,'drm':aerFXvzkPtSBTNwjlUohROxGJDIKCp.DRM,'partner':aerFXvzkPtSBTNwjlUohROxGJDIKCp.PARTNER,'pooqzone':aerFXvzkPtSBTNwjlUohROxGJDIKCp.POOQZONE,'region':aerFXvzkPtSBTNwjlUohROxGJDIKCp.REGION,'targetage':aerFXvzkPtSBTNwjlUohROxGJDIKCp.TARGETAGE}
  return aerFXvzkPtSBTNwjlUohROxGJDIKCn
 def GetGUID(aerFXvzkPtSBTNwjlUohROxGJDIKCp,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   aerFXvzkPtSBTNwjlUohROxGJDIKCV=aerFXvzkPtSBTNwjlUohROxGJDIKCp.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   aerFXvzkPtSBTNwjlUohROxGJDIKCu=GenerateRandomString(5)
   aerFXvzkPtSBTNwjlUohROxGJDIKCY=aerFXvzkPtSBTNwjlUohROxGJDIKCu+media+aerFXvzkPtSBTNwjlUohROxGJDIKCV
   return aerFXvzkPtSBTNwjlUohROxGJDIKCY
  def GenerateRandomString(num):
   from random import randint
   aerFXvzkPtSBTNwjlUohROxGJDIKCd=""
   for i in aerFXvzkPtSBTNwjlUohROxGJDIKbH(0,num):
    s=aerFXvzkPtSBTNwjlUohROxGJDIKbM(randint(1,5))
    aerFXvzkPtSBTNwjlUohROxGJDIKCd+=s
   return aerFXvzkPtSBTNwjlUohROxGJDIKCd
  aerFXvzkPtSBTNwjlUohROxGJDIKCY=GenerateID(guid_str)
  aerFXvzkPtSBTNwjlUohROxGJDIKCf=aerFXvzkPtSBTNwjlUohROxGJDIKCp.GetHash(aerFXvzkPtSBTNwjlUohROxGJDIKCY)
  if guidType==2:
   aerFXvzkPtSBTNwjlUohROxGJDIKCf='%s-%s-%s-%s-%s'%(aerFXvzkPtSBTNwjlUohROxGJDIKCf[:8],aerFXvzkPtSBTNwjlUohROxGJDIKCf[8:12],aerFXvzkPtSBTNwjlUohROxGJDIKCf[12:16],aerFXvzkPtSBTNwjlUohROxGJDIKCf[16:20],aerFXvzkPtSBTNwjlUohROxGJDIKCf[20:])
  return aerFXvzkPtSBTNwjlUohROxGJDIKCf
 def GetHash(aerFXvzkPtSBTNwjlUohROxGJDIKCp,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return aerFXvzkPtSBTNwjlUohROxGJDIKbM(m.hexdigest())
 def CheckQuality(aerFXvzkPtSBTNwjlUohROxGJDIKCp,sel_qt,qt_list):
  aerFXvzkPtSBTNwjlUohROxGJDIKCg=0
  for aerFXvzkPtSBTNwjlUohROxGJDIKCy in qt_list:
   if sel_qt>=aerFXvzkPtSBTNwjlUohROxGJDIKCy:return aerFXvzkPtSBTNwjlUohROxGJDIKCy
   aerFXvzkPtSBTNwjlUohROxGJDIKCg=aerFXvzkPtSBTNwjlUohROxGJDIKCy
  return aerFXvzkPtSBTNwjlUohROxGJDIKCg
 def Get_Now_Datetime(aerFXvzkPtSBTNwjlUohROxGJDIKCp):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(aerFXvzkPtSBTNwjlUohROxGJDIKCp,in_text):
  aerFXvzkPtSBTNwjlUohROxGJDIKCs=in_text.replace('&lt;','<').replace('&gt;','>')
  aerFXvzkPtSBTNwjlUohROxGJDIKCs=aerFXvzkPtSBTNwjlUohROxGJDIKCs.replace('$O$','')
  aerFXvzkPtSBTNwjlUohROxGJDIKCs=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',aerFXvzkPtSBTNwjlUohROxGJDIKCs)
  aerFXvzkPtSBTNwjlUohROxGJDIKCs=aerFXvzkPtSBTNwjlUohROxGJDIKCs.lstrip('#')
  return aerFXvzkPtSBTNwjlUohROxGJDIKCs
 def GetCredential(aerFXvzkPtSBTNwjlUohROxGJDIKCp,user_id,user_pw,user_pf):
  aerFXvzkPtSBTNwjlUohROxGJDIKCm=aerFXvzkPtSBTNwjlUohROxGJDIKbi
  try:
   aerFXvzkPtSBTNwjlUohROxGJDIKCq=aerFXvzkPtSBTNwjlUohROxGJDIKCp.API_DOMAIN+ '/login'
   aerFXvzkPtSBTNwjlUohROxGJDIKCn=aerFXvzkPtSBTNwjlUohROxGJDIKCp.GetDefaultParams(login=aerFXvzkPtSBTNwjlUohROxGJDIKbi)
   aerFXvzkPtSBTNwjlUohROxGJDIKQC={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   aerFXvzkPtSBTNwjlUohROxGJDIKQp=aerFXvzkPtSBTNwjlUohROxGJDIKCp.callRequestCookies('Post',aerFXvzkPtSBTNwjlUohROxGJDIKCq,payload=aerFXvzkPtSBTNwjlUohROxGJDIKQC,params=aerFXvzkPtSBTNwjlUohROxGJDIKCn,headers=aerFXvzkPtSBTNwjlUohROxGJDIKbp,cookies=aerFXvzkPtSBTNwjlUohROxGJDIKbp)
   aerFXvzkPtSBTNwjlUohROxGJDIKQi=json.loads(aerFXvzkPtSBTNwjlUohROxGJDIKQp.text)
   aerFXvzkPtSBTNwjlUohROxGJDIKCp.WV['cookies']['credential']=aerFXvzkPtSBTNwjlUohROxGJDIKQi['credential']
   if user_pf!=0:
    aerFXvzkPtSBTNwjlUohROxGJDIKQC={'id':aerFXvzkPtSBTNwjlUohROxGJDIKCp.WV['cookies']['credential'],'password':'','profile':aerFXvzkPtSBTNwjlUohROxGJDIKbM(user_pf),'pushid':'','type':'credential'}
    aerFXvzkPtSBTNwjlUohROxGJDIKCn =aerFXvzkPtSBTNwjlUohROxGJDIKCp.GetDefaultParams(login=aerFXvzkPtSBTNwjlUohROxGJDIKbA) 
    aerFXvzkPtSBTNwjlUohROxGJDIKQp=aerFXvzkPtSBTNwjlUohROxGJDIKCp.callRequestCookies('Post',aerFXvzkPtSBTNwjlUohROxGJDIKCq,payload=aerFXvzkPtSBTNwjlUohROxGJDIKQC,params=aerFXvzkPtSBTNwjlUohROxGJDIKCn,headers=aerFXvzkPtSBTNwjlUohROxGJDIKbp,cookies=aerFXvzkPtSBTNwjlUohROxGJDIKbp)
    aerFXvzkPtSBTNwjlUohROxGJDIKQi=json.loads(aerFXvzkPtSBTNwjlUohROxGJDIKQp.text)
    aerFXvzkPtSBTNwjlUohROxGJDIKCp.WV['cookies']['credential']=aerFXvzkPtSBTNwjlUohROxGJDIKQi['credential']
    aerFXvzkPtSBTNwjlUohROxGJDIKCm=aerFXvzkPtSBTNwjlUohROxGJDIKbA
  except aerFXvzkPtSBTNwjlUohROxGJDIKbc as exception:
   aerFXvzkPtSBTNwjlUohROxGJDIKbL(exception)
   aerFXvzkPtSBTNwjlUohROxGJDIKCp.Init_WV_Total()
  return aerFXvzkPtSBTNwjlUohROxGJDIKCm
 def GetIssue(aerFXvzkPtSBTNwjlUohROxGJDIKCp):
  aerFXvzkPtSBTNwjlUohROxGJDIKQE=aerFXvzkPtSBTNwjlUohROxGJDIKbi
  try:
   aerFXvzkPtSBTNwjlUohROxGJDIKCq=aerFXvzkPtSBTNwjlUohROxGJDIKCp.API_DOMAIN+'/guid/issue'
   aerFXvzkPtSBTNwjlUohROxGJDIKCn=aerFXvzkPtSBTNwjlUohROxGJDIKCp.GetDefaultParams()
   aerFXvzkPtSBTNwjlUohROxGJDIKQp=aerFXvzkPtSBTNwjlUohROxGJDIKCp.callRequestCookies('Get',aerFXvzkPtSBTNwjlUohROxGJDIKCq,payload=aerFXvzkPtSBTNwjlUohROxGJDIKbp,params=aerFXvzkPtSBTNwjlUohROxGJDIKCn,headers=aerFXvzkPtSBTNwjlUohROxGJDIKbp,cookies=aerFXvzkPtSBTNwjlUohROxGJDIKbp)
   aerFXvzkPtSBTNwjlUohROxGJDIKQi=json.loads(aerFXvzkPtSBTNwjlUohROxGJDIKQp.text)
   aerFXvzkPtSBTNwjlUohROxGJDIKQb=aerFXvzkPtSBTNwjlUohROxGJDIKQi['guid']
   aerFXvzkPtSBTNwjlUohROxGJDIKQA=aerFXvzkPtSBTNwjlUohROxGJDIKQi['guidtimestamp']
   if aerFXvzkPtSBTNwjlUohROxGJDIKQb:aerFXvzkPtSBTNwjlUohROxGJDIKQE=aerFXvzkPtSBTNwjlUohROxGJDIKbA
  except aerFXvzkPtSBTNwjlUohROxGJDIKbc as exception:
   aerFXvzkPtSBTNwjlUohROxGJDIKbL(exception)
   aerFXvzkPtSBTNwjlUohROxGJDIKQb='none'
   aerFXvzkPtSBTNwjlUohROxGJDIKQA='none' 
  aerFXvzkPtSBTNwjlUohROxGJDIKCp.guid=aerFXvzkPtSBTNwjlUohROxGJDIKQb
  aerFXvzkPtSBTNwjlUohROxGJDIKCp.guidtimestamp=aerFXvzkPtSBTNwjlUohROxGJDIKQA
  return aerFXvzkPtSBTNwjlUohROxGJDIKQE
 def Baseapi_Parse(aerFXvzkPtSBTNwjlUohROxGJDIKCp,aerFXvzkPtSBTNwjlUohROxGJDIKQL):
  try:
   aerFXvzkPtSBTNwjlUohROxGJDIKQH =urllib.parse.urlsplit(aerFXvzkPtSBTNwjlUohROxGJDIKQL)
   if aerFXvzkPtSBTNwjlUohROxGJDIKQH.netloc=='':
    aerFXvzkPtSBTNwjlUohROxGJDIKCq=aerFXvzkPtSBTNwjlUohROxGJDIKCp.HTTPTAG+aerFXvzkPtSBTNwjlUohROxGJDIKQH.netloc+aerFXvzkPtSBTNwjlUohROxGJDIKQH.path
   else:
    aerFXvzkPtSBTNwjlUohROxGJDIKCq=aerFXvzkPtSBTNwjlUohROxGJDIKQH.scheme+'://'+aerFXvzkPtSBTNwjlUohROxGJDIKQH.netloc+aerFXvzkPtSBTNwjlUohROxGJDIKQH.path
   aerFXvzkPtSBTNwjlUohROxGJDIKCn=aerFXvzkPtSBTNwjlUohROxGJDIKbn(urllib.parse.parse_qsl(aerFXvzkPtSBTNwjlUohROxGJDIKQH.query))
  except aerFXvzkPtSBTNwjlUohROxGJDIKbc as exception:
   aerFXvzkPtSBTNwjlUohROxGJDIKbL(exception)
   return '',{}
  return aerFXvzkPtSBTNwjlUohROxGJDIKCq,aerFXvzkPtSBTNwjlUohROxGJDIKCn
 def GetSupermultiUrl(aerFXvzkPtSBTNwjlUohROxGJDIKCp,sCode,sIndex='0'):
  try:
   aerFXvzkPtSBTNwjlUohROxGJDIKCq=aerFXvzkPtSBTNwjlUohROxGJDIKCp.API_DOMAIN+'/cf/supermultisections/'+sCode
   aerFXvzkPtSBTNwjlUohROxGJDIKCn=aerFXvzkPtSBTNwjlUohROxGJDIKCp.GetDefaultParams(login=aerFXvzkPtSBTNwjlUohROxGJDIKbi)
   aerFXvzkPtSBTNwjlUohROxGJDIKQp=aerFXvzkPtSBTNwjlUohROxGJDIKCp.callRequestCookies('Get',aerFXvzkPtSBTNwjlUohROxGJDIKCq,payload=aerFXvzkPtSBTNwjlUohROxGJDIKbp,params=aerFXvzkPtSBTNwjlUohROxGJDIKCn,headers=aerFXvzkPtSBTNwjlUohROxGJDIKbp,cookies=aerFXvzkPtSBTNwjlUohROxGJDIKbp)
   aerFXvzkPtSBTNwjlUohROxGJDIKQi=json.loads(aerFXvzkPtSBTNwjlUohROxGJDIKQp.text)
   aerFXvzkPtSBTNwjlUohROxGJDIKQM=aerFXvzkPtSBTNwjlUohROxGJDIKQi['multisectionlist'][aerFXvzkPtSBTNwjlUohROxGJDIKbV(sIndex)]['eventlist'][1]['url']
  except aerFXvzkPtSBTNwjlUohROxGJDIKbc as exception:
   aerFXvzkPtSBTNwjlUohROxGJDIKbL(exception)
   return ''
  return aerFXvzkPtSBTNwjlUohROxGJDIKQM
 def Get_LiveCatagory_List(aerFXvzkPtSBTNwjlUohROxGJDIKCp,sCode,sIndex='0'):
  aerFXvzkPtSBTNwjlUohROxGJDIKQc=[]
  aerFXvzkPtSBTNwjlUohROxGJDIKQL =aerFXvzkPtSBTNwjlUohROxGJDIKCp.GetSupermultiUrl(sCode,sIndex)
  (aerFXvzkPtSBTNwjlUohROxGJDIKCq,aerFXvzkPtSBTNwjlUohROxGJDIKCn)=aerFXvzkPtSBTNwjlUohROxGJDIKCp.Baseapi_Parse(aerFXvzkPtSBTNwjlUohROxGJDIKQL)
  if aerFXvzkPtSBTNwjlUohROxGJDIKCq=='':return aerFXvzkPtSBTNwjlUohROxGJDIKQc,''
  try:
   aerFXvzkPtSBTNwjlUohROxGJDIKCn.update(aerFXvzkPtSBTNwjlUohROxGJDIKCp.GetDefaultParams(login=aerFXvzkPtSBTNwjlUohROxGJDIKbi))
   aerFXvzkPtSBTNwjlUohROxGJDIKQp=aerFXvzkPtSBTNwjlUohROxGJDIKCp.callRequestCookies('Get',aerFXvzkPtSBTNwjlUohROxGJDIKCq,payload=aerFXvzkPtSBTNwjlUohROxGJDIKbp,params=aerFXvzkPtSBTNwjlUohROxGJDIKCn,headers=aerFXvzkPtSBTNwjlUohROxGJDIKbp,cookies=aerFXvzkPtSBTNwjlUohROxGJDIKbp)
   aerFXvzkPtSBTNwjlUohROxGJDIKQi=json.loads(aerFXvzkPtSBTNwjlUohROxGJDIKQp.text)
   if not('filter_item_list' in aerFXvzkPtSBTNwjlUohROxGJDIKQi['filter']['filterlist'][0]):return[],''
   aerFXvzkPtSBTNwjlUohROxGJDIKQV=aerFXvzkPtSBTNwjlUohROxGJDIKQi['filter']['filterlist'][0]['filter_item_list']
   for aerFXvzkPtSBTNwjlUohROxGJDIKQu in aerFXvzkPtSBTNwjlUohROxGJDIKQV:
    aerFXvzkPtSBTNwjlUohROxGJDIKQY={'title':aerFXvzkPtSBTNwjlUohROxGJDIKQu['title'],'genre':aerFXvzkPtSBTNwjlUohROxGJDIKQu['api_parameters'][aerFXvzkPtSBTNwjlUohROxGJDIKQu['api_parameters'].index('=')+1:]}
    aerFXvzkPtSBTNwjlUohROxGJDIKQc.append(aerFXvzkPtSBTNwjlUohROxGJDIKQY)
  except aerFXvzkPtSBTNwjlUohROxGJDIKbc as exception:
   aerFXvzkPtSBTNwjlUohROxGJDIKbL(exception)
   return[],''
  return aerFXvzkPtSBTNwjlUohROxGJDIKQc,aerFXvzkPtSBTNwjlUohROxGJDIKQL
 def Get_MainCatagory_List(aerFXvzkPtSBTNwjlUohROxGJDIKCp,sCode,sIndex='0'):
  aerFXvzkPtSBTNwjlUohROxGJDIKQc=[]
  aerFXvzkPtSBTNwjlUohROxGJDIKQL =aerFXvzkPtSBTNwjlUohROxGJDIKCp.GetSupermultiUrl(sCode,sIndex)
  (aerFXvzkPtSBTNwjlUohROxGJDIKCq,aerFXvzkPtSBTNwjlUohROxGJDIKCn)=aerFXvzkPtSBTNwjlUohROxGJDIKCp.Baseapi_Parse(aerFXvzkPtSBTNwjlUohROxGJDIKQL)
  if aerFXvzkPtSBTNwjlUohROxGJDIKCq=='':return aerFXvzkPtSBTNwjlUohROxGJDIKQc
  try:
   aerFXvzkPtSBTNwjlUohROxGJDIKCn.update(aerFXvzkPtSBTNwjlUohROxGJDIKCp.GetDefaultParams(login=aerFXvzkPtSBTNwjlUohROxGJDIKbi))
   aerFXvzkPtSBTNwjlUohROxGJDIKQp=aerFXvzkPtSBTNwjlUohROxGJDIKCp.callRequestCookies('Get',aerFXvzkPtSBTNwjlUohROxGJDIKCq,payload=aerFXvzkPtSBTNwjlUohROxGJDIKbp,params=aerFXvzkPtSBTNwjlUohROxGJDIKCn,headers=aerFXvzkPtSBTNwjlUohROxGJDIKbp,cookies=aerFXvzkPtSBTNwjlUohROxGJDIKbp)
   aerFXvzkPtSBTNwjlUohROxGJDIKQi=json.loads(aerFXvzkPtSBTNwjlUohROxGJDIKQp.text)
   if not('celllist' in aerFXvzkPtSBTNwjlUohROxGJDIKQi['band']):return[]
   aerFXvzkPtSBTNwjlUohROxGJDIKQV=aerFXvzkPtSBTNwjlUohROxGJDIKQi['band']['celllist']
   for aerFXvzkPtSBTNwjlUohROxGJDIKQu in aerFXvzkPtSBTNwjlUohROxGJDIKQV:
    aerFXvzkPtSBTNwjlUohROxGJDIKQd =aerFXvzkPtSBTNwjlUohROxGJDIKQu['event_list'][1]['url']
    (aerFXvzkPtSBTNwjlUohROxGJDIKQf,aerFXvzkPtSBTNwjlUohROxGJDIKQg)=aerFXvzkPtSBTNwjlUohROxGJDIKCp.Baseapi_Parse(aerFXvzkPtSBTNwjlUohROxGJDIKQd)
    aerFXvzkPtSBTNwjlUohROxGJDIKQY={'title':aerFXvzkPtSBTNwjlUohROxGJDIKQu['title_list'][0]['text'],'suburl':aerFXvzkPtSBTNwjlUohROxGJDIKQf,'subapi':aerFXvzkPtSBTNwjlUohROxGJDIKQg.get('api'),'subtype':'catagory' if aerFXvzkPtSBTNwjlUohROxGJDIKQg else 'supersection'}
    aerFXvzkPtSBTNwjlUohROxGJDIKQc.append(aerFXvzkPtSBTNwjlUohROxGJDIKQY)
  except aerFXvzkPtSBTNwjlUohROxGJDIKbc as exception:
   aerFXvzkPtSBTNwjlUohROxGJDIKbL(exception)
   return[]
  return aerFXvzkPtSBTNwjlUohROxGJDIKQc
 def Get_SuperMultiSection_List(aerFXvzkPtSBTNwjlUohROxGJDIKCp,subapi_text):
  aerFXvzkPtSBTNwjlUohROxGJDIKQc=[]
  aerFXvzkPtSBTNwjlUohROxGJDIKCn={}
  try:
   aerFXvzkPtSBTNwjlUohROxGJDIKQH =urllib.parse.urlsplit(subapi_text)
   if aerFXvzkPtSBTNwjlUohROxGJDIKQH.path.find('apis.wavve.com')>=0: 
    aerFXvzkPtSBTNwjlUohROxGJDIKCq=aerFXvzkPtSBTNwjlUohROxGJDIKCp.HTTPTAG+aerFXvzkPtSBTNwjlUohROxGJDIKQH.path 
    aerFXvzkPtSBTNwjlUohROxGJDIKCn=aerFXvzkPtSBTNwjlUohROxGJDIKbn(urllib.parse.parse_qsl(aerFXvzkPtSBTNwjlUohROxGJDIKQH.query))
   else:
    aerFXvzkPtSBTNwjlUohROxGJDIKCq=aerFXvzkPtSBTNwjlUohROxGJDIKCp.API_DOMAIN+'/cf'+aerFXvzkPtSBTNwjlUohROxGJDIKQH.path 
   aerFXvzkPtSBTNwjlUohROxGJDIKCq=aerFXvzkPtSBTNwjlUohROxGJDIKCq.replace('supermultisection/','supermultisections/')
  except aerFXvzkPtSBTNwjlUohROxGJDIKbc as exception:
   aerFXvzkPtSBTNwjlUohROxGJDIKbL(exception)
   return[]
  try:
   aerFXvzkPtSBTNwjlUohROxGJDIKCn.update(aerFXvzkPtSBTNwjlUohROxGJDIKCp.GetDefaultParams(login=aerFXvzkPtSBTNwjlUohROxGJDIKbi))
   aerFXvzkPtSBTNwjlUohROxGJDIKQp=aerFXvzkPtSBTNwjlUohROxGJDIKCp.callRequestCookies('Get',aerFXvzkPtSBTNwjlUohROxGJDIKCq,payload=aerFXvzkPtSBTNwjlUohROxGJDIKbp,params=aerFXvzkPtSBTNwjlUohROxGJDIKbp,headers=aerFXvzkPtSBTNwjlUohROxGJDIKbp,cookies=aerFXvzkPtSBTNwjlUohROxGJDIKbp)
   aerFXvzkPtSBTNwjlUohROxGJDIKQi=json.loads(aerFXvzkPtSBTNwjlUohROxGJDIKQp.text)
   if not('multisectionlist' in aerFXvzkPtSBTNwjlUohROxGJDIKQi):return[]
   aerFXvzkPtSBTNwjlUohROxGJDIKQV=aerFXvzkPtSBTNwjlUohROxGJDIKQi['multisectionlist']
   for aerFXvzkPtSBTNwjlUohROxGJDIKQu in aerFXvzkPtSBTNwjlUohROxGJDIKQV:
    aerFXvzkPtSBTNwjlUohROxGJDIKQy=aerFXvzkPtSBTNwjlUohROxGJDIKQu['title']
    if aerFXvzkPtSBTNwjlUohROxGJDIKbu(aerFXvzkPtSBTNwjlUohROxGJDIKQy)==0:continue
    if aerFXvzkPtSBTNwjlUohROxGJDIKQy=='minor':continue
    if re.search(u'베너',aerFXvzkPtSBTNwjlUohROxGJDIKQy):continue
    if re.search(u'배너',aerFXvzkPtSBTNwjlUohROxGJDIKQy):continue 
    if aerFXvzkPtSBTNwjlUohROxGJDIKbu(aerFXvzkPtSBTNwjlUohROxGJDIKQu['eventlist'])>=3:
     aerFXvzkPtSBTNwjlUohROxGJDIKQg =aerFXvzkPtSBTNwjlUohROxGJDIKQu['eventlist'][2]['url']
    else:
     aerFXvzkPtSBTNwjlUohROxGJDIKQg =aerFXvzkPtSBTNwjlUohROxGJDIKQu['eventlist'][1]['url']
    aerFXvzkPtSBTNwjlUohROxGJDIKQW=aerFXvzkPtSBTNwjlUohROxGJDIKQu['cell_type']
    if aerFXvzkPtSBTNwjlUohROxGJDIKQW=='band_2':
     if aerFXvzkPtSBTNwjlUohROxGJDIKQg.find('channellist=')>=0:
      aerFXvzkPtSBTNwjlUohROxGJDIKQW='band_live'
    aerFXvzkPtSBTNwjlUohROxGJDIKQY={'title':aerFXvzkPtSBTNwjlUohROxGJDIKCp.Get_ChangeText(aerFXvzkPtSBTNwjlUohROxGJDIKQy),'subapi':aerFXvzkPtSBTNwjlUohROxGJDIKQg,'cell_type':aerFXvzkPtSBTNwjlUohROxGJDIKQW}
    aerFXvzkPtSBTNwjlUohROxGJDIKQc.append(aerFXvzkPtSBTNwjlUohROxGJDIKQY)
  except aerFXvzkPtSBTNwjlUohROxGJDIKbc as exception:
   aerFXvzkPtSBTNwjlUohROxGJDIKbL(exception)
   return[]
  return aerFXvzkPtSBTNwjlUohROxGJDIKQc
 def Get_BandLiveSection_List(aerFXvzkPtSBTNwjlUohROxGJDIKCp,aerFXvzkPtSBTNwjlUohROxGJDIKQL,page_int=1):
  aerFXvzkPtSBTNwjlUohROxGJDIKQs=[]
  aerFXvzkPtSBTNwjlUohROxGJDIKQm=aerFXvzkPtSBTNwjlUohROxGJDIKpb=1
  aerFXvzkPtSBTNwjlUohROxGJDIKQq=aerFXvzkPtSBTNwjlUohROxGJDIKbi
  try:
   (aerFXvzkPtSBTNwjlUohROxGJDIKCq,aerFXvzkPtSBTNwjlUohROxGJDIKCn)=aerFXvzkPtSBTNwjlUohROxGJDIKCp.Baseapi_Parse(aerFXvzkPtSBTNwjlUohROxGJDIKQL)
  except aerFXvzkPtSBTNwjlUohROxGJDIKbc as exception:
   aerFXvzkPtSBTNwjlUohROxGJDIKbL(exception)
   return[],aerFXvzkPtSBTNwjlUohROxGJDIKbi
  try:
   aerFXvzkPtSBTNwjlUohROxGJDIKCn['limit']=aerFXvzkPtSBTNwjlUohROxGJDIKCp.LIST_LIMIT
   aerFXvzkPtSBTNwjlUohROxGJDIKCn['offset']=aerFXvzkPtSBTNwjlUohROxGJDIKbM((page_int-1)*aerFXvzkPtSBTNwjlUohROxGJDIKCp.LIST_LIMIT)
   aerFXvzkPtSBTNwjlUohROxGJDIKCn.update(aerFXvzkPtSBTNwjlUohROxGJDIKCp.GetDefaultParams(login=aerFXvzkPtSBTNwjlUohROxGJDIKbi))
   aerFXvzkPtSBTNwjlUohROxGJDIKQp=aerFXvzkPtSBTNwjlUohROxGJDIKCp.callRequestCookies('Get',aerFXvzkPtSBTNwjlUohROxGJDIKCq,payload=aerFXvzkPtSBTNwjlUohROxGJDIKbp,params=aerFXvzkPtSBTNwjlUohROxGJDIKCn,headers=aerFXvzkPtSBTNwjlUohROxGJDIKbp,cookies=aerFXvzkPtSBTNwjlUohROxGJDIKbp)
   aerFXvzkPtSBTNwjlUohROxGJDIKQi=json.loads(aerFXvzkPtSBTNwjlUohROxGJDIKQp.text)
   if not('celllist' in aerFXvzkPtSBTNwjlUohROxGJDIKQi['cell_toplist']):return[],aerFXvzkPtSBTNwjlUohROxGJDIKbi
   aerFXvzkPtSBTNwjlUohROxGJDIKQV=aerFXvzkPtSBTNwjlUohROxGJDIKQi['cell_toplist']['celllist']
   for aerFXvzkPtSBTNwjlUohROxGJDIKQu in aerFXvzkPtSBTNwjlUohROxGJDIKQV:
    aerFXvzkPtSBTNwjlUohROxGJDIKpC =aerFXvzkPtSBTNwjlUohROxGJDIKQu['event_list'][1]['url']
    aerFXvzkPtSBTNwjlUohROxGJDIKpQ=urllib.parse.urlsplit(aerFXvzkPtSBTNwjlUohROxGJDIKpC).query
    aerFXvzkPtSBTNwjlUohROxGJDIKpQ=aerFXvzkPtSBTNwjlUohROxGJDIKbn(urllib.parse.parse_qsl(aerFXvzkPtSBTNwjlUohROxGJDIKpQ))
    aerFXvzkPtSBTNwjlUohROxGJDIKpi='channelid'
    aerFXvzkPtSBTNwjlUohROxGJDIKpE=aerFXvzkPtSBTNwjlUohROxGJDIKpQ[aerFXvzkPtSBTNwjlUohROxGJDIKpi]
    aerFXvzkPtSBTNwjlUohROxGJDIKQY={'studio':aerFXvzkPtSBTNwjlUohROxGJDIKQu['title_list'][0]['text'],'tvshowtitle':aerFXvzkPtSBTNwjlUohROxGJDIKCp.Get_ChangeText(aerFXvzkPtSBTNwjlUohROxGJDIKQu['title_list'][1]['text']),'channelid':aerFXvzkPtSBTNwjlUohROxGJDIKpE,'age':aerFXvzkPtSBTNwjlUohROxGJDIKQu.get('age'),'thumbnail':'https://%s'%aerFXvzkPtSBTNwjlUohROxGJDIKQu.get('thumbnail')}
    aerFXvzkPtSBTNwjlUohROxGJDIKQs.append(aerFXvzkPtSBTNwjlUohROxGJDIKQY)
   aerFXvzkPtSBTNwjlUohROxGJDIKQm=aerFXvzkPtSBTNwjlUohROxGJDIKbV(aerFXvzkPtSBTNwjlUohROxGJDIKQi['cell_toplist']['pagecount'])
   if aerFXvzkPtSBTNwjlUohROxGJDIKQi['cell_toplist']['count']:aerFXvzkPtSBTNwjlUohROxGJDIKpb =aerFXvzkPtSBTNwjlUohROxGJDIKbV(aerFXvzkPtSBTNwjlUohROxGJDIKQi['cell_toplist']['count'])
   else:aerFXvzkPtSBTNwjlUohROxGJDIKpb=aerFXvzkPtSBTNwjlUohROxGJDIKCp.LIST_LIMIT*page_int
   aerFXvzkPtSBTNwjlUohROxGJDIKQq=aerFXvzkPtSBTNwjlUohROxGJDIKQm>aerFXvzkPtSBTNwjlUohROxGJDIKpb
  except aerFXvzkPtSBTNwjlUohROxGJDIKbc as exception:
   aerFXvzkPtSBTNwjlUohROxGJDIKbL(exception)
   return[],aerFXvzkPtSBTNwjlUohROxGJDIKbi
  return aerFXvzkPtSBTNwjlUohROxGJDIKQs,aerFXvzkPtSBTNwjlUohROxGJDIKQq
 def Get_Band2Section_List(aerFXvzkPtSBTNwjlUohROxGJDIKCp,aerFXvzkPtSBTNwjlUohROxGJDIKQL,page_int=1):
  aerFXvzkPtSBTNwjlUohROxGJDIKpA=[]
  aerFXvzkPtSBTNwjlUohROxGJDIKQm=aerFXvzkPtSBTNwjlUohROxGJDIKpb=1
  aerFXvzkPtSBTNwjlUohROxGJDIKQq=aerFXvzkPtSBTNwjlUohROxGJDIKbi
  try:
   (aerFXvzkPtSBTNwjlUohROxGJDIKCq,aerFXvzkPtSBTNwjlUohROxGJDIKCn)=aerFXvzkPtSBTNwjlUohROxGJDIKCp.Baseapi_Parse(aerFXvzkPtSBTNwjlUohROxGJDIKQL)
  except aerFXvzkPtSBTNwjlUohROxGJDIKbc as exception:
   aerFXvzkPtSBTNwjlUohROxGJDIKbL(exception)
   return[],aerFXvzkPtSBTNwjlUohROxGJDIKbi
  try:
   aerFXvzkPtSBTNwjlUohROxGJDIKCn['came'] ='BandView'
   aerFXvzkPtSBTNwjlUohROxGJDIKCn['limit']=aerFXvzkPtSBTNwjlUohROxGJDIKCp.LIST_LIMIT
   aerFXvzkPtSBTNwjlUohROxGJDIKCn['offset']=aerFXvzkPtSBTNwjlUohROxGJDIKbM((page_int-1)*aerFXvzkPtSBTNwjlUohROxGJDIKCp.LIST_LIMIT)
   aerFXvzkPtSBTNwjlUohROxGJDIKCn.update(aerFXvzkPtSBTNwjlUohROxGJDIKCp.GetDefaultParams(login=aerFXvzkPtSBTNwjlUohROxGJDIKbi))
   aerFXvzkPtSBTNwjlUohROxGJDIKQp=aerFXvzkPtSBTNwjlUohROxGJDIKCp.callRequestCookies('Get',aerFXvzkPtSBTNwjlUohROxGJDIKCq,payload=aerFXvzkPtSBTNwjlUohROxGJDIKbp,params=aerFXvzkPtSBTNwjlUohROxGJDIKCn,headers=aerFXvzkPtSBTNwjlUohROxGJDIKbp,cookies=aerFXvzkPtSBTNwjlUohROxGJDIKbp)
   aerFXvzkPtSBTNwjlUohROxGJDIKQi=json.loads(aerFXvzkPtSBTNwjlUohROxGJDIKQp.text)
   if not('celllist' in aerFXvzkPtSBTNwjlUohROxGJDIKQi['cell_toplist']):return[],aerFXvzkPtSBTNwjlUohROxGJDIKbi
   aerFXvzkPtSBTNwjlUohROxGJDIKQV=aerFXvzkPtSBTNwjlUohROxGJDIKQi['cell_toplist']['celllist']
   for aerFXvzkPtSBTNwjlUohROxGJDIKQu in aerFXvzkPtSBTNwjlUohROxGJDIKQV:
    aerFXvzkPtSBTNwjlUohROxGJDIKpC =aerFXvzkPtSBTNwjlUohROxGJDIKQu['event_list'][1]['url']
    aerFXvzkPtSBTNwjlUohROxGJDIKpQ=urllib.parse.urlsplit(aerFXvzkPtSBTNwjlUohROxGJDIKpC).query
    aerFXvzkPtSBTNwjlUohROxGJDIKpQ=aerFXvzkPtSBTNwjlUohROxGJDIKbn(urllib.parse.parse_qsl(aerFXvzkPtSBTNwjlUohROxGJDIKpQ))
    aerFXvzkPtSBTNwjlUohROxGJDIKpi='contentid'
    aerFXvzkPtSBTNwjlUohROxGJDIKpE=aerFXvzkPtSBTNwjlUohROxGJDIKpQ[aerFXvzkPtSBTNwjlUohROxGJDIKpi]
    aerFXvzkPtSBTNwjlUohROxGJDIKQY={'programtitle':aerFXvzkPtSBTNwjlUohROxGJDIKQu['title_list'][0]['text'],'episodetitle':aerFXvzkPtSBTNwjlUohROxGJDIKCp.Get_ChangeText(aerFXvzkPtSBTNwjlUohROxGJDIKQu['title_list'][1]['text']),'age':aerFXvzkPtSBTNwjlUohROxGJDIKQu.get('age'),'thumbnail':aerFXvzkPtSBTNwjlUohROxGJDIKCp.HTTPTAG+aerFXvzkPtSBTNwjlUohROxGJDIKQu.get('thumbnail'),'vidtype':aerFXvzkPtSBTNwjlUohROxGJDIKpi,'videoid':aerFXvzkPtSBTNwjlUohROxGJDIKpE}
    aerFXvzkPtSBTNwjlUohROxGJDIKpA.append(aerFXvzkPtSBTNwjlUohROxGJDIKQY)
   aerFXvzkPtSBTNwjlUohROxGJDIKQm=aerFXvzkPtSBTNwjlUohROxGJDIKbV(aerFXvzkPtSBTNwjlUohROxGJDIKQi['cell_toplist']['pagecount'])
   if aerFXvzkPtSBTNwjlUohROxGJDIKQi['cell_toplist']['count']:aerFXvzkPtSBTNwjlUohROxGJDIKpb =aerFXvzkPtSBTNwjlUohROxGJDIKbV(aerFXvzkPtSBTNwjlUohROxGJDIKQi['cell_toplist']['count'])
   else:aerFXvzkPtSBTNwjlUohROxGJDIKpb=aerFXvzkPtSBTNwjlUohROxGJDIKCp.LIST_LIMIT*page_int
   aerFXvzkPtSBTNwjlUohROxGJDIKQq=aerFXvzkPtSBTNwjlUohROxGJDIKQm>aerFXvzkPtSBTNwjlUohROxGJDIKpb
  except aerFXvzkPtSBTNwjlUohROxGJDIKbc as exception:
   aerFXvzkPtSBTNwjlUohROxGJDIKbL(exception)
   return[],aerFXvzkPtSBTNwjlUohROxGJDIKbi
  return aerFXvzkPtSBTNwjlUohROxGJDIKpA,aerFXvzkPtSBTNwjlUohROxGJDIKQq
 def Get_Program_List(aerFXvzkPtSBTNwjlUohROxGJDIKCp,aerFXvzkPtSBTNwjlUohROxGJDIKQL,page_int=1,orderby='-'):
  aerFXvzkPtSBTNwjlUohROxGJDIKpH=[]
  aerFXvzkPtSBTNwjlUohROxGJDIKQm=aerFXvzkPtSBTNwjlUohROxGJDIKpb=1
  aerFXvzkPtSBTNwjlUohROxGJDIKQq=aerFXvzkPtSBTNwjlUohROxGJDIKbi
  (aerFXvzkPtSBTNwjlUohROxGJDIKCq,aerFXvzkPtSBTNwjlUohROxGJDIKCn)=aerFXvzkPtSBTNwjlUohROxGJDIKCp.Baseapi_Parse(aerFXvzkPtSBTNwjlUohROxGJDIKQL)
  if aerFXvzkPtSBTNwjlUohROxGJDIKCq=='':return aerFXvzkPtSBTNwjlUohROxGJDIKpH,aerFXvzkPtSBTNwjlUohROxGJDIKQq
  try:
   aerFXvzkPtSBTNwjlUohROxGJDIKCn['limit'] =aerFXvzkPtSBTNwjlUohROxGJDIKCp.LIST_LIMIT
   aerFXvzkPtSBTNwjlUohROxGJDIKCn['offset']=aerFXvzkPtSBTNwjlUohROxGJDIKbM((page_int-1)*aerFXvzkPtSBTNwjlUohROxGJDIKCp.LIST_LIMIT)
   aerFXvzkPtSBTNwjlUohROxGJDIKCn['page'] =aerFXvzkPtSBTNwjlUohROxGJDIKbM(page_int)
   if aerFXvzkPtSBTNwjlUohROxGJDIKCn.get('orderby')!='' and aerFXvzkPtSBTNwjlUohROxGJDIKCn.get('orderby')!='regdatefirst' and orderby!='-':
    aerFXvzkPtSBTNwjlUohROxGJDIKCn['orderby']=orderby 
   aerFXvzkPtSBTNwjlUohROxGJDIKCn.update(aerFXvzkPtSBTNwjlUohROxGJDIKCp.GetDefaultParams(login=aerFXvzkPtSBTNwjlUohROxGJDIKbi))
   aerFXvzkPtSBTNwjlUohROxGJDIKQp=aerFXvzkPtSBTNwjlUohROxGJDIKCp.callRequestCookies('Get',aerFXvzkPtSBTNwjlUohROxGJDIKCq,payload=aerFXvzkPtSBTNwjlUohROxGJDIKbp,params=aerFXvzkPtSBTNwjlUohROxGJDIKCn,headers=aerFXvzkPtSBTNwjlUohROxGJDIKbp,cookies=aerFXvzkPtSBTNwjlUohROxGJDIKbp)
   aerFXvzkPtSBTNwjlUohROxGJDIKQi=json.loads(aerFXvzkPtSBTNwjlUohROxGJDIKQp.text)
   if aerFXvzkPtSBTNwjlUohROxGJDIKQL.find('instantplay')>=0:
    if not('celllist' in aerFXvzkPtSBTNwjlUohROxGJDIKQi['band']):return aerFXvzkPtSBTNwjlUohROxGJDIKpH,aerFXvzkPtSBTNwjlUohROxGJDIKQq
    aerFXvzkPtSBTNwjlUohROxGJDIKQV=aerFXvzkPtSBTNwjlUohROxGJDIKQi['band']['celllist']
   else:
    if not('celllist' in aerFXvzkPtSBTNwjlUohROxGJDIKQi['cell_toplist']):return aerFXvzkPtSBTNwjlUohROxGJDIKpH,aerFXvzkPtSBTNwjlUohROxGJDIKQq
    aerFXvzkPtSBTNwjlUohROxGJDIKQV=aerFXvzkPtSBTNwjlUohROxGJDIKQi['cell_toplist']['celllist']
   for aerFXvzkPtSBTNwjlUohROxGJDIKQu in aerFXvzkPtSBTNwjlUohROxGJDIKQV:
    for aerFXvzkPtSBTNwjlUohROxGJDIKpM in aerFXvzkPtSBTNwjlUohROxGJDIKQu['event_list']:
     if aerFXvzkPtSBTNwjlUohROxGJDIKpM.get('type')=='on-navigation':
      aerFXvzkPtSBTNwjlUohROxGJDIKpC =aerFXvzkPtSBTNwjlUohROxGJDIKpM['url']
    aerFXvzkPtSBTNwjlUohROxGJDIKpQ=urllib.parse.urlsplit(aerFXvzkPtSBTNwjlUohROxGJDIKpC).query
    aerFXvzkPtSBTNwjlUohROxGJDIKpi=aerFXvzkPtSBTNwjlUohROxGJDIKpQ[0:aerFXvzkPtSBTNwjlUohROxGJDIKpQ.find('=')]
    aerFXvzkPtSBTNwjlUohROxGJDIKpE=aerFXvzkPtSBTNwjlUohROxGJDIKpQ[aerFXvzkPtSBTNwjlUohROxGJDIKpQ.find('=')+1:]
    aerFXvzkPtSBTNwjlUohROxGJDIKQY={'title':aerFXvzkPtSBTNwjlUohROxGJDIKQu['title_list'][0]['text'],'age':aerFXvzkPtSBTNwjlUohROxGJDIKQu['age'],'thumbnail':'https://%s'%aerFXvzkPtSBTNwjlUohROxGJDIKQu.get('thumbnail'),'videoid':aerFXvzkPtSBTNwjlUohROxGJDIKpE,'vidtype':aerFXvzkPtSBTNwjlUohROxGJDIKpi}
    aerFXvzkPtSBTNwjlUohROxGJDIKpH.append(aerFXvzkPtSBTNwjlUohROxGJDIKQY)
   if aerFXvzkPtSBTNwjlUohROxGJDIKQL.find('instantplay')<0:
    aerFXvzkPtSBTNwjlUohROxGJDIKQm=aerFXvzkPtSBTNwjlUohROxGJDIKbV(aerFXvzkPtSBTNwjlUohROxGJDIKQi['cell_toplist']['pagecount'])
    if aerFXvzkPtSBTNwjlUohROxGJDIKQi['cell_toplist']['count']:aerFXvzkPtSBTNwjlUohROxGJDIKpb =aerFXvzkPtSBTNwjlUohROxGJDIKbV(aerFXvzkPtSBTNwjlUohROxGJDIKQi['cell_toplist']['count'])
    else:aerFXvzkPtSBTNwjlUohROxGJDIKpb=aerFXvzkPtSBTNwjlUohROxGJDIKCp.LIST_LIMIT*page_int
    aerFXvzkPtSBTNwjlUohROxGJDIKQq=aerFXvzkPtSBTNwjlUohROxGJDIKQm>aerFXvzkPtSBTNwjlUohROxGJDIKpb
  except aerFXvzkPtSBTNwjlUohROxGJDIKbc as exception:
   aerFXvzkPtSBTNwjlUohROxGJDIKbL(exception)
   return[],aerFXvzkPtSBTNwjlUohROxGJDIKbi
  return aerFXvzkPtSBTNwjlUohROxGJDIKpH,aerFXvzkPtSBTNwjlUohROxGJDIKQq
 def Get_Movie_List(aerFXvzkPtSBTNwjlUohROxGJDIKCp,aerFXvzkPtSBTNwjlUohROxGJDIKQL,page_int=1):
  aerFXvzkPtSBTNwjlUohROxGJDIKpc=[]
  aerFXvzkPtSBTNwjlUohROxGJDIKQm=aerFXvzkPtSBTNwjlUohROxGJDIKpb=1
  aerFXvzkPtSBTNwjlUohROxGJDIKQq=aerFXvzkPtSBTNwjlUohROxGJDIKbi
  (aerFXvzkPtSBTNwjlUohROxGJDIKCq,aerFXvzkPtSBTNwjlUohROxGJDIKCn)=aerFXvzkPtSBTNwjlUohROxGJDIKCp.Baseapi_Parse(aerFXvzkPtSBTNwjlUohROxGJDIKQL)
  if aerFXvzkPtSBTNwjlUohROxGJDIKCq=='':return aerFXvzkPtSBTNwjlUohROxGJDIKpc,aerFXvzkPtSBTNwjlUohROxGJDIKQq
  try:
   aerFXvzkPtSBTNwjlUohROxGJDIKCn['limit']=aerFXvzkPtSBTNwjlUohROxGJDIKCp.MV_LIMIT
   aerFXvzkPtSBTNwjlUohROxGJDIKCn['offset']=aerFXvzkPtSBTNwjlUohROxGJDIKbM((page_int-1)*aerFXvzkPtSBTNwjlUohROxGJDIKCp.MV_LIMIT)
   aerFXvzkPtSBTNwjlUohROxGJDIKCn.update(aerFXvzkPtSBTNwjlUohROxGJDIKCp.GetDefaultParams(login=aerFXvzkPtSBTNwjlUohROxGJDIKbi))
   aerFXvzkPtSBTNwjlUohROxGJDIKQp=aerFXvzkPtSBTNwjlUohROxGJDIKCp.callRequestCookies('Get',aerFXvzkPtSBTNwjlUohROxGJDIKCq,payload=aerFXvzkPtSBTNwjlUohROxGJDIKbp,params=aerFXvzkPtSBTNwjlUohROxGJDIKCn,headers=aerFXvzkPtSBTNwjlUohROxGJDIKbp,cookies=aerFXvzkPtSBTNwjlUohROxGJDIKbp)
   aerFXvzkPtSBTNwjlUohROxGJDIKQi=json.loads(aerFXvzkPtSBTNwjlUohROxGJDIKQp.text)
   if not('celllist' in aerFXvzkPtSBTNwjlUohROxGJDIKQi['cell_toplist']):return aerFXvzkPtSBTNwjlUohROxGJDIKpc,aerFXvzkPtSBTNwjlUohROxGJDIKQq
   aerFXvzkPtSBTNwjlUohROxGJDIKQV=aerFXvzkPtSBTNwjlUohROxGJDIKQi['cell_toplist']['celllist']
   for aerFXvzkPtSBTNwjlUohROxGJDIKQu in aerFXvzkPtSBTNwjlUohROxGJDIKQV:
    aerFXvzkPtSBTNwjlUohROxGJDIKpC =aerFXvzkPtSBTNwjlUohROxGJDIKQu['event_list'][1]['url']
    aerFXvzkPtSBTNwjlUohROxGJDIKpQ=urllib.parse.urlsplit(aerFXvzkPtSBTNwjlUohROxGJDIKpC).query
    aerFXvzkPtSBTNwjlUohROxGJDIKpi=aerFXvzkPtSBTNwjlUohROxGJDIKpQ[0:aerFXvzkPtSBTNwjlUohROxGJDIKpQ.find('=')]
    aerFXvzkPtSBTNwjlUohROxGJDIKpE=aerFXvzkPtSBTNwjlUohROxGJDIKpQ[aerFXvzkPtSBTNwjlUohROxGJDIKpQ.find('=')+1:]
    aerFXvzkPtSBTNwjlUohROxGJDIKQY={'title':aerFXvzkPtSBTNwjlUohROxGJDIKQu['title_list'][0]['text'],'age':aerFXvzkPtSBTNwjlUohROxGJDIKQu['age'],'thumbnail':'https://%s'%aerFXvzkPtSBTNwjlUohROxGJDIKQu.get('thumbnail'),'videoid':aerFXvzkPtSBTNwjlUohROxGJDIKpE,'vidtype':aerFXvzkPtSBTNwjlUohROxGJDIKpi}
    aerFXvzkPtSBTNwjlUohROxGJDIKpc.append(aerFXvzkPtSBTNwjlUohROxGJDIKQY)
   aerFXvzkPtSBTNwjlUohROxGJDIKQm=aerFXvzkPtSBTNwjlUohROxGJDIKbV(aerFXvzkPtSBTNwjlUohROxGJDIKQi['cell_toplist']['pagecount'])
   if aerFXvzkPtSBTNwjlUohROxGJDIKQi['cell_toplist']['count']:aerFXvzkPtSBTNwjlUohROxGJDIKpb =aerFXvzkPtSBTNwjlUohROxGJDIKbV(aerFXvzkPtSBTNwjlUohROxGJDIKQi['cell_toplist']['count'])
   else:aerFXvzkPtSBTNwjlUohROxGJDIKpb=aerFXvzkPtSBTNwjlUohROxGJDIKCp.MV_LIMIT*page_int
   aerFXvzkPtSBTNwjlUohROxGJDIKQq=aerFXvzkPtSBTNwjlUohROxGJDIKQm>aerFXvzkPtSBTNwjlUohROxGJDIKpb
  except aerFXvzkPtSBTNwjlUohROxGJDIKbc as exception:
   aerFXvzkPtSBTNwjlUohROxGJDIKbL(exception)
   return[],aerFXvzkPtSBTNwjlUohROxGJDIKbi
  return aerFXvzkPtSBTNwjlUohROxGJDIKpc,aerFXvzkPtSBTNwjlUohROxGJDIKQq
 def ProgramidToContentid(aerFXvzkPtSBTNwjlUohROxGJDIKCp,aerFXvzkPtSBTNwjlUohROxGJDIKpV):
  aerFXvzkPtSBTNwjlUohROxGJDIKpL=''
  try:
   aerFXvzkPtSBTNwjlUohROxGJDIKCq =aerFXvzkPtSBTNwjlUohROxGJDIKCp.API_DOMAIN+'/vod/programs-contentid/'+aerFXvzkPtSBTNwjlUohROxGJDIKpV
   aerFXvzkPtSBTNwjlUohROxGJDIKCn=aerFXvzkPtSBTNwjlUohROxGJDIKCp.GetDefaultParams(login=aerFXvzkPtSBTNwjlUohROxGJDIKbi)
   aerFXvzkPtSBTNwjlUohROxGJDIKQp=aerFXvzkPtSBTNwjlUohROxGJDIKCp.callRequestCookies('Get',aerFXvzkPtSBTNwjlUohROxGJDIKCq,payload=aerFXvzkPtSBTNwjlUohROxGJDIKbp,params=aerFXvzkPtSBTNwjlUohROxGJDIKCn,headers=aerFXvzkPtSBTNwjlUohROxGJDIKbp,cookies=aerFXvzkPtSBTNwjlUohROxGJDIKbp)
   aerFXvzkPtSBTNwjlUohROxGJDIKpn=json.loads(aerFXvzkPtSBTNwjlUohROxGJDIKQp.text)
   if not('contentid' in aerFXvzkPtSBTNwjlUohROxGJDIKpn):return aerFXvzkPtSBTNwjlUohROxGJDIKpL 
   aerFXvzkPtSBTNwjlUohROxGJDIKpL=aerFXvzkPtSBTNwjlUohROxGJDIKpn['contentid']
  except aerFXvzkPtSBTNwjlUohROxGJDIKbc as exception:
   aerFXvzkPtSBTNwjlUohROxGJDIKbL(exception)
  return aerFXvzkPtSBTNwjlUohROxGJDIKpL
 def ContentidToProgramid(aerFXvzkPtSBTNwjlUohROxGJDIKCp,aerFXvzkPtSBTNwjlUohROxGJDIKpL):
  aerFXvzkPtSBTNwjlUohROxGJDIKpV=''
  try:
   aerFXvzkPtSBTNwjlUohROxGJDIKCq =aerFXvzkPtSBTNwjlUohROxGJDIKCp.API_DOMAIN+'/cf/vod/contents/'+aerFXvzkPtSBTNwjlUohROxGJDIKpL
   aerFXvzkPtSBTNwjlUohROxGJDIKCn=aerFXvzkPtSBTNwjlUohROxGJDIKCp.GetDefaultParams(login=aerFXvzkPtSBTNwjlUohROxGJDIKbi)
   aerFXvzkPtSBTNwjlUohROxGJDIKQp=aerFXvzkPtSBTNwjlUohROxGJDIKCp.callRequestCookies('Get',aerFXvzkPtSBTNwjlUohROxGJDIKCq,payload=aerFXvzkPtSBTNwjlUohROxGJDIKbp,params=aerFXvzkPtSBTNwjlUohROxGJDIKCn,headers=aerFXvzkPtSBTNwjlUohROxGJDIKbp,cookies=aerFXvzkPtSBTNwjlUohROxGJDIKbp)
   aerFXvzkPtSBTNwjlUohROxGJDIKpn=json.loads(aerFXvzkPtSBTNwjlUohROxGJDIKQp.text)
   if not('programid' in aerFXvzkPtSBTNwjlUohROxGJDIKpn):return aerFXvzkPtSBTNwjlUohROxGJDIKpV 
   aerFXvzkPtSBTNwjlUohROxGJDIKpV=aerFXvzkPtSBTNwjlUohROxGJDIKpn['programid']
  except aerFXvzkPtSBTNwjlUohROxGJDIKbc as exception:
   aerFXvzkPtSBTNwjlUohROxGJDIKbL(exception)
  return aerFXvzkPtSBTNwjlUohROxGJDIKpV
 def GetProgramInfo(aerFXvzkPtSBTNwjlUohROxGJDIKCp,program_code):
  aerFXvzkPtSBTNwjlUohROxGJDIKpu={}
  try:
   aerFXvzkPtSBTNwjlUohROxGJDIKCq=aerFXvzkPtSBTNwjlUohROxGJDIKCp.API_DOMAIN+'/cf/vod/contents/'+program_code
   aerFXvzkPtSBTNwjlUohROxGJDIKCn=aerFXvzkPtSBTNwjlUohROxGJDIKCp.GetDefaultParams(login=aerFXvzkPtSBTNwjlUohROxGJDIKbi)
   aerFXvzkPtSBTNwjlUohROxGJDIKQp=aerFXvzkPtSBTNwjlUohROxGJDIKCp.callRequestCookies('Get',aerFXvzkPtSBTNwjlUohROxGJDIKCq,payload=aerFXvzkPtSBTNwjlUohROxGJDIKbp,params=aerFXvzkPtSBTNwjlUohROxGJDIKCn,headers=aerFXvzkPtSBTNwjlUohROxGJDIKbp,cookies=aerFXvzkPtSBTNwjlUohROxGJDIKbp)
   aerFXvzkPtSBTNwjlUohROxGJDIKpn=json.loads(aerFXvzkPtSBTNwjlUohROxGJDIKQp.text)
   aerFXvzkPtSBTNwjlUohROxGJDIKbL(aerFXvzkPtSBTNwjlUohROxGJDIKpn)
   aerFXvzkPtSBTNwjlUohROxGJDIKpY=img_fanart=aerFXvzkPtSBTNwjlUohROxGJDIKpd=''
   if aerFXvzkPtSBTNwjlUohROxGJDIKpn.get('programposterimage')!='':aerFXvzkPtSBTNwjlUohROxGJDIKpY =aerFXvzkPtSBTNwjlUohROxGJDIKCp.HTTPTAG+aerFXvzkPtSBTNwjlUohROxGJDIKpn.get('programposterimage')
   if aerFXvzkPtSBTNwjlUohROxGJDIKpn.get('programimage') !='':img_fanart =aerFXvzkPtSBTNwjlUohROxGJDIKCp.HTTPTAG+aerFXvzkPtSBTNwjlUohROxGJDIKpn.get('programimage')
   if aerFXvzkPtSBTNwjlUohROxGJDIKpn.get('programcirlceimage')!='':aerFXvzkPtSBTNwjlUohROxGJDIKpd=aerFXvzkPtSBTNwjlUohROxGJDIKCp.HTTPTAG+aerFXvzkPtSBTNwjlUohROxGJDIKpn.get('programcirlceimage')
   if 'poster_default' in aerFXvzkPtSBTNwjlUohROxGJDIKpY:
    aerFXvzkPtSBTNwjlUohROxGJDIKpY =img_fanart
    aerFXvzkPtSBTNwjlUohROxGJDIKpd=''
   aerFXvzkPtSBTNwjlUohROxGJDIKpu={'imgPoster':aerFXvzkPtSBTNwjlUohROxGJDIKpY,'imgFanart':img_fanart,'imgClearlogo':aerFXvzkPtSBTNwjlUohROxGJDIKpd}
  except aerFXvzkPtSBTNwjlUohROxGJDIKbc as exception:
   aerFXvzkPtSBTNwjlUohROxGJDIKbL(exception)
  return aerFXvzkPtSBTNwjlUohROxGJDIKpu
 def Get_Episode_List(aerFXvzkPtSBTNwjlUohROxGJDIKCp,aerFXvzkPtSBTNwjlUohROxGJDIKpE,aerFXvzkPtSBTNwjlUohROxGJDIKpi,page_int=1,orderby='desc'):
  aerFXvzkPtSBTNwjlUohROxGJDIKpf=[]
  aerFXvzkPtSBTNwjlUohROxGJDIKQm=aerFXvzkPtSBTNwjlUohROxGJDIKpb=1
  aerFXvzkPtSBTNwjlUohROxGJDIKQq=aerFXvzkPtSBTNwjlUohROxGJDIKbi
  aerFXvzkPtSBTNwjlUohROxGJDIKpg={}
  if aerFXvzkPtSBTNwjlUohROxGJDIKpi=='contentid':
   aerFXvzkPtSBTNwjlUohROxGJDIKpV=aerFXvzkPtSBTNwjlUohROxGJDIKCp.ContentidToProgramid(aerFXvzkPtSBTNwjlUohROxGJDIKpE)
   aerFXvzkPtSBTNwjlUohROxGJDIKpg=aerFXvzkPtSBTNwjlUohROxGJDIKCp.GetProgramInfo(aerFXvzkPtSBTNwjlUohROxGJDIKpE)
  else:
   aerFXvzkPtSBTNwjlUohROxGJDIKpV=aerFXvzkPtSBTNwjlUohROxGJDIKpE
   aerFXvzkPtSBTNwjlUohROxGJDIKpL=aerFXvzkPtSBTNwjlUohROxGJDIKCp.ProgramidToContentid(aerFXvzkPtSBTNwjlUohROxGJDIKpE)
   if aerFXvzkPtSBTNwjlUohROxGJDIKpL!='':aerFXvzkPtSBTNwjlUohROxGJDIKpg=aerFXvzkPtSBTNwjlUohROxGJDIKCp.GetProgramInfo(aerFXvzkPtSBTNwjlUohROxGJDIKpL)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   aerFXvzkPtSBTNwjlUohROxGJDIKCq=aerFXvzkPtSBTNwjlUohROxGJDIKCp.API_DOMAIN+'/vod/programs-contents/'+aerFXvzkPtSBTNwjlUohROxGJDIKpV
   aerFXvzkPtSBTNwjlUohROxGJDIKCn={}
   aerFXvzkPtSBTNwjlUohROxGJDIKCn['limit'] =aerFXvzkPtSBTNwjlUohROxGJDIKCp.EP_LIMIT
   aerFXvzkPtSBTNwjlUohROxGJDIKCn['offset']=aerFXvzkPtSBTNwjlUohROxGJDIKbM((page_int-1)*aerFXvzkPtSBTNwjlUohROxGJDIKCp.EP_LIMIT)
   aerFXvzkPtSBTNwjlUohROxGJDIKCn['orderby']=orderby 
   aerFXvzkPtSBTNwjlUohROxGJDIKCn.update(aerFXvzkPtSBTNwjlUohROxGJDIKCp.GetDefaultParams(login=aerFXvzkPtSBTNwjlUohROxGJDIKbi))
   aerFXvzkPtSBTNwjlUohROxGJDIKQp=aerFXvzkPtSBTNwjlUohROxGJDIKCp.callRequestCookies('Get',aerFXvzkPtSBTNwjlUohROxGJDIKCq,payload=aerFXvzkPtSBTNwjlUohROxGJDIKbp,params=aerFXvzkPtSBTNwjlUohROxGJDIKCn,headers=aerFXvzkPtSBTNwjlUohROxGJDIKbp,cookies=aerFXvzkPtSBTNwjlUohROxGJDIKbp)
   aerFXvzkPtSBTNwjlUohROxGJDIKQi=json.loads(aerFXvzkPtSBTNwjlUohROxGJDIKQp.text)
   aerFXvzkPtSBTNwjlUohROxGJDIKQV=aerFXvzkPtSBTNwjlUohROxGJDIKQi['list']
   for aerFXvzkPtSBTNwjlUohROxGJDIKQu in aerFXvzkPtSBTNwjlUohROxGJDIKQV:
    aerFXvzkPtSBTNwjlUohROxGJDIKpW=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',aerFXvzkPtSBTNwjlUohROxGJDIKQu.get('synopsis'))
    aerFXvzkPtSBTNwjlUohROxGJDIKps=aerFXvzkPtSBTNwjlUohROxGJDIKCp.HTTPTAG+aerFXvzkPtSBTNwjlUohROxGJDIKQu.get('image')
    aerFXvzkPtSBTNwjlUohROxGJDIKpm=aerFXvzkPtSBTNwjlUohROxGJDIKpq=aerFXvzkPtSBTNwjlUohROxGJDIKiC=''
    if aerFXvzkPtSBTNwjlUohROxGJDIKpg!={}:
     aerFXvzkPtSBTNwjlUohROxGJDIKpm =aerFXvzkPtSBTNwjlUohROxGJDIKpg.get('imgPoster')
     aerFXvzkPtSBTNwjlUohROxGJDIKpq =aerFXvzkPtSBTNwjlUohROxGJDIKpg.get('imgFanart')
     aerFXvzkPtSBTNwjlUohROxGJDIKiC=aerFXvzkPtSBTNwjlUohROxGJDIKpg.get('imgClearlogo')
     aerFXvzkPtSBTNwjlUohROxGJDIKiQ={'thumb':aerFXvzkPtSBTNwjlUohROxGJDIKps,'poster':aerFXvzkPtSBTNwjlUohROxGJDIKpm,'fanart':aerFXvzkPtSBTNwjlUohROxGJDIKpq,'clearlogo':aerFXvzkPtSBTNwjlUohROxGJDIKiC}
    else:
     aerFXvzkPtSBTNwjlUohROxGJDIKiQ=aerFXvzkPtSBTNwjlUohROxGJDIKps
    aerFXvzkPtSBTNwjlUohROxGJDIKQY={'programtitle':aerFXvzkPtSBTNwjlUohROxGJDIKQu.get('programtitle'),'episodetitle':aerFXvzkPtSBTNwjlUohROxGJDIKQu.get('episodetitle'),'episodenumber':aerFXvzkPtSBTNwjlUohROxGJDIKQu.get('episodenumber'),'releasedate':aerFXvzkPtSBTNwjlUohROxGJDIKQu.get('releasedate'),'releaseweekday':aerFXvzkPtSBTNwjlUohROxGJDIKQu.get('releaseweekday'),'programid':aerFXvzkPtSBTNwjlUohROxGJDIKQu.get('programid'),'contentid':aerFXvzkPtSBTNwjlUohROxGJDIKQu.get('contentid'),'age':aerFXvzkPtSBTNwjlUohROxGJDIKQu.get('targetage'),'playtime':aerFXvzkPtSBTNwjlUohROxGJDIKQu.get('playtime'),'synopsis':aerFXvzkPtSBTNwjlUohROxGJDIKpW,'episodeactors':aerFXvzkPtSBTNwjlUohROxGJDIKQu.get('episodeactors').split(',')if aerFXvzkPtSBTNwjlUohROxGJDIKQu.get('episodeactors')!='' else[],'thumbnail':aerFXvzkPtSBTNwjlUohROxGJDIKiQ}
    aerFXvzkPtSBTNwjlUohROxGJDIKpf.append(aerFXvzkPtSBTNwjlUohROxGJDIKQY)
   aerFXvzkPtSBTNwjlUohROxGJDIKQm=aerFXvzkPtSBTNwjlUohROxGJDIKbV(aerFXvzkPtSBTNwjlUohROxGJDIKQi['pagecount'])
   if aerFXvzkPtSBTNwjlUohROxGJDIKQi['count']:aerFXvzkPtSBTNwjlUohROxGJDIKpb =aerFXvzkPtSBTNwjlUohROxGJDIKbV(aerFXvzkPtSBTNwjlUohROxGJDIKQi['count'])
   else:aerFXvzkPtSBTNwjlUohROxGJDIKpb=aerFXvzkPtSBTNwjlUohROxGJDIKCp.EP_LIMIT*page_int
   aerFXvzkPtSBTNwjlUohROxGJDIKQq=aerFXvzkPtSBTNwjlUohROxGJDIKQm>aerFXvzkPtSBTNwjlUohROxGJDIKpb
  except aerFXvzkPtSBTNwjlUohROxGJDIKbc as exception:
   aerFXvzkPtSBTNwjlUohROxGJDIKbL(exception)
   return[],aerFXvzkPtSBTNwjlUohROxGJDIKbi
  return aerFXvzkPtSBTNwjlUohROxGJDIKpf,aerFXvzkPtSBTNwjlUohROxGJDIKQq
 def GetEPGList(aerFXvzkPtSBTNwjlUohROxGJDIKCp,genre):
  aerFXvzkPtSBTNwjlUohROxGJDIKip={}
  try:
   aerFXvzkPtSBTNwjlUohROxGJDIKiE=aerFXvzkPtSBTNwjlUohROxGJDIKCp.Get_Now_Datetime()
   if genre=='all':
    aerFXvzkPtSBTNwjlUohROxGJDIKib =aerFXvzkPtSBTNwjlUohROxGJDIKiE+datetime.timedelta(hours=3)
   else:
    aerFXvzkPtSBTNwjlUohROxGJDIKib =aerFXvzkPtSBTNwjlUohROxGJDIKiE+datetime.timedelta(hours=3)
   aerFXvzkPtSBTNwjlUohROxGJDIKCq=aerFXvzkPtSBTNwjlUohROxGJDIKCp.API_DOMAIN+'/live/epgs'
   aerFXvzkPtSBTNwjlUohROxGJDIKCn={'limit':'100','offset':'0','genre':genre,'startdatetime':aerFXvzkPtSBTNwjlUohROxGJDIKiE.strftime('%Y-%m-%d %H:00'),'enddatetime':aerFXvzkPtSBTNwjlUohROxGJDIKib.strftime('%Y-%m-%d %H:00')}
   aerFXvzkPtSBTNwjlUohROxGJDIKCn.update(aerFXvzkPtSBTNwjlUohROxGJDIKCp.GetDefaultParams(login=aerFXvzkPtSBTNwjlUohROxGJDIKbi))
   aerFXvzkPtSBTNwjlUohROxGJDIKQp=aerFXvzkPtSBTNwjlUohROxGJDIKCp.callRequestCookies('Get',aerFXvzkPtSBTNwjlUohROxGJDIKCq,payload=aerFXvzkPtSBTNwjlUohROxGJDIKbp,params=aerFXvzkPtSBTNwjlUohROxGJDIKCn,headers=aerFXvzkPtSBTNwjlUohROxGJDIKbp,cookies=aerFXvzkPtSBTNwjlUohROxGJDIKbp)
   aerFXvzkPtSBTNwjlUohROxGJDIKQi=json.loads(aerFXvzkPtSBTNwjlUohROxGJDIKQp.text)
   aerFXvzkPtSBTNwjlUohROxGJDIKiA=aerFXvzkPtSBTNwjlUohROxGJDIKQi['list']
   for aerFXvzkPtSBTNwjlUohROxGJDIKQu in aerFXvzkPtSBTNwjlUohROxGJDIKiA:
    aerFXvzkPtSBTNwjlUohROxGJDIKiH=''
    for aerFXvzkPtSBTNwjlUohROxGJDIKiM in aerFXvzkPtSBTNwjlUohROxGJDIKQu['list']:
     if aerFXvzkPtSBTNwjlUohROxGJDIKiH:aerFXvzkPtSBTNwjlUohROxGJDIKiH+='\n'
     aerFXvzkPtSBTNwjlUohROxGJDIKiH+=aerFXvzkPtSBTNwjlUohROxGJDIKCp.Get_ChangeText(aerFXvzkPtSBTNwjlUohROxGJDIKiM['title'])+'\n'
     aerFXvzkPtSBTNwjlUohROxGJDIKiH+=' [%s ~ %s]'%(aerFXvzkPtSBTNwjlUohROxGJDIKiM['starttime'][-5:],aerFXvzkPtSBTNwjlUohROxGJDIKiM['endtime'][-5:])+'\n'
    aerFXvzkPtSBTNwjlUohROxGJDIKip[aerFXvzkPtSBTNwjlUohROxGJDIKQu['channelid']]=aerFXvzkPtSBTNwjlUohROxGJDIKiH
  except aerFXvzkPtSBTNwjlUohROxGJDIKbc as exception:
   aerFXvzkPtSBTNwjlUohROxGJDIKbL(exception)
  return aerFXvzkPtSBTNwjlUohROxGJDIKip
 def Get_LiveChannel_List(aerFXvzkPtSBTNwjlUohROxGJDIKCp,genre,aerFXvzkPtSBTNwjlUohROxGJDIKQL):
  aerFXvzkPtSBTNwjlUohROxGJDIKQs=[]
  (aerFXvzkPtSBTNwjlUohROxGJDIKCq,aerFXvzkPtSBTNwjlUohROxGJDIKCn)=aerFXvzkPtSBTNwjlUohROxGJDIKCp.Baseapi_Parse(aerFXvzkPtSBTNwjlUohROxGJDIKQL)
  if aerFXvzkPtSBTNwjlUohROxGJDIKCq=='':return aerFXvzkPtSBTNwjlUohROxGJDIKQs
  aerFXvzkPtSBTNwjlUohROxGJDIKic=aerFXvzkPtSBTNwjlUohROxGJDIKCp.GetEPGList(genre)
  try:
   aerFXvzkPtSBTNwjlUohROxGJDIKCn.update(aerFXvzkPtSBTNwjlUohROxGJDIKCp.GetDefaultParams(login=aerFXvzkPtSBTNwjlUohROxGJDIKbi))
   aerFXvzkPtSBTNwjlUohROxGJDIKCn['genre']=genre
   aerFXvzkPtSBTNwjlUohROxGJDIKQp=aerFXvzkPtSBTNwjlUohROxGJDIKCp.callRequestCookies('Get',aerFXvzkPtSBTNwjlUohROxGJDIKCq,payload=aerFXvzkPtSBTNwjlUohROxGJDIKbp,params=aerFXvzkPtSBTNwjlUohROxGJDIKCn,headers=aerFXvzkPtSBTNwjlUohROxGJDIKbp,cookies=aerFXvzkPtSBTNwjlUohROxGJDIKbp)
   aerFXvzkPtSBTNwjlUohROxGJDIKQi=json.loads(aerFXvzkPtSBTNwjlUohROxGJDIKQp.text)
   if not('celllist' in aerFXvzkPtSBTNwjlUohROxGJDIKQi['cell_toplist']):return[]
   aerFXvzkPtSBTNwjlUohROxGJDIKQV=aerFXvzkPtSBTNwjlUohROxGJDIKQi['cell_toplist']['celllist']
   for aerFXvzkPtSBTNwjlUohROxGJDIKQu in aerFXvzkPtSBTNwjlUohROxGJDIKQV:
    aerFXvzkPtSBTNwjlUohROxGJDIKpL=aerFXvzkPtSBTNwjlUohROxGJDIKQu['contentid']
    if aerFXvzkPtSBTNwjlUohROxGJDIKpL in aerFXvzkPtSBTNwjlUohROxGJDIKic:
     aerFXvzkPtSBTNwjlUohROxGJDIKiL=aerFXvzkPtSBTNwjlUohROxGJDIKic[aerFXvzkPtSBTNwjlUohROxGJDIKpL]
    else:
     aerFXvzkPtSBTNwjlUohROxGJDIKiL=''
    aerFXvzkPtSBTNwjlUohROxGJDIKQY={'studio':aerFXvzkPtSBTNwjlUohROxGJDIKQu['title_list'][0]['text'],'tvshowtitle':aerFXvzkPtSBTNwjlUohROxGJDIKCp.Get_ChangeText(aerFXvzkPtSBTNwjlUohROxGJDIKQu['title_list'][1]['text']),'channelid':aerFXvzkPtSBTNwjlUohROxGJDIKpL,'age':aerFXvzkPtSBTNwjlUohROxGJDIKQu['age'],'thumbnail':'https://%s'%aerFXvzkPtSBTNwjlUohROxGJDIKQu.get('thumbnail'),'epg':aerFXvzkPtSBTNwjlUohROxGJDIKiL}
    aerFXvzkPtSBTNwjlUohROxGJDIKQs.append(aerFXvzkPtSBTNwjlUohROxGJDIKQY)
  except aerFXvzkPtSBTNwjlUohROxGJDIKbc as exception:
   aerFXvzkPtSBTNwjlUohROxGJDIKbL(exception)
   return[]
  return aerFXvzkPtSBTNwjlUohROxGJDIKQs
 def Get_Search_List(aerFXvzkPtSBTNwjlUohROxGJDIKCp,search_key,sType,page_int,exclusion21=aerFXvzkPtSBTNwjlUohROxGJDIKbi):
  aerFXvzkPtSBTNwjlUohROxGJDIKin=[]
  aerFXvzkPtSBTNwjlUohROxGJDIKQm=aerFXvzkPtSBTNwjlUohROxGJDIKpb=1
  aerFXvzkPtSBTNwjlUohROxGJDIKQq=aerFXvzkPtSBTNwjlUohROxGJDIKbi
  try:
   aerFXvzkPtSBTNwjlUohROxGJDIKCq=aerFXvzkPtSBTNwjlUohROxGJDIKCp.API_DOMAIN+'/cf/search/list.js'
   aerFXvzkPtSBTNwjlUohROxGJDIKCn={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':aerFXvzkPtSBTNwjlUohROxGJDIKbM((page_int-1)*aerFXvzkPtSBTNwjlUohROxGJDIKCp.SEARCH_LIMIT),'limit':aerFXvzkPtSBTNwjlUohROxGJDIKCp.SEARCH_LIMIT,'orderby':'score'}
   aerFXvzkPtSBTNwjlUohROxGJDIKCn.update(aerFXvzkPtSBTNwjlUohROxGJDIKCp.GetDefaultParams(login=aerFXvzkPtSBTNwjlUohROxGJDIKbi))
   aerFXvzkPtSBTNwjlUohROxGJDIKQp=aerFXvzkPtSBTNwjlUohROxGJDIKCp.callRequestCookies('Get',aerFXvzkPtSBTNwjlUohROxGJDIKCq,payload=aerFXvzkPtSBTNwjlUohROxGJDIKbp,params=aerFXvzkPtSBTNwjlUohROxGJDIKCn,headers=aerFXvzkPtSBTNwjlUohROxGJDIKbp,cookies=aerFXvzkPtSBTNwjlUohROxGJDIKbp)
   aerFXvzkPtSBTNwjlUohROxGJDIKpn=json.loads(aerFXvzkPtSBTNwjlUohROxGJDIKQp.text)
   if not('celllist' in aerFXvzkPtSBTNwjlUohROxGJDIKpn['cell_toplist']):return aerFXvzkPtSBTNwjlUohROxGJDIKin,aerFXvzkPtSBTNwjlUohROxGJDIKQq
   aerFXvzkPtSBTNwjlUohROxGJDIKQV=aerFXvzkPtSBTNwjlUohROxGJDIKpn['cell_toplist']['celllist']
   for aerFXvzkPtSBTNwjlUohROxGJDIKQu in aerFXvzkPtSBTNwjlUohROxGJDIKQV:
    aerFXvzkPtSBTNwjlUohROxGJDIKpC =aerFXvzkPtSBTNwjlUohROxGJDIKQu['event_list'][1]['url']
    aerFXvzkPtSBTNwjlUohROxGJDIKpQ=urllib.parse.urlsplit(aerFXvzkPtSBTNwjlUohROxGJDIKpC).query
    aerFXvzkPtSBTNwjlUohROxGJDIKpi=aerFXvzkPtSBTNwjlUohROxGJDIKpQ[0:aerFXvzkPtSBTNwjlUohROxGJDIKpQ.find('=')]
    aerFXvzkPtSBTNwjlUohROxGJDIKpE=aerFXvzkPtSBTNwjlUohROxGJDIKpQ[aerFXvzkPtSBTNwjlUohROxGJDIKpQ.find('=')+1:]
    aerFXvzkPtSBTNwjlUohROxGJDIKQY={'title':aerFXvzkPtSBTNwjlUohROxGJDIKQu['title_list'][0]['text'],'age':aerFXvzkPtSBTNwjlUohROxGJDIKQu['age'],'thumbnail':'https://%s'%aerFXvzkPtSBTNwjlUohROxGJDIKQu.get('thumbnail'),'videoid':aerFXvzkPtSBTNwjlUohROxGJDIKpE,'vidtype':aerFXvzkPtSBTNwjlUohROxGJDIKpi}
    if exclusion21==aerFXvzkPtSBTNwjlUohROxGJDIKbi or aerFXvzkPtSBTNwjlUohROxGJDIKQu.get('age')!='21':
     aerFXvzkPtSBTNwjlUohROxGJDIKin.append(aerFXvzkPtSBTNwjlUohROxGJDIKQY)
   aerFXvzkPtSBTNwjlUohROxGJDIKQm=aerFXvzkPtSBTNwjlUohROxGJDIKbV(aerFXvzkPtSBTNwjlUohROxGJDIKpn['cell_toplist']['pagecount'])
   if aerFXvzkPtSBTNwjlUohROxGJDIKpn['cell_toplist']['count']:aerFXvzkPtSBTNwjlUohROxGJDIKpb =aerFXvzkPtSBTNwjlUohROxGJDIKbV(aerFXvzkPtSBTNwjlUohROxGJDIKpn['cell_toplist']['count'])
   else:aerFXvzkPtSBTNwjlUohROxGJDIKpb=aerFXvzkPtSBTNwjlUohROxGJDIKCp.LIST_LIMIT
   aerFXvzkPtSBTNwjlUohROxGJDIKQq=aerFXvzkPtSBTNwjlUohROxGJDIKQm>aerFXvzkPtSBTNwjlUohROxGJDIKpb
  except aerFXvzkPtSBTNwjlUohROxGJDIKbc as exception:
   aerFXvzkPtSBTNwjlUohROxGJDIKbL(exception)
  return aerFXvzkPtSBTNwjlUohROxGJDIKin,aerFXvzkPtSBTNwjlUohROxGJDIKQq 
 def GetStreamingURL(aerFXvzkPtSBTNwjlUohROxGJDIKCp,mode,aerFXvzkPtSBTNwjlUohROxGJDIKpL,quality_int,pvrmode='-'):
  aerFXvzkPtSBTNwjlUohROxGJDIKiV=aerFXvzkPtSBTNwjlUohROxGJDIKis=aerFXvzkPtSBTNwjlUohROxGJDIKim=streaming_preview=''
  aerFXvzkPtSBTNwjlUohROxGJDIKiu=[]
  aerFXvzkPtSBTNwjlUohROxGJDIKiY='hls'
  if mode=='LIVE':
   aerFXvzkPtSBTNwjlUohROxGJDIKCq =aerFXvzkPtSBTNwjlUohROxGJDIKCp.API_DOMAIN+'/live/channels/'+aerFXvzkPtSBTNwjlUohROxGJDIKpL
   aerFXvzkPtSBTNwjlUohROxGJDIKid='live'
  elif mode=='VOD':
   aerFXvzkPtSBTNwjlUohROxGJDIKCq =aerFXvzkPtSBTNwjlUohROxGJDIKCp.API_DOMAIN+'/cf/vod/contents/'+aerFXvzkPtSBTNwjlUohROxGJDIKpL
   aerFXvzkPtSBTNwjlUohROxGJDIKid='vod'
  elif mode=='MOVIE':
   aerFXvzkPtSBTNwjlUohROxGJDIKCq =aerFXvzkPtSBTNwjlUohROxGJDIKCp.API_DOMAIN+'/cf/movie/contents/'+aerFXvzkPtSBTNwjlUohROxGJDIKpL
   aerFXvzkPtSBTNwjlUohROxGJDIKid='movie'
  try:
   if mode!='LIVE' or pvrmode=='-':
    aerFXvzkPtSBTNwjlUohROxGJDIKCn=aerFXvzkPtSBTNwjlUohROxGJDIKCp.GetDefaultParams(login=aerFXvzkPtSBTNwjlUohROxGJDIKbi)
    aerFXvzkPtSBTNwjlUohROxGJDIKQp=aerFXvzkPtSBTNwjlUohROxGJDIKCp.callRequestCookies('Get',aerFXvzkPtSBTNwjlUohROxGJDIKCq,payload=aerFXvzkPtSBTNwjlUohROxGJDIKbp,params=aerFXvzkPtSBTNwjlUohROxGJDIKCn,headers=aerFXvzkPtSBTNwjlUohROxGJDIKbp,cookies=aerFXvzkPtSBTNwjlUohROxGJDIKbp)
    aerFXvzkPtSBTNwjlUohROxGJDIKQi=json.loads(aerFXvzkPtSBTNwjlUohROxGJDIKQp.text)
    aerFXvzkPtSBTNwjlUohROxGJDIKif=aerFXvzkPtSBTNwjlUohROxGJDIKQi['qualities']['list']
    if aerFXvzkPtSBTNwjlUohROxGJDIKif==aerFXvzkPtSBTNwjlUohROxGJDIKbp:return(aerFXvzkPtSBTNwjlUohROxGJDIKiV,aerFXvzkPtSBTNwjlUohROxGJDIKis,aerFXvzkPtSBTNwjlUohROxGJDIKim,streaming_preview)
    for aerFXvzkPtSBTNwjlUohROxGJDIKig in aerFXvzkPtSBTNwjlUohROxGJDIKif:
     aerFXvzkPtSBTNwjlUohROxGJDIKiu.append(aerFXvzkPtSBTNwjlUohROxGJDIKbV(aerFXvzkPtSBTNwjlUohROxGJDIKig.get('id').rstrip('p')))
    if 'type' in aerFXvzkPtSBTNwjlUohROxGJDIKQi:
     if aerFXvzkPtSBTNwjlUohROxGJDIKQi['type']=='onair':
      aerFXvzkPtSBTNwjlUohROxGJDIKid='onairvod'
    if 'drms' in aerFXvzkPtSBTNwjlUohROxGJDIKQi:
     if aerFXvzkPtSBTNwjlUohROxGJDIKQi['drms']:
      aerFXvzkPtSBTNwjlUohROxGJDIKiY='dash'
  except aerFXvzkPtSBTNwjlUohROxGJDIKbc as exception:
   aerFXvzkPtSBTNwjlUohROxGJDIKbL(exception)
   return(aerFXvzkPtSBTNwjlUohROxGJDIKiV,aerFXvzkPtSBTNwjlUohROxGJDIKis,aerFXvzkPtSBTNwjlUohROxGJDIKim,streaming_preview)
  try:
   aerFXvzkPtSBTNwjlUohROxGJDIKiy=aerFXvzkPtSBTNwjlUohROxGJDIKCp.CheckQuality(quality_int,aerFXvzkPtSBTNwjlUohROxGJDIKiu)
   if mode=='LIVE' and pvrmode!='-':
    aerFXvzkPtSBTNwjlUohROxGJDIKiW='auto'
   else:
    aerFXvzkPtSBTNwjlUohROxGJDIKiW=aerFXvzkPtSBTNwjlUohROxGJDIKbM(aerFXvzkPtSBTNwjlUohROxGJDIKiy)+'p'
   aerFXvzkPtSBTNwjlUohROxGJDIKCq=aerFXvzkPtSBTNwjlUohROxGJDIKCp.API_DOMAIN+'/streaming'
   aerFXvzkPtSBTNwjlUohROxGJDIKCn={'contentid':aerFXvzkPtSBTNwjlUohROxGJDIKpL,'contenttype':aerFXvzkPtSBTNwjlUohROxGJDIKid,'action':aerFXvzkPtSBTNwjlUohROxGJDIKiY,'quality':aerFXvzkPtSBTNwjlUohROxGJDIKiW,'deviceModelId':'Windows 10','guid':aerFXvzkPtSBTNwjlUohROxGJDIKCp.GetGUID(guidType=2),'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n'}
   aerFXvzkPtSBTNwjlUohROxGJDIKCn.update(aerFXvzkPtSBTNwjlUohROxGJDIKCp.GetDefaultParams(login=aerFXvzkPtSBTNwjlUohROxGJDIKbA))
   aerFXvzkPtSBTNwjlUohROxGJDIKQp=aerFXvzkPtSBTNwjlUohROxGJDIKCp.callRequestCookies('Get',aerFXvzkPtSBTNwjlUohROxGJDIKCq,payload=aerFXvzkPtSBTNwjlUohROxGJDIKbp,params=aerFXvzkPtSBTNwjlUohROxGJDIKCn,headers=aerFXvzkPtSBTNwjlUohROxGJDIKbp,cookies=aerFXvzkPtSBTNwjlUohROxGJDIKbp)
   aerFXvzkPtSBTNwjlUohROxGJDIKQi=json.loads(aerFXvzkPtSBTNwjlUohROxGJDIKQp.text)
   aerFXvzkPtSBTNwjlUohROxGJDIKiV=aerFXvzkPtSBTNwjlUohROxGJDIKQi['playurl']
   if aerFXvzkPtSBTNwjlUohROxGJDIKiV==aerFXvzkPtSBTNwjlUohROxGJDIKbp:return(aerFXvzkPtSBTNwjlUohROxGJDIKiV,aerFXvzkPtSBTNwjlUohROxGJDIKis,aerFXvzkPtSBTNwjlUohROxGJDIKim,streaming_preview)
   aerFXvzkPtSBTNwjlUohROxGJDIKis=aerFXvzkPtSBTNwjlUohROxGJDIKQi['awscookie']
   aerFXvzkPtSBTNwjlUohROxGJDIKim =aerFXvzkPtSBTNwjlUohROxGJDIKQi['drm']
   if 'previewmsg' in aerFXvzkPtSBTNwjlUohROxGJDIKQi['preview']:streaming_preview=aerFXvzkPtSBTNwjlUohROxGJDIKQi['preview']['previewmsg']
  except aerFXvzkPtSBTNwjlUohROxGJDIKbc as exception:
   aerFXvzkPtSBTNwjlUohROxGJDIKbL(exception)
  return(aerFXvzkPtSBTNwjlUohROxGJDIKiV,aerFXvzkPtSBTNwjlUohROxGJDIKis,aerFXvzkPtSBTNwjlUohROxGJDIKim,streaming_preview) 
 def GetSportsURL(aerFXvzkPtSBTNwjlUohROxGJDIKCp,aerFXvzkPtSBTNwjlUohROxGJDIKpL,quality_int):
  aerFXvzkPtSBTNwjlUohROxGJDIKiV=aerFXvzkPtSBTNwjlUohROxGJDIKis=''
  aerFXvzkPtSBTNwjlUohROxGJDIKiu=[]
  try:
   aerFXvzkPtSBTNwjlUohROxGJDIKCq=aerFXvzkPtSBTNwjlUohROxGJDIKCp.API_DOMAIN+'/streaming/other'
   aerFXvzkPtSBTNwjlUohROxGJDIKCn={'contentid':aerFXvzkPtSBTNwjlUohROxGJDIKpL,'contenttype':'live','action':'hls','quality':aerFXvzkPtSBTNwjlUohROxGJDIKbM(quality_int)+'p','deviceModelId':'Windows 10','guid':aerFXvzkPtSBTNwjlUohROxGJDIKCp.GetGUID(guidType=2),'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n'}
   aerFXvzkPtSBTNwjlUohROxGJDIKCn.update(aerFXvzkPtSBTNwjlUohROxGJDIKCp.GetDefaultParams(login=aerFXvzkPtSBTNwjlUohROxGJDIKbA))
   aerFXvzkPtSBTNwjlUohROxGJDIKQp=aerFXvzkPtSBTNwjlUohROxGJDIKCp.callRequestCookies('Get',aerFXvzkPtSBTNwjlUohROxGJDIKCq,payload=aerFXvzkPtSBTNwjlUohROxGJDIKbp,params=aerFXvzkPtSBTNwjlUohROxGJDIKCn,headers=aerFXvzkPtSBTNwjlUohROxGJDIKbp,cookies=aerFXvzkPtSBTNwjlUohROxGJDIKbp)
   aerFXvzkPtSBTNwjlUohROxGJDIKQi=json.loads(aerFXvzkPtSBTNwjlUohROxGJDIKQp.text)
   aerFXvzkPtSBTNwjlUohROxGJDIKiV=aerFXvzkPtSBTNwjlUohROxGJDIKQi['playurl']
   if aerFXvzkPtSBTNwjlUohROxGJDIKiV==aerFXvzkPtSBTNwjlUohROxGJDIKbp:return(aerFXvzkPtSBTNwjlUohROxGJDIKiV,aerFXvzkPtSBTNwjlUohROxGJDIKis)
   aerFXvzkPtSBTNwjlUohROxGJDIKis=aerFXvzkPtSBTNwjlUohROxGJDIKQi['awscookie']
  except aerFXvzkPtSBTNwjlUohROxGJDIKbc as exception:
   aerFXvzkPtSBTNwjlUohROxGJDIKbL(exception)
  return(aerFXvzkPtSBTNwjlUohROxGJDIKiV,aerFXvzkPtSBTNwjlUohROxGJDIKis) 
 def make_viewdate(aerFXvzkPtSBTNwjlUohROxGJDIKCp):
  aerFXvzkPtSBTNwjlUohROxGJDIKiq =aerFXvzkPtSBTNwjlUohROxGJDIKCp.Get_Now_Datetime()
  aerFXvzkPtSBTNwjlUohROxGJDIKEC =aerFXvzkPtSBTNwjlUohROxGJDIKiq+datetime.timedelta(days=-1)
  aerFXvzkPtSBTNwjlUohROxGJDIKEQ =aerFXvzkPtSBTNwjlUohROxGJDIKiq+datetime.timedelta(days=1)
  aerFXvzkPtSBTNwjlUohROxGJDIKEp=[aerFXvzkPtSBTNwjlUohROxGJDIKiq.strftime('%Y%m%d'),aerFXvzkPtSBTNwjlUohROxGJDIKEQ.strftime('%Y%m%d'),]
  return aerFXvzkPtSBTNwjlUohROxGJDIKEp
 def Get_Sports_Gamelist(aerFXvzkPtSBTNwjlUohROxGJDIKCp):
  aerFXvzkPtSBTNwjlUohROxGJDIKEi =aerFXvzkPtSBTNwjlUohROxGJDIKCp.make_viewdate()
  aerFXvzkPtSBTNwjlUohROxGJDIKEb=[]
  aerFXvzkPtSBTNwjlUohROxGJDIKEA =[]
  for aerFXvzkPtSBTNwjlUohROxGJDIKEH in aerFXvzkPtSBTNwjlUohROxGJDIKEi:
   aerFXvzkPtSBTNwjlUohROxGJDIKEM=aerFXvzkPtSBTNwjlUohROxGJDIKEH[:6]
   if aerFXvzkPtSBTNwjlUohROxGJDIKEM not in aerFXvzkPtSBTNwjlUohROxGJDIKEb:
    aerFXvzkPtSBTNwjlUohROxGJDIKEb.append(aerFXvzkPtSBTNwjlUohROxGJDIKEM)
  try:
   aerFXvzkPtSBTNwjlUohROxGJDIKCq='https://annexapi.wavve.com/skb/baseball/teammonthlycalendarlist'
   aerFXvzkPtSBTNwjlUohROxGJDIKCn={'IF':'IF-PORG-002','m':'getTeamCalendarListBand','response_format':'json','spo_itm_cd':'KBO','teamcd':'all','tgroup':'B','tvalue':'BC123','ver':'2.0',}
   aerFXvzkPtSBTNwjlUohROxGJDIKCn.update(aerFXvzkPtSBTNwjlUohROxGJDIKCp.GetDefaultParams(login=aerFXvzkPtSBTNwjlUohROxGJDIKbi))
   for aerFXvzkPtSBTNwjlUohROxGJDIKEc in aerFXvzkPtSBTNwjlUohROxGJDIKEb:
    aerFXvzkPtSBTNwjlUohROxGJDIKCn['date']=aerFXvzkPtSBTNwjlUohROxGJDIKEc
    aerFXvzkPtSBTNwjlUohROxGJDIKQp=aerFXvzkPtSBTNwjlUohROxGJDIKCp.callRequestCookies('Get',aerFXvzkPtSBTNwjlUohROxGJDIKCq,payload=aerFXvzkPtSBTNwjlUohROxGJDIKbp,params=aerFXvzkPtSBTNwjlUohROxGJDIKCn,headers=aerFXvzkPtSBTNwjlUohROxGJDIKbp,cookies=aerFXvzkPtSBTNwjlUohROxGJDIKbp)
    aerFXvzkPtSBTNwjlUohROxGJDIKQi=json.loads(aerFXvzkPtSBTNwjlUohROxGJDIKQp.text)
    aerFXvzkPtSBTNwjlUohROxGJDIKQV=aerFXvzkPtSBTNwjlUohROxGJDIKQi['cell_toplist']['celllist']
    for aerFXvzkPtSBTNwjlUohROxGJDIKQu in aerFXvzkPtSBTNwjlUohROxGJDIKQV:
     aerFXvzkPtSBTNwjlUohROxGJDIKEL=aerFXvzkPtSBTNwjlUohROxGJDIKQu.get('game_date')
     aerFXvzkPtSBTNwjlUohROxGJDIKEn =aerFXvzkPtSBTNwjlUohROxGJDIKQu.get('svc_id')
     if aerFXvzkPtSBTNwjlUohROxGJDIKEn=='':continue
     if aerFXvzkPtSBTNwjlUohROxGJDIKEL in aerFXvzkPtSBTNwjlUohROxGJDIKEi:
      aerFXvzkPtSBTNwjlUohROxGJDIKEV=aerFXvzkPtSBTNwjlUohROxGJDIKQu.get('game_status') 
      aerFXvzkPtSBTNwjlUohROxGJDIKEu =aerFXvzkPtSBTNwjlUohROxGJDIKQu.get('title_list')[0].get('text')
      aerFXvzkPtSBTNwjlUohROxGJDIKEL =aerFXvzkPtSBTNwjlUohROxGJDIKEL[:4]+'-'+aerFXvzkPtSBTNwjlUohROxGJDIKEL[4:6]+'-'+aerFXvzkPtSBTNwjlUohROxGJDIKEL[-2:]
      aerFXvzkPtSBTNwjlUohROxGJDIKEY =aerFXvzkPtSBTNwjlUohROxGJDIKQu.get('game_time')
      aerFXvzkPtSBTNwjlUohROxGJDIKEY =aerFXvzkPtSBTNwjlUohROxGJDIKEY[:2]+':'+aerFXvzkPtSBTNwjlUohROxGJDIKEY[-2:]
      aerFXvzkPtSBTNwjlUohROxGJDIKQY={'game_date':aerFXvzkPtSBTNwjlUohROxGJDIKEL,'game_time':aerFXvzkPtSBTNwjlUohROxGJDIKEY,'svc_id':aerFXvzkPtSBTNwjlUohROxGJDIKEn,'away_team':aerFXvzkPtSBTNwjlUohROxGJDIKQu.get('away_team').get('team_name'),'home_team':aerFXvzkPtSBTNwjlUohROxGJDIKQu.get('home_team').get('team_name'),'game_status':aerFXvzkPtSBTNwjlUohROxGJDIKEV,'game_place':aerFXvzkPtSBTNwjlUohROxGJDIKQu.get('game_place'),}
      aerFXvzkPtSBTNwjlUohROxGJDIKEA.append(aerFXvzkPtSBTNwjlUohROxGJDIKQY)
  except aerFXvzkPtSBTNwjlUohROxGJDIKbc as exception:
   aerFXvzkPtSBTNwjlUohROxGJDIKbL(exception)
   return[]
  aerFXvzkPtSBTNwjlUohROxGJDIKEd=[]
  for i in aerFXvzkPtSBTNwjlUohROxGJDIKbH(2):
   for aerFXvzkPtSBTNwjlUohROxGJDIKQu in aerFXvzkPtSBTNwjlUohROxGJDIKEA:
    if i==0 and aerFXvzkPtSBTNwjlUohROxGJDIKQu.get('game_status')=='LIVE':
     aerFXvzkPtSBTNwjlUohROxGJDIKEd.append(aerFXvzkPtSBTNwjlUohROxGJDIKQu)
    elif i==1 and aerFXvzkPtSBTNwjlUohROxGJDIKQu.get('game_status')!='LIVE':
     aerFXvzkPtSBTNwjlUohROxGJDIKEd.append(aerFXvzkPtSBTNwjlUohROxGJDIKQu)
  return aerFXvzkPtSBTNwjlUohROxGJDIKEd
 def GetBookmarkInfo(aerFXvzkPtSBTNwjlUohROxGJDIKCp,aerFXvzkPtSBTNwjlUohROxGJDIKpE,aerFXvzkPtSBTNwjlUohROxGJDIKpi,aerFXvzkPtSBTNwjlUohROxGJDIKid):
  if aerFXvzkPtSBTNwjlUohROxGJDIKpi=='tvshow':
   if aerFXvzkPtSBTNwjlUohROxGJDIKid=='contentid':
    aerFXvzkPtSBTNwjlUohROxGJDIKpL=aerFXvzkPtSBTNwjlUohROxGJDIKpE
    aerFXvzkPtSBTNwjlUohROxGJDIKpE =aerFXvzkPtSBTNwjlUohROxGJDIKCp.ContentidToProgramid(aerFXvzkPtSBTNwjlUohROxGJDIKpL)
   else:
    aerFXvzkPtSBTNwjlUohROxGJDIKpL=aerFXvzkPtSBTNwjlUohROxGJDIKCp.ProgramidToContentid(aerFXvzkPtSBTNwjlUohROxGJDIKpE)
  else:
   aerFXvzkPtSBTNwjlUohROxGJDIKpL=''
  aerFXvzkPtSBTNwjlUohROxGJDIKEf={'indexinfo':{'ott':'wavve','videoid':aerFXvzkPtSBTNwjlUohROxGJDIKpE,'vidtype':aerFXvzkPtSBTNwjlUohROxGJDIKpi,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':aerFXvzkPtSBTNwjlUohROxGJDIKpi,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if aerFXvzkPtSBTNwjlUohROxGJDIKpi=='tvshow':
   aerFXvzkPtSBTNwjlUohROxGJDIKCq=aerFXvzkPtSBTNwjlUohROxGJDIKCp.API_DOMAIN+'/cf/vod/contents/'+aerFXvzkPtSBTNwjlUohROxGJDIKpL 
   aerFXvzkPtSBTNwjlUohROxGJDIKCn=aerFXvzkPtSBTNwjlUohROxGJDIKCp.GetDefaultParams(login=aerFXvzkPtSBTNwjlUohROxGJDIKbi)
   aerFXvzkPtSBTNwjlUohROxGJDIKQp=aerFXvzkPtSBTNwjlUohROxGJDIKCp.callRequestCookies('Get',aerFXvzkPtSBTNwjlUohROxGJDIKCq,payload=aerFXvzkPtSBTNwjlUohROxGJDIKbp,params=aerFXvzkPtSBTNwjlUohROxGJDIKCn,headers=aerFXvzkPtSBTNwjlUohROxGJDIKbp,cookies=aerFXvzkPtSBTNwjlUohROxGJDIKbp)
   aerFXvzkPtSBTNwjlUohROxGJDIKQi=json.loads(aerFXvzkPtSBTNwjlUohROxGJDIKQp.text)
   if not('programtitle' in aerFXvzkPtSBTNwjlUohROxGJDIKQi):return{}
   aerFXvzkPtSBTNwjlUohROxGJDIKEg=aerFXvzkPtSBTNwjlUohROxGJDIKQi
   aerFXvzkPtSBTNwjlUohROxGJDIKEy=aerFXvzkPtSBTNwjlUohROxGJDIKEg.get('programtitle')
   aerFXvzkPtSBTNwjlUohROxGJDIKEf['saveinfo']['infoLabels']['title']=aerFXvzkPtSBTNwjlUohROxGJDIKEy
   if aerFXvzkPtSBTNwjlUohROxGJDIKEg.get('targetage')=='18' or aerFXvzkPtSBTNwjlUohROxGJDIKEg.get('targetage')=='19' or aerFXvzkPtSBTNwjlUohROxGJDIKEg.get('targetage')=='21':
    aerFXvzkPtSBTNwjlUohROxGJDIKEy +=u' (%s)'%(aerFXvzkPtSBTNwjlUohROxGJDIKEg.get('targetage'))
   aerFXvzkPtSBTNwjlUohROxGJDIKEf['saveinfo']['title'] =aerFXvzkPtSBTNwjlUohROxGJDIKEy
   aerFXvzkPtSBTNwjlUohROxGJDIKEf['saveinfo']['infoLabels']['mpaa'] =aerFXvzkPtSBTNwjlUohROxGJDIKEg.get('targetage')
   aerFXvzkPtSBTNwjlUohROxGJDIKEf['saveinfo']['infoLabels']['plot'] =aerFXvzkPtSBTNwjlUohROxGJDIKEg.get('programsynopsis').replace('<br>','\n')
   aerFXvzkPtSBTNwjlUohROxGJDIKEf['saveinfo']['infoLabels']['studio'] =aerFXvzkPtSBTNwjlUohROxGJDIKEg.get('channelname')
   if aerFXvzkPtSBTNwjlUohROxGJDIKEg.get('firstreleaseyear')!='':aerFXvzkPtSBTNwjlUohROxGJDIKEf['saveinfo']['infoLabels']['year'] =aerFXvzkPtSBTNwjlUohROxGJDIKEg.get('firstreleaseyear')
   if aerFXvzkPtSBTNwjlUohROxGJDIKEg.get('firstreleasedate')!='':aerFXvzkPtSBTNwjlUohROxGJDIKEf['saveinfo']['infoLabels']['premiered']=aerFXvzkPtSBTNwjlUohROxGJDIKEg.get('firstreleasedate')
   if aerFXvzkPtSBTNwjlUohROxGJDIKEg.get('genretext') !='':aerFXvzkPtSBTNwjlUohROxGJDIKEf['saveinfo']['infoLabels']['genre'] =[aerFXvzkPtSBTNwjlUohROxGJDIKEg.get('genretext')]
   aerFXvzkPtSBTNwjlUohROxGJDIKEW=[]
   for aerFXvzkPtSBTNwjlUohROxGJDIKEs in aerFXvzkPtSBTNwjlUohROxGJDIKEg['actors']['list']:aerFXvzkPtSBTNwjlUohROxGJDIKEW.append(aerFXvzkPtSBTNwjlUohROxGJDIKEs.get('text'))
   if aerFXvzkPtSBTNwjlUohROxGJDIKbu(aerFXvzkPtSBTNwjlUohROxGJDIKEW)>0:
    if aerFXvzkPtSBTNwjlUohROxGJDIKEW[0]!='':aerFXvzkPtSBTNwjlUohROxGJDIKEf['saveinfo']['infoLabels']['cast']=aerFXvzkPtSBTNwjlUohROxGJDIKEW
   aerFXvzkPtSBTNwjlUohROxGJDIKpm =''
   aerFXvzkPtSBTNwjlUohROxGJDIKpq =''
   aerFXvzkPtSBTNwjlUohROxGJDIKiC=''
   if aerFXvzkPtSBTNwjlUohROxGJDIKEg.get('programposterimage')!='':aerFXvzkPtSBTNwjlUohROxGJDIKpm =aerFXvzkPtSBTNwjlUohROxGJDIKCp.HTTPTAG+aerFXvzkPtSBTNwjlUohROxGJDIKEg.get('programposterimage')
   if aerFXvzkPtSBTNwjlUohROxGJDIKEg.get('programimage') !='':aerFXvzkPtSBTNwjlUohROxGJDIKpq =aerFXvzkPtSBTNwjlUohROxGJDIKCp.HTTPTAG+aerFXvzkPtSBTNwjlUohROxGJDIKEg.get('programimage')
   if aerFXvzkPtSBTNwjlUohROxGJDIKEg.get('programcirlceimage')!='':aerFXvzkPtSBTNwjlUohROxGJDIKiC=aerFXvzkPtSBTNwjlUohROxGJDIKCp.HTTPTAG+aerFXvzkPtSBTNwjlUohROxGJDIKEg.get('programcirlceimage')
   if 'poster_default' in aerFXvzkPtSBTNwjlUohROxGJDIKpm:
    aerFXvzkPtSBTNwjlUohROxGJDIKpm =aerFXvzkPtSBTNwjlUohROxGJDIKpq
    aerFXvzkPtSBTNwjlUohROxGJDIKiC=''
   aerFXvzkPtSBTNwjlUohROxGJDIKEf['saveinfo']['thumbnail']['poster']=aerFXvzkPtSBTNwjlUohROxGJDIKpm
   aerFXvzkPtSBTNwjlUohROxGJDIKEf['saveinfo']['thumbnail']['thumb']=aerFXvzkPtSBTNwjlUohROxGJDIKpq
   aerFXvzkPtSBTNwjlUohROxGJDIKEf['saveinfo']['thumbnail']['clearlogo']=aerFXvzkPtSBTNwjlUohROxGJDIKiC
   aerFXvzkPtSBTNwjlUohROxGJDIKEf['saveinfo']['thumbnail']['fanart']=aerFXvzkPtSBTNwjlUohROxGJDIKpq
  else:
   aerFXvzkPtSBTNwjlUohROxGJDIKCq=aerFXvzkPtSBTNwjlUohROxGJDIKCp.API_DOMAIN+'/movie/contents/'+aerFXvzkPtSBTNwjlUohROxGJDIKpE 
   aerFXvzkPtSBTNwjlUohROxGJDIKCn=aerFXvzkPtSBTNwjlUohROxGJDIKCp.GetDefaultParams(login=aerFXvzkPtSBTNwjlUohROxGJDIKbi)
   aerFXvzkPtSBTNwjlUohROxGJDIKQp=aerFXvzkPtSBTNwjlUohROxGJDIKCp.callRequestCookies('Get',aerFXvzkPtSBTNwjlUohROxGJDIKCq,payload=aerFXvzkPtSBTNwjlUohROxGJDIKbp,params=aerFXvzkPtSBTNwjlUohROxGJDIKCn,headers=aerFXvzkPtSBTNwjlUohROxGJDIKbp,cookies=aerFXvzkPtSBTNwjlUohROxGJDIKbp)
   aerFXvzkPtSBTNwjlUohROxGJDIKQi=json.loads(aerFXvzkPtSBTNwjlUohROxGJDIKQp.text)
   if not('title' in aerFXvzkPtSBTNwjlUohROxGJDIKQi):return{}
   aerFXvzkPtSBTNwjlUohROxGJDIKEg=aerFXvzkPtSBTNwjlUohROxGJDIKQi
   aerFXvzkPtSBTNwjlUohROxGJDIKEy=aerFXvzkPtSBTNwjlUohROxGJDIKEg.get('title')
   aerFXvzkPtSBTNwjlUohROxGJDIKEf['saveinfo']['infoLabels']['title']=aerFXvzkPtSBTNwjlUohROxGJDIKEy
   if aerFXvzkPtSBTNwjlUohROxGJDIKEg.get('targetage')=='18' or aerFXvzkPtSBTNwjlUohROxGJDIKEg.get('targetage')=='19' or aerFXvzkPtSBTNwjlUohROxGJDIKEg.get('targetage')=='21':
    aerFXvzkPtSBTNwjlUohROxGJDIKEy +=u' (%s)'%(aerFXvzkPtSBTNwjlUohROxGJDIKEg.get('targetage'))
   aerFXvzkPtSBTNwjlUohROxGJDIKEf['saveinfo']['title'] =aerFXvzkPtSBTNwjlUohROxGJDIKEy
   aerFXvzkPtSBTNwjlUohROxGJDIKEf['saveinfo']['infoLabels']['mpaa'] =aerFXvzkPtSBTNwjlUohROxGJDIKEg.get('targetage')
   aerFXvzkPtSBTNwjlUohROxGJDIKEf['saveinfo']['infoLabels']['plot'] =aerFXvzkPtSBTNwjlUohROxGJDIKEg.get('synopsis').replace('<br>','\n')
   aerFXvzkPtSBTNwjlUohROxGJDIKEf['saveinfo']['infoLabels']['duration']=aerFXvzkPtSBTNwjlUohROxGJDIKEg.get('playtime')
   aerFXvzkPtSBTNwjlUohROxGJDIKEf['saveinfo']['infoLabels']['country']=aerFXvzkPtSBTNwjlUohROxGJDIKEg.get('country')
   aerFXvzkPtSBTNwjlUohROxGJDIKEf['saveinfo']['infoLabels']['studio'] =aerFXvzkPtSBTNwjlUohROxGJDIKEg.get('cpname')
   if aerFXvzkPtSBTNwjlUohROxGJDIKEg.get('releasedate')!='':
    aerFXvzkPtSBTNwjlUohROxGJDIKEf['saveinfo']['infoLabels']['year'] =aerFXvzkPtSBTNwjlUohROxGJDIKEg.get('releasedate')[:4]
    aerFXvzkPtSBTNwjlUohROxGJDIKEf['saveinfo']['infoLabels']['premiered']=aerFXvzkPtSBTNwjlUohROxGJDIKEg.get('releasedate')
   aerFXvzkPtSBTNwjlUohROxGJDIKEW=[]
   for aerFXvzkPtSBTNwjlUohROxGJDIKEs in aerFXvzkPtSBTNwjlUohROxGJDIKEg['actors']['list']:aerFXvzkPtSBTNwjlUohROxGJDIKEW.append(aerFXvzkPtSBTNwjlUohROxGJDIKEs.get('text'))
   if aerFXvzkPtSBTNwjlUohROxGJDIKbu(aerFXvzkPtSBTNwjlUohROxGJDIKEW)>0:
    if aerFXvzkPtSBTNwjlUohROxGJDIKEW[0]!='':aerFXvzkPtSBTNwjlUohROxGJDIKEf['saveinfo']['infoLabels']['cast']=aerFXvzkPtSBTNwjlUohROxGJDIKEW
   aerFXvzkPtSBTNwjlUohROxGJDIKEm=[]
   for aerFXvzkPtSBTNwjlUohROxGJDIKEq in aerFXvzkPtSBTNwjlUohROxGJDIKEg['directors']['list']:aerFXvzkPtSBTNwjlUohROxGJDIKEm.append(aerFXvzkPtSBTNwjlUohROxGJDIKEq.get('text'))
   if aerFXvzkPtSBTNwjlUohROxGJDIKbu(aerFXvzkPtSBTNwjlUohROxGJDIKEm)>0:
    if aerFXvzkPtSBTNwjlUohROxGJDIKEm[0]!='':aerFXvzkPtSBTNwjlUohROxGJDIKEf['saveinfo']['infoLabels']['director']=aerFXvzkPtSBTNwjlUohROxGJDIKEm
   aerFXvzkPtSBTNwjlUohROxGJDIKQc=[]
   for aerFXvzkPtSBTNwjlUohROxGJDIKbC in aerFXvzkPtSBTNwjlUohROxGJDIKEg['genre']['list']:aerFXvzkPtSBTNwjlUohROxGJDIKQc.append(aerFXvzkPtSBTNwjlUohROxGJDIKbC.get('text'))
   if aerFXvzkPtSBTNwjlUohROxGJDIKbu(aerFXvzkPtSBTNwjlUohROxGJDIKQc)>0:
    if aerFXvzkPtSBTNwjlUohROxGJDIKQc[0]!='':aerFXvzkPtSBTNwjlUohROxGJDIKEf['saveinfo']['infoLabels']['genre']=aerFXvzkPtSBTNwjlUohROxGJDIKQc
   aerFXvzkPtSBTNwjlUohROxGJDIKpm ='https://%s'%aerFXvzkPtSBTNwjlUohROxGJDIKEg['image']
   aerFXvzkPtSBTNwjlUohROxGJDIKEf['saveinfo']['thumbnail']['poster'] =aerFXvzkPtSBTNwjlUohROxGJDIKpm
   aerFXvzkPtSBTNwjlUohROxGJDIKEf['saveinfo']['thumbnail']['thumb'] =aerFXvzkPtSBTNwjlUohROxGJDIKpm
  return aerFXvzkPtSBTNwjlUohROxGJDIKEf
# Created by pyminifier (https://github.com/liftoff/pyminifier)
