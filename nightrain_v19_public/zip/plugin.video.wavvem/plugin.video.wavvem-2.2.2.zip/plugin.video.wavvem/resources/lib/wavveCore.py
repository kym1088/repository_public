__author__="NightRain"
RrVNCwXYgTehLcKHkMBqFnSmfpGjPE=object
RrVNCwXYgTehLcKHkMBqFnSmfpGjPO=None
RrVNCwXYgTehLcKHkMBqFnSmfpGjPl=False
RrVNCwXYgTehLcKHkMBqFnSmfpGjPz=True
RrVNCwXYgTehLcKHkMBqFnSmfpGjWy=range
RrVNCwXYgTehLcKHkMBqFnSmfpGjWi=str
RrVNCwXYgTehLcKHkMBqFnSmfpGjWI=Exception
RrVNCwXYgTehLcKHkMBqFnSmfpGjWd=print
RrVNCwXYgTehLcKHkMBqFnSmfpGjWP=dict
RrVNCwXYgTehLcKHkMBqFnSmfpGjWv=int
RrVNCwXYgTehLcKHkMBqFnSmfpGjWt=len
import urllib
import re
import json
import sys
import requests
import datetime
class RrVNCwXYgTehLcKHkMBqFnSmfpGjyi(RrVNCwXYgTehLcKHkMBqFnSmfpGjPE):
 def __init__(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI):
  RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.API_DOMAIN='https://apis.wavve.com'
  RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.CREDENTIAL='none'
  RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.DEVICE ='pc'
  RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.DRM ='wm'
  RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.PARTNER ='pooq'
  RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.POOQZONE ='none'
  RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.REGION ='kor'
  RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.TARGETAGE ='all'
  RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.HTTPTAG ='https://'
  RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.LIST_LIMIT=30 
  RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.EP_LIMIT =30 
  RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.MV_LIMIT =24 
  RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.SEARCH_LIMIT=20 
  RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.guid ='none' 
  RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.guidtimestamp='none' 
  RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.DEFAULT_HEADER={'user-agent':RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.USER_AGENT}
 def callRequestCookies(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI,jobtype,RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,payload=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,params=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,headers=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,cookies=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,redirects=RrVNCwXYgTehLcKHkMBqFnSmfpGjPl):
  RrVNCwXYgTehLcKHkMBqFnSmfpGjyd=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.DEFAULT_HEADER
  if headers:RrVNCwXYgTehLcKHkMBqFnSmfpGjyd.update(headers)
  if jobtype=='Get':
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyP=requests.get(RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,params=params,headers=RrVNCwXYgTehLcKHkMBqFnSmfpGjyd,cookies=cookies,allow_redirects=redirects)
  else:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyP=requests.post(RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,data=payload,params=params,headers=RrVNCwXYgTehLcKHkMBqFnSmfpGjyd,cookies=cookies,allow_redirects=redirects)
  return RrVNCwXYgTehLcKHkMBqFnSmfpGjyP
 def SaveCredential(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI,RrVNCwXYgTehLcKHkMBqFnSmfpGjyW):
  RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.CREDENTIAL=RrVNCwXYgTehLcKHkMBqFnSmfpGjyW
 def LoadCredential(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI):
  return RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.CREDENTIAL
 def GetDefaultParams(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI,login=RrVNCwXYgTehLcKHkMBqFnSmfpGjPz):
  RrVNCwXYgTehLcKHkMBqFnSmfpGjyv={'apikey':RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.APIKEY,'credential':RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.CREDENTIAL if login else 'none','device':RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.DEVICE,'drm':RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.DRM,'partner':RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.PARTNER,'pooqzone':RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.POOQZONE,'region':RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.REGION,'targetage':RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.TARGETAGE}
  return RrVNCwXYgTehLcKHkMBqFnSmfpGjyv
 def GetGUID(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyt=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyu=GenerateRandomString(5)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyo=RrVNCwXYgTehLcKHkMBqFnSmfpGjyu+media+RrVNCwXYgTehLcKHkMBqFnSmfpGjyt
   return RrVNCwXYgTehLcKHkMBqFnSmfpGjyo
  def GenerateRandomString(num):
   from random import randint
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyx=""
   for i in RrVNCwXYgTehLcKHkMBqFnSmfpGjWy(0,num):
    s=RrVNCwXYgTehLcKHkMBqFnSmfpGjWi(randint(1,5))
    RrVNCwXYgTehLcKHkMBqFnSmfpGjyx+=s
   return RrVNCwXYgTehLcKHkMBqFnSmfpGjyx
  RrVNCwXYgTehLcKHkMBqFnSmfpGjyo=GenerateID(guid_str)
  RrVNCwXYgTehLcKHkMBqFnSmfpGjya=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.GetHash(RrVNCwXYgTehLcKHkMBqFnSmfpGjyo)
  if guidType==2:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjya='%s-%s-%s-%s-%s'%(RrVNCwXYgTehLcKHkMBqFnSmfpGjya[:8],RrVNCwXYgTehLcKHkMBqFnSmfpGjya[8:12],RrVNCwXYgTehLcKHkMBqFnSmfpGjya[12:16],RrVNCwXYgTehLcKHkMBqFnSmfpGjya[16:20],RrVNCwXYgTehLcKHkMBqFnSmfpGjya[20:])
  return RrVNCwXYgTehLcKHkMBqFnSmfpGjya
 def GetHash(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return RrVNCwXYgTehLcKHkMBqFnSmfpGjWi(m.hexdigest())
 def CheckQuality(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI,sel_qt,qt_list):
  RrVNCwXYgTehLcKHkMBqFnSmfpGjys=0
  for RrVNCwXYgTehLcKHkMBqFnSmfpGjyJ in qt_list:
   if sel_qt>=RrVNCwXYgTehLcKHkMBqFnSmfpGjyJ:return RrVNCwXYgTehLcKHkMBqFnSmfpGjyJ
   RrVNCwXYgTehLcKHkMBqFnSmfpGjys=RrVNCwXYgTehLcKHkMBqFnSmfpGjyJ
  return RrVNCwXYgTehLcKHkMBqFnSmfpGjys
 def Get_Now_Datetime(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI,in_text):
  RrVNCwXYgTehLcKHkMBqFnSmfpGjyA=in_text.replace('&lt;','<').replace('&gt;','>')
  RrVNCwXYgTehLcKHkMBqFnSmfpGjyA=RrVNCwXYgTehLcKHkMBqFnSmfpGjyA.replace('$O$','')
  RrVNCwXYgTehLcKHkMBqFnSmfpGjyA=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',RrVNCwXYgTehLcKHkMBqFnSmfpGjyA)
  RrVNCwXYgTehLcKHkMBqFnSmfpGjyA=RrVNCwXYgTehLcKHkMBqFnSmfpGjyA.lstrip('#')
  return RrVNCwXYgTehLcKHkMBqFnSmfpGjyA
 def GetCredential(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI,user_id,user_pw,user_pf):
  RrVNCwXYgTehLcKHkMBqFnSmfpGjyQ=RrVNCwXYgTehLcKHkMBqFnSmfpGjPl
  try:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyD=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.API_DOMAIN+ '/login'
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.GetDefaultParams()
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyb={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyE=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.callRequestCookies('Post',RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,payload=RrVNCwXYgTehLcKHkMBqFnSmfpGjyb,params=RrVNCwXYgTehLcKHkMBqFnSmfpGjyv,headers=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,cookies=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyO=json.loads(RrVNCwXYgTehLcKHkMBqFnSmfpGjyE.text)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyW=RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['credential']
   if user_pf!=0:
    RrVNCwXYgTehLcKHkMBqFnSmfpGjyb={'id':RrVNCwXYgTehLcKHkMBqFnSmfpGjyW,'password':'','profile':RrVNCwXYgTehLcKHkMBqFnSmfpGjWi(user_pf),'pushid':'','type':'credential'}
    RrVNCwXYgTehLcKHkMBqFnSmfpGjyv['credential']=RrVNCwXYgTehLcKHkMBqFnSmfpGjyW 
    RrVNCwXYgTehLcKHkMBqFnSmfpGjyE=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.callRequestCookies('Post',RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,payload=RrVNCwXYgTehLcKHkMBqFnSmfpGjyb,params=RrVNCwXYgTehLcKHkMBqFnSmfpGjyv,headers=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,cookies=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO)
    RrVNCwXYgTehLcKHkMBqFnSmfpGjyO=json.loads(RrVNCwXYgTehLcKHkMBqFnSmfpGjyE.text)
    RrVNCwXYgTehLcKHkMBqFnSmfpGjyW=RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['credential']
   if RrVNCwXYgTehLcKHkMBqFnSmfpGjyW:RrVNCwXYgTehLcKHkMBqFnSmfpGjyQ=RrVNCwXYgTehLcKHkMBqFnSmfpGjPz
  except RrVNCwXYgTehLcKHkMBqFnSmfpGjWI as exception:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjWd(exception)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyW='none' 
  RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.SaveCredential(RrVNCwXYgTehLcKHkMBqFnSmfpGjyW)
  return RrVNCwXYgTehLcKHkMBqFnSmfpGjyQ
 def GetIssue(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI):
  RrVNCwXYgTehLcKHkMBqFnSmfpGjyl=RrVNCwXYgTehLcKHkMBqFnSmfpGjPl
  try:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyD=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.API_DOMAIN+'/guid/issue'
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.GetDefaultParams()
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyE=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.callRequestCookies('Get',RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,payload=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,params=RrVNCwXYgTehLcKHkMBqFnSmfpGjyv,headers=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,cookies=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyO=json.loads(RrVNCwXYgTehLcKHkMBqFnSmfpGjyE.text)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyz=RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['guid']
   RrVNCwXYgTehLcKHkMBqFnSmfpGjiy=RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['guidtimestamp']
   if RrVNCwXYgTehLcKHkMBqFnSmfpGjyz:RrVNCwXYgTehLcKHkMBqFnSmfpGjyl=RrVNCwXYgTehLcKHkMBqFnSmfpGjPz
  except RrVNCwXYgTehLcKHkMBqFnSmfpGjWI as exception:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjWd(exception)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyz='none'
   RrVNCwXYgTehLcKHkMBqFnSmfpGjiy='none' 
  RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.guid=RrVNCwXYgTehLcKHkMBqFnSmfpGjyz
  RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.guidtimestamp=RrVNCwXYgTehLcKHkMBqFnSmfpGjiy
  return RrVNCwXYgTehLcKHkMBqFnSmfpGjyl
 def Baseapi_Parse(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI,RrVNCwXYgTehLcKHkMBqFnSmfpGjiW):
  try:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjiI =urllib.parse.urlsplit(RrVNCwXYgTehLcKHkMBqFnSmfpGjiW)
   if RrVNCwXYgTehLcKHkMBqFnSmfpGjiI.netloc=='':
    RrVNCwXYgTehLcKHkMBqFnSmfpGjyD=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.HTTPTAG+RrVNCwXYgTehLcKHkMBqFnSmfpGjiI.netloc+RrVNCwXYgTehLcKHkMBqFnSmfpGjiI.path
   else:
    RrVNCwXYgTehLcKHkMBqFnSmfpGjyD=RrVNCwXYgTehLcKHkMBqFnSmfpGjiI.scheme+'://'+RrVNCwXYgTehLcKHkMBqFnSmfpGjiI.netloc+RrVNCwXYgTehLcKHkMBqFnSmfpGjiI.path
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv=RrVNCwXYgTehLcKHkMBqFnSmfpGjWP(urllib.parse.parse_qsl(RrVNCwXYgTehLcKHkMBqFnSmfpGjiI.query))
  except:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjWd(exception)
   return '',{}
  return RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,RrVNCwXYgTehLcKHkMBqFnSmfpGjyv
 def GetSupermultiUrl(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI,sCode,sIndex='0'):
  try:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyD=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.API_DOMAIN+'/cf/supermultisections/'+sCode
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.GetDefaultParams(login=RrVNCwXYgTehLcKHkMBqFnSmfpGjPl)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyE=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.callRequestCookies('Get',RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,payload=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,params=RrVNCwXYgTehLcKHkMBqFnSmfpGjyv,headers=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,cookies=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyO=json.loads(RrVNCwXYgTehLcKHkMBqFnSmfpGjyE.text)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjid=RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['multisectionlist'][RrVNCwXYgTehLcKHkMBqFnSmfpGjWv(sIndex)]['eventlist'][1]['url']
  except RrVNCwXYgTehLcKHkMBqFnSmfpGjWI as exception:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjWd(exception)
   return ''
  return RrVNCwXYgTehLcKHkMBqFnSmfpGjid
 def Get_LiveCatagory_List(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI,sCode,sIndex='0'):
  RrVNCwXYgTehLcKHkMBqFnSmfpGjiP=[]
  RrVNCwXYgTehLcKHkMBqFnSmfpGjiW =RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.GetSupermultiUrl(sCode,sIndex)
  (RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,RrVNCwXYgTehLcKHkMBqFnSmfpGjyv)=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.Baseapi_Parse(RrVNCwXYgTehLcKHkMBqFnSmfpGjiW)
  if RrVNCwXYgTehLcKHkMBqFnSmfpGjyD=='':return RrVNCwXYgTehLcKHkMBqFnSmfpGjiP,''
  try:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv.update(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.GetDefaultParams(login=RrVNCwXYgTehLcKHkMBqFnSmfpGjPl))
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyE=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.callRequestCookies('Get',RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,payload=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,params=RrVNCwXYgTehLcKHkMBqFnSmfpGjyv,headers=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,cookies=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyO=json.loads(RrVNCwXYgTehLcKHkMBqFnSmfpGjyE.text)
   if not('filter_item_list' in RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['filter']['filterlist'][0]):return[],''
   RrVNCwXYgTehLcKHkMBqFnSmfpGjit=RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['filter']['filterlist'][0]['filter_item_list']
   for RrVNCwXYgTehLcKHkMBqFnSmfpGjiu in RrVNCwXYgTehLcKHkMBqFnSmfpGjit:
    RrVNCwXYgTehLcKHkMBqFnSmfpGjio={'title':RrVNCwXYgTehLcKHkMBqFnSmfpGjiu['title'],'genre':RrVNCwXYgTehLcKHkMBqFnSmfpGjiu['api_parameters'][RrVNCwXYgTehLcKHkMBqFnSmfpGjiu['api_parameters'].index('=')+1:]}
    RrVNCwXYgTehLcKHkMBqFnSmfpGjiP.append(RrVNCwXYgTehLcKHkMBqFnSmfpGjio)
  except RrVNCwXYgTehLcKHkMBqFnSmfpGjWI as exception:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjWd(exception)
   return[],''
  return RrVNCwXYgTehLcKHkMBqFnSmfpGjiP,RrVNCwXYgTehLcKHkMBqFnSmfpGjiW
 def Get_MainCatagory_List(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI,sCode,sIndex='0'):
  RrVNCwXYgTehLcKHkMBqFnSmfpGjiP=[]
  RrVNCwXYgTehLcKHkMBqFnSmfpGjiW =RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.GetSupermultiUrl(sCode,sIndex)
  (RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,RrVNCwXYgTehLcKHkMBqFnSmfpGjyv)=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.Baseapi_Parse(RrVNCwXYgTehLcKHkMBqFnSmfpGjiW)
  if RrVNCwXYgTehLcKHkMBqFnSmfpGjyD=='':return RrVNCwXYgTehLcKHkMBqFnSmfpGjiP
  try:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv.update(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.GetDefaultParams(login=RrVNCwXYgTehLcKHkMBqFnSmfpGjPl))
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyE=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.callRequestCookies('Get',RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,payload=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,params=RrVNCwXYgTehLcKHkMBqFnSmfpGjyv,headers=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,cookies=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyO=json.loads(RrVNCwXYgTehLcKHkMBqFnSmfpGjyE.text)
   if not('celllist' in RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['band']):return[]
   RrVNCwXYgTehLcKHkMBqFnSmfpGjit=RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['band']['celllist']
   for RrVNCwXYgTehLcKHkMBqFnSmfpGjiu in RrVNCwXYgTehLcKHkMBqFnSmfpGjit:
    RrVNCwXYgTehLcKHkMBqFnSmfpGjix =RrVNCwXYgTehLcKHkMBqFnSmfpGjiu['event_list'][1]['url']
    (RrVNCwXYgTehLcKHkMBqFnSmfpGjia,RrVNCwXYgTehLcKHkMBqFnSmfpGjis)=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.Baseapi_Parse(RrVNCwXYgTehLcKHkMBqFnSmfpGjix)
    RrVNCwXYgTehLcKHkMBqFnSmfpGjio={'title':RrVNCwXYgTehLcKHkMBqFnSmfpGjiu['title_list'][0]['text'],'suburl':RrVNCwXYgTehLcKHkMBqFnSmfpGjia,'subapi':RrVNCwXYgTehLcKHkMBqFnSmfpGjis.get('api'),'subtype':'catagory' if RrVNCwXYgTehLcKHkMBqFnSmfpGjis else 'supersection'}
    RrVNCwXYgTehLcKHkMBqFnSmfpGjiP.append(RrVNCwXYgTehLcKHkMBqFnSmfpGjio)
  except RrVNCwXYgTehLcKHkMBqFnSmfpGjWI as exception:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjWd(exception)
   return[]
  return RrVNCwXYgTehLcKHkMBqFnSmfpGjiP
 def Get_SuperMultiSection_List(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI,subapi_text):
  RrVNCwXYgTehLcKHkMBqFnSmfpGjiP=[]
  RrVNCwXYgTehLcKHkMBqFnSmfpGjyv={}
  try:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjiI =urllib.parse.urlsplit(subapi_text)
   if RrVNCwXYgTehLcKHkMBqFnSmfpGjiI.path.find('apis.wavve.com')>=0: 
    RrVNCwXYgTehLcKHkMBqFnSmfpGjyD=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.HTTPTAG+RrVNCwXYgTehLcKHkMBqFnSmfpGjiI.path 
    RrVNCwXYgTehLcKHkMBqFnSmfpGjyv=RrVNCwXYgTehLcKHkMBqFnSmfpGjWP(urllib.parse.parse_qsl(RrVNCwXYgTehLcKHkMBqFnSmfpGjiI.query))
   else:
    RrVNCwXYgTehLcKHkMBqFnSmfpGjyD=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.API_DOMAIN+'/cf'+RrVNCwXYgTehLcKHkMBqFnSmfpGjiI.path 
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyD=RrVNCwXYgTehLcKHkMBqFnSmfpGjyD.replace('supermultisection/','supermultisections/')
  except RrVNCwXYgTehLcKHkMBqFnSmfpGjWI as exception:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjWd(exception)
   return[]
  try:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv.update(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.GetDefaultParams(login=RrVNCwXYgTehLcKHkMBqFnSmfpGjPl))
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyE=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.callRequestCookies('Get',RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,payload=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,params=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,headers=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,cookies=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyO=json.loads(RrVNCwXYgTehLcKHkMBqFnSmfpGjyE.text)
   if not('multisectionlist' in RrVNCwXYgTehLcKHkMBqFnSmfpGjyO):return[]
   RrVNCwXYgTehLcKHkMBqFnSmfpGjit=RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['multisectionlist']
   for RrVNCwXYgTehLcKHkMBqFnSmfpGjiu in RrVNCwXYgTehLcKHkMBqFnSmfpGjit:
    RrVNCwXYgTehLcKHkMBqFnSmfpGjiJ=RrVNCwXYgTehLcKHkMBqFnSmfpGjiu['title']
    if RrVNCwXYgTehLcKHkMBqFnSmfpGjWt(RrVNCwXYgTehLcKHkMBqFnSmfpGjiJ)==0:continue
    if RrVNCwXYgTehLcKHkMBqFnSmfpGjiJ=='minor':continue
    if re.search(u'베너',RrVNCwXYgTehLcKHkMBqFnSmfpGjiJ):continue
    if re.search(u'배너',RrVNCwXYgTehLcKHkMBqFnSmfpGjiJ):continue 
    if RrVNCwXYgTehLcKHkMBqFnSmfpGjWt(RrVNCwXYgTehLcKHkMBqFnSmfpGjiu['eventlist'])>=3:
     RrVNCwXYgTehLcKHkMBqFnSmfpGjis =RrVNCwXYgTehLcKHkMBqFnSmfpGjiu['eventlist'][2]['url']
    else:
     RrVNCwXYgTehLcKHkMBqFnSmfpGjis =RrVNCwXYgTehLcKHkMBqFnSmfpGjiu['eventlist'][1]['url']
    RrVNCwXYgTehLcKHkMBqFnSmfpGjiU=RrVNCwXYgTehLcKHkMBqFnSmfpGjiu['cell_type']
    if RrVNCwXYgTehLcKHkMBqFnSmfpGjiU=='band_2':
     if RrVNCwXYgTehLcKHkMBqFnSmfpGjis.find('channellist=')>=0:
      RrVNCwXYgTehLcKHkMBqFnSmfpGjiU='band_live'
    RrVNCwXYgTehLcKHkMBqFnSmfpGjio={'title':RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.Get_ChangeText(RrVNCwXYgTehLcKHkMBqFnSmfpGjiJ),'subapi':RrVNCwXYgTehLcKHkMBqFnSmfpGjis,'cell_type':RrVNCwXYgTehLcKHkMBqFnSmfpGjiU}
    RrVNCwXYgTehLcKHkMBqFnSmfpGjiP.append(RrVNCwXYgTehLcKHkMBqFnSmfpGjio)
  except RrVNCwXYgTehLcKHkMBqFnSmfpGjWI as exception:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjWd(exception)
   return[]
  return RrVNCwXYgTehLcKHkMBqFnSmfpGjiP
 def Get_BandLiveSection_List(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI,RrVNCwXYgTehLcKHkMBqFnSmfpGjiW,page_int=1):
  RrVNCwXYgTehLcKHkMBqFnSmfpGjiA=[]
  RrVNCwXYgTehLcKHkMBqFnSmfpGjiQ=RrVNCwXYgTehLcKHkMBqFnSmfpGjiz=1
  RrVNCwXYgTehLcKHkMBqFnSmfpGjiD=RrVNCwXYgTehLcKHkMBqFnSmfpGjPl
  try:
   (RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,RrVNCwXYgTehLcKHkMBqFnSmfpGjyv)=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.Baseapi_Parse(RrVNCwXYgTehLcKHkMBqFnSmfpGjiW)
  except RrVNCwXYgTehLcKHkMBqFnSmfpGjWI as exception:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjWd(exception)
   return[],RrVNCwXYgTehLcKHkMBqFnSmfpGjPl
  try:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv['limit']=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.LIST_LIMIT
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv['offset']=RrVNCwXYgTehLcKHkMBqFnSmfpGjWi((page_int-1)*RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.LIST_LIMIT)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv.update(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.GetDefaultParams(login=RrVNCwXYgTehLcKHkMBqFnSmfpGjPl))
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyE=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.callRequestCookies('Get',RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,payload=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,params=RrVNCwXYgTehLcKHkMBqFnSmfpGjyv,headers=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,cookies=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyO=json.loads(RrVNCwXYgTehLcKHkMBqFnSmfpGjyE.text)
   if not('celllist' in RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['cell_toplist']):return[],RrVNCwXYgTehLcKHkMBqFnSmfpGjPl
   RrVNCwXYgTehLcKHkMBqFnSmfpGjit=RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['cell_toplist']['celllist']
   for RrVNCwXYgTehLcKHkMBqFnSmfpGjiu in RrVNCwXYgTehLcKHkMBqFnSmfpGjit:
    RrVNCwXYgTehLcKHkMBqFnSmfpGjib =RrVNCwXYgTehLcKHkMBqFnSmfpGjiu['event_list'][1]['url']
    RrVNCwXYgTehLcKHkMBqFnSmfpGjiE=urllib.parse.urlsplit(RrVNCwXYgTehLcKHkMBqFnSmfpGjib).query
    RrVNCwXYgTehLcKHkMBqFnSmfpGjiE=RrVNCwXYgTehLcKHkMBqFnSmfpGjWP(urllib.parse.parse_qsl(RrVNCwXYgTehLcKHkMBqFnSmfpGjiE))
    RrVNCwXYgTehLcKHkMBqFnSmfpGjiO='channelid'
    RrVNCwXYgTehLcKHkMBqFnSmfpGjil=RrVNCwXYgTehLcKHkMBqFnSmfpGjiE[RrVNCwXYgTehLcKHkMBqFnSmfpGjiO]
    RrVNCwXYgTehLcKHkMBqFnSmfpGjio={'studio':RrVNCwXYgTehLcKHkMBqFnSmfpGjiu['title_list'][0]['text'],'tvshowtitle':RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.Get_ChangeText(RrVNCwXYgTehLcKHkMBqFnSmfpGjiu['title_list'][1]['text']),'channelid':RrVNCwXYgTehLcKHkMBqFnSmfpGjil,'age':RrVNCwXYgTehLcKHkMBqFnSmfpGjiu.get('age'),'thumbnail':'https://%s'%RrVNCwXYgTehLcKHkMBqFnSmfpGjiu.get('thumbnail')}
    RrVNCwXYgTehLcKHkMBqFnSmfpGjiA.append(RrVNCwXYgTehLcKHkMBqFnSmfpGjio)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjiQ=RrVNCwXYgTehLcKHkMBqFnSmfpGjWv(RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['cell_toplist']['pagecount'])
   if RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['cell_toplist']['count']:RrVNCwXYgTehLcKHkMBqFnSmfpGjiz =RrVNCwXYgTehLcKHkMBqFnSmfpGjWv(RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['cell_toplist']['count'])
   else:RrVNCwXYgTehLcKHkMBqFnSmfpGjiz=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.LIST_LIMIT*page_int
   RrVNCwXYgTehLcKHkMBqFnSmfpGjiD=RrVNCwXYgTehLcKHkMBqFnSmfpGjiQ>RrVNCwXYgTehLcKHkMBqFnSmfpGjiz
  except RrVNCwXYgTehLcKHkMBqFnSmfpGjWI as exception:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjWd(exception)
   return[],RrVNCwXYgTehLcKHkMBqFnSmfpGjPl
  return RrVNCwXYgTehLcKHkMBqFnSmfpGjiA,RrVNCwXYgTehLcKHkMBqFnSmfpGjiD
 def Get_Band2Section_List(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI,RrVNCwXYgTehLcKHkMBqFnSmfpGjiW,page_int=1):
  RrVNCwXYgTehLcKHkMBqFnSmfpGjIy=[]
  RrVNCwXYgTehLcKHkMBqFnSmfpGjiQ=RrVNCwXYgTehLcKHkMBqFnSmfpGjiz=1
  RrVNCwXYgTehLcKHkMBqFnSmfpGjiD=RrVNCwXYgTehLcKHkMBqFnSmfpGjPl
  try:
   (RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,RrVNCwXYgTehLcKHkMBqFnSmfpGjyv)=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.Baseapi_Parse(RrVNCwXYgTehLcKHkMBqFnSmfpGjiW)
  except RrVNCwXYgTehLcKHkMBqFnSmfpGjWI as exception:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjWd(exception)
   return[],RrVNCwXYgTehLcKHkMBqFnSmfpGjPl
  try:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv['came'] ='BandView'
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv['limit']=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.LIST_LIMIT
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv['offset']=RrVNCwXYgTehLcKHkMBqFnSmfpGjWi((page_int-1)*RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.LIST_LIMIT)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv.update(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.GetDefaultParams(login=RrVNCwXYgTehLcKHkMBqFnSmfpGjPl))
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyE=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.callRequestCookies('Get',RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,payload=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,params=RrVNCwXYgTehLcKHkMBqFnSmfpGjyv,headers=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,cookies=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyO=json.loads(RrVNCwXYgTehLcKHkMBqFnSmfpGjyE.text)
   if not('celllist' in RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['cell_toplist']):return[],RrVNCwXYgTehLcKHkMBqFnSmfpGjPl
   RrVNCwXYgTehLcKHkMBqFnSmfpGjit=RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['cell_toplist']['celllist']
   for RrVNCwXYgTehLcKHkMBqFnSmfpGjiu in RrVNCwXYgTehLcKHkMBqFnSmfpGjit:
    RrVNCwXYgTehLcKHkMBqFnSmfpGjib =RrVNCwXYgTehLcKHkMBqFnSmfpGjiu['event_list'][1]['url']
    RrVNCwXYgTehLcKHkMBqFnSmfpGjiE=urllib.parse.urlsplit(RrVNCwXYgTehLcKHkMBqFnSmfpGjib).query
    RrVNCwXYgTehLcKHkMBqFnSmfpGjiE=RrVNCwXYgTehLcKHkMBqFnSmfpGjWP(urllib.parse.parse_qsl(RrVNCwXYgTehLcKHkMBqFnSmfpGjiE))
    RrVNCwXYgTehLcKHkMBqFnSmfpGjiO='contentid'
    RrVNCwXYgTehLcKHkMBqFnSmfpGjil=RrVNCwXYgTehLcKHkMBqFnSmfpGjiE[RrVNCwXYgTehLcKHkMBqFnSmfpGjiO]
    RrVNCwXYgTehLcKHkMBqFnSmfpGjio={'programtitle':RrVNCwXYgTehLcKHkMBqFnSmfpGjiu['title_list'][0]['text'],'episodetitle':RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.Get_ChangeText(RrVNCwXYgTehLcKHkMBqFnSmfpGjiu['title_list'][1]['text']),'age':RrVNCwXYgTehLcKHkMBqFnSmfpGjiu.get('age'),'thumbnail':RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.HTTPTAG+RrVNCwXYgTehLcKHkMBqFnSmfpGjiu.get('thumbnail'),'vidtype':RrVNCwXYgTehLcKHkMBqFnSmfpGjiO,'videoid':RrVNCwXYgTehLcKHkMBqFnSmfpGjil}
    RrVNCwXYgTehLcKHkMBqFnSmfpGjIy.append(RrVNCwXYgTehLcKHkMBqFnSmfpGjio)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjiQ=RrVNCwXYgTehLcKHkMBqFnSmfpGjWv(RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['cell_toplist']['pagecount'])
   if RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['cell_toplist']['count']:RrVNCwXYgTehLcKHkMBqFnSmfpGjiz =RrVNCwXYgTehLcKHkMBqFnSmfpGjWv(RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['cell_toplist']['count'])
   else:RrVNCwXYgTehLcKHkMBqFnSmfpGjiz=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.LIST_LIMIT*page_int
   RrVNCwXYgTehLcKHkMBqFnSmfpGjiD=RrVNCwXYgTehLcKHkMBqFnSmfpGjiQ>RrVNCwXYgTehLcKHkMBqFnSmfpGjiz
  except RrVNCwXYgTehLcKHkMBqFnSmfpGjWI as exception:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjWd(exception)
   return[],RrVNCwXYgTehLcKHkMBqFnSmfpGjPl
  return RrVNCwXYgTehLcKHkMBqFnSmfpGjIy,RrVNCwXYgTehLcKHkMBqFnSmfpGjiD
 def Get_Program_List(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI,RrVNCwXYgTehLcKHkMBqFnSmfpGjiW,page_int=1,orderby='-'):
  RrVNCwXYgTehLcKHkMBqFnSmfpGjIi=[]
  RrVNCwXYgTehLcKHkMBqFnSmfpGjiQ=RrVNCwXYgTehLcKHkMBqFnSmfpGjiz=1
  RrVNCwXYgTehLcKHkMBqFnSmfpGjiD=RrVNCwXYgTehLcKHkMBqFnSmfpGjPl
  (RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,RrVNCwXYgTehLcKHkMBqFnSmfpGjyv)=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.Baseapi_Parse(RrVNCwXYgTehLcKHkMBqFnSmfpGjiW)
  if RrVNCwXYgTehLcKHkMBqFnSmfpGjyD=='':return RrVNCwXYgTehLcKHkMBqFnSmfpGjIi,RrVNCwXYgTehLcKHkMBqFnSmfpGjiD
  try:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv['limit'] =RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.LIST_LIMIT
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv['offset']=RrVNCwXYgTehLcKHkMBqFnSmfpGjWi((page_int-1)*RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.LIST_LIMIT)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv['page'] =RrVNCwXYgTehLcKHkMBqFnSmfpGjWi(page_int)
   if RrVNCwXYgTehLcKHkMBqFnSmfpGjyv.get('orderby')!='' and RrVNCwXYgTehLcKHkMBqFnSmfpGjyv.get('orderby')!='regdatefirst' and orderby!='-':
    RrVNCwXYgTehLcKHkMBqFnSmfpGjyv['orderby']=orderby 
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv.update(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.GetDefaultParams(login=RrVNCwXYgTehLcKHkMBqFnSmfpGjPl))
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyE=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.callRequestCookies('Get',RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,payload=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,params=RrVNCwXYgTehLcKHkMBqFnSmfpGjyv,headers=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,cookies=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyO=json.loads(RrVNCwXYgTehLcKHkMBqFnSmfpGjyE.text)
   if RrVNCwXYgTehLcKHkMBqFnSmfpGjiW.find('instantplay')>=0:
    if not('celllist' in RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['band']):return RrVNCwXYgTehLcKHkMBqFnSmfpGjIi,RrVNCwXYgTehLcKHkMBqFnSmfpGjiD
    RrVNCwXYgTehLcKHkMBqFnSmfpGjit=RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['band']['celllist']
   else:
    if not('celllist' in RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['cell_toplist']):return RrVNCwXYgTehLcKHkMBqFnSmfpGjIi,RrVNCwXYgTehLcKHkMBqFnSmfpGjiD
    RrVNCwXYgTehLcKHkMBqFnSmfpGjit=RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['cell_toplist']['celllist']
   for RrVNCwXYgTehLcKHkMBqFnSmfpGjiu in RrVNCwXYgTehLcKHkMBqFnSmfpGjit:
    for RrVNCwXYgTehLcKHkMBqFnSmfpGjId in RrVNCwXYgTehLcKHkMBqFnSmfpGjiu['event_list']:
     if RrVNCwXYgTehLcKHkMBqFnSmfpGjId.get('type')=='on-navigation':
      RrVNCwXYgTehLcKHkMBqFnSmfpGjib =RrVNCwXYgTehLcKHkMBqFnSmfpGjId['url']
    RrVNCwXYgTehLcKHkMBqFnSmfpGjiE=urllib.parse.urlsplit(RrVNCwXYgTehLcKHkMBqFnSmfpGjib).query
    RrVNCwXYgTehLcKHkMBqFnSmfpGjiO=RrVNCwXYgTehLcKHkMBqFnSmfpGjiE[0:RrVNCwXYgTehLcKHkMBqFnSmfpGjiE.find('=')]
    RrVNCwXYgTehLcKHkMBqFnSmfpGjil=RrVNCwXYgTehLcKHkMBqFnSmfpGjiE[RrVNCwXYgTehLcKHkMBqFnSmfpGjiE.find('=')+1:]
    RrVNCwXYgTehLcKHkMBqFnSmfpGjio={'title':RrVNCwXYgTehLcKHkMBqFnSmfpGjiu['title_list'][0]['text'],'age':RrVNCwXYgTehLcKHkMBqFnSmfpGjiu['age'],'thumbnail':'https://%s'%RrVNCwXYgTehLcKHkMBqFnSmfpGjiu.get('thumbnail'),'videoid':RrVNCwXYgTehLcKHkMBqFnSmfpGjil,'vidtype':RrVNCwXYgTehLcKHkMBqFnSmfpGjiO}
    RrVNCwXYgTehLcKHkMBqFnSmfpGjIi.append(RrVNCwXYgTehLcKHkMBqFnSmfpGjio)
   if RrVNCwXYgTehLcKHkMBqFnSmfpGjiW.find('instantplay')<0:
    RrVNCwXYgTehLcKHkMBqFnSmfpGjiQ=RrVNCwXYgTehLcKHkMBqFnSmfpGjWv(RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['cell_toplist']['pagecount'])
    if RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['cell_toplist']['count']:RrVNCwXYgTehLcKHkMBqFnSmfpGjiz =RrVNCwXYgTehLcKHkMBqFnSmfpGjWv(RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['cell_toplist']['count'])
    else:RrVNCwXYgTehLcKHkMBqFnSmfpGjiz=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.LIST_LIMIT*page_int
    RrVNCwXYgTehLcKHkMBqFnSmfpGjiD=RrVNCwXYgTehLcKHkMBqFnSmfpGjiQ>RrVNCwXYgTehLcKHkMBqFnSmfpGjiz
  except RrVNCwXYgTehLcKHkMBqFnSmfpGjWI as exception:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjWd(exception)
   return[],RrVNCwXYgTehLcKHkMBqFnSmfpGjPl
  return RrVNCwXYgTehLcKHkMBqFnSmfpGjIi,RrVNCwXYgTehLcKHkMBqFnSmfpGjiD
 def Get_Movie_List(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI,RrVNCwXYgTehLcKHkMBqFnSmfpGjiW,page_int=1):
  RrVNCwXYgTehLcKHkMBqFnSmfpGjIP=[]
  RrVNCwXYgTehLcKHkMBqFnSmfpGjiQ=RrVNCwXYgTehLcKHkMBqFnSmfpGjiz=1
  RrVNCwXYgTehLcKHkMBqFnSmfpGjiD=RrVNCwXYgTehLcKHkMBqFnSmfpGjPl
  (RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,RrVNCwXYgTehLcKHkMBqFnSmfpGjyv)=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.Baseapi_Parse(RrVNCwXYgTehLcKHkMBqFnSmfpGjiW)
  if RrVNCwXYgTehLcKHkMBqFnSmfpGjyD=='':return RrVNCwXYgTehLcKHkMBqFnSmfpGjIP,RrVNCwXYgTehLcKHkMBqFnSmfpGjiD
  try:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv['limit']=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.MV_LIMIT
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv['offset']=RrVNCwXYgTehLcKHkMBqFnSmfpGjWi((page_int-1)*RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.MV_LIMIT)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv.update(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.GetDefaultParams(login=RrVNCwXYgTehLcKHkMBqFnSmfpGjPl))
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyE=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.callRequestCookies('Get',RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,payload=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,params=RrVNCwXYgTehLcKHkMBqFnSmfpGjyv,headers=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,cookies=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyO=json.loads(RrVNCwXYgTehLcKHkMBqFnSmfpGjyE.text)
   if not('celllist' in RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['cell_toplist']):return RrVNCwXYgTehLcKHkMBqFnSmfpGjIP,RrVNCwXYgTehLcKHkMBqFnSmfpGjiD
   RrVNCwXYgTehLcKHkMBqFnSmfpGjit=RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['cell_toplist']['celllist']
   for RrVNCwXYgTehLcKHkMBqFnSmfpGjiu in RrVNCwXYgTehLcKHkMBqFnSmfpGjit:
    RrVNCwXYgTehLcKHkMBqFnSmfpGjib =RrVNCwXYgTehLcKHkMBqFnSmfpGjiu['event_list'][1]['url']
    RrVNCwXYgTehLcKHkMBqFnSmfpGjiE=urllib.parse.urlsplit(RrVNCwXYgTehLcKHkMBqFnSmfpGjib).query
    RrVNCwXYgTehLcKHkMBqFnSmfpGjiO=RrVNCwXYgTehLcKHkMBqFnSmfpGjiE[0:RrVNCwXYgTehLcKHkMBqFnSmfpGjiE.find('=')]
    RrVNCwXYgTehLcKHkMBqFnSmfpGjil=RrVNCwXYgTehLcKHkMBqFnSmfpGjiE[RrVNCwXYgTehLcKHkMBqFnSmfpGjiE.find('=')+1:]
    RrVNCwXYgTehLcKHkMBqFnSmfpGjio={'title':RrVNCwXYgTehLcKHkMBqFnSmfpGjiu['title_list'][0]['text'],'age':RrVNCwXYgTehLcKHkMBqFnSmfpGjiu['age'],'thumbnail':'https://%s'%RrVNCwXYgTehLcKHkMBqFnSmfpGjiu.get('thumbnail'),'videoid':RrVNCwXYgTehLcKHkMBqFnSmfpGjil,'vidtype':RrVNCwXYgTehLcKHkMBqFnSmfpGjiO}
    RrVNCwXYgTehLcKHkMBqFnSmfpGjIP.append(RrVNCwXYgTehLcKHkMBqFnSmfpGjio)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjiQ=RrVNCwXYgTehLcKHkMBqFnSmfpGjWv(RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['cell_toplist']['pagecount'])
   if RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['cell_toplist']['count']:RrVNCwXYgTehLcKHkMBqFnSmfpGjiz =RrVNCwXYgTehLcKHkMBqFnSmfpGjWv(RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['cell_toplist']['count'])
   else:RrVNCwXYgTehLcKHkMBqFnSmfpGjiz=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.MV_LIMIT*page_int
   RrVNCwXYgTehLcKHkMBqFnSmfpGjiD=RrVNCwXYgTehLcKHkMBqFnSmfpGjiQ>RrVNCwXYgTehLcKHkMBqFnSmfpGjiz
  except RrVNCwXYgTehLcKHkMBqFnSmfpGjWI as exception:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjWd(exception)
   return[],RrVNCwXYgTehLcKHkMBqFnSmfpGjPl
  return RrVNCwXYgTehLcKHkMBqFnSmfpGjIP,RrVNCwXYgTehLcKHkMBqFnSmfpGjiD
 def ProgramidToContentid(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI,RrVNCwXYgTehLcKHkMBqFnSmfpGjIt):
  RrVNCwXYgTehLcKHkMBqFnSmfpGjIW=''
  try:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyD =RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.API_DOMAIN+'/vod/programs-contentid/'+RrVNCwXYgTehLcKHkMBqFnSmfpGjIt
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.GetDefaultParams(login=RrVNCwXYgTehLcKHkMBqFnSmfpGjPl)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyE=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.callRequestCookies('Get',RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,payload=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,params=RrVNCwXYgTehLcKHkMBqFnSmfpGjyv,headers=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,cookies=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjIv=json.loads(RrVNCwXYgTehLcKHkMBqFnSmfpGjyE.text)
   if not('contentid' in RrVNCwXYgTehLcKHkMBqFnSmfpGjIv):return RrVNCwXYgTehLcKHkMBqFnSmfpGjIW 
   RrVNCwXYgTehLcKHkMBqFnSmfpGjIW=RrVNCwXYgTehLcKHkMBqFnSmfpGjIv['contentid']
  except RrVNCwXYgTehLcKHkMBqFnSmfpGjWI as exception:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjWd(exception)
  return RrVNCwXYgTehLcKHkMBqFnSmfpGjIW
 def ContentidToProgramid(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI,RrVNCwXYgTehLcKHkMBqFnSmfpGjIW):
  RrVNCwXYgTehLcKHkMBqFnSmfpGjIt=''
  try:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyD =RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.API_DOMAIN+'/cf/vod/contents/'+RrVNCwXYgTehLcKHkMBqFnSmfpGjIW
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.GetDefaultParams(login=RrVNCwXYgTehLcKHkMBqFnSmfpGjPl)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyE=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.callRequestCookies('Get',RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,payload=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,params=RrVNCwXYgTehLcKHkMBqFnSmfpGjyv,headers=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,cookies=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjIv=json.loads(RrVNCwXYgTehLcKHkMBqFnSmfpGjyE.text)
   if not('programid' in RrVNCwXYgTehLcKHkMBqFnSmfpGjIv):return RrVNCwXYgTehLcKHkMBqFnSmfpGjIt 
   RrVNCwXYgTehLcKHkMBqFnSmfpGjIt=RrVNCwXYgTehLcKHkMBqFnSmfpGjIv['programid']
  except RrVNCwXYgTehLcKHkMBqFnSmfpGjWI as exception:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjWd(exception)
  return RrVNCwXYgTehLcKHkMBqFnSmfpGjIt
 def GetProgramInfo(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI,program_code):
  RrVNCwXYgTehLcKHkMBqFnSmfpGjIu={}
  try:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyD=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.API_DOMAIN+'/cf/vod/contents/'+program_code
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.GetDefaultParams(login=RrVNCwXYgTehLcKHkMBqFnSmfpGjPl)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyE=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.callRequestCookies('Get',RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,payload=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,params=RrVNCwXYgTehLcKHkMBqFnSmfpGjyv,headers=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,cookies=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjIv=json.loads(RrVNCwXYgTehLcKHkMBqFnSmfpGjyE.text)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjWd(RrVNCwXYgTehLcKHkMBqFnSmfpGjIv)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjIo=img_fanart=RrVNCwXYgTehLcKHkMBqFnSmfpGjIx=''
   if RrVNCwXYgTehLcKHkMBqFnSmfpGjIv.get('programposterimage')!='':RrVNCwXYgTehLcKHkMBqFnSmfpGjIo =RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.HTTPTAG+RrVNCwXYgTehLcKHkMBqFnSmfpGjIv.get('programposterimage')
   if RrVNCwXYgTehLcKHkMBqFnSmfpGjIv.get('programimage') !='':img_fanart =RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.HTTPTAG+RrVNCwXYgTehLcKHkMBqFnSmfpGjIv.get('programimage')
   if RrVNCwXYgTehLcKHkMBqFnSmfpGjIv.get('programcirlceimage')!='':RrVNCwXYgTehLcKHkMBqFnSmfpGjIx=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.HTTPTAG+RrVNCwXYgTehLcKHkMBqFnSmfpGjIv.get('programcirlceimage')
   if 'poster_default' in RrVNCwXYgTehLcKHkMBqFnSmfpGjIo:
    RrVNCwXYgTehLcKHkMBqFnSmfpGjIo =img_fanart
    RrVNCwXYgTehLcKHkMBqFnSmfpGjIx=''
   RrVNCwXYgTehLcKHkMBqFnSmfpGjIu={'imgPoster':RrVNCwXYgTehLcKHkMBqFnSmfpGjIo,'imgFanart':img_fanart,'imgClearlogo':RrVNCwXYgTehLcKHkMBqFnSmfpGjIx}
  except RrVNCwXYgTehLcKHkMBqFnSmfpGjWI as exception:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjWd(exception)
  return RrVNCwXYgTehLcKHkMBqFnSmfpGjIu
 def Get_Episode_List(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI,RrVNCwXYgTehLcKHkMBqFnSmfpGjil,RrVNCwXYgTehLcKHkMBqFnSmfpGjiO,page_int=1,orderby='desc'):
  RrVNCwXYgTehLcKHkMBqFnSmfpGjIa=[]
  RrVNCwXYgTehLcKHkMBqFnSmfpGjiQ=RrVNCwXYgTehLcKHkMBqFnSmfpGjiz=1
  RrVNCwXYgTehLcKHkMBqFnSmfpGjiD=RrVNCwXYgTehLcKHkMBqFnSmfpGjPl
  RrVNCwXYgTehLcKHkMBqFnSmfpGjIs={}
  if RrVNCwXYgTehLcKHkMBqFnSmfpGjiO=='contentid':
   RrVNCwXYgTehLcKHkMBqFnSmfpGjIt=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.ContentidToProgramid(RrVNCwXYgTehLcKHkMBqFnSmfpGjil)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjIs=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.GetProgramInfo(RrVNCwXYgTehLcKHkMBqFnSmfpGjil)
  else:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjIt=RrVNCwXYgTehLcKHkMBqFnSmfpGjil
   RrVNCwXYgTehLcKHkMBqFnSmfpGjIW=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.ProgramidToContentid(RrVNCwXYgTehLcKHkMBqFnSmfpGjil)
   if RrVNCwXYgTehLcKHkMBqFnSmfpGjIW!='':RrVNCwXYgTehLcKHkMBqFnSmfpGjIs=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.GetProgramInfo(RrVNCwXYgTehLcKHkMBqFnSmfpGjIW)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyD=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.API_DOMAIN+'/vod/programs-contents/'+RrVNCwXYgTehLcKHkMBqFnSmfpGjIt
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv={}
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv['limit'] =RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.EP_LIMIT
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv['offset']=RrVNCwXYgTehLcKHkMBqFnSmfpGjWi((page_int-1)*RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.EP_LIMIT)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv['orderby']=orderby 
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv.update(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.GetDefaultParams(login=RrVNCwXYgTehLcKHkMBqFnSmfpGjPl))
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyE=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.callRequestCookies('Get',RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,payload=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,params=RrVNCwXYgTehLcKHkMBqFnSmfpGjyv,headers=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,cookies=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyO=json.loads(RrVNCwXYgTehLcKHkMBqFnSmfpGjyE.text)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjit=RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['list']
   for RrVNCwXYgTehLcKHkMBqFnSmfpGjiu in RrVNCwXYgTehLcKHkMBqFnSmfpGjit:
    RrVNCwXYgTehLcKHkMBqFnSmfpGjIU=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',RrVNCwXYgTehLcKHkMBqFnSmfpGjiu.get('synopsis'))
    RrVNCwXYgTehLcKHkMBqFnSmfpGjIA=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.HTTPTAG+RrVNCwXYgTehLcKHkMBqFnSmfpGjiu.get('image')
    RrVNCwXYgTehLcKHkMBqFnSmfpGjIQ=RrVNCwXYgTehLcKHkMBqFnSmfpGjID=RrVNCwXYgTehLcKHkMBqFnSmfpGjIb=''
    if RrVNCwXYgTehLcKHkMBqFnSmfpGjIs!={}:
     RrVNCwXYgTehLcKHkMBqFnSmfpGjIQ =RrVNCwXYgTehLcKHkMBqFnSmfpGjIs.get('imgPoster')
     RrVNCwXYgTehLcKHkMBqFnSmfpGjID =RrVNCwXYgTehLcKHkMBqFnSmfpGjIs.get('imgFanart')
     RrVNCwXYgTehLcKHkMBqFnSmfpGjIb=RrVNCwXYgTehLcKHkMBqFnSmfpGjIs.get('imgClearlogo')
     RrVNCwXYgTehLcKHkMBqFnSmfpGjIE={'thumb':RrVNCwXYgTehLcKHkMBqFnSmfpGjIA,'poster':RrVNCwXYgTehLcKHkMBqFnSmfpGjIQ,'fanart':RrVNCwXYgTehLcKHkMBqFnSmfpGjID,'clearlogo':RrVNCwXYgTehLcKHkMBqFnSmfpGjIb}
    else:
     RrVNCwXYgTehLcKHkMBqFnSmfpGjIE=RrVNCwXYgTehLcKHkMBqFnSmfpGjIA
    RrVNCwXYgTehLcKHkMBqFnSmfpGjio={'programtitle':RrVNCwXYgTehLcKHkMBqFnSmfpGjiu.get('programtitle'),'episodetitle':RrVNCwXYgTehLcKHkMBqFnSmfpGjiu.get('episodetitle'),'episodenumber':RrVNCwXYgTehLcKHkMBqFnSmfpGjiu.get('episodenumber'),'releasedate':RrVNCwXYgTehLcKHkMBqFnSmfpGjiu.get('releasedate'),'releaseweekday':RrVNCwXYgTehLcKHkMBqFnSmfpGjiu.get('releaseweekday'),'programid':RrVNCwXYgTehLcKHkMBqFnSmfpGjiu.get('programid'),'contentid':RrVNCwXYgTehLcKHkMBqFnSmfpGjiu.get('contentid'),'age':RrVNCwXYgTehLcKHkMBqFnSmfpGjiu.get('targetage'),'playtime':RrVNCwXYgTehLcKHkMBqFnSmfpGjiu.get('playtime'),'synopsis':RrVNCwXYgTehLcKHkMBqFnSmfpGjIU,'episodeactors':RrVNCwXYgTehLcKHkMBqFnSmfpGjiu.get('episodeactors').split(',')if RrVNCwXYgTehLcKHkMBqFnSmfpGjiu.get('episodeactors')!='' else[],'thumbnail':RrVNCwXYgTehLcKHkMBqFnSmfpGjIE}
    RrVNCwXYgTehLcKHkMBqFnSmfpGjIa.append(RrVNCwXYgTehLcKHkMBqFnSmfpGjio)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjiQ=RrVNCwXYgTehLcKHkMBqFnSmfpGjWv(RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['pagecount'])
   if RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['count']:RrVNCwXYgTehLcKHkMBqFnSmfpGjiz =RrVNCwXYgTehLcKHkMBqFnSmfpGjWv(RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['count'])
   else:RrVNCwXYgTehLcKHkMBqFnSmfpGjiz=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.EP_LIMIT*page_int
   RrVNCwXYgTehLcKHkMBqFnSmfpGjiD=RrVNCwXYgTehLcKHkMBqFnSmfpGjiQ>RrVNCwXYgTehLcKHkMBqFnSmfpGjiz
  except RrVNCwXYgTehLcKHkMBqFnSmfpGjWI as exception:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjWd(exception)
   return[],RrVNCwXYgTehLcKHkMBqFnSmfpGjPl
  return RrVNCwXYgTehLcKHkMBqFnSmfpGjIa,RrVNCwXYgTehLcKHkMBqFnSmfpGjiD
 def GetEPGList(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI,genre):
  RrVNCwXYgTehLcKHkMBqFnSmfpGjIO={}
  try:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjIl=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.Get_Now_Datetime()
   if genre=='all':
    RrVNCwXYgTehLcKHkMBqFnSmfpGjIz =RrVNCwXYgTehLcKHkMBqFnSmfpGjIl+datetime.timedelta(hours=3)
   else:
    RrVNCwXYgTehLcKHkMBqFnSmfpGjIz =RrVNCwXYgTehLcKHkMBqFnSmfpGjIl+datetime.timedelta(hours=3)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyD=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.API_DOMAIN+'/live/epgs'
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv={'limit':'100','offset':'0','genre':genre,'startdatetime':RrVNCwXYgTehLcKHkMBqFnSmfpGjIl.strftime('%Y-%m-%d %H:00'),'enddatetime':RrVNCwXYgTehLcKHkMBqFnSmfpGjIz.strftime('%Y-%m-%d %H:00')}
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv.update(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.GetDefaultParams(login=RrVNCwXYgTehLcKHkMBqFnSmfpGjPl))
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyE=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.callRequestCookies('Get',RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,payload=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,params=RrVNCwXYgTehLcKHkMBqFnSmfpGjyv,headers=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,cookies=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyO=json.loads(RrVNCwXYgTehLcKHkMBqFnSmfpGjyE.text)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjdy=RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['list']
   for RrVNCwXYgTehLcKHkMBqFnSmfpGjiu in RrVNCwXYgTehLcKHkMBqFnSmfpGjdy:
    RrVNCwXYgTehLcKHkMBqFnSmfpGjdi=''
    for RrVNCwXYgTehLcKHkMBqFnSmfpGjdI in RrVNCwXYgTehLcKHkMBqFnSmfpGjiu['list']:
     if RrVNCwXYgTehLcKHkMBqFnSmfpGjdi:RrVNCwXYgTehLcKHkMBqFnSmfpGjdi+='\n'
     RrVNCwXYgTehLcKHkMBqFnSmfpGjdi+=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.Get_ChangeText(RrVNCwXYgTehLcKHkMBqFnSmfpGjdI['title'])+'\n'
     RrVNCwXYgTehLcKHkMBqFnSmfpGjdi+=' [%s ~ %s]'%(RrVNCwXYgTehLcKHkMBqFnSmfpGjdI['starttime'][-5:],RrVNCwXYgTehLcKHkMBqFnSmfpGjdI['endtime'][-5:])+'\n'
    RrVNCwXYgTehLcKHkMBqFnSmfpGjIO[RrVNCwXYgTehLcKHkMBqFnSmfpGjiu['channelid']]=RrVNCwXYgTehLcKHkMBqFnSmfpGjdi
  except RrVNCwXYgTehLcKHkMBqFnSmfpGjWI as exception:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjWd(exception)
  return RrVNCwXYgTehLcKHkMBqFnSmfpGjIO
 def Get_LiveChannel_List(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI,genre,RrVNCwXYgTehLcKHkMBqFnSmfpGjiW):
  RrVNCwXYgTehLcKHkMBqFnSmfpGjiA=[]
  (RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,RrVNCwXYgTehLcKHkMBqFnSmfpGjyv)=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.Baseapi_Parse(RrVNCwXYgTehLcKHkMBqFnSmfpGjiW)
  if RrVNCwXYgTehLcKHkMBqFnSmfpGjyD=='':return RrVNCwXYgTehLcKHkMBqFnSmfpGjiA
  RrVNCwXYgTehLcKHkMBqFnSmfpGjdP=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.GetEPGList(genre)
  try:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv.update(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.GetDefaultParams(login=RrVNCwXYgTehLcKHkMBqFnSmfpGjPl))
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv['genre']=genre
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyE=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.callRequestCookies('Get',RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,payload=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,params=RrVNCwXYgTehLcKHkMBqFnSmfpGjyv,headers=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,cookies=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyO=json.loads(RrVNCwXYgTehLcKHkMBqFnSmfpGjyE.text)
   if not('celllist' in RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['cell_toplist']):return[]
   RrVNCwXYgTehLcKHkMBqFnSmfpGjit=RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['cell_toplist']['celllist']
   for RrVNCwXYgTehLcKHkMBqFnSmfpGjiu in RrVNCwXYgTehLcKHkMBqFnSmfpGjit:
    RrVNCwXYgTehLcKHkMBqFnSmfpGjIW=RrVNCwXYgTehLcKHkMBqFnSmfpGjiu['contentid']
    if RrVNCwXYgTehLcKHkMBqFnSmfpGjIW in RrVNCwXYgTehLcKHkMBqFnSmfpGjdP:
     RrVNCwXYgTehLcKHkMBqFnSmfpGjdW=RrVNCwXYgTehLcKHkMBqFnSmfpGjdP[RrVNCwXYgTehLcKHkMBqFnSmfpGjIW]
    else:
     RrVNCwXYgTehLcKHkMBqFnSmfpGjdW=''
    RrVNCwXYgTehLcKHkMBqFnSmfpGjio={'studio':RrVNCwXYgTehLcKHkMBqFnSmfpGjiu['title_list'][0]['text'],'tvshowtitle':RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.Get_ChangeText(RrVNCwXYgTehLcKHkMBqFnSmfpGjiu['title_list'][1]['text']),'channelid':RrVNCwXYgTehLcKHkMBqFnSmfpGjIW,'age':RrVNCwXYgTehLcKHkMBqFnSmfpGjiu['age'],'thumbnail':'https://%s'%RrVNCwXYgTehLcKHkMBqFnSmfpGjiu.get('thumbnail'),'epg':RrVNCwXYgTehLcKHkMBqFnSmfpGjdW}
    RrVNCwXYgTehLcKHkMBqFnSmfpGjiA.append(RrVNCwXYgTehLcKHkMBqFnSmfpGjio)
  except RrVNCwXYgTehLcKHkMBqFnSmfpGjWI as exception:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjWd(exception)
   return[]
  return RrVNCwXYgTehLcKHkMBqFnSmfpGjiA
 def Get_Search_List(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI,search_key,sType,page_int,exclusion21=RrVNCwXYgTehLcKHkMBqFnSmfpGjPl):
  RrVNCwXYgTehLcKHkMBqFnSmfpGjdv=[]
  RrVNCwXYgTehLcKHkMBqFnSmfpGjiQ=RrVNCwXYgTehLcKHkMBqFnSmfpGjiz=1
  RrVNCwXYgTehLcKHkMBqFnSmfpGjiD=RrVNCwXYgTehLcKHkMBqFnSmfpGjPl
  try:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyD=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.API_DOMAIN+'/cf/search/list.js'
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':RrVNCwXYgTehLcKHkMBqFnSmfpGjWi((page_int-1)*RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.SEARCH_LIMIT),'limit':RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.SEARCH_LIMIT,'orderby':'score'}
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv.update(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.GetDefaultParams(login=RrVNCwXYgTehLcKHkMBqFnSmfpGjPl))
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyE=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.callRequestCookies('Get',RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,payload=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,params=RrVNCwXYgTehLcKHkMBqFnSmfpGjyv,headers=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,cookies=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjIv=json.loads(RrVNCwXYgTehLcKHkMBqFnSmfpGjyE.text)
   if not('celllist' in RrVNCwXYgTehLcKHkMBqFnSmfpGjIv['cell_toplist']):return RrVNCwXYgTehLcKHkMBqFnSmfpGjdv,RrVNCwXYgTehLcKHkMBqFnSmfpGjiD
   RrVNCwXYgTehLcKHkMBqFnSmfpGjit=RrVNCwXYgTehLcKHkMBqFnSmfpGjIv['cell_toplist']['celllist']
   for RrVNCwXYgTehLcKHkMBqFnSmfpGjiu in RrVNCwXYgTehLcKHkMBqFnSmfpGjit:
    RrVNCwXYgTehLcKHkMBqFnSmfpGjib =RrVNCwXYgTehLcKHkMBqFnSmfpGjiu['event_list'][1]['url']
    RrVNCwXYgTehLcKHkMBqFnSmfpGjiE=urllib.parse.urlsplit(RrVNCwXYgTehLcKHkMBqFnSmfpGjib).query
    RrVNCwXYgTehLcKHkMBqFnSmfpGjiO=RrVNCwXYgTehLcKHkMBqFnSmfpGjiE[0:RrVNCwXYgTehLcKHkMBqFnSmfpGjiE.find('=')]
    RrVNCwXYgTehLcKHkMBqFnSmfpGjil=RrVNCwXYgTehLcKHkMBqFnSmfpGjiE[RrVNCwXYgTehLcKHkMBqFnSmfpGjiE.find('=')+1:]
    RrVNCwXYgTehLcKHkMBqFnSmfpGjio={'title':RrVNCwXYgTehLcKHkMBqFnSmfpGjiu['title_list'][0]['text'],'age':RrVNCwXYgTehLcKHkMBqFnSmfpGjiu['age'],'thumbnail':'https://%s'%RrVNCwXYgTehLcKHkMBqFnSmfpGjiu.get('thumbnail'),'videoid':RrVNCwXYgTehLcKHkMBqFnSmfpGjil,'vidtype':RrVNCwXYgTehLcKHkMBqFnSmfpGjiO}
    if exclusion21==RrVNCwXYgTehLcKHkMBqFnSmfpGjPl or RrVNCwXYgTehLcKHkMBqFnSmfpGjiu.get('age')!='21':
     RrVNCwXYgTehLcKHkMBqFnSmfpGjdv.append(RrVNCwXYgTehLcKHkMBqFnSmfpGjio)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjiQ=RrVNCwXYgTehLcKHkMBqFnSmfpGjWv(RrVNCwXYgTehLcKHkMBqFnSmfpGjIv['cell_toplist']['pagecount'])
   if RrVNCwXYgTehLcKHkMBqFnSmfpGjIv['cell_toplist']['count']:RrVNCwXYgTehLcKHkMBqFnSmfpGjiz =RrVNCwXYgTehLcKHkMBqFnSmfpGjWv(RrVNCwXYgTehLcKHkMBqFnSmfpGjIv['cell_toplist']['count'])
   else:RrVNCwXYgTehLcKHkMBqFnSmfpGjiz=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.LIST_LIMIT
   RrVNCwXYgTehLcKHkMBqFnSmfpGjiD=RrVNCwXYgTehLcKHkMBqFnSmfpGjiQ>RrVNCwXYgTehLcKHkMBqFnSmfpGjiz
  except RrVNCwXYgTehLcKHkMBqFnSmfpGjWI as exception:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjWd(exception)
  return RrVNCwXYgTehLcKHkMBqFnSmfpGjdv,RrVNCwXYgTehLcKHkMBqFnSmfpGjiD 
 def GetStreamingURL(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI,mode,RrVNCwXYgTehLcKHkMBqFnSmfpGjIW,quality_int,pvrmode='-'):
  RrVNCwXYgTehLcKHkMBqFnSmfpGjdt=RrVNCwXYgTehLcKHkMBqFnSmfpGjdA=RrVNCwXYgTehLcKHkMBqFnSmfpGjdQ=streaming_preview=''
  RrVNCwXYgTehLcKHkMBqFnSmfpGjdu=[]
  RrVNCwXYgTehLcKHkMBqFnSmfpGjdo='hls'
  if mode=='LIVE':
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyD =RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.API_DOMAIN+'/live/channels/'+RrVNCwXYgTehLcKHkMBqFnSmfpGjIW
   RrVNCwXYgTehLcKHkMBqFnSmfpGjdx='live'
  elif mode=='VOD':
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyD =RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.API_DOMAIN+'/cf/vod/contents/'+RrVNCwXYgTehLcKHkMBqFnSmfpGjIW
   RrVNCwXYgTehLcKHkMBqFnSmfpGjdx='vod'
  elif mode=='MOVIE':
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyD =RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.API_DOMAIN+'/cf/movie/contents/'+RrVNCwXYgTehLcKHkMBqFnSmfpGjIW
   RrVNCwXYgTehLcKHkMBqFnSmfpGjdx='movie'
  try:
   if mode!='LIVE' or pvrmode=='-':
    RrVNCwXYgTehLcKHkMBqFnSmfpGjyv=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.GetDefaultParams(login=RrVNCwXYgTehLcKHkMBqFnSmfpGjPl)
    RrVNCwXYgTehLcKHkMBqFnSmfpGjyE=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.callRequestCookies('Get',RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,payload=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,params=RrVNCwXYgTehLcKHkMBqFnSmfpGjyv,headers=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,cookies=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO)
    RrVNCwXYgTehLcKHkMBqFnSmfpGjyO=json.loads(RrVNCwXYgTehLcKHkMBqFnSmfpGjyE.text)
    RrVNCwXYgTehLcKHkMBqFnSmfpGjda=RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['qualities']['list']
    if RrVNCwXYgTehLcKHkMBqFnSmfpGjda==RrVNCwXYgTehLcKHkMBqFnSmfpGjPO:return(RrVNCwXYgTehLcKHkMBqFnSmfpGjdt,RrVNCwXYgTehLcKHkMBqFnSmfpGjdA,RrVNCwXYgTehLcKHkMBqFnSmfpGjdQ,streaming_preview)
    for RrVNCwXYgTehLcKHkMBqFnSmfpGjds in RrVNCwXYgTehLcKHkMBqFnSmfpGjda:
     RrVNCwXYgTehLcKHkMBqFnSmfpGjdu.append(RrVNCwXYgTehLcKHkMBqFnSmfpGjWv(RrVNCwXYgTehLcKHkMBqFnSmfpGjds.get('id').rstrip('p')))
    if 'type' in RrVNCwXYgTehLcKHkMBqFnSmfpGjyO:
     if RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['type']=='onair':
      RrVNCwXYgTehLcKHkMBqFnSmfpGjdx='onairvod'
    if 'drms' in RrVNCwXYgTehLcKHkMBqFnSmfpGjyO:
     if RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['drms']:
      RrVNCwXYgTehLcKHkMBqFnSmfpGjdo='dash'
  except RrVNCwXYgTehLcKHkMBqFnSmfpGjWI as exception:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjWd(exception)
   return(RrVNCwXYgTehLcKHkMBqFnSmfpGjdt,RrVNCwXYgTehLcKHkMBqFnSmfpGjdA,RrVNCwXYgTehLcKHkMBqFnSmfpGjdQ,streaming_preview)
  try:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjdJ=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.CheckQuality(quality_int,RrVNCwXYgTehLcKHkMBqFnSmfpGjdu)
   if mode=='LIVE' and pvrmode!='-':
    RrVNCwXYgTehLcKHkMBqFnSmfpGjdU='auto'
   else:
    RrVNCwXYgTehLcKHkMBqFnSmfpGjdU=RrVNCwXYgTehLcKHkMBqFnSmfpGjWi(RrVNCwXYgTehLcKHkMBqFnSmfpGjdJ)+'p'
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyD=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.API_DOMAIN+'/streaming'
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv={'contentid':RrVNCwXYgTehLcKHkMBqFnSmfpGjIW,'contenttype':RrVNCwXYgTehLcKHkMBqFnSmfpGjdx,'action':RrVNCwXYgTehLcKHkMBqFnSmfpGjdo,'quality':RrVNCwXYgTehLcKHkMBqFnSmfpGjdU,'deviceModelId':'Windows 10','guid':RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.GetGUID(guidType=2),'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n'}
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv.update(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.GetDefaultParams(login=RrVNCwXYgTehLcKHkMBqFnSmfpGjPz))
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyE=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.callRequestCookies('Get',RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,payload=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,params=RrVNCwXYgTehLcKHkMBqFnSmfpGjyv,headers=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,cookies=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyO=json.loads(RrVNCwXYgTehLcKHkMBqFnSmfpGjyE.text)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjdt=RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['playurl']
   if RrVNCwXYgTehLcKHkMBqFnSmfpGjdt==RrVNCwXYgTehLcKHkMBqFnSmfpGjPO:return(RrVNCwXYgTehLcKHkMBqFnSmfpGjdt,RrVNCwXYgTehLcKHkMBqFnSmfpGjdA,RrVNCwXYgTehLcKHkMBqFnSmfpGjdQ,streaming_preview)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjdA=RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['awscookie']
   RrVNCwXYgTehLcKHkMBqFnSmfpGjdQ =RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['drm']
   if 'previewmsg' in RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['preview']:streaming_preview=RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['preview']['previewmsg']
  except RrVNCwXYgTehLcKHkMBqFnSmfpGjWI as exception:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjWd(exception)
  return(RrVNCwXYgTehLcKHkMBqFnSmfpGjdt,RrVNCwXYgTehLcKHkMBqFnSmfpGjdA,RrVNCwXYgTehLcKHkMBqFnSmfpGjdQ,streaming_preview) 
 def GetSportsURL(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI,RrVNCwXYgTehLcKHkMBqFnSmfpGjIW,quality_int):
  RrVNCwXYgTehLcKHkMBqFnSmfpGjdt=RrVNCwXYgTehLcKHkMBqFnSmfpGjdA=''
  RrVNCwXYgTehLcKHkMBqFnSmfpGjdu=[]
  try:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyD=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.API_DOMAIN+'/streaming/other'
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv={'contentid':RrVNCwXYgTehLcKHkMBqFnSmfpGjIW,'contenttype':'live','action':'hls','quality':RrVNCwXYgTehLcKHkMBqFnSmfpGjWi(quality_int)+'p','deviceModelId':'Windows 10','guid':RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.GetGUID(guidType=2),'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n'}
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv.update(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.GetDefaultParams(login=RrVNCwXYgTehLcKHkMBqFnSmfpGjPz))
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyE=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.callRequestCookies('Get',RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,payload=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,params=RrVNCwXYgTehLcKHkMBqFnSmfpGjyv,headers=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,cookies=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyO=json.loads(RrVNCwXYgTehLcKHkMBqFnSmfpGjyE.text)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjdt=RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['playurl']
   if RrVNCwXYgTehLcKHkMBqFnSmfpGjdt==RrVNCwXYgTehLcKHkMBqFnSmfpGjPO:return(RrVNCwXYgTehLcKHkMBqFnSmfpGjdt,RrVNCwXYgTehLcKHkMBqFnSmfpGjdA)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjdA=RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['awscookie']
  except RrVNCwXYgTehLcKHkMBqFnSmfpGjWI as exception:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjWd(exception)
  return(RrVNCwXYgTehLcKHkMBqFnSmfpGjdt,RrVNCwXYgTehLcKHkMBqFnSmfpGjdA) 
 def make_viewdate(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI):
  RrVNCwXYgTehLcKHkMBqFnSmfpGjdD =RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.Get_Now_Datetime()
  RrVNCwXYgTehLcKHkMBqFnSmfpGjdb =RrVNCwXYgTehLcKHkMBqFnSmfpGjdD+datetime.timedelta(days=-1)
  RrVNCwXYgTehLcKHkMBqFnSmfpGjdE =RrVNCwXYgTehLcKHkMBqFnSmfpGjdD+datetime.timedelta(days=1)
  RrVNCwXYgTehLcKHkMBqFnSmfpGjdO=[RrVNCwXYgTehLcKHkMBqFnSmfpGjdD.strftime('%Y%m%d'),RrVNCwXYgTehLcKHkMBqFnSmfpGjdE.strftime('%Y%m%d'),]
  return RrVNCwXYgTehLcKHkMBqFnSmfpGjdO
 def Get_Sports_Gamelist(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI):
  RrVNCwXYgTehLcKHkMBqFnSmfpGjdl =RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.make_viewdate()
  RrVNCwXYgTehLcKHkMBqFnSmfpGjdz=[]
  RrVNCwXYgTehLcKHkMBqFnSmfpGjPy =[]
  for RrVNCwXYgTehLcKHkMBqFnSmfpGjPi in RrVNCwXYgTehLcKHkMBqFnSmfpGjdl:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjPI=RrVNCwXYgTehLcKHkMBqFnSmfpGjPi[:6]
   if RrVNCwXYgTehLcKHkMBqFnSmfpGjPI not in RrVNCwXYgTehLcKHkMBqFnSmfpGjdz:
    RrVNCwXYgTehLcKHkMBqFnSmfpGjdz.append(RrVNCwXYgTehLcKHkMBqFnSmfpGjPI)
  try:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyD='https://annexapi.wavve.com/skb/baseball/teammonthlycalendarlist'
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv={'IF':'IF-PORG-002','m':'getTeamCalendarListBand','response_format':'json','spo_itm_cd':'KBO','teamcd':'all','tgroup':'B','tvalue':'BC123','ver':'2.0',}
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv.update(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.GetDefaultParams(login=RrVNCwXYgTehLcKHkMBqFnSmfpGjPl))
   for RrVNCwXYgTehLcKHkMBqFnSmfpGjPd in RrVNCwXYgTehLcKHkMBqFnSmfpGjdz:
    RrVNCwXYgTehLcKHkMBqFnSmfpGjyv['date']=RrVNCwXYgTehLcKHkMBqFnSmfpGjPd
    RrVNCwXYgTehLcKHkMBqFnSmfpGjyE=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.callRequestCookies('Get',RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,payload=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,params=RrVNCwXYgTehLcKHkMBqFnSmfpGjyv,headers=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,cookies=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO)
    RrVNCwXYgTehLcKHkMBqFnSmfpGjyO=json.loads(RrVNCwXYgTehLcKHkMBqFnSmfpGjyE.text)
    RrVNCwXYgTehLcKHkMBqFnSmfpGjit=RrVNCwXYgTehLcKHkMBqFnSmfpGjyO['cell_toplist']['celllist']
    for RrVNCwXYgTehLcKHkMBqFnSmfpGjiu in RrVNCwXYgTehLcKHkMBqFnSmfpGjit:
     RrVNCwXYgTehLcKHkMBqFnSmfpGjPW=RrVNCwXYgTehLcKHkMBqFnSmfpGjiu.get('game_date')
     RrVNCwXYgTehLcKHkMBqFnSmfpGjPv =RrVNCwXYgTehLcKHkMBqFnSmfpGjiu.get('svc_id')
     if RrVNCwXYgTehLcKHkMBqFnSmfpGjPv=='':continue
     if RrVNCwXYgTehLcKHkMBqFnSmfpGjPW in RrVNCwXYgTehLcKHkMBqFnSmfpGjdl:
      RrVNCwXYgTehLcKHkMBqFnSmfpGjPt=RrVNCwXYgTehLcKHkMBqFnSmfpGjiu.get('game_status') 
      RrVNCwXYgTehLcKHkMBqFnSmfpGjPu =RrVNCwXYgTehLcKHkMBqFnSmfpGjiu.get('title_list')[0].get('text')
      RrVNCwXYgTehLcKHkMBqFnSmfpGjPW =RrVNCwXYgTehLcKHkMBqFnSmfpGjPW[:4]+'-'+RrVNCwXYgTehLcKHkMBqFnSmfpGjPW[4:6]+'-'+RrVNCwXYgTehLcKHkMBqFnSmfpGjPW[-2:]
      RrVNCwXYgTehLcKHkMBqFnSmfpGjPo =RrVNCwXYgTehLcKHkMBqFnSmfpGjiu.get('game_time')
      RrVNCwXYgTehLcKHkMBqFnSmfpGjPo =RrVNCwXYgTehLcKHkMBqFnSmfpGjPo[:2]+':'+RrVNCwXYgTehLcKHkMBqFnSmfpGjPo[-2:]
      RrVNCwXYgTehLcKHkMBqFnSmfpGjio={'game_date':RrVNCwXYgTehLcKHkMBqFnSmfpGjPW,'game_time':RrVNCwXYgTehLcKHkMBqFnSmfpGjPo,'svc_id':RrVNCwXYgTehLcKHkMBqFnSmfpGjPv,'away_team':RrVNCwXYgTehLcKHkMBqFnSmfpGjiu.get('away_team').get('team_name'),'home_team':RrVNCwXYgTehLcKHkMBqFnSmfpGjiu.get('home_team').get('team_name'),'game_status':RrVNCwXYgTehLcKHkMBqFnSmfpGjPt,'game_place':RrVNCwXYgTehLcKHkMBqFnSmfpGjiu.get('game_place'),}
      RrVNCwXYgTehLcKHkMBqFnSmfpGjPy.append(RrVNCwXYgTehLcKHkMBqFnSmfpGjio)
  except RrVNCwXYgTehLcKHkMBqFnSmfpGjWI as exception:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjWd(exception)
   return[]
  RrVNCwXYgTehLcKHkMBqFnSmfpGjPx=[]
  for i in RrVNCwXYgTehLcKHkMBqFnSmfpGjWy(2):
   for RrVNCwXYgTehLcKHkMBqFnSmfpGjiu in RrVNCwXYgTehLcKHkMBqFnSmfpGjPy:
    if i==0 and RrVNCwXYgTehLcKHkMBqFnSmfpGjiu.get('game_status')=='LIVE':
     RrVNCwXYgTehLcKHkMBqFnSmfpGjPx.append(RrVNCwXYgTehLcKHkMBqFnSmfpGjiu)
    elif i==1 and RrVNCwXYgTehLcKHkMBqFnSmfpGjiu.get('game_status')!='LIVE':
     RrVNCwXYgTehLcKHkMBqFnSmfpGjPx.append(RrVNCwXYgTehLcKHkMBqFnSmfpGjiu)
  return RrVNCwXYgTehLcKHkMBqFnSmfpGjPx
 def GetBookmarkInfo(RrVNCwXYgTehLcKHkMBqFnSmfpGjyI,RrVNCwXYgTehLcKHkMBqFnSmfpGjil,RrVNCwXYgTehLcKHkMBqFnSmfpGjiO,RrVNCwXYgTehLcKHkMBqFnSmfpGjdx):
  if RrVNCwXYgTehLcKHkMBqFnSmfpGjiO=='tvshow':
   if RrVNCwXYgTehLcKHkMBqFnSmfpGjdx=='contentid':
    RrVNCwXYgTehLcKHkMBqFnSmfpGjIW=RrVNCwXYgTehLcKHkMBqFnSmfpGjil
    RrVNCwXYgTehLcKHkMBqFnSmfpGjil =RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.ContentidToProgramid(RrVNCwXYgTehLcKHkMBqFnSmfpGjIW)
   else:
    RrVNCwXYgTehLcKHkMBqFnSmfpGjIW=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.ProgramidToContentid(RrVNCwXYgTehLcKHkMBqFnSmfpGjil)
  else:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjIW=''
  RrVNCwXYgTehLcKHkMBqFnSmfpGjPa={'indexinfo':{'ott':'wavve','videoid':RrVNCwXYgTehLcKHkMBqFnSmfpGjil,'vidtype':RrVNCwXYgTehLcKHkMBqFnSmfpGjiO,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':RrVNCwXYgTehLcKHkMBqFnSmfpGjiO,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if RrVNCwXYgTehLcKHkMBqFnSmfpGjiO=='tvshow':
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyD=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.API_DOMAIN+'/cf/vod/contents/'+RrVNCwXYgTehLcKHkMBqFnSmfpGjIW 
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.GetDefaultParams(login=RrVNCwXYgTehLcKHkMBqFnSmfpGjPl)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyE=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.callRequestCookies('Get',RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,payload=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,params=RrVNCwXYgTehLcKHkMBqFnSmfpGjyv,headers=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,cookies=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyO=json.loads(RrVNCwXYgTehLcKHkMBqFnSmfpGjyE.text)
   if not('programtitle' in RrVNCwXYgTehLcKHkMBqFnSmfpGjyO):return{}
   RrVNCwXYgTehLcKHkMBqFnSmfpGjPs=RrVNCwXYgTehLcKHkMBqFnSmfpGjyO
   RrVNCwXYgTehLcKHkMBqFnSmfpGjPJ=RrVNCwXYgTehLcKHkMBqFnSmfpGjPs.get('programtitle')
   RrVNCwXYgTehLcKHkMBqFnSmfpGjPa['saveinfo']['infoLabels']['title']=RrVNCwXYgTehLcKHkMBqFnSmfpGjPJ
   if RrVNCwXYgTehLcKHkMBqFnSmfpGjPs.get('targetage')=='18' or RrVNCwXYgTehLcKHkMBqFnSmfpGjPs.get('targetage')=='19' or RrVNCwXYgTehLcKHkMBqFnSmfpGjPs.get('targetage')=='21':
    RrVNCwXYgTehLcKHkMBqFnSmfpGjPJ +=u' (%s)'%(RrVNCwXYgTehLcKHkMBqFnSmfpGjPs.get('targetage'))
   RrVNCwXYgTehLcKHkMBqFnSmfpGjPa['saveinfo']['title'] =RrVNCwXYgTehLcKHkMBqFnSmfpGjPJ
   RrVNCwXYgTehLcKHkMBqFnSmfpGjPa['saveinfo']['infoLabels']['mpaa'] =RrVNCwXYgTehLcKHkMBqFnSmfpGjPs.get('targetage')
   RrVNCwXYgTehLcKHkMBqFnSmfpGjPa['saveinfo']['infoLabels']['plot'] =RrVNCwXYgTehLcKHkMBqFnSmfpGjPs.get('programsynopsis').replace('<br>','\n')
   RrVNCwXYgTehLcKHkMBqFnSmfpGjPa['saveinfo']['infoLabels']['studio'] =RrVNCwXYgTehLcKHkMBqFnSmfpGjPs.get('channelname')
   if RrVNCwXYgTehLcKHkMBqFnSmfpGjPs.get('firstreleaseyear')!='':RrVNCwXYgTehLcKHkMBqFnSmfpGjPa['saveinfo']['infoLabels']['year'] =RrVNCwXYgTehLcKHkMBqFnSmfpGjPs.get('firstreleaseyear')
   if RrVNCwXYgTehLcKHkMBqFnSmfpGjPs.get('firstreleasedate')!='':RrVNCwXYgTehLcKHkMBqFnSmfpGjPa['saveinfo']['infoLabels']['premiered']=RrVNCwXYgTehLcKHkMBqFnSmfpGjPs.get('firstreleasedate')
   if RrVNCwXYgTehLcKHkMBqFnSmfpGjPs.get('genretext') !='':RrVNCwXYgTehLcKHkMBqFnSmfpGjPa['saveinfo']['infoLabels']['genre'] =[RrVNCwXYgTehLcKHkMBqFnSmfpGjPs.get('genretext')]
   RrVNCwXYgTehLcKHkMBqFnSmfpGjPU=[]
   for RrVNCwXYgTehLcKHkMBqFnSmfpGjPA in RrVNCwXYgTehLcKHkMBqFnSmfpGjPs['actors']['list']:RrVNCwXYgTehLcKHkMBqFnSmfpGjPU.append(RrVNCwXYgTehLcKHkMBqFnSmfpGjPA.get('text'))
   if RrVNCwXYgTehLcKHkMBqFnSmfpGjWt(RrVNCwXYgTehLcKHkMBqFnSmfpGjPU)>0:
    if RrVNCwXYgTehLcKHkMBqFnSmfpGjPU[0]!='':RrVNCwXYgTehLcKHkMBqFnSmfpGjPa['saveinfo']['infoLabels']['cast']=RrVNCwXYgTehLcKHkMBqFnSmfpGjPU
   RrVNCwXYgTehLcKHkMBqFnSmfpGjIQ =''
   RrVNCwXYgTehLcKHkMBqFnSmfpGjID =''
   RrVNCwXYgTehLcKHkMBqFnSmfpGjIb=''
   if RrVNCwXYgTehLcKHkMBqFnSmfpGjPs.get('programposterimage')!='':RrVNCwXYgTehLcKHkMBqFnSmfpGjIQ =RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.HTTPTAG+RrVNCwXYgTehLcKHkMBqFnSmfpGjPs.get('programposterimage')
   if RrVNCwXYgTehLcKHkMBqFnSmfpGjPs.get('programimage') !='':RrVNCwXYgTehLcKHkMBqFnSmfpGjID =RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.HTTPTAG+RrVNCwXYgTehLcKHkMBqFnSmfpGjPs.get('programimage')
   if RrVNCwXYgTehLcKHkMBqFnSmfpGjPs.get('programcirlceimage')!='':RrVNCwXYgTehLcKHkMBqFnSmfpGjIb=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.HTTPTAG+RrVNCwXYgTehLcKHkMBqFnSmfpGjPs.get('programcirlceimage')
   if 'poster_default' in RrVNCwXYgTehLcKHkMBqFnSmfpGjIQ:
    RrVNCwXYgTehLcKHkMBqFnSmfpGjIQ =RrVNCwXYgTehLcKHkMBqFnSmfpGjID
    RrVNCwXYgTehLcKHkMBqFnSmfpGjIb=''
   RrVNCwXYgTehLcKHkMBqFnSmfpGjPa['saveinfo']['thumbnail']['poster']=RrVNCwXYgTehLcKHkMBqFnSmfpGjIQ
   RrVNCwXYgTehLcKHkMBqFnSmfpGjPa['saveinfo']['thumbnail']['thumb']=RrVNCwXYgTehLcKHkMBqFnSmfpGjID
   RrVNCwXYgTehLcKHkMBqFnSmfpGjPa['saveinfo']['thumbnail']['clearlogo']=RrVNCwXYgTehLcKHkMBqFnSmfpGjIb
   RrVNCwXYgTehLcKHkMBqFnSmfpGjPa['saveinfo']['thumbnail']['fanart']=RrVNCwXYgTehLcKHkMBqFnSmfpGjID
  else:
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyD=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.API_DOMAIN+'/movie/contents/'+RrVNCwXYgTehLcKHkMBqFnSmfpGjil 
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyv=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.GetDefaultParams(login=RrVNCwXYgTehLcKHkMBqFnSmfpGjPl)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyE=RrVNCwXYgTehLcKHkMBqFnSmfpGjyI.callRequestCookies('Get',RrVNCwXYgTehLcKHkMBqFnSmfpGjyD,payload=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,params=RrVNCwXYgTehLcKHkMBqFnSmfpGjyv,headers=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO,cookies=RrVNCwXYgTehLcKHkMBqFnSmfpGjPO)
   RrVNCwXYgTehLcKHkMBqFnSmfpGjyO=json.loads(RrVNCwXYgTehLcKHkMBqFnSmfpGjyE.text)
   if not('title' in RrVNCwXYgTehLcKHkMBqFnSmfpGjyO):return{}
   RrVNCwXYgTehLcKHkMBqFnSmfpGjPs=RrVNCwXYgTehLcKHkMBqFnSmfpGjyO
   RrVNCwXYgTehLcKHkMBqFnSmfpGjPJ=RrVNCwXYgTehLcKHkMBqFnSmfpGjPs.get('title')
   RrVNCwXYgTehLcKHkMBqFnSmfpGjPa['saveinfo']['infoLabels']['title']=RrVNCwXYgTehLcKHkMBqFnSmfpGjPJ
   if RrVNCwXYgTehLcKHkMBqFnSmfpGjPs.get('targetage')=='18' or RrVNCwXYgTehLcKHkMBqFnSmfpGjPs.get('targetage')=='19' or RrVNCwXYgTehLcKHkMBqFnSmfpGjPs.get('targetage')=='21':
    RrVNCwXYgTehLcKHkMBqFnSmfpGjPJ +=u' (%s)'%(RrVNCwXYgTehLcKHkMBqFnSmfpGjPs.get('targetage'))
   RrVNCwXYgTehLcKHkMBqFnSmfpGjPa['saveinfo']['title'] =RrVNCwXYgTehLcKHkMBqFnSmfpGjPJ
   RrVNCwXYgTehLcKHkMBqFnSmfpGjPa['saveinfo']['infoLabels']['mpaa'] =RrVNCwXYgTehLcKHkMBqFnSmfpGjPs.get('targetage')
   RrVNCwXYgTehLcKHkMBqFnSmfpGjPa['saveinfo']['infoLabels']['plot'] =RrVNCwXYgTehLcKHkMBqFnSmfpGjPs.get('synopsis').replace('<br>','\n')
   RrVNCwXYgTehLcKHkMBqFnSmfpGjPa['saveinfo']['infoLabels']['duration']=RrVNCwXYgTehLcKHkMBqFnSmfpGjPs.get('playtime')
   RrVNCwXYgTehLcKHkMBqFnSmfpGjPa['saveinfo']['infoLabels']['country']=RrVNCwXYgTehLcKHkMBqFnSmfpGjPs.get('country')
   RrVNCwXYgTehLcKHkMBqFnSmfpGjPa['saveinfo']['infoLabels']['studio'] =RrVNCwXYgTehLcKHkMBqFnSmfpGjPs.get('cpname')
   if RrVNCwXYgTehLcKHkMBqFnSmfpGjPs.get('releasedate')!='':
    RrVNCwXYgTehLcKHkMBqFnSmfpGjPa['saveinfo']['infoLabels']['year'] =RrVNCwXYgTehLcKHkMBqFnSmfpGjPs.get('releasedate')[:4]
    RrVNCwXYgTehLcKHkMBqFnSmfpGjPa['saveinfo']['infoLabels']['premiered']=RrVNCwXYgTehLcKHkMBqFnSmfpGjPs.get('releasedate')
   RrVNCwXYgTehLcKHkMBqFnSmfpGjPU=[]
   for RrVNCwXYgTehLcKHkMBqFnSmfpGjPA in RrVNCwXYgTehLcKHkMBqFnSmfpGjPs['actors']['list']:RrVNCwXYgTehLcKHkMBqFnSmfpGjPU.append(RrVNCwXYgTehLcKHkMBqFnSmfpGjPA.get('text'))
   if RrVNCwXYgTehLcKHkMBqFnSmfpGjWt(RrVNCwXYgTehLcKHkMBqFnSmfpGjPU)>0:
    if RrVNCwXYgTehLcKHkMBqFnSmfpGjPU[0]!='':RrVNCwXYgTehLcKHkMBqFnSmfpGjPa['saveinfo']['infoLabels']['cast']=RrVNCwXYgTehLcKHkMBqFnSmfpGjPU
   RrVNCwXYgTehLcKHkMBqFnSmfpGjPQ=[]
   for RrVNCwXYgTehLcKHkMBqFnSmfpGjPD in RrVNCwXYgTehLcKHkMBqFnSmfpGjPs['directors']['list']:RrVNCwXYgTehLcKHkMBqFnSmfpGjPQ.append(RrVNCwXYgTehLcKHkMBqFnSmfpGjPD.get('text'))
   if RrVNCwXYgTehLcKHkMBqFnSmfpGjWt(RrVNCwXYgTehLcKHkMBqFnSmfpGjPQ)>0:
    if RrVNCwXYgTehLcKHkMBqFnSmfpGjPQ[0]!='':RrVNCwXYgTehLcKHkMBqFnSmfpGjPa['saveinfo']['infoLabels']['director']=RrVNCwXYgTehLcKHkMBqFnSmfpGjPQ
   RrVNCwXYgTehLcKHkMBqFnSmfpGjiP=[]
   for RrVNCwXYgTehLcKHkMBqFnSmfpGjPb in RrVNCwXYgTehLcKHkMBqFnSmfpGjPs['genre']['list']:RrVNCwXYgTehLcKHkMBqFnSmfpGjiP.append(RrVNCwXYgTehLcKHkMBqFnSmfpGjPb.get('text'))
   if RrVNCwXYgTehLcKHkMBqFnSmfpGjWt(RrVNCwXYgTehLcKHkMBqFnSmfpGjiP)>0:
    if RrVNCwXYgTehLcKHkMBqFnSmfpGjiP[0]!='':RrVNCwXYgTehLcKHkMBqFnSmfpGjPa['saveinfo']['infoLabels']['genre']=RrVNCwXYgTehLcKHkMBqFnSmfpGjiP
   RrVNCwXYgTehLcKHkMBqFnSmfpGjIQ ='https://%s'%RrVNCwXYgTehLcKHkMBqFnSmfpGjPs['image']
   RrVNCwXYgTehLcKHkMBqFnSmfpGjPa['saveinfo']['thumbnail']['poster'] =RrVNCwXYgTehLcKHkMBqFnSmfpGjIQ
   RrVNCwXYgTehLcKHkMBqFnSmfpGjPa['saveinfo']['thumbnail']['thumb'] =RrVNCwXYgTehLcKHkMBqFnSmfpGjIQ
  return RrVNCwXYgTehLcKHkMBqFnSmfpGjPa
# Created by pyminifier (https://github.com/liftoff/pyminifier)
