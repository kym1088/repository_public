__author__="NightRain"
WLxgMbUFSYhRTCGDzmuHlVBfecvoEp=object
WLxgMbUFSYhRTCGDzmuHlVBfecvoEy=None
WLxgMbUFSYhRTCGDzmuHlVBfecvoEa=True
WLxgMbUFSYhRTCGDzmuHlVBfecvoEd=False
WLxgMbUFSYhRTCGDzmuHlVBfecvoEX=int
WLxgMbUFSYhRTCGDzmuHlVBfecvoEO=type
WLxgMbUFSYhRTCGDzmuHlVBfecvoEA=dict
WLxgMbUFSYhRTCGDzmuHlVBfecvoEK=len
WLxgMbUFSYhRTCGDzmuHlVBfecvoEq=range
WLxgMbUFSYhRTCGDzmuHlVBfecvoEJ=str
WLxgMbUFSYhRTCGDzmuHlVBfecvoEP=open
WLxgMbUFSYhRTCGDzmuHlVBfecvoEN=Exception
WLxgMbUFSYhRTCGDzmuHlVBfecvonI=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
WLxgMbUFSYhRTCGDzmuHlVBfecvoIw=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://www.wavve.com/supermultisection/GN51','icon':'home.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&offset=0&limit=20&uicode=VN500','page':'1','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=01&WeekDay=all&uitype=VN4&uiparent=FN0&uirank=0&broadcastid=847243&uicode=VN4','page':'1','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=02&WeekDay=all&uitype=VN3&uiparent=FN0&uirank=0&broadcastid=783664&uicode=VN3','page':'1','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'1','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'paid','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'displaystart','ordernm':'업데이트순','icon':''},{'title':'프로야구 - 경기중 시청가능','mode':'GAME_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'(웨이브) 검색','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'(웨이브) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
WLxgMbUFSYhRTCGDzmuHlVBfecvoIs=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
WLxgMbUFSYhRTCGDzmuHlVBfecvoIr=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
WLxgMbUFSYhRTCGDzmuHlVBfecvoIt =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
WLxgMbUFSYhRTCGDzmuHlVBfecvoIE=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_searched.txt'))
from wavveCore import*
class WLxgMbUFSYhRTCGDzmuHlVBfecvoIi(WLxgMbUFSYhRTCGDzmuHlVBfecvoEp):
 def __init__(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn,WLxgMbUFSYhRTCGDzmuHlVBfecvoIj,WLxgMbUFSYhRTCGDzmuHlVBfecvoIk,WLxgMbUFSYhRTCGDzmuHlVBfecvoIQ):
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIn._addon_url =WLxgMbUFSYhRTCGDzmuHlVBfecvoIj
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIn._addon_handle=WLxgMbUFSYhRTCGDzmuHlVBfecvoIk
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.main_params =WLxgMbUFSYhRTCGDzmuHlVBfecvoIQ
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj =RrVNCwXYgTehLcKHkMBqFnSmfpGjyi() 
 def addon_noti(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn,sting):
  try:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIy=xbmcgui.Dialog()
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIy.notification(__addonname__,sting)
  except:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoEy
 def addon_log(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn,string):
  try:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIa=string.encode('utf-8','ignore')
  except:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIa='addonException: addon_log'
  WLxgMbUFSYhRTCGDzmuHlVBfecvoId=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,WLxgMbUFSYhRTCGDzmuHlVBfecvoIa),level=WLxgMbUFSYhRTCGDzmuHlVBfecvoId)
 def get_keyboard_input(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn,WLxgMbUFSYhRTCGDzmuHlVBfecvoij):
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIX=WLxgMbUFSYhRTCGDzmuHlVBfecvoEy
  kb=xbmc.Keyboard()
  kb.setHeading(WLxgMbUFSYhRTCGDzmuHlVBfecvoij)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIX=kb.getText()
  return WLxgMbUFSYhRTCGDzmuHlVBfecvoIX
 def get_settings_login_info(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn):
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIO =__addon__.getSetting('id')
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIA =__addon__.getSetting('pw')
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIK=__addon__.getSetting('selected_profile')
  return(WLxgMbUFSYhRTCGDzmuHlVBfecvoIO,WLxgMbUFSYhRTCGDzmuHlVBfecvoIA,WLxgMbUFSYhRTCGDzmuHlVBfecvoIK)
 def get_settings_totalsearch(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn):
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIq =WLxgMbUFSYhRTCGDzmuHlVBfecvoEa if __addon__.getSetting('local_search')=='true' else WLxgMbUFSYhRTCGDzmuHlVBfecvoEd
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIJ=WLxgMbUFSYhRTCGDzmuHlVBfecvoEa if __addon__.getSetting('local_history')=='true' else WLxgMbUFSYhRTCGDzmuHlVBfecvoEd
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIP =WLxgMbUFSYhRTCGDzmuHlVBfecvoEa if __addon__.getSetting('total_search')=='true' else WLxgMbUFSYhRTCGDzmuHlVBfecvoEd
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIN=WLxgMbUFSYhRTCGDzmuHlVBfecvoEa if __addon__.getSetting('total_history')=='true' else WLxgMbUFSYhRTCGDzmuHlVBfecvoEd
  WLxgMbUFSYhRTCGDzmuHlVBfecvoiI=WLxgMbUFSYhRTCGDzmuHlVBfecvoEa if __addon__.getSetting('menu_bookmark')=='true' else WLxgMbUFSYhRTCGDzmuHlVBfecvoEd
  return(WLxgMbUFSYhRTCGDzmuHlVBfecvoIq,WLxgMbUFSYhRTCGDzmuHlVBfecvoIJ,WLxgMbUFSYhRTCGDzmuHlVBfecvoIP,WLxgMbUFSYhRTCGDzmuHlVBfecvoIN,WLxgMbUFSYhRTCGDzmuHlVBfecvoiI)
 def get_settings_makebookmark(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn):
  return WLxgMbUFSYhRTCGDzmuHlVBfecvoEa if __addon__.getSetting('make_bookmark')=='true' else WLxgMbUFSYhRTCGDzmuHlVBfecvoEd
 def get_selQuality(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn):
  try:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiw=[1080,720,480,360]
   WLxgMbUFSYhRTCGDzmuHlVBfecvois=WLxgMbUFSYhRTCGDzmuHlVBfecvoEX(__addon__.getSetting('selected_quality'))
   return WLxgMbUFSYhRTCGDzmuHlVBfecvoiw[WLxgMbUFSYhRTCGDzmuHlVBfecvois]
  except:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoEy
  return 1080 
 def get_settings_exclusion21(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn):
  WLxgMbUFSYhRTCGDzmuHlVBfecvoir =__addon__.getSetting('exclusion21')
  if WLxgMbUFSYhRTCGDzmuHlVBfecvoir=='false':
   return WLxgMbUFSYhRTCGDzmuHlVBfecvoEd
  else:
   return WLxgMbUFSYhRTCGDzmuHlVBfecvoEa
 def get_settings_direct_replay(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn):
  WLxgMbUFSYhRTCGDzmuHlVBfecvoit=WLxgMbUFSYhRTCGDzmuHlVBfecvoEX(__addon__.getSetting('direct_replay'))
  if WLxgMbUFSYhRTCGDzmuHlVBfecvoit==0:
   return WLxgMbUFSYhRTCGDzmuHlVBfecvoEd
  else:
   return WLxgMbUFSYhRTCGDzmuHlVBfecvoEa
 def set_winCredential(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn,credential):
  WLxgMbUFSYhRTCGDzmuHlVBfecvoiE=xbmcgui.Window(10000)
  WLxgMbUFSYhRTCGDzmuHlVBfecvoiE.setProperty('WAVVE_M_CREDENTIAL',credential)
  WLxgMbUFSYhRTCGDzmuHlVBfecvoiE.setProperty('WAVVE_M_LOGINTIME',WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn):
  WLxgMbUFSYhRTCGDzmuHlVBfecvoiE=xbmcgui.Window(10000)
  return WLxgMbUFSYhRTCGDzmuHlVBfecvoiE.getProperty('WAVVE_M_CREDENTIAL')
 def set_winEpisodeOrderby(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn,WLxgMbUFSYhRTCGDzmuHlVBfecvori):
  WLxgMbUFSYhRTCGDzmuHlVBfecvoiE=xbmcgui.Window(10000)
  WLxgMbUFSYhRTCGDzmuHlVBfecvoiE.setProperty('WAVVE_M_ORDERBY',WLxgMbUFSYhRTCGDzmuHlVBfecvori)
 def get_winEpisodeOrderby(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn):
  WLxgMbUFSYhRTCGDzmuHlVBfecvoiE=xbmcgui.Window(10000)
  return WLxgMbUFSYhRTCGDzmuHlVBfecvoiE.getProperty('WAVVE_M_ORDERBY')
 def add_dir(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn,label,sublabel='',img='',infoLabels=WLxgMbUFSYhRTCGDzmuHlVBfecvoEy,isFolder=WLxgMbUFSYhRTCGDzmuHlVBfecvoEa,params='',isLink=WLxgMbUFSYhRTCGDzmuHlVBfecvoEd,ContextMenu=WLxgMbUFSYhRTCGDzmuHlVBfecvoEy):
  WLxgMbUFSYhRTCGDzmuHlVBfecvoin='%s?%s'%(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn._addon_url,urllib.parse.urlencode(params))
  if sublabel:WLxgMbUFSYhRTCGDzmuHlVBfecvoij='%s < %s >'%(label,sublabel)
  else: WLxgMbUFSYhRTCGDzmuHlVBfecvoij=label
  if not img:img='DefaultFolder.png'
  WLxgMbUFSYhRTCGDzmuHlVBfecvoik=xbmcgui.ListItem(WLxgMbUFSYhRTCGDzmuHlVBfecvoij)
  if WLxgMbUFSYhRTCGDzmuHlVBfecvoEO(img)==WLxgMbUFSYhRTCGDzmuHlVBfecvoEA:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoik.setArt(img)
  else:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoik.setArt({'thumb':img,'poster':img})
  if infoLabels:WLxgMbUFSYhRTCGDzmuHlVBfecvoik.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoik.setProperty('IsPlayable','true')
  if ContextMenu:WLxgMbUFSYhRTCGDzmuHlVBfecvoik.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn._addon_handle,WLxgMbUFSYhRTCGDzmuHlVBfecvoin,WLxgMbUFSYhRTCGDzmuHlVBfecvoik,isFolder)
 def dp_Main_List(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn):
  (WLxgMbUFSYhRTCGDzmuHlVBfecvoIq,WLxgMbUFSYhRTCGDzmuHlVBfecvoIJ,WLxgMbUFSYhRTCGDzmuHlVBfecvoIP,WLxgMbUFSYhRTCGDzmuHlVBfecvoIN,WLxgMbUFSYhRTCGDzmuHlVBfecvoiI)=WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.get_settings_totalsearch()
  for WLxgMbUFSYhRTCGDzmuHlVBfecvoiQ in WLxgMbUFSYhRTCGDzmuHlVBfecvoIw:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoij=WLxgMbUFSYhRTCGDzmuHlVBfecvoiQ.get('title')
   WLxgMbUFSYhRTCGDzmuHlVBfecvoip=''
   if WLxgMbUFSYhRTCGDzmuHlVBfecvoiQ.get('mode')=='SEARCH_GROUP' and WLxgMbUFSYhRTCGDzmuHlVBfecvoIq ==WLxgMbUFSYhRTCGDzmuHlVBfecvoEd:continue
   elif WLxgMbUFSYhRTCGDzmuHlVBfecvoiQ.get('mode')=='SEARCH_HISTORY' and WLxgMbUFSYhRTCGDzmuHlVBfecvoIJ==WLxgMbUFSYhRTCGDzmuHlVBfecvoEd:continue
   elif WLxgMbUFSYhRTCGDzmuHlVBfecvoiQ.get('mode')=='TOTAL_SEARCH' and WLxgMbUFSYhRTCGDzmuHlVBfecvoIP ==WLxgMbUFSYhRTCGDzmuHlVBfecvoEd:continue
   elif WLxgMbUFSYhRTCGDzmuHlVBfecvoiQ.get('mode')=='TOTAL_HISTORY' and WLxgMbUFSYhRTCGDzmuHlVBfecvoIN==WLxgMbUFSYhRTCGDzmuHlVBfecvoEd:continue
   elif WLxgMbUFSYhRTCGDzmuHlVBfecvoiQ.get('mode')=='MENU_BOOKMARK' and WLxgMbUFSYhRTCGDzmuHlVBfecvoiI==WLxgMbUFSYhRTCGDzmuHlVBfecvoEd:continue
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy={'mode':WLxgMbUFSYhRTCGDzmuHlVBfecvoiQ.get('mode'),'sCode':WLxgMbUFSYhRTCGDzmuHlVBfecvoiQ.get('sCode'),'sIndex':WLxgMbUFSYhRTCGDzmuHlVBfecvoiQ.get('sIndex'),'sType':WLxgMbUFSYhRTCGDzmuHlVBfecvoiQ.get('sType'),'suburl':WLxgMbUFSYhRTCGDzmuHlVBfecvoiQ.get('suburl'),'subapi':WLxgMbUFSYhRTCGDzmuHlVBfecvoiQ.get('subapi'),'page':WLxgMbUFSYhRTCGDzmuHlVBfecvoiQ.get('page'),'orderby':WLxgMbUFSYhRTCGDzmuHlVBfecvoiQ.get('orderby'),'ordernm':WLxgMbUFSYhRTCGDzmuHlVBfecvoiQ.get('ordernm')}
   if WLxgMbUFSYhRTCGDzmuHlVBfecvoiQ.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    WLxgMbUFSYhRTCGDzmuHlVBfecvoia=WLxgMbUFSYhRTCGDzmuHlVBfecvoEd
    WLxgMbUFSYhRTCGDzmuHlVBfecvoid =WLxgMbUFSYhRTCGDzmuHlVBfecvoEa
   else:
    WLxgMbUFSYhRTCGDzmuHlVBfecvoia=WLxgMbUFSYhRTCGDzmuHlVBfecvoEa
    WLxgMbUFSYhRTCGDzmuHlVBfecvoid =WLxgMbUFSYhRTCGDzmuHlVBfecvoEd
   if 'icon' in WLxgMbUFSYhRTCGDzmuHlVBfecvoiQ:WLxgMbUFSYhRTCGDzmuHlVBfecvoip=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',WLxgMbUFSYhRTCGDzmuHlVBfecvoiQ.get('icon')) 
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.add_dir(WLxgMbUFSYhRTCGDzmuHlVBfecvoij,sublabel='',img=WLxgMbUFSYhRTCGDzmuHlVBfecvoip,infoLabels=WLxgMbUFSYhRTCGDzmuHlVBfecvoEy,isFolder=WLxgMbUFSYhRTCGDzmuHlVBfecvoia,params=WLxgMbUFSYhRTCGDzmuHlVBfecvoiy,isLink=WLxgMbUFSYhRTCGDzmuHlVBfecvoid)
  xbmcplugin.endOfDirectory(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn._addon_handle,cacheToDisc=WLxgMbUFSYhRTCGDzmuHlVBfecvoEa)
 def dp_Search_Group(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn,args):
  if 'search_key' in args:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiA=args.get('search_key')
  else:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiA=WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not WLxgMbUFSYhRTCGDzmuHlVBfecvoiA:
    return
  for WLxgMbUFSYhRTCGDzmuHlVBfecvoiK in WLxgMbUFSYhRTCGDzmuHlVBfecvoIs:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiq =WLxgMbUFSYhRTCGDzmuHlVBfecvoiK.get('mode')
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiJ=WLxgMbUFSYhRTCGDzmuHlVBfecvoiK.get('sType')
   WLxgMbUFSYhRTCGDzmuHlVBfecvoij=WLxgMbUFSYhRTCGDzmuHlVBfecvoiK.get('title')
   (WLxgMbUFSYhRTCGDzmuHlVBfecvoiP,WLxgMbUFSYhRTCGDzmuHlVBfecvoiN)=WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.Get_Search_List(WLxgMbUFSYhRTCGDzmuHlVBfecvoiA,WLxgMbUFSYhRTCGDzmuHlVBfecvoiJ,1,exclusion21=WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.get_settings_exclusion21())
   WLxgMbUFSYhRTCGDzmuHlVBfecvowI={'plot':'검색어 : '+WLxgMbUFSYhRTCGDzmuHlVBfecvoiA+'\n\n'+WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.Search_FreeList(WLxgMbUFSYhRTCGDzmuHlVBfecvoiP)}
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy={'mode':WLxgMbUFSYhRTCGDzmuHlVBfecvoiq,'sType':WLxgMbUFSYhRTCGDzmuHlVBfecvoiJ,'search_key':WLxgMbUFSYhRTCGDzmuHlVBfecvoiA,'page':'1',}
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.add_dir(WLxgMbUFSYhRTCGDzmuHlVBfecvoij,sublabel='',img='',infoLabels=WLxgMbUFSYhRTCGDzmuHlVBfecvowI,isFolder=WLxgMbUFSYhRTCGDzmuHlVBfecvoEa,params=WLxgMbUFSYhRTCGDzmuHlVBfecvoiy)
  if WLxgMbUFSYhRTCGDzmuHlVBfecvoEK(WLxgMbUFSYhRTCGDzmuHlVBfecvoIs)>0:xbmcplugin.endOfDirectory(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn._addon_handle,cacheToDisc=WLxgMbUFSYhRTCGDzmuHlVBfecvoEa)
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.Save_Searched_List(WLxgMbUFSYhRTCGDzmuHlVBfecvoiA)
 def Search_FreeList(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn,search_list):
  WLxgMbUFSYhRTCGDzmuHlVBfecvowi=''
  WLxgMbUFSYhRTCGDzmuHlVBfecvows=7
  try:
   if WLxgMbUFSYhRTCGDzmuHlVBfecvoEK(search_list)==0:return '검색결과 없음'
   for i in WLxgMbUFSYhRTCGDzmuHlVBfecvoEq(WLxgMbUFSYhRTCGDzmuHlVBfecvoEK(search_list)):
    if i>=WLxgMbUFSYhRTCGDzmuHlVBfecvows:
     WLxgMbUFSYhRTCGDzmuHlVBfecvowi=WLxgMbUFSYhRTCGDzmuHlVBfecvowi+'...'
     break
    WLxgMbUFSYhRTCGDzmuHlVBfecvowi=WLxgMbUFSYhRTCGDzmuHlVBfecvowi+search_list[i]['title']+'\n'
  except:
   return ''
  return WLxgMbUFSYhRTCGDzmuHlVBfecvowi
 def dp_Watch_Group(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn,args):
  for WLxgMbUFSYhRTCGDzmuHlVBfecvowr in WLxgMbUFSYhRTCGDzmuHlVBfecvoIr:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoij=WLxgMbUFSYhRTCGDzmuHlVBfecvowr.get('title')
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy={'mode':WLxgMbUFSYhRTCGDzmuHlVBfecvowr.get('mode'),'sType':WLxgMbUFSYhRTCGDzmuHlVBfecvowr.get('sType')}
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.add_dir(WLxgMbUFSYhRTCGDzmuHlVBfecvoij,sublabel='',img='',infoLabels=WLxgMbUFSYhRTCGDzmuHlVBfecvoEy,isFolder=WLxgMbUFSYhRTCGDzmuHlVBfecvoEa,params=WLxgMbUFSYhRTCGDzmuHlVBfecvoiy)
  if WLxgMbUFSYhRTCGDzmuHlVBfecvoEK(WLxgMbUFSYhRTCGDzmuHlVBfecvoIr)>0:xbmcplugin.endOfDirectory(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn._addon_handle,cacheToDisc=WLxgMbUFSYhRTCGDzmuHlVBfecvoEa)
 def dp_Search_History(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn,args):
  WLxgMbUFSYhRTCGDzmuHlVBfecvowt=WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.Load_List_File('search')
  for WLxgMbUFSYhRTCGDzmuHlVBfecvowE in WLxgMbUFSYhRTCGDzmuHlVBfecvowt:
   WLxgMbUFSYhRTCGDzmuHlVBfecvown=WLxgMbUFSYhRTCGDzmuHlVBfecvoEA(urllib.parse.parse_qsl(WLxgMbUFSYhRTCGDzmuHlVBfecvowE))
   WLxgMbUFSYhRTCGDzmuHlVBfecvowj=WLxgMbUFSYhRTCGDzmuHlVBfecvown.get('skey').strip()
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy={'mode':'SEARCH_GROUP','search_key':WLxgMbUFSYhRTCGDzmuHlVBfecvowj,}
   WLxgMbUFSYhRTCGDzmuHlVBfecvowk={'mode':'SEARCH_REMOVE','sType':'ONE','skey':WLxgMbUFSYhRTCGDzmuHlVBfecvowj,}
   WLxgMbUFSYhRTCGDzmuHlVBfecvowQ=urllib.parse.urlencode(WLxgMbUFSYhRTCGDzmuHlVBfecvowk)
   WLxgMbUFSYhRTCGDzmuHlVBfecvowp=[('선택된 검색어 ( %s ) 삭제'%(WLxgMbUFSYhRTCGDzmuHlVBfecvowj),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(WLxgMbUFSYhRTCGDzmuHlVBfecvowQ))]
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.add_dir(WLxgMbUFSYhRTCGDzmuHlVBfecvowj,sublabel='',img=WLxgMbUFSYhRTCGDzmuHlVBfecvoEy,infoLabels=WLxgMbUFSYhRTCGDzmuHlVBfecvoEy,isFolder=WLxgMbUFSYhRTCGDzmuHlVBfecvoEa,params=WLxgMbUFSYhRTCGDzmuHlVBfecvoiy,ContextMenu=WLxgMbUFSYhRTCGDzmuHlVBfecvowp)
  WLxgMbUFSYhRTCGDzmuHlVBfecvowy={'plot':'검색목록 전체를 삭제합니다.'}
  WLxgMbUFSYhRTCGDzmuHlVBfecvoij='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  WLxgMbUFSYhRTCGDzmuHlVBfecvoiy={'mode':'SEARCH_REMOVE','sType':'ALL','skey':'-',}
  WLxgMbUFSYhRTCGDzmuHlVBfecvoip=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.add_dir(WLxgMbUFSYhRTCGDzmuHlVBfecvoij,sublabel='',img=WLxgMbUFSYhRTCGDzmuHlVBfecvoip,infoLabels=WLxgMbUFSYhRTCGDzmuHlVBfecvowy,isFolder=WLxgMbUFSYhRTCGDzmuHlVBfecvoEd,params=WLxgMbUFSYhRTCGDzmuHlVBfecvoiy,isLink=WLxgMbUFSYhRTCGDzmuHlVBfecvoEa)
  xbmcplugin.endOfDirectory(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn._addon_handle,cacheToDisc=WLxgMbUFSYhRTCGDzmuHlVBfecvoEd)
 def dp_Search_List(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn,args):
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.SaveCredential(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.get_winCredential())
  WLxgMbUFSYhRTCGDzmuHlVBfecvoiJ =args.get('sType')
  WLxgMbUFSYhRTCGDzmuHlVBfecvowa =WLxgMbUFSYhRTCGDzmuHlVBfecvoEX(args.get('page'))
  if 'search_key' in args:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiA=args.get('search_key')
  else:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiA=WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not WLxgMbUFSYhRTCGDzmuHlVBfecvoiA:
    xbmcplugin.endOfDirectory(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn._addon_handle)
    return
  WLxgMbUFSYhRTCGDzmuHlVBfecvowd,WLxgMbUFSYhRTCGDzmuHlVBfecvoiN=WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.Get_Search_List(WLxgMbUFSYhRTCGDzmuHlVBfecvoiA,WLxgMbUFSYhRTCGDzmuHlVBfecvoiJ,WLxgMbUFSYhRTCGDzmuHlVBfecvowa,exclusion21=WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.get_settings_exclusion21())
  for WLxgMbUFSYhRTCGDzmuHlVBfecvowX in WLxgMbUFSYhRTCGDzmuHlVBfecvowd:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoij =WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('title')
   WLxgMbUFSYhRTCGDzmuHlVBfecvowO=WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('thumbnail')
   WLxgMbUFSYhRTCGDzmuHlVBfecvowA =WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('age')
   if WLxgMbUFSYhRTCGDzmuHlVBfecvowA=='18' or WLxgMbUFSYhRTCGDzmuHlVBfecvowA=='19' or WLxgMbUFSYhRTCGDzmuHlVBfecvowA=='21':WLxgMbUFSYhRTCGDzmuHlVBfecvoij+=' (%s)'%(WLxgMbUFSYhRTCGDzmuHlVBfecvowA)
   WLxgMbUFSYhRTCGDzmuHlVBfecvowy={'mediatype':'tvshow' if WLxgMbUFSYhRTCGDzmuHlVBfecvoiJ=='vod' else 'movie','mpaa':WLxgMbUFSYhRTCGDzmuHlVBfecvowA,'title':WLxgMbUFSYhRTCGDzmuHlVBfecvoij,'plot':WLxgMbUFSYhRTCGDzmuHlVBfecvoij}
   if WLxgMbUFSYhRTCGDzmuHlVBfecvoiJ=='vod':
    WLxgMbUFSYhRTCGDzmuHlVBfecvoiy={'mode':'EPISODE_LIST','videoid':WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('videoid'),'vidtype':WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('vidtype'),'page':'1'}
    WLxgMbUFSYhRTCGDzmuHlVBfecvoia=WLxgMbUFSYhRTCGDzmuHlVBfecvoEa
   else:
    WLxgMbUFSYhRTCGDzmuHlVBfecvoiy={'mode':'MOVIE','contentid':WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('videoid'),'title':WLxgMbUFSYhRTCGDzmuHlVBfecvoij,'thumbnail':WLxgMbUFSYhRTCGDzmuHlVBfecvowO,'age':WLxgMbUFSYhRTCGDzmuHlVBfecvowA}
    WLxgMbUFSYhRTCGDzmuHlVBfecvoia=WLxgMbUFSYhRTCGDzmuHlVBfecvoEd
   if WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.get_settings_makebookmark():
    WLxgMbUFSYhRTCGDzmuHlVBfecvowK={'videoid':WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('videoid'),'vidtype':'tvshow' if WLxgMbUFSYhRTCGDzmuHlVBfecvoiJ=='vod' else 'movie','vtitle':WLxgMbUFSYhRTCGDzmuHlVBfecvoij,'vsubtitle':'','contenttype':WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('vidtype'),}
    WLxgMbUFSYhRTCGDzmuHlVBfecvowq=json.dumps(WLxgMbUFSYhRTCGDzmuHlVBfecvowK)
    WLxgMbUFSYhRTCGDzmuHlVBfecvowq=urllib.parse.quote(WLxgMbUFSYhRTCGDzmuHlVBfecvowq)
    WLxgMbUFSYhRTCGDzmuHlVBfecvowJ='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(WLxgMbUFSYhRTCGDzmuHlVBfecvowq)
    WLxgMbUFSYhRTCGDzmuHlVBfecvowp=[('(통합) 찜 영상에 추가',WLxgMbUFSYhRTCGDzmuHlVBfecvowJ)]
   else:
    WLxgMbUFSYhRTCGDzmuHlVBfecvowp=WLxgMbUFSYhRTCGDzmuHlVBfecvoEy
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.add_dir(WLxgMbUFSYhRTCGDzmuHlVBfecvoij,sublabel='',img=WLxgMbUFSYhRTCGDzmuHlVBfecvowO,infoLabels=WLxgMbUFSYhRTCGDzmuHlVBfecvowy,isFolder=WLxgMbUFSYhRTCGDzmuHlVBfecvoia,params=WLxgMbUFSYhRTCGDzmuHlVBfecvoiy,ContextMenu=WLxgMbUFSYhRTCGDzmuHlVBfecvowp)
  if WLxgMbUFSYhRTCGDzmuHlVBfecvoiN:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy['mode'] ='SEARCH_LIST' 
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy['sType']=WLxgMbUFSYhRTCGDzmuHlVBfecvoiJ 
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy['page'] =WLxgMbUFSYhRTCGDzmuHlVBfecvoEJ(WLxgMbUFSYhRTCGDzmuHlVBfecvowa+1)
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy['search_key']=WLxgMbUFSYhRTCGDzmuHlVBfecvoiA
   WLxgMbUFSYhRTCGDzmuHlVBfecvoij='[B]%s >>[/B]'%'다음 페이지'
   WLxgMbUFSYhRTCGDzmuHlVBfecvowP=WLxgMbUFSYhRTCGDzmuHlVBfecvoEJ(WLxgMbUFSYhRTCGDzmuHlVBfecvowa+1)
   WLxgMbUFSYhRTCGDzmuHlVBfecvoip=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.add_dir(WLxgMbUFSYhRTCGDzmuHlVBfecvoij,sublabel=WLxgMbUFSYhRTCGDzmuHlVBfecvowP,img=WLxgMbUFSYhRTCGDzmuHlVBfecvoip,infoLabels=WLxgMbUFSYhRTCGDzmuHlVBfecvoEy,isFolder=WLxgMbUFSYhRTCGDzmuHlVBfecvoEa,params=WLxgMbUFSYhRTCGDzmuHlVBfecvoiy)
  if WLxgMbUFSYhRTCGDzmuHlVBfecvoiJ=='movie':xbmcplugin.setContent(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn._addon_handle,'movies')
  else:xbmcplugin.setContent(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn._addon_handle,cacheToDisc=WLxgMbUFSYhRTCGDzmuHlVBfecvoEd)
 def dp_Watch_List(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn,args):
  WLxgMbUFSYhRTCGDzmuHlVBfecvoiJ =args.get('sType')
  WLxgMbUFSYhRTCGDzmuHlVBfecvoit=WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.get_settings_direct_replay()
  WLxgMbUFSYhRTCGDzmuHlVBfecvowd=WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.Load_List_File(WLxgMbUFSYhRTCGDzmuHlVBfecvoiJ)
  for WLxgMbUFSYhRTCGDzmuHlVBfecvowX in WLxgMbUFSYhRTCGDzmuHlVBfecvowd:
   WLxgMbUFSYhRTCGDzmuHlVBfecvown=WLxgMbUFSYhRTCGDzmuHlVBfecvoEA(urllib.parse.parse_qsl(WLxgMbUFSYhRTCGDzmuHlVBfecvowX))
   WLxgMbUFSYhRTCGDzmuHlVBfecvowN =WLxgMbUFSYhRTCGDzmuHlVBfecvown.get('code').strip()
   WLxgMbUFSYhRTCGDzmuHlVBfecvoij =WLxgMbUFSYhRTCGDzmuHlVBfecvown.get('title').strip()
   WLxgMbUFSYhRTCGDzmuHlVBfecvowP =WLxgMbUFSYhRTCGDzmuHlVBfecvown.get('subtitle').strip()
   if WLxgMbUFSYhRTCGDzmuHlVBfecvowP=='None':WLxgMbUFSYhRTCGDzmuHlVBfecvowP=''
   WLxgMbUFSYhRTCGDzmuHlVBfecvowO=WLxgMbUFSYhRTCGDzmuHlVBfecvown.get('img').strip()
   WLxgMbUFSYhRTCGDzmuHlVBfecvosI =WLxgMbUFSYhRTCGDzmuHlVBfecvown.get('videoid').strip()
   try:
    WLxgMbUFSYhRTCGDzmuHlVBfecvowO=WLxgMbUFSYhRTCGDzmuHlVBfecvowO.replace('\'','\"')
    WLxgMbUFSYhRTCGDzmuHlVBfecvowO=json.loads(WLxgMbUFSYhRTCGDzmuHlVBfecvowO)
   except:
    WLxgMbUFSYhRTCGDzmuHlVBfecvoEy
   WLxgMbUFSYhRTCGDzmuHlVBfecvowy={'plot':'%s\n%s'%(WLxgMbUFSYhRTCGDzmuHlVBfecvoij,WLxgMbUFSYhRTCGDzmuHlVBfecvowP)}
   if WLxgMbUFSYhRTCGDzmuHlVBfecvoiJ=='vod':
    if WLxgMbUFSYhRTCGDzmuHlVBfecvoit==WLxgMbUFSYhRTCGDzmuHlVBfecvoEd or WLxgMbUFSYhRTCGDzmuHlVBfecvosI==WLxgMbUFSYhRTCGDzmuHlVBfecvoEy:
     WLxgMbUFSYhRTCGDzmuHlVBfecvoiy={'mode':'EPISODE_LIST','videoid':WLxgMbUFSYhRTCGDzmuHlVBfecvowN,'vidtype':'programid','page':'1'}
     WLxgMbUFSYhRTCGDzmuHlVBfecvoia=WLxgMbUFSYhRTCGDzmuHlVBfecvoEa
    else:
     WLxgMbUFSYhRTCGDzmuHlVBfecvoiy={'mode':'VOD','programid':WLxgMbUFSYhRTCGDzmuHlVBfecvowN,'contentid':WLxgMbUFSYhRTCGDzmuHlVBfecvosI,'title':WLxgMbUFSYhRTCGDzmuHlVBfecvoij,'subtitle':WLxgMbUFSYhRTCGDzmuHlVBfecvowP,'thumbnail':WLxgMbUFSYhRTCGDzmuHlVBfecvowO}
     WLxgMbUFSYhRTCGDzmuHlVBfecvoia=WLxgMbUFSYhRTCGDzmuHlVBfecvoEd
   else:
    WLxgMbUFSYhRTCGDzmuHlVBfecvoiy={'mode':'MOVIE','contentid':WLxgMbUFSYhRTCGDzmuHlVBfecvowN,'title':WLxgMbUFSYhRTCGDzmuHlVBfecvoij,'subtitle':WLxgMbUFSYhRTCGDzmuHlVBfecvowP,'thumbnail':WLxgMbUFSYhRTCGDzmuHlVBfecvowO}
    WLxgMbUFSYhRTCGDzmuHlVBfecvoia=WLxgMbUFSYhRTCGDzmuHlVBfecvoEd
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.add_dir(WLxgMbUFSYhRTCGDzmuHlVBfecvoij,sublabel=WLxgMbUFSYhRTCGDzmuHlVBfecvowP,img=WLxgMbUFSYhRTCGDzmuHlVBfecvowO,infoLabels=WLxgMbUFSYhRTCGDzmuHlVBfecvowy,isFolder=WLxgMbUFSYhRTCGDzmuHlVBfecvoia,params=WLxgMbUFSYhRTCGDzmuHlVBfecvoiy)
  WLxgMbUFSYhRTCGDzmuHlVBfecvowy={'plot':'시청목록을 삭제합니다.'}
  WLxgMbUFSYhRTCGDzmuHlVBfecvoij='*** 시청목록 삭제 ***'
  WLxgMbUFSYhRTCGDzmuHlVBfecvoiy={'mode':'MYVIEW_REMOVE','sType':WLxgMbUFSYhRTCGDzmuHlVBfecvoiJ,'skey':'-',}
  WLxgMbUFSYhRTCGDzmuHlVBfecvoip=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.add_dir(WLxgMbUFSYhRTCGDzmuHlVBfecvoij,sublabel='',img=WLxgMbUFSYhRTCGDzmuHlVBfecvoip,infoLabels=WLxgMbUFSYhRTCGDzmuHlVBfecvowy,isFolder=WLxgMbUFSYhRTCGDzmuHlVBfecvoEd,params=WLxgMbUFSYhRTCGDzmuHlVBfecvoiy,isLink=WLxgMbUFSYhRTCGDzmuHlVBfecvoEa)
  if WLxgMbUFSYhRTCGDzmuHlVBfecvoiJ=='movie':xbmcplugin.setContent(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn._addon_handle,'movies')
  else:xbmcplugin.setContent(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn._addon_handle,cacheToDisc=WLxgMbUFSYhRTCGDzmuHlVBfecvoEd)
 def Load_List_File(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn,WLxgMbUFSYhRTCGDzmuHlVBfecvosa): 
  try:
   if WLxgMbUFSYhRTCGDzmuHlVBfecvosa=='search':
    WLxgMbUFSYhRTCGDzmuHlVBfecvosi=WLxgMbUFSYhRTCGDzmuHlVBfecvoIE
   elif WLxgMbUFSYhRTCGDzmuHlVBfecvosa in['vod','movie']:
    WLxgMbUFSYhRTCGDzmuHlVBfecvosi=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%WLxgMbUFSYhRTCGDzmuHlVBfecvosa))
   else:
    return[]
   fp=WLxgMbUFSYhRTCGDzmuHlVBfecvoEP(WLxgMbUFSYhRTCGDzmuHlVBfecvosi,'r',-1,'utf-8')
   WLxgMbUFSYhRTCGDzmuHlVBfecvosw=fp.readlines()
   fp.close()
  except:
   WLxgMbUFSYhRTCGDzmuHlVBfecvosw=[]
  return WLxgMbUFSYhRTCGDzmuHlVBfecvosw
 def Save_Watched_List(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn,WLxgMbUFSYhRTCGDzmuHlVBfecvotN,WLxgMbUFSYhRTCGDzmuHlVBfecvoIQ):
  try:
   WLxgMbUFSYhRTCGDzmuHlVBfecvosr=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%WLxgMbUFSYhRTCGDzmuHlVBfecvotN))
   WLxgMbUFSYhRTCGDzmuHlVBfecvost=WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.Load_List_File(WLxgMbUFSYhRTCGDzmuHlVBfecvotN) 
   fp=WLxgMbUFSYhRTCGDzmuHlVBfecvoEP(WLxgMbUFSYhRTCGDzmuHlVBfecvosr,'w',-1,'utf-8')
   WLxgMbUFSYhRTCGDzmuHlVBfecvosE=urllib.parse.urlencode(WLxgMbUFSYhRTCGDzmuHlVBfecvoIQ)
   WLxgMbUFSYhRTCGDzmuHlVBfecvosE=WLxgMbUFSYhRTCGDzmuHlVBfecvosE+'\n'
   fp.write(WLxgMbUFSYhRTCGDzmuHlVBfecvosE)
   WLxgMbUFSYhRTCGDzmuHlVBfecvosn=0
   for WLxgMbUFSYhRTCGDzmuHlVBfecvosj in WLxgMbUFSYhRTCGDzmuHlVBfecvost:
    WLxgMbUFSYhRTCGDzmuHlVBfecvosk=WLxgMbUFSYhRTCGDzmuHlVBfecvoEA(urllib.parse.parse_qsl(WLxgMbUFSYhRTCGDzmuHlVBfecvosj))
    WLxgMbUFSYhRTCGDzmuHlVBfecvosQ=WLxgMbUFSYhRTCGDzmuHlVBfecvoIQ.get('code').strip()
    WLxgMbUFSYhRTCGDzmuHlVBfecvosp=WLxgMbUFSYhRTCGDzmuHlVBfecvosk.get('code').strip()
    if WLxgMbUFSYhRTCGDzmuHlVBfecvotN=='vod' and WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.get_settings_direct_replay()==WLxgMbUFSYhRTCGDzmuHlVBfecvoEa:
     WLxgMbUFSYhRTCGDzmuHlVBfecvosQ=WLxgMbUFSYhRTCGDzmuHlVBfecvoIQ.get('videoid').strip()
     WLxgMbUFSYhRTCGDzmuHlVBfecvosp=WLxgMbUFSYhRTCGDzmuHlVBfecvosk.get('videoid').strip()if WLxgMbUFSYhRTCGDzmuHlVBfecvosp!=WLxgMbUFSYhRTCGDzmuHlVBfecvoEy else '-'
    if WLxgMbUFSYhRTCGDzmuHlVBfecvosQ!=WLxgMbUFSYhRTCGDzmuHlVBfecvosp:
     fp.write(WLxgMbUFSYhRTCGDzmuHlVBfecvosj)
     WLxgMbUFSYhRTCGDzmuHlVBfecvosn+=1
     if WLxgMbUFSYhRTCGDzmuHlVBfecvosn>=50:break
   fp.close()
  except:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoEy
 def Delete_List_File(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn,WLxgMbUFSYhRTCGDzmuHlVBfecvosa,skey='-'):
  if WLxgMbUFSYhRTCGDzmuHlVBfecvosa=='ALL':
   try:
    WLxgMbUFSYhRTCGDzmuHlVBfecvosi=WLxgMbUFSYhRTCGDzmuHlVBfecvoIE
    fp=WLxgMbUFSYhRTCGDzmuHlVBfecvoEP(WLxgMbUFSYhRTCGDzmuHlVBfecvosi,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    WLxgMbUFSYhRTCGDzmuHlVBfecvoEy
  elif WLxgMbUFSYhRTCGDzmuHlVBfecvosa=='ONE':
   try:
    WLxgMbUFSYhRTCGDzmuHlVBfecvosi=WLxgMbUFSYhRTCGDzmuHlVBfecvoIE
    WLxgMbUFSYhRTCGDzmuHlVBfecvost=WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.Load_List_File('search') 
    fp=WLxgMbUFSYhRTCGDzmuHlVBfecvoEP(WLxgMbUFSYhRTCGDzmuHlVBfecvosi,'w',-1,'utf-8')
    for WLxgMbUFSYhRTCGDzmuHlVBfecvosj in WLxgMbUFSYhRTCGDzmuHlVBfecvost:
     WLxgMbUFSYhRTCGDzmuHlVBfecvosk=WLxgMbUFSYhRTCGDzmuHlVBfecvoEA(urllib.parse.parse_qsl(WLxgMbUFSYhRTCGDzmuHlVBfecvosj))
     WLxgMbUFSYhRTCGDzmuHlVBfecvosy=WLxgMbUFSYhRTCGDzmuHlVBfecvosk.get('skey').strip()
     if skey!=WLxgMbUFSYhRTCGDzmuHlVBfecvosy:
      fp.write(WLxgMbUFSYhRTCGDzmuHlVBfecvosj)
    fp.close()
   except:
    WLxgMbUFSYhRTCGDzmuHlVBfecvoEy
  elif WLxgMbUFSYhRTCGDzmuHlVBfecvosa in['vod','movie']:
   try:
    WLxgMbUFSYhRTCGDzmuHlVBfecvosi=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%WLxgMbUFSYhRTCGDzmuHlVBfecvosa))
    fp=WLxgMbUFSYhRTCGDzmuHlVBfecvoEP(WLxgMbUFSYhRTCGDzmuHlVBfecvosi,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    WLxgMbUFSYhRTCGDzmuHlVBfecvoEy
 def dp_Listfile_Delete(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn,args):
  WLxgMbUFSYhRTCGDzmuHlVBfecvosa=args.get('sType')
  WLxgMbUFSYhRTCGDzmuHlVBfecvowj =args.get('skey')
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIy=xbmcgui.Dialog()
  if WLxgMbUFSYhRTCGDzmuHlVBfecvosa=='ALL':
   WLxgMbUFSYhRTCGDzmuHlVBfecvosd=WLxgMbUFSYhRTCGDzmuHlVBfecvoIy.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif WLxgMbUFSYhRTCGDzmuHlVBfecvosa=='ONE':
   WLxgMbUFSYhRTCGDzmuHlVBfecvosd=WLxgMbUFSYhRTCGDzmuHlVBfecvoIy.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif WLxgMbUFSYhRTCGDzmuHlVBfecvosa in['vod','movie']:
   WLxgMbUFSYhRTCGDzmuHlVBfecvosd=WLxgMbUFSYhRTCGDzmuHlVBfecvoIy.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if WLxgMbUFSYhRTCGDzmuHlVBfecvosd==WLxgMbUFSYhRTCGDzmuHlVBfecvoEd:sys.exit()
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.Delete_List_File(WLxgMbUFSYhRTCGDzmuHlVBfecvosa,skey=WLxgMbUFSYhRTCGDzmuHlVBfecvowj)
  xbmc.executebuiltin("Container.Refresh")
 def Save_Searched_List(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn,WLxgMbUFSYhRTCGDzmuHlVBfecvoiA):
  try:
   WLxgMbUFSYhRTCGDzmuHlVBfecvosX=WLxgMbUFSYhRTCGDzmuHlVBfecvoIE
   WLxgMbUFSYhRTCGDzmuHlVBfecvost=WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.Load_List_File('search') 
   WLxgMbUFSYhRTCGDzmuHlVBfecvosO={'skey':WLxgMbUFSYhRTCGDzmuHlVBfecvoiA.strip()}
   fp=WLxgMbUFSYhRTCGDzmuHlVBfecvoEP(WLxgMbUFSYhRTCGDzmuHlVBfecvosX,'w',-1,'utf-8')
   WLxgMbUFSYhRTCGDzmuHlVBfecvosE=urllib.parse.urlencode(WLxgMbUFSYhRTCGDzmuHlVBfecvosO)
   WLxgMbUFSYhRTCGDzmuHlVBfecvosE=WLxgMbUFSYhRTCGDzmuHlVBfecvosE+'\n'
   fp.write(WLxgMbUFSYhRTCGDzmuHlVBfecvosE)
   WLxgMbUFSYhRTCGDzmuHlVBfecvosn=0
   for WLxgMbUFSYhRTCGDzmuHlVBfecvosj in WLxgMbUFSYhRTCGDzmuHlVBfecvost:
    WLxgMbUFSYhRTCGDzmuHlVBfecvosk=WLxgMbUFSYhRTCGDzmuHlVBfecvoEA(urllib.parse.parse_qsl(WLxgMbUFSYhRTCGDzmuHlVBfecvosj))
    WLxgMbUFSYhRTCGDzmuHlVBfecvosQ=WLxgMbUFSYhRTCGDzmuHlVBfecvosO.get('skey').strip()
    WLxgMbUFSYhRTCGDzmuHlVBfecvosp=WLxgMbUFSYhRTCGDzmuHlVBfecvosk.get('skey').strip()
    if WLxgMbUFSYhRTCGDzmuHlVBfecvosQ!=WLxgMbUFSYhRTCGDzmuHlVBfecvosp:
     fp.write(WLxgMbUFSYhRTCGDzmuHlVBfecvosj)
     WLxgMbUFSYhRTCGDzmuHlVBfecvosn+=1
     if WLxgMbUFSYhRTCGDzmuHlVBfecvosn>=50:break
   fp.close()
  except:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoEy
 def dp_Global_Search(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn,args):
  WLxgMbUFSYhRTCGDzmuHlVBfecvoiq=args.get('mode')
  if WLxgMbUFSYhRTCGDzmuHlVBfecvoiq=='TOTAL_SEARCH':
   WLxgMbUFSYhRTCGDzmuHlVBfecvosA='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   WLxgMbUFSYhRTCGDzmuHlVBfecvosA='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(WLxgMbUFSYhRTCGDzmuHlVBfecvosA)
 def dp_Bookmark_Menu(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn,args):
  WLxgMbUFSYhRTCGDzmuHlVBfecvosA='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(WLxgMbUFSYhRTCGDzmuHlVBfecvosA)
 def login_main(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn):
  (WLxgMbUFSYhRTCGDzmuHlVBfecvosK,WLxgMbUFSYhRTCGDzmuHlVBfecvosq,WLxgMbUFSYhRTCGDzmuHlVBfecvosJ)=WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.get_settings_login_info()
  if not(WLxgMbUFSYhRTCGDzmuHlVBfecvosK and WLxgMbUFSYhRTCGDzmuHlVBfecvosq):
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIy=xbmcgui.Dialog()
   WLxgMbUFSYhRTCGDzmuHlVBfecvosd=WLxgMbUFSYhRTCGDzmuHlVBfecvoIy.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if WLxgMbUFSYhRTCGDzmuHlVBfecvosd==WLxgMbUFSYhRTCGDzmuHlVBfecvoEa:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.get_winEpisodeOrderby()=='':
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.set_winEpisodeOrderby('desc')
  if WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.cookiefile_check():return
  WLxgMbUFSYhRTCGDzmuHlVBfecvosP =WLxgMbUFSYhRTCGDzmuHlVBfecvoEX(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  WLxgMbUFSYhRTCGDzmuHlVBfecvosN=xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINTIME')
  if WLxgMbUFSYhRTCGDzmuHlVBfecvosN==WLxgMbUFSYhRTCGDzmuHlVBfecvoEy or WLxgMbUFSYhRTCGDzmuHlVBfecvosN=='':
   WLxgMbUFSYhRTCGDzmuHlVBfecvosN=WLxgMbUFSYhRTCGDzmuHlVBfecvoEX('19000101')
  else:
   WLxgMbUFSYhRTCGDzmuHlVBfecvosN=WLxgMbUFSYhRTCGDzmuHlVBfecvoEX(re.sub('-','',WLxgMbUFSYhRTCGDzmuHlVBfecvosN))
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   WLxgMbUFSYhRTCGDzmuHlVBfecvorI=0
   while WLxgMbUFSYhRTCGDzmuHlVBfecvoEa:
    WLxgMbUFSYhRTCGDzmuHlVBfecvorI+=1
    time.sleep(0.05)
    if WLxgMbUFSYhRTCGDzmuHlVBfecvosN>=WLxgMbUFSYhRTCGDzmuHlVBfecvosP:return
    if WLxgMbUFSYhRTCGDzmuHlVBfecvorI>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  if WLxgMbUFSYhRTCGDzmuHlVBfecvosN>=WLxgMbUFSYhRTCGDzmuHlVBfecvosP:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   return
  if not WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.GetCredential(WLxgMbUFSYhRTCGDzmuHlVBfecvosK,WLxgMbUFSYhRTCGDzmuHlVBfecvosq,WLxgMbUFSYhRTCGDzmuHlVBfecvosJ):
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   sys.exit()
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.set_winCredential(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.LoadCredential())
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
 def dp_setEpOrderby(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn,args):
  WLxgMbUFSYhRTCGDzmuHlVBfecvori =args.get('orderby')
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.set_winEpisodeOrderby(WLxgMbUFSYhRTCGDzmuHlVBfecvori)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn,args):
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.SaveCredential(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.get_winCredential())
  WLxgMbUFSYhRTCGDzmuHlVBfecvoiq =args.get('mode')
  WLxgMbUFSYhRTCGDzmuHlVBfecvorw =args.get('contentid')
  WLxgMbUFSYhRTCGDzmuHlVBfecvors =args.get('pvrmode')
  WLxgMbUFSYhRTCGDzmuHlVBfecvort=WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.get_selQuality()
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.addon_log(WLxgMbUFSYhRTCGDzmuHlVBfecvorw+' - '+WLxgMbUFSYhRTCGDzmuHlVBfecvoiq)
  if WLxgMbUFSYhRTCGDzmuHlVBfecvoiq=='SPORTS':
   WLxgMbUFSYhRTCGDzmuHlVBfecvorE,WLxgMbUFSYhRTCGDzmuHlVBfecvorn=WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.GetSportsURL(WLxgMbUFSYhRTCGDzmuHlVBfecvorw,WLxgMbUFSYhRTCGDzmuHlVBfecvort)
   WLxgMbUFSYhRTCGDzmuHlVBfecvorj =''
   WLxgMbUFSYhRTCGDzmuHlVBfecvork=''
  else:
   WLxgMbUFSYhRTCGDzmuHlVBfecvorE,WLxgMbUFSYhRTCGDzmuHlVBfecvorn,WLxgMbUFSYhRTCGDzmuHlVBfecvorj,WLxgMbUFSYhRTCGDzmuHlVBfecvork=WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.GetStreamingURL(WLxgMbUFSYhRTCGDzmuHlVBfecvoiq,WLxgMbUFSYhRTCGDzmuHlVBfecvorw,WLxgMbUFSYhRTCGDzmuHlVBfecvort,WLxgMbUFSYhRTCGDzmuHlVBfecvors)
  WLxgMbUFSYhRTCGDzmuHlVBfecvorQ='%s|Cookie=%s'%(WLxgMbUFSYhRTCGDzmuHlVBfecvorE,WLxgMbUFSYhRTCGDzmuHlVBfecvorn)
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.addon_log(WLxgMbUFSYhRTCGDzmuHlVBfecvorQ)
  if WLxgMbUFSYhRTCGDzmuHlVBfecvorE=='':
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.addon_noti(__language__(30907).encode('utf8'))
   return
  WLxgMbUFSYhRTCGDzmuHlVBfecvorp=xbmcgui.ListItem(path=WLxgMbUFSYhRTCGDzmuHlVBfecvorQ)
  if WLxgMbUFSYhRTCGDzmuHlVBfecvorj:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.addon_log('!!streaming_drm!!')
   WLxgMbUFSYhRTCGDzmuHlVBfecvory=WLxgMbUFSYhRTCGDzmuHlVBfecvorj['customdata']
   WLxgMbUFSYhRTCGDzmuHlVBfecvora =WLxgMbUFSYhRTCGDzmuHlVBfecvorj['drmhost']
   WLxgMbUFSYhRTCGDzmuHlVBfecvord =inputstreamhelper.Helper('mpd',drm='widevine')
   if WLxgMbUFSYhRTCGDzmuHlVBfecvord.check_inputstream():
    if WLxgMbUFSYhRTCGDzmuHlVBfecvoiq=='MOVIE':
     WLxgMbUFSYhRTCGDzmuHlVBfecvorX='https://www.wavve.com/player/movie?movieid=%s'%WLxgMbUFSYhRTCGDzmuHlVBfecvorw
    else:
     WLxgMbUFSYhRTCGDzmuHlVBfecvorX='https://www.wavve.com/player/vod?programid=%s&page=1'%WLxgMbUFSYhRTCGDzmuHlVBfecvorw
    WLxgMbUFSYhRTCGDzmuHlVBfecvorO={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':WLxgMbUFSYhRTCGDzmuHlVBfecvory,'referer':WLxgMbUFSYhRTCGDzmuHlVBfecvorX,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.USER_AGENT}
    WLxgMbUFSYhRTCGDzmuHlVBfecvorA=WLxgMbUFSYhRTCGDzmuHlVBfecvora+'|'+urllib.parse.urlencode(WLxgMbUFSYhRTCGDzmuHlVBfecvorO)+'|R{SSM}|'
    WLxgMbUFSYhRTCGDzmuHlVBfecvorp.setProperty('inputstream',WLxgMbUFSYhRTCGDzmuHlVBfecvord.inputstream_addon)
    WLxgMbUFSYhRTCGDzmuHlVBfecvorp.setProperty('inputstream.adaptive.manifest_type','mpd')
    WLxgMbUFSYhRTCGDzmuHlVBfecvorp.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    WLxgMbUFSYhRTCGDzmuHlVBfecvorp.setProperty('inputstream.adaptive.license_key',WLxgMbUFSYhRTCGDzmuHlVBfecvorA)
    WLxgMbUFSYhRTCGDzmuHlVBfecvorp.setProperty('inputstream.adaptive.stream_headers','user-agent=%s&Cookie=%s'%(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.USER_AGENT,WLxgMbUFSYhRTCGDzmuHlVBfecvorn))
  xbmcplugin.setResolvedUrl(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn._addon_handle,WLxgMbUFSYhRTCGDzmuHlVBfecvoEa,WLxgMbUFSYhRTCGDzmuHlVBfecvorp)
  WLxgMbUFSYhRTCGDzmuHlVBfecvorK=WLxgMbUFSYhRTCGDzmuHlVBfecvoEd
  if WLxgMbUFSYhRTCGDzmuHlVBfecvork:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.addon_noti(WLxgMbUFSYhRTCGDzmuHlVBfecvork.encode('utf-8'))
   WLxgMbUFSYhRTCGDzmuHlVBfecvorK=WLxgMbUFSYhRTCGDzmuHlVBfecvoEa
  else:
   if '/preview.' in urllib.parse.urlsplit(WLxgMbUFSYhRTCGDzmuHlVBfecvorE).path:
    WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.addon_noti(__language__(30908).encode('utf8'))
    WLxgMbUFSYhRTCGDzmuHlVBfecvorK=WLxgMbUFSYhRTCGDzmuHlVBfecvoEa
  try:
   WLxgMbUFSYhRTCGDzmuHlVBfecvorq=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and WLxgMbUFSYhRTCGDzmuHlVBfecvorK==WLxgMbUFSYhRTCGDzmuHlVBfecvoEd and WLxgMbUFSYhRTCGDzmuHlVBfecvorq!='-':
    WLxgMbUFSYhRTCGDzmuHlVBfecvoiy={'code':WLxgMbUFSYhRTCGDzmuHlVBfecvorq,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.Save_Watched_List(args.get('mode').lower(),WLxgMbUFSYhRTCGDzmuHlVBfecvoiy)
  except:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoEy
 def logout(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn):
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIy=xbmcgui.Dialog()
  WLxgMbUFSYhRTCGDzmuHlVBfecvosd=WLxgMbUFSYhRTCGDzmuHlVBfecvoIy.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if WLxgMbUFSYhRTCGDzmuHlVBfecvosd==WLxgMbUFSYhRTCGDzmuHlVBfecvoEd:sys.exit()
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.wininfo_clear()
  if os.path.isfile(WLxgMbUFSYhRTCGDzmuHlVBfecvoIt):os.remove(WLxgMbUFSYhRTCGDzmuHlVBfecvoIt)
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn):
  WLxgMbUFSYhRTCGDzmuHlVBfecvoiE=xbmcgui.Window(10000)
  WLxgMbUFSYhRTCGDzmuHlVBfecvoiE.setProperty('WAVVE_M_CREDENTIAL','')
  WLxgMbUFSYhRTCGDzmuHlVBfecvoiE.setProperty('WAVVE_M_LOGINTIME','')
 def cookiefile_save(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn):
  WLxgMbUFSYhRTCGDzmuHlVBfecvorJ =WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.Get_Now_Datetime()
  WLxgMbUFSYhRTCGDzmuHlVBfecvorP=WLxgMbUFSYhRTCGDzmuHlVBfecvorJ+datetime.timedelta(days=WLxgMbUFSYhRTCGDzmuHlVBfecvoEX(__addon__.getSetting('cache_ttl')))
  WLxgMbUFSYhRTCGDzmuHlVBfecvoiE=xbmcgui.Window(10000)
  WLxgMbUFSYhRTCGDzmuHlVBfecvorN={'wavve_token':WLxgMbUFSYhRTCGDzmuHlVBfecvoiE.getProperty('WAVVE_M_CREDENTIAL'),'wavve_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'wavve_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'wavve_profile':__addon__.getSetting('selected_profile'),'wavve_limitdate':WLxgMbUFSYhRTCGDzmuHlVBfecvorP.strftime('%Y-%m-%d')}
  try: 
   fp=WLxgMbUFSYhRTCGDzmuHlVBfecvoEP(WLxgMbUFSYhRTCGDzmuHlVBfecvoIt,'w',-1,'utf-8')
   json.dump(WLxgMbUFSYhRTCGDzmuHlVBfecvorN,fp)
   fp.close()
  except WLxgMbUFSYhRTCGDzmuHlVBfecvoEN as exception:
   WLxgMbUFSYhRTCGDzmuHlVBfecvonI(exception)
 def cookiefile_check(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn):
  WLxgMbUFSYhRTCGDzmuHlVBfecvorN={}
  try: 
   fp=WLxgMbUFSYhRTCGDzmuHlVBfecvoEP(WLxgMbUFSYhRTCGDzmuHlVBfecvoIt,'r',-1,'utf-8')
   WLxgMbUFSYhRTCGDzmuHlVBfecvorN= json.load(fp)
   fp.close()
  except WLxgMbUFSYhRTCGDzmuHlVBfecvoEN as exception:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.wininfo_clear()
   return WLxgMbUFSYhRTCGDzmuHlVBfecvoEd
  WLxgMbUFSYhRTCGDzmuHlVBfecvosK =__addon__.getSetting('id')
  WLxgMbUFSYhRTCGDzmuHlVBfecvosq =__addon__.getSetting('pw')
  WLxgMbUFSYhRTCGDzmuHlVBfecvotI =__addon__.getSetting('selected_profile')
  WLxgMbUFSYhRTCGDzmuHlVBfecvorN['wavve_id']=base64.standard_b64decode(WLxgMbUFSYhRTCGDzmuHlVBfecvorN['wavve_id']).decode('utf-8')
  WLxgMbUFSYhRTCGDzmuHlVBfecvorN['wavve_pw']=base64.standard_b64decode(WLxgMbUFSYhRTCGDzmuHlVBfecvorN['wavve_pw']).decode('utf-8')
  if WLxgMbUFSYhRTCGDzmuHlVBfecvosK!=WLxgMbUFSYhRTCGDzmuHlVBfecvorN['wavve_id']or WLxgMbUFSYhRTCGDzmuHlVBfecvosq!=WLxgMbUFSYhRTCGDzmuHlVBfecvorN['wavve_pw']or WLxgMbUFSYhRTCGDzmuHlVBfecvotI!=WLxgMbUFSYhRTCGDzmuHlVBfecvorN['wavve_profile']:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.wininfo_clear()
   return WLxgMbUFSYhRTCGDzmuHlVBfecvoEd
  WLxgMbUFSYhRTCGDzmuHlVBfecvosP =WLxgMbUFSYhRTCGDzmuHlVBfecvoEX(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  WLxgMbUFSYhRTCGDzmuHlVBfecvoti=WLxgMbUFSYhRTCGDzmuHlVBfecvorN['wavve_limitdate']
  WLxgMbUFSYhRTCGDzmuHlVBfecvosN =WLxgMbUFSYhRTCGDzmuHlVBfecvoEX(re.sub('-','',WLxgMbUFSYhRTCGDzmuHlVBfecvoti))
  if WLxgMbUFSYhRTCGDzmuHlVBfecvosN<WLxgMbUFSYhRTCGDzmuHlVBfecvosP:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.wininfo_clear()
   return WLxgMbUFSYhRTCGDzmuHlVBfecvoEd
  WLxgMbUFSYhRTCGDzmuHlVBfecvoiE=xbmcgui.Window(10000)
  WLxgMbUFSYhRTCGDzmuHlVBfecvoiE.setProperty('WAVVE_M_CREDENTIAL',WLxgMbUFSYhRTCGDzmuHlVBfecvorN['wavve_token'])
  WLxgMbUFSYhRTCGDzmuHlVBfecvoiE.setProperty('WAVVE_M_LOGINTIME',WLxgMbUFSYhRTCGDzmuHlVBfecvoti)
  return WLxgMbUFSYhRTCGDzmuHlVBfecvoEa
 def dp_LiveCatagory_List(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn,args):
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.SaveCredential(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.get_winCredential())
  WLxgMbUFSYhRTCGDzmuHlVBfecvotw =args.get('sCode')
  WLxgMbUFSYhRTCGDzmuHlVBfecvots=args.get('sIndex')
  WLxgMbUFSYhRTCGDzmuHlVBfecvowd,WLxgMbUFSYhRTCGDzmuHlVBfecvotr=WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.Get_LiveCatagory_List(WLxgMbUFSYhRTCGDzmuHlVBfecvotw,WLxgMbUFSYhRTCGDzmuHlVBfecvots)
  for WLxgMbUFSYhRTCGDzmuHlVBfecvowX in WLxgMbUFSYhRTCGDzmuHlVBfecvowd:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoij =WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('title')
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy={'mode':'LIVE_LIST','genre':WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('genre'),'baseapi':WLxgMbUFSYhRTCGDzmuHlVBfecvotr}
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.add_dir(WLxgMbUFSYhRTCGDzmuHlVBfecvoij,sublabel='',img='',infoLabels=WLxgMbUFSYhRTCGDzmuHlVBfecvoEy,isFolder=WLxgMbUFSYhRTCGDzmuHlVBfecvoEa,params=WLxgMbUFSYhRTCGDzmuHlVBfecvoiy)
  if WLxgMbUFSYhRTCGDzmuHlVBfecvoEK(WLxgMbUFSYhRTCGDzmuHlVBfecvowd)>0:xbmcplugin.endOfDirectory(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn._addon_handle,cacheToDisc=WLxgMbUFSYhRTCGDzmuHlVBfecvoEd)
 def dp_MainCatagory_List(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn,args):
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.SaveCredential(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.get_winCredential())
  WLxgMbUFSYhRTCGDzmuHlVBfecvotw =args.get('sCode')
  WLxgMbUFSYhRTCGDzmuHlVBfecvots=args.get('sIndex')
  WLxgMbUFSYhRTCGDzmuHlVBfecvoiJ =args.get('sType')
  WLxgMbUFSYhRTCGDzmuHlVBfecvowd=WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.Get_MainCatagory_List(WLxgMbUFSYhRTCGDzmuHlVBfecvotw,WLxgMbUFSYhRTCGDzmuHlVBfecvots)
  for WLxgMbUFSYhRTCGDzmuHlVBfecvowX in WLxgMbUFSYhRTCGDzmuHlVBfecvowd:
   if WLxgMbUFSYhRTCGDzmuHlVBfecvoiJ=='vod':
    if WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('subtype')=='catagory':
     WLxgMbUFSYhRTCGDzmuHlVBfecvoiq='PROGRAM_LIST'
    else:
     WLxgMbUFSYhRTCGDzmuHlVBfecvoiq='SUPERSECTION_LIST'
   elif WLxgMbUFSYhRTCGDzmuHlVBfecvoiJ=='movie':
    WLxgMbUFSYhRTCGDzmuHlVBfecvoiq='MOVIE_LIST'
   else:
    WLxgMbUFSYhRTCGDzmuHlVBfecvoiq=''
   WLxgMbUFSYhRTCGDzmuHlVBfecvoij='%s (%s)'%(WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('title'),args.get('ordernm'))
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy={'mode':WLxgMbUFSYhRTCGDzmuHlVBfecvoiq,'suburl':WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('suburl'),'subapi':WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.get_settings_exclusion21():
    if WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('title')=='성인' or WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('title')=='성인+':continue
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.add_dir(WLxgMbUFSYhRTCGDzmuHlVBfecvoij,sublabel='',img='',infoLabels=WLxgMbUFSYhRTCGDzmuHlVBfecvoEy,isFolder=WLxgMbUFSYhRTCGDzmuHlVBfecvoEa,params=WLxgMbUFSYhRTCGDzmuHlVBfecvoiy)
  if WLxgMbUFSYhRTCGDzmuHlVBfecvoEK(WLxgMbUFSYhRTCGDzmuHlVBfecvowd)>0:xbmcplugin.endOfDirectory(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn._addon_handle,cacheToDisc=WLxgMbUFSYhRTCGDzmuHlVBfecvoEd)
 def dp_Program_List(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn,args):
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.SaveCredential(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.get_winCredential())
  WLxgMbUFSYhRTCGDzmuHlVBfecvotE =args.get('subapi')
  WLxgMbUFSYhRTCGDzmuHlVBfecvowa=WLxgMbUFSYhRTCGDzmuHlVBfecvoEX(args.get('page'))
  WLxgMbUFSYhRTCGDzmuHlVBfecvori =args.get('orderby')
  WLxgMbUFSYhRTCGDzmuHlVBfecvowd,WLxgMbUFSYhRTCGDzmuHlVBfecvoiN=WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.Get_Program_List(WLxgMbUFSYhRTCGDzmuHlVBfecvotE,WLxgMbUFSYhRTCGDzmuHlVBfecvowa,WLxgMbUFSYhRTCGDzmuHlVBfecvori)
  for WLxgMbUFSYhRTCGDzmuHlVBfecvowX in WLxgMbUFSYhRTCGDzmuHlVBfecvowd:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoij =WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('title')
   WLxgMbUFSYhRTCGDzmuHlVBfecvowO=WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('thumbnail')
   WLxgMbUFSYhRTCGDzmuHlVBfecvowA =WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('age')
   if WLxgMbUFSYhRTCGDzmuHlVBfecvowA=='18' or WLxgMbUFSYhRTCGDzmuHlVBfecvowA=='19' or WLxgMbUFSYhRTCGDzmuHlVBfecvowA=='21':WLxgMbUFSYhRTCGDzmuHlVBfecvoij+=' (%s)'%(WLxgMbUFSYhRTCGDzmuHlVBfecvowA)
   WLxgMbUFSYhRTCGDzmuHlVBfecvowy={'plot':WLxgMbUFSYhRTCGDzmuHlVBfecvoij,'mpaa':WLxgMbUFSYhRTCGDzmuHlVBfecvowA,'mediatype':'tvshow'}
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy={'mode':'EPISODE_LIST','videoid':WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('videoid'),'vidtype':WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('vidtype'),'page':'1'}
   if WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.get_settings_makebookmark():
    WLxgMbUFSYhRTCGDzmuHlVBfecvowK={'videoid':WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('videoid'),'vidtype':'tvshow','vtitle':WLxgMbUFSYhRTCGDzmuHlVBfecvoij,'vsubtitle':'','contenttype':WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('vidtype'),}
    WLxgMbUFSYhRTCGDzmuHlVBfecvowq=json.dumps(WLxgMbUFSYhRTCGDzmuHlVBfecvowK)
    WLxgMbUFSYhRTCGDzmuHlVBfecvowq=urllib.parse.quote(WLxgMbUFSYhRTCGDzmuHlVBfecvowq)
    WLxgMbUFSYhRTCGDzmuHlVBfecvowJ='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(WLxgMbUFSYhRTCGDzmuHlVBfecvowq)
    WLxgMbUFSYhRTCGDzmuHlVBfecvowp=[('(통합) 찜 영상에 추가',WLxgMbUFSYhRTCGDzmuHlVBfecvowJ)]
   else:
    WLxgMbUFSYhRTCGDzmuHlVBfecvowp=WLxgMbUFSYhRTCGDzmuHlVBfecvoEy
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.add_dir(WLxgMbUFSYhRTCGDzmuHlVBfecvoij,sublabel='',img=WLxgMbUFSYhRTCGDzmuHlVBfecvowO,infoLabels=WLxgMbUFSYhRTCGDzmuHlVBfecvowy,isFolder=WLxgMbUFSYhRTCGDzmuHlVBfecvoEa,params=WLxgMbUFSYhRTCGDzmuHlVBfecvoiy,ContextMenu=WLxgMbUFSYhRTCGDzmuHlVBfecvowp)
  if WLxgMbUFSYhRTCGDzmuHlVBfecvoiN:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy={}
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy['mode'] ='PROGRAM_LIST' 
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy['subapi']=WLxgMbUFSYhRTCGDzmuHlVBfecvotE 
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy['page'] =WLxgMbUFSYhRTCGDzmuHlVBfecvoEJ(WLxgMbUFSYhRTCGDzmuHlVBfecvowa+1)
   WLxgMbUFSYhRTCGDzmuHlVBfecvoij='[B]%s >>[/B]'%'다음 페이지'
   WLxgMbUFSYhRTCGDzmuHlVBfecvowP=WLxgMbUFSYhRTCGDzmuHlVBfecvoEJ(WLxgMbUFSYhRTCGDzmuHlVBfecvowa+1)
   WLxgMbUFSYhRTCGDzmuHlVBfecvoip=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.add_dir(WLxgMbUFSYhRTCGDzmuHlVBfecvoij,sublabel=WLxgMbUFSYhRTCGDzmuHlVBfecvowP,img=WLxgMbUFSYhRTCGDzmuHlVBfecvoip,infoLabels=WLxgMbUFSYhRTCGDzmuHlVBfecvoEy,isFolder=WLxgMbUFSYhRTCGDzmuHlVBfecvoEa,params=WLxgMbUFSYhRTCGDzmuHlVBfecvoiy)
  xbmcplugin.setContent(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn._addon_handle,'tvshows')
  if WLxgMbUFSYhRTCGDzmuHlVBfecvoEK(WLxgMbUFSYhRTCGDzmuHlVBfecvowd)>0:xbmcplugin.endOfDirectory(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn._addon_handle,cacheToDisc=WLxgMbUFSYhRTCGDzmuHlVBfecvoEd)
 def dp_SuperSection_List(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn,args):
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.SaveCredential(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.get_winCredential())
  WLxgMbUFSYhRTCGDzmuHlVBfecvotn =args.get('suburl')
  WLxgMbUFSYhRTCGDzmuHlVBfecvowd=WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.Get_SuperMultiSection_List(WLxgMbUFSYhRTCGDzmuHlVBfecvotn)
  for WLxgMbUFSYhRTCGDzmuHlVBfecvowX in WLxgMbUFSYhRTCGDzmuHlVBfecvowd:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoij =WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('title')
   WLxgMbUFSYhRTCGDzmuHlVBfecvotE =WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('subapi')
   WLxgMbUFSYhRTCGDzmuHlVBfecvotj=WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('cell_type')
   if WLxgMbUFSYhRTCGDzmuHlVBfecvotE.find('mtype=svod')>=0 or WLxgMbUFSYhRTCGDzmuHlVBfecvotE.find('mtype=ppv')>=0:
    WLxgMbUFSYhRTCGDzmuHlVBfecvoiq='MOVIE_LIST'
   elif WLxgMbUFSYhRTCGDzmuHlVBfecvotj=='band_71':
    WLxgMbUFSYhRTCGDzmuHlVBfecvoiq ='SUPERSECTION_LIST'
    (WLxgMbUFSYhRTCGDzmuHlVBfecvotk,WLxgMbUFSYhRTCGDzmuHlVBfecvotQ)=WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.Baseapi_Parse(WLxgMbUFSYhRTCGDzmuHlVBfecvotE)
    WLxgMbUFSYhRTCGDzmuHlVBfecvotn=WLxgMbUFSYhRTCGDzmuHlVBfecvotQ.get('api')
    WLxgMbUFSYhRTCGDzmuHlVBfecvotE=''
   elif WLxgMbUFSYhRTCGDzmuHlVBfecvotj=='band_2':
    WLxgMbUFSYhRTCGDzmuHlVBfecvoiq='BAND2SECTION_LIST'
   elif WLxgMbUFSYhRTCGDzmuHlVBfecvotj=='band_live':
    WLxgMbUFSYhRTCGDzmuHlVBfecvoiq='BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}',WLxgMbUFSYhRTCGDzmuHlVBfecvotE):
    WLxgMbUFSYhRTCGDzmuHlVBfecvoiq='MOVIE_LIST'
   else:
    WLxgMbUFSYhRTCGDzmuHlVBfecvoiq='PROGRAM_LIST'
   WLxgMbUFSYhRTCGDzmuHlVBfecvowy={'plot':WLxgMbUFSYhRTCGDzmuHlVBfecvoij,'mediatype':'tvshow'}
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy={'mode':WLxgMbUFSYhRTCGDzmuHlVBfecvoiq,'suburl':WLxgMbUFSYhRTCGDzmuHlVBfecvotn,'subapi':WLxgMbUFSYhRTCGDzmuHlVBfecvotE,'page':'1'}
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.add_dir(WLxgMbUFSYhRTCGDzmuHlVBfecvoij,sublabel='',img=WLxgMbUFSYhRTCGDzmuHlVBfecvoEy,infoLabels=WLxgMbUFSYhRTCGDzmuHlVBfecvowy,isFolder=WLxgMbUFSYhRTCGDzmuHlVBfecvoEa,params=WLxgMbUFSYhRTCGDzmuHlVBfecvoiy)
  if WLxgMbUFSYhRTCGDzmuHlVBfecvoEK(WLxgMbUFSYhRTCGDzmuHlVBfecvowd)>0:xbmcplugin.endOfDirectory(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn._addon_handle,cacheToDisc=WLxgMbUFSYhRTCGDzmuHlVBfecvoEd)
 def dp_BandLiveSection_List(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn,args):
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.SaveCredential(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.get_winCredential())
  WLxgMbUFSYhRTCGDzmuHlVBfecvotE =args.get('subapi')
  WLxgMbUFSYhRTCGDzmuHlVBfecvowa=WLxgMbUFSYhRTCGDzmuHlVBfecvoEX(args.get('page'))
  WLxgMbUFSYhRTCGDzmuHlVBfecvowd,WLxgMbUFSYhRTCGDzmuHlVBfecvoiN=WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.Get_BandLiveSection_List(WLxgMbUFSYhRTCGDzmuHlVBfecvotE,WLxgMbUFSYhRTCGDzmuHlVBfecvowa)
  for WLxgMbUFSYhRTCGDzmuHlVBfecvowX in WLxgMbUFSYhRTCGDzmuHlVBfecvowd:
   WLxgMbUFSYhRTCGDzmuHlVBfecvotp =WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('channelid')
   WLxgMbUFSYhRTCGDzmuHlVBfecvoty =WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('studio')
   WLxgMbUFSYhRTCGDzmuHlVBfecvota=WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('tvshowtitle')
   WLxgMbUFSYhRTCGDzmuHlVBfecvowO =WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('thumbnail')
   WLxgMbUFSYhRTCGDzmuHlVBfecvowA =WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('age')
   WLxgMbUFSYhRTCGDzmuHlVBfecvowy={'mediatype':'tvshow','mpaa':WLxgMbUFSYhRTCGDzmuHlVBfecvowA,'title':'%s < %s >'%(WLxgMbUFSYhRTCGDzmuHlVBfecvoty,WLxgMbUFSYhRTCGDzmuHlVBfecvota),'tvshowtitle':WLxgMbUFSYhRTCGDzmuHlVBfecvota,'studio':WLxgMbUFSYhRTCGDzmuHlVBfecvoty,'plot':WLxgMbUFSYhRTCGDzmuHlVBfecvoty}
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy={'mode':'LIVE','contentid':WLxgMbUFSYhRTCGDzmuHlVBfecvotp}
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.add_dir(WLxgMbUFSYhRTCGDzmuHlVBfecvoty,sublabel=WLxgMbUFSYhRTCGDzmuHlVBfecvota,img=WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('thumbnail'),infoLabels=WLxgMbUFSYhRTCGDzmuHlVBfecvowy,isFolder=WLxgMbUFSYhRTCGDzmuHlVBfecvoEd,params=WLxgMbUFSYhRTCGDzmuHlVBfecvoiy)
  if WLxgMbUFSYhRTCGDzmuHlVBfecvoiN:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy={}
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy['mode'] ='BANDLIVESECTION_LIST' 
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy['subapi']=WLxgMbUFSYhRTCGDzmuHlVBfecvotE
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy['page'] =WLxgMbUFSYhRTCGDzmuHlVBfecvoEJ(WLxgMbUFSYhRTCGDzmuHlVBfecvowa+1)
   WLxgMbUFSYhRTCGDzmuHlVBfecvoij='[B]%s >>[/B]'%'다음 페이지'
   WLxgMbUFSYhRTCGDzmuHlVBfecvowP=WLxgMbUFSYhRTCGDzmuHlVBfecvoEJ(WLxgMbUFSYhRTCGDzmuHlVBfecvowa+1)
   WLxgMbUFSYhRTCGDzmuHlVBfecvoip=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.add_dir(WLxgMbUFSYhRTCGDzmuHlVBfecvoij,sublabel=WLxgMbUFSYhRTCGDzmuHlVBfecvowP,img=WLxgMbUFSYhRTCGDzmuHlVBfecvoip,infoLabels=WLxgMbUFSYhRTCGDzmuHlVBfecvoEy,isFolder=WLxgMbUFSYhRTCGDzmuHlVBfecvoEa,params=WLxgMbUFSYhRTCGDzmuHlVBfecvoiy)
  if WLxgMbUFSYhRTCGDzmuHlVBfecvoEK(WLxgMbUFSYhRTCGDzmuHlVBfecvowd)>0:xbmcplugin.endOfDirectory(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn._addon_handle,cacheToDisc=WLxgMbUFSYhRTCGDzmuHlVBfecvoEd)
 def dp_Band2Section_List(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn,args):
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.SaveCredential(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.get_winCredential())
  WLxgMbUFSYhRTCGDzmuHlVBfecvotE =args.get('subapi')
  WLxgMbUFSYhRTCGDzmuHlVBfecvowa=WLxgMbUFSYhRTCGDzmuHlVBfecvoEX(args.get('page'))
  WLxgMbUFSYhRTCGDzmuHlVBfecvowd,WLxgMbUFSYhRTCGDzmuHlVBfecvoiN=WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.Get_Band2Section_List(WLxgMbUFSYhRTCGDzmuHlVBfecvotE,WLxgMbUFSYhRTCGDzmuHlVBfecvowa)
  for WLxgMbUFSYhRTCGDzmuHlVBfecvowX in WLxgMbUFSYhRTCGDzmuHlVBfecvowd:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoij =WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('programtitle')
   WLxgMbUFSYhRTCGDzmuHlVBfecvowP =WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('episodetitle')
   WLxgMbUFSYhRTCGDzmuHlVBfecvowy={'plot':WLxgMbUFSYhRTCGDzmuHlVBfecvoij+'\n\n'+WLxgMbUFSYhRTCGDzmuHlVBfecvowP,'mpaa':WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('age'),'mediatype':'episode'}
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy={'mode':'VOD','programid':'-','contentid':WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('videoid'),'thumbnail':WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('thumbnail'),'title':WLxgMbUFSYhRTCGDzmuHlVBfecvoij,'subtitle':WLxgMbUFSYhRTCGDzmuHlVBfecvowP}
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.add_dir(WLxgMbUFSYhRTCGDzmuHlVBfecvoij,sublabel=WLxgMbUFSYhRTCGDzmuHlVBfecvowP,img=WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('thumbnail'),infoLabels=WLxgMbUFSYhRTCGDzmuHlVBfecvowy,isFolder=WLxgMbUFSYhRTCGDzmuHlVBfecvoEd,params=WLxgMbUFSYhRTCGDzmuHlVBfecvoiy)
  if WLxgMbUFSYhRTCGDzmuHlVBfecvoiN:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy={}
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy['mode'] ='BAND2SECTION_LIST' 
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy['subapi']=WLxgMbUFSYhRTCGDzmuHlVBfecvotE
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy['page'] =WLxgMbUFSYhRTCGDzmuHlVBfecvoEJ(WLxgMbUFSYhRTCGDzmuHlVBfecvowa+1)
   WLxgMbUFSYhRTCGDzmuHlVBfecvoij='[B]%s >>[/B]'%'다음 페이지'
   WLxgMbUFSYhRTCGDzmuHlVBfecvowP=WLxgMbUFSYhRTCGDzmuHlVBfecvoEJ(WLxgMbUFSYhRTCGDzmuHlVBfecvowa+1)
   WLxgMbUFSYhRTCGDzmuHlVBfecvoip=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.add_dir(WLxgMbUFSYhRTCGDzmuHlVBfecvoij,sublabel=WLxgMbUFSYhRTCGDzmuHlVBfecvowP,img=WLxgMbUFSYhRTCGDzmuHlVBfecvoip,infoLabels=WLxgMbUFSYhRTCGDzmuHlVBfecvoEy,isFolder=WLxgMbUFSYhRTCGDzmuHlVBfecvoEa,params=WLxgMbUFSYhRTCGDzmuHlVBfecvoiy)
  if WLxgMbUFSYhRTCGDzmuHlVBfecvoEK(WLxgMbUFSYhRTCGDzmuHlVBfecvowd)>0:xbmcplugin.endOfDirectory(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn._addon_handle,cacheToDisc=WLxgMbUFSYhRTCGDzmuHlVBfecvoEd)
 def dp_Movie_List(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn,args):
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.SaveCredential(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.get_winCredential())
  WLxgMbUFSYhRTCGDzmuHlVBfecvotE =args.get('subapi')
  WLxgMbUFSYhRTCGDzmuHlVBfecvowa=WLxgMbUFSYhRTCGDzmuHlVBfecvoEX(args.get('page'))
  WLxgMbUFSYhRTCGDzmuHlVBfecvowd,WLxgMbUFSYhRTCGDzmuHlVBfecvoiN=WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.Get_Movie_List(WLxgMbUFSYhRTCGDzmuHlVBfecvotE,WLxgMbUFSYhRTCGDzmuHlVBfecvowa)
  for WLxgMbUFSYhRTCGDzmuHlVBfecvowX in WLxgMbUFSYhRTCGDzmuHlVBfecvowd:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoij =WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('title')
   WLxgMbUFSYhRTCGDzmuHlVBfecvowO=WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('thumbnail')
   WLxgMbUFSYhRTCGDzmuHlVBfecvowA =WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('age')
   if WLxgMbUFSYhRTCGDzmuHlVBfecvowA=='18' or WLxgMbUFSYhRTCGDzmuHlVBfecvowA=='19' or WLxgMbUFSYhRTCGDzmuHlVBfecvowA=='21':WLxgMbUFSYhRTCGDzmuHlVBfecvoij+=' (%s)'%(WLxgMbUFSYhRTCGDzmuHlVBfecvowA)
   WLxgMbUFSYhRTCGDzmuHlVBfecvowy={'plot':WLxgMbUFSYhRTCGDzmuHlVBfecvoij,'mpaa':WLxgMbUFSYhRTCGDzmuHlVBfecvowA,'mediatype':'movie'}
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy={'mode':'MOVIE','contentid':WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('videoid'),'title':WLxgMbUFSYhRTCGDzmuHlVBfecvoij,'thumbnail':WLxgMbUFSYhRTCGDzmuHlVBfecvowO,'age':WLxgMbUFSYhRTCGDzmuHlVBfecvowA}
   if WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.get_settings_makebookmark():
    WLxgMbUFSYhRTCGDzmuHlVBfecvowK={'videoid':WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('videoid'),'vidtype':'movie','vtitle':WLxgMbUFSYhRTCGDzmuHlVBfecvoij,'vsubtitle':'','contenttype':'programid',}
    WLxgMbUFSYhRTCGDzmuHlVBfecvowq=json.dumps(WLxgMbUFSYhRTCGDzmuHlVBfecvowK)
    WLxgMbUFSYhRTCGDzmuHlVBfecvowq=urllib.parse.quote(WLxgMbUFSYhRTCGDzmuHlVBfecvowq)
    WLxgMbUFSYhRTCGDzmuHlVBfecvowJ='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(WLxgMbUFSYhRTCGDzmuHlVBfecvowq)
    WLxgMbUFSYhRTCGDzmuHlVBfecvowp=[('(통합) 찜 영상에 추가',WLxgMbUFSYhRTCGDzmuHlVBfecvowJ)]
   else:
    WLxgMbUFSYhRTCGDzmuHlVBfecvowp=WLxgMbUFSYhRTCGDzmuHlVBfecvoEy
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.add_dir(WLxgMbUFSYhRTCGDzmuHlVBfecvoij,sublabel='',img=WLxgMbUFSYhRTCGDzmuHlVBfecvowO,infoLabels=WLxgMbUFSYhRTCGDzmuHlVBfecvowy,isFolder=WLxgMbUFSYhRTCGDzmuHlVBfecvoEd,params=WLxgMbUFSYhRTCGDzmuHlVBfecvoiy,ContextMenu=WLxgMbUFSYhRTCGDzmuHlVBfecvowp)
  if WLxgMbUFSYhRTCGDzmuHlVBfecvoiN:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy={}
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy['mode'] ='MOVIE_LIST' 
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy['subapi']=WLxgMbUFSYhRTCGDzmuHlVBfecvotE 
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy['page'] =WLxgMbUFSYhRTCGDzmuHlVBfecvoEJ(WLxgMbUFSYhRTCGDzmuHlVBfecvowa+1)
   WLxgMbUFSYhRTCGDzmuHlVBfecvoij='[B]%s >>[/B]'%'다음 페이지'
   WLxgMbUFSYhRTCGDzmuHlVBfecvowP=WLxgMbUFSYhRTCGDzmuHlVBfecvoEJ(WLxgMbUFSYhRTCGDzmuHlVBfecvowa+1)
   WLxgMbUFSYhRTCGDzmuHlVBfecvoip=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.add_dir(WLxgMbUFSYhRTCGDzmuHlVBfecvoij,sublabel=WLxgMbUFSYhRTCGDzmuHlVBfecvowP,img=WLxgMbUFSYhRTCGDzmuHlVBfecvoip,infoLabels=WLxgMbUFSYhRTCGDzmuHlVBfecvoEy,isFolder=WLxgMbUFSYhRTCGDzmuHlVBfecvoEa,params=WLxgMbUFSYhRTCGDzmuHlVBfecvoiy)
  xbmcplugin.setContent(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn._addon_handle,'movies')
  if WLxgMbUFSYhRTCGDzmuHlVBfecvoEK(WLxgMbUFSYhRTCGDzmuHlVBfecvowd)>0:xbmcplugin.endOfDirectory(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn._addon_handle,cacheToDisc=WLxgMbUFSYhRTCGDzmuHlVBfecvoEd)
 def dp_Set_Bookmark(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn,args):
  WLxgMbUFSYhRTCGDzmuHlVBfecvotd=urllib.parse.unquote(args.get('bm_param'))
  WLxgMbUFSYhRTCGDzmuHlVBfecvotd=json.loads(WLxgMbUFSYhRTCGDzmuHlVBfecvotd)
  WLxgMbUFSYhRTCGDzmuHlVBfecvosI =WLxgMbUFSYhRTCGDzmuHlVBfecvotd.get('videoid')
  WLxgMbUFSYhRTCGDzmuHlVBfecvotX =WLxgMbUFSYhRTCGDzmuHlVBfecvotd.get('vidtype')
  WLxgMbUFSYhRTCGDzmuHlVBfecvotO =WLxgMbUFSYhRTCGDzmuHlVBfecvotd.get('vtitle')
  WLxgMbUFSYhRTCGDzmuHlVBfecvotA =WLxgMbUFSYhRTCGDzmuHlVBfecvotd.get('vsubtitle')
  WLxgMbUFSYhRTCGDzmuHlVBfecvotK=WLxgMbUFSYhRTCGDzmuHlVBfecvotd.get('contenttype')
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIy=xbmcgui.Dialog()
  WLxgMbUFSYhRTCGDzmuHlVBfecvosd=WLxgMbUFSYhRTCGDzmuHlVBfecvoIy.yesno(__language__(30913).encode('utf8'),WLxgMbUFSYhRTCGDzmuHlVBfecvotO+' \n\n'+__language__(30914))
  if WLxgMbUFSYhRTCGDzmuHlVBfecvosd==WLxgMbUFSYhRTCGDzmuHlVBfecvoEd:return
  WLxgMbUFSYhRTCGDzmuHlVBfecvotq=WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.GetBookmarkInfo(WLxgMbUFSYhRTCGDzmuHlVBfecvosI,WLxgMbUFSYhRTCGDzmuHlVBfecvotX,WLxgMbUFSYhRTCGDzmuHlVBfecvotK)
  WLxgMbUFSYhRTCGDzmuHlVBfecvotJ=json.dumps(WLxgMbUFSYhRTCGDzmuHlVBfecvotq)
  WLxgMbUFSYhRTCGDzmuHlVBfecvotJ=urllib.parse.quote(WLxgMbUFSYhRTCGDzmuHlVBfecvotJ)
  WLxgMbUFSYhRTCGDzmuHlVBfecvowJ ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(WLxgMbUFSYhRTCGDzmuHlVBfecvotJ)
  xbmc.executebuiltin(WLxgMbUFSYhRTCGDzmuHlVBfecvowJ)
 def dp_Episode_List(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn,args):
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.SaveCredential(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.get_winCredential())
  WLxgMbUFSYhRTCGDzmuHlVBfecvosI =args.get('videoid')
  WLxgMbUFSYhRTCGDzmuHlVBfecvotX =args.get('vidtype')
  WLxgMbUFSYhRTCGDzmuHlVBfecvowa=WLxgMbUFSYhRTCGDzmuHlVBfecvoEX(args.get('page'))
  WLxgMbUFSYhRTCGDzmuHlVBfecvowd,WLxgMbUFSYhRTCGDzmuHlVBfecvoiN=WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.Get_Episode_List(WLxgMbUFSYhRTCGDzmuHlVBfecvosI,WLxgMbUFSYhRTCGDzmuHlVBfecvotX,WLxgMbUFSYhRTCGDzmuHlVBfecvowa,orderby=WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.get_winEpisodeOrderby())
  for WLxgMbUFSYhRTCGDzmuHlVBfecvowX in WLxgMbUFSYhRTCGDzmuHlVBfecvowd:
   WLxgMbUFSYhRTCGDzmuHlVBfecvowP='%s회, %s(%s)'%(WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('episodenumber'),WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('releasedate'),WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('releaseweekday'))
   WLxgMbUFSYhRTCGDzmuHlVBfecvotP ='[%s]\n\n%s'%(WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('episodetitle'),WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('synopsis'))
   WLxgMbUFSYhRTCGDzmuHlVBfecvowy={'mediatype':'episode','title':WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('programtitle'),'year':WLxgMbUFSYhRTCGDzmuHlVBfecvoEX(WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('releasedate')[:4]),'aired':WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('releasedate'),'mpaa':WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('age'),'episode':WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('episodenumber'),'duration':WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('playtime'),'plot':WLxgMbUFSYhRTCGDzmuHlVBfecvotP,'cast':WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('episodeactors')}
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy={'mode':'VOD','programid':WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('programid'),'contentid':WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('contentid'),'thumbnail':WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('thumbnail'),'title':WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('programtitle'),'subtitle':WLxgMbUFSYhRTCGDzmuHlVBfecvowP}
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.add_dir(WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('programtitle'),sublabel=WLxgMbUFSYhRTCGDzmuHlVBfecvowP,img=WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('thumbnail'),infoLabels=WLxgMbUFSYhRTCGDzmuHlVBfecvowy,isFolder=WLxgMbUFSYhRTCGDzmuHlVBfecvoEd,params=WLxgMbUFSYhRTCGDzmuHlVBfecvoiy)
  if WLxgMbUFSYhRTCGDzmuHlVBfecvowa==1:
   WLxgMbUFSYhRTCGDzmuHlVBfecvowy={'plot':'정렬순서를 변경합니다.'}
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy={}
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy['mode'] ='ORDER_BY' 
   if WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.get_winEpisodeOrderby()=='desc':
    WLxgMbUFSYhRTCGDzmuHlVBfecvoij='정렬순서변경 : 최신화부터 -> 1회부터'
    WLxgMbUFSYhRTCGDzmuHlVBfecvoiy['orderby']='asc'
   else:
    WLxgMbUFSYhRTCGDzmuHlVBfecvoij='정렬순서변경 : 1회부터 -> 최신화부터'
    WLxgMbUFSYhRTCGDzmuHlVBfecvoiy['orderby']='desc'
   WLxgMbUFSYhRTCGDzmuHlVBfecvoip=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.add_dir(WLxgMbUFSYhRTCGDzmuHlVBfecvoij,sublabel='',img=WLxgMbUFSYhRTCGDzmuHlVBfecvoip,infoLabels=WLxgMbUFSYhRTCGDzmuHlVBfecvowy,isFolder=WLxgMbUFSYhRTCGDzmuHlVBfecvoEd,params=WLxgMbUFSYhRTCGDzmuHlVBfecvoiy,isLink=WLxgMbUFSYhRTCGDzmuHlVBfecvoEa)
  if WLxgMbUFSYhRTCGDzmuHlVBfecvoiN:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy={}
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy['mode'] ='EPISODE_LIST' 
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy['videoid']=WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('programid')
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy['vidtype']='programid'
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy['page'] =WLxgMbUFSYhRTCGDzmuHlVBfecvoEJ(WLxgMbUFSYhRTCGDzmuHlVBfecvowa+1)
   WLxgMbUFSYhRTCGDzmuHlVBfecvoij='[B]%s >>[/B]'%'다음 페이지'
   WLxgMbUFSYhRTCGDzmuHlVBfecvowP=WLxgMbUFSYhRTCGDzmuHlVBfecvoEJ(WLxgMbUFSYhRTCGDzmuHlVBfecvowa+1)
   WLxgMbUFSYhRTCGDzmuHlVBfecvoip=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.add_dir(WLxgMbUFSYhRTCGDzmuHlVBfecvoij,sublabel=WLxgMbUFSYhRTCGDzmuHlVBfecvowP,img=WLxgMbUFSYhRTCGDzmuHlVBfecvoip,infoLabels=WLxgMbUFSYhRTCGDzmuHlVBfecvoEy,isFolder=WLxgMbUFSYhRTCGDzmuHlVBfecvoEa,params=WLxgMbUFSYhRTCGDzmuHlVBfecvoiy)
  xbmcplugin.setContent(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn._addon_handle,'episodes')
  if WLxgMbUFSYhRTCGDzmuHlVBfecvoEK(WLxgMbUFSYhRTCGDzmuHlVBfecvowd)>0:xbmcplugin.endOfDirectory(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn._addon_handle,cacheToDisc=WLxgMbUFSYhRTCGDzmuHlVBfecvoEd)
 def dp_LiveChannel_List(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn,args):
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.SaveCredential(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.get_winCredential())
  WLxgMbUFSYhRTCGDzmuHlVBfecvotN =args.get('genre')
  WLxgMbUFSYhRTCGDzmuHlVBfecvotr=args.get('baseapi')
  WLxgMbUFSYhRTCGDzmuHlVBfecvowd=WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.Get_LiveChannel_List(WLxgMbUFSYhRTCGDzmuHlVBfecvotN,WLxgMbUFSYhRTCGDzmuHlVBfecvotr)
  for WLxgMbUFSYhRTCGDzmuHlVBfecvowX in WLxgMbUFSYhRTCGDzmuHlVBfecvowd:
   WLxgMbUFSYhRTCGDzmuHlVBfecvotp =WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('channelid')
   WLxgMbUFSYhRTCGDzmuHlVBfecvoty =WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('studio')
   WLxgMbUFSYhRTCGDzmuHlVBfecvota=WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('tvshowtitle')
   WLxgMbUFSYhRTCGDzmuHlVBfecvowO =WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('thumbnail')
   WLxgMbUFSYhRTCGDzmuHlVBfecvowA =WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('age')
   WLxgMbUFSYhRTCGDzmuHlVBfecvoEI =WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('epg')
   WLxgMbUFSYhRTCGDzmuHlVBfecvowy={'mediatype':'episode','mpaa':WLxgMbUFSYhRTCGDzmuHlVBfecvowA,'title':'%s < %s >'%(WLxgMbUFSYhRTCGDzmuHlVBfecvoty,WLxgMbUFSYhRTCGDzmuHlVBfecvota),'tvshowtitle':WLxgMbUFSYhRTCGDzmuHlVBfecvota,'studio':WLxgMbUFSYhRTCGDzmuHlVBfecvoty,'plot':'%s\n\n%s'%(WLxgMbUFSYhRTCGDzmuHlVBfecvoty,WLxgMbUFSYhRTCGDzmuHlVBfecvoEI)}
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy={'mode':'LIVE','contentid':WLxgMbUFSYhRTCGDzmuHlVBfecvotp}
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.add_dir(WLxgMbUFSYhRTCGDzmuHlVBfecvoty,sublabel=WLxgMbUFSYhRTCGDzmuHlVBfecvota,img=WLxgMbUFSYhRTCGDzmuHlVBfecvowO,infoLabels=WLxgMbUFSYhRTCGDzmuHlVBfecvowy,isFolder=WLxgMbUFSYhRTCGDzmuHlVBfecvoEd,params=WLxgMbUFSYhRTCGDzmuHlVBfecvoiy)
  if WLxgMbUFSYhRTCGDzmuHlVBfecvoEK(WLxgMbUFSYhRTCGDzmuHlVBfecvowd)>0:xbmcplugin.endOfDirectory(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn._addon_handle,cacheToDisc=WLxgMbUFSYhRTCGDzmuHlVBfecvoEd)
 def dp_Sports_GameList(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn,args):
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.SaveCredential(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.get_winCredential())
  WLxgMbUFSYhRTCGDzmuHlVBfecvowd=WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.WavveObj.Get_Sports_Gamelist()
  for WLxgMbUFSYhRTCGDzmuHlVBfecvowX in WLxgMbUFSYhRTCGDzmuHlVBfecvowd:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoEi =WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('game_date')
   WLxgMbUFSYhRTCGDzmuHlVBfecvoEw =WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('game_time')
   WLxgMbUFSYhRTCGDzmuHlVBfecvoEs =WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('svc_id')
   WLxgMbUFSYhRTCGDzmuHlVBfecvoEr =WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('away_team')
   WLxgMbUFSYhRTCGDzmuHlVBfecvoEt =WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('home_team')
   WLxgMbUFSYhRTCGDzmuHlVBfecvoEn=WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('game_status')
   WLxgMbUFSYhRTCGDzmuHlVBfecvoEj =WLxgMbUFSYhRTCGDzmuHlVBfecvowX.get('game_place')
   WLxgMbUFSYhRTCGDzmuHlVBfecvoEk ='%s vs %s (%s)'%(WLxgMbUFSYhRTCGDzmuHlVBfecvoEr,WLxgMbUFSYhRTCGDzmuHlVBfecvoEt,WLxgMbUFSYhRTCGDzmuHlVBfecvoEj)
   WLxgMbUFSYhRTCGDzmuHlVBfecvoEQ =WLxgMbUFSYhRTCGDzmuHlVBfecvoEi+' '+WLxgMbUFSYhRTCGDzmuHlVBfecvoEw
   if WLxgMbUFSYhRTCGDzmuHlVBfecvoEn=='LIVE':
    WLxgMbUFSYhRTCGDzmuHlVBfecvoEn='~경기중~'
   elif WLxgMbUFSYhRTCGDzmuHlVBfecvoEn=='END':
    WLxgMbUFSYhRTCGDzmuHlVBfecvoEn='경기종료'
   elif WLxgMbUFSYhRTCGDzmuHlVBfecvoEn=='CANCEL':
    WLxgMbUFSYhRTCGDzmuHlVBfecvoEn='취소'
   else:
    WLxgMbUFSYhRTCGDzmuHlVBfecvoEn=''
   if WLxgMbUFSYhRTCGDzmuHlVBfecvoEn=='':
    WLxgMbUFSYhRTCGDzmuHlVBfecvowP=WLxgMbUFSYhRTCGDzmuHlVBfecvoEk
   else:
    WLxgMbUFSYhRTCGDzmuHlVBfecvowP=WLxgMbUFSYhRTCGDzmuHlVBfecvoEk+'  '+WLxgMbUFSYhRTCGDzmuHlVBfecvoEn
   WLxgMbUFSYhRTCGDzmuHlVBfecvowy={'mediatype':'episode','title':WLxgMbUFSYhRTCGDzmuHlVBfecvoEk,'plot':'%s\n\n%s\n\n%s'%(WLxgMbUFSYhRTCGDzmuHlVBfecvoEQ,WLxgMbUFSYhRTCGDzmuHlVBfecvoEk,WLxgMbUFSYhRTCGDzmuHlVBfecvoEn)}
   WLxgMbUFSYhRTCGDzmuHlVBfecvoiy={'mode':'SPORTS','contentid':WLxgMbUFSYhRTCGDzmuHlVBfecvoEs}
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.add_dir(WLxgMbUFSYhRTCGDzmuHlVBfecvoEQ,sublabel=WLxgMbUFSYhRTCGDzmuHlVBfecvowP,img='',infoLabels=WLxgMbUFSYhRTCGDzmuHlVBfecvowy,isFolder=WLxgMbUFSYhRTCGDzmuHlVBfecvoEd,params=WLxgMbUFSYhRTCGDzmuHlVBfecvoiy)
  xbmcplugin.endOfDirectory(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn._addon_handle,cacheToDisc=WLxgMbUFSYhRTCGDzmuHlVBfecvoEd)
 def wavve_main(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn):
  WLxgMbUFSYhRTCGDzmuHlVBfecvoiq=WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.main_params.get('mode',WLxgMbUFSYhRTCGDzmuHlVBfecvoEy)
  if WLxgMbUFSYhRTCGDzmuHlVBfecvoiq=='LOGOUT':
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.logout()
   return
  WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.login_main()
  if WLxgMbUFSYhRTCGDzmuHlVBfecvoiq is WLxgMbUFSYhRTCGDzmuHlVBfecvoEy:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.dp_Main_List()
  elif WLxgMbUFSYhRTCGDzmuHlVBfecvoiq in['LIVE','VOD','MOVIE','SPORTS']:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.play_VIDEO(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.main_params)
  elif WLxgMbUFSYhRTCGDzmuHlVBfecvoiq=='LIVE_CATAGORY':
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.dp_LiveCatagory_List(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.main_params)
  elif WLxgMbUFSYhRTCGDzmuHlVBfecvoiq=='MAIN_CATAGORY':
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.dp_MainCatagory_List(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.main_params)
  elif WLxgMbUFSYhRTCGDzmuHlVBfecvoiq=='SUPERSECTION_LIST':
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.dp_SuperSection_List(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.main_params)
  elif WLxgMbUFSYhRTCGDzmuHlVBfecvoiq=='BANDLIVESECTION_LIST':
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.dp_BandLiveSection_List(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.main_params)
  elif WLxgMbUFSYhRTCGDzmuHlVBfecvoiq=='BAND2SECTION_LIST':
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.dp_Band2Section_List(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.main_params)
  elif WLxgMbUFSYhRTCGDzmuHlVBfecvoiq=='PROGRAM_LIST':
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.dp_Program_List(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.main_params)
  elif WLxgMbUFSYhRTCGDzmuHlVBfecvoiq=='EPISODE_LIST':
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.dp_Episode_List(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.main_params)
  elif WLxgMbUFSYhRTCGDzmuHlVBfecvoiq=='MOVIE_LIST':
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.dp_Movie_List(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.main_params)
  elif WLxgMbUFSYhRTCGDzmuHlVBfecvoiq=='LIVE_LIST':
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.dp_LiveChannel_List(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.main_params)
  elif WLxgMbUFSYhRTCGDzmuHlVBfecvoiq=='ORDER_BY':
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.dp_setEpOrderby(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.main_params)
  elif WLxgMbUFSYhRTCGDzmuHlVBfecvoiq=='SEARCH_GROUP':
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.dp_Search_Group(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.main_params)
  elif WLxgMbUFSYhRTCGDzmuHlVBfecvoiq in['SEARCH_LIST','LOCAL_SEARCH']:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.dp_Search_List(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.main_params)
  elif WLxgMbUFSYhRTCGDzmuHlVBfecvoiq=='WATCH_GROUP':
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.dp_Watch_Group(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.main_params)
  elif WLxgMbUFSYhRTCGDzmuHlVBfecvoiq=='WATCH_LIST':
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.dp_Watch_List(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.main_params)
  elif WLxgMbUFSYhRTCGDzmuHlVBfecvoiq=='SET_BOOKMARK':
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.dp_Set_Bookmark(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.main_params)
  elif WLxgMbUFSYhRTCGDzmuHlVBfecvoiq in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.dp_Listfile_Delete(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.main_params)
  elif WLxgMbUFSYhRTCGDzmuHlVBfecvoiq in['TOTAL_SEARCH','TOTAL_HISTORY']:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.dp_Global_Search(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.main_params)
  elif WLxgMbUFSYhRTCGDzmuHlVBfecvoiq=='SEARCH_HISTORY':
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.dp_Search_History(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.main_params)
  elif WLxgMbUFSYhRTCGDzmuHlVBfecvoiq=='MENU_BOOKMARK':
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.dp_Bookmark_Menu(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.main_params)
  elif WLxgMbUFSYhRTCGDzmuHlVBfecvoiq=='GAME_LIST':
   WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.dp_Sports_GameList(WLxgMbUFSYhRTCGDzmuHlVBfecvoIn.main_params)
  else:
   WLxgMbUFSYhRTCGDzmuHlVBfecvoEy
# Created by pyminifier (https://github.com/liftoff/pyminifier)
