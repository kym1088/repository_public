__author__="NightRain"
VrfXREhLNImCbniAzqstedjvUWoGJp=object
VrfXREhLNImCbniAzqstedjvUWoGJO=None
VrfXREhLNImCbniAzqstedjvUWoGJc=int
VrfXREhLNImCbniAzqstedjvUWoGJx=False
VrfXREhLNImCbniAzqstedjvUWoGJl=True
VrfXREhLNImCbniAzqstedjvUWoGJT=len
VrfXREhLNImCbniAzqstedjvUWoGky=str
VrfXREhLNImCbniAzqstedjvUWoGkS=dict
VrfXREhLNImCbniAzqstedjvUWoGkw=open
VrfXREhLNImCbniAzqstedjvUWoGkP=Exception
VrfXREhLNImCbniAzqstedjvUWoGkJ=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
VrfXREhLNImCbniAzqstedjvUWoGyw=[{'title':'홈','uicode':'GN1','came':'home'},{'title':'LIVE 채널','uicode':'GN3','came':'live'},{'title':'VOD 방송','uicode':'GN2','came':'broadcast'},{'title':'영화(Movie)','uicode':'GN17','came':'movie'},{'title':'해외시리즈','uicode':'GN12','came':'global'},{'title':'분류별 - 방송(VOD) - 인기순','uicode':'GENRE','came':'vodgenre','orderby':'viewtime','ordernm':'인기순'},{'title':'분류별 - 방송(VOD) - 최신순','uicode':'GENRE','came':'vodgenre','orderby':'new','ordernm':'최신순'},{'title':'분류별 - 영화(Movie) - 인기순','uicode':'GENRE','came':'moviegenre_svod','orderby':'paid','ordernm':'인기순'},{'title':'분류별 - 영화(Movie) - 업데이트순','uicode':'GENRE','came':'moviegenre_svod','orderby':'displaystart','ordernm':'업데이트순'},{'title':'검색','uicode':'SEARCH','came':'-'},{'title':'Watched(시청목록)','uicode':'WATCH','came':'-'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmc.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
VrfXREhLNImCbniAzqstedjvUWoGyP='Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'
VrfXREhLNImCbniAzqstedjvUWoGyJ=xbmc.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
from wavveCore import*
class VrfXREhLNImCbniAzqstedjvUWoGyS(VrfXREhLNImCbniAzqstedjvUWoGJp):
 def __init__(VrfXREhLNImCbniAzqstedjvUWoGyk,VrfXREhLNImCbniAzqstedjvUWoGyY,VrfXREhLNImCbniAzqstedjvUWoGyB,VrfXREhLNImCbniAzqstedjvUWoGyg):
  VrfXREhLNImCbniAzqstedjvUWoGyk._addon_url =VrfXREhLNImCbniAzqstedjvUWoGyY
  VrfXREhLNImCbniAzqstedjvUWoGyk._addon_handle=VrfXREhLNImCbniAzqstedjvUWoGyB
  VrfXREhLNImCbniAzqstedjvUWoGyk.main_params =VrfXREhLNImCbniAzqstedjvUWoGyg
  VrfXREhLNImCbniAzqstedjvUWoGyk.WavveObj =wxlSzvIeAMOCFGqWaNrHTiPhEQcgJB() 
 def addon_noti(VrfXREhLNImCbniAzqstedjvUWoGyk,sting):
  try:
   VrfXREhLNImCbniAzqstedjvUWoGya=xbmcgui.Dialog()
   VrfXREhLNImCbniAzqstedjvUWoGya.notification(__addonname__,sting)
  except:
   VrfXREhLNImCbniAzqstedjvUWoGJO
 def addon_log(VrfXREhLNImCbniAzqstedjvUWoGyk,string):
  try:
   VrfXREhLNImCbniAzqstedjvUWoGyK=string.encode('utf-8','ignore')
  except:
   VrfXREhLNImCbniAzqstedjvUWoGyK='addonException: addon_log'
  VrfXREhLNImCbniAzqstedjvUWoGyF=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,VrfXREhLNImCbniAzqstedjvUWoGyK),level=VrfXREhLNImCbniAzqstedjvUWoGyF)
 def get_keyboard_input(VrfXREhLNImCbniAzqstedjvUWoGyk,VrfXREhLNImCbniAzqstedjvUWoGSP):
  VrfXREhLNImCbniAzqstedjvUWoGyH=VrfXREhLNImCbniAzqstedjvUWoGJO
  kb=xbmc.Keyboard()
  kb.setHeading(VrfXREhLNImCbniAzqstedjvUWoGSP)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   VrfXREhLNImCbniAzqstedjvUWoGyH=kb.getText()
  return VrfXREhLNImCbniAzqstedjvUWoGyH
 def get_settings_login_info(VrfXREhLNImCbniAzqstedjvUWoGyk):
  VrfXREhLNImCbniAzqstedjvUWoGyD =__addon__.getSetting('id')
  VrfXREhLNImCbniAzqstedjvUWoGyQ =__addon__.getSetting('pw')
  VrfXREhLNImCbniAzqstedjvUWoGyu=__addon__.getSetting('selected_profile')
  return(VrfXREhLNImCbniAzqstedjvUWoGyD,VrfXREhLNImCbniAzqstedjvUWoGyQ,VrfXREhLNImCbniAzqstedjvUWoGyu)
 def get_selQuality(VrfXREhLNImCbniAzqstedjvUWoGyk):
  try:
   VrfXREhLNImCbniAzqstedjvUWoGyp=[1080,720,480,360]
   VrfXREhLNImCbniAzqstedjvUWoGyO=VrfXREhLNImCbniAzqstedjvUWoGJc(__addon__.getSetting('selected_quality'))
   return VrfXREhLNImCbniAzqstedjvUWoGyp[VrfXREhLNImCbniAzqstedjvUWoGyO]
  except:
   VrfXREhLNImCbniAzqstedjvUWoGJO
  return 1080 
 def get_settings_exclusion21(VrfXREhLNImCbniAzqstedjvUWoGyk):
  VrfXREhLNImCbniAzqstedjvUWoGyc =__addon__.getSetting('exclusion21')
  if VrfXREhLNImCbniAzqstedjvUWoGyc=='false':
   return VrfXREhLNImCbniAzqstedjvUWoGJx
  else:
   return VrfXREhLNImCbniAzqstedjvUWoGJl
 def get_settings_direct_replay(VrfXREhLNImCbniAzqstedjvUWoGyk):
  VrfXREhLNImCbniAzqstedjvUWoGyx=VrfXREhLNImCbniAzqstedjvUWoGJc(__addon__.getSetting('direct_replay'))
  if VrfXREhLNImCbniAzqstedjvUWoGyx==0:
   return VrfXREhLNImCbniAzqstedjvUWoGJx
  else:
   return VrfXREhLNImCbniAzqstedjvUWoGJl
 def get_settings_addinfo(VrfXREhLNImCbniAzqstedjvUWoGyk):
  VrfXREhLNImCbniAzqstedjvUWoGyl =__addon__.getSetting('add_infoyn')
  if VrfXREhLNImCbniAzqstedjvUWoGyl=='false':
   return VrfXREhLNImCbniAzqstedjvUWoGJx
  else:
   return VrfXREhLNImCbniAzqstedjvUWoGJl
 def get_settings_thumbnail_landyn(VrfXREhLNImCbniAzqstedjvUWoGyk):
  VrfXREhLNImCbniAzqstedjvUWoGyT =VrfXREhLNImCbniAzqstedjvUWoGJc(__addon__.getSetting('thumbnail_way'))
  if VrfXREhLNImCbniAzqstedjvUWoGyT==0:
   return VrfXREhLNImCbniAzqstedjvUWoGJl
  else:
   return VrfXREhLNImCbniAzqstedjvUWoGJx
 def set_winCredential(VrfXREhLNImCbniAzqstedjvUWoGyk,credential):
  VrfXREhLNImCbniAzqstedjvUWoGSy=xbmcgui.Window(10000)
  VrfXREhLNImCbniAzqstedjvUWoGSy.setProperty('WAVVE_M_CREDENTIAL',credential)
  VrfXREhLNImCbniAzqstedjvUWoGSy.setProperty('WAVVE_M_LOGINTIME',VrfXREhLNImCbniAzqstedjvUWoGyk.WavveObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(VrfXREhLNImCbniAzqstedjvUWoGyk):
  VrfXREhLNImCbniAzqstedjvUWoGSy=xbmcgui.Window(10000)
  return VrfXREhLNImCbniAzqstedjvUWoGSy.getProperty('WAVVE_M_CREDENTIAL')
 def set_winEpisodeOrderby(VrfXREhLNImCbniAzqstedjvUWoGyk,VrfXREhLNImCbniAzqstedjvUWoGSu):
  VrfXREhLNImCbniAzqstedjvUWoGSy=xbmcgui.Window(10000)
  VrfXREhLNImCbniAzqstedjvUWoGSy.setProperty('WAVVE_M_ORDERBY',VrfXREhLNImCbniAzqstedjvUWoGSu)
 def get_winEpisodeOrderby(VrfXREhLNImCbniAzqstedjvUWoGyk):
  VrfXREhLNImCbniAzqstedjvUWoGSy=xbmcgui.Window(10000)
  return VrfXREhLNImCbniAzqstedjvUWoGSy.getProperty('WAVVE_M_ORDERBY')
 def add_dir(VrfXREhLNImCbniAzqstedjvUWoGyk,label,sublabel='',img='',infoLabels=VrfXREhLNImCbniAzqstedjvUWoGJO,isFolder=VrfXREhLNImCbniAzqstedjvUWoGJl,params=''):
  VrfXREhLNImCbniAzqstedjvUWoGSw='%s?%s'%(VrfXREhLNImCbniAzqstedjvUWoGyk._addon_url,urllib.parse.urlencode(params))
  if sublabel:VrfXREhLNImCbniAzqstedjvUWoGSP='%s < %s >'%(label,sublabel)
  else: VrfXREhLNImCbniAzqstedjvUWoGSP=label
  if not img:img='DefaultFolder.png'
  VrfXREhLNImCbniAzqstedjvUWoGSJ=xbmcgui.ListItem(VrfXREhLNImCbniAzqstedjvUWoGSP)
  VrfXREhLNImCbniAzqstedjvUWoGSJ.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:VrfXREhLNImCbniAzqstedjvUWoGSJ.setInfo(type="video",infoLabels=infoLabels)
  if not isFolder:VrfXREhLNImCbniAzqstedjvUWoGSJ.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(VrfXREhLNImCbniAzqstedjvUWoGyk._addon_handle,VrfXREhLNImCbniAzqstedjvUWoGSw,VrfXREhLNImCbniAzqstedjvUWoGSJ,isFolder)
 def dp_Main_List(VrfXREhLNImCbniAzqstedjvUWoGyk):
  for VrfXREhLNImCbniAzqstedjvUWoGSk in VrfXREhLNImCbniAzqstedjvUWoGyw:
   VrfXREhLNImCbniAzqstedjvUWoGSP=VrfXREhLNImCbniAzqstedjvUWoGSk.get('title')
   if VrfXREhLNImCbniAzqstedjvUWoGSk.get('uicode')=='GENRE':
    VrfXREhLNImCbniAzqstedjvUWoGSY={'mode':'GENRE','uicode':VrfXREhLNImCbniAzqstedjvUWoGSk.get('came'),'genre':'-','subgenre':'-','orderby':VrfXREhLNImCbniAzqstedjvUWoGSk.get('orderby'),'ordernm':VrfXREhLNImCbniAzqstedjvUWoGSk.get('ordernm')}
   elif VrfXREhLNImCbniAzqstedjvUWoGSk.get('uicode')=='WATCH':
    VrfXREhLNImCbniAzqstedjvUWoGSY={'mode':'WATCH','genre':'-'}
   elif VrfXREhLNImCbniAzqstedjvUWoGSk.get('uicode')=='SEARCH':
    VrfXREhLNImCbniAzqstedjvUWoGSY={'mode':'SEARCH','genre':'-'}
   else:
    VrfXREhLNImCbniAzqstedjvUWoGSY={'mode':'GNB_LIST','uicode':VrfXREhLNImCbniAzqstedjvUWoGSk.get('uicode'),'came':VrfXREhLNImCbniAzqstedjvUWoGSk.get('came')}
   VrfXREhLNImCbniAzqstedjvUWoGSB=VrfXREhLNImCbniAzqstedjvUWoGJl
   if VrfXREhLNImCbniAzqstedjvUWoGSk.get('uicode')=='XXX':
    VrfXREhLNImCbniAzqstedjvUWoGSY['mode']='XXX'
    VrfXREhLNImCbniAzqstedjvUWoGSB=VrfXREhLNImCbniAzqstedjvUWoGJx
   VrfXREhLNImCbniAzqstedjvUWoGyk.add_dir(VrfXREhLNImCbniAzqstedjvUWoGSP,sublabel='',img='',infoLabels=VrfXREhLNImCbniAzqstedjvUWoGJO,isFolder=VrfXREhLNImCbniAzqstedjvUWoGSB,params=VrfXREhLNImCbniAzqstedjvUWoGSY)
  if VrfXREhLNImCbniAzqstedjvUWoGJT(VrfXREhLNImCbniAzqstedjvUWoGyw)>0:xbmcplugin.endOfDirectory(VrfXREhLNImCbniAzqstedjvUWoGyk._addon_handle)
 def login_main(VrfXREhLNImCbniAzqstedjvUWoGyk):
  (VrfXREhLNImCbniAzqstedjvUWoGSM,VrfXREhLNImCbniAzqstedjvUWoGSa,VrfXREhLNImCbniAzqstedjvUWoGSK)=VrfXREhLNImCbniAzqstedjvUWoGyk.get_settings_login_info()
  if not(VrfXREhLNImCbniAzqstedjvUWoGSM and VrfXREhLNImCbniAzqstedjvUWoGSa):
   VrfXREhLNImCbniAzqstedjvUWoGya=xbmcgui.Dialog()
   VrfXREhLNImCbniAzqstedjvUWoGSF=VrfXREhLNImCbniAzqstedjvUWoGya.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if VrfXREhLNImCbniAzqstedjvUWoGSF==VrfXREhLNImCbniAzqstedjvUWoGJl:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if VrfXREhLNImCbniAzqstedjvUWoGyk.get_winEpisodeOrderby()=='':
   VrfXREhLNImCbniAzqstedjvUWoGyk.set_winEpisodeOrderby('desc')
  if VrfXREhLNImCbniAzqstedjvUWoGyk.cookiefile_check():return
  VrfXREhLNImCbniAzqstedjvUWoGSH =VrfXREhLNImCbniAzqstedjvUWoGJc(VrfXREhLNImCbniAzqstedjvUWoGyk.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  VrfXREhLNImCbniAzqstedjvUWoGSD=xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINTIME')
  if VrfXREhLNImCbniAzqstedjvUWoGSD==VrfXREhLNImCbniAzqstedjvUWoGJO or VrfXREhLNImCbniAzqstedjvUWoGSD=='':
   VrfXREhLNImCbniAzqstedjvUWoGSD=VrfXREhLNImCbniAzqstedjvUWoGJc('19000101')
  else:
   VrfXREhLNImCbniAzqstedjvUWoGSD=VrfXREhLNImCbniAzqstedjvUWoGJc(re.sub('-','',VrfXREhLNImCbniAzqstedjvUWoGSD))
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   VrfXREhLNImCbniAzqstedjvUWoGSQ=0
   while VrfXREhLNImCbniAzqstedjvUWoGJl:
    VrfXREhLNImCbniAzqstedjvUWoGSQ+=1
    time.sleep(0.05)
    if VrfXREhLNImCbniAzqstedjvUWoGSD>=VrfXREhLNImCbniAzqstedjvUWoGSH:return
    if VrfXREhLNImCbniAzqstedjvUWoGSQ>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  if VrfXREhLNImCbniAzqstedjvUWoGSD>=VrfXREhLNImCbniAzqstedjvUWoGSH:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   return
  if not VrfXREhLNImCbniAzqstedjvUWoGyk.WavveObj.GetCredential(VrfXREhLNImCbniAzqstedjvUWoGSM,VrfXREhLNImCbniAzqstedjvUWoGSa,VrfXREhLNImCbniAzqstedjvUWoGSK):
   VrfXREhLNImCbniAzqstedjvUWoGyk.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   sys.exit()
  VrfXREhLNImCbniAzqstedjvUWoGyk.set_winCredential(VrfXREhLNImCbniAzqstedjvUWoGyk.WavveObj.LoadCredential())
  VrfXREhLNImCbniAzqstedjvUWoGyk.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
 def dp_setEpOrderby(VrfXREhLNImCbniAzqstedjvUWoGyk,args):
  VrfXREhLNImCbniAzqstedjvUWoGSu =args.get('orderby')
  VrfXREhLNImCbniAzqstedjvUWoGyk.set_winEpisodeOrderby(VrfXREhLNImCbniAzqstedjvUWoGSu)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Gnb_List(VrfXREhLNImCbniAzqstedjvUWoGyk,args):
  VrfXREhLNImCbniAzqstedjvUWoGyk.WavveObj.SaveCredential(VrfXREhLNImCbniAzqstedjvUWoGyk.get_winCredential())
  VrfXREhLNImCbniAzqstedjvUWoGSp=VrfXREhLNImCbniAzqstedjvUWoGyk.WavveObj.GetGnList(args.get('uicode'))
  for VrfXREhLNImCbniAzqstedjvUWoGSO in VrfXREhLNImCbniAzqstedjvUWoGSp:
   VrfXREhLNImCbniAzqstedjvUWoGSP=VrfXREhLNImCbniAzqstedjvUWoGSO.get('title')
   VrfXREhLNImCbniAzqstedjvUWoGSY={'mode':'GN_LIST' if VrfXREhLNImCbniAzqstedjvUWoGSO.get('uicode')!='CY1' else 'GN_MYVIEW','uicode':VrfXREhLNImCbniAzqstedjvUWoGSO.get('uicode'),'came':args.get('came'),'page':'1'}
   VrfXREhLNImCbniAzqstedjvUWoGyk.add_dir(VrfXREhLNImCbniAzqstedjvUWoGSP,sublabel='',img='',infoLabels=VrfXREhLNImCbniAzqstedjvUWoGJO,isFolder=VrfXREhLNImCbniAzqstedjvUWoGJl,params=VrfXREhLNImCbniAzqstedjvUWoGSY)
  if VrfXREhLNImCbniAzqstedjvUWoGJT(VrfXREhLNImCbniAzqstedjvUWoGSp)>0:xbmcplugin.endOfDirectory(VrfXREhLNImCbniAzqstedjvUWoGyk._addon_handle,cacheToDisc=VrfXREhLNImCbniAzqstedjvUWoGJx)
 def dp_Myview_Group(VrfXREhLNImCbniAzqstedjvUWoGyk,args):
  VrfXREhLNImCbniAzqstedjvUWoGSP='VOD 시청내역'
  VrfXREhLNImCbniAzqstedjvUWoGSY={'mode':'MYVIEW_LIST','uicode':'vod','page':'1'}
  VrfXREhLNImCbniAzqstedjvUWoGyk.add_dir(VrfXREhLNImCbniAzqstedjvUWoGSP,sublabel='',img='',infoLabels=VrfXREhLNImCbniAzqstedjvUWoGJO,isFolder=VrfXREhLNImCbniAzqstedjvUWoGJl,params=VrfXREhLNImCbniAzqstedjvUWoGSY)
  VrfXREhLNImCbniAzqstedjvUWoGSP='영화 시청내역'
  VrfXREhLNImCbniAzqstedjvUWoGSY['uicode']='movie'
  VrfXREhLNImCbniAzqstedjvUWoGyk.add_dir(VrfXREhLNImCbniAzqstedjvUWoGSP,sublabel='',img='',infoLabels=VrfXREhLNImCbniAzqstedjvUWoGJO,isFolder=VrfXREhLNImCbniAzqstedjvUWoGJl,params=VrfXREhLNImCbniAzqstedjvUWoGSY)
  xbmcplugin.endOfDirectory(VrfXREhLNImCbniAzqstedjvUWoGyk._addon_handle)
 def dp_Myview_List(VrfXREhLNImCbniAzqstedjvUWoGyk,args):
  VrfXREhLNImCbniAzqstedjvUWoGyk.WavveObj.SaveCredential(VrfXREhLNImCbniAzqstedjvUWoGyk.get_winCredential())
  VrfXREhLNImCbniAzqstedjvUWoGSc =VrfXREhLNImCbniAzqstedjvUWoGyk.get_settings_addinfo()
  VrfXREhLNImCbniAzqstedjvUWoGSx=args.get('uicode')
  VrfXREhLNImCbniAzqstedjvUWoGSl =VrfXREhLNImCbniAzqstedjvUWoGJc(args.get('page'))
  VrfXREhLNImCbniAzqstedjvUWoGST,VrfXREhLNImCbniAzqstedjvUWoGwy=VrfXREhLNImCbniAzqstedjvUWoGyk.WavveObj.GetMyviewList(VrfXREhLNImCbniAzqstedjvUWoGSx,VrfXREhLNImCbniAzqstedjvUWoGSl,addinfoyn=VrfXREhLNImCbniAzqstedjvUWoGSc)
  for VrfXREhLNImCbniAzqstedjvUWoGwS in VrfXREhLNImCbniAzqstedjvUWoGST:
   VrfXREhLNImCbniAzqstedjvUWoGSP =VrfXREhLNImCbniAzqstedjvUWoGwS.get('title')
   VrfXREhLNImCbniAzqstedjvUWoGwP =VrfXREhLNImCbniAzqstedjvUWoGwS.get('subtitle')
   VrfXREhLNImCbniAzqstedjvUWoGwJ=VrfXREhLNImCbniAzqstedjvUWoGwS.get('thumbnail')
   VrfXREhLNImCbniAzqstedjvUWoGwk=VrfXREhLNImCbniAzqstedjvUWoGwS.get('info')
   if VrfXREhLNImCbniAzqstedjvUWoGSx=='movie' and VrfXREhLNImCbniAzqstedjvUWoGSc==VrfXREhLNImCbniAzqstedjvUWoGJl:
    VrfXREhLNImCbniAzqstedjvUWoGSP='%s (%s)'%(VrfXREhLNImCbniAzqstedjvUWoGSP,VrfXREhLNImCbniAzqstedjvUWoGky(VrfXREhLNImCbniAzqstedjvUWoGwk.get('year')))
   else:
    VrfXREhLNImCbniAzqstedjvUWoGwk['plot']=VrfXREhLNImCbniAzqstedjvUWoGSP
   if VrfXREhLNImCbniAzqstedjvUWoGSx=='vod':
    VrfXREhLNImCbniAzqstedjvUWoGSY={'mode':'DEEP_LIST','contentid':VrfXREhLNImCbniAzqstedjvUWoGwS.get('programid'),'contentidType':'programid','uicode':'vod','page':'1','title':VrfXREhLNImCbniAzqstedjvUWoGSP,'subtitle':VrfXREhLNImCbniAzqstedjvUWoGwP,'thumbnail':VrfXREhLNImCbniAzqstedjvUWoGwJ,'viewage':VrfXREhLNImCbniAzqstedjvUWoGwS.get('viewage')}
    VrfXREhLNImCbniAzqstedjvUWoGSB=VrfXREhLNImCbniAzqstedjvUWoGJl
   else:
    VrfXREhLNImCbniAzqstedjvUWoGSY={'mode':'MOVIE','contentid':VrfXREhLNImCbniAzqstedjvUWoGwS.get('contentid'),'contentidType':'contentid','uicode':'movie','page':'1','title':VrfXREhLNImCbniAzqstedjvUWoGSP,'subtitle':VrfXREhLNImCbniAzqstedjvUWoGwP,'thumbnail':VrfXREhLNImCbniAzqstedjvUWoGwJ,'viewage':VrfXREhLNImCbniAzqstedjvUWoGwS.get('viewage')}
    VrfXREhLNImCbniAzqstedjvUWoGSB=VrfXREhLNImCbniAzqstedjvUWoGJx
   if VrfXREhLNImCbniAzqstedjvUWoGwS.get('viewage')=='21':VrfXREhLNImCbniAzqstedjvUWoGwP+=' (%s)'%(VrfXREhLNImCbniAzqstedjvUWoGwS.get('viewage'))
   VrfXREhLNImCbniAzqstedjvUWoGyk.add_dir(VrfXREhLNImCbniAzqstedjvUWoGSP,sublabel=VrfXREhLNImCbniAzqstedjvUWoGwP,img=VrfXREhLNImCbniAzqstedjvUWoGwJ,infoLabels=VrfXREhLNImCbniAzqstedjvUWoGwk,isFolder=VrfXREhLNImCbniAzqstedjvUWoGSB,params=VrfXREhLNImCbniAzqstedjvUWoGSY)
  if VrfXREhLNImCbniAzqstedjvUWoGwy:
   VrfXREhLNImCbniAzqstedjvUWoGSY['mode'] ='MYVIEW_LIST' 
   VrfXREhLNImCbniAzqstedjvUWoGSY['uicode']=VrfXREhLNImCbniAzqstedjvUWoGSx 
   VrfXREhLNImCbniAzqstedjvUWoGSY['page'] =VrfXREhLNImCbniAzqstedjvUWoGky(VrfXREhLNImCbniAzqstedjvUWoGSl+1)
   VrfXREhLNImCbniAzqstedjvUWoGSP='[B]%s >>[/B]'%'다음 페이지'
   VrfXREhLNImCbniAzqstedjvUWoGwP=VrfXREhLNImCbniAzqstedjvUWoGky(VrfXREhLNImCbniAzqstedjvUWoGSl+1)
   VrfXREhLNImCbniAzqstedjvUWoGyk.add_dir(VrfXREhLNImCbniAzqstedjvUWoGSP,sublabel=VrfXREhLNImCbniAzqstedjvUWoGwP,img='',infoLabels=VrfXREhLNImCbniAzqstedjvUWoGJO,isFolder=VrfXREhLNImCbniAzqstedjvUWoGJl,params=VrfXREhLNImCbniAzqstedjvUWoGSY)
  if VrfXREhLNImCbniAzqstedjvUWoGJT(VrfXREhLNImCbniAzqstedjvUWoGST)>0:xbmcplugin.endOfDirectory(VrfXREhLNImCbniAzqstedjvUWoGyk._addon_handle,cacheToDisc=VrfXREhLNImCbniAzqstedjvUWoGJx)
 def dp_Genre_Group(VrfXREhLNImCbniAzqstedjvUWoGyk,args):
  VrfXREhLNImCbniAzqstedjvUWoGyk.WavveObj.SaveCredential(VrfXREhLNImCbniAzqstedjvUWoGyk.get_winCredential())
  VrfXREhLNImCbniAzqstedjvUWoGwY =args.get('mode') 
  VrfXREhLNImCbniAzqstedjvUWoGwB =args.get('uicode')
  VrfXREhLNImCbniAzqstedjvUWoGwg =args.get('genre') 
  VrfXREhLNImCbniAzqstedjvUWoGwM=args.get('subgenre')
  VrfXREhLNImCbniAzqstedjvUWoGSu =args.get('orderby')
  VrfXREhLNImCbniAzqstedjvUWoGwa =args.get('ordernm')
  if VrfXREhLNImCbniAzqstedjvUWoGwg=='-':
   VrfXREhLNImCbniAzqstedjvUWoGwK=VrfXREhLNImCbniAzqstedjvUWoGyk.WavveObj.GetGenreGroup(VrfXREhLNImCbniAzqstedjvUWoGwB,VrfXREhLNImCbniAzqstedjvUWoGwg,VrfXREhLNImCbniAzqstedjvUWoGSu,VrfXREhLNImCbniAzqstedjvUWoGwa,exclusion21=VrfXREhLNImCbniAzqstedjvUWoGyk.get_settings_exclusion21())
  else:
   VrfXREhLNImCbniAzqstedjvUWoGwF={'adult':args.get('adult'),'broadcastid':args.get('broadcastid'),'contenttype':args.get('contenttype'),'genre':args.get('genre'),'uiparent':args.get('uiparent'),'uirank':args.get('uirank'),'uitype':args.get('uitype'),'orderby':VrfXREhLNImCbniAzqstedjvUWoGSu,'ordernm':VrfXREhLNImCbniAzqstedjvUWoGwa}
   VrfXREhLNImCbniAzqstedjvUWoGwK=VrfXREhLNImCbniAzqstedjvUWoGyk.WavveObj.GetGenreGroup_sub(VrfXREhLNImCbniAzqstedjvUWoGwF)
  for VrfXREhLNImCbniAzqstedjvUWoGwH in VrfXREhLNImCbniAzqstedjvUWoGwK:
   VrfXREhLNImCbniAzqstedjvUWoGSP =VrfXREhLNImCbniAzqstedjvUWoGwH.get('title')+'  ('+VrfXREhLNImCbniAzqstedjvUWoGwa+')'
   VrfXREhLNImCbniAzqstedjvUWoGSY={'mode':VrfXREhLNImCbniAzqstedjvUWoGwY,'uicode':VrfXREhLNImCbniAzqstedjvUWoGwB,'genre':VrfXREhLNImCbniAzqstedjvUWoGwH.get('genre'),'subgenre':VrfXREhLNImCbniAzqstedjvUWoGwH.get('subgenre'),'adult':VrfXREhLNImCbniAzqstedjvUWoGwH.get('adult'),'page':'1','broadcastid':VrfXREhLNImCbniAzqstedjvUWoGwH.get('broadcastid'),'contenttype':VrfXREhLNImCbniAzqstedjvUWoGwH.get('contenttype'),'uiparent':VrfXREhLNImCbniAzqstedjvUWoGwH.get('uiparent'),'uirank':VrfXREhLNImCbniAzqstedjvUWoGwH.get('uirank'),'uitype':VrfXREhLNImCbniAzqstedjvUWoGwH.get('uitype'),'orderby':VrfXREhLNImCbniAzqstedjvUWoGSu,'ordernm':VrfXREhLNImCbniAzqstedjvUWoGwa}
   if VrfXREhLNImCbniAzqstedjvUWoGwB=='moviegenre' or VrfXREhLNImCbniAzqstedjvUWoGwB=='moviegenre_svod' or VrfXREhLNImCbniAzqstedjvUWoGwB=='moviegenre_ppv' or VrfXREhLNImCbniAzqstedjvUWoGwH.get('subgenre')!='-':
    VrfXREhLNImCbniAzqstedjvUWoGSY['mode'] ='GENRE_LIST'
   else:
    VrfXREhLNImCbniAzqstedjvUWoGJO
   VrfXREhLNImCbniAzqstedjvUWoGyk.add_dir(VrfXREhLNImCbniAzqstedjvUWoGSP,sublabel='',img='',infoLabels=VrfXREhLNImCbniAzqstedjvUWoGJO,isFolder=VrfXREhLNImCbniAzqstedjvUWoGJl,params=VrfXREhLNImCbniAzqstedjvUWoGSY)
  if VrfXREhLNImCbniAzqstedjvUWoGJT(VrfXREhLNImCbniAzqstedjvUWoGwK)>0:xbmcplugin.endOfDirectory(VrfXREhLNImCbniAzqstedjvUWoGyk._addon_handle,cacheToDisc=VrfXREhLNImCbniAzqstedjvUWoGJx)
 def dp_Genre_List(VrfXREhLNImCbniAzqstedjvUWoGyk,args):
  VrfXREhLNImCbniAzqstedjvUWoGyk.WavveObj.SaveCredential(VrfXREhLNImCbniAzqstedjvUWoGyk.get_winCredential())
  VrfXREhLNImCbniAzqstedjvUWoGSc=VrfXREhLNImCbniAzqstedjvUWoGyk.get_settings_addinfo()
  VrfXREhLNImCbniAzqstedjvUWoGwB =args.get('uicode')
  VrfXREhLNImCbniAzqstedjvUWoGSl=VrfXREhLNImCbniAzqstedjvUWoGJc(args.get('page'))
  VrfXREhLNImCbniAzqstedjvUWoGSY={'adult':args.get('adult'),'broadcastid':args.get('broadcastid'),'contenttype':args.get('contenttype'),'genre':args.get('genre'),'subgenre':args.get('subgenre'),'uiparent':args.get('uiparent'),'uirank':args.get('uirank'),'uitype':args.get('uitype'),'orderby':args.get('orderby')}
  if args.get('genre')==args.get('subgenre'):
   VrfXREhLNImCbniAzqstedjvUWoGSY['subgenre']='all'
  VrfXREhLNImCbniAzqstedjvUWoGwK,VrfXREhLNImCbniAzqstedjvUWoGwy=VrfXREhLNImCbniAzqstedjvUWoGyk.WavveObj.GetGenreList(VrfXREhLNImCbniAzqstedjvUWoGwB,VrfXREhLNImCbniAzqstedjvUWoGSY,VrfXREhLNImCbniAzqstedjvUWoGSl,addinfoyn=VrfXREhLNImCbniAzqstedjvUWoGSc)
  for VrfXREhLNImCbniAzqstedjvUWoGwH in VrfXREhLNImCbniAzqstedjvUWoGwK:
   VrfXREhLNImCbniAzqstedjvUWoGSP =VrfXREhLNImCbniAzqstedjvUWoGwH.get('title')
   VrfXREhLNImCbniAzqstedjvUWoGwJ=VrfXREhLNImCbniAzqstedjvUWoGwH.get('thumbnail')
   VrfXREhLNImCbniAzqstedjvUWoGwk=VrfXREhLNImCbniAzqstedjvUWoGwH.get('info')
   if VrfXREhLNImCbniAzqstedjvUWoGwB=='moviegenre_svod' and VrfXREhLNImCbniAzqstedjvUWoGSc==VrfXREhLNImCbniAzqstedjvUWoGJl:
    VrfXREhLNImCbniAzqstedjvUWoGSP='%s (%s)'%(VrfXREhLNImCbniAzqstedjvUWoGSP,VrfXREhLNImCbniAzqstedjvUWoGky(VrfXREhLNImCbniAzqstedjvUWoGwk.get('year')))
   else:
    VrfXREhLNImCbniAzqstedjvUWoGwk['plot']=VrfXREhLNImCbniAzqstedjvUWoGSP
   if VrfXREhLNImCbniAzqstedjvUWoGwB=='vodgenre':
    VrfXREhLNImCbniAzqstedjvUWoGwD={'mode':'DEEP_LIST','contentid':VrfXREhLNImCbniAzqstedjvUWoGwH.get('uicode'),'contentidType':'contentid','uicode':'vod','page':'1','title':VrfXREhLNImCbniAzqstedjvUWoGSP,'subtitle':'','thumbnail':VrfXREhLNImCbniAzqstedjvUWoGwJ,'viewage':VrfXREhLNImCbniAzqstedjvUWoGwH.get('viewage')}
    VrfXREhLNImCbniAzqstedjvUWoGSB=VrfXREhLNImCbniAzqstedjvUWoGJl
   else:
    VrfXREhLNImCbniAzqstedjvUWoGwD={'mode':'MOVIE','contentid':VrfXREhLNImCbniAzqstedjvUWoGwH.get('uicode'),'contentidType':'contentid','uicode':'movie','page':'1','title':VrfXREhLNImCbniAzqstedjvUWoGSP,'subtitle':'','thumbnail':VrfXREhLNImCbniAzqstedjvUWoGwJ,'viewage':VrfXREhLNImCbniAzqstedjvUWoGwH.get('viewage')}
    VrfXREhLNImCbniAzqstedjvUWoGSB=VrfXREhLNImCbniAzqstedjvUWoGJx
   if VrfXREhLNImCbniAzqstedjvUWoGwD.get('viewage')=='21':VrfXREhLNImCbniAzqstedjvUWoGSP+=' (%s)'%(VrfXREhLNImCbniAzqstedjvUWoGwD.get('viewage'))
   VrfXREhLNImCbniAzqstedjvUWoGyk.add_dir(VrfXREhLNImCbniAzqstedjvUWoGSP,sublabel='',img=VrfXREhLNImCbniAzqstedjvUWoGwJ,infoLabels=VrfXREhLNImCbniAzqstedjvUWoGwk,isFolder=VrfXREhLNImCbniAzqstedjvUWoGSB,params=VrfXREhLNImCbniAzqstedjvUWoGwD)
  if VrfXREhLNImCbniAzqstedjvUWoGwy:
   VrfXREhLNImCbniAzqstedjvUWoGSY['mode'] ='GENRE_LIST' 
   VrfXREhLNImCbniAzqstedjvUWoGSY['uicode']=VrfXREhLNImCbniAzqstedjvUWoGwB 
   VrfXREhLNImCbniAzqstedjvUWoGSY['page'] =VrfXREhLNImCbniAzqstedjvUWoGky(VrfXREhLNImCbniAzqstedjvUWoGSl+1)
   VrfXREhLNImCbniAzqstedjvUWoGSP='[B]%s >>[/B]'%'다음 페이지'
   VrfXREhLNImCbniAzqstedjvUWoGwP=VrfXREhLNImCbniAzqstedjvUWoGky(VrfXREhLNImCbniAzqstedjvUWoGSl+1)
   VrfXREhLNImCbniAzqstedjvUWoGyk.add_dir(VrfXREhLNImCbniAzqstedjvUWoGSP,sublabel=VrfXREhLNImCbniAzqstedjvUWoGwP,img='',infoLabels=VrfXREhLNImCbniAzqstedjvUWoGJO,isFolder=VrfXREhLNImCbniAzqstedjvUWoGJl,params=VrfXREhLNImCbniAzqstedjvUWoGSY)
  if VrfXREhLNImCbniAzqstedjvUWoGJT(VrfXREhLNImCbniAzqstedjvUWoGwK)>0:xbmcplugin.endOfDirectory(VrfXREhLNImCbniAzqstedjvUWoGyk._addon_handle,cacheToDisc=VrfXREhLNImCbniAzqstedjvUWoGJx)
 def dp_Deeplink_List(VrfXREhLNImCbniAzqstedjvUWoGyk,args):
  VrfXREhLNImCbniAzqstedjvUWoGyk.WavveObj.SaveCredential(VrfXREhLNImCbniAzqstedjvUWoGyk.get_winCredential())
  VrfXREhLNImCbniAzqstedjvUWoGSc=VrfXREhLNImCbniAzqstedjvUWoGyk.get_settings_addinfo()
  VrfXREhLNImCbniAzqstedjvUWoGwB =args.get('uicode')
  VrfXREhLNImCbniAzqstedjvUWoGwQ =args.get('came')
  VrfXREhLNImCbniAzqstedjvUWoGSl=VrfXREhLNImCbniAzqstedjvUWoGJc(args.get('page'))
  VrfXREhLNImCbniAzqstedjvUWoGwu,VrfXREhLNImCbniAzqstedjvUWoGwy=VrfXREhLNImCbniAzqstedjvUWoGyk.WavveObj.GetDeeplinkList(VrfXREhLNImCbniAzqstedjvUWoGwB,VrfXREhLNImCbniAzqstedjvUWoGwQ,VrfXREhLNImCbniAzqstedjvUWoGSl,addinfoyn=VrfXREhLNImCbniAzqstedjvUWoGSc)
  for VrfXREhLNImCbniAzqstedjvUWoGwp in VrfXREhLNImCbniAzqstedjvUWoGwu:
   VrfXREhLNImCbniAzqstedjvUWoGSP =VrfXREhLNImCbniAzqstedjvUWoGwp.get('title')
   VrfXREhLNImCbniAzqstedjvUWoGwP =VrfXREhLNImCbniAzqstedjvUWoGwp.get('subtitle')
   VrfXREhLNImCbniAzqstedjvUWoGwJ=VrfXREhLNImCbniAzqstedjvUWoGwp.get('thumbnail')
   VrfXREhLNImCbniAzqstedjvUWoGwO=VrfXREhLNImCbniAzqstedjvUWoGwp.get('uicode')
   VrfXREhLNImCbniAzqstedjvUWoGwc=VrfXREhLNImCbniAzqstedjvUWoGwp.get('channelepg')
   VrfXREhLNImCbniAzqstedjvUWoGSY={'uicode':VrfXREhLNImCbniAzqstedjvUWoGwO,'came':VrfXREhLNImCbniAzqstedjvUWoGwQ,'contentid':VrfXREhLNImCbniAzqstedjvUWoGwp.get('contentid'),'contentidType':VrfXREhLNImCbniAzqstedjvUWoGwp.get('contentidType'),'page':'1','title':VrfXREhLNImCbniAzqstedjvUWoGSP,'subtitle':VrfXREhLNImCbniAzqstedjvUWoGwP,'thumbnail':VrfXREhLNImCbniAzqstedjvUWoGwJ,'viewage':VrfXREhLNImCbniAzqstedjvUWoGwp.get('viewage')}
   if VrfXREhLNImCbniAzqstedjvUWoGwO=='channel':
    VrfXREhLNImCbniAzqstedjvUWoGSY['mode'] ='LIVE'
   elif VrfXREhLNImCbniAzqstedjvUWoGwO=='movie':
    VrfXREhLNImCbniAzqstedjvUWoGSY['mode'] ='MOVIE'
   else:
    VrfXREhLNImCbniAzqstedjvUWoGSY['mode'] ='DEEP_LIST'
   VrfXREhLNImCbniAzqstedjvUWoGwk=VrfXREhLNImCbniAzqstedjvUWoGwp.get('info')
   if VrfXREhLNImCbniAzqstedjvUWoGwc:
    VrfXREhLNImCbniAzqstedjvUWoGwk['plot']='%s\n\n%s'%(VrfXREhLNImCbniAzqstedjvUWoGSP,VrfXREhLNImCbniAzqstedjvUWoGwc)
   elif VrfXREhLNImCbniAzqstedjvUWoGwO=='movie' and VrfXREhLNImCbniAzqstedjvUWoGSc==VrfXREhLNImCbniAzqstedjvUWoGJl:
    VrfXREhLNImCbniAzqstedjvUWoGSP='%s (%s)'%(VrfXREhLNImCbniAzqstedjvUWoGSP,VrfXREhLNImCbniAzqstedjvUWoGky(VrfXREhLNImCbniAzqstedjvUWoGwk.get('year')))
   else:
    VrfXREhLNImCbniAzqstedjvUWoGwk['plot']='%s\n\n%s'%(VrfXREhLNImCbniAzqstedjvUWoGSP,VrfXREhLNImCbniAzqstedjvUWoGwP)
   if VrfXREhLNImCbniAzqstedjvUWoGwp.get('viewage')=='21':VrfXREhLNImCbniAzqstedjvUWoGwP+=' (%s)'%(VrfXREhLNImCbniAzqstedjvUWoGwp.get('viewage'))
   if VrfXREhLNImCbniAzqstedjvUWoGwO in['channel','movie']:
    VrfXREhLNImCbniAzqstedjvUWoGSB=VrfXREhLNImCbniAzqstedjvUWoGJx
   elif VrfXREhLNImCbniAzqstedjvUWoGSY['contentidType']=='direct':
    VrfXREhLNImCbniAzqstedjvUWoGSB=VrfXREhLNImCbniAzqstedjvUWoGJx
    VrfXREhLNImCbniAzqstedjvUWoGSY['mode']='VOD'
   else:
    VrfXREhLNImCbniAzqstedjvUWoGSB=VrfXREhLNImCbniAzqstedjvUWoGJl
   VrfXREhLNImCbniAzqstedjvUWoGyk.add_dir(VrfXREhLNImCbniAzqstedjvUWoGSP,sublabel=VrfXREhLNImCbniAzqstedjvUWoGwP,img=VrfXREhLNImCbniAzqstedjvUWoGwJ,infoLabels=VrfXREhLNImCbniAzqstedjvUWoGwk,isFolder=VrfXREhLNImCbniAzqstedjvUWoGSB,params=VrfXREhLNImCbniAzqstedjvUWoGSY)
  if VrfXREhLNImCbniAzqstedjvUWoGwy:
   VrfXREhLNImCbniAzqstedjvUWoGSY['mode'] ='GN_LIST' 
   VrfXREhLNImCbniAzqstedjvUWoGSY['uicode']=VrfXREhLNImCbniAzqstedjvUWoGwB 
   VrfXREhLNImCbniAzqstedjvUWoGSY['page'] =VrfXREhLNImCbniAzqstedjvUWoGky(VrfXREhLNImCbniAzqstedjvUWoGSl+1)
   VrfXREhLNImCbniAzqstedjvUWoGSP='[B]%s >>[/B]'%'다음 페이지'
   VrfXREhLNImCbniAzqstedjvUWoGwP=VrfXREhLNImCbniAzqstedjvUWoGky(VrfXREhLNImCbniAzqstedjvUWoGSl+1)
   VrfXREhLNImCbniAzqstedjvUWoGyk.add_dir(VrfXREhLNImCbniAzqstedjvUWoGSP,sublabel=VrfXREhLNImCbniAzqstedjvUWoGwP,img='',infoLabels=VrfXREhLNImCbniAzqstedjvUWoGJO,isFolder=VrfXREhLNImCbniAzqstedjvUWoGJl,params=VrfXREhLNImCbniAzqstedjvUWoGSY)
  if VrfXREhLNImCbniAzqstedjvUWoGJT(VrfXREhLNImCbniAzqstedjvUWoGwu)>0:xbmcplugin.endOfDirectory(VrfXREhLNImCbniAzqstedjvUWoGyk._addon_handle,cacheToDisc=VrfXREhLNImCbniAzqstedjvUWoGJx)
 def dp_Episodelink_List(VrfXREhLNImCbniAzqstedjvUWoGyk,args):
  VrfXREhLNImCbniAzqstedjvUWoGyk.WavveObj.SaveCredential(VrfXREhLNImCbniAzqstedjvUWoGyk.get_winCredential())
  VrfXREhLNImCbniAzqstedjvUWoGwx =args.get('contentid')
  VrfXREhLNImCbniAzqstedjvUWoGwl=args.get('contentidType')
  VrfXREhLNImCbniAzqstedjvUWoGSx =args.get('uicode')
  VrfXREhLNImCbniAzqstedjvUWoGSl =VrfXREhLNImCbniAzqstedjvUWoGJc(args.get('page'))
  VrfXREhLNImCbniAzqstedjvUWoGwT,VrfXREhLNImCbniAzqstedjvUWoGwy=VrfXREhLNImCbniAzqstedjvUWoGyk.WavveObj.GetEpisodeList(VrfXREhLNImCbniAzqstedjvUWoGwx,VrfXREhLNImCbniAzqstedjvUWoGSx,VrfXREhLNImCbniAzqstedjvUWoGwl,VrfXREhLNImCbniAzqstedjvUWoGSl,orderby=VrfXREhLNImCbniAzqstedjvUWoGyk.get_winEpisodeOrderby())
  for VrfXREhLNImCbniAzqstedjvUWoGPy in VrfXREhLNImCbniAzqstedjvUWoGwT:
   VrfXREhLNImCbniAzqstedjvUWoGSP =VrfXREhLNImCbniAzqstedjvUWoGPy.get('title')
   VrfXREhLNImCbniAzqstedjvUWoGwP =VrfXREhLNImCbniAzqstedjvUWoGPy.get('subtitle')
   VrfXREhLNImCbniAzqstedjvUWoGwJ=VrfXREhLNImCbniAzqstedjvUWoGPy.get('thumbnail')
   VrfXREhLNImCbniAzqstedjvUWoGSY={'mode':'VOD','uicode':VrfXREhLNImCbniAzqstedjvUWoGPy.get('uicode'),'contentid':VrfXREhLNImCbniAzqstedjvUWoGPy.get('contentid'),'programid':VrfXREhLNImCbniAzqstedjvUWoGPy.get('programid'),'title':VrfXREhLNImCbniAzqstedjvUWoGSP,'subtitle':VrfXREhLNImCbniAzqstedjvUWoGwP,'thumbnail':VrfXREhLNImCbniAzqstedjvUWoGwJ,'viewage':VrfXREhLNImCbniAzqstedjvUWoGPy.get('viewage')}
   if VrfXREhLNImCbniAzqstedjvUWoGPy.get('viewage')=='21':VrfXREhLNImCbniAzqstedjvUWoGwP+=' (%s)'%(VrfXREhLNImCbniAzqstedjvUWoGPy.get('viewage'))
   VrfXREhLNImCbniAzqstedjvUWoGPS=VrfXREhLNImCbniAzqstedjvUWoGPy.get('info')
   VrfXREhLNImCbniAzqstedjvUWoGPS['plot']=VrfXREhLNImCbniAzqstedjvUWoGPy.get('synopsis')
   VrfXREhLNImCbniAzqstedjvUWoGyk.add_dir(VrfXREhLNImCbniAzqstedjvUWoGSP,sublabel=VrfXREhLNImCbniAzqstedjvUWoGwP,img=VrfXREhLNImCbniAzqstedjvUWoGwJ,infoLabels=VrfXREhLNImCbniAzqstedjvUWoGPS,isFolder=VrfXREhLNImCbniAzqstedjvUWoGJx,params=VrfXREhLNImCbniAzqstedjvUWoGSY)
  if VrfXREhLNImCbniAzqstedjvUWoGSl==1:
   VrfXREhLNImCbniAzqstedjvUWoGwk={'plot':'정렬순서를 변경합니다.'}
   VrfXREhLNImCbniAzqstedjvUWoGSY={}
   VrfXREhLNImCbniAzqstedjvUWoGSY['mode'] ='ORDER_BY' 
   if VrfXREhLNImCbniAzqstedjvUWoGyk.get_winEpisodeOrderby()=='desc':
    VrfXREhLNImCbniAzqstedjvUWoGSP='정렬순서변경 : 최신화부터 -> 1회부터'
    VrfXREhLNImCbniAzqstedjvUWoGSY['orderby']='asc'
   else:
    VrfXREhLNImCbniAzqstedjvUWoGSP='정렬순서변경 : 1회부터 -> 최신화부터'
    VrfXREhLNImCbniAzqstedjvUWoGSY['orderby']='desc'
   VrfXREhLNImCbniAzqstedjvUWoGyk.add_dir(VrfXREhLNImCbniAzqstedjvUWoGSP,sublabel='',img='',infoLabels=VrfXREhLNImCbniAzqstedjvUWoGwk,isFolder=VrfXREhLNImCbniAzqstedjvUWoGJx,params=VrfXREhLNImCbniAzqstedjvUWoGSY)
  if VrfXREhLNImCbniAzqstedjvUWoGwy:
   VrfXREhLNImCbniAzqstedjvUWoGSY['mode'] ='DEEP_LIST' 
   VrfXREhLNImCbniAzqstedjvUWoGSY['uicode'] =VrfXREhLNImCbniAzqstedjvUWoGSx 
   VrfXREhLNImCbniAzqstedjvUWoGSY['contentid'] =VrfXREhLNImCbniAzqstedjvUWoGwx 
   VrfXREhLNImCbniAzqstedjvUWoGSY['contentidType']=VrfXREhLNImCbniAzqstedjvUWoGwl 
   VrfXREhLNImCbniAzqstedjvUWoGSY['page'] =VrfXREhLNImCbniAzqstedjvUWoGky(VrfXREhLNImCbniAzqstedjvUWoGSl+1)
   VrfXREhLNImCbniAzqstedjvUWoGSP='[B]%s >>[/B]'%'다음 페이지'
   VrfXREhLNImCbniAzqstedjvUWoGwP=VrfXREhLNImCbniAzqstedjvUWoGky(VrfXREhLNImCbniAzqstedjvUWoGSl+1)
   VrfXREhLNImCbniAzqstedjvUWoGyk.add_dir(VrfXREhLNImCbniAzqstedjvUWoGSP,sublabel=VrfXREhLNImCbniAzqstedjvUWoGwP,img='',infoLabels=VrfXREhLNImCbniAzqstedjvUWoGJO,isFolder=VrfXREhLNImCbniAzqstedjvUWoGJl,params=VrfXREhLNImCbniAzqstedjvUWoGSY)
  if VrfXREhLNImCbniAzqstedjvUWoGJT(VrfXREhLNImCbniAzqstedjvUWoGwT)>0:xbmcplugin.endOfDirectory(VrfXREhLNImCbniAzqstedjvUWoGyk._addon_handle,cacheToDisc=VrfXREhLNImCbniAzqstedjvUWoGJl)
 def play_VIDEO(VrfXREhLNImCbniAzqstedjvUWoGyk,args):
  VrfXREhLNImCbniAzqstedjvUWoGyk.WavveObj.SaveCredential(VrfXREhLNImCbniAzqstedjvUWoGyk.get_winCredential())
  VrfXREhLNImCbniAzqstedjvUWoGwx =args.get('contentid')
  VrfXREhLNImCbniAzqstedjvUWoGSx=args.get('uicode')
  VrfXREhLNImCbniAzqstedjvUWoGPw=VrfXREhLNImCbniAzqstedjvUWoGyk.get_selQuality()
  VrfXREhLNImCbniAzqstedjvUWoGyk.addon_log(VrfXREhLNImCbniAzqstedjvUWoGwx+' - '+VrfXREhLNImCbniAzqstedjvUWoGSx)
  VrfXREhLNImCbniAzqstedjvUWoGPJ,VrfXREhLNImCbniAzqstedjvUWoGPk,VrfXREhLNImCbniAzqstedjvUWoGPY,VrfXREhLNImCbniAzqstedjvUWoGPB=VrfXREhLNImCbniAzqstedjvUWoGyk.WavveObj.GetStreamingURL(VrfXREhLNImCbniAzqstedjvUWoGwx,VrfXREhLNImCbniAzqstedjvUWoGSx,VrfXREhLNImCbniAzqstedjvUWoGPw)
  VrfXREhLNImCbniAzqstedjvUWoGPg='%s|Cookie=%s'%(VrfXREhLNImCbniAzqstedjvUWoGPJ,VrfXREhLNImCbniAzqstedjvUWoGPk)
  VrfXREhLNImCbniAzqstedjvUWoGyk.addon_log(VrfXREhLNImCbniAzqstedjvUWoGPg)
  if VrfXREhLNImCbniAzqstedjvUWoGPJ=='':
   VrfXREhLNImCbniAzqstedjvUWoGyk.addon_noti(__language__(30907).encode('utf8'))
   return
  VrfXREhLNImCbniAzqstedjvUWoGPM=xbmcgui.ListItem(path=VrfXREhLNImCbniAzqstedjvUWoGPg)
  if VrfXREhLNImCbniAzqstedjvUWoGPY:
   VrfXREhLNImCbniAzqstedjvUWoGPa=VrfXREhLNImCbniAzqstedjvUWoGPY['customdata']
   VrfXREhLNImCbniAzqstedjvUWoGPK =VrfXREhLNImCbniAzqstedjvUWoGPY['drmhost']
   VrfXREhLNImCbniAzqstedjvUWoGPF =inputstreamhelper.Helper('mpd',drm='widevine')
   if VrfXREhLNImCbniAzqstedjvUWoGPF.check_inputstream():
    if VrfXREhLNImCbniAzqstedjvUWoGSx=='movie':
     VrfXREhLNImCbniAzqstedjvUWoGPH='https://www.wavve.com/player/movie?movieid=%s'%VrfXREhLNImCbniAzqstedjvUWoGwx
    else:
     VrfXREhLNImCbniAzqstedjvUWoGPH='https://www.wavve.com/player/vod?programid=%s&page=1'%VrfXREhLNImCbniAzqstedjvUWoGwx
    VrfXREhLNImCbniAzqstedjvUWoGPD={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':VrfXREhLNImCbniAzqstedjvUWoGPa,'referer':VrfXREhLNImCbniAzqstedjvUWoGPH,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':VrfXREhLNImCbniAzqstedjvUWoGyP}
    VrfXREhLNImCbniAzqstedjvUWoGPQ=VrfXREhLNImCbniAzqstedjvUWoGPK+'|'+urllib.parse.urlencode(VrfXREhLNImCbniAzqstedjvUWoGPD)+'|R{SSM}|'
    VrfXREhLNImCbniAzqstedjvUWoGPM.setProperty('inputstream',VrfXREhLNImCbniAzqstedjvUWoGPF.inputstream_addon)
    VrfXREhLNImCbniAzqstedjvUWoGPM.setProperty('inputstream.adaptive.manifest_type','mpd')
    VrfXREhLNImCbniAzqstedjvUWoGPM.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    VrfXREhLNImCbniAzqstedjvUWoGPM.setProperty('inputstream.adaptive.license_key',VrfXREhLNImCbniAzqstedjvUWoGPQ)
    VrfXREhLNImCbniAzqstedjvUWoGPM.setProperty('inputstream.adaptive.stream_headers','user-agent=%s&Cookie=%s'%(VrfXREhLNImCbniAzqstedjvUWoGyP,VrfXREhLNImCbniAzqstedjvUWoGPk))
  xbmcplugin.setResolvedUrl(VrfXREhLNImCbniAzqstedjvUWoGyk._addon_handle,VrfXREhLNImCbniAzqstedjvUWoGJl,VrfXREhLNImCbniAzqstedjvUWoGPM)
  if VrfXREhLNImCbniAzqstedjvUWoGPB:
   VrfXREhLNImCbniAzqstedjvUWoGyk.addon_noti(VrfXREhLNImCbniAzqstedjvUWoGPB.encode('utf-8'))
  else:
   if '/preview.' in urllib.parse.urlsplit(VrfXREhLNImCbniAzqstedjvUWoGPJ).path:VrfXREhLNImCbniAzqstedjvUWoGyk.addon_noti(__language__(30908).encode('utf8'))
  try:
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('viewage')!='21':
    VrfXREhLNImCbniAzqstedjvUWoGSY={'code':args.get('programid')if args.get('mode')=='VOD' else args.get('contentid'),'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    VrfXREhLNImCbniAzqstedjvUWoGyk.Save_Watched_List(args.get('mode').lower(),VrfXREhLNImCbniAzqstedjvUWoGSY)
  except:
   VrfXREhLNImCbniAzqstedjvUWoGJO
 def dp_Watch_List(VrfXREhLNImCbniAzqstedjvUWoGyk,args):
  VrfXREhLNImCbniAzqstedjvUWoGwg =args.get('genre')
  VrfXREhLNImCbniAzqstedjvUWoGyx=VrfXREhLNImCbniAzqstedjvUWoGyk.get_settings_direct_replay()
  if VrfXREhLNImCbniAzqstedjvUWoGwg=='-':
   VrfXREhLNImCbniAzqstedjvUWoGSP='VOD 시청내역'
   VrfXREhLNImCbniAzqstedjvUWoGSY={'mode':'WATCH','genre':'vod'}
   VrfXREhLNImCbniAzqstedjvUWoGyk.add_dir(VrfXREhLNImCbniAzqstedjvUWoGSP,sublabel='',img='',infoLabels=VrfXREhLNImCbniAzqstedjvUWoGJO,isFolder=VrfXREhLNImCbniAzqstedjvUWoGJl,params=VrfXREhLNImCbniAzqstedjvUWoGSY)
   VrfXREhLNImCbniAzqstedjvUWoGSP='영화 시청내역'
   VrfXREhLNImCbniAzqstedjvUWoGSY['genre']='movie'
   VrfXREhLNImCbniAzqstedjvUWoGyk.add_dir(VrfXREhLNImCbniAzqstedjvUWoGSP,sublabel='',img='',infoLabels=VrfXREhLNImCbniAzqstedjvUWoGJO,isFolder=VrfXREhLNImCbniAzqstedjvUWoGJl,params=VrfXREhLNImCbniAzqstedjvUWoGSY)
   xbmcplugin.endOfDirectory(VrfXREhLNImCbniAzqstedjvUWoGyk._addon_handle)
  else:
   VrfXREhLNImCbniAzqstedjvUWoGPu=VrfXREhLNImCbniAzqstedjvUWoGyk.Load_Watched_List(VrfXREhLNImCbniAzqstedjvUWoGwg)
   for VrfXREhLNImCbniAzqstedjvUWoGPp in VrfXREhLNImCbniAzqstedjvUWoGPu:
    VrfXREhLNImCbniAzqstedjvUWoGPO=VrfXREhLNImCbniAzqstedjvUWoGkS(urllib.parse.parse_qsl(VrfXREhLNImCbniAzqstedjvUWoGPp))
    VrfXREhLNImCbniAzqstedjvUWoGSP =VrfXREhLNImCbniAzqstedjvUWoGPO.get('title').strip()
    VrfXREhLNImCbniAzqstedjvUWoGwP =VrfXREhLNImCbniAzqstedjvUWoGPO.get('subtitle').strip()
    if VrfXREhLNImCbniAzqstedjvUWoGwP=='None':VrfXREhLNImCbniAzqstedjvUWoGwP=''
    VrfXREhLNImCbniAzqstedjvUWoGwJ=VrfXREhLNImCbniAzqstedjvUWoGPO.get('img')
    VrfXREhLNImCbniAzqstedjvUWoGPc =VrfXREhLNImCbniAzqstedjvUWoGPO.get('videoid')
    VrfXREhLNImCbniAzqstedjvUWoGwk={}
    if VrfXREhLNImCbniAzqstedjvUWoGwg=='movie' and VrfXREhLNImCbniAzqstedjvUWoGyk.get_settings_addinfo()==VrfXREhLNImCbniAzqstedjvUWoGJl:
     VrfXREhLNImCbniAzqstedjvUWoGPx=VrfXREhLNImCbniAzqstedjvUWoGyk.WavveObj.GetMovieInfoList([VrfXREhLNImCbniAzqstedjvUWoGPO.get('code')])
     VrfXREhLNImCbniAzqstedjvUWoGwk=VrfXREhLNImCbniAzqstedjvUWoGPx.get(VrfXREhLNImCbniAzqstedjvUWoGPO.get('code'))
    else:
     VrfXREhLNImCbniAzqstedjvUWoGwk['plot']='%s\n%s'%(VrfXREhLNImCbniAzqstedjvUWoGSP,VrfXREhLNImCbniAzqstedjvUWoGwP)
    if VrfXREhLNImCbniAzqstedjvUWoGwg=='vod':
     if VrfXREhLNImCbniAzqstedjvUWoGyx==VrfXREhLNImCbniAzqstedjvUWoGJx or VrfXREhLNImCbniAzqstedjvUWoGPc==VrfXREhLNImCbniAzqstedjvUWoGJO:
      VrfXREhLNImCbniAzqstedjvUWoGSY={'mode':'DEEP_LIST','contentid':VrfXREhLNImCbniAzqstedjvUWoGPO.get('code'),'contentidType':'programid','uicode':'vod','page':'1'}
      VrfXREhLNImCbniAzqstedjvUWoGSB=VrfXREhLNImCbniAzqstedjvUWoGJl
     else:
      VrfXREhLNImCbniAzqstedjvUWoGSY={'mode':'VOD','contentid':VrfXREhLNImCbniAzqstedjvUWoGPc,'contentidType':'contentid','programid':VrfXREhLNImCbniAzqstedjvUWoGPO.get('code'),'uicode':'vod','title':VrfXREhLNImCbniAzqstedjvUWoGSP,'subtitle':VrfXREhLNImCbniAzqstedjvUWoGwP,'thumbnail':VrfXREhLNImCbniAzqstedjvUWoGwJ}
      VrfXREhLNImCbniAzqstedjvUWoGSB=VrfXREhLNImCbniAzqstedjvUWoGJx
    else:
     VrfXREhLNImCbniAzqstedjvUWoGSY={'mode':'MOVIE','contentid':VrfXREhLNImCbniAzqstedjvUWoGPO.get('code'),'contentidType':'contentid','uicode':'movie','title':VrfXREhLNImCbniAzqstedjvUWoGSP,'thumbnail':VrfXREhLNImCbniAzqstedjvUWoGwJ}
     VrfXREhLNImCbniAzqstedjvUWoGSB=VrfXREhLNImCbniAzqstedjvUWoGJx
    VrfXREhLNImCbniAzqstedjvUWoGyk.add_dir(VrfXREhLNImCbniAzqstedjvUWoGSP,sublabel=VrfXREhLNImCbniAzqstedjvUWoGwP,img=VrfXREhLNImCbniAzqstedjvUWoGwJ,infoLabels=VrfXREhLNImCbniAzqstedjvUWoGwk,isFolder=VrfXREhLNImCbniAzqstedjvUWoGSB,params=VrfXREhLNImCbniAzqstedjvUWoGSY)
   VrfXREhLNImCbniAzqstedjvUWoGwk={'plot':'시청목록을 삭제합니다.'}
   VrfXREhLNImCbniAzqstedjvUWoGSP='*** 시청목록 삭제 ***'
   VrfXREhLNImCbniAzqstedjvUWoGSY={'mode':'MYVIEW_REMOVE','genre':VrfXREhLNImCbniAzqstedjvUWoGwg}
   VrfXREhLNImCbniAzqstedjvUWoGyk.add_dir(VrfXREhLNImCbniAzqstedjvUWoGSP,sublabel='',img='',infoLabels=VrfXREhLNImCbniAzqstedjvUWoGwk,isFolder=VrfXREhLNImCbniAzqstedjvUWoGJx,params=VrfXREhLNImCbniAzqstedjvUWoGSY)
   xbmcplugin.endOfDirectory(VrfXREhLNImCbniAzqstedjvUWoGyk._addon_handle,cacheToDisc=VrfXREhLNImCbniAzqstedjvUWoGJx)
 def dp_Search_Group(VrfXREhLNImCbniAzqstedjvUWoGyk,args):
  VrfXREhLNImCbniAzqstedjvUWoGSP='VOD 검색'
  VrfXREhLNImCbniAzqstedjvUWoGSY={'mode':'SEARCH_LIST','genre':'vod','page':'1'}
  VrfXREhLNImCbniAzqstedjvUWoGyk.add_dir(VrfXREhLNImCbniAzqstedjvUWoGSP,sublabel='',img='',infoLabels=VrfXREhLNImCbniAzqstedjvUWoGJO,isFolder=VrfXREhLNImCbniAzqstedjvUWoGJl,params=VrfXREhLNImCbniAzqstedjvUWoGSY)
  VrfXREhLNImCbniAzqstedjvUWoGSP='영화 검색'
  VrfXREhLNImCbniAzqstedjvUWoGSY['genre']='movie'
  VrfXREhLNImCbniAzqstedjvUWoGyk.add_dir(VrfXREhLNImCbniAzqstedjvUWoGSP,sublabel='',img='',infoLabels=VrfXREhLNImCbniAzqstedjvUWoGJO,isFolder=VrfXREhLNImCbniAzqstedjvUWoGJl,params=VrfXREhLNImCbniAzqstedjvUWoGSY)
  xbmcplugin.endOfDirectory(VrfXREhLNImCbniAzqstedjvUWoGyk._addon_handle)
 def dp_Search_List(VrfXREhLNImCbniAzqstedjvUWoGyk,args):
  VrfXREhLNImCbniAzqstedjvUWoGyk.WavveObj.SaveCredential(VrfXREhLNImCbniAzqstedjvUWoGyk.get_winCredential())
  VrfXREhLNImCbniAzqstedjvUWoGSc=VrfXREhLNImCbniAzqstedjvUWoGyk.get_settings_addinfo()
  VrfXREhLNImCbniAzqstedjvUWoGSx=args.get('genre')
  VrfXREhLNImCbniAzqstedjvUWoGSl =VrfXREhLNImCbniAzqstedjvUWoGJc(args.get('page'))
  if 'search_key' in args:
   VrfXREhLNImCbniAzqstedjvUWoGPT=args.get('search_key')
  else:
   VrfXREhLNImCbniAzqstedjvUWoGPT=VrfXREhLNImCbniAzqstedjvUWoGyk.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not VrfXREhLNImCbniAzqstedjvUWoGPT:return
  VrfXREhLNImCbniAzqstedjvUWoGJy,VrfXREhLNImCbniAzqstedjvUWoGwy=VrfXREhLNImCbniAzqstedjvUWoGyk.WavveObj.GetSearchList(VrfXREhLNImCbniAzqstedjvUWoGPT,VrfXREhLNImCbniAzqstedjvUWoGSx,VrfXREhLNImCbniAzqstedjvUWoGSl,exclusion21=VrfXREhLNImCbniAzqstedjvUWoGyk.get_settings_exclusion21(),addinfoyn=VrfXREhLNImCbniAzqstedjvUWoGSc)
  for VrfXREhLNImCbniAzqstedjvUWoGJS in VrfXREhLNImCbniAzqstedjvUWoGJy:
   VrfXREhLNImCbniAzqstedjvUWoGSP =VrfXREhLNImCbniAzqstedjvUWoGJS.get('title')
   VrfXREhLNImCbniAzqstedjvUWoGwJ=VrfXREhLNImCbniAzqstedjvUWoGJS.get('thumbnail')
   VrfXREhLNImCbniAzqstedjvUWoGwk=VrfXREhLNImCbniAzqstedjvUWoGJS.get('info')
   if VrfXREhLNImCbniAzqstedjvUWoGSx=='movie' and VrfXREhLNImCbniAzqstedjvUWoGSc==VrfXREhLNImCbniAzqstedjvUWoGJl:
    VrfXREhLNImCbniAzqstedjvUWoGSP='%s (%s)'%(VrfXREhLNImCbniAzqstedjvUWoGSP,VrfXREhLNImCbniAzqstedjvUWoGky(VrfXREhLNImCbniAzqstedjvUWoGwk.get('year')))
   else:
    VrfXREhLNImCbniAzqstedjvUWoGwk['plot']=VrfXREhLNImCbniAzqstedjvUWoGSP
   if VrfXREhLNImCbniAzqstedjvUWoGSx=='vod':
    VrfXREhLNImCbniAzqstedjvUWoGSY={'mode':'DEEP_LIST','contentid':VrfXREhLNImCbniAzqstedjvUWoGJS.get('programid'),'contentidType':'programid','uicode':'vod','page':'1','title':VrfXREhLNImCbniAzqstedjvUWoGSP,'subtitle':'','thumbnail':VrfXREhLNImCbniAzqstedjvUWoGwJ,'viewage':VrfXREhLNImCbniAzqstedjvUWoGJS.get('viewage')}
    VrfXREhLNImCbniAzqstedjvUWoGSB=VrfXREhLNImCbniAzqstedjvUWoGJl
   else:
    VrfXREhLNImCbniAzqstedjvUWoGSY={'mode':'MOVIE','contentid':VrfXREhLNImCbniAzqstedjvUWoGJS.get('contentid'),'contentidType':'contentid','uicode':'movie','page':'1','title':VrfXREhLNImCbniAzqstedjvUWoGSP,'subtitle':'','thumbnail':VrfXREhLNImCbniAzqstedjvUWoGwJ,'viewage':VrfXREhLNImCbniAzqstedjvUWoGJS.get('viewage')}
    VrfXREhLNImCbniAzqstedjvUWoGSB=VrfXREhLNImCbniAzqstedjvUWoGJx
   if VrfXREhLNImCbniAzqstedjvUWoGSY.get('viewage')=='21':VrfXREhLNImCbniAzqstedjvUWoGSP+=' (%s)'%(VrfXREhLNImCbniAzqstedjvUWoGSY.get('viewage'))
   VrfXREhLNImCbniAzqstedjvUWoGyk.add_dir(VrfXREhLNImCbniAzqstedjvUWoGSP,sublabel='',img=VrfXREhLNImCbniAzqstedjvUWoGwJ,infoLabels=VrfXREhLNImCbniAzqstedjvUWoGwk,isFolder=VrfXREhLNImCbniAzqstedjvUWoGSB,params=VrfXREhLNImCbniAzqstedjvUWoGSY)
  if VrfXREhLNImCbniAzqstedjvUWoGwy:
   VrfXREhLNImCbniAzqstedjvUWoGSY['mode'] ='SEARCH_LIST' 
   VrfXREhLNImCbniAzqstedjvUWoGSY['genre']=VrfXREhLNImCbniAzqstedjvUWoGSx 
   VrfXREhLNImCbniAzqstedjvUWoGSY['page'] =VrfXREhLNImCbniAzqstedjvUWoGky(VrfXREhLNImCbniAzqstedjvUWoGSl+1)
   VrfXREhLNImCbniAzqstedjvUWoGSY['search_key']=VrfXREhLNImCbniAzqstedjvUWoGPT
   VrfXREhLNImCbniAzqstedjvUWoGSP='[B]%s >>[/B]'%'다음 페이지'
   VrfXREhLNImCbniAzqstedjvUWoGwP=VrfXREhLNImCbniAzqstedjvUWoGky(VrfXREhLNImCbniAzqstedjvUWoGSl+1)
   VrfXREhLNImCbniAzqstedjvUWoGyk.add_dir(VrfXREhLNImCbniAzqstedjvUWoGSP,sublabel=VrfXREhLNImCbniAzqstedjvUWoGwP,img='',infoLabels=VrfXREhLNImCbniAzqstedjvUWoGJO,isFolder=VrfXREhLNImCbniAzqstedjvUWoGJl,params=VrfXREhLNImCbniAzqstedjvUWoGSY)
  if VrfXREhLNImCbniAzqstedjvUWoGJT(VrfXREhLNImCbniAzqstedjvUWoGJy)>0:xbmcplugin.endOfDirectory(VrfXREhLNImCbniAzqstedjvUWoGyk._addon_handle)
 def Load_Watched_List(VrfXREhLNImCbniAzqstedjvUWoGyk,VrfXREhLNImCbniAzqstedjvUWoGwg):
  try:
   VrfXREhLNImCbniAzqstedjvUWoGJw=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%VrfXREhLNImCbniAzqstedjvUWoGwg))
   fp=VrfXREhLNImCbniAzqstedjvUWoGkw(VrfXREhLNImCbniAzqstedjvUWoGJw,'r',-1,'utf-8')
   VrfXREhLNImCbniAzqstedjvUWoGJP=fp.readlines()
   fp.close()
  except:
   VrfXREhLNImCbniAzqstedjvUWoGJP=[]
  return VrfXREhLNImCbniAzqstedjvUWoGJP
 def Save_Watched_List(VrfXREhLNImCbniAzqstedjvUWoGyk,VrfXREhLNImCbniAzqstedjvUWoGwg,VrfXREhLNImCbniAzqstedjvUWoGyg):
  try:
   VrfXREhLNImCbniAzqstedjvUWoGJw=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%VrfXREhLNImCbniAzqstedjvUWoGwg))
   VrfXREhLNImCbniAzqstedjvUWoGJk=VrfXREhLNImCbniAzqstedjvUWoGyk.Load_Watched_List(VrfXREhLNImCbniAzqstedjvUWoGwg) 
   fp=VrfXREhLNImCbniAzqstedjvUWoGkw(VrfXREhLNImCbniAzqstedjvUWoGJw,'w',-1,'utf-8')
   VrfXREhLNImCbniAzqstedjvUWoGJY=urllib.parse.urlencode(VrfXREhLNImCbniAzqstedjvUWoGyg)
   VrfXREhLNImCbniAzqstedjvUWoGJY=VrfXREhLNImCbniAzqstedjvUWoGJY+'\n'
   fp.write(VrfXREhLNImCbniAzqstedjvUWoGJY)
   VrfXREhLNImCbniAzqstedjvUWoGJB=0
   for VrfXREhLNImCbniAzqstedjvUWoGJg in VrfXREhLNImCbniAzqstedjvUWoGJk:
    VrfXREhLNImCbniAzqstedjvUWoGJM=VrfXREhLNImCbniAzqstedjvUWoGkS(urllib.parse.parse_qsl(VrfXREhLNImCbniAzqstedjvUWoGJg))
    VrfXREhLNImCbniAzqstedjvUWoGJa=VrfXREhLNImCbniAzqstedjvUWoGyg.get('code')
    VrfXREhLNImCbniAzqstedjvUWoGJK=VrfXREhLNImCbniAzqstedjvUWoGJM.get('code')
    if VrfXREhLNImCbniAzqstedjvUWoGwg=='vod' and VrfXREhLNImCbniAzqstedjvUWoGyk.get_settings_direct_replay()==VrfXREhLNImCbniAzqstedjvUWoGJl:
     VrfXREhLNImCbniAzqstedjvUWoGJa=VrfXREhLNImCbniAzqstedjvUWoGyg.get('videoid')
     VrfXREhLNImCbniAzqstedjvUWoGJK=VrfXREhLNImCbniAzqstedjvUWoGJM.get('videoid')if VrfXREhLNImCbniAzqstedjvUWoGJK!=VrfXREhLNImCbniAzqstedjvUWoGJO else '-'
    if VrfXREhLNImCbniAzqstedjvUWoGJa!=VrfXREhLNImCbniAzqstedjvUWoGJK:
     fp.write(VrfXREhLNImCbniAzqstedjvUWoGJg)
     VrfXREhLNImCbniAzqstedjvUWoGJB+=1
     if VrfXREhLNImCbniAzqstedjvUWoGJB>=50:break
   fp.close()
  except:
   VrfXREhLNImCbniAzqstedjvUWoGJO
 def Delete_Watched_List(VrfXREhLNImCbniAzqstedjvUWoGyk,VrfXREhLNImCbniAzqstedjvUWoGwg):
  try:
   VrfXREhLNImCbniAzqstedjvUWoGJw=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%VrfXREhLNImCbniAzqstedjvUWoGwg))
   fp=VrfXREhLNImCbniAzqstedjvUWoGkw(VrfXREhLNImCbniAzqstedjvUWoGJw,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   VrfXREhLNImCbniAzqstedjvUWoGJO
 def dp_WatchList_Delete(VrfXREhLNImCbniAzqstedjvUWoGyk,args):
  VrfXREhLNImCbniAzqstedjvUWoGwg=args.get('genre')
  VrfXREhLNImCbniAzqstedjvUWoGya=xbmcgui.Dialog()
  VrfXREhLNImCbniAzqstedjvUWoGSF=VrfXREhLNImCbniAzqstedjvUWoGya.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if VrfXREhLNImCbniAzqstedjvUWoGSF==VrfXREhLNImCbniAzqstedjvUWoGJx:sys.exit()
  VrfXREhLNImCbniAzqstedjvUWoGyk.Delete_Watched_List(VrfXREhLNImCbniAzqstedjvUWoGwg)
  xbmc.executebuiltin("Container.Refresh")
 def logout(VrfXREhLNImCbniAzqstedjvUWoGyk):
  VrfXREhLNImCbniAzqstedjvUWoGya=xbmcgui.Dialog()
  VrfXREhLNImCbniAzqstedjvUWoGSF=VrfXREhLNImCbniAzqstedjvUWoGya.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if VrfXREhLNImCbniAzqstedjvUWoGSF==VrfXREhLNImCbniAzqstedjvUWoGJx:sys.exit()
  VrfXREhLNImCbniAzqstedjvUWoGyk.wininfo_clear()
  if os.path.isfile(VrfXREhLNImCbniAzqstedjvUWoGyJ):os.remove(VrfXREhLNImCbniAzqstedjvUWoGyJ)
  VrfXREhLNImCbniAzqstedjvUWoGyk.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(VrfXREhLNImCbniAzqstedjvUWoGyk):
  VrfXREhLNImCbniAzqstedjvUWoGSy=xbmcgui.Window(10000)
  VrfXREhLNImCbniAzqstedjvUWoGSy.setProperty('WAVVE_M_CREDENTIAL','')
  VrfXREhLNImCbniAzqstedjvUWoGSy.setProperty('WAVVE_M_LOGINTIME','')
 def cookiefile_save(VrfXREhLNImCbniAzqstedjvUWoGyk):
  VrfXREhLNImCbniAzqstedjvUWoGJF =VrfXREhLNImCbniAzqstedjvUWoGyk.WavveObj.Get_Now_Datetime()
  VrfXREhLNImCbniAzqstedjvUWoGJH=VrfXREhLNImCbniAzqstedjvUWoGJF+datetime.timedelta(days=VrfXREhLNImCbniAzqstedjvUWoGJc(__addon__.getSetting('cache_ttl')))
  VrfXREhLNImCbniAzqstedjvUWoGSy=xbmcgui.Window(10000)
  VrfXREhLNImCbniAzqstedjvUWoGJD={'wavve_token':VrfXREhLNImCbniAzqstedjvUWoGSy.getProperty('WAVVE_M_CREDENTIAL'),'wavve_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'wavve_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'wavve_profile':__addon__.getSetting('selected_profile'),'wavve_limitdate':VrfXREhLNImCbniAzqstedjvUWoGJH.strftime('%Y-%m-%d')}
  try: 
   fp=VrfXREhLNImCbniAzqstedjvUWoGkw(VrfXREhLNImCbniAzqstedjvUWoGyJ,'w',-1,'utf-8')
   json.dump(VrfXREhLNImCbniAzqstedjvUWoGJD,fp)
   fp.close()
  except VrfXREhLNImCbniAzqstedjvUWoGkP as exception:
   VrfXREhLNImCbniAzqstedjvUWoGkJ(exception)
 def cookiefile_check(VrfXREhLNImCbniAzqstedjvUWoGyk):
  VrfXREhLNImCbniAzqstedjvUWoGJD={}
  try: 
   fp=VrfXREhLNImCbniAzqstedjvUWoGkw(VrfXREhLNImCbniAzqstedjvUWoGyJ,'r',-1,'utf-8')
   VrfXREhLNImCbniAzqstedjvUWoGJD= json.load(fp)
   fp.close()
  except VrfXREhLNImCbniAzqstedjvUWoGkP as exception:
   VrfXREhLNImCbniAzqstedjvUWoGyk.wininfo_clear()
   return VrfXREhLNImCbniAzqstedjvUWoGJx
  VrfXREhLNImCbniAzqstedjvUWoGSM =__addon__.getSetting('id')
  VrfXREhLNImCbniAzqstedjvUWoGSa =__addon__.getSetting('pw')
  VrfXREhLNImCbniAzqstedjvUWoGJQ =__addon__.getSetting('selected_profile')
  VrfXREhLNImCbniAzqstedjvUWoGJD['wavve_id']=base64.standard_b64decode(VrfXREhLNImCbniAzqstedjvUWoGJD['wavve_id']).decode('utf-8')
  VrfXREhLNImCbniAzqstedjvUWoGJD['wavve_pw']=base64.standard_b64decode(VrfXREhLNImCbniAzqstedjvUWoGJD['wavve_pw']).decode('utf-8')
  if VrfXREhLNImCbniAzqstedjvUWoGSM!=VrfXREhLNImCbniAzqstedjvUWoGJD['wavve_id']or VrfXREhLNImCbniAzqstedjvUWoGSa!=VrfXREhLNImCbniAzqstedjvUWoGJD['wavve_pw']or VrfXREhLNImCbniAzqstedjvUWoGJQ!=VrfXREhLNImCbniAzqstedjvUWoGJD['wavve_profile']:
   VrfXREhLNImCbniAzqstedjvUWoGyk.wininfo_clear()
   return VrfXREhLNImCbniAzqstedjvUWoGJx
  VrfXREhLNImCbniAzqstedjvUWoGSH =VrfXREhLNImCbniAzqstedjvUWoGJc(VrfXREhLNImCbniAzqstedjvUWoGyk.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  VrfXREhLNImCbniAzqstedjvUWoGJu=VrfXREhLNImCbniAzqstedjvUWoGJD['wavve_limitdate']
  VrfXREhLNImCbniAzqstedjvUWoGSD =VrfXREhLNImCbniAzqstedjvUWoGJc(re.sub('-','',VrfXREhLNImCbniAzqstedjvUWoGJu))
  if VrfXREhLNImCbniAzqstedjvUWoGSD<VrfXREhLNImCbniAzqstedjvUWoGSH:
   VrfXREhLNImCbniAzqstedjvUWoGyk.wininfo_clear()
   return VrfXREhLNImCbniAzqstedjvUWoGJx
  VrfXREhLNImCbniAzqstedjvUWoGSy=xbmcgui.Window(10000)
  VrfXREhLNImCbniAzqstedjvUWoGSy.setProperty('WAVVE_M_CREDENTIAL',VrfXREhLNImCbniAzqstedjvUWoGJD['wavve_token'])
  VrfXREhLNImCbniAzqstedjvUWoGSy.setProperty('WAVVE_M_LOGINTIME',VrfXREhLNImCbniAzqstedjvUWoGJu)
  return VrfXREhLNImCbniAzqstedjvUWoGJl
 def wavve_main(VrfXREhLNImCbniAzqstedjvUWoGyk):
  VrfXREhLNImCbniAzqstedjvUWoGwY=VrfXREhLNImCbniAzqstedjvUWoGyk.main_params.get('mode',VrfXREhLNImCbniAzqstedjvUWoGJO)
  if VrfXREhLNImCbniAzqstedjvUWoGwY=='LOGOUT':
   VrfXREhLNImCbniAzqstedjvUWoGyk.logout()
   return
  VrfXREhLNImCbniAzqstedjvUWoGyk.login_main()
  if VrfXREhLNImCbniAzqstedjvUWoGwY is VrfXREhLNImCbniAzqstedjvUWoGJO:
   VrfXREhLNImCbniAzqstedjvUWoGyk.dp_Main_List()
  elif VrfXREhLNImCbniAzqstedjvUWoGwY=='GNB_LIST':
   VrfXREhLNImCbniAzqstedjvUWoGyk.dp_Gnb_List(VrfXREhLNImCbniAzqstedjvUWoGyk.main_params)
  elif VrfXREhLNImCbniAzqstedjvUWoGwY=='GN_LIST':
   VrfXREhLNImCbniAzqstedjvUWoGyk.dp_Deeplink_List(VrfXREhLNImCbniAzqstedjvUWoGyk.main_params)
  elif VrfXREhLNImCbniAzqstedjvUWoGwY=='DEEP_LIST':
   VrfXREhLNImCbniAzqstedjvUWoGSx=VrfXREhLNImCbniAzqstedjvUWoGyk.main_params.get('uicode',VrfXREhLNImCbniAzqstedjvUWoGJO)
   if VrfXREhLNImCbniAzqstedjvUWoGSx in['quick','vod','program','x']:
    VrfXREhLNImCbniAzqstedjvUWoGyk.dp_Episodelink_List(VrfXREhLNImCbniAzqstedjvUWoGyk.main_params)
   else:VrfXREhLNImCbniAzqstedjvUWoGJO
  elif VrfXREhLNImCbniAzqstedjvUWoGwY in['LIVE','VOD','MOVIE']:
   VrfXREhLNImCbniAzqstedjvUWoGyk.play_VIDEO(VrfXREhLNImCbniAzqstedjvUWoGyk.main_params)
  elif VrfXREhLNImCbniAzqstedjvUWoGwY=='GN_MYVIEW':
   VrfXREhLNImCbniAzqstedjvUWoGyk.dp_Myview_Group(VrfXREhLNImCbniAzqstedjvUWoGyk.main_params)
  elif VrfXREhLNImCbniAzqstedjvUWoGwY=='MYVIEW_LIST':
   VrfXREhLNImCbniAzqstedjvUWoGyk.dp_Myview_List(VrfXREhLNImCbniAzqstedjvUWoGyk.main_params)
  elif VrfXREhLNImCbniAzqstedjvUWoGwY=='GENRE':
   VrfXREhLNImCbniAzqstedjvUWoGyk.dp_Genre_Group(VrfXREhLNImCbniAzqstedjvUWoGyk.main_params)
  elif VrfXREhLNImCbniAzqstedjvUWoGwY=='GENRE_LIST':
   VrfXREhLNImCbniAzqstedjvUWoGyk.dp_Genre_List(VrfXREhLNImCbniAzqstedjvUWoGyk.main_params)
  elif VrfXREhLNImCbniAzqstedjvUWoGwY=='WATCH':
   VrfXREhLNImCbniAzqstedjvUWoGyk.dp_Watch_List(VrfXREhLNImCbniAzqstedjvUWoGyk.main_params)
  elif VrfXREhLNImCbniAzqstedjvUWoGwY=='MYVIEW_REMOVE':
   VrfXREhLNImCbniAzqstedjvUWoGyk.dp_WatchList_Delete(VrfXREhLNImCbniAzqstedjvUWoGyk.main_params)
  elif VrfXREhLNImCbniAzqstedjvUWoGwY=='SEARCH':
   VrfXREhLNImCbniAzqstedjvUWoGyk.dp_Search_Group(VrfXREhLNImCbniAzqstedjvUWoGyk.main_params)
  elif VrfXREhLNImCbniAzqstedjvUWoGwY=='SEARCH_LIST':
   VrfXREhLNImCbniAzqstedjvUWoGyk.dp_Search_List(VrfXREhLNImCbniAzqstedjvUWoGyk.main_params)
  elif VrfXREhLNImCbniAzqstedjvUWoGwY=='ORDER_BY':
   VrfXREhLNImCbniAzqstedjvUWoGyk.dp_setEpOrderby(VrfXREhLNImCbniAzqstedjvUWoGyk.main_params)
  else:
   VrfXREhLNImCbniAzqstedjvUWoGJO
# Created by pyminifier (https://github.com/liftoff/pyminifier)
