__author__="NightRain"
wxlSzvIeAMOCFGqWaNrHTiPhEQcgjk=object
wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt=None
wxlSzvIeAMOCFGqWaNrHTiPhEQcgjR=False
wxlSzvIeAMOCFGqWaNrHTiPhEQcgjd=range
wxlSzvIeAMOCFGqWaNrHTiPhEQcgjs=str
wxlSzvIeAMOCFGqWaNrHTiPhEQcgjf=True
wxlSzvIeAMOCFGqWaNrHTiPhEQcgjK=Exception
wxlSzvIeAMOCFGqWaNrHTiPhEQcgjp=print
wxlSzvIeAMOCFGqWaNrHTiPhEQcgjX=len
wxlSzvIeAMOCFGqWaNrHTiPhEQcgju=dict
wxlSzvIeAMOCFGqWaNrHTiPhEQcgjU=int
import urllib
import http.cookiejar 
import re
import json
import sys
import requests
import datetime
wxlSzvIeAMOCFGqWaNrHTiPhEQcgJV='Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'
class wxlSzvIeAMOCFGqWaNrHTiPhEQcgJB(wxlSzvIeAMOCFGqWaNrHTiPhEQcgjk):
 def __init__(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk):
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.API_DOMAIN='https://apis.pooq.co.kr'
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.APIKEY='E5F3E0D30947AA5440556471321BB6D9'
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.CREDENTIAL='none'
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.DEVICE='pc'
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.DRM='wm'
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.PARTNER='pooq'
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.POOQZONE='none'
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.REGION='kor'
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.TARGETAGE ='all'
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.HTTPTAG='https://'
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.LIST_LIMIT=30 
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.EP_LIMIT=30 
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.MV_LIMIT=24 
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.guid='none' 
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.guidtimestamp='none' 
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.DEFAULT_HEADER={'user-agent':wxlSzvIeAMOCFGqWaNrHTiPhEQcgJV}
 def callRequestCookies(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk,jobtype,wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs,payload=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,params=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,headers=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,cookies=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,redirects=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjR):
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgJj=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.DEFAULT_HEADER
  if headers:wxlSzvIeAMOCFGqWaNrHTiPhEQcgJj.update(headers)
  if jobtype=='Get':
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJt=requests.get(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs,params=params,headers=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJj,cookies=cookies,allow_redirects=redirects)
  else:
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJt=requests.post(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs,data=payload,params=params,headers=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJj,cookies=cookies,allow_redirects=redirects)
  return wxlSzvIeAMOCFGqWaNrHTiPhEQcgJt
 def SaveCredential(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk,wxlSzvIeAMOCFGqWaNrHTiPhEQcgJR):
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.CREDENTIAL=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJR
 def LoadCredential(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk):
  return wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.CREDENTIAL
 def GetDefaultParams(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk):
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgJd={'apikey':wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.APIKEY,'credential':wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.CREDENTIAL,'device':wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.DEVICE,'drm':wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.DRM,'partner':wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.PARTNER,'pooqzone':wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.POOQZONE,'region':wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.REGION,'targetage':wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.TARGETAGE}
  return wxlSzvIeAMOCFGqWaNrHTiPhEQcgJd
 def makeurl(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk,domain,path,query1=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,query2=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt):
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs=domain+path
  if query1:
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs+='?%s'%urllib.parse.urlencode(query1)
  if query2:
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs+='&%s'%urllib.parse.urlencode(query2)
  return wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs
 def GetGUID(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJp=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJX=GenerateRandomString(5)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJu=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJX+media+wxlSzvIeAMOCFGqWaNrHTiPhEQcgJp
   return wxlSzvIeAMOCFGqWaNrHTiPhEQcgJu
  def GenerateRandomString(num):
   from random import randint
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJU=""
   for i in wxlSzvIeAMOCFGqWaNrHTiPhEQcgjd(0,num):
    s=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjs(randint(1,5))
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgJU+=s
   return wxlSzvIeAMOCFGqWaNrHTiPhEQcgJU
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgJu=GenerateID(guid_str)
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgJo=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.GetHash(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJu)
  if guidType==2:
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJo='%s-%s-%s-%s-%s'%(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJo[:8],wxlSzvIeAMOCFGqWaNrHTiPhEQcgJo[8:12],wxlSzvIeAMOCFGqWaNrHTiPhEQcgJo[12:16],wxlSzvIeAMOCFGqWaNrHTiPhEQcgJo[16:20],wxlSzvIeAMOCFGqWaNrHTiPhEQcgJo[20:])
  return wxlSzvIeAMOCFGqWaNrHTiPhEQcgJo
 def GetHash(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return wxlSzvIeAMOCFGqWaNrHTiPhEQcgjs(m.hexdigest())
 def CheckQuality(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk,sel_qt,qt_list):
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgJY=0
  for wxlSzvIeAMOCFGqWaNrHTiPhEQcgJn in qt_list:
   if sel_qt>=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJn:return wxlSzvIeAMOCFGqWaNrHTiPhEQcgJn
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJY=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJn
  return wxlSzvIeAMOCFGqWaNrHTiPhEQcgJY
 def GetCredential(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk,user_id,user_pw,user_pf):
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgJD=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjR
  try:
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb='/login'
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJd=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.GetDefaultParams()
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJL={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.makeurl(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.API_DOMAIN,wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJy=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.callRequestCookies('Post',wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs,payload=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJL,params=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJd,headers=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,cookies=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm=json.loads(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJy.text)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJR=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['credential']
   if user_pf!=0:
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgJL={'id':wxlSzvIeAMOCFGqWaNrHTiPhEQcgJR,'password':'','profile':wxlSzvIeAMOCFGqWaNrHTiPhEQcgjs(user_pf),'pushid':'','type':'credential'}
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgJd['credential']=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJR 
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgJy=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.callRequestCookies('Post',wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs,payload=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJL,params=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJd,headers=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,cookies=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt)
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm=json.loads(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJy.text)
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgJR=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['credential']
   if wxlSzvIeAMOCFGqWaNrHTiPhEQcgJR:wxlSzvIeAMOCFGqWaNrHTiPhEQcgJD=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjf
  except wxlSzvIeAMOCFGqWaNrHTiPhEQcgjK as exception:
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgjp(exception)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJR='none' 
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.SaveCredential(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJR)
  return wxlSzvIeAMOCFGqWaNrHTiPhEQcgJD
 def GetIssue(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk):
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgBJ=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjR
  try:
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb='/guid/issue'
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJd=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.GetDefaultParams()
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.makeurl(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.API_DOMAIN,wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJy=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.callRequestCookies('Get',wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs,payload=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,params=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJd,headers=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,cookies=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm=json.loads(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJy.text)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBV=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['guid']
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBk=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['guidtimestamp']
   if wxlSzvIeAMOCFGqWaNrHTiPhEQcgBV:wxlSzvIeAMOCFGqWaNrHTiPhEQcgBJ=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjf
  except wxlSzvIeAMOCFGqWaNrHTiPhEQcgjK as exception:
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgjp(exception)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBV='none'
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBk='none' 
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.guid=wxlSzvIeAMOCFGqWaNrHTiPhEQcgBV
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.guidtimestamp=wxlSzvIeAMOCFGqWaNrHTiPhEQcgBk
  return wxlSzvIeAMOCFGqWaNrHTiPhEQcgBJ
 def GetGnList(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk,gn_str):
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgBj=[]
  try:
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb='/cf/supermultisections/'+gn_str
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJd=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.GetDefaultParams()
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.makeurl(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.API_DOMAIN,wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJy=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.callRequestCookies('Get',wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs,payload=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,params=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJd,headers=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,cookies=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm=json.loads(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJy.text)
   if not('multisectionlist' in wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm):return wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt 
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBt=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['multisectionlist']
   for wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR in wxlSzvIeAMOCFGqWaNrHTiPhEQcgBt:
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgBd=wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR['title']
    if wxlSzvIeAMOCFGqWaNrHTiPhEQcgjX(wxlSzvIeAMOCFGqWaNrHTiPhEQcgBd)==0:continue
    if wxlSzvIeAMOCFGqWaNrHTiPhEQcgBd=='minor':continue 
    if re.search(u'베너',wxlSzvIeAMOCFGqWaNrHTiPhEQcgBd):continue
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgBd=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',wxlSzvIeAMOCFGqWaNrHTiPhEQcgBd)
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgBd=wxlSzvIeAMOCFGqWaNrHTiPhEQcgBd.lstrip('#')
    for wxlSzvIeAMOCFGqWaNrHTiPhEQcgBs in wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR['eventlist'][0]['bodylist']:
     if re.search(r'uicode:',wxlSzvIeAMOCFGqWaNrHTiPhEQcgBs):
      wxlSzvIeAMOCFGqWaNrHTiPhEQcgBf={'title':wxlSzvIeAMOCFGqWaNrHTiPhEQcgBd,'uicode':re.sub(r'uicode:','',wxlSzvIeAMOCFGqWaNrHTiPhEQcgBs)}
      wxlSzvIeAMOCFGqWaNrHTiPhEQcgBj.append(wxlSzvIeAMOCFGqWaNrHTiPhEQcgBf)
      break
  except wxlSzvIeAMOCFGqWaNrHTiPhEQcgjK as exception:
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgjp(exception)
  return wxlSzvIeAMOCFGqWaNrHTiPhEQcgBj
 def GetDeeplinkList(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk,gn_str,came_str,page_int,addinfoyn=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjR):
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgBK=[]
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgBp=wxlSzvIeAMOCFGqWaNrHTiPhEQcgVR=1
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgBX='quick'
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgBu=wxlSzvIeAMOCFGqWaNrHTiPhEQcgVk=wxlSzvIeAMOCFGqWaNrHTiPhEQcgVj=''
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgBU=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjR
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgBo={}
  try:
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb='/cf/deeplink/'+gn_str
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJd=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.GetDefaultParams()
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.makeurl(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.API_DOMAIN,wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJy=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.callRequestCookies('Get',wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs,payload=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,params=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJd,headers=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,cookies=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm=json.loads(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJy.text)
   if not('url' in wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm):return wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt 
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBY=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['url']
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb=urllib.parse.urlsplit(wxlSzvIeAMOCFGqWaNrHTiPhEQcgBY).path
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn=wxlSzvIeAMOCFGqWaNrHTiPhEQcgju(urllib.parse.parse_qsl(urllib.parse.urlsplit(wxlSzvIeAMOCFGqWaNrHTiPhEQcgBY).query))
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn['came']=came_str 
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn['limit']=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjs(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.LIST_LIMIT)
   if 'contenttype' in wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn:wxlSzvIeAMOCFGqWaNrHTiPhEQcgBX=wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn['contenttype']
   if came_str=='movie':wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn['mtype']='svod'
   if page_int!=1:
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn['offset']=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjs((page_int-1)*wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.LIST_LIMIT)
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn['page'] =wxlSzvIeAMOCFGqWaNrHTiPhEQcgjs(page_int)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.HTTPTAG+wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn.update(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJd)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJy=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.callRequestCookies('Get',wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs,payload=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,params=wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn,headers=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,cookies=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm=json.loads(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJy.text)
   if not('celllist' in wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['cell_toplist']):return wxlSzvIeAMOCFGqWaNrHTiPhEQcgBK,wxlSzvIeAMOCFGqWaNrHTiPhEQcgBU 
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBD=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['cell_toplist']['celllist']
   if(wxlSzvIeAMOCFGqWaNrHTiPhEQcgBX=='channel' and came_str=='live'):
    if('genre' in wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn):
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgBb=wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn['genre']
    else:
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgBb='all'
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgjp("*epgcall*")
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgBo=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.GetEPGList(wxlSzvIeAMOCFGqWaNrHTiPhEQcgBb)
   for wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR in wxlSzvIeAMOCFGqWaNrHTiPhEQcgBD:
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgBL=wxlSzvIeAMOCFGqWaNrHTiPhEQcgBm=thumbnail=''
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgBL=wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('title_list')[0].get('text')
    if(wxlSzvIeAMOCFGqWaNrHTiPhEQcgjX(wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('title_list'))>1):
     if(wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('title_list')[1].get('text').startswith('@')):
      for wxlSzvIeAMOCFGqWaNrHTiPhEQcgBy in wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('bottom_taglist'):
       if wxlSzvIeAMOCFGqWaNrHTiPhEQcgBy=='playy' or wxlSzvIeAMOCFGqWaNrHTiPhEQcgBy=='won':wxlSzvIeAMOCFGqWaNrHTiPhEQcgBm=wxlSzvIeAMOCFGqWaNrHTiPhEQcgBy
     else:
      wxlSzvIeAMOCFGqWaNrHTiPhEQcgBm=wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('title_list')[1].get('text')
      wxlSzvIeAMOCFGqWaNrHTiPhEQcgBm=re.sub(r'(\$O\$)|(\&[a-z]{2}\;)','',wxlSzvIeAMOCFGqWaNrHTiPhEQcgBm)
    if(wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('thumbnail')!=''):thumbnail='https://%s'%wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('thumbnail')
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVJ=wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR['event_list'][1].get('url')
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVB=wxlSzvIeAMOCFGqWaNrHTiPhEQcgju(urllib.parse.parse_qsl(urllib.parse.urlsplit(wxlSzvIeAMOCFGqWaNrHTiPhEQcgVJ).query))
    if re.search(u'programid=\&',wxlSzvIeAMOCFGqWaNrHTiPhEQcgVJ)and('contentid' in wxlSzvIeAMOCFGqWaNrHTiPhEQcgVB):
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgBu=wxlSzvIeAMOCFGqWaNrHTiPhEQcgVB['contentid']
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgVk='direct'
    elif('contentid' in wxlSzvIeAMOCFGqWaNrHTiPhEQcgVB):
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgBu=wxlSzvIeAMOCFGqWaNrHTiPhEQcgVB['contentid']
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgVk='contentid'
    elif('programid' in wxlSzvIeAMOCFGqWaNrHTiPhEQcgVB):
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgBu=wxlSzvIeAMOCFGqWaNrHTiPhEQcgVB['programid']
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgVk='programid'
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgBX ='program' 
    elif('channelid' in wxlSzvIeAMOCFGqWaNrHTiPhEQcgVB):
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgBu=wxlSzvIeAMOCFGqWaNrHTiPhEQcgVB['channelid']
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgVk='channelid'
     if wxlSzvIeAMOCFGqWaNrHTiPhEQcgBu in wxlSzvIeAMOCFGqWaNrHTiPhEQcgBo:
      wxlSzvIeAMOCFGqWaNrHTiPhEQcgVj=wxlSzvIeAMOCFGqWaNrHTiPhEQcgBo[wxlSzvIeAMOCFGqWaNrHTiPhEQcgBu]
     else:
      wxlSzvIeAMOCFGqWaNrHTiPhEQcgVj=''
    elif('movieid' in wxlSzvIeAMOCFGqWaNrHTiPhEQcgVB):
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgBu=wxlSzvIeAMOCFGqWaNrHTiPhEQcgVB['movieid']
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgVk='movieid'
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgBX='movie' 
    else:
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgBu ='-'
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgVk='-'
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt={}
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['mpaa'] =wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('age')
    try:
     if('channelid' in wxlSzvIeAMOCFGqWaNrHTiPhEQcgVB):
      wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['mediatype'] ='video'
      wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['title'] ='%s < %s >'%(wxlSzvIeAMOCFGqWaNrHTiPhEQcgBL,wxlSzvIeAMOCFGqWaNrHTiPhEQcgBm)
      wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['tvshowtitle']=wxlSzvIeAMOCFGqWaNrHTiPhEQcgBm
      wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['studio'] =wxlSzvIeAMOCFGqWaNrHTiPhEQcgBL
     elif('movieid' in wxlSzvIeAMOCFGqWaNrHTiPhEQcgVB):
      wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['mediatype'] ='movie'
      wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['title'] =title_list
     else:
      wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['mediatype'] ='episode'
      wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['title'] =title_list
    except:
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgBf={'title':wxlSzvIeAMOCFGqWaNrHTiPhEQcgBL,'subtitle':wxlSzvIeAMOCFGqWaNrHTiPhEQcgBm,'thumbnail':thumbnail,'uicode':wxlSzvIeAMOCFGqWaNrHTiPhEQcgBX,'contentid':wxlSzvIeAMOCFGqWaNrHTiPhEQcgBu,'contentidType':wxlSzvIeAMOCFGqWaNrHTiPhEQcgVk,'viewage':wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('age'),'channelepg':wxlSzvIeAMOCFGqWaNrHTiPhEQcgVj,'info':wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt}
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgBK.append(wxlSzvIeAMOCFGqWaNrHTiPhEQcgBf)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBp=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjU(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['cell_toplist']['pagecount'])
   if wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['cell_toplist']['count']:wxlSzvIeAMOCFGqWaNrHTiPhEQcgVR =wxlSzvIeAMOCFGqWaNrHTiPhEQcgjU(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['cell_toplist']['count'])
   else:wxlSzvIeAMOCFGqWaNrHTiPhEQcgVR=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.LIST_LIMIT
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBU=wxlSzvIeAMOCFGqWaNrHTiPhEQcgBp>wxlSzvIeAMOCFGqWaNrHTiPhEQcgVR
  except wxlSzvIeAMOCFGqWaNrHTiPhEQcgjK as exception:
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgjp(exception)
  try:
   if wxlSzvIeAMOCFGqWaNrHTiPhEQcgBK[0].get('contentidType')=='movieid' and addinfoyn==wxlSzvIeAMOCFGqWaNrHTiPhEQcgjf:
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVd=[]
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVs={}
    for wxlSzvIeAMOCFGqWaNrHTiPhEQcgVf in wxlSzvIeAMOCFGqWaNrHTiPhEQcgBK:wxlSzvIeAMOCFGqWaNrHTiPhEQcgVd.append(wxlSzvIeAMOCFGqWaNrHTiPhEQcgVf.get('contentid'))
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVs=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.GetMovieInfoList(wxlSzvIeAMOCFGqWaNrHTiPhEQcgVd)
    for i in wxlSzvIeAMOCFGqWaNrHTiPhEQcgjd(wxlSzvIeAMOCFGqWaNrHTiPhEQcgjX(wxlSzvIeAMOCFGqWaNrHTiPhEQcgBK)):
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgBK[i]['info']=wxlSzvIeAMOCFGqWaNrHTiPhEQcgVs.get(wxlSzvIeAMOCFGqWaNrHTiPhEQcgBK[i]['contentid'])
  except:
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt
  return(wxlSzvIeAMOCFGqWaNrHTiPhEQcgBK,wxlSzvIeAMOCFGqWaNrHTiPhEQcgBU)
 def GetEpisodeList(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk,wxlSzvIeAMOCFGqWaNrHTiPhEQcgBu,wxlSzvIeAMOCFGqWaNrHTiPhEQcgBX,wxlSzvIeAMOCFGqWaNrHTiPhEQcgVk,page_int,orderby='desc'):
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgVK=[]
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgBp=wxlSzvIeAMOCFGqWaNrHTiPhEQcgVR=1
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgBU=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjR
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJd=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.GetDefaultParams()
   if wxlSzvIeAMOCFGqWaNrHTiPhEQcgVk=='contentid':
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb='/cf/vod/contents/'+wxlSzvIeAMOCFGqWaNrHTiPhEQcgBu
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.makeurl(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.API_DOMAIN,wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb)
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgJy=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.callRequestCookies('Get',wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs,payload=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,params=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJd,headers=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,cookies=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt)
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm=json.loads(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJy.text)
    if not('programid' in wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm):return wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt 
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVX=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['programid']
   else:
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVX=wxlSzvIeAMOCFGqWaNrHTiPhEQcgBu
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb='/vod/programs-contents/'+wxlSzvIeAMOCFGqWaNrHTiPhEQcgVX
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn={'limit':wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.EP_LIMIT,'offset':wxlSzvIeAMOCFGqWaNrHTiPhEQcgjs((page_int-1)*wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.EP_LIMIT),'orderby':orderby}
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.makeurl(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.API_DOMAIN,wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn.update(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJd)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJy=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.callRequestCookies('Get',wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs,payload=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,params=wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn,headers=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,cookies=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm=json.loads(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJy.text)
   if not('list' in wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm):return wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt 
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgVu=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['list']
   for wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR in wxlSzvIeAMOCFGqWaNrHTiPhEQcgVu:
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVU =wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('programtitle')
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVo ='%s회, %s(%s)'%(wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('episodenumber'),wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('releasedate'),wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('releaseweekday'))
    if(wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('image')!=''):tmp_thumbnail='https://%s'%wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('image')
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVY=wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('synopsis')
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVY=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',wxlSzvIeAMOCFGqWaNrHTiPhEQcgVY)
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt={}
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['title'] =wxlSzvIeAMOCFGqWaNrHTiPhEQcgVU
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['mediatype']='episode' 
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['mpaa'] =wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('targetage')
    try:
     if 'episodenumber' in wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR:wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['episode'] =wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('episodenumber')
     if 'releasedate' in wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR:wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['year'] =wxlSzvIeAMOCFGqWaNrHTiPhEQcgjU(wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('releasedate')[:4])
     if 'releasedate' in wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR:wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['aired'] =wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('releasedate')
     if 'playtime' in wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR:wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['duration']=wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('playtime')
     if 'episodeactors' in wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR:
      if wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('episodeactors')!='':wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['cast']=wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('episodeactors').split(',')
    except:
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVn={'title':wxlSzvIeAMOCFGqWaNrHTiPhEQcgVU,'subtitle':wxlSzvIeAMOCFGqWaNrHTiPhEQcgVo,'thumbnail':tmp_thumbnail,'uicode':wxlSzvIeAMOCFGqWaNrHTiPhEQcgBX,'contentid':wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('contentid'),'programid':wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('programid'),'synopsis':wxlSzvIeAMOCFGqWaNrHTiPhEQcgVY,'viewage':wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('targetage'),'info':wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt}
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVK.append(wxlSzvIeAMOCFGqWaNrHTiPhEQcgVn)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBp=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjU(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['pagecount'])
   if wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['count']:wxlSzvIeAMOCFGqWaNrHTiPhEQcgVR =wxlSzvIeAMOCFGqWaNrHTiPhEQcgjU(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['count'])
   else:wxlSzvIeAMOCFGqWaNrHTiPhEQcgVR=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.EP_LIMIT
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBU=wxlSzvIeAMOCFGqWaNrHTiPhEQcgBp>wxlSzvIeAMOCFGqWaNrHTiPhEQcgVR
  except wxlSzvIeAMOCFGqWaNrHTiPhEQcgjK as exception:
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgjp(exception)
  return(wxlSzvIeAMOCFGqWaNrHTiPhEQcgVK,wxlSzvIeAMOCFGqWaNrHTiPhEQcgBU)
 def GetMyviewList(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk,wxlSzvIeAMOCFGqWaNrHTiPhEQcgBX,page_int,addinfoyn=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjR):
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgVD=[]
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgBp=wxlSzvIeAMOCFGqWaNrHTiPhEQcgVR=1
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgBU=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjR
  try:
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJd=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.GetDefaultParams()
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb='/myview/contents'
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn={'contenttype':wxlSzvIeAMOCFGqWaNrHTiPhEQcgBX,'limit':wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.MV_LIMIT,'offset':wxlSzvIeAMOCFGqWaNrHTiPhEQcgjs((page_int-1)*wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.MV_LIMIT),'orderby':'new'}
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.makeurl(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.API_DOMAIN,wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn.update(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJd)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJy=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.callRequestCookies('Get',wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs,payload=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,params=wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn,headers=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,cookies=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm=json.loads(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJy.text)
   if not('list' in wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm[0]):return wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt 
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgVb=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm[0]['list']
   for wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR in wxlSzvIeAMOCFGqWaNrHTiPhEQcgVb:
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt={}
    if wxlSzvIeAMOCFGqWaNrHTiPhEQcgBX=='vod':
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgVU =wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('programtitle')
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgVo='%s회, %s'%(wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('episodenumber'),wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('releasedate'))
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgBu=wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('contentid')
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgVX=wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('programid')
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['title'] =wxlSzvIeAMOCFGqWaNrHTiPhEQcgVU
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['mediatype']='episode' 
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['mpaa'] =wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('targetage')
     try:
      wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['studio'] =wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('channelname')
     except:
      wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt
     try:
      if 'releasedate' in wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR:wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['year'] =wxlSzvIeAMOCFGqWaNrHTiPhEQcgjU(wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('releasedate')[:4])
      if 'releasedate' in wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR:wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['aired'] =wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('releasedate')
     except:
      wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt
    else:
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgVU =wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('title')
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgVo='' 
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgBu=wxlSzvIeAMOCFGqWaNrHTiPhEQcgVX=wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('movieid')
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['title'] =wxlSzvIeAMOCFGqWaNrHTiPhEQcgVU
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['mediatype']='movie' 
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['mpaa'] =wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('targetage')
     try:
      if 'releasedate' in wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR:wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['year'] =wxlSzvIeAMOCFGqWaNrHTiPhEQcgjU(wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('releasedate')[:4])
      if 'releasedate' in wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR:wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['aired'] =wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('releasedate')
     except:
      wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt
    if(wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('image')!=''):tmp_thumbnail='https://%s'%wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('image')
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVL={'title':wxlSzvIeAMOCFGqWaNrHTiPhEQcgVU,'subtitle':wxlSzvIeAMOCFGqWaNrHTiPhEQcgVo,'thumbnail':tmp_thumbnail,'uicode':wxlSzvIeAMOCFGqWaNrHTiPhEQcgBX,'contentid':wxlSzvIeAMOCFGqWaNrHTiPhEQcgBu,'programid':wxlSzvIeAMOCFGqWaNrHTiPhEQcgVX,'viewage':wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('targetage'),'info':wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt}
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVD.append(wxlSzvIeAMOCFGqWaNrHTiPhEQcgVL)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBp=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjU(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm[0]['pagecount'])
   if wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm[0]['count']:wxlSzvIeAMOCFGqWaNrHTiPhEQcgVR =wxlSzvIeAMOCFGqWaNrHTiPhEQcgjU(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm[0]['count'])
   else:wxlSzvIeAMOCFGqWaNrHTiPhEQcgVR=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.MV_LIMIT
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBU=wxlSzvIeAMOCFGqWaNrHTiPhEQcgBp>wxlSzvIeAMOCFGqWaNrHTiPhEQcgVR
  except wxlSzvIeAMOCFGqWaNrHTiPhEQcgjK as exception:
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgjp(exception)
  try:
   if wxlSzvIeAMOCFGqWaNrHTiPhEQcgBX=='movie' and addinfoyn==wxlSzvIeAMOCFGqWaNrHTiPhEQcgjf:
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVd=[]
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVs={}
    for wxlSzvIeAMOCFGqWaNrHTiPhEQcgVf in wxlSzvIeAMOCFGqWaNrHTiPhEQcgVD:wxlSzvIeAMOCFGqWaNrHTiPhEQcgVd.append(wxlSzvIeAMOCFGqWaNrHTiPhEQcgVf.get('contentid'))
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVs=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.GetMovieInfoList(wxlSzvIeAMOCFGqWaNrHTiPhEQcgVd)
    for i in wxlSzvIeAMOCFGqWaNrHTiPhEQcgjd(wxlSzvIeAMOCFGqWaNrHTiPhEQcgjX(wxlSzvIeAMOCFGqWaNrHTiPhEQcgVD)):
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgVD[i]['info']=wxlSzvIeAMOCFGqWaNrHTiPhEQcgVs.get(wxlSzvIeAMOCFGqWaNrHTiPhEQcgVD[i]['contentid'])
  except:
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt
  return wxlSzvIeAMOCFGqWaNrHTiPhEQcgVD,wxlSzvIeAMOCFGqWaNrHTiPhEQcgBU
 def GetSearchList(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk,search_key,genre,page_int,exclusion21=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjR,addinfoyn=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjR):
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgVy=[]
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgBp=wxlSzvIeAMOCFGqWaNrHTiPhEQcgVR=1
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgBU=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjR
  try:
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJd=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.GetDefaultParams()
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb='/cf/search/list.js'
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn={'type':'program' if genre=='vod' else 'movie','keyword':search_key,'offset':wxlSzvIeAMOCFGqWaNrHTiPhEQcgjs((page_int-1)*wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.LIST_LIMIT),'limit':wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.LIST_LIMIT,'orderby':'score','isplayymovie':'y'}
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.makeurl(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.API_DOMAIN,wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn.update(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJd)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJy=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.callRequestCookies('Get',wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs,payload=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,params=wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn,headers=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,cookies=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm=json.loads(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJy.text)
   if not('celllist' in wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['cell_toplist']):return wxlSzvIeAMOCFGqWaNrHTiPhEQcgVy,wxlSzvIeAMOCFGqWaNrHTiPhEQcgBU
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgVm=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['cell_toplist']['celllist']
   for wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR in wxlSzvIeAMOCFGqWaNrHTiPhEQcgVm:
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt={}
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVU =wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR['title_list'][0]['text']
    if(wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('thumbnail')!=''):tmp_thumbnail='https://%s'%wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('thumbnail')
    for wxlSzvIeAMOCFGqWaNrHTiPhEQcgBs in wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR['event_list'][0]['bodylist']:
     if re.search(r'uicode:',wxlSzvIeAMOCFGqWaNrHTiPhEQcgBs):
      if genre=='vod':
       wxlSzvIeAMOCFGqWaNrHTiPhEQcgBu=''
       wxlSzvIeAMOCFGqWaNrHTiPhEQcgVX=re.sub(r'uicode:','',wxlSzvIeAMOCFGqWaNrHTiPhEQcgBs)
       wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['mediatype']='episode' 
      else:
       wxlSzvIeAMOCFGqWaNrHTiPhEQcgBu=re.sub(r'uicode:','',wxlSzvIeAMOCFGqWaNrHTiPhEQcgBs)
       wxlSzvIeAMOCFGqWaNrHTiPhEQcgVX=''
       if wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('bottom_taglist')[0]=='playy':
        wxlSzvIeAMOCFGqWaNrHTiPhEQcgVU+=' [playy]'
       wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['mediatype']='movie' 
      wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['title'] =wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR['title_list'][0]['text']
      wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['mpaa'] =wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('age')
      wxlSzvIeAMOCFGqWaNrHTiPhEQcgVL={'title':wxlSzvIeAMOCFGqWaNrHTiPhEQcgVU,'thumbnail':tmp_thumbnail,'uicode':genre,'contentid':wxlSzvIeAMOCFGqWaNrHTiPhEQcgBu,'programid':wxlSzvIeAMOCFGqWaNrHTiPhEQcgVX,'viewage':wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('age'),'info':wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt}
    if exclusion21==wxlSzvIeAMOCFGqWaNrHTiPhEQcgjR or wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('age')!='21':
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgVy.append(wxlSzvIeAMOCFGqWaNrHTiPhEQcgVL)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBp=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjU(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['cell_toplist']['pagecount'])
   if wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['cell_toplist']['count']:wxlSzvIeAMOCFGqWaNrHTiPhEQcgVR =wxlSzvIeAMOCFGqWaNrHTiPhEQcgjU(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['cell_toplist']['count'])
   else:wxlSzvIeAMOCFGqWaNrHTiPhEQcgVR=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.LIST_LIMIT
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBU=wxlSzvIeAMOCFGqWaNrHTiPhEQcgBp>wxlSzvIeAMOCFGqWaNrHTiPhEQcgVR
  except wxlSzvIeAMOCFGqWaNrHTiPhEQcgjK as exception:
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgjp(exception)
  try:
   if genre=='movie' and addinfoyn==wxlSzvIeAMOCFGqWaNrHTiPhEQcgjf:
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVd=[]
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVs={}
    for wxlSzvIeAMOCFGqWaNrHTiPhEQcgVf in wxlSzvIeAMOCFGqWaNrHTiPhEQcgVy:wxlSzvIeAMOCFGqWaNrHTiPhEQcgVd.append(wxlSzvIeAMOCFGqWaNrHTiPhEQcgVf.get('contentid'))
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVs=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.GetMovieInfoList(wxlSzvIeAMOCFGqWaNrHTiPhEQcgVd)
    for i in wxlSzvIeAMOCFGqWaNrHTiPhEQcgjd(wxlSzvIeAMOCFGqWaNrHTiPhEQcgjX(wxlSzvIeAMOCFGqWaNrHTiPhEQcgVy)):
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgVy[i]['info']=wxlSzvIeAMOCFGqWaNrHTiPhEQcgVs.get(wxlSzvIeAMOCFGqWaNrHTiPhEQcgVy[i]['contentid'])
  except:
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt
  return wxlSzvIeAMOCFGqWaNrHTiPhEQcgVy,wxlSzvIeAMOCFGqWaNrHTiPhEQcgBU 
 def GetGenreGroup(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk,maintype,subtype,wxlSzvIeAMOCFGqWaNrHTiPhEQcgVp,ordernm,exclusion21=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjR):
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgkJ=[]
  try:
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJd=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.GetDefaultParams()
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb='/cf/filters'
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn={'type':maintype}
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.makeurl(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.API_DOMAIN,wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn.update(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJd)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJy=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.callRequestCookies('Get',wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs,payload=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,params=wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn,headers=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,cookies=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm=json.loads(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJy.text)
   if not(maintype in wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm):return wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt 
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgkB=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm[maintype]
   if subtype=='-':
    for wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR in wxlSzvIeAMOCFGqWaNrHTiPhEQcgkB:
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgkV=wxlSzvIeAMOCFGqWaNrHTiPhEQcgju(urllib.parse.parse_qsl(urllib.parse.urlsplit(wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('url')).query))
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgVL={'title':wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('text'),'genre':wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('id'),'subgenre':'-','adult':wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('adult'),'broadcastid':wxlSzvIeAMOCFGqWaNrHTiPhEQcgkV.get('broadcastid'),'contenttype':wxlSzvIeAMOCFGqWaNrHTiPhEQcgkV.get('contenttype'),'uiparent':wxlSzvIeAMOCFGqWaNrHTiPhEQcgkV.get('uiparent'),'uirank':wxlSzvIeAMOCFGqWaNrHTiPhEQcgkV.get('uirank'),'uitype':wxlSzvIeAMOCFGqWaNrHTiPhEQcgkV.get('uitype'),'orderby':wxlSzvIeAMOCFGqWaNrHTiPhEQcgVp,'ordernm':ordernm}
     if exclusion21==wxlSzvIeAMOCFGqWaNrHTiPhEQcgjR or wxlSzvIeAMOCFGqWaNrHTiPhEQcgVL.get('adult')=='n':
      wxlSzvIeAMOCFGqWaNrHTiPhEQcgkJ.append(wxlSzvIeAMOCFGqWaNrHTiPhEQcgVL)
   else:
    for wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR in wxlSzvIeAMOCFGqWaNrHTiPhEQcgkB:
     if wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('id')==subtype:
      for tt in wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR['sublist']:
       wxlSzvIeAMOCFGqWaNrHTiPhEQcgkV=wxlSzvIeAMOCFGqWaNrHTiPhEQcgju(urlparse.parse_qsl(urlparse.urlsplit(tt.get('url')).query))
       wxlSzvIeAMOCFGqWaNrHTiPhEQcgVL={'title':tt.get('text'),'genre':subtype,'subgenre':tt.get('id'),'adult':tt.get('adult'),'broadcastid':wxlSzvIeAMOCFGqWaNrHTiPhEQcgkV.get('broadcastid'),'contenttype':wxlSzvIeAMOCFGqWaNrHTiPhEQcgkV.get('contenttype'),'uiparent':wxlSzvIeAMOCFGqWaNrHTiPhEQcgkV.get('uiparent'),'uirank':wxlSzvIeAMOCFGqWaNrHTiPhEQcgkV.get('uirank'),'uitype':wxlSzvIeAMOCFGqWaNrHTiPhEQcgkV.get('uitype'),'orderby':wxlSzvIeAMOCFGqWaNrHTiPhEQcgVp,'ordernm':ordernm}
       wxlSzvIeAMOCFGqWaNrHTiPhEQcgkJ.append(wxlSzvIeAMOCFGqWaNrHTiPhEQcgVL)
      break
  except wxlSzvIeAMOCFGqWaNrHTiPhEQcgjK as exception:
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgjp(exception)
  return wxlSzvIeAMOCFGqWaNrHTiPhEQcgkJ
 def GetGenreGroup_sub(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk,in_params):
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgkJ=[]
  try:
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJd=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.GetDefaultParams()
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb='/cf/vod/newcontents'
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn={'WeekDay':'all','limit':'20','offset':'0','orderby':in_params.get('orderby'),'adult':in_params.get('adult'),'broadcastid':in_params.get('broadcastid'),'contenttype':in_params.get('contenttype'),'genre':in_params.get('genre'),'uiparent':in_params.get('uiparent'),'uirank':in_params.get('uirank'),'uitype':in_params.get('uitype')}
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.makeurl(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.API_DOMAIN,wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn.update(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJd)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJy=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.callRequestCookies('Get',wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs,payload=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,params=wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn,headers=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,cookies=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm=json.loads(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJy.text)
   if not('filter_item_list' in wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['filter']['filterlist'][1]):return wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt 
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgkB=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['filter']['filterlist'][1]['filter_item_list']
   for wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR in wxlSzvIeAMOCFGqWaNrHTiPhEQcgkB:
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVL={'broadcastid':in_params.get('broadcastid'),'contenttype':in_params.get('contenttype'),'genre':in_params.get('genre'),'uiparent':in_params.get('uiparent'),'uirank':in_params.get('uirank'),'uitype':in_params.get('uitype'),'adult':wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('adult'),'title':wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('title'),'subgenre':wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('api_parameters')[wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('api_parameters').find('=')+1:],'orderby':in_params.get('orderby')}
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgkJ.append(wxlSzvIeAMOCFGqWaNrHTiPhEQcgVL)
  except wxlSzvIeAMOCFGqWaNrHTiPhEQcgjK as exception:
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgjp(exception)
  return wxlSzvIeAMOCFGqWaNrHTiPhEQcgkJ
 def GetGenreList(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk,genre,in_params,page_int,addinfoyn=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjR):
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgkJ=[]
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgBp=wxlSzvIeAMOCFGqWaNrHTiPhEQcgVR=1
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgBU=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjR
  try:
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJd=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.GetDefaultParams()
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn={'WeekDay':'all','adult':in_params.get('adult'),'broadcastid':in_params.get('broadcastid'),'contenttype':in_params.get('contenttype'),'genre':in_params.get('genre'),'orderby':in_params.get('orderby'),'uiparent':in_params.get('uiparent'),'uirank':in_params.get('uirank'),'uitype':in_params.get('uitype')}
   if genre=='vodgenre':
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb='/cf/vod/newcontents'
    if in_params.get('subgenre')!='-':
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn['subgenre']=in_params.get('subgenre')
   else:
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb='/cf/movie/contents'
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn['price'] ='all'
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn['sptheme']='svod' 
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn['limit']=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.LIST_LIMIT
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn['offset']=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjs((page_int-1)*wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.LIST_LIMIT)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn['page'] =wxlSzvIeAMOCFGqWaNrHTiPhEQcgjs(page_int)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.makeurl(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.API_DOMAIN,wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn.update(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJd)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJy=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.callRequestCookies('Get',wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs,payload=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,params=wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn,headers=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,cookies=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm=json.loads(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJy.text)
   if not('celllist' in wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['cell_toplist']):return wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt 
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgkB=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['cell_toplist']['celllist']
   for wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR in wxlSzvIeAMOCFGqWaNrHTiPhEQcgkB:
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt={}
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVU=tmp_thumbnail=''
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVU =wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR['title_list'][0]['text']
    if(wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('thumbnail')!=''):tmp_thumbnail='https://%s'%wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('thumbnail')
    for wxlSzvIeAMOCFGqWaNrHTiPhEQcgBs in wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR['event_list'][0]['bodylist']:
     if re.search(r'uicode:',wxlSzvIeAMOCFGqWaNrHTiPhEQcgBs):
      wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['title'] =wxlSzvIeAMOCFGqWaNrHTiPhEQcgVU
      wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['mpaa'] =wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('age')
      if genre=='moviegenre_svod':
       wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['mediatype']='movie' 
      else:
       wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['mediatype']='episode' 
      wxlSzvIeAMOCFGqWaNrHTiPhEQcgVL={'title':wxlSzvIeAMOCFGqWaNrHTiPhEQcgVU,'uicode':re.sub(r'uicode:','',wxlSzvIeAMOCFGqWaNrHTiPhEQcgBs),'thumbnail':tmp_thumbnail,'viewage':wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR.get('age'),'info':wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt}
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgkJ.append(wxlSzvIeAMOCFGqWaNrHTiPhEQcgVL)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBp=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjU(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['cell_toplist']['pagecount'])
   if wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['cell_toplist']['count']:wxlSzvIeAMOCFGqWaNrHTiPhEQcgVR =wxlSzvIeAMOCFGqWaNrHTiPhEQcgjU(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['cell_toplist']['count'])
   else:wxlSzvIeAMOCFGqWaNrHTiPhEQcgVR=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.LIST_LIMIT
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBU=wxlSzvIeAMOCFGqWaNrHTiPhEQcgBp>wxlSzvIeAMOCFGqWaNrHTiPhEQcgVR
  except wxlSzvIeAMOCFGqWaNrHTiPhEQcgjK as exception:
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgjp(exception)
  try:
   if genre=='moviegenre_svod' and addinfoyn==wxlSzvIeAMOCFGqWaNrHTiPhEQcgjf:
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVd=[]
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVs={}
    for wxlSzvIeAMOCFGqWaNrHTiPhEQcgVf in wxlSzvIeAMOCFGqWaNrHTiPhEQcgkJ:wxlSzvIeAMOCFGqWaNrHTiPhEQcgVd.append(wxlSzvIeAMOCFGqWaNrHTiPhEQcgVf.get('uicode'))
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVs=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.GetMovieInfoList(wxlSzvIeAMOCFGqWaNrHTiPhEQcgVd)
    for i in wxlSzvIeAMOCFGqWaNrHTiPhEQcgjd(wxlSzvIeAMOCFGqWaNrHTiPhEQcgjX(wxlSzvIeAMOCFGqWaNrHTiPhEQcgkJ)):
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgkJ[i]['info']=wxlSzvIeAMOCFGqWaNrHTiPhEQcgVs.get(wxlSzvIeAMOCFGqWaNrHTiPhEQcgkJ[i]['uicode'])
  except:
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt
  return wxlSzvIeAMOCFGqWaNrHTiPhEQcgkJ,wxlSzvIeAMOCFGqWaNrHTiPhEQcgBU
 def Get_Now_Datetime(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetEPGList(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk,genre):
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgkt={}
  try:
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgkR=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.Get_Now_Datetime()
   if genre=='all':
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgkd =wxlSzvIeAMOCFGqWaNrHTiPhEQcgkR+datetime.timedelta(hours=2)
   else:
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgkd =wxlSzvIeAMOCFGqWaNrHTiPhEQcgkR+datetime.timedelta(hours=3)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJd=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.GetDefaultParams()
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn={'limit':'100','offset':'0','genre':genre,'startdatetime':wxlSzvIeAMOCFGqWaNrHTiPhEQcgkR.strftime('%Y-%m-%d %H:%M'),'enddatetime':wxlSzvIeAMOCFGqWaNrHTiPhEQcgkd.strftime('%Y-%m-%d %H:%M')}
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb='/live/epgs'
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.makeurl(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.API_DOMAIN,wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn.update(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJd)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJy=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.callRequestCookies('Get',wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs,payload=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,params=wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn,headers=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,cookies=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm=json.loads(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJy.text)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgks=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['list']
   for wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR in wxlSzvIeAMOCFGqWaNrHTiPhEQcgks:
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgkf=''
    for wxlSzvIeAMOCFGqWaNrHTiPhEQcgkK in wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR['list']:
     if wxlSzvIeAMOCFGqWaNrHTiPhEQcgkf:wxlSzvIeAMOCFGqWaNrHTiPhEQcgkf+='\n'
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgkf+=wxlSzvIeAMOCFGqWaNrHTiPhEQcgkK['title'].replace('&lt;','<').replace('&gt;','>')+'\n'
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgkf+=' [%s ~ %s]'%(wxlSzvIeAMOCFGqWaNrHTiPhEQcgkK['starttime'][-5:],wxlSzvIeAMOCFGqWaNrHTiPhEQcgkK['endtime'][-5:])+'\n'
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgkt[wxlSzvIeAMOCFGqWaNrHTiPhEQcgBR['channelid']]=wxlSzvIeAMOCFGqWaNrHTiPhEQcgkf
  except wxlSzvIeAMOCFGqWaNrHTiPhEQcgjK as exception:
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgjp(exception)
  return wxlSzvIeAMOCFGqWaNrHTiPhEQcgkt
 def GetMovieInfoList(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk,movie_list):
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgkp={}
  try:
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJd =wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.GetDefaultParams()
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.API_DOMAIN+'/movie/contents/'
   for wxlSzvIeAMOCFGqWaNrHTiPhEQcgVf in movie_list:
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb+wxlSzvIeAMOCFGqWaNrHTiPhEQcgVf
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgJy=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.callRequestCookies('Get',wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs,payload=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,params=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJd,headers=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,cookies=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt)
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm=json.loads(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJy.text)
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt={}
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['mediatype']='movie'
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgkX=[]
    for wxlSzvIeAMOCFGqWaNrHTiPhEQcgku in wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['actors']['list']:wxlSzvIeAMOCFGqWaNrHTiPhEQcgkX.append(wxlSzvIeAMOCFGqWaNrHTiPhEQcgku.get('text'))
    if wxlSzvIeAMOCFGqWaNrHTiPhEQcgkX[0]!='':wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['cast']=wxlSzvIeAMOCFGqWaNrHTiPhEQcgkX
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgkU=[]
    for wxlSzvIeAMOCFGqWaNrHTiPhEQcgko in wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['directors']['list']:wxlSzvIeAMOCFGqWaNrHTiPhEQcgkU.append(wxlSzvIeAMOCFGqWaNrHTiPhEQcgko.get('text'))
    if wxlSzvIeAMOCFGqWaNrHTiPhEQcgkU[0]!='':wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['director']=wxlSzvIeAMOCFGqWaNrHTiPhEQcgkU
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgkJ=[]
    for wxlSzvIeAMOCFGqWaNrHTiPhEQcgkY in wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['genre']['list']:wxlSzvIeAMOCFGqWaNrHTiPhEQcgkJ.append(wxlSzvIeAMOCFGqWaNrHTiPhEQcgkY.get('text'))
    if wxlSzvIeAMOCFGqWaNrHTiPhEQcgkJ[0]!='':wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['genre']=wxlSzvIeAMOCFGqWaNrHTiPhEQcgkJ
    if wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm.get('releasedate')!='':
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['year'] =wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['releasedate'][:4]
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['aired'] =wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['releasedate']
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['country']=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['country']
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['duration']=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['playtime']
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['title'] =wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['title']
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['mpaa'] =wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['targetage']
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt['plot'] =wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['synopsis']
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgkp[wxlSzvIeAMOCFGqWaNrHTiPhEQcgVf]=wxlSzvIeAMOCFGqWaNrHTiPhEQcgVt
  except wxlSzvIeAMOCFGqWaNrHTiPhEQcgjK as exception:
   return{}
  return wxlSzvIeAMOCFGqWaNrHTiPhEQcgkp
 def GetStreamingURL(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk,wxlSzvIeAMOCFGqWaNrHTiPhEQcgBu,wxlSzvIeAMOCFGqWaNrHTiPhEQcgBX,quality_int):
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgkn=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjB=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjV=streaming_preview=''
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgkD=[]
  try:
   if wxlSzvIeAMOCFGqWaNrHTiPhEQcgBX=='channel':
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb='/live/channels/'+wxlSzvIeAMOCFGqWaNrHTiPhEQcgBu
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgkb='live'
   elif wxlSzvIeAMOCFGqWaNrHTiPhEQcgBX=='movie':
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb='/cf/movie/contents/'+wxlSzvIeAMOCFGqWaNrHTiPhEQcgBu
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgkb='movie'
   else: 
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb='/cf/vod/contents/'+wxlSzvIeAMOCFGqWaNrHTiPhEQcgBu
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgkb='vod'
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJd=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.GetDefaultParams()
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.makeurl(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.API_DOMAIN,wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJy=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.callRequestCookies('Get',wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs,payload=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,params=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJd,headers=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,cookies=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm=json.loads(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJy.text)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgkL=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['qualities']['list']
   if wxlSzvIeAMOCFGqWaNrHTiPhEQcgkL==wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt:return(wxlSzvIeAMOCFGqWaNrHTiPhEQcgkn,wxlSzvIeAMOCFGqWaNrHTiPhEQcgjB,wxlSzvIeAMOCFGqWaNrHTiPhEQcgjV,streaming_preview)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgky='hls'
   if 'drms' in wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm:
    if wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['drms']:
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgky='dash'
   if 'type' in wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm:
    if wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['type']=='onair':
     wxlSzvIeAMOCFGqWaNrHTiPhEQcgkb='onairvod'
   for wxlSzvIeAMOCFGqWaNrHTiPhEQcgkm in wxlSzvIeAMOCFGqWaNrHTiPhEQcgkL:
    wxlSzvIeAMOCFGqWaNrHTiPhEQcgkD.append(wxlSzvIeAMOCFGqWaNrHTiPhEQcgjU(wxlSzvIeAMOCFGqWaNrHTiPhEQcgkm.get('id').rstrip('p')))
  except wxlSzvIeAMOCFGqWaNrHTiPhEQcgjK as exception:
   return(wxlSzvIeAMOCFGqWaNrHTiPhEQcgkn,wxlSzvIeAMOCFGqWaNrHTiPhEQcgjB,wxlSzvIeAMOCFGqWaNrHTiPhEQcgjV,streaming_preview)
  try:
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgjJ=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.CheckQuality(quality_int,wxlSzvIeAMOCFGqWaNrHTiPhEQcgkD)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb='/streaming'
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn={'contentid':wxlSzvIeAMOCFGqWaNrHTiPhEQcgBu,'contenttype':wxlSzvIeAMOCFGqWaNrHTiPhEQcgkb,'action':wxlSzvIeAMOCFGqWaNrHTiPhEQcgky,'quality':wxlSzvIeAMOCFGqWaNrHTiPhEQcgjs(wxlSzvIeAMOCFGqWaNrHTiPhEQcgjJ)+'p','deviceModelId':'Windows 10','guid':wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.GetGUID(guidType=2),'lastplayid':wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.guid,'authtype':'cookie','isabr':'y','ishevc':'n'}
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.makeurl(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.API_DOMAIN,wxlSzvIeAMOCFGqWaNrHTiPhEQcgJb)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn.update(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJd)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJy=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJk.callRequestCookies('Get',wxlSzvIeAMOCFGqWaNrHTiPhEQcgJs,payload=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,params=wxlSzvIeAMOCFGqWaNrHTiPhEQcgBn,headers=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt,cookies=wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm=json.loads(wxlSzvIeAMOCFGqWaNrHTiPhEQcgJy.text)
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgkn=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['playurl']
   if wxlSzvIeAMOCFGqWaNrHTiPhEQcgkn==wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt:return wxlSzvIeAMOCFGqWaNrHTiPhEQcgjt
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgjB=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['awscookie']
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgjV =wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['drm']
   if 'previewmsg' in wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['preview']:streaming_preview=wxlSzvIeAMOCFGqWaNrHTiPhEQcgJm['preview']['previewmsg']
  except wxlSzvIeAMOCFGqWaNrHTiPhEQcgjK as exception:
   wxlSzvIeAMOCFGqWaNrHTiPhEQcgjp(exception)
  wxlSzvIeAMOCFGqWaNrHTiPhEQcgkn=wxlSzvIeAMOCFGqWaNrHTiPhEQcgkn.replace('pooq.co.kr','wavve.com')
  return(wxlSzvIeAMOCFGqWaNrHTiPhEQcgkn,wxlSzvIeAMOCFGqWaNrHTiPhEQcgjB,wxlSzvIeAMOCFGqWaNrHTiPhEQcgjV,streaming_preview) 
# Created by pyminifier (https://github.com/liftoff/pyminifier)
