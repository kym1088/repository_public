__author__="NightRain"
dyiwPESNaBAtGzDOrCqxQUjluXJKVF=object
dyiwPESNaBAtGzDOrCqxQUjluXJKVs=None
dyiwPESNaBAtGzDOrCqxQUjluXJKVR=True
dyiwPESNaBAtGzDOrCqxQUjluXJKVk=False
dyiwPESNaBAtGzDOrCqxQUjluXJKIb=int
dyiwPESNaBAtGzDOrCqxQUjluXJKIL=type
dyiwPESNaBAtGzDOrCqxQUjluXJKIe=dict
dyiwPESNaBAtGzDOrCqxQUjluXJKIf=len
dyiwPESNaBAtGzDOrCqxQUjluXJKIV=open
dyiwPESNaBAtGzDOrCqxQUjluXJKIM=Exception
dyiwPESNaBAtGzDOrCqxQUjluXJKIv=print
dyiwPESNaBAtGzDOrCqxQUjluXJKIY=str
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
dyiwPESNaBAtGzDOrCqxQUjluXJKbe=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://www.wavve.com/supermultisection/GN51','icon':'home.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&offset=0&limit=20&uicode=VN500','page':'1','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=01&WeekDay=all&uitype=VN4&uiparent=FN0&uirank=0&broadcastid=847243&uicode=VN4','page':'1','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=02&WeekDay=all&uitype=VN3&uiparent=FN0&uirank=0&broadcastid=783664&uicode=VN3','page':'1','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'1','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'paid','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'displaystart','ordernm':'업데이트순','icon':''},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'검색 (웨이브)','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 이력','mode':'TOTAL_HISTORY','icon':'search_history.png'}]
dyiwPESNaBAtGzDOrCqxQUjluXJKbf=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
dyiwPESNaBAtGzDOrCqxQUjluXJKbV=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
dyiwPESNaBAtGzDOrCqxQUjluXJKbI=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
from wavveCore import*
class dyiwPESNaBAtGzDOrCqxQUjluXJKbL(dyiwPESNaBAtGzDOrCqxQUjluXJKVF):
 def __init__(dyiwPESNaBAtGzDOrCqxQUjluXJKbM,dyiwPESNaBAtGzDOrCqxQUjluXJKbv,dyiwPESNaBAtGzDOrCqxQUjluXJKbY,dyiwPESNaBAtGzDOrCqxQUjluXJKbo):
  dyiwPESNaBAtGzDOrCqxQUjluXJKbM._addon_url =dyiwPESNaBAtGzDOrCqxQUjluXJKbv
  dyiwPESNaBAtGzDOrCqxQUjluXJKbM._addon_handle=dyiwPESNaBAtGzDOrCqxQUjluXJKbY
  dyiwPESNaBAtGzDOrCqxQUjluXJKbM.main_params =dyiwPESNaBAtGzDOrCqxQUjluXJKbo
  dyiwPESNaBAtGzDOrCqxQUjluXJKbM.WavveObj =lqSNbLtMmIenORTdxcfUiaCvjsEFuH() 
 def addon_noti(dyiwPESNaBAtGzDOrCqxQUjluXJKbM,sting):
  try:
   dyiwPESNaBAtGzDOrCqxQUjluXJKbc=xbmcgui.Dialog()
   dyiwPESNaBAtGzDOrCqxQUjluXJKbc.notification(__addonname__,sting)
  except:
   dyiwPESNaBAtGzDOrCqxQUjluXJKVs
 def addon_log(dyiwPESNaBAtGzDOrCqxQUjluXJKbM,string):
  try:
   dyiwPESNaBAtGzDOrCqxQUjluXJKbn=string.encode('utf-8','ignore')
  except:
   dyiwPESNaBAtGzDOrCqxQUjluXJKbn='addonException: addon_log'
  dyiwPESNaBAtGzDOrCqxQUjluXJKbh=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,dyiwPESNaBAtGzDOrCqxQUjluXJKbn),level=dyiwPESNaBAtGzDOrCqxQUjluXJKbh)
 def get_keyboard_input(dyiwPESNaBAtGzDOrCqxQUjluXJKbM,dyiwPESNaBAtGzDOrCqxQUjluXJKLI):
  dyiwPESNaBAtGzDOrCqxQUjluXJKbW=dyiwPESNaBAtGzDOrCqxQUjluXJKVs
  kb=xbmc.Keyboard()
  kb.setHeading(dyiwPESNaBAtGzDOrCqxQUjluXJKLI)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   dyiwPESNaBAtGzDOrCqxQUjluXJKbW=kb.getText()
  return dyiwPESNaBAtGzDOrCqxQUjluXJKbW
 def get_settings_login_info(dyiwPESNaBAtGzDOrCqxQUjluXJKbM):
  dyiwPESNaBAtGzDOrCqxQUjluXJKbT =__addon__.getSetting('id')
  dyiwPESNaBAtGzDOrCqxQUjluXJKbm =__addon__.getSetting('pw')
  dyiwPESNaBAtGzDOrCqxQUjluXJKbg=__addon__.getSetting('selected_profile')
  return(dyiwPESNaBAtGzDOrCqxQUjluXJKbT,dyiwPESNaBAtGzDOrCqxQUjluXJKbm,dyiwPESNaBAtGzDOrCqxQUjluXJKbg)
 def get_settings_totalsearch(dyiwPESNaBAtGzDOrCqxQUjluXJKbM):
  dyiwPESNaBAtGzDOrCqxQUjluXJKbp =dyiwPESNaBAtGzDOrCqxQUjluXJKVR if __addon__.getSetting('local_search')=='true' else dyiwPESNaBAtGzDOrCqxQUjluXJKVk
  dyiwPESNaBAtGzDOrCqxQUjluXJKbF =dyiwPESNaBAtGzDOrCqxQUjluXJKVR if __addon__.getSetting('total_search')=='true' else dyiwPESNaBAtGzDOrCqxQUjluXJKVk
  dyiwPESNaBAtGzDOrCqxQUjluXJKbs=dyiwPESNaBAtGzDOrCqxQUjluXJKVR if __addon__.getSetting('total_history')=='true' else dyiwPESNaBAtGzDOrCqxQUjluXJKVk
  return(dyiwPESNaBAtGzDOrCqxQUjluXJKbp,dyiwPESNaBAtGzDOrCqxQUjluXJKbF,dyiwPESNaBAtGzDOrCqxQUjluXJKbs)
 def get_selQuality(dyiwPESNaBAtGzDOrCqxQUjluXJKbM):
  try:
   dyiwPESNaBAtGzDOrCqxQUjluXJKbR=[1080,720,480,360]
   dyiwPESNaBAtGzDOrCqxQUjluXJKbk=dyiwPESNaBAtGzDOrCqxQUjluXJKIb(__addon__.getSetting('selected_quality'))
   return dyiwPESNaBAtGzDOrCqxQUjluXJKbR[dyiwPESNaBAtGzDOrCqxQUjluXJKbk]
  except:
   dyiwPESNaBAtGzDOrCqxQUjluXJKVs
  return 1080 
 def get_settings_exclusion21(dyiwPESNaBAtGzDOrCqxQUjluXJKbM):
  dyiwPESNaBAtGzDOrCqxQUjluXJKLb =__addon__.getSetting('exclusion21')
  if dyiwPESNaBAtGzDOrCqxQUjluXJKLb=='false':
   return dyiwPESNaBAtGzDOrCqxQUjluXJKVk
  else:
   return dyiwPESNaBAtGzDOrCqxQUjluXJKVR
 def get_settings_direct_replay(dyiwPESNaBAtGzDOrCqxQUjluXJKbM):
  dyiwPESNaBAtGzDOrCqxQUjluXJKLe=dyiwPESNaBAtGzDOrCqxQUjluXJKIb(__addon__.getSetting('direct_replay'))
  if dyiwPESNaBAtGzDOrCqxQUjluXJKLe==0:
   return dyiwPESNaBAtGzDOrCqxQUjluXJKVk
  else:
   return dyiwPESNaBAtGzDOrCqxQUjluXJKVR
 def set_winCredential(dyiwPESNaBAtGzDOrCqxQUjluXJKbM,credential):
  dyiwPESNaBAtGzDOrCqxQUjluXJKLf=xbmcgui.Window(10000)
  dyiwPESNaBAtGzDOrCqxQUjluXJKLf.setProperty('WAVVE_M_CREDENTIAL',credential)
  dyiwPESNaBAtGzDOrCqxQUjluXJKLf.setProperty('WAVVE_M_LOGINTIME',dyiwPESNaBAtGzDOrCqxQUjluXJKbM.WavveObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(dyiwPESNaBAtGzDOrCqxQUjluXJKbM):
  dyiwPESNaBAtGzDOrCqxQUjluXJKLf=xbmcgui.Window(10000)
  return dyiwPESNaBAtGzDOrCqxQUjluXJKLf.getProperty('WAVVE_M_CREDENTIAL')
 def set_winEpisodeOrderby(dyiwPESNaBAtGzDOrCqxQUjluXJKbM,dyiwPESNaBAtGzDOrCqxQUjluXJKLk):
  dyiwPESNaBAtGzDOrCqxQUjluXJKLf=xbmcgui.Window(10000)
  dyiwPESNaBAtGzDOrCqxQUjluXJKLf.setProperty('WAVVE_M_ORDERBY',dyiwPESNaBAtGzDOrCqxQUjluXJKLk)
 def get_winEpisodeOrderby(dyiwPESNaBAtGzDOrCqxQUjluXJKbM):
  dyiwPESNaBAtGzDOrCqxQUjluXJKLf=xbmcgui.Window(10000)
  return dyiwPESNaBAtGzDOrCqxQUjluXJKLf.getProperty('WAVVE_M_ORDERBY')
 def add_dir(dyiwPESNaBAtGzDOrCqxQUjluXJKbM,label,sublabel='',img='',infoLabels=dyiwPESNaBAtGzDOrCqxQUjluXJKVs,isFolder=dyiwPESNaBAtGzDOrCqxQUjluXJKVR,params='',isLink=dyiwPESNaBAtGzDOrCqxQUjluXJKVk,ContextMenu=dyiwPESNaBAtGzDOrCqxQUjluXJKVs):
  dyiwPESNaBAtGzDOrCqxQUjluXJKLV='%s?%s'%(dyiwPESNaBAtGzDOrCqxQUjluXJKbM._addon_url,urllib.parse.urlencode(params))
  if sublabel:dyiwPESNaBAtGzDOrCqxQUjluXJKLI='%s < %s >'%(label,sublabel)
  else: dyiwPESNaBAtGzDOrCqxQUjluXJKLI=label
  if not img:img='DefaultFolder.png'
  dyiwPESNaBAtGzDOrCqxQUjluXJKLM=xbmcgui.ListItem(dyiwPESNaBAtGzDOrCqxQUjluXJKLI)
  if dyiwPESNaBAtGzDOrCqxQUjluXJKIL(img)==dyiwPESNaBAtGzDOrCqxQUjluXJKIe:
   dyiwPESNaBAtGzDOrCqxQUjluXJKLM.setArt(img)
  else:
   dyiwPESNaBAtGzDOrCqxQUjluXJKLM.setArt({'thumb':img,'poster':img})
  if infoLabels:dyiwPESNaBAtGzDOrCqxQUjluXJKLM.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   dyiwPESNaBAtGzDOrCqxQUjluXJKLM.setProperty('IsPlayable','true')
  if ContextMenu:dyiwPESNaBAtGzDOrCqxQUjluXJKLM.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(dyiwPESNaBAtGzDOrCqxQUjluXJKbM._addon_handle,dyiwPESNaBAtGzDOrCqxQUjluXJKLV,dyiwPESNaBAtGzDOrCqxQUjluXJKLM,isFolder)
 def dp_Main_List(dyiwPESNaBAtGzDOrCqxQUjluXJKbM):
  (dyiwPESNaBAtGzDOrCqxQUjluXJKbp,dyiwPESNaBAtGzDOrCqxQUjluXJKbF,dyiwPESNaBAtGzDOrCqxQUjluXJKbs)=dyiwPESNaBAtGzDOrCqxQUjluXJKbM.get_settings_totalsearch()
  for dyiwPESNaBAtGzDOrCqxQUjluXJKLv in dyiwPESNaBAtGzDOrCqxQUjluXJKbe:
   dyiwPESNaBAtGzDOrCqxQUjluXJKLI=dyiwPESNaBAtGzDOrCqxQUjluXJKLv.get('title')
   dyiwPESNaBAtGzDOrCqxQUjluXJKLY=''
   if dyiwPESNaBAtGzDOrCqxQUjluXJKLv.get('mode')=='SEARCH_GROUP' and dyiwPESNaBAtGzDOrCqxQUjluXJKbp ==dyiwPESNaBAtGzDOrCqxQUjluXJKVk:continue
   elif dyiwPESNaBAtGzDOrCqxQUjluXJKLv.get('mode')=='TOTAL_SEARCH' and dyiwPESNaBAtGzDOrCqxQUjluXJKbF ==dyiwPESNaBAtGzDOrCqxQUjluXJKVk:continue
   elif dyiwPESNaBAtGzDOrCqxQUjluXJKLv.get('mode')=='TOTAL_HISTORY' and dyiwPESNaBAtGzDOrCqxQUjluXJKbs==dyiwPESNaBAtGzDOrCqxQUjluXJKVk:continue
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo={'mode':dyiwPESNaBAtGzDOrCqxQUjluXJKLv.get('mode'),'sCode':dyiwPESNaBAtGzDOrCqxQUjluXJKLv.get('sCode'),'sIndex':dyiwPESNaBAtGzDOrCqxQUjluXJKLv.get('sIndex'),'sType':dyiwPESNaBAtGzDOrCqxQUjluXJKLv.get('sType'),'suburl':dyiwPESNaBAtGzDOrCqxQUjluXJKLv.get('suburl'),'subapi':dyiwPESNaBAtGzDOrCqxQUjluXJKLv.get('subapi'),'page':dyiwPESNaBAtGzDOrCqxQUjluXJKLv.get('page'),'orderby':dyiwPESNaBAtGzDOrCqxQUjluXJKLv.get('orderby'),'ordernm':dyiwPESNaBAtGzDOrCqxQUjluXJKLv.get('ordernm')}
   if dyiwPESNaBAtGzDOrCqxQUjluXJKLv.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY']:
    dyiwPESNaBAtGzDOrCqxQUjluXJKLH=dyiwPESNaBAtGzDOrCqxQUjluXJKVk
    dyiwPESNaBAtGzDOrCqxQUjluXJKLc =dyiwPESNaBAtGzDOrCqxQUjluXJKVR
   else:
    dyiwPESNaBAtGzDOrCqxQUjluXJKLH=dyiwPESNaBAtGzDOrCqxQUjluXJKVR
    dyiwPESNaBAtGzDOrCqxQUjluXJKLc =dyiwPESNaBAtGzDOrCqxQUjluXJKVk
   if 'icon' in dyiwPESNaBAtGzDOrCqxQUjluXJKLv:dyiwPESNaBAtGzDOrCqxQUjluXJKLY=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',dyiwPESNaBAtGzDOrCqxQUjluXJKLv.get('icon')) 
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.add_dir(dyiwPESNaBAtGzDOrCqxQUjluXJKLI,sublabel='',img=dyiwPESNaBAtGzDOrCqxQUjluXJKLY,infoLabels=dyiwPESNaBAtGzDOrCqxQUjluXJKVs,isFolder=dyiwPESNaBAtGzDOrCqxQUjluXJKLH,params=dyiwPESNaBAtGzDOrCqxQUjluXJKLo,isLink=dyiwPESNaBAtGzDOrCqxQUjluXJKLc)
  if dyiwPESNaBAtGzDOrCqxQUjluXJKIf(dyiwPESNaBAtGzDOrCqxQUjluXJKbe)>0:xbmcplugin.endOfDirectory(dyiwPESNaBAtGzDOrCqxQUjluXJKbM._addon_handle,cacheToDisc=dyiwPESNaBAtGzDOrCqxQUjluXJKVR)
 def dp_Search_Group(dyiwPESNaBAtGzDOrCqxQUjluXJKbM,args):
  for dyiwPESNaBAtGzDOrCqxQUjluXJKLh in dyiwPESNaBAtGzDOrCqxQUjluXJKbf:
   dyiwPESNaBAtGzDOrCqxQUjluXJKLI=dyiwPESNaBAtGzDOrCqxQUjluXJKLh.get('title')
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo={'mode':dyiwPESNaBAtGzDOrCqxQUjluXJKLh.get('mode'),'sType':dyiwPESNaBAtGzDOrCqxQUjluXJKLh.get('sType'),'page':'1'}
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.add_dir(dyiwPESNaBAtGzDOrCqxQUjluXJKLI,sublabel='',img='',infoLabels=dyiwPESNaBAtGzDOrCqxQUjluXJKVs,isFolder=dyiwPESNaBAtGzDOrCqxQUjluXJKVR,params=dyiwPESNaBAtGzDOrCqxQUjluXJKLo)
  if dyiwPESNaBAtGzDOrCqxQUjluXJKIf(dyiwPESNaBAtGzDOrCqxQUjluXJKbf)>0:xbmcplugin.endOfDirectory(dyiwPESNaBAtGzDOrCqxQUjluXJKbM._addon_handle,cacheToDisc=dyiwPESNaBAtGzDOrCqxQUjluXJKVR)
 def dp_Watch_Group(dyiwPESNaBAtGzDOrCqxQUjluXJKbM,args):
  for dyiwPESNaBAtGzDOrCqxQUjluXJKLW in dyiwPESNaBAtGzDOrCqxQUjluXJKbV:
   dyiwPESNaBAtGzDOrCqxQUjluXJKLI=dyiwPESNaBAtGzDOrCqxQUjluXJKLW.get('title')
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo={'mode':dyiwPESNaBAtGzDOrCqxQUjluXJKLW.get('mode'),'sType':dyiwPESNaBAtGzDOrCqxQUjluXJKLW.get('sType')}
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.add_dir(dyiwPESNaBAtGzDOrCqxQUjluXJKLI,sublabel='',img='',infoLabels=dyiwPESNaBAtGzDOrCqxQUjluXJKVs,isFolder=dyiwPESNaBAtGzDOrCqxQUjluXJKVR,params=dyiwPESNaBAtGzDOrCqxQUjluXJKLo)
  if dyiwPESNaBAtGzDOrCqxQUjluXJKIf(dyiwPESNaBAtGzDOrCqxQUjluXJKbV)>0:xbmcplugin.endOfDirectory(dyiwPESNaBAtGzDOrCqxQUjluXJKbM._addon_handle,cacheToDisc=dyiwPESNaBAtGzDOrCqxQUjluXJKVR)
 def login_main(dyiwPESNaBAtGzDOrCqxQUjluXJKbM):
  (dyiwPESNaBAtGzDOrCqxQUjluXJKLT,dyiwPESNaBAtGzDOrCqxQUjluXJKLm,dyiwPESNaBAtGzDOrCqxQUjluXJKLg)=dyiwPESNaBAtGzDOrCqxQUjluXJKbM.get_settings_login_info()
  if not(dyiwPESNaBAtGzDOrCqxQUjluXJKLT and dyiwPESNaBAtGzDOrCqxQUjluXJKLm):
   dyiwPESNaBAtGzDOrCqxQUjluXJKbc=xbmcgui.Dialog()
   dyiwPESNaBAtGzDOrCqxQUjluXJKLp=dyiwPESNaBAtGzDOrCqxQUjluXJKbc.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if dyiwPESNaBAtGzDOrCqxQUjluXJKLp==dyiwPESNaBAtGzDOrCqxQUjluXJKVR:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if dyiwPESNaBAtGzDOrCqxQUjluXJKbM.get_winEpisodeOrderby()=='':
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.set_winEpisodeOrderby('desc')
  if dyiwPESNaBAtGzDOrCqxQUjluXJKbM.cookiefile_check():return
  dyiwPESNaBAtGzDOrCqxQUjluXJKLF =dyiwPESNaBAtGzDOrCqxQUjluXJKIb(dyiwPESNaBAtGzDOrCqxQUjluXJKbM.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  dyiwPESNaBAtGzDOrCqxQUjluXJKLs=xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINTIME')
  if dyiwPESNaBAtGzDOrCqxQUjluXJKLs==dyiwPESNaBAtGzDOrCqxQUjluXJKVs or dyiwPESNaBAtGzDOrCqxQUjluXJKLs=='':
   dyiwPESNaBAtGzDOrCqxQUjluXJKLs=dyiwPESNaBAtGzDOrCqxQUjluXJKIb('19000101')
  else:
   dyiwPESNaBAtGzDOrCqxQUjluXJKLs=dyiwPESNaBAtGzDOrCqxQUjluXJKIb(re.sub('-','',dyiwPESNaBAtGzDOrCqxQUjluXJKLs))
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   dyiwPESNaBAtGzDOrCqxQUjluXJKLR=0
   while dyiwPESNaBAtGzDOrCqxQUjluXJKVR:
    dyiwPESNaBAtGzDOrCqxQUjluXJKLR+=1
    time.sleep(0.05)
    if dyiwPESNaBAtGzDOrCqxQUjluXJKLs>=dyiwPESNaBAtGzDOrCqxQUjluXJKLF:return
    if dyiwPESNaBAtGzDOrCqxQUjluXJKLR>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  if dyiwPESNaBAtGzDOrCqxQUjluXJKLs>=dyiwPESNaBAtGzDOrCqxQUjluXJKLF:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   return
  if not dyiwPESNaBAtGzDOrCqxQUjluXJKbM.WavveObj.GetCredential(dyiwPESNaBAtGzDOrCqxQUjluXJKLT,dyiwPESNaBAtGzDOrCqxQUjluXJKLm,dyiwPESNaBAtGzDOrCqxQUjluXJKLg):
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   sys.exit()
  dyiwPESNaBAtGzDOrCqxQUjluXJKbM.set_winCredential(dyiwPESNaBAtGzDOrCqxQUjluXJKbM.WavveObj.LoadCredential())
  dyiwPESNaBAtGzDOrCqxQUjluXJKbM.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
 def dp_setEpOrderby(dyiwPESNaBAtGzDOrCqxQUjluXJKbM,args):
  dyiwPESNaBAtGzDOrCqxQUjluXJKLk =args.get('orderby')
  dyiwPESNaBAtGzDOrCqxQUjluXJKbM.set_winEpisodeOrderby(dyiwPESNaBAtGzDOrCqxQUjluXJKLk)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(dyiwPESNaBAtGzDOrCqxQUjluXJKbM,args):
  dyiwPESNaBAtGzDOrCqxQUjluXJKbM.WavveObj.SaveCredential(dyiwPESNaBAtGzDOrCqxQUjluXJKbM.get_winCredential())
  dyiwPESNaBAtGzDOrCqxQUjluXJKeb =args.get('mode')
  dyiwPESNaBAtGzDOrCqxQUjluXJKeL =args.get('contentid')
  dyiwPESNaBAtGzDOrCqxQUjluXJKef =args.get('pvrmode')
  dyiwPESNaBAtGzDOrCqxQUjluXJKeV=dyiwPESNaBAtGzDOrCqxQUjluXJKbM.get_selQuality()
  dyiwPESNaBAtGzDOrCqxQUjluXJKbM.addon_log(dyiwPESNaBAtGzDOrCqxQUjluXJKeL+' - '+dyiwPESNaBAtGzDOrCqxQUjluXJKeb)
  dyiwPESNaBAtGzDOrCqxQUjluXJKeI,dyiwPESNaBAtGzDOrCqxQUjluXJKeM,dyiwPESNaBAtGzDOrCqxQUjluXJKev,dyiwPESNaBAtGzDOrCqxQUjluXJKeY=dyiwPESNaBAtGzDOrCqxQUjluXJKbM.WavveObj.GetStreamingURL(dyiwPESNaBAtGzDOrCqxQUjluXJKeb,dyiwPESNaBAtGzDOrCqxQUjluXJKeL,dyiwPESNaBAtGzDOrCqxQUjluXJKeV,dyiwPESNaBAtGzDOrCqxQUjluXJKef)
  dyiwPESNaBAtGzDOrCqxQUjluXJKeo='%s|Cookie=%s'%(dyiwPESNaBAtGzDOrCqxQUjluXJKeI,dyiwPESNaBAtGzDOrCqxQUjluXJKeM)
  dyiwPESNaBAtGzDOrCqxQUjluXJKbM.addon_log(dyiwPESNaBAtGzDOrCqxQUjluXJKeo)
  if dyiwPESNaBAtGzDOrCqxQUjluXJKeI=='':
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.addon_noti(__language__(30907).encode('utf8'))
   return
  dyiwPESNaBAtGzDOrCqxQUjluXJKeH=xbmcgui.ListItem(path=dyiwPESNaBAtGzDOrCqxQUjluXJKeo)
  if dyiwPESNaBAtGzDOrCqxQUjluXJKev:
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.addon_log('!!streaming_drm!!')
   dyiwPESNaBAtGzDOrCqxQUjluXJKec=dyiwPESNaBAtGzDOrCqxQUjluXJKev['customdata']
   dyiwPESNaBAtGzDOrCqxQUjluXJKen =dyiwPESNaBAtGzDOrCqxQUjluXJKev['drmhost']
   dyiwPESNaBAtGzDOrCqxQUjluXJKeh =inputstreamhelper.Helper('mpd',drm='widevine')
   if dyiwPESNaBAtGzDOrCqxQUjluXJKeh.check_inputstream():
    if dyiwPESNaBAtGzDOrCqxQUjluXJKeb=='MOVIE':
     dyiwPESNaBAtGzDOrCqxQUjluXJKeW='https://www.wavve.com/player/movie?movieid=%s'%dyiwPESNaBAtGzDOrCqxQUjluXJKeL
    else:
     dyiwPESNaBAtGzDOrCqxQUjluXJKeW='https://www.wavve.com/player/vod?programid=%s&page=1'%dyiwPESNaBAtGzDOrCqxQUjluXJKeL
    dyiwPESNaBAtGzDOrCqxQUjluXJKeT={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':dyiwPESNaBAtGzDOrCqxQUjluXJKec,'referer':dyiwPESNaBAtGzDOrCqxQUjluXJKeW,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':dyiwPESNaBAtGzDOrCqxQUjluXJKbM.WavveObj.USER_AGENT}
    dyiwPESNaBAtGzDOrCqxQUjluXJKem=dyiwPESNaBAtGzDOrCqxQUjluXJKen+'|'+urllib.parse.urlencode(dyiwPESNaBAtGzDOrCqxQUjluXJKeT)+'|R{SSM}|'
    dyiwPESNaBAtGzDOrCqxQUjluXJKeH.setProperty('inputstream',dyiwPESNaBAtGzDOrCqxQUjluXJKeh.inputstream_addon)
    dyiwPESNaBAtGzDOrCqxQUjluXJKeH.setProperty('inputstream.adaptive.manifest_type','mpd')
    dyiwPESNaBAtGzDOrCqxQUjluXJKeH.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    dyiwPESNaBAtGzDOrCqxQUjluXJKeH.setProperty('inputstream.adaptive.license_key',dyiwPESNaBAtGzDOrCqxQUjluXJKem)
    dyiwPESNaBAtGzDOrCqxQUjluXJKeH.setProperty('inputstream.adaptive.stream_headers','user-agent=%s&Cookie=%s'%(dyiwPESNaBAtGzDOrCqxQUjluXJKbM.WavveObj.USER_AGENT,dyiwPESNaBAtGzDOrCqxQUjluXJKeM))
  xbmcplugin.setResolvedUrl(dyiwPESNaBAtGzDOrCqxQUjluXJKbM._addon_handle,dyiwPESNaBAtGzDOrCqxQUjluXJKVR,dyiwPESNaBAtGzDOrCqxQUjluXJKeH)
  dyiwPESNaBAtGzDOrCqxQUjluXJKeg=dyiwPESNaBAtGzDOrCqxQUjluXJKVk
  if dyiwPESNaBAtGzDOrCqxQUjluXJKeY:
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.addon_noti(dyiwPESNaBAtGzDOrCqxQUjluXJKeY.encode('utf-8'))
   dyiwPESNaBAtGzDOrCqxQUjluXJKeg=dyiwPESNaBAtGzDOrCqxQUjluXJKVR
  else:
   if '/preview.' in urllib.parse.urlsplit(dyiwPESNaBAtGzDOrCqxQUjluXJKeI).path:
    dyiwPESNaBAtGzDOrCqxQUjluXJKbM.addon_noti(__language__(30908).encode('utf8'))
    dyiwPESNaBAtGzDOrCqxQUjluXJKeg=dyiwPESNaBAtGzDOrCqxQUjluXJKVR
  try:
   dyiwPESNaBAtGzDOrCqxQUjluXJKep=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and dyiwPESNaBAtGzDOrCqxQUjluXJKeg==dyiwPESNaBAtGzDOrCqxQUjluXJKVk and dyiwPESNaBAtGzDOrCqxQUjluXJKep!='-':
    dyiwPESNaBAtGzDOrCqxQUjluXJKLo={'code':dyiwPESNaBAtGzDOrCqxQUjluXJKep,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    dyiwPESNaBAtGzDOrCqxQUjluXJKbM.Save_Watched_List(args.get('mode').lower(),dyiwPESNaBAtGzDOrCqxQUjluXJKLo)
  except:
   dyiwPESNaBAtGzDOrCqxQUjluXJKVs
 def Load_Watched_List(dyiwPESNaBAtGzDOrCqxQUjluXJKbM,dyiwPESNaBAtGzDOrCqxQUjluXJKVn):
  try:
   dyiwPESNaBAtGzDOrCqxQUjluXJKeF=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%dyiwPESNaBAtGzDOrCqxQUjluXJKVn))
   fp=dyiwPESNaBAtGzDOrCqxQUjluXJKIV(dyiwPESNaBAtGzDOrCqxQUjluXJKeF,'r',-1,'utf-8')
   dyiwPESNaBAtGzDOrCqxQUjluXJKes=fp.readlines()
   fp.close()
  except:
   dyiwPESNaBAtGzDOrCqxQUjluXJKes=[]
  return dyiwPESNaBAtGzDOrCqxQUjluXJKes
 def Save_Watched_List(dyiwPESNaBAtGzDOrCqxQUjluXJKbM,dyiwPESNaBAtGzDOrCqxQUjluXJKVn,dyiwPESNaBAtGzDOrCqxQUjluXJKbo):
  try:
   dyiwPESNaBAtGzDOrCqxQUjluXJKeF=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%dyiwPESNaBAtGzDOrCqxQUjluXJKVn))
   dyiwPESNaBAtGzDOrCqxQUjluXJKeR=dyiwPESNaBAtGzDOrCqxQUjluXJKbM.Load_Watched_List(dyiwPESNaBAtGzDOrCqxQUjluXJKVn) 
   fp=dyiwPESNaBAtGzDOrCqxQUjluXJKIV(dyiwPESNaBAtGzDOrCqxQUjluXJKeF,'w',-1,'utf-8')
   dyiwPESNaBAtGzDOrCqxQUjluXJKek=urllib.parse.urlencode(dyiwPESNaBAtGzDOrCqxQUjluXJKbo)
   dyiwPESNaBAtGzDOrCqxQUjluXJKek=dyiwPESNaBAtGzDOrCqxQUjluXJKek+'\n'
   fp.write(dyiwPESNaBAtGzDOrCqxQUjluXJKek)
   dyiwPESNaBAtGzDOrCqxQUjluXJKfb=0
   for dyiwPESNaBAtGzDOrCqxQUjluXJKfL in dyiwPESNaBAtGzDOrCqxQUjluXJKeR:
    dyiwPESNaBAtGzDOrCqxQUjluXJKfe=dyiwPESNaBAtGzDOrCqxQUjluXJKIe(urllib.parse.parse_qsl(dyiwPESNaBAtGzDOrCqxQUjluXJKfL))
    dyiwPESNaBAtGzDOrCqxQUjluXJKfV=dyiwPESNaBAtGzDOrCqxQUjluXJKbo.get('code').strip()
    dyiwPESNaBAtGzDOrCqxQUjluXJKfI=dyiwPESNaBAtGzDOrCqxQUjluXJKfe.get('code').strip()
    if dyiwPESNaBAtGzDOrCqxQUjluXJKVn=='vod' and dyiwPESNaBAtGzDOrCqxQUjluXJKbM.get_settings_direct_replay()==dyiwPESNaBAtGzDOrCqxQUjluXJKVR:
     dyiwPESNaBAtGzDOrCqxQUjluXJKfV=dyiwPESNaBAtGzDOrCqxQUjluXJKbo.get('videoid').strip()
     dyiwPESNaBAtGzDOrCqxQUjluXJKfI=dyiwPESNaBAtGzDOrCqxQUjluXJKfe.get('videoid').strip()if dyiwPESNaBAtGzDOrCqxQUjluXJKfI!=dyiwPESNaBAtGzDOrCqxQUjluXJKVs else '-'
    if dyiwPESNaBAtGzDOrCqxQUjluXJKfV!=dyiwPESNaBAtGzDOrCqxQUjluXJKfI:
     fp.write(dyiwPESNaBAtGzDOrCqxQUjluXJKfL)
     dyiwPESNaBAtGzDOrCqxQUjluXJKfb+=1
     if dyiwPESNaBAtGzDOrCqxQUjluXJKfb>=50:break
   fp.close()
  except:
   dyiwPESNaBAtGzDOrCqxQUjluXJKVs
 def Delete_Watched_List(dyiwPESNaBAtGzDOrCqxQUjluXJKbM,dyiwPESNaBAtGzDOrCqxQUjluXJKVn):
  try:
   dyiwPESNaBAtGzDOrCqxQUjluXJKeF=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%dyiwPESNaBAtGzDOrCqxQUjluXJKVn))
   fp=dyiwPESNaBAtGzDOrCqxQUjluXJKIV(dyiwPESNaBAtGzDOrCqxQUjluXJKeF,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   dyiwPESNaBAtGzDOrCqxQUjluXJKVs
 def dp_WatchList_Delete(dyiwPESNaBAtGzDOrCqxQUjluXJKbM,args):
  dyiwPESNaBAtGzDOrCqxQUjluXJKfM=args.get('sType')
  dyiwPESNaBAtGzDOrCqxQUjluXJKbc=xbmcgui.Dialog()
  dyiwPESNaBAtGzDOrCqxQUjluXJKLp=dyiwPESNaBAtGzDOrCqxQUjluXJKbc.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if dyiwPESNaBAtGzDOrCqxQUjluXJKLp==dyiwPESNaBAtGzDOrCqxQUjluXJKVk:sys.exit()
  dyiwPESNaBAtGzDOrCqxQUjluXJKbM.Delete_Watched_List(dyiwPESNaBAtGzDOrCqxQUjluXJKfM)
  xbmc.executebuiltin("Container.Refresh")
 def logout(dyiwPESNaBAtGzDOrCqxQUjluXJKbM):
  dyiwPESNaBAtGzDOrCqxQUjluXJKbc=xbmcgui.Dialog()
  dyiwPESNaBAtGzDOrCqxQUjluXJKLp=dyiwPESNaBAtGzDOrCqxQUjluXJKbc.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if dyiwPESNaBAtGzDOrCqxQUjluXJKLp==dyiwPESNaBAtGzDOrCqxQUjluXJKVk:sys.exit()
  dyiwPESNaBAtGzDOrCqxQUjluXJKbM.wininfo_clear()
  if os.path.isfile(dyiwPESNaBAtGzDOrCqxQUjluXJKbI):os.remove(dyiwPESNaBAtGzDOrCqxQUjluXJKbI)
  dyiwPESNaBAtGzDOrCqxQUjluXJKbM.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(dyiwPESNaBAtGzDOrCqxQUjluXJKbM):
  dyiwPESNaBAtGzDOrCqxQUjluXJKLf=xbmcgui.Window(10000)
  dyiwPESNaBAtGzDOrCqxQUjluXJKLf.setProperty('WAVVE_M_CREDENTIAL','')
  dyiwPESNaBAtGzDOrCqxQUjluXJKLf.setProperty('WAVVE_M_LOGINTIME','')
 def cookiefile_save(dyiwPESNaBAtGzDOrCqxQUjluXJKbM):
  dyiwPESNaBAtGzDOrCqxQUjluXJKfv =dyiwPESNaBAtGzDOrCqxQUjluXJKbM.WavveObj.Get_Now_Datetime()
  dyiwPESNaBAtGzDOrCqxQUjluXJKfY=dyiwPESNaBAtGzDOrCqxQUjluXJKfv+datetime.timedelta(days=dyiwPESNaBAtGzDOrCqxQUjluXJKIb(__addon__.getSetting('cache_ttl')))
  dyiwPESNaBAtGzDOrCqxQUjluXJKLf=xbmcgui.Window(10000)
  dyiwPESNaBAtGzDOrCqxQUjluXJKfo={'wavve_token':dyiwPESNaBAtGzDOrCqxQUjluXJKLf.getProperty('WAVVE_M_CREDENTIAL'),'wavve_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'wavve_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'wavve_profile':__addon__.getSetting('selected_profile'),'wavve_limitdate':dyiwPESNaBAtGzDOrCqxQUjluXJKfY.strftime('%Y-%m-%d')}
  try: 
   fp=dyiwPESNaBAtGzDOrCqxQUjluXJKIV(dyiwPESNaBAtGzDOrCqxQUjluXJKbI,'w',-1,'utf-8')
   json.dump(dyiwPESNaBAtGzDOrCqxQUjluXJKfo,fp)
   fp.close()
  except dyiwPESNaBAtGzDOrCqxQUjluXJKIM as exception:
   dyiwPESNaBAtGzDOrCqxQUjluXJKIv(exception)
 def cookiefile_check(dyiwPESNaBAtGzDOrCqxQUjluXJKbM):
  dyiwPESNaBAtGzDOrCqxQUjluXJKfo={}
  try: 
   fp=dyiwPESNaBAtGzDOrCqxQUjluXJKIV(dyiwPESNaBAtGzDOrCqxQUjluXJKbI,'r',-1,'utf-8')
   dyiwPESNaBAtGzDOrCqxQUjluXJKfo= json.load(fp)
   fp.close()
  except dyiwPESNaBAtGzDOrCqxQUjluXJKIM as exception:
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.wininfo_clear()
   return dyiwPESNaBAtGzDOrCqxQUjluXJKVk
  dyiwPESNaBAtGzDOrCqxQUjluXJKLT =__addon__.getSetting('id')
  dyiwPESNaBAtGzDOrCqxQUjluXJKLm =__addon__.getSetting('pw')
  dyiwPESNaBAtGzDOrCqxQUjluXJKfH =__addon__.getSetting('selected_profile')
  dyiwPESNaBAtGzDOrCqxQUjluXJKfo['wavve_id']=base64.standard_b64decode(dyiwPESNaBAtGzDOrCqxQUjluXJKfo['wavve_id']).decode('utf-8')
  dyiwPESNaBAtGzDOrCqxQUjluXJKfo['wavve_pw']=base64.standard_b64decode(dyiwPESNaBAtGzDOrCqxQUjluXJKfo['wavve_pw']).decode('utf-8')
  if dyiwPESNaBAtGzDOrCqxQUjluXJKLT!=dyiwPESNaBAtGzDOrCqxQUjluXJKfo['wavve_id']or dyiwPESNaBAtGzDOrCqxQUjluXJKLm!=dyiwPESNaBAtGzDOrCqxQUjluXJKfo['wavve_pw']or dyiwPESNaBAtGzDOrCqxQUjluXJKfH!=dyiwPESNaBAtGzDOrCqxQUjluXJKfo['wavve_profile']:
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.wininfo_clear()
   return dyiwPESNaBAtGzDOrCqxQUjluXJKVk
  dyiwPESNaBAtGzDOrCqxQUjluXJKLF =dyiwPESNaBAtGzDOrCqxQUjluXJKIb(dyiwPESNaBAtGzDOrCqxQUjluXJKbM.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  dyiwPESNaBAtGzDOrCqxQUjluXJKfc=dyiwPESNaBAtGzDOrCqxQUjluXJKfo['wavve_limitdate']
  dyiwPESNaBAtGzDOrCqxQUjluXJKLs =dyiwPESNaBAtGzDOrCqxQUjluXJKIb(re.sub('-','',dyiwPESNaBAtGzDOrCqxQUjluXJKfc))
  if dyiwPESNaBAtGzDOrCqxQUjluXJKLs<dyiwPESNaBAtGzDOrCqxQUjluXJKLF:
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.wininfo_clear()
   return dyiwPESNaBAtGzDOrCqxQUjluXJKVk
  dyiwPESNaBAtGzDOrCqxQUjluXJKLf=xbmcgui.Window(10000)
  dyiwPESNaBAtGzDOrCqxQUjluXJKLf.setProperty('WAVVE_M_CREDENTIAL',dyiwPESNaBAtGzDOrCqxQUjluXJKfo['wavve_token'])
  dyiwPESNaBAtGzDOrCqxQUjluXJKLf.setProperty('WAVVE_M_LOGINTIME',dyiwPESNaBAtGzDOrCqxQUjluXJKfc)
  return dyiwPESNaBAtGzDOrCqxQUjluXJKVR
 def dp_LiveCatagory_List(dyiwPESNaBAtGzDOrCqxQUjluXJKbM,args):
  dyiwPESNaBAtGzDOrCqxQUjluXJKbM.WavveObj.SaveCredential(dyiwPESNaBAtGzDOrCqxQUjluXJKbM.get_winCredential())
  dyiwPESNaBAtGzDOrCqxQUjluXJKfn =args.get('sCode')
  dyiwPESNaBAtGzDOrCqxQUjluXJKfh=args.get('sIndex')
  dyiwPESNaBAtGzDOrCqxQUjluXJKfW,dyiwPESNaBAtGzDOrCqxQUjluXJKfT=dyiwPESNaBAtGzDOrCqxQUjluXJKbM.WavveObj.Get_LiveCatagory_List(dyiwPESNaBAtGzDOrCqxQUjluXJKfn,dyiwPESNaBAtGzDOrCqxQUjluXJKfh)
  for dyiwPESNaBAtGzDOrCqxQUjluXJKfm in dyiwPESNaBAtGzDOrCqxQUjluXJKfW:
   dyiwPESNaBAtGzDOrCqxQUjluXJKLI =dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('title')
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo={'mode':'LIVE_LIST','genre':dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('genre'),'baseapi':dyiwPESNaBAtGzDOrCqxQUjluXJKfT}
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.add_dir(dyiwPESNaBAtGzDOrCqxQUjluXJKLI,sublabel='',img='',infoLabels=dyiwPESNaBAtGzDOrCqxQUjluXJKVs,isFolder=dyiwPESNaBAtGzDOrCqxQUjluXJKVR,params=dyiwPESNaBAtGzDOrCqxQUjluXJKLo)
  if dyiwPESNaBAtGzDOrCqxQUjluXJKIf(dyiwPESNaBAtGzDOrCqxQUjluXJKfW)>0:xbmcplugin.endOfDirectory(dyiwPESNaBAtGzDOrCqxQUjluXJKbM._addon_handle,cacheToDisc=dyiwPESNaBAtGzDOrCqxQUjluXJKVk)
 def dp_MainCatagory_List(dyiwPESNaBAtGzDOrCqxQUjluXJKbM,args):
  dyiwPESNaBAtGzDOrCqxQUjluXJKbM.WavveObj.SaveCredential(dyiwPESNaBAtGzDOrCqxQUjluXJKbM.get_winCredential())
  dyiwPESNaBAtGzDOrCqxQUjluXJKfn =args.get('sCode')
  dyiwPESNaBAtGzDOrCqxQUjluXJKfh=args.get('sIndex')
  dyiwPESNaBAtGzDOrCqxQUjluXJKfM =args.get('sType')
  dyiwPESNaBAtGzDOrCqxQUjluXJKfW=dyiwPESNaBAtGzDOrCqxQUjluXJKbM.WavveObj.Get_MainCatagory_List(dyiwPESNaBAtGzDOrCqxQUjluXJKfn,dyiwPESNaBAtGzDOrCqxQUjluXJKfh)
  for dyiwPESNaBAtGzDOrCqxQUjluXJKfm in dyiwPESNaBAtGzDOrCqxQUjluXJKfW:
   if dyiwPESNaBAtGzDOrCqxQUjluXJKfM=='vod':
    if dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('subtype')=='catagory':
     dyiwPESNaBAtGzDOrCqxQUjluXJKeb='PROGRAM_LIST'
    else:
     dyiwPESNaBAtGzDOrCqxQUjluXJKeb='SUPERSECTION_LIST'
   elif dyiwPESNaBAtGzDOrCqxQUjluXJKfM=='movie':
    dyiwPESNaBAtGzDOrCqxQUjluXJKeb='MOVIE_LIST'
   else:
    dyiwPESNaBAtGzDOrCqxQUjluXJKeb=''
   dyiwPESNaBAtGzDOrCqxQUjluXJKLI='%s (%s)'%(dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('title'),args.get('ordernm'))
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo={'mode':dyiwPESNaBAtGzDOrCqxQUjluXJKeb,'suburl':dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('suburl'),'subapi':dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if dyiwPESNaBAtGzDOrCqxQUjluXJKbM.get_settings_exclusion21():
    if dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('title')=='성인' or dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('title')=='성인+':continue
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.add_dir(dyiwPESNaBAtGzDOrCqxQUjluXJKLI,sublabel='',img='',infoLabels=dyiwPESNaBAtGzDOrCqxQUjluXJKVs,isFolder=dyiwPESNaBAtGzDOrCqxQUjluXJKVR,params=dyiwPESNaBAtGzDOrCqxQUjluXJKLo)
  if dyiwPESNaBAtGzDOrCqxQUjluXJKIf(dyiwPESNaBAtGzDOrCqxQUjluXJKfW)>0:xbmcplugin.endOfDirectory(dyiwPESNaBAtGzDOrCqxQUjluXJKbM._addon_handle,cacheToDisc=dyiwPESNaBAtGzDOrCqxQUjluXJKVk)
 def dp_Program_List(dyiwPESNaBAtGzDOrCqxQUjluXJKbM,args):
  dyiwPESNaBAtGzDOrCqxQUjluXJKbM.WavveObj.SaveCredential(dyiwPESNaBAtGzDOrCqxQUjluXJKbM.get_winCredential())
  dyiwPESNaBAtGzDOrCqxQUjluXJKfg =args.get('subapi')
  dyiwPESNaBAtGzDOrCqxQUjluXJKfp=dyiwPESNaBAtGzDOrCqxQUjluXJKIb(args.get('page'))
  dyiwPESNaBAtGzDOrCqxQUjluXJKLk =args.get('orderby')
  dyiwPESNaBAtGzDOrCqxQUjluXJKfW,dyiwPESNaBAtGzDOrCqxQUjluXJKfF=dyiwPESNaBAtGzDOrCqxQUjluXJKbM.WavveObj.Get_Program_List(dyiwPESNaBAtGzDOrCqxQUjluXJKfg,dyiwPESNaBAtGzDOrCqxQUjluXJKfp,dyiwPESNaBAtGzDOrCqxQUjluXJKLk)
  for dyiwPESNaBAtGzDOrCqxQUjluXJKfm in dyiwPESNaBAtGzDOrCqxQUjluXJKfW:
   dyiwPESNaBAtGzDOrCqxQUjluXJKLI =dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('title')
   dyiwPESNaBAtGzDOrCqxQUjluXJKfs=dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('thumbnail')
   dyiwPESNaBAtGzDOrCqxQUjluXJKfR =dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('age')
   if dyiwPESNaBAtGzDOrCqxQUjluXJKfR=='18' or dyiwPESNaBAtGzDOrCqxQUjluXJKfR=='19' or dyiwPESNaBAtGzDOrCqxQUjluXJKfR=='21':dyiwPESNaBAtGzDOrCqxQUjluXJKLI+=' (%s)'%(dyiwPESNaBAtGzDOrCqxQUjluXJKfR)
   dyiwPESNaBAtGzDOrCqxQUjluXJKfk={'plot':dyiwPESNaBAtGzDOrCqxQUjluXJKLI,'mpaa':dyiwPESNaBAtGzDOrCqxQUjluXJKfR,'mediatype':'tvshow'}
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo={'mode':'EPISODE_LIST','videoid':dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('videoid'),'vidtype':dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('vidtype'),'page':'1'}
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.add_dir(dyiwPESNaBAtGzDOrCqxQUjluXJKLI,sublabel='',img=dyiwPESNaBAtGzDOrCqxQUjluXJKfs,infoLabels=dyiwPESNaBAtGzDOrCqxQUjluXJKfk,isFolder=dyiwPESNaBAtGzDOrCqxQUjluXJKVR,params=dyiwPESNaBAtGzDOrCqxQUjluXJKLo)
  if dyiwPESNaBAtGzDOrCqxQUjluXJKfF:
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo={}
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo['mode'] ='PROGRAM_LIST' 
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo['subapi']=dyiwPESNaBAtGzDOrCqxQUjluXJKfg 
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo['page'] =dyiwPESNaBAtGzDOrCqxQUjluXJKIY(dyiwPESNaBAtGzDOrCqxQUjluXJKfp+1)
   dyiwPESNaBAtGzDOrCqxQUjluXJKLI='[B]%s >>[/B]'%'다음 페이지'
   dyiwPESNaBAtGzDOrCqxQUjluXJKVb=dyiwPESNaBAtGzDOrCqxQUjluXJKIY(dyiwPESNaBAtGzDOrCqxQUjluXJKfp+1)
   dyiwPESNaBAtGzDOrCqxQUjluXJKLY=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.add_dir(dyiwPESNaBAtGzDOrCqxQUjluXJKLI,sublabel=dyiwPESNaBAtGzDOrCqxQUjluXJKVb,img=dyiwPESNaBAtGzDOrCqxQUjluXJKLY,infoLabels=dyiwPESNaBAtGzDOrCqxQUjluXJKVs,isFolder=dyiwPESNaBAtGzDOrCqxQUjluXJKVR,params=dyiwPESNaBAtGzDOrCqxQUjluXJKLo)
  if dyiwPESNaBAtGzDOrCqxQUjluXJKIf(dyiwPESNaBAtGzDOrCqxQUjluXJKfW)>0:xbmcplugin.endOfDirectory(dyiwPESNaBAtGzDOrCqxQUjluXJKbM._addon_handle,cacheToDisc=dyiwPESNaBAtGzDOrCqxQUjluXJKVk)
 def dp_SuperSection_List(dyiwPESNaBAtGzDOrCqxQUjluXJKbM,args):
  dyiwPESNaBAtGzDOrCqxQUjluXJKbM.WavveObj.SaveCredential(dyiwPESNaBAtGzDOrCqxQUjluXJKbM.get_winCredential())
  dyiwPESNaBAtGzDOrCqxQUjluXJKVL =args.get('suburl')
  dyiwPESNaBAtGzDOrCqxQUjluXJKfW=dyiwPESNaBAtGzDOrCqxQUjluXJKbM.WavveObj.Get_SuperMultiSection_List(dyiwPESNaBAtGzDOrCqxQUjluXJKVL)
  for dyiwPESNaBAtGzDOrCqxQUjluXJKfm in dyiwPESNaBAtGzDOrCqxQUjluXJKfW:
   dyiwPESNaBAtGzDOrCqxQUjluXJKLI =dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('title')
   dyiwPESNaBAtGzDOrCqxQUjluXJKfg =dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('subapi')
   dyiwPESNaBAtGzDOrCqxQUjluXJKVe=dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('cell_type')
   if dyiwPESNaBAtGzDOrCqxQUjluXJKfg.find('mtype=svod')>=0 or dyiwPESNaBAtGzDOrCqxQUjluXJKfg.find('mtype=ppv')>=0:
    dyiwPESNaBAtGzDOrCqxQUjluXJKeb='MOVIE_LIST'
   elif dyiwPESNaBAtGzDOrCqxQUjluXJKVe=='band_71':
    dyiwPESNaBAtGzDOrCqxQUjluXJKeb ='SUPERSECTION_LIST'
    (dyiwPESNaBAtGzDOrCqxQUjluXJKVf,dyiwPESNaBAtGzDOrCqxQUjluXJKVI)=dyiwPESNaBAtGzDOrCqxQUjluXJKbM.WavveObj.Baseapi_Parse(dyiwPESNaBAtGzDOrCqxQUjluXJKfg)
    dyiwPESNaBAtGzDOrCqxQUjluXJKVL=dyiwPESNaBAtGzDOrCqxQUjluXJKVI.get('api')
    dyiwPESNaBAtGzDOrCqxQUjluXJKfg=''
   elif dyiwPESNaBAtGzDOrCqxQUjluXJKVe=='band_2':
    dyiwPESNaBAtGzDOrCqxQUjluXJKeb='BAND2SECTION_LIST'
   elif dyiwPESNaBAtGzDOrCqxQUjluXJKVe=='band_live':
    dyiwPESNaBAtGzDOrCqxQUjluXJKeb='BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}',dyiwPESNaBAtGzDOrCqxQUjluXJKfg):
    dyiwPESNaBAtGzDOrCqxQUjluXJKeb='MOVIE_LIST'
   else:
    dyiwPESNaBAtGzDOrCqxQUjluXJKeb='PROGRAM_LIST'
   dyiwPESNaBAtGzDOrCqxQUjluXJKfk={'plot':dyiwPESNaBAtGzDOrCqxQUjluXJKLI,'mediatype':'tvshow'}
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo={'mode':dyiwPESNaBAtGzDOrCqxQUjluXJKeb,'suburl':dyiwPESNaBAtGzDOrCqxQUjluXJKVL,'subapi':dyiwPESNaBAtGzDOrCqxQUjluXJKfg,'page':'1'}
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.add_dir(dyiwPESNaBAtGzDOrCqxQUjluXJKLI,sublabel='',img=dyiwPESNaBAtGzDOrCqxQUjluXJKVs,infoLabels=dyiwPESNaBAtGzDOrCqxQUjluXJKfk,isFolder=dyiwPESNaBAtGzDOrCqxQUjluXJKVR,params=dyiwPESNaBAtGzDOrCqxQUjluXJKLo)
  if dyiwPESNaBAtGzDOrCqxQUjluXJKIf(dyiwPESNaBAtGzDOrCqxQUjluXJKfW)>0:xbmcplugin.endOfDirectory(dyiwPESNaBAtGzDOrCqxQUjluXJKbM._addon_handle,cacheToDisc=dyiwPESNaBAtGzDOrCqxQUjluXJKVk)
 def dp_BandLiveSection_List(dyiwPESNaBAtGzDOrCqxQUjluXJKbM,args):
  dyiwPESNaBAtGzDOrCqxQUjluXJKbM.WavveObj.SaveCredential(dyiwPESNaBAtGzDOrCqxQUjluXJKbM.get_winCredential())
  dyiwPESNaBAtGzDOrCqxQUjluXJKfg =args.get('subapi')
  dyiwPESNaBAtGzDOrCqxQUjluXJKfp=dyiwPESNaBAtGzDOrCqxQUjluXJKIb(args.get('page'))
  dyiwPESNaBAtGzDOrCqxQUjluXJKfW,dyiwPESNaBAtGzDOrCqxQUjluXJKfF=dyiwPESNaBAtGzDOrCqxQUjluXJKbM.WavveObj.Get_BandLiveSection_List(dyiwPESNaBAtGzDOrCqxQUjluXJKfg,dyiwPESNaBAtGzDOrCqxQUjluXJKfp)
  for dyiwPESNaBAtGzDOrCqxQUjluXJKfm in dyiwPESNaBAtGzDOrCqxQUjluXJKfW:
   dyiwPESNaBAtGzDOrCqxQUjluXJKVM =dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('channelid')
   dyiwPESNaBAtGzDOrCqxQUjluXJKVv =dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('studio')
   dyiwPESNaBAtGzDOrCqxQUjluXJKVY=dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('tvshowtitle')
   dyiwPESNaBAtGzDOrCqxQUjluXJKfs =dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('thumbnail')
   dyiwPESNaBAtGzDOrCqxQUjluXJKfR =dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('age')
   dyiwPESNaBAtGzDOrCqxQUjluXJKfk={'mediatype':'tvshow','mpaa':dyiwPESNaBAtGzDOrCqxQUjluXJKfR,'title':'%s < %s >'%(dyiwPESNaBAtGzDOrCqxQUjluXJKVv,dyiwPESNaBAtGzDOrCqxQUjluXJKVY),'tvshowtitle':dyiwPESNaBAtGzDOrCqxQUjluXJKVY,'studio':dyiwPESNaBAtGzDOrCqxQUjluXJKVv,'plot':dyiwPESNaBAtGzDOrCqxQUjluXJKVv}
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo={'mode':'LIVE','contentid':dyiwPESNaBAtGzDOrCqxQUjluXJKVM}
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.add_dir(dyiwPESNaBAtGzDOrCqxQUjluXJKVv,sublabel=dyiwPESNaBAtGzDOrCqxQUjluXJKVY,img=dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('thumbnail'),infoLabels=dyiwPESNaBAtGzDOrCqxQUjluXJKfk,isFolder=dyiwPESNaBAtGzDOrCqxQUjluXJKVk,params=dyiwPESNaBAtGzDOrCqxQUjluXJKLo)
  if dyiwPESNaBAtGzDOrCqxQUjluXJKfF:
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo={}
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo['mode'] ='BANDLIVESECTION_LIST' 
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo['subapi']=dyiwPESNaBAtGzDOrCqxQUjluXJKfg
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo['page'] =dyiwPESNaBAtGzDOrCqxQUjluXJKIY(dyiwPESNaBAtGzDOrCqxQUjluXJKfp+1)
   dyiwPESNaBAtGzDOrCqxQUjluXJKLI='[B]%s >>[/B]'%'다음 페이지'
   dyiwPESNaBAtGzDOrCqxQUjluXJKVb=dyiwPESNaBAtGzDOrCqxQUjluXJKIY(dyiwPESNaBAtGzDOrCqxQUjluXJKfp+1)
   dyiwPESNaBAtGzDOrCqxQUjluXJKLY=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.add_dir(dyiwPESNaBAtGzDOrCqxQUjluXJKLI,sublabel=dyiwPESNaBAtGzDOrCqxQUjluXJKVb,img=dyiwPESNaBAtGzDOrCqxQUjluXJKLY,infoLabels=dyiwPESNaBAtGzDOrCqxQUjluXJKVs,isFolder=dyiwPESNaBAtGzDOrCqxQUjluXJKVR,params=dyiwPESNaBAtGzDOrCqxQUjluXJKLo)
  if dyiwPESNaBAtGzDOrCqxQUjluXJKIf(dyiwPESNaBAtGzDOrCqxQUjluXJKfW)>0:xbmcplugin.endOfDirectory(dyiwPESNaBAtGzDOrCqxQUjluXJKbM._addon_handle,cacheToDisc=dyiwPESNaBAtGzDOrCqxQUjluXJKVk)
 def dp_Band2Section_List(dyiwPESNaBAtGzDOrCqxQUjluXJKbM,args):
  dyiwPESNaBAtGzDOrCqxQUjluXJKbM.WavveObj.SaveCredential(dyiwPESNaBAtGzDOrCqxQUjluXJKbM.get_winCredential())
  dyiwPESNaBAtGzDOrCqxQUjluXJKfg =args.get('subapi')
  dyiwPESNaBAtGzDOrCqxQUjluXJKfp=dyiwPESNaBAtGzDOrCqxQUjluXJKIb(args.get('page'))
  dyiwPESNaBAtGzDOrCqxQUjluXJKfW,dyiwPESNaBAtGzDOrCqxQUjluXJKfF=dyiwPESNaBAtGzDOrCqxQUjluXJKbM.WavveObj.Get_Band2Section_List(dyiwPESNaBAtGzDOrCqxQUjluXJKfg,dyiwPESNaBAtGzDOrCqxQUjluXJKfp)
  for dyiwPESNaBAtGzDOrCqxQUjluXJKfm in dyiwPESNaBAtGzDOrCqxQUjluXJKfW:
   dyiwPESNaBAtGzDOrCqxQUjluXJKLI =dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('programtitle')
   dyiwPESNaBAtGzDOrCqxQUjluXJKVb =dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('episodetitle')
   dyiwPESNaBAtGzDOrCqxQUjluXJKfk={'plot':dyiwPESNaBAtGzDOrCqxQUjluXJKLI+'\n\n'+dyiwPESNaBAtGzDOrCqxQUjluXJKVb,'mpaa':dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('age'),'mediatype':'episode'}
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo={'mode':'VOD','programid':'-','contentid':dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('videoid'),'thumbnail':dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('thumbnail'),'title':dyiwPESNaBAtGzDOrCqxQUjluXJKLI,'subtitle':dyiwPESNaBAtGzDOrCqxQUjluXJKVb}
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.add_dir(dyiwPESNaBAtGzDOrCqxQUjluXJKLI,sublabel=dyiwPESNaBAtGzDOrCqxQUjluXJKVb,img=dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('thumbnail'),infoLabels=dyiwPESNaBAtGzDOrCqxQUjluXJKfk,isFolder=dyiwPESNaBAtGzDOrCqxQUjluXJKVk,params=dyiwPESNaBAtGzDOrCqxQUjluXJKLo)
  if dyiwPESNaBAtGzDOrCqxQUjluXJKfF:
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo={}
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo['mode'] ='BAND2SECTION_LIST' 
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo['subapi']=dyiwPESNaBAtGzDOrCqxQUjluXJKfg
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo['page'] =dyiwPESNaBAtGzDOrCqxQUjluXJKIY(dyiwPESNaBAtGzDOrCqxQUjluXJKfp+1)
   dyiwPESNaBAtGzDOrCqxQUjluXJKLI='[B]%s >>[/B]'%'다음 페이지'
   dyiwPESNaBAtGzDOrCqxQUjluXJKVb=dyiwPESNaBAtGzDOrCqxQUjluXJKIY(dyiwPESNaBAtGzDOrCqxQUjluXJKfp+1)
   dyiwPESNaBAtGzDOrCqxQUjluXJKLY=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.add_dir(dyiwPESNaBAtGzDOrCqxQUjluXJKLI,sublabel=dyiwPESNaBAtGzDOrCqxQUjluXJKVb,img=dyiwPESNaBAtGzDOrCqxQUjluXJKLY,infoLabels=dyiwPESNaBAtGzDOrCqxQUjluXJKVs,isFolder=dyiwPESNaBAtGzDOrCqxQUjluXJKVR,params=dyiwPESNaBAtGzDOrCqxQUjluXJKLo)
  if dyiwPESNaBAtGzDOrCqxQUjluXJKIf(dyiwPESNaBAtGzDOrCqxQUjluXJKfW)>0:xbmcplugin.endOfDirectory(dyiwPESNaBAtGzDOrCqxQUjluXJKbM._addon_handle,cacheToDisc=dyiwPESNaBAtGzDOrCqxQUjluXJKVk)
 def dp_Movie_List(dyiwPESNaBAtGzDOrCqxQUjluXJKbM,args):
  dyiwPESNaBAtGzDOrCqxQUjluXJKbM.WavveObj.SaveCredential(dyiwPESNaBAtGzDOrCqxQUjluXJKbM.get_winCredential())
  dyiwPESNaBAtGzDOrCqxQUjluXJKfg =args.get('subapi')
  dyiwPESNaBAtGzDOrCqxQUjluXJKfp=dyiwPESNaBAtGzDOrCqxQUjluXJKIb(args.get('page'))
  dyiwPESNaBAtGzDOrCqxQUjluXJKfW,dyiwPESNaBAtGzDOrCqxQUjluXJKfF=dyiwPESNaBAtGzDOrCqxQUjluXJKbM.WavveObj.Get_Movie_List(dyiwPESNaBAtGzDOrCqxQUjluXJKfg,dyiwPESNaBAtGzDOrCqxQUjluXJKfp)
  for dyiwPESNaBAtGzDOrCqxQUjluXJKfm in dyiwPESNaBAtGzDOrCqxQUjluXJKfW:
   dyiwPESNaBAtGzDOrCqxQUjluXJKLI =dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('title')
   dyiwPESNaBAtGzDOrCqxQUjluXJKfs=dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('thumbnail')
   dyiwPESNaBAtGzDOrCqxQUjluXJKfR =dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('age')
   if dyiwPESNaBAtGzDOrCqxQUjluXJKfR=='18' or dyiwPESNaBAtGzDOrCqxQUjluXJKfR=='19' or dyiwPESNaBAtGzDOrCqxQUjluXJKfR=='21':dyiwPESNaBAtGzDOrCqxQUjluXJKLI+=' (%s)'%(dyiwPESNaBAtGzDOrCqxQUjluXJKfR)
   dyiwPESNaBAtGzDOrCqxQUjluXJKfk={'plot':dyiwPESNaBAtGzDOrCqxQUjluXJKLI,'mpaa':dyiwPESNaBAtGzDOrCqxQUjluXJKfR,'mediatype':'movie'}
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo={'mode':'MOVIE','contentid':dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('videoid'),'title':dyiwPESNaBAtGzDOrCqxQUjluXJKLI,'thumbnail':dyiwPESNaBAtGzDOrCqxQUjluXJKfs,'age':dyiwPESNaBAtGzDOrCqxQUjluXJKfR}
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.add_dir(dyiwPESNaBAtGzDOrCqxQUjluXJKLI,sublabel='',img=dyiwPESNaBAtGzDOrCqxQUjluXJKfs,infoLabels=dyiwPESNaBAtGzDOrCqxQUjluXJKfk,isFolder=dyiwPESNaBAtGzDOrCqxQUjluXJKVk,params=dyiwPESNaBAtGzDOrCqxQUjluXJKLo)
  if dyiwPESNaBAtGzDOrCqxQUjluXJKfF:
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo={}
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo['mode'] ='MOVIE_LIST' 
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo['subapi']=dyiwPESNaBAtGzDOrCqxQUjluXJKfg 
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo['page'] =dyiwPESNaBAtGzDOrCqxQUjluXJKIY(dyiwPESNaBAtGzDOrCqxQUjluXJKfp+1)
   dyiwPESNaBAtGzDOrCqxQUjluXJKLI='[B]%s >>[/B]'%'다음 페이지'
   dyiwPESNaBAtGzDOrCqxQUjluXJKVb=dyiwPESNaBAtGzDOrCqxQUjluXJKIY(dyiwPESNaBAtGzDOrCqxQUjluXJKfp+1)
   dyiwPESNaBAtGzDOrCqxQUjluXJKLY=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.add_dir(dyiwPESNaBAtGzDOrCqxQUjluXJKLI,sublabel=dyiwPESNaBAtGzDOrCqxQUjluXJKVb,img=dyiwPESNaBAtGzDOrCqxQUjluXJKLY,infoLabels=dyiwPESNaBAtGzDOrCqxQUjluXJKVs,isFolder=dyiwPESNaBAtGzDOrCqxQUjluXJKVR,params=dyiwPESNaBAtGzDOrCqxQUjluXJKLo)
  if dyiwPESNaBAtGzDOrCqxQUjluXJKIf(dyiwPESNaBAtGzDOrCqxQUjluXJKfW)>0:xbmcplugin.endOfDirectory(dyiwPESNaBAtGzDOrCqxQUjluXJKbM._addon_handle,cacheToDisc=dyiwPESNaBAtGzDOrCqxQUjluXJKVk)
 def dp_Episode_List(dyiwPESNaBAtGzDOrCqxQUjluXJKbM,args):
  dyiwPESNaBAtGzDOrCqxQUjluXJKbM.WavveObj.SaveCredential(dyiwPESNaBAtGzDOrCqxQUjluXJKbM.get_winCredential())
  dyiwPESNaBAtGzDOrCqxQUjluXJKVo =args.get('videoid')
  dyiwPESNaBAtGzDOrCqxQUjluXJKVH =args.get('vidtype')
  dyiwPESNaBAtGzDOrCqxQUjluXJKfp=dyiwPESNaBAtGzDOrCqxQUjluXJKIb(args.get('page'))
  dyiwPESNaBAtGzDOrCqxQUjluXJKfW,dyiwPESNaBAtGzDOrCqxQUjluXJKfF=dyiwPESNaBAtGzDOrCqxQUjluXJKbM.WavveObj.Get_Episode_List(dyiwPESNaBAtGzDOrCqxQUjluXJKVo,dyiwPESNaBAtGzDOrCqxQUjluXJKVH,dyiwPESNaBAtGzDOrCqxQUjluXJKfp,orderby=dyiwPESNaBAtGzDOrCqxQUjluXJKbM.get_winEpisodeOrderby())
  for dyiwPESNaBAtGzDOrCqxQUjluXJKfm in dyiwPESNaBAtGzDOrCqxQUjluXJKfW:
   dyiwPESNaBAtGzDOrCqxQUjluXJKVb='%s회, %s(%s)'%(dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('episodenumber'),dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('releasedate'),dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('releaseweekday'))
   dyiwPESNaBAtGzDOrCqxQUjluXJKVc ='[%s]\n\n%s'%(dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('episodetitle'),dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('synopsis'))
   dyiwPESNaBAtGzDOrCqxQUjluXJKfk={'mediatype':'episode','title':dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('programtitle'),'year':dyiwPESNaBAtGzDOrCqxQUjluXJKIb(dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('releasedate')[:4]),'aired':dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('releasedate'),'mpaa':dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('age'),'episode':dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('episodenumber'),'duration':dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('playtime'),'plot':dyiwPESNaBAtGzDOrCqxQUjluXJKVc,'cast':dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('episodeactors')}
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo={'mode':'VOD','programid':dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('programid'),'contentid':dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('contentid'),'thumbnail':dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('thumbnail'),'title':dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('programtitle'),'subtitle':dyiwPESNaBAtGzDOrCqxQUjluXJKVb}
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.add_dir(dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('programtitle'),sublabel=dyiwPESNaBAtGzDOrCqxQUjluXJKVb,img=dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('thumbnail'),infoLabels=dyiwPESNaBAtGzDOrCqxQUjluXJKfk,isFolder=dyiwPESNaBAtGzDOrCqxQUjluXJKVk,params=dyiwPESNaBAtGzDOrCqxQUjluXJKLo)
  if dyiwPESNaBAtGzDOrCqxQUjluXJKfp==1:
   dyiwPESNaBAtGzDOrCqxQUjluXJKfk={'plot':'정렬순서를 변경합니다.'}
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo={}
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo['mode'] ='ORDER_BY' 
   if dyiwPESNaBAtGzDOrCqxQUjluXJKbM.get_winEpisodeOrderby()=='desc':
    dyiwPESNaBAtGzDOrCqxQUjluXJKLI='정렬순서변경 : 최신화부터 -> 1회부터'
    dyiwPESNaBAtGzDOrCqxQUjluXJKLo['orderby']='asc'
   else:
    dyiwPESNaBAtGzDOrCqxQUjluXJKLI='정렬순서변경 : 1회부터 -> 최신화부터'
    dyiwPESNaBAtGzDOrCqxQUjluXJKLo['orderby']='desc'
   dyiwPESNaBAtGzDOrCqxQUjluXJKLY=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.add_dir(dyiwPESNaBAtGzDOrCqxQUjluXJKLI,sublabel='',img=dyiwPESNaBAtGzDOrCqxQUjluXJKLY,infoLabels=dyiwPESNaBAtGzDOrCqxQUjluXJKfk,isFolder=dyiwPESNaBAtGzDOrCqxQUjluXJKVk,params=dyiwPESNaBAtGzDOrCqxQUjluXJKLo,isLink=dyiwPESNaBAtGzDOrCqxQUjluXJKVR)
  if dyiwPESNaBAtGzDOrCqxQUjluXJKfF:
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo={}
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo['mode'] ='EPISODE_LIST' 
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo['videoid']=dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('programid')
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo['vidtype']='programid'
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo['page'] =dyiwPESNaBAtGzDOrCqxQUjluXJKIY(dyiwPESNaBAtGzDOrCqxQUjluXJKfp+1)
   dyiwPESNaBAtGzDOrCqxQUjluXJKLI='[B]%s >>[/B]'%'다음 페이지'
   dyiwPESNaBAtGzDOrCqxQUjluXJKVb=dyiwPESNaBAtGzDOrCqxQUjluXJKIY(dyiwPESNaBAtGzDOrCqxQUjluXJKfp+1)
   dyiwPESNaBAtGzDOrCqxQUjluXJKLY=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.add_dir(dyiwPESNaBAtGzDOrCqxQUjluXJKLI,sublabel=dyiwPESNaBAtGzDOrCqxQUjluXJKVb,img=dyiwPESNaBAtGzDOrCqxQUjluXJKLY,infoLabels=dyiwPESNaBAtGzDOrCqxQUjluXJKVs,isFolder=dyiwPESNaBAtGzDOrCqxQUjluXJKVR,params=dyiwPESNaBAtGzDOrCqxQUjluXJKLo)
  if dyiwPESNaBAtGzDOrCqxQUjluXJKIf(dyiwPESNaBAtGzDOrCqxQUjluXJKfW)>0:xbmcplugin.endOfDirectory(dyiwPESNaBAtGzDOrCqxQUjluXJKbM._addon_handle,cacheToDisc=dyiwPESNaBAtGzDOrCqxQUjluXJKVk)
 def dp_LiveChannel_List(dyiwPESNaBAtGzDOrCqxQUjluXJKbM,args):
  dyiwPESNaBAtGzDOrCqxQUjluXJKbM.WavveObj.SaveCredential(dyiwPESNaBAtGzDOrCqxQUjluXJKbM.get_winCredential())
  dyiwPESNaBAtGzDOrCqxQUjluXJKVn =args.get('genre')
  dyiwPESNaBAtGzDOrCqxQUjluXJKfT=args.get('baseapi')
  dyiwPESNaBAtGzDOrCqxQUjluXJKfW=dyiwPESNaBAtGzDOrCqxQUjluXJKbM.WavveObj.Get_LiveChannel_List(dyiwPESNaBAtGzDOrCqxQUjluXJKVn,dyiwPESNaBAtGzDOrCqxQUjluXJKfT)
  for dyiwPESNaBAtGzDOrCqxQUjluXJKfm in dyiwPESNaBAtGzDOrCqxQUjluXJKfW:
   dyiwPESNaBAtGzDOrCqxQUjluXJKVM =dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('channelid')
   dyiwPESNaBAtGzDOrCqxQUjluXJKVv =dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('studio')
   dyiwPESNaBAtGzDOrCqxQUjluXJKVY=dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('tvshowtitle')
   dyiwPESNaBAtGzDOrCqxQUjluXJKfs =dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('thumbnail')
   dyiwPESNaBAtGzDOrCqxQUjluXJKfR =dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('age')
   dyiwPESNaBAtGzDOrCqxQUjluXJKVh =dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('epg')
   dyiwPESNaBAtGzDOrCqxQUjluXJKfk={'mediatype':'episode','mpaa':dyiwPESNaBAtGzDOrCqxQUjluXJKfR,'title':'%s < %s >'%(dyiwPESNaBAtGzDOrCqxQUjluXJKVv,dyiwPESNaBAtGzDOrCqxQUjluXJKVY),'tvshowtitle':dyiwPESNaBAtGzDOrCqxQUjluXJKVY,'studio':dyiwPESNaBAtGzDOrCqxQUjluXJKVv,'plot':'%s\n\n%s'%(dyiwPESNaBAtGzDOrCqxQUjluXJKVv,dyiwPESNaBAtGzDOrCqxQUjluXJKVh)}
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo={'mode':'LIVE','contentid':dyiwPESNaBAtGzDOrCqxQUjluXJKVM}
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.add_dir(dyiwPESNaBAtGzDOrCqxQUjluXJKVv,sublabel=dyiwPESNaBAtGzDOrCqxQUjluXJKVY,img=dyiwPESNaBAtGzDOrCqxQUjluXJKfs,infoLabels=dyiwPESNaBAtGzDOrCqxQUjluXJKfk,isFolder=dyiwPESNaBAtGzDOrCqxQUjluXJKVk,params=dyiwPESNaBAtGzDOrCqxQUjluXJKLo)
  if dyiwPESNaBAtGzDOrCqxQUjluXJKIf(dyiwPESNaBAtGzDOrCqxQUjluXJKfW)>0:xbmcplugin.endOfDirectory(dyiwPESNaBAtGzDOrCqxQUjluXJKbM._addon_handle,cacheToDisc=dyiwPESNaBAtGzDOrCqxQUjluXJKVk)
 def dp_Search_List(dyiwPESNaBAtGzDOrCqxQUjluXJKbM,args):
  dyiwPESNaBAtGzDOrCqxQUjluXJKbM.WavveObj.SaveCredential(dyiwPESNaBAtGzDOrCqxQUjluXJKbM.get_winCredential())
  dyiwPESNaBAtGzDOrCqxQUjluXJKfM =args.get('sType')
  dyiwPESNaBAtGzDOrCqxQUjluXJKfp =dyiwPESNaBAtGzDOrCqxQUjluXJKIb(args.get('page'))
  if 'search_key' in args:
   dyiwPESNaBAtGzDOrCqxQUjluXJKVW=args.get('search_key')
  else:
   dyiwPESNaBAtGzDOrCqxQUjluXJKVW=dyiwPESNaBAtGzDOrCqxQUjluXJKbM.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not dyiwPESNaBAtGzDOrCqxQUjluXJKVW:
    xbmcplugin.endOfDirectory(dyiwPESNaBAtGzDOrCqxQUjluXJKbM._addon_handle)
    return
  dyiwPESNaBAtGzDOrCqxQUjluXJKfW,dyiwPESNaBAtGzDOrCqxQUjluXJKfF=dyiwPESNaBAtGzDOrCqxQUjluXJKbM.WavveObj.Get_Search_List(dyiwPESNaBAtGzDOrCqxQUjluXJKVW,dyiwPESNaBAtGzDOrCqxQUjluXJKfM,dyiwPESNaBAtGzDOrCqxQUjluXJKfp,exclusion21=dyiwPESNaBAtGzDOrCqxQUjluXJKbM.get_settings_exclusion21())
  for dyiwPESNaBAtGzDOrCqxQUjluXJKfm in dyiwPESNaBAtGzDOrCqxQUjluXJKfW:
   dyiwPESNaBAtGzDOrCqxQUjluXJKLI =dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('title')
   dyiwPESNaBAtGzDOrCqxQUjluXJKfs=dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('thumbnail')
   dyiwPESNaBAtGzDOrCqxQUjluXJKfR =dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('age')
   if dyiwPESNaBAtGzDOrCqxQUjluXJKfR=='18' or dyiwPESNaBAtGzDOrCqxQUjluXJKfR=='19' or dyiwPESNaBAtGzDOrCqxQUjluXJKfR=='21':dyiwPESNaBAtGzDOrCqxQUjluXJKLI+=' (%s)'%(dyiwPESNaBAtGzDOrCqxQUjluXJKfR)
   dyiwPESNaBAtGzDOrCqxQUjluXJKfk={'mediatype':'tvshow' if dyiwPESNaBAtGzDOrCqxQUjluXJKfM=='vod' else 'movie','mpaa':dyiwPESNaBAtGzDOrCqxQUjluXJKfR,'title':dyiwPESNaBAtGzDOrCqxQUjluXJKLI,'plot':dyiwPESNaBAtGzDOrCqxQUjluXJKLI}
   if dyiwPESNaBAtGzDOrCqxQUjluXJKfM=='vod':
    dyiwPESNaBAtGzDOrCqxQUjluXJKLo={'mode':'EPISODE_LIST','videoid':dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('videoid'),'vidtype':dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('vidtype'),'page':'1'}
    dyiwPESNaBAtGzDOrCqxQUjluXJKLH=dyiwPESNaBAtGzDOrCqxQUjluXJKVR
   else:
    dyiwPESNaBAtGzDOrCqxQUjluXJKLo={'mode':'MOVIE','contentid':dyiwPESNaBAtGzDOrCqxQUjluXJKfm.get('videoid'),'title':dyiwPESNaBAtGzDOrCqxQUjluXJKLI,'thumbnail':dyiwPESNaBAtGzDOrCqxQUjluXJKfs,'age':dyiwPESNaBAtGzDOrCqxQUjluXJKfR}
    dyiwPESNaBAtGzDOrCqxQUjluXJKLH=dyiwPESNaBAtGzDOrCqxQUjluXJKVk
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.add_dir(dyiwPESNaBAtGzDOrCqxQUjluXJKLI,sublabel='',img=dyiwPESNaBAtGzDOrCqxQUjluXJKfs,infoLabels=dyiwPESNaBAtGzDOrCqxQUjluXJKfk,isFolder=dyiwPESNaBAtGzDOrCqxQUjluXJKLH,params=dyiwPESNaBAtGzDOrCqxQUjluXJKLo)
  if dyiwPESNaBAtGzDOrCqxQUjluXJKfF:
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo['mode'] ='SEARCH_LIST' 
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo['sType']=dyiwPESNaBAtGzDOrCqxQUjluXJKfM 
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo['page'] =dyiwPESNaBAtGzDOrCqxQUjluXJKIY(dyiwPESNaBAtGzDOrCqxQUjluXJKfp+1)
   dyiwPESNaBAtGzDOrCqxQUjluXJKLo['search_key']=dyiwPESNaBAtGzDOrCqxQUjluXJKVW
   dyiwPESNaBAtGzDOrCqxQUjluXJKLI='[B]%s >>[/B]'%'다음 페이지'
   dyiwPESNaBAtGzDOrCqxQUjluXJKVb=dyiwPESNaBAtGzDOrCqxQUjluXJKIY(dyiwPESNaBAtGzDOrCqxQUjluXJKfp+1)
   dyiwPESNaBAtGzDOrCqxQUjluXJKLY=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.add_dir(dyiwPESNaBAtGzDOrCqxQUjluXJKLI,sublabel=dyiwPESNaBAtGzDOrCqxQUjluXJKVb,img=dyiwPESNaBAtGzDOrCqxQUjluXJKLY,infoLabels=dyiwPESNaBAtGzDOrCqxQUjluXJKVs,isFolder=dyiwPESNaBAtGzDOrCqxQUjluXJKVR,params=dyiwPESNaBAtGzDOrCqxQUjluXJKLo)
  xbmcplugin.endOfDirectory(dyiwPESNaBAtGzDOrCqxQUjluXJKbM._addon_handle,cacheToDisc=dyiwPESNaBAtGzDOrCqxQUjluXJKVk)
 def dp_Watch_List(dyiwPESNaBAtGzDOrCqxQUjluXJKbM,args):
  dyiwPESNaBAtGzDOrCqxQUjluXJKfM =args.get('sType')
  dyiwPESNaBAtGzDOrCqxQUjluXJKLe=dyiwPESNaBAtGzDOrCqxQUjluXJKbM.get_settings_direct_replay()
  dyiwPESNaBAtGzDOrCqxQUjluXJKfW=dyiwPESNaBAtGzDOrCqxQUjluXJKbM.Load_Watched_List(dyiwPESNaBAtGzDOrCqxQUjluXJKfM)
  for dyiwPESNaBAtGzDOrCqxQUjluXJKfm in dyiwPESNaBAtGzDOrCqxQUjluXJKfW:
   dyiwPESNaBAtGzDOrCqxQUjluXJKVm=dyiwPESNaBAtGzDOrCqxQUjluXJKIe(urllib.parse.parse_qsl(dyiwPESNaBAtGzDOrCqxQUjluXJKfm))
   dyiwPESNaBAtGzDOrCqxQUjluXJKVg =dyiwPESNaBAtGzDOrCqxQUjluXJKVm.get('code').strip()
   dyiwPESNaBAtGzDOrCqxQUjluXJKLI =dyiwPESNaBAtGzDOrCqxQUjluXJKVm.get('title').strip()
   dyiwPESNaBAtGzDOrCqxQUjluXJKVb =dyiwPESNaBAtGzDOrCqxQUjluXJKVm.get('subtitle').strip()
   if dyiwPESNaBAtGzDOrCqxQUjluXJKVb=='None':dyiwPESNaBAtGzDOrCqxQUjluXJKVb=''
   dyiwPESNaBAtGzDOrCqxQUjluXJKfs=dyiwPESNaBAtGzDOrCqxQUjluXJKVm.get('img').strip()
   dyiwPESNaBAtGzDOrCqxQUjluXJKVo =dyiwPESNaBAtGzDOrCqxQUjluXJKVm.get('videoid').strip()
   try:
    dyiwPESNaBAtGzDOrCqxQUjluXJKfs=dyiwPESNaBAtGzDOrCqxQUjluXJKfs.replace('\'','\"')
    dyiwPESNaBAtGzDOrCqxQUjluXJKfs=json.loads(dyiwPESNaBAtGzDOrCqxQUjluXJKfs)
   except:
    dyiwPESNaBAtGzDOrCqxQUjluXJKVs
   dyiwPESNaBAtGzDOrCqxQUjluXJKfk={'plot':'%s\n%s'%(dyiwPESNaBAtGzDOrCqxQUjluXJKLI,dyiwPESNaBAtGzDOrCqxQUjluXJKVb)}
   if dyiwPESNaBAtGzDOrCqxQUjluXJKfM=='vod':
    if dyiwPESNaBAtGzDOrCqxQUjluXJKLe==dyiwPESNaBAtGzDOrCqxQUjluXJKVk or dyiwPESNaBAtGzDOrCqxQUjluXJKVo==dyiwPESNaBAtGzDOrCqxQUjluXJKVs:
     dyiwPESNaBAtGzDOrCqxQUjluXJKLo={'mode':'EPISODE_LIST','videoid':dyiwPESNaBAtGzDOrCqxQUjluXJKVg,'vidtype':'programid','page':'1'}
     dyiwPESNaBAtGzDOrCqxQUjluXJKLH=dyiwPESNaBAtGzDOrCqxQUjluXJKVR
    else:
     dyiwPESNaBAtGzDOrCqxQUjluXJKLo={'mode':'VOD','programid':dyiwPESNaBAtGzDOrCqxQUjluXJKVg,'contentid':dyiwPESNaBAtGzDOrCqxQUjluXJKVo,'title':dyiwPESNaBAtGzDOrCqxQUjluXJKLI,'subtitle':dyiwPESNaBAtGzDOrCqxQUjluXJKVb,'thumbnail':dyiwPESNaBAtGzDOrCqxQUjluXJKfs}
     dyiwPESNaBAtGzDOrCqxQUjluXJKLH=dyiwPESNaBAtGzDOrCqxQUjluXJKVk
   else:
    dyiwPESNaBAtGzDOrCqxQUjluXJKLo={'mode':'MOVIE','contentid':dyiwPESNaBAtGzDOrCqxQUjluXJKVg,'title':dyiwPESNaBAtGzDOrCqxQUjluXJKLI,'subtitle':dyiwPESNaBAtGzDOrCqxQUjluXJKVb,'thumbnail':dyiwPESNaBAtGzDOrCqxQUjluXJKfs}
    dyiwPESNaBAtGzDOrCqxQUjluXJKLH=dyiwPESNaBAtGzDOrCqxQUjluXJKVk
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.add_dir(dyiwPESNaBAtGzDOrCqxQUjluXJKLI,sublabel=dyiwPESNaBAtGzDOrCqxQUjluXJKVb,img=dyiwPESNaBAtGzDOrCqxQUjluXJKfs,infoLabels=dyiwPESNaBAtGzDOrCqxQUjluXJKfk,isFolder=dyiwPESNaBAtGzDOrCqxQUjluXJKLH,params=dyiwPESNaBAtGzDOrCqxQUjluXJKLo)
  dyiwPESNaBAtGzDOrCqxQUjluXJKfk={'plot':'시청목록을 삭제합니다.'}
  dyiwPESNaBAtGzDOrCqxQUjluXJKLI='*** 시청목록 삭제 ***'
  dyiwPESNaBAtGzDOrCqxQUjluXJKLo={'mode':'MYVIEW_REMOVE','sType':dyiwPESNaBAtGzDOrCqxQUjluXJKfM}
  dyiwPESNaBAtGzDOrCqxQUjluXJKLY=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  dyiwPESNaBAtGzDOrCqxQUjluXJKbM.add_dir(dyiwPESNaBAtGzDOrCqxQUjluXJKLI,sublabel='',img=dyiwPESNaBAtGzDOrCqxQUjluXJKLY,infoLabels=dyiwPESNaBAtGzDOrCqxQUjluXJKfk,isFolder=dyiwPESNaBAtGzDOrCqxQUjluXJKVk,params=dyiwPESNaBAtGzDOrCqxQUjluXJKLo,isLink=dyiwPESNaBAtGzDOrCqxQUjluXJKVR)
  xbmcplugin.endOfDirectory(dyiwPESNaBAtGzDOrCqxQUjluXJKbM._addon_handle,cacheToDisc=dyiwPESNaBAtGzDOrCqxQUjluXJKVk)
 def dp_Global_Search(dyiwPESNaBAtGzDOrCqxQUjluXJKbM,args):
  dyiwPESNaBAtGzDOrCqxQUjluXJKeb=args.get('mode')
  if dyiwPESNaBAtGzDOrCqxQUjluXJKeb=='TOTAL_SEARCH':
   dyiwPESNaBAtGzDOrCqxQUjluXJKVp='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   dyiwPESNaBAtGzDOrCqxQUjluXJKVp='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(dyiwPESNaBAtGzDOrCqxQUjluXJKVp)
 def wavve_main(dyiwPESNaBAtGzDOrCqxQUjluXJKbM):
  dyiwPESNaBAtGzDOrCqxQUjluXJKeb=dyiwPESNaBAtGzDOrCqxQUjluXJKbM.main_params.get('mode',dyiwPESNaBAtGzDOrCqxQUjluXJKVs)
  if dyiwPESNaBAtGzDOrCqxQUjluXJKeb=='LOGOUT':
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.logout()
   return
  dyiwPESNaBAtGzDOrCqxQUjluXJKbM.login_main()
  if dyiwPESNaBAtGzDOrCqxQUjluXJKeb is dyiwPESNaBAtGzDOrCqxQUjluXJKVs:
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.dp_Main_List()
  elif dyiwPESNaBAtGzDOrCqxQUjluXJKeb in['LIVE','VOD','MOVIE']:
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.play_VIDEO(dyiwPESNaBAtGzDOrCqxQUjluXJKbM.main_params)
  elif dyiwPESNaBAtGzDOrCqxQUjluXJKeb=='LIVE_CATAGORY':
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.dp_LiveCatagory_List(dyiwPESNaBAtGzDOrCqxQUjluXJKbM.main_params)
  elif dyiwPESNaBAtGzDOrCqxQUjluXJKeb=='MAIN_CATAGORY':
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.dp_MainCatagory_List(dyiwPESNaBAtGzDOrCqxQUjluXJKbM.main_params)
  elif dyiwPESNaBAtGzDOrCqxQUjluXJKeb=='SUPERSECTION_LIST':
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.dp_SuperSection_List(dyiwPESNaBAtGzDOrCqxQUjluXJKbM.main_params)
  elif dyiwPESNaBAtGzDOrCqxQUjluXJKeb=='BANDLIVESECTION_LIST':
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.dp_BandLiveSection_List(dyiwPESNaBAtGzDOrCqxQUjluXJKbM.main_params)
  elif dyiwPESNaBAtGzDOrCqxQUjluXJKeb=='BAND2SECTION_LIST':
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.dp_Band2Section_List(dyiwPESNaBAtGzDOrCqxQUjluXJKbM.main_params)
  elif dyiwPESNaBAtGzDOrCqxQUjluXJKeb=='PROGRAM_LIST':
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.dp_Program_List(dyiwPESNaBAtGzDOrCqxQUjluXJKbM.main_params)
  elif dyiwPESNaBAtGzDOrCqxQUjluXJKeb=='EPISODE_LIST':
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.dp_Episode_List(dyiwPESNaBAtGzDOrCqxQUjluXJKbM.main_params)
  elif dyiwPESNaBAtGzDOrCqxQUjluXJKeb=='MOVIE_LIST':
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.dp_Movie_List(dyiwPESNaBAtGzDOrCqxQUjluXJKbM.main_params)
  elif dyiwPESNaBAtGzDOrCqxQUjluXJKeb=='LIVE_LIST':
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.dp_LiveChannel_List(dyiwPESNaBAtGzDOrCqxQUjluXJKbM.main_params)
  elif dyiwPESNaBAtGzDOrCqxQUjluXJKeb=='ORDER_BY':
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.dp_setEpOrderby(dyiwPESNaBAtGzDOrCqxQUjluXJKbM.main_params)
  elif dyiwPESNaBAtGzDOrCqxQUjluXJKeb=='SEARCH_GROUP':
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.dp_Search_Group(dyiwPESNaBAtGzDOrCqxQUjluXJKbM.main_params)
  elif dyiwPESNaBAtGzDOrCqxQUjluXJKeb in['SEARCH_LIST','LOCAL_SEARCH']:
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.dp_Search_List(dyiwPESNaBAtGzDOrCqxQUjluXJKbM.main_params)
  elif dyiwPESNaBAtGzDOrCqxQUjluXJKeb=='WATCH_GROUP':
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.dp_Watch_Group(dyiwPESNaBAtGzDOrCqxQUjluXJKbM.main_params)
  elif dyiwPESNaBAtGzDOrCqxQUjluXJKeb=='WATCH_LIST':
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.dp_Watch_List(dyiwPESNaBAtGzDOrCqxQUjluXJKbM.main_params)
  elif dyiwPESNaBAtGzDOrCqxQUjluXJKeb=='MYVIEW_REMOVE':
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.dp_WatchList_Delete(dyiwPESNaBAtGzDOrCqxQUjluXJKbM.main_params)
  elif dyiwPESNaBAtGzDOrCqxQUjluXJKeb in['TOTAL_SEARCH','TOTAL_HISTORY']:
   dyiwPESNaBAtGzDOrCqxQUjluXJKbM.dp_Global_Search(dyiwPESNaBAtGzDOrCqxQUjluXJKbM.main_params)
  else:
   dyiwPESNaBAtGzDOrCqxQUjluXJKVs
# Created by pyminifier (https://github.com/liftoff/pyminifier)
