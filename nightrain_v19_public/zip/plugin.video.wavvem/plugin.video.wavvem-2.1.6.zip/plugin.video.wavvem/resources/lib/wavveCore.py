__author__="NightRain"
lqSNbLtMmIenORTdxcfUiaCvjsEFPG=object
lqSNbLtMmIenORTdxcfUiaCvjsEFPp=None
lqSNbLtMmIenORTdxcfUiaCvjsEFPV=False
lqSNbLtMmIenORTdxcfUiaCvjsEFPW=True
lqSNbLtMmIenORTdxcfUiaCvjsEFPk=range
lqSNbLtMmIenORTdxcfUiaCvjsEFPK=str
lqSNbLtMmIenORTdxcfUiaCvjsEFgu=Exception
lqSNbLtMmIenORTdxcfUiaCvjsEFgH=print
lqSNbLtMmIenORTdxcfUiaCvjsEFgX=dict
lqSNbLtMmIenORTdxcfUiaCvjsEFgP=int
lqSNbLtMmIenORTdxcfUiaCvjsEFgQ=len
import urllib
import re
import json
import sys
import requests
import datetime
class lqSNbLtMmIenORTdxcfUiaCvjsEFuH(lqSNbLtMmIenORTdxcfUiaCvjsEFPG):
 def __init__(lqSNbLtMmIenORTdxcfUiaCvjsEFuX):
  lqSNbLtMmIenORTdxcfUiaCvjsEFuX.API_DOMAIN='https://apis.wavve.com'
  lqSNbLtMmIenORTdxcfUiaCvjsEFuX.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  lqSNbLtMmIenORTdxcfUiaCvjsEFuX.CREDENTIAL='none'
  lqSNbLtMmIenORTdxcfUiaCvjsEFuX.DEVICE ='pc'
  lqSNbLtMmIenORTdxcfUiaCvjsEFuX.DRM ='wm'
  lqSNbLtMmIenORTdxcfUiaCvjsEFuX.PARTNER ='pooq'
  lqSNbLtMmIenORTdxcfUiaCvjsEFuX.POOQZONE ='none'
  lqSNbLtMmIenORTdxcfUiaCvjsEFuX.REGION ='kor'
  lqSNbLtMmIenORTdxcfUiaCvjsEFuX.TARGETAGE ='all'
  lqSNbLtMmIenORTdxcfUiaCvjsEFuX.HTTPTAG ='https://'
  lqSNbLtMmIenORTdxcfUiaCvjsEFuX.LIST_LIMIT=30 
  lqSNbLtMmIenORTdxcfUiaCvjsEFuX.EP_LIMIT =30 
  lqSNbLtMmIenORTdxcfUiaCvjsEFuX.MV_LIMIT =24 
  lqSNbLtMmIenORTdxcfUiaCvjsEFuX.SEARCH_LIMIT=20 
  lqSNbLtMmIenORTdxcfUiaCvjsEFuX.guid ='none' 
  lqSNbLtMmIenORTdxcfUiaCvjsEFuX.guidtimestamp='none' 
  lqSNbLtMmIenORTdxcfUiaCvjsEFuX.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  lqSNbLtMmIenORTdxcfUiaCvjsEFuX.DEFAULT_HEADER={'user-agent':lqSNbLtMmIenORTdxcfUiaCvjsEFuX.USER_AGENT}
 def callRequestCookies(lqSNbLtMmIenORTdxcfUiaCvjsEFuX,jobtype,lqSNbLtMmIenORTdxcfUiaCvjsEFuG,payload=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,params=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,headers=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,cookies=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,redirects=lqSNbLtMmIenORTdxcfUiaCvjsEFPV):
  lqSNbLtMmIenORTdxcfUiaCvjsEFuP=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.DEFAULT_HEADER
  if headers:lqSNbLtMmIenORTdxcfUiaCvjsEFuP.update(headers)
  if jobtype=='Get':
   lqSNbLtMmIenORTdxcfUiaCvjsEFug=requests.get(lqSNbLtMmIenORTdxcfUiaCvjsEFuG,params=params,headers=lqSNbLtMmIenORTdxcfUiaCvjsEFuP,cookies=cookies,allow_redirects=redirects)
  else:
   lqSNbLtMmIenORTdxcfUiaCvjsEFug=requests.post(lqSNbLtMmIenORTdxcfUiaCvjsEFuG,data=payload,params=params,headers=lqSNbLtMmIenORTdxcfUiaCvjsEFuP,cookies=cookies,allow_redirects=redirects)
  return lqSNbLtMmIenORTdxcfUiaCvjsEFug
 def SaveCredential(lqSNbLtMmIenORTdxcfUiaCvjsEFuX,lqSNbLtMmIenORTdxcfUiaCvjsEFuQ):
  lqSNbLtMmIenORTdxcfUiaCvjsEFuX.CREDENTIAL=lqSNbLtMmIenORTdxcfUiaCvjsEFuQ
 def LoadCredential(lqSNbLtMmIenORTdxcfUiaCvjsEFuX):
  return lqSNbLtMmIenORTdxcfUiaCvjsEFuX.CREDENTIAL
 def GetDefaultParams(lqSNbLtMmIenORTdxcfUiaCvjsEFuX,login=lqSNbLtMmIenORTdxcfUiaCvjsEFPW):
  lqSNbLtMmIenORTdxcfUiaCvjsEFuo={'apikey':lqSNbLtMmIenORTdxcfUiaCvjsEFuX.APIKEY,'credential':lqSNbLtMmIenORTdxcfUiaCvjsEFuX.CREDENTIAL if login else 'none','device':lqSNbLtMmIenORTdxcfUiaCvjsEFuX.DEVICE,'drm':lqSNbLtMmIenORTdxcfUiaCvjsEFuX.DRM,'partner':lqSNbLtMmIenORTdxcfUiaCvjsEFuX.PARTNER,'pooqzone':lqSNbLtMmIenORTdxcfUiaCvjsEFuX.POOQZONE,'region':lqSNbLtMmIenORTdxcfUiaCvjsEFuX.REGION,'targetage':lqSNbLtMmIenORTdxcfUiaCvjsEFuX.TARGETAGE}
  return lqSNbLtMmIenORTdxcfUiaCvjsEFuo
 def GetGUID(lqSNbLtMmIenORTdxcfUiaCvjsEFuX,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   lqSNbLtMmIenORTdxcfUiaCvjsEFuJ=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   lqSNbLtMmIenORTdxcfUiaCvjsEFuA=GenerateRandomString(5)
   lqSNbLtMmIenORTdxcfUiaCvjsEFuD=lqSNbLtMmIenORTdxcfUiaCvjsEFuA+media+lqSNbLtMmIenORTdxcfUiaCvjsEFuJ
   return lqSNbLtMmIenORTdxcfUiaCvjsEFuD
  def GenerateRandomString(num):
   from random import randint
   lqSNbLtMmIenORTdxcfUiaCvjsEFuw=""
   for i in lqSNbLtMmIenORTdxcfUiaCvjsEFPk(0,num):
    s=lqSNbLtMmIenORTdxcfUiaCvjsEFPK(randint(1,5))
    lqSNbLtMmIenORTdxcfUiaCvjsEFuw+=s
   return lqSNbLtMmIenORTdxcfUiaCvjsEFuw
  lqSNbLtMmIenORTdxcfUiaCvjsEFuD=GenerateID(guid_str)
  lqSNbLtMmIenORTdxcfUiaCvjsEFur=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.GetHash(lqSNbLtMmIenORTdxcfUiaCvjsEFuD)
  if guidType==2:
   lqSNbLtMmIenORTdxcfUiaCvjsEFur='%s-%s-%s-%s-%s'%(lqSNbLtMmIenORTdxcfUiaCvjsEFur[:8],lqSNbLtMmIenORTdxcfUiaCvjsEFur[8:12],lqSNbLtMmIenORTdxcfUiaCvjsEFur[12:16],lqSNbLtMmIenORTdxcfUiaCvjsEFur[16:20],lqSNbLtMmIenORTdxcfUiaCvjsEFur[20:])
  return lqSNbLtMmIenORTdxcfUiaCvjsEFur
 def GetHash(lqSNbLtMmIenORTdxcfUiaCvjsEFuX,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return lqSNbLtMmIenORTdxcfUiaCvjsEFPK(m.hexdigest())
 def CheckQuality(lqSNbLtMmIenORTdxcfUiaCvjsEFuX,sel_qt,qt_list):
  lqSNbLtMmIenORTdxcfUiaCvjsEFuy=0
  for lqSNbLtMmIenORTdxcfUiaCvjsEFuY in qt_list:
   if sel_qt>=lqSNbLtMmIenORTdxcfUiaCvjsEFuY:return lqSNbLtMmIenORTdxcfUiaCvjsEFuY
   lqSNbLtMmIenORTdxcfUiaCvjsEFuy=lqSNbLtMmIenORTdxcfUiaCvjsEFuY
  return lqSNbLtMmIenORTdxcfUiaCvjsEFuy
 def Get_Now_Datetime(lqSNbLtMmIenORTdxcfUiaCvjsEFuX):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(lqSNbLtMmIenORTdxcfUiaCvjsEFuX,in_text):
  lqSNbLtMmIenORTdxcfUiaCvjsEFuz=in_text.replace('&lt;','<').replace('&gt;','>')
  lqSNbLtMmIenORTdxcfUiaCvjsEFuz=lqSNbLtMmIenORTdxcfUiaCvjsEFuz.replace('$O$','')
  lqSNbLtMmIenORTdxcfUiaCvjsEFuz=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',lqSNbLtMmIenORTdxcfUiaCvjsEFuz)
  lqSNbLtMmIenORTdxcfUiaCvjsEFuz=lqSNbLtMmIenORTdxcfUiaCvjsEFuz.lstrip('#')
  return lqSNbLtMmIenORTdxcfUiaCvjsEFuz
 def GetCredential(lqSNbLtMmIenORTdxcfUiaCvjsEFuX,user_id,user_pw,user_pf):
  lqSNbLtMmIenORTdxcfUiaCvjsEFuh=lqSNbLtMmIenORTdxcfUiaCvjsEFPV
  try:
   lqSNbLtMmIenORTdxcfUiaCvjsEFuG=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.API_DOMAIN+ '/login'
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.GetDefaultParams()
   lqSNbLtMmIenORTdxcfUiaCvjsEFup={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   lqSNbLtMmIenORTdxcfUiaCvjsEFuV=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.callRequestCookies('Post',lqSNbLtMmIenORTdxcfUiaCvjsEFuG,payload=lqSNbLtMmIenORTdxcfUiaCvjsEFup,params=lqSNbLtMmIenORTdxcfUiaCvjsEFuo,headers=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,cookies=lqSNbLtMmIenORTdxcfUiaCvjsEFPp)
   lqSNbLtMmIenORTdxcfUiaCvjsEFuW=json.loads(lqSNbLtMmIenORTdxcfUiaCvjsEFuV.text)
   lqSNbLtMmIenORTdxcfUiaCvjsEFuQ=lqSNbLtMmIenORTdxcfUiaCvjsEFuW['credential']
   if user_pf!=0:
    lqSNbLtMmIenORTdxcfUiaCvjsEFup={'id':lqSNbLtMmIenORTdxcfUiaCvjsEFuQ,'password':'','profile':lqSNbLtMmIenORTdxcfUiaCvjsEFPK(user_pf),'pushid':'','type':'credential'}
    lqSNbLtMmIenORTdxcfUiaCvjsEFuo['credential']=lqSNbLtMmIenORTdxcfUiaCvjsEFuQ 
    lqSNbLtMmIenORTdxcfUiaCvjsEFuV=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.callRequestCookies('Post',lqSNbLtMmIenORTdxcfUiaCvjsEFuG,payload=lqSNbLtMmIenORTdxcfUiaCvjsEFup,params=lqSNbLtMmIenORTdxcfUiaCvjsEFuo,headers=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,cookies=lqSNbLtMmIenORTdxcfUiaCvjsEFPp)
    lqSNbLtMmIenORTdxcfUiaCvjsEFuW=json.loads(lqSNbLtMmIenORTdxcfUiaCvjsEFuV.text)
    lqSNbLtMmIenORTdxcfUiaCvjsEFuQ=lqSNbLtMmIenORTdxcfUiaCvjsEFuW['credential']
   if lqSNbLtMmIenORTdxcfUiaCvjsEFuQ:lqSNbLtMmIenORTdxcfUiaCvjsEFuh=lqSNbLtMmIenORTdxcfUiaCvjsEFPW
  except lqSNbLtMmIenORTdxcfUiaCvjsEFgu as exception:
   lqSNbLtMmIenORTdxcfUiaCvjsEFgH(exception)
   lqSNbLtMmIenORTdxcfUiaCvjsEFuQ='none' 
  lqSNbLtMmIenORTdxcfUiaCvjsEFuX.SaveCredential(lqSNbLtMmIenORTdxcfUiaCvjsEFuQ)
  return lqSNbLtMmIenORTdxcfUiaCvjsEFuh
 def GetIssue(lqSNbLtMmIenORTdxcfUiaCvjsEFuX):
  lqSNbLtMmIenORTdxcfUiaCvjsEFuk=lqSNbLtMmIenORTdxcfUiaCvjsEFPV
  try:
   lqSNbLtMmIenORTdxcfUiaCvjsEFuG=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.API_DOMAIN+'/guid/issue'
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.GetDefaultParams()
   lqSNbLtMmIenORTdxcfUiaCvjsEFuV=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.callRequestCookies('Get',lqSNbLtMmIenORTdxcfUiaCvjsEFuG,payload=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,params=lqSNbLtMmIenORTdxcfUiaCvjsEFuo,headers=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,cookies=lqSNbLtMmIenORTdxcfUiaCvjsEFPp)
   lqSNbLtMmIenORTdxcfUiaCvjsEFuW=json.loads(lqSNbLtMmIenORTdxcfUiaCvjsEFuV.text)
   lqSNbLtMmIenORTdxcfUiaCvjsEFuK=lqSNbLtMmIenORTdxcfUiaCvjsEFuW['guid']
   lqSNbLtMmIenORTdxcfUiaCvjsEFHu=lqSNbLtMmIenORTdxcfUiaCvjsEFuW['guidtimestamp']
   if lqSNbLtMmIenORTdxcfUiaCvjsEFuK:lqSNbLtMmIenORTdxcfUiaCvjsEFuk=lqSNbLtMmIenORTdxcfUiaCvjsEFPW
  except lqSNbLtMmIenORTdxcfUiaCvjsEFgu as exception:
   lqSNbLtMmIenORTdxcfUiaCvjsEFgH(exception)
   lqSNbLtMmIenORTdxcfUiaCvjsEFuK='none'
   lqSNbLtMmIenORTdxcfUiaCvjsEFHu='none' 
  lqSNbLtMmIenORTdxcfUiaCvjsEFuX.guid=lqSNbLtMmIenORTdxcfUiaCvjsEFuK
  lqSNbLtMmIenORTdxcfUiaCvjsEFuX.guidtimestamp=lqSNbLtMmIenORTdxcfUiaCvjsEFHu
  return lqSNbLtMmIenORTdxcfUiaCvjsEFuk
 def Baseapi_Parse(lqSNbLtMmIenORTdxcfUiaCvjsEFuX,lqSNbLtMmIenORTdxcfUiaCvjsEFHQ):
  try:
   lqSNbLtMmIenORTdxcfUiaCvjsEFHX =urllib.parse.urlsplit(lqSNbLtMmIenORTdxcfUiaCvjsEFHQ)
   if lqSNbLtMmIenORTdxcfUiaCvjsEFHX.netloc=='':
    lqSNbLtMmIenORTdxcfUiaCvjsEFuG=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.HTTPTAG+lqSNbLtMmIenORTdxcfUiaCvjsEFHX.netloc+lqSNbLtMmIenORTdxcfUiaCvjsEFHX.path
   else:
    lqSNbLtMmIenORTdxcfUiaCvjsEFuG=lqSNbLtMmIenORTdxcfUiaCvjsEFHX.scheme+'://'+lqSNbLtMmIenORTdxcfUiaCvjsEFHX.netloc+lqSNbLtMmIenORTdxcfUiaCvjsEFHX.path
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo=lqSNbLtMmIenORTdxcfUiaCvjsEFgX(urllib.parse.parse_qsl(lqSNbLtMmIenORTdxcfUiaCvjsEFHX.query))
  except:
   lqSNbLtMmIenORTdxcfUiaCvjsEFgH(exception)
   return '',{}
  return lqSNbLtMmIenORTdxcfUiaCvjsEFuG,lqSNbLtMmIenORTdxcfUiaCvjsEFuo
 def GetSupermultiUrl(lqSNbLtMmIenORTdxcfUiaCvjsEFuX,sCode,sIndex='0'):
  try:
   lqSNbLtMmIenORTdxcfUiaCvjsEFuG=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.API_DOMAIN+'/cf/supermultisections/'+sCode
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.GetDefaultParams(login=lqSNbLtMmIenORTdxcfUiaCvjsEFPV)
   lqSNbLtMmIenORTdxcfUiaCvjsEFuV=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.callRequestCookies('Get',lqSNbLtMmIenORTdxcfUiaCvjsEFuG,payload=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,params=lqSNbLtMmIenORTdxcfUiaCvjsEFuo,headers=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,cookies=lqSNbLtMmIenORTdxcfUiaCvjsEFPp)
   lqSNbLtMmIenORTdxcfUiaCvjsEFuW=json.loads(lqSNbLtMmIenORTdxcfUiaCvjsEFuV.text)
   lqSNbLtMmIenORTdxcfUiaCvjsEFHP=lqSNbLtMmIenORTdxcfUiaCvjsEFuW['multisectionlist'][lqSNbLtMmIenORTdxcfUiaCvjsEFgP(sIndex)]['eventlist'][1]['url']
  except lqSNbLtMmIenORTdxcfUiaCvjsEFgu as exception:
   lqSNbLtMmIenORTdxcfUiaCvjsEFgH(exception)
   return ''
  return lqSNbLtMmIenORTdxcfUiaCvjsEFHP
 def Get_LiveCatagory_List(lqSNbLtMmIenORTdxcfUiaCvjsEFuX,sCode,sIndex='0'):
  lqSNbLtMmIenORTdxcfUiaCvjsEFHg=[]
  lqSNbLtMmIenORTdxcfUiaCvjsEFHQ =lqSNbLtMmIenORTdxcfUiaCvjsEFuX.GetSupermultiUrl(sCode,sIndex)
  (lqSNbLtMmIenORTdxcfUiaCvjsEFuG,lqSNbLtMmIenORTdxcfUiaCvjsEFuo)=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.Baseapi_Parse(lqSNbLtMmIenORTdxcfUiaCvjsEFHQ)
  if lqSNbLtMmIenORTdxcfUiaCvjsEFuG=='':return lqSNbLtMmIenORTdxcfUiaCvjsEFHg,''
  try:
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo.update(lqSNbLtMmIenORTdxcfUiaCvjsEFuX.GetDefaultParams(login=lqSNbLtMmIenORTdxcfUiaCvjsEFPV))
   lqSNbLtMmIenORTdxcfUiaCvjsEFuV=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.callRequestCookies('Get',lqSNbLtMmIenORTdxcfUiaCvjsEFuG,payload=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,params=lqSNbLtMmIenORTdxcfUiaCvjsEFuo,headers=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,cookies=lqSNbLtMmIenORTdxcfUiaCvjsEFPp)
   lqSNbLtMmIenORTdxcfUiaCvjsEFuW=json.loads(lqSNbLtMmIenORTdxcfUiaCvjsEFuV.text)
   if not('filter_item_list' in lqSNbLtMmIenORTdxcfUiaCvjsEFuW['filter']['filterlist'][0]):return[],''
   lqSNbLtMmIenORTdxcfUiaCvjsEFHJ=lqSNbLtMmIenORTdxcfUiaCvjsEFuW['filter']['filterlist'][0]['filter_item_list']
   for lqSNbLtMmIenORTdxcfUiaCvjsEFHA in lqSNbLtMmIenORTdxcfUiaCvjsEFHJ:
    lqSNbLtMmIenORTdxcfUiaCvjsEFHD={'title':lqSNbLtMmIenORTdxcfUiaCvjsEFHA['title'],'genre':lqSNbLtMmIenORTdxcfUiaCvjsEFHA['api_parameters'][lqSNbLtMmIenORTdxcfUiaCvjsEFHA['api_parameters'].index('=')+1:]}
    lqSNbLtMmIenORTdxcfUiaCvjsEFHg.append(lqSNbLtMmIenORTdxcfUiaCvjsEFHD)
  except lqSNbLtMmIenORTdxcfUiaCvjsEFgu as exception:
   lqSNbLtMmIenORTdxcfUiaCvjsEFgH(exception)
   return[],''
  return lqSNbLtMmIenORTdxcfUiaCvjsEFHg,lqSNbLtMmIenORTdxcfUiaCvjsEFHQ
 def Get_MainCatagory_List(lqSNbLtMmIenORTdxcfUiaCvjsEFuX,sCode,sIndex='0'):
  lqSNbLtMmIenORTdxcfUiaCvjsEFHg=[]
  lqSNbLtMmIenORTdxcfUiaCvjsEFHQ =lqSNbLtMmIenORTdxcfUiaCvjsEFuX.GetSupermultiUrl(sCode,sIndex)
  (lqSNbLtMmIenORTdxcfUiaCvjsEFuG,lqSNbLtMmIenORTdxcfUiaCvjsEFuo)=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.Baseapi_Parse(lqSNbLtMmIenORTdxcfUiaCvjsEFHQ)
  if lqSNbLtMmIenORTdxcfUiaCvjsEFuG=='':return lqSNbLtMmIenORTdxcfUiaCvjsEFHg
  try:
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo.update(lqSNbLtMmIenORTdxcfUiaCvjsEFuX.GetDefaultParams(login=lqSNbLtMmIenORTdxcfUiaCvjsEFPV))
   lqSNbLtMmIenORTdxcfUiaCvjsEFuV=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.callRequestCookies('Get',lqSNbLtMmIenORTdxcfUiaCvjsEFuG,payload=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,params=lqSNbLtMmIenORTdxcfUiaCvjsEFuo,headers=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,cookies=lqSNbLtMmIenORTdxcfUiaCvjsEFPp)
   lqSNbLtMmIenORTdxcfUiaCvjsEFuW=json.loads(lqSNbLtMmIenORTdxcfUiaCvjsEFuV.text)
   if not('celllist' in lqSNbLtMmIenORTdxcfUiaCvjsEFuW['band']):return[]
   lqSNbLtMmIenORTdxcfUiaCvjsEFHJ=lqSNbLtMmIenORTdxcfUiaCvjsEFuW['band']['celllist']
   for lqSNbLtMmIenORTdxcfUiaCvjsEFHA in lqSNbLtMmIenORTdxcfUiaCvjsEFHJ:
    lqSNbLtMmIenORTdxcfUiaCvjsEFHw =lqSNbLtMmIenORTdxcfUiaCvjsEFHA['event_list'][1]['url']
    (lqSNbLtMmIenORTdxcfUiaCvjsEFHr,lqSNbLtMmIenORTdxcfUiaCvjsEFHy)=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.Baseapi_Parse(lqSNbLtMmIenORTdxcfUiaCvjsEFHw)
    lqSNbLtMmIenORTdxcfUiaCvjsEFHD={'title':lqSNbLtMmIenORTdxcfUiaCvjsEFHA['title_list'][0]['text'],'suburl':lqSNbLtMmIenORTdxcfUiaCvjsEFHr,'subapi':lqSNbLtMmIenORTdxcfUiaCvjsEFHy.get('api'),'subtype':'catagory' if lqSNbLtMmIenORTdxcfUiaCvjsEFHy else 'supersection'}
    lqSNbLtMmIenORTdxcfUiaCvjsEFHg.append(lqSNbLtMmIenORTdxcfUiaCvjsEFHD)
  except lqSNbLtMmIenORTdxcfUiaCvjsEFgu as exception:
   lqSNbLtMmIenORTdxcfUiaCvjsEFgH(exception)
   return[]
  return lqSNbLtMmIenORTdxcfUiaCvjsEFHg
 def Get_SuperMultiSection_List(lqSNbLtMmIenORTdxcfUiaCvjsEFuX,subapi_text):
  lqSNbLtMmIenORTdxcfUiaCvjsEFHg=[]
  lqSNbLtMmIenORTdxcfUiaCvjsEFuo={}
  try:
   lqSNbLtMmIenORTdxcfUiaCvjsEFHX =urllib.parse.urlsplit(subapi_text)
   if lqSNbLtMmIenORTdxcfUiaCvjsEFHX.path.find('apis.wavve.com')>=0: 
    lqSNbLtMmIenORTdxcfUiaCvjsEFuG=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.HTTPTAG+lqSNbLtMmIenORTdxcfUiaCvjsEFHX.path 
    lqSNbLtMmIenORTdxcfUiaCvjsEFuo=lqSNbLtMmIenORTdxcfUiaCvjsEFgX(urllib.parse.parse_qsl(lqSNbLtMmIenORTdxcfUiaCvjsEFHX.query))
   else:
    lqSNbLtMmIenORTdxcfUiaCvjsEFuG=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.API_DOMAIN+'/cf'+lqSNbLtMmIenORTdxcfUiaCvjsEFHX.path 
   lqSNbLtMmIenORTdxcfUiaCvjsEFuG=lqSNbLtMmIenORTdxcfUiaCvjsEFuG.replace('supermultisection/','supermultisections/')
  except lqSNbLtMmIenORTdxcfUiaCvjsEFgu as exception:
   lqSNbLtMmIenORTdxcfUiaCvjsEFgH(exception)
   return[]
  try:
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo.update(lqSNbLtMmIenORTdxcfUiaCvjsEFuX.GetDefaultParams(login=lqSNbLtMmIenORTdxcfUiaCvjsEFPV))
   lqSNbLtMmIenORTdxcfUiaCvjsEFuV=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.callRequestCookies('Get',lqSNbLtMmIenORTdxcfUiaCvjsEFuG,payload=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,params=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,headers=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,cookies=lqSNbLtMmIenORTdxcfUiaCvjsEFPp)
   lqSNbLtMmIenORTdxcfUiaCvjsEFuW=json.loads(lqSNbLtMmIenORTdxcfUiaCvjsEFuV.text)
   if not('multisectionlist' in lqSNbLtMmIenORTdxcfUiaCvjsEFuW):return[]
   lqSNbLtMmIenORTdxcfUiaCvjsEFHJ=lqSNbLtMmIenORTdxcfUiaCvjsEFuW['multisectionlist']
   for lqSNbLtMmIenORTdxcfUiaCvjsEFHA in lqSNbLtMmIenORTdxcfUiaCvjsEFHJ:
    lqSNbLtMmIenORTdxcfUiaCvjsEFHY=lqSNbLtMmIenORTdxcfUiaCvjsEFHA['title']
    if lqSNbLtMmIenORTdxcfUiaCvjsEFgQ(lqSNbLtMmIenORTdxcfUiaCvjsEFHY)==0:continue
    if lqSNbLtMmIenORTdxcfUiaCvjsEFHY=='minor':continue
    if re.search(u'베너',lqSNbLtMmIenORTdxcfUiaCvjsEFHY):continue
    if re.search(u'배너',lqSNbLtMmIenORTdxcfUiaCvjsEFHY):continue 
    if lqSNbLtMmIenORTdxcfUiaCvjsEFgQ(lqSNbLtMmIenORTdxcfUiaCvjsEFHA['eventlist'])>=3:
     lqSNbLtMmIenORTdxcfUiaCvjsEFHy =lqSNbLtMmIenORTdxcfUiaCvjsEFHA['eventlist'][2]['url']
    else:
     lqSNbLtMmIenORTdxcfUiaCvjsEFHy =lqSNbLtMmIenORTdxcfUiaCvjsEFHA['eventlist'][1]['url']
    lqSNbLtMmIenORTdxcfUiaCvjsEFHB=lqSNbLtMmIenORTdxcfUiaCvjsEFHA['cell_type']
    if lqSNbLtMmIenORTdxcfUiaCvjsEFHB=='band_2':
     if lqSNbLtMmIenORTdxcfUiaCvjsEFHy.find('channellist=')>=0:
      lqSNbLtMmIenORTdxcfUiaCvjsEFHB='band_live'
    lqSNbLtMmIenORTdxcfUiaCvjsEFHD={'title':lqSNbLtMmIenORTdxcfUiaCvjsEFuX.Get_ChangeText(lqSNbLtMmIenORTdxcfUiaCvjsEFHY),'subapi':lqSNbLtMmIenORTdxcfUiaCvjsEFHy,'cell_type':lqSNbLtMmIenORTdxcfUiaCvjsEFHB}
    lqSNbLtMmIenORTdxcfUiaCvjsEFHg.append(lqSNbLtMmIenORTdxcfUiaCvjsEFHD)
  except lqSNbLtMmIenORTdxcfUiaCvjsEFgu as exception:
   lqSNbLtMmIenORTdxcfUiaCvjsEFgH(exception)
   return[]
  return lqSNbLtMmIenORTdxcfUiaCvjsEFHg
 def Get_BandLiveSection_List(lqSNbLtMmIenORTdxcfUiaCvjsEFuX,lqSNbLtMmIenORTdxcfUiaCvjsEFHQ,page_int=1):
  lqSNbLtMmIenORTdxcfUiaCvjsEFHz=[]
  lqSNbLtMmIenORTdxcfUiaCvjsEFHh=lqSNbLtMmIenORTdxcfUiaCvjsEFHK=1
  lqSNbLtMmIenORTdxcfUiaCvjsEFHG=lqSNbLtMmIenORTdxcfUiaCvjsEFPV
  try:
   (lqSNbLtMmIenORTdxcfUiaCvjsEFuG,lqSNbLtMmIenORTdxcfUiaCvjsEFuo)=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.Baseapi_Parse(lqSNbLtMmIenORTdxcfUiaCvjsEFHQ)
  except lqSNbLtMmIenORTdxcfUiaCvjsEFgu as exception:
   lqSNbLtMmIenORTdxcfUiaCvjsEFgH(exception)
   return[],lqSNbLtMmIenORTdxcfUiaCvjsEFPV
  try:
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo['limit']=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.LIST_LIMIT
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo['offset']=lqSNbLtMmIenORTdxcfUiaCvjsEFPK((page_int-1)*lqSNbLtMmIenORTdxcfUiaCvjsEFuX.LIST_LIMIT)
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo.update(lqSNbLtMmIenORTdxcfUiaCvjsEFuX.GetDefaultParams(login=lqSNbLtMmIenORTdxcfUiaCvjsEFPV))
   lqSNbLtMmIenORTdxcfUiaCvjsEFuV=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.callRequestCookies('Get',lqSNbLtMmIenORTdxcfUiaCvjsEFuG,payload=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,params=lqSNbLtMmIenORTdxcfUiaCvjsEFuo,headers=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,cookies=lqSNbLtMmIenORTdxcfUiaCvjsEFPp)
   lqSNbLtMmIenORTdxcfUiaCvjsEFuW=json.loads(lqSNbLtMmIenORTdxcfUiaCvjsEFuV.text)
   if not('celllist' in lqSNbLtMmIenORTdxcfUiaCvjsEFuW['cell_toplist']):return[],lqSNbLtMmIenORTdxcfUiaCvjsEFPV
   lqSNbLtMmIenORTdxcfUiaCvjsEFHJ=lqSNbLtMmIenORTdxcfUiaCvjsEFuW['cell_toplist']['celllist']
   for lqSNbLtMmIenORTdxcfUiaCvjsEFHA in lqSNbLtMmIenORTdxcfUiaCvjsEFHJ:
    lqSNbLtMmIenORTdxcfUiaCvjsEFHp =lqSNbLtMmIenORTdxcfUiaCvjsEFHA['event_list'][1]['url']
    lqSNbLtMmIenORTdxcfUiaCvjsEFHV=urllib.parse.urlsplit(lqSNbLtMmIenORTdxcfUiaCvjsEFHp).query
    lqSNbLtMmIenORTdxcfUiaCvjsEFHV=lqSNbLtMmIenORTdxcfUiaCvjsEFgX(urllib.parse.parse_qsl(lqSNbLtMmIenORTdxcfUiaCvjsEFHV))
    lqSNbLtMmIenORTdxcfUiaCvjsEFHW='channelid'
    lqSNbLtMmIenORTdxcfUiaCvjsEFHk=lqSNbLtMmIenORTdxcfUiaCvjsEFHV[lqSNbLtMmIenORTdxcfUiaCvjsEFHW]
    lqSNbLtMmIenORTdxcfUiaCvjsEFHD={'studio':lqSNbLtMmIenORTdxcfUiaCvjsEFHA['title_list'][0]['text'],'tvshowtitle':lqSNbLtMmIenORTdxcfUiaCvjsEFuX.Get_ChangeText(lqSNbLtMmIenORTdxcfUiaCvjsEFHA['title_list'][1]['text']),'channelid':lqSNbLtMmIenORTdxcfUiaCvjsEFHk,'age':lqSNbLtMmIenORTdxcfUiaCvjsEFHA.get('age'),'thumbnail':'https://%s'%lqSNbLtMmIenORTdxcfUiaCvjsEFHA.get('thumbnail')}
    lqSNbLtMmIenORTdxcfUiaCvjsEFHz.append(lqSNbLtMmIenORTdxcfUiaCvjsEFHD)
   lqSNbLtMmIenORTdxcfUiaCvjsEFHh=lqSNbLtMmIenORTdxcfUiaCvjsEFgP(lqSNbLtMmIenORTdxcfUiaCvjsEFuW['cell_toplist']['pagecount'])
   if lqSNbLtMmIenORTdxcfUiaCvjsEFuW['cell_toplist']['count']:lqSNbLtMmIenORTdxcfUiaCvjsEFHK =lqSNbLtMmIenORTdxcfUiaCvjsEFgP(lqSNbLtMmIenORTdxcfUiaCvjsEFuW['cell_toplist']['count'])
   else:lqSNbLtMmIenORTdxcfUiaCvjsEFHK=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.LIST_LIMIT*page_int
   lqSNbLtMmIenORTdxcfUiaCvjsEFHG=lqSNbLtMmIenORTdxcfUiaCvjsEFHh>lqSNbLtMmIenORTdxcfUiaCvjsEFHK
  except lqSNbLtMmIenORTdxcfUiaCvjsEFgu as exception:
   lqSNbLtMmIenORTdxcfUiaCvjsEFgH(exception)
   return[],lqSNbLtMmIenORTdxcfUiaCvjsEFPV
  return lqSNbLtMmIenORTdxcfUiaCvjsEFHz,lqSNbLtMmIenORTdxcfUiaCvjsEFHG
 def Get_Band2Section_List(lqSNbLtMmIenORTdxcfUiaCvjsEFuX,lqSNbLtMmIenORTdxcfUiaCvjsEFHQ,page_int=1):
  lqSNbLtMmIenORTdxcfUiaCvjsEFXu=[]
  lqSNbLtMmIenORTdxcfUiaCvjsEFHh=lqSNbLtMmIenORTdxcfUiaCvjsEFHK=1
  lqSNbLtMmIenORTdxcfUiaCvjsEFHG=lqSNbLtMmIenORTdxcfUiaCvjsEFPV
  try:
   (lqSNbLtMmIenORTdxcfUiaCvjsEFuG,lqSNbLtMmIenORTdxcfUiaCvjsEFuo)=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.Baseapi_Parse(lqSNbLtMmIenORTdxcfUiaCvjsEFHQ)
  except lqSNbLtMmIenORTdxcfUiaCvjsEFgu as exception:
   lqSNbLtMmIenORTdxcfUiaCvjsEFgH(exception)
   return[],lqSNbLtMmIenORTdxcfUiaCvjsEFPV
  try:
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo['came'] ='BandView'
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo['limit']=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.LIST_LIMIT
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo['offset']=lqSNbLtMmIenORTdxcfUiaCvjsEFPK((page_int-1)*lqSNbLtMmIenORTdxcfUiaCvjsEFuX.LIST_LIMIT)
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo.update(lqSNbLtMmIenORTdxcfUiaCvjsEFuX.GetDefaultParams(login=lqSNbLtMmIenORTdxcfUiaCvjsEFPV))
   lqSNbLtMmIenORTdxcfUiaCvjsEFuV=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.callRequestCookies('Get',lqSNbLtMmIenORTdxcfUiaCvjsEFuG,payload=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,params=lqSNbLtMmIenORTdxcfUiaCvjsEFuo,headers=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,cookies=lqSNbLtMmIenORTdxcfUiaCvjsEFPp)
   lqSNbLtMmIenORTdxcfUiaCvjsEFuW=json.loads(lqSNbLtMmIenORTdxcfUiaCvjsEFuV.text)
   if not('celllist' in lqSNbLtMmIenORTdxcfUiaCvjsEFuW['cell_toplist']):return[],lqSNbLtMmIenORTdxcfUiaCvjsEFPV
   lqSNbLtMmIenORTdxcfUiaCvjsEFHJ=lqSNbLtMmIenORTdxcfUiaCvjsEFuW['cell_toplist']['celllist']
   for lqSNbLtMmIenORTdxcfUiaCvjsEFHA in lqSNbLtMmIenORTdxcfUiaCvjsEFHJ:
    lqSNbLtMmIenORTdxcfUiaCvjsEFHp =lqSNbLtMmIenORTdxcfUiaCvjsEFHA['event_list'][1]['url']
    lqSNbLtMmIenORTdxcfUiaCvjsEFHV=urllib.parse.urlsplit(lqSNbLtMmIenORTdxcfUiaCvjsEFHp).query
    lqSNbLtMmIenORTdxcfUiaCvjsEFHV=lqSNbLtMmIenORTdxcfUiaCvjsEFgX(urllib.parse.parse_qsl(lqSNbLtMmIenORTdxcfUiaCvjsEFHV))
    lqSNbLtMmIenORTdxcfUiaCvjsEFHW='contentid'
    lqSNbLtMmIenORTdxcfUiaCvjsEFHk=lqSNbLtMmIenORTdxcfUiaCvjsEFHV[lqSNbLtMmIenORTdxcfUiaCvjsEFHW]
    lqSNbLtMmIenORTdxcfUiaCvjsEFHD={'programtitle':lqSNbLtMmIenORTdxcfUiaCvjsEFHA['title_list'][0]['text'],'episodetitle':lqSNbLtMmIenORTdxcfUiaCvjsEFuX.Get_ChangeText(lqSNbLtMmIenORTdxcfUiaCvjsEFHA['title_list'][1]['text']),'age':lqSNbLtMmIenORTdxcfUiaCvjsEFHA.get('age'),'thumbnail':lqSNbLtMmIenORTdxcfUiaCvjsEFuX.HTTPTAG+lqSNbLtMmIenORTdxcfUiaCvjsEFHA.get('thumbnail'),'vidtype':lqSNbLtMmIenORTdxcfUiaCvjsEFHW,'videoid':lqSNbLtMmIenORTdxcfUiaCvjsEFHk}
    lqSNbLtMmIenORTdxcfUiaCvjsEFXu.append(lqSNbLtMmIenORTdxcfUiaCvjsEFHD)
   lqSNbLtMmIenORTdxcfUiaCvjsEFHh=lqSNbLtMmIenORTdxcfUiaCvjsEFgP(lqSNbLtMmIenORTdxcfUiaCvjsEFuW['cell_toplist']['pagecount'])
   if lqSNbLtMmIenORTdxcfUiaCvjsEFuW['cell_toplist']['count']:lqSNbLtMmIenORTdxcfUiaCvjsEFHK =lqSNbLtMmIenORTdxcfUiaCvjsEFgP(lqSNbLtMmIenORTdxcfUiaCvjsEFuW['cell_toplist']['count'])
   else:lqSNbLtMmIenORTdxcfUiaCvjsEFHK=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.LIST_LIMIT*page_int
   lqSNbLtMmIenORTdxcfUiaCvjsEFHG=lqSNbLtMmIenORTdxcfUiaCvjsEFHh>lqSNbLtMmIenORTdxcfUiaCvjsEFHK
  except lqSNbLtMmIenORTdxcfUiaCvjsEFgu as exception:
   lqSNbLtMmIenORTdxcfUiaCvjsEFgH(exception)
   return[],lqSNbLtMmIenORTdxcfUiaCvjsEFPV
  return lqSNbLtMmIenORTdxcfUiaCvjsEFXu,lqSNbLtMmIenORTdxcfUiaCvjsEFHG
 def Get_Program_List(lqSNbLtMmIenORTdxcfUiaCvjsEFuX,lqSNbLtMmIenORTdxcfUiaCvjsEFHQ,page_int=1,orderby='-'):
  lqSNbLtMmIenORTdxcfUiaCvjsEFXH=[]
  lqSNbLtMmIenORTdxcfUiaCvjsEFHh=lqSNbLtMmIenORTdxcfUiaCvjsEFHK=1
  lqSNbLtMmIenORTdxcfUiaCvjsEFHG=lqSNbLtMmIenORTdxcfUiaCvjsEFPV
  (lqSNbLtMmIenORTdxcfUiaCvjsEFuG,lqSNbLtMmIenORTdxcfUiaCvjsEFuo)=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.Baseapi_Parse(lqSNbLtMmIenORTdxcfUiaCvjsEFHQ)
  if lqSNbLtMmIenORTdxcfUiaCvjsEFuG=='':return lqSNbLtMmIenORTdxcfUiaCvjsEFXH,lqSNbLtMmIenORTdxcfUiaCvjsEFHG
  try:
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo['limit'] =lqSNbLtMmIenORTdxcfUiaCvjsEFuX.LIST_LIMIT
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo['offset']=lqSNbLtMmIenORTdxcfUiaCvjsEFPK((page_int-1)*lqSNbLtMmIenORTdxcfUiaCvjsEFuX.LIST_LIMIT)
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo['page'] =lqSNbLtMmIenORTdxcfUiaCvjsEFPK(page_int)
   if lqSNbLtMmIenORTdxcfUiaCvjsEFuo.get('orderby')!='' and lqSNbLtMmIenORTdxcfUiaCvjsEFuo.get('orderby')!='regdatefirst' and orderby!='-':
    lqSNbLtMmIenORTdxcfUiaCvjsEFuo['orderby']=orderby 
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo.update(lqSNbLtMmIenORTdxcfUiaCvjsEFuX.GetDefaultParams(login=lqSNbLtMmIenORTdxcfUiaCvjsEFPV))
   lqSNbLtMmIenORTdxcfUiaCvjsEFuV=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.callRequestCookies('Get',lqSNbLtMmIenORTdxcfUiaCvjsEFuG,payload=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,params=lqSNbLtMmIenORTdxcfUiaCvjsEFuo,headers=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,cookies=lqSNbLtMmIenORTdxcfUiaCvjsEFPp)
   lqSNbLtMmIenORTdxcfUiaCvjsEFuW=json.loads(lqSNbLtMmIenORTdxcfUiaCvjsEFuV.text)
   if lqSNbLtMmIenORTdxcfUiaCvjsEFHQ.find('instantplay')>=0:
    if not('celllist' in lqSNbLtMmIenORTdxcfUiaCvjsEFuW['band']):return lqSNbLtMmIenORTdxcfUiaCvjsEFXH,lqSNbLtMmIenORTdxcfUiaCvjsEFHG
    lqSNbLtMmIenORTdxcfUiaCvjsEFHJ=lqSNbLtMmIenORTdxcfUiaCvjsEFuW['band']['celllist']
   else:
    if not('celllist' in lqSNbLtMmIenORTdxcfUiaCvjsEFuW['cell_toplist']):return lqSNbLtMmIenORTdxcfUiaCvjsEFXH,lqSNbLtMmIenORTdxcfUiaCvjsEFHG
    lqSNbLtMmIenORTdxcfUiaCvjsEFHJ=lqSNbLtMmIenORTdxcfUiaCvjsEFuW['cell_toplist']['celllist']
   for lqSNbLtMmIenORTdxcfUiaCvjsEFHA in lqSNbLtMmIenORTdxcfUiaCvjsEFHJ:
    for lqSNbLtMmIenORTdxcfUiaCvjsEFXP in lqSNbLtMmIenORTdxcfUiaCvjsEFHA['event_list']:
     if lqSNbLtMmIenORTdxcfUiaCvjsEFXP.get('type')=='on-navigation':
      lqSNbLtMmIenORTdxcfUiaCvjsEFHp =lqSNbLtMmIenORTdxcfUiaCvjsEFXP['url']
    lqSNbLtMmIenORTdxcfUiaCvjsEFHV=urllib.parse.urlsplit(lqSNbLtMmIenORTdxcfUiaCvjsEFHp).query
    lqSNbLtMmIenORTdxcfUiaCvjsEFHW=lqSNbLtMmIenORTdxcfUiaCvjsEFHV[0:lqSNbLtMmIenORTdxcfUiaCvjsEFHV.find('=')]
    lqSNbLtMmIenORTdxcfUiaCvjsEFHk=lqSNbLtMmIenORTdxcfUiaCvjsEFHV[lqSNbLtMmIenORTdxcfUiaCvjsEFHV.find('=')+1:]
    lqSNbLtMmIenORTdxcfUiaCvjsEFHD={'title':lqSNbLtMmIenORTdxcfUiaCvjsEFHA['title_list'][0]['text'],'age':lqSNbLtMmIenORTdxcfUiaCvjsEFHA['age'],'thumbnail':'https://%s'%lqSNbLtMmIenORTdxcfUiaCvjsEFHA.get('thumbnail'),'videoid':lqSNbLtMmIenORTdxcfUiaCvjsEFHk,'vidtype':lqSNbLtMmIenORTdxcfUiaCvjsEFHW}
    lqSNbLtMmIenORTdxcfUiaCvjsEFXH.append(lqSNbLtMmIenORTdxcfUiaCvjsEFHD)
   if lqSNbLtMmIenORTdxcfUiaCvjsEFHQ.find('instantplay')<0:
    lqSNbLtMmIenORTdxcfUiaCvjsEFHh=lqSNbLtMmIenORTdxcfUiaCvjsEFgP(lqSNbLtMmIenORTdxcfUiaCvjsEFuW['cell_toplist']['pagecount'])
    if lqSNbLtMmIenORTdxcfUiaCvjsEFuW['cell_toplist']['count']:lqSNbLtMmIenORTdxcfUiaCvjsEFHK =lqSNbLtMmIenORTdxcfUiaCvjsEFgP(lqSNbLtMmIenORTdxcfUiaCvjsEFuW['cell_toplist']['count'])
    else:lqSNbLtMmIenORTdxcfUiaCvjsEFHK=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.LIST_LIMIT*page_int
    lqSNbLtMmIenORTdxcfUiaCvjsEFHG=lqSNbLtMmIenORTdxcfUiaCvjsEFHh>lqSNbLtMmIenORTdxcfUiaCvjsEFHK
  except lqSNbLtMmIenORTdxcfUiaCvjsEFgu as exception:
   lqSNbLtMmIenORTdxcfUiaCvjsEFgH(exception)
   return[],lqSNbLtMmIenORTdxcfUiaCvjsEFPV
  return lqSNbLtMmIenORTdxcfUiaCvjsEFXH,lqSNbLtMmIenORTdxcfUiaCvjsEFHG
 def Get_Movie_List(lqSNbLtMmIenORTdxcfUiaCvjsEFuX,lqSNbLtMmIenORTdxcfUiaCvjsEFHQ,page_int=1):
  lqSNbLtMmIenORTdxcfUiaCvjsEFXg=[]
  lqSNbLtMmIenORTdxcfUiaCvjsEFHh=lqSNbLtMmIenORTdxcfUiaCvjsEFHK=1
  lqSNbLtMmIenORTdxcfUiaCvjsEFHG=lqSNbLtMmIenORTdxcfUiaCvjsEFPV
  (lqSNbLtMmIenORTdxcfUiaCvjsEFuG,lqSNbLtMmIenORTdxcfUiaCvjsEFuo)=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.Baseapi_Parse(lqSNbLtMmIenORTdxcfUiaCvjsEFHQ)
  if lqSNbLtMmIenORTdxcfUiaCvjsEFuG=='':return lqSNbLtMmIenORTdxcfUiaCvjsEFXg,lqSNbLtMmIenORTdxcfUiaCvjsEFHG
  try:
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo['limit']=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.MV_LIMIT
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo['offset']=lqSNbLtMmIenORTdxcfUiaCvjsEFPK((page_int-1)*lqSNbLtMmIenORTdxcfUiaCvjsEFuX.MV_LIMIT)
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo.update(lqSNbLtMmIenORTdxcfUiaCvjsEFuX.GetDefaultParams(login=lqSNbLtMmIenORTdxcfUiaCvjsEFPV))
   lqSNbLtMmIenORTdxcfUiaCvjsEFuV=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.callRequestCookies('Get',lqSNbLtMmIenORTdxcfUiaCvjsEFuG,payload=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,params=lqSNbLtMmIenORTdxcfUiaCvjsEFuo,headers=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,cookies=lqSNbLtMmIenORTdxcfUiaCvjsEFPp)
   lqSNbLtMmIenORTdxcfUiaCvjsEFuW=json.loads(lqSNbLtMmIenORTdxcfUiaCvjsEFuV.text)
   if not('celllist' in lqSNbLtMmIenORTdxcfUiaCvjsEFuW['cell_toplist']):return lqSNbLtMmIenORTdxcfUiaCvjsEFXg,lqSNbLtMmIenORTdxcfUiaCvjsEFHG
   lqSNbLtMmIenORTdxcfUiaCvjsEFHJ=lqSNbLtMmIenORTdxcfUiaCvjsEFuW['cell_toplist']['celllist']
   for lqSNbLtMmIenORTdxcfUiaCvjsEFHA in lqSNbLtMmIenORTdxcfUiaCvjsEFHJ:
    lqSNbLtMmIenORTdxcfUiaCvjsEFHp =lqSNbLtMmIenORTdxcfUiaCvjsEFHA['event_list'][1]['url']
    lqSNbLtMmIenORTdxcfUiaCvjsEFHV=urllib.parse.urlsplit(lqSNbLtMmIenORTdxcfUiaCvjsEFHp).query
    lqSNbLtMmIenORTdxcfUiaCvjsEFHW=lqSNbLtMmIenORTdxcfUiaCvjsEFHV[0:lqSNbLtMmIenORTdxcfUiaCvjsEFHV.find('=')]
    lqSNbLtMmIenORTdxcfUiaCvjsEFHk=lqSNbLtMmIenORTdxcfUiaCvjsEFHV[lqSNbLtMmIenORTdxcfUiaCvjsEFHV.find('=')+1:]
    lqSNbLtMmIenORTdxcfUiaCvjsEFHD={'title':lqSNbLtMmIenORTdxcfUiaCvjsEFHA['title_list'][0]['text'],'age':lqSNbLtMmIenORTdxcfUiaCvjsEFHA['age'],'thumbnail':'https://%s'%lqSNbLtMmIenORTdxcfUiaCvjsEFHA.get('thumbnail'),'videoid':lqSNbLtMmIenORTdxcfUiaCvjsEFHk,'vidtype':lqSNbLtMmIenORTdxcfUiaCvjsEFHW}
    lqSNbLtMmIenORTdxcfUiaCvjsEFXg.append(lqSNbLtMmIenORTdxcfUiaCvjsEFHD)
   lqSNbLtMmIenORTdxcfUiaCvjsEFHh=lqSNbLtMmIenORTdxcfUiaCvjsEFgP(lqSNbLtMmIenORTdxcfUiaCvjsEFuW['cell_toplist']['pagecount'])
   if lqSNbLtMmIenORTdxcfUiaCvjsEFuW['cell_toplist']['count']:lqSNbLtMmIenORTdxcfUiaCvjsEFHK =lqSNbLtMmIenORTdxcfUiaCvjsEFgP(lqSNbLtMmIenORTdxcfUiaCvjsEFuW['cell_toplist']['count'])
   else:lqSNbLtMmIenORTdxcfUiaCvjsEFHK=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.MV_LIMIT*page_int
   lqSNbLtMmIenORTdxcfUiaCvjsEFHG=lqSNbLtMmIenORTdxcfUiaCvjsEFHh>lqSNbLtMmIenORTdxcfUiaCvjsEFHK
  except lqSNbLtMmIenORTdxcfUiaCvjsEFgu as exception:
   lqSNbLtMmIenORTdxcfUiaCvjsEFgH(exception)
   return[],lqSNbLtMmIenORTdxcfUiaCvjsEFPV
  return lqSNbLtMmIenORTdxcfUiaCvjsEFXg,lqSNbLtMmIenORTdxcfUiaCvjsEFHG
 def ProgramidToContentid(lqSNbLtMmIenORTdxcfUiaCvjsEFuX,lqSNbLtMmIenORTdxcfUiaCvjsEFXJ):
  lqSNbLtMmIenORTdxcfUiaCvjsEFXQ=''
  try:
   lqSNbLtMmIenORTdxcfUiaCvjsEFuG =lqSNbLtMmIenORTdxcfUiaCvjsEFuX.API_DOMAIN+'/vod/programs-contentid/'+lqSNbLtMmIenORTdxcfUiaCvjsEFXJ
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.GetDefaultParams(login=lqSNbLtMmIenORTdxcfUiaCvjsEFPV)
   lqSNbLtMmIenORTdxcfUiaCvjsEFuV=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.callRequestCookies('Get',lqSNbLtMmIenORTdxcfUiaCvjsEFuG,payload=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,params=lqSNbLtMmIenORTdxcfUiaCvjsEFuo,headers=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,cookies=lqSNbLtMmIenORTdxcfUiaCvjsEFPp)
   lqSNbLtMmIenORTdxcfUiaCvjsEFXo=json.loads(lqSNbLtMmIenORTdxcfUiaCvjsEFuV.text)
   if not('contentid' in lqSNbLtMmIenORTdxcfUiaCvjsEFXo):return lqSNbLtMmIenORTdxcfUiaCvjsEFXQ 
   lqSNbLtMmIenORTdxcfUiaCvjsEFXQ=lqSNbLtMmIenORTdxcfUiaCvjsEFXo['contentid']
  except lqSNbLtMmIenORTdxcfUiaCvjsEFgu as exception:
   lqSNbLtMmIenORTdxcfUiaCvjsEFgH(exception)
  return lqSNbLtMmIenORTdxcfUiaCvjsEFXQ
 def ContentidToProgramid(lqSNbLtMmIenORTdxcfUiaCvjsEFuX,lqSNbLtMmIenORTdxcfUiaCvjsEFXQ):
  lqSNbLtMmIenORTdxcfUiaCvjsEFXJ=''
  try:
   lqSNbLtMmIenORTdxcfUiaCvjsEFuG =lqSNbLtMmIenORTdxcfUiaCvjsEFuX.API_DOMAIN+'/cf/vod/contents/'+lqSNbLtMmIenORTdxcfUiaCvjsEFXQ
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.GetDefaultParams(login=lqSNbLtMmIenORTdxcfUiaCvjsEFPV)
   lqSNbLtMmIenORTdxcfUiaCvjsEFuV=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.callRequestCookies('Get',lqSNbLtMmIenORTdxcfUiaCvjsEFuG,payload=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,params=lqSNbLtMmIenORTdxcfUiaCvjsEFuo,headers=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,cookies=lqSNbLtMmIenORTdxcfUiaCvjsEFPp)
   lqSNbLtMmIenORTdxcfUiaCvjsEFXo=json.loads(lqSNbLtMmIenORTdxcfUiaCvjsEFuV.text)
   if not('programid' in lqSNbLtMmIenORTdxcfUiaCvjsEFXo):return lqSNbLtMmIenORTdxcfUiaCvjsEFXJ 
   lqSNbLtMmIenORTdxcfUiaCvjsEFXJ=lqSNbLtMmIenORTdxcfUiaCvjsEFXo['programid']
  except lqSNbLtMmIenORTdxcfUiaCvjsEFgu as exception:
   lqSNbLtMmIenORTdxcfUiaCvjsEFgH(exception)
  return lqSNbLtMmIenORTdxcfUiaCvjsEFXJ
 def GetProgramInfo(lqSNbLtMmIenORTdxcfUiaCvjsEFuX,program_code):
  lqSNbLtMmIenORTdxcfUiaCvjsEFXA={}
  try:
   lqSNbLtMmIenORTdxcfUiaCvjsEFuG=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.API_DOMAIN+'/cf/vod/contents/'+program_code
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.GetDefaultParams(login=lqSNbLtMmIenORTdxcfUiaCvjsEFPV)
   lqSNbLtMmIenORTdxcfUiaCvjsEFuV=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.callRequestCookies('Get',lqSNbLtMmIenORTdxcfUiaCvjsEFuG,payload=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,params=lqSNbLtMmIenORTdxcfUiaCvjsEFuo,headers=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,cookies=lqSNbLtMmIenORTdxcfUiaCvjsEFPp)
   lqSNbLtMmIenORTdxcfUiaCvjsEFXo=json.loads(lqSNbLtMmIenORTdxcfUiaCvjsEFuV.text)
   lqSNbLtMmIenORTdxcfUiaCvjsEFgH(lqSNbLtMmIenORTdxcfUiaCvjsEFXo)
   lqSNbLtMmIenORTdxcfUiaCvjsEFXD=img_fanart=lqSNbLtMmIenORTdxcfUiaCvjsEFXw=''
   if lqSNbLtMmIenORTdxcfUiaCvjsEFXo.get('programposterimage')!='':lqSNbLtMmIenORTdxcfUiaCvjsEFXD =lqSNbLtMmIenORTdxcfUiaCvjsEFuX.HTTPTAG+lqSNbLtMmIenORTdxcfUiaCvjsEFXo.get('programposterimage')
   if lqSNbLtMmIenORTdxcfUiaCvjsEFXo.get('programimage') !='':img_fanart =lqSNbLtMmIenORTdxcfUiaCvjsEFuX.HTTPTAG+lqSNbLtMmIenORTdxcfUiaCvjsEFXo.get('programimage')
   if lqSNbLtMmIenORTdxcfUiaCvjsEFXo.get('programcirlceimage')!='':lqSNbLtMmIenORTdxcfUiaCvjsEFXw=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.HTTPTAG+lqSNbLtMmIenORTdxcfUiaCvjsEFXo.get('programcirlceimage')
   if 'poster_default' in lqSNbLtMmIenORTdxcfUiaCvjsEFXD:
    lqSNbLtMmIenORTdxcfUiaCvjsEFXD =img_fanart
    lqSNbLtMmIenORTdxcfUiaCvjsEFXw=''
   lqSNbLtMmIenORTdxcfUiaCvjsEFXA={'imgPoster':lqSNbLtMmIenORTdxcfUiaCvjsEFXD,'imgFanart':img_fanart,'imgClearlogo':lqSNbLtMmIenORTdxcfUiaCvjsEFXw}
  except lqSNbLtMmIenORTdxcfUiaCvjsEFgu as exception:
   lqSNbLtMmIenORTdxcfUiaCvjsEFgH(exception)
  return lqSNbLtMmIenORTdxcfUiaCvjsEFXA
 def Get_Episode_List(lqSNbLtMmIenORTdxcfUiaCvjsEFuX,lqSNbLtMmIenORTdxcfUiaCvjsEFHk,lqSNbLtMmIenORTdxcfUiaCvjsEFHW,page_int=1,orderby='desc'):
  lqSNbLtMmIenORTdxcfUiaCvjsEFXr=[]
  lqSNbLtMmIenORTdxcfUiaCvjsEFHh=lqSNbLtMmIenORTdxcfUiaCvjsEFHK=1
  lqSNbLtMmIenORTdxcfUiaCvjsEFHG=lqSNbLtMmIenORTdxcfUiaCvjsEFPV
  lqSNbLtMmIenORTdxcfUiaCvjsEFXy={}
  if lqSNbLtMmIenORTdxcfUiaCvjsEFHW=='contentid':
   lqSNbLtMmIenORTdxcfUiaCvjsEFXJ=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.ContentidToProgramid(lqSNbLtMmIenORTdxcfUiaCvjsEFHk)
   lqSNbLtMmIenORTdxcfUiaCvjsEFXy=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.GetProgramInfo(lqSNbLtMmIenORTdxcfUiaCvjsEFHk)
  else:
   lqSNbLtMmIenORTdxcfUiaCvjsEFXJ=lqSNbLtMmIenORTdxcfUiaCvjsEFHk
   lqSNbLtMmIenORTdxcfUiaCvjsEFXQ=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.ProgramidToContentid(lqSNbLtMmIenORTdxcfUiaCvjsEFHk)
   if lqSNbLtMmIenORTdxcfUiaCvjsEFXQ!='':lqSNbLtMmIenORTdxcfUiaCvjsEFXy=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.GetProgramInfo(lqSNbLtMmIenORTdxcfUiaCvjsEFXQ)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   lqSNbLtMmIenORTdxcfUiaCvjsEFuG=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.API_DOMAIN+'/vod/programs-contents/'+lqSNbLtMmIenORTdxcfUiaCvjsEFXJ
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo={}
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo['limit'] =lqSNbLtMmIenORTdxcfUiaCvjsEFuX.EP_LIMIT
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo['offset']=lqSNbLtMmIenORTdxcfUiaCvjsEFPK((page_int-1)*lqSNbLtMmIenORTdxcfUiaCvjsEFuX.EP_LIMIT)
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo['orderby']=orderby 
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo.update(lqSNbLtMmIenORTdxcfUiaCvjsEFuX.GetDefaultParams(login=lqSNbLtMmIenORTdxcfUiaCvjsEFPV))
   lqSNbLtMmIenORTdxcfUiaCvjsEFuV=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.callRequestCookies('Get',lqSNbLtMmIenORTdxcfUiaCvjsEFuG,payload=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,params=lqSNbLtMmIenORTdxcfUiaCvjsEFuo,headers=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,cookies=lqSNbLtMmIenORTdxcfUiaCvjsEFPp)
   lqSNbLtMmIenORTdxcfUiaCvjsEFuW=json.loads(lqSNbLtMmIenORTdxcfUiaCvjsEFuV.text)
   lqSNbLtMmIenORTdxcfUiaCvjsEFHJ=lqSNbLtMmIenORTdxcfUiaCvjsEFuW['list']
   for lqSNbLtMmIenORTdxcfUiaCvjsEFHA in lqSNbLtMmIenORTdxcfUiaCvjsEFHJ:
    lqSNbLtMmIenORTdxcfUiaCvjsEFXB=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',lqSNbLtMmIenORTdxcfUiaCvjsEFHA.get('synopsis'))
    lqSNbLtMmIenORTdxcfUiaCvjsEFXz=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.HTTPTAG+lqSNbLtMmIenORTdxcfUiaCvjsEFHA.get('image')
    lqSNbLtMmIenORTdxcfUiaCvjsEFXh=lqSNbLtMmIenORTdxcfUiaCvjsEFXG=lqSNbLtMmIenORTdxcfUiaCvjsEFXp=''
    if lqSNbLtMmIenORTdxcfUiaCvjsEFXy!={}:
     lqSNbLtMmIenORTdxcfUiaCvjsEFXh =lqSNbLtMmIenORTdxcfUiaCvjsEFXy.get('imgPoster')
     lqSNbLtMmIenORTdxcfUiaCvjsEFXG =lqSNbLtMmIenORTdxcfUiaCvjsEFXy.get('imgFanart')
     lqSNbLtMmIenORTdxcfUiaCvjsEFXp=lqSNbLtMmIenORTdxcfUiaCvjsEFXy.get('imgClearlogo')
     lqSNbLtMmIenORTdxcfUiaCvjsEFXV={'thumb':lqSNbLtMmIenORTdxcfUiaCvjsEFXz,'poster':lqSNbLtMmIenORTdxcfUiaCvjsEFXh,'fanart':lqSNbLtMmIenORTdxcfUiaCvjsEFXG,'clearlogo':lqSNbLtMmIenORTdxcfUiaCvjsEFXp}
    else:
     lqSNbLtMmIenORTdxcfUiaCvjsEFXV=lqSNbLtMmIenORTdxcfUiaCvjsEFXz
    lqSNbLtMmIenORTdxcfUiaCvjsEFHD={'programtitle':lqSNbLtMmIenORTdxcfUiaCvjsEFHA.get('programtitle'),'episodetitle':lqSNbLtMmIenORTdxcfUiaCvjsEFHA.get('episodetitle'),'episodenumber':lqSNbLtMmIenORTdxcfUiaCvjsEFHA.get('episodenumber'),'releasedate':lqSNbLtMmIenORTdxcfUiaCvjsEFHA.get('releasedate'),'releaseweekday':lqSNbLtMmIenORTdxcfUiaCvjsEFHA.get('releaseweekday'),'programid':lqSNbLtMmIenORTdxcfUiaCvjsEFHA.get('programid'),'contentid':lqSNbLtMmIenORTdxcfUiaCvjsEFHA.get('contentid'),'age':lqSNbLtMmIenORTdxcfUiaCvjsEFHA.get('targetage'),'playtime':lqSNbLtMmIenORTdxcfUiaCvjsEFHA.get('playtime'),'synopsis':lqSNbLtMmIenORTdxcfUiaCvjsEFXB,'episodeactors':lqSNbLtMmIenORTdxcfUiaCvjsEFHA.get('episodeactors').split(',')if lqSNbLtMmIenORTdxcfUiaCvjsEFHA.get('episodeactors')!='' else[],'thumbnail':lqSNbLtMmIenORTdxcfUiaCvjsEFXV}
    lqSNbLtMmIenORTdxcfUiaCvjsEFXr.append(lqSNbLtMmIenORTdxcfUiaCvjsEFHD)
   lqSNbLtMmIenORTdxcfUiaCvjsEFHh=lqSNbLtMmIenORTdxcfUiaCvjsEFgP(lqSNbLtMmIenORTdxcfUiaCvjsEFuW['pagecount'])
   if lqSNbLtMmIenORTdxcfUiaCvjsEFuW['count']:lqSNbLtMmIenORTdxcfUiaCvjsEFHK =lqSNbLtMmIenORTdxcfUiaCvjsEFgP(lqSNbLtMmIenORTdxcfUiaCvjsEFuW['count'])
   else:lqSNbLtMmIenORTdxcfUiaCvjsEFHK=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.EP_LIMIT*page_int
   lqSNbLtMmIenORTdxcfUiaCvjsEFHG=lqSNbLtMmIenORTdxcfUiaCvjsEFHh>lqSNbLtMmIenORTdxcfUiaCvjsEFHK
  except lqSNbLtMmIenORTdxcfUiaCvjsEFgu as exception:
   lqSNbLtMmIenORTdxcfUiaCvjsEFgH(exception)
   return[],lqSNbLtMmIenORTdxcfUiaCvjsEFPV
  return lqSNbLtMmIenORTdxcfUiaCvjsEFXr,lqSNbLtMmIenORTdxcfUiaCvjsEFHG
 def GetEPGList(lqSNbLtMmIenORTdxcfUiaCvjsEFuX,genre):
  lqSNbLtMmIenORTdxcfUiaCvjsEFXW={}
  try:
   lqSNbLtMmIenORTdxcfUiaCvjsEFXk=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.Get_Now_Datetime()
   if genre=='all':
    lqSNbLtMmIenORTdxcfUiaCvjsEFXK =lqSNbLtMmIenORTdxcfUiaCvjsEFXk+datetime.timedelta(hours=3)
   else:
    lqSNbLtMmIenORTdxcfUiaCvjsEFXK =lqSNbLtMmIenORTdxcfUiaCvjsEFXk+datetime.timedelta(hours=3)
   lqSNbLtMmIenORTdxcfUiaCvjsEFuG=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.API_DOMAIN+'/live/epgs'
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo={'limit':'100','offset':'0','genre':genre,'startdatetime':lqSNbLtMmIenORTdxcfUiaCvjsEFXk.strftime('%Y-%m-%d %H:00'),'enddatetime':lqSNbLtMmIenORTdxcfUiaCvjsEFXK.strftime('%Y-%m-%d %H:00')}
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo.update(lqSNbLtMmIenORTdxcfUiaCvjsEFuX.GetDefaultParams(login=lqSNbLtMmIenORTdxcfUiaCvjsEFPV))
   lqSNbLtMmIenORTdxcfUiaCvjsEFuV=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.callRequestCookies('Get',lqSNbLtMmIenORTdxcfUiaCvjsEFuG,payload=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,params=lqSNbLtMmIenORTdxcfUiaCvjsEFuo,headers=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,cookies=lqSNbLtMmIenORTdxcfUiaCvjsEFPp)
   lqSNbLtMmIenORTdxcfUiaCvjsEFuW=json.loads(lqSNbLtMmIenORTdxcfUiaCvjsEFuV.text)
   lqSNbLtMmIenORTdxcfUiaCvjsEFPu=lqSNbLtMmIenORTdxcfUiaCvjsEFuW['list']
   for lqSNbLtMmIenORTdxcfUiaCvjsEFHA in lqSNbLtMmIenORTdxcfUiaCvjsEFPu:
    lqSNbLtMmIenORTdxcfUiaCvjsEFPH=''
    for lqSNbLtMmIenORTdxcfUiaCvjsEFPX in lqSNbLtMmIenORTdxcfUiaCvjsEFHA['list']:
     if lqSNbLtMmIenORTdxcfUiaCvjsEFPH:lqSNbLtMmIenORTdxcfUiaCvjsEFPH+='\n'
     lqSNbLtMmIenORTdxcfUiaCvjsEFPH+=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.Get_ChangeText(lqSNbLtMmIenORTdxcfUiaCvjsEFPX['title'])+'\n'
     lqSNbLtMmIenORTdxcfUiaCvjsEFPH+=' [%s ~ %s]'%(lqSNbLtMmIenORTdxcfUiaCvjsEFPX['starttime'][-5:],lqSNbLtMmIenORTdxcfUiaCvjsEFPX['endtime'][-5:])+'\n'
    lqSNbLtMmIenORTdxcfUiaCvjsEFXW[lqSNbLtMmIenORTdxcfUiaCvjsEFHA['channelid']]=lqSNbLtMmIenORTdxcfUiaCvjsEFPH
  except lqSNbLtMmIenORTdxcfUiaCvjsEFgu as exception:
   lqSNbLtMmIenORTdxcfUiaCvjsEFgH(exception)
  return lqSNbLtMmIenORTdxcfUiaCvjsEFXW
 def Get_LiveChannel_List(lqSNbLtMmIenORTdxcfUiaCvjsEFuX,genre,lqSNbLtMmIenORTdxcfUiaCvjsEFHQ):
  lqSNbLtMmIenORTdxcfUiaCvjsEFHz=[]
  (lqSNbLtMmIenORTdxcfUiaCvjsEFuG,lqSNbLtMmIenORTdxcfUiaCvjsEFuo)=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.Baseapi_Parse(lqSNbLtMmIenORTdxcfUiaCvjsEFHQ)
  if lqSNbLtMmIenORTdxcfUiaCvjsEFuG=='':return lqSNbLtMmIenORTdxcfUiaCvjsEFHz
  lqSNbLtMmIenORTdxcfUiaCvjsEFPg=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.GetEPGList(genre)
  try:
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo.update(lqSNbLtMmIenORTdxcfUiaCvjsEFuX.GetDefaultParams(login=lqSNbLtMmIenORTdxcfUiaCvjsEFPV))
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo['genre']=genre
   lqSNbLtMmIenORTdxcfUiaCvjsEFuV=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.callRequestCookies('Get',lqSNbLtMmIenORTdxcfUiaCvjsEFuG,payload=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,params=lqSNbLtMmIenORTdxcfUiaCvjsEFuo,headers=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,cookies=lqSNbLtMmIenORTdxcfUiaCvjsEFPp)
   lqSNbLtMmIenORTdxcfUiaCvjsEFuW=json.loads(lqSNbLtMmIenORTdxcfUiaCvjsEFuV.text)
   if not('celllist' in lqSNbLtMmIenORTdxcfUiaCvjsEFuW['cell_toplist']):return[]
   lqSNbLtMmIenORTdxcfUiaCvjsEFHJ=lqSNbLtMmIenORTdxcfUiaCvjsEFuW['cell_toplist']['celllist']
   for lqSNbLtMmIenORTdxcfUiaCvjsEFHA in lqSNbLtMmIenORTdxcfUiaCvjsEFHJ:
    lqSNbLtMmIenORTdxcfUiaCvjsEFXQ=lqSNbLtMmIenORTdxcfUiaCvjsEFHA['contentid']
    if lqSNbLtMmIenORTdxcfUiaCvjsEFXQ in lqSNbLtMmIenORTdxcfUiaCvjsEFPg:
     lqSNbLtMmIenORTdxcfUiaCvjsEFPQ=lqSNbLtMmIenORTdxcfUiaCvjsEFPg[lqSNbLtMmIenORTdxcfUiaCvjsEFXQ]
    else:
     lqSNbLtMmIenORTdxcfUiaCvjsEFPQ=''
    lqSNbLtMmIenORTdxcfUiaCvjsEFHD={'studio':lqSNbLtMmIenORTdxcfUiaCvjsEFHA['title_list'][0]['text'],'tvshowtitle':lqSNbLtMmIenORTdxcfUiaCvjsEFuX.Get_ChangeText(lqSNbLtMmIenORTdxcfUiaCvjsEFHA['title_list'][1]['text']),'channelid':lqSNbLtMmIenORTdxcfUiaCvjsEFXQ,'age':lqSNbLtMmIenORTdxcfUiaCvjsEFHA['age'],'thumbnail':'https://%s'%lqSNbLtMmIenORTdxcfUiaCvjsEFHA.get('thumbnail'),'epg':lqSNbLtMmIenORTdxcfUiaCvjsEFPQ}
    lqSNbLtMmIenORTdxcfUiaCvjsEFHz.append(lqSNbLtMmIenORTdxcfUiaCvjsEFHD)
  except lqSNbLtMmIenORTdxcfUiaCvjsEFgu as exception:
   lqSNbLtMmIenORTdxcfUiaCvjsEFgH(exception)
   return[]
  return lqSNbLtMmIenORTdxcfUiaCvjsEFHz
 def Get_Search_List(lqSNbLtMmIenORTdxcfUiaCvjsEFuX,search_key,sType,page_int,exclusion21=lqSNbLtMmIenORTdxcfUiaCvjsEFPV):
  lqSNbLtMmIenORTdxcfUiaCvjsEFPo=[]
  lqSNbLtMmIenORTdxcfUiaCvjsEFHh=lqSNbLtMmIenORTdxcfUiaCvjsEFHK=1
  lqSNbLtMmIenORTdxcfUiaCvjsEFHG=lqSNbLtMmIenORTdxcfUiaCvjsEFPV
  try:
   lqSNbLtMmIenORTdxcfUiaCvjsEFuG=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.API_DOMAIN+'/cf/search/list.js'
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':lqSNbLtMmIenORTdxcfUiaCvjsEFPK((page_int-1)*lqSNbLtMmIenORTdxcfUiaCvjsEFuX.SEARCH_LIMIT),'limit':lqSNbLtMmIenORTdxcfUiaCvjsEFuX.SEARCH_LIMIT,'orderby':'score'}
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo.update(lqSNbLtMmIenORTdxcfUiaCvjsEFuX.GetDefaultParams(login=lqSNbLtMmIenORTdxcfUiaCvjsEFPV))
   lqSNbLtMmIenORTdxcfUiaCvjsEFuV=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.callRequestCookies('Get',lqSNbLtMmIenORTdxcfUiaCvjsEFuG,payload=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,params=lqSNbLtMmIenORTdxcfUiaCvjsEFuo,headers=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,cookies=lqSNbLtMmIenORTdxcfUiaCvjsEFPp)
   lqSNbLtMmIenORTdxcfUiaCvjsEFXo=json.loads(lqSNbLtMmIenORTdxcfUiaCvjsEFuV.text)
   if not('celllist' in lqSNbLtMmIenORTdxcfUiaCvjsEFXo['cell_toplist']):return lqSNbLtMmIenORTdxcfUiaCvjsEFPo,lqSNbLtMmIenORTdxcfUiaCvjsEFHG
   lqSNbLtMmIenORTdxcfUiaCvjsEFHJ=lqSNbLtMmIenORTdxcfUiaCvjsEFXo['cell_toplist']['celllist']
   for lqSNbLtMmIenORTdxcfUiaCvjsEFHA in lqSNbLtMmIenORTdxcfUiaCvjsEFHJ:
    lqSNbLtMmIenORTdxcfUiaCvjsEFHp =lqSNbLtMmIenORTdxcfUiaCvjsEFHA['event_list'][1]['url']
    lqSNbLtMmIenORTdxcfUiaCvjsEFHV=urllib.parse.urlsplit(lqSNbLtMmIenORTdxcfUiaCvjsEFHp).query
    lqSNbLtMmIenORTdxcfUiaCvjsEFHW=lqSNbLtMmIenORTdxcfUiaCvjsEFHV[0:lqSNbLtMmIenORTdxcfUiaCvjsEFHV.find('=')]
    lqSNbLtMmIenORTdxcfUiaCvjsEFHk=lqSNbLtMmIenORTdxcfUiaCvjsEFHV[lqSNbLtMmIenORTdxcfUiaCvjsEFHV.find('=')+1:]
    lqSNbLtMmIenORTdxcfUiaCvjsEFHD={'title':lqSNbLtMmIenORTdxcfUiaCvjsEFHA['title_list'][0]['text'],'age':lqSNbLtMmIenORTdxcfUiaCvjsEFHA['age'],'thumbnail':'https://%s'%lqSNbLtMmIenORTdxcfUiaCvjsEFHA.get('thumbnail'),'videoid':lqSNbLtMmIenORTdxcfUiaCvjsEFHk,'vidtype':lqSNbLtMmIenORTdxcfUiaCvjsEFHW}
    if exclusion21==lqSNbLtMmIenORTdxcfUiaCvjsEFPV or lqSNbLtMmIenORTdxcfUiaCvjsEFHA.get('age')!='21':
     lqSNbLtMmIenORTdxcfUiaCvjsEFPo.append(lqSNbLtMmIenORTdxcfUiaCvjsEFHD)
   lqSNbLtMmIenORTdxcfUiaCvjsEFHh=lqSNbLtMmIenORTdxcfUiaCvjsEFgP(lqSNbLtMmIenORTdxcfUiaCvjsEFXo['cell_toplist']['pagecount'])
   if lqSNbLtMmIenORTdxcfUiaCvjsEFXo['cell_toplist']['count']:lqSNbLtMmIenORTdxcfUiaCvjsEFHK =lqSNbLtMmIenORTdxcfUiaCvjsEFgP(lqSNbLtMmIenORTdxcfUiaCvjsEFXo['cell_toplist']['count'])
   else:lqSNbLtMmIenORTdxcfUiaCvjsEFHK=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.LIST_LIMIT
   lqSNbLtMmIenORTdxcfUiaCvjsEFHG=lqSNbLtMmIenORTdxcfUiaCvjsEFHh>lqSNbLtMmIenORTdxcfUiaCvjsEFHK
  except lqSNbLtMmIenORTdxcfUiaCvjsEFgu as exception:
   lqSNbLtMmIenORTdxcfUiaCvjsEFgH(exception)
  return lqSNbLtMmIenORTdxcfUiaCvjsEFPo,lqSNbLtMmIenORTdxcfUiaCvjsEFHG 
 def GetStreamingURL(lqSNbLtMmIenORTdxcfUiaCvjsEFuX,mode,lqSNbLtMmIenORTdxcfUiaCvjsEFXQ,quality_int,pvrmode='-'):
  lqSNbLtMmIenORTdxcfUiaCvjsEFPJ=lqSNbLtMmIenORTdxcfUiaCvjsEFPz=lqSNbLtMmIenORTdxcfUiaCvjsEFPh=streaming_preview=''
  lqSNbLtMmIenORTdxcfUiaCvjsEFPA=[]
  lqSNbLtMmIenORTdxcfUiaCvjsEFPD='hls'
  if mode=='LIVE':
   lqSNbLtMmIenORTdxcfUiaCvjsEFuG =lqSNbLtMmIenORTdxcfUiaCvjsEFuX.API_DOMAIN+'/live/channels/'+lqSNbLtMmIenORTdxcfUiaCvjsEFXQ
   lqSNbLtMmIenORTdxcfUiaCvjsEFPw='live'
  elif mode=='VOD':
   lqSNbLtMmIenORTdxcfUiaCvjsEFuG =lqSNbLtMmIenORTdxcfUiaCvjsEFuX.API_DOMAIN+'/cf/vod/contents/'+lqSNbLtMmIenORTdxcfUiaCvjsEFXQ
   lqSNbLtMmIenORTdxcfUiaCvjsEFPw='vod'
  elif mode=='MOVIE':
   lqSNbLtMmIenORTdxcfUiaCvjsEFuG =lqSNbLtMmIenORTdxcfUiaCvjsEFuX.API_DOMAIN+'/cf/movie/contents/'+lqSNbLtMmIenORTdxcfUiaCvjsEFXQ
   lqSNbLtMmIenORTdxcfUiaCvjsEFPw='movie'
  try:
   if mode!='LIVE' or pvrmode=='-':
    lqSNbLtMmIenORTdxcfUiaCvjsEFuo=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.GetDefaultParams(login=lqSNbLtMmIenORTdxcfUiaCvjsEFPV)
    lqSNbLtMmIenORTdxcfUiaCvjsEFuV=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.callRequestCookies('Get',lqSNbLtMmIenORTdxcfUiaCvjsEFuG,payload=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,params=lqSNbLtMmIenORTdxcfUiaCvjsEFuo,headers=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,cookies=lqSNbLtMmIenORTdxcfUiaCvjsEFPp)
    lqSNbLtMmIenORTdxcfUiaCvjsEFuW=json.loads(lqSNbLtMmIenORTdxcfUiaCvjsEFuV.text)
    lqSNbLtMmIenORTdxcfUiaCvjsEFPr=lqSNbLtMmIenORTdxcfUiaCvjsEFuW['qualities']['list']
    if lqSNbLtMmIenORTdxcfUiaCvjsEFPr==lqSNbLtMmIenORTdxcfUiaCvjsEFPp:return(lqSNbLtMmIenORTdxcfUiaCvjsEFPJ,lqSNbLtMmIenORTdxcfUiaCvjsEFPz,lqSNbLtMmIenORTdxcfUiaCvjsEFPh,streaming_preview)
    for lqSNbLtMmIenORTdxcfUiaCvjsEFPy in lqSNbLtMmIenORTdxcfUiaCvjsEFPr:
     lqSNbLtMmIenORTdxcfUiaCvjsEFPA.append(lqSNbLtMmIenORTdxcfUiaCvjsEFgP(lqSNbLtMmIenORTdxcfUiaCvjsEFPy.get('id').rstrip('p')))
    if 'type' in lqSNbLtMmIenORTdxcfUiaCvjsEFuW:
     if lqSNbLtMmIenORTdxcfUiaCvjsEFuW['type']=='onair':
      lqSNbLtMmIenORTdxcfUiaCvjsEFPw='onairvod'
    if 'drms' in lqSNbLtMmIenORTdxcfUiaCvjsEFuW:
     if lqSNbLtMmIenORTdxcfUiaCvjsEFuW['drms']:
      lqSNbLtMmIenORTdxcfUiaCvjsEFPD='dash'
  except lqSNbLtMmIenORTdxcfUiaCvjsEFgu as exception:
   lqSNbLtMmIenORTdxcfUiaCvjsEFgH(exception)
   return(lqSNbLtMmIenORTdxcfUiaCvjsEFPJ,lqSNbLtMmIenORTdxcfUiaCvjsEFPz,lqSNbLtMmIenORTdxcfUiaCvjsEFPh,streaming_preview)
  try:
   lqSNbLtMmIenORTdxcfUiaCvjsEFPY=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.CheckQuality(quality_int,lqSNbLtMmIenORTdxcfUiaCvjsEFPA)
   if mode=='LIVE' and pvrmode!='-':
    lqSNbLtMmIenORTdxcfUiaCvjsEFPB='auto'
   else:
    lqSNbLtMmIenORTdxcfUiaCvjsEFPB=lqSNbLtMmIenORTdxcfUiaCvjsEFPK(lqSNbLtMmIenORTdxcfUiaCvjsEFPY)+'p'
   lqSNbLtMmIenORTdxcfUiaCvjsEFuG=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.API_DOMAIN+'/streaming'
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo={'contentid':lqSNbLtMmIenORTdxcfUiaCvjsEFXQ,'contenttype':lqSNbLtMmIenORTdxcfUiaCvjsEFPw,'action':lqSNbLtMmIenORTdxcfUiaCvjsEFPD,'quality':lqSNbLtMmIenORTdxcfUiaCvjsEFPB,'deviceModelId':'Windows 10','guid':lqSNbLtMmIenORTdxcfUiaCvjsEFuX.GetGUID(guidType=2),'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n'}
   lqSNbLtMmIenORTdxcfUiaCvjsEFuo.update(lqSNbLtMmIenORTdxcfUiaCvjsEFuX.GetDefaultParams(login=lqSNbLtMmIenORTdxcfUiaCvjsEFPW))
   lqSNbLtMmIenORTdxcfUiaCvjsEFuV=lqSNbLtMmIenORTdxcfUiaCvjsEFuX.callRequestCookies('Get',lqSNbLtMmIenORTdxcfUiaCvjsEFuG,payload=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,params=lqSNbLtMmIenORTdxcfUiaCvjsEFuo,headers=lqSNbLtMmIenORTdxcfUiaCvjsEFPp,cookies=lqSNbLtMmIenORTdxcfUiaCvjsEFPp)
   lqSNbLtMmIenORTdxcfUiaCvjsEFuW=json.loads(lqSNbLtMmIenORTdxcfUiaCvjsEFuV.text)
   lqSNbLtMmIenORTdxcfUiaCvjsEFPJ=lqSNbLtMmIenORTdxcfUiaCvjsEFuW['playurl']
   if lqSNbLtMmIenORTdxcfUiaCvjsEFPJ==lqSNbLtMmIenORTdxcfUiaCvjsEFPp:return(lqSNbLtMmIenORTdxcfUiaCvjsEFPJ,lqSNbLtMmIenORTdxcfUiaCvjsEFPz,lqSNbLtMmIenORTdxcfUiaCvjsEFPh,streaming_preview)
   lqSNbLtMmIenORTdxcfUiaCvjsEFPz=lqSNbLtMmIenORTdxcfUiaCvjsEFuW['awscookie']
   lqSNbLtMmIenORTdxcfUiaCvjsEFPh =lqSNbLtMmIenORTdxcfUiaCvjsEFuW['drm']
   if 'previewmsg' in lqSNbLtMmIenORTdxcfUiaCvjsEFuW['preview']:streaming_preview=lqSNbLtMmIenORTdxcfUiaCvjsEFuW['preview']['previewmsg']
  except lqSNbLtMmIenORTdxcfUiaCvjsEFgu as exception:
   lqSNbLtMmIenORTdxcfUiaCvjsEFgH(exception)
  return(lqSNbLtMmIenORTdxcfUiaCvjsEFPJ,lqSNbLtMmIenORTdxcfUiaCvjsEFPz,lqSNbLtMmIenORTdxcfUiaCvjsEFPh,streaming_preview) 
# Created by pyminifier (https://github.com/liftoff/pyminifier)
