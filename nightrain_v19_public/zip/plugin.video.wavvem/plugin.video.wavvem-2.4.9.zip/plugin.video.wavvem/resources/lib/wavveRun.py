__author__="NightRain"
fvdTSjcImEOplzNKnJgDkxuPyGUVBY=object
fvdTSjcImEOplzNKnJgDkxuPyGUVBC=None
fvdTSjcImEOplzNKnJgDkxuPyGUVBw=int
fvdTSjcImEOplzNKnJgDkxuPyGUVBa=True
fvdTSjcImEOplzNKnJgDkxuPyGUVBA=False
fvdTSjcImEOplzNKnJgDkxuPyGUVBs=type
fvdTSjcImEOplzNKnJgDkxuPyGUVBt=dict
fvdTSjcImEOplzNKnJgDkxuPyGUVBM=getattr
fvdTSjcImEOplzNKnJgDkxuPyGUVBL=list
fvdTSjcImEOplzNKnJgDkxuPyGUVBq=len
fvdTSjcImEOplzNKnJgDkxuPyGUVBR=range
fvdTSjcImEOplzNKnJgDkxuPyGUVBW=str
fvdTSjcImEOplzNKnJgDkxuPyGUVBi=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import json
fvdTSjcImEOplzNKnJgDkxuPyGUVbX=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://apis.wavve.com/v1/multiband/GN51','icon':'home.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&uicode=VN500','page':'1','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/allprograms?WeekDay=all&broadcastid=VN1000&came=MainCategory&contenttype=program&genre=01&uicode=VN1000&uiparent=GN56&uirank=21&uitype=VN1000','page':'1','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/allprograms?WeekDay=all&adult=n&broadcastid=VN1001&came=MainCategory&contenttype=program&genre=02&subgenre=all&uicode=VN1001&uiparent=GN57&uirank=17&uitype=VN1001','page':'1','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'CN21','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'vod09','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'vod09','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'4','sType':'movie','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'4','sType':'movie','orderby':'modifydate','ordernm':'업데이트순','icon':''},{'title':'프로야구 - 경기중 시청가능','mode':'GAME_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'(웨이브) 검색','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'(웨이브) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
fvdTSjcImEOplzNKnJgDkxuPyGUVbe=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
fvdTSjcImEOplzNKnJgDkxuPyGUVbQ=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
fvdTSjcImEOplzNKnJgDkxuPyGUVbr={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
fvdTSjcImEOplzNKnJgDkxuPyGUVbF =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
fvdTSjcImEOplzNKnJgDkxuPyGUVbB=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_searched.txt'))
from wavveCore import*
class fvdTSjcImEOplzNKnJgDkxuPyGUVbh(fvdTSjcImEOplzNKnJgDkxuPyGUVBY):
 def __init__(fvdTSjcImEOplzNKnJgDkxuPyGUVbo,fvdTSjcImEOplzNKnJgDkxuPyGUVbH,fvdTSjcImEOplzNKnJgDkxuPyGUVbY,fvdTSjcImEOplzNKnJgDkxuPyGUVbC):
  fvdTSjcImEOplzNKnJgDkxuPyGUVbo._addon_url =fvdTSjcImEOplzNKnJgDkxuPyGUVbH
  fvdTSjcImEOplzNKnJgDkxuPyGUVbo._addon_handle=fvdTSjcImEOplzNKnJgDkxuPyGUVbY
  fvdTSjcImEOplzNKnJgDkxuPyGUVbo.main_params =fvdTSjcImEOplzNKnJgDkxuPyGUVbC
  fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj =YtLREoMBucmwQOKAnWfGDeIVxlFavT() 
  fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.WV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_stream(mpd,m3u8)'))
 def addon_noti(fvdTSjcImEOplzNKnJgDkxuPyGUVbo,sting):
  try:
   fvdTSjcImEOplzNKnJgDkxuPyGUVba=xbmcgui.Dialog()
   fvdTSjcImEOplzNKnJgDkxuPyGUVba.notification(__addonname__,sting)
  except:
   fvdTSjcImEOplzNKnJgDkxuPyGUVBC
 def addon_log(fvdTSjcImEOplzNKnJgDkxuPyGUVbo,string):
  try:
   fvdTSjcImEOplzNKnJgDkxuPyGUVbA=string.encode('utf-8','ignore')
  except:
   fvdTSjcImEOplzNKnJgDkxuPyGUVbA='addonException: addon_log'
  fvdTSjcImEOplzNKnJgDkxuPyGUVbs=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,fvdTSjcImEOplzNKnJgDkxuPyGUVbA),level=fvdTSjcImEOplzNKnJgDkxuPyGUVbs)
 def get_keyboard_input(fvdTSjcImEOplzNKnJgDkxuPyGUVbo,fvdTSjcImEOplzNKnJgDkxuPyGUVhw):
  fvdTSjcImEOplzNKnJgDkxuPyGUVbt=fvdTSjcImEOplzNKnJgDkxuPyGUVBC
  kb=xbmc.Keyboard()
  kb.setHeading(fvdTSjcImEOplzNKnJgDkxuPyGUVhw)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   fvdTSjcImEOplzNKnJgDkxuPyGUVbt=kb.getText()
  return fvdTSjcImEOplzNKnJgDkxuPyGUVbt
 def get_settings_account(fvdTSjcImEOplzNKnJgDkxuPyGUVbo):
  fvdTSjcImEOplzNKnJgDkxuPyGUVbM =__addon__.getSetting('id')
  fvdTSjcImEOplzNKnJgDkxuPyGUVbL =__addon__.getSetting('pw')
  fvdTSjcImEOplzNKnJgDkxuPyGUVbq=fvdTSjcImEOplzNKnJgDkxuPyGUVBw(__addon__.getSetting('selected_profile'))
  return(fvdTSjcImEOplzNKnJgDkxuPyGUVbM,fvdTSjcImEOplzNKnJgDkxuPyGUVbL,fvdTSjcImEOplzNKnJgDkxuPyGUVbq)
 def get_settings_totalsearch(fvdTSjcImEOplzNKnJgDkxuPyGUVbo):
  fvdTSjcImEOplzNKnJgDkxuPyGUVbR =fvdTSjcImEOplzNKnJgDkxuPyGUVBa if __addon__.getSetting('local_search')=='true' else fvdTSjcImEOplzNKnJgDkxuPyGUVBA
  fvdTSjcImEOplzNKnJgDkxuPyGUVbW=fvdTSjcImEOplzNKnJgDkxuPyGUVBa if __addon__.getSetting('local_history')=='true' else fvdTSjcImEOplzNKnJgDkxuPyGUVBA
  fvdTSjcImEOplzNKnJgDkxuPyGUVbi =fvdTSjcImEOplzNKnJgDkxuPyGUVBa if __addon__.getSetting('total_search')=='true' else fvdTSjcImEOplzNKnJgDkxuPyGUVBA
  fvdTSjcImEOplzNKnJgDkxuPyGUVhb=fvdTSjcImEOplzNKnJgDkxuPyGUVBa if __addon__.getSetting('total_history')=='true' else fvdTSjcImEOplzNKnJgDkxuPyGUVBA
  fvdTSjcImEOplzNKnJgDkxuPyGUVhX=fvdTSjcImEOplzNKnJgDkxuPyGUVBa if __addon__.getSetting('menu_bookmark')=='true' else fvdTSjcImEOplzNKnJgDkxuPyGUVBA
  return(fvdTSjcImEOplzNKnJgDkxuPyGUVbR,fvdTSjcImEOplzNKnJgDkxuPyGUVbW,fvdTSjcImEOplzNKnJgDkxuPyGUVbi,fvdTSjcImEOplzNKnJgDkxuPyGUVhb,fvdTSjcImEOplzNKnJgDkxuPyGUVhX)
 def get_settings_makebookmark(fvdTSjcImEOplzNKnJgDkxuPyGUVbo):
  return fvdTSjcImEOplzNKnJgDkxuPyGUVBa if __addon__.getSetting('make_bookmark')=='true' else fvdTSjcImEOplzNKnJgDkxuPyGUVBA
 def get_settings_play(fvdTSjcImEOplzNKnJgDkxuPyGUVbo):
  fvdTSjcImEOplzNKnJgDkxuPyGUVhe={'enable_hdr':fvdTSjcImEOplzNKnJgDkxuPyGUVBa if __addon__.getSetting('enable_hdr')=='true' else fvdTSjcImEOplzNKnJgDkxuPyGUVBA,'enable_uhd':fvdTSjcImEOplzNKnJgDkxuPyGUVBa if __addon__.getSetting('enable_uhd')=='true' else fvdTSjcImEOplzNKnJgDkxuPyGUVBA,'streamFilename':fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.WV_STREAM_FILENAME,}
  if fvdTSjcImEOplzNKnJgDkxuPyGUVbo.get_selQuality()<1080:
   fvdTSjcImEOplzNKnJgDkxuPyGUVhe['enable_hdr']=fvdTSjcImEOplzNKnJgDkxuPyGUVBA
   fvdTSjcImEOplzNKnJgDkxuPyGUVhe['enable_uhd']=fvdTSjcImEOplzNKnJgDkxuPyGUVBA
  return(fvdTSjcImEOplzNKnJgDkxuPyGUVhe)
 def get_settings_proxyport(fvdTSjcImEOplzNKnJgDkxuPyGUVbo):
  fvdTSjcImEOplzNKnJgDkxuPyGUVhQ =fvdTSjcImEOplzNKnJgDkxuPyGUVBa if __addon__.getSetting('proxyYn')=='true' else fvdTSjcImEOplzNKnJgDkxuPyGUVBA
  fvdTSjcImEOplzNKnJgDkxuPyGUVhr=fvdTSjcImEOplzNKnJgDkxuPyGUVBw(__addon__.getSetting('proxyPort'))
  return fvdTSjcImEOplzNKnJgDkxuPyGUVhQ,fvdTSjcImEOplzNKnJgDkxuPyGUVhr
 def get_selQuality(fvdTSjcImEOplzNKnJgDkxuPyGUVbo):
  try:
   fvdTSjcImEOplzNKnJgDkxuPyGUVhF=[1080,720,480,360]
   fvdTSjcImEOplzNKnJgDkxuPyGUVhB=fvdTSjcImEOplzNKnJgDkxuPyGUVBw(__addon__.getSetting('selected_quality'))
   return fvdTSjcImEOplzNKnJgDkxuPyGUVhF[fvdTSjcImEOplzNKnJgDkxuPyGUVhB]
  except:
   fvdTSjcImEOplzNKnJgDkxuPyGUVBC
  return 1080 
 def get_settings_exclusion21(fvdTSjcImEOplzNKnJgDkxuPyGUVbo):
  fvdTSjcImEOplzNKnJgDkxuPyGUVho =__addon__.getSetting('exclusion21')
  if fvdTSjcImEOplzNKnJgDkxuPyGUVho=='false':
   return fvdTSjcImEOplzNKnJgDkxuPyGUVBA
  else:
   return fvdTSjcImEOplzNKnJgDkxuPyGUVBa
 def get_settings_direct_replay(fvdTSjcImEOplzNKnJgDkxuPyGUVbo):
  fvdTSjcImEOplzNKnJgDkxuPyGUVhH=fvdTSjcImEOplzNKnJgDkxuPyGUVBw(__addon__.getSetting('direct_replay'))
  if fvdTSjcImEOplzNKnJgDkxuPyGUVhH==0:
   return fvdTSjcImEOplzNKnJgDkxuPyGUVBA
  else:
   return fvdTSjcImEOplzNKnJgDkxuPyGUVBa
 def set_winEpisodeOrderby(fvdTSjcImEOplzNKnJgDkxuPyGUVbo,fvdTSjcImEOplzNKnJgDkxuPyGUVhY):
  __addon__.setSetting('wavve_orderby',fvdTSjcImEOplzNKnJgDkxuPyGUVhY)
 def get_winEpisodeOrderby(fvdTSjcImEOplzNKnJgDkxuPyGUVbo):
  fvdTSjcImEOplzNKnJgDkxuPyGUVhY=__addon__.getSetting('wavve_orderby')
  if fvdTSjcImEOplzNKnJgDkxuPyGUVhY in['',fvdTSjcImEOplzNKnJgDkxuPyGUVBC]:fvdTSjcImEOplzNKnJgDkxuPyGUVhY='desc'
  return fvdTSjcImEOplzNKnJgDkxuPyGUVhY
 def add_dir(fvdTSjcImEOplzNKnJgDkxuPyGUVbo,label,sublabel='',img='',infoLabels=fvdTSjcImEOplzNKnJgDkxuPyGUVBC,isFolder=fvdTSjcImEOplzNKnJgDkxuPyGUVBa,params='',isLink=fvdTSjcImEOplzNKnJgDkxuPyGUVBA,ContextMenu=fvdTSjcImEOplzNKnJgDkxuPyGUVBC):
  fvdTSjcImEOplzNKnJgDkxuPyGUVhC='%s?%s'%(fvdTSjcImEOplzNKnJgDkxuPyGUVbo._addon_url,urllib.parse.urlencode(params))
  if sublabel:fvdTSjcImEOplzNKnJgDkxuPyGUVhw='%s < %s >'%(label,sublabel)
  else: fvdTSjcImEOplzNKnJgDkxuPyGUVhw=label
  if not img:img='DefaultFolder.png'
  fvdTSjcImEOplzNKnJgDkxuPyGUVha=xbmcgui.ListItem(fvdTSjcImEOplzNKnJgDkxuPyGUVhw)
  if fvdTSjcImEOplzNKnJgDkxuPyGUVBs(img)==fvdTSjcImEOplzNKnJgDkxuPyGUVBt:
   fvdTSjcImEOplzNKnJgDkxuPyGUVha.setArt(img)
  else:
   fvdTSjcImEOplzNKnJgDkxuPyGUVha.setArt({'thumb':img,'poster':img})
  if fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.KodiVersion>=20:
   if infoLabels:fvdTSjcImEOplzNKnJgDkxuPyGUVbo.Set_InfoTag(fvdTSjcImEOplzNKnJgDkxuPyGUVha.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:fvdTSjcImEOplzNKnJgDkxuPyGUVha.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   fvdTSjcImEOplzNKnJgDkxuPyGUVha.setProperty('IsPlayable','true')
  if ContextMenu:fvdTSjcImEOplzNKnJgDkxuPyGUVha.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(fvdTSjcImEOplzNKnJgDkxuPyGUVbo._addon_handle,fvdTSjcImEOplzNKnJgDkxuPyGUVhC,fvdTSjcImEOplzNKnJgDkxuPyGUVha,isFolder)
 def Set_InfoTag(fvdTSjcImEOplzNKnJgDkxuPyGUVbo,video_InfoTag:xbmc.InfoTagVideo,fvdTSjcImEOplzNKnJgDkxuPyGUVhW):
  for fvdTSjcImEOplzNKnJgDkxuPyGUVhA,value in fvdTSjcImEOplzNKnJgDkxuPyGUVhW.items():
   if fvdTSjcImEOplzNKnJgDkxuPyGUVbr[fvdTSjcImEOplzNKnJgDkxuPyGUVhA]['type']=='string':
    fvdTSjcImEOplzNKnJgDkxuPyGUVBM(video_InfoTag,fvdTSjcImEOplzNKnJgDkxuPyGUVbr[fvdTSjcImEOplzNKnJgDkxuPyGUVhA]['func'])(value)
   elif fvdTSjcImEOplzNKnJgDkxuPyGUVbr[fvdTSjcImEOplzNKnJgDkxuPyGUVhA]['type']=='int':
    if fvdTSjcImEOplzNKnJgDkxuPyGUVBs(value)==fvdTSjcImEOplzNKnJgDkxuPyGUVBw:
     fvdTSjcImEOplzNKnJgDkxuPyGUVhs=fvdTSjcImEOplzNKnJgDkxuPyGUVBw(value)
    else:
     fvdTSjcImEOplzNKnJgDkxuPyGUVhs=0
    fvdTSjcImEOplzNKnJgDkxuPyGUVBM(video_InfoTag,fvdTSjcImEOplzNKnJgDkxuPyGUVbr[fvdTSjcImEOplzNKnJgDkxuPyGUVhA]['func'])(fvdTSjcImEOplzNKnJgDkxuPyGUVhs)
   elif fvdTSjcImEOplzNKnJgDkxuPyGUVbr[fvdTSjcImEOplzNKnJgDkxuPyGUVhA]['type']=='actor':
    if value!=[]:
     fvdTSjcImEOplzNKnJgDkxuPyGUVBM(video_InfoTag,fvdTSjcImEOplzNKnJgDkxuPyGUVbr[fvdTSjcImEOplzNKnJgDkxuPyGUVhA]['func'])([xbmc.Actor(name)for name in value])
   elif fvdTSjcImEOplzNKnJgDkxuPyGUVbr[fvdTSjcImEOplzNKnJgDkxuPyGUVhA]['type']=='list':
    if fvdTSjcImEOplzNKnJgDkxuPyGUVBs(value)==fvdTSjcImEOplzNKnJgDkxuPyGUVBL:
     fvdTSjcImEOplzNKnJgDkxuPyGUVBM(video_InfoTag,fvdTSjcImEOplzNKnJgDkxuPyGUVbr[fvdTSjcImEOplzNKnJgDkxuPyGUVhA]['func'])(value)
    else:
     fvdTSjcImEOplzNKnJgDkxuPyGUVBM(video_InfoTag,fvdTSjcImEOplzNKnJgDkxuPyGUVbr[fvdTSjcImEOplzNKnJgDkxuPyGUVhA]['func'])([value])
 def dp_Main_List(fvdTSjcImEOplzNKnJgDkxuPyGUVbo):
  (fvdTSjcImEOplzNKnJgDkxuPyGUVbR,fvdTSjcImEOplzNKnJgDkxuPyGUVbW,fvdTSjcImEOplzNKnJgDkxuPyGUVbi,fvdTSjcImEOplzNKnJgDkxuPyGUVhb,fvdTSjcImEOplzNKnJgDkxuPyGUVhX)=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.get_settings_totalsearch()
  for fvdTSjcImEOplzNKnJgDkxuPyGUVht in fvdTSjcImEOplzNKnJgDkxuPyGUVbX:
   fvdTSjcImEOplzNKnJgDkxuPyGUVhw=fvdTSjcImEOplzNKnJgDkxuPyGUVht.get('title')
   fvdTSjcImEOplzNKnJgDkxuPyGUVhM=''
   if fvdTSjcImEOplzNKnJgDkxuPyGUVht.get('mode')=='SEARCH_GROUP' and fvdTSjcImEOplzNKnJgDkxuPyGUVbR ==fvdTSjcImEOplzNKnJgDkxuPyGUVBA:continue
   elif fvdTSjcImEOplzNKnJgDkxuPyGUVht.get('mode')=='SEARCH_HISTORY' and fvdTSjcImEOplzNKnJgDkxuPyGUVbW==fvdTSjcImEOplzNKnJgDkxuPyGUVBA:continue
   elif fvdTSjcImEOplzNKnJgDkxuPyGUVht.get('mode')=='TOTAL_SEARCH' and fvdTSjcImEOplzNKnJgDkxuPyGUVbi ==fvdTSjcImEOplzNKnJgDkxuPyGUVBA:continue
   elif fvdTSjcImEOplzNKnJgDkxuPyGUVht.get('mode')=='TOTAL_HISTORY' and fvdTSjcImEOplzNKnJgDkxuPyGUVhb==fvdTSjcImEOplzNKnJgDkxuPyGUVBA:continue
   elif fvdTSjcImEOplzNKnJgDkxuPyGUVht.get('mode')=='MENU_BOOKMARK' and fvdTSjcImEOplzNKnJgDkxuPyGUVhX==fvdTSjcImEOplzNKnJgDkxuPyGUVBA:continue
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL={'mode':fvdTSjcImEOplzNKnJgDkxuPyGUVht.get('mode'),'sCode':fvdTSjcImEOplzNKnJgDkxuPyGUVht.get('sCode'),'sIndex':fvdTSjcImEOplzNKnJgDkxuPyGUVht.get('sIndex'),'sType':fvdTSjcImEOplzNKnJgDkxuPyGUVht.get('sType'),'suburl':fvdTSjcImEOplzNKnJgDkxuPyGUVht.get('suburl'),'subapi':fvdTSjcImEOplzNKnJgDkxuPyGUVht.get('subapi'),'page':fvdTSjcImEOplzNKnJgDkxuPyGUVht.get('page'),'orderby':fvdTSjcImEOplzNKnJgDkxuPyGUVht.get('orderby'),'ordernm':fvdTSjcImEOplzNKnJgDkxuPyGUVht.get('ordernm')}
   if fvdTSjcImEOplzNKnJgDkxuPyGUVht.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    fvdTSjcImEOplzNKnJgDkxuPyGUVhq=fvdTSjcImEOplzNKnJgDkxuPyGUVBA
    fvdTSjcImEOplzNKnJgDkxuPyGUVhR =fvdTSjcImEOplzNKnJgDkxuPyGUVBa
   else:
    fvdTSjcImEOplzNKnJgDkxuPyGUVhq=fvdTSjcImEOplzNKnJgDkxuPyGUVBa
    fvdTSjcImEOplzNKnJgDkxuPyGUVhR =fvdTSjcImEOplzNKnJgDkxuPyGUVBA
   fvdTSjcImEOplzNKnJgDkxuPyGUVhW={'title':fvdTSjcImEOplzNKnJgDkxuPyGUVhw,'plot':fvdTSjcImEOplzNKnJgDkxuPyGUVhw}
   if fvdTSjcImEOplzNKnJgDkxuPyGUVht.get('mode')=='XXX':fvdTSjcImEOplzNKnJgDkxuPyGUVhW=fvdTSjcImEOplzNKnJgDkxuPyGUVBC
   if 'icon' in fvdTSjcImEOplzNKnJgDkxuPyGUVht:fvdTSjcImEOplzNKnJgDkxuPyGUVhM=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',fvdTSjcImEOplzNKnJgDkxuPyGUVht.get('icon')) 
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.add_dir(fvdTSjcImEOplzNKnJgDkxuPyGUVhw,sublabel='',img=fvdTSjcImEOplzNKnJgDkxuPyGUVhM,infoLabels=fvdTSjcImEOplzNKnJgDkxuPyGUVhW,isFolder=fvdTSjcImEOplzNKnJgDkxuPyGUVhq,params=fvdTSjcImEOplzNKnJgDkxuPyGUVhL,isLink=fvdTSjcImEOplzNKnJgDkxuPyGUVhR)
  xbmcplugin.endOfDirectory(fvdTSjcImEOplzNKnJgDkxuPyGUVbo._addon_handle,cacheToDisc=fvdTSjcImEOplzNKnJgDkxuPyGUVBa)
 def dp_Search_Group(fvdTSjcImEOplzNKnJgDkxuPyGUVbo,args):
  if 'search_key' in args:
   fvdTSjcImEOplzNKnJgDkxuPyGUVXh=args.get('search_key')
  else:
   fvdTSjcImEOplzNKnJgDkxuPyGUVXh=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not fvdTSjcImEOplzNKnJgDkxuPyGUVXh:
    return
  for fvdTSjcImEOplzNKnJgDkxuPyGUVXe in fvdTSjcImEOplzNKnJgDkxuPyGUVbe:
   fvdTSjcImEOplzNKnJgDkxuPyGUVXQ =fvdTSjcImEOplzNKnJgDkxuPyGUVXe.get('mode')
   fvdTSjcImEOplzNKnJgDkxuPyGUVXr=fvdTSjcImEOplzNKnJgDkxuPyGUVXe.get('sType')
   fvdTSjcImEOplzNKnJgDkxuPyGUVhw=fvdTSjcImEOplzNKnJgDkxuPyGUVXe.get('title')
   (fvdTSjcImEOplzNKnJgDkxuPyGUVXF,fvdTSjcImEOplzNKnJgDkxuPyGUVXB)=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.Get_Search_List(fvdTSjcImEOplzNKnJgDkxuPyGUVXh,fvdTSjcImEOplzNKnJgDkxuPyGUVXr,1,exclusion21=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.get_settings_exclusion21())
   fvdTSjcImEOplzNKnJgDkxuPyGUVhW={'plot':'검색어 : '+fvdTSjcImEOplzNKnJgDkxuPyGUVXh+'\n\n'+fvdTSjcImEOplzNKnJgDkxuPyGUVbo.Search_FreeList(fvdTSjcImEOplzNKnJgDkxuPyGUVXF)}
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL={'mode':fvdTSjcImEOplzNKnJgDkxuPyGUVXQ,'sType':fvdTSjcImEOplzNKnJgDkxuPyGUVXr,'search_key':fvdTSjcImEOplzNKnJgDkxuPyGUVXh,'page':'1',}
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.add_dir(fvdTSjcImEOplzNKnJgDkxuPyGUVhw,sublabel='',img='',infoLabels=fvdTSjcImEOplzNKnJgDkxuPyGUVhW,isFolder=fvdTSjcImEOplzNKnJgDkxuPyGUVBa,params=fvdTSjcImEOplzNKnJgDkxuPyGUVhL)
  if fvdTSjcImEOplzNKnJgDkxuPyGUVBq(fvdTSjcImEOplzNKnJgDkxuPyGUVbe)>0:xbmcplugin.endOfDirectory(fvdTSjcImEOplzNKnJgDkxuPyGUVbo._addon_handle,cacheToDisc=fvdTSjcImEOplzNKnJgDkxuPyGUVBa)
  fvdTSjcImEOplzNKnJgDkxuPyGUVbo.Save_Searched_List(fvdTSjcImEOplzNKnJgDkxuPyGUVXh)
 def Search_FreeList(fvdTSjcImEOplzNKnJgDkxuPyGUVbo,search_list):
  fvdTSjcImEOplzNKnJgDkxuPyGUVXo=''
  fvdTSjcImEOplzNKnJgDkxuPyGUVXH=7
  try:
   if fvdTSjcImEOplzNKnJgDkxuPyGUVBq(search_list)==0:return '검색결과 없음'
   for i in fvdTSjcImEOplzNKnJgDkxuPyGUVBR(fvdTSjcImEOplzNKnJgDkxuPyGUVBq(search_list)):
    if i>=fvdTSjcImEOplzNKnJgDkxuPyGUVXH:
     fvdTSjcImEOplzNKnJgDkxuPyGUVXo=fvdTSjcImEOplzNKnJgDkxuPyGUVXo+'...'
     break
    fvdTSjcImEOplzNKnJgDkxuPyGUVXo=fvdTSjcImEOplzNKnJgDkxuPyGUVXo+search_list[i]['title']+'\n'
  except:
   return ''
  return fvdTSjcImEOplzNKnJgDkxuPyGUVXo
 def dp_Watch_Group(fvdTSjcImEOplzNKnJgDkxuPyGUVbo,args):
  for fvdTSjcImEOplzNKnJgDkxuPyGUVXY in fvdTSjcImEOplzNKnJgDkxuPyGUVbQ:
   fvdTSjcImEOplzNKnJgDkxuPyGUVhw=fvdTSjcImEOplzNKnJgDkxuPyGUVXY.get('title')
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL={'mode':fvdTSjcImEOplzNKnJgDkxuPyGUVXY.get('mode'),'sType':fvdTSjcImEOplzNKnJgDkxuPyGUVXY.get('sType')}
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.add_dir(fvdTSjcImEOplzNKnJgDkxuPyGUVhw,sublabel='',img='',infoLabels=fvdTSjcImEOplzNKnJgDkxuPyGUVBC,isFolder=fvdTSjcImEOplzNKnJgDkxuPyGUVBa,params=fvdTSjcImEOplzNKnJgDkxuPyGUVhL)
  if fvdTSjcImEOplzNKnJgDkxuPyGUVBq(fvdTSjcImEOplzNKnJgDkxuPyGUVbQ)>0:xbmcplugin.endOfDirectory(fvdTSjcImEOplzNKnJgDkxuPyGUVbo._addon_handle,cacheToDisc=fvdTSjcImEOplzNKnJgDkxuPyGUVBa)
 def dp_Search_History(fvdTSjcImEOplzNKnJgDkxuPyGUVbo,args):
  fvdTSjcImEOplzNKnJgDkxuPyGUVXC=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.Load_List_File('search')
  for fvdTSjcImEOplzNKnJgDkxuPyGUVXw in fvdTSjcImEOplzNKnJgDkxuPyGUVXC:
   fvdTSjcImEOplzNKnJgDkxuPyGUVXa=fvdTSjcImEOplzNKnJgDkxuPyGUVBt(urllib.parse.parse_qsl(fvdTSjcImEOplzNKnJgDkxuPyGUVXw))
   fvdTSjcImEOplzNKnJgDkxuPyGUVXA=fvdTSjcImEOplzNKnJgDkxuPyGUVXa.get('skey').strip()
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL={'mode':'SEARCH_GROUP','search_key':fvdTSjcImEOplzNKnJgDkxuPyGUVXA,}
   fvdTSjcImEOplzNKnJgDkxuPyGUVXs={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':fvdTSjcImEOplzNKnJgDkxuPyGUVXA,'vType':'-',}
   fvdTSjcImEOplzNKnJgDkxuPyGUVXt=urllib.parse.urlencode(fvdTSjcImEOplzNKnJgDkxuPyGUVXs)
   fvdTSjcImEOplzNKnJgDkxuPyGUVXM=[('선택된 검색어 ( %s ) 삭제'%(fvdTSjcImEOplzNKnJgDkxuPyGUVXA),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(fvdTSjcImEOplzNKnJgDkxuPyGUVXt))]
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.add_dir(fvdTSjcImEOplzNKnJgDkxuPyGUVXA,sublabel='',img=fvdTSjcImEOplzNKnJgDkxuPyGUVBC,infoLabels=fvdTSjcImEOplzNKnJgDkxuPyGUVBC,isFolder=fvdTSjcImEOplzNKnJgDkxuPyGUVBa,params=fvdTSjcImEOplzNKnJgDkxuPyGUVhL,ContextMenu=fvdTSjcImEOplzNKnJgDkxuPyGUVXM)
  fvdTSjcImEOplzNKnJgDkxuPyGUVXL={'plot':'검색목록 전체를 삭제합니다.'}
  fvdTSjcImEOplzNKnJgDkxuPyGUVhw='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  fvdTSjcImEOplzNKnJgDkxuPyGUVhL={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  fvdTSjcImEOplzNKnJgDkxuPyGUVhM=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  fvdTSjcImEOplzNKnJgDkxuPyGUVbo.add_dir(fvdTSjcImEOplzNKnJgDkxuPyGUVhw,sublabel='',img=fvdTSjcImEOplzNKnJgDkxuPyGUVhM,infoLabels=fvdTSjcImEOplzNKnJgDkxuPyGUVXL,isFolder=fvdTSjcImEOplzNKnJgDkxuPyGUVBA,params=fvdTSjcImEOplzNKnJgDkxuPyGUVhL,isLink=fvdTSjcImEOplzNKnJgDkxuPyGUVBa)
  xbmcplugin.endOfDirectory(fvdTSjcImEOplzNKnJgDkxuPyGUVbo._addon_handle,cacheToDisc=fvdTSjcImEOplzNKnJgDkxuPyGUVBA)
 def dp_Search_List(fvdTSjcImEOplzNKnJgDkxuPyGUVbo,args):
  fvdTSjcImEOplzNKnJgDkxuPyGUVXr =args.get('sType')
  fvdTSjcImEOplzNKnJgDkxuPyGUVXq =fvdTSjcImEOplzNKnJgDkxuPyGUVBw(args.get('page'))
  if 'search_key' in args:
   fvdTSjcImEOplzNKnJgDkxuPyGUVXh=args.get('search_key')
  else:
   fvdTSjcImEOplzNKnJgDkxuPyGUVXh=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not fvdTSjcImEOplzNKnJgDkxuPyGUVXh:
    xbmcplugin.endOfDirectory(fvdTSjcImEOplzNKnJgDkxuPyGUVbo._addon_handle)
    return
  fvdTSjcImEOplzNKnJgDkxuPyGUVXR,fvdTSjcImEOplzNKnJgDkxuPyGUVXB=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.Get_Search_List(fvdTSjcImEOplzNKnJgDkxuPyGUVXh,fvdTSjcImEOplzNKnJgDkxuPyGUVXr,fvdTSjcImEOplzNKnJgDkxuPyGUVXq,exclusion21=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.get_settings_exclusion21())
  for fvdTSjcImEOplzNKnJgDkxuPyGUVXW in fvdTSjcImEOplzNKnJgDkxuPyGUVXR:
   fvdTSjcImEOplzNKnJgDkxuPyGUVXi =fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('videoid')
   fvdTSjcImEOplzNKnJgDkxuPyGUVeb =fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('vidtype')
   fvdTSjcImEOplzNKnJgDkxuPyGUVhw =fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('title')
   fvdTSjcImEOplzNKnJgDkxuPyGUVeh=fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('thumbnail')
   fvdTSjcImEOplzNKnJgDkxuPyGUVeX =fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('age')
   if fvdTSjcImEOplzNKnJgDkxuPyGUVeX=='18' or fvdTSjcImEOplzNKnJgDkxuPyGUVeX=='19' or fvdTSjcImEOplzNKnJgDkxuPyGUVeX=='21':fvdTSjcImEOplzNKnJgDkxuPyGUVhw+=' (%s)'%(fvdTSjcImEOplzNKnJgDkxuPyGUVeX)
   fvdTSjcImEOplzNKnJgDkxuPyGUVXL={'mediatype':'tvshow' if fvdTSjcImEOplzNKnJgDkxuPyGUVXr=='vod' else 'movie','mpaa':fvdTSjcImEOplzNKnJgDkxuPyGUVeX,'title':fvdTSjcImEOplzNKnJgDkxuPyGUVhw,'plot':fvdTSjcImEOplzNKnJgDkxuPyGUVhw}
   if fvdTSjcImEOplzNKnJgDkxuPyGUVXr=='vod':
    fvdTSjcImEOplzNKnJgDkxuPyGUVhL={'mode':'EPISODE_LIST','seasonid':fvdTSjcImEOplzNKnJgDkxuPyGUVXi,'page':'1',}
    fvdTSjcImEOplzNKnJgDkxuPyGUVhq=fvdTSjcImEOplzNKnJgDkxuPyGUVBa
   else:
    fvdTSjcImEOplzNKnJgDkxuPyGUVhL={'mode':'MOVIE','contentid':fvdTSjcImEOplzNKnJgDkxuPyGUVXi,'title':fvdTSjcImEOplzNKnJgDkxuPyGUVhw,'thumbnail':fvdTSjcImEOplzNKnJgDkxuPyGUVeh,'age':fvdTSjcImEOplzNKnJgDkxuPyGUVeX,}
    fvdTSjcImEOplzNKnJgDkxuPyGUVhq=fvdTSjcImEOplzNKnJgDkxuPyGUVBA
   fvdTSjcImEOplzNKnJgDkxuPyGUVXM=[]
   fvdTSjcImEOplzNKnJgDkxuPyGUVeQ={'mode':'VIEW_DETAIL','values':{'videoid':fvdTSjcImEOplzNKnJgDkxuPyGUVXi,'vidtype':'tvshow' if fvdTSjcImEOplzNKnJgDkxuPyGUVXr=='vod' else 'movie','contenttype':fvdTSjcImEOplzNKnJgDkxuPyGUVeb,}}
   fvdTSjcImEOplzNKnJgDkxuPyGUVer=json.dumps(fvdTSjcImEOplzNKnJgDkxuPyGUVeQ,separators=(',',':'))
   fvdTSjcImEOplzNKnJgDkxuPyGUVer=base64.standard_b64encode(fvdTSjcImEOplzNKnJgDkxuPyGUVer.encode()).decode('utf-8')
   fvdTSjcImEOplzNKnJgDkxuPyGUVer=fvdTSjcImEOplzNKnJgDkxuPyGUVer.replace('+','%2B')
   fvdTSjcImEOplzNKnJgDkxuPyGUVeF='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(fvdTSjcImEOplzNKnJgDkxuPyGUVer)
   fvdTSjcImEOplzNKnJgDkxuPyGUVXM.append(('상세정보 조회',fvdTSjcImEOplzNKnJgDkxuPyGUVeF))
   if fvdTSjcImEOplzNKnJgDkxuPyGUVbo.get_settings_makebookmark():
    fvdTSjcImEOplzNKnJgDkxuPyGUVeQ={'videoid':fvdTSjcImEOplzNKnJgDkxuPyGUVXi,'vidtype':'tvshow' if fvdTSjcImEOplzNKnJgDkxuPyGUVXr=='vod' else 'movie','vtitle':fvdTSjcImEOplzNKnJgDkxuPyGUVhw,'vsubtitle':'','contenttype':fvdTSjcImEOplzNKnJgDkxuPyGUVeb,}
    fvdTSjcImEOplzNKnJgDkxuPyGUVeB=json.dumps(fvdTSjcImEOplzNKnJgDkxuPyGUVeQ)
    fvdTSjcImEOplzNKnJgDkxuPyGUVeB=urllib.parse.quote(fvdTSjcImEOplzNKnJgDkxuPyGUVeB)
    fvdTSjcImEOplzNKnJgDkxuPyGUVeF='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(fvdTSjcImEOplzNKnJgDkxuPyGUVeB)
    fvdTSjcImEOplzNKnJgDkxuPyGUVXM.append(('(통합) 찜 영상에 추가',fvdTSjcImEOplzNKnJgDkxuPyGUVeF))
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.add_dir(fvdTSjcImEOplzNKnJgDkxuPyGUVhw,sublabel='',img=fvdTSjcImEOplzNKnJgDkxuPyGUVeh,infoLabels=fvdTSjcImEOplzNKnJgDkxuPyGUVXL,isFolder=fvdTSjcImEOplzNKnJgDkxuPyGUVhq,params=fvdTSjcImEOplzNKnJgDkxuPyGUVhL,ContextMenu=fvdTSjcImEOplzNKnJgDkxuPyGUVXM)
  if fvdTSjcImEOplzNKnJgDkxuPyGUVXB:
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL['mode'] ='SEARCH_LIST' 
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL['sType']=fvdTSjcImEOplzNKnJgDkxuPyGUVXr 
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL['page'] =fvdTSjcImEOplzNKnJgDkxuPyGUVBW(fvdTSjcImEOplzNKnJgDkxuPyGUVXq+1)
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL['search_key']=fvdTSjcImEOplzNKnJgDkxuPyGUVXh
   fvdTSjcImEOplzNKnJgDkxuPyGUVhw='[B]%s >>[/B]'%'다음 페이지'
   fvdTSjcImEOplzNKnJgDkxuPyGUVeo=fvdTSjcImEOplzNKnJgDkxuPyGUVBW(fvdTSjcImEOplzNKnJgDkxuPyGUVXq+1)
   fvdTSjcImEOplzNKnJgDkxuPyGUVhM=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.add_dir(fvdTSjcImEOplzNKnJgDkxuPyGUVhw,sublabel=fvdTSjcImEOplzNKnJgDkxuPyGUVeo,img=fvdTSjcImEOplzNKnJgDkxuPyGUVhM,infoLabels=fvdTSjcImEOplzNKnJgDkxuPyGUVBC,isFolder=fvdTSjcImEOplzNKnJgDkxuPyGUVBa,params=fvdTSjcImEOplzNKnJgDkxuPyGUVhL)
  if fvdTSjcImEOplzNKnJgDkxuPyGUVXr=='movie':xbmcplugin.setContent(fvdTSjcImEOplzNKnJgDkxuPyGUVbo._addon_handle,'movies')
  else:xbmcplugin.setContent(fvdTSjcImEOplzNKnJgDkxuPyGUVbo._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(fvdTSjcImEOplzNKnJgDkxuPyGUVbo._addon_handle,cacheToDisc=fvdTSjcImEOplzNKnJgDkxuPyGUVBA)
 def dp_Watch_List(fvdTSjcImEOplzNKnJgDkxuPyGUVbo,args):
  fvdTSjcImEOplzNKnJgDkxuPyGUVXr =args.get('sType')
  fvdTSjcImEOplzNKnJgDkxuPyGUVhH=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.get_settings_direct_replay()
  fvdTSjcImEOplzNKnJgDkxuPyGUVXR=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.Load_List_File(fvdTSjcImEOplzNKnJgDkxuPyGUVXr)
  for fvdTSjcImEOplzNKnJgDkxuPyGUVXW in fvdTSjcImEOplzNKnJgDkxuPyGUVXR:
   fvdTSjcImEOplzNKnJgDkxuPyGUVXa=fvdTSjcImEOplzNKnJgDkxuPyGUVBt(urllib.parse.parse_qsl(fvdTSjcImEOplzNKnJgDkxuPyGUVXW))
   fvdTSjcImEOplzNKnJgDkxuPyGUVeH =fvdTSjcImEOplzNKnJgDkxuPyGUVXa.get('code').strip()
   fvdTSjcImEOplzNKnJgDkxuPyGUVhw =fvdTSjcImEOplzNKnJgDkxuPyGUVXa.get('title').strip()
   fvdTSjcImEOplzNKnJgDkxuPyGUVeo =fvdTSjcImEOplzNKnJgDkxuPyGUVXa.get('subtitle').strip()
   if fvdTSjcImEOplzNKnJgDkxuPyGUVeo=='None':fvdTSjcImEOplzNKnJgDkxuPyGUVeo=''
   fvdTSjcImEOplzNKnJgDkxuPyGUVeh=fvdTSjcImEOplzNKnJgDkxuPyGUVXa.get('img').strip()
   fvdTSjcImEOplzNKnJgDkxuPyGUVXi =fvdTSjcImEOplzNKnJgDkxuPyGUVXa.get('videoid').strip()
   try:
    fvdTSjcImEOplzNKnJgDkxuPyGUVeh=fvdTSjcImEOplzNKnJgDkxuPyGUVeh.replace('\'','\"')
    fvdTSjcImEOplzNKnJgDkxuPyGUVeh=json.loads(fvdTSjcImEOplzNKnJgDkxuPyGUVeh)
   except:
    fvdTSjcImEOplzNKnJgDkxuPyGUVBC
   fvdTSjcImEOplzNKnJgDkxuPyGUVXL={'plot':'%s\n%s'%(fvdTSjcImEOplzNKnJgDkxuPyGUVhw,fvdTSjcImEOplzNKnJgDkxuPyGUVeo)}
   if fvdTSjcImEOplzNKnJgDkxuPyGUVXr=='vod':
    if fvdTSjcImEOplzNKnJgDkxuPyGUVhH==fvdTSjcImEOplzNKnJgDkxuPyGUVBA or fvdTSjcImEOplzNKnJgDkxuPyGUVXi==fvdTSjcImEOplzNKnJgDkxuPyGUVBC:
     fvdTSjcImEOplzNKnJgDkxuPyGUVXL['mediatype']='tvshow'
     fvdTSjcImEOplzNKnJgDkxuPyGUVhL={'mode':'SEASON_LIST','videoid':fvdTSjcImEOplzNKnJgDkxuPyGUVXi,'vidtype':'contentid',}
     fvdTSjcImEOplzNKnJgDkxuPyGUVhq=fvdTSjcImEOplzNKnJgDkxuPyGUVBa
    else:
     fvdTSjcImEOplzNKnJgDkxuPyGUVXL['mediatype']='episode'
     fvdTSjcImEOplzNKnJgDkxuPyGUVhL={'mode':'VOD','programid':fvdTSjcImEOplzNKnJgDkxuPyGUVeH,'contentid':fvdTSjcImEOplzNKnJgDkxuPyGUVXi,'title':fvdTSjcImEOplzNKnJgDkxuPyGUVhw,'subtitle':fvdTSjcImEOplzNKnJgDkxuPyGUVeo,'thumbnail':fvdTSjcImEOplzNKnJgDkxuPyGUVeh}
     fvdTSjcImEOplzNKnJgDkxuPyGUVhq=fvdTSjcImEOplzNKnJgDkxuPyGUVBA
   else:
    fvdTSjcImEOplzNKnJgDkxuPyGUVXL['mediatype']='movie'
    fvdTSjcImEOplzNKnJgDkxuPyGUVhL={'mode':'MOVIE','contentid':fvdTSjcImEOplzNKnJgDkxuPyGUVeH,'title':fvdTSjcImEOplzNKnJgDkxuPyGUVhw,'subtitle':fvdTSjcImEOplzNKnJgDkxuPyGUVeo,'thumbnail':fvdTSjcImEOplzNKnJgDkxuPyGUVeh}
    fvdTSjcImEOplzNKnJgDkxuPyGUVhq=fvdTSjcImEOplzNKnJgDkxuPyGUVBA
   fvdTSjcImEOplzNKnJgDkxuPyGUVXs={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':fvdTSjcImEOplzNKnJgDkxuPyGUVeH,'vType':fvdTSjcImEOplzNKnJgDkxuPyGUVXr,}
   fvdTSjcImEOplzNKnJgDkxuPyGUVXt=urllib.parse.urlencode(fvdTSjcImEOplzNKnJgDkxuPyGUVXs)
   fvdTSjcImEOplzNKnJgDkxuPyGUVXM=[('선택된 시청이력 ( %s ) 삭제'%(fvdTSjcImEOplzNKnJgDkxuPyGUVhw),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(fvdTSjcImEOplzNKnJgDkxuPyGUVXt))]
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.add_dir(fvdTSjcImEOplzNKnJgDkxuPyGUVhw,sublabel=fvdTSjcImEOplzNKnJgDkxuPyGUVeo,img=fvdTSjcImEOplzNKnJgDkxuPyGUVeh,infoLabels=fvdTSjcImEOplzNKnJgDkxuPyGUVXL,isFolder=fvdTSjcImEOplzNKnJgDkxuPyGUVhq,params=fvdTSjcImEOplzNKnJgDkxuPyGUVhL,ContextMenu=fvdTSjcImEOplzNKnJgDkxuPyGUVXM)
  fvdTSjcImEOplzNKnJgDkxuPyGUVXL={'plot':'시청목록을 삭제합니다.'}
  fvdTSjcImEOplzNKnJgDkxuPyGUVhw='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  fvdTSjcImEOplzNKnJgDkxuPyGUVhL={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':fvdTSjcImEOplzNKnJgDkxuPyGUVXr,}
  fvdTSjcImEOplzNKnJgDkxuPyGUVhM=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  fvdTSjcImEOplzNKnJgDkxuPyGUVbo.add_dir(fvdTSjcImEOplzNKnJgDkxuPyGUVhw,sublabel='',img=fvdTSjcImEOplzNKnJgDkxuPyGUVhM,infoLabels=fvdTSjcImEOplzNKnJgDkxuPyGUVXL,isFolder=fvdTSjcImEOplzNKnJgDkxuPyGUVBA,params=fvdTSjcImEOplzNKnJgDkxuPyGUVhL,isLink=fvdTSjcImEOplzNKnJgDkxuPyGUVBa)
  if fvdTSjcImEOplzNKnJgDkxuPyGUVXr=='movie':xbmcplugin.setContent(fvdTSjcImEOplzNKnJgDkxuPyGUVbo._addon_handle,'movies')
  else:xbmcplugin.setContent(fvdTSjcImEOplzNKnJgDkxuPyGUVbo._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(fvdTSjcImEOplzNKnJgDkxuPyGUVbo._addon_handle,cacheToDisc=fvdTSjcImEOplzNKnJgDkxuPyGUVBA)
 def Load_List_File(fvdTSjcImEOplzNKnJgDkxuPyGUVbo,stype): 
  try:
   if stype=='search':
    fvdTSjcImEOplzNKnJgDkxuPyGUVeY=fvdTSjcImEOplzNKnJgDkxuPyGUVbB
   elif stype in['vod','movie']:
    fvdTSjcImEOplzNKnJgDkxuPyGUVeY=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   else:
    return[]
   fp=fvdTSjcImEOplzNKnJgDkxuPyGUVBi(fvdTSjcImEOplzNKnJgDkxuPyGUVeY,'r',-1,'utf-8')
   fvdTSjcImEOplzNKnJgDkxuPyGUVeC=fp.readlines()
   fp.close()
  except:
   fvdTSjcImEOplzNKnJgDkxuPyGUVeC=[]
  return fvdTSjcImEOplzNKnJgDkxuPyGUVeC
 def Save_Watched_List(fvdTSjcImEOplzNKnJgDkxuPyGUVbo,fvdTSjcImEOplzNKnJgDkxuPyGUVFL,fvdTSjcImEOplzNKnJgDkxuPyGUVbC):
  try:
   fvdTSjcImEOplzNKnJgDkxuPyGUVew=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%fvdTSjcImEOplzNKnJgDkxuPyGUVFL))
   fvdTSjcImEOplzNKnJgDkxuPyGUVea=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.Load_List_File(fvdTSjcImEOplzNKnJgDkxuPyGUVFL) 
   fp=fvdTSjcImEOplzNKnJgDkxuPyGUVBi(fvdTSjcImEOplzNKnJgDkxuPyGUVew,'w',-1,'utf-8')
   fvdTSjcImEOplzNKnJgDkxuPyGUVeA=urllib.parse.urlencode(fvdTSjcImEOplzNKnJgDkxuPyGUVbC)
   fvdTSjcImEOplzNKnJgDkxuPyGUVeA=fvdTSjcImEOplzNKnJgDkxuPyGUVeA+'\n'
   fp.write(fvdTSjcImEOplzNKnJgDkxuPyGUVeA)
   fvdTSjcImEOplzNKnJgDkxuPyGUVes=0
   for fvdTSjcImEOplzNKnJgDkxuPyGUVet in fvdTSjcImEOplzNKnJgDkxuPyGUVea:
    fvdTSjcImEOplzNKnJgDkxuPyGUVeM=fvdTSjcImEOplzNKnJgDkxuPyGUVBt(urllib.parse.parse_qsl(fvdTSjcImEOplzNKnJgDkxuPyGUVet))
    fvdTSjcImEOplzNKnJgDkxuPyGUVeL=fvdTSjcImEOplzNKnJgDkxuPyGUVbC.get('code').strip()
    fvdTSjcImEOplzNKnJgDkxuPyGUVeq=fvdTSjcImEOplzNKnJgDkxuPyGUVeM.get('code').strip()
    if fvdTSjcImEOplzNKnJgDkxuPyGUVFL=='vod' and fvdTSjcImEOplzNKnJgDkxuPyGUVbo.get_settings_direct_replay()==fvdTSjcImEOplzNKnJgDkxuPyGUVBa:
     fvdTSjcImEOplzNKnJgDkxuPyGUVeL=fvdTSjcImEOplzNKnJgDkxuPyGUVbC.get('videoid').strip()
     fvdTSjcImEOplzNKnJgDkxuPyGUVeq=fvdTSjcImEOplzNKnJgDkxuPyGUVeM.get('videoid').strip()if fvdTSjcImEOplzNKnJgDkxuPyGUVeq!=fvdTSjcImEOplzNKnJgDkxuPyGUVBC else '-'
    if fvdTSjcImEOplzNKnJgDkxuPyGUVeL!=fvdTSjcImEOplzNKnJgDkxuPyGUVeq:
     fp.write(fvdTSjcImEOplzNKnJgDkxuPyGUVet)
     fvdTSjcImEOplzNKnJgDkxuPyGUVes+=1
     if fvdTSjcImEOplzNKnJgDkxuPyGUVes>=50:break
   fp.close()
  except:
   fvdTSjcImEOplzNKnJgDkxuPyGUVBC
 def dp_History_Remove(fvdTSjcImEOplzNKnJgDkxuPyGUVbo,args):
  fvdTSjcImEOplzNKnJgDkxuPyGUVeR=args.get('delType')
  fvdTSjcImEOplzNKnJgDkxuPyGUVeW =args.get('sKey')
  fvdTSjcImEOplzNKnJgDkxuPyGUVei =args.get('vType')
  fvdTSjcImEOplzNKnJgDkxuPyGUVba=xbmcgui.Dialog()
  if fvdTSjcImEOplzNKnJgDkxuPyGUVeR=='SEARCH_ALL':
   fvdTSjcImEOplzNKnJgDkxuPyGUVQb=fvdTSjcImEOplzNKnJgDkxuPyGUVba.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif fvdTSjcImEOplzNKnJgDkxuPyGUVeR=='SEARCH_ONE':
   fvdTSjcImEOplzNKnJgDkxuPyGUVQb=fvdTSjcImEOplzNKnJgDkxuPyGUVba.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif fvdTSjcImEOplzNKnJgDkxuPyGUVeR=='WATCH_ALL':
   fvdTSjcImEOplzNKnJgDkxuPyGUVQb=fvdTSjcImEOplzNKnJgDkxuPyGUVba.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif fvdTSjcImEOplzNKnJgDkxuPyGUVeR=='WATCH_ONE':
   fvdTSjcImEOplzNKnJgDkxuPyGUVQb=fvdTSjcImEOplzNKnJgDkxuPyGUVba.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if fvdTSjcImEOplzNKnJgDkxuPyGUVQb==fvdTSjcImEOplzNKnJgDkxuPyGUVBA:sys.exit()
  if fvdTSjcImEOplzNKnJgDkxuPyGUVeR=='SEARCH_ALL':
   if os.path.isfile(fvdTSjcImEOplzNKnJgDkxuPyGUVbB):os.remove(fvdTSjcImEOplzNKnJgDkxuPyGUVbB)
  elif fvdTSjcImEOplzNKnJgDkxuPyGUVeR=='SEARCH_ONE':
   try:
    fvdTSjcImEOplzNKnJgDkxuPyGUVeY=fvdTSjcImEOplzNKnJgDkxuPyGUVbB
    fvdTSjcImEOplzNKnJgDkxuPyGUVea=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.Load_List_File('search') 
    fp=fvdTSjcImEOplzNKnJgDkxuPyGUVBi(fvdTSjcImEOplzNKnJgDkxuPyGUVeY,'w',-1,'utf-8')
    for fvdTSjcImEOplzNKnJgDkxuPyGUVet in fvdTSjcImEOplzNKnJgDkxuPyGUVea:
     fvdTSjcImEOplzNKnJgDkxuPyGUVeM=fvdTSjcImEOplzNKnJgDkxuPyGUVBt(urllib.parse.parse_qsl(fvdTSjcImEOplzNKnJgDkxuPyGUVet))
     fvdTSjcImEOplzNKnJgDkxuPyGUVQh=fvdTSjcImEOplzNKnJgDkxuPyGUVeM.get('skey').strip()
     if fvdTSjcImEOplzNKnJgDkxuPyGUVeW!=fvdTSjcImEOplzNKnJgDkxuPyGUVQh:
      fp.write(fvdTSjcImEOplzNKnJgDkxuPyGUVet)
    fp.close()
   except:
    fvdTSjcImEOplzNKnJgDkxuPyGUVBC
  elif fvdTSjcImEOplzNKnJgDkxuPyGUVeR=='WATCH_ALL':
   fvdTSjcImEOplzNKnJgDkxuPyGUVeY=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%fvdTSjcImEOplzNKnJgDkxuPyGUVei))
   if os.path.isfile(fvdTSjcImEOplzNKnJgDkxuPyGUVeY):os.remove(fvdTSjcImEOplzNKnJgDkxuPyGUVeY)
  elif fvdTSjcImEOplzNKnJgDkxuPyGUVeR=='WATCH_ONE':
   fvdTSjcImEOplzNKnJgDkxuPyGUVeY=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%fvdTSjcImEOplzNKnJgDkxuPyGUVei))
   try:
    fvdTSjcImEOplzNKnJgDkxuPyGUVea=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.Load_List_File(fvdTSjcImEOplzNKnJgDkxuPyGUVei) 
    fp=fvdTSjcImEOplzNKnJgDkxuPyGUVBi(fvdTSjcImEOplzNKnJgDkxuPyGUVeY,'w',-1,'utf-8')
    for fvdTSjcImEOplzNKnJgDkxuPyGUVet in fvdTSjcImEOplzNKnJgDkxuPyGUVea:
     fvdTSjcImEOplzNKnJgDkxuPyGUVeM=fvdTSjcImEOplzNKnJgDkxuPyGUVBt(urllib.parse.parse_qsl(fvdTSjcImEOplzNKnJgDkxuPyGUVet))
     fvdTSjcImEOplzNKnJgDkxuPyGUVQh=fvdTSjcImEOplzNKnJgDkxuPyGUVeM.get('code').strip()
     if fvdTSjcImEOplzNKnJgDkxuPyGUVeW!=fvdTSjcImEOplzNKnJgDkxuPyGUVQh:
      fp.write(fvdTSjcImEOplzNKnJgDkxuPyGUVet)
    fp.close()
   except:
    fvdTSjcImEOplzNKnJgDkxuPyGUVBC
  xbmc.executebuiltin("Container.Refresh")
 def Save_Searched_List(fvdTSjcImEOplzNKnJgDkxuPyGUVbo,fvdTSjcImEOplzNKnJgDkxuPyGUVXh):
  try:
   fvdTSjcImEOplzNKnJgDkxuPyGUVQX=fvdTSjcImEOplzNKnJgDkxuPyGUVbB
   fvdTSjcImEOplzNKnJgDkxuPyGUVea=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.Load_List_File('search') 
   fvdTSjcImEOplzNKnJgDkxuPyGUVQe={'skey':fvdTSjcImEOplzNKnJgDkxuPyGUVXh.strip()}
   fp=fvdTSjcImEOplzNKnJgDkxuPyGUVBi(fvdTSjcImEOplzNKnJgDkxuPyGUVQX,'w',-1,'utf-8')
   fvdTSjcImEOplzNKnJgDkxuPyGUVeA=urllib.parse.urlencode(fvdTSjcImEOplzNKnJgDkxuPyGUVQe)
   fvdTSjcImEOplzNKnJgDkxuPyGUVeA=fvdTSjcImEOplzNKnJgDkxuPyGUVeA+'\n'
   fp.write(fvdTSjcImEOplzNKnJgDkxuPyGUVeA)
   fvdTSjcImEOplzNKnJgDkxuPyGUVes=0
   for fvdTSjcImEOplzNKnJgDkxuPyGUVet in fvdTSjcImEOplzNKnJgDkxuPyGUVea:
    fvdTSjcImEOplzNKnJgDkxuPyGUVeM=fvdTSjcImEOplzNKnJgDkxuPyGUVBt(urllib.parse.parse_qsl(fvdTSjcImEOplzNKnJgDkxuPyGUVet))
    fvdTSjcImEOplzNKnJgDkxuPyGUVeL=fvdTSjcImEOplzNKnJgDkxuPyGUVQe.get('skey').strip()
    fvdTSjcImEOplzNKnJgDkxuPyGUVeq=fvdTSjcImEOplzNKnJgDkxuPyGUVeM.get('skey').strip()
    if fvdTSjcImEOplzNKnJgDkxuPyGUVeL!=fvdTSjcImEOplzNKnJgDkxuPyGUVeq:
     fp.write(fvdTSjcImEOplzNKnJgDkxuPyGUVet)
     fvdTSjcImEOplzNKnJgDkxuPyGUVes+=1
     if fvdTSjcImEOplzNKnJgDkxuPyGUVes>=50:break
   fp.close()
  except:
   fvdTSjcImEOplzNKnJgDkxuPyGUVBC
 def dp_Global_Search(fvdTSjcImEOplzNKnJgDkxuPyGUVbo,args):
  fvdTSjcImEOplzNKnJgDkxuPyGUVXQ=args.get('mode')
  if fvdTSjcImEOplzNKnJgDkxuPyGUVXQ=='TOTAL_SEARCH':
   fvdTSjcImEOplzNKnJgDkxuPyGUVQr='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   fvdTSjcImEOplzNKnJgDkxuPyGUVQr='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(fvdTSjcImEOplzNKnJgDkxuPyGUVQr)
 def dp_Bookmark_Menu(fvdTSjcImEOplzNKnJgDkxuPyGUVbo,args):
  fvdTSjcImEOplzNKnJgDkxuPyGUVQr='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(fvdTSjcImEOplzNKnJgDkxuPyGUVQr)
 def login_main(fvdTSjcImEOplzNKnJgDkxuPyGUVbo):
  (fvdTSjcImEOplzNKnJgDkxuPyGUVQF,fvdTSjcImEOplzNKnJgDkxuPyGUVQB,fvdTSjcImEOplzNKnJgDkxuPyGUVQo)=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.get_settings_account()
  if not(fvdTSjcImEOplzNKnJgDkxuPyGUVQF and fvdTSjcImEOplzNKnJgDkxuPyGUVQB):
   fvdTSjcImEOplzNKnJgDkxuPyGUVba=xbmcgui.Dialog()
   fvdTSjcImEOplzNKnJgDkxuPyGUVQb=fvdTSjcImEOplzNKnJgDkxuPyGUVba.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if fvdTSjcImEOplzNKnJgDkxuPyGUVQb==fvdTSjcImEOplzNKnJgDkxuPyGUVBa:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if fvdTSjcImEOplzNKnJgDkxuPyGUVbo.cookiefile_check()==fvdTSjcImEOplzNKnJgDkxuPyGUVBa:return
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   fvdTSjcImEOplzNKnJgDkxuPyGUVQH=0
   while fvdTSjcImEOplzNKnJgDkxuPyGUVBa:
    fvdTSjcImEOplzNKnJgDkxuPyGUVQH+=1
    time.sleep(0.05)
    if fvdTSjcImEOplzNKnJgDkxuPyGUVQH>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  fvdTSjcImEOplzNKnJgDkxuPyGUVQY=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.GetCredential(fvdTSjcImEOplzNKnJgDkxuPyGUVQF,fvdTSjcImEOplzNKnJgDkxuPyGUVQB,fvdTSjcImEOplzNKnJgDkxuPyGUVQo)
  if fvdTSjcImEOplzNKnJgDkxuPyGUVQY:fvdTSjcImEOplzNKnJgDkxuPyGUVbo.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
  if fvdTSjcImEOplzNKnJgDkxuPyGUVQY==fvdTSjcImEOplzNKnJgDkxuPyGUVBA:
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_setEpOrderby(fvdTSjcImEOplzNKnJgDkxuPyGUVbo,args):
  fvdTSjcImEOplzNKnJgDkxuPyGUVhY =args.get('orderby')
  fvdTSjcImEOplzNKnJgDkxuPyGUVbo.set_winEpisodeOrderby(fvdTSjcImEOplzNKnJgDkxuPyGUVhY)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(fvdTSjcImEOplzNKnJgDkxuPyGUVbo,args):
  fvdTSjcImEOplzNKnJgDkxuPyGUVXQ =args.get('mode')
  fvdTSjcImEOplzNKnJgDkxuPyGUVQC =args.get('contentid')
  fvdTSjcImEOplzNKnJgDkxuPyGUVQw =args.get('pvrmode')
  fvdTSjcImEOplzNKnJgDkxuPyGUVQa=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.get_selQuality()
  fvdTSjcImEOplzNKnJgDkxuPyGUVhe =fvdTSjcImEOplzNKnJgDkxuPyGUVbo.get_settings_play()
  fvdTSjcImEOplzNKnJgDkxuPyGUVbo.addon_log(fvdTSjcImEOplzNKnJgDkxuPyGUVQC+' - '+fvdTSjcImEOplzNKnJgDkxuPyGUVXQ)
  if fvdTSjcImEOplzNKnJgDkxuPyGUVXQ=='SPORTS':
   fvdTSjcImEOplzNKnJgDkxuPyGUVQA=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.GetSportsURL(fvdTSjcImEOplzNKnJgDkxuPyGUVQC,fvdTSjcImEOplzNKnJgDkxuPyGUVQa)
  else:
   fvdTSjcImEOplzNKnJgDkxuPyGUVQA=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.GetStreamingURL(fvdTSjcImEOplzNKnJgDkxuPyGUVXQ,fvdTSjcImEOplzNKnJgDkxuPyGUVQC,fvdTSjcImEOplzNKnJgDkxuPyGUVQa,fvdTSjcImEOplzNKnJgDkxuPyGUVQw,playOption=fvdTSjcImEOplzNKnJgDkxuPyGUVhe)
  fvdTSjcImEOplzNKnJgDkxuPyGUVQs={'user-agent':fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.USER_AGENT}
  fvdTSjcImEOplzNKnJgDkxuPyGUVQt=fvdTSjcImEOplzNKnJgDkxuPyGUVQA['stream_cookie'] 
  fvdTSjcImEOplzNKnJgDkxuPyGUVQM=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.make_stream_header(fvdTSjcImEOplzNKnJgDkxuPyGUVQs,fvdTSjcImEOplzNKnJgDkxuPyGUVQt)
  fvdTSjcImEOplzNKnJgDkxuPyGUVQL='{}|{}'.format(fvdTSjcImEOplzNKnJgDkxuPyGUVQA['stream_url'],fvdTSjcImEOplzNKnJgDkxuPyGUVQM)
  fvdTSjcImEOplzNKnJgDkxuPyGUVbo.addon_log('surl : '+fvdTSjcImEOplzNKnJgDkxuPyGUVQL)
  if fvdTSjcImEOplzNKnJgDkxuPyGUVQA['stream_url']=='':
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.addon_noti(__language__(30907).encode('utf8'))
   return
  fvdTSjcImEOplzNKnJgDkxuPyGUVhQ,fvdTSjcImEOplzNKnJgDkxuPyGUVhr=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.get_settings_proxyport()
  fvdTSjcImEOplzNKnJgDkxuPyGUVQq=urllib.parse.urlparse(fvdTSjcImEOplzNKnJgDkxuPyGUVQA['stream_url'])
  fvdTSjcImEOplzNKnJgDkxuPyGUVQq=fvdTSjcImEOplzNKnJgDkxuPyGUVQq.path.strip('/').split('/')
  fvdTSjcImEOplzNKnJgDkxuPyGUVQq=fvdTSjcImEOplzNKnJgDkxuPyGUVQq[fvdTSjcImEOplzNKnJgDkxuPyGUVBq(fvdTSjcImEOplzNKnJgDkxuPyGUVQq)-1] 
  if (fvdTSjcImEOplzNKnJgDkxuPyGUVhQ==fvdTSjcImEOplzNKnJgDkxuPyGUVBa and args.get('mode')in['VOD','MOVIE']and(fvdTSjcImEOplzNKnJgDkxuPyGUVQA['playParam']['hdr']=='hdr' or fvdTSjcImEOplzNKnJgDkxuPyGUVQA['playParam']['uhd']=='uhd')):
   if fvdTSjcImEOplzNKnJgDkxuPyGUVQq.split('.')[1]=='mpd':
    fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.Wavve_Parse_mpd(fvdTSjcImEOplzNKnJgDkxuPyGUVQA)
   else:
    fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.Wavve_Parse_m3u8(fvdTSjcImEOplzNKnJgDkxuPyGUVQA)
   fvdTSjcImEOplzNKnJgDkxuPyGUVQR={'addon':'wavvem','playOption':fvdTSjcImEOplzNKnJgDkxuPyGUVhe,}
   fvdTSjcImEOplzNKnJgDkxuPyGUVQR=json.dumps(fvdTSjcImEOplzNKnJgDkxuPyGUVQR,separators=(',',':'))
   fvdTSjcImEOplzNKnJgDkxuPyGUVQR=base64.standard_b64encode(fvdTSjcImEOplzNKnJgDkxuPyGUVQR.encode()).decode('utf-8')
   fvdTSjcImEOplzNKnJgDkxuPyGUVQL ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(fvdTSjcImEOplzNKnJgDkxuPyGUVhr,fvdTSjcImEOplzNKnJgDkxuPyGUVQL,fvdTSjcImEOplzNKnJgDkxuPyGUVQR)
  fvdTSjcImEOplzNKnJgDkxuPyGUVbo.addon_log('surl : '+fvdTSjcImEOplzNKnJgDkxuPyGUVQL)
  fvdTSjcImEOplzNKnJgDkxuPyGUVQW=xbmcgui.ListItem(path=fvdTSjcImEOplzNKnJgDkxuPyGUVQL)
  if fvdTSjcImEOplzNKnJgDkxuPyGUVQA['stream_drm']:
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.addon_log('!!streaming_drm!!')
   inputstreamhelper.Helper('mpd',drm='com.widevine.alpha').check_inputstream()
   if 'licensetoken' in fvdTSjcImEOplzNKnJgDkxuPyGUVQA['stream_drm']:
    fvdTSjcImEOplzNKnJgDkxuPyGUVrb=fvdTSjcImEOplzNKnJgDkxuPyGUVQA['stream_drm']['licensetoken']
    fvdTSjcImEOplzNKnJgDkxuPyGUVrh =fvdTSjcImEOplzNKnJgDkxuPyGUVQA['stream_drm']['licenseurl']
    if fvdTSjcImEOplzNKnJgDkxuPyGUVXQ=='MOVIE':
     fvdTSjcImEOplzNKnJgDkxuPyGUVrX='https://www.wavve.com/player/movie?movieid=%s'%fvdTSjcImEOplzNKnJgDkxuPyGUVQC
    else:
     fvdTSjcImEOplzNKnJgDkxuPyGUVrX='https://www.wavve.com/player/vod?programid=%s&page=1'%fvdTSjcImEOplzNKnJgDkxuPyGUVQC
    fvdTSjcImEOplzNKnJgDkxuPyGUVre={'content-type':'application/octet-stream','origin':'https://www.wavve.com','License-Token':fvdTSjcImEOplzNKnJgDkxuPyGUVrb,'referer':fvdTSjcImEOplzNKnJgDkxuPyGUVrX,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.USER_AGENT,}
   else:
    fvdTSjcImEOplzNKnJgDkxuPyGUVrb=fvdTSjcImEOplzNKnJgDkxuPyGUVQA['stream_drm']['customdata']
    fvdTSjcImEOplzNKnJgDkxuPyGUVrh =fvdTSjcImEOplzNKnJgDkxuPyGUVQA['stream_drm']['drmhost']
    if fvdTSjcImEOplzNKnJgDkxuPyGUVXQ=='MOVIE':
     fvdTSjcImEOplzNKnJgDkxuPyGUVrX='https://www.wavve.com/player/movie?movieid=%s'%fvdTSjcImEOplzNKnJgDkxuPyGUVQC
    else:
     fvdTSjcImEOplzNKnJgDkxuPyGUVrX='https://www.wavve.com/player/vod?programid=%s&page=1'%fvdTSjcImEOplzNKnJgDkxuPyGUVQC
    fvdTSjcImEOplzNKnJgDkxuPyGUVre={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':fvdTSjcImEOplzNKnJgDkxuPyGUVrb,'referer':fvdTSjcImEOplzNKnJgDkxuPyGUVrX,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.USER_AGENT,}
   fvdTSjcImEOplzNKnJgDkxuPyGUVrQ=fvdTSjcImEOplzNKnJgDkxuPyGUVrh+'|'+urllib.parse.urlencode(fvdTSjcImEOplzNKnJgDkxuPyGUVre)+'|R{SSM}|'
   fvdTSjcImEOplzNKnJgDkxuPyGUVQW.setProperty('inputstream','inputstream.adaptive')
   if fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.KodiVersion<=20:
    fvdTSjcImEOplzNKnJgDkxuPyGUVQW.setProperty('inputstream.adaptive.manifest_type','mpd')
   fvdTSjcImEOplzNKnJgDkxuPyGUVQW.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
   fvdTSjcImEOplzNKnJgDkxuPyGUVQW.setProperty('inputstream.adaptive.license_key',fvdTSjcImEOplzNKnJgDkxuPyGUVrQ)
   fvdTSjcImEOplzNKnJgDkxuPyGUVQW.setProperty('inputstream.adaptive.stream_headers',fvdTSjcImEOplzNKnJgDkxuPyGUVQM)
   fvdTSjcImEOplzNKnJgDkxuPyGUVQW.setProperty('inputstream.adaptive.manifest_headers',fvdTSjcImEOplzNKnJgDkxuPyGUVQM)
  elif fvdTSjcImEOplzNKnJgDkxuPyGUVXQ in['VOD','MOVIE']:
   fvdTSjcImEOplzNKnJgDkxuPyGUVQW.setContentLookup(fvdTSjcImEOplzNKnJgDkxuPyGUVBA)
   fvdTSjcImEOplzNKnJgDkxuPyGUVQW.setMimeType('application/x-mpegURL')
   fvdTSjcImEOplzNKnJgDkxuPyGUVQW.setProperty('inputstream','inputstream.adaptive')
   if fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.KodiVersion<=20:
    if fvdTSjcImEOplzNKnJgDkxuPyGUVQA['stream_action']=='hls':
     fvdTSjcImEOplzNKnJgDkxuPyGUVQW.setProperty('inputstream.adaptive.manifest_type','hls')
    else:
     fvdTSjcImEOplzNKnJgDkxuPyGUVQW.setProperty('inputstream.adaptive.manifest_type','mpd')
   fvdTSjcImEOplzNKnJgDkxuPyGUVQW.setProperty('inputstream.adaptive.stream_headers',fvdTSjcImEOplzNKnJgDkxuPyGUVQM)
   fvdTSjcImEOplzNKnJgDkxuPyGUVQW.setProperty('inputstream.adaptive.manifest_headers',fvdTSjcImEOplzNKnJgDkxuPyGUVQM)
  if fvdTSjcImEOplzNKnJgDkxuPyGUVQA['stream_vtt']:
   fvdTSjcImEOplzNKnJgDkxuPyGUVQW.setSubtitles([fvdTSjcImEOplzNKnJgDkxuPyGUVQA['stream_vtt']])
  xbmcplugin.setResolvedUrl(fvdTSjcImEOplzNKnJgDkxuPyGUVbo._addon_handle,fvdTSjcImEOplzNKnJgDkxuPyGUVBa,fvdTSjcImEOplzNKnJgDkxuPyGUVQW)
  fvdTSjcImEOplzNKnJgDkxuPyGUVrF=fvdTSjcImEOplzNKnJgDkxuPyGUVBA
  if fvdTSjcImEOplzNKnJgDkxuPyGUVQA['stream_preview']:
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.addon_noti(fvdTSjcImEOplzNKnJgDkxuPyGUVQA['stream_preview'].encode('utf-8'))
   fvdTSjcImEOplzNKnJgDkxuPyGUVrF=fvdTSjcImEOplzNKnJgDkxuPyGUVBa
  else:
   if '/preview.' in urllib.parse.urlsplit(fvdTSjcImEOplzNKnJgDkxuPyGUVQA['stream_url']).path:
    fvdTSjcImEOplzNKnJgDkxuPyGUVbo.addon_noti(__language__(30908).encode('utf8'))
    fvdTSjcImEOplzNKnJgDkxuPyGUVrF=fvdTSjcImEOplzNKnJgDkxuPyGUVBa
  try:
   fvdTSjcImEOplzNKnJgDkxuPyGUVrB=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and fvdTSjcImEOplzNKnJgDkxuPyGUVrF==fvdTSjcImEOplzNKnJgDkxuPyGUVBA and fvdTSjcImEOplzNKnJgDkxuPyGUVrB!='-':
    fvdTSjcImEOplzNKnJgDkxuPyGUVhL={'code':fvdTSjcImEOplzNKnJgDkxuPyGUVrB,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    fvdTSjcImEOplzNKnJgDkxuPyGUVbo.Save_Watched_List(args.get('mode').lower(),fvdTSjcImEOplzNKnJgDkxuPyGUVhL)
  except:
   fvdTSjcImEOplzNKnJgDkxuPyGUVBC
 def logout(fvdTSjcImEOplzNKnJgDkxuPyGUVbo):
  fvdTSjcImEOplzNKnJgDkxuPyGUVba=xbmcgui.Dialog()
  fvdTSjcImEOplzNKnJgDkxuPyGUVQb=fvdTSjcImEOplzNKnJgDkxuPyGUVba.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if fvdTSjcImEOplzNKnJgDkxuPyGUVQb==fvdTSjcImEOplzNKnJgDkxuPyGUVBA:sys.exit()
  fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.Init_WV_Total()
  if os.path.isfile(fvdTSjcImEOplzNKnJgDkxuPyGUVbF):os.remove(fvdTSjcImEOplzNKnJgDkxuPyGUVbF)
  fvdTSjcImEOplzNKnJgDkxuPyGUVbo.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(fvdTSjcImEOplzNKnJgDkxuPyGUVbo):
  fvdTSjcImEOplzNKnJgDkxuPyGUVro =fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.Get_Now_Datetime()
  fvdTSjcImEOplzNKnJgDkxuPyGUVrH=fvdTSjcImEOplzNKnJgDkxuPyGUVro+datetime.timedelta(days=fvdTSjcImEOplzNKnJgDkxuPyGUVBw(__addon__.getSetting('cache_ttl')))
  (fvdTSjcImEOplzNKnJgDkxuPyGUVQF,fvdTSjcImEOplzNKnJgDkxuPyGUVQB,fvdTSjcImEOplzNKnJgDkxuPyGUVQo)=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.get_settings_account()
  fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.Save_session_acount(fvdTSjcImEOplzNKnJgDkxuPyGUVQF,fvdTSjcImEOplzNKnJgDkxuPyGUVQB,fvdTSjcImEOplzNKnJgDkxuPyGUVQo)
  fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.WV['account']['token_limit']=fvdTSjcImEOplzNKnJgDkxuPyGUVrH.strftime('%Y%m%d')
  fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.JsonFile_Save(fvdTSjcImEOplzNKnJgDkxuPyGUVbF,fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.WV)
 def cookiefile_check(fvdTSjcImEOplzNKnJgDkxuPyGUVbo):
  fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.WV=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.JsonFile_Load(fvdTSjcImEOplzNKnJgDkxuPyGUVbF)
  if 'account' not in fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.WV:
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.Init_WV_Total()
   return fvdTSjcImEOplzNKnJgDkxuPyGUVBA
  if 'uuid' not in fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.WV.get('cookies'):
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.Init_WV_Total()
   return fvdTSjcImEOplzNKnJgDkxuPyGUVBA
  (fvdTSjcImEOplzNKnJgDkxuPyGUVrY,fvdTSjcImEOplzNKnJgDkxuPyGUVrC,fvdTSjcImEOplzNKnJgDkxuPyGUVrw)=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.get_settings_account()
  (fvdTSjcImEOplzNKnJgDkxuPyGUVra,fvdTSjcImEOplzNKnJgDkxuPyGUVrA,fvdTSjcImEOplzNKnJgDkxuPyGUVrs)=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.Load_session_acount()
  if fvdTSjcImEOplzNKnJgDkxuPyGUVrY!=fvdTSjcImEOplzNKnJgDkxuPyGUVra or fvdTSjcImEOplzNKnJgDkxuPyGUVrC!=fvdTSjcImEOplzNKnJgDkxuPyGUVrA or fvdTSjcImEOplzNKnJgDkxuPyGUVrw!=fvdTSjcImEOplzNKnJgDkxuPyGUVrs:
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.Init_WV_Total()
   return fvdTSjcImEOplzNKnJgDkxuPyGUVBA
  if fvdTSjcImEOplzNKnJgDkxuPyGUVBw(fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))>fvdTSjcImEOplzNKnJgDkxuPyGUVBw(fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.WV['account']['token_limit']):
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.Init_WV_Total()
   return fvdTSjcImEOplzNKnJgDkxuPyGUVBA
  return fvdTSjcImEOplzNKnJgDkxuPyGUVBa
 def dp_LiveCatagory_List(fvdTSjcImEOplzNKnJgDkxuPyGUVbo,args):
  fvdTSjcImEOplzNKnJgDkxuPyGUVrt =args.get('sCode')
  fvdTSjcImEOplzNKnJgDkxuPyGUVrM=args.get('sIndex')
  fvdTSjcImEOplzNKnJgDkxuPyGUVXR,fvdTSjcImEOplzNKnJgDkxuPyGUVrL=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.Get_LiveCatagory_List(fvdTSjcImEOplzNKnJgDkxuPyGUVrt,fvdTSjcImEOplzNKnJgDkxuPyGUVrM)
  for fvdTSjcImEOplzNKnJgDkxuPyGUVXW in fvdTSjcImEOplzNKnJgDkxuPyGUVXR:
   fvdTSjcImEOplzNKnJgDkxuPyGUVhw =fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('title')
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL={'mode':'LIVE_LIST','genre':fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('genre'),'baseapi':fvdTSjcImEOplzNKnJgDkxuPyGUVrL}
   fvdTSjcImEOplzNKnJgDkxuPyGUVhW={'title':fvdTSjcImEOplzNKnJgDkxuPyGUVhw,'plot':fvdTSjcImEOplzNKnJgDkxuPyGUVhw}
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.add_dir(fvdTSjcImEOplzNKnJgDkxuPyGUVhw,sublabel='',img='',infoLabels=fvdTSjcImEOplzNKnJgDkxuPyGUVhW,isFolder=fvdTSjcImEOplzNKnJgDkxuPyGUVBa,params=fvdTSjcImEOplzNKnJgDkxuPyGUVhL)
  if fvdTSjcImEOplzNKnJgDkxuPyGUVBq(fvdTSjcImEOplzNKnJgDkxuPyGUVXR)>0:xbmcplugin.endOfDirectory(fvdTSjcImEOplzNKnJgDkxuPyGUVbo._addon_handle,cacheToDisc=fvdTSjcImEOplzNKnJgDkxuPyGUVBA)
 def dp_MainCatagory_List(fvdTSjcImEOplzNKnJgDkxuPyGUVbo,args):
  fvdTSjcImEOplzNKnJgDkxuPyGUVrt =args.get('sCode')
  fvdTSjcImEOplzNKnJgDkxuPyGUVrM=args.get('sIndex')
  fvdTSjcImEOplzNKnJgDkxuPyGUVXr =args.get('sType')
  fvdTSjcImEOplzNKnJgDkxuPyGUVXR=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.Get_MainCatagory_List(fvdTSjcImEOplzNKnJgDkxuPyGUVrt,fvdTSjcImEOplzNKnJgDkxuPyGUVrM,fvdTSjcImEOplzNKnJgDkxuPyGUVXr)
  for fvdTSjcImEOplzNKnJgDkxuPyGUVXW in fvdTSjcImEOplzNKnJgDkxuPyGUVXR:
   if fvdTSjcImEOplzNKnJgDkxuPyGUVXr in['vod','vod09']:
    if fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('subtype')=='catagory':
     fvdTSjcImEOplzNKnJgDkxuPyGUVXQ='PROGRAM_LIST'
    else:
     fvdTSjcImEOplzNKnJgDkxuPyGUVXQ='SUPERSECTION_LIST'
   elif fvdTSjcImEOplzNKnJgDkxuPyGUVXr=='movie':
    fvdTSjcImEOplzNKnJgDkxuPyGUVXQ='MOVIE_LIST'
   else:
    fvdTSjcImEOplzNKnJgDkxuPyGUVXQ=''
   fvdTSjcImEOplzNKnJgDkxuPyGUVhw='%s (%s)'%(fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('title'),args.get('ordernm'))
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL={'mode':fvdTSjcImEOplzNKnJgDkxuPyGUVXQ,'suburl':fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('suburl'),'subapi':fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if fvdTSjcImEOplzNKnJgDkxuPyGUVbo.get_settings_exclusion21():
    if fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('title')=='성인' or fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('title')=='성인+' or fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('title')=='에로티시즘' or fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('title')=='19':continue
   fvdTSjcImEOplzNKnJgDkxuPyGUVhW={'title':fvdTSjcImEOplzNKnJgDkxuPyGUVhw,'plot':fvdTSjcImEOplzNKnJgDkxuPyGUVhw}
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.add_dir(fvdTSjcImEOplzNKnJgDkxuPyGUVhw,sublabel='',img='',infoLabels=fvdTSjcImEOplzNKnJgDkxuPyGUVhW,isFolder=fvdTSjcImEOplzNKnJgDkxuPyGUVBa,params=fvdTSjcImEOplzNKnJgDkxuPyGUVhL)
  if fvdTSjcImEOplzNKnJgDkxuPyGUVBq(fvdTSjcImEOplzNKnJgDkxuPyGUVXR)>0:xbmcplugin.endOfDirectory(fvdTSjcImEOplzNKnJgDkxuPyGUVbo._addon_handle,cacheToDisc=fvdTSjcImEOplzNKnJgDkxuPyGUVBA)
 def dp_Program_List(fvdTSjcImEOplzNKnJgDkxuPyGUVbo,args):
  fvdTSjcImEOplzNKnJgDkxuPyGUVrq =args.get('subapi')
  fvdTSjcImEOplzNKnJgDkxuPyGUVXq=fvdTSjcImEOplzNKnJgDkxuPyGUVBw(args.get('page'))
  fvdTSjcImEOplzNKnJgDkxuPyGUVhY =args.get('orderby')
  fvdTSjcImEOplzNKnJgDkxuPyGUVbo.addon_log('dp_Program_List')
  fvdTSjcImEOplzNKnJgDkxuPyGUVbo.addon_log(fvdTSjcImEOplzNKnJgDkxuPyGUVrq)
  fvdTSjcImEOplzNKnJgDkxuPyGUVXR,fvdTSjcImEOplzNKnJgDkxuPyGUVXB=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.Get_Program_List(fvdTSjcImEOplzNKnJgDkxuPyGUVrq,fvdTSjcImEOplzNKnJgDkxuPyGUVXq,fvdTSjcImEOplzNKnJgDkxuPyGUVhY)
  for fvdTSjcImEOplzNKnJgDkxuPyGUVXW in fvdTSjcImEOplzNKnJgDkxuPyGUVXR:
   fvdTSjcImEOplzNKnJgDkxuPyGUVXi =fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('videoid')
   fvdTSjcImEOplzNKnJgDkxuPyGUVeb =fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('vidtype')
   fvdTSjcImEOplzNKnJgDkxuPyGUVhw =fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('title')
   fvdTSjcImEOplzNKnJgDkxuPyGUVeh=fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('thumbnail')
   fvdTSjcImEOplzNKnJgDkxuPyGUVeX =fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('age')
   if fvdTSjcImEOplzNKnJgDkxuPyGUVeX=='18' or fvdTSjcImEOplzNKnJgDkxuPyGUVeX=='19' or fvdTSjcImEOplzNKnJgDkxuPyGUVeX=='21':fvdTSjcImEOplzNKnJgDkxuPyGUVhw+=' (%s)'%(fvdTSjcImEOplzNKnJgDkxuPyGUVeX)
   fvdTSjcImEOplzNKnJgDkxuPyGUVhW={'plot':fvdTSjcImEOplzNKnJgDkxuPyGUVhw,'mpaa':fvdTSjcImEOplzNKnJgDkxuPyGUVeX,'mediatype':'tvshow','title':fvdTSjcImEOplzNKnJgDkxuPyGUVhw,}
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL={'mode':'SEASON_LIST','videoid':fvdTSjcImEOplzNKnJgDkxuPyGUVXi,'vidtype':fvdTSjcImEOplzNKnJgDkxuPyGUVeb,}
   fvdTSjcImEOplzNKnJgDkxuPyGUVXM=[]
   fvdTSjcImEOplzNKnJgDkxuPyGUVeQ={'mode':'VIEW_DETAIL','values':{'videoid':fvdTSjcImEOplzNKnJgDkxuPyGUVXi,'vidtype':'tvshow','contenttype':fvdTSjcImEOplzNKnJgDkxuPyGUVeb,}}
   fvdTSjcImEOplzNKnJgDkxuPyGUVer=json.dumps(fvdTSjcImEOplzNKnJgDkxuPyGUVeQ,separators=(',',':'))
   fvdTSjcImEOplzNKnJgDkxuPyGUVer=base64.standard_b64encode(fvdTSjcImEOplzNKnJgDkxuPyGUVer.encode()).decode('utf-8')
   fvdTSjcImEOplzNKnJgDkxuPyGUVer=fvdTSjcImEOplzNKnJgDkxuPyGUVer.replace('+','%2B')
   fvdTSjcImEOplzNKnJgDkxuPyGUVeF='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(fvdTSjcImEOplzNKnJgDkxuPyGUVer)
   fvdTSjcImEOplzNKnJgDkxuPyGUVXM.append(('상세정보 조회',fvdTSjcImEOplzNKnJgDkxuPyGUVeF))
   if fvdTSjcImEOplzNKnJgDkxuPyGUVbo.get_settings_makebookmark():
    fvdTSjcImEOplzNKnJgDkxuPyGUVeQ={'videoid':fvdTSjcImEOplzNKnJgDkxuPyGUVXi,'vidtype':'tvshow','vtitle':fvdTSjcImEOplzNKnJgDkxuPyGUVhw,'vsubtitle':'','contenttype':fvdTSjcImEOplzNKnJgDkxuPyGUVeb,}
    fvdTSjcImEOplzNKnJgDkxuPyGUVeB=json.dumps(fvdTSjcImEOplzNKnJgDkxuPyGUVeQ)
    fvdTSjcImEOplzNKnJgDkxuPyGUVeB=urllib.parse.quote(fvdTSjcImEOplzNKnJgDkxuPyGUVeB)
    fvdTSjcImEOplzNKnJgDkxuPyGUVeF='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(fvdTSjcImEOplzNKnJgDkxuPyGUVeB)
    fvdTSjcImEOplzNKnJgDkxuPyGUVXM.append(('(통합) 찜 영상에 추가',fvdTSjcImEOplzNKnJgDkxuPyGUVeF))
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.add_dir(fvdTSjcImEOplzNKnJgDkxuPyGUVhw,sublabel='',img=fvdTSjcImEOplzNKnJgDkxuPyGUVeh,infoLabels=fvdTSjcImEOplzNKnJgDkxuPyGUVhW,isFolder=fvdTSjcImEOplzNKnJgDkxuPyGUVBa,params=fvdTSjcImEOplzNKnJgDkxuPyGUVhL,ContextMenu=fvdTSjcImEOplzNKnJgDkxuPyGUVXM)
  if fvdTSjcImEOplzNKnJgDkxuPyGUVXB:
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL={}
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL['mode'] ='PROGRAM_LIST' 
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL['subapi']=fvdTSjcImEOplzNKnJgDkxuPyGUVrq 
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL['page'] =fvdTSjcImEOplzNKnJgDkxuPyGUVBW(fvdTSjcImEOplzNKnJgDkxuPyGUVXq+1)
   fvdTSjcImEOplzNKnJgDkxuPyGUVhw='[B]%s >>[/B]'%'다음 페이지'
   fvdTSjcImEOplzNKnJgDkxuPyGUVeo=fvdTSjcImEOplzNKnJgDkxuPyGUVBW(fvdTSjcImEOplzNKnJgDkxuPyGUVXq+1)
   fvdTSjcImEOplzNKnJgDkxuPyGUVhM=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.add_dir(fvdTSjcImEOplzNKnJgDkxuPyGUVhw,sublabel=fvdTSjcImEOplzNKnJgDkxuPyGUVeo,img=fvdTSjcImEOplzNKnJgDkxuPyGUVhM,infoLabels=fvdTSjcImEOplzNKnJgDkxuPyGUVBC,isFolder=fvdTSjcImEOplzNKnJgDkxuPyGUVBa,params=fvdTSjcImEOplzNKnJgDkxuPyGUVhL)
  xbmcplugin.setContent(fvdTSjcImEOplzNKnJgDkxuPyGUVbo._addon_handle,'tvshows')
  if fvdTSjcImEOplzNKnJgDkxuPyGUVBq(fvdTSjcImEOplzNKnJgDkxuPyGUVXR)>0:xbmcplugin.endOfDirectory(fvdTSjcImEOplzNKnJgDkxuPyGUVbo._addon_handle,cacheToDisc=fvdTSjcImEOplzNKnJgDkxuPyGUVBA)
 def dp_Season_List(fvdTSjcImEOplzNKnJgDkxuPyGUVbo,args):
  fvdTSjcImEOplzNKnJgDkxuPyGUVXi=args.get('videoid')
  fvdTSjcImEOplzNKnJgDkxuPyGUVeb=args.get('vidtype')
  fvdTSjcImEOplzNKnJgDkxuPyGUVbo.addon_log('videoid : '+fvdTSjcImEOplzNKnJgDkxuPyGUVXi)
  fvdTSjcImEOplzNKnJgDkxuPyGUVbo.addon_log('vidtype : '+fvdTSjcImEOplzNKnJgDkxuPyGUVeb)
  if fvdTSjcImEOplzNKnJgDkxuPyGUVeb=='contentid':
   fvdTSjcImEOplzNKnJgDkxuPyGUVQC=fvdTSjcImEOplzNKnJgDkxuPyGUVXi
   fvdTSjcImEOplzNKnJgDkxuPyGUVrR =fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.ContentidToSeasonid(fvdTSjcImEOplzNKnJgDkxuPyGUVXi)
  else:
   fvdTSjcImEOplzNKnJgDkxuPyGUVQC=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.ProgramidToContentid(fvdTSjcImEOplzNKnJgDkxuPyGUVXi)
   fvdTSjcImEOplzNKnJgDkxuPyGUVrR =fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.ContentidToSeasonid(fvdTSjcImEOplzNKnJgDkxuPyGUVQC)
  fvdTSjcImEOplzNKnJgDkxuPyGUVrW=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.Get_Season_List(fvdTSjcImEOplzNKnJgDkxuPyGUVrR)
  if fvdTSjcImEOplzNKnJgDkxuPyGUVBq(fvdTSjcImEOplzNKnJgDkxuPyGUVrW)>1:
   for fvdTSjcImEOplzNKnJgDkxuPyGUVri in fvdTSjcImEOplzNKnJgDkxuPyGUVrW:
    fvdTSjcImEOplzNKnJgDkxuPyGUVFb=fvdTSjcImEOplzNKnJgDkxuPyGUVri.get('season_Id')
    fvdTSjcImEOplzNKnJgDkxuPyGUVFh=fvdTSjcImEOplzNKnJgDkxuPyGUVri.get('season_Nm')
    fvdTSjcImEOplzNKnJgDkxuPyGUVFX=fvdTSjcImEOplzNKnJgDkxuPyGUVri.get('programNm')
    fvdTSjcImEOplzNKnJgDkxuPyGUVeh=fvdTSjcImEOplzNKnJgDkxuPyGUVri.get('thumbnail')
    fvdTSjcImEOplzNKnJgDkxuPyGUVFe =fvdTSjcImEOplzNKnJgDkxuPyGUVri.get('synopsis')
    fvdTSjcImEOplzNKnJgDkxuPyGUVXL={'mediatype':'tvshow','title':fvdTSjcImEOplzNKnJgDkxuPyGUVFh,'plot':fvdTSjcImEOplzNKnJgDkxuPyGUVFe,}
    fvdTSjcImEOplzNKnJgDkxuPyGUVhL={'mode':'EPISODE_LIST','seasonid':fvdTSjcImEOplzNKnJgDkxuPyGUVFb,'page':'1',}
    fvdTSjcImEOplzNKnJgDkxuPyGUVbo.add_dir(fvdTSjcImEOplzNKnJgDkxuPyGUVFh,sublabel=fvdTSjcImEOplzNKnJgDkxuPyGUVFX,img=fvdTSjcImEOplzNKnJgDkxuPyGUVeh,infoLabels=fvdTSjcImEOplzNKnJgDkxuPyGUVXL,isFolder=fvdTSjcImEOplzNKnJgDkxuPyGUVBa,params=fvdTSjcImEOplzNKnJgDkxuPyGUVhL,ContextMenu=fvdTSjcImEOplzNKnJgDkxuPyGUVBC)
   xbmcplugin.setContent(fvdTSjcImEOplzNKnJgDkxuPyGUVbo._addon_handle,'seasons')
   xbmcplugin.endOfDirectory(fvdTSjcImEOplzNKnJgDkxuPyGUVbo._addon_handle,cacheToDisc=fvdTSjcImEOplzNKnJgDkxuPyGUVBA)
  else:
   fvdTSjcImEOplzNKnJgDkxuPyGUVFQ={'seasonid':fvdTSjcImEOplzNKnJgDkxuPyGUVrR,'page':'1',}
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.dp_Episode_List(fvdTSjcImEOplzNKnJgDkxuPyGUVFQ)
 def dp_Episode_List(fvdTSjcImEOplzNKnJgDkxuPyGUVbo,args):
  fvdTSjcImEOplzNKnJgDkxuPyGUVrR =args.get('seasonid')
  fvdTSjcImEOplzNKnJgDkxuPyGUVXq =fvdTSjcImEOplzNKnJgDkxuPyGUVBw(args.get('page'))
  fvdTSjcImEOplzNKnJgDkxuPyGUVbo.addon_log('seasonid : '+fvdTSjcImEOplzNKnJgDkxuPyGUVrR)
  fvdTSjcImEOplzNKnJgDkxuPyGUVXR,fvdTSjcImEOplzNKnJgDkxuPyGUVXB=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.Get_Episode_List(fvdTSjcImEOplzNKnJgDkxuPyGUVrR,fvdTSjcImEOplzNKnJgDkxuPyGUVXq,orderby=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.get_winEpisodeOrderby())
  for fvdTSjcImEOplzNKnJgDkxuPyGUVXW in fvdTSjcImEOplzNKnJgDkxuPyGUVXR:
   fvdTSjcImEOplzNKnJgDkxuPyGUVeo=fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('episodenumber')
   fvdTSjcImEOplzNKnJgDkxuPyGUVFr ='[%s]\n\n%s'%(fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('episodetitle'),fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('synopsis'))
   fvdTSjcImEOplzNKnJgDkxuPyGUVXL={'mediatype':'episode','title':fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('programtitle'),'plot':fvdTSjcImEOplzNKnJgDkxuPyGUVFr,'cast':fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('episodeactors'),}
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL={'mode':'VOD','programid':fvdTSjcImEOplzNKnJgDkxuPyGUVrR,'contentid':fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('contentid'),'thumbnail':fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('thumbnail'),'title':fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('programtitle'),'subtitle':fvdTSjcImEOplzNKnJgDkxuPyGUVeo,}
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.add_dir(fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('programtitle'),sublabel=fvdTSjcImEOplzNKnJgDkxuPyGUVeo,img=fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('thumbnail'),infoLabels=fvdTSjcImEOplzNKnJgDkxuPyGUVXL,isFolder=fvdTSjcImEOplzNKnJgDkxuPyGUVBA,params=fvdTSjcImEOplzNKnJgDkxuPyGUVhL)
  if fvdTSjcImEOplzNKnJgDkxuPyGUVXq==1:
   fvdTSjcImEOplzNKnJgDkxuPyGUVXL={'plot':'정렬순서를 변경합니다.'}
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL={}
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL['mode'] ='ORDER_BY' 
   if fvdTSjcImEOplzNKnJgDkxuPyGUVbo.get_winEpisodeOrderby()=='desc':
    fvdTSjcImEOplzNKnJgDkxuPyGUVhw='정렬순서변경 : 최신화부터 -> 1회부터'
    fvdTSjcImEOplzNKnJgDkxuPyGUVhL['orderby']='asc'
   else:
    fvdTSjcImEOplzNKnJgDkxuPyGUVhw='정렬순서변경 : 1회부터 -> 최신화부터'
    fvdTSjcImEOplzNKnJgDkxuPyGUVhL['orderby']='desc'
   fvdTSjcImEOplzNKnJgDkxuPyGUVhM=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.add_dir(fvdTSjcImEOplzNKnJgDkxuPyGUVhw,sublabel='',img=fvdTSjcImEOplzNKnJgDkxuPyGUVhM,infoLabels=fvdTSjcImEOplzNKnJgDkxuPyGUVXL,isFolder=fvdTSjcImEOplzNKnJgDkxuPyGUVBA,params=fvdTSjcImEOplzNKnJgDkxuPyGUVhL,isLink=fvdTSjcImEOplzNKnJgDkxuPyGUVBa)
  if fvdTSjcImEOplzNKnJgDkxuPyGUVXB:
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL={}
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL['mode'] ='EPISODE_LIST' 
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL['seasonid']=fvdTSjcImEOplzNKnJgDkxuPyGUVrR
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL['page'] =fvdTSjcImEOplzNKnJgDkxuPyGUVBW(fvdTSjcImEOplzNKnJgDkxuPyGUVXq+1)
   fvdTSjcImEOplzNKnJgDkxuPyGUVhw='[B]%s >>[/B]'%'다음 페이지'
   fvdTSjcImEOplzNKnJgDkxuPyGUVeo=fvdTSjcImEOplzNKnJgDkxuPyGUVBW(fvdTSjcImEOplzNKnJgDkxuPyGUVXq+1)
   fvdTSjcImEOplzNKnJgDkxuPyGUVhM=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.add_dir(fvdTSjcImEOplzNKnJgDkxuPyGUVhw,sublabel=fvdTSjcImEOplzNKnJgDkxuPyGUVeo,img=fvdTSjcImEOplzNKnJgDkxuPyGUVhM,infoLabels=fvdTSjcImEOplzNKnJgDkxuPyGUVBC,isFolder=fvdTSjcImEOplzNKnJgDkxuPyGUVBa,params=fvdTSjcImEOplzNKnJgDkxuPyGUVhL)
  xbmcplugin.setContent(fvdTSjcImEOplzNKnJgDkxuPyGUVbo._addon_handle,'episodes')
  if fvdTSjcImEOplzNKnJgDkxuPyGUVBq(fvdTSjcImEOplzNKnJgDkxuPyGUVXR)>0:xbmcplugin.endOfDirectory(fvdTSjcImEOplzNKnJgDkxuPyGUVbo._addon_handle,cacheToDisc=fvdTSjcImEOplzNKnJgDkxuPyGUVBA)
 def dp_SuperSection_List(fvdTSjcImEOplzNKnJgDkxuPyGUVbo,args):
  fvdTSjcImEOplzNKnJgDkxuPyGUVFB =args.get('suburl')
  fvdTSjcImEOplzNKnJgDkxuPyGUVrq =args.get('subapi')
  fvdTSjcImEOplzNKnJgDkxuPyGUVbo.addon_log('dp_SuperSection_List')
  fvdTSjcImEOplzNKnJgDkxuPyGUVbo.addon_log('suburl : '+fvdTSjcImEOplzNKnJgDkxuPyGUVFB)
  fvdTSjcImEOplzNKnJgDkxuPyGUVbo.addon_log('subapi : '+fvdTSjcImEOplzNKnJgDkxuPyGUVrq)
  fvdTSjcImEOplzNKnJgDkxuPyGUVXR=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.Get_SuperMultiSection_List(fvdTSjcImEOplzNKnJgDkxuPyGUVFB)
  for fvdTSjcImEOplzNKnJgDkxuPyGUVXW in fvdTSjcImEOplzNKnJgDkxuPyGUVXR:
   fvdTSjcImEOplzNKnJgDkxuPyGUVhw =fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('title')
   fvdTSjcImEOplzNKnJgDkxuPyGUVrq =fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('subapi')
   fvdTSjcImEOplzNKnJgDkxuPyGUVFo=fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('cell_type')
   if fvdTSjcImEOplzNKnJgDkxuPyGUVrq.find('contenttype=movie')>=0 or fvdTSjcImEOplzNKnJgDkxuPyGUVrq.find('mtype=svod')>=0:
    fvdTSjcImEOplzNKnJgDkxuPyGUVXQ='MOVIE_LIST'
   elif re.search('themes/2\d{4}',fvdTSjcImEOplzNKnJgDkxuPyGUVrq)or re.search('themes-band/9\d{4}',fvdTSjcImEOplzNKnJgDkxuPyGUVrq):
    fvdTSjcImEOplzNKnJgDkxuPyGUVXQ='MOVIE_LIST'
   else:
    fvdTSjcImEOplzNKnJgDkxuPyGUVXQ='PROGRAM_LIST'
   '''
   if subapi.find('mtype=svod') >= 0 or subapi.find('mtype=ppv') >= 0 or subapi.find('contenttype=movie') >= 0: #영화 #20201107
    mode = 'MOVIE_LIST'
   elif subapi.find('contenttype=program') >= 0:
    mode = 'PROGRAM_LIST'
   elif cell_type == 'band_71': # band_71 #20201107
    mode   = 'SUPERSECTION_LIST'
    (temp_url, temp_api) = self.WavveObj.Baseapi_Parse(subapi)
    suburl = temp_api.get('api')
    subapi = ''
   elif cell_type == 'band_2': # band_2
    mode = 'BAND2SECTION_LIST'
   elif cell_type == 'band_live':
    mode = 'BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}', subapi) :
    mode = 'MOVIE_LIST'
   else: # band_10
    mode = 'PROGRAM_LIST'
   '''   
   fvdTSjcImEOplzNKnJgDkxuPyGUVXL={'plot':fvdTSjcImEOplzNKnJgDkxuPyGUVhw,'mediatype':'tvshow',}
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL={'mode':fvdTSjcImEOplzNKnJgDkxuPyGUVXQ,'suburl':fvdTSjcImEOplzNKnJgDkxuPyGUVFB,'subapi':fvdTSjcImEOplzNKnJgDkxuPyGUVrq,'page':'1',}
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.add_dir(fvdTSjcImEOplzNKnJgDkxuPyGUVhw,sublabel='',img=fvdTSjcImEOplzNKnJgDkxuPyGUVBC,infoLabels=fvdTSjcImEOplzNKnJgDkxuPyGUVXL,isFolder=fvdTSjcImEOplzNKnJgDkxuPyGUVBa,params=fvdTSjcImEOplzNKnJgDkxuPyGUVhL)
  if fvdTSjcImEOplzNKnJgDkxuPyGUVBq(fvdTSjcImEOplzNKnJgDkxuPyGUVXR)>0:xbmcplugin.endOfDirectory(fvdTSjcImEOplzNKnJgDkxuPyGUVbo._addon_handle,cacheToDisc=fvdTSjcImEOplzNKnJgDkxuPyGUVBA)
 def dp_BandLiveSection_List(fvdTSjcImEOplzNKnJgDkxuPyGUVbo,args):
  fvdTSjcImEOplzNKnJgDkxuPyGUVrq =args.get('subapi')
  fvdTSjcImEOplzNKnJgDkxuPyGUVXq=fvdTSjcImEOplzNKnJgDkxuPyGUVBw(args.get('page'))
  fvdTSjcImEOplzNKnJgDkxuPyGUVXR,fvdTSjcImEOplzNKnJgDkxuPyGUVXB=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.Get_BandLiveSection_List(fvdTSjcImEOplzNKnJgDkxuPyGUVrq,fvdTSjcImEOplzNKnJgDkxuPyGUVXq)
  for fvdTSjcImEOplzNKnJgDkxuPyGUVXW in fvdTSjcImEOplzNKnJgDkxuPyGUVXR:
   fvdTSjcImEOplzNKnJgDkxuPyGUVFH =fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('channelid')
   fvdTSjcImEOplzNKnJgDkxuPyGUVFY =fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('studio')
   fvdTSjcImEOplzNKnJgDkxuPyGUVFC=fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('tvshowtitle')
   fvdTSjcImEOplzNKnJgDkxuPyGUVeh =fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('thumbnail')
   fvdTSjcImEOplzNKnJgDkxuPyGUVeX =fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('age')
   fvdTSjcImEOplzNKnJgDkxuPyGUVXL={'mediatype':'tvshow','mpaa':fvdTSjcImEOplzNKnJgDkxuPyGUVeX,'title':'%s < %s >'%(fvdTSjcImEOplzNKnJgDkxuPyGUVFY,fvdTSjcImEOplzNKnJgDkxuPyGUVFC),'tvshowtitle':fvdTSjcImEOplzNKnJgDkxuPyGUVFC,'studio':fvdTSjcImEOplzNKnJgDkxuPyGUVFY,'plot':fvdTSjcImEOplzNKnJgDkxuPyGUVFY}
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL={'mode':'LIVE','contentid':fvdTSjcImEOplzNKnJgDkxuPyGUVFH}
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.add_dir(fvdTSjcImEOplzNKnJgDkxuPyGUVFY,sublabel=fvdTSjcImEOplzNKnJgDkxuPyGUVFC,img=fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('thumbnail'),infoLabels=fvdTSjcImEOplzNKnJgDkxuPyGUVXL,isFolder=fvdTSjcImEOplzNKnJgDkxuPyGUVBA,params=fvdTSjcImEOplzNKnJgDkxuPyGUVhL)
  if fvdTSjcImEOplzNKnJgDkxuPyGUVXB:
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL={}
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL['mode'] ='BANDLIVESECTION_LIST' 
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL['subapi']=fvdTSjcImEOplzNKnJgDkxuPyGUVrq
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL['page'] =fvdTSjcImEOplzNKnJgDkxuPyGUVBW(fvdTSjcImEOplzNKnJgDkxuPyGUVXq+1)
   fvdTSjcImEOplzNKnJgDkxuPyGUVhw='[B]%s >>[/B]'%'다음 페이지'
   fvdTSjcImEOplzNKnJgDkxuPyGUVeo=fvdTSjcImEOplzNKnJgDkxuPyGUVBW(fvdTSjcImEOplzNKnJgDkxuPyGUVXq+1)
   fvdTSjcImEOplzNKnJgDkxuPyGUVhM=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.add_dir(fvdTSjcImEOplzNKnJgDkxuPyGUVhw,sublabel=fvdTSjcImEOplzNKnJgDkxuPyGUVeo,img=fvdTSjcImEOplzNKnJgDkxuPyGUVhM,infoLabels=fvdTSjcImEOplzNKnJgDkxuPyGUVBC,isFolder=fvdTSjcImEOplzNKnJgDkxuPyGUVBa,params=fvdTSjcImEOplzNKnJgDkxuPyGUVhL)
  if fvdTSjcImEOplzNKnJgDkxuPyGUVBq(fvdTSjcImEOplzNKnJgDkxuPyGUVXR)>0:xbmcplugin.endOfDirectory(fvdTSjcImEOplzNKnJgDkxuPyGUVbo._addon_handle,cacheToDisc=fvdTSjcImEOplzNKnJgDkxuPyGUVBA)
 def dp_Band2Section_List(fvdTSjcImEOplzNKnJgDkxuPyGUVbo,args):
  fvdTSjcImEOplzNKnJgDkxuPyGUVrq =args.get('subapi')
  fvdTSjcImEOplzNKnJgDkxuPyGUVXq=fvdTSjcImEOplzNKnJgDkxuPyGUVBw(args.get('page'))
  fvdTSjcImEOplzNKnJgDkxuPyGUVXR,fvdTSjcImEOplzNKnJgDkxuPyGUVXB=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.Get_Band2Section_List(fvdTSjcImEOplzNKnJgDkxuPyGUVrq,fvdTSjcImEOplzNKnJgDkxuPyGUVXq)
  for fvdTSjcImEOplzNKnJgDkxuPyGUVXW in fvdTSjcImEOplzNKnJgDkxuPyGUVXR:
   fvdTSjcImEOplzNKnJgDkxuPyGUVhw =fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('programtitle')
   fvdTSjcImEOplzNKnJgDkxuPyGUVeo =fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('episodetitle')
   fvdTSjcImEOplzNKnJgDkxuPyGUVXL={'plot':fvdTSjcImEOplzNKnJgDkxuPyGUVhw+'\n\n'+fvdTSjcImEOplzNKnJgDkxuPyGUVeo,'mpaa':fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('age'),'mediatype':'episode'}
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL={'mode':'VOD','programid':'-','contentid':fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('videoid'),'thumbnail':fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('thumbnail'),'title':fvdTSjcImEOplzNKnJgDkxuPyGUVhw,'subtitle':fvdTSjcImEOplzNKnJgDkxuPyGUVeo}
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.add_dir(fvdTSjcImEOplzNKnJgDkxuPyGUVhw,sublabel=fvdTSjcImEOplzNKnJgDkxuPyGUVeo,img=fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('thumbnail'),infoLabels=fvdTSjcImEOplzNKnJgDkxuPyGUVXL,isFolder=fvdTSjcImEOplzNKnJgDkxuPyGUVBA,params=fvdTSjcImEOplzNKnJgDkxuPyGUVhL)
  if fvdTSjcImEOplzNKnJgDkxuPyGUVXB:
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL={}
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL['mode'] ='BAND2SECTION_LIST' 
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL['subapi']=fvdTSjcImEOplzNKnJgDkxuPyGUVrq
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL['page'] =fvdTSjcImEOplzNKnJgDkxuPyGUVBW(fvdTSjcImEOplzNKnJgDkxuPyGUVXq+1)
   fvdTSjcImEOplzNKnJgDkxuPyGUVhw='[B]%s >>[/B]'%'다음 페이지'
   fvdTSjcImEOplzNKnJgDkxuPyGUVeo=fvdTSjcImEOplzNKnJgDkxuPyGUVBW(fvdTSjcImEOplzNKnJgDkxuPyGUVXq+1)
   fvdTSjcImEOplzNKnJgDkxuPyGUVhM=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.add_dir(fvdTSjcImEOplzNKnJgDkxuPyGUVhw,sublabel=fvdTSjcImEOplzNKnJgDkxuPyGUVeo,img=fvdTSjcImEOplzNKnJgDkxuPyGUVhM,infoLabels=fvdTSjcImEOplzNKnJgDkxuPyGUVBC,isFolder=fvdTSjcImEOplzNKnJgDkxuPyGUVBa,params=fvdTSjcImEOplzNKnJgDkxuPyGUVhL)
  if fvdTSjcImEOplzNKnJgDkxuPyGUVBq(fvdTSjcImEOplzNKnJgDkxuPyGUVXR)>0:xbmcplugin.endOfDirectory(fvdTSjcImEOplzNKnJgDkxuPyGUVbo._addon_handle,cacheToDisc=fvdTSjcImEOplzNKnJgDkxuPyGUVBA)
 def dp_Movie_List(fvdTSjcImEOplzNKnJgDkxuPyGUVbo,args):
  fvdTSjcImEOplzNKnJgDkxuPyGUVrq =args.get('subapi')
  fvdTSjcImEOplzNKnJgDkxuPyGUVXq=fvdTSjcImEOplzNKnJgDkxuPyGUVBw(args.get('page'))
  fvdTSjcImEOplzNKnJgDkxuPyGUVhY =args.get('orderby')or '-'
  fvdTSjcImEOplzNKnJgDkxuPyGUVbo.addon_log('dp_Movie_List')
  fvdTSjcImEOplzNKnJgDkxuPyGUVbo.addon_log(fvdTSjcImEOplzNKnJgDkxuPyGUVrq)
  fvdTSjcImEOplzNKnJgDkxuPyGUVXR,fvdTSjcImEOplzNKnJgDkxuPyGUVXB=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.Get_Movie_List(fvdTSjcImEOplzNKnJgDkxuPyGUVrq,fvdTSjcImEOplzNKnJgDkxuPyGUVXq,fvdTSjcImEOplzNKnJgDkxuPyGUVhY)
  for fvdTSjcImEOplzNKnJgDkxuPyGUVXW in fvdTSjcImEOplzNKnJgDkxuPyGUVXR:
   fvdTSjcImEOplzNKnJgDkxuPyGUVXi =fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('videoid')
   fvdTSjcImEOplzNKnJgDkxuPyGUVeb =fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('vidtype')
   fvdTSjcImEOplzNKnJgDkxuPyGUVhw =fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('title')
   fvdTSjcImEOplzNKnJgDkxuPyGUVeh=fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('thumbnail')
   fvdTSjcImEOplzNKnJgDkxuPyGUVeX =fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('age')
   if fvdTSjcImEOplzNKnJgDkxuPyGUVeX=='18' or fvdTSjcImEOplzNKnJgDkxuPyGUVeX=='19' or fvdTSjcImEOplzNKnJgDkxuPyGUVeX=='21':fvdTSjcImEOplzNKnJgDkxuPyGUVhw+=' (%s)'%(fvdTSjcImEOplzNKnJgDkxuPyGUVeX)
   fvdTSjcImEOplzNKnJgDkxuPyGUVXL={'plot':fvdTSjcImEOplzNKnJgDkxuPyGUVhw,'mpaa':fvdTSjcImEOplzNKnJgDkxuPyGUVeX,'mediatype':'movie'}
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL={'mode':'MOVIE','contentid':fvdTSjcImEOplzNKnJgDkxuPyGUVXi,'title':fvdTSjcImEOplzNKnJgDkxuPyGUVhw,'thumbnail':fvdTSjcImEOplzNKnJgDkxuPyGUVeh,'age':fvdTSjcImEOplzNKnJgDkxuPyGUVeX,}
   fvdTSjcImEOplzNKnJgDkxuPyGUVXM=[]
   fvdTSjcImEOplzNKnJgDkxuPyGUVeQ={'mode':'VIEW_DETAIL','values':{'videoid':fvdTSjcImEOplzNKnJgDkxuPyGUVXi,'vidtype':'movie','contenttype':fvdTSjcImEOplzNKnJgDkxuPyGUVeb,}}
   fvdTSjcImEOplzNKnJgDkxuPyGUVer=json.dumps(fvdTSjcImEOplzNKnJgDkxuPyGUVeQ,separators=(',',':'))
   fvdTSjcImEOplzNKnJgDkxuPyGUVer=base64.standard_b64encode(fvdTSjcImEOplzNKnJgDkxuPyGUVer.encode()).decode('utf-8')
   fvdTSjcImEOplzNKnJgDkxuPyGUVer=fvdTSjcImEOplzNKnJgDkxuPyGUVer.replace('+','%2B')
   fvdTSjcImEOplzNKnJgDkxuPyGUVeF='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(fvdTSjcImEOplzNKnJgDkxuPyGUVer)
   fvdTSjcImEOplzNKnJgDkxuPyGUVXM.append(('상세정보 조회',fvdTSjcImEOplzNKnJgDkxuPyGUVeF))
   if fvdTSjcImEOplzNKnJgDkxuPyGUVbo.get_settings_makebookmark():
    fvdTSjcImEOplzNKnJgDkxuPyGUVeQ={'videoid':fvdTSjcImEOplzNKnJgDkxuPyGUVXi,'vidtype':'movie','vtitle':fvdTSjcImEOplzNKnJgDkxuPyGUVhw,'vsubtitle':'','contenttype':'programid',}
    fvdTSjcImEOplzNKnJgDkxuPyGUVeB=json.dumps(fvdTSjcImEOplzNKnJgDkxuPyGUVeQ)
    fvdTSjcImEOplzNKnJgDkxuPyGUVeB=urllib.parse.quote(fvdTSjcImEOplzNKnJgDkxuPyGUVeB)
    fvdTSjcImEOplzNKnJgDkxuPyGUVeF='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(fvdTSjcImEOplzNKnJgDkxuPyGUVeB)
    fvdTSjcImEOplzNKnJgDkxuPyGUVXM.append(('(통합) 찜 영상에 추가',fvdTSjcImEOplzNKnJgDkxuPyGUVeF))
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.add_dir(fvdTSjcImEOplzNKnJgDkxuPyGUVhw,sublabel='',img=fvdTSjcImEOplzNKnJgDkxuPyGUVeh,infoLabels=fvdTSjcImEOplzNKnJgDkxuPyGUVXL,isFolder=fvdTSjcImEOplzNKnJgDkxuPyGUVBA,params=fvdTSjcImEOplzNKnJgDkxuPyGUVhL,ContextMenu=fvdTSjcImEOplzNKnJgDkxuPyGUVXM)
  if fvdTSjcImEOplzNKnJgDkxuPyGUVXB:
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL={}
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL['mode'] ='MOVIE_LIST' 
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL['subapi']=fvdTSjcImEOplzNKnJgDkxuPyGUVrq 
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL['page'] =fvdTSjcImEOplzNKnJgDkxuPyGUVBW(fvdTSjcImEOplzNKnJgDkxuPyGUVXq+1)
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL['orderby']=fvdTSjcImEOplzNKnJgDkxuPyGUVhY
   fvdTSjcImEOplzNKnJgDkxuPyGUVhw='[B]%s >>[/B]'%'다음 페이지'
   fvdTSjcImEOplzNKnJgDkxuPyGUVeo=fvdTSjcImEOplzNKnJgDkxuPyGUVBW(fvdTSjcImEOplzNKnJgDkxuPyGUVXq+1)
   fvdTSjcImEOplzNKnJgDkxuPyGUVhM=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.add_dir(fvdTSjcImEOplzNKnJgDkxuPyGUVhw,sublabel=fvdTSjcImEOplzNKnJgDkxuPyGUVeo,img=fvdTSjcImEOplzNKnJgDkxuPyGUVhM,infoLabels=fvdTSjcImEOplzNKnJgDkxuPyGUVBC,isFolder=fvdTSjcImEOplzNKnJgDkxuPyGUVBa,params=fvdTSjcImEOplzNKnJgDkxuPyGUVhL)
  xbmcplugin.setContent(fvdTSjcImEOplzNKnJgDkxuPyGUVbo._addon_handle,'movies')
  if fvdTSjcImEOplzNKnJgDkxuPyGUVBq(fvdTSjcImEOplzNKnJgDkxuPyGUVXR)>0:xbmcplugin.endOfDirectory(fvdTSjcImEOplzNKnJgDkxuPyGUVbo._addon_handle,cacheToDisc=fvdTSjcImEOplzNKnJgDkxuPyGUVBA)
 def dp_Set_Bookmark(fvdTSjcImEOplzNKnJgDkxuPyGUVbo,args):
  fvdTSjcImEOplzNKnJgDkxuPyGUVFw=urllib.parse.unquote(args.get('bm_param'))
  fvdTSjcImEOplzNKnJgDkxuPyGUVFw=json.loads(fvdTSjcImEOplzNKnJgDkxuPyGUVFw)
  fvdTSjcImEOplzNKnJgDkxuPyGUVXi =fvdTSjcImEOplzNKnJgDkxuPyGUVFw.get('videoid')
  fvdTSjcImEOplzNKnJgDkxuPyGUVeb =fvdTSjcImEOplzNKnJgDkxuPyGUVFw.get('vidtype')
  fvdTSjcImEOplzNKnJgDkxuPyGUVFa =fvdTSjcImEOplzNKnJgDkxuPyGUVFw.get('vtitle')
  fvdTSjcImEOplzNKnJgDkxuPyGUVFA =fvdTSjcImEOplzNKnJgDkxuPyGUVFw.get('vsubtitle')
  fvdTSjcImEOplzNKnJgDkxuPyGUVFs=fvdTSjcImEOplzNKnJgDkxuPyGUVFw.get('contenttype')
  fvdTSjcImEOplzNKnJgDkxuPyGUVba=xbmcgui.Dialog()
  fvdTSjcImEOplzNKnJgDkxuPyGUVQb=fvdTSjcImEOplzNKnJgDkxuPyGUVba.yesno(__language__(30913).encode('utf8'),fvdTSjcImEOplzNKnJgDkxuPyGUVFa+' \n\n'+__language__(30914))
  if fvdTSjcImEOplzNKnJgDkxuPyGUVQb==fvdTSjcImEOplzNKnJgDkxuPyGUVBA:return
  fvdTSjcImEOplzNKnJgDkxuPyGUVFt=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.GetBookmarkInfo(fvdTSjcImEOplzNKnJgDkxuPyGUVXi,fvdTSjcImEOplzNKnJgDkxuPyGUVeb,fvdTSjcImEOplzNKnJgDkxuPyGUVFs)
  fvdTSjcImEOplzNKnJgDkxuPyGUVFM=json.dumps(fvdTSjcImEOplzNKnJgDkxuPyGUVFt)
  fvdTSjcImEOplzNKnJgDkxuPyGUVFM=urllib.parse.quote(fvdTSjcImEOplzNKnJgDkxuPyGUVFM)
  fvdTSjcImEOplzNKnJgDkxuPyGUVeF ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(fvdTSjcImEOplzNKnJgDkxuPyGUVFM)
  xbmc.executebuiltin(fvdTSjcImEOplzNKnJgDkxuPyGUVeF)
 def dp_LiveChannel_List(fvdTSjcImEOplzNKnJgDkxuPyGUVbo,args):
  fvdTSjcImEOplzNKnJgDkxuPyGUVFL =args.get('genre')
  fvdTSjcImEOplzNKnJgDkxuPyGUVrL=args.get('baseapi')
  fvdTSjcImEOplzNKnJgDkxuPyGUVXR=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.Get_LiveChannel_List(fvdTSjcImEOplzNKnJgDkxuPyGUVFL,fvdTSjcImEOplzNKnJgDkxuPyGUVrL)
  for fvdTSjcImEOplzNKnJgDkxuPyGUVXW in fvdTSjcImEOplzNKnJgDkxuPyGUVXR:
   fvdTSjcImEOplzNKnJgDkxuPyGUVFH =fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('channelid')
   fvdTSjcImEOplzNKnJgDkxuPyGUVFY =fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('studio')
   fvdTSjcImEOplzNKnJgDkxuPyGUVFC=fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('tvshowtitle')
   fvdTSjcImEOplzNKnJgDkxuPyGUVeh =fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('thumbnail')
   fvdTSjcImEOplzNKnJgDkxuPyGUVeX =fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('age')
   fvdTSjcImEOplzNKnJgDkxuPyGUVFq =fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('epg')
   fvdTSjcImEOplzNKnJgDkxuPyGUVXL={'mediatype':'episode','mpaa':fvdTSjcImEOplzNKnJgDkxuPyGUVeX,'title':'%s < %s >'%(fvdTSjcImEOplzNKnJgDkxuPyGUVFY,fvdTSjcImEOplzNKnJgDkxuPyGUVFC),'tvshowtitle':fvdTSjcImEOplzNKnJgDkxuPyGUVFC,'studio':fvdTSjcImEOplzNKnJgDkxuPyGUVFY,'plot':'%s\n\n%s'%(fvdTSjcImEOplzNKnJgDkxuPyGUVFY,fvdTSjcImEOplzNKnJgDkxuPyGUVFq)}
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL={'mode':'LIVE','contentid':fvdTSjcImEOplzNKnJgDkxuPyGUVFH}
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.add_dir(fvdTSjcImEOplzNKnJgDkxuPyGUVFY,sublabel=fvdTSjcImEOplzNKnJgDkxuPyGUVFC,img=fvdTSjcImEOplzNKnJgDkxuPyGUVeh,infoLabels=fvdTSjcImEOplzNKnJgDkxuPyGUVXL,isFolder=fvdTSjcImEOplzNKnJgDkxuPyGUVBA,params=fvdTSjcImEOplzNKnJgDkxuPyGUVhL)
  if fvdTSjcImEOplzNKnJgDkxuPyGUVBq(fvdTSjcImEOplzNKnJgDkxuPyGUVXR)>0:xbmcplugin.endOfDirectory(fvdTSjcImEOplzNKnJgDkxuPyGUVbo._addon_handle,cacheToDisc=fvdTSjcImEOplzNKnJgDkxuPyGUVBA)
 def dp_Sports_GameList(fvdTSjcImEOplzNKnJgDkxuPyGUVbo,args):
  fvdTSjcImEOplzNKnJgDkxuPyGUVXR=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.Get_Sports_Gamelist()
  for fvdTSjcImEOplzNKnJgDkxuPyGUVXW in fvdTSjcImEOplzNKnJgDkxuPyGUVXR:
   fvdTSjcImEOplzNKnJgDkxuPyGUVFR =fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('game_date')
   fvdTSjcImEOplzNKnJgDkxuPyGUVFW =fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('game_time')
   fvdTSjcImEOplzNKnJgDkxuPyGUVFi =fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('svc_id')
   fvdTSjcImEOplzNKnJgDkxuPyGUVBb =fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('away_team')
   fvdTSjcImEOplzNKnJgDkxuPyGUVBh =fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('home_team')
   fvdTSjcImEOplzNKnJgDkxuPyGUVBX=fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('game_status')
   fvdTSjcImEOplzNKnJgDkxuPyGUVBe =fvdTSjcImEOplzNKnJgDkxuPyGUVXW.get('game_place')
   fvdTSjcImEOplzNKnJgDkxuPyGUVBQ ='%s vs %s (%s)'%(fvdTSjcImEOplzNKnJgDkxuPyGUVBb,fvdTSjcImEOplzNKnJgDkxuPyGUVBh,fvdTSjcImEOplzNKnJgDkxuPyGUVBe)
   fvdTSjcImEOplzNKnJgDkxuPyGUVBr =fvdTSjcImEOplzNKnJgDkxuPyGUVFR+' '+fvdTSjcImEOplzNKnJgDkxuPyGUVFW
   if fvdTSjcImEOplzNKnJgDkxuPyGUVBX=='LIVE':
    fvdTSjcImEOplzNKnJgDkxuPyGUVBX='~경기중~'
   elif fvdTSjcImEOplzNKnJgDkxuPyGUVBX=='END':
    fvdTSjcImEOplzNKnJgDkxuPyGUVBX='경기종료'
   elif fvdTSjcImEOplzNKnJgDkxuPyGUVBX=='CANCEL':
    fvdTSjcImEOplzNKnJgDkxuPyGUVBX='취소'
   else:
    fvdTSjcImEOplzNKnJgDkxuPyGUVBX=''
   if fvdTSjcImEOplzNKnJgDkxuPyGUVBX=='':
    fvdTSjcImEOplzNKnJgDkxuPyGUVeo=fvdTSjcImEOplzNKnJgDkxuPyGUVBQ
   else:
    fvdTSjcImEOplzNKnJgDkxuPyGUVeo=fvdTSjcImEOplzNKnJgDkxuPyGUVBQ+'  '+fvdTSjcImEOplzNKnJgDkxuPyGUVBX
   fvdTSjcImEOplzNKnJgDkxuPyGUVXL={'mediatype':'episode','title':fvdTSjcImEOplzNKnJgDkxuPyGUVBQ,'plot':'%s\n\n%s\n\n%s'%(fvdTSjcImEOplzNKnJgDkxuPyGUVBr,fvdTSjcImEOplzNKnJgDkxuPyGUVBQ,fvdTSjcImEOplzNKnJgDkxuPyGUVBX)}
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL={'mode':'SPORTS','contentid':fvdTSjcImEOplzNKnJgDkxuPyGUVFi}
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.add_dir(fvdTSjcImEOplzNKnJgDkxuPyGUVBr,sublabel=fvdTSjcImEOplzNKnJgDkxuPyGUVeo,img='',infoLabels=fvdTSjcImEOplzNKnJgDkxuPyGUVXL,isFolder=fvdTSjcImEOplzNKnJgDkxuPyGUVBA,params=fvdTSjcImEOplzNKnJgDkxuPyGUVhL)
  xbmcplugin.endOfDirectory(fvdTSjcImEOplzNKnJgDkxuPyGUVbo._addon_handle,cacheToDisc=fvdTSjcImEOplzNKnJgDkxuPyGUVBA)
 def dp_View_Detail(fvdTSjcImEOplzNKnJgDkxuPyGUVbo,fvdTSjcImEOplzNKnJgDkxuPyGUVBH):
  fvdTSjcImEOplzNKnJgDkxuPyGUVXi =fvdTSjcImEOplzNKnJgDkxuPyGUVBH.get('videoid')
  fvdTSjcImEOplzNKnJgDkxuPyGUVeb =fvdTSjcImEOplzNKnJgDkxuPyGUVBH.get('vidtype') 
  fvdTSjcImEOplzNKnJgDkxuPyGUVFs=fvdTSjcImEOplzNKnJgDkxuPyGUVBH.get('contenttype')
  fvdTSjcImEOplzNKnJgDkxuPyGUVbo.addon_log(fvdTSjcImEOplzNKnJgDkxuPyGUVXi)
  fvdTSjcImEOplzNKnJgDkxuPyGUVbo.addon_log(fvdTSjcImEOplzNKnJgDkxuPyGUVeb)
  fvdTSjcImEOplzNKnJgDkxuPyGUVbo.addon_log(fvdTSjcImEOplzNKnJgDkxuPyGUVFs)
  fvdTSjcImEOplzNKnJgDkxuPyGUVFt=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.GetBookmarkInfo(fvdTSjcImEOplzNKnJgDkxuPyGUVXi,fvdTSjcImEOplzNKnJgDkxuPyGUVeb,fvdTSjcImEOplzNKnJgDkxuPyGUVFs)
  if fvdTSjcImEOplzNKnJgDkxuPyGUVeb=='tvshow':
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL={'mode':'SEASON_LIST','videoid':fvdTSjcImEOplzNKnJgDkxuPyGUVFt['indexinfo']['videoid'],'vidtype':fvdTSjcImEOplzNKnJgDkxuPyGUVFt['indexinfo']['vidtype'],}
   fvdTSjcImEOplzNKnJgDkxuPyGUVQr='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(fvdTSjcImEOplzNKnJgDkxuPyGUVhL))
  else:
   fvdTSjcImEOplzNKnJgDkxuPyGUVhL={'mode':'MOVIE','contentid':fvdTSjcImEOplzNKnJgDkxuPyGUVFt['indexinfo']['videoid'],'title':fvdTSjcImEOplzNKnJgDkxuPyGUVFt['saveinfo']['infoLabels']['title'],'thumbnail':fvdTSjcImEOplzNKnJgDkxuPyGUVFt['saveinfo']['thumbnail'],'age':fvdTSjcImEOplzNKnJgDkxuPyGUVFt['saveinfo']['infoLabels']['mpaa'],}
   fvdTSjcImEOplzNKnJgDkxuPyGUVQr='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(fvdTSjcImEOplzNKnJgDkxuPyGUVhL))
  fvdTSjcImEOplzNKnJgDkxuPyGUVha=xbmcgui.ListItem(label=fvdTSjcImEOplzNKnJgDkxuPyGUVFt['saveinfo']['title'],path=fvdTSjcImEOplzNKnJgDkxuPyGUVQr)
  fvdTSjcImEOplzNKnJgDkxuPyGUVha.setArt(fvdTSjcImEOplzNKnJgDkxuPyGUVFt['saveinfo']['thumbnail'])
  fvdTSjcImEOplzNKnJgDkxuPyGUVbo.Set_InfoTag(fvdTSjcImEOplzNKnJgDkxuPyGUVha.getVideoInfoTag(),fvdTSjcImEOplzNKnJgDkxuPyGUVFt['saveinfo']['infoLabels'])
  if fvdTSjcImEOplzNKnJgDkxuPyGUVeb=='movie':
   fvdTSjcImEOplzNKnJgDkxuPyGUVha.setIsFolder(fvdTSjcImEOplzNKnJgDkxuPyGUVBA)
   fvdTSjcImEOplzNKnJgDkxuPyGUVha.setProperty('IsPlayable','true')
  else:
   fvdTSjcImEOplzNKnJgDkxuPyGUVha.setIsFolder(fvdTSjcImEOplzNKnJgDkxuPyGUVBa)
   fvdTSjcImEOplzNKnJgDkxuPyGUVha.setProperty('IsPlayable','false')
  fvdTSjcImEOplzNKnJgDkxuPyGUVba=xbmcgui.Dialog()
  fvdTSjcImEOplzNKnJgDkxuPyGUVba.info(fvdTSjcImEOplzNKnJgDkxuPyGUVha)
 def wavve_main(fvdTSjcImEOplzNKnJgDkxuPyGUVbo):
  fvdTSjcImEOplzNKnJgDkxuPyGUVbo.WavveObj.KodiVersion=fvdTSjcImEOplzNKnJgDkxuPyGUVBw(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  fvdTSjcImEOplzNKnJgDkxuPyGUVBF=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.main_params.get('params')
  if fvdTSjcImEOplzNKnJgDkxuPyGUVBF:
   fvdTSjcImEOplzNKnJgDkxuPyGUVBo =base64.standard_b64decode(fvdTSjcImEOplzNKnJgDkxuPyGUVBF).decode('utf-8')
   fvdTSjcImEOplzNKnJgDkxuPyGUVBo =json.loads(fvdTSjcImEOplzNKnJgDkxuPyGUVBo)
   fvdTSjcImEOplzNKnJgDkxuPyGUVXQ =fvdTSjcImEOplzNKnJgDkxuPyGUVBo.get('mode')
   fvdTSjcImEOplzNKnJgDkxuPyGUVBH =fvdTSjcImEOplzNKnJgDkxuPyGUVBo.get('values')
  else:
   fvdTSjcImEOplzNKnJgDkxuPyGUVXQ=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.main_params.get('mode',fvdTSjcImEOplzNKnJgDkxuPyGUVBC)
   fvdTSjcImEOplzNKnJgDkxuPyGUVBH=fvdTSjcImEOplzNKnJgDkxuPyGUVbo.main_params
  if fvdTSjcImEOplzNKnJgDkxuPyGUVXQ=='LOGOUT':
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.logout()
   return
  fvdTSjcImEOplzNKnJgDkxuPyGUVbo.login_main()
  if fvdTSjcImEOplzNKnJgDkxuPyGUVXQ is fvdTSjcImEOplzNKnJgDkxuPyGUVBC:
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.dp_Main_List()
  elif fvdTSjcImEOplzNKnJgDkxuPyGUVXQ in['LIVE','VOD','MOVIE','SPORTS']:
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.play_VIDEO(fvdTSjcImEOplzNKnJgDkxuPyGUVBH)
  elif fvdTSjcImEOplzNKnJgDkxuPyGUVXQ=='LIVE_CATAGORY':
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.dp_LiveCatagory_List(fvdTSjcImEOplzNKnJgDkxuPyGUVBH)
  elif fvdTSjcImEOplzNKnJgDkxuPyGUVXQ=='MAIN_CATAGORY':
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.dp_MainCatagory_List(fvdTSjcImEOplzNKnJgDkxuPyGUVBH)
  elif fvdTSjcImEOplzNKnJgDkxuPyGUVXQ=='SUPERSECTION_LIST':
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.dp_SuperSection_List(fvdTSjcImEOplzNKnJgDkxuPyGUVBH)
  elif fvdTSjcImEOplzNKnJgDkxuPyGUVXQ=='BANDLIVESECTION_LIST':
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.dp_BandLiveSection_List(fvdTSjcImEOplzNKnJgDkxuPyGUVBH)
  elif fvdTSjcImEOplzNKnJgDkxuPyGUVXQ=='BAND2SECTION_LIST':
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.dp_Band2Section_List(fvdTSjcImEOplzNKnJgDkxuPyGUVBH)
  elif fvdTSjcImEOplzNKnJgDkxuPyGUVXQ=='PROGRAM_LIST':
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.dp_Program_List(fvdTSjcImEOplzNKnJgDkxuPyGUVBH)
  elif fvdTSjcImEOplzNKnJgDkxuPyGUVXQ=='SEASON_LIST':
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.dp_Season_List(fvdTSjcImEOplzNKnJgDkxuPyGUVBH)
  elif fvdTSjcImEOplzNKnJgDkxuPyGUVXQ=='EPISODE_LIST':
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.dp_Episode_List(fvdTSjcImEOplzNKnJgDkxuPyGUVBH)
  elif fvdTSjcImEOplzNKnJgDkxuPyGUVXQ=='MOVIE_LIST':
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.dp_Movie_List(fvdTSjcImEOplzNKnJgDkxuPyGUVBH)
  elif fvdTSjcImEOplzNKnJgDkxuPyGUVXQ=='LIVE_LIST':
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.dp_LiveChannel_List(fvdTSjcImEOplzNKnJgDkxuPyGUVBH)
  elif fvdTSjcImEOplzNKnJgDkxuPyGUVXQ=='ORDER_BY':
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.dp_setEpOrderby(fvdTSjcImEOplzNKnJgDkxuPyGUVBH)
  elif fvdTSjcImEOplzNKnJgDkxuPyGUVXQ=='SEARCH_GROUP':
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.dp_Search_Group(fvdTSjcImEOplzNKnJgDkxuPyGUVBH)
  elif fvdTSjcImEOplzNKnJgDkxuPyGUVXQ in['SEARCH_LIST','LOCAL_SEARCH']:
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.dp_Search_List(fvdTSjcImEOplzNKnJgDkxuPyGUVBH)
  elif fvdTSjcImEOplzNKnJgDkxuPyGUVXQ=='WATCH_GROUP':
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.dp_Watch_Group(fvdTSjcImEOplzNKnJgDkxuPyGUVBH)
  elif fvdTSjcImEOplzNKnJgDkxuPyGUVXQ=='WATCH_LIST':
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.dp_Watch_List(fvdTSjcImEOplzNKnJgDkxuPyGUVBH)
  elif fvdTSjcImEOplzNKnJgDkxuPyGUVXQ=='SET_BOOKMARK':
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.dp_Set_Bookmark(fvdTSjcImEOplzNKnJgDkxuPyGUVBH)
  elif fvdTSjcImEOplzNKnJgDkxuPyGUVXQ in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.dp_History_Remove(fvdTSjcImEOplzNKnJgDkxuPyGUVBH)
  elif fvdTSjcImEOplzNKnJgDkxuPyGUVXQ in['TOTAL_SEARCH','TOTAL_HISTORY']:
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.dp_Global_Search(fvdTSjcImEOplzNKnJgDkxuPyGUVBH)
  elif fvdTSjcImEOplzNKnJgDkxuPyGUVXQ=='SEARCH_HISTORY':
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.dp_Search_History(fvdTSjcImEOplzNKnJgDkxuPyGUVBH)
  elif fvdTSjcImEOplzNKnJgDkxuPyGUVXQ=='MENU_BOOKMARK':
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.dp_Bookmark_Menu(fvdTSjcImEOplzNKnJgDkxuPyGUVBH)
  elif fvdTSjcImEOplzNKnJgDkxuPyGUVXQ=='GAME_LIST':
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.dp_Sports_GameList(fvdTSjcImEOplzNKnJgDkxuPyGUVBH)
  elif fvdTSjcImEOplzNKnJgDkxuPyGUVXQ=='VIEW_DETAIL':
   fvdTSjcImEOplzNKnJgDkxuPyGUVbo.dp_View_Detail(fvdTSjcImEOplzNKnJgDkxuPyGUVBH)
  else:
   fvdTSjcImEOplzNKnJgDkxuPyGUVBC
# Created by pyminifier (https://github.com/liftoff/pyminifier)
