__author__="NightRain"
YtLREoMBucmwQOKAnWfGDeIVxlFais=object
YtLREoMBucmwQOKAnWfGDeIVxlFaik=None
YtLREoMBucmwQOKAnWfGDeIVxlFaiU=False
YtLREoMBucmwQOKAnWfGDeIVxlFaiS=print
YtLREoMBucmwQOKAnWfGDeIVxlFaPv=str
YtLREoMBucmwQOKAnWfGDeIVxlFaPT=open
YtLREoMBucmwQOKAnWfGDeIVxlFaPg=True
YtLREoMBucmwQOKAnWfGDeIVxlFaPX=range
YtLREoMBucmwQOKAnWfGDeIVxlFaPq=len
YtLREoMBucmwQOKAnWfGDeIVxlFaPz=Exception
YtLREoMBucmwQOKAnWfGDeIVxlFaPi=dict
YtLREoMBucmwQOKAnWfGDeIVxlFaPC=int
import urllib
import re
import json
import sys
import requests
import datetime
import base64
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
YtLREoMBucmwQOKAnWfGDeIVxlFavg =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
class YtLREoMBucmwQOKAnWfGDeIVxlFavT(YtLREoMBucmwQOKAnWfGDeIVxlFais):
 def __init__(YtLREoMBucmwQOKAnWfGDeIVxlFavX):
  YtLREoMBucmwQOKAnWfGDeIVxlFavX.API_DOMAIN='https://apis.wavve.com'
  YtLREoMBucmwQOKAnWfGDeIVxlFavX.WV ={}
  YtLREoMBucmwQOKAnWfGDeIVxlFavX.Init_WV_Total()
  YtLREoMBucmwQOKAnWfGDeIVxlFavX.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  YtLREoMBucmwQOKAnWfGDeIVxlFavX.DEVICE ='pc'
  YtLREoMBucmwQOKAnWfGDeIVxlFavX.DRM ='wm'
  YtLREoMBucmwQOKAnWfGDeIVxlFavX.PARTNER ='pooq'
  YtLREoMBucmwQOKAnWfGDeIVxlFavX.POOQZONE ='none'
  YtLREoMBucmwQOKAnWfGDeIVxlFavX.REGION ='kor'
  YtLREoMBucmwQOKAnWfGDeIVxlFavX.TARGETAGE ='all'
  YtLREoMBucmwQOKAnWfGDeIVxlFavX.HTTPTAG ='https://'
  YtLREoMBucmwQOKAnWfGDeIVxlFavX.LIST_LIMIT=30 
  YtLREoMBucmwQOKAnWfGDeIVxlFavX.EP_LIMIT =30 
  YtLREoMBucmwQOKAnWfGDeIVxlFavX.MV_LIMIT =24 
  YtLREoMBucmwQOKAnWfGDeIVxlFavX.SEARCH_LIMIT=20 
  YtLREoMBucmwQOKAnWfGDeIVxlFavX.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36'
  YtLREoMBucmwQOKAnWfGDeIVxlFavX.DEFAULT_HEADER={'user-agent':YtLREoMBucmwQOKAnWfGDeIVxlFavX.USER_AGENT}
  YtLREoMBucmwQOKAnWfGDeIVxlFavX.KodiVersion=20
  YtLREoMBucmwQOKAnWfGDeIVxlFavX.WV_SESSION_COOKIES1=''
  YtLREoMBucmwQOKAnWfGDeIVxlFavX.WV_SESSION_COOKIES2=''
  YtLREoMBucmwQOKAnWfGDeIVxlFavX.COOKIE_FILE_NAME =''
  YtLREoMBucmwQOKAnWfGDeIVxlFavX.WV_STREAM_FILENAME =''
 def Init_WV_Total(YtLREoMBucmwQOKAnWfGDeIVxlFavX):
  YtLREoMBucmwQOKAnWfGDeIVxlFavX.WV={'account':{},'cookies':{},}
 def callRequestCookies(YtLREoMBucmwQOKAnWfGDeIVxlFavX,jobtype,YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,payload=YtLREoMBucmwQOKAnWfGDeIVxlFaik,params=YtLREoMBucmwQOKAnWfGDeIVxlFaik,headers=YtLREoMBucmwQOKAnWfGDeIVxlFaik,cookies=YtLREoMBucmwQOKAnWfGDeIVxlFaik,redirects=YtLREoMBucmwQOKAnWfGDeIVxlFaiU):
  YtLREoMBucmwQOKAnWfGDeIVxlFavq=YtLREoMBucmwQOKAnWfGDeIVxlFavX.DEFAULT_HEADER
  if headers:YtLREoMBucmwQOKAnWfGDeIVxlFavq.update(headers)
  if jobtype=='Get':
   YtLREoMBucmwQOKAnWfGDeIVxlFavz=requests.get(YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,params=params,headers=YtLREoMBucmwQOKAnWfGDeIVxlFavq,cookies=cookies,allow_redirects=redirects)
  else:
   YtLREoMBucmwQOKAnWfGDeIVxlFavz=requests.post(YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,json=payload,params=params,headers=YtLREoMBucmwQOKAnWfGDeIVxlFavq,cookies=cookies,allow_redirects=redirects)
  YtLREoMBucmwQOKAnWfGDeIVxlFaiS(YtLREoMBucmwQOKAnWfGDeIVxlFaPv(YtLREoMBucmwQOKAnWfGDeIVxlFavz.status_code)+' - '+YtLREoMBucmwQOKAnWfGDeIVxlFaPv(YtLREoMBucmwQOKAnWfGDeIVxlFavz.url))
  return YtLREoMBucmwQOKAnWfGDeIVxlFavz
 def JsonFile_Save(YtLREoMBucmwQOKAnWfGDeIVxlFavX,filename,YtLREoMBucmwQOKAnWfGDeIVxlFavi):
  if filename=='':return YtLREoMBucmwQOKAnWfGDeIVxlFaiU
  try:
   fp=YtLREoMBucmwQOKAnWfGDeIVxlFaPT(filename,'w',-1,'utf-8')
   json.dump(YtLREoMBucmwQOKAnWfGDeIVxlFavi,fp,indent=4,ensure_ascii=YtLREoMBucmwQOKAnWfGDeIVxlFaiU)
   fp.close()
  except:
   return YtLREoMBucmwQOKAnWfGDeIVxlFaiU
  return YtLREoMBucmwQOKAnWfGDeIVxlFaPg
 def JsonFile_Load(YtLREoMBucmwQOKAnWfGDeIVxlFavX,filename):
  if filename=='':return{}
  try:
   fp=YtLREoMBucmwQOKAnWfGDeIVxlFaPT(filename,'r',-1,'utf-8')
   YtLREoMBucmwQOKAnWfGDeIVxlFavC=json.load(fp)
   fp.close()
  except:
   return{}
  return YtLREoMBucmwQOKAnWfGDeIVxlFavC
 def TextFile_Save(YtLREoMBucmwQOKAnWfGDeIVxlFavX,filename,resText):
  if filename=='':return YtLREoMBucmwQOKAnWfGDeIVxlFaiU
  try:
   fp=YtLREoMBucmwQOKAnWfGDeIVxlFaPT(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return YtLREoMBucmwQOKAnWfGDeIVxlFaiU
  return YtLREoMBucmwQOKAnWfGDeIVxlFaPg
 def Save_session_acount(YtLREoMBucmwQOKAnWfGDeIVxlFavX,YtLREoMBucmwQOKAnWfGDeIVxlFavr,YtLREoMBucmwQOKAnWfGDeIVxlFavJ,YtLREoMBucmwQOKAnWfGDeIVxlFavd):
  YtLREoMBucmwQOKAnWfGDeIVxlFavX.WV['account']['wvid']=base64.standard_b64encode(YtLREoMBucmwQOKAnWfGDeIVxlFavr.encode()).decode('utf-8')
  YtLREoMBucmwQOKAnWfGDeIVxlFavX.WV['account']['wvpw']=base64.standard_b64encode(YtLREoMBucmwQOKAnWfGDeIVxlFavJ.encode()).decode('utf-8')
  YtLREoMBucmwQOKAnWfGDeIVxlFavX.WV['account']['wvpf']=YtLREoMBucmwQOKAnWfGDeIVxlFavd 
 def Load_session_acount(YtLREoMBucmwQOKAnWfGDeIVxlFavX):
  try:
   YtLREoMBucmwQOKAnWfGDeIVxlFavr=base64.standard_b64decode(YtLREoMBucmwQOKAnWfGDeIVxlFavX.WV['account']['wvid']).decode('utf-8')
   YtLREoMBucmwQOKAnWfGDeIVxlFavJ=base64.standard_b64decode(YtLREoMBucmwQOKAnWfGDeIVxlFavX.WV['account']['wvpw']).decode('utf-8')
   YtLREoMBucmwQOKAnWfGDeIVxlFavd=YtLREoMBucmwQOKAnWfGDeIVxlFavX.WV['account']['wvpf']
  except:
   return '','',0
  return YtLREoMBucmwQOKAnWfGDeIVxlFavr,YtLREoMBucmwQOKAnWfGDeIVxlFavJ,YtLREoMBucmwQOKAnWfGDeIVxlFavd
 def GetDefaultParams(YtLREoMBucmwQOKAnWfGDeIVxlFavX,login=YtLREoMBucmwQOKAnWfGDeIVxlFaPg):
  YtLREoMBucmwQOKAnWfGDeIVxlFavN={'apikey':YtLREoMBucmwQOKAnWfGDeIVxlFavX.APIKEY,'credential':YtLREoMBucmwQOKAnWfGDeIVxlFavX.WV['cookies']['credential']if login else 'none','device':YtLREoMBucmwQOKAnWfGDeIVxlFavX.DEVICE,'drm':YtLREoMBucmwQOKAnWfGDeIVxlFavX.DRM,'partner':YtLREoMBucmwQOKAnWfGDeIVxlFavX.PARTNER,'pooqzone':YtLREoMBucmwQOKAnWfGDeIVxlFavX.POOQZONE,'region':YtLREoMBucmwQOKAnWfGDeIVxlFavX.REGION,'targetage':YtLREoMBucmwQOKAnWfGDeIVxlFavX.TARGETAGE,'client_version':'6.0.1',}
  return YtLREoMBucmwQOKAnWfGDeIVxlFavN
 def GetDefaultParams_AND(YtLREoMBucmwQOKAnWfGDeIVxlFavX):
  YtLREoMBucmwQOKAnWfGDeIVxlFavN={'apikey':'6A87455D54481A536DFB8AD397C5EC4D','credential':YtLREoMBucmwQOKAnWfGDeIVxlFavX.WV['cookies']['credential'],'device':'ott','drm':YtLREoMBucmwQOKAnWfGDeIVxlFavX.DRM,'partner':YtLREoMBucmwQOKAnWfGDeIVxlFavX.PARTNER,'pooqzone':YtLREoMBucmwQOKAnWfGDeIVxlFavX.POOQZONE,'region':YtLREoMBucmwQOKAnWfGDeIVxlFavX.REGION,'targetage':YtLREoMBucmwQOKAnWfGDeIVxlFavX.TARGETAGE,}
  return YtLREoMBucmwQOKAnWfGDeIVxlFavN
 def GetGUID(YtLREoMBucmwQOKAnWfGDeIVxlFavX,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   YtLREoMBucmwQOKAnWfGDeIVxlFavh=YtLREoMBucmwQOKAnWfGDeIVxlFavX.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   YtLREoMBucmwQOKAnWfGDeIVxlFavy=GenerateRandomString(5)
   YtLREoMBucmwQOKAnWfGDeIVxlFavb=YtLREoMBucmwQOKAnWfGDeIVxlFavy+media+YtLREoMBucmwQOKAnWfGDeIVxlFavh
   return YtLREoMBucmwQOKAnWfGDeIVxlFavb
  def GenerateRandomString(num):
   from random import randint
   YtLREoMBucmwQOKAnWfGDeIVxlFavp=""
   for i in YtLREoMBucmwQOKAnWfGDeIVxlFaPX(0,num):
    s=YtLREoMBucmwQOKAnWfGDeIVxlFaPv(randint(1,5))
    YtLREoMBucmwQOKAnWfGDeIVxlFavp+=s
   return YtLREoMBucmwQOKAnWfGDeIVxlFavp
  if guidType==3:
   YtLREoMBucmwQOKAnWfGDeIVxlFavb=guid_str
  else:
   YtLREoMBucmwQOKAnWfGDeIVxlFavb=GenerateID(guid_str)
  YtLREoMBucmwQOKAnWfGDeIVxlFavH=YtLREoMBucmwQOKAnWfGDeIVxlFavX.GetHash(YtLREoMBucmwQOKAnWfGDeIVxlFavb)
  if guidType in[2,3]:
   YtLREoMBucmwQOKAnWfGDeIVxlFavH='%s-%s-%s-%s-%s'%(YtLREoMBucmwQOKAnWfGDeIVxlFavH[:8],YtLREoMBucmwQOKAnWfGDeIVxlFavH[8:12],YtLREoMBucmwQOKAnWfGDeIVxlFavH[12:16],YtLREoMBucmwQOKAnWfGDeIVxlFavH[16:20],YtLREoMBucmwQOKAnWfGDeIVxlFavH[20:])
  return YtLREoMBucmwQOKAnWfGDeIVxlFavH
 def GetHash(YtLREoMBucmwQOKAnWfGDeIVxlFavX,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return YtLREoMBucmwQOKAnWfGDeIVxlFaPv(m.hexdigest())
 def CheckQuality(YtLREoMBucmwQOKAnWfGDeIVxlFavX,sel_qt,qt_list):
  YtLREoMBucmwQOKAnWfGDeIVxlFavj=0
  for YtLREoMBucmwQOKAnWfGDeIVxlFavs in qt_list:
   if sel_qt>=YtLREoMBucmwQOKAnWfGDeIVxlFavs:return YtLREoMBucmwQOKAnWfGDeIVxlFavs
   YtLREoMBucmwQOKAnWfGDeIVxlFavj=YtLREoMBucmwQOKAnWfGDeIVxlFavs
  return YtLREoMBucmwQOKAnWfGDeIVxlFavj
 def Get_Now_Datetime(YtLREoMBucmwQOKAnWfGDeIVxlFavX):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(YtLREoMBucmwQOKAnWfGDeIVxlFavX,in_text):
  YtLREoMBucmwQOKAnWfGDeIVxlFavU=in_text.replace('&lt;','<').replace('&gt;','>')
  YtLREoMBucmwQOKAnWfGDeIVxlFavU=YtLREoMBucmwQOKAnWfGDeIVxlFavU.replace('<br>','\n')
  YtLREoMBucmwQOKAnWfGDeIVxlFavU=YtLREoMBucmwQOKAnWfGDeIVxlFavU.replace('$O$','')
  YtLREoMBucmwQOKAnWfGDeIVxlFavU=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',YtLREoMBucmwQOKAnWfGDeIVxlFavU)
  YtLREoMBucmwQOKAnWfGDeIVxlFavU=YtLREoMBucmwQOKAnWfGDeIVxlFavU.lstrip('#')
  return YtLREoMBucmwQOKAnWfGDeIVxlFavU
 def make_str_ToCookie(YtLREoMBucmwQOKAnWfGDeIVxlFavX,cookieStr):
  YtLREoMBucmwQOKAnWfGDeIVxlFavS={}
  for YtLREoMBucmwQOKAnWfGDeIVxlFaTv in cookieStr.split(';'):
   YtLREoMBucmwQOKAnWfGDeIVxlFaTg=YtLREoMBucmwQOKAnWfGDeIVxlFaTv.split('=')
   YtLREoMBucmwQOKAnWfGDeIVxlFavS[YtLREoMBucmwQOKAnWfGDeIVxlFaTg[0]]=YtLREoMBucmwQOKAnWfGDeIVxlFaTg[1]
  return YtLREoMBucmwQOKAnWfGDeIVxlFavS 
 def make_stream_header(YtLREoMBucmwQOKAnWfGDeIVxlFavX,YtLREoMBucmwQOKAnWfGDeIVxlFaTP,YtLREoMBucmwQOKAnWfGDeIVxlFavS):
  YtLREoMBucmwQOKAnWfGDeIVxlFaTX=''
  if YtLREoMBucmwQOKAnWfGDeIVxlFavS not in[{},YtLREoMBucmwQOKAnWfGDeIVxlFaik,'']:
   YtLREoMBucmwQOKAnWfGDeIVxlFaTq=YtLREoMBucmwQOKAnWfGDeIVxlFaPq(YtLREoMBucmwQOKAnWfGDeIVxlFavS)
   for YtLREoMBucmwQOKAnWfGDeIVxlFaTz,YtLREoMBucmwQOKAnWfGDeIVxlFaTi in YtLREoMBucmwQOKAnWfGDeIVxlFavS.items():
    YtLREoMBucmwQOKAnWfGDeIVxlFaTX+='{}={}'.format(YtLREoMBucmwQOKAnWfGDeIVxlFaTz,YtLREoMBucmwQOKAnWfGDeIVxlFaTi)
    YtLREoMBucmwQOKAnWfGDeIVxlFaTq+=-1
    if YtLREoMBucmwQOKAnWfGDeIVxlFaTq>0:YtLREoMBucmwQOKAnWfGDeIVxlFaTX+='; '
   YtLREoMBucmwQOKAnWfGDeIVxlFaTP['cookie']=YtLREoMBucmwQOKAnWfGDeIVxlFaTX
  YtLREoMBucmwQOKAnWfGDeIVxlFaTC=''
  i=0
  for YtLREoMBucmwQOKAnWfGDeIVxlFaTz,YtLREoMBucmwQOKAnWfGDeIVxlFaTi in YtLREoMBucmwQOKAnWfGDeIVxlFaTP.items():
   i=i+1
   if i>1:YtLREoMBucmwQOKAnWfGDeIVxlFaTC+='&'
   YtLREoMBucmwQOKAnWfGDeIVxlFaTC+='{}={}'.format(YtLREoMBucmwQOKAnWfGDeIVxlFaTz,urllib.parse.quote(YtLREoMBucmwQOKAnWfGDeIVxlFaTi))
  return YtLREoMBucmwQOKAnWfGDeIVxlFaTC
 def GetCredential(YtLREoMBucmwQOKAnWfGDeIVxlFavX,user_id,user_pw,user_pf):
  YtLREoMBucmwQOKAnWfGDeIVxlFaTr=YtLREoMBucmwQOKAnWfGDeIVxlFaiU
  try:
   YtLREoMBucmwQOKAnWfGDeIVxlFaTJ=YtLREoMBucmwQOKAnWfGDeIVxlFavX.API_DOMAIN+ '/login'
   YtLREoMBucmwQOKAnWfGDeIVxlFavN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.GetDefaultParams(login=YtLREoMBucmwQOKAnWfGDeIVxlFaiU)
   YtLREoMBucmwQOKAnWfGDeIVxlFaTd={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   YtLREoMBucmwQOKAnWfGDeIVxlFaTN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.callRequestCookies('Post',YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,payload=YtLREoMBucmwQOKAnWfGDeIVxlFaTd,params=YtLREoMBucmwQOKAnWfGDeIVxlFavN,headers=YtLREoMBucmwQOKAnWfGDeIVxlFaik,cookies=YtLREoMBucmwQOKAnWfGDeIVxlFaik)
   YtLREoMBucmwQOKAnWfGDeIVxlFaTh=json.loads(YtLREoMBucmwQOKAnWfGDeIVxlFaTN.text)
   YtLREoMBucmwQOKAnWfGDeIVxlFavX.WV['cookies']['credential']=YtLREoMBucmwQOKAnWfGDeIVxlFaTh['credential']
   if user_pf!=0:
    YtLREoMBucmwQOKAnWfGDeIVxlFaTd={'id':YtLREoMBucmwQOKAnWfGDeIVxlFavX.WV['cookies']['credential'],'password':'','profile':YtLREoMBucmwQOKAnWfGDeIVxlFaPv(user_pf),'pushid':'','type':'credential'}
    YtLREoMBucmwQOKAnWfGDeIVxlFavN =YtLREoMBucmwQOKAnWfGDeIVxlFavX.GetDefaultParams(login=YtLREoMBucmwQOKAnWfGDeIVxlFaPg) 
    YtLREoMBucmwQOKAnWfGDeIVxlFaTN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.callRequestCookies('Post',YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,payload=YtLREoMBucmwQOKAnWfGDeIVxlFaTd,params=YtLREoMBucmwQOKAnWfGDeIVxlFavN,headers=YtLREoMBucmwQOKAnWfGDeIVxlFaik,cookies=YtLREoMBucmwQOKAnWfGDeIVxlFaik)
    YtLREoMBucmwQOKAnWfGDeIVxlFaTh=json.loads(YtLREoMBucmwQOKAnWfGDeIVxlFaTN.text)
    YtLREoMBucmwQOKAnWfGDeIVxlFavX.WV['cookies']['credential']=YtLREoMBucmwQOKAnWfGDeIVxlFaTh['credential']
   YtLREoMBucmwQOKAnWfGDeIVxlFaTy=user_id+YtLREoMBucmwQOKAnWfGDeIVxlFaPv(user_pf) 
   YtLREoMBucmwQOKAnWfGDeIVxlFavX.WV['cookies']['uuid']=YtLREoMBucmwQOKAnWfGDeIVxlFavX.GetGUID(guid_str=YtLREoMBucmwQOKAnWfGDeIVxlFaTy,guidType=3)
   YtLREoMBucmwQOKAnWfGDeIVxlFaTr=YtLREoMBucmwQOKAnWfGDeIVxlFaPg
  except YtLREoMBucmwQOKAnWfGDeIVxlFaPz as exception:
   YtLREoMBucmwQOKAnWfGDeIVxlFaiS(exception)
   YtLREoMBucmwQOKAnWfGDeIVxlFavX.Init_WV_Total()
  return YtLREoMBucmwQOKAnWfGDeIVxlFaTr
 def GetIssue(YtLREoMBucmwQOKAnWfGDeIVxlFavX):
  YtLREoMBucmwQOKAnWfGDeIVxlFaTb=YtLREoMBucmwQOKAnWfGDeIVxlFaiU
  try:
   YtLREoMBucmwQOKAnWfGDeIVxlFaTJ=YtLREoMBucmwQOKAnWfGDeIVxlFavX.API_DOMAIN+'/guid/issue'
   YtLREoMBucmwQOKAnWfGDeIVxlFavN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.GetDefaultParams()
   YtLREoMBucmwQOKAnWfGDeIVxlFaTN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.callRequestCookies('Get',YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,payload=YtLREoMBucmwQOKAnWfGDeIVxlFaik,params=YtLREoMBucmwQOKAnWfGDeIVxlFavN,headers=YtLREoMBucmwQOKAnWfGDeIVxlFaik,cookies=YtLREoMBucmwQOKAnWfGDeIVxlFaik)
   YtLREoMBucmwQOKAnWfGDeIVxlFaTh=json.loads(YtLREoMBucmwQOKAnWfGDeIVxlFaTN.text)
   YtLREoMBucmwQOKAnWfGDeIVxlFaTp=YtLREoMBucmwQOKAnWfGDeIVxlFaTh['guid']
   YtLREoMBucmwQOKAnWfGDeIVxlFaTH=YtLREoMBucmwQOKAnWfGDeIVxlFaTh['guidtimestamp']
   if YtLREoMBucmwQOKAnWfGDeIVxlFaTp:YtLREoMBucmwQOKAnWfGDeIVxlFaTb=YtLREoMBucmwQOKAnWfGDeIVxlFaPg
  except YtLREoMBucmwQOKAnWfGDeIVxlFaPz as exception:
   YtLREoMBucmwQOKAnWfGDeIVxlFaiS(exception)
   YtLREoMBucmwQOKAnWfGDeIVxlFaTp='none'
   YtLREoMBucmwQOKAnWfGDeIVxlFaTH='none' 
  YtLREoMBucmwQOKAnWfGDeIVxlFavX.guid=YtLREoMBucmwQOKAnWfGDeIVxlFaTp
  YtLREoMBucmwQOKAnWfGDeIVxlFavX.guidtimestamp=YtLREoMBucmwQOKAnWfGDeIVxlFaTH
  return YtLREoMBucmwQOKAnWfGDeIVxlFaTb
 def Baseapi_Parse(YtLREoMBucmwQOKAnWfGDeIVxlFavX,YtLREoMBucmwQOKAnWfGDeIVxlFaTU):
  try:
   YtLREoMBucmwQOKAnWfGDeIVxlFaTj =urllib.parse.urlsplit(YtLREoMBucmwQOKAnWfGDeIVxlFaTU)
   if YtLREoMBucmwQOKAnWfGDeIVxlFaTj.netloc=='':
    YtLREoMBucmwQOKAnWfGDeIVxlFaTJ=YtLREoMBucmwQOKAnWfGDeIVxlFavX.HTTPTAG+YtLREoMBucmwQOKAnWfGDeIVxlFaTj.netloc+YtLREoMBucmwQOKAnWfGDeIVxlFaTj.path
   else:
    YtLREoMBucmwQOKAnWfGDeIVxlFaTJ=YtLREoMBucmwQOKAnWfGDeIVxlFaTj.scheme+'://'+YtLREoMBucmwQOKAnWfGDeIVxlFaTj.netloc+YtLREoMBucmwQOKAnWfGDeIVxlFaTj.path
   YtLREoMBucmwQOKAnWfGDeIVxlFavN=YtLREoMBucmwQOKAnWfGDeIVxlFaPi(urllib.parse.parse_qsl(YtLREoMBucmwQOKAnWfGDeIVxlFaTj.query))
  except YtLREoMBucmwQOKAnWfGDeIVxlFaPz as exception:
   YtLREoMBucmwQOKAnWfGDeIVxlFaiS(exception)
   return '',{}
  return YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,YtLREoMBucmwQOKAnWfGDeIVxlFavN
 def GetSupermultiUrl(YtLREoMBucmwQOKAnWfGDeIVxlFavX,sCode,sIndex='0'):
  try:
   YtLREoMBucmwQOKAnWfGDeIVxlFaTJ=YtLREoMBucmwQOKAnWfGDeIVxlFavX.API_DOMAIN+'/cf/supermultisections/'+sCode
   YtLREoMBucmwQOKAnWfGDeIVxlFavN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.GetDefaultParams(login=YtLREoMBucmwQOKAnWfGDeIVxlFaiU)
   YtLREoMBucmwQOKAnWfGDeIVxlFaTN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.callRequestCookies('Get',YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,payload=YtLREoMBucmwQOKAnWfGDeIVxlFaik,params=YtLREoMBucmwQOKAnWfGDeIVxlFavN,headers=YtLREoMBucmwQOKAnWfGDeIVxlFaik,cookies=YtLREoMBucmwQOKAnWfGDeIVxlFaik)
   YtLREoMBucmwQOKAnWfGDeIVxlFaTh=json.loads(YtLREoMBucmwQOKAnWfGDeIVxlFaTN.text)
   YtLREoMBucmwQOKAnWfGDeIVxlFaTs=YtLREoMBucmwQOKAnWfGDeIVxlFaTh['multisectionlist'][YtLREoMBucmwQOKAnWfGDeIVxlFaPC(sIndex)]['eventlist'][1]['url']
  except YtLREoMBucmwQOKAnWfGDeIVxlFaPz as exception:
   YtLREoMBucmwQOKAnWfGDeIVxlFaiS(exception)
   return ''
  return YtLREoMBucmwQOKAnWfGDeIVxlFaTs
 def Get_LiveCatagory_List(YtLREoMBucmwQOKAnWfGDeIVxlFavX,sCode,sIndex='0'):
  YtLREoMBucmwQOKAnWfGDeIVxlFaTk=[]
  YtLREoMBucmwQOKAnWfGDeIVxlFaTU =YtLREoMBucmwQOKAnWfGDeIVxlFavX.GetSupermultiUrl(sCode,sIndex)
  (YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,YtLREoMBucmwQOKAnWfGDeIVxlFavN)=YtLREoMBucmwQOKAnWfGDeIVxlFavX.Baseapi_Parse(YtLREoMBucmwQOKAnWfGDeIVxlFaTU)
  if YtLREoMBucmwQOKAnWfGDeIVxlFaTJ=='':return YtLREoMBucmwQOKAnWfGDeIVxlFaTk,''
  try:
   YtLREoMBucmwQOKAnWfGDeIVxlFavN.update(YtLREoMBucmwQOKAnWfGDeIVxlFavX.GetDefaultParams(login=YtLREoMBucmwQOKAnWfGDeIVxlFaiU))
   YtLREoMBucmwQOKAnWfGDeIVxlFaTN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.callRequestCookies('Get',YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,payload=YtLREoMBucmwQOKAnWfGDeIVxlFaik,params=YtLREoMBucmwQOKAnWfGDeIVxlFavN,headers=YtLREoMBucmwQOKAnWfGDeIVxlFaik,cookies=YtLREoMBucmwQOKAnWfGDeIVxlFaik)
   YtLREoMBucmwQOKAnWfGDeIVxlFaTh=json.loads(YtLREoMBucmwQOKAnWfGDeIVxlFaTN.text)
   if not('filter_item_list' in YtLREoMBucmwQOKAnWfGDeIVxlFaTh['filter']['filterlist'][0]):return[],''
   YtLREoMBucmwQOKAnWfGDeIVxlFagv=YtLREoMBucmwQOKAnWfGDeIVxlFaTh['filter']['filterlist'][0]['filter_item_list']
   for YtLREoMBucmwQOKAnWfGDeIVxlFagT in YtLREoMBucmwQOKAnWfGDeIVxlFagv:
    YtLREoMBucmwQOKAnWfGDeIVxlFagX={'title':YtLREoMBucmwQOKAnWfGDeIVxlFagT['title'],'genre':YtLREoMBucmwQOKAnWfGDeIVxlFagT['api_parameters'][YtLREoMBucmwQOKAnWfGDeIVxlFagT['api_parameters'].index('=')+1:]}
    YtLREoMBucmwQOKAnWfGDeIVxlFaTk.append(YtLREoMBucmwQOKAnWfGDeIVxlFagX)
  except YtLREoMBucmwQOKAnWfGDeIVxlFaPz as exception:
   YtLREoMBucmwQOKAnWfGDeIVxlFaiS(exception)
   return[],''
  return YtLREoMBucmwQOKAnWfGDeIVxlFaTk,YtLREoMBucmwQOKAnWfGDeIVxlFaTU
 def Get_MainCatagory_List(YtLREoMBucmwQOKAnWfGDeIVxlFavX,sCode,sIndex,sType):
  YtLREoMBucmwQOKAnWfGDeIVxlFaTk=[]
  YtLREoMBucmwQOKAnWfGDeIVxlFaTJ='https://apis.wavve.com/es/category/launcher-band'
  YtLREoMBucmwQOKAnWfGDeIVxlFavN={'uitype':sCode,'uiparent':'GN52-'+sCode,'uirank':sIndex,'broadcastid':sCode,'offset':'0','limit':'20','uicode':sCode,'mtype':'N','ctype':sType,'orderby':'default',}
  try:
   YtLREoMBucmwQOKAnWfGDeIVxlFavN.update(YtLREoMBucmwQOKAnWfGDeIVxlFavX.GetDefaultParams(login=YtLREoMBucmwQOKAnWfGDeIVxlFaiU))
   YtLREoMBucmwQOKAnWfGDeIVxlFaTN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.callRequestCookies('Get',YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,payload=YtLREoMBucmwQOKAnWfGDeIVxlFaik,params=YtLREoMBucmwQOKAnWfGDeIVxlFavN,headers=YtLREoMBucmwQOKAnWfGDeIVxlFaik,cookies=YtLREoMBucmwQOKAnWfGDeIVxlFaik)
   YtLREoMBucmwQOKAnWfGDeIVxlFaTh=json.loads(YtLREoMBucmwQOKAnWfGDeIVxlFaTN.text)
   if not('celllist' in YtLREoMBucmwQOKAnWfGDeIVxlFaTh['band']):return[]
   YtLREoMBucmwQOKAnWfGDeIVxlFagv=YtLREoMBucmwQOKAnWfGDeIVxlFaTh['band']['celllist']
   for YtLREoMBucmwQOKAnWfGDeIVxlFagT in YtLREoMBucmwQOKAnWfGDeIVxlFagv:
    YtLREoMBucmwQOKAnWfGDeIVxlFagq =YtLREoMBucmwQOKAnWfGDeIVxlFagT['event_list'][1]['url']
    (YtLREoMBucmwQOKAnWfGDeIVxlFagz,YtLREoMBucmwQOKAnWfGDeIVxlFagi)=YtLREoMBucmwQOKAnWfGDeIVxlFavX.Baseapi_Parse(YtLREoMBucmwQOKAnWfGDeIVxlFagq)
    YtLREoMBucmwQOKAnWfGDeIVxlFagX={'title':YtLREoMBucmwQOKAnWfGDeIVxlFagT['title_list'][0]['text'],'suburl':YtLREoMBucmwQOKAnWfGDeIVxlFagz,'subapi':YtLREoMBucmwQOKAnWfGDeIVxlFagi.get('api'),'subtype':'catagory' if YtLREoMBucmwQOKAnWfGDeIVxlFagi else 'supersection'}
    YtLREoMBucmwQOKAnWfGDeIVxlFaTk.append(YtLREoMBucmwQOKAnWfGDeIVxlFagX)
  except YtLREoMBucmwQOKAnWfGDeIVxlFaPz as exception:
   YtLREoMBucmwQOKAnWfGDeIVxlFaiS(exception)
   return[]
  return YtLREoMBucmwQOKAnWfGDeIVxlFaTk
 def Get_SuperMultiSection_List(YtLREoMBucmwQOKAnWfGDeIVxlFavX,subapi_text):
  YtLREoMBucmwQOKAnWfGDeIVxlFaTk=[]
  if '/multiband/' in subapi_text: 
   YtLREoMBucmwQOKAnWfGDeIVxlFaTJ=subapi_text 
   YtLREoMBucmwQOKAnWfGDeIVxlFavN={'client':'40'}
  else:
   YtLREoMBucmwQOKAnWfGDeIVxlFaTJ=subapi_text 
   YtLREoMBucmwQOKAnWfGDeIVxlFaTJ=YtLREoMBucmwQOKAnWfGDeIVxlFaTJ.replace('www.wavve.com','apis.wavve.com').replace('supermultisection','v1/multiband')
   YtLREoMBucmwQOKAnWfGDeIVxlFavN={}
  try:
   YtLREoMBucmwQOKAnWfGDeIVxlFavN.update(YtLREoMBucmwQOKAnWfGDeIVxlFavX.GetDefaultParams(login=YtLREoMBucmwQOKAnWfGDeIVxlFaiU))
   YtLREoMBucmwQOKAnWfGDeIVxlFaTN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.callRequestCookies('Get',YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,payload=YtLREoMBucmwQOKAnWfGDeIVxlFaik,params=YtLREoMBucmwQOKAnWfGDeIVxlFavN,headers=YtLREoMBucmwQOKAnWfGDeIVxlFaik,cookies=YtLREoMBucmwQOKAnWfGDeIVxlFaik)
   YtLREoMBucmwQOKAnWfGDeIVxlFaTh=json.loads(YtLREoMBucmwQOKAnWfGDeIVxlFaTN.text)
   if not('multisectionlist' in YtLREoMBucmwQOKAnWfGDeIVxlFaTh):return[]
   YtLREoMBucmwQOKAnWfGDeIVxlFagv=YtLREoMBucmwQOKAnWfGDeIVxlFaTh['multisectionlist']
   for YtLREoMBucmwQOKAnWfGDeIVxlFagT in YtLREoMBucmwQOKAnWfGDeIVxlFagv:
    YtLREoMBucmwQOKAnWfGDeIVxlFagP=YtLREoMBucmwQOKAnWfGDeIVxlFagT['title']
    if YtLREoMBucmwQOKAnWfGDeIVxlFaPq(YtLREoMBucmwQOKAnWfGDeIVxlFagP)==0:continue
    if YtLREoMBucmwQOKAnWfGDeIVxlFagP=='minor':continue
    if re.search(u'베너',YtLREoMBucmwQOKAnWfGDeIVxlFagP):continue
    if re.search(u'배너',YtLREoMBucmwQOKAnWfGDeIVxlFagP):continue 
    if YtLREoMBucmwQOKAnWfGDeIVxlFagT['force_refresh']=='y':continue
    if YtLREoMBucmwQOKAnWfGDeIVxlFaPq(YtLREoMBucmwQOKAnWfGDeIVxlFagT['eventlist'])>=3:
     YtLREoMBucmwQOKAnWfGDeIVxlFagi =YtLREoMBucmwQOKAnWfGDeIVxlFagT['eventlist'][2]['url']
    else:
     YtLREoMBucmwQOKAnWfGDeIVxlFagi =YtLREoMBucmwQOKAnWfGDeIVxlFagT['eventlist'][1]['url']
    YtLREoMBucmwQOKAnWfGDeIVxlFagC=YtLREoMBucmwQOKAnWfGDeIVxlFagT['cell_type']
    if YtLREoMBucmwQOKAnWfGDeIVxlFagC=='band_2':
     if YtLREoMBucmwQOKAnWfGDeIVxlFagi.find('channellist=')>=0:
      YtLREoMBucmwQOKAnWfGDeIVxlFagC='band_live'
    YtLREoMBucmwQOKAnWfGDeIVxlFagX={'title':YtLREoMBucmwQOKAnWfGDeIVxlFavX.Get_ChangeText(YtLREoMBucmwQOKAnWfGDeIVxlFagP),'subapi':YtLREoMBucmwQOKAnWfGDeIVxlFagi,'cell_type':YtLREoMBucmwQOKAnWfGDeIVxlFagC}
    YtLREoMBucmwQOKAnWfGDeIVxlFaTk.append(YtLREoMBucmwQOKAnWfGDeIVxlFagX)
  except YtLREoMBucmwQOKAnWfGDeIVxlFaPz as exception:
   YtLREoMBucmwQOKAnWfGDeIVxlFaiS(exception)
   return[]
  return YtLREoMBucmwQOKAnWfGDeIVxlFaTk
 def Get_BandLiveSection_List(YtLREoMBucmwQOKAnWfGDeIVxlFavX,YtLREoMBucmwQOKAnWfGDeIVxlFaTU,page_int=1):
  YtLREoMBucmwQOKAnWfGDeIVxlFagr=[]
  YtLREoMBucmwQOKAnWfGDeIVxlFagJ=YtLREoMBucmwQOKAnWfGDeIVxlFagp=1
  YtLREoMBucmwQOKAnWfGDeIVxlFagd=YtLREoMBucmwQOKAnWfGDeIVxlFaiU
  try:
   (YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,YtLREoMBucmwQOKAnWfGDeIVxlFavN)=YtLREoMBucmwQOKAnWfGDeIVxlFavX.Baseapi_Parse(YtLREoMBucmwQOKAnWfGDeIVxlFaTU)
  except YtLREoMBucmwQOKAnWfGDeIVxlFaPz as exception:
   YtLREoMBucmwQOKAnWfGDeIVxlFaiS(exception)
   return[],YtLREoMBucmwQOKAnWfGDeIVxlFaiU
  try:
   YtLREoMBucmwQOKAnWfGDeIVxlFavN['limit']=YtLREoMBucmwQOKAnWfGDeIVxlFavX.LIST_LIMIT
   YtLREoMBucmwQOKAnWfGDeIVxlFavN['offset']=YtLREoMBucmwQOKAnWfGDeIVxlFaPv((page_int-1)*YtLREoMBucmwQOKAnWfGDeIVxlFavX.LIST_LIMIT)
   YtLREoMBucmwQOKAnWfGDeIVxlFavN.update(YtLREoMBucmwQOKAnWfGDeIVxlFavX.GetDefaultParams(login=YtLREoMBucmwQOKAnWfGDeIVxlFaiU))
   YtLREoMBucmwQOKAnWfGDeIVxlFaTN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.callRequestCookies('Get',YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,payload=YtLREoMBucmwQOKAnWfGDeIVxlFaik,params=YtLREoMBucmwQOKAnWfGDeIVxlFavN,headers=YtLREoMBucmwQOKAnWfGDeIVxlFaik,cookies=YtLREoMBucmwQOKAnWfGDeIVxlFaik)
   YtLREoMBucmwQOKAnWfGDeIVxlFaTh=json.loads(YtLREoMBucmwQOKAnWfGDeIVxlFaTN.text)
   if not('celllist' in YtLREoMBucmwQOKAnWfGDeIVxlFaTh['cell_toplist']):return[],YtLREoMBucmwQOKAnWfGDeIVxlFaiU
   YtLREoMBucmwQOKAnWfGDeIVxlFagv=YtLREoMBucmwQOKAnWfGDeIVxlFaTh['cell_toplist']['celllist']
   for YtLREoMBucmwQOKAnWfGDeIVxlFagT in YtLREoMBucmwQOKAnWfGDeIVxlFagv:
    YtLREoMBucmwQOKAnWfGDeIVxlFagN =YtLREoMBucmwQOKAnWfGDeIVxlFagT['event_list'][1]['url']
    YtLREoMBucmwQOKAnWfGDeIVxlFagh=urllib.parse.urlsplit(YtLREoMBucmwQOKAnWfGDeIVxlFagN).query
    YtLREoMBucmwQOKAnWfGDeIVxlFagh=YtLREoMBucmwQOKAnWfGDeIVxlFaPi(urllib.parse.parse_qsl(YtLREoMBucmwQOKAnWfGDeIVxlFagh))
    YtLREoMBucmwQOKAnWfGDeIVxlFagy='channelid'
    YtLREoMBucmwQOKAnWfGDeIVxlFagb=YtLREoMBucmwQOKAnWfGDeIVxlFagh[YtLREoMBucmwQOKAnWfGDeIVxlFagy]
    YtLREoMBucmwQOKAnWfGDeIVxlFagX={'studio':YtLREoMBucmwQOKAnWfGDeIVxlFagT['title_list'][0]['text'],'tvshowtitle':YtLREoMBucmwQOKAnWfGDeIVxlFavX.Get_ChangeText(YtLREoMBucmwQOKAnWfGDeIVxlFagT['title_list'][1]['text']),'channelid':YtLREoMBucmwQOKAnWfGDeIVxlFagb,'age':YtLREoMBucmwQOKAnWfGDeIVxlFagT.get('age'),'thumbnail':'https://%s'%YtLREoMBucmwQOKAnWfGDeIVxlFagT.get('thumbnail')}
    YtLREoMBucmwQOKAnWfGDeIVxlFagr.append(YtLREoMBucmwQOKAnWfGDeIVxlFagX)
   YtLREoMBucmwQOKAnWfGDeIVxlFagJ=YtLREoMBucmwQOKAnWfGDeIVxlFaPC(YtLREoMBucmwQOKAnWfGDeIVxlFaTh['cell_toplist']['pagecount'])
   if YtLREoMBucmwQOKAnWfGDeIVxlFaTh['cell_toplist']['count']:YtLREoMBucmwQOKAnWfGDeIVxlFagp =YtLREoMBucmwQOKAnWfGDeIVxlFaPC(YtLREoMBucmwQOKAnWfGDeIVxlFaTh['cell_toplist']['count'])
   else:YtLREoMBucmwQOKAnWfGDeIVxlFagp=YtLREoMBucmwQOKAnWfGDeIVxlFavX.LIST_LIMIT*page_int
   YtLREoMBucmwQOKAnWfGDeIVxlFagd=YtLREoMBucmwQOKAnWfGDeIVxlFagJ>YtLREoMBucmwQOKAnWfGDeIVxlFagp
  except YtLREoMBucmwQOKAnWfGDeIVxlFaPz as exception:
   YtLREoMBucmwQOKAnWfGDeIVxlFaiS(exception)
   return[],YtLREoMBucmwQOKAnWfGDeIVxlFaiU
  return YtLREoMBucmwQOKAnWfGDeIVxlFagr,YtLREoMBucmwQOKAnWfGDeIVxlFagd
 def Get_Band2Section_List(YtLREoMBucmwQOKAnWfGDeIVxlFavX,YtLREoMBucmwQOKAnWfGDeIVxlFaTU,page_int=1):
  YtLREoMBucmwQOKAnWfGDeIVxlFagH=[]
  YtLREoMBucmwQOKAnWfGDeIVxlFagJ=YtLREoMBucmwQOKAnWfGDeIVxlFagp=1
  YtLREoMBucmwQOKAnWfGDeIVxlFagd=YtLREoMBucmwQOKAnWfGDeIVxlFaiU
  try:
   (YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,YtLREoMBucmwQOKAnWfGDeIVxlFavN)=YtLREoMBucmwQOKAnWfGDeIVxlFavX.Baseapi_Parse(YtLREoMBucmwQOKAnWfGDeIVxlFaTU)
  except YtLREoMBucmwQOKAnWfGDeIVxlFaPz as exception:
   YtLREoMBucmwQOKAnWfGDeIVxlFaiS(exception)
   return[],YtLREoMBucmwQOKAnWfGDeIVxlFaiU
  try:
   YtLREoMBucmwQOKAnWfGDeIVxlFavN['came'] ='BandView'
   YtLREoMBucmwQOKAnWfGDeIVxlFavN['limit']=YtLREoMBucmwQOKAnWfGDeIVxlFavX.LIST_LIMIT
   YtLREoMBucmwQOKAnWfGDeIVxlFavN['offset']=YtLREoMBucmwQOKAnWfGDeIVxlFaPv((page_int-1)*YtLREoMBucmwQOKAnWfGDeIVxlFavX.LIST_LIMIT)
   YtLREoMBucmwQOKAnWfGDeIVxlFavN.update(YtLREoMBucmwQOKAnWfGDeIVxlFavX.GetDefaultParams(login=YtLREoMBucmwQOKAnWfGDeIVxlFaiU))
   YtLREoMBucmwQOKAnWfGDeIVxlFaTN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.callRequestCookies('Get',YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,payload=YtLREoMBucmwQOKAnWfGDeIVxlFaik,params=YtLREoMBucmwQOKAnWfGDeIVxlFavN,headers=YtLREoMBucmwQOKAnWfGDeIVxlFaik,cookies=YtLREoMBucmwQOKAnWfGDeIVxlFaik)
   YtLREoMBucmwQOKAnWfGDeIVxlFaTh=json.loads(YtLREoMBucmwQOKAnWfGDeIVxlFaTN.text)
   if not('celllist' in YtLREoMBucmwQOKAnWfGDeIVxlFaTh['cell_toplist']):return[],YtLREoMBucmwQOKAnWfGDeIVxlFaiU
   YtLREoMBucmwQOKAnWfGDeIVxlFagv=YtLREoMBucmwQOKAnWfGDeIVxlFaTh['cell_toplist']['celllist']
   for YtLREoMBucmwQOKAnWfGDeIVxlFagT in YtLREoMBucmwQOKAnWfGDeIVxlFagv:
    YtLREoMBucmwQOKAnWfGDeIVxlFagN =YtLREoMBucmwQOKAnWfGDeIVxlFagT['event_list'][1]['url']
    YtLREoMBucmwQOKAnWfGDeIVxlFagh=urllib.parse.urlsplit(YtLREoMBucmwQOKAnWfGDeIVxlFagN).query
    YtLREoMBucmwQOKAnWfGDeIVxlFagh=YtLREoMBucmwQOKAnWfGDeIVxlFaPi(urllib.parse.parse_qsl(YtLREoMBucmwQOKAnWfGDeIVxlFagh))
    YtLREoMBucmwQOKAnWfGDeIVxlFagy='contentid'
    YtLREoMBucmwQOKAnWfGDeIVxlFagb=YtLREoMBucmwQOKAnWfGDeIVxlFagh[YtLREoMBucmwQOKAnWfGDeIVxlFagy]
    YtLREoMBucmwQOKAnWfGDeIVxlFagX={'programtitle':YtLREoMBucmwQOKAnWfGDeIVxlFagT['title_list'][0]['text'],'episodetitle':YtLREoMBucmwQOKAnWfGDeIVxlFavX.Get_ChangeText(YtLREoMBucmwQOKAnWfGDeIVxlFagT['title_list'][1]['text']),'age':YtLREoMBucmwQOKAnWfGDeIVxlFagT.get('age'),'thumbnail':YtLREoMBucmwQOKAnWfGDeIVxlFavX.HTTPTAG+YtLREoMBucmwQOKAnWfGDeIVxlFagT.get('thumbnail'),'vidtype':YtLREoMBucmwQOKAnWfGDeIVxlFagy,'videoid':YtLREoMBucmwQOKAnWfGDeIVxlFagb}
    YtLREoMBucmwQOKAnWfGDeIVxlFagH.append(YtLREoMBucmwQOKAnWfGDeIVxlFagX)
   YtLREoMBucmwQOKAnWfGDeIVxlFagJ=YtLREoMBucmwQOKAnWfGDeIVxlFaPC(YtLREoMBucmwQOKAnWfGDeIVxlFaTh['cell_toplist']['pagecount'])
   if YtLREoMBucmwQOKAnWfGDeIVxlFaTh['cell_toplist']['count']:YtLREoMBucmwQOKAnWfGDeIVxlFagp =YtLREoMBucmwQOKAnWfGDeIVxlFaPC(YtLREoMBucmwQOKAnWfGDeIVxlFaTh['cell_toplist']['count'])
   else:YtLREoMBucmwQOKAnWfGDeIVxlFagp=YtLREoMBucmwQOKAnWfGDeIVxlFavX.LIST_LIMIT*page_int
   YtLREoMBucmwQOKAnWfGDeIVxlFagd=YtLREoMBucmwQOKAnWfGDeIVxlFagJ>YtLREoMBucmwQOKAnWfGDeIVxlFagp
  except YtLREoMBucmwQOKAnWfGDeIVxlFaPz as exception:
   YtLREoMBucmwQOKAnWfGDeIVxlFaiS(exception)
   return[],YtLREoMBucmwQOKAnWfGDeIVxlFaiU
  return YtLREoMBucmwQOKAnWfGDeIVxlFagH,YtLREoMBucmwQOKAnWfGDeIVxlFagd
 def Get_Program_List(YtLREoMBucmwQOKAnWfGDeIVxlFavX,YtLREoMBucmwQOKAnWfGDeIVxlFaTU,page_int=1,orderby='-'):
  YtLREoMBucmwQOKAnWfGDeIVxlFagj=[]
  YtLREoMBucmwQOKAnWfGDeIVxlFagJ=YtLREoMBucmwQOKAnWfGDeIVxlFagp=1
  YtLREoMBucmwQOKAnWfGDeIVxlFagd=YtLREoMBucmwQOKAnWfGDeIVxlFaiU
  (YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,YtLREoMBucmwQOKAnWfGDeIVxlFavN)=YtLREoMBucmwQOKAnWfGDeIVxlFavX.Baseapi_Parse(YtLREoMBucmwQOKAnWfGDeIVxlFaTU)
  if YtLREoMBucmwQOKAnWfGDeIVxlFaTJ=='':return YtLREoMBucmwQOKAnWfGDeIVxlFagj,YtLREoMBucmwQOKAnWfGDeIVxlFagd
  try:
   YtLREoMBucmwQOKAnWfGDeIVxlFavN['limit'] =YtLREoMBucmwQOKAnWfGDeIVxlFavX.LIST_LIMIT
   YtLREoMBucmwQOKAnWfGDeIVxlFavN['offset']=YtLREoMBucmwQOKAnWfGDeIVxlFaPv((page_int-1)*YtLREoMBucmwQOKAnWfGDeIVxlFavX.LIST_LIMIT)
   YtLREoMBucmwQOKAnWfGDeIVxlFavN['page'] =YtLREoMBucmwQOKAnWfGDeIVxlFaPv(page_int)
   if YtLREoMBucmwQOKAnWfGDeIVxlFavN.get('orderby')!='' and YtLREoMBucmwQOKAnWfGDeIVxlFavN.get('orderby')!='regdatefirst' and orderby!='-':
    YtLREoMBucmwQOKAnWfGDeIVxlFavN['orderby']=orderby 
   YtLREoMBucmwQOKAnWfGDeIVxlFavN.update(YtLREoMBucmwQOKAnWfGDeIVxlFavX.GetDefaultParams(login=YtLREoMBucmwQOKAnWfGDeIVxlFaiU))
   YtLREoMBucmwQOKAnWfGDeIVxlFaTN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.callRequestCookies('Get',YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,payload=YtLREoMBucmwQOKAnWfGDeIVxlFaik,params=YtLREoMBucmwQOKAnWfGDeIVxlFavN,headers=YtLREoMBucmwQOKAnWfGDeIVxlFaik,cookies=YtLREoMBucmwQOKAnWfGDeIVxlFaik)
   YtLREoMBucmwQOKAnWfGDeIVxlFaTh=json.loads(YtLREoMBucmwQOKAnWfGDeIVxlFaTN.text)
   if YtLREoMBucmwQOKAnWfGDeIVxlFaTh.get('cell_toplist')not in[{},YtLREoMBucmwQOKAnWfGDeIVxlFaik,'']:
    YtLREoMBucmwQOKAnWfGDeIVxlFagv=YtLREoMBucmwQOKAnWfGDeIVxlFaTh['cell_toplist']['celllist']
   elif YtLREoMBucmwQOKAnWfGDeIVxlFaTh.get('band')not in[{},YtLREoMBucmwQOKAnWfGDeIVxlFaik,'']:
    YtLREoMBucmwQOKAnWfGDeIVxlFagv=YtLREoMBucmwQOKAnWfGDeIVxlFaTh['band']['celllist']
   else:
    return YtLREoMBucmwQOKAnWfGDeIVxlFagj,YtLREoMBucmwQOKAnWfGDeIVxlFagd
   for YtLREoMBucmwQOKAnWfGDeIVxlFagT in YtLREoMBucmwQOKAnWfGDeIVxlFagv:
    for YtLREoMBucmwQOKAnWfGDeIVxlFags in YtLREoMBucmwQOKAnWfGDeIVxlFagT['event_list']:
     if YtLREoMBucmwQOKAnWfGDeIVxlFags.get('type')=='on-navigation':
      YtLREoMBucmwQOKAnWfGDeIVxlFagN =YtLREoMBucmwQOKAnWfGDeIVxlFags['url']
    YtLREoMBucmwQOKAnWfGDeIVxlFagh=urllib.parse.urlsplit(YtLREoMBucmwQOKAnWfGDeIVxlFagN).query
    YtLREoMBucmwQOKAnWfGDeIVxlFagy=YtLREoMBucmwQOKAnWfGDeIVxlFagh[0:YtLREoMBucmwQOKAnWfGDeIVxlFagh.find('=')]
    YtLREoMBucmwQOKAnWfGDeIVxlFagk=YtLREoMBucmwQOKAnWfGDeIVxlFaPi(urllib.parse.parse_qsl(YtLREoMBucmwQOKAnWfGDeIVxlFagh))
    YtLREoMBucmwQOKAnWfGDeIVxlFagb=YtLREoMBucmwQOKAnWfGDeIVxlFagk.get(YtLREoMBucmwQOKAnWfGDeIVxlFagy)
    YtLREoMBucmwQOKAnWfGDeIVxlFagX={'title':YtLREoMBucmwQOKAnWfGDeIVxlFagT.get('alt')or YtLREoMBucmwQOKAnWfGDeIVxlFagT.get('title_list')[0].get('text'),'age':YtLREoMBucmwQOKAnWfGDeIVxlFagT.get('age'),'thumbnail':YtLREoMBucmwQOKAnWfGDeIVxlFagT.get('thumbnail'),'videoid':YtLREoMBucmwQOKAnWfGDeIVxlFagb,'vidtype':YtLREoMBucmwQOKAnWfGDeIVxlFagy,}
    if not YtLREoMBucmwQOKAnWfGDeIVxlFagX.get('thumbnail').startswith('http'):
     YtLREoMBucmwQOKAnWfGDeIVxlFagX['thumbnail']='https://%s'%YtLREoMBucmwQOKAnWfGDeIVxlFagX['thumbnail']
    YtLREoMBucmwQOKAnWfGDeIVxlFagj.append(YtLREoMBucmwQOKAnWfGDeIVxlFagX)
   if YtLREoMBucmwQOKAnWfGDeIVxlFaTh.get('cell_toplist')not in[{},YtLREoMBucmwQOKAnWfGDeIVxlFaik,'']:
    YtLREoMBucmwQOKAnWfGDeIVxlFagJ=YtLREoMBucmwQOKAnWfGDeIVxlFaPC(YtLREoMBucmwQOKAnWfGDeIVxlFaTh['cell_toplist']['pagecount'])
    if YtLREoMBucmwQOKAnWfGDeIVxlFaTh['cell_toplist']['count']:YtLREoMBucmwQOKAnWfGDeIVxlFagp =YtLREoMBucmwQOKAnWfGDeIVxlFaPC(YtLREoMBucmwQOKAnWfGDeIVxlFaTh['cell_toplist']['count'])
    else:YtLREoMBucmwQOKAnWfGDeIVxlFagp=YtLREoMBucmwQOKAnWfGDeIVxlFavX.LIST_LIMIT*page_int
    YtLREoMBucmwQOKAnWfGDeIVxlFagd=YtLREoMBucmwQOKAnWfGDeIVxlFagJ>YtLREoMBucmwQOKAnWfGDeIVxlFagp
  except YtLREoMBucmwQOKAnWfGDeIVxlFaPz as exception:
   YtLREoMBucmwQOKAnWfGDeIVxlFaiS(exception)
   return[],YtLREoMBucmwQOKAnWfGDeIVxlFaiU
  return YtLREoMBucmwQOKAnWfGDeIVxlFagj,YtLREoMBucmwQOKAnWfGDeIVxlFagd
 def Get_Movie_List(YtLREoMBucmwQOKAnWfGDeIVxlFavX,YtLREoMBucmwQOKAnWfGDeIVxlFaTU,page_int=1,orderby='-'):
  YtLREoMBucmwQOKAnWfGDeIVxlFagU=[]
  YtLREoMBucmwQOKAnWfGDeIVxlFagJ=YtLREoMBucmwQOKAnWfGDeIVxlFagp=1
  YtLREoMBucmwQOKAnWfGDeIVxlFagd=YtLREoMBucmwQOKAnWfGDeIVxlFaiU
  (YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,YtLREoMBucmwQOKAnWfGDeIVxlFavN)=YtLREoMBucmwQOKAnWfGDeIVxlFavX.Baseapi_Parse(YtLREoMBucmwQOKAnWfGDeIVxlFaTU)
  if YtLREoMBucmwQOKAnWfGDeIVxlFaTJ=='':return YtLREoMBucmwQOKAnWfGDeIVxlFagU,YtLREoMBucmwQOKAnWfGDeIVxlFagd
  try:
   YtLREoMBucmwQOKAnWfGDeIVxlFavN['limit']=YtLREoMBucmwQOKAnWfGDeIVxlFavX.MV_LIMIT
   YtLREoMBucmwQOKAnWfGDeIVxlFavN['offset']=YtLREoMBucmwQOKAnWfGDeIVxlFaPv((page_int-1)*YtLREoMBucmwQOKAnWfGDeIVxlFavX.MV_LIMIT)
   if YtLREoMBucmwQOKAnWfGDeIVxlFavN.get('orderby')!='' and YtLREoMBucmwQOKAnWfGDeIVxlFavN.get('orderby')!='regdatefirst' and orderby!='-':
    YtLREoMBucmwQOKAnWfGDeIVxlFavN['orderby']=orderby 
   YtLREoMBucmwQOKAnWfGDeIVxlFavN.update(YtLREoMBucmwQOKAnWfGDeIVxlFavX.GetDefaultParams(login=YtLREoMBucmwQOKAnWfGDeIVxlFaiU))
   YtLREoMBucmwQOKAnWfGDeIVxlFaTN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.callRequestCookies('Get',YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,payload=YtLREoMBucmwQOKAnWfGDeIVxlFaik,params=YtLREoMBucmwQOKAnWfGDeIVxlFavN,headers=YtLREoMBucmwQOKAnWfGDeIVxlFaik,cookies=YtLREoMBucmwQOKAnWfGDeIVxlFaik)
   YtLREoMBucmwQOKAnWfGDeIVxlFaTh=json.loads(YtLREoMBucmwQOKAnWfGDeIVxlFaTN.text)
   if YtLREoMBucmwQOKAnWfGDeIVxlFaTh.get('cell_toplist')not in[{},YtLREoMBucmwQOKAnWfGDeIVxlFaik,'']:
    YtLREoMBucmwQOKAnWfGDeIVxlFagv=YtLREoMBucmwQOKAnWfGDeIVxlFaTh['cell_toplist']['celllist']
   elif YtLREoMBucmwQOKAnWfGDeIVxlFaTh.get('band')not in[{},YtLREoMBucmwQOKAnWfGDeIVxlFaik,'']:
    YtLREoMBucmwQOKAnWfGDeIVxlFagv=YtLREoMBucmwQOKAnWfGDeIVxlFaTh['band']['celllist']
   else:
    return YtLREoMBucmwQOKAnWfGDeIVxlFagU,YtLREoMBucmwQOKAnWfGDeIVxlFagd
   for YtLREoMBucmwQOKAnWfGDeIVxlFagT in YtLREoMBucmwQOKAnWfGDeIVxlFagv:
    YtLREoMBucmwQOKAnWfGDeIVxlFagN =YtLREoMBucmwQOKAnWfGDeIVxlFagT['event_list'][1]['url']
    YtLREoMBucmwQOKAnWfGDeIVxlFagh=urllib.parse.urlsplit(YtLREoMBucmwQOKAnWfGDeIVxlFagN).query
    YtLREoMBucmwQOKAnWfGDeIVxlFagy=YtLREoMBucmwQOKAnWfGDeIVxlFagh[0:YtLREoMBucmwQOKAnWfGDeIVxlFagh.find('=')]
    YtLREoMBucmwQOKAnWfGDeIVxlFagk=YtLREoMBucmwQOKAnWfGDeIVxlFaPi(urllib.parse.parse_qsl(YtLREoMBucmwQOKAnWfGDeIVxlFagh))
    YtLREoMBucmwQOKAnWfGDeIVxlFagb=YtLREoMBucmwQOKAnWfGDeIVxlFagk.get(YtLREoMBucmwQOKAnWfGDeIVxlFagy)
    YtLREoMBucmwQOKAnWfGDeIVxlFagX={'title':YtLREoMBucmwQOKAnWfGDeIVxlFagT.get('alt')or YtLREoMBucmwQOKAnWfGDeIVxlFagT.get('title_list')[0].get('text'),'age':YtLREoMBucmwQOKAnWfGDeIVxlFagT.get('age'),'thumbnail':YtLREoMBucmwQOKAnWfGDeIVxlFagT.get('thumbnail'),'videoid':YtLREoMBucmwQOKAnWfGDeIVxlFagb,'vidtype':YtLREoMBucmwQOKAnWfGDeIVxlFagy,}
    if not YtLREoMBucmwQOKAnWfGDeIVxlFagX.get('thumbnail').startswith('http'):
     YtLREoMBucmwQOKAnWfGDeIVxlFagX['thumbnail']='https://%s'%YtLREoMBucmwQOKAnWfGDeIVxlFagX['thumbnail']
    YtLREoMBucmwQOKAnWfGDeIVxlFagU.append(YtLREoMBucmwQOKAnWfGDeIVxlFagX)
   if YtLREoMBucmwQOKAnWfGDeIVxlFaTh.get('cell_toplist')not in[{},YtLREoMBucmwQOKAnWfGDeIVxlFaik,'']:
    YtLREoMBucmwQOKAnWfGDeIVxlFagJ=YtLREoMBucmwQOKAnWfGDeIVxlFaPC(YtLREoMBucmwQOKAnWfGDeIVxlFaTh['cell_toplist']['pagecount'])
    if YtLREoMBucmwQOKAnWfGDeIVxlFaTh['cell_toplist']['count']:YtLREoMBucmwQOKAnWfGDeIVxlFagp =YtLREoMBucmwQOKAnWfGDeIVxlFaPC(YtLREoMBucmwQOKAnWfGDeIVxlFaTh['cell_toplist']['count'])
    else:YtLREoMBucmwQOKAnWfGDeIVxlFagp=YtLREoMBucmwQOKAnWfGDeIVxlFavX.MV_LIMIT*page_int
    YtLREoMBucmwQOKAnWfGDeIVxlFagd=YtLREoMBucmwQOKAnWfGDeIVxlFagJ>YtLREoMBucmwQOKAnWfGDeIVxlFagp
  except YtLREoMBucmwQOKAnWfGDeIVxlFaPz as exception:
   YtLREoMBucmwQOKAnWfGDeIVxlFaiS(exception)
   return[],YtLREoMBucmwQOKAnWfGDeIVxlFaiU
  return YtLREoMBucmwQOKAnWfGDeIVxlFagU,YtLREoMBucmwQOKAnWfGDeIVxlFagd
 def ProgramidToContentid(YtLREoMBucmwQOKAnWfGDeIVxlFavX,YtLREoMBucmwQOKAnWfGDeIVxlFaXT):
  YtLREoMBucmwQOKAnWfGDeIVxlFagS=''
  try:
   YtLREoMBucmwQOKAnWfGDeIVxlFaTJ =YtLREoMBucmwQOKAnWfGDeIVxlFavX.API_DOMAIN+'/vod/programs-contentid/'+YtLREoMBucmwQOKAnWfGDeIVxlFaXT
   YtLREoMBucmwQOKAnWfGDeIVxlFavN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.GetDefaultParams(login=YtLREoMBucmwQOKAnWfGDeIVxlFaiU)
   YtLREoMBucmwQOKAnWfGDeIVxlFaTN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.callRequestCookies('Get',YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,payload=YtLREoMBucmwQOKAnWfGDeIVxlFaik,params=YtLREoMBucmwQOKAnWfGDeIVxlFavN,headers=YtLREoMBucmwQOKAnWfGDeIVxlFaik,cookies=YtLREoMBucmwQOKAnWfGDeIVxlFaik)
   YtLREoMBucmwQOKAnWfGDeIVxlFaXv=json.loads(YtLREoMBucmwQOKAnWfGDeIVxlFaTN.text)
   if not('contentid' in YtLREoMBucmwQOKAnWfGDeIVxlFaXv):return YtLREoMBucmwQOKAnWfGDeIVxlFagS 
   YtLREoMBucmwQOKAnWfGDeIVxlFagS=YtLREoMBucmwQOKAnWfGDeIVxlFaXv['contentid']
  except YtLREoMBucmwQOKAnWfGDeIVxlFaPz as exception:
   YtLREoMBucmwQOKAnWfGDeIVxlFaiS(exception)
  return YtLREoMBucmwQOKAnWfGDeIVxlFagS
 def ContentidToSeasonid(YtLREoMBucmwQOKAnWfGDeIVxlFavX,YtLREoMBucmwQOKAnWfGDeIVxlFagS):
  YtLREoMBucmwQOKAnWfGDeIVxlFaXT=''
  try:
   YtLREoMBucmwQOKAnWfGDeIVxlFaTJ =YtLREoMBucmwQOKAnWfGDeIVxlFavX.API_DOMAIN+'/fz/vod/contents/'+YtLREoMBucmwQOKAnWfGDeIVxlFagS
   YtLREoMBucmwQOKAnWfGDeIVxlFavN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.GetDefaultParams(login=YtLREoMBucmwQOKAnWfGDeIVxlFaiU)
   YtLREoMBucmwQOKAnWfGDeIVxlFaTN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.callRequestCookies('Get',YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,payload=YtLREoMBucmwQOKAnWfGDeIVxlFaik,params=YtLREoMBucmwQOKAnWfGDeIVxlFavN,headers=YtLREoMBucmwQOKAnWfGDeIVxlFaik,cookies=YtLREoMBucmwQOKAnWfGDeIVxlFaik)
   YtLREoMBucmwQOKAnWfGDeIVxlFaXv=json.loads(YtLREoMBucmwQOKAnWfGDeIVxlFaTN.text)
   if not('programid' in YtLREoMBucmwQOKAnWfGDeIVxlFaXv):return YtLREoMBucmwQOKAnWfGDeIVxlFaXT 
   YtLREoMBucmwQOKAnWfGDeIVxlFaXT=YtLREoMBucmwQOKAnWfGDeIVxlFaXv['programid']
  except YtLREoMBucmwQOKAnWfGDeIVxlFaPz as exception:
   YtLREoMBucmwQOKAnWfGDeIVxlFaiS(exception)
  return YtLREoMBucmwQOKAnWfGDeIVxlFaXT
 def GetProgramInfo(YtLREoMBucmwQOKAnWfGDeIVxlFavX,YtLREoMBucmwQOKAnWfGDeIVxlFagS):
  YtLREoMBucmwQOKAnWfGDeIVxlFaXg={}
  try:
   YtLREoMBucmwQOKAnWfGDeIVxlFaTJ=YtLREoMBucmwQOKAnWfGDeIVxlFavX.API_DOMAIN+'/fz/vod/contents/'+YtLREoMBucmwQOKAnWfGDeIVxlFagS
   YtLREoMBucmwQOKAnWfGDeIVxlFavN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.GetDefaultParams(login=YtLREoMBucmwQOKAnWfGDeIVxlFaiU)
   YtLREoMBucmwQOKAnWfGDeIVxlFaTN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.callRequestCookies('Get',YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,payload=YtLREoMBucmwQOKAnWfGDeIVxlFaik,params=YtLREoMBucmwQOKAnWfGDeIVxlFavN,headers=YtLREoMBucmwQOKAnWfGDeIVxlFaik,cookies=YtLREoMBucmwQOKAnWfGDeIVxlFaik)
   YtLREoMBucmwQOKAnWfGDeIVxlFaXv=json.loads(YtLREoMBucmwQOKAnWfGDeIVxlFaTN.text)
   YtLREoMBucmwQOKAnWfGDeIVxlFaXq=img_fanart=YtLREoMBucmwQOKAnWfGDeIVxlFaXz=''
   if YtLREoMBucmwQOKAnWfGDeIVxlFaXv.get('programposterimage')!='':YtLREoMBucmwQOKAnWfGDeIVxlFaXq =YtLREoMBucmwQOKAnWfGDeIVxlFavX.HTTPTAG+YtLREoMBucmwQOKAnWfGDeIVxlFaXv.get('programposterimage')
   if YtLREoMBucmwQOKAnWfGDeIVxlFaXv.get('programimage') !='':img_fanart =YtLREoMBucmwQOKAnWfGDeIVxlFavX.HTTPTAG+YtLREoMBucmwQOKAnWfGDeIVxlFaXv.get('programimage')
   if YtLREoMBucmwQOKAnWfGDeIVxlFaXv.get('programcircleimage')!='':YtLREoMBucmwQOKAnWfGDeIVxlFaXz=YtLREoMBucmwQOKAnWfGDeIVxlFavX.HTTPTAG+YtLREoMBucmwQOKAnWfGDeIVxlFaXv.get('programcircleimage')
   if 'poster_default' in YtLREoMBucmwQOKAnWfGDeIVxlFaXq:
    YtLREoMBucmwQOKAnWfGDeIVxlFaXq =img_fanart
    YtLREoMBucmwQOKAnWfGDeIVxlFaXz=''
   YtLREoMBucmwQOKAnWfGDeIVxlFaXg={'imgPoster':YtLREoMBucmwQOKAnWfGDeIVxlFaXq,'imgFanart':img_fanart,'imgClearlogo':YtLREoMBucmwQOKAnWfGDeIVxlFaXz,'programtitle':YtLREoMBucmwQOKAnWfGDeIVxlFavX.Get_ChangeText(YtLREoMBucmwQOKAnWfGDeIVxlFaXv.get('programtitle')),'programid':YtLREoMBucmwQOKAnWfGDeIVxlFaXv.get('programid'),'synopsis':YtLREoMBucmwQOKAnWfGDeIVxlFavX.Get_ChangeText(YtLREoMBucmwQOKAnWfGDeIVxlFaXv.get('programsynopsis')),}
  except YtLREoMBucmwQOKAnWfGDeIVxlFaPz as exception:
   YtLREoMBucmwQOKAnWfGDeIVxlFaiS(exception)
  return YtLREoMBucmwQOKAnWfGDeIVxlFaXg
 def Get_Season_List(YtLREoMBucmwQOKAnWfGDeIVxlFavX,seasonid):
  YtLREoMBucmwQOKAnWfGDeIVxlFaXi=[]
  YtLREoMBucmwQOKAnWfGDeIVxlFagS=YtLREoMBucmwQOKAnWfGDeIVxlFavX.ProgramidToContentid(seasonid)
  YtLREoMBucmwQOKAnWfGDeIVxlFaXP=YtLREoMBucmwQOKAnWfGDeIVxlFavX.GetProgramInfo(YtLREoMBucmwQOKAnWfGDeIVxlFagS)
  YtLREoMBucmwQOKAnWfGDeIVxlFaXC={'poster':YtLREoMBucmwQOKAnWfGDeIVxlFaXP.get('imgPoster'),'fanart':YtLREoMBucmwQOKAnWfGDeIVxlFaXP.get('imgFanart'),'clearlogo':YtLREoMBucmwQOKAnWfGDeIVxlFaXP.get('imgClearlogo'),}
  try:
   YtLREoMBucmwQOKAnWfGDeIVxlFaTJ=YtLREoMBucmwQOKAnWfGDeIVxlFavX.API_DOMAIN+'/fz/vod/programs-contents/'+seasonid
   YtLREoMBucmwQOKAnWfGDeIVxlFavN={'limit':'10','offset':'0','orderby':'new',}
   YtLREoMBucmwQOKAnWfGDeIVxlFavN.update(YtLREoMBucmwQOKAnWfGDeIVxlFavX.GetDefaultParams(login=YtLREoMBucmwQOKAnWfGDeIVxlFaiU))
   YtLREoMBucmwQOKAnWfGDeIVxlFaTN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.callRequestCookies('Get',YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,payload=YtLREoMBucmwQOKAnWfGDeIVxlFaik,params=YtLREoMBucmwQOKAnWfGDeIVxlFavN,headers=YtLREoMBucmwQOKAnWfGDeIVxlFaik,cookies=YtLREoMBucmwQOKAnWfGDeIVxlFaik)
   YtLREoMBucmwQOKAnWfGDeIVxlFaTh=json.loads(YtLREoMBucmwQOKAnWfGDeIVxlFaTN.text)
   for YtLREoMBucmwQOKAnWfGDeIVxlFaXr in YtLREoMBucmwQOKAnWfGDeIVxlFaTh['filter']['filterlist'][0]['filter_item_list']:
    YtLREoMBucmwQOKAnWfGDeIVxlFagX={'season_Nm':YtLREoMBucmwQOKAnWfGDeIVxlFavX.Get_ChangeText(YtLREoMBucmwQOKAnWfGDeIVxlFaXr.get('title')),'season_Id':YtLREoMBucmwQOKAnWfGDeIVxlFaXr.get('api_path'),'thumbnail':YtLREoMBucmwQOKAnWfGDeIVxlFaXC,'programNm':YtLREoMBucmwQOKAnWfGDeIVxlFavX.Get_ChangeText(YtLREoMBucmwQOKAnWfGDeIVxlFaXP.get('programtitle')),'synopsis':YtLREoMBucmwQOKAnWfGDeIVxlFavX.Get_ChangeText(YtLREoMBucmwQOKAnWfGDeIVxlFaXP.get('synopsis')),}
    YtLREoMBucmwQOKAnWfGDeIVxlFaXi.append(YtLREoMBucmwQOKAnWfGDeIVxlFagX)
  except YtLREoMBucmwQOKAnWfGDeIVxlFaPz as exception:
   YtLREoMBucmwQOKAnWfGDeIVxlFaiS(exception)
   return[]
  return YtLREoMBucmwQOKAnWfGDeIVxlFaXi
 def Get_Episode_List(YtLREoMBucmwQOKAnWfGDeIVxlFavX,seasionid,page_int=1,orderby='desc'):
  YtLREoMBucmwQOKAnWfGDeIVxlFaXJ=[]
  YtLREoMBucmwQOKAnWfGDeIVxlFagJ=YtLREoMBucmwQOKAnWfGDeIVxlFagp=1
  YtLREoMBucmwQOKAnWfGDeIVxlFagd=YtLREoMBucmwQOKAnWfGDeIVxlFaiU
  YtLREoMBucmwQOKAnWfGDeIVxlFaXP={}
  YtLREoMBucmwQOKAnWfGDeIVxlFagS=YtLREoMBucmwQOKAnWfGDeIVxlFavX.ProgramidToContentid(seasionid)
  YtLREoMBucmwQOKAnWfGDeIVxlFaXP=YtLREoMBucmwQOKAnWfGDeIVxlFavX.GetProgramInfo(YtLREoMBucmwQOKAnWfGDeIVxlFagS)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   YtLREoMBucmwQOKAnWfGDeIVxlFaTJ=YtLREoMBucmwQOKAnWfGDeIVxlFavX.API_DOMAIN+'/fz/vod/programs-contents/'+seasionid
   YtLREoMBucmwQOKAnWfGDeIVxlFavN={'limit':YtLREoMBucmwQOKAnWfGDeIVxlFavX.EP_LIMIT,'offset':YtLREoMBucmwQOKAnWfGDeIVxlFaPv((page_int-1)*YtLREoMBucmwQOKAnWfGDeIVxlFavX.EP_LIMIT),'orderby':orderby,}
   YtLREoMBucmwQOKAnWfGDeIVxlFavN.update(YtLREoMBucmwQOKAnWfGDeIVxlFavX.GetDefaultParams(login=YtLREoMBucmwQOKAnWfGDeIVxlFaiU))
   YtLREoMBucmwQOKAnWfGDeIVxlFaTN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.callRequestCookies('Get',YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,payload=YtLREoMBucmwQOKAnWfGDeIVxlFaik,params=YtLREoMBucmwQOKAnWfGDeIVxlFavN,headers=YtLREoMBucmwQOKAnWfGDeIVxlFaik,cookies=YtLREoMBucmwQOKAnWfGDeIVxlFaik)
   YtLREoMBucmwQOKAnWfGDeIVxlFaTh=json.loads(YtLREoMBucmwQOKAnWfGDeIVxlFaTN.text)
   YtLREoMBucmwQOKAnWfGDeIVxlFagv=YtLREoMBucmwQOKAnWfGDeIVxlFaTh['cell_toplist']['celllist']
   for YtLREoMBucmwQOKAnWfGDeIVxlFagT in YtLREoMBucmwQOKAnWfGDeIVxlFagv:
    YtLREoMBucmwQOKAnWfGDeIVxlFaXN=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',YtLREoMBucmwQOKAnWfGDeIVxlFagT.get('synopsis'))
    YtLREoMBucmwQOKAnWfGDeIVxlFaXh=YtLREoMBucmwQOKAnWfGDeIVxlFagT.get('thumbnail')
    if not YtLREoMBucmwQOKAnWfGDeIVxlFaXh.startswith('http'):
     YtLREoMBucmwQOKAnWfGDeIVxlFaXh=YtLREoMBucmwQOKAnWfGDeIVxlFavX.HTTPTAG+YtLREoMBucmwQOKAnWfGDeIVxlFaXh
    YtLREoMBucmwQOKAnWfGDeIVxlFaXy=YtLREoMBucmwQOKAnWfGDeIVxlFaXb=YtLREoMBucmwQOKAnWfGDeIVxlFaXp=''
    YtLREoMBucmwQOKAnWfGDeIVxlFaXy =YtLREoMBucmwQOKAnWfGDeIVxlFaXP.get('imgPoster')
    YtLREoMBucmwQOKAnWfGDeIVxlFaXb =YtLREoMBucmwQOKAnWfGDeIVxlFaXP.get('imgFanart')
    YtLREoMBucmwQOKAnWfGDeIVxlFaXp =YtLREoMBucmwQOKAnWfGDeIVxlFaXP.get('imgClearlogo')
    YtLREoMBucmwQOKAnWfGDeIVxlFaXH=YtLREoMBucmwQOKAnWfGDeIVxlFaXP.get('programtitle')
    YtLREoMBucmwQOKAnWfGDeIVxlFaXC={'thumb':YtLREoMBucmwQOKAnWfGDeIVxlFaXh,'poster':YtLREoMBucmwQOKAnWfGDeIVxlFaXy,'fanart':YtLREoMBucmwQOKAnWfGDeIVxlFaXb,'clearlogo':YtLREoMBucmwQOKAnWfGDeIVxlFaXp}
    YtLREoMBucmwQOKAnWfGDeIVxlFagX={'programtitle':YtLREoMBucmwQOKAnWfGDeIVxlFavX.Get_ChangeText(YtLREoMBucmwQOKAnWfGDeIVxlFaXH),'episodetitle':YtLREoMBucmwQOKAnWfGDeIVxlFavX.Get_ChangeText(YtLREoMBucmwQOKAnWfGDeIVxlFagT['title_list'][0]['text']),'episodenumber':YtLREoMBucmwQOKAnWfGDeIVxlFagT['title_list'][1]['text'].replace('$O$',''),'contentid':YtLREoMBucmwQOKAnWfGDeIVxlFagT['contentid'],'synopsis':YtLREoMBucmwQOKAnWfGDeIVxlFavX.Get_ChangeText(YtLREoMBucmwQOKAnWfGDeIVxlFaXN),'episodeactors':YtLREoMBucmwQOKAnWfGDeIVxlFagT.get('actors').split(',')if YtLREoMBucmwQOKAnWfGDeIVxlFagT.get('actors')!='' else[],'thumbnail':YtLREoMBucmwQOKAnWfGDeIVxlFaXC,}
    YtLREoMBucmwQOKAnWfGDeIVxlFaXJ.append(YtLREoMBucmwQOKAnWfGDeIVxlFagX)
   YtLREoMBucmwQOKAnWfGDeIVxlFagJ=YtLREoMBucmwQOKAnWfGDeIVxlFaPC(YtLREoMBucmwQOKAnWfGDeIVxlFaTh['cell_toplist']['pagecount'])
   if YtLREoMBucmwQOKAnWfGDeIVxlFaTh['cell_toplist']['count']:YtLREoMBucmwQOKAnWfGDeIVxlFagp =YtLREoMBucmwQOKAnWfGDeIVxlFaPC(YtLREoMBucmwQOKAnWfGDeIVxlFaTh['cell_toplist']['count'])
   else:YtLREoMBucmwQOKAnWfGDeIVxlFagp=YtLREoMBucmwQOKAnWfGDeIVxlFavX.EP_LIMIT*page_int
   YtLREoMBucmwQOKAnWfGDeIVxlFagd=YtLREoMBucmwQOKAnWfGDeIVxlFagJ>YtLREoMBucmwQOKAnWfGDeIVxlFagp
  except YtLREoMBucmwQOKAnWfGDeIVxlFaPz as exception:
   YtLREoMBucmwQOKAnWfGDeIVxlFaiS(exception)
   return[],YtLREoMBucmwQOKAnWfGDeIVxlFaiU
  return YtLREoMBucmwQOKAnWfGDeIVxlFaXJ,YtLREoMBucmwQOKAnWfGDeIVxlFagd
 def GetEPGList(YtLREoMBucmwQOKAnWfGDeIVxlFavX,genre):
  YtLREoMBucmwQOKAnWfGDeIVxlFaXj={}
  try:
   YtLREoMBucmwQOKAnWfGDeIVxlFaXs=YtLREoMBucmwQOKAnWfGDeIVxlFavX.Get_Now_Datetime()
   if genre=='all':
    YtLREoMBucmwQOKAnWfGDeIVxlFaXk =YtLREoMBucmwQOKAnWfGDeIVxlFaXs+datetime.timedelta(hours=3)
   else:
    YtLREoMBucmwQOKAnWfGDeIVxlFaXk =YtLREoMBucmwQOKAnWfGDeIVxlFaXs+datetime.timedelta(hours=3)
   YtLREoMBucmwQOKAnWfGDeIVxlFaTJ=YtLREoMBucmwQOKAnWfGDeIVxlFavX.API_DOMAIN+'/live/epgs'
   YtLREoMBucmwQOKAnWfGDeIVxlFavN={'limit':'100','offset':'0','genre':genre,'startdatetime':YtLREoMBucmwQOKAnWfGDeIVxlFaXs.strftime('%Y-%m-%d %H:00'),'enddatetime':YtLREoMBucmwQOKAnWfGDeIVxlFaXk.strftime('%Y-%m-%d %H:00')}
   YtLREoMBucmwQOKAnWfGDeIVxlFavN.update(YtLREoMBucmwQOKAnWfGDeIVxlFavX.GetDefaultParams(login=YtLREoMBucmwQOKAnWfGDeIVxlFaiU))
   YtLREoMBucmwQOKAnWfGDeIVxlFaTN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.callRequestCookies('Get',YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,payload=YtLREoMBucmwQOKAnWfGDeIVxlFaik,params=YtLREoMBucmwQOKAnWfGDeIVxlFavN,headers=YtLREoMBucmwQOKAnWfGDeIVxlFaik,cookies=YtLREoMBucmwQOKAnWfGDeIVxlFaik)
   YtLREoMBucmwQOKAnWfGDeIVxlFaTh=json.loads(YtLREoMBucmwQOKAnWfGDeIVxlFaTN.text)
   YtLREoMBucmwQOKAnWfGDeIVxlFaXU=YtLREoMBucmwQOKAnWfGDeIVxlFaTh['list']
   for YtLREoMBucmwQOKAnWfGDeIVxlFagT in YtLREoMBucmwQOKAnWfGDeIVxlFaXU:
    YtLREoMBucmwQOKAnWfGDeIVxlFaXS=''
    for YtLREoMBucmwQOKAnWfGDeIVxlFaqv in YtLREoMBucmwQOKAnWfGDeIVxlFagT['list']:
     if YtLREoMBucmwQOKAnWfGDeIVxlFaXS:YtLREoMBucmwQOKAnWfGDeIVxlFaXS+='\n'
     YtLREoMBucmwQOKAnWfGDeIVxlFaXS+=YtLREoMBucmwQOKAnWfGDeIVxlFavX.Get_ChangeText(YtLREoMBucmwQOKAnWfGDeIVxlFaqv['title'])+'\n'
     YtLREoMBucmwQOKAnWfGDeIVxlFaXS+=' [%s ~ %s]'%(YtLREoMBucmwQOKAnWfGDeIVxlFaqv['starttime'][-5:],YtLREoMBucmwQOKAnWfGDeIVxlFaqv['endtime'][-5:])+'\n'
    YtLREoMBucmwQOKAnWfGDeIVxlFaXj[YtLREoMBucmwQOKAnWfGDeIVxlFagT['channelid']]=YtLREoMBucmwQOKAnWfGDeIVxlFaXS
  except YtLREoMBucmwQOKAnWfGDeIVxlFaPz as exception:
   YtLREoMBucmwQOKAnWfGDeIVxlFaiS(exception)
  return YtLREoMBucmwQOKAnWfGDeIVxlFaXj
 def Get_LiveChannel_List(YtLREoMBucmwQOKAnWfGDeIVxlFavX,genre,YtLREoMBucmwQOKAnWfGDeIVxlFaTU):
  YtLREoMBucmwQOKAnWfGDeIVxlFagr=[]
  (YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,YtLREoMBucmwQOKAnWfGDeIVxlFavN)=YtLREoMBucmwQOKAnWfGDeIVxlFavX.Baseapi_Parse(YtLREoMBucmwQOKAnWfGDeIVxlFaTU)
  if YtLREoMBucmwQOKAnWfGDeIVxlFaTJ=='':return YtLREoMBucmwQOKAnWfGDeIVxlFagr
  YtLREoMBucmwQOKAnWfGDeIVxlFaqT=YtLREoMBucmwQOKAnWfGDeIVxlFavX.GetEPGList(genre)
  try:
   YtLREoMBucmwQOKAnWfGDeIVxlFavN.update(YtLREoMBucmwQOKAnWfGDeIVxlFavX.GetDefaultParams(login=YtLREoMBucmwQOKAnWfGDeIVxlFaiU))
   YtLREoMBucmwQOKAnWfGDeIVxlFavN['genre']=genre
   YtLREoMBucmwQOKAnWfGDeIVxlFaTN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.callRequestCookies('Get',YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,payload=YtLREoMBucmwQOKAnWfGDeIVxlFaik,params=YtLREoMBucmwQOKAnWfGDeIVxlFavN,headers=YtLREoMBucmwQOKAnWfGDeIVxlFaik,cookies=YtLREoMBucmwQOKAnWfGDeIVxlFaik)
   YtLREoMBucmwQOKAnWfGDeIVxlFaTh=json.loads(YtLREoMBucmwQOKAnWfGDeIVxlFaTN.text)
   if not('celllist' in YtLREoMBucmwQOKAnWfGDeIVxlFaTh['cell_toplist']):return[]
   YtLREoMBucmwQOKAnWfGDeIVxlFagv=YtLREoMBucmwQOKAnWfGDeIVxlFaTh['cell_toplist']['celllist']
   for YtLREoMBucmwQOKAnWfGDeIVxlFagT in YtLREoMBucmwQOKAnWfGDeIVxlFagv:
    YtLREoMBucmwQOKAnWfGDeIVxlFagS=YtLREoMBucmwQOKAnWfGDeIVxlFagT['contentid']
    if YtLREoMBucmwQOKAnWfGDeIVxlFagS in YtLREoMBucmwQOKAnWfGDeIVxlFaqT:
     YtLREoMBucmwQOKAnWfGDeIVxlFaqg=YtLREoMBucmwQOKAnWfGDeIVxlFaqT[YtLREoMBucmwQOKAnWfGDeIVxlFagS]
    else:
     YtLREoMBucmwQOKAnWfGDeIVxlFaqg=''
    YtLREoMBucmwQOKAnWfGDeIVxlFagX={'studio':YtLREoMBucmwQOKAnWfGDeIVxlFagT['title_list'][0]['text'],'tvshowtitle':YtLREoMBucmwQOKAnWfGDeIVxlFavX.Get_ChangeText(YtLREoMBucmwQOKAnWfGDeIVxlFagT['title_list'][1]['text']),'channelid':YtLREoMBucmwQOKAnWfGDeIVxlFagS,'age':YtLREoMBucmwQOKAnWfGDeIVxlFagT['age'],'thumbnail':'https://%s'%YtLREoMBucmwQOKAnWfGDeIVxlFagT.get('thumbnail'),'epg':YtLREoMBucmwQOKAnWfGDeIVxlFaqg}
    YtLREoMBucmwQOKAnWfGDeIVxlFagr.append(YtLREoMBucmwQOKAnWfGDeIVxlFagX)
  except YtLREoMBucmwQOKAnWfGDeIVxlFaPz as exception:
   YtLREoMBucmwQOKAnWfGDeIVxlFaiS(exception)
   return[]
  return YtLREoMBucmwQOKAnWfGDeIVxlFagr
 def Get_Search_List(YtLREoMBucmwQOKAnWfGDeIVxlFavX,search_key,sType,page_int,exclusion21=YtLREoMBucmwQOKAnWfGDeIVxlFaiU):
  YtLREoMBucmwQOKAnWfGDeIVxlFaqX=[]
  YtLREoMBucmwQOKAnWfGDeIVxlFagJ=YtLREoMBucmwQOKAnWfGDeIVxlFagp=1
  YtLREoMBucmwQOKAnWfGDeIVxlFagd=YtLREoMBucmwQOKAnWfGDeIVxlFaiU
  try:
   YtLREoMBucmwQOKAnWfGDeIVxlFaTJ=YtLREoMBucmwQOKAnWfGDeIVxlFavX.API_DOMAIN+'/fz/search/band.js'
   YtLREoMBucmwQOKAnWfGDeIVxlFavN={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':YtLREoMBucmwQOKAnWfGDeIVxlFaPv((page_int-1)*YtLREoMBucmwQOKAnWfGDeIVxlFavX.SEARCH_LIMIT),'limit':YtLREoMBucmwQOKAnWfGDeIVxlFavX.SEARCH_LIMIT,'orderby':'score','mtype':'svod',}
   YtLREoMBucmwQOKAnWfGDeIVxlFavN.update(YtLREoMBucmwQOKAnWfGDeIVxlFavX.GetDefaultParams(login=YtLREoMBucmwQOKAnWfGDeIVxlFaiU))
   YtLREoMBucmwQOKAnWfGDeIVxlFaTN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.callRequestCookies('Get',YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,payload=YtLREoMBucmwQOKAnWfGDeIVxlFaik,params=YtLREoMBucmwQOKAnWfGDeIVxlFavN,headers=YtLREoMBucmwQOKAnWfGDeIVxlFaik,cookies=YtLREoMBucmwQOKAnWfGDeIVxlFaik)
   YtLREoMBucmwQOKAnWfGDeIVxlFaXv=json.loads(YtLREoMBucmwQOKAnWfGDeIVxlFaTN.text)
   if not('celllist' in YtLREoMBucmwQOKAnWfGDeIVxlFaXv['band']):return YtLREoMBucmwQOKAnWfGDeIVxlFaqX,YtLREoMBucmwQOKAnWfGDeIVxlFagd
   YtLREoMBucmwQOKAnWfGDeIVxlFagv=YtLREoMBucmwQOKAnWfGDeIVxlFaXv['band']['celllist']
   for YtLREoMBucmwQOKAnWfGDeIVxlFagT in YtLREoMBucmwQOKAnWfGDeIVxlFagv:
    YtLREoMBucmwQOKAnWfGDeIVxlFagN =YtLREoMBucmwQOKAnWfGDeIVxlFagT['event_list'][1]['url']
    YtLREoMBucmwQOKAnWfGDeIVxlFagh=urllib.parse.urlsplit(YtLREoMBucmwQOKAnWfGDeIVxlFagN).query
    YtLREoMBucmwQOKAnWfGDeIVxlFagy=YtLREoMBucmwQOKAnWfGDeIVxlFagh[0:YtLREoMBucmwQOKAnWfGDeIVxlFagh.find('=')]
    YtLREoMBucmwQOKAnWfGDeIVxlFagk=YtLREoMBucmwQOKAnWfGDeIVxlFaPi(urllib.parse.parse_qsl(YtLREoMBucmwQOKAnWfGDeIVxlFagh))
    YtLREoMBucmwQOKAnWfGDeIVxlFagb=YtLREoMBucmwQOKAnWfGDeIVxlFagk.get(YtLREoMBucmwQOKAnWfGDeIVxlFagy)
    YtLREoMBucmwQOKAnWfGDeIVxlFagX={'title':YtLREoMBucmwQOKAnWfGDeIVxlFagT['title_list'][0]['text'],'age':YtLREoMBucmwQOKAnWfGDeIVxlFagT['age'],'thumbnail':'https://%s'%YtLREoMBucmwQOKAnWfGDeIVxlFagT.get('thumbnail'),'videoid':YtLREoMBucmwQOKAnWfGDeIVxlFagb,'vidtype':YtLREoMBucmwQOKAnWfGDeIVxlFagy,}
    YtLREoMBucmwQOKAnWfGDeIVxlFaqz=YtLREoMBucmwQOKAnWfGDeIVxlFaiU
    for YtLREoMBucmwQOKAnWfGDeIVxlFaqi in YtLREoMBucmwQOKAnWfGDeIVxlFagT['bottom_taglist']:
     if YtLREoMBucmwQOKAnWfGDeIVxlFaqi=='won':
      YtLREoMBucmwQOKAnWfGDeIVxlFaqz=YtLREoMBucmwQOKAnWfGDeIVxlFaPg
      break
    if YtLREoMBucmwQOKAnWfGDeIVxlFaqz==YtLREoMBucmwQOKAnWfGDeIVxlFaPg: 
     YtLREoMBucmwQOKAnWfGDeIVxlFagX['title']=YtLREoMBucmwQOKAnWfGDeIVxlFagX['title']+' [개별구매]'
    if exclusion21==YtLREoMBucmwQOKAnWfGDeIVxlFaiU or YtLREoMBucmwQOKAnWfGDeIVxlFagT.get('age')!='21':
     YtLREoMBucmwQOKAnWfGDeIVxlFaqX.append(YtLREoMBucmwQOKAnWfGDeIVxlFagX)
   YtLREoMBucmwQOKAnWfGDeIVxlFagJ=YtLREoMBucmwQOKAnWfGDeIVxlFaPC(YtLREoMBucmwQOKAnWfGDeIVxlFaXv['band']['pagecount'])
   if YtLREoMBucmwQOKAnWfGDeIVxlFaXv['band']['count']:YtLREoMBucmwQOKAnWfGDeIVxlFagp =YtLREoMBucmwQOKAnWfGDeIVxlFaPC(YtLREoMBucmwQOKAnWfGDeIVxlFaXv['band']['count'])
   else:YtLREoMBucmwQOKAnWfGDeIVxlFagp=YtLREoMBucmwQOKAnWfGDeIVxlFavX.LIST_LIMIT
   YtLREoMBucmwQOKAnWfGDeIVxlFagd=YtLREoMBucmwQOKAnWfGDeIVxlFagJ>YtLREoMBucmwQOKAnWfGDeIVxlFagp
  except YtLREoMBucmwQOKAnWfGDeIVxlFaPz as exception:
   YtLREoMBucmwQOKAnWfGDeIVxlFaiS(exception)
  return YtLREoMBucmwQOKAnWfGDeIVxlFaqX,YtLREoMBucmwQOKAnWfGDeIVxlFagd 
 def GetSecureToken(YtLREoMBucmwQOKAnWfGDeIVxlFavX):
  YtLREoMBucmwQOKAnWfGDeIVxlFaTJ=YtLREoMBucmwQOKAnWfGDeIVxlFavX.API_DOMAIN+'/ip'
  YtLREoMBucmwQOKAnWfGDeIVxlFavN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.GetDefaultParams(login=YtLREoMBucmwQOKAnWfGDeIVxlFaiU)
  YtLREoMBucmwQOKAnWfGDeIVxlFaTN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.callRequestCookies('Get',YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,payload=YtLREoMBucmwQOKAnWfGDeIVxlFaik,params=YtLREoMBucmwQOKAnWfGDeIVxlFavN,headers=YtLREoMBucmwQOKAnWfGDeIVxlFaik,cookies=YtLREoMBucmwQOKAnWfGDeIVxlFaik)
  YtLREoMBucmwQOKAnWfGDeIVxlFaTh=json.loads(YtLREoMBucmwQOKAnWfGDeIVxlFaTN.text)
  return YtLREoMBucmwQOKAnWfGDeIVxlFaTh['securetoken']
 def Wavve_Parse_m3u8(YtLREoMBucmwQOKAnWfGDeIVxlFavX,YtLREoMBucmwQOKAnWfGDeIVxlFazP):
  try:
   YtLREoMBucmwQOKAnWfGDeIVxlFaTP={'user-agent':'pooqV2/5.6.0 (Linux;Android 10) ExoPlayerLib/2.13.3'}
   YtLREoMBucmwQOKAnWfGDeIVxlFaTN=requests.get(url=YtLREoMBucmwQOKAnWfGDeIVxlFazP['stream_url'],headers=YtLREoMBucmwQOKAnWfGDeIVxlFaTP,cookies=YtLREoMBucmwQOKAnWfGDeIVxlFazP['stream_cookie'])
   YtLREoMBucmwQOKAnWfGDeIVxlFaqP=YtLREoMBucmwQOKAnWfGDeIVxlFaTN.content.decode('utf-8')
   if '#EXTM3U' not in YtLREoMBucmwQOKAnWfGDeIVxlFaqP:
    return YtLREoMBucmwQOKAnWfGDeIVxlFaiU
   if '#EXT-X-STREAM-INF' not in YtLREoMBucmwQOKAnWfGDeIVxlFaqP: 
    return YtLREoMBucmwQOKAnWfGDeIVxlFaiU
   YtLREoMBucmwQOKAnWfGDeIVxlFaqC=0
   for YtLREoMBucmwQOKAnWfGDeIVxlFaqr in YtLREoMBucmwQOKAnWfGDeIVxlFaqP.splitlines():
    if YtLREoMBucmwQOKAnWfGDeIVxlFaqr.startswith('#EXT-X-STREAM-INF'):
     YtLREoMBucmwQOKAnWfGDeIVxlFaqJ=YtLREoMBucmwQOKAnWfGDeIVxlFavX.MediaLine_Parse(YtLREoMBucmwQOKAnWfGDeIVxlFaqr,'#EXT-X-STREAM-INF')
     if YtLREoMBucmwQOKAnWfGDeIVxlFaqC<YtLREoMBucmwQOKAnWfGDeIVxlFaPC(YtLREoMBucmwQOKAnWfGDeIVxlFaqJ.get('BANDWIDTH')):
      YtLREoMBucmwQOKAnWfGDeIVxlFaqC=YtLREoMBucmwQOKAnWfGDeIVxlFaPC(YtLREoMBucmwQOKAnWfGDeIVxlFaqJ.get('BANDWIDTH'))
   YtLREoMBucmwQOKAnWfGDeIVxlFaqd=[]
   YtLREoMBucmwQOKAnWfGDeIVxlFaqN=YtLREoMBucmwQOKAnWfGDeIVxlFaiU
   for YtLREoMBucmwQOKAnWfGDeIVxlFaqr in YtLREoMBucmwQOKAnWfGDeIVxlFaqP.splitlines():
    if YtLREoMBucmwQOKAnWfGDeIVxlFaqN==YtLREoMBucmwQOKAnWfGDeIVxlFaPg:
     YtLREoMBucmwQOKAnWfGDeIVxlFaqN=YtLREoMBucmwQOKAnWfGDeIVxlFaiU
     continue
    if YtLREoMBucmwQOKAnWfGDeIVxlFaqr.startswith('#EXT-X-STREAM-INF'):
     YtLREoMBucmwQOKAnWfGDeIVxlFaqJ=YtLREoMBucmwQOKAnWfGDeIVxlFavX.MediaLine_Parse(YtLREoMBucmwQOKAnWfGDeIVxlFaqr,'#EXT-X-STREAM-INF')
     if YtLREoMBucmwQOKAnWfGDeIVxlFaqC!=YtLREoMBucmwQOKAnWfGDeIVxlFaPC(YtLREoMBucmwQOKAnWfGDeIVxlFaqJ.get('BANDWIDTH')):
      YtLREoMBucmwQOKAnWfGDeIVxlFaqN=YtLREoMBucmwQOKAnWfGDeIVxlFaPg
      continue
    YtLREoMBucmwQOKAnWfGDeIVxlFaqd.append(YtLREoMBucmwQOKAnWfGDeIVxlFaqr)
  except YtLREoMBucmwQOKAnWfGDeIVxlFaPz as exception:
   YtLREoMBucmwQOKAnWfGDeIVxlFaiS(exception)
   return YtLREoMBucmwQOKAnWfGDeIVxlFaiU
  YtLREoMBucmwQOKAnWfGDeIVxlFaqh='\n'.join(YtLREoMBucmwQOKAnWfGDeIVxlFaqd)
  YtLREoMBucmwQOKAnWfGDeIVxlFavX.TextFile_Save(YtLREoMBucmwQOKAnWfGDeIVxlFavX.WV_STREAM_FILENAME,YtLREoMBucmwQOKAnWfGDeIVxlFaqh)
  return YtLREoMBucmwQOKAnWfGDeIVxlFaPg
 def Wavve_Parse_mpd(YtLREoMBucmwQOKAnWfGDeIVxlFavX,YtLREoMBucmwQOKAnWfGDeIVxlFazP):
  YtLREoMBucmwQOKAnWfGDeIVxlFaTP={'user-agent':'pooqV2/5.6.0 (Linux;Android 10) ExoPlayerLib/2.13.3'}
  YtLREoMBucmwQOKAnWfGDeIVxlFaTN=requests.get(url=YtLREoMBucmwQOKAnWfGDeIVxlFazP['stream_url'],headers=YtLREoMBucmwQOKAnWfGDeIVxlFaTP,cookies=YtLREoMBucmwQOKAnWfGDeIVxlFazP['stream_cookie'])
  YtLREoMBucmwQOKAnWfGDeIVxlFaqy=YtLREoMBucmwQOKAnWfGDeIVxlFaTN.content.decode('utf-8')
  YtLREoMBucmwQOKAnWfGDeIVxlFaqb =ET.ElementTree(ET.fromstring(YtLREoMBucmwQOKAnWfGDeIVxlFaqy))
  YtLREoMBucmwQOKAnWfGDeIVxlFaqp =YtLREoMBucmwQOKAnWfGDeIVxlFaqb.getroot()
  YtLREoMBucmwQOKAnWfGDeIVxlFaqH=re.match(r'\{.*\}',YtLREoMBucmwQOKAnWfGDeIVxlFaqp.tag)[0] 
  YtLREoMBucmwQOKAnWfGDeIVxlFaqj=YtLREoMBucmwQOKAnWfGDeIVxlFaPi([node for _,node in ET.iterparse(io.StringIO(YtLREoMBucmwQOKAnWfGDeIVxlFaqy),events=['start-ns'])])
  for YtLREoMBucmwQOKAnWfGDeIVxlFaTz,YtLREoMBucmwQOKAnWfGDeIVxlFazi in YtLREoMBucmwQOKAnWfGDeIVxlFaqj.items():
   ET.register_namespace(YtLREoMBucmwQOKAnWfGDeIVxlFaTz,YtLREoMBucmwQOKAnWfGDeIVxlFazi)
  YtLREoMBucmwQOKAnWfGDeIVxlFaqs=YtLREoMBucmwQOKAnWfGDeIVxlFaqp.find(YtLREoMBucmwQOKAnWfGDeIVxlFaqH+'Period')
  for YtLREoMBucmwQOKAnWfGDeIVxlFaqk in YtLREoMBucmwQOKAnWfGDeIVxlFaqs.findall(YtLREoMBucmwQOKAnWfGDeIVxlFaqH+'AdaptationSet'):
   if YtLREoMBucmwQOKAnWfGDeIVxlFaqk.attrib.get('mimeType')=='video/mp4':
    YtLREoMBucmwQOKAnWfGDeIVxlFaqU=0
    for YtLREoMBucmwQOKAnWfGDeIVxlFaqS in YtLREoMBucmwQOKAnWfGDeIVxlFaqk.findall(YtLREoMBucmwQOKAnWfGDeIVxlFaqH+'Representation'):
     YtLREoMBucmwQOKAnWfGDeIVxlFazv=YtLREoMBucmwQOKAnWfGDeIVxlFaPC(YtLREoMBucmwQOKAnWfGDeIVxlFaqS.attrib.get('bandwidth'))
     if YtLREoMBucmwQOKAnWfGDeIVxlFaqU<YtLREoMBucmwQOKAnWfGDeIVxlFazv:YtLREoMBucmwQOKAnWfGDeIVxlFaqU=YtLREoMBucmwQOKAnWfGDeIVxlFazv
    for YtLREoMBucmwQOKAnWfGDeIVxlFaqS in YtLREoMBucmwQOKAnWfGDeIVxlFaqk.findall(YtLREoMBucmwQOKAnWfGDeIVxlFaqH+'Representation'):
     if YtLREoMBucmwQOKAnWfGDeIVxlFaqU>YtLREoMBucmwQOKAnWfGDeIVxlFaPC(YtLREoMBucmwQOKAnWfGDeIVxlFaqS.attrib.get('bandwidth')):
      YtLREoMBucmwQOKAnWfGDeIVxlFaqk.remove(YtLREoMBucmwQOKAnWfGDeIVxlFaqS)
   elif YtLREoMBucmwQOKAnWfGDeIVxlFaqk.attrib.get('mimeType')=='audio/mp4':
    YtLREoMBucmwQOKAnWfGDeIVxlFaqU=0
    for YtLREoMBucmwQOKAnWfGDeIVxlFaqS in YtLREoMBucmwQOKAnWfGDeIVxlFaqk.findall(YtLREoMBucmwQOKAnWfGDeIVxlFaqH+'Representation'):
     YtLREoMBucmwQOKAnWfGDeIVxlFazv=YtLREoMBucmwQOKAnWfGDeIVxlFaPC(YtLREoMBucmwQOKAnWfGDeIVxlFaqS.attrib.get('bandwidth'))
     if YtLREoMBucmwQOKAnWfGDeIVxlFaqU<YtLREoMBucmwQOKAnWfGDeIVxlFazv:YtLREoMBucmwQOKAnWfGDeIVxlFaqU=YtLREoMBucmwQOKAnWfGDeIVxlFazv
    for YtLREoMBucmwQOKAnWfGDeIVxlFaqS in YtLREoMBucmwQOKAnWfGDeIVxlFaqk.findall(YtLREoMBucmwQOKAnWfGDeIVxlFaqH+'Representation'):
     if YtLREoMBucmwQOKAnWfGDeIVxlFaqU>YtLREoMBucmwQOKAnWfGDeIVxlFaPC(YtLREoMBucmwQOKAnWfGDeIVxlFaqS.attrib.get('bandwidth')):
      YtLREoMBucmwQOKAnWfGDeIVxlFaqk.remove(YtLREoMBucmwQOKAnWfGDeIVxlFaqS)
   else:
    continue
  YtLREoMBucmwQOKAnWfGDeIVxlFazT=ET.tostring(YtLREoMBucmwQOKAnWfGDeIVxlFaqp).decode('utf-8')
  YtLREoMBucmwQOKAnWfGDeIVxlFazg='<?xml version="1.0" encoding="UTF-8"?>\n'
  YtLREoMBucmwQOKAnWfGDeIVxlFavX.TextFile_Save(YtLREoMBucmwQOKAnWfGDeIVxlFavX.WV_STREAM_FILENAME,YtLREoMBucmwQOKAnWfGDeIVxlFazg+YtLREoMBucmwQOKAnWfGDeIVxlFazT)
  return YtLREoMBucmwQOKAnWfGDeIVxlFaPg
 def MediaLine_Parse(YtLREoMBucmwQOKAnWfGDeIVxlFavX,YtLREoMBucmwQOKAnWfGDeIVxlFaqr,prefix):
  YtLREoMBucmwQOKAnWfGDeIVxlFaqJ={}
  for YtLREoMBucmwQOKAnWfGDeIVxlFazX in YtLREoMBucmwQOKAnWfGDeIVxlFavg.split(YtLREoMBucmwQOKAnWfGDeIVxlFaqr.replace(prefix+':',''))[1::2]:
   YtLREoMBucmwQOKAnWfGDeIVxlFazq,YtLREoMBucmwQOKAnWfGDeIVxlFazi=YtLREoMBucmwQOKAnWfGDeIVxlFazX.split('=',1)
   YtLREoMBucmwQOKAnWfGDeIVxlFaqJ[YtLREoMBucmwQOKAnWfGDeIVxlFazq.upper()]=YtLREoMBucmwQOKAnWfGDeIVxlFazi.replace('"','').strip()
  return YtLREoMBucmwQOKAnWfGDeIVxlFaqJ
 def GetStreamingURL(YtLREoMBucmwQOKAnWfGDeIVxlFavX,mode,YtLREoMBucmwQOKAnWfGDeIVxlFagS,quality_int,pvrmode='-',playOption={}):
  YtLREoMBucmwQOKAnWfGDeIVxlFazP ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  YtLREoMBucmwQOKAnWfGDeIVxlFazC=[]
  if mode=='LIVE':
   YtLREoMBucmwQOKAnWfGDeIVxlFaTJ =YtLREoMBucmwQOKAnWfGDeIVxlFavX.API_DOMAIN+'/live/channels/'+YtLREoMBucmwQOKAnWfGDeIVxlFagS
   YtLREoMBucmwQOKAnWfGDeIVxlFazr='live'
  elif mode=='VOD':
   YtLREoMBucmwQOKAnWfGDeIVxlFaTJ =YtLREoMBucmwQOKAnWfGDeIVxlFavX.API_DOMAIN+'/fz/vod/contents-detail/'+YtLREoMBucmwQOKAnWfGDeIVxlFagS 
   YtLREoMBucmwQOKAnWfGDeIVxlFazr='vod'
  elif mode=='MOVIE':
   YtLREoMBucmwQOKAnWfGDeIVxlFaTJ =YtLREoMBucmwQOKAnWfGDeIVxlFavX.API_DOMAIN+'/fz/movie/contents/'+YtLREoMBucmwQOKAnWfGDeIVxlFagS
   YtLREoMBucmwQOKAnWfGDeIVxlFazr='movie'
  YtLREoMBucmwQOKAnWfGDeIVxlFazJ={'hdr':'sdr','uhd':'-',}
  try:
   YtLREoMBucmwQOKAnWfGDeIVxlFavN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.GetDefaultParams(login=YtLREoMBucmwQOKAnWfGDeIVxlFaiU)
   YtLREoMBucmwQOKAnWfGDeIVxlFaTN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.callRequestCookies('Get',YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,payload=YtLREoMBucmwQOKAnWfGDeIVxlFaik,params=YtLREoMBucmwQOKAnWfGDeIVxlFavN,headers=YtLREoMBucmwQOKAnWfGDeIVxlFaik,cookies=YtLREoMBucmwQOKAnWfGDeIVxlFaik)
   YtLREoMBucmwQOKAnWfGDeIVxlFaTh=json.loads(YtLREoMBucmwQOKAnWfGDeIVxlFaTN.text)
   YtLREoMBucmwQOKAnWfGDeIVxlFazd=YtLREoMBucmwQOKAnWfGDeIVxlFaTh['qualities']['list']
   if YtLREoMBucmwQOKAnWfGDeIVxlFazd==YtLREoMBucmwQOKAnWfGDeIVxlFaik:return YtLREoMBucmwQOKAnWfGDeIVxlFazP
   for YtLREoMBucmwQOKAnWfGDeIVxlFazN in YtLREoMBucmwQOKAnWfGDeIVxlFazd:
    YtLREoMBucmwQOKAnWfGDeIVxlFazC.append(YtLREoMBucmwQOKAnWfGDeIVxlFaPC(YtLREoMBucmwQOKAnWfGDeIVxlFazN.get('id').rstrip('p')))
   if 'drms' in YtLREoMBucmwQOKAnWfGDeIVxlFaTh:
    if YtLREoMBucmwQOKAnWfGDeIVxlFaTh['drms']:
     YtLREoMBucmwQOKAnWfGDeIVxlFazP['stream_action']='dash' 
   if playOption.get('enable_hdr'):
    if 'mediatypes' in YtLREoMBucmwQOKAnWfGDeIVxlFaTh.get('qualities'):
     for YtLREoMBucmwQOKAnWfGDeIVxlFazh in YtLREoMBucmwQOKAnWfGDeIVxlFaTh.get('qualities').get('mediatypes'):
      if YtLREoMBucmwQOKAnWfGDeIVxlFazh=='HDR10':
       YtLREoMBucmwQOKAnWfGDeIVxlFazJ['hdr']='hdr'
       YtLREoMBucmwQOKAnWfGDeIVxlFazP['stream_action']='dash'
       break
   if playOption.get('enable_uhd'):
    for YtLREoMBucmwQOKAnWfGDeIVxlFazh in YtLREoMBucmwQOKAnWfGDeIVxlFaTh.get('qualities').get('list'):
     if YtLREoMBucmwQOKAnWfGDeIVxlFazh.get('name')=='UHD':
      YtLREoMBucmwQOKAnWfGDeIVxlFazJ['uhd']='uhd'
      break
  except YtLREoMBucmwQOKAnWfGDeIVxlFaPz as exception:
   YtLREoMBucmwQOKAnWfGDeIVxlFaiS(exception)
   return YtLREoMBucmwQOKAnWfGDeIVxlFazP
  YtLREoMBucmwQOKAnWfGDeIVxlFaiS('stream_action : '+YtLREoMBucmwQOKAnWfGDeIVxlFazP['stream_action'])
  try:
   YtLREoMBucmwQOKAnWfGDeIVxlFazy=YtLREoMBucmwQOKAnWfGDeIVxlFavX.CheckQuality(quality_int,YtLREoMBucmwQOKAnWfGDeIVxlFazC)
   YtLREoMBucmwQOKAnWfGDeIVxlFaiS(YtLREoMBucmwQOKAnWfGDeIVxlFazy)
   if YtLREoMBucmwQOKAnWfGDeIVxlFazy<1080:
    YtLREoMBucmwQOKAnWfGDeIVxlFazJ['uhd']='-'
    YtLREoMBucmwQOKAnWfGDeIVxlFazJ['hdr']='sdr'
   if YtLREoMBucmwQOKAnWfGDeIVxlFazJ['uhd']=='uhd':YtLREoMBucmwQOKAnWfGDeIVxlFazy=2160 
   YtLREoMBucmwQOKAnWfGDeIVxlFazb=YtLREoMBucmwQOKAnWfGDeIVxlFaPv(YtLREoMBucmwQOKAnWfGDeIVxlFazy)+'p'
   YtLREoMBucmwQOKAnWfGDeIVxlFaiS(YtLREoMBucmwQOKAnWfGDeIVxlFazb)
   YtLREoMBucmwQOKAnWfGDeIVxlFaTJ='https://delivery.wavve.com/v1/streaming/{}'.format(YtLREoMBucmwQOKAnWfGDeIVxlFazr)
   if YtLREoMBucmwQOKAnWfGDeIVxlFazJ['hdr']=='hdr' or YtLREoMBucmwQOKAnWfGDeIVxlFazJ['uhd']=='uhd':
    YtLREoMBucmwQOKAnWfGDeIVxlFavN={'service':'wavve','contentid':YtLREoMBucmwQOKAnWfGDeIVxlFagS,'audioChannel':'2ch','contenttype':YtLREoMBucmwQOKAnWfGDeIVxlFazr,'hdr':'HDR10','videocodec':'HEVC','audiocodec':'AAC','issurround':'y','format':'normal','withinsubtitle':'n','action':YtLREoMBucmwQOKAnWfGDeIVxlFazP['stream_action'],'protocol':YtLREoMBucmwQOKAnWfGDeIVxlFazP['stream_action'],'quality':YtLREoMBucmwQOKAnWfGDeIVxlFazb,'modelid':'SHIELD Android TV','guid':YtLREoMBucmwQOKAnWfGDeIVxlFavX.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n',}
    YtLREoMBucmwQOKAnWfGDeIVxlFavN.update(YtLREoMBucmwQOKAnWfGDeIVxlFavX.GetDefaultParams_AND())
   else:
    YtLREoMBucmwQOKAnWfGDeIVxlFavN={'service':'wavve','contentid':YtLREoMBucmwQOKAnWfGDeIVxlFagS,'audioChannel':'2ch','contenttype':YtLREoMBucmwQOKAnWfGDeIVxlFazr,'hdr':'sdr','videocodec':'avc','audiocodec':'aac','issurround':'n','format':'normal','withinsubtitle':'n','action':YtLREoMBucmwQOKAnWfGDeIVxlFazP['stream_action'],'protocol':YtLREoMBucmwQOKAnWfGDeIVxlFazP['stream_action'],'quality':YtLREoMBucmwQOKAnWfGDeIVxlFazb,'deviceModelId':'Windows 10','guid':YtLREoMBucmwQOKAnWfGDeIVxlFavX.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n',}
    '''
    params = {'contentid' : contentid, 'contenttype' : contenttype, 'quality' : quality_param, ###### if login=False : 체크 미비 (auto, 1080p) ###### 'deviceModelId' : 'Windows 10', 'guid' : self.WV['cookies']['uuid'], # self.GetGUID(guidType=2), 'lastplayid' : '', #self.guid 'authtype' : 'cookie', 'isabr' : 'y', 'ishevc' : 'n', 'action' : url_info['stream_action'], # 기본 hls / DRM dash ##### 'protocol' : url_info['stream_action'], # hls ? 확인필요 'hdr' : 'sdr', # hdr 'videocodec' : 'avc', 'audiocodec' : 'aac', 'issurround' : 'n', 'format' : 'normal', 'withinsubtitle' : 'n', }
    '''    
    YtLREoMBucmwQOKAnWfGDeIVxlFavN.update(YtLREoMBucmwQOKAnWfGDeIVxlFavX.GetDefaultParams(login=YtLREoMBucmwQOKAnWfGDeIVxlFaPg))
   YtLREoMBucmwQOKAnWfGDeIVxlFaTP={'wavve-credential':YtLREoMBucmwQOKAnWfGDeIVxlFavX.WV['cookies']['credential'],}
   YtLREoMBucmwQOKAnWfGDeIVxlFaTN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.callRequestCookies('Get',YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,payload=YtLREoMBucmwQOKAnWfGDeIVxlFaik,params=YtLREoMBucmwQOKAnWfGDeIVxlFavN,headers=YtLREoMBucmwQOKAnWfGDeIVxlFaTP,cookies=YtLREoMBucmwQOKAnWfGDeIVxlFaik)
   YtLREoMBucmwQOKAnWfGDeIVxlFaTh=json.loads(YtLREoMBucmwQOKAnWfGDeIVxlFaTN.text)
   YtLREoMBucmwQOKAnWfGDeIVxlFazP['stream_url']=YtLREoMBucmwQOKAnWfGDeIVxlFaTh['playurl']
   if YtLREoMBucmwQOKAnWfGDeIVxlFazP['stream_url']==YtLREoMBucmwQOKAnWfGDeIVxlFaik:return YtLREoMBucmwQOKAnWfGDeIVxlFazP
   YtLREoMBucmwQOKAnWfGDeIVxlFazP['stream_cookie']=YtLREoMBucmwQOKAnWfGDeIVxlFavX.make_str_ToCookie(YtLREoMBucmwQOKAnWfGDeIVxlFaTh['awscookie'])
   YtLREoMBucmwQOKAnWfGDeIVxlFazP['stream_drm'] =YtLREoMBucmwQOKAnWfGDeIVxlFaTh['drm']
   if 'previewmsg' in YtLREoMBucmwQOKAnWfGDeIVxlFaTh['preview']:YtLREoMBucmwQOKAnWfGDeIVxlFazP['stream_preview']=YtLREoMBucmwQOKAnWfGDeIVxlFaTh['preview']['previewmsg']
   if 'subtitles' in YtLREoMBucmwQOKAnWfGDeIVxlFaTh:
    for YtLREoMBucmwQOKAnWfGDeIVxlFazp in YtLREoMBucmwQOKAnWfGDeIVxlFaTh['subtitles']:
     if YtLREoMBucmwQOKAnWfGDeIVxlFazp.get('languagecode')=='ko':
      YtLREoMBucmwQOKAnWfGDeIVxlFazP['stream_vtt']=YtLREoMBucmwQOKAnWfGDeIVxlFazp.get('url')
      break
    if YtLREoMBucmwQOKAnWfGDeIVxlFazP['stream_vtt']=='':
     for YtLREoMBucmwQOKAnWfGDeIVxlFazp in YtLREoMBucmwQOKAnWfGDeIVxlFaTh['subtitles']:
      if YtLREoMBucmwQOKAnWfGDeIVxlFazp.get('languagecode')=='ko_cc':
       YtLREoMBucmwQOKAnWfGDeIVxlFazP['stream_vtt']=YtLREoMBucmwQOKAnWfGDeIVxlFazp.get('url')
       break
   YtLREoMBucmwQOKAnWfGDeIVxlFazP['playParam']=YtLREoMBucmwQOKAnWfGDeIVxlFazJ 
  except YtLREoMBucmwQOKAnWfGDeIVxlFaPz as exception:
   YtLREoMBucmwQOKAnWfGDeIVxlFaiS(exception)
  return YtLREoMBucmwQOKAnWfGDeIVxlFazP 
 def GetSportsURL(YtLREoMBucmwQOKAnWfGDeIVxlFavX,YtLREoMBucmwQOKAnWfGDeIVxlFagS,quality_int):
  YtLREoMBucmwQOKAnWfGDeIVxlFazP ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  YtLREoMBucmwQOKAnWfGDeIVxlFazC=[]
  try:
   YtLREoMBucmwQOKAnWfGDeIVxlFaTJ=YtLREoMBucmwQOKAnWfGDeIVxlFavX.API_DOMAIN+'/streaming/other'
   YtLREoMBucmwQOKAnWfGDeIVxlFavN={'contentid':YtLREoMBucmwQOKAnWfGDeIVxlFagS,'contenttype':'live','action':YtLREoMBucmwQOKAnWfGDeIVxlFazP['stream_action'],'quality':YtLREoMBucmwQOKAnWfGDeIVxlFaPv(quality_int)+'p','deviceModelId':'Windows 10','guid':YtLREoMBucmwQOKAnWfGDeIVxlFavX.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n',}
   YtLREoMBucmwQOKAnWfGDeIVxlFavN.update(YtLREoMBucmwQOKAnWfGDeIVxlFavX.GetDefaultParams(login=YtLREoMBucmwQOKAnWfGDeIVxlFaPg))
   YtLREoMBucmwQOKAnWfGDeIVxlFaTN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.callRequestCookies('Get',YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,payload=YtLREoMBucmwQOKAnWfGDeIVxlFaik,params=YtLREoMBucmwQOKAnWfGDeIVxlFavN,headers=YtLREoMBucmwQOKAnWfGDeIVxlFaik,cookies=YtLREoMBucmwQOKAnWfGDeIVxlFaik)
   YtLREoMBucmwQOKAnWfGDeIVxlFaTh=json.loads(YtLREoMBucmwQOKAnWfGDeIVxlFaTN.text)
   YtLREoMBucmwQOKAnWfGDeIVxlFazP['stream_url']=YtLREoMBucmwQOKAnWfGDeIVxlFaTh['playurl']
   if YtLREoMBucmwQOKAnWfGDeIVxlFazP['stream_url']==YtLREoMBucmwQOKAnWfGDeIVxlFaik:return YtLREoMBucmwQOKAnWfGDeIVxlFazP
   YtLREoMBucmwQOKAnWfGDeIVxlFazP['stream_cookie']=YtLREoMBucmwQOKAnWfGDeIVxlFaTh['awscookie']
  except YtLREoMBucmwQOKAnWfGDeIVxlFaPz as exception:
   YtLREoMBucmwQOKAnWfGDeIVxlFaiS(exception)
  return YtLREoMBucmwQOKAnWfGDeIVxlFazP
 def make_viewdate(YtLREoMBucmwQOKAnWfGDeIVxlFavX):
  YtLREoMBucmwQOKAnWfGDeIVxlFazH =YtLREoMBucmwQOKAnWfGDeIVxlFavX.Get_Now_Datetime()
  YtLREoMBucmwQOKAnWfGDeIVxlFazj =YtLREoMBucmwQOKAnWfGDeIVxlFazH+datetime.timedelta(days=-1)
  YtLREoMBucmwQOKAnWfGDeIVxlFazs =YtLREoMBucmwQOKAnWfGDeIVxlFazH+datetime.timedelta(days=1)
  YtLREoMBucmwQOKAnWfGDeIVxlFazk=[YtLREoMBucmwQOKAnWfGDeIVxlFazH.strftime('%Y%m%d'),YtLREoMBucmwQOKAnWfGDeIVxlFazs.strftime('%Y%m%d'),]
  return YtLREoMBucmwQOKAnWfGDeIVxlFazk
 def Get_Sports_Gamelist(YtLREoMBucmwQOKAnWfGDeIVxlFavX):
  YtLREoMBucmwQOKAnWfGDeIVxlFazU =YtLREoMBucmwQOKAnWfGDeIVxlFavX.make_viewdate()
  YtLREoMBucmwQOKAnWfGDeIVxlFazS=[]
  YtLREoMBucmwQOKAnWfGDeIVxlFaiv =[]
  for YtLREoMBucmwQOKAnWfGDeIVxlFaiT in YtLREoMBucmwQOKAnWfGDeIVxlFazU:
   YtLREoMBucmwQOKAnWfGDeIVxlFaig=YtLREoMBucmwQOKAnWfGDeIVxlFaiT[:6]
   if YtLREoMBucmwQOKAnWfGDeIVxlFaig not in YtLREoMBucmwQOKAnWfGDeIVxlFazS:
    YtLREoMBucmwQOKAnWfGDeIVxlFazS.append(YtLREoMBucmwQOKAnWfGDeIVxlFaig)
  try:
   YtLREoMBucmwQOKAnWfGDeIVxlFaTJ='https://annexapi.wavve.com/skb/baseball/teammonthlycalendarlist'
   YtLREoMBucmwQOKAnWfGDeIVxlFavN={'IF':'IF-PORG-002','m':'getTeamCalendarListBand','response_format':'json','spo_itm_cd':'KBO','teamcd':'all','tgroup':'B','tvalue':'BC123','ver':'2.0',}
   YtLREoMBucmwQOKAnWfGDeIVxlFavN.update(YtLREoMBucmwQOKAnWfGDeIVxlFavX.GetDefaultParams(login=YtLREoMBucmwQOKAnWfGDeIVxlFaiU))
   for YtLREoMBucmwQOKAnWfGDeIVxlFaiX in YtLREoMBucmwQOKAnWfGDeIVxlFazS:
    YtLREoMBucmwQOKAnWfGDeIVxlFavN['date']=YtLREoMBucmwQOKAnWfGDeIVxlFaiX
    YtLREoMBucmwQOKAnWfGDeIVxlFaTN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.callRequestCookies('Get',YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,payload=YtLREoMBucmwQOKAnWfGDeIVxlFaik,params=YtLREoMBucmwQOKAnWfGDeIVxlFavN,headers=YtLREoMBucmwQOKAnWfGDeIVxlFaik,cookies=YtLREoMBucmwQOKAnWfGDeIVxlFaik)
    YtLREoMBucmwQOKAnWfGDeIVxlFaTh=json.loads(YtLREoMBucmwQOKAnWfGDeIVxlFaTN.text)
    YtLREoMBucmwQOKAnWfGDeIVxlFagv=YtLREoMBucmwQOKAnWfGDeIVxlFaTh['cell_toplist']['celllist']
    for YtLREoMBucmwQOKAnWfGDeIVxlFagT in YtLREoMBucmwQOKAnWfGDeIVxlFagv:
     YtLREoMBucmwQOKAnWfGDeIVxlFaiq=YtLREoMBucmwQOKAnWfGDeIVxlFagT.get('game_date')
     YtLREoMBucmwQOKAnWfGDeIVxlFaiz =YtLREoMBucmwQOKAnWfGDeIVxlFagT.get('svc_id')
     if YtLREoMBucmwQOKAnWfGDeIVxlFaiz=='':continue
     if YtLREoMBucmwQOKAnWfGDeIVxlFaiq in YtLREoMBucmwQOKAnWfGDeIVxlFazU:
      YtLREoMBucmwQOKAnWfGDeIVxlFaiP=YtLREoMBucmwQOKAnWfGDeIVxlFagT.get('game_status') 
      YtLREoMBucmwQOKAnWfGDeIVxlFaiC =YtLREoMBucmwQOKAnWfGDeIVxlFagT.get('title_list')[0].get('text')
      YtLREoMBucmwQOKAnWfGDeIVxlFaiq =YtLREoMBucmwQOKAnWfGDeIVxlFaiq[:4]+'-'+YtLREoMBucmwQOKAnWfGDeIVxlFaiq[4:6]+'-'+YtLREoMBucmwQOKAnWfGDeIVxlFaiq[-2:]
      YtLREoMBucmwQOKAnWfGDeIVxlFair =YtLREoMBucmwQOKAnWfGDeIVxlFagT.get('game_time')
      YtLREoMBucmwQOKAnWfGDeIVxlFair =YtLREoMBucmwQOKAnWfGDeIVxlFair[:2]+':'+YtLREoMBucmwQOKAnWfGDeIVxlFair[-2:]
      YtLREoMBucmwQOKAnWfGDeIVxlFagX={'game_date':YtLREoMBucmwQOKAnWfGDeIVxlFaiq,'game_time':YtLREoMBucmwQOKAnWfGDeIVxlFair,'svc_id':YtLREoMBucmwQOKAnWfGDeIVxlFaiz,'away_team':YtLREoMBucmwQOKAnWfGDeIVxlFagT.get('away_team').get('team_name'),'home_team':YtLREoMBucmwQOKAnWfGDeIVxlFagT.get('home_team').get('team_name'),'game_status':YtLREoMBucmwQOKAnWfGDeIVxlFaiP,'game_place':YtLREoMBucmwQOKAnWfGDeIVxlFagT.get('game_place'),}
      YtLREoMBucmwQOKAnWfGDeIVxlFaiv.append(YtLREoMBucmwQOKAnWfGDeIVxlFagX)
  except YtLREoMBucmwQOKAnWfGDeIVxlFaPz as exception:
   YtLREoMBucmwQOKAnWfGDeIVxlFaiS(exception)
   return[]
  YtLREoMBucmwQOKAnWfGDeIVxlFaiJ=[]
  for i in YtLREoMBucmwQOKAnWfGDeIVxlFaPX(2):
   for YtLREoMBucmwQOKAnWfGDeIVxlFagT in YtLREoMBucmwQOKAnWfGDeIVxlFaiv:
    if i==0 and YtLREoMBucmwQOKAnWfGDeIVxlFagT.get('game_status')=='LIVE':
     YtLREoMBucmwQOKAnWfGDeIVxlFaiJ.append(YtLREoMBucmwQOKAnWfGDeIVxlFagT)
    elif i==1 and YtLREoMBucmwQOKAnWfGDeIVxlFagT.get('game_status')!='LIVE':
     YtLREoMBucmwQOKAnWfGDeIVxlFaiJ.append(YtLREoMBucmwQOKAnWfGDeIVxlFagT)
  return YtLREoMBucmwQOKAnWfGDeIVxlFaiJ
 def GetBookmarkInfo(YtLREoMBucmwQOKAnWfGDeIVxlFavX,YtLREoMBucmwQOKAnWfGDeIVxlFagb,YtLREoMBucmwQOKAnWfGDeIVxlFagy,YtLREoMBucmwQOKAnWfGDeIVxlFazr):
  if YtLREoMBucmwQOKAnWfGDeIVxlFagy=='tvshow':
   if YtLREoMBucmwQOKAnWfGDeIVxlFazr=='contentid':
    YtLREoMBucmwQOKAnWfGDeIVxlFagS=YtLREoMBucmwQOKAnWfGDeIVxlFagb
    YtLREoMBucmwQOKAnWfGDeIVxlFagb =YtLREoMBucmwQOKAnWfGDeIVxlFavX.ContentidToSeasonid(YtLREoMBucmwQOKAnWfGDeIVxlFagS)
   else:
    YtLREoMBucmwQOKAnWfGDeIVxlFagS=YtLREoMBucmwQOKAnWfGDeIVxlFavX.ProgramidToContentid(YtLREoMBucmwQOKAnWfGDeIVxlFagb)
  else:
   YtLREoMBucmwQOKAnWfGDeIVxlFagS=''
  YtLREoMBucmwQOKAnWfGDeIVxlFaid={'indexinfo':{'ott':'wavve','videoid':YtLREoMBucmwQOKAnWfGDeIVxlFagb,'vidtype':YtLREoMBucmwQOKAnWfGDeIVxlFagy,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':YtLREoMBucmwQOKAnWfGDeIVxlFagy,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if YtLREoMBucmwQOKAnWfGDeIVxlFagy=='tvshow':
   YtLREoMBucmwQOKAnWfGDeIVxlFaTJ=YtLREoMBucmwQOKAnWfGDeIVxlFavX.API_DOMAIN+'/fz/vod/contents/'+YtLREoMBucmwQOKAnWfGDeIVxlFagS 
   YtLREoMBucmwQOKAnWfGDeIVxlFavN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.GetDefaultParams(login=YtLREoMBucmwQOKAnWfGDeIVxlFaiU)
   YtLREoMBucmwQOKAnWfGDeIVxlFaTN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.callRequestCookies('Get',YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,payload=YtLREoMBucmwQOKAnWfGDeIVxlFaik,params=YtLREoMBucmwQOKAnWfGDeIVxlFavN,headers=YtLREoMBucmwQOKAnWfGDeIVxlFaik,cookies=YtLREoMBucmwQOKAnWfGDeIVxlFaik)
   YtLREoMBucmwQOKAnWfGDeIVxlFaTh=json.loads(YtLREoMBucmwQOKAnWfGDeIVxlFaTN.text)
   if not('programtitle' in YtLREoMBucmwQOKAnWfGDeIVxlFaTh):return{}
   YtLREoMBucmwQOKAnWfGDeIVxlFaiN=YtLREoMBucmwQOKAnWfGDeIVxlFaTh
   YtLREoMBucmwQOKAnWfGDeIVxlFaih=YtLREoMBucmwQOKAnWfGDeIVxlFaiN.get('programtitle')
   YtLREoMBucmwQOKAnWfGDeIVxlFaid['saveinfo']['infoLabels']['title']=YtLREoMBucmwQOKAnWfGDeIVxlFaih
   if YtLREoMBucmwQOKAnWfGDeIVxlFaiN.get('targetage')=='18' or YtLREoMBucmwQOKAnWfGDeIVxlFaiN.get('targetage')=='19' or YtLREoMBucmwQOKAnWfGDeIVxlFaiN.get('targetage')=='21':
    YtLREoMBucmwQOKAnWfGDeIVxlFaih +=u' (%s)'%(YtLREoMBucmwQOKAnWfGDeIVxlFaiN.get('targetage'))
   YtLREoMBucmwQOKAnWfGDeIVxlFaid['saveinfo']['title'] =YtLREoMBucmwQOKAnWfGDeIVxlFaih
   YtLREoMBucmwQOKAnWfGDeIVxlFaid['saveinfo']['infoLabels']['mpaa'] =YtLREoMBucmwQOKAnWfGDeIVxlFaiN.get('targetage')
   YtLREoMBucmwQOKAnWfGDeIVxlFaid['saveinfo']['infoLabels']['plot'] =YtLREoMBucmwQOKAnWfGDeIVxlFavX.Get_ChangeText(YtLREoMBucmwQOKAnWfGDeIVxlFaiN.get('programsynopsis'))
   YtLREoMBucmwQOKAnWfGDeIVxlFaid['saveinfo']['infoLabels']['studio'] =YtLREoMBucmwQOKAnWfGDeIVxlFaiN.get('channelname')
   if YtLREoMBucmwQOKAnWfGDeIVxlFaiN.get('firstreleaseyear')!='':YtLREoMBucmwQOKAnWfGDeIVxlFaid['saveinfo']['infoLabels']['year'] =YtLREoMBucmwQOKAnWfGDeIVxlFaiN.get('firstreleaseyear')
   if YtLREoMBucmwQOKAnWfGDeIVxlFaiN.get('firstreleasedate')!='':YtLREoMBucmwQOKAnWfGDeIVxlFaid['saveinfo']['infoLabels']['premiered']=YtLREoMBucmwQOKAnWfGDeIVxlFaiN.get('firstreleasedate')
   if YtLREoMBucmwQOKAnWfGDeIVxlFaiN.get('genretext') !='':YtLREoMBucmwQOKAnWfGDeIVxlFaid['saveinfo']['infoLabels']['genre'] =[YtLREoMBucmwQOKAnWfGDeIVxlFaiN.get('genretext')]
   YtLREoMBucmwQOKAnWfGDeIVxlFaiy=[]
   for YtLREoMBucmwQOKAnWfGDeIVxlFaib in YtLREoMBucmwQOKAnWfGDeIVxlFaiN['actors']['list']:YtLREoMBucmwQOKAnWfGDeIVxlFaiy.append(YtLREoMBucmwQOKAnWfGDeIVxlFaib.get('text'))
   if YtLREoMBucmwQOKAnWfGDeIVxlFaPq(YtLREoMBucmwQOKAnWfGDeIVxlFaiy)>0:
    if YtLREoMBucmwQOKAnWfGDeIVxlFaiy[0]!='':YtLREoMBucmwQOKAnWfGDeIVxlFaid['saveinfo']['infoLabels']['cast']=YtLREoMBucmwQOKAnWfGDeIVxlFaiy
   YtLREoMBucmwQOKAnWfGDeIVxlFaXy =''
   YtLREoMBucmwQOKAnWfGDeIVxlFaXb =''
   YtLREoMBucmwQOKAnWfGDeIVxlFaXp=''
   if YtLREoMBucmwQOKAnWfGDeIVxlFaiN.get('programposterimage')!='':YtLREoMBucmwQOKAnWfGDeIVxlFaXy =YtLREoMBucmwQOKAnWfGDeIVxlFavX.HTTPTAG+YtLREoMBucmwQOKAnWfGDeIVxlFaiN.get('programposterimage')
   if YtLREoMBucmwQOKAnWfGDeIVxlFaiN.get('programimage') !='':YtLREoMBucmwQOKAnWfGDeIVxlFaXb =YtLREoMBucmwQOKAnWfGDeIVxlFavX.HTTPTAG+YtLREoMBucmwQOKAnWfGDeIVxlFaiN.get('programimage')
   if YtLREoMBucmwQOKAnWfGDeIVxlFaiN.get('programcircleimage')!='':YtLREoMBucmwQOKAnWfGDeIVxlFaXp=YtLREoMBucmwQOKAnWfGDeIVxlFavX.HTTPTAG+YtLREoMBucmwQOKAnWfGDeIVxlFaiN.get('programcircleimage')
   if 'poster_default' in YtLREoMBucmwQOKAnWfGDeIVxlFaXy:
    YtLREoMBucmwQOKAnWfGDeIVxlFaXy =YtLREoMBucmwQOKAnWfGDeIVxlFaXb
    YtLREoMBucmwQOKAnWfGDeIVxlFaXp=''
   YtLREoMBucmwQOKAnWfGDeIVxlFaid['saveinfo']['thumbnail']['poster']=YtLREoMBucmwQOKAnWfGDeIVxlFaXy
   YtLREoMBucmwQOKAnWfGDeIVxlFaid['saveinfo']['thumbnail']['thumb']=YtLREoMBucmwQOKAnWfGDeIVxlFaXb
   YtLREoMBucmwQOKAnWfGDeIVxlFaid['saveinfo']['thumbnail']['clearlogo']=YtLREoMBucmwQOKAnWfGDeIVxlFaXp
   YtLREoMBucmwQOKAnWfGDeIVxlFaid['saveinfo']['thumbnail']['fanart']=YtLREoMBucmwQOKAnWfGDeIVxlFaXb
  else:
   YtLREoMBucmwQOKAnWfGDeIVxlFaTJ=YtLREoMBucmwQOKAnWfGDeIVxlFavX.API_DOMAIN+'/movie/contents/'+YtLREoMBucmwQOKAnWfGDeIVxlFagb 
   YtLREoMBucmwQOKAnWfGDeIVxlFavN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.GetDefaultParams(login=YtLREoMBucmwQOKAnWfGDeIVxlFaiU)
   YtLREoMBucmwQOKAnWfGDeIVxlFaTN=YtLREoMBucmwQOKAnWfGDeIVxlFavX.callRequestCookies('Get',YtLREoMBucmwQOKAnWfGDeIVxlFaTJ,payload=YtLREoMBucmwQOKAnWfGDeIVxlFaik,params=YtLREoMBucmwQOKAnWfGDeIVxlFavN,headers=YtLREoMBucmwQOKAnWfGDeIVxlFaik,cookies=YtLREoMBucmwQOKAnWfGDeIVxlFaik)
   YtLREoMBucmwQOKAnWfGDeIVxlFaTh=json.loads(YtLREoMBucmwQOKAnWfGDeIVxlFaTN.text)
   if not('title' in YtLREoMBucmwQOKAnWfGDeIVxlFaTh):return{}
   YtLREoMBucmwQOKAnWfGDeIVxlFaiN=YtLREoMBucmwQOKAnWfGDeIVxlFaTh
   YtLREoMBucmwQOKAnWfGDeIVxlFaih=YtLREoMBucmwQOKAnWfGDeIVxlFaiN.get('title')
   YtLREoMBucmwQOKAnWfGDeIVxlFaid['saveinfo']['infoLabels']['title']=YtLREoMBucmwQOKAnWfGDeIVxlFaih
   if YtLREoMBucmwQOKAnWfGDeIVxlFaiN.get('targetage')=='18' or YtLREoMBucmwQOKAnWfGDeIVxlFaiN.get('targetage')=='19' or YtLREoMBucmwQOKAnWfGDeIVxlFaiN.get('targetage')=='21':
    YtLREoMBucmwQOKAnWfGDeIVxlFaih +=u' (%s)'%(YtLREoMBucmwQOKAnWfGDeIVxlFaiN.get('targetage'))
   YtLREoMBucmwQOKAnWfGDeIVxlFaid['saveinfo']['title'] =YtLREoMBucmwQOKAnWfGDeIVxlFaih
   YtLREoMBucmwQOKAnWfGDeIVxlFaid['saveinfo']['infoLabels']['mpaa'] =YtLREoMBucmwQOKAnWfGDeIVxlFaiN.get('targetage')
   YtLREoMBucmwQOKAnWfGDeIVxlFaid['saveinfo']['infoLabels']['plot'] =YtLREoMBucmwQOKAnWfGDeIVxlFavX.Get_ChangeText(YtLREoMBucmwQOKAnWfGDeIVxlFaiN.get('synopsis'))
   YtLREoMBucmwQOKAnWfGDeIVxlFaid['saveinfo']['infoLabels']['duration']=YtLREoMBucmwQOKAnWfGDeIVxlFaiN.get('playtime')
   YtLREoMBucmwQOKAnWfGDeIVxlFaid['saveinfo']['infoLabels']['country']=YtLREoMBucmwQOKAnWfGDeIVxlFaiN.get('country')
   YtLREoMBucmwQOKAnWfGDeIVxlFaid['saveinfo']['infoLabels']['studio'] =YtLREoMBucmwQOKAnWfGDeIVxlFaiN.get('cpname')
   if YtLREoMBucmwQOKAnWfGDeIVxlFaiN.get('releasedate')!='':
    YtLREoMBucmwQOKAnWfGDeIVxlFaid['saveinfo']['infoLabels']['year'] =YtLREoMBucmwQOKAnWfGDeIVxlFaiN.get('releasedate')[:4]
    YtLREoMBucmwQOKAnWfGDeIVxlFaid['saveinfo']['infoLabels']['premiered']=YtLREoMBucmwQOKAnWfGDeIVxlFaiN.get('releasedate')
   YtLREoMBucmwQOKAnWfGDeIVxlFaiy=[]
   for YtLREoMBucmwQOKAnWfGDeIVxlFaib in YtLREoMBucmwQOKAnWfGDeIVxlFaiN['actors']['list']:YtLREoMBucmwQOKAnWfGDeIVxlFaiy.append(YtLREoMBucmwQOKAnWfGDeIVxlFaib.get('text'))
   if YtLREoMBucmwQOKAnWfGDeIVxlFaPq(YtLREoMBucmwQOKAnWfGDeIVxlFaiy)>0:
    if YtLREoMBucmwQOKAnWfGDeIVxlFaiy[0]!='':YtLREoMBucmwQOKAnWfGDeIVxlFaid['saveinfo']['infoLabels']['cast']=YtLREoMBucmwQOKAnWfGDeIVxlFaiy
   YtLREoMBucmwQOKAnWfGDeIVxlFaip=[]
   for YtLREoMBucmwQOKAnWfGDeIVxlFaiH in YtLREoMBucmwQOKAnWfGDeIVxlFaiN['directors']['list']:YtLREoMBucmwQOKAnWfGDeIVxlFaip.append(YtLREoMBucmwQOKAnWfGDeIVxlFaiH.get('text'))
   if YtLREoMBucmwQOKAnWfGDeIVxlFaPq(YtLREoMBucmwQOKAnWfGDeIVxlFaip)>0:
    if YtLREoMBucmwQOKAnWfGDeIVxlFaip[0]!='':YtLREoMBucmwQOKAnWfGDeIVxlFaid['saveinfo']['infoLabels']['director']=YtLREoMBucmwQOKAnWfGDeIVxlFaip
   YtLREoMBucmwQOKAnWfGDeIVxlFaTk=[]
   for YtLREoMBucmwQOKAnWfGDeIVxlFaij in YtLREoMBucmwQOKAnWfGDeIVxlFaiN['genre']['list']:YtLREoMBucmwQOKAnWfGDeIVxlFaTk.append(YtLREoMBucmwQOKAnWfGDeIVxlFaij.get('text'))
   if YtLREoMBucmwQOKAnWfGDeIVxlFaPq(YtLREoMBucmwQOKAnWfGDeIVxlFaTk)>0:
    if YtLREoMBucmwQOKAnWfGDeIVxlFaTk[0]!='':YtLREoMBucmwQOKAnWfGDeIVxlFaid['saveinfo']['infoLabels']['genre']=YtLREoMBucmwQOKAnWfGDeIVxlFaTk
   YtLREoMBucmwQOKAnWfGDeIVxlFaXy ='https://%s'%YtLREoMBucmwQOKAnWfGDeIVxlFaiN['image']
   YtLREoMBucmwQOKAnWfGDeIVxlFaid['saveinfo']['thumbnail']['poster'] =YtLREoMBucmwQOKAnWfGDeIVxlFaXy
   YtLREoMBucmwQOKAnWfGDeIVxlFaid['saveinfo']['thumbnail']['thumb'] =YtLREoMBucmwQOKAnWfGDeIVxlFaXy
  return YtLREoMBucmwQOKAnWfGDeIVxlFaid
# Created by pyminifier (https://github.com/liftoff/pyminifier)
