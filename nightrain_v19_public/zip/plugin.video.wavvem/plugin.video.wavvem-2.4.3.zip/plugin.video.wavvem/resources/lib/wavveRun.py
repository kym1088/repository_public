__author__="NightRain"
fGnKoFzQxuVWaXORPJgMrvwSDsEImU=object
fGnKoFzQxuVWaXORPJgMrvwSDsEImt=None
fGnKoFzQxuVWaXORPJgMrvwSDsEImj=int
fGnKoFzQxuVWaXORPJgMrvwSDsEImN=True
fGnKoFzQxuVWaXORPJgMrvwSDsEImC=False
fGnKoFzQxuVWaXORPJgMrvwSDsEImi=type
fGnKoFzQxuVWaXORPJgMrvwSDsEImy=dict
fGnKoFzQxuVWaXORPJgMrvwSDsEImp=getattr
fGnKoFzQxuVWaXORPJgMrvwSDsEImc=list
fGnKoFzQxuVWaXORPJgMrvwSDsEImH=len
fGnKoFzQxuVWaXORPJgMrvwSDsEIml=range
fGnKoFzQxuVWaXORPJgMrvwSDsEImB=str
fGnKoFzQxuVWaXORPJgMrvwSDsEImk=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import json
fGnKoFzQxuVWaXORPJgMrvwSDsEIdq=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://apis.wavve.com/v1/multiband/GN51','icon':'home.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&uicode=VN500','page':'1','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?WeekDay=all&broadcastid=1390539&contenttype=vod&genre=01&orderby=viewtime&uicode=VN4&uiparent=FN0&uirank=0&uitype=VN4','page':'1','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?WeekDay=all&broadcastid=1311034&contenttype=vod&genre=02&orderby=viewtime&uicode=VN3&uiparent=FN0&uirank=0&uitype=VN3','page':'1','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'CN21','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'vod09','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'vod09','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'4','sType':'movie','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'4','sType':'movie','orderby':'modifydate','ordernm':'업데이트순','icon':''},{'title':'프로야구 - 경기중 시청가능','mode':'GAME_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'(웨이브) 검색','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'(웨이브) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
fGnKoFzQxuVWaXORPJgMrvwSDsEIdY=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
fGnKoFzQxuVWaXORPJgMrvwSDsEIdT=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
fGnKoFzQxuVWaXORPJgMrvwSDsEIde={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
fGnKoFzQxuVWaXORPJgMrvwSDsEIdh =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
fGnKoFzQxuVWaXORPJgMrvwSDsEIdm=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_searched.txt'))
from wavveCore import*
class fGnKoFzQxuVWaXORPJgMrvwSDsEIdL(fGnKoFzQxuVWaXORPJgMrvwSDsEImU):
 def __init__(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA,fGnKoFzQxuVWaXORPJgMrvwSDsEIdb,fGnKoFzQxuVWaXORPJgMrvwSDsEIdU,fGnKoFzQxuVWaXORPJgMrvwSDsEIdt):
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdA._addon_url =fGnKoFzQxuVWaXORPJgMrvwSDsEIdb
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdA._addon_handle=fGnKoFzQxuVWaXORPJgMrvwSDsEIdU
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.main_params =fGnKoFzQxuVWaXORPJgMrvwSDsEIdt
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj =vFMAyWcljmNwSGLsCTRHEUiIkDBQzq() 
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.WV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_stream(mpd,m3u8)'))
 def addon_noti(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA,sting):
  try:
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdN=xbmcgui.Dialog()
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdN.notification(__addonname__,sting)
  except:
   fGnKoFzQxuVWaXORPJgMrvwSDsEImt
 def addon_log(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA,string):
  try:
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdC=string.encode('utf-8','ignore')
  except:
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdC='addonException: addon_log'
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdi=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,fGnKoFzQxuVWaXORPJgMrvwSDsEIdC),level=fGnKoFzQxuVWaXORPJgMrvwSDsEIdi)
 def get_keyboard_input(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA,fGnKoFzQxuVWaXORPJgMrvwSDsEILj):
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdy=fGnKoFzQxuVWaXORPJgMrvwSDsEImt
  kb=xbmc.Keyboard()
  kb.setHeading(fGnKoFzQxuVWaXORPJgMrvwSDsEILj)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdy=kb.getText()
  return fGnKoFzQxuVWaXORPJgMrvwSDsEIdy
 def get_settings_account(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA):
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdp =__addon__.getSetting('id')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdc =__addon__.getSetting('pw')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdH=fGnKoFzQxuVWaXORPJgMrvwSDsEImj(__addon__.getSetting('selected_profile'))
  return(fGnKoFzQxuVWaXORPJgMrvwSDsEIdp,fGnKoFzQxuVWaXORPJgMrvwSDsEIdc,fGnKoFzQxuVWaXORPJgMrvwSDsEIdH)
 def get_settings_totalsearch(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA):
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdl =fGnKoFzQxuVWaXORPJgMrvwSDsEImN if __addon__.getSetting('local_search')=='true' else fGnKoFzQxuVWaXORPJgMrvwSDsEImC
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdB=fGnKoFzQxuVWaXORPJgMrvwSDsEImN if __addon__.getSetting('local_history')=='true' else fGnKoFzQxuVWaXORPJgMrvwSDsEImC
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdk =fGnKoFzQxuVWaXORPJgMrvwSDsEImN if __addon__.getSetting('total_search')=='true' else fGnKoFzQxuVWaXORPJgMrvwSDsEImC
  fGnKoFzQxuVWaXORPJgMrvwSDsEILd=fGnKoFzQxuVWaXORPJgMrvwSDsEImN if __addon__.getSetting('total_history')=='true' else fGnKoFzQxuVWaXORPJgMrvwSDsEImC
  fGnKoFzQxuVWaXORPJgMrvwSDsEILq=fGnKoFzQxuVWaXORPJgMrvwSDsEImN if __addon__.getSetting('menu_bookmark')=='true' else fGnKoFzQxuVWaXORPJgMrvwSDsEImC
  return(fGnKoFzQxuVWaXORPJgMrvwSDsEIdl,fGnKoFzQxuVWaXORPJgMrvwSDsEIdB,fGnKoFzQxuVWaXORPJgMrvwSDsEIdk,fGnKoFzQxuVWaXORPJgMrvwSDsEILd,fGnKoFzQxuVWaXORPJgMrvwSDsEILq)
 def get_settings_makebookmark(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA):
  return fGnKoFzQxuVWaXORPJgMrvwSDsEImN if __addon__.getSetting('make_bookmark')=='true' else fGnKoFzQxuVWaXORPJgMrvwSDsEImC
 def get_settings_play(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA):
  fGnKoFzQxuVWaXORPJgMrvwSDsEILY={'enable_hdr':fGnKoFzQxuVWaXORPJgMrvwSDsEImN if __addon__.getSetting('enable_hdr')=='true' else fGnKoFzQxuVWaXORPJgMrvwSDsEImC,'enable_uhd':fGnKoFzQxuVWaXORPJgMrvwSDsEImN if __addon__.getSetting('enable_uhd')=='true' else fGnKoFzQxuVWaXORPJgMrvwSDsEImC,'streamFilename':fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.WV_STREAM_FILENAME,}
  if fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.get_selQuality()<1080:
   fGnKoFzQxuVWaXORPJgMrvwSDsEILY['enable_hdr']=fGnKoFzQxuVWaXORPJgMrvwSDsEImC
   fGnKoFzQxuVWaXORPJgMrvwSDsEILY['enable_uhd']=fGnKoFzQxuVWaXORPJgMrvwSDsEImC
  return(fGnKoFzQxuVWaXORPJgMrvwSDsEILY)
 def get_settings_proxyport(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA):
  fGnKoFzQxuVWaXORPJgMrvwSDsEILT =fGnKoFzQxuVWaXORPJgMrvwSDsEImN if __addon__.getSetting('proxyYn')=='true' else fGnKoFzQxuVWaXORPJgMrvwSDsEImC
  fGnKoFzQxuVWaXORPJgMrvwSDsEILe=fGnKoFzQxuVWaXORPJgMrvwSDsEImj(__addon__.getSetting('proxyPort'))
  return fGnKoFzQxuVWaXORPJgMrvwSDsEILT,fGnKoFzQxuVWaXORPJgMrvwSDsEILe
 def get_selQuality(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA):
  try:
   fGnKoFzQxuVWaXORPJgMrvwSDsEILh=[1080,720,480,360]
   fGnKoFzQxuVWaXORPJgMrvwSDsEILm=fGnKoFzQxuVWaXORPJgMrvwSDsEImj(__addon__.getSetting('selected_quality'))
   return fGnKoFzQxuVWaXORPJgMrvwSDsEILh[fGnKoFzQxuVWaXORPJgMrvwSDsEILm]
  except:
   fGnKoFzQxuVWaXORPJgMrvwSDsEImt
  return 1080 
 def get_settings_exclusion21(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA):
  fGnKoFzQxuVWaXORPJgMrvwSDsEILA =__addon__.getSetting('exclusion21')
  if fGnKoFzQxuVWaXORPJgMrvwSDsEILA=='false':
   return fGnKoFzQxuVWaXORPJgMrvwSDsEImC
  else:
   return fGnKoFzQxuVWaXORPJgMrvwSDsEImN
 def get_settings_direct_replay(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA):
  fGnKoFzQxuVWaXORPJgMrvwSDsEILb=fGnKoFzQxuVWaXORPJgMrvwSDsEImj(__addon__.getSetting('direct_replay'))
  if fGnKoFzQxuVWaXORPJgMrvwSDsEILb==0:
   return fGnKoFzQxuVWaXORPJgMrvwSDsEImC
  else:
   return fGnKoFzQxuVWaXORPJgMrvwSDsEImN
 def set_winEpisodeOrderby(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA,fGnKoFzQxuVWaXORPJgMrvwSDsEILU):
  __addon__.setSetting('wavve_orderby',fGnKoFzQxuVWaXORPJgMrvwSDsEILU)
 def get_winEpisodeOrderby(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA):
  fGnKoFzQxuVWaXORPJgMrvwSDsEILU=__addon__.getSetting('wavve_orderby')
  if fGnKoFzQxuVWaXORPJgMrvwSDsEILU in['',fGnKoFzQxuVWaXORPJgMrvwSDsEImt]:fGnKoFzQxuVWaXORPJgMrvwSDsEILU='desc'
  return fGnKoFzQxuVWaXORPJgMrvwSDsEILU
 def add_dir(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA,label,sublabel='',img='',infoLabels=fGnKoFzQxuVWaXORPJgMrvwSDsEImt,isFolder=fGnKoFzQxuVWaXORPJgMrvwSDsEImN,params='',isLink=fGnKoFzQxuVWaXORPJgMrvwSDsEImC,ContextMenu=fGnKoFzQxuVWaXORPJgMrvwSDsEImt):
  fGnKoFzQxuVWaXORPJgMrvwSDsEILt='%s?%s'%(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA._addon_url,urllib.parse.urlencode(params))
  if sublabel:fGnKoFzQxuVWaXORPJgMrvwSDsEILj='%s < %s >'%(label,sublabel)
  else: fGnKoFzQxuVWaXORPJgMrvwSDsEILj=label
  if not img:img='DefaultFolder.png'
  fGnKoFzQxuVWaXORPJgMrvwSDsEILN=xbmcgui.ListItem(fGnKoFzQxuVWaXORPJgMrvwSDsEILj)
  if fGnKoFzQxuVWaXORPJgMrvwSDsEImi(img)==fGnKoFzQxuVWaXORPJgMrvwSDsEImy:
   fGnKoFzQxuVWaXORPJgMrvwSDsEILN.setArt(img)
  else:
   fGnKoFzQxuVWaXORPJgMrvwSDsEILN.setArt({'thumb':img,'poster':img})
  if fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.KodiVersion>=20:
   if infoLabels:fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.Set_InfoTag(fGnKoFzQxuVWaXORPJgMrvwSDsEILN.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:fGnKoFzQxuVWaXORPJgMrvwSDsEILN.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   fGnKoFzQxuVWaXORPJgMrvwSDsEILN.setProperty('IsPlayable','true')
  if ContextMenu:fGnKoFzQxuVWaXORPJgMrvwSDsEILN.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA._addon_handle,fGnKoFzQxuVWaXORPJgMrvwSDsEILt,fGnKoFzQxuVWaXORPJgMrvwSDsEILN,isFolder)
 def Set_InfoTag(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA,video_InfoTag:xbmc.InfoTagVideo,fGnKoFzQxuVWaXORPJgMrvwSDsEILB):
  for fGnKoFzQxuVWaXORPJgMrvwSDsEILC,value in fGnKoFzQxuVWaXORPJgMrvwSDsEILB.items():
   if fGnKoFzQxuVWaXORPJgMrvwSDsEIde[fGnKoFzQxuVWaXORPJgMrvwSDsEILC]['type']=='string':
    fGnKoFzQxuVWaXORPJgMrvwSDsEImp(video_InfoTag,fGnKoFzQxuVWaXORPJgMrvwSDsEIde[fGnKoFzQxuVWaXORPJgMrvwSDsEILC]['func'])(value)
   elif fGnKoFzQxuVWaXORPJgMrvwSDsEIde[fGnKoFzQxuVWaXORPJgMrvwSDsEILC]['type']=='int':
    if fGnKoFzQxuVWaXORPJgMrvwSDsEImi(value)==fGnKoFzQxuVWaXORPJgMrvwSDsEImj:
     fGnKoFzQxuVWaXORPJgMrvwSDsEILi=fGnKoFzQxuVWaXORPJgMrvwSDsEImj(value)
    else:
     fGnKoFzQxuVWaXORPJgMrvwSDsEILi=0
    fGnKoFzQxuVWaXORPJgMrvwSDsEImp(video_InfoTag,fGnKoFzQxuVWaXORPJgMrvwSDsEIde[fGnKoFzQxuVWaXORPJgMrvwSDsEILC]['func'])(fGnKoFzQxuVWaXORPJgMrvwSDsEILi)
   elif fGnKoFzQxuVWaXORPJgMrvwSDsEIde[fGnKoFzQxuVWaXORPJgMrvwSDsEILC]['type']=='actor':
    if value!=[]:
     fGnKoFzQxuVWaXORPJgMrvwSDsEImp(video_InfoTag,fGnKoFzQxuVWaXORPJgMrvwSDsEIde[fGnKoFzQxuVWaXORPJgMrvwSDsEILC]['func'])([xbmc.Actor(name)for name in value])
   elif fGnKoFzQxuVWaXORPJgMrvwSDsEIde[fGnKoFzQxuVWaXORPJgMrvwSDsEILC]['type']=='list':
    if fGnKoFzQxuVWaXORPJgMrvwSDsEImi(value)==fGnKoFzQxuVWaXORPJgMrvwSDsEImc:
     fGnKoFzQxuVWaXORPJgMrvwSDsEImp(video_InfoTag,fGnKoFzQxuVWaXORPJgMrvwSDsEIde[fGnKoFzQxuVWaXORPJgMrvwSDsEILC]['func'])(value)
    else:
     fGnKoFzQxuVWaXORPJgMrvwSDsEImp(video_InfoTag,fGnKoFzQxuVWaXORPJgMrvwSDsEIde[fGnKoFzQxuVWaXORPJgMrvwSDsEILC]['func'])([value])
 def dp_Main_List(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA):
  (fGnKoFzQxuVWaXORPJgMrvwSDsEIdl,fGnKoFzQxuVWaXORPJgMrvwSDsEIdB,fGnKoFzQxuVWaXORPJgMrvwSDsEIdk,fGnKoFzQxuVWaXORPJgMrvwSDsEILd,fGnKoFzQxuVWaXORPJgMrvwSDsEILq)=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.get_settings_totalsearch()
  for fGnKoFzQxuVWaXORPJgMrvwSDsEILy in fGnKoFzQxuVWaXORPJgMrvwSDsEIdq:
   fGnKoFzQxuVWaXORPJgMrvwSDsEILj=fGnKoFzQxuVWaXORPJgMrvwSDsEILy.get('title')
   fGnKoFzQxuVWaXORPJgMrvwSDsEILp=''
   if fGnKoFzQxuVWaXORPJgMrvwSDsEILy.get('mode')=='SEARCH_GROUP' and fGnKoFzQxuVWaXORPJgMrvwSDsEIdl ==fGnKoFzQxuVWaXORPJgMrvwSDsEImC:continue
   elif fGnKoFzQxuVWaXORPJgMrvwSDsEILy.get('mode')=='SEARCH_HISTORY' and fGnKoFzQxuVWaXORPJgMrvwSDsEIdB==fGnKoFzQxuVWaXORPJgMrvwSDsEImC:continue
   elif fGnKoFzQxuVWaXORPJgMrvwSDsEILy.get('mode')=='TOTAL_SEARCH' and fGnKoFzQxuVWaXORPJgMrvwSDsEIdk ==fGnKoFzQxuVWaXORPJgMrvwSDsEImC:continue
   elif fGnKoFzQxuVWaXORPJgMrvwSDsEILy.get('mode')=='TOTAL_HISTORY' and fGnKoFzQxuVWaXORPJgMrvwSDsEILd==fGnKoFzQxuVWaXORPJgMrvwSDsEImC:continue
   elif fGnKoFzQxuVWaXORPJgMrvwSDsEILy.get('mode')=='MENU_BOOKMARK' and fGnKoFzQxuVWaXORPJgMrvwSDsEILq==fGnKoFzQxuVWaXORPJgMrvwSDsEImC:continue
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc={'mode':fGnKoFzQxuVWaXORPJgMrvwSDsEILy.get('mode'),'sCode':fGnKoFzQxuVWaXORPJgMrvwSDsEILy.get('sCode'),'sIndex':fGnKoFzQxuVWaXORPJgMrvwSDsEILy.get('sIndex'),'sType':fGnKoFzQxuVWaXORPJgMrvwSDsEILy.get('sType'),'suburl':fGnKoFzQxuVWaXORPJgMrvwSDsEILy.get('suburl'),'subapi':fGnKoFzQxuVWaXORPJgMrvwSDsEILy.get('subapi'),'page':fGnKoFzQxuVWaXORPJgMrvwSDsEILy.get('page'),'orderby':fGnKoFzQxuVWaXORPJgMrvwSDsEILy.get('orderby'),'ordernm':fGnKoFzQxuVWaXORPJgMrvwSDsEILy.get('ordernm')}
   if fGnKoFzQxuVWaXORPJgMrvwSDsEILy.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    fGnKoFzQxuVWaXORPJgMrvwSDsEILH=fGnKoFzQxuVWaXORPJgMrvwSDsEImC
    fGnKoFzQxuVWaXORPJgMrvwSDsEILl =fGnKoFzQxuVWaXORPJgMrvwSDsEImN
   else:
    fGnKoFzQxuVWaXORPJgMrvwSDsEILH=fGnKoFzQxuVWaXORPJgMrvwSDsEImN
    fGnKoFzQxuVWaXORPJgMrvwSDsEILl =fGnKoFzQxuVWaXORPJgMrvwSDsEImC
   fGnKoFzQxuVWaXORPJgMrvwSDsEILB={'title':fGnKoFzQxuVWaXORPJgMrvwSDsEILj,'plot':fGnKoFzQxuVWaXORPJgMrvwSDsEILj}
   if fGnKoFzQxuVWaXORPJgMrvwSDsEILy.get('mode')=='XXX':fGnKoFzQxuVWaXORPJgMrvwSDsEILB=fGnKoFzQxuVWaXORPJgMrvwSDsEImt
   if 'icon' in fGnKoFzQxuVWaXORPJgMrvwSDsEILy:fGnKoFzQxuVWaXORPJgMrvwSDsEILp=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',fGnKoFzQxuVWaXORPJgMrvwSDsEILy.get('icon')) 
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.add_dir(fGnKoFzQxuVWaXORPJgMrvwSDsEILj,sublabel='',img=fGnKoFzQxuVWaXORPJgMrvwSDsEILp,infoLabels=fGnKoFzQxuVWaXORPJgMrvwSDsEILB,isFolder=fGnKoFzQxuVWaXORPJgMrvwSDsEILH,params=fGnKoFzQxuVWaXORPJgMrvwSDsEILc,isLink=fGnKoFzQxuVWaXORPJgMrvwSDsEILl)
  xbmcplugin.endOfDirectory(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA._addon_handle,cacheToDisc=fGnKoFzQxuVWaXORPJgMrvwSDsEImN)
 def dp_Search_Group(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA,args):
  if 'search_key' in args:
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqL=args.get('search_key')
  else:
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqL=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not fGnKoFzQxuVWaXORPJgMrvwSDsEIqL:
    return
  for fGnKoFzQxuVWaXORPJgMrvwSDsEIqY in fGnKoFzQxuVWaXORPJgMrvwSDsEIdY:
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqT =fGnKoFzQxuVWaXORPJgMrvwSDsEIqY.get('mode')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqe=fGnKoFzQxuVWaXORPJgMrvwSDsEIqY.get('sType')
   fGnKoFzQxuVWaXORPJgMrvwSDsEILj=fGnKoFzQxuVWaXORPJgMrvwSDsEIqY.get('title')
   (fGnKoFzQxuVWaXORPJgMrvwSDsEIqh,fGnKoFzQxuVWaXORPJgMrvwSDsEIqm)=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.Get_Search_List(fGnKoFzQxuVWaXORPJgMrvwSDsEIqL,fGnKoFzQxuVWaXORPJgMrvwSDsEIqe,1,exclusion21=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.get_settings_exclusion21())
   fGnKoFzQxuVWaXORPJgMrvwSDsEILB={'plot':'검색어 : '+fGnKoFzQxuVWaXORPJgMrvwSDsEIqL+'\n\n'+fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.Search_FreeList(fGnKoFzQxuVWaXORPJgMrvwSDsEIqh)}
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc={'mode':fGnKoFzQxuVWaXORPJgMrvwSDsEIqT,'sType':fGnKoFzQxuVWaXORPJgMrvwSDsEIqe,'search_key':fGnKoFzQxuVWaXORPJgMrvwSDsEIqL,'page':'1',}
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.add_dir(fGnKoFzQxuVWaXORPJgMrvwSDsEILj,sublabel='',img='',infoLabels=fGnKoFzQxuVWaXORPJgMrvwSDsEILB,isFolder=fGnKoFzQxuVWaXORPJgMrvwSDsEImN,params=fGnKoFzQxuVWaXORPJgMrvwSDsEILc)
  if fGnKoFzQxuVWaXORPJgMrvwSDsEImH(fGnKoFzQxuVWaXORPJgMrvwSDsEIdY)>0:xbmcplugin.endOfDirectory(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA._addon_handle,cacheToDisc=fGnKoFzQxuVWaXORPJgMrvwSDsEImN)
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.Save_Searched_List(fGnKoFzQxuVWaXORPJgMrvwSDsEIqL)
 def Search_FreeList(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA,search_list):
  fGnKoFzQxuVWaXORPJgMrvwSDsEIqA=''
  fGnKoFzQxuVWaXORPJgMrvwSDsEIqb=7
  try:
   if fGnKoFzQxuVWaXORPJgMrvwSDsEImH(search_list)==0:return '검색결과 없음'
   for i in fGnKoFzQxuVWaXORPJgMrvwSDsEIml(fGnKoFzQxuVWaXORPJgMrvwSDsEImH(search_list)):
    if i>=fGnKoFzQxuVWaXORPJgMrvwSDsEIqb:
     fGnKoFzQxuVWaXORPJgMrvwSDsEIqA=fGnKoFzQxuVWaXORPJgMrvwSDsEIqA+'...'
     break
    fGnKoFzQxuVWaXORPJgMrvwSDsEIqA=fGnKoFzQxuVWaXORPJgMrvwSDsEIqA+search_list[i]['title']+'\n'
  except:
   return ''
  return fGnKoFzQxuVWaXORPJgMrvwSDsEIqA
 def dp_Watch_Group(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA,args):
  for fGnKoFzQxuVWaXORPJgMrvwSDsEIqU in fGnKoFzQxuVWaXORPJgMrvwSDsEIdT:
   fGnKoFzQxuVWaXORPJgMrvwSDsEILj=fGnKoFzQxuVWaXORPJgMrvwSDsEIqU.get('title')
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc={'mode':fGnKoFzQxuVWaXORPJgMrvwSDsEIqU.get('mode'),'sType':fGnKoFzQxuVWaXORPJgMrvwSDsEIqU.get('sType')}
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.add_dir(fGnKoFzQxuVWaXORPJgMrvwSDsEILj,sublabel='',img='',infoLabels=fGnKoFzQxuVWaXORPJgMrvwSDsEImt,isFolder=fGnKoFzQxuVWaXORPJgMrvwSDsEImN,params=fGnKoFzQxuVWaXORPJgMrvwSDsEILc)
  if fGnKoFzQxuVWaXORPJgMrvwSDsEImH(fGnKoFzQxuVWaXORPJgMrvwSDsEIdT)>0:xbmcplugin.endOfDirectory(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA._addon_handle,cacheToDisc=fGnKoFzQxuVWaXORPJgMrvwSDsEImN)
 def dp_Search_History(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA,args):
  fGnKoFzQxuVWaXORPJgMrvwSDsEIqt=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.Load_List_File('search')
  for fGnKoFzQxuVWaXORPJgMrvwSDsEIqj in fGnKoFzQxuVWaXORPJgMrvwSDsEIqt:
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqN=fGnKoFzQxuVWaXORPJgMrvwSDsEImy(urllib.parse.parse_qsl(fGnKoFzQxuVWaXORPJgMrvwSDsEIqj))
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqC=fGnKoFzQxuVWaXORPJgMrvwSDsEIqN.get('skey').strip()
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc={'mode':'SEARCH_GROUP','search_key':fGnKoFzQxuVWaXORPJgMrvwSDsEIqC,}
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqi={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':fGnKoFzQxuVWaXORPJgMrvwSDsEIqC,'vType':'-',}
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqy=urllib.parse.urlencode(fGnKoFzQxuVWaXORPJgMrvwSDsEIqi)
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqp=[('선택된 검색어 ( %s ) 삭제'%(fGnKoFzQxuVWaXORPJgMrvwSDsEIqC),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(fGnKoFzQxuVWaXORPJgMrvwSDsEIqy))]
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.add_dir(fGnKoFzQxuVWaXORPJgMrvwSDsEIqC,sublabel='',img=fGnKoFzQxuVWaXORPJgMrvwSDsEImt,infoLabels=fGnKoFzQxuVWaXORPJgMrvwSDsEImt,isFolder=fGnKoFzQxuVWaXORPJgMrvwSDsEImN,params=fGnKoFzQxuVWaXORPJgMrvwSDsEILc,ContextMenu=fGnKoFzQxuVWaXORPJgMrvwSDsEIqp)
  fGnKoFzQxuVWaXORPJgMrvwSDsEIqc={'plot':'검색목록 전체를 삭제합니다.'}
  fGnKoFzQxuVWaXORPJgMrvwSDsEILj='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  fGnKoFzQxuVWaXORPJgMrvwSDsEILc={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  fGnKoFzQxuVWaXORPJgMrvwSDsEILp=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.add_dir(fGnKoFzQxuVWaXORPJgMrvwSDsEILj,sublabel='',img=fGnKoFzQxuVWaXORPJgMrvwSDsEILp,infoLabels=fGnKoFzQxuVWaXORPJgMrvwSDsEIqc,isFolder=fGnKoFzQxuVWaXORPJgMrvwSDsEImC,params=fGnKoFzQxuVWaXORPJgMrvwSDsEILc,isLink=fGnKoFzQxuVWaXORPJgMrvwSDsEImN)
  xbmcplugin.endOfDirectory(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA._addon_handle,cacheToDisc=fGnKoFzQxuVWaXORPJgMrvwSDsEImC)
 def dp_Search_List(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA,args):
  fGnKoFzQxuVWaXORPJgMrvwSDsEIqe =args.get('sType')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIqH =fGnKoFzQxuVWaXORPJgMrvwSDsEImj(args.get('page'))
  if 'search_key' in args:
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqL=args.get('search_key')
  else:
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqL=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not fGnKoFzQxuVWaXORPJgMrvwSDsEIqL:
    xbmcplugin.endOfDirectory(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA._addon_handle)
    return
  fGnKoFzQxuVWaXORPJgMrvwSDsEIql,fGnKoFzQxuVWaXORPJgMrvwSDsEIqm=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.Get_Search_List(fGnKoFzQxuVWaXORPJgMrvwSDsEIqL,fGnKoFzQxuVWaXORPJgMrvwSDsEIqe,fGnKoFzQxuVWaXORPJgMrvwSDsEIqH,exclusion21=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.get_settings_exclusion21())
  for fGnKoFzQxuVWaXORPJgMrvwSDsEIqB in fGnKoFzQxuVWaXORPJgMrvwSDsEIql:
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqk =fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('videoid')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYd =fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('vidtype')
   fGnKoFzQxuVWaXORPJgMrvwSDsEILj =fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('title')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYL=fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('thumbnail')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYq =fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('age')
   if fGnKoFzQxuVWaXORPJgMrvwSDsEIYq=='18' or fGnKoFzQxuVWaXORPJgMrvwSDsEIYq=='19' or fGnKoFzQxuVWaXORPJgMrvwSDsEIYq=='21':fGnKoFzQxuVWaXORPJgMrvwSDsEILj+=' (%s)'%(fGnKoFzQxuVWaXORPJgMrvwSDsEIYq)
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqc={'mediatype':'tvshow' if fGnKoFzQxuVWaXORPJgMrvwSDsEIqe=='vod' else 'movie','mpaa':fGnKoFzQxuVWaXORPJgMrvwSDsEIYq,'title':fGnKoFzQxuVWaXORPJgMrvwSDsEILj,'plot':fGnKoFzQxuVWaXORPJgMrvwSDsEILj}
   if fGnKoFzQxuVWaXORPJgMrvwSDsEIqe=='vod':
    fGnKoFzQxuVWaXORPJgMrvwSDsEILc={'mode':'EPISODE_LIST','seasonid':fGnKoFzQxuVWaXORPJgMrvwSDsEIqk,'page':'1',}
    fGnKoFzQxuVWaXORPJgMrvwSDsEILH=fGnKoFzQxuVWaXORPJgMrvwSDsEImN
   else:
    fGnKoFzQxuVWaXORPJgMrvwSDsEILc={'mode':'MOVIE','contentid':fGnKoFzQxuVWaXORPJgMrvwSDsEIqk,'title':fGnKoFzQxuVWaXORPJgMrvwSDsEILj,'thumbnail':fGnKoFzQxuVWaXORPJgMrvwSDsEIYL,'age':fGnKoFzQxuVWaXORPJgMrvwSDsEIYq,}
    fGnKoFzQxuVWaXORPJgMrvwSDsEILH=fGnKoFzQxuVWaXORPJgMrvwSDsEImC
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqp=[]
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYT={'mode':'VIEW_DETAIL','values':{'videoid':fGnKoFzQxuVWaXORPJgMrvwSDsEIqk,'vidtype':'tvshow' if fGnKoFzQxuVWaXORPJgMrvwSDsEIqe=='vod' else 'movie','contenttype':fGnKoFzQxuVWaXORPJgMrvwSDsEIYd,}}
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYe=json.dumps(fGnKoFzQxuVWaXORPJgMrvwSDsEIYT,separators=(',',':'))
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYe=base64.standard_b64encode(fGnKoFzQxuVWaXORPJgMrvwSDsEIYe.encode()).decode('utf-8')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYe=fGnKoFzQxuVWaXORPJgMrvwSDsEIYe.replace('+','%2B')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYh='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(fGnKoFzQxuVWaXORPJgMrvwSDsEIYe)
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqp.append(('상세정보 조회',fGnKoFzQxuVWaXORPJgMrvwSDsEIYh))
   if fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.get_settings_makebookmark():
    fGnKoFzQxuVWaXORPJgMrvwSDsEIYT={'videoid':fGnKoFzQxuVWaXORPJgMrvwSDsEIqk,'vidtype':'tvshow' if fGnKoFzQxuVWaXORPJgMrvwSDsEIqe=='vod' else 'movie','vtitle':fGnKoFzQxuVWaXORPJgMrvwSDsEILj,'vsubtitle':'','contenttype':fGnKoFzQxuVWaXORPJgMrvwSDsEIYd,}
    fGnKoFzQxuVWaXORPJgMrvwSDsEIYm=json.dumps(fGnKoFzQxuVWaXORPJgMrvwSDsEIYT)
    fGnKoFzQxuVWaXORPJgMrvwSDsEIYm=urllib.parse.quote(fGnKoFzQxuVWaXORPJgMrvwSDsEIYm)
    fGnKoFzQxuVWaXORPJgMrvwSDsEIYh='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(fGnKoFzQxuVWaXORPJgMrvwSDsEIYm)
    fGnKoFzQxuVWaXORPJgMrvwSDsEIqp.append(('(통합) 찜 영상에 추가',fGnKoFzQxuVWaXORPJgMrvwSDsEIYh))
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.add_dir(fGnKoFzQxuVWaXORPJgMrvwSDsEILj,sublabel='',img=fGnKoFzQxuVWaXORPJgMrvwSDsEIYL,infoLabels=fGnKoFzQxuVWaXORPJgMrvwSDsEIqc,isFolder=fGnKoFzQxuVWaXORPJgMrvwSDsEILH,params=fGnKoFzQxuVWaXORPJgMrvwSDsEILc,ContextMenu=fGnKoFzQxuVWaXORPJgMrvwSDsEIqp)
  if fGnKoFzQxuVWaXORPJgMrvwSDsEIqm:
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc['mode'] ='SEARCH_LIST' 
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc['sType']=fGnKoFzQxuVWaXORPJgMrvwSDsEIqe 
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc['page'] =fGnKoFzQxuVWaXORPJgMrvwSDsEImB(fGnKoFzQxuVWaXORPJgMrvwSDsEIqH+1)
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc['search_key']=fGnKoFzQxuVWaXORPJgMrvwSDsEIqL
   fGnKoFzQxuVWaXORPJgMrvwSDsEILj='[B]%s >>[/B]'%'다음 페이지'
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYA=fGnKoFzQxuVWaXORPJgMrvwSDsEImB(fGnKoFzQxuVWaXORPJgMrvwSDsEIqH+1)
   fGnKoFzQxuVWaXORPJgMrvwSDsEILp=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.add_dir(fGnKoFzQxuVWaXORPJgMrvwSDsEILj,sublabel=fGnKoFzQxuVWaXORPJgMrvwSDsEIYA,img=fGnKoFzQxuVWaXORPJgMrvwSDsEILp,infoLabels=fGnKoFzQxuVWaXORPJgMrvwSDsEImt,isFolder=fGnKoFzQxuVWaXORPJgMrvwSDsEImN,params=fGnKoFzQxuVWaXORPJgMrvwSDsEILc)
  if fGnKoFzQxuVWaXORPJgMrvwSDsEIqe=='movie':xbmcplugin.setContent(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA._addon_handle,'movies')
  else:xbmcplugin.setContent(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA._addon_handle,cacheToDisc=fGnKoFzQxuVWaXORPJgMrvwSDsEImC)
 def dp_Watch_List(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA,args):
  fGnKoFzQxuVWaXORPJgMrvwSDsEIqe =args.get('sType')
  fGnKoFzQxuVWaXORPJgMrvwSDsEILb=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.get_settings_direct_replay()
  fGnKoFzQxuVWaXORPJgMrvwSDsEIql=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.Load_List_File(fGnKoFzQxuVWaXORPJgMrvwSDsEIqe)
  for fGnKoFzQxuVWaXORPJgMrvwSDsEIqB in fGnKoFzQxuVWaXORPJgMrvwSDsEIql:
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqN=fGnKoFzQxuVWaXORPJgMrvwSDsEImy(urllib.parse.parse_qsl(fGnKoFzQxuVWaXORPJgMrvwSDsEIqB))
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYb =fGnKoFzQxuVWaXORPJgMrvwSDsEIqN.get('code').strip()
   fGnKoFzQxuVWaXORPJgMrvwSDsEILj =fGnKoFzQxuVWaXORPJgMrvwSDsEIqN.get('title').strip()
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYA =fGnKoFzQxuVWaXORPJgMrvwSDsEIqN.get('subtitle').strip()
   if fGnKoFzQxuVWaXORPJgMrvwSDsEIYA=='None':fGnKoFzQxuVWaXORPJgMrvwSDsEIYA=''
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYL=fGnKoFzQxuVWaXORPJgMrvwSDsEIqN.get('img').strip()
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqk =fGnKoFzQxuVWaXORPJgMrvwSDsEIqN.get('videoid').strip()
   try:
    fGnKoFzQxuVWaXORPJgMrvwSDsEIYL=fGnKoFzQxuVWaXORPJgMrvwSDsEIYL.replace('\'','\"')
    fGnKoFzQxuVWaXORPJgMrvwSDsEIYL=json.loads(fGnKoFzQxuVWaXORPJgMrvwSDsEIYL)
   except:
    fGnKoFzQxuVWaXORPJgMrvwSDsEImt
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqc={'plot':'%s\n%s'%(fGnKoFzQxuVWaXORPJgMrvwSDsEILj,fGnKoFzQxuVWaXORPJgMrvwSDsEIYA)}
   if fGnKoFzQxuVWaXORPJgMrvwSDsEIqe=='vod':
    if fGnKoFzQxuVWaXORPJgMrvwSDsEILb==fGnKoFzQxuVWaXORPJgMrvwSDsEImC or fGnKoFzQxuVWaXORPJgMrvwSDsEIqk==fGnKoFzQxuVWaXORPJgMrvwSDsEImt:
     fGnKoFzQxuVWaXORPJgMrvwSDsEIqc['mediatype']='tvshow'
     fGnKoFzQxuVWaXORPJgMrvwSDsEILc={'mode':'SEASON_LIST','videoid':fGnKoFzQxuVWaXORPJgMrvwSDsEIqk,'vidtype':'contentid',}
     fGnKoFzQxuVWaXORPJgMrvwSDsEILH=fGnKoFzQxuVWaXORPJgMrvwSDsEImN
    else:
     fGnKoFzQxuVWaXORPJgMrvwSDsEIqc['mediatype']='episode'
     fGnKoFzQxuVWaXORPJgMrvwSDsEILc={'mode':'VOD','programid':fGnKoFzQxuVWaXORPJgMrvwSDsEIYb,'contentid':fGnKoFzQxuVWaXORPJgMrvwSDsEIqk,'title':fGnKoFzQxuVWaXORPJgMrvwSDsEILj,'subtitle':fGnKoFzQxuVWaXORPJgMrvwSDsEIYA,'thumbnail':fGnKoFzQxuVWaXORPJgMrvwSDsEIYL}
     fGnKoFzQxuVWaXORPJgMrvwSDsEILH=fGnKoFzQxuVWaXORPJgMrvwSDsEImC
   else:
    fGnKoFzQxuVWaXORPJgMrvwSDsEIqc['mediatype']='movie'
    fGnKoFzQxuVWaXORPJgMrvwSDsEILc={'mode':'MOVIE','contentid':fGnKoFzQxuVWaXORPJgMrvwSDsEIYb,'title':fGnKoFzQxuVWaXORPJgMrvwSDsEILj,'subtitle':fGnKoFzQxuVWaXORPJgMrvwSDsEIYA,'thumbnail':fGnKoFzQxuVWaXORPJgMrvwSDsEIYL}
    fGnKoFzQxuVWaXORPJgMrvwSDsEILH=fGnKoFzQxuVWaXORPJgMrvwSDsEImC
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqi={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':fGnKoFzQxuVWaXORPJgMrvwSDsEIYb,'vType':fGnKoFzQxuVWaXORPJgMrvwSDsEIqe,}
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqy=urllib.parse.urlencode(fGnKoFzQxuVWaXORPJgMrvwSDsEIqi)
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqp=[('선택된 시청이력 ( %s ) 삭제'%(fGnKoFzQxuVWaXORPJgMrvwSDsEILj),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(fGnKoFzQxuVWaXORPJgMrvwSDsEIqy))]
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.add_dir(fGnKoFzQxuVWaXORPJgMrvwSDsEILj,sublabel=fGnKoFzQxuVWaXORPJgMrvwSDsEIYA,img=fGnKoFzQxuVWaXORPJgMrvwSDsEIYL,infoLabels=fGnKoFzQxuVWaXORPJgMrvwSDsEIqc,isFolder=fGnKoFzQxuVWaXORPJgMrvwSDsEILH,params=fGnKoFzQxuVWaXORPJgMrvwSDsEILc,ContextMenu=fGnKoFzQxuVWaXORPJgMrvwSDsEIqp)
  fGnKoFzQxuVWaXORPJgMrvwSDsEIqc={'plot':'시청목록을 삭제합니다.'}
  fGnKoFzQxuVWaXORPJgMrvwSDsEILj='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  fGnKoFzQxuVWaXORPJgMrvwSDsEILc={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':fGnKoFzQxuVWaXORPJgMrvwSDsEIqe,}
  fGnKoFzQxuVWaXORPJgMrvwSDsEILp=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.add_dir(fGnKoFzQxuVWaXORPJgMrvwSDsEILj,sublabel='',img=fGnKoFzQxuVWaXORPJgMrvwSDsEILp,infoLabels=fGnKoFzQxuVWaXORPJgMrvwSDsEIqc,isFolder=fGnKoFzQxuVWaXORPJgMrvwSDsEImC,params=fGnKoFzQxuVWaXORPJgMrvwSDsEILc,isLink=fGnKoFzQxuVWaXORPJgMrvwSDsEImN)
  if fGnKoFzQxuVWaXORPJgMrvwSDsEIqe=='movie':xbmcplugin.setContent(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA._addon_handle,'movies')
  else:xbmcplugin.setContent(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA._addon_handle,cacheToDisc=fGnKoFzQxuVWaXORPJgMrvwSDsEImC)
 def Load_List_File(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA,stype): 
  try:
   if stype=='search':
    fGnKoFzQxuVWaXORPJgMrvwSDsEIYU=fGnKoFzQxuVWaXORPJgMrvwSDsEIdm
   elif stype in['vod','movie']:
    fGnKoFzQxuVWaXORPJgMrvwSDsEIYU=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   else:
    return[]
   fp=fGnKoFzQxuVWaXORPJgMrvwSDsEImk(fGnKoFzQxuVWaXORPJgMrvwSDsEIYU,'r',-1,'utf-8')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYt=fp.readlines()
   fp.close()
  except:
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYt=[]
  return fGnKoFzQxuVWaXORPJgMrvwSDsEIYt
 def Save_Watched_List(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA,fGnKoFzQxuVWaXORPJgMrvwSDsEIhc,fGnKoFzQxuVWaXORPJgMrvwSDsEIdt):
  try:
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYj=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%fGnKoFzQxuVWaXORPJgMrvwSDsEIhc))
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYN=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.Load_List_File(fGnKoFzQxuVWaXORPJgMrvwSDsEIhc) 
   fp=fGnKoFzQxuVWaXORPJgMrvwSDsEImk(fGnKoFzQxuVWaXORPJgMrvwSDsEIYj,'w',-1,'utf-8')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYC=urllib.parse.urlencode(fGnKoFzQxuVWaXORPJgMrvwSDsEIdt)
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYC=fGnKoFzQxuVWaXORPJgMrvwSDsEIYC+'\n'
   fp.write(fGnKoFzQxuVWaXORPJgMrvwSDsEIYC)
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYi=0
   for fGnKoFzQxuVWaXORPJgMrvwSDsEIYy in fGnKoFzQxuVWaXORPJgMrvwSDsEIYN:
    fGnKoFzQxuVWaXORPJgMrvwSDsEIYp=fGnKoFzQxuVWaXORPJgMrvwSDsEImy(urllib.parse.parse_qsl(fGnKoFzQxuVWaXORPJgMrvwSDsEIYy))
    fGnKoFzQxuVWaXORPJgMrvwSDsEIYc=fGnKoFzQxuVWaXORPJgMrvwSDsEIdt.get('code').strip()
    fGnKoFzQxuVWaXORPJgMrvwSDsEIYH=fGnKoFzQxuVWaXORPJgMrvwSDsEIYp.get('code').strip()
    if fGnKoFzQxuVWaXORPJgMrvwSDsEIhc=='vod' and fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.get_settings_direct_replay()==fGnKoFzQxuVWaXORPJgMrvwSDsEImN:
     fGnKoFzQxuVWaXORPJgMrvwSDsEIYc=fGnKoFzQxuVWaXORPJgMrvwSDsEIdt.get('videoid').strip()
     fGnKoFzQxuVWaXORPJgMrvwSDsEIYH=fGnKoFzQxuVWaXORPJgMrvwSDsEIYp.get('videoid').strip()if fGnKoFzQxuVWaXORPJgMrvwSDsEIYH!=fGnKoFzQxuVWaXORPJgMrvwSDsEImt else '-'
    if fGnKoFzQxuVWaXORPJgMrvwSDsEIYc!=fGnKoFzQxuVWaXORPJgMrvwSDsEIYH:
     fp.write(fGnKoFzQxuVWaXORPJgMrvwSDsEIYy)
     fGnKoFzQxuVWaXORPJgMrvwSDsEIYi+=1
     if fGnKoFzQxuVWaXORPJgMrvwSDsEIYi>=50:break
   fp.close()
  except:
   fGnKoFzQxuVWaXORPJgMrvwSDsEImt
 def dp_History_Remove(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA,args):
  fGnKoFzQxuVWaXORPJgMrvwSDsEIYl=args.get('delType')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIYB =args.get('sKey')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIYk =args.get('vType')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdN=xbmcgui.Dialog()
  if fGnKoFzQxuVWaXORPJgMrvwSDsEIYl=='SEARCH_ALL':
   fGnKoFzQxuVWaXORPJgMrvwSDsEITd=fGnKoFzQxuVWaXORPJgMrvwSDsEIdN.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif fGnKoFzQxuVWaXORPJgMrvwSDsEIYl=='SEARCH_ONE':
   fGnKoFzQxuVWaXORPJgMrvwSDsEITd=fGnKoFzQxuVWaXORPJgMrvwSDsEIdN.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif fGnKoFzQxuVWaXORPJgMrvwSDsEIYl=='WATCH_ALL':
   fGnKoFzQxuVWaXORPJgMrvwSDsEITd=fGnKoFzQxuVWaXORPJgMrvwSDsEIdN.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif fGnKoFzQxuVWaXORPJgMrvwSDsEIYl=='WATCH_ONE':
   fGnKoFzQxuVWaXORPJgMrvwSDsEITd=fGnKoFzQxuVWaXORPJgMrvwSDsEIdN.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if fGnKoFzQxuVWaXORPJgMrvwSDsEITd==fGnKoFzQxuVWaXORPJgMrvwSDsEImC:sys.exit()
  if fGnKoFzQxuVWaXORPJgMrvwSDsEIYl=='SEARCH_ALL':
   if os.path.isfile(fGnKoFzQxuVWaXORPJgMrvwSDsEIdm):os.remove(fGnKoFzQxuVWaXORPJgMrvwSDsEIdm)
  elif fGnKoFzQxuVWaXORPJgMrvwSDsEIYl=='SEARCH_ONE':
   try:
    fGnKoFzQxuVWaXORPJgMrvwSDsEIYU=fGnKoFzQxuVWaXORPJgMrvwSDsEIdm
    fGnKoFzQxuVWaXORPJgMrvwSDsEIYN=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.Load_List_File('search') 
    fp=fGnKoFzQxuVWaXORPJgMrvwSDsEImk(fGnKoFzQxuVWaXORPJgMrvwSDsEIYU,'w',-1,'utf-8')
    for fGnKoFzQxuVWaXORPJgMrvwSDsEIYy in fGnKoFzQxuVWaXORPJgMrvwSDsEIYN:
     fGnKoFzQxuVWaXORPJgMrvwSDsEIYp=fGnKoFzQxuVWaXORPJgMrvwSDsEImy(urllib.parse.parse_qsl(fGnKoFzQxuVWaXORPJgMrvwSDsEIYy))
     fGnKoFzQxuVWaXORPJgMrvwSDsEITL=fGnKoFzQxuVWaXORPJgMrvwSDsEIYp.get('skey').strip()
     if fGnKoFzQxuVWaXORPJgMrvwSDsEIYB!=fGnKoFzQxuVWaXORPJgMrvwSDsEITL:
      fp.write(fGnKoFzQxuVWaXORPJgMrvwSDsEIYy)
    fp.close()
   except:
    fGnKoFzQxuVWaXORPJgMrvwSDsEImt
  elif fGnKoFzQxuVWaXORPJgMrvwSDsEIYl=='WATCH_ALL':
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYU=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%fGnKoFzQxuVWaXORPJgMrvwSDsEIYk))
   if os.path.isfile(fGnKoFzQxuVWaXORPJgMrvwSDsEIYU):os.remove(fGnKoFzQxuVWaXORPJgMrvwSDsEIYU)
  elif fGnKoFzQxuVWaXORPJgMrvwSDsEIYl=='WATCH_ONE':
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYU=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%fGnKoFzQxuVWaXORPJgMrvwSDsEIYk))
   try:
    fGnKoFzQxuVWaXORPJgMrvwSDsEIYN=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.Load_List_File(fGnKoFzQxuVWaXORPJgMrvwSDsEIYk) 
    fp=fGnKoFzQxuVWaXORPJgMrvwSDsEImk(fGnKoFzQxuVWaXORPJgMrvwSDsEIYU,'w',-1,'utf-8')
    for fGnKoFzQxuVWaXORPJgMrvwSDsEIYy in fGnKoFzQxuVWaXORPJgMrvwSDsEIYN:
     fGnKoFzQxuVWaXORPJgMrvwSDsEIYp=fGnKoFzQxuVWaXORPJgMrvwSDsEImy(urllib.parse.parse_qsl(fGnKoFzQxuVWaXORPJgMrvwSDsEIYy))
     fGnKoFzQxuVWaXORPJgMrvwSDsEITL=fGnKoFzQxuVWaXORPJgMrvwSDsEIYp.get('code').strip()
     if fGnKoFzQxuVWaXORPJgMrvwSDsEIYB!=fGnKoFzQxuVWaXORPJgMrvwSDsEITL:
      fp.write(fGnKoFzQxuVWaXORPJgMrvwSDsEIYy)
    fp.close()
   except:
    fGnKoFzQxuVWaXORPJgMrvwSDsEImt
  xbmc.executebuiltin("Container.Refresh")
 def Save_Searched_List(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA,fGnKoFzQxuVWaXORPJgMrvwSDsEIqL):
  try:
   fGnKoFzQxuVWaXORPJgMrvwSDsEITq=fGnKoFzQxuVWaXORPJgMrvwSDsEIdm
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYN=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.Load_List_File('search') 
   fGnKoFzQxuVWaXORPJgMrvwSDsEITY={'skey':fGnKoFzQxuVWaXORPJgMrvwSDsEIqL.strip()}
   fp=fGnKoFzQxuVWaXORPJgMrvwSDsEImk(fGnKoFzQxuVWaXORPJgMrvwSDsEITq,'w',-1,'utf-8')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYC=urllib.parse.urlencode(fGnKoFzQxuVWaXORPJgMrvwSDsEITY)
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYC=fGnKoFzQxuVWaXORPJgMrvwSDsEIYC+'\n'
   fp.write(fGnKoFzQxuVWaXORPJgMrvwSDsEIYC)
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYi=0
   for fGnKoFzQxuVWaXORPJgMrvwSDsEIYy in fGnKoFzQxuVWaXORPJgMrvwSDsEIYN:
    fGnKoFzQxuVWaXORPJgMrvwSDsEIYp=fGnKoFzQxuVWaXORPJgMrvwSDsEImy(urllib.parse.parse_qsl(fGnKoFzQxuVWaXORPJgMrvwSDsEIYy))
    fGnKoFzQxuVWaXORPJgMrvwSDsEIYc=fGnKoFzQxuVWaXORPJgMrvwSDsEITY.get('skey').strip()
    fGnKoFzQxuVWaXORPJgMrvwSDsEIYH=fGnKoFzQxuVWaXORPJgMrvwSDsEIYp.get('skey').strip()
    if fGnKoFzQxuVWaXORPJgMrvwSDsEIYc!=fGnKoFzQxuVWaXORPJgMrvwSDsEIYH:
     fp.write(fGnKoFzQxuVWaXORPJgMrvwSDsEIYy)
     fGnKoFzQxuVWaXORPJgMrvwSDsEIYi+=1
     if fGnKoFzQxuVWaXORPJgMrvwSDsEIYi>=50:break
   fp.close()
  except:
   fGnKoFzQxuVWaXORPJgMrvwSDsEImt
 def dp_Global_Search(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA,args):
  fGnKoFzQxuVWaXORPJgMrvwSDsEIqT=args.get('mode')
  if fGnKoFzQxuVWaXORPJgMrvwSDsEIqT=='TOTAL_SEARCH':
   fGnKoFzQxuVWaXORPJgMrvwSDsEITe='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   fGnKoFzQxuVWaXORPJgMrvwSDsEITe='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(fGnKoFzQxuVWaXORPJgMrvwSDsEITe)
 def dp_Bookmark_Menu(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA,args):
  fGnKoFzQxuVWaXORPJgMrvwSDsEITe='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(fGnKoFzQxuVWaXORPJgMrvwSDsEITe)
 def login_main(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA):
  (fGnKoFzQxuVWaXORPJgMrvwSDsEITh,fGnKoFzQxuVWaXORPJgMrvwSDsEITm,fGnKoFzQxuVWaXORPJgMrvwSDsEITA)=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.get_settings_account()
  if not(fGnKoFzQxuVWaXORPJgMrvwSDsEITh and fGnKoFzQxuVWaXORPJgMrvwSDsEITm):
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdN=xbmcgui.Dialog()
   fGnKoFzQxuVWaXORPJgMrvwSDsEITd=fGnKoFzQxuVWaXORPJgMrvwSDsEIdN.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if fGnKoFzQxuVWaXORPJgMrvwSDsEITd==fGnKoFzQxuVWaXORPJgMrvwSDsEImN:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.cookiefile_check()==fGnKoFzQxuVWaXORPJgMrvwSDsEImN:return
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   fGnKoFzQxuVWaXORPJgMrvwSDsEITb=0
   while fGnKoFzQxuVWaXORPJgMrvwSDsEImN:
    fGnKoFzQxuVWaXORPJgMrvwSDsEITb+=1
    time.sleep(0.05)
    if fGnKoFzQxuVWaXORPJgMrvwSDsEITb>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  fGnKoFzQxuVWaXORPJgMrvwSDsEITU=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.GetCredential(fGnKoFzQxuVWaXORPJgMrvwSDsEITh,fGnKoFzQxuVWaXORPJgMrvwSDsEITm,fGnKoFzQxuVWaXORPJgMrvwSDsEITA)
  if fGnKoFzQxuVWaXORPJgMrvwSDsEITU:fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
  if fGnKoFzQxuVWaXORPJgMrvwSDsEITU==fGnKoFzQxuVWaXORPJgMrvwSDsEImC:
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_setEpOrderby(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA,args):
  fGnKoFzQxuVWaXORPJgMrvwSDsEILU =args.get('orderby')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.set_winEpisodeOrderby(fGnKoFzQxuVWaXORPJgMrvwSDsEILU)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA,args):
  fGnKoFzQxuVWaXORPJgMrvwSDsEIqT =args.get('mode')
  fGnKoFzQxuVWaXORPJgMrvwSDsEITt =args.get('contentid')
  fGnKoFzQxuVWaXORPJgMrvwSDsEITj =args.get('pvrmode')
  fGnKoFzQxuVWaXORPJgMrvwSDsEITN=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.get_selQuality()
  fGnKoFzQxuVWaXORPJgMrvwSDsEILY =fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.get_settings_play()
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.addon_log(fGnKoFzQxuVWaXORPJgMrvwSDsEITt+' - '+fGnKoFzQxuVWaXORPJgMrvwSDsEIqT)
  if fGnKoFzQxuVWaXORPJgMrvwSDsEIqT=='SPORTS':
   fGnKoFzQxuVWaXORPJgMrvwSDsEITC=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.GetSportsURL(fGnKoFzQxuVWaXORPJgMrvwSDsEITt,fGnKoFzQxuVWaXORPJgMrvwSDsEITN)
  else:
   fGnKoFzQxuVWaXORPJgMrvwSDsEITC=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.GetStreamingURL(fGnKoFzQxuVWaXORPJgMrvwSDsEIqT,fGnKoFzQxuVWaXORPJgMrvwSDsEITt,fGnKoFzQxuVWaXORPJgMrvwSDsEITN,fGnKoFzQxuVWaXORPJgMrvwSDsEITj,playOption=fGnKoFzQxuVWaXORPJgMrvwSDsEILY)
  fGnKoFzQxuVWaXORPJgMrvwSDsEITi={'user-agent':fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.USER_AGENT}
  fGnKoFzQxuVWaXORPJgMrvwSDsEITy=fGnKoFzQxuVWaXORPJgMrvwSDsEITC['stream_cookie'] 
  fGnKoFzQxuVWaXORPJgMrvwSDsEITp=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.make_stream_header(fGnKoFzQxuVWaXORPJgMrvwSDsEITi,fGnKoFzQxuVWaXORPJgMrvwSDsEITy)
  fGnKoFzQxuVWaXORPJgMrvwSDsEITc='{}|{}'.format(fGnKoFzQxuVWaXORPJgMrvwSDsEITC['stream_url'],fGnKoFzQxuVWaXORPJgMrvwSDsEITp)
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.addon_log('surl : '+fGnKoFzQxuVWaXORPJgMrvwSDsEITc)
  if fGnKoFzQxuVWaXORPJgMrvwSDsEITC['stream_url']=='':
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.addon_noti(__language__(30907).encode('utf8'))
   return
  fGnKoFzQxuVWaXORPJgMrvwSDsEILT,fGnKoFzQxuVWaXORPJgMrvwSDsEILe=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.get_settings_proxyport()
  fGnKoFzQxuVWaXORPJgMrvwSDsEITH=urllib.parse.urlparse(fGnKoFzQxuVWaXORPJgMrvwSDsEITC['stream_url'])
  fGnKoFzQxuVWaXORPJgMrvwSDsEITH=fGnKoFzQxuVWaXORPJgMrvwSDsEITH.path.strip('/').split('/')
  fGnKoFzQxuVWaXORPJgMrvwSDsEITH=fGnKoFzQxuVWaXORPJgMrvwSDsEITH[fGnKoFzQxuVWaXORPJgMrvwSDsEImH(fGnKoFzQxuVWaXORPJgMrvwSDsEITH)-1] 
  if (fGnKoFzQxuVWaXORPJgMrvwSDsEILT==fGnKoFzQxuVWaXORPJgMrvwSDsEImN and args.get('mode')in['VOD','MOVIE']and(fGnKoFzQxuVWaXORPJgMrvwSDsEITC['playParam']['hdr']=='hdr' or fGnKoFzQxuVWaXORPJgMrvwSDsEITC['playParam']['uhd']=='uhd')):
   if fGnKoFzQxuVWaXORPJgMrvwSDsEITH.split('.')[1]=='mpd':
    fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.Wavve_Parse_mpd(fGnKoFzQxuVWaXORPJgMrvwSDsEITC)
   else:
    fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.Wavve_Parse_m3u8(fGnKoFzQxuVWaXORPJgMrvwSDsEITC)
   fGnKoFzQxuVWaXORPJgMrvwSDsEITl={'addon':'wavvem','playOption':fGnKoFzQxuVWaXORPJgMrvwSDsEILY,}
   fGnKoFzQxuVWaXORPJgMrvwSDsEITl=json.dumps(fGnKoFzQxuVWaXORPJgMrvwSDsEITl,separators=(',',':'))
   fGnKoFzQxuVWaXORPJgMrvwSDsEITl=base64.standard_b64encode(fGnKoFzQxuVWaXORPJgMrvwSDsEITl.encode()).decode('utf-8')
   fGnKoFzQxuVWaXORPJgMrvwSDsEITc ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(fGnKoFzQxuVWaXORPJgMrvwSDsEILe,fGnKoFzQxuVWaXORPJgMrvwSDsEITc,fGnKoFzQxuVWaXORPJgMrvwSDsEITl)
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.addon_log('surl : '+fGnKoFzQxuVWaXORPJgMrvwSDsEITc)
  fGnKoFzQxuVWaXORPJgMrvwSDsEITB=xbmcgui.ListItem(path=fGnKoFzQxuVWaXORPJgMrvwSDsEITc)
  if fGnKoFzQxuVWaXORPJgMrvwSDsEITC['stream_drm']:
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.addon_log('!!streaming_drm!!')
   fGnKoFzQxuVWaXORPJgMrvwSDsEITk =inputstreamhelper.Helper('mpd',drm='widevine')
   if 'licensetoken' in fGnKoFzQxuVWaXORPJgMrvwSDsEITC['stream_drm']:
    fGnKoFzQxuVWaXORPJgMrvwSDsEIed=fGnKoFzQxuVWaXORPJgMrvwSDsEITC['stream_drm']['licensetoken']
    fGnKoFzQxuVWaXORPJgMrvwSDsEIeL =fGnKoFzQxuVWaXORPJgMrvwSDsEITC['stream_drm']['licenseurl']
    if fGnKoFzQxuVWaXORPJgMrvwSDsEIqT=='MOVIE':
     fGnKoFzQxuVWaXORPJgMrvwSDsEIeq='https://www.wavve.com/player/movie?movieid=%s'%fGnKoFzQxuVWaXORPJgMrvwSDsEITt
    else:
     fGnKoFzQxuVWaXORPJgMrvwSDsEIeq='https://www.wavve.com/player/vod?programid=%s&page=1'%fGnKoFzQxuVWaXORPJgMrvwSDsEITt
    fGnKoFzQxuVWaXORPJgMrvwSDsEIeY={'content-type':'application/octet-stream','origin':'https://www.wavve.com','License-Token':fGnKoFzQxuVWaXORPJgMrvwSDsEIed,'referer':fGnKoFzQxuVWaXORPJgMrvwSDsEIeq,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.USER_AGENT,}
   else:
    fGnKoFzQxuVWaXORPJgMrvwSDsEIed=fGnKoFzQxuVWaXORPJgMrvwSDsEITC['stream_drm']['customdata']
    fGnKoFzQxuVWaXORPJgMrvwSDsEIeL =fGnKoFzQxuVWaXORPJgMrvwSDsEITC['stream_drm']['drmhost']
    if fGnKoFzQxuVWaXORPJgMrvwSDsEIqT=='MOVIE':
     fGnKoFzQxuVWaXORPJgMrvwSDsEIeq='https://www.wavve.com/player/movie?movieid=%s'%fGnKoFzQxuVWaXORPJgMrvwSDsEITt
    else:
     fGnKoFzQxuVWaXORPJgMrvwSDsEIeq='https://www.wavve.com/player/vod?programid=%s&page=1'%fGnKoFzQxuVWaXORPJgMrvwSDsEITt
    fGnKoFzQxuVWaXORPJgMrvwSDsEIeY={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':fGnKoFzQxuVWaXORPJgMrvwSDsEIed,'referer':fGnKoFzQxuVWaXORPJgMrvwSDsEIeq,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.USER_AGENT,}
   fGnKoFzQxuVWaXORPJgMrvwSDsEIeT=fGnKoFzQxuVWaXORPJgMrvwSDsEIeL+'|'+urllib.parse.urlencode(fGnKoFzQxuVWaXORPJgMrvwSDsEIeY)+'|R{SSM}|'
   fGnKoFzQxuVWaXORPJgMrvwSDsEITB.setProperty('inputstream',fGnKoFzQxuVWaXORPJgMrvwSDsEITk.inputstream_addon)
   if fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.KodiVersion<=20:
    fGnKoFzQxuVWaXORPJgMrvwSDsEITB.setProperty('inputstream.adaptive.manifest_type','mpd')
   fGnKoFzQxuVWaXORPJgMrvwSDsEITB.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
   fGnKoFzQxuVWaXORPJgMrvwSDsEITB.setProperty('inputstream.adaptive.license_key',fGnKoFzQxuVWaXORPJgMrvwSDsEIeT)
   fGnKoFzQxuVWaXORPJgMrvwSDsEITB.setProperty('inputstream.adaptive.stream_headers',fGnKoFzQxuVWaXORPJgMrvwSDsEITp)
   fGnKoFzQxuVWaXORPJgMrvwSDsEITB.setProperty('inputstream.adaptive.manifest_headers',fGnKoFzQxuVWaXORPJgMrvwSDsEITp)
  elif fGnKoFzQxuVWaXORPJgMrvwSDsEIqT in['VOD','MOVIE']:
   fGnKoFzQxuVWaXORPJgMrvwSDsEITB.setContentLookup(fGnKoFzQxuVWaXORPJgMrvwSDsEImC)
   fGnKoFzQxuVWaXORPJgMrvwSDsEITB.setMimeType('application/x-mpegURL')
   if fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.KodiVersion<=20:
    fGnKoFzQxuVWaXORPJgMrvwSDsEITB.setProperty('inputstream','inputstream.adaptive')
    if fGnKoFzQxuVWaXORPJgMrvwSDsEITC['stream_action']=='hls':
     fGnKoFzQxuVWaXORPJgMrvwSDsEITB.setProperty('inputstream.adaptive.manifest_type','hls')
    else:
     fGnKoFzQxuVWaXORPJgMrvwSDsEITB.setProperty('inputstream.adaptive.manifest_type','mpd')
   fGnKoFzQxuVWaXORPJgMrvwSDsEITB.setProperty('inputstream.adaptive.stream_headers',fGnKoFzQxuVWaXORPJgMrvwSDsEITp)
   fGnKoFzQxuVWaXORPJgMrvwSDsEITB.setProperty('inputstream.adaptive.manifest_headers',fGnKoFzQxuVWaXORPJgMrvwSDsEITp)
  if fGnKoFzQxuVWaXORPJgMrvwSDsEITC['stream_vtt']:
   fGnKoFzQxuVWaXORPJgMrvwSDsEITB.setSubtitles([fGnKoFzQxuVWaXORPJgMrvwSDsEITC['stream_vtt']])
  xbmcplugin.setResolvedUrl(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA._addon_handle,fGnKoFzQxuVWaXORPJgMrvwSDsEImN,fGnKoFzQxuVWaXORPJgMrvwSDsEITB)
  fGnKoFzQxuVWaXORPJgMrvwSDsEIeh=fGnKoFzQxuVWaXORPJgMrvwSDsEImC
  if fGnKoFzQxuVWaXORPJgMrvwSDsEITC['stream_preview']:
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.addon_noti(fGnKoFzQxuVWaXORPJgMrvwSDsEITC['stream_preview'].encode('utf-8'))
   fGnKoFzQxuVWaXORPJgMrvwSDsEIeh=fGnKoFzQxuVWaXORPJgMrvwSDsEImN
  else:
   if '/preview.' in urllib.parse.urlsplit(fGnKoFzQxuVWaXORPJgMrvwSDsEITC['stream_url']).path:
    fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.addon_noti(__language__(30908).encode('utf8'))
    fGnKoFzQxuVWaXORPJgMrvwSDsEIeh=fGnKoFzQxuVWaXORPJgMrvwSDsEImN
  try:
   fGnKoFzQxuVWaXORPJgMrvwSDsEIem=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and fGnKoFzQxuVWaXORPJgMrvwSDsEIeh==fGnKoFzQxuVWaXORPJgMrvwSDsEImC and fGnKoFzQxuVWaXORPJgMrvwSDsEIem!='-':
    fGnKoFzQxuVWaXORPJgMrvwSDsEILc={'code':fGnKoFzQxuVWaXORPJgMrvwSDsEIem,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.Save_Watched_List(args.get('mode').lower(),fGnKoFzQxuVWaXORPJgMrvwSDsEILc)
  except:
   fGnKoFzQxuVWaXORPJgMrvwSDsEImt
 def logout(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA):
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdN=xbmcgui.Dialog()
  fGnKoFzQxuVWaXORPJgMrvwSDsEITd=fGnKoFzQxuVWaXORPJgMrvwSDsEIdN.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if fGnKoFzQxuVWaXORPJgMrvwSDsEITd==fGnKoFzQxuVWaXORPJgMrvwSDsEImC:sys.exit()
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.Init_WV_Total()
  if os.path.isfile(fGnKoFzQxuVWaXORPJgMrvwSDsEIdh):os.remove(fGnKoFzQxuVWaXORPJgMrvwSDsEIdh)
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA):
  fGnKoFzQxuVWaXORPJgMrvwSDsEIeA =fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.Get_Now_Datetime()
  fGnKoFzQxuVWaXORPJgMrvwSDsEIeb=fGnKoFzQxuVWaXORPJgMrvwSDsEIeA+datetime.timedelta(days=fGnKoFzQxuVWaXORPJgMrvwSDsEImj(__addon__.getSetting('cache_ttl')))
  (fGnKoFzQxuVWaXORPJgMrvwSDsEITh,fGnKoFzQxuVWaXORPJgMrvwSDsEITm,fGnKoFzQxuVWaXORPJgMrvwSDsEITA)=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.get_settings_account()
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.Save_session_acount(fGnKoFzQxuVWaXORPJgMrvwSDsEITh,fGnKoFzQxuVWaXORPJgMrvwSDsEITm,fGnKoFzQxuVWaXORPJgMrvwSDsEITA)
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.WV['account']['token_limit']=fGnKoFzQxuVWaXORPJgMrvwSDsEIeb.strftime('%Y%m%d')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.JsonFile_Save(fGnKoFzQxuVWaXORPJgMrvwSDsEIdh,fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.WV)
 def cookiefile_check(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA):
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.WV=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.JsonFile_Load(fGnKoFzQxuVWaXORPJgMrvwSDsEIdh)
  if 'account' not in fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.WV:
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.Init_WV_Total()
   return fGnKoFzQxuVWaXORPJgMrvwSDsEImC
  if 'uuid' not in fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.WV.get('cookies'):
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.Init_WV_Total()
   return fGnKoFzQxuVWaXORPJgMrvwSDsEImC
  (fGnKoFzQxuVWaXORPJgMrvwSDsEIeU,fGnKoFzQxuVWaXORPJgMrvwSDsEIet,fGnKoFzQxuVWaXORPJgMrvwSDsEIej)=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.get_settings_account()
  (fGnKoFzQxuVWaXORPJgMrvwSDsEIeN,fGnKoFzQxuVWaXORPJgMrvwSDsEIeC,fGnKoFzQxuVWaXORPJgMrvwSDsEIei)=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.Load_session_acount()
  if fGnKoFzQxuVWaXORPJgMrvwSDsEIeU!=fGnKoFzQxuVWaXORPJgMrvwSDsEIeN or fGnKoFzQxuVWaXORPJgMrvwSDsEIet!=fGnKoFzQxuVWaXORPJgMrvwSDsEIeC or fGnKoFzQxuVWaXORPJgMrvwSDsEIej!=fGnKoFzQxuVWaXORPJgMrvwSDsEIei:
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.Init_WV_Total()
   return fGnKoFzQxuVWaXORPJgMrvwSDsEImC
  if fGnKoFzQxuVWaXORPJgMrvwSDsEImj(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))>fGnKoFzQxuVWaXORPJgMrvwSDsEImj(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.WV['account']['token_limit']):
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.Init_WV_Total()
   return fGnKoFzQxuVWaXORPJgMrvwSDsEImC
  return fGnKoFzQxuVWaXORPJgMrvwSDsEImN
 def dp_LiveCatagory_List(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA,args):
  fGnKoFzQxuVWaXORPJgMrvwSDsEIey =args.get('sCode')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIep=args.get('sIndex')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIql,fGnKoFzQxuVWaXORPJgMrvwSDsEIec=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.Get_LiveCatagory_List(fGnKoFzQxuVWaXORPJgMrvwSDsEIey,fGnKoFzQxuVWaXORPJgMrvwSDsEIep)
  for fGnKoFzQxuVWaXORPJgMrvwSDsEIqB in fGnKoFzQxuVWaXORPJgMrvwSDsEIql:
   fGnKoFzQxuVWaXORPJgMrvwSDsEILj =fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('title')
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc={'mode':'LIVE_LIST','genre':fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('genre'),'baseapi':fGnKoFzQxuVWaXORPJgMrvwSDsEIec}
   fGnKoFzQxuVWaXORPJgMrvwSDsEILB={'title':fGnKoFzQxuVWaXORPJgMrvwSDsEILj,'plot':fGnKoFzQxuVWaXORPJgMrvwSDsEILj}
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.add_dir(fGnKoFzQxuVWaXORPJgMrvwSDsEILj,sublabel='',img='',infoLabels=fGnKoFzQxuVWaXORPJgMrvwSDsEILB,isFolder=fGnKoFzQxuVWaXORPJgMrvwSDsEImN,params=fGnKoFzQxuVWaXORPJgMrvwSDsEILc)
  if fGnKoFzQxuVWaXORPJgMrvwSDsEImH(fGnKoFzQxuVWaXORPJgMrvwSDsEIql)>0:xbmcplugin.endOfDirectory(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA._addon_handle,cacheToDisc=fGnKoFzQxuVWaXORPJgMrvwSDsEImC)
 def dp_MainCatagory_List(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA,args):
  fGnKoFzQxuVWaXORPJgMrvwSDsEIey =args.get('sCode')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIep=args.get('sIndex')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIqe =args.get('sType')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIql=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.Get_MainCatagory_List(fGnKoFzQxuVWaXORPJgMrvwSDsEIey,fGnKoFzQxuVWaXORPJgMrvwSDsEIep,fGnKoFzQxuVWaXORPJgMrvwSDsEIqe)
  for fGnKoFzQxuVWaXORPJgMrvwSDsEIqB in fGnKoFzQxuVWaXORPJgMrvwSDsEIql:
   if fGnKoFzQxuVWaXORPJgMrvwSDsEIqe in['vod','vod09']:
    if fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('subtype')=='catagory':
     fGnKoFzQxuVWaXORPJgMrvwSDsEIqT='PROGRAM_LIST'
    else:
     fGnKoFzQxuVWaXORPJgMrvwSDsEIqT='SUPERSECTION_LIST'
   elif fGnKoFzQxuVWaXORPJgMrvwSDsEIqe=='movie':
    fGnKoFzQxuVWaXORPJgMrvwSDsEIqT='MOVIE_LIST'
   else:
    fGnKoFzQxuVWaXORPJgMrvwSDsEIqT=''
   fGnKoFzQxuVWaXORPJgMrvwSDsEILj='%s (%s)'%(fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('title'),args.get('ordernm'))
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc={'mode':fGnKoFzQxuVWaXORPJgMrvwSDsEIqT,'suburl':fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('suburl'),'subapi':fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.get_settings_exclusion21():
    if fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('title')=='성인' or fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('title')=='성인+' or fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('title')=='에로티시즘' or fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('title')=='19':continue
   fGnKoFzQxuVWaXORPJgMrvwSDsEILB={'title':fGnKoFzQxuVWaXORPJgMrvwSDsEILj,'plot':fGnKoFzQxuVWaXORPJgMrvwSDsEILj}
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.add_dir(fGnKoFzQxuVWaXORPJgMrvwSDsEILj,sublabel='',img='',infoLabels=fGnKoFzQxuVWaXORPJgMrvwSDsEILB,isFolder=fGnKoFzQxuVWaXORPJgMrvwSDsEImN,params=fGnKoFzQxuVWaXORPJgMrvwSDsEILc)
  if fGnKoFzQxuVWaXORPJgMrvwSDsEImH(fGnKoFzQxuVWaXORPJgMrvwSDsEIql)>0:xbmcplugin.endOfDirectory(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA._addon_handle,cacheToDisc=fGnKoFzQxuVWaXORPJgMrvwSDsEImC)
 def dp_Program_List(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA,args):
  fGnKoFzQxuVWaXORPJgMrvwSDsEIeH =args.get('subapi')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIqH=fGnKoFzQxuVWaXORPJgMrvwSDsEImj(args.get('page'))
  fGnKoFzQxuVWaXORPJgMrvwSDsEILU =args.get('orderby')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.addon_log('dp_Program_List')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.addon_log(fGnKoFzQxuVWaXORPJgMrvwSDsEIeH)
  fGnKoFzQxuVWaXORPJgMrvwSDsEIql,fGnKoFzQxuVWaXORPJgMrvwSDsEIqm=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.Get_Program_List(fGnKoFzQxuVWaXORPJgMrvwSDsEIeH,fGnKoFzQxuVWaXORPJgMrvwSDsEIqH,fGnKoFzQxuVWaXORPJgMrvwSDsEILU)
  for fGnKoFzQxuVWaXORPJgMrvwSDsEIqB in fGnKoFzQxuVWaXORPJgMrvwSDsEIql:
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqk =fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('videoid')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYd =fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('vidtype')
   fGnKoFzQxuVWaXORPJgMrvwSDsEILj =fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('title')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYL=fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('thumbnail')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYq =fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('age')
   if fGnKoFzQxuVWaXORPJgMrvwSDsEIYq=='18' or fGnKoFzQxuVWaXORPJgMrvwSDsEIYq=='19' or fGnKoFzQxuVWaXORPJgMrvwSDsEIYq=='21':fGnKoFzQxuVWaXORPJgMrvwSDsEILj+=' (%s)'%(fGnKoFzQxuVWaXORPJgMrvwSDsEIYq)
   fGnKoFzQxuVWaXORPJgMrvwSDsEILB={'plot':fGnKoFzQxuVWaXORPJgMrvwSDsEILj,'mpaa':fGnKoFzQxuVWaXORPJgMrvwSDsEIYq,'mediatype':'tvshow','title':fGnKoFzQxuVWaXORPJgMrvwSDsEILj,}
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc={'mode':'SEASON_LIST','videoid':fGnKoFzQxuVWaXORPJgMrvwSDsEIqk,'vidtype':fGnKoFzQxuVWaXORPJgMrvwSDsEIYd,}
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqp=[]
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYT={'mode':'VIEW_DETAIL','values':{'videoid':fGnKoFzQxuVWaXORPJgMrvwSDsEIqk,'vidtype':'tvshow','contenttype':fGnKoFzQxuVWaXORPJgMrvwSDsEIYd,}}
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYe=json.dumps(fGnKoFzQxuVWaXORPJgMrvwSDsEIYT,separators=(',',':'))
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYe=base64.standard_b64encode(fGnKoFzQxuVWaXORPJgMrvwSDsEIYe.encode()).decode('utf-8')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYe=fGnKoFzQxuVWaXORPJgMrvwSDsEIYe.replace('+','%2B')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYh='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(fGnKoFzQxuVWaXORPJgMrvwSDsEIYe)
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqp.append(('상세정보 조회',fGnKoFzQxuVWaXORPJgMrvwSDsEIYh))
   if fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.get_settings_makebookmark():
    fGnKoFzQxuVWaXORPJgMrvwSDsEIYT={'videoid':fGnKoFzQxuVWaXORPJgMrvwSDsEIqk,'vidtype':'tvshow','vtitle':fGnKoFzQxuVWaXORPJgMrvwSDsEILj,'vsubtitle':'','contenttype':fGnKoFzQxuVWaXORPJgMrvwSDsEIYd,}
    fGnKoFzQxuVWaXORPJgMrvwSDsEIYm=json.dumps(fGnKoFzQxuVWaXORPJgMrvwSDsEIYT)
    fGnKoFzQxuVWaXORPJgMrvwSDsEIYm=urllib.parse.quote(fGnKoFzQxuVWaXORPJgMrvwSDsEIYm)
    fGnKoFzQxuVWaXORPJgMrvwSDsEIYh='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(fGnKoFzQxuVWaXORPJgMrvwSDsEIYm)
    fGnKoFzQxuVWaXORPJgMrvwSDsEIqp.append(('(통합) 찜 영상에 추가',fGnKoFzQxuVWaXORPJgMrvwSDsEIYh))
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.add_dir(fGnKoFzQxuVWaXORPJgMrvwSDsEILj,sublabel='',img=fGnKoFzQxuVWaXORPJgMrvwSDsEIYL,infoLabels=fGnKoFzQxuVWaXORPJgMrvwSDsEILB,isFolder=fGnKoFzQxuVWaXORPJgMrvwSDsEImN,params=fGnKoFzQxuVWaXORPJgMrvwSDsEILc,ContextMenu=fGnKoFzQxuVWaXORPJgMrvwSDsEIqp)
  if fGnKoFzQxuVWaXORPJgMrvwSDsEIqm:
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc={}
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc['mode'] ='PROGRAM_LIST' 
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc['subapi']=fGnKoFzQxuVWaXORPJgMrvwSDsEIeH 
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc['page'] =fGnKoFzQxuVWaXORPJgMrvwSDsEImB(fGnKoFzQxuVWaXORPJgMrvwSDsEIqH+1)
   fGnKoFzQxuVWaXORPJgMrvwSDsEILj='[B]%s >>[/B]'%'다음 페이지'
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYA=fGnKoFzQxuVWaXORPJgMrvwSDsEImB(fGnKoFzQxuVWaXORPJgMrvwSDsEIqH+1)
   fGnKoFzQxuVWaXORPJgMrvwSDsEILp=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.add_dir(fGnKoFzQxuVWaXORPJgMrvwSDsEILj,sublabel=fGnKoFzQxuVWaXORPJgMrvwSDsEIYA,img=fGnKoFzQxuVWaXORPJgMrvwSDsEILp,infoLabels=fGnKoFzQxuVWaXORPJgMrvwSDsEImt,isFolder=fGnKoFzQxuVWaXORPJgMrvwSDsEImN,params=fGnKoFzQxuVWaXORPJgMrvwSDsEILc)
  xbmcplugin.setContent(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA._addon_handle,'tvshows')
  if fGnKoFzQxuVWaXORPJgMrvwSDsEImH(fGnKoFzQxuVWaXORPJgMrvwSDsEIql)>0:xbmcplugin.endOfDirectory(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA._addon_handle,cacheToDisc=fGnKoFzQxuVWaXORPJgMrvwSDsEImC)
 def dp_Season_List(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA,args):
  fGnKoFzQxuVWaXORPJgMrvwSDsEIqk=args.get('videoid')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIYd=args.get('vidtype')
  if fGnKoFzQxuVWaXORPJgMrvwSDsEIYd=='contentid':
   fGnKoFzQxuVWaXORPJgMrvwSDsEITt=fGnKoFzQxuVWaXORPJgMrvwSDsEIqk
   fGnKoFzQxuVWaXORPJgMrvwSDsEIel =fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.ContentidToSeasonid(fGnKoFzQxuVWaXORPJgMrvwSDsEIqk)
  else:
   fGnKoFzQxuVWaXORPJgMrvwSDsEITt=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.ProgramidToContentid(fGnKoFzQxuVWaXORPJgMrvwSDsEIqk)
   fGnKoFzQxuVWaXORPJgMrvwSDsEIel =fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.ContentidToSeasonid(fGnKoFzQxuVWaXORPJgMrvwSDsEITt)
  fGnKoFzQxuVWaXORPJgMrvwSDsEIeB=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.Get_Season_List(fGnKoFzQxuVWaXORPJgMrvwSDsEIel)
  if fGnKoFzQxuVWaXORPJgMrvwSDsEImH(fGnKoFzQxuVWaXORPJgMrvwSDsEIeB)>1:
   for fGnKoFzQxuVWaXORPJgMrvwSDsEIek in fGnKoFzQxuVWaXORPJgMrvwSDsEIeB:
    fGnKoFzQxuVWaXORPJgMrvwSDsEIhd=fGnKoFzQxuVWaXORPJgMrvwSDsEIek.get('season_Id')
    fGnKoFzQxuVWaXORPJgMrvwSDsEIhL=fGnKoFzQxuVWaXORPJgMrvwSDsEIek.get('season_Nm')
    fGnKoFzQxuVWaXORPJgMrvwSDsEIhq=fGnKoFzQxuVWaXORPJgMrvwSDsEIek.get('programNm')
    fGnKoFzQxuVWaXORPJgMrvwSDsEIYL=fGnKoFzQxuVWaXORPJgMrvwSDsEIek.get('thumbnail')
    fGnKoFzQxuVWaXORPJgMrvwSDsEIhY =fGnKoFzQxuVWaXORPJgMrvwSDsEIek.get('synopsis')
    fGnKoFzQxuVWaXORPJgMrvwSDsEIqc={'mediatype':'tvshow','title':fGnKoFzQxuVWaXORPJgMrvwSDsEIhL,'plot':fGnKoFzQxuVWaXORPJgMrvwSDsEIhY,}
    fGnKoFzQxuVWaXORPJgMrvwSDsEILc={'mode':'EPISODE_LIST','seasonid':fGnKoFzQxuVWaXORPJgMrvwSDsEIhd,'page':'1',}
    fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.add_dir(fGnKoFzQxuVWaXORPJgMrvwSDsEIhL,sublabel=fGnKoFzQxuVWaXORPJgMrvwSDsEIhq,img=fGnKoFzQxuVWaXORPJgMrvwSDsEIYL,infoLabels=fGnKoFzQxuVWaXORPJgMrvwSDsEIqc,isFolder=fGnKoFzQxuVWaXORPJgMrvwSDsEImN,params=fGnKoFzQxuVWaXORPJgMrvwSDsEILc,ContextMenu=fGnKoFzQxuVWaXORPJgMrvwSDsEImt)
   xbmcplugin.setContent(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA._addon_handle,'seasons')
   xbmcplugin.endOfDirectory(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA._addon_handle,cacheToDisc=fGnKoFzQxuVWaXORPJgMrvwSDsEImC)
  else:
   fGnKoFzQxuVWaXORPJgMrvwSDsEIhT={'seasonid':fGnKoFzQxuVWaXORPJgMrvwSDsEIel,'page':'1',}
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.dp_Episode_List(fGnKoFzQxuVWaXORPJgMrvwSDsEIhT)
 def dp_Episode_List(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA,args):
  fGnKoFzQxuVWaXORPJgMrvwSDsEIel =args.get('seasonid')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIqH =fGnKoFzQxuVWaXORPJgMrvwSDsEImj(args.get('page'))
  fGnKoFzQxuVWaXORPJgMrvwSDsEIql,fGnKoFzQxuVWaXORPJgMrvwSDsEIqm=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.Get_Episode_List(fGnKoFzQxuVWaXORPJgMrvwSDsEIel,fGnKoFzQxuVWaXORPJgMrvwSDsEIqH,orderby=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.get_winEpisodeOrderby())
  for fGnKoFzQxuVWaXORPJgMrvwSDsEIqB in fGnKoFzQxuVWaXORPJgMrvwSDsEIql:
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYA=fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('episodenumber')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIhe ='[%s]\n\n%s'%(fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('episodetitle'),fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('synopsis'))
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqc={'mediatype':'episode','title':fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('programtitle'),'plot':fGnKoFzQxuVWaXORPJgMrvwSDsEIhe,'cast':fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('episodeactors'),}
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc={'mode':'VOD','programid':fGnKoFzQxuVWaXORPJgMrvwSDsEIel,'contentid':fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('contentid'),'thumbnail':fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('thumbnail'),'title':fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('programtitle'),'subtitle':fGnKoFzQxuVWaXORPJgMrvwSDsEIYA,}
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.add_dir(fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('programtitle'),sublabel=fGnKoFzQxuVWaXORPJgMrvwSDsEIYA,img=fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('thumbnail'),infoLabels=fGnKoFzQxuVWaXORPJgMrvwSDsEIqc,isFolder=fGnKoFzQxuVWaXORPJgMrvwSDsEImC,params=fGnKoFzQxuVWaXORPJgMrvwSDsEILc)
  if fGnKoFzQxuVWaXORPJgMrvwSDsEIqH==1:
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqc={'plot':'정렬순서를 변경합니다.'}
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc={}
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc['mode'] ='ORDER_BY' 
   if fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.get_winEpisodeOrderby()=='desc':
    fGnKoFzQxuVWaXORPJgMrvwSDsEILj='정렬순서변경 : 최신화부터 -> 1회부터'
    fGnKoFzQxuVWaXORPJgMrvwSDsEILc['orderby']='asc'
   else:
    fGnKoFzQxuVWaXORPJgMrvwSDsEILj='정렬순서변경 : 1회부터 -> 최신화부터'
    fGnKoFzQxuVWaXORPJgMrvwSDsEILc['orderby']='desc'
   fGnKoFzQxuVWaXORPJgMrvwSDsEILp=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.add_dir(fGnKoFzQxuVWaXORPJgMrvwSDsEILj,sublabel='',img=fGnKoFzQxuVWaXORPJgMrvwSDsEILp,infoLabels=fGnKoFzQxuVWaXORPJgMrvwSDsEIqc,isFolder=fGnKoFzQxuVWaXORPJgMrvwSDsEImC,params=fGnKoFzQxuVWaXORPJgMrvwSDsEILc,isLink=fGnKoFzQxuVWaXORPJgMrvwSDsEImN)
  if fGnKoFzQxuVWaXORPJgMrvwSDsEIqm:
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc={}
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc['mode'] ='EPISODE_LIST' 
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc['seasonid']=fGnKoFzQxuVWaXORPJgMrvwSDsEIel
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc['page'] =fGnKoFzQxuVWaXORPJgMrvwSDsEImB(fGnKoFzQxuVWaXORPJgMrvwSDsEIqH+1)
   fGnKoFzQxuVWaXORPJgMrvwSDsEILj='[B]%s >>[/B]'%'다음 페이지'
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYA=fGnKoFzQxuVWaXORPJgMrvwSDsEImB(fGnKoFzQxuVWaXORPJgMrvwSDsEIqH+1)
   fGnKoFzQxuVWaXORPJgMrvwSDsEILp=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.add_dir(fGnKoFzQxuVWaXORPJgMrvwSDsEILj,sublabel=fGnKoFzQxuVWaXORPJgMrvwSDsEIYA,img=fGnKoFzQxuVWaXORPJgMrvwSDsEILp,infoLabels=fGnKoFzQxuVWaXORPJgMrvwSDsEImt,isFolder=fGnKoFzQxuVWaXORPJgMrvwSDsEImN,params=fGnKoFzQxuVWaXORPJgMrvwSDsEILc)
  xbmcplugin.setContent(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA._addon_handle,'episodes')
  if fGnKoFzQxuVWaXORPJgMrvwSDsEImH(fGnKoFzQxuVWaXORPJgMrvwSDsEIql)>0:xbmcplugin.endOfDirectory(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA._addon_handle,cacheToDisc=fGnKoFzQxuVWaXORPJgMrvwSDsEImC)
 def dp_SuperSection_List(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA,args):
  fGnKoFzQxuVWaXORPJgMrvwSDsEIhm =args.get('suburl')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIeH =args.get('subapi')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.addon_log('dp_SuperSection_List')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.addon_log('suburl : '+fGnKoFzQxuVWaXORPJgMrvwSDsEIhm)
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.addon_log('subapi : '+fGnKoFzQxuVWaXORPJgMrvwSDsEIeH)
  fGnKoFzQxuVWaXORPJgMrvwSDsEIql=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.Get_SuperMultiSection_List(fGnKoFzQxuVWaXORPJgMrvwSDsEIhm)
  for fGnKoFzQxuVWaXORPJgMrvwSDsEIqB in fGnKoFzQxuVWaXORPJgMrvwSDsEIql:
   fGnKoFzQxuVWaXORPJgMrvwSDsEILj =fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('title')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIeH =fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('subapi')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIhA=fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('cell_type')
   if fGnKoFzQxuVWaXORPJgMrvwSDsEIeH.find('contenttype=movie')>=0 or fGnKoFzQxuVWaXORPJgMrvwSDsEIeH.find('mtype=svod')>=0:
    fGnKoFzQxuVWaXORPJgMrvwSDsEIqT='MOVIE_LIST'
   elif re.search('themes/2\d{4}',fGnKoFzQxuVWaXORPJgMrvwSDsEIeH)or re.search('themes-band/9\d{4}',fGnKoFzQxuVWaXORPJgMrvwSDsEIeH):
    fGnKoFzQxuVWaXORPJgMrvwSDsEIqT='MOVIE_LIST'
   else:
    fGnKoFzQxuVWaXORPJgMrvwSDsEIqT='PROGRAM_LIST'
   '''
   if subapi.find('mtype=svod') >= 0 or subapi.find('mtype=ppv') >= 0 or subapi.find('contenttype=movie') >= 0: #영화 #20201107
    mode = 'MOVIE_LIST'
   elif subapi.find('contenttype=program') >= 0:
    mode = 'PROGRAM_LIST'
   elif cell_type == 'band_71': # band_71 #20201107
    mode   = 'SUPERSECTION_LIST'
    (temp_url, temp_api) = self.WavveObj.Baseapi_Parse(subapi)
    suburl = temp_api.get('api')
    subapi = ''
   elif cell_type == 'band_2': # band_2
    mode = 'BAND2SECTION_LIST'
   elif cell_type == 'band_live':
    mode = 'BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}', subapi) :
    mode = 'MOVIE_LIST'
   else: # band_10
    mode = 'PROGRAM_LIST'
   '''   
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqc={'plot':fGnKoFzQxuVWaXORPJgMrvwSDsEILj,'mediatype':'tvshow',}
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc={'mode':fGnKoFzQxuVWaXORPJgMrvwSDsEIqT,'suburl':fGnKoFzQxuVWaXORPJgMrvwSDsEIhm,'subapi':fGnKoFzQxuVWaXORPJgMrvwSDsEIeH,'page':'1',}
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.add_dir(fGnKoFzQxuVWaXORPJgMrvwSDsEILj,sublabel='',img=fGnKoFzQxuVWaXORPJgMrvwSDsEImt,infoLabels=fGnKoFzQxuVWaXORPJgMrvwSDsEIqc,isFolder=fGnKoFzQxuVWaXORPJgMrvwSDsEImN,params=fGnKoFzQxuVWaXORPJgMrvwSDsEILc)
  if fGnKoFzQxuVWaXORPJgMrvwSDsEImH(fGnKoFzQxuVWaXORPJgMrvwSDsEIql)>0:xbmcplugin.endOfDirectory(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA._addon_handle,cacheToDisc=fGnKoFzQxuVWaXORPJgMrvwSDsEImC)
 def dp_BandLiveSection_List(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA,args):
  fGnKoFzQxuVWaXORPJgMrvwSDsEIeH =args.get('subapi')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIqH=fGnKoFzQxuVWaXORPJgMrvwSDsEImj(args.get('page'))
  fGnKoFzQxuVWaXORPJgMrvwSDsEIql,fGnKoFzQxuVWaXORPJgMrvwSDsEIqm=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.Get_BandLiveSection_List(fGnKoFzQxuVWaXORPJgMrvwSDsEIeH,fGnKoFzQxuVWaXORPJgMrvwSDsEIqH)
  for fGnKoFzQxuVWaXORPJgMrvwSDsEIqB in fGnKoFzQxuVWaXORPJgMrvwSDsEIql:
   fGnKoFzQxuVWaXORPJgMrvwSDsEIhb =fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('channelid')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIhU =fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('studio')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIht=fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('tvshowtitle')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYL =fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('thumbnail')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYq =fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('age')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqc={'mediatype':'tvshow','mpaa':fGnKoFzQxuVWaXORPJgMrvwSDsEIYq,'title':'%s < %s >'%(fGnKoFzQxuVWaXORPJgMrvwSDsEIhU,fGnKoFzQxuVWaXORPJgMrvwSDsEIht),'tvshowtitle':fGnKoFzQxuVWaXORPJgMrvwSDsEIht,'studio':fGnKoFzQxuVWaXORPJgMrvwSDsEIhU,'plot':fGnKoFzQxuVWaXORPJgMrvwSDsEIhU}
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc={'mode':'LIVE','contentid':fGnKoFzQxuVWaXORPJgMrvwSDsEIhb}
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.add_dir(fGnKoFzQxuVWaXORPJgMrvwSDsEIhU,sublabel=fGnKoFzQxuVWaXORPJgMrvwSDsEIht,img=fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('thumbnail'),infoLabels=fGnKoFzQxuVWaXORPJgMrvwSDsEIqc,isFolder=fGnKoFzQxuVWaXORPJgMrvwSDsEImC,params=fGnKoFzQxuVWaXORPJgMrvwSDsEILc)
  if fGnKoFzQxuVWaXORPJgMrvwSDsEIqm:
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc={}
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc['mode'] ='BANDLIVESECTION_LIST' 
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc['subapi']=fGnKoFzQxuVWaXORPJgMrvwSDsEIeH
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc['page'] =fGnKoFzQxuVWaXORPJgMrvwSDsEImB(fGnKoFzQxuVWaXORPJgMrvwSDsEIqH+1)
   fGnKoFzQxuVWaXORPJgMrvwSDsEILj='[B]%s >>[/B]'%'다음 페이지'
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYA=fGnKoFzQxuVWaXORPJgMrvwSDsEImB(fGnKoFzQxuVWaXORPJgMrvwSDsEIqH+1)
   fGnKoFzQxuVWaXORPJgMrvwSDsEILp=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.add_dir(fGnKoFzQxuVWaXORPJgMrvwSDsEILj,sublabel=fGnKoFzQxuVWaXORPJgMrvwSDsEIYA,img=fGnKoFzQxuVWaXORPJgMrvwSDsEILp,infoLabels=fGnKoFzQxuVWaXORPJgMrvwSDsEImt,isFolder=fGnKoFzQxuVWaXORPJgMrvwSDsEImN,params=fGnKoFzQxuVWaXORPJgMrvwSDsEILc)
  if fGnKoFzQxuVWaXORPJgMrvwSDsEImH(fGnKoFzQxuVWaXORPJgMrvwSDsEIql)>0:xbmcplugin.endOfDirectory(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA._addon_handle,cacheToDisc=fGnKoFzQxuVWaXORPJgMrvwSDsEImC)
 def dp_Band2Section_List(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA,args):
  fGnKoFzQxuVWaXORPJgMrvwSDsEIeH =args.get('subapi')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIqH=fGnKoFzQxuVWaXORPJgMrvwSDsEImj(args.get('page'))
  fGnKoFzQxuVWaXORPJgMrvwSDsEIql,fGnKoFzQxuVWaXORPJgMrvwSDsEIqm=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.Get_Band2Section_List(fGnKoFzQxuVWaXORPJgMrvwSDsEIeH,fGnKoFzQxuVWaXORPJgMrvwSDsEIqH)
  for fGnKoFzQxuVWaXORPJgMrvwSDsEIqB in fGnKoFzQxuVWaXORPJgMrvwSDsEIql:
   fGnKoFzQxuVWaXORPJgMrvwSDsEILj =fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('programtitle')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYA =fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('episodetitle')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqc={'plot':fGnKoFzQxuVWaXORPJgMrvwSDsEILj+'\n\n'+fGnKoFzQxuVWaXORPJgMrvwSDsEIYA,'mpaa':fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('age'),'mediatype':'episode'}
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc={'mode':'VOD','programid':'-','contentid':fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('videoid'),'thumbnail':fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('thumbnail'),'title':fGnKoFzQxuVWaXORPJgMrvwSDsEILj,'subtitle':fGnKoFzQxuVWaXORPJgMrvwSDsEIYA}
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.add_dir(fGnKoFzQxuVWaXORPJgMrvwSDsEILj,sublabel=fGnKoFzQxuVWaXORPJgMrvwSDsEIYA,img=fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('thumbnail'),infoLabels=fGnKoFzQxuVWaXORPJgMrvwSDsEIqc,isFolder=fGnKoFzQxuVWaXORPJgMrvwSDsEImC,params=fGnKoFzQxuVWaXORPJgMrvwSDsEILc)
  if fGnKoFzQxuVWaXORPJgMrvwSDsEIqm:
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc={}
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc['mode'] ='BAND2SECTION_LIST' 
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc['subapi']=fGnKoFzQxuVWaXORPJgMrvwSDsEIeH
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc['page'] =fGnKoFzQxuVWaXORPJgMrvwSDsEImB(fGnKoFzQxuVWaXORPJgMrvwSDsEIqH+1)
   fGnKoFzQxuVWaXORPJgMrvwSDsEILj='[B]%s >>[/B]'%'다음 페이지'
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYA=fGnKoFzQxuVWaXORPJgMrvwSDsEImB(fGnKoFzQxuVWaXORPJgMrvwSDsEIqH+1)
   fGnKoFzQxuVWaXORPJgMrvwSDsEILp=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.add_dir(fGnKoFzQxuVWaXORPJgMrvwSDsEILj,sublabel=fGnKoFzQxuVWaXORPJgMrvwSDsEIYA,img=fGnKoFzQxuVWaXORPJgMrvwSDsEILp,infoLabels=fGnKoFzQxuVWaXORPJgMrvwSDsEImt,isFolder=fGnKoFzQxuVWaXORPJgMrvwSDsEImN,params=fGnKoFzQxuVWaXORPJgMrvwSDsEILc)
  if fGnKoFzQxuVWaXORPJgMrvwSDsEImH(fGnKoFzQxuVWaXORPJgMrvwSDsEIql)>0:xbmcplugin.endOfDirectory(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA._addon_handle,cacheToDisc=fGnKoFzQxuVWaXORPJgMrvwSDsEImC)
 def dp_Movie_List(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA,args):
  fGnKoFzQxuVWaXORPJgMrvwSDsEIeH =args.get('subapi')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIqH=fGnKoFzQxuVWaXORPJgMrvwSDsEImj(args.get('page'))
  fGnKoFzQxuVWaXORPJgMrvwSDsEILU =args.get('orderby')or '-'
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.addon_log('dp_Movie_List')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.addon_log(fGnKoFzQxuVWaXORPJgMrvwSDsEIeH)
  fGnKoFzQxuVWaXORPJgMrvwSDsEIql,fGnKoFzQxuVWaXORPJgMrvwSDsEIqm=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.Get_Movie_List(fGnKoFzQxuVWaXORPJgMrvwSDsEIeH,fGnKoFzQxuVWaXORPJgMrvwSDsEIqH,fGnKoFzQxuVWaXORPJgMrvwSDsEILU)
  for fGnKoFzQxuVWaXORPJgMrvwSDsEIqB in fGnKoFzQxuVWaXORPJgMrvwSDsEIql:
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqk =fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('videoid')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYd =fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('vidtype')
   fGnKoFzQxuVWaXORPJgMrvwSDsEILj =fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('title')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYL=fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('thumbnail')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYq =fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('age')
   if fGnKoFzQxuVWaXORPJgMrvwSDsEIYq=='18' or fGnKoFzQxuVWaXORPJgMrvwSDsEIYq=='19' or fGnKoFzQxuVWaXORPJgMrvwSDsEIYq=='21':fGnKoFzQxuVWaXORPJgMrvwSDsEILj+=' (%s)'%(fGnKoFzQxuVWaXORPJgMrvwSDsEIYq)
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqc={'plot':fGnKoFzQxuVWaXORPJgMrvwSDsEILj,'mpaa':fGnKoFzQxuVWaXORPJgMrvwSDsEIYq,'mediatype':'movie'}
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc={'mode':'MOVIE','contentid':fGnKoFzQxuVWaXORPJgMrvwSDsEIqk,'title':fGnKoFzQxuVWaXORPJgMrvwSDsEILj,'thumbnail':fGnKoFzQxuVWaXORPJgMrvwSDsEIYL,'age':fGnKoFzQxuVWaXORPJgMrvwSDsEIYq,}
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqp=[]
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYT={'mode':'VIEW_DETAIL','values':{'videoid':fGnKoFzQxuVWaXORPJgMrvwSDsEIqk,'vidtype':'movie','contenttype':fGnKoFzQxuVWaXORPJgMrvwSDsEIYd,}}
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYe=json.dumps(fGnKoFzQxuVWaXORPJgMrvwSDsEIYT,separators=(',',':'))
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYe=base64.standard_b64encode(fGnKoFzQxuVWaXORPJgMrvwSDsEIYe.encode()).decode('utf-8')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYe=fGnKoFzQxuVWaXORPJgMrvwSDsEIYe.replace('+','%2B')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYh='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(fGnKoFzQxuVWaXORPJgMrvwSDsEIYe)
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqp.append(('상세정보 조회',fGnKoFzQxuVWaXORPJgMrvwSDsEIYh))
   if fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.get_settings_makebookmark():
    fGnKoFzQxuVWaXORPJgMrvwSDsEIYT={'videoid':fGnKoFzQxuVWaXORPJgMrvwSDsEIqk,'vidtype':'movie','vtitle':fGnKoFzQxuVWaXORPJgMrvwSDsEILj,'vsubtitle':'','contenttype':'programid',}
    fGnKoFzQxuVWaXORPJgMrvwSDsEIYm=json.dumps(fGnKoFzQxuVWaXORPJgMrvwSDsEIYT)
    fGnKoFzQxuVWaXORPJgMrvwSDsEIYm=urllib.parse.quote(fGnKoFzQxuVWaXORPJgMrvwSDsEIYm)
    fGnKoFzQxuVWaXORPJgMrvwSDsEIYh='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(fGnKoFzQxuVWaXORPJgMrvwSDsEIYm)
    fGnKoFzQxuVWaXORPJgMrvwSDsEIqp.append(('(통합) 찜 영상에 추가',fGnKoFzQxuVWaXORPJgMrvwSDsEIYh))
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.add_dir(fGnKoFzQxuVWaXORPJgMrvwSDsEILj,sublabel='',img=fGnKoFzQxuVWaXORPJgMrvwSDsEIYL,infoLabels=fGnKoFzQxuVWaXORPJgMrvwSDsEIqc,isFolder=fGnKoFzQxuVWaXORPJgMrvwSDsEImC,params=fGnKoFzQxuVWaXORPJgMrvwSDsEILc,ContextMenu=fGnKoFzQxuVWaXORPJgMrvwSDsEIqp)
  if fGnKoFzQxuVWaXORPJgMrvwSDsEIqm:
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc={}
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc['mode'] ='MOVIE_LIST' 
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc['subapi']=fGnKoFzQxuVWaXORPJgMrvwSDsEIeH 
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc['page'] =fGnKoFzQxuVWaXORPJgMrvwSDsEImB(fGnKoFzQxuVWaXORPJgMrvwSDsEIqH+1)
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc['orderby']=fGnKoFzQxuVWaXORPJgMrvwSDsEILU
   fGnKoFzQxuVWaXORPJgMrvwSDsEILj='[B]%s >>[/B]'%'다음 페이지'
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYA=fGnKoFzQxuVWaXORPJgMrvwSDsEImB(fGnKoFzQxuVWaXORPJgMrvwSDsEIqH+1)
   fGnKoFzQxuVWaXORPJgMrvwSDsEILp=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.add_dir(fGnKoFzQxuVWaXORPJgMrvwSDsEILj,sublabel=fGnKoFzQxuVWaXORPJgMrvwSDsEIYA,img=fGnKoFzQxuVWaXORPJgMrvwSDsEILp,infoLabels=fGnKoFzQxuVWaXORPJgMrvwSDsEImt,isFolder=fGnKoFzQxuVWaXORPJgMrvwSDsEImN,params=fGnKoFzQxuVWaXORPJgMrvwSDsEILc)
  xbmcplugin.setContent(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA._addon_handle,'movies')
  if fGnKoFzQxuVWaXORPJgMrvwSDsEImH(fGnKoFzQxuVWaXORPJgMrvwSDsEIql)>0:xbmcplugin.endOfDirectory(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA._addon_handle,cacheToDisc=fGnKoFzQxuVWaXORPJgMrvwSDsEImC)
 def dp_Set_Bookmark(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA,args):
  fGnKoFzQxuVWaXORPJgMrvwSDsEIhj=urllib.parse.unquote(args.get('bm_param'))
  fGnKoFzQxuVWaXORPJgMrvwSDsEIhj=json.loads(fGnKoFzQxuVWaXORPJgMrvwSDsEIhj)
  fGnKoFzQxuVWaXORPJgMrvwSDsEIqk =fGnKoFzQxuVWaXORPJgMrvwSDsEIhj.get('videoid')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIYd =fGnKoFzQxuVWaXORPJgMrvwSDsEIhj.get('vidtype')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIhN =fGnKoFzQxuVWaXORPJgMrvwSDsEIhj.get('vtitle')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIhC =fGnKoFzQxuVWaXORPJgMrvwSDsEIhj.get('vsubtitle')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIhi=fGnKoFzQxuVWaXORPJgMrvwSDsEIhj.get('contenttype')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdN=xbmcgui.Dialog()
  fGnKoFzQxuVWaXORPJgMrvwSDsEITd=fGnKoFzQxuVWaXORPJgMrvwSDsEIdN.yesno(__language__(30913).encode('utf8'),fGnKoFzQxuVWaXORPJgMrvwSDsEIhN+' \n\n'+__language__(30914))
  if fGnKoFzQxuVWaXORPJgMrvwSDsEITd==fGnKoFzQxuVWaXORPJgMrvwSDsEImC:return
  fGnKoFzQxuVWaXORPJgMrvwSDsEIhy=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.GetBookmarkInfo(fGnKoFzQxuVWaXORPJgMrvwSDsEIqk,fGnKoFzQxuVWaXORPJgMrvwSDsEIYd,fGnKoFzQxuVWaXORPJgMrvwSDsEIhi)
  fGnKoFzQxuVWaXORPJgMrvwSDsEIhp=json.dumps(fGnKoFzQxuVWaXORPJgMrvwSDsEIhy)
  fGnKoFzQxuVWaXORPJgMrvwSDsEIhp=urllib.parse.quote(fGnKoFzQxuVWaXORPJgMrvwSDsEIhp)
  fGnKoFzQxuVWaXORPJgMrvwSDsEIYh ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(fGnKoFzQxuVWaXORPJgMrvwSDsEIhp)
  xbmc.executebuiltin(fGnKoFzQxuVWaXORPJgMrvwSDsEIYh)
 def dp_LiveChannel_List(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA,args):
  fGnKoFzQxuVWaXORPJgMrvwSDsEIhc =args.get('genre')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIec=args.get('baseapi')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIql=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.Get_LiveChannel_List(fGnKoFzQxuVWaXORPJgMrvwSDsEIhc,fGnKoFzQxuVWaXORPJgMrvwSDsEIec)
  for fGnKoFzQxuVWaXORPJgMrvwSDsEIqB in fGnKoFzQxuVWaXORPJgMrvwSDsEIql:
   fGnKoFzQxuVWaXORPJgMrvwSDsEIhb =fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('channelid')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIhU =fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('studio')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIht=fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('tvshowtitle')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYL =fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('thumbnail')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIYq =fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('age')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIhH =fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('epg')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqc={'mediatype':'episode','mpaa':fGnKoFzQxuVWaXORPJgMrvwSDsEIYq,'title':'%s < %s >'%(fGnKoFzQxuVWaXORPJgMrvwSDsEIhU,fGnKoFzQxuVWaXORPJgMrvwSDsEIht),'tvshowtitle':fGnKoFzQxuVWaXORPJgMrvwSDsEIht,'studio':fGnKoFzQxuVWaXORPJgMrvwSDsEIhU,'plot':'%s\n\n%s'%(fGnKoFzQxuVWaXORPJgMrvwSDsEIhU,fGnKoFzQxuVWaXORPJgMrvwSDsEIhH)}
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc={'mode':'LIVE','contentid':fGnKoFzQxuVWaXORPJgMrvwSDsEIhb}
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.add_dir(fGnKoFzQxuVWaXORPJgMrvwSDsEIhU,sublabel=fGnKoFzQxuVWaXORPJgMrvwSDsEIht,img=fGnKoFzQxuVWaXORPJgMrvwSDsEIYL,infoLabels=fGnKoFzQxuVWaXORPJgMrvwSDsEIqc,isFolder=fGnKoFzQxuVWaXORPJgMrvwSDsEImC,params=fGnKoFzQxuVWaXORPJgMrvwSDsEILc)
  if fGnKoFzQxuVWaXORPJgMrvwSDsEImH(fGnKoFzQxuVWaXORPJgMrvwSDsEIql)>0:xbmcplugin.endOfDirectory(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA._addon_handle,cacheToDisc=fGnKoFzQxuVWaXORPJgMrvwSDsEImC)
 def dp_Sports_GameList(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA,args):
  fGnKoFzQxuVWaXORPJgMrvwSDsEIql=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.Get_Sports_Gamelist()
  for fGnKoFzQxuVWaXORPJgMrvwSDsEIqB in fGnKoFzQxuVWaXORPJgMrvwSDsEIql:
   fGnKoFzQxuVWaXORPJgMrvwSDsEIhl =fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('game_date')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIhB =fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('game_time')
   fGnKoFzQxuVWaXORPJgMrvwSDsEIhk =fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('svc_id')
   fGnKoFzQxuVWaXORPJgMrvwSDsEImd =fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('away_team')
   fGnKoFzQxuVWaXORPJgMrvwSDsEImL =fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('home_team')
   fGnKoFzQxuVWaXORPJgMrvwSDsEImq=fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('game_status')
   fGnKoFzQxuVWaXORPJgMrvwSDsEImY =fGnKoFzQxuVWaXORPJgMrvwSDsEIqB.get('game_place')
   fGnKoFzQxuVWaXORPJgMrvwSDsEImT ='%s vs %s (%s)'%(fGnKoFzQxuVWaXORPJgMrvwSDsEImd,fGnKoFzQxuVWaXORPJgMrvwSDsEImL,fGnKoFzQxuVWaXORPJgMrvwSDsEImY)
   fGnKoFzQxuVWaXORPJgMrvwSDsEIme =fGnKoFzQxuVWaXORPJgMrvwSDsEIhl+' '+fGnKoFzQxuVWaXORPJgMrvwSDsEIhB
   if fGnKoFzQxuVWaXORPJgMrvwSDsEImq=='LIVE':
    fGnKoFzQxuVWaXORPJgMrvwSDsEImq='~경기중~'
   elif fGnKoFzQxuVWaXORPJgMrvwSDsEImq=='END':
    fGnKoFzQxuVWaXORPJgMrvwSDsEImq='경기종료'
   elif fGnKoFzQxuVWaXORPJgMrvwSDsEImq=='CANCEL':
    fGnKoFzQxuVWaXORPJgMrvwSDsEImq='취소'
   else:
    fGnKoFzQxuVWaXORPJgMrvwSDsEImq=''
   if fGnKoFzQxuVWaXORPJgMrvwSDsEImq=='':
    fGnKoFzQxuVWaXORPJgMrvwSDsEIYA=fGnKoFzQxuVWaXORPJgMrvwSDsEImT
   else:
    fGnKoFzQxuVWaXORPJgMrvwSDsEIYA=fGnKoFzQxuVWaXORPJgMrvwSDsEImT+'  '+fGnKoFzQxuVWaXORPJgMrvwSDsEImq
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqc={'mediatype':'episode','title':fGnKoFzQxuVWaXORPJgMrvwSDsEImT,'plot':'%s\n\n%s\n\n%s'%(fGnKoFzQxuVWaXORPJgMrvwSDsEIme,fGnKoFzQxuVWaXORPJgMrvwSDsEImT,fGnKoFzQxuVWaXORPJgMrvwSDsEImq)}
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc={'mode':'SPORTS','contentid':fGnKoFzQxuVWaXORPJgMrvwSDsEIhk}
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.add_dir(fGnKoFzQxuVWaXORPJgMrvwSDsEIme,sublabel=fGnKoFzQxuVWaXORPJgMrvwSDsEIYA,img='',infoLabels=fGnKoFzQxuVWaXORPJgMrvwSDsEIqc,isFolder=fGnKoFzQxuVWaXORPJgMrvwSDsEImC,params=fGnKoFzQxuVWaXORPJgMrvwSDsEILc)
  xbmcplugin.endOfDirectory(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA._addon_handle,cacheToDisc=fGnKoFzQxuVWaXORPJgMrvwSDsEImC)
 def dp_View_Detail(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA,fGnKoFzQxuVWaXORPJgMrvwSDsEImb):
  fGnKoFzQxuVWaXORPJgMrvwSDsEIqk =fGnKoFzQxuVWaXORPJgMrvwSDsEImb.get('videoid')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIYd =fGnKoFzQxuVWaXORPJgMrvwSDsEImb.get('vidtype') 
  fGnKoFzQxuVWaXORPJgMrvwSDsEIhi=fGnKoFzQxuVWaXORPJgMrvwSDsEImb.get('contenttype')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.addon_log(fGnKoFzQxuVWaXORPJgMrvwSDsEIqk)
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.addon_log(fGnKoFzQxuVWaXORPJgMrvwSDsEIYd)
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.addon_log(fGnKoFzQxuVWaXORPJgMrvwSDsEIhi)
  fGnKoFzQxuVWaXORPJgMrvwSDsEIhy=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.GetBookmarkInfo(fGnKoFzQxuVWaXORPJgMrvwSDsEIqk,fGnKoFzQxuVWaXORPJgMrvwSDsEIYd,fGnKoFzQxuVWaXORPJgMrvwSDsEIhi)
  if fGnKoFzQxuVWaXORPJgMrvwSDsEIYd=='tvshow':
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc={'mode':'SEASON_LIST','videoid':fGnKoFzQxuVWaXORPJgMrvwSDsEIhy['indexinfo']['videoid'],'vidtype':fGnKoFzQxuVWaXORPJgMrvwSDsEIhy['indexinfo']['vidtype'],}
   fGnKoFzQxuVWaXORPJgMrvwSDsEITe='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(fGnKoFzQxuVWaXORPJgMrvwSDsEILc))
  else:
   fGnKoFzQxuVWaXORPJgMrvwSDsEILc={'mode':'MOVIE','contentid':fGnKoFzQxuVWaXORPJgMrvwSDsEIhy['indexinfo']['videoid'],'title':fGnKoFzQxuVWaXORPJgMrvwSDsEIhy['saveinfo']['infoLabels']['title'],'thumbnail':fGnKoFzQxuVWaXORPJgMrvwSDsEIhy['saveinfo']['thumbnail'],'age':fGnKoFzQxuVWaXORPJgMrvwSDsEIhy['saveinfo']['infoLabels']['mpaa'],}
   fGnKoFzQxuVWaXORPJgMrvwSDsEITe='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(fGnKoFzQxuVWaXORPJgMrvwSDsEILc))
  fGnKoFzQxuVWaXORPJgMrvwSDsEILN=xbmcgui.ListItem(label=fGnKoFzQxuVWaXORPJgMrvwSDsEIhy['saveinfo']['title'],path=fGnKoFzQxuVWaXORPJgMrvwSDsEITe)
  fGnKoFzQxuVWaXORPJgMrvwSDsEILN.setArt(fGnKoFzQxuVWaXORPJgMrvwSDsEIhy['saveinfo']['thumbnail'])
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.Set_InfoTag(fGnKoFzQxuVWaXORPJgMrvwSDsEILN.getVideoInfoTag(),fGnKoFzQxuVWaXORPJgMrvwSDsEIhy['saveinfo']['infoLabels'])
  if fGnKoFzQxuVWaXORPJgMrvwSDsEIYd=='movie':
   fGnKoFzQxuVWaXORPJgMrvwSDsEILN.setIsFolder(fGnKoFzQxuVWaXORPJgMrvwSDsEImC)
   fGnKoFzQxuVWaXORPJgMrvwSDsEILN.setProperty('IsPlayable','true')
  else:
   fGnKoFzQxuVWaXORPJgMrvwSDsEILN.setIsFolder(fGnKoFzQxuVWaXORPJgMrvwSDsEImN)
   fGnKoFzQxuVWaXORPJgMrvwSDsEILN.setProperty('IsPlayable','false')
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdN=xbmcgui.Dialog()
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdN.info(fGnKoFzQxuVWaXORPJgMrvwSDsEILN)
 def wavve_main(fGnKoFzQxuVWaXORPJgMrvwSDsEIdA):
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.WavveObj.KodiVersion=fGnKoFzQxuVWaXORPJgMrvwSDsEImj(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  fGnKoFzQxuVWaXORPJgMrvwSDsEImh=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.main_params.get('params')
  if fGnKoFzQxuVWaXORPJgMrvwSDsEImh:
   fGnKoFzQxuVWaXORPJgMrvwSDsEImA =base64.standard_b64decode(fGnKoFzQxuVWaXORPJgMrvwSDsEImh).decode('utf-8')
   fGnKoFzQxuVWaXORPJgMrvwSDsEImA =json.loads(fGnKoFzQxuVWaXORPJgMrvwSDsEImA)
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqT =fGnKoFzQxuVWaXORPJgMrvwSDsEImA.get('mode')
   fGnKoFzQxuVWaXORPJgMrvwSDsEImb =fGnKoFzQxuVWaXORPJgMrvwSDsEImA.get('values')
  else:
   fGnKoFzQxuVWaXORPJgMrvwSDsEIqT=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.main_params.get('mode',fGnKoFzQxuVWaXORPJgMrvwSDsEImt)
   fGnKoFzQxuVWaXORPJgMrvwSDsEImb=fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.main_params
  if fGnKoFzQxuVWaXORPJgMrvwSDsEIqT=='LOGOUT':
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.logout()
   return
  fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.login_main()
  if fGnKoFzQxuVWaXORPJgMrvwSDsEIqT is fGnKoFzQxuVWaXORPJgMrvwSDsEImt:
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.dp_Main_List()
  elif fGnKoFzQxuVWaXORPJgMrvwSDsEIqT in['LIVE','VOD','MOVIE','SPORTS']:
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.play_VIDEO(fGnKoFzQxuVWaXORPJgMrvwSDsEImb)
  elif fGnKoFzQxuVWaXORPJgMrvwSDsEIqT=='LIVE_CATAGORY':
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.dp_LiveCatagory_List(fGnKoFzQxuVWaXORPJgMrvwSDsEImb)
  elif fGnKoFzQxuVWaXORPJgMrvwSDsEIqT=='MAIN_CATAGORY':
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.dp_MainCatagory_List(fGnKoFzQxuVWaXORPJgMrvwSDsEImb)
  elif fGnKoFzQxuVWaXORPJgMrvwSDsEIqT=='SUPERSECTION_LIST':
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.dp_SuperSection_List(fGnKoFzQxuVWaXORPJgMrvwSDsEImb)
  elif fGnKoFzQxuVWaXORPJgMrvwSDsEIqT=='BANDLIVESECTION_LIST':
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.dp_BandLiveSection_List(fGnKoFzQxuVWaXORPJgMrvwSDsEImb)
  elif fGnKoFzQxuVWaXORPJgMrvwSDsEIqT=='BAND2SECTION_LIST':
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.dp_Band2Section_List(fGnKoFzQxuVWaXORPJgMrvwSDsEImb)
  elif fGnKoFzQxuVWaXORPJgMrvwSDsEIqT=='PROGRAM_LIST':
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.dp_Program_List(fGnKoFzQxuVWaXORPJgMrvwSDsEImb)
  elif fGnKoFzQxuVWaXORPJgMrvwSDsEIqT=='SEASON_LIST':
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.dp_Season_List(fGnKoFzQxuVWaXORPJgMrvwSDsEImb)
  elif fGnKoFzQxuVWaXORPJgMrvwSDsEIqT=='EPISODE_LIST':
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.dp_Episode_List(fGnKoFzQxuVWaXORPJgMrvwSDsEImb)
  elif fGnKoFzQxuVWaXORPJgMrvwSDsEIqT=='MOVIE_LIST':
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.dp_Movie_List(fGnKoFzQxuVWaXORPJgMrvwSDsEImb)
  elif fGnKoFzQxuVWaXORPJgMrvwSDsEIqT=='LIVE_LIST':
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.dp_LiveChannel_List(fGnKoFzQxuVWaXORPJgMrvwSDsEImb)
  elif fGnKoFzQxuVWaXORPJgMrvwSDsEIqT=='ORDER_BY':
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.dp_setEpOrderby(fGnKoFzQxuVWaXORPJgMrvwSDsEImb)
  elif fGnKoFzQxuVWaXORPJgMrvwSDsEIqT=='SEARCH_GROUP':
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.dp_Search_Group(fGnKoFzQxuVWaXORPJgMrvwSDsEImb)
  elif fGnKoFzQxuVWaXORPJgMrvwSDsEIqT in['SEARCH_LIST','LOCAL_SEARCH']:
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.dp_Search_List(fGnKoFzQxuVWaXORPJgMrvwSDsEImb)
  elif fGnKoFzQxuVWaXORPJgMrvwSDsEIqT=='WATCH_GROUP':
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.dp_Watch_Group(fGnKoFzQxuVWaXORPJgMrvwSDsEImb)
  elif fGnKoFzQxuVWaXORPJgMrvwSDsEIqT=='WATCH_LIST':
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.dp_Watch_List(fGnKoFzQxuVWaXORPJgMrvwSDsEImb)
  elif fGnKoFzQxuVWaXORPJgMrvwSDsEIqT=='SET_BOOKMARK':
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.dp_Set_Bookmark(fGnKoFzQxuVWaXORPJgMrvwSDsEImb)
  elif fGnKoFzQxuVWaXORPJgMrvwSDsEIqT in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.dp_History_Remove(fGnKoFzQxuVWaXORPJgMrvwSDsEImb)
  elif fGnKoFzQxuVWaXORPJgMrvwSDsEIqT in['TOTAL_SEARCH','TOTAL_HISTORY']:
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.dp_Global_Search(fGnKoFzQxuVWaXORPJgMrvwSDsEImb)
  elif fGnKoFzQxuVWaXORPJgMrvwSDsEIqT=='SEARCH_HISTORY':
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.dp_Search_History(fGnKoFzQxuVWaXORPJgMrvwSDsEImb)
  elif fGnKoFzQxuVWaXORPJgMrvwSDsEIqT=='MENU_BOOKMARK':
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.dp_Bookmark_Menu(fGnKoFzQxuVWaXORPJgMrvwSDsEImb)
  elif fGnKoFzQxuVWaXORPJgMrvwSDsEIqT=='GAME_LIST':
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.dp_Sports_GameList(fGnKoFzQxuVWaXORPJgMrvwSDsEImb)
  elif fGnKoFzQxuVWaXORPJgMrvwSDsEIqT=='VIEW_DETAIL':
   fGnKoFzQxuVWaXORPJgMrvwSDsEIdA.dp_View_Detail(fGnKoFzQxuVWaXORPJgMrvwSDsEImb)
  else:
   fGnKoFzQxuVWaXORPJgMrvwSDsEImt
# Created by pyminifier (https://github.com/liftoff/pyminifier)
