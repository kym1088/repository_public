__author__="NightRain"
vFMAyWcljmNwSGLsCTRHEUiIkDBQon=object
vFMAyWcljmNwSGLsCTRHEUiIkDBQoV=None
vFMAyWcljmNwSGLsCTRHEUiIkDBQoO=False
vFMAyWcljmNwSGLsCTRHEUiIkDBQot=open
vFMAyWcljmNwSGLsCTRHEUiIkDBQrz=True
vFMAyWcljmNwSGLsCTRHEUiIkDBQrq=range
vFMAyWcljmNwSGLsCTRHEUiIkDBQrp=str
vFMAyWcljmNwSGLsCTRHEUiIkDBQra=len
vFMAyWcljmNwSGLsCTRHEUiIkDBQre=Exception
vFMAyWcljmNwSGLsCTRHEUiIkDBQrJ=print
vFMAyWcljmNwSGLsCTRHEUiIkDBQro=dict
vFMAyWcljmNwSGLsCTRHEUiIkDBQrh=int
import urllib
import re
import json
import sys
import requests
import datetime
import base64
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
vFMAyWcljmNwSGLsCTRHEUiIkDBQzp =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
class vFMAyWcljmNwSGLsCTRHEUiIkDBQzq(vFMAyWcljmNwSGLsCTRHEUiIkDBQon):
 def __init__(vFMAyWcljmNwSGLsCTRHEUiIkDBQza):
  vFMAyWcljmNwSGLsCTRHEUiIkDBQza.API_DOMAIN='https://apis.wavve.com'
  vFMAyWcljmNwSGLsCTRHEUiIkDBQza.WV ={}
  vFMAyWcljmNwSGLsCTRHEUiIkDBQza.Init_WV_Total()
  vFMAyWcljmNwSGLsCTRHEUiIkDBQza.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  vFMAyWcljmNwSGLsCTRHEUiIkDBQza.DEVICE ='pc'
  vFMAyWcljmNwSGLsCTRHEUiIkDBQza.DRM ='wm'
  vFMAyWcljmNwSGLsCTRHEUiIkDBQza.PARTNER ='pooq'
  vFMAyWcljmNwSGLsCTRHEUiIkDBQza.POOQZONE ='none'
  vFMAyWcljmNwSGLsCTRHEUiIkDBQza.REGION ='kor'
  vFMAyWcljmNwSGLsCTRHEUiIkDBQza.TARGETAGE ='all'
  vFMAyWcljmNwSGLsCTRHEUiIkDBQza.HTTPTAG ='https://'
  vFMAyWcljmNwSGLsCTRHEUiIkDBQza.LIST_LIMIT=30 
  vFMAyWcljmNwSGLsCTRHEUiIkDBQza.EP_LIMIT =30 
  vFMAyWcljmNwSGLsCTRHEUiIkDBQza.MV_LIMIT =24 
  vFMAyWcljmNwSGLsCTRHEUiIkDBQza.SEARCH_LIMIT=20 
  vFMAyWcljmNwSGLsCTRHEUiIkDBQza.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
  vFMAyWcljmNwSGLsCTRHEUiIkDBQza.DEFAULT_HEADER={'user-agent':vFMAyWcljmNwSGLsCTRHEUiIkDBQza.USER_AGENT}
  vFMAyWcljmNwSGLsCTRHEUiIkDBQza.KodiVersion=20
  vFMAyWcljmNwSGLsCTRHEUiIkDBQza.WV_SESSION_COOKIES1=''
  vFMAyWcljmNwSGLsCTRHEUiIkDBQza.WV_SESSION_COOKIES2=''
  vFMAyWcljmNwSGLsCTRHEUiIkDBQza.COOKIE_FILE_NAME =''
  vFMAyWcljmNwSGLsCTRHEUiIkDBQza.WV_STREAM_FILENAME =''
 def Init_WV_Total(vFMAyWcljmNwSGLsCTRHEUiIkDBQza):
  vFMAyWcljmNwSGLsCTRHEUiIkDBQza.WV={'account':{},'cookies':{},}
 def callRequestCookies(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,jobtype,vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,payload=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,params=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,headers=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,cookies=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,redirects=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO):
  vFMAyWcljmNwSGLsCTRHEUiIkDBQze=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.DEFAULT_HEADER
  if headers:vFMAyWcljmNwSGLsCTRHEUiIkDBQze.update(headers)
  if jobtype=='Get':
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzJ=requests.get(vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,params=params,headers=vFMAyWcljmNwSGLsCTRHEUiIkDBQze,cookies=cookies,allow_redirects=redirects)
  else:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzJ=requests.post(vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,json=payload,params=params,headers=vFMAyWcljmNwSGLsCTRHEUiIkDBQze,cookies=cookies,allow_redirects=redirects)
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQzJ
 def JsonFile_Save(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,filename,vFMAyWcljmNwSGLsCTRHEUiIkDBQzo):
  if filename=='':return vFMAyWcljmNwSGLsCTRHEUiIkDBQoO
  try:
   fp=vFMAyWcljmNwSGLsCTRHEUiIkDBQot(filename,'w',-1,'utf-8')
   json.dump(vFMAyWcljmNwSGLsCTRHEUiIkDBQzo,fp,indent=4,ensure_ascii=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO)
   fp.close()
  except:
   return vFMAyWcljmNwSGLsCTRHEUiIkDBQoO
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQrz
 def JsonFile_Load(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,filename):
  if filename=='':return{}
  try:
   fp=vFMAyWcljmNwSGLsCTRHEUiIkDBQot(filename,'r',-1,'utf-8')
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzh=json.load(fp)
   fp.close()
  except:
   return{}
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQzh
 def TextFile_Save(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,filename,resText):
  if filename=='':return vFMAyWcljmNwSGLsCTRHEUiIkDBQoO
  try:
   fp=vFMAyWcljmNwSGLsCTRHEUiIkDBQot(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return vFMAyWcljmNwSGLsCTRHEUiIkDBQoO
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQrz
 def Save_session_acount(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,vFMAyWcljmNwSGLsCTRHEUiIkDBQzd,vFMAyWcljmNwSGLsCTRHEUiIkDBQzb,vFMAyWcljmNwSGLsCTRHEUiIkDBQzK):
  vFMAyWcljmNwSGLsCTRHEUiIkDBQza.WV['account']['wvid']=base64.standard_b64encode(vFMAyWcljmNwSGLsCTRHEUiIkDBQzd.encode()).decode('utf-8')
  vFMAyWcljmNwSGLsCTRHEUiIkDBQza.WV['account']['wvpw']=base64.standard_b64encode(vFMAyWcljmNwSGLsCTRHEUiIkDBQzb.encode()).decode('utf-8')
  vFMAyWcljmNwSGLsCTRHEUiIkDBQza.WV['account']['wvpf']=vFMAyWcljmNwSGLsCTRHEUiIkDBQzK 
 def Load_session_acount(vFMAyWcljmNwSGLsCTRHEUiIkDBQza):
  try:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzd=base64.standard_b64decode(vFMAyWcljmNwSGLsCTRHEUiIkDBQza.WV['account']['wvid']).decode('utf-8')
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzb=base64.standard_b64decode(vFMAyWcljmNwSGLsCTRHEUiIkDBQza.WV['account']['wvpw']).decode('utf-8')
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzK=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.WV['account']['wvpf']
  except:
   return '','',0
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQzd,vFMAyWcljmNwSGLsCTRHEUiIkDBQzb,vFMAyWcljmNwSGLsCTRHEUiIkDBQzK
 def GetDefaultParams(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,login=vFMAyWcljmNwSGLsCTRHEUiIkDBQrz):
  vFMAyWcljmNwSGLsCTRHEUiIkDBQzx={'apikey':vFMAyWcljmNwSGLsCTRHEUiIkDBQza.APIKEY,'credential':vFMAyWcljmNwSGLsCTRHEUiIkDBQza.WV['cookies']['credential']if login else 'none','device':vFMAyWcljmNwSGLsCTRHEUiIkDBQza.DEVICE,'drm':vFMAyWcljmNwSGLsCTRHEUiIkDBQza.DRM,'partner':vFMAyWcljmNwSGLsCTRHEUiIkDBQza.PARTNER,'pooqzone':vFMAyWcljmNwSGLsCTRHEUiIkDBQza.POOQZONE,'region':vFMAyWcljmNwSGLsCTRHEUiIkDBQza.REGION,'targetage':vFMAyWcljmNwSGLsCTRHEUiIkDBQza.TARGETAGE,}
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQzx
 def GetDefaultParams_AND(vFMAyWcljmNwSGLsCTRHEUiIkDBQza):
  vFMAyWcljmNwSGLsCTRHEUiIkDBQzx={'apikey':'6A87455D54481A536DFB8AD397C5EC4D','credential':vFMAyWcljmNwSGLsCTRHEUiIkDBQza.WV['cookies']['credential'],'device':'ott','drm':vFMAyWcljmNwSGLsCTRHEUiIkDBQza.DRM,'partner':vFMAyWcljmNwSGLsCTRHEUiIkDBQza.PARTNER,'pooqzone':vFMAyWcljmNwSGLsCTRHEUiIkDBQza.POOQZONE,'region':vFMAyWcljmNwSGLsCTRHEUiIkDBQza.REGION,'targetage':vFMAyWcljmNwSGLsCTRHEUiIkDBQza.TARGETAGE,}
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQzx
 def GetGUID(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzY=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzP=GenerateRandomString(5)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzu=vFMAyWcljmNwSGLsCTRHEUiIkDBQzP+media+vFMAyWcljmNwSGLsCTRHEUiIkDBQzY
   return vFMAyWcljmNwSGLsCTRHEUiIkDBQzu
  def GenerateRandomString(num):
   from random import randint
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzg=""
   for i in vFMAyWcljmNwSGLsCTRHEUiIkDBQrq(0,num):
    s=vFMAyWcljmNwSGLsCTRHEUiIkDBQrp(randint(1,5))
    vFMAyWcljmNwSGLsCTRHEUiIkDBQzg+=s
   return vFMAyWcljmNwSGLsCTRHEUiIkDBQzg
  if guidType==3:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzu=guid_str
  else:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzu=GenerateID(guid_str)
  vFMAyWcljmNwSGLsCTRHEUiIkDBQzX=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.GetHash(vFMAyWcljmNwSGLsCTRHEUiIkDBQzu)
  if guidType in[2,3]:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzX='%s-%s-%s-%s-%s'%(vFMAyWcljmNwSGLsCTRHEUiIkDBQzX[:8],vFMAyWcljmNwSGLsCTRHEUiIkDBQzX[8:12],vFMAyWcljmNwSGLsCTRHEUiIkDBQzX[12:16],vFMAyWcljmNwSGLsCTRHEUiIkDBQzX[16:20],vFMAyWcljmNwSGLsCTRHEUiIkDBQzX[20:])
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQzX
 def GetHash(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQrp(m.hexdigest())
 def CheckQuality(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,sel_qt,qt_list):
  vFMAyWcljmNwSGLsCTRHEUiIkDBQzf=0
  for vFMAyWcljmNwSGLsCTRHEUiIkDBQzn in qt_list:
   if sel_qt>=vFMAyWcljmNwSGLsCTRHEUiIkDBQzn:return vFMAyWcljmNwSGLsCTRHEUiIkDBQzn
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzf=vFMAyWcljmNwSGLsCTRHEUiIkDBQzn
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQzf
 def Get_Now_Datetime(vFMAyWcljmNwSGLsCTRHEUiIkDBQza):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,in_text):
  vFMAyWcljmNwSGLsCTRHEUiIkDBQzO=in_text.replace('&lt;','<').replace('&gt;','>')
  vFMAyWcljmNwSGLsCTRHEUiIkDBQzO=vFMAyWcljmNwSGLsCTRHEUiIkDBQzO.replace('<br>','\n')
  vFMAyWcljmNwSGLsCTRHEUiIkDBQzO=vFMAyWcljmNwSGLsCTRHEUiIkDBQzO.replace('$O$','')
  vFMAyWcljmNwSGLsCTRHEUiIkDBQzO=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',vFMAyWcljmNwSGLsCTRHEUiIkDBQzO)
  vFMAyWcljmNwSGLsCTRHEUiIkDBQzO=vFMAyWcljmNwSGLsCTRHEUiIkDBQzO.lstrip('#')
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQzO
 def make_str_ToCookie(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,cookieStr):
  vFMAyWcljmNwSGLsCTRHEUiIkDBQzt={}
  for vFMAyWcljmNwSGLsCTRHEUiIkDBQqz in cookieStr.split(';'):
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqp=vFMAyWcljmNwSGLsCTRHEUiIkDBQqz.split('=')
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzt[vFMAyWcljmNwSGLsCTRHEUiIkDBQqp[0]]=vFMAyWcljmNwSGLsCTRHEUiIkDBQqp[1]
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQzt 
 def make_stream_header(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,vFMAyWcljmNwSGLsCTRHEUiIkDBQqr,vFMAyWcljmNwSGLsCTRHEUiIkDBQzt):
  vFMAyWcljmNwSGLsCTRHEUiIkDBQqa=''
  if vFMAyWcljmNwSGLsCTRHEUiIkDBQzt not in[{},vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,'']:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqe=vFMAyWcljmNwSGLsCTRHEUiIkDBQra(vFMAyWcljmNwSGLsCTRHEUiIkDBQzt)
   for vFMAyWcljmNwSGLsCTRHEUiIkDBQqJ,vFMAyWcljmNwSGLsCTRHEUiIkDBQqo in vFMAyWcljmNwSGLsCTRHEUiIkDBQzt.items():
    vFMAyWcljmNwSGLsCTRHEUiIkDBQqa+='{}={}'.format(vFMAyWcljmNwSGLsCTRHEUiIkDBQqJ,vFMAyWcljmNwSGLsCTRHEUiIkDBQqo)
    vFMAyWcljmNwSGLsCTRHEUiIkDBQqe+=-1
    if vFMAyWcljmNwSGLsCTRHEUiIkDBQqe>0:vFMAyWcljmNwSGLsCTRHEUiIkDBQqa+='; '
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqr['cookie']=vFMAyWcljmNwSGLsCTRHEUiIkDBQqa
  vFMAyWcljmNwSGLsCTRHEUiIkDBQqh=''
  i=0
  for vFMAyWcljmNwSGLsCTRHEUiIkDBQqJ,vFMAyWcljmNwSGLsCTRHEUiIkDBQqo in vFMAyWcljmNwSGLsCTRHEUiIkDBQqr.items():
   i=i+1
   if i>1:vFMAyWcljmNwSGLsCTRHEUiIkDBQqh+='&'
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqh+='{}={}'.format(vFMAyWcljmNwSGLsCTRHEUiIkDBQqJ,urllib.parse.quote(vFMAyWcljmNwSGLsCTRHEUiIkDBQqo))
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQqh
 def GetCredential(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,user_id,user_pw,user_pf):
  vFMAyWcljmNwSGLsCTRHEUiIkDBQqd=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO
  try:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqb=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.API_DOMAIN+ '/login'
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.GetDefaultParams(login=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqK={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.callRequestCookies('Post',vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,payload=vFMAyWcljmNwSGLsCTRHEUiIkDBQqK,params=vFMAyWcljmNwSGLsCTRHEUiIkDBQzx,headers=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,cookies=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqY=json.loads(vFMAyWcljmNwSGLsCTRHEUiIkDBQqx.text)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQza.WV['cookies']['credential']=vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['credential']
   if user_pf!=0:
    vFMAyWcljmNwSGLsCTRHEUiIkDBQqK={'id':vFMAyWcljmNwSGLsCTRHEUiIkDBQza.WV['cookies']['credential'],'password':'','profile':vFMAyWcljmNwSGLsCTRHEUiIkDBQrp(user_pf),'pushid':'','type':'credential'}
    vFMAyWcljmNwSGLsCTRHEUiIkDBQzx =vFMAyWcljmNwSGLsCTRHEUiIkDBQza.GetDefaultParams(login=vFMAyWcljmNwSGLsCTRHEUiIkDBQrz) 
    vFMAyWcljmNwSGLsCTRHEUiIkDBQqx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.callRequestCookies('Post',vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,payload=vFMAyWcljmNwSGLsCTRHEUiIkDBQqK,params=vFMAyWcljmNwSGLsCTRHEUiIkDBQzx,headers=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,cookies=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV)
    vFMAyWcljmNwSGLsCTRHEUiIkDBQqY=json.loads(vFMAyWcljmNwSGLsCTRHEUiIkDBQqx.text)
    vFMAyWcljmNwSGLsCTRHEUiIkDBQza.WV['cookies']['credential']=vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['credential']
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqP=user_id+vFMAyWcljmNwSGLsCTRHEUiIkDBQrp(user_pf) 
   vFMAyWcljmNwSGLsCTRHEUiIkDBQza.WV['cookies']['uuid']=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.GetGUID(guid_str=vFMAyWcljmNwSGLsCTRHEUiIkDBQqP,guidType=3)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqd=vFMAyWcljmNwSGLsCTRHEUiIkDBQrz
  except vFMAyWcljmNwSGLsCTRHEUiIkDBQre as exception:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQrJ(exception)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQza.Init_WV_Total()
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQqd
 def GetIssue(vFMAyWcljmNwSGLsCTRHEUiIkDBQza):
  vFMAyWcljmNwSGLsCTRHEUiIkDBQqu=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO
  try:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqb=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.API_DOMAIN+'/guid/issue'
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.GetDefaultParams()
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.callRequestCookies('Get',vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,payload=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,params=vFMAyWcljmNwSGLsCTRHEUiIkDBQzx,headers=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,cookies=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqY=json.loads(vFMAyWcljmNwSGLsCTRHEUiIkDBQqx.text)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqg=vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['guid']
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqX=vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['guidtimestamp']
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQqg:vFMAyWcljmNwSGLsCTRHEUiIkDBQqu=vFMAyWcljmNwSGLsCTRHEUiIkDBQrz
  except vFMAyWcljmNwSGLsCTRHEUiIkDBQre as exception:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQrJ(exception)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqg='none'
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqX='none' 
  vFMAyWcljmNwSGLsCTRHEUiIkDBQza.guid=vFMAyWcljmNwSGLsCTRHEUiIkDBQqg
  vFMAyWcljmNwSGLsCTRHEUiIkDBQza.guidtimestamp=vFMAyWcljmNwSGLsCTRHEUiIkDBQqX
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQqu
 def Baseapi_Parse(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,vFMAyWcljmNwSGLsCTRHEUiIkDBQqO):
  try:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqf =urllib.parse.urlsplit(vFMAyWcljmNwSGLsCTRHEUiIkDBQqO)
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQqf.netloc=='':
    vFMAyWcljmNwSGLsCTRHEUiIkDBQqb=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.HTTPTAG+vFMAyWcljmNwSGLsCTRHEUiIkDBQqf.netloc+vFMAyWcljmNwSGLsCTRHEUiIkDBQqf.path
   else:
    vFMAyWcljmNwSGLsCTRHEUiIkDBQqb=vFMAyWcljmNwSGLsCTRHEUiIkDBQqf.scheme+'://'+vFMAyWcljmNwSGLsCTRHEUiIkDBQqf.netloc+vFMAyWcljmNwSGLsCTRHEUiIkDBQqf.path
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx=vFMAyWcljmNwSGLsCTRHEUiIkDBQro(urllib.parse.parse_qsl(vFMAyWcljmNwSGLsCTRHEUiIkDBQqf.query))
  except vFMAyWcljmNwSGLsCTRHEUiIkDBQre as exception:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQrJ(exception)
   return '',{}
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,vFMAyWcljmNwSGLsCTRHEUiIkDBQzx
 def GetSupermultiUrl(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,sCode,sIndex='0'):
  try:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqb=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.API_DOMAIN+'/cf/supermultisections/'+sCode
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.GetDefaultParams(login=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.callRequestCookies('Get',vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,payload=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,params=vFMAyWcljmNwSGLsCTRHEUiIkDBQzx,headers=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,cookies=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqY=json.loads(vFMAyWcljmNwSGLsCTRHEUiIkDBQqx.text)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqn=vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['multisectionlist'][vFMAyWcljmNwSGLsCTRHEUiIkDBQrh(sIndex)]['eventlist'][1]['url']
  except vFMAyWcljmNwSGLsCTRHEUiIkDBQre as exception:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQrJ(exception)
   return ''
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQqn
 def Get_LiveCatagory_List(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,sCode,sIndex='0'):
  vFMAyWcljmNwSGLsCTRHEUiIkDBQqV=[]
  vFMAyWcljmNwSGLsCTRHEUiIkDBQqO =vFMAyWcljmNwSGLsCTRHEUiIkDBQza.GetSupermultiUrl(sCode,sIndex)
  (vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,vFMAyWcljmNwSGLsCTRHEUiIkDBQzx)=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.Baseapi_Parse(vFMAyWcljmNwSGLsCTRHEUiIkDBQqO)
  if vFMAyWcljmNwSGLsCTRHEUiIkDBQqb=='':return vFMAyWcljmNwSGLsCTRHEUiIkDBQqV,''
  try:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx.update(vFMAyWcljmNwSGLsCTRHEUiIkDBQza.GetDefaultParams(login=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO))
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.callRequestCookies('Get',vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,payload=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,params=vFMAyWcljmNwSGLsCTRHEUiIkDBQzx,headers=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,cookies=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqY=json.loads(vFMAyWcljmNwSGLsCTRHEUiIkDBQqx.text)
   if not('filter_item_list' in vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['filter']['filterlist'][0]):return[],''
   vFMAyWcljmNwSGLsCTRHEUiIkDBQpz=vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['filter']['filterlist'][0]['filter_item_list']
   for vFMAyWcljmNwSGLsCTRHEUiIkDBQpq in vFMAyWcljmNwSGLsCTRHEUiIkDBQpz:
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpa={'title':vFMAyWcljmNwSGLsCTRHEUiIkDBQpq['title'],'genre':vFMAyWcljmNwSGLsCTRHEUiIkDBQpq['api_parameters'][vFMAyWcljmNwSGLsCTRHEUiIkDBQpq['api_parameters'].index('=')+1:]}
    vFMAyWcljmNwSGLsCTRHEUiIkDBQqV.append(vFMAyWcljmNwSGLsCTRHEUiIkDBQpa)
  except vFMAyWcljmNwSGLsCTRHEUiIkDBQre as exception:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQrJ(exception)
   return[],''
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQqV,vFMAyWcljmNwSGLsCTRHEUiIkDBQqO
 def Get_MainCatagory_List(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,sCode,sIndex,sType):
  vFMAyWcljmNwSGLsCTRHEUiIkDBQqV=[]
  vFMAyWcljmNwSGLsCTRHEUiIkDBQqb='https://apis.wavve.com/es/category/launcher-band'
  vFMAyWcljmNwSGLsCTRHEUiIkDBQzx={'uitype':sCode,'uiparent':'GN52-'+sCode,'uirank':sIndex,'broadcastid':sCode,'offset':'0','limit':'20','uicode':sCode,'mtype':'N','ctype':sType,'orderby':'default',}
  try:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx.update(vFMAyWcljmNwSGLsCTRHEUiIkDBQza.GetDefaultParams(login=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO))
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.callRequestCookies('Get',vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,payload=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,params=vFMAyWcljmNwSGLsCTRHEUiIkDBQzx,headers=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,cookies=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqY=json.loads(vFMAyWcljmNwSGLsCTRHEUiIkDBQqx.text)
   if not('celllist' in vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['band']):return[]
   vFMAyWcljmNwSGLsCTRHEUiIkDBQpz=vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['band']['celllist']
   for vFMAyWcljmNwSGLsCTRHEUiIkDBQpq in vFMAyWcljmNwSGLsCTRHEUiIkDBQpz:
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpe =vFMAyWcljmNwSGLsCTRHEUiIkDBQpq['event_list'][1]['url']
    (vFMAyWcljmNwSGLsCTRHEUiIkDBQpJ,vFMAyWcljmNwSGLsCTRHEUiIkDBQpo)=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.Baseapi_Parse(vFMAyWcljmNwSGLsCTRHEUiIkDBQpe)
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpa={'title':vFMAyWcljmNwSGLsCTRHEUiIkDBQpq['title_list'][0]['text'],'suburl':vFMAyWcljmNwSGLsCTRHEUiIkDBQpJ,'subapi':vFMAyWcljmNwSGLsCTRHEUiIkDBQpo.get('api'),'subtype':'catagory' if vFMAyWcljmNwSGLsCTRHEUiIkDBQpo else 'supersection'}
    vFMAyWcljmNwSGLsCTRHEUiIkDBQqV.append(vFMAyWcljmNwSGLsCTRHEUiIkDBQpa)
  except vFMAyWcljmNwSGLsCTRHEUiIkDBQre as exception:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQrJ(exception)
   return[]
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQqV
 def Get_SuperMultiSection_List(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,subapi_text):
  vFMAyWcljmNwSGLsCTRHEUiIkDBQqV=[]
  if '/multiband/' in subapi_text: 
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqb=subapi_text 
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx={'client':'40'}
  else:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqb=subapi_text 
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqb=vFMAyWcljmNwSGLsCTRHEUiIkDBQqb.replace('www.wavve.com','apis.wavve.com').replace('supermultisection','v1/multiband')
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx={}
  try:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx.update(vFMAyWcljmNwSGLsCTRHEUiIkDBQza.GetDefaultParams(login=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO))
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.callRequestCookies('Get',vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,payload=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,params=vFMAyWcljmNwSGLsCTRHEUiIkDBQzx,headers=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,cookies=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqY=json.loads(vFMAyWcljmNwSGLsCTRHEUiIkDBQqx.text)
   if not('multisectionlist' in vFMAyWcljmNwSGLsCTRHEUiIkDBQqY):return[]
   vFMAyWcljmNwSGLsCTRHEUiIkDBQpz=vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['multisectionlist']
   for vFMAyWcljmNwSGLsCTRHEUiIkDBQpq in vFMAyWcljmNwSGLsCTRHEUiIkDBQpz:
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpr=vFMAyWcljmNwSGLsCTRHEUiIkDBQpq['title']
    if vFMAyWcljmNwSGLsCTRHEUiIkDBQra(vFMAyWcljmNwSGLsCTRHEUiIkDBQpr)==0:continue
    if vFMAyWcljmNwSGLsCTRHEUiIkDBQpr=='minor':continue
    if re.search(u'베너',vFMAyWcljmNwSGLsCTRHEUiIkDBQpr):continue
    if re.search(u'배너',vFMAyWcljmNwSGLsCTRHEUiIkDBQpr):continue 
    if vFMAyWcljmNwSGLsCTRHEUiIkDBQpq['force_refresh']=='y':continue
    if vFMAyWcljmNwSGLsCTRHEUiIkDBQra(vFMAyWcljmNwSGLsCTRHEUiIkDBQpq['eventlist'])>=3:
     vFMAyWcljmNwSGLsCTRHEUiIkDBQpo =vFMAyWcljmNwSGLsCTRHEUiIkDBQpq['eventlist'][2]['url']
    else:
     vFMAyWcljmNwSGLsCTRHEUiIkDBQpo =vFMAyWcljmNwSGLsCTRHEUiIkDBQpq['eventlist'][1]['url']
    vFMAyWcljmNwSGLsCTRHEUiIkDBQph=vFMAyWcljmNwSGLsCTRHEUiIkDBQpq['cell_type']
    if vFMAyWcljmNwSGLsCTRHEUiIkDBQph=='band_2':
     if vFMAyWcljmNwSGLsCTRHEUiIkDBQpo.find('channellist=')>=0:
      vFMAyWcljmNwSGLsCTRHEUiIkDBQph='band_live'
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpa={'title':vFMAyWcljmNwSGLsCTRHEUiIkDBQza.Get_ChangeText(vFMAyWcljmNwSGLsCTRHEUiIkDBQpr),'subapi':vFMAyWcljmNwSGLsCTRHEUiIkDBQpo,'cell_type':vFMAyWcljmNwSGLsCTRHEUiIkDBQph}
    vFMAyWcljmNwSGLsCTRHEUiIkDBQqV.append(vFMAyWcljmNwSGLsCTRHEUiIkDBQpa)
  except vFMAyWcljmNwSGLsCTRHEUiIkDBQre as exception:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQrJ(exception)
   return[]
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQqV
 def Get_BandLiveSection_List(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,vFMAyWcljmNwSGLsCTRHEUiIkDBQqO,page_int=1):
  vFMAyWcljmNwSGLsCTRHEUiIkDBQpd=[]
  vFMAyWcljmNwSGLsCTRHEUiIkDBQpb=vFMAyWcljmNwSGLsCTRHEUiIkDBQpg=1
  vFMAyWcljmNwSGLsCTRHEUiIkDBQpK=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO
  try:
   (vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,vFMAyWcljmNwSGLsCTRHEUiIkDBQzx)=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.Baseapi_Parse(vFMAyWcljmNwSGLsCTRHEUiIkDBQqO)
  except vFMAyWcljmNwSGLsCTRHEUiIkDBQre as exception:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQrJ(exception)
   return[],vFMAyWcljmNwSGLsCTRHEUiIkDBQoO
  try:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx['limit']=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.LIST_LIMIT
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx['offset']=vFMAyWcljmNwSGLsCTRHEUiIkDBQrp((page_int-1)*vFMAyWcljmNwSGLsCTRHEUiIkDBQza.LIST_LIMIT)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx.update(vFMAyWcljmNwSGLsCTRHEUiIkDBQza.GetDefaultParams(login=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO))
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.callRequestCookies('Get',vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,payload=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,params=vFMAyWcljmNwSGLsCTRHEUiIkDBQzx,headers=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,cookies=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqY=json.loads(vFMAyWcljmNwSGLsCTRHEUiIkDBQqx.text)
   if not('celllist' in vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['cell_toplist']):return[],vFMAyWcljmNwSGLsCTRHEUiIkDBQoO
   vFMAyWcljmNwSGLsCTRHEUiIkDBQpz=vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['cell_toplist']['celllist']
   for vFMAyWcljmNwSGLsCTRHEUiIkDBQpq in vFMAyWcljmNwSGLsCTRHEUiIkDBQpz:
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpx =vFMAyWcljmNwSGLsCTRHEUiIkDBQpq['event_list'][1]['url']
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpY=urllib.parse.urlsplit(vFMAyWcljmNwSGLsCTRHEUiIkDBQpx).query
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpY=vFMAyWcljmNwSGLsCTRHEUiIkDBQro(urllib.parse.parse_qsl(vFMAyWcljmNwSGLsCTRHEUiIkDBQpY))
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpP='channelid'
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpu=vFMAyWcljmNwSGLsCTRHEUiIkDBQpY[vFMAyWcljmNwSGLsCTRHEUiIkDBQpP]
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpa={'studio':vFMAyWcljmNwSGLsCTRHEUiIkDBQpq['title_list'][0]['text'],'tvshowtitle':vFMAyWcljmNwSGLsCTRHEUiIkDBQza.Get_ChangeText(vFMAyWcljmNwSGLsCTRHEUiIkDBQpq['title_list'][1]['text']),'channelid':vFMAyWcljmNwSGLsCTRHEUiIkDBQpu,'age':vFMAyWcljmNwSGLsCTRHEUiIkDBQpq.get('age'),'thumbnail':'https://%s'%vFMAyWcljmNwSGLsCTRHEUiIkDBQpq.get('thumbnail')}
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpd.append(vFMAyWcljmNwSGLsCTRHEUiIkDBQpa)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQpb=vFMAyWcljmNwSGLsCTRHEUiIkDBQrh(vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['cell_toplist']['pagecount'])
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['cell_toplist']['count']:vFMAyWcljmNwSGLsCTRHEUiIkDBQpg =vFMAyWcljmNwSGLsCTRHEUiIkDBQrh(vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['cell_toplist']['count'])
   else:vFMAyWcljmNwSGLsCTRHEUiIkDBQpg=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.LIST_LIMIT*page_int
   vFMAyWcljmNwSGLsCTRHEUiIkDBQpK=vFMAyWcljmNwSGLsCTRHEUiIkDBQpb>vFMAyWcljmNwSGLsCTRHEUiIkDBQpg
  except vFMAyWcljmNwSGLsCTRHEUiIkDBQre as exception:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQrJ(exception)
   return[],vFMAyWcljmNwSGLsCTRHEUiIkDBQoO
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQpd,vFMAyWcljmNwSGLsCTRHEUiIkDBQpK
 def Get_Band2Section_List(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,vFMAyWcljmNwSGLsCTRHEUiIkDBQqO,page_int=1):
  vFMAyWcljmNwSGLsCTRHEUiIkDBQpX=[]
  vFMAyWcljmNwSGLsCTRHEUiIkDBQpb=vFMAyWcljmNwSGLsCTRHEUiIkDBQpg=1
  vFMAyWcljmNwSGLsCTRHEUiIkDBQpK=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO
  try:
   (vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,vFMAyWcljmNwSGLsCTRHEUiIkDBQzx)=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.Baseapi_Parse(vFMAyWcljmNwSGLsCTRHEUiIkDBQqO)
  except vFMAyWcljmNwSGLsCTRHEUiIkDBQre as exception:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQrJ(exception)
   return[],vFMAyWcljmNwSGLsCTRHEUiIkDBQoO
  try:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx['came'] ='BandView'
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx['limit']=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.LIST_LIMIT
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx['offset']=vFMAyWcljmNwSGLsCTRHEUiIkDBQrp((page_int-1)*vFMAyWcljmNwSGLsCTRHEUiIkDBQza.LIST_LIMIT)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx.update(vFMAyWcljmNwSGLsCTRHEUiIkDBQza.GetDefaultParams(login=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO))
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.callRequestCookies('Get',vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,payload=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,params=vFMAyWcljmNwSGLsCTRHEUiIkDBQzx,headers=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,cookies=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqY=json.loads(vFMAyWcljmNwSGLsCTRHEUiIkDBQqx.text)
   if not('celllist' in vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['cell_toplist']):return[],vFMAyWcljmNwSGLsCTRHEUiIkDBQoO
   vFMAyWcljmNwSGLsCTRHEUiIkDBQpz=vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['cell_toplist']['celllist']
   for vFMAyWcljmNwSGLsCTRHEUiIkDBQpq in vFMAyWcljmNwSGLsCTRHEUiIkDBQpz:
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpx =vFMAyWcljmNwSGLsCTRHEUiIkDBQpq['event_list'][1]['url']
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpY=urllib.parse.urlsplit(vFMAyWcljmNwSGLsCTRHEUiIkDBQpx).query
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpY=vFMAyWcljmNwSGLsCTRHEUiIkDBQro(urllib.parse.parse_qsl(vFMAyWcljmNwSGLsCTRHEUiIkDBQpY))
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpP='contentid'
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpu=vFMAyWcljmNwSGLsCTRHEUiIkDBQpY[vFMAyWcljmNwSGLsCTRHEUiIkDBQpP]
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpa={'programtitle':vFMAyWcljmNwSGLsCTRHEUiIkDBQpq['title_list'][0]['text'],'episodetitle':vFMAyWcljmNwSGLsCTRHEUiIkDBQza.Get_ChangeText(vFMAyWcljmNwSGLsCTRHEUiIkDBQpq['title_list'][1]['text']),'age':vFMAyWcljmNwSGLsCTRHEUiIkDBQpq.get('age'),'thumbnail':vFMAyWcljmNwSGLsCTRHEUiIkDBQza.HTTPTAG+vFMAyWcljmNwSGLsCTRHEUiIkDBQpq.get('thumbnail'),'vidtype':vFMAyWcljmNwSGLsCTRHEUiIkDBQpP,'videoid':vFMAyWcljmNwSGLsCTRHEUiIkDBQpu}
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpX.append(vFMAyWcljmNwSGLsCTRHEUiIkDBQpa)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQpb=vFMAyWcljmNwSGLsCTRHEUiIkDBQrh(vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['cell_toplist']['pagecount'])
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['cell_toplist']['count']:vFMAyWcljmNwSGLsCTRHEUiIkDBQpg =vFMAyWcljmNwSGLsCTRHEUiIkDBQrh(vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['cell_toplist']['count'])
   else:vFMAyWcljmNwSGLsCTRHEUiIkDBQpg=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.LIST_LIMIT*page_int
   vFMAyWcljmNwSGLsCTRHEUiIkDBQpK=vFMAyWcljmNwSGLsCTRHEUiIkDBQpb>vFMAyWcljmNwSGLsCTRHEUiIkDBQpg
  except vFMAyWcljmNwSGLsCTRHEUiIkDBQre as exception:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQrJ(exception)
   return[],vFMAyWcljmNwSGLsCTRHEUiIkDBQoO
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQpX,vFMAyWcljmNwSGLsCTRHEUiIkDBQpK
 def Get_Program_List(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,vFMAyWcljmNwSGLsCTRHEUiIkDBQqO,page_int=1,orderby='-'):
  vFMAyWcljmNwSGLsCTRHEUiIkDBQpf=[]
  vFMAyWcljmNwSGLsCTRHEUiIkDBQpb=vFMAyWcljmNwSGLsCTRHEUiIkDBQpg=1
  vFMAyWcljmNwSGLsCTRHEUiIkDBQpK=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO
  (vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,vFMAyWcljmNwSGLsCTRHEUiIkDBQzx)=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.Baseapi_Parse(vFMAyWcljmNwSGLsCTRHEUiIkDBQqO)
  if vFMAyWcljmNwSGLsCTRHEUiIkDBQqb=='':return vFMAyWcljmNwSGLsCTRHEUiIkDBQpf,vFMAyWcljmNwSGLsCTRHEUiIkDBQpK
  try:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx['limit'] =vFMAyWcljmNwSGLsCTRHEUiIkDBQza.LIST_LIMIT
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx['offset']=vFMAyWcljmNwSGLsCTRHEUiIkDBQrp((page_int-1)*vFMAyWcljmNwSGLsCTRHEUiIkDBQza.LIST_LIMIT)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx['page'] =vFMAyWcljmNwSGLsCTRHEUiIkDBQrp(page_int)
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQzx.get('orderby')!='' and vFMAyWcljmNwSGLsCTRHEUiIkDBQzx.get('orderby')!='regdatefirst' and orderby!='-':
    vFMAyWcljmNwSGLsCTRHEUiIkDBQzx['orderby']=orderby 
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx.update(vFMAyWcljmNwSGLsCTRHEUiIkDBQza.GetDefaultParams(login=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO))
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.callRequestCookies('Get',vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,payload=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,params=vFMAyWcljmNwSGLsCTRHEUiIkDBQzx,headers=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,cookies=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqY=json.loads(vFMAyWcljmNwSGLsCTRHEUiIkDBQqx.text)
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQqY.get('cell_toplist')not in[{},vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,'']:
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpz=vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['cell_toplist']['celllist']
   elif vFMAyWcljmNwSGLsCTRHEUiIkDBQqY.get('band')not in[{},vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,'']:
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpz=vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['band']['celllist']
   else:
    return vFMAyWcljmNwSGLsCTRHEUiIkDBQpf,vFMAyWcljmNwSGLsCTRHEUiIkDBQpK
   for vFMAyWcljmNwSGLsCTRHEUiIkDBQpq in vFMAyWcljmNwSGLsCTRHEUiIkDBQpz:
    for vFMAyWcljmNwSGLsCTRHEUiIkDBQpn in vFMAyWcljmNwSGLsCTRHEUiIkDBQpq['event_list']:
     if vFMAyWcljmNwSGLsCTRHEUiIkDBQpn.get('type')=='on-navigation':
      vFMAyWcljmNwSGLsCTRHEUiIkDBQpx =vFMAyWcljmNwSGLsCTRHEUiIkDBQpn['url']
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpY=urllib.parse.urlsplit(vFMAyWcljmNwSGLsCTRHEUiIkDBQpx).query
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpP=vFMAyWcljmNwSGLsCTRHEUiIkDBQpY[0:vFMAyWcljmNwSGLsCTRHEUiIkDBQpY.find('=')]
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpV=vFMAyWcljmNwSGLsCTRHEUiIkDBQro(urllib.parse.parse_qsl(vFMAyWcljmNwSGLsCTRHEUiIkDBQpY))
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpu=vFMAyWcljmNwSGLsCTRHEUiIkDBQpV.get(vFMAyWcljmNwSGLsCTRHEUiIkDBQpP)
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpa={'title':vFMAyWcljmNwSGLsCTRHEUiIkDBQpq.get('alt')or vFMAyWcljmNwSGLsCTRHEUiIkDBQpq.get('title_list')[0].get('text'),'age':vFMAyWcljmNwSGLsCTRHEUiIkDBQpq.get('age'),'thumbnail':vFMAyWcljmNwSGLsCTRHEUiIkDBQpq.get('thumbnail'),'videoid':vFMAyWcljmNwSGLsCTRHEUiIkDBQpu,'vidtype':vFMAyWcljmNwSGLsCTRHEUiIkDBQpP,}
    if not vFMAyWcljmNwSGLsCTRHEUiIkDBQpa.get('thumbnail').startswith('http'):
     vFMAyWcljmNwSGLsCTRHEUiIkDBQpa['thumbnail']='https://%s'%vFMAyWcljmNwSGLsCTRHEUiIkDBQpa['thumbnail']
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpf.append(vFMAyWcljmNwSGLsCTRHEUiIkDBQpa)
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQqY.get('cell_toplist')not in[{},vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,'']:
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpb=vFMAyWcljmNwSGLsCTRHEUiIkDBQrh(vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['cell_toplist']['pagecount'])
    if vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['cell_toplist']['count']:vFMAyWcljmNwSGLsCTRHEUiIkDBQpg =vFMAyWcljmNwSGLsCTRHEUiIkDBQrh(vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['cell_toplist']['count'])
    else:vFMAyWcljmNwSGLsCTRHEUiIkDBQpg=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.LIST_LIMIT*page_int
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpK=vFMAyWcljmNwSGLsCTRHEUiIkDBQpb>vFMAyWcljmNwSGLsCTRHEUiIkDBQpg
  except vFMAyWcljmNwSGLsCTRHEUiIkDBQre as exception:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQrJ(exception)
   return[],vFMAyWcljmNwSGLsCTRHEUiIkDBQoO
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQpf,vFMAyWcljmNwSGLsCTRHEUiIkDBQpK
 def Get_Movie_List(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,vFMAyWcljmNwSGLsCTRHEUiIkDBQqO,page_int=1,orderby='-'):
  vFMAyWcljmNwSGLsCTRHEUiIkDBQpO=[]
  vFMAyWcljmNwSGLsCTRHEUiIkDBQpb=vFMAyWcljmNwSGLsCTRHEUiIkDBQpg=1
  vFMAyWcljmNwSGLsCTRHEUiIkDBQpK=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO
  (vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,vFMAyWcljmNwSGLsCTRHEUiIkDBQzx)=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.Baseapi_Parse(vFMAyWcljmNwSGLsCTRHEUiIkDBQqO)
  if vFMAyWcljmNwSGLsCTRHEUiIkDBQqb=='':return vFMAyWcljmNwSGLsCTRHEUiIkDBQpO,vFMAyWcljmNwSGLsCTRHEUiIkDBQpK
  try:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx['limit']=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.MV_LIMIT
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx['offset']=vFMAyWcljmNwSGLsCTRHEUiIkDBQrp((page_int-1)*vFMAyWcljmNwSGLsCTRHEUiIkDBQza.MV_LIMIT)
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQzx.get('orderby')!='' and vFMAyWcljmNwSGLsCTRHEUiIkDBQzx.get('orderby')!='regdatefirst' and orderby!='-':
    vFMAyWcljmNwSGLsCTRHEUiIkDBQzx['orderby']=orderby 
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx.update(vFMAyWcljmNwSGLsCTRHEUiIkDBQza.GetDefaultParams(login=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO))
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.callRequestCookies('Get',vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,payload=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,params=vFMAyWcljmNwSGLsCTRHEUiIkDBQzx,headers=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,cookies=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqY=json.loads(vFMAyWcljmNwSGLsCTRHEUiIkDBQqx.text)
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQqY.get('cell_toplist')not in[{},vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,'']:
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpz=vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['cell_toplist']['celllist']
   elif vFMAyWcljmNwSGLsCTRHEUiIkDBQqY.get('band')not in[{},vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,'']:
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpz=vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['band']['celllist']
   else:
    return vFMAyWcljmNwSGLsCTRHEUiIkDBQpO,vFMAyWcljmNwSGLsCTRHEUiIkDBQpK
   for vFMAyWcljmNwSGLsCTRHEUiIkDBQpq in vFMAyWcljmNwSGLsCTRHEUiIkDBQpz:
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpx =vFMAyWcljmNwSGLsCTRHEUiIkDBQpq['event_list'][1]['url']
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpY=urllib.parse.urlsplit(vFMAyWcljmNwSGLsCTRHEUiIkDBQpx).query
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpP=vFMAyWcljmNwSGLsCTRHEUiIkDBQpY[0:vFMAyWcljmNwSGLsCTRHEUiIkDBQpY.find('=')]
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpV=vFMAyWcljmNwSGLsCTRHEUiIkDBQro(urllib.parse.parse_qsl(vFMAyWcljmNwSGLsCTRHEUiIkDBQpY))
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpu=vFMAyWcljmNwSGLsCTRHEUiIkDBQpV.get(vFMAyWcljmNwSGLsCTRHEUiIkDBQpP)
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpa={'title':vFMAyWcljmNwSGLsCTRHEUiIkDBQpq.get('alt')or vFMAyWcljmNwSGLsCTRHEUiIkDBQpq.get('title_list')[0].get('text'),'age':vFMAyWcljmNwSGLsCTRHEUiIkDBQpq.get('age'),'thumbnail':vFMAyWcljmNwSGLsCTRHEUiIkDBQpq.get('thumbnail'),'videoid':vFMAyWcljmNwSGLsCTRHEUiIkDBQpu,'vidtype':vFMAyWcljmNwSGLsCTRHEUiIkDBQpP,}
    if not vFMAyWcljmNwSGLsCTRHEUiIkDBQpa.get('thumbnail').startswith('http'):
     vFMAyWcljmNwSGLsCTRHEUiIkDBQpa['thumbnail']='https://%s'%vFMAyWcljmNwSGLsCTRHEUiIkDBQpa['thumbnail']
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpO.append(vFMAyWcljmNwSGLsCTRHEUiIkDBQpa)
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQqY.get('cell_toplist')not in[{},vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,'']:
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpb=vFMAyWcljmNwSGLsCTRHEUiIkDBQrh(vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['cell_toplist']['pagecount'])
    if vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['cell_toplist']['count']:vFMAyWcljmNwSGLsCTRHEUiIkDBQpg =vFMAyWcljmNwSGLsCTRHEUiIkDBQrh(vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['cell_toplist']['count'])
    else:vFMAyWcljmNwSGLsCTRHEUiIkDBQpg=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.MV_LIMIT*page_int
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpK=vFMAyWcljmNwSGLsCTRHEUiIkDBQpb>vFMAyWcljmNwSGLsCTRHEUiIkDBQpg
  except vFMAyWcljmNwSGLsCTRHEUiIkDBQre as exception:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQrJ(exception)
   return[],vFMAyWcljmNwSGLsCTRHEUiIkDBQoO
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQpO,vFMAyWcljmNwSGLsCTRHEUiIkDBQpK
 def ProgramidToContentid(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,vFMAyWcljmNwSGLsCTRHEUiIkDBQaq):
  vFMAyWcljmNwSGLsCTRHEUiIkDBQpt=''
  try:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqb =vFMAyWcljmNwSGLsCTRHEUiIkDBQza.API_DOMAIN+'/vod/programs-contentid/'+vFMAyWcljmNwSGLsCTRHEUiIkDBQaq
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.GetDefaultParams(login=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.callRequestCookies('Get',vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,payload=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,params=vFMAyWcljmNwSGLsCTRHEUiIkDBQzx,headers=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,cookies=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQaz=json.loads(vFMAyWcljmNwSGLsCTRHEUiIkDBQqx.text)
   if not('contentid' in vFMAyWcljmNwSGLsCTRHEUiIkDBQaz):return vFMAyWcljmNwSGLsCTRHEUiIkDBQpt 
   vFMAyWcljmNwSGLsCTRHEUiIkDBQpt=vFMAyWcljmNwSGLsCTRHEUiIkDBQaz['contentid']
  except vFMAyWcljmNwSGLsCTRHEUiIkDBQre as exception:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQrJ(exception)
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQpt
 def ContentidToSeasonid(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,vFMAyWcljmNwSGLsCTRHEUiIkDBQpt):
  vFMAyWcljmNwSGLsCTRHEUiIkDBQaq=''
  try:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqb =vFMAyWcljmNwSGLsCTRHEUiIkDBQza.API_DOMAIN+'/fz/vod/contents/'+vFMAyWcljmNwSGLsCTRHEUiIkDBQpt
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.GetDefaultParams(login=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.callRequestCookies('Get',vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,payload=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,params=vFMAyWcljmNwSGLsCTRHEUiIkDBQzx,headers=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,cookies=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQaz=json.loads(vFMAyWcljmNwSGLsCTRHEUiIkDBQqx.text)
   if not('programid' in vFMAyWcljmNwSGLsCTRHEUiIkDBQaz):return vFMAyWcljmNwSGLsCTRHEUiIkDBQaq 
   vFMAyWcljmNwSGLsCTRHEUiIkDBQaq=vFMAyWcljmNwSGLsCTRHEUiIkDBQaz['programid']
  except vFMAyWcljmNwSGLsCTRHEUiIkDBQre as exception:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQrJ(exception)
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQaq
 def GetProgramInfo(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,vFMAyWcljmNwSGLsCTRHEUiIkDBQpt):
  vFMAyWcljmNwSGLsCTRHEUiIkDBQap={}
  try:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqb=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.API_DOMAIN+'/fz/vod/contents/'+vFMAyWcljmNwSGLsCTRHEUiIkDBQpt
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.GetDefaultParams(login=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.callRequestCookies('Get',vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,payload=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,params=vFMAyWcljmNwSGLsCTRHEUiIkDBQzx,headers=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,cookies=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQaz=json.loads(vFMAyWcljmNwSGLsCTRHEUiIkDBQqx.text)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQae=img_fanart=vFMAyWcljmNwSGLsCTRHEUiIkDBQaJ=''
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQaz.get('programposterimage')!='':vFMAyWcljmNwSGLsCTRHEUiIkDBQae =vFMAyWcljmNwSGLsCTRHEUiIkDBQza.HTTPTAG+vFMAyWcljmNwSGLsCTRHEUiIkDBQaz.get('programposterimage')
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQaz.get('programimage') !='':img_fanart =vFMAyWcljmNwSGLsCTRHEUiIkDBQza.HTTPTAG+vFMAyWcljmNwSGLsCTRHEUiIkDBQaz.get('programimage')
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQaz.get('programcircleimage')!='':vFMAyWcljmNwSGLsCTRHEUiIkDBQaJ=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.HTTPTAG+vFMAyWcljmNwSGLsCTRHEUiIkDBQaz.get('programcircleimage')
   if 'poster_default' in vFMAyWcljmNwSGLsCTRHEUiIkDBQae:
    vFMAyWcljmNwSGLsCTRHEUiIkDBQae =img_fanart
    vFMAyWcljmNwSGLsCTRHEUiIkDBQaJ=''
   vFMAyWcljmNwSGLsCTRHEUiIkDBQap={'imgPoster':vFMAyWcljmNwSGLsCTRHEUiIkDBQae,'imgFanart':img_fanart,'imgClearlogo':vFMAyWcljmNwSGLsCTRHEUiIkDBQaJ,'programtitle':vFMAyWcljmNwSGLsCTRHEUiIkDBQaz.get('programtitle'),'programid':vFMAyWcljmNwSGLsCTRHEUiIkDBQaz.get('programid'),'synopsis':vFMAyWcljmNwSGLsCTRHEUiIkDBQza.Get_ChangeText(vFMAyWcljmNwSGLsCTRHEUiIkDBQaz.get('programsynopsis')),}
  except vFMAyWcljmNwSGLsCTRHEUiIkDBQre as exception:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQrJ(exception)
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQap
 def Get_Season_List(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,seasonid):
  vFMAyWcljmNwSGLsCTRHEUiIkDBQao=[]
  vFMAyWcljmNwSGLsCTRHEUiIkDBQpt=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.ProgramidToContentid(seasonid)
  vFMAyWcljmNwSGLsCTRHEUiIkDBQar=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.GetProgramInfo(vFMAyWcljmNwSGLsCTRHEUiIkDBQpt)
  vFMAyWcljmNwSGLsCTRHEUiIkDBQah={'poster':vFMAyWcljmNwSGLsCTRHEUiIkDBQar.get('imgPoster'),'fanart':vFMAyWcljmNwSGLsCTRHEUiIkDBQar.get('imgFanart'),'clearlogo':vFMAyWcljmNwSGLsCTRHEUiIkDBQar.get('imgClearlogo'),}
  try:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqb=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.API_DOMAIN+'/fz/vod/programs-contents/'+seasonid
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx={'limit':'10','offset':'0','orderby':'new',}
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx.update(vFMAyWcljmNwSGLsCTRHEUiIkDBQza.GetDefaultParams(login=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO))
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.callRequestCookies('Get',vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,payload=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,params=vFMAyWcljmNwSGLsCTRHEUiIkDBQzx,headers=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,cookies=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqY=json.loads(vFMAyWcljmNwSGLsCTRHEUiIkDBQqx.text)
   for vFMAyWcljmNwSGLsCTRHEUiIkDBQad in vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['filter']['filterlist'][0]['filter_item_list']:
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpa={'season_Nm':vFMAyWcljmNwSGLsCTRHEUiIkDBQad.get('title'),'season_Id':vFMAyWcljmNwSGLsCTRHEUiIkDBQad.get('api_path'),'thumbnail':vFMAyWcljmNwSGLsCTRHEUiIkDBQah,'programNm':vFMAyWcljmNwSGLsCTRHEUiIkDBQar.get('programtitle'),'synopsis':vFMAyWcljmNwSGLsCTRHEUiIkDBQza.Get_ChangeText(vFMAyWcljmNwSGLsCTRHEUiIkDBQar.get('synopsis')),}
    vFMAyWcljmNwSGLsCTRHEUiIkDBQao.append(vFMAyWcljmNwSGLsCTRHEUiIkDBQpa)
  except vFMAyWcljmNwSGLsCTRHEUiIkDBQre as exception:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQrJ(exception)
   return[]
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQao
 def Get_Episode_List(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,seasionid,page_int=1,orderby='desc'):
  vFMAyWcljmNwSGLsCTRHEUiIkDBQab=[]
  vFMAyWcljmNwSGLsCTRHEUiIkDBQpb=vFMAyWcljmNwSGLsCTRHEUiIkDBQpg=1
  vFMAyWcljmNwSGLsCTRHEUiIkDBQpK=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO
  vFMAyWcljmNwSGLsCTRHEUiIkDBQar={}
  vFMAyWcljmNwSGLsCTRHEUiIkDBQpt=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.ProgramidToContentid(seasionid)
  vFMAyWcljmNwSGLsCTRHEUiIkDBQar=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.GetProgramInfo(vFMAyWcljmNwSGLsCTRHEUiIkDBQpt)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqb=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.API_DOMAIN+'/fz/vod/programs-contents/'+seasionid
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx={'limit':vFMAyWcljmNwSGLsCTRHEUiIkDBQza.EP_LIMIT,'offset':vFMAyWcljmNwSGLsCTRHEUiIkDBQrp((page_int-1)*vFMAyWcljmNwSGLsCTRHEUiIkDBQza.EP_LIMIT),'orderby':orderby,}
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx.update(vFMAyWcljmNwSGLsCTRHEUiIkDBQza.GetDefaultParams(login=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO))
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.callRequestCookies('Get',vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,payload=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,params=vFMAyWcljmNwSGLsCTRHEUiIkDBQzx,headers=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,cookies=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqY=json.loads(vFMAyWcljmNwSGLsCTRHEUiIkDBQqx.text)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQpz=vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['cell_toplist']['celllist']
   for vFMAyWcljmNwSGLsCTRHEUiIkDBQpq in vFMAyWcljmNwSGLsCTRHEUiIkDBQpz:
    vFMAyWcljmNwSGLsCTRHEUiIkDBQax=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',vFMAyWcljmNwSGLsCTRHEUiIkDBQpq.get('synopsis'))
    vFMAyWcljmNwSGLsCTRHEUiIkDBQaY=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.HTTPTAG+vFMAyWcljmNwSGLsCTRHEUiIkDBQpq.get('thumbnail')
    vFMAyWcljmNwSGLsCTRHEUiIkDBQaP=vFMAyWcljmNwSGLsCTRHEUiIkDBQau=vFMAyWcljmNwSGLsCTRHEUiIkDBQag=''
    vFMAyWcljmNwSGLsCTRHEUiIkDBQaP =vFMAyWcljmNwSGLsCTRHEUiIkDBQar.get('imgPoster')
    vFMAyWcljmNwSGLsCTRHEUiIkDBQau =vFMAyWcljmNwSGLsCTRHEUiIkDBQar.get('imgFanart')
    vFMAyWcljmNwSGLsCTRHEUiIkDBQag =vFMAyWcljmNwSGLsCTRHEUiIkDBQar.get('imgClearlogo')
    vFMAyWcljmNwSGLsCTRHEUiIkDBQaX=vFMAyWcljmNwSGLsCTRHEUiIkDBQar.get('programtitle')
    vFMAyWcljmNwSGLsCTRHEUiIkDBQah={'thumb':vFMAyWcljmNwSGLsCTRHEUiIkDBQaY,'poster':vFMAyWcljmNwSGLsCTRHEUiIkDBQaP,'fanart':vFMAyWcljmNwSGLsCTRHEUiIkDBQau,'clearlogo':vFMAyWcljmNwSGLsCTRHEUiIkDBQag}
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpa={'programtitle':vFMAyWcljmNwSGLsCTRHEUiIkDBQaX,'episodetitle':vFMAyWcljmNwSGLsCTRHEUiIkDBQpq['title_list'][0]['text'],'episodenumber':vFMAyWcljmNwSGLsCTRHEUiIkDBQpq['title_list'][1]['text'].replace('$O$',''),'contentid':vFMAyWcljmNwSGLsCTRHEUiIkDBQpq['contentid'],'synopsis':vFMAyWcljmNwSGLsCTRHEUiIkDBQza.Get_ChangeText(vFMAyWcljmNwSGLsCTRHEUiIkDBQax),'episodeactors':vFMAyWcljmNwSGLsCTRHEUiIkDBQpq.get('actors').split(',')if vFMAyWcljmNwSGLsCTRHEUiIkDBQpq.get('actors')!='' else[],'thumbnail':vFMAyWcljmNwSGLsCTRHEUiIkDBQah,}
    vFMAyWcljmNwSGLsCTRHEUiIkDBQab.append(vFMAyWcljmNwSGLsCTRHEUiIkDBQpa)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQpb=vFMAyWcljmNwSGLsCTRHEUiIkDBQrh(vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['cell_toplist']['pagecount'])
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['cell_toplist']['count']:vFMAyWcljmNwSGLsCTRHEUiIkDBQpg =vFMAyWcljmNwSGLsCTRHEUiIkDBQrh(vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['cell_toplist']['count'])
   else:vFMAyWcljmNwSGLsCTRHEUiIkDBQpg=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.EP_LIMIT*page_int
   vFMAyWcljmNwSGLsCTRHEUiIkDBQpK=vFMAyWcljmNwSGLsCTRHEUiIkDBQpb>vFMAyWcljmNwSGLsCTRHEUiIkDBQpg
  except vFMAyWcljmNwSGLsCTRHEUiIkDBQre as exception:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQrJ(exception)
   return[],vFMAyWcljmNwSGLsCTRHEUiIkDBQoO
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQab,vFMAyWcljmNwSGLsCTRHEUiIkDBQpK
 def GetEPGList(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,genre):
  vFMAyWcljmNwSGLsCTRHEUiIkDBQaf={}
  try:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQan=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.Get_Now_Datetime()
   if genre=='all':
    vFMAyWcljmNwSGLsCTRHEUiIkDBQaV =vFMAyWcljmNwSGLsCTRHEUiIkDBQan+datetime.timedelta(hours=3)
   else:
    vFMAyWcljmNwSGLsCTRHEUiIkDBQaV =vFMAyWcljmNwSGLsCTRHEUiIkDBQan+datetime.timedelta(hours=3)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqb=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.API_DOMAIN+'/live/epgs'
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx={'limit':'100','offset':'0','genre':genre,'startdatetime':vFMAyWcljmNwSGLsCTRHEUiIkDBQan.strftime('%Y-%m-%d %H:00'),'enddatetime':vFMAyWcljmNwSGLsCTRHEUiIkDBQaV.strftime('%Y-%m-%d %H:00')}
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx.update(vFMAyWcljmNwSGLsCTRHEUiIkDBQza.GetDefaultParams(login=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO))
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.callRequestCookies('Get',vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,payload=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,params=vFMAyWcljmNwSGLsCTRHEUiIkDBQzx,headers=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,cookies=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqY=json.loads(vFMAyWcljmNwSGLsCTRHEUiIkDBQqx.text)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQaO=vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['list']
   for vFMAyWcljmNwSGLsCTRHEUiIkDBQpq in vFMAyWcljmNwSGLsCTRHEUiIkDBQaO:
    vFMAyWcljmNwSGLsCTRHEUiIkDBQat=''
    for vFMAyWcljmNwSGLsCTRHEUiIkDBQez in vFMAyWcljmNwSGLsCTRHEUiIkDBQpq['list']:
     if vFMAyWcljmNwSGLsCTRHEUiIkDBQat:vFMAyWcljmNwSGLsCTRHEUiIkDBQat+='\n'
     vFMAyWcljmNwSGLsCTRHEUiIkDBQat+=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.Get_ChangeText(vFMAyWcljmNwSGLsCTRHEUiIkDBQez['title'])+'\n'
     vFMAyWcljmNwSGLsCTRHEUiIkDBQat+=' [%s ~ %s]'%(vFMAyWcljmNwSGLsCTRHEUiIkDBQez['starttime'][-5:],vFMAyWcljmNwSGLsCTRHEUiIkDBQez['endtime'][-5:])+'\n'
    vFMAyWcljmNwSGLsCTRHEUiIkDBQaf[vFMAyWcljmNwSGLsCTRHEUiIkDBQpq['channelid']]=vFMAyWcljmNwSGLsCTRHEUiIkDBQat
  except vFMAyWcljmNwSGLsCTRHEUiIkDBQre as exception:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQrJ(exception)
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQaf
 def Get_LiveChannel_List(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,genre,vFMAyWcljmNwSGLsCTRHEUiIkDBQqO):
  vFMAyWcljmNwSGLsCTRHEUiIkDBQpd=[]
  (vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,vFMAyWcljmNwSGLsCTRHEUiIkDBQzx)=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.Baseapi_Parse(vFMAyWcljmNwSGLsCTRHEUiIkDBQqO)
  if vFMAyWcljmNwSGLsCTRHEUiIkDBQqb=='':return vFMAyWcljmNwSGLsCTRHEUiIkDBQpd
  vFMAyWcljmNwSGLsCTRHEUiIkDBQeq=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.GetEPGList(genre)
  try:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx.update(vFMAyWcljmNwSGLsCTRHEUiIkDBQza.GetDefaultParams(login=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO))
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx['genre']=genre
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.callRequestCookies('Get',vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,payload=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,params=vFMAyWcljmNwSGLsCTRHEUiIkDBQzx,headers=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,cookies=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqY=json.loads(vFMAyWcljmNwSGLsCTRHEUiIkDBQqx.text)
   if not('celllist' in vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['cell_toplist']):return[]
   vFMAyWcljmNwSGLsCTRHEUiIkDBQpz=vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['cell_toplist']['celllist']
   for vFMAyWcljmNwSGLsCTRHEUiIkDBQpq in vFMAyWcljmNwSGLsCTRHEUiIkDBQpz:
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpt=vFMAyWcljmNwSGLsCTRHEUiIkDBQpq['contentid']
    if vFMAyWcljmNwSGLsCTRHEUiIkDBQpt in vFMAyWcljmNwSGLsCTRHEUiIkDBQeq:
     vFMAyWcljmNwSGLsCTRHEUiIkDBQep=vFMAyWcljmNwSGLsCTRHEUiIkDBQeq[vFMAyWcljmNwSGLsCTRHEUiIkDBQpt]
    else:
     vFMAyWcljmNwSGLsCTRHEUiIkDBQep=''
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpa={'studio':vFMAyWcljmNwSGLsCTRHEUiIkDBQpq['title_list'][0]['text'],'tvshowtitle':vFMAyWcljmNwSGLsCTRHEUiIkDBQza.Get_ChangeText(vFMAyWcljmNwSGLsCTRHEUiIkDBQpq['title_list'][1]['text']),'channelid':vFMAyWcljmNwSGLsCTRHEUiIkDBQpt,'age':vFMAyWcljmNwSGLsCTRHEUiIkDBQpq['age'],'thumbnail':'https://%s'%vFMAyWcljmNwSGLsCTRHEUiIkDBQpq.get('thumbnail'),'epg':vFMAyWcljmNwSGLsCTRHEUiIkDBQep}
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpd.append(vFMAyWcljmNwSGLsCTRHEUiIkDBQpa)
  except vFMAyWcljmNwSGLsCTRHEUiIkDBQre as exception:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQrJ(exception)
   return[]
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQpd
 def Get_Search_List(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,search_key,sType,page_int,exclusion21=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO):
  vFMAyWcljmNwSGLsCTRHEUiIkDBQea=[]
  vFMAyWcljmNwSGLsCTRHEUiIkDBQpb=vFMAyWcljmNwSGLsCTRHEUiIkDBQpg=1
  vFMAyWcljmNwSGLsCTRHEUiIkDBQpK=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO
  try:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqb=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.API_DOMAIN+'/fz/search/band.js'
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':vFMAyWcljmNwSGLsCTRHEUiIkDBQrp((page_int-1)*vFMAyWcljmNwSGLsCTRHEUiIkDBQza.SEARCH_LIMIT),'limit':vFMAyWcljmNwSGLsCTRHEUiIkDBQza.SEARCH_LIMIT,'orderby':'score','mtype':'svod',}
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx.update(vFMAyWcljmNwSGLsCTRHEUiIkDBQza.GetDefaultParams(login=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO))
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.callRequestCookies('Get',vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,payload=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,params=vFMAyWcljmNwSGLsCTRHEUiIkDBQzx,headers=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,cookies=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQaz=json.loads(vFMAyWcljmNwSGLsCTRHEUiIkDBQqx.text)
   if not('celllist' in vFMAyWcljmNwSGLsCTRHEUiIkDBQaz['band']):return vFMAyWcljmNwSGLsCTRHEUiIkDBQea,vFMAyWcljmNwSGLsCTRHEUiIkDBQpK
   vFMAyWcljmNwSGLsCTRHEUiIkDBQpz=vFMAyWcljmNwSGLsCTRHEUiIkDBQaz['band']['celllist']
   for vFMAyWcljmNwSGLsCTRHEUiIkDBQpq in vFMAyWcljmNwSGLsCTRHEUiIkDBQpz:
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpx =vFMAyWcljmNwSGLsCTRHEUiIkDBQpq['event_list'][1]['url']
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpY=urllib.parse.urlsplit(vFMAyWcljmNwSGLsCTRHEUiIkDBQpx).query
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpP=vFMAyWcljmNwSGLsCTRHEUiIkDBQpY[0:vFMAyWcljmNwSGLsCTRHEUiIkDBQpY.find('=')]
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpV=vFMAyWcljmNwSGLsCTRHEUiIkDBQro(urllib.parse.parse_qsl(vFMAyWcljmNwSGLsCTRHEUiIkDBQpY))
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpu=vFMAyWcljmNwSGLsCTRHEUiIkDBQpV.get(vFMAyWcljmNwSGLsCTRHEUiIkDBQpP)
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpa={'title':vFMAyWcljmNwSGLsCTRHEUiIkDBQpq['title_list'][0]['text'],'age':vFMAyWcljmNwSGLsCTRHEUiIkDBQpq['age'],'thumbnail':'https://%s'%vFMAyWcljmNwSGLsCTRHEUiIkDBQpq.get('thumbnail'),'videoid':vFMAyWcljmNwSGLsCTRHEUiIkDBQpu,'vidtype':vFMAyWcljmNwSGLsCTRHEUiIkDBQpP,}
    vFMAyWcljmNwSGLsCTRHEUiIkDBQeJ=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO
    for vFMAyWcljmNwSGLsCTRHEUiIkDBQeo in vFMAyWcljmNwSGLsCTRHEUiIkDBQpq['bottom_taglist']:
     if vFMAyWcljmNwSGLsCTRHEUiIkDBQeo=='won':
      vFMAyWcljmNwSGLsCTRHEUiIkDBQeJ=vFMAyWcljmNwSGLsCTRHEUiIkDBQrz
      break
    if vFMAyWcljmNwSGLsCTRHEUiIkDBQeJ==vFMAyWcljmNwSGLsCTRHEUiIkDBQrz: 
     vFMAyWcljmNwSGLsCTRHEUiIkDBQpa['title']=vFMAyWcljmNwSGLsCTRHEUiIkDBQpa['title']+' [개별구매]'
    if exclusion21==vFMAyWcljmNwSGLsCTRHEUiIkDBQoO or vFMAyWcljmNwSGLsCTRHEUiIkDBQpq.get('age')!='21':
     vFMAyWcljmNwSGLsCTRHEUiIkDBQea.append(vFMAyWcljmNwSGLsCTRHEUiIkDBQpa)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQpb=vFMAyWcljmNwSGLsCTRHEUiIkDBQrh(vFMAyWcljmNwSGLsCTRHEUiIkDBQaz['band']['pagecount'])
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQaz['band']['count']:vFMAyWcljmNwSGLsCTRHEUiIkDBQpg =vFMAyWcljmNwSGLsCTRHEUiIkDBQrh(vFMAyWcljmNwSGLsCTRHEUiIkDBQaz['band']['count'])
   else:vFMAyWcljmNwSGLsCTRHEUiIkDBQpg=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.LIST_LIMIT
   vFMAyWcljmNwSGLsCTRHEUiIkDBQpK=vFMAyWcljmNwSGLsCTRHEUiIkDBQpb>vFMAyWcljmNwSGLsCTRHEUiIkDBQpg
  except vFMAyWcljmNwSGLsCTRHEUiIkDBQre as exception:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQrJ(exception)
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQea,vFMAyWcljmNwSGLsCTRHEUiIkDBQpK 
 def GetSecureToken(vFMAyWcljmNwSGLsCTRHEUiIkDBQza):
  vFMAyWcljmNwSGLsCTRHEUiIkDBQqb=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.API_DOMAIN+'/ip'
  vFMAyWcljmNwSGLsCTRHEUiIkDBQzx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.GetDefaultParams(login=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO)
  vFMAyWcljmNwSGLsCTRHEUiIkDBQqx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.callRequestCookies('Get',vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,payload=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,params=vFMAyWcljmNwSGLsCTRHEUiIkDBQzx,headers=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,cookies=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV)
  vFMAyWcljmNwSGLsCTRHEUiIkDBQqY=json.loads(vFMAyWcljmNwSGLsCTRHEUiIkDBQqx.text)
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['securetoken']
 def Wavve_Parse_m3u8(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,vFMAyWcljmNwSGLsCTRHEUiIkDBQJr):
  try:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqr={'user-agent':'pooqV2/5.6.0 (Linux;Android 10) ExoPlayerLib/2.13.3'}
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqx=requests.get(url=vFMAyWcljmNwSGLsCTRHEUiIkDBQJr['stream_url'],headers=vFMAyWcljmNwSGLsCTRHEUiIkDBQqr,cookies=vFMAyWcljmNwSGLsCTRHEUiIkDBQJr['stream_cookie'])
   vFMAyWcljmNwSGLsCTRHEUiIkDBQer=vFMAyWcljmNwSGLsCTRHEUiIkDBQqx.content.decode('utf-8')
   if '#EXTM3U' not in vFMAyWcljmNwSGLsCTRHEUiIkDBQer:
    return vFMAyWcljmNwSGLsCTRHEUiIkDBQoO
   if '#EXT-X-STREAM-INF' not in vFMAyWcljmNwSGLsCTRHEUiIkDBQer: 
    return vFMAyWcljmNwSGLsCTRHEUiIkDBQoO
   vFMAyWcljmNwSGLsCTRHEUiIkDBQeh=0
   for vFMAyWcljmNwSGLsCTRHEUiIkDBQed in vFMAyWcljmNwSGLsCTRHEUiIkDBQer.splitlines():
    if vFMAyWcljmNwSGLsCTRHEUiIkDBQed.startswith('#EXT-X-STREAM-INF'):
     vFMAyWcljmNwSGLsCTRHEUiIkDBQeb=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.MediaLine_Parse(vFMAyWcljmNwSGLsCTRHEUiIkDBQed,'#EXT-X-STREAM-INF')
     if vFMAyWcljmNwSGLsCTRHEUiIkDBQeh<vFMAyWcljmNwSGLsCTRHEUiIkDBQrh(vFMAyWcljmNwSGLsCTRHEUiIkDBQeb.get('BANDWIDTH')):
      vFMAyWcljmNwSGLsCTRHEUiIkDBQeh=vFMAyWcljmNwSGLsCTRHEUiIkDBQrh(vFMAyWcljmNwSGLsCTRHEUiIkDBQeb.get('BANDWIDTH'))
   vFMAyWcljmNwSGLsCTRHEUiIkDBQeK=[]
   vFMAyWcljmNwSGLsCTRHEUiIkDBQex=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO
   for vFMAyWcljmNwSGLsCTRHEUiIkDBQed in vFMAyWcljmNwSGLsCTRHEUiIkDBQer.splitlines():
    if vFMAyWcljmNwSGLsCTRHEUiIkDBQex==vFMAyWcljmNwSGLsCTRHEUiIkDBQrz:
     vFMAyWcljmNwSGLsCTRHEUiIkDBQex=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO
     continue
    if vFMAyWcljmNwSGLsCTRHEUiIkDBQed.startswith('#EXT-X-STREAM-INF'):
     vFMAyWcljmNwSGLsCTRHEUiIkDBQeb=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.MediaLine_Parse(vFMAyWcljmNwSGLsCTRHEUiIkDBQed,'#EXT-X-STREAM-INF')
     if vFMAyWcljmNwSGLsCTRHEUiIkDBQeh!=vFMAyWcljmNwSGLsCTRHEUiIkDBQrh(vFMAyWcljmNwSGLsCTRHEUiIkDBQeb.get('BANDWIDTH')):
      vFMAyWcljmNwSGLsCTRHEUiIkDBQex=vFMAyWcljmNwSGLsCTRHEUiIkDBQrz
      continue
    vFMAyWcljmNwSGLsCTRHEUiIkDBQeK.append(vFMAyWcljmNwSGLsCTRHEUiIkDBQed)
  except vFMAyWcljmNwSGLsCTRHEUiIkDBQre as exception:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQrJ(exception)
   return vFMAyWcljmNwSGLsCTRHEUiIkDBQoO
  vFMAyWcljmNwSGLsCTRHEUiIkDBQeY='\n'.join(vFMAyWcljmNwSGLsCTRHEUiIkDBQeK)
  vFMAyWcljmNwSGLsCTRHEUiIkDBQza.TextFile_Save(vFMAyWcljmNwSGLsCTRHEUiIkDBQza.WV_STREAM_FILENAME,vFMAyWcljmNwSGLsCTRHEUiIkDBQeY)
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQrz
 def Wavve_Parse_mpd(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,vFMAyWcljmNwSGLsCTRHEUiIkDBQJr):
  vFMAyWcljmNwSGLsCTRHEUiIkDBQqr={'user-agent':'pooqV2/5.6.0 (Linux;Android 10) ExoPlayerLib/2.13.3'}
  vFMAyWcljmNwSGLsCTRHEUiIkDBQqx=requests.get(url=vFMAyWcljmNwSGLsCTRHEUiIkDBQJr['stream_url'],headers=vFMAyWcljmNwSGLsCTRHEUiIkDBQqr,cookies=vFMAyWcljmNwSGLsCTRHEUiIkDBQJr['stream_cookie'])
  vFMAyWcljmNwSGLsCTRHEUiIkDBQeP=vFMAyWcljmNwSGLsCTRHEUiIkDBQqx.content.decode('utf-8')
  vFMAyWcljmNwSGLsCTRHEUiIkDBQeu =ET.ElementTree(ET.fromstring(vFMAyWcljmNwSGLsCTRHEUiIkDBQeP))
  vFMAyWcljmNwSGLsCTRHEUiIkDBQeg =vFMAyWcljmNwSGLsCTRHEUiIkDBQeu.getroot()
  vFMAyWcljmNwSGLsCTRHEUiIkDBQeX=re.match(r'\{.*\}',vFMAyWcljmNwSGLsCTRHEUiIkDBQeg.tag)[0] 
  vFMAyWcljmNwSGLsCTRHEUiIkDBQef=vFMAyWcljmNwSGLsCTRHEUiIkDBQro([node for _,node in ET.iterparse(io.StringIO(vFMAyWcljmNwSGLsCTRHEUiIkDBQeP),events=['start-ns'])])
  for vFMAyWcljmNwSGLsCTRHEUiIkDBQqJ,vFMAyWcljmNwSGLsCTRHEUiIkDBQJo in vFMAyWcljmNwSGLsCTRHEUiIkDBQef.items():
   ET.register_namespace(vFMAyWcljmNwSGLsCTRHEUiIkDBQqJ,vFMAyWcljmNwSGLsCTRHEUiIkDBQJo)
  vFMAyWcljmNwSGLsCTRHEUiIkDBQen=vFMAyWcljmNwSGLsCTRHEUiIkDBQeg.find(vFMAyWcljmNwSGLsCTRHEUiIkDBQeX+'Period')
  for vFMAyWcljmNwSGLsCTRHEUiIkDBQeV in vFMAyWcljmNwSGLsCTRHEUiIkDBQen.findall(vFMAyWcljmNwSGLsCTRHEUiIkDBQeX+'AdaptationSet'):
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQeV.attrib.get('mimeType')=='video/mp4':
    vFMAyWcljmNwSGLsCTRHEUiIkDBQeO=0
    for vFMAyWcljmNwSGLsCTRHEUiIkDBQet in vFMAyWcljmNwSGLsCTRHEUiIkDBQeV.findall(vFMAyWcljmNwSGLsCTRHEUiIkDBQeX+'Representation'):
     vFMAyWcljmNwSGLsCTRHEUiIkDBQJz=vFMAyWcljmNwSGLsCTRHEUiIkDBQrh(vFMAyWcljmNwSGLsCTRHEUiIkDBQet.attrib.get('bandwidth'))
     if vFMAyWcljmNwSGLsCTRHEUiIkDBQeO<vFMAyWcljmNwSGLsCTRHEUiIkDBQJz:vFMAyWcljmNwSGLsCTRHEUiIkDBQeO=vFMAyWcljmNwSGLsCTRHEUiIkDBQJz
    for vFMAyWcljmNwSGLsCTRHEUiIkDBQet in vFMAyWcljmNwSGLsCTRHEUiIkDBQeV.findall(vFMAyWcljmNwSGLsCTRHEUiIkDBQeX+'Representation'):
     if vFMAyWcljmNwSGLsCTRHEUiIkDBQeO>vFMAyWcljmNwSGLsCTRHEUiIkDBQrh(vFMAyWcljmNwSGLsCTRHEUiIkDBQet.attrib.get('bandwidth')):
      vFMAyWcljmNwSGLsCTRHEUiIkDBQeV.remove(vFMAyWcljmNwSGLsCTRHEUiIkDBQet)
   elif vFMAyWcljmNwSGLsCTRHEUiIkDBQeV.attrib.get('mimeType')=='audio/mp4':
    vFMAyWcljmNwSGLsCTRHEUiIkDBQeO=0
    for vFMAyWcljmNwSGLsCTRHEUiIkDBQet in vFMAyWcljmNwSGLsCTRHEUiIkDBQeV.findall(vFMAyWcljmNwSGLsCTRHEUiIkDBQeX+'Representation'):
     vFMAyWcljmNwSGLsCTRHEUiIkDBQJz=vFMAyWcljmNwSGLsCTRHEUiIkDBQrh(vFMAyWcljmNwSGLsCTRHEUiIkDBQet.attrib.get('bandwidth'))
     if vFMAyWcljmNwSGLsCTRHEUiIkDBQeO<vFMAyWcljmNwSGLsCTRHEUiIkDBQJz:vFMAyWcljmNwSGLsCTRHEUiIkDBQeO=vFMAyWcljmNwSGLsCTRHEUiIkDBQJz
    for vFMAyWcljmNwSGLsCTRHEUiIkDBQet in vFMAyWcljmNwSGLsCTRHEUiIkDBQeV.findall(vFMAyWcljmNwSGLsCTRHEUiIkDBQeX+'Representation'):
     if vFMAyWcljmNwSGLsCTRHEUiIkDBQeO>vFMAyWcljmNwSGLsCTRHEUiIkDBQrh(vFMAyWcljmNwSGLsCTRHEUiIkDBQet.attrib.get('bandwidth')):
      vFMAyWcljmNwSGLsCTRHEUiIkDBQeV.remove(vFMAyWcljmNwSGLsCTRHEUiIkDBQet)
   else:
    continue
  vFMAyWcljmNwSGLsCTRHEUiIkDBQJq=ET.tostring(vFMAyWcljmNwSGLsCTRHEUiIkDBQeg).decode('utf-8')
  vFMAyWcljmNwSGLsCTRHEUiIkDBQJp='<?xml version="1.0" encoding="UTF-8"?>\n'
  vFMAyWcljmNwSGLsCTRHEUiIkDBQza.TextFile_Save(vFMAyWcljmNwSGLsCTRHEUiIkDBQza.WV_STREAM_FILENAME,vFMAyWcljmNwSGLsCTRHEUiIkDBQJp+vFMAyWcljmNwSGLsCTRHEUiIkDBQJq)
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQrz
 def MediaLine_Parse(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,vFMAyWcljmNwSGLsCTRHEUiIkDBQed,prefix):
  vFMAyWcljmNwSGLsCTRHEUiIkDBQeb={}
  for vFMAyWcljmNwSGLsCTRHEUiIkDBQJa in vFMAyWcljmNwSGLsCTRHEUiIkDBQzp.split(vFMAyWcljmNwSGLsCTRHEUiIkDBQed.replace(prefix+':',''))[1::2]:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQJe,vFMAyWcljmNwSGLsCTRHEUiIkDBQJo=vFMAyWcljmNwSGLsCTRHEUiIkDBQJa.split('=',1)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQeb[vFMAyWcljmNwSGLsCTRHEUiIkDBQJe.upper()]=vFMAyWcljmNwSGLsCTRHEUiIkDBQJo.replace('"','').strip()
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQeb
 def GetStreamingURL(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,mode,vFMAyWcljmNwSGLsCTRHEUiIkDBQpt,quality_int,pvrmode='-',playOption={}):
  vFMAyWcljmNwSGLsCTRHEUiIkDBQJr ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  vFMAyWcljmNwSGLsCTRHEUiIkDBQJh=[]
  if mode=='LIVE':
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqb =vFMAyWcljmNwSGLsCTRHEUiIkDBQza.API_DOMAIN+'/live/channels/'+vFMAyWcljmNwSGLsCTRHEUiIkDBQpt
   vFMAyWcljmNwSGLsCTRHEUiIkDBQJd='live'
  elif mode=='VOD':
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqb =vFMAyWcljmNwSGLsCTRHEUiIkDBQza.API_DOMAIN+'/fz/vod/contents-detail/'+vFMAyWcljmNwSGLsCTRHEUiIkDBQpt 
   vFMAyWcljmNwSGLsCTRHEUiIkDBQJd='vod'
  elif mode=='MOVIE':
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqb =vFMAyWcljmNwSGLsCTRHEUiIkDBQza.API_DOMAIN+'/fz/movie/contents/'+vFMAyWcljmNwSGLsCTRHEUiIkDBQpt
   vFMAyWcljmNwSGLsCTRHEUiIkDBQJd='movie'
  vFMAyWcljmNwSGLsCTRHEUiIkDBQJb={'hdr':'sdr','uhd':'-',}
  try:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.GetDefaultParams(login=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.callRequestCookies('Get',vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,payload=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,params=vFMAyWcljmNwSGLsCTRHEUiIkDBQzx,headers=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,cookies=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqY=json.loads(vFMAyWcljmNwSGLsCTRHEUiIkDBQqx.text)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQJK=vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['qualities']['list']
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQJK==vFMAyWcljmNwSGLsCTRHEUiIkDBQoV:return vFMAyWcljmNwSGLsCTRHEUiIkDBQJr
   for vFMAyWcljmNwSGLsCTRHEUiIkDBQJx in vFMAyWcljmNwSGLsCTRHEUiIkDBQJK:
    vFMAyWcljmNwSGLsCTRHEUiIkDBQJh.append(vFMAyWcljmNwSGLsCTRHEUiIkDBQrh(vFMAyWcljmNwSGLsCTRHEUiIkDBQJx.get('id').rstrip('p')))
   if 'type' in vFMAyWcljmNwSGLsCTRHEUiIkDBQqY:
    if vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['type']=='onair':
     vFMAyWcljmNwSGLsCTRHEUiIkDBQJd='onairvod'
   if 'drms' in vFMAyWcljmNwSGLsCTRHEUiIkDBQqY:
    if vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['drms']:
     vFMAyWcljmNwSGLsCTRHEUiIkDBQJr['stream_action']='dash' 
   if playOption.get('enable_hdr'):
    if 'mediatypes' in vFMAyWcljmNwSGLsCTRHEUiIkDBQqY.get('qualities'):
     for vFMAyWcljmNwSGLsCTRHEUiIkDBQJY in vFMAyWcljmNwSGLsCTRHEUiIkDBQqY.get('qualities').get('mediatypes'):
      if vFMAyWcljmNwSGLsCTRHEUiIkDBQJY=='HDR10':
       vFMAyWcljmNwSGLsCTRHEUiIkDBQJb['hdr']='hdr'
       vFMAyWcljmNwSGLsCTRHEUiIkDBQJr['stream_action']='dash'
       break
   if playOption.get('enable_uhd'):
    for vFMAyWcljmNwSGLsCTRHEUiIkDBQJY in vFMAyWcljmNwSGLsCTRHEUiIkDBQqY.get('qualities').get('list'):
     if vFMAyWcljmNwSGLsCTRHEUiIkDBQJY.get('name')=='UHD':
      vFMAyWcljmNwSGLsCTRHEUiIkDBQJb['uhd']='uhd'
      break
  except vFMAyWcljmNwSGLsCTRHEUiIkDBQre as exception:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQrJ(exception)
   return vFMAyWcljmNwSGLsCTRHEUiIkDBQJr
  vFMAyWcljmNwSGLsCTRHEUiIkDBQrJ('stream_action : '+vFMAyWcljmNwSGLsCTRHEUiIkDBQJr['stream_action'])
  try:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQJP=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.CheckQuality(quality_int,vFMAyWcljmNwSGLsCTRHEUiIkDBQJh)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQrJ(vFMAyWcljmNwSGLsCTRHEUiIkDBQJP)
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQJP<1080:
    vFMAyWcljmNwSGLsCTRHEUiIkDBQJb['uhd']='-'
    vFMAyWcljmNwSGLsCTRHEUiIkDBQJb['hdr']='sdr'
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQJb['uhd']=='uhd':vFMAyWcljmNwSGLsCTRHEUiIkDBQJP=2160 
   vFMAyWcljmNwSGLsCTRHEUiIkDBQJu=vFMAyWcljmNwSGLsCTRHEUiIkDBQrp(vFMAyWcljmNwSGLsCTRHEUiIkDBQJP)+'p'
   vFMAyWcljmNwSGLsCTRHEUiIkDBQrJ(vFMAyWcljmNwSGLsCTRHEUiIkDBQJu)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqb=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.API_DOMAIN+'/fz/streaming'
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQJb['hdr']=='hdr' or vFMAyWcljmNwSGLsCTRHEUiIkDBQJb['uhd']=='uhd':
    vFMAyWcljmNwSGLsCTRHEUiIkDBQzx={'contentid':vFMAyWcljmNwSGLsCTRHEUiIkDBQpt,'contenttype':vFMAyWcljmNwSGLsCTRHEUiIkDBQJd,'quality':vFMAyWcljmNwSGLsCTRHEUiIkDBQJu,'modelid':'SHIELD Android TV','guid':vFMAyWcljmNwSGLsCTRHEUiIkDBQza.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n','protocol':vFMAyWcljmNwSGLsCTRHEUiIkDBQJr['stream_action'],'hdr':'HDR10','videocodec':'HEVC','audiocodec':'AAC','issurround':'y','format':'normal','withinsubtitle':'n',}
    vFMAyWcljmNwSGLsCTRHEUiIkDBQzx.update(vFMAyWcljmNwSGLsCTRHEUiIkDBQza.GetDefaultParams_AND())
   else:
    vFMAyWcljmNwSGLsCTRHEUiIkDBQzx={'contentid':vFMAyWcljmNwSGLsCTRHEUiIkDBQpt,'contenttype':vFMAyWcljmNwSGLsCTRHEUiIkDBQJd,'quality':vFMAyWcljmNwSGLsCTRHEUiIkDBQJu,'deviceModelId':'Windows 10','guid':vFMAyWcljmNwSGLsCTRHEUiIkDBQza.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n','action':vFMAyWcljmNwSGLsCTRHEUiIkDBQJr['stream_action'],'protocol':vFMAyWcljmNwSGLsCTRHEUiIkDBQJr['stream_action'],'hdr':'sdr','videocodec':'avc','audiocodec':'aac','issurround':'n','format':'normal','withinsubtitle':'n',}
    vFMAyWcljmNwSGLsCTRHEUiIkDBQzx.update(vFMAyWcljmNwSGLsCTRHEUiIkDBQza.GetDefaultParams(login=vFMAyWcljmNwSGLsCTRHEUiIkDBQrz))
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.callRequestCookies('Get',vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,payload=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,params=vFMAyWcljmNwSGLsCTRHEUiIkDBQzx,headers=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,cookies=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqY=json.loads(vFMAyWcljmNwSGLsCTRHEUiIkDBQqx.text)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQJr['stream_url']=vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['playurl']
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQJr['stream_url']==vFMAyWcljmNwSGLsCTRHEUiIkDBQoV:return vFMAyWcljmNwSGLsCTRHEUiIkDBQJr
   vFMAyWcljmNwSGLsCTRHEUiIkDBQJr['stream_cookie']=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.make_str_ToCookie(vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['awscookie'])
   vFMAyWcljmNwSGLsCTRHEUiIkDBQJr['stream_drm'] =vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['drm']
   if 'previewmsg' in vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['preview']:vFMAyWcljmNwSGLsCTRHEUiIkDBQJr['stream_preview']=vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['preview']['previewmsg']
   if 'subtitles' in vFMAyWcljmNwSGLsCTRHEUiIkDBQqY:
    for vFMAyWcljmNwSGLsCTRHEUiIkDBQJg in vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['subtitles']:
     if vFMAyWcljmNwSGLsCTRHEUiIkDBQJg.get('languagecode')=='ko':
      vFMAyWcljmNwSGLsCTRHEUiIkDBQJr['stream_vtt']=vFMAyWcljmNwSGLsCTRHEUiIkDBQJg.get('url')
      break
    if vFMAyWcljmNwSGLsCTRHEUiIkDBQJr['stream_vtt']=='':
     for vFMAyWcljmNwSGLsCTRHEUiIkDBQJg in vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['subtitles']:
      if vFMAyWcljmNwSGLsCTRHEUiIkDBQJg.get('languagecode')=='ko_cc':
       vFMAyWcljmNwSGLsCTRHEUiIkDBQJr['stream_vtt']=vFMAyWcljmNwSGLsCTRHEUiIkDBQJg.get('url')
       break
   vFMAyWcljmNwSGLsCTRHEUiIkDBQJr['playParam']=vFMAyWcljmNwSGLsCTRHEUiIkDBQJb 
  except vFMAyWcljmNwSGLsCTRHEUiIkDBQre as exception:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQrJ(exception)
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQJr 
 def GetSportsURL(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,vFMAyWcljmNwSGLsCTRHEUiIkDBQpt,quality_int):
  vFMAyWcljmNwSGLsCTRHEUiIkDBQJr ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  vFMAyWcljmNwSGLsCTRHEUiIkDBQJh=[]
  try:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqb=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.API_DOMAIN+'/streaming/other'
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx={'contentid':vFMAyWcljmNwSGLsCTRHEUiIkDBQpt,'contenttype':'live','action':vFMAyWcljmNwSGLsCTRHEUiIkDBQJr['stream_action'],'quality':vFMAyWcljmNwSGLsCTRHEUiIkDBQrp(quality_int)+'p','deviceModelId':'Windows 10','guid':vFMAyWcljmNwSGLsCTRHEUiIkDBQza.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n',}
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx.update(vFMAyWcljmNwSGLsCTRHEUiIkDBQza.GetDefaultParams(login=vFMAyWcljmNwSGLsCTRHEUiIkDBQrz))
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.callRequestCookies('Get',vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,payload=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,params=vFMAyWcljmNwSGLsCTRHEUiIkDBQzx,headers=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,cookies=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqY=json.loads(vFMAyWcljmNwSGLsCTRHEUiIkDBQqx.text)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQJr['stream_url']=vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['playurl']
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQJr['stream_url']==vFMAyWcljmNwSGLsCTRHEUiIkDBQoV:return vFMAyWcljmNwSGLsCTRHEUiIkDBQJr
   vFMAyWcljmNwSGLsCTRHEUiIkDBQJr['stream_cookie']=vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['awscookie']
  except vFMAyWcljmNwSGLsCTRHEUiIkDBQre as exception:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQrJ(exception)
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQJr
 def make_viewdate(vFMAyWcljmNwSGLsCTRHEUiIkDBQza):
  vFMAyWcljmNwSGLsCTRHEUiIkDBQJX =vFMAyWcljmNwSGLsCTRHEUiIkDBQza.Get_Now_Datetime()
  vFMAyWcljmNwSGLsCTRHEUiIkDBQJf =vFMAyWcljmNwSGLsCTRHEUiIkDBQJX+datetime.timedelta(days=-1)
  vFMAyWcljmNwSGLsCTRHEUiIkDBQJn =vFMAyWcljmNwSGLsCTRHEUiIkDBQJX+datetime.timedelta(days=1)
  vFMAyWcljmNwSGLsCTRHEUiIkDBQJV=[vFMAyWcljmNwSGLsCTRHEUiIkDBQJX.strftime('%Y%m%d'),vFMAyWcljmNwSGLsCTRHEUiIkDBQJn.strftime('%Y%m%d'),]
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQJV
 def Get_Sports_Gamelist(vFMAyWcljmNwSGLsCTRHEUiIkDBQza):
  vFMAyWcljmNwSGLsCTRHEUiIkDBQJO =vFMAyWcljmNwSGLsCTRHEUiIkDBQza.make_viewdate()
  vFMAyWcljmNwSGLsCTRHEUiIkDBQJt=[]
  vFMAyWcljmNwSGLsCTRHEUiIkDBQoz =[]
  for vFMAyWcljmNwSGLsCTRHEUiIkDBQoq in vFMAyWcljmNwSGLsCTRHEUiIkDBQJO:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQop=vFMAyWcljmNwSGLsCTRHEUiIkDBQoq[:6]
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQop not in vFMAyWcljmNwSGLsCTRHEUiIkDBQJt:
    vFMAyWcljmNwSGLsCTRHEUiIkDBQJt.append(vFMAyWcljmNwSGLsCTRHEUiIkDBQop)
  try:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqb='https://annexapi.wavve.com/skb/baseball/teammonthlycalendarlist'
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx={'IF':'IF-PORG-002','m':'getTeamCalendarListBand','response_format':'json','spo_itm_cd':'KBO','teamcd':'all','tgroup':'B','tvalue':'BC123','ver':'2.0',}
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx.update(vFMAyWcljmNwSGLsCTRHEUiIkDBQza.GetDefaultParams(login=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO))
   for vFMAyWcljmNwSGLsCTRHEUiIkDBQoa in vFMAyWcljmNwSGLsCTRHEUiIkDBQJt:
    vFMAyWcljmNwSGLsCTRHEUiIkDBQzx['date']=vFMAyWcljmNwSGLsCTRHEUiIkDBQoa
    vFMAyWcljmNwSGLsCTRHEUiIkDBQqx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.callRequestCookies('Get',vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,payload=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,params=vFMAyWcljmNwSGLsCTRHEUiIkDBQzx,headers=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,cookies=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV)
    vFMAyWcljmNwSGLsCTRHEUiIkDBQqY=json.loads(vFMAyWcljmNwSGLsCTRHEUiIkDBQqx.text)
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpz=vFMAyWcljmNwSGLsCTRHEUiIkDBQqY['cell_toplist']['celllist']
    for vFMAyWcljmNwSGLsCTRHEUiIkDBQpq in vFMAyWcljmNwSGLsCTRHEUiIkDBQpz:
     vFMAyWcljmNwSGLsCTRHEUiIkDBQoe=vFMAyWcljmNwSGLsCTRHEUiIkDBQpq.get('game_date')
     vFMAyWcljmNwSGLsCTRHEUiIkDBQoJ =vFMAyWcljmNwSGLsCTRHEUiIkDBQpq.get('svc_id')
     if vFMAyWcljmNwSGLsCTRHEUiIkDBQoJ=='':continue
     if vFMAyWcljmNwSGLsCTRHEUiIkDBQoe in vFMAyWcljmNwSGLsCTRHEUiIkDBQJO:
      vFMAyWcljmNwSGLsCTRHEUiIkDBQor=vFMAyWcljmNwSGLsCTRHEUiIkDBQpq.get('game_status') 
      vFMAyWcljmNwSGLsCTRHEUiIkDBQoh =vFMAyWcljmNwSGLsCTRHEUiIkDBQpq.get('title_list')[0].get('text')
      vFMAyWcljmNwSGLsCTRHEUiIkDBQoe =vFMAyWcljmNwSGLsCTRHEUiIkDBQoe[:4]+'-'+vFMAyWcljmNwSGLsCTRHEUiIkDBQoe[4:6]+'-'+vFMAyWcljmNwSGLsCTRHEUiIkDBQoe[-2:]
      vFMAyWcljmNwSGLsCTRHEUiIkDBQod =vFMAyWcljmNwSGLsCTRHEUiIkDBQpq.get('game_time')
      vFMAyWcljmNwSGLsCTRHEUiIkDBQod =vFMAyWcljmNwSGLsCTRHEUiIkDBQod[:2]+':'+vFMAyWcljmNwSGLsCTRHEUiIkDBQod[-2:]
      vFMAyWcljmNwSGLsCTRHEUiIkDBQpa={'game_date':vFMAyWcljmNwSGLsCTRHEUiIkDBQoe,'game_time':vFMAyWcljmNwSGLsCTRHEUiIkDBQod,'svc_id':vFMAyWcljmNwSGLsCTRHEUiIkDBQoJ,'away_team':vFMAyWcljmNwSGLsCTRHEUiIkDBQpq.get('away_team').get('team_name'),'home_team':vFMAyWcljmNwSGLsCTRHEUiIkDBQpq.get('home_team').get('team_name'),'game_status':vFMAyWcljmNwSGLsCTRHEUiIkDBQor,'game_place':vFMAyWcljmNwSGLsCTRHEUiIkDBQpq.get('game_place'),}
      vFMAyWcljmNwSGLsCTRHEUiIkDBQoz.append(vFMAyWcljmNwSGLsCTRHEUiIkDBQpa)
  except vFMAyWcljmNwSGLsCTRHEUiIkDBQre as exception:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQrJ(exception)
   return[]
  vFMAyWcljmNwSGLsCTRHEUiIkDBQob=[]
  for i in vFMAyWcljmNwSGLsCTRHEUiIkDBQrq(2):
   for vFMAyWcljmNwSGLsCTRHEUiIkDBQpq in vFMAyWcljmNwSGLsCTRHEUiIkDBQoz:
    if i==0 and vFMAyWcljmNwSGLsCTRHEUiIkDBQpq.get('game_status')=='LIVE':
     vFMAyWcljmNwSGLsCTRHEUiIkDBQob.append(vFMAyWcljmNwSGLsCTRHEUiIkDBQpq)
    elif i==1 and vFMAyWcljmNwSGLsCTRHEUiIkDBQpq.get('game_status')!='LIVE':
     vFMAyWcljmNwSGLsCTRHEUiIkDBQob.append(vFMAyWcljmNwSGLsCTRHEUiIkDBQpq)
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQob
 def GetBookmarkInfo(vFMAyWcljmNwSGLsCTRHEUiIkDBQza,vFMAyWcljmNwSGLsCTRHEUiIkDBQpu,vFMAyWcljmNwSGLsCTRHEUiIkDBQpP,vFMAyWcljmNwSGLsCTRHEUiIkDBQJd):
  if vFMAyWcljmNwSGLsCTRHEUiIkDBQpP=='tvshow':
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQJd=='contentid':
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpt=vFMAyWcljmNwSGLsCTRHEUiIkDBQpu
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpu =vFMAyWcljmNwSGLsCTRHEUiIkDBQza.ContentidToSeasonid(vFMAyWcljmNwSGLsCTRHEUiIkDBQpt)
   else:
    vFMAyWcljmNwSGLsCTRHEUiIkDBQpt=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.ProgramidToContentid(vFMAyWcljmNwSGLsCTRHEUiIkDBQpu)
  else:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQpt=''
  vFMAyWcljmNwSGLsCTRHEUiIkDBQoK={'indexinfo':{'ott':'wavve','videoid':vFMAyWcljmNwSGLsCTRHEUiIkDBQpu,'vidtype':vFMAyWcljmNwSGLsCTRHEUiIkDBQpP,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vFMAyWcljmNwSGLsCTRHEUiIkDBQpP,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vFMAyWcljmNwSGLsCTRHEUiIkDBQpP=='tvshow':
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqb=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.API_DOMAIN+'/fz/vod/contents/'+vFMAyWcljmNwSGLsCTRHEUiIkDBQpt 
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.GetDefaultParams(login=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.callRequestCookies('Get',vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,payload=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,params=vFMAyWcljmNwSGLsCTRHEUiIkDBQzx,headers=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,cookies=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqY=json.loads(vFMAyWcljmNwSGLsCTRHEUiIkDBQqx.text)
   if not('programtitle' in vFMAyWcljmNwSGLsCTRHEUiIkDBQqY):return{}
   vFMAyWcljmNwSGLsCTRHEUiIkDBQox=vFMAyWcljmNwSGLsCTRHEUiIkDBQqY
   vFMAyWcljmNwSGLsCTRHEUiIkDBQoY=vFMAyWcljmNwSGLsCTRHEUiIkDBQox.get('programtitle')
   vFMAyWcljmNwSGLsCTRHEUiIkDBQoK['saveinfo']['infoLabels']['title']=vFMAyWcljmNwSGLsCTRHEUiIkDBQoY
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQox.get('targetage')=='18' or vFMAyWcljmNwSGLsCTRHEUiIkDBQox.get('targetage')=='19' or vFMAyWcljmNwSGLsCTRHEUiIkDBQox.get('targetage')=='21':
    vFMAyWcljmNwSGLsCTRHEUiIkDBQoY +=u' (%s)'%(vFMAyWcljmNwSGLsCTRHEUiIkDBQox.get('targetage'))
   vFMAyWcljmNwSGLsCTRHEUiIkDBQoK['saveinfo']['title'] =vFMAyWcljmNwSGLsCTRHEUiIkDBQoY
   vFMAyWcljmNwSGLsCTRHEUiIkDBQoK['saveinfo']['infoLabels']['mpaa'] =vFMAyWcljmNwSGLsCTRHEUiIkDBQox.get('targetage')
   vFMAyWcljmNwSGLsCTRHEUiIkDBQoK['saveinfo']['infoLabels']['plot'] =vFMAyWcljmNwSGLsCTRHEUiIkDBQza.Get_ChangeText(vFMAyWcljmNwSGLsCTRHEUiIkDBQox.get('programsynopsis'))
   vFMAyWcljmNwSGLsCTRHEUiIkDBQoK['saveinfo']['infoLabels']['studio'] =vFMAyWcljmNwSGLsCTRHEUiIkDBQox.get('channelname')
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQox.get('firstreleaseyear')!='':vFMAyWcljmNwSGLsCTRHEUiIkDBQoK['saveinfo']['infoLabels']['year'] =vFMAyWcljmNwSGLsCTRHEUiIkDBQox.get('firstreleaseyear')
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQox.get('firstreleasedate')!='':vFMAyWcljmNwSGLsCTRHEUiIkDBQoK['saveinfo']['infoLabels']['premiered']=vFMAyWcljmNwSGLsCTRHEUiIkDBQox.get('firstreleasedate')
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQox.get('genretext') !='':vFMAyWcljmNwSGLsCTRHEUiIkDBQoK['saveinfo']['infoLabels']['genre'] =[vFMAyWcljmNwSGLsCTRHEUiIkDBQox.get('genretext')]
   vFMAyWcljmNwSGLsCTRHEUiIkDBQoP=[]
   for vFMAyWcljmNwSGLsCTRHEUiIkDBQou in vFMAyWcljmNwSGLsCTRHEUiIkDBQox['actors']['list']:vFMAyWcljmNwSGLsCTRHEUiIkDBQoP.append(vFMAyWcljmNwSGLsCTRHEUiIkDBQou.get('text'))
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQra(vFMAyWcljmNwSGLsCTRHEUiIkDBQoP)>0:
    if vFMAyWcljmNwSGLsCTRHEUiIkDBQoP[0]!='':vFMAyWcljmNwSGLsCTRHEUiIkDBQoK['saveinfo']['infoLabels']['cast']=vFMAyWcljmNwSGLsCTRHEUiIkDBQoP
   vFMAyWcljmNwSGLsCTRHEUiIkDBQaP =''
   vFMAyWcljmNwSGLsCTRHEUiIkDBQau =''
   vFMAyWcljmNwSGLsCTRHEUiIkDBQag=''
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQox.get('programposterimage')!='':vFMAyWcljmNwSGLsCTRHEUiIkDBQaP =vFMAyWcljmNwSGLsCTRHEUiIkDBQza.HTTPTAG+vFMAyWcljmNwSGLsCTRHEUiIkDBQox.get('programposterimage')
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQox.get('programimage') !='':vFMAyWcljmNwSGLsCTRHEUiIkDBQau =vFMAyWcljmNwSGLsCTRHEUiIkDBQza.HTTPTAG+vFMAyWcljmNwSGLsCTRHEUiIkDBQox.get('programimage')
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQox.get('programcircleimage')!='':vFMAyWcljmNwSGLsCTRHEUiIkDBQag=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.HTTPTAG+vFMAyWcljmNwSGLsCTRHEUiIkDBQox.get('programcircleimage')
   if 'poster_default' in vFMAyWcljmNwSGLsCTRHEUiIkDBQaP:
    vFMAyWcljmNwSGLsCTRHEUiIkDBQaP =vFMAyWcljmNwSGLsCTRHEUiIkDBQau
    vFMAyWcljmNwSGLsCTRHEUiIkDBQag=''
   vFMAyWcljmNwSGLsCTRHEUiIkDBQoK['saveinfo']['thumbnail']['poster']=vFMAyWcljmNwSGLsCTRHEUiIkDBQaP
   vFMAyWcljmNwSGLsCTRHEUiIkDBQoK['saveinfo']['thumbnail']['thumb']=vFMAyWcljmNwSGLsCTRHEUiIkDBQau
   vFMAyWcljmNwSGLsCTRHEUiIkDBQoK['saveinfo']['thumbnail']['clearlogo']=vFMAyWcljmNwSGLsCTRHEUiIkDBQag
   vFMAyWcljmNwSGLsCTRHEUiIkDBQoK['saveinfo']['thumbnail']['fanart']=vFMAyWcljmNwSGLsCTRHEUiIkDBQau
  else:
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqb=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.API_DOMAIN+'/movie/contents/'+vFMAyWcljmNwSGLsCTRHEUiIkDBQpu 
   vFMAyWcljmNwSGLsCTRHEUiIkDBQzx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.GetDefaultParams(login=vFMAyWcljmNwSGLsCTRHEUiIkDBQoO)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqx=vFMAyWcljmNwSGLsCTRHEUiIkDBQza.callRequestCookies('Get',vFMAyWcljmNwSGLsCTRHEUiIkDBQqb,payload=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,params=vFMAyWcljmNwSGLsCTRHEUiIkDBQzx,headers=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV,cookies=vFMAyWcljmNwSGLsCTRHEUiIkDBQoV)
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqY=json.loads(vFMAyWcljmNwSGLsCTRHEUiIkDBQqx.text)
   if not('title' in vFMAyWcljmNwSGLsCTRHEUiIkDBQqY):return{}
   vFMAyWcljmNwSGLsCTRHEUiIkDBQox=vFMAyWcljmNwSGLsCTRHEUiIkDBQqY
   vFMAyWcljmNwSGLsCTRHEUiIkDBQoY=vFMAyWcljmNwSGLsCTRHEUiIkDBQox.get('title')
   vFMAyWcljmNwSGLsCTRHEUiIkDBQoK['saveinfo']['infoLabels']['title']=vFMAyWcljmNwSGLsCTRHEUiIkDBQoY
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQox.get('targetage')=='18' or vFMAyWcljmNwSGLsCTRHEUiIkDBQox.get('targetage')=='19' or vFMAyWcljmNwSGLsCTRHEUiIkDBQox.get('targetage')=='21':
    vFMAyWcljmNwSGLsCTRHEUiIkDBQoY +=u' (%s)'%(vFMAyWcljmNwSGLsCTRHEUiIkDBQox.get('targetage'))
   vFMAyWcljmNwSGLsCTRHEUiIkDBQoK['saveinfo']['title'] =vFMAyWcljmNwSGLsCTRHEUiIkDBQoY
   vFMAyWcljmNwSGLsCTRHEUiIkDBQoK['saveinfo']['infoLabels']['mpaa'] =vFMAyWcljmNwSGLsCTRHEUiIkDBQox.get('targetage')
   vFMAyWcljmNwSGLsCTRHEUiIkDBQoK['saveinfo']['infoLabels']['plot'] =vFMAyWcljmNwSGLsCTRHEUiIkDBQza.Get_ChangeText(vFMAyWcljmNwSGLsCTRHEUiIkDBQox.get('synopsis'))
   vFMAyWcljmNwSGLsCTRHEUiIkDBQoK['saveinfo']['infoLabels']['duration']=vFMAyWcljmNwSGLsCTRHEUiIkDBQox.get('playtime')
   vFMAyWcljmNwSGLsCTRHEUiIkDBQoK['saveinfo']['infoLabels']['country']=vFMAyWcljmNwSGLsCTRHEUiIkDBQox.get('country')
   vFMAyWcljmNwSGLsCTRHEUiIkDBQoK['saveinfo']['infoLabels']['studio'] =vFMAyWcljmNwSGLsCTRHEUiIkDBQox.get('cpname')
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQox.get('releasedate')!='':
    vFMAyWcljmNwSGLsCTRHEUiIkDBQoK['saveinfo']['infoLabels']['year'] =vFMAyWcljmNwSGLsCTRHEUiIkDBQox.get('releasedate')[:4]
    vFMAyWcljmNwSGLsCTRHEUiIkDBQoK['saveinfo']['infoLabels']['premiered']=vFMAyWcljmNwSGLsCTRHEUiIkDBQox.get('releasedate')
   vFMAyWcljmNwSGLsCTRHEUiIkDBQoP=[]
   for vFMAyWcljmNwSGLsCTRHEUiIkDBQou in vFMAyWcljmNwSGLsCTRHEUiIkDBQox['actors']['list']:vFMAyWcljmNwSGLsCTRHEUiIkDBQoP.append(vFMAyWcljmNwSGLsCTRHEUiIkDBQou.get('text'))
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQra(vFMAyWcljmNwSGLsCTRHEUiIkDBQoP)>0:
    if vFMAyWcljmNwSGLsCTRHEUiIkDBQoP[0]!='':vFMAyWcljmNwSGLsCTRHEUiIkDBQoK['saveinfo']['infoLabels']['cast']=vFMAyWcljmNwSGLsCTRHEUiIkDBQoP
   vFMAyWcljmNwSGLsCTRHEUiIkDBQog=[]
   for vFMAyWcljmNwSGLsCTRHEUiIkDBQoX in vFMAyWcljmNwSGLsCTRHEUiIkDBQox['directors']['list']:vFMAyWcljmNwSGLsCTRHEUiIkDBQog.append(vFMAyWcljmNwSGLsCTRHEUiIkDBQoX.get('text'))
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQra(vFMAyWcljmNwSGLsCTRHEUiIkDBQog)>0:
    if vFMAyWcljmNwSGLsCTRHEUiIkDBQog[0]!='':vFMAyWcljmNwSGLsCTRHEUiIkDBQoK['saveinfo']['infoLabels']['director']=vFMAyWcljmNwSGLsCTRHEUiIkDBQog
   vFMAyWcljmNwSGLsCTRHEUiIkDBQqV=[]
   for vFMAyWcljmNwSGLsCTRHEUiIkDBQof in vFMAyWcljmNwSGLsCTRHEUiIkDBQox['genre']['list']:vFMAyWcljmNwSGLsCTRHEUiIkDBQqV.append(vFMAyWcljmNwSGLsCTRHEUiIkDBQof.get('text'))
   if vFMAyWcljmNwSGLsCTRHEUiIkDBQra(vFMAyWcljmNwSGLsCTRHEUiIkDBQqV)>0:
    if vFMAyWcljmNwSGLsCTRHEUiIkDBQqV[0]!='':vFMAyWcljmNwSGLsCTRHEUiIkDBQoK['saveinfo']['infoLabels']['genre']=vFMAyWcljmNwSGLsCTRHEUiIkDBQqV
   vFMAyWcljmNwSGLsCTRHEUiIkDBQaP ='https://%s'%vFMAyWcljmNwSGLsCTRHEUiIkDBQox['image']
   vFMAyWcljmNwSGLsCTRHEUiIkDBQoK['saveinfo']['thumbnail']['poster'] =vFMAyWcljmNwSGLsCTRHEUiIkDBQaP
   vFMAyWcljmNwSGLsCTRHEUiIkDBQoK['saveinfo']['thumbnail']['thumb'] =vFMAyWcljmNwSGLsCTRHEUiIkDBQaP
  return vFMAyWcljmNwSGLsCTRHEUiIkDBQoK
# Created by pyminifier (https://github.com/liftoff/pyminifier)
