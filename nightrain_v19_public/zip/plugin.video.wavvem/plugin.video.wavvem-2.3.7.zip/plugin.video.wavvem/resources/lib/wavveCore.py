__author__="NightRain"
HVTOpveGCwQXJgrSInBRoFysUcDNfb=object
HVTOpveGCwQXJgrSInBRoFysUcDNfE=None
HVTOpveGCwQXJgrSInBRoFysUcDNfm=False
HVTOpveGCwQXJgrSInBRoFysUcDNfz=open
HVTOpveGCwQXJgrSInBRoFysUcDNfx=True
HVTOpveGCwQXJgrSInBRoFysUcDNfW=range
HVTOpveGCwQXJgrSInBRoFysUcDNfj=str
HVTOpveGCwQXJgrSInBRoFysUcDNfh=Exception
HVTOpveGCwQXJgrSInBRoFysUcDNft=print
HVTOpveGCwQXJgrSInBRoFysUcDNfL=dict
HVTOpveGCwQXJgrSInBRoFysUcDNfu=int
HVTOpveGCwQXJgrSInBRoFysUcDNfM=len
import urllib
import re
import json
import sys
import requests
import datetime
import base64
class HVTOpveGCwQXJgrSInBRoFysUcDNik(HVTOpveGCwQXJgrSInBRoFysUcDNfb):
 def __init__(HVTOpveGCwQXJgrSInBRoFysUcDNiK):
  HVTOpveGCwQXJgrSInBRoFysUcDNiK.API_DOMAIN='https://apis.wavve.com'
  HVTOpveGCwQXJgrSInBRoFysUcDNiK.WV ={}
  HVTOpveGCwQXJgrSInBRoFysUcDNiK.Init_WV_Total()
  HVTOpveGCwQXJgrSInBRoFysUcDNiK.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  HVTOpveGCwQXJgrSInBRoFysUcDNiK.DEVICE ='pc'
  HVTOpveGCwQXJgrSInBRoFysUcDNiK.DRM ='wm'
  HVTOpveGCwQXJgrSInBRoFysUcDNiK.PARTNER ='pooq'
  HVTOpveGCwQXJgrSInBRoFysUcDNiK.POOQZONE ='none'
  HVTOpveGCwQXJgrSInBRoFysUcDNiK.REGION ='kor'
  HVTOpveGCwQXJgrSInBRoFysUcDNiK.TARGETAGE ='all'
  HVTOpveGCwQXJgrSInBRoFysUcDNiK.HTTPTAG ='https://'
  HVTOpveGCwQXJgrSInBRoFysUcDNiK.LIST_LIMIT=30 
  HVTOpveGCwQXJgrSInBRoFysUcDNiK.EP_LIMIT =30 
  HVTOpveGCwQXJgrSInBRoFysUcDNiK.MV_LIMIT =24 
  HVTOpveGCwQXJgrSInBRoFysUcDNiK.SEARCH_LIMIT=20 
  HVTOpveGCwQXJgrSInBRoFysUcDNiK.USER_AGENT ='ozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36'
  HVTOpveGCwQXJgrSInBRoFysUcDNiK.DEFAULT_HEADER={'user-agent':HVTOpveGCwQXJgrSInBRoFysUcDNiK.USER_AGENT}
 def Init_WV_Total(HVTOpveGCwQXJgrSInBRoFysUcDNiK):
  HVTOpveGCwQXJgrSInBRoFysUcDNiK.WV={'account':{},'cookies':{},}
 def callRequestCookies(HVTOpveGCwQXJgrSInBRoFysUcDNiK,jobtype,HVTOpveGCwQXJgrSInBRoFysUcDNia,payload=HVTOpveGCwQXJgrSInBRoFysUcDNfE,params=HVTOpveGCwQXJgrSInBRoFysUcDNfE,headers=HVTOpveGCwQXJgrSInBRoFysUcDNfE,cookies=HVTOpveGCwQXJgrSInBRoFysUcDNfE,redirects=HVTOpveGCwQXJgrSInBRoFysUcDNfm):
  HVTOpveGCwQXJgrSInBRoFysUcDNiq=HVTOpveGCwQXJgrSInBRoFysUcDNiK.DEFAULT_HEADER
  if headers:HVTOpveGCwQXJgrSInBRoFysUcDNiq.update(headers)
  if jobtype=='Get':
   HVTOpveGCwQXJgrSInBRoFysUcDNiY=requests.get(HVTOpveGCwQXJgrSInBRoFysUcDNia,params=params,headers=HVTOpveGCwQXJgrSInBRoFysUcDNiq,cookies=cookies,allow_redirects=redirects)
  else:
   HVTOpveGCwQXJgrSInBRoFysUcDNiY=requests.post(HVTOpveGCwQXJgrSInBRoFysUcDNia,json=payload,params=params,headers=HVTOpveGCwQXJgrSInBRoFysUcDNiq,cookies=cookies,allow_redirects=redirects)
  return HVTOpveGCwQXJgrSInBRoFysUcDNiY
 def JsonFile_Save(HVTOpveGCwQXJgrSInBRoFysUcDNiK,filename,HVTOpveGCwQXJgrSInBRoFysUcDNif):
  if filename=='':return HVTOpveGCwQXJgrSInBRoFysUcDNfm
  try:
   fp=HVTOpveGCwQXJgrSInBRoFysUcDNfz(filename,'w',-1,'utf-8')
   json.dump(HVTOpveGCwQXJgrSInBRoFysUcDNif,fp,indent=4,ensure_ascii=HVTOpveGCwQXJgrSInBRoFysUcDNfm)
   fp.close()
  except:
   return HVTOpveGCwQXJgrSInBRoFysUcDNfm
  return HVTOpveGCwQXJgrSInBRoFysUcDNfx
 def JsonFile_Load(HVTOpveGCwQXJgrSInBRoFysUcDNiK,filename):
  if filename=='':return{}
  try:
   fp=HVTOpveGCwQXJgrSInBRoFysUcDNfz(filename,'r',-1,'utf-8')
   HVTOpveGCwQXJgrSInBRoFysUcDNiA=json.load(fp)
   fp.close()
  except:
   return{}
  return HVTOpveGCwQXJgrSInBRoFysUcDNiA
 def Save_session_acount(HVTOpveGCwQXJgrSInBRoFysUcDNiK,HVTOpveGCwQXJgrSInBRoFysUcDNil,HVTOpveGCwQXJgrSInBRoFysUcDNib,HVTOpveGCwQXJgrSInBRoFysUcDNiE):
  HVTOpveGCwQXJgrSInBRoFysUcDNiK.WV['account']['wvid']=base64.standard_b64encode(HVTOpveGCwQXJgrSInBRoFysUcDNil.encode()).decode('utf-8')
  HVTOpveGCwQXJgrSInBRoFysUcDNiK.WV['account']['wvpw']=base64.standard_b64encode(HVTOpveGCwQXJgrSInBRoFysUcDNib.encode()).decode('utf-8')
  HVTOpveGCwQXJgrSInBRoFysUcDNiK.WV['account']['wvpf']=HVTOpveGCwQXJgrSInBRoFysUcDNiE 
 def Load_session_acount(HVTOpveGCwQXJgrSInBRoFysUcDNiK):
  try:
   HVTOpveGCwQXJgrSInBRoFysUcDNil=base64.standard_b64decode(HVTOpveGCwQXJgrSInBRoFysUcDNiK.WV['account']['wvid']).decode('utf-8')
   HVTOpveGCwQXJgrSInBRoFysUcDNib=base64.standard_b64decode(HVTOpveGCwQXJgrSInBRoFysUcDNiK.WV['account']['wvpw']).decode('utf-8')
   HVTOpveGCwQXJgrSInBRoFysUcDNiE=HVTOpveGCwQXJgrSInBRoFysUcDNiK.WV['account']['wvpf']
  except:
   return '','',0
  return HVTOpveGCwQXJgrSInBRoFysUcDNil,HVTOpveGCwQXJgrSInBRoFysUcDNib,HVTOpveGCwQXJgrSInBRoFysUcDNiE
 def GetDefaultParams(HVTOpveGCwQXJgrSInBRoFysUcDNiK,login=HVTOpveGCwQXJgrSInBRoFysUcDNfx):
  HVTOpveGCwQXJgrSInBRoFysUcDNim={'apikey':HVTOpveGCwQXJgrSInBRoFysUcDNiK.APIKEY,'credential':HVTOpveGCwQXJgrSInBRoFysUcDNiK.WV['cookies']['credential']if login else 'none','device':HVTOpveGCwQXJgrSInBRoFysUcDNiK.DEVICE,'drm':HVTOpveGCwQXJgrSInBRoFysUcDNiK.DRM,'partner':HVTOpveGCwQXJgrSInBRoFysUcDNiK.PARTNER,'pooqzone':HVTOpveGCwQXJgrSInBRoFysUcDNiK.POOQZONE,'region':HVTOpveGCwQXJgrSInBRoFysUcDNiK.REGION,'targetage':HVTOpveGCwQXJgrSInBRoFysUcDNiK.TARGETAGE,}
  return HVTOpveGCwQXJgrSInBRoFysUcDNim
 def GetDefaultParams_AND(HVTOpveGCwQXJgrSInBRoFysUcDNiK):
  HVTOpveGCwQXJgrSInBRoFysUcDNim={'apikey':'6A87455D54481A536DFB8AD397C5EC4D','credential':HVTOpveGCwQXJgrSInBRoFysUcDNiK.WV['cookies']['credential'],'device':'ott','drm':HVTOpveGCwQXJgrSInBRoFysUcDNiK.DRM,'partner':HVTOpveGCwQXJgrSInBRoFysUcDNiK.PARTNER,'pooqzone':HVTOpveGCwQXJgrSInBRoFysUcDNiK.POOQZONE,'region':HVTOpveGCwQXJgrSInBRoFysUcDNiK.REGION,'targetage':HVTOpveGCwQXJgrSInBRoFysUcDNiK.TARGETAGE,}
  return HVTOpveGCwQXJgrSInBRoFysUcDNim
 def GetGUID(HVTOpveGCwQXJgrSInBRoFysUcDNiK,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   HVTOpveGCwQXJgrSInBRoFysUcDNiz=HVTOpveGCwQXJgrSInBRoFysUcDNiK.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   HVTOpveGCwQXJgrSInBRoFysUcDNix=GenerateRandomString(5)
   HVTOpveGCwQXJgrSInBRoFysUcDNiW=HVTOpveGCwQXJgrSInBRoFysUcDNix+media+HVTOpveGCwQXJgrSInBRoFysUcDNiz
   return HVTOpveGCwQXJgrSInBRoFysUcDNiW
  def GenerateRandomString(num):
   from random import randint
   HVTOpveGCwQXJgrSInBRoFysUcDNij=""
   for i in HVTOpveGCwQXJgrSInBRoFysUcDNfW(0,num):
    s=HVTOpveGCwQXJgrSInBRoFysUcDNfj(randint(1,5))
    HVTOpveGCwQXJgrSInBRoFysUcDNij+=s
   return HVTOpveGCwQXJgrSInBRoFysUcDNij
  if guidType==3:
   HVTOpveGCwQXJgrSInBRoFysUcDNiW=guid_str
  else:
   HVTOpveGCwQXJgrSInBRoFysUcDNiW=GenerateID(guid_str)
  HVTOpveGCwQXJgrSInBRoFysUcDNih=HVTOpveGCwQXJgrSInBRoFysUcDNiK.GetHash(HVTOpveGCwQXJgrSInBRoFysUcDNiW)
  if guidType in[2,3]:
   HVTOpveGCwQXJgrSInBRoFysUcDNih='%s-%s-%s-%s-%s'%(HVTOpveGCwQXJgrSInBRoFysUcDNih[:8],HVTOpveGCwQXJgrSInBRoFysUcDNih[8:12],HVTOpveGCwQXJgrSInBRoFysUcDNih[12:16],HVTOpveGCwQXJgrSInBRoFysUcDNih[16:20],HVTOpveGCwQXJgrSInBRoFysUcDNih[20:])
  return HVTOpveGCwQXJgrSInBRoFysUcDNih
 def GetHash(HVTOpveGCwQXJgrSInBRoFysUcDNiK,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return HVTOpveGCwQXJgrSInBRoFysUcDNfj(m.hexdigest())
 def CheckQuality(HVTOpveGCwQXJgrSInBRoFysUcDNiK,sel_qt,qt_list):
  HVTOpveGCwQXJgrSInBRoFysUcDNit=0
  for HVTOpveGCwQXJgrSInBRoFysUcDNiL in qt_list:
   if sel_qt>=HVTOpveGCwQXJgrSInBRoFysUcDNiL:return HVTOpveGCwQXJgrSInBRoFysUcDNiL
   HVTOpveGCwQXJgrSInBRoFysUcDNit=HVTOpveGCwQXJgrSInBRoFysUcDNiL
  return HVTOpveGCwQXJgrSInBRoFysUcDNit
 def Get_Now_Datetime(HVTOpveGCwQXJgrSInBRoFysUcDNiK):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(HVTOpveGCwQXJgrSInBRoFysUcDNiK,in_text):
  HVTOpveGCwQXJgrSInBRoFysUcDNiM=in_text.replace('&lt;','<').replace('&gt;','>')
  HVTOpveGCwQXJgrSInBRoFysUcDNiM=HVTOpveGCwQXJgrSInBRoFysUcDNiM.replace('$O$','')
  HVTOpveGCwQXJgrSInBRoFysUcDNiM=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',HVTOpveGCwQXJgrSInBRoFysUcDNiM)
  HVTOpveGCwQXJgrSInBRoFysUcDNiM=HVTOpveGCwQXJgrSInBRoFysUcDNiM.lstrip('#')
  return HVTOpveGCwQXJgrSInBRoFysUcDNiM
 def GetCredential(HVTOpveGCwQXJgrSInBRoFysUcDNiK,user_id,user_pw,user_pf):
  HVTOpveGCwQXJgrSInBRoFysUcDNiP=HVTOpveGCwQXJgrSInBRoFysUcDNfm
  try:
   HVTOpveGCwQXJgrSInBRoFysUcDNia=HVTOpveGCwQXJgrSInBRoFysUcDNiK.API_DOMAIN+ '/login'
   HVTOpveGCwQXJgrSInBRoFysUcDNim=HVTOpveGCwQXJgrSInBRoFysUcDNiK.GetDefaultParams(login=HVTOpveGCwQXJgrSInBRoFysUcDNfm)
   HVTOpveGCwQXJgrSInBRoFysUcDNki={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   HVTOpveGCwQXJgrSInBRoFysUcDNkK=HVTOpveGCwQXJgrSInBRoFysUcDNiK.callRequestCookies('Post',HVTOpveGCwQXJgrSInBRoFysUcDNia,payload=HVTOpveGCwQXJgrSInBRoFysUcDNki,params=HVTOpveGCwQXJgrSInBRoFysUcDNim,headers=HVTOpveGCwQXJgrSInBRoFysUcDNfE,cookies=HVTOpveGCwQXJgrSInBRoFysUcDNfE)
   HVTOpveGCwQXJgrSInBRoFysUcDNkq=json.loads(HVTOpveGCwQXJgrSInBRoFysUcDNkK.text)
   HVTOpveGCwQXJgrSInBRoFysUcDNiK.WV['cookies']['credential']=HVTOpveGCwQXJgrSInBRoFysUcDNkq['credential']
   if user_pf!=0:
    HVTOpveGCwQXJgrSInBRoFysUcDNki={'id':HVTOpveGCwQXJgrSInBRoFysUcDNiK.WV['cookies']['credential'],'password':'','profile':HVTOpveGCwQXJgrSInBRoFysUcDNfj(user_pf),'pushid':'','type':'credential'}
    HVTOpveGCwQXJgrSInBRoFysUcDNim =HVTOpveGCwQXJgrSInBRoFysUcDNiK.GetDefaultParams(login=HVTOpveGCwQXJgrSInBRoFysUcDNfx) 
    HVTOpveGCwQXJgrSInBRoFysUcDNkK=HVTOpveGCwQXJgrSInBRoFysUcDNiK.callRequestCookies('Post',HVTOpveGCwQXJgrSInBRoFysUcDNia,payload=HVTOpveGCwQXJgrSInBRoFysUcDNki,params=HVTOpveGCwQXJgrSInBRoFysUcDNim,headers=HVTOpveGCwQXJgrSInBRoFysUcDNfE,cookies=HVTOpveGCwQXJgrSInBRoFysUcDNfE)
    HVTOpveGCwQXJgrSInBRoFysUcDNkq=json.loads(HVTOpveGCwQXJgrSInBRoFysUcDNkK.text)
    HVTOpveGCwQXJgrSInBRoFysUcDNiK.WV['cookies']['credential']=HVTOpveGCwQXJgrSInBRoFysUcDNkq['credential']
   HVTOpveGCwQXJgrSInBRoFysUcDNkY=user_id+HVTOpveGCwQXJgrSInBRoFysUcDNfj(user_pf) 
   HVTOpveGCwQXJgrSInBRoFysUcDNiK.WV['cookies']['uuid']=HVTOpveGCwQXJgrSInBRoFysUcDNiK.GetGUID(guid_str=HVTOpveGCwQXJgrSInBRoFysUcDNkY,guidType=3)
   HVTOpveGCwQXJgrSInBRoFysUcDNiP=HVTOpveGCwQXJgrSInBRoFysUcDNfx
  except HVTOpveGCwQXJgrSInBRoFysUcDNfh as exception:
   HVTOpveGCwQXJgrSInBRoFysUcDNft(exception)
   HVTOpveGCwQXJgrSInBRoFysUcDNiK.Init_WV_Total()
  return HVTOpveGCwQXJgrSInBRoFysUcDNiP
 def GetIssue(HVTOpveGCwQXJgrSInBRoFysUcDNiK):
  HVTOpveGCwQXJgrSInBRoFysUcDNkf=HVTOpveGCwQXJgrSInBRoFysUcDNfm
  try:
   HVTOpveGCwQXJgrSInBRoFysUcDNia=HVTOpveGCwQXJgrSInBRoFysUcDNiK.API_DOMAIN+'/guid/issue'
   HVTOpveGCwQXJgrSInBRoFysUcDNim=HVTOpveGCwQXJgrSInBRoFysUcDNiK.GetDefaultParams()
   HVTOpveGCwQXJgrSInBRoFysUcDNkK=HVTOpveGCwQXJgrSInBRoFysUcDNiK.callRequestCookies('Get',HVTOpveGCwQXJgrSInBRoFysUcDNia,payload=HVTOpveGCwQXJgrSInBRoFysUcDNfE,params=HVTOpveGCwQXJgrSInBRoFysUcDNim,headers=HVTOpveGCwQXJgrSInBRoFysUcDNfE,cookies=HVTOpveGCwQXJgrSInBRoFysUcDNfE)
   HVTOpveGCwQXJgrSInBRoFysUcDNkq=json.loads(HVTOpveGCwQXJgrSInBRoFysUcDNkK.text)
   HVTOpveGCwQXJgrSInBRoFysUcDNkd=HVTOpveGCwQXJgrSInBRoFysUcDNkq['guid']
   HVTOpveGCwQXJgrSInBRoFysUcDNkA=HVTOpveGCwQXJgrSInBRoFysUcDNkq['guidtimestamp']
   if HVTOpveGCwQXJgrSInBRoFysUcDNkd:HVTOpveGCwQXJgrSInBRoFysUcDNkf=HVTOpveGCwQXJgrSInBRoFysUcDNfx
  except HVTOpveGCwQXJgrSInBRoFysUcDNfh as exception:
   HVTOpveGCwQXJgrSInBRoFysUcDNft(exception)
   HVTOpveGCwQXJgrSInBRoFysUcDNkd='none'
   HVTOpveGCwQXJgrSInBRoFysUcDNkA='none' 
  HVTOpveGCwQXJgrSInBRoFysUcDNiK.guid=HVTOpveGCwQXJgrSInBRoFysUcDNkd
  HVTOpveGCwQXJgrSInBRoFysUcDNiK.guidtimestamp=HVTOpveGCwQXJgrSInBRoFysUcDNkA
  return HVTOpveGCwQXJgrSInBRoFysUcDNkf
 def Baseapi_Parse(HVTOpveGCwQXJgrSInBRoFysUcDNiK,HVTOpveGCwQXJgrSInBRoFysUcDNkm):
  try:
   HVTOpveGCwQXJgrSInBRoFysUcDNkl =urllib.parse.urlsplit(HVTOpveGCwQXJgrSInBRoFysUcDNkm)
   if HVTOpveGCwQXJgrSInBRoFysUcDNkl.netloc=='':
    HVTOpveGCwQXJgrSInBRoFysUcDNia=HVTOpveGCwQXJgrSInBRoFysUcDNiK.HTTPTAG+HVTOpveGCwQXJgrSInBRoFysUcDNkl.netloc+HVTOpveGCwQXJgrSInBRoFysUcDNkl.path
   else:
    HVTOpveGCwQXJgrSInBRoFysUcDNia=HVTOpveGCwQXJgrSInBRoFysUcDNkl.scheme+'://'+HVTOpveGCwQXJgrSInBRoFysUcDNkl.netloc+HVTOpveGCwQXJgrSInBRoFysUcDNkl.path
   HVTOpveGCwQXJgrSInBRoFysUcDNim=HVTOpveGCwQXJgrSInBRoFysUcDNfL(urllib.parse.parse_qsl(HVTOpveGCwQXJgrSInBRoFysUcDNkl.query))
  except HVTOpveGCwQXJgrSInBRoFysUcDNfh as exception:
   HVTOpveGCwQXJgrSInBRoFysUcDNft(exception)
   return '',{}
  return HVTOpveGCwQXJgrSInBRoFysUcDNia,HVTOpveGCwQXJgrSInBRoFysUcDNim
 def GetSupermultiUrl(HVTOpveGCwQXJgrSInBRoFysUcDNiK,sCode,sIndex='0'):
  try:
   HVTOpveGCwQXJgrSInBRoFysUcDNia=HVTOpveGCwQXJgrSInBRoFysUcDNiK.API_DOMAIN+'/cf/supermultisections/'+sCode
   HVTOpveGCwQXJgrSInBRoFysUcDNim=HVTOpveGCwQXJgrSInBRoFysUcDNiK.GetDefaultParams(login=HVTOpveGCwQXJgrSInBRoFysUcDNfm)
   HVTOpveGCwQXJgrSInBRoFysUcDNkK=HVTOpveGCwQXJgrSInBRoFysUcDNiK.callRequestCookies('Get',HVTOpveGCwQXJgrSInBRoFysUcDNia,payload=HVTOpveGCwQXJgrSInBRoFysUcDNfE,params=HVTOpveGCwQXJgrSInBRoFysUcDNim,headers=HVTOpveGCwQXJgrSInBRoFysUcDNfE,cookies=HVTOpveGCwQXJgrSInBRoFysUcDNfE)
   HVTOpveGCwQXJgrSInBRoFysUcDNkq=json.loads(HVTOpveGCwQXJgrSInBRoFysUcDNkK.text)
   HVTOpveGCwQXJgrSInBRoFysUcDNkb=HVTOpveGCwQXJgrSInBRoFysUcDNkq['multisectionlist'][HVTOpveGCwQXJgrSInBRoFysUcDNfu(sIndex)]['eventlist'][1]['url']
  except HVTOpveGCwQXJgrSInBRoFysUcDNfh as exception:
   HVTOpveGCwQXJgrSInBRoFysUcDNft(exception)
   return ''
  return HVTOpveGCwQXJgrSInBRoFysUcDNkb
 def Get_LiveCatagory_List(HVTOpveGCwQXJgrSInBRoFysUcDNiK,sCode,sIndex='0'):
  HVTOpveGCwQXJgrSInBRoFysUcDNkE=[]
  HVTOpveGCwQXJgrSInBRoFysUcDNkm =HVTOpveGCwQXJgrSInBRoFysUcDNiK.GetSupermultiUrl(sCode,sIndex)
  (HVTOpveGCwQXJgrSInBRoFysUcDNia,HVTOpveGCwQXJgrSInBRoFysUcDNim)=HVTOpveGCwQXJgrSInBRoFysUcDNiK.Baseapi_Parse(HVTOpveGCwQXJgrSInBRoFysUcDNkm)
  if HVTOpveGCwQXJgrSInBRoFysUcDNia=='':return HVTOpveGCwQXJgrSInBRoFysUcDNkE,''
  try:
   HVTOpveGCwQXJgrSInBRoFysUcDNim.update(HVTOpveGCwQXJgrSInBRoFysUcDNiK.GetDefaultParams(login=HVTOpveGCwQXJgrSInBRoFysUcDNfm))
   HVTOpveGCwQXJgrSInBRoFysUcDNkK=HVTOpveGCwQXJgrSInBRoFysUcDNiK.callRequestCookies('Get',HVTOpveGCwQXJgrSInBRoFysUcDNia,payload=HVTOpveGCwQXJgrSInBRoFysUcDNfE,params=HVTOpveGCwQXJgrSInBRoFysUcDNim,headers=HVTOpveGCwQXJgrSInBRoFysUcDNfE,cookies=HVTOpveGCwQXJgrSInBRoFysUcDNfE)
   HVTOpveGCwQXJgrSInBRoFysUcDNkq=json.loads(HVTOpveGCwQXJgrSInBRoFysUcDNkK.text)
   if not('filter_item_list' in HVTOpveGCwQXJgrSInBRoFysUcDNkq['filter']['filterlist'][0]):return[],''
   HVTOpveGCwQXJgrSInBRoFysUcDNkx=HVTOpveGCwQXJgrSInBRoFysUcDNkq['filter']['filterlist'][0]['filter_item_list']
   for HVTOpveGCwQXJgrSInBRoFysUcDNkW in HVTOpveGCwQXJgrSInBRoFysUcDNkx:
    HVTOpveGCwQXJgrSInBRoFysUcDNkj={'title':HVTOpveGCwQXJgrSInBRoFysUcDNkW['title'],'genre':HVTOpveGCwQXJgrSInBRoFysUcDNkW['api_parameters'][HVTOpveGCwQXJgrSInBRoFysUcDNkW['api_parameters'].index('=')+1:]}
    HVTOpveGCwQXJgrSInBRoFysUcDNkE.append(HVTOpveGCwQXJgrSInBRoFysUcDNkj)
  except HVTOpveGCwQXJgrSInBRoFysUcDNfh as exception:
   HVTOpveGCwQXJgrSInBRoFysUcDNft(exception)
   return[],''
  return HVTOpveGCwQXJgrSInBRoFysUcDNkE,HVTOpveGCwQXJgrSInBRoFysUcDNkm
 def Get_MainCatagory_List(HVTOpveGCwQXJgrSInBRoFysUcDNiK,sCode,sIndex,sType):
  HVTOpveGCwQXJgrSInBRoFysUcDNkE=[]
  HVTOpveGCwQXJgrSInBRoFysUcDNia='https://apis.wavve.com/es/category/launcher-band'
  HVTOpveGCwQXJgrSInBRoFysUcDNim={'uitype':sCode,'uiparent':'GN52-'+sCode,'uirank':sIndex,'broadcastid':sCode,'offset':'0','limit':'20','uicode':sCode,'mtype':'N','ctype':sType,'orderby':'default',}
  try:
   HVTOpveGCwQXJgrSInBRoFysUcDNim.update(HVTOpveGCwQXJgrSInBRoFysUcDNiK.GetDefaultParams(login=HVTOpveGCwQXJgrSInBRoFysUcDNfm))
   HVTOpveGCwQXJgrSInBRoFysUcDNkK=HVTOpveGCwQXJgrSInBRoFysUcDNiK.callRequestCookies('Get',HVTOpveGCwQXJgrSInBRoFysUcDNia,payload=HVTOpveGCwQXJgrSInBRoFysUcDNfE,params=HVTOpveGCwQXJgrSInBRoFysUcDNim,headers=HVTOpveGCwQXJgrSInBRoFysUcDNfE,cookies=HVTOpveGCwQXJgrSInBRoFysUcDNfE)
   HVTOpveGCwQXJgrSInBRoFysUcDNkq=json.loads(HVTOpveGCwQXJgrSInBRoFysUcDNkK.text)
   if not('celllist' in HVTOpveGCwQXJgrSInBRoFysUcDNkq['band']):return[]
   HVTOpveGCwQXJgrSInBRoFysUcDNkx=HVTOpveGCwQXJgrSInBRoFysUcDNkq['band']['celllist']
   for HVTOpveGCwQXJgrSInBRoFysUcDNkW in HVTOpveGCwQXJgrSInBRoFysUcDNkx:
    HVTOpveGCwQXJgrSInBRoFysUcDNkh =HVTOpveGCwQXJgrSInBRoFysUcDNkW['event_list'][1]['url']
    (HVTOpveGCwQXJgrSInBRoFysUcDNkt,HVTOpveGCwQXJgrSInBRoFysUcDNkL)=HVTOpveGCwQXJgrSInBRoFysUcDNiK.Baseapi_Parse(HVTOpveGCwQXJgrSInBRoFysUcDNkh)
    HVTOpveGCwQXJgrSInBRoFysUcDNkj={'title':HVTOpveGCwQXJgrSInBRoFysUcDNkW['title_list'][0]['text'],'suburl':HVTOpveGCwQXJgrSInBRoFysUcDNkt,'subapi':HVTOpveGCwQXJgrSInBRoFysUcDNkL.get('api'),'subtype':'catagory' if HVTOpveGCwQXJgrSInBRoFysUcDNkL else 'supersection'}
    HVTOpveGCwQXJgrSInBRoFysUcDNkE.append(HVTOpveGCwQXJgrSInBRoFysUcDNkj)
  except HVTOpveGCwQXJgrSInBRoFysUcDNfh as exception:
   HVTOpveGCwQXJgrSInBRoFysUcDNft(exception)
   return[]
  return HVTOpveGCwQXJgrSInBRoFysUcDNkE
 def Get_SuperMultiSection_List(HVTOpveGCwQXJgrSInBRoFysUcDNiK,subapi_text):
  HVTOpveGCwQXJgrSInBRoFysUcDNkE=[]
  if '/multiband/' in subapi_text: 
   HVTOpveGCwQXJgrSInBRoFysUcDNia=subapi_text 
   HVTOpveGCwQXJgrSInBRoFysUcDNim={'client':'40'}
  else:
   HVTOpveGCwQXJgrSInBRoFysUcDNia=subapi_text 
   HVTOpveGCwQXJgrSInBRoFysUcDNia=HVTOpveGCwQXJgrSInBRoFysUcDNia.replace('www.wavve.com','apis.wavve.com').replace('supermultisection','v1/multiband')
   HVTOpveGCwQXJgrSInBRoFysUcDNim={}
  try:
   HVTOpveGCwQXJgrSInBRoFysUcDNim.update(HVTOpveGCwQXJgrSInBRoFysUcDNiK.GetDefaultParams(login=HVTOpveGCwQXJgrSInBRoFysUcDNfm))
   HVTOpveGCwQXJgrSInBRoFysUcDNkK=HVTOpveGCwQXJgrSInBRoFysUcDNiK.callRequestCookies('Get',HVTOpveGCwQXJgrSInBRoFysUcDNia,payload=HVTOpveGCwQXJgrSInBRoFysUcDNfE,params=HVTOpveGCwQXJgrSInBRoFysUcDNim,headers=HVTOpveGCwQXJgrSInBRoFysUcDNfE,cookies=HVTOpveGCwQXJgrSInBRoFysUcDNfE)
   HVTOpveGCwQXJgrSInBRoFysUcDNkq=json.loads(HVTOpveGCwQXJgrSInBRoFysUcDNkK.text)
   if not('multisectionlist' in HVTOpveGCwQXJgrSInBRoFysUcDNkq):return[]
   HVTOpveGCwQXJgrSInBRoFysUcDNkx=HVTOpveGCwQXJgrSInBRoFysUcDNkq['multisectionlist']
   for HVTOpveGCwQXJgrSInBRoFysUcDNkW in HVTOpveGCwQXJgrSInBRoFysUcDNkx:
    HVTOpveGCwQXJgrSInBRoFysUcDNku=HVTOpveGCwQXJgrSInBRoFysUcDNkW['title']
    if HVTOpveGCwQXJgrSInBRoFysUcDNfM(HVTOpveGCwQXJgrSInBRoFysUcDNku)==0:continue
    if HVTOpveGCwQXJgrSInBRoFysUcDNku=='minor':continue
    if re.search(u'베너',HVTOpveGCwQXJgrSInBRoFysUcDNku):continue
    if re.search(u'배너',HVTOpveGCwQXJgrSInBRoFysUcDNku):continue 
    if HVTOpveGCwQXJgrSInBRoFysUcDNkW['force_refresh']=='y':continue
    if HVTOpveGCwQXJgrSInBRoFysUcDNfM(HVTOpveGCwQXJgrSInBRoFysUcDNkW['eventlist'])>=3:
     HVTOpveGCwQXJgrSInBRoFysUcDNkL =HVTOpveGCwQXJgrSInBRoFysUcDNkW['eventlist'][2]['url']
    else:
     HVTOpveGCwQXJgrSInBRoFysUcDNkL =HVTOpveGCwQXJgrSInBRoFysUcDNkW['eventlist'][1]['url']
    HVTOpveGCwQXJgrSInBRoFysUcDNkM=HVTOpveGCwQXJgrSInBRoFysUcDNkW['cell_type']
    if HVTOpveGCwQXJgrSInBRoFysUcDNkM=='band_2':
     if HVTOpveGCwQXJgrSInBRoFysUcDNkL.find('channellist=')>=0:
      HVTOpveGCwQXJgrSInBRoFysUcDNkM='band_live'
    HVTOpveGCwQXJgrSInBRoFysUcDNkj={'title':HVTOpveGCwQXJgrSInBRoFysUcDNiK.Get_ChangeText(HVTOpveGCwQXJgrSInBRoFysUcDNku),'subapi':HVTOpveGCwQXJgrSInBRoFysUcDNkL,'cell_type':HVTOpveGCwQXJgrSInBRoFysUcDNkM}
    HVTOpveGCwQXJgrSInBRoFysUcDNkE.append(HVTOpveGCwQXJgrSInBRoFysUcDNkj)
  except HVTOpveGCwQXJgrSInBRoFysUcDNfh as exception:
   HVTOpveGCwQXJgrSInBRoFysUcDNft(exception)
   return[]
  return HVTOpveGCwQXJgrSInBRoFysUcDNkE
 def Get_BandLiveSection_List(HVTOpveGCwQXJgrSInBRoFysUcDNiK,HVTOpveGCwQXJgrSInBRoFysUcDNkm,page_int=1):
  HVTOpveGCwQXJgrSInBRoFysUcDNkP=[]
  HVTOpveGCwQXJgrSInBRoFysUcDNka=HVTOpveGCwQXJgrSInBRoFysUcDNKd=1
  HVTOpveGCwQXJgrSInBRoFysUcDNKi=HVTOpveGCwQXJgrSInBRoFysUcDNfm
  try:
   (HVTOpveGCwQXJgrSInBRoFysUcDNia,HVTOpveGCwQXJgrSInBRoFysUcDNim)=HVTOpveGCwQXJgrSInBRoFysUcDNiK.Baseapi_Parse(HVTOpveGCwQXJgrSInBRoFysUcDNkm)
  except HVTOpveGCwQXJgrSInBRoFysUcDNfh as exception:
   HVTOpveGCwQXJgrSInBRoFysUcDNft(exception)
   return[],HVTOpveGCwQXJgrSInBRoFysUcDNfm
  try:
   HVTOpveGCwQXJgrSInBRoFysUcDNim['limit']=HVTOpveGCwQXJgrSInBRoFysUcDNiK.LIST_LIMIT
   HVTOpveGCwQXJgrSInBRoFysUcDNim['offset']=HVTOpveGCwQXJgrSInBRoFysUcDNfj((page_int-1)*HVTOpveGCwQXJgrSInBRoFysUcDNiK.LIST_LIMIT)
   HVTOpveGCwQXJgrSInBRoFysUcDNim.update(HVTOpveGCwQXJgrSInBRoFysUcDNiK.GetDefaultParams(login=HVTOpveGCwQXJgrSInBRoFysUcDNfm))
   HVTOpveGCwQXJgrSInBRoFysUcDNkK=HVTOpveGCwQXJgrSInBRoFysUcDNiK.callRequestCookies('Get',HVTOpveGCwQXJgrSInBRoFysUcDNia,payload=HVTOpveGCwQXJgrSInBRoFysUcDNfE,params=HVTOpveGCwQXJgrSInBRoFysUcDNim,headers=HVTOpveGCwQXJgrSInBRoFysUcDNfE,cookies=HVTOpveGCwQXJgrSInBRoFysUcDNfE)
   HVTOpveGCwQXJgrSInBRoFysUcDNkq=json.loads(HVTOpveGCwQXJgrSInBRoFysUcDNkK.text)
   if not('celllist' in HVTOpveGCwQXJgrSInBRoFysUcDNkq['cell_toplist']):return[],HVTOpveGCwQXJgrSInBRoFysUcDNfm
   HVTOpveGCwQXJgrSInBRoFysUcDNkx=HVTOpveGCwQXJgrSInBRoFysUcDNkq['cell_toplist']['celllist']
   for HVTOpveGCwQXJgrSInBRoFysUcDNkW in HVTOpveGCwQXJgrSInBRoFysUcDNkx:
    HVTOpveGCwQXJgrSInBRoFysUcDNKk =HVTOpveGCwQXJgrSInBRoFysUcDNkW['event_list'][1]['url']
    HVTOpveGCwQXJgrSInBRoFysUcDNKq=urllib.parse.urlsplit(HVTOpveGCwQXJgrSInBRoFysUcDNKk).query
    HVTOpveGCwQXJgrSInBRoFysUcDNKq=HVTOpveGCwQXJgrSInBRoFysUcDNfL(urllib.parse.parse_qsl(HVTOpveGCwQXJgrSInBRoFysUcDNKq))
    HVTOpveGCwQXJgrSInBRoFysUcDNKY='channelid'
    HVTOpveGCwQXJgrSInBRoFysUcDNKf=HVTOpveGCwQXJgrSInBRoFysUcDNKq[HVTOpveGCwQXJgrSInBRoFysUcDNKY]
    HVTOpveGCwQXJgrSInBRoFysUcDNkj={'studio':HVTOpveGCwQXJgrSInBRoFysUcDNkW['title_list'][0]['text'],'tvshowtitle':HVTOpveGCwQXJgrSInBRoFysUcDNiK.Get_ChangeText(HVTOpveGCwQXJgrSInBRoFysUcDNkW['title_list'][1]['text']),'channelid':HVTOpveGCwQXJgrSInBRoFysUcDNKf,'age':HVTOpveGCwQXJgrSInBRoFysUcDNkW.get('age'),'thumbnail':'https://%s'%HVTOpveGCwQXJgrSInBRoFysUcDNkW.get('thumbnail')}
    HVTOpveGCwQXJgrSInBRoFysUcDNkP.append(HVTOpveGCwQXJgrSInBRoFysUcDNkj)
   HVTOpveGCwQXJgrSInBRoFysUcDNka=HVTOpveGCwQXJgrSInBRoFysUcDNfu(HVTOpveGCwQXJgrSInBRoFysUcDNkq['cell_toplist']['pagecount'])
   if HVTOpveGCwQXJgrSInBRoFysUcDNkq['cell_toplist']['count']:HVTOpveGCwQXJgrSInBRoFysUcDNKd =HVTOpveGCwQXJgrSInBRoFysUcDNfu(HVTOpveGCwQXJgrSInBRoFysUcDNkq['cell_toplist']['count'])
   else:HVTOpveGCwQXJgrSInBRoFysUcDNKd=HVTOpveGCwQXJgrSInBRoFysUcDNiK.LIST_LIMIT*page_int
   HVTOpveGCwQXJgrSInBRoFysUcDNKi=HVTOpveGCwQXJgrSInBRoFysUcDNka>HVTOpveGCwQXJgrSInBRoFysUcDNKd
  except HVTOpveGCwQXJgrSInBRoFysUcDNfh as exception:
   HVTOpveGCwQXJgrSInBRoFysUcDNft(exception)
   return[],HVTOpveGCwQXJgrSInBRoFysUcDNfm
  return HVTOpveGCwQXJgrSInBRoFysUcDNkP,HVTOpveGCwQXJgrSInBRoFysUcDNKi
 def Get_Band2Section_List(HVTOpveGCwQXJgrSInBRoFysUcDNiK,HVTOpveGCwQXJgrSInBRoFysUcDNkm,page_int=1):
  HVTOpveGCwQXJgrSInBRoFysUcDNKA=[]
  HVTOpveGCwQXJgrSInBRoFysUcDNka=HVTOpveGCwQXJgrSInBRoFysUcDNKd=1
  HVTOpveGCwQXJgrSInBRoFysUcDNKi=HVTOpveGCwQXJgrSInBRoFysUcDNfm
  try:
   (HVTOpveGCwQXJgrSInBRoFysUcDNia,HVTOpveGCwQXJgrSInBRoFysUcDNim)=HVTOpveGCwQXJgrSInBRoFysUcDNiK.Baseapi_Parse(HVTOpveGCwQXJgrSInBRoFysUcDNkm)
  except HVTOpveGCwQXJgrSInBRoFysUcDNfh as exception:
   HVTOpveGCwQXJgrSInBRoFysUcDNft(exception)
   return[],HVTOpveGCwQXJgrSInBRoFysUcDNfm
  try:
   HVTOpveGCwQXJgrSInBRoFysUcDNim['came'] ='BandView'
   HVTOpveGCwQXJgrSInBRoFysUcDNim['limit']=HVTOpveGCwQXJgrSInBRoFysUcDNiK.LIST_LIMIT
   HVTOpveGCwQXJgrSInBRoFysUcDNim['offset']=HVTOpveGCwQXJgrSInBRoFysUcDNfj((page_int-1)*HVTOpveGCwQXJgrSInBRoFysUcDNiK.LIST_LIMIT)
   HVTOpveGCwQXJgrSInBRoFysUcDNim.update(HVTOpveGCwQXJgrSInBRoFysUcDNiK.GetDefaultParams(login=HVTOpveGCwQXJgrSInBRoFysUcDNfm))
   HVTOpveGCwQXJgrSInBRoFysUcDNkK=HVTOpveGCwQXJgrSInBRoFysUcDNiK.callRequestCookies('Get',HVTOpveGCwQXJgrSInBRoFysUcDNia,payload=HVTOpveGCwQXJgrSInBRoFysUcDNfE,params=HVTOpveGCwQXJgrSInBRoFysUcDNim,headers=HVTOpveGCwQXJgrSInBRoFysUcDNfE,cookies=HVTOpveGCwQXJgrSInBRoFysUcDNfE)
   HVTOpveGCwQXJgrSInBRoFysUcDNkq=json.loads(HVTOpveGCwQXJgrSInBRoFysUcDNkK.text)
   if not('celllist' in HVTOpveGCwQXJgrSInBRoFysUcDNkq['cell_toplist']):return[],HVTOpveGCwQXJgrSInBRoFysUcDNfm
   HVTOpveGCwQXJgrSInBRoFysUcDNkx=HVTOpveGCwQXJgrSInBRoFysUcDNkq['cell_toplist']['celllist']
   for HVTOpveGCwQXJgrSInBRoFysUcDNkW in HVTOpveGCwQXJgrSInBRoFysUcDNkx:
    HVTOpveGCwQXJgrSInBRoFysUcDNKk =HVTOpveGCwQXJgrSInBRoFysUcDNkW['event_list'][1]['url']
    HVTOpveGCwQXJgrSInBRoFysUcDNKq=urllib.parse.urlsplit(HVTOpveGCwQXJgrSInBRoFysUcDNKk).query
    HVTOpveGCwQXJgrSInBRoFysUcDNKq=HVTOpveGCwQXJgrSInBRoFysUcDNfL(urllib.parse.parse_qsl(HVTOpveGCwQXJgrSInBRoFysUcDNKq))
    HVTOpveGCwQXJgrSInBRoFysUcDNKY='contentid'
    HVTOpveGCwQXJgrSInBRoFysUcDNKf=HVTOpveGCwQXJgrSInBRoFysUcDNKq[HVTOpveGCwQXJgrSInBRoFysUcDNKY]
    HVTOpveGCwQXJgrSInBRoFysUcDNkj={'programtitle':HVTOpveGCwQXJgrSInBRoFysUcDNkW['title_list'][0]['text'],'episodetitle':HVTOpveGCwQXJgrSInBRoFysUcDNiK.Get_ChangeText(HVTOpveGCwQXJgrSInBRoFysUcDNkW['title_list'][1]['text']),'age':HVTOpveGCwQXJgrSInBRoFysUcDNkW.get('age'),'thumbnail':HVTOpveGCwQXJgrSInBRoFysUcDNiK.HTTPTAG+HVTOpveGCwQXJgrSInBRoFysUcDNkW.get('thumbnail'),'vidtype':HVTOpveGCwQXJgrSInBRoFysUcDNKY,'videoid':HVTOpveGCwQXJgrSInBRoFysUcDNKf}
    HVTOpveGCwQXJgrSInBRoFysUcDNKA.append(HVTOpveGCwQXJgrSInBRoFysUcDNkj)
   HVTOpveGCwQXJgrSInBRoFysUcDNka=HVTOpveGCwQXJgrSInBRoFysUcDNfu(HVTOpveGCwQXJgrSInBRoFysUcDNkq['cell_toplist']['pagecount'])
   if HVTOpveGCwQXJgrSInBRoFysUcDNkq['cell_toplist']['count']:HVTOpveGCwQXJgrSInBRoFysUcDNKd =HVTOpveGCwQXJgrSInBRoFysUcDNfu(HVTOpveGCwQXJgrSInBRoFysUcDNkq['cell_toplist']['count'])
   else:HVTOpveGCwQXJgrSInBRoFysUcDNKd=HVTOpveGCwQXJgrSInBRoFysUcDNiK.LIST_LIMIT*page_int
   HVTOpveGCwQXJgrSInBRoFysUcDNKi=HVTOpveGCwQXJgrSInBRoFysUcDNka>HVTOpveGCwQXJgrSInBRoFysUcDNKd
  except HVTOpveGCwQXJgrSInBRoFysUcDNfh as exception:
   HVTOpveGCwQXJgrSInBRoFysUcDNft(exception)
   return[],HVTOpveGCwQXJgrSInBRoFysUcDNfm
  return HVTOpveGCwQXJgrSInBRoFysUcDNKA,HVTOpveGCwQXJgrSInBRoFysUcDNKi
 def Get_Program_List(HVTOpveGCwQXJgrSInBRoFysUcDNiK,HVTOpveGCwQXJgrSInBRoFysUcDNkm,page_int=1,orderby='-'):
  HVTOpveGCwQXJgrSInBRoFysUcDNKl=[]
  HVTOpveGCwQXJgrSInBRoFysUcDNka=HVTOpveGCwQXJgrSInBRoFysUcDNKd=1
  HVTOpveGCwQXJgrSInBRoFysUcDNKi=HVTOpveGCwQXJgrSInBRoFysUcDNfm
  (HVTOpveGCwQXJgrSInBRoFysUcDNia,HVTOpveGCwQXJgrSInBRoFysUcDNim)=HVTOpveGCwQXJgrSInBRoFysUcDNiK.Baseapi_Parse(HVTOpveGCwQXJgrSInBRoFysUcDNkm)
  if HVTOpveGCwQXJgrSInBRoFysUcDNia=='':return HVTOpveGCwQXJgrSInBRoFysUcDNKl,HVTOpveGCwQXJgrSInBRoFysUcDNKi
  try:
   HVTOpveGCwQXJgrSInBRoFysUcDNim['limit'] =HVTOpveGCwQXJgrSInBRoFysUcDNiK.LIST_LIMIT
   HVTOpveGCwQXJgrSInBRoFysUcDNim['offset']=HVTOpveGCwQXJgrSInBRoFysUcDNfj((page_int-1)*HVTOpveGCwQXJgrSInBRoFysUcDNiK.LIST_LIMIT)
   HVTOpveGCwQXJgrSInBRoFysUcDNim['page'] =HVTOpveGCwQXJgrSInBRoFysUcDNfj(page_int)
   if HVTOpveGCwQXJgrSInBRoFysUcDNim.get('orderby')!='' and HVTOpveGCwQXJgrSInBRoFysUcDNim.get('orderby')!='regdatefirst' and orderby!='-':
    HVTOpveGCwQXJgrSInBRoFysUcDNim['orderby']=orderby 
   HVTOpveGCwQXJgrSInBRoFysUcDNim.update(HVTOpveGCwQXJgrSInBRoFysUcDNiK.GetDefaultParams(login=HVTOpveGCwQXJgrSInBRoFysUcDNfm))
   HVTOpveGCwQXJgrSInBRoFysUcDNkK=HVTOpveGCwQXJgrSInBRoFysUcDNiK.callRequestCookies('Get',HVTOpveGCwQXJgrSInBRoFysUcDNia,payload=HVTOpveGCwQXJgrSInBRoFysUcDNfE,params=HVTOpveGCwQXJgrSInBRoFysUcDNim,headers=HVTOpveGCwQXJgrSInBRoFysUcDNfE,cookies=HVTOpveGCwQXJgrSInBRoFysUcDNfE)
   HVTOpveGCwQXJgrSInBRoFysUcDNkq=json.loads(HVTOpveGCwQXJgrSInBRoFysUcDNkK.text)
   if HVTOpveGCwQXJgrSInBRoFysUcDNkq.get('cell_toplist')not in[{},HVTOpveGCwQXJgrSInBRoFysUcDNfE,'']:
    HVTOpveGCwQXJgrSInBRoFysUcDNkx=HVTOpveGCwQXJgrSInBRoFysUcDNkq['cell_toplist']['celllist']
   elif HVTOpveGCwQXJgrSInBRoFysUcDNkq.get('band')not in[{},HVTOpveGCwQXJgrSInBRoFysUcDNfE,'']:
    HVTOpveGCwQXJgrSInBRoFysUcDNkx=HVTOpveGCwQXJgrSInBRoFysUcDNkq['band']['celllist']
   else:
    return HVTOpveGCwQXJgrSInBRoFysUcDNKl,HVTOpveGCwQXJgrSInBRoFysUcDNKi
   for HVTOpveGCwQXJgrSInBRoFysUcDNkW in HVTOpveGCwQXJgrSInBRoFysUcDNkx:
    for HVTOpveGCwQXJgrSInBRoFysUcDNKb in HVTOpveGCwQXJgrSInBRoFysUcDNkW['event_list']:
     if HVTOpveGCwQXJgrSInBRoFysUcDNKb.get('type')=='on-navigation':
      HVTOpveGCwQXJgrSInBRoFysUcDNKk =HVTOpveGCwQXJgrSInBRoFysUcDNKb['url']
    HVTOpveGCwQXJgrSInBRoFysUcDNKq=urllib.parse.urlsplit(HVTOpveGCwQXJgrSInBRoFysUcDNKk).query
    HVTOpveGCwQXJgrSInBRoFysUcDNKY=HVTOpveGCwQXJgrSInBRoFysUcDNKq[0:HVTOpveGCwQXJgrSInBRoFysUcDNKq.find('=')]
    HVTOpveGCwQXJgrSInBRoFysUcDNKE=HVTOpveGCwQXJgrSInBRoFysUcDNfL(urllib.parse.parse_qsl(HVTOpveGCwQXJgrSInBRoFysUcDNKq))
    HVTOpveGCwQXJgrSInBRoFysUcDNKf=HVTOpveGCwQXJgrSInBRoFysUcDNKE.get(HVTOpveGCwQXJgrSInBRoFysUcDNKY)
    HVTOpveGCwQXJgrSInBRoFysUcDNkj={'title':HVTOpveGCwQXJgrSInBRoFysUcDNkW.get('alt')or HVTOpveGCwQXJgrSInBRoFysUcDNkW.get('title_list')[0].get('text'),'age':HVTOpveGCwQXJgrSInBRoFysUcDNkW.get('age'),'thumbnail':HVTOpveGCwQXJgrSInBRoFysUcDNkW.get('thumbnail'),'videoid':HVTOpveGCwQXJgrSInBRoFysUcDNKf,'vidtype':HVTOpveGCwQXJgrSInBRoFysUcDNKY,}
    if not HVTOpveGCwQXJgrSInBRoFysUcDNkj.get('thumbnail').startswith('http'):
     HVTOpveGCwQXJgrSInBRoFysUcDNkj['thumbnail']='https://%s'%HVTOpveGCwQXJgrSInBRoFysUcDNkj['thumbnail']
    HVTOpveGCwQXJgrSInBRoFysUcDNKl.append(HVTOpveGCwQXJgrSInBRoFysUcDNkj)
   if HVTOpveGCwQXJgrSInBRoFysUcDNkq.get('cell_toplist')not in[{},HVTOpveGCwQXJgrSInBRoFysUcDNfE,'']:
    HVTOpveGCwQXJgrSInBRoFysUcDNka=HVTOpveGCwQXJgrSInBRoFysUcDNfu(HVTOpveGCwQXJgrSInBRoFysUcDNkq['cell_toplist']['pagecount'])
    if HVTOpveGCwQXJgrSInBRoFysUcDNkq['cell_toplist']['count']:HVTOpveGCwQXJgrSInBRoFysUcDNKd =HVTOpveGCwQXJgrSInBRoFysUcDNfu(HVTOpveGCwQXJgrSInBRoFysUcDNkq['cell_toplist']['count'])
    else:HVTOpveGCwQXJgrSInBRoFysUcDNKd=HVTOpveGCwQXJgrSInBRoFysUcDNiK.LIST_LIMIT*page_int
    HVTOpveGCwQXJgrSInBRoFysUcDNKi=HVTOpveGCwQXJgrSInBRoFysUcDNka>HVTOpveGCwQXJgrSInBRoFysUcDNKd
  except HVTOpveGCwQXJgrSInBRoFysUcDNfh as exception:
   HVTOpveGCwQXJgrSInBRoFysUcDNft(exception)
   return[],HVTOpveGCwQXJgrSInBRoFysUcDNfm
  return HVTOpveGCwQXJgrSInBRoFysUcDNKl,HVTOpveGCwQXJgrSInBRoFysUcDNKi
 def Get_Movie_List(HVTOpveGCwQXJgrSInBRoFysUcDNiK,HVTOpveGCwQXJgrSInBRoFysUcDNkm,page_int=1,orderby='-'):
  HVTOpveGCwQXJgrSInBRoFysUcDNKm=[]
  HVTOpveGCwQXJgrSInBRoFysUcDNka=HVTOpveGCwQXJgrSInBRoFysUcDNKd=1
  HVTOpveGCwQXJgrSInBRoFysUcDNKi=HVTOpveGCwQXJgrSInBRoFysUcDNfm
  (HVTOpveGCwQXJgrSInBRoFysUcDNia,HVTOpveGCwQXJgrSInBRoFysUcDNim)=HVTOpveGCwQXJgrSInBRoFysUcDNiK.Baseapi_Parse(HVTOpveGCwQXJgrSInBRoFysUcDNkm)
  if HVTOpveGCwQXJgrSInBRoFysUcDNia=='':return HVTOpveGCwQXJgrSInBRoFysUcDNKm,HVTOpveGCwQXJgrSInBRoFysUcDNKi
  try:
   HVTOpveGCwQXJgrSInBRoFysUcDNim['limit']=HVTOpveGCwQXJgrSInBRoFysUcDNiK.MV_LIMIT
   HVTOpveGCwQXJgrSInBRoFysUcDNim['offset']=HVTOpveGCwQXJgrSInBRoFysUcDNfj((page_int-1)*HVTOpveGCwQXJgrSInBRoFysUcDNiK.MV_LIMIT)
   if HVTOpveGCwQXJgrSInBRoFysUcDNim.get('orderby')!='' and HVTOpveGCwQXJgrSInBRoFysUcDNim.get('orderby')!='regdatefirst' and orderby!='-':
    HVTOpveGCwQXJgrSInBRoFysUcDNim['orderby']=orderby 
   HVTOpveGCwQXJgrSInBRoFysUcDNim.update(HVTOpveGCwQXJgrSInBRoFysUcDNiK.GetDefaultParams(login=HVTOpveGCwQXJgrSInBRoFysUcDNfm))
   HVTOpveGCwQXJgrSInBRoFysUcDNkK=HVTOpveGCwQXJgrSInBRoFysUcDNiK.callRequestCookies('Get',HVTOpveGCwQXJgrSInBRoFysUcDNia,payload=HVTOpveGCwQXJgrSInBRoFysUcDNfE,params=HVTOpveGCwQXJgrSInBRoFysUcDNim,headers=HVTOpveGCwQXJgrSInBRoFysUcDNfE,cookies=HVTOpveGCwQXJgrSInBRoFysUcDNfE)
   HVTOpveGCwQXJgrSInBRoFysUcDNkq=json.loads(HVTOpveGCwQXJgrSInBRoFysUcDNkK.text)
   if HVTOpveGCwQXJgrSInBRoFysUcDNkq.get('cell_toplist')not in[{},HVTOpveGCwQXJgrSInBRoFysUcDNfE,'']:
    HVTOpveGCwQXJgrSInBRoFysUcDNkx=HVTOpveGCwQXJgrSInBRoFysUcDNkq['cell_toplist']['celllist']
   elif HVTOpveGCwQXJgrSInBRoFysUcDNkq.get('band')not in[{},HVTOpveGCwQXJgrSInBRoFysUcDNfE,'']:
    HVTOpveGCwQXJgrSInBRoFysUcDNkx=HVTOpveGCwQXJgrSInBRoFysUcDNkq['band']['celllist']
   else:
    return HVTOpveGCwQXJgrSInBRoFysUcDNKm,HVTOpveGCwQXJgrSInBRoFysUcDNKi
   for HVTOpveGCwQXJgrSInBRoFysUcDNkW in HVTOpveGCwQXJgrSInBRoFysUcDNkx:
    HVTOpveGCwQXJgrSInBRoFysUcDNKk =HVTOpveGCwQXJgrSInBRoFysUcDNkW['event_list'][1]['url']
    HVTOpveGCwQXJgrSInBRoFysUcDNKq=urllib.parse.urlsplit(HVTOpveGCwQXJgrSInBRoFysUcDNKk).query
    HVTOpveGCwQXJgrSInBRoFysUcDNKY=HVTOpveGCwQXJgrSInBRoFysUcDNKq[0:HVTOpveGCwQXJgrSInBRoFysUcDNKq.find('=')]
    HVTOpveGCwQXJgrSInBRoFysUcDNKE=HVTOpveGCwQXJgrSInBRoFysUcDNfL(urllib.parse.parse_qsl(HVTOpveGCwQXJgrSInBRoFysUcDNKq))
    HVTOpveGCwQXJgrSInBRoFysUcDNKf=HVTOpveGCwQXJgrSInBRoFysUcDNKE.get(HVTOpveGCwQXJgrSInBRoFysUcDNKY)
    HVTOpveGCwQXJgrSInBRoFysUcDNkj={'title':HVTOpveGCwQXJgrSInBRoFysUcDNkW.get('alt')or HVTOpveGCwQXJgrSInBRoFysUcDNkW.get('title_list')[0].get('text'),'age':HVTOpveGCwQXJgrSInBRoFysUcDNkW.get('age'),'thumbnail':HVTOpveGCwQXJgrSInBRoFysUcDNkW.get('thumbnail'),'videoid':HVTOpveGCwQXJgrSInBRoFysUcDNKf,'vidtype':HVTOpveGCwQXJgrSInBRoFysUcDNKY,}
    if not HVTOpveGCwQXJgrSInBRoFysUcDNkj.get('thumbnail').startswith('http'):
     HVTOpveGCwQXJgrSInBRoFysUcDNkj['thumbnail']='https://%s'%HVTOpveGCwQXJgrSInBRoFysUcDNkj['thumbnail']
    HVTOpveGCwQXJgrSInBRoFysUcDNKm.append(HVTOpveGCwQXJgrSInBRoFysUcDNkj)
   if HVTOpveGCwQXJgrSInBRoFysUcDNkq.get('cell_toplist')not in[{},HVTOpveGCwQXJgrSInBRoFysUcDNfE,'']:
    HVTOpveGCwQXJgrSInBRoFysUcDNka=HVTOpveGCwQXJgrSInBRoFysUcDNfu(HVTOpveGCwQXJgrSInBRoFysUcDNkq['cell_toplist']['pagecount'])
    if HVTOpveGCwQXJgrSInBRoFysUcDNkq['cell_toplist']['count']:HVTOpveGCwQXJgrSInBRoFysUcDNKd =HVTOpveGCwQXJgrSInBRoFysUcDNfu(HVTOpveGCwQXJgrSInBRoFysUcDNkq['cell_toplist']['count'])
    else:HVTOpveGCwQXJgrSInBRoFysUcDNKd=HVTOpveGCwQXJgrSInBRoFysUcDNiK.MV_LIMIT*page_int
    HVTOpveGCwQXJgrSInBRoFysUcDNKi=HVTOpveGCwQXJgrSInBRoFysUcDNka>HVTOpveGCwQXJgrSInBRoFysUcDNKd
  except HVTOpveGCwQXJgrSInBRoFysUcDNfh as exception:
   HVTOpveGCwQXJgrSInBRoFysUcDNft(exception)
   return[],HVTOpveGCwQXJgrSInBRoFysUcDNfm
  return HVTOpveGCwQXJgrSInBRoFysUcDNKm,HVTOpveGCwQXJgrSInBRoFysUcDNKi
 def ProgramidToContentid(HVTOpveGCwQXJgrSInBRoFysUcDNiK,HVTOpveGCwQXJgrSInBRoFysUcDNKW):
  HVTOpveGCwQXJgrSInBRoFysUcDNKz=''
  try:
   HVTOpveGCwQXJgrSInBRoFysUcDNia =HVTOpveGCwQXJgrSInBRoFysUcDNiK.API_DOMAIN+'/vod/programs-contentid/'+HVTOpveGCwQXJgrSInBRoFysUcDNKW
   HVTOpveGCwQXJgrSInBRoFysUcDNim=HVTOpveGCwQXJgrSInBRoFysUcDNiK.GetDefaultParams(login=HVTOpveGCwQXJgrSInBRoFysUcDNfm)
   HVTOpveGCwQXJgrSInBRoFysUcDNkK=HVTOpveGCwQXJgrSInBRoFysUcDNiK.callRequestCookies('Get',HVTOpveGCwQXJgrSInBRoFysUcDNia,payload=HVTOpveGCwQXJgrSInBRoFysUcDNfE,params=HVTOpveGCwQXJgrSInBRoFysUcDNim,headers=HVTOpveGCwQXJgrSInBRoFysUcDNfE,cookies=HVTOpveGCwQXJgrSInBRoFysUcDNfE)
   HVTOpveGCwQXJgrSInBRoFysUcDNKx=json.loads(HVTOpveGCwQXJgrSInBRoFysUcDNkK.text)
   if not('contentid' in HVTOpveGCwQXJgrSInBRoFysUcDNKx):return HVTOpveGCwQXJgrSInBRoFysUcDNKz 
   HVTOpveGCwQXJgrSInBRoFysUcDNKz=HVTOpveGCwQXJgrSInBRoFysUcDNKx['contentid']
  except HVTOpveGCwQXJgrSInBRoFysUcDNfh as exception:
   HVTOpveGCwQXJgrSInBRoFysUcDNft(exception)
  return HVTOpveGCwQXJgrSInBRoFysUcDNKz
 def ContentidToSeasonid(HVTOpveGCwQXJgrSInBRoFysUcDNiK,HVTOpveGCwQXJgrSInBRoFysUcDNKz):
  HVTOpveGCwQXJgrSInBRoFysUcDNKW=''
  try:
   HVTOpveGCwQXJgrSInBRoFysUcDNia =HVTOpveGCwQXJgrSInBRoFysUcDNiK.API_DOMAIN+'/fz/vod/contents/'+HVTOpveGCwQXJgrSInBRoFysUcDNKz
   HVTOpveGCwQXJgrSInBRoFysUcDNim=HVTOpveGCwQXJgrSInBRoFysUcDNiK.GetDefaultParams(login=HVTOpveGCwQXJgrSInBRoFysUcDNfm)
   HVTOpveGCwQXJgrSInBRoFysUcDNkK=HVTOpveGCwQXJgrSInBRoFysUcDNiK.callRequestCookies('Get',HVTOpveGCwQXJgrSInBRoFysUcDNia,payload=HVTOpveGCwQXJgrSInBRoFysUcDNfE,params=HVTOpveGCwQXJgrSInBRoFysUcDNim,headers=HVTOpveGCwQXJgrSInBRoFysUcDNfE,cookies=HVTOpveGCwQXJgrSInBRoFysUcDNfE)
   HVTOpveGCwQXJgrSInBRoFysUcDNKx=json.loads(HVTOpveGCwQXJgrSInBRoFysUcDNkK.text)
   if not('programid' in HVTOpveGCwQXJgrSInBRoFysUcDNKx):return HVTOpveGCwQXJgrSInBRoFysUcDNKW 
   HVTOpveGCwQXJgrSInBRoFysUcDNKW=HVTOpveGCwQXJgrSInBRoFysUcDNKx['programid']
  except HVTOpveGCwQXJgrSInBRoFysUcDNfh as exception:
   HVTOpveGCwQXJgrSInBRoFysUcDNft(exception)
  return HVTOpveGCwQXJgrSInBRoFysUcDNKW
 def GetProgramInfo(HVTOpveGCwQXJgrSInBRoFysUcDNiK,HVTOpveGCwQXJgrSInBRoFysUcDNKz):
  HVTOpveGCwQXJgrSInBRoFysUcDNKj={}
  try:
   HVTOpveGCwQXJgrSInBRoFysUcDNia=HVTOpveGCwQXJgrSInBRoFysUcDNiK.API_DOMAIN+'/fz/vod/contents/'+HVTOpveGCwQXJgrSInBRoFysUcDNKz
   HVTOpveGCwQXJgrSInBRoFysUcDNim=HVTOpveGCwQXJgrSInBRoFysUcDNiK.GetDefaultParams(login=HVTOpveGCwQXJgrSInBRoFysUcDNfm)
   HVTOpveGCwQXJgrSInBRoFysUcDNkK=HVTOpveGCwQXJgrSInBRoFysUcDNiK.callRequestCookies('Get',HVTOpveGCwQXJgrSInBRoFysUcDNia,payload=HVTOpveGCwQXJgrSInBRoFysUcDNfE,params=HVTOpveGCwQXJgrSInBRoFysUcDNim,headers=HVTOpveGCwQXJgrSInBRoFysUcDNfE,cookies=HVTOpveGCwQXJgrSInBRoFysUcDNfE)
   HVTOpveGCwQXJgrSInBRoFysUcDNKx=json.loads(HVTOpveGCwQXJgrSInBRoFysUcDNkK.text)
   HVTOpveGCwQXJgrSInBRoFysUcDNKh=img_fanart=HVTOpveGCwQXJgrSInBRoFysUcDNKt=''
   if HVTOpveGCwQXJgrSInBRoFysUcDNKx.get('programposterimage')!='':HVTOpveGCwQXJgrSInBRoFysUcDNKh =HVTOpveGCwQXJgrSInBRoFysUcDNiK.HTTPTAG+HVTOpveGCwQXJgrSInBRoFysUcDNKx.get('programposterimage')
   if HVTOpveGCwQXJgrSInBRoFysUcDNKx.get('programimage') !='':img_fanart =HVTOpveGCwQXJgrSInBRoFysUcDNiK.HTTPTAG+HVTOpveGCwQXJgrSInBRoFysUcDNKx.get('programimage')
   if HVTOpveGCwQXJgrSInBRoFysUcDNKx.get('programcircleimage')!='':HVTOpveGCwQXJgrSInBRoFysUcDNKt=HVTOpveGCwQXJgrSInBRoFysUcDNiK.HTTPTAG+HVTOpveGCwQXJgrSInBRoFysUcDNKx.get('programcircleimage')
   if 'poster_default' in HVTOpveGCwQXJgrSInBRoFysUcDNKh:
    HVTOpveGCwQXJgrSInBRoFysUcDNKh =img_fanart
    HVTOpveGCwQXJgrSInBRoFysUcDNKt=''
   HVTOpveGCwQXJgrSInBRoFysUcDNKj={'imgPoster':HVTOpveGCwQXJgrSInBRoFysUcDNKh,'imgFanart':img_fanart,'imgClearlogo':HVTOpveGCwQXJgrSInBRoFysUcDNKt,'programtitle':HVTOpveGCwQXJgrSInBRoFysUcDNKx.get('programtitle'),'programid':HVTOpveGCwQXJgrSInBRoFysUcDNKx.get('programid'),'synopsis':HVTOpveGCwQXJgrSInBRoFysUcDNKx.get('programsynopsis').replace('<br>','\n'),}
  except HVTOpveGCwQXJgrSInBRoFysUcDNfh as exception:
   HVTOpveGCwQXJgrSInBRoFysUcDNft(exception)
  return HVTOpveGCwQXJgrSInBRoFysUcDNKj
 def Get_Season_List(HVTOpveGCwQXJgrSInBRoFysUcDNiK,seasonid):
  HVTOpveGCwQXJgrSInBRoFysUcDNKL=[]
  HVTOpveGCwQXJgrSInBRoFysUcDNKz=HVTOpveGCwQXJgrSInBRoFysUcDNiK.ProgramidToContentid(seasonid)
  HVTOpveGCwQXJgrSInBRoFysUcDNKu=HVTOpveGCwQXJgrSInBRoFysUcDNiK.GetProgramInfo(HVTOpveGCwQXJgrSInBRoFysUcDNKz)
  HVTOpveGCwQXJgrSInBRoFysUcDNKM={'poster':HVTOpveGCwQXJgrSInBRoFysUcDNKu.get('imgPoster'),'fanart':HVTOpveGCwQXJgrSInBRoFysUcDNKu.get('imgFanart'),'clearlogo':HVTOpveGCwQXJgrSInBRoFysUcDNKu.get('imgClearlogo'),}
  try:
   HVTOpveGCwQXJgrSInBRoFysUcDNia=HVTOpveGCwQXJgrSInBRoFysUcDNiK.API_DOMAIN+'/fz/vod/programs-contents/'+seasonid
   HVTOpveGCwQXJgrSInBRoFysUcDNim={'limit':'10','offset':'0','orderby':'new',}
   HVTOpveGCwQXJgrSInBRoFysUcDNim.update(HVTOpveGCwQXJgrSInBRoFysUcDNiK.GetDefaultParams(login=HVTOpveGCwQXJgrSInBRoFysUcDNfm))
   HVTOpveGCwQXJgrSInBRoFysUcDNkK=HVTOpveGCwQXJgrSInBRoFysUcDNiK.callRequestCookies('Get',HVTOpveGCwQXJgrSInBRoFysUcDNia,payload=HVTOpveGCwQXJgrSInBRoFysUcDNfE,params=HVTOpveGCwQXJgrSInBRoFysUcDNim,headers=HVTOpveGCwQXJgrSInBRoFysUcDNfE,cookies=HVTOpveGCwQXJgrSInBRoFysUcDNfE)
   HVTOpveGCwQXJgrSInBRoFysUcDNkq=json.loads(HVTOpveGCwQXJgrSInBRoFysUcDNkK.text)
   for HVTOpveGCwQXJgrSInBRoFysUcDNKP in HVTOpveGCwQXJgrSInBRoFysUcDNkq['filter']['filterlist'][0]['filter_item_list']:
    HVTOpveGCwQXJgrSInBRoFysUcDNkj={'season_Nm':HVTOpveGCwQXJgrSInBRoFysUcDNKP.get('title'),'season_Id':HVTOpveGCwQXJgrSInBRoFysUcDNKP.get('api_path'),'thumbnail':HVTOpveGCwQXJgrSInBRoFysUcDNKM,'programNm':HVTOpveGCwQXJgrSInBRoFysUcDNKu.get('programtitle'),'synopsis':HVTOpveGCwQXJgrSInBRoFysUcDNKu.get('synopsis'),}
    HVTOpveGCwQXJgrSInBRoFysUcDNKL.append(HVTOpveGCwQXJgrSInBRoFysUcDNkj)
  except HVTOpveGCwQXJgrSInBRoFysUcDNfh as exception:
   HVTOpveGCwQXJgrSInBRoFysUcDNft(exception)
   return[]
  return HVTOpveGCwQXJgrSInBRoFysUcDNKL
 def Get_Episode_List(HVTOpveGCwQXJgrSInBRoFysUcDNiK,seasionid,page_int=1,orderby='desc'):
  HVTOpveGCwQXJgrSInBRoFysUcDNKa=[]
  HVTOpveGCwQXJgrSInBRoFysUcDNka=HVTOpveGCwQXJgrSInBRoFysUcDNKd=1
  HVTOpveGCwQXJgrSInBRoFysUcDNKi=HVTOpveGCwQXJgrSInBRoFysUcDNfm
  HVTOpveGCwQXJgrSInBRoFysUcDNKu={}
  HVTOpveGCwQXJgrSInBRoFysUcDNKz=HVTOpveGCwQXJgrSInBRoFysUcDNiK.ProgramidToContentid(seasionid)
  HVTOpveGCwQXJgrSInBRoFysUcDNKu=HVTOpveGCwQXJgrSInBRoFysUcDNiK.GetProgramInfo(HVTOpveGCwQXJgrSInBRoFysUcDNKz)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   HVTOpveGCwQXJgrSInBRoFysUcDNia=HVTOpveGCwQXJgrSInBRoFysUcDNiK.API_DOMAIN+'/fz/vod/programs-contents/'+seasionid
   HVTOpveGCwQXJgrSInBRoFysUcDNim={'limit':HVTOpveGCwQXJgrSInBRoFysUcDNiK.EP_LIMIT,'offset':HVTOpveGCwQXJgrSInBRoFysUcDNfj((page_int-1)*HVTOpveGCwQXJgrSInBRoFysUcDNiK.EP_LIMIT),'orderby':orderby,}
   HVTOpveGCwQXJgrSInBRoFysUcDNim.update(HVTOpveGCwQXJgrSInBRoFysUcDNiK.GetDefaultParams(login=HVTOpveGCwQXJgrSInBRoFysUcDNfm))
   HVTOpveGCwQXJgrSInBRoFysUcDNkK=HVTOpveGCwQXJgrSInBRoFysUcDNiK.callRequestCookies('Get',HVTOpveGCwQXJgrSInBRoFysUcDNia,payload=HVTOpveGCwQXJgrSInBRoFysUcDNfE,params=HVTOpveGCwQXJgrSInBRoFysUcDNim,headers=HVTOpveGCwQXJgrSInBRoFysUcDNfE,cookies=HVTOpveGCwQXJgrSInBRoFysUcDNfE)
   HVTOpveGCwQXJgrSInBRoFysUcDNkq=json.loads(HVTOpveGCwQXJgrSInBRoFysUcDNkK.text)
   HVTOpveGCwQXJgrSInBRoFysUcDNkx=HVTOpveGCwQXJgrSInBRoFysUcDNkq['cell_toplist']['celllist']
   for HVTOpveGCwQXJgrSInBRoFysUcDNkW in HVTOpveGCwQXJgrSInBRoFysUcDNkx:
    HVTOpveGCwQXJgrSInBRoFysUcDNqk=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',HVTOpveGCwQXJgrSInBRoFysUcDNkW.get('synopsis'))
    HVTOpveGCwQXJgrSInBRoFysUcDNqK=HVTOpveGCwQXJgrSInBRoFysUcDNiK.HTTPTAG+HVTOpveGCwQXJgrSInBRoFysUcDNkW.get('thumbnail')
    HVTOpveGCwQXJgrSInBRoFysUcDNqY=HVTOpveGCwQXJgrSInBRoFysUcDNqf=HVTOpveGCwQXJgrSInBRoFysUcDNqd=''
    HVTOpveGCwQXJgrSInBRoFysUcDNqY =HVTOpveGCwQXJgrSInBRoFysUcDNKu.get('imgPoster')
    HVTOpveGCwQXJgrSInBRoFysUcDNqf =HVTOpveGCwQXJgrSInBRoFysUcDNKu.get('imgFanart')
    HVTOpveGCwQXJgrSInBRoFysUcDNqd =HVTOpveGCwQXJgrSInBRoFysUcDNKu.get('imgClearlogo')
    HVTOpveGCwQXJgrSInBRoFysUcDNqA=HVTOpveGCwQXJgrSInBRoFysUcDNKu.get('programtitle')
    HVTOpveGCwQXJgrSInBRoFysUcDNKM={'thumb':HVTOpveGCwQXJgrSInBRoFysUcDNqK,'poster':HVTOpveGCwQXJgrSInBRoFysUcDNqY,'fanart':HVTOpveGCwQXJgrSInBRoFysUcDNqf,'clearlogo':HVTOpveGCwQXJgrSInBRoFysUcDNqd}
    HVTOpveGCwQXJgrSInBRoFysUcDNkj={'programtitle':HVTOpveGCwQXJgrSInBRoFysUcDNqA,'episodetitle':HVTOpveGCwQXJgrSInBRoFysUcDNkW['title_list'][0]['text'],'episodenumber':HVTOpveGCwQXJgrSInBRoFysUcDNkW['title_list'][1]['text'].replace('$O$',''),'contentid':HVTOpveGCwQXJgrSInBRoFysUcDNkW['contentid'],'synopsis':HVTOpveGCwQXJgrSInBRoFysUcDNqk,'episodeactors':HVTOpveGCwQXJgrSInBRoFysUcDNkW.get('actors').split(',')if HVTOpveGCwQXJgrSInBRoFysUcDNkW.get('actors')!='' else[],'thumbnail':HVTOpveGCwQXJgrSInBRoFysUcDNKM,}
    HVTOpveGCwQXJgrSInBRoFysUcDNKa.append(HVTOpveGCwQXJgrSInBRoFysUcDNkj)
   HVTOpveGCwQXJgrSInBRoFysUcDNka=HVTOpveGCwQXJgrSInBRoFysUcDNfu(HVTOpveGCwQXJgrSInBRoFysUcDNkq['cell_toplist']['pagecount'])
   if HVTOpveGCwQXJgrSInBRoFysUcDNkq['cell_toplist']['count']:HVTOpveGCwQXJgrSInBRoFysUcDNKd =HVTOpveGCwQXJgrSInBRoFysUcDNfu(HVTOpveGCwQXJgrSInBRoFysUcDNkq['cell_toplist']['count'])
   else:HVTOpveGCwQXJgrSInBRoFysUcDNKd=HVTOpveGCwQXJgrSInBRoFysUcDNiK.EP_LIMIT*page_int
   HVTOpveGCwQXJgrSInBRoFysUcDNKi=HVTOpveGCwQXJgrSInBRoFysUcDNka>HVTOpveGCwQXJgrSInBRoFysUcDNKd
  except HVTOpveGCwQXJgrSInBRoFysUcDNfh as exception:
   HVTOpveGCwQXJgrSInBRoFysUcDNft(exception)
   return[],HVTOpveGCwQXJgrSInBRoFysUcDNfm
  return HVTOpveGCwQXJgrSInBRoFysUcDNKa,HVTOpveGCwQXJgrSInBRoFysUcDNKi
 def GetEPGList(HVTOpveGCwQXJgrSInBRoFysUcDNiK,genre):
  HVTOpveGCwQXJgrSInBRoFysUcDNql={}
  try:
   HVTOpveGCwQXJgrSInBRoFysUcDNqb=HVTOpveGCwQXJgrSInBRoFysUcDNiK.Get_Now_Datetime()
   if genre=='all':
    HVTOpveGCwQXJgrSInBRoFysUcDNqE =HVTOpveGCwQXJgrSInBRoFysUcDNqb+datetime.timedelta(hours=3)
   else:
    HVTOpveGCwQXJgrSInBRoFysUcDNqE =HVTOpveGCwQXJgrSInBRoFysUcDNqb+datetime.timedelta(hours=3)
   HVTOpveGCwQXJgrSInBRoFysUcDNia=HVTOpveGCwQXJgrSInBRoFysUcDNiK.API_DOMAIN+'/live/epgs'
   HVTOpveGCwQXJgrSInBRoFysUcDNim={'limit':'100','offset':'0','genre':genre,'startdatetime':HVTOpveGCwQXJgrSInBRoFysUcDNqb.strftime('%Y-%m-%d %H:00'),'enddatetime':HVTOpveGCwQXJgrSInBRoFysUcDNqE.strftime('%Y-%m-%d %H:00')}
   HVTOpveGCwQXJgrSInBRoFysUcDNim.update(HVTOpveGCwQXJgrSInBRoFysUcDNiK.GetDefaultParams(login=HVTOpveGCwQXJgrSInBRoFysUcDNfm))
   HVTOpveGCwQXJgrSInBRoFysUcDNkK=HVTOpveGCwQXJgrSInBRoFysUcDNiK.callRequestCookies('Get',HVTOpveGCwQXJgrSInBRoFysUcDNia,payload=HVTOpveGCwQXJgrSInBRoFysUcDNfE,params=HVTOpveGCwQXJgrSInBRoFysUcDNim,headers=HVTOpveGCwQXJgrSInBRoFysUcDNfE,cookies=HVTOpveGCwQXJgrSInBRoFysUcDNfE)
   HVTOpveGCwQXJgrSInBRoFysUcDNkq=json.loads(HVTOpveGCwQXJgrSInBRoFysUcDNkK.text)
   HVTOpveGCwQXJgrSInBRoFysUcDNqm=HVTOpveGCwQXJgrSInBRoFysUcDNkq['list']
   for HVTOpveGCwQXJgrSInBRoFysUcDNkW in HVTOpveGCwQXJgrSInBRoFysUcDNqm:
    HVTOpveGCwQXJgrSInBRoFysUcDNqz=''
    for HVTOpveGCwQXJgrSInBRoFysUcDNqx in HVTOpveGCwQXJgrSInBRoFysUcDNkW['list']:
     if HVTOpveGCwQXJgrSInBRoFysUcDNqz:HVTOpveGCwQXJgrSInBRoFysUcDNqz+='\n'
     HVTOpveGCwQXJgrSInBRoFysUcDNqz+=HVTOpveGCwQXJgrSInBRoFysUcDNiK.Get_ChangeText(HVTOpveGCwQXJgrSInBRoFysUcDNqx['title'])+'\n'
     HVTOpveGCwQXJgrSInBRoFysUcDNqz+=' [%s ~ %s]'%(HVTOpveGCwQXJgrSInBRoFysUcDNqx['starttime'][-5:],HVTOpveGCwQXJgrSInBRoFysUcDNqx['endtime'][-5:])+'\n'
    HVTOpveGCwQXJgrSInBRoFysUcDNql[HVTOpveGCwQXJgrSInBRoFysUcDNkW['channelid']]=HVTOpveGCwQXJgrSInBRoFysUcDNqz
  except HVTOpveGCwQXJgrSInBRoFysUcDNfh as exception:
   HVTOpveGCwQXJgrSInBRoFysUcDNft(exception)
  return HVTOpveGCwQXJgrSInBRoFysUcDNql
 def Get_LiveChannel_List(HVTOpveGCwQXJgrSInBRoFysUcDNiK,genre,HVTOpveGCwQXJgrSInBRoFysUcDNkm):
  HVTOpveGCwQXJgrSInBRoFysUcDNkP=[]
  (HVTOpveGCwQXJgrSInBRoFysUcDNia,HVTOpveGCwQXJgrSInBRoFysUcDNim)=HVTOpveGCwQXJgrSInBRoFysUcDNiK.Baseapi_Parse(HVTOpveGCwQXJgrSInBRoFysUcDNkm)
  if HVTOpveGCwQXJgrSInBRoFysUcDNia=='':return HVTOpveGCwQXJgrSInBRoFysUcDNkP
  HVTOpveGCwQXJgrSInBRoFysUcDNqW=HVTOpveGCwQXJgrSInBRoFysUcDNiK.GetEPGList(genre)
  try:
   HVTOpveGCwQXJgrSInBRoFysUcDNim.update(HVTOpveGCwQXJgrSInBRoFysUcDNiK.GetDefaultParams(login=HVTOpveGCwQXJgrSInBRoFysUcDNfm))
   HVTOpveGCwQXJgrSInBRoFysUcDNim['genre']=genre
   HVTOpveGCwQXJgrSInBRoFysUcDNkK=HVTOpveGCwQXJgrSInBRoFysUcDNiK.callRequestCookies('Get',HVTOpveGCwQXJgrSInBRoFysUcDNia,payload=HVTOpveGCwQXJgrSInBRoFysUcDNfE,params=HVTOpveGCwQXJgrSInBRoFysUcDNim,headers=HVTOpveGCwQXJgrSInBRoFysUcDNfE,cookies=HVTOpveGCwQXJgrSInBRoFysUcDNfE)
   HVTOpveGCwQXJgrSInBRoFysUcDNkq=json.loads(HVTOpveGCwQXJgrSInBRoFysUcDNkK.text)
   if not('celllist' in HVTOpveGCwQXJgrSInBRoFysUcDNkq['cell_toplist']):return[]
   HVTOpveGCwQXJgrSInBRoFysUcDNkx=HVTOpveGCwQXJgrSInBRoFysUcDNkq['cell_toplist']['celllist']
   for HVTOpveGCwQXJgrSInBRoFysUcDNkW in HVTOpveGCwQXJgrSInBRoFysUcDNkx:
    HVTOpveGCwQXJgrSInBRoFysUcDNKz=HVTOpveGCwQXJgrSInBRoFysUcDNkW['contentid']
    if HVTOpveGCwQXJgrSInBRoFysUcDNKz in HVTOpveGCwQXJgrSInBRoFysUcDNqW:
     HVTOpveGCwQXJgrSInBRoFysUcDNqj=HVTOpveGCwQXJgrSInBRoFysUcDNqW[HVTOpveGCwQXJgrSInBRoFysUcDNKz]
    else:
     HVTOpveGCwQXJgrSInBRoFysUcDNqj=''
    HVTOpveGCwQXJgrSInBRoFysUcDNkj={'studio':HVTOpveGCwQXJgrSInBRoFysUcDNkW['title_list'][0]['text'],'tvshowtitle':HVTOpveGCwQXJgrSInBRoFysUcDNiK.Get_ChangeText(HVTOpveGCwQXJgrSInBRoFysUcDNkW['title_list'][1]['text']),'channelid':HVTOpveGCwQXJgrSInBRoFysUcDNKz,'age':HVTOpveGCwQXJgrSInBRoFysUcDNkW['age'],'thumbnail':'https://%s'%HVTOpveGCwQXJgrSInBRoFysUcDNkW.get('thumbnail'),'epg':HVTOpveGCwQXJgrSInBRoFysUcDNqj}
    HVTOpveGCwQXJgrSInBRoFysUcDNkP.append(HVTOpveGCwQXJgrSInBRoFysUcDNkj)
  except HVTOpveGCwQXJgrSInBRoFysUcDNfh as exception:
   HVTOpveGCwQXJgrSInBRoFysUcDNft(exception)
   return[]
  return HVTOpveGCwQXJgrSInBRoFysUcDNkP
 def Get_Search_List(HVTOpveGCwQXJgrSInBRoFysUcDNiK,search_key,sType,page_int,exclusion21=HVTOpveGCwQXJgrSInBRoFysUcDNfm):
  HVTOpveGCwQXJgrSInBRoFysUcDNqh=[]
  HVTOpveGCwQXJgrSInBRoFysUcDNka=HVTOpveGCwQXJgrSInBRoFysUcDNKd=1
  HVTOpveGCwQXJgrSInBRoFysUcDNKi=HVTOpveGCwQXJgrSInBRoFysUcDNfm
  try:
   HVTOpveGCwQXJgrSInBRoFysUcDNia=HVTOpveGCwQXJgrSInBRoFysUcDNiK.API_DOMAIN+'/fz/search/band.js'
   HVTOpveGCwQXJgrSInBRoFysUcDNim={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':HVTOpveGCwQXJgrSInBRoFysUcDNfj((page_int-1)*HVTOpveGCwQXJgrSInBRoFysUcDNiK.SEARCH_LIMIT),'limit':HVTOpveGCwQXJgrSInBRoFysUcDNiK.SEARCH_LIMIT,'orderby':'score','mtype':'svod',}
   HVTOpveGCwQXJgrSInBRoFysUcDNim.update(HVTOpveGCwQXJgrSInBRoFysUcDNiK.GetDefaultParams(login=HVTOpveGCwQXJgrSInBRoFysUcDNfm))
   HVTOpveGCwQXJgrSInBRoFysUcDNkK=HVTOpveGCwQXJgrSInBRoFysUcDNiK.callRequestCookies('Get',HVTOpveGCwQXJgrSInBRoFysUcDNia,payload=HVTOpveGCwQXJgrSInBRoFysUcDNfE,params=HVTOpveGCwQXJgrSInBRoFysUcDNim,headers=HVTOpveGCwQXJgrSInBRoFysUcDNfE,cookies=HVTOpveGCwQXJgrSInBRoFysUcDNfE)
   HVTOpveGCwQXJgrSInBRoFysUcDNKx=json.loads(HVTOpveGCwQXJgrSInBRoFysUcDNkK.text)
   if not('celllist' in HVTOpveGCwQXJgrSInBRoFysUcDNKx['band']):return HVTOpveGCwQXJgrSInBRoFysUcDNqh,HVTOpveGCwQXJgrSInBRoFysUcDNKi
   HVTOpveGCwQXJgrSInBRoFysUcDNkx=HVTOpveGCwQXJgrSInBRoFysUcDNKx['band']['celllist']
   for HVTOpveGCwQXJgrSInBRoFysUcDNkW in HVTOpveGCwQXJgrSInBRoFysUcDNkx:
    HVTOpveGCwQXJgrSInBRoFysUcDNKk =HVTOpveGCwQXJgrSInBRoFysUcDNkW['event_list'][1]['url']
    HVTOpveGCwQXJgrSInBRoFysUcDNKq=urllib.parse.urlsplit(HVTOpveGCwQXJgrSInBRoFysUcDNKk).query
    HVTOpveGCwQXJgrSInBRoFysUcDNKY=HVTOpveGCwQXJgrSInBRoFysUcDNKq[0:HVTOpveGCwQXJgrSInBRoFysUcDNKq.find('=')]
    HVTOpveGCwQXJgrSInBRoFysUcDNKE=HVTOpveGCwQXJgrSInBRoFysUcDNfL(urllib.parse.parse_qsl(HVTOpveGCwQXJgrSInBRoFysUcDNKq))
    HVTOpveGCwQXJgrSInBRoFysUcDNKf=HVTOpveGCwQXJgrSInBRoFysUcDNKE.get(HVTOpveGCwQXJgrSInBRoFysUcDNKY)
    HVTOpveGCwQXJgrSInBRoFysUcDNkj={'title':HVTOpveGCwQXJgrSInBRoFysUcDNkW['title_list'][0]['text'],'age':HVTOpveGCwQXJgrSInBRoFysUcDNkW['age'],'thumbnail':'https://%s'%HVTOpveGCwQXJgrSInBRoFysUcDNkW.get('thumbnail'),'videoid':HVTOpveGCwQXJgrSInBRoFysUcDNKf,'vidtype':HVTOpveGCwQXJgrSInBRoFysUcDNKY,}
    HVTOpveGCwQXJgrSInBRoFysUcDNqt=HVTOpveGCwQXJgrSInBRoFysUcDNfm
    for HVTOpveGCwQXJgrSInBRoFysUcDNqL in HVTOpveGCwQXJgrSInBRoFysUcDNkW['bottom_taglist']:
     if HVTOpveGCwQXJgrSInBRoFysUcDNqL=='won':
      HVTOpveGCwQXJgrSInBRoFysUcDNqt=HVTOpveGCwQXJgrSInBRoFysUcDNfx
      break
    if HVTOpveGCwQXJgrSInBRoFysUcDNqt==HVTOpveGCwQXJgrSInBRoFysUcDNfx: 
     HVTOpveGCwQXJgrSInBRoFysUcDNkj['title']=HVTOpveGCwQXJgrSInBRoFysUcDNkj['title']+' [개별구매]'
    if exclusion21==HVTOpveGCwQXJgrSInBRoFysUcDNfm or HVTOpveGCwQXJgrSInBRoFysUcDNkW.get('age')!='21':
     HVTOpveGCwQXJgrSInBRoFysUcDNqh.append(HVTOpveGCwQXJgrSInBRoFysUcDNkj)
   HVTOpveGCwQXJgrSInBRoFysUcDNka=HVTOpveGCwQXJgrSInBRoFysUcDNfu(HVTOpveGCwQXJgrSInBRoFysUcDNKx['band']['pagecount'])
   if HVTOpveGCwQXJgrSInBRoFysUcDNKx['band']['count']:HVTOpveGCwQXJgrSInBRoFysUcDNKd =HVTOpveGCwQXJgrSInBRoFysUcDNfu(HVTOpveGCwQXJgrSInBRoFysUcDNKx['band']['count'])
   else:HVTOpveGCwQXJgrSInBRoFysUcDNKd=HVTOpveGCwQXJgrSInBRoFysUcDNiK.LIST_LIMIT
   HVTOpveGCwQXJgrSInBRoFysUcDNKi=HVTOpveGCwQXJgrSInBRoFysUcDNka>HVTOpveGCwQXJgrSInBRoFysUcDNKd
  except HVTOpveGCwQXJgrSInBRoFysUcDNfh as exception:
   HVTOpveGCwQXJgrSInBRoFysUcDNft(exception)
  return HVTOpveGCwQXJgrSInBRoFysUcDNqh,HVTOpveGCwQXJgrSInBRoFysUcDNKi 
 def GetSecureToken(HVTOpveGCwQXJgrSInBRoFysUcDNiK):
  HVTOpveGCwQXJgrSInBRoFysUcDNia=HVTOpveGCwQXJgrSInBRoFysUcDNiK.API_DOMAIN+'/ip'
  HVTOpveGCwQXJgrSInBRoFysUcDNim=HVTOpveGCwQXJgrSInBRoFysUcDNiK.GetDefaultParams(login=HVTOpveGCwQXJgrSInBRoFysUcDNfm)
  HVTOpveGCwQXJgrSInBRoFysUcDNkK=HVTOpveGCwQXJgrSInBRoFysUcDNiK.callRequestCookies('Get',HVTOpveGCwQXJgrSInBRoFysUcDNia,payload=HVTOpveGCwQXJgrSInBRoFysUcDNfE,params=HVTOpveGCwQXJgrSInBRoFysUcDNim,headers=HVTOpveGCwQXJgrSInBRoFysUcDNfE,cookies=HVTOpveGCwQXJgrSInBRoFysUcDNfE)
  HVTOpveGCwQXJgrSInBRoFysUcDNkq=json.loads(HVTOpveGCwQXJgrSInBRoFysUcDNkK.text)
  return HVTOpveGCwQXJgrSInBRoFysUcDNkq['securetoken']
 def GetStreamingURL(HVTOpveGCwQXJgrSInBRoFysUcDNiK,mode,HVTOpveGCwQXJgrSInBRoFysUcDNKz,quality_int,pvrmode='-',playOption={}):
  HVTOpveGCwQXJgrSInBRoFysUcDNqu ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  HVTOpveGCwQXJgrSInBRoFysUcDNqM=[]
  if mode=='LIVE':
   HVTOpveGCwQXJgrSInBRoFysUcDNia =HVTOpveGCwQXJgrSInBRoFysUcDNiK.API_DOMAIN+'/live/channels/'+HVTOpveGCwQXJgrSInBRoFysUcDNKz
   HVTOpveGCwQXJgrSInBRoFysUcDNqP='live'
  elif mode=='VOD':
   HVTOpveGCwQXJgrSInBRoFysUcDNia =HVTOpveGCwQXJgrSInBRoFysUcDNiK.API_DOMAIN+'/fz/vod/contents/'+HVTOpveGCwQXJgrSInBRoFysUcDNKz
   HVTOpveGCwQXJgrSInBRoFysUcDNqP='vod'
  elif mode=='MOVIE':
   HVTOpveGCwQXJgrSInBRoFysUcDNia =HVTOpveGCwQXJgrSInBRoFysUcDNiK.API_DOMAIN+'/fz/movie/contents/'+HVTOpveGCwQXJgrSInBRoFysUcDNKz
   HVTOpveGCwQXJgrSInBRoFysUcDNqP='movie'
  HVTOpveGCwQXJgrSInBRoFysUcDNqa={'hdr':'sdr',}
  try:
   HVTOpveGCwQXJgrSInBRoFysUcDNim=HVTOpveGCwQXJgrSInBRoFysUcDNiK.GetDefaultParams(login=HVTOpveGCwQXJgrSInBRoFysUcDNfm)
   HVTOpveGCwQXJgrSInBRoFysUcDNkK=HVTOpveGCwQXJgrSInBRoFysUcDNiK.callRequestCookies('Get',HVTOpveGCwQXJgrSInBRoFysUcDNia,payload=HVTOpveGCwQXJgrSInBRoFysUcDNfE,params=HVTOpveGCwQXJgrSInBRoFysUcDNim,headers=HVTOpveGCwQXJgrSInBRoFysUcDNfE,cookies=HVTOpveGCwQXJgrSInBRoFysUcDNfE)
   HVTOpveGCwQXJgrSInBRoFysUcDNkq=json.loads(HVTOpveGCwQXJgrSInBRoFysUcDNkK.text)
   HVTOpveGCwQXJgrSInBRoFysUcDNYi=HVTOpveGCwQXJgrSInBRoFysUcDNkq['qualities']['list']
   if HVTOpveGCwQXJgrSInBRoFysUcDNYi==HVTOpveGCwQXJgrSInBRoFysUcDNfE:return HVTOpveGCwQXJgrSInBRoFysUcDNqu
   for HVTOpveGCwQXJgrSInBRoFysUcDNYk in HVTOpveGCwQXJgrSInBRoFysUcDNYi:
    HVTOpveGCwQXJgrSInBRoFysUcDNqM.append(HVTOpveGCwQXJgrSInBRoFysUcDNfu(HVTOpveGCwQXJgrSInBRoFysUcDNYk.get('id').rstrip('p')))
   if 'type' in HVTOpveGCwQXJgrSInBRoFysUcDNkq:
    if HVTOpveGCwQXJgrSInBRoFysUcDNkq['type']=='onair':
     HVTOpveGCwQXJgrSInBRoFysUcDNqP='onairvod'
   if 'drms' in HVTOpveGCwQXJgrSInBRoFysUcDNkq:
    if HVTOpveGCwQXJgrSInBRoFysUcDNkq['drms']:
     HVTOpveGCwQXJgrSInBRoFysUcDNqu['stream_action']='dash'
   if playOption.get('enable_hdr'):
    if 'mediatypes' in HVTOpveGCwQXJgrSInBRoFysUcDNkq.get('qualities'):
     for HVTOpveGCwQXJgrSInBRoFysUcDNYK in HVTOpveGCwQXJgrSInBRoFysUcDNkq.get('qualities').get('mediatypes'):
      if HVTOpveGCwQXJgrSInBRoFysUcDNYK=='HDR10':
       HVTOpveGCwQXJgrSInBRoFysUcDNqa['hdr']='hdr'
       HVTOpveGCwQXJgrSInBRoFysUcDNqu['stream_action']='dash'
       break
  except HVTOpveGCwQXJgrSInBRoFysUcDNfh as exception:
   HVTOpveGCwQXJgrSInBRoFysUcDNft(exception)
   return HVTOpveGCwQXJgrSInBRoFysUcDNqu
  HVTOpveGCwQXJgrSInBRoFysUcDNft(HVTOpveGCwQXJgrSInBRoFysUcDNqu['stream_action'])
  try:
   HVTOpveGCwQXJgrSInBRoFysUcDNYq=HVTOpveGCwQXJgrSInBRoFysUcDNiK.CheckQuality(quality_int,HVTOpveGCwQXJgrSInBRoFysUcDNqM)
   HVTOpveGCwQXJgrSInBRoFysUcDNYf=HVTOpveGCwQXJgrSInBRoFysUcDNfj(HVTOpveGCwQXJgrSInBRoFysUcDNYq)+'p'
   HVTOpveGCwQXJgrSInBRoFysUcDNia=HVTOpveGCwQXJgrSInBRoFysUcDNiK.API_DOMAIN+'/fz/streaming'
   if HVTOpveGCwQXJgrSInBRoFysUcDNqa['hdr']=='hdr':
    HVTOpveGCwQXJgrSInBRoFysUcDNim={'contentid':HVTOpveGCwQXJgrSInBRoFysUcDNKz,'contenttype':HVTOpveGCwQXJgrSInBRoFysUcDNqP,'quality':HVTOpveGCwQXJgrSInBRoFysUcDNYf,'modelid':'SHIELD Android TV','guid':HVTOpveGCwQXJgrSInBRoFysUcDNiK.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n','protocol':HVTOpveGCwQXJgrSInBRoFysUcDNqu['stream_action'],'hdr':'HDR10','videocodec':'HEVC','audiocodec':'AAC','issurround':'y','format':'normal','withinsubtitle':'n',}
    HVTOpveGCwQXJgrSInBRoFysUcDNim.update(HVTOpveGCwQXJgrSInBRoFysUcDNiK.GetDefaultParams_AND())
   else:
    HVTOpveGCwQXJgrSInBRoFysUcDNim={'contentid':HVTOpveGCwQXJgrSInBRoFysUcDNKz,'contenttype':HVTOpveGCwQXJgrSInBRoFysUcDNqP,'quality':HVTOpveGCwQXJgrSInBRoFysUcDNYf,'deviceModelId':'Windows 10','guid':HVTOpveGCwQXJgrSInBRoFysUcDNiK.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n','action':HVTOpveGCwQXJgrSInBRoFysUcDNqu['stream_action'],'protocol':HVTOpveGCwQXJgrSInBRoFysUcDNqu['stream_action'],'hdr':'sdr','videocodec':'avc','audiocodec':'aac','issurround':'n','format':'normal','withinsubtitle':'n',}
    HVTOpveGCwQXJgrSInBRoFysUcDNim.update(HVTOpveGCwQXJgrSInBRoFysUcDNiK.GetDefaultParams(login=HVTOpveGCwQXJgrSInBRoFysUcDNfx))
   HVTOpveGCwQXJgrSInBRoFysUcDNkK=HVTOpveGCwQXJgrSInBRoFysUcDNiK.callRequestCookies('Get',HVTOpveGCwQXJgrSInBRoFysUcDNia,payload=HVTOpveGCwQXJgrSInBRoFysUcDNfE,params=HVTOpveGCwQXJgrSInBRoFysUcDNim,headers=HVTOpveGCwQXJgrSInBRoFysUcDNfE,cookies=HVTOpveGCwQXJgrSInBRoFysUcDNfE)
   HVTOpveGCwQXJgrSInBRoFysUcDNkq=json.loads(HVTOpveGCwQXJgrSInBRoFysUcDNkK.text)
   HVTOpveGCwQXJgrSInBRoFysUcDNqu['stream_url']=HVTOpveGCwQXJgrSInBRoFysUcDNkq['playurl']
   if HVTOpveGCwQXJgrSInBRoFysUcDNqu['stream_url']==HVTOpveGCwQXJgrSInBRoFysUcDNfE:return HVTOpveGCwQXJgrSInBRoFysUcDNqu
   HVTOpveGCwQXJgrSInBRoFysUcDNqu['stream_cookie']=HVTOpveGCwQXJgrSInBRoFysUcDNkq['awscookie']
   HVTOpveGCwQXJgrSInBRoFysUcDNqu['stream_drm'] =HVTOpveGCwQXJgrSInBRoFysUcDNkq['drm']
   if 'previewmsg' in HVTOpveGCwQXJgrSInBRoFysUcDNkq['preview']:HVTOpveGCwQXJgrSInBRoFysUcDNqu['stream_preview']=HVTOpveGCwQXJgrSInBRoFysUcDNkq['preview']['previewmsg']
   if 'subtitles' in HVTOpveGCwQXJgrSInBRoFysUcDNkq:
    for HVTOpveGCwQXJgrSInBRoFysUcDNYd in HVTOpveGCwQXJgrSInBRoFysUcDNkq['subtitles']:
     if HVTOpveGCwQXJgrSInBRoFysUcDNYd.get('languagecode')=='ko':
      HVTOpveGCwQXJgrSInBRoFysUcDNqu['stream_vtt']=HVTOpveGCwQXJgrSInBRoFysUcDNYd.get('url')
      break
  except HVTOpveGCwQXJgrSInBRoFysUcDNfh as exception:
   HVTOpveGCwQXJgrSInBRoFysUcDNft(exception)
  return HVTOpveGCwQXJgrSInBRoFysUcDNqu 
 def GetSportsURL(HVTOpveGCwQXJgrSInBRoFysUcDNiK,HVTOpveGCwQXJgrSInBRoFysUcDNKz,quality_int):
  HVTOpveGCwQXJgrSInBRoFysUcDNqu ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  HVTOpveGCwQXJgrSInBRoFysUcDNqM=[]
  try:
   HVTOpveGCwQXJgrSInBRoFysUcDNia=HVTOpveGCwQXJgrSInBRoFysUcDNiK.API_DOMAIN+'/streaming/other'
   HVTOpveGCwQXJgrSInBRoFysUcDNim={'contentid':HVTOpveGCwQXJgrSInBRoFysUcDNKz,'contenttype':'live','action':HVTOpveGCwQXJgrSInBRoFysUcDNqu['stream_action'],'quality':HVTOpveGCwQXJgrSInBRoFysUcDNfj(quality_int)+'p','deviceModelId':'Windows 10','guid':HVTOpveGCwQXJgrSInBRoFysUcDNiK.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n',}
   HVTOpveGCwQXJgrSInBRoFysUcDNim.update(HVTOpveGCwQXJgrSInBRoFysUcDNiK.GetDefaultParams(login=HVTOpveGCwQXJgrSInBRoFysUcDNfx))
   HVTOpveGCwQXJgrSInBRoFysUcDNkK=HVTOpveGCwQXJgrSInBRoFysUcDNiK.callRequestCookies('Get',HVTOpveGCwQXJgrSInBRoFysUcDNia,payload=HVTOpveGCwQXJgrSInBRoFysUcDNfE,params=HVTOpveGCwQXJgrSInBRoFysUcDNim,headers=HVTOpveGCwQXJgrSInBRoFysUcDNfE,cookies=HVTOpveGCwQXJgrSInBRoFysUcDNfE)
   HVTOpveGCwQXJgrSInBRoFysUcDNkq=json.loads(HVTOpveGCwQXJgrSInBRoFysUcDNkK.text)
   HVTOpveGCwQXJgrSInBRoFysUcDNqu['stream_url']=HVTOpveGCwQXJgrSInBRoFysUcDNkq['playurl']
   if HVTOpveGCwQXJgrSInBRoFysUcDNqu['stream_url']==HVTOpveGCwQXJgrSInBRoFysUcDNfE:return HVTOpveGCwQXJgrSInBRoFysUcDNqu
   HVTOpveGCwQXJgrSInBRoFysUcDNqu['stream_cookie']=HVTOpveGCwQXJgrSInBRoFysUcDNkq['awscookie']
  except HVTOpveGCwQXJgrSInBRoFysUcDNfh as exception:
   HVTOpveGCwQXJgrSInBRoFysUcDNft(exception)
  return HVTOpveGCwQXJgrSInBRoFysUcDNqu
 def make_viewdate(HVTOpveGCwQXJgrSInBRoFysUcDNiK):
  HVTOpveGCwQXJgrSInBRoFysUcDNYA =HVTOpveGCwQXJgrSInBRoFysUcDNiK.Get_Now_Datetime()
  HVTOpveGCwQXJgrSInBRoFysUcDNYl =HVTOpveGCwQXJgrSInBRoFysUcDNYA+datetime.timedelta(days=-1)
  HVTOpveGCwQXJgrSInBRoFysUcDNYb =HVTOpveGCwQXJgrSInBRoFysUcDNYA+datetime.timedelta(days=1)
  HVTOpveGCwQXJgrSInBRoFysUcDNYE=[HVTOpveGCwQXJgrSInBRoFysUcDNYA.strftime('%Y%m%d'),HVTOpveGCwQXJgrSInBRoFysUcDNYb.strftime('%Y%m%d'),]
  return HVTOpveGCwQXJgrSInBRoFysUcDNYE
 def Get_Sports_Gamelist(HVTOpveGCwQXJgrSInBRoFysUcDNiK):
  HVTOpveGCwQXJgrSInBRoFysUcDNYm =HVTOpveGCwQXJgrSInBRoFysUcDNiK.make_viewdate()
  HVTOpveGCwQXJgrSInBRoFysUcDNYz=[]
  HVTOpveGCwQXJgrSInBRoFysUcDNYx =[]
  for HVTOpveGCwQXJgrSInBRoFysUcDNYW in HVTOpveGCwQXJgrSInBRoFysUcDNYm:
   HVTOpveGCwQXJgrSInBRoFysUcDNYj=HVTOpveGCwQXJgrSInBRoFysUcDNYW[:6]
   if HVTOpveGCwQXJgrSInBRoFysUcDNYj not in HVTOpveGCwQXJgrSInBRoFysUcDNYz:
    HVTOpveGCwQXJgrSInBRoFysUcDNYz.append(HVTOpveGCwQXJgrSInBRoFysUcDNYj)
  try:
   HVTOpveGCwQXJgrSInBRoFysUcDNia='https://annexapi.wavve.com/skb/baseball/teammonthlycalendarlist'
   HVTOpveGCwQXJgrSInBRoFysUcDNim={'IF':'IF-PORG-002','m':'getTeamCalendarListBand','response_format':'json','spo_itm_cd':'KBO','teamcd':'all','tgroup':'B','tvalue':'BC123','ver':'2.0',}
   HVTOpveGCwQXJgrSInBRoFysUcDNim.update(HVTOpveGCwQXJgrSInBRoFysUcDNiK.GetDefaultParams(login=HVTOpveGCwQXJgrSInBRoFysUcDNfm))
   for HVTOpveGCwQXJgrSInBRoFysUcDNYh in HVTOpveGCwQXJgrSInBRoFysUcDNYz:
    HVTOpveGCwQXJgrSInBRoFysUcDNim['date']=HVTOpveGCwQXJgrSInBRoFysUcDNYh
    HVTOpveGCwQXJgrSInBRoFysUcDNkK=HVTOpveGCwQXJgrSInBRoFysUcDNiK.callRequestCookies('Get',HVTOpveGCwQXJgrSInBRoFysUcDNia,payload=HVTOpveGCwQXJgrSInBRoFysUcDNfE,params=HVTOpveGCwQXJgrSInBRoFysUcDNim,headers=HVTOpveGCwQXJgrSInBRoFysUcDNfE,cookies=HVTOpveGCwQXJgrSInBRoFysUcDNfE)
    HVTOpveGCwQXJgrSInBRoFysUcDNkq=json.loads(HVTOpveGCwQXJgrSInBRoFysUcDNkK.text)
    HVTOpveGCwQXJgrSInBRoFysUcDNkx=HVTOpveGCwQXJgrSInBRoFysUcDNkq['cell_toplist']['celllist']
    for HVTOpveGCwQXJgrSInBRoFysUcDNkW in HVTOpveGCwQXJgrSInBRoFysUcDNkx:
     HVTOpveGCwQXJgrSInBRoFysUcDNYt=HVTOpveGCwQXJgrSInBRoFysUcDNkW.get('game_date')
     HVTOpveGCwQXJgrSInBRoFysUcDNYL =HVTOpveGCwQXJgrSInBRoFysUcDNkW.get('svc_id')
     if HVTOpveGCwQXJgrSInBRoFysUcDNYL=='':continue
     if HVTOpveGCwQXJgrSInBRoFysUcDNYt in HVTOpveGCwQXJgrSInBRoFysUcDNYm:
      HVTOpveGCwQXJgrSInBRoFysUcDNYu=HVTOpveGCwQXJgrSInBRoFysUcDNkW.get('game_status') 
      HVTOpveGCwQXJgrSInBRoFysUcDNYM =HVTOpveGCwQXJgrSInBRoFysUcDNkW.get('title_list')[0].get('text')
      HVTOpveGCwQXJgrSInBRoFysUcDNYt =HVTOpveGCwQXJgrSInBRoFysUcDNYt[:4]+'-'+HVTOpveGCwQXJgrSInBRoFysUcDNYt[4:6]+'-'+HVTOpveGCwQXJgrSInBRoFysUcDNYt[-2:]
      HVTOpveGCwQXJgrSInBRoFysUcDNYP =HVTOpveGCwQXJgrSInBRoFysUcDNkW.get('game_time')
      HVTOpveGCwQXJgrSInBRoFysUcDNYP =HVTOpveGCwQXJgrSInBRoFysUcDNYP[:2]+':'+HVTOpveGCwQXJgrSInBRoFysUcDNYP[-2:]
      HVTOpveGCwQXJgrSInBRoFysUcDNkj={'game_date':HVTOpveGCwQXJgrSInBRoFysUcDNYt,'game_time':HVTOpveGCwQXJgrSInBRoFysUcDNYP,'svc_id':HVTOpveGCwQXJgrSInBRoFysUcDNYL,'away_team':HVTOpveGCwQXJgrSInBRoFysUcDNkW.get('away_team').get('team_name'),'home_team':HVTOpveGCwQXJgrSInBRoFysUcDNkW.get('home_team').get('team_name'),'game_status':HVTOpveGCwQXJgrSInBRoFysUcDNYu,'game_place':HVTOpveGCwQXJgrSInBRoFysUcDNkW.get('game_place'),}
      HVTOpveGCwQXJgrSInBRoFysUcDNYx.append(HVTOpveGCwQXJgrSInBRoFysUcDNkj)
  except HVTOpveGCwQXJgrSInBRoFysUcDNfh as exception:
   HVTOpveGCwQXJgrSInBRoFysUcDNft(exception)
   return[]
  HVTOpveGCwQXJgrSInBRoFysUcDNYa=[]
  for i in HVTOpveGCwQXJgrSInBRoFysUcDNfW(2):
   for HVTOpveGCwQXJgrSInBRoFysUcDNkW in HVTOpveGCwQXJgrSInBRoFysUcDNYx:
    if i==0 and HVTOpveGCwQXJgrSInBRoFysUcDNkW.get('game_status')=='LIVE':
     HVTOpveGCwQXJgrSInBRoFysUcDNYa.append(HVTOpveGCwQXJgrSInBRoFysUcDNkW)
    elif i==1 and HVTOpveGCwQXJgrSInBRoFysUcDNkW.get('game_status')!='LIVE':
     HVTOpveGCwQXJgrSInBRoFysUcDNYa.append(HVTOpveGCwQXJgrSInBRoFysUcDNkW)
  return HVTOpveGCwQXJgrSInBRoFysUcDNYa
 def GetBookmarkInfo(HVTOpveGCwQXJgrSInBRoFysUcDNiK,HVTOpveGCwQXJgrSInBRoFysUcDNKf,HVTOpveGCwQXJgrSInBRoFysUcDNKY,HVTOpveGCwQXJgrSInBRoFysUcDNqP):
  if HVTOpveGCwQXJgrSInBRoFysUcDNKY=='tvshow':
   if HVTOpveGCwQXJgrSInBRoFysUcDNqP=='contentid':
    HVTOpveGCwQXJgrSInBRoFysUcDNKz=HVTOpveGCwQXJgrSInBRoFysUcDNKf
    HVTOpveGCwQXJgrSInBRoFysUcDNKf =HVTOpveGCwQXJgrSInBRoFysUcDNiK.ContentidToSeasonid(HVTOpveGCwQXJgrSInBRoFysUcDNKz)
   else:
    HVTOpveGCwQXJgrSInBRoFysUcDNKz=HVTOpveGCwQXJgrSInBRoFysUcDNiK.ProgramidToContentid(HVTOpveGCwQXJgrSInBRoFysUcDNKf)
  else:
   HVTOpveGCwQXJgrSInBRoFysUcDNKz=''
  HVTOpveGCwQXJgrSInBRoFysUcDNfi={'indexinfo':{'ott':'wavve','videoid':HVTOpveGCwQXJgrSInBRoFysUcDNKf,'vidtype':HVTOpveGCwQXJgrSInBRoFysUcDNKY,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':HVTOpveGCwQXJgrSInBRoFysUcDNKY,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if HVTOpveGCwQXJgrSInBRoFysUcDNKY=='tvshow':
   HVTOpveGCwQXJgrSInBRoFysUcDNia=HVTOpveGCwQXJgrSInBRoFysUcDNiK.API_DOMAIN+'/fz/vod/contents/'+HVTOpveGCwQXJgrSInBRoFysUcDNKz 
   HVTOpveGCwQXJgrSInBRoFysUcDNim=HVTOpveGCwQXJgrSInBRoFysUcDNiK.GetDefaultParams(login=HVTOpveGCwQXJgrSInBRoFysUcDNfm)
   HVTOpveGCwQXJgrSInBRoFysUcDNkK=HVTOpveGCwQXJgrSInBRoFysUcDNiK.callRequestCookies('Get',HVTOpveGCwQXJgrSInBRoFysUcDNia,payload=HVTOpveGCwQXJgrSInBRoFysUcDNfE,params=HVTOpveGCwQXJgrSInBRoFysUcDNim,headers=HVTOpveGCwQXJgrSInBRoFysUcDNfE,cookies=HVTOpveGCwQXJgrSInBRoFysUcDNfE)
   HVTOpveGCwQXJgrSInBRoFysUcDNkq=json.loads(HVTOpveGCwQXJgrSInBRoFysUcDNkK.text)
   if not('programtitle' in HVTOpveGCwQXJgrSInBRoFysUcDNkq):return{}
   HVTOpveGCwQXJgrSInBRoFysUcDNfk=HVTOpveGCwQXJgrSInBRoFysUcDNkq
   HVTOpveGCwQXJgrSInBRoFysUcDNfK=HVTOpveGCwQXJgrSInBRoFysUcDNfk.get('programtitle')
   HVTOpveGCwQXJgrSInBRoFysUcDNfi['saveinfo']['infoLabels']['title']=HVTOpveGCwQXJgrSInBRoFysUcDNfK
   if HVTOpveGCwQXJgrSInBRoFysUcDNfk.get('targetage')=='18' or HVTOpveGCwQXJgrSInBRoFysUcDNfk.get('targetage')=='19' or HVTOpveGCwQXJgrSInBRoFysUcDNfk.get('targetage')=='21':
    HVTOpveGCwQXJgrSInBRoFysUcDNfK +=u' (%s)'%(HVTOpveGCwQXJgrSInBRoFysUcDNfk.get('targetage'))
   HVTOpveGCwQXJgrSInBRoFysUcDNfi['saveinfo']['title'] =HVTOpveGCwQXJgrSInBRoFysUcDNfK
   HVTOpveGCwQXJgrSInBRoFysUcDNfi['saveinfo']['infoLabels']['mpaa'] =HVTOpveGCwQXJgrSInBRoFysUcDNfk.get('targetage')
   HVTOpveGCwQXJgrSInBRoFysUcDNfi['saveinfo']['infoLabels']['plot'] =HVTOpveGCwQXJgrSInBRoFysUcDNfk.get('programsynopsis').replace('<br>','\n')
   HVTOpveGCwQXJgrSInBRoFysUcDNfi['saveinfo']['infoLabels']['studio'] =HVTOpveGCwQXJgrSInBRoFysUcDNfk.get('channelname')
   if HVTOpveGCwQXJgrSInBRoFysUcDNfk.get('firstreleaseyear')!='':HVTOpveGCwQXJgrSInBRoFysUcDNfi['saveinfo']['infoLabels']['year'] =HVTOpveGCwQXJgrSInBRoFysUcDNfk.get('firstreleaseyear')
   if HVTOpveGCwQXJgrSInBRoFysUcDNfk.get('firstreleasedate')!='':HVTOpveGCwQXJgrSInBRoFysUcDNfi['saveinfo']['infoLabels']['premiered']=HVTOpveGCwQXJgrSInBRoFysUcDNfk.get('firstreleasedate')
   if HVTOpveGCwQXJgrSInBRoFysUcDNfk.get('genretext') !='':HVTOpveGCwQXJgrSInBRoFysUcDNfi['saveinfo']['infoLabels']['genre'] =[HVTOpveGCwQXJgrSInBRoFysUcDNfk.get('genretext')]
   HVTOpveGCwQXJgrSInBRoFysUcDNfq=[]
   for HVTOpveGCwQXJgrSInBRoFysUcDNfY in HVTOpveGCwQXJgrSInBRoFysUcDNfk['actors']['list']:HVTOpveGCwQXJgrSInBRoFysUcDNfq.append(HVTOpveGCwQXJgrSInBRoFysUcDNfY.get('text'))
   if HVTOpveGCwQXJgrSInBRoFysUcDNfM(HVTOpveGCwQXJgrSInBRoFysUcDNfq)>0:
    if HVTOpveGCwQXJgrSInBRoFysUcDNfq[0]!='':HVTOpveGCwQXJgrSInBRoFysUcDNfi['saveinfo']['infoLabels']['cast']=HVTOpveGCwQXJgrSInBRoFysUcDNfq
   HVTOpveGCwQXJgrSInBRoFysUcDNqY =''
   HVTOpveGCwQXJgrSInBRoFysUcDNqf =''
   HVTOpveGCwQXJgrSInBRoFysUcDNqd=''
   if HVTOpveGCwQXJgrSInBRoFysUcDNfk.get('programposterimage')!='':HVTOpveGCwQXJgrSInBRoFysUcDNqY =HVTOpveGCwQXJgrSInBRoFysUcDNiK.HTTPTAG+HVTOpveGCwQXJgrSInBRoFysUcDNfk.get('programposterimage')
   if HVTOpveGCwQXJgrSInBRoFysUcDNfk.get('programimage') !='':HVTOpveGCwQXJgrSInBRoFysUcDNqf =HVTOpveGCwQXJgrSInBRoFysUcDNiK.HTTPTAG+HVTOpveGCwQXJgrSInBRoFysUcDNfk.get('programimage')
   if HVTOpveGCwQXJgrSInBRoFysUcDNfk.get('programcircleimage')!='':HVTOpveGCwQXJgrSInBRoFysUcDNqd=HVTOpveGCwQXJgrSInBRoFysUcDNiK.HTTPTAG+HVTOpveGCwQXJgrSInBRoFysUcDNfk.get('programcircleimage')
   if 'poster_default' in HVTOpveGCwQXJgrSInBRoFysUcDNqY:
    HVTOpveGCwQXJgrSInBRoFysUcDNqY =HVTOpveGCwQXJgrSInBRoFysUcDNqf
    HVTOpveGCwQXJgrSInBRoFysUcDNqd=''
   HVTOpveGCwQXJgrSInBRoFysUcDNfi['saveinfo']['thumbnail']['poster']=HVTOpveGCwQXJgrSInBRoFysUcDNqY
   HVTOpveGCwQXJgrSInBRoFysUcDNfi['saveinfo']['thumbnail']['thumb']=HVTOpveGCwQXJgrSInBRoFysUcDNqf
   HVTOpveGCwQXJgrSInBRoFysUcDNfi['saveinfo']['thumbnail']['clearlogo']=HVTOpveGCwQXJgrSInBRoFysUcDNqd
   HVTOpveGCwQXJgrSInBRoFysUcDNfi['saveinfo']['thumbnail']['fanart']=HVTOpveGCwQXJgrSInBRoFysUcDNqf
  else:
   HVTOpveGCwQXJgrSInBRoFysUcDNia=HVTOpveGCwQXJgrSInBRoFysUcDNiK.API_DOMAIN+'/movie/contents/'+HVTOpveGCwQXJgrSInBRoFysUcDNKf 
   HVTOpveGCwQXJgrSInBRoFysUcDNim=HVTOpveGCwQXJgrSInBRoFysUcDNiK.GetDefaultParams(login=HVTOpveGCwQXJgrSInBRoFysUcDNfm)
   HVTOpveGCwQXJgrSInBRoFysUcDNkK=HVTOpveGCwQXJgrSInBRoFysUcDNiK.callRequestCookies('Get',HVTOpveGCwQXJgrSInBRoFysUcDNia,payload=HVTOpveGCwQXJgrSInBRoFysUcDNfE,params=HVTOpveGCwQXJgrSInBRoFysUcDNim,headers=HVTOpveGCwQXJgrSInBRoFysUcDNfE,cookies=HVTOpveGCwQXJgrSInBRoFysUcDNfE)
   HVTOpveGCwQXJgrSInBRoFysUcDNkq=json.loads(HVTOpveGCwQXJgrSInBRoFysUcDNkK.text)
   if not('title' in HVTOpveGCwQXJgrSInBRoFysUcDNkq):return{}
   HVTOpveGCwQXJgrSInBRoFysUcDNfk=HVTOpveGCwQXJgrSInBRoFysUcDNkq
   HVTOpveGCwQXJgrSInBRoFysUcDNfK=HVTOpveGCwQXJgrSInBRoFysUcDNfk.get('title')
   HVTOpveGCwQXJgrSInBRoFysUcDNfi['saveinfo']['infoLabels']['title']=HVTOpveGCwQXJgrSInBRoFysUcDNfK
   if HVTOpveGCwQXJgrSInBRoFysUcDNfk.get('targetage')=='18' or HVTOpveGCwQXJgrSInBRoFysUcDNfk.get('targetage')=='19' or HVTOpveGCwQXJgrSInBRoFysUcDNfk.get('targetage')=='21':
    HVTOpveGCwQXJgrSInBRoFysUcDNfK +=u' (%s)'%(HVTOpveGCwQXJgrSInBRoFysUcDNfk.get('targetage'))
   HVTOpveGCwQXJgrSInBRoFysUcDNfi['saveinfo']['title'] =HVTOpveGCwQXJgrSInBRoFysUcDNfK
   HVTOpveGCwQXJgrSInBRoFysUcDNfi['saveinfo']['infoLabels']['mpaa'] =HVTOpveGCwQXJgrSInBRoFysUcDNfk.get('targetage')
   HVTOpveGCwQXJgrSInBRoFysUcDNfi['saveinfo']['infoLabels']['plot'] =HVTOpveGCwQXJgrSInBRoFysUcDNfk.get('synopsis').replace('<br>','\n')
   HVTOpveGCwQXJgrSInBRoFysUcDNfi['saveinfo']['infoLabels']['duration']=HVTOpveGCwQXJgrSInBRoFysUcDNfk.get('playtime')
   HVTOpveGCwQXJgrSInBRoFysUcDNfi['saveinfo']['infoLabels']['country']=HVTOpveGCwQXJgrSInBRoFysUcDNfk.get('country')
   HVTOpveGCwQXJgrSInBRoFysUcDNfi['saveinfo']['infoLabels']['studio'] =HVTOpveGCwQXJgrSInBRoFysUcDNfk.get('cpname')
   if HVTOpveGCwQXJgrSInBRoFysUcDNfk.get('releasedate')!='':
    HVTOpveGCwQXJgrSInBRoFysUcDNfi['saveinfo']['infoLabels']['year'] =HVTOpveGCwQXJgrSInBRoFysUcDNfk.get('releasedate')[:4]
    HVTOpveGCwQXJgrSInBRoFysUcDNfi['saveinfo']['infoLabels']['premiered']=HVTOpveGCwQXJgrSInBRoFysUcDNfk.get('releasedate')
   HVTOpveGCwQXJgrSInBRoFysUcDNfq=[]
   for HVTOpveGCwQXJgrSInBRoFysUcDNfY in HVTOpveGCwQXJgrSInBRoFysUcDNfk['actors']['list']:HVTOpveGCwQXJgrSInBRoFysUcDNfq.append(HVTOpveGCwQXJgrSInBRoFysUcDNfY.get('text'))
   if HVTOpveGCwQXJgrSInBRoFysUcDNfM(HVTOpveGCwQXJgrSInBRoFysUcDNfq)>0:
    if HVTOpveGCwQXJgrSInBRoFysUcDNfq[0]!='':HVTOpveGCwQXJgrSInBRoFysUcDNfi['saveinfo']['infoLabels']['cast']=HVTOpveGCwQXJgrSInBRoFysUcDNfq
   HVTOpveGCwQXJgrSInBRoFysUcDNfd=[]
   for HVTOpveGCwQXJgrSInBRoFysUcDNfA in HVTOpveGCwQXJgrSInBRoFysUcDNfk['directors']['list']:HVTOpveGCwQXJgrSInBRoFysUcDNfd.append(HVTOpveGCwQXJgrSInBRoFysUcDNfA.get('text'))
   if HVTOpveGCwQXJgrSInBRoFysUcDNfM(HVTOpveGCwQXJgrSInBRoFysUcDNfd)>0:
    if HVTOpveGCwQXJgrSInBRoFysUcDNfd[0]!='':HVTOpveGCwQXJgrSInBRoFysUcDNfi['saveinfo']['infoLabels']['director']=HVTOpveGCwQXJgrSInBRoFysUcDNfd
   HVTOpveGCwQXJgrSInBRoFysUcDNkE=[]
   for HVTOpveGCwQXJgrSInBRoFysUcDNfl in HVTOpveGCwQXJgrSInBRoFysUcDNfk['genre']['list']:HVTOpveGCwQXJgrSInBRoFysUcDNkE.append(HVTOpveGCwQXJgrSInBRoFysUcDNfl.get('text'))
   if HVTOpveGCwQXJgrSInBRoFysUcDNfM(HVTOpveGCwQXJgrSInBRoFysUcDNkE)>0:
    if HVTOpveGCwQXJgrSInBRoFysUcDNkE[0]!='':HVTOpveGCwQXJgrSInBRoFysUcDNfi['saveinfo']['infoLabels']['genre']=HVTOpveGCwQXJgrSInBRoFysUcDNkE
   HVTOpveGCwQXJgrSInBRoFysUcDNqY ='https://%s'%HVTOpveGCwQXJgrSInBRoFysUcDNfk['image']
   HVTOpveGCwQXJgrSInBRoFysUcDNfi['saveinfo']['thumbnail']['poster'] =HVTOpveGCwQXJgrSInBRoFysUcDNqY
   HVTOpveGCwQXJgrSInBRoFysUcDNfi['saveinfo']['thumbnail']['thumb'] =HVTOpveGCwQXJgrSInBRoFysUcDNqY
  return HVTOpveGCwQXJgrSInBRoFysUcDNfi
# Created by pyminifier (https://github.com/liftoff/pyminifier)
