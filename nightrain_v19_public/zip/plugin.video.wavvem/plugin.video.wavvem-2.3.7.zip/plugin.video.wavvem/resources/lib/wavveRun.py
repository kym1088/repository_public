__author__="NightRain"
SYjoDwgvEaQteqBJmKRFklLIcNMdGO=object
SYjoDwgvEaQteqBJmKRFklLIcNMdGH=None
SYjoDwgvEaQteqBJmKRFklLIcNMdGU=int
SYjoDwgvEaQteqBJmKRFklLIcNMdGi=True
SYjoDwgvEaQteqBJmKRFklLIcNMdGh=False
SYjoDwgvEaQteqBJmKRFklLIcNMdGb=type
SYjoDwgvEaQteqBJmKRFklLIcNMdGs=dict
SYjoDwgvEaQteqBJmKRFklLIcNMdGT=len
SYjoDwgvEaQteqBJmKRFklLIcNMdGP=range
SYjoDwgvEaQteqBJmKRFklLIcNMdGr=str
SYjoDwgvEaQteqBJmKRFklLIcNMdGA=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import json
SYjoDwgvEaQteqBJmKRFklLIcNMdOU=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://apis.wavve.com/v1/multiband/GN51','icon':'home.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&uicode=VN500','page':'1','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?WeekDay=all&broadcastid=1390539&contenttype=vod&genre=01&orderby=viewtime&uicode=VN4&uiparent=FN0&uirank=0&uitype=VN4','page':'1','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?WeekDay=all&broadcastid=1311034&contenttype=vod&genre=02&orderby=viewtime&uicode=VN3&uiparent=FN0&uirank=0&uitype=VN3','page':'1','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'CN21','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'vod09','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'vod09','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'4','sType':'movie','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'4','sType':'movie','orderby':'modifydate','ordernm':'업데이트순','icon':''},{'title':'프로야구 - 경기중 시청가능','mode':'GAME_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'(웨이브) 검색','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'(웨이브) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
SYjoDwgvEaQteqBJmKRFklLIcNMdOi=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
SYjoDwgvEaQteqBJmKRFklLIcNMdOh=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
SYjoDwgvEaQteqBJmKRFklLIcNMdOb =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
SYjoDwgvEaQteqBJmKRFklLIcNMdOs=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_searched.txt'))
from wavveCore import*
class SYjoDwgvEaQteqBJmKRFklLIcNMdOH(SYjoDwgvEaQteqBJmKRFklLIcNMdGO):
 def __init__(SYjoDwgvEaQteqBJmKRFklLIcNMdOG,SYjoDwgvEaQteqBJmKRFklLIcNMdOT,SYjoDwgvEaQteqBJmKRFklLIcNMdOP,SYjoDwgvEaQteqBJmKRFklLIcNMdOr):
  SYjoDwgvEaQteqBJmKRFklLIcNMdOG._addon_url =SYjoDwgvEaQteqBJmKRFklLIcNMdOT
  SYjoDwgvEaQteqBJmKRFklLIcNMdOG._addon_handle=SYjoDwgvEaQteqBJmKRFklLIcNMdOP
  SYjoDwgvEaQteqBJmKRFklLIcNMdOG.main_params =SYjoDwgvEaQteqBJmKRFklLIcNMdOr
  SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj =HVTOpveGCwQXJgrSInBRoFysUcDNik() 
 def addon_noti(SYjoDwgvEaQteqBJmKRFklLIcNMdOG,sting):
  try:
   SYjoDwgvEaQteqBJmKRFklLIcNMdOz=xbmcgui.Dialog()
   SYjoDwgvEaQteqBJmKRFklLIcNMdOz.notification(__addonname__,sting)
  except:
   SYjoDwgvEaQteqBJmKRFklLIcNMdGH
 def addon_log(SYjoDwgvEaQteqBJmKRFklLIcNMdOG,string):
  try:
   SYjoDwgvEaQteqBJmKRFklLIcNMdOC=string.encode('utf-8','ignore')
  except:
   SYjoDwgvEaQteqBJmKRFklLIcNMdOC='addonException: addon_log'
  SYjoDwgvEaQteqBJmKRFklLIcNMdOf=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,SYjoDwgvEaQteqBJmKRFklLIcNMdOC),level=SYjoDwgvEaQteqBJmKRFklLIcNMdOf)
 def get_keyboard_input(SYjoDwgvEaQteqBJmKRFklLIcNMdOG,SYjoDwgvEaQteqBJmKRFklLIcNMdHP):
  SYjoDwgvEaQteqBJmKRFklLIcNMdOn=SYjoDwgvEaQteqBJmKRFklLIcNMdGH
  kb=xbmc.Keyboard()
  kb.setHeading(SYjoDwgvEaQteqBJmKRFklLIcNMdHP)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   SYjoDwgvEaQteqBJmKRFklLIcNMdOn=kb.getText()
  return SYjoDwgvEaQteqBJmKRFklLIcNMdOn
 def get_settings_account(SYjoDwgvEaQteqBJmKRFklLIcNMdOG):
  SYjoDwgvEaQteqBJmKRFklLIcNMdOW =__addon__.getSetting('id')
  SYjoDwgvEaQteqBJmKRFklLIcNMdOX =__addon__.getSetting('pw')
  SYjoDwgvEaQteqBJmKRFklLIcNMdOy=SYjoDwgvEaQteqBJmKRFklLIcNMdGU(__addon__.getSetting('selected_profile'))
  return(SYjoDwgvEaQteqBJmKRFklLIcNMdOW,SYjoDwgvEaQteqBJmKRFklLIcNMdOX,SYjoDwgvEaQteqBJmKRFklLIcNMdOy)
 def get_settings_totalsearch(SYjoDwgvEaQteqBJmKRFklLIcNMdOG):
  SYjoDwgvEaQteqBJmKRFklLIcNMdOV =SYjoDwgvEaQteqBJmKRFklLIcNMdGi if __addon__.getSetting('local_search')=='true' else SYjoDwgvEaQteqBJmKRFklLIcNMdGh
  SYjoDwgvEaQteqBJmKRFklLIcNMdOu=SYjoDwgvEaQteqBJmKRFklLIcNMdGi if __addon__.getSetting('local_history')=='true' else SYjoDwgvEaQteqBJmKRFklLIcNMdGh
  SYjoDwgvEaQteqBJmKRFklLIcNMdOx =SYjoDwgvEaQteqBJmKRFklLIcNMdGi if __addon__.getSetting('total_search')=='true' else SYjoDwgvEaQteqBJmKRFklLIcNMdGh
  SYjoDwgvEaQteqBJmKRFklLIcNMdOp=SYjoDwgvEaQteqBJmKRFklLIcNMdGi if __addon__.getSetting('total_history')=='true' else SYjoDwgvEaQteqBJmKRFklLIcNMdGh
  SYjoDwgvEaQteqBJmKRFklLIcNMdHO=SYjoDwgvEaQteqBJmKRFklLIcNMdGi if __addon__.getSetting('menu_bookmark')=='true' else SYjoDwgvEaQteqBJmKRFklLIcNMdGh
  return(SYjoDwgvEaQteqBJmKRFklLIcNMdOV,SYjoDwgvEaQteqBJmKRFklLIcNMdOu,SYjoDwgvEaQteqBJmKRFklLIcNMdOx,SYjoDwgvEaQteqBJmKRFklLIcNMdOp,SYjoDwgvEaQteqBJmKRFklLIcNMdHO)
 def get_settings_makebookmark(SYjoDwgvEaQteqBJmKRFklLIcNMdOG):
  return SYjoDwgvEaQteqBJmKRFklLIcNMdGi if __addon__.getSetting('make_bookmark')=='true' else SYjoDwgvEaQteqBJmKRFklLIcNMdGh
 def get_settings_play(SYjoDwgvEaQteqBJmKRFklLIcNMdOG):
  SYjoDwgvEaQteqBJmKRFklLIcNMdHU={'enable_hdr':SYjoDwgvEaQteqBJmKRFklLIcNMdGi if __addon__.getSetting('enable_hdr')=='true' else SYjoDwgvEaQteqBJmKRFklLIcNMdGh,}
  if SYjoDwgvEaQteqBJmKRFklLIcNMdHU['enable_hdr']==SYjoDwgvEaQteqBJmKRFklLIcNMdGi:
   if SYjoDwgvEaQteqBJmKRFklLIcNMdOG.get_selQuality()<1080:SYjoDwgvEaQteqBJmKRFklLIcNMdHU['enable_hdr']=SYjoDwgvEaQteqBJmKRFklLIcNMdGh
  return(SYjoDwgvEaQteqBJmKRFklLIcNMdHU)
 def get_selQuality(SYjoDwgvEaQteqBJmKRFklLIcNMdOG):
  try:
   SYjoDwgvEaQteqBJmKRFklLIcNMdHi=[1080,720,480,360]
   SYjoDwgvEaQteqBJmKRFklLIcNMdHh=SYjoDwgvEaQteqBJmKRFklLIcNMdGU(__addon__.getSetting('selected_quality'))
   return SYjoDwgvEaQteqBJmKRFklLIcNMdHi[SYjoDwgvEaQteqBJmKRFklLIcNMdHh]
  except:
   SYjoDwgvEaQteqBJmKRFklLIcNMdGH
  return 1080 
 def get_settings_exclusion21(SYjoDwgvEaQteqBJmKRFklLIcNMdOG):
  SYjoDwgvEaQteqBJmKRFklLIcNMdHb =__addon__.getSetting('exclusion21')
  if SYjoDwgvEaQteqBJmKRFklLIcNMdHb=='false':
   return SYjoDwgvEaQteqBJmKRFklLIcNMdGh
  else:
   return SYjoDwgvEaQteqBJmKRFklLIcNMdGi
 def get_settings_direct_replay(SYjoDwgvEaQteqBJmKRFklLIcNMdOG):
  SYjoDwgvEaQteqBJmKRFklLIcNMdHs=SYjoDwgvEaQteqBJmKRFklLIcNMdGU(__addon__.getSetting('direct_replay'))
  if SYjoDwgvEaQteqBJmKRFklLIcNMdHs==0:
   return SYjoDwgvEaQteqBJmKRFklLIcNMdGh
  else:
   return SYjoDwgvEaQteqBJmKRFklLIcNMdGi
 def set_winEpisodeOrderby(SYjoDwgvEaQteqBJmKRFklLIcNMdOG,SYjoDwgvEaQteqBJmKRFklLIcNMdHG):
  __addon__.setSetting('wavve_orderby',SYjoDwgvEaQteqBJmKRFklLIcNMdHG)
 def get_winEpisodeOrderby(SYjoDwgvEaQteqBJmKRFklLIcNMdOG):
  SYjoDwgvEaQteqBJmKRFklLIcNMdHG=__addon__.getSetting('wavve_orderby')
  if SYjoDwgvEaQteqBJmKRFklLIcNMdHG in['',SYjoDwgvEaQteqBJmKRFklLIcNMdGH]:SYjoDwgvEaQteqBJmKRFklLIcNMdHG='desc'
  return SYjoDwgvEaQteqBJmKRFklLIcNMdHG
 def add_dir(SYjoDwgvEaQteqBJmKRFklLIcNMdOG,label,sublabel='',img='',infoLabels=SYjoDwgvEaQteqBJmKRFklLIcNMdGH,isFolder=SYjoDwgvEaQteqBJmKRFklLIcNMdGi,params='',isLink=SYjoDwgvEaQteqBJmKRFklLIcNMdGh,ContextMenu=SYjoDwgvEaQteqBJmKRFklLIcNMdGH):
  SYjoDwgvEaQteqBJmKRFklLIcNMdHT='%s?%s'%(SYjoDwgvEaQteqBJmKRFklLIcNMdOG._addon_url,urllib.parse.urlencode(params))
  if sublabel:SYjoDwgvEaQteqBJmKRFklLIcNMdHP='%s < %s >'%(label,sublabel)
  else: SYjoDwgvEaQteqBJmKRFklLIcNMdHP=label
  if not img:img='DefaultFolder.png'
  SYjoDwgvEaQteqBJmKRFklLIcNMdHr=xbmcgui.ListItem(SYjoDwgvEaQteqBJmKRFklLIcNMdHP)
  if SYjoDwgvEaQteqBJmKRFklLIcNMdGb(img)==SYjoDwgvEaQteqBJmKRFklLIcNMdGs:
   SYjoDwgvEaQteqBJmKRFklLIcNMdHr.setArt(img)
  else:
   SYjoDwgvEaQteqBJmKRFklLIcNMdHr.setArt({'thumb':img,'poster':img})
  if infoLabels:SYjoDwgvEaQteqBJmKRFklLIcNMdHr.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   SYjoDwgvEaQteqBJmKRFklLIcNMdHr.setProperty('IsPlayable','true')
  if ContextMenu:SYjoDwgvEaQteqBJmKRFklLIcNMdHr.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(SYjoDwgvEaQteqBJmKRFklLIcNMdOG._addon_handle,SYjoDwgvEaQteqBJmKRFklLIcNMdHT,SYjoDwgvEaQteqBJmKRFklLIcNMdHr,isFolder)
 def dp_Main_List(SYjoDwgvEaQteqBJmKRFklLIcNMdOG):
  (SYjoDwgvEaQteqBJmKRFklLIcNMdOV,SYjoDwgvEaQteqBJmKRFklLIcNMdOu,SYjoDwgvEaQteqBJmKRFklLIcNMdOx,SYjoDwgvEaQteqBJmKRFklLIcNMdOp,SYjoDwgvEaQteqBJmKRFklLIcNMdHO)=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.get_settings_totalsearch()
  for SYjoDwgvEaQteqBJmKRFklLIcNMdHA in SYjoDwgvEaQteqBJmKRFklLIcNMdOU:
   SYjoDwgvEaQteqBJmKRFklLIcNMdHP=SYjoDwgvEaQteqBJmKRFklLIcNMdHA.get('title')
   SYjoDwgvEaQteqBJmKRFklLIcNMdHz=''
   if SYjoDwgvEaQteqBJmKRFklLIcNMdHA.get('mode')=='SEARCH_GROUP' and SYjoDwgvEaQteqBJmKRFklLIcNMdOV ==SYjoDwgvEaQteqBJmKRFklLIcNMdGh:continue
   elif SYjoDwgvEaQteqBJmKRFklLIcNMdHA.get('mode')=='SEARCH_HISTORY' and SYjoDwgvEaQteqBJmKRFklLIcNMdOu==SYjoDwgvEaQteqBJmKRFklLIcNMdGh:continue
   elif SYjoDwgvEaQteqBJmKRFklLIcNMdHA.get('mode')=='TOTAL_SEARCH' and SYjoDwgvEaQteqBJmKRFklLIcNMdOx ==SYjoDwgvEaQteqBJmKRFklLIcNMdGh:continue
   elif SYjoDwgvEaQteqBJmKRFklLIcNMdHA.get('mode')=='TOTAL_HISTORY' and SYjoDwgvEaQteqBJmKRFklLIcNMdOp==SYjoDwgvEaQteqBJmKRFklLIcNMdGh:continue
   elif SYjoDwgvEaQteqBJmKRFklLIcNMdHA.get('mode')=='MENU_BOOKMARK' and SYjoDwgvEaQteqBJmKRFklLIcNMdHO==SYjoDwgvEaQteqBJmKRFklLIcNMdGh:continue
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC={'mode':SYjoDwgvEaQteqBJmKRFklLIcNMdHA.get('mode'),'sCode':SYjoDwgvEaQteqBJmKRFklLIcNMdHA.get('sCode'),'sIndex':SYjoDwgvEaQteqBJmKRFklLIcNMdHA.get('sIndex'),'sType':SYjoDwgvEaQteqBJmKRFklLIcNMdHA.get('sType'),'suburl':SYjoDwgvEaQteqBJmKRFklLIcNMdHA.get('suburl'),'subapi':SYjoDwgvEaQteqBJmKRFklLIcNMdHA.get('subapi'),'page':SYjoDwgvEaQteqBJmKRFklLIcNMdHA.get('page'),'orderby':SYjoDwgvEaQteqBJmKRFklLIcNMdHA.get('orderby'),'ordernm':SYjoDwgvEaQteqBJmKRFklLIcNMdHA.get('ordernm')}
   if SYjoDwgvEaQteqBJmKRFklLIcNMdHA.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    SYjoDwgvEaQteqBJmKRFklLIcNMdHf=SYjoDwgvEaQteqBJmKRFklLIcNMdGh
    SYjoDwgvEaQteqBJmKRFklLIcNMdHn =SYjoDwgvEaQteqBJmKRFklLIcNMdGi
   else:
    SYjoDwgvEaQteqBJmKRFklLIcNMdHf=SYjoDwgvEaQteqBJmKRFklLIcNMdGi
    SYjoDwgvEaQteqBJmKRFklLIcNMdHn =SYjoDwgvEaQteqBJmKRFklLIcNMdGh
   if 'icon' in SYjoDwgvEaQteqBJmKRFklLIcNMdHA:SYjoDwgvEaQteqBJmKRFklLIcNMdHz=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',SYjoDwgvEaQteqBJmKRFklLIcNMdHA.get('icon')) 
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.add_dir(SYjoDwgvEaQteqBJmKRFklLIcNMdHP,sublabel='',img=SYjoDwgvEaQteqBJmKRFklLIcNMdHz,infoLabels=SYjoDwgvEaQteqBJmKRFklLIcNMdGH,isFolder=SYjoDwgvEaQteqBJmKRFklLIcNMdHf,params=SYjoDwgvEaQteqBJmKRFklLIcNMdHC,isLink=SYjoDwgvEaQteqBJmKRFklLIcNMdHn)
  xbmcplugin.endOfDirectory(SYjoDwgvEaQteqBJmKRFklLIcNMdOG._addon_handle,cacheToDisc=SYjoDwgvEaQteqBJmKRFklLIcNMdGi)
 def dp_Search_Group(SYjoDwgvEaQteqBJmKRFklLIcNMdOG,args):
  if 'search_key' in args:
   SYjoDwgvEaQteqBJmKRFklLIcNMdHy=args.get('search_key')
  else:
   SYjoDwgvEaQteqBJmKRFklLIcNMdHy=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not SYjoDwgvEaQteqBJmKRFklLIcNMdHy:
    return
  for SYjoDwgvEaQteqBJmKRFklLIcNMdHV in SYjoDwgvEaQteqBJmKRFklLIcNMdOi:
   SYjoDwgvEaQteqBJmKRFklLIcNMdHu =SYjoDwgvEaQteqBJmKRFklLIcNMdHV.get('mode')
   SYjoDwgvEaQteqBJmKRFklLIcNMdHx=SYjoDwgvEaQteqBJmKRFklLIcNMdHV.get('sType')
   SYjoDwgvEaQteqBJmKRFklLIcNMdHP=SYjoDwgvEaQteqBJmKRFklLIcNMdHV.get('title')
   (SYjoDwgvEaQteqBJmKRFklLIcNMdHp,SYjoDwgvEaQteqBJmKRFklLIcNMdUO)=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.Get_Search_List(SYjoDwgvEaQteqBJmKRFklLIcNMdHy,SYjoDwgvEaQteqBJmKRFklLIcNMdHx,1,exclusion21=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.get_settings_exclusion21())
   SYjoDwgvEaQteqBJmKRFklLIcNMdUH={'plot':'검색어 : '+SYjoDwgvEaQteqBJmKRFklLIcNMdHy+'\n\n'+SYjoDwgvEaQteqBJmKRFklLIcNMdOG.Search_FreeList(SYjoDwgvEaQteqBJmKRFklLIcNMdHp)}
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC={'mode':SYjoDwgvEaQteqBJmKRFklLIcNMdHu,'sType':SYjoDwgvEaQteqBJmKRFklLIcNMdHx,'search_key':SYjoDwgvEaQteqBJmKRFklLIcNMdHy,'page':'1',}
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.add_dir(SYjoDwgvEaQteqBJmKRFklLIcNMdHP,sublabel='',img='',infoLabels=SYjoDwgvEaQteqBJmKRFklLIcNMdUH,isFolder=SYjoDwgvEaQteqBJmKRFklLIcNMdGi,params=SYjoDwgvEaQteqBJmKRFklLIcNMdHC)
  if SYjoDwgvEaQteqBJmKRFklLIcNMdGT(SYjoDwgvEaQteqBJmKRFklLIcNMdOi)>0:xbmcplugin.endOfDirectory(SYjoDwgvEaQteqBJmKRFklLIcNMdOG._addon_handle,cacheToDisc=SYjoDwgvEaQteqBJmKRFklLIcNMdGi)
  SYjoDwgvEaQteqBJmKRFklLIcNMdOG.Save_Searched_List(SYjoDwgvEaQteqBJmKRFklLIcNMdHy)
 def Search_FreeList(SYjoDwgvEaQteqBJmKRFklLIcNMdOG,search_list):
  SYjoDwgvEaQteqBJmKRFklLIcNMdUi=''
  SYjoDwgvEaQteqBJmKRFklLIcNMdUh=7
  try:
   if SYjoDwgvEaQteqBJmKRFklLIcNMdGT(search_list)==0:return '검색결과 없음'
   for i in SYjoDwgvEaQteqBJmKRFklLIcNMdGP(SYjoDwgvEaQteqBJmKRFklLIcNMdGT(search_list)):
    if i>=SYjoDwgvEaQteqBJmKRFklLIcNMdUh:
     SYjoDwgvEaQteqBJmKRFklLIcNMdUi=SYjoDwgvEaQteqBJmKRFklLIcNMdUi+'...'
     break
    SYjoDwgvEaQteqBJmKRFklLIcNMdUi=SYjoDwgvEaQteqBJmKRFklLIcNMdUi+search_list[i]['title']+'\n'
  except:
   return ''
  return SYjoDwgvEaQteqBJmKRFklLIcNMdUi
 def dp_Watch_Group(SYjoDwgvEaQteqBJmKRFklLIcNMdOG,args):
  for SYjoDwgvEaQteqBJmKRFklLIcNMdUb in SYjoDwgvEaQteqBJmKRFklLIcNMdOh:
   SYjoDwgvEaQteqBJmKRFklLIcNMdHP=SYjoDwgvEaQteqBJmKRFklLIcNMdUb.get('title')
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC={'mode':SYjoDwgvEaQteqBJmKRFklLIcNMdUb.get('mode'),'sType':SYjoDwgvEaQteqBJmKRFklLIcNMdUb.get('sType')}
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.add_dir(SYjoDwgvEaQteqBJmKRFklLIcNMdHP,sublabel='',img='',infoLabels=SYjoDwgvEaQteqBJmKRFklLIcNMdGH,isFolder=SYjoDwgvEaQteqBJmKRFklLIcNMdGi,params=SYjoDwgvEaQteqBJmKRFklLIcNMdHC)
  if SYjoDwgvEaQteqBJmKRFklLIcNMdGT(SYjoDwgvEaQteqBJmKRFklLIcNMdOh)>0:xbmcplugin.endOfDirectory(SYjoDwgvEaQteqBJmKRFklLIcNMdOG._addon_handle,cacheToDisc=SYjoDwgvEaQteqBJmKRFklLIcNMdGi)
 def dp_Search_History(SYjoDwgvEaQteqBJmKRFklLIcNMdOG,args):
  SYjoDwgvEaQteqBJmKRFklLIcNMdUs=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.Load_List_File('search')
  for SYjoDwgvEaQteqBJmKRFklLIcNMdUG in SYjoDwgvEaQteqBJmKRFklLIcNMdUs:
   SYjoDwgvEaQteqBJmKRFklLIcNMdUT=SYjoDwgvEaQteqBJmKRFklLIcNMdGs(urllib.parse.parse_qsl(SYjoDwgvEaQteqBJmKRFklLIcNMdUG))
   SYjoDwgvEaQteqBJmKRFklLIcNMdUP=SYjoDwgvEaQteqBJmKRFklLIcNMdUT.get('skey').strip()
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC={'mode':'SEARCH_GROUP','search_key':SYjoDwgvEaQteqBJmKRFklLIcNMdUP,}
   SYjoDwgvEaQteqBJmKRFklLIcNMdUr={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':SYjoDwgvEaQteqBJmKRFklLIcNMdUP,'vType':'-',}
   SYjoDwgvEaQteqBJmKRFklLIcNMdUA=urllib.parse.urlencode(SYjoDwgvEaQteqBJmKRFklLIcNMdUr)
   SYjoDwgvEaQteqBJmKRFklLIcNMdUz=[('선택된 검색어 ( %s ) 삭제'%(SYjoDwgvEaQteqBJmKRFklLIcNMdUP),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(SYjoDwgvEaQteqBJmKRFklLIcNMdUA))]
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.add_dir(SYjoDwgvEaQteqBJmKRFklLIcNMdUP,sublabel='',img=SYjoDwgvEaQteqBJmKRFklLIcNMdGH,infoLabels=SYjoDwgvEaQteqBJmKRFklLIcNMdGH,isFolder=SYjoDwgvEaQteqBJmKRFklLIcNMdGi,params=SYjoDwgvEaQteqBJmKRFklLIcNMdHC,ContextMenu=SYjoDwgvEaQteqBJmKRFklLIcNMdUz)
  SYjoDwgvEaQteqBJmKRFklLIcNMdUC={'plot':'검색목록 전체를 삭제합니다.'}
  SYjoDwgvEaQteqBJmKRFklLIcNMdHP='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  SYjoDwgvEaQteqBJmKRFklLIcNMdHC={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  SYjoDwgvEaQteqBJmKRFklLIcNMdHz=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  SYjoDwgvEaQteqBJmKRFklLIcNMdOG.add_dir(SYjoDwgvEaQteqBJmKRFklLIcNMdHP,sublabel='',img=SYjoDwgvEaQteqBJmKRFklLIcNMdHz,infoLabels=SYjoDwgvEaQteqBJmKRFklLIcNMdUC,isFolder=SYjoDwgvEaQteqBJmKRFklLIcNMdGh,params=SYjoDwgvEaQteqBJmKRFklLIcNMdHC,isLink=SYjoDwgvEaQteqBJmKRFklLIcNMdGi)
  xbmcplugin.endOfDirectory(SYjoDwgvEaQteqBJmKRFklLIcNMdOG._addon_handle,cacheToDisc=SYjoDwgvEaQteqBJmKRFklLIcNMdGh)
 def dp_Search_List(SYjoDwgvEaQteqBJmKRFklLIcNMdOG,args):
  SYjoDwgvEaQteqBJmKRFklLIcNMdHx =args.get('sType')
  SYjoDwgvEaQteqBJmKRFklLIcNMdUf =SYjoDwgvEaQteqBJmKRFklLIcNMdGU(args.get('page'))
  if 'search_key' in args:
   SYjoDwgvEaQteqBJmKRFklLIcNMdHy=args.get('search_key')
  else:
   SYjoDwgvEaQteqBJmKRFklLIcNMdHy=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not SYjoDwgvEaQteqBJmKRFklLIcNMdHy:
    xbmcplugin.endOfDirectory(SYjoDwgvEaQteqBJmKRFklLIcNMdOG._addon_handle)
    return
  SYjoDwgvEaQteqBJmKRFklLIcNMdUn,SYjoDwgvEaQteqBJmKRFklLIcNMdUO=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.Get_Search_List(SYjoDwgvEaQteqBJmKRFklLIcNMdHy,SYjoDwgvEaQteqBJmKRFklLIcNMdHx,SYjoDwgvEaQteqBJmKRFklLIcNMdUf,exclusion21=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.get_settings_exclusion21())
  for SYjoDwgvEaQteqBJmKRFklLIcNMdUW in SYjoDwgvEaQteqBJmKRFklLIcNMdUn:
   SYjoDwgvEaQteqBJmKRFklLIcNMdUX =SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('videoid')
   SYjoDwgvEaQteqBJmKRFklLIcNMdUy =SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('vidtype')
   SYjoDwgvEaQteqBJmKRFklLIcNMdHP =SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('title')
   SYjoDwgvEaQteqBJmKRFklLIcNMdUV=SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('thumbnail')
   SYjoDwgvEaQteqBJmKRFklLIcNMdUu =SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('age')
   if SYjoDwgvEaQteqBJmKRFklLIcNMdUu=='18' or SYjoDwgvEaQteqBJmKRFklLIcNMdUu=='19' or SYjoDwgvEaQteqBJmKRFklLIcNMdUu=='21':SYjoDwgvEaQteqBJmKRFklLIcNMdHP+=' (%s)'%(SYjoDwgvEaQteqBJmKRFklLIcNMdUu)
   SYjoDwgvEaQteqBJmKRFklLIcNMdUC={'mediatype':'tvshow' if SYjoDwgvEaQteqBJmKRFklLIcNMdHx=='vod' else 'movie','mpaa':SYjoDwgvEaQteqBJmKRFklLIcNMdUu,'title':SYjoDwgvEaQteqBJmKRFklLIcNMdHP,'plot':SYjoDwgvEaQteqBJmKRFklLIcNMdHP}
   if SYjoDwgvEaQteqBJmKRFklLIcNMdHx=='vod':
    SYjoDwgvEaQteqBJmKRFklLIcNMdHC={'mode':'EPISODE_LIST','seasonid':SYjoDwgvEaQteqBJmKRFklLIcNMdUX,'page':'1',}
    SYjoDwgvEaQteqBJmKRFklLIcNMdHf=SYjoDwgvEaQteqBJmKRFklLIcNMdGi
   else:
    SYjoDwgvEaQteqBJmKRFklLIcNMdHC={'mode':'MOVIE','contentid':SYjoDwgvEaQteqBJmKRFklLIcNMdUX,'title':SYjoDwgvEaQteqBJmKRFklLIcNMdHP,'thumbnail':SYjoDwgvEaQteqBJmKRFklLIcNMdUV,'age':SYjoDwgvEaQteqBJmKRFklLIcNMdUu,}
    SYjoDwgvEaQteqBJmKRFklLIcNMdHf=SYjoDwgvEaQteqBJmKRFklLIcNMdGh
   SYjoDwgvEaQteqBJmKRFklLIcNMdUz=[]
   SYjoDwgvEaQteqBJmKRFklLIcNMdUx={'mode':'VIEW_DETAIL','values':{'videoid':SYjoDwgvEaQteqBJmKRFklLIcNMdUX,'vidtype':'tvshow' if SYjoDwgvEaQteqBJmKRFklLIcNMdHx=='vod' else 'movie','contenttype':SYjoDwgvEaQteqBJmKRFklLIcNMdUy,}}
   SYjoDwgvEaQteqBJmKRFklLIcNMdUp=json.dumps(SYjoDwgvEaQteqBJmKRFklLIcNMdUx,separators=(',',':'))
   SYjoDwgvEaQteqBJmKRFklLIcNMdUp=base64.standard_b64encode(SYjoDwgvEaQteqBJmKRFklLIcNMdUp.encode()).decode('utf-8')
   SYjoDwgvEaQteqBJmKRFklLIcNMdUp=SYjoDwgvEaQteqBJmKRFklLIcNMdUp.replace('+','%2B')
   SYjoDwgvEaQteqBJmKRFklLIcNMdiO='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(SYjoDwgvEaQteqBJmKRFklLIcNMdUp)
   SYjoDwgvEaQteqBJmKRFklLIcNMdUz.append(('상세정보 조회',SYjoDwgvEaQteqBJmKRFklLIcNMdiO))
   if SYjoDwgvEaQteqBJmKRFklLIcNMdOG.get_settings_makebookmark():
    SYjoDwgvEaQteqBJmKRFklLIcNMdUx={'videoid':SYjoDwgvEaQteqBJmKRFklLIcNMdUX,'vidtype':'tvshow' if SYjoDwgvEaQteqBJmKRFklLIcNMdHx=='vod' else 'movie','vtitle':SYjoDwgvEaQteqBJmKRFklLIcNMdHP,'vsubtitle':'','contenttype':SYjoDwgvEaQteqBJmKRFklLIcNMdUy,}
    SYjoDwgvEaQteqBJmKRFklLIcNMdiH=json.dumps(SYjoDwgvEaQteqBJmKRFklLIcNMdUx)
    SYjoDwgvEaQteqBJmKRFklLIcNMdiH=urllib.parse.quote(SYjoDwgvEaQteqBJmKRFklLIcNMdiH)
    SYjoDwgvEaQteqBJmKRFklLIcNMdiO='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(SYjoDwgvEaQteqBJmKRFklLIcNMdiH)
    SYjoDwgvEaQteqBJmKRFklLIcNMdUz.append(('(통합) 찜 영상에 추가',SYjoDwgvEaQteqBJmKRFklLIcNMdiO))
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.add_dir(SYjoDwgvEaQteqBJmKRFklLIcNMdHP,sublabel='',img=SYjoDwgvEaQteqBJmKRFklLIcNMdUV,infoLabels=SYjoDwgvEaQteqBJmKRFklLIcNMdUC,isFolder=SYjoDwgvEaQteqBJmKRFklLIcNMdHf,params=SYjoDwgvEaQteqBJmKRFklLIcNMdHC,ContextMenu=SYjoDwgvEaQteqBJmKRFklLIcNMdUz)
  if SYjoDwgvEaQteqBJmKRFklLIcNMdUO:
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC['mode'] ='SEARCH_LIST' 
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC['sType']=SYjoDwgvEaQteqBJmKRFklLIcNMdHx 
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC['page'] =SYjoDwgvEaQteqBJmKRFklLIcNMdGr(SYjoDwgvEaQteqBJmKRFklLIcNMdUf+1)
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC['search_key']=SYjoDwgvEaQteqBJmKRFklLIcNMdHy
   SYjoDwgvEaQteqBJmKRFklLIcNMdHP='[B]%s >>[/B]'%'다음 페이지'
   SYjoDwgvEaQteqBJmKRFklLIcNMdiU=SYjoDwgvEaQteqBJmKRFklLIcNMdGr(SYjoDwgvEaQteqBJmKRFklLIcNMdUf+1)
   SYjoDwgvEaQteqBJmKRFklLIcNMdHz=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.add_dir(SYjoDwgvEaQteqBJmKRFklLIcNMdHP,sublabel=SYjoDwgvEaQteqBJmKRFklLIcNMdiU,img=SYjoDwgvEaQteqBJmKRFklLIcNMdHz,infoLabels=SYjoDwgvEaQteqBJmKRFklLIcNMdGH,isFolder=SYjoDwgvEaQteqBJmKRFklLIcNMdGi,params=SYjoDwgvEaQteqBJmKRFklLIcNMdHC)
  if SYjoDwgvEaQteqBJmKRFklLIcNMdHx=='movie':xbmcplugin.setContent(SYjoDwgvEaQteqBJmKRFklLIcNMdOG._addon_handle,'movies')
  else:xbmcplugin.setContent(SYjoDwgvEaQteqBJmKRFklLIcNMdOG._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(SYjoDwgvEaQteqBJmKRFklLIcNMdOG._addon_handle,cacheToDisc=SYjoDwgvEaQteqBJmKRFklLIcNMdGh)
 def dp_Watch_List(SYjoDwgvEaQteqBJmKRFklLIcNMdOG,args):
  SYjoDwgvEaQteqBJmKRFklLIcNMdHx =args.get('sType')
  SYjoDwgvEaQteqBJmKRFklLIcNMdHs=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.get_settings_direct_replay()
  SYjoDwgvEaQteqBJmKRFklLIcNMdUn=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.Load_List_File(SYjoDwgvEaQteqBJmKRFklLIcNMdHx)
  for SYjoDwgvEaQteqBJmKRFklLIcNMdUW in SYjoDwgvEaQteqBJmKRFklLIcNMdUn:
   SYjoDwgvEaQteqBJmKRFklLIcNMdUT=SYjoDwgvEaQteqBJmKRFklLIcNMdGs(urllib.parse.parse_qsl(SYjoDwgvEaQteqBJmKRFklLIcNMdUW))
   SYjoDwgvEaQteqBJmKRFklLIcNMdih =SYjoDwgvEaQteqBJmKRFklLIcNMdUT.get('code').strip()
   SYjoDwgvEaQteqBJmKRFklLIcNMdHP =SYjoDwgvEaQteqBJmKRFklLIcNMdUT.get('title').strip()
   SYjoDwgvEaQteqBJmKRFklLIcNMdiU =SYjoDwgvEaQteqBJmKRFklLIcNMdUT.get('subtitle').strip()
   if SYjoDwgvEaQteqBJmKRFklLIcNMdiU=='None':SYjoDwgvEaQteqBJmKRFklLIcNMdiU=''
   SYjoDwgvEaQteqBJmKRFklLIcNMdUV=SYjoDwgvEaQteqBJmKRFklLIcNMdUT.get('img').strip()
   SYjoDwgvEaQteqBJmKRFklLIcNMdUX =SYjoDwgvEaQteqBJmKRFklLIcNMdUT.get('videoid').strip()
   try:
    SYjoDwgvEaQteqBJmKRFklLIcNMdUV=SYjoDwgvEaQteqBJmKRFklLIcNMdUV.replace('\'','\"')
    SYjoDwgvEaQteqBJmKRFklLIcNMdUV=json.loads(SYjoDwgvEaQteqBJmKRFklLIcNMdUV)
   except:
    SYjoDwgvEaQteqBJmKRFklLIcNMdGH
   SYjoDwgvEaQteqBJmKRFklLIcNMdUC={'plot':'%s\n%s'%(SYjoDwgvEaQteqBJmKRFklLIcNMdHP,SYjoDwgvEaQteqBJmKRFklLIcNMdiU)}
   if SYjoDwgvEaQteqBJmKRFklLIcNMdHx=='vod':
    if SYjoDwgvEaQteqBJmKRFklLIcNMdHs==SYjoDwgvEaQteqBJmKRFklLIcNMdGh or SYjoDwgvEaQteqBJmKRFklLIcNMdUX==SYjoDwgvEaQteqBJmKRFklLIcNMdGH:
     SYjoDwgvEaQteqBJmKRFklLIcNMdUC['mediatype']='tvshow'
     SYjoDwgvEaQteqBJmKRFklLIcNMdHC={'mode':'SEASON_LIST','videoid':SYjoDwgvEaQteqBJmKRFklLIcNMdUX,'vidtype':'contentid',}
     SYjoDwgvEaQteqBJmKRFklLIcNMdHf=SYjoDwgvEaQteqBJmKRFklLIcNMdGi
    else:
     SYjoDwgvEaQteqBJmKRFklLIcNMdUC['mediatype']='episode'
     SYjoDwgvEaQteqBJmKRFklLIcNMdHC={'mode':'VOD','programid':SYjoDwgvEaQteqBJmKRFklLIcNMdih,'contentid':SYjoDwgvEaQteqBJmKRFklLIcNMdUX,'title':SYjoDwgvEaQteqBJmKRFklLIcNMdHP,'subtitle':SYjoDwgvEaQteqBJmKRFklLIcNMdiU,'thumbnail':SYjoDwgvEaQteqBJmKRFklLIcNMdUV}
     SYjoDwgvEaQteqBJmKRFklLIcNMdHf=SYjoDwgvEaQteqBJmKRFklLIcNMdGh
   else:
    SYjoDwgvEaQteqBJmKRFklLIcNMdUC['mediatype']='movie'
    SYjoDwgvEaQteqBJmKRFklLIcNMdHC={'mode':'MOVIE','contentid':SYjoDwgvEaQteqBJmKRFklLIcNMdih,'title':SYjoDwgvEaQteqBJmKRFklLIcNMdHP,'subtitle':SYjoDwgvEaQteqBJmKRFklLIcNMdiU,'thumbnail':SYjoDwgvEaQteqBJmKRFklLIcNMdUV}
    SYjoDwgvEaQteqBJmKRFklLIcNMdHf=SYjoDwgvEaQteqBJmKRFklLIcNMdGh
   SYjoDwgvEaQteqBJmKRFklLIcNMdUr={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':SYjoDwgvEaQteqBJmKRFklLIcNMdih,'vType':SYjoDwgvEaQteqBJmKRFklLIcNMdHx,}
   SYjoDwgvEaQteqBJmKRFklLIcNMdUA=urllib.parse.urlencode(SYjoDwgvEaQteqBJmKRFklLIcNMdUr)
   SYjoDwgvEaQteqBJmKRFklLIcNMdUz=[('선택된 시청이력 ( %s ) 삭제'%(SYjoDwgvEaQteqBJmKRFklLIcNMdHP),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(SYjoDwgvEaQteqBJmKRFklLIcNMdUA))]
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.add_dir(SYjoDwgvEaQteqBJmKRFklLIcNMdHP,sublabel=SYjoDwgvEaQteqBJmKRFklLIcNMdiU,img=SYjoDwgvEaQteqBJmKRFklLIcNMdUV,infoLabels=SYjoDwgvEaQteqBJmKRFklLIcNMdUC,isFolder=SYjoDwgvEaQteqBJmKRFklLIcNMdHf,params=SYjoDwgvEaQteqBJmKRFklLIcNMdHC,ContextMenu=SYjoDwgvEaQteqBJmKRFklLIcNMdUz)
  SYjoDwgvEaQteqBJmKRFklLIcNMdUC={'plot':'시청목록을 삭제합니다.'}
  SYjoDwgvEaQteqBJmKRFklLIcNMdHP='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  SYjoDwgvEaQteqBJmKRFklLIcNMdHC={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':SYjoDwgvEaQteqBJmKRFklLIcNMdHx,}
  SYjoDwgvEaQteqBJmKRFklLIcNMdHz=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  SYjoDwgvEaQteqBJmKRFklLIcNMdOG.add_dir(SYjoDwgvEaQteqBJmKRFklLIcNMdHP,sublabel='',img=SYjoDwgvEaQteqBJmKRFklLIcNMdHz,infoLabels=SYjoDwgvEaQteqBJmKRFklLIcNMdUC,isFolder=SYjoDwgvEaQteqBJmKRFklLIcNMdGh,params=SYjoDwgvEaQteqBJmKRFklLIcNMdHC,isLink=SYjoDwgvEaQteqBJmKRFklLIcNMdGi)
  if SYjoDwgvEaQteqBJmKRFklLIcNMdHx=='movie':xbmcplugin.setContent(SYjoDwgvEaQteqBJmKRFklLIcNMdOG._addon_handle,'movies')
  else:xbmcplugin.setContent(SYjoDwgvEaQteqBJmKRFklLIcNMdOG._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(SYjoDwgvEaQteqBJmKRFklLIcNMdOG._addon_handle,cacheToDisc=SYjoDwgvEaQteqBJmKRFklLIcNMdGh)
 def Load_List_File(SYjoDwgvEaQteqBJmKRFklLIcNMdOG,stype): 
  try:
   if stype=='search':
    SYjoDwgvEaQteqBJmKRFklLIcNMdib=SYjoDwgvEaQteqBJmKRFklLIcNMdOs
   elif stype in['vod','movie']:
    SYjoDwgvEaQteqBJmKRFklLIcNMdib=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   else:
    return[]
   fp=SYjoDwgvEaQteqBJmKRFklLIcNMdGA(SYjoDwgvEaQteqBJmKRFklLIcNMdib,'r',-1,'utf-8')
   SYjoDwgvEaQteqBJmKRFklLIcNMdis=fp.readlines()
   fp.close()
  except:
   SYjoDwgvEaQteqBJmKRFklLIcNMdis=[]
  return SYjoDwgvEaQteqBJmKRFklLIcNMdis
 def Save_Watched_List(SYjoDwgvEaQteqBJmKRFklLIcNMdOG,SYjoDwgvEaQteqBJmKRFklLIcNMdsP,SYjoDwgvEaQteqBJmKRFklLIcNMdOr):
  try:
   SYjoDwgvEaQteqBJmKRFklLIcNMdiG=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%SYjoDwgvEaQteqBJmKRFklLIcNMdsP))
   SYjoDwgvEaQteqBJmKRFklLIcNMdiT=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.Load_List_File(SYjoDwgvEaQteqBJmKRFklLIcNMdsP) 
   fp=SYjoDwgvEaQteqBJmKRFklLIcNMdGA(SYjoDwgvEaQteqBJmKRFklLIcNMdiG,'w',-1,'utf-8')
   SYjoDwgvEaQteqBJmKRFklLIcNMdiP=urllib.parse.urlencode(SYjoDwgvEaQteqBJmKRFklLIcNMdOr)
   SYjoDwgvEaQteqBJmKRFklLIcNMdiP=SYjoDwgvEaQteqBJmKRFklLIcNMdiP+'\n'
   fp.write(SYjoDwgvEaQteqBJmKRFklLIcNMdiP)
   SYjoDwgvEaQteqBJmKRFklLIcNMdir=0
   for SYjoDwgvEaQteqBJmKRFklLIcNMdiA in SYjoDwgvEaQteqBJmKRFklLIcNMdiT:
    SYjoDwgvEaQteqBJmKRFklLIcNMdiz=SYjoDwgvEaQteqBJmKRFklLIcNMdGs(urllib.parse.parse_qsl(SYjoDwgvEaQteqBJmKRFklLIcNMdiA))
    SYjoDwgvEaQteqBJmKRFklLIcNMdiC=SYjoDwgvEaQteqBJmKRFklLIcNMdOr.get('code').strip()
    SYjoDwgvEaQteqBJmKRFklLIcNMdif=SYjoDwgvEaQteqBJmKRFklLIcNMdiz.get('code').strip()
    if SYjoDwgvEaQteqBJmKRFklLIcNMdsP=='vod' and SYjoDwgvEaQteqBJmKRFklLIcNMdOG.get_settings_direct_replay()==SYjoDwgvEaQteqBJmKRFklLIcNMdGi:
     SYjoDwgvEaQteqBJmKRFklLIcNMdiC=SYjoDwgvEaQteqBJmKRFklLIcNMdOr.get('videoid').strip()
     SYjoDwgvEaQteqBJmKRFklLIcNMdif=SYjoDwgvEaQteqBJmKRFklLIcNMdiz.get('videoid').strip()if SYjoDwgvEaQteqBJmKRFklLIcNMdif!=SYjoDwgvEaQteqBJmKRFklLIcNMdGH else '-'
    if SYjoDwgvEaQteqBJmKRFklLIcNMdiC!=SYjoDwgvEaQteqBJmKRFklLIcNMdif:
     fp.write(SYjoDwgvEaQteqBJmKRFklLIcNMdiA)
     SYjoDwgvEaQteqBJmKRFklLIcNMdir+=1
     if SYjoDwgvEaQteqBJmKRFklLIcNMdir>=50:break
   fp.close()
  except:
   SYjoDwgvEaQteqBJmKRFklLIcNMdGH
 def dp_History_Remove(SYjoDwgvEaQteqBJmKRFklLIcNMdOG,args):
  SYjoDwgvEaQteqBJmKRFklLIcNMdin=args.get('delType')
  SYjoDwgvEaQteqBJmKRFklLIcNMdiW =args.get('sKey')
  SYjoDwgvEaQteqBJmKRFklLIcNMdiX =args.get('vType')
  SYjoDwgvEaQteqBJmKRFklLIcNMdOz=xbmcgui.Dialog()
  if SYjoDwgvEaQteqBJmKRFklLIcNMdin=='SEARCH_ALL':
   SYjoDwgvEaQteqBJmKRFklLIcNMdiy=SYjoDwgvEaQteqBJmKRFklLIcNMdOz.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif SYjoDwgvEaQteqBJmKRFklLIcNMdin=='SEARCH_ONE':
   SYjoDwgvEaQteqBJmKRFklLIcNMdiy=SYjoDwgvEaQteqBJmKRFklLIcNMdOz.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif SYjoDwgvEaQteqBJmKRFklLIcNMdin=='WATCH_ALL':
   SYjoDwgvEaQteqBJmKRFklLIcNMdiy=SYjoDwgvEaQteqBJmKRFklLIcNMdOz.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif SYjoDwgvEaQteqBJmKRFklLIcNMdin=='WATCH_ONE':
   SYjoDwgvEaQteqBJmKRFklLIcNMdiy=SYjoDwgvEaQteqBJmKRFklLIcNMdOz.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if SYjoDwgvEaQteqBJmKRFklLIcNMdiy==SYjoDwgvEaQteqBJmKRFklLIcNMdGh:sys.exit()
  if SYjoDwgvEaQteqBJmKRFklLIcNMdin=='SEARCH_ALL':
   if os.path.isfile(SYjoDwgvEaQteqBJmKRFklLIcNMdOs):os.remove(SYjoDwgvEaQteqBJmKRFklLIcNMdOs)
  elif SYjoDwgvEaQteqBJmKRFklLIcNMdin=='SEARCH_ONE':
   try:
    SYjoDwgvEaQteqBJmKRFklLIcNMdib=SYjoDwgvEaQteqBJmKRFklLIcNMdOs
    SYjoDwgvEaQteqBJmKRFklLIcNMdiT=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.Load_List_File('search') 
    fp=SYjoDwgvEaQteqBJmKRFklLIcNMdGA(SYjoDwgvEaQteqBJmKRFklLIcNMdib,'w',-1,'utf-8')
    for SYjoDwgvEaQteqBJmKRFklLIcNMdiA in SYjoDwgvEaQteqBJmKRFklLIcNMdiT:
     SYjoDwgvEaQteqBJmKRFklLIcNMdiz=SYjoDwgvEaQteqBJmKRFklLIcNMdGs(urllib.parse.parse_qsl(SYjoDwgvEaQteqBJmKRFklLIcNMdiA))
     SYjoDwgvEaQteqBJmKRFklLIcNMdiV=SYjoDwgvEaQteqBJmKRFklLIcNMdiz.get('skey').strip()
     if SYjoDwgvEaQteqBJmKRFklLIcNMdiW!=SYjoDwgvEaQteqBJmKRFklLIcNMdiV:
      fp.write(SYjoDwgvEaQteqBJmKRFklLIcNMdiA)
    fp.close()
   except:
    SYjoDwgvEaQteqBJmKRFklLIcNMdGH
  elif SYjoDwgvEaQteqBJmKRFklLIcNMdin=='WATCH_ALL':
   SYjoDwgvEaQteqBJmKRFklLIcNMdib=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%SYjoDwgvEaQteqBJmKRFklLIcNMdiX))
   if os.path.isfile(SYjoDwgvEaQteqBJmKRFklLIcNMdib):os.remove(SYjoDwgvEaQteqBJmKRFklLIcNMdib)
  elif SYjoDwgvEaQteqBJmKRFklLIcNMdin=='WATCH_ONE':
   SYjoDwgvEaQteqBJmKRFklLIcNMdib=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%SYjoDwgvEaQteqBJmKRFklLIcNMdiX))
   try:
    SYjoDwgvEaQteqBJmKRFklLIcNMdiT=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.Load_List_File(SYjoDwgvEaQteqBJmKRFklLIcNMdiX) 
    fp=SYjoDwgvEaQteqBJmKRFklLIcNMdGA(SYjoDwgvEaQteqBJmKRFklLIcNMdib,'w',-1,'utf-8')
    for SYjoDwgvEaQteqBJmKRFklLIcNMdiA in SYjoDwgvEaQteqBJmKRFklLIcNMdiT:
     SYjoDwgvEaQteqBJmKRFklLIcNMdiz=SYjoDwgvEaQteqBJmKRFklLIcNMdGs(urllib.parse.parse_qsl(SYjoDwgvEaQteqBJmKRFklLIcNMdiA))
     SYjoDwgvEaQteqBJmKRFklLIcNMdiV=SYjoDwgvEaQteqBJmKRFklLIcNMdiz.get('code').strip()
     if SYjoDwgvEaQteqBJmKRFklLIcNMdiW!=SYjoDwgvEaQteqBJmKRFklLIcNMdiV:
      fp.write(SYjoDwgvEaQteqBJmKRFklLIcNMdiA)
    fp.close()
   except:
    SYjoDwgvEaQteqBJmKRFklLIcNMdGH
  xbmc.executebuiltin("Container.Refresh")
 def Save_Searched_List(SYjoDwgvEaQteqBJmKRFklLIcNMdOG,SYjoDwgvEaQteqBJmKRFklLIcNMdHy):
  try:
   SYjoDwgvEaQteqBJmKRFklLIcNMdiu=SYjoDwgvEaQteqBJmKRFklLIcNMdOs
   SYjoDwgvEaQteqBJmKRFklLIcNMdiT=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.Load_List_File('search') 
   SYjoDwgvEaQteqBJmKRFklLIcNMdix={'skey':SYjoDwgvEaQteqBJmKRFklLIcNMdHy.strip()}
   fp=SYjoDwgvEaQteqBJmKRFklLIcNMdGA(SYjoDwgvEaQteqBJmKRFklLIcNMdiu,'w',-1,'utf-8')
   SYjoDwgvEaQteqBJmKRFklLIcNMdiP=urllib.parse.urlencode(SYjoDwgvEaQteqBJmKRFklLIcNMdix)
   SYjoDwgvEaQteqBJmKRFklLIcNMdiP=SYjoDwgvEaQteqBJmKRFklLIcNMdiP+'\n'
   fp.write(SYjoDwgvEaQteqBJmKRFklLIcNMdiP)
   SYjoDwgvEaQteqBJmKRFklLIcNMdir=0
   for SYjoDwgvEaQteqBJmKRFklLIcNMdiA in SYjoDwgvEaQteqBJmKRFklLIcNMdiT:
    SYjoDwgvEaQteqBJmKRFklLIcNMdiz=SYjoDwgvEaQteqBJmKRFklLIcNMdGs(urllib.parse.parse_qsl(SYjoDwgvEaQteqBJmKRFklLIcNMdiA))
    SYjoDwgvEaQteqBJmKRFklLIcNMdiC=SYjoDwgvEaQteqBJmKRFklLIcNMdix.get('skey').strip()
    SYjoDwgvEaQteqBJmKRFklLIcNMdif=SYjoDwgvEaQteqBJmKRFklLIcNMdiz.get('skey').strip()
    if SYjoDwgvEaQteqBJmKRFklLIcNMdiC!=SYjoDwgvEaQteqBJmKRFklLIcNMdif:
     fp.write(SYjoDwgvEaQteqBJmKRFklLIcNMdiA)
     SYjoDwgvEaQteqBJmKRFklLIcNMdir+=1
     if SYjoDwgvEaQteqBJmKRFklLIcNMdir>=50:break
   fp.close()
  except:
   SYjoDwgvEaQteqBJmKRFklLIcNMdGH
 def dp_Global_Search(SYjoDwgvEaQteqBJmKRFklLIcNMdOG,args):
  SYjoDwgvEaQteqBJmKRFklLIcNMdHu=args.get('mode')
  if SYjoDwgvEaQteqBJmKRFklLIcNMdHu=='TOTAL_SEARCH':
   SYjoDwgvEaQteqBJmKRFklLIcNMdip='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   SYjoDwgvEaQteqBJmKRFklLIcNMdip='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(SYjoDwgvEaQteqBJmKRFklLIcNMdip)
 def dp_Bookmark_Menu(SYjoDwgvEaQteqBJmKRFklLIcNMdOG,args):
  SYjoDwgvEaQteqBJmKRFklLIcNMdip='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(SYjoDwgvEaQteqBJmKRFklLIcNMdip)
 def login_main(SYjoDwgvEaQteqBJmKRFklLIcNMdOG):
  (SYjoDwgvEaQteqBJmKRFklLIcNMdhO,SYjoDwgvEaQteqBJmKRFklLIcNMdhH,SYjoDwgvEaQteqBJmKRFklLIcNMdhU)=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.get_settings_account()
  if not(SYjoDwgvEaQteqBJmKRFklLIcNMdhO and SYjoDwgvEaQteqBJmKRFklLIcNMdhH):
   SYjoDwgvEaQteqBJmKRFklLIcNMdOz=xbmcgui.Dialog()
   SYjoDwgvEaQteqBJmKRFklLIcNMdiy=SYjoDwgvEaQteqBJmKRFklLIcNMdOz.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if SYjoDwgvEaQteqBJmKRFklLIcNMdiy==SYjoDwgvEaQteqBJmKRFklLIcNMdGi:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if SYjoDwgvEaQteqBJmKRFklLIcNMdOG.cookiefile_check()==SYjoDwgvEaQteqBJmKRFklLIcNMdGi:return
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   SYjoDwgvEaQteqBJmKRFklLIcNMdhi=0
   while SYjoDwgvEaQteqBJmKRFklLIcNMdGi:
    SYjoDwgvEaQteqBJmKRFklLIcNMdhi+=1
    time.sleep(0.05)
    if SYjoDwgvEaQteqBJmKRFklLIcNMdhi>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  SYjoDwgvEaQteqBJmKRFklLIcNMdhb=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.GetCredential(SYjoDwgvEaQteqBJmKRFklLIcNMdhO,SYjoDwgvEaQteqBJmKRFklLIcNMdhH,SYjoDwgvEaQteqBJmKRFklLIcNMdhU)
  if SYjoDwgvEaQteqBJmKRFklLIcNMdhb:SYjoDwgvEaQteqBJmKRFklLIcNMdOG.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
  if SYjoDwgvEaQteqBJmKRFklLIcNMdhb==SYjoDwgvEaQteqBJmKRFklLIcNMdGh:
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_setEpOrderby(SYjoDwgvEaQteqBJmKRFklLIcNMdOG,args):
  SYjoDwgvEaQteqBJmKRFklLIcNMdHG =args.get('orderby')
  SYjoDwgvEaQteqBJmKRFklLIcNMdOG.set_winEpisodeOrderby(SYjoDwgvEaQteqBJmKRFklLIcNMdHG)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(SYjoDwgvEaQteqBJmKRFklLIcNMdOG,args):
  SYjoDwgvEaQteqBJmKRFklLIcNMdHu =args.get('mode')
  SYjoDwgvEaQteqBJmKRFklLIcNMdhs =args.get('contentid')
  SYjoDwgvEaQteqBJmKRFklLIcNMdhG =args.get('pvrmode')
  SYjoDwgvEaQteqBJmKRFklLIcNMdhT=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.get_selQuality()
  SYjoDwgvEaQteqBJmKRFklLIcNMdHU =SYjoDwgvEaQteqBJmKRFklLIcNMdOG.get_settings_play()
  SYjoDwgvEaQteqBJmKRFklLIcNMdOG.addon_log(SYjoDwgvEaQteqBJmKRFklLIcNMdhs+' - '+SYjoDwgvEaQteqBJmKRFklLIcNMdHu)
  if SYjoDwgvEaQteqBJmKRFklLIcNMdHu=='SPORTS':
   SYjoDwgvEaQteqBJmKRFklLIcNMdhP=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.GetSportsURL(SYjoDwgvEaQteqBJmKRFklLIcNMdhs,SYjoDwgvEaQteqBJmKRFklLIcNMdhT)
  else:
   SYjoDwgvEaQteqBJmKRFklLIcNMdhP=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.GetStreamingURL(SYjoDwgvEaQteqBJmKRFklLIcNMdHu,SYjoDwgvEaQteqBJmKRFklLIcNMdhs,SYjoDwgvEaQteqBJmKRFklLIcNMdhT,SYjoDwgvEaQteqBJmKRFklLIcNMdhG,playOption=SYjoDwgvEaQteqBJmKRFklLIcNMdHU)
  SYjoDwgvEaQteqBJmKRFklLIcNMdhr=SYjoDwgvEaQteqBJmKRFklLIcNMdhP['stream_cookie']
  SYjoDwgvEaQteqBJmKRFklLIcNMdhA='{}|Cookie={}'.format(SYjoDwgvEaQteqBJmKRFklLIcNMdhP['stream_url'],SYjoDwgvEaQteqBJmKRFklLIcNMdhr)
  SYjoDwgvEaQteqBJmKRFklLIcNMdOG.addon_log(SYjoDwgvEaQteqBJmKRFklLIcNMdhA)
  if SYjoDwgvEaQteqBJmKRFklLIcNMdhP['stream_url']=='':
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.addon_noti(__language__(30907).encode('utf8'))
   return
  SYjoDwgvEaQteqBJmKRFklLIcNMdhz=xbmcgui.ListItem(path=SYjoDwgvEaQteqBJmKRFklLIcNMdhA)
  if SYjoDwgvEaQteqBJmKRFklLIcNMdhP['stream_drm']:
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.addon_log('!!streaming_drm!!')
   SYjoDwgvEaQteqBJmKRFklLIcNMdhC=SYjoDwgvEaQteqBJmKRFklLIcNMdhP['stream_drm']['customdata']
   SYjoDwgvEaQteqBJmKRFklLIcNMdhf =SYjoDwgvEaQteqBJmKRFklLIcNMdhP['stream_drm']['drmhost']
   SYjoDwgvEaQteqBJmKRFklLIcNMdhn =inputstreamhelper.Helper('mpd',drm='widevine')
   if SYjoDwgvEaQteqBJmKRFklLIcNMdhn.check_inputstream():
    if SYjoDwgvEaQteqBJmKRFklLIcNMdHu=='MOVIE':
     SYjoDwgvEaQteqBJmKRFklLIcNMdhW='https://www.wavve.com/player/movie?movieid=%s'%SYjoDwgvEaQteqBJmKRFklLIcNMdhs
    else:
     SYjoDwgvEaQteqBJmKRFklLIcNMdhW='https://www.wavve.com/player/vod?programid=%s&page=1'%SYjoDwgvEaQteqBJmKRFklLIcNMdhs
    SYjoDwgvEaQteqBJmKRFklLIcNMdhX={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':SYjoDwgvEaQteqBJmKRFklLIcNMdhC,'referer':SYjoDwgvEaQteqBJmKRFklLIcNMdhW,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.USER_AGENT,}
    SYjoDwgvEaQteqBJmKRFklLIcNMdhy=SYjoDwgvEaQteqBJmKRFklLIcNMdhf+'|'+urllib.parse.urlencode(SYjoDwgvEaQteqBJmKRFklLIcNMdhX)+'|R{SSM}|'
    SYjoDwgvEaQteqBJmKRFklLIcNMdhz.setProperty('inputstream',SYjoDwgvEaQteqBJmKRFklLIcNMdhn.inputstream_addon)
    SYjoDwgvEaQteqBJmKRFklLIcNMdhz.setProperty('inputstream.adaptive.manifest_type','mpd')
    SYjoDwgvEaQteqBJmKRFklLIcNMdhz.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    SYjoDwgvEaQteqBJmKRFklLIcNMdhz.setProperty('inputstream.adaptive.license_key',SYjoDwgvEaQteqBJmKRFklLIcNMdhy)
    SYjoDwgvEaQteqBJmKRFklLIcNMdhz.setProperty('inputstream.adaptive.stream_headers','user-agent={}&Cookie={}'.format(SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.USER_AGENT,SYjoDwgvEaQteqBJmKRFklLIcNMdhr))
  elif SYjoDwgvEaQteqBJmKRFklLIcNMdHu in['VOD','MOVIE']:
   SYjoDwgvEaQteqBJmKRFklLIcNMdhz.setContentLookup(SYjoDwgvEaQteqBJmKRFklLIcNMdGh)
   SYjoDwgvEaQteqBJmKRFklLIcNMdhz.setMimeType('application/x-mpegURL')
   SYjoDwgvEaQteqBJmKRFklLIcNMdhz.setProperty('inputstream','inputstream.adaptive')
   if SYjoDwgvEaQteqBJmKRFklLIcNMdhP['stream_action']=='hls':
    SYjoDwgvEaQteqBJmKRFklLIcNMdhz.setProperty('inputstream.adaptive.manifest_type','hls')
   else:
    SYjoDwgvEaQteqBJmKRFklLIcNMdhz.setProperty('inputstream.adaptive.manifest_type','mpd')
   SYjoDwgvEaQteqBJmKRFklLIcNMdhz.setProperty('inputstream.adaptive.stream_headers','user-agent={}&Cookie={}'.format(SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.USER_AGENT,SYjoDwgvEaQteqBJmKRFklLIcNMdhr))
  if SYjoDwgvEaQteqBJmKRFklLIcNMdhP['stream_vtt']:
   SYjoDwgvEaQteqBJmKRFklLIcNMdhz.setSubtitles([SYjoDwgvEaQteqBJmKRFklLIcNMdhP['stream_vtt']])
  xbmcplugin.setResolvedUrl(SYjoDwgvEaQteqBJmKRFklLIcNMdOG._addon_handle,SYjoDwgvEaQteqBJmKRFklLIcNMdGi,SYjoDwgvEaQteqBJmKRFklLIcNMdhz)
  SYjoDwgvEaQteqBJmKRFklLIcNMdhV=SYjoDwgvEaQteqBJmKRFklLIcNMdGh
  if SYjoDwgvEaQteqBJmKRFklLIcNMdhP['stream_preview']:
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.addon_noti(SYjoDwgvEaQteqBJmKRFklLIcNMdhP['stream_preview'].encode('utf-8'))
   SYjoDwgvEaQteqBJmKRFklLIcNMdhV=SYjoDwgvEaQteqBJmKRFklLIcNMdGi
  else:
   if '/preview.' in urllib.parse.urlsplit(SYjoDwgvEaQteqBJmKRFklLIcNMdhP['stream_url']).path:
    SYjoDwgvEaQteqBJmKRFklLIcNMdOG.addon_noti(__language__(30908).encode('utf8'))
    SYjoDwgvEaQteqBJmKRFklLIcNMdhV=SYjoDwgvEaQteqBJmKRFklLIcNMdGi
  try:
   SYjoDwgvEaQteqBJmKRFklLIcNMdhu=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and SYjoDwgvEaQteqBJmKRFklLIcNMdhV==SYjoDwgvEaQteqBJmKRFklLIcNMdGh and SYjoDwgvEaQteqBJmKRFklLIcNMdhu!='-':
    SYjoDwgvEaQteqBJmKRFklLIcNMdHC={'code':SYjoDwgvEaQteqBJmKRFklLIcNMdhu,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    SYjoDwgvEaQteqBJmKRFklLIcNMdOG.Save_Watched_List(args.get('mode').lower(),SYjoDwgvEaQteqBJmKRFklLIcNMdHC)
  except:
   SYjoDwgvEaQteqBJmKRFklLIcNMdGH
 def logout(SYjoDwgvEaQteqBJmKRFklLIcNMdOG):
  SYjoDwgvEaQteqBJmKRFklLIcNMdOz=xbmcgui.Dialog()
  SYjoDwgvEaQteqBJmKRFklLIcNMdiy=SYjoDwgvEaQteqBJmKRFklLIcNMdOz.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if SYjoDwgvEaQteqBJmKRFklLIcNMdiy==SYjoDwgvEaQteqBJmKRFklLIcNMdGh:sys.exit()
  SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.Init_WV_Total()
  if os.path.isfile(SYjoDwgvEaQteqBJmKRFklLIcNMdOb):os.remove(SYjoDwgvEaQteqBJmKRFklLIcNMdOb)
  SYjoDwgvEaQteqBJmKRFklLIcNMdOG.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(SYjoDwgvEaQteqBJmKRFklLIcNMdOG):
  SYjoDwgvEaQteqBJmKRFklLIcNMdhx =SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.Get_Now_Datetime()
  SYjoDwgvEaQteqBJmKRFklLIcNMdhp=SYjoDwgvEaQteqBJmKRFklLIcNMdhx+datetime.timedelta(days=SYjoDwgvEaQteqBJmKRFklLIcNMdGU(__addon__.getSetting('cache_ttl')))
  (SYjoDwgvEaQteqBJmKRFklLIcNMdhO,SYjoDwgvEaQteqBJmKRFklLIcNMdhH,SYjoDwgvEaQteqBJmKRFklLIcNMdhU)=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.get_settings_account()
  SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.Save_session_acount(SYjoDwgvEaQteqBJmKRFklLIcNMdhO,SYjoDwgvEaQteqBJmKRFklLIcNMdhH,SYjoDwgvEaQteqBJmKRFklLIcNMdhU)
  SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.WV['account']['token_limit']=SYjoDwgvEaQteqBJmKRFklLIcNMdhp.strftime('%Y%m%d')
  SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.JsonFile_Save(SYjoDwgvEaQteqBJmKRFklLIcNMdOb,SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.WV)
 def cookiefile_check(SYjoDwgvEaQteqBJmKRFklLIcNMdOG):
  SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.WV=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.JsonFile_Load(SYjoDwgvEaQteqBJmKRFklLIcNMdOb)
  if 'account' not in SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.WV:
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.Init_WV_Total()
   return SYjoDwgvEaQteqBJmKRFklLIcNMdGh
  if 'uuid' not in SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.WV.get('cookies'):
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.Init_WV_Total()
   return SYjoDwgvEaQteqBJmKRFklLIcNMdGh
  (SYjoDwgvEaQteqBJmKRFklLIcNMdbO,SYjoDwgvEaQteqBJmKRFklLIcNMdbH,SYjoDwgvEaQteqBJmKRFklLIcNMdbU)=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.get_settings_account()
  (SYjoDwgvEaQteqBJmKRFklLIcNMdbi,SYjoDwgvEaQteqBJmKRFklLIcNMdbh,SYjoDwgvEaQteqBJmKRFklLIcNMdbs)=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.Load_session_acount()
  if SYjoDwgvEaQteqBJmKRFklLIcNMdbO!=SYjoDwgvEaQteqBJmKRFklLIcNMdbi or SYjoDwgvEaQteqBJmKRFklLIcNMdbH!=SYjoDwgvEaQteqBJmKRFklLIcNMdbh or SYjoDwgvEaQteqBJmKRFklLIcNMdbU!=SYjoDwgvEaQteqBJmKRFklLIcNMdbs:
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.Init_WV_Total()
   return SYjoDwgvEaQteqBJmKRFklLIcNMdGh
  if SYjoDwgvEaQteqBJmKRFklLIcNMdGU(SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))>SYjoDwgvEaQteqBJmKRFklLIcNMdGU(SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.WV['account']['token_limit']):
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.Init_WV_Total()
   return SYjoDwgvEaQteqBJmKRFklLIcNMdGh
  return SYjoDwgvEaQteqBJmKRFklLIcNMdGi
 def dp_LiveCatagory_List(SYjoDwgvEaQteqBJmKRFklLIcNMdOG,args):
  SYjoDwgvEaQteqBJmKRFklLIcNMdbG =args.get('sCode')
  SYjoDwgvEaQteqBJmKRFklLIcNMdbT=args.get('sIndex')
  SYjoDwgvEaQteqBJmKRFklLIcNMdUn,SYjoDwgvEaQteqBJmKRFklLIcNMdbP=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.Get_LiveCatagory_List(SYjoDwgvEaQteqBJmKRFklLIcNMdbG,SYjoDwgvEaQteqBJmKRFklLIcNMdbT)
  for SYjoDwgvEaQteqBJmKRFklLIcNMdUW in SYjoDwgvEaQteqBJmKRFklLIcNMdUn:
   SYjoDwgvEaQteqBJmKRFklLIcNMdHP =SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('title')
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC={'mode':'LIVE_LIST','genre':SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('genre'),'baseapi':SYjoDwgvEaQteqBJmKRFklLIcNMdbP}
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.add_dir(SYjoDwgvEaQteqBJmKRFklLIcNMdHP,sublabel='',img='',infoLabels=SYjoDwgvEaQteqBJmKRFklLIcNMdGH,isFolder=SYjoDwgvEaQteqBJmKRFklLIcNMdGi,params=SYjoDwgvEaQteqBJmKRFklLIcNMdHC)
  if SYjoDwgvEaQteqBJmKRFklLIcNMdGT(SYjoDwgvEaQteqBJmKRFklLIcNMdUn)>0:xbmcplugin.endOfDirectory(SYjoDwgvEaQteqBJmKRFklLIcNMdOG._addon_handle,cacheToDisc=SYjoDwgvEaQteqBJmKRFklLIcNMdGh)
 def dp_MainCatagory_List(SYjoDwgvEaQteqBJmKRFklLIcNMdOG,args):
  SYjoDwgvEaQteqBJmKRFklLIcNMdbG =args.get('sCode')
  SYjoDwgvEaQteqBJmKRFklLIcNMdbT=args.get('sIndex')
  SYjoDwgvEaQteqBJmKRFklLIcNMdHx =args.get('sType')
  SYjoDwgvEaQteqBJmKRFklLIcNMdUn=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.Get_MainCatagory_List(SYjoDwgvEaQteqBJmKRFklLIcNMdbG,SYjoDwgvEaQteqBJmKRFklLIcNMdbT,SYjoDwgvEaQteqBJmKRFklLIcNMdHx)
  for SYjoDwgvEaQteqBJmKRFklLIcNMdUW in SYjoDwgvEaQteqBJmKRFklLIcNMdUn:
   if SYjoDwgvEaQteqBJmKRFklLIcNMdHx in['vod','vod09']:
    if SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('subtype')=='catagory':
     SYjoDwgvEaQteqBJmKRFklLIcNMdHu='PROGRAM_LIST'
    else:
     SYjoDwgvEaQteqBJmKRFklLIcNMdHu='SUPERSECTION_LIST'
   elif SYjoDwgvEaQteqBJmKRFklLIcNMdHx=='movie':
    SYjoDwgvEaQteqBJmKRFklLIcNMdHu='MOVIE_LIST'
   else:
    SYjoDwgvEaQteqBJmKRFklLIcNMdHu=''
   SYjoDwgvEaQteqBJmKRFklLIcNMdHP='%s (%s)'%(SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('title'),args.get('ordernm'))
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC={'mode':SYjoDwgvEaQteqBJmKRFklLIcNMdHu,'suburl':SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('suburl'),'subapi':SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if SYjoDwgvEaQteqBJmKRFklLIcNMdOG.get_settings_exclusion21():
    if SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('title')=='성인' or SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('title')=='성인+' or SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('title')=='에로티시즘' or SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('title')=='19':continue
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.add_dir(SYjoDwgvEaQteqBJmKRFklLIcNMdHP,sublabel='',img='',infoLabels=SYjoDwgvEaQteqBJmKRFklLIcNMdGH,isFolder=SYjoDwgvEaQteqBJmKRFklLIcNMdGi,params=SYjoDwgvEaQteqBJmKRFklLIcNMdHC)
  if SYjoDwgvEaQteqBJmKRFklLIcNMdGT(SYjoDwgvEaQteqBJmKRFklLIcNMdUn)>0:xbmcplugin.endOfDirectory(SYjoDwgvEaQteqBJmKRFklLIcNMdOG._addon_handle,cacheToDisc=SYjoDwgvEaQteqBJmKRFklLIcNMdGh)
 def dp_Program_List(SYjoDwgvEaQteqBJmKRFklLIcNMdOG,args):
  SYjoDwgvEaQteqBJmKRFklLIcNMdbr =args.get('subapi')
  SYjoDwgvEaQteqBJmKRFklLIcNMdUf=SYjoDwgvEaQteqBJmKRFklLIcNMdGU(args.get('page'))
  SYjoDwgvEaQteqBJmKRFklLIcNMdHG =args.get('orderby')
  SYjoDwgvEaQteqBJmKRFklLIcNMdOG.addon_log('dp_Program_List')
  SYjoDwgvEaQteqBJmKRFklLIcNMdOG.addon_log(SYjoDwgvEaQteqBJmKRFklLIcNMdbr)
  SYjoDwgvEaQteqBJmKRFklLIcNMdUn,SYjoDwgvEaQteqBJmKRFklLIcNMdUO=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.Get_Program_List(SYjoDwgvEaQteqBJmKRFklLIcNMdbr,SYjoDwgvEaQteqBJmKRFklLIcNMdUf,SYjoDwgvEaQteqBJmKRFklLIcNMdHG)
  for SYjoDwgvEaQteqBJmKRFklLIcNMdUW in SYjoDwgvEaQteqBJmKRFklLIcNMdUn:
   SYjoDwgvEaQteqBJmKRFklLIcNMdUX =SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('videoid')
   SYjoDwgvEaQteqBJmKRFklLIcNMdUy =SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('vidtype')
   SYjoDwgvEaQteqBJmKRFklLIcNMdHP =SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('title')
   SYjoDwgvEaQteqBJmKRFklLIcNMdUV=SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('thumbnail')
   SYjoDwgvEaQteqBJmKRFklLIcNMdUu =SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('age')
   if SYjoDwgvEaQteqBJmKRFklLIcNMdUu=='18' or SYjoDwgvEaQteqBJmKRFklLIcNMdUu=='19' or SYjoDwgvEaQteqBJmKRFklLIcNMdUu=='21':SYjoDwgvEaQteqBJmKRFklLIcNMdHP+=' (%s)'%(SYjoDwgvEaQteqBJmKRFklLIcNMdUu)
   SYjoDwgvEaQteqBJmKRFklLIcNMdUC={'plot':SYjoDwgvEaQteqBJmKRFklLIcNMdHP,'mpaa':SYjoDwgvEaQteqBJmKRFklLIcNMdUu,'mediatype':'tvshow',}
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC={'mode':'SEASON_LIST','videoid':SYjoDwgvEaQteqBJmKRFklLIcNMdUX,'vidtype':SYjoDwgvEaQteqBJmKRFklLIcNMdUy,}
   SYjoDwgvEaQteqBJmKRFklLIcNMdUz=[]
   SYjoDwgvEaQteqBJmKRFklLIcNMdUx={'mode':'VIEW_DETAIL','values':{'videoid':SYjoDwgvEaQteqBJmKRFklLIcNMdUX,'vidtype':'tvshow','contenttype':SYjoDwgvEaQteqBJmKRFklLIcNMdUy,}}
   SYjoDwgvEaQteqBJmKRFklLIcNMdUp=json.dumps(SYjoDwgvEaQteqBJmKRFklLIcNMdUx,separators=(',',':'))
   SYjoDwgvEaQteqBJmKRFklLIcNMdUp=base64.standard_b64encode(SYjoDwgvEaQteqBJmKRFklLIcNMdUp.encode()).decode('utf-8')
   SYjoDwgvEaQteqBJmKRFklLIcNMdUp=SYjoDwgvEaQteqBJmKRFklLIcNMdUp.replace('+','%2B')
   SYjoDwgvEaQteqBJmKRFklLIcNMdiO='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(SYjoDwgvEaQteqBJmKRFklLIcNMdUp)
   SYjoDwgvEaQteqBJmKRFklLIcNMdUz.append(('상세정보 조회',SYjoDwgvEaQteqBJmKRFklLIcNMdiO))
   if SYjoDwgvEaQteqBJmKRFklLIcNMdOG.get_settings_makebookmark():
    SYjoDwgvEaQteqBJmKRFklLIcNMdUx={'videoid':SYjoDwgvEaQteqBJmKRFklLIcNMdUX,'vidtype':'tvshow','vtitle':SYjoDwgvEaQteqBJmKRFklLIcNMdHP,'vsubtitle':'','contenttype':SYjoDwgvEaQteqBJmKRFklLIcNMdUy,}
    SYjoDwgvEaQteqBJmKRFklLIcNMdiH=json.dumps(SYjoDwgvEaQteqBJmKRFklLIcNMdUx)
    SYjoDwgvEaQteqBJmKRFklLIcNMdiH=urllib.parse.quote(SYjoDwgvEaQteqBJmKRFklLIcNMdiH)
    SYjoDwgvEaQteqBJmKRFklLIcNMdiO='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(SYjoDwgvEaQteqBJmKRFklLIcNMdiH)
    SYjoDwgvEaQteqBJmKRFklLIcNMdUz.append(('(통합) 찜 영상에 추가',SYjoDwgvEaQteqBJmKRFklLIcNMdiO))
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.add_dir(SYjoDwgvEaQteqBJmKRFklLIcNMdHP,sublabel='',img=SYjoDwgvEaQteqBJmKRFklLIcNMdUV,infoLabels=SYjoDwgvEaQteqBJmKRFklLIcNMdUC,isFolder=SYjoDwgvEaQteqBJmKRFklLIcNMdGi,params=SYjoDwgvEaQteqBJmKRFklLIcNMdHC,ContextMenu=SYjoDwgvEaQteqBJmKRFklLIcNMdUz)
  if SYjoDwgvEaQteqBJmKRFklLIcNMdUO:
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC={}
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC['mode'] ='PROGRAM_LIST' 
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC['subapi']=SYjoDwgvEaQteqBJmKRFklLIcNMdbr 
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC['page'] =SYjoDwgvEaQteqBJmKRFklLIcNMdGr(SYjoDwgvEaQteqBJmKRFklLIcNMdUf+1)
   SYjoDwgvEaQteqBJmKRFklLIcNMdHP='[B]%s >>[/B]'%'다음 페이지'
   SYjoDwgvEaQteqBJmKRFklLIcNMdiU=SYjoDwgvEaQteqBJmKRFklLIcNMdGr(SYjoDwgvEaQteqBJmKRFklLIcNMdUf+1)
   SYjoDwgvEaQteqBJmKRFklLIcNMdHz=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.add_dir(SYjoDwgvEaQteqBJmKRFklLIcNMdHP,sublabel=SYjoDwgvEaQteqBJmKRFklLIcNMdiU,img=SYjoDwgvEaQteqBJmKRFklLIcNMdHz,infoLabels=SYjoDwgvEaQteqBJmKRFklLIcNMdGH,isFolder=SYjoDwgvEaQteqBJmKRFklLIcNMdGi,params=SYjoDwgvEaQteqBJmKRFklLIcNMdHC)
  xbmcplugin.setContent(SYjoDwgvEaQteqBJmKRFklLIcNMdOG._addon_handle,'tvshows')
  if SYjoDwgvEaQteqBJmKRFklLIcNMdGT(SYjoDwgvEaQteqBJmKRFklLIcNMdUn)>0:xbmcplugin.endOfDirectory(SYjoDwgvEaQteqBJmKRFklLIcNMdOG._addon_handle,cacheToDisc=SYjoDwgvEaQteqBJmKRFklLIcNMdGh)
 def dp_Season_List(SYjoDwgvEaQteqBJmKRFklLIcNMdOG,args):
  SYjoDwgvEaQteqBJmKRFklLIcNMdUX=args.get('videoid')
  SYjoDwgvEaQteqBJmKRFklLIcNMdUy=args.get('vidtype')
  if SYjoDwgvEaQteqBJmKRFklLIcNMdUy=='contentid':
   SYjoDwgvEaQteqBJmKRFklLIcNMdhs=SYjoDwgvEaQteqBJmKRFklLIcNMdUX
   SYjoDwgvEaQteqBJmKRFklLIcNMdbA =SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.ContentidToSeasonid(SYjoDwgvEaQteqBJmKRFklLIcNMdUX)
  else:
   SYjoDwgvEaQteqBJmKRFklLIcNMdhs=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.ProgramidToContentid(SYjoDwgvEaQteqBJmKRFklLIcNMdUX)
   SYjoDwgvEaQteqBJmKRFklLIcNMdbA =SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.ContentidToSeasonid(SYjoDwgvEaQteqBJmKRFklLIcNMdhs)
  SYjoDwgvEaQteqBJmKRFklLIcNMdbz=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.Get_Season_List(SYjoDwgvEaQteqBJmKRFklLIcNMdbA)
  if SYjoDwgvEaQteqBJmKRFklLIcNMdGT(SYjoDwgvEaQteqBJmKRFklLIcNMdbz)>1:
   for SYjoDwgvEaQteqBJmKRFklLIcNMdbC in SYjoDwgvEaQteqBJmKRFklLIcNMdbz:
    SYjoDwgvEaQteqBJmKRFklLIcNMdbf=SYjoDwgvEaQteqBJmKRFklLIcNMdbC.get('season_Id')
    SYjoDwgvEaQteqBJmKRFklLIcNMdbn=SYjoDwgvEaQteqBJmKRFklLIcNMdbC.get('season_Nm')
    SYjoDwgvEaQteqBJmKRFklLIcNMdbW=SYjoDwgvEaQteqBJmKRFklLIcNMdbC.get('programNm')
    SYjoDwgvEaQteqBJmKRFklLIcNMdUV=SYjoDwgvEaQteqBJmKRFklLIcNMdbC.get('thumbnail')
    SYjoDwgvEaQteqBJmKRFklLIcNMdbX =SYjoDwgvEaQteqBJmKRFklLIcNMdbC.get('synopsis')
    SYjoDwgvEaQteqBJmKRFklLIcNMdUC={'mediatype':'tvshow','title':SYjoDwgvEaQteqBJmKRFklLIcNMdbn,'plot':SYjoDwgvEaQteqBJmKRFklLIcNMdbX,}
    SYjoDwgvEaQteqBJmKRFklLIcNMdHC={'mode':'EPISODE_LIST','seasonid':SYjoDwgvEaQteqBJmKRFklLIcNMdbf,'page':'1',}
    SYjoDwgvEaQteqBJmKRFklLIcNMdOG.add_dir(SYjoDwgvEaQteqBJmKRFklLIcNMdbn,sublabel=SYjoDwgvEaQteqBJmKRFklLIcNMdbW,img=SYjoDwgvEaQteqBJmKRFklLIcNMdUV,infoLabels=SYjoDwgvEaQteqBJmKRFklLIcNMdUC,isFolder=SYjoDwgvEaQteqBJmKRFklLIcNMdGi,params=SYjoDwgvEaQteqBJmKRFklLIcNMdHC,ContextMenu=SYjoDwgvEaQteqBJmKRFklLIcNMdGH)
   xbmcplugin.setContent(SYjoDwgvEaQteqBJmKRFklLIcNMdOG._addon_handle,'seasons')
   xbmcplugin.endOfDirectory(SYjoDwgvEaQteqBJmKRFklLIcNMdOG._addon_handle,cacheToDisc=SYjoDwgvEaQteqBJmKRFklLIcNMdGh)
  else:
   SYjoDwgvEaQteqBJmKRFklLIcNMdby={'seasonid':SYjoDwgvEaQteqBJmKRFklLIcNMdbA,'page':'1',}
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.dp_Episode_List(SYjoDwgvEaQteqBJmKRFklLIcNMdby)
 def dp_Episode_List(SYjoDwgvEaQteqBJmKRFklLIcNMdOG,args):
  SYjoDwgvEaQteqBJmKRFklLIcNMdbA =args.get('seasonid')
  SYjoDwgvEaQteqBJmKRFklLIcNMdUf =SYjoDwgvEaQteqBJmKRFklLIcNMdGU(args.get('page'))
  SYjoDwgvEaQteqBJmKRFklLIcNMdUn,SYjoDwgvEaQteqBJmKRFklLIcNMdUO=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.Get_Episode_List(SYjoDwgvEaQteqBJmKRFklLIcNMdbA,SYjoDwgvEaQteqBJmKRFklLIcNMdUf,orderby=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.get_winEpisodeOrderby())
  for SYjoDwgvEaQteqBJmKRFklLIcNMdUW in SYjoDwgvEaQteqBJmKRFklLIcNMdUn:
   SYjoDwgvEaQteqBJmKRFklLIcNMdiU=SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('episodenumber')
   SYjoDwgvEaQteqBJmKRFklLIcNMdbV ='[%s]\n\n%s'%(SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('episodetitle'),SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('synopsis'))
   SYjoDwgvEaQteqBJmKRFklLIcNMdUC={'mediatype':'episode','title':SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('programtitle'),'plot':SYjoDwgvEaQteqBJmKRFklLIcNMdbV,'cast':SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('episodeactors'),}
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC={'mode':'VOD','programid':SYjoDwgvEaQteqBJmKRFklLIcNMdbA,'contentid':SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('contentid'),'thumbnail':SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('thumbnail'),'title':SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('programtitle'),'subtitle':SYjoDwgvEaQteqBJmKRFklLIcNMdiU,}
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.add_dir(SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('programtitle'),sublabel=SYjoDwgvEaQteqBJmKRFklLIcNMdiU,img=SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('thumbnail'),infoLabels=SYjoDwgvEaQteqBJmKRFklLIcNMdUC,isFolder=SYjoDwgvEaQteqBJmKRFklLIcNMdGh,params=SYjoDwgvEaQteqBJmKRFklLIcNMdHC)
  if SYjoDwgvEaQteqBJmKRFklLIcNMdUf==1:
   SYjoDwgvEaQteqBJmKRFklLIcNMdUC={'plot':'정렬순서를 변경합니다.'}
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC={}
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC['mode'] ='ORDER_BY' 
   if SYjoDwgvEaQteqBJmKRFklLIcNMdOG.get_winEpisodeOrderby()=='desc':
    SYjoDwgvEaQteqBJmKRFklLIcNMdHP='정렬순서변경 : 최신화부터 -> 1회부터'
    SYjoDwgvEaQteqBJmKRFklLIcNMdHC['orderby']='asc'
   else:
    SYjoDwgvEaQteqBJmKRFklLIcNMdHP='정렬순서변경 : 1회부터 -> 최신화부터'
    SYjoDwgvEaQteqBJmKRFklLIcNMdHC['orderby']='desc'
   SYjoDwgvEaQteqBJmKRFklLIcNMdHz=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.add_dir(SYjoDwgvEaQteqBJmKRFklLIcNMdHP,sublabel='',img=SYjoDwgvEaQteqBJmKRFklLIcNMdHz,infoLabels=SYjoDwgvEaQteqBJmKRFklLIcNMdUC,isFolder=SYjoDwgvEaQteqBJmKRFklLIcNMdGh,params=SYjoDwgvEaQteqBJmKRFklLIcNMdHC,isLink=SYjoDwgvEaQteqBJmKRFklLIcNMdGi)
  if SYjoDwgvEaQteqBJmKRFklLIcNMdUO:
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC={}
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC['mode'] ='EPISODE_LIST' 
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC['seasonid']=SYjoDwgvEaQteqBJmKRFklLIcNMdbA
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC['page'] =SYjoDwgvEaQteqBJmKRFklLIcNMdGr(SYjoDwgvEaQteqBJmKRFklLIcNMdUf+1)
   SYjoDwgvEaQteqBJmKRFklLIcNMdHP='[B]%s >>[/B]'%'다음 페이지'
   SYjoDwgvEaQteqBJmKRFklLIcNMdiU=SYjoDwgvEaQteqBJmKRFklLIcNMdGr(SYjoDwgvEaQteqBJmKRFklLIcNMdUf+1)
   SYjoDwgvEaQteqBJmKRFklLIcNMdHz=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.add_dir(SYjoDwgvEaQteqBJmKRFklLIcNMdHP,sublabel=SYjoDwgvEaQteqBJmKRFklLIcNMdiU,img=SYjoDwgvEaQteqBJmKRFklLIcNMdHz,infoLabels=SYjoDwgvEaQteqBJmKRFklLIcNMdGH,isFolder=SYjoDwgvEaQteqBJmKRFklLIcNMdGi,params=SYjoDwgvEaQteqBJmKRFklLIcNMdHC)
  xbmcplugin.setContent(SYjoDwgvEaQteqBJmKRFklLIcNMdOG._addon_handle,'episodes')
  if SYjoDwgvEaQteqBJmKRFklLIcNMdGT(SYjoDwgvEaQteqBJmKRFklLIcNMdUn)>0:xbmcplugin.endOfDirectory(SYjoDwgvEaQteqBJmKRFklLIcNMdOG._addon_handle,cacheToDisc=SYjoDwgvEaQteqBJmKRFklLIcNMdGh)
 def dp_SuperSection_List(SYjoDwgvEaQteqBJmKRFklLIcNMdOG,args):
  SYjoDwgvEaQteqBJmKRFklLIcNMdbu =args.get('suburl')
  SYjoDwgvEaQteqBJmKRFklLIcNMdbr =args.get('subapi')
  SYjoDwgvEaQteqBJmKRFklLIcNMdOG.addon_log('dp_SuperSection_List')
  SYjoDwgvEaQteqBJmKRFklLIcNMdOG.addon_log('suburl : '+SYjoDwgvEaQteqBJmKRFklLIcNMdbu)
  SYjoDwgvEaQteqBJmKRFklLIcNMdOG.addon_log('subapi : '+SYjoDwgvEaQteqBJmKRFklLIcNMdbr)
  SYjoDwgvEaQteqBJmKRFklLIcNMdUn=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.Get_SuperMultiSection_List(SYjoDwgvEaQteqBJmKRFklLIcNMdbu)
  for SYjoDwgvEaQteqBJmKRFklLIcNMdUW in SYjoDwgvEaQteqBJmKRFklLIcNMdUn:
   SYjoDwgvEaQteqBJmKRFklLIcNMdHP =SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('title')
   SYjoDwgvEaQteqBJmKRFklLIcNMdbr =SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('subapi')
   SYjoDwgvEaQteqBJmKRFklLIcNMdbx=SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('cell_type')
   if SYjoDwgvEaQteqBJmKRFklLIcNMdbr.find('contenttype=movie')>=0 or SYjoDwgvEaQteqBJmKRFklLIcNMdbr.find('mtype=svod')>=0:
    SYjoDwgvEaQteqBJmKRFklLIcNMdHu='MOVIE_LIST'
   elif re.search('themes/2\d{4}',SYjoDwgvEaQteqBJmKRFklLIcNMdbr)or re.search('themes-band/9\d{4}',SYjoDwgvEaQteqBJmKRFklLIcNMdbr):
    SYjoDwgvEaQteqBJmKRFklLIcNMdHu='MOVIE_LIST'
   else:
    SYjoDwgvEaQteqBJmKRFklLIcNMdHu='PROGRAM_LIST'
   '''
   if subapi.find('mtype=svod') >= 0 or subapi.find('mtype=ppv') >= 0 or subapi.find('contenttype=movie') >= 0: #영화 #20201107
    mode = 'MOVIE_LIST'
   elif subapi.find('contenttype=program') >= 0:
    mode = 'PROGRAM_LIST'
   elif cell_type == 'band_71': # band_71 #20201107
    mode   = 'SUPERSECTION_LIST'
    (temp_url, temp_api) = self.WavveObj.Baseapi_Parse(subapi)
    suburl = temp_api.get('api')
    subapi = ''
   elif cell_type == 'band_2': # band_2
    mode = 'BAND2SECTION_LIST'
   elif cell_type == 'band_live':
    mode = 'BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}', subapi) :
    mode = 'MOVIE_LIST'
   else: # band_10
    mode = 'PROGRAM_LIST'
   '''   
   SYjoDwgvEaQteqBJmKRFklLIcNMdUC={'plot':SYjoDwgvEaQteqBJmKRFklLIcNMdHP,'mediatype':'tvshow',}
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC={'mode':SYjoDwgvEaQteqBJmKRFklLIcNMdHu,'suburl':SYjoDwgvEaQteqBJmKRFklLIcNMdbu,'subapi':SYjoDwgvEaQteqBJmKRFklLIcNMdbr,'page':'1',}
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.add_dir(SYjoDwgvEaQteqBJmKRFklLIcNMdHP,sublabel='',img=SYjoDwgvEaQteqBJmKRFklLIcNMdGH,infoLabels=SYjoDwgvEaQteqBJmKRFklLIcNMdUC,isFolder=SYjoDwgvEaQteqBJmKRFklLIcNMdGi,params=SYjoDwgvEaQteqBJmKRFklLIcNMdHC)
  if SYjoDwgvEaQteqBJmKRFklLIcNMdGT(SYjoDwgvEaQteqBJmKRFklLIcNMdUn)>0:xbmcplugin.endOfDirectory(SYjoDwgvEaQteqBJmKRFklLIcNMdOG._addon_handle,cacheToDisc=SYjoDwgvEaQteqBJmKRFklLIcNMdGh)
 def dp_BandLiveSection_List(SYjoDwgvEaQteqBJmKRFklLIcNMdOG,args):
  SYjoDwgvEaQteqBJmKRFklLIcNMdbr =args.get('subapi')
  SYjoDwgvEaQteqBJmKRFklLIcNMdUf=SYjoDwgvEaQteqBJmKRFklLIcNMdGU(args.get('page'))
  SYjoDwgvEaQteqBJmKRFklLIcNMdUn,SYjoDwgvEaQteqBJmKRFklLIcNMdUO=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.Get_BandLiveSection_List(SYjoDwgvEaQteqBJmKRFklLIcNMdbr,SYjoDwgvEaQteqBJmKRFklLIcNMdUf)
  for SYjoDwgvEaQteqBJmKRFklLIcNMdUW in SYjoDwgvEaQteqBJmKRFklLIcNMdUn:
   SYjoDwgvEaQteqBJmKRFklLIcNMdbp =SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('channelid')
   SYjoDwgvEaQteqBJmKRFklLIcNMdsO =SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('studio')
   SYjoDwgvEaQteqBJmKRFklLIcNMdsH=SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('tvshowtitle')
   SYjoDwgvEaQteqBJmKRFklLIcNMdUV =SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('thumbnail')
   SYjoDwgvEaQteqBJmKRFklLIcNMdUu =SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('age')
   SYjoDwgvEaQteqBJmKRFklLIcNMdUC={'mediatype':'tvshow','mpaa':SYjoDwgvEaQteqBJmKRFklLIcNMdUu,'title':'%s < %s >'%(SYjoDwgvEaQteqBJmKRFklLIcNMdsO,SYjoDwgvEaQteqBJmKRFklLIcNMdsH),'tvshowtitle':SYjoDwgvEaQteqBJmKRFklLIcNMdsH,'studio':SYjoDwgvEaQteqBJmKRFklLIcNMdsO,'plot':SYjoDwgvEaQteqBJmKRFklLIcNMdsO}
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC={'mode':'LIVE','contentid':SYjoDwgvEaQteqBJmKRFklLIcNMdbp}
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.add_dir(SYjoDwgvEaQteqBJmKRFklLIcNMdsO,sublabel=SYjoDwgvEaQteqBJmKRFklLIcNMdsH,img=SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('thumbnail'),infoLabels=SYjoDwgvEaQteqBJmKRFklLIcNMdUC,isFolder=SYjoDwgvEaQteqBJmKRFklLIcNMdGh,params=SYjoDwgvEaQteqBJmKRFklLIcNMdHC)
  if SYjoDwgvEaQteqBJmKRFklLIcNMdUO:
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC={}
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC['mode'] ='BANDLIVESECTION_LIST' 
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC['subapi']=SYjoDwgvEaQteqBJmKRFklLIcNMdbr
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC['page'] =SYjoDwgvEaQteqBJmKRFklLIcNMdGr(SYjoDwgvEaQteqBJmKRFklLIcNMdUf+1)
   SYjoDwgvEaQteqBJmKRFklLIcNMdHP='[B]%s >>[/B]'%'다음 페이지'
   SYjoDwgvEaQteqBJmKRFklLIcNMdiU=SYjoDwgvEaQteqBJmKRFklLIcNMdGr(SYjoDwgvEaQteqBJmKRFklLIcNMdUf+1)
   SYjoDwgvEaQteqBJmKRFklLIcNMdHz=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.add_dir(SYjoDwgvEaQteqBJmKRFklLIcNMdHP,sublabel=SYjoDwgvEaQteqBJmKRFklLIcNMdiU,img=SYjoDwgvEaQteqBJmKRFklLIcNMdHz,infoLabels=SYjoDwgvEaQteqBJmKRFklLIcNMdGH,isFolder=SYjoDwgvEaQteqBJmKRFklLIcNMdGi,params=SYjoDwgvEaQteqBJmKRFklLIcNMdHC)
  if SYjoDwgvEaQteqBJmKRFklLIcNMdGT(SYjoDwgvEaQteqBJmKRFklLIcNMdUn)>0:xbmcplugin.endOfDirectory(SYjoDwgvEaQteqBJmKRFklLIcNMdOG._addon_handle,cacheToDisc=SYjoDwgvEaQteqBJmKRFklLIcNMdGh)
 def dp_Band2Section_List(SYjoDwgvEaQteqBJmKRFklLIcNMdOG,args):
  SYjoDwgvEaQteqBJmKRFklLIcNMdbr =args.get('subapi')
  SYjoDwgvEaQteqBJmKRFklLIcNMdUf=SYjoDwgvEaQteqBJmKRFklLIcNMdGU(args.get('page'))
  SYjoDwgvEaQteqBJmKRFklLIcNMdUn,SYjoDwgvEaQteqBJmKRFklLIcNMdUO=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.Get_Band2Section_List(SYjoDwgvEaQteqBJmKRFklLIcNMdbr,SYjoDwgvEaQteqBJmKRFklLIcNMdUf)
  for SYjoDwgvEaQteqBJmKRFklLIcNMdUW in SYjoDwgvEaQteqBJmKRFklLIcNMdUn:
   SYjoDwgvEaQteqBJmKRFklLIcNMdHP =SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('programtitle')
   SYjoDwgvEaQteqBJmKRFklLIcNMdiU =SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('episodetitle')
   SYjoDwgvEaQteqBJmKRFklLIcNMdUC={'plot':SYjoDwgvEaQteqBJmKRFklLIcNMdHP+'\n\n'+SYjoDwgvEaQteqBJmKRFklLIcNMdiU,'mpaa':SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('age'),'mediatype':'episode'}
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC={'mode':'VOD','programid':'-','contentid':SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('videoid'),'thumbnail':SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('thumbnail'),'title':SYjoDwgvEaQteqBJmKRFklLIcNMdHP,'subtitle':SYjoDwgvEaQteqBJmKRFklLIcNMdiU}
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.add_dir(SYjoDwgvEaQteqBJmKRFklLIcNMdHP,sublabel=SYjoDwgvEaQteqBJmKRFklLIcNMdiU,img=SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('thumbnail'),infoLabels=SYjoDwgvEaQteqBJmKRFklLIcNMdUC,isFolder=SYjoDwgvEaQteqBJmKRFklLIcNMdGh,params=SYjoDwgvEaQteqBJmKRFklLIcNMdHC)
  if SYjoDwgvEaQteqBJmKRFklLIcNMdUO:
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC={}
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC['mode'] ='BAND2SECTION_LIST' 
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC['subapi']=SYjoDwgvEaQteqBJmKRFklLIcNMdbr
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC['page'] =SYjoDwgvEaQteqBJmKRFklLIcNMdGr(SYjoDwgvEaQteqBJmKRFklLIcNMdUf+1)
   SYjoDwgvEaQteqBJmKRFklLIcNMdHP='[B]%s >>[/B]'%'다음 페이지'
   SYjoDwgvEaQteqBJmKRFklLIcNMdiU=SYjoDwgvEaQteqBJmKRFklLIcNMdGr(SYjoDwgvEaQteqBJmKRFklLIcNMdUf+1)
   SYjoDwgvEaQteqBJmKRFklLIcNMdHz=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.add_dir(SYjoDwgvEaQteqBJmKRFklLIcNMdHP,sublabel=SYjoDwgvEaQteqBJmKRFklLIcNMdiU,img=SYjoDwgvEaQteqBJmKRFklLIcNMdHz,infoLabels=SYjoDwgvEaQteqBJmKRFklLIcNMdGH,isFolder=SYjoDwgvEaQteqBJmKRFklLIcNMdGi,params=SYjoDwgvEaQteqBJmKRFklLIcNMdHC)
  if SYjoDwgvEaQteqBJmKRFklLIcNMdGT(SYjoDwgvEaQteqBJmKRFklLIcNMdUn)>0:xbmcplugin.endOfDirectory(SYjoDwgvEaQteqBJmKRFklLIcNMdOG._addon_handle,cacheToDisc=SYjoDwgvEaQteqBJmKRFklLIcNMdGh)
 def dp_Movie_List(SYjoDwgvEaQteqBJmKRFklLIcNMdOG,args):
  SYjoDwgvEaQteqBJmKRFklLIcNMdbr =args.get('subapi')
  SYjoDwgvEaQteqBJmKRFklLIcNMdUf=SYjoDwgvEaQteqBJmKRFklLIcNMdGU(args.get('page'))
  SYjoDwgvEaQteqBJmKRFklLIcNMdHG =args.get('orderby')or '-'
  SYjoDwgvEaQteqBJmKRFklLIcNMdOG.addon_log('dp_Movie_List')
  SYjoDwgvEaQteqBJmKRFklLIcNMdOG.addon_log(SYjoDwgvEaQteqBJmKRFklLIcNMdbr)
  SYjoDwgvEaQteqBJmKRFklLIcNMdUn,SYjoDwgvEaQteqBJmKRFklLIcNMdUO=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.Get_Movie_List(SYjoDwgvEaQteqBJmKRFklLIcNMdbr,SYjoDwgvEaQteqBJmKRFklLIcNMdUf,SYjoDwgvEaQteqBJmKRFklLIcNMdHG)
  for SYjoDwgvEaQteqBJmKRFklLIcNMdUW in SYjoDwgvEaQteqBJmKRFklLIcNMdUn:
   SYjoDwgvEaQteqBJmKRFklLIcNMdUX =SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('videoid')
   SYjoDwgvEaQteqBJmKRFklLIcNMdUy =SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('vidtype')
   SYjoDwgvEaQteqBJmKRFklLIcNMdHP =SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('title')
   SYjoDwgvEaQteqBJmKRFklLIcNMdUV=SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('thumbnail')
   SYjoDwgvEaQteqBJmKRFklLIcNMdUu =SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('age')
   if SYjoDwgvEaQteqBJmKRFklLIcNMdUu=='18' or SYjoDwgvEaQteqBJmKRFklLIcNMdUu=='19' or SYjoDwgvEaQteqBJmKRFklLIcNMdUu=='21':SYjoDwgvEaQteqBJmKRFklLIcNMdHP+=' (%s)'%(SYjoDwgvEaQteqBJmKRFklLIcNMdUu)
   SYjoDwgvEaQteqBJmKRFklLIcNMdUC={'plot':SYjoDwgvEaQteqBJmKRFklLIcNMdHP,'mpaa':SYjoDwgvEaQteqBJmKRFklLIcNMdUu,'mediatype':'movie'}
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC={'mode':'MOVIE','contentid':SYjoDwgvEaQteqBJmKRFklLIcNMdUX,'title':SYjoDwgvEaQteqBJmKRFklLIcNMdHP,'thumbnail':SYjoDwgvEaQteqBJmKRFklLIcNMdUV,'age':SYjoDwgvEaQteqBJmKRFklLIcNMdUu,}
   SYjoDwgvEaQteqBJmKRFklLIcNMdUz=[]
   SYjoDwgvEaQteqBJmKRFklLIcNMdUx={'mode':'VIEW_DETAIL','values':{'videoid':SYjoDwgvEaQteqBJmKRFklLIcNMdUX,'vidtype':'movie','contenttype':SYjoDwgvEaQteqBJmKRFklLIcNMdUy,}}
   SYjoDwgvEaQteqBJmKRFklLIcNMdUp=json.dumps(SYjoDwgvEaQteqBJmKRFklLIcNMdUx,separators=(',',':'))
   SYjoDwgvEaQteqBJmKRFklLIcNMdUp=base64.standard_b64encode(SYjoDwgvEaQteqBJmKRFklLIcNMdUp.encode()).decode('utf-8')
   SYjoDwgvEaQteqBJmKRFklLIcNMdUp=SYjoDwgvEaQteqBJmKRFklLIcNMdUp.replace('+','%2B')
   SYjoDwgvEaQteqBJmKRFklLIcNMdiO='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(SYjoDwgvEaQteqBJmKRFklLIcNMdUp)
   SYjoDwgvEaQteqBJmKRFklLIcNMdUz.append(('상세정보 조회',SYjoDwgvEaQteqBJmKRFklLIcNMdiO))
   if SYjoDwgvEaQteqBJmKRFklLIcNMdOG.get_settings_makebookmark():
    SYjoDwgvEaQteqBJmKRFklLIcNMdUx={'videoid':SYjoDwgvEaQteqBJmKRFklLIcNMdUX,'vidtype':'movie','vtitle':SYjoDwgvEaQteqBJmKRFklLIcNMdHP,'vsubtitle':'','contenttype':'programid',}
    SYjoDwgvEaQteqBJmKRFklLIcNMdiH=json.dumps(SYjoDwgvEaQteqBJmKRFklLIcNMdUx)
    SYjoDwgvEaQteqBJmKRFklLIcNMdiH=urllib.parse.quote(SYjoDwgvEaQteqBJmKRFklLIcNMdiH)
    SYjoDwgvEaQteqBJmKRFklLIcNMdiO='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(SYjoDwgvEaQteqBJmKRFklLIcNMdiH)
    SYjoDwgvEaQteqBJmKRFklLIcNMdUz.append(('(통합) 찜 영상에 추가',SYjoDwgvEaQteqBJmKRFklLIcNMdiO))
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.add_dir(SYjoDwgvEaQteqBJmKRFklLIcNMdHP,sublabel='',img=SYjoDwgvEaQteqBJmKRFklLIcNMdUV,infoLabels=SYjoDwgvEaQteqBJmKRFklLIcNMdUC,isFolder=SYjoDwgvEaQteqBJmKRFklLIcNMdGh,params=SYjoDwgvEaQteqBJmKRFklLIcNMdHC,ContextMenu=SYjoDwgvEaQteqBJmKRFklLIcNMdUz)
  if SYjoDwgvEaQteqBJmKRFklLIcNMdUO:
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC={}
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC['mode'] ='MOVIE_LIST' 
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC['subapi']=SYjoDwgvEaQteqBJmKRFklLIcNMdbr 
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC['page'] =SYjoDwgvEaQteqBJmKRFklLIcNMdGr(SYjoDwgvEaQteqBJmKRFklLIcNMdUf+1)
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC['orderby']=SYjoDwgvEaQteqBJmKRFklLIcNMdHG
   SYjoDwgvEaQteqBJmKRFklLIcNMdHP='[B]%s >>[/B]'%'다음 페이지'
   SYjoDwgvEaQteqBJmKRFklLIcNMdiU=SYjoDwgvEaQteqBJmKRFklLIcNMdGr(SYjoDwgvEaQteqBJmKRFklLIcNMdUf+1)
   SYjoDwgvEaQteqBJmKRFklLIcNMdHz=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.add_dir(SYjoDwgvEaQteqBJmKRFklLIcNMdHP,sublabel=SYjoDwgvEaQteqBJmKRFklLIcNMdiU,img=SYjoDwgvEaQteqBJmKRFklLIcNMdHz,infoLabels=SYjoDwgvEaQteqBJmKRFklLIcNMdGH,isFolder=SYjoDwgvEaQteqBJmKRFklLIcNMdGi,params=SYjoDwgvEaQteqBJmKRFklLIcNMdHC)
  xbmcplugin.setContent(SYjoDwgvEaQteqBJmKRFklLIcNMdOG._addon_handle,'movies')
  if SYjoDwgvEaQteqBJmKRFklLIcNMdGT(SYjoDwgvEaQteqBJmKRFklLIcNMdUn)>0:xbmcplugin.endOfDirectory(SYjoDwgvEaQteqBJmKRFklLIcNMdOG._addon_handle,cacheToDisc=SYjoDwgvEaQteqBJmKRFklLIcNMdGh)
 def dp_Set_Bookmark(SYjoDwgvEaQteqBJmKRFklLIcNMdOG,args):
  SYjoDwgvEaQteqBJmKRFklLIcNMdsU=urllib.parse.unquote(args.get('bm_param'))
  SYjoDwgvEaQteqBJmKRFklLIcNMdsU=json.loads(SYjoDwgvEaQteqBJmKRFklLIcNMdsU)
  SYjoDwgvEaQteqBJmKRFklLIcNMdUX =SYjoDwgvEaQteqBJmKRFklLIcNMdsU.get('videoid')
  SYjoDwgvEaQteqBJmKRFklLIcNMdUy =SYjoDwgvEaQteqBJmKRFklLIcNMdsU.get('vidtype')
  SYjoDwgvEaQteqBJmKRFklLIcNMdsi =SYjoDwgvEaQteqBJmKRFklLIcNMdsU.get('vtitle')
  SYjoDwgvEaQteqBJmKRFklLIcNMdsh =SYjoDwgvEaQteqBJmKRFklLIcNMdsU.get('vsubtitle')
  SYjoDwgvEaQteqBJmKRFklLIcNMdsb=SYjoDwgvEaQteqBJmKRFklLIcNMdsU.get('contenttype')
  SYjoDwgvEaQteqBJmKRFklLIcNMdOz=xbmcgui.Dialog()
  SYjoDwgvEaQteqBJmKRFklLIcNMdiy=SYjoDwgvEaQteqBJmKRFklLIcNMdOz.yesno(__language__(30913).encode('utf8'),SYjoDwgvEaQteqBJmKRFklLIcNMdsi+' \n\n'+__language__(30914))
  if SYjoDwgvEaQteqBJmKRFklLIcNMdiy==SYjoDwgvEaQteqBJmKRFklLIcNMdGh:return
  SYjoDwgvEaQteqBJmKRFklLIcNMdsG=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.GetBookmarkInfo(SYjoDwgvEaQteqBJmKRFklLIcNMdUX,SYjoDwgvEaQteqBJmKRFklLIcNMdUy,SYjoDwgvEaQteqBJmKRFklLIcNMdsb)
  SYjoDwgvEaQteqBJmKRFklLIcNMdsT=json.dumps(SYjoDwgvEaQteqBJmKRFklLIcNMdsG)
  SYjoDwgvEaQteqBJmKRFklLIcNMdsT=urllib.parse.quote(SYjoDwgvEaQteqBJmKRFklLIcNMdsT)
  SYjoDwgvEaQteqBJmKRFklLIcNMdiO ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(SYjoDwgvEaQteqBJmKRFklLIcNMdsT)
  xbmc.executebuiltin(SYjoDwgvEaQteqBJmKRFklLIcNMdiO)
 def dp_LiveChannel_List(SYjoDwgvEaQteqBJmKRFklLIcNMdOG,args):
  SYjoDwgvEaQteqBJmKRFklLIcNMdsP =args.get('genre')
  SYjoDwgvEaQteqBJmKRFklLIcNMdbP=args.get('baseapi')
  SYjoDwgvEaQteqBJmKRFklLIcNMdUn=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.Get_LiveChannel_List(SYjoDwgvEaQteqBJmKRFklLIcNMdsP,SYjoDwgvEaQteqBJmKRFklLIcNMdbP)
  for SYjoDwgvEaQteqBJmKRFklLIcNMdUW in SYjoDwgvEaQteqBJmKRFklLIcNMdUn:
   SYjoDwgvEaQteqBJmKRFklLIcNMdbp =SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('channelid')
   SYjoDwgvEaQteqBJmKRFklLIcNMdsO =SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('studio')
   SYjoDwgvEaQteqBJmKRFklLIcNMdsH=SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('tvshowtitle')
   SYjoDwgvEaQteqBJmKRFklLIcNMdUV =SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('thumbnail')
   SYjoDwgvEaQteqBJmKRFklLIcNMdUu =SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('age')
   SYjoDwgvEaQteqBJmKRFklLIcNMdsr =SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('epg')
   SYjoDwgvEaQteqBJmKRFklLIcNMdUC={'mediatype':'episode','mpaa':SYjoDwgvEaQteqBJmKRFklLIcNMdUu,'title':'%s < %s >'%(SYjoDwgvEaQteqBJmKRFklLIcNMdsO,SYjoDwgvEaQteqBJmKRFklLIcNMdsH),'tvshowtitle':SYjoDwgvEaQteqBJmKRFklLIcNMdsH,'studio':SYjoDwgvEaQteqBJmKRFklLIcNMdsO,'plot':'%s\n\n%s'%(SYjoDwgvEaQteqBJmKRFklLIcNMdsO,SYjoDwgvEaQteqBJmKRFklLIcNMdsr)}
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC={'mode':'LIVE','contentid':SYjoDwgvEaQteqBJmKRFklLIcNMdbp}
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.add_dir(SYjoDwgvEaQteqBJmKRFklLIcNMdsO,sublabel=SYjoDwgvEaQteqBJmKRFklLIcNMdsH,img=SYjoDwgvEaQteqBJmKRFklLIcNMdUV,infoLabels=SYjoDwgvEaQteqBJmKRFklLIcNMdUC,isFolder=SYjoDwgvEaQteqBJmKRFklLIcNMdGh,params=SYjoDwgvEaQteqBJmKRFklLIcNMdHC)
  if SYjoDwgvEaQteqBJmKRFklLIcNMdGT(SYjoDwgvEaQteqBJmKRFklLIcNMdUn)>0:xbmcplugin.endOfDirectory(SYjoDwgvEaQteqBJmKRFklLIcNMdOG._addon_handle,cacheToDisc=SYjoDwgvEaQteqBJmKRFklLIcNMdGh)
 def dp_Sports_GameList(SYjoDwgvEaQteqBJmKRFklLIcNMdOG,args):
  SYjoDwgvEaQteqBJmKRFklLIcNMdUn=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.Get_Sports_Gamelist()
  for SYjoDwgvEaQteqBJmKRFklLIcNMdUW in SYjoDwgvEaQteqBJmKRFklLIcNMdUn:
   SYjoDwgvEaQteqBJmKRFklLIcNMdsA =SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('game_date')
   SYjoDwgvEaQteqBJmKRFklLIcNMdsz =SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('game_time')
   SYjoDwgvEaQteqBJmKRFklLIcNMdsC =SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('svc_id')
   SYjoDwgvEaQteqBJmKRFklLIcNMdsf =SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('away_team')
   SYjoDwgvEaQteqBJmKRFklLIcNMdsn =SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('home_team')
   SYjoDwgvEaQteqBJmKRFklLIcNMdsW=SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('game_status')
   SYjoDwgvEaQteqBJmKRFklLIcNMdsX =SYjoDwgvEaQteqBJmKRFklLIcNMdUW.get('game_place')
   SYjoDwgvEaQteqBJmKRFklLIcNMdsy ='%s vs %s (%s)'%(SYjoDwgvEaQteqBJmKRFklLIcNMdsf,SYjoDwgvEaQteqBJmKRFklLIcNMdsn,SYjoDwgvEaQteqBJmKRFklLIcNMdsX)
   SYjoDwgvEaQteqBJmKRFklLIcNMdsV =SYjoDwgvEaQteqBJmKRFklLIcNMdsA+' '+SYjoDwgvEaQteqBJmKRFklLIcNMdsz
   if SYjoDwgvEaQteqBJmKRFklLIcNMdsW=='LIVE':
    SYjoDwgvEaQteqBJmKRFklLIcNMdsW='~경기중~'
   elif SYjoDwgvEaQteqBJmKRFklLIcNMdsW=='END':
    SYjoDwgvEaQteqBJmKRFklLIcNMdsW='경기종료'
   elif SYjoDwgvEaQteqBJmKRFklLIcNMdsW=='CANCEL':
    SYjoDwgvEaQteqBJmKRFklLIcNMdsW='취소'
   else:
    SYjoDwgvEaQteqBJmKRFklLIcNMdsW=''
   if SYjoDwgvEaQteqBJmKRFklLIcNMdsW=='':
    SYjoDwgvEaQteqBJmKRFklLIcNMdiU=SYjoDwgvEaQteqBJmKRFklLIcNMdsy
   else:
    SYjoDwgvEaQteqBJmKRFklLIcNMdiU=SYjoDwgvEaQteqBJmKRFklLIcNMdsy+'  '+SYjoDwgvEaQteqBJmKRFklLIcNMdsW
   SYjoDwgvEaQteqBJmKRFklLIcNMdUC={'mediatype':'episode','title':SYjoDwgvEaQteqBJmKRFklLIcNMdsy,'plot':'%s\n\n%s\n\n%s'%(SYjoDwgvEaQteqBJmKRFklLIcNMdsV,SYjoDwgvEaQteqBJmKRFklLIcNMdsy,SYjoDwgvEaQteqBJmKRFklLIcNMdsW)}
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC={'mode':'SPORTS','contentid':SYjoDwgvEaQteqBJmKRFklLIcNMdsC}
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.add_dir(SYjoDwgvEaQteqBJmKRFklLIcNMdsV,sublabel=SYjoDwgvEaQteqBJmKRFklLIcNMdiU,img='',infoLabels=SYjoDwgvEaQteqBJmKRFklLIcNMdUC,isFolder=SYjoDwgvEaQteqBJmKRFklLIcNMdGh,params=SYjoDwgvEaQteqBJmKRFklLIcNMdHC)
  xbmcplugin.endOfDirectory(SYjoDwgvEaQteqBJmKRFklLIcNMdOG._addon_handle,cacheToDisc=SYjoDwgvEaQteqBJmKRFklLIcNMdGh)
 def dp_View_Detail(SYjoDwgvEaQteqBJmKRFklLIcNMdOG,SYjoDwgvEaQteqBJmKRFklLIcNMdsp):
  SYjoDwgvEaQteqBJmKRFklLIcNMdUX =SYjoDwgvEaQteqBJmKRFklLIcNMdsp.get('videoid')
  SYjoDwgvEaQteqBJmKRFklLIcNMdUy =SYjoDwgvEaQteqBJmKRFklLIcNMdsp.get('vidtype') 
  SYjoDwgvEaQteqBJmKRFklLIcNMdsb=SYjoDwgvEaQteqBJmKRFklLIcNMdsp.get('contenttype')
  SYjoDwgvEaQteqBJmKRFklLIcNMdOG.addon_log(SYjoDwgvEaQteqBJmKRFklLIcNMdUX)
  SYjoDwgvEaQteqBJmKRFklLIcNMdOG.addon_log(SYjoDwgvEaQteqBJmKRFklLIcNMdUy)
  SYjoDwgvEaQteqBJmKRFklLIcNMdOG.addon_log(SYjoDwgvEaQteqBJmKRFklLIcNMdsb)
  SYjoDwgvEaQteqBJmKRFklLIcNMdsG=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.WavveObj.GetBookmarkInfo(SYjoDwgvEaQteqBJmKRFklLIcNMdUX,SYjoDwgvEaQteqBJmKRFklLIcNMdUy,SYjoDwgvEaQteqBJmKRFklLIcNMdsb)
  if SYjoDwgvEaQteqBJmKRFklLIcNMdUy=='tvshow':
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC={'mode':'SEASON_LIST','videoid':SYjoDwgvEaQteqBJmKRFklLIcNMdsG['indexinfo']['videoid'],'vidtype':SYjoDwgvEaQteqBJmKRFklLIcNMdsG['indexinfo']['vidtype'],}
   SYjoDwgvEaQteqBJmKRFklLIcNMdip='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(SYjoDwgvEaQteqBJmKRFklLIcNMdHC))
  else:
   SYjoDwgvEaQteqBJmKRFklLIcNMdHC={'mode':'MOVIE','contentid':SYjoDwgvEaQteqBJmKRFklLIcNMdsG['indexinfo']['videoid'],'title':SYjoDwgvEaQteqBJmKRFklLIcNMdsG['saveinfo']['infoLabels']['title'],'thumbnail':SYjoDwgvEaQteqBJmKRFklLIcNMdsG['saveinfo']['thumbnail'],'age':SYjoDwgvEaQteqBJmKRFklLIcNMdsG['saveinfo']['infoLabels']['mpaa'],}
   SYjoDwgvEaQteqBJmKRFklLIcNMdip='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(SYjoDwgvEaQteqBJmKRFklLIcNMdHC))
  SYjoDwgvEaQteqBJmKRFklLIcNMdHr=xbmcgui.ListItem(label=SYjoDwgvEaQteqBJmKRFklLIcNMdsG['saveinfo']['title'],path=SYjoDwgvEaQteqBJmKRFklLIcNMdip)
  SYjoDwgvEaQteqBJmKRFklLIcNMdHr.setArt(SYjoDwgvEaQteqBJmKRFklLIcNMdsG['saveinfo']['thumbnail'])
  SYjoDwgvEaQteqBJmKRFklLIcNMdHr.setInfo('Video',SYjoDwgvEaQteqBJmKRFklLIcNMdsG['saveinfo']['infoLabels'])
  if SYjoDwgvEaQteqBJmKRFklLIcNMdUy=='movie':
   SYjoDwgvEaQteqBJmKRFklLIcNMdHr.setIsFolder(SYjoDwgvEaQteqBJmKRFklLIcNMdGh)
   SYjoDwgvEaQteqBJmKRFklLIcNMdHr.setProperty('IsPlayable','true')
  else:
   SYjoDwgvEaQteqBJmKRFklLIcNMdHr.setIsFolder(SYjoDwgvEaQteqBJmKRFklLIcNMdGi)
   SYjoDwgvEaQteqBJmKRFklLIcNMdHr.setProperty('IsPlayable','false')
  SYjoDwgvEaQteqBJmKRFklLIcNMdOz=xbmcgui.Dialog()
  SYjoDwgvEaQteqBJmKRFklLIcNMdOz.info(SYjoDwgvEaQteqBJmKRFklLIcNMdHr)
 def wavve_main(SYjoDwgvEaQteqBJmKRFklLIcNMdOG):
  SYjoDwgvEaQteqBJmKRFklLIcNMdsu=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.main_params.get('params')
  if SYjoDwgvEaQteqBJmKRFklLIcNMdsu:
   SYjoDwgvEaQteqBJmKRFklLIcNMdsx =base64.standard_b64decode(SYjoDwgvEaQteqBJmKRFklLIcNMdsu).decode('utf-8')
   SYjoDwgvEaQteqBJmKRFklLIcNMdsx =json.loads(SYjoDwgvEaQteqBJmKRFklLIcNMdsx)
   SYjoDwgvEaQteqBJmKRFklLIcNMdHu =SYjoDwgvEaQteqBJmKRFklLIcNMdsx.get('mode')
   SYjoDwgvEaQteqBJmKRFklLIcNMdsp =SYjoDwgvEaQteqBJmKRFklLIcNMdsx.get('values')
  else:
   SYjoDwgvEaQteqBJmKRFklLIcNMdHu=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.main_params.get('mode',SYjoDwgvEaQteqBJmKRFklLIcNMdGH)
   SYjoDwgvEaQteqBJmKRFklLIcNMdsp=SYjoDwgvEaQteqBJmKRFklLIcNMdOG.main_params
  if SYjoDwgvEaQteqBJmKRFklLIcNMdHu=='LOGOUT':
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.logout()
   return
  SYjoDwgvEaQteqBJmKRFklLIcNMdOG.login_main()
  if SYjoDwgvEaQteqBJmKRFklLIcNMdHu is SYjoDwgvEaQteqBJmKRFklLIcNMdGH:
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.dp_Main_List()
  elif SYjoDwgvEaQteqBJmKRFklLIcNMdHu in['LIVE','VOD','MOVIE','SPORTS']:
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.play_VIDEO(SYjoDwgvEaQteqBJmKRFklLIcNMdsp)
  elif SYjoDwgvEaQteqBJmKRFklLIcNMdHu=='LIVE_CATAGORY':
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.dp_LiveCatagory_List(SYjoDwgvEaQteqBJmKRFklLIcNMdsp)
  elif SYjoDwgvEaQteqBJmKRFklLIcNMdHu=='MAIN_CATAGORY':
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.dp_MainCatagory_List(SYjoDwgvEaQteqBJmKRFklLIcNMdsp)
  elif SYjoDwgvEaQteqBJmKRFklLIcNMdHu=='SUPERSECTION_LIST':
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.dp_SuperSection_List(SYjoDwgvEaQteqBJmKRFklLIcNMdsp)
  elif SYjoDwgvEaQteqBJmKRFklLIcNMdHu=='BANDLIVESECTION_LIST':
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.dp_BandLiveSection_List(SYjoDwgvEaQteqBJmKRFklLIcNMdsp)
  elif SYjoDwgvEaQteqBJmKRFklLIcNMdHu=='BAND2SECTION_LIST':
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.dp_Band2Section_List(SYjoDwgvEaQteqBJmKRFklLIcNMdsp)
  elif SYjoDwgvEaQteqBJmKRFklLIcNMdHu=='PROGRAM_LIST':
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.dp_Program_List(SYjoDwgvEaQteqBJmKRFklLIcNMdsp)
  elif SYjoDwgvEaQteqBJmKRFklLIcNMdHu=='SEASON_LIST':
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.dp_Season_List(SYjoDwgvEaQteqBJmKRFklLIcNMdsp)
  elif SYjoDwgvEaQteqBJmKRFklLIcNMdHu=='EPISODE_LIST':
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.dp_Episode_List(SYjoDwgvEaQteqBJmKRFklLIcNMdsp)
  elif SYjoDwgvEaQteqBJmKRFklLIcNMdHu=='MOVIE_LIST':
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.dp_Movie_List(SYjoDwgvEaQteqBJmKRFklLIcNMdsp)
  elif SYjoDwgvEaQteqBJmKRFklLIcNMdHu=='LIVE_LIST':
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.dp_LiveChannel_List(SYjoDwgvEaQteqBJmKRFklLIcNMdsp)
  elif SYjoDwgvEaQteqBJmKRFklLIcNMdHu=='ORDER_BY':
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.dp_setEpOrderby(SYjoDwgvEaQteqBJmKRFklLIcNMdsp)
  elif SYjoDwgvEaQteqBJmKRFklLIcNMdHu=='SEARCH_GROUP':
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.dp_Search_Group(SYjoDwgvEaQteqBJmKRFklLIcNMdsp)
  elif SYjoDwgvEaQteqBJmKRFklLIcNMdHu in['SEARCH_LIST','LOCAL_SEARCH']:
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.dp_Search_List(SYjoDwgvEaQteqBJmKRFklLIcNMdsp)
  elif SYjoDwgvEaQteqBJmKRFklLIcNMdHu=='WATCH_GROUP':
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.dp_Watch_Group(SYjoDwgvEaQteqBJmKRFklLIcNMdsp)
  elif SYjoDwgvEaQteqBJmKRFklLIcNMdHu=='WATCH_LIST':
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.dp_Watch_List(SYjoDwgvEaQteqBJmKRFklLIcNMdsp)
  elif SYjoDwgvEaQteqBJmKRFklLIcNMdHu=='SET_BOOKMARK':
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.dp_Set_Bookmark(SYjoDwgvEaQteqBJmKRFklLIcNMdsp)
  elif SYjoDwgvEaQteqBJmKRFklLIcNMdHu in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.dp_History_Remove(SYjoDwgvEaQteqBJmKRFklLIcNMdsp)
  elif SYjoDwgvEaQteqBJmKRFklLIcNMdHu in['TOTAL_SEARCH','TOTAL_HISTORY']:
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.dp_Global_Search(SYjoDwgvEaQteqBJmKRFklLIcNMdsp)
  elif SYjoDwgvEaQteqBJmKRFklLIcNMdHu=='SEARCH_HISTORY':
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.dp_Search_History(SYjoDwgvEaQteqBJmKRFklLIcNMdsp)
  elif SYjoDwgvEaQteqBJmKRFklLIcNMdHu=='MENU_BOOKMARK':
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.dp_Bookmark_Menu(SYjoDwgvEaQteqBJmKRFklLIcNMdsp)
  elif SYjoDwgvEaQteqBJmKRFklLIcNMdHu=='GAME_LIST':
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.dp_Sports_GameList(SYjoDwgvEaQteqBJmKRFklLIcNMdsp)
  elif SYjoDwgvEaQteqBJmKRFklLIcNMdHu=='VIEW_DETAIL':
   SYjoDwgvEaQteqBJmKRFklLIcNMdOG.dp_View_Detail(SYjoDwgvEaQteqBJmKRFklLIcNMdsp)
  else:
   SYjoDwgvEaQteqBJmKRFklLIcNMdGH
# Created by pyminifier (https://github.com/liftoff/pyminifier)
