__author__="NightRain"
fejPAdomYDEwLVpGubHyUMrFTqvJQX=object
fejPAdomYDEwLVpGubHyUMrFTqvJQi=None
fejPAdomYDEwLVpGubHyUMrFTqvJQN=False
fejPAdomYDEwLVpGubHyUMrFTqvJQk=open
fejPAdomYDEwLVpGubHyUMrFTqvJQO=True
fejPAdomYDEwLVpGubHyUMrFTqvJQt=range
fejPAdomYDEwLVpGubHyUMrFTqvJQa=str
fejPAdomYDEwLVpGubHyUMrFTqvJQs=Exception
fejPAdomYDEwLVpGubHyUMrFTqvJQz=print
fejPAdomYDEwLVpGubHyUMrFTqvJQW=dict
fejPAdomYDEwLVpGubHyUMrFTqvJQR=int
fejPAdomYDEwLVpGubHyUMrFTqvJQc=len
import urllib
import re
import json
import sys
import requests
import datetime
import base64
class fejPAdomYDEwLVpGubHyUMrFTqvJgS(fejPAdomYDEwLVpGubHyUMrFTqvJQX):
 def __init__(fejPAdomYDEwLVpGubHyUMrFTqvJgC):
  fejPAdomYDEwLVpGubHyUMrFTqvJgC.API_DOMAIN='https://apis.wavve.com'
  fejPAdomYDEwLVpGubHyUMrFTqvJgC.WV ={}
  fejPAdomYDEwLVpGubHyUMrFTqvJgC.Init_WV_Total()
  fejPAdomYDEwLVpGubHyUMrFTqvJgC.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  fejPAdomYDEwLVpGubHyUMrFTqvJgC.DEVICE ='pc'
  fejPAdomYDEwLVpGubHyUMrFTqvJgC.DRM ='wm'
  fejPAdomYDEwLVpGubHyUMrFTqvJgC.PARTNER ='pooq'
  fejPAdomYDEwLVpGubHyUMrFTqvJgC.POOQZONE ='none'
  fejPAdomYDEwLVpGubHyUMrFTqvJgC.REGION ='kor'
  fejPAdomYDEwLVpGubHyUMrFTqvJgC.TARGETAGE ='all'
  fejPAdomYDEwLVpGubHyUMrFTqvJgC.HTTPTAG ='https://'
  fejPAdomYDEwLVpGubHyUMrFTqvJgC.LIST_LIMIT=30 
  fejPAdomYDEwLVpGubHyUMrFTqvJgC.EP_LIMIT =30 
  fejPAdomYDEwLVpGubHyUMrFTqvJgC.MV_LIMIT =24 
  fejPAdomYDEwLVpGubHyUMrFTqvJgC.SEARCH_LIMIT=20 
  fejPAdomYDEwLVpGubHyUMrFTqvJgC.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36'
  fejPAdomYDEwLVpGubHyUMrFTqvJgC.DEFAULT_HEADER={'user-agent':fejPAdomYDEwLVpGubHyUMrFTqvJgC.USER_AGENT}
 def Init_WV_Total(fejPAdomYDEwLVpGubHyUMrFTqvJgC):
  fejPAdomYDEwLVpGubHyUMrFTqvJgC.WV={'account':{},'cookies':{},}
 def callRequestCookies(fejPAdomYDEwLVpGubHyUMrFTqvJgC,jobtype,fejPAdomYDEwLVpGubHyUMrFTqvJgI,payload=fejPAdomYDEwLVpGubHyUMrFTqvJQi,params=fejPAdomYDEwLVpGubHyUMrFTqvJQi,headers=fejPAdomYDEwLVpGubHyUMrFTqvJQi,cookies=fejPAdomYDEwLVpGubHyUMrFTqvJQi,redirects=fejPAdomYDEwLVpGubHyUMrFTqvJQN):
  fejPAdomYDEwLVpGubHyUMrFTqvJgh=fejPAdomYDEwLVpGubHyUMrFTqvJgC.DEFAULT_HEADER
  if headers:fejPAdomYDEwLVpGubHyUMrFTqvJgh.update(headers)
  if jobtype=='Get':
   fejPAdomYDEwLVpGubHyUMrFTqvJgl=requests.get(fejPAdomYDEwLVpGubHyUMrFTqvJgI,params=params,headers=fejPAdomYDEwLVpGubHyUMrFTqvJgh,cookies=cookies,allow_redirects=redirects)
  else:
   fejPAdomYDEwLVpGubHyUMrFTqvJgl=requests.post(fejPAdomYDEwLVpGubHyUMrFTqvJgI,json=payload,params=params,headers=fejPAdomYDEwLVpGubHyUMrFTqvJgh,cookies=cookies,allow_redirects=redirects)
  return fejPAdomYDEwLVpGubHyUMrFTqvJgl
 def JsonFile_Save(fejPAdomYDEwLVpGubHyUMrFTqvJgC,filename,fejPAdomYDEwLVpGubHyUMrFTqvJgQ):
  if filename=='':return fejPAdomYDEwLVpGubHyUMrFTqvJQN
  try:
   fp=fejPAdomYDEwLVpGubHyUMrFTqvJQk(filename,'w',-1,'utf-8')
   json.dump(fejPAdomYDEwLVpGubHyUMrFTqvJgQ,fp,indent=4,ensure_ascii=fejPAdomYDEwLVpGubHyUMrFTqvJQN)
   fp.close()
  except:
   return fejPAdomYDEwLVpGubHyUMrFTqvJQN
  return fejPAdomYDEwLVpGubHyUMrFTqvJQO
 def JsonFile_Load(fejPAdomYDEwLVpGubHyUMrFTqvJgC,filename):
  if filename=='':return{}
  try:
   fp=fejPAdomYDEwLVpGubHyUMrFTqvJQk(filename,'r',-1,'utf-8')
   fejPAdomYDEwLVpGubHyUMrFTqvJgn=json.load(fp)
   fp.close()
  except:
   return{}
  return fejPAdomYDEwLVpGubHyUMrFTqvJgn
 def Save_session_acount(fejPAdomYDEwLVpGubHyUMrFTqvJgC,fejPAdomYDEwLVpGubHyUMrFTqvJgx,fejPAdomYDEwLVpGubHyUMrFTqvJgX,fejPAdomYDEwLVpGubHyUMrFTqvJgi):
  fejPAdomYDEwLVpGubHyUMrFTqvJgC.WV['account']['wvid']=base64.standard_b64encode(fejPAdomYDEwLVpGubHyUMrFTqvJgx.encode()).decode('utf-8')
  fejPAdomYDEwLVpGubHyUMrFTqvJgC.WV['account']['wvpw']=base64.standard_b64encode(fejPAdomYDEwLVpGubHyUMrFTqvJgX.encode()).decode('utf-8')
  fejPAdomYDEwLVpGubHyUMrFTqvJgC.WV['account']['wvpf']=fejPAdomYDEwLVpGubHyUMrFTqvJgi 
 def Load_session_acount(fejPAdomYDEwLVpGubHyUMrFTqvJgC):
  try:
   fejPAdomYDEwLVpGubHyUMrFTqvJgx=base64.standard_b64decode(fejPAdomYDEwLVpGubHyUMrFTqvJgC.WV['account']['wvid']).decode('utf-8')
   fejPAdomYDEwLVpGubHyUMrFTqvJgX=base64.standard_b64decode(fejPAdomYDEwLVpGubHyUMrFTqvJgC.WV['account']['wvpw']).decode('utf-8')
   fejPAdomYDEwLVpGubHyUMrFTqvJgi=fejPAdomYDEwLVpGubHyUMrFTqvJgC.WV['account']['wvpf']
  except:
   return '','',0
  return fejPAdomYDEwLVpGubHyUMrFTqvJgx,fejPAdomYDEwLVpGubHyUMrFTqvJgX,fejPAdomYDEwLVpGubHyUMrFTqvJgi
 def GetDefaultParams(fejPAdomYDEwLVpGubHyUMrFTqvJgC,login=fejPAdomYDEwLVpGubHyUMrFTqvJQO):
  fejPAdomYDEwLVpGubHyUMrFTqvJgN={'apikey':fejPAdomYDEwLVpGubHyUMrFTqvJgC.APIKEY,'credential':fejPAdomYDEwLVpGubHyUMrFTqvJgC.WV['cookies']['credential']if login else 'none','device':fejPAdomYDEwLVpGubHyUMrFTqvJgC.DEVICE,'drm':fejPAdomYDEwLVpGubHyUMrFTqvJgC.DRM,'partner':fejPAdomYDEwLVpGubHyUMrFTqvJgC.PARTNER,'pooqzone':fejPAdomYDEwLVpGubHyUMrFTqvJgC.POOQZONE,'region':fejPAdomYDEwLVpGubHyUMrFTqvJgC.REGION,'targetage':fejPAdomYDEwLVpGubHyUMrFTqvJgC.TARGETAGE,}
  return fejPAdomYDEwLVpGubHyUMrFTqvJgN
 def GetDefaultParams_AND(fejPAdomYDEwLVpGubHyUMrFTqvJgC):
  fejPAdomYDEwLVpGubHyUMrFTqvJgN={'apikey':'6A87455D54481A536DFB8AD397C5EC4D','credential':fejPAdomYDEwLVpGubHyUMrFTqvJgC.WV['cookies']['credential'],'device':'ott','drm':fejPAdomYDEwLVpGubHyUMrFTqvJgC.DRM,'partner':fejPAdomYDEwLVpGubHyUMrFTqvJgC.PARTNER,'pooqzone':fejPAdomYDEwLVpGubHyUMrFTqvJgC.POOQZONE,'region':fejPAdomYDEwLVpGubHyUMrFTqvJgC.REGION,'targetage':fejPAdomYDEwLVpGubHyUMrFTqvJgC.TARGETAGE,}
  return fejPAdomYDEwLVpGubHyUMrFTqvJgN
 def GetGUID(fejPAdomYDEwLVpGubHyUMrFTqvJgC,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   fejPAdomYDEwLVpGubHyUMrFTqvJgk=fejPAdomYDEwLVpGubHyUMrFTqvJgC.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   fejPAdomYDEwLVpGubHyUMrFTqvJgO=GenerateRandomString(5)
   fejPAdomYDEwLVpGubHyUMrFTqvJgt=fejPAdomYDEwLVpGubHyUMrFTqvJgO+media+fejPAdomYDEwLVpGubHyUMrFTqvJgk
   return fejPAdomYDEwLVpGubHyUMrFTqvJgt
  def GenerateRandomString(num):
   from random import randint
   fejPAdomYDEwLVpGubHyUMrFTqvJga=""
   for i in fejPAdomYDEwLVpGubHyUMrFTqvJQt(0,num):
    s=fejPAdomYDEwLVpGubHyUMrFTqvJQa(randint(1,5))
    fejPAdomYDEwLVpGubHyUMrFTqvJga+=s
   return fejPAdomYDEwLVpGubHyUMrFTqvJga
  if guidType==3:
   fejPAdomYDEwLVpGubHyUMrFTqvJgt=guid_str
  else:
   fejPAdomYDEwLVpGubHyUMrFTqvJgt=GenerateID(guid_str)
  fejPAdomYDEwLVpGubHyUMrFTqvJgs=fejPAdomYDEwLVpGubHyUMrFTqvJgC.GetHash(fejPAdomYDEwLVpGubHyUMrFTqvJgt)
  if guidType in[2,3]:
   fejPAdomYDEwLVpGubHyUMrFTqvJgs='%s-%s-%s-%s-%s'%(fejPAdomYDEwLVpGubHyUMrFTqvJgs[:8],fejPAdomYDEwLVpGubHyUMrFTqvJgs[8:12],fejPAdomYDEwLVpGubHyUMrFTqvJgs[12:16],fejPAdomYDEwLVpGubHyUMrFTqvJgs[16:20],fejPAdomYDEwLVpGubHyUMrFTqvJgs[20:])
  return fejPAdomYDEwLVpGubHyUMrFTqvJgs
 def GetHash(fejPAdomYDEwLVpGubHyUMrFTqvJgC,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return fejPAdomYDEwLVpGubHyUMrFTqvJQa(m.hexdigest())
 def CheckQuality(fejPAdomYDEwLVpGubHyUMrFTqvJgC,sel_qt,qt_list):
  fejPAdomYDEwLVpGubHyUMrFTqvJgz=0
  for fejPAdomYDEwLVpGubHyUMrFTqvJgW in qt_list:
   if sel_qt>=fejPAdomYDEwLVpGubHyUMrFTqvJgW:return fejPAdomYDEwLVpGubHyUMrFTqvJgW
   fejPAdomYDEwLVpGubHyUMrFTqvJgz=fejPAdomYDEwLVpGubHyUMrFTqvJgW
  return fejPAdomYDEwLVpGubHyUMrFTqvJgz
 def Get_Now_Datetime(fejPAdomYDEwLVpGubHyUMrFTqvJgC):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(fejPAdomYDEwLVpGubHyUMrFTqvJgC,in_text):
  fejPAdomYDEwLVpGubHyUMrFTqvJgc=in_text.replace('&lt;','<').replace('&gt;','>')
  fejPAdomYDEwLVpGubHyUMrFTqvJgc=fejPAdomYDEwLVpGubHyUMrFTqvJgc.replace('$O$','')
  fejPAdomYDEwLVpGubHyUMrFTqvJgc=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',fejPAdomYDEwLVpGubHyUMrFTqvJgc)
  fejPAdomYDEwLVpGubHyUMrFTqvJgc=fejPAdomYDEwLVpGubHyUMrFTqvJgc.lstrip('#')
  return fejPAdomYDEwLVpGubHyUMrFTqvJgc
 def GetCredential(fejPAdomYDEwLVpGubHyUMrFTqvJgC,user_id,user_pw,user_pf):
  fejPAdomYDEwLVpGubHyUMrFTqvJgK=fejPAdomYDEwLVpGubHyUMrFTqvJQN
  try:
   fejPAdomYDEwLVpGubHyUMrFTqvJgI=fejPAdomYDEwLVpGubHyUMrFTqvJgC.API_DOMAIN+ '/login'
   fejPAdomYDEwLVpGubHyUMrFTqvJgN=fejPAdomYDEwLVpGubHyUMrFTqvJgC.GetDefaultParams(login=fejPAdomYDEwLVpGubHyUMrFTqvJQN)
   fejPAdomYDEwLVpGubHyUMrFTqvJSg={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   fejPAdomYDEwLVpGubHyUMrFTqvJSC=fejPAdomYDEwLVpGubHyUMrFTqvJgC.callRequestCookies('Post',fejPAdomYDEwLVpGubHyUMrFTqvJgI,payload=fejPAdomYDEwLVpGubHyUMrFTqvJSg,params=fejPAdomYDEwLVpGubHyUMrFTqvJgN,headers=fejPAdomYDEwLVpGubHyUMrFTqvJQi,cookies=fejPAdomYDEwLVpGubHyUMrFTqvJQi)
   fejPAdomYDEwLVpGubHyUMrFTqvJSh=json.loads(fejPAdomYDEwLVpGubHyUMrFTqvJSC.text)
   fejPAdomYDEwLVpGubHyUMrFTqvJgC.WV['cookies']['credential']=fejPAdomYDEwLVpGubHyUMrFTqvJSh['credential']
   if user_pf!=0:
    fejPAdomYDEwLVpGubHyUMrFTqvJSg={'id':fejPAdomYDEwLVpGubHyUMrFTqvJgC.WV['cookies']['credential'],'password':'','profile':fejPAdomYDEwLVpGubHyUMrFTqvJQa(user_pf),'pushid':'','type':'credential'}
    fejPAdomYDEwLVpGubHyUMrFTqvJgN =fejPAdomYDEwLVpGubHyUMrFTqvJgC.GetDefaultParams(login=fejPAdomYDEwLVpGubHyUMrFTqvJQO) 
    fejPAdomYDEwLVpGubHyUMrFTqvJSC=fejPAdomYDEwLVpGubHyUMrFTqvJgC.callRequestCookies('Post',fejPAdomYDEwLVpGubHyUMrFTqvJgI,payload=fejPAdomYDEwLVpGubHyUMrFTqvJSg,params=fejPAdomYDEwLVpGubHyUMrFTqvJgN,headers=fejPAdomYDEwLVpGubHyUMrFTqvJQi,cookies=fejPAdomYDEwLVpGubHyUMrFTqvJQi)
    fejPAdomYDEwLVpGubHyUMrFTqvJSh=json.loads(fejPAdomYDEwLVpGubHyUMrFTqvJSC.text)
    fejPAdomYDEwLVpGubHyUMrFTqvJgC.WV['cookies']['credential']=fejPAdomYDEwLVpGubHyUMrFTqvJSh['credential']
   fejPAdomYDEwLVpGubHyUMrFTqvJSl=user_id+fejPAdomYDEwLVpGubHyUMrFTqvJQa(user_pf) 
   fejPAdomYDEwLVpGubHyUMrFTqvJgC.WV['cookies']['uuid']=fejPAdomYDEwLVpGubHyUMrFTqvJgC.GetGUID(guid_str=fejPAdomYDEwLVpGubHyUMrFTqvJSl,guidType=3)
   fejPAdomYDEwLVpGubHyUMrFTqvJgK=fejPAdomYDEwLVpGubHyUMrFTqvJQO
  except fejPAdomYDEwLVpGubHyUMrFTqvJQs as exception:
   fejPAdomYDEwLVpGubHyUMrFTqvJQz(exception)
   fejPAdomYDEwLVpGubHyUMrFTqvJgC.Init_WV_Total()
  return fejPAdomYDEwLVpGubHyUMrFTqvJgK
 def GetIssue(fejPAdomYDEwLVpGubHyUMrFTqvJgC):
  fejPAdomYDEwLVpGubHyUMrFTqvJSQ=fejPAdomYDEwLVpGubHyUMrFTqvJQN
  try:
   fejPAdomYDEwLVpGubHyUMrFTqvJgI=fejPAdomYDEwLVpGubHyUMrFTqvJgC.API_DOMAIN+'/guid/issue'
   fejPAdomYDEwLVpGubHyUMrFTqvJgN=fejPAdomYDEwLVpGubHyUMrFTqvJgC.GetDefaultParams()
   fejPAdomYDEwLVpGubHyUMrFTqvJSC=fejPAdomYDEwLVpGubHyUMrFTqvJgC.callRequestCookies('Get',fejPAdomYDEwLVpGubHyUMrFTqvJgI,payload=fejPAdomYDEwLVpGubHyUMrFTqvJQi,params=fejPAdomYDEwLVpGubHyUMrFTqvJgN,headers=fejPAdomYDEwLVpGubHyUMrFTqvJQi,cookies=fejPAdomYDEwLVpGubHyUMrFTqvJQi)
   fejPAdomYDEwLVpGubHyUMrFTqvJSh=json.loads(fejPAdomYDEwLVpGubHyUMrFTqvJSC.text)
   fejPAdomYDEwLVpGubHyUMrFTqvJSB=fejPAdomYDEwLVpGubHyUMrFTqvJSh['guid']
   fejPAdomYDEwLVpGubHyUMrFTqvJSn=fejPAdomYDEwLVpGubHyUMrFTqvJSh['guidtimestamp']
   if fejPAdomYDEwLVpGubHyUMrFTqvJSB:fejPAdomYDEwLVpGubHyUMrFTqvJSQ=fejPAdomYDEwLVpGubHyUMrFTqvJQO
  except fejPAdomYDEwLVpGubHyUMrFTqvJQs as exception:
   fejPAdomYDEwLVpGubHyUMrFTqvJQz(exception)
   fejPAdomYDEwLVpGubHyUMrFTqvJSB='none'
   fejPAdomYDEwLVpGubHyUMrFTqvJSn='none' 
  fejPAdomYDEwLVpGubHyUMrFTqvJgC.guid=fejPAdomYDEwLVpGubHyUMrFTqvJSB
  fejPAdomYDEwLVpGubHyUMrFTqvJgC.guidtimestamp=fejPAdomYDEwLVpGubHyUMrFTqvJSn
  return fejPAdomYDEwLVpGubHyUMrFTqvJSQ
 def Baseapi_Parse(fejPAdomYDEwLVpGubHyUMrFTqvJgC,fejPAdomYDEwLVpGubHyUMrFTqvJSN):
  try:
   fejPAdomYDEwLVpGubHyUMrFTqvJSx =urllib.parse.urlsplit(fejPAdomYDEwLVpGubHyUMrFTqvJSN)
   if fejPAdomYDEwLVpGubHyUMrFTqvJSx.netloc=='':
    fejPAdomYDEwLVpGubHyUMrFTqvJgI=fejPAdomYDEwLVpGubHyUMrFTqvJgC.HTTPTAG+fejPAdomYDEwLVpGubHyUMrFTqvJSx.netloc+fejPAdomYDEwLVpGubHyUMrFTqvJSx.path
   else:
    fejPAdomYDEwLVpGubHyUMrFTqvJgI=fejPAdomYDEwLVpGubHyUMrFTqvJSx.scheme+'://'+fejPAdomYDEwLVpGubHyUMrFTqvJSx.netloc+fejPAdomYDEwLVpGubHyUMrFTqvJSx.path
   fejPAdomYDEwLVpGubHyUMrFTqvJgN=fejPAdomYDEwLVpGubHyUMrFTqvJQW(urllib.parse.parse_qsl(fejPAdomYDEwLVpGubHyUMrFTqvJSx.query))
  except fejPAdomYDEwLVpGubHyUMrFTqvJQs as exception:
   fejPAdomYDEwLVpGubHyUMrFTqvJQz(exception)
   return '',{}
  return fejPAdomYDEwLVpGubHyUMrFTqvJgI,fejPAdomYDEwLVpGubHyUMrFTqvJgN
 def GetSupermultiUrl(fejPAdomYDEwLVpGubHyUMrFTqvJgC,sCode,sIndex='0'):
  try:
   fejPAdomYDEwLVpGubHyUMrFTqvJgI=fejPAdomYDEwLVpGubHyUMrFTqvJgC.API_DOMAIN+'/cf/supermultisections/'+sCode
   fejPAdomYDEwLVpGubHyUMrFTqvJgN=fejPAdomYDEwLVpGubHyUMrFTqvJgC.GetDefaultParams(login=fejPAdomYDEwLVpGubHyUMrFTqvJQN)
   fejPAdomYDEwLVpGubHyUMrFTqvJSC=fejPAdomYDEwLVpGubHyUMrFTqvJgC.callRequestCookies('Get',fejPAdomYDEwLVpGubHyUMrFTqvJgI,payload=fejPAdomYDEwLVpGubHyUMrFTqvJQi,params=fejPAdomYDEwLVpGubHyUMrFTqvJgN,headers=fejPAdomYDEwLVpGubHyUMrFTqvJQi,cookies=fejPAdomYDEwLVpGubHyUMrFTqvJQi)
   fejPAdomYDEwLVpGubHyUMrFTqvJSh=json.loads(fejPAdomYDEwLVpGubHyUMrFTqvJSC.text)
   fejPAdomYDEwLVpGubHyUMrFTqvJSX=fejPAdomYDEwLVpGubHyUMrFTqvJSh['multisectionlist'][fejPAdomYDEwLVpGubHyUMrFTqvJQR(sIndex)]['eventlist'][1]['url']
  except fejPAdomYDEwLVpGubHyUMrFTqvJQs as exception:
   fejPAdomYDEwLVpGubHyUMrFTqvJQz(exception)
   return ''
  return fejPAdomYDEwLVpGubHyUMrFTqvJSX
 def Get_LiveCatagory_List(fejPAdomYDEwLVpGubHyUMrFTqvJgC,sCode,sIndex='0'):
  fejPAdomYDEwLVpGubHyUMrFTqvJSi=[]
  fejPAdomYDEwLVpGubHyUMrFTqvJSN =fejPAdomYDEwLVpGubHyUMrFTqvJgC.GetSupermultiUrl(sCode,sIndex)
  (fejPAdomYDEwLVpGubHyUMrFTqvJgI,fejPAdomYDEwLVpGubHyUMrFTqvJgN)=fejPAdomYDEwLVpGubHyUMrFTqvJgC.Baseapi_Parse(fejPAdomYDEwLVpGubHyUMrFTqvJSN)
  if fejPAdomYDEwLVpGubHyUMrFTqvJgI=='':return fejPAdomYDEwLVpGubHyUMrFTqvJSi,''
  try:
   fejPAdomYDEwLVpGubHyUMrFTqvJgN.update(fejPAdomYDEwLVpGubHyUMrFTqvJgC.GetDefaultParams(login=fejPAdomYDEwLVpGubHyUMrFTqvJQN))
   fejPAdomYDEwLVpGubHyUMrFTqvJSC=fejPAdomYDEwLVpGubHyUMrFTqvJgC.callRequestCookies('Get',fejPAdomYDEwLVpGubHyUMrFTqvJgI,payload=fejPAdomYDEwLVpGubHyUMrFTqvJQi,params=fejPAdomYDEwLVpGubHyUMrFTqvJgN,headers=fejPAdomYDEwLVpGubHyUMrFTqvJQi,cookies=fejPAdomYDEwLVpGubHyUMrFTqvJQi)
   fejPAdomYDEwLVpGubHyUMrFTqvJSh=json.loads(fejPAdomYDEwLVpGubHyUMrFTqvJSC.text)
   if not('filter_item_list' in fejPAdomYDEwLVpGubHyUMrFTqvJSh['filter']['filterlist'][0]):return[],''
   fejPAdomYDEwLVpGubHyUMrFTqvJSO=fejPAdomYDEwLVpGubHyUMrFTqvJSh['filter']['filterlist'][0]['filter_item_list']
   for fejPAdomYDEwLVpGubHyUMrFTqvJSt in fejPAdomYDEwLVpGubHyUMrFTqvJSO:
    fejPAdomYDEwLVpGubHyUMrFTqvJSa={'title':fejPAdomYDEwLVpGubHyUMrFTqvJSt['title'],'genre':fejPAdomYDEwLVpGubHyUMrFTqvJSt['api_parameters'][fejPAdomYDEwLVpGubHyUMrFTqvJSt['api_parameters'].index('=')+1:]}
    fejPAdomYDEwLVpGubHyUMrFTqvJSi.append(fejPAdomYDEwLVpGubHyUMrFTqvJSa)
  except fejPAdomYDEwLVpGubHyUMrFTqvJQs as exception:
   fejPAdomYDEwLVpGubHyUMrFTqvJQz(exception)
   return[],''
  return fejPAdomYDEwLVpGubHyUMrFTqvJSi,fejPAdomYDEwLVpGubHyUMrFTqvJSN
 def Get_MainCatagory_List(fejPAdomYDEwLVpGubHyUMrFTqvJgC,sCode,sIndex,sType):
  fejPAdomYDEwLVpGubHyUMrFTqvJSi=[]
  fejPAdomYDEwLVpGubHyUMrFTqvJgI='https://apis.wavve.com/es/category/launcher-band'
  fejPAdomYDEwLVpGubHyUMrFTqvJgN={'uitype':sCode,'uiparent':'GN52-'+sCode,'uirank':sIndex,'broadcastid':sCode,'offset':'0','limit':'20','uicode':sCode,'mtype':'N','ctype':sType,'orderby':'default',}
  try:
   fejPAdomYDEwLVpGubHyUMrFTqvJgN.update(fejPAdomYDEwLVpGubHyUMrFTqvJgC.GetDefaultParams(login=fejPAdomYDEwLVpGubHyUMrFTqvJQN))
   fejPAdomYDEwLVpGubHyUMrFTqvJSC=fejPAdomYDEwLVpGubHyUMrFTqvJgC.callRequestCookies('Get',fejPAdomYDEwLVpGubHyUMrFTqvJgI,payload=fejPAdomYDEwLVpGubHyUMrFTqvJQi,params=fejPAdomYDEwLVpGubHyUMrFTqvJgN,headers=fejPAdomYDEwLVpGubHyUMrFTqvJQi,cookies=fejPAdomYDEwLVpGubHyUMrFTqvJQi)
   fejPAdomYDEwLVpGubHyUMrFTqvJSh=json.loads(fejPAdomYDEwLVpGubHyUMrFTqvJSC.text)
   if not('celllist' in fejPAdomYDEwLVpGubHyUMrFTqvJSh['band']):return[]
   fejPAdomYDEwLVpGubHyUMrFTqvJSO=fejPAdomYDEwLVpGubHyUMrFTqvJSh['band']['celllist']
   for fejPAdomYDEwLVpGubHyUMrFTqvJSt in fejPAdomYDEwLVpGubHyUMrFTqvJSO:
    fejPAdomYDEwLVpGubHyUMrFTqvJSs =fejPAdomYDEwLVpGubHyUMrFTqvJSt['event_list'][1]['url']
    (fejPAdomYDEwLVpGubHyUMrFTqvJSz,fejPAdomYDEwLVpGubHyUMrFTqvJSW)=fejPAdomYDEwLVpGubHyUMrFTqvJgC.Baseapi_Parse(fejPAdomYDEwLVpGubHyUMrFTqvJSs)
    fejPAdomYDEwLVpGubHyUMrFTqvJSa={'title':fejPAdomYDEwLVpGubHyUMrFTqvJSt['title_list'][0]['text'],'suburl':fejPAdomYDEwLVpGubHyUMrFTqvJSz,'subapi':fejPAdomYDEwLVpGubHyUMrFTqvJSW.get('api'),'subtype':'catagory' if fejPAdomYDEwLVpGubHyUMrFTqvJSW else 'supersection'}
    fejPAdomYDEwLVpGubHyUMrFTqvJSi.append(fejPAdomYDEwLVpGubHyUMrFTqvJSa)
  except fejPAdomYDEwLVpGubHyUMrFTqvJQs as exception:
   fejPAdomYDEwLVpGubHyUMrFTqvJQz(exception)
   return[]
  return fejPAdomYDEwLVpGubHyUMrFTqvJSi
 def Get_SuperMultiSection_List(fejPAdomYDEwLVpGubHyUMrFTqvJgC,subapi_text):
  fejPAdomYDEwLVpGubHyUMrFTqvJSi=[]
  if '/multiband/' in subapi_text: 
   fejPAdomYDEwLVpGubHyUMrFTqvJgI=subapi_text 
   fejPAdomYDEwLVpGubHyUMrFTqvJgN={'client':'40'}
  else:
   fejPAdomYDEwLVpGubHyUMrFTqvJgI=subapi_text 
   fejPAdomYDEwLVpGubHyUMrFTqvJgI=fejPAdomYDEwLVpGubHyUMrFTqvJgI.replace('www.wavve.com','apis.wavve.com').replace('supermultisection','v1/multiband')
   fejPAdomYDEwLVpGubHyUMrFTqvJgN={}
  try:
   fejPAdomYDEwLVpGubHyUMrFTqvJgN.update(fejPAdomYDEwLVpGubHyUMrFTqvJgC.GetDefaultParams(login=fejPAdomYDEwLVpGubHyUMrFTqvJQN))
   fejPAdomYDEwLVpGubHyUMrFTqvJSC=fejPAdomYDEwLVpGubHyUMrFTqvJgC.callRequestCookies('Get',fejPAdomYDEwLVpGubHyUMrFTqvJgI,payload=fejPAdomYDEwLVpGubHyUMrFTqvJQi,params=fejPAdomYDEwLVpGubHyUMrFTqvJgN,headers=fejPAdomYDEwLVpGubHyUMrFTqvJQi,cookies=fejPAdomYDEwLVpGubHyUMrFTqvJQi)
   fejPAdomYDEwLVpGubHyUMrFTqvJSh=json.loads(fejPAdomYDEwLVpGubHyUMrFTqvJSC.text)
   if not('multisectionlist' in fejPAdomYDEwLVpGubHyUMrFTqvJSh):return[]
   fejPAdomYDEwLVpGubHyUMrFTqvJSO=fejPAdomYDEwLVpGubHyUMrFTqvJSh['multisectionlist']
   for fejPAdomYDEwLVpGubHyUMrFTqvJSt in fejPAdomYDEwLVpGubHyUMrFTqvJSO:
    fejPAdomYDEwLVpGubHyUMrFTqvJSR=fejPAdomYDEwLVpGubHyUMrFTqvJSt['title']
    if fejPAdomYDEwLVpGubHyUMrFTqvJQc(fejPAdomYDEwLVpGubHyUMrFTqvJSR)==0:continue
    if fejPAdomYDEwLVpGubHyUMrFTqvJSR=='minor':continue
    if re.search(u'베너',fejPAdomYDEwLVpGubHyUMrFTqvJSR):continue
    if re.search(u'배너',fejPAdomYDEwLVpGubHyUMrFTqvJSR):continue 
    if fejPAdomYDEwLVpGubHyUMrFTqvJSt['force_refresh']=='y':continue
    if fejPAdomYDEwLVpGubHyUMrFTqvJQc(fejPAdomYDEwLVpGubHyUMrFTqvJSt['eventlist'])>=3:
     fejPAdomYDEwLVpGubHyUMrFTqvJSW =fejPAdomYDEwLVpGubHyUMrFTqvJSt['eventlist'][2]['url']
    else:
     fejPAdomYDEwLVpGubHyUMrFTqvJSW =fejPAdomYDEwLVpGubHyUMrFTqvJSt['eventlist'][1]['url']
    fejPAdomYDEwLVpGubHyUMrFTqvJSc=fejPAdomYDEwLVpGubHyUMrFTqvJSt['cell_type']
    if fejPAdomYDEwLVpGubHyUMrFTqvJSc=='band_2':
     if fejPAdomYDEwLVpGubHyUMrFTqvJSW.find('channellist=')>=0:
      fejPAdomYDEwLVpGubHyUMrFTqvJSc='band_live'
    fejPAdomYDEwLVpGubHyUMrFTqvJSa={'title':fejPAdomYDEwLVpGubHyUMrFTqvJgC.Get_ChangeText(fejPAdomYDEwLVpGubHyUMrFTqvJSR),'subapi':fejPAdomYDEwLVpGubHyUMrFTqvJSW,'cell_type':fejPAdomYDEwLVpGubHyUMrFTqvJSc}
    fejPAdomYDEwLVpGubHyUMrFTqvJSi.append(fejPAdomYDEwLVpGubHyUMrFTqvJSa)
  except fejPAdomYDEwLVpGubHyUMrFTqvJQs as exception:
   fejPAdomYDEwLVpGubHyUMrFTqvJQz(exception)
   return[]
  return fejPAdomYDEwLVpGubHyUMrFTqvJSi
 def Get_BandLiveSection_List(fejPAdomYDEwLVpGubHyUMrFTqvJgC,fejPAdomYDEwLVpGubHyUMrFTqvJSN,page_int=1):
  fejPAdomYDEwLVpGubHyUMrFTqvJSK=[]
  fejPAdomYDEwLVpGubHyUMrFTqvJSI=fejPAdomYDEwLVpGubHyUMrFTqvJCB=1
  fejPAdomYDEwLVpGubHyUMrFTqvJCg=fejPAdomYDEwLVpGubHyUMrFTqvJQN
  try:
   (fejPAdomYDEwLVpGubHyUMrFTqvJgI,fejPAdomYDEwLVpGubHyUMrFTqvJgN)=fejPAdomYDEwLVpGubHyUMrFTqvJgC.Baseapi_Parse(fejPAdomYDEwLVpGubHyUMrFTqvJSN)
  except fejPAdomYDEwLVpGubHyUMrFTqvJQs as exception:
   fejPAdomYDEwLVpGubHyUMrFTqvJQz(exception)
   return[],fejPAdomYDEwLVpGubHyUMrFTqvJQN
  try:
   fejPAdomYDEwLVpGubHyUMrFTqvJgN['limit']=fejPAdomYDEwLVpGubHyUMrFTqvJgC.LIST_LIMIT
   fejPAdomYDEwLVpGubHyUMrFTqvJgN['offset']=fejPAdomYDEwLVpGubHyUMrFTqvJQa((page_int-1)*fejPAdomYDEwLVpGubHyUMrFTqvJgC.LIST_LIMIT)
   fejPAdomYDEwLVpGubHyUMrFTqvJgN.update(fejPAdomYDEwLVpGubHyUMrFTqvJgC.GetDefaultParams(login=fejPAdomYDEwLVpGubHyUMrFTqvJQN))
   fejPAdomYDEwLVpGubHyUMrFTqvJSC=fejPAdomYDEwLVpGubHyUMrFTqvJgC.callRequestCookies('Get',fejPAdomYDEwLVpGubHyUMrFTqvJgI,payload=fejPAdomYDEwLVpGubHyUMrFTqvJQi,params=fejPAdomYDEwLVpGubHyUMrFTqvJgN,headers=fejPAdomYDEwLVpGubHyUMrFTqvJQi,cookies=fejPAdomYDEwLVpGubHyUMrFTqvJQi)
   fejPAdomYDEwLVpGubHyUMrFTqvJSh=json.loads(fejPAdomYDEwLVpGubHyUMrFTqvJSC.text)
   if not('celllist' in fejPAdomYDEwLVpGubHyUMrFTqvJSh['cell_toplist']):return[],fejPAdomYDEwLVpGubHyUMrFTqvJQN
   fejPAdomYDEwLVpGubHyUMrFTqvJSO=fejPAdomYDEwLVpGubHyUMrFTqvJSh['cell_toplist']['celllist']
   for fejPAdomYDEwLVpGubHyUMrFTqvJSt in fejPAdomYDEwLVpGubHyUMrFTqvJSO:
    fejPAdomYDEwLVpGubHyUMrFTqvJCS =fejPAdomYDEwLVpGubHyUMrFTqvJSt['event_list'][1]['url']
    fejPAdomYDEwLVpGubHyUMrFTqvJCh=urllib.parse.urlsplit(fejPAdomYDEwLVpGubHyUMrFTqvJCS).query
    fejPAdomYDEwLVpGubHyUMrFTqvJCh=fejPAdomYDEwLVpGubHyUMrFTqvJQW(urllib.parse.parse_qsl(fejPAdomYDEwLVpGubHyUMrFTqvJCh))
    fejPAdomYDEwLVpGubHyUMrFTqvJCl='channelid'
    fejPAdomYDEwLVpGubHyUMrFTqvJCQ=fejPAdomYDEwLVpGubHyUMrFTqvJCh[fejPAdomYDEwLVpGubHyUMrFTqvJCl]
    fejPAdomYDEwLVpGubHyUMrFTqvJSa={'studio':fejPAdomYDEwLVpGubHyUMrFTqvJSt['title_list'][0]['text'],'tvshowtitle':fejPAdomYDEwLVpGubHyUMrFTqvJgC.Get_ChangeText(fejPAdomYDEwLVpGubHyUMrFTqvJSt['title_list'][1]['text']),'channelid':fejPAdomYDEwLVpGubHyUMrFTqvJCQ,'age':fejPAdomYDEwLVpGubHyUMrFTqvJSt.get('age'),'thumbnail':'https://%s'%fejPAdomYDEwLVpGubHyUMrFTqvJSt.get('thumbnail')}
    fejPAdomYDEwLVpGubHyUMrFTqvJSK.append(fejPAdomYDEwLVpGubHyUMrFTqvJSa)
   fejPAdomYDEwLVpGubHyUMrFTqvJSI=fejPAdomYDEwLVpGubHyUMrFTqvJQR(fejPAdomYDEwLVpGubHyUMrFTqvJSh['cell_toplist']['pagecount'])
   if fejPAdomYDEwLVpGubHyUMrFTqvJSh['cell_toplist']['count']:fejPAdomYDEwLVpGubHyUMrFTqvJCB =fejPAdomYDEwLVpGubHyUMrFTqvJQR(fejPAdomYDEwLVpGubHyUMrFTqvJSh['cell_toplist']['count'])
   else:fejPAdomYDEwLVpGubHyUMrFTqvJCB=fejPAdomYDEwLVpGubHyUMrFTqvJgC.LIST_LIMIT*page_int
   fejPAdomYDEwLVpGubHyUMrFTqvJCg=fejPAdomYDEwLVpGubHyUMrFTqvJSI>fejPAdomYDEwLVpGubHyUMrFTqvJCB
  except fejPAdomYDEwLVpGubHyUMrFTqvJQs as exception:
   fejPAdomYDEwLVpGubHyUMrFTqvJQz(exception)
   return[],fejPAdomYDEwLVpGubHyUMrFTqvJQN
  return fejPAdomYDEwLVpGubHyUMrFTqvJSK,fejPAdomYDEwLVpGubHyUMrFTqvJCg
 def Get_Band2Section_List(fejPAdomYDEwLVpGubHyUMrFTqvJgC,fejPAdomYDEwLVpGubHyUMrFTqvJSN,page_int=1):
  fejPAdomYDEwLVpGubHyUMrFTqvJCn=[]
  fejPAdomYDEwLVpGubHyUMrFTqvJSI=fejPAdomYDEwLVpGubHyUMrFTqvJCB=1
  fejPAdomYDEwLVpGubHyUMrFTqvJCg=fejPAdomYDEwLVpGubHyUMrFTqvJQN
  try:
   (fejPAdomYDEwLVpGubHyUMrFTqvJgI,fejPAdomYDEwLVpGubHyUMrFTqvJgN)=fejPAdomYDEwLVpGubHyUMrFTqvJgC.Baseapi_Parse(fejPAdomYDEwLVpGubHyUMrFTqvJSN)
  except fejPAdomYDEwLVpGubHyUMrFTqvJQs as exception:
   fejPAdomYDEwLVpGubHyUMrFTqvJQz(exception)
   return[],fejPAdomYDEwLVpGubHyUMrFTqvJQN
  try:
   fejPAdomYDEwLVpGubHyUMrFTqvJgN['came'] ='BandView'
   fejPAdomYDEwLVpGubHyUMrFTqvJgN['limit']=fejPAdomYDEwLVpGubHyUMrFTqvJgC.LIST_LIMIT
   fejPAdomYDEwLVpGubHyUMrFTqvJgN['offset']=fejPAdomYDEwLVpGubHyUMrFTqvJQa((page_int-1)*fejPAdomYDEwLVpGubHyUMrFTqvJgC.LIST_LIMIT)
   fejPAdomYDEwLVpGubHyUMrFTqvJgN.update(fejPAdomYDEwLVpGubHyUMrFTqvJgC.GetDefaultParams(login=fejPAdomYDEwLVpGubHyUMrFTqvJQN))
   fejPAdomYDEwLVpGubHyUMrFTqvJSC=fejPAdomYDEwLVpGubHyUMrFTqvJgC.callRequestCookies('Get',fejPAdomYDEwLVpGubHyUMrFTqvJgI,payload=fejPAdomYDEwLVpGubHyUMrFTqvJQi,params=fejPAdomYDEwLVpGubHyUMrFTqvJgN,headers=fejPAdomYDEwLVpGubHyUMrFTqvJQi,cookies=fejPAdomYDEwLVpGubHyUMrFTqvJQi)
   fejPAdomYDEwLVpGubHyUMrFTqvJSh=json.loads(fejPAdomYDEwLVpGubHyUMrFTqvJSC.text)
   if not('celllist' in fejPAdomYDEwLVpGubHyUMrFTqvJSh['cell_toplist']):return[],fejPAdomYDEwLVpGubHyUMrFTqvJQN
   fejPAdomYDEwLVpGubHyUMrFTqvJSO=fejPAdomYDEwLVpGubHyUMrFTqvJSh['cell_toplist']['celllist']
   for fejPAdomYDEwLVpGubHyUMrFTqvJSt in fejPAdomYDEwLVpGubHyUMrFTqvJSO:
    fejPAdomYDEwLVpGubHyUMrFTqvJCS =fejPAdomYDEwLVpGubHyUMrFTqvJSt['event_list'][1]['url']
    fejPAdomYDEwLVpGubHyUMrFTqvJCh=urllib.parse.urlsplit(fejPAdomYDEwLVpGubHyUMrFTqvJCS).query
    fejPAdomYDEwLVpGubHyUMrFTqvJCh=fejPAdomYDEwLVpGubHyUMrFTqvJQW(urllib.parse.parse_qsl(fejPAdomYDEwLVpGubHyUMrFTqvJCh))
    fejPAdomYDEwLVpGubHyUMrFTqvJCl='contentid'
    fejPAdomYDEwLVpGubHyUMrFTqvJCQ=fejPAdomYDEwLVpGubHyUMrFTqvJCh[fejPAdomYDEwLVpGubHyUMrFTqvJCl]
    fejPAdomYDEwLVpGubHyUMrFTqvJSa={'programtitle':fejPAdomYDEwLVpGubHyUMrFTqvJSt['title_list'][0]['text'],'episodetitle':fejPAdomYDEwLVpGubHyUMrFTqvJgC.Get_ChangeText(fejPAdomYDEwLVpGubHyUMrFTqvJSt['title_list'][1]['text']),'age':fejPAdomYDEwLVpGubHyUMrFTqvJSt.get('age'),'thumbnail':fejPAdomYDEwLVpGubHyUMrFTqvJgC.HTTPTAG+fejPAdomYDEwLVpGubHyUMrFTqvJSt.get('thumbnail'),'vidtype':fejPAdomYDEwLVpGubHyUMrFTqvJCl,'videoid':fejPAdomYDEwLVpGubHyUMrFTqvJCQ}
    fejPAdomYDEwLVpGubHyUMrFTqvJCn.append(fejPAdomYDEwLVpGubHyUMrFTqvJSa)
   fejPAdomYDEwLVpGubHyUMrFTqvJSI=fejPAdomYDEwLVpGubHyUMrFTqvJQR(fejPAdomYDEwLVpGubHyUMrFTqvJSh['cell_toplist']['pagecount'])
   if fejPAdomYDEwLVpGubHyUMrFTqvJSh['cell_toplist']['count']:fejPAdomYDEwLVpGubHyUMrFTqvJCB =fejPAdomYDEwLVpGubHyUMrFTqvJQR(fejPAdomYDEwLVpGubHyUMrFTqvJSh['cell_toplist']['count'])
   else:fejPAdomYDEwLVpGubHyUMrFTqvJCB=fejPAdomYDEwLVpGubHyUMrFTqvJgC.LIST_LIMIT*page_int
   fejPAdomYDEwLVpGubHyUMrFTqvJCg=fejPAdomYDEwLVpGubHyUMrFTqvJSI>fejPAdomYDEwLVpGubHyUMrFTqvJCB
  except fejPAdomYDEwLVpGubHyUMrFTqvJQs as exception:
   fejPAdomYDEwLVpGubHyUMrFTqvJQz(exception)
   return[],fejPAdomYDEwLVpGubHyUMrFTqvJQN
  return fejPAdomYDEwLVpGubHyUMrFTqvJCn,fejPAdomYDEwLVpGubHyUMrFTqvJCg
 def Get_Program_List(fejPAdomYDEwLVpGubHyUMrFTqvJgC,fejPAdomYDEwLVpGubHyUMrFTqvJSN,page_int=1,orderby='-'):
  fejPAdomYDEwLVpGubHyUMrFTqvJCx=[]
  fejPAdomYDEwLVpGubHyUMrFTqvJSI=fejPAdomYDEwLVpGubHyUMrFTqvJCB=1
  fejPAdomYDEwLVpGubHyUMrFTqvJCg=fejPAdomYDEwLVpGubHyUMrFTqvJQN
  (fejPAdomYDEwLVpGubHyUMrFTqvJgI,fejPAdomYDEwLVpGubHyUMrFTqvJgN)=fejPAdomYDEwLVpGubHyUMrFTqvJgC.Baseapi_Parse(fejPAdomYDEwLVpGubHyUMrFTqvJSN)
  if fejPAdomYDEwLVpGubHyUMrFTqvJgI=='':return fejPAdomYDEwLVpGubHyUMrFTqvJCx,fejPAdomYDEwLVpGubHyUMrFTqvJCg
  try:
   fejPAdomYDEwLVpGubHyUMrFTqvJgN['limit'] =fejPAdomYDEwLVpGubHyUMrFTqvJgC.LIST_LIMIT
   fejPAdomYDEwLVpGubHyUMrFTqvJgN['offset']=fejPAdomYDEwLVpGubHyUMrFTqvJQa((page_int-1)*fejPAdomYDEwLVpGubHyUMrFTqvJgC.LIST_LIMIT)
   fejPAdomYDEwLVpGubHyUMrFTqvJgN['page'] =fejPAdomYDEwLVpGubHyUMrFTqvJQa(page_int)
   if fejPAdomYDEwLVpGubHyUMrFTqvJgN.get('orderby')!='' and fejPAdomYDEwLVpGubHyUMrFTqvJgN.get('orderby')!='regdatefirst' and orderby!='-':
    fejPAdomYDEwLVpGubHyUMrFTqvJgN['orderby']=orderby 
   fejPAdomYDEwLVpGubHyUMrFTqvJgN.update(fejPAdomYDEwLVpGubHyUMrFTqvJgC.GetDefaultParams(login=fejPAdomYDEwLVpGubHyUMrFTqvJQN))
   fejPAdomYDEwLVpGubHyUMrFTqvJSC=fejPAdomYDEwLVpGubHyUMrFTqvJgC.callRequestCookies('Get',fejPAdomYDEwLVpGubHyUMrFTqvJgI,payload=fejPAdomYDEwLVpGubHyUMrFTqvJQi,params=fejPAdomYDEwLVpGubHyUMrFTqvJgN,headers=fejPAdomYDEwLVpGubHyUMrFTqvJQi,cookies=fejPAdomYDEwLVpGubHyUMrFTqvJQi)
   fejPAdomYDEwLVpGubHyUMrFTqvJSh=json.loads(fejPAdomYDEwLVpGubHyUMrFTqvJSC.text)
   if fejPAdomYDEwLVpGubHyUMrFTqvJSh.get('cell_toplist')not in[{},fejPAdomYDEwLVpGubHyUMrFTqvJQi,'']:
    fejPAdomYDEwLVpGubHyUMrFTqvJSO=fejPAdomYDEwLVpGubHyUMrFTqvJSh['cell_toplist']['celllist']
   elif fejPAdomYDEwLVpGubHyUMrFTqvJSh.get('band')not in[{},fejPAdomYDEwLVpGubHyUMrFTqvJQi,'']:
    fejPAdomYDEwLVpGubHyUMrFTqvJSO=fejPAdomYDEwLVpGubHyUMrFTqvJSh['band']['celllist']
   else:
    return fejPAdomYDEwLVpGubHyUMrFTqvJCx,fejPAdomYDEwLVpGubHyUMrFTqvJCg
   for fejPAdomYDEwLVpGubHyUMrFTqvJSt in fejPAdomYDEwLVpGubHyUMrFTqvJSO:
    for fejPAdomYDEwLVpGubHyUMrFTqvJCX in fejPAdomYDEwLVpGubHyUMrFTqvJSt['event_list']:
     if fejPAdomYDEwLVpGubHyUMrFTqvJCX.get('type')=='on-navigation':
      fejPAdomYDEwLVpGubHyUMrFTqvJCS =fejPAdomYDEwLVpGubHyUMrFTqvJCX['url']
    fejPAdomYDEwLVpGubHyUMrFTqvJCh=urllib.parse.urlsplit(fejPAdomYDEwLVpGubHyUMrFTqvJCS).query
    fejPAdomYDEwLVpGubHyUMrFTqvJCl=fejPAdomYDEwLVpGubHyUMrFTqvJCh[0:fejPAdomYDEwLVpGubHyUMrFTqvJCh.find('=')]
    fejPAdomYDEwLVpGubHyUMrFTqvJCi=fejPAdomYDEwLVpGubHyUMrFTqvJQW(urllib.parse.parse_qsl(fejPAdomYDEwLVpGubHyUMrFTqvJCh))
    fejPAdomYDEwLVpGubHyUMrFTqvJCQ=fejPAdomYDEwLVpGubHyUMrFTqvJCi.get(fejPAdomYDEwLVpGubHyUMrFTqvJCl)
    fejPAdomYDEwLVpGubHyUMrFTqvJSa={'title':fejPAdomYDEwLVpGubHyUMrFTqvJSt.get('alt')or fejPAdomYDEwLVpGubHyUMrFTqvJSt.get('title_list')[0].get('text'),'age':fejPAdomYDEwLVpGubHyUMrFTqvJSt.get('age'),'thumbnail':fejPAdomYDEwLVpGubHyUMrFTqvJSt.get('thumbnail'),'videoid':fejPAdomYDEwLVpGubHyUMrFTqvJCQ,'vidtype':fejPAdomYDEwLVpGubHyUMrFTqvJCl,}
    if not fejPAdomYDEwLVpGubHyUMrFTqvJSa.get('thumbnail').startswith('http'):
     fejPAdomYDEwLVpGubHyUMrFTqvJSa['thumbnail']='https://%s'%fejPAdomYDEwLVpGubHyUMrFTqvJSa['thumbnail']
    fejPAdomYDEwLVpGubHyUMrFTqvJCx.append(fejPAdomYDEwLVpGubHyUMrFTqvJSa)
   if fejPAdomYDEwLVpGubHyUMrFTqvJSh.get('cell_toplist')not in[{},fejPAdomYDEwLVpGubHyUMrFTqvJQi,'']:
    fejPAdomYDEwLVpGubHyUMrFTqvJSI=fejPAdomYDEwLVpGubHyUMrFTqvJQR(fejPAdomYDEwLVpGubHyUMrFTqvJSh['cell_toplist']['pagecount'])
    if fejPAdomYDEwLVpGubHyUMrFTqvJSh['cell_toplist']['count']:fejPAdomYDEwLVpGubHyUMrFTqvJCB =fejPAdomYDEwLVpGubHyUMrFTqvJQR(fejPAdomYDEwLVpGubHyUMrFTqvJSh['cell_toplist']['count'])
    else:fejPAdomYDEwLVpGubHyUMrFTqvJCB=fejPAdomYDEwLVpGubHyUMrFTqvJgC.LIST_LIMIT*page_int
    fejPAdomYDEwLVpGubHyUMrFTqvJCg=fejPAdomYDEwLVpGubHyUMrFTqvJSI>fejPAdomYDEwLVpGubHyUMrFTqvJCB
  except fejPAdomYDEwLVpGubHyUMrFTqvJQs as exception:
   fejPAdomYDEwLVpGubHyUMrFTqvJQz(exception)
   return[],fejPAdomYDEwLVpGubHyUMrFTqvJQN
  return fejPAdomYDEwLVpGubHyUMrFTqvJCx,fejPAdomYDEwLVpGubHyUMrFTqvJCg
 def Get_Movie_List(fejPAdomYDEwLVpGubHyUMrFTqvJgC,fejPAdomYDEwLVpGubHyUMrFTqvJSN,page_int=1,orderby='-'):
  fejPAdomYDEwLVpGubHyUMrFTqvJCN=[]
  fejPAdomYDEwLVpGubHyUMrFTqvJSI=fejPAdomYDEwLVpGubHyUMrFTqvJCB=1
  fejPAdomYDEwLVpGubHyUMrFTqvJCg=fejPAdomYDEwLVpGubHyUMrFTqvJQN
  (fejPAdomYDEwLVpGubHyUMrFTqvJgI,fejPAdomYDEwLVpGubHyUMrFTqvJgN)=fejPAdomYDEwLVpGubHyUMrFTqvJgC.Baseapi_Parse(fejPAdomYDEwLVpGubHyUMrFTqvJSN)
  if fejPAdomYDEwLVpGubHyUMrFTqvJgI=='':return fejPAdomYDEwLVpGubHyUMrFTqvJCN,fejPAdomYDEwLVpGubHyUMrFTqvJCg
  try:
   fejPAdomYDEwLVpGubHyUMrFTqvJgN['limit']=fejPAdomYDEwLVpGubHyUMrFTqvJgC.MV_LIMIT
   fejPAdomYDEwLVpGubHyUMrFTqvJgN['offset']=fejPAdomYDEwLVpGubHyUMrFTqvJQa((page_int-1)*fejPAdomYDEwLVpGubHyUMrFTqvJgC.MV_LIMIT)
   if fejPAdomYDEwLVpGubHyUMrFTqvJgN.get('orderby')!='' and fejPAdomYDEwLVpGubHyUMrFTqvJgN.get('orderby')!='regdatefirst' and orderby!='-':
    fejPAdomYDEwLVpGubHyUMrFTqvJgN['orderby']=orderby 
   fejPAdomYDEwLVpGubHyUMrFTqvJgN.update(fejPAdomYDEwLVpGubHyUMrFTqvJgC.GetDefaultParams(login=fejPAdomYDEwLVpGubHyUMrFTqvJQN))
   fejPAdomYDEwLVpGubHyUMrFTqvJSC=fejPAdomYDEwLVpGubHyUMrFTqvJgC.callRequestCookies('Get',fejPAdomYDEwLVpGubHyUMrFTqvJgI,payload=fejPAdomYDEwLVpGubHyUMrFTqvJQi,params=fejPAdomYDEwLVpGubHyUMrFTqvJgN,headers=fejPAdomYDEwLVpGubHyUMrFTqvJQi,cookies=fejPAdomYDEwLVpGubHyUMrFTqvJQi)
   fejPAdomYDEwLVpGubHyUMrFTqvJSh=json.loads(fejPAdomYDEwLVpGubHyUMrFTqvJSC.text)
   if fejPAdomYDEwLVpGubHyUMrFTqvJSh.get('cell_toplist')not in[{},fejPAdomYDEwLVpGubHyUMrFTqvJQi,'']:
    fejPAdomYDEwLVpGubHyUMrFTqvJSO=fejPAdomYDEwLVpGubHyUMrFTqvJSh['cell_toplist']['celllist']
   elif fejPAdomYDEwLVpGubHyUMrFTqvJSh.get('band')not in[{},fejPAdomYDEwLVpGubHyUMrFTqvJQi,'']:
    fejPAdomYDEwLVpGubHyUMrFTqvJSO=fejPAdomYDEwLVpGubHyUMrFTqvJSh['band']['celllist']
   else:
    return fejPAdomYDEwLVpGubHyUMrFTqvJCN,fejPAdomYDEwLVpGubHyUMrFTqvJCg
   for fejPAdomYDEwLVpGubHyUMrFTqvJSt in fejPAdomYDEwLVpGubHyUMrFTqvJSO:
    fejPAdomYDEwLVpGubHyUMrFTqvJCS =fejPAdomYDEwLVpGubHyUMrFTqvJSt['event_list'][1]['url']
    fejPAdomYDEwLVpGubHyUMrFTqvJCh=urllib.parse.urlsplit(fejPAdomYDEwLVpGubHyUMrFTqvJCS).query
    fejPAdomYDEwLVpGubHyUMrFTqvJCl=fejPAdomYDEwLVpGubHyUMrFTqvJCh[0:fejPAdomYDEwLVpGubHyUMrFTqvJCh.find('=')]
    fejPAdomYDEwLVpGubHyUMrFTqvJCi=fejPAdomYDEwLVpGubHyUMrFTqvJQW(urllib.parse.parse_qsl(fejPAdomYDEwLVpGubHyUMrFTqvJCh))
    fejPAdomYDEwLVpGubHyUMrFTqvJCQ=fejPAdomYDEwLVpGubHyUMrFTqvJCi.get(fejPAdomYDEwLVpGubHyUMrFTqvJCl)
    fejPAdomYDEwLVpGubHyUMrFTqvJSa={'title':fejPAdomYDEwLVpGubHyUMrFTqvJSt.get('alt')or fejPAdomYDEwLVpGubHyUMrFTqvJSt.get('title_list')[0].get('text'),'age':fejPAdomYDEwLVpGubHyUMrFTqvJSt.get('age'),'thumbnail':fejPAdomYDEwLVpGubHyUMrFTqvJSt.get('thumbnail'),'videoid':fejPAdomYDEwLVpGubHyUMrFTqvJCQ,'vidtype':fejPAdomYDEwLVpGubHyUMrFTqvJCl,}
    if not fejPAdomYDEwLVpGubHyUMrFTqvJSa.get('thumbnail').startswith('http'):
     fejPAdomYDEwLVpGubHyUMrFTqvJSa['thumbnail']='https://%s'%fejPAdomYDEwLVpGubHyUMrFTqvJSa['thumbnail']
    fejPAdomYDEwLVpGubHyUMrFTqvJCN.append(fejPAdomYDEwLVpGubHyUMrFTqvJSa)
   if fejPAdomYDEwLVpGubHyUMrFTqvJSh.get('cell_toplist')not in[{},fejPAdomYDEwLVpGubHyUMrFTqvJQi,'']:
    fejPAdomYDEwLVpGubHyUMrFTqvJSI=fejPAdomYDEwLVpGubHyUMrFTqvJQR(fejPAdomYDEwLVpGubHyUMrFTqvJSh['cell_toplist']['pagecount'])
    if fejPAdomYDEwLVpGubHyUMrFTqvJSh['cell_toplist']['count']:fejPAdomYDEwLVpGubHyUMrFTqvJCB =fejPAdomYDEwLVpGubHyUMrFTqvJQR(fejPAdomYDEwLVpGubHyUMrFTqvJSh['cell_toplist']['count'])
    else:fejPAdomYDEwLVpGubHyUMrFTqvJCB=fejPAdomYDEwLVpGubHyUMrFTqvJgC.MV_LIMIT*page_int
    fejPAdomYDEwLVpGubHyUMrFTqvJCg=fejPAdomYDEwLVpGubHyUMrFTqvJSI>fejPAdomYDEwLVpGubHyUMrFTqvJCB
  except fejPAdomYDEwLVpGubHyUMrFTqvJQs as exception:
   fejPAdomYDEwLVpGubHyUMrFTqvJQz(exception)
   return[],fejPAdomYDEwLVpGubHyUMrFTqvJQN
  return fejPAdomYDEwLVpGubHyUMrFTqvJCN,fejPAdomYDEwLVpGubHyUMrFTqvJCg
 def ProgramidToContentid(fejPAdomYDEwLVpGubHyUMrFTqvJgC,fejPAdomYDEwLVpGubHyUMrFTqvJCt):
  fejPAdomYDEwLVpGubHyUMrFTqvJCk=''
  try:
   fejPAdomYDEwLVpGubHyUMrFTqvJgI =fejPAdomYDEwLVpGubHyUMrFTqvJgC.API_DOMAIN+'/vod/programs-contentid/'+fejPAdomYDEwLVpGubHyUMrFTqvJCt
   fejPAdomYDEwLVpGubHyUMrFTqvJgN=fejPAdomYDEwLVpGubHyUMrFTqvJgC.GetDefaultParams(login=fejPAdomYDEwLVpGubHyUMrFTqvJQN)
   fejPAdomYDEwLVpGubHyUMrFTqvJSC=fejPAdomYDEwLVpGubHyUMrFTqvJgC.callRequestCookies('Get',fejPAdomYDEwLVpGubHyUMrFTqvJgI,payload=fejPAdomYDEwLVpGubHyUMrFTqvJQi,params=fejPAdomYDEwLVpGubHyUMrFTqvJgN,headers=fejPAdomYDEwLVpGubHyUMrFTqvJQi,cookies=fejPAdomYDEwLVpGubHyUMrFTqvJQi)
   fejPAdomYDEwLVpGubHyUMrFTqvJCO=json.loads(fejPAdomYDEwLVpGubHyUMrFTqvJSC.text)
   if not('contentid' in fejPAdomYDEwLVpGubHyUMrFTqvJCO):return fejPAdomYDEwLVpGubHyUMrFTqvJCk 
   fejPAdomYDEwLVpGubHyUMrFTqvJCk=fejPAdomYDEwLVpGubHyUMrFTqvJCO['contentid']
  except fejPAdomYDEwLVpGubHyUMrFTqvJQs as exception:
   fejPAdomYDEwLVpGubHyUMrFTqvJQz(exception)
  return fejPAdomYDEwLVpGubHyUMrFTqvJCk
 def ContentidToSeasonid(fejPAdomYDEwLVpGubHyUMrFTqvJgC,fejPAdomYDEwLVpGubHyUMrFTqvJCk):
  fejPAdomYDEwLVpGubHyUMrFTqvJCt=''
  try:
   fejPAdomYDEwLVpGubHyUMrFTqvJgI =fejPAdomYDEwLVpGubHyUMrFTqvJgC.API_DOMAIN+'/fz/vod/contents/'+fejPAdomYDEwLVpGubHyUMrFTqvJCk
   fejPAdomYDEwLVpGubHyUMrFTqvJgN=fejPAdomYDEwLVpGubHyUMrFTqvJgC.GetDefaultParams(login=fejPAdomYDEwLVpGubHyUMrFTqvJQN)
   fejPAdomYDEwLVpGubHyUMrFTqvJSC=fejPAdomYDEwLVpGubHyUMrFTqvJgC.callRequestCookies('Get',fejPAdomYDEwLVpGubHyUMrFTqvJgI,payload=fejPAdomYDEwLVpGubHyUMrFTqvJQi,params=fejPAdomYDEwLVpGubHyUMrFTqvJgN,headers=fejPAdomYDEwLVpGubHyUMrFTqvJQi,cookies=fejPAdomYDEwLVpGubHyUMrFTqvJQi)
   fejPAdomYDEwLVpGubHyUMrFTqvJCO=json.loads(fejPAdomYDEwLVpGubHyUMrFTqvJSC.text)
   if not('programid' in fejPAdomYDEwLVpGubHyUMrFTqvJCO):return fejPAdomYDEwLVpGubHyUMrFTqvJCt 
   fejPAdomYDEwLVpGubHyUMrFTqvJCt=fejPAdomYDEwLVpGubHyUMrFTqvJCO['programid']
  except fejPAdomYDEwLVpGubHyUMrFTqvJQs as exception:
   fejPAdomYDEwLVpGubHyUMrFTqvJQz(exception)
  return fejPAdomYDEwLVpGubHyUMrFTqvJCt
 def GetProgramInfo(fejPAdomYDEwLVpGubHyUMrFTqvJgC,fejPAdomYDEwLVpGubHyUMrFTqvJCk):
  fejPAdomYDEwLVpGubHyUMrFTqvJCa={}
  try:
   fejPAdomYDEwLVpGubHyUMrFTqvJgI=fejPAdomYDEwLVpGubHyUMrFTqvJgC.API_DOMAIN+'/fz/vod/contents/'+fejPAdomYDEwLVpGubHyUMrFTqvJCk
   fejPAdomYDEwLVpGubHyUMrFTqvJgN=fejPAdomYDEwLVpGubHyUMrFTqvJgC.GetDefaultParams(login=fejPAdomYDEwLVpGubHyUMrFTqvJQN)
   fejPAdomYDEwLVpGubHyUMrFTqvJSC=fejPAdomYDEwLVpGubHyUMrFTqvJgC.callRequestCookies('Get',fejPAdomYDEwLVpGubHyUMrFTqvJgI,payload=fejPAdomYDEwLVpGubHyUMrFTqvJQi,params=fejPAdomYDEwLVpGubHyUMrFTqvJgN,headers=fejPAdomYDEwLVpGubHyUMrFTqvJQi,cookies=fejPAdomYDEwLVpGubHyUMrFTqvJQi)
   fejPAdomYDEwLVpGubHyUMrFTqvJCO=json.loads(fejPAdomYDEwLVpGubHyUMrFTqvJSC.text)
   fejPAdomYDEwLVpGubHyUMrFTqvJCs=img_fanart=fejPAdomYDEwLVpGubHyUMrFTqvJCz=''
   if fejPAdomYDEwLVpGubHyUMrFTqvJCO.get('programposterimage')!='':fejPAdomYDEwLVpGubHyUMrFTqvJCs =fejPAdomYDEwLVpGubHyUMrFTqvJgC.HTTPTAG+fejPAdomYDEwLVpGubHyUMrFTqvJCO.get('programposterimage')
   if fejPAdomYDEwLVpGubHyUMrFTqvJCO.get('programimage') !='':img_fanart =fejPAdomYDEwLVpGubHyUMrFTqvJgC.HTTPTAG+fejPAdomYDEwLVpGubHyUMrFTqvJCO.get('programimage')
   if fejPAdomYDEwLVpGubHyUMrFTqvJCO.get('programcircleimage')!='':fejPAdomYDEwLVpGubHyUMrFTqvJCz=fejPAdomYDEwLVpGubHyUMrFTqvJgC.HTTPTAG+fejPAdomYDEwLVpGubHyUMrFTqvJCO.get('programcircleimage')
   if 'poster_default' in fejPAdomYDEwLVpGubHyUMrFTqvJCs:
    fejPAdomYDEwLVpGubHyUMrFTqvJCs =img_fanart
    fejPAdomYDEwLVpGubHyUMrFTqvJCz=''
   fejPAdomYDEwLVpGubHyUMrFTqvJCa={'imgPoster':fejPAdomYDEwLVpGubHyUMrFTqvJCs,'imgFanart':img_fanart,'imgClearlogo':fejPAdomYDEwLVpGubHyUMrFTqvJCz,'programtitle':fejPAdomYDEwLVpGubHyUMrFTqvJCO.get('programtitle'),'programid':fejPAdomYDEwLVpGubHyUMrFTqvJCO.get('programid'),'synopsis':fejPAdomYDEwLVpGubHyUMrFTqvJCO.get('programsynopsis').replace('<br>','\n'),}
  except fejPAdomYDEwLVpGubHyUMrFTqvJQs as exception:
   fejPAdomYDEwLVpGubHyUMrFTqvJQz(exception)
  return fejPAdomYDEwLVpGubHyUMrFTqvJCa
 def Get_Season_List(fejPAdomYDEwLVpGubHyUMrFTqvJgC,seasonid):
  fejPAdomYDEwLVpGubHyUMrFTqvJCW=[]
  fejPAdomYDEwLVpGubHyUMrFTqvJCk=fejPAdomYDEwLVpGubHyUMrFTqvJgC.ProgramidToContentid(seasonid)
  fejPAdomYDEwLVpGubHyUMrFTqvJCR=fejPAdomYDEwLVpGubHyUMrFTqvJgC.GetProgramInfo(fejPAdomYDEwLVpGubHyUMrFTqvJCk)
  fejPAdomYDEwLVpGubHyUMrFTqvJCc={'poster':fejPAdomYDEwLVpGubHyUMrFTqvJCR.get('imgPoster'),'fanart':fejPAdomYDEwLVpGubHyUMrFTqvJCR.get('imgFanart'),'clearlogo':fejPAdomYDEwLVpGubHyUMrFTqvJCR.get('imgClearlogo'),}
  try:
   fejPAdomYDEwLVpGubHyUMrFTqvJgI=fejPAdomYDEwLVpGubHyUMrFTqvJgC.API_DOMAIN+'/fz/vod/programs-contents/'+seasonid
   fejPAdomYDEwLVpGubHyUMrFTqvJgN={'limit':'10','offset':'0','orderby':'new',}
   fejPAdomYDEwLVpGubHyUMrFTqvJgN.update(fejPAdomYDEwLVpGubHyUMrFTqvJgC.GetDefaultParams(login=fejPAdomYDEwLVpGubHyUMrFTqvJQN))
   fejPAdomYDEwLVpGubHyUMrFTqvJSC=fejPAdomYDEwLVpGubHyUMrFTqvJgC.callRequestCookies('Get',fejPAdomYDEwLVpGubHyUMrFTqvJgI,payload=fejPAdomYDEwLVpGubHyUMrFTqvJQi,params=fejPAdomYDEwLVpGubHyUMrFTqvJgN,headers=fejPAdomYDEwLVpGubHyUMrFTqvJQi,cookies=fejPAdomYDEwLVpGubHyUMrFTqvJQi)
   fejPAdomYDEwLVpGubHyUMrFTqvJSh=json.loads(fejPAdomYDEwLVpGubHyUMrFTqvJSC.text)
   for fejPAdomYDEwLVpGubHyUMrFTqvJCK in fejPAdomYDEwLVpGubHyUMrFTqvJSh['filter']['filterlist'][0]['filter_item_list']:
    fejPAdomYDEwLVpGubHyUMrFTqvJSa={'season_Nm':fejPAdomYDEwLVpGubHyUMrFTqvJCK.get('title'),'season_Id':fejPAdomYDEwLVpGubHyUMrFTqvJCK.get('api_path'),'thumbnail':fejPAdomYDEwLVpGubHyUMrFTqvJCc,'programNm':fejPAdomYDEwLVpGubHyUMrFTqvJCR.get('programtitle'),'synopsis':fejPAdomYDEwLVpGubHyUMrFTqvJCR.get('synopsis'),}
    fejPAdomYDEwLVpGubHyUMrFTqvJCW.append(fejPAdomYDEwLVpGubHyUMrFTqvJSa)
  except fejPAdomYDEwLVpGubHyUMrFTqvJQs as exception:
   fejPAdomYDEwLVpGubHyUMrFTqvJQz(exception)
   return[]
  return fejPAdomYDEwLVpGubHyUMrFTqvJCW
 def Get_Episode_List(fejPAdomYDEwLVpGubHyUMrFTqvJgC,seasionid,page_int=1,orderby='desc'):
  fejPAdomYDEwLVpGubHyUMrFTqvJCI=[]
  fejPAdomYDEwLVpGubHyUMrFTqvJSI=fejPAdomYDEwLVpGubHyUMrFTqvJCB=1
  fejPAdomYDEwLVpGubHyUMrFTqvJCg=fejPAdomYDEwLVpGubHyUMrFTqvJQN
  fejPAdomYDEwLVpGubHyUMrFTqvJCR={}
  fejPAdomYDEwLVpGubHyUMrFTqvJCk=fejPAdomYDEwLVpGubHyUMrFTqvJgC.ProgramidToContentid(seasionid)
  fejPAdomYDEwLVpGubHyUMrFTqvJCR=fejPAdomYDEwLVpGubHyUMrFTqvJgC.GetProgramInfo(fejPAdomYDEwLVpGubHyUMrFTqvJCk)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   fejPAdomYDEwLVpGubHyUMrFTqvJgI=fejPAdomYDEwLVpGubHyUMrFTqvJgC.API_DOMAIN+'/fz/vod/programs-contents/'+seasionid
   fejPAdomYDEwLVpGubHyUMrFTqvJgN={'limit':fejPAdomYDEwLVpGubHyUMrFTqvJgC.EP_LIMIT,'offset':fejPAdomYDEwLVpGubHyUMrFTqvJQa((page_int-1)*fejPAdomYDEwLVpGubHyUMrFTqvJgC.EP_LIMIT),'orderby':orderby,}
   fejPAdomYDEwLVpGubHyUMrFTqvJgN.update(fejPAdomYDEwLVpGubHyUMrFTqvJgC.GetDefaultParams(login=fejPAdomYDEwLVpGubHyUMrFTqvJQN))
   fejPAdomYDEwLVpGubHyUMrFTqvJSC=fejPAdomYDEwLVpGubHyUMrFTqvJgC.callRequestCookies('Get',fejPAdomYDEwLVpGubHyUMrFTqvJgI,payload=fejPAdomYDEwLVpGubHyUMrFTqvJQi,params=fejPAdomYDEwLVpGubHyUMrFTqvJgN,headers=fejPAdomYDEwLVpGubHyUMrFTqvJQi,cookies=fejPAdomYDEwLVpGubHyUMrFTqvJQi)
   fejPAdomYDEwLVpGubHyUMrFTqvJSh=json.loads(fejPAdomYDEwLVpGubHyUMrFTqvJSC.text)
   fejPAdomYDEwLVpGubHyUMrFTqvJSO=fejPAdomYDEwLVpGubHyUMrFTqvJSh['cell_toplist']['celllist']
   for fejPAdomYDEwLVpGubHyUMrFTqvJSt in fejPAdomYDEwLVpGubHyUMrFTqvJSO:
    fejPAdomYDEwLVpGubHyUMrFTqvJhS=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',fejPAdomYDEwLVpGubHyUMrFTqvJSt.get('synopsis'))
    fejPAdomYDEwLVpGubHyUMrFTqvJhC=fejPAdomYDEwLVpGubHyUMrFTqvJgC.HTTPTAG+fejPAdomYDEwLVpGubHyUMrFTqvJSt.get('thumbnail')
    fejPAdomYDEwLVpGubHyUMrFTqvJhl=fejPAdomYDEwLVpGubHyUMrFTqvJhQ=fejPAdomYDEwLVpGubHyUMrFTqvJhB=''
    fejPAdomYDEwLVpGubHyUMrFTqvJhl =fejPAdomYDEwLVpGubHyUMrFTqvJCR.get('imgPoster')
    fejPAdomYDEwLVpGubHyUMrFTqvJhQ =fejPAdomYDEwLVpGubHyUMrFTqvJCR.get('imgFanart')
    fejPAdomYDEwLVpGubHyUMrFTqvJhB =fejPAdomYDEwLVpGubHyUMrFTqvJCR.get('imgClearlogo')
    fejPAdomYDEwLVpGubHyUMrFTqvJhn=fejPAdomYDEwLVpGubHyUMrFTqvJCR.get('programtitle')
    fejPAdomYDEwLVpGubHyUMrFTqvJCc={'thumb':fejPAdomYDEwLVpGubHyUMrFTqvJhC,'poster':fejPAdomYDEwLVpGubHyUMrFTqvJhl,'fanart':fejPAdomYDEwLVpGubHyUMrFTqvJhQ,'clearlogo':fejPAdomYDEwLVpGubHyUMrFTqvJhB}
    fejPAdomYDEwLVpGubHyUMrFTqvJSa={'programtitle':fejPAdomYDEwLVpGubHyUMrFTqvJhn,'episodetitle':fejPAdomYDEwLVpGubHyUMrFTqvJSt['title_list'][0]['text'],'episodenumber':fejPAdomYDEwLVpGubHyUMrFTqvJSt['title_list'][1]['text'].replace('$O$',''),'contentid':fejPAdomYDEwLVpGubHyUMrFTqvJSt['contentid'],'synopsis':fejPAdomYDEwLVpGubHyUMrFTqvJhS,'episodeactors':fejPAdomYDEwLVpGubHyUMrFTqvJSt.get('actors').split(',')if fejPAdomYDEwLVpGubHyUMrFTqvJSt.get('actors')!='' else[],'thumbnail':fejPAdomYDEwLVpGubHyUMrFTqvJCc,}
    fejPAdomYDEwLVpGubHyUMrFTqvJCI.append(fejPAdomYDEwLVpGubHyUMrFTqvJSa)
   fejPAdomYDEwLVpGubHyUMrFTqvJSI=fejPAdomYDEwLVpGubHyUMrFTqvJQR(fejPAdomYDEwLVpGubHyUMrFTqvJSh['cell_toplist']['pagecount'])
   if fejPAdomYDEwLVpGubHyUMrFTqvJSh['cell_toplist']['count']:fejPAdomYDEwLVpGubHyUMrFTqvJCB =fejPAdomYDEwLVpGubHyUMrFTqvJQR(fejPAdomYDEwLVpGubHyUMrFTqvJSh['cell_toplist']['count'])
   else:fejPAdomYDEwLVpGubHyUMrFTqvJCB=fejPAdomYDEwLVpGubHyUMrFTqvJgC.EP_LIMIT*page_int
   fejPAdomYDEwLVpGubHyUMrFTqvJCg=fejPAdomYDEwLVpGubHyUMrFTqvJSI>fejPAdomYDEwLVpGubHyUMrFTqvJCB
  except fejPAdomYDEwLVpGubHyUMrFTqvJQs as exception:
   fejPAdomYDEwLVpGubHyUMrFTqvJQz(exception)
   return[],fejPAdomYDEwLVpGubHyUMrFTqvJQN
  return fejPAdomYDEwLVpGubHyUMrFTqvJCI,fejPAdomYDEwLVpGubHyUMrFTqvJCg
 def GetEPGList(fejPAdomYDEwLVpGubHyUMrFTqvJgC,genre):
  fejPAdomYDEwLVpGubHyUMrFTqvJhx={}
  try:
   fejPAdomYDEwLVpGubHyUMrFTqvJhX=fejPAdomYDEwLVpGubHyUMrFTqvJgC.Get_Now_Datetime()
   if genre=='all':
    fejPAdomYDEwLVpGubHyUMrFTqvJhi =fejPAdomYDEwLVpGubHyUMrFTqvJhX+datetime.timedelta(hours=3)
   else:
    fejPAdomYDEwLVpGubHyUMrFTqvJhi =fejPAdomYDEwLVpGubHyUMrFTqvJhX+datetime.timedelta(hours=3)
   fejPAdomYDEwLVpGubHyUMrFTqvJgI=fejPAdomYDEwLVpGubHyUMrFTqvJgC.API_DOMAIN+'/live/epgs'
   fejPAdomYDEwLVpGubHyUMrFTqvJgN={'limit':'100','offset':'0','genre':genre,'startdatetime':fejPAdomYDEwLVpGubHyUMrFTqvJhX.strftime('%Y-%m-%d %H:00'),'enddatetime':fejPAdomYDEwLVpGubHyUMrFTqvJhi.strftime('%Y-%m-%d %H:00')}
   fejPAdomYDEwLVpGubHyUMrFTqvJgN.update(fejPAdomYDEwLVpGubHyUMrFTqvJgC.GetDefaultParams(login=fejPAdomYDEwLVpGubHyUMrFTqvJQN))
   fejPAdomYDEwLVpGubHyUMrFTqvJSC=fejPAdomYDEwLVpGubHyUMrFTqvJgC.callRequestCookies('Get',fejPAdomYDEwLVpGubHyUMrFTqvJgI,payload=fejPAdomYDEwLVpGubHyUMrFTqvJQi,params=fejPAdomYDEwLVpGubHyUMrFTqvJgN,headers=fejPAdomYDEwLVpGubHyUMrFTqvJQi,cookies=fejPAdomYDEwLVpGubHyUMrFTqvJQi)
   fejPAdomYDEwLVpGubHyUMrFTqvJSh=json.loads(fejPAdomYDEwLVpGubHyUMrFTqvJSC.text)
   fejPAdomYDEwLVpGubHyUMrFTqvJhN=fejPAdomYDEwLVpGubHyUMrFTqvJSh['list']
   for fejPAdomYDEwLVpGubHyUMrFTqvJSt in fejPAdomYDEwLVpGubHyUMrFTqvJhN:
    fejPAdomYDEwLVpGubHyUMrFTqvJhk=''
    for fejPAdomYDEwLVpGubHyUMrFTqvJhO in fejPAdomYDEwLVpGubHyUMrFTqvJSt['list']:
     if fejPAdomYDEwLVpGubHyUMrFTqvJhk:fejPAdomYDEwLVpGubHyUMrFTqvJhk+='\n'
     fejPAdomYDEwLVpGubHyUMrFTqvJhk+=fejPAdomYDEwLVpGubHyUMrFTqvJgC.Get_ChangeText(fejPAdomYDEwLVpGubHyUMrFTqvJhO['title'])+'\n'
     fejPAdomYDEwLVpGubHyUMrFTqvJhk+=' [%s ~ %s]'%(fejPAdomYDEwLVpGubHyUMrFTqvJhO['starttime'][-5:],fejPAdomYDEwLVpGubHyUMrFTqvJhO['endtime'][-5:])+'\n'
    fejPAdomYDEwLVpGubHyUMrFTqvJhx[fejPAdomYDEwLVpGubHyUMrFTqvJSt['channelid']]=fejPAdomYDEwLVpGubHyUMrFTqvJhk
  except fejPAdomYDEwLVpGubHyUMrFTqvJQs as exception:
   fejPAdomYDEwLVpGubHyUMrFTqvJQz(exception)
  return fejPAdomYDEwLVpGubHyUMrFTqvJhx
 def Get_LiveChannel_List(fejPAdomYDEwLVpGubHyUMrFTqvJgC,genre,fejPAdomYDEwLVpGubHyUMrFTqvJSN):
  fejPAdomYDEwLVpGubHyUMrFTqvJSK=[]
  (fejPAdomYDEwLVpGubHyUMrFTqvJgI,fejPAdomYDEwLVpGubHyUMrFTqvJgN)=fejPAdomYDEwLVpGubHyUMrFTqvJgC.Baseapi_Parse(fejPAdomYDEwLVpGubHyUMrFTqvJSN)
  if fejPAdomYDEwLVpGubHyUMrFTqvJgI=='':return fejPAdomYDEwLVpGubHyUMrFTqvJSK
  fejPAdomYDEwLVpGubHyUMrFTqvJht=fejPAdomYDEwLVpGubHyUMrFTqvJgC.GetEPGList(genre)
  try:
   fejPAdomYDEwLVpGubHyUMrFTqvJgN.update(fejPAdomYDEwLVpGubHyUMrFTqvJgC.GetDefaultParams(login=fejPAdomYDEwLVpGubHyUMrFTqvJQN))
   fejPAdomYDEwLVpGubHyUMrFTqvJgN['genre']=genre
   fejPAdomYDEwLVpGubHyUMrFTqvJSC=fejPAdomYDEwLVpGubHyUMrFTqvJgC.callRequestCookies('Get',fejPAdomYDEwLVpGubHyUMrFTqvJgI,payload=fejPAdomYDEwLVpGubHyUMrFTqvJQi,params=fejPAdomYDEwLVpGubHyUMrFTqvJgN,headers=fejPAdomYDEwLVpGubHyUMrFTqvJQi,cookies=fejPAdomYDEwLVpGubHyUMrFTqvJQi)
   fejPAdomYDEwLVpGubHyUMrFTqvJSh=json.loads(fejPAdomYDEwLVpGubHyUMrFTqvJSC.text)
   if not('celllist' in fejPAdomYDEwLVpGubHyUMrFTqvJSh['cell_toplist']):return[]
   fejPAdomYDEwLVpGubHyUMrFTqvJSO=fejPAdomYDEwLVpGubHyUMrFTqvJSh['cell_toplist']['celllist']
   for fejPAdomYDEwLVpGubHyUMrFTqvJSt in fejPAdomYDEwLVpGubHyUMrFTqvJSO:
    fejPAdomYDEwLVpGubHyUMrFTqvJCk=fejPAdomYDEwLVpGubHyUMrFTqvJSt['contentid']
    if fejPAdomYDEwLVpGubHyUMrFTqvJCk in fejPAdomYDEwLVpGubHyUMrFTqvJht:
     fejPAdomYDEwLVpGubHyUMrFTqvJha=fejPAdomYDEwLVpGubHyUMrFTqvJht[fejPAdomYDEwLVpGubHyUMrFTqvJCk]
    else:
     fejPAdomYDEwLVpGubHyUMrFTqvJha=''
    fejPAdomYDEwLVpGubHyUMrFTqvJSa={'studio':fejPAdomYDEwLVpGubHyUMrFTqvJSt['title_list'][0]['text'],'tvshowtitle':fejPAdomYDEwLVpGubHyUMrFTqvJgC.Get_ChangeText(fejPAdomYDEwLVpGubHyUMrFTqvJSt['title_list'][1]['text']),'channelid':fejPAdomYDEwLVpGubHyUMrFTqvJCk,'age':fejPAdomYDEwLVpGubHyUMrFTqvJSt['age'],'thumbnail':'https://%s'%fejPAdomYDEwLVpGubHyUMrFTqvJSt.get('thumbnail'),'epg':fejPAdomYDEwLVpGubHyUMrFTqvJha}
    fejPAdomYDEwLVpGubHyUMrFTqvJSK.append(fejPAdomYDEwLVpGubHyUMrFTqvJSa)
  except fejPAdomYDEwLVpGubHyUMrFTqvJQs as exception:
   fejPAdomYDEwLVpGubHyUMrFTqvJQz(exception)
   return[]
  return fejPAdomYDEwLVpGubHyUMrFTqvJSK
 def Get_Search_List(fejPAdomYDEwLVpGubHyUMrFTqvJgC,search_key,sType,page_int,exclusion21=fejPAdomYDEwLVpGubHyUMrFTqvJQN):
  fejPAdomYDEwLVpGubHyUMrFTqvJhs=[]
  fejPAdomYDEwLVpGubHyUMrFTqvJSI=fejPAdomYDEwLVpGubHyUMrFTqvJCB=1
  fejPAdomYDEwLVpGubHyUMrFTqvJCg=fejPAdomYDEwLVpGubHyUMrFTqvJQN
  try:
   fejPAdomYDEwLVpGubHyUMrFTqvJgI=fejPAdomYDEwLVpGubHyUMrFTqvJgC.API_DOMAIN+'/fz/search/band.js'
   fejPAdomYDEwLVpGubHyUMrFTqvJgN={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':fejPAdomYDEwLVpGubHyUMrFTqvJQa((page_int-1)*fejPAdomYDEwLVpGubHyUMrFTqvJgC.SEARCH_LIMIT),'limit':fejPAdomYDEwLVpGubHyUMrFTqvJgC.SEARCH_LIMIT,'orderby':'score','mtype':'svod',}
   fejPAdomYDEwLVpGubHyUMrFTqvJgN.update(fejPAdomYDEwLVpGubHyUMrFTqvJgC.GetDefaultParams(login=fejPAdomYDEwLVpGubHyUMrFTqvJQN))
   fejPAdomYDEwLVpGubHyUMrFTqvJSC=fejPAdomYDEwLVpGubHyUMrFTqvJgC.callRequestCookies('Get',fejPAdomYDEwLVpGubHyUMrFTqvJgI,payload=fejPAdomYDEwLVpGubHyUMrFTqvJQi,params=fejPAdomYDEwLVpGubHyUMrFTqvJgN,headers=fejPAdomYDEwLVpGubHyUMrFTqvJQi,cookies=fejPAdomYDEwLVpGubHyUMrFTqvJQi)
   fejPAdomYDEwLVpGubHyUMrFTqvJCO=json.loads(fejPAdomYDEwLVpGubHyUMrFTqvJSC.text)
   if not('celllist' in fejPAdomYDEwLVpGubHyUMrFTqvJCO['band']):return fejPAdomYDEwLVpGubHyUMrFTqvJhs,fejPAdomYDEwLVpGubHyUMrFTqvJCg
   fejPAdomYDEwLVpGubHyUMrFTqvJSO=fejPAdomYDEwLVpGubHyUMrFTqvJCO['band']['celllist']
   for fejPAdomYDEwLVpGubHyUMrFTqvJSt in fejPAdomYDEwLVpGubHyUMrFTqvJSO:
    fejPAdomYDEwLVpGubHyUMrFTqvJCS =fejPAdomYDEwLVpGubHyUMrFTqvJSt['event_list'][1]['url']
    fejPAdomYDEwLVpGubHyUMrFTqvJCh=urllib.parse.urlsplit(fejPAdomYDEwLVpGubHyUMrFTqvJCS).query
    fejPAdomYDEwLVpGubHyUMrFTqvJCl=fejPAdomYDEwLVpGubHyUMrFTqvJCh[0:fejPAdomYDEwLVpGubHyUMrFTqvJCh.find('=')]
    fejPAdomYDEwLVpGubHyUMrFTqvJCi=fejPAdomYDEwLVpGubHyUMrFTqvJQW(urllib.parse.parse_qsl(fejPAdomYDEwLVpGubHyUMrFTqvJCh))
    fejPAdomYDEwLVpGubHyUMrFTqvJCQ=fejPAdomYDEwLVpGubHyUMrFTqvJCi.get(fejPAdomYDEwLVpGubHyUMrFTqvJCl)
    fejPAdomYDEwLVpGubHyUMrFTqvJSa={'title':fejPAdomYDEwLVpGubHyUMrFTqvJSt['title_list'][0]['text'],'age':fejPAdomYDEwLVpGubHyUMrFTqvJSt['age'],'thumbnail':'https://%s'%fejPAdomYDEwLVpGubHyUMrFTqvJSt.get('thumbnail'),'videoid':fejPAdomYDEwLVpGubHyUMrFTqvJCQ,'vidtype':fejPAdomYDEwLVpGubHyUMrFTqvJCl,}
    fejPAdomYDEwLVpGubHyUMrFTqvJhz=fejPAdomYDEwLVpGubHyUMrFTqvJQN
    for fejPAdomYDEwLVpGubHyUMrFTqvJhW in fejPAdomYDEwLVpGubHyUMrFTqvJSt['bottom_taglist']:
     if fejPAdomYDEwLVpGubHyUMrFTqvJhW=='won':
      fejPAdomYDEwLVpGubHyUMrFTqvJhz=fejPAdomYDEwLVpGubHyUMrFTqvJQO
      break
    if fejPAdomYDEwLVpGubHyUMrFTqvJhz==fejPAdomYDEwLVpGubHyUMrFTqvJQO: 
     fejPAdomYDEwLVpGubHyUMrFTqvJSa['title']=fejPAdomYDEwLVpGubHyUMrFTqvJSa['title']+' [개별구매]'
    if exclusion21==fejPAdomYDEwLVpGubHyUMrFTqvJQN or fejPAdomYDEwLVpGubHyUMrFTqvJSt.get('age')!='21':
     fejPAdomYDEwLVpGubHyUMrFTqvJhs.append(fejPAdomYDEwLVpGubHyUMrFTqvJSa)
   fejPAdomYDEwLVpGubHyUMrFTqvJSI=fejPAdomYDEwLVpGubHyUMrFTqvJQR(fejPAdomYDEwLVpGubHyUMrFTqvJCO['band']['pagecount'])
   if fejPAdomYDEwLVpGubHyUMrFTqvJCO['band']['count']:fejPAdomYDEwLVpGubHyUMrFTqvJCB =fejPAdomYDEwLVpGubHyUMrFTqvJQR(fejPAdomYDEwLVpGubHyUMrFTqvJCO['band']['count'])
   else:fejPAdomYDEwLVpGubHyUMrFTqvJCB=fejPAdomYDEwLVpGubHyUMrFTqvJgC.LIST_LIMIT
   fejPAdomYDEwLVpGubHyUMrFTqvJCg=fejPAdomYDEwLVpGubHyUMrFTqvJSI>fejPAdomYDEwLVpGubHyUMrFTqvJCB
  except fejPAdomYDEwLVpGubHyUMrFTqvJQs as exception:
   fejPAdomYDEwLVpGubHyUMrFTqvJQz(exception)
  return fejPAdomYDEwLVpGubHyUMrFTqvJhs,fejPAdomYDEwLVpGubHyUMrFTqvJCg 
 def GetSecureToken(fejPAdomYDEwLVpGubHyUMrFTqvJgC):
  fejPAdomYDEwLVpGubHyUMrFTqvJgI=fejPAdomYDEwLVpGubHyUMrFTqvJgC.API_DOMAIN+'/ip'
  fejPAdomYDEwLVpGubHyUMrFTqvJgN=fejPAdomYDEwLVpGubHyUMrFTqvJgC.GetDefaultParams(login=fejPAdomYDEwLVpGubHyUMrFTqvJQN)
  fejPAdomYDEwLVpGubHyUMrFTqvJSC=fejPAdomYDEwLVpGubHyUMrFTqvJgC.callRequestCookies('Get',fejPAdomYDEwLVpGubHyUMrFTqvJgI,payload=fejPAdomYDEwLVpGubHyUMrFTqvJQi,params=fejPAdomYDEwLVpGubHyUMrFTqvJgN,headers=fejPAdomYDEwLVpGubHyUMrFTqvJQi,cookies=fejPAdomYDEwLVpGubHyUMrFTqvJQi)
  fejPAdomYDEwLVpGubHyUMrFTqvJSh=json.loads(fejPAdomYDEwLVpGubHyUMrFTqvJSC.text)
  return fejPAdomYDEwLVpGubHyUMrFTqvJSh['securetoken']
 def GetStreamingURL(fejPAdomYDEwLVpGubHyUMrFTqvJgC,mode,fejPAdomYDEwLVpGubHyUMrFTqvJCk,quality_int,pvrmode='-',playOption={}):
  fejPAdomYDEwLVpGubHyUMrFTqvJhR ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  fejPAdomYDEwLVpGubHyUMrFTqvJhc=[]
  if mode=='LIVE':
   fejPAdomYDEwLVpGubHyUMrFTqvJgI =fejPAdomYDEwLVpGubHyUMrFTqvJgC.API_DOMAIN+'/live/channels/'+fejPAdomYDEwLVpGubHyUMrFTqvJCk
   fejPAdomYDEwLVpGubHyUMrFTqvJhK='live'
  elif mode=='VOD':
   fejPAdomYDEwLVpGubHyUMrFTqvJgI =fejPAdomYDEwLVpGubHyUMrFTqvJgC.API_DOMAIN+'/fz/vod/contents-detail/'+fejPAdomYDEwLVpGubHyUMrFTqvJCk 
   fejPAdomYDEwLVpGubHyUMrFTqvJhK='vod'
  elif mode=='MOVIE':
   fejPAdomYDEwLVpGubHyUMrFTqvJgI =fejPAdomYDEwLVpGubHyUMrFTqvJgC.API_DOMAIN+'/fz/movie/contents/'+fejPAdomYDEwLVpGubHyUMrFTqvJCk
   fejPAdomYDEwLVpGubHyUMrFTqvJhK='movie'
  fejPAdomYDEwLVpGubHyUMrFTqvJhI={'hdr':'sdr',}
  try:
   fejPAdomYDEwLVpGubHyUMrFTqvJgN=fejPAdomYDEwLVpGubHyUMrFTqvJgC.GetDefaultParams(login=fejPAdomYDEwLVpGubHyUMrFTqvJQN)
   fejPAdomYDEwLVpGubHyUMrFTqvJSC=fejPAdomYDEwLVpGubHyUMrFTqvJgC.callRequestCookies('Get',fejPAdomYDEwLVpGubHyUMrFTqvJgI,payload=fejPAdomYDEwLVpGubHyUMrFTqvJQi,params=fejPAdomYDEwLVpGubHyUMrFTqvJgN,headers=fejPAdomYDEwLVpGubHyUMrFTqvJQi,cookies=fejPAdomYDEwLVpGubHyUMrFTqvJQi)
   fejPAdomYDEwLVpGubHyUMrFTqvJSh=json.loads(fejPAdomYDEwLVpGubHyUMrFTqvJSC.text)
   fejPAdomYDEwLVpGubHyUMrFTqvJlg=fejPAdomYDEwLVpGubHyUMrFTqvJSh['qualities']['list']
   if fejPAdomYDEwLVpGubHyUMrFTqvJlg==fejPAdomYDEwLVpGubHyUMrFTqvJQi:return fejPAdomYDEwLVpGubHyUMrFTqvJhR
   for fejPAdomYDEwLVpGubHyUMrFTqvJlS in fejPAdomYDEwLVpGubHyUMrFTqvJlg:
    fejPAdomYDEwLVpGubHyUMrFTqvJhc.append(fejPAdomYDEwLVpGubHyUMrFTqvJQR(fejPAdomYDEwLVpGubHyUMrFTqvJlS.get('id').rstrip('p')))
   if 'type' in fejPAdomYDEwLVpGubHyUMrFTqvJSh:
    if fejPAdomYDEwLVpGubHyUMrFTqvJSh['type']=='onair':
     fejPAdomYDEwLVpGubHyUMrFTqvJhK='onairvod'
   if 'drms' in fejPAdomYDEwLVpGubHyUMrFTqvJSh:
    if fejPAdomYDEwLVpGubHyUMrFTqvJSh['drms']:
     fejPAdomYDEwLVpGubHyUMrFTqvJhR['stream_action']='dash'
   if playOption.get('enable_hdr'):
    if 'mediatypes' in fejPAdomYDEwLVpGubHyUMrFTqvJSh.get('qualities'):
     for fejPAdomYDEwLVpGubHyUMrFTqvJlC in fejPAdomYDEwLVpGubHyUMrFTqvJSh.get('qualities').get('mediatypes'):
      if fejPAdomYDEwLVpGubHyUMrFTqvJlC=='HDR10':
       fejPAdomYDEwLVpGubHyUMrFTqvJhI['hdr']='hdr'
       fejPAdomYDEwLVpGubHyUMrFTqvJhR['stream_action']='dash'
       break
  except fejPAdomYDEwLVpGubHyUMrFTqvJQs as exception:
   fejPAdomYDEwLVpGubHyUMrFTqvJQz(exception)
   return fejPAdomYDEwLVpGubHyUMrFTqvJhR
  fejPAdomYDEwLVpGubHyUMrFTqvJQz(fejPAdomYDEwLVpGubHyUMrFTqvJhR['stream_action'])
  try:
   fejPAdomYDEwLVpGubHyUMrFTqvJlh=fejPAdomYDEwLVpGubHyUMrFTqvJgC.CheckQuality(quality_int,fejPAdomYDEwLVpGubHyUMrFTqvJhc)
   fejPAdomYDEwLVpGubHyUMrFTqvJlQ=fejPAdomYDEwLVpGubHyUMrFTqvJQa(fejPAdomYDEwLVpGubHyUMrFTqvJlh)+'p'
   fejPAdomYDEwLVpGubHyUMrFTqvJgI=fejPAdomYDEwLVpGubHyUMrFTqvJgC.API_DOMAIN+'/fz/streaming'
   if fejPAdomYDEwLVpGubHyUMrFTqvJhI['hdr']=='hdr':
    fejPAdomYDEwLVpGubHyUMrFTqvJgN={'contentid':fejPAdomYDEwLVpGubHyUMrFTqvJCk,'contenttype':fejPAdomYDEwLVpGubHyUMrFTqvJhK,'quality':fejPAdomYDEwLVpGubHyUMrFTqvJlQ,'modelid':'SHIELD Android TV','guid':fejPAdomYDEwLVpGubHyUMrFTqvJgC.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n','protocol':fejPAdomYDEwLVpGubHyUMrFTqvJhR['stream_action'],'hdr':'HDR10','videocodec':'HEVC','audiocodec':'AAC','issurround':'y','format':'normal','withinsubtitle':'n',}
    fejPAdomYDEwLVpGubHyUMrFTqvJgN.update(fejPAdomYDEwLVpGubHyUMrFTqvJgC.GetDefaultParams_AND())
   else:
    fejPAdomYDEwLVpGubHyUMrFTqvJgN={'contentid':fejPAdomYDEwLVpGubHyUMrFTqvJCk,'contenttype':fejPAdomYDEwLVpGubHyUMrFTqvJhK,'quality':fejPAdomYDEwLVpGubHyUMrFTqvJlQ,'deviceModelId':'Windows 10','guid':fejPAdomYDEwLVpGubHyUMrFTqvJgC.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n','action':fejPAdomYDEwLVpGubHyUMrFTqvJhR['stream_action'],'protocol':fejPAdomYDEwLVpGubHyUMrFTqvJhR['stream_action'],'hdr':'sdr','videocodec':'avc','audiocodec':'aac','issurround':'n','format':'normal','withinsubtitle':'n',}
    fejPAdomYDEwLVpGubHyUMrFTqvJgN.update(fejPAdomYDEwLVpGubHyUMrFTqvJgC.GetDefaultParams(login=fejPAdomYDEwLVpGubHyUMrFTqvJQO))
   fejPAdomYDEwLVpGubHyUMrFTqvJSC=fejPAdomYDEwLVpGubHyUMrFTqvJgC.callRequestCookies('Get',fejPAdomYDEwLVpGubHyUMrFTqvJgI,payload=fejPAdomYDEwLVpGubHyUMrFTqvJQi,params=fejPAdomYDEwLVpGubHyUMrFTqvJgN,headers=fejPAdomYDEwLVpGubHyUMrFTqvJQi,cookies=fejPAdomYDEwLVpGubHyUMrFTqvJQi)
   fejPAdomYDEwLVpGubHyUMrFTqvJSh=json.loads(fejPAdomYDEwLVpGubHyUMrFTqvJSC.text)
   fejPAdomYDEwLVpGubHyUMrFTqvJhR['stream_url']=fejPAdomYDEwLVpGubHyUMrFTqvJSh['playurl']
   if fejPAdomYDEwLVpGubHyUMrFTqvJhR['stream_url']==fejPAdomYDEwLVpGubHyUMrFTqvJQi:return fejPAdomYDEwLVpGubHyUMrFTqvJhR
   fejPAdomYDEwLVpGubHyUMrFTqvJhR['stream_cookie']=fejPAdomYDEwLVpGubHyUMrFTqvJSh['awscookie']
   fejPAdomYDEwLVpGubHyUMrFTqvJhR['stream_drm'] =fejPAdomYDEwLVpGubHyUMrFTqvJSh['drm']
   if 'previewmsg' in fejPAdomYDEwLVpGubHyUMrFTqvJSh['preview']:fejPAdomYDEwLVpGubHyUMrFTqvJhR['stream_preview']=fejPAdomYDEwLVpGubHyUMrFTqvJSh['preview']['previewmsg']
   if 'subtitles' in fejPAdomYDEwLVpGubHyUMrFTqvJSh:
    for fejPAdomYDEwLVpGubHyUMrFTqvJlB in fejPAdomYDEwLVpGubHyUMrFTqvJSh['subtitles']:
     if fejPAdomYDEwLVpGubHyUMrFTqvJlB.get('languagecode')=='ko':
      fejPAdomYDEwLVpGubHyUMrFTqvJhR['stream_vtt']=fejPAdomYDEwLVpGubHyUMrFTqvJlB.get('url')
      break
    if fejPAdomYDEwLVpGubHyUMrFTqvJhR['stream_vtt']=='':
     for fejPAdomYDEwLVpGubHyUMrFTqvJlB in fejPAdomYDEwLVpGubHyUMrFTqvJSh['subtitles']:
      if fejPAdomYDEwLVpGubHyUMrFTqvJlB.get('languagecode')=='ko_cc':
       fejPAdomYDEwLVpGubHyUMrFTqvJhR['stream_vtt']=fejPAdomYDEwLVpGubHyUMrFTqvJlB.get('url')
       break
  except fejPAdomYDEwLVpGubHyUMrFTqvJQs as exception:
   fejPAdomYDEwLVpGubHyUMrFTqvJQz(exception)
  return fejPAdomYDEwLVpGubHyUMrFTqvJhR 
 def GetSportsURL(fejPAdomYDEwLVpGubHyUMrFTqvJgC,fejPAdomYDEwLVpGubHyUMrFTqvJCk,quality_int):
  fejPAdomYDEwLVpGubHyUMrFTqvJhR ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  fejPAdomYDEwLVpGubHyUMrFTqvJhc=[]
  try:
   fejPAdomYDEwLVpGubHyUMrFTqvJgI=fejPAdomYDEwLVpGubHyUMrFTqvJgC.API_DOMAIN+'/streaming/other'
   fejPAdomYDEwLVpGubHyUMrFTqvJgN={'contentid':fejPAdomYDEwLVpGubHyUMrFTqvJCk,'contenttype':'live','action':fejPAdomYDEwLVpGubHyUMrFTqvJhR['stream_action'],'quality':fejPAdomYDEwLVpGubHyUMrFTqvJQa(quality_int)+'p','deviceModelId':'Windows 10','guid':fejPAdomYDEwLVpGubHyUMrFTqvJgC.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n',}
   fejPAdomYDEwLVpGubHyUMrFTqvJgN.update(fejPAdomYDEwLVpGubHyUMrFTqvJgC.GetDefaultParams(login=fejPAdomYDEwLVpGubHyUMrFTqvJQO))
   fejPAdomYDEwLVpGubHyUMrFTqvJSC=fejPAdomYDEwLVpGubHyUMrFTqvJgC.callRequestCookies('Get',fejPAdomYDEwLVpGubHyUMrFTqvJgI,payload=fejPAdomYDEwLVpGubHyUMrFTqvJQi,params=fejPAdomYDEwLVpGubHyUMrFTqvJgN,headers=fejPAdomYDEwLVpGubHyUMrFTqvJQi,cookies=fejPAdomYDEwLVpGubHyUMrFTqvJQi)
   fejPAdomYDEwLVpGubHyUMrFTqvJSh=json.loads(fejPAdomYDEwLVpGubHyUMrFTqvJSC.text)
   fejPAdomYDEwLVpGubHyUMrFTqvJhR['stream_url']=fejPAdomYDEwLVpGubHyUMrFTqvJSh['playurl']
   if fejPAdomYDEwLVpGubHyUMrFTqvJhR['stream_url']==fejPAdomYDEwLVpGubHyUMrFTqvJQi:return fejPAdomYDEwLVpGubHyUMrFTqvJhR
   fejPAdomYDEwLVpGubHyUMrFTqvJhR['stream_cookie']=fejPAdomYDEwLVpGubHyUMrFTqvJSh['awscookie']
  except fejPAdomYDEwLVpGubHyUMrFTqvJQs as exception:
   fejPAdomYDEwLVpGubHyUMrFTqvJQz(exception)
  return fejPAdomYDEwLVpGubHyUMrFTqvJhR
 def make_viewdate(fejPAdomYDEwLVpGubHyUMrFTqvJgC):
  fejPAdomYDEwLVpGubHyUMrFTqvJln =fejPAdomYDEwLVpGubHyUMrFTqvJgC.Get_Now_Datetime()
  fejPAdomYDEwLVpGubHyUMrFTqvJlx =fejPAdomYDEwLVpGubHyUMrFTqvJln+datetime.timedelta(days=-1)
  fejPAdomYDEwLVpGubHyUMrFTqvJlX =fejPAdomYDEwLVpGubHyUMrFTqvJln+datetime.timedelta(days=1)
  fejPAdomYDEwLVpGubHyUMrFTqvJli=[fejPAdomYDEwLVpGubHyUMrFTqvJln.strftime('%Y%m%d'),fejPAdomYDEwLVpGubHyUMrFTqvJlX.strftime('%Y%m%d'),]
  return fejPAdomYDEwLVpGubHyUMrFTqvJli
 def Get_Sports_Gamelist(fejPAdomYDEwLVpGubHyUMrFTqvJgC):
  fejPAdomYDEwLVpGubHyUMrFTqvJlN =fejPAdomYDEwLVpGubHyUMrFTqvJgC.make_viewdate()
  fejPAdomYDEwLVpGubHyUMrFTqvJlk=[]
  fejPAdomYDEwLVpGubHyUMrFTqvJlO =[]
  for fejPAdomYDEwLVpGubHyUMrFTqvJlt in fejPAdomYDEwLVpGubHyUMrFTqvJlN:
   fejPAdomYDEwLVpGubHyUMrFTqvJla=fejPAdomYDEwLVpGubHyUMrFTqvJlt[:6]
   if fejPAdomYDEwLVpGubHyUMrFTqvJla not in fejPAdomYDEwLVpGubHyUMrFTqvJlk:
    fejPAdomYDEwLVpGubHyUMrFTqvJlk.append(fejPAdomYDEwLVpGubHyUMrFTqvJla)
  try:
   fejPAdomYDEwLVpGubHyUMrFTqvJgI='https://annexapi.wavve.com/skb/baseball/teammonthlycalendarlist'
   fejPAdomYDEwLVpGubHyUMrFTqvJgN={'IF':'IF-PORG-002','m':'getTeamCalendarListBand','response_format':'json','spo_itm_cd':'KBO','teamcd':'all','tgroup':'B','tvalue':'BC123','ver':'2.0',}
   fejPAdomYDEwLVpGubHyUMrFTqvJgN.update(fejPAdomYDEwLVpGubHyUMrFTqvJgC.GetDefaultParams(login=fejPAdomYDEwLVpGubHyUMrFTqvJQN))
   for fejPAdomYDEwLVpGubHyUMrFTqvJls in fejPAdomYDEwLVpGubHyUMrFTqvJlk:
    fejPAdomYDEwLVpGubHyUMrFTqvJgN['date']=fejPAdomYDEwLVpGubHyUMrFTqvJls
    fejPAdomYDEwLVpGubHyUMrFTqvJSC=fejPAdomYDEwLVpGubHyUMrFTqvJgC.callRequestCookies('Get',fejPAdomYDEwLVpGubHyUMrFTqvJgI,payload=fejPAdomYDEwLVpGubHyUMrFTqvJQi,params=fejPAdomYDEwLVpGubHyUMrFTqvJgN,headers=fejPAdomYDEwLVpGubHyUMrFTqvJQi,cookies=fejPAdomYDEwLVpGubHyUMrFTqvJQi)
    fejPAdomYDEwLVpGubHyUMrFTqvJSh=json.loads(fejPAdomYDEwLVpGubHyUMrFTqvJSC.text)
    fejPAdomYDEwLVpGubHyUMrFTqvJSO=fejPAdomYDEwLVpGubHyUMrFTqvJSh['cell_toplist']['celllist']
    for fejPAdomYDEwLVpGubHyUMrFTqvJSt in fejPAdomYDEwLVpGubHyUMrFTqvJSO:
     fejPAdomYDEwLVpGubHyUMrFTqvJlz=fejPAdomYDEwLVpGubHyUMrFTqvJSt.get('game_date')
     fejPAdomYDEwLVpGubHyUMrFTqvJlW =fejPAdomYDEwLVpGubHyUMrFTqvJSt.get('svc_id')
     if fejPAdomYDEwLVpGubHyUMrFTqvJlW=='':continue
     if fejPAdomYDEwLVpGubHyUMrFTqvJlz in fejPAdomYDEwLVpGubHyUMrFTqvJlN:
      fejPAdomYDEwLVpGubHyUMrFTqvJlR=fejPAdomYDEwLVpGubHyUMrFTqvJSt.get('game_status') 
      fejPAdomYDEwLVpGubHyUMrFTqvJlc =fejPAdomYDEwLVpGubHyUMrFTqvJSt.get('title_list')[0].get('text')
      fejPAdomYDEwLVpGubHyUMrFTqvJlz =fejPAdomYDEwLVpGubHyUMrFTqvJlz[:4]+'-'+fejPAdomYDEwLVpGubHyUMrFTqvJlz[4:6]+'-'+fejPAdomYDEwLVpGubHyUMrFTqvJlz[-2:]
      fejPAdomYDEwLVpGubHyUMrFTqvJlK =fejPAdomYDEwLVpGubHyUMrFTqvJSt.get('game_time')
      fejPAdomYDEwLVpGubHyUMrFTqvJlK =fejPAdomYDEwLVpGubHyUMrFTqvJlK[:2]+':'+fejPAdomYDEwLVpGubHyUMrFTqvJlK[-2:]
      fejPAdomYDEwLVpGubHyUMrFTqvJSa={'game_date':fejPAdomYDEwLVpGubHyUMrFTqvJlz,'game_time':fejPAdomYDEwLVpGubHyUMrFTqvJlK,'svc_id':fejPAdomYDEwLVpGubHyUMrFTqvJlW,'away_team':fejPAdomYDEwLVpGubHyUMrFTqvJSt.get('away_team').get('team_name'),'home_team':fejPAdomYDEwLVpGubHyUMrFTqvJSt.get('home_team').get('team_name'),'game_status':fejPAdomYDEwLVpGubHyUMrFTqvJlR,'game_place':fejPAdomYDEwLVpGubHyUMrFTqvJSt.get('game_place'),}
      fejPAdomYDEwLVpGubHyUMrFTqvJlO.append(fejPAdomYDEwLVpGubHyUMrFTqvJSa)
  except fejPAdomYDEwLVpGubHyUMrFTqvJQs as exception:
   fejPAdomYDEwLVpGubHyUMrFTqvJQz(exception)
   return[]
  fejPAdomYDEwLVpGubHyUMrFTqvJlI=[]
  for i in fejPAdomYDEwLVpGubHyUMrFTqvJQt(2):
   for fejPAdomYDEwLVpGubHyUMrFTqvJSt in fejPAdomYDEwLVpGubHyUMrFTqvJlO:
    if i==0 and fejPAdomYDEwLVpGubHyUMrFTqvJSt.get('game_status')=='LIVE':
     fejPAdomYDEwLVpGubHyUMrFTqvJlI.append(fejPAdomYDEwLVpGubHyUMrFTqvJSt)
    elif i==1 and fejPAdomYDEwLVpGubHyUMrFTqvJSt.get('game_status')!='LIVE':
     fejPAdomYDEwLVpGubHyUMrFTqvJlI.append(fejPAdomYDEwLVpGubHyUMrFTqvJSt)
  return fejPAdomYDEwLVpGubHyUMrFTqvJlI
 def GetBookmarkInfo(fejPAdomYDEwLVpGubHyUMrFTqvJgC,fejPAdomYDEwLVpGubHyUMrFTqvJCQ,fejPAdomYDEwLVpGubHyUMrFTqvJCl,fejPAdomYDEwLVpGubHyUMrFTqvJhK):
  if fejPAdomYDEwLVpGubHyUMrFTqvJCl=='tvshow':
   if fejPAdomYDEwLVpGubHyUMrFTqvJhK=='contentid':
    fejPAdomYDEwLVpGubHyUMrFTqvJCk=fejPAdomYDEwLVpGubHyUMrFTqvJCQ
    fejPAdomYDEwLVpGubHyUMrFTqvJCQ =fejPAdomYDEwLVpGubHyUMrFTqvJgC.ContentidToSeasonid(fejPAdomYDEwLVpGubHyUMrFTqvJCk)
   else:
    fejPAdomYDEwLVpGubHyUMrFTqvJCk=fejPAdomYDEwLVpGubHyUMrFTqvJgC.ProgramidToContentid(fejPAdomYDEwLVpGubHyUMrFTqvJCQ)
  else:
   fejPAdomYDEwLVpGubHyUMrFTqvJCk=''
  fejPAdomYDEwLVpGubHyUMrFTqvJQg={'indexinfo':{'ott':'wavve','videoid':fejPAdomYDEwLVpGubHyUMrFTqvJCQ,'vidtype':fejPAdomYDEwLVpGubHyUMrFTqvJCl,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':fejPAdomYDEwLVpGubHyUMrFTqvJCl,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if fejPAdomYDEwLVpGubHyUMrFTqvJCl=='tvshow':
   fejPAdomYDEwLVpGubHyUMrFTqvJgI=fejPAdomYDEwLVpGubHyUMrFTqvJgC.API_DOMAIN+'/fz/vod/contents/'+fejPAdomYDEwLVpGubHyUMrFTqvJCk 
   fejPAdomYDEwLVpGubHyUMrFTqvJgN=fejPAdomYDEwLVpGubHyUMrFTqvJgC.GetDefaultParams(login=fejPAdomYDEwLVpGubHyUMrFTqvJQN)
   fejPAdomYDEwLVpGubHyUMrFTqvJSC=fejPAdomYDEwLVpGubHyUMrFTqvJgC.callRequestCookies('Get',fejPAdomYDEwLVpGubHyUMrFTqvJgI,payload=fejPAdomYDEwLVpGubHyUMrFTqvJQi,params=fejPAdomYDEwLVpGubHyUMrFTqvJgN,headers=fejPAdomYDEwLVpGubHyUMrFTqvJQi,cookies=fejPAdomYDEwLVpGubHyUMrFTqvJQi)
   fejPAdomYDEwLVpGubHyUMrFTqvJSh=json.loads(fejPAdomYDEwLVpGubHyUMrFTqvJSC.text)
   if not('programtitle' in fejPAdomYDEwLVpGubHyUMrFTqvJSh):return{}
   fejPAdomYDEwLVpGubHyUMrFTqvJQS=fejPAdomYDEwLVpGubHyUMrFTqvJSh
   fejPAdomYDEwLVpGubHyUMrFTqvJQC=fejPAdomYDEwLVpGubHyUMrFTqvJQS.get('programtitle')
   fejPAdomYDEwLVpGubHyUMrFTqvJQg['saveinfo']['infoLabels']['title']=fejPAdomYDEwLVpGubHyUMrFTqvJQC
   if fejPAdomYDEwLVpGubHyUMrFTqvJQS.get('targetage')=='18' or fejPAdomYDEwLVpGubHyUMrFTqvJQS.get('targetage')=='19' or fejPAdomYDEwLVpGubHyUMrFTqvJQS.get('targetage')=='21':
    fejPAdomYDEwLVpGubHyUMrFTqvJQC +=u' (%s)'%(fejPAdomYDEwLVpGubHyUMrFTqvJQS.get('targetage'))
   fejPAdomYDEwLVpGubHyUMrFTqvJQg['saveinfo']['title'] =fejPAdomYDEwLVpGubHyUMrFTqvJQC
   fejPAdomYDEwLVpGubHyUMrFTqvJQg['saveinfo']['infoLabels']['mpaa'] =fejPAdomYDEwLVpGubHyUMrFTqvJQS.get('targetage')
   fejPAdomYDEwLVpGubHyUMrFTqvJQg['saveinfo']['infoLabels']['plot'] =fejPAdomYDEwLVpGubHyUMrFTqvJQS.get('programsynopsis').replace('<br>','\n')
   fejPAdomYDEwLVpGubHyUMrFTqvJQg['saveinfo']['infoLabels']['studio'] =fejPAdomYDEwLVpGubHyUMrFTqvJQS.get('channelname')
   if fejPAdomYDEwLVpGubHyUMrFTqvJQS.get('firstreleaseyear')!='':fejPAdomYDEwLVpGubHyUMrFTqvJQg['saveinfo']['infoLabels']['year'] =fejPAdomYDEwLVpGubHyUMrFTqvJQS.get('firstreleaseyear')
   if fejPAdomYDEwLVpGubHyUMrFTqvJQS.get('firstreleasedate')!='':fejPAdomYDEwLVpGubHyUMrFTqvJQg['saveinfo']['infoLabels']['premiered']=fejPAdomYDEwLVpGubHyUMrFTqvJQS.get('firstreleasedate')
   if fejPAdomYDEwLVpGubHyUMrFTqvJQS.get('genretext') !='':fejPAdomYDEwLVpGubHyUMrFTqvJQg['saveinfo']['infoLabels']['genre'] =[fejPAdomYDEwLVpGubHyUMrFTqvJQS.get('genretext')]
   fejPAdomYDEwLVpGubHyUMrFTqvJQh=[]
   for fejPAdomYDEwLVpGubHyUMrFTqvJQl in fejPAdomYDEwLVpGubHyUMrFTqvJQS['actors']['list']:fejPAdomYDEwLVpGubHyUMrFTqvJQh.append(fejPAdomYDEwLVpGubHyUMrFTqvJQl.get('text'))
   if fejPAdomYDEwLVpGubHyUMrFTqvJQc(fejPAdomYDEwLVpGubHyUMrFTqvJQh)>0:
    if fejPAdomYDEwLVpGubHyUMrFTqvJQh[0]!='':fejPAdomYDEwLVpGubHyUMrFTqvJQg['saveinfo']['infoLabels']['cast']=fejPAdomYDEwLVpGubHyUMrFTqvJQh
   fejPAdomYDEwLVpGubHyUMrFTqvJhl =''
   fejPAdomYDEwLVpGubHyUMrFTqvJhQ =''
   fejPAdomYDEwLVpGubHyUMrFTqvJhB=''
   if fejPAdomYDEwLVpGubHyUMrFTqvJQS.get('programposterimage')!='':fejPAdomYDEwLVpGubHyUMrFTqvJhl =fejPAdomYDEwLVpGubHyUMrFTqvJgC.HTTPTAG+fejPAdomYDEwLVpGubHyUMrFTqvJQS.get('programposterimage')
   if fejPAdomYDEwLVpGubHyUMrFTqvJQS.get('programimage') !='':fejPAdomYDEwLVpGubHyUMrFTqvJhQ =fejPAdomYDEwLVpGubHyUMrFTqvJgC.HTTPTAG+fejPAdomYDEwLVpGubHyUMrFTqvJQS.get('programimage')
   if fejPAdomYDEwLVpGubHyUMrFTqvJQS.get('programcircleimage')!='':fejPAdomYDEwLVpGubHyUMrFTqvJhB=fejPAdomYDEwLVpGubHyUMrFTqvJgC.HTTPTAG+fejPAdomYDEwLVpGubHyUMrFTqvJQS.get('programcircleimage')
   if 'poster_default' in fejPAdomYDEwLVpGubHyUMrFTqvJhl:
    fejPAdomYDEwLVpGubHyUMrFTqvJhl =fejPAdomYDEwLVpGubHyUMrFTqvJhQ
    fejPAdomYDEwLVpGubHyUMrFTqvJhB=''
   fejPAdomYDEwLVpGubHyUMrFTqvJQg['saveinfo']['thumbnail']['poster']=fejPAdomYDEwLVpGubHyUMrFTqvJhl
   fejPAdomYDEwLVpGubHyUMrFTqvJQg['saveinfo']['thumbnail']['thumb']=fejPAdomYDEwLVpGubHyUMrFTqvJhQ
   fejPAdomYDEwLVpGubHyUMrFTqvJQg['saveinfo']['thumbnail']['clearlogo']=fejPAdomYDEwLVpGubHyUMrFTqvJhB
   fejPAdomYDEwLVpGubHyUMrFTqvJQg['saveinfo']['thumbnail']['fanart']=fejPAdomYDEwLVpGubHyUMrFTqvJhQ
  else:
   fejPAdomYDEwLVpGubHyUMrFTqvJgI=fejPAdomYDEwLVpGubHyUMrFTqvJgC.API_DOMAIN+'/movie/contents/'+fejPAdomYDEwLVpGubHyUMrFTqvJCQ 
   fejPAdomYDEwLVpGubHyUMrFTqvJgN=fejPAdomYDEwLVpGubHyUMrFTqvJgC.GetDefaultParams(login=fejPAdomYDEwLVpGubHyUMrFTqvJQN)
   fejPAdomYDEwLVpGubHyUMrFTqvJSC=fejPAdomYDEwLVpGubHyUMrFTqvJgC.callRequestCookies('Get',fejPAdomYDEwLVpGubHyUMrFTqvJgI,payload=fejPAdomYDEwLVpGubHyUMrFTqvJQi,params=fejPAdomYDEwLVpGubHyUMrFTqvJgN,headers=fejPAdomYDEwLVpGubHyUMrFTqvJQi,cookies=fejPAdomYDEwLVpGubHyUMrFTqvJQi)
   fejPAdomYDEwLVpGubHyUMrFTqvJSh=json.loads(fejPAdomYDEwLVpGubHyUMrFTqvJSC.text)
   if not('title' in fejPAdomYDEwLVpGubHyUMrFTqvJSh):return{}
   fejPAdomYDEwLVpGubHyUMrFTqvJQS=fejPAdomYDEwLVpGubHyUMrFTqvJSh
   fejPAdomYDEwLVpGubHyUMrFTqvJQC=fejPAdomYDEwLVpGubHyUMrFTqvJQS.get('title')
   fejPAdomYDEwLVpGubHyUMrFTqvJQg['saveinfo']['infoLabels']['title']=fejPAdomYDEwLVpGubHyUMrFTqvJQC
   if fejPAdomYDEwLVpGubHyUMrFTqvJQS.get('targetage')=='18' or fejPAdomYDEwLVpGubHyUMrFTqvJQS.get('targetage')=='19' or fejPAdomYDEwLVpGubHyUMrFTqvJQS.get('targetage')=='21':
    fejPAdomYDEwLVpGubHyUMrFTqvJQC +=u' (%s)'%(fejPAdomYDEwLVpGubHyUMrFTqvJQS.get('targetage'))
   fejPAdomYDEwLVpGubHyUMrFTqvJQg['saveinfo']['title'] =fejPAdomYDEwLVpGubHyUMrFTqvJQC
   fejPAdomYDEwLVpGubHyUMrFTqvJQg['saveinfo']['infoLabels']['mpaa'] =fejPAdomYDEwLVpGubHyUMrFTqvJQS.get('targetage')
   fejPAdomYDEwLVpGubHyUMrFTqvJQg['saveinfo']['infoLabels']['plot'] =fejPAdomYDEwLVpGubHyUMrFTqvJQS.get('synopsis').replace('<br>','\n')
   fejPAdomYDEwLVpGubHyUMrFTqvJQg['saveinfo']['infoLabels']['duration']=fejPAdomYDEwLVpGubHyUMrFTqvJQS.get('playtime')
   fejPAdomYDEwLVpGubHyUMrFTqvJQg['saveinfo']['infoLabels']['country']=fejPAdomYDEwLVpGubHyUMrFTqvJQS.get('country')
   fejPAdomYDEwLVpGubHyUMrFTqvJQg['saveinfo']['infoLabels']['studio'] =fejPAdomYDEwLVpGubHyUMrFTqvJQS.get('cpname')
   if fejPAdomYDEwLVpGubHyUMrFTqvJQS.get('releasedate')!='':
    fejPAdomYDEwLVpGubHyUMrFTqvJQg['saveinfo']['infoLabels']['year'] =fejPAdomYDEwLVpGubHyUMrFTqvJQS.get('releasedate')[:4]
    fejPAdomYDEwLVpGubHyUMrFTqvJQg['saveinfo']['infoLabels']['premiered']=fejPAdomYDEwLVpGubHyUMrFTqvJQS.get('releasedate')
   fejPAdomYDEwLVpGubHyUMrFTqvJQh=[]
   for fejPAdomYDEwLVpGubHyUMrFTqvJQl in fejPAdomYDEwLVpGubHyUMrFTqvJQS['actors']['list']:fejPAdomYDEwLVpGubHyUMrFTqvJQh.append(fejPAdomYDEwLVpGubHyUMrFTqvJQl.get('text'))
   if fejPAdomYDEwLVpGubHyUMrFTqvJQc(fejPAdomYDEwLVpGubHyUMrFTqvJQh)>0:
    if fejPAdomYDEwLVpGubHyUMrFTqvJQh[0]!='':fejPAdomYDEwLVpGubHyUMrFTqvJQg['saveinfo']['infoLabels']['cast']=fejPAdomYDEwLVpGubHyUMrFTqvJQh
   fejPAdomYDEwLVpGubHyUMrFTqvJQB=[]
   for fejPAdomYDEwLVpGubHyUMrFTqvJQn in fejPAdomYDEwLVpGubHyUMrFTqvJQS['directors']['list']:fejPAdomYDEwLVpGubHyUMrFTqvJQB.append(fejPAdomYDEwLVpGubHyUMrFTqvJQn.get('text'))
   if fejPAdomYDEwLVpGubHyUMrFTqvJQc(fejPAdomYDEwLVpGubHyUMrFTqvJQB)>0:
    if fejPAdomYDEwLVpGubHyUMrFTqvJQB[0]!='':fejPAdomYDEwLVpGubHyUMrFTqvJQg['saveinfo']['infoLabels']['director']=fejPAdomYDEwLVpGubHyUMrFTqvJQB
   fejPAdomYDEwLVpGubHyUMrFTqvJSi=[]
   for fejPAdomYDEwLVpGubHyUMrFTqvJQx in fejPAdomYDEwLVpGubHyUMrFTqvJQS['genre']['list']:fejPAdomYDEwLVpGubHyUMrFTqvJSi.append(fejPAdomYDEwLVpGubHyUMrFTqvJQx.get('text'))
   if fejPAdomYDEwLVpGubHyUMrFTqvJQc(fejPAdomYDEwLVpGubHyUMrFTqvJSi)>0:
    if fejPAdomYDEwLVpGubHyUMrFTqvJSi[0]!='':fejPAdomYDEwLVpGubHyUMrFTqvJQg['saveinfo']['infoLabels']['genre']=fejPAdomYDEwLVpGubHyUMrFTqvJSi
   fejPAdomYDEwLVpGubHyUMrFTqvJhl ='https://%s'%fejPAdomYDEwLVpGubHyUMrFTqvJQS['image']
   fejPAdomYDEwLVpGubHyUMrFTqvJQg['saveinfo']['thumbnail']['poster'] =fejPAdomYDEwLVpGubHyUMrFTqvJhl
   fejPAdomYDEwLVpGubHyUMrFTqvJQg['saveinfo']['thumbnail']['thumb'] =fejPAdomYDEwLVpGubHyUMrFTqvJhl
  return fejPAdomYDEwLVpGubHyUMrFTqvJQg
# Created by pyminifier (https://github.com/liftoff/pyminifier)
