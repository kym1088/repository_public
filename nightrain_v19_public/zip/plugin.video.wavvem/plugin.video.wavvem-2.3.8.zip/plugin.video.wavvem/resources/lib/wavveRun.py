__author__="NightRain"
icKwYGUBWnkoLfhquzxdlgVONStPAM=object
icKwYGUBWnkoLfhquzxdlgVONStPAb=None
icKwYGUBWnkoLfhquzxdlgVONStPAv=int
icKwYGUBWnkoLfhquzxdlgVONStPAR=True
icKwYGUBWnkoLfhquzxdlgVONStPAp=False
icKwYGUBWnkoLfhquzxdlgVONStPAD=type
icKwYGUBWnkoLfhquzxdlgVONStPAy=dict
icKwYGUBWnkoLfhquzxdlgVONStPAe=getattr
icKwYGUBWnkoLfhquzxdlgVONStPAI=list
icKwYGUBWnkoLfhquzxdlgVONStPAE=len
icKwYGUBWnkoLfhquzxdlgVONStPAT=range
icKwYGUBWnkoLfhquzxdlgVONStPAX=str
icKwYGUBWnkoLfhquzxdlgVONStPAr=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import json
icKwYGUBWnkoLfhquzxdlgVONStPsa=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://apis.wavve.com/v1/multiband/GN51','icon':'home.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&uicode=VN500','page':'1','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?WeekDay=all&broadcastid=1390539&contenttype=vod&genre=01&orderby=viewtime&uicode=VN4&uiparent=FN0&uirank=0&uitype=VN4','page':'1','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?WeekDay=all&broadcastid=1311034&contenttype=vod&genre=02&orderby=viewtime&uicode=VN3&uiparent=FN0&uirank=0&uitype=VN3','page':'1','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'CN21','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'vod09','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'vod09','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'4','sType':'movie','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'4','sType':'movie','orderby':'modifydate','ordernm':'업데이트순','icon':''},{'title':'프로야구 - 경기중 시청가능','mode':'GAME_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'(웨이브) 검색','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'(웨이브) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
icKwYGUBWnkoLfhquzxdlgVONStPsM=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
icKwYGUBWnkoLfhquzxdlgVONStPsb=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
icKwYGUBWnkoLfhquzxdlgVONStPsv={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
icKwYGUBWnkoLfhquzxdlgVONStPsR =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
icKwYGUBWnkoLfhquzxdlgVONStPsA=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_searched.txt'))
from wavveCore import*
class icKwYGUBWnkoLfhquzxdlgVONStPsQ(icKwYGUBWnkoLfhquzxdlgVONStPAM):
 def __init__(icKwYGUBWnkoLfhquzxdlgVONStPsp,icKwYGUBWnkoLfhquzxdlgVONStPsD,icKwYGUBWnkoLfhquzxdlgVONStPsy,icKwYGUBWnkoLfhquzxdlgVONStPse):
  icKwYGUBWnkoLfhquzxdlgVONStPsp._addon_url =icKwYGUBWnkoLfhquzxdlgVONStPsD
  icKwYGUBWnkoLfhquzxdlgVONStPsp._addon_handle=icKwYGUBWnkoLfhquzxdlgVONStPsy
  icKwYGUBWnkoLfhquzxdlgVONStPsp.main_params =icKwYGUBWnkoLfhquzxdlgVONStPse
  icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj =fejPAdomYDEwLVpGubHyUMrFTqvJgS() 
 def addon_noti(icKwYGUBWnkoLfhquzxdlgVONStPsp,sting):
  try:
   icKwYGUBWnkoLfhquzxdlgVONStPsE=xbmcgui.Dialog()
   icKwYGUBWnkoLfhquzxdlgVONStPsE.notification(__addonname__,sting)
  except:
   icKwYGUBWnkoLfhquzxdlgVONStPAb
 def addon_log(icKwYGUBWnkoLfhquzxdlgVONStPsp,string):
  try:
   icKwYGUBWnkoLfhquzxdlgVONStPsT=string.encode('utf-8','ignore')
  except:
   icKwYGUBWnkoLfhquzxdlgVONStPsT='addonException: addon_log'
  icKwYGUBWnkoLfhquzxdlgVONStPsX=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,icKwYGUBWnkoLfhquzxdlgVONStPsT),level=icKwYGUBWnkoLfhquzxdlgVONStPsX)
 def get_keyboard_input(icKwYGUBWnkoLfhquzxdlgVONStPsp,icKwYGUBWnkoLfhquzxdlgVONStPQy):
  icKwYGUBWnkoLfhquzxdlgVONStPsr=icKwYGUBWnkoLfhquzxdlgVONStPAb
  kb=xbmc.Keyboard()
  kb.setHeading(icKwYGUBWnkoLfhquzxdlgVONStPQy)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   icKwYGUBWnkoLfhquzxdlgVONStPsr=kb.getText()
  return icKwYGUBWnkoLfhquzxdlgVONStPsr
 def get_settings_account(icKwYGUBWnkoLfhquzxdlgVONStPsp):
  icKwYGUBWnkoLfhquzxdlgVONStPsH =__addon__.getSetting('id')
  icKwYGUBWnkoLfhquzxdlgVONStPsJ =__addon__.getSetting('pw')
  icKwYGUBWnkoLfhquzxdlgVONStPsj=icKwYGUBWnkoLfhquzxdlgVONStPAv(__addon__.getSetting('selected_profile'))
  return(icKwYGUBWnkoLfhquzxdlgVONStPsH,icKwYGUBWnkoLfhquzxdlgVONStPsJ,icKwYGUBWnkoLfhquzxdlgVONStPsj)
 def get_settings_totalsearch(icKwYGUBWnkoLfhquzxdlgVONStPsp):
  icKwYGUBWnkoLfhquzxdlgVONStPsm =icKwYGUBWnkoLfhquzxdlgVONStPAR if __addon__.getSetting('local_search')=='true' else icKwYGUBWnkoLfhquzxdlgVONStPAp
  icKwYGUBWnkoLfhquzxdlgVONStPsF=icKwYGUBWnkoLfhquzxdlgVONStPAR if __addon__.getSetting('local_history')=='true' else icKwYGUBWnkoLfhquzxdlgVONStPAp
  icKwYGUBWnkoLfhquzxdlgVONStPsC =icKwYGUBWnkoLfhquzxdlgVONStPAR if __addon__.getSetting('total_search')=='true' else icKwYGUBWnkoLfhquzxdlgVONStPAp
  icKwYGUBWnkoLfhquzxdlgVONStPQs=icKwYGUBWnkoLfhquzxdlgVONStPAR if __addon__.getSetting('total_history')=='true' else icKwYGUBWnkoLfhquzxdlgVONStPAp
  icKwYGUBWnkoLfhquzxdlgVONStPQa=icKwYGUBWnkoLfhquzxdlgVONStPAR if __addon__.getSetting('menu_bookmark')=='true' else icKwYGUBWnkoLfhquzxdlgVONStPAp
  return(icKwYGUBWnkoLfhquzxdlgVONStPsm,icKwYGUBWnkoLfhquzxdlgVONStPsF,icKwYGUBWnkoLfhquzxdlgVONStPsC,icKwYGUBWnkoLfhquzxdlgVONStPQs,icKwYGUBWnkoLfhquzxdlgVONStPQa)
 def get_settings_makebookmark(icKwYGUBWnkoLfhquzxdlgVONStPsp):
  return icKwYGUBWnkoLfhquzxdlgVONStPAR if __addon__.getSetting('make_bookmark')=='true' else icKwYGUBWnkoLfhquzxdlgVONStPAp
 def get_settings_play(icKwYGUBWnkoLfhquzxdlgVONStPsp):
  icKwYGUBWnkoLfhquzxdlgVONStPQM={'enable_hdr':icKwYGUBWnkoLfhquzxdlgVONStPAR if __addon__.getSetting('enable_hdr')=='true' else icKwYGUBWnkoLfhquzxdlgVONStPAp,}
  if icKwYGUBWnkoLfhquzxdlgVONStPQM['enable_hdr']==icKwYGUBWnkoLfhquzxdlgVONStPAR:
   if icKwYGUBWnkoLfhquzxdlgVONStPsp.get_selQuality()<1080:icKwYGUBWnkoLfhquzxdlgVONStPQM['enable_hdr']=icKwYGUBWnkoLfhquzxdlgVONStPAp
  return(icKwYGUBWnkoLfhquzxdlgVONStPQM)
 def get_selQuality(icKwYGUBWnkoLfhquzxdlgVONStPsp):
  try:
   icKwYGUBWnkoLfhquzxdlgVONStPQb=[1080,720,480,360]
   icKwYGUBWnkoLfhquzxdlgVONStPQv=icKwYGUBWnkoLfhquzxdlgVONStPAv(__addon__.getSetting('selected_quality'))
   return icKwYGUBWnkoLfhquzxdlgVONStPQb[icKwYGUBWnkoLfhquzxdlgVONStPQv]
  except:
   icKwYGUBWnkoLfhquzxdlgVONStPAb
  return 1080 
 def get_settings_exclusion21(icKwYGUBWnkoLfhquzxdlgVONStPsp):
  icKwYGUBWnkoLfhquzxdlgVONStPQR =__addon__.getSetting('exclusion21')
  if icKwYGUBWnkoLfhquzxdlgVONStPQR=='false':
   return icKwYGUBWnkoLfhquzxdlgVONStPAp
  else:
   return icKwYGUBWnkoLfhquzxdlgVONStPAR
 def get_settings_direct_replay(icKwYGUBWnkoLfhquzxdlgVONStPsp):
  icKwYGUBWnkoLfhquzxdlgVONStPQA=icKwYGUBWnkoLfhquzxdlgVONStPAv(__addon__.getSetting('direct_replay'))
  if icKwYGUBWnkoLfhquzxdlgVONStPQA==0:
   return icKwYGUBWnkoLfhquzxdlgVONStPAp
  else:
   return icKwYGUBWnkoLfhquzxdlgVONStPAR
 def set_winEpisodeOrderby(icKwYGUBWnkoLfhquzxdlgVONStPsp,icKwYGUBWnkoLfhquzxdlgVONStPQp):
  __addon__.setSetting('wavve_orderby',icKwYGUBWnkoLfhquzxdlgVONStPQp)
 def get_winEpisodeOrderby(icKwYGUBWnkoLfhquzxdlgVONStPsp):
  icKwYGUBWnkoLfhquzxdlgVONStPQp=__addon__.getSetting('wavve_orderby')
  if icKwYGUBWnkoLfhquzxdlgVONStPQp in['',icKwYGUBWnkoLfhquzxdlgVONStPAb]:icKwYGUBWnkoLfhquzxdlgVONStPQp='desc'
  return icKwYGUBWnkoLfhquzxdlgVONStPQp
 def add_dir(icKwYGUBWnkoLfhquzxdlgVONStPsp,label,sublabel='',img='',infoLabels=icKwYGUBWnkoLfhquzxdlgVONStPAb,isFolder=icKwYGUBWnkoLfhquzxdlgVONStPAR,params='',isLink=icKwYGUBWnkoLfhquzxdlgVONStPAp,ContextMenu=icKwYGUBWnkoLfhquzxdlgVONStPAb):
  icKwYGUBWnkoLfhquzxdlgVONStPQD='%s?%s'%(icKwYGUBWnkoLfhquzxdlgVONStPsp._addon_url,urllib.parse.urlencode(params))
  if sublabel:icKwYGUBWnkoLfhquzxdlgVONStPQy='%s < %s >'%(label,sublabel)
  else: icKwYGUBWnkoLfhquzxdlgVONStPQy=label
  if not img:img='DefaultFolder.png'
  icKwYGUBWnkoLfhquzxdlgVONStPQe=xbmcgui.ListItem(icKwYGUBWnkoLfhquzxdlgVONStPQy)
  if icKwYGUBWnkoLfhquzxdlgVONStPAD(img)==icKwYGUBWnkoLfhquzxdlgVONStPAy:
   icKwYGUBWnkoLfhquzxdlgVONStPQe.setArt(img)
  else:
   icKwYGUBWnkoLfhquzxdlgVONStPQe.setArt({'thumb':img,'poster':img})
  if infoLabels:icKwYGUBWnkoLfhquzxdlgVONStPsp.Set_InfoTag(icKwYGUBWnkoLfhquzxdlgVONStPQe.getVideoInfoTag(),infoLabels)
  if not isFolder and not isLink:
   icKwYGUBWnkoLfhquzxdlgVONStPQe.setProperty('IsPlayable','true')
  if ContextMenu:icKwYGUBWnkoLfhquzxdlgVONStPQe.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(icKwYGUBWnkoLfhquzxdlgVONStPsp._addon_handle,icKwYGUBWnkoLfhquzxdlgVONStPQD,icKwYGUBWnkoLfhquzxdlgVONStPQe,isFolder)
 def Set_InfoTag(icKwYGUBWnkoLfhquzxdlgVONStPsp,video_InfoTag:xbmc.InfoTagVideo,icKwYGUBWnkoLfhquzxdlgVONStPQj):
  for icKwYGUBWnkoLfhquzxdlgVONStPQI,value in icKwYGUBWnkoLfhquzxdlgVONStPQj.items():
   if icKwYGUBWnkoLfhquzxdlgVONStPsv[icKwYGUBWnkoLfhquzxdlgVONStPQI]['type']=='string':
    icKwYGUBWnkoLfhquzxdlgVONStPAe(video_InfoTag,icKwYGUBWnkoLfhquzxdlgVONStPsv[icKwYGUBWnkoLfhquzxdlgVONStPQI]['func'])(value)
   elif icKwYGUBWnkoLfhquzxdlgVONStPsv[icKwYGUBWnkoLfhquzxdlgVONStPQI]['type']=='int':
    if icKwYGUBWnkoLfhquzxdlgVONStPAD(value)==icKwYGUBWnkoLfhquzxdlgVONStPAv:
     icKwYGUBWnkoLfhquzxdlgVONStPQE=icKwYGUBWnkoLfhquzxdlgVONStPAv(value)
    else:
     icKwYGUBWnkoLfhquzxdlgVONStPQE=0
    icKwYGUBWnkoLfhquzxdlgVONStPAe(video_InfoTag,icKwYGUBWnkoLfhquzxdlgVONStPsv[icKwYGUBWnkoLfhquzxdlgVONStPQI]['func'])(icKwYGUBWnkoLfhquzxdlgVONStPQE)
   elif icKwYGUBWnkoLfhquzxdlgVONStPsv[icKwYGUBWnkoLfhquzxdlgVONStPQI]['type']=='actor':
    if value!=[]:
     icKwYGUBWnkoLfhquzxdlgVONStPAe(video_InfoTag,icKwYGUBWnkoLfhquzxdlgVONStPsv[icKwYGUBWnkoLfhquzxdlgVONStPQI]['func'])([xbmc.Actor(name)for name in value])
   elif icKwYGUBWnkoLfhquzxdlgVONStPsv[icKwYGUBWnkoLfhquzxdlgVONStPQI]['type']=='list':
    if icKwYGUBWnkoLfhquzxdlgVONStPAD(value)==icKwYGUBWnkoLfhquzxdlgVONStPAI:
     icKwYGUBWnkoLfhquzxdlgVONStPAe(video_InfoTag,icKwYGUBWnkoLfhquzxdlgVONStPsv[icKwYGUBWnkoLfhquzxdlgVONStPQI]['func'])(value)
    else:
     icKwYGUBWnkoLfhquzxdlgVONStPAe(video_InfoTag,icKwYGUBWnkoLfhquzxdlgVONStPsv[icKwYGUBWnkoLfhquzxdlgVONStPQI]['func'])([value])
 def dp_Main_List(icKwYGUBWnkoLfhquzxdlgVONStPsp):
  (icKwYGUBWnkoLfhquzxdlgVONStPsm,icKwYGUBWnkoLfhquzxdlgVONStPsF,icKwYGUBWnkoLfhquzxdlgVONStPsC,icKwYGUBWnkoLfhquzxdlgVONStPQs,icKwYGUBWnkoLfhquzxdlgVONStPQa)=icKwYGUBWnkoLfhquzxdlgVONStPsp.get_settings_totalsearch()
  for icKwYGUBWnkoLfhquzxdlgVONStPQT in icKwYGUBWnkoLfhquzxdlgVONStPsa:
   icKwYGUBWnkoLfhquzxdlgVONStPQy=icKwYGUBWnkoLfhquzxdlgVONStPQT.get('title')
   icKwYGUBWnkoLfhquzxdlgVONStPQX=''
   if icKwYGUBWnkoLfhquzxdlgVONStPQT.get('mode')=='SEARCH_GROUP' and icKwYGUBWnkoLfhquzxdlgVONStPsm ==icKwYGUBWnkoLfhquzxdlgVONStPAp:continue
   elif icKwYGUBWnkoLfhquzxdlgVONStPQT.get('mode')=='SEARCH_HISTORY' and icKwYGUBWnkoLfhquzxdlgVONStPsF==icKwYGUBWnkoLfhquzxdlgVONStPAp:continue
   elif icKwYGUBWnkoLfhquzxdlgVONStPQT.get('mode')=='TOTAL_SEARCH' and icKwYGUBWnkoLfhquzxdlgVONStPsC ==icKwYGUBWnkoLfhquzxdlgVONStPAp:continue
   elif icKwYGUBWnkoLfhquzxdlgVONStPQT.get('mode')=='TOTAL_HISTORY' and icKwYGUBWnkoLfhquzxdlgVONStPQs==icKwYGUBWnkoLfhquzxdlgVONStPAp:continue
   elif icKwYGUBWnkoLfhquzxdlgVONStPQT.get('mode')=='MENU_BOOKMARK' and icKwYGUBWnkoLfhquzxdlgVONStPQa==icKwYGUBWnkoLfhquzxdlgVONStPAp:continue
   icKwYGUBWnkoLfhquzxdlgVONStPQr={'mode':icKwYGUBWnkoLfhquzxdlgVONStPQT.get('mode'),'sCode':icKwYGUBWnkoLfhquzxdlgVONStPQT.get('sCode'),'sIndex':icKwYGUBWnkoLfhquzxdlgVONStPQT.get('sIndex'),'sType':icKwYGUBWnkoLfhquzxdlgVONStPQT.get('sType'),'suburl':icKwYGUBWnkoLfhquzxdlgVONStPQT.get('suburl'),'subapi':icKwYGUBWnkoLfhquzxdlgVONStPQT.get('subapi'),'page':icKwYGUBWnkoLfhquzxdlgVONStPQT.get('page'),'orderby':icKwYGUBWnkoLfhquzxdlgVONStPQT.get('orderby'),'ordernm':icKwYGUBWnkoLfhquzxdlgVONStPQT.get('ordernm')}
   if icKwYGUBWnkoLfhquzxdlgVONStPQT.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    icKwYGUBWnkoLfhquzxdlgVONStPQH=icKwYGUBWnkoLfhquzxdlgVONStPAp
    icKwYGUBWnkoLfhquzxdlgVONStPQJ =icKwYGUBWnkoLfhquzxdlgVONStPAR
   else:
    icKwYGUBWnkoLfhquzxdlgVONStPQH=icKwYGUBWnkoLfhquzxdlgVONStPAR
    icKwYGUBWnkoLfhquzxdlgVONStPQJ =icKwYGUBWnkoLfhquzxdlgVONStPAp
   icKwYGUBWnkoLfhquzxdlgVONStPQj={'title':icKwYGUBWnkoLfhquzxdlgVONStPQy,'plot':icKwYGUBWnkoLfhquzxdlgVONStPQy}
   if icKwYGUBWnkoLfhquzxdlgVONStPQT.get('mode')=='XXX':icKwYGUBWnkoLfhquzxdlgVONStPQj=icKwYGUBWnkoLfhquzxdlgVONStPAb
   if 'icon' in icKwYGUBWnkoLfhquzxdlgVONStPQT:icKwYGUBWnkoLfhquzxdlgVONStPQX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',icKwYGUBWnkoLfhquzxdlgVONStPQT.get('icon')) 
   icKwYGUBWnkoLfhquzxdlgVONStPsp.add_dir(icKwYGUBWnkoLfhquzxdlgVONStPQy,sublabel='',img=icKwYGUBWnkoLfhquzxdlgVONStPQX,infoLabels=icKwYGUBWnkoLfhquzxdlgVONStPQj,isFolder=icKwYGUBWnkoLfhquzxdlgVONStPQH,params=icKwYGUBWnkoLfhquzxdlgVONStPQr,isLink=icKwYGUBWnkoLfhquzxdlgVONStPQJ)
  xbmcplugin.endOfDirectory(icKwYGUBWnkoLfhquzxdlgVONStPsp._addon_handle,cacheToDisc=icKwYGUBWnkoLfhquzxdlgVONStPAR)
 def dp_Search_Group(icKwYGUBWnkoLfhquzxdlgVONStPsp,args):
  if 'search_key' in args:
   icKwYGUBWnkoLfhquzxdlgVONStPQC=args.get('search_key')
  else:
   icKwYGUBWnkoLfhquzxdlgVONStPQC=icKwYGUBWnkoLfhquzxdlgVONStPsp.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not icKwYGUBWnkoLfhquzxdlgVONStPQC:
    return
  for icKwYGUBWnkoLfhquzxdlgVONStPas in icKwYGUBWnkoLfhquzxdlgVONStPsM:
   icKwYGUBWnkoLfhquzxdlgVONStPaQ =icKwYGUBWnkoLfhquzxdlgVONStPas.get('mode')
   icKwYGUBWnkoLfhquzxdlgVONStPaM=icKwYGUBWnkoLfhquzxdlgVONStPas.get('sType')
   icKwYGUBWnkoLfhquzxdlgVONStPQy=icKwYGUBWnkoLfhquzxdlgVONStPas.get('title')
   (icKwYGUBWnkoLfhquzxdlgVONStPab,icKwYGUBWnkoLfhquzxdlgVONStPav)=icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.Get_Search_List(icKwYGUBWnkoLfhquzxdlgVONStPQC,icKwYGUBWnkoLfhquzxdlgVONStPaM,1,exclusion21=icKwYGUBWnkoLfhquzxdlgVONStPsp.get_settings_exclusion21())
   icKwYGUBWnkoLfhquzxdlgVONStPQj={'plot':'검색어 : '+icKwYGUBWnkoLfhquzxdlgVONStPQC+'\n\n'+icKwYGUBWnkoLfhquzxdlgVONStPsp.Search_FreeList(icKwYGUBWnkoLfhquzxdlgVONStPab)}
   icKwYGUBWnkoLfhquzxdlgVONStPQr={'mode':icKwYGUBWnkoLfhquzxdlgVONStPaQ,'sType':icKwYGUBWnkoLfhquzxdlgVONStPaM,'search_key':icKwYGUBWnkoLfhquzxdlgVONStPQC,'page':'1',}
   icKwYGUBWnkoLfhquzxdlgVONStPsp.add_dir(icKwYGUBWnkoLfhquzxdlgVONStPQy,sublabel='',img='',infoLabels=icKwYGUBWnkoLfhquzxdlgVONStPQj,isFolder=icKwYGUBWnkoLfhquzxdlgVONStPAR,params=icKwYGUBWnkoLfhquzxdlgVONStPQr)
  if icKwYGUBWnkoLfhquzxdlgVONStPAE(icKwYGUBWnkoLfhquzxdlgVONStPsM)>0:xbmcplugin.endOfDirectory(icKwYGUBWnkoLfhquzxdlgVONStPsp._addon_handle,cacheToDisc=icKwYGUBWnkoLfhquzxdlgVONStPAR)
  icKwYGUBWnkoLfhquzxdlgVONStPsp.Save_Searched_List(icKwYGUBWnkoLfhquzxdlgVONStPQC)
 def Search_FreeList(icKwYGUBWnkoLfhquzxdlgVONStPsp,search_list):
  icKwYGUBWnkoLfhquzxdlgVONStPaR=''
  icKwYGUBWnkoLfhquzxdlgVONStPaA=7
  try:
   if icKwYGUBWnkoLfhquzxdlgVONStPAE(search_list)==0:return '검색결과 없음'
   for i in icKwYGUBWnkoLfhquzxdlgVONStPAT(icKwYGUBWnkoLfhquzxdlgVONStPAE(search_list)):
    if i>=icKwYGUBWnkoLfhquzxdlgVONStPaA:
     icKwYGUBWnkoLfhquzxdlgVONStPaR=icKwYGUBWnkoLfhquzxdlgVONStPaR+'...'
     break
    icKwYGUBWnkoLfhquzxdlgVONStPaR=icKwYGUBWnkoLfhquzxdlgVONStPaR+search_list[i]['title']+'\n'
  except:
   return ''
  return icKwYGUBWnkoLfhquzxdlgVONStPaR
 def dp_Watch_Group(icKwYGUBWnkoLfhquzxdlgVONStPsp,args):
  for icKwYGUBWnkoLfhquzxdlgVONStPap in icKwYGUBWnkoLfhquzxdlgVONStPsb:
   icKwYGUBWnkoLfhquzxdlgVONStPQy=icKwYGUBWnkoLfhquzxdlgVONStPap.get('title')
   icKwYGUBWnkoLfhquzxdlgVONStPQr={'mode':icKwYGUBWnkoLfhquzxdlgVONStPap.get('mode'),'sType':icKwYGUBWnkoLfhquzxdlgVONStPap.get('sType')}
   icKwYGUBWnkoLfhquzxdlgVONStPsp.add_dir(icKwYGUBWnkoLfhquzxdlgVONStPQy,sublabel='',img='',infoLabels=icKwYGUBWnkoLfhquzxdlgVONStPAb,isFolder=icKwYGUBWnkoLfhquzxdlgVONStPAR,params=icKwYGUBWnkoLfhquzxdlgVONStPQr)
  if icKwYGUBWnkoLfhquzxdlgVONStPAE(icKwYGUBWnkoLfhquzxdlgVONStPsb)>0:xbmcplugin.endOfDirectory(icKwYGUBWnkoLfhquzxdlgVONStPsp._addon_handle,cacheToDisc=icKwYGUBWnkoLfhquzxdlgVONStPAR)
 def dp_Search_History(icKwYGUBWnkoLfhquzxdlgVONStPsp,args):
  icKwYGUBWnkoLfhquzxdlgVONStPaD=icKwYGUBWnkoLfhquzxdlgVONStPsp.Load_List_File('search')
  for icKwYGUBWnkoLfhquzxdlgVONStPay in icKwYGUBWnkoLfhquzxdlgVONStPaD:
   icKwYGUBWnkoLfhquzxdlgVONStPae=icKwYGUBWnkoLfhquzxdlgVONStPAy(urllib.parse.parse_qsl(icKwYGUBWnkoLfhquzxdlgVONStPay))
   icKwYGUBWnkoLfhquzxdlgVONStPaI=icKwYGUBWnkoLfhquzxdlgVONStPae.get('skey').strip()
   icKwYGUBWnkoLfhquzxdlgVONStPQr={'mode':'SEARCH_GROUP','search_key':icKwYGUBWnkoLfhquzxdlgVONStPaI,}
   icKwYGUBWnkoLfhquzxdlgVONStPaE={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':icKwYGUBWnkoLfhquzxdlgVONStPaI,'vType':'-',}
   icKwYGUBWnkoLfhquzxdlgVONStPaT=urllib.parse.urlencode(icKwYGUBWnkoLfhquzxdlgVONStPaE)
   icKwYGUBWnkoLfhquzxdlgVONStPaX=[('선택된 검색어 ( %s ) 삭제'%(icKwYGUBWnkoLfhquzxdlgVONStPaI),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(icKwYGUBWnkoLfhquzxdlgVONStPaT))]
   icKwYGUBWnkoLfhquzxdlgVONStPsp.add_dir(icKwYGUBWnkoLfhquzxdlgVONStPaI,sublabel='',img=icKwYGUBWnkoLfhquzxdlgVONStPAb,infoLabels=icKwYGUBWnkoLfhquzxdlgVONStPAb,isFolder=icKwYGUBWnkoLfhquzxdlgVONStPAR,params=icKwYGUBWnkoLfhquzxdlgVONStPQr,ContextMenu=icKwYGUBWnkoLfhquzxdlgVONStPaX)
  icKwYGUBWnkoLfhquzxdlgVONStPar={'plot':'검색목록 전체를 삭제합니다.'}
  icKwYGUBWnkoLfhquzxdlgVONStPQy='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  icKwYGUBWnkoLfhquzxdlgVONStPQr={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  icKwYGUBWnkoLfhquzxdlgVONStPQX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  icKwYGUBWnkoLfhquzxdlgVONStPsp.add_dir(icKwYGUBWnkoLfhquzxdlgVONStPQy,sublabel='',img=icKwYGUBWnkoLfhquzxdlgVONStPQX,infoLabels=icKwYGUBWnkoLfhquzxdlgVONStPar,isFolder=icKwYGUBWnkoLfhquzxdlgVONStPAp,params=icKwYGUBWnkoLfhquzxdlgVONStPQr,isLink=icKwYGUBWnkoLfhquzxdlgVONStPAR)
  xbmcplugin.endOfDirectory(icKwYGUBWnkoLfhquzxdlgVONStPsp._addon_handle,cacheToDisc=icKwYGUBWnkoLfhquzxdlgVONStPAp)
 def dp_Search_List(icKwYGUBWnkoLfhquzxdlgVONStPsp,args):
  icKwYGUBWnkoLfhquzxdlgVONStPaM =args.get('sType')
  icKwYGUBWnkoLfhquzxdlgVONStPaH =icKwYGUBWnkoLfhquzxdlgVONStPAv(args.get('page'))
  if 'search_key' in args:
   icKwYGUBWnkoLfhquzxdlgVONStPQC=args.get('search_key')
  else:
   icKwYGUBWnkoLfhquzxdlgVONStPQC=icKwYGUBWnkoLfhquzxdlgVONStPsp.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not icKwYGUBWnkoLfhquzxdlgVONStPQC:
    xbmcplugin.endOfDirectory(icKwYGUBWnkoLfhquzxdlgVONStPsp._addon_handle)
    return
  icKwYGUBWnkoLfhquzxdlgVONStPaJ,icKwYGUBWnkoLfhquzxdlgVONStPav=icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.Get_Search_List(icKwYGUBWnkoLfhquzxdlgVONStPQC,icKwYGUBWnkoLfhquzxdlgVONStPaM,icKwYGUBWnkoLfhquzxdlgVONStPaH,exclusion21=icKwYGUBWnkoLfhquzxdlgVONStPsp.get_settings_exclusion21())
  for icKwYGUBWnkoLfhquzxdlgVONStPaj in icKwYGUBWnkoLfhquzxdlgVONStPaJ:
   icKwYGUBWnkoLfhquzxdlgVONStPam =icKwYGUBWnkoLfhquzxdlgVONStPaj.get('videoid')
   icKwYGUBWnkoLfhquzxdlgVONStPaF =icKwYGUBWnkoLfhquzxdlgVONStPaj.get('vidtype')
   icKwYGUBWnkoLfhquzxdlgVONStPQy =icKwYGUBWnkoLfhquzxdlgVONStPaj.get('title')
   icKwYGUBWnkoLfhquzxdlgVONStPaC=icKwYGUBWnkoLfhquzxdlgVONStPaj.get('thumbnail')
   icKwYGUBWnkoLfhquzxdlgVONStPMs =icKwYGUBWnkoLfhquzxdlgVONStPaj.get('age')
   if icKwYGUBWnkoLfhquzxdlgVONStPMs=='18' or icKwYGUBWnkoLfhquzxdlgVONStPMs=='19' or icKwYGUBWnkoLfhquzxdlgVONStPMs=='21':icKwYGUBWnkoLfhquzxdlgVONStPQy+=' (%s)'%(icKwYGUBWnkoLfhquzxdlgVONStPMs)
   icKwYGUBWnkoLfhquzxdlgVONStPar={'mediatype':'tvshow' if icKwYGUBWnkoLfhquzxdlgVONStPaM=='vod' else 'movie','mpaa':icKwYGUBWnkoLfhquzxdlgVONStPMs,'title':icKwYGUBWnkoLfhquzxdlgVONStPQy,'plot':icKwYGUBWnkoLfhquzxdlgVONStPQy}
   if icKwYGUBWnkoLfhquzxdlgVONStPaM=='vod':
    icKwYGUBWnkoLfhquzxdlgVONStPQr={'mode':'EPISODE_LIST','seasonid':icKwYGUBWnkoLfhquzxdlgVONStPam,'page':'1',}
    icKwYGUBWnkoLfhquzxdlgVONStPQH=icKwYGUBWnkoLfhquzxdlgVONStPAR
   else:
    icKwYGUBWnkoLfhquzxdlgVONStPQr={'mode':'MOVIE','contentid':icKwYGUBWnkoLfhquzxdlgVONStPam,'title':icKwYGUBWnkoLfhquzxdlgVONStPQy,'thumbnail':icKwYGUBWnkoLfhquzxdlgVONStPaC,'age':icKwYGUBWnkoLfhquzxdlgVONStPMs,}
    icKwYGUBWnkoLfhquzxdlgVONStPQH=icKwYGUBWnkoLfhquzxdlgVONStPAp
   icKwYGUBWnkoLfhquzxdlgVONStPaX=[]
   icKwYGUBWnkoLfhquzxdlgVONStPMQ={'mode':'VIEW_DETAIL','values':{'videoid':icKwYGUBWnkoLfhquzxdlgVONStPam,'vidtype':'tvshow' if icKwYGUBWnkoLfhquzxdlgVONStPaM=='vod' else 'movie','contenttype':icKwYGUBWnkoLfhquzxdlgVONStPaF,}}
   icKwYGUBWnkoLfhquzxdlgVONStPMa=json.dumps(icKwYGUBWnkoLfhquzxdlgVONStPMQ,separators=(',',':'))
   icKwYGUBWnkoLfhquzxdlgVONStPMa=base64.standard_b64encode(icKwYGUBWnkoLfhquzxdlgVONStPMa.encode()).decode('utf-8')
   icKwYGUBWnkoLfhquzxdlgVONStPMa=icKwYGUBWnkoLfhquzxdlgVONStPMa.replace('+','%2B')
   icKwYGUBWnkoLfhquzxdlgVONStPMb='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(icKwYGUBWnkoLfhquzxdlgVONStPMa)
   icKwYGUBWnkoLfhquzxdlgVONStPaX.append(('상세정보 조회',icKwYGUBWnkoLfhquzxdlgVONStPMb))
   if icKwYGUBWnkoLfhquzxdlgVONStPsp.get_settings_makebookmark():
    icKwYGUBWnkoLfhquzxdlgVONStPMQ={'videoid':icKwYGUBWnkoLfhquzxdlgVONStPam,'vidtype':'tvshow' if icKwYGUBWnkoLfhquzxdlgVONStPaM=='vod' else 'movie','vtitle':icKwYGUBWnkoLfhquzxdlgVONStPQy,'vsubtitle':'','contenttype':icKwYGUBWnkoLfhquzxdlgVONStPaF,}
    icKwYGUBWnkoLfhquzxdlgVONStPMv=json.dumps(icKwYGUBWnkoLfhquzxdlgVONStPMQ)
    icKwYGUBWnkoLfhquzxdlgVONStPMv=urllib.parse.quote(icKwYGUBWnkoLfhquzxdlgVONStPMv)
    icKwYGUBWnkoLfhquzxdlgVONStPMb='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(icKwYGUBWnkoLfhquzxdlgVONStPMv)
    icKwYGUBWnkoLfhquzxdlgVONStPaX.append(('(통합) 찜 영상에 추가',icKwYGUBWnkoLfhquzxdlgVONStPMb))
   icKwYGUBWnkoLfhquzxdlgVONStPsp.add_dir(icKwYGUBWnkoLfhquzxdlgVONStPQy,sublabel='',img=icKwYGUBWnkoLfhquzxdlgVONStPaC,infoLabels=icKwYGUBWnkoLfhquzxdlgVONStPar,isFolder=icKwYGUBWnkoLfhquzxdlgVONStPQH,params=icKwYGUBWnkoLfhquzxdlgVONStPQr,ContextMenu=icKwYGUBWnkoLfhquzxdlgVONStPaX)
  if icKwYGUBWnkoLfhquzxdlgVONStPav:
   icKwYGUBWnkoLfhquzxdlgVONStPQr['mode'] ='SEARCH_LIST' 
   icKwYGUBWnkoLfhquzxdlgVONStPQr['sType']=icKwYGUBWnkoLfhquzxdlgVONStPaM 
   icKwYGUBWnkoLfhquzxdlgVONStPQr['page'] =icKwYGUBWnkoLfhquzxdlgVONStPAX(icKwYGUBWnkoLfhquzxdlgVONStPaH+1)
   icKwYGUBWnkoLfhquzxdlgVONStPQr['search_key']=icKwYGUBWnkoLfhquzxdlgVONStPQC
   icKwYGUBWnkoLfhquzxdlgVONStPQy='[B]%s >>[/B]'%'다음 페이지'
   icKwYGUBWnkoLfhquzxdlgVONStPMR=icKwYGUBWnkoLfhquzxdlgVONStPAX(icKwYGUBWnkoLfhquzxdlgVONStPaH+1)
   icKwYGUBWnkoLfhquzxdlgVONStPQX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   icKwYGUBWnkoLfhquzxdlgVONStPsp.add_dir(icKwYGUBWnkoLfhquzxdlgVONStPQy,sublabel=icKwYGUBWnkoLfhquzxdlgVONStPMR,img=icKwYGUBWnkoLfhquzxdlgVONStPQX,infoLabels=icKwYGUBWnkoLfhquzxdlgVONStPAb,isFolder=icKwYGUBWnkoLfhquzxdlgVONStPAR,params=icKwYGUBWnkoLfhquzxdlgVONStPQr)
  if icKwYGUBWnkoLfhquzxdlgVONStPaM=='movie':xbmcplugin.setContent(icKwYGUBWnkoLfhquzxdlgVONStPsp._addon_handle,'movies')
  else:xbmcplugin.setContent(icKwYGUBWnkoLfhquzxdlgVONStPsp._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(icKwYGUBWnkoLfhquzxdlgVONStPsp._addon_handle,cacheToDisc=icKwYGUBWnkoLfhquzxdlgVONStPAp)
 def dp_Watch_List(icKwYGUBWnkoLfhquzxdlgVONStPsp,args):
  icKwYGUBWnkoLfhquzxdlgVONStPaM =args.get('sType')
  icKwYGUBWnkoLfhquzxdlgVONStPQA=icKwYGUBWnkoLfhquzxdlgVONStPsp.get_settings_direct_replay()
  icKwYGUBWnkoLfhquzxdlgVONStPaJ=icKwYGUBWnkoLfhquzxdlgVONStPsp.Load_List_File(icKwYGUBWnkoLfhquzxdlgVONStPaM)
  for icKwYGUBWnkoLfhquzxdlgVONStPaj in icKwYGUBWnkoLfhquzxdlgVONStPaJ:
   icKwYGUBWnkoLfhquzxdlgVONStPae=icKwYGUBWnkoLfhquzxdlgVONStPAy(urllib.parse.parse_qsl(icKwYGUBWnkoLfhquzxdlgVONStPaj))
   icKwYGUBWnkoLfhquzxdlgVONStPMA =icKwYGUBWnkoLfhquzxdlgVONStPae.get('code').strip()
   icKwYGUBWnkoLfhquzxdlgVONStPQy =icKwYGUBWnkoLfhquzxdlgVONStPae.get('title').strip()
   icKwYGUBWnkoLfhquzxdlgVONStPMR =icKwYGUBWnkoLfhquzxdlgVONStPae.get('subtitle').strip()
   if icKwYGUBWnkoLfhquzxdlgVONStPMR=='None':icKwYGUBWnkoLfhquzxdlgVONStPMR=''
   icKwYGUBWnkoLfhquzxdlgVONStPaC=icKwYGUBWnkoLfhquzxdlgVONStPae.get('img').strip()
   icKwYGUBWnkoLfhquzxdlgVONStPam =icKwYGUBWnkoLfhquzxdlgVONStPae.get('videoid').strip()
   try:
    icKwYGUBWnkoLfhquzxdlgVONStPaC=icKwYGUBWnkoLfhquzxdlgVONStPaC.replace('\'','\"')
    icKwYGUBWnkoLfhquzxdlgVONStPaC=json.loads(icKwYGUBWnkoLfhquzxdlgVONStPaC)
   except:
    icKwYGUBWnkoLfhquzxdlgVONStPAb
   icKwYGUBWnkoLfhquzxdlgVONStPar={'plot':'%s\n%s'%(icKwYGUBWnkoLfhquzxdlgVONStPQy,icKwYGUBWnkoLfhquzxdlgVONStPMR)}
   if icKwYGUBWnkoLfhquzxdlgVONStPaM=='vod':
    if icKwYGUBWnkoLfhquzxdlgVONStPQA==icKwYGUBWnkoLfhquzxdlgVONStPAp or icKwYGUBWnkoLfhquzxdlgVONStPam==icKwYGUBWnkoLfhquzxdlgVONStPAb:
     icKwYGUBWnkoLfhquzxdlgVONStPar['mediatype']='tvshow'
     icKwYGUBWnkoLfhquzxdlgVONStPQr={'mode':'SEASON_LIST','videoid':icKwYGUBWnkoLfhquzxdlgVONStPam,'vidtype':'contentid',}
     icKwYGUBWnkoLfhquzxdlgVONStPQH=icKwYGUBWnkoLfhquzxdlgVONStPAR
    else:
     icKwYGUBWnkoLfhquzxdlgVONStPar['mediatype']='episode'
     icKwYGUBWnkoLfhquzxdlgVONStPQr={'mode':'VOD','programid':icKwYGUBWnkoLfhquzxdlgVONStPMA,'contentid':icKwYGUBWnkoLfhquzxdlgVONStPam,'title':icKwYGUBWnkoLfhquzxdlgVONStPQy,'subtitle':icKwYGUBWnkoLfhquzxdlgVONStPMR,'thumbnail':icKwYGUBWnkoLfhquzxdlgVONStPaC}
     icKwYGUBWnkoLfhquzxdlgVONStPQH=icKwYGUBWnkoLfhquzxdlgVONStPAp
   else:
    icKwYGUBWnkoLfhquzxdlgVONStPar['mediatype']='movie'
    icKwYGUBWnkoLfhquzxdlgVONStPQr={'mode':'MOVIE','contentid':icKwYGUBWnkoLfhquzxdlgVONStPMA,'title':icKwYGUBWnkoLfhquzxdlgVONStPQy,'subtitle':icKwYGUBWnkoLfhquzxdlgVONStPMR,'thumbnail':icKwYGUBWnkoLfhquzxdlgVONStPaC}
    icKwYGUBWnkoLfhquzxdlgVONStPQH=icKwYGUBWnkoLfhquzxdlgVONStPAp
   icKwYGUBWnkoLfhquzxdlgVONStPaE={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':icKwYGUBWnkoLfhquzxdlgVONStPMA,'vType':icKwYGUBWnkoLfhquzxdlgVONStPaM,}
   icKwYGUBWnkoLfhquzxdlgVONStPaT=urllib.parse.urlencode(icKwYGUBWnkoLfhquzxdlgVONStPaE)
   icKwYGUBWnkoLfhquzxdlgVONStPaX=[('선택된 시청이력 ( %s ) 삭제'%(icKwYGUBWnkoLfhquzxdlgVONStPQy),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(icKwYGUBWnkoLfhquzxdlgVONStPaT))]
   icKwYGUBWnkoLfhquzxdlgVONStPsp.add_dir(icKwYGUBWnkoLfhquzxdlgVONStPQy,sublabel=icKwYGUBWnkoLfhquzxdlgVONStPMR,img=icKwYGUBWnkoLfhquzxdlgVONStPaC,infoLabels=icKwYGUBWnkoLfhquzxdlgVONStPar,isFolder=icKwYGUBWnkoLfhquzxdlgVONStPQH,params=icKwYGUBWnkoLfhquzxdlgVONStPQr,ContextMenu=icKwYGUBWnkoLfhquzxdlgVONStPaX)
  icKwYGUBWnkoLfhquzxdlgVONStPar={'plot':'시청목록을 삭제합니다.'}
  icKwYGUBWnkoLfhquzxdlgVONStPQy='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  icKwYGUBWnkoLfhquzxdlgVONStPQr={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':icKwYGUBWnkoLfhquzxdlgVONStPaM,}
  icKwYGUBWnkoLfhquzxdlgVONStPQX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  icKwYGUBWnkoLfhquzxdlgVONStPsp.add_dir(icKwYGUBWnkoLfhquzxdlgVONStPQy,sublabel='',img=icKwYGUBWnkoLfhquzxdlgVONStPQX,infoLabels=icKwYGUBWnkoLfhquzxdlgVONStPar,isFolder=icKwYGUBWnkoLfhquzxdlgVONStPAp,params=icKwYGUBWnkoLfhquzxdlgVONStPQr,isLink=icKwYGUBWnkoLfhquzxdlgVONStPAR)
  if icKwYGUBWnkoLfhquzxdlgVONStPaM=='movie':xbmcplugin.setContent(icKwYGUBWnkoLfhquzxdlgVONStPsp._addon_handle,'movies')
  else:xbmcplugin.setContent(icKwYGUBWnkoLfhquzxdlgVONStPsp._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(icKwYGUBWnkoLfhquzxdlgVONStPsp._addon_handle,cacheToDisc=icKwYGUBWnkoLfhquzxdlgVONStPAp)
 def Load_List_File(icKwYGUBWnkoLfhquzxdlgVONStPsp,stype): 
  try:
   if stype=='search':
    icKwYGUBWnkoLfhquzxdlgVONStPMp=icKwYGUBWnkoLfhquzxdlgVONStPsA
   elif stype in['vod','movie']:
    icKwYGUBWnkoLfhquzxdlgVONStPMp=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   else:
    return[]
   fp=icKwYGUBWnkoLfhquzxdlgVONStPAr(icKwYGUBWnkoLfhquzxdlgVONStPMp,'r',-1,'utf-8')
   icKwYGUBWnkoLfhquzxdlgVONStPMD=fp.readlines()
   fp.close()
  except:
   icKwYGUBWnkoLfhquzxdlgVONStPMD=[]
  return icKwYGUBWnkoLfhquzxdlgVONStPMD
 def Save_Watched_List(icKwYGUBWnkoLfhquzxdlgVONStPsp,icKwYGUBWnkoLfhquzxdlgVONStPRI,icKwYGUBWnkoLfhquzxdlgVONStPse):
  try:
   icKwYGUBWnkoLfhquzxdlgVONStPMy=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%icKwYGUBWnkoLfhquzxdlgVONStPRI))
   icKwYGUBWnkoLfhquzxdlgVONStPMe=icKwYGUBWnkoLfhquzxdlgVONStPsp.Load_List_File(icKwYGUBWnkoLfhquzxdlgVONStPRI) 
   fp=icKwYGUBWnkoLfhquzxdlgVONStPAr(icKwYGUBWnkoLfhquzxdlgVONStPMy,'w',-1,'utf-8')
   icKwYGUBWnkoLfhquzxdlgVONStPMI=urllib.parse.urlencode(icKwYGUBWnkoLfhquzxdlgVONStPse)
   icKwYGUBWnkoLfhquzxdlgVONStPMI=icKwYGUBWnkoLfhquzxdlgVONStPMI+'\n'
   fp.write(icKwYGUBWnkoLfhquzxdlgVONStPMI)
   icKwYGUBWnkoLfhquzxdlgVONStPME=0
   for icKwYGUBWnkoLfhquzxdlgVONStPMT in icKwYGUBWnkoLfhquzxdlgVONStPMe:
    icKwYGUBWnkoLfhquzxdlgVONStPMX=icKwYGUBWnkoLfhquzxdlgVONStPAy(urllib.parse.parse_qsl(icKwYGUBWnkoLfhquzxdlgVONStPMT))
    icKwYGUBWnkoLfhquzxdlgVONStPMr=icKwYGUBWnkoLfhquzxdlgVONStPse.get('code').strip()
    icKwYGUBWnkoLfhquzxdlgVONStPMH=icKwYGUBWnkoLfhquzxdlgVONStPMX.get('code').strip()
    if icKwYGUBWnkoLfhquzxdlgVONStPRI=='vod' and icKwYGUBWnkoLfhquzxdlgVONStPsp.get_settings_direct_replay()==icKwYGUBWnkoLfhquzxdlgVONStPAR:
     icKwYGUBWnkoLfhquzxdlgVONStPMr=icKwYGUBWnkoLfhquzxdlgVONStPse.get('videoid').strip()
     icKwYGUBWnkoLfhquzxdlgVONStPMH=icKwYGUBWnkoLfhquzxdlgVONStPMX.get('videoid').strip()if icKwYGUBWnkoLfhquzxdlgVONStPMH!=icKwYGUBWnkoLfhquzxdlgVONStPAb else '-'
    if icKwYGUBWnkoLfhquzxdlgVONStPMr!=icKwYGUBWnkoLfhquzxdlgVONStPMH:
     fp.write(icKwYGUBWnkoLfhquzxdlgVONStPMT)
     icKwYGUBWnkoLfhquzxdlgVONStPME+=1
     if icKwYGUBWnkoLfhquzxdlgVONStPME>=50:break
   fp.close()
  except:
   icKwYGUBWnkoLfhquzxdlgVONStPAb
 def dp_History_Remove(icKwYGUBWnkoLfhquzxdlgVONStPsp,args):
  icKwYGUBWnkoLfhquzxdlgVONStPMJ=args.get('delType')
  icKwYGUBWnkoLfhquzxdlgVONStPMj =args.get('sKey')
  icKwYGUBWnkoLfhquzxdlgVONStPMm =args.get('vType')
  icKwYGUBWnkoLfhquzxdlgVONStPsE=xbmcgui.Dialog()
  if icKwYGUBWnkoLfhquzxdlgVONStPMJ=='SEARCH_ALL':
   icKwYGUBWnkoLfhquzxdlgVONStPMF=icKwYGUBWnkoLfhquzxdlgVONStPsE.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif icKwYGUBWnkoLfhquzxdlgVONStPMJ=='SEARCH_ONE':
   icKwYGUBWnkoLfhquzxdlgVONStPMF=icKwYGUBWnkoLfhquzxdlgVONStPsE.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif icKwYGUBWnkoLfhquzxdlgVONStPMJ=='WATCH_ALL':
   icKwYGUBWnkoLfhquzxdlgVONStPMF=icKwYGUBWnkoLfhquzxdlgVONStPsE.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif icKwYGUBWnkoLfhquzxdlgVONStPMJ=='WATCH_ONE':
   icKwYGUBWnkoLfhquzxdlgVONStPMF=icKwYGUBWnkoLfhquzxdlgVONStPsE.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if icKwYGUBWnkoLfhquzxdlgVONStPMF==icKwYGUBWnkoLfhquzxdlgVONStPAp:sys.exit()
  if icKwYGUBWnkoLfhquzxdlgVONStPMJ=='SEARCH_ALL':
   if os.path.isfile(icKwYGUBWnkoLfhquzxdlgVONStPsA):os.remove(icKwYGUBWnkoLfhquzxdlgVONStPsA)
  elif icKwYGUBWnkoLfhquzxdlgVONStPMJ=='SEARCH_ONE':
   try:
    icKwYGUBWnkoLfhquzxdlgVONStPMp=icKwYGUBWnkoLfhquzxdlgVONStPsA
    icKwYGUBWnkoLfhquzxdlgVONStPMe=icKwYGUBWnkoLfhquzxdlgVONStPsp.Load_List_File('search') 
    fp=icKwYGUBWnkoLfhquzxdlgVONStPAr(icKwYGUBWnkoLfhquzxdlgVONStPMp,'w',-1,'utf-8')
    for icKwYGUBWnkoLfhquzxdlgVONStPMT in icKwYGUBWnkoLfhquzxdlgVONStPMe:
     icKwYGUBWnkoLfhquzxdlgVONStPMX=icKwYGUBWnkoLfhquzxdlgVONStPAy(urllib.parse.parse_qsl(icKwYGUBWnkoLfhquzxdlgVONStPMT))
     icKwYGUBWnkoLfhquzxdlgVONStPMC=icKwYGUBWnkoLfhquzxdlgVONStPMX.get('skey').strip()
     if icKwYGUBWnkoLfhquzxdlgVONStPMj!=icKwYGUBWnkoLfhquzxdlgVONStPMC:
      fp.write(icKwYGUBWnkoLfhquzxdlgVONStPMT)
    fp.close()
   except:
    icKwYGUBWnkoLfhquzxdlgVONStPAb
  elif icKwYGUBWnkoLfhquzxdlgVONStPMJ=='WATCH_ALL':
   icKwYGUBWnkoLfhquzxdlgVONStPMp=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%icKwYGUBWnkoLfhquzxdlgVONStPMm))
   if os.path.isfile(icKwYGUBWnkoLfhquzxdlgVONStPMp):os.remove(icKwYGUBWnkoLfhquzxdlgVONStPMp)
  elif icKwYGUBWnkoLfhquzxdlgVONStPMJ=='WATCH_ONE':
   icKwYGUBWnkoLfhquzxdlgVONStPMp=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%icKwYGUBWnkoLfhquzxdlgVONStPMm))
   try:
    icKwYGUBWnkoLfhquzxdlgVONStPMe=icKwYGUBWnkoLfhquzxdlgVONStPsp.Load_List_File(icKwYGUBWnkoLfhquzxdlgVONStPMm) 
    fp=icKwYGUBWnkoLfhquzxdlgVONStPAr(icKwYGUBWnkoLfhquzxdlgVONStPMp,'w',-1,'utf-8')
    for icKwYGUBWnkoLfhquzxdlgVONStPMT in icKwYGUBWnkoLfhquzxdlgVONStPMe:
     icKwYGUBWnkoLfhquzxdlgVONStPMX=icKwYGUBWnkoLfhquzxdlgVONStPAy(urllib.parse.parse_qsl(icKwYGUBWnkoLfhquzxdlgVONStPMT))
     icKwYGUBWnkoLfhquzxdlgVONStPMC=icKwYGUBWnkoLfhquzxdlgVONStPMX.get('code').strip()
     if icKwYGUBWnkoLfhquzxdlgVONStPMj!=icKwYGUBWnkoLfhquzxdlgVONStPMC:
      fp.write(icKwYGUBWnkoLfhquzxdlgVONStPMT)
    fp.close()
   except:
    icKwYGUBWnkoLfhquzxdlgVONStPAb
  xbmc.executebuiltin("Container.Refresh")
 def Save_Searched_List(icKwYGUBWnkoLfhquzxdlgVONStPsp,icKwYGUBWnkoLfhquzxdlgVONStPQC):
  try:
   icKwYGUBWnkoLfhquzxdlgVONStPbs=icKwYGUBWnkoLfhquzxdlgVONStPsA
   icKwYGUBWnkoLfhquzxdlgVONStPMe=icKwYGUBWnkoLfhquzxdlgVONStPsp.Load_List_File('search') 
   icKwYGUBWnkoLfhquzxdlgVONStPbQ={'skey':icKwYGUBWnkoLfhquzxdlgVONStPQC.strip()}
   fp=icKwYGUBWnkoLfhquzxdlgVONStPAr(icKwYGUBWnkoLfhquzxdlgVONStPbs,'w',-1,'utf-8')
   icKwYGUBWnkoLfhquzxdlgVONStPMI=urllib.parse.urlencode(icKwYGUBWnkoLfhquzxdlgVONStPbQ)
   icKwYGUBWnkoLfhquzxdlgVONStPMI=icKwYGUBWnkoLfhquzxdlgVONStPMI+'\n'
   fp.write(icKwYGUBWnkoLfhquzxdlgVONStPMI)
   icKwYGUBWnkoLfhquzxdlgVONStPME=0
   for icKwYGUBWnkoLfhquzxdlgVONStPMT in icKwYGUBWnkoLfhquzxdlgVONStPMe:
    icKwYGUBWnkoLfhquzxdlgVONStPMX=icKwYGUBWnkoLfhquzxdlgVONStPAy(urllib.parse.parse_qsl(icKwYGUBWnkoLfhquzxdlgVONStPMT))
    icKwYGUBWnkoLfhquzxdlgVONStPMr=icKwYGUBWnkoLfhquzxdlgVONStPbQ.get('skey').strip()
    icKwYGUBWnkoLfhquzxdlgVONStPMH=icKwYGUBWnkoLfhquzxdlgVONStPMX.get('skey').strip()
    if icKwYGUBWnkoLfhquzxdlgVONStPMr!=icKwYGUBWnkoLfhquzxdlgVONStPMH:
     fp.write(icKwYGUBWnkoLfhquzxdlgVONStPMT)
     icKwYGUBWnkoLfhquzxdlgVONStPME+=1
     if icKwYGUBWnkoLfhquzxdlgVONStPME>=50:break
   fp.close()
  except:
   icKwYGUBWnkoLfhquzxdlgVONStPAb
 def dp_Global_Search(icKwYGUBWnkoLfhquzxdlgVONStPsp,args):
  icKwYGUBWnkoLfhquzxdlgVONStPaQ=args.get('mode')
  if icKwYGUBWnkoLfhquzxdlgVONStPaQ=='TOTAL_SEARCH':
   icKwYGUBWnkoLfhquzxdlgVONStPba='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   icKwYGUBWnkoLfhquzxdlgVONStPba='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(icKwYGUBWnkoLfhquzxdlgVONStPba)
 def dp_Bookmark_Menu(icKwYGUBWnkoLfhquzxdlgVONStPsp,args):
  icKwYGUBWnkoLfhquzxdlgVONStPba='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(icKwYGUBWnkoLfhquzxdlgVONStPba)
 def login_main(icKwYGUBWnkoLfhquzxdlgVONStPsp):
  (icKwYGUBWnkoLfhquzxdlgVONStPbM,icKwYGUBWnkoLfhquzxdlgVONStPbv,icKwYGUBWnkoLfhquzxdlgVONStPbR)=icKwYGUBWnkoLfhquzxdlgVONStPsp.get_settings_account()
  if not(icKwYGUBWnkoLfhquzxdlgVONStPbM and icKwYGUBWnkoLfhquzxdlgVONStPbv):
   icKwYGUBWnkoLfhquzxdlgVONStPsE=xbmcgui.Dialog()
   icKwYGUBWnkoLfhquzxdlgVONStPMF=icKwYGUBWnkoLfhquzxdlgVONStPsE.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if icKwYGUBWnkoLfhquzxdlgVONStPMF==icKwYGUBWnkoLfhquzxdlgVONStPAR:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if icKwYGUBWnkoLfhquzxdlgVONStPsp.cookiefile_check()==icKwYGUBWnkoLfhquzxdlgVONStPAR:return
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   icKwYGUBWnkoLfhquzxdlgVONStPbA=0
   while icKwYGUBWnkoLfhquzxdlgVONStPAR:
    icKwYGUBWnkoLfhquzxdlgVONStPbA+=1
    time.sleep(0.05)
    if icKwYGUBWnkoLfhquzxdlgVONStPbA>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  icKwYGUBWnkoLfhquzxdlgVONStPbp=icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.GetCredential(icKwYGUBWnkoLfhquzxdlgVONStPbM,icKwYGUBWnkoLfhquzxdlgVONStPbv,icKwYGUBWnkoLfhquzxdlgVONStPbR)
  if icKwYGUBWnkoLfhquzxdlgVONStPbp:icKwYGUBWnkoLfhquzxdlgVONStPsp.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
  if icKwYGUBWnkoLfhquzxdlgVONStPbp==icKwYGUBWnkoLfhquzxdlgVONStPAp:
   icKwYGUBWnkoLfhquzxdlgVONStPsp.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_setEpOrderby(icKwYGUBWnkoLfhquzxdlgVONStPsp,args):
  icKwYGUBWnkoLfhquzxdlgVONStPQp =args.get('orderby')
  icKwYGUBWnkoLfhquzxdlgVONStPsp.set_winEpisodeOrderby(icKwYGUBWnkoLfhquzxdlgVONStPQp)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(icKwYGUBWnkoLfhquzxdlgVONStPsp,args):
  icKwYGUBWnkoLfhquzxdlgVONStPaQ =args.get('mode')
  icKwYGUBWnkoLfhquzxdlgVONStPbD =args.get('contentid')
  icKwYGUBWnkoLfhquzxdlgVONStPby =args.get('pvrmode')
  icKwYGUBWnkoLfhquzxdlgVONStPbe=icKwYGUBWnkoLfhquzxdlgVONStPsp.get_selQuality()
  icKwYGUBWnkoLfhquzxdlgVONStPQM =icKwYGUBWnkoLfhquzxdlgVONStPsp.get_settings_play()
  icKwYGUBWnkoLfhquzxdlgVONStPsp.addon_log(icKwYGUBWnkoLfhquzxdlgVONStPbD+' - '+icKwYGUBWnkoLfhquzxdlgVONStPaQ)
  if icKwYGUBWnkoLfhquzxdlgVONStPaQ=='SPORTS':
   icKwYGUBWnkoLfhquzxdlgVONStPbI=icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.GetSportsURL(icKwYGUBWnkoLfhquzxdlgVONStPbD,icKwYGUBWnkoLfhquzxdlgVONStPbe)
  else:
   icKwYGUBWnkoLfhquzxdlgVONStPbI=icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.GetStreamingURL(icKwYGUBWnkoLfhquzxdlgVONStPaQ,icKwYGUBWnkoLfhquzxdlgVONStPbD,icKwYGUBWnkoLfhquzxdlgVONStPbe,icKwYGUBWnkoLfhquzxdlgVONStPby,playOption=icKwYGUBWnkoLfhquzxdlgVONStPQM)
  icKwYGUBWnkoLfhquzxdlgVONStPbE=icKwYGUBWnkoLfhquzxdlgVONStPbI['stream_cookie']
  icKwYGUBWnkoLfhquzxdlgVONStPbT='{}|Cookie={}'.format(icKwYGUBWnkoLfhquzxdlgVONStPbI['stream_url'],icKwYGUBWnkoLfhquzxdlgVONStPbE)
  icKwYGUBWnkoLfhquzxdlgVONStPsp.addon_log(icKwYGUBWnkoLfhquzxdlgVONStPbT)
  if icKwYGUBWnkoLfhquzxdlgVONStPbI['stream_url']=='':
   icKwYGUBWnkoLfhquzxdlgVONStPsp.addon_noti(__language__(30907).encode('utf8'))
   return
  icKwYGUBWnkoLfhquzxdlgVONStPbX=xbmcgui.ListItem(path=icKwYGUBWnkoLfhquzxdlgVONStPbT)
  if icKwYGUBWnkoLfhquzxdlgVONStPbI['stream_drm']:
   icKwYGUBWnkoLfhquzxdlgVONStPsp.addon_log('!!streaming_drm!!')
   icKwYGUBWnkoLfhquzxdlgVONStPbr=icKwYGUBWnkoLfhquzxdlgVONStPbI['stream_drm']['customdata']
   icKwYGUBWnkoLfhquzxdlgVONStPbH =icKwYGUBWnkoLfhquzxdlgVONStPbI['stream_drm']['drmhost']
   icKwYGUBWnkoLfhquzxdlgVONStPbJ =inputstreamhelper.Helper('mpd',drm='widevine')
   if icKwYGUBWnkoLfhquzxdlgVONStPbJ.check_inputstream():
    if icKwYGUBWnkoLfhquzxdlgVONStPaQ=='MOVIE':
     icKwYGUBWnkoLfhquzxdlgVONStPbj='https://www.wavve.com/player/movie?movieid=%s'%icKwYGUBWnkoLfhquzxdlgVONStPbD
    else:
     icKwYGUBWnkoLfhquzxdlgVONStPbj='https://www.wavve.com/player/vod?programid=%s&page=1'%icKwYGUBWnkoLfhquzxdlgVONStPbD
    icKwYGUBWnkoLfhquzxdlgVONStPbm={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':icKwYGUBWnkoLfhquzxdlgVONStPbr,'referer':icKwYGUBWnkoLfhquzxdlgVONStPbj,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.USER_AGENT,}
    icKwYGUBWnkoLfhquzxdlgVONStPbF=icKwYGUBWnkoLfhquzxdlgVONStPbH+'|'+urllib.parse.urlencode(icKwYGUBWnkoLfhquzxdlgVONStPbm)+'|R{SSM}|'
    icKwYGUBWnkoLfhquzxdlgVONStPbX.setProperty('inputstream',icKwYGUBWnkoLfhquzxdlgVONStPbJ.inputstream_addon)
    icKwYGUBWnkoLfhquzxdlgVONStPbX.setProperty('inputstream.adaptive.manifest_type','mpd')
    icKwYGUBWnkoLfhquzxdlgVONStPbX.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    icKwYGUBWnkoLfhquzxdlgVONStPbX.setProperty('inputstream.adaptive.license_key',icKwYGUBWnkoLfhquzxdlgVONStPbF)
    icKwYGUBWnkoLfhquzxdlgVONStPbX.setProperty('inputstream.adaptive.stream_headers','user-agent={}&Cookie={}'.format(icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.USER_AGENT,icKwYGUBWnkoLfhquzxdlgVONStPbE))
  elif icKwYGUBWnkoLfhquzxdlgVONStPaQ in['VOD','MOVIE']:
   icKwYGUBWnkoLfhquzxdlgVONStPbX.setContentLookup(icKwYGUBWnkoLfhquzxdlgVONStPAp)
   icKwYGUBWnkoLfhquzxdlgVONStPbX.setMimeType('application/x-mpegURL')
   icKwYGUBWnkoLfhquzxdlgVONStPbX.setProperty('inputstream','inputstream.adaptive')
   if icKwYGUBWnkoLfhquzxdlgVONStPbI['stream_action']=='hls':
    icKwYGUBWnkoLfhquzxdlgVONStPbX.setProperty('inputstream.adaptive.manifest_type','hls')
   else:
    icKwYGUBWnkoLfhquzxdlgVONStPbX.setProperty('inputstream.adaptive.manifest_type','mpd')
   icKwYGUBWnkoLfhquzxdlgVONStPbX.setProperty('inputstream.adaptive.stream_headers','user-agent={}&Cookie={}'.format(icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.USER_AGENT,icKwYGUBWnkoLfhquzxdlgVONStPbE))
  if icKwYGUBWnkoLfhquzxdlgVONStPbI['stream_vtt']:
   icKwYGUBWnkoLfhquzxdlgVONStPbX.setSubtitles([icKwYGUBWnkoLfhquzxdlgVONStPbI['stream_vtt']])
  xbmcplugin.setResolvedUrl(icKwYGUBWnkoLfhquzxdlgVONStPsp._addon_handle,icKwYGUBWnkoLfhquzxdlgVONStPAR,icKwYGUBWnkoLfhquzxdlgVONStPbX)
  icKwYGUBWnkoLfhquzxdlgVONStPbC=icKwYGUBWnkoLfhquzxdlgVONStPAp
  if icKwYGUBWnkoLfhquzxdlgVONStPbI['stream_preview']:
   icKwYGUBWnkoLfhquzxdlgVONStPsp.addon_noti(icKwYGUBWnkoLfhquzxdlgVONStPbI['stream_preview'].encode('utf-8'))
   icKwYGUBWnkoLfhquzxdlgVONStPbC=icKwYGUBWnkoLfhquzxdlgVONStPAR
  else:
   if '/preview.' in urllib.parse.urlsplit(icKwYGUBWnkoLfhquzxdlgVONStPbI['stream_url']).path:
    icKwYGUBWnkoLfhquzxdlgVONStPsp.addon_noti(__language__(30908).encode('utf8'))
    icKwYGUBWnkoLfhquzxdlgVONStPbC=icKwYGUBWnkoLfhquzxdlgVONStPAR
  try:
   icKwYGUBWnkoLfhquzxdlgVONStPvs=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and icKwYGUBWnkoLfhquzxdlgVONStPbC==icKwYGUBWnkoLfhquzxdlgVONStPAp and icKwYGUBWnkoLfhquzxdlgVONStPvs!='-':
    icKwYGUBWnkoLfhquzxdlgVONStPQr={'code':icKwYGUBWnkoLfhquzxdlgVONStPvs,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    icKwYGUBWnkoLfhquzxdlgVONStPsp.Save_Watched_List(args.get('mode').lower(),icKwYGUBWnkoLfhquzxdlgVONStPQr)
  except:
   icKwYGUBWnkoLfhquzxdlgVONStPAb
 def logout(icKwYGUBWnkoLfhquzxdlgVONStPsp):
  icKwYGUBWnkoLfhquzxdlgVONStPsE=xbmcgui.Dialog()
  icKwYGUBWnkoLfhquzxdlgVONStPMF=icKwYGUBWnkoLfhquzxdlgVONStPsE.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if icKwYGUBWnkoLfhquzxdlgVONStPMF==icKwYGUBWnkoLfhquzxdlgVONStPAp:sys.exit()
  icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.Init_WV_Total()
  if os.path.isfile(icKwYGUBWnkoLfhquzxdlgVONStPsR):os.remove(icKwYGUBWnkoLfhquzxdlgVONStPsR)
  icKwYGUBWnkoLfhquzxdlgVONStPsp.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(icKwYGUBWnkoLfhquzxdlgVONStPsp):
  icKwYGUBWnkoLfhquzxdlgVONStPvQ =icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.Get_Now_Datetime()
  icKwYGUBWnkoLfhquzxdlgVONStPva=icKwYGUBWnkoLfhquzxdlgVONStPvQ+datetime.timedelta(days=icKwYGUBWnkoLfhquzxdlgVONStPAv(__addon__.getSetting('cache_ttl')))
  (icKwYGUBWnkoLfhquzxdlgVONStPbM,icKwYGUBWnkoLfhquzxdlgVONStPbv,icKwYGUBWnkoLfhquzxdlgVONStPbR)=icKwYGUBWnkoLfhquzxdlgVONStPsp.get_settings_account()
  icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.Save_session_acount(icKwYGUBWnkoLfhquzxdlgVONStPbM,icKwYGUBWnkoLfhquzxdlgVONStPbv,icKwYGUBWnkoLfhquzxdlgVONStPbR)
  icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.WV['account']['token_limit']=icKwYGUBWnkoLfhquzxdlgVONStPva.strftime('%Y%m%d')
  icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.JsonFile_Save(icKwYGUBWnkoLfhquzxdlgVONStPsR,icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.WV)
 def cookiefile_check(icKwYGUBWnkoLfhquzxdlgVONStPsp):
  icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.WV=icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.JsonFile_Load(icKwYGUBWnkoLfhquzxdlgVONStPsR)
  if 'account' not in icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.WV:
   icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.Init_WV_Total()
   return icKwYGUBWnkoLfhquzxdlgVONStPAp
  if 'uuid' not in icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.WV.get('cookies'):
   icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.Init_WV_Total()
   return icKwYGUBWnkoLfhquzxdlgVONStPAp
  (icKwYGUBWnkoLfhquzxdlgVONStPvM,icKwYGUBWnkoLfhquzxdlgVONStPvb,icKwYGUBWnkoLfhquzxdlgVONStPvR)=icKwYGUBWnkoLfhquzxdlgVONStPsp.get_settings_account()
  (icKwYGUBWnkoLfhquzxdlgVONStPvA,icKwYGUBWnkoLfhquzxdlgVONStPvp,icKwYGUBWnkoLfhquzxdlgVONStPvD)=icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.Load_session_acount()
  if icKwYGUBWnkoLfhquzxdlgVONStPvM!=icKwYGUBWnkoLfhquzxdlgVONStPvA or icKwYGUBWnkoLfhquzxdlgVONStPvb!=icKwYGUBWnkoLfhquzxdlgVONStPvp or icKwYGUBWnkoLfhquzxdlgVONStPvR!=icKwYGUBWnkoLfhquzxdlgVONStPvD:
   icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.Init_WV_Total()
   return icKwYGUBWnkoLfhquzxdlgVONStPAp
  if icKwYGUBWnkoLfhquzxdlgVONStPAv(icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))>icKwYGUBWnkoLfhquzxdlgVONStPAv(icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.WV['account']['token_limit']):
   icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.Init_WV_Total()
   return icKwYGUBWnkoLfhquzxdlgVONStPAp
  return icKwYGUBWnkoLfhquzxdlgVONStPAR
 def dp_LiveCatagory_List(icKwYGUBWnkoLfhquzxdlgVONStPsp,args):
  icKwYGUBWnkoLfhquzxdlgVONStPvy =args.get('sCode')
  icKwYGUBWnkoLfhquzxdlgVONStPve=args.get('sIndex')
  icKwYGUBWnkoLfhquzxdlgVONStPaJ,icKwYGUBWnkoLfhquzxdlgVONStPvI=icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.Get_LiveCatagory_List(icKwYGUBWnkoLfhquzxdlgVONStPvy,icKwYGUBWnkoLfhquzxdlgVONStPve)
  for icKwYGUBWnkoLfhquzxdlgVONStPaj in icKwYGUBWnkoLfhquzxdlgVONStPaJ:
   icKwYGUBWnkoLfhquzxdlgVONStPQy =icKwYGUBWnkoLfhquzxdlgVONStPaj.get('title')
   icKwYGUBWnkoLfhquzxdlgVONStPQr={'mode':'LIVE_LIST','genre':icKwYGUBWnkoLfhquzxdlgVONStPaj.get('genre'),'baseapi':icKwYGUBWnkoLfhquzxdlgVONStPvI}
   icKwYGUBWnkoLfhquzxdlgVONStPQj={'title':icKwYGUBWnkoLfhquzxdlgVONStPQy,'plot':icKwYGUBWnkoLfhquzxdlgVONStPQy}
   icKwYGUBWnkoLfhquzxdlgVONStPsp.add_dir(icKwYGUBWnkoLfhquzxdlgVONStPQy,sublabel='',img='',infoLabels=icKwYGUBWnkoLfhquzxdlgVONStPQj,isFolder=icKwYGUBWnkoLfhquzxdlgVONStPAR,params=icKwYGUBWnkoLfhquzxdlgVONStPQr)
  if icKwYGUBWnkoLfhquzxdlgVONStPAE(icKwYGUBWnkoLfhquzxdlgVONStPaJ)>0:xbmcplugin.endOfDirectory(icKwYGUBWnkoLfhquzxdlgVONStPsp._addon_handle,cacheToDisc=icKwYGUBWnkoLfhquzxdlgVONStPAp)
 def dp_MainCatagory_List(icKwYGUBWnkoLfhquzxdlgVONStPsp,args):
  icKwYGUBWnkoLfhquzxdlgVONStPvy =args.get('sCode')
  icKwYGUBWnkoLfhquzxdlgVONStPve=args.get('sIndex')
  icKwYGUBWnkoLfhquzxdlgVONStPaM =args.get('sType')
  icKwYGUBWnkoLfhquzxdlgVONStPaJ=icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.Get_MainCatagory_List(icKwYGUBWnkoLfhquzxdlgVONStPvy,icKwYGUBWnkoLfhquzxdlgVONStPve,icKwYGUBWnkoLfhquzxdlgVONStPaM)
  for icKwYGUBWnkoLfhquzxdlgVONStPaj in icKwYGUBWnkoLfhquzxdlgVONStPaJ:
   if icKwYGUBWnkoLfhquzxdlgVONStPaM in['vod','vod09']:
    if icKwYGUBWnkoLfhquzxdlgVONStPaj.get('subtype')=='catagory':
     icKwYGUBWnkoLfhquzxdlgVONStPaQ='PROGRAM_LIST'
    else:
     icKwYGUBWnkoLfhquzxdlgVONStPaQ='SUPERSECTION_LIST'
   elif icKwYGUBWnkoLfhquzxdlgVONStPaM=='movie':
    icKwYGUBWnkoLfhquzxdlgVONStPaQ='MOVIE_LIST'
   else:
    icKwYGUBWnkoLfhquzxdlgVONStPaQ=''
   icKwYGUBWnkoLfhquzxdlgVONStPQy='%s (%s)'%(icKwYGUBWnkoLfhquzxdlgVONStPaj.get('title'),args.get('ordernm'))
   icKwYGUBWnkoLfhquzxdlgVONStPQr={'mode':icKwYGUBWnkoLfhquzxdlgVONStPaQ,'suburl':icKwYGUBWnkoLfhquzxdlgVONStPaj.get('suburl'),'subapi':icKwYGUBWnkoLfhquzxdlgVONStPaj.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if icKwYGUBWnkoLfhquzxdlgVONStPsp.get_settings_exclusion21():
    if icKwYGUBWnkoLfhquzxdlgVONStPaj.get('title')=='성인' or icKwYGUBWnkoLfhquzxdlgVONStPaj.get('title')=='성인+' or icKwYGUBWnkoLfhquzxdlgVONStPaj.get('title')=='에로티시즘' or icKwYGUBWnkoLfhquzxdlgVONStPaj.get('title')=='19':continue
   icKwYGUBWnkoLfhquzxdlgVONStPQj={'title':icKwYGUBWnkoLfhquzxdlgVONStPQy,'plot':icKwYGUBWnkoLfhquzxdlgVONStPQy}
   icKwYGUBWnkoLfhquzxdlgVONStPsp.add_dir(icKwYGUBWnkoLfhquzxdlgVONStPQy,sublabel='',img='',infoLabels=icKwYGUBWnkoLfhquzxdlgVONStPQj,isFolder=icKwYGUBWnkoLfhquzxdlgVONStPAR,params=icKwYGUBWnkoLfhquzxdlgVONStPQr)
  if icKwYGUBWnkoLfhquzxdlgVONStPAE(icKwYGUBWnkoLfhquzxdlgVONStPaJ)>0:xbmcplugin.endOfDirectory(icKwYGUBWnkoLfhquzxdlgVONStPsp._addon_handle,cacheToDisc=icKwYGUBWnkoLfhquzxdlgVONStPAp)
 def dp_Program_List(icKwYGUBWnkoLfhquzxdlgVONStPsp,args):
  icKwYGUBWnkoLfhquzxdlgVONStPvE =args.get('subapi')
  icKwYGUBWnkoLfhquzxdlgVONStPaH=icKwYGUBWnkoLfhquzxdlgVONStPAv(args.get('page'))
  icKwYGUBWnkoLfhquzxdlgVONStPQp =args.get('orderby')
  icKwYGUBWnkoLfhquzxdlgVONStPsp.addon_log('dp_Program_List')
  icKwYGUBWnkoLfhquzxdlgVONStPsp.addon_log(icKwYGUBWnkoLfhquzxdlgVONStPvE)
  icKwYGUBWnkoLfhquzxdlgVONStPaJ,icKwYGUBWnkoLfhquzxdlgVONStPav=icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.Get_Program_List(icKwYGUBWnkoLfhquzxdlgVONStPvE,icKwYGUBWnkoLfhquzxdlgVONStPaH,icKwYGUBWnkoLfhquzxdlgVONStPQp)
  for icKwYGUBWnkoLfhquzxdlgVONStPaj in icKwYGUBWnkoLfhquzxdlgVONStPaJ:
   icKwYGUBWnkoLfhquzxdlgVONStPam =icKwYGUBWnkoLfhquzxdlgVONStPaj.get('videoid')
   icKwYGUBWnkoLfhquzxdlgVONStPaF =icKwYGUBWnkoLfhquzxdlgVONStPaj.get('vidtype')
   icKwYGUBWnkoLfhquzxdlgVONStPQy =icKwYGUBWnkoLfhquzxdlgVONStPaj.get('title')
   icKwYGUBWnkoLfhquzxdlgVONStPaC=icKwYGUBWnkoLfhquzxdlgVONStPaj.get('thumbnail')
   icKwYGUBWnkoLfhquzxdlgVONStPMs =icKwYGUBWnkoLfhquzxdlgVONStPaj.get('age')
   if icKwYGUBWnkoLfhquzxdlgVONStPMs=='18' or icKwYGUBWnkoLfhquzxdlgVONStPMs=='19' or icKwYGUBWnkoLfhquzxdlgVONStPMs=='21':icKwYGUBWnkoLfhquzxdlgVONStPQy+=' (%s)'%(icKwYGUBWnkoLfhquzxdlgVONStPMs)
   icKwYGUBWnkoLfhquzxdlgVONStPQj={'plot':icKwYGUBWnkoLfhquzxdlgVONStPQy,'mpaa':icKwYGUBWnkoLfhquzxdlgVONStPMs,'mediatype':'tvshow','title':icKwYGUBWnkoLfhquzxdlgVONStPQy,}
   icKwYGUBWnkoLfhquzxdlgVONStPQr={'mode':'SEASON_LIST','videoid':icKwYGUBWnkoLfhquzxdlgVONStPam,'vidtype':icKwYGUBWnkoLfhquzxdlgVONStPaF,}
   icKwYGUBWnkoLfhquzxdlgVONStPaX=[]
   icKwYGUBWnkoLfhquzxdlgVONStPMQ={'mode':'VIEW_DETAIL','values':{'videoid':icKwYGUBWnkoLfhquzxdlgVONStPam,'vidtype':'tvshow','contenttype':icKwYGUBWnkoLfhquzxdlgVONStPaF,}}
   icKwYGUBWnkoLfhquzxdlgVONStPMa=json.dumps(icKwYGUBWnkoLfhquzxdlgVONStPMQ,separators=(',',':'))
   icKwYGUBWnkoLfhquzxdlgVONStPMa=base64.standard_b64encode(icKwYGUBWnkoLfhquzxdlgVONStPMa.encode()).decode('utf-8')
   icKwYGUBWnkoLfhquzxdlgVONStPMa=icKwYGUBWnkoLfhquzxdlgVONStPMa.replace('+','%2B')
   icKwYGUBWnkoLfhquzxdlgVONStPMb='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(icKwYGUBWnkoLfhquzxdlgVONStPMa)
   icKwYGUBWnkoLfhquzxdlgVONStPaX.append(('상세정보 조회',icKwYGUBWnkoLfhquzxdlgVONStPMb))
   if icKwYGUBWnkoLfhquzxdlgVONStPsp.get_settings_makebookmark():
    icKwYGUBWnkoLfhquzxdlgVONStPMQ={'videoid':icKwYGUBWnkoLfhquzxdlgVONStPam,'vidtype':'tvshow','vtitle':icKwYGUBWnkoLfhquzxdlgVONStPQy,'vsubtitle':'','contenttype':icKwYGUBWnkoLfhquzxdlgVONStPaF,}
    icKwYGUBWnkoLfhquzxdlgVONStPMv=json.dumps(icKwYGUBWnkoLfhquzxdlgVONStPMQ)
    icKwYGUBWnkoLfhquzxdlgVONStPMv=urllib.parse.quote(icKwYGUBWnkoLfhquzxdlgVONStPMv)
    icKwYGUBWnkoLfhquzxdlgVONStPMb='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(icKwYGUBWnkoLfhquzxdlgVONStPMv)
    icKwYGUBWnkoLfhquzxdlgVONStPaX.append(('(통합) 찜 영상에 추가',icKwYGUBWnkoLfhquzxdlgVONStPMb))
   icKwYGUBWnkoLfhquzxdlgVONStPsp.add_dir(icKwYGUBWnkoLfhquzxdlgVONStPQy,sublabel='',img=icKwYGUBWnkoLfhquzxdlgVONStPaC,infoLabels=icKwYGUBWnkoLfhquzxdlgVONStPQj,isFolder=icKwYGUBWnkoLfhquzxdlgVONStPAR,params=icKwYGUBWnkoLfhquzxdlgVONStPQr,ContextMenu=icKwYGUBWnkoLfhquzxdlgVONStPaX)
  if icKwYGUBWnkoLfhquzxdlgVONStPav:
   icKwYGUBWnkoLfhquzxdlgVONStPQr={}
   icKwYGUBWnkoLfhquzxdlgVONStPQr['mode'] ='PROGRAM_LIST' 
   icKwYGUBWnkoLfhquzxdlgVONStPQr['subapi']=icKwYGUBWnkoLfhquzxdlgVONStPvE 
   icKwYGUBWnkoLfhquzxdlgVONStPQr['page'] =icKwYGUBWnkoLfhquzxdlgVONStPAX(icKwYGUBWnkoLfhquzxdlgVONStPaH+1)
   icKwYGUBWnkoLfhquzxdlgVONStPQy='[B]%s >>[/B]'%'다음 페이지'
   icKwYGUBWnkoLfhquzxdlgVONStPMR=icKwYGUBWnkoLfhquzxdlgVONStPAX(icKwYGUBWnkoLfhquzxdlgVONStPaH+1)
   icKwYGUBWnkoLfhquzxdlgVONStPQX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   icKwYGUBWnkoLfhquzxdlgVONStPsp.add_dir(icKwYGUBWnkoLfhquzxdlgVONStPQy,sublabel=icKwYGUBWnkoLfhquzxdlgVONStPMR,img=icKwYGUBWnkoLfhquzxdlgVONStPQX,infoLabels=icKwYGUBWnkoLfhquzxdlgVONStPAb,isFolder=icKwYGUBWnkoLfhquzxdlgVONStPAR,params=icKwYGUBWnkoLfhquzxdlgVONStPQr)
  xbmcplugin.setContent(icKwYGUBWnkoLfhquzxdlgVONStPsp._addon_handle,'tvshows')
  if icKwYGUBWnkoLfhquzxdlgVONStPAE(icKwYGUBWnkoLfhquzxdlgVONStPaJ)>0:xbmcplugin.endOfDirectory(icKwYGUBWnkoLfhquzxdlgVONStPsp._addon_handle,cacheToDisc=icKwYGUBWnkoLfhquzxdlgVONStPAp)
 def dp_Season_List(icKwYGUBWnkoLfhquzxdlgVONStPsp,args):
  icKwYGUBWnkoLfhquzxdlgVONStPam=args.get('videoid')
  icKwYGUBWnkoLfhquzxdlgVONStPaF=args.get('vidtype')
  if icKwYGUBWnkoLfhquzxdlgVONStPaF=='contentid':
   icKwYGUBWnkoLfhquzxdlgVONStPbD=icKwYGUBWnkoLfhquzxdlgVONStPam
   icKwYGUBWnkoLfhquzxdlgVONStPvT =icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.ContentidToSeasonid(icKwYGUBWnkoLfhquzxdlgVONStPam)
  else:
   icKwYGUBWnkoLfhquzxdlgVONStPbD=icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.ProgramidToContentid(icKwYGUBWnkoLfhquzxdlgVONStPam)
   icKwYGUBWnkoLfhquzxdlgVONStPvT =icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.ContentidToSeasonid(icKwYGUBWnkoLfhquzxdlgVONStPbD)
  icKwYGUBWnkoLfhquzxdlgVONStPvX=icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.Get_Season_List(icKwYGUBWnkoLfhquzxdlgVONStPvT)
  if icKwYGUBWnkoLfhquzxdlgVONStPAE(icKwYGUBWnkoLfhquzxdlgVONStPvX)>1:
   for icKwYGUBWnkoLfhquzxdlgVONStPvr in icKwYGUBWnkoLfhquzxdlgVONStPvX:
    icKwYGUBWnkoLfhquzxdlgVONStPvH=icKwYGUBWnkoLfhquzxdlgVONStPvr.get('season_Id')
    icKwYGUBWnkoLfhquzxdlgVONStPvJ=icKwYGUBWnkoLfhquzxdlgVONStPvr.get('season_Nm')
    icKwYGUBWnkoLfhquzxdlgVONStPvj=icKwYGUBWnkoLfhquzxdlgVONStPvr.get('programNm')
    icKwYGUBWnkoLfhquzxdlgVONStPaC=icKwYGUBWnkoLfhquzxdlgVONStPvr.get('thumbnail')
    icKwYGUBWnkoLfhquzxdlgVONStPvm =icKwYGUBWnkoLfhquzxdlgVONStPvr.get('synopsis')
    icKwYGUBWnkoLfhquzxdlgVONStPar={'mediatype':'tvshow','title':icKwYGUBWnkoLfhquzxdlgVONStPvJ,'plot':icKwYGUBWnkoLfhquzxdlgVONStPvm,}
    icKwYGUBWnkoLfhquzxdlgVONStPQr={'mode':'EPISODE_LIST','seasonid':icKwYGUBWnkoLfhquzxdlgVONStPvH,'page':'1',}
    icKwYGUBWnkoLfhquzxdlgVONStPsp.add_dir(icKwYGUBWnkoLfhquzxdlgVONStPvJ,sublabel=icKwYGUBWnkoLfhquzxdlgVONStPvj,img=icKwYGUBWnkoLfhquzxdlgVONStPaC,infoLabels=icKwYGUBWnkoLfhquzxdlgVONStPar,isFolder=icKwYGUBWnkoLfhquzxdlgVONStPAR,params=icKwYGUBWnkoLfhquzxdlgVONStPQr,ContextMenu=icKwYGUBWnkoLfhquzxdlgVONStPAb)
   xbmcplugin.setContent(icKwYGUBWnkoLfhquzxdlgVONStPsp._addon_handle,'seasons')
   xbmcplugin.endOfDirectory(icKwYGUBWnkoLfhquzxdlgVONStPsp._addon_handle,cacheToDisc=icKwYGUBWnkoLfhquzxdlgVONStPAp)
  else:
   icKwYGUBWnkoLfhquzxdlgVONStPvF={'seasonid':icKwYGUBWnkoLfhquzxdlgVONStPvT,'page':'1',}
   icKwYGUBWnkoLfhquzxdlgVONStPsp.dp_Episode_List(icKwYGUBWnkoLfhquzxdlgVONStPvF)
 def dp_Episode_List(icKwYGUBWnkoLfhquzxdlgVONStPsp,args):
  icKwYGUBWnkoLfhquzxdlgVONStPvT =args.get('seasonid')
  icKwYGUBWnkoLfhquzxdlgVONStPaH =icKwYGUBWnkoLfhquzxdlgVONStPAv(args.get('page'))
  icKwYGUBWnkoLfhquzxdlgVONStPaJ,icKwYGUBWnkoLfhquzxdlgVONStPav=icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.Get_Episode_List(icKwYGUBWnkoLfhquzxdlgVONStPvT,icKwYGUBWnkoLfhquzxdlgVONStPaH,orderby=icKwYGUBWnkoLfhquzxdlgVONStPsp.get_winEpisodeOrderby())
  for icKwYGUBWnkoLfhquzxdlgVONStPaj in icKwYGUBWnkoLfhquzxdlgVONStPaJ:
   icKwYGUBWnkoLfhquzxdlgVONStPMR=icKwYGUBWnkoLfhquzxdlgVONStPaj.get('episodenumber')
   icKwYGUBWnkoLfhquzxdlgVONStPvC ='[%s]\n\n%s'%(icKwYGUBWnkoLfhquzxdlgVONStPaj.get('episodetitle'),icKwYGUBWnkoLfhquzxdlgVONStPaj.get('synopsis'))
   icKwYGUBWnkoLfhquzxdlgVONStPar={'mediatype':'episode','title':icKwYGUBWnkoLfhquzxdlgVONStPaj.get('programtitle'),'plot':icKwYGUBWnkoLfhquzxdlgVONStPvC,'cast':icKwYGUBWnkoLfhquzxdlgVONStPaj.get('episodeactors'),}
   icKwYGUBWnkoLfhquzxdlgVONStPQr={'mode':'VOD','programid':icKwYGUBWnkoLfhquzxdlgVONStPvT,'contentid':icKwYGUBWnkoLfhquzxdlgVONStPaj.get('contentid'),'thumbnail':icKwYGUBWnkoLfhquzxdlgVONStPaj.get('thumbnail'),'title':icKwYGUBWnkoLfhquzxdlgVONStPaj.get('programtitle'),'subtitle':icKwYGUBWnkoLfhquzxdlgVONStPMR,}
   icKwYGUBWnkoLfhquzxdlgVONStPsp.add_dir(icKwYGUBWnkoLfhquzxdlgVONStPaj.get('programtitle'),sublabel=icKwYGUBWnkoLfhquzxdlgVONStPMR,img=icKwYGUBWnkoLfhquzxdlgVONStPaj.get('thumbnail'),infoLabels=icKwYGUBWnkoLfhquzxdlgVONStPar,isFolder=icKwYGUBWnkoLfhquzxdlgVONStPAp,params=icKwYGUBWnkoLfhquzxdlgVONStPQr)
  if icKwYGUBWnkoLfhquzxdlgVONStPaH==1:
   icKwYGUBWnkoLfhquzxdlgVONStPar={'plot':'정렬순서를 변경합니다.'}
   icKwYGUBWnkoLfhquzxdlgVONStPQr={}
   icKwYGUBWnkoLfhquzxdlgVONStPQr['mode'] ='ORDER_BY' 
   if icKwYGUBWnkoLfhquzxdlgVONStPsp.get_winEpisodeOrderby()=='desc':
    icKwYGUBWnkoLfhquzxdlgVONStPQy='정렬순서변경 : 최신화부터 -> 1회부터'
    icKwYGUBWnkoLfhquzxdlgVONStPQr['orderby']='asc'
   else:
    icKwYGUBWnkoLfhquzxdlgVONStPQy='정렬순서변경 : 1회부터 -> 최신화부터'
    icKwYGUBWnkoLfhquzxdlgVONStPQr['orderby']='desc'
   icKwYGUBWnkoLfhquzxdlgVONStPQX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   icKwYGUBWnkoLfhquzxdlgVONStPsp.add_dir(icKwYGUBWnkoLfhquzxdlgVONStPQy,sublabel='',img=icKwYGUBWnkoLfhquzxdlgVONStPQX,infoLabels=icKwYGUBWnkoLfhquzxdlgVONStPar,isFolder=icKwYGUBWnkoLfhquzxdlgVONStPAp,params=icKwYGUBWnkoLfhquzxdlgVONStPQr,isLink=icKwYGUBWnkoLfhquzxdlgVONStPAR)
  if icKwYGUBWnkoLfhquzxdlgVONStPav:
   icKwYGUBWnkoLfhquzxdlgVONStPQr={}
   icKwYGUBWnkoLfhquzxdlgVONStPQr['mode'] ='EPISODE_LIST' 
   icKwYGUBWnkoLfhquzxdlgVONStPQr['seasonid']=icKwYGUBWnkoLfhquzxdlgVONStPvT
   icKwYGUBWnkoLfhquzxdlgVONStPQr['page'] =icKwYGUBWnkoLfhquzxdlgVONStPAX(icKwYGUBWnkoLfhquzxdlgVONStPaH+1)
   icKwYGUBWnkoLfhquzxdlgVONStPQy='[B]%s >>[/B]'%'다음 페이지'
   icKwYGUBWnkoLfhquzxdlgVONStPMR=icKwYGUBWnkoLfhquzxdlgVONStPAX(icKwYGUBWnkoLfhquzxdlgVONStPaH+1)
   icKwYGUBWnkoLfhquzxdlgVONStPQX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   icKwYGUBWnkoLfhquzxdlgVONStPsp.add_dir(icKwYGUBWnkoLfhquzxdlgVONStPQy,sublabel=icKwYGUBWnkoLfhquzxdlgVONStPMR,img=icKwYGUBWnkoLfhquzxdlgVONStPQX,infoLabels=icKwYGUBWnkoLfhquzxdlgVONStPAb,isFolder=icKwYGUBWnkoLfhquzxdlgVONStPAR,params=icKwYGUBWnkoLfhquzxdlgVONStPQr)
  xbmcplugin.setContent(icKwYGUBWnkoLfhquzxdlgVONStPsp._addon_handle,'episodes')
  if icKwYGUBWnkoLfhquzxdlgVONStPAE(icKwYGUBWnkoLfhquzxdlgVONStPaJ)>0:xbmcplugin.endOfDirectory(icKwYGUBWnkoLfhquzxdlgVONStPsp._addon_handle,cacheToDisc=icKwYGUBWnkoLfhquzxdlgVONStPAp)
 def dp_SuperSection_List(icKwYGUBWnkoLfhquzxdlgVONStPsp,args):
  icKwYGUBWnkoLfhquzxdlgVONStPRs =args.get('suburl')
  icKwYGUBWnkoLfhquzxdlgVONStPvE =args.get('subapi')
  icKwYGUBWnkoLfhquzxdlgVONStPsp.addon_log('dp_SuperSection_List')
  icKwYGUBWnkoLfhquzxdlgVONStPsp.addon_log('suburl : '+icKwYGUBWnkoLfhquzxdlgVONStPRs)
  icKwYGUBWnkoLfhquzxdlgVONStPsp.addon_log('subapi : '+icKwYGUBWnkoLfhquzxdlgVONStPvE)
  icKwYGUBWnkoLfhquzxdlgVONStPaJ=icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.Get_SuperMultiSection_List(icKwYGUBWnkoLfhquzxdlgVONStPRs)
  for icKwYGUBWnkoLfhquzxdlgVONStPaj in icKwYGUBWnkoLfhquzxdlgVONStPaJ:
   icKwYGUBWnkoLfhquzxdlgVONStPQy =icKwYGUBWnkoLfhquzxdlgVONStPaj.get('title')
   icKwYGUBWnkoLfhquzxdlgVONStPvE =icKwYGUBWnkoLfhquzxdlgVONStPaj.get('subapi')
   icKwYGUBWnkoLfhquzxdlgVONStPRQ=icKwYGUBWnkoLfhquzxdlgVONStPaj.get('cell_type')
   if icKwYGUBWnkoLfhquzxdlgVONStPvE.find('contenttype=movie')>=0 or icKwYGUBWnkoLfhquzxdlgVONStPvE.find('mtype=svod')>=0:
    icKwYGUBWnkoLfhquzxdlgVONStPaQ='MOVIE_LIST'
   elif re.search('themes/2\d{4}',icKwYGUBWnkoLfhquzxdlgVONStPvE)or re.search('themes-band/9\d{4}',icKwYGUBWnkoLfhquzxdlgVONStPvE):
    icKwYGUBWnkoLfhquzxdlgVONStPaQ='MOVIE_LIST'
   else:
    icKwYGUBWnkoLfhquzxdlgVONStPaQ='PROGRAM_LIST'
   '''
   if subapi.find('mtype=svod') >= 0 or subapi.find('mtype=ppv') >= 0 or subapi.find('contenttype=movie') >= 0: #영화 #20201107
    mode = 'MOVIE_LIST'
   elif subapi.find('contenttype=program') >= 0:
    mode = 'PROGRAM_LIST'
   elif cell_type == 'band_71': # band_71 #20201107
    mode   = 'SUPERSECTION_LIST'
    (temp_url, temp_api) = self.WavveObj.Baseapi_Parse(subapi)
    suburl = temp_api.get('api')
    subapi = ''
   elif cell_type == 'band_2': # band_2
    mode = 'BAND2SECTION_LIST'
   elif cell_type == 'band_live':
    mode = 'BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}', subapi) :
    mode = 'MOVIE_LIST'
   else: # band_10
    mode = 'PROGRAM_LIST'
   '''   
   icKwYGUBWnkoLfhquzxdlgVONStPar={'plot':icKwYGUBWnkoLfhquzxdlgVONStPQy,'mediatype':'tvshow',}
   icKwYGUBWnkoLfhquzxdlgVONStPQr={'mode':icKwYGUBWnkoLfhquzxdlgVONStPaQ,'suburl':icKwYGUBWnkoLfhquzxdlgVONStPRs,'subapi':icKwYGUBWnkoLfhquzxdlgVONStPvE,'page':'1',}
   icKwYGUBWnkoLfhquzxdlgVONStPsp.add_dir(icKwYGUBWnkoLfhquzxdlgVONStPQy,sublabel='',img=icKwYGUBWnkoLfhquzxdlgVONStPAb,infoLabels=icKwYGUBWnkoLfhquzxdlgVONStPar,isFolder=icKwYGUBWnkoLfhquzxdlgVONStPAR,params=icKwYGUBWnkoLfhquzxdlgVONStPQr)
  if icKwYGUBWnkoLfhquzxdlgVONStPAE(icKwYGUBWnkoLfhquzxdlgVONStPaJ)>0:xbmcplugin.endOfDirectory(icKwYGUBWnkoLfhquzxdlgVONStPsp._addon_handle,cacheToDisc=icKwYGUBWnkoLfhquzxdlgVONStPAp)
 def dp_BandLiveSection_List(icKwYGUBWnkoLfhquzxdlgVONStPsp,args):
  icKwYGUBWnkoLfhquzxdlgVONStPvE =args.get('subapi')
  icKwYGUBWnkoLfhquzxdlgVONStPaH=icKwYGUBWnkoLfhquzxdlgVONStPAv(args.get('page'))
  icKwYGUBWnkoLfhquzxdlgVONStPaJ,icKwYGUBWnkoLfhquzxdlgVONStPav=icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.Get_BandLiveSection_List(icKwYGUBWnkoLfhquzxdlgVONStPvE,icKwYGUBWnkoLfhquzxdlgVONStPaH)
  for icKwYGUBWnkoLfhquzxdlgVONStPaj in icKwYGUBWnkoLfhquzxdlgVONStPaJ:
   icKwYGUBWnkoLfhquzxdlgVONStPRa =icKwYGUBWnkoLfhquzxdlgVONStPaj.get('channelid')
   icKwYGUBWnkoLfhquzxdlgVONStPRM =icKwYGUBWnkoLfhquzxdlgVONStPaj.get('studio')
   icKwYGUBWnkoLfhquzxdlgVONStPRb=icKwYGUBWnkoLfhquzxdlgVONStPaj.get('tvshowtitle')
   icKwYGUBWnkoLfhquzxdlgVONStPaC =icKwYGUBWnkoLfhquzxdlgVONStPaj.get('thumbnail')
   icKwYGUBWnkoLfhquzxdlgVONStPMs =icKwYGUBWnkoLfhquzxdlgVONStPaj.get('age')
   icKwYGUBWnkoLfhquzxdlgVONStPar={'mediatype':'tvshow','mpaa':icKwYGUBWnkoLfhquzxdlgVONStPMs,'title':'%s < %s >'%(icKwYGUBWnkoLfhquzxdlgVONStPRM,icKwYGUBWnkoLfhquzxdlgVONStPRb),'tvshowtitle':icKwYGUBWnkoLfhquzxdlgVONStPRb,'studio':icKwYGUBWnkoLfhquzxdlgVONStPRM,'plot':icKwYGUBWnkoLfhquzxdlgVONStPRM}
   icKwYGUBWnkoLfhquzxdlgVONStPQr={'mode':'LIVE','contentid':icKwYGUBWnkoLfhquzxdlgVONStPRa}
   icKwYGUBWnkoLfhquzxdlgVONStPsp.add_dir(icKwYGUBWnkoLfhquzxdlgVONStPRM,sublabel=icKwYGUBWnkoLfhquzxdlgVONStPRb,img=icKwYGUBWnkoLfhquzxdlgVONStPaj.get('thumbnail'),infoLabels=icKwYGUBWnkoLfhquzxdlgVONStPar,isFolder=icKwYGUBWnkoLfhquzxdlgVONStPAp,params=icKwYGUBWnkoLfhquzxdlgVONStPQr)
  if icKwYGUBWnkoLfhquzxdlgVONStPav:
   icKwYGUBWnkoLfhquzxdlgVONStPQr={}
   icKwYGUBWnkoLfhquzxdlgVONStPQr['mode'] ='BANDLIVESECTION_LIST' 
   icKwYGUBWnkoLfhquzxdlgVONStPQr['subapi']=icKwYGUBWnkoLfhquzxdlgVONStPvE
   icKwYGUBWnkoLfhquzxdlgVONStPQr['page'] =icKwYGUBWnkoLfhquzxdlgVONStPAX(icKwYGUBWnkoLfhquzxdlgVONStPaH+1)
   icKwYGUBWnkoLfhquzxdlgVONStPQy='[B]%s >>[/B]'%'다음 페이지'
   icKwYGUBWnkoLfhquzxdlgVONStPMR=icKwYGUBWnkoLfhquzxdlgVONStPAX(icKwYGUBWnkoLfhquzxdlgVONStPaH+1)
   icKwYGUBWnkoLfhquzxdlgVONStPQX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   icKwYGUBWnkoLfhquzxdlgVONStPsp.add_dir(icKwYGUBWnkoLfhquzxdlgVONStPQy,sublabel=icKwYGUBWnkoLfhquzxdlgVONStPMR,img=icKwYGUBWnkoLfhquzxdlgVONStPQX,infoLabels=icKwYGUBWnkoLfhquzxdlgVONStPAb,isFolder=icKwYGUBWnkoLfhquzxdlgVONStPAR,params=icKwYGUBWnkoLfhquzxdlgVONStPQr)
  if icKwYGUBWnkoLfhquzxdlgVONStPAE(icKwYGUBWnkoLfhquzxdlgVONStPaJ)>0:xbmcplugin.endOfDirectory(icKwYGUBWnkoLfhquzxdlgVONStPsp._addon_handle,cacheToDisc=icKwYGUBWnkoLfhquzxdlgVONStPAp)
 def dp_Band2Section_List(icKwYGUBWnkoLfhquzxdlgVONStPsp,args):
  icKwYGUBWnkoLfhquzxdlgVONStPvE =args.get('subapi')
  icKwYGUBWnkoLfhquzxdlgVONStPaH=icKwYGUBWnkoLfhquzxdlgVONStPAv(args.get('page'))
  icKwYGUBWnkoLfhquzxdlgVONStPaJ,icKwYGUBWnkoLfhquzxdlgVONStPav=icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.Get_Band2Section_List(icKwYGUBWnkoLfhquzxdlgVONStPvE,icKwYGUBWnkoLfhquzxdlgVONStPaH)
  for icKwYGUBWnkoLfhquzxdlgVONStPaj in icKwYGUBWnkoLfhquzxdlgVONStPaJ:
   icKwYGUBWnkoLfhquzxdlgVONStPQy =icKwYGUBWnkoLfhquzxdlgVONStPaj.get('programtitle')
   icKwYGUBWnkoLfhquzxdlgVONStPMR =icKwYGUBWnkoLfhquzxdlgVONStPaj.get('episodetitle')
   icKwYGUBWnkoLfhquzxdlgVONStPar={'plot':icKwYGUBWnkoLfhquzxdlgVONStPQy+'\n\n'+icKwYGUBWnkoLfhquzxdlgVONStPMR,'mpaa':icKwYGUBWnkoLfhquzxdlgVONStPaj.get('age'),'mediatype':'episode'}
   icKwYGUBWnkoLfhquzxdlgVONStPQr={'mode':'VOD','programid':'-','contentid':icKwYGUBWnkoLfhquzxdlgVONStPaj.get('videoid'),'thumbnail':icKwYGUBWnkoLfhquzxdlgVONStPaj.get('thumbnail'),'title':icKwYGUBWnkoLfhquzxdlgVONStPQy,'subtitle':icKwYGUBWnkoLfhquzxdlgVONStPMR}
   icKwYGUBWnkoLfhquzxdlgVONStPsp.add_dir(icKwYGUBWnkoLfhquzxdlgVONStPQy,sublabel=icKwYGUBWnkoLfhquzxdlgVONStPMR,img=icKwYGUBWnkoLfhquzxdlgVONStPaj.get('thumbnail'),infoLabels=icKwYGUBWnkoLfhquzxdlgVONStPar,isFolder=icKwYGUBWnkoLfhquzxdlgVONStPAp,params=icKwYGUBWnkoLfhquzxdlgVONStPQr)
  if icKwYGUBWnkoLfhquzxdlgVONStPav:
   icKwYGUBWnkoLfhquzxdlgVONStPQr={}
   icKwYGUBWnkoLfhquzxdlgVONStPQr['mode'] ='BAND2SECTION_LIST' 
   icKwYGUBWnkoLfhquzxdlgVONStPQr['subapi']=icKwYGUBWnkoLfhquzxdlgVONStPvE
   icKwYGUBWnkoLfhquzxdlgVONStPQr['page'] =icKwYGUBWnkoLfhquzxdlgVONStPAX(icKwYGUBWnkoLfhquzxdlgVONStPaH+1)
   icKwYGUBWnkoLfhquzxdlgVONStPQy='[B]%s >>[/B]'%'다음 페이지'
   icKwYGUBWnkoLfhquzxdlgVONStPMR=icKwYGUBWnkoLfhquzxdlgVONStPAX(icKwYGUBWnkoLfhquzxdlgVONStPaH+1)
   icKwYGUBWnkoLfhquzxdlgVONStPQX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   icKwYGUBWnkoLfhquzxdlgVONStPsp.add_dir(icKwYGUBWnkoLfhquzxdlgVONStPQy,sublabel=icKwYGUBWnkoLfhquzxdlgVONStPMR,img=icKwYGUBWnkoLfhquzxdlgVONStPQX,infoLabels=icKwYGUBWnkoLfhquzxdlgVONStPAb,isFolder=icKwYGUBWnkoLfhquzxdlgVONStPAR,params=icKwYGUBWnkoLfhquzxdlgVONStPQr)
  if icKwYGUBWnkoLfhquzxdlgVONStPAE(icKwYGUBWnkoLfhquzxdlgVONStPaJ)>0:xbmcplugin.endOfDirectory(icKwYGUBWnkoLfhquzxdlgVONStPsp._addon_handle,cacheToDisc=icKwYGUBWnkoLfhquzxdlgVONStPAp)
 def dp_Movie_List(icKwYGUBWnkoLfhquzxdlgVONStPsp,args):
  icKwYGUBWnkoLfhquzxdlgVONStPvE =args.get('subapi')
  icKwYGUBWnkoLfhquzxdlgVONStPaH=icKwYGUBWnkoLfhquzxdlgVONStPAv(args.get('page'))
  icKwYGUBWnkoLfhquzxdlgVONStPQp =args.get('orderby')or '-'
  icKwYGUBWnkoLfhquzxdlgVONStPsp.addon_log('dp_Movie_List')
  icKwYGUBWnkoLfhquzxdlgVONStPsp.addon_log(icKwYGUBWnkoLfhquzxdlgVONStPvE)
  icKwYGUBWnkoLfhquzxdlgVONStPaJ,icKwYGUBWnkoLfhquzxdlgVONStPav=icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.Get_Movie_List(icKwYGUBWnkoLfhquzxdlgVONStPvE,icKwYGUBWnkoLfhquzxdlgVONStPaH,icKwYGUBWnkoLfhquzxdlgVONStPQp)
  for icKwYGUBWnkoLfhquzxdlgVONStPaj in icKwYGUBWnkoLfhquzxdlgVONStPaJ:
   icKwYGUBWnkoLfhquzxdlgVONStPam =icKwYGUBWnkoLfhquzxdlgVONStPaj.get('videoid')
   icKwYGUBWnkoLfhquzxdlgVONStPaF =icKwYGUBWnkoLfhquzxdlgVONStPaj.get('vidtype')
   icKwYGUBWnkoLfhquzxdlgVONStPQy =icKwYGUBWnkoLfhquzxdlgVONStPaj.get('title')
   icKwYGUBWnkoLfhquzxdlgVONStPaC=icKwYGUBWnkoLfhquzxdlgVONStPaj.get('thumbnail')
   icKwYGUBWnkoLfhquzxdlgVONStPMs =icKwYGUBWnkoLfhquzxdlgVONStPaj.get('age')
   if icKwYGUBWnkoLfhquzxdlgVONStPMs=='18' or icKwYGUBWnkoLfhquzxdlgVONStPMs=='19' or icKwYGUBWnkoLfhquzxdlgVONStPMs=='21':icKwYGUBWnkoLfhquzxdlgVONStPQy+=' (%s)'%(icKwYGUBWnkoLfhquzxdlgVONStPMs)
   icKwYGUBWnkoLfhquzxdlgVONStPar={'plot':icKwYGUBWnkoLfhquzxdlgVONStPQy,'mpaa':icKwYGUBWnkoLfhquzxdlgVONStPMs,'mediatype':'movie'}
   icKwYGUBWnkoLfhquzxdlgVONStPQr={'mode':'MOVIE','contentid':icKwYGUBWnkoLfhquzxdlgVONStPam,'title':icKwYGUBWnkoLfhquzxdlgVONStPQy,'thumbnail':icKwYGUBWnkoLfhquzxdlgVONStPaC,'age':icKwYGUBWnkoLfhquzxdlgVONStPMs,}
   icKwYGUBWnkoLfhquzxdlgVONStPaX=[]
   icKwYGUBWnkoLfhquzxdlgVONStPMQ={'mode':'VIEW_DETAIL','values':{'videoid':icKwYGUBWnkoLfhquzxdlgVONStPam,'vidtype':'movie','contenttype':icKwYGUBWnkoLfhquzxdlgVONStPaF,}}
   icKwYGUBWnkoLfhquzxdlgVONStPMa=json.dumps(icKwYGUBWnkoLfhquzxdlgVONStPMQ,separators=(',',':'))
   icKwYGUBWnkoLfhquzxdlgVONStPMa=base64.standard_b64encode(icKwYGUBWnkoLfhquzxdlgVONStPMa.encode()).decode('utf-8')
   icKwYGUBWnkoLfhquzxdlgVONStPMa=icKwYGUBWnkoLfhquzxdlgVONStPMa.replace('+','%2B')
   icKwYGUBWnkoLfhquzxdlgVONStPMb='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(icKwYGUBWnkoLfhquzxdlgVONStPMa)
   icKwYGUBWnkoLfhquzxdlgVONStPaX.append(('상세정보 조회',icKwYGUBWnkoLfhquzxdlgVONStPMb))
   if icKwYGUBWnkoLfhquzxdlgVONStPsp.get_settings_makebookmark():
    icKwYGUBWnkoLfhquzxdlgVONStPMQ={'videoid':icKwYGUBWnkoLfhquzxdlgVONStPam,'vidtype':'movie','vtitle':icKwYGUBWnkoLfhquzxdlgVONStPQy,'vsubtitle':'','contenttype':'programid',}
    icKwYGUBWnkoLfhquzxdlgVONStPMv=json.dumps(icKwYGUBWnkoLfhquzxdlgVONStPMQ)
    icKwYGUBWnkoLfhquzxdlgVONStPMv=urllib.parse.quote(icKwYGUBWnkoLfhquzxdlgVONStPMv)
    icKwYGUBWnkoLfhquzxdlgVONStPMb='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(icKwYGUBWnkoLfhquzxdlgVONStPMv)
    icKwYGUBWnkoLfhquzxdlgVONStPaX.append(('(통합) 찜 영상에 추가',icKwYGUBWnkoLfhquzxdlgVONStPMb))
   icKwYGUBWnkoLfhquzxdlgVONStPsp.add_dir(icKwYGUBWnkoLfhquzxdlgVONStPQy,sublabel='',img=icKwYGUBWnkoLfhquzxdlgVONStPaC,infoLabels=icKwYGUBWnkoLfhquzxdlgVONStPar,isFolder=icKwYGUBWnkoLfhquzxdlgVONStPAp,params=icKwYGUBWnkoLfhquzxdlgVONStPQr,ContextMenu=icKwYGUBWnkoLfhquzxdlgVONStPaX)
  if icKwYGUBWnkoLfhquzxdlgVONStPav:
   icKwYGUBWnkoLfhquzxdlgVONStPQr={}
   icKwYGUBWnkoLfhquzxdlgVONStPQr['mode'] ='MOVIE_LIST' 
   icKwYGUBWnkoLfhquzxdlgVONStPQr['subapi']=icKwYGUBWnkoLfhquzxdlgVONStPvE 
   icKwYGUBWnkoLfhquzxdlgVONStPQr['page'] =icKwYGUBWnkoLfhquzxdlgVONStPAX(icKwYGUBWnkoLfhquzxdlgVONStPaH+1)
   icKwYGUBWnkoLfhquzxdlgVONStPQr['orderby']=icKwYGUBWnkoLfhquzxdlgVONStPQp
   icKwYGUBWnkoLfhquzxdlgVONStPQy='[B]%s >>[/B]'%'다음 페이지'
   icKwYGUBWnkoLfhquzxdlgVONStPMR=icKwYGUBWnkoLfhquzxdlgVONStPAX(icKwYGUBWnkoLfhquzxdlgVONStPaH+1)
   icKwYGUBWnkoLfhquzxdlgVONStPQX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   icKwYGUBWnkoLfhquzxdlgVONStPsp.add_dir(icKwYGUBWnkoLfhquzxdlgVONStPQy,sublabel=icKwYGUBWnkoLfhquzxdlgVONStPMR,img=icKwYGUBWnkoLfhquzxdlgVONStPQX,infoLabels=icKwYGUBWnkoLfhquzxdlgVONStPAb,isFolder=icKwYGUBWnkoLfhquzxdlgVONStPAR,params=icKwYGUBWnkoLfhquzxdlgVONStPQr)
  xbmcplugin.setContent(icKwYGUBWnkoLfhquzxdlgVONStPsp._addon_handle,'movies')
  if icKwYGUBWnkoLfhquzxdlgVONStPAE(icKwYGUBWnkoLfhquzxdlgVONStPaJ)>0:xbmcplugin.endOfDirectory(icKwYGUBWnkoLfhquzxdlgVONStPsp._addon_handle,cacheToDisc=icKwYGUBWnkoLfhquzxdlgVONStPAp)
 def dp_Set_Bookmark(icKwYGUBWnkoLfhquzxdlgVONStPsp,args):
  icKwYGUBWnkoLfhquzxdlgVONStPRv=urllib.parse.unquote(args.get('bm_param'))
  icKwYGUBWnkoLfhquzxdlgVONStPRv=json.loads(icKwYGUBWnkoLfhquzxdlgVONStPRv)
  icKwYGUBWnkoLfhquzxdlgVONStPam =icKwYGUBWnkoLfhquzxdlgVONStPRv.get('videoid')
  icKwYGUBWnkoLfhquzxdlgVONStPaF =icKwYGUBWnkoLfhquzxdlgVONStPRv.get('vidtype')
  icKwYGUBWnkoLfhquzxdlgVONStPRA =icKwYGUBWnkoLfhquzxdlgVONStPRv.get('vtitle')
  icKwYGUBWnkoLfhquzxdlgVONStPRp =icKwYGUBWnkoLfhquzxdlgVONStPRv.get('vsubtitle')
  icKwYGUBWnkoLfhquzxdlgVONStPRD=icKwYGUBWnkoLfhquzxdlgVONStPRv.get('contenttype')
  icKwYGUBWnkoLfhquzxdlgVONStPsE=xbmcgui.Dialog()
  icKwYGUBWnkoLfhquzxdlgVONStPMF=icKwYGUBWnkoLfhquzxdlgVONStPsE.yesno(__language__(30913).encode('utf8'),icKwYGUBWnkoLfhquzxdlgVONStPRA+' \n\n'+__language__(30914))
  if icKwYGUBWnkoLfhquzxdlgVONStPMF==icKwYGUBWnkoLfhquzxdlgVONStPAp:return
  icKwYGUBWnkoLfhquzxdlgVONStPRy=icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.GetBookmarkInfo(icKwYGUBWnkoLfhquzxdlgVONStPam,icKwYGUBWnkoLfhquzxdlgVONStPaF,icKwYGUBWnkoLfhquzxdlgVONStPRD)
  icKwYGUBWnkoLfhquzxdlgVONStPRe=json.dumps(icKwYGUBWnkoLfhquzxdlgVONStPRy)
  icKwYGUBWnkoLfhquzxdlgVONStPRe=urllib.parse.quote(icKwYGUBWnkoLfhquzxdlgVONStPRe)
  icKwYGUBWnkoLfhquzxdlgVONStPMb ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(icKwYGUBWnkoLfhquzxdlgVONStPRe)
  xbmc.executebuiltin(icKwYGUBWnkoLfhquzxdlgVONStPMb)
 def dp_LiveChannel_List(icKwYGUBWnkoLfhquzxdlgVONStPsp,args):
  icKwYGUBWnkoLfhquzxdlgVONStPRI =args.get('genre')
  icKwYGUBWnkoLfhquzxdlgVONStPvI=args.get('baseapi')
  icKwYGUBWnkoLfhquzxdlgVONStPaJ=icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.Get_LiveChannel_List(icKwYGUBWnkoLfhquzxdlgVONStPRI,icKwYGUBWnkoLfhquzxdlgVONStPvI)
  for icKwYGUBWnkoLfhquzxdlgVONStPaj in icKwYGUBWnkoLfhquzxdlgVONStPaJ:
   icKwYGUBWnkoLfhquzxdlgVONStPRa =icKwYGUBWnkoLfhquzxdlgVONStPaj.get('channelid')
   icKwYGUBWnkoLfhquzxdlgVONStPRM =icKwYGUBWnkoLfhquzxdlgVONStPaj.get('studio')
   icKwYGUBWnkoLfhquzxdlgVONStPRb=icKwYGUBWnkoLfhquzxdlgVONStPaj.get('tvshowtitle')
   icKwYGUBWnkoLfhquzxdlgVONStPaC =icKwYGUBWnkoLfhquzxdlgVONStPaj.get('thumbnail')
   icKwYGUBWnkoLfhquzxdlgVONStPMs =icKwYGUBWnkoLfhquzxdlgVONStPaj.get('age')
   icKwYGUBWnkoLfhquzxdlgVONStPRE =icKwYGUBWnkoLfhquzxdlgVONStPaj.get('epg')
   icKwYGUBWnkoLfhquzxdlgVONStPar={'mediatype':'episode','mpaa':icKwYGUBWnkoLfhquzxdlgVONStPMs,'title':'%s < %s >'%(icKwYGUBWnkoLfhquzxdlgVONStPRM,icKwYGUBWnkoLfhquzxdlgVONStPRb),'tvshowtitle':icKwYGUBWnkoLfhquzxdlgVONStPRb,'studio':icKwYGUBWnkoLfhquzxdlgVONStPRM,'plot':'%s\n\n%s'%(icKwYGUBWnkoLfhquzxdlgVONStPRM,icKwYGUBWnkoLfhquzxdlgVONStPRE)}
   icKwYGUBWnkoLfhquzxdlgVONStPQr={'mode':'LIVE','contentid':icKwYGUBWnkoLfhquzxdlgVONStPRa}
   icKwYGUBWnkoLfhquzxdlgVONStPsp.add_dir(icKwYGUBWnkoLfhquzxdlgVONStPRM,sublabel=icKwYGUBWnkoLfhquzxdlgVONStPRb,img=icKwYGUBWnkoLfhquzxdlgVONStPaC,infoLabels=icKwYGUBWnkoLfhquzxdlgVONStPar,isFolder=icKwYGUBWnkoLfhquzxdlgVONStPAp,params=icKwYGUBWnkoLfhquzxdlgVONStPQr)
  if icKwYGUBWnkoLfhquzxdlgVONStPAE(icKwYGUBWnkoLfhquzxdlgVONStPaJ)>0:xbmcplugin.endOfDirectory(icKwYGUBWnkoLfhquzxdlgVONStPsp._addon_handle,cacheToDisc=icKwYGUBWnkoLfhquzxdlgVONStPAp)
 def dp_Sports_GameList(icKwYGUBWnkoLfhquzxdlgVONStPsp,args):
  icKwYGUBWnkoLfhquzxdlgVONStPaJ=icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.Get_Sports_Gamelist()
  for icKwYGUBWnkoLfhquzxdlgVONStPaj in icKwYGUBWnkoLfhquzxdlgVONStPaJ:
   icKwYGUBWnkoLfhquzxdlgVONStPRT =icKwYGUBWnkoLfhquzxdlgVONStPaj.get('game_date')
   icKwYGUBWnkoLfhquzxdlgVONStPRX =icKwYGUBWnkoLfhquzxdlgVONStPaj.get('game_time')
   icKwYGUBWnkoLfhquzxdlgVONStPRr =icKwYGUBWnkoLfhquzxdlgVONStPaj.get('svc_id')
   icKwYGUBWnkoLfhquzxdlgVONStPRH =icKwYGUBWnkoLfhquzxdlgVONStPaj.get('away_team')
   icKwYGUBWnkoLfhquzxdlgVONStPRJ =icKwYGUBWnkoLfhquzxdlgVONStPaj.get('home_team')
   icKwYGUBWnkoLfhquzxdlgVONStPRj=icKwYGUBWnkoLfhquzxdlgVONStPaj.get('game_status')
   icKwYGUBWnkoLfhquzxdlgVONStPRm =icKwYGUBWnkoLfhquzxdlgVONStPaj.get('game_place')
   icKwYGUBWnkoLfhquzxdlgVONStPRF ='%s vs %s (%s)'%(icKwYGUBWnkoLfhquzxdlgVONStPRH,icKwYGUBWnkoLfhquzxdlgVONStPRJ,icKwYGUBWnkoLfhquzxdlgVONStPRm)
   icKwYGUBWnkoLfhquzxdlgVONStPRC =icKwYGUBWnkoLfhquzxdlgVONStPRT+' '+icKwYGUBWnkoLfhquzxdlgVONStPRX
   if icKwYGUBWnkoLfhquzxdlgVONStPRj=='LIVE':
    icKwYGUBWnkoLfhquzxdlgVONStPRj='~경기중~'
   elif icKwYGUBWnkoLfhquzxdlgVONStPRj=='END':
    icKwYGUBWnkoLfhquzxdlgVONStPRj='경기종료'
   elif icKwYGUBWnkoLfhquzxdlgVONStPRj=='CANCEL':
    icKwYGUBWnkoLfhquzxdlgVONStPRj='취소'
   else:
    icKwYGUBWnkoLfhquzxdlgVONStPRj=''
   if icKwYGUBWnkoLfhquzxdlgVONStPRj=='':
    icKwYGUBWnkoLfhquzxdlgVONStPMR=icKwYGUBWnkoLfhquzxdlgVONStPRF
   else:
    icKwYGUBWnkoLfhquzxdlgVONStPMR=icKwYGUBWnkoLfhquzxdlgVONStPRF+'  '+icKwYGUBWnkoLfhquzxdlgVONStPRj
   icKwYGUBWnkoLfhquzxdlgVONStPar={'mediatype':'episode','title':icKwYGUBWnkoLfhquzxdlgVONStPRF,'plot':'%s\n\n%s\n\n%s'%(icKwYGUBWnkoLfhquzxdlgVONStPRC,icKwYGUBWnkoLfhquzxdlgVONStPRF,icKwYGUBWnkoLfhquzxdlgVONStPRj)}
   icKwYGUBWnkoLfhquzxdlgVONStPQr={'mode':'SPORTS','contentid':icKwYGUBWnkoLfhquzxdlgVONStPRr}
   icKwYGUBWnkoLfhquzxdlgVONStPsp.add_dir(icKwYGUBWnkoLfhquzxdlgVONStPRC,sublabel=icKwYGUBWnkoLfhquzxdlgVONStPMR,img='',infoLabels=icKwYGUBWnkoLfhquzxdlgVONStPar,isFolder=icKwYGUBWnkoLfhquzxdlgVONStPAp,params=icKwYGUBWnkoLfhquzxdlgVONStPQr)
  xbmcplugin.endOfDirectory(icKwYGUBWnkoLfhquzxdlgVONStPsp._addon_handle,cacheToDisc=icKwYGUBWnkoLfhquzxdlgVONStPAp)
 def dp_View_Detail(icKwYGUBWnkoLfhquzxdlgVONStPsp,icKwYGUBWnkoLfhquzxdlgVONStPAa):
  icKwYGUBWnkoLfhquzxdlgVONStPam =icKwYGUBWnkoLfhquzxdlgVONStPAa.get('videoid')
  icKwYGUBWnkoLfhquzxdlgVONStPaF =icKwYGUBWnkoLfhquzxdlgVONStPAa.get('vidtype') 
  icKwYGUBWnkoLfhquzxdlgVONStPRD=icKwYGUBWnkoLfhquzxdlgVONStPAa.get('contenttype')
  icKwYGUBWnkoLfhquzxdlgVONStPsp.addon_log(icKwYGUBWnkoLfhquzxdlgVONStPam)
  icKwYGUBWnkoLfhquzxdlgVONStPsp.addon_log(icKwYGUBWnkoLfhquzxdlgVONStPaF)
  icKwYGUBWnkoLfhquzxdlgVONStPsp.addon_log(icKwYGUBWnkoLfhquzxdlgVONStPRD)
  icKwYGUBWnkoLfhquzxdlgVONStPRy=icKwYGUBWnkoLfhquzxdlgVONStPsp.WavveObj.GetBookmarkInfo(icKwYGUBWnkoLfhquzxdlgVONStPam,icKwYGUBWnkoLfhquzxdlgVONStPaF,icKwYGUBWnkoLfhquzxdlgVONStPRD)
  if icKwYGUBWnkoLfhquzxdlgVONStPaF=='tvshow':
   icKwYGUBWnkoLfhquzxdlgVONStPQr={'mode':'SEASON_LIST','videoid':icKwYGUBWnkoLfhquzxdlgVONStPRy['indexinfo']['videoid'],'vidtype':icKwYGUBWnkoLfhquzxdlgVONStPRy['indexinfo']['vidtype'],}
   icKwYGUBWnkoLfhquzxdlgVONStPba='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(icKwYGUBWnkoLfhquzxdlgVONStPQr))
  else:
   icKwYGUBWnkoLfhquzxdlgVONStPQr={'mode':'MOVIE','contentid':icKwYGUBWnkoLfhquzxdlgVONStPRy['indexinfo']['videoid'],'title':icKwYGUBWnkoLfhquzxdlgVONStPRy['saveinfo']['infoLabels']['title'],'thumbnail':icKwYGUBWnkoLfhquzxdlgVONStPRy['saveinfo']['thumbnail'],'age':icKwYGUBWnkoLfhquzxdlgVONStPRy['saveinfo']['infoLabels']['mpaa'],}
   icKwYGUBWnkoLfhquzxdlgVONStPba='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(icKwYGUBWnkoLfhquzxdlgVONStPQr))
  icKwYGUBWnkoLfhquzxdlgVONStPQe=xbmcgui.ListItem(label=icKwYGUBWnkoLfhquzxdlgVONStPRy['saveinfo']['title'],path=icKwYGUBWnkoLfhquzxdlgVONStPba)
  icKwYGUBWnkoLfhquzxdlgVONStPQe.setArt(icKwYGUBWnkoLfhquzxdlgVONStPRy['saveinfo']['thumbnail'])
  icKwYGUBWnkoLfhquzxdlgVONStPsp.Set_InfoTag(icKwYGUBWnkoLfhquzxdlgVONStPQe.getVideoInfoTag(),icKwYGUBWnkoLfhquzxdlgVONStPRy['saveinfo']['infoLabels'])
  if icKwYGUBWnkoLfhquzxdlgVONStPaF=='movie':
   icKwYGUBWnkoLfhquzxdlgVONStPQe.setIsFolder(icKwYGUBWnkoLfhquzxdlgVONStPAp)
   icKwYGUBWnkoLfhquzxdlgVONStPQe.setProperty('IsPlayable','true')
  else:
   icKwYGUBWnkoLfhquzxdlgVONStPQe.setIsFolder(icKwYGUBWnkoLfhquzxdlgVONStPAR)
   icKwYGUBWnkoLfhquzxdlgVONStPQe.setProperty('IsPlayable','false')
  icKwYGUBWnkoLfhquzxdlgVONStPsE=xbmcgui.Dialog()
  icKwYGUBWnkoLfhquzxdlgVONStPsE.info(icKwYGUBWnkoLfhquzxdlgVONStPQe)
 def wavve_main(icKwYGUBWnkoLfhquzxdlgVONStPsp):
  icKwYGUBWnkoLfhquzxdlgVONStPAs=icKwYGUBWnkoLfhquzxdlgVONStPsp.main_params.get('params')
  if icKwYGUBWnkoLfhquzxdlgVONStPAs:
   icKwYGUBWnkoLfhquzxdlgVONStPAQ =base64.standard_b64decode(icKwYGUBWnkoLfhquzxdlgVONStPAs).decode('utf-8')
   icKwYGUBWnkoLfhquzxdlgVONStPAQ =json.loads(icKwYGUBWnkoLfhquzxdlgVONStPAQ)
   icKwYGUBWnkoLfhquzxdlgVONStPaQ =icKwYGUBWnkoLfhquzxdlgVONStPAQ.get('mode')
   icKwYGUBWnkoLfhquzxdlgVONStPAa =icKwYGUBWnkoLfhquzxdlgVONStPAQ.get('values')
  else:
   icKwYGUBWnkoLfhquzxdlgVONStPaQ=icKwYGUBWnkoLfhquzxdlgVONStPsp.main_params.get('mode',icKwYGUBWnkoLfhquzxdlgVONStPAb)
   icKwYGUBWnkoLfhquzxdlgVONStPAa=icKwYGUBWnkoLfhquzxdlgVONStPsp.main_params
  if icKwYGUBWnkoLfhquzxdlgVONStPaQ=='LOGOUT':
   icKwYGUBWnkoLfhquzxdlgVONStPsp.logout()
   return
  icKwYGUBWnkoLfhquzxdlgVONStPsp.login_main()
  if icKwYGUBWnkoLfhquzxdlgVONStPaQ is icKwYGUBWnkoLfhquzxdlgVONStPAb:
   icKwYGUBWnkoLfhquzxdlgVONStPsp.dp_Main_List()
  elif icKwYGUBWnkoLfhquzxdlgVONStPaQ in['LIVE','VOD','MOVIE','SPORTS']:
   icKwYGUBWnkoLfhquzxdlgVONStPsp.play_VIDEO(icKwYGUBWnkoLfhquzxdlgVONStPAa)
  elif icKwYGUBWnkoLfhquzxdlgVONStPaQ=='LIVE_CATAGORY':
   icKwYGUBWnkoLfhquzxdlgVONStPsp.dp_LiveCatagory_List(icKwYGUBWnkoLfhquzxdlgVONStPAa)
  elif icKwYGUBWnkoLfhquzxdlgVONStPaQ=='MAIN_CATAGORY':
   icKwYGUBWnkoLfhquzxdlgVONStPsp.dp_MainCatagory_List(icKwYGUBWnkoLfhquzxdlgVONStPAa)
  elif icKwYGUBWnkoLfhquzxdlgVONStPaQ=='SUPERSECTION_LIST':
   icKwYGUBWnkoLfhquzxdlgVONStPsp.dp_SuperSection_List(icKwYGUBWnkoLfhquzxdlgVONStPAa)
  elif icKwYGUBWnkoLfhquzxdlgVONStPaQ=='BANDLIVESECTION_LIST':
   icKwYGUBWnkoLfhquzxdlgVONStPsp.dp_BandLiveSection_List(icKwYGUBWnkoLfhquzxdlgVONStPAa)
  elif icKwYGUBWnkoLfhquzxdlgVONStPaQ=='BAND2SECTION_LIST':
   icKwYGUBWnkoLfhquzxdlgVONStPsp.dp_Band2Section_List(icKwYGUBWnkoLfhquzxdlgVONStPAa)
  elif icKwYGUBWnkoLfhquzxdlgVONStPaQ=='PROGRAM_LIST':
   icKwYGUBWnkoLfhquzxdlgVONStPsp.dp_Program_List(icKwYGUBWnkoLfhquzxdlgVONStPAa)
  elif icKwYGUBWnkoLfhquzxdlgVONStPaQ=='SEASON_LIST':
   icKwYGUBWnkoLfhquzxdlgVONStPsp.dp_Season_List(icKwYGUBWnkoLfhquzxdlgVONStPAa)
  elif icKwYGUBWnkoLfhquzxdlgVONStPaQ=='EPISODE_LIST':
   icKwYGUBWnkoLfhquzxdlgVONStPsp.dp_Episode_List(icKwYGUBWnkoLfhquzxdlgVONStPAa)
  elif icKwYGUBWnkoLfhquzxdlgVONStPaQ=='MOVIE_LIST':
   icKwYGUBWnkoLfhquzxdlgVONStPsp.dp_Movie_List(icKwYGUBWnkoLfhquzxdlgVONStPAa)
  elif icKwYGUBWnkoLfhquzxdlgVONStPaQ=='LIVE_LIST':
   icKwYGUBWnkoLfhquzxdlgVONStPsp.dp_LiveChannel_List(icKwYGUBWnkoLfhquzxdlgVONStPAa)
  elif icKwYGUBWnkoLfhquzxdlgVONStPaQ=='ORDER_BY':
   icKwYGUBWnkoLfhquzxdlgVONStPsp.dp_setEpOrderby(icKwYGUBWnkoLfhquzxdlgVONStPAa)
  elif icKwYGUBWnkoLfhquzxdlgVONStPaQ=='SEARCH_GROUP':
   icKwYGUBWnkoLfhquzxdlgVONStPsp.dp_Search_Group(icKwYGUBWnkoLfhquzxdlgVONStPAa)
  elif icKwYGUBWnkoLfhquzxdlgVONStPaQ in['SEARCH_LIST','LOCAL_SEARCH']:
   icKwYGUBWnkoLfhquzxdlgVONStPsp.dp_Search_List(icKwYGUBWnkoLfhquzxdlgVONStPAa)
  elif icKwYGUBWnkoLfhquzxdlgVONStPaQ=='WATCH_GROUP':
   icKwYGUBWnkoLfhquzxdlgVONStPsp.dp_Watch_Group(icKwYGUBWnkoLfhquzxdlgVONStPAa)
  elif icKwYGUBWnkoLfhquzxdlgVONStPaQ=='WATCH_LIST':
   icKwYGUBWnkoLfhquzxdlgVONStPsp.dp_Watch_List(icKwYGUBWnkoLfhquzxdlgVONStPAa)
  elif icKwYGUBWnkoLfhquzxdlgVONStPaQ=='SET_BOOKMARK':
   icKwYGUBWnkoLfhquzxdlgVONStPsp.dp_Set_Bookmark(icKwYGUBWnkoLfhquzxdlgVONStPAa)
  elif icKwYGUBWnkoLfhquzxdlgVONStPaQ in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   icKwYGUBWnkoLfhquzxdlgVONStPsp.dp_History_Remove(icKwYGUBWnkoLfhquzxdlgVONStPAa)
  elif icKwYGUBWnkoLfhquzxdlgVONStPaQ in['TOTAL_SEARCH','TOTAL_HISTORY']:
   icKwYGUBWnkoLfhquzxdlgVONStPsp.dp_Global_Search(icKwYGUBWnkoLfhquzxdlgVONStPAa)
  elif icKwYGUBWnkoLfhquzxdlgVONStPaQ=='SEARCH_HISTORY':
   icKwYGUBWnkoLfhquzxdlgVONStPsp.dp_Search_History(icKwYGUBWnkoLfhquzxdlgVONStPAa)
  elif icKwYGUBWnkoLfhquzxdlgVONStPaQ=='MENU_BOOKMARK':
   icKwYGUBWnkoLfhquzxdlgVONStPsp.dp_Bookmark_Menu(icKwYGUBWnkoLfhquzxdlgVONStPAa)
  elif icKwYGUBWnkoLfhquzxdlgVONStPaQ=='GAME_LIST':
   icKwYGUBWnkoLfhquzxdlgVONStPsp.dp_Sports_GameList(icKwYGUBWnkoLfhquzxdlgVONStPAa)
  elif icKwYGUBWnkoLfhquzxdlgVONStPaQ=='VIEW_DETAIL':
   icKwYGUBWnkoLfhquzxdlgVONStPsp.dp_View_Detail(icKwYGUBWnkoLfhquzxdlgVONStPAa)
  else:
   icKwYGUBWnkoLfhquzxdlgVONStPAb
# Created by pyminifier (https://github.com/liftoff/pyminifier)
