__author__="NightRain"
aVPqfrWzOvNAkmYGxEehnulIoLTcbX=object
aVPqfrWzOvNAkmYGxEehnulIoLTcbD=None
aVPqfrWzOvNAkmYGxEehnulIoLTcbp=False
aVPqfrWzOvNAkmYGxEehnulIoLTcbd=open
aVPqfrWzOvNAkmYGxEehnulIoLTcbQ=True
aVPqfrWzOvNAkmYGxEehnulIoLTcbC=range
aVPqfrWzOvNAkmYGxEehnulIoLTcbJ=str
aVPqfrWzOvNAkmYGxEehnulIoLTcbw=Exception
aVPqfrWzOvNAkmYGxEehnulIoLTcbj=print
aVPqfrWzOvNAkmYGxEehnulIoLTcbB=dict
aVPqfrWzOvNAkmYGxEehnulIoLTcbM=int
aVPqfrWzOvNAkmYGxEehnulIoLTcbt=len
import urllib
import re
import json
import sys
import requests
import datetime
import base64
class aVPqfrWzOvNAkmYGxEehnulIoLTcKX(aVPqfrWzOvNAkmYGxEehnulIoLTcbX):
 def __init__(aVPqfrWzOvNAkmYGxEehnulIoLTcKD):
  aVPqfrWzOvNAkmYGxEehnulIoLTcKD.API_DOMAIN='https://apis.wavve.com'
  aVPqfrWzOvNAkmYGxEehnulIoLTcKD.WV ={}
  aVPqfrWzOvNAkmYGxEehnulIoLTcKD.Init_WV_Total()
  aVPqfrWzOvNAkmYGxEehnulIoLTcKD.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  aVPqfrWzOvNAkmYGxEehnulIoLTcKD.DEVICE ='pc'
  aVPqfrWzOvNAkmYGxEehnulIoLTcKD.DRM ='wm'
  aVPqfrWzOvNAkmYGxEehnulIoLTcKD.PARTNER ='pooq'
  aVPqfrWzOvNAkmYGxEehnulIoLTcKD.POOQZONE ='none'
  aVPqfrWzOvNAkmYGxEehnulIoLTcKD.REGION ='kor'
  aVPqfrWzOvNAkmYGxEehnulIoLTcKD.TARGETAGE ='all'
  aVPqfrWzOvNAkmYGxEehnulIoLTcKD.HTTPTAG ='https://'
  aVPqfrWzOvNAkmYGxEehnulIoLTcKD.LIST_LIMIT=30 
  aVPqfrWzOvNAkmYGxEehnulIoLTcKD.EP_LIMIT =30 
  aVPqfrWzOvNAkmYGxEehnulIoLTcKD.MV_LIMIT =24 
  aVPqfrWzOvNAkmYGxEehnulIoLTcKD.SEARCH_LIMIT=20 
  aVPqfrWzOvNAkmYGxEehnulIoLTcKD.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36'
  aVPqfrWzOvNAkmYGxEehnulIoLTcKD.DEFAULT_HEADER={'user-agent':aVPqfrWzOvNAkmYGxEehnulIoLTcKD.USER_AGENT}
 def Init_WV_Total(aVPqfrWzOvNAkmYGxEehnulIoLTcKD):
  aVPqfrWzOvNAkmYGxEehnulIoLTcKD.WV={'account':{},'cookies':{},}
 def callRequestCookies(aVPqfrWzOvNAkmYGxEehnulIoLTcKD,jobtype,aVPqfrWzOvNAkmYGxEehnulIoLTcKR,payload=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,params=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,headers=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,cookies=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,redirects=aVPqfrWzOvNAkmYGxEehnulIoLTcbp):
  aVPqfrWzOvNAkmYGxEehnulIoLTcKp=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.DEFAULT_HEADER
  if headers:aVPqfrWzOvNAkmYGxEehnulIoLTcKp.update(headers)
  if jobtype=='Get':
   aVPqfrWzOvNAkmYGxEehnulIoLTcKd=requests.get(aVPqfrWzOvNAkmYGxEehnulIoLTcKR,params=params,headers=aVPqfrWzOvNAkmYGxEehnulIoLTcKp,cookies=cookies,allow_redirects=redirects)
  else:
   aVPqfrWzOvNAkmYGxEehnulIoLTcKd=requests.post(aVPqfrWzOvNAkmYGxEehnulIoLTcKR,data=payload,params=params,headers=aVPqfrWzOvNAkmYGxEehnulIoLTcKp,cookies=cookies,allow_redirects=redirects)
  return aVPqfrWzOvNAkmYGxEehnulIoLTcKd
 def JsonFile_Save(aVPqfrWzOvNAkmYGxEehnulIoLTcKD,filename,aVPqfrWzOvNAkmYGxEehnulIoLTcKb):
  if filename=='':return aVPqfrWzOvNAkmYGxEehnulIoLTcbp
  try:
   fp=aVPqfrWzOvNAkmYGxEehnulIoLTcbd(filename,'w',-1,'utf-8')
   json.dump(aVPqfrWzOvNAkmYGxEehnulIoLTcKb,fp,indent=4,ensure_ascii=aVPqfrWzOvNAkmYGxEehnulIoLTcbp)
   fp.close()
  except:
   return aVPqfrWzOvNAkmYGxEehnulIoLTcbp
  return aVPqfrWzOvNAkmYGxEehnulIoLTcbQ
 def JsonFile_Load(aVPqfrWzOvNAkmYGxEehnulIoLTcKD,filename):
  if filename=='':return{}
  try:
   fp=aVPqfrWzOvNAkmYGxEehnulIoLTcbd(filename,'r',-1,'utf-8')
   aVPqfrWzOvNAkmYGxEehnulIoLTcKC=json.load(fp)
   fp.close()
  except:
   return{}
  return aVPqfrWzOvNAkmYGxEehnulIoLTcKC
 def Save_session_acount(aVPqfrWzOvNAkmYGxEehnulIoLTcKD,aVPqfrWzOvNAkmYGxEehnulIoLTcKJ,aVPqfrWzOvNAkmYGxEehnulIoLTcKw,aVPqfrWzOvNAkmYGxEehnulIoLTcKj):
  aVPqfrWzOvNAkmYGxEehnulIoLTcKD.WV['account']['wvid']=base64.standard_b64encode(aVPqfrWzOvNAkmYGxEehnulIoLTcKJ.encode()).decode('utf-8')
  aVPqfrWzOvNAkmYGxEehnulIoLTcKD.WV['account']['wvpw']=base64.standard_b64encode(aVPqfrWzOvNAkmYGxEehnulIoLTcKw.encode()).decode('utf-8')
  aVPqfrWzOvNAkmYGxEehnulIoLTcKD.WV['account']['wvpf']=aVPqfrWzOvNAkmYGxEehnulIoLTcKj 
 def Load_session_acount(aVPqfrWzOvNAkmYGxEehnulIoLTcKD):
  try:
   aVPqfrWzOvNAkmYGxEehnulIoLTcKJ=base64.standard_b64decode(aVPqfrWzOvNAkmYGxEehnulIoLTcKD.WV['account']['wvid']).decode('utf-8')
   aVPqfrWzOvNAkmYGxEehnulIoLTcKw=base64.standard_b64decode(aVPqfrWzOvNAkmYGxEehnulIoLTcKD.WV['account']['wvpw']).decode('utf-8')
   aVPqfrWzOvNAkmYGxEehnulIoLTcKj=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.WV['account']['wvpf']
  except:
   return '','',0
  return aVPqfrWzOvNAkmYGxEehnulIoLTcKJ,aVPqfrWzOvNAkmYGxEehnulIoLTcKw,aVPqfrWzOvNAkmYGxEehnulIoLTcKj
 def GetDefaultParams(aVPqfrWzOvNAkmYGxEehnulIoLTcKD,login=aVPqfrWzOvNAkmYGxEehnulIoLTcbQ):
  aVPqfrWzOvNAkmYGxEehnulIoLTcKB={'apikey':aVPqfrWzOvNAkmYGxEehnulIoLTcKD.APIKEY,'credential':aVPqfrWzOvNAkmYGxEehnulIoLTcKD.WV['cookies']['credential']if login else 'none','device':aVPqfrWzOvNAkmYGxEehnulIoLTcKD.DEVICE,'drm':aVPqfrWzOvNAkmYGxEehnulIoLTcKD.DRM,'partner':aVPqfrWzOvNAkmYGxEehnulIoLTcKD.PARTNER,'pooqzone':aVPqfrWzOvNAkmYGxEehnulIoLTcKD.POOQZONE,'region':aVPqfrWzOvNAkmYGxEehnulIoLTcKD.REGION,'targetage':aVPqfrWzOvNAkmYGxEehnulIoLTcKD.TARGETAGE}
  return aVPqfrWzOvNAkmYGxEehnulIoLTcKB
 def GetGUID(aVPqfrWzOvNAkmYGxEehnulIoLTcKD,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   aVPqfrWzOvNAkmYGxEehnulIoLTcKM=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   aVPqfrWzOvNAkmYGxEehnulIoLTcKt=GenerateRandomString(5)
   aVPqfrWzOvNAkmYGxEehnulIoLTcKs=aVPqfrWzOvNAkmYGxEehnulIoLTcKt+media+aVPqfrWzOvNAkmYGxEehnulIoLTcKM
   return aVPqfrWzOvNAkmYGxEehnulIoLTcKs
  def GenerateRandomString(num):
   from random import randint
   aVPqfrWzOvNAkmYGxEehnulIoLTcKy=""
   for i in aVPqfrWzOvNAkmYGxEehnulIoLTcbC(0,num):
    s=aVPqfrWzOvNAkmYGxEehnulIoLTcbJ(randint(1,5))
    aVPqfrWzOvNAkmYGxEehnulIoLTcKy+=s
   return aVPqfrWzOvNAkmYGxEehnulIoLTcKy
  aVPqfrWzOvNAkmYGxEehnulIoLTcKs=GenerateID(guid_str)
  aVPqfrWzOvNAkmYGxEehnulIoLTcKg=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.GetHash(aVPqfrWzOvNAkmYGxEehnulIoLTcKs)
  if guidType==2:
   aVPqfrWzOvNAkmYGxEehnulIoLTcKg='%s-%s-%s-%s-%s'%(aVPqfrWzOvNAkmYGxEehnulIoLTcKg[:8],aVPqfrWzOvNAkmYGxEehnulIoLTcKg[8:12],aVPqfrWzOvNAkmYGxEehnulIoLTcKg[12:16],aVPqfrWzOvNAkmYGxEehnulIoLTcKg[16:20],aVPqfrWzOvNAkmYGxEehnulIoLTcKg[20:])
  return aVPqfrWzOvNAkmYGxEehnulIoLTcKg
 def GetHash(aVPqfrWzOvNAkmYGxEehnulIoLTcKD,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return aVPqfrWzOvNAkmYGxEehnulIoLTcbJ(m.hexdigest())
 def CheckQuality(aVPqfrWzOvNAkmYGxEehnulIoLTcKD,sel_qt,qt_list):
  aVPqfrWzOvNAkmYGxEehnulIoLTcKH=0
  for aVPqfrWzOvNAkmYGxEehnulIoLTcKS in qt_list:
   if sel_qt>=aVPqfrWzOvNAkmYGxEehnulIoLTcKS:return aVPqfrWzOvNAkmYGxEehnulIoLTcKS
   aVPqfrWzOvNAkmYGxEehnulIoLTcKH=aVPqfrWzOvNAkmYGxEehnulIoLTcKS
  return aVPqfrWzOvNAkmYGxEehnulIoLTcKH
 def Get_Now_Datetime(aVPqfrWzOvNAkmYGxEehnulIoLTcKD):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(aVPqfrWzOvNAkmYGxEehnulIoLTcKD,in_text):
  aVPqfrWzOvNAkmYGxEehnulIoLTcKi=in_text.replace('&lt;','<').replace('&gt;','>')
  aVPqfrWzOvNAkmYGxEehnulIoLTcKi=aVPqfrWzOvNAkmYGxEehnulIoLTcKi.replace('$O$','')
  aVPqfrWzOvNAkmYGxEehnulIoLTcKi=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',aVPqfrWzOvNAkmYGxEehnulIoLTcKi)
  aVPqfrWzOvNAkmYGxEehnulIoLTcKi=aVPqfrWzOvNAkmYGxEehnulIoLTcKi.lstrip('#')
  return aVPqfrWzOvNAkmYGxEehnulIoLTcKi
 def GetCredential(aVPqfrWzOvNAkmYGxEehnulIoLTcKD,user_id,user_pw,user_pf):
  aVPqfrWzOvNAkmYGxEehnulIoLTcKF=aVPqfrWzOvNAkmYGxEehnulIoLTcbp
  try:
   aVPqfrWzOvNAkmYGxEehnulIoLTcKR=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.API_DOMAIN+ '/login'
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.GetDefaultParams(login=aVPqfrWzOvNAkmYGxEehnulIoLTcbp)
   aVPqfrWzOvNAkmYGxEehnulIoLTcXK={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   aVPqfrWzOvNAkmYGxEehnulIoLTcXD=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.callRequestCookies('Post',aVPqfrWzOvNAkmYGxEehnulIoLTcKR,payload=aVPqfrWzOvNAkmYGxEehnulIoLTcXK,params=aVPqfrWzOvNAkmYGxEehnulIoLTcKB,headers=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,cookies=aVPqfrWzOvNAkmYGxEehnulIoLTcbD)
   aVPqfrWzOvNAkmYGxEehnulIoLTcXp=json.loads(aVPqfrWzOvNAkmYGxEehnulIoLTcXD.text)
   aVPqfrWzOvNAkmYGxEehnulIoLTcKD.WV['cookies']['credential']=aVPqfrWzOvNAkmYGxEehnulIoLTcXp['credential']
   if user_pf!=0:
    aVPqfrWzOvNAkmYGxEehnulIoLTcXK={'id':aVPqfrWzOvNAkmYGxEehnulIoLTcKD.WV['cookies']['credential'],'password':'','profile':aVPqfrWzOvNAkmYGxEehnulIoLTcbJ(user_pf),'pushid':'','type':'credential'}
    aVPqfrWzOvNAkmYGxEehnulIoLTcKB =aVPqfrWzOvNAkmYGxEehnulIoLTcKD.GetDefaultParams(login=aVPqfrWzOvNAkmYGxEehnulIoLTcbQ) 
    aVPqfrWzOvNAkmYGxEehnulIoLTcXD=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.callRequestCookies('Post',aVPqfrWzOvNAkmYGxEehnulIoLTcKR,payload=aVPqfrWzOvNAkmYGxEehnulIoLTcXK,params=aVPqfrWzOvNAkmYGxEehnulIoLTcKB,headers=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,cookies=aVPqfrWzOvNAkmYGxEehnulIoLTcbD)
    aVPqfrWzOvNAkmYGxEehnulIoLTcXp=json.loads(aVPqfrWzOvNAkmYGxEehnulIoLTcXD.text)
    aVPqfrWzOvNAkmYGxEehnulIoLTcKD.WV['cookies']['credential']=aVPqfrWzOvNAkmYGxEehnulIoLTcXp['credential']
   aVPqfrWzOvNAkmYGxEehnulIoLTcKF=aVPqfrWzOvNAkmYGxEehnulIoLTcbQ
  except aVPqfrWzOvNAkmYGxEehnulIoLTcbw as exception:
   aVPqfrWzOvNAkmYGxEehnulIoLTcbj(exception)
   aVPqfrWzOvNAkmYGxEehnulIoLTcKD.Init_WV_Total()
  return aVPqfrWzOvNAkmYGxEehnulIoLTcKF
 def GetIssue(aVPqfrWzOvNAkmYGxEehnulIoLTcKD):
  aVPqfrWzOvNAkmYGxEehnulIoLTcXd=aVPqfrWzOvNAkmYGxEehnulIoLTcbp
  try:
   aVPqfrWzOvNAkmYGxEehnulIoLTcKR=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.API_DOMAIN+'/guid/issue'
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.GetDefaultParams()
   aVPqfrWzOvNAkmYGxEehnulIoLTcXD=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.callRequestCookies('Get',aVPqfrWzOvNAkmYGxEehnulIoLTcKR,payload=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,params=aVPqfrWzOvNAkmYGxEehnulIoLTcKB,headers=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,cookies=aVPqfrWzOvNAkmYGxEehnulIoLTcbD)
   aVPqfrWzOvNAkmYGxEehnulIoLTcXp=json.loads(aVPqfrWzOvNAkmYGxEehnulIoLTcXD.text)
   aVPqfrWzOvNAkmYGxEehnulIoLTcXb=aVPqfrWzOvNAkmYGxEehnulIoLTcXp['guid']
   aVPqfrWzOvNAkmYGxEehnulIoLTcXQ=aVPqfrWzOvNAkmYGxEehnulIoLTcXp['guidtimestamp']
   if aVPqfrWzOvNAkmYGxEehnulIoLTcXb:aVPqfrWzOvNAkmYGxEehnulIoLTcXd=aVPqfrWzOvNAkmYGxEehnulIoLTcbQ
  except aVPqfrWzOvNAkmYGxEehnulIoLTcbw as exception:
   aVPqfrWzOvNAkmYGxEehnulIoLTcbj(exception)
   aVPqfrWzOvNAkmYGxEehnulIoLTcXb='none'
   aVPqfrWzOvNAkmYGxEehnulIoLTcXQ='none' 
  aVPqfrWzOvNAkmYGxEehnulIoLTcKD.guid=aVPqfrWzOvNAkmYGxEehnulIoLTcXb
  aVPqfrWzOvNAkmYGxEehnulIoLTcKD.guidtimestamp=aVPqfrWzOvNAkmYGxEehnulIoLTcXQ
  return aVPqfrWzOvNAkmYGxEehnulIoLTcXd
 def Baseapi_Parse(aVPqfrWzOvNAkmYGxEehnulIoLTcKD,aVPqfrWzOvNAkmYGxEehnulIoLTcXj):
  try:
   aVPqfrWzOvNAkmYGxEehnulIoLTcXC =urllib.parse.urlsplit(aVPqfrWzOvNAkmYGxEehnulIoLTcXj)
   if aVPqfrWzOvNAkmYGxEehnulIoLTcXC.netloc=='':
    aVPqfrWzOvNAkmYGxEehnulIoLTcKR=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.HTTPTAG+aVPqfrWzOvNAkmYGxEehnulIoLTcXC.netloc+aVPqfrWzOvNAkmYGxEehnulIoLTcXC.path
   else:
    aVPqfrWzOvNAkmYGxEehnulIoLTcKR=aVPqfrWzOvNAkmYGxEehnulIoLTcXC.scheme+'://'+aVPqfrWzOvNAkmYGxEehnulIoLTcXC.netloc+aVPqfrWzOvNAkmYGxEehnulIoLTcXC.path
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB=aVPqfrWzOvNAkmYGxEehnulIoLTcbB(urllib.parse.parse_qsl(aVPqfrWzOvNAkmYGxEehnulIoLTcXC.query))
  except aVPqfrWzOvNAkmYGxEehnulIoLTcbw as exception:
   aVPqfrWzOvNAkmYGxEehnulIoLTcbj(exception)
   return '',{}
  return aVPqfrWzOvNAkmYGxEehnulIoLTcKR,aVPqfrWzOvNAkmYGxEehnulIoLTcKB
 def GetSupermultiUrl(aVPqfrWzOvNAkmYGxEehnulIoLTcKD,sCode,sIndex='0'):
  try:
   aVPqfrWzOvNAkmYGxEehnulIoLTcKR=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.API_DOMAIN+'/cf/supermultisections/'+sCode
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.GetDefaultParams(login=aVPqfrWzOvNAkmYGxEehnulIoLTcbp)
   aVPqfrWzOvNAkmYGxEehnulIoLTcXD=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.callRequestCookies('Get',aVPqfrWzOvNAkmYGxEehnulIoLTcKR,payload=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,params=aVPqfrWzOvNAkmYGxEehnulIoLTcKB,headers=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,cookies=aVPqfrWzOvNAkmYGxEehnulIoLTcbD)
   aVPqfrWzOvNAkmYGxEehnulIoLTcXp=json.loads(aVPqfrWzOvNAkmYGxEehnulIoLTcXD.text)
   aVPqfrWzOvNAkmYGxEehnulIoLTcXJ=aVPqfrWzOvNAkmYGxEehnulIoLTcXp['multisectionlist'][aVPqfrWzOvNAkmYGxEehnulIoLTcbM(sIndex)]['eventlist'][1]['url']
  except aVPqfrWzOvNAkmYGxEehnulIoLTcbw as exception:
   aVPqfrWzOvNAkmYGxEehnulIoLTcbj(exception)
   return ''
  return aVPqfrWzOvNAkmYGxEehnulIoLTcXJ
 def Get_LiveCatagory_List(aVPqfrWzOvNAkmYGxEehnulIoLTcKD,sCode,sIndex='0'):
  aVPqfrWzOvNAkmYGxEehnulIoLTcXw=[]
  aVPqfrWzOvNAkmYGxEehnulIoLTcXj =aVPqfrWzOvNAkmYGxEehnulIoLTcKD.GetSupermultiUrl(sCode,sIndex)
  (aVPqfrWzOvNAkmYGxEehnulIoLTcKR,aVPqfrWzOvNAkmYGxEehnulIoLTcKB)=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.Baseapi_Parse(aVPqfrWzOvNAkmYGxEehnulIoLTcXj)
  if aVPqfrWzOvNAkmYGxEehnulIoLTcKR=='':return aVPqfrWzOvNAkmYGxEehnulIoLTcXw,''
  try:
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB.update(aVPqfrWzOvNAkmYGxEehnulIoLTcKD.GetDefaultParams(login=aVPqfrWzOvNAkmYGxEehnulIoLTcbp))
   aVPqfrWzOvNAkmYGxEehnulIoLTcXD=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.callRequestCookies('Get',aVPqfrWzOvNAkmYGxEehnulIoLTcKR,payload=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,params=aVPqfrWzOvNAkmYGxEehnulIoLTcKB,headers=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,cookies=aVPqfrWzOvNAkmYGxEehnulIoLTcbD)
   aVPqfrWzOvNAkmYGxEehnulIoLTcXp=json.loads(aVPqfrWzOvNAkmYGxEehnulIoLTcXD.text)
   if not('filter_item_list' in aVPqfrWzOvNAkmYGxEehnulIoLTcXp['filter']['filterlist'][0]):return[],''
   aVPqfrWzOvNAkmYGxEehnulIoLTcXM=aVPqfrWzOvNAkmYGxEehnulIoLTcXp['filter']['filterlist'][0]['filter_item_list']
   for aVPqfrWzOvNAkmYGxEehnulIoLTcXt in aVPqfrWzOvNAkmYGxEehnulIoLTcXM:
    aVPqfrWzOvNAkmYGxEehnulIoLTcXs={'title':aVPqfrWzOvNAkmYGxEehnulIoLTcXt['title'],'genre':aVPqfrWzOvNAkmYGxEehnulIoLTcXt['api_parameters'][aVPqfrWzOvNAkmYGxEehnulIoLTcXt['api_parameters'].index('=')+1:]}
    aVPqfrWzOvNAkmYGxEehnulIoLTcXw.append(aVPqfrWzOvNAkmYGxEehnulIoLTcXs)
  except aVPqfrWzOvNAkmYGxEehnulIoLTcbw as exception:
   aVPqfrWzOvNAkmYGxEehnulIoLTcbj(exception)
   return[],''
  return aVPqfrWzOvNAkmYGxEehnulIoLTcXw,aVPqfrWzOvNAkmYGxEehnulIoLTcXj
 def Get_MainCatagory_List(aVPqfrWzOvNAkmYGxEehnulIoLTcKD,sCode,sIndex='0'):
  aVPqfrWzOvNAkmYGxEehnulIoLTcXw=[]
  aVPqfrWzOvNAkmYGxEehnulIoLTcXj =aVPqfrWzOvNAkmYGxEehnulIoLTcKD.GetSupermultiUrl(sCode,sIndex)
  (aVPqfrWzOvNAkmYGxEehnulIoLTcKR,aVPqfrWzOvNAkmYGxEehnulIoLTcKB)=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.Baseapi_Parse(aVPqfrWzOvNAkmYGxEehnulIoLTcXj)
  if aVPqfrWzOvNAkmYGxEehnulIoLTcKR=='':return aVPqfrWzOvNAkmYGxEehnulIoLTcXw
  try:
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB.update(aVPqfrWzOvNAkmYGxEehnulIoLTcKD.GetDefaultParams(login=aVPqfrWzOvNAkmYGxEehnulIoLTcbp))
   aVPqfrWzOvNAkmYGxEehnulIoLTcXD=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.callRequestCookies('Get',aVPqfrWzOvNAkmYGxEehnulIoLTcKR,payload=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,params=aVPqfrWzOvNAkmYGxEehnulIoLTcKB,headers=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,cookies=aVPqfrWzOvNAkmYGxEehnulIoLTcbD)
   aVPqfrWzOvNAkmYGxEehnulIoLTcXp=json.loads(aVPqfrWzOvNAkmYGxEehnulIoLTcXD.text)
   if not('celllist' in aVPqfrWzOvNAkmYGxEehnulIoLTcXp['band']):return[]
   aVPqfrWzOvNAkmYGxEehnulIoLTcXM=aVPqfrWzOvNAkmYGxEehnulIoLTcXp['band']['celllist']
   for aVPqfrWzOvNAkmYGxEehnulIoLTcXt in aVPqfrWzOvNAkmYGxEehnulIoLTcXM:
    aVPqfrWzOvNAkmYGxEehnulIoLTcXy =aVPqfrWzOvNAkmYGxEehnulIoLTcXt['event_list'][1]['url']
    (aVPqfrWzOvNAkmYGxEehnulIoLTcXg,aVPqfrWzOvNAkmYGxEehnulIoLTcXH)=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.Baseapi_Parse(aVPqfrWzOvNAkmYGxEehnulIoLTcXy)
    aVPqfrWzOvNAkmYGxEehnulIoLTcXs={'title':aVPqfrWzOvNAkmYGxEehnulIoLTcXt['title_list'][0]['text'],'suburl':aVPqfrWzOvNAkmYGxEehnulIoLTcXg,'subapi':aVPqfrWzOvNAkmYGxEehnulIoLTcXH.get('api'),'subtype':'catagory' if aVPqfrWzOvNAkmYGxEehnulIoLTcXH else 'supersection'}
    aVPqfrWzOvNAkmYGxEehnulIoLTcXw.append(aVPqfrWzOvNAkmYGxEehnulIoLTcXs)
  except aVPqfrWzOvNAkmYGxEehnulIoLTcbw as exception:
   aVPqfrWzOvNAkmYGxEehnulIoLTcbj(exception)
   return[]
  return aVPqfrWzOvNAkmYGxEehnulIoLTcXw
 def Get_SuperMultiSection_List(aVPqfrWzOvNAkmYGxEehnulIoLTcKD,subapi_text):
  aVPqfrWzOvNAkmYGxEehnulIoLTcXw=[]
  aVPqfrWzOvNAkmYGxEehnulIoLTcKB={}
  try:
   aVPqfrWzOvNAkmYGxEehnulIoLTcXC =urllib.parse.urlsplit(subapi_text)
   if aVPqfrWzOvNAkmYGxEehnulIoLTcXC.path.find('apis.wavve.com')>=0: 
    aVPqfrWzOvNAkmYGxEehnulIoLTcKR=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.HTTPTAG+aVPqfrWzOvNAkmYGxEehnulIoLTcXC.path 
    aVPqfrWzOvNAkmYGxEehnulIoLTcKB=aVPqfrWzOvNAkmYGxEehnulIoLTcbB(urllib.parse.parse_qsl(aVPqfrWzOvNAkmYGxEehnulIoLTcXC.query))
   else:
    aVPqfrWzOvNAkmYGxEehnulIoLTcKR=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.API_DOMAIN+'/cf'+aVPqfrWzOvNAkmYGxEehnulIoLTcXC.path 
   aVPqfrWzOvNAkmYGxEehnulIoLTcKR=aVPqfrWzOvNAkmYGxEehnulIoLTcKR.replace('supermultisection/','supermultisections/')
  except aVPqfrWzOvNAkmYGxEehnulIoLTcbw as exception:
   aVPqfrWzOvNAkmYGxEehnulIoLTcbj(exception)
   return[]
  try:
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB.update(aVPqfrWzOvNAkmYGxEehnulIoLTcKD.GetDefaultParams(login=aVPqfrWzOvNAkmYGxEehnulIoLTcbp))
   aVPqfrWzOvNAkmYGxEehnulIoLTcXD=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.callRequestCookies('Get',aVPqfrWzOvNAkmYGxEehnulIoLTcKR,payload=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,params=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,headers=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,cookies=aVPqfrWzOvNAkmYGxEehnulIoLTcbD)
   aVPqfrWzOvNAkmYGxEehnulIoLTcXp=json.loads(aVPqfrWzOvNAkmYGxEehnulIoLTcXD.text)
   if not('multisectionlist' in aVPqfrWzOvNAkmYGxEehnulIoLTcXp):return[]
   aVPqfrWzOvNAkmYGxEehnulIoLTcXM=aVPqfrWzOvNAkmYGxEehnulIoLTcXp['multisectionlist']
   for aVPqfrWzOvNAkmYGxEehnulIoLTcXt in aVPqfrWzOvNAkmYGxEehnulIoLTcXM:
    aVPqfrWzOvNAkmYGxEehnulIoLTcXS=aVPqfrWzOvNAkmYGxEehnulIoLTcXt['title']
    if aVPqfrWzOvNAkmYGxEehnulIoLTcbt(aVPqfrWzOvNAkmYGxEehnulIoLTcXS)==0:continue
    if aVPqfrWzOvNAkmYGxEehnulIoLTcXS=='minor':continue
    if re.search(u'베너',aVPqfrWzOvNAkmYGxEehnulIoLTcXS):continue
    if re.search(u'배너',aVPqfrWzOvNAkmYGxEehnulIoLTcXS):continue 
    if aVPqfrWzOvNAkmYGxEehnulIoLTcbt(aVPqfrWzOvNAkmYGxEehnulIoLTcXt['eventlist'])>=3:
     aVPqfrWzOvNAkmYGxEehnulIoLTcXH =aVPqfrWzOvNAkmYGxEehnulIoLTcXt['eventlist'][2]['url']
    else:
     aVPqfrWzOvNAkmYGxEehnulIoLTcXH =aVPqfrWzOvNAkmYGxEehnulIoLTcXt['eventlist'][1]['url']
    aVPqfrWzOvNAkmYGxEehnulIoLTcXU=aVPqfrWzOvNAkmYGxEehnulIoLTcXt['cell_type']
    if aVPqfrWzOvNAkmYGxEehnulIoLTcXU=='band_2':
     if aVPqfrWzOvNAkmYGxEehnulIoLTcXH.find('channellist=')>=0:
      aVPqfrWzOvNAkmYGxEehnulIoLTcXU='band_live'
    aVPqfrWzOvNAkmYGxEehnulIoLTcXs={'title':aVPqfrWzOvNAkmYGxEehnulIoLTcKD.Get_ChangeText(aVPqfrWzOvNAkmYGxEehnulIoLTcXS),'subapi':aVPqfrWzOvNAkmYGxEehnulIoLTcXH,'cell_type':aVPqfrWzOvNAkmYGxEehnulIoLTcXU}
    aVPqfrWzOvNAkmYGxEehnulIoLTcXw.append(aVPqfrWzOvNAkmYGxEehnulIoLTcXs)
  except aVPqfrWzOvNAkmYGxEehnulIoLTcbw as exception:
   aVPqfrWzOvNAkmYGxEehnulIoLTcbj(exception)
   return[]
  return aVPqfrWzOvNAkmYGxEehnulIoLTcXw
 def Get_BandLiveSection_List(aVPqfrWzOvNAkmYGxEehnulIoLTcKD,aVPqfrWzOvNAkmYGxEehnulIoLTcXj,page_int=1):
  aVPqfrWzOvNAkmYGxEehnulIoLTcXi=[]
  aVPqfrWzOvNAkmYGxEehnulIoLTcXF=aVPqfrWzOvNAkmYGxEehnulIoLTcDb=1
  aVPqfrWzOvNAkmYGxEehnulIoLTcXR=aVPqfrWzOvNAkmYGxEehnulIoLTcbp
  try:
   (aVPqfrWzOvNAkmYGxEehnulIoLTcKR,aVPqfrWzOvNAkmYGxEehnulIoLTcKB)=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.Baseapi_Parse(aVPqfrWzOvNAkmYGxEehnulIoLTcXj)
  except aVPqfrWzOvNAkmYGxEehnulIoLTcbw as exception:
   aVPqfrWzOvNAkmYGxEehnulIoLTcbj(exception)
   return[],aVPqfrWzOvNAkmYGxEehnulIoLTcbp
  try:
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB['limit']=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.LIST_LIMIT
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB['offset']=aVPqfrWzOvNAkmYGxEehnulIoLTcbJ((page_int-1)*aVPqfrWzOvNAkmYGxEehnulIoLTcKD.LIST_LIMIT)
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB.update(aVPqfrWzOvNAkmYGxEehnulIoLTcKD.GetDefaultParams(login=aVPqfrWzOvNAkmYGxEehnulIoLTcbp))
   aVPqfrWzOvNAkmYGxEehnulIoLTcXD=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.callRequestCookies('Get',aVPqfrWzOvNAkmYGxEehnulIoLTcKR,payload=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,params=aVPqfrWzOvNAkmYGxEehnulIoLTcKB,headers=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,cookies=aVPqfrWzOvNAkmYGxEehnulIoLTcbD)
   aVPqfrWzOvNAkmYGxEehnulIoLTcXp=json.loads(aVPqfrWzOvNAkmYGxEehnulIoLTcXD.text)
   if not('celllist' in aVPqfrWzOvNAkmYGxEehnulIoLTcXp['cell_toplist']):return[],aVPqfrWzOvNAkmYGxEehnulIoLTcbp
   aVPqfrWzOvNAkmYGxEehnulIoLTcXM=aVPqfrWzOvNAkmYGxEehnulIoLTcXp['cell_toplist']['celllist']
   for aVPqfrWzOvNAkmYGxEehnulIoLTcXt in aVPqfrWzOvNAkmYGxEehnulIoLTcXM:
    aVPqfrWzOvNAkmYGxEehnulIoLTcDK =aVPqfrWzOvNAkmYGxEehnulIoLTcXt['event_list'][1]['url']
    aVPqfrWzOvNAkmYGxEehnulIoLTcDX=urllib.parse.urlsplit(aVPqfrWzOvNAkmYGxEehnulIoLTcDK).query
    aVPqfrWzOvNAkmYGxEehnulIoLTcDX=aVPqfrWzOvNAkmYGxEehnulIoLTcbB(urllib.parse.parse_qsl(aVPqfrWzOvNAkmYGxEehnulIoLTcDX))
    aVPqfrWzOvNAkmYGxEehnulIoLTcDp='channelid'
    aVPqfrWzOvNAkmYGxEehnulIoLTcDd=aVPqfrWzOvNAkmYGxEehnulIoLTcDX[aVPqfrWzOvNAkmYGxEehnulIoLTcDp]
    aVPqfrWzOvNAkmYGxEehnulIoLTcXs={'studio':aVPqfrWzOvNAkmYGxEehnulIoLTcXt['title_list'][0]['text'],'tvshowtitle':aVPqfrWzOvNAkmYGxEehnulIoLTcKD.Get_ChangeText(aVPqfrWzOvNAkmYGxEehnulIoLTcXt['title_list'][1]['text']),'channelid':aVPqfrWzOvNAkmYGxEehnulIoLTcDd,'age':aVPqfrWzOvNAkmYGxEehnulIoLTcXt.get('age'),'thumbnail':'https://%s'%aVPqfrWzOvNAkmYGxEehnulIoLTcXt.get('thumbnail')}
    aVPqfrWzOvNAkmYGxEehnulIoLTcXi.append(aVPqfrWzOvNAkmYGxEehnulIoLTcXs)
   aVPqfrWzOvNAkmYGxEehnulIoLTcXF=aVPqfrWzOvNAkmYGxEehnulIoLTcbM(aVPqfrWzOvNAkmYGxEehnulIoLTcXp['cell_toplist']['pagecount'])
   if aVPqfrWzOvNAkmYGxEehnulIoLTcXp['cell_toplist']['count']:aVPqfrWzOvNAkmYGxEehnulIoLTcDb =aVPqfrWzOvNAkmYGxEehnulIoLTcbM(aVPqfrWzOvNAkmYGxEehnulIoLTcXp['cell_toplist']['count'])
   else:aVPqfrWzOvNAkmYGxEehnulIoLTcDb=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.LIST_LIMIT*page_int
   aVPqfrWzOvNAkmYGxEehnulIoLTcXR=aVPqfrWzOvNAkmYGxEehnulIoLTcXF>aVPqfrWzOvNAkmYGxEehnulIoLTcDb
  except aVPqfrWzOvNAkmYGxEehnulIoLTcbw as exception:
   aVPqfrWzOvNAkmYGxEehnulIoLTcbj(exception)
   return[],aVPqfrWzOvNAkmYGxEehnulIoLTcbp
  return aVPqfrWzOvNAkmYGxEehnulIoLTcXi,aVPqfrWzOvNAkmYGxEehnulIoLTcXR
 def Get_Band2Section_List(aVPqfrWzOvNAkmYGxEehnulIoLTcKD,aVPqfrWzOvNAkmYGxEehnulIoLTcXj,page_int=1):
  aVPqfrWzOvNAkmYGxEehnulIoLTcDQ=[]
  aVPqfrWzOvNAkmYGxEehnulIoLTcXF=aVPqfrWzOvNAkmYGxEehnulIoLTcDb=1
  aVPqfrWzOvNAkmYGxEehnulIoLTcXR=aVPqfrWzOvNAkmYGxEehnulIoLTcbp
  try:
   (aVPqfrWzOvNAkmYGxEehnulIoLTcKR,aVPqfrWzOvNAkmYGxEehnulIoLTcKB)=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.Baseapi_Parse(aVPqfrWzOvNAkmYGxEehnulIoLTcXj)
  except aVPqfrWzOvNAkmYGxEehnulIoLTcbw as exception:
   aVPqfrWzOvNAkmYGxEehnulIoLTcbj(exception)
   return[],aVPqfrWzOvNAkmYGxEehnulIoLTcbp
  try:
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB['came'] ='BandView'
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB['limit']=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.LIST_LIMIT
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB['offset']=aVPqfrWzOvNAkmYGxEehnulIoLTcbJ((page_int-1)*aVPqfrWzOvNAkmYGxEehnulIoLTcKD.LIST_LIMIT)
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB.update(aVPqfrWzOvNAkmYGxEehnulIoLTcKD.GetDefaultParams(login=aVPqfrWzOvNAkmYGxEehnulIoLTcbp))
   aVPqfrWzOvNAkmYGxEehnulIoLTcXD=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.callRequestCookies('Get',aVPqfrWzOvNAkmYGxEehnulIoLTcKR,payload=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,params=aVPqfrWzOvNAkmYGxEehnulIoLTcKB,headers=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,cookies=aVPqfrWzOvNAkmYGxEehnulIoLTcbD)
   aVPqfrWzOvNAkmYGxEehnulIoLTcXp=json.loads(aVPqfrWzOvNAkmYGxEehnulIoLTcXD.text)
   if not('celllist' in aVPqfrWzOvNAkmYGxEehnulIoLTcXp['cell_toplist']):return[],aVPqfrWzOvNAkmYGxEehnulIoLTcbp
   aVPqfrWzOvNAkmYGxEehnulIoLTcXM=aVPqfrWzOvNAkmYGxEehnulIoLTcXp['cell_toplist']['celllist']
   for aVPqfrWzOvNAkmYGxEehnulIoLTcXt in aVPqfrWzOvNAkmYGxEehnulIoLTcXM:
    aVPqfrWzOvNAkmYGxEehnulIoLTcDK =aVPqfrWzOvNAkmYGxEehnulIoLTcXt['event_list'][1]['url']
    aVPqfrWzOvNAkmYGxEehnulIoLTcDX=urllib.parse.urlsplit(aVPqfrWzOvNAkmYGxEehnulIoLTcDK).query
    aVPqfrWzOvNAkmYGxEehnulIoLTcDX=aVPqfrWzOvNAkmYGxEehnulIoLTcbB(urllib.parse.parse_qsl(aVPqfrWzOvNAkmYGxEehnulIoLTcDX))
    aVPqfrWzOvNAkmYGxEehnulIoLTcDp='contentid'
    aVPqfrWzOvNAkmYGxEehnulIoLTcDd=aVPqfrWzOvNAkmYGxEehnulIoLTcDX[aVPqfrWzOvNAkmYGxEehnulIoLTcDp]
    aVPqfrWzOvNAkmYGxEehnulIoLTcXs={'programtitle':aVPqfrWzOvNAkmYGxEehnulIoLTcXt['title_list'][0]['text'],'episodetitle':aVPqfrWzOvNAkmYGxEehnulIoLTcKD.Get_ChangeText(aVPqfrWzOvNAkmYGxEehnulIoLTcXt['title_list'][1]['text']),'age':aVPqfrWzOvNAkmYGxEehnulIoLTcXt.get('age'),'thumbnail':aVPqfrWzOvNAkmYGxEehnulIoLTcKD.HTTPTAG+aVPqfrWzOvNAkmYGxEehnulIoLTcXt.get('thumbnail'),'vidtype':aVPqfrWzOvNAkmYGxEehnulIoLTcDp,'videoid':aVPqfrWzOvNAkmYGxEehnulIoLTcDd}
    aVPqfrWzOvNAkmYGxEehnulIoLTcDQ.append(aVPqfrWzOvNAkmYGxEehnulIoLTcXs)
   aVPqfrWzOvNAkmYGxEehnulIoLTcXF=aVPqfrWzOvNAkmYGxEehnulIoLTcbM(aVPqfrWzOvNAkmYGxEehnulIoLTcXp['cell_toplist']['pagecount'])
   if aVPqfrWzOvNAkmYGxEehnulIoLTcXp['cell_toplist']['count']:aVPqfrWzOvNAkmYGxEehnulIoLTcDb =aVPqfrWzOvNAkmYGxEehnulIoLTcbM(aVPqfrWzOvNAkmYGxEehnulIoLTcXp['cell_toplist']['count'])
   else:aVPqfrWzOvNAkmYGxEehnulIoLTcDb=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.LIST_LIMIT*page_int
   aVPqfrWzOvNAkmYGxEehnulIoLTcXR=aVPqfrWzOvNAkmYGxEehnulIoLTcXF>aVPqfrWzOvNAkmYGxEehnulIoLTcDb
  except aVPqfrWzOvNAkmYGxEehnulIoLTcbw as exception:
   aVPqfrWzOvNAkmYGxEehnulIoLTcbj(exception)
   return[],aVPqfrWzOvNAkmYGxEehnulIoLTcbp
  return aVPqfrWzOvNAkmYGxEehnulIoLTcDQ,aVPqfrWzOvNAkmYGxEehnulIoLTcXR
 def Get_Program_List(aVPqfrWzOvNAkmYGxEehnulIoLTcKD,aVPqfrWzOvNAkmYGxEehnulIoLTcXj,page_int=1,orderby='-'):
  aVPqfrWzOvNAkmYGxEehnulIoLTcDC=[]
  aVPqfrWzOvNAkmYGxEehnulIoLTcXF=aVPqfrWzOvNAkmYGxEehnulIoLTcDb=1
  aVPqfrWzOvNAkmYGxEehnulIoLTcXR=aVPqfrWzOvNAkmYGxEehnulIoLTcbp
  (aVPqfrWzOvNAkmYGxEehnulIoLTcKR,aVPqfrWzOvNAkmYGxEehnulIoLTcKB)=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.Baseapi_Parse(aVPqfrWzOvNAkmYGxEehnulIoLTcXj)
  if aVPqfrWzOvNAkmYGxEehnulIoLTcKR=='':return aVPqfrWzOvNAkmYGxEehnulIoLTcDC,aVPqfrWzOvNAkmYGxEehnulIoLTcXR
  try:
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB['limit'] =aVPqfrWzOvNAkmYGxEehnulIoLTcKD.LIST_LIMIT
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB['offset']=aVPqfrWzOvNAkmYGxEehnulIoLTcbJ((page_int-1)*aVPqfrWzOvNAkmYGxEehnulIoLTcKD.LIST_LIMIT)
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB['page'] =aVPqfrWzOvNAkmYGxEehnulIoLTcbJ(page_int)
   if aVPqfrWzOvNAkmYGxEehnulIoLTcKB.get('orderby')!='' and aVPqfrWzOvNAkmYGxEehnulIoLTcKB.get('orderby')!='regdatefirst' and orderby!='-':
    aVPqfrWzOvNAkmYGxEehnulIoLTcKB['orderby']=orderby 
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB.update(aVPqfrWzOvNAkmYGxEehnulIoLTcKD.GetDefaultParams(login=aVPqfrWzOvNAkmYGxEehnulIoLTcbp))
   aVPqfrWzOvNAkmYGxEehnulIoLTcXD=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.callRequestCookies('Get',aVPqfrWzOvNAkmYGxEehnulIoLTcKR,payload=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,params=aVPqfrWzOvNAkmYGxEehnulIoLTcKB,headers=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,cookies=aVPqfrWzOvNAkmYGxEehnulIoLTcbD)
   aVPqfrWzOvNAkmYGxEehnulIoLTcXp=json.loads(aVPqfrWzOvNAkmYGxEehnulIoLTcXD.text)
   if aVPqfrWzOvNAkmYGxEehnulIoLTcXj.find('instantplay')>=0:
    if not('celllist' in aVPqfrWzOvNAkmYGxEehnulIoLTcXp['band']):return aVPqfrWzOvNAkmYGxEehnulIoLTcDC,aVPqfrWzOvNAkmYGxEehnulIoLTcXR
    aVPqfrWzOvNAkmYGxEehnulIoLTcXM=aVPqfrWzOvNAkmYGxEehnulIoLTcXp['band']['celllist']
   else:
    if not('celllist' in aVPqfrWzOvNAkmYGxEehnulIoLTcXp['cell_toplist']):return aVPqfrWzOvNAkmYGxEehnulIoLTcDC,aVPqfrWzOvNAkmYGxEehnulIoLTcXR
    aVPqfrWzOvNAkmYGxEehnulIoLTcXM=aVPqfrWzOvNAkmYGxEehnulIoLTcXp['cell_toplist']['celllist']
   for aVPqfrWzOvNAkmYGxEehnulIoLTcXt in aVPqfrWzOvNAkmYGxEehnulIoLTcXM:
    for aVPqfrWzOvNAkmYGxEehnulIoLTcDJ in aVPqfrWzOvNAkmYGxEehnulIoLTcXt['event_list']:
     if aVPqfrWzOvNAkmYGxEehnulIoLTcDJ.get('type')=='on-navigation':
      aVPqfrWzOvNAkmYGxEehnulIoLTcDK =aVPqfrWzOvNAkmYGxEehnulIoLTcDJ['url']
    aVPqfrWzOvNAkmYGxEehnulIoLTcDX=urllib.parse.urlsplit(aVPqfrWzOvNAkmYGxEehnulIoLTcDK).query
    aVPqfrWzOvNAkmYGxEehnulIoLTcDp=aVPqfrWzOvNAkmYGxEehnulIoLTcDX[0:aVPqfrWzOvNAkmYGxEehnulIoLTcDX.find('=')]
    aVPqfrWzOvNAkmYGxEehnulIoLTcDd=aVPqfrWzOvNAkmYGxEehnulIoLTcDX[aVPqfrWzOvNAkmYGxEehnulIoLTcDX.find('=')+1:]
    aVPqfrWzOvNAkmYGxEehnulIoLTcXs={'title':aVPqfrWzOvNAkmYGxEehnulIoLTcXt['title_list'][0]['text'],'age':aVPqfrWzOvNAkmYGxEehnulIoLTcXt['age'],'thumbnail':'https://%s'%aVPqfrWzOvNAkmYGxEehnulIoLTcXt.get('thumbnail'),'videoid':aVPqfrWzOvNAkmYGxEehnulIoLTcDd,'vidtype':aVPqfrWzOvNAkmYGxEehnulIoLTcDp}
    aVPqfrWzOvNAkmYGxEehnulIoLTcDC.append(aVPqfrWzOvNAkmYGxEehnulIoLTcXs)
   if aVPqfrWzOvNAkmYGxEehnulIoLTcXj.find('instantplay')<0:
    aVPqfrWzOvNAkmYGxEehnulIoLTcXF=aVPqfrWzOvNAkmYGxEehnulIoLTcbM(aVPqfrWzOvNAkmYGxEehnulIoLTcXp['cell_toplist']['pagecount'])
    if aVPqfrWzOvNAkmYGxEehnulIoLTcXp['cell_toplist']['count']:aVPqfrWzOvNAkmYGxEehnulIoLTcDb =aVPqfrWzOvNAkmYGxEehnulIoLTcbM(aVPqfrWzOvNAkmYGxEehnulIoLTcXp['cell_toplist']['count'])
    else:aVPqfrWzOvNAkmYGxEehnulIoLTcDb=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.LIST_LIMIT*page_int
    aVPqfrWzOvNAkmYGxEehnulIoLTcXR=aVPqfrWzOvNAkmYGxEehnulIoLTcXF>aVPqfrWzOvNAkmYGxEehnulIoLTcDb
  except aVPqfrWzOvNAkmYGxEehnulIoLTcbw as exception:
   aVPqfrWzOvNAkmYGxEehnulIoLTcbj(exception)
   return[],aVPqfrWzOvNAkmYGxEehnulIoLTcbp
  return aVPqfrWzOvNAkmYGxEehnulIoLTcDC,aVPqfrWzOvNAkmYGxEehnulIoLTcXR
 def Get_Movie_List(aVPqfrWzOvNAkmYGxEehnulIoLTcKD,aVPqfrWzOvNAkmYGxEehnulIoLTcXj,page_int=1):
  aVPqfrWzOvNAkmYGxEehnulIoLTcDw=[]
  aVPqfrWzOvNAkmYGxEehnulIoLTcXF=aVPqfrWzOvNAkmYGxEehnulIoLTcDb=1
  aVPqfrWzOvNAkmYGxEehnulIoLTcXR=aVPqfrWzOvNAkmYGxEehnulIoLTcbp
  (aVPqfrWzOvNAkmYGxEehnulIoLTcKR,aVPqfrWzOvNAkmYGxEehnulIoLTcKB)=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.Baseapi_Parse(aVPqfrWzOvNAkmYGxEehnulIoLTcXj)
  if aVPqfrWzOvNAkmYGxEehnulIoLTcKR=='':return aVPqfrWzOvNAkmYGxEehnulIoLTcDw,aVPqfrWzOvNAkmYGxEehnulIoLTcXR
  try:
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB['limit']=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.MV_LIMIT
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB['offset']=aVPqfrWzOvNAkmYGxEehnulIoLTcbJ((page_int-1)*aVPqfrWzOvNAkmYGxEehnulIoLTcKD.MV_LIMIT)
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB.update(aVPqfrWzOvNAkmYGxEehnulIoLTcKD.GetDefaultParams(login=aVPqfrWzOvNAkmYGxEehnulIoLTcbp))
   aVPqfrWzOvNAkmYGxEehnulIoLTcXD=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.callRequestCookies('Get',aVPqfrWzOvNAkmYGxEehnulIoLTcKR,payload=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,params=aVPqfrWzOvNAkmYGxEehnulIoLTcKB,headers=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,cookies=aVPqfrWzOvNAkmYGxEehnulIoLTcbD)
   aVPqfrWzOvNAkmYGxEehnulIoLTcXp=json.loads(aVPqfrWzOvNAkmYGxEehnulIoLTcXD.text)
   if not('celllist' in aVPqfrWzOvNAkmYGxEehnulIoLTcXp['cell_toplist']):return aVPqfrWzOvNAkmYGxEehnulIoLTcDw,aVPqfrWzOvNAkmYGxEehnulIoLTcXR
   aVPqfrWzOvNAkmYGxEehnulIoLTcXM=aVPqfrWzOvNAkmYGxEehnulIoLTcXp['cell_toplist']['celllist']
   for aVPqfrWzOvNAkmYGxEehnulIoLTcXt in aVPqfrWzOvNAkmYGxEehnulIoLTcXM:
    aVPqfrWzOvNAkmYGxEehnulIoLTcDK =aVPqfrWzOvNAkmYGxEehnulIoLTcXt['event_list'][1]['url']
    aVPqfrWzOvNAkmYGxEehnulIoLTcDX=urllib.parse.urlsplit(aVPqfrWzOvNAkmYGxEehnulIoLTcDK).query
    aVPqfrWzOvNAkmYGxEehnulIoLTcDp=aVPqfrWzOvNAkmYGxEehnulIoLTcDX[0:aVPqfrWzOvNAkmYGxEehnulIoLTcDX.find('=')]
    aVPqfrWzOvNAkmYGxEehnulIoLTcDd=aVPqfrWzOvNAkmYGxEehnulIoLTcDX[aVPqfrWzOvNAkmYGxEehnulIoLTcDX.find('=')+1:]
    aVPqfrWzOvNAkmYGxEehnulIoLTcXs={'title':aVPqfrWzOvNAkmYGxEehnulIoLTcXt['title_list'][0]['text'],'age':aVPqfrWzOvNAkmYGxEehnulIoLTcXt['age'],'thumbnail':'https://%s'%aVPqfrWzOvNAkmYGxEehnulIoLTcXt.get('thumbnail'),'videoid':aVPqfrWzOvNAkmYGxEehnulIoLTcDd,'vidtype':aVPqfrWzOvNAkmYGxEehnulIoLTcDp}
    aVPqfrWzOvNAkmYGxEehnulIoLTcDw.append(aVPqfrWzOvNAkmYGxEehnulIoLTcXs)
   aVPqfrWzOvNAkmYGxEehnulIoLTcXF=aVPqfrWzOvNAkmYGxEehnulIoLTcbM(aVPqfrWzOvNAkmYGxEehnulIoLTcXp['cell_toplist']['pagecount'])
   if aVPqfrWzOvNAkmYGxEehnulIoLTcXp['cell_toplist']['count']:aVPqfrWzOvNAkmYGxEehnulIoLTcDb =aVPqfrWzOvNAkmYGxEehnulIoLTcbM(aVPqfrWzOvNAkmYGxEehnulIoLTcXp['cell_toplist']['count'])
   else:aVPqfrWzOvNAkmYGxEehnulIoLTcDb=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.MV_LIMIT*page_int
   aVPqfrWzOvNAkmYGxEehnulIoLTcXR=aVPqfrWzOvNAkmYGxEehnulIoLTcXF>aVPqfrWzOvNAkmYGxEehnulIoLTcDb
  except aVPqfrWzOvNAkmYGxEehnulIoLTcbw as exception:
   aVPqfrWzOvNAkmYGxEehnulIoLTcbj(exception)
   return[],aVPqfrWzOvNAkmYGxEehnulIoLTcbp
  return aVPqfrWzOvNAkmYGxEehnulIoLTcDw,aVPqfrWzOvNAkmYGxEehnulIoLTcXR
 def ProgramidToContentid(aVPqfrWzOvNAkmYGxEehnulIoLTcKD,aVPqfrWzOvNAkmYGxEehnulIoLTcDM):
  aVPqfrWzOvNAkmYGxEehnulIoLTcDj=''
  try:
   aVPqfrWzOvNAkmYGxEehnulIoLTcKR =aVPqfrWzOvNAkmYGxEehnulIoLTcKD.API_DOMAIN+'/vod/programs-contentid/'+aVPqfrWzOvNAkmYGxEehnulIoLTcDM
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.GetDefaultParams(login=aVPqfrWzOvNAkmYGxEehnulIoLTcbp)
   aVPqfrWzOvNAkmYGxEehnulIoLTcXD=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.callRequestCookies('Get',aVPqfrWzOvNAkmYGxEehnulIoLTcKR,payload=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,params=aVPqfrWzOvNAkmYGxEehnulIoLTcKB,headers=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,cookies=aVPqfrWzOvNAkmYGxEehnulIoLTcbD)
   aVPqfrWzOvNAkmYGxEehnulIoLTcDB=json.loads(aVPqfrWzOvNAkmYGxEehnulIoLTcXD.text)
   if not('contentid' in aVPqfrWzOvNAkmYGxEehnulIoLTcDB):return aVPqfrWzOvNAkmYGxEehnulIoLTcDj 
   aVPqfrWzOvNAkmYGxEehnulIoLTcDj=aVPqfrWzOvNAkmYGxEehnulIoLTcDB['contentid']
  except aVPqfrWzOvNAkmYGxEehnulIoLTcbw as exception:
   aVPqfrWzOvNAkmYGxEehnulIoLTcbj(exception)
  return aVPqfrWzOvNAkmYGxEehnulIoLTcDj
 def ContentidToProgramid(aVPqfrWzOvNAkmYGxEehnulIoLTcKD,aVPqfrWzOvNAkmYGxEehnulIoLTcDj):
  aVPqfrWzOvNAkmYGxEehnulIoLTcDM=''
  try:
   aVPqfrWzOvNAkmYGxEehnulIoLTcKR =aVPqfrWzOvNAkmYGxEehnulIoLTcKD.API_DOMAIN+'/cf/vod/contents/'+aVPqfrWzOvNAkmYGxEehnulIoLTcDj
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.GetDefaultParams(login=aVPqfrWzOvNAkmYGxEehnulIoLTcbp)
   aVPqfrWzOvNAkmYGxEehnulIoLTcXD=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.callRequestCookies('Get',aVPqfrWzOvNAkmYGxEehnulIoLTcKR,payload=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,params=aVPqfrWzOvNAkmYGxEehnulIoLTcKB,headers=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,cookies=aVPqfrWzOvNAkmYGxEehnulIoLTcbD)
   aVPqfrWzOvNAkmYGxEehnulIoLTcDB=json.loads(aVPqfrWzOvNAkmYGxEehnulIoLTcXD.text)
   if not('programid' in aVPqfrWzOvNAkmYGxEehnulIoLTcDB):return aVPqfrWzOvNAkmYGxEehnulIoLTcDM 
   aVPqfrWzOvNAkmYGxEehnulIoLTcDM=aVPqfrWzOvNAkmYGxEehnulIoLTcDB['programid']
  except aVPqfrWzOvNAkmYGxEehnulIoLTcbw as exception:
   aVPqfrWzOvNAkmYGxEehnulIoLTcbj(exception)
  return aVPqfrWzOvNAkmYGxEehnulIoLTcDM
 def GetProgramInfo(aVPqfrWzOvNAkmYGxEehnulIoLTcKD,program_code):
  aVPqfrWzOvNAkmYGxEehnulIoLTcDt={}
  try:
   aVPqfrWzOvNAkmYGxEehnulIoLTcKR=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.API_DOMAIN+'/cf/vod/contents/'+program_code
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.GetDefaultParams(login=aVPqfrWzOvNAkmYGxEehnulIoLTcbp)
   aVPqfrWzOvNAkmYGxEehnulIoLTcXD=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.callRequestCookies('Get',aVPqfrWzOvNAkmYGxEehnulIoLTcKR,payload=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,params=aVPqfrWzOvNAkmYGxEehnulIoLTcKB,headers=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,cookies=aVPqfrWzOvNAkmYGxEehnulIoLTcbD)
   aVPqfrWzOvNAkmYGxEehnulIoLTcDB=json.loads(aVPqfrWzOvNAkmYGxEehnulIoLTcXD.text)
   aVPqfrWzOvNAkmYGxEehnulIoLTcbj(aVPqfrWzOvNAkmYGxEehnulIoLTcDB)
   aVPqfrWzOvNAkmYGxEehnulIoLTcDs=img_fanart=aVPqfrWzOvNAkmYGxEehnulIoLTcDy=''
   if aVPqfrWzOvNAkmYGxEehnulIoLTcDB.get('programposterimage')!='':aVPqfrWzOvNAkmYGxEehnulIoLTcDs =aVPqfrWzOvNAkmYGxEehnulIoLTcKD.HTTPTAG+aVPqfrWzOvNAkmYGxEehnulIoLTcDB.get('programposterimage')
   if aVPqfrWzOvNAkmYGxEehnulIoLTcDB.get('programimage') !='':img_fanart =aVPqfrWzOvNAkmYGxEehnulIoLTcKD.HTTPTAG+aVPqfrWzOvNAkmYGxEehnulIoLTcDB.get('programimage')
   if aVPqfrWzOvNAkmYGxEehnulIoLTcDB.get('programcirlceimage')!='':aVPqfrWzOvNAkmYGxEehnulIoLTcDy=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.HTTPTAG+aVPqfrWzOvNAkmYGxEehnulIoLTcDB.get('programcirlceimage')
   if 'poster_default' in aVPqfrWzOvNAkmYGxEehnulIoLTcDs:
    aVPqfrWzOvNAkmYGxEehnulIoLTcDs =img_fanart
    aVPqfrWzOvNAkmYGxEehnulIoLTcDy=''
   aVPqfrWzOvNAkmYGxEehnulIoLTcDt={'imgPoster':aVPqfrWzOvNAkmYGxEehnulIoLTcDs,'imgFanart':img_fanart,'imgClearlogo':aVPqfrWzOvNAkmYGxEehnulIoLTcDy}
  except aVPqfrWzOvNAkmYGxEehnulIoLTcbw as exception:
   aVPqfrWzOvNAkmYGxEehnulIoLTcbj(exception)
  return aVPqfrWzOvNAkmYGxEehnulIoLTcDt
 def Get_Episode_List(aVPqfrWzOvNAkmYGxEehnulIoLTcKD,aVPqfrWzOvNAkmYGxEehnulIoLTcDd,aVPqfrWzOvNAkmYGxEehnulIoLTcDp,page_int=1,orderby='desc'):
  aVPqfrWzOvNAkmYGxEehnulIoLTcDg=[]
  aVPqfrWzOvNAkmYGxEehnulIoLTcXF=aVPqfrWzOvNAkmYGxEehnulIoLTcDb=1
  aVPqfrWzOvNAkmYGxEehnulIoLTcXR=aVPqfrWzOvNAkmYGxEehnulIoLTcbp
  aVPqfrWzOvNAkmYGxEehnulIoLTcDH={}
  if aVPqfrWzOvNAkmYGxEehnulIoLTcDp=='contentid':
   aVPqfrWzOvNAkmYGxEehnulIoLTcDM=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.ContentidToProgramid(aVPqfrWzOvNAkmYGxEehnulIoLTcDd)
   aVPqfrWzOvNAkmYGxEehnulIoLTcDH=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.GetProgramInfo(aVPqfrWzOvNAkmYGxEehnulIoLTcDd)
  else:
   aVPqfrWzOvNAkmYGxEehnulIoLTcDM=aVPqfrWzOvNAkmYGxEehnulIoLTcDd
   aVPqfrWzOvNAkmYGxEehnulIoLTcDj=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.ProgramidToContentid(aVPqfrWzOvNAkmYGxEehnulIoLTcDd)
   if aVPqfrWzOvNAkmYGxEehnulIoLTcDj!='':aVPqfrWzOvNAkmYGxEehnulIoLTcDH=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.GetProgramInfo(aVPqfrWzOvNAkmYGxEehnulIoLTcDj)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   aVPqfrWzOvNAkmYGxEehnulIoLTcKR=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.API_DOMAIN+'/vod/programs-contents/'+aVPqfrWzOvNAkmYGxEehnulIoLTcDM
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB={}
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB['limit'] =aVPqfrWzOvNAkmYGxEehnulIoLTcKD.EP_LIMIT
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB['offset']=aVPqfrWzOvNAkmYGxEehnulIoLTcbJ((page_int-1)*aVPqfrWzOvNAkmYGxEehnulIoLTcKD.EP_LIMIT)
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB['orderby']=orderby 
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB.update(aVPqfrWzOvNAkmYGxEehnulIoLTcKD.GetDefaultParams(login=aVPqfrWzOvNAkmYGxEehnulIoLTcbp))
   aVPqfrWzOvNAkmYGxEehnulIoLTcXD=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.callRequestCookies('Get',aVPqfrWzOvNAkmYGxEehnulIoLTcKR,payload=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,params=aVPqfrWzOvNAkmYGxEehnulIoLTcKB,headers=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,cookies=aVPqfrWzOvNAkmYGxEehnulIoLTcbD)
   aVPqfrWzOvNAkmYGxEehnulIoLTcXp=json.loads(aVPqfrWzOvNAkmYGxEehnulIoLTcXD.text)
   aVPqfrWzOvNAkmYGxEehnulIoLTcXM=aVPqfrWzOvNAkmYGxEehnulIoLTcXp['list']
   for aVPqfrWzOvNAkmYGxEehnulIoLTcXt in aVPqfrWzOvNAkmYGxEehnulIoLTcXM:
    aVPqfrWzOvNAkmYGxEehnulIoLTcDU=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',aVPqfrWzOvNAkmYGxEehnulIoLTcXt.get('synopsis'))
    aVPqfrWzOvNAkmYGxEehnulIoLTcDi=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.HTTPTAG+aVPqfrWzOvNAkmYGxEehnulIoLTcXt.get('image')
    aVPqfrWzOvNAkmYGxEehnulIoLTcDF=aVPqfrWzOvNAkmYGxEehnulIoLTcDR=aVPqfrWzOvNAkmYGxEehnulIoLTcpK=''
    if aVPqfrWzOvNAkmYGxEehnulIoLTcDH!={}:
     aVPqfrWzOvNAkmYGxEehnulIoLTcDF =aVPqfrWzOvNAkmYGxEehnulIoLTcDH.get('imgPoster')
     aVPqfrWzOvNAkmYGxEehnulIoLTcDR =aVPqfrWzOvNAkmYGxEehnulIoLTcDH.get('imgFanart')
     aVPqfrWzOvNAkmYGxEehnulIoLTcpK=aVPqfrWzOvNAkmYGxEehnulIoLTcDH.get('imgClearlogo')
     aVPqfrWzOvNAkmYGxEehnulIoLTcpX={'thumb':aVPqfrWzOvNAkmYGxEehnulIoLTcDi,'poster':aVPqfrWzOvNAkmYGxEehnulIoLTcDF,'fanart':aVPqfrWzOvNAkmYGxEehnulIoLTcDR,'clearlogo':aVPqfrWzOvNAkmYGxEehnulIoLTcpK}
    else:
     aVPqfrWzOvNAkmYGxEehnulIoLTcpX=aVPqfrWzOvNAkmYGxEehnulIoLTcDi
    aVPqfrWzOvNAkmYGxEehnulIoLTcXs={'programtitle':aVPqfrWzOvNAkmYGxEehnulIoLTcXt.get('programtitle'),'episodetitle':aVPqfrWzOvNAkmYGxEehnulIoLTcXt.get('episodetitle'),'episodenumber':aVPqfrWzOvNAkmYGxEehnulIoLTcXt.get('episodenumber'),'releasedate':aVPqfrWzOvNAkmYGxEehnulIoLTcXt.get('releasedate'),'releaseweekday':aVPqfrWzOvNAkmYGxEehnulIoLTcXt.get('releaseweekday'),'programid':aVPqfrWzOvNAkmYGxEehnulIoLTcXt.get('programid'),'contentid':aVPqfrWzOvNAkmYGxEehnulIoLTcXt.get('contentid'),'age':aVPqfrWzOvNAkmYGxEehnulIoLTcXt.get('targetage'),'playtime':aVPqfrWzOvNAkmYGxEehnulIoLTcXt.get('playtime'),'synopsis':aVPqfrWzOvNAkmYGxEehnulIoLTcDU,'episodeactors':aVPqfrWzOvNAkmYGxEehnulIoLTcXt.get('episodeactors').split(',')if aVPqfrWzOvNAkmYGxEehnulIoLTcXt.get('episodeactors')!='' else[],'thumbnail':aVPqfrWzOvNAkmYGxEehnulIoLTcpX}
    aVPqfrWzOvNAkmYGxEehnulIoLTcDg.append(aVPqfrWzOvNAkmYGxEehnulIoLTcXs)
   aVPqfrWzOvNAkmYGxEehnulIoLTcXF=aVPqfrWzOvNAkmYGxEehnulIoLTcbM(aVPqfrWzOvNAkmYGxEehnulIoLTcXp['pagecount'])
   if aVPqfrWzOvNAkmYGxEehnulIoLTcXp['count']:aVPqfrWzOvNAkmYGxEehnulIoLTcDb =aVPqfrWzOvNAkmYGxEehnulIoLTcbM(aVPqfrWzOvNAkmYGxEehnulIoLTcXp['count'])
   else:aVPqfrWzOvNAkmYGxEehnulIoLTcDb=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.EP_LIMIT*page_int
   aVPqfrWzOvNAkmYGxEehnulIoLTcXR=aVPqfrWzOvNAkmYGxEehnulIoLTcXF>aVPqfrWzOvNAkmYGxEehnulIoLTcDb
  except aVPqfrWzOvNAkmYGxEehnulIoLTcbw as exception:
   aVPqfrWzOvNAkmYGxEehnulIoLTcbj(exception)
   return[],aVPqfrWzOvNAkmYGxEehnulIoLTcbp
  return aVPqfrWzOvNAkmYGxEehnulIoLTcDg,aVPqfrWzOvNAkmYGxEehnulIoLTcXR
 def GetEPGList(aVPqfrWzOvNAkmYGxEehnulIoLTcKD,genre):
  aVPqfrWzOvNAkmYGxEehnulIoLTcpD={}
  try:
   aVPqfrWzOvNAkmYGxEehnulIoLTcpd=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.Get_Now_Datetime()
   if genre=='all':
    aVPqfrWzOvNAkmYGxEehnulIoLTcpb =aVPqfrWzOvNAkmYGxEehnulIoLTcpd+datetime.timedelta(hours=3)
   else:
    aVPqfrWzOvNAkmYGxEehnulIoLTcpb =aVPqfrWzOvNAkmYGxEehnulIoLTcpd+datetime.timedelta(hours=3)
   aVPqfrWzOvNAkmYGxEehnulIoLTcKR=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.API_DOMAIN+'/live/epgs'
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB={'limit':'100','offset':'0','genre':genre,'startdatetime':aVPqfrWzOvNAkmYGxEehnulIoLTcpd.strftime('%Y-%m-%d %H:00'),'enddatetime':aVPqfrWzOvNAkmYGxEehnulIoLTcpb.strftime('%Y-%m-%d %H:00')}
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB.update(aVPqfrWzOvNAkmYGxEehnulIoLTcKD.GetDefaultParams(login=aVPqfrWzOvNAkmYGxEehnulIoLTcbp))
   aVPqfrWzOvNAkmYGxEehnulIoLTcXD=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.callRequestCookies('Get',aVPqfrWzOvNAkmYGxEehnulIoLTcKR,payload=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,params=aVPqfrWzOvNAkmYGxEehnulIoLTcKB,headers=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,cookies=aVPqfrWzOvNAkmYGxEehnulIoLTcbD)
   aVPqfrWzOvNAkmYGxEehnulIoLTcXp=json.loads(aVPqfrWzOvNAkmYGxEehnulIoLTcXD.text)
   aVPqfrWzOvNAkmYGxEehnulIoLTcpQ=aVPqfrWzOvNAkmYGxEehnulIoLTcXp['list']
   for aVPqfrWzOvNAkmYGxEehnulIoLTcXt in aVPqfrWzOvNAkmYGxEehnulIoLTcpQ:
    aVPqfrWzOvNAkmYGxEehnulIoLTcpC=''
    for aVPqfrWzOvNAkmYGxEehnulIoLTcpJ in aVPqfrWzOvNAkmYGxEehnulIoLTcXt['list']:
     if aVPqfrWzOvNAkmYGxEehnulIoLTcpC:aVPqfrWzOvNAkmYGxEehnulIoLTcpC+='\n'
     aVPqfrWzOvNAkmYGxEehnulIoLTcpC+=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.Get_ChangeText(aVPqfrWzOvNAkmYGxEehnulIoLTcpJ['title'])+'\n'
     aVPqfrWzOvNAkmYGxEehnulIoLTcpC+=' [%s ~ %s]'%(aVPqfrWzOvNAkmYGxEehnulIoLTcpJ['starttime'][-5:],aVPqfrWzOvNAkmYGxEehnulIoLTcpJ['endtime'][-5:])+'\n'
    aVPqfrWzOvNAkmYGxEehnulIoLTcpD[aVPqfrWzOvNAkmYGxEehnulIoLTcXt['channelid']]=aVPqfrWzOvNAkmYGxEehnulIoLTcpC
  except aVPqfrWzOvNAkmYGxEehnulIoLTcbw as exception:
   aVPqfrWzOvNAkmYGxEehnulIoLTcbj(exception)
  return aVPqfrWzOvNAkmYGxEehnulIoLTcpD
 def Get_LiveChannel_List(aVPqfrWzOvNAkmYGxEehnulIoLTcKD,genre,aVPqfrWzOvNAkmYGxEehnulIoLTcXj):
  aVPqfrWzOvNAkmYGxEehnulIoLTcXi=[]
  (aVPqfrWzOvNAkmYGxEehnulIoLTcKR,aVPqfrWzOvNAkmYGxEehnulIoLTcKB)=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.Baseapi_Parse(aVPqfrWzOvNAkmYGxEehnulIoLTcXj)
  if aVPqfrWzOvNAkmYGxEehnulIoLTcKR=='':return aVPqfrWzOvNAkmYGxEehnulIoLTcXi
  aVPqfrWzOvNAkmYGxEehnulIoLTcpw=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.GetEPGList(genre)
  try:
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB.update(aVPqfrWzOvNAkmYGxEehnulIoLTcKD.GetDefaultParams(login=aVPqfrWzOvNAkmYGxEehnulIoLTcbp))
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB['genre']=genre
   aVPqfrWzOvNAkmYGxEehnulIoLTcXD=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.callRequestCookies('Get',aVPqfrWzOvNAkmYGxEehnulIoLTcKR,payload=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,params=aVPqfrWzOvNAkmYGxEehnulIoLTcKB,headers=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,cookies=aVPqfrWzOvNAkmYGxEehnulIoLTcbD)
   aVPqfrWzOvNAkmYGxEehnulIoLTcXp=json.loads(aVPqfrWzOvNAkmYGxEehnulIoLTcXD.text)
   if not('celllist' in aVPqfrWzOvNAkmYGxEehnulIoLTcXp['cell_toplist']):return[]
   aVPqfrWzOvNAkmYGxEehnulIoLTcXM=aVPqfrWzOvNAkmYGxEehnulIoLTcXp['cell_toplist']['celllist']
   for aVPqfrWzOvNAkmYGxEehnulIoLTcXt in aVPqfrWzOvNAkmYGxEehnulIoLTcXM:
    aVPqfrWzOvNAkmYGxEehnulIoLTcDj=aVPqfrWzOvNAkmYGxEehnulIoLTcXt['contentid']
    if aVPqfrWzOvNAkmYGxEehnulIoLTcDj in aVPqfrWzOvNAkmYGxEehnulIoLTcpw:
     aVPqfrWzOvNAkmYGxEehnulIoLTcpj=aVPqfrWzOvNAkmYGxEehnulIoLTcpw[aVPqfrWzOvNAkmYGxEehnulIoLTcDj]
    else:
     aVPqfrWzOvNAkmYGxEehnulIoLTcpj=''
    aVPqfrWzOvNAkmYGxEehnulIoLTcXs={'studio':aVPqfrWzOvNAkmYGxEehnulIoLTcXt['title_list'][0]['text'],'tvshowtitle':aVPqfrWzOvNAkmYGxEehnulIoLTcKD.Get_ChangeText(aVPqfrWzOvNAkmYGxEehnulIoLTcXt['title_list'][1]['text']),'channelid':aVPqfrWzOvNAkmYGxEehnulIoLTcDj,'age':aVPqfrWzOvNAkmYGxEehnulIoLTcXt['age'],'thumbnail':'https://%s'%aVPqfrWzOvNAkmYGxEehnulIoLTcXt.get('thumbnail'),'epg':aVPqfrWzOvNAkmYGxEehnulIoLTcpj}
    aVPqfrWzOvNAkmYGxEehnulIoLTcXi.append(aVPqfrWzOvNAkmYGxEehnulIoLTcXs)
  except aVPqfrWzOvNAkmYGxEehnulIoLTcbw as exception:
   aVPqfrWzOvNAkmYGxEehnulIoLTcbj(exception)
   return[]
  return aVPqfrWzOvNAkmYGxEehnulIoLTcXi
 def Get_Search_List(aVPqfrWzOvNAkmYGxEehnulIoLTcKD,search_key,sType,page_int,exclusion21=aVPqfrWzOvNAkmYGxEehnulIoLTcbp):
  aVPqfrWzOvNAkmYGxEehnulIoLTcpB=[]
  aVPqfrWzOvNAkmYGxEehnulIoLTcXF=aVPqfrWzOvNAkmYGxEehnulIoLTcDb=1
  aVPqfrWzOvNAkmYGxEehnulIoLTcXR=aVPqfrWzOvNAkmYGxEehnulIoLTcbp
  try:
   aVPqfrWzOvNAkmYGxEehnulIoLTcKR=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.API_DOMAIN+'/cf/search/list.js'
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':aVPqfrWzOvNAkmYGxEehnulIoLTcbJ((page_int-1)*aVPqfrWzOvNAkmYGxEehnulIoLTcKD.SEARCH_LIMIT),'limit':aVPqfrWzOvNAkmYGxEehnulIoLTcKD.SEARCH_LIMIT,'orderby':'score'}
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB.update(aVPqfrWzOvNAkmYGxEehnulIoLTcKD.GetDefaultParams(login=aVPqfrWzOvNAkmYGxEehnulIoLTcbp))
   aVPqfrWzOvNAkmYGxEehnulIoLTcXD=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.callRequestCookies('Get',aVPqfrWzOvNAkmYGxEehnulIoLTcKR,payload=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,params=aVPqfrWzOvNAkmYGxEehnulIoLTcKB,headers=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,cookies=aVPqfrWzOvNAkmYGxEehnulIoLTcbD)
   aVPqfrWzOvNAkmYGxEehnulIoLTcDB=json.loads(aVPqfrWzOvNAkmYGxEehnulIoLTcXD.text)
   if not('celllist' in aVPqfrWzOvNAkmYGxEehnulIoLTcDB['cell_toplist']):return aVPqfrWzOvNAkmYGxEehnulIoLTcpB,aVPqfrWzOvNAkmYGxEehnulIoLTcXR
   aVPqfrWzOvNAkmYGxEehnulIoLTcXM=aVPqfrWzOvNAkmYGxEehnulIoLTcDB['cell_toplist']['celllist']
   for aVPqfrWzOvNAkmYGxEehnulIoLTcXt in aVPqfrWzOvNAkmYGxEehnulIoLTcXM:
    aVPqfrWzOvNAkmYGxEehnulIoLTcDK =aVPqfrWzOvNAkmYGxEehnulIoLTcXt['event_list'][1]['url']
    aVPqfrWzOvNAkmYGxEehnulIoLTcDX=urllib.parse.urlsplit(aVPqfrWzOvNAkmYGxEehnulIoLTcDK).query
    aVPqfrWzOvNAkmYGxEehnulIoLTcDp=aVPqfrWzOvNAkmYGxEehnulIoLTcDX[0:aVPqfrWzOvNAkmYGxEehnulIoLTcDX.find('=')]
    aVPqfrWzOvNAkmYGxEehnulIoLTcDd=aVPqfrWzOvNAkmYGxEehnulIoLTcDX[aVPqfrWzOvNAkmYGxEehnulIoLTcDX.find('=')+1:]
    aVPqfrWzOvNAkmYGxEehnulIoLTcXs={'title':aVPqfrWzOvNAkmYGxEehnulIoLTcXt['title_list'][0]['text'],'age':aVPqfrWzOvNAkmYGxEehnulIoLTcXt['age'],'thumbnail':'https://%s'%aVPqfrWzOvNAkmYGxEehnulIoLTcXt.get('thumbnail'),'videoid':aVPqfrWzOvNAkmYGxEehnulIoLTcDd,'vidtype':aVPqfrWzOvNAkmYGxEehnulIoLTcDp}
    if exclusion21==aVPqfrWzOvNAkmYGxEehnulIoLTcbp or aVPqfrWzOvNAkmYGxEehnulIoLTcXt.get('age')!='21':
     aVPqfrWzOvNAkmYGxEehnulIoLTcpB.append(aVPqfrWzOvNAkmYGxEehnulIoLTcXs)
   aVPqfrWzOvNAkmYGxEehnulIoLTcXF=aVPqfrWzOvNAkmYGxEehnulIoLTcbM(aVPqfrWzOvNAkmYGxEehnulIoLTcDB['cell_toplist']['pagecount'])
   if aVPqfrWzOvNAkmYGxEehnulIoLTcDB['cell_toplist']['count']:aVPqfrWzOvNAkmYGxEehnulIoLTcDb =aVPqfrWzOvNAkmYGxEehnulIoLTcbM(aVPqfrWzOvNAkmYGxEehnulIoLTcDB['cell_toplist']['count'])
   else:aVPqfrWzOvNAkmYGxEehnulIoLTcDb=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.LIST_LIMIT
   aVPqfrWzOvNAkmYGxEehnulIoLTcXR=aVPqfrWzOvNAkmYGxEehnulIoLTcXF>aVPqfrWzOvNAkmYGxEehnulIoLTcDb
  except aVPqfrWzOvNAkmYGxEehnulIoLTcbw as exception:
   aVPqfrWzOvNAkmYGxEehnulIoLTcbj(exception)
  return aVPqfrWzOvNAkmYGxEehnulIoLTcpB,aVPqfrWzOvNAkmYGxEehnulIoLTcXR 
 def GetStreamingURL(aVPqfrWzOvNAkmYGxEehnulIoLTcKD,mode,aVPqfrWzOvNAkmYGxEehnulIoLTcDj,quality_int,pvrmode='-'):
  aVPqfrWzOvNAkmYGxEehnulIoLTcpM=aVPqfrWzOvNAkmYGxEehnulIoLTcpi=aVPqfrWzOvNAkmYGxEehnulIoLTcpF=streaming_preview=''
  aVPqfrWzOvNAkmYGxEehnulIoLTcpt=[]
  aVPqfrWzOvNAkmYGxEehnulIoLTcps='hls'
  if mode=='LIVE':
   aVPqfrWzOvNAkmYGxEehnulIoLTcKR =aVPqfrWzOvNAkmYGxEehnulIoLTcKD.API_DOMAIN+'/live/channels/'+aVPqfrWzOvNAkmYGxEehnulIoLTcDj
   aVPqfrWzOvNAkmYGxEehnulIoLTcpy='live'
  elif mode=='VOD':
   aVPqfrWzOvNAkmYGxEehnulIoLTcKR =aVPqfrWzOvNAkmYGxEehnulIoLTcKD.API_DOMAIN+'/cf/vod/contents/'+aVPqfrWzOvNAkmYGxEehnulIoLTcDj
   aVPqfrWzOvNAkmYGxEehnulIoLTcpy='vod'
  elif mode=='MOVIE':
   aVPqfrWzOvNAkmYGxEehnulIoLTcKR =aVPqfrWzOvNAkmYGxEehnulIoLTcKD.API_DOMAIN+'/cf/movie/contents/'+aVPqfrWzOvNAkmYGxEehnulIoLTcDj
   aVPqfrWzOvNAkmYGxEehnulIoLTcpy='movie'
  try:
   if mode!='LIVE' or pvrmode=='-':
    aVPqfrWzOvNAkmYGxEehnulIoLTcKB=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.GetDefaultParams(login=aVPqfrWzOvNAkmYGxEehnulIoLTcbp)
    aVPqfrWzOvNAkmYGxEehnulIoLTcXD=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.callRequestCookies('Get',aVPqfrWzOvNAkmYGxEehnulIoLTcKR,payload=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,params=aVPqfrWzOvNAkmYGxEehnulIoLTcKB,headers=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,cookies=aVPqfrWzOvNAkmYGxEehnulIoLTcbD)
    aVPqfrWzOvNAkmYGxEehnulIoLTcXp=json.loads(aVPqfrWzOvNAkmYGxEehnulIoLTcXD.text)
    aVPqfrWzOvNAkmYGxEehnulIoLTcpg=aVPqfrWzOvNAkmYGxEehnulIoLTcXp['qualities']['list']
    if aVPqfrWzOvNAkmYGxEehnulIoLTcpg==aVPqfrWzOvNAkmYGxEehnulIoLTcbD:return(aVPqfrWzOvNAkmYGxEehnulIoLTcpM,aVPqfrWzOvNAkmYGxEehnulIoLTcpi,aVPqfrWzOvNAkmYGxEehnulIoLTcpF,streaming_preview)
    for aVPqfrWzOvNAkmYGxEehnulIoLTcpH in aVPqfrWzOvNAkmYGxEehnulIoLTcpg:
     aVPqfrWzOvNAkmYGxEehnulIoLTcpt.append(aVPqfrWzOvNAkmYGxEehnulIoLTcbM(aVPqfrWzOvNAkmYGxEehnulIoLTcpH.get('id').rstrip('p')))
    if 'type' in aVPqfrWzOvNAkmYGxEehnulIoLTcXp:
     if aVPqfrWzOvNAkmYGxEehnulIoLTcXp['type']=='onair':
      aVPqfrWzOvNAkmYGxEehnulIoLTcpy='onairvod'
    if 'drms' in aVPqfrWzOvNAkmYGxEehnulIoLTcXp:
     if aVPqfrWzOvNAkmYGxEehnulIoLTcXp['drms']:
      aVPqfrWzOvNAkmYGxEehnulIoLTcps='dash'
  except aVPqfrWzOvNAkmYGxEehnulIoLTcbw as exception:
   aVPqfrWzOvNAkmYGxEehnulIoLTcbj(exception)
   return(aVPqfrWzOvNAkmYGxEehnulIoLTcpM,aVPqfrWzOvNAkmYGxEehnulIoLTcpi,aVPqfrWzOvNAkmYGxEehnulIoLTcpF,streaming_preview)
  try:
   aVPqfrWzOvNAkmYGxEehnulIoLTcpS=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.CheckQuality(quality_int,aVPqfrWzOvNAkmYGxEehnulIoLTcpt)
   if mode=='LIVE' and pvrmode!='-':
    aVPqfrWzOvNAkmYGxEehnulIoLTcpU='auto'
   else:
    aVPqfrWzOvNAkmYGxEehnulIoLTcpU=aVPqfrWzOvNAkmYGxEehnulIoLTcbJ(aVPqfrWzOvNAkmYGxEehnulIoLTcpS)+'p'
   aVPqfrWzOvNAkmYGxEehnulIoLTcKR=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.API_DOMAIN+'/streaming'
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB={'contentid':aVPqfrWzOvNAkmYGxEehnulIoLTcDj,'contenttype':aVPqfrWzOvNAkmYGxEehnulIoLTcpy,'action':aVPqfrWzOvNAkmYGxEehnulIoLTcps,'quality':aVPqfrWzOvNAkmYGxEehnulIoLTcpU,'deviceModelId':'Windows 10','guid':aVPqfrWzOvNAkmYGxEehnulIoLTcKD.GetGUID(guidType=2),'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n'}
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB.update(aVPqfrWzOvNAkmYGxEehnulIoLTcKD.GetDefaultParams(login=aVPqfrWzOvNAkmYGxEehnulIoLTcbQ))
   aVPqfrWzOvNAkmYGxEehnulIoLTcXD=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.callRequestCookies('Get',aVPqfrWzOvNAkmYGxEehnulIoLTcKR,payload=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,params=aVPqfrWzOvNAkmYGxEehnulIoLTcKB,headers=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,cookies=aVPqfrWzOvNAkmYGxEehnulIoLTcbD)
   aVPqfrWzOvNAkmYGxEehnulIoLTcXp=json.loads(aVPqfrWzOvNAkmYGxEehnulIoLTcXD.text)
   aVPqfrWzOvNAkmYGxEehnulIoLTcpM=aVPqfrWzOvNAkmYGxEehnulIoLTcXp['playurl']
   if aVPqfrWzOvNAkmYGxEehnulIoLTcpM==aVPqfrWzOvNAkmYGxEehnulIoLTcbD:return(aVPqfrWzOvNAkmYGxEehnulIoLTcpM,aVPqfrWzOvNAkmYGxEehnulIoLTcpi,aVPqfrWzOvNAkmYGxEehnulIoLTcpF,streaming_preview)
   aVPqfrWzOvNAkmYGxEehnulIoLTcpi=aVPqfrWzOvNAkmYGxEehnulIoLTcXp['awscookie']
   aVPqfrWzOvNAkmYGxEehnulIoLTcpF =aVPqfrWzOvNAkmYGxEehnulIoLTcXp['drm']
   if 'previewmsg' in aVPqfrWzOvNAkmYGxEehnulIoLTcXp['preview']:streaming_preview=aVPqfrWzOvNAkmYGxEehnulIoLTcXp['preview']['previewmsg']
  except aVPqfrWzOvNAkmYGxEehnulIoLTcbw as exception:
   aVPqfrWzOvNAkmYGxEehnulIoLTcbj(exception)
  return(aVPqfrWzOvNAkmYGxEehnulIoLTcpM,aVPqfrWzOvNAkmYGxEehnulIoLTcpi,aVPqfrWzOvNAkmYGxEehnulIoLTcpF,streaming_preview) 
 def GetSportsURL(aVPqfrWzOvNAkmYGxEehnulIoLTcKD,aVPqfrWzOvNAkmYGxEehnulIoLTcDj,quality_int):
  aVPqfrWzOvNAkmYGxEehnulIoLTcpM=aVPqfrWzOvNAkmYGxEehnulIoLTcpi=''
  aVPqfrWzOvNAkmYGxEehnulIoLTcpt=[]
  try:
   aVPqfrWzOvNAkmYGxEehnulIoLTcKR=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.API_DOMAIN+'/streaming/other'
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB={'contentid':aVPqfrWzOvNAkmYGxEehnulIoLTcDj,'contenttype':'live','action':'hls','quality':aVPqfrWzOvNAkmYGxEehnulIoLTcbJ(quality_int)+'p','deviceModelId':'Windows 10','guid':aVPqfrWzOvNAkmYGxEehnulIoLTcKD.GetGUID(guidType=2),'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n'}
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB.update(aVPqfrWzOvNAkmYGxEehnulIoLTcKD.GetDefaultParams(login=aVPqfrWzOvNAkmYGxEehnulIoLTcbQ))
   aVPqfrWzOvNAkmYGxEehnulIoLTcXD=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.callRequestCookies('Get',aVPqfrWzOvNAkmYGxEehnulIoLTcKR,payload=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,params=aVPqfrWzOvNAkmYGxEehnulIoLTcKB,headers=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,cookies=aVPqfrWzOvNAkmYGxEehnulIoLTcbD)
   aVPqfrWzOvNAkmYGxEehnulIoLTcXp=json.loads(aVPqfrWzOvNAkmYGxEehnulIoLTcXD.text)
   aVPqfrWzOvNAkmYGxEehnulIoLTcpM=aVPqfrWzOvNAkmYGxEehnulIoLTcXp['playurl']
   if aVPqfrWzOvNAkmYGxEehnulIoLTcpM==aVPqfrWzOvNAkmYGxEehnulIoLTcbD:return(aVPqfrWzOvNAkmYGxEehnulIoLTcpM,aVPqfrWzOvNAkmYGxEehnulIoLTcpi)
   aVPqfrWzOvNAkmYGxEehnulIoLTcpi=aVPqfrWzOvNAkmYGxEehnulIoLTcXp['awscookie']
  except aVPqfrWzOvNAkmYGxEehnulIoLTcbw as exception:
   aVPqfrWzOvNAkmYGxEehnulIoLTcbj(exception)
  return(aVPqfrWzOvNAkmYGxEehnulIoLTcpM,aVPqfrWzOvNAkmYGxEehnulIoLTcpi) 
 def make_viewdate(aVPqfrWzOvNAkmYGxEehnulIoLTcKD):
  aVPqfrWzOvNAkmYGxEehnulIoLTcpR =aVPqfrWzOvNAkmYGxEehnulIoLTcKD.Get_Now_Datetime()
  aVPqfrWzOvNAkmYGxEehnulIoLTcdK =aVPqfrWzOvNAkmYGxEehnulIoLTcpR+datetime.timedelta(days=-1)
  aVPqfrWzOvNAkmYGxEehnulIoLTcdX =aVPqfrWzOvNAkmYGxEehnulIoLTcpR+datetime.timedelta(days=1)
  aVPqfrWzOvNAkmYGxEehnulIoLTcdD=[aVPqfrWzOvNAkmYGxEehnulIoLTcpR.strftime('%Y%m%d'),aVPqfrWzOvNAkmYGxEehnulIoLTcdX.strftime('%Y%m%d'),]
  return aVPqfrWzOvNAkmYGxEehnulIoLTcdD
 def Get_Sports_Gamelist(aVPqfrWzOvNAkmYGxEehnulIoLTcKD):
  aVPqfrWzOvNAkmYGxEehnulIoLTcdp =aVPqfrWzOvNAkmYGxEehnulIoLTcKD.make_viewdate()
  aVPqfrWzOvNAkmYGxEehnulIoLTcdb=[]
  aVPqfrWzOvNAkmYGxEehnulIoLTcdQ =[]
  for aVPqfrWzOvNAkmYGxEehnulIoLTcdC in aVPqfrWzOvNAkmYGxEehnulIoLTcdp:
   aVPqfrWzOvNAkmYGxEehnulIoLTcdJ=aVPqfrWzOvNAkmYGxEehnulIoLTcdC[:6]
   if aVPqfrWzOvNAkmYGxEehnulIoLTcdJ not in aVPqfrWzOvNAkmYGxEehnulIoLTcdb:
    aVPqfrWzOvNAkmYGxEehnulIoLTcdb.append(aVPqfrWzOvNAkmYGxEehnulIoLTcdJ)
  try:
   aVPqfrWzOvNAkmYGxEehnulIoLTcKR='https://annexapi.wavve.com/skb/baseball/teammonthlycalendarlist'
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB={'IF':'IF-PORG-002','m':'getTeamCalendarListBand','response_format':'json','spo_itm_cd':'KBO','teamcd':'all','tgroup':'B','tvalue':'BC123','ver':'2.0',}
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB.update(aVPqfrWzOvNAkmYGxEehnulIoLTcKD.GetDefaultParams(login=aVPqfrWzOvNAkmYGxEehnulIoLTcbp))
   for aVPqfrWzOvNAkmYGxEehnulIoLTcdw in aVPqfrWzOvNAkmYGxEehnulIoLTcdb:
    aVPqfrWzOvNAkmYGxEehnulIoLTcKB['date']=aVPqfrWzOvNAkmYGxEehnulIoLTcdw
    aVPqfrWzOvNAkmYGxEehnulIoLTcXD=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.callRequestCookies('Get',aVPqfrWzOvNAkmYGxEehnulIoLTcKR,payload=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,params=aVPqfrWzOvNAkmYGxEehnulIoLTcKB,headers=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,cookies=aVPqfrWzOvNAkmYGxEehnulIoLTcbD)
    aVPqfrWzOvNAkmYGxEehnulIoLTcXp=json.loads(aVPqfrWzOvNAkmYGxEehnulIoLTcXD.text)
    aVPqfrWzOvNAkmYGxEehnulIoLTcXM=aVPqfrWzOvNAkmYGxEehnulIoLTcXp['cell_toplist']['celllist']
    for aVPqfrWzOvNAkmYGxEehnulIoLTcXt in aVPqfrWzOvNAkmYGxEehnulIoLTcXM:
     aVPqfrWzOvNAkmYGxEehnulIoLTcdj=aVPqfrWzOvNAkmYGxEehnulIoLTcXt.get('game_date')
     aVPqfrWzOvNAkmYGxEehnulIoLTcdB =aVPqfrWzOvNAkmYGxEehnulIoLTcXt.get('svc_id')
     if aVPqfrWzOvNAkmYGxEehnulIoLTcdB=='':continue
     if aVPqfrWzOvNAkmYGxEehnulIoLTcdj in aVPqfrWzOvNAkmYGxEehnulIoLTcdp:
      aVPqfrWzOvNAkmYGxEehnulIoLTcdM=aVPqfrWzOvNAkmYGxEehnulIoLTcXt.get('game_status') 
      aVPqfrWzOvNAkmYGxEehnulIoLTcdt =aVPqfrWzOvNAkmYGxEehnulIoLTcXt.get('title_list')[0].get('text')
      aVPqfrWzOvNAkmYGxEehnulIoLTcdj =aVPqfrWzOvNAkmYGxEehnulIoLTcdj[:4]+'-'+aVPqfrWzOvNAkmYGxEehnulIoLTcdj[4:6]+'-'+aVPqfrWzOvNAkmYGxEehnulIoLTcdj[-2:]
      aVPqfrWzOvNAkmYGxEehnulIoLTcds =aVPqfrWzOvNAkmYGxEehnulIoLTcXt.get('game_time')
      aVPqfrWzOvNAkmYGxEehnulIoLTcds =aVPqfrWzOvNAkmYGxEehnulIoLTcds[:2]+':'+aVPqfrWzOvNAkmYGxEehnulIoLTcds[-2:]
      aVPqfrWzOvNAkmYGxEehnulIoLTcXs={'game_date':aVPqfrWzOvNAkmYGxEehnulIoLTcdj,'game_time':aVPqfrWzOvNAkmYGxEehnulIoLTcds,'svc_id':aVPqfrWzOvNAkmYGxEehnulIoLTcdB,'away_team':aVPqfrWzOvNAkmYGxEehnulIoLTcXt.get('away_team').get('team_name'),'home_team':aVPqfrWzOvNAkmYGxEehnulIoLTcXt.get('home_team').get('team_name'),'game_status':aVPqfrWzOvNAkmYGxEehnulIoLTcdM,'game_place':aVPqfrWzOvNAkmYGxEehnulIoLTcXt.get('game_place'),}
      aVPqfrWzOvNAkmYGxEehnulIoLTcdQ.append(aVPqfrWzOvNAkmYGxEehnulIoLTcXs)
  except aVPqfrWzOvNAkmYGxEehnulIoLTcbw as exception:
   aVPqfrWzOvNAkmYGxEehnulIoLTcbj(exception)
   return[]
  aVPqfrWzOvNAkmYGxEehnulIoLTcdy=[]
  for i in aVPqfrWzOvNAkmYGxEehnulIoLTcbC(2):
   for aVPqfrWzOvNAkmYGxEehnulIoLTcXt in aVPqfrWzOvNAkmYGxEehnulIoLTcdQ:
    if i==0 and aVPqfrWzOvNAkmYGxEehnulIoLTcXt.get('game_status')=='LIVE':
     aVPqfrWzOvNAkmYGxEehnulIoLTcdy.append(aVPqfrWzOvNAkmYGxEehnulIoLTcXt)
    elif i==1 and aVPqfrWzOvNAkmYGxEehnulIoLTcXt.get('game_status')!='LIVE':
     aVPqfrWzOvNAkmYGxEehnulIoLTcdy.append(aVPqfrWzOvNAkmYGxEehnulIoLTcXt)
  return aVPqfrWzOvNAkmYGxEehnulIoLTcdy
 def GetBookmarkInfo(aVPqfrWzOvNAkmYGxEehnulIoLTcKD,aVPqfrWzOvNAkmYGxEehnulIoLTcDd,aVPqfrWzOvNAkmYGxEehnulIoLTcDp,aVPqfrWzOvNAkmYGxEehnulIoLTcpy):
  if aVPqfrWzOvNAkmYGxEehnulIoLTcDp=='tvshow':
   if aVPqfrWzOvNAkmYGxEehnulIoLTcpy=='contentid':
    aVPqfrWzOvNAkmYGxEehnulIoLTcDj=aVPqfrWzOvNAkmYGxEehnulIoLTcDd
    aVPqfrWzOvNAkmYGxEehnulIoLTcDd =aVPqfrWzOvNAkmYGxEehnulIoLTcKD.ContentidToProgramid(aVPqfrWzOvNAkmYGxEehnulIoLTcDj)
   else:
    aVPqfrWzOvNAkmYGxEehnulIoLTcDj=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.ProgramidToContentid(aVPqfrWzOvNAkmYGxEehnulIoLTcDd)
  else:
   aVPqfrWzOvNAkmYGxEehnulIoLTcDj=''
  aVPqfrWzOvNAkmYGxEehnulIoLTcdg={'indexinfo':{'ott':'wavve','videoid':aVPqfrWzOvNAkmYGxEehnulIoLTcDd,'vidtype':aVPqfrWzOvNAkmYGxEehnulIoLTcDp,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':aVPqfrWzOvNAkmYGxEehnulIoLTcDp,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if aVPqfrWzOvNAkmYGxEehnulIoLTcDp=='tvshow':
   aVPqfrWzOvNAkmYGxEehnulIoLTcKR=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.API_DOMAIN+'/cf/vod/contents/'+aVPqfrWzOvNAkmYGxEehnulIoLTcDj 
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.GetDefaultParams(login=aVPqfrWzOvNAkmYGxEehnulIoLTcbp)
   aVPqfrWzOvNAkmYGxEehnulIoLTcXD=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.callRequestCookies('Get',aVPqfrWzOvNAkmYGxEehnulIoLTcKR,payload=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,params=aVPqfrWzOvNAkmYGxEehnulIoLTcKB,headers=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,cookies=aVPqfrWzOvNAkmYGxEehnulIoLTcbD)
   aVPqfrWzOvNAkmYGxEehnulIoLTcXp=json.loads(aVPqfrWzOvNAkmYGxEehnulIoLTcXD.text)
   if not('programtitle' in aVPqfrWzOvNAkmYGxEehnulIoLTcXp):return{}
   aVPqfrWzOvNAkmYGxEehnulIoLTcdH=aVPqfrWzOvNAkmYGxEehnulIoLTcXp
   aVPqfrWzOvNAkmYGxEehnulIoLTcdS=aVPqfrWzOvNAkmYGxEehnulIoLTcdH.get('programtitle')
   aVPqfrWzOvNAkmYGxEehnulIoLTcdg['saveinfo']['infoLabels']['title']=aVPqfrWzOvNAkmYGxEehnulIoLTcdS
   if aVPqfrWzOvNAkmYGxEehnulIoLTcdH.get('targetage')=='18' or aVPqfrWzOvNAkmYGxEehnulIoLTcdH.get('targetage')=='19' or aVPqfrWzOvNAkmYGxEehnulIoLTcdH.get('targetage')=='21':
    aVPqfrWzOvNAkmYGxEehnulIoLTcdS +=u' (%s)'%(aVPqfrWzOvNAkmYGxEehnulIoLTcdH.get('targetage'))
   aVPqfrWzOvNAkmYGxEehnulIoLTcdg['saveinfo']['title'] =aVPqfrWzOvNAkmYGxEehnulIoLTcdS
   aVPqfrWzOvNAkmYGxEehnulIoLTcdg['saveinfo']['infoLabels']['mpaa'] =aVPqfrWzOvNAkmYGxEehnulIoLTcdH.get('targetage')
   aVPqfrWzOvNAkmYGxEehnulIoLTcdg['saveinfo']['infoLabels']['plot'] =aVPqfrWzOvNAkmYGxEehnulIoLTcdH.get('programsynopsis').replace('<br>','\n')
   aVPqfrWzOvNAkmYGxEehnulIoLTcdg['saveinfo']['infoLabels']['studio'] =aVPqfrWzOvNAkmYGxEehnulIoLTcdH.get('channelname')
   if aVPqfrWzOvNAkmYGxEehnulIoLTcdH.get('firstreleaseyear')!='':aVPqfrWzOvNAkmYGxEehnulIoLTcdg['saveinfo']['infoLabels']['year'] =aVPqfrWzOvNAkmYGxEehnulIoLTcdH.get('firstreleaseyear')
   if aVPqfrWzOvNAkmYGxEehnulIoLTcdH.get('firstreleasedate')!='':aVPqfrWzOvNAkmYGxEehnulIoLTcdg['saveinfo']['infoLabels']['premiered']=aVPqfrWzOvNAkmYGxEehnulIoLTcdH.get('firstreleasedate')
   if aVPqfrWzOvNAkmYGxEehnulIoLTcdH.get('genretext') !='':aVPqfrWzOvNAkmYGxEehnulIoLTcdg['saveinfo']['infoLabels']['genre'] =[aVPqfrWzOvNAkmYGxEehnulIoLTcdH.get('genretext')]
   aVPqfrWzOvNAkmYGxEehnulIoLTcdU=[]
   for aVPqfrWzOvNAkmYGxEehnulIoLTcdi in aVPqfrWzOvNAkmYGxEehnulIoLTcdH['actors']['list']:aVPqfrWzOvNAkmYGxEehnulIoLTcdU.append(aVPqfrWzOvNAkmYGxEehnulIoLTcdi.get('text'))
   if aVPqfrWzOvNAkmYGxEehnulIoLTcbt(aVPqfrWzOvNAkmYGxEehnulIoLTcdU)>0:
    if aVPqfrWzOvNAkmYGxEehnulIoLTcdU[0]!='':aVPqfrWzOvNAkmYGxEehnulIoLTcdg['saveinfo']['infoLabels']['cast']=aVPqfrWzOvNAkmYGxEehnulIoLTcdU
   aVPqfrWzOvNAkmYGxEehnulIoLTcDF =''
   aVPqfrWzOvNAkmYGxEehnulIoLTcDR =''
   aVPqfrWzOvNAkmYGxEehnulIoLTcpK=''
   if aVPqfrWzOvNAkmYGxEehnulIoLTcdH.get('programposterimage')!='':aVPqfrWzOvNAkmYGxEehnulIoLTcDF =aVPqfrWzOvNAkmYGxEehnulIoLTcKD.HTTPTAG+aVPqfrWzOvNAkmYGxEehnulIoLTcdH.get('programposterimage')
   if aVPqfrWzOvNAkmYGxEehnulIoLTcdH.get('programimage') !='':aVPqfrWzOvNAkmYGxEehnulIoLTcDR =aVPqfrWzOvNAkmYGxEehnulIoLTcKD.HTTPTAG+aVPqfrWzOvNAkmYGxEehnulIoLTcdH.get('programimage')
   if aVPqfrWzOvNAkmYGxEehnulIoLTcdH.get('programcirlceimage')!='':aVPqfrWzOvNAkmYGxEehnulIoLTcpK=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.HTTPTAG+aVPqfrWzOvNAkmYGxEehnulIoLTcdH.get('programcirlceimage')
   if 'poster_default' in aVPqfrWzOvNAkmYGxEehnulIoLTcDF:
    aVPqfrWzOvNAkmYGxEehnulIoLTcDF =aVPqfrWzOvNAkmYGxEehnulIoLTcDR
    aVPqfrWzOvNAkmYGxEehnulIoLTcpK=''
   aVPqfrWzOvNAkmYGxEehnulIoLTcdg['saveinfo']['thumbnail']['poster']=aVPqfrWzOvNAkmYGxEehnulIoLTcDF
   aVPqfrWzOvNAkmYGxEehnulIoLTcdg['saveinfo']['thumbnail']['thumb']=aVPqfrWzOvNAkmYGxEehnulIoLTcDR
   aVPqfrWzOvNAkmYGxEehnulIoLTcdg['saveinfo']['thumbnail']['clearlogo']=aVPqfrWzOvNAkmYGxEehnulIoLTcpK
   aVPqfrWzOvNAkmYGxEehnulIoLTcdg['saveinfo']['thumbnail']['fanart']=aVPqfrWzOvNAkmYGxEehnulIoLTcDR
  else:
   aVPqfrWzOvNAkmYGxEehnulIoLTcKR=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.API_DOMAIN+'/movie/contents/'+aVPqfrWzOvNAkmYGxEehnulIoLTcDd 
   aVPqfrWzOvNAkmYGxEehnulIoLTcKB=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.GetDefaultParams(login=aVPqfrWzOvNAkmYGxEehnulIoLTcbp)
   aVPqfrWzOvNAkmYGxEehnulIoLTcXD=aVPqfrWzOvNAkmYGxEehnulIoLTcKD.callRequestCookies('Get',aVPqfrWzOvNAkmYGxEehnulIoLTcKR,payload=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,params=aVPqfrWzOvNAkmYGxEehnulIoLTcKB,headers=aVPqfrWzOvNAkmYGxEehnulIoLTcbD,cookies=aVPqfrWzOvNAkmYGxEehnulIoLTcbD)
   aVPqfrWzOvNAkmYGxEehnulIoLTcXp=json.loads(aVPqfrWzOvNAkmYGxEehnulIoLTcXD.text)
   if not('title' in aVPqfrWzOvNAkmYGxEehnulIoLTcXp):return{}
   aVPqfrWzOvNAkmYGxEehnulIoLTcdH=aVPqfrWzOvNAkmYGxEehnulIoLTcXp
   aVPqfrWzOvNAkmYGxEehnulIoLTcdS=aVPqfrWzOvNAkmYGxEehnulIoLTcdH.get('title')
   aVPqfrWzOvNAkmYGxEehnulIoLTcdg['saveinfo']['infoLabels']['title']=aVPqfrWzOvNAkmYGxEehnulIoLTcdS
   if aVPqfrWzOvNAkmYGxEehnulIoLTcdH.get('targetage')=='18' or aVPqfrWzOvNAkmYGxEehnulIoLTcdH.get('targetage')=='19' or aVPqfrWzOvNAkmYGxEehnulIoLTcdH.get('targetage')=='21':
    aVPqfrWzOvNAkmYGxEehnulIoLTcdS +=u' (%s)'%(aVPqfrWzOvNAkmYGxEehnulIoLTcdH.get('targetage'))
   aVPqfrWzOvNAkmYGxEehnulIoLTcdg['saveinfo']['title'] =aVPqfrWzOvNAkmYGxEehnulIoLTcdS
   aVPqfrWzOvNAkmYGxEehnulIoLTcdg['saveinfo']['infoLabels']['mpaa'] =aVPqfrWzOvNAkmYGxEehnulIoLTcdH.get('targetage')
   aVPqfrWzOvNAkmYGxEehnulIoLTcdg['saveinfo']['infoLabels']['plot'] =aVPqfrWzOvNAkmYGxEehnulIoLTcdH.get('synopsis').replace('<br>','\n')
   aVPqfrWzOvNAkmYGxEehnulIoLTcdg['saveinfo']['infoLabels']['duration']=aVPqfrWzOvNAkmYGxEehnulIoLTcdH.get('playtime')
   aVPqfrWzOvNAkmYGxEehnulIoLTcdg['saveinfo']['infoLabels']['country']=aVPqfrWzOvNAkmYGxEehnulIoLTcdH.get('country')
   aVPqfrWzOvNAkmYGxEehnulIoLTcdg['saveinfo']['infoLabels']['studio'] =aVPqfrWzOvNAkmYGxEehnulIoLTcdH.get('cpname')
   if aVPqfrWzOvNAkmYGxEehnulIoLTcdH.get('releasedate')!='':
    aVPqfrWzOvNAkmYGxEehnulIoLTcdg['saveinfo']['infoLabels']['year'] =aVPqfrWzOvNAkmYGxEehnulIoLTcdH.get('releasedate')[:4]
    aVPqfrWzOvNAkmYGxEehnulIoLTcdg['saveinfo']['infoLabels']['premiered']=aVPqfrWzOvNAkmYGxEehnulIoLTcdH.get('releasedate')
   aVPqfrWzOvNAkmYGxEehnulIoLTcdU=[]
   for aVPqfrWzOvNAkmYGxEehnulIoLTcdi in aVPqfrWzOvNAkmYGxEehnulIoLTcdH['actors']['list']:aVPqfrWzOvNAkmYGxEehnulIoLTcdU.append(aVPqfrWzOvNAkmYGxEehnulIoLTcdi.get('text'))
   if aVPqfrWzOvNAkmYGxEehnulIoLTcbt(aVPqfrWzOvNAkmYGxEehnulIoLTcdU)>0:
    if aVPqfrWzOvNAkmYGxEehnulIoLTcdU[0]!='':aVPqfrWzOvNAkmYGxEehnulIoLTcdg['saveinfo']['infoLabels']['cast']=aVPqfrWzOvNAkmYGxEehnulIoLTcdU
   aVPqfrWzOvNAkmYGxEehnulIoLTcdF=[]
   for aVPqfrWzOvNAkmYGxEehnulIoLTcdR in aVPqfrWzOvNAkmYGxEehnulIoLTcdH['directors']['list']:aVPqfrWzOvNAkmYGxEehnulIoLTcdF.append(aVPqfrWzOvNAkmYGxEehnulIoLTcdR.get('text'))
   if aVPqfrWzOvNAkmYGxEehnulIoLTcbt(aVPqfrWzOvNAkmYGxEehnulIoLTcdF)>0:
    if aVPqfrWzOvNAkmYGxEehnulIoLTcdF[0]!='':aVPqfrWzOvNAkmYGxEehnulIoLTcdg['saveinfo']['infoLabels']['director']=aVPqfrWzOvNAkmYGxEehnulIoLTcdF
   aVPqfrWzOvNAkmYGxEehnulIoLTcXw=[]
   for aVPqfrWzOvNAkmYGxEehnulIoLTcbK in aVPqfrWzOvNAkmYGxEehnulIoLTcdH['genre']['list']:aVPqfrWzOvNAkmYGxEehnulIoLTcXw.append(aVPqfrWzOvNAkmYGxEehnulIoLTcbK.get('text'))
   if aVPqfrWzOvNAkmYGxEehnulIoLTcbt(aVPqfrWzOvNAkmYGxEehnulIoLTcXw)>0:
    if aVPqfrWzOvNAkmYGxEehnulIoLTcXw[0]!='':aVPqfrWzOvNAkmYGxEehnulIoLTcdg['saveinfo']['infoLabels']['genre']=aVPqfrWzOvNAkmYGxEehnulIoLTcXw
   aVPqfrWzOvNAkmYGxEehnulIoLTcDF ='https://%s'%aVPqfrWzOvNAkmYGxEehnulIoLTcdH['image']
   aVPqfrWzOvNAkmYGxEehnulIoLTcdg['saveinfo']['thumbnail']['poster'] =aVPqfrWzOvNAkmYGxEehnulIoLTcDF
   aVPqfrWzOvNAkmYGxEehnulIoLTcdg['saveinfo']['thumbnail']['thumb'] =aVPqfrWzOvNAkmYGxEehnulIoLTcDF
  return aVPqfrWzOvNAkmYGxEehnulIoLTcdg
# Created by pyminifier (https://github.com/liftoff/pyminifier)
