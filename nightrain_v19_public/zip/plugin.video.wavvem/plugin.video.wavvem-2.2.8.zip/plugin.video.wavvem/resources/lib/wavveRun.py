__author__="NightRain"
VNHzWpGrfsyBKnLQCXMqJDIEbtvRxi=object
VNHzWpGrfsyBKnLQCXMqJDIEbtvRxa=None
VNHzWpGrfsyBKnLQCXMqJDIEbtvRxP=int
VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj=True
VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu=False
VNHzWpGrfsyBKnLQCXMqJDIEbtvRxl=type
VNHzWpGrfsyBKnLQCXMqJDIEbtvRxe=dict
VNHzWpGrfsyBKnLQCXMqJDIEbtvRxc=len
VNHzWpGrfsyBKnLQCXMqJDIEbtvRoY=range
VNHzWpGrfsyBKnLQCXMqJDIEbtvRoh=str
VNHzWpGrfsyBKnLQCXMqJDIEbtvRog=open
VNHzWpGrfsyBKnLQCXMqJDIEbtvRoT=Exception
VNHzWpGrfsyBKnLQCXMqJDIEbtvRom=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import json
VNHzWpGrfsyBKnLQCXMqJDIEbtvRYg=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://www.wavve.com/supermultisection/GN51','icon':'home.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&offset=0&limit=20&uicode=VN500','page':'1','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=01&WeekDay=all&uitype=VN4&uiparent=FN0&uirank=0&broadcastid=847243&uicode=VN4','page':'1','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=02&WeekDay=all&uitype=VN3&uiparent=FN0&uirank=0&broadcastid=783664&uicode=VN3','page':'1','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'1','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'paid','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'displaystart','ordernm':'업데이트순','icon':''},{'title':'프로야구 - 경기중 시청가능','mode':'GAME_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'(웨이브) 검색','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'(웨이브) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
VNHzWpGrfsyBKnLQCXMqJDIEbtvRYT=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
VNHzWpGrfsyBKnLQCXMqJDIEbtvRYm=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
VNHzWpGrfsyBKnLQCXMqJDIEbtvRYk =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
VNHzWpGrfsyBKnLQCXMqJDIEbtvRYx=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_searched.txt'))
from wavveCore import*
class VNHzWpGrfsyBKnLQCXMqJDIEbtvRYh(VNHzWpGrfsyBKnLQCXMqJDIEbtvRxi):
 def __init__(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo,VNHzWpGrfsyBKnLQCXMqJDIEbtvRYd,VNHzWpGrfsyBKnLQCXMqJDIEbtvRYF,VNHzWpGrfsyBKnLQCXMqJDIEbtvRYA):
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo._addon_url =VNHzWpGrfsyBKnLQCXMqJDIEbtvRYd
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo._addon_handle=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYF
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.main_params =VNHzWpGrfsyBKnLQCXMqJDIEbtvRYA
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.WavveObj =aVPqfrWzOvNAkmYGxEehnulIoLTcKX() 
 def addon_noti(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo,sting):
  try:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYw=xbmcgui.Dialog()
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYw.notification(__addonname__,sting)
  except:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRxa
 def addon_log(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo,string):
  try:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYO=string.encode('utf-8','ignore')
  except:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYO='addonException: addon_log'
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRYS=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,VNHzWpGrfsyBKnLQCXMqJDIEbtvRYO),level=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYS)
 def get_keyboard_input(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo,VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd):
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRYi=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxa
  kb=xbmc.Keyboard()
  kb.setHeading(VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYi=kb.getText()
  return VNHzWpGrfsyBKnLQCXMqJDIEbtvRYi
 def get_settings_account(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo):
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRYa =__addon__.getSetting('id')
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRYP =__addon__.getSetting('pw')
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRYj=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxP(__addon__.getSetting('selected_profile'))
  return(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYa,VNHzWpGrfsyBKnLQCXMqJDIEbtvRYP,VNHzWpGrfsyBKnLQCXMqJDIEbtvRYj)
 def get_settings_totalsearch(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo):
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRYu =VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj if __addon__.getSetting('local_search')=='true' else VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRYl=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj if __addon__.getSetting('local_history')=='true' else VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRYe =VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj if __addon__.getSetting('total_search')=='true' else VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRYc=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj if __addon__.getSetting('total_history')=='true' else VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRhY=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj if __addon__.getSetting('menu_bookmark')=='true' else VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu
  return(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYu,VNHzWpGrfsyBKnLQCXMqJDIEbtvRYl,VNHzWpGrfsyBKnLQCXMqJDIEbtvRYe,VNHzWpGrfsyBKnLQCXMqJDIEbtvRYc,VNHzWpGrfsyBKnLQCXMqJDIEbtvRhY)
 def get_settings_makebookmark(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo):
  return VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj if __addon__.getSetting('make_bookmark')=='true' else VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu
 def get_selQuality(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo):
  try:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhg=[1080,720,480,360]
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhT=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxP(__addon__.getSetting('selected_quality'))
   return VNHzWpGrfsyBKnLQCXMqJDIEbtvRhg[VNHzWpGrfsyBKnLQCXMqJDIEbtvRhT]
  except:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRxa
  return 1080 
 def get_settings_exclusion21(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo):
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRhm =__addon__.getSetting('exclusion21')
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRhm=='false':
   return VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu
  else:
   return VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj
 def get_settings_direct_replay(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo):
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRhk=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxP(__addon__.getSetting('direct_replay'))
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRhk==0:
   return VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu
  else:
   return VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj
 def set_winEpisodeOrderby(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo,VNHzWpGrfsyBKnLQCXMqJDIEbtvRhx):
  __addon__.setSetting('wavve_orderby',VNHzWpGrfsyBKnLQCXMqJDIEbtvRhx)
 def get_winEpisodeOrderby(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo):
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRhx=__addon__.getSetting('wavve_orderby')
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRhx in['',VNHzWpGrfsyBKnLQCXMqJDIEbtvRxa]:VNHzWpGrfsyBKnLQCXMqJDIEbtvRhx='desc'
  return VNHzWpGrfsyBKnLQCXMqJDIEbtvRhx
 def add_dir(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo,label,sublabel='',img='',infoLabels=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxa,isFolder=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj,params='',isLink=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu,ContextMenu=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxa):
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRho='%s?%s'%(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo._addon_url,urllib.parse.urlencode(params))
  if sublabel:VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd='%s < %s >'%(label,sublabel)
  else: VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd=label
  if not img:img='DefaultFolder.png'
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRhF=xbmcgui.ListItem(VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd)
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRxl(img)==VNHzWpGrfsyBKnLQCXMqJDIEbtvRxe:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhF.setArt(img)
  else:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhF.setArt({'thumb':img,'poster':img})
  if infoLabels:VNHzWpGrfsyBKnLQCXMqJDIEbtvRhF.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhF.setProperty('IsPlayable','true')
  if ContextMenu:VNHzWpGrfsyBKnLQCXMqJDIEbtvRhF.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo._addon_handle,VNHzWpGrfsyBKnLQCXMqJDIEbtvRho,VNHzWpGrfsyBKnLQCXMqJDIEbtvRhF,isFolder)
 def dp_Main_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo):
  (VNHzWpGrfsyBKnLQCXMqJDIEbtvRYu,VNHzWpGrfsyBKnLQCXMqJDIEbtvRYl,VNHzWpGrfsyBKnLQCXMqJDIEbtvRYe,VNHzWpGrfsyBKnLQCXMqJDIEbtvRYc,VNHzWpGrfsyBKnLQCXMqJDIEbtvRhY)=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.get_settings_totalsearch()
  for VNHzWpGrfsyBKnLQCXMqJDIEbtvRhA in VNHzWpGrfsyBKnLQCXMqJDIEbtvRYg:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhA.get('title')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhU=''
   if VNHzWpGrfsyBKnLQCXMqJDIEbtvRhA.get('mode')=='SEARCH_GROUP' and VNHzWpGrfsyBKnLQCXMqJDIEbtvRYu ==VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu:continue
   elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRhA.get('mode')=='SEARCH_HISTORY' and VNHzWpGrfsyBKnLQCXMqJDIEbtvRYl==VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu:continue
   elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRhA.get('mode')=='TOTAL_SEARCH' and VNHzWpGrfsyBKnLQCXMqJDIEbtvRYe ==VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu:continue
   elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRhA.get('mode')=='TOTAL_HISTORY' and VNHzWpGrfsyBKnLQCXMqJDIEbtvRYc==VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu:continue
   elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRhA.get('mode')=='MENU_BOOKMARK' and VNHzWpGrfsyBKnLQCXMqJDIEbtvRhY==VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu:continue
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw={'mode':VNHzWpGrfsyBKnLQCXMqJDIEbtvRhA.get('mode'),'sCode':VNHzWpGrfsyBKnLQCXMqJDIEbtvRhA.get('sCode'),'sIndex':VNHzWpGrfsyBKnLQCXMqJDIEbtvRhA.get('sIndex'),'sType':VNHzWpGrfsyBKnLQCXMqJDIEbtvRhA.get('sType'),'suburl':VNHzWpGrfsyBKnLQCXMqJDIEbtvRhA.get('suburl'),'subapi':VNHzWpGrfsyBKnLQCXMqJDIEbtvRhA.get('subapi'),'page':VNHzWpGrfsyBKnLQCXMqJDIEbtvRhA.get('page'),'orderby':VNHzWpGrfsyBKnLQCXMqJDIEbtvRhA.get('orderby'),'ordernm':VNHzWpGrfsyBKnLQCXMqJDIEbtvRhA.get('ordernm')}
   if VNHzWpGrfsyBKnLQCXMqJDIEbtvRhA.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRhO=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRhS =VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj
   else:
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRhO=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRhS =VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu
   if 'icon' in VNHzWpGrfsyBKnLQCXMqJDIEbtvRhA:VNHzWpGrfsyBKnLQCXMqJDIEbtvRhU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',VNHzWpGrfsyBKnLQCXMqJDIEbtvRhA.get('icon')) 
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.add_dir(VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd,sublabel='',img=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhU,infoLabels=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxa,isFolder=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhO,params=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw,isLink=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhS)
  xbmcplugin.endOfDirectory(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo._addon_handle,cacheToDisc=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj)
 def dp_Search_Group(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo,args):
  if 'search_key' in args:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhP=args.get('search_key')
  else:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhP=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not VNHzWpGrfsyBKnLQCXMqJDIEbtvRhP:
    return
  for VNHzWpGrfsyBKnLQCXMqJDIEbtvRhj in VNHzWpGrfsyBKnLQCXMqJDIEbtvRYT:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu =VNHzWpGrfsyBKnLQCXMqJDIEbtvRhj.get('mode')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhl=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhj.get('sType')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhj.get('title')
   (VNHzWpGrfsyBKnLQCXMqJDIEbtvRhe,VNHzWpGrfsyBKnLQCXMqJDIEbtvRhc)=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.WavveObj.Get_Search_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRhP,VNHzWpGrfsyBKnLQCXMqJDIEbtvRhl,1,exclusion21=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.get_settings_exclusion21())
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRgY={'plot':'검색어 : '+VNHzWpGrfsyBKnLQCXMqJDIEbtvRhP+'\n\n'+VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.Search_FreeList(VNHzWpGrfsyBKnLQCXMqJDIEbtvRhe)}
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw={'mode':VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu,'sType':VNHzWpGrfsyBKnLQCXMqJDIEbtvRhl,'search_key':VNHzWpGrfsyBKnLQCXMqJDIEbtvRhP,'page':'1',}
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.add_dir(VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd,sublabel='',img='',infoLabels=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgY,isFolder=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj,params=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw)
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRxc(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYT)>0:xbmcplugin.endOfDirectory(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo._addon_handle,cacheToDisc=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj)
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.Save_Searched_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRhP)
 def Search_FreeList(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo,search_list):
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRgh=''
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRgT=7
  try:
   if VNHzWpGrfsyBKnLQCXMqJDIEbtvRxc(search_list)==0:return '검색결과 없음'
   for i in VNHzWpGrfsyBKnLQCXMqJDIEbtvRoY(VNHzWpGrfsyBKnLQCXMqJDIEbtvRxc(search_list)):
    if i>=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgT:
     VNHzWpGrfsyBKnLQCXMqJDIEbtvRgh=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgh+'...'
     break
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRgh=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgh+search_list[i]['title']+'\n'
  except:
   return ''
  return VNHzWpGrfsyBKnLQCXMqJDIEbtvRgh
 def dp_Watch_Group(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo,args):
  for VNHzWpGrfsyBKnLQCXMqJDIEbtvRgm in VNHzWpGrfsyBKnLQCXMqJDIEbtvRYm:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgm.get('title')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw={'mode':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgm.get('mode'),'sType':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgm.get('sType')}
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.add_dir(VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd,sublabel='',img='',infoLabels=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxa,isFolder=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj,params=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw)
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRxc(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYm)>0:xbmcplugin.endOfDirectory(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo._addon_handle,cacheToDisc=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj)
 def dp_Search_History(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo,args):
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRgk=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.Load_List_File('search')
  for VNHzWpGrfsyBKnLQCXMqJDIEbtvRgx in VNHzWpGrfsyBKnLQCXMqJDIEbtvRgk:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRgo=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxe(urllib.parse.parse_qsl(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgx))
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRgd=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgo.get('skey').strip()
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw={'mode':'SEARCH_GROUP','search_key':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgd,}
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRgF={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgd,'vType':'-',}
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRgA=urllib.parse.urlencode(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgF)
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRgU=[('선택된 검색어 ( %s ) 삭제'%(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgd),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgA))]
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.add_dir(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgd,sublabel='',img=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxa,infoLabels=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxa,isFolder=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj,params=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw,ContextMenu=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgU)
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRgw={'plot':'검색목록 전체를 삭제합니다.'}
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRhU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.add_dir(VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd,sublabel='',img=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhU,infoLabels=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgw,isFolder=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu,params=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw,isLink=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj)
  xbmcplugin.endOfDirectory(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo._addon_handle,cacheToDisc=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu)
 def dp_Search_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo,args):
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRhl =args.get('sType')
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRgO =VNHzWpGrfsyBKnLQCXMqJDIEbtvRxP(args.get('page'))
  if 'search_key' in args:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhP=args.get('search_key')
  else:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhP=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not VNHzWpGrfsyBKnLQCXMqJDIEbtvRhP:
    xbmcplugin.endOfDirectory(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo._addon_handle)
    return
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRgS,VNHzWpGrfsyBKnLQCXMqJDIEbtvRhc=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.WavveObj.Get_Search_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRhP,VNHzWpGrfsyBKnLQCXMqJDIEbtvRhl,VNHzWpGrfsyBKnLQCXMqJDIEbtvRgO,exclusion21=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.get_settings_exclusion21())
  for VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi in VNHzWpGrfsyBKnLQCXMqJDIEbtvRgS:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd =VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('title')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRga=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('thumbnail')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRgP =VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('age')
   if VNHzWpGrfsyBKnLQCXMqJDIEbtvRgP=='18' or VNHzWpGrfsyBKnLQCXMqJDIEbtvRgP=='19' or VNHzWpGrfsyBKnLQCXMqJDIEbtvRgP=='21':VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd+=' (%s)'%(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgP)
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRgw={'mediatype':'tvshow' if VNHzWpGrfsyBKnLQCXMqJDIEbtvRhl=='vod' else 'movie','mpaa':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgP,'title':VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd,'plot':VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd}
   if VNHzWpGrfsyBKnLQCXMqJDIEbtvRhl=='vod':
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw={'mode':'EPISODE_LIST','videoid':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('videoid'),'vidtype':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('vidtype'),'page':'1'}
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRhO=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj
   else:
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw={'mode':'MOVIE','contentid':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('videoid'),'title':VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd,'thumbnail':VNHzWpGrfsyBKnLQCXMqJDIEbtvRga,'age':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgP}
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRhO=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu
   if VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.get_settings_makebookmark():
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRgj={'videoid':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('videoid'),'vidtype':'tvshow' if VNHzWpGrfsyBKnLQCXMqJDIEbtvRhl=='vod' else 'movie','vtitle':VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd,'vsubtitle':'','contenttype':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('vidtype'),}
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRgu=json.dumps(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgj)
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRgu=urllib.parse.quote(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgu)
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRgl='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgu)
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRgU=[('(통합) 찜 영상에 추가',VNHzWpGrfsyBKnLQCXMqJDIEbtvRgl)]
   else:
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRgU=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxa
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.add_dir(VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd,sublabel='',img=VNHzWpGrfsyBKnLQCXMqJDIEbtvRga,infoLabels=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgw,isFolder=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhO,params=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw,ContextMenu=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgU)
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRhc:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw['mode'] ='SEARCH_LIST' 
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw['sType']=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhl 
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw['page'] =VNHzWpGrfsyBKnLQCXMqJDIEbtvRoh(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgO+1)
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw['search_key']=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhP
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd='[B]%s >>[/B]'%'다음 페이지'
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRge=VNHzWpGrfsyBKnLQCXMqJDIEbtvRoh(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgO+1)
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.add_dir(VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd,sublabel=VNHzWpGrfsyBKnLQCXMqJDIEbtvRge,img=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhU,infoLabels=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxa,isFolder=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj,params=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw)
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRhl=='movie':xbmcplugin.setContent(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo._addon_handle,'movies')
  else:xbmcplugin.setContent(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo._addon_handle,cacheToDisc=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu)
 def dp_Watch_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo,args):
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRhl =args.get('sType')
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRhk=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.get_settings_direct_replay()
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRgS=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.Load_List_File(VNHzWpGrfsyBKnLQCXMqJDIEbtvRhl)
  for VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi in VNHzWpGrfsyBKnLQCXMqJDIEbtvRgS:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRgo=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxe(urllib.parse.parse_qsl(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi))
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRgc =VNHzWpGrfsyBKnLQCXMqJDIEbtvRgo.get('code').strip()
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd =VNHzWpGrfsyBKnLQCXMqJDIEbtvRgo.get('title').strip()
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRge =VNHzWpGrfsyBKnLQCXMqJDIEbtvRgo.get('subtitle').strip()
   if VNHzWpGrfsyBKnLQCXMqJDIEbtvRge=='None':VNHzWpGrfsyBKnLQCXMqJDIEbtvRge=''
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRga=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgo.get('img').strip()
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRTY =VNHzWpGrfsyBKnLQCXMqJDIEbtvRgo.get('videoid').strip()
   try:
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRga=VNHzWpGrfsyBKnLQCXMqJDIEbtvRga.replace('\'','\"')
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRga=json.loads(VNHzWpGrfsyBKnLQCXMqJDIEbtvRga)
   except:
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRxa
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRgw={'plot':'%s\n%s'%(VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd,VNHzWpGrfsyBKnLQCXMqJDIEbtvRge)}
   if VNHzWpGrfsyBKnLQCXMqJDIEbtvRhl=='vod':
    if VNHzWpGrfsyBKnLQCXMqJDIEbtvRhk==VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu or VNHzWpGrfsyBKnLQCXMqJDIEbtvRTY==VNHzWpGrfsyBKnLQCXMqJDIEbtvRxa:
     VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw={'mode':'EPISODE_LIST','videoid':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgc,'vidtype':'programid','page':'1'}
     VNHzWpGrfsyBKnLQCXMqJDIEbtvRhO=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj
    else:
     VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw={'mode':'VOD','programid':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgc,'contentid':VNHzWpGrfsyBKnLQCXMqJDIEbtvRTY,'title':VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd,'subtitle':VNHzWpGrfsyBKnLQCXMqJDIEbtvRge,'thumbnail':VNHzWpGrfsyBKnLQCXMqJDIEbtvRga}
     VNHzWpGrfsyBKnLQCXMqJDIEbtvRhO=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu
   else:
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw={'mode':'MOVIE','contentid':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgc,'title':VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd,'subtitle':VNHzWpGrfsyBKnLQCXMqJDIEbtvRge,'thumbnail':VNHzWpGrfsyBKnLQCXMqJDIEbtvRga}
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRhO=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRgF={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgc,'vType':VNHzWpGrfsyBKnLQCXMqJDIEbtvRhl,}
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRgA=urllib.parse.urlencode(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgF)
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRgU=[('선택된 시청이력 ( %s ) 삭제'%(VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgA))]
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.add_dir(VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd,sublabel=VNHzWpGrfsyBKnLQCXMqJDIEbtvRge,img=VNHzWpGrfsyBKnLQCXMqJDIEbtvRga,infoLabels=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgw,isFolder=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhO,params=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw,ContextMenu=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgU)
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRgw={'plot':'시청목록을 삭제합니다.'}
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':VNHzWpGrfsyBKnLQCXMqJDIEbtvRhl,}
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRhU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.add_dir(VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd,sublabel='',img=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhU,infoLabels=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgw,isFolder=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu,params=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw,isLink=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj)
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRhl=='movie':xbmcplugin.setContent(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo._addon_handle,'movies')
  else:xbmcplugin.setContent(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo._addon_handle,cacheToDisc=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu)
 def Load_List_File(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo,stype): 
  try:
   if stype=='search':
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRTh=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYx
   elif stype in['vod','movie']:
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRTh=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   else:
    return[]
   fp=VNHzWpGrfsyBKnLQCXMqJDIEbtvRog(VNHzWpGrfsyBKnLQCXMqJDIEbtvRTh,'r',-1,'utf-8')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRTg=fp.readlines()
   fp.close()
  except:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRTg=[]
  return VNHzWpGrfsyBKnLQCXMqJDIEbtvRTg
 def Save_Watched_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo,VNHzWpGrfsyBKnLQCXMqJDIEbtvRxT,VNHzWpGrfsyBKnLQCXMqJDIEbtvRYA):
  try:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRTm=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%VNHzWpGrfsyBKnLQCXMqJDIEbtvRxT))
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRTk=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.Load_List_File(VNHzWpGrfsyBKnLQCXMqJDIEbtvRxT) 
   fp=VNHzWpGrfsyBKnLQCXMqJDIEbtvRog(VNHzWpGrfsyBKnLQCXMqJDIEbtvRTm,'w',-1,'utf-8')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRTx=urllib.parse.urlencode(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYA)
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRTx=VNHzWpGrfsyBKnLQCXMqJDIEbtvRTx+'\n'
   fp.write(VNHzWpGrfsyBKnLQCXMqJDIEbtvRTx)
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRTo=0
   for VNHzWpGrfsyBKnLQCXMqJDIEbtvRTd in VNHzWpGrfsyBKnLQCXMqJDIEbtvRTk:
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRTF=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxe(urllib.parse.parse_qsl(VNHzWpGrfsyBKnLQCXMqJDIEbtvRTd))
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRTA=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYA.get('code').strip()
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRTU=VNHzWpGrfsyBKnLQCXMqJDIEbtvRTF.get('code').strip()
    if VNHzWpGrfsyBKnLQCXMqJDIEbtvRxT=='vod' and VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.get_settings_direct_replay()==VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj:
     VNHzWpGrfsyBKnLQCXMqJDIEbtvRTA=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYA.get('videoid').strip()
     VNHzWpGrfsyBKnLQCXMqJDIEbtvRTU=VNHzWpGrfsyBKnLQCXMqJDIEbtvRTF.get('videoid').strip()if VNHzWpGrfsyBKnLQCXMqJDIEbtvRTU!=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxa else '-'
    if VNHzWpGrfsyBKnLQCXMqJDIEbtvRTA!=VNHzWpGrfsyBKnLQCXMqJDIEbtvRTU:
     fp.write(VNHzWpGrfsyBKnLQCXMqJDIEbtvRTd)
     VNHzWpGrfsyBKnLQCXMqJDIEbtvRTo+=1
     if VNHzWpGrfsyBKnLQCXMqJDIEbtvRTo>=50:break
   fp.close()
  except:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRxa
 def dp_History_Remove(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo,args):
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRTw=args.get('delType')
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRTO =args.get('sKey')
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRTS =args.get('vType')
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRYw=xbmcgui.Dialog()
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRTw=='SEARCH_ALL':
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRTi=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYw.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRTw=='SEARCH_ONE':
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRTi=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYw.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRTw=='WATCH_ALL':
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRTi=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYw.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRTw=='WATCH_ONE':
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRTi=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYw.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRTi==VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu:sys.exit()
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRTw=='SEARCH_ALL':
   if os.path.isfile(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYx):os.remove(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYx)
  elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRTw=='SEARCH_ONE':
   try:
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRTh=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYx
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRTk=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.Load_List_File('search') 
    fp=VNHzWpGrfsyBKnLQCXMqJDIEbtvRog(VNHzWpGrfsyBKnLQCXMqJDIEbtvRTh,'w',-1,'utf-8')
    for VNHzWpGrfsyBKnLQCXMqJDIEbtvRTd in VNHzWpGrfsyBKnLQCXMqJDIEbtvRTk:
     VNHzWpGrfsyBKnLQCXMqJDIEbtvRTF=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxe(urllib.parse.parse_qsl(VNHzWpGrfsyBKnLQCXMqJDIEbtvRTd))
     VNHzWpGrfsyBKnLQCXMqJDIEbtvRTa=VNHzWpGrfsyBKnLQCXMqJDIEbtvRTF.get('skey').strip()
     if VNHzWpGrfsyBKnLQCXMqJDIEbtvRTO!=VNHzWpGrfsyBKnLQCXMqJDIEbtvRTa:
      fp.write(VNHzWpGrfsyBKnLQCXMqJDIEbtvRTd)
    fp.close()
   except:
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRxa
  elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRTw=='WATCH_ALL':
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRTh=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%VNHzWpGrfsyBKnLQCXMqJDIEbtvRTS))
   if os.path.isfile(VNHzWpGrfsyBKnLQCXMqJDIEbtvRTh):os.remove(VNHzWpGrfsyBKnLQCXMqJDIEbtvRTh)
  elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRTw=='WATCH_ONE':
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRTh=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%VNHzWpGrfsyBKnLQCXMqJDIEbtvRTS))
   try:
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRTk=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.Load_List_File(VNHzWpGrfsyBKnLQCXMqJDIEbtvRTS) 
    fp=VNHzWpGrfsyBKnLQCXMqJDIEbtvRog(VNHzWpGrfsyBKnLQCXMqJDIEbtvRTh,'w',-1,'utf-8')
    for VNHzWpGrfsyBKnLQCXMqJDIEbtvRTd in VNHzWpGrfsyBKnLQCXMqJDIEbtvRTk:
     VNHzWpGrfsyBKnLQCXMqJDIEbtvRTF=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxe(urllib.parse.parse_qsl(VNHzWpGrfsyBKnLQCXMqJDIEbtvRTd))
     VNHzWpGrfsyBKnLQCXMqJDIEbtvRTa=VNHzWpGrfsyBKnLQCXMqJDIEbtvRTF.get('code').strip()
     if VNHzWpGrfsyBKnLQCXMqJDIEbtvRTO!=VNHzWpGrfsyBKnLQCXMqJDIEbtvRTa:
      fp.write(VNHzWpGrfsyBKnLQCXMqJDIEbtvRTd)
    fp.close()
   except:
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRxa
  xbmc.executebuiltin("Container.Refresh")
 def Save_Searched_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo,VNHzWpGrfsyBKnLQCXMqJDIEbtvRhP):
  try:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRTP=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYx
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRTk=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.Load_List_File('search') 
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRTj={'skey':VNHzWpGrfsyBKnLQCXMqJDIEbtvRhP.strip()}
   fp=VNHzWpGrfsyBKnLQCXMqJDIEbtvRog(VNHzWpGrfsyBKnLQCXMqJDIEbtvRTP,'w',-1,'utf-8')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRTx=urllib.parse.urlencode(VNHzWpGrfsyBKnLQCXMqJDIEbtvRTj)
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRTx=VNHzWpGrfsyBKnLQCXMqJDIEbtvRTx+'\n'
   fp.write(VNHzWpGrfsyBKnLQCXMqJDIEbtvRTx)
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRTo=0
   for VNHzWpGrfsyBKnLQCXMqJDIEbtvRTd in VNHzWpGrfsyBKnLQCXMqJDIEbtvRTk:
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRTF=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxe(urllib.parse.parse_qsl(VNHzWpGrfsyBKnLQCXMqJDIEbtvRTd))
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRTA=VNHzWpGrfsyBKnLQCXMqJDIEbtvRTj.get('skey').strip()
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRTU=VNHzWpGrfsyBKnLQCXMqJDIEbtvRTF.get('skey').strip()
    if VNHzWpGrfsyBKnLQCXMqJDIEbtvRTA!=VNHzWpGrfsyBKnLQCXMqJDIEbtvRTU:
     fp.write(VNHzWpGrfsyBKnLQCXMqJDIEbtvRTd)
     VNHzWpGrfsyBKnLQCXMqJDIEbtvRTo+=1
     if VNHzWpGrfsyBKnLQCXMqJDIEbtvRTo>=50:break
   fp.close()
  except:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRxa
 def dp_Global_Search(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo,args):
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu=args.get('mode')
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu=='TOTAL_SEARCH':
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRTu='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRTu='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(VNHzWpGrfsyBKnLQCXMqJDIEbtvRTu)
 def dp_Bookmark_Menu(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo,args):
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRTu='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(VNHzWpGrfsyBKnLQCXMqJDIEbtvRTu)
 def login_main(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo):
  (VNHzWpGrfsyBKnLQCXMqJDIEbtvRTl,VNHzWpGrfsyBKnLQCXMqJDIEbtvRTe,VNHzWpGrfsyBKnLQCXMqJDIEbtvRTc)=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.get_settings_account()
  if not(VNHzWpGrfsyBKnLQCXMqJDIEbtvRTl and VNHzWpGrfsyBKnLQCXMqJDIEbtvRTe):
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYw=xbmcgui.Dialog()
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRTi=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYw.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if VNHzWpGrfsyBKnLQCXMqJDIEbtvRTi==VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.cookiefile_check()==VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj:return
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRmY=0
   while VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj:
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRmY+=1
    time.sleep(0.05)
    if VNHzWpGrfsyBKnLQCXMqJDIEbtvRmY>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRmh=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.WavveObj.GetCredential(VNHzWpGrfsyBKnLQCXMqJDIEbtvRTl,VNHzWpGrfsyBKnLQCXMqJDIEbtvRTe,VNHzWpGrfsyBKnLQCXMqJDIEbtvRTc)
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRmh:VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRmh==VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_setEpOrderby(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo,args):
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRhx =args.get('orderby')
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.set_winEpisodeOrderby(VNHzWpGrfsyBKnLQCXMqJDIEbtvRhx)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo,args):
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu =args.get('mode')
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRmg =args.get('contentid')
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRmT =args.get('pvrmode')
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRmk=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.get_selQuality()
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.addon_log(VNHzWpGrfsyBKnLQCXMqJDIEbtvRmg+' - '+VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu)
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu=='SPORTS':
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRmx,VNHzWpGrfsyBKnLQCXMqJDIEbtvRmo=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.WavveObj.GetSportsURL(VNHzWpGrfsyBKnLQCXMqJDIEbtvRmg,VNHzWpGrfsyBKnLQCXMqJDIEbtvRmk)
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRmd =''
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRmF=''
  else:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRmx,VNHzWpGrfsyBKnLQCXMqJDIEbtvRmo,VNHzWpGrfsyBKnLQCXMqJDIEbtvRmd,VNHzWpGrfsyBKnLQCXMqJDIEbtvRmF=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.WavveObj.GetStreamingURL(VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu,VNHzWpGrfsyBKnLQCXMqJDIEbtvRmg,VNHzWpGrfsyBKnLQCXMqJDIEbtvRmk,VNHzWpGrfsyBKnLQCXMqJDIEbtvRmT)
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRmA='%s|Cookie=%s'%(VNHzWpGrfsyBKnLQCXMqJDIEbtvRmx,VNHzWpGrfsyBKnLQCXMqJDIEbtvRmo)
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.addon_log(VNHzWpGrfsyBKnLQCXMqJDIEbtvRmA)
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRmx=='':
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.addon_noti(__language__(30907).encode('utf8'))
   return
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRmU=xbmcgui.ListItem(path=VNHzWpGrfsyBKnLQCXMqJDIEbtvRmA)
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRmd:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.addon_log('!!streaming_drm!!')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRmw=VNHzWpGrfsyBKnLQCXMqJDIEbtvRmd['customdata']
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRmO =VNHzWpGrfsyBKnLQCXMqJDIEbtvRmd['drmhost']
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRmS =inputstreamhelper.Helper('mpd',drm='widevine')
   if VNHzWpGrfsyBKnLQCXMqJDIEbtvRmS.check_inputstream():
    if VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu=='MOVIE':
     VNHzWpGrfsyBKnLQCXMqJDIEbtvRmi='https://www.wavve.com/player/movie?movieid=%s'%VNHzWpGrfsyBKnLQCXMqJDIEbtvRmg
    else:
     VNHzWpGrfsyBKnLQCXMqJDIEbtvRmi='https://www.wavve.com/player/vod?programid=%s&page=1'%VNHzWpGrfsyBKnLQCXMqJDIEbtvRmg
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRma={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':VNHzWpGrfsyBKnLQCXMqJDIEbtvRmw,'referer':VNHzWpGrfsyBKnLQCXMqJDIEbtvRmi,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.WavveObj.USER_AGENT}
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRmP=VNHzWpGrfsyBKnLQCXMqJDIEbtvRmO+'|'+urllib.parse.urlencode(VNHzWpGrfsyBKnLQCXMqJDIEbtvRma)+'|R{SSM}|'
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRmU.setProperty('inputstream',VNHzWpGrfsyBKnLQCXMqJDIEbtvRmS.inputstream_addon)
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRmU.setProperty('inputstream.adaptive.manifest_type','mpd')
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRmU.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRmU.setProperty('inputstream.adaptive.license_key',VNHzWpGrfsyBKnLQCXMqJDIEbtvRmP)
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRmU.setProperty('inputstream.adaptive.stream_headers','user-agent=%s&Cookie=%s'%(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.WavveObj.USER_AGENT,VNHzWpGrfsyBKnLQCXMqJDIEbtvRmo))
  xbmcplugin.setResolvedUrl(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo._addon_handle,VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj,VNHzWpGrfsyBKnLQCXMqJDIEbtvRmU)
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRmj=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRmF:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.addon_noti(VNHzWpGrfsyBKnLQCXMqJDIEbtvRmF.encode('utf-8'))
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRmj=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj
  else:
   if '/preview.' in urllib.parse.urlsplit(VNHzWpGrfsyBKnLQCXMqJDIEbtvRmx).path:
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.addon_noti(__language__(30908).encode('utf8'))
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRmj=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj
  try:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRmu=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and VNHzWpGrfsyBKnLQCXMqJDIEbtvRmj==VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu and VNHzWpGrfsyBKnLQCXMqJDIEbtvRmu!='-':
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw={'code':VNHzWpGrfsyBKnLQCXMqJDIEbtvRmu,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.Save_Watched_List(args.get('mode').lower(),VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw)
  except:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRxa
 def logout(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo):
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRYw=xbmcgui.Dialog()
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRTi=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYw.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRTi==VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu:sys.exit()
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.WavveObj.Init_WV_Total()
  if os.path.isfile(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYk):os.remove(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYk)
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo):
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRml =VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.WavveObj.Get_Now_Datetime()
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRme=VNHzWpGrfsyBKnLQCXMqJDIEbtvRml+datetime.timedelta(days=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxP(__addon__.getSetting('cache_ttl')))
  (VNHzWpGrfsyBKnLQCXMqJDIEbtvRTl,VNHzWpGrfsyBKnLQCXMqJDIEbtvRTe,VNHzWpGrfsyBKnLQCXMqJDIEbtvRTc)=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.get_settings_account()
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.WavveObj.Save_session_acount(VNHzWpGrfsyBKnLQCXMqJDIEbtvRTl,VNHzWpGrfsyBKnLQCXMqJDIEbtvRTe,VNHzWpGrfsyBKnLQCXMqJDIEbtvRTc)
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.WavveObj.WV['account']['token_limit']=VNHzWpGrfsyBKnLQCXMqJDIEbtvRme.strftime('%Y%m%d')
  try: 
   fp=VNHzWpGrfsyBKnLQCXMqJDIEbtvRog(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYk,'w',-1,'utf-8')
   json.dump(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.WavveObj.WV,fp,indent=4,ensure_ascii=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu)
   fp.close()
  except VNHzWpGrfsyBKnLQCXMqJDIEbtvRoT as exception:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRom(exception)
 def cookiefile_check(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo):
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.WavveObj.WV=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.WavveObj.JsonFile_Load(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYk)
  if 'account' not in VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.WavveObj.WV:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.WavveObj.Init_WV_Total()
   return VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu
  (VNHzWpGrfsyBKnLQCXMqJDIEbtvRkY,VNHzWpGrfsyBKnLQCXMqJDIEbtvRkh,VNHzWpGrfsyBKnLQCXMqJDIEbtvRkg)=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.get_settings_account()
  (VNHzWpGrfsyBKnLQCXMqJDIEbtvRkT,VNHzWpGrfsyBKnLQCXMqJDIEbtvRkm,VNHzWpGrfsyBKnLQCXMqJDIEbtvRkx)=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.WavveObj.Load_session_acount()
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRkY!=VNHzWpGrfsyBKnLQCXMqJDIEbtvRkT or VNHzWpGrfsyBKnLQCXMqJDIEbtvRkh!=VNHzWpGrfsyBKnLQCXMqJDIEbtvRkm or VNHzWpGrfsyBKnLQCXMqJDIEbtvRkg!=VNHzWpGrfsyBKnLQCXMqJDIEbtvRkx:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.WavveObj.Init_WV_Total()
   return VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRxP(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))>VNHzWpGrfsyBKnLQCXMqJDIEbtvRxP(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.WavveObj.WV['account']['token_limit']):
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.WavveObj.Init_WV_Total()
   return VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu
  return VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj
 def dp_LiveCatagory_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo,args):
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRko =args.get('sCode')
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRkd=args.get('sIndex')
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRgS,VNHzWpGrfsyBKnLQCXMqJDIEbtvRkF=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.WavveObj.Get_LiveCatagory_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRko,VNHzWpGrfsyBKnLQCXMqJDIEbtvRkd)
  for VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi in VNHzWpGrfsyBKnLQCXMqJDIEbtvRgS:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd =VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('title')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw={'mode':'LIVE_LIST','genre':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('genre'),'baseapi':VNHzWpGrfsyBKnLQCXMqJDIEbtvRkF}
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.add_dir(VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd,sublabel='',img='',infoLabels=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxa,isFolder=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj,params=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw)
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRxc(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgS)>0:xbmcplugin.endOfDirectory(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo._addon_handle,cacheToDisc=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu)
 def dp_MainCatagory_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo,args):
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRko =args.get('sCode')
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRkd=args.get('sIndex')
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRhl =args.get('sType')
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRgS=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.WavveObj.Get_MainCatagory_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRko,VNHzWpGrfsyBKnLQCXMqJDIEbtvRkd)
  for VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi in VNHzWpGrfsyBKnLQCXMqJDIEbtvRgS:
   if VNHzWpGrfsyBKnLQCXMqJDIEbtvRhl=='vod':
    if VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('subtype')=='catagory':
     VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu='PROGRAM_LIST'
    else:
     VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu='SUPERSECTION_LIST'
   elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRhl=='movie':
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu='MOVIE_LIST'
   else:
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu=''
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd='%s (%s)'%(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('title'),args.get('ordernm'))
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw={'mode':VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu,'suburl':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('suburl'),'subapi':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.get_settings_exclusion21():
    if VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('title')=='성인' or VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('title')=='성인+' or VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('title')=='에로티시즘' or VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('title')=='19':continue
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.add_dir(VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd,sublabel='',img='',infoLabels=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxa,isFolder=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj,params=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw)
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRxc(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgS)>0:xbmcplugin.endOfDirectory(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo._addon_handle,cacheToDisc=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu)
 def dp_Program_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo,args):
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRkA =args.get('subapi')
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRgO=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxP(args.get('page'))
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRhx =args.get('orderby')
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRgS,VNHzWpGrfsyBKnLQCXMqJDIEbtvRhc=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.WavveObj.Get_Program_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRkA,VNHzWpGrfsyBKnLQCXMqJDIEbtvRgO,VNHzWpGrfsyBKnLQCXMqJDIEbtvRhx)
  for VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi in VNHzWpGrfsyBKnLQCXMqJDIEbtvRgS:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd =VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('title')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRga=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('thumbnail')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRgP =VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('age')
   if VNHzWpGrfsyBKnLQCXMqJDIEbtvRgP=='18' or VNHzWpGrfsyBKnLQCXMqJDIEbtvRgP=='19' or VNHzWpGrfsyBKnLQCXMqJDIEbtvRgP=='21':VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd+=' (%s)'%(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgP)
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRgw={'plot':VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd,'mpaa':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgP,'mediatype':'tvshow'}
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw={'mode':'EPISODE_LIST','videoid':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('videoid'),'vidtype':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('vidtype'),'page':'1'}
   if VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.get_settings_makebookmark():
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRgj={'videoid':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('videoid'),'vidtype':'tvshow','vtitle':VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd,'vsubtitle':'','contenttype':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('vidtype'),}
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRgu=json.dumps(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgj)
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRgu=urllib.parse.quote(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgu)
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRgl='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgu)
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRgU=[('(통합) 찜 영상에 추가',VNHzWpGrfsyBKnLQCXMqJDIEbtvRgl)]
   else:
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRgU=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxa
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.add_dir(VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd,sublabel='',img=VNHzWpGrfsyBKnLQCXMqJDIEbtvRga,infoLabels=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgw,isFolder=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj,params=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw,ContextMenu=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgU)
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRhc:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw={}
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw['mode'] ='PROGRAM_LIST' 
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw['subapi']=VNHzWpGrfsyBKnLQCXMqJDIEbtvRkA 
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw['page'] =VNHzWpGrfsyBKnLQCXMqJDIEbtvRoh(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgO+1)
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd='[B]%s >>[/B]'%'다음 페이지'
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRge=VNHzWpGrfsyBKnLQCXMqJDIEbtvRoh(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgO+1)
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.add_dir(VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd,sublabel=VNHzWpGrfsyBKnLQCXMqJDIEbtvRge,img=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhU,infoLabels=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxa,isFolder=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj,params=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw)
  xbmcplugin.setContent(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo._addon_handle,'tvshows')
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRxc(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgS)>0:xbmcplugin.endOfDirectory(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo._addon_handle,cacheToDisc=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu)
 def dp_SuperSection_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo,args):
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRkU =args.get('suburl')
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRgS=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.WavveObj.Get_SuperMultiSection_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRkU)
  for VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi in VNHzWpGrfsyBKnLQCXMqJDIEbtvRgS:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd =VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('title')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRkA =VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('subapi')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRkw=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('cell_type')
   if VNHzWpGrfsyBKnLQCXMqJDIEbtvRkA.find('mtype=svod')>=0 or VNHzWpGrfsyBKnLQCXMqJDIEbtvRkA.find('mtype=ppv')>=0:
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu='MOVIE_LIST'
   elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRkw=='band_71':
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu ='SUPERSECTION_LIST'
    (VNHzWpGrfsyBKnLQCXMqJDIEbtvRkO,VNHzWpGrfsyBKnLQCXMqJDIEbtvRkS)=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.WavveObj.Baseapi_Parse(VNHzWpGrfsyBKnLQCXMqJDIEbtvRkA)
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRkU=VNHzWpGrfsyBKnLQCXMqJDIEbtvRkS.get('api')
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRkA=''
   elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRkw=='band_2':
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu='BAND2SECTION_LIST'
   elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRkw=='band_live':
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu='BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}',VNHzWpGrfsyBKnLQCXMqJDIEbtvRkA):
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu='MOVIE_LIST'
   else:
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu='PROGRAM_LIST'
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRgw={'plot':VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd,'mediatype':'tvshow'}
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw={'mode':VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu,'suburl':VNHzWpGrfsyBKnLQCXMqJDIEbtvRkU,'subapi':VNHzWpGrfsyBKnLQCXMqJDIEbtvRkA,'page':'1'}
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.add_dir(VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd,sublabel='',img=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxa,infoLabels=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgw,isFolder=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj,params=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw)
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRxc(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgS)>0:xbmcplugin.endOfDirectory(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo._addon_handle,cacheToDisc=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu)
 def dp_BandLiveSection_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo,args):
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRkA =args.get('subapi')
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRgO=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxP(args.get('page'))
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRgS,VNHzWpGrfsyBKnLQCXMqJDIEbtvRhc=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.WavveObj.Get_BandLiveSection_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRkA,VNHzWpGrfsyBKnLQCXMqJDIEbtvRgO)
  for VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi in VNHzWpGrfsyBKnLQCXMqJDIEbtvRgS:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRki =VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('channelid')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRka =VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('studio')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRkP=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('tvshowtitle')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRga =VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('thumbnail')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRgP =VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('age')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRgw={'mediatype':'tvshow','mpaa':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgP,'title':'%s < %s >'%(VNHzWpGrfsyBKnLQCXMqJDIEbtvRka,VNHzWpGrfsyBKnLQCXMqJDIEbtvRkP),'tvshowtitle':VNHzWpGrfsyBKnLQCXMqJDIEbtvRkP,'studio':VNHzWpGrfsyBKnLQCXMqJDIEbtvRka,'plot':VNHzWpGrfsyBKnLQCXMqJDIEbtvRka}
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw={'mode':'LIVE','contentid':VNHzWpGrfsyBKnLQCXMqJDIEbtvRki}
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.add_dir(VNHzWpGrfsyBKnLQCXMqJDIEbtvRka,sublabel=VNHzWpGrfsyBKnLQCXMqJDIEbtvRkP,img=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('thumbnail'),infoLabels=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgw,isFolder=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu,params=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw)
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRhc:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw={}
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw['mode'] ='BANDLIVESECTION_LIST' 
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw['subapi']=VNHzWpGrfsyBKnLQCXMqJDIEbtvRkA
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw['page'] =VNHzWpGrfsyBKnLQCXMqJDIEbtvRoh(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgO+1)
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd='[B]%s >>[/B]'%'다음 페이지'
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRge=VNHzWpGrfsyBKnLQCXMqJDIEbtvRoh(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgO+1)
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.add_dir(VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd,sublabel=VNHzWpGrfsyBKnLQCXMqJDIEbtvRge,img=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhU,infoLabels=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxa,isFolder=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj,params=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw)
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRxc(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgS)>0:xbmcplugin.endOfDirectory(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo._addon_handle,cacheToDisc=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu)
 def dp_Band2Section_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo,args):
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRkA =args.get('subapi')
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRgO=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxP(args.get('page'))
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRgS,VNHzWpGrfsyBKnLQCXMqJDIEbtvRhc=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.WavveObj.Get_Band2Section_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRkA,VNHzWpGrfsyBKnLQCXMqJDIEbtvRgO)
  for VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi in VNHzWpGrfsyBKnLQCXMqJDIEbtvRgS:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd =VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('programtitle')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRge =VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('episodetitle')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRgw={'plot':VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd+'\n\n'+VNHzWpGrfsyBKnLQCXMqJDIEbtvRge,'mpaa':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('age'),'mediatype':'episode'}
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw={'mode':'VOD','programid':'-','contentid':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('videoid'),'thumbnail':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('thumbnail'),'title':VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd,'subtitle':VNHzWpGrfsyBKnLQCXMqJDIEbtvRge}
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.add_dir(VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd,sublabel=VNHzWpGrfsyBKnLQCXMqJDIEbtvRge,img=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('thumbnail'),infoLabels=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgw,isFolder=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu,params=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw)
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRhc:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw={}
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw['mode'] ='BAND2SECTION_LIST' 
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw['subapi']=VNHzWpGrfsyBKnLQCXMqJDIEbtvRkA
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw['page'] =VNHzWpGrfsyBKnLQCXMqJDIEbtvRoh(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgO+1)
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd='[B]%s >>[/B]'%'다음 페이지'
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRge=VNHzWpGrfsyBKnLQCXMqJDIEbtvRoh(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgO+1)
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.add_dir(VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd,sublabel=VNHzWpGrfsyBKnLQCXMqJDIEbtvRge,img=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhU,infoLabels=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxa,isFolder=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj,params=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw)
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRxc(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgS)>0:xbmcplugin.endOfDirectory(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo._addon_handle,cacheToDisc=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu)
 def dp_Movie_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo,args):
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRkA =args.get('subapi')
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRgO=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxP(args.get('page'))
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRgS,VNHzWpGrfsyBKnLQCXMqJDIEbtvRhc=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.WavveObj.Get_Movie_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRkA,VNHzWpGrfsyBKnLQCXMqJDIEbtvRgO)
  for VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi in VNHzWpGrfsyBKnLQCXMqJDIEbtvRgS:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd =VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('title')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRga=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('thumbnail')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRgP =VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('age')
   if VNHzWpGrfsyBKnLQCXMqJDIEbtvRgP=='18' or VNHzWpGrfsyBKnLQCXMqJDIEbtvRgP=='19' or VNHzWpGrfsyBKnLQCXMqJDIEbtvRgP=='21':VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd+=' (%s)'%(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgP)
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRgw={'plot':VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd,'mpaa':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgP,'mediatype':'movie'}
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw={'mode':'MOVIE','contentid':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('videoid'),'title':VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd,'thumbnail':VNHzWpGrfsyBKnLQCXMqJDIEbtvRga,'age':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgP}
   if VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.get_settings_makebookmark():
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRgj={'videoid':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('videoid'),'vidtype':'movie','vtitle':VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd,'vsubtitle':'','contenttype':'programid',}
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRgu=json.dumps(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgj)
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRgu=urllib.parse.quote(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgu)
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRgl='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgu)
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRgU=[('(통합) 찜 영상에 추가',VNHzWpGrfsyBKnLQCXMqJDIEbtvRgl)]
   else:
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRgU=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxa
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.add_dir(VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd,sublabel='',img=VNHzWpGrfsyBKnLQCXMqJDIEbtvRga,infoLabels=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgw,isFolder=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu,params=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw,ContextMenu=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgU)
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRhc:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw={}
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw['mode'] ='MOVIE_LIST' 
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw['subapi']=VNHzWpGrfsyBKnLQCXMqJDIEbtvRkA 
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw['page'] =VNHzWpGrfsyBKnLQCXMqJDIEbtvRoh(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgO+1)
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd='[B]%s >>[/B]'%'다음 페이지'
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRge=VNHzWpGrfsyBKnLQCXMqJDIEbtvRoh(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgO+1)
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.add_dir(VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd,sublabel=VNHzWpGrfsyBKnLQCXMqJDIEbtvRge,img=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhU,infoLabels=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxa,isFolder=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj,params=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw)
  xbmcplugin.setContent(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo._addon_handle,'movies')
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRxc(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgS)>0:xbmcplugin.endOfDirectory(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo._addon_handle,cacheToDisc=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu)
 def dp_Set_Bookmark(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo,args):
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRkj=urllib.parse.unquote(args.get('bm_param'))
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRkj=json.loads(VNHzWpGrfsyBKnLQCXMqJDIEbtvRkj)
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRTY =VNHzWpGrfsyBKnLQCXMqJDIEbtvRkj.get('videoid')
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRku =VNHzWpGrfsyBKnLQCXMqJDIEbtvRkj.get('vidtype')
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRkl =VNHzWpGrfsyBKnLQCXMqJDIEbtvRkj.get('vtitle')
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRke =VNHzWpGrfsyBKnLQCXMqJDIEbtvRkj.get('vsubtitle')
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRkc=VNHzWpGrfsyBKnLQCXMqJDIEbtvRkj.get('contenttype')
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRYw=xbmcgui.Dialog()
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRTi=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYw.yesno(__language__(30913).encode('utf8'),VNHzWpGrfsyBKnLQCXMqJDIEbtvRkl+' \n\n'+__language__(30914))
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRTi==VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu:return
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRxY=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.WavveObj.GetBookmarkInfo(VNHzWpGrfsyBKnLQCXMqJDIEbtvRTY,VNHzWpGrfsyBKnLQCXMqJDIEbtvRku,VNHzWpGrfsyBKnLQCXMqJDIEbtvRkc)
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRxh=json.dumps(VNHzWpGrfsyBKnLQCXMqJDIEbtvRxY)
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRxh=urllib.parse.quote(VNHzWpGrfsyBKnLQCXMqJDIEbtvRxh)
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRgl ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(VNHzWpGrfsyBKnLQCXMqJDIEbtvRxh)
  xbmc.executebuiltin(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgl)
 def dp_Episode_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo,args):
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRTY =args.get('videoid')
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRku =args.get('vidtype')
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRgO=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxP(args.get('page'))
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRgS,VNHzWpGrfsyBKnLQCXMqJDIEbtvRhc=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.WavveObj.Get_Episode_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRTY,VNHzWpGrfsyBKnLQCXMqJDIEbtvRku,VNHzWpGrfsyBKnLQCXMqJDIEbtvRgO,orderby=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.get_winEpisodeOrderby())
  for VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi in VNHzWpGrfsyBKnLQCXMqJDIEbtvRgS:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRge='%s회, %s(%s)'%(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('episodenumber'),VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('releasedate'),VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('releaseweekday'))
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRxg ='[%s]\n\n%s'%(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('episodetitle'),VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('synopsis'))
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRgw={'mediatype':'episode','title':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('programtitle'),'year':VNHzWpGrfsyBKnLQCXMqJDIEbtvRxP(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('releasedate')[:4]),'aired':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('releasedate'),'mpaa':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('age'),'episode':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('episodenumber'),'duration':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('playtime'),'plot':VNHzWpGrfsyBKnLQCXMqJDIEbtvRxg,'cast':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('episodeactors')}
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw={'mode':'VOD','programid':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('programid'),'contentid':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('contentid'),'thumbnail':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('thumbnail'),'title':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('programtitle'),'subtitle':VNHzWpGrfsyBKnLQCXMqJDIEbtvRge}
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.add_dir(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('programtitle'),sublabel=VNHzWpGrfsyBKnLQCXMqJDIEbtvRge,img=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('thumbnail'),infoLabels=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgw,isFolder=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu,params=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw)
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRgO==1:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRgw={'plot':'정렬순서를 변경합니다.'}
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw={}
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw['mode'] ='ORDER_BY' 
   if VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.get_winEpisodeOrderby()=='desc':
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd='정렬순서변경 : 최신화부터 -> 1회부터'
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw['orderby']='asc'
   else:
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd='정렬순서변경 : 1회부터 -> 최신화부터'
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw['orderby']='desc'
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.add_dir(VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd,sublabel='',img=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhU,infoLabels=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgw,isFolder=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu,params=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw,isLink=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj)
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRhc:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw={}
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw['mode'] ='EPISODE_LIST' 
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw['videoid']=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('programid')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw['vidtype']='programid'
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw['page'] =VNHzWpGrfsyBKnLQCXMqJDIEbtvRoh(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgO+1)
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd='[B]%s >>[/B]'%'다음 페이지'
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRge=VNHzWpGrfsyBKnLQCXMqJDIEbtvRoh(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgO+1)
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.add_dir(VNHzWpGrfsyBKnLQCXMqJDIEbtvRhd,sublabel=VNHzWpGrfsyBKnLQCXMqJDIEbtvRge,img=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhU,infoLabels=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxa,isFolder=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxj,params=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw)
  xbmcplugin.setContent(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo._addon_handle,'episodes')
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRxc(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgS)>0:xbmcplugin.endOfDirectory(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo._addon_handle,cacheToDisc=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu)
 def dp_LiveChannel_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo,args):
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRxT =args.get('genre')
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRkF=args.get('baseapi')
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRgS=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.WavveObj.Get_LiveChannel_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRxT,VNHzWpGrfsyBKnLQCXMqJDIEbtvRkF)
  for VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi in VNHzWpGrfsyBKnLQCXMqJDIEbtvRgS:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRki =VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('channelid')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRka =VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('studio')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRkP=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('tvshowtitle')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRga =VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('thumbnail')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRgP =VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('age')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRxm =VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('epg')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRgw={'mediatype':'episode','mpaa':VNHzWpGrfsyBKnLQCXMqJDIEbtvRgP,'title':'%s < %s >'%(VNHzWpGrfsyBKnLQCXMqJDIEbtvRka,VNHzWpGrfsyBKnLQCXMqJDIEbtvRkP),'tvshowtitle':VNHzWpGrfsyBKnLQCXMqJDIEbtvRkP,'studio':VNHzWpGrfsyBKnLQCXMqJDIEbtvRka,'plot':'%s\n\n%s'%(VNHzWpGrfsyBKnLQCXMqJDIEbtvRka,VNHzWpGrfsyBKnLQCXMqJDIEbtvRxm)}
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw={'mode':'LIVE','contentid':VNHzWpGrfsyBKnLQCXMqJDIEbtvRki}
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.add_dir(VNHzWpGrfsyBKnLQCXMqJDIEbtvRka,sublabel=VNHzWpGrfsyBKnLQCXMqJDIEbtvRkP,img=VNHzWpGrfsyBKnLQCXMqJDIEbtvRga,infoLabels=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgw,isFolder=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu,params=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw)
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRxc(VNHzWpGrfsyBKnLQCXMqJDIEbtvRgS)>0:xbmcplugin.endOfDirectory(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo._addon_handle,cacheToDisc=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu)
 def dp_Sports_GameList(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo,args):
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRgS=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.WavveObj.Get_Sports_Gamelist()
  for VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi in VNHzWpGrfsyBKnLQCXMqJDIEbtvRgS:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRxk =VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('game_date')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRxo =VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('game_time')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRxd =VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('svc_id')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRxF =VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('away_team')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRxA =VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('home_team')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRxU=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('game_status')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRxw =VNHzWpGrfsyBKnLQCXMqJDIEbtvRgi.get('game_place')
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRxO ='%s vs %s (%s)'%(VNHzWpGrfsyBKnLQCXMqJDIEbtvRxF,VNHzWpGrfsyBKnLQCXMqJDIEbtvRxA,VNHzWpGrfsyBKnLQCXMqJDIEbtvRxw)
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRxS =VNHzWpGrfsyBKnLQCXMqJDIEbtvRxk+' '+VNHzWpGrfsyBKnLQCXMqJDIEbtvRxo
   if VNHzWpGrfsyBKnLQCXMqJDIEbtvRxU=='LIVE':
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRxU='~경기중~'
   elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRxU=='END':
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRxU='경기종료'
   elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRxU=='CANCEL':
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRxU='취소'
   else:
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRxU=''
   if VNHzWpGrfsyBKnLQCXMqJDIEbtvRxU=='':
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRge=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxO
   else:
    VNHzWpGrfsyBKnLQCXMqJDIEbtvRge=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxO+'  '+VNHzWpGrfsyBKnLQCXMqJDIEbtvRxU
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRgw={'mediatype':'episode','title':VNHzWpGrfsyBKnLQCXMqJDIEbtvRxO,'plot':'%s\n\n%s\n\n%s'%(VNHzWpGrfsyBKnLQCXMqJDIEbtvRxS,VNHzWpGrfsyBKnLQCXMqJDIEbtvRxO,VNHzWpGrfsyBKnLQCXMqJDIEbtvRxU)}
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw={'mode':'SPORTS','contentid':VNHzWpGrfsyBKnLQCXMqJDIEbtvRxd}
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.add_dir(VNHzWpGrfsyBKnLQCXMqJDIEbtvRxS,sublabel=VNHzWpGrfsyBKnLQCXMqJDIEbtvRge,img='',infoLabels=VNHzWpGrfsyBKnLQCXMqJDIEbtvRgw,isFolder=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu,params=VNHzWpGrfsyBKnLQCXMqJDIEbtvRhw)
  xbmcplugin.endOfDirectory(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo._addon_handle,cacheToDisc=VNHzWpGrfsyBKnLQCXMqJDIEbtvRxu)
 def wavve_main(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo):
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu=VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.main_params.get('mode',VNHzWpGrfsyBKnLQCXMqJDIEbtvRxa)
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu=='LOGOUT':
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.logout()
   return
  VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.login_main()
  if VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu is VNHzWpGrfsyBKnLQCXMqJDIEbtvRxa:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.dp_Main_List()
  elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu in['LIVE','VOD','MOVIE','SPORTS']:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.play_VIDEO(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.main_params)
  elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu=='LIVE_CATAGORY':
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.dp_LiveCatagory_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.main_params)
  elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu=='MAIN_CATAGORY':
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.dp_MainCatagory_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.main_params)
  elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu=='SUPERSECTION_LIST':
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.dp_SuperSection_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.main_params)
  elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu=='BANDLIVESECTION_LIST':
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.dp_BandLiveSection_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.main_params)
  elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu=='BAND2SECTION_LIST':
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.dp_Band2Section_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.main_params)
  elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu=='PROGRAM_LIST':
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.dp_Program_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.main_params)
  elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu=='EPISODE_LIST':
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.dp_Episode_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.main_params)
  elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu=='MOVIE_LIST':
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.dp_Movie_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.main_params)
  elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu=='LIVE_LIST':
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.dp_LiveChannel_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.main_params)
  elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu=='ORDER_BY':
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.dp_setEpOrderby(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.main_params)
  elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu=='SEARCH_GROUP':
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.dp_Search_Group(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.main_params)
  elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu in['SEARCH_LIST','LOCAL_SEARCH']:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.dp_Search_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.main_params)
  elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu=='WATCH_GROUP':
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.dp_Watch_Group(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.main_params)
  elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu=='WATCH_LIST':
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.dp_Watch_List(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.main_params)
  elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu=='SET_BOOKMARK':
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.dp_Set_Bookmark(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.main_params)
  elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.dp_History_Remove(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.main_params)
  elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu in['TOTAL_SEARCH','TOTAL_HISTORY']:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.dp_Global_Search(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.main_params)
  elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu=='SEARCH_HISTORY':
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.dp_Search_History(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.main_params)
  elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu=='MENU_BOOKMARK':
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.dp_Bookmark_Menu(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.main_params)
  elif VNHzWpGrfsyBKnLQCXMqJDIEbtvRhu=='GAME_LIST':
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.dp_Sports_GameList(VNHzWpGrfsyBKnLQCXMqJDIEbtvRYo.main_params)
  else:
   VNHzWpGrfsyBKnLQCXMqJDIEbtvRxa
# Created by pyminifier (https://github.com/liftoff/pyminifier)
