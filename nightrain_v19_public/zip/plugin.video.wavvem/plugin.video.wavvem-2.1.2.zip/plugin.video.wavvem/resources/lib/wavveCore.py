__author__="NightRain"
lSOdjEKcHRQuvYpwkUPITznsAaobCJ=object
lSOdjEKcHRQuvYpwkUPITznsAaobCM=None
lSOdjEKcHRQuvYpwkUPITznsAaobCf=False
lSOdjEKcHRQuvYpwkUPITznsAaobCL=True
lSOdjEKcHRQuvYpwkUPITznsAaobCB=range
lSOdjEKcHRQuvYpwkUPITznsAaobCF=str
lSOdjEKcHRQuvYpwkUPITznsAaobCy=Exception
lSOdjEKcHRQuvYpwkUPITznsAaobCN=print
lSOdjEKcHRQuvYpwkUPITznsAaobCG=dict
lSOdjEKcHRQuvYpwkUPITznsAaobCX=int
lSOdjEKcHRQuvYpwkUPITznsAaobCh=len
import urllib
import http.cookiejar 
import re
import json
import sys
import requests
import datetime
class lSOdjEKcHRQuvYpwkUPITznsAaobri(lSOdjEKcHRQuvYpwkUPITznsAaobCJ):
 def __init__(lSOdjEKcHRQuvYpwkUPITznsAaobrV):
  lSOdjEKcHRQuvYpwkUPITznsAaobrV.API_DOMAIN='https://apis.wavve.com'
  lSOdjEKcHRQuvYpwkUPITznsAaobrV.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  lSOdjEKcHRQuvYpwkUPITznsAaobrV.CREDENTIAL='none'
  lSOdjEKcHRQuvYpwkUPITznsAaobrV.DEVICE ='pc'
  lSOdjEKcHRQuvYpwkUPITznsAaobrV.DRM ='wm'
  lSOdjEKcHRQuvYpwkUPITznsAaobrV.PARTNER ='pooq'
  lSOdjEKcHRQuvYpwkUPITznsAaobrV.POOQZONE ='none'
  lSOdjEKcHRQuvYpwkUPITznsAaobrV.REGION ='kor'
  lSOdjEKcHRQuvYpwkUPITznsAaobrV.TARGETAGE ='all'
  lSOdjEKcHRQuvYpwkUPITznsAaobrV.HTTPTAG ='https://'
  lSOdjEKcHRQuvYpwkUPITznsAaobrV.LIST_LIMIT=30 
  lSOdjEKcHRQuvYpwkUPITznsAaobrV.EP_LIMIT =30 
  lSOdjEKcHRQuvYpwkUPITznsAaobrV.MV_LIMIT =24 
  lSOdjEKcHRQuvYpwkUPITznsAaobrV.guid ='none' 
  lSOdjEKcHRQuvYpwkUPITznsAaobrV.guidtimestamp='none' 
  lSOdjEKcHRQuvYpwkUPITznsAaobrV.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
  lSOdjEKcHRQuvYpwkUPITznsAaobrV.DEFAULT_HEADER={'user-agent':lSOdjEKcHRQuvYpwkUPITznsAaobrV.USER_AGENT}
 def callRequestCookies(lSOdjEKcHRQuvYpwkUPITznsAaobrV,jobtype,lSOdjEKcHRQuvYpwkUPITznsAaobrX,payload=lSOdjEKcHRQuvYpwkUPITznsAaobCM,params=lSOdjEKcHRQuvYpwkUPITznsAaobCM,headers=lSOdjEKcHRQuvYpwkUPITznsAaobCM,cookies=lSOdjEKcHRQuvYpwkUPITznsAaobCM,redirects=lSOdjEKcHRQuvYpwkUPITznsAaobCf):
  lSOdjEKcHRQuvYpwkUPITznsAaobrC=lSOdjEKcHRQuvYpwkUPITznsAaobrV.DEFAULT_HEADER
  if headers:lSOdjEKcHRQuvYpwkUPITznsAaobrC.update(headers)
  if jobtype=='Get':
   lSOdjEKcHRQuvYpwkUPITznsAaobre=requests.get(lSOdjEKcHRQuvYpwkUPITznsAaobrX,params=params,headers=lSOdjEKcHRQuvYpwkUPITznsAaobrC,cookies=cookies,allow_redirects=redirects)
  else:
   lSOdjEKcHRQuvYpwkUPITznsAaobre=requests.post(lSOdjEKcHRQuvYpwkUPITznsAaobrX,data=payload,params=params,headers=lSOdjEKcHRQuvYpwkUPITznsAaobrC,cookies=cookies,allow_redirects=redirects)
  return lSOdjEKcHRQuvYpwkUPITznsAaobre
 def SaveCredential(lSOdjEKcHRQuvYpwkUPITznsAaobrV,lSOdjEKcHRQuvYpwkUPITznsAaobrW):
  lSOdjEKcHRQuvYpwkUPITznsAaobrV.CREDENTIAL=lSOdjEKcHRQuvYpwkUPITznsAaobrW
 def LoadCredential(lSOdjEKcHRQuvYpwkUPITznsAaobrV):
  return lSOdjEKcHRQuvYpwkUPITznsAaobrV.CREDENTIAL
 def GetDefaultParams(lSOdjEKcHRQuvYpwkUPITznsAaobrV,login=lSOdjEKcHRQuvYpwkUPITznsAaobCL):
  lSOdjEKcHRQuvYpwkUPITznsAaobrx={'apikey':lSOdjEKcHRQuvYpwkUPITznsAaobrV.APIKEY,'credential':lSOdjEKcHRQuvYpwkUPITznsAaobrV.CREDENTIAL if login else 'none','device':lSOdjEKcHRQuvYpwkUPITznsAaobrV.DEVICE,'drm':lSOdjEKcHRQuvYpwkUPITznsAaobrV.DRM,'partner':lSOdjEKcHRQuvYpwkUPITznsAaobrV.PARTNER,'pooqzone':lSOdjEKcHRQuvYpwkUPITznsAaobrV.POOQZONE,'region':lSOdjEKcHRQuvYpwkUPITznsAaobrV.REGION,'targetage':lSOdjEKcHRQuvYpwkUPITznsAaobrV.TARGETAGE}
  return lSOdjEKcHRQuvYpwkUPITznsAaobrx
 def GetGUID(lSOdjEKcHRQuvYpwkUPITznsAaobrV,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   lSOdjEKcHRQuvYpwkUPITznsAaobrt=lSOdjEKcHRQuvYpwkUPITznsAaobrV.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   lSOdjEKcHRQuvYpwkUPITznsAaobrJ=GenerateRandomString(5)
   lSOdjEKcHRQuvYpwkUPITznsAaobrM=lSOdjEKcHRQuvYpwkUPITznsAaobrJ+media+lSOdjEKcHRQuvYpwkUPITznsAaobrt
   return lSOdjEKcHRQuvYpwkUPITznsAaobrM
  def GenerateRandomString(num):
   from random import randint
   lSOdjEKcHRQuvYpwkUPITznsAaobrf=""
   for i in lSOdjEKcHRQuvYpwkUPITznsAaobCB(0,num):
    s=lSOdjEKcHRQuvYpwkUPITznsAaobCF(randint(1,5))
    lSOdjEKcHRQuvYpwkUPITznsAaobrf+=s
   return lSOdjEKcHRQuvYpwkUPITznsAaobrf
  lSOdjEKcHRQuvYpwkUPITznsAaobrM=GenerateID(guid_str)
  lSOdjEKcHRQuvYpwkUPITznsAaobrL=lSOdjEKcHRQuvYpwkUPITznsAaobrV.GetHash(lSOdjEKcHRQuvYpwkUPITznsAaobrM)
  if guidType==2:
   lSOdjEKcHRQuvYpwkUPITznsAaobrL='%s-%s-%s-%s-%s'%(lSOdjEKcHRQuvYpwkUPITznsAaobrL[:8],lSOdjEKcHRQuvYpwkUPITznsAaobrL[8:12],lSOdjEKcHRQuvYpwkUPITznsAaobrL[12:16],lSOdjEKcHRQuvYpwkUPITznsAaobrL[16:20],lSOdjEKcHRQuvYpwkUPITznsAaobrL[20:])
  return lSOdjEKcHRQuvYpwkUPITznsAaobrL
 def GetHash(lSOdjEKcHRQuvYpwkUPITznsAaobrV,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return lSOdjEKcHRQuvYpwkUPITznsAaobCF(m.hexdigest())
 def CheckQuality(lSOdjEKcHRQuvYpwkUPITznsAaobrV,sel_qt,qt_list):
  lSOdjEKcHRQuvYpwkUPITznsAaobrB=0
  for lSOdjEKcHRQuvYpwkUPITznsAaobrF in qt_list:
   if sel_qt>=lSOdjEKcHRQuvYpwkUPITznsAaobrF:return lSOdjEKcHRQuvYpwkUPITznsAaobrF
   lSOdjEKcHRQuvYpwkUPITznsAaobrB=lSOdjEKcHRQuvYpwkUPITznsAaobrF
  return lSOdjEKcHRQuvYpwkUPITznsAaobrB
 def Get_Now_Datetime(lSOdjEKcHRQuvYpwkUPITznsAaobrV):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(lSOdjEKcHRQuvYpwkUPITznsAaobrV,in_text):
  lSOdjEKcHRQuvYpwkUPITznsAaobrN=in_text.replace('&lt;','<').replace('&gt;','>')
  lSOdjEKcHRQuvYpwkUPITznsAaobrN=lSOdjEKcHRQuvYpwkUPITznsAaobrN.replace('$O$','')
  lSOdjEKcHRQuvYpwkUPITznsAaobrN=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',lSOdjEKcHRQuvYpwkUPITznsAaobrN)
  lSOdjEKcHRQuvYpwkUPITznsAaobrN=lSOdjEKcHRQuvYpwkUPITznsAaobrN.lstrip('#')
  return lSOdjEKcHRQuvYpwkUPITznsAaobrN
 def GetCredential(lSOdjEKcHRQuvYpwkUPITznsAaobrV,user_id,user_pw,user_pf):
  lSOdjEKcHRQuvYpwkUPITznsAaobrG=lSOdjEKcHRQuvYpwkUPITznsAaobCf
  try:
   lSOdjEKcHRQuvYpwkUPITznsAaobrX=lSOdjEKcHRQuvYpwkUPITznsAaobrV.API_DOMAIN+ '/login'
   lSOdjEKcHRQuvYpwkUPITznsAaobrx=lSOdjEKcHRQuvYpwkUPITznsAaobrV.GetDefaultParams()
   lSOdjEKcHRQuvYpwkUPITznsAaobrh={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   lSOdjEKcHRQuvYpwkUPITznsAaobrm=lSOdjEKcHRQuvYpwkUPITznsAaobrV.callRequestCookies('Post',lSOdjEKcHRQuvYpwkUPITznsAaobrX,payload=lSOdjEKcHRQuvYpwkUPITznsAaobrh,params=lSOdjEKcHRQuvYpwkUPITznsAaobrx,headers=lSOdjEKcHRQuvYpwkUPITznsAaobCM,cookies=lSOdjEKcHRQuvYpwkUPITznsAaobCM)
   lSOdjEKcHRQuvYpwkUPITznsAaobrg=json.loads(lSOdjEKcHRQuvYpwkUPITznsAaobrm.text)
   lSOdjEKcHRQuvYpwkUPITznsAaobrW=lSOdjEKcHRQuvYpwkUPITznsAaobrg['credential']
   if user_pf!=0:
    lSOdjEKcHRQuvYpwkUPITznsAaobrh={'id':lSOdjEKcHRQuvYpwkUPITznsAaobrW,'password':'','profile':lSOdjEKcHRQuvYpwkUPITznsAaobCF(user_pf),'pushid':'','type':'credential'}
    lSOdjEKcHRQuvYpwkUPITznsAaobrx['credential']=lSOdjEKcHRQuvYpwkUPITznsAaobrW 
    lSOdjEKcHRQuvYpwkUPITznsAaobrm=lSOdjEKcHRQuvYpwkUPITznsAaobrV.callRequestCookies('Post',lSOdjEKcHRQuvYpwkUPITznsAaobrX,payload=lSOdjEKcHRQuvYpwkUPITznsAaobrh,params=lSOdjEKcHRQuvYpwkUPITznsAaobrx,headers=lSOdjEKcHRQuvYpwkUPITznsAaobCM,cookies=lSOdjEKcHRQuvYpwkUPITznsAaobCM)
    lSOdjEKcHRQuvYpwkUPITznsAaobrg=json.loads(lSOdjEKcHRQuvYpwkUPITznsAaobrm.text)
    lSOdjEKcHRQuvYpwkUPITznsAaobrW=lSOdjEKcHRQuvYpwkUPITznsAaobrg['credential']
   if lSOdjEKcHRQuvYpwkUPITznsAaobrW:lSOdjEKcHRQuvYpwkUPITznsAaobrG=lSOdjEKcHRQuvYpwkUPITznsAaobCL
  except lSOdjEKcHRQuvYpwkUPITznsAaobCy as exception:
   lSOdjEKcHRQuvYpwkUPITznsAaobCN(exception)
   lSOdjEKcHRQuvYpwkUPITznsAaobrW='none' 
  lSOdjEKcHRQuvYpwkUPITznsAaobrV.SaveCredential(lSOdjEKcHRQuvYpwkUPITznsAaobrW)
  return lSOdjEKcHRQuvYpwkUPITznsAaobrG
 def GetIssue(lSOdjEKcHRQuvYpwkUPITznsAaobrV):
  lSOdjEKcHRQuvYpwkUPITznsAaobrq=lSOdjEKcHRQuvYpwkUPITznsAaobCf
  try:
   lSOdjEKcHRQuvYpwkUPITznsAaobrX=lSOdjEKcHRQuvYpwkUPITznsAaobrV.API_DOMAIN+'/guid/issue'
   lSOdjEKcHRQuvYpwkUPITznsAaobrx=lSOdjEKcHRQuvYpwkUPITznsAaobrV.GetDefaultParams()
   lSOdjEKcHRQuvYpwkUPITznsAaobrm=lSOdjEKcHRQuvYpwkUPITznsAaobrV.callRequestCookies('Get',lSOdjEKcHRQuvYpwkUPITznsAaobrX,payload=lSOdjEKcHRQuvYpwkUPITznsAaobCM,params=lSOdjEKcHRQuvYpwkUPITznsAaobrx,headers=lSOdjEKcHRQuvYpwkUPITznsAaobCM,cookies=lSOdjEKcHRQuvYpwkUPITznsAaobCM)
   lSOdjEKcHRQuvYpwkUPITznsAaobrg=json.loads(lSOdjEKcHRQuvYpwkUPITznsAaobrm.text)
   lSOdjEKcHRQuvYpwkUPITznsAaobrD=lSOdjEKcHRQuvYpwkUPITznsAaobrg['guid']
   lSOdjEKcHRQuvYpwkUPITznsAaobir=lSOdjEKcHRQuvYpwkUPITznsAaobrg['guidtimestamp']
   if lSOdjEKcHRQuvYpwkUPITznsAaobrD:lSOdjEKcHRQuvYpwkUPITznsAaobrq=lSOdjEKcHRQuvYpwkUPITznsAaobCL
  except lSOdjEKcHRQuvYpwkUPITznsAaobCy as exception:
   lSOdjEKcHRQuvYpwkUPITznsAaobCN(exception)
   lSOdjEKcHRQuvYpwkUPITznsAaobrD='none'
   lSOdjEKcHRQuvYpwkUPITznsAaobir='none' 
  lSOdjEKcHRQuvYpwkUPITznsAaobrV.guid=lSOdjEKcHRQuvYpwkUPITznsAaobrD
  lSOdjEKcHRQuvYpwkUPITznsAaobrV.guidtimestamp=lSOdjEKcHRQuvYpwkUPITznsAaobir
  return lSOdjEKcHRQuvYpwkUPITznsAaobrq
 def Baseapi_Parse(lSOdjEKcHRQuvYpwkUPITznsAaobrV,lSOdjEKcHRQuvYpwkUPITznsAaobiW):
  try:
   lSOdjEKcHRQuvYpwkUPITznsAaobiV =urllib.parse.urlsplit(lSOdjEKcHRQuvYpwkUPITznsAaobiW)
   if lSOdjEKcHRQuvYpwkUPITznsAaobiV.netloc=='':
    lSOdjEKcHRQuvYpwkUPITznsAaobrX=lSOdjEKcHRQuvYpwkUPITznsAaobrV.HTTPTAG+lSOdjEKcHRQuvYpwkUPITznsAaobiV.netloc+lSOdjEKcHRQuvYpwkUPITznsAaobiV.path
   else:
    lSOdjEKcHRQuvYpwkUPITznsAaobrX=lSOdjEKcHRQuvYpwkUPITznsAaobiV.scheme+'://'+lSOdjEKcHRQuvYpwkUPITznsAaobiV.netloc+lSOdjEKcHRQuvYpwkUPITznsAaobiV.path
   lSOdjEKcHRQuvYpwkUPITznsAaobrx=lSOdjEKcHRQuvYpwkUPITznsAaobCG(urllib.parse.parse_qsl(lSOdjEKcHRQuvYpwkUPITznsAaobiV.query))
  except:
   lSOdjEKcHRQuvYpwkUPITznsAaobCN(exception)
   return '',{}
  return lSOdjEKcHRQuvYpwkUPITznsAaobrX,lSOdjEKcHRQuvYpwkUPITznsAaobrx
 def GetSupermultiUrl(lSOdjEKcHRQuvYpwkUPITznsAaobrV,sCode,sIndex='0'):
  try:
   lSOdjEKcHRQuvYpwkUPITznsAaobrX=lSOdjEKcHRQuvYpwkUPITznsAaobrV.API_DOMAIN+'/cf/supermultisections/'+sCode
   lSOdjEKcHRQuvYpwkUPITznsAaobrx=lSOdjEKcHRQuvYpwkUPITznsAaobrV.GetDefaultParams(login=lSOdjEKcHRQuvYpwkUPITznsAaobCf)
   lSOdjEKcHRQuvYpwkUPITznsAaobrm=lSOdjEKcHRQuvYpwkUPITznsAaobrV.callRequestCookies('Get',lSOdjEKcHRQuvYpwkUPITznsAaobrX,payload=lSOdjEKcHRQuvYpwkUPITznsAaobCM,params=lSOdjEKcHRQuvYpwkUPITznsAaobrx,headers=lSOdjEKcHRQuvYpwkUPITznsAaobCM,cookies=lSOdjEKcHRQuvYpwkUPITznsAaobCM)
   lSOdjEKcHRQuvYpwkUPITznsAaobrg=json.loads(lSOdjEKcHRQuvYpwkUPITznsAaobrm.text)
   lSOdjEKcHRQuvYpwkUPITznsAaobiC=lSOdjEKcHRQuvYpwkUPITznsAaobrg['multisectionlist'][lSOdjEKcHRQuvYpwkUPITznsAaobCX(sIndex)]['eventlist'][1]['url']
  except lSOdjEKcHRQuvYpwkUPITznsAaobCy as exception:
   lSOdjEKcHRQuvYpwkUPITznsAaobCN(exception)
   return ''
  return lSOdjEKcHRQuvYpwkUPITznsAaobiC
 def Get_LiveCatagory_List(lSOdjEKcHRQuvYpwkUPITznsAaobrV,sCode,sIndex='0'):
  lSOdjEKcHRQuvYpwkUPITznsAaobie=[]
  lSOdjEKcHRQuvYpwkUPITznsAaobiW =lSOdjEKcHRQuvYpwkUPITznsAaobrV.GetSupermultiUrl(sCode,sIndex)
  (lSOdjEKcHRQuvYpwkUPITznsAaobrX,lSOdjEKcHRQuvYpwkUPITznsAaobrx)=lSOdjEKcHRQuvYpwkUPITznsAaobrV.Baseapi_Parse(lSOdjEKcHRQuvYpwkUPITznsAaobiW)
  if lSOdjEKcHRQuvYpwkUPITznsAaobrX=='':return lSOdjEKcHRQuvYpwkUPITznsAaobie,''
  try:
   lSOdjEKcHRQuvYpwkUPITznsAaobrx.update(lSOdjEKcHRQuvYpwkUPITznsAaobrV.GetDefaultParams(login=lSOdjEKcHRQuvYpwkUPITznsAaobCf))
   lSOdjEKcHRQuvYpwkUPITznsAaobrm=lSOdjEKcHRQuvYpwkUPITznsAaobrV.callRequestCookies('Get',lSOdjEKcHRQuvYpwkUPITznsAaobrX,payload=lSOdjEKcHRQuvYpwkUPITznsAaobCM,params=lSOdjEKcHRQuvYpwkUPITznsAaobrx,headers=lSOdjEKcHRQuvYpwkUPITznsAaobCM,cookies=lSOdjEKcHRQuvYpwkUPITznsAaobCM)
   lSOdjEKcHRQuvYpwkUPITznsAaobrg=json.loads(lSOdjEKcHRQuvYpwkUPITznsAaobrm.text)
   if not('filter_item_list' in lSOdjEKcHRQuvYpwkUPITznsAaobrg['filter']['filterlist'][0]):return[],''
   lSOdjEKcHRQuvYpwkUPITznsAaobit=lSOdjEKcHRQuvYpwkUPITznsAaobrg['filter']['filterlist'][0]['filter_item_list']
   for lSOdjEKcHRQuvYpwkUPITznsAaobiJ in lSOdjEKcHRQuvYpwkUPITznsAaobit:
    lSOdjEKcHRQuvYpwkUPITznsAaobiM={'title':lSOdjEKcHRQuvYpwkUPITznsAaobiJ['title'],'genre':lSOdjEKcHRQuvYpwkUPITznsAaobiJ['api_parameters'][lSOdjEKcHRQuvYpwkUPITznsAaobiJ['api_parameters'].index('=')+1:]}
    lSOdjEKcHRQuvYpwkUPITznsAaobie.append(lSOdjEKcHRQuvYpwkUPITznsAaobiM)
  except lSOdjEKcHRQuvYpwkUPITznsAaobCy as exception:
   lSOdjEKcHRQuvYpwkUPITznsAaobCN(exception)
   return[],''
  return lSOdjEKcHRQuvYpwkUPITznsAaobie,lSOdjEKcHRQuvYpwkUPITznsAaobiW
 def Get_MainCatagory_List(lSOdjEKcHRQuvYpwkUPITznsAaobrV,sCode,sIndex='0'):
  lSOdjEKcHRQuvYpwkUPITznsAaobie=[]
  lSOdjEKcHRQuvYpwkUPITznsAaobiW =lSOdjEKcHRQuvYpwkUPITznsAaobrV.GetSupermultiUrl(sCode,sIndex)
  (lSOdjEKcHRQuvYpwkUPITznsAaobrX,lSOdjEKcHRQuvYpwkUPITznsAaobrx)=lSOdjEKcHRQuvYpwkUPITznsAaobrV.Baseapi_Parse(lSOdjEKcHRQuvYpwkUPITznsAaobiW)
  if lSOdjEKcHRQuvYpwkUPITznsAaobrX=='':return lSOdjEKcHRQuvYpwkUPITznsAaobie
  try:
   lSOdjEKcHRQuvYpwkUPITznsAaobrx.update(lSOdjEKcHRQuvYpwkUPITznsAaobrV.GetDefaultParams(login=lSOdjEKcHRQuvYpwkUPITznsAaobCf))
   lSOdjEKcHRQuvYpwkUPITznsAaobrm=lSOdjEKcHRQuvYpwkUPITznsAaobrV.callRequestCookies('Get',lSOdjEKcHRQuvYpwkUPITznsAaobrX,payload=lSOdjEKcHRQuvYpwkUPITznsAaobCM,params=lSOdjEKcHRQuvYpwkUPITznsAaobrx,headers=lSOdjEKcHRQuvYpwkUPITznsAaobCM,cookies=lSOdjEKcHRQuvYpwkUPITznsAaobCM)
   lSOdjEKcHRQuvYpwkUPITznsAaobrg=json.loads(lSOdjEKcHRQuvYpwkUPITznsAaobrm.text)
   if not('celllist' in lSOdjEKcHRQuvYpwkUPITznsAaobrg['band']):return[]
   lSOdjEKcHRQuvYpwkUPITznsAaobit=lSOdjEKcHRQuvYpwkUPITznsAaobrg['band']['celllist']
   for lSOdjEKcHRQuvYpwkUPITznsAaobiJ in lSOdjEKcHRQuvYpwkUPITznsAaobit:
    lSOdjEKcHRQuvYpwkUPITznsAaobif =lSOdjEKcHRQuvYpwkUPITznsAaobiJ['event_list'][1]['url']
    (lSOdjEKcHRQuvYpwkUPITznsAaobiL,lSOdjEKcHRQuvYpwkUPITznsAaobiB)=lSOdjEKcHRQuvYpwkUPITznsAaobrV.Baseapi_Parse(lSOdjEKcHRQuvYpwkUPITznsAaobif)
    lSOdjEKcHRQuvYpwkUPITznsAaobiM={'title':lSOdjEKcHRQuvYpwkUPITznsAaobiJ['title_list'][0]['text'],'suburl':lSOdjEKcHRQuvYpwkUPITznsAaobiL,'subapi':lSOdjEKcHRQuvYpwkUPITznsAaobiB.get('api'),'subtype':'catagory' if lSOdjEKcHRQuvYpwkUPITznsAaobiB else 'supersection'}
    lSOdjEKcHRQuvYpwkUPITznsAaobie.append(lSOdjEKcHRQuvYpwkUPITznsAaobiM)
  except lSOdjEKcHRQuvYpwkUPITznsAaobCy as exception:
   lSOdjEKcHRQuvYpwkUPITznsAaobCN(exception)
   return[]
  return lSOdjEKcHRQuvYpwkUPITznsAaobie
 def Get_SuperMultiSection_List(lSOdjEKcHRQuvYpwkUPITznsAaobrV,subapi_text):
  lSOdjEKcHRQuvYpwkUPITznsAaobie=[]
  lSOdjEKcHRQuvYpwkUPITznsAaobrx={}
  try:
   lSOdjEKcHRQuvYpwkUPITznsAaobiV =urllib.parse.urlsplit(subapi_text)
   if lSOdjEKcHRQuvYpwkUPITznsAaobiV.path.find('apis.wavve.com')>=0: 
    lSOdjEKcHRQuvYpwkUPITznsAaobrX=lSOdjEKcHRQuvYpwkUPITznsAaobrV.HTTPTAG+lSOdjEKcHRQuvYpwkUPITznsAaobiV.path 
    lSOdjEKcHRQuvYpwkUPITznsAaobrx=lSOdjEKcHRQuvYpwkUPITznsAaobCG(urllib.parse.parse_qsl(lSOdjEKcHRQuvYpwkUPITznsAaobiV.query))
   else:
    lSOdjEKcHRQuvYpwkUPITznsAaobrX=lSOdjEKcHRQuvYpwkUPITznsAaobrV.API_DOMAIN+'/cf'+lSOdjEKcHRQuvYpwkUPITznsAaobiV.path 
   lSOdjEKcHRQuvYpwkUPITznsAaobrX=lSOdjEKcHRQuvYpwkUPITznsAaobrX.replace('supermultisection/','supermultisections/')
  except lSOdjEKcHRQuvYpwkUPITznsAaobCy as exception:
   lSOdjEKcHRQuvYpwkUPITznsAaobCN(exception)
   return[]
  try:
   lSOdjEKcHRQuvYpwkUPITznsAaobrx.update(lSOdjEKcHRQuvYpwkUPITznsAaobrV.GetDefaultParams(login=lSOdjEKcHRQuvYpwkUPITznsAaobCf))
   lSOdjEKcHRQuvYpwkUPITznsAaobrm=lSOdjEKcHRQuvYpwkUPITznsAaobrV.callRequestCookies('Get',lSOdjEKcHRQuvYpwkUPITznsAaobrX,payload=lSOdjEKcHRQuvYpwkUPITznsAaobCM,params=lSOdjEKcHRQuvYpwkUPITznsAaobCM,headers=lSOdjEKcHRQuvYpwkUPITznsAaobCM,cookies=lSOdjEKcHRQuvYpwkUPITznsAaobCM)
   lSOdjEKcHRQuvYpwkUPITznsAaobrg=json.loads(lSOdjEKcHRQuvYpwkUPITznsAaobrm.text)
   if not('multisectionlist' in lSOdjEKcHRQuvYpwkUPITznsAaobrg):return[]
   lSOdjEKcHRQuvYpwkUPITznsAaobit=lSOdjEKcHRQuvYpwkUPITznsAaobrg['multisectionlist']
   for lSOdjEKcHRQuvYpwkUPITznsAaobiJ in lSOdjEKcHRQuvYpwkUPITznsAaobit:
    lSOdjEKcHRQuvYpwkUPITznsAaobiF=lSOdjEKcHRQuvYpwkUPITznsAaobiJ['title']
    if lSOdjEKcHRQuvYpwkUPITznsAaobCh(lSOdjEKcHRQuvYpwkUPITznsAaobiF)==0:continue
    if lSOdjEKcHRQuvYpwkUPITznsAaobiF=='minor':continue
    if re.search(u'베너',lSOdjEKcHRQuvYpwkUPITznsAaobiF):continue
    if re.search(u'배너',lSOdjEKcHRQuvYpwkUPITznsAaobiF):continue 
    if lSOdjEKcHRQuvYpwkUPITznsAaobCh(lSOdjEKcHRQuvYpwkUPITznsAaobiJ['eventlist'])>=3:
     lSOdjEKcHRQuvYpwkUPITznsAaobiB =lSOdjEKcHRQuvYpwkUPITznsAaobiJ['eventlist'][2]['url']
    else:
     lSOdjEKcHRQuvYpwkUPITznsAaobiB =lSOdjEKcHRQuvYpwkUPITznsAaobiJ['eventlist'][1]['url']
    lSOdjEKcHRQuvYpwkUPITznsAaobiy=lSOdjEKcHRQuvYpwkUPITznsAaobiJ['cell_type']
    if lSOdjEKcHRQuvYpwkUPITznsAaobiy=='band_2':
     if lSOdjEKcHRQuvYpwkUPITznsAaobiB.find('channellist=')>=0:
      lSOdjEKcHRQuvYpwkUPITznsAaobiy='band_live'
    lSOdjEKcHRQuvYpwkUPITznsAaobiM={'title':lSOdjEKcHRQuvYpwkUPITznsAaobrV.Get_ChangeText(lSOdjEKcHRQuvYpwkUPITznsAaobiF),'subapi':lSOdjEKcHRQuvYpwkUPITznsAaobiB,'cell_type':lSOdjEKcHRQuvYpwkUPITznsAaobiy}
    lSOdjEKcHRQuvYpwkUPITznsAaobie.append(lSOdjEKcHRQuvYpwkUPITznsAaobiM)
  except lSOdjEKcHRQuvYpwkUPITznsAaobCy as exception:
   lSOdjEKcHRQuvYpwkUPITznsAaobCN(exception)
   return[]
  return lSOdjEKcHRQuvYpwkUPITznsAaobie
 def Get_BandLiveSection_List(lSOdjEKcHRQuvYpwkUPITznsAaobrV,lSOdjEKcHRQuvYpwkUPITznsAaobiW,page_int=1):
  lSOdjEKcHRQuvYpwkUPITznsAaobiN=[]
  lSOdjEKcHRQuvYpwkUPITznsAaobiG=lSOdjEKcHRQuvYpwkUPITznsAaobiD=1
  lSOdjEKcHRQuvYpwkUPITznsAaobiX=lSOdjEKcHRQuvYpwkUPITznsAaobCf
  try:
   (lSOdjEKcHRQuvYpwkUPITznsAaobrX,lSOdjEKcHRQuvYpwkUPITznsAaobrx)=lSOdjEKcHRQuvYpwkUPITznsAaobrV.Baseapi_Parse(lSOdjEKcHRQuvYpwkUPITznsAaobiW)
  except lSOdjEKcHRQuvYpwkUPITznsAaobCy as exception:
   lSOdjEKcHRQuvYpwkUPITznsAaobCN(exception)
   return[],lSOdjEKcHRQuvYpwkUPITznsAaobCf
  try:
   lSOdjEKcHRQuvYpwkUPITznsAaobrx['limit']=lSOdjEKcHRQuvYpwkUPITznsAaobrV.LIST_LIMIT
   lSOdjEKcHRQuvYpwkUPITznsAaobrx['offset']=lSOdjEKcHRQuvYpwkUPITznsAaobCF((page_int-1)*lSOdjEKcHRQuvYpwkUPITznsAaobrV.LIST_LIMIT)
   lSOdjEKcHRQuvYpwkUPITznsAaobrx.update(lSOdjEKcHRQuvYpwkUPITznsAaobrV.GetDefaultParams(login=lSOdjEKcHRQuvYpwkUPITznsAaobCf))
   lSOdjEKcHRQuvYpwkUPITznsAaobrm=lSOdjEKcHRQuvYpwkUPITznsAaobrV.callRequestCookies('Get',lSOdjEKcHRQuvYpwkUPITznsAaobrX,payload=lSOdjEKcHRQuvYpwkUPITznsAaobCM,params=lSOdjEKcHRQuvYpwkUPITznsAaobrx,headers=lSOdjEKcHRQuvYpwkUPITznsAaobCM,cookies=lSOdjEKcHRQuvYpwkUPITznsAaobCM)
   lSOdjEKcHRQuvYpwkUPITznsAaobrg=json.loads(lSOdjEKcHRQuvYpwkUPITznsAaobrm.text)
   if not('celllist' in lSOdjEKcHRQuvYpwkUPITznsAaobrg['cell_toplist']):return[],lSOdjEKcHRQuvYpwkUPITznsAaobCf
   lSOdjEKcHRQuvYpwkUPITznsAaobit=lSOdjEKcHRQuvYpwkUPITznsAaobrg['cell_toplist']['celllist']
   for lSOdjEKcHRQuvYpwkUPITznsAaobiJ in lSOdjEKcHRQuvYpwkUPITznsAaobit:
    lSOdjEKcHRQuvYpwkUPITznsAaobih =lSOdjEKcHRQuvYpwkUPITznsAaobiJ['event_list'][1]['url']
    lSOdjEKcHRQuvYpwkUPITznsAaobim=urllib.parse.urlsplit(lSOdjEKcHRQuvYpwkUPITznsAaobih).query
    lSOdjEKcHRQuvYpwkUPITznsAaobim=lSOdjEKcHRQuvYpwkUPITznsAaobCG(urllib.parse.parse_qsl(lSOdjEKcHRQuvYpwkUPITznsAaobim))
    lSOdjEKcHRQuvYpwkUPITznsAaobig='channelid'
    lSOdjEKcHRQuvYpwkUPITznsAaobiq=lSOdjEKcHRQuvYpwkUPITznsAaobim[lSOdjEKcHRQuvYpwkUPITznsAaobig]
    lSOdjEKcHRQuvYpwkUPITznsAaobiM={'studio':lSOdjEKcHRQuvYpwkUPITznsAaobiJ['title_list'][0]['text'],'tvshowtitle':lSOdjEKcHRQuvYpwkUPITznsAaobrV.Get_ChangeText(lSOdjEKcHRQuvYpwkUPITznsAaobiJ['title_list'][1]['text']),'channelid':lSOdjEKcHRQuvYpwkUPITznsAaobiq,'age':lSOdjEKcHRQuvYpwkUPITznsAaobiJ.get('age'),'thumbnail':'https://%s'%lSOdjEKcHRQuvYpwkUPITznsAaobiJ.get('thumbnail')}
    lSOdjEKcHRQuvYpwkUPITznsAaobiN.append(lSOdjEKcHRQuvYpwkUPITznsAaobiM)
   lSOdjEKcHRQuvYpwkUPITznsAaobiG=lSOdjEKcHRQuvYpwkUPITznsAaobCX(lSOdjEKcHRQuvYpwkUPITznsAaobrg['cell_toplist']['pagecount'])
   if lSOdjEKcHRQuvYpwkUPITznsAaobrg['cell_toplist']['count']:lSOdjEKcHRQuvYpwkUPITznsAaobiD =lSOdjEKcHRQuvYpwkUPITznsAaobCX(lSOdjEKcHRQuvYpwkUPITznsAaobrg['cell_toplist']['count'])
   else:lSOdjEKcHRQuvYpwkUPITznsAaobiD=lSOdjEKcHRQuvYpwkUPITznsAaobrV.LIST_LIMIT*page_int
   lSOdjEKcHRQuvYpwkUPITznsAaobiX=lSOdjEKcHRQuvYpwkUPITznsAaobiG>lSOdjEKcHRQuvYpwkUPITznsAaobiD
  except lSOdjEKcHRQuvYpwkUPITznsAaobCy as exception:
   lSOdjEKcHRQuvYpwkUPITznsAaobCN(exception)
   return[],lSOdjEKcHRQuvYpwkUPITznsAaobCf
  return lSOdjEKcHRQuvYpwkUPITznsAaobiN,lSOdjEKcHRQuvYpwkUPITznsAaobiX
 def Get_Band2Section_List(lSOdjEKcHRQuvYpwkUPITznsAaobrV,lSOdjEKcHRQuvYpwkUPITznsAaobiW,page_int=1):
  lSOdjEKcHRQuvYpwkUPITznsAaobVr=[]
  lSOdjEKcHRQuvYpwkUPITznsAaobiG=lSOdjEKcHRQuvYpwkUPITznsAaobiD=1
  lSOdjEKcHRQuvYpwkUPITznsAaobiX=lSOdjEKcHRQuvYpwkUPITznsAaobCf
  try:
   (lSOdjEKcHRQuvYpwkUPITznsAaobrX,lSOdjEKcHRQuvYpwkUPITznsAaobrx)=lSOdjEKcHRQuvYpwkUPITznsAaobrV.Baseapi_Parse(lSOdjEKcHRQuvYpwkUPITznsAaobiW)
  except lSOdjEKcHRQuvYpwkUPITznsAaobCy as exception:
   lSOdjEKcHRQuvYpwkUPITznsAaobCN(exception)
   return[],lSOdjEKcHRQuvYpwkUPITznsAaobCf
  try:
   lSOdjEKcHRQuvYpwkUPITznsAaobrx['came'] ='BandView'
   lSOdjEKcHRQuvYpwkUPITznsAaobrx['limit']=lSOdjEKcHRQuvYpwkUPITznsAaobrV.LIST_LIMIT
   lSOdjEKcHRQuvYpwkUPITznsAaobrx['offset']=lSOdjEKcHRQuvYpwkUPITznsAaobCF((page_int-1)*lSOdjEKcHRQuvYpwkUPITznsAaobrV.LIST_LIMIT)
   lSOdjEKcHRQuvYpwkUPITznsAaobrx.update(lSOdjEKcHRQuvYpwkUPITznsAaobrV.GetDefaultParams(login=lSOdjEKcHRQuvYpwkUPITznsAaobCf))
   lSOdjEKcHRQuvYpwkUPITznsAaobrm=lSOdjEKcHRQuvYpwkUPITznsAaobrV.callRequestCookies('Get',lSOdjEKcHRQuvYpwkUPITznsAaobrX,payload=lSOdjEKcHRQuvYpwkUPITznsAaobCM,params=lSOdjEKcHRQuvYpwkUPITznsAaobrx,headers=lSOdjEKcHRQuvYpwkUPITznsAaobCM,cookies=lSOdjEKcHRQuvYpwkUPITznsAaobCM)
   lSOdjEKcHRQuvYpwkUPITznsAaobrg=json.loads(lSOdjEKcHRQuvYpwkUPITznsAaobrm.text)
   if not('celllist' in lSOdjEKcHRQuvYpwkUPITznsAaobrg['cell_toplist']):return[],lSOdjEKcHRQuvYpwkUPITznsAaobCf
   lSOdjEKcHRQuvYpwkUPITznsAaobit=lSOdjEKcHRQuvYpwkUPITznsAaobrg['cell_toplist']['celllist']
   for lSOdjEKcHRQuvYpwkUPITznsAaobiJ in lSOdjEKcHRQuvYpwkUPITznsAaobit:
    lSOdjEKcHRQuvYpwkUPITznsAaobih =lSOdjEKcHRQuvYpwkUPITznsAaobiJ['event_list'][1]['url']
    lSOdjEKcHRQuvYpwkUPITznsAaobim=urllib.parse.urlsplit(lSOdjEKcHRQuvYpwkUPITznsAaobih).query
    lSOdjEKcHRQuvYpwkUPITznsAaobim=lSOdjEKcHRQuvYpwkUPITznsAaobCG(urllib.parse.parse_qsl(lSOdjEKcHRQuvYpwkUPITznsAaobim))
    lSOdjEKcHRQuvYpwkUPITznsAaobig='contentid'
    lSOdjEKcHRQuvYpwkUPITznsAaobiq=lSOdjEKcHRQuvYpwkUPITznsAaobim[lSOdjEKcHRQuvYpwkUPITznsAaobig]
    lSOdjEKcHRQuvYpwkUPITznsAaobiM={'programtitle':lSOdjEKcHRQuvYpwkUPITznsAaobiJ['title_list'][0]['text'],'episodetitle':lSOdjEKcHRQuvYpwkUPITznsAaobrV.Get_ChangeText(lSOdjEKcHRQuvYpwkUPITznsAaobiJ['title_list'][1]['text']),'age':lSOdjEKcHRQuvYpwkUPITznsAaobiJ.get('age'),'thumbnail':lSOdjEKcHRQuvYpwkUPITznsAaobrV.HTTPTAG+lSOdjEKcHRQuvYpwkUPITznsAaobiJ.get('thumbnail'),'vidtype':lSOdjEKcHRQuvYpwkUPITznsAaobig,'videoid':lSOdjEKcHRQuvYpwkUPITznsAaobiq}
    lSOdjEKcHRQuvYpwkUPITznsAaobVr.append(lSOdjEKcHRQuvYpwkUPITznsAaobiM)
   lSOdjEKcHRQuvYpwkUPITznsAaobiG=lSOdjEKcHRQuvYpwkUPITznsAaobCX(lSOdjEKcHRQuvYpwkUPITznsAaobrg['cell_toplist']['pagecount'])
   if lSOdjEKcHRQuvYpwkUPITznsAaobrg['cell_toplist']['count']:lSOdjEKcHRQuvYpwkUPITznsAaobiD =lSOdjEKcHRQuvYpwkUPITznsAaobCX(lSOdjEKcHRQuvYpwkUPITznsAaobrg['cell_toplist']['count'])
   else:lSOdjEKcHRQuvYpwkUPITznsAaobiD=lSOdjEKcHRQuvYpwkUPITznsAaobrV.LIST_LIMIT*page_int
   lSOdjEKcHRQuvYpwkUPITznsAaobiX=lSOdjEKcHRQuvYpwkUPITznsAaobiG>lSOdjEKcHRQuvYpwkUPITznsAaobiD
  except lSOdjEKcHRQuvYpwkUPITznsAaobCy as exception:
   lSOdjEKcHRQuvYpwkUPITznsAaobCN(exception)
   return[],lSOdjEKcHRQuvYpwkUPITznsAaobCf
  return lSOdjEKcHRQuvYpwkUPITznsAaobVr,lSOdjEKcHRQuvYpwkUPITznsAaobiX
 def Get_Program_List(lSOdjEKcHRQuvYpwkUPITznsAaobrV,lSOdjEKcHRQuvYpwkUPITznsAaobiW,page_int=1,orderby='-'):
  lSOdjEKcHRQuvYpwkUPITznsAaobVi=[]
  lSOdjEKcHRQuvYpwkUPITznsAaobiG=lSOdjEKcHRQuvYpwkUPITznsAaobiD=1
  lSOdjEKcHRQuvYpwkUPITznsAaobiX=lSOdjEKcHRQuvYpwkUPITznsAaobCf
  (lSOdjEKcHRQuvYpwkUPITznsAaobrX,lSOdjEKcHRQuvYpwkUPITznsAaobrx)=lSOdjEKcHRQuvYpwkUPITznsAaobrV.Baseapi_Parse(lSOdjEKcHRQuvYpwkUPITznsAaobiW)
  if lSOdjEKcHRQuvYpwkUPITznsAaobrX=='':return lSOdjEKcHRQuvYpwkUPITznsAaobVi,lSOdjEKcHRQuvYpwkUPITznsAaobiX
  try:
   lSOdjEKcHRQuvYpwkUPITznsAaobrx['limit'] =lSOdjEKcHRQuvYpwkUPITznsAaobrV.LIST_LIMIT
   lSOdjEKcHRQuvYpwkUPITznsAaobrx['offset']=lSOdjEKcHRQuvYpwkUPITznsAaobCF((page_int-1)*lSOdjEKcHRQuvYpwkUPITznsAaobrV.LIST_LIMIT)
   lSOdjEKcHRQuvYpwkUPITznsAaobrx['page'] =lSOdjEKcHRQuvYpwkUPITznsAaobCF(page_int)
   if lSOdjEKcHRQuvYpwkUPITznsAaobrx.get('orderby')!='' and lSOdjEKcHRQuvYpwkUPITznsAaobrx.get('orderby')!='regdatefirst' and orderby!='-':
    lSOdjEKcHRQuvYpwkUPITznsAaobrx['orderby']=orderby 
   lSOdjEKcHRQuvYpwkUPITznsAaobrx.update(lSOdjEKcHRQuvYpwkUPITznsAaobrV.GetDefaultParams(login=lSOdjEKcHRQuvYpwkUPITznsAaobCf))
   lSOdjEKcHRQuvYpwkUPITznsAaobrm=lSOdjEKcHRQuvYpwkUPITznsAaobrV.callRequestCookies('Get',lSOdjEKcHRQuvYpwkUPITznsAaobrX,payload=lSOdjEKcHRQuvYpwkUPITznsAaobCM,params=lSOdjEKcHRQuvYpwkUPITznsAaobrx,headers=lSOdjEKcHRQuvYpwkUPITznsAaobCM,cookies=lSOdjEKcHRQuvYpwkUPITznsAaobCM)
   lSOdjEKcHRQuvYpwkUPITznsAaobrg=json.loads(lSOdjEKcHRQuvYpwkUPITznsAaobrm.text)
   if lSOdjEKcHRQuvYpwkUPITznsAaobiW.find('instantplay')>=0:
    if not('celllist' in lSOdjEKcHRQuvYpwkUPITznsAaobrg['band']):return lSOdjEKcHRQuvYpwkUPITznsAaobVi,lSOdjEKcHRQuvYpwkUPITznsAaobiX
    lSOdjEKcHRQuvYpwkUPITznsAaobit=lSOdjEKcHRQuvYpwkUPITznsAaobrg['band']['celllist']
   else:
    if not('celllist' in lSOdjEKcHRQuvYpwkUPITznsAaobrg['cell_toplist']):return lSOdjEKcHRQuvYpwkUPITznsAaobVi,lSOdjEKcHRQuvYpwkUPITznsAaobiX
    lSOdjEKcHRQuvYpwkUPITznsAaobit=lSOdjEKcHRQuvYpwkUPITznsAaobrg['cell_toplist']['celllist']
   for lSOdjEKcHRQuvYpwkUPITznsAaobiJ in lSOdjEKcHRQuvYpwkUPITznsAaobit:
    for lSOdjEKcHRQuvYpwkUPITznsAaobVC in lSOdjEKcHRQuvYpwkUPITznsAaobiJ['event_list']:
     if lSOdjEKcHRQuvYpwkUPITznsAaobVC.get('type')=='on-navigation':
      lSOdjEKcHRQuvYpwkUPITznsAaobih =lSOdjEKcHRQuvYpwkUPITznsAaobVC['url']
    lSOdjEKcHRQuvYpwkUPITznsAaobim=urllib.parse.urlsplit(lSOdjEKcHRQuvYpwkUPITznsAaobih).query
    lSOdjEKcHRQuvYpwkUPITznsAaobig=lSOdjEKcHRQuvYpwkUPITznsAaobim[0:lSOdjEKcHRQuvYpwkUPITznsAaobim.find('=')]
    lSOdjEKcHRQuvYpwkUPITznsAaobiq=lSOdjEKcHRQuvYpwkUPITznsAaobim[lSOdjEKcHRQuvYpwkUPITznsAaobim.find('=')+1:]
    lSOdjEKcHRQuvYpwkUPITznsAaobiM={'title':lSOdjEKcHRQuvYpwkUPITznsAaobiJ['title_list'][0]['text'],'age':lSOdjEKcHRQuvYpwkUPITznsAaobiJ['age'],'thumbnail':'https://%s'%lSOdjEKcHRQuvYpwkUPITznsAaobiJ.get('thumbnail'),'videoid':lSOdjEKcHRQuvYpwkUPITznsAaobiq,'vidtype':lSOdjEKcHRQuvYpwkUPITznsAaobig}
    lSOdjEKcHRQuvYpwkUPITznsAaobVi.append(lSOdjEKcHRQuvYpwkUPITznsAaobiM)
   if lSOdjEKcHRQuvYpwkUPITznsAaobiW.find('instantplay')<0:
    lSOdjEKcHRQuvYpwkUPITznsAaobiG=lSOdjEKcHRQuvYpwkUPITznsAaobCX(lSOdjEKcHRQuvYpwkUPITznsAaobrg['cell_toplist']['pagecount'])
    if lSOdjEKcHRQuvYpwkUPITznsAaobrg['cell_toplist']['count']:lSOdjEKcHRQuvYpwkUPITznsAaobiD =lSOdjEKcHRQuvYpwkUPITznsAaobCX(lSOdjEKcHRQuvYpwkUPITznsAaobrg['cell_toplist']['count'])
    else:lSOdjEKcHRQuvYpwkUPITznsAaobiD=lSOdjEKcHRQuvYpwkUPITznsAaobrV.LIST_LIMIT*page_int
    lSOdjEKcHRQuvYpwkUPITznsAaobiX=lSOdjEKcHRQuvYpwkUPITznsAaobiG>lSOdjEKcHRQuvYpwkUPITznsAaobiD
  except lSOdjEKcHRQuvYpwkUPITznsAaobCy as exception:
   lSOdjEKcHRQuvYpwkUPITznsAaobCN(exception)
   return[],lSOdjEKcHRQuvYpwkUPITznsAaobCf
  return lSOdjEKcHRQuvYpwkUPITznsAaobVi,lSOdjEKcHRQuvYpwkUPITznsAaobiX
 def Get_Movie_List(lSOdjEKcHRQuvYpwkUPITznsAaobrV,lSOdjEKcHRQuvYpwkUPITznsAaobiW,page_int=1):
  lSOdjEKcHRQuvYpwkUPITznsAaobVe=[]
  lSOdjEKcHRQuvYpwkUPITznsAaobiG=lSOdjEKcHRQuvYpwkUPITznsAaobiD=1
  lSOdjEKcHRQuvYpwkUPITznsAaobiX=lSOdjEKcHRQuvYpwkUPITznsAaobCf
  (lSOdjEKcHRQuvYpwkUPITznsAaobrX,lSOdjEKcHRQuvYpwkUPITznsAaobrx)=lSOdjEKcHRQuvYpwkUPITznsAaobrV.Baseapi_Parse(lSOdjEKcHRQuvYpwkUPITznsAaobiW)
  if lSOdjEKcHRQuvYpwkUPITznsAaobrX=='':return lSOdjEKcHRQuvYpwkUPITznsAaobVe,lSOdjEKcHRQuvYpwkUPITznsAaobiX
  try:
   lSOdjEKcHRQuvYpwkUPITznsAaobrx['limit']=lSOdjEKcHRQuvYpwkUPITznsAaobrV.MV_LIMIT
   lSOdjEKcHRQuvYpwkUPITznsAaobrx['offset']=lSOdjEKcHRQuvYpwkUPITznsAaobCF((page_int-1)*lSOdjEKcHRQuvYpwkUPITznsAaobrV.MV_LIMIT)
   lSOdjEKcHRQuvYpwkUPITznsAaobrx.update(lSOdjEKcHRQuvYpwkUPITznsAaobrV.GetDefaultParams(login=lSOdjEKcHRQuvYpwkUPITznsAaobCf))
   lSOdjEKcHRQuvYpwkUPITznsAaobrm=lSOdjEKcHRQuvYpwkUPITznsAaobrV.callRequestCookies('Get',lSOdjEKcHRQuvYpwkUPITznsAaobrX,payload=lSOdjEKcHRQuvYpwkUPITznsAaobCM,params=lSOdjEKcHRQuvYpwkUPITznsAaobrx,headers=lSOdjEKcHRQuvYpwkUPITznsAaobCM,cookies=lSOdjEKcHRQuvYpwkUPITznsAaobCM)
   lSOdjEKcHRQuvYpwkUPITznsAaobrg=json.loads(lSOdjEKcHRQuvYpwkUPITznsAaobrm.text)
   if not('celllist' in lSOdjEKcHRQuvYpwkUPITznsAaobrg['cell_toplist']):return lSOdjEKcHRQuvYpwkUPITznsAaobVe,lSOdjEKcHRQuvYpwkUPITznsAaobiX
   lSOdjEKcHRQuvYpwkUPITznsAaobit=lSOdjEKcHRQuvYpwkUPITznsAaobrg['cell_toplist']['celllist']
   for lSOdjEKcHRQuvYpwkUPITznsAaobiJ in lSOdjEKcHRQuvYpwkUPITznsAaobit:
    lSOdjEKcHRQuvYpwkUPITznsAaobih =lSOdjEKcHRQuvYpwkUPITznsAaobiJ['event_list'][1]['url']
    lSOdjEKcHRQuvYpwkUPITznsAaobim=urllib.parse.urlsplit(lSOdjEKcHRQuvYpwkUPITznsAaobih).query
    lSOdjEKcHRQuvYpwkUPITznsAaobig=lSOdjEKcHRQuvYpwkUPITznsAaobim[0:lSOdjEKcHRQuvYpwkUPITznsAaobim.find('=')]
    lSOdjEKcHRQuvYpwkUPITznsAaobiq=lSOdjEKcHRQuvYpwkUPITznsAaobim[lSOdjEKcHRQuvYpwkUPITznsAaobim.find('=')+1:]
    lSOdjEKcHRQuvYpwkUPITznsAaobiM={'title':lSOdjEKcHRQuvYpwkUPITznsAaobiJ['title_list'][0]['text'],'age':lSOdjEKcHRQuvYpwkUPITznsAaobiJ['age'],'thumbnail':'https://%s'%lSOdjEKcHRQuvYpwkUPITznsAaobiJ.get('thumbnail'),'videoid':lSOdjEKcHRQuvYpwkUPITznsAaobiq,'vidtype':lSOdjEKcHRQuvYpwkUPITznsAaobig}
    lSOdjEKcHRQuvYpwkUPITznsAaobVe.append(lSOdjEKcHRQuvYpwkUPITznsAaobiM)
   lSOdjEKcHRQuvYpwkUPITznsAaobiG=lSOdjEKcHRQuvYpwkUPITznsAaobCX(lSOdjEKcHRQuvYpwkUPITznsAaobrg['cell_toplist']['pagecount'])
   if lSOdjEKcHRQuvYpwkUPITznsAaobrg['cell_toplist']['count']:lSOdjEKcHRQuvYpwkUPITznsAaobiD =lSOdjEKcHRQuvYpwkUPITznsAaobCX(lSOdjEKcHRQuvYpwkUPITznsAaobrg['cell_toplist']['count'])
   else:lSOdjEKcHRQuvYpwkUPITznsAaobiD=lSOdjEKcHRQuvYpwkUPITznsAaobrV.MV_LIMIT*page_int
   lSOdjEKcHRQuvYpwkUPITznsAaobiX=lSOdjEKcHRQuvYpwkUPITznsAaobiG>lSOdjEKcHRQuvYpwkUPITznsAaobiD
  except lSOdjEKcHRQuvYpwkUPITznsAaobCy as exception:
   lSOdjEKcHRQuvYpwkUPITznsAaobCN(exception)
   return[],lSOdjEKcHRQuvYpwkUPITznsAaobCf
  return lSOdjEKcHRQuvYpwkUPITznsAaobVe,lSOdjEKcHRQuvYpwkUPITznsAaobiX
 def ChangeToProgramid(lSOdjEKcHRQuvYpwkUPITznsAaobrV,lSOdjEKcHRQuvYpwkUPITznsAaobVX):
  lSOdjEKcHRQuvYpwkUPITznsAaobVW=''
  try:
   lSOdjEKcHRQuvYpwkUPITznsAaobrX =lSOdjEKcHRQuvYpwkUPITznsAaobrV.API_DOMAIN+'/cf/vod/contents/'+lSOdjEKcHRQuvYpwkUPITznsAaobVX
   lSOdjEKcHRQuvYpwkUPITznsAaobrx=lSOdjEKcHRQuvYpwkUPITznsAaobrV.GetDefaultParams(login=lSOdjEKcHRQuvYpwkUPITznsAaobCf)
   lSOdjEKcHRQuvYpwkUPITznsAaobrm=lSOdjEKcHRQuvYpwkUPITznsAaobrV.callRequestCookies('Get',lSOdjEKcHRQuvYpwkUPITznsAaobrX,payload=lSOdjEKcHRQuvYpwkUPITznsAaobCM,params=lSOdjEKcHRQuvYpwkUPITznsAaobrx,headers=lSOdjEKcHRQuvYpwkUPITznsAaobCM,cookies=lSOdjEKcHRQuvYpwkUPITznsAaobCM)
   lSOdjEKcHRQuvYpwkUPITznsAaobVx=json.loads(lSOdjEKcHRQuvYpwkUPITznsAaobrm.text)
   if not('programid' in lSOdjEKcHRQuvYpwkUPITznsAaobVx):return lSOdjEKcHRQuvYpwkUPITznsAaobVW 
   lSOdjEKcHRQuvYpwkUPITznsAaobVW=lSOdjEKcHRQuvYpwkUPITznsAaobVx['programid']
  except lSOdjEKcHRQuvYpwkUPITznsAaobCy as exception:
   lSOdjEKcHRQuvYpwkUPITznsAaobCN(exception)
  return lSOdjEKcHRQuvYpwkUPITznsAaobVW
 def Get_Episode_List(lSOdjEKcHRQuvYpwkUPITznsAaobrV,lSOdjEKcHRQuvYpwkUPITznsAaobiq,lSOdjEKcHRQuvYpwkUPITznsAaobig,page_int=1,orderby='desc'):
  lSOdjEKcHRQuvYpwkUPITznsAaobVt=[]
  lSOdjEKcHRQuvYpwkUPITznsAaobiG=lSOdjEKcHRQuvYpwkUPITznsAaobiD=1
  lSOdjEKcHRQuvYpwkUPITznsAaobiX=lSOdjEKcHRQuvYpwkUPITznsAaobCf
  if lSOdjEKcHRQuvYpwkUPITznsAaobig=='contentid':
   lSOdjEKcHRQuvYpwkUPITznsAaobVW=lSOdjEKcHRQuvYpwkUPITznsAaobrV.ChangeToProgramid(lSOdjEKcHRQuvYpwkUPITznsAaobiq)
  else:
   lSOdjEKcHRQuvYpwkUPITznsAaobVW=lSOdjEKcHRQuvYpwkUPITznsAaobiq
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   lSOdjEKcHRQuvYpwkUPITznsAaobrX=lSOdjEKcHRQuvYpwkUPITznsAaobrV.API_DOMAIN+'/vod/programs-contents/'+lSOdjEKcHRQuvYpwkUPITznsAaobVW
   lSOdjEKcHRQuvYpwkUPITznsAaobrx={}
   lSOdjEKcHRQuvYpwkUPITznsAaobrx['limit'] =lSOdjEKcHRQuvYpwkUPITznsAaobrV.EP_LIMIT
   lSOdjEKcHRQuvYpwkUPITznsAaobrx['offset']=lSOdjEKcHRQuvYpwkUPITznsAaobCF((page_int-1)*lSOdjEKcHRQuvYpwkUPITznsAaobrV.EP_LIMIT)
   lSOdjEKcHRQuvYpwkUPITznsAaobrx['orderby']=orderby 
   lSOdjEKcHRQuvYpwkUPITznsAaobrx.update(lSOdjEKcHRQuvYpwkUPITznsAaobrV.GetDefaultParams(login=lSOdjEKcHRQuvYpwkUPITznsAaobCf))
   lSOdjEKcHRQuvYpwkUPITznsAaobrm=lSOdjEKcHRQuvYpwkUPITznsAaobrV.callRequestCookies('Get',lSOdjEKcHRQuvYpwkUPITznsAaobrX,payload=lSOdjEKcHRQuvYpwkUPITznsAaobCM,params=lSOdjEKcHRQuvYpwkUPITznsAaobrx,headers=lSOdjEKcHRQuvYpwkUPITznsAaobCM,cookies=lSOdjEKcHRQuvYpwkUPITznsAaobCM)
   lSOdjEKcHRQuvYpwkUPITznsAaobrg=json.loads(lSOdjEKcHRQuvYpwkUPITznsAaobrm.text)
   lSOdjEKcHRQuvYpwkUPITznsAaobit=lSOdjEKcHRQuvYpwkUPITznsAaobrg['list']
   for lSOdjEKcHRQuvYpwkUPITznsAaobiJ in lSOdjEKcHRQuvYpwkUPITznsAaobit:
    lSOdjEKcHRQuvYpwkUPITznsAaobVM=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',lSOdjEKcHRQuvYpwkUPITznsAaobiJ.get('synopsis'))
    lSOdjEKcHRQuvYpwkUPITznsAaobiM={'programtitle':lSOdjEKcHRQuvYpwkUPITznsAaobiJ.get('programtitle'),'episodetitle':lSOdjEKcHRQuvYpwkUPITznsAaobiJ.get('episodetitle'),'episodenumber':lSOdjEKcHRQuvYpwkUPITznsAaobiJ.get('episodenumber'),'releasedate':lSOdjEKcHRQuvYpwkUPITznsAaobiJ.get('releasedate'),'releaseweekday':lSOdjEKcHRQuvYpwkUPITznsAaobiJ.get('releaseweekday'),'programid':lSOdjEKcHRQuvYpwkUPITznsAaobiJ.get('programid'),'contentid':lSOdjEKcHRQuvYpwkUPITznsAaobiJ.get('contentid'),'age':lSOdjEKcHRQuvYpwkUPITznsAaobiJ.get('targetage'),'playtime':lSOdjEKcHRQuvYpwkUPITznsAaobiJ.get('playtime'),'synopsis':lSOdjEKcHRQuvYpwkUPITznsAaobVM,'episodeactors':lSOdjEKcHRQuvYpwkUPITznsAaobiJ.get('episodeactors').split(','),'thumbnail':lSOdjEKcHRQuvYpwkUPITznsAaobrV.HTTPTAG+lSOdjEKcHRQuvYpwkUPITznsAaobiJ.get('image')}
    lSOdjEKcHRQuvYpwkUPITznsAaobVt.append(lSOdjEKcHRQuvYpwkUPITznsAaobiM)
   lSOdjEKcHRQuvYpwkUPITznsAaobiG=lSOdjEKcHRQuvYpwkUPITznsAaobCX(lSOdjEKcHRQuvYpwkUPITznsAaobrg['pagecount'])
   if lSOdjEKcHRQuvYpwkUPITznsAaobrg['count']:lSOdjEKcHRQuvYpwkUPITznsAaobiD =lSOdjEKcHRQuvYpwkUPITznsAaobCX(lSOdjEKcHRQuvYpwkUPITznsAaobrg['count'])
   else:lSOdjEKcHRQuvYpwkUPITznsAaobiD=lSOdjEKcHRQuvYpwkUPITznsAaobrV.EP_LIMIT*page_int
   lSOdjEKcHRQuvYpwkUPITznsAaobiX=lSOdjEKcHRQuvYpwkUPITznsAaobiG>lSOdjEKcHRQuvYpwkUPITznsAaobiD
  except lSOdjEKcHRQuvYpwkUPITznsAaobCy as exception:
   lSOdjEKcHRQuvYpwkUPITznsAaobCN(exception)
   return[],lSOdjEKcHRQuvYpwkUPITznsAaobCf
  return lSOdjEKcHRQuvYpwkUPITznsAaobVt,lSOdjEKcHRQuvYpwkUPITznsAaobiX
 def GetEPGList(lSOdjEKcHRQuvYpwkUPITznsAaobrV,genre):
  lSOdjEKcHRQuvYpwkUPITznsAaobVf={}
  try:
   lSOdjEKcHRQuvYpwkUPITznsAaobVL=lSOdjEKcHRQuvYpwkUPITznsAaobrV.Get_Now_Datetime()
   if genre=='all':
    lSOdjEKcHRQuvYpwkUPITznsAaobVB =lSOdjEKcHRQuvYpwkUPITznsAaobVL+datetime.timedelta(hours=3)
   else:
    lSOdjEKcHRQuvYpwkUPITznsAaobVB =lSOdjEKcHRQuvYpwkUPITznsAaobVL+datetime.timedelta(hours=3)
   lSOdjEKcHRQuvYpwkUPITznsAaobrX=lSOdjEKcHRQuvYpwkUPITznsAaobrV.API_DOMAIN+'/live/epgs'
   lSOdjEKcHRQuvYpwkUPITznsAaobrx={'limit':'100','offset':'0','genre':genre,'startdatetime':lSOdjEKcHRQuvYpwkUPITznsAaobVL.strftime('%Y-%m-%d %H:00'),'enddatetime':lSOdjEKcHRQuvYpwkUPITznsAaobVB.strftime('%Y-%m-%d %H:00')}
   lSOdjEKcHRQuvYpwkUPITznsAaobrx.update(lSOdjEKcHRQuvYpwkUPITznsAaobrV.GetDefaultParams(login=lSOdjEKcHRQuvYpwkUPITznsAaobCf))
   lSOdjEKcHRQuvYpwkUPITznsAaobrm=lSOdjEKcHRQuvYpwkUPITznsAaobrV.callRequestCookies('Get',lSOdjEKcHRQuvYpwkUPITznsAaobrX,payload=lSOdjEKcHRQuvYpwkUPITznsAaobCM,params=lSOdjEKcHRQuvYpwkUPITznsAaobrx,headers=lSOdjEKcHRQuvYpwkUPITznsAaobCM,cookies=lSOdjEKcHRQuvYpwkUPITznsAaobCM)
   lSOdjEKcHRQuvYpwkUPITznsAaobrg=json.loads(lSOdjEKcHRQuvYpwkUPITznsAaobrm.text)
   lSOdjEKcHRQuvYpwkUPITznsAaobVF=lSOdjEKcHRQuvYpwkUPITznsAaobrg['list']
   for lSOdjEKcHRQuvYpwkUPITznsAaobiJ in lSOdjEKcHRQuvYpwkUPITznsAaobVF:
    lSOdjEKcHRQuvYpwkUPITznsAaobVy=''
    for lSOdjEKcHRQuvYpwkUPITznsAaobVN in lSOdjEKcHRQuvYpwkUPITznsAaobiJ['list']:
     if lSOdjEKcHRQuvYpwkUPITznsAaobVy:lSOdjEKcHRQuvYpwkUPITznsAaobVy+='\n'
     lSOdjEKcHRQuvYpwkUPITznsAaobVy+=lSOdjEKcHRQuvYpwkUPITznsAaobrV.Get_ChangeText(lSOdjEKcHRQuvYpwkUPITznsAaobVN['title'])+'\n'
     lSOdjEKcHRQuvYpwkUPITznsAaobVy+=' [%s ~ %s]'%(lSOdjEKcHRQuvYpwkUPITznsAaobVN['starttime'][-5:],lSOdjEKcHRQuvYpwkUPITznsAaobVN['endtime'][-5:])+'\n'
    lSOdjEKcHRQuvYpwkUPITznsAaobVf[lSOdjEKcHRQuvYpwkUPITznsAaobiJ['channelid']]=lSOdjEKcHRQuvYpwkUPITznsAaobVy
  except lSOdjEKcHRQuvYpwkUPITznsAaobCy as exception:
   lSOdjEKcHRQuvYpwkUPITznsAaobCN(exception)
  return lSOdjEKcHRQuvYpwkUPITznsAaobVf
 def Get_LiveChannel_List(lSOdjEKcHRQuvYpwkUPITznsAaobrV,genre,lSOdjEKcHRQuvYpwkUPITznsAaobiW):
  lSOdjEKcHRQuvYpwkUPITznsAaobiN=[]
  (lSOdjEKcHRQuvYpwkUPITznsAaobrX,lSOdjEKcHRQuvYpwkUPITznsAaobrx)=lSOdjEKcHRQuvYpwkUPITznsAaobrV.Baseapi_Parse(lSOdjEKcHRQuvYpwkUPITznsAaobiW)
  if lSOdjEKcHRQuvYpwkUPITznsAaobrX=='':return lSOdjEKcHRQuvYpwkUPITznsAaobiN
  lSOdjEKcHRQuvYpwkUPITznsAaobVG=lSOdjEKcHRQuvYpwkUPITznsAaobrV.GetEPGList(genre)
  try:
   lSOdjEKcHRQuvYpwkUPITznsAaobrx.update(lSOdjEKcHRQuvYpwkUPITznsAaobrV.GetDefaultParams(login=lSOdjEKcHRQuvYpwkUPITznsAaobCf))
   lSOdjEKcHRQuvYpwkUPITznsAaobrx['genre']=genre
   lSOdjEKcHRQuvYpwkUPITznsAaobrm=lSOdjEKcHRQuvYpwkUPITznsAaobrV.callRequestCookies('Get',lSOdjEKcHRQuvYpwkUPITznsAaobrX,payload=lSOdjEKcHRQuvYpwkUPITznsAaobCM,params=lSOdjEKcHRQuvYpwkUPITznsAaobrx,headers=lSOdjEKcHRQuvYpwkUPITznsAaobCM,cookies=lSOdjEKcHRQuvYpwkUPITznsAaobCM)
   lSOdjEKcHRQuvYpwkUPITznsAaobrg=json.loads(lSOdjEKcHRQuvYpwkUPITznsAaobrm.text)
   if not('celllist' in lSOdjEKcHRQuvYpwkUPITznsAaobrg['cell_toplist']):return[]
   lSOdjEKcHRQuvYpwkUPITznsAaobit=lSOdjEKcHRQuvYpwkUPITznsAaobrg['cell_toplist']['celllist']
   for lSOdjEKcHRQuvYpwkUPITznsAaobiJ in lSOdjEKcHRQuvYpwkUPITznsAaobit:
    lSOdjEKcHRQuvYpwkUPITznsAaobVX=lSOdjEKcHRQuvYpwkUPITznsAaobiJ['contentid']
    if lSOdjEKcHRQuvYpwkUPITznsAaobVX in lSOdjEKcHRQuvYpwkUPITznsAaobVG:
     lSOdjEKcHRQuvYpwkUPITznsAaobVh=lSOdjEKcHRQuvYpwkUPITznsAaobVG[lSOdjEKcHRQuvYpwkUPITznsAaobVX]
    else:
     lSOdjEKcHRQuvYpwkUPITznsAaobVh=''
    lSOdjEKcHRQuvYpwkUPITznsAaobiM={'studio':lSOdjEKcHRQuvYpwkUPITznsAaobiJ['title_list'][0]['text'],'tvshowtitle':lSOdjEKcHRQuvYpwkUPITznsAaobrV.Get_ChangeText(lSOdjEKcHRQuvYpwkUPITznsAaobiJ['title_list'][1]['text']),'channelid':lSOdjEKcHRQuvYpwkUPITznsAaobVX,'age':lSOdjEKcHRQuvYpwkUPITznsAaobiJ['age'],'thumbnail':'https://%s'%lSOdjEKcHRQuvYpwkUPITznsAaobiJ.get('thumbnail'),'epg':lSOdjEKcHRQuvYpwkUPITznsAaobVh}
    lSOdjEKcHRQuvYpwkUPITznsAaobiN.append(lSOdjEKcHRQuvYpwkUPITznsAaobiM)
  except lSOdjEKcHRQuvYpwkUPITznsAaobCy as exception:
   lSOdjEKcHRQuvYpwkUPITznsAaobCN(exception)
   return[]
  return lSOdjEKcHRQuvYpwkUPITznsAaobiN
 def Get_Search_List(lSOdjEKcHRQuvYpwkUPITznsAaobrV,search_key,sType,page_int,exclusion21=lSOdjEKcHRQuvYpwkUPITznsAaobCf):
  lSOdjEKcHRQuvYpwkUPITznsAaobVm=[]
  lSOdjEKcHRQuvYpwkUPITznsAaobiG=lSOdjEKcHRQuvYpwkUPITznsAaobiD=1
  lSOdjEKcHRQuvYpwkUPITznsAaobiX=lSOdjEKcHRQuvYpwkUPITznsAaobCf
  try:
   lSOdjEKcHRQuvYpwkUPITznsAaobrX=lSOdjEKcHRQuvYpwkUPITznsAaobrV.API_DOMAIN+'/cf/search/list.js'
   lSOdjEKcHRQuvYpwkUPITznsAaobrx={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':lSOdjEKcHRQuvYpwkUPITznsAaobCF((page_int-1)*lSOdjEKcHRQuvYpwkUPITznsAaobrV.LIST_LIMIT),'limit':lSOdjEKcHRQuvYpwkUPITznsAaobrV.LIST_LIMIT,'orderby':'score'}
   lSOdjEKcHRQuvYpwkUPITznsAaobrx.update(lSOdjEKcHRQuvYpwkUPITznsAaobrV.GetDefaultParams(login=lSOdjEKcHRQuvYpwkUPITznsAaobCf))
   lSOdjEKcHRQuvYpwkUPITznsAaobrm=lSOdjEKcHRQuvYpwkUPITznsAaobrV.callRequestCookies('Get',lSOdjEKcHRQuvYpwkUPITznsAaobrX,payload=lSOdjEKcHRQuvYpwkUPITznsAaobCM,params=lSOdjEKcHRQuvYpwkUPITznsAaobrx,headers=lSOdjEKcHRQuvYpwkUPITznsAaobCM,cookies=lSOdjEKcHRQuvYpwkUPITznsAaobCM)
   lSOdjEKcHRQuvYpwkUPITznsAaobVx=json.loads(lSOdjEKcHRQuvYpwkUPITznsAaobrm.text)
   if not('celllist' in lSOdjEKcHRQuvYpwkUPITznsAaobVx['cell_toplist']):return lSOdjEKcHRQuvYpwkUPITznsAaobVm,lSOdjEKcHRQuvYpwkUPITznsAaobiX
   lSOdjEKcHRQuvYpwkUPITznsAaobit=lSOdjEKcHRQuvYpwkUPITznsAaobVx['cell_toplist']['celllist']
   for lSOdjEKcHRQuvYpwkUPITznsAaobiJ in lSOdjEKcHRQuvYpwkUPITznsAaobit:
    lSOdjEKcHRQuvYpwkUPITznsAaobih =lSOdjEKcHRQuvYpwkUPITznsAaobiJ['event_list'][1]['url']
    lSOdjEKcHRQuvYpwkUPITznsAaobim=urllib.parse.urlsplit(lSOdjEKcHRQuvYpwkUPITznsAaobih).query
    lSOdjEKcHRQuvYpwkUPITznsAaobig=lSOdjEKcHRQuvYpwkUPITznsAaobim[0:lSOdjEKcHRQuvYpwkUPITznsAaobim.find('=')]
    lSOdjEKcHRQuvYpwkUPITznsAaobiq=lSOdjEKcHRQuvYpwkUPITznsAaobim[lSOdjEKcHRQuvYpwkUPITznsAaobim.find('=')+1:]
    lSOdjEKcHRQuvYpwkUPITznsAaobiM={'title':lSOdjEKcHRQuvYpwkUPITznsAaobiJ['title_list'][0]['text'],'age':lSOdjEKcHRQuvYpwkUPITznsAaobiJ['age'],'thumbnail':'https://%s'%lSOdjEKcHRQuvYpwkUPITznsAaobiJ.get('thumbnail'),'videoid':lSOdjEKcHRQuvYpwkUPITznsAaobiq,'vidtype':lSOdjEKcHRQuvYpwkUPITznsAaobig}
    if exclusion21==lSOdjEKcHRQuvYpwkUPITznsAaobCf or lSOdjEKcHRQuvYpwkUPITznsAaobiJ.get('age')!='21':
     lSOdjEKcHRQuvYpwkUPITznsAaobVm.append(lSOdjEKcHRQuvYpwkUPITznsAaobiM)
   lSOdjEKcHRQuvYpwkUPITznsAaobiG=lSOdjEKcHRQuvYpwkUPITznsAaobCX(lSOdjEKcHRQuvYpwkUPITznsAaobVx['cell_toplist']['pagecount'])
   if lSOdjEKcHRQuvYpwkUPITznsAaobVx['cell_toplist']['count']:lSOdjEKcHRQuvYpwkUPITznsAaobiD =lSOdjEKcHRQuvYpwkUPITznsAaobCX(lSOdjEKcHRQuvYpwkUPITznsAaobVx['cell_toplist']['count'])
   else:lSOdjEKcHRQuvYpwkUPITznsAaobiD=lSOdjEKcHRQuvYpwkUPITznsAaobrV.LIST_LIMIT
   lSOdjEKcHRQuvYpwkUPITznsAaobiX=lSOdjEKcHRQuvYpwkUPITznsAaobiG>lSOdjEKcHRQuvYpwkUPITznsAaobiD
  except lSOdjEKcHRQuvYpwkUPITznsAaobCy as exception:
   lSOdjEKcHRQuvYpwkUPITznsAaobCN(exception)
  return lSOdjEKcHRQuvYpwkUPITznsAaobVm,lSOdjEKcHRQuvYpwkUPITznsAaobiX 
 def GetStreamingURL(lSOdjEKcHRQuvYpwkUPITznsAaobrV,mode,lSOdjEKcHRQuvYpwkUPITznsAaobVX,quality_int,pvrmode='-'):
  lSOdjEKcHRQuvYpwkUPITznsAaobVg=lSOdjEKcHRQuvYpwkUPITznsAaobCx=lSOdjEKcHRQuvYpwkUPITznsAaobCt=streaming_preview=''
  lSOdjEKcHRQuvYpwkUPITznsAaobVq=[]
  lSOdjEKcHRQuvYpwkUPITznsAaobVD='hls'
  if mode=='LIVE':
   lSOdjEKcHRQuvYpwkUPITznsAaobrX =lSOdjEKcHRQuvYpwkUPITznsAaobrV.API_DOMAIN+'/live/channels/'+lSOdjEKcHRQuvYpwkUPITznsAaobVX
   lSOdjEKcHRQuvYpwkUPITznsAaobCr='live'
  elif mode=='VOD':
   lSOdjEKcHRQuvYpwkUPITznsAaobrX =lSOdjEKcHRQuvYpwkUPITznsAaobrV.API_DOMAIN+'/cf/vod/contents/'+lSOdjEKcHRQuvYpwkUPITznsAaobVX
   lSOdjEKcHRQuvYpwkUPITznsAaobCr='vod'
  elif mode=='MOVIE':
   lSOdjEKcHRQuvYpwkUPITznsAaobrX =lSOdjEKcHRQuvYpwkUPITznsAaobrV.API_DOMAIN+'/cf/movie/contents/'+lSOdjEKcHRQuvYpwkUPITznsAaobVX
   lSOdjEKcHRQuvYpwkUPITznsAaobCr='movie'
  try:
   if mode!='LIVE' or pvrmode=='-':
    lSOdjEKcHRQuvYpwkUPITznsAaobrx=lSOdjEKcHRQuvYpwkUPITznsAaobrV.GetDefaultParams(login=lSOdjEKcHRQuvYpwkUPITznsAaobCf)
    lSOdjEKcHRQuvYpwkUPITznsAaobrm=lSOdjEKcHRQuvYpwkUPITznsAaobrV.callRequestCookies('Get',lSOdjEKcHRQuvYpwkUPITznsAaobrX,payload=lSOdjEKcHRQuvYpwkUPITznsAaobCM,params=lSOdjEKcHRQuvYpwkUPITznsAaobrx,headers=lSOdjEKcHRQuvYpwkUPITznsAaobCM,cookies=lSOdjEKcHRQuvYpwkUPITznsAaobCM)
    lSOdjEKcHRQuvYpwkUPITznsAaobrg=json.loads(lSOdjEKcHRQuvYpwkUPITznsAaobrm.text)
    lSOdjEKcHRQuvYpwkUPITznsAaobCi=lSOdjEKcHRQuvYpwkUPITznsAaobrg['qualities']['list']
    if lSOdjEKcHRQuvYpwkUPITznsAaobCi==lSOdjEKcHRQuvYpwkUPITznsAaobCM:return(lSOdjEKcHRQuvYpwkUPITznsAaobVg,lSOdjEKcHRQuvYpwkUPITznsAaobCx,lSOdjEKcHRQuvYpwkUPITznsAaobCt,streaming_preview)
    for lSOdjEKcHRQuvYpwkUPITznsAaobCV in lSOdjEKcHRQuvYpwkUPITznsAaobCi:
     lSOdjEKcHRQuvYpwkUPITznsAaobVq.append(lSOdjEKcHRQuvYpwkUPITznsAaobCX(lSOdjEKcHRQuvYpwkUPITznsAaobCV.get('id').rstrip('p')))
    if 'type' in lSOdjEKcHRQuvYpwkUPITznsAaobrg:
     if lSOdjEKcHRQuvYpwkUPITznsAaobrg['type']=='onair':
      lSOdjEKcHRQuvYpwkUPITznsAaobCr='onairvod'
    if 'drms' in lSOdjEKcHRQuvYpwkUPITznsAaobrg:
     if lSOdjEKcHRQuvYpwkUPITznsAaobrg['drms']:
      lSOdjEKcHRQuvYpwkUPITznsAaobVD='dash'
  except lSOdjEKcHRQuvYpwkUPITznsAaobCy as exception:
   lSOdjEKcHRQuvYpwkUPITznsAaobCN(exception)
   return(lSOdjEKcHRQuvYpwkUPITznsAaobVg,lSOdjEKcHRQuvYpwkUPITznsAaobCx,lSOdjEKcHRQuvYpwkUPITznsAaobCt,streaming_preview)
  try:
   lSOdjEKcHRQuvYpwkUPITznsAaobCe=lSOdjEKcHRQuvYpwkUPITznsAaobrV.CheckQuality(quality_int,lSOdjEKcHRQuvYpwkUPITznsAaobVq)
   if mode=='LIVE' and pvrmode!='-':
    lSOdjEKcHRQuvYpwkUPITznsAaobCW='auto'
   else:
    lSOdjEKcHRQuvYpwkUPITznsAaobCW=lSOdjEKcHRQuvYpwkUPITznsAaobCF(lSOdjEKcHRQuvYpwkUPITznsAaobCe)+'p'
   lSOdjEKcHRQuvYpwkUPITznsAaobrX=lSOdjEKcHRQuvYpwkUPITznsAaobrV.API_DOMAIN+'/streaming'
   lSOdjEKcHRQuvYpwkUPITznsAaobrx={'contentid':lSOdjEKcHRQuvYpwkUPITznsAaobVX,'contenttype':lSOdjEKcHRQuvYpwkUPITznsAaobCr,'action':lSOdjEKcHRQuvYpwkUPITznsAaobVD,'quality':lSOdjEKcHRQuvYpwkUPITznsAaobCW,'deviceModelId':'Windows 10','guid':lSOdjEKcHRQuvYpwkUPITznsAaobrV.GetGUID(guidType=2),'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n'}
   lSOdjEKcHRQuvYpwkUPITznsAaobrx.update(lSOdjEKcHRQuvYpwkUPITznsAaobrV.GetDefaultParams(login=lSOdjEKcHRQuvYpwkUPITznsAaobCL))
   lSOdjEKcHRQuvYpwkUPITznsAaobrm=lSOdjEKcHRQuvYpwkUPITznsAaobrV.callRequestCookies('Get',lSOdjEKcHRQuvYpwkUPITznsAaobrX,payload=lSOdjEKcHRQuvYpwkUPITznsAaobCM,params=lSOdjEKcHRQuvYpwkUPITznsAaobrx,headers=lSOdjEKcHRQuvYpwkUPITznsAaobCM,cookies=lSOdjEKcHRQuvYpwkUPITznsAaobCM)
   lSOdjEKcHRQuvYpwkUPITznsAaobrg=json.loads(lSOdjEKcHRQuvYpwkUPITznsAaobrm.text)
   lSOdjEKcHRQuvYpwkUPITznsAaobVg=lSOdjEKcHRQuvYpwkUPITznsAaobrg['playurl']
   if lSOdjEKcHRQuvYpwkUPITznsAaobVg==lSOdjEKcHRQuvYpwkUPITznsAaobCM:return(lSOdjEKcHRQuvYpwkUPITznsAaobVg,lSOdjEKcHRQuvYpwkUPITznsAaobCx,lSOdjEKcHRQuvYpwkUPITznsAaobCt,streaming_preview)
   lSOdjEKcHRQuvYpwkUPITznsAaobCx=lSOdjEKcHRQuvYpwkUPITznsAaobrg['awscookie']
   lSOdjEKcHRQuvYpwkUPITznsAaobCt =lSOdjEKcHRQuvYpwkUPITznsAaobrg['drm']
   if 'previewmsg' in lSOdjEKcHRQuvYpwkUPITznsAaobrg['preview']:streaming_preview=lSOdjEKcHRQuvYpwkUPITznsAaobrg['preview']['previewmsg']
  except lSOdjEKcHRQuvYpwkUPITznsAaobCy as exception:
   lSOdjEKcHRQuvYpwkUPITznsAaobCN(exception)
  return(lSOdjEKcHRQuvYpwkUPITznsAaobVg,lSOdjEKcHRQuvYpwkUPITznsAaobCx,lSOdjEKcHRQuvYpwkUPITznsAaobCt,streaming_preview) 
# Created by pyminifier (https://github.com/liftoff/pyminifier)
