__author__="NightRain"
WukBaKhGUzRIFJebYdxtVqsmATXvgS=object
WukBaKhGUzRIFJebYdxtVqsmATXvgN=None
WukBaKhGUzRIFJebYdxtVqsmATXvgi=False
WukBaKhGUzRIFJebYdxtVqsmATXvgw=True
WukBaKhGUzRIFJebYdxtVqsmATXvgf=range
WukBaKhGUzRIFJebYdxtVqsmATXvgy=str
WukBaKhGUzRIFJebYdxtVqsmATXvgl=Exception
WukBaKhGUzRIFJebYdxtVqsmATXvgE=print
WukBaKhGUzRIFJebYdxtVqsmATXvgQ=dict
WukBaKhGUzRIFJebYdxtVqsmATXvgr=int
WukBaKhGUzRIFJebYdxtVqsmATXvgM=len
import urllib
import http.cookiejar 
import re
import json
import sys
import requests
import datetime
WukBaKhGUzRIFJebYdxtVqsmATXvoH='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
class WukBaKhGUzRIFJebYdxtVqsmATXvoc(WukBaKhGUzRIFJebYdxtVqsmATXvgS):
 def __init__(WukBaKhGUzRIFJebYdxtVqsmATXvog):
  WukBaKhGUzRIFJebYdxtVqsmATXvog.API_DOMAIN='https://apis.wavve.com'
  WukBaKhGUzRIFJebYdxtVqsmATXvog.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  WukBaKhGUzRIFJebYdxtVqsmATXvog.CREDENTIAL='none'
  WukBaKhGUzRIFJebYdxtVqsmATXvog.DEVICE ='pc'
  WukBaKhGUzRIFJebYdxtVqsmATXvog.DRM ='wm'
  WukBaKhGUzRIFJebYdxtVqsmATXvog.PARTNER ='pooq'
  WukBaKhGUzRIFJebYdxtVqsmATXvog.POOQZONE ='none'
  WukBaKhGUzRIFJebYdxtVqsmATXvog.REGION ='kor'
  WukBaKhGUzRIFJebYdxtVqsmATXvog.TARGETAGE ='all'
  WukBaKhGUzRIFJebYdxtVqsmATXvog.HTTPTAG ='https://'
  WukBaKhGUzRIFJebYdxtVqsmATXvog.LIST_LIMIT=30 
  WukBaKhGUzRIFJebYdxtVqsmATXvog.EP_LIMIT =30 
  WukBaKhGUzRIFJebYdxtVqsmATXvog.MV_LIMIT =24 
  WukBaKhGUzRIFJebYdxtVqsmATXvog.guid ='none' 
  WukBaKhGUzRIFJebYdxtVqsmATXvog.guidtimestamp='none' 
  WukBaKhGUzRIFJebYdxtVqsmATXvog.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
  WukBaKhGUzRIFJebYdxtVqsmATXvog.DEFAULT_HEADER={'user-agent':WukBaKhGUzRIFJebYdxtVqsmATXvog.USER_AGENT}
 def callRequestCookies(WukBaKhGUzRIFJebYdxtVqsmATXvog,jobtype,WukBaKhGUzRIFJebYdxtVqsmATXvor,payload=WukBaKhGUzRIFJebYdxtVqsmATXvgN,params=WukBaKhGUzRIFJebYdxtVqsmATXvgN,headers=WukBaKhGUzRIFJebYdxtVqsmATXvgN,cookies=WukBaKhGUzRIFJebYdxtVqsmATXvgN,redirects=WukBaKhGUzRIFJebYdxtVqsmATXvgi):
  WukBaKhGUzRIFJebYdxtVqsmATXvoP=WukBaKhGUzRIFJebYdxtVqsmATXvog.DEFAULT_HEADER
  if headers:WukBaKhGUzRIFJebYdxtVqsmATXvoP.update(headers)
  if jobtype=='Get':
   WukBaKhGUzRIFJebYdxtVqsmATXvoj=requests.get(WukBaKhGUzRIFJebYdxtVqsmATXvor,params=params,headers=WukBaKhGUzRIFJebYdxtVqsmATXvoP,cookies=cookies,allow_redirects=redirects)
  else:
   WukBaKhGUzRIFJebYdxtVqsmATXvoj=requests.post(WukBaKhGUzRIFJebYdxtVqsmATXvor,data=payload,params=params,headers=WukBaKhGUzRIFJebYdxtVqsmATXvoP,cookies=cookies,allow_redirects=redirects)
  return WukBaKhGUzRIFJebYdxtVqsmATXvoj
 def SaveCredential(WukBaKhGUzRIFJebYdxtVqsmATXvog,WukBaKhGUzRIFJebYdxtVqsmATXvoL):
  WukBaKhGUzRIFJebYdxtVqsmATXvog.CREDENTIAL=WukBaKhGUzRIFJebYdxtVqsmATXvoL
 def LoadCredential(WukBaKhGUzRIFJebYdxtVqsmATXvog):
  return WukBaKhGUzRIFJebYdxtVqsmATXvog.CREDENTIAL
 def GetDefaultParams(WukBaKhGUzRIFJebYdxtVqsmATXvog,login=WukBaKhGUzRIFJebYdxtVqsmATXvgw):
  WukBaKhGUzRIFJebYdxtVqsmATXvoD={'apikey':WukBaKhGUzRIFJebYdxtVqsmATXvog.APIKEY,'credential':WukBaKhGUzRIFJebYdxtVqsmATXvog.CREDENTIAL if login else 'none','device':WukBaKhGUzRIFJebYdxtVqsmATXvog.DEVICE,'drm':WukBaKhGUzRIFJebYdxtVqsmATXvog.DRM,'partner':WukBaKhGUzRIFJebYdxtVqsmATXvog.PARTNER,'pooqzone':WukBaKhGUzRIFJebYdxtVqsmATXvog.POOQZONE,'region':WukBaKhGUzRIFJebYdxtVqsmATXvog.REGION,'targetage':WukBaKhGUzRIFJebYdxtVqsmATXvog.TARGETAGE}
  return WukBaKhGUzRIFJebYdxtVqsmATXvoD
 def GetGUID(WukBaKhGUzRIFJebYdxtVqsmATXvog,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   WukBaKhGUzRIFJebYdxtVqsmATXvoC=WukBaKhGUzRIFJebYdxtVqsmATXvog.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   WukBaKhGUzRIFJebYdxtVqsmATXvoS=GenerateRandomString(5)
   WukBaKhGUzRIFJebYdxtVqsmATXvoN=WukBaKhGUzRIFJebYdxtVqsmATXvoS+media+WukBaKhGUzRIFJebYdxtVqsmATXvoC
   return WukBaKhGUzRIFJebYdxtVqsmATXvoN
  def GenerateRandomString(num):
   from random import randint
   WukBaKhGUzRIFJebYdxtVqsmATXvoi=""
   for i in WukBaKhGUzRIFJebYdxtVqsmATXvgf(0,num):
    s=WukBaKhGUzRIFJebYdxtVqsmATXvgy(randint(1,5))
    WukBaKhGUzRIFJebYdxtVqsmATXvoi+=s
   return WukBaKhGUzRIFJebYdxtVqsmATXvoi
  WukBaKhGUzRIFJebYdxtVqsmATXvoN=GenerateID(guid_str)
  WukBaKhGUzRIFJebYdxtVqsmATXvow=WukBaKhGUzRIFJebYdxtVqsmATXvog.GetHash(WukBaKhGUzRIFJebYdxtVqsmATXvoN)
  if guidType==2:
   WukBaKhGUzRIFJebYdxtVqsmATXvow='%s-%s-%s-%s-%s'%(WukBaKhGUzRIFJebYdxtVqsmATXvow[:8],WukBaKhGUzRIFJebYdxtVqsmATXvow[8:12],WukBaKhGUzRIFJebYdxtVqsmATXvow[12:16],WukBaKhGUzRIFJebYdxtVqsmATXvow[16:20],WukBaKhGUzRIFJebYdxtVqsmATXvow[20:])
  return WukBaKhGUzRIFJebYdxtVqsmATXvow
 def GetHash(WukBaKhGUzRIFJebYdxtVqsmATXvog,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return WukBaKhGUzRIFJebYdxtVqsmATXvgy(m.hexdigest())
 def CheckQuality(WukBaKhGUzRIFJebYdxtVqsmATXvog,sel_qt,qt_list):
  WukBaKhGUzRIFJebYdxtVqsmATXvof=0
  for WukBaKhGUzRIFJebYdxtVqsmATXvoy in qt_list:
   if sel_qt>=WukBaKhGUzRIFJebYdxtVqsmATXvoy:return WukBaKhGUzRIFJebYdxtVqsmATXvoy
   WukBaKhGUzRIFJebYdxtVqsmATXvof=WukBaKhGUzRIFJebYdxtVqsmATXvoy
  return WukBaKhGUzRIFJebYdxtVqsmATXvof
 def Get_Now_Datetime(WukBaKhGUzRIFJebYdxtVqsmATXvog):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(WukBaKhGUzRIFJebYdxtVqsmATXvog,in_text):
  WukBaKhGUzRIFJebYdxtVqsmATXvoE=in_text.replace('&lt;','<').replace('&gt;','>')
  WukBaKhGUzRIFJebYdxtVqsmATXvoE=WukBaKhGUzRIFJebYdxtVqsmATXvoE.replace('$O$','')
  WukBaKhGUzRIFJebYdxtVqsmATXvoE=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',WukBaKhGUzRIFJebYdxtVqsmATXvoE)
  WukBaKhGUzRIFJebYdxtVqsmATXvoE=WukBaKhGUzRIFJebYdxtVqsmATXvoE.lstrip('#')
  return WukBaKhGUzRIFJebYdxtVqsmATXvoE
 def GetCredential(WukBaKhGUzRIFJebYdxtVqsmATXvog,user_id,user_pw,user_pf):
  WukBaKhGUzRIFJebYdxtVqsmATXvoQ=WukBaKhGUzRIFJebYdxtVqsmATXvgi
  try:
   WukBaKhGUzRIFJebYdxtVqsmATXvor=WukBaKhGUzRIFJebYdxtVqsmATXvog.API_DOMAIN+ '/login'
   WukBaKhGUzRIFJebYdxtVqsmATXvoD=WukBaKhGUzRIFJebYdxtVqsmATXvog.GetDefaultParams()
   WukBaKhGUzRIFJebYdxtVqsmATXvoM={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   WukBaKhGUzRIFJebYdxtVqsmATXvon=WukBaKhGUzRIFJebYdxtVqsmATXvog.callRequestCookies('Post',WukBaKhGUzRIFJebYdxtVqsmATXvor,payload=WukBaKhGUzRIFJebYdxtVqsmATXvoM,params=WukBaKhGUzRIFJebYdxtVqsmATXvoD,headers=WukBaKhGUzRIFJebYdxtVqsmATXvgN,cookies=WukBaKhGUzRIFJebYdxtVqsmATXvgN)
   WukBaKhGUzRIFJebYdxtVqsmATXvop=json.loads(WukBaKhGUzRIFJebYdxtVqsmATXvon.text)
   WukBaKhGUzRIFJebYdxtVqsmATXvoL=WukBaKhGUzRIFJebYdxtVqsmATXvop['credential']
   if user_pf!=0:
    WukBaKhGUzRIFJebYdxtVqsmATXvoM={'id':WukBaKhGUzRIFJebYdxtVqsmATXvoL,'password':'','profile':WukBaKhGUzRIFJebYdxtVqsmATXvgy(user_pf),'pushid':'','type':'credential'}
    WukBaKhGUzRIFJebYdxtVqsmATXvoD['credential']=WukBaKhGUzRIFJebYdxtVqsmATXvoL 
    WukBaKhGUzRIFJebYdxtVqsmATXvon=WukBaKhGUzRIFJebYdxtVqsmATXvog.callRequestCookies('Post',WukBaKhGUzRIFJebYdxtVqsmATXvor,payload=WukBaKhGUzRIFJebYdxtVqsmATXvoM,params=WukBaKhGUzRIFJebYdxtVqsmATXvoD,headers=WukBaKhGUzRIFJebYdxtVqsmATXvgN,cookies=WukBaKhGUzRIFJebYdxtVqsmATXvgN)
    WukBaKhGUzRIFJebYdxtVqsmATXvop=json.loads(WukBaKhGUzRIFJebYdxtVqsmATXvon.text)
    WukBaKhGUzRIFJebYdxtVqsmATXvoL=WukBaKhGUzRIFJebYdxtVqsmATXvop['credential']
   if WukBaKhGUzRIFJebYdxtVqsmATXvoL:WukBaKhGUzRIFJebYdxtVqsmATXvoQ=WukBaKhGUzRIFJebYdxtVqsmATXvgw
  except WukBaKhGUzRIFJebYdxtVqsmATXvgl as exception:
   WukBaKhGUzRIFJebYdxtVqsmATXvgE(exception)
   WukBaKhGUzRIFJebYdxtVqsmATXvoL='none' 
  WukBaKhGUzRIFJebYdxtVqsmATXvog.SaveCredential(WukBaKhGUzRIFJebYdxtVqsmATXvoL)
  return WukBaKhGUzRIFJebYdxtVqsmATXvoQ
 def GetIssue(WukBaKhGUzRIFJebYdxtVqsmATXvog):
  WukBaKhGUzRIFJebYdxtVqsmATXvoO=WukBaKhGUzRIFJebYdxtVqsmATXvgi
  try:
   WukBaKhGUzRIFJebYdxtVqsmATXvor=WukBaKhGUzRIFJebYdxtVqsmATXvog.API_DOMAIN+'/guid/issue'
   WukBaKhGUzRIFJebYdxtVqsmATXvoD=WukBaKhGUzRIFJebYdxtVqsmATXvog.GetDefaultParams()
   WukBaKhGUzRIFJebYdxtVqsmATXvon=WukBaKhGUzRIFJebYdxtVqsmATXvog.callRequestCookies('Get',WukBaKhGUzRIFJebYdxtVqsmATXvor,payload=WukBaKhGUzRIFJebYdxtVqsmATXvgN,params=WukBaKhGUzRIFJebYdxtVqsmATXvoD,headers=WukBaKhGUzRIFJebYdxtVqsmATXvgN,cookies=WukBaKhGUzRIFJebYdxtVqsmATXvgN)
   WukBaKhGUzRIFJebYdxtVqsmATXvop=json.loads(WukBaKhGUzRIFJebYdxtVqsmATXvon.text)
   WukBaKhGUzRIFJebYdxtVqsmATXvco=WukBaKhGUzRIFJebYdxtVqsmATXvop['guid']
   WukBaKhGUzRIFJebYdxtVqsmATXvcH=WukBaKhGUzRIFJebYdxtVqsmATXvop['guidtimestamp']
   if WukBaKhGUzRIFJebYdxtVqsmATXvco:WukBaKhGUzRIFJebYdxtVqsmATXvoO=WukBaKhGUzRIFJebYdxtVqsmATXvgw
  except WukBaKhGUzRIFJebYdxtVqsmATXvgl as exception:
   WukBaKhGUzRIFJebYdxtVqsmATXvgE(exception)
   WukBaKhGUzRIFJebYdxtVqsmATXvco='none'
   WukBaKhGUzRIFJebYdxtVqsmATXvcH='none' 
  WukBaKhGUzRIFJebYdxtVqsmATXvog.guid=WukBaKhGUzRIFJebYdxtVqsmATXvco
  WukBaKhGUzRIFJebYdxtVqsmATXvog.guidtimestamp=WukBaKhGUzRIFJebYdxtVqsmATXvcH
  return WukBaKhGUzRIFJebYdxtVqsmATXvoO
 def Baseapi_Parse(WukBaKhGUzRIFJebYdxtVqsmATXvog,WukBaKhGUzRIFJebYdxtVqsmATXvcL):
  try:
   WukBaKhGUzRIFJebYdxtVqsmATXvcg =urllib.parse.urlsplit(WukBaKhGUzRIFJebYdxtVqsmATXvcL)
   if WukBaKhGUzRIFJebYdxtVqsmATXvcg.netloc=='':
    WukBaKhGUzRIFJebYdxtVqsmATXvor=WukBaKhGUzRIFJebYdxtVqsmATXvog.HTTPTAG+WukBaKhGUzRIFJebYdxtVqsmATXvcg.netloc+WukBaKhGUzRIFJebYdxtVqsmATXvcg.path
   else:
    WukBaKhGUzRIFJebYdxtVqsmATXvor=WukBaKhGUzRIFJebYdxtVqsmATXvcg.scheme+'://'+WukBaKhGUzRIFJebYdxtVqsmATXvcg.netloc+WukBaKhGUzRIFJebYdxtVqsmATXvcg.path
   WukBaKhGUzRIFJebYdxtVqsmATXvoD=WukBaKhGUzRIFJebYdxtVqsmATXvgQ(urllib.parse.parse_qsl(WukBaKhGUzRIFJebYdxtVqsmATXvcg.query))
  except:
   WukBaKhGUzRIFJebYdxtVqsmATXvgE(exception)
   return '',{}
  return WukBaKhGUzRIFJebYdxtVqsmATXvor,WukBaKhGUzRIFJebYdxtVqsmATXvoD
 def GetSupermultiUrl(WukBaKhGUzRIFJebYdxtVqsmATXvog,sCode,sIndex='0'):
  try:
   WukBaKhGUzRIFJebYdxtVqsmATXvor=WukBaKhGUzRIFJebYdxtVqsmATXvog.API_DOMAIN+'/cf/supermultisections/'+sCode
   WukBaKhGUzRIFJebYdxtVqsmATXvoD=WukBaKhGUzRIFJebYdxtVqsmATXvog.GetDefaultParams(login=WukBaKhGUzRIFJebYdxtVqsmATXvgi)
   WukBaKhGUzRIFJebYdxtVqsmATXvon=WukBaKhGUzRIFJebYdxtVqsmATXvog.callRequestCookies('Get',WukBaKhGUzRIFJebYdxtVqsmATXvor,payload=WukBaKhGUzRIFJebYdxtVqsmATXvgN,params=WukBaKhGUzRIFJebYdxtVqsmATXvoD,headers=WukBaKhGUzRIFJebYdxtVqsmATXvgN,cookies=WukBaKhGUzRIFJebYdxtVqsmATXvgN)
   WukBaKhGUzRIFJebYdxtVqsmATXvop=json.loads(WukBaKhGUzRIFJebYdxtVqsmATXvon.text)
   WukBaKhGUzRIFJebYdxtVqsmATXvcP=WukBaKhGUzRIFJebYdxtVqsmATXvop['multisectionlist'][WukBaKhGUzRIFJebYdxtVqsmATXvgr(sIndex)]['eventlist'][1]['url']
  except WukBaKhGUzRIFJebYdxtVqsmATXvgl as exception:
   WukBaKhGUzRIFJebYdxtVqsmATXvgE(exception)
   return ''
  return WukBaKhGUzRIFJebYdxtVqsmATXvcP
 def Get_LiveCatagory_List(WukBaKhGUzRIFJebYdxtVqsmATXvog,sCode,sIndex='0'):
  WukBaKhGUzRIFJebYdxtVqsmATXvcj=[]
  WukBaKhGUzRIFJebYdxtVqsmATXvcL =WukBaKhGUzRIFJebYdxtVqsmATXvog.GetSupermultiUrl(sCode,sIndex)
  (WukBaKhGUzRIFJebYdxtVqsmATXvor,WukBaKhGUzRIFJebYdxtVqsmATXvoD)=WukBaKhGUzRIFJebYdxtVqsmATXvog.Baseapi_Parse(WukBaKhGUzRIFJebYdxtVqsmATXvcL)
  if WukBaKhGUzRIFJebYdxtVqsmATXvor=='':return WukBaKhGUzRIFJebYdxtVqsmATXvcj,''
  try:
   WukBaKhGUzRIFJebYdxtVqsmATXvoD.update(WukBaKhGUzRIFJebYdxtVqsmATXvog.GetDefaultParams(login=WukBaKhGUzRIFJebYdxtVqsmATXvgi))
   WukBaKhGUzRIFJebYdxtVqsmATXvon=WukBaKhGUzRIFJebYdxtVqsmATXvog.callRequestCookies('Get',WukBaKhGUzRIFJebYdxtVqsmATXvor,payload=WukBaKhGUzRIFJebYdxtVqsmATXvgN,params=WukBaKhGUzRIFJebYdxtVqsmATXvoD,headers=WukBaKhGUzRIFJebYdxtVqsmATXvgN,cookies=WukBaKhGUzRIFJebYdxtVqsmATXvgN)
   WukBaKhGUzRIFJebYdxtVqsmATXvop=json.loads(WukBaKhGUzRIFJebYdxtVqsmATXvon.text)
   if not('filter_item_list' in WukBaKhGUzRIFJebYdxtVqsmATXvop['filter']['filterlist'][0]):return[],''
   WukBaKhGUzRIFJebYdxtVqsmATXvcC=WukBaKhGUzRIFJebYdxtVqsmATXvop['filter']['filterlist'][0]['filter_item_list']
   for WukBaKhGUzRIFJebYdxtVqsmATXvcS in WukBaKhGUzRIFJebYdxtVqsmATXvcC:
    WukBaKhGUzRIFJebYdxtVqsmATXvcN={'title':WukBaKhGUzRIFJebYdxtVqsmATXvcS['title'],'genre':WukBaKhGUzRIFJebYdxtVqsmATXvcS['api_parameters'][WukBaKhGUzRIFJebYdxtVqsmATXvcS['api_parameters'].index('=')+1:]}
    WukBaKhGUzRIFJebYdxtVqsmATXvcj.append(WukBaKhGUzRIFJebYdxtVqsmATXvcN)
  except WukBaKhGUzRIFJebYdxtVqsmATXvgl as exception:
   WukBaKhGUzRIFJebYdxtVqsmATXvgE(exception)
   return[],''
  return WukBaKhGUzRIFJebYdxtVqsmATXvcj,WukBaKhGUzRIFJebYdxtVqsmATXvcL
 def Get_MainCatagory_List(WukBaKhGUzRIFJebYdxtVqsmATXvog,sCode,sIndex='0'):
  WukBaKhGUzRIFJebYdxtVqsmATXvcj=[]
  WukBaKhGUzRIFJebYdxtVqsmATXvcL =WukBaKhGUzRIFJebYdxtVqsmATXvog.GetSupermultiUrl(sCode,sIndex)
  (WukBaKhGUzRIFJebYdxtVqsmATXvor,WukBaKhGUzRIFJebYdxtVqsmATXvoD)=WukBaKhGUzRIFJebYdxtVqsmATXvog.Baseapi_Parse(WukBaKhGUzRIFJebYdxtVqsmATXvcL)
  if WukBaKhGUzRIFJebYdxtVqsmATXvor=='':return WukBaKhGUzRIFJebYdxtVqsmATXvcj
  try:
   WukBaKhGUzRIFJebYdxtVqsmATXvoD.update(WukBaKhGUzRIFJebYdxtVqsmATXvog.GetDefaultParams(login=WukBaKhGUzRIFJebYdxtVqsmATXvgi))
   WukBaKhGUzRIFJebYdxtVqsmATXvon=WukBaKhGUzRIFJebYdxtVqsmATXvog.callRequestCookies('Get',WukBaKhGUzRIFJebYdxtVqsmATXvor,payload=WukBaKhGUzRIFJebYdxtVqsmATXvgN,params=WukBaKhGUzRIFJebYdxtVqsmATXvoD,headers=WukBaKhGUzRIFJebYdxtVqsmATXvgN,cookies=WukBaKhGUzRIFJebYdxtVqsmATXvgN)
   WukBaKhGUzRIFJebYdxtVqsmATXvop=json.loads(WukBaKhGUzRIFJebYdxtVqsmATXvon.text)
   if not('celllist' in WukBaKhGUzRIFJebYdxtVqsmATXvop['band']):return[]
   WukBaKhGUzRIFJebYdxtVqsmATXvcC=WukBaKhGUzRIFJebYdxtVqsmATXvop['band']['celllist']
   for WukBaKhGUzRIFJebYdxtVqsmATXvcS in WukBaKhGUzRIFJebYdxtVqsmATXvcC:
    WukBaKhGUzRIFJebYdxtVqsmATXvci =WukBaKhGUzRIFJebYdxtVqsmATXvcS['event_list'][1]['url']
    (WukBaKhGUzRIFJebYdxtVqsmATXvcw,WukBaKhGUzRIFJebYdxtVqsmATXvcf)=WukBaKhGUzRIFJebYdxtVqsmATXvog.Baseapi_Parse(WukBaKhGUzRIFJebYdxtVqsmATXvci)
    WukBaKhGUzRIFJebYdxtVqsmATXvcN={'title':WukBaKhGUzRIFJebYdxtVqsmATXvcS['title_list'][0]['text'],'suburl':WukBaKhGUzRIFJebYdxtVqsmATXvcw,'subapi':WukBaKhGUzRIFJebYdxtVqsmATXvcf.get('api'),'subtype':'catagory' if WukBaKhGUzRIFJebYdxtVqsmATXvcf else 'supersection'}
    WukBaKhGUzRIFJebYdxtVqsmATXvcj.append(WukBaKhGUzRIFJebYdxtVqsmATXvcN)
  except WukBaKhGUzRIFJebYdxtVqsmATXvgl as exception:
   WukBaKhGUzRIFJebYdxtVqsmATXvgE(exception)
   return[]
  return WukBaKhGUzRIFJebYdxtVqsmATXvcj
 def Get_SuperMultiSection_List(WukBaKhGUzRIFJebYdxtVqsmATXvog,subapi_text):
  WukBaKhGUzRIFJebYdxtVqsmATXvcj=[]
  WukBaKhGUzRIFJebYdxtVqsmATXvoD={}
  try:
   WukBaKhGUzRIFJebYdxtVqsmATXvcg =urllib.parse.urlsplit(subapi_text)
   if WukBaKhGUzRIFJebYdxtVqsmATXvcg.path.find('apis.wavve.com')>=0: 
    WukBaKhGUzRIFJebYdxtVqsmATXvor=WukBaKhGUzRIFJebYdxtVqsmATXvog.HTTPTAG+WukBaKhGUzRIFJebYdxtVqsmATXvcg.path 
    WukBaKhGUzRIFJebYdxtVqsmATXvoD=WukBaKhGUzRIFJebYdxtVqsmATXvgQ(urllib.parse.parse_qsl(WukBaKhGUzRIFJebYdxtVqsmATXvcg.query))
   else:
    WukBaKhGUzRIFJebYdxtVqsmATXvor=WukBaKhGUzRIFJebYdxtVqsmATXvog.API_DOMAIN+'/cf'+WukBaKhGUzRIFJebYdxtVqsmATXvcg.path 
   WukBaKhGUzRIFJebYdxtVqsmATXvor=WukBaKhGUzRIFJebYdxtVqsmATXvor.replace('supermultisection/','supermultisections/')
  except WukBaKhGUzRIFJebYdxtVqsmATXvgl as exception:
   WukBaKhGUzRIFJebYdxtVqsmATXvgE(exception)
   return[]
  try:
   WukBaKhGUzRIFJebYdxtVqsmATXvoD.update(WukBaKhGUzRIFJebYdxtVqsmATXvog.GetDefaultParams(login=WukBaKhGUzRIFJebYdxtVqsmATXvgi))
   WukBaKhGUzRIFJebYdxtVqsmATXvon=WukBaKhGUzRIFJebYdxtVqsmATXvog.callRequestCookies('Get',WukBaKhGUzRIFJebYdxtVqsmATXvor,payload=WukBaKhGUzRIFJebYdxtVqsmATXvgN,params=WukBaKhGUzRIFJebYdxtVqsmATXvgN,headers=WukBaKhGUzRIFJebYdxtVqsmATXvgN,cookies=WukBaKhGUzRIFJebYdxtVqsmATXvgN)
   WukBaKhGUzRIFJebYdxtVqsmATXvop=json.loads(WukBaKhGUzRIFJebYdxtVqsmATXvon.text)
   if not('multisectionlist' in WukBaKhGUzRIFJebYdxtVqsmATXvop):return[]
   WukBaKhGUzRIFJebYdxtVqsmATXvcC=WukBaKhGUzRIFJebYdxtVqsmATXvop['multisectionlist']
   for WukBaKhGUzRIFJebYdxtVqsmATXvcS in WukBaKhGUzRIFJebYdxtVqsmATXvcC:
    WukBaKhGUzRIFJebYdxtVqsmATXvcy=WukBaKhGUzRIFJebYdxtVqsmATXvcS['title']
    if WukBaKhGUzRIFJebYdxtVqsmATXvgM(WukBaKhGUzRIFJebYdxtVqsmATXvcy)==0:continue
    if WukBaKhGUzRIFJebYdxtVqsmATXvcy=='minor':continue
    if re.search(u'베너',WukBaKhGUzRIFJebYdxtVqsmATXvcy):continue
    if re.search(u'배너',WukBaKhGUzRIFJebYdxtVqsmATXvcy):continue 
    if WukBaKhGUzRIFJebYdxtVqsmATXvgM(WukBaKhGUzRIFJebYdxtVqsmATXvcS['eventlist'])>=3:
     WukBaKhGUzRIFJebYdxtVqsmATXvcf =WukBaKhGUzRIFJebYdxtVqsmATXvcS['eventlist'][2]['url']
    else:
     WukBaKhGUzRIFJebYdxtVqsmATXvcf =WukBaKhGUzRIFJebYdxtVqsmATXvcS['eventlist'][1]['url']
    WukBaKhGUzRIFJebYdxtVqsmATXvcl=WukBaKhGUzRIFJebYdxtVqsmATXvcS['cell_type']
    if WukBaKhGUzRIFJebYdxtVqsmATXvcl=='band_2':
     if WukBaKhGUzRIFJebYdxtVqsmATXvcf.find('channellist=')>=0:
      WukBaKhGUzRIFJebYdxtVqsmATXvcl='band_live'
    WukBaKhGUzRIFJebYdxtVqsmATXvcN={'title':WukBaKhGUzRIFJebYdxtVqsmATXvog.Get_ChangeText(WukBaKhGUzRIFJebYdxtVqsmATXvcy),'subapi':WukBaKhGUzRIFJebYdxtVqsmATXvcf,'cell_type':WukBaKhGUzRIFJebYdxtVqsmATXvcl}
    WukBaKhGUzRIFJebYdxtVqsmATXvcj.append(WukBaKhGUzRIFJebYdxtVqsmATXvcN)
  except WukBaKhGUzRIFJebYdxtVqsmATXvgl as exception:
   WukBaKhGUzRIFJebYdxtVqsmATXvgE(exception)
   return[]
  return WukBaKhGUzRIFJebYdxtVqsmATXvcj
 def Get_BandLiveSection_List(WukBaKhGUzRIFJebYdxtVqsmATXvog,WukBaKhGUzRIFJebYdxtVqsmATXvcL,page_int=1):
  WukBaKhGUzRIFJebYdxtVqsmATXvcE=[]
  WukBaKhGUzRIFJebYdxtVqsmATXvcQ=WukBaKhGUzRIFJebYdxtVqsmATXvHo=1
  WukBaKhGUzRIFJebYdxtVqsmATXvcr=WukBaKhGUzRIFJebYdxtVqsmATXvgi
  try:
   (WukBaKhGUzRIFJebYdxtVqsmATXvor,WukBaKhGUzRIFJebYdxtVqsmATXvoD)=WukBaKhGUzRIFJebYdxtVqsmATXvog.Baseapi_Parse(WukBaKhGUzRIFJebYdxtVqsmATXvcL)
  except WukBaKhGUzRIFJebYdxtVqsmATXvgl as exception:
   WukBaKhGUzRIFJebYdxtVqsmATXvgE(exception)
   return[],WukBaKhGUzRIFJebYdxtVqsmATXvgi
  try:
   WukBaKhGUzRIFJebYdxtVqsmATXvoD['limit']=WukBaKhGUzRIFJebYdxtVqsmATXvog.LIST_LIMIT
   WukBaKhGUzRIFJebYdxtVqsmATXvoD['offset']=WukBaKhGUzRIFJebYdxtVqsmATXvgy((page_int-1)*WukBaKhGUzRIFJebYdxtVqsmATXvog.LIST_LIMIT)
   WukBaKhGUzRIFJebYdxtVqsmATXvoD.update(WukBaKhGUzRIFJebYdxtVqsmATXvog.GetDefaultParams(login=WukBaKhGUzRIFJebYdxtVqsmATXvgi))
   WukBaKhGUzRIFJebYdxtVqsmATXvon=WukBaKhGUzRIFJebYdxtVqsmATXvog.callRequestCookies('Get',WukBaKhGUzRIFJebYdxtVqsmATXvor,payload=WukBaKhGUzRIFJebYdxtVqsmATXvgN,params=WukBaKhGUzRIFJebYdxtVqsmATXvoD,headers=WukBaKhGUzRIFJebYdxtVqsmATXvgN,cookies=WukBaKhGUzRIFJebYdxtVqsmATXvgN)
   WukBaKhGUzRIFJebYdxtVqsmATXvop=json.loads(WukBaKhGUzRIFJebYdxtVqsmATXvon.text)
   if not('celllist' in WukBaKhGUzRIFJebYdxtVqsmATXvop['cell_toplist']):return[],WukBaKhGUzRIFJebYdxtVqsmATXvgi
   WukBaKhGUzRIFJebYdxtVqsmATXvcC=WukBaKhGUzRIFJebYdxtVqsmATXvop['cell_toplist']['celllist']
   for WukBaKhGUzRIFJebYdxtVqsmATXvcS in WukBaKhGUzRIFJebYdxtVqsmATXvcC:
    WukBaKhGUzRIFJebYdxtVqsmATXvcM =WukBaKhGUzRIFJebYdxtVqsmATXvcS['event_list'][1]['url']
    WukBaKhGUzRIFJebYdxtVqsmATXvcn=urllib.parse.urlsplit(WukBaKhGUzRIFJebYdxtVqsmATXvcM).query
    WukBaKhGUzRIFJebYdxtVqsmATXvcn=WukBaKhGUzRIFJebYdxtVqsmATXvgQ(urllib.parse.parse_qsl(WukBaKhGUzRIFJebYdxtVqsmATXvcn))
    WukBaKhGUzRIFJebYdxtVqsmATXvcp='channelid'
    WukBaKhGUzRIFJebYdxtVqsmATXvcO=WukBaKhGUzRIFJebYdxtVqsmATXvcn[WukBaKhGUzRIFJebYdxtVqsmATXvcp]
    WukBaKhGUzRIFJebYdxtVqsmATXvcN={'studio':WukBaKhGUzRIFJebYdxtVqsmATXvcS['title_list'][0]['text'],'tvshowtitle':WukBaKhGUzRIFJebYdxtVqsmATXvog.Get_ChangeText(WukBaKhGUzRIFJebYdxtVqsmATXvcS['title_list'][1]['text']),'channelid':WukBaKhGUzRIFJebYdxtVqsmATXvcO,'age':WukBaKhGUzRIFJebYdxtVqsmATXvcS.get('age'),'thumbnail':'https://%s'%WukBaKhGUzRIFJebYdxtVqsmATXvcS.get('thumbnail')}
    WukBaKhGUzRIFJebYdxtVqsmATXvcE.append(WukBaKhGUzRIFJebYdxtVqsmATXvcN)
   WukBaKhGUzRIFJebYdxtVqsmATXvcQ=WukBaKhGUzRIFJebYdxtVqsmATXvgr(WukBaKhGUzRIFJebYdxtVqsmATXvop['cell_toplist']['pagecount'])
   if WukBaKhGUzRIFJebYdxtVqsmATXvop['cell_toplist']['count']:WukBaKhGUzRIFJebYdxtVqsmATXvHo =WukBaKhGUzRIFJebYdxtVqsmATXvgr(WukBaKhGUzRIFJebYdxtVqsmATXvop['cell_toplist']['count'])
   else:WukBaKhGUzRIFJebYdxtVqsmATXvHo=WukBaKhGUzRIFJebYdxtVqsmATXvog.LIST_LIMIT*page_int
   WukBaKhGUzRIFJebYdxtVqsmATXvcr=WukBaKhGUzRIFJebYdxtVqsmATXvcQ>WukBaKhGUzRIFJebYdxtVqsmATXvHo
  except WukBaKhGUzRIFJebYdxtVqsmATXvgl as exception:
   WukBaKhGUzRIFJebYdxtVqsmATXvgE(exception)
   return[],WukBaKhGUzRIFJebYdxtVqsmATXvgi
  return WukBaKhGUzRIFJebYdxtVqsmATXvcE,WukBaKhGUzRIFJebYdxtVqsmATXvcr
 def Get_Band2Section_List(WukBaKhGUzRIFJebYdxtVqsmATXvog,WukBaKhGUzRIFJebYdxtVqsmATXvcL,page_int=1):
  WukBaKhGUzRIFJebYdxtVqsmATXvHc=[]
  WukBaKhGUzRIFJebYdxtVqsmATXvcQ=WukBaKhGUzRIFJebYdxtVqsmATXvHo=1
  WukBaKhGUzRIFJebYdxtVqsmATXvcr=WukBaKhGUzRIFJebYdxtVqsmATXvgi
  try:
   (WukBaKhGUzRIFJebYdxtVqsmATXvor,WukBaKhGUzRIFJebYdxtVqsmATXvoD)=WukBaKhGUzRIFJebYdxtVqsmATXvog.Baseapi_Parse(WukBaKhGUzRIFJebYdxtVqsmATXvcL)
  except WukBaKhGUzRIFJebYdxtVqsmATXvgl as exception:
   WukBaKhGUzRIFJebYdxtVqsmATXvgE(exception)
   return[],WukBaKhGUzRIFJebYdxtVqsmATXvgi
  try:
   WukBaKhGUzRIFJebYdxtVqsmATXvoD['came'] ='BandView'
   WukBaKhGUzRIFJebYdxtVqsmATXvoD['limit']=WukBaKhGUzRIFJebYdxtVqsmATXvog.LIST_LIMIT
   WukBaKhGUzRIFJebYdxtVqsmATXvoD['offset']=WukBaKhGUzRIFJebYdxtVqsmATXvgy((page_int-1)*WukBaKhGUzRIFJebYdxtVqsmATXvog.LIST_LIMIT)
   WukBaKhGUzRIFJebYdxtVqsmATXvoD.update(WukBaKhGUzRIFJebYdxtVqsmATXvog.GetDefaultParams(login=WukBaKhGUzRIFJebYdxtVqsmATXvgi))
   WukBaKhGUzRIFJebYdxtVqsmATXvon=WukBaKhGUzRIFJebYdxtVqsmATXvog.callRequestCookies('Get',WukBaKhGUzRIFJebYdxtVqsmATXvor,payload=WukBaKhGUzRIFJebYdxtVqsmATXvgN,params=WukBaKhGUzRIFJebYdxtVqsmATXvoD,headers=WukBaKhGUzRIFJebYdxtVqsmATXvgN,cookies=WukBaKhGUzRIFJebYdxtVqsmATXvgN)
   WukBaKhGUzRIFJebYdxtVqsmATXvop=json.loads(WukBaKhGUzRIFJebYdxtVqsmATXvon.text)
   if not('celllist' in WukBaKhGUzRIFJebYdxtVqsmATXvop['cell_toplist']):return[],WukBaKhGUzRIFJebYdxtVqsmATXvgi
   WukBaKhGUzRIFJebYdxtVqsmATXvcC=WukBaKhGUzRIFJebYdxtVqsmATXvop['cell_toplist']['celllist']
   for WukBaKhGUzRIFJebYdxtVqsmATXvcS in WukBaKhGUzRIFJebYdxtVqsmATXvcC:
    WukBaKhGUzRIFJebYdxtVqsmATXvcM =WukBaKhGUzRIFJebYdxtVqsmATXvcS['event_list'][1]['url']
    WukBaKhGUzRIFJebYdxtVqsmATXvcn=urllib.parse.urlsplit(WukBaKhGUzRIFJebYdxtVqsmATXvcM).query
    WukBaKhGUzRIFJebYdxtVqsmATXvcn=WukBaKhGUzRIFJebYdxtVqsmATXvgQ(urllib.parse.parse_qsl(WukBaKhGUzRIFJebYdxtVqsmATXvcn))
    WukBaKhGUzRIFJebYdxtVqsmATXvcp='contentid'
    WukBaKhGUzRIFJebYdxtVqsmATXvcO=WukBaKhGUzRIFJebYdxtVqsmATXvcn[WukBaKhGUzRIFJebYdxtVqsmATXvcp]
    WukBaKhGUzRIFJebYdxtVqsmATXvcN={'programtitle':WukBaKhGUzRIFJebYdxtVqsmATXvcS['title_list'][0]['text'],'episodetitle':WukBaKhGUzRIFJebYdxtVqsmATXvog.Get_ChangeText(WukBaKhGUzRIFJebYdxtVqsmATXvcS['title_list'][1]['text']),'age':WukBaKhGUzRIFJebYdxtVqsmATXvcS.get('age'),'thumbnail':WukBaKhGUzRIFJebYdxtVqsmATXvog.HTTPTAG+WukBaKhGUzRIFJebYdxtVqsmATXvcS.get('thumbnail'),'vidtype':WukBaKhGUzRIFJebYdxtVqsmATXvcp,'videoid':WukBaKhGUzRIFJebYdxtVqsmATXvcO}
    WukBaKhGUzRIFJebYdxtVqsmATXvHc.append(WukBaKhGUzRIFJebYdxtVqsmATXvcN)
   WukBaKhGUzRIFJebYdxtVqsmATXvcQ=WukBaKhGUzRIFJebYdxtVqsmATXvgr(WukBaKhGUzRIFJebYdxtVqsmATXvop['cell_toplist']['pagecount'])
   if WukBaKhGUzRIFJebYdxtVqsmATXvop['cell_toplist']['count']:WukBaKhGUzRIFJebYdxtVqsmATXvHo =WukBaKhGUzRIFJebYdxtVqsmATXvgr(WukBaKhGUzRIFJebYdxtVqsmATXvop['cell_toplist']['count'])
   else:WukBaKhGUzRIFJebYdxtVqsmATXvHo=WukBaKhGUzRIFJebYdxtVqsmATXvog.LIST_LIMIT*page_int
   WukBaKhGUzRIFJebYdxtVqsmATXvcr=WukBaKhGUzRIFJebYdxtVqsmATXvcQ>WukBaKhGUzRIFJebYdxtVqsmATXvHo
  except WukBaKhGUzRIFJebYdxtVqsmATXvgl as exception:
   WukBaKhGUzRIFJebYdxtVqsmATXvgE(exception)
   return[],WukBaKhGUzRIFJebYdxtVqsmATXvgi
  return WukBaKhGUzRIFJebYdxtVqsmATXvHc,WukBaKhGUzRIFJebYdxtVqsmATXvcr
 def Get_Program_List(WukBaKhGUzRIFJebYdxtVqsmATXvog,WukBaKhGUzRIFJebYdxtVqsmATXvcL,page_int=1,orderby='-'):
  WukBaKhGUzRIFJebYdxtVqsmATXvHg=[]
  WukBaKhGUzRIFJebYdxtVqsmATXvcQ=WukBaKhGUzRIFJebYdxtVqsmATXvHo=1
  WukBaKhGUzRIFJebYdxtVqsmATXvcr=WukBaKhGUzRIFJebYdxtVqsmATXvgi
  (WukBaKhGUzRIFJebYdxtVqsmATXvor,WukBaKhGUzRIFJebYdxtVqsmATXvoD)=WukBaKhGUzRIFJebYdxtVqsmATXvog.Baseapi_Parse(WukBaKhGUzRIFJebYdxtVqsmATXvcL)
  if WukBaKhGUzRIFJebYdxtVqsmATXvor=='':return WukBaKhGUzRIFJebYdxtVqsmATXvHg,WukBaKhGUzRIFJebYdxtVqsmATXvcr
  try:
   WukBaKhGUzRIFJebYdxtVqsmATXvoD['limit'] =WukBaKhGUzRIFJebYdxtVqsmATXvog.LIST_LIMIT
   WukBaKhGUzRIFJebYdxtVqsmATXvoD['offset']=WukBaKhGUzRIFJebYdxtVqsmATXvgy((page_int-1)*WukBaKhGUzRIFJebYdxtVqsmATXvog.LIST_LIMIT)
   WukBaKhGUzRIFJebYdxtVqsmATXvoD['page'] =WukBaKhGUzRIFJebYdxtVqsmATXvgy(page_int)
   if WukBaKhGUzRIFJebYdxtVqsmATXvoD.get('orderby')!='' and WukBaKhGUzRIFJebYdxtVqsmATXvoD.get('orderby')!='regdatefirst' and orderby!='-':
    WukBaKhGUzRIFJebYdxtVqsmATXvoD['orderby']=orderby 
   WukBaKhGUzRIFJebYdxtVqsmATXvoD.update(WukBaKhGUzRIFJebYdxtVqsmATXvog.GetDefaultParams(login=WukBaKhGUzRIFJebYdxtVqsmATXvgi))
   WukBaKhGUzRIFJebYdxtVqsmATXvon=WukBaKhGUzRIFJebYdxtVqsmATXvog.callRequestCookies('Get',WukBaKhGUzRIFJebYdxtVqsmATXvor,payload=WukBaKhGUzRIFJebYdxtVqsmATXvgN,params=WukBaKhGUzRIFJebYdxtVqsmATXvoD,headers=WukBaKhGUzRIFJebYdxtVqsmATXvgN,cookies=WukBaKhGUzRIFJebYdxtVqsmATXvgN)
   WukBaKhGUzRIFJebYdxtVqsmATXvop=json.loads(WukBaKhGUzRIFJebYdxtVqsmATXvon.text)
   if WukBaKhGUzRIFJebYdxtVqsmATXvcL.find('instantplay')>=0:
    if not('celllist' in WukBaKhGUzRIFJebYdxtVqsmATXvop['band']):return WukBaKhGUzRIFJebYdxtVqsmATXvHg,WukBaKhGUzRIFJebYdxtVqsmATXvcr
    WukBaKhGUzRIFJebYdxtVqsmATXvcC=WukBaKhGUzRIFJebYdxtVqsmATXvop['band']['celllist']
   else:
    if not('celllist' in WukBaKhGUzRIFJebYdxtVqsmATXvop['cell_toplist']):return WukBaKhGUzRIFJebYdxtVqsmATXvHg,WukBaKhGUzRIFJebYdxtVqsmATXvcr
    WukBaKhGUzRIFJebYdxtVqsmATXvcC=WukBaKhGUzRIFJebYdxtVqsmATXvop['cell_toplist']['celllist']
   for WukBaKhGUzRIFJebYdxtVqsmATXvcS in WukBaKhGUzRIFJebYdxtVqsmATXvcC:
    for WukBaKhGUzRIFJebYdxtVqsmATXvHP in WukBaKhGUzRIFJebYdxtVqsmATXvcS['event_list']:
     if WukBaKhGUzRIFJebYdxtVqsmATXvHP.get('type')=='on-navigation':
      WukBaKhGUzRIFJebYdxtVqsmATXvcM =WukBaKhGUzRIFJebYdxtVqsmATXvHP['url']
    WukBaKhGUzRIFJebYdxtVqsmATXvcn=urllib.parse.urlsplit(WukBaKhGUzRIFJebYdxtVqsmATXvcM).query
    WukBaKhGUzRIFJebYdxtVqsmATXvcp=WukBaKhGUzRIFJebYdxtVqsmATXvcn[0:WukBaKhGUzRIFJebYdxtVqsmATXvcn.find('=')]
    WukBaKhGUzRIFJebYdxtVqsmATXvcO=WukBaKhGUzRIFJebYdxtVqsmATXvcn[WukBaKhGUzRIFJebYdxtVqsmATXvcn.find('=')+1:]
    WukBaKhGUzRIFJebYdxtVqsmATXvcN={'title':WukBaKhGUzRIFJebYdxtVqsmATXvcS['title_list'][0]['text'],'age':WukBaKhGUzRIFJebYdxtVqsmATXvcS['age'],'thumbnail':'https://%s'%WukBaKhGUzRIFJebYdxtVqsmATXvcS.get('thumbnail'),'videoid':WukBaKhGUzRIFJebYdxtVqsmATXvcO,'vidtype':WukBaKhGUzRIFJebYdxtVqsmATXvcp}
    WukBaKhGUzRIFJebYdxtVqsmATXvHg.append(WukBaKhGUzRIFJebYdxtVqsmATXvcN)
   if WukBaKhGUzRIFJebYdxtVqsmATXvcL.find('instantplay')<0:
    WukBaKhGUzRIFJebYdxtVqsmATXvcQ=WukBaKhGUzRIFJebYdxtVqsmATXvgr(WukBaKhGUzRIFJebYdxtVqsmATXvop['cell_toplist']['pagecount'])
    if WukBaKhGUzRIFJebYdxtVqsmATXvop['cell_toplist']['count']:WukBaKhGUzRIFJebYdxtVqsmATXvHo =WukBaKhGUzRIFJebYdxtVqsmATXvgr(WukBaKhGUzRIFJebYdxtVqsmATXvop['cell_toplist']['count'])
    else:WukBaKhGUzRIFJebYdxtVqsmATXvHo=WukBaKhGUzRIFJebYdxtVqsmATXvog.LIST_LIMIT*page_int
    WukBaKhGUzRIFJebYdxtVqsmATXvcr=WukBaKhGUzRIFJebYdxtVqsmATXvcQ>WukBaKhGUzRIFJebYdxtVqsmATXvHo
  except WukBaKhGUzRIFJebYdxtVqsmATXvgl as exception:
   WukBaKhGUzRIFJebYdxtVqsmATXvgE(exception)
   return[],WukBaKhGUzRIFJebYdxtVqsmATXvgi
  return WukBaKhGUzRIFJebYdxtVqsmATXvHg,WukBaKhGUzRIFJebYdxtVqsmATXvcr
 def Get_Movie_List(WukBaKhGUzRIFJebYdxtVqsmATXvog,WukBaKhGUzRIFJebYdxtVqsmATXvcL,page_int=1):
  WukBaKhGUzRIFJebYdxtVqsmATXvHj=[]
  WukBaKhGUzRIFJebYdxtVqsmATXvcQ=WukBaKhGUzRIFJebYdxtVqsmATXvHo=1
  WukBaKhGUzRIFJebYdxtVqsmATXvcr=WukBaKhGUzRIFJebYdxtVqsmATXvgi
  (WukBaKhGUzRIFJebYdxtVqsmATXvor,WukBaKhGUzRIFJebYdxtVqsmATXvoD)=WukBaKhGUzRIFJebYdxtVqsmATXvog.Baseapi_Parse(WukBaKhGUzRIFJebYdxtVqsmATXvcL)
  if WukBaKhGUzRIFJebYdxtVqsmATXvor=='':return WukBaKhGUzRIFJebYdxtVqsmATXvHj,WukBaKhGUzRIFJebYdxtVqsmATXvcr
  try:
   WukBaKhGUzRIFJebYdxtVqsmATXvoD['limit']=WukBaKhGUzRIFJebYdxtVqsmATXvog.MV_LIMIT
   WukBaKhGUzRIFJebYdxtVqsmATXvoD['offset']=WukBaKhGUzRIFJebYdxtVqsmATXvgy((page_int-1)*WukBaKhGUzRIFJebYdxtVqsmATXvog.MV_LIMIT)
   WukBaKhGUzRIFJebYdxtVqsmATXvoD.update(WukBaKhGUzRIFJebYdxtVqsmATXvog.GetDefaultParams(login=WukBaKhGUzRIFJebYdxtVqsmATXvgi))
   WukBaKhGUzRIFJebYdxtVqsmATXvon=WukBaKhGUzRIFJebYdxtVqsmATXvog.callRequestCookies('Get',WukBaKhGUzRIFJebYdxtVqsmATXvor,payload=WukBaKhGUzRIFJebYdxtVqsmATXvgN,params=WukBaKhGUzRIFJebYdxtVqsmATXvoD,headers=WukBaKhGUzRIFJebYdxtVqsmATXvgN,cookies=WukBaKhGUzRIFJebYdxtVqsmATXvgN)
   WukBaKhGUzRIFJebYdxtVqsmATXvop=json.loads(WukBaKhGUzRIFJebYdxtVqsmATXvon.text)
   if not('celllist' in WukBaKhGUzRIFJebYdxtVqsmATXvop['cell_toplist']):return WukBaKhGUzRIFJebYdxtVqsmATXvHj,WukBaKhGUzRIFJebYdxtVqsmATXvcr
   WukBaKhGUzRIFJebYdxtVqsmATXvcC=WukBaKhGUzRIFJebYdxtVqsmATXvop['cell_toplist']['celllist']
   for WukBaKhGUzRIFJebYdxtVqsmATXvcS in WukBaKhGUzRIFJebYdxtVqsmATXvcC:
    WukBaKhGUzRIFJebYdxtVqsmATXvcM =WukBaKhGUzRIFJebYdxtVqsmATXvcS['event_list'][1]['url']
    WukBaKhGUzRIFJebYdxtVqsmATXvcn=urllib.parse.urlsplit(WukBaKhGUzRIFJebYdxtVqsmATXvcM).query
    WukBaKhGUzRIFJebYdxtVqsmATXvcp=WukBaKhGUzRIFJebYdxtVqsmATXvcn[0:WukBaKhGUzRIFJebYdxtVqsmATXvcn.find('=')]
    WukBaKhGUzRIFJebYdxtVqsmATXvcO=WukBaKhGUzRIFJebYdxtVqsmATXvcn[WukBaKhGUzRIFJebYdxtVqsmATXvcn.find('=')+1:]
    WukBaKhGUzRIFJebYdxtVqsmATXvcN={'title':WukBaKhGUzRIFJebYdxtVqsmATXvcS['title_list'][0]['text'],'age':WukBaKhGUzRIFJebYdxtVqsmATXvcS['age'],'thumbnail':'https://%s'%WukBaKhGUzRIFJebYdxtVqsmATXvcS.get('thumbnail'),'videoid':WukBaKhGUzRIFJebYdxtVqsmATXvcO,'vidtype':WukBaKhGUzRIFJebYdxtVqsmATXvcp}
    WukBaKhGUzRIFJebYdxtVqsmATXvHj.append(WukBaKhGUzRIFJebYdxtVqsmATXvcN)
   WukBaKhGUzRIFJebYdxtVqsmATXvcQ=WukBaKhGUzRIFJebYdxtVqsmATXvgr(WukBaKhGUzRIFJebYdxtVqsmATXvop['cell_toplist']['pagecount'])
   if WukBaKhGUzRIFJebYdxtVqsmATXvop['cell_toplist']['count']:WukBaKhGUzRIFJebYdxtVqsmATXvHo =WukBaKhGUzRIFJebYdxtVqsmATXvgr(WukBaKhGUzRIFJebYdxtVqsmATXvop['cell_toplist']['count'])
   else:WukBaKhGUzRIFJebYdxtVqsmATXvHo=WukBaKhGUzRIFJebYdxtVqsmATXvog.MV_LIMIT*page_int
   WukBaKhGUzRIFJebYdxtVqsmATXvcr=WukBaKhGUzRIFJebYdxtVqsmATXvcQ>WukBaKhGUzRIFJebYdxtVqsmATXvHo
  except WukBaKhGUzRIFJebYdxtVqsmATXvgl as exception:
   WukBaKhGUzRIFJebYdxtVqsmATXvgE(exception)
   return[],WukBaKhGUzRIFJebYdxtVqsmATXvgi
  return WukBaKhGUzRIFJebYdxtVqsmATXvHj,WukBaKhGUzRIFJebYdxtVqsmATXvcr
 def ChangeToProgramid(WukBaKhGUzRIFJebYdxtVqsmATXvog,WukBaKhGUzRIFJebYdxtVqsmATXvHr):
  WukBaKhGUzRIFJebYdxtVqsmATXvHL=''
  try:
   WukBaKhGUzRIFJebYdxtVqsmATXvor =WukBaKhGUzRIFJebYdxtVqsmATXvog.API_DOMAIN+'/cf/vod/contents/'+WukBaKhGUzRIFJebYdxtVqsmATXvHr
   WukBaKhGUzRIFJebYdxtVqsmATXvoD=WukBaKhGUzRIFJebYdxtVqsmATXvog.GetDefaultParams(login=WukBaKhGUzRIFJebYdxtVqsmATXvgi)
   WukBaKhGUzRIFJebYdxtVqsmATXvon=WukBaKhGUzRIFJebYdxtVqsmATXvog.callRequestCookies('Get',WukBaKhGUzRIFJebYdxtVqsmATXvor,payload=WukBaKhGUzRIFJebYdxtVqsmATXvgN,params=WukBaKhGUzRIFJebYdxtVqsmATXvoD,headers=WukBaKhGUzRIFJebYdxtVqsmATXvgN,cookies=WukBaKhGUzRIFJebYdxtVqsmATXvgN)
   WukBaKhGUzRIFJebYdxtVqsmATXvHD=json.loads(WukBaKhGUzRIFJebYdxtVqsmATXvon.text)
   if not('programid' in WukBaKhGUzRIFJebYdxtVqsmATXvHD):return WukBaKhGUzRIFJebYdxtVqsmATXvHL 
   WukBaKhGUzRIFJebYdxtVqsmATXvHL=WukBaKhGUzRIFJebYdxtVqsmATXvHD['programid']
  except WukBaKhGUzRIFJebYdxtVqsmATXvgl as exception:
   WukBaKhGUzRIFJebYdxtVqsmATXvgE(exception)
  return WukBaKhGUzRIFJebYdxtVqsmATXvHL
 def Get_Episode_List(WukBaKhGUzRIFJebYdxtVqsmATXvog,WukBaKhGUzRIFJebYdxtVqsmATXvcO,WukBaKhGUzRIFJebYdxtVqsmATXvcp,page_int=1,orderby='desc'):
  WukBaKhGUzRIFJebYdxtVqsmATXvHC=[]
  WukBaKhGUzRIFJebYdxtVqsmATXvcQ=WukBaKhGUzRIFJebYdxtVqsmATXvHo=1
  WukBaKhGUzRIFJebYdxtVqsmATXvcr=WukBaKhGUzRIFJebYdxtVqsmATXvgi
  if WukBaKhGUzRIFJebYdxtVqsmATXvcp=='contentid':
   WukBaKhGUzRIFJebYdxtVqsmATXvHL=WukBaKhGUzRIFJebYdxtVqsmATXvog.ChangeToProgramid(WukBaKhGUzRIFJebYdxtVqsmATXvcO)
  else:
   WukBaKhGUzRIFJebYdxtVqsmATXvHL=WukBaKhGUzRIFJebYdxtVqsmATXvcO
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   WukBaKhGUzRIFJebYdxtVqsmATXvor=WukBaKhGUzRIFJebYdxtVqsmATXvog.API_DOMAIN+'/vod/programs-contents/'+WukBaKhGUzRIFJebYdxtVqsmATXvHL
   WukBaKhGUzRIFJebYdxtVqsmATXvoD={}
   WukBaKhGUzRIFJebYdxtVqsmATXvoD['limit'] =WukBaKhGUzRIFJebYdxtVqsmATXvog.EP_LIMIT
   WukBaKhGUzRIFJebYdxtVqsmATXvoD['offset']=WukBaKhGUzRIFJebYdxtVqsmATXvgy((page_int-1)*WukBaKhGUzRIFJebYdxtVqsmATXvog.EP_LIMIT)
   WukBaKhGUzRIFJebYdxtVqsmATXvoD['orderby']=orderby 
   WukBaKhGUzRIFJebYdxtVqsmATXvoD.update(WukBaKhGUzRIFJebYdxtVqsmATXvog.GetDefaultParams(login=WukBaKhGUzRIFJebYdxtVqsmATXvgi))
   WukBaKhGUzRIFJebYdxtVqsmATXvon=WukBaKhGUzRIFJebYdxtVqsmATXvog.callRequestCookies('Get',WukBaKhGUzRIFJebYdxtVqsmATXvor,payload=WukBaKhGUzRIFJebYdxtVqsmATXvgN,params=WukBaKhGUzRIFJebYdxtVqsmATXvoD,headers=WukBaKhGUzRIFJebYdxtVqsmATXvgN,cookies=WukBaKhGUzRIFJebYdxtVqsmATXvgN)
   WukBaKhGUzRIFJebYdxtVqsmATXvop=json.loads(WukBaKhGUzRIFJebYdxtVqsmATXvon.text)
   WukBaKhGUzRIFJebYdxtVqsmATXvcC=WukBaKhGUzRIFJebYdxtVqsmATXvop['list']
   for WukBaKhGUzRIFJebYdxtVqsmATXvcS in WukBaKhGUzRIFJebYdxtVqsmATXvcC:
    WukBaKhGUzRIFJebYdxtVqsmATXvHN=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',WukBaKhGUzRIFJebYdxtVqsmATXvcS.get('synopsis'))
    WukBaKhGUzRIFJebYdxtVqsmATXvcN={'programtitle':WukBaKhGUzRIFJebYdxtVqsmATXvcS.get('programtitle'),'episodetitle':WukBaKhGUzRIFJebYdxtVqsmATXvcS.get('episodetitle'),'episodenumber':WukBaKhGUzRIFJebYdxtVqsmATXvcS.get('episodenumber'),'releasedate':WukBaKhGUzRIFJebYdxtVqsmATXvcS.get('releasedate'),'releaseweekday':WukBaKhGUzRIFJebYdxtVqsmATXvcS.get('releaseweekday'),'programid':WukBaKhGUzRIFJebYdxtVqsmATXvcS.get('programid'),'contentid':WukBaKhGUzRIFJebYdxtVqsmATXvcS.get('contentid'),'age':WukBaKhGUzRIFJebYdxtVqsmATXvcS.get('targetage'),'playtime':WukBaKhGUzRIFJebYdxtVqsmATXvcS.get('playtime'),'synopsis':WukBaKhGUzRIFJebYdxtVqsmATXvHN,'episodeactors':WukBaKhGUzRIFJebYdxtVqsmATXvcS.get('episodeactors').split(','),'thumbnail':WukBaKhGUzRIFJebYdxtVqsmATXvog.HTTPTAG+WukBaKhGUzRIFJebYdxtVqsmATXvcS.get('image')}
    WukBaKhGUzRIFJebYdxtVqsmATXvHC.append(WukBaKhGUzRIFJebYdxtVqsmATXvcN)
   WukBaKhGUzRIFJebYdxtVqsmATXvcQ=WukBaKhGUzRIFJebYdxtVqsmATXvgr(WukBaKhGUzRIFJebYdxtVqsmATXvop['pagecount'])
   if WukBaKhGUzRIFJebYdxtVqsmATXvop['count']:WukBaKhGUzRIFJebYdxtVqsmATXvHo =WukBaKhGUzRIFJebYdxtVqsmATXvgr(WukBaKhGUzRIFJebYdxtVqsmATXvop['count'])
   else:WukBaKhGUzRIFJebYdxtVqsmATXvHo=WukBaKhGUzRIFJebYdxtVqsmATXvog.EP_LIMIT*page_int
   WukBaKhGUzRIFJebYdxtVqsmATXvcr=WukBaKhGUzRIFJebYdxtVqsmATXvcQ>WukBaKhGUzRIFJebYdxtVqsmATXvHo
  except WukBaKhGUzRIFJebYdxtVqsmATXvgl as exception:
   WukBaKhGUzRIFJebYdxtVqsmATXvgE(exception)
   return[],WukBaKhGUzRIFJebYdxtVqsmATXvgi
  return WukBaKhGUzRIFJebYdxtVqsmATXvHC,WukBaKhGUzRIFJebYdxtVqsmATXvcr
 def GetEPGList(WukBaKhGUzRIFJebYdxtVqsmATXvog,genre):
  WukBaKhGUzRIFJebYdxtVqsmATXvHi={}
  try:
   WukBaKhGUzRIFJebYdxtVqsmATXvHw=WukBaKhGUzRIFJebYdxtVqsmATXvog.Get_Now_Datetime()
   if genre=='all':
    WukBaKhGUzRIFJebYdxtVqsmATXvHf =WukBaKhGUzRIFJebYdxtVqsmATXvHw+datetime.timedelta(hours=3)
   else:
    WukBaKhGUzRIFJebYdxtVqsmATXvHf =WukBaKhGUzRIFJebYdxtVqsmATXvHw+datetime.timedelta(hours=3)
   WukBaKhGUzRIFJebYdxtVqsmATXvor=WukBaKhGUzRIFJebYdxtVqsmATXvog.API_DOMAIN+'/live/epgs'
   WukBaKhGUzRIFJebYdxtVqsmATXvoD={'limit':'100','offset':'0','genre':genre,'startdatetime':WukBaKhGUzRIFJebYdxtVqsmATXvHw.strftime('%Y-%m-%d %H:00'),'enddatetime':WukBaKhGUzRIFJebYdxtVqsmATXvHf.strftime('%Y-%m-%d %H:00')}
   WukBaKhGUzRIFJebYdxtVqsmATXvoD.update(WukBaKhGUzRIFJebYdxtVqsmATXvog.GetDefaultParams(login=WukBaKhGUzRIFJebYdxtVqsmATXvgi))
   WukBaKhGUzRIFJebYdxtVqsmATXvon=WukBaKhGUzRIFJebYdxtVqsmATXvog.callRequestCookies('Get',WukBaKhGUzRIFJebYdxtVqsmATXvor,payload=WukBaKhGUzRIFJebYdxtVqsmATXvgN,params=WukBaKhGUzRIFJebYdxtVqsmATXvoD,headers=WukBaKhGUzRIFJebYdxtVqsmATXvgN,cookies=WukBaKhGUzRIFJebYdxtVqsmATXvgN)
   WukBaKhGUzRIFJebYdxtVqsmATXvop=json.loads(WukBaKhGUzRIFJebYdxtVqsmATXvon.text)
   WukBaKhGUzRIFJebYdxtVqsmATXvHy=WukBaKhGUzRIFJebYdxtVqsmATXvop['list']
   for WukBaKhGUzRIFJebYdxtVqsmATXvcS in WukBaKhGUzRIFJebYdxtVqsmATXvHy:
    WukBaKhGUzRIFJebYdxtVqsmATXvHl=''
    for WukBaKhGUzRIFJebYdxtVqsmATXvHE in WukBaKhGUzRIFJebYdxtVqsmATXvcS['list']:
     if WukBaKhGUzRIFJebYdxtVqsmATXvHl:WukBaKhGUzRIFJebYdxtVqsmATXvHl+='\n'
     WukBaKhGUzRIFJebYdxtVqsmATXvHl+=WukBaKhGUzRIFJebYdxtVqsmATXvog.Get_ChangeText(WukBaKhGUzRIFJebYdxtVqsmATXvHE['title'])+'\n'
     WukBaKhGUzRIFJebYdxtVqsmATXvHl+=' [%s ~ %s]'%(WukBaKhGUzRIFJebYdxtVqsmATXvHE['starttime'][-5:],WukBaKhGUzRIFJebYdxtVqsmATXvHE['endtime'][-5:])+'\n'
    WukBaKhGUzRIFJebYdxtVqsmATXvHi[WukBaKhGUzRIFJebYdxtVqsmATXvcS['channelid']]=WukBaKhGUzRIFJebYdxtVqsmATXvHl
  except WukBaKhGUzRIFJebYdxtVqsmATXvgl as exception:
   WukBaKhGUzRIFJebYdxtVqsmATXvgE(exception)
  return WukBaKhGUzRIFJebYdxtVqsmATXvHi
 def Get_LiveChannel_List(WukBaKhGUzRIFJebYdxtVqsmATXvog,genre,WukBaKhGUzRIFJebYdxtVqsmATXvcL):
  WukBaKhGUzRIFJebYdxtVqsmATXvcE=[]
  (WukBaKhGUzRIFJebYdxtVqsmATXvor,WukBaKhGUzRIFJebYdxtVqsmATXvoD)=WukBaKhGUzRIFJebYdxtVqsmATXvog.Baseapi_Parse(WukBaKhGUzRIFJebYdxtVqsmATXvcL)
  if WukBaKhGUzRIFJebYdxtVqsmATXvor=='':return WukBaKhGUzRIFJebYdxtVqsmATXvcE
  WukBaKhGUzRIFJebYdxtVqsmATXvHQ=WukBaKhGUzRIFJebYdxtVqsmATXvog.GetEPGList(genre)
  try:
   WukBaKhGUzRIFJebYdxtVqsmATXvoD.update(WukBaKhGUzRIFJebYdxtVqsmATXvog.GetDefaultParams(login=WukBaKhGUzRIFJebYdxtVqsmATXvgi))
   WukBaKhGUzRIFJebYdxtVqsmATXvoD['genre']=genre
   WukBaKhGUzRIFJebYdxtVqsmATXvon=WukBaKhGUzRIFJebYdxtVqsmATXvog.callRequestCookies('Get',WukBaKhGUzRIFJebYdxtVqsmATXvor,payload=WukBaKhGUzRIFJebYdxtVqsmATXvgN,params=WukBaKhGUzRIFJebYdxtVqsmATXvoD,headers=WukBaKhGUzRIFJebYdxtVqsmATXvgN,cookies=WukBaKhGUzRIFJebYdxtVqsmATXvgN)
   WukBaKhGUzRIFJebYdxtVqsmATXvop=json.loads(WukBaKhGUzRIFJebYdxtVqsmATXvon.text)
   if not('celllist' in WukBaKhGUzRIFJebYdxtVqsmATXvop['cell_toplist']):return[]
   WukBaKhGUzRIFJebYdxtVqsmATXvcC=WukBaKhGUzRIFJebYdxtVqsmATXvop['cell_toplist']['celllist']
   for WukBaKhGUzRIFJebYdxtVqsmATXvcS in WukBaKhGUzRIFJebYdxtVqsmATXvcC:
    WukBaKhGUzRIFJebYdxtVqsmATXvHr=WukBaKhGUzRIFJebYdxtVqsmATXvcS['contentid']
    if WukBaKhGUzRIFJebYdxtVqsmATXvHr in WukBaKhGUzRIFJebYdxtVqsmATXvHQ:
     WukBaKhGUzRIFJebYdxtVqsmATXvHM=WukBaKhGUzRIFJebYdxtVqsmATXvHQ[WukBaKhGUzRIFJebYdxtVqsmATXvHr]
    else:
     WukBaKhGUzRIFJebYdxtVqsmATXvHM=''
    WukBaKhGUzRIFJebYdxtVqsmATXvcN={'studio':WukBaKhGUzRIFJebYdxtVqsmATXvcS['title_list'][0]['text'],'tvshowtitle':WukBaKhGUzRIFJebYdxtVqsmATXvog.Get_ChangeText(WukBaKhGUzRIFJebYdxtVqsmATXvcS['title_list'][1]['text']),'channelid':WukBaKhGUzRIFJebYdxtVqsmATXvHr,'age':WukBaKhGUzRIFJebYdxtVqsmATXvcS['age'],'thumbnail':'https://%s'%WukBaKhGUzRIFJebYdxtVqsmATXvcS.get('thumbnail'),'epg':WukBaKhGUzRIFJebYdxtVqsmATXvHM}
    WukBaKhGUzRIFJebYdxtVqsmATXvcE.append(WukBaKhGUzRIFJebYdxtVqsmATXvcN)
  except WukBaKhGUzRIFJebYdxtVqsmATXvgl as exception:
   WukBaKhGUzRIFJebYdxtVqsmATXvgE(exception)
   return[]
  return WukBaKhGUzRIFJebYdxtVqsmATXvcE
 def Get_Search_List(WukBaKhGUzRIFJebYdxtVqsmATXvog,search_key,sType,page_int,exclusion21=WukBaKhGUzRIFJebYdxtVqsmATXvgi):
  WukBaKhGUzRIFJebYdxtVqsmATXvHn=[]
  WukBaKhGUzRIFJebYdxtVqsmATXvcQ=WukBaKhGUzRIFJebYdxtVqsmATXvHo=1
  WukBaKhGUzRIFJebYdxtVqsmATXvcr=WukBaKhGUzRIFJebYdxtVqsmATXvgi
  try:
   WukBaKhGUzRIFJebYdxtVqsmATXvor=WukBaKhGUzRIFJebYdxtVqsmATXvog.API_DOMAIN+'/cf/search/list.js'
   WukBaKhGUzRIFJebYdxtVqsmATXvoD={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':WukBaKhGUzRIFJebYdxtVqsmATXvgy((page_int-1)*WukBaKhGUzRIFJebYdxtVqsmATXvog.LIST_LIMIT),'limit':WukBaKhGUzRIFJebYdxtVqsmATXvog.LIST_LIMIT,'orderby':'score'}
   WukBaKhGUzRIFJebYdxtVqsmATXvoD.update(WukBaKhGUzRIFJebYdxtVqsmATXvog.GetDefaultParams(login=WukBaKhGUzRIFJebYdxtVqsmATXvgi))
   WukBaKhGUzRIFJebYdxtVqsmATXvon=WukBaKhGUzRIFJebYdxtVqsmATXvog.callRequestCookies('Get',WukBaKhGUzRIFJebYdxtVqsmATXvor,payload=WukBaKhGUzRIFJebYdxtVqsmATXvgN,params=WukBaKhGUzRIFJebYdxtVqsmATXvoD,headers=WukBaKhGUzRIFJebYdxtVqsmATXvgN,cookies=WukBaKhGUzRIFJebYdxtVqsmATXvgN)
   WukBaKhGUzRIFJebYdxtVqsmATXvHD=json.loads(WukBaKhGUzRIFJebYdxtVqsmATXvon.text)
   if not('celllist' in WukBaKhGUzRIFJebYdxtVqsmATXvHD['cell_toplist']):return WukBaKhGUzRIFJebYdxtVqsmATXvHn,WukBaKhGUzRIFJebYdxtVqsmATXvcr
   WukBaKhGUzRIFJebYdxtVqsmATXvcC=WukBaKhGUzRIFJebYdxtVqsmATXvHD['cell_toplist']['celllist']
   for WukBaKhGUzRIFJebYdxtVqsmATXvcS in WukBaKhGUzRIFJebYdxtVqsmATXvcC:
    WukBaKhGUzRIFJebYdxtVqsmATXvcM =WukBaKhGUzRIFJebYdxtVqsmATXvcS['event_list'][1]['url']
    WukBaKhGUzRIFJebYdxtVqsmATXvcn=urllib.parse.urlsplit(WukBaKhGUzRIFJebYdxtVqsmATXvcM).query
    WukBaKhGUzRIFJebYdxtVqsmATXvcp=WukBaKhGUzRIFJebYdxtVqsmATXvcn[0:WukBaKhGUzRIFJebYdxtVqsmATXvcn.find('=')]
    WukBaKhGUzRIFJebYdxtVqsmATXvcO=WukBaKhGUzRIFJebYdxtVqsmATXvcn[WukBaKhGUzRIFJebYdxtVqsmATXvcn.find('=')+1:]
    WukBaKhGUzRIFJebYdxtVqsmATXvcN={'title':WukBaKhGUzRIFJebYdxtVqsmATXvcS['title_list'][0]['text'],'age':WukBaKhGUzRIFJebYdxtVqsmATXvcS['age'],'thumbnail':'https://%s'%WukBaKhGUzRIFJebYdxtVqsmATXvcS.get('thumbnail'),'videoid':WukBaKhGUzRIFJebYdxtVqsmATXvcO,'vidtype':WukBaKhGUzRIFJebYdxtVqsmATXvcp}
    if exclusion21==WukBaKhGUzRIFJebYdxtVqsmATXvgi or WukBaKhGUzRIFJebYdxtVqsmATXvcS.get('age')!='21':
     WukBaKhGUzRIFJebYdxtVqsmATXvHn.append(WukBaKhGUzRIFJebYdxtVqsmATXvcN)
   WukBaKhGUzRIFJebYdxtVqsmATXvcQ=WukBaKhGUzRIFJebYdxtVqsmATXvgr(WukBaKhGUzRIFJebYdxtVqsmATXvHD['cell_toplist']['pagecount'])
   if WukBaKhGUzRIFJebYdxtVqsmATXvHD['cell_toplist']['count']:WukBaKhGUzRIFJebYdxtVqsmATXvHo =WukBaKhGUzRIFJebYdxtVqsmATXvgr(WukBaKhGUzRIFJebYdxtVqsmATXvHD['cell_toplist']['count'])
   else:WukBaKhGUzRIFJebYdxtVqsmATXvHo=WukBaKhGUzRIFJebYdxtVqsmATXvog.LIST_LIMIT
   WukBaKhGUzRIFJebYdxtVqsmATXvcr=WukBaKhGUzRIFJebYdxtVqsmATXvcQ>WukBaKhGUzRIFJebYdxtVqsmATXvHo
  except WukBaKhGUzRIFJebYdxtVqsmATXvgl as exception:
   WukBaKhGUzRIFJebYdxtVqsmATXvgE(exception)
  return WukBaKhGUzRIFJebYdxtVqsmATXvHn,WukBaKhGUzRIFJebYdxtVqsmATXvcr 
 def GetStreamingURL(WukBaKhGUzRIFJebYdxtVqsmATXvog,mode,WukBaKhGUzRIFJebYdxtVqsmATXvHr,quality_int,pvrmode='-'):
  WukBaKhGUzRIFJebYdxtVqsmATXvHp=WukBaKhGUzRIFJebYdxtVqsmATXvgD=WukBaKhGUzRIFJebYdxtVqsmATXvgC=streaming_preview=''
  WukBaKhGUzRIFJebYdxtVqsmATXvHO=[]
  WukBaKhGUzRIFJebYdxtVqsmATXvgo='hls'
  if mode=='LIVE':
   WukBaKhGUzRIFJebYdxtVqsmATXvor =WukBaKhGUzRIFJebYdxtVqsmATXvog.API_DOMAIN+'/live/channels/'+WukBaKhGUzRIFJebYdxtVqsmATXvHr
   WukBaKhGUzRIFJebYdxtVqsmATXvgc='live'
  elif mode=='VOD':
   WukBaKhGUzRIFJebYdxtVqsmATXvor =WukBaKhGUzRIFJebYdxtVqsmATXvog.API_DOMAIN+'/cf/vod/contents/'+WukBaKhGUzRIFJebYdxtVqsmATXvHr
   WukBaKhGUzRIFJebYdxtVqsmATXvgc='vod'
  elif mode=='MOVIE':
   WukBaKhGUzRIFJebYdxtVqsmATXvor =WukBaKhGUzRIFJebYdxtVqsmATXvog.API_DOMAIN+'/cf/movie/contents/'+WukBaKhGUzRIFJebYdxtVqsmATXvHr
   WukBaKhGUzRIFJebYdxtVqsmATXvgc='movie'
  try:
   if mode!='LIVE' or pvrmode=='-':
    WukBaKhGUzRIFJebYdxtVqsmATXvoD=WukBaKhGUzRIFJebYdxtVqsmATXvog.GetDefaultParams(login=WukBaKhGUzRIFJebYdxtVqsmATXvgi)
    WukBaKhGUzRIFJebYdxtVqsmATXvon=WukBaKhGUzRIFJebYdxtVqsmATXvog.callRequestCookies('Get',WukBaKhGUzRIFJebYdxtVqsmATXvor,payload=WukBaKhGUzRIFJebYdxtVqsmATXvgN,params=WukBaKhGUzRIFJebYdxtVqsmATXvoD,headers=WukBaKhGUzRIFJebYdxtVqsmATXvgN,cookies=WukBaKhGUzRIFJebYdxtVqsmATXvgN)
    WukBaKhGUzRIFJebYdxtVqsmATXvop=json.loads(WukBaKhGUzRIFJebYdxtVqsmATXvon.text)
    WukBaKhGUzRIFJebYdxtVqsmATXvgH=WukBaKhGUzRIFJebYdxtVqsmATXvop['qualities']['list']
    if WukBaKhGUzRIFJebYdxtVqsmATXvgH==WukBaKhGUzRIFJebYdxtVqsmATXvgN:return(WukBaKhGUzRIFJebYdxtVqsmATXvHp,WukBaKhGUzRIFJebYdxtVqsmATXvgD,WukBaKhGUzRIFJebYdxtVqsmATXvgC,streaming_preview)
    for WukBaKhGUzRIFJebYdxtVqsmATXvgP in WukBaKhGUzRIFJebYdxtVqsmATXvgH:
     WukBaKhGUzRIFJebYdxtVqsmATXvHO.append(WukBaKhGUzRIFJebYdxtVqsmATXvgr(WukBaKhGUzRIFJebYdxtVqsmATXvgP.get('id').rstrip('p')))
    if 'type' in WukBaKhGUzRIFJebYdxtVqsmATXvop:
     if WukBaKhGUzRIFJebYdxtVqsmATXvop['type']=='onair':
      WukBaKhGUzRIFJebYdxtVqsmATXvgc='onairvod'
    if 'drms' in WukBaKhGUzRIFJebYdxtVqsmATXvop:
     if WukBaKhGUzRIFJebYdxtVqsmATXvop['drms']:
      WukBaKhGUzRIFJebYdxtVqsmATXvgo='dash'
  except WukBaKhGUzRIFJebYdxtVqsmATXvgl as exception:
   WukBaKhGUzRIFJebYdxtVqsmATXvgE(exception)
   return(WukBaKhGUzRIFJebYdxtVqsmATXvHp,WukBaKhGUzRIFJebYdxtVqsmATXvgD,WukBaKhGUzRIFJebYdxtVqsmATXvgC,streaming_preview)
  try:
   WukBaKhGUzRIFJebYdxtVqsmATXvgj=WukBaKhGUzRIFJebYdxtVqsmATXvog.CheckQuality(quality_int,WukBaKhGUzRIFJebYdxtVqsmATXvHO)
   if mode=='LIVE' and pvrmode!='-':
    WukBaKhGUzRIFJebYdxtVqsmATXvgL='auto'
   else:
    WukBaKhGUzRIFJebYdxtVqsmATXvgL=WukBaKhGUzRIFJebYdxtVqsmATXvgy(WukBaKhGUzRIFJebYdxtVqsmATXvgj)+'p'
   WukBaKhGUzRIFJebYdxtVqsmATXvor=WukBaKhGUzRIFJebYdxtVqsmATXvog.API_DOMAIN+'/streaming'
   WukBaKhGUzRIFJebYdxtVqsmATXvoD={'contentid':WukBaKhGUzRIFJebYdxtVqsmATXvHr,'contenttype':WukBaKhGUzRIFJebYdxtVqsmATXvgc,'action':WukBaKhGUzRIFJebYdxtVqsmATXvgo,'quality':WukBaKhGUzRIFJebYdxtVqsmATXvgL,'deviceModelId':'Windows 10','guid':WukBaKhGUzRIFJebYdxtVqsmATXvog.GetGUID(guidType=2),'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n'}
   WukBaKhGUzRIFJebYdxtVqsmATXvoD.update(WukBaKhGUzRIFJebYdxtVqsmATXvog.GetDefaultParams(login=WukBaKhGUzRIFJebYdxtVqsmATXvgw))
   WukBaKhGUzRIFJebYdxtVqsmATXvon=WukBaKhGUzRIFJebYdxtVqsmATXvog.callRequestCookies('Get',WukBaKhGUzRIFJebYdxtVqsmATXvor,payload=WukBaKhGUzRIFJebYdxtVqsmATXvgN,params=WukBaKhGUzRIFJebYdxtVqsmATXvoD,headers=WukBaKhGUzRIFJebYdxtVqsmATXvgN,cookies=WukBaKhGUzRIFJebYdxtVqsmATXvgN)
   WukBaKhGUzRIFJebYdxtVqsmATXvop=json.loads(WukBaKhGUzRIFJebYdxtVqsmATXvon.text)
   WukBaKhGUzRIFJebYdxtVqsmATXvHp=WukBaKhGUzRIFJebYdxtVqsmATXvop['playurl']
   if WukBaKhGUzRIFJebYdxtVqsmATXvHp==WukBaKhGUzRIFJebYdxtVqsmATXvgN:return(WukBaKhGUzRIFJebYdxtVqsmATXvHp,WukBaKhGUzRIFJebYdxtVqsmATXvgD,WukBaKhGUzRIFJebYdxtVqsmATXvgC,streaming_preview)
   WukBaKhGUzRIFJebYdxtVqsmATXvgD=WukBaKhGUzRIFJebYdxtVqsmATXvop['awscookie']
   WukBaKhGUzRIFJebYdxtVqsmATXvgC =WukBaKhGUzRIFJebYdxtVqsmATXvop['drm']
   if 'previewmsg' in WukBaKhGUzRIFJebYdxtVqsmATXvop['preview']:streaming_preview=WukBaKhGUzRIFJebYdxtVqsmATXvop['preview']['previewmsg']
  except WukBaKhGUzRIFJebYdxtVqsmATXvgl as exception:
   WukBaKhGUzRIFJebYdxtVqsmATXvgE(exception)
  return(WukBaKhGUzRIFJebYdxtVqsmATXvHp,WukBaKhGUzRIFJebYdxtVqsmATXvgD,WukBaKhGUzRIFJebYdxtVqsmATXvgC,streaming_preview) 
# Created by pyminifier (https://github.com/liftoff/pyminifier)
