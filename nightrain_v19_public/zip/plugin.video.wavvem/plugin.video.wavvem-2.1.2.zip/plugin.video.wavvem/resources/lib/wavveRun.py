__author__="NightRain"
DCBYVFjQyfdtazAemwhHJgWiNqULMk=object
DCBYVFjQyfdtazAemwhHJgWiNqULMv=None
DCBYVFjQyfdtazAemwhHJgWiNqULMT=int
DCBYVFjQyfdtazAemwhHJgWiNqULMK=False
DCBYVFjQyfdtazAemwhHJgWiNqULMr=True
DCBYVFjQyfdtazAemwhHJgWiNqULMS=len
DCBYVFjQyfdtazAemwhHJgWiNqULMG=open
DCBYVFjQyfdtazAemwhHJgWiNqULMX=dict
DCBYVFjQyfdtazAemwhHJgWiNqULMn=Exception
DCBYVFjQyfdtazAemwhHJgWiNqULEc=print
DCBYVFjQyfdtazAemwhHJgWiNqULEo=str
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
DCBYVFjQyfdtazAemwhHJgWiNqULcp=[{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://www.wavve.com/supermultisection/GN51'},{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&offset=0&limit=20&uicode=VN500','page':'1'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=01&WeekDay=all&uitype=VN4&uiparent=FN0&uirank=0&broadcastid=847243&uicode=VN4','page':'1'},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=02&WeekDay=all&uitype=VN3&uiparent=FN0&uirank=0&broadcastid=783664&uicode=VN3','page':'1'},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'1','sType':'vod','orderby':'new','ordernm':'최신순'},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'viewtime','ordernm':'인기순'},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순'},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'paid','ordernm':'인기순'},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'displaystart','ordernm':'업데이트순'},{'title':'검색 (search)','mode':'SEARCH_GROUP'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP'}]
DCBYVFjQyfdtazAemwhHJgWiNqULcl=[{'title':'VOD 검색','mode':'SEARCH_LIST','sType':'vod'},{'title':'영화 검색','mode':'SEARCH_LIST','sType':'movie'}]
DCBYVFjQyfdtazAemwhHJgWiNqULcM=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
DCBYVFjQyfdtazAemwhHJgWiNqULcE=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
from wavveCore import*
class DCBYVFjQyfdtazAemwhHJgWiNqULco(DCBYVFjQyfdtazAemwhHJgWiNqULMk):
 def __init__(DCBYVFjQyfdtazAemwhHJgWiNqULcx,DCBYVFjQyfdtazAemwhHJgWiNqULcu,DCBYVFjQyfdtazAemwhHJgWiNqULcb,DCBYVFjQyfdtazAemwhHJgWiNqULcI):
  DCBYVFjQyfdtazAemwhHJgWiNqULcx._addon_url =DCBYVFjQyfdtazAemwhHJgWiNqULcu
  DCBYVFjQyfdtazAemwhHJgWiNqULcx._addon_handle=DCBYVFjQyfdtazAemwhHJgWiNqULcb
  DCBYVFjQyfdtazAemwhHJgWiNqULcx.main_params =DCBYVFjQyfdtazAemwhHJgWiNqULcI
  DCBYVFjQyfdtazAemwhHJgWiNqULcx.WavveObj =lSOdjEKcHRQuvYpwkUPITznsAaobri() 
 def addon_noti(DCBYVFjQyfdtazAemwhHJgWiNqULcx,sting):
  try:
   DCBYVFjQyfdtazAemwhHJgWiNqULcR=xbmcgui.Dialog()
   DCBYVFjQyfdtazAemwhHJgWiNqULcR.notification(__addonname__,sting)
  except:
   DCBYVFjQyfdtazAemwhHJgWiNqULMv
 def addon_log(DCBYVFjQyfdtazAemwhHJgWiNqULcx,string):
  try:
   DCBYVFjQyfdtazAemwhHJgWiNqULcP=string.encode('utf-8','ignore')
  except:
   DCBYVFjQyfdtazAemwhHJgWiNqULcP='addonException: addon_log'
  DCBYVFjQyfdtazAemwhHJgWiNqULcO=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,DCBYVFjQyfdtazAemwhHJgWiNqULcP),level=DCBYVFjQyfdtazAemwhHJgWiNqULcO)
 def get_keyboard_input(DCBYVFjQyfdtazAemwhHJgWiNqULcx,DCBYVFjQyfdtazAemwhHJgWiNqULol):
  DCBYVFjQyfdtazAemwhHJgWiNqULck=DCBYVFjQyfdtazAemwhHJgWiNqULMv
  kb=xbmc.Keyboard()
  kb.setHeading(DCBYVFjQyfdtazAemwhHJgWiNqULol)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   DCBYVFjQyfdtazAemwhHJgWiNqULck=kb.getText()
  return DCBYVFjQyfdtazAemwhHJgWiNqULck
 def get_settings_login_info(DCBYVFjQyfdtazAemwhHJgWiNqULcx):
  DCBYVFjQyfdtazAemwhHJgWiNqULcv =__addon__.getSetting('id')
  DCBYVFjQyfdtazAemwhHJgWiNqULcT =__addon__.getSetting('pw')
  DCBYVFjQyfdtazAemwhHJgWiNqULcK=__addon__.getSetting('selected_profile')
  return(DCBYVFjQyfdtazAemwhHJgWiNqULcv,DCBYVFjQyfdtazAemwhHJgWiNqULcT,DCBYVFjQyfdtazAemwhHJgWiNqULcK)
 def get_selQuality(DCBYVFjQyfdtazAemwhHJgWiNqULcx):
  try:
   DCBYVFjQyfdtazAemwhHJgWiNqULcr=[1080,720,480,360]
   DCBYVFjQyfdtazAemwhHJgWiNqULcS=DCBYVFjQyfdtazAemwhHJgWiNqULMT(__addon__.getSetting('selected_quality'))
   return DCBYVFjQyfdtazAemwhHJgWiNqULcr[DCBYVFjQyfdtazAemwhHJgWiNqULcS]
  except:
   DCBYVFjQyfdtazAemwhHJgWiNqULMv
  return 1080 
 def get_settings_exclusion21(DCBYVFjQyfdtazAemwhHJgWiNqULcx):
  DCBYVFjQyfdtazAemwhHJgWiNqULcG =__addon__.getSetting('exclusion21')
  if DCBYVFjQyfdtazAemwhHJgWiNqULcG=='false':
   return DCBYVFjQyfdtazAemwhHJgWiNqULMK
  else:
   return DCBYVFjQyfdtazAemwhHJgWiNqULMr
 def get_settings_direct_replay(DCBYVFjQyfdtazAemwhHJgWiNqULcx):
  DCBYVFjQyfdtazAemwhHJgWiNqULcX=DCBYVFjQyfdtazAemwhHJgWiNqULMT(__addon__.getSetting('direct_replay'))
  if DCBYVFjQyfdtazAemwhHJgWiNqULcX==0:
   return DCBYVFjQyfdtazAemwhHJgWiNqULMK
  else:
   return DCBYVFjQyfdtazAemwhHJgWiNqULMr
 def get_settings_addinfo(DCBYVFjQyfdtazAemwhHJgWiNqULcx):
  DCBYVFjQyfdtazAemwhHJgWiNqULcn =__addon__.getSetting('add_infoyn')
  if DCBYVFjQyfdtazAemwhHJgWiNqULcn=='false':
   return DCBYVFjQyfdtazAemwhHJgWiNqULMK
  else:
   return DCBYVFjQyfdtazAemwhHJgWiNqULMr
 def set_winCredential(DCBYVFjQyfdtazAemwhHJgWiNqULcx,credential):
  DCBYVFjQyfdtazAemwhHJgWiNqULoc=xbmcgui.Window(10000)
  DCBYVFjQyfdtazAemwhHJgWiNqULoc.setProperty('WAVVE_M_CREDENTIAL',credential)
  DCBYVFjQyfdtazAemwhHJgWiNqULoc.setProperty('WAVVE_M_LOGINTIME',DCBYVFjQyfdtazAemwhHJgWiNqULcx.WavveObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(DCBYVFjQyfdtazAemwhHJgWiNqULcx):
  DCBYVFjQyfdtazAemwhHJgWiNqULoc=xbmcgui.Window(10000)
  return DCBYVFjQyfdtazAemwhHJgWiNqULoc.getProperty('WAVVE_M_CREDENTIAL')
 def set_winEpisodeOrderby(DCBYVFjQyfdtazAemwhHJgWiNqULcx,DCBYVFjQyfdtazAemwhHJgWiNqULor):
  DCBYVFjQyfdtazAemwhHJgWiNqULoc=xbmcgui.Window(10000)
  DCBYVFjQyfdtazAemwhHJgWiNqULoc.setProperty('WAVVE_M_ORDERBY',DCBYVFjQyfdtazAemwhHJgWiNqULor)
 def get_winEpisodeOrderby(DCBYVFjQyfdtazAemwhHJgWiNqULcx):
  DCBYVFjQyfdtazAemwhHJgWiNqULoc=xbmcgui.Window(10000)
  return DCBYVFjQyfdtazAemwhHJgWiNqULoc.getProperty('WAVVE_M_ORDERBY')
 def add_dir(DCBYVFjQyfdtazAemwhHJgWiNqULcx,label,sublabel='',img='',infoLabels=DCBYVFjQyfdtazAemwhHJgWiNqULMv,isFolder=DCBYVFjQyfdtazAemwhHJgWiNqULMr,params=''):
  DCBYVFjQyfdtazAemwhHJgWiNqULop='%s?%s'%(DCBYVFjQyfdtazAemwhHJgWiNqULcx._addon_url,urllib.parse.urlencode(params))
  if sublabel:DCBYVFjQyfdtazAemwhHJgWiNqULol='%s < %s >'%(label,sublabel)
  else: DCBYVFjQyfdtazAemwhHJgWiNqULol=label
  if not img:img='DefaultFolder.png'
  DCBYVFjQyfdtazAemwhHJgWiNqULoM=xbmcgui.ListItem(DCBYVFjQyfdtazAemwhHJgWiNqULol)
  DCBYVFjQyfdtazAemwhHJgWiNqULoM.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:DCBYVFjQyfdtazAemwhHJgWiNqULoM.setInfo(type="video",infoLabels=infoLabels)
  if not isFolder:DCBYVFjQyfdtazAemwhHJgWiNqULoM.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(DCBYVFjQyfdtazAemwhHJgWiNqULcx._addon_handle,DCBYVFjQyfdtazAemwhHJgWiNqULop,DCBYVFjQyfdtazAemwhHJgWiNqULoM,isFolder)
 def dp_Main_List(DCBYVFjQyfdtazAemwhHJgWiNqULcx):
  for DCBYVFjQyfdtazAemwhHJgWiNqULoE in DCBYVFjQyfdtazAemwhHJgWiNqULcp:
   DCBYVFjQyfdtazAemwhHJgWiNqULol=DCBYVFjQyfdtazAemwhHJgWiNqULoE.get('title')
   DCBYVFjQyfdtazAemwhHJgWiNqULox={'mode':DCBYVFjQyfdtazAemwhHJgWiNqULoE.get('mode'),'sCode':DCBYVFjQyfdtazAemwhHJgWiNqULoE.get('sCode'),'sIndex':DCBYVFjQyfdtazAemwhHJgWiNqULoE.get('sIndex'),'sType':DCBYVFjQyfdtazAemwhHJgWiNqULoE.get('sType'),'suburl':DCBYVFjQyfdtazAemwhHJgWiNqULoE.get('suburl'),'subapi':DCBYVFjQyfdtazAemwhHJgWiNqULoE.get('subapi'),'page':DCBYVFjQyfdtazAemwhHJgWiNqULoE.get('page'),'orderby':DCBYVFjQyfdtazAemwhHJgWiNqULoE.get('orderby'),'ordernm':DCBYVFjQyfdtazAemwhHJgWiNqULoE.get('ordernm')}
   if DCBYVFjQyfdtazAemwhHJgWiNqULoE.get('mode')=='XXX':
    DCBYVFjQyfdtazAemwhHJgWiNqULou=DCBYVFjQyfdtazAemwhHJgWiNqULMK
   else:
    DCBYVFjQyfdtazAemwhHJgWiNqULou=DCBYVFjQyfdtazAemwhHJgWiNqULMr
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.add_dir(DCBYVFjQyfdtazAemwhHJgWiNqULol,sublabel='',img='',infoLabels=DCBYVFjQyfdtazAemwhHJgWiNqULMv,isFolder=DCBYVFjQyfdtazAemwhHJgWiNqULou,params=DCBYVFjQyfdtazAemwhHJgWiNqULox)
  if DCBYVFjQyfdtazAemwhHJgWiNqULMS(DCBYVFjQyfdtazAemwhHJgWiNqULcp)>0:xbmcplugin.endOfDirectory(DCBYVFjQyfdtazAemwhHJgWiNqULcx._addon_handle,cacheToDisc=DCBYVFjQyfdtazAemwhHJgWiNqULMr)
 def dp_Search_Group(DCBYVFjQyfdtazAemwhHJgWiNqULcx,args):
  for DCBYVFjQyfdtazAemwhHJgWiNqULoI in DCBYVFjQyfdtazAemwhHJgWiNqULcl:
   DCBYVFjQyfdtazAemwhHJgWiNqULol=DCBYVFjQyfdtazAemwhHJgWiNqULoI.get('title')
   DCBYVFjQyfdtazAemwhHJgWiNqULox={'mode':DCBYVFjQyfdtazAemwhHJgWiNqULoI.get('mode'),'sType':DCBYVFjQyfdtazAemwhHJgWiNqULoI.get('sType'),'page':'1'}
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.add_dir(DCBYVFjQyfdtazAemwhHJgWiNqULol,sublabel='',img='',infoLabels=DCBYVFjQyfdtazAemwhHJgWiNqULMv,isFolder=DCBYVFjQyfdtazAemwhHJgWiNqULMr,params=DCBYVFjQyfdtazAemwhHJgWiNqULox)
  if DCBYVFjQyfdtazAemwhHJgWiNqULMS(DCBYVFjQyfdtazAemwhHJgWiNqULcl)>0:xbmcplugin.endOfDirectory(DCBYVFjQyfdtazAemwhHJgWiNqULcx._addon_handle,cacheToDisc=DCBYVFjQyfdtazAemwhHJgWiNqULMr)
 def dp_Watch_Group(DCBYVFjQyfdtazAemwhHJgWiNqULcx,args):
  for DCBYVFjQyfdtazAemwhHJgWiNqULos in DCBYVFjQyfdtazAemwhHJgWiNqULcM:
   DCBYVFjQyfdtazAemwhHJgWiNqULol=DCBYVFjQyfdtazAemwhHJgWiNqULos.get('title')
   DCBYVFjQyfdtazAemwhHJgWiNqULox={'mode':DCBYVFjQyfdtazAemwhHJgWiNqULos.get('mode'),'sType':DCBYVFjQyfdtazAemwhHJgWiNqULos.get('sType')}
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.add_dir(DCBYVFjQyfdtazAemwhHJgWiNqULol,sublabel='',img='',infoLabels=DCBYVFjQyfdtazAemwhHJgWiNqULMv,isFolder=DCBYVFjQyfdtazAemwhHJgWiNqULMr,params=DCBYVFjQyfdtazAemwhHJgWiNqULox)
  if DCBYVFjQyfdtazAemwhHJgWiNqULMS(DCBYVFjQyfdtazAemwhHJgWiNqULcM)>0:xbmcplugin.endOfDirectory(DCBYVFjQyfdtazAemwhHJgWiNqULcx._addon_handle,cacheToDisc=DCBYVFjQyfdtazAemwhHJgWiNqULMr)
 def login_main(DCBYVFjQyfdtazAemwhHJgWiNqULcx):
  (DCBYVFjQyfdtazAemwhHJgWiNqULoR,DCBYVFjQyfdtazAemwhHJgWiNqULoP,DCBYVFjQyfdtazAemwhHJgWiNqULoO)=DCBYVFjQyfdtazAemwhHJgWiNqULcx.get_settings_login_info()
  if not(DCBYVFjQyfdtazAemwhHJgWiNqULoR and DCBYVFjQyfdtazAemwhHJgWiNqULoP):
   DCBYVFjQyfdtazAemwhHJgWiNqULcR=xbmcgui.Dialog()
   DCBYVFjQyfdtazAemwhHJgWiNqULok=DCBYVFjQyfdtazAemwhHJgWiNqULcR.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if DCBYVFjQyfdtazAemwhHJgWiNqULok==DCBYVFjQyfdtazAemwhHJgWiNqULMr:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if DCBYVFjQyfdtazAemwhHJgWiNqULcx.get_winEpisodeOrderby()=='':
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.set_winEpisodeOrderby('desc')
  if DCBYVFjQyfdtazAemwhHJgWiNqULcx.cookiefile_check():return
  DCBYVFjQyfdtazAemwhHJgWiNqULov =DCBYVFjQyfdtazAemwhHJgWiNqULMT(DCBYVFjQyfdtazAemwhHJgWiNqULcx.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  DCBYVFjQyfdtazAemwhHJgWiNqULoT=xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINTIME')
  if DCBYVFjQyfdtazAemwhHJgWiNqULoT==DCBYVFjQyfdtazAemwhHJgWiNqULMv or DCBYVFjQyfdtazAemwhHJgWiNqULoT=='':
   DCBYVFjQyfdtazAemwhHJgWiNqULoT=DCBYVFjQyfdtazAemwhHJgWiNqULMT('19000101')
  else:
   DCBYVFjQyfdtazAemwhHJgWiNqULoT=DCBYVFjQyfdtazAemwhHJgWiNqULMT(re.sub('-','',DCBYVFjQyfdtazAemwhHJgWiNqULoT))
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   DCBYVFjQyfdtazAemwhHJgWiNqULoK=0
   while DCBYVFjQyfdtazAemwhHJgWiNqULMr:
    DCBYVFjQyfdtazAemwhHJgWiNqULoK+=1
    time.sleep(0.05)
    if DCBYVFjQyfdtazAemwhHJgWiNqULoT>=DCBYVFjQyfdtazAemwhHJgWiNqULov:return
    if DCBYVFjQyfdtazAemwhHJgWiNqULoK>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  if DCBYVFjQyfdtazAemwhHJgWiNqULoT>=DCBYVFjQyfdtazAemwhHJgWiNqULov:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   return
  if not DCBYVFjQyfdtazAemwhHJgWiNqULcx.WavveObj.GetCredential(DCBYVFjQyfdtazAemwhHJgWiNqULoR,DCBYVFjQyfdtazAemwhHJgWiNqULoP,DCBYVFjQyfdtazAemwhHJgWiNqULoO):
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   sys.exit()
  DCBYVFjQyfdtazAemwhHJgWiNqULcx.set_winCredential(DCBYVFjQyfdtazAemwhHJgWiNqULcx.WavveObj.LoadCredential())
  DCBYVFjQyfdtazAemwhHJgWiNqULcx.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
 def dp_setEpOrderby(DCBYVFjQyfdtazAemwhHJgWiNqULcx,args):
  DCBYVFjQyfdtazAemwhHJgWiNqULor =args.get('orderby')
  DCBYVFjQyfdtazAemwhHJgWiNqULcx.set_winEpisodeOrderby(DCBYVFjQyfdtazAemwhHJgWiNqULor)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(DCBYVFjQyfdtazAemwhHJgWiNqULcx,args):
  DCBYVFjQyfdtazAemwhHJgWiNqULcx.WavveObj.SaveCredential(DCBYVFjQyfdtazAemwhHJgWiNqULcx.get_winCredential())
  DCBYVFjQyfdtazAemwhHJgWiNqULoS =args.get('mode')
  DCBYVFjQyfdtazAemwhHJgWiNqULoG =args.get('contentid')
  DCBYVFjQyfdtazAemwhHJgWiNqULoX =args.get('pvrmode')
  DCBYVFjQyfdtazAemwhHJgWiNqULon=DCBYVFjQyfdtazAemwhHJgWiNqULcx.get_selQuality()
  DCBYVFjQyfdtazAemwhHJgWiNqULcx.addon_log(DCBYVFjQyfdtazAemwhHJgWiNqULoG+' - '+DCBYVFjQyfdtazAemwhHJgWiNqULoS)
  DCBYVFjQyfdtazAemwhHJgWiNqULpc,DCBYVFjQyfdtazAemwhHJgWiNqULpo,DCBYVFjQyfdtazAemwhHJgWiNqULpl,DCBYVFjQyfdtazAemwhHJgWiNqULpM=DCBYVFjQyfdtazAemwhHJgWiNqULcx.WavveObj.GetStreamingURL(DCBYVFjQyfdtazAemwhHJgWiNqULoS,DCBYVFjQyfdtazAemwhHJgWiNqULoG,DCBYVFjQyfdtazAemwhHJgWiNqULon,DCBYVFjQyfdtazAemwhHJgWiNqULoX)
  DCBYVFjQyfdtazAemwhHJgWiNqULpE='%s|Cookie=%s'%(DCBYVFjQyfdtazAemwhHJgWiNqULpc,DCBYVFjQyfdtazAemwhHJgWiNqULpo)
  DCBYVFjQyfdtazAemwhHJgWiNqULcx.addon_log(DCBYVFjQyfdtazAemwhHJgWiNqULpE)
  if DCBYVFjQyfdtazAemwhHJgWiNqULpc=='':
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.addon_noti(__language__(30907).encode('utf8'))
   return
  DCBYVFjQyfdtazAemwhHJgWiNqULpx=xbmcgui.ListItem(path=DCBYVFjQyfdtazAemwhHJgWiNqULpE)
  if DCBYVFjQyfdtazAemwhHJgWiNqULpl:
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.addon_log('!!streaming_drm!!')
   DCBYVFjQyfdtazAemwhHJgWiNqULpu=DCBYVFjQyfdtazAemwhHJgWiNqULpl['customdata']
   DCBYVFjQyfdtazAemwhHJgWiNqULpb =DCBYVFjQyfdtazAemwhHJgWiNqULpl['drmhost']
   DCBYVFjQyfdtazAemwhHJgWiNqULpI =inputstreamhelper.Helper('mpd',drm='widevine')
   if DCBYVFjQyfdtazAemwhHJgWiNqULpI.check_inputstream():
    if DCBYVFjQyfdtazAemwhHJgWiNqULoS=='MOVIE':
     DCBYVFjQyfdtazAemwhHJgWiNqULps='https://www.wavve.com/player/movie?movieid=%s'%DCBYVFjQyfdtazAemwhHJgWiNqULoG
    else:
     DCBYVFjQyfdtazAemwhHJgWiNqULps='https://www.wavve.com/player/vod?programid=%s&page=1'%DCBYVFjQyfdtazAemwhHJgWiNqULoG
    DCBYVFjQyfdtazAemwhHJgWiNqULpR={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':DCBYVFjQyfdtazAemwhHJgWiNqULpu,'referer':DCBYVFjQyfdtazAemwhHJgWiNqULps,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':DCBYVFjQyfdtazAemwhHJgWiNqULcx.WavveObj.USER_AGENT}
    DCBYVFjQyfdtazAemwhHJgWiNqULpP=DCBYVFjQyfdtazAemwhHJgWiNqULpb+'|'+urllib.parse.urlencode(DCBYVFjQyfdtazAemwhHJgWiNqULpR)+'|R{SSM}|'
    DCBYVFjQyfdtazAemwhHJgWiNqULpx.setProperty('inputstream',DCBYVFjQyfdtazAemwhHJgWiNqULpI.inputstream_addon)
    DCBYVFjQyfdtazAemwhHJgWiNqULpx.setProperty('inputstream.adaptive.manifest_type','mpd')
    DCBYVFjQyfdtazAemwhHJgWiNqULpx.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    DCBYVFjQyfdtazAemwhHJgWiNqULpx.setProperty('inputstream.adaptive.license_key',DCBYVFjQyfdtazAemwhHJgWiNqULpP)
    DCBYVFjQyfdtazAemwhHJgWiNqULpx.setProperty('inputstream.adaptive.stream_headers','user-agent=%s&Cookie=%s'%(DCBYVFjQyfdtazAemwhHJgWiNqULcx.WavveObj.USER_AGENT,DCBYVFjQyfdtazAemwhHJgWiNqULpo))
  xbmcplugin.setResolvedUrl(DCBYVFjQyfdtazAemwhHJgWiNqULcx._addon_handle,DCBYVFjQyfdtazAemwhHJgWiNqULMr,DCBYVFjQyfdtazAemwhHJgWiNqULpx)
  DCBYVFjQyfdtazAemwhHJgWiNqULpO=DCBYVFjQyfdtazAemwhHJgWiNqULMK
  if DCBYVFjQyfdtazAemwhHJgWiNqULpM:
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.addon_noti(DCBYVFjQyfdtazAemwhHJgWiNqULpM.encode('utf-8'))
   DCBYVFjQyfdtazAemwhHJgWiNqULpO=DCBYVFjQyfdtazAemwhHJgWiNqULMr
  else:
   if '/preview.' in urllib.parse.urlsplit(DCBYVFjQyfdtazAemwhHJgWiNqULpc).path:
    DCBYVFjQyfdtazAemwhHJgWiNqULcx.addon_noti(__language__(30908).encode('utf8'))
    DCBYVFjQyfdtazAemwhHJgWiNqULpO=DCBYVFjQyfdtazAemwhHJgWiNqULMr
  try:
   DCBYVFjQyfdtazAemwhHJgWiNqULpk=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and DCBYVFjQyfdtazAemwhHJgWiNqULpO==DCBYVFjQyfdtazAemwhHJgWiNqULMK and DCBYVFjQyfdtazAemwhHJgWiNqULpk!='-':
    DCBYVFjQyfdtazAemwhHJgWiNqULox={'code':DCBYVFjQyfdtazAemwhHJgWiNqULpk,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    DCBYVFjQyfdtazAemwhHJgWiNqULcx.Save_Watched_List(args.get('mode').lower(),DCBYVFjQyfdtazAemwhHJgWiNqULox)
  except:
   DCBYVFjQyfdtazAemwhHJgWiNqULMv
 def Load_Watched_List(DCBYVFjQyfdtazAemwhHJgWiNqULcx,DCBYVFjQyfdtazAemwhHJgWiNqULMb):
  try:
   DCBYVFjQyfdtazAemwhHJgWiNqULpv=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%DCBYVFjQyfdtazAemwhHJgWiNqULMb))
   fp=DCBYVFjQyfdtazAemwhHJgWiNqULMG(DCBYVFjQyfdtazAemwhHJgWiNqULpv,'r',-1,'utf-8')
   DCBYVFjQyfdtazAemwhHJgWiNqULpT=fp.readlines()
   fp.close()
  except:
   DCBYVFjQyfdtazAemwhHJgWiNqULpT=[]
  return DCBYVFjQyfdtazAemwhHJgWiNqULpT
 def Save_Watched_List(DCBYVFjQyfdtazAemwhHJgWiNqULcx,DCBYVFjQyfdtazAemwhHJgWiNqULMb,DCBYVFjQyfdtazAemwhHJgWiNqULcI):
  try:
   DCBYVFjQyfdtazAemwhHJgWiNqULpv=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%DCBYVFjQyfdtazAemwhHJgWiNqULMb))
   DCBYVFjQyfdtazAemwhHJgWiNqULpK=DCBYVFjQyfdtazAemwhHJgWiNqULcx.Load_Watched_List(DCBYVFjQyfdtazAemwhHJgWiNqULMb) 
   fp=DCBYVFjQyfdtazAemwhHJgWiNqULMG(DCBYVFjQyfdtazAemwhHJgWiNqULpv,'w',-1,'utf-8')
   DCBYVFjQyfdtazAemwhHJgWiNqULpr=urllib.parse.urlencode(DCBYVFjQyfdtazAemwhHJgWiNqULcI)
   DCBYVFjQyfdtazAemwhHJgWiNqULpr=DCBYVFjQyfdtazAemwhHJgWiNqULpr+'\n'
   fp.write(DCBYVFjQyfdtazAemwhHJgWiNqULpr)
   DCBYVFjQyfdtazAemwhHJgWiNqULpS=0
   for DCBYVFjQyfdtazAemwhHJgWiNqULpG in DCBYVFjQyfdtazAemwhHJgWiNqULpK:
    DCBYVFjQyfdtazAemwhHJgWiNqULpX=DCBYVFjQyfdtazAemwhHJgWiNqULMX(urllib.parse.parse_qsl(DCBYVFjQyfdtazAemwhHJgWiNqULpG))
    DCBYVFjQyfdtazAemwhHJgWiNqULpn=DCBYVFjQyfdtazAemwhHJgWiNqULcI.get('code').strip()
    DCBYVFjQyfdtazAemwhHJgWiNqULlc=DCBYVFjQyfdtazAemwhHJgWiNqULpX.get('code').strip()
    if DCBYVFjQyfdtazAemwhHJgWiNqULMb=='vod' and DCBYVFjQyfdtazAemwhHJgWiNqULcx.get_settings_direct_replay()==DCBYVFjQyfdtazAemwhHJgWiNqULMr:
     DCBYVFjQyfdtazAemwhHJgWiNqULpn=DCBYVFjQyfdtazAemwhHJgWiNqULcI.get('videoid').strip()
     DCBYVFjQyfdtazAemwhHJgWiNqULlc=DCBYVFjQyfdtazAemwhHJgWiNqULpX.get('videoid').strip()if DCBYVFjQyfdtazAemwhHJgWiNqULlc!=DCBYVFjQyfdtazAemwhHJgWiNqULMv else '-'
    if DCBYVFjQyfdtazAemwhHJgWiNqULpn!=DCBYVFjQyfdtazAemwhHJgWiNqULlc:
     fp.write(DCBYVFjQyfdtazAemwhHJgWiNqULpG)
     DCBYVFjQyfdtazAemwhHJgWiNqULpS+=1
     if DCBYVFjQyfdtazAemwhHJgWiNqULpS>=50:break
   fp.close()
  except:
   DCBYVFjQyfdtazAemwhHJgWiNqULMv
 def Delete_Watched_List(DCBYVFjQyfdtazAemwhHJgWiNqULcx,DCBYVFjQyfdtazAemwhHJgWiNqULMb):
  try:
   DCBYVFjQyfdtazAemwhHJgWiNqULpv=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%DCBYVFjQyfdtazAemwhHJgWiNqULMb))
   fp=DCBYVFjQyfdtazAemwhHJgWiNqULMG(DCBYVFjQyfdtazAemwhHJgWiNqULpv,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   DCBYVFjQyfdtazAemwhHJgWiNqULMv
 def dp_WatchList_Delete(DCBYVFjQyfdtazAemwhHJgWiNqULcx,args):
  DCBYVFjQyfdtazAemwhHJgWiNqULlo=args.get('sType')
  DCBYVFjQyfdtazAemwhHJgWiNqULcR=xbmcgui.Dialog()
  DCBYVFjQyfdtazAemwhHJgWiNqULok=DCBYVFjQyfdtazAemwhHJgWiNqULcR.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if DCBYVFjQyfdtazAemwhHJgWiNqULok==DCBYVFjQyfdtazAemwhHJgWiNqULMK:sys.exit()
  DCBYVFjQyfdtazAemwhHJgWiNqULcx.Delete_Watched_List(DCBYVFjQyfdtazAemwhHJgWiNqULlo)
  xbmc.executebuiltin("Container.Refresh")
 def logout(DCBYVFjQyfdtazAemwhHJgWiNqULcx):
  DCBYVFjQyfdtazAemwhHJgWiNqULcR=xbmcgui.Dialog()
  DCBYVFjQyfdtazAemwhHJgWiNqULok=DCBYVFjQyfdtazAemwhHJgWiNqULcR.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if DCBYVFjQyfdtazAemwhHJgWiNqULok==DCBYVFjQyfdtazAemwhHJgWiNqULMK:sys.exit()
  DCBYVFjQyfdtazAemwhHJgWiNqULcx.wininfo_clear()
  if os.path.isfile(DCBYVFjQyfdtazAemwhHJgWiNqULcE):os.remove(DCBYVFjQyfdtazAemwhHJgWiNqULcE)
  DCBYVFjQyfdtazAemwhHJgWiNqULcx.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(DCBYVFjQyfdtazAemwhHJgWiNqULcx):
  DCBYVFjQyfdtazAemwhHJgWiNqULoc=xbmcgui.Window(10000)
  DCBYVFjQyfdtazAemwhHJgWiNqULoc.setProperty('WAVVE_M_CREDENTIAL','')
  DCBYVFjQyfdtazAemwhHJgWiNqULoc.setProperty('WAVVE_M_LOGINTIME','')
 def cookiefile_save(DCBYVFjQyfdtazAemwhHJgWiNqULcx):
  DCBYVFjQyfdtazAemwhHJgWiNqULlp =DCBYVFjQyfdtazAemwhHJgWiNqULcx.WavveObj.Get_Now_Datetime()
  DCBYVFjQyfdtazAemwhHJgWiNqULlM=DCBYVFjQyfdtazAemwhHJgWiNqULlp+datetime.timedelta(days=DCBYVFjQyfdtazAemwhHJgWiNqULMT(__addon__.getSetting('cache_ttl')))
  DCBYVFjQyfdtazAemwhHJgWiNqULoc=xbmcgui.Window(10000)
  DCBYVFjQyfdtazAemwhHJgWiNqULlE={'wavve_token':DCBYVFjQyfdtazAemwhHJgWiNqULoc.getProperty('WAVVE_M_CREDENTIAL'),'wavve_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'wavve_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'wavve_profile':__addon__.getSetting('selected_profile'),'wavve_limitdate':DCBYVFjQyfdtazAemwhHJgWiNqULlM.strftime('%Y-%m-%d')}
  try: 
   fp=DCBYVFjQyfdtazAemwhHJgWiNqULMG(DCBYVFjQyfdtazAemwhHJgWiNqULcE,'w',-1,'utf-8')
   json.dump(DCBYVFjQyfdtazAemwhHJgWiNqULlE,fp)
   fp.close()
  except DCBYVFjQyfdtazAemwhHJgWiNqULMn as exception:
   DCBYVFjQyfdtazAemwhHJgWiNqULEc(exception)
 def cookiefile_check(DCBYVFjQyfdtazAemwhHJgWiNqULcx):
  DCBYVFjQyfdtazAemwhHJgWiNqULlE={}
  try: 
   fp=DCBYVFjQyfdtazAemwhHJgWiNqULMG(DCBYVFjQyfdtazAemwhHJgWiNqULcE,'r',-1,'utf-8')
   DCBYVFjQyfdtazAemwhHJgWiNqULlE= json.load(fp)
   fp.close()
  except DCBYVFjQyfdtazAemwhHJgWiNqULMn as exception:
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.wininfo_clear()
   return DCBYVFjQyfdtazAemwhHJgWiNqULMK
  DCBYVFjQyfdtazAemwhHJgWiNqULoR =__addon__.getSetting('id')
  DCBYVFjQyfdtazAemwhHJgWiNqULoP =__addon__.getSetting('pw')
  DCBYVFjQyfdtazAemwhHJgWiNqULlx =__addon__.getSetting('selected_profile')
  DCBYVFjQyfdtazAemwhHJgWiNqULlE['wavve_id']=base64.standard_b64decode(DCBYVFjQyfdtazAemwhHJgWiNqULlE['wavve_id']).decode('utf-8')
  DCBYVFjQyfdtazAemwhHJgWiNqULlE['wavve_pw']=base64.standard_b64decode(DCBYVFjQyfdtazAemwhHJgWiNqULlE['wavve_pw']).decode('utf-8')
  if DCBYVFjQyfdtazAemwhHJgWiNqULoR!=DCBYVFjQyfdtazAemwhHJgWiNqULlE['wavve_id']or DCBYVFjQyfdtazAemwhHJgWiNqULoP!=DCBYVFjQyfdtazAemwhHJgWiNqULlE['wavve_pw']or DCBYVFjQyfdtazAemwhHJgWiNqULlx!=DCBYVFjQyfdtazAemwhHJgWiNqULlE['wavve_profile']:
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.wininfo_clear()
   return DCBYVFjQyfdtazAemwhHJgWiNqULMK
  DCBYVFjQyfdtazAemwhHJgWiNqULov =DCBYVFjQyfdtazAemwhHJgWiNqULMT(DCBYVFjQyfdtazAemwhHJgWiNqULcx.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  DCBYVFjQyfdtazAemwhHJgWiNqULlu=DCBYVFjQyfdtazAemwhHJgWiNqULlE['wavve_limitdate']
  DCBYVFjQyfdtazAemwhHJgWiNqULoT =DCBYVFjQyfdtazAemwhHJgWiNqULMT(re.sub('-','',DCBYVFjQyfdtazAemwhHJgWiNqULlu))
  if DCBYVFjQyfdtazAemwhHJgWiNqULoT<DCBYVFjQyfdtazAemwhHJgWiNqULov:
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.wininfo_clear()
   return DCBYVFjQyfdtazAemwhHJgWiNqULMK
  DCBYVFjQyfdtazAemwhHJgWiNqULoc=xbmcgui.Window(10000)
  DCBYVFjQyfdtazAemwhHJgWiNqULoc.setProperty('WAVVE_M_CREDENTIAL',DCBYVFjQyfdtazAemwhHJgWiNqULlE['wavve_token'])
  DCBYVFjQyfdtazAemwhHJgWiNqULoc.setProperty('WAVVE_M_LOGINTIME',DCBYVFjQyfdtazAemwhHJgWiNqULlu)
  return DCBYVFjQyfdtazAemwhHJgWiNqULMr
 def dp_LiveCatagory_List(DCBYVFjQyfdtazAemwhHJgWiNqULcx,args):
  DCBYVFjQyfdtazAemwhHJgWiNqULcx.WavveObj.SaveCredential(DCBYVFjQyfdtazAemwhHJgWiNqULcx.get_winCredential())
  DCBYVFjQyfdtazAemwhHJgWiNqULlb =args.get('sCode')
  DCBYVFjQyfdtazAemwhHJgWiNqULlI=args.get('sIndex')
  DCBYVFjQyfdtazAemwhHJgWiNqULls,DCBYVFjQyfdtazAemwhHJgWiNqULlR=DCBYVFjQyfdtazAemwhHJgWiNqULcx.WavveObj.Get_LiveCatagory_List(DCBYVFjQyfdtazAemwhHJgWiNqULlb,DCBYVFjQyfdtazAemwhHJgWiNqULlI)
  for DCBYVFjQyfdtazAemwhHJgWiNqULlP in DCBYVFjQyfdtazAemwhHJgWiNqULls:
   DCBYVFjQyfdtazAemwhHJgWiNqULol =DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('title')
   DCBYVFjQyfdtazAemwhHJgWiNqULox={'mode':'LIVE_LIST','genre':DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('genre'),'baseapi':DCBYVFjQyfdtazAemwhHJgWiNqULlR}
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.add_dir(DCBYVFjQyfdtazAemwhHJgWiNqULol,sublabel='',img='',infoLabels=DCBYVFjQyfdtazAemwhHJgWiNqULMv,isFolder=DCBYVFjQyfdtazAemwhHJgWiNqULMr,params=DCBYVFjQyfdtazAemwhHJgWiNqULox)
  if DCBYVFjQyfdtazAemwhHJgWiNqULMS(DCBYVFjQyfdtazAemwhHJgWiNqULls)>0:xbmcplugin.endOfDirectory(DCBYVFjQyfdtazAemwhHJgWiNqULcx._addon_handle,cacheToDisc=DCBYVFjQyfdtazAemwhHJgWiNqULMK)
 def dp_MainCatagory_List(DCBYVFjQyfdtazAemwhHJgWiNqULcx,args):
  DCBYVFjQyfdtazAemwhHJgWiNqULcx.WavveObj.SaveCredential(DCBYVFjQyfdtazAemwhHJgWiNqULcx.get_winCredential())
  DCBYVFjQyfdtazAemwhHJgWiNqULlb =args.get('sCode')
  DCBYVFjQyfdtazAemwhHJgWiNqULlI=args.get('sIndex')
  DCBYVFjQyfdtazAemwhHJgWiNqULlo =args.get('sType')
  DCBYVFjQyfdtazAemwhHJgWiNqULls=DCBYVFjQyfdtazAemwhHJgWiNqULcx.WavveObj.Get_MainCatagory_List(DCBYVFjQyfdtazAemwhHJgWiNqULlb,DCBYVFjQyfdtazAemwhHJgWiNqULlI)
  for DCBYVFjQyfdtazAemwhHJgWiNqULlP in DCBYVFjQyfdtazAemwhHJgWiNqULls:
   if DCBYVFjQyfdtazAemwhHJgWiNqULlo=='vod':
    if DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('subtype')=='catagory':
     DCBYVFjQyfdtazAemwhHJgWiNqULoS='PROGRAM_LIST'
    else:
     DCBYVFjQyfdtazAemwhHJgWiNqULoS='SUPERSECTION_LIST'
   elif DCBYVFjQyfdtazAemwhHJgWiNqULlo=='movie':
    DCBYVFjQyfdtazAemwhHJgWiNqULoS='MOVIE_LIST'
   else:
    DCBYVFjQyfdtazAemwhHJgWiNqULoS=''
   DCBYVFjQyfdtazAemwhHJgWiNqULol='%s (%s)'%(DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('title'),args.get('ordernm'))
   DCBYVFjQyfdtazAemwhHJgWiNqULox={'mode':DCBYVFjQyfdtazAemwhHJgWiNqULoS,'suburl':DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('suburl'),'subapi':DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if DCBYVFjQyfdtazAemwhHJgWiNqULcx.get_settings_exclusion21():
    if DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('title')=='성인' or DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('title')=='성인+':continue
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.add_dir(DCBYVFjQyfdtazAemwhHJgWiNqULol,sublabel='',img='',infoLabels=DCBYVFjQyfdtazAemwhHJgWiNqULMv,isFolder=DCBYVFjQyfdtazAemwhHJgWiNqULMr,params=DCBYVFjQyfdtazAemwhHJgWiNqULox)
  if DCBYVFjQyfdtazAemwhHJgWiNqULMS(DCBYVFjQyfdtazAemwhHJgWiNqULls)>0:xbmcplugin.endOfDirectory(DCBYVFjQyfdtazAemwhHJgWiNqULcx._addon_handle,cacheToDisc=DCBYVFjQyfdtazAemwhHJgWiNqULMK)
 def dp_Program_List(DCBYVFjQyfdtazAemwhHJgWiNqULcx,args):
  DCBYVFjQyfdtazAemwhHJgWiNqULcx.WavveObj.SaveCredential(DCBYVFjQyfdtazAemwhHJgWiNqULcx.get_winCredential())
  DCBYVFjQyfdtazAemwhHJgWiNqULlO =args.get('subapi')
  DCBYVFjQyfdtazAemwhHJgWiNqULlk=DCBYVFjQyfdtazAemwhHJgWiNqULMT(args.get('page'))
  DCBYVFjQyfdtazAemwhHJgWiNqULor =args.get('orderby')
  DCBYVFjQyfdtazAemwhHJgWiNqULls,DCBYVFjQyfdtazAemwhHJgWiNqULlv=DCBYVFjQyfdtazAemwhHJgWiNqULcx.WavveObj.Get_Program_List(DCBYVFjQyfdtazAemwhHJgWiNqULlO,DCBYVFjQyfdtazAemwhHJgWiNqULlk,DCBYVFjQyfdtazAemwhHJgWiNqULor)
  for DCBYVFjQyfdtazAemwhHJgWiNqULlP in DCBYVFjQyfdtazAemwhHJgWiNqULls:
   DCBYVFjQyfdtazAemwhHJgWiNqULol =DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('title')
   DCBYVFjQyfdtazAemwhHJgWiNqULlT=DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('thumbnail')
   DCBYVFjQyfdtazAemwhHJgWiNqULlK =DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('age')
   if DCBYVFjQyfdtazAemwhHJgWiNqULlK=='18' or DCBYVFjQyfdtazAemwhHJgWiNqULlK=='19' or DCBYVFjQyfdtazAemwhHJgWiNqULlK=='21':DCBYVFjQyfdtazAemwhHJgWiNqULol+=' (%s)'%(DCBYVFjQyfdtazAemwhHJgWiNqULlK)
   DCBYVFjQyfdtazAemwhHJgWiNqULlr={'plot':DCBYVFjQyfdtazAemwhHJgWiNqULol,'mpaa':DCBYVFjQyfdtazAemwhHJgWiNqULlK,'mediatype':'episode'}
   DCBYVFjQyfdtazAemwhHJgWiNqULox={'mode':'EPISODE_LIST','videoid':DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('videoid'),'vidtype':DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('vidtype'),'page':'1'}
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.add_dir(DCBYVFjQyfdtazAemwhHJgWiNqULol,sublabel='',img=DCBYVFjQyfdtazAemwhHJgWiNqULlT,infoLabels=DCBYVFjQyfdtazAemwhHJgWiNqULlr,isFolder=DCBYVFjQyfdtazAemwhHJgWiNqULMr,params=DCBYVFjQyfdtazAemwhHJgWiNqULox)
  if DCBYVFjQyfdtazAemwhHJgWiNqULlv:
   DCBYVFjQyfdtazAemwhHJgWiNqULox={}
   DCBYVFjQyfdtazAemwhHJgWiNqULox['mode'] ='PROGRAM_LIST' 
   DCBYVFjQyfdtazAemwhHJgWiNqULox['subapi']=DCBYVFjQyfdtazAemwhHJgWiNqULlO 
   DCBYVFjQyfdtazAemwhHJgWiNqULox['page'] =DCBYVFjQyfdtazAemwhHJgWiNqULEo(DCBYVFjQyfdtazAemwhHJgWiNqULlk+1)
   DCBYVFjQyfdtazAemwhHJgWiNqULol='[B]%s >>[/B]'%'다음 페이지'
   DCBYVFjQyfdtazAemwhHJgWiNqULlS=DCBYVFjQyfdtazAemwhHJgWiNqULEo(DCBYVFjQyfdtazAemwhHJgWiNqULlk+1)
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.add_dir(DCBYVFjQyfdtazAemwhHJgWiNqULol,sublabel=DCBYVFjQyfdtazAemwhHJgWiNqULlS,img='',infoLabels=DCBYVFjQyfdtazAemwhHJgWiNqULMv,isFolder=DCBYVFjQyfdtazAemwhHJgWiNqULMr,params=DCBYVFjQyfdtazAemwhHJgWiNqULox)
  if DCBYVFjQyfdtazAemwhHJgWiNqULMS(DCBYVFjQyfdtazAemwhHJgWiNqULls)>0:xbmcplugin.endOfDirectory(DCBYVFjQyfdtazAemwhHJgWiNqULcx._addon_handle,cacheToDisc=DCBYVFjQyfdtazAemwhHJgWiNqULMK)
 def dp_SuperSection_List(DCBYVFjQyfdtazAemwhHJgWiNqULcx,args):
  DCBYVFjQyfdtazAemwhHJgWiNqULcx.WavveObj.SaveCredential(DCBYVFjQyfdtazAemwhHJgWiNqULcx.get_winCredential())
  DCBYVFjQyfdtazAemwhHJgWiNqULlG =args.get('suburl')
  DCBYVFjQyfdtazAemwhHJgWiNqULls=DCBYVFjQyfdtazAemwhHJgWiNqULcx.WavveObj.Get_SuperMultiSection_List(DCBYVFjQyfdtazAemwhHJgWiNqULlG)
  for DCBYVFjQyfdtazAemwhHJgWiNqULlP in DCBYVFjQyfdtazAemwhHJgWiNqULls:
   DCBYVFjQyfdtazAemwhHJgWiNqULol =DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('title')
   DCBYVFjQyfdtazAemwhHJgWiNqULlO =DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('subapi')
   DCBYVFjQyfdtazAemwhHJgWiNqULlX=DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('cell_type')
   if DCBYVFjQyfdtazAemwhHJgWiNqULlO.find('mtype=svod')>=0 or DCBYVFjQyfdtazAemwhHJgWiNqULlO.find('mtype=ppv')>=0:
    DCBYVFjQyfdtazAemwhHJgWiNqULoS='MOVIE_LIST'
   elif DCBYVFjQyfdtazAemwhHJgWiNqULlX=='band_71':
    DCBYVFjQyfdtazAemwhHJgWiNqULoS ='SUPERSECTION_LIST'
    (DCBYVFjQyfdtazAemwhHJgWiNqULln,DCBYVFjQyfdtazAemwhHJgWiNqULMc)=DCBYVFjQyfdtazAemwhHJgWiNqULcx.WavveObj.Baseapi_Parse(DCBYVFjQyfdtazAemwhHJgWiNqULlO)
    DCBYVFjQyfdtazAemwhHJgWiNqULlG=DCBYVFjQyfdtazAemwhHJgWiNqULMc.get('api')
    DCBYVFjQyfdtazAemwhHJgWiNqULlO=''
   elif DCBYVFjQyfdtazAemwhHJgWiNqULlX=='band_2':
    DCBYVFjQyfdtazAemwhHJgWiNqULoS='BAND2SECTION_LIST'
   elif DCBYVFjQyfdtazAemwhHJgWiNqULlX=='band_live':
    DCBYVFjQyfdtazAemwhHJgWiNqULoS='BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}',DCBYVFjQyfdtazAemwhHJgWiNqULlO):
    DCBYVFjQyfdtazAemwhHJgWiNqULoS='MOVIE_LIST'
   else:
    DCBYVFjQyfdtazAemwhHJgWiNqULoS='PROGRAM_LIST'
   DCBYVFjQyfdtazAemwhHJgWiNqULlr={'plot':DCBYVFjQyfdtazAemwhHJgWiNqULol,'mediatype':'episode'}
   DCBYVFjQyfdtazAemwhHJgWiNqULox={'mode':DCBYVFjQyfdtazAemwhHJgWiNqULoS,'suburl':DCBYVFjQyfdtazAemwhHJgWiNqULlG,'subapi':DCBYVFjQyfdtazAemwhHJgWiNqULlO,'page':'1'}
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.add_dir(DCBYVFjQyfdtazAemwhHJgWiNqULol,sublabel='',img=DCBYVFjQyfdtazAemwhHJgWiNqULMv,infoLabels=DCBYVFjQyfdtazAemwhHJgWiNqULlr,isFolder=DCBYVFjQyfdtazAemwhHJgWiNqULMr,params=DCBYVFjQyfdtazAemwhHJgWiNqULox)
  if DCBYVFjQyfdtazAemwhHJgWiNqULMS(DCBYVFjQyfdtazAemwhHJgWiNqULls)>0:xbmcplugin.endOfDirectory(DCBYVFjQyfdtazAemwhHJgWiNqULcx._addon_handle,cacheToDisc=DCBYVFjQyfdtazAemwhHJgWiNqULMK)
 def dp_BandLiveSection_List(DCBYVFjQyfdtazAemwhHJgWiNqULcx,args):
  DCBYVFjQyfdtazAemwhHJgWiNqULcx.WavveObj.SaveCredential(DCBYVFjQyfdtazAemwhHJgWiNqULcx.get_winCredential())
  DCBYVFjQyfdtazAemwhHJgWiNqULlO =args.get('subapi')
  DCBYVFjQyfdtazAemwhHJgWiNqULlk=DCBYVFjQyfdtazAemwhHJgWiNqULMT(args.get('page'))
  DCBYVFjQyfdtazAemwhHJgWiNqULls,DCBYVFjQyfdtazAemwhHJgWiNqULlv=DCBYVFjQyfdtazAemwhHJgWiNqULcx.WavveObj.Get_BandLiveSection_List(DCBYVFjQyfdtazAemwhHJgWiNqULlO,DCBYVFjQyfdtazAemwhHJgWiNqULlk)
  for DCBYVFjQyfdtazAemwhHJgWiNqULlP in DCBYVFjQyfdtazAemwhHJgWiNqULls:
   DCBYVFjQyfdtazAemwhHJgWiNqULMo =DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('channelid')
   DCBYVFjQyfdtazAemwhHJgWiNqULMp =DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('studio')
   DCBYVFjQyfdtazAemwhHJgWiNqULMl=DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('tvshowtitle')
   DCBYVFjQyfdtazAemwhHJgWiNqULlT =DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('thumbnail')
   DCBYVFjQyfdtazAemwhHJgWiNqULlK =DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('age')
   DCBYVFjQyfdtazAemwhHJgWiNqULlr={'mediatype':'video','mpaa':DCBYVFjQyfdtazAemwhHJgWiNqULlK,'title':'%s < %s >'%(DCBYVFjQyfdtazAemwhHJgWiNqULMp,DCBYVFjQyfdtazAemwhHJgWiNqULMl),'tvshowtitle':DCBYVFjQyfdtazAemwhHJgWiNqULMl,'studio':DCBYVFjQyfdtazAemwhHJgWiNqULMp,'plot':DCBYVFjQyfdtazAemwhHJgWiNqULMp}
   DCBYVFjQyfdtazAemwhHJgWiNqULox={'mode':'LIVE','contentid':DCBYVFjQyfdtazAemwhHJgWiNqULMo}
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.add_dir(DCBYVFjQyfdtazAemwhHJgWiNqULMp,sublabel=DCBYVFjQyfdtazAemwhHJgWiNqULMl,img=DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('thumbnail'),infoLabels=DCBYVFjQyfdtazAemwhHJgWiNqULlr,isFolder=DCBYVFjQyfdtazAemwhHJgWiNqULMK,params=DCBYVFjQyfdtazAemwhHJgWiNqULox)
  if DCBYVFjQyfdtazAemwhHJgWiNqULlv:
   DCBYVFjQyfdtazAemwhHJgWiNqULox={}
   DCBYVFjQyfdtazAemwhHJgWiNqULox['mode'] ='BANDLIVESECTION_LIST' 
   DCBYVFjQyfdtazAemwhHJgWiNqULox['subapi']=DCBYVFjQyfdtazAemwhHJgWiNqULlO
   DCBYVFjQyfdtazAemwhHJgWiNqULox['page'] =DCBYVFjQyfdtazAemwhHJgWiNqULEo(DCBYVFjQyfdtazAemwhHJgWiNqULlk+1)
   DCBYVFjQyfdtazAemwhHJgWiNqULol='[B]%s >>[/B]'%'다음 페이지'
   DCBYVFjQyfdtazAemwhHJgWiNqULlS=DCBYVFjQyfdtazAemwhHJgWiNqULEo(DCBYVFjQyfdtazAemwhHJgWiNqULlk+1)
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.add_dir(DCBYVFjQyfdtazAemwhHJgWiNqULol,sublabel=DCBYVFjQyfdtazAemwhHJgWiNqULlS,img='',infoLabels=DCBYVFjQyfdtazAemwhHJgWiNqULMv,isFolder=DCBYVFjQyfdtazAemwhHJgWiNqULMr,params=DCBYVFjQyfdtazAemwhHJgWiNqULox)
  if DCBYVFjQyfdtazAemwhHJgWiNqULMS(DCBYVFjQyfdtazAemwhHJgWiNqULls)>0:xbmcplugin.endOfDirectory(DCBYVFjQyfdtazAemwhHJgWiNqULcx._addon_handle,cacheToDisc=DCBYVFjQyfdtazAemwhHJgWiNqULMK)
 def dp_Band2Section_List(DCBYVFjQyfdtazAemwhHJgWiNqULcx,args):
  DCBYVFjQyfdtazAemwhHJgWiNqULcx.WavveObj.SaveCredential(DCBYVFjQyfdtazAemwhHJgWiNqULcx.get_winCredential())
  DCBYVFjQyfdtazAemwhHJgWiNqULlO =args.get('subapi')
  DCBYVFjQyfdtazAemwhHJgWiNqULlk=DCBYVFjQyfdtazAemwhHJgWiNqULMT(args.get('page'))
  DCBYVFjQyfdtazAemwhHJgWiNqULls,DCBYVFjQyfdtazAemwhHJgWiNqULlv=DCBYVFjQyfdtazAemwhHJgWiNqULcx.WavveObj.Get_Band2Section_List(DCBYVFjQyfdtazAemwhHJgWiNqULlO,DCBYVFjQyfdtazAemwhHJgWiNqULlk)
  for DCBYVFjQyfdtazAemwhHJgWiNqULlP in DCBYVFjQyfdtazAemwhHJgWiNqULls:
   DCBYVFjQyfdtazAemwhHJgWiNqULol =DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('programtitle')
   DCBYVFjQyfdtazAemwhHJgWiNqULlS =DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('episodetitle')
   DCBYVFjQyfdtazAemwhHJgWiNqULlr={'plot':DCBYVFjQyfdtazAemwhHJgWiNqULol+'\n\n'+DCBYVFjQyfdtazAemwhHJgWiNqULlS,'mpaa':DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('age'),'mediatype':'episode'}
   DCBYVFjQyfdtazAemwhHJgWiNqULox={'mode':'VOD','programid':'-','contentid':DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('videoid'),'thumbnail':DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('thumbnail'),'title':DCBYVFjQyfdtazAemwhHJgWiNqULol,'subtitle':DCBYVFjQyfdtazAemwhHJgWiNqULlS}
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.add_dir(DCBYVFjQyfdtazAemwhHJgWiNqULol,sublabel=DCBYVFjQyfdtazAemwhHJgWiNqULlS,img=DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('thumbnail'),infoLabels=DCBYVFjQyfdtazAemwhHJgWiNqULlr,isFolder=DCBYVFjQyfdtazAemwhHJgWiNqULMK,params=DCBYVFjQyfdtazAemwhHJgWiNqULox)
  if DCBYVFjQyfdtazAemwhHJgWiNqULlv:
   DCBYVFjQyfdtazAemwhHJgWiNqULox={}
   DCBYVFjQyfdtazAemwhHJgWiNqULox['mode'] ='BAND2SECTION_LIST' 
   DCBYVFjQyfdtazAemwhHJgWiNqULox['subapi']=DCBYVFjQyfdtazAemwhHJgWiNqULlO
   DCBYVFjQyfdtazAemwhHJgWiNqULox['page'] =DCBYVFjQyfdtazAemwhHJgWiNqULEo(DCBYVFjQyfdtazAemwhHJgWiNqULlk+1)
   DCBYVFjQyfdtazAemwhHJgWiNqULol='[B]%s >>[/B]'%'다음 페이지'
   DCBYVFjQyfdtazAemwhHJgWiNqULlS=DCBYVFjQyfdtazAemwhHJgWiNqULEo(DCBYVFjQyfdtazAemwhHJgWiNqULlk+1)
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.add_dir(DCBYVFjQyfdtazAemwhHJgWiNqULol,sublabel=DCBYVFjQyfdtazAemwhHJgWiNqULlS,img='',infoLabels=DCBYVFjQyfdtazAemwhHJgWiNqULMv,isFolder=DCBYVFjQyfdtazAemwhHJgWiNqULMr,params=DCBYVFjQyfdtazAemwhHJgWiNqULox)
  if DCBYVFjQyfdtazAemwhHJgWiNqULMS(DCBYVFjQyfdtazAemwhHJgWiNqULls)>0:xbmcplugin.endOfDirectory(DCBYVFjQyfdtazAemwhHJgWiNqULcx._addon_handle,cacheToDisc=DCBYVFjQyfdtazAemwhHJgWiNqULMK)
 def dp_Movie_List(DCBYVFjQyfdtazAemwhHJgWiNqULcx,args):
  DCBYVFjQyfdtazAemwhHJgWiNqULcx.WavveObj.SaveCredential(DCBYVFjQyfdtazAemwhHJgWiNqULcx.get_winCredential())
  DCBYVFjQyfdtazAemwhHJgWiNqULlO =args.get('subapi')
  DCBYVFjQyfdtazAemwhHJgWiNqULlk=DCBYVFjQyfdtazAemwhHJgWiNqULMT(args.get('page'))
  DCBYVFjQyfdtazAemwhHJgWiNqULls,DCBYVFjQyfdtazAemwhHJgWiNqULlv=DCBYVFjQyfdtazAemwhHJgWiNqULcx.WavveObj.Get_Movie_List(DCBYVFjQyfdtazAemwhHJgWiNqULlO,DCBYVFjQyfdtazAemwhHJgWiNqULlk)
  for DCBYVFjQyfdtazAemwhHJgWiNqULlP in DCBYVFjQyfdtazAemwhHJgWiNqULls:
   DCBYVFjQyfdtazAemwhHJgWiNqULol =DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('title')
   DCBYVFjQyfdtazAemwhHJgWiNqULlT=DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('thumbnail')
   DCBYVFjQyfdtazAemwhHJgWiNqULlK =DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('age')
   if DCBYVFjQyfdtazAemwhHJgWiNqULlK=='18' or DCBYVFjQyfdtazAemwhHJgWiNqULlK=='19' or DCBYVFjQyfdtazAemwhHJgWiNqULlK=='21':DCBYVFjQyfdtazAemwhHJgWiNqULol+=' (%s)'%(DCBYVFjQyfdtazAemwhHJgWiNqULlK)
   DCBYVFjQyfdtazAemwhHJgWiNqULlr={'plot':DCBYVFjQyfdtazAemwhHJgWiNqULol,'mpaa':DCBYVFjQyfdtazAemwhHJgWiNqULlK,'mediatype':'movie'}
   DCBYVFjQyfdtazAemwhHJgWiNqULox={'mode':'MOVIE','contentid':DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('videoid'),'title':DCBYVFjQyfdtazAemwhHJgWiNqULol,'thumbnail':DCBYVFjQyfdtazAemwhHJgWiNqULlT,'age':DCBYVFjQyfdtazAemwhHJgWiNqULlK}
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.add_dir(DCBYVFjQyfdtazAemwhHJgWiNqULol,sublabel='',img=DCBYVFjQyfdtazAemwhHJgWiNqULlT,infoLabels=DCBYVFjQyfdtazAemwhHJgWiNqULlr,isFolder=DCBYVFjQyfdtazAemwhHJgWiNqULMK,params=DCBYVFjQyfdtazAemwhHJgWiNqULox)
  if DCBYVFjQyfdtazAemwhHJgWiNqULlv:
   DCBYVFjQyfdtazAemwhHJgWiNqULox={}
   DCBYVFjQyfdtazAemwhHJgWiNqULox['mode'] ='MOVIE_LIST' 
   DCBYVFjQyfdtazAemwhHJgWiNqULox['subapi']=DCBYVFjQyfdtazAemwhHJgWiNqULlO 
   DCBYVFjQyfdtazAemwhHJgWiNqULox['page'] =DCBYVFjQyfdtazAemwhHJgWiNqULEo(DCBYVFjQyfdtazAemwhHJgWiNqULlk+1)
   DCBYVFjQyfdtazAemwhHJgWiNqULol='[B]%s >>[/B]'%'다음 페이지'
   DCBYVFjQyfdtazAemwhHJgWiNqULlS=DCBYVFjQyfdtazAemwhHJgWiNqULEo(DCBYVFjQyfdtazAemwhHJgWiNqULlk+1)
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.add_dir(DCBYVFjQyfdtazAemwhHJgWiNqULol,sublabel=DCBYVFjQyfdtazAemwhHJgWiNqULlS,img='',infoLabels=DCBYVFjQyfdtazAemwhHJgWiNqULMv,isFolder=DCBYVFjQyfdtazAemwhHJgWiNqULMr,params=DCBYVFjQyfdtazAemwhHJgWiNqULox)
  if DCBYVFjQyfdtazAemwhHJgWiNqULMS(DCBYVFjQyfdtazAemwhHJgWiNqULls)>0:xbmcplugin.endOfDirectory(DCBYVFjQyfdtazAemwhHJgWiNqULcx._addon_handle,cacheToDisc=DCBYVFjQyfdtazAemwhHJgWiNqULMK)
 def dp_Episode_List(DCBYVFjQyfdtazAemwhHJgWiNqULcx,args):
  DCBYVFjQyfdtazAemwhHJgWiNqULcx.WavveObj.SaveCredential(DCBYVFjQyfdtazAemwhHJgWiNqULcx.get_winCredential())
  DCBYVFjQyfdtazAemwhHJgWiNqULME =args.get('videoid')
  DCBYVFjQyfdtazAemwhHJgWiNqULMx =args.get('vidtype')
  DCBYVFjQyfdtazAemwhHJgWiNqULlk=DCBYVFjQyfdtazAemwhHJgWiNqULMT(args.get('page'))
  DCBYVFjQyfdtazAemwhHJgWiNqULls,DCBYVFjQyfdtazAemwhHJgWiNqULlv=DCBYVFjQyfdtazAemwhHJgWiNqULcx.WavveObj.Get_Episode_List(DCBYVFjQyfdtazAemwhHJgWiNqULME,DCBYVFjQyfdtazAemwhHJgWiNqULMx,DCBYVFjQyfdtazAemwhHJgWiNqULlk,orderby=DCBYVFjQyfdtazAemwhHJgWiNqULcx.get_winEpisodeOrderby())
  for DCBYVFjQyfdtazAemwhHJgWiNqULlP in DCBYVFjQyfdtazAemwhHJgWiNqULls:
   DCBYVFjQyfdtazAemwhHJgWiNqULlS='%s회, %s(%s)'%(DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('episodenumber'),DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('releasedate'),DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('releaseweekday'))
   DCBYVFjQyfdtazAemwhHJgWiNqULMu ='[%s]\n\n%s'%(DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('episodetitle'),DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('synopsis'))
   DCBYVFjQyfdtazAemwhHJgWiNqULlr={'mediatype':'episode','title':DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('programtitle'),'year':DCBYVFjQyfdtazAemwhHJgWiNqULMT(DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('releasedate')[:4]),'aired':DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('releasedate'),'mpaa':DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('age'),'episode':DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('episodenumber'),'duration':DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('playtime'),'plot':DCBYVFjQyfdtazAemwhHJgWiNqULMu,'cast':DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('episodeactors')}
   DCBYVFjQyfdtazAemwhHJgWiNqULox={'mode':'VOD','programid':DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('programid'),'contentid':DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('contentid'),'thumbnail':DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('thumbnail'),'title':DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('programtitle'),'subtitle':DCBYVFjQyfdtazAemwhHJgWiNqULlS}
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.add_dir(DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('programtitle'),sublabel=DCBYVFjQyfdtazAemwhHJgWiNqULlS,img=DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('thumbnail'),infoLabels=DCBYVFjQyfdtazAemwhHJgWiNqULlr,isFolder=DCBYVFjQyfdtazAemwhHJgWiNqULMK,params=DCBYVFjQyfdtazAemwhHJgWiNqULox)
  if DCBYVFjQyfdtazAemwhHJgWiNqULlk==1:
   DCBYVFjQyfdtazAemwhHJgWiNqULlr={'plot':'정렬순서를 변경합니다.'}
   DCBYVFjQyfdtazAemwhHJgWiNqULox={}
   DCBYVFjQyfdtazAemwhHJgWiNqULox['mode'] ='ORDER_BY' 
   if DCBYVFjQyfdtazAemwhHJgWiNqULcx.get_winEpisodeOrderby()=='desc':
    DCBYVFjQyfdtazAemwhHJgWiNqULol='정렬순서변경 : 최신화부터 -> 1회부터'
    DCBYVFjQyfdtazAemwhHJgWiNqULox['orderby']='asc'
   else:
    DCBYVFjQyfdtazAemwhHJgWiNqULol='정렬순서변경 : 1회부터 -> 최신화부터'
    DCBYVFjQyfdtazAemwhHJgWiNqULox['orderby']='desc'
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.add_dir(DCBYVFjQyfdtazAemwhHJgWiNqULol,sublabel='',img='',infoLabels=DCBYVFjQyfdtazAemwhHJgWiNqULlr,isFolder=DCBYVFjQyfdtazAemwhHJgWiNqULMK,params=DCBYVFjQyfdtazAemwhHJgWiNqULox)
  if DCBYVFjQyfdtazAemwhHJgWiNqULlv:
   DCBYVFjQyfdtazAemwhHJgWiNqULox={}
   DCBYVFjQyfdtazAemwhHJgWiNqULox['mode'] ='EPISODE_LIST' 
   DCBYVFjQyfdtazAemwhHJgWiNqULox['videoid']=DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('programid')
   DCBYVFjQyfdtazAemwhHJgWiNqULox['vidtype']='programid'
   DCBYVFjQyfdtazAemwhHJgWiNqULox['page'] =DCBYVFjQyfdtazAemwhHJgWiNqULEo(DCBYVFjQyfdtazAemwhHJgWiNqULlk+1)
   DCBYVFjQyfdtazAemwhHJgWiNqULol='[B]%s >>[/B]'%'다음 페이지'
   DCBYVFjQyfdtazAemwhHJgWiNqULlS=DCBYVFjQyfdtazAemwhHJgWiNqULEo(DCBYVFjQyfdtazAemwhHJgWiNqULlk+1)
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.add_dir(DCBYVFjQyfdtazAemwhHJgWiNqULol,sublabel=DCBYVFjQyfdtazAemwhHJgWiNqULlS,img='',infoLabels=DCBYVFjQyfdtazAemwhHJgWiNqULMv,isFolder=DCBYVFjQyfdtazAemwhHJgWiNqULMr,params=DCBYVFjQyfdtazAemwhHJgWiNqULox)
  if DCBYVFjQyfdtazAemwhHJgWiNqULMS(DCBYVFjQyfdtazAemwhHJgWiNqULls)>0:xbmcplugin.endOfDirectory(DCBYVFjQyfdtazAemwhHJgWiNqULcx._addon_handle,cacheToDisc=DCBYVFjQyfdtazAemwhHJgWiNqULMK)
 def dp_LiveChannel_List(DCBYVFjQyfdtazAemwhHJgWiNqULcx,args):
  DCBYVFjQyfdtazAemwhHJgWiNqULcx.WavveObj.SaveCredential(DCBYVFjQyfdtazAemwhHJgWiNqULcx.get_winCredential())
  DCBYVFjQyfdtazAemwhHJgWiNqULMb =args.get('genre')
  DCBYVFjQyfdtazAemwhHJgWiNqULlR=args.get('baseapi')
  DCBYVFjQyfdtazAemwhHJgWiNqULls=DCBYVFjQyfdtazAemwhHJgWiNqULcx.WavveObj.Get_LiveChannel_List(DCBYVFjQyfdtazAemwhHJgWiNqULMb,DCBYVFjQyfdtazAemwhHJgWiNqULlR)
  for DCBYVFjQyfdtazAemwhHJgWiNqULlP in DCBYVFjQyfdtazAemwhHJgWiNqULls:
   DCBYVFjQyfdtazAemwhHJgWiNqULMo =DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('channelid')
   DCBYVFjQyfdtazAemwhHJgWiNqULMp =DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('studio')
   DCBYVFjQyfdtazAemwhHJgWiNqULMl=DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('tvshowtitle')
   DCBYVFjQyfdtazAemwhHJgWiNqULlT =DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('thumbnail')
   DCBYVFjQyfdtazAemwhHJgWiNqULlK =DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('age')
   DCBYVFjQyfdtazAemwhHJgWiNqULMI =DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('epg')
   DCBYVFjQyfdtazAemwhHJgWiNqULlr={'mediatype':'video','mpaa':DCBYVFjQyfdtazAemwhHJgWiNqULlK,'title':'%s < %s >'%(DCBYVFjQyfdtazAemwhHJgWiNqULMp,DCBYVFjQyfdtazAemwhHJgWiNqULMl),'tvshowtitle':DCBYVFjQyfdtazAemwhHJgWiNqULMl,'studio':DCBYVFjQyfdtazAemwhHJgWiNqULMp,'plot':'%s\n\n%s'%(DCBYVFjQyfdtazAemwhHJgWiNqULMp,DCBYVFjQyfdtazAemwhHJgWiNqULMI)}
   DCBYVFjQyfdtazAemwhHJgWiNqULox={'mode':'LIVE','contentid':DCBYVFjQyfdtazAemwhHJgWiNqULMo}
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.add_dir(DCBYVFjQyfdtazAemwhHJgWiNqULMp,sublabel=DCBYVFjQyfdtazAemwhHJgWiNqULMl,img=DCBYVFjQyfdtazAemwhHJgWiNqULlT,infoLabels=DCBYVFjQyfdtazAemwhHJgWiNqULlr,isFolder=DCBYVFjQyfdtazAemwhHJgWiNqULMK,params=DCBYVFjQyfdtazAemwhHJgWiNqULox)
  if DCBYVFjQyfdtazAemwhHJgWiNqULMS(DCBYVFjQyfdtazAemwhHJgWiNqULls)>0:xbmcplugin.endOfDirectory(DCBYVFjQyfdtazAemwhHJgWiNqULcx._addon_handle,cacheToDisc=DCBYVFjQyfdtazAemwhHJgWiNqULMK)
 def dp_Search_List(DCBYVFjQyfdtazAemwhHJgWiNqULcx,args):
  DCBYVFjQyfdtazAemwhHJgWiNqULcx.WavveObj.SaveCredential(DCBYVFjQyfdtazAemwhHJgWiNqULcx.get_winCredential())
  DCBYVFjQyfdtazAemwhHJgWiNqULlo =args.get('sType')
  DCBYVFjQyfdtazAemwhHJgWiNqULlk =DCBYVFjQyfdtazAemwhHJgWiNqULMT(args.get('page'))
  if 'search_key' in args:
   DCBYVFjQyfdtazAemwhHJgWiNqULMs=args.get('search_key')
  else:
   DCBYVFjQyfdtazAemwhHJgWiNqULMs=DCBYVFjQyfdtazAemwhHJgWiNqULcx.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not DCBYVFjQyfdtazAemwhHJgWiNqULMs:return
  DCBYVFjQyfdtazAemwhHJgWiNqULls,DCBYVFjQyfdtazAemwhHJgWiNqULlv=DCBYVFjQyfdtazAemwhHJgWiNqULcx.WavveObj.Get_Search_List(DCBYVFjQyfdtazAemwhHJgWiNqULMs,DCBYVFjQyfdtazAemwhHJgWiNqULlo,DCBYVFjQyfdtazAemwhHJgWiNqULlk,exclusion21=DCBYVFjQyfdtazAemwhHJgWiNqULcx.get_settings_exclusion21())
  for DCBYVFjQyfdtazAemwhHJgWiNqULlP in DCBYVFjQyfdtazAemwhHJgWiNqULls:
   DCBYVFjQyfdtazAemwhHJgWiNqULol =DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('title')
   DCBYVFjQyfdtazAemwhHJgWiNqULlT=DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('thumbnail')
   DCBYVFjQyfdtazAemwhHJgWiNqULlK =DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('age')
   if DCBYVFjQyfdtazAemwhHJgWiNqULlK=='18' or DCBYVFjQyfdtazAemwhHJgWiNqULlK=='19' or DCBYVFjQyfdtazAemwhHJgWiNqULlK=='21':DCBYVFjQyfdtazAemwhHJgWiNqULol+=' (%s)'%(DCBYVFjQyfdtazAemwhHJgWiNqULlK)
   DCBYVFjQyfdtazAemwhHJgWiNqULlr={'mediatype':'episode' if DCBYVFjQyfdtazAemwhHJgWiNqULlo=='vod' else 'movie','mpaa':DCBYVFjQyfdtazAemwhHJgWiNqULlK,'title':DCBYVFjQyfdtazAemwhHJgWiNqULol,'plot':DCBYVFjQyfdtazAemwhHJgWiNqULol}
   if DCBYVFjQyfdtazAemwhHJgWiNqULlo=='vod':
    DCBYVFjQyfdtazAemwhHJgWiNqULox={'mode':'EPISODE_LIST','videoid':DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('videoid'),'vidtype':DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('vidtype'),'page':'1'}
    DCBYVFjQyfdtazAemwhHJgWiNqULou=DCBYVFjQyfdtazAemwhHJgWiNqULMr
   else:
    DCBYVFjQyfdtazAemwhHJgWiNqULox={'mode':'MOVIE','contentid':DCBYVFjQyfdtazAemwhHJgWiNqULlP.get('videoid'),'title':DCBYVFjQyfdtazAemwhHJgWiNqULol,'thumbnail':DCBYVFjQyfdtazAemwhHJgWiNqULlT,'age':DCBYVFjQyfdtazAemwhHJgWiNqULlK}
    DCBYVFjQyfdtazAemwhHJgWiNqULou=DCBYVFjQyfdtazAemwhHJgWiNqULMK
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.add_dir(DCBYVFjQyfdtazAemwhHJgWiNqULol,sublabel='',img=DCBYVFjQyfdtazAemwhHJgWiNqULlT,infoLabels=DCBYVFjQyfdtazAemwhHJgWiNqULlr,isFolder=DCBYVFjQyfdtazAemwhHJgWiNqULou,params=DCBYVFjQyfdtazAemwhHJgWiNqULox)
  if DCBYVFjQyfdtazAemwhHJgWiNqULlv:
   DCBYVFjQyfdtazAemwhHJgWiNqULox['mode'] ='SEARCH_LIST' 
   DCBYVFjQyfdtazAemwhHJgWiNqULox['sType']=DCBYVFjQyfdtazAemwhHJgWiNqULlo 
   DCBYVFjQyfdtazAemwhHJgWiNqULox['page'] =DCBYVFjQyfdtazAemwhHJgWiNqULEo(DCBYVFjQyfdtazAemwhHJgWiNqULlk+1)
   DCBYVFjQyfdtazAemwhHJgWiNqULox['search_key']=DCBYVFjQyfdtazAemwhHJgWiNqULMs
   DCBYVFjQyfdtazAemwhHJgWiNqULol='[B]%s >>[/B]'%'다음 페이지'
   DCBYVFjQyfdtazAemwhHJgWiNqULlS=DCBYVFjQyfdtazAemwhHJgWiNqULEo(DCBYVFjQyfdtazAemwhHJgWiNqULlk+1)
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.add_dir(DCBYVFjQyfdtazAemwhHJgWiNqULol,sublabel=DCBYVFjQyfdtazAemwhHJgWiNqULlS,img='',infoLabels=DCBYVFjQyfdtazAemwhHJgWiNqULMv,isFolder=DCBYVFjQyfdtazAemwhHJgWiNqULMr,params=DCBYVFjQyfdtazAemwhHJgWiNqULox)
  if DCBYVFjQyfdtazAemwhHJgWiNqULMS(DCBYVFjQyfdtazAemwhHJgWiNqULls)>0:xbmcplugin.endOfDirectory(DCBYVFjQyfdtazAemwhHJgWiNqULcx._addon_handle)
 def dp_Watch_List(DCBYVFjQyfdtazAemwhHJgWiNqULcx,args):
  DCBYVFjQyfdtazAemwhHJgWiNqULlo =args.get('sType')
  DCBYVFjQyfdtazAemwhHJgWiNqULcX=DCBYVFjQyfdtazAemwhHJgWiNqULcx.get_settings_direct_replay()
  DCBYVFjQyfdtazAemwhHJgWiNqULls=DCBYVFjQyfdtazAemwhHJgWiNqULcx.Load_Watched_List(DCBYVFjQyfdtazAemwhHJgWiNqULlo)
  for DCBYVFjQyfdtazAemwhHJgWiNqULlP in DCBYVFjQyfdtazAemwhHJgWiNqULls:
   DCBYVFjQyfdtazAemwhHJgWiNqULMR=DCBYVFjQyfdtazAemwhHJgWiNqULMX(urllib.parse.parse_qsl(DCBYVFjQyfdtazAemwhHJgWiNqULlP))
   DCBYVFjQyfdtazAemwhHJgWiNqULMP =DCBYVFjQyfdtazAemwhHJgWiNqULMR.get('code').strip()
   DCBYVFjQyfdtazAemwhHJgWiNqULol =DCBYVFjQyfdtazAemwhHJgWiNqULMR.get('title').strip()
   DCBYVFjQyfdtazAemwhHJgWiNqULlS =DCBYVFjQyfdtazAemwhHJgWiNqULMR.get('subtitle').strip()
   if DCBYVFjQyfdtazAemwhHJgWiNqULlS=='None':DCBYVFjQyfdtazAemwhHJgWiNqULlS=''
   DCBYVFjQyfdtazAemwhHJgWiNqULlT=DCBYVFjQyfdtazAemwhHJgWiNqULMR.get('img').strip()
   DCBYVFjQyfdtazAemwhHJgWiNqULME =DCBYVFjQyfdtazAemwhHJgWiNqULMR.get('videoid').strip()
   DCBYVFjQyfdtazAemwhHJgWiNqULlr={'plot':'%s\n%s'%(DCBYVFjQyfdtazAemwhHJgWiNqULol,DCBYVFjQyfdtazAemwhHJgWiNqULlS)}
   if DCBYVFjQyfdtazAemwhHJgWiNqULlo=='vod':
    if DCBYVFjQyfdtazAemwhHJgWiNqULcX==DCBYVFjQyfdtazAemwhHJgWiNqULMK or DCBYVFjQyfdtazAemwhHJgWiNqULME==DCBYVFjQyfdtazAemwhHJgWiNqULMv:
     DCBYVFjQyfdtazAemwhHJgWiNqULox={'mode':'EPISODE_LIST','videoid':DCBYVFjQyfdtazAemwhHJgWiNqULMP,'vidtype':'programid','page':'1'}
     DCBYVFjQyfdtazAemwhHJgWiNqULou=DCBYVFjQyfdtazAemwhHJgWiNqULMr
    else:
     DCBYVFjQyfdtazAemwhHJgWiNqULox={'mode':'VOD','programid':DCBYVFjQyfdtazAemwhHJgWiNqULMP,'contentid':DCBYVFjQyfdtazAemwhHJgWiNqULME,'title':DCBYVFjQyfdtazAemwhHJgWiNqULol,'subtitle':DCBYVFjQyfdtazAemwhHJgWiNqULlS,'thumbnail':DCBYVFjQyfdtazAemwhHJgWiNqULlT}
     DCBYVFjQyfdtazAemwhHJgWiNqULou=DCBYVFjQyfdtazAemwhHJgWiNqULMK
   else:
    DCBYVFjQyfdtazAemwhHJgWiNqULox={'mode':'MOVIE','contentid':DCBYVFjQyfdtazAemwhHJgWiNqULMP,'title':DCBYVFjQyfdtazAemwhHJgWiNqULol,'subtitle':DCBYVFjQyfdtazAemwhHJgWiNqULlS,'thumbnail':DCBYVFjQyfdtazAemwhHJgWiNqULlT}
    DCBYVFjQyfdtazAemwhHJgWiNqULou=DCBYVFjQyfdtazAemwhHJgWiNqULMK
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.add_dir(DCBYVFjQyfdtazAemwhHJgWiNqULol,sublabel=DCBYVFjQyfdtazAemwhHJgWiNqULlS,img=DCBYVFjQyfdtazAemwhHJgWiNqULlT,infoLabels=DCBYVFjQyfdtazAemwhHJgWiNqULlr,isFolder=DCBYVFjQyfdtazAemwhHJgWiNqULou,params=DCBYVFjQyfdtazAemwhHJgWiNqULox)
  DCBYVFjQyfdtazAemwhHJgWiNqULlr={'plot':'시청목록을 삭제합니다.'}
  DCBYVFjQyfdtazAemwhHJgWiNqULol='*** 시청목록 삭제 ***'
  DCBYVFjQyfdtazAemwhHJgWiNqULox={'mode':'MYVIEW_REMOVE','sType':DCBYVFjQyfdtazAemwhHJgWiNqULlo}
  DCBYVFjQyfdtazAemwhHJgWiNqULcx.add_dir(DCBYVFjQyfdtazAemwhHJgWiNqULol,sublabel='',img='',infoLabels=DCBYVFjQyfdtazAemwhHJgWiNqULlr,isFolder=DCBYVFjQyfdtazAemwhHJgWiNqULMK,params=DCBYVFjQyfdtazAemwhHJgWiNqULox)
  xbmcplugin.endOfDirectory(DCBYVFjQyfdtazAemwhHJgWiNqULcx._addon_handle,cacheToDisc=DCBYVFjQyfdtazAemwhHJgWiNqULMK)
 def wavve_main(DCBYVFjQyfdtazAemwhHJgWiNqULcx):
  DCBYVFjQyfdtazAemwhHJgWiNqULoS=DCBYVFjQyfdtazAemwhHJgWiNqULcx.main_params.get('mode',DCBYVFjQyfdtazAemwhHJgWiNqULMv)
  if DCBYVFjQyfdtazAemwhHJgWiNqULoS=='LOGOUT':
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.logout()
   return
  DCBYVFjQyfdtazAemwhHJgWiNqULcx.login_main()
  if DCBYVFjQyfdtazAemwhHJgWiNqULoS is DCBYVFjQyfdtazAemwhHJgWiNqULMv:
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.dp_Main_List()
  elif DCBYVFjQyfdtazAemwhHJgWiNqULoS in['LIVE','VOD','MOVIE']:
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.play_VIDEO(DCBYVFjQyfdtazAemwhHJgWiNqULcx.main_params)
  elif DCBYVFjQyfdtazAemwhHJgWiNqULoS=='LIVE_CATAGORY':
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.dp_LiveCatagory_List(DCBYVFjQyfdtazAemwhHJgWiNqULcx.main_params)
  elif DCBYVFjQyfdtazAemwhHJgWiNqULoS=='MAIN_CATAGORY':
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.dp_MainCatagory_List(DCBYVFjQyfdtazAemwhHJgWiNqULcx.main_params)
  elif DCBYVFjQyfdtazAemwhHJgWiNqULoS=='SUPERSECTION_LIST':
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.dp_SuperSection_List(DCBYVFjQyfdtazAemwhHJgWiNqULcx.main_params)
  elif DCBYVFjQyfdtazAemwhHJgWiNqULoS=='BANDLIVESECTION_LIST':
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.dp_BandLiveSection_List(DCBYVFjQyfdtazAemwhHJgWiNqULcx.main_params)
  elif DCBYVFjQyfdtazAemwhHJgWiNqULoS=='BAND2SECTION_LIST':
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.dp_Band2Section_List(DCBYVFjQyfdtazAemwhHJgWiNqULcx.main_params)
  elif DCBYVFjQyfdtazAemwhHJgWiNqULoS=='PROGRAM_LIST':
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.dp_Program_List(DCBYVFjQyfdtazAemwhHJgWiNqULcx.main_params)
  elif DCBYVFjQyfdtazAemwhHJgWiNqULoS=='EPISODE_LIST':
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.dp_Episode_List(DCBYVFjQyfdtazAemwhHJgWiNqULcx.main_params)
  elif DCBYVFjQyfdtazAemwhHJgWiNqULoS=='MOVIE_LIST':
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.dp_Movie_List(DCBYVFjQyfdtazAemwhHJgWiNqULcx.main_params)
  elif DCBYVFjQyfdtazAemwhHJgWiNqULoS=='LIVE_LIST':
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.dp_LiveChannel_List(DCBYVFjQyfdtazAemwhHJgWiNqULcx.main_params)
  elif DCBYVFjQyfdtazAemwhHJgWiNqULoS=='ORDER_BY':
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.dp_setEpOrderby(DCBYVFjQyfdtazAemwhHJgWiNqULcx.main_params)
  elif DCBYVFjQyfdtazAemwhHJgWiNqULoS=='SEARCH_GROUP':
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.dp_Search_Group(DCBYVFjQyfdtazAemwhHJgWiNqULcx.main_params)
  elif DCBYVFjQyfdtazAemwhHJgWiNqULoS=='SEARCH_LIST':
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.dp_Search_List(DCBYVFjQyfdtazAemwhHJgWiNqULcx.main_params)
  elif DCBYVFjQyfdtazAemwhHJgWiNqULoS=='WATCH_GROUP':
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.dp_Watch_Group(DCBYVFjQyfdtazAemwhHJgWiNqULcx.main_params)
  elif DCBYVFjQyfdtazAemwhHJgWiNqULoS=='WATCH_LIST':
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.dp_Watch_List(DCBYVFjQyfdtazAemwhHJgWiNqULcx.main_params)
  elif DCBYVFjQyfdtazAemwhHJgWiNqULoS=='MYVIEW_REMOVE':
   DCBYVFjQyfdtazAemwhHJgWiNqULcx.dp_WatchList_Delete(DCBYVFjQyfdtazAemwhHJgWiNqULcx.main_params)
  else:
   DCBYVFjQyfdtazAemwhHJgWiNqULMv
# Created by pyminifier (https://github.com/liftoff/pyminifier)
