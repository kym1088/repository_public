__author__="NightRain"
HbcBODGIFuJVixALrpvygndlRWakzf=object
HbcBODGIFuJVixALrpvygndlRWakzQ=None
HbcBODGIFuJVixALrpvygndlRWakzP=int
HbcBODGIFuJVixALrpvygndlRWakze=False
HbcBODGIFuJVixALrpvygndlRWakzs=True
HbcBODGIFuJVixALrpvygndlRWakzh=len
HbcBODGIFuJVixALrpvygndlRWakzM=open
HbcBODGIFuJVixALrpvygndlRWakzY=dict
HbcBODGIFuJVixALrpvygndlRWakzo=Exception
HbcBODGIFuJVixALrpvygndlRWakEq=print
HbcBODGIFuJVixALrpvygndlRWakES=str
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
HbcBODGIFuJVixALrpvygndlRWakqU=[{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://www.wavve.com/supermultisection/GN51'},{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&offset=0&limit=20&uicode=VN500','page':'1'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=01&WeekDay=all&uitype=VN4&uiparent=FN0&uirank=0&broadcastid=847243&uicode=VN4','page':'1'},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=02&WeekDay=all&uitype=VN3&uiparent=FN0&uirank=0&broadcastid=783664&uicode=VN3','page':'1'},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'1','sType':'vod','orderby':'new','ordernm':'최신순'},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'viewtime','ordernm':'인기순'},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순'},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'paid','ordernm':'인기순'},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'displaystart','ordernm':'업데이트순'},{'title':'검색 (search)','mode':'SEARCH_GROUP'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP'}]
HbcBODGIFuJVixALrpvygndlRWakqK=[{'title':'VOD 검색','mode':'SEARCH_LIST','sType':'vod'},{'title':'영화 검색','mode':'SEARCH_LIST','sType':'movie'}]
HbcBODGIFuJVixALrpvygndlRWakqz=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
HbcBODGIFuJVixALrpvygndlRWakqE=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
from wavveCore import*
class HbcBODGIFuJVixALrpvygndlRWakqS(HbcBODGIFuJVixALrpvygndlRWakzf):
 def __init__(HbcBODGIFuJVixALrpvygndlRWakqj,HbcBODGIFuJVixALrpvygndlRWakqC,HbcBODGIFuJVixALrpvygndlRWakqt,HbcBODGIFuJVixALrpvygndlRWakqw):
  HbcBODGIFuJVixALrpvygndlRWakqj._addon_url =HbcBODGIFuJVixALrpvygndlRWakqC
  HbcBODGIFuJVixALrpvygndlRWakqj._addon_handle=HbcBODGIFuJVixALrpvygndlRWakqt
  HbcBODGIFuJVixALrpvygndlRWakqj.main_params =HbcBODGIFuJVixALrpvygndlRWakqw
  HbcBODGIFuJVixALrpvygndlRWakqj.WavveObj =WukBaKhGUzRIFJebYdxtVqsmATXvoc() 
 def addon_noti(HbcBODGIFuJVixALrpvygndlRWakqj,sting):
  try:
   HbcBODGIFuJVixALrpvygndlRWakqN=xbmcgui.Dialog()
   HbcBODGIFuJVixALrpvygndlRWakqN.notification(__addonname__,sting)
  except:
   HbcBODGIFuJVixALrpvygndlRWakzQ
 def addon_log(HbcBODGIFuJVixALrpvygndlRWakqj,string):
  try:
   HbcBODGIFuJVixALrpvygndlRWakqT=string.encode('utf-8','ignore')
  except:
   HbcBODGIFuJVixALrpvygndlRWakqT='addonException: addon_log'
  HbcBODGIFuJVixALrpvygndlRWakqm=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,HbcBODGIFuJVixALrpvygndlRWakqT),level=HbcBODGIFuJVixALrpvygndlRWakqm)
 def get_keyboard_input(HbcBODGIFuJVixALrpvygndlRWakqj,HbcBODGIFuJVixALrpvygndlRWakSK):
  HbcBODGIFuJVixALrpvygndlRWakqf=HbcBODGIFuJVixALrpvygndlRWakzQ
  kb=xbmc.Keyboard()
  kb.setHeading(HbcBODGIFuJVixALrpvygndlRWakSK)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   HbcBODGIFuJVixALrpvygndlRWakqf=kb.getText()
  return HbcBODGIFuJVixALrpvygndlRWakqf
 def get_settings_login_info(HbcBODGIFuJVixALrpvygndlRWakqj):
  HbcBODGIFuJVixALrpvygndlRWakqQ =__addon__.getSetting('id')
  HbcBODGIFuJVixALrpvygndlRWakqP =__addon__.getSetting('pw')
  HbcBODGIFuJVixALrpvygndlRWakqe=__addon__.getSetting('selected_profile')
  return(HbcBODGIFuJVixALrpvygndlRWakqQ,HbcBODGIFuJVixALrpvygndlRWakqP,HbcBODGIFuJVixALrpvygndlRWakqe)
 def get_selQuality(HbcBODGIFuJVixALrpvygndlRWakqj):
  try:
   HbcBODGIFuJVixALrpvygndlRWakqs=[1080,720,480,360]
   HbcBODGIFuJVixALrpvygndlRWakqh=HbcBODGIFuJVixALrpvygndlRWakzP(__addon__.getSetting('selected_quality'))
   return HbcBODGIFuJVixALrpvygndlRWakqs[HbcBODGIFuJVixALrpvygndlRWakqh]
  except:
   HbcBODGIFuJVixALrpvygndlRWakzQ
  return 1080 
 def get_settings_exclusion21(HbcBODGIFuJVixALrpvygndlRWakqj):
  HbcBODGIFuJVixALrpvygndlRWakqM =__addon__.getSetting('exclusion21')
  if HbcBODGIFuJVixALrpvygndlRWakqM=='false':
   return HbcBODGIFuJVixALrpvygndlRWakze
  else:
   return HbcBODGIFuJVixALrpvygndlRWakzs
 def get_settings_direct_replay(HbcBODGIFuJVixALrpvygndlRWakqj):
  HbcBODGIFuJVixALrpvygndlRWakqY=HbcBODGIFuJVixALrpvygndlRWakzP(__addon__.getSetting('direct_replay'))
  if HbcBODGIFuJVixALrpvygndlRWakqY==0:
   return HbcBODGIFuJVixALrpvygndlRWakze
  else:
   return HbcBODGIFuJVixALrpvygndlRWakzs
 def get_settings_addinfo(HbcBODGIFuJVixALrpvygndlRWakqj):
  HbcBODGIFuJVixALrpvygndlRWakqo =__addon__.getSetting('add_infoyn')
  if HbcBODGIFuJVixALrpvygndlRWakqo=='false':
   return HbcBODGIFuJVixALrpvygndlRWakze
  else:
   return HbcBODGIFuJVixALrpvygndlRWakzs
 def set_winCredential(HbcBODGIFuJVixALrpvygndlRWakqj,credential):
  HbcBODGIFuJVixALrpvygndlRWakSq=xbmcgui.Window(10000)
  HbcBODGIFuJVixALrpvygndlRWakSq.setProperty('WAVVE_M_CREDENTIAL',credential)
  HbcBODGIFuJVixALrpvygndlRWakSq.setProperty('WAVVE_M_LOGINTIME',HbcBODGIFuJVixALrpvygndlRWakqj.WavveObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(HbcBODGIFuJVixALrpvygndlRWakqj):
  HbcBODGIFuJVixALrpvygndlRWakSq=xbmcgui.Window(10000)
  return HbcBODGIFuJVixALrpvygndlRWakSq.getProperty('WAVVE_M_CREDENTIAL')
 def set_winEpisodeOrderby(HbcBODGIFuJVixALrpvygndlRWakqj,HbcBODGIFuJVixALrpvygndlRWakSs):
  HbcBODGIFuJVixALrpvygndlRWakSq=xbmcgui.Window(10000)
  HbcBODGIFuJVixALrpvygndlRWakSq.setProperty('WAVVE_M_ORDERBY',HbcBODGIFuJVixALrpvygndlRWakSs)
 def get_winEpisodeOrderby(HbcBODGIFuJVixALrpvygndlRWakqj):
  HbcBODGIFuJVixALrpvygndlRWakSq=xbmcgui.Window(10000)
  return HbcBODGIFuJVixALrpvygndlRWakSq.getProperty('WAVVE_M_ORDERBY')
 def add_dir(HbcBODGIFuJVixALrpvygndlRWakqj,label,sublabel='',img='',infoLabels=HbcBODGIFuJVixALrpvygndlRWakzQ,isFolder=HbcBODGIFuJVixALrpvygndlRWakzs,params=''):
  HbcBODGIFuJVixALrpvygndlRWakSU='%s?%s'%(HbcBODGIFuJVixALrpvygndlRWakqj._addon_url,urllib.parse.urlencode(params))
  if sublabel:HbcBODGIFuJVixALrpvygndlRWakSK='%s < %s >'%(label,sublabel)
  else: HbcBODGIFuJVixALrpvygndlRWakSK=label
  if not img:img='DefaultFolder.png'
  HbcBODGIFuJVixALrpvygndlRWakSz=xbmcgui.ListItem(HbcBODGIFuJVixALrpvygndlRWakSK)
  HbcBODGIFuJVixALrpvygndlRWakSz.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:HbcBODGIFuJVixALrpvygndlRWakSz.setInfo(type="video",infoLabels=infoLabels)
  if not isFolder:HbcBODGIFuJVixALrpvygndlRWakSz.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(HbcBODGIFuJVixALrpvygndlRWakqj._addon_handle,HbcBODGIFuJVixALrpvygndlRWakSU,HbcBODGIFuJVixALrpvygndlRWakSz,isFolder)
 def dp_Main_List(HbcBODGIFuJVixALrpvygndlRWakqj):
  for HbcBODGIFuJVixALrpvygndlRWakSE in HbcBODGIFuJVixALrpvygndlRWakqU:
   HbcBODGIFuJVixALrpvygndlRWakSK=HbcBODGIFuJVixALrpvygndlRWakSE.get('title')
   HbcBODGIFuJVixALrpvygndlRWakSj={'mode':HbcBODGIFuJVixALrpvygndlRWakSE.get('mode'),'sCode':HbcBODGIFuJVixALrpvygndlRWakSE.get('sCode'),'sIndex':HbcBODGIFuJVixALrpvygndlRWakSE.get('sIndex'),'sType':HbcBODGIFuJVixALrpvygndlRWakSE.get('sType'),'suburl':HbcBODGIFuJVixALrpvygndlRWakSE.get('suburl'),'subapi':HbcBODGIFuJVixALrpvygndlRWakSE.get('subapi'),'page':HbcBODGIFuJVixALrpvygndlRWakSE.get('page'),'orderby':HbcBODGIFuJVixALrpvygndlRWakSE.get('orderby'),'ordernm':HbcBODGIFuJVixALrpvygndlRWakSE.get('ordernm')}
   if HbcBODGIFuJVixALrpvygndlRWakSE.get('mode')=='XXX':
    HbcBODGIFuJVixALrpvygndlRWakSC=HbcBODGIFuJVixALrpvygndlRWakze
   else:
    HbcBODGIFuJVixALrpvygndlRWakSC=HbcBODGIFuJVixALrpvygndlRWakzs
   HbcBODGIFuJVixALrpvygndlRWakqj.add_dir(HbcBODGIFuJVixALrpvygndlRWakSK,sublabel='',img='',infoLabels=HbcBODGIFuJVixALrpvygndlRWakzQ,isFolder=HbcBODGIFuJVixALrpvygndlRWakSC,params=HbcBODGIFuJVixALrpvygndlRWakSj)
  if HbcBODGIFuJVixALrpvygndlRWakzh(HbcBODGIFuJVixALrpvygndlRWakqU)>0:xbmcplugin.endOfDirectory(HbcBODGIFuJVixALrpvygndlRWakqj._addon_handle,cacheToDisc=HbcBODGIFuJVixALrpvygndlRWakzs)
 def dp_Search_Group(HbcBODGIFuJVixALrpvygndlRWakqj,args):
  for HbcBODGIFuJVixALrpvygndlRWakSw in HbcBODGIFuJVixALrpvygndlRWakqK:
   HbcBODGIFuJVixALrpvygndlRWakSK=HbcBODGIFuJVixALrpvygndlRWakSw.get('title')
   HbcBODGIFuJVixALrpvygndlRWakSj={'mode':HbcBODGIFuJVixALrpvygndlRWakSw.get('mode'),'sType':HbcBODGIFuJVixALrpvygndlRWakSw.get('sType'),'page':'1'}
   HbcBODGIFuJVixALrpvygndlRWakqj.add_dir(HbcBODGIFuJVixALrpvygndlRWakSK,sublabel='',img='',infoLabels=HbcBODGIFuJVixALrpvygndlRWakzQ,isFolder=HbcBODGIFuJVixALrpvygndlRWakzs,params=HbcBODGIFuJVixALrpvygndlRWakSj)
  if HbcBODGIFuJVixALrpvygndlRWakzh(HbcBODGIFuJVixALrpvygndlRWakqK)>0:xbmcplugin.endOfDirectory(HbcBODGIFuJVixALrpvygndlRWakqj._addon_handle,cacheToDisc=HbcBODGIFuJVixALrpvygndlRWakzs)
 def dp_Watch_Group(HbcBODGIFuJVixALrpvygndlRWakqj,args):
  for HbcBODGIFuJVixALrpvygndlRWakSX in HbcBODGIFuJVixALrpvygndlRWakqz:
   HbcBODGIFuJVixALrpvygndlRWakSK=HbcBODGIFuJVixALrpvygndlRWakSX.get('title')
   HbcBODGIFuJVixALrpvygndlRWakSj={'mode':HbcBODGIFuJVixALrpvygndlRWakSX.get('mode'),'sType':HbcBODGIFuJVixALrpvygndlRWakSX.get('sType')}
   HbcBODGIFuJVixALrpvygndlRWakqj.add_dir(HbcBODGIFuJVixALrpvygndlRWakSK,sublabel='',img='',infoLabels=HbcBODGIFuJVixALrpvygndlRWakzQ,isFolder=HbcBODGIFuJVixALrpvygndlRWakzs,params=HbcBODGIFuJVixALrpvygndlRWakSj)
  if HbcBODGIFuJVixALrpvygndlRWakzh(HbcBODGIFuJVixALrpvygndlRWakqz)>0:xbmcplugin.endOfDirectory(HbcBODGIFuJVixALrpvygndlRWakqj._addon_handle,cacheToDisc=HbcBODGIFuJVixALrpvygndlRWakzs)
 def login_main(HbcBODGIFuJVixALrpvygndlRWakqj):
  (HbcBODGIFuJVixALrpvygndlRWakSN,HbcBODGIFuJVixALrpvygndlRWakST,HbcBODGIFuJVixALrpvygndlRWakSm)=HbcBODGIFuJVixALrpvygndlRWakqj.get_settings_login_info()
  if not(HbcBODGIFuJVixALrpvygndlRWakSN and HbcBODGIFuJVixALrpvygndlRWakST):
   HbcBODGIFuJVixALrpvygndlRWakqN=xbmcgui.Dialog()
   HbcBODGIFuJVixALrpvygndlRWakSf=HbcBODGIFuJVixALrpvygndlRWakqN.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if HbcBODGIFuJVixALrpvygndlRWakSf==HbcBODGIFuJVixALrpvygndlRWakzs:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if HbcBODGIFuJVixALrpvygndlRWakqj.get_winEpisodeOrderby()=='':
   HbcBODGIFuJVixALrpvygndlRWakqj.set_winEpisodeOrderby('desc')
  if HbcBODGIFuJVixALrpvygndlRWakqj.cookiefile_check():return
  HbcBODGIFuJVixALrpvygndlRWakSQ =HbcBODGIFuJVixALrpvygndlRWakzP(HbcBODGIFuJVixALrpvygndlRWakqj.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  HbcBODGIFuJVixALrpvygndlRWakSP=xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINTIME')
  if HbcBODGIFuJVixALrpvygndlRWakSP==HbcBODGIFuJVixALrpvygndlRWakzQ or HbcBODGIFuJVixALrpvygndlRWakSP=='':
   HbcBODGIFuJVixALrpvygndlRWakSP=HbcBODGIFuJVixALrpvygndlRWakzP('19000101')
  else:
   HbcBODGIFuJVixALrpvygndlRWakSP=HbcBODGIFuJVixALrpvygndlRWakzP(re.sub('-','',HbcBODGIFuJVixALrpvygndlRWakSP))
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   HbcBODGIFuJVixALrpvygndlRWakSe=0
   while HbcBODGIFuJVixALrpvygndlRWakzs:
    HbcBODGIFuJVixALrpvygndlRWakSe+=1
    time.sleep(0.05)
    if HbcBODGIFuJVixALrpvygndlRWakSP>=HbcBODGIFuJVixALrpvygndlRWakSQ:return
    if HbcBODGIFuJVixALrpvygndlRWakSe>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  if HbcBODGIFuJVixALrpvygndlRWakSP>=HbcBODGIFuJVixALrpvygndlRWakSQ:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   return
  if not HbcBODGIFuJVixALrpvygndlRWakqj.WavveObj.GetCredential(HbcBODGIFuJVixALrpvygndlRWakSN,HbcBODGIFuJVixALrpvygndlRWakST,HbcBODGIFuJVixALrpvygndlRWakSm):
   HbcBODGIFuJVixALrpvygndlRWakqj.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   sys.exit()
  HbcBODGIFuJVixALrpvygndlRWakqj.set_winCredential(HbcBODGIFuJVixALrpvygndlRWakqj.WavveObj.LoadCredential())
  HbcBODGIFuJVixALrpvygndlRWakqj.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
 def dp_setEpOrderby(HbcBODGIFuJVixALrpvygndlRWakqj,args):
  HbcBODGIFuJVixALrpvygndlRWakSs =args.get('orderby')
  HbcBODGIFuJVixALrpvygndlRWakqj.set_winEpisodeOrderby(HbcBODGIFuJVixALrpvygndlRWakSs)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(HbcBODGIFuJVixALrpvygndlRWakqj,args):
  HbcBODGIFuJVixALrpvygndlRWakqj.WavveObj.SaveCredential(HbcBODGIFuJVixALrpvygndlRWakqj.get_winCredential())
  HbcBODGIFuJVixALrpvygndlRWakSh =args.get('mode')
  HbcBODGIFuJVixALrpvygndlRWakSM =args.get('contentid')
  HbcBODGIFuJVixALrpvygndlRWakSY =args.get('pvrmode')
  HbcBODGIFuJVixALrpvygndlRWakSo=HbcBODGIFuJVixALrpvygndlRWakqj.get_selQuality()
  HbcBODGIFuJVixALrpvygndlRWakqj.addon_log(HbcBODGIFuJVixALrpvygndlRWakSM+' - '+HbcBODGIFuJVixALrpvygndlRWakSh)
  HbcBODGIFuJVixALrpvygndlRWakUq,HbcBODGIFuJVixALrpvygndlRWakUS,HbcBODGIFuJVixALrpvygndlRWakUK,HbcBODGIFuJVixALrpvygndlRWakUz=HbcBODGIFuJVixALrpvygndlRWakqj.WavveObj.GetStreamingURL(HbcBODGIFuJVixALrpvygndlRWakSh,HbcBODGIFuJVixALrpvygndlRWakSM,HbcBODGIFuJVixALrpvygndlRWakSo,HbcBODGIFuJVixALrpvygndlRWakSY)
  HbcBODGIFuJVixALrpvygndlRWakUE='%s|Cookie=%s'%(HbcBODGIFuJVixALrpvygndlRWakUq,HbcBODGIFuJVixALrpvygndlRWakUS)
  HbcBODGIFuJVixALrpvygndlRWakqj.addon_log(HbcBODGIFuJVixALrpvygndlRWakUE)
  if HbcBODGIFuJVixALrpvygndlRWakUq=='':
   HbcBODGIFuJVixALrpvygndlRWakqj.addon_noti(__language__(30907).encode('utf8'))
   return
  HbcBODGIFuJVixALrpvygndlRWakUj=xbmcgui.ListItem(path=HbcBODGIFuJVixALrpvygndlRWakUE)
  if HbcBODGIFuJVixALrpvygndlRWakUK:
   HbcBODGIFuJVixALrpvygndlRWakqj.addon_log('!!streaming_drm!!')
   HbcBODGIFuJVixALrpvygndlRWakUC=HbcBODGIFuJVixALrpvygndlRWakUK['customdata']
   HbcBODGIFuJVixALrpvygndlRWakUt =HbcBODGIFuJVixALrpvygndlRWakUK['drmhost']
   HbcBODGIFuJVixALrpvygndlRWakUw =inputstreamhelper.Helper('mpd',drm='widevine')
   if HbcBODGIFuJVixALrpvygndlRWakUw.check_inputstream():
    if HbcBODGIFuJVixALrpvygndlRWakSh=='MOVIE':
     HbcBODGIFuJVixALrpvygndlRWakUX='https://www.wavve.com/player/movie?movieid=%s'%HbcBODGIFuJVixALrpvygndlRWakSM
    else:
     HbcBODGIFuJVixALrpvygndlRWakUX='https://www.wavve.com/player/vod?programid=%s&page=1'%HbcBODGIFuJVixALrpvygndlRWakSM
    HbcBODGIFuJVixALrpvygndlRWakUN={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':HbcBODGIFuJVixALrpvygndlRWakUC,'referer':HbcBODGIFuJVixALrpvygndlRWakUX,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':HbcBODGIFuJVixALrpvygndlRWakqj.WavveObj.USER_AGENT}
    HbcBODGIFuJVixALrpvygndlRWakUT=HbcBODGIFuJVixALrpvygndlRWakUt+'|'+urllib.parse.urlencode(HbcBODGIFuJVixALrpvygndlRWakUN)+'|R{SSM}|'
    HbcBODGIFuJVixALrpvygndlRWakUj.setProperty('inputstream',HbcBODGIFuJVixALrpvygndlRWakUw.inputstream_addon)
    HbcBODGIFuJVixALrpvygndlRWakUj.setProperty('inputstream.adaptive.manifest_type','mpd')
    HbcBODGIFuJVixALrpvygndlRWakUj.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    HbcBODGIFuJVixALrpvygndlRWakUj.setProperty('inputstream.adaptive.license_key',HbcBODGIFuJVixALrpvygndlRWakUT)
    HbcBODGIFuJVixALrpvygndlRWakUj.setProperty('inputstream.adaptive.stream_headers','user-agent=%s&Cookie=%s'%(HbcBODGIFuJVixALrpvygndlRWakqj.WavveObj.USER_AGENT,HbcBODGIFuJVixALrpvygndlRWakUS))
  xbmcplugin.setResolvedUrl(HbcBODGIFuJVixALrpvygndlRWakqj._addon_handle,HbcBODGIFuJVixALrpvygndlRWakzs,HbcBODGIFuJVixALrpvygndlRWakUj)
  HbcBODGIFuJVixALrpvygndlRWakUm=HbcBODGIFuJVixALrpvygndlRWakze
  if HbcBODGIFuJVixALrpvygndlRWakUz:
   HbcBODGIFuJVixALrpvygndlRWakqj.addon_noti(HbcBODGIFuJVixALrpvygndlRWakUz.encode('utf-8'))
   HbcBODGIFuJVixALrpvygndlRWakUm=HbcBODGIFuJVixALrpvygndlRWakzs
  else:
   if '/preview.' in urllib.parse.urlsplit(HbcBODGIFuJVixALrpvygndlRWakUq).path:
    HbcBODGIFuJVixALrpvygndlRWakqj.addon_noti(__language__(30908).encode('utf8'))
    HbcBODGIFuJVixALrpvygndlRWakUm=HbcBODGIFuJVixALrpvygndlRWakzs
  try:
   HbcBODGIFuJVixALrpvygndlRWakUf=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and HbcBODGIFuJVixALrpvygndlRWakUm==HbcBODGIFuJVixALrpvygndlRWakze and HbcBODGIFuJVixALrpvygndlRWakUf!='-':
    HbcBODGIFuJVixALrpvygndlRWakSj={'code':HbcBODGIFuJVixALrpvygndlRWakUf,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    HbcBODGIFuJVixALrpvygndlRWakqj.Save_Watched_List(args.get('mode').lower(),HbcBODGIFuJVixALrpvygndlRWakSj)
  except:
   HbcBODGIFuJVixALrpvygndlRWakzQ
 def Load_Watched_List(HbcBODGIFuJVixALrpvygndlRWakqj,HbcBODGIFuJVixALrpvygndlRWakzt):
  try:
   HbcBODGIFuJVixALrpvygndlRWakUQ=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%HbcBODGIFuJVixALrpvygndlRWakzt))
   fp=HbcBODGIFuJVixALrpvygndlRWakzM(HbcBODGIFuJVixALrpvygndlRWakUQ,'r',-1,'utf-8')
   HbcBODGIFuJVixALrpvygndlRWakUP=fp.readlines()
   fp.close()
  except:
   HbcBODGIFuJVixALrpvygndlRWakUP=[]
  return HbcBODGIFuJVixALrpvygndlRWakUP
 def Save_Watched_List(HbcBODGIFuJVixALrpvygndlRWakqj,HbcBODGIFuJVixALrpvygndlRWakzt,HbcBODGIFuJVixALrpvygndlRWakqw):
  try:
   HbcBODGIFuJVixALrpvygndlRWakUQ=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%HbcBODGIFuJVixALrpvygndlRWakzt))
   HbcBODGIFuJVixALrpvygndlRWakUe=HbcBODGIFuJVixALrpvygndlRWakqj.Load_Watched_List(HbcBODGIFuJVixALrpvygndlRWakzt) 
   fp=HbcBODGIFuJVixALrpvygndlRWakzM(HbcBODGIFuJVixALrpvygndlRWakUQ,'w',-1,'utf-8')
   HbcBODGIFuJVixALrpvygndlRWakUs=urllib.parse.urlencode(HbcBODGIFuJVixALrpvygndlRWakqw)
   HbcBODGIFuJVixALrpvygndlRWakUs=HbcBODGIFuJVixALrpvygndlRWakUs+'\n'
   fp.write(HbcBODGIFuJVixALrpvygndlRWakUs)
   HbcBODGIFuJVixALrpvygndlRWakUh=0
   for HbcBODGIFuJVixALrpvygndlRWakUM in HbcBODGIFuJVixALrpvygndlRWakUe:
    HbcBODGIFuJVixALrpvygndlRWakUY=HbcBODGIFuJVixALrpvygndlRWakzY(urllib.parse.parse_qsl(HbcBODGIFuJVixALrpvygndlRWakUM))
    HbcBODGIFuJVixALrpvygndlRWakUo=HbcBODGIFuJVixALrpvygndlRWakqw.get('code').strip()
    HbcBODGIFuJVixALrpvygndlRWakKq=HbcBODGIFuJVixALrpvygndlRWakUY.get('code').strip()
    if HbcBODGIFuJVixALrpvygndlRWakzt=='vod' and HbcBODGIFuJVixALrpvygndlRWakqj.get_settings_direct_replay()==HbcBODGIFuJVixALrpvygndlRWakzs:
     HbcBODGIFuJVixALrpvygndlRWakUo=HbcBODGIFuJVixALrpvygndlRWakqw.get('videoid').strip()
     HbcBODGIFuJVixALrpvygndlRWakKq=HbcBODGIFuJVixALrpvygndlRWakUY.get('videoid').strip()if HbcBODGIFuJVixALrpvygndlRWakKq!=HbcBODGIFuJVixALrpvygndlRWakzQ else '-'
    if HbcBODGIFuJVixALrpvygndlRWakUo!=HbcBODGIFuJVixALrpvygndlRWakKq:
     fp.write(HbcBODGIFuJVixALrpvygndlRWakUM)
     HbcBODGIFuJVixALrpvygndlRWakUh+=1
     if HbcBODGIFuJVixALrpvygndlRWakUh>=50:break
   fp.close()
  except:
   HbcBODGIFuJVixALrpvygndlRWakzQ
 def Delete_Watched_List(HbcBODGIFuJVixALrpvygndlRWakqj,HbcBODGIFuJVixALrpvygndlRWakzt):
  try:
   HbcBODGIFuJVixALrpvygndlRWakUQ=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%HbcBODGIFuJVixALrpvygndlRWakzt))
   fp=HbcBODGIFuJVixALrpvygndlRWakzM(HbcBODGIFuJVixALrpvygndlRWakUQ,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   HbcBODGIFuJVixALrpvygndlRWakzQ
 def dp_WatchList_Delete(HbcBODGIFuJVixALrpvygndlRWakqj,args):
  HbcBODGIFuJVixALrpvygndlRWakKS=args.get('sType')
  HbcBODGIFuJVixALrpvygndlRWakqN=xbmcgui.Dialog()
  HbcBODGIFuJVixALrpvygndlRWakSf=HbcBODGIFuJVixALrpvygndlRWakqN.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if HbcBODGIFuJVixALrpvygndlRWakSf==HbcBODGIFuJVixALrpvygndlRWakze:sys.exit()
  HbcBODGIFuJVixALrpvygndlRWakqj.Delete_Watched_List(HbcBODGIFuJVixALrpvygndlRWakKS)
  xbmc.executebuiltin("Container.Refresh")
 def logout(HbcBODGIFuJVixALrpvygndlRWakqj):
  HbcBODGIFuJVixALrpvygndlRWakqN=xbmcgui.Dialog()
  HbcBODGIFuJVixALrpvygndlRWakSf=HbcBODGIFuJVixALrpvygndlRWakqN.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if HbcBODGIFuJVixALrpvygndlRWakSf==HbcBODGIFuJVixALrpvygndlRWakze:sys.exit()
  HbcBODGIFuJVixALrpvygndlRWakqj.wininfo_clear()
  if os.path.isfile(HbcBODGIFuJVixALrpvygndlRWakqE):os.remove(HbcBODGIFuJVixALrpvygndlRWakqE)
  HbcBODGIFuJVixALrpvygndlRWakqj.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(HbcBODGIFuJVixALrpvygndlRWakqj):
  HbcBODGIFuJVixALrpvygndlRWakSq=xbmcgui.Window(10000)
  HbcBODGIFuJVixALrpvygndlRWakSq.setProperty('WAVVE_M_CREDENTIAL','')
  HbcBODGIFuJVixALrpvygndlRWakSq.setProperty('WAVVE_M_LOGINTIME','')
 def cookiefile_save(HbcBODGIFuJVixALrpvygndlRWakqj):
  HbcBODGIFuJVixALrpvygndlRWakKU =HbcBODGIFuJVixALrpvygndlRWakqj.WavveObj.Get_Now_Datetime()
  HbcBODGIFuJVixALrpvygndlRWakKz=HbcBODGIFuJVixALrpvygndlRWakKU+datetime.timedelta(days=HbcBODGIFuJVixALrpvygndlRWakzP(__addon__.getSetting('cache_ttl')))
  HbcBODGIFuJVixALrpvygndlRWakSq=xbmcgui.Window(10000)
  HbcBODGIFuJVixALrpvygndlRWakKE={'wavve_token':HbcBODGIFuJVixALrpvygndlRWakSq.getProperty('WAVVE_M_CREDENTIAL'),'wavve_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'wavve_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'wavve_profile':__addon__.getSetting('selected_profile'),'wavve_limitdate':HbcBODGIFuJVixALrpvygndlRWakKz.strftime('%Y-%m-%d')}
  try: 
   fp=HbcBODGIFuJVixALrpvygndlRWakzM(HbcBODGIFuJVixALrpvygndlRWakqE,'w',-1,'utf-8')
   json.dump(HbcBODGIFuJVixALrpvygndlRWakKE,fp)
   fp.close()
  except HbcBODGIFuJVixALrpvygndlRWakzo as exception:
   HbcBODGIFuJVixALrpvygndlRWakEq(exception)
 def cookiefile_check(HbcBODGIFuJVixALrpvygndlRWakqj):
  HbcBODGIFuJVixALrpvygndlRWakKE={}
  try: 
   fp=HbcBODGIFuJVixALrpvygndlRWakzM(HbcBODGIFuJVixALrpvygndlRWakqE,'r',-1,'utf-8')
   HbcBODGIFuJVixALrpvygndlRWakKE= json.load(fp)
   fp.close()
  except HbcBODGIFuJVixALrpvygndlRWakzo as exception:
   HbcBODGIFuJVixALrpvygndlRWakqj.wininfo_clear()
   return HbcBODGIFuJVixALrpvygndlRWakze
  HbcBODGIFuJVixALrpvygndlRWakSN =__addon__.getSetting('id')
  HbcBODGIFuJVixALrpvygndlRWakST =__addon__.getSetting('pw')
  HbcBODGIFuJVixALrpvygndlRWakKj =__addon__.getSetting('selected_profile')
  HbcBODGIFuJVixALrpvygndlRWakKE['wavve_id']=base64.standard_b64decode(HbcBODGIFuJVixALrpvygndlRWakKE['wavve_id']).decode('utf-8')
  HbcBODGIFuJVixALrpvygndlRWakKE['wavve_pw']=base64.standard_b64decode(HbcBODGIFuJVixALrpvygndlRWakKE['wavve_pw']).decode('utf-8')
  if HbcBODGIFuJVixALrpvygndlRWakSN!=HbcBODGIFuJVixALrpvygndlRWakKE['wavve_id']or HbcBODGIFuJVixALrpvygndlRWakST!=HbcBODGIFuJVixALrpvygndlRWakKE['wavve_pw']or HbcBODGIFuJVixALrpvygndlRWakKj!=HbcBODGIFuJVixALrpvygndlRWakKE['wavve_profile']:
   HbcBODGIFuJVixALrpvygndlRWakqj.wininfo_clear()
   return HbcBODGIFuJVixALrpvygndlRWakze
  HbcBODGIFuJVixALrpvygndlRWakSQ =HbcBODGIFuJVixALrpvygndlRWakzP(HbcBODGIFuJVixALrpvygndlRWakqj.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  HbcBODGIFuJVixALrpvygndlRWakKC=HbcBODGIFuJVixALrpvygndlRWakKE['wavve_limitdate']
  HbcBODGIFuJVixALrpvygndlRWakSP =HbcBODGIFuJVixALrpvygndlRWakzP(re.sub('-','',HbcBODGIFuJVixALrpvygndlRWakKC))
  if HbcBODGIFuJVixALrpvygndlRWakSP<HbcBODGIFuJVixALrpvygndlRWakSQ:
   HbcBODGIFuJVixALrpvygndlRWakqj.wininfo_clear()
   return HbcBODGIFuJVixALrpvygndlRWakze
  HbcBODGIFuJVixALrpvygndlRWakSq=xbmcgui.Window(10000)
  HbcBODGIFuJVixALrpvygndlRWakSq.setProperty('WAVVE_M_CREDENTIAL',HbcBODGIFuJVixALrpvygndlRWakKE['wavve_token'])
  HbcBODGIFuJVixALrpvygndlRWakSq.setProperty('WAVVE_M_LOGINTIME',HbcBODGIFuJVixALrpvygndlRWakKC)
  return HbcBODGIFuJVixALrpvygndlRWakzs
 def dp_LiveCatagory_List(HbcBODGIFuJVixALrpvygndlRWakqj,args):
  HbcBODGIFuJVixALrpvygndlRWakqj.WavveObj.SaveCredential(HbcBODGIFuJVixALrpvygndlRWakqj.get_winCredential())
  HbcBODGIFuJVixALrpvygndlRWakKt =args.get('sCode')
  HbcBODGIFuJVixALrpvygndlRWakKw=args.get('sIndex')
  HbcBODGIFuJVixALrpvygndlRWakKX,HbcBODGIFuJVixALrpvygndlRWakKN=HbcBODGIFuJVixALrpvygndlRWakqj.WavveObj.Get_LiveCatagory_List(HbcBODGIFuJVixALrpvygndlRWakKt,HbcBODGIFuJVixALrpvygndlRWakKw)
  for HbcBODGIFuJVixALrpvygndlRWakKT in HbcBODGIFuJVixALrpvygndlRWakKX:
   HbcBODGIFuJVixALrpvygndlRWakSK =HbcBODGIFuJVixALrpvygndlRWakKT.get('title')
   HbcBODGIFuJVixALrpvygndlRWakSj={'mode':'LIVE_LIST','genre':HbcBODGIFuJVixALrpvygndlRWakKT.get('genre'),'baseapi':HbcBODGIFuJVixALrpvygndlRWakKN}
   HbcBODGIFuJVixALrpvygndlRWakqj.add_dir(HbcBODGIFuJVixALrpvygndlRWakSK,sublabel='',img='',infoLabels=HbcBODGIFuJVixALrpvygndlRWakzQ,isFolder=HbcBODGIFuJVixALrpvygndlRWakzs,params=HbcBODGIFuJVixALrpvygndlRWakSj)
  if HbcBODGIFuJVixALrpvygndlRWakzh(HbcBODGIFuJVixALrpvygndlRWakKX)>0:xbmcplugin.endOfDirectory(HbcBODGIFuJVixALrpvygndlRWakqj._addon_handle,cacheToDisc=HbcBODGIFuJVixALrpvygndlRWakze)
 def dp_MainCatagory_List(HbcBODGIFuJVixALrpvygndlRWakqj,args):
  HbcBODGIFuJVixALrpvygndlRWakqj.WavveObj.SaveCredential(HbcBODGIFuJVixALrpvygndlRWakqj.get_winCredential())
  HbcBODGIFuJVixALrpvygndlRWakKt =args.get('sCode')
  HbcBODGIFuJVixALrpvygndlRWakKw=args.get('sIndex')
  HbcBODGIFuJVixALrpvygndlRWakKS =args.get('sType')
  HbcBODGIFuJVixALrpvygndlRWakKX=HbcBODGIFuJVixALrpvygndlRWakqj.WavveObj.Get_MainCatagory_List(HbcBODGIFuJVixALrpvygndlRWakKt,HbcBODGIFuJVixALrpvygndlRWakKw)
  for HbcBODGIFuJVixALrpvygndlRWakKT in HbcBODGIFuJVixALrpvygndlRWakKX:
   if HbcBODGIFuJVixALrpvygndlRWakKS=='vod':
    if HbcBODGIFuJVixALrpvygndlRWakKT.get('subtype')=='catagory':
     HbcBODGIFuJVixALrpvygndlRWakSh='PROGRAM_LIST'
    else:
     HbcBODGIFuJVixALrpvygndlRWakSh='SUPERSECTION_LIST'
   elif HbcBODGIFuJVixALrpvygndlRWakKS=='movie':
    HbcBODGIFuJVixALrpvygndlRWakSh='MOVIE_LIST'
   else:
    HbcBODGIFuJVixALrpvygndlRWakSh=''
   HbcBODGIFuJVixALrpvygndlRWakSK='%s (%s)'%(HbcBODGIFuJVixALrpvygndlRWakKT.get('title'),args.get('ordernm'))
   HbcBODGIFuJVixALrpvygndlRWakSj={'mode':HbcBODGIFuJVixALrpvygndlRWakSh,'suburl':HbcBODGIFuJVixALrpvygndlRWakKT.get('suburl'),'subapi':HbcBODGIFuJVixALrpvygndlRWakKT.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if HbcBODGIFuJVixALrpvygndlRWakqj.get_settings_exclusion21():
    if HbcBODGIFuJVixALrpvygndlRWakKT.get('title')=='성인' or HbcBODGIFuJVixALrpvygndlRWakKT.get('title')=='성인+':continue
   HbcBODGIFuJVixALrpvygndlRWakqj.add_dir(HbcBODGIFuJVixALrpvygndlRWakSK,sublabel='',img='',infoLabels=HbcBODGIFuJVixALrpvygndlRWakzQ,isFolder=HbcBODGIFuJVixALrpvygndlRWakzs,params=HbcBODGIFuJVixALrpvygndlRWakSj)
  if HbcBODGIFuJVixALrpvygndlRWakzh(HbcBODGIFuJVixALrpvygndlRWakKX)>0:xbmcplugin.endOfDirectory(HbcBODGIFuJVixALrpvygndlRWakqj._addon_handle,cacheToDisc=HbcBODGIFuJVixALrpvygndlRWakze)
 def dp_Program_List(HbcBODGIFuJVixALrpvygndlRWakqj,args):
  HbcBODGIFuJVixALrpvygndlRWakqj.WavveObj.SaveCredential(HbcBODGIFuJVixALrpvygndlRWakqj.get_winCredential())
  HbcBODGIFuJVixALrpvygndlRWakKm =args.get('subapi')
  HbcBODGIFuJVixALrpvygndlRWakKf=HbcBODGIFuJVixALrpvygndlRWakzP(args.get('page'))
  HbcBODGIFuJVixALrpvygndlRWakSs =args.get('orderby')
  HbcBODGIFuJVixALrpvygndlRWakKX,HbcBODGIFuJVixALrpvygndlRWakKQ=HbcBODGIFuJVixALrpvygndlRWakqj.WavveObj.Get_Program_List(HbcBODGIFuJVixALrpvygndlRWakKm,HbcBODGIFuJVixALrpvygndlRWakKf,HbcBODGIFuJVixALrpvygndlRWakSs)
  for HbcBODGIFuJVixALrpvygndlRWakKT in HbcBODGIFuJVixALrpvygndlRWakKX:
   HbcBODGIFuJVixALrpvygndlRWakSK =HbcBODGIFuJVixALrpvygndlRWakKT.get('title')
   HbcBODGIFuJVixALrpvygndlRWakKP=HbcBODGIFuJVixALrpvygndlRWakKT.get('thumbnail')
   HbcBODGIFuJVixALrpvygndlRWakKe =HbcBODGIFuJVixALrpvygndlRWakKT.get('age')
   if HbcBODGIFuJVixALrpvygndlRWakKe=='18' or HbcBODGIFuJVixALrpvygndlRWakKe=='19' or HbcBODGIFuJVixALrpvygndlRWakKe=='21':HbcBODGIFuJVixALrpvygndlRWakSK+=' (%s)'%(HbcBODGIFuJVixALrpvygndlRWakKe)
   HbcBODGIFuJVixALrpvygndlRWakKs={'plot':HbcBODGIFuJVixALrpvygndlRWakSK,'mpaa':HbcBODGIFuJVixALrpvygndlRWakKe,'mediatype':'episode'}
   HbcBODGIFuJVixALrpvygndlRWakSj={'mode':'EPISODE_LIST','videoid':HbcBODGIFuJVixALrpvygndlRWakKT.get('videoid'),'vidtype':HbcBODGIFuJVixALrpvygndlRWakKT.get('vidtype'),'page':'1'}
   HbcBODGIFuJVixALrpvygndlRWakqj.add_dir(HbcBODGIFuJVixALrpvygndlRWakSK,sublabel='',img=HbcBODGIFuJVixALrpvygndlRWakKP,infoLabels=HbcBODGIFuJVixALrpvygndlRWakKs,isFolder=HbcBODGIFuJVixALrpvygndlRWakzs,params=HbcBODGIFuJVixALrpvygndlRWakSj)
  if HbcBODGIFuJVixALrpvygndlRWakKQ:
   HbcBODGIFuJVixALrpvygndlRWakSj={}
   HbcBODGIFuJVixALrpvygndlRWakSj['mode'] ='PROGRAM_LIST' 
   HbcBODGIFuJVixALrpvygndlRWakSj['subapi']=HbcBODGIFuJVixALrpvygndlRWakKm 
   HbcBODGIFuJVixALrpvygndlRWakSj['page'] =HbcBODGIFuJVixALrpvygndlRWakES(HbcBODGIFuJVixALrpvygndlRWakKf+1)
   HbcBODGIFuJVixALrpvygndlRWakSK='[B]%s >>[/B]'%'다음 페이지'
   HbcBODGIFuJVixALrpvygndlRWakKh=HbcBODGIFuJVixALrpvygndlRWakES(HbcBODGIFuJVixALrpvygndlRWakKf+1)
   HbcBODGIFuJVixALrpvygndlRWakqj.add_dir(HbcBODGIFuJVixALrpvygndlRWakSK,sublabel=HbcBODGIFuJVixALrpvygndlRWakKh,img='',infoLabels=HbcBODGIFuJVixALrpvygndlRWakzQ,isFolder=HbcBODGIFuJVixALrpvygndlRWakzs,params=HbcBODGIFuJVixALrpvygndlRWakSj)
  if HbcBODGIFuJVixALrpvygndlRWakzh(HbcBODGIFuJVixALrpvygndlRWakKX)>0:xbmcplugin.endOfDirectory(HbcBODGIFuJVixALrpvygndlRWakqj._addon_handle,cacheToDisc=HbcBODGIFuJVixALrpvygndlRWakze)
 def dp_SuperSection_List(HbcBODGIFuJVixALrpvygndlRWakqj,args):
  HbcBODGIFuJVixALrpvygndlRWakqj.WavveObj.SaveCredential(HbcBODGIFuJVixALrpvygndlRWakqj.get_winCredential())
  HbcBODGIFuJVixALrpvygndlRWakKM =args.get('suburl')
  HbcBODGIFuJVixALrpvygndlRWakKX=HbcBODGIFuJVixALrpvygndlRWakqj.WavveObj.Get_SuperMultiSection_List(HbcBODGIFuJVixALrpvygndlRWakKM)
  for HbcBODGIFuJVixALrpvygndlRWakKT in HbcBODGIFuJVixALrpvygndlRWakKX:
   HbcBODGIFuJVixALrpvygndlRWakSK =HbcBODGIFuJVixALrpvygndlRWakKT.get('title')
   HbcBODGIFuJVixALrpvygndlRWakKm =HbcBODGIFuJVixALrpvygndlRWakKT.get('subapi')
   HbcBODGIFuJVixALrpvygndlRWakKY=HbcBODGIFuJVixALrpvygndlRWakKT.get('cell_type')
   if HbcBODGIFuJVixALrpvygndlRWakKm.find('mtype=svod')>=0 or HbcBODGIFuJVixALrpvygndlRWakKm.find('mtype=ppv')>=0:
    HbcBODGIFuJVixALrpvygndlRWakSh='MOVIE_LIST'
   elif HbcBODGIFuJVixALrpvygndlRWakKY=='band_71':
    HbcBODGIFuJVixALrpvygndlRWakSh ='SUPERSECTION_LIST'
    (HbcBODGIFuJVixALrpvygndlRWakKo,HbcBODGIFuJVixALrpvygndlRWakzq)=HbcBODGIFuJVixALrpvygndlRWakqj.WavveObj.Baseapi_Parse(HbcBODGIFuJVixALrpvygndlRWakKm)
    HbcBODGIFuJVixALrpvygndlRWakKM=HbcBODGIFuJVixALrpvygndlRWakzq.get('api')
    HbcBODGIFuJVixALrpvygndlRWakKm=''
   elif HbcBODGIFuJVixALrpvygndlRWakKY=='band_2':
    HbcBODGIFuJVixALrpvygndlRWakSh='BAND2SECTION_LIST'
   elif HbcBODGIFuJVixALrpvygndlRWakKY=='band_live':
    HbcBODGIFuJVixALrpvygndlRWakSh='BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}',HbcBODGIFuJVixALrpvygndlRWakKm):
    HbcBODGIFuJVixALrpvygndlRWakSh='MOVIE_LIST'
   else:
    HbcBODGIFuJVixALrpvygndlRWakSh='PROGRAM_LIST'
   HbcBODGIFuJVixALrpvygndlRWakKs={'plot':HbcBODGIFuJVixALrpvygndlRWakSK,'mediatype':'episode'}
   HbcBODGIFuJVixALrpvygndlRWakSj={'mode':HbcBODGIFuJVixALrpvygndlRWakSh,'suburl':HbcBODGIFuJVixALrpvygndlRWakKM,'subapi':HbcBODGIFuJVixALrpvygndlRWakKm,'page':'1'}
   HbcBODGIFuJVixALrpvygndlRWakqj.add_dir(HbcBODGIFuJVixALrpvygndlRWakSK,sublabel='',img=HbcBODGIFuJVixALrpvygndlRWakzQ,infoLabels=HbcBODGIFuJVixALrpvygndlRWakKs,isFolder=HbcBODGIFuJVixALrpvygndlRWakzs,params=HbcBODGIFuJVixALrpvygndlRWakSj)
  if HbcBODGIFuJVixALrpvygndlRWakzh(HbcBODGIFuJVixALrpvygndlRWakKX)>0:xbmcplugin.endOfDirectory(HbcBODGIFuJVixALrpvygndlRWakqj._addon_handle,cacheToDisc=HbcBODGIFuJVixALrpvygndlRWakze)
 def dp_BandLiveSection_List(HbcBODGIFuJVixALrpvygndlRWakqj,args):
  HbcBODGIFuJVixALrpvygndlRWakqj.WavveObj.SaveCredential(HbcBODGIFuJVixALrpvygndlRWakqj.get_winCredential())
  HbcBODGIFuJVixALrpvygndlRWakKm =args.get('subapi')
  HbcBODGIFuJVixALrpvygndlRWakKf=HbcBODGIFuJVixALrpvygndlRWakzP(args.get('page'))
  HbcBODGIFuJVixALrpvygndlRWakKX,HbcBODGIFuJVixALrpvygndlRWakKQ=HbcBODGIFuJVixALrpvygndlRWakqj.WavveObj.Get_BandLiveSection_List(HbcBODGIFuJVixALrpvygndlRWakKm,HbcBODGIFuJVixALrpvygndlRWakKf)
  for HbcBODGIFuJVixALrpvygndlRWakKT in HbcBODGIFuJVixALrpvygndlRWakKX:
   HbcBODGIFuJVixALrpvygndlRWakzS =HbcBODGIFuJVixALrpvygndlRWakKT.get('channelid')
   HbcBODGIFuJVixALrpvygndlRWakzU =HbcBODGIFuJVixALrpvygndlRWakKT.get('studio')
   HbcBODGIFuJVixALrpvygndlRWakzK=HbcBODGIFuJVixALrpvygndlRWakKT.get('tvshowtitle')
   HbcBODGIFuJVixALrpvygndlRWakKP =HbcBODGIFuJVixALrpvygndlRWakKT.get('thumbnail')
   HbcBODGIFuJVixALrpvygndlRWakKe =HbcBODGIFuJVixALrpvygndlRWakKT.get('age')
   HbcBODGIFuJVixALrpvygndlRWakKs={'mediatype':'video','mpaa':HbcBODGIFuJVixALrpvygndlRWakKe,'title':'%s < %s >'%(HbcBODGIFuJVixALrpvygndlRWakzU,HbcBODGIFuJVixALrpvygndlRWakzK),'tvshowtitle':HbcBODGIFuJVixALrpvygndlRWakzK,'studio':HbcBODGIFuJVixALrpvygndlRWakzU,'plot':HbcBODGIFuJVixALrpvygndlRWakzU}
   HbcBODGIFuJVixALrpvygndlRWakSj={'mode':'LIVE','contentid':HbcBODGIFuJVixALrpvygndlRWakzS}
   HbcBODGIFuJVixALrpvygndlRWakqj.add_dir(HbcBODGIFuJVixALrpvygndlRWakzU,sublabel=HbcBODGIFuJVixALrpvygndlRWakzK,img=HbcBODGIFuJVixALrpvygndlRWakKT.get('thumbnail'),infoLabels=HbcBODGIFuJVixALrpvygndlRWakKs,isFolder=HbcBODGIFuJVixALrpvygndlRWakze,params=HbcBODGIFuJVixALrpvygndlRWakSj)
  if HbcBODGIFuJVixALrpvygndlRWakKQ:
   HbcBODGIFuJVixALrpvygndlRWakSj={}
   HbcBODGIFuJVixALrpvygndlRWakSj['mode'] ='BANDLIVESECTION_LIST' 
   HbcBODGIFuJVixALrpvygndlRWakSj['subapi']=HbcBODGIFuJVixALrpvygndlRWakKm
   HbcBODGIFuJVixALrpvygndlRWakSj['page'] =HbcBODGIFuJVixALrpvygndlRWakES(HbcBODGIFuJVixALrpvygndlRWakKf+1)
   HbcBODGIFuJVixALrpvygndlRWakSK='[B]%s >>[/B]'%'다음 페이지'
   HbcBODGIFuJVixALrpvygndlRWakKh=HbcBODGIFuJVixALrpvygndlRWakES(HbcBODGIFuJVixALrpvygndlRWakKf+1)
   HbcBODGIFuJVixALrpvygndlRWakqj.add_dir(HbcBODGIFuJVixALrpvygndlRWakSK,sublabel=HbcBODGIFuJVixALrpvygndlRWakKh,img='',infoLabels=HbcBODGIFuJVixALrpvygndlRWakzQ,isFolder=HbcBODGIFuJVixALrpvygndlRWakzs,params=HbcBODGIFuJVixALrpvygndlRWakSj)
  if HbcBODGIFuJVixALrpvygndlRWakzh(HbcBODGIFuJVixALrpvygndlRWakKX)>0:xbmcplugin.endOfDirectory(HbcBODGIFuJVixALrpvygndlRWakqj._addon_handle,cacheToDisc=HbcBODGIFuJVixALrpvygndlRWakze)
 def dp_Band2Section_List(HbcBODGIFuJVixALrpvygndlRWakqj,args):
  HbcBODGIFuJVixALrpvygndlRWakqj.WavveObj.SaveCredential(HbcBODGIFuJVixALrpvygndlRWakqj.get_winCredential())
  HbcBODGIFuJVixALrpvygndlRWakKm =args.get('subapi')
  HbcBODGIFuJVixALrpvygndlRWakKf=HbcBODGIFuJVixALrpvygndlRWakzP(args.get('page'))
  HbcBODGIFuJVixALrpvygndlRWakKX,HbcBODGIFuJVixALrpvygndlRWakKQ=HbcBODGIFuJVixALrpvygndlRWakqj.WavveObj.Get_Band2Section_List(HbcBODGIFuJVixALrpvygndlRWakKm,HbcBODGIFuJVixALrpvygndlRWakKf)
  for HbcBODGIFuJVixALrpvygndlRWakKT in HbcBODGIFuJVixALrpvygndlRWakKX:
   HbcBODGIFuJVixALrpvygndlRWakSK =HbcBODGIFuJVixALrpvygndlRWakKT.get('programtitle')
   HbcBODGIFuJVixALrpvygndlRWakKh =HbcBODGIFuJVixALrpvygndlRWakKT.get('episodetitle')
   HbcBODGIFuJVixALrpvygndlRWakKs={'plot':HbcBODGIFuJVixALrpvygndlRWakSK+'\n\n'+HbcBODGIFuJVixALrpvygndlRWakKh,'mpaa':HbcBODGIFuJVixALrpvygndlRWakKT.get('age'),'mediatype':'episode'}
   HbcBODGIFuJVixALrpvygndlRWakSj={'mode':'VOD','programid':'-','contentid':HbcBODGIFuJVixALrpvygndlRWakKT.get('videoid'),'thumbnail':HbcBODGIFuJVixALrpvygndlRWakKT.get('thumbnail'),'title':HbcBODGIFuJVixALrpvygndlRWakSK,'subtitle':HbcBODGIFuJVixALrpvygndlRWakKh}
   HbcBODGIFuJVixALrpvygndlRWakqj.add_dir(HbcBODGIFuJVixALrpvygndlRWakSK,sublabel=HbcBODGIFuJVixALrpvygndlRWakKh,img=HbcBODGIFuJVixALrpvygndlRWakKT.get('thumbnail'),infoLabels=HbcBODGIFuJVixALrpvygndlRWakKs,isFolder=HbcBODGIFuJVixALrpvygndlRWakze,params=HbcBODGIFuJVixALrpvygndlRWakSj)
  if HbcBODGIFuJVixALrpvygndlRWakKQ:
   HbcBODGIFuJVixALrpvygndlRWakSj={}
   HbcBODGIFuJVixALrpvygndlRWakSj['mode'] ='BAND2SECTION_LIST' 
   HbcBODGIFuJVixALrpvygndlRWakSj['subapi']=HbcBODGIFuJVixALrpvygndlRWakKm
   HbcBODGIFuJVixALrpvygndlRWakSj['page'] =HbcBODGIFuJVixALrpvygndlRWakES(HbcBODGIFuJVixALrpvygndlRWakKf+1)
   HbcBODGIFuJVixALrpvygndlRWakSK='[B]%s >>[/B]'%'다음 페이지'
   HbcBODGIFuJVixALrpvygndlRWakKh=HbcBODGIFuJVixALrpvygndlRWakES(HbcBODGIFuJVixALrpvygndlRWakKf+1)
   HbcBODGIFuJVixALrpvygndlRWakqj.add_dir(HbcBODGIFuJVixALrpvygndlRWakSK,sublabel=HbcBODGIFuJVixALrpvygndlRWakKh,img='',infoLabels=HbcBODGIFuJVixALrpvygndlRWakzQ,isFolder=HbcBODGIFuJVixALrpvygndlRWakzs,params=HbcBODGIFuJVixALrpvygndlRWakSj)
  if HbcBODGIFuJVixALrpvygndlRWakzh(HbcBODGIFuJVixALrpvygndlRWakKX)>0:xbmcplugin.endOfDirectory(HbcBODGIFuJVixALrpvygndlRWakqj._addon_handle,cacheToDisc=HbcBODGIFuJVixALrpvygndlRWakze)
 def dp_Movie_List(HbcBODGIFuJVixALrpvygndlRWakqj,args):
  HbcBODGIFuJVixALrpvygndlRWakqj.WavveObj.SaveCredential(HbcBODGIFuJVixALrpvygndlRWakqj.get_winCredential())
  HbcBODGIFuJVixALrpvygndlRWakKm =args.get('subapi')
  HbcBODGIFuJVixALrpvygndlRWakKf=HbcBODGIFuJVixALrpvygndlRWakzP(args.get('page'))
  HbcBODGIFuJVixALrpvygndlRWakKX,HbcBODGIFuJVixALrpvygndlRWakKQ=HbcBODGIFuJVixALrpvygndlRWakqj.WavveObj.Get_Movie_List(HbcBODGIFuJVixALrpvygndlRWakKm,HbcBODGIFuJVixALrpvygndlRWakKf)
  for HbcBODGIFuJVixALrpvygndlRWakKT in HbcBODGIFuJVixALrpvygndlRWakKX:
   HbcBODGIFuJVixALrpvygndlRWakSK =HbcBODGIFuJVixALrpvygndlRWakKT.get('title')
   HbcBODGIFuJVixALrpvygndlRWakKP=HbcBODGIFuJVixALrpvygndlRWakKT.get('thumbnail')
   HbcBODGIFuJVixALrpvygndlRWakKe =HbcBODGIFuJVixALrpvygndlRWakKT.get('age')
   if HbcBODGIFuJVixALrpvygndlRWakKe=='18' or HbcBODGIFuJVixALrpvygndlRWakKe=='19' or HbcBODGIFuJVixALrpvygndlRWakKe=='21':HbcBODGIFuJVixALrpvygndlRWakSK+=' (%s)'%(HbcBODGIFuJVixALrpvygndlRWakKe)
   HbcBODGIFuJVixALrpvygndlRWakKs={'plot':HbcBODGIFuJVixALrpvygndlRWakSK,'mpaa':HbcBODGIFuJVixALrpvygndlRWakKe,'mediatype':'movie'}
   HbcBODGIFuJVixALrpvygndlRWakSj={'mode':'MOVIE','contentid':HbcBODGIFuJVixALrpvygndlRWakKT.get('videoid'),'title':HbcBODGIFuJVixALrpvygndlRWakSK,'thumbnail':HbcBODGIFuJVixALrpvygndlRWakKP,'age':HbcBODGIFuJVixALrpvygndlRWakKe}
   HbcBODGIFuJVixALrpvygndlRWakqj.add_dir(HbcBODGIFuJVixALrpvygndlRWakSK,sublabel='',img=HbcBODGIFuJVixALrpvygndlRWakKP,infoLabels=HbcBODGIFuJVixALrpvygndlRWakKs,isFolder=HbcBODGIFuJVixALrpvygndlRWakze,params=HbcBODGIFuJVixALrpvygndlRWakSj)
  if HbcBODGIFuJVixALrpvygndlRWakKQ:
   HbcBODGIFuJVixALrpvygndlRWakSj={}
   HbcBODGIFuJVixALrpvygndlRWakSj['mode'] ='MOVIE_LIST' 
   HbcBODGIFuJVixALrpvygndlRWakSj['subapi']=HbcBODGIFuJVixALrpvygndlRWakKm 
   HbcBODGIFuJVixALrpvygndlRWakSj['page'] =HbcBODGIFuJVixALrpvygndlRWakES(HbcBODGIFuJVixALrpvygndlRWakKf+1)
   HbcBODGIFuJVixALrpvygndlRWakSK='[B]%s >>[/B]'%'다음 페이지'
   HbcBODGIFuJVixALrpvygndlRWakKh=HbcBODGIFuJVixALrpvygndlRWakES(HbcBODGIFuJVixALrpvygndlRWakKf+1)
   HbcBODGIFuJVixALrpvygndlRWakqj.add_dir(HbcBODGIFuJVixALrpvygndlRWakSK,sublabel=HbcBODGIFuJVixALrpvygndlRWakKh,img='',infoLabels=HbcBODGIFuJVixALrpvygndlRWakzQ,isFolder=HbcBODGIFuJVixALrpvygndlRWakzs,params=HbcBODGIFuJVixALrpvygndlRWakSj)
  if HbcBODGIFuJVixALrpvygndlRWakzh(HbcBODGIFuJVixALrpvygndlRWakKX)>0:xbmcplugin.endOfDirectory(HbcBODGIFuJVixALrpvygndlRWakqj._addon_handle,cacheToDisc=HbcBODGIFuJVixALrpvygndlRWakze)
 def dp_Episode_List(HbcBODGIFuJVixALrpvygndlRWakqj,args):
  HbcBODGIFuJVixALrpvygndlRWakqj.WavveObj.SaveCredential(HbcBODGIFuJVixALrpvygndlRWakqj.get_winCredential())
  HbcBODGIFuJVixALrpvygndlRWakzE =args.get('videoid')
  HbcBODGIFuJVixALrpvygndlRWakzj =args.get('vidtype')
  HbcBODGIFuJVixALrpvygndlRWakKf=HbcBODGIFuJVixALrpvygndlRWakzP(args.get('page'))
  HbcBODGIFuJVixALrpvygndlRWakKX,HbcBODGIFuJVixALrpvygndlRWakKQ=HbcBODGIFuJVixALrpvygndlRWakqj.WavveObj.Get_Episode_List(HbcBODGIFuJVixALrpvygndlRWakzE,HbcBODGIFuJVixALrpvygndlRWakzj,HbcBODGIFuJVixALrpvygndlRWakKf,orderby=HbcBODGIFuJVixALrpvygndlRWakqj.get_winEpisodeOrderby())
  for HbcBODGIFuJVixALrpvygndlRWakKT in HbcBODGIFuJVixALrpvygndlRWakKX:
   HbcBODGIFuJVixALrpvygndlRWakKh='%s회, %s(%s)'%(HbcBODGIFuJVixALrpvygndlRWakKT.get('episodenumber'),HbcBODGIFuJVixALrpvygndlRWakKT.get('releasedate'),HbcBODGIFuJVixALrpvygndlRWakKT.get('releaseweekday'))
   HbcBODGIFuJVixALrpvygndlRWakzC ='[%s]\n\n%s'%(HbcBODGIFuJVixALrpvygndlRWakKT.get('episodetitle'),HbcBODGIFuJVixALrpvygndlRWakKT.get('synopsis'))
   HbcBODGIFuJVixALrpvygndlRWakKs={'mediatype':'episode','title':HbcBODGIFuJVixALrpvygndlRWakKT.get('programtitle'),'year':HbcBODGIFuJVixALrpvygndlRWakzP(HbcBODGIFuJVixALrpvygndlRWakKT.get('releasedate')[:4]),'aired':HbcBODGIFuJVixALrpvygndlRWakKT.get('releasedate'),'mpaa':HbcBODGIFuJVixALrpvygndlRWakKT.get('age'),'episode':HbcBODGIFuJVixALrpvygndlRWakKT.get('episodenumber'),'duration':HbcBODGIFuJVixALrpvygndlRWakKT.get('playtime'),'plot':HbcBODGIFuJVixALrpvygndlRWakzC,'cast':HbcBODGIFuJVixALrpvygndlRWakKT.get('episodeactors')}
   HbcBODGIFuJVixALrpvygndlRWakSj={'mode':'VOD','programid':HbcBODGIFuJVixALrpvygndlRWakKT.get('programid'),'contentid':HbcBODGIFuJVixALrpvygndlRWakKT.get('contentid'),'thumbnail':HbcBODGIFuJVixALrpvygndlRWakKT.get('thumbnail'),'title':HbcBODGIFuJVixALrpvygndlRWakKT.get('programtitle'),'subtitle':HbcBODGIFuJVixALrpvygndlRWakKh}
   HbcBODGIFuJVixALrpvygndlRWakqj.add_dir(HbcBODGIFuJVixALrpvygndlRWakKT.get('programtitle'),sublabel=HbcBODGIFuJVixALrpvygndlRWakKh,img=HbcBODGIFuJVixALrpvygndlRWakKT.get('thumbnail'),infoLabels=HbcBODGIFuJVixALrpvygndlRWakKs,isFolder=HbcBODGIFuJVixALrpvygndlRWakze,params=HbcBODGIFuJVixALrpvygndlRWakSj)
  if HbcBODGIFuJVixALrpvygndlRWakKf==1:
   HbcBODGIFuJVixALrpvygndlRWakKs={'plot':'정렬순서를 변경합니다.'}
   HbcBODGIFuJVixALrpvygndlRWakSj={}
   HbcBODGIFuJVixALrpvygndlRWakSj['mode'] ='ORDER_BY' 
   if HbcBODGIFuJVixALrpvygndlRWakqj.get_winEpisodeOrderby()=='desc':
    HbcBODGIFuJVixALrpvygndlRWakSK='정렬순서변경 : 최신화부터 -> 1회부터'
    HbcBODGIFuJVixALrpvygndlRWakSj['orderby']='asc'
   else:
    HbcBODGIFuJVixALrpvygndlRWakSK='정렬순서변경 : 1회부터 -> 최신화부터'
    HbcBODGIFuJVixALrpvygndlRWakSj['orderby']='desc'
   HbcBODGIFuJVixALrpvygndlRWakqj.add_dir(HbcBODGIFuJVixALrpvygndlRWakSK,sublabel='',img='',infoLabels=HbcBODGIFuJVixALrpvygndlRWakKs,isFolder=HbcBODGIFuJVixALrpvygndlRWakze,params=HbcBODGIFuJVixALrpvygndlRWakSj)
  if HbcBODGIFuJVixALrpvygndlRWakKQ:
   HbcBODGIFuJVixALrpvygndlRWakSj={}
   HbcBODGIFuJVixALrpvygndlRWakSj['mode'] ='EPISODE_LIST' 
   HbcBODGIFuJVixALrpvygndlRWakSj['videoid']=HbcBODGIFuJVixALrpvygndlRWakKT.get('programid')
   HbcBODGIFuJVixALrpvygndlRWakSj['vidtype']='programid'
   HbcBODGIFuJVixALrpvygndlRWakSj['page'] =HbcBODGIFuJVixALrpvygndlRWakES(HbcBODGIFuJVixALrpvygndlRWakKf+1)
   HbcBODGIFuJVixALrpvygndlRWakSK='[B]%s >>[/B]'%'다음 페이지'
   HbcBODGIFuJVixALrpvygndlRWakKh=HbcBODGIFuJVixALrpvygndlRWakES(HbcBODGIFuJVixALrpvygndlRWakKf+1)
   HbcBODGIFuJVixALrpvygndlRWakqj.add_dir(HbcBODGIFuJVixALrpvygndlRWakSK,sublabel=HbcBODGIFuJVixALrpvygndlRWakKh,img='',infoLabels=HbcBODGIFuJVixALrpvygndlRWakzQ,isFolder=HbcBODGIFuJVixALrpvygndlRWakzs,params=HbcBODGIFuJVixALrpvygndlRWakSj)
  if HbcBODGIFuJVixALrpvygndlRWakzh(HbcBODGIFuJVixALrpvygndlRWakKX)>0:xbmcplugin.endOfDirectory(HbcBODGIFuJVixALrpvygndlRWakqj._addon_handle,cacheToDisc=HbcBODGIFuJVixALrpvygndlRWakze)
 def dp_LiveChannel_List(HbcBODGIFuJVixALrpvygndlRWakqj,args):
  HbcBODGIFuJVixALrpvygndlRWakqj.WavveObj.SaveCredential(HbcBODGIFuJVixALrpvygndlRWakqj.get_winCredential())
  HbcBODGIFuJVixALrpvygndlRWakzt =args.get('genre')
  HbcBODGIFuJVixALrpvygndlRWakKN=args.get('baseapi')
  HbcBODGIFuJVixALrpvygndlRWakKX=HbcBODGIFuJVixALrpvygndlRWakqj.WavveObj.Get_LiveChannel_List(HbcBODGIFuJVixALrpvygndlRWakzt,HbcBODGIFuJVixALrpvygndlRWakKN)
  for HbcBODGIFuJVixALrpvygndlRWakKT in HbcBODGIFuJVixALrpvygndlRWakKX:
   HbcBODGIFuJVixALrpvygndlRWakzS =HbcBODGIFuJVixALrpvygndlRWakKT.get('channelid')
   HbcBODGIFuJVixALrpvygndlRWakzU =HbcBODGIFuJVixALrpvygndlRWakKT.get('studio')
   HbcBODGIFuJVixALrpvygndlRWakzK=HbcBODGIFuJVixALrpvygndlRWakKT.get('tvshowtitle')
   HbcBODGIFuJVixALrpvygndlRWakKP =HbcBODGIFuJVixALrpvygndlRWakKT.get('thumbnail')
   HbcBODGIFuJVixALrpvygndlRWakKe =HbcBODGIFuJVixALrpvygndlRWakKT.get('age')
   HbcBODGIFuJVixALrpvygndlRWakzw =HbcBODGIFuJVixALrpvygndlRWakKT.get('epg')
   HbcBODGIFuJVixALrpvygndlRWakKs={'mediatype':'video','mpaa':HbcBODGIFuJVixALrpvygndlRWakKe,'title':'%s < %s >'%(HbcBODGIFuJVixALrpvygndlRWakzU,HbcBODGIFuJVixALrpvygndlRWakzK),'tvshowtitle':HbcBODGIFuJVixALrpvygndlRWakzK,'studio':HbcBODGIFuJVixALrpvygndlRWakzU,'plot':'%s\n\n%s'%(HbcBODGIFuJVixALrpvygndlRWakzU,HbcBODGIFuJVixALrpvygndlRWakzw)}
   HbcBODGIFuJVixALrpvygndlRWakSj={'mode':'LIVE','contentid':HbcBODGIFuJVixALrpvygndlRWakzS}
   HbcBODGIFuJVixALrpvygndlRWakqj.add_dir(HbcBODGIFuJVixALrpvygndlRWakzU,sublabel=HbcBODGIFuJVixALrpvygndlRWakzK,img=HbcBODGIFuJVixALrpvygndlRWakKP,infoLabels=HbcBODGIFuJVixALrpvygndlRWakKs,isFolder=HbcBODGIFuJVixALrpvygndlRWakze,params=HbcBODGIFuJVixALrpvygndlRWakSj)
  if HbcBODGIFuJVixALrpvygndlRWakzh(HbcBODGIFuJVixALrpvygndlRWakKX)>0:xbmcplugin.endOfDirectory(HbcBODGIFuJVixALrpvygndlRWakqj._addon_handle,cacheToDisc=HbcBODGIFuJVixALrpvygndlRWakze)
 def dp_Search_List(HbcBODGIFuJVixALrpvygndlRWakqj,args):
  HbcBODGIFuJVixALrpvygndlRWakqj.WavveObj.SaveCredential(HbcBODGIFuJVixALrpvygndlRWakqj.get_winCredential())
  HbcBODGIFuJVixALrpvygndlRWakKS =args.get('sType')
  HbcBODGIFuJVixALrpvygndlRWakKf =HbcBODGIFuJVixALrpvygndlRWakzP(args.get('page'))
  if 'search_key' in args:
   HbcBODGIFuJVixALrpvygndlRWakzX=args.get('search_key')
  else:
   HbcBODGIFuJVixALrpvygndlRWakzX=HbcBODGIFuJVixALrpvygndlRWakqj.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not HbcBODGIFuJVixALrpvygndlRWakzX:return
  HbcBODGIFuJVixALrpvygndlRWakKX,HbcBODGIFuJVixALrpvygndlRWakKQ=HbcBODGIFuJVixALrpvygndlRWakqj.WavveObj.Get_Search_List(HbcBODGIFuJVixALrpvygndlRWakzX,HbcBODGIFuJVixALrpvygndlRWakKS,HbcBODGIFuJVixALrpvygndlRWakKf,exclusion21=HbcBODGIFuJVixALrpvygndlRWakqj.get_settings_exclusion21())
  for HbcBODGIFuJVixALrpvygndlRWakKT in HbcBODGIFuJVixALrpvygndlRWakKX:
   HbcBODGIFuJVixALrpvygndlRWakSK =HbcBODGIFuJVixALrpvygndlRWakKT.get('title')
   HbcBODGIFuJVixALrpvygndlRWakKP=HbcBODGIFuJVixALrpvygndlRWakKT.get('thumbnail')
   HbcBODGIFuJVixALrpvygndlRWakKe =HbcBODGIFuJVixALrpvygndlRWakKT.get('age')
   if HbcBODGIFuJVixALrpvygndlRWakKe=='18' or HbcBODGIFuJVixALrpvygndlRWakKe=='19' or HbcBODGIFuJVixALrpvygndlRWakKe=='21':HbcBODGIFuJVixALrpvygndlRWakSK+=' (%s)'%(HbcBODGIFuJVixALrpvygndlRWakKe)
   HbcBODGIFuJVixALrpvygndlRWakKs={'mediatype':'episode' if HbcBODGIFuJVixALrpvygndlRWakKS=='vod' else 'movie','mpaa':HbcBODGIFuJVixALrpvygndlRWakKe,'title':HbcBODGIFuJVixALrpvygndlRWakSK,'plot':HbcBODGIFuJVixALrpvygndlRWakSK}
   if HbcBODGIFuJVixALrpvygndlRWakKS=='vod':
    HbcBODGIFuJVixALrpvygndlRWakSj={'mode':'EPISODE_LIST','videoid':HbcBODGIFuJVixALrpvygndlRWakKT.get('videoid'),'vidtype':HbcBODGIFuJVixALrpvygndlRWakKT.get('vidtype'),'page':'1'}
    HbcBODGIFuJVixALrpvygndlRWakSC=HbcBODGIFuJVixALrpvygndlRWakzs
   else:
    HbcBODGIFuJVixALrpvygndlRWakSj={'mode':'MOVIE','contentid':HbcBODGIFuJVixALrpvygndlRWakKT.get('videoid'),'title':HbcBODGIFuJVixALrpvygndlRWakSK,'thumbnail':HbcBODGIFuJVixALrpvygndlRWakKP,'age':HbcBODGIFuJVixALrpvygndlRWakKe}
    HbcBODGIFuJVixALrpvygndlRWakSC=HbcBODGIFuJVixALrpvygndlRWakze
   HbcBODGIFuJVixALrpvygndlRWakqj.add_dir(HbcBODGIFuJVixALrpvygndlRWakSK,sublabel='',img=HbcBODGIFuJVixALrpvygndlRWakKP,infoLabels=HbcBODGIFuJVixALrpvygndlRWakKs,isFolder=HbcBODGIFuJVixALrpvygndlRWakSC,params=HbcBODGIFuJVixALrpvygndlRWakSj)
  if HbcBODGIFuJVixALrpvygndlRWakKQ:
   HbcBODGIFuJVixALrpvygndlRWakSj['mode'] ='SEARCH_LIST' 
   HbcBODGIFuJVixALrpvygndlRWakSj['sType']=HbcBODGIFuJVixALrpvygndlRWakKS 
   HbcBODGIFuJVixALrpvygndlRWakSj['page'] =HbcBODGIFuJVixALrpvygndlRWakES(HbcBODGIFuJVixALrpvygndlRWakKf+1)
   HbcBODGIFuJVixALrpvygndlRWakSj['search_key']=HbcBODGIFuJVixALrpvygndlRWakzX
   HbcBODGIFuJVixALrpvygndlRWakSK='[B]%s >>[/B]'%'다음 페이지'
   HbcBODGIFuJVixALrpvygndlRWakKh=HbcBODGIFuJVixALrpvygndlRWakES(HbcBODGIFuJVixALrpvygndlRWakKf+1)
   HbcBODGIFuJVixALrpvygndlRWakqj.add_dir(HbcBODGIFuJVixALrpvygndlRWakSK,sublabel=HbcBODGIFuJVixALrpvygndlRWakKh,img='',infoLabels=HbcBODGIFuJVixALrpvygndlRWakzQ,isFolder=HbcBODGIFuJVixALrpvygndlRWakzs,params=HbcBODGIFuJVixALrpvygndlRWakSj)
  if HbcBODGIFuJVixALrpvygndlRWakzh(HbcBODGIFuJVixALrpvygndlRWakKX)>0:xbmcplugin.endOfDirectory(HbcBODGIFuJVixALrpvygndlRWakqj._addon_handle)
 def dp_Watch_List(HbcBODGIFuJVixALrpvygndlRWakqj,args):
  HbcBODGIFuJVixALrpvygndlRWakKS =args.get('sType')
  HbcBODGIFuJVixALrpvygndlRWakqY=HbcBODGIFuJVixALrpvygndlRWakqj.get_settings_direct_replay()
  HbcBODGIFuJVixALrpvygndlRWakKX=HbcBODGIFuJVixALrpvygndlRWakqj.Load_Watched_List(HbcBODGIFuJVixALrpvygndlRWakKS)
  for HbcBODGIFuJVixALrpvygndlRWakKT in HbcBODGIFuJVixALrpvygndlRWakKX:
   HbcBODGIFuJVixALrpvygndlRWakzN=HbcBODGIFuJVixALrpvygndlRWakzY(urllib.parse.parse_qsl(HbcBODGIFuJVixALrpvygndlRWakKT))
   HbcBODGIFuJVixALrpvygndlRWakzT =HbcBODGIFuJVixALrpvygndlRWakzN.get('code').strip()
   HbcBODGIFuJVixALrpvygndlRWakSK =HbcBODGIFuJVixALrpvygndlRWakzN.get('title').strip()
   HbcBODGIFuJVixALrpvygndlRWakKh =HbcBODGIFuJVixALrpvygndlRWakzN.get('subtitle').strip()
   if HbcBODGIFuJVixALrpvygndlRWakKh=='None':HbcBODGIFuJVixALrpvygndlRWakKh=''
   HbcBODGIFuJVixALrpvygndlRWakKP=HbcBODGIFuJVixALrpvygndlRWakzN.get('img').strip()
   HbcBODGIFuJVixALrpvygndlRWakzE =HbcBODGIFuJVixALrpvygndlRWakzN.get('videoid').strip()
   HbcBODGIFuJVixALrpvygndlRWakKs={'plot':'%s\n%s'%(HbcBODGIFuJVixALrpvygndlRWakSK,HbcBODGIFuJVixALrpvygndlRWakKh)}
   if HbcBODGIFuJVixALrpvygndlRWakKS=='vod':
    if HbcBODGIFuJVixALrpvygndlRWakqY==HbcBODGIFuJVixALrpvygndlRWakze or HbcBODGIFuJVixALrpvygndlRWakzE==HbcBODGIFuJVixALrpvygndlRWakzQ:
     HbcBODGIFuJVixALrpvygndlRWakSj={'mode':'EPISODE_LIST','videoid':HbcBODGIFuJVixALrpvygndlRWakzT,'vidtype':'programid','page':'1'}
     HbcBODGIFuJVixALrpvygndlRWakSC=HbcBODGIFuJVixALrpvygndlRWakzs
    else:
     HbcBODGIFuJVixALrpvygndlRWakSj={'mode':'VOD','programid':HbcBODGIFuJVixALrpvygndlRWakzT,'contentid':HbcBODGIFuJVixALrpvygndlRWakzE,'title':HbcBODGIFuJVixALrpvygndlRWakSK,'subtitle':HbcBODGIFuJVixALrpvygndlRWakKh,'thumbnail':HbcBODGIFuJVixALrpvygndlRWakKP}
     HbcBODGIFuJVixALrpvygndlRWakSC=HbcBODGIFuJVixALrpvygndlRWakze
   else:
    HbcBODGIFuJVixALrpvygndlRWakSj={'mode':'MOVIE','contentid':HbcBODGIFuJVixALrpvygndlRWakzT,'title':HbcBODGIFuJVixALrpvygndlRWakSK,'subtitle':HbcBODGIFuJVixALrpvygndlRWakKh,'thumbnail':HbcBODGIFuJVixALrpvygndlRWakKP}
    HbcBODGIFuJVixALrpvygndlRWakSC=HbcBODGIFuJVixALrpvygndlRWakze
   HbcBODGIFuJVixALrpvygndlRWakqj.add_dir(HbcBODGIFuJVixALrpvygndlRWakSK,sublabel=HbcBODGIFuJVixALrpvygndlRWakKh,img=HbcBODGIFuJVixALrpvygndlRWakKP,infoLabels=HbcBODGIFuJVixALrpvygndlRWakKs,isFolder=HbcBODGIFuJVixALrpvygndlRWakSC,params=HbcBODGIFuJVixALrpvygndlRWakSj)
  HbcBODGIFuJVixALrpvygndlRWakKs={'plot':'시청목록을 삭제합니다.'}
  HbcBODGIFuJVixALrpvygndlRWakSK='*** 시청목록 삭제 ***'
  HbcBODGIFuJVixALrpvygndlRWakSj={'mode':'MYVIEW_REMOVE','sType':HbcBODGIFuJVixALrpvygndlRWakKS}
  HbcBODGIFuJVixALrpvygndlRWakqj.add_dir(HbcBODGIFuJVixALrpvygndlRWakSK,sublabel='',img='',infoLabels=HbcBODGIFuJVixALrpvygndlRWakKs,isFolder=HbcBODGIFuJVixALrpvygndlRWakze,params=HbcBODGIFuJVixALrpvygndlRWakSj)
  xbmcplugin.endOfDirectory(HbcBODGIFuJVixALrpvygndlRWakqj._addon_handle,cacheToDisc=HbcBODGIFuJVixALrpvygndlRWakze)
 def wavve_main(HbcBODGIFuJVixALrpvygndlRWakqj):
  HbcBODGIFuJVixALrpvygndlRWakSh=HbcBODGIFuJVixALrpvygndlRWakqj.main_params.get('mode',HbcBODGIFuJVixALrpvygndlRWakzQ)
  if HbcBODGIFuJVixALrpvygndlRWakSh=='LOGOUT':
   HbcBODGIFuJVixALrpvygndlRWakqj.logout()
   return
  HbcBODGIFuJVixALrpvygndlRWakqj.login_main()
  if HbcBODGIFuJVixALrpvygndlRWakSh is HbcBODGIFuJVixALrpvygndlRWakzQ:
   HbcBODGIFuJVixALrpvygndlRWakqj.dp_Main_List()
  elif HbcBODGIFuJVixALrpvygndlRWakSh in['LIVE','VOD','MOVIE']:
   HbcBODGIFuJVixALrpvygndlRWakqj.play_VIDEO(HbcBODGIFuJVixALrpvygndlRWakqj.main_params)
  elif HbcBODGIFuJVixALrpvygndlRWakSh=='LIVE_CATAGORY':
   HbcBODGIFuJVixALrpvygndlRWakqj.dp_LiveCatagory_List(HbcBODGIFuJVixALrpvygndlRWakqj.main_params)
  elif HbcBODGIFuJVixALrpvygndlRWakSh=='MAIN_CATAGORY':
   HbcBODGIFuJVixALrpvygndlRWakqj.dp_MainCatagory_List(HbcBODGIFuJVixALrpvygndlRWakqj.main_params)
  elif HbcBODGIFuJVixALrpvygndlRWakSh=='SUPERSECTION_LIST':
   HbcBODGIFuJVixALrpvygndlRWakqj.dp_SuperSection_List(HbcBODGIFuJVixALrpvygndlRWakqj.main_params)
  elif HbcBODGIFuJVixALrpvygndlRWakSh=='BANDLIVESECTION_LIST':
   HbcBODGIFuJVixALrpvygndlRWakqj.dp_BandLiveSection_List(HbcBODGIFuJVixALrpvygndlRWakqj.main_params)
  elif HbcBODGIFuJVixALrpvygndlRWakSh=='BAND2SECTION_LIST':
   HbcBODGIFuJVixALrpvygndlRWakqj.dp_Band2Section_List(HbcBODGIFuJVixALrpvygndlRWakqj.main_params)
  elif HbcBODGIFuJVixALrpvygndlRWakSh=='PROGRAM_LIST':
   HbcBODGIFuJVixALrpvygndlRWakqj.dp_Program_List(HbcBODGIFuJVixALrpvygndlRWakqj.main_params)
  elif HbcBODGIFuJVixALrpvygndlRWakSh=='EPISODE_LIST':
   HbcBODGIFuJVixALrpvygndlRWakqj.dp_Episode_List(HbcBODGIFuJVixALrpvygndlRWakqj.main_params)
  elif HbcBODGIFuJVixALrpvygndlRWakSh=='MOVIE_LIST':
   HbcBODGIFuJVixALrpvygndlRWakqj.dp_Movie_List(HbcBODGIFuJVixALrpvygndlRWakqj.main_params)
  elif HbcBODGIFuJVixALrpvygndlRWakSh=='LIVE_LIST':
   HbcBODGIFuJVixALrpvygndlRWakqj.dp_LiveChannel_List(HbcBODGIFuJVixALrpvygndlRWakqj.main_params)
  elif HbcBODGIFuJVixALrpvygndlRWakSh=='ORDER_BY':
   HbcBODGIFuJVixALrpvygndlRWakqj.dp_setEpOrderby(HbcBODGIFuJVixALrpvygndlRWakqj.main_params)
  elif HbcBODGIFuJVixALrpvygndlRWakSh=='SEARCH_GROUP':
   HbcBODGIFuJVixALrpvygndlRWakqj.dp_Search_Group(HbcBODGIFuJVixALrpvygndlRWakqj.main_params)
  elif HbcBODGIFuJVixALrpvygndlRWakSh=='SEARCH_LIST':
   HbcBODGIFuJVixALrpvygndlRWakqj.dp_Search_List(HbcBODGIFuJVixALrpvygndlRWakqj.main_params)
  elif HbcBODGIFuJVixALrpvygndlRWakSh=='WATCH_GROUP':
   HbcBODGIFuJVixALrpvygndlRWakqj.dp_Watch_Group(HbcBODGIFuJVixALrpvygndlRWakqj.main_params)
  elif HbcBODGIFuJVixALrpvygndlRWakSh=='WATCH_LIST':
   HbcBODGIFuJVixALrpvygndlRWakqj.dp_Watch_List(HbcBODGIFuJVixALrpvygndlRWakqj.main_params)
  elif HbcBODGIFuJVixALrpvygndlRWakSh=='MYVIEW_REMOVE':
   HbcBODGIFuJVixALrpvygndlRWakqj.dp_WatchList_Delete(HbcBODGIFuJVixALrpvygndlRWakqj.main_params)
  else:
   HbcBODGIFuJVixALrpvygndlRWakzQ
# Created by pyminifier (https://github.com/liftoff/pyminifier)
