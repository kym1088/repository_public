__author__="NightRain"
tLbVBvOzwGdRHePigThIyoXFrnfDKC=object
tLbVBvOzwGdRHePigThIyoXFrnfDKW=None
tLbVBvOzwGdRHePigThIyoXFrnfDKu=int
tLbVBvOzwGdRHePigThIyoXFrnfDKx=True
tLbVBvOzwGdRHePigThIyoXFrnfDKk=False
tLbVBvOzwGdRHePigThIyoXFrnfDKE=type
tLbVBvOzwGdRHePigThIyoXFrnfDKQ=dict
tLbVBvOzwGdRHePigThIyoXFrnfDKY=getattr
tLbVBvOzwGdRHePigThIyoXFrnfDKM=list
tLbVBvOzwGdRHePigThIyoXFrnfDKN=len
tLbVBvOzwGdRHePigThIyoXFrnfDKl=range
tLbVBvOzwGdRHePigThIyoXFrnfDKj=str
tLbVBvOzwGdRHePigThIyoXFrnfDKm=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import json
tLbVBvOzwGdRHePigThIyoXFrnfDsJ=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://apis.wavve.com/v1/multiband/GN51','icon':'home.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&uicode=VN500','page':'1','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/allprograms?WeekDay=all&broadcastid=VN1000&came=MainCategory&contenttype=program&genre=01&uicode=VN1000&uiparent=GN56&uirank=21&uitype=VN1000','page':'1','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/allprograms?WeekDay=all&adult=n&broadcastid=VN1001&came=MainCategory&contenttype=program&genre=02&subgenre=all&uicode=VN1001&uiparent=GN57&uirank=17&uitype=VN1001','page':'1','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'CN21','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'vod09','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'vod09','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'4','sType':'movie','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'4','sType':'movie','orderby':'modifydate','ordernm':'업데이트순','icon':''},{'title':'프로야구 - 경기중 시청가능','mode':'GAME_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'(웨이브) 검색','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'(웨이브) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
tLbVBvOzwGdRHePigThIyoXFrnfDsU=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
tLbVBvOzwGdRHePigThIyoXFrnfDsc=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
tLbVBvOzwGdRHePigThIyoXFrnfDsS={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
tLbVBvOzwGdRHePigThIyoXFrnfDsp =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
tLbVBvOzwGdRHePigThIyoXFrnfDsK=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_searched.txt'))
from wavveCore import*
class tLbVBvOzwGdRHePigThIyoXFrnfDsA(tLbVBvOzwGdRHePigThIyoXFrnfDKC):
 def __init__(tLbVBvOzwGdRHePigThIyoXFrnfDsq,tLbVBvOzwGdRHePigThIyoXFrnfDsa,tLbVBvOzwGdRHePigThIyoXFrnfDsC,tLbVBvOzwGdRHePigThIyoXFrnfDsW):
  tLbVBvOzwGdRHePigThIyoXFrnfDsq._addon_url =tLbVBvOzwGdRHePigThIyoXFrnfDsa
  tLbVBvOzwGdRHePigThIyoXFrnfDsq._addon_handle=tLbVBvOzwGdRHePigThIyoXFrnfDsC
  tLbVBvOzwGdRHePigThIyoXFrnfDsq.main_params =tLbVBvOzwGdRHePigThIyoXFrnfDsW
  tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj =BhpIelOqUgfKCzdWsETVJGMyrajbiX() 
  tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.WV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_stream(mpd,m3u8)'))
 def addon_noti(tLbVBvOzwGdRHePigThIyoXFrnfDsq,sting):
  try:
   tLbVBvOzwGdRHePigThIyoXFrnfDsx=xbmcgui.Dialog()
   tLbVBvOzwGdRHePigThIyoXFrnfDsx.notification(__addonname__,sting)
  except:
   tLbVBvOzwGdRHePigThIyoXFrnfDKW
 def addon_log(tLbVBvOzwGdRHePigThIyoXFrnfDsq,string):
  try:
   tLbVBvOzwGdRHePigThIyoXFrnfDsk=string.encode('utf-8','ignore')
  except:
   tLbVBvOzwGdRHePigThIyoXFrnfDsk='addonException: addon_log'
  tLbVBvOzwGdRHePigThIyoXFrnfDsE=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,tLbVBvOzwGdRHePigThIyoXFrnfDsk),level=tLbVBvOzwGdRHePigThIyoXFrnfDsE)
 def get_keyboard_input(tLbVBvOzwGdRHePigThIyoXFrnfDsq,tLbVBvOzwGdRHePigThIyoXFrnfDAu):
  tLbVBvOzwGdRHePigThIyoXFrnfDsQ=tLbVBvOzwGdRHePigThIyoXFrnfDKW
  kb=xbmc.Keyboard()
  kb.setHeading(tLbVBvOzwGdRHePigThIyoXFrnfDAu)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   tLbVBvOzwGdRHePigThIyoXFrnfDsQ=kb.getText()
  return tLbVBvOzwGdRHePigThIyoXFrnfDsQ
 def get_settings_account(tLbVBvOzwGdRHePigThIyoXFrnfDsq):
  tLbVBvOzwGdRHePigThIyoXFrnfDsY =__addon__.getSetting('id')
  tLbVBvOzwGdRHePigThIyoXFrnfDsM =__addon__.getSetting('pw')
  tLbVBvOzwGdRHePigThIyoXFrnfDsN=tLbVBvOzwGdRHePigThIyoXFrnfDKu(__addon__.getSetting('selected_profile'))
  return(tLbVBvOzwGdRHePigThIyoXFrnfDsY,tLbVBvOzwGdRHePigThIyoXFrnfDsM,tLbVBvOzwGdRHePigThIyoXFrnfDsN)
 def get_settings_totalsearch(tLbVBvOzwGdRHePigThIyoXFrnfDsq):
  tLbVBvOzwGdRHePigThIyoXFrnfDsl =tLbVBvOzwGdRHePigThIyoXFrnfDKx if __addon__.getSetting('local_search')=='true' else tLbVBvOzwGdRHePigThIyoXFrnfDKk
  tLbVBvOzwGdRHePigThIyoXFrnfDsj=tLbVBvOzwGdRHePigThIyoXFrnfDKx if __addon__.getSetting('local_history')=='true' else tLbVBvOzwGdRHePigThIyoXFrnfDKk
  tLbVBvOzwGdRHePigThIyoXFrnfDsm =tLbVBvOzwGdRHePigThIyoXFrnfDKx if __addon__.getSetting('total_search')=='true' else tLbVBvOzwGdRHePigThIyoXFrnfDKk
  tLbVBvOzwGdRHePigThIyoXFrnfDAs=tLbVBvOzwGdRHePigThIyoXFrnfDKx if __addon__.getSetting('total_history')=='true' else tLbVBvOzwGdRHePigThIyoXFrnfDKk
  tLbVBvOzwGdRHePigThIyoXFrnfDAJ=tLbVBvOzwGdRHePigThIyoXFrnfDKx if __addon__.getSetting('menu_bookmark')=='true' else tLbVBvOzwGdRHePigThIyoXFrnfDKk
  return(tLbVBvOzwGdRHePigThIyoXFrnfDsl,tLbVBvOzwGdRHePigThIyoXFrnfDsj,tLbVBvOzwGdRHePigThIyoXFrnfDsm,tLbVBvOzwGdRHePigThIyoXFrnfDAs,tLbVBvOzwGdRHePigThIyoXFrnfDAJ)
 def get_settings_makebookmark(tLbVBvOzwGdRHePigThIyoXFrnfDsq):
  return tLbVBvOzwGdRHePigThIyoXFrnfDKx if __addon__.getSetting('make_bookmark')=='true' else tLbVBvOzwGdRHePigThIyoXFrnfDKk
 def get_settings_play(tLbVBvOzwGdRHePigThIyoXFrnfDsq):
  tLbVBvOzwGdRHePigThIyoXFrnfDAU={'enable_hdr':tLbVBvOzwGdRHePigThIyoXFrnfDKx if __addon__.getSetting('enable_hdr')=='true' else tLbVBvOzwGdRHePigThIyoXFrnfDKk,'enable_uhd':tLbVBvOzwGdRHePigThIyoXFrnfDKx if __addon__.getSetting('enable_uhd')=='true' else tLbVBvOzwGdRHePigThIyoXFrnfDKk,'streamFilename':tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.WV_STREAM_FILENAME,}
  if tLbVBvOzwGdRHePigThIyoXFrnfDsq.get_selQuality()<1080:
   tLbVBvOzwGdRHePigThIyoXFrnfDAU['enable_hdr']=tLbVBvOzwGdRHePigThIyoXFrnfDKk
   tLbVBvOzwGdRHePigThIyoXFrnfDAU['enable_uhd']=tLbVBvOzwGdRHePigThIyoXFrnfDKk
  return(tLbVBvOzwGdRHePigThIyoXFrnfDAU)
 def get_settings_proxyport(tLbVBvOzwGdRHePigThIyoXFrnfDsq):
  tLbVBvOzwGdRHePigThIyoXFrnfDAc =tLbVBvOzwGdRHePigThIyoXFrnfDKx if __addon__.getSetting('proxyYn')=='true' else tLbVBvOzwGdRHePigThIyoXFrnfDKk
  tLbVBvOzwGdRHePigThIyoXFrnfDAS=tLbVBvOzwGdRHePigThIyoXFrnfDKu(__addon__.getSetting('proxyPort'))
  return tLbVBvOzwGdRHePigThIyoXFrnfDAc,tLbVBvOzwGdRHePigThIyoXFrnfDAS
 def get_selQuality(tLbVBvOzwGdRHePigThIyoXFrnfDsq):
  try:
   tLbVBvOzwGdRHePigThIyoXFrnfDAp=[1080,720,480,360]
   tLbVBvOzwGdRHePigThIyoXFrnfDAK=tLbVBvOzwGdRHePigThIyoXFrnfDKu(__addon__.getSetting('selected_quality'))
   return tLbVBvOzwGdRHePigThIyoXFrnfDAp[tLbVBvOzwGdRHePigThIyoXFrnfDAK]
  except:
   tLbVBvOzwGdRHePigThIyoXFrnfDKW
  return 1080 
 def get_settings_exclusion21(tLbVBvOzwGdRHePigThIyoXFrnfDsq):
  tLbVBvOzwGdRHePigThIyoXFrnfDAq =__addon__.getSetting('exclusion21')
  if tLbVBvOzwGdRHePigThIyoXFrnfDAq=='false':
   return tLbVBvOzwGdRHePigThIyoXFrnfDKk
  else:
   return tLbVBvOzwGdRHePigThIyoXFrnfDKx
 def get_settings_direct_replay(tLbVBvOzwGdRHePigThIyoXFrnfDsq):
  tLbVBvOzwGdRHePigThIyoXFrnfDAa=tLbVBvOzwGdRHePigThIyoXFrnfDKu(__addon__.getSetting('direct_replay'))
  if tLbVBvOzwGdRHePigThIyoXFrnfDAa==0:
   return tLbVBvOzwGdRHePigThIyoXFrnfDKk
  else:
   return tLbVBvOzwGdRHePigThIyoXFrnfDKx
 def set_winEpisodeOrderby(tLbVBvOzwGdRHePigThIyoXFrnfDsq,tLbVBvOzwGdRHePigThIyoXFrnfDAC):
  __addon__.setSetting('wavve_orderby',tLbVBvOzwGdRHePigThIyoXFrnfDAC)
 def get_winEpisodeOrderby(tLbVBvOzwGdRHePigThIyoXFrnfDsq):
  tLbVBvOzwGdRHePigThIyoXFrnfDAC=__addon__.getSetting('wavve_orderby')
  if tLbVBvOzwGdRHePigThIyoXFrnfDAC in['',tLbVBvOzwGdRHePigThIyoXFrnfDKW]:tLbVBvOzwGdRHePigThIyoXFrnfDAC='desc'
  return tLbVBvOzwGdRHePigThIyoXFrnfDAC
 def add_dir(tLbVBvOzwGdRHePigThIyoXFrnfDsq,label,sublabel='',img='',infoLabels=tLbVBvOzwGdRHePigThIyoXFrnfDKW,isFolder=tLbVBvOzwGdRHePigThIyoXFrnfDKx,params='',isLink=tLbVBvOzwGdRHePigThIyoXFrnfDKk,ContextMenu=tLbVBvOzwGdRHePigThIyoXFrnfDKW):
  tLbVBvOzwGdRHePigThIyoXFrnfDAW='%s?%s'%(tLbVBvOzwGdRHePigThIyoXFrnfDsq._addon_url,urllib.parse.urlencode(params))
  if sublabel:tLbVBvOzwGdRHePigThIyoXFrnfDAu='%s < %s >'%(label,sublabel)
  else: tLbVBvOzwGdRHePigThIyoXFrnfDAu=label
  if not img:img='DefaultFolder.png'
  tLbVBvOzwGdRHePigThIyoXFrnfDAx=xbmcgui.ListItem(tLbVBvOzwGdRHePigThIyoXFrnfDAu)
  if tLbVBvOzwGdRHePigThIyoXFrnfDKE(img)==tLbVBvOzwGdRHePigThIyoXFrnfDKQ:
   tLbVBvOzwGdRHePigThIyoXFrnfDAx.setArt(img)
  else:
   tLbVBvOzwGdRHePigThIyoXFrnfDAx.setArt({'thumb':img,'poster':img})
  if tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.KodiVersion>=20:
   if infoLabels:tLbVBvOzwGdRHePigThIyoXFrnfDsq.Set_InfoTag(tLbVBvOzwGdRHePigThIyoXFrnfDAx.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:tLbVBvOzwGdRHePigThIyoXFrnfDAx.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   tLbVBvOzwGdRHePigThIyoXFrnfDAx.setProperty('IsPlayable','true')
  if ContextMenu:tLbVBvOzwGdRHePigThIyoXFrnfDAx.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(tLbVBvOzwGdRHePigThIyoXFrnfDsq._addon_handle,tLbVBvOzwGdRHePigThIyoXFrnfDAW,tLbVBvOzwGdRHePigThIyoXFrnfDAx,isFolder)
 def Set_InfoTag(tLbVBvOzwGdRHePigThIyoXFrnfDsq,video_InfoTag:xbmc.InfoTagVideo,tLbVBvOzwGdRHePigThIyoXFrnfDAj):
  for tLbVBvOzwGdRHePigThIyoXFrnfDAk,value in tLbVBvOzwGdRHePigThIyoXFrnfDAj.items():
   if tLbVBvOzwGdRHePigThIyoXFrnfDsS[tLbVBvOzwGdRHePigThIyoXFrnfDAk]['type']=='string':
    tLbVBvOzwGdRHePigThIyoXFrnfDKY(video_InfoTag,tLbVBvOzwGdRHePigThIyoXFrnfDsS[tLbVBvOzwGdRHePigThIyoXFrnfDAk]['func'])(value)
   elif tLbVBvOzwGdRHePigThIyoXFrnfDsS[tLbVBvOzwGdRHePigThIyoXFrnfDAk]['type']=='int':
    if tLbVBvOzwGdRHePigThIyoXFrnfDKE(value)==tLbVBvOzwGdRHePigThIyoXFrnfDKu:
     tLbVBvOzwGdRHePigThIyoXFrnfDAE=tLbVBvOzwGdRHePigThIyoXFrnfDKu(value)
    else:
     tLbVBvOzwGdRHePigThIyoXFrnfDAE=0
    tLbVBvOzwGdRHePigThIyoXFrnfDKY(video_InfoTag,tLbVBvOzwGdRHePigThIyoXFrnfDsS[tLbVBvOzwGdRHePigThIyoXFrnfDAk]['func'])(tLbVBvOzwGdRHePigThIyoXFrnfDAE)
   elif tLbVBvOzwGdRHePigThIyoXFrnfDsS[tLbVBvOzwGdRHePigThIyoXFrnfDAk]['type']=='actor':
    if value!=[]:
     tLbVBvOzwGdRHePigThIyoXFrnfDKY(video_InfoTag,tLbVBvOzwGdRHePigThIyoXFrnfDsS[tLbVBvOzwGdRHePigThIyoXFrnfDAk]['func'])([xbmc.Actor(name)for name in value])
   elif tLbVBvOzwGdRHePigThIyoXFrnfDsS[tLbVBvOzwGdRHePigThIyoXFrnfDAk]['type']=='list':
    if tLbVBvOzwGdRHePigThIyoXFrnfDKE(value)==tLbVBvOzwGdRHePigThIyoXFrnfDKM:
     tLbVBvOzwGdRHePigThIyoXFrnfDKY(video_InfoTag,tLbVBvOzwGdRHePigThIyoXFrnfDsS[tLbVBvOzwGdRHePigThIyoXFrnfDAk]['func'])(value)
    else:
     tLbVBvOzwGdRHePigThIyoXFrnfDKY(video_InfoTag,tLbVBvOzwGdRHePigThIyoXFrnfDsS[tLbVBvOzwGdRHePigThIyoXFrnfDAk]['func'])([value])
 def dp_Main_List(tLbVBvOzwGdRHePigThIyoXFrnfDsq):
  (tLbVBvOzwGdRHePigThIyoXFrnfDsl,tLbVBvOzwGdRHePigThIyoXFrnfDsj,tLbVBvOzwGdRHePigThIyoXFrnfDsm,tLbVBvOzwGdRHePigThIyoXFrnfDAs,tLbVBvOzwGdRHePigThIyoXFrnfDAJ)=tLbVBvOzwGdRHePigThIyoXFrnfDsq.get_settings_totalsearch()
  for tLbVBvOzwGdRHePigThIyoXFrnfDAQ in tLbVBvOzwGdRHePigThIyoXFrnfDsJ:
   tLbVBvOzwGdRHePigThIyoXFrnfDAu=tLbVBvOzwGdRHePigThIyoXFrnfDAQ.get('title')
   tLbVBvOzwGdRHePigThIyoXFrnfDAY=''
   if tLbVBvOzwGdRHePigThIyoXFrnfDAQ.get('mode')=='SEARCH_GROUP' and tLbVBvOzwGdRHePigThIyoXFrnfDsl ==tLbVBvOzwGdRHePigThIyoXFrnfDKk:continue
   elif tLbVBvOzwGdRHePigThIyoXFrnfDAQ.get('mode')=='SEARCH_HISTORY' and tLbVBvOzwGdRHePigThIyoXFrnfDsj==tLbVBvOzwGdRHePigThIyoXFrnfDKk:continue
   elif tLbVBvOzwGdRHePigThIyoXFrnfDAQ.get('mode')=='TOTAL_SEARCH' and tLbVBvOzwGdRHePigThIyoXFrnfDsm ==tLbVBvOzwGdRHePigThIyoXFrnfDKk:continue
   elif tLbVBvOzwGdRHePigThIyoXFrnfDAQ.get('mode')=='TOTAL_HISTORY' and tLbVBvOzwGdRHePigThIyoXFrnfDAs==tLbVBvOzwGdRHePigThIyoXFrnfDKk:continue
   elif tLbVBvOzwGdRHePigThIyoXFrnfDAQ.get('mode')=='MENU_BOOKMARK' and tLbVBvOzwGdRHePigThIyoXFrnfDAJ==tLbVBvOzwGdRHePigThIyoXFrnfDKk:continue
   tLbVBvOzwGdRHePigThIyoXFrnfDAM={'mode':tLbVBvOzwGdRHePigThIyoXFrnfDAQ.get('mode'),'sCode':tLbVBvOzwGdRHePigThIyoXFrnfDAQ.get('sCode'),'sIndex':tLbVBvOzwGdRHePigThIyoXFrnfDAQ.get('sIndex'),'sType':tLbVBvOzwGdRHePigThIyoXFrnfDAQ.get('sType'),'suburl':tLbVBvOzwGdRHePigThIyoXFrnfDAQ.get('suburl'),'subapi':tLbVBvOzwGdRHePigThIyoXFrnfDAQ.get('subapi'),'page':tLbVBvOzwGdRHePigThIyoXFrnfDAQ.get('page'),'orderby':tLbVBvOzwGdRHePigThIyoXFrnfDAQ.get('orderby'),'ordernm':tLbVBvOzwGdRHePigThIyoXFrnfDAQ.get('ordernm')}
   if tLbVBvOzwGdRHePigThIyoXFrnfDAQ.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    tLbVBvOzwGdRHePigThIyoXFrnfDAN=tLbVBvOzwGdRHePigThIyoXFrnfDKk
    tLbVBvOzwGdRHePigThIyoXFrnfDAl =tLbVBvOzwGdRHePigThIyoXFrnfDKx
   else:
    tLbVBvOzwGdRHePigThIyoXFrnfDAN=tLbVBvOzwGdRHePigThIyoXFrnfDKx
    tLbVBvOzwGdRHePigThIyoXFrnfDAl =tLbVBvOzwGdRHePigThIyoXFrnfDKk
   tLbVBvOzwGdRHePigThIyoXFrnfDAj={'title':tLbVBvOzwGdRHePigThIyoXFrnfDAu,'plot':tLbVBvOzwGdRHePigThIyoXFrnfDAu}
   if tLbVBvOzwGdRHePigThIyoXFrnfDAQ.get('mode')=='XXX':tLbVBvOzwGdRHePigThIyoXFrnfDAj=tLbVBvOzwGdRHePigThIyoXFrnfDKW
   if 'icon' in tLbVBvOzwGdRHePigThIyoXFrnfDAQ:tLbVBvOzwGdRHePigThIyoXFrnfDAY=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',tLbVBvOzwGdRHePigThIyoXFrnfDAQ.get('icon')) 
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.add_dir(tLbVBvOzwGdRHePigThIyoXFrnfDAu,sublabel='',img=tLbVBvOzwGdRHePigThIyoXFrnfDAY,infoLabels=tLbVBvOzwGdRHePigThIyoXFrnfDAj,isFolder=tLbVBvOzwGdRHePigThIyoXFrnfDAN,params=tLbVBvOzwGdRHePigThIyoXFrnfDAM,isLink=tLbVBvOzwGdRHePigThIyoXFrnfDAl)
  xbmcplugin.endOfDirectory(tLbVBvOzwGdRHePigThIyoXFrnfDsq._addon_handle,cacheToDisc=tLbVBvOzwGdRHePigThIyoXFrnfDKx)
 def dp_Search_Group(tLbVBvOzwGdRHePigThIyoXFrnfDsq,args):
  if 'search_key' in args:
   tLbVBvOzwGdRHePigThIyoXFrnfDJA=args.get('search_key')
  else:
   tLbVBvOzwGdRHePigThIyoXFrnfDJA=tLbVBvOzwGdRHePigThIyoXFrnfDsq.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not tLbVBvOzwGdRHePigThIyoXFrnfDJA:
    return
  for tLbVBvOzwGdRHePigThIyoXFrnfDJU in tLbVBvOzwGdRHePigThIyoXFrnfDsU:
   tLbVBvOzwGdRHePigThIyoXFrnfDJc =tLbVBvOzwGdRHePigThIyoXFrnfDJU.get('mode')
   tLbVBvOzwGdRHePigThIyoXFrnfDJS=tLbVBvOzwGdRHePigThIyoXFrnfDJU.get('sType')
   tLbVBvOzwGdRHePigThIyoXFrnfDAu=tLbVBvOzwGdRHePigThIyoXFrnfDJU.get('title')
   (tLbVBvOzwGdRHePigThIyoXFrnfDJp,tLbVBvOzwGdRHePigThIyoXFrnfDJK)=tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.Get_Search_List(tLbVBvOzwGdRHePigThIyoXFrnfDJA,tLbVBvOzwGdRHePigThIyoXFrnfDJS,1,exclusion21=tLbVBvOzwGdRHePigThIyoXFrnfDsq.get_settings_exclusion21())
   tLbVBvOzwGdRHePigThIyoXFrnfDAj={'plot':'검색어 : '+tLbVBvOzwGdRHePigThIyoXFrnfDJA+'\n\n'+tLbVBvOzwGdRHePigThIyoXFrnfDsq.Search_FreeList(tLbVBvOzwGdRHePigThIyoXFrnfDJp)}
   tLbVBvOzwGdRHePigThIyoXFrnfDAM={'mode':tLbVBvOzwGdRHePigThIyoXFrnfDJc,'sType':tLbVBvOzwGdRHePigThIyoXFrnfDJS,'search_key':tLbVBvOzwGdRHePigThIyoXFrnfDJA,'page':'1',}
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.add_dir(tLbVBvOzwGdRHePigThIyoXFrnfDAu,sublabel='',img='',infoLabels=tLbVBvOzwGdRHePigThIyoXFrnfDAj,isFolder=tLbVBvOzwGdRHePigThIyoXFrnfDKx,params=tLbVBvOzwGdRHePigThIyoXFrnfDAM)
  if tLbVBvOzwGdRHePigThIyoXFrnfDKN(tLbVBvOzwGdRHePigThIyoXFrnfDsU)>0:xbmcplugin.endOfDirectory(tLbVBvOzwGdRHePigThIyoXFrnfDsq._addon_handle,cacheToDisc=tLbVBvOzwGdRHePigThIyoXFrnfDKx)
  tLbVBvOzwGdRHePigThIyoXFrnfDsq.Save_Searched_List(tLbVBvOzwGdRHePigThIyoXFrnfDJA)
 def Search_FreeList(tLbVBvOzwGdRHePigThIyoXFrnfDsq,search_list):
  tLbVBvOzwGdRHePigThIyoXFrnfDJq=''
  tLbVBvOzwGdRHePigThIyoXFrnfDJa=7
  try:
   if tLbVBvOzwGdRHePigThIyoXFrnfDKN(search_list)==0:return '검색결과 없음'
   for i in tLbVBvOzwGdRHePigThIyoXFrnfDKl(tLbVBvOzwGdRHePigThIyoXFrnfDKN(search_list)):
    if i>=tLbVBvOzwGdRHePigThIyoXFrnfDJa:
     tLbVBvOzwGdRHePigThIyoXFrnfDJq=tLbVBvOzwGdRHePigThIyoXFrnfDJq+'...'
     break
    tLbVBvOzwGdRHePigThIyoXFrnfDJq=tLbVBvOzwGdRHePigThIyoXFrnfDJq+search_list[i]['title']+'\n'
  except:
   return ''
  return tLbVBvOzwGdRHePigThIyoXFrnfDJq
 def dp_Watch_Group(tLbVBvOzwGdRHePigThIyoXFrnfDsq,args):
  for tLbVBvOzwGdRHePigThIyoXFrnfDJC in tLbVBvOzwGdRHePigThIyoXFrnfDsc:
   tLbVBvOzwGdRHePigThIyoXFrnfDAu=tLbVBvOzwGdRHePigThIyoXFrnfDJC.get('title')
   tLbVBvOzwGdRHePigThIyoXFrnfDAM={'mode':tLbVBvOzwGdRHePigThIyoXFrnfDJC.get('mode'),'sType':tLbVBvOzwGdRHePigThIyoXFrnfDJC.get('sType')}
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.add_dir(tLbVBvOzwGdRHePigThIyoXFrnfDAu,sublabel='',img='',infoLabels=tLbVBvOzwGdRHePigThIyoXFrnfDKW,isFolder=tLbVBvOzwGdRHePigThIyoXFrnfDKx,params=tLbVBvOzwGdRHePigThIyoXFrnfDAM)
  if tLbVBvOzwGdRHePigThIyoXFrnfDKN(tLbVBvOzwGdRHePigThIyoXFrnfDsc)>0:xbmcplugin.endOfDirectory(tLbVBvOzwGdRHePigThIyoXFrnfDsq._addon_handle,cacheToDisc=tLbVBvOzwGdRHePigThIyoXFrnfDKx)
 def dp_Search_History(tLbVBvOzwGdRHePigThIyoXFrnfDsq,args):
  tLbVBvOzwGdRHePigThIyoXFrnfDJW=tLbVBvOzwGdRHePigThIyoXFrnfDsq.Load_List_File('search')
  for tLbVBvOzwGdRHePigThIyoXFrnfDJu in tLbVBvOzwGdRHePigThIyoXFrnfDJW:
   tLbVBvOzwGdRHePigThIyoXFrnfDJx=tLbVBvOzwGdRHePigThIyoXFrnfDKQ(urllib.parse.parse_qsl(tLbVBvOzwGdRHePigThIyoXFrnfDJu))
   tLbVBvOzwGdRHePigThIyoXFrnfDJk=tLbVBvOzwGdRHePigThIyoXFrnfDJx.get('skey').strip()
   tLbVBvOzwGdRHePigThIyoXFrnfDAM={'mode':'SEARCH_GROUP','search_key':tLbVBvOzwGdRHePigThIyoXFrnfDJk,}
   tLbVBvOzwGdRHePigThIyoXFrnfDJE={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':tLbVBvOzwGdRHePigThIyoXFrnfDJk,'vType':'-',}
   tLbVBvOzwGdRHePigThIyoXFrnfDJQ=urllib.parse.urlencode(tLbVBvOzwGdRHePigThIyoXFrnfDJE)
   tLbVBvOzwGdRHePigThIyoXFrnfDJY=[('선택된 검색어 ( %s ) 삭제'%(tLbVBvOzwGdRHePigThIyoXFrnfDJk),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(tLbVBvOzwGdRHePigThIyoXFrnfDJQ))]
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.add_dir(tLbVBvOzwGdRHePigThIyoXFrnfDJk,sublabel='',img=tLbVBvOzwGdRHePigThIyoXFrnfDKW,infoLabels=tLbVBvOzwGdRHePigThIyoXFrnfDKW,isFolder=tLbVBvOzwGdRHePigThIyoXFrnfDKx,params=tLbVBvOzwGdRHePigThIyoXFrnfDAM,ContextMenu=tLbVBvOzwGdRHePigThIyoXFrnfDJY)
  tLbVBvOzwGdRHePigThIyoXFrnfDJM={'plot':'검색목록 전체를 삭제합니다.'}
  tLbVBvOzwGdRHePigThIyoXFrnfDAu='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  tLbVBvOzwGdRHePigThIyoXFrnfDAM={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  tLbVBvOzwGdRHePigThIyoXFrnfDAY=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  tLbVBvOzwGdRHePigThIyoXFrnfDsq.add_dir(tLbVBvOzwGdRHePigThIyoXFrnfDAu,sublabel='',img=tLbVBvOzwGdRHePigThIyoXFrnfDAY,infoLabels=tLbVBvOzwGdRHePigThIyoXFrnfDJM,isFolder=tLbVBvOzwGdRHePigThIyoXFrnfDKk,params=tLbVBvOzwGdRHePigThIyoXFrnfDAM,isLink=tLbVBvOzwGdRHePigThIyoXFrnfDKx)
  xbmcplugin.endOfDirectory(tLbVBvOzwGdRHePigThIyoXFrnfDsq._addon_handle,cacheToDisc=tLbVBvOzwGdRHePigThIyoXFrnfDKk)
 def dp_Search_List(tLbVBvOzwGdRHePigThIyoXFrnfDsq,args):
  tLbVBvOzwGdRHePigThIyoXFrnfDJS =args.get('sType')
  tLbVBvOzwGdRHePigThIyoXFrnfDJN =tLbVBvOzwGdRHePigThIyoXFrnfDKu(args.get('page'))
  if 'search_key' in args:
   tLbVBvOzwGdRHePigThIyoXFrnfDJA=args.get('search_key')
  else:
   tLbVBvOzwGdRHePigThIyoXFrnfDJA=tLbVBvOzwGdRHePigThIyoXFrnfDsq.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not tLbVBvOzwGdRHePigThIyoXFrnfDJA:
    xbmcplugin.endOfDirectory(tLbVBvOzwGdRHePigThIyoXFrnfDsq._addon_handle)
    return
  tLbVBvOzwGdRHePigThIyoXFrnfDJl,tLbVBvOzwGdRHePigThIyoXFrnfDJK=tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.Get_Search_List(tLbVBvOzwGdRHePigThIyoXFrnfDJA,tLbVBvOzwGdRHePigThIyoXFrnfDJS,tLbVBvOzwGdRHePigThIyoXFrnfDJN,exclusion21=tLbVBvOzwGdRHePigThIyoXFrnfDsq.get_settings_exclusion21())
  for tLbVBvOzwGdRHePigThIyoXFrnfDJj in tLbVBvOzwGdRHePigThIyoXFrnfDJl:
   tLbVBvOzwGdRHePigThIyoXFrnfDJm =tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('videoid')
   tLbVBvOzwGdRHePigThIyoXFrnfDUs =tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('vidtype')
   tLbVBvOzwGdRHePigThIyoXFrnfDAu =tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('title')
   tLbVBvOzwGdRHePigThIyoXFrnfDUA=tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('thumbnail')
   tLbVBvOzwGdRHePigThIyoXFrnfDUJ =tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('age')
   if tLbVBvOzwGdRHePigThIyoXFrnfDUJ=='18' or tLbVBvOzwGdRHePigThIyoXFrnfDUJ=='19' or tLbVBvOzwGdRHePigThIyoXFrnfDUJ=='21':tLbVBvOzwGdRHePigThIyoXFrnfDAu+=' (%s)'%(tLbVBvOzwGdRHePigThIyoXFrnfDUJ)
   tLbVBvOzwGdRHePigThIyoXFrnfDJM={'mediatype':'tvshow' if tLbVBvOzwGdRHePigThIyoXFrnfDJS=='vod' else 'movie','mpaa':tLbVBvOzwGdRHePigThIyoXFrnfDUJ,'title':tLbVBvOzwGdRHePigThIyoXFrnfDAu,'plot':tLbVBvOzwGdRHePigThIyoXFrnfDAu}
   if tLbVBvOzwGdRHePigThIyoXFrnfDJS=='vod':
    tLbVBvOzwGdRHePigThIyoXFrnfDAM={'mode':'EPISODE_LIST','seasonid':tLbVBvOzwGdRHePigThIyoXFrnfDJm,'page':'1',}
    tLbVBvOzwGdRHePigThIyoXFrnfDAN=tLbVBvOzwGdRHePigThIyoXFrnfDKx
   else:
    tLbVBvOzwGdRHePigThIyoXFrnfDAM={'mode':'MOVIE','contentid':tLbVBvOzwGdRHePigThIyoXFrnfDJm,'title':tLbVBvOzwGdRHePigThIyoXFrnfDAu,'thumbnail':tLbVBvOzwGdRHePigThIyoXFrnfDUA,'age':tLbVBvOzwGdRHePigThIyoXFrnfDUJ,}
    tLbVBvOzwGdRHePigThIyoXFrnfDAN=tLbVBvOzwGdRHePigThIyoXFrnfDKk
   tLbVBvOzwGdRHePigThIyoXFrnfDJY=[]
   tLbVBvOzwGdRHePigThIyoXFrnfDUc={'mode':'VIEW_DETAIL','values':{'videoid':tLbVBvOzwGdRHePigThIyoXFrnfDJm,'vidtype':'tvshow' if tLbVBvOzwGdRHePigThIyoXFrnfDJS=='vod' else 'movie','contenttype':tLbVBvOzwGdRHePigThIyoXFrnfDUs,}}
   tLbVBvOzwGdRHePigThIyoXFrnfDUS=json.dumps(tLbVBvOzwGdRHePigThIyoXFrnfDUc,separators=(',',':'))
   tLbVBvOzwGdRHePigThIyoXFrnfDUS=base64.standard_b64encode(tLbVBvOzwGdRHePigThIyoXFrnfDUS.encode()).decode('utf-8')
   tLbVBvOzwGdRHePigThIyoXFrnfDUS=tLbVBvOzwGdRHePigThIyoXFrnfDUS.replace('+','%2B')
   tLbVBvOzwGdRHePigThIyoXFrnfDUp='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(tLbVBvOzwGdRHePigThIyoXFrnfDUS)
   tLbVBvOzwGdRHePigThIyoXFrnfDJY.append(('상세정보 조회',tLbVBvOzwGdRHePigThIyoXFrnfDUp))
   if tLbVBvOzwGdRHePigThIyoXFrnfDsq.get_settings_makebookmark():
    tLbVBvOzwGdRHePigThIyoXFrnfDUc={'videoid':tLbVBvOzwGdRHePigThIyoXFrnfDJm,'vidtype':'tvshow' if tLbVBvOzwGdRHePigThIyoXFrnfDJS=='vod' else 'movie','vtitle':tLbVBvOzwGdRHePigThIyoXFrnfDAu,'vsubtitle':'','contenttype':tLbVBvOzwGdRHePigThIyoXFrnfDUs,}
    tLbVBvOzwGdRHePigThIyoXFrnfDUK=json.dumps(tLbVBvOzwGdRHePigThIyoXFrnfDUc)
    tLbVBvOzwGdRHePigThIyoXFrnfDUK=urllib.parse.quote(tLbVBvOzwGdRHePigThIyoXFrnfDUK)
    tLbVBvOzwGdRHePigThIyoXFrnfDUp='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(tLbVBvOzwGdRHePigThIyoXFrnfDUK)
    tLbVBvOzwGdRHePigThIyoXFrnfDJY.append(('(통합) 찜 영상에 추가',tLbVBvOzwGdRHePigThIyoXFrnfDUp))
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.add_dir(tLbVBvOzwGdRHePigThIyoXFrnfDAu,sublabel='',img=tLbVBvOzwGdRHePigThIyoXFrnfDUA,infoLabels=tLbVBvOzwGdRHePigThIyoXFrnfDJM,isFolder=tLbVBvOzwGdRHePigThIyoXFrnfDAN,params=tLbVBvOzwGdRHePigThIyoXFrnfDAM,ContextMenu=tLbVBvOzwGdRHePigThIyoXFrnfDJY)
  if tLbVBvOzwGdRHePigThIyoXFrnfDJK:
   tLbVBvOzwGdRHePigThIyoXFrnfDAM['mode'] ='SEARCH_LIST' 
   tLbVBvOzwGdRHePigThIyoXFrnfDAM['sType']=tLbVBvOzwGdRHePigThIyoXFrnfDJS 
   tLbVBvOzwGdRHePigThIyoXFrnfDAM['page'] =tLbVBvOzwGdRHePigThIyoXFrnfDKj(tLbVBvOzwGdRHePigThIyoXFrnfDJN+1)
   tLbVBvOzwGdRHePigThIyoXFrnfDAM['search_key']=tLbVBvOzwGdRHePigThIyoXFrnfDJA
   tLbVBvOzwGdRHePigThIyoXFrnfDAu='[B]%s >>[/B]'%'다음 페이지'
   tLbVBvOzwGdRHePigThIyoXFrnfDUq=tLbVBvOzwGdRHePigThIyoXFrnfDKj(tLbVBvOzwGdRHePigThIyoXFrnfDJN+1)
   tLbVBvOzwGdRHePigThIyoXFrnfDAY=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.add_dir(tLbVBvOzwGdRHePigThIyoXFrnfDAu,sublabel=tLbVBvOzwGdRHePigThIyoXFrnfDUq,img=tLbVBvOzwGdRHePigThIyoXFrnfDAY,infoLabels=tLbVBvOzwGdRHePigThIyoXFrnfDKW,isFolder=tLbVBvOzwGdRHePigThIyoXFrnfDKx,params=tLbVBvOzwGdRHePigThIyoXFrnfDAM)
  if tLbVBvOzwGdRHePigThIyoXFrnfDJS=='movie':xbmcplugin.setContent(tLbVBvOzwGdRHePigThIyoXFrnfDsq._addon_handle,'movies')
  else:xbmcplugin.setContent(tLbVBvOzwGdRHePigThIyoXFrnfDsq._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(tLbVBvOzwGdRHePigThIyoXFrnfDsq._addon_handle,cacheToDisc=tLbVBvOzwGdRHePigThIyoXFrnfDKk)
 def dp_Watch_List(tLbVBvOzwGdRHePigThIyoXFrnfDsq,args):
  tLbVBvOzwGdRHePigThIyoXFrnfDJS =args.get('sType')
  tLbVBvOzwGdRHePigThIyoXFrnfDAa=tLbVBvOzwGdRHePigThIyoXFrnfDsq.get_settings_direct_replay()
  tLbVBvOzwGdRHePigThIyoXFrnfDJl=tLbVBvOzwGdRHePigThIyoXFrnfDsq.Load_List_File(tLbVBvOzwGdRHePigThIyoXFrnfDJS)
  for tLbVBvOzwGdRHePigThIyoXFrnfDJj in tLbVBvOzwGdRHePigThIyoXFrnfDJl:
   tLbVBvOzwGdRHePigThIyoXFrnfDJx=tLbVBvOzwGdRHePigThIyoXFrnfDKQ(urllib.parse.parse_qsl(tLbVBvOzwGdRHePigThIyoXFrnfDJj))
   tLbVBvOzwGdRHePigThIyoXFrnfDUa =tLbVBvOzwGdRHePigThIyoXFrnfDJx.get('code').strip()
   tLbVBvOzwGdRHePigThIyoXFrnfDAu =tLbVBvOzwGdRHePigThIyoXFrnfDJx.get('title').strip()
   tLbVBvOzwGdRHePigThIyoXFrnfDUq =tLbVBvOzwGdRHePigThIyoXFrnfDJx.get('subtitle').strip()
   if tLbVBvOzwGdRHePigThIyoXFrnfDUq=='None':tLbVBvOzwGdRHePigThIyoXFrnfDUq=''
   tLbVBvOzwGdRHePigThIyoXFrnfDUA=tLbVBvOzwGdRHePigThIyoXFrnfDJx.get('img').strip()
   tLbVBvOzwGdRHePigThIyoXFrnfDJm =tLbVBvOzwGdRHePigThIyoXFrnfDJx.get('videoid').strip()
   try:
    tLbVBvOzwGdRHePigThIyoXFrnfDUA=tLbVBvOzwGdRHePigThIyoXFrnfDUA.replace('\'','\"')
    tLbVBvOzwGdRHePigThIyoXFrnfDUA=json.loads(tLbVBvOzwGdRHePigThIyoXFrnfDUA)
   except:
    tLbVBvOzwGdRHePigThIyoXFrnfDKW
   tLbVBvOzwGdRHePigThIyoXFrnfDJM={'plot':'%s\n%s'%(tLbVBvOzwGdRHePigThIyoXFrnfDAu,tLbVBvOzwGdRHePigThIyoXFrnfDUq)}
   if tLbVBvOzwGdRHePigThIyoXFrnfDJS=='vod':
    if tLbVBvOzwGdRHePigThIyoXFrnfDAa==tLbVBvOzwGdRHePigThIyoXFrnfDKk or tLbVBvOzwGdRHePigThIyoXFrnfDJm==tLbVBvOzwGdRHePigThIyoXFrnfDKW:
     tLbVBvOzwGdRHePigThIyoXFrnfDJM['mediatype']='tvshow'
     tLbVBvOzwGdRHePigThIyoXFrnfDAM={'mode':'SEASON_LIST','videoid':tLbVBvOzwGdRHePigThIyoXFrnfDJm,'vidtype':'contentid',}
     tLbVBvOzwGdRHePigThIyoXFrnfDAN=tLbVBvOzwGdRHePigThIyoXFrnfDKx
    else:
     tLbVBvOzwGdRHePigThIyoXFrnfDJM['mediatype']='episode'
     tLbVBvOzwGdRHePigThIyoXFrnfDAM={'mode':'VOD','programid':tLbVBvOzwGdRHePigThIyoXFrnfDUa,'contentid':tLbVBvOzwGdRHePigThIyoXFrnfDJm,'title':tLbVBvOzwGdRHePigThIyoXFrnfDAu,'subtitle':tLbVBvOzwGdRHePigThIyoXFrnfDUq,'thumbnail':tLbVBvOzwGdRHePigThIyoXFrnfDUA}
     tLbVBvOzwGdRHePigThIyoXFrnfDAN=tLbVBvOzwGdRHePigThIyoXFrnfDKk
   else:
    tLbVBvOzwGdRHePigThIyoXFrnfDJM['mediatype']='movie'
    tLbVBvOzwGdRHePigThIyoXFrnfDAM={'mode':'MOVIE','contentid':tLbVBvOzwGdRHePigThIyoXFrnfDUa,'title':tLbVBvOzwGdRHePigThIyoXFrnfDAu,'subtitle':tLbVBvOzwGdRHePigThIyoXFrnfDUq,'thumbnail':tLbVBvOzwGdRHePigThIyoXFrnfDUA}
    tLbVBvOzwGdRHePigThIyoXFrnfDAN=tLbVBvOzwGdRHePigThIyoXFrnfDKk
   tLbVBvOzwGdRHePigThIyoXFrnfDJE={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':tLbVBvOzwGdRHePigThIyoXFrnfDUa,'vType':tLbVBvOzwGdRHePigThIyoXFrnfDJS,}
   tLbVBvOzwGdRHePigThIyoXFrnfDJQ=urllib.parse.urlencode(tLbVBvOzwGdRHePigThIyoXFrnfDJE)
   tLbVBvOzwGdRHePigThIyoXFrnfDJY=[('선택된 시청이력 ( %s ) 삭제'%(tLbVBvOzwGdRHePigThIyoXFrnfDAu),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(tLbVBvOzwGdRHePigThIyoXFrnfDJQ))]
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.add_dir(tLbVBvOzwGdRHePigThIyoXFrnfDAu,sublabel=tLbVBvOzwGdRHePigThIyoXFrnfDUq,img=tLbVBvOzwGdRHePigThIyoXFrnfDUA,infoLabels=tLbVBvOzwGdRHePigThIyoXFrnfDJM,isFolder=tLbVBvOzwGdRHePigThIyoXFrnfDAN,params=tLbVBvOzwGdRHePigThIyoXFrnfDAM,ContextMenu=tLbVBvOzwGdRHePigThIyoXFrnfDJY)
  tLbVBvOzwGdRHePigThIyoXFrnfDJM={'plot':'시청목록을 삭제합니다.'}
  tLbVBvOzwGdRHePigThIyoXFrnfDAu='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  tLbVBvOzwGdRHePigThIyoXFrnfDAM={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':tLbVBvOzwGdRHePigThIyoXFrnfDJS,}
  tLbVBvOzwGdRHePigThIyoXFrnfDAY=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  tLbVBvOzwGdRHePigThIyoXFrnfDsq.add_dir(tLbVBvOzwGdRHePigThIyoXFrnfDAu,sublabel='',img=tLbVBvOzwGdRHePigThIyoXFrnfDAY,infoLabels=tLbVBvOzwGdRHePigThIyoXFrnfDJM,isFolder=tLbVBvOzwGdRHePigThIyoXFrnfDKk,params=tLbVBvOzwGdRHePigThIyoXFrnfDAM,isLink=tLbVBvOzwGdRHePigThIyoXFrnfDKx)
  if tLbVBvOzwGdRHePigThIyoXFrnfDJS=='movie':xbmcplugin.setContent(tLbVBvOzwGdRHePigThIyoXFrnfDsq._addon_handle,'movies')
  else:xbmcplugin.setContent(tLbVBvOzwGdRHePigThIyoXFrnfDsq._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(tLbVBvOzwGdRHePigThIyoXFrnfDsq._addon_handle,cacheToDisc=tLbVBvOzwGdRHePigThIyoXFrnfDKk)
 def Load_List_File(tLbVBvOzwGdRHePigThIyoXFrnfDsq,stype): 
  try:
   if stype=='search':
    tLbVBvOzwGdRHePigThIyoXFrnfDUC=tLbVBvOzwGdRHePigThIyoXFrnfDsK
   elif stype in['vod','movie']:
    tLbVBvOzwGdRHePigThIyoXFrnfDUC=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   else:
    return[]
   fp=tLbVBvOzwGdRHePigThIyoXFrnfDKm(tLbVBvOzwGdRHePigThIyoXFrnfDUC,'r',-1,'utf-8')
   tLbVBvOzwGdRHePigThIyoXFrnfDUW=fp.readlines()
   fp.close()
  except:
   tLbVBvOzwGdRHePigThIyoXFrnfDUW=[]
  return tLbVBvOzwGdRHePigThIyoXFrnfDUW
 def Save_Watched_List(tLbVBvOzwGdRHePigThIyoXFrnfDsq,tLbVBvOzwGdRHePigThIyoXFrnfDpM,tLbVBvOzwGdRHePigThIyoXFrnfDsW):
  try:
   tLbVBvOzwGdRHePigThIyoXFrnfDUu=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%tLbVBvOzwGdRHePigThIyoXFrnfDpM))
   tLbVBvOzwGdRHePigThIyoXFrnfDUx=tLbVBvOzwGdRHePigThIyoXFrnfDsq.Load_List_File(tLbVBvOzwGdRHePigThIyoXFrnfDpM) 
   fp=tLbVBvOzwGdRHePigThIyoXFrnfDKm(tLbVBvOzwGdRHePigThIyoXFrnfDUu,'w',-1,'utf-8')
   tLbVBvOzwGdRHePigThIyoXFrnfDUk=urllib.parse.urlencode(tLbVBvOzwGdRHePigThIyoXFrnfDsW)
   tLbVBvOzwGdRHePigThIyoXFrnfDUk=tLbVBvOzwGdRHePigThIyoXFrnfDUk+'\n'
   fp.write(tLbVBvOzwGdRHePigThIyoXFrnfDUk)
   tLbVBvOzwGdRHePigThIyoXFrnfDUE=0
   for tLbVBvOzwGdRHePigThIyoXFrnfDUQ in tLbVBvOzwGdRHePigThIyoXFrnfDUx:
    tLbVBvOzwGdRHePigThIyoXFrnfDUY=tLbVBvOzwGdRHePigThIyoXFrnfDKQ(urllib.parse.parse_qsl(tLbVBvOzwGdRHePigThIyoXFrnfDUQ))
    tLbVBvOzwGdRHePigThIyoXFrnfDUM=tLbVBvOzwGdRHePigThIyoXFrnfDsW.get('code').strip()
    tLbVBvOzwGdRHePigThIyoXFrnfDUN=tLbVBvOzwGdRHePigThIyoXFrnfDUY.get('code').strip()
    if tLbVBvOzwGdRHePigThIyoXFrnfDpM=='vod' and tLbVBvOzwGdRHePigThIyoXFrnfDsq.get_settings_direct_replay()==tLbVBvOzwGdRHePigThIyoXFrnfDKx:
     tLbVBvOzwGdRHePigThIyoXFrnfDUM=tLbVBvOzwGdRHePigThIyoXFrnfDsW.get('videoid').strip()
     tLbVBvOzwGdRHePigThIyoXFrnfDUN=tLbVBvOzwGdRHePigThIyoXFrnfDUY.get('videoid').strip()if tLbVBvOzwGdRHePigThIyoXFrnfDUN!=tLbVBvOzwGdRHePigThIyoXFrnfDKW else '-'
    if tLbVBvOzwGdRHePigThIyoXFrnfDUM!=tLbVBvOzwGdRHePigThIyoXFrnfDUN:
     fp.write(tLbVBvOzwGdRHePigThIyoXFrnfDUQ)
     tLbVBvOzwGdRHePigThIyoXFrnfDUE+=1
     if tLbVBvOzwGdRHePigThIyoXFrnfDUE>=50:break
   fp.close()
  except:
   tLbVBvOzwGdRHePigThIyoXFrnfDKW
 def dp_History_Remove(tLbVBvOzwGdRHePigThIyoXFrnfDsq,args):
  tLbVBvOzwGdRHePigThIyoXFrnfDUl=args.get('delType')
  tLbVBvOzwGdRHePigThIyoXFrnfDUj =args.get('sKey')
  tLbVBvOzwGdRHePigThIyoXFrnfDUm =args.get('vType')
  tLbVBvOzwGdRHePigThIyoXFrnfDsx=xbmcgui.Dialog()
  if tLbVBvOzwGdRHePigThIyoXFrnfDUl=='SEARCH_ALL':
   tLbVBvOzwGdRHePigThIyoXFrnfDcs=tLbVBvOzwGdRHePigThIyoXFrnfDsx.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif tLbVBvOzwGdRHePigThIyoXFrnfDUl=='SEARCH_ONE':
   tLbVBvOzwGdRHePigThIyoXFrnfDcs=tLbVBvOzwGdRHePigThIyoXFrnfDsx.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif tLbVBvOzwGdRHePigThIyoXFrnfDUl=='WATCH_ALL':
   tLbVBvOzwGdRHePigThIyoXFrnfDcs=tLbVBvOzwGdRHePigThIyoXFrnfDsx.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif tLbVBvOzwGdRHePigThIyoXFrnfDUl=='WATCH_ONE':
   tLbVBvOzwGdRHePigThIyoXFrnfDcs=tLbVBvOzwGdRHePigThIyoXFrnfDsx.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if tLbVBvOzwGdRHePigThIyoXFrnfDcs==tLbVBvOzwGdRHePigThIyoXFrnfDKk:sys.exit()
  if tLbVBvOzwGdRHePigThIyoXFrnfDUl=='SEARCH_ALL':
   if os.path.isfile(tLbVBvOzwGdRHePigThIyoXFrnfDsK):os.remove(tLbVBvOzwGdRHePigThIyoXFrnfDsK)
  elif tLbVBvOzwGdRHePigThIyoXFrnfDUl=='SEARCH_ONE':
   try:
    tLbVBvOzwGdRHePigThIyoXFrnfDUC=tLbVBvOzwGdRHePigThIyoXFrnfDsK
    tLbVBvOzwGdRHePigThIyoXFrnfDUx=tLbVBvOzwGdRHePigThIyoXFrnfDsq.Load_List_File('search') 
    fp=tLbVBvOzwGdRHePigThIyoXFrnfDKm(tLbVBvOzwGdRHePigThIyoXFrnfDUC,'w',-1,'utf-8')
    for tLbVBvOzwGdRHePigThIyoXFrnfDUQ in tLbVBvOzwGdRHePigThIyoXFrnfDUx:
     tLbVBvOzwGdRHePigThIyoXFrnfDUY=tLbVBvOzwGdRHePigThIyoXFrnfDKQ(urllib.parse.parse_qsl(tLbVBvOzwGdRHePigThIyoXFrnfDUQ))
     tLbVBvOzwGdRHePigThIyoXFrnfDcA=tLbVBvOzwGdRHePigThIyoXFrnfDUY.get('skey').strip()
     if tLbVBvOzwGdRHePigThIyoXFrnfDUj!=tLbVBvOzwGdRHePigThIyoXFrnfDcA:
      fp.write(tLbVBvOzwGdRHePigThIyoXFrnfDUQ)
    fp.close()
   except:
    tLbVBvOzwGdRHePigThIyoXFrnfDKW
  elif tLbVBvOzwGdRHePigThIyoXFrnfDUl=='WATCH_ALL':
   tLbVBvOzwGdRHePigThIyoXFrnfDUC=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%tLbVBvOzwGdRHePigThIyoXFrnfDUm))
   if os.path.isfile(tLbVBvOzwGdRHePigThIyoXFrnfDUC):os.remove(tLbVBvOzwGdRHePigThIyoXFrnfDUC)
  elif tLbVBvOzwGdRHePigThIyoXFrnfDUl=='WATCH_ONE':
   tLbVBvOzwGdRHePigThIyoXFrnfDUC=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%tLbVBvOzwGdRHePigThIyoXFrnfDUm))
   try:
    tLbVBvOzwGdRHePigThIyoXFrnfDUx=tLbVBvOzwGdRHePigThIyoXFrnfDsq.Load_List_File(tLbVBvOzwGdRHePigThIyoXFrnfDUm) 
    fp=tLbVBvOzwGdRHePigThIyoXFrnfDKm(tLbVBvOzwGdRHePigThIyoXFrnfDUC,'w',-1,'utf-8')
    for tLbVBvOzwGdRHePigThIyoXFrnfDUQ in tLbVBvOzwGdRHePigThIyoXFrnfDUx:
     tLbVBvOzwGdRHePigThIyoXFrnfDUY=tLbVBvOzwGdRHePigThIyoXFrnfDKQ(urllib.parse.parse_qsl(tLbVBvOzwGdRHePigThIyoXFrnfDUQ))
     tLbVBvOzwGdRHePigThIyoXFrnfDcA=tLbVBvOzwGdRHePigThIyoXFrnfDUY.get('code').strip()
     if tLbVBvOzwGdRHePigThIyoXFrnfDUj!=tLbVBvOzwGdRHePigThIyoXFrnfDcA:
      fp.write(tLbVBvOzwGdRHePigThIyoXFrnfDUQ)
    fp.close()
   except:
    tLbVBvOzwGdRHePigThIyoXFrnfDKW
  xbmc.executebuiltin("Container.Refresh")
 def Save_Searched_List(tLbVBvOzwGdRHePigThIyoXFrnfDsq,tLbVBvOzwGdRHePigThIyoXFrnfDJA):
  try:
   tLbVBvOzwGdRHePigThIyoXFrnfDcJ=tLbVBvOzwGdRHePigThIyoXFrnfDsK
   tLbVBvOzwGdRHePigThIyoXFrnfDUx=tLbVBvOzwGdRHePigThIyoXFrnfDsq.Load_List_File('search') 
   tLbVBvOzwGdRHePigThIyoXFrnfDcU={'skey':tLbVBvOzwGdRHePigThIyoXFrnfDJA.strip()}
   fp=tLbVBvOzwGdRHePigThIyoXFrnfDKm(tLbVBvOzwGdRHePigThIyoXFrnfDcJ,'w',-1,'utf-8')
   tLbVBvOzwGdRHePigThIyoXFrnfDUk=urllib.parse.urlencode(tLbVBvOzwGdRHePigThIyoXFrnfDcU)
   tLbVBvOzwGdRHePigThIyoXFrnfDUk=tLbVBvOzwGdRHePigThIyoXFrnfDUk+'\n'
   fp.write(tLbVBvOzwGdRHePigThIyoXFrnfDUk)
   tLbVBvOzwGdRHePigThIyoXFrnfDUE=0
   for tLbVBvOzwGdRHePigThIyoXFrnfDUQ in tLbVBvOzwGdRHePigThIyoXFrnfDUx:
    tLbVBvOzwGdRHePigThIyoXFrnfDUY=tLbVBvOzwGdRHePigThIyoXFrnfDKQ(urllib.parse.parse_qsl(tLbVBvOzwGdRHePigThIyoXFrnfDUQ))
    tLbVBvOzwGdRHePigThIyoXFrnfDUM=tLbVBvOzwGdRHePigThIyoXFrnfDcU.get('skey').strip()
    tLbVBvOzwGdRHePigThIyoXFrnfDUN=tLbVBvOzwGdRHePigThIyoXFrnfDUY.get('skey').strip()
    if tLbVBvOzwGdRHePigThIyoXFrnfDUM!=tLbVBvOzwGdRHePigThIyoXFrnfDUN:
     fp.write(tLbVBvOzwGdRHePigThIyoXFrnfDUQ)
     tLbVBvOzwGdRHePigThIyoXFrnfDUE+=1
     if tLbVBvOzwGdRHePigThIyoXFrnfDUE>=50:break
   fp.close()
  except:
   tLbVBvOzwGdRHePigThIyoXFrnfDKW
 def dp_Global_Search(tLbVBvOzwGdRHePigThIyoXFrnfDsq,args):
  tLbVBvOzwGdRHePigThIyoXFrnfDJc=args.get('mode')
  if tLbVBvOzwGdRHePigThIyoXFrnfDJc=='TOTAL_SEARCH':
   tLbVBvOzwGdRHePigThIyoXFrnfDcS='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   tLbVBvOzwGdRHePigThIyoXFrnfDcS='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(tLbVBvOzwGdRHePigThIyoXFrnfDcS)
 def dp_Bookmark_Menu(tLbVBvOzwGdRHePigThIyoXFrnfDsq,args):
  tLbVBvOzwGdRHePigThIyoXFrnfDcS='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(tLbVBvOzwGdRHePigThIyoXFrnfDcS)
 def login_main(tLbVBvOzwGdRHePigThIyoXFrnfDsq):
  (tLbVBvOzwGdRHePigThIyoXFrnfDcp,tLbVBvOzwGdRHePigThIyoXFrnfDcK,tLbVBvOzwGdRHePigThIyoXFrnfDcq)=tLbVBvOzwGdRHePigThIyoXFrnfDsq.get_settings_account()
  if not(tLbVBvOzwGdRHePigThIyoXFrnfDcp and tLbVBvOzwGdRHePigThIyoXFrnfDcK):
   tLbVBvOzwGdRHePigThIyoXFrnfDsx=xbmcgui.Dialog()
   tLbVBvOzwGdRHePigThIyoXFrnfDcs=tLbVBvOzwGdRHePigThIyoXFrnfDsx.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if tLbVBvOzwGdRHePigThIyoXFrnfDcs==tLbVBvOzwGdRHePigThIyoXFrnfDKx:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if tLbVBvOzwGdRHePigThIyoXFrnfDsq.cookiefile_check()==tLbVBvOzwGdRHePigThIyoXFrnfDKx:return
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   tLbVBvOzwGdRHePigThIyoXFrnfDca=0
   while tLbVBvOzwGdRHePigThIyoXFrnfDKx:
    tLbVBvOzwGdRHePigThIyoXFrnfDca+=1
    time.sleep(0.05)
    if tLbVBvOzwGdRHePigThIyoXFrnfDca>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  tLbVBvOzwGdRHePigThIyoXFrnfDcC=tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.GetCredential_new(tLbVBvOzwGdRHePigThIyoXFrnfDcp,tLbVBvOzwGdRHePigThIyoXFrnfDcK,tLbVBvOzwGdRHePigThIyoXFrnfDcq)
  if tLbVBvOzwGdRHePigThIyoXFrnfDcC:tLbVBvOzwGdRHePigThIyoXFrnfDsq.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
  if tLbVBvOzwGdRHePigThIyoXFrnfDcC==tLbVBvOzwGdRHePigThIyoXFrnfDKk:
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_setEpOrderby(tLbVBvOzwGdRHePigThIyoXFrnfDsq,args):
  tLbVBvOzwGdRHePigThIyoXFrnfDAC =args.get('orderby')
  tLbVBvOzwGdRHePigThIyoXFrnfDsq.set_winEpisodeOrderby(tLbVBvOzwGdRHePigThIyoXFrnfDAC)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(tLbVBvOzwGdRHePigThIyoXFrnfDsq,args):
  tLbVBvOzwGdRHePigThIyoXFrnfDJc =args.get('mode')
  tLbVBvOzwGdRHePigThIyoXFrnfDcW =args.get('contentid')
  tLbVBvOzwGdRHePigThIyoXFrnfDcu =args.get('pvrmode')
  tLbVBvOzwGdRHePigThIyoXFrnfDcx=tLbVBvOzwGdRHePigThIyoXFrnfDsq.get_selQuality()
  tLbVBvOzwGdRHePigThIyoXFrnfDAU =tLbVBvOzwGdRHePigThIyoXFrnfDsq.get_settings_play()
  tLbVBvOzwGdRHePigThIyoXFrnfDsq.addon_log(tLbVBvOzwGdRHePigThIyoXFrnfDcW+' - '+tLbVBvOzwGdRHePigThIyoXFrnfDJc)
  if tLbVBvOzwGdRHePigThIyoXFrnfDJc=='SPORTS':
   tLbVBvOzwGdRHePigThIyoXFrnfDck=tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.GetSportsURL(tLbVBvOzwGdRHePigThIyoXFrnfDcW,tLbVBvOzwGdRHePigThIyoXFrnfDcx)
  else:
   tLbVBvOzwGdRHePigThIyoXFrnfDck=tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.GetStreamingURL(tLbVBvOzwGdRHePigThIyoXFrnfDJc,tLbVBvOzwGdRHePigThIyoXFrnfDcW,tLbVBvOzwGdRHePigThIyoXFrnfDcx,tLbVBvOzwGdRHePigThIyoXFrnfDcu,playOption=tLbVBvOzwGdRHePigThIyoXFrnfDAU)
  tLbVBvOzwGdRHePigThIyoXFrnfDcE={'user-agent':tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.USER_AGENT}
  tLbVBvOzwGdRHePigThIyoXFrnfDcQ=tLbVBvOzwGdRHePigThIyoXFrnfDck['stream_cookie'] 
  tLbVBvOzwGdRHePigThIyoXFrnfDcY=tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.make_stream_header(tLbVBvOzwGdRHePigThIyoXFrnfDcE,tLbVBvOzwGdRHePigThIyoXFrnfDcQ)
  tLbVBvOzwGdRHePigThIyoXFrnfDcM='{}|{}'.format(tLbVBvOzwGdRHePigThIyoXFrnfDck['stream_url'],tLbVBvOzwGdRHePigThIyoXFrnfDcY)
  tLbVBvOzwGdRHePigThIyoXFrnfDsq.addon_log('surl : '+tLbVBvOzwGdRHePigThIyoXFrnfDcM)
  if tLbVBvOzwGdRHePigThIyoXFrnfDck['stream_url']=='':
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.addon_noti(__language__(30907).encode('utf8'))
   return
  tLbVBvOzwGdRHePigThIyoXFrnfDAc,tLbVBvOzwGdRHePigThIyoXFrnfDAS=tLbVBvOzwGdRHePigThIyoXFrnfDsq.get_settings_proxyport()
  tLbVBvOzwGdRHePigThIyoXFrnfDcN=urllib.parse.urlparse(tLbVBvOzwGdRHePigThIyoXFrnfDck['stream_url'])
  tLbVBvOzwGdRHePigThIyoXFrnfDcN=tLbVBvOzwGdRHePigThIyoXFrnfDcN.path.strip('/').split('/')
  tLbVBvOzwGdRHePigThIyoXFrnfDcN=tLbVBvOzwGdRHePigThIyoXFrnfDcN[tLbVBvOzwGdRHePigThIyoXFrnfDKN(tLbVBvOzwGdRHePigThIyoXFrnfDcN)-1] 
  if (tLbVBvOzwGdRHePigThIyoXFrnfDAc==tLbVBvOzwGdRHePigThIyoXFrnfDKx and args.get('mode')in['VOD','MOVIE']and(tLbVBvOzwGdRHePigThIyoXFrnfDck['playParam']['hdr']=='hdr' or tLbVBvOzwGdRHePigThIyoXFrnfDck['playParam']['uhd']=='uhd')):
   if tLbVBvOzwGdRHePigThIyoXFrnfDcN.split('.')[1]=='mpd':
    tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.Wavve_Parse_mpd(tLbVBvOzwGdRHePigThIyoXFrnfDck)
   else:
    tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.Wavve_Parse_m3u8(tLbVBvOzwGdRHePigThIyoXFrnfDck)
   tLbVBvOzwGdRHePigThIyoXFrnfDcl={'addon':'wavvem','playOption':tLbVBvOzwGdRHePigThIyoXFrnfDAU,}
   tLbVBvOzwGdRHePigThIyoXFrnfDcl=json.dumps(tLbVBvOzwGdRHePigThIyoXFrnfDcl,separators=(',',':'))
   tLbVBvOzwGdRHePigThIyoXFrnfDcl=base64.standard_b64encode(tLbVBvOzwGdRHePigThIyoXFrnfDcl.encode()).decode('utf-8')
   tLbVBvOzwGdRHePigThIyoXFrnfDcM ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(tLbVBvOzwGdRHePigThIyoXFrnfDAS,tLbVBvOzwGdRHePigThIyoXFrnfDcM,tLbVBvOzwGdRHePigThIyoXFrnfDcl)
  tLbVBvOzwGdRHePigThIyoXFrnfDsq.addon_log('surl : '+tLbVBvOzwGdRHePigThIyoXFrnfDcM)
  tLbVBvOzwGdRHePigThIyoXFrnfDcj=xbmcgui.ListItem(path=tLbVBvOzwGdRHePigThIyoXFrnfDcM)
  if tLbVBvOzwGdRHePigThIyoXFrnfDck['stream_drm']:
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.addon_log('!!streaming_drm!!')
   inputstreamhelper.Helper('mpd',drm='com.widevine.alpha').check_inputstream()
   if 'licensetoken' in tLbVBvOzwGdRHePigThIyoXFrnfDck['stream_drm']:
    tLbVBvOzwGdRHePigThIyoXFrnfDSs=tLbVBvOzwGdRHePigThIyoXFrnfDck['stream_drm']['licensetoken']
    tLbVBvOzwGdRHePigThIyoXFrnfDSA =tLbVBvOzwGdRHePigThIyoXFrnfDck['stream_drm']['licenseurl']
    if tLbVBvOzwGdRHePigThIyoXFrnfDJc=='MOVIE':
     tLbVBvOzwGdRHePigThIyoXFrnfDSJ='https://www.wavve.com/player/movie?movieid=%s'%tLbVBvOzwGdRHePigThIyoXFrnfDcW
    else:
     tLbVBvOzwGdRHePigThIyoXFrnfDSJ='https://www.wavve.com/player/vod?programid=%s&page=1'%tLbVBvOzwGdRHePigThIyoXFrnfDcW
    tLbVBvOzwGdRHePigThIyoXFrnfDSU={'content-type':'application/octet-stream','origin':'https://www.wavve.com','License-Token':tLbVBvOzwGdRHePigThIyoXFrnfDSs,'referer':tLbVBvOzwGdRHePigThIyoXFrnfDSJ,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.USER_AGENT,}
   else:
    tLbVBvOzwGdRHePigThIyoXFrnfDSs=tLbVBvOzwGdRHePigThIyoXFrnfDck['stream_drm']['customdata']
    tLbVBvOzwGdRHePigThIyoXFrnfDSA =tLbVBvOzwGdRHePigThIyoXFrnfDck['stream_drm']['drmhost']
    if tLbVBvOzwGdRHePigThIyoXFrnfDJc=='MOVIE':
     tLbVBvOzwGdRHePigThIyoXFrnfDSJ='https://www.wavve.com/player/movie?movieid=%s'%tLbVBvOzwGdRHePigThIyoXFrnfDcW
    else:
     tLbVBvOzwGdRHePigThIyoXFrnfDSJ='https://www.wavve.com/player/vod?programid=%s&page=1'%tLbVBvOzwGdRHePigThIyoXFrnfDcW
    tLbVBvOzwGdRHePigThIyoXFrnfDSU={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':tLbVBvOzwGdRHePigThIyoXFrnfDSs,'referer':tLbVBvOzwGdRHePigThIyoXFrnfDSJ,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.USER_AGENT,}
   tLbVBvOzwGdRHePigThIyoXFrnfDSc=tLbVBvOzwGdRHePigThIyoXFrnfDSA+'|'+urllib.parse.urlencode(tLbVBvOzwGdRHePigThIyoXFrnfDSU)+'|R{SSM}|'
   tLbVBvOzwGdRHePigThIyoXFrnfDcj.setProperty('inputstream','inputstream.adaptive')
   if tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.KodiVersion<=20:
    tLbVBvOzwGdRHePigThIyoXFrnfDcj.setProperty('inputstream.adaptive.manifest_type','mpd')
   tLbVBvOzwGdRHePigThIyoXFrnfDcj.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
   tLbVBvOzwGdRHePigThIyoXFrnfDcj.setProperty('inputstream.adaptive.license_key',tLbVBvOzwGdRHePigThIyoXFrnfDSc)
   tLbVBvOzwGdRHePigThIyoXFrnfDcj.setProperty('inputstream.adaptive.stream_headers',tLbVBvOzwGdRHePigThIyoXFrnfDcY)
   tLbVBvOzwGdRHePigThIyoXFrnfDcj.setProperty('inputstream.adaptive.manifest_headers',tLbVBvOzwGdRHePigThIyoXFrnfDcY)
  elif tLbVBvOzwGdRHePigThIyoXFrnfDJc in['VOD','MOVIE']:
   tLbVBvOzwGdRHePigThIyoXFrnfDcj.setContentLookup(tLbVBvOzwGdRHePigThIyoXFrnfDKk)
   tLbVBvOzwGdRHePigThIyoXFrnfDcj.setMimeType('application/x-mpegURL')
   tLbVBvOzwGdRHePigThIyoXFrnfDcj.setProperty('inputstream','inputstream.adaptive')
   if tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.KodiVersion<=20:
    if tLbVBvOzwGdRHePigThIyoXFrnfDck['stream_action']=='hls':
     tLbVBvOzwGdRHePigThIyoXFrnfDcj.setProperty('inputstream.adaptive.manifest_type','hls')
    else:
     tLbVBvOzwGdRHePigThIyoXFrnfDcj.setProperty('inputstream.adaptive.manifest_type','mpd')
   tLbVBvOzwGdRHePigThIyoXFrnfDcj.setProperty('inputstream.adaptive.stream_headers',tLbVBvOzwGdRHePigThIyoXFrnfDcY)
   tLbVBvOzwGdRHePigThIyoXFrnfDcj.setProperty('inputstream.adaptive.manifest_headers',tLbVBvOzwGdRHePigThIyoXFrnfDcY)
  if tLbVBvOzwGdRHePigThIyoXFrnfDck['stream_vtt']:
   tLbVBvOzwGdRHePigThIyoXFrnfDcj.setSubtitles([tLbVBvOzwGdRHePigThIyoXFrnfDck['stream_vtt']])
  xbmcplugin.setResolvedUrl(tLbVBvOzwGdRHePigThIyoXFrnfDsq._addon_handle,tLbVBvOzwGdRHePigThIyoXFrnfDKx,tLbVBvOzwGdRHePigThIyoXFrnfDcj)
  tLbVBvOzwGdRHePigThIyoXFrnfDSp=tLbVBvOzwGdRHePigThIyoXFrnfDKk
  if tLbVBvOzwGdRHePigThIyoXFrnfDck['stream_preview']:
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.addon_noti(tLbVBvOzwGdRHePigThIyoXFrnfDck['stream_preview'].encode('utf-8'))
   tLbVBvOzwGdRHePigThIyoXFrnfDSp=tLbVBvOzwGdRHePigThIyoXFrnfDKx
  else:
   if '/preview.' in urllib.parse.urlsplit(tLbVBvOzwGdRHePigThIyoXFrnfDck['stream_url']).path:
    tLbVBvOzwGdRHePigThIyoXFrnfDsq.addon_noti(__language__(30908).encode('utf8'))
    tLbVBvOzwGdRHePigThIyoXFrnfDSp=tLbVBvOzwGdRHePigThIyoXFrnfDKx
  try:
   tLbVBvOzwGdRHePigThIyoXFrnfDSK=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and tLbVBvOzwGdRHePigThIyoXFrnfDSp==tLbVBvOzwGdRHePigThIyoXFrnfDKk and tLbVBvOzwGdRHePigThIyoXFrnfDSK!='-':
    tLbVBvOzwGdRHePigThIyoXFrnfDAM={'code':tLbVBvOzwGdRHePigThIyoXFrnfDSK,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    tLbVBvOzwGdRHePigThIyoXFrnfDsq.Save_Watched_List(args.get('mode').lower(),tLbVBvOzwGdRHePigThIyoXFrnfDAM)
  except:
   tLbVBvOzwGdRHePigThIyoXFrnfDKW
 def logout(tLbVBvOzwGdRHePigThIyoXFrnfDsq):
  tLbVBvOzwGdRHePigThIyoXFrnfDsx=xbmcgui.Dialog()
  tLbVBvOzwGdRHePigThIyoXFrnfDcs=tLbVBvOzwGdRHePigThIyoXFrnfDsx.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if tLbVBvOzwGdRHePigThIyoXFrnfDcs==tLbVBvOzwGdRHePigThIyoXFrnfDKk:sys.exit()
  tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.Init_WV_Total()
  if os.path.isfile(tLbVBvOzwGdRHePigThIyoXFrnfDsp):os.remove(tLbVBvOzwGdRHePigThIyoXFrnfDsp)
  tLbVBvOzwGdRHePigThIyoXFrnfDsq.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(tLbVBvOzwGdRHePigThIyoXFrnfDsq):
  tLbVBvOzwGdRHePigThIyoXFrnfDSq =tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.Get_Now_Datetime()
  tLbVBvOzwGdRHePigThIyoXFrnfDSa=tLbVBvOzwGdRHePigThIyoXFrnfDSq+datetime.timedelta(days=tLbVBvOzwGdRHePigThIyoXFrnfDKu(__addon__.getSetting('cache_ttl')))
  (tLbVBvOzwGdRHePigThIyoXFrnfDcp,tLbVBvOzwGdRHePigThIyoXFrnfDcK,tLbVBvOzwGdRHePigThIyoXFrnfDcq)=tLbVBvOzwGdRHePigThIyoXFrnfDsq.get_settings_account()
  tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.Save_session_acount(tLbVBvOzwGdRHePigThIyoXFrnfDcp,tLbVBvOzwGdRHePigThIyoXFrnfDcK,tLbVBvOzwGdRHePigThIyoXFrnfDcq)
  tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.WV['account']['token_limit']=tLbVBvOzwGdRHePigThIyoXFrnfDSa.strftime('%Y%m%d')
  tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.JsonFile_Save(tLbVBvOzwGdRHePigThIyoXFrnfDsp,tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.WV)
 def cookiefile_check(tLbVBvOzwGdRHePigThIyoXFrnfDsq):
  tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.WV=tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.JsonFile_Load(tLbVBvOzwGdRHePigThIyoXFrnfDsp)
  if 'account' not in tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.WV:
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.Init_WV_Total()
   return tLbVBvOzwGdRHePigThIyoXFrnfDKk
  if 'uuid' not in tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.WV.get('cookies'):
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.Init_WV_Total()
   return tLbVBvOzwGdRHePigThIyoXFrnfDKk
  (tLbVBvOzwGdRHePigThIyoXFrnfDSC,tLbVBvOzwGdRHePigThIyoXFrnfDSW,tLbVBvOzwGdRHePigThIyoXFrnfDSu)=tLbVBvOzwGdRHePigThIyoXFrnfDsq.get_settings_account()
  (tLbVBvOzwGdRHePigThIyoXFrnfDSx,tLbVBvOzwGdRHePigThIyoXFrnfDSk,tLbVBvOzwGdRHePigThIyoXFrnfDSE)=tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.Load_session_acount()
  if tLbVBvOzwGdRHePigThIyoXFrnfDSC!=tLbVBvOzwGdRHePigThIyoXFrnfDSx or tLbVBvOzwGdRHePigThIyoXFrnfDSW!=tLbVBvOzwGdRHePigThIyoXFrnfDSk or tLbVBvOzwGdRHePigThIyoXFrnfDSu!=tLbVBvOzwGdRHePigThIyoXFrnfDSE:
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.Init_WV_Total()
   return tLbVBvOzwGdRHePigThIyoXFrnfDKk
  if tLbVBvOzwGdRHePigThIyoXFrnfDKu(tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))>tLbVBvOzwGdRHePigThIyoXFrnfDKu(tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.WV['account']['token_limit']):
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.Init_WV_Total()
   return tLbVBvOzwGdRHePigThIyoXFrnfDKk
  return tLbVBvOzwGdRHePigThIyoXFrnfDKx
 def dp_LiveCatagory_List(tLbVBvOzwGdRHePigThIyoXFrnfDsq,args):
  tLbVBvOzwGdRHePigThIyoXFrnfDSQ =args.get('sCode')
  tLbVBvOzwGdRHePigThIyoXFrnfDSY=args.get('sIndex')
  addon_log('sCode  : {}'.format(tLbVBvOzwGdRHePigThIyoXFrnfDSQ)) 
  addon_log('sIndex : {}'.format(tLbVBvOzwGdRHePigThIyoXFrnfDSY)) 
  tLbVBvOzwGdRHePigThIyoXFrnfDJl,tLbVBvOzwGdRHePigThIyoXFrnfDSM=tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.Get_LiveCatagory_List(tLbVBvOzwGdRHePigThIyoXFrnfDSQ,tLbVBvOzwGdRHePigThIyoXFrnfDSY)
  for tLbVBvOzwGdRHePigThIyoXFrnfDJj in tLbVBvOzwGdRHePigThIyoXFrnfDJl:
   tLbVBvOzwGdRHePigThIyoXFrnfDAu =tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('title')
   tLbVBvOzwGdRHePigThIyoXFrnfDAM={'mode':'LIVE_LIST','genre':tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('genre'),'baseapi':tLbVBvOzwGdRHePigThIyoXFrnfDSM}
   tLbVBvOzwGdRHePigThIyoXFrnfDAj={'title':tLbVBvOzwGdRHePigThIyoXFrnfDAu,'plot':tLbVBvOzwGdRHePigThIyoXFrnfDAu}
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.add_dir(tLbVBvOzwGdRHePigThIyoXFrnfDAu,sublabel='',img='',infoLabels=tLbVBvOzwGdRHePigThIyoXFrnfDAj,isFolder=tLbVBvOzwGdRHePigThIyoXFrnfDKx,params=tLbVBvOzwGdRHePigThIyoXFrnfDAM)
  if tLbVBvOzwGdRHePigThIyoXFrnfDKN(tLbVBvOzwGdRHePigThIyoXFrnfDJl)>0:xbmcplugin.endOfDirectory(tLbVBvOzwGdRHePigThIyoXFrnfDsq._addon_handle,cacheToDisc=tLbVBvOzwGdRHePigThIyoXFrnfDKk)
 def dp_MainCatagory_List(tLbVBvOzwGdRHePigThIyoXFrnfDsq,args):
  tLbVBvOzwGdRHePigThIyoXFrnfDSQ =args.get('sCode')
  tLbVBvOzwGdRHePigThIyoXFrnfDSY=args.get('sIndex')
  tLbVBvOzwGdRHePigThIyoXFrnfDJS =args.get('sType')
  tLbVBvOzwGdRHePigThIyoXFrnfDJl=tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.Get_MainCatagory_List(tLbVBvOzwGdRHePigThIyoXFrnfDSQ,tLbVBvOzwGdRHePigThIyoXFrnfDSY,tLbVBvOzwGdRHePigThIyoXFrnfDJS)
  for tLbVBvOzwGdRHePigThIyoXFrnfDJj in tLbVBvOzwGdRHePigThIyoXFrnfDJl:
   if tLbVBvOzwGdRHePigThIyoXFrnfDJS in['vod','vod09']:
    if tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('subtype')=='catagory':
     tLbVBvOzwGdRHePigThIyoXFrnfDJc='PROGRAM_LIST'
    else:
     tLbVBvOzwGdRHePigThIyoXFrnfDJc='SUPERSECTION_LIST'
   elif tLbVBvOzwGdRHePigThIyoXFrnfDJS=='movie':
    tLbVBvOzwGdRHePigThIyoXFrnfDJc='MOVIE_LIST'
   else:
    tLbVBvOzwGdRHePigThIyoXFrnfDJc=''
   tLbVBvOzwGdRHePigThIyoXFrnfDAu='%s (%s)'%(tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('title'),args.get('ordernm'))
   tLbVBvOzwGdRHePigThIyoXFrnfDAM={'mode':tLbVBvOzwGdRHePigThIyoXFrnfDJc,'suburl':tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('suburl'),'subapi':tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if tLbVBvOzwGdRHePigThIyoXFrnfDsq.get_settings_exclusion21():
    if tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('title')=='성인' or tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('title')=='성인+' or tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('title')=='에로티시즘' or tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('title')=='19':continue
   tLbVBvOzwGdRHePigThIyoXFrnfDAj={'title':tLbVBvOzwGdRHePigThIyoXFrnfDAu,'plot':tLbVBvOzwGdRHePigThIyoXFrnfDAu}
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.add_dir(tLbVBvOzwGdRHePigThIyoXFrnfDAu,sublabel='',img='',infoLabels=tLbVBvOzwGdRHePigThIyoXFrnfDAj,isFolder=tLbVBvOzwGdRHePigThIyoXFrnfDKx,params=tLbVBvOzwGdRHePigThIyoXFrnfDAM)
  if tLbVBvOzwGdRHePigThIyoXFrnfDKN(tLbVBvOzwGdRHePigThIyoXFrnfDJl)>0:xbmcplugin.endOfDirectory(tLbVBvOzwGdRHePigThIyoXFrnfDsq._addon_handle,cacheToDisc=tLbVBvOzwGdRHePigThIyoXFrnfDKk)
 def dp_Program_List(tLbVBvOzwGdRHePigThIyoXFrnfDsq,args):
  tLbVBvOzwGdRHePigThIyoXFrnfDSN =args.get('subapi')
  tLbVBvOzwGdRHePigThIyoXFrnfDJN=tLbVBvOzwGdRHePigThIyoXFrnfDKu(args.get('page'))
  tLbVBvOzwGdRHePigThIyoXFrnfDAC =args.get('orderby')
  tLbVBvOzwGdRHePigThIyoXFrnfDsq.addon_log('dp_Program_List')
  tLbVBvOzwGdRHePigThIyoXFrnfDsq.addon_log(tLbVBvOzwGdRHePigThIyoXFrnfDSN)
  tLbVBvOzwGdRHePigThIyoXFrnfDJl,tLbVBvOzwGdRHePigThIyoXFrnfDJK=tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.Get_Program_List(tLbVBvOzwGdRHePigThIyoXFrnfDSN,tLbVBvOzwGdRHePigThIyoXFrnfDJN,tLbVBvOzwGdRHePigThIyoXFrnfDAC)
  for tLbVBvOzwGdRHePigThIyoXFrnfDJj in tLbVBvOzwGdRHePigThIyoXFrnfDJl:
   tLbVBvOzwGdRHePigThIyoXFrnfDJm =tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('videoid')
   tLbVBvOzwGdRHePigThIyoXFrnfDUs =tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('vidtype')
   tLbVBvOzwGdRHePigThIyoXFrnfDAu =tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('title')
   tLbVBvOzwGdRHePigThIyoXFrnfDUA=tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('thumbnail')
   tLbVBvOzwGdRHePigThIyoXFrnfDAj={'plot':tLbVBvOzwGdRHePigThIyoXFrnfDAu,'mediatype':'tvshow','title':tLbVBvOzwGdRHePigThIyoXFrnfDAu,}
   tLbVBvOzwGdRHePigThIyoXFrnfDAM={'mode':'SEASON_LIST','videoid':tLbVBvOzwGdRHePigThIyoXFrnfDJm,'vidtype':tLbVBvOzwGdRHePigThIyoXFrnfDUs,}
   tLbVBvOzwGdRHePigThIyoXFrnfDJY=[]
   tLbVBvOzwGdRHePigThIyoXFrnfDUc={'mode':'VIEW_DETAIL','values':{'videoid':tLbVBvOzwGdRHePigThIyoXFrnfDJm,'vidtype':'tvshow','contenttype':tLbVBvOzwGdRHePigThIyoXFrnfDUs,}}
   tLbVBvOzwGdRHePigThIyoXFrnfDUS=json.dumps(tLbVBvOzwGdRHePigThIyoXFrnfDUc,separators=(',',':'))
   tLbVBvOzwGdRHePigThIyoXFrnfDUS=base64.standard_b64encode(tLbVBvOzwGdRHePigThIyoXFrnfDUS.encode()).decode('utf-8')
   tLbVBvOzwGdRHePigThIyoXFrnfDUS=tLbVBvOzwGdRHePigThIyoXFrnfDUS.replace('+','%2B')
   tLbVBvOzwGdRHePigThIyoXFrnfDUp='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(tLbVBvOzwGdRHePigThIyoXFrnfDUS)
   tLbVBvOzwGdRHePigThIyoXFrnfDJY.append(('상세정보 조회',tLbVBvOzwGdRHePigThIyoXFrnfDUp))
   if tLbVBvOzwGdRHePigThIyoXFrnfDsq.get_settings_makebookmark():
    tLbVBvOzwGdRHePigThIyoXFrnfDUc={'videoid':tLbVBvOzwGdRHePigThIyoXFrnfDJm,'vidtype':'tvshow','vtitle':tLbVBvOzwGdRHePigThIyoXFrnfDAu,'vsubtitle':'','contenttype':tLbVBvOzwGdRHePigThIyoXFrnfDUs,}
    tLbVBvOzwGdRHePigThIyoXFrnfDUK=json.dumps(tLbVBvOzwGdRHePigThIyoXFrnfDUc)
    tLbVBvOzwGdRHePigThIyoXFrnfDUK=urllib.parse.quote(tLbVBvOzwGdRHePigThIyoXFrnfDUK)
    tLbVBvOzwGdRHePigThIyoXFrnfDUp='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(tLbVBvOzwGdRHePigThIyoXFrnfDUK)
    tLbVBvOzwGdRHePigThIyoXFrnfDJY.append(('(통합) 찜 영상에 추가',tLbVBvOzwGdRHePigThIyoXFrnfDUp))
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.add_dir(tLbVBvOzwGdRHePigThIyoXFrnfDAu,sublabel='',img=tLbVBvOzwGdRHePigThIyoXFrnfDUA,infoLabels=tLbVBvOzwGdRHePigThIyoXFrnfDAj,isFolder=tLbVBvOzwGdRHePigThIyoXFrnfDKx,params=tLbVBvOzwGdRHePigThIyoXFrnfDAM,ContextMenu=tLbVBvOzwGdRHePigThIyoXFrnfDJY)
  if tLbVBvOzwGdRHePigThIyoXFrnfDJK:
   tLbVBvOzwGdRHePigThIyoXFrnfDAM={}
   tLbVBvOzwGdRHePigThIyoXFrnfDAM['mode'] ='PROGRAM_LIST' 
   tLbVBvOzwGdRHePigThIyoXFrnfDAM['subapi']=tLbVBvOzwGdRHePigThIyoXFrnfDSN 
   tLbVBvOzwGdRHePigThIyoXFrnfDAM['page'] =tLbVBvOzwGdRHePigThIyoXFrnfDKj(tLbVBvOzwGdRHePigThIyoXFrnfDJN+1)
   tLbVBvOzwGdRHePigThIyoXFrnfDAu='[B]%s >>[/B]'%'다음 페이지'
   tLbVBvOzwGdRHePigThIyoXFrnfDUq=tLbVBvOzwGdRHePigThIyoXFrnfDKj(tLbVBvOzwGdRHePigThIyoXFrnfDJN+1)
   tLbVBvOzwGdRHePigThIyoXFrnfDAY=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.add_dir(tLbVBvOzwGdRHePigThIyoXFrnfDAu,sublabel=tLbVBvOzwGdRHePigThIyoXFrnfDUq,img=tLbVBvOzwGdRHePigThIyoXFrnfDAY,infoLabels=tLbVBvOzwGdRHePigThIyoXFrnfDKW,isFolder=tLbVBvOzwGdRHePigThIyoXFrnfDKx,params=tLbVBvOzwGdRHePigThIyoXFrnfDAM)
  xbmcplugin.setContent(tLbVBvOzwGdRHePigThIyoXFrnfDsq._addon_handle,'tvshows')
  if tLbVBvOzwGdRHePigThIyoXFrnfDKN(tLbVBvOzwGdRHePigThIyoXFrnfDJl)>0:xbmcplugin.endOfDirectory(tLbVBvOzwGdRHePigThIyoXFrnfDsq._addon_handle,cacheToDisc=tLbVBvOzwGdRHePigThIyoXFrnfDKk)
 def dp_Season_List(tLbVBvOzwGdRHePigThIyoXFrnfDsq,args):
  tLbVBvOzwGdRHePigThIyoXFrnfDJm=args.get('videoid')
  tLbVBvOzwGdRHePigThIyoXFrnfDUs=args.get('vidtype')
  tLbVBvOzwGdRHePigThIyoXFrnfDsq.addon_log('dp_Season_List')
  tLbVBvOzwGdRHePigThIyoXFrnfDsq.addon_log('videoid : '+tLbVBvOzwGdRHePigThIyoXFrnfDJm)
  tLbVBvOzwGdRHePigThIyoXFrnfDsq.addon_log('vidtype : '+tLbVBvOzwGdRHePigThIyoXFrnfDUs)
  if tLbVBvOzwGdRHePigThIyoXFrnfDUs=='contentid':
   tLbVBvOzwGdRHePigThIyoXFrnfDcW=tLbVBvOzwGdRHePigThIyoXFrnfDJm
   tLbVBvOzwGdRHePigThIyoXFrnfDSl =tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.ContentidToSeasonid(tLbVBvOzwGdRHePigThIyoXFrnfDJm)
  else:
   tLbVBvOzwGdRHePigThIyoXFrnfDcW=tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.ProgramidToContentid(tLbVBvOzwGdRHePigThIyoXFrnfDJm)
   tLbVBvOzwGdRHePigThIyoXFrnfDSl =tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.ContentidToSeasonid(tLbVBvOzwGdRHePigThIyoXFrnfDcW)
  tLbVBvOzwGdRHePigThIyoXFrnfDSj=tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.Get_Season_List(tLbVBvOzwGdRHePigThIyoXFrnfDSl)
  if tLbVBvOzwGdRHePigThIyoXFrnfDKN(tLbVBvOzwGdRHePigThIyoXFrnfDSj)>1:
   for tLbVBvOzwGdRHePigThIyoXFrnfDSm in tLbVBvOzwGdRHePigThIyoXFrnfDSj:
    tLbVBvOzwGdRHePigThIyoXFrnfDps=tLbVBvOzwGdRHePigThIyoXFrnfDSm.get('season_Id')
    tLbVBvOzwGdRHePigThIyoXFrnfDpA=tLbVBvOzwGdRHePigThIyoXFrnfDSm.get('season_Nm')
    tLbVBvOzwGdRHePigThIyoXFrnfDpJ=tLbVBvOzwGdRHePigThIyoXFrnfDSm.get('programNm')
    tLbVBvOzwGdRHePigThIyoXFrnfDUA=tLbVBvOzwGdRHePigThIyoXFrnfDSm.get('thumbnail')
    tLbVBvOzwGdRHePigThIyoXFrnfDpU =tLbVBvOzwGdRHePigThIyoXFrnfDSm.get('synopsis')
    tLbVBvOzwGdRHePigThIyoXFrnfDJM={'mediatype':'tvshow','title':tLbVBvOzwGdRHePigThIyoXFrnfDpA,'plot':tLbVBvOzwGdRHePigThIyoXFrnfDpU,}
    tLbVBvOzwGdRHePigThIyoXFrnfDAM={'mode':'EPISODE_LIST','seasonid':tLbVBvOzwGdRHePigThIyoXFrnfDps,'page':'1',}
    tLbVBvOzwGdRHePigThIyoXFrnfDsq.add_dir(tLbVBvOzwGdRHePigThIyoXFrnfDpA,sublabel=tLbVBvOzwGdRHePigThIyoXFrnfDpJ,img=tLbVBvOzwGdRHePigThIyoXFrnfDUA,infoLabels=tLbVBvOzwGdRHePigThIyoXFrnfDJM,isFolder=tLbVBvOzwGdRHePigThIyoXFrnfDKx,params=tLbVBvOzwGdRHePigThIyoXFrnfDAM,ContextMenu=tLbVBvOzwGdRHePigThIyoXFrnfDKW)
   xbmcplugin.setContent(tLbVBvOzwGdRHePigThIyoXFrnfDsq._addon_handle,'seasons')
   xbmcplugin.endOfDirectory(tLbVBvOzwGdRHePigThIyoXFrnfDsq._addon_handle,cacheToDisc=tLbVBvOzwGdRHePigThIyoXFrnfDKk)
  else:
   tLbVBvOzwGdRHePigThIyoXFrnfDpc={'seasonid':tLbVBvOzwGdRHePigThIyoXFrnfDSl,'page':'1',}
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.dp_Episode_List(tLbVBvOzwGdRHePigThIyoXFrnfDpc)
 def dp_Episode_List(tLbVBvOzwGdRHePigThIyoXFrnfDsq,args):
  tLbVBvOzwGdRHePigThIyoXFrnfDSl =args.get('seasonid')
  tLbVBvOzwGdRHePigThIyoXFrnfDJN =tLbVBvOzwGdRHePigThIyoXFrnfDKu(args.get('page'))
  tLbVBvOzwGdRHePigThIyoXFrnfDsq.addon_log('seasonid : '+tLbVBvOzwGdRHePigThIyoXFrnfDSl)
  tLbVBvOzwGdRHePigThIyoXFrnfDJl,tLbVBvOzwGdRHePigThIyoXFrnfDJK=tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.Get_Episode_List(tLbVBvOzwGdRHePigThIyoXFrnfDSl,tLbVBvOzwGdRHePigThIyoXFrnfDJN,orderby=tLbVBvOzwGdRHePigThIyoXFrnfDsq.get_winEpisodeOrderby())
  for tLbVBvOzwGdRHePigThIyoXFrnfDJj in tLbVBvOzwGdRHePigThIyoXFrnfDJl:
   tLbVBvOzwGdRHePigThIyoXFrnfDUq=tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('episodenumber')
   tLbVBvOzwGdRHePigThIyoXFrnfDpS ='[%s]\n\n%s'%(tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('episodetitle'),tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('synopsis'))
   tLbVBvOzwGdRHePigThIyoXFrnfDJM={'mediatype':'episode','title':tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('programtitle'),'plot':tLbVBvOzwGdRHePigThIyoXFrnfDpS,'cast':tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('episodeactors'),}
   tLbVBvOzwGdRHePigThIyoXFrnfDAM={'mode':'VOD','programid':tLbVBvOzwGdRHePigThIyoXFrnfDSl,'contentid':tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('contentid'),'thumbnail':tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('thumbnail'),'title':tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('programtitle'),'subtitle':tLbVBvOzwGdRHePigThIyoXFrnfDUq,}
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.add_dir(tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('programtitle'),sublabel=tLbVBvOzwGdRHePigThIyoXFrnfDUq,img=tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('thumbnail'),infoLabels=tLbVBvOzwGdRHePigThIyoXFrnfDJM,isFolder=tLbVBvOzwGdRHePigThIyoXFrnfDKk,params=tLbVBvOzwGdRHePigThIyoXFrnfDAM)
  if tLbVBvOzwGdRHePigThIyoXFrnfDJN==1:
   tLbVBvOzwGdRHePigThIyoXFrnfDJM={'plot':'정렬순서를 변경합니다.'}
   tLbVBvOzwGdRHePigThIyoXFrnfDAM={}
   tLbVBvOzwGdRHePigThIyoXFrnfDAM['mode'] ='ORDER_BY' 
   if tLbVBvOzwGdRHePigThIyoXFrnfDsq.get_winEpisodeOrderby()=='desc':
    tLbVBvOzwGdRHePigThIyoXFrnfDAu='정렬순서변경 : 최신화부터 -> 1회부터'
    tLbVBvOzwGdRHePigThIyoXFrnfDAM['orderby']='asc'
   else:
    tLbVBvOzwGdRHePigThIyoXFrnfDAu='정렬순서변경 : 1회부터 -> 최신화부터'
    tLbVBvOzwGdRHePigThIyoXFrnfDAM['orderby']='desc'
   tLbVBvOzwGdRHePigThIyoXFrnfDAY=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.add_dir(tLbVBvOzwGdRHePigThIyoXFrnfDAu,sublabel='',img=tLbVBvOzwGdRHePigThIyoXFrnfDAY,infoLabels=tLbVBvOzwGdRHePigThIyoXFrnfDJM,isFolder=tLbVBvOzwGdRHePigThIyoXFrnfDKk,params=tLbVBvOzwGdRHePigThIyoXFrnfDAM,isLink=tLbVBvOzwGdRHePigThIyoXFrnfDKx)
  if tLbVBvOzwGdRHePigThIyoXFrnfDJK:
   tLbVBvOzwGdRHePigThIyoXFrnfDAM={}
   tLbVBvOzwGdRHePigThIyoXFrnfDAM['mode'] ='EPISODE_LIST' 
   tLbVBvOzwGdRHePigThIyoXFrnfDAM['seasonid']=tLbVBvOzwGdRHePigThIyoXFrnfDSl
   tLbVBvOzwGdRHePigThIyoXFrnfDAM['page'] =tLbVBvOzwGdRHePigThIyoXFrnfDKj(tLbVBvOzwGdRHePigThIyoXFrnfDJN+1)
   tLbVBvOzwGdRHePigThIyoXFrnfDAu='[B]%s >>[/B]'%'다음 페이지'
   tLbVBvOzwGdRHePigThIyoXFrnfDUq=tLbVBvOzwGdRHePigThIyoXFrnfDKj(tLbVBvOzwGdRHePigThIyoXFrnfDJN+1)
   tLbVBvOzwGdRHePigThIyoXFrnfDAY=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.add_dir(tLbVBvOzwGdRHePigThIyoXFrnfDAu,sublabel=tLbVBvOzwGdRHePigThIyoXFrnfDUq,img=tLbVBvOzwGdRHePigThIyoXFrnfDAY,infoLabels=tLbVBvOzwGdRHePigThIyoXFrnfDKW,isFolder=tLbVBvOzwGdRHePigThIyoXFrnfDKx,params=tLbVBvOzwGdRHePigThIyoXFrnfDAM)
  xbmcplugin.setContent(tLbVBvOzwGdRHePigThIyoXFrnfDsq._addon_handle,'episodes')
  if tLbVBvOzwGdRHePigThIyoXFrnfDKN(tLbVBvOzwGdRHePigThIyoXFrnfDJl)>0:xbmcplugin.endOfDirectory(tLbVBvOzwGdRHePigThIyoXFrnfDsq._addon_handle,cacheToDisc=tLbVBvOzwGdRHePigThIyoXFrnfDKk)
 def dp_SuperSection_List(tLbVBvOzwGdRHePigThIyoXFrnfDsq,args):
  tLbVBvOzwGdRHePigThIyoXFrnfDpK =args.get('suburl')
  tLbVBvOzwGdRHePigThIyoXFrnfDSN =args.get('subapi')
  tLbVBvOzwGdRHePigThIyoXFrnfDsq.addon_log('dp_SuperSection_List')
  tLbVBvOzwGdRHePigThIyoXFrnfDsq.addon_log('suburl : '+tLbVBvOzwGdRHePigThIyoXFrnfDpK)
  tLbVBvOzwGdRHePigThIyoXFrnfDsq.addon_log('subapi : '+tLbVBvOzwGdRHePigThIyoXFrnfDSN)
  tLbVBvOzwGdRHePigThIyoXFrnfDJl=tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.Get_SuperMultiSection_List(tLbVBvOzwGdRHePigThIyoXFrnfDpK)
  for tLbVBvOzwGdRHePigThIyoXFrnfDJj in tLbVBvOzwGdRHePigThIyoXFrnfDJl:
   tLbVBvOzwGdRHePigThIyoXFrnfDAu =tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('title')
   tLbVBvOzwGdRHePigThIyoXFrnfDSN =tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('subapi')
   tLbVBvOzwGdRHePigThIyoXFrnfDpq=tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('cell_type')
   if tLbVBvOzwGdRHePigThIyoXFrnfDSN.find('contenttype=movie')>=0 or tLbVBvOzwGdRHePigThIyoXFrnfDSN.find('mtype=svod')>=0:
    tLbVBvOzwGdRHePigThIyoXFrnfDJc='MOVIE_LIST'
   elif re.search('themes/2\d{4}',tLbVBvOzwGdRHePigThIyoXFrnfDSN)or re.search('themes-band/9\d{4}',tLbVBvOzwGdRHePigThIyoXFrnfDSN):
    tLbVBvOzwGdRHePigThIyoXFrnfDJc='MOVIE_LIST'
   else:
    tLbVBvOzwGdRHePigThIyoXFrnfDJc='PROGRAM_LIST'
   '''
   if subapi.find('mtype=svod') >= 0 or subapi.find('mtype=ppv') >= 0 or subapi.find('contenttype=movie') >= 0: #영화 #20201107
    mode = 'MOVIE_LIST'
   elif subapi.find('contenttype=program') >= 0:
    mode = 'PROGRAM_LIST'
   elif cell_type == 'band_71': # band_71 #20201107
    mode   = 'SUPERSECTION_LIST'
    (temp_url, temp_api) = self.WavveObj.Baseapi_Parse(subapi)
    suburl = temp_api.get('api')
    subapi = ''
   elif cell_type == 'band_2': # band_2
    mode = 'BAND2SECTION_LIST'
   elif cell_type == 'band_live':
    mode = 'BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}', subapi) :
    mode = 'MOVIE_LIST'
   else: # band_10
    mode = 'PROGRAM_LIST'
   '''   
   tLbVBvOzwGdRHePigThIyoXFrnfDJM={'plot':tLbVBvOzwGdRHePigThIyoXFrnfDAu,'mediatype':'tvshow',}
   tLbVBvOzwGdRHePigThIyoXFrnfDAM={'mode':tLbVBvOzwGdRHePigThIyoXFrnfDJc,'suburl':tLbVBvOzwGdRHePigThIyoXFrnfDpK,'subapi':tLbVBvOzwGdRHePigThIyoXFrnfDSN,'page':'1',}
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.add_dir(tLbVBvOzwGdRHePigThIyoXFrnfDAu,sublabel='',img=tLbVBvOzwGdRHePigThIyoXFrnfDKW,infoLabels=tLbVBvOzwGdRHePigThIyoXFrnfDJM,isFolder=tLbVBvOzwGdRHePigThIyoXFrnfDKx,params=tLbVBvOzwGdRHePigThIyoXFrnfDAM)
  if tLbVBvOzwGdRHePigThIyoXFrnfDKN(tLbVBvOzwGdRHePigThIyoXFrnfDJl)>0:xbmcplugin.endOfDirectory(tLbVBvOzwGdRHePigThIyoXFrnfDsq._addon_handle,cacheToDisc=tLbVBvOzwGdRHePigThIyoXFrnfDKk)
 def dp_BandLiveSection_List(tLbVBvOzwGdRHePigThIyoXFrnfDsq,args):
  tLbVBvOzwGdRHePigThIyoXFrnfDSN =args.get('subapi')
  tLbVBvOzwGdRHePigThIyoXFrnfDJN=tLbVBvOzwGdRHePigThIyoXFrnfDKu(args.get('page'))
  tLbVBvOzwGdRHePigThIyoXFrnfDJl,tLbVBvOzwGdRHePigThIyoXFrnfDJK=tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.Get_BandLiveSection_List(tLbVBvOzwGdRHePigThIyoXFrnfDSN,tLbVBvOzwGdRHePigThIyoXFrnfDJN)
  for tLbVBvOzwGdRHePigThIyoXFrnfDJj in tLbVBvOzwGdRHePigThIyoXFrnfDJl:
   tLbVBvOzwGdRHePigThIyoXFrnfDpa =tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('channelid')
   tLbVBvOzwGdRHePigThIyoXFrnfDpC =tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('studio')
   tLbVBvOzwGdRHePigThIyoXFrnfDpW=tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('tvshowtitle')
   tLbVBvOzwGdRHePigThIyoXFrnfDUA =tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('thumbnail')
   tLbVBvOzwGdRHePigThIyoXFrnfDUJ =tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('age')
   tLbVBvOzwGdRHePigThIyoXFrnfDJM={'mediatype':'tvshow','mpaa':tLbVBvOzwGdRHePigThIyoXFrnfDUJ,'title':'%s < %s >'%(tLbVBvOzwGdRHePigThIyoXFrnfDpC,tLbVBvOzwGdRHePigThIyoXFrnfDpW),'tvshowtitle':tLbVBvOzwGdRHePigThIyoXFrnfDpW,'studio':tLbVBvOzwGdRHePigThIyoXFrnfDpC,'plot':tLbVBvOzwGdRHePigThIyoXFrnfDpC}
   tLbVBvOzwGdRHePigThIyoXFrnfDAM={'mode':'LIVE','contentid':tLbVBvOzwGdRHePigThIyoXFrnfDpa}
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.add_dir(tLbVBvOzwGdRHePigThIyoXFrnfDpC,sublabel=tLbVBvOzwGdRHePigThIyoXFrnfDpW,img=tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('thumbnail'),infoLabels=tLbVBvOzwGdRHePigThIyoXFrnfDJM,isFolder=tLbVBvOzwGdRHePigThIyoXFrnfDKk,params=tLbVBvOzwGdRHePigThIyoXFrnfDAM)
  if tLbVBvOzwGdRHePigThIyoXFrnfDJK:
   tLbVBvOzwGdRHePigThIyoXFrnfDAM={}
   tLbVBvOzwGdRHePigThIyoXFrnfDAM['mode'] ='BANDLIVESECTION_LIST' 
   tLbVBvOzwGdRHePigThIyoXFrnfDAM['subapi']=tLbVBvOzwGdRHePigThIyoXFrnfDSN
   tLbVBvOzwGdRHePigThIyoXFrnfDAM['page'] =tLbVBvOzwGdRHePigThIyoXFrnfDKj(tLbVBvOzwGdRHePigThIyoXFrnfDJN+1)
   tLbVBvOzwGdRHePigThIyoXFrnfDAu='[B]%s >>[/B]'%'다음 페이지'
   tLbVBvOzwGdRHePigThIyoXFrnfDUq=tLbVBvOzwGdRHePigThIyoXFrnfDKj(tLbVBvOzwGdRHePigThIyoXFrnfDJN+1)
   tLbVBvOzwGdRHePigThIyoXFrnfDAY=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.add_dir(tLbVBvOzwGdRHePigThIyoXFrnfDAu,sublabel=tLbVBvOzwGdRHePigThIyoXFrnfDUq,img=tLbVBvOzwGdRHePigThIyoXFrnfDAY,infoLabels=tLbVBvOzwGdRHePigThIyoXFrnfDKW,isFolder=tLbVBvOzwGdRHePigThIyoXFrnfDKx,params=tLbVBvOzwGdRHePigThIyoXFrnfDAM)
  if tLbVBvOzwGdRHePigThIyoXFrnfDKN(tLbVBvOzwGdRHePigThIyoXFrnfDJl)>0:xbmcplugin.endOfDirectory(tLbVBvOzwGdRHePigThIyoXFrnfDsq._addon_handle,cacheToDisc=tLbVBvOzwGdRHePigThIyoXFrnfDKk)
 def dp_Band2Section_List(tLbVBvOzwGdRHePigThIyoXFrnfDsq,args):
  tLbVBvOzwGdRHePigThIyoXFrnfDSN =args.get('subapi')
  tLbVBvOzwGdRHePigThIyoXFrnfDJN=tLbVBvOzwGdRHePigThIyoXFrnfDKu(args.get('page'))
  tLbVBvOzwGdRHePigThIyoXFrnfDJl,tLbVBvOzwGdRHePigThIyoXFrnfDJK=tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.Get_Band2Section_List(tLbVBvOzwGdRHePigThIyoXFrnfDSN,tLbVBvOzwGdRHePigThIyoXFrnfDJN)
  for tLbVBvOzwGdRHePigThIyoXFrnfDJj in tLbVBvOzwGdRHePigThIyoXFrnfDJl:
   tLbVBvOzwGdRHePigThIyoXFrnfDAu =tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('programtitle')
   tLbVBvOzwGdRHePigThIyoXFrnfDUq =tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('episodetitle')
   tLbVBvOzwGdRHePigThIyoXFrnfDJM={'plot':tLbVBvOzwGdRHePigThIyoXFrnfDAu+'\n\n'+tLbVBvOzwGdRHePigThIyoXFrnfDUq,'mpaa':tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('age'),'mediatype':'episode'}
   tLbVBvOzwGdRHePigThIyoXFrnfDAM={'mode':'VOD','programid':'-','contentid':tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('videoid'),'thumbnail':tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('thumbnail'),'title':tLbVBvOzwGdRHePigThIyoXFrnfDAu,'subtitle':tLbVBvOzwGdRHePigThIyoXFrnfDUq}
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.add_dir(tLbVBvOzwGdRHePigThIyoXFrnfDAu,sublabel=tLbVBvOzwGdRHePigThIyoXFrnfDUq,img=tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('thumbnail'),infoLabels=tLbVBvOzwGdRHePigThIyoXFrnfDJM,isFolder=tLbVBvOzwGdRHePigThIyoXFrnfDKk,params=tLbVBvOzwGdRHePigThIyoXFrnfDAM)
  if tLbVBvOzwGdRHePigThIyoXFrnfDJK:
   tLbVBvOzwGdRHePigThIyoXFrnfDAM={}
   tLbVBvOzwGdRHePigThIyoXFrnfDAM['mode'] ='BAND2SECTION_LIST' 
   tLbVBvOzwGdRHePigThIyoXFrnfDAM['subapi']=tLbVBvOzwGdRHePigThIyoXFrnfDSN
   tLbVBvOzwGdRHePigThIyoXFrnfDAM['page'] =tLbVBvOzwGdRHePigThIyoXFrnfDKj(tLbVBvOzwGdRHePigThIyoXFrnfDJN+1)
   tLbVBvOzwGdRHePigThIyoXFrnfDAu='[B]%s >>[/B]'%'다음 페이지'
   tLbVBvOzwGdRHePigThIyoXFrnfDUq=tLbVBvOzwGdRHePigThIyoXFrnfDKj(tLbVBvOzwGdRHePigThIyoXFrnfDJN+1)
   tLbVBvOzwGdRHePigThIyoXFrnfDAY=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.add_dir(tLbVBvOzwGdRHePigThIyoXFrnfDAu,sublabel=tLbVBvOzwGdRHePigThIyoXFrnfDUq,img=tLbVBvOzwGdRHePigThIyoXFrnfDAY,infoLabels=tLbVBvOzwGdRHePigThIyoXFrnfDKW,isFolder=tLbVBvOzwGdRHePigThIyoXFrnfDKx,params=tLbVBvOzwGdRHePigThIyoXFrnfDAM)
  if tLbVBvOzwGdRHePigThIyoXFrnfDKN(tLbVBvOzwGdRHePigThIyoXFrnfDJl)>0:xbmcplugin.endOfDirectory(tLbVBvOzwGdRHePigThIyoXFrnfDsq._addon_handle,cacheToDisc=tLbVBvOzwGdRHePigThIyoXFrnfDKk)
 def dp_Movie_List(tLbVBvOzwGdRHePigThIyoXFrnfDsq,args):
  tLbVBvOzwGdRHePigThIyoXFrnfDSN =args.get('subapi')
  tLbVBvOzwGdRHePigThIyoXFrnfDJN=tLbVBvOzwGdRHePigThIyoXFrnfDKu(args.get('page'))
  tLbVBvOzwGdRHePigThIyoXFrnfDAC =args.get('orderby')or '-'
  tLbVBvOzwGdRHePigThIyoXFrnfDsq.addon_log('dp_Movie_List')
  tLbVBvOzwGdRHePigThIyoXFrnfDsq.addon_log(tLbVBvOzwGdRHePigThIyoXFrnfDSN)
  tLbVBvOzwGdRHePigThIyoXFrnfDJl,tLbVBvOzwGdRHePigThIyoXFrnfDJK=tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.Get_Movie_List(tLbVBvOzwGdRHePigThIyoXFrnfDSN,tLbVBvOzwGdRHePigThIyoXFrnfDJN,tLbVBvOzwGdRHePigThIyoXFrnfDAC)
  for tLbVBvOzwGdRHePigThIyoXFrnfDJj in tLbVBvOzwGdRHePigThIyoXFrnfDJl:
   tLbVBvOzwGdRHePigThIyoXFrnfDJm =tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('videoid')
   tLbVBvOzwGdRHePigThIyoXFrnfDUs =tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('vidtype')
   tLbVBvOzwGdRHePigThIyoXFrnfDAu =tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('title')
   tLbVBvOzwGdRHePigThIyoXFrnfDUA=tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('thumbnail')
   tLbVBvOzwGdRHePigThIyoXFrnfDUJ =tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('age')
   if tLbVBvOzwGdRHePigThIyoXFrnfDUJ=='18' or tLbVBvOzwGdRHePigThIyoXFrnfDUJ=='19' or tLbVBvOzwGdRHePigThIyoXFrnfDUJ=='21':tLbVBvOzwGdRHePigThIyoXFrnfDAu+=' (%s)'%(tLbVBvOzwGdRHePigThIyoXFrnfDUJ)
   tLbVBvOzwGdRHePigThIyoXFrnfDJM={'plot':tLbVBvOzwGdRHePigThIyoXFrnfDAu,'mpaa':tLbVBvOzwGdRHePigThIyoXFrnfDUJ,'mediatype':'movie'}
   tLbVBvOzwGdRHePigThIyoXFrnfDAM={'mode':'MOVIE','contentid':tLbVBvOzwGdRHePigThIyoXFrnfDJm,'title':tLbVBvOzwGdRHePigThIyoXFrnfDAu,'thumbnail':tLbVBvOzwGdRHePigThIyoXFrnfDUA,'age':tLbVBvOzwGdRHePigThIyoXFrnfDUJ,}
   tLbVBvOzwGdRHePigThIyoXFrnfDJY=[]
   tLbVBvOzwGdRHePigThIyoXFrnfDUc={'mode':'VIEW_DETAIL','values':{'videoid':tLbVBvOzwGdRHePigThIyoXFrnfDJm,'vidtype':'movie','contenttype':tLbVBvOzwGdRHePigThIyoXFrnfDUs,}}
   tLbVBvOzwGdRHePigThIyoXFrnfDUS=json.dumps(tLbVBvOzwGdRHePigThIyoXFrnfDUc,separators=(',',':'))
   tLbVBvOzwGdRHePigThIyoXFrnfDUS=base64.standard_b64encode(tLbVBvOzwGdRHePigThIyoXFrnfDUS.encode()).decode('utf-8')
   tLbVBvOzwGdRHePigThIyoXFrnfDUS=tLbVBvOzwGdRHePigThIyoXFrnfDUS.replace('+','%2B')
   tLbVBvOzwGdRHePigThIyoXFrnfDUp='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(tLbVBvOzwGdRHePigThIyoXFrnfDUS)
   tLbVBvOzwGdRHePigThIyoXFrnfDJY.append(('상세정보 조회',tLbVBvOzwGdRHePigThIyoXFrnfDUp))
   if tLbVBvOzwGdRHePigThIyoXFrnfDsq.get_settings_makebookmark():
    tLbVBvOzwGdRHePigThIyoXFrnfDUc={'videoid':tLbVBvOzwGdRHePigThIyoXFrnfDJm,'vidtype':'movie','vtitle':tLbVBvOzwGdRHePigThIyoXFrnfDAu,'vsubtitle':'','contenttype':'programid',}
    tLbVBvOzwGdRHePigThIyoXFrnfDUK=json.dumps(tLbVBvOzwGdRHePigThIyoXFrnfDUc)
    tLbVBvOzwGdRHePigThIyoXFrnfDUK=urllib.parse.quote(tLbVBvOzwGdRHePigThIyoXFrnfDUK)
    tLbVBvOzwGdRHePigThIyoXFrnfDUp='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(tLbVBvOzwGdRHePigThIyoXFrnfDUK)
    tLbVBvOzwGdRHePigThIyoXFrnfDJY.append(('(통합) 찜 영상에 추가',tLbVBvOzwGdRHePigThIyoXFrnfDUp))
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.add_dir(tLbVBvOzwGdRHePigThIyoXFrnfDAu,sublabel='',img=tLbVBvOzwGdRHePigThIyoXFrnfDUA,infoLabels=tLbVBvOzwGdRHePigThIyoXFrnfDJM,isFolder=tLbVBvOzwGdRHePigThIyoXFrnfDKk,params=tLbVBvOzwGdRHePigThIyoXFrnfDAM,ContextMenu=tLbVBvOzwGdRHePigThIyoXFrnfDJY)
  if tLbVBvOzwGdRHePigThIyoXFrnfDJK:
   tLbVBvOzwGdRHePigThIyoXFrnfDAM={}
   tLbVBvOzwGdRHePigThIyoXFrnfDAM['mode'] ='MOVIE_LIST' 
   tLbVBvOzwGdRHePigThIyoXFrnfDAM['subapi']=tLbVBvOzwGdRHePigThIyoXFrnfDSN 
   tLbVBvOzwGdRHePigThIyoXFrnfDAM['page'] =tLbVBvOzwGdRHePigThIyoXFrnfDKj(tLbVBvOzwGdRHePigThIyoXFrnfDJN+1)
   tLbVBvOzwGdRHePigThIyoXFrnfDAM['orderby']=tLbVBvOzwGdRHePigThIyoXFrnfDAC
   tLbVBvOzwGdRHePigThIyoXFrnfDAu='[B]%s >>[/B]'%'다음 페이지'
   tLbVBvOzwGdRHePigThIyoXFrnfDUq=tLbVBvOzwGdRHePigThIyoXFrnfDKj(tLbVBvOzwGdRHePigThIyoXFrnfDJN+1)
   tLbVBvOzwGdRHePigThIyoXFrnfDAY=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.add_dir(tLbVBvOzwGdRHePigThIyoXFrnfDAu,sublabel=tLbVBvOzwGdRHePigThIyoXFrnfDUq,img=tLbVBvOzwGdRHePigThIyoXFrnfDAY,infoLabels=tLbVBvOzwGdRHePigThIyoXFrnfDKW,isFolder=tLbVBvOzwGdRHePigThIyoXFrnfDKx,params=tLbVBvOzwGdRHePigThIyoXFrnfDAM)
  xbmcplugin.setContent(tLbVBvOzwGdRHePigThIyoXFrnfDsq._addon_handle,'movies')
  if tLbVBvOzwGdRHePigThIyoXFrnfDKN(tLbVBvOzwGdRHePigThIyoXFrnfDJl)>0:xbmcplugin.endOfDirectory(tLbVBvOzwGdRHePigThIyoXFrnfDsq._addon_handle,cacheToDisc=tLbVBvOzwGdRHePigThIyoXFrnfDKk)
 def dp_Set_Bookmark(tLbVBvOzwGdRHePigThIyoXFrnfDsq,args):
  tLbVBvOzwGdRHePigThIyoXFrnfDpu=urllib.parse.unquote(args.get('bm_param'))
  tLbVBvOzwGdRHePigThIyoXFrnfDpu=json.loads(tLbVBvOzwGdRHePigThIyoXFrnfDpu)
  tLbVBvOzwGdRHePigThIyoXFrnfDJm =tLbVBvOzwGdRHePigThIyoXFrnfDpu.get('videoid')
  tLbVBvOzwGdRHePigThIyoXFrnfDUs =tLbVBvOzwGdRHePigThIyoXFrnfDpu.get('vidtype')
  tLbVBvOzwGdRHePigThIyoXFrnfDpx =tLbVBvOzwGdRHePigThIyoXFrnfDpu.get('vtitle')
  tLbVBvOzwGdRHePigThIyoXFrnfDpk =tLbVBvOzwGdRHePigThIyoXFrnfDpu.get('vsubtitle')
  tLbVBvOzwGdRHePigThIyoXFrnfDpE=tLbVBvOzwGdRHePigThIyoXFrnfDpu.get('contenttype')
  tLbVBvOzwGdRHePigThIyoXFrnfDsx=xbmcgui.Dialog()
  tLbVBvOzwGdRHePigThIyoXFrnfDcs=tLbVBvOzwGdRHePigThIyoXFrnfDsx.yesno(__language__(30913).encode('utf8'),tLbVBvOzwGdRHePigThIyoXFrnfDpx+' \n\n'+__language__(30914))
  if tLbVBvOzwGdRHePigThIyoXFrnfDcs==tLbVBvOzwGdRHePigThIyoXFrnfDKk:return
  tLbVBvOzwGdRHePigThIyoXFrnfDpQ=tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.GetBookmarkInfo(tLbVBvOzwGdRHePigThIyoXFrnfDJm,tLbVBvOzwGdRHePigThIyoXFrnfDUs,tLbVBvOzwGdRHePigThIyoXFrnfDpE)
  tLbVBvOzwGdRHePigThIyoXFrnfDpY=json.dumps(tLbVBvOzwGdRHePigThIyoXFrnfDpQ)
  tLbVBvOzwGdRHePigThIyoXFrnfDpY=urllib.parse.quote(tLbVBvOzwGdRHePigThIyoXFrnfDpY)
  tLbVBvOzwGdRHePigThIyoXFrnfDUp ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(tLbVBvOzwGdRHePigThIyoXFrnfDpY)
  xbmc.executebuiltin(tLbVBvOzwGdRHePigThIyoXFrnfDUp)
 def dp_LiveChannel_List(tLbVBvOzwGdRHePigThIyoXFrnfDsq,args):
  tLbVBvOzwGdRHePigThIyoXFrnfDpM =args.get('genre')
  tLbVBvOzwGdRHePigThIyoXFrnfDSM=args.get('baseapi')
  tLbVBvOzwGdRHePigThIyoXFrnfDJl=tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.Get_LiveChannel_List(tLbVBvOzwGdRHePigThIyoXFrnfDpM,tLbVBvOzwGdRHePigThIyoXFrnfDSM)
  for tLbVBvOzwGdRHePigThIyoXFrnfDJj in tLbVBvOzwGdRHePigThIyoXFrnfDJl:
   tLbVBvOzwGdRHePigThIyoXFrnfDpa =tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('channelid')
   tLbVBvOzwGdRHePigThIyoXFrnfDpC =tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('studio')
   tLbVBvOzwGdRHePigThIyoXFrnfDpW=tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('tvshowtitle')
   tLbVBvOzwGdRHePigThIyoXFrnfDUA =tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('thumbnail')
   tLbVBvOzwGdRHePigThIyoXFrnfDUJ =tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('age')
   tLbVBvOzwGdRHePigThIyoXFrnfDpN =tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('epg')
   tLbVBvOzwGdRHePigThIyoXFrnfDJM={'mediatype':'episode','mpaa':tLbVBvOzwGdRHePigThIyoXFrnfDUJ,'title':'%s < %s >'%(tLbVBvOzwGdRHePigThIyoXFrnfDpC,tLbVBvOzwGdRHePigThIyoXFrnfDpW),'tvshowtitle':tLbVBvOzwGdRHePigThIyoXFrnfDpW,'studio':tLbVBvOzwGdRHePigThIyoXFrnfDpC,'plot':'%s\n\n%s'%(tLbVBvOzwGdRHePigThIyoXFrnfDpC,tLbVBvOzwGdRHePigThIyoXFrnfDpN)}
   tLbVBvOzwGdRHePigThIyoXFrnfDAM={'mode':'LIVE','contentid':tLbVBvOzwGdRHePigThIyoXFrnfDpa}
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.add_dir(tLbVBvOzwGdRHePigThIyoXFrnfDpC,sublabel=tLbVBvOzwGdRHePigThIyoXFrnfDpW,img=tLbVBvOzwGdRHePigThIyoXFrnfDUA,infoLabels=tLbVBvOzwGdRHePigThIyoXFrnfDJM,isFolder=tLbVBvOzwGdRHePigThIyoXFrnfDKk,params=tLbVBvOzwGdRHePigThIyoXFrnfDAM)
  if tLbVBvOzwGdRHePigThIyoXFrnfDKN(tLbVBvOzwGdRHePigThIyoXFrnfDJl)>0:xbmcplugin.endOfDirectory(tLbVBvOzwGdRHePigThIyoXFrnfDsq._addon_handle,cacheToDisc=tLbVBvOzwGdRHePigThIyoXFrnfDKk)
 def dp_Sports_GameList(tLbVBvOzwGdRHePigThIyoXFrnfDsq,args):
  tLbVBvOzwGdRHePigThIyoXFrnfDJl=tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.Get_Sports_Gamelist()
  for tLbVBvOzwGdRHePigThIyoXFrnfDJj in tLbVBvOzwGdRHePigThIyoXFrnfDJl:
   tLbVBvOzwGdRHePigThIyoXFrnfDpl =tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('game_date')
   tLbVBvOzwGdRHePigThIyoXFrnfDpj =tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('game_time')
   tLbVBvOzwGdRHePigThIyoXFrnfDpm =tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('svc_id')
   tLbVBvOzwGdRHePigThIyoXFrnfDKs =tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('away_team')
   tLbVBvOzwGdRHePigThIyoXFrnfDKA =tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('home_team')
   tLbVBvOzwGdRHePigThIyoXFrnfDKJ=tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('game_status')
   tLbVBvOzwGdRHePigThIyoXFrnfDKU =tLbVBvOzwGdRHePigThIyoXFrnfDJj.get('game_place')
   tLbVBvOzwGdRHePigThIyoXFrnfDKc ='%s vs %s (%s)'%(tLbVBvOzwGdRHePigThIyoXFrnfDKs,tLbVBvOzwGdRHePigThIyoXFrnfDKA,tLbVBvOzwGdRHePigThIyoXFrnfDKU)
   tLbVBvOzwGdRHePigThIyoXFrnfDKS =tLbVBvOzwGdRHePigThIyoXFrnfDpl+' '+tLbVBvOzwGdRHePigThIyoXFrnfDpj
   if tLbVBvOzwGdRHePigThIyoXFrnfDKJ=='LIVE':
    tLbVBvOzwGdRHePigThIyoXFrnfDKJ='~경기중~'
   elif tLbVBvOzwGdRHePigThIyoXFrnfDKJ=='END':
    tLbVBvOzwGdRHePigThIyoXFrnfDKJ='경기종료'
   elif tLbVBvOzwGdRHePigThIyoXFrnfDKJ=='CANCEL':
    tLbVBvOzwGdRHePigThIyoXFrnfDKJ='취소'
   else:
    tLbVBvOzwGdRHePigThIyoXFrnfDKJ=''
   if tLbVBvOzwGdRHePigThIyoXFrnfDKJ=='':
    tLbVBvOzwGdRHePigThIyoXFrnfDUq=tLbVBvOzwGdRHePigThIyoXFrnfDKc
   else:
    tLbVBvOzwGdRHePigThIyoXFrnfDUq=tLbVBvOzwGdRHePigThIyoXFrnfDKc+'  '+tLbVBvOzwGdRHePigThIyoXFrnfDKJ
   tLbVBvOzwGdRHePigThIyoXFrnfDJM={'mediatype':'episode','title':tLbVBvOzwGdRHePigThIyoXFrnfDKc,'plot':'%s\n\n%s\n\n%s'%(tLbVBvOzwGdRHePigThIyoXFrnfDKS,tLbVBvOzwGdRHePigThIyoXFrnfDKc,tLbVBvOzwGdRHePigThIyoXFrnfDKJ)}
   tLbVBvOzwGdRHePigThIyoXFrnfDAM={'mode':'SPORTS','contentid':tLbVBvOzwGdRHePigThIyoXFrnfDpm}
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.add_dir(tLbVBvOzwGdRHePigThIyoXFrnfDKS,sublabel=tLbVBvOzwGdRHePigThIyoXFrnfDUq,img='',infoLabels=tLbVBvOzwGdRHePigThIyoXFrnfDJM,isFolder=tLbVBvOzwGdRHePigThIyoXFrnfDKk,params=tLbVBvOzwGdRHePigThIyoXFrnfDAM)
  xbmcplugin.endOfDirectory(tLbVBvOzwGdRHePigThIyoXFrnfDsq._addon_handle,cacheToDisc=tLbVBvOzwGdRHePigThIyoXFrnfDKk)
 def dp_View_Detail(tLbVBvOzwGdRHePigThIyoXFrnfDsq,tLbVBvOzwGdRHePigThIyoXFrnfDKa):
  tLbVBvOzwGdRHePigThIyoXFrnfDJm =tLbVBvOzwGdRHePigThIyoXFrnfDKa.get('videoid')
  tLbVBvOzwGdRHePigThIyoXFrnfDUs =tLbVBvOzwGdRHePigThIyoXFrnfDKa.get('vidtype') 
  tLbVBvOzwGdRHePigThIyoXFrnfDpE=tLbVBvOzwGdRHePigThIyoXFrnfDKa.get('contenttype')
  tLbVBvOzwGdRHePigThIyoXFrnfDsq.addon_log(tLbVBvOzwGdRHePigThIyoXFrnfDJm)
  tLbVBvOzwGdRHePigThIyoXFrnfDsq.addon_log(tLbVBvOzwGdRHePigThIyoXFrnfDUs)
  tLbVBvOzwGdRHePigThIyoXFrnfDsq.addon_log(tLbVBvOzwGdRHePigThIyoXFrnfDpE)
  tLbVBvOzwGdRHePigThIyoXFrnfDpQ=tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.GetBookmarkInfo(tLbVBvOzwGdRHePigThIyoXFrnfDJm,tLbVBvOzwGdRHePigThIyoXFrnfDUs,tLbVBvOzwGdRHePigThIyoXFrnfDpE)
  if tLbVBvOzwGdRHePigThIyoXFrnfDUs=='tvshow':
   tLbVBvOzwGdRHePigThIyoXFrnfDAM={'mode':'SEASON_LIST','videoid':tLbVBvOzwGdRHePigThIyoXFrnfDpQ['indexinfo']['videoid'],'vidtype':tLbVBvOzwGdRHePigThIyoXFrnfDpQ['indexinfo']['vidtype'],}
   tLbVBvOzwGdRHePigThIyoXFrnfDcS='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(tLbVBvOzwGdRHePigThIyoXFrnfDAM))
  else:
   tLbVBvOzwGdRHePigThIyoXFrnfDAM={'mode':'MOVIE','contentid':tLbVBvOzwGdRHePigThIyoXFrnfDpQ['indexinfo']['videoid'],'title':tLbVBvOzwGdRHePigThIyoXFrnfDpQ['saveinfo']['infoLabels']['title'],'thumbnail':tLbVBvOzwGdRHePigThIyoXFrnfDpQ['saveinfo']['thumbnail'],'age':tLbVBvOzwGdRHePigThIyoXFrnfDpQ['saveinfo']['infoLabels']['mpaa'],}
   tLbVBvOzwGdRHePigThIyoXFrnfDcS='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(tLbVBvOzwGdRHePigThIyoXFrnfDAM))
  tLbVBvOzwGdRHePigThIyoXFrnfDAx=xbmcgui.ListItem(label=tLbVBvOzwGdRHePigThIyoXFrnfDpQ['saveinfo']['title'],path=tLbVBvOzwGdRHePigThIyoXFrnfDcS)
  tLbVBvOzwGdRHePigThIyoXFrnfDAx.setArt(tLbVBvOzwGdRHePigThIyoXFrnfDpQ['saveinfo']['thumbnail'])
  tLbVBvOzwGdRHePigThIyoXFrnfDsq.Set_InfoTag(tLbVBvOzwGdRHePigThIyoXFrnfDAx.getVideoInfoTag(),tLbVBvOzwGdRHePigThIyoXFrnfDpQ['saveinfo']['infoLabels'])
  if tLbVBvOzwGdRHePigThIyoXFrnfDUs=='movie':
   tLbVBvOzwGdRHePigThIyoXFrnfDAx.setIsFolder(tLbVBvOzwGdRHePigThIyoXFrnfDKk)
   tLbVBvOzwGdRHePigThIyoXFrnfDAx.setProperty('IsPlayable','true')
  else:
   tLbVBvOzwGdRHePigThIyoXFrnfDAx.setIsFolder(tLbVBvOzwGdRHePigThIyoXFrnfDKx)
   tLbVBvOzwGdRHePigThIyoXFrnfDAx.setProperty('IsPlayable','false')
  tLbVBvOzwGdRHePigThIyoXFrnfDsx=xbmcgui.Dialog()
  tLbVBvOzwGdRHePigThIyoXFrnfDsx.info(tLbVBvOzwGdRHePigThIyoXFrnfDAx)
 def wavve_main(tLbVBvOzwGdRHePigThIyoXFrnfDsq):
  tLbVBvOzwGdRHePigThIyoXFrnfDsq.WavveObj.KodiVersion=tLbVBvOzwGdRHePigThIyoXFrnfDKu(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  tLbVBvOzwGdRHePigThIyoXFrnfDKp=tLbVBvOzwGdRHePigThIyoXFrnfDsq.main_params.get('params')
  if tLbVBvOzwGdRHePigThIyoXFrnfDKp:
   tLbVBvOzwGdRHePigThIyoXFrnfDKq =base64.standard_b64decode(tLbVBvOzwGdRHePigThIyoXFrnfDKp).decode('utf-8')
   tLbVBvOzwGdRHePigThIyoXFrnfDKq =json.loads(tLbVBvOzwGdRHePigThIyoXFrnfDKq)
   tLbVBvOzwGdRHePigThIyoXFrnfDJc =tLbVBvOzwGdRHePigThIyoXFrnfDKq.get('mode')
   tLbVBvOzwGdRHePigThIyoXFrnfDKa =tLbVBvOzwGdRHePigThIyoXFrnfDKq.get('values')
  else:
   tLbVBvOzwGdRHePigThIyoXFrnfDJc=tLbVBvOzwGdRHePigThIyoXFrnfDsq.main_params.get('mode',tLbVBvOzwGdRHePigThIyoXFrnfDKW)
   tLbVBvOzwGdRHePigThIyoXFrnfDKa=tLbVBvOzwGdRHePigThIyoXFrnfDsq.main_params
  if tLbVBvOzwGdRHePigThIyoXFrnfDJc=='LOGOUT':
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.logout()
   return
  tLbVBvOzwGdRHePigThIyoXFrnfDsq.login_main()
  if tLbVBvOzwGdRHePigThIyoXFrnfDJc is tLbVBvOzwGdRHePigThIyoXFrnfDKW:
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.dp_Main_List()
  elif tLbVBvOzwGdRHePigThIyoXFrnfDJc in['LIVE','VOD','MOVIE','SPORTS']:
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.play_VIDEO(tLbVBvOzwGdRHePigThIyoXFrnfDKa)
  elif tLbVBvOzwGdRHePigThIyoXFrnfDJc=='LIVE_CATAGORY':
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.dp_LiveCatagory_List(tLbVBvOzwGdRHePigThIyoXFrnfDKa)
  elif tLbVBvOzwGdRHePigThIyoXFrnfDJc=='MAIN_CATAGORY':
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.dp_MainCatagory_List(tLbVBvOzwGdRHePigThIyoXFrnfDKa)
  elif tLbVBvOzwGdRHePigThIyoXFrnfDJc=='SUPERSECTION_LIST':
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.dp_SuperSection_List(tLbVBvOzwGdRHePigThIyoXFrnfDKa)
  elif tLbVBvOzwGdRHePigThIyoXFrnfDJc=='BANDLIVESECTION_LIST':
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.dp_BandLiveSection_List(tLbVBvOzwGdRHePigThIyoXFrnfDKa)
  elif tLbVBvOzwGdRHePigThIyoXFrnfDJc=='BAND2SECTION_LIST':
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.dp_Band2Section_List(tLbVBvOzwGdRHePigThIyoXFrnfDKa)
  elif tLbVBvOzwGdRHePigThIyoXFrnfDJc=='PROGRAM_LIST':
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.dp_Program_List(tLbVBvOzwGdRHePigThIyoXFrnfDKa)
  elif tLbVBvOzwGdRHePigThIyoXFrnfDJc=='SEASON_LIST':
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.dp_Season_List(tLbVBvOzwGdRHePigThIyoXFrnfDKa)
  elif tLbVBvOzwGdRHePigThIyoXFrnfDJc=='EPISODE_LIST':
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.dp_Episode_List(tLbVBvOzwGdRHePigThIyoXFrnfDKa)
  elif tLbVBvOzwGdRHePigThIyoXFrnfDJc=='MOVIE_LIST':
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.dp_Movie_List(tLbVBvOzwGdRHePigThIyoXFrnfDKa)
  elif tLbVBvOzwGdRHePigThIyoXFrnfDJc=='LIVE_LIST':
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.dp_LiveChannel_List(tLbVBvOzwGdRHePigThIyoXFrnfDKa)
  elif tLbVBvOzwGdRHePigThIyoXFrnfDJc=='ORDER_BY':
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.dp_setEpOrderby(tLbVBvOzwGdRHePigThIyoXFrnfDKa)
  elif tLbVBvOzwGdRHePigThIyoXFrnfDJc=='SEARCH_GROUP':
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.dp_Search_Group(tLbVBvOzwGdRHePigThIyoXFrnfDKa)
  elif tLbVBvOzwGdRHePigThIyoXFrnfDJc in['SEARCH_LIST','LOCAL_SEARCH']:
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.dp_Search_List(tLbVBvOzwGdRHePigThIyoXFrnfDKa)
  elif tLbVBvOzwGdRHePigThIyoXFrnfDJc=='WATCH_GROUP':
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.dp_Watch_Group(tLbVBvOzwGdRHePigThIyoXFrnfDKa)
  elif tLbVBvOzwGdRHePigThIyoXFrnfDJc=='WATCH_LIST':
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.dp_Watch_List(tLbVBvOzwGdRHePigThIyoXFrnfDKa)
  elif tLbVBvOzwGdRHePigThIyoXFrnfDJc=='SET_BOOKMARK':
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.dp_Set_Bookmark(tLbVBvOzwGdRHePigThIyoXFrnfDKa)
  elif tLbVBvOzwGdRHePigThIyoXFrnfDJc in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.dp_History_Remove(tLbVBvOzwGdRHePigThIyoXFrnfDKa)
  elif tLbVBvOzwGdRHePigThIyoXFrnfDJc in['TOTAL_SEARCH','TOTAL_HISTORY']:
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.dp_Global_Search(tLbVBvOzwGdRHePigThIyoXFrnfDKa)
  elif tLbVBvOzwGdRHePigThIyoXFrnfDJc=='SEARCH_HISTORY':
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.dp_Search_History(tLbVBvOzwGdRHePigThIyoXFrnfDKa)
  elif tLbVBvOzwGdRHePigThIyoXFrnfDJc=='MENU_BOOKMARK':
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.dp_Bookmark_Menu(tLbVBvOzwGdRHePigThIyoXFrnfDKa)
  elif tLbVBvOzwGdRHePigThIyoXFrnfDJc=='GAME_LIST':
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.dp_Sports_GameList(tLbVBvOzwGdRHePigThIyoXFrnfDKa)
  elif tLbVBvOzwGdRHePigThIyoXFrnfDJc=='VIEW_DETAIL':
   tLbVBvOzwGdRHePigThIyoXFrnfDsq.dp_View_Detail(tLbVBvOzwGdRHePigThIyoXFrnfDKa)
  else:
   tLbVBvOzwGdRHePigThIyoXFrnfDKW
# Created by pyminifier (https://github.com/liftoff/pyminifier)
