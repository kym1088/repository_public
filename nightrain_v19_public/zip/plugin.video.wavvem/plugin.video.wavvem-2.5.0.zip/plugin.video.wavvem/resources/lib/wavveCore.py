__author__="NightRain"
BhpIelOqUgfKCzdWsETVJGMyrajbmQ=None
BhpIelOqUgfKCzdWsETVJGMyrajbmY=object
BhpIelOqUgfKCzdWsETVJGMyrajbki=print
BhpIelOqUgfKCzdWsETVJGMyrajbkX=str
BhpIelOqUgfKCzdWsETVJGMyrajbkx=False
BhpIelOqUgfKCzdWsETVJGMyrajbkt=open
BhpIelOqUgfKCzdWsETVJGMyrajbkc=True
BhpIelOqUgfKCzdWsETVJGMyrajbkR=range
BhpIelOqUgfKCzdWsETVJGMyrajbkm=len
BhpIelOqUgfKCzdWsETVJGMyrajbkL=Exception
BhpIelOqUgfKCzdWsETVJGMyrajbkH=dict
BhpIelOqUgfKCzdWsETVJGMyrajbkn=int
import urllib
import re
import json
import sys
import requests
import datetime
import base64
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
import httpx
try:
 import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
 __addon__=xbmcaddon.Addon()
 __language__ =__addon__.getLocalizedString
 __profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
 __version__=__addon__.getAddonInfo('version')
 __addonid__=__addon__.getAddonInfo('id')
 __addonname__=__addon__.getAddonInfo('name')
except:
 BhpIelOqUgfKCzdWsETVJGMyrajbmQ
def addon_log(string):
 try:
  BhpIelOqUgfKCzdWsETVJGMyrajbix=string.encode('utf-8','ignore')
  BhpIelOqUgfKCzdWsETVJGMyrajbit=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,BhpIelOqUgfKCzdWsETVJGMyrajbix),level=BhpIelOqUgfKCzdWsETVJGMyrajbit)
 except:
  BhpIelOqUgfKCzdWsETVJGMyrajbix='addonException: addon_log'
BhpIelOqUgfKCzdWsETVJGMyrajbic =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
class BhpIelOqUgfKCzdWsETVJGMyrajbiX(BhpIelOqUgfKCzdWsETVJGMyrajbmY):
 def __init__(BhpIelOqUgfKCzdWsETVJGMyrajbiR):
  BhpIelOqUgfKCzdWsETVJGMyrajbiR.API_DOMAIN='https://apis.wavve.com'
  BhpIelOqUgfKCzdWsETVJGMyrajbiR.WV ={}
  BhpIelOqUgfKCzdWsETVJGMyrajbiR.Init_WV_Total()
  BhpIelOqUgfKCzdWsETVJGMyrajbiR.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  BhpIelOqUgfKCzdWsETVJGMyrajbiR.DEVICE ='pc'
  BhpIelOqUgfKCzdWsETVJGMyrajbiR.DRM ='wm'
  BhpIelOqUgfKCzdWsETVJGMyrajbiR.PARTNER ='pooq'
  BhpIelOqUgfKCzdWsETVJGMyrajbiR.POOQZONE ='none'
  BhpIelOqUgfKCzdWsETVJGMyrajbiR.REGION ='kor'
  BhpIelOqUgfKCzdWsETVJGMyrajbiR.TARGETAGE ='all'
  BhpIelOqUgfKCzdWsETVJGMyrajbiR.HTTPTAG ='https://'
  BhpIelOqUgfKCzdWsETVJGMyrajbiR.LIST_LIMIT=40 
  BhpIelOqUgfKCzdWsETVJGMyrajbiR.EP_LIMIT =30 
  BhpIelOqUgfKCzdWsETVJGMyrajbiR.MV_LIMIT =24 
  BhpIelOqUgfKCzdWsETVJGMyrajbiR.SEARCH_LIMIT=20 
  BhpIelOqUgfKCzdWsETVJGMyrajbiR.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36'
  BhpIelOqUgfKCzdWsETVJGMyrajbiR.DEFAULT_HEADER={'user-agent':BhpIelOqUgfKCzdWsETVJGMyrajbiR.USER_AGENT}
  BhpIelOqUgfKCzdWsETVJGMyrajbiR.KodiVersion=20
  BhpIelOqUgfKCzdWsETVJGMyrajbiR.WV_SESSION_COOKIES1=''
  BhpIelOqUgfKCzdWsETVJGMyrajbiR.WV_SESSION_COOKIES2=''
  BhpIelOqUgfKCzdWsETVJGMyrajbiR.COOKIE_FILE_NAME =''
  BhpIelOqUgfKCzdWsETVJGMyrajbiR.WV_STREAM_FILENAME =''
 def Init_WV_Total(BhpIelOqUgfKCzdWsETVJGMyrajbiR):
  BhpIelOqUgfKCzdWsETVJGMyrajbiR.WV={'account':{},'cookies':{},}
 def make_auth_header(BhpIelOqUgfKCzdWsETVJGMyrajbiR):
  return{'authorization':'Bearer {}'.format(BhpIelOqUgfKCzdWsETVJGMyrajbiR.WV['cookies']['credential']),'wavve-credential':BhpIelOqUgfKCzdWsETVJGMyrajbiR.WV['cookies']['credential'],}
 def callRequestCookies(BhpIelOqUgfKCzdWsETVJGMyrajbiR,jobtype,BhpIelOqUgfKCzdWsETVJGMyrajbXw,payload=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,params=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,headers=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,cookies=BhpIelOqUgfKCzdWsETVJGMyrajbmQ):
  BhpIelOqUgfKCzdWsETVJGMyrajbim=httpx.Client() 
  BhpIelOqUgfKCzdWsETVJGMyrajbik=BhpIelOqUgfKCzdWsETVJGMyrajbiR.DEFAULT_HEADER
  if headers:BhpIelOqUgfKCzdWsETVJGMyrajbik.update(headers)
  if jobtype=='Get':
   BhpIelOqUgfKCzdWsETVJGMyrajbiL=BhpIelOqUgfKCzdWsETVJGMyrajbim.get(BhpIelOqUgfKCzdWsETVJGMyrajbXw,params=params,headers=BhpIelOqUgfKCzdWsETVJGMyrajbik,cookies=cookies)
  else:
   BhpIelOqUgfKCzdWsETVJGMyrajbiL=BhpIelOqUgfKCzdWsETVJGMyrajbim.post(BhpIelOqUgfKCzdWsETVJGMyrajbXw,json=payload,params=params,headers=BhpIelOqUgfKCzdWsETVJGMyrajbik,cookies=cookies)
  BhpIelOqUgfKCzdWsETVJGMyrajbki(BhpIelOqUgfKCzdWsETVJGMyrajbkX(BhpIelOqUgfKCzdWsETVJGMyrajbiL.status_code)+' - '+BhpIelOqUgfKCzdWsETVJGMyrajbkX(BhpIelOqUgfKCzdWsETVJGMyrajbiL.url))
  return BhpIelOqUgfKCzdWsETVJGMyrajbiL
 def JsonFile_Save(BhpIelOqUgfKCzdWsETVJGMyrajbiR,filename,BhpIelOqUgfKCzdWsETVJGMyrajbiH):
  if filename=='':return BhpIelOqUgfKCzdWsETVJGMyrajbkx
  try:
   fp=BhpIelOqUgfKCzdWsETVJGMyrajbkt(filename,'w',-1,'utf-8')
   json.dump(BhpIelOqUgfKCzdWsETVJGMyrajbiH,fp,indent=4,ensure_ascii=BhpIelOqUgfKCzdWsETVJGMyrajbkx)
   fp.close()
  except:
   return BhpIelOqUgfKCzdWsETVJGMyrajbkx
  return BhpIelOqUgfKCzdWsETVJGMyrajbkc
 def JsonFile_Load(BhpIelOqUgfKCzdWsETVJGMyrajbiR,filename):
  if filename=='':return{}
  try:
   fp=BhpIelOqUgfKCzdWsETVJGMyrajbkt(filename,'r',-1,'utf-8')
   BhpIelOqUgfKCzdWsETVJGMyrajbio=json.load(fp)
   fp.close()
  except:
   return{}
  return BhpIelOqUgfKCzdWsETVJGMyrajbio
 def TextFile_Save(BhpIelOqUgfKCzdWsETVJGMyrajbiR,filename,resText):
  if filename=='':return BhpIelOqUgfKCzdWsETVJGMyrajbkx
  try:
   fp=BhpIelOqUgfKCzdWsETVJGMyrajbkt(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return BhpIelOqUgfKCzdWsETVJGMyrajbkx
  return BhpIelOqUgfKCzdWsETVJGMyrajbkc
 def Save_session_acount(BhpIelOqUgfKCzdWsETVJGMyrajbiR,BhpIelOqUgfKCzdWsETVJGMyrajbiv,BhpIelOqUgfKCzdWsETVJGMyrajbiw,BhpIelOqUgfKCzdWsETVJGMyrajbiN):
  BhpIelOqUgfKCzdWsETVJGMyrajbiR.WV['account']['wvid']=base64.standard_b64encode(BhpIelOqUgfKCzdWsETVJGMyrajbiv.encode()).decode('utf-8')
  BhpIelOqUgfKCzdWsETVJGMyrajbiR.WV['account']['wvpw']=base64.standard_b64encode(BhpIelOqUgfKCzdWsETVJGMyrajbiw.encode()).decode('utf-8')
  BhpIelOqUgfKCzdWsETVJGMyrajbiR.WV['account']['wvpf']=BhpIelOqUgfKCzdWsETVJGMyrajbiN 
 def Load_session_acount(BhpIelOqUgfKCzdWsETVJGMyrajbiR):
  try:
   BhpIelOqUgfKCzdWsETVJGMyrajbiv=base64.standard_b64decode(BhpIelOqUgfKCzdWsETVJGMyrajbiR.WV['account']['wvid']).decode('utf-8')
   BhpIelOqUgfKCzdWsETVJGMyrajbiw=base64.standard_b64decode(BhpIelOqUgfKCzdWsETVJGMyrajbiR.WV['account']['wvpw']).decode('utf-8')
   BhpIelOqUgfKCzdWsETVJGMyrajbiN=BhpIelOqUgfKCzdWsETVJGMyrajbiR.WV['account']['wvpf']
  except:
   return '','',0
  return BhpIelOqUgfKCzdWsETVJGMyrajbiv,BhpIelOqUgfKCzdWsETVJGMyrajbiw,BhpIelOqUgfKCzdWsETVJGMyrajbiN
 def GetDefaultParams(BhpIelOqUgfKCzdWsETVJGMyrajbiR):
  BhpIelOqUgfKCzdWsETVJGMyrajbiu={'apikey':BhpIelOqUgfKCzdWsETVJGMyrajbiR.APIKEY,'device':BhpIelOqUgfKCzdWsETVJGMyrajbiR.DEVICE,'drm':BhpIelOqUgfKCzdWsETVJGMyrajbiR.DRM,'partner':BhpIelOqUgfKCzdWsETVJGMyrajbiR.PARTNER,'pooqzone':BhpIelOqUgfKCzdWsETVJGMyrajbiR.POOQZONE,'region':BhpIelOqUgfKCzdWsETVJGMyrajbiR.REGION,'targetage':BhpIelOqUgfKCzdWsETVJGMyrajbiR.TARGETAGE,'client_version':'7.1.40',}
  return BhpIelOqUgfKCzdWsETVJGMyrajbiu
 def GetDefaultParams_AND(BhpIelOqUgfKCzdWsETVJGMyrajbiR):
  BhpIelOqUgfKCzdWsETVJGMyrajbiu={'apikey':'6A87455D54481A536DFB8AD397C5EC4D','credential':BhpIelOqUgfKCzdWsETVJGMyrajbiR.WV['cookies']['credential'],'device':'ott','drm':BhpIelOqUgfKCzdWsETVJGMyrajbiR.DRM,'partner':BhpIelOqUgfKCzdWsETVJGMyrajbiR.PARTNER,'pooqzone':BhpIelOqUgfKCzdWsETVJGMyrajbiR.POOQZONE,'region':BhpIelOqUgfKCzdWsETVJGMyrajbiR.REGION,'targetage':BhpIelOqUgfKCzdWsETVJGMyrajbiR.TARGETAGE,}
  return BhpIelOqUgfKCzdWsETVJGMyrajbiu
 def GetGUID(BhpIelOqUgfKCzdWsETVJGMyrajbiR,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   BhpIelOqUgfKCzdWsETVJGMyrajbiP=BhpIelOqUgfKCzdWsETVJGMyrajbiR.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   BhpIelOqUgfKCzdWsETVJGMyrajbiF=GenerateRandomString(5)
   BhpIelOqUgfKCzdWsETVJGMyrajbiD=BhpIelOqUgfKCzdWsETVJGMyrajbiF+media+BhpIelOqUgfKCzdWsETVJGMyrajbiP
   return BhpIelOqUgfKCzdWsETVJGMyrajbiD
  def GenerateRandomString(num):
   from random import randint
   BhpIelOqUgfKCzdWsETVJGMyrajbiS=""
   for i in BhpIelOqUgfKCzdWsETVJGMyrajbkR(0,num):
    s=BhpIelOqUgfKCzdWsETVJGMyrajbkX(randint(1,5))
    BhpIelOqUgfKCzdWsETVJGMyrajbiS+=s
   return BhpIelOqUgfKCzdWsETVJGMyrajbiS
  if guidType==3:
   BhpIelOqUgfKCzdWsETVJGMyrajbiD=guid_str
  else:
   BhpIelOqUgfKCzdWsETVJGMyrajbiD=GenerateID(guid_str)
  BhpIelOqUgfKCzdWsETVJGMyrajbiA=BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetHash(BhpIelOqUgfKCzdWsETVJGMyrajbiD)
  if guidType in[2,3]:
   BhpIelOqUgfKCzdWsETVJGMyrajbiA='%s-%s-%s-%s-%s'%(BhpIelOqUgfKCzdWsETVJGMyrajbiA[:8],BhpIelOqUgfKCzdWsETVJGMyrajbiA[8:12],BhpIelOqUgfKCzdWsETVJGMyrajbiA[12:16],BhpIelOqUgfKCzdWsETVJGMyrajbiA[16:20],BhpIelOqUgfKCzdWsETVJGMyrajbiA[20:])
  return BhpIelOqUgfKCzdWsETVJGMyrajbiA
 def GetHash(BhpIelOqUgfKCzdWsETVJGMyrajbiR,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return BhpIelOqUgfKCzdWsETVJGMyrajbkX(m.hexdigest())
 def CheckQuality(BhpIelOqUgfKCzdWsETVJGMyrajbiR,sel_qt,qt_list):
  BhpIelOqUgfKCzdWsETVJGMyrajbiQ=0
  for BhpIelOqUgfKCzdWsETVJGMyrajbiY in qt_list:
   if sel_qt>=BhpIelOqUgfKCzdWsETVJGMyrajbiY:return BhpIelOqUgfKCzdWsETVJGMyrajbiY
   BhpIelOqUgfKCzdWsETVJGMyrajbiQ=BhpIelOqUgfKCzdWsETVJGMyrajbiY
  return BhpIelOqUgfKCzdWsETVJGMyrajbiQ
 def Get_Now_Datetime(BhpIelOqUgfKCzdWsETVJGMyrajbiR):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(BhpIelOqUgfKCzdWsETVJGMyrajbiR,in_text):
  BhpIelOqUgfKCzdWsETVJGMyrajbXx=in_text.replace('&lt;','<').replace('&gt;','>')
  BhpIelOqUgfKCzdWsETVJGMyrajbXx=BhpIelOqUgfKCzdWsETVJGMyrajbXx.replace('<br>','\n')
  BhpIelOqUgfKCzdWsETVJGMyrajbXx=BhpIelOqUgfKCzdWsETVJGMyrajbXx.replace('$O$','')
  BhpIelOqUgfKCzdWsETVJGMyrajbXx=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',BhpIelOqUgfKCzdWsETVJGMyrajbXx)
  BhpIelOqUgfKCzdWsETVJGMyrajbXx=BhpIelOqUgfKCzdWsETVJGMyrajbXx.lstrip('#')
  return BhpIelOqUgfKCzdWsETVJGMyrajbXx
 def make_str_ToCookie(BhpIelOqUgfKCzdWsETVJGMyrajbiR,cookieStr):
  BhpIelOqUgfKCzdWsETVJGMyrajbXt={}
  for BhpIelOqUgfKCzdWsETVJGMyrajbXc in cookieStr.split(';'):
   BhpIelOqUgfKCzdWsETVJGMyrajbXR=BhpIelOqUgfKCzdWsETVJGMyrajbXc.split('=')
   BhpIelOqUgfKCzdWsETVJGMyrajbXt[BhpIelOqUgfKCzdWsETVJGMyrajbXR[0]]=BhpIelOqUgfKCzdWsETVJGMyrajbXR[1]
  return BhpIelOqUgfKCzdWsETVJGMyrajbXt 
 def make_stream_header(BhpIelOqUgfKCzdWsETVJGMyrajbiR,BhpIelOqUgfKCzdWsETVJGMyrajbXn,BhpIelOqUgfKCzdWsETVJGMyrajbXt):
  BhpIelOqUgfKCzdWsETVJGMyrajbXm=''
  if BhpIelOqUgfKCzdWsETVJGMyrajbXt not in[{},BhpIelOqUgfKCzdWsETVJGMyrajbmQ,'']:
   BhpIelOqUgfKCzdWsETVJGMyrajbXk=BhpIelOqUgfKCzdWsETVJGMyrajbkm(BhpIelOqUgfKCzdWsETVJGMyrajbXt)
   for BhpIelOqUgfKCzdWsETVJGMyrajbXL,BhpIelOqUgfKCzdWsETVJGMyrajbXH in BhpIelOqUgfKCzdWsETVJGMyrajbXt.items():
    BhpIelOqUgfKCzdWsETVJGMyrajbXm+='{}={}'.format(BhpIelOqUgfKCzdWsETVJGMyrajbXL,BhpIelOqUgfKCzdWsETVJGMyrajbXH)
    BhpIelOqUgfKCzdWsETVJGMyrajbXk+=-1
    if BhpIelOqUgfKCzdWsETVJGMyrajbXk>0:BhpIelOqUgfKCzdWsETVJGMyrajbXm+='; '
   BhpIelOqUgfKCzdWsETVJGMyrajbXn['cookie']=BhpIelOqUgfKCzdWsETVJGMyrajbXm
  BhpIelOqUgfKCzdWsETVJGMyrajbXo=''
  i=0
  for BhpIelOqUgfKCzdWsETVJGMyrajbXL,BhpIelOqUgfKCzdWsETVJGMyrajbXH in BhpIelOqUgfKCzdWsETVJGMyrajbXn.items():
   i=i+1
   if i>1:BhpIelOqUgfKCzdWsETVJGMyrajbXo+='&'
   BhpIelOqUgfKCzdWsETVJGMyrajbXo+='{}={}'.format(BhpIelOqUgfKCzdWsETVJGMyrajbXL,urllib.parse.quote(BhpIelOqUgfKCzdWsETVJGMyrajbXH))
  return BhpIelOqUgfKCzdWsETVJGMyrajbXo
 def GetCredential(BhpIelOqUgfKCzdWsETVJGMyrajbiR,user_id,user_pw,user_pf):
  BhpIelOqUgfKCzdWsETVJGMyrajbXv=BhpIelOqUgfKCzdWsETVJGMyrajbkx
  try:
   BhpIelOqUgfKCzdWsETVJGMyrajbXw=BhpIelOqUgfKCzdWsETVJGMyrajbiR.API_DOMAIN+ '/login'
   BhpIelOqUgfKCzdWsETVJGMyrajbiu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetDefaultParams()
   BhpIelOqUgfKCzdWsETVJGMyrajbXn={'content-type':'application/json',}
   BhpIelOqUgfKCzdWsETVJGMyrajbXN={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   BhpIelOqUgfKCzdWsETVJGMyrajbXu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.callRequestCookies('Post',BhpIelOqUgfKCzdWsETVJGMyrajbXw,payload=BhpIelOqUgfKCzdWsETVJGMyrajbXN,params=BhpIelOqUgfKCzdWsETVJGMyrajbiu,headers=BhpIelOqUgfKCzdWsETVJGMyrajbXn,cookies=BhpIelOqUgfKCzdWsETVJGMyrajbmQ)
   addon_log('url : {}'.format(BhpIelOqUgfKCzdWsETVJGMyrajbXw))
   addon_log('res : {}'.format(BhpIelOqUgfKCzdWsETVJGMyrajbXu.text))
   BhpIelOqUgfKCzdWsETVJGMyrajbXP=json.loads(BhpIelOqUgfKCzdWsETVJGMyrajbXu.text)
   BhpIelOqUgfKCzdWsETVJGMyrajbiR.WV['cookies']['credential']=BhpIelOqUgfKCzdWsETVJGMyrajbXP['credential']
   if user_pf!=0:
    BhpIelOqUgfKCzdWsETVJGMyrajbXN={'id':BhpIelOqUgfKCzdWsETVJGMyrajbiR.WV['cookies']['credential'],'password':'','profile':BhpIelOqUgfKCzdWsETVJGMyrajbkX(user_pf),'pushid':'','type':'credential'}
    BhpIelOqUgfKCzdWsETVJGMyrajbiu =BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetDefaultParams() 
    BhpIelOqUgfKCzdWsETVJGMyrajbXu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.callRequestCookies('Post',BhpIelOqUgfKCzdWsETVJGMyrajbXw,payload=BhpIelOqUgfKCzdWsETVJGMyrajbXN,params=BhpIelOqUgfKCzdWsETVJGMyrajbiu,headers=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,cookies=BhpIelOqUgfKCzdWsETVJGMyrajbmQ)
    BhpIelOqUgfKCzdWsETVJGMyrajbXP=json.loads(BhpIelOqUgfKCzdWsETVJGMyrajbXu.text)
    BhpIelOqUgfKCzdWsETVJGMyrajbiR.WV['cookies']['credential']=BhpIelOqUgfKCzdWsETVJGMyrajbXP['credential']
   BhpIelOqUgfKCzdWsETVJGMyrajbXF=user_id+BhpIelOqUgfKCzdWsETVJGMyrajbkX(user_pf) 
   BhpIelOqUgfKCzdWsETVJGMyrajbiR.WV['cookies']['uuid']=BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetGUID(guid_str=BhpIelOqUgfKCzdWsETVJGMyrajbXF,guidType=3)
   BhpIelOqUgfKCzdWsETVJGMyrajbXv=BhpIelOqUgfKCzdWsETVJGMyrajbkc
  except BhpIelOqUgfKCzdWsETVJGMyrajbkL as exception:
   BhpIelOqUgfKCzdWsETVJGMyrajbki(exception)
   BhpIelOqUgfKCzdWsETVJGMyrajbiR.Init_WV_Total()
  return BhpIelOqUgfKCzdWsETVJGMyrajbXv
 def GetCredential_new(BhpIelOqUgfKCzdWsETVJGMyrajbiR,user_id,user_pw,user_pf):
  BhpIelOqUgfKCzdWsETVJGMyrajbXv=BhpIelOqUgfKCzdWsETVJGMyrajbkx
  try:
   BhpIelOqUgfKCzdWsETVJGMyrajbXw='https://account-api.wavve.com/v1/signin/wavve'
   BhpIelOqUgfKCzdWsETVJGMyrajbiu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetDefaultParams()
   BhpIelOqUgfKCzdWsETVJGMyrajbXn={'wavve-credential':'none','content-type':'application/json',}
   BhpIelOqUgfKCzdWsETVJGMyrajbXN={'id':user_id,'password':user_pw,'device':'pc','type':'wavve',}
   BhpIelOqUgfKCzdWsETVJGMyrajbXu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.callRequestCookies('Post',BhpIelOqUgfKCzdWsETVJGMyrajbXw,payload=BhpIelOqUgfKCzdWsETVJGMyrajbXN,params=BhpIelOqUgfKCzdWsETVJGMyrajbiu,headers=BhpIelOqUgfKCzdWsETVJGMyrajbXn,cookies=BhpIelOqUgfKCzdWsETVJGMyrajbmQ)
   addon_log('url : {}'.format(BhpIelOqUgfKCzdWsETVJGMyrajbXw))
   addon_log('res : {}'.format(BhpIelOqUgfKCzdWsETVJGMyrajbXu.text))
   BhpIelOqUgfKCzdWsETVJGMyrajbXP=json.loads(BhpIelOqUgfKCzdWsETVJGMyrajbXu.text)
   BhpIelOqUgfKCzdWsETVJGMyrajbiR.WV['cookies']['credential']=BhpIelOqUgfKCzdWsETVJGMyrajbXP['credential']
   BhpIelOqUgfKCzdWsETVJGMyrajbXw='https://account-api.wavve.com/v1/signin'
   BhpIelOqUgfKCzdWsETVJGMyrajbXn={'wavve-credential':BhpIelOqUgfKCzdWsETVJGMyrajbiR.WV['cookies']['credential'],'content-type':'application/json',}
   BhpIelOqUgfKCzdWsETVJGMyrajbXN={'id':BhpIelOqUgfKCzdWsETVJGMyrajbiR.WV['cookies']['credential'],'profile':BhpIelOqUgfKCzdWsETVJGMyrajbkX(user_pf),'device':'pc','type':'credential',}
   BhpIelOqUgfKCzdWsETVJGMyrajbXu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.callRequestCookies('Post',BhpIelOqUgfKCzdWsETVJGMyrajbXw,payload=BhpIelOqUgfKCzdWsETVJGMyrajbXN,params=BhpIelOqUgfKCzdWsETVJGMyrajbiu,headers=BhpIelOqUgfKCzdWsETVJGMyrajbXn,cookies=BhpIelOqUgfKCzdWsETVJGMyrajbmQ)
   BhpIelOqUgfKCzdWsETVJGMyrajbXP=json.loads(BhpIelOqUgfKCzdWsETVJGMyrajbXu.text)
   BhpIelOqUgfKCzdWsETVJGMyrajbiR.WV['cookies']['credential']=BhpIelOqUgfKCzdWsETVJGMyrajbXP['credential']
   BhpIelOqUgfKCzdWsETVJGMyrajbiR.WV['cookies']['uuid'] =BhpIelOqUgfKCzdWsETVJGMyrajbXP['device_id']
   BhpIelOqUgfKCzdWsETVJGMyrajbXv=BhpIelOqUgfKCzdWsETVJGMyrajbkc
  except BhpIelOqUgfKCzdWsETVJGMyrajbkL as exception:
   BhpIelOqUgfKCzdWsETVJGMyrajbki(exception)
   BhpIelOqUgfKCzdWsETVJGMyrajbiR.Init_WV_Total()
  return BhpIelOqUgfKCzdWsETVJGMyrajbXv
 def GetIssue(BhpIelOqUgfKCzdWsETVJGMyrajbiR):
  BhpIelOqUgfKCzdWsETVJGMyrajbXD=BhpIelOqUgfKCzdWsETVJGMyrajbkx
  try:
   BhpIelOqUgfKCzdWsETVJGMyrajbXw=BhpIelOqUgfKCzdWsETVJGMyrajbiR.API_DOMAIN+'/guid/issue'
   BhpIelOqUgfKCzdWsETVJGMyrajbiu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetDefaultParams()
   BhpIelOqUgfKCzdWsETVJGMyrajbXu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.callRequestCookies('Get',BhpIelOqUgfKCzdWsETVJGMyrajbXw,payload=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,params=BhpIelOqUgfKCzdWsETVJGMyrajbiu,headers=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,cookies=BhpIelOqUgfKCzdWsETVJGMyrajbmQ)
   BhpIelOqUgfKCzdWsETVJGMyrajbXP=json.loads(BhpIelOqUgfKCzdWsETVJGMyrajbXu.text)
   BhpIelOqUgfKCzdWsETVJGMyrajbXS=BhpIelOqUgfKCzdWsETVJGMyrajbXP['guid']
   BhpIelOqUgfKCzdWsETVJGMyrajbXA=BhpIelOqUgfKCzdWsETVJGMyrajbXP['guidtimestamp']
   if BhpIelOqUgfKCzdWsETVJGMyrajbXS:BhpIelOqUgfKCzdWsETVJGMyrajbXD=BhpIelOqUgfKCzdWsETVJGMyrajbkc
  except BhpIelOqUgfKCzdWsETVJGMyrajbkL as exception:
   BhpIelOqUgfKCzdWsETVJGMyrajbki(exception)
   BhpIelOqUgfKCzdWsETVJGMyrajbXS='none'
   BhpIelOqUgfKCzdWsETVJGMyrajbXA='none' 
  BhpIelOqUgfKCzdWsETVJGMyrajbiR.guid=BhpIelOqUgfKCzdWsETVJGMyrajbXS
  BhpIelOqUgfKCzdWsETVJGMyrajbiR.guidtimestamp=BhpIelOqUgfKCzdWsETVJGMyrajbXA
  return BhpIelOqUgfKCzdWsETVJGMyrajbXD
 def Baseapi_Parse(BhpIelOqUgfKCzdWsETVJGMyrajbiR,BhpIelOqUgfKCzdWsETVJGMyrajbxX):
  try:
   BhpIelOqUgfKCzdWsETVJGMyrajbXQ =urllib.parse.urlsplit(BhpIelOqUgfKCzdWsETVJGMyrajbxX)
   if BhpIelOqUgfKCzdWsETVJGMyrajbXQ.netloc=='':
    BhpIelOqUgfKCzdWsETVJGMyrajbXw=BhpIelOqUgfKCzdWsETVJGMyrajbiR.HTTPTAG+BhpIelOqUgfKCzdWsETVJGMyrajbXQ.netloc+BhpIelOqUgfKCzdWsETVJGMyrajbXQ.path
   else:
    BhpIelOqUgfKCzdWsETVJGMyrajbXw=BhpIelOqUgfKCzdWsETVJGMyrajbXQ.scheme+'://'+BhpIelOqUgfKCzdWsETVJGMyrajbXQ.netloc+BhpIelOqUgfKCzdWsETVJGMyrajbXQ.path
   BhpIelOqUgfKCzdWsETVJGMyrajbiu=BhpIelOqUgfKCzdWsETVJGMyrajbkH(urllib.parse.parse_qsl(BhpIelOqUgfKCzdWsETVJGMyrajbXQ.query))
  except BhpIelOqUgfKCzdWsETVJGMyrajbkL as exception:
   BhpIelOqUgfKCzdWsETVJGMyrajbki(exception)
   return '',{}
  return BhpIelOqUgfKCzdWsETVJGMyrajbXw,BhpIelOqUgfKCzdWsETVJGMyrajbiu
 def GetSupermultiUrl(BhpIelOqUgfKCzdWsETVJGMyrajbiR,sCode,sIndex='0'):
  try:
   BhpIelOqUgfKCzdWsETVJGMyrajbXw=BhpIelOqUgfKCzdWsETVJGMyrajbiR.API_DOMAIN+'/cf/supermultisections/'+sCode
   BhpIelOqUgfKCzdWsETVJGMyrajbiu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetDefaultParams()
   BhpIelOqUgfKCzdWsETVJGMyrajbXu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.callRequestCookies('Get',BhpIelOqUgfKCzdWsETVJGMyrajbXw,payload=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,params=BhpIelOqUgfKCzdWsETVJGMyrajbiu,headers=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,cookies=BhpIelOqUgfKCzdWsETVJGMyrajbmQ)
   BhpIelOqUgfKCzdWsETVJGMyrajbXP=json.loads(BhpIelOqUgfKCzdWsETVJGMyrajbXu.text)
   BhpIelOqUgfKCzdWsETVJGMyrajbXY=BhpIelOqUgfKCzdWsETVJGMyrajbXP['multisectionlist'][BhpIelOqUgfKCzdWsETVJGMyrajbkn(sIndex)]['eventlist'][1]['url']
  except BhpIelOqUgfKCzdWsETVJGMyrajbkL as exception:
   BhpIelOqUgfKCzdWsETVJGMyrajbki(exception)
   return ''
  return BhpIelOqUgfKCzdWsETVJGMyrajbXY
 def Get_LiveCatagory_List(BhpIelOqUgfKCzdWsETVJGMyrajbiR,sCode,sIndex='0'):
  BhpIelOqUgfKCzdWsETVJGMyrajbxi=[]
  BhpIelOqUgfKCzdWsETVJGMyrajbxX =BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetSupermultiUrl(sCode,sIndex)
  (BhpIelOqUgfKCzdWsETVJGMyrajbXw,BhpIelOqUgfKCzdWsETVJGMyrajbiu)=BhpIelOqUgfKCzdWsETVJGMyrajbiR.Baseapi_Parse(BhpIelOqUgfKCzdWsETVJGMyrajbxX)
  if BhpIelOqUgfKCzdWsETVJGMyrajbXw=='':return BhpIelOqUgfKCzdWsETVJGMyrajbxi,''
  addon_log('Get_LiveCatagory_List url : {}'.format(BhpIelOqUgfKCzdWsETVJGMyrajbXw))
  try:
   BhpIelOqUgfKCzdWsETVJGMyrajbiu.update(BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetDefaultParams())
   BhpIelOqUgfKCzdWsETVJGMyrajbXu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.callRequestCookies('Get',BhpIelOqUgfKCzdWsETVJGMyrajbXw,payload=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,params=BhpIelOqUgfKCzdWsETVJGMyrajbiu,headers=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,cookies=BhpIelOqUgfKCzdWsETVJGMyrajbmQ)
   BhpIelOqUgfKCzdWsETVJGMyrajbXP=json.loads(BhpIelOqUgfKCzdWsETVJGMyrajbXu.text)
   if not('filter_item_list' in BhpIelOqUgfKCzdWsETVJGMyrajbXP['filter']['filterlist'][0]):return[],''
   BhpIelOqUgfKCzdWsETVJGMyrajbxt=BhpIelOqUgfKCzdWsETVJGMyrajbXP['filter']['filterlist'][0]['filter_item_list']
   for BhpIelOqUgfKCzdWsETVJGMyrajbxc in BhpIelOqUgfKCzdWsETVJGMyrajbxt:
    BhpIelOqUgfKCzdWsETVJGMyrajbxR={'title':BhpIelOqUgfKCzdWsETVJGMyrajbxc['title'],'genre':BhpIelOqUgfKCzdWsETVJGMyrajbxc['api_parameters'][BhpIelOqUgfKCzdWsETVJGMyrajbxc['api_parameters'].index('=')+1:]}
    BhpIelOqUgfKCzdWsETVJGMyrajbxi.append(BhpIelOqUgfKCzdWsETVJGMyrajbxR)
  except BhpIelOqUgfKCzdWsETVJGMyrajbkL as exception:
   BhpIelOqUgfKCzdWsETVJGMyrajbki(exception)
   return[],''
  return BhpIelOqUgfKCzdWsETVJGMyrajbxi,BhpIelOqUgfKCzdWsETVJGMyrajbxX
 def Get_MainCatagory_List(BhpIelOqUgfKCzdWsETVJGMyrajbiR,sCode,sIndex,sType):
  BhpIelOqUgfKCzdWsETVJGMyrajbxi=[]
  BhpIelOqUgfKCzdWsETVJGMyrajbXw='https://apis.wavve.com/es/category/launcher-band'
  BhpIelOqUgfKCzdWsETVJGMyrajbiu={'uitype':sCode,'uiparent':'GN52-'+sCode,'uirank':sIndex,'broadcastid':sCode,'offset':'0','limit':'20','uicode':sCode,'mtype':'N','ctype':sType,'orderby':'default',}
  try:
   BhpIelOqUgfKCzdWsETVJGMyrajbiu.update(BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetDefaultParams())
   BhpIelOqUgfKCzdWsETVJGMyrajbXu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.callRequestCookies('Get',BhpIelOqUgfKCzdWsETVJGMyrajbXw,payload=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,params=BhpIelOqUgfKCzdWsETVJGMyrajbiu,headers=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,cookies=BhpIelOqUgfKCzdWsETVJGMyrajbmQ)
   BhpIelOqUgfKCzdWsETVJGMyrajbXP=json.loads(BhpIelOqUgfKCzdWsETVJGMyrajbXu.text)
   if not('celllist' in BhpIelOqUgfKCzdWsETVJGMyrajbXP['band']):return[]
   BhpIelOqUgfKCzdWsETVJGMyrajbxt=BhpIelOqUgfKCzdWsETVJGMyrajbXP['band']['celllist']
   for BhpIelOqUgfKCzdWsETVJGMyrajbxc in BhpIelOqUgfKCzdWsETVJGMyrajbxt:
    BhpIelOqUgfKCzdWsETVJGMyrajbxm =BhpIelOqUgfKCzdWsETVJGMyrajbxc['event_list'][1]['url']
    (BhpIelOqUgfKCzdWsETVJGMyrajbxk,BhpIelOqUgfKCzdWsETVJGMyrajbxL)=BhpIelOqUgfKCzdWsETVJGMyrajbiR.Baseapi_Parse(BhpIelOqUgfKCzdWsETVJGMyrajbxm)
    BhpIelOqUgfKCzdWsETVJGMyrajbxR={'title':BhpIelOqUgfKCzdWsETVJGMyrajbxc['title_list'][0]['text'],'suburl':BhpIelOqUgfKCzdWsETVJGMyrajbxk,'subapi':BhpIelOqUgfKCzdWsETVJGMyrajbxL.get('api'),'subtype':'catagory' if BhpIelOqUgfKCzdWsETVJGMyrajbxL else 'supersection'}
    BhpIelOqUgfKCzdWsETVJGMyrajbxi.append(BhpIelOqUgfKCzdWsETVJGMyrajbxR)
  except BhpIelOqUgfKCzdWsETVJGMyrajbkL as exception:
   BhpIelOqUgfKCzdWsETVJGMyrajbki(exception)
   return[]
  return BhpIelOqUgfKCzdWsETVJGMyrajbxi
 def Get_SuperMultiSection_List(BhpIelOqUgfKCzdWsETVJGMyrajbiR,subapi_text):
  BhpIelOqUgfKCzdWsETVJGMyrajbxi=[]
  if '/multiband/' in subapi_text: 
   BhpIelOqUgfKCzdWsETVJGMyrajbXw=subapi_text 
   BhpIelOqUgfKCzdWsETVJGMyrajbiu={'client':'40'}
  else:
   BhpIelOqUgfKCzdWsETVJGMyrajbXw=subapi_text 
   BhpIelOqUgfKCzdWsETVJGMyrajbXw=BhpIelOqUgfKCzdWsETVJGMyrajbXw.replace('www.wavve.com','apis.wavve.com').replace('supermultisection','v1/multiband')
   BhpIelOqUgfKCzdWsETVJGMyrajbiu={}
  try:
   BhpIelOqUgfKCzdWsETVJGMyrajbiu.update(BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetDefaultParams())
   BhpIelOqUgfKCzdWsETVJGMyrajbXu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.callRequestCookies('Get',BhpIelOqUgfKCzdWsETVJGMyrajbXw,payload=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,params=BhpIelOqUgfKCzdWsETVJGMyrajbiu,headers=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,cookies=BhpIelOqUgfKCzdWsETVJGMyrajbmQ)
   BhpIelOqUgfKCzdWsETVJGMyrajbXP=json.loads(BhpIelOqUgfKCzdWsETVJGMyrajbXu.text)
   if not('multisectionlist' in BhpIelOqUgfKCzdWsETVJGMyrajbXP):return[]
   BhpIelOqUgfKCzdWsETVJGMyrajbxt=BhpIelOqUgfKCzdWsETVJGMyrajbXP['multisectionlist']
   for BhpIelOqUgfKCzdWsETVJGMyrajbxc in BhpIelOqUgfKCzdWsETVJGMyrajbxt:
    BhpIelOqUgfKCzdWsETVJGMyrajbxH=BhpIelOqUgfKCzdWsETVJGMyrajbxc['title']
    if BhpIelOqUgfKCzdWsETVJGMyrajbkm(BhpIelOqUgfKCzdWsETVJGMyrajbxH)==0:continue
    if BhpIelOqUgfKCzdWsETVJGMyrajbxH=='minor':continue
    if re.search(u'베너',BhpIelOqUgfKCzdWsETVJGMyrajbxH):continue
    if re.search(u'배너',BhpIelOqUgfKCzdWsETVJGMyrajbxH):continue 
    if BhpIelOqUgfKCzdWsETVJGMyrajbxc['force_refresh']=='y':continue
    if BhpIelOqUgfKCzdWsETVJGMyrajbkm(BhpIelOqUgfKCzdWsETVJGMyrajbxc['eventlist'])>=3:
     BhpIelOqUgfKCzdWsETVJGMyrajbxL =BhpIelOqUgfKCzdWsETVJGMyrajbxc['eventlist'][2]['url']
    else:
     BhpIelOqUgfKCzdWsETVJGMyrajbxL =BhpIelOqUgfKCzdWsETVJGMyrajbxc['eventlist'][1]['url']
    BhpIelOqUgfKCzdWsETVJGMyrajbxn=BhpIelOqUgfKCzdWsETVJGMyrajbxc['cell_type']
    if BhpIelOqUgfKCzdWsETVJGMyrajbxn=='band_2':
     if BhpIelOqUgfKCzdWsETVJGMyrajbxL.find('channellist=')>=0:
      BhpIelOqUgfKCzdWsETVJGMyrajbxn='band_live'
    BhpIelOqUgfKCzdWsETVJGMyrajbxR={'title':BhpIelOqUgfKCzdWsETVJGMyrajbiR.Get_ChangeText(BhpIelOqUgfKCzdWsETVJGMyrajbxH),'subapi':BhpIelOqUgfKCzdWsETVJGMyrajbxL,'cell_type':BhpIelOqUgfKCzdWsETVJGMyrajbxn}
    BhpIelOqUgfKCzdWsETVJGMyrajbxi.append(BhpIelOqUgfKCzdWsETVJGMyrajbxR)
  except BhpIelOqUgfKCzdWsETVJGMyrajbkL as exception:
   BhpIelOqUgfKCzdWsETVJGMyrajbki(exception)
   return[]
  return BhpIelOqUgfKCzdWsETVJGMyrajbxi
 def Get_BandLiveSection_List(BhpIelOqUgfKCzdWsETVJGMyrajbiR,BhpIelOqUgfKCzdWsETVJGMyrajbxX,page_int=1):
  BhpIelOqUgfKCzdWsETVJGMyrajbxo=[]
  BhpIelOqUgfKCzdWsETVJGMyrajbxv=BhpIelOqUgfKCzdWsETVJGMyrajbxD=1
  BhpIelOqUgfKCzdWsETVJGMyrajbxw=BhpIelOqUgfKCzdWsETVJGMyrajbkx
  try:
   (BhpIelOqUgfKCzdWsETVJGMyrajbXw,BhpIelOqUgfKCzdWsETVJGMyrajbiu)=BhpIelOqUgfKCzdWsETVJGMyrajbiR.Baseapi_Parse(BhpIelOqUgfKCzdWsETVJGMyrajbxX)
  except BhpIelOqUgfKCzdWsETVJGMyrajbkL as exception:
   BhpIelOqUgfKCzdWsETVJGMyrajbki(exception)
   return[],BhpIelOqUgfKCzdWsETVJGMyrajbkx
  try:
   BhpIelOqUgfKCzdWsETVJGMyrajbiu['limit']=BhpIelOqUgfKCzdWsETVJGMyrajbiR.LIST_LIMIT
   BhpIelOqUgfKCzdWsETVJGMyrajbiu['offset']=BhpIelOqUgfKCzdWsETVJGMyrajbkX((page_int-1)*BhpIelOqUgfKCzdWsETVJGMyrajbiR.LIST_LIMIT)
   BhpIelOqUgfKCzdWsETVJGMyrajbiu.update(BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetDefaultParams())
   BhpIelOqUgfKCzdWsETVJGMyrajbXu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.callRequestCookies('Get',BhpIelOqUgfKCzdWsETVJGMyrajbXw,payload=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,params=BhpIelOqUgfKCzdWsETVJGMyrajbiu,headers=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,cookies=BhpIelOqUgfKCzdWsETVJGMyrajbmQ)
   BhpIelOqUgfKCzdWsETVJGMyrajbXP=json.loads(BhpIelOqUgfKCzdWsETVJGMyrajbXu.text)
   if not('celllist' in BhpIelOqUgfKCzdWsETVJGMyrajbXP['cell_toplist']):return[],BhpIelOqUgfKCzdWsETVJGMyrajbkx
   BhpIelOqUgfKCzdWsETVJGMyrajbxt=BhpIelOqUgfKCzdWsETVJGMyrajbXP['cell_toplist']['celllist']
   for BhpIelOqUgfKCzdWsETVJGMyrajbxc in BhpIelOqUgfKCzdWsETVJGMyrajbxt:
    BhpIelOqUgfKCzdWsETVJGMyrajbxN =BhpIelOqUgfKCzdWsETVJGMyrajbxc['event_list'][1]['url']
    BhpIelOqUgfKCzdWsETVJGMyrajbxu=urllib.parse.urlsplit(BhpIelOqUgfKCzdWsETVJGMyrajbxN).query
    BhpIelOqUgfKCzdWsETVJGMyrajbxu=BhpIelOqUgfKCzdWsETVJGMyrajbkH(urllib.parse.parse_qsl(BhpIelOqUgfKCzdWsETVJGMyrajbxu))
    BhpIelOqUgfKCzdWsETVJGMyrajbxP='channelid'
    BhpIelOqUgfKCzdWsETVJGMyrajbxF=BhpIelOqUgfKCzdWsETVJGMyrajbxu[BhpIelOqUgfKCzdWsETVJGMyrajbxP]
    BhpIelOqUgfKCzdWsETVJGMyrajbxR={'studio':BhpIelOqUgfKCzdWsETVJGMyrajbxc['title_list'][0]['text'],'tvshowtitle':BhpIelOqUgfKCzdWsETVJGMyrajbiR.Get_ChangeText(BhpIelOqUgfKCzdWsETVJGMyrajbxc['title_list'][1]['text']),'channelid':BhpIelOqUgfKCzdWsETVJGMyrajbxF,'age':BhpIelOqUgfKCzdWsETVJGMyrajbxc.get('age'),'thumbnail':'https://%s'%BhpIelOqUgfKCzdWsETVJGMyrajbxc.get('thumbnail')}
    BhpIelOqUgfKCzdWsETVJGMyrajbxo.append(BhpIelOqUgfKCzdWsETVJGMyrajbxR)
   BhpIelOqUgfKCzdWsETVJGMyrajbxv=BhpIelOqUgfKCzdWsETVJGMyrajbkn(BhpIelOqUgfKCzdWsETVJGMyrajbXP['cell_toplist']['pagecount'])
   if BhpIelOqUgfKCzdWsETVJGMyrajbXP['cell_toplist']['count']:BhpIelOqUgfKCzdWsETVJGMyrajbxD =BhpIelOqUgfKCzdWsETVJGMyrajbkn(BhpIelOqUgfKCzdWsETVJGMyrajbXP['cell_toplist']['count'])
   else:BhpIelOqUgfKCzdWsETVJGMyrajbxD=BhpIelOqUgfKCzdWsETVJGMyrajbiR.LIST_LIMIT*page_int
   BhpIelOqUgfKCzdWsETVJGMyrajbxw=BhpIelOqUgfKCzdWsETVJGMyrajbxv>BhpIelOqUgfKCzdWsETVJGMyrajbxD
  except BhpIelOqUgfKCzdWsETVJGMyrajbkL as exception:
   BhpIelOqUgfKCzdWsETVJGMyrajbki(exception)
   return[],BhpIelOqUgfKCzdWsETVJGMyrajbkx
  return BhpIelOqUgfKCzdWsETVJGMyrajbxo,BhpIelOqUgfKCzdWsETVJGMyrajbxw
 def Get_Band2Section_List(BhpIelOqUgfKCzdWsETVJGMyrajbiR,BhpIelOqUgfKCzdWsETVJGMyrajbxX,page_int=1):
  BhpIelOqUgfKCzdWsETVJGMyrajbxS=[]
  BhpIelOqUgfKCzdWsETVJGMyrajbxv=BhpIelOqUgfKCzdWsETVJGMyrajbxD=1
  BhpIelOqUgfKCzdWsETVJGMyrajbxw=BhpIelOqUgfKCzdWsETVJGMyrajbkx
  try:
   (BhpIelOqUgfKCzdWsETVJGMyrajbXw,BhpIelOqUgfKCzdWsETVJGMyrajbiu)=BhpIelOqUgfKCzdWsETVJGMyrajbiR.Baseapi_Parse(BhpIelOqUgfKCzdWsETVJGMyrajbxX)
  except BhpIelOqUgfKCzdWsETVJGMyrajbkL as exception:
   BhpIelOqUgfKCzdWsETVJGMyrajbki(exception)
   return[],BhpIelOqUgfKCzdWsETVJGMyrajbkx
  try:
   BhpIelOqUgfKCzdWsETVJGMyrajbiu['came'] ='BandView'
   BhpIelOqUgfKCzdWsETVJGMyrajbiu['limit']=BhpIelOqUgfKCzdWsETVJGMyrajbiR.LIST_LIMIT
   BhpIelOqUgfKCzdWsETVJGMyrajbiu['offset']=BhpIelOqUgfKCzdWsETVJGMyrajbkX((page_int-1)*BhpIelOqUgfKCzdWsETVJGMyrajbiR.LIST_LIMIT)
   BhpIelOqUgfKCzdWsETVJGMyrajbiu.update(BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetDefaultParams())
   BhpIelOqUgfKCzdWsETVJGMyrajbXu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.callRequestCookies('Get',BhpIelOqUgfKCzdWsETVJGMyrajbXw,payload=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,params=BhpIelOqUgfKCzdWsETVJGMyrajbiu,headers=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,cookies=BhpIelOqUgfKCzdWsETVJGMyrajbmQ)
   BhpIelOqUgfKCzdWsETVJGMyrajbXP=json.loads(BhpIelOqUgfKCzdWsETVJGMyrajbXu.text)
   if not('celllist' in BhpIelOqUgfKCzdWsETVJGMyrajbXP['cell_toplist']):return[],BhpIelOqUgfKCzdWsETVJGMyrajbkx
   BhpIelOqUgfKCzdWsETVJGMyrajbxt=BhpIelOqUgfKCzdWsETVJGMyrajbXP['cell_toplist']['celllist']
   for BhpIelOqUgfKCzdWsETVJGMyrajbxc in BhpIelOqUgfKCzdWsETVJGMyrajbxt:
    BhpIelOqUgfKCzdWsETVJGMyrajbxN =BhpIelOqUgfKCzdWsETVJGMyrajbxc['event_list'][1]['url']
    BhpIelOqUgfKCzdWsETVJGMyrajbxu=urllib.parse.urlsplit(BhpIelOqUgfKCzdWsETVJGMyrajbxN).query
    BhpIelOqUgfKCzdWsETVJGMyrajbxu=BhpIelOqUgfKCzdWsETVJGMyrajbkH(urllib.parse.parse_qsl(BhpIelOqUgfKCzdWsETVJGMyrajbxu))
    BhpIelOqUgfKCzdWsETVJGMyrajbxP='contentid'
    BhpIelOqUgfKCzdWsETVJGMyrajbxF=BhpIelOqUgfKCzdWsETVJGMyrajbxu[BhpIelOqUgfKCzdWsETVJGMyrajbxP]
    BhpIelOqUgfKCzdWsETVJGMyrajbxR={'programtitle':BhpIelOqUgfKCzdWsETVJGMyrajbxc['title_list'][0]['text'],'episodetitle':BhpIelOqUgfKCzdWsETVJGMyrajbiR.Get_ChangeText(BhpIelOqUgfKCzdWsETVJGMyrajbxc['title_list'][1]['text']),'age':BhpIelOqUgfKCzdWsETVJGMyrajbxc.get('age'),'thumbnail':BhpIelOqUgfKCzdWsETVJGMyrajbiR.HTTPTAG+BhpIelOqUgfKCzdWsETVJGMyrajbxc.get('thumbnail'),'vidtype':BhpIelOqUgfKCzdWsETVJGMyrajbxP,'videoid':BhpIelOqUgfKCzdWsETVJGMyrajbxF}
    BhpIelOqUgfKCzdWsETVJGMyrajbxS.append(BhpIelOqUgfKCzdWsETVJGMyrajbxR)
   BhpIelOqUgfKCzdWsETVJGMyrajbxv=BhpIelOqUgfKCzdWsETVJGMyrajbkn(BhpIelOqUgfKCzdWsETVJGMyrajbXP['cell_toplist']['pagecount'])
   if BhpIelOqUgfKCzdWsETVJGMyrajbXP['cell_toplist']['count']:BhpIelOqUgfKCzdWsETVJGMyrajbxD =BhpIelOqUgfKCzdWsETVJGMyrajbkn(BhpIelOqUgfKCzdWsETVJGMyrajbXP['cell_toplist']['count'])
   else:BhpIelOqUgfKCzdWsETVJGMyrajbxD=BhpIelOqUgfKCzdWsETVJGMyrajbiR.LIST_LIMIT*page_int
   BhpIelOqUgfKCzdWsETVJGMyrajbxw=BhpIelOqUgfKCzdWsETVJGMyrajbxv>BhpIelOqUgfKCzdWsETVJGMyrajbxD
  except BhpIelOqUgfKCzdWsETVJGMyrajbkL as exception:
   BhpIelOqUgfKCzdWsETVJGMyrajbki(exception)
   return[],BhpIelOqUgfKCzdWsETVJGMyrajbkx
  return BhpIelOqUgfKCzdWsETVJGMyrajbxS,BhpIelOqUgfKCzdWsETVJGMyrajbxw
 def Get_Program_List_new(BhpIelOqUgfKCzdWsETVJGMyrajbiR,BhpIelOqUgfKCzdWsETVJGMyrajbxX,page_int=1,orderby='-'):
  BhpIelOqUgfKCzdWsETVJGMyrajbxA=[]
  BhpIelOqUgfKCzdWsETVJGMyrajbxv=BhpIelOqUgfKCzdWsETVJGMyrajbxD=1
  BhpIelOqUgfKCzdWsETVJGMyrajbxw=BhpIelOqUgfKCzdWsETVJGMyrajbkx
  (BhpIelOqUgfKCzdWsETVJGMyrajbXw,BhpIelOqUgfKCzdWsETVJGMyrajbiu)=BhpIelOqUgfKCzdWsETVJGMyrajbiR.Baseapi_Parse(BhpIelOqUgfKCzdWsETVJGMyrajbxX)
  if BhpIelOqUgfKCzdWsETVJGMyrajbXw=='':return BhpIelOqUgfKCzdWsETVJGMyrajbxA,BhpIelOqUgfKCzdWsETVJGMyrajbxw
  try:
   BhpIelOqUgfKCzdWsETVJGMyrajbiu['limit'] =BhpIelOqUgfKCzdWsETVJGMyrajbiR.LIST_LIMIT
   BhpIelOqUgfKCzdWsETVJGMyrajbiu['offset']=BhpIelOqUgfKCzdWsETVJGMyrajbkX((page_int-1)*BhpIelOqUgfKCzdWsETVJGMyrajbiR.LIST_LIMIT)
   if BhpIelOqUgfKCzdWsETVJGMyrajbiu.get('orderby')!='' and BhpIelOqUgfKCzdWsETVJGMyrajbiu.get('orderby')!='regdatefirst' and orderby!='-':
    BhpIelOqUgfKCzdWsETVJGMyrajbiu['orderby']=orderby 
   BhpIelOqUgfKCzdWsETVJGMyrajbiu.update(BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetDefaultParams())
   BhpIelOqUgfKCzdWsETVJGMyrajbXu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.callRequestCookies('Get',BhpIelOqUgfKCzdWsETVJGMyrajbXw,payload=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,params=BhpIelOqUgfKCzdWsETVJGMyrajbiu,headers=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,cookies=BhpIelOqUgfKCzdWsETVJGMyrajbmQ)
   BhpIelOqUgfKCzdWsETVJGMyrajbXP=json.loads(BhpIelOqUgfKCzdWsETVJGMyrajbXu.text)
   BhpIelOqUgfKCzdWsETVJGMyrajbxt=BhpIelOqUgfKCzdWsETVJGMyrajbXP['data']['context_list']
   for BhpIelOqUgfKCzdWsETVJGMyrajbxc in BhpIelOqUgfKCzdWsETVJGMyrajbxt:
    BhpIelOqUgfKCzdWsETVJGMyrajbxR={'title':BhpIelOqUgfKCzdWsETVJGMyrajbxc['program']['title'],'thumbnail':BhpIelOqUgfKCzdWsETVJGMyrajbxc['program']['vertical_logo_y_image'],'videoid':BhpIelOqUgfKCzdWsETVJGMyrajbxc['context_id'],'vidtype':'contentid',}
    BhpIelOqUgfKCzdWsETVJGMyrajbxA.append(BhpIelOqUgfKCzdWsETVJGMyrajbxR)
   '''
   if res_json.get('cell_toplist') not in [{}, None, '' ]:
    pagecount = int(res_json['cell_toplist']['pagecount'])
    if res_json['cell_toplist']['count']: nowcount  = int(res_json['cell_toplist']['count'])
    else: nowcount = self.LIST_LIMIT * page_int
    more_page = pagecount > nowcount
   '''   
   if BhpIelOqUgfKCzdWsETVJGMyrajbkn(BhpIelOqUgfKCzdWsETVJGMyrajbXP['data']['pagecount'])>page_int:
    BhpIelOqUgfKCzdWsETVJGMyrajbxw=BhpIelOqUgfKCzdWsETVJGMyrajbkc
  except BhpIelOqUgfKCzdWsETVJGMyrajbkL as exception:
   BhpIelOqUgfKCzdWsETVJGMyrajbki(exception)
   addon_log('error : {}'.format(exception))
   return[],BhpIelOqUgfKCzdWsETVJGMyrajbkx
  return BhpIelOqUgfKCzdWsETVJGMyrajbxA,BhpIelOqUgfKCzdWsETVJGMyrajbxw
 def Get_Program_List(BhpIelOqUgfKCzdWsETVJGMyrajbiR,BhpIelOqUgfKCzdWsETVJGMyrajbxX,page_int=1,orderby='-'):
  BhpIelOqUgfKCzdWsETVJGMyrajbxA=[]
  BhpIelOqUgfKCzdWsETVJGMyrajbxv=BhpIelOqUgfKCzdWsETVJGMyrajbxD=1
  BhpIelOqUgfKCzdWsETVJGMyrajbxw=BhpIelOqUgfKCzdWsETVJGMyrajbkx
  (BhpIelOqUgfKCzdWsETVJGMyrajbXw,BhpIelOqUgfKCzdWsETVJGMyrajbiu)=BhpIelOqUgfKCzdWsETVJGMyrajbiR.Baseapi_Parse(BhpIelOqUgfKCzdWsETVJGMyrajbxX)
  if BhpIelOqUgfKCzdWsETVJGMyrajbXw=='':return BhpIelOqUgfKCzdWsETVJGMyrajbxA,BhpIelOqUgfKCzdWsETVJGMyrajbxw
  try:
   BhpIelOqUgfKCzdWsETVJGMyrajbiu['limit'] =BhpIelOqUgfKCzdWsETVJGMyrajbiR.LIST_LIMIT
   BhpIelOqUgfKCzdWsETVJGMyrajbiu['offset']=BhpIelOqUgfKCzdWsETVJGMyrajbkX((page_int-1)*BhpIelOqUgfKCzdWsETVJGMyrajbiR.LIST_LIMIT)
   BhpIelOqUgfKCzdWsETVJGMyrajbiu['page'] =BhpIelOqUgfKCzdWsETVJGMyrajbkX(page_int)
   if BhpIelOqUgfKCzdWsETVJGMyrajbiu.get('orderby')!='' and BhpIelOqUgfKCzdWsETVJGMyrajbiu.get('orderby')!='regdatefirst' and orderby!='-':
    BhpIelOqUgfKCzdWsETVJGMyrajbiu['orderby']=orderby 
   BhpIelOqUgfKCzdWsETVJGMyrajbiu.update(BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetDefaultParams())
   BhpIelOqUgfKCzdWsETVJGMyrajbXu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.callRequestCookies('Get',BhpIelOqUgfKCzdWsETVJGMyrajbXw,payload=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,params=BhpIelOqUgfKCzdWsETVJGMyrajbiu,headers=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,cookies=BhpIelOqUgfKCzdWsETVJGMyrajbmQ)
   BhpIelOqUgfKCzdWsETVJGMyrajbXP=json.loads(BhpIelOqUgfKCzdWsETVJGMyrajbXu.text)
   if BhpIelOqUgfKCzdWsETVJGMyrajbXP.get('cell_toplist')not in[{},BhpIelOqUgfKCzdWsETVJGMyrajbmQ,'']:
    BhpIelOqUgfKCzdWsETVJGMyrajbxt=BhpIelOqUgfKCzdWsETVJGMyrajbXP['cell_toplist']['celllist']
   elif BhpIelOqUgfKCzdWsETVJGMyrajbXP.get('band')not in[{},BhpIelOqUgfKCzdWsETVJGMyrajbmQ,'']:
    BhpIelOqUgfKCzdWsETVJGMyrajbxt=BhpIelOqUgfKCzdWsETVJGMyrajbXP['band']['celllist']
   else:
    return BhpIelOqUgfKCzdWsETVJGMyrajbxA,BhpIelOqUgfKCzdWsETVJGMyrajbxw
   for BhpIelOqUgfKCzdWsETVJGMyrajbxc in BhpIelOqUgfKCzdWsETVJGMyrajbxt:
    for BhpIelOqUgfKCzdWsETVJGMyrajbxQ in BhpIelOqUgfKCzdWsETVJGMyrajbxc['event_list']:
     if BhpIelOqUgfKCzdWsETVJGMyrajbxQ.get('type')=='on-navigation':
      BhpIelOqUgfKCzdWsETVJGMyrajbxN =BhpIelOqUgfKCzdWsETVJGMyrajbxQ['url']
    BhpIelOqUgfKCzdWsETVJGMyrajbxu=urllib.parse.urlsplit(BhpIelOqUgfKCzdWsETVJGMyrajbxN).query
    BhpIelOqUgfKCzdWsETVJGMyrajbxP=BhpIelOqUgfKCzdWsETVJGMyrajbxu[0:BhpIelOqUgfKCzdWsETVJGMyrajbxu.find('=')]
    BhpIelOqUgfKCzdWsETVJGMyrajbxY=BhpIelOqUgfKCzdWsETVJGMyrajbkH(urllib.parse.parse_qsl(BhpIelOqUgfKCzdWsETVJGMyrajbxu))
    BhpIelOqUgfKCzdWsETVJGMyrajbxF=BhpIelOqUgfKCzdWsETVJGMyrajbxY.get(BhpIelOqUgfKCzdWsETVJGMyrajbxP)
    BhpIelOqUgfKCzdWsETVJGMyrajbxR={'title':BhpIelOqUgfKCzdWsETVJGMyrajbxc.get('alt')or BhpIelOqUgfKCzdWsETVJGMyrajbxc.get('title_list')[0].get('text'),'age':BhpIelOqUgfKCzdWsETVJGMyrajbxc.get('age'),'thumbnail':BhpIelOqUgfKCzdWsETVJGMyrajbxc.get('thumbnail'),'videoid':BhpIelOqUgfKCzdWsETVJGMyrajbxF,'vidtype':BhpIelOqUgfKCzdWsETVJGMyrajbxP,}
    if not BhpIelOqUgfKCzdWsETVJGMyrajbxR.get('thumbnail').startswith('http'):
     BhpIelOqUgfKCzdWsETVJGMyrajbxR['thumbnail']='https://%s'%BhpIelOqUgfKCzdWsETVJGMyrajbxR['thumbnail']
    BhpIelOqUgfKCzdWsETVJGMyrajbxA.append(BhpIelOqUgfKCzdWsETVJGMyrajbxR)
   if BhpIelOqUgfKCzdWsETVJGMyrajbXP.get('cell_toplist')not in[{},BhpIelOqUgfKCzdWsETVJGMyrajbmQ,'']:
    BhpIelOqUgfKCzdWsETVJGMyrajbxv=BhpIelOqUgfKCzdWsETVJGMyrajbkn(BhpIelOqUgfKCzdWsETVJGMyrajbXP['cell_toplist']['pagecount'])
    if BhpIelOqUgfKCzdWsETVJGMyrajbXP['cell_toplist']['count']:BhpIelOqUgfKCzdWsETVJGMyrajbxD =BhpIelOqUgfKCzdWsETVJGMyrajbkn(BhpIelOqUgfKCzdWsETVJGMyrajbXP['cell_toplist']['count'])
    else:BhpIelOqUgfKCzdWsETVJGMyrajbxD=BhpIelOqUgfKCzdWsETVJGMyrajbiR.LIST_LIMIT*page_int
    BhpIelOqUgfKCzdWsETVJGMyrajbxw=BhpIelOqUgfKCzdWsETVJGMyrajbxv>BhpIelOqUgfKCzdWsETVJGMyrajbxD
  except BhpIelOqUgfKCzdWsETVJGMyrajbkL as exception:
   BhpIelOqUgfKCzdWsETVJGMyrajbki(exception)
   return[],BhpIelOqUgfKCzdWsETVJGMyrajbkx
  return BhpIelOqUgfKCzdWsETVJGMyrajbxA,BhpIelOqUgfKCzdWsETVJGMyrajbxw
 def Get_Movie_List(BhpIelOqUgfKCzdWsETVJGMyrajbiR,BhpIelOqUgfKCzdWsETVJGMyrajbxX,page_int=1,orderby='-'):
  BhpIelOqUgfKCzdWsETVJGMyrajbti=[]
  BhpIelOqUgfKCzdWsETVJGMyrajbxv=BhpIelOqUgfKCzdWsETVJGMyrajbxD=1
  BhpIelOqUgfKCzdWsETVJGMyrajbxw=BhpIelOqUgfKCzdWsETVJGMyrajbkx
  (BhpIelOqUgfKCzdWsETVJGMyrajbXw,BhpIelOqUgfKCzdWsETVJGMyrajbiu)=BhpIelOqUgfKCzdWsETVJGMyrajbiR.Baseapi_Parse(BhpIelOqUgfKCzdWsETVJGMyrajbxX)
  if BhpIelOqUgfKCzdWsETVJGMyrajbXw=='':return BhpIelOqUgfKCzdWsETVJGMyrajbti,BhpIelOqUgfKCzdWsETVJGMyrajbxw
  try:
   BhpIelOqUgfKCzdWsETVJGMyrajbiu['limit']=BhpIelOqUgfKCzdWsETVJGMyrajbiR.MV_LIMIT
   BhpIelOqUgfKCzdWsETVJGMyrajbiu['offset']=BhpIelOqUgfKCzdWsETVJGMyrajbkX((page_int-1)*BhpIelOqUgfKCzdWsETVJGMyrajbiR.MV_LIMIT)
   if BhpIelOqUgfKCzdWsETVJGMyrajbiu.get('orderby')!='' and BhpIelOqUgfKCzdWsETVJGMyrajbiu.get('orderby')!='regdatefirst' and orderby!='-':
    BhpIelOqUgfKCzdWsETVJGMyrajbiu['orderby']=orderby 
   BhpIelOqUgfKCzdWsETVJGMyrajbiu.update(BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetDefaultParams())
   BhpIelOqUgfKCzdWsETVJGMyrajbXu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.callRequestCookies('Get',BhpIelOqUgfKCzdWsETVJGMyrajbXw,payload=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,params=BhpIelOqUgfKCzdWsETVJGMyrajbiu,headers=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,cookies=BhpIelOqUgfKCzdWsETVJGMyrajbmQ)
   BhpIelOqUgfKCzdWsETVJGMyrajbXP=json.loads(BhpIelOqUgfKCzdWsETVJGMyrajbXu.text)
   if BhpIelOqUgfKCzdWsETVJGMyrajbXP.get('cell_toplist')not in[{},BhpIelOqUgfKCzdWsETVJGMyrajbmQ,'']:
    BhpIelOqUgfKCzdWsETVJGMyrajbxt=BhpIelOqUgfKCzdWsETVJGMyrajbXP['cell_toplist']['celllist']
   elif BhpIelOqUgfKCzdWsETVJGMyrajbXP.get('band')not in[{},BhpIelOqUgfKCzdWsETVJGMyrajbmQ,'']:
    BhpIelOqUgfKCzdWsETVJGMyrajbxt=BhpIelOqUgfKCzdWsETVJGMyrajbXP['band']['celllist']
   else:
    return BhpIelOqUgfKCzdWsETVJGMyrajbti,BhpIelOqUgfKCzdWsETVJGMyrajbxw
   for BhpIelOqUgfKCzdWsETVJGMyrajbxc in BhpIelOqUgfKCzdWsETVJGMyrajbxt:
    BhpIelOqUgfKCzdWsETVJGMyrajbxN =BhpIelOqUgfKCzdWsETVJGMyrajbxc['event_list'][1]['url']
    BhpIelOqUgfKCzdWsETVJGMyrajbxu=urllib.parse.urlsplit(BhpIelOqUgfKCzdWsETVJGMyrajbxN).query
    BhpIelOqUgfKCzdWsETVJGMyrajbxP=BhpIelOqUgfKCzdWsETVJGMyrajbxu[0:BhpIelOqUgfKCzdWsETVJGMyrajbxu.find('=')]
    BhpIelOqUgfKCzdWsETVJGMyrajbxY=BhpIelOqUgfKCzdWsETVJGMyrajbkH(urllib.parse.parse_qsl(BhpIelOqUgfKCzdWsETVJGMyrajbxu))
    BhpIelOqUgfKCzdWsETVJGMyrajbxF=BhpIelOqUgfKCzdWsETVJGMyrajbxY.get(BhpIelOqUgfKCzdWsETVJGMyrajbxP)
    BhpIelOqUgfKCzdWsETVJGMyrajbxR={'title':BhpIelOqUgfKCzdWsETVJGMyrajbxc.get('alt')or BhpIelOqUgfKCzdWsETVJGMyrajbxc.get('title_list')[0].get('text'),'age':BhpIelOqUgfKCzdWsETVJGMyrajbxc.get('age'),'thumbnail':BhpIelOqUgfKCzdWsETVJGMyrajbxc.get('thumbnail'),'videoid':BhpIelOqUgfKCzdWsETVJGMyrajbxF,'vidtype':BhpIelOqUgfKCzdWsETVJGMyrajbxP,}
    if not BhpIelOqUgfKCzdWsETVJGMyrajbxR.get('thumbnail').startswith('http'):
     BhpIelOqUgfKCzdWsETVJGMyrajbxR['thumbnail']='https://%s'%BhpIelOqUgfKCzdWsETVJGMyrajbxR['thumbnail']
    BhpIelOqUgfKCzdWsETVJGMyrajbti.append(BhpIelOqUgfKCzdWsETVJGMyrajbxR)
   if BhpIelOqUgfKCzdWsETVJGMyrajbXP.get('cell_toplist')not in[{},BhpIelOqUgfKCzdWsETVJGMyrajbmQ,'']:
    BhpIelOqUgfKCzdWsETVJGMyrajbxv=BhpIelOqUgfKCzdWsETVJGMyrajbkn(BhpIelOqUgfKCzdWsETVJGMyrajbXP['cell_toplist']['pagecount'])
    if BhpIelOqUgfKCzdWsETVJGMyrajbXP['cell_toplist']['count']:BhpIelOqUgfKCzdWsETVJGMyrajbxD =BhpIelOqUgfKCzdWsETVJGMyrajbkn(BhpIelOqUgfKCzdWsETVJGMyrajbXP['cell_toplist']['count'])
    else:BhpIelOqUgfKCzdWsETVJGMyrajbxD=BhpIelOqUgfKCzdWsETVJGMyrajbiR.MV_LIMIT*page_int
    BhpIelOqUgfKCzdWsETVJGMyrajbxw=BhpIelOqUgfKCzdWsETVJGMyrajbxv>BhpIelOqUgfKCzdWsETVJGMyrajbxD
  except BhpIelOqUgfKCzdWsETVJGMyrajbkL as exception:
   BhpIelOqUgfKCzdWsETVJGMyrajbki(exception)
   return[],BhpIelOqUgfKCzdWsETVJGMyrajbkx
  return BhpIelOqUgfKCzdWsETVJGMyrajbti,BhpIelOqUgfKCzdWsETVJGMyrajbxw
 def ProgramidToContentid(BhpIelOqUgfKCzdWsETVJGMyrajbiR,BhpIelOqUgfKCzdWsETVJGMyrajbtc):
  BhpIelOqUgfKCzdWsETVJGMyrajbtX=''
  try:
   BhpIelOqUgfKCzdWsETVJGMyrajbXw =BhpIelOqUgfKCzdWsETVJGMyrajbiR.API_DOMAIN+'/vod/programs-contentid/'+BhpIelOqUgfKCzdWsETVJGMyrajbtc
   BhpIelOqUgfKCzdWsETVJGMyrajbiu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetDefaultParams()
   BhpIelOqUgfKCzdWsETVJGMyrajbXu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.callRequestCookies('Get',BhpIelOqUgfKCzdWsETVJGMyrajbXw,payload=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,params=BhpIelOqUgfKCzdWsETVJGMyrajbiu,headers=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,cookies=BhpIelOqUgfKCzdWsETVJGMyrajbmQ)
   BhpIelOqUgfKCzdWsETVJGMyrajbtx=json.loads(BhpIelOqUgfKCzdWsETVJGMyrajbXu.text)
   if not('contentid' in BhpIelOqUgfKCzdWsETVJGMyrajbtx):return BhpIelOqUgfKCzdWsETVJGMyrajbtX 
   BhpIelOqUgfKCzdWsETVJGMyrajbtX=BhpIelOqUgfKCzdWsETVJGMyrajbtx['contentid']
  except BhpIelOqUgfKCzdWsETVJGMyrajbkL as exception:
   BhpIelOqUgfKCzdWsETVJGMyrajbki(exception)
  return BhpIelOqUgfKCzdWsETVJGMyrajbtX
 def ContentidToSeasonid(BhpIelOqUgfKCzdWsETVJGMyrajbiR,BhpIelOqUgfKCzdWsETVJGMyrajbtX):
  BhpIelOqUgfKCzdWsETVJGMyrajbtc=''
  try:
   BhpIelOqUgfKCzdWsETVJGMyrajbXw =BhpIelOqUgfKCzdWsETVJGMyrajbiR.API_DOMAIN+'/fz/vod/contents/'+BhpIelOqUgfKCzdWsETVJGMyrajbtX
   BhpIelOqUgfKCzdWsETVJGMyrajbiu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetDefaultParams()
   BhpIelOqUgfKCzdWsETVJGMyrajbXu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.callRequestCookies('Get',BhpIelOqUgfKCzdWsETVJGMyrajbXw,payload=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,params=BhpIelOqUgfKCzdWsETVJGMyrajbiu,headers=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,cookies=BhpIelOqUgfKCzdWsETVJGMyrajbmQ)
   BhpIelOqUgfKCzdWsETVJGMyrajbtx=json.loads(BhpIelOqUgfKCzdWsETVJGMyrajbXu.text)
   if not('programid' in BhpIelOqUgfKCzdWsETVJGMyrajbtx):return BhpIelOqUgfKCzdWsETVJGMyrajbtc 
   BhpIelOqUgfKCzdWsETVJGMyrajbtc=BhpIelOqUgfKCzdWsETVJGMyrajbtx['programid']
  except BhpIelOqUgfKCzdWsETVJGMyrajbkL as exception:
   BhpIelOqUgfKCzdWsETVJGMyrajbki(exception)
  return BhpIelOqUgfKCzdWsETVJGMyrajbtc
 def GetProgramInfo(BhpIelOqUgfKCzdWsETVJGMyrajbiR,BhpIelOqUgfKCzdWsETVJGMyrajbtX):
  BhpIelOqUgfKCzdWsETVJGMyrajbtR={}
  try:
   BhpIelOqUgfKCzdWsETVJGMyrajbXw=BhpIelOqUgfKCzdWsETVJGMyrajbiR.API_DOMAIN+'/fz/vod/contents/'+BhpIelOqUgfKCzdWsETVJGMyrajbtX
   BhpIelOqUgfKCzdWsETVJGMyrajbiu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetDefaultParams()
   BhpIelOqUgfKCzdWsETVJGMyrajbXu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.callRequestCookies('Get',BhpIelOqUgfKCzdWsETVJGMyrajbXw,payload=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,params=BhpIelOqUgfKCzdWsETVJGMyrajbiu,headers=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,cookies=BhpIelOqUgfKCzdWsETVJGMyrajbmQ)
   BhpIelOqUgfKCzdWsETVJGMyrajbtx=json.loads(BhpIelOqUgfKCzdWsETVJGMyrajbXu.text)
   BhpIelOqUgfKCzdWsETVJGMyrajbtm=img_fanart=BhpIelOqUgfKCzdWsETVJGMyrajbtk=''
   if BhpIelOqUgfKCzdWsETVJGMyrajbtx.get('programposterimage')!='':BhpIelOqUgfKCzdWsETVJGMyrajbtm =BhpIelOqUgfKCzdWsETVJGMyrajbiR.HTTPTAG+BhpIelOqUgfKCzdWsETVJGMyrajbtx.get('programposterimage')
   if BhpIelOqUgfKCzdWsETVJGMyrajbtx.get('programimage') !='':img_fanart =BhpIelOqUgfKCzdWsETVJGMyrajbiR.HTTPTAG+BhpIelOqUgfKCzdWsETVJGMyrajbtx.get('programimage')
   if BhpIelOqUgfKCzdWsETVJGMyrajbtx.get('programcircleimage')!='':BhpIelOqUgfKCzdWsETVJGMyrajbtk=BhpIelOqUgfKCzdWsETVJGMyrajbiR.HTTPTAG+BhpIelOqUgfKCzdWsETVJGMyrajbtx.get('programcircleimage')
   if 'poster_default' in BhpIelOqUgfKCzdWsETVJGMyrajbtm:
    BhpIelOqUgfKCzdWsETVJGMyrajbtm =img_fanart
    BhpIelOqUgfKCzdWsETVJGMyrajbtk=''
   BhpIelOqUgfKCzdWsETVJGMyrajbtR={'imgPoster':BhpIelOqUgfKCzdWsETVJGMyrajbtm,'imgFanart':img_fanart,'imgClearlogo':BhpIelOqUgfKCzdWsETVJGMyrajbtk,'programtitle':BhpIelOqUgfKCzdWsETVJGMyrajbiR.Get_ChangeText(BhpIelOqUgfKCzdWsETVJGMyrajbtx.get('programtitle')),'programid':BhpIelOqUgfKCzdWsETVJGMyrajbtx.get('programid'),'synopsis':BhpIelOqUgfKCzdWsETVJGMyrajbiR.Get_ChangeText(BhpIelOqUgfKCzdWsETVJGMyrajbtx.get('programsynopsis')),}
  except BhpIelOqUgfKCzdWsETVJGMyrajbkL as exception:
   BhpIelOqUgfKCzdWsETVJGMyrajbki(exception)
  return BhpIelOqUgfKCzdWsETVJGMyrajbtR
 def Get_Season_List(BhpIelOqUgfKCzdWsETVJGMyrajbiR,seasonid):
  BhpIelOqUgfKCzdWsETVJGMyrajbtL=[]
  BhpIelOqUgfKCzdWsETVJGMyrajbtX=BhpIelOqUgfKCzdWsETVJGMyrajbiR.ProgramidToContentid(seasonid)
  BhpIelOqUgfKCzdWsETVJGMyrajbtH=BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetProgramInfo(BhpIelOqUgfKCzdWsETVJGMyrajbtX)
  BhpIelOqUgfKCzdWsETVJGMyrajbtn={'poster':BhpIelOqUgfKCzdWsETVJGMyrajbtH.get('imgPoster'),'fanart':BhpIelOqUgfKCzdWsETVJGMyrajbtH.get('imgFanart'),'clearlogo':BhpIelOqUgfKCzdWsETVJGMyrajbtH.get('imgClearlogo'),}
  try:
   BhpIelOqUgfKCzdWsETVJGMyrajbXw=BhpIelOqUgfKCzdWsETVJGMyrajbiR.API_DOMAIN+'/fz/vod/programs-contents/'+seasonid
   BhpIelOqUgfKCzdWsETVJGMyrajbiu={'limit':'10','offset':'0','orderby':'new',}
   BhpIelOqUgfKCzdWsETVJGMyrajbiu.update(BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetDefaultParams())
   BhpIelOqUgfKCzdWsETVJGMyrajbXu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.callRequestCookies('Get',BhpIelOqUgfKCzdWsETVJGMyrajbXw,payload=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,params=BhpIelOqUgfKCzdWsETVJGMyrajbiu,headers=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,cookies=BhpIelOqUgfKCzdWsETVJGMyrajbmQ)
   BhpIelOqUgfKCzdWsETVJGMyrajbXP=json.loads(BhpIelOqUgfKCzdWsETVJGMyrajbXu.text)
   for BhpIelOqUgfKCzdWsETVJGMyrajbto in BhpIelOqUgfKCzdWsETVJGMyrajbXP['filter']['filterlist'][0]['filter_item_list']:
    BhpIelOqUgfKCzdWsETVJGMyrajbxR={'season_Nm':BhpIelOqUgfKCzdWsETVJGMyrajbiR.Get_ChangeText(BhpIelOqUgfKCzdWsETVJGMyrajbto.get('title')),'season_Id':BhpIelOqUgfKCzdWsETVJGMyrajbto.get('api_path'),'thumbnail':BhpIelOqUgfKCzdWsETVJGMyrajbtn,'programNm':BhpIelOqUgfKCzdWsETVJGMyrajbiR.Get_ChangeText(BhpIelOqUgfKCzdWsETVJGMyrajbtH.get('programtitle')),'synopsis':BhpIelOqUgfKCzdWsETVJGMyrajbiR.Get_ChangeText(BhpIelOqUgfKCzdWsETVJGMyrajbtH.get('synopsis')),}
    BhpIelOqUgfKCzdWsETVJGMyrajbtL.append(BhpIelOqUgfKCzdWsETVJGMyrajbxR)
  except BhpIelOqUgfKCzdWsETVJGMyrajbkL as exception:
   BhpIelOqUgfKCzdWsETVJGMyrajbki(exception)
   return[]
  return BhpIelOqUgfKCzdWsETVJGMyrajbtL
 def Get_Episode_List(BhpIelOqUgfKCzdWsETVJGMyrajbiR,seasionid,page_int=1,orderby='desc'):
  BhpIelOqUgfKCzdWsETVJGMyrajbtv=[]
  BhpIelOqUgfKCzdWsETVJGMyrajbxv=BhpIelOqUgfKCzdWsETVJGMyrajbxD=1
  BhpIelOqUgfKCzdWsETVJGMyrajbxw=BhpIelOqUgfKCzdWsETVJGMyrajbkx
  BhpIelOqUgfKCzdWsETVJGMyrajbtH={}
  BhpIelOqUgfKCzdWsETVJGMyrajbtX=BhpIelOqUgfKCzdWsETVJGMyrajbiR.ProgramidToContentid(seasionid)
  BhpIelOqUgfKCzdWsETVJGMyrajbtH=BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetProgramInfo(BhpIelOqUgfKCzdWsETVJGMyrajbtX)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   BhpIelOqUgfKCzdWsETVJGMyrajbXw=BhpIelOqUgfKCzdWsETVJGMyrajbiR.API_DOMAIN+'/fz/vod/programs-contents/'+seasionid
   BhpIelOqUgfKCzdWsETVJGMyrajbiu={'limit':BhpIelOqUgfKCzdWsETVJGMyrajbiR.EP_LIMIT,'offset':BhpIelOqUgfKCzdWsETVJGMyrajbkX((page_int-1)*BhpIelOqUgfKCzdWsETVJGMyrajbiR.EP_LIMIT),'orderby':orderby,}
   BhpIelOqUgfKCzdWsETVJGMyrajbiu.update(BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetDefaultParams())
   BhpIelOqUgfKCzdWsETVJGMyrajbXu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.callRequestCookies('Get',BhpIelOqUgfKCzdWsETVJGMyrajbXw,payload=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,params=BhpIelOqUgfKCzdWsETVJGMyrajbiu,headers=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,cookies=BhpIelOqUgfKCzdWsETVJGMyrajbmQ)
   BhpIelOqUgfKCzdWsETVJGMyrajbXP=json.loads(BhpIelOqUgfKCzdWsETVJGMyrajbXu.text)
   BhpIelOqUgfKCzdWsETVJGMyrajbxt=BhpIelOqUgfKCzdWsETVJGMyrajbXP['cell_toplist']['celllist']
   for BhpIelOqUgfKCzdWsETVJGMyrajbxc in BhpIelOqUgfKCzdWsETVJGMyrajbxt:
    BhpIelOqUgfKCzdWsETVJGMyrajbtN=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',BhpIelOqUgfKCzdWsETVJGMyrajbxc.get('synopsis'))
    BhpIelOqUgfKCzdWsETVJGMyrajbtu=BhpIelOqUgfKCzdWsETVJGMyrajbxc.get('thumbnail')
    if not BhpIelOqUgfKCzdWsETVJGMyrajbtu.startswith('http'):
     BhpIelOqUgfKCzdWsETVJGMyrajbtu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.HTTPTAG+BhpIelOqUgfKCzdWsETVJGMyrajbtu
    BhpIelOqUgfKCzdWsETVJGMyrajbtP=BhpIelOqUgfKCzdWsETVJGMyrajbtF=BhpIelOqUgfKCzdWsETVJGMyrajbtD=''
    BhpIelOqUgfKCzdWsETVJGMyrajbtP =BhpIelOqUgfKCzdWsETVJGMyrajbtH.get('imgPoster')
    BhpIelOqUgfKCzdWsETVJGMyrajbtF =BhpIelOqUgfKCzdWsETVJGMyrajbtH.get('imgFanart')
    BhpIelOqUgfKCzdWsETVJGMyrajbtD =BhpIelOqUgfKCzdWsETVJGMyrajbtH.get('imgClearlogo')
    BhpIelOqUgfKCzdWsETVJGMyrajbtS=BhpIelOqUgfKCzdWsETVJGMyrajbtH.get('programtitle')
    BhpIelOqUgfKCzdWsETVJGMyrajbtn={'thumb':BhpIelOqUgfKCzdWsETVJGMyrajbtu,'poster':BhpIelOqUgfKCzdWsETVJGMyrajbtP,'fanart':BhpIelOqUgfKCzdWsETVJGMyrajbtF,'clearlogo':BhpIelOqUgfKCzdWsETVJGMyrajbtD}
    BhpIelOqUgfKCzdWsETVJGMyrajbxR={'programtitle':BhpIelOqUgfKCzdWsETVJGMyrajbiR.Get_ChangeText(BhpIelOqUgfKCzdWsETVJGMyrajbtS),'episodetitle':BhpIelOqUgfKCzdWsETVJGMyrajbiR.Get_ChangeText(BhpIelOqUgfKCzdWsETVJGMyrajbxc['title_list'][0]['text']),'episodenumber':BhpIelOqUgfKCzdWsETVJGMyrajbxc['title_list'][1]['text'].replace('$O$',''),'contentid':BhpIelOqUgfKCzdWsETVJGMyrajbxc['contentid'],'synopsis':BhpIelOqUgfKCzdWsETVJGMyrajbiR.Get_ChangeText(BhpIelOqUgfKCzdWsETVJGMyrajbtN),'episodeactors':BhpIelOqUgfKCzdWsETVJGMyrajbxc.get('actors').split(',')if BhpIelOqUgfKCzdWsETVJGMyrajbxc.get('actors')!='' else[],'thumbnail':BhpIelOqUgfKCzdWsETVJGMyrajbtn,}
    BhpIelOqUgfKCzdWsETVJGMyrajbtv.append(BhpIelOqUgfKCzdWsETVJGMyrajbxR)
   BhpIelOqUgfKCzdWsETVJGMyrajbxv=BhpIelOqUgfKCzdWsETVJGMyrajbkn(BhpIelOqUgfKCzdWsETVJGMyrajbXP['cell_toplist']['pagecount'])
   if BhpIelOqUgfKCzdWsETVJGMyrajbXP['cell_toplist']['count']:BhpIelOqUgfKCzdWsETVJGMyrajbxD =BhpIelOqUgfKCzdWsETVJGMyrajbkn(BhpIelOqUgfKCzdWsETVJGMyrajbXP['cell_toplist']['count'])
   else:BhpIelOqUgfKCzdWsETVJGMyrajbxD=BhpIelOqUgfKCzdWsETVJGMyrajbiR.EP_LIMIT*page_int
   BhpIelOqUgfKCzdWsETVJGMyrajbxw=BhpIelOqUgfKCzdWsETVJGMyrajbxv>BhpIelOqUgfKCzdWsETVJGMyrajbxD
  except BhpIelOqUgfKCzdWsETVJGMyrajbkL as exception:
   BhpIelOqUgfKCzdWsETVJGMyrajbki(exception)
   return[],BhpIelOqUgfKCzdWsETVJGMyrajbkx
  return BhpIelOqUgfKCzdWsETVJGMyrajbtv,BhpIelOqUgfKCzdWsETVJGMyrajbxw
 def GetEPGList(BhpIelOqUgfKCzdWsETVJGMyrajbiR,genre):
  BhpIelOqUgfKCzdWsETVJGMyrajbtA={}
  try:
   BhpIelOqUgfKCzdWsETVJGMyrajbtQ=BhpIelOqUgfKCzdWsETVJGMyrajbiR.Get_Now_Datetime()
   if genre=='all':
    BhpIelOqUgfKCzdWsETVJGMyrajbtY =BhpIelOqUgfKCzdWsETVJGMyrajbtQ+datetime.timedelta(hours=3)
   else:
    BhpIelOqUgfKCzdWsETVJGMyrajbtY =BhpIelOqUgfKCzdWsETVJGMyrajbtQ+datetime.timedelta(hours=3)
   BhpIelOqUgfKCzdWsETVJGMyrajbXw=BhpIelOqUgfKCzdWsETVJGMyrajbiR.API_DOMAIN+'/live/epgs'
   BhpIelOqUgfKCzdWsETVJGMyrajbiu={'limit':'100','offset':'0','genre':genre,'startdatetime':BhpIelOqUgfKCzdWsETVJGMyrajbtQ.strftime('%Y-%m-%d %H:00'),'enddatetime':BhpIelOqUgfKCzdWsETVJGMyrajbtY.strftime('%Y-%m-%d %H:00')}
   BhpIelOqUgfKCzdWsETVJGMyrajbiu.update(BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetDefaultParams())
   BhpIelOqUgfKCzdWsETVJGMyrajbXu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.callRequestCookies('Get',BhpIelOqUgfKCzdWsETVJGMyrajbXw,payload=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,params=BhpIelOqUgfKCzdWsETVJGMyrajbiu,headers=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,cookies=BhpIelOqUgfKCzdWsETVJGMyrajbmQ)
   BhpIelOqUgfKCzdWsETVJGMyrajbXP=json.loads(BhpIelOqUgfKCzdWsETVJGMyrajbXu.text)
   BhpIelOqUgfKCzdWsETVJGMyrajbci=BhpIelOqUgfKCzdWsETVJGMyrajbXP['list']
   for BhpIelOqUgfKCzdWsETVJGMyrajbxc in BhpIelOqUgfKCzdWsETVJGMyrajbci:
    BhpIelOqUgfKCzdWsETVJGMyrajbcX=''
    for BhpIelOqUgfKCzdWsETVJGMyrajbcx in BhpIelOqUgfKCzdWsETVJGMyrajbxc['list']:
     if BhpIelOqUgfKCzdWsETVJGMyrajbcX:BhpIelOqUgfKCzdWsETVJGMyrajbcX+='\n'
     BhpIelOqUgfKCzdWsETVJGMyrajbcX+=BhpIelOqUgfKCzdWsETVJGMyrajbiR.Get_ChangeText(BhpIelOqUgfKCzdWsETVJGMyrajbcx['title'])+'\n'
     BhpIelOqUgfKCzdWsETVJGMyrajbcX+=' [%s ~ %s]'%(BhpIelOqUgfKCzdWsETVJGMyrajbcx['starttime'][-5:],BhpIelOqUgfKCzdWsETVJGMyrajbcx['endtime'][-5:])+'\n'
    BhpIelOqUgfKCzdWsETVJGMyrajbtA[BhpIelOqUgfKCzdWsETVJGMyrajbxc['channelid']]=BhpIelOqUgfKCzdWsETVJGMyrajbcX
  except BhpIelOqUgfKCzdWsETVJGMyrajbkL as exception:
   BhpIelOqUgfKCzdWsETVJGMyrajbki(exception)
  return BhpIelOqUgfKCzdWsETVJGMyrajbtA
 def Get_LiveChannel_List(BhpIelOqUgfKCzdWsETVJGMyrajbiR,genre,BhpIelOqUgfKCzdWsETVJGMyrajbxX):
  BhpIelOqUgfKCzdWsETVJGMyrajbxo=[]
  (BhpIelOqUgfKCzdWsETVJGMyrajbXw,BhpIelOqUgfKCzdWsETVJGMyrajbiu)=BhpIelOqUgfKCzdWsETVJGMyrajbiR.Baseapi_Parse(BhpIelOqUgfKCzdWsETVJGMyrajbxX)
  if BhpIelOqUgfKCzdWsETVJGMyrajbXw=='':return BhpIelOqUgfKCzdWsETVJGMyrajbxo
  BhpIelOqUgfKCzdWsETVJGMyrajbct=BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetEPGList(genre)
  try:
   BhpIelOqUgfKCzdWsETVJGMyrajbiu.update(BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetDefaultParams())
   BhpIelOqUgfKCzdWsETVJGMyrajbiu['genre']=genre
   BhpIelOqUgfKCzdWsETVJGMyrajbXu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.callRequestCookies('Get',BhpIelOqUgfKCzdWsETVJGMyrajbXw,payload=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,params=BhpIelOqUgfKCzdWsETVJGMyrajbiu,headers=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,cookies=BhpIelOqUgfKCzdWsETVJGMyrajbmQ)
   BhpIelOqUgfKCzdWsETVJGMyrajbXP=json.loads(BhpIelOqUgfKCzdWsETVJGMyrajbXu.text)
   if not('celllist' in BhpIelOqUgfKCzdWsETVJGMyrajbXP['cell_toplist']):return[]
   BhpIelOqUgfKCzdWsETVJGMyrajbxt=BhpIelOqUgfKCzdWsETVJGMyrajbXP['cell_toplist']['celllist']
   for BhpIelOqUgfKCzdWsETVJGMyrajbxc in BhpIelOqUgfKCzdWsETVJGMyrajbxt:
    BhpIelOqUgfKCzdWsETVJGMyrajbtX=BhpIelOqUgfKCzdWsETVJGMyrajbxc['contentid']
    if BhpIelOqUgfKCzdWsETVJGMyrajbtX in BhpIelOqUgfKCzdWsETVJGMyrajbct:
     BhpIelOqUgfKCzdWsETVJGMyrajbcR=BhpIelOqUgfKCzdWsETVJGMyrajbct[BhpIelOqUgfKCzdWsETVJGMyrajbtX]
    else:
     BhpIelOqUgfKCzdWsETVJGMyrajbcR=''
    BhpIelOqUgfKCzdWsETVJGMyrajbxR={'studio':BhpIelOqUgfKCzdWsETVJGMyrajbxc['title_list'][0]['text'],'tvshowtitle':BhpIelOqUgfKCzdWsETVJGMyrajbiR.Get_ChangeText(BhpIelOqUgfKCzdWsETVJGMyrajbxc['title_list'][1]['text']),'channelid':BhpIelOqUgfKCzdWsETVJGMyrajbtX,'age':BhpIelOqUgfKCzdWsETVJGMyrajbxc['age'],'thumbnail':'https://%s'%BhpIelOqUgfKCzdWsETVJGMyrajbxc.get('thumbnail'),'epg':BhpIelOqUgfKCzdWsETVJGMyrajbcR}
    BhpIelOqUgfKCzdWsETVJGMyrajbxo.append(BhpIelOqUgfKCzdWsETVJGMyrajbxR)
  except BhpIelOqUgfKCzdWsETVJGMyrajbkL as exception:
   BhpIelOqUgfKCzdWsETVJGMyrajbki(exception)
   return[]
  return BhpIelOqUgfKCzdWsETVJGMyrajbxo
 def Get_Search_List(BhpIelOqUgfKCzdWsETVJGMyrajbiR,search_key,sType,page_int,exclusion21=BhpIelOqUgfKCzdWsETVJGMyrajbkx):
  BhpIelOqUgfKCzdWsETVJGMyrajbcm=[]
  BhpIelOqUgfKCzdWsETVJGMyrajbxv=BhpIelOqUgfKCzdWsETVJGMyrajbxD=1
  BhpIelOqUgfKCzdWsETVJGMyrajbxw=BhpIelOqUgfKCzdWsETVJGMyrajbkx
  try:
   BhpIelOqUgfKCzdWsETVJGMyrajbXw=BhpIelOqUgfKCzdWsETVJGMyrajbiR.API_DOMAIN+'/fz/search/band.js'
   BhpIelOqUgfKCzdWsETVJGMyrajbiu={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':BhpIelOqUgfKCzdWsETVJGMyrajbkX((page_int-1)*BhpIelOqUgfKCzdWsETVJGMyrajbiR.SEARCH_LIMIT),'limit':BhpIelOqUgfKCzdWsETVJGMyrajbiR.SEARCH_LIMIT,'orderby':'score','mtype':'svod',}
   BhpIelOqUgfKCzdWsETVJGMyrajbiu.update(BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetDefaultParams())
   BhpIelOqUgfKCzdWsETVJGMyrajbXu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.callRequestCookies('Get',BhpIelOqUgfKCzdWsETVJGMyrajbXw,payload=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,params=BhpIelOqUgfKCzdWsETVJGMyrajbiu,headers=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,cookies=BhpIelOqUgfKCzdWsETVJGMyrajbmQ)
   BhpIelOqUgfKCzdWsETVJGMyrajbtx=json.loads(BhpIelOqUgfKCzdWsETVJGMyrajbXu.text)
   if not('celllist' in BhpIelOqUgfKCzdWsETVJGMyrajbtx['band']):return BhpIelOqUgfKCzdWsETVJGMyrajbcm,BhpIelOqUgfKCzdWsETVJGMyrajbxw
   BhpIelOqUgfKCzdWsETVJGMyrajbxt=BhpIelOqUgfKCzdWsETVJGMyrajbtx['band']['celllist']
   for BhpIelOqUgfKCzdWsETVJGMyrajbxc in BhpIelOqUgfKCzdWsETVJGMyrajbxt:
    BhpIelOqUgfKCzdWsETVJGMyrajbxN =BhpIelOqUgfKCzdWsETVJGMyrajbxc['event_list'][1]['url']
    BhpIelOqUgfKCzdWsETVJGMyrajbxu=urllib.parse.urlsplit(BhpIelOqUgfKCzdWsETVJGMyrajbxN).query
    BhpIelOqUgfKCzdWsETVJGMyrajbxP=BhpIelOqUgfKCzdWsETVJGMyrajbxu[0:BhpIelOqUgfKCzdWsETVJGMyrajbxu.find('=')]
    BhpIelOqUgfKCzdWsETVJGMyrajbxY=BhpIelOqUgfKCzdWsETVJGMyrajbkH(urllib.parse.parse_qsl(BhpIelOqUgfKCzdWsETVJGMyrajbxu))
    BhpIelOqUgfKCzdWsETVJGMyrajbxF=BhpIelOqUgfKCzdWsETVJGMyrajbxY.get(BhpIelOqUgfKCzdWsETVJGMyrajbxP)
    BhpIelOqUgfKCzdWsETVJGMyrajbxR={'title':BhpIelOqUgfKCzdWsETVJGMyrajbxc['title_list'][0]['text'],'age':BhpIelOqUgfKCzdWsETVJGMyrajbxc['age'],'thumbnail':'https://%s'%BhpIelOqUgfKCzdWsETVJGMyrajbxc.get('thumbnail'),'videoid':BhpIelOqUgfKCzdWsETVJGMyrajbxF,'vidtype':BhpIelOqUgfKCzdWsETVJGMyrajbxP,}
    BhpIelOqUgfKCzdWsETVJGMyrajbck=BhpIelOqUgfKCzdWsETVJGMyrajbkx
    for BhpIelOqUgfKCzdWsETVJGMyrajbcL in BhpIelOqUgfKCzdWsETVJGMyrajbxc['bottom_taglist']:
     if BhpIelOqUgfKCzdWsETVJGMyrajbcL=='won':
      BhpIelOqUgfKCzdWsETVJGMyrajbck=BhpIelOqUgfKCzdWsETVJGMyrajbkc
      break
    if BhpIelOqUgfKCzdWsETVJGMyrajbck==BhpIelOqUgfKCzdWsETVJGMyrajbkc: 
     BhpIelOqUgfKCzdWsETVJGMyrajbxR['title']=BhpIelOqUgfKCzdWsETVJGMyrajbxR['title']+' [개별구매]'
    if exclusion21==BhpIelOqUgfKCzdWsETVJGMyrajbkx or BhpIelOqUgfKCzdWsETVJGMyrajbxc.get('age')!='21':
     BhpIelOqUgfKCzdWsETVJGMyrajbcm.append(BhpIelOqUgfKCzdWsETVJGMyrajbxR)
   BhpIelOqUgfKCzdWsETVJGMyrajbxv=BhpIelOqUgfKCzdWsETVJGMyrajbkn(BhpIelOqUgfKCzdWsETVJGMyrajbtx['band']['pagecount'])
   if BhpIelOqUgfKCzdWsETVJGMyrajbtx['band']['count']:BhpIelOqUgfKCzdWsETVJGMyrajbxD =BhpIelOqUgfKCzdWsETVJGMyrajbkn(BhpIelOqUgfKCzdWsETVJGMyrajbtx['band']['count'])
   else:BhpIelOqUgfKCzdWsETVJGMyrajbxD=BhpIelOqUgfKCzdWsETVJGMyrajbiR.LIST_LIMIT
   BhpIelOqUgfKCzdWsETVJGMyrajbxw=BhpIelOqUgfKCzdWsETVJGMyrajbxv>BhpIelOqUgfKCzdWsETVJGMyrajbxD
  except BhpIelOqUgfKCzdWsETVJGMyrajbkL as exception:
   BhpIelOqUgfKCzdWsETVJGMyrajbki(exception)
  return BhpIelOqUgfKCzdWsETVJGMyrajbcm,BhpIelOqUgfKCzdWsETVJGMyrajbxw 
 def GetSecureToken(BhpIelOqUgfKCzdWsETVJGMyrajbiR):
  BhpIelOqUgfKCzdWsETVJGMyrajbXw=BhpIelOqUgfKCzdWsETVJGMyrajbiR.API_DOMAIN+'/ip'
  BhpIelOqUgfKCzdWsETVJGMyrajbiu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetDefaultParams()
  BhpIelOqUgfKCzdWsETVJGMyrajbXu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.callRequestCookies('Get',BhpIelOqUgfKCzdWsETVJGMyrajbXw,payload=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,params=BhpIelOqUgfKCzdWsETVJGMyrajbiu,headers=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,cookies=BhpIelOqUgfKCzdWsETVJGMyrajbmQ)
  BhpIelOqUgfKCzdWsETVJGMyrajbXP=json.loads(BhpIelOqUgfKCzdWsETVJGMyrajbXu.text)
  return BhpIelOqUgfKCzdWsETVJGMyrajbXP['securetoken']
 def Wavve_Parse_m3u8(BhpIelOqUgfKCzdWsETVJGMyrajbiR,BhpIelOqUgfKCzdWsETVJGMyrajbRH):
  try:
   BhpIelOqUgfKCzdWsETVJGMyrajbXn={'user-agent':'pooqV2/5.6.0 (Linux;Android 10) ExoPlayerLib/2.13.3'}
   BhpIelOqUgfKCzdWsETVJGMyrajbXu=requests.get(url=BhpIelOqUgfKCzdWsETVJGMyrajbRH['stream_url'],headers=BhpIelOqUgfKCzdWsETVJGMyrajbXn,cookies=BhpIelOqUgfKCzdWsETVJGMyrajbRH['stream_cookie'])
   BhpIelOqUgfKCzdWsETVJGMyrajbcH=BhpIelOqUgfKCzdWsETVJGMyrajbXu.content.decode('utf-8')
   if '#EXTM3U' not in BhpIelOqUgfKCzdWsETVJGMyrajbcH:
    return BhpIelOqUgfKCzdWsETVJGMyrajbkx
   if '#EXT-X-STREAM-INF' not in BhpIelOqUgfKCzdWsETVJGMyrajbcH: 
    return BhpIelOqUgfKCzdWsETVJGMyrajbkx
   BhpIelOqUgfKCzdWsETVJGMyrajbcn=0
   for BhpIelOqUgfKCzdWsETVJGMyrajbco in BhpIelOqUgfKCzdWsETVJGMyrajbcH.splitlines():
    if BhpIelOqUgfKCzdWsETVJGMyrajbco.startswith('#EXT-X-STREAM-INF'):
     BhpIelOqUgfKCzdWsETVJGMyrajbcv=BhpIelOqUgfKCzdWsETVJGMyrajbiR.MediaLine_Parse(BhpIelOqUgfKCzdWsETVJGMyrajbco,'#EXT-X-STREAM-INF')
     if BhpIelOqUgfKCzdWsETVJGMyrajbcn<BhpIelOqUgfKCzdWsETVJGMyrajbkn(BhpIelOqUgfKCzdWsETVJGMyrajbcv.get('BANDWIDTH')):
      BhpIelOqUgfKCzdWsETVJGMyrajbcn=BhpIelOqUgfKCzdWsETVJGMyrajbkn(BhpIelOqUgfKCzdWsETVJGMyrajbcv.get('BANDWIDTH'))
   BhpIelOqUgfKCzdWsETVJGMyrajbcw=[]
   BhpIelOqUgfKCzdWsETVJGMyrajbcN=BhpIelOqUgfKCzdWsETVJGMyrajbkx
   for BhpIelOqUgfKCzdWsETVJGMyrajbco in BhpIelOqUgfKCzdWsETVJGMyrajbcH.splitlines():
    if BhpIelOqUgfKCzdWsETVJGMyrajbcN==BhpIelOqUgfKCzdWsETVJGMyrajbkc:
     BhpIelOqUgfKCzdWsETVJGMyrajbcN=BhpIelOqUgfKCzdWsETVJGMyrajbkx
     continue
    if BhpIelOqUgfKCzdWsETVJGMyrajbco.startswith('#EXT-X-STREAM-INF'):
     BhpIelOqUgfKCzdWsETVJGMyrajbcv=BhpIelOqUgfKCzdWsETVJGMyrajbiR.MediaLine_Parse(BhpIelOqUgfKCzdWsETVJGMyrajbco,'#EXT-X-STREAM-INF')
     if BhpIelOqUgfKCzdWsETVJGMyrajbcn!=BhpIelOqUgfKCzdWsETVJGMyrajbkn(BhpIelOqUgfKCzdWsETVJGMyrajbcv.get('BANDWIDTH')):
      BhpIelOqUgfKCzdWsETVJGMyrajbcN=BhpIelOqUgfKCzdWsETVJGMyrajbkc
      continue
    BhpIelOqUgfKCzdWsETVJGMyrajbcw.append(BhpIelOqUgfKCzdWsETVJGMyrajbco)
  except BhpIelOqUgfKCzdWsETVJGMyrajbkL as exception:
   BhpIelOqUgfKCzdWsETVJGMyrajbki(exception)
   return BhpIelOqUgfKCzdWsETVJGMyrajbkx
  BhpIelOqUgfKCzdWsETVJGMyrajbcu='\n'.join(BhpIelOqUgfKCzdWsETVJGMyrajbcw)
  BhpIelOqUgfKCzdWsETVJGMyrajbiR.TextFile_Save(BhpIelOqUgfKCzdWsETVJGMyrajbiR.WV_STREAM_FILENAME,BhpIelOqUgfKCzdWsETVJGMyrajbcu)
  return BhpIelOqUgfKCzdWsETVJGMyrajbkc
 def Wavve_Parse_mpd(BhpIelOqUgfKCzdWsETVJGMyrajbiR,BhpIelOqUgfKCzdWsETVJGMyrajbRH):
  BhpIelOqUgfKCzdWsETVJGMyrajbXn={'user-agent':'pooqV2/5.6.0 (Linux;Android 10) ExoPlayerLib/2.13.3'}
  BhpIelOqUgfKCzdWsETVJGMyrajbXu=requests.get(url=BhpIelOqUgfKCzdWsETVJGMyrajbRH['stream_url'],headers=BhpIelOqUgfKCzdWsETVJGMyrajbXn,cookies=BhpIelOqUgfKCzdWsETVJGMyrajbRH['stream_cookie'])
  BhpIelOqUgfKCzdWsETVJGMyrajbcP=BhpIelOqUgfKCzdWsETVJGMyrajbXu.content.decode('utf-8')
  BhpIelOqUgfKCzdWsETVJGMyrajbcF =ET.ElementTree(ET.fromstring(BhpIelOqUgfKCzdWsETVJGMyrajbcP))
  BhpIelOqUgfKCzdWsETVJGMyrajbcD =BhpIelOqUgfKCzdWsETVJGMyrajbcF.getroot()
  BhpIelOqUgfKCzdWsETVJGMyrajbcS=re.match(r'\{.*\}',BhpIelOqUgfKCzdWsETVJGMyrajbcD.tag)[0] 
  BhpIelOqUgfKCzdWsETVJGMyrajbcA=BhpIelOqUgfKCzdWsETVJGMyrajbkH([node for _,node in ET.iterparse(io.StringIO(BhpIelOqUgfKCzdWsETVJGMyrajbcP),events=['start-ns'])])
  for BhpIelOqUgfKCzdWsETVJGMyrajbXL,BhpIelOqUgfKCzdWsETVJGMyrajbRL in BhpIelOqUgfKCzdWsETVJGMyrajbcA.items():
   ET.register_namespace(BhpIelOqUgfKCzdWsETVJGMyrajbXL,BhpIelOqUgfKCzdWsETVJGMyrajbRL)
  BhpIelOqUgfKCzdWsETVJGMyrajbcQ=BhpIelOqUgfKCzdWsETVJGMyrajbcD.find(BhpIelOqUgfKCzdWsETVJGMyrajbcS+'Period')
  for BhpIelOqUgfKCzdWsETVJGMyrajbcY in BhpIelOqUgfKCzdWsETVJGMyrajbcQ.findall(BhpIelOqUgfKCzdWsETVJGMyrajbcS+'AdaptationSet'):
   if BhpIelOqUgfKCzdWsETVJGMyrajbcY.attrib.get('mimeType')=='video/mp4':
    BhpIelOqUgfKCzdWsETVJGMyrajbRi=0
    for BhpIelOqUgfKCzdWsETVJGMyrajbRX in BhpIelOqUgfKCzdWsETVJGMyrajbcY.findall(BhpIelOqUgfKCzdWsETVJGMyrajbcS+'Representation'):
     BhpIelOqUgfKCzdWsETVJGMyrajbRx=BhpIelOqUgfKCzdWsETVJGMyrajbkn(BhpIelOqUgfKCzdWsETVJGMyrajbRX.attrib.get('bandwidth'))
     if BhpIelOqUgfKCzdWsETVJGMyrajbRi<BhpIelOqUgfKCzdWsETVJGMyrajbRx:BhpIelOqUgfKCzdWsETVJGMyrajbRi=BhpIelOqUgfKCzdWsETVJGMyrajbRx
    for BhpIelOqUgfKCzdWsETVJGMyrajbRX in BhpIelOqUgfKCzdWsETVJGMyrajbcY.findall(BhpIelOqUgfKCzdWsETVJGMyrajbcS+'Representation'):
     if BhpIelOqUgfKCzdWsETVJGMyrajbRi>BhpIelOqUgfKCzdWsETVJGMyrajbkn(BhpIelOqUgfKCzdWsETVJGMyrajbRX.attrib.get('bandwidth')):
      BhpIelOqUgfKCzdWsETVJGMyrajbcY.remove(BhpIelOqUgfKCzdWsETVJGMyrajbRX)
   elif BhpIelOqUgfKCzdWsETVJGMyrajbcY.attrib.get('mimeType')=='audio/mp4':
    BhpIelOqUgfKCzdWsETVJGMyrajbRi=0
    for BhpIelOqUgfKCzdWsETVJGMyrajbRX in BhpIelOqUgfKCzdWsETVJGMyrajbcY.findall(BhpIelOqUgfKCzdWsETVJGMyrajbcS+'Representation'):
     BhpIelOqUgfKCzdWsETVJGMyrajbRx=BhpIelOqUgfKCzdWsETVJGMyrajbkn(BhpIelOqUgfKCzdWsETVJGMyrajbRX.attrib.get('bandwidth'))
     if BhpIelOqUgfKCzdWsETVJGMyrajbRi<BhpIelOqUgfKCzdWsETVJGMyrajbRx:BhpIelOqUgfKCzdWsETVJGMyrajbRi=BhpIelOqUgfKCzdWsETVJGMyrajbRx
    for BhpIelOqUgfKCzdWsETVJGMyrajbRX in BhpIelOqUgfKCzdWsETVJGMyrajbcY.findall(BhpIelOqUgfKCzdWsETVJGMyrajbcS+'Representation'):
     if BhpIelOqUgfKCzdWsETVJGMyrajbRi>BhpIelOqUgfKCzdWsETVJGMyrajbkn(BhpIelOqUgfKCzdWsETVJGMyrajbRX.attrib.get('bandwidth')):
      BhpIelOqUgfKCzdWsETVJGMyrajbcY.remove(BhpIelOqUgfKCzdWsETVJGMyrajbRX)
   else:
    continue
  BhpIelOqUgfKCzdWsETVJGMyrajbRt=ET.tostring(BhpIelOqUgfKCzdWsETVJGMyrajbcD).decode('utf-8')
  BhpIelOqUgfKCzdWsETVJGMyrajbRc='<?xml version="1.0" encoding="UTF-8"?>\n'
  BhpIelOqUgfKCzdWsETVJGMyrajbiR.TextFile_Save(BhpIelOqUgfKCzdWsETVJGMyrajbiR.WV_STREAM_FILENAME,BhpIelOqUgfKCzdWsETVJGMyrajbRc+BhpIelOqUgfKCzdWsETVJGMyrajbRt)
  return BhpIelOqUgfKCzdWsETVJGMyrajbkc
 def MediaLine_Parse(BhpIelOqUgfKCzdWsETVJGMyrajbiR,BhpIelOqUgfKCzdWsETVJGMyrajbco,prefix):
  BhpIelOqUgfKCzdWsETVJGMyrajbcv={}
  for BhpIelOqUgfKCzdWsETVJGMyrajbRm in BhpIelOqUgfKCzdWsETVJGMyrajbic.split(BhpIelOqUgfKCzdWsETVJGMyrajbco.replace(prefix+':',''))[1::2]:
   BhpIelOqUgfKCzdWsETVJGMyrajbRk,BhpIelOqUgfKCzdWsETVJGMyrajbRL=BhpIelOqUgfKCzdWsETVJGMyrajbRm.split('=',1)
   BhpIelOqUgfKCzdWsETVJGMyrajbcv[BhpIelOqUgfKCzdWsETVJGMyrajbRk.upper()]=BhpIelOqUgfKCzdWsETVJGMyrajbRL.replace('"','').strip()
  return BhpIelOqUgfKCzdWsETVJGMyrajbcv
 def GetStreamingURL(BhpIelOqUgfKCzdWsETVJGMyrajbiR,mode,BhpIelOqUgfKCzdWsETVJGMyrajbtX,quality_int,pvrmode='-',playOption={}):
  BhpIelOqUgfKCzdWsETVJGMyrajbRH ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  BhpIelOqUgfKCzdWsETVJGMyrajbRn=[]
  if mode=='LIVE':
   BhpIelOqUgfKCzdWsETVJGMyrajbXw =BhpIelOqUgfKCzdWsETVJGMyrajbiR.API_DOMAIN+'/live/channels/'+BhpIelOqUgfKCzdWsETVJGMyrajbtX
   BhpIelOqUgfKCzdWsETVJGMyrajbRo='live'
  elif mode=='VOD':
   BhpIelOqUgfKCzdWsETVJGMyrajbXw =BhpIelOqUgfKCzdWsETVJGMyrajbiR.API_DOMAIN+'/fz/vod/contents-detail/'+BhpIelOqUgfKCzdWsETVJGMyrajbtX 
   BhpIelOqUgfKCzdWsETVJGMyrajbRo='vod'
  elif mode=='MOVIE':
   BhpIelOqUgfKCzdWsETVJGMyrajbXw =BhpIelOqUgfKCzdWsETVJGMyrajbiR.API_DOMAIN+'/fz/movie/contents/'+BhpIelOqUgfKCzdWsETVJGMyrajbtX
   BhpIelOqUgfKCzdWsETVJGMyrajbRo='movie'
  BhpIelOqUgfKCzdWsETVJGMyrajbRv={'hdr':'sdr','uhd':'-',}
  try:
   BhpIelOqUgfKCzdWsETVJGMyrajbiu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetDefaultParams()
   BhpIelOqUgfKCzdWsETVJGMyrajbXu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.callRequestCookies('Get',BhpIelOqUgfKCzdWsETVJGMyrajbXw,payload=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,params=BhpIelOqUgfKCzdWsETVJGMyrajbiu,headers=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,cookies=BhpIelOqUgfKCzdWsETVJGMyrajbmQ)
   BhpIelOqUgfKCzdWsETVJGMyrajbXP=json.loads(BhpIelOqUgfKCzdWsETVJGMyrajbXu.text)
   BhpIelOqUgfKCzdWsETVJGMyrajbRw=BhpIelOqUgfKCzdWsETVJGMyrajbXP['qualities']['list']
   if BhpIelOqUgfKCzdWsETVJGMyrajbRw==BhpIelOqUgfKCzdWsETVJGMyrajbmQ:return BhpIelOqUgfKCzdWsETVJGMyrajbRH
   for BhpIelOqUgfKCzdWsETVJGMyrajbRN in BhpIelOqUgfKCzdWsETVJGMyrajbRw:
    BhpIelOqUgfKCzdWsETVJGMyrajbRn.append(BhpIelOqUgfKCzdWsETVJGMyrajbkn(BhpIelOqUgfKCzdWsETVJGMyrajbRN.get('id').rstrip('p')))
   if 'drms' in BhpIelOqUgfKCzdWsETVJGMyrajbXP:
    if BhpIelOqUgfKCzdWsETVJGMyrajbXP['drms']:
     BhpIelOqUgfKCzdWsETVJGMyrajbRH['stream_action']='dash' 
   if playOption.get('enable_hdr'):
    if 'mediatypes' in BhpIelOqUgfKCzdWsETVJGMyrajbXP.get('qualities'):
     for BhpIelOqUgfKCzdWsETVJGMyrajbRu in BhpIelOqUgfKCzdWsETVJGMyrajbXP.get('qualities').get('mediatypes'):
      if BhpIelOqUgfKCzdWsETVJGMyrajbRu=='HDR10':
       BhpIelOqUgfKCzdWsETVJGMyrajbRv['hdr']='hdr'
       BhpIelOqUgfKCzdWsETVJGMyrajbRH['stream_action']='dash'
       break
   if playOption.get('enable_uhd'):
    for BhpIelOqUgfKCzdWsETVJGMyrajbRu in BhpIelOqUgfKCzdWsETVJGMyrajbXP.get('qualities').get('list'):
     if BhpIelOqUgfKCzdWsETVJGMyrajbRu.get('name')=='UHD':
      BhpIelOqUgfKCzdWsETVJGMyrajbRv['uhd']='uhd'
      break
  except BhpIelOqUgfKCzdWsETVJGMyrajbkL as exception:
   BhpIelOqUgfKCzdWsETVJGMyrajbki(exception)
   return BhpIelOqUgfKCzdWsETVJGMyrajbRH
  BhpIelOqUgfKCzdWsETVJGMyrajbki('stream_action : '+BhpIelOqUgfKCzdWsETVJGMyrajbRH['stream_action'])
  try:
   BhpIelOqUgfKCzdWsETVJGMyrajbRP=BhpIelOqUgfKCzdWsETVJGMyrajbiR.CheckQuality(quality_int,BhpIelOqUgfKCzdWsETVJGMyrajbRn)
   BhpIelOqUgfKCzdWsETVJGMyrajbki(BhpIelOqUgfKCzdWsETVJGMyrajbRP)
   if BhpIelOqUgfKCzdWsETVJGMyrajbRP<1080:
    BhpIelOqUgfKCzdWsETVJGMyrajbRv['uhd']='-'
    BhpIelOqUgfKCzdWsETVJGMyrajbRv['hdr']='sdr'
   if BhpIelOqUgfKCzdWsETVJGMyrajbRv['uhd']=='uhd':BhpIelOqUgfKCzdWsETVJGMyrajbRP=2160 
   BhpIelOqUgfKCzdWsETVJGMyrajbRF=BhpIelOqUgfKCzdWsETVJGMyrajbkX(BhpIelOqUgfKCzdWsETVJGMyrajbRP)+'p'
   BhpIelOqUgfKCzdWsETVJGMyrajbki(BhpIelOqUgfKCzdWsETVJGMyrajbRF)
   BhpIelOqUgfKCzdWsETVJGMyrajbXw='https://delivery.wavve.com/v1/streaming/{}'.format(BhpIelOqUgfKCzdWsETVJGMyrajbRo)
   if BhpIelOqUgfKCzdWsETVJGMyrajbRv['hdr']=='hdr' or BhpIelOqUgfKCzdWsETVJGMyrajbRv['uhd']=='uhd':
    BhpIelOqUgfKCzdWsETVJGMyrajbiu={'service':'wavve','contentid':BhpIelOqUgfKCzdWsETVJGMyrajbtX,'audioChannel':'2ch','contenttype':BhpIelOqUgfKCzdWsETVJGMyrajbRo,'hdr':'HDR10','videocodec':'HEVC','audiocodec':'AAC','issurround':'y','format':'normal','withinsubtitle':'n','action':BhpIelOqUgfKCzdWsETVJGMyrajbRH['stream_action'],'protocol':BhpIelOqUgfKCzdWsETVJGMyrajbRH['stream_action'],'quality':BhpIelOqUgfKCzdWsETVJGMyrajbRF,'modelid':'SHIELD Android TV','guid':BhpIelOqUgfKCzdWsETVJGMyrajbiR.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n',}
    BhpIelOqUgfKCzdWsETVJGMyrajbiu.update(BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetDefaultParams_AND())
   else:
    BhpIelOqUgfKCzdWsETVJGMyrajbiu={'service':'wavve','contentid':BhpIelOqUgfKCzdWsETVJGMyrajbtX,'audioChannel':'2ch','contenttype':BhpIelOqUgfKCzdWsETVJGMyrajbRo,'hdr':'sdr','videocodec':'avc','audiocodec':'aac','issurround':'n','format':'normal','withinsubtitle':'n','action':BhpIelOqUgfKCzdWsETVJGMyrajbRH['stream_action'],'protocol':BhpIelOqUgfKCzdWsETVJGMyrajbRH['stream_action'],'quality':BhpIelOqUgfKCzdWsETVJGMyrajbRF,'deviceModelId':'Windows 10','guid':BhpIelOqUgfKCzdWsETVJGMyrajbiR.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n',}
    '''
    params = {'contentid' : contentid, 'contenttype' : contenttype, 'quality' : quality_param, ###### if login=False : 체크 미비 (auto, 1080p) ###### 'deviceModelId' : 'Windows 10', 'guid' : self.WV['cookies']['uuid'], # self.GetGUID(guidType=2), 'lastplayid' : '', #self.guid 'authtype' : 'cookie', 'isabr' : 'y', 'ishevc' : 'n', 'action' : url_info['stream_action'], # 기본 hls / DRM dash ##### 'protocol' : url_info['stream_action'], # hls ? 확인필요 'hdr' : 'sdr', # hdr 'videocodec' : 'avc', 'audiocodec' : 'aac', 'issurround' : 'n', 'format' : 'normal', 'withinsubtitle' : 'n', }
    '''    
    BhpIelOqUgfKCzdWsETVJGMyrajbiu.update(BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetDefaultParams())
   BhpIelOqUgfKCzdWsETVJGMyrajbXn={'wavve-credential':BhpIelOqUgfKCzdWsETVJGMyrajbiR.WV['cookies']['credential'],}
   BhpIelOqUgfKCzdWsETVJGMyrajbXu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.callRequestCookies('Get',BhpIelOqUgfKCzdWsETVJGMyrajbXw,payload=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,params=BhpIelOqUgfKCzdWsETVJGMyrajbiu,headers=BhpIelOqUgfKCzdWsETVJGMyrajbXn,cookies=BhpIelOqUgfKCzdWsETVJGMyrajbmQ)
   BhpIelOqUgfKCzdWsETVJGMyrajbXP=json.loads(BhpIelOqUgfKCzdWsETVJGMyrajbXu.text)
   BhpIelOqUgfKCzdWsETVJGMyrajbRH['stream_url']=BhpIelOqUgfKCzdWsETVJGMyrajbXP['playurl']
   if BhpIelOqUgfKCzdWsETVJGMyrajbRH['stream_url']==BhpIelOqUgfKCzdWsETVJGMyrajbmQ:return BhpIelOqUgfKCzdWsETVJGMyrajbRH
   BhpIelOqUgfKCzdWsETVJGMyrajbRH['stream_cookie']=BhpIelOqUgfKCzdWsETVJGMyrajbiR.make_str_ToCookie(BhpIelOqUgfKCzdWsETVJGMyrajbXP['awscookie'])
   BhpIelOqUgfKCzdWsETVJGMyrajbRH['stream_drm'] =BhpIelOqUgfKCzdWsETVJGMyrajbXP['drm']
   if 'previewmsg' in BhpIelOqUgfKCzdWsETVJGMyrajbXP['preview']:BhpIelOqUgfKCzdWsETVJGMyrajbRH['stream_preview']=BhpIelOqUgfKCzdWsETVJGMyrajbXP['preview']['previewmsg']
   if 'subtitles' in BhpIelOqUgfKCzdWsETVJGMyrajbXP:
    for BhpIelOqUgfKCzdWsETVJGMyrajbRD in BhpIelOqUgfKCzdWsETVJGMyrajbXP['subtitles']:
     if BhpIelOqUgfKCzdWsETVJGMyrajbRD.get('languagecode')=='ko':
      BhpIelOqUgfKCzdWsETVJGMyrajbRH['stream_vtt']=BhpIelOqUgfKCzdWsETVJGMyrajbRD.get('url')
      break
    if BhpIelOqUgfKCzdWsETVJGMyrajbRH['stream_vtt']=='':
     for BhpIelOqUgfKCzdWsETVJGMyrajbRD in BhpIelOqUgfKCzdWsETVJGMyrajbXP['subtitles']:
      if BhpIelOqUgfKCzdWsETVJGMyrajbRD.get('languagecode')=='ko_cc':
       BhpIelOqUgfKCzdWsETVJGMyrajbRH['stream_vtt']=BhpIelOqUgfKCzdWsETVJGMyrajbRD.get('url')
       break
   BhpIelOqUgfKCzdWsETVJGMyrajbRH['playParam']=BhpIelOqUgfKCzdWsETVJGMyrajbRv 
  except BhpIelOqUgfKCzdWsETVJGMyrajbkL as exception:
   BhpIelOqUgfKCzdWsETVJGMyrajbki(exception)
  return BhpIelOqUgfKCzdWsETVJGMyrajbRH 
 def GetSportsURL(BhpIelOqUgfKCzdWsETVJGMyrajbiR,BhpIelOqUgfKCzdWsETVJGMyrajbtX,quality_int):
  BhpIelOqUgfKCzdWsETVJGMyrajbRH ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  BhpIelOqUgfKCzdWsETVJGMyrajbRn=[]
  try:
   BhpIelOqUgfKCzdWsETVJGMyrajbXw=BhpIelOqUgfKCzdWsETVJGMyrajbiR.API_DOMAIN+'/streaming/other'
   BhpIelOqUgfKCzdWsETVJGMyrajbiu={'contentid':BhpIelOqUgfKCzdWsETVJGMyrajbtX,'contenttype':'live','action':BhpIelOqUgfKCzdWsETVJGMyrajbRH['stream_action'],'quality':BhpIelOqUgfKCzdWsETVJGMyrajbkX(quality_int)+'p','deviceModelId':'Windows 10','guid':BhpIelOqUgfKCzdWsETVJGMyrajbiR.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n',}
   BhpIelOqUgfKCzdWsETVJGMyrajbiu.update(BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetDefaultParams())
   BhpIelOqUgfKCzdWsETVJGMyrajbXu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.callRequestCookies('Get',BhpIelOqUgfKCzdWsETVJGMyrajbXw,payload=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,params=BhpIelOqUgfKCzdWsETVJGMyrajbiu,headers=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,cookies=BhpIelOqUgfKCzdWsETVJGMyrajbmQ)
   BhpIelOqUgfKCzdWsETVJGMyrajbXP=json.loads(BhpIelOqUgfKCzdWsETVJGMyrajbXu.text)
   BhpIelOqUgfKCzdWsETVJGMyrajbRH['stream_url']=BhpIelOqUgfKCzdWsETVJGMyrajbXP['playurl']
   if BhpIelOqUgfKCzdWsETVJGMyrajbRH['stream_url']==BhpIelOqUgfKCzdWsETVJGMyrajbmQ:return BhpIelOqUgfKCzdWsETVJGMyrajbRH
   BhpIelOqUgfKCzdWsETVJGMyrajbRH['stream_cookie']=BhpIelOqUgfKCzdWsETVJGMyrajbXP['awscookie']
  except BhpIelOqUgfKCzdWsETVJGMyrajbkL as exception:
   BhpIelOqUgfKCzdWsETVJGMyrajbki(exception)
  return BhpIelOqUgfKCzdWsETVJGMyrajbRH
 def make_viewdate(BhpIelOqUgfKCzdWsETVJGMyrajbiR):
  BhpIelOqUgfKCzdWsETVJGMyrajbRS =BhpIelOqUgfKCzdWsETVJGMyrajbiR.Get_Now_Datetime()
  BhpIelOqUgfKCzdWsETVJGMyrajbRA =BhpIelOqUgfKCzdWsETVJGMyrajbRS+datetime.timedelta(days=-1)
  BhpIelOqUgfKCzdWsETVJGMyrajbRQ =BhpIelOqUgfKCzdWsETVJGMyrajbRS+datetime.timedelta(days=1)
  BhpIelOqUgfKCzdWsETVJGMyrajbRY=[BhpIelOqUgfKCzdWsETVJGMyrajbRS.strftime('%Y%m%d'),BhpIelOqUgfKCzdWsETVJGMyrajbRQ.strftime('%Y%m%d'),]
  return BhpIelOqUgfKCzdWsETVJGMyrajbRY
 def Get_Sports_Gamelist(BhpIelOqUgfKCzdWsETVJGMyrajbiR):
  BhpIelOqUgfKCzdWsETVJGMyrajbmi =BhpIelOqUgfKCzdWsETVJGMyrajbiR.make_viewdate()
  BhpIelOqUgfKCzdWsETVJGMyrajbmX=[]
  BhpIelOqUgfKCzdWsETVJGMyrajbmx =[]
  for BhpIelOqUgfKCzdWsETVJGMyrajbmt in BhpIelOqUgfKCzdWsETVJGMyrajbmi:
   BhpIelOqUgfKCzdWsETVJGMyrajbmc=BhpIelOqUgfKCzdWsETVJGMyrajbmt[:6]
   if BhpIelOqUgfKCzdWsETVJGMyrajbmc not in BhpIelOqUgfKCzdWsETVJGMyrajbmX:
    BhpIelOqUgfKCzdWsETVJGMyrajbmX.append(BhpIelOqUgfKCzdWsETVJGMyrajbmc)
  try:
   BhpIelOqUgfKCzdWsETVJGMyrajbXw='https://annexapi.wavve.com/skb/baseball/teammonthlycalendarlist'
   BhpIelOqUgfKCzdWsETVJGMyrajbiu={'IF':'IF-PORG-002','m':'getTeamCalendarListBand','response_format':'json','spo_itm_cd':'KBO','teamcd':'all','tgroup':'B','tvalue':'BC123','ver':'2.0',}
   BhpIelOqUgfKCzdWsETVJGMyrajbiu.update(BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetDefaultParams())
   for BhpIelOqUgfKCzdWsETVJGMyrajbmR in BhpIelOqUgfKCzdWsETVJGMyrajbmX:
    BhpIelOqUgfKCzdWsETVJGMyrajbiu['date']=BhpIelOqUgfKCzdWsETVJGMyrajbmR
    BhpIelOqUgfKCzdWsETVJGMyrajbXu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.callRequestCookies('Get',BhpIelOqUgfKCzdWsETVJGMyrajbXw,payload=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,params=BhpIelOqUgfKCzdWsETVJGMyrajbiu,headers=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,cookies=BhpIelOqUgfKCzdWsETVJGMyrajbmQ)
    BhpIelOqUgfKCzdWsETVJGMyrajbXP=json.loads(BhpIelOqUgfKCzdWsETVJGMyrajbXu.text)
    BhpIelOqUgfKCzdWsETVJGMyrajbxt=BhpIelOqUgfKCzdWsETVJGMyrajbXP['cell_toplist']['celllist']
    for BhpIelOqUgfKCzdWsETVJGMyrajbxc in BhpIelOqUgfKCzdWsETVJGMyrajbxt:
     BhpIelOqUgfKCzdWsETVJGMyrajbmk=BhpIelOqUgfKCzdWsETVJGMyrajbxc.get('game_date')
     BhpIelOqUgfKCzdWsETVJGMyrajbmL =BhpIelOqUgfKCzdWsETVJGMyrajbxc.get('svc_id')
     if BhpIelOqUgfKCzdWsETVJGMyrajbmL=='':continue
     if BhpIelOqUgfKCzdWsETVJGMyrajbmk in BhpIelOqUgfKCzdWsETVJGMyrajbmi:
      BhpIelOqUgfKCzdWsETVJGMyrajbmH=BhpIelOqUgfKCzdWsETVJGMyrajbxc.get('game_status') 
      BhpIelOqUgfKCzdWsETVJGMyrajbmn =BhpIelOqUgfKCzdWsETVJGMyrajbxc.get('title_list')[0].get('text')
      BhpIelOqUgfKCzdWsETVJGMyrajbmk =BhpIelOqUgfKCzdWsETVJGMyrajbmk[:4]+'-'+BhpIelOqUgfKCzdWsETVJGMyrajbmk[4:6]+'-'+BhpIelOqUgfKCzdWsETVJGMyrajbmk[-2:]
      BhpIelOqUgfKCzdWsETVJGMyrajbmo =BhpIelOqUgfKCzdWsETVJGMyrajbxc.get('game_time')
      BhpIelOqUgfKCzdWsETVJGMyrajbmo =BhpIelOqUgfKCzdWsETVJGMyrajbmo[:2]+':'+BhpIelOqUgfKCzdWsETVJGMyrajbmo[-2:]
      BhpIelOqUgfKCzdWsETVJGMyrajbxR={'game_date':BhpIelOqUgfKCzdWsETVJGMyrajbmk,'game_time':BhpIelOqUgfKCzdWsETVJGMyrajbmo,'svc_id':BhpIelOqUgfKCzdWsETVJGMyrajbmL,'away_team':BhpIelOqUgfKCzdWsETVJGMyrajbxc.get('away_team').get('team_name'),'home_team':BhpIelOqUgfKCzdWsETVJGMyrajbxc.get('home_team').get('team_name'),'game_status':BhpIelOqUgfKCzdWsETVJGMyrajbmH,'game_place':BhpIelOqUgfKCzdWsETVJGMyrajbxc.get('game_place'),}
      BhpIelOqUgfKCzdWsETVJGMyrajbmx.append(BhpIelOqUgfKCzdWsETVJGMyrajbxR)
  except BhpIelOqUgfKCzdWsETVJGMyrajbkL as exception:
   BhpIelOqUgfKCzdWsETVJGMyrajbki(exception)
   return[]
  BhpIelOqUgfKCzdWsETVJGMyrajbmv=[]
  for i in BhpIelOqUgfKCzdWsETVJGMyrajbkR(2):
   for BhpIelOqUgfKCzdWsETVJGMyrajbxc in BhpIelOqUgfKCzdWsETVJGMyrajbmx:
    if i==0 and BhpIelOqUgfKCzdWsETVJGMyrajbxc.get('game_status')=='LIVE':
     BhpIelOqUgfKCzdWsETVJGMyrajbmv.append(BhpIelOqUgfKCzdWsETVJGMyrajbxc)
    elif i==1 and BhpIelOqUgfKCzdWsETVJGMyrajbxc.get('game_status')!='LIVE':
     BhpIelOqUgfKCzdWsETVJGMyrajbmv.append(BhpIelOqUgfKCzdWsETVJGMyrajbxc)
  return BhpIelOqUgfKCzdWsETVJGMyrajbmv
 def GetBookmarkInfo(BhpIelOqUgfKCzdWsETVJGMyrajbiR,BhpIelOqUgfKCzdWsETVJGMyrajbxF,BhpIelOqUgfKCzdWsETVJGMyrajbxP,BhpIelOqUgfKCzdWsETVJGMyrajbRo):
  if BhpIelOqUgfKCzdWsETVJGMyrajbxP=='tvshow':
   if BhpIelOqUgfKCzdWsETVJGMyrajbRo=='contentid':
    BhpIelOqUgfKCzdWsETVJGMyrajbtX=BhpIelOqUgfKCzdWsETVJGMyrajbxF
    BhpIelOqUgfKCzdWsETVJGMyrajbxF =BhpIelOqUgfKCzdWsETVJGMyrajbiR.ContentidToSeasonid(BhpIelOqUgfKCzdWsETVJGMyrajbtX)
   else:
    BhpIelOqUgfKCzdWsETVJGMyrajbtX=BhpIelOqUgfKCzdWsETVJGMyrajbiR.ProgramidToContentid(BhpIelOqUgfKCzdWsETVJGMyrajbxF)
  else:
   BhpIelOqUgfKCzdWsETVJGMyrajbtX=''
  BhpIelOqUgfKCzdWsETVJGMyrajbmw={'indexinfo':{'ott':'wavve','videoid':BhpIelOqUgfKCzdWsETVJGMyrajbxF,'vidtype':BhpIelOqUgfKCzdWsETVJGMyrajbxP,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':BhpIelOqUgfKCzdWsETVJGMyrajbxP,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if BhpIelOqUgfKCzdWsETVJGMyrajbxP=='tvshow':
   BhpIelOqUgfKCzdWsETVJGMyrajbXw=BhpIelOqUgfKCzdWsETVJGMyrajbiR.API_DOMAIN+'/fz/vod/contents/'+BhpIelOqUgfKCzdWsETVJGMyrajbtX 
   BhpIelOqUgfKCzdWsETVJGMyrajbiu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetDefaultParams()
   BhpIelOqUgfKCzdWsETVJGMyrajbXu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.callRequestCookies('Get',BhpIelOqUgfKCzdWsETVJGMyrajbXw,payload=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,params=BhpIelOqUgfKCzdWsETVJGMyrajbiu,headers=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,cookies=BhpIelOqUgfKCzdWsETVJGMyrajbmQ)
   BhpIelOqUgfKCzdWsETVJGMyrajbXP=json.loads(BhpIelOqUgfKCzdWsETVJGMyrajbXu.text)
   if not('programtitle' in BhpIelOqUgfKCzdWsETVJGMyrajbXP):return{}
   BhpIelOqUgfKCzdWsETVJGMyrajbmN=BhpIelOqUgfKCzdWsETVJGMyrajbXP
   BhpIelOqUgfKCzdWsETVJGMyrajbmu=BhpIelOqUgfKCzdWsETVJGMyrajbmN.get('programtitle')
   BhpIelOqUgfKCzdWsETVJGMyrajbmw['saveinfo']['infoLabels']['title']=BhpIelOqUgfKCzdWsETVJGMyrajbmu
   if BhpIelOqUgfKCzdWsETVJGMyrajbmN.get('targetage')=='18' or BhpIelOqUgfKCzdWsETVJGMyrajbmN.get('targetage')=='19' or BhpIelOqUgfKCzdWsETVJGMyrajbmN.get('targetage')=='21':
    BhpIelOqUgfKCzdWsETVJGMyrajbmu +=u' (%s)'%(BhpIelOqUgfKCzdWsETVJGMyrajbmN.get('targetage'))
   BhpIelOqUgfKCzdWsETVJGMyrajbmw['saveinfo']['title'] =BhpIelOqUgfKCzdWsETVJGMyrajbmu
   BhpIelOqUgfKCzdWsETVJGMyrajbmw['saveinfo']['infoLabels']['mpaa'] =BhpIelOqUgfKCzdWsETVJGMyrajbmN.get('targetage')
   BhpIelOqUgfKCzdWsETVJGMyrajbmw['saveinfo']['infoLabels']['plot'] =BhpIelOqUgfKCzdWsETVJGMyrajbiR.Get_ChangeText(BhpIelOqUgfKCzdWsETVJGMyrajbmN.get('programsynopsis'))
   BhpIelOqUgfKCzdWsETVJGMyrajbmw['saveinfo']['infoLabels']['studio'] =BhpIelOqUgfKCzdWsETVJGMyrajbmN.get('channelname')
   if BhpIelOqUgfKCzdWsETVJGMyrajbmN.get('firstreleaseyear')!='':BhpIelOqUgfKCzdWsETVJGMyrajbmw['saveinfo']['infoLabels']['year'] =BhpIelOqUgfKCzdWsETVJGMyrajbmN.get('firstreleaseyear')
   if BhpIelOqUgfKCzdWsETVJGMyrajbmN.get('firstreleasedate')!='':BhpIelOqUgfKCzdWsETVJGMyrajbmw['saveinfo']['infoLabels']['premiered']=BhpIelOqUgfKCzdWsETVJGMyrajbmN.get('firstreleasedate')
   if BhpIelOqUgfKCzdWsETVJGMyrajbmN.get('genretext') !='':BhpIelOqUgfKCzdWsETVJGMyrajbmw['saveinfo']['infoLabels']['genre'] =[BhpIelOqUgfKCzdWsETVJGMyrajbmN.get('genretext')]
   BhpIelOqUgfKCzdWsETVJGMyrajbmP=[]
   for BhpIelOqUgfKCzdWsETVJGMyrajbmF in BhpIelOqUgfKCzdWsETVJGMyrajbmN['actors']['list']:BhpIelOqUgfKCzdWsETVJGMyrajbmP.append(BhpIelOqUgfKCzdWsETVJGMyrajbmF.get('text'))
   if BhpIelOqUgfKCzdWsETVJGMyrajbkm(BhpIelOqUgfKCzdWsETVJGMyrajbmP)>0:
    if BhpIelOqUgfKCzdWsETVJGMyrajbmP[0]!='':BhpIelOqUgfKCzdWsETVJGMyrajbmw['saveinfo']['infoLabels']['cast']=BhpIelOqUgfKCzdWsETVJGMyrajbmP
   BhpIelOqUgfKCzdWsETVJGMyrajbtP =''
   BhpIelOqUgfKCzdWsETVJGMyrajbtF =''
   BhpIelOqUgfKCzdWsETVJGMyrajbtD=''
   if BhpIelOqUgfKCzdWsETVJGMyrajbmN.get('programposterimage')!='':BhpIelOqUgfKCzdWsETVJGMyrajbtP =BhpIelOqUgfKCzdWsETVJGMyrajbiR.HTTPTAG+BhpIelOqUgfKCzdWsETVJGMyrajbmN.get('programposterimage')
   if BhpIelOqUgfKCzdWsETVJGMyrajbmN.get('programimage') !='':BhpIelOqUgfKCzdWsETVJGMyrajbtF =BhpIelOqUgfKCzdWsETVJGMyrajbiR.HTTPTAG+BhpIelOqUgfKCzdWsETVJGMyrajbmN.get('programimage')
   if BhpIelOqUgfKCzdWsETVJGMyrajbmN.get('programcircleimage')!='':BhpIelOqUgfKCzdWsETVJGMyrajbtD=BhpIelOqUgfKCzdWsETVJGMyrajbiR.HTTPTAG+BhpIelOqUgfKCzdWsETVJGMyrajbmN.get('programcircleimage')
   if 'poster_default' in BhpIelOqUgfKCzdWsETVJGMyrajbtP:
    BhpIelOqUgfKCzdWsETVJGMyrajbtP =BhpIelOqUgfKCzdWsETVJGMyrajbtF
    BhpIelOqUgfKCzdWsETVJGMyrajbtD=''
   BhpIelOqUgfKCzdWsETVJGMyrajbmw['saveinfo']['thumbnail']['poster']=BhpIelOqUgfKCzdWsETVJGMyrajbtP
   BhpIelOqUgfKCzdWsETVJGMyrajbmw['saveinfo']['thumbnail']['thumb']=BhpIelOqUgfKCzdWsETVJGMyrajbtF
   BhpIelOqUgfKCzdWsETVJGMyrajbmw['saveinfo']['thumbnail']['clearlogo']=BhpIelOqUgfKCzdWsETVJGMyrajbtD
   BhpIelOqUgfKCzdWsETVJGMyrajbmw['saveinfo']['thumbnail']['fanart']=BhpIelOqUgfKCzdWsETVJGMyrajbtF
  else:
   BhpIelOqUgfKCzdWsETVJGMyrajbXw=BhpIelOqUgfKCzdWsETVJGMyrajbiR.API_DOMAIN+'/movie/contents/'+BhpIelOqUgfKCzdWsETVJGMyrajbxF 
   BhpIelOqUgfKCzdWsETVJGMyrajbiu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.GetDefaultParams()
   BhpIelOqUgfKCzdWsETVJGMyrajbXu=BhpIelOqUgfKCzdWsETVJGMyrajbiR.callRequestCookies('Get',BhpIelOqUgfKCzdWsETVJGMyrajbXw,payload=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,params=BhpIelOqUgfKCzdWsETVJGMyrajbiu,headers=BhpIelOqUgfKCzdWsETVJGMyrajbmQ,cookies=BhpIelOqUgfKCzdWsETVJGMyrajbmQ)
   BhpIelOqUgfKCzdWsETVJGMyrajbXP=json.loads(BhpIelOqUgfKCzdWsETVJGMyrajbXu.text)
   if not('title' in BhpIelOqUgfKCzdWsETVJGMyrajbXP):return{}
   BhpIelOqUgfKCzdWsETVJGMyrajbmN=BhpIelOqUgfKCzdWsETVJGMyrajbXP
   BhpIelOqUgfKCzdWsETVJGMyrajbmu=BhpIelOqUgfKCzdWsETVJGMyrajbmN.get('title')
   BhpIelOqUgfKCzdWsETVJGMyrajbmw['saveinfo']['infoLabels']['title']=BhpIelOqUgfKCzdWsETVJGMyrajbmu
   if BhpIelOqUgfKCzdWsETVJGMyrajbmN.get('targetage')=='18' or BhpIelOqUgfKCzdWsETVJGMyrajbmN.get('targetage')=='19' or BhpIelOqUgfKCzdWsETVJGMyrajbmN.get('targetage')=='21':
    BhpIelOqUgfKCzdWsETVJGMyrajbmu +=u' (%s)'%(BhpIelOqUgfKCzdWsETVJGMyrajbmN.get('targetage'))
   BhpIelOqUgfKCzdWsETVJGMyrajbmw['saveinfo']['title'] =BhpIelOqUgfKCzdWsETVJGMyrajbmu
   BhpIelOqUgfKCzdWsETVJGMyrajbmw['saveinfo']['infoLabels']['mpaa'] =BhpIelOqUgfKCzdWsETVJGMyrajbmN.get('targetage')
   BhpIelOqUgfKCzdWsETVJGMyrajbmw['saveinfo']['infoLabels']['plot'] =BhpIelOqUgfKCzdWsETVJGMyrajbiR.Get_ChangeText(BhpIelOqUgfKCzdWsETVJGMyrajbmN.get('synopsis'))
   BhpIelOqUgfKCzdWsETVJGMyrajbmw['saveinfo']['infoLabels']['duration']=BhpIelOqUgfKCzdWsETVJGMyrajbmN.get('playtime')
   BhpIelOqUgfKCzdWsETVJGMyrajbmw['saveinfo']['infoLabels']['country']=BhpIelOqUgfKCzdWsETVJGMyrajbmN.get('country')
   BhpIelOqUgfKCzdWsETVJGMyrajbmw['saveinfo']['infoLabels']['studio'] =BhpIelOqUgfKCzdWsETVJGMyrajbmN.get('cpname')
   if BhpIelOqUgfKCzdWsETVJGMyrajbmN.get('releasedate')!='':
    BhpIelOqUgfKCzdWsETVJGMyrajbmw['saveinfo']['infoLabels']['year'] =BhpIelOqUgfKCzdWsETVJGMyrajbmN.get('releasedate')[:4]
    BhpIelOqUgfKCzdWsETVJGMyrajbmw['saveinfo']['infoLabels']['premiered']=BhpIelOqUgfKCzdWsETVJGMyrajbmN.get('releasedate')
   BhpIelOqUgfKCzdWsETVJGMyrajbmP=[]
   for BhpIelOqUgfKCzdWsETVJGMyrajbmF in BhpIelOqUgfKCzdWsETVJGMyrajbmN['actors']['list']:BhpIelOqUgfKCzdWsETVJGMyrajbmP.append(BhpIelOqUgfKCzdWsETVJGMyrajbmF.get('text'))
   if BhpIelOqUgfKCzdWsETVJGMyrajbkm(BhpIelOqUgfKCzdWsETVJGMyrajbmP)>0:
    if BhpIelOqUgfKCzdWsETVJGMyrajbmP[0]!='':BhpIelOqUgfKCzdWsETVJGMyrajbmw['saveinfo']['infoLabels']['cast']=BhpIelOqUgfKCzdWsETVJGMyrajbmP
   BhpIelOqUgfKCzdWsETVJGMyrajbmD=[]
   for BhpIelOqUgfKCzdWsETVJGMyrajbmS in BhpIelOqUgfKCzdWsETVJGMyrajbmN['directors']['list']:BhpIelOqUgfKCzdWsETVJGMyrajbmD.append(BhpIelOqUgfKCzdWsETVJGMyrajbmS.get('text'))
   if BhpIelOqUgfKCzdWsETVJGMyrajbkm(BhpIelOqUgfKCzdWsETVJGMyrajbmD)>0:
    if BhpIelOqUgfKCzdWsETVJGMyrajbmD[0]!='':BhpIelOqUgfKCzdWsETVJGMyrajbmw['saveinfo']['infoLabels']['director']=BhpIelOqUgfKCzdWsETVJGMyrajbmD
   BhpIelOqUgfKCzdWsETVJGMyrajbxi=[]
   for BhpIelOqUgfKCzdWsETVJGMyrajbmA in BhpIelOqUgfKCzdWsETVJGMyrajbmN['genre']['list']:BhpIelOqUgfKCzdWsETVJGMyrajbxi.append(BhpIelOqUgfKCzdWsETVJGMyrajbmA.get('text'))
   if BhpIelOqUgfKCzdWsETVJGMyrajbkm(BhpIelOqUgfKCzdWsETVJGMyrajbxi)>0:
    if BhpIelOqUgfKCzdWsETVJGMyrajbxi[0]!='':BhpIelOqUgfKCzdWsETVJGMyrajbmw['saveinfo']['infoLabels']['genre']=BhpIelOqUgfKCzdWsETVJGMyrajbxi
   BhpIelOqUgfKCzdWsETVJGMyrajbtP ='https://%s'%BhpIelOqUgfKCzdWsETVJGMyrajbmN['image']
   BhpIelOqUgfKCzdWsETVJGMyrajbmw['saveinfo']['thumbnail']['poster'] =BhpIelOqUgfKCzdWsETVJGMyrajbtP
   BhpIelOqUgfKCzdWsETVJGMyrajbmw['saveinfo']['thumbnail']['thumb'] =BhpIelOqUgfKCzdWsETVJGMyrajbtP
  return BhpIelOqUgfKCzdWsETVJGMyrajbmw
# Created by pyminifier (https://github.com/liftoff/pyminifier)
