__author__="NightRain"
mdAUcEWCrqIQygjNRtiJKVuoxMGFkn=object
mdAUcEWCrqIQygjNRtiJKVuoxMGFkB=None
mdAUcEWCrqIQygjNRtiJKVuoxMGFkl=int
mdAUcEWCrqIQygjNRtiJKVuoxMGFkT=True
mdAUcEWCrqIQygjNRtiJKVuoxMGFkb=False
mdAUcEWCrqIQygjNRtiJKVuoxMGFkS=type
mdAUcEWCrqIQygjNRtiJKVuoxMGFkw=dict
mdAUcEWCrqIQygjNRtiJKVuoxMGFkh=getattr
mdAUcEWCrqIQygjNRtiJKVuoxMGFkH=list
mdAUcEWCrqIQygjNRtiJKVuoxMGFka=len
mdAUcEWCrqIQygjNRtiJKVuoxMGFkD=range
mdAUcEWCrqIQygjNRtiJKVuoxMGFkL=str
mdAUcEWCrqIQygjNRtiJKVuoxMGFkY=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import json
mdAUcEWCrqIQygjNRtiJKVuoxMGFvz=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://apis.wavve.com/v1/multiband/GN51','icon':'home.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&uicode=VN500','page':'1','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?WeekDay=all&broadcastid=1390539&contenttype=vod&genre=01&orderby=viewtime&uicode=VN4&uiparent=FN0&uirank=0&uitype=VN4','page':'1','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?WeekDay=all&broadcastid=1311034&contenttype=vod&genre=02&orderby=viewtime&uicode=VN3&uiparent=FN0&uirank=0&uitype=VN3','page':'1','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'CN21','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'vod09','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'vod09','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'4','sType':'movie','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'4','sType':'movie','orderby':'modifydate','ordernm':'업데이트순','icon':''},{'title':'프로야구 - 경기중 시청가능','mode':'GAME_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'(웨이브) 검색','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'(웨이브) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
mdAUcEWCrqIQygjNRtiJKVuoxMGFvp=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
mdAUcEWCrqIQygjNRtiJKVuoxMGFve=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
mdAUcEWCrqIQygjNRtiJKVuoxMGFvO={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
mdAUcEWCrqIQygjNRtiJKVuoxMGFvs =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
mdAUcEWCrqIQygjNRtiJKVuoxMGFvk=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_searched.txt'))
from wavveCore import*
class mdAUcEWCrqIQygjNRtiJKVuoxMGFvX(mdAUcEWCrqIQygjNRtiJKVuoxMGFkn):
 def __init__(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP,mdAUcEWCrqIQygjNRtiJKVuoxMGFvn,mdAUcEWCrqIQygjNRtiJKVuoxMGFvB,mdAUcEWCrqIQygjNRtiJKVuoxMGFvl):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvP._addon_url =mdAUcEWCrqIQygjNRtiJKVuoxMGFvn
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvP._addon_handle=mdAUcEWCrqIQygjNRtiJKVuoxMGFvB
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.main_params =mdAUcEWCrqIQygjNRtiJKVuoxMGFvl
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj =tkNzmWicyQJYlqXCHEFOSarRTLpgBv() 
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.WV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_stream(mpd,m3u8)'))
 def addon_noti(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP,sting):
  try:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvb=xbmcgui.Dialog()
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvb.notification(__addonname__,sting)
  except:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFkB
 def addon_log(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP,string):
  try:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvS=string.encode('utf-8','ignore')
  except:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvS='addonException: addon_log'
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvw=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,mdAUcEWCrqIQygjNRtiJKVuoxMGFvS),level=mdAUcEWCrqIQygjNRtiJKVuoxMGFvw)
 def get_keyboard_input(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP,mdAUcEWCrqIQygjNRtiJKVuoxMGFXT):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvh=mdAUcEWCrqIQygjNRtiJKVuoxMGFkB
  kb=xbmc.Keyboard()
  kb.setHeading(mdAUcEWCrqIQygjNRtiJKVuoxMGFXT)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvh=kb.getText()
  return mdAUcEWCrqIQygjNRtiJKVuoxMGFvh
 def get_settings_account(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvH =__addon__.getSetting('id')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFva =__addon__.getSetting('pw')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvD=mdAUcEWCrqIQygjNRtiJKVuoxMGFkl(__addon__.getSetting('selected_profile'))
  return(mdAUcEWCrqIQygjNRtiJKVuoxMGFvH,mdAUcEWCrqIQygjNRtiJKVuoxMGFva,mdAUcEWCrqIQygjNRtiJKVuoxMGFvD)
 def get_settings_totalsearch(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvL =mdAUcEWCrqIQygjNRtiJKVuoxMGFkT if __addon__.getSetting('local_search')=='true' else mdAUcEWCrqIQygjNRtiJKVuoxMGFkb
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvY=mdAUcEWCrqIQygjNRtiJKVuoxMGFkT if __addon__.getSetting('local_history')=='true' else mdAUcEWCrqIQygjNRtiJKVuoxMGFkb
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvf =mdAUcEWCrqIQygjNRtiJKVuoxMGFkT if __addon__.getSetting('total_search')=='true' else mdAUcEWCrqIQygjNRtiJKVuoxMGFkb
  mdAUcEWCrqIQygjNRtiJKVuoxMGFXv=mdAUcEWCrqIQygjNRtiJKVuoxMGFkT if __addon__.getSetting('total_history')=='true' else mdAUcEWCrqIQygjNRtiJKVuoxMGFkb
  mdAUcEWCrqIQygjNRtiJKVuoxMGFXz=mdAUcEWCrqIQygjNRtiJKVuoxMGFkT if __addon__.getSetting('menu_bookmark')=='true' else mdAUcEWCrqIQygjNRtiJKVuoxMGFkb
  return(mdAUcEWCrqIQygjNRtiJKVuoxMGFvL,mdAUcEWCrqIQygjNRtiJKVuoxMGFvY,mdAUcEWCrqIQygjNRtiJKVuoxMGFvf,mdAUcEWCrqIQygjNRtiJKVuoxMGFXv,mdAUcEWCrqIQygjNRtiJKVuoxMGFXz)
 def get_settings_makebookmark(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP):
  return mdAUcEWCrqIQygjNRtiJKVuoxMGFkT if __addon__.getSetting('make_bookmark')=='true' else mdAUcEWCrqIQygjNRtiJKVuoxMGFkb
 def get_settings_play(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFXp={'enable_hdr':mdAUcEWCrqIQygjNRtiJKVuoxMGFkT if __addon__.getSetting('enable_hdr')=='true' else mdAUcEWCrqIQygjNRtiJKVuoxMGFkb,'enable_uhd':mdAUcEWCrqIQygjNRtiJKVuoxMGFkT if __addon__.getSetting('enable_uhd')=='true' else mdAUcEWCrqIQygjNRtiJKVuoxMGFkb,'streamFilename':mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.WV_STREAM_FILENAME,}
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.get_selQuality()<1080:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXp['enable_hdr']=mdAUcEWCrqIQygjNRtiJKVuoxMGFkb
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXp['enable_uhd']=mdAUcEWCrqIQygjNRtiJKVuoxMGFkb
  return(mdAUcEWCrqIQygjNRtiJKVuoxMGFXp)
 def get_settings_proxyport(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFXe =mdAUcEWCrqIQygjNRtiJKVuoxMGFkT if __addon__.getSetting('proxyYn')=='true' else mdAUcEWCrqIQygjNRtiJKVuoxMGFkb
  mdAUcEWCrqIQygjNRtiJKVuoxMGFXO=mdAUcEWCrqIQygjNRtiJKVuoxMGFkl(__addon__.getSetting('proxyPort'))
  return mdAUcEWCrqIQygjNRtiJKVuoxMGFXe,mdAUcEWCrqIQygjNRtiJKVuoxMGFXO
 def get_selQuality(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP):
  try:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXs=[1080,720,480,360]
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXk=mdAUcEWCrqIQygjNRtiJKVuoxMGFkl(__addon__.getSetting('selected_quality'))
   return mdAUcEWCrqIQygjNRtiJKVuoxMGFXs[mdAUcEWCrqIQygjNRtiJKVuoxMGFXk]
  except:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFkB
  return 1080 
 def get_settings_exclusion21(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFXP =__addon__.getSetting('exclusion21')
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFXP=='false':
   return mdAUcEWCrqIQygjNRtiJKVuoxMGFkb
  else:
   return mdAUcEWCrqIQygjNRtiJKVuoxMGFkT
 def get_settings_direct_replay(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFXn=mdAUcEWCrqIQygjNRtiJKVuoxMGFkl(__addon__.getSetting('direct_replay'))
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFXn==0:
   return mdAUcEWCrqIQygjNRtiJKVuoxMGFkb
  else:
   return mdAUcEWCrqIQygjNRtiJKVuoxMGFkT
 def set_winEpisodeOrderby(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP,mdAUcEWCrqIQygjNRtiJKVuoxMGFXB):
  __addon__.setSetting('wavve_orderby',mdAUcEWCrqIQygjNRtiJKVuoxMGFXB)
 def get_winEpisodeOrderby(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFXB=__addon__.getSetting('wavve_orderby')
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFXB in['',mdAUcEWCrqIQygjNRtiJKVuoxMGFkB]:mdAUcEWCrqIQygjNRtiJKVuoxMGFXB='desc'
  return mdAUcEWCrqIQygjNRtiJKVuoxMGFXB
 def add_dir(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP,label,sublabel='',img='',infoLabels=mdAUcEWCrqIQygjNRtiJKVuoxMGFkB,isFolder=mdAUcEWCrqIQygjNRtiJKVuoxMGFkT,params='',isLink=mdAUcEWCrqIQygjNRtiJKVuoxMGFkb,ContextMenu=mdAUcEWCrqIQygjNRtiJKVuoxMGFkB):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFXl='%s?%s'%(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP._addon_url,urllib.parse.urlencode(params))
  if sublabel:mdAUcEWCrqIQygjNRtiJKVuoxMGFXT='%s < %s >'%(label,sublabel)
  else: mdAUcEWCrqIQygjNRtiJKVuoxMGFXT=label
  if not img:img='DefaultFolder.png'
  mdAUcEWCrqIQygjNRtiJKVuoxMGFXb=xbmcgui.ListItem(mdAUcEWCrqIQygjNRtiJKVuoxMGFXT)
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFkS(img)==mdAUcEWCrqIQygjNRtiJKVuoxMGFkw:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXb.setArt(img)
  else:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXb.setArt({'thumb':img,'poster':img})
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.KodiVersion>=20:
   if infoLabels:mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.Set_InfoTag(mdAUcEWCrqIQygjNRtiJKVuoxMGFXb.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:mdAUcEWCrqIQygjNRtiJKVuoxMGFXb.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXb.setProperty('IsPlayable','true')
  if ContextMenu:mdAUcEWCrqIQygjNRtiJKVuoxMGFXb.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP._addon_handle,mdAUcEWCrqIQygjNRtiJKVuoxMGFXl,mdAUcEWCrqIQygjNRtiJKVuoxMGFXb,isFolder)
 def Set_InfoTag(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP,video_InfoTag:xbmc.InfoTagVideo,mdAUcEWCrqIQygjNRtiJKVuoxMGFXY):
  for mdAUcEWCrqIQygjNRtiJKVuoxMGFXS,value in mdAUcEWCrqIQygjNRtiJKVuoxMGFXY.items():
   if mdAUcEWCrqIQygjNRtiJKVuoxMGFvO[mdAUcEWCrqIQygjNRtiJKVuoxMGFXS]['type']=='string':
    mdAUcEWCrqIQygjNRtiJKVuoxMGFkh(video_InfoTag,mdAUcEWCrqIQygjNRtiJKVuoxMGFvO[mdAUcEWCrqIQygjNRtiJKVuoxMGFXS]['func'])(value)
   elif mdAUcEWCrqIQygjNRtiJKVuoxMGFvO[mdAUcEWCrqIQygjNRtiJKVuoxMGFXS]['type']=='int':
    if mdAUcEWCrqIQygjNRtiJKVuoxMGFkS(value)==mdAUcEWCrqIQygjNRtiJKVuoxMGFkl:
     mdAUcEWCrqIQygjNRtiJKVuoxMGFXw=mdAUcEWCrqIQygjNRtiJKVuoxMGFkl(value)
    else:
     mdAUcEWCrqIQygjNRtiJKVuoxMGFXw=0
    mdAUcEWCrqIQygjNRtiJKVuoxMGFkh(video_InfoTag,mdAUcEWCrqIQygjNRtiJKVuoxMGFvO[mdAUcEWCrqIQygjNRtiJKVuoxMGFXS]['func'])(mdAUcEWCrqIQygjNRtiJKVuoxMGFXw)
   elif mdAUcEWCrqIQygjNRtiJKVuoxMGFvO[mdAUcEWCrqIQygjNRtiJKVuoxMGFXS]['type']=='actor':
    if value!=[]:
     mdAUcEWCrqIQygjNRtiJKVuoxMGFkh(video_InfoTag,mdAUcEWCrqIQygjNRtiJKVuoxMGFvO[mdAUcEWCrqIQygjNRtiJKVuoxMGFXS]['func'])([xbmc.Actor(name)for name in value])
   elif mdAUcEWCrqIQygjNRtiJKVuoxMGFvO[mdAUcEWCrqIQygjNRtiJKVuoxMGFXS]['type']=='list':
    if mdAUcEWCrqIQygjNRtiJKVuoxMGFkS(value)==mdAUcEWCrqIQygjNRtiJKVuoxMGFkH:
     mdAUcEWCrqIQygjNRtiJKVuoxMGFkh(video_InfoTag,mdAUcEWCrqIQygjNRtiJKVuoxMGFvO[mdAUcEWCrqIQygjNRtiJKVuoxMGFXS]['func'])(value)
    else:
     mdAUcEWCrqIQygjNRtiJKVuoxMGFkh(video_InfoTag,mdAUcEWCrqIQygjNRtiJKVuoxMGFvO[mdAUcEWCrqIQygjNRtiJKVuoxMGFXS]['func'])([value])
 def dp_Main_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP):
  (mdAUcEWCrqIQygjNRtiJKVuoxMGFvL,mdAUcEWCrqIQygjNRtiJKVuoxMGFvY,mdAUcEWCrqIQygjNRtiJKVuoxMGFvf,mdAUcEWCrqIQygjNRtiJKVuoxMGFXv,mdAUcEWCrqIQygjNRtiJKVuoxMGFXz)=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.get_settings_totalsearch()
  for mdAUcEWCrqIQygjNRtiJKVuoxMGFXh in mdAUcEWCrqIQygjNRtiJKVuoxMGFvz:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXT=mdAUcEWCrqIQygjNRtiJKVuoxMGFXh.get('title')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXH=''
   if mdAUcEWCrqIQygjNRtiJKVuoxMGFXh.get('mode')=='SEARCH_GROUP' and mdAUcEWCrqIQygjNRtiJKVuoxMGFvL ==mdAUcEWCrqIQygjNRtiJKVuoxMGFkb:continue
   elif mdAUcEWCrqIQygjNRtiJKVuoxMGFXh.get('mode')=='SEARCH_HISTORY' and mdAUcEWCrqIQygjNRtiJKVuoxMGFvY==mdAUcEWCrqIQygjNRtiJKVuoxMGFkb:continue
   elif mdAUcEWCrqIQygjNRtiJKVuoxMGFXh.get('mode')=='TOTAL_SEARCH' and mdAUcEWCrqIQygjNRtiJKVuoxMGFvf ==mdAUcEWCrqIQygjNRtiJKVuoxMGFkb:continue
   elif mdAUcEWCrqIQygjNRtiJKVuoxMGFXh.get('mode')=='TOTAL_HISTORY' and mdAUcEWCrqIQygjNRtiJKVuoxMGFXv==mdAUcEWCrqIQygjNRtiJKVuoxMGFkb:continue
   elif mdAUcEWCrqIQygjNRtiJKVuoxMGFXh.get('mode')=='MENU_BOOKMARK' and mdAUcEWCrqIQygjNRtiJKVuoxMGFXz==mdAUcEWCrqIQygjNRtiJKVuoxMGFkb:continue
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa={'mode':mdAUcEWCrqIQygjNRtiJKVuoxMGFXh.get('mode'),'sCode':mdAUcEWCrqIQygjNRtiJKVuoxMGFXh.get('sCode'),'sIndex':mdAUcEWCrqIQygjNRtiJKVuoxMGFXh.get('sIndex'),'sType':mdAUcEWCrqIQygjNRtiJKVuoxMGFXh.get('sType'),'suburl':mdAUcEWCrqIQygjNRtiJKVuoxMGFXh.get('suburl'),'subapi':mdAUcEWCrqIQygjNRtiJKVuoxMGFXh.get('subapi'),'page':mdAUcEWCrqIQygjNRtiJKVuoxMGFXh.get('page'),'orderby':mdAUcEWCrqIQygjNRtiJKVuoxMGFXh.get('orderby'),'ordernm':mdAUcEWCrqIQygjNRtiJKVuoxMGFXh.get('ordernm')}
   if mdAUcEWCrqIQygjNRtiJKVuoxMGFXh.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    mdAUcEWCrqIQygjNRtiJKVuoxMGFXD=mdAUcEWCrqIQygjNRtiJKVuoxMGFkb
    mdAUcEWCrqIQygjNRtiJKVuoxMGFXL =mdAUcEWCrqIQygjNRtiJKVuoxMGFkT
   else:
    mdAUcEWCrqIQygjNRtiJKVuoxMGFXD=mdAUcEWCrqIQygjNRtiJKVuoxMGFkT
    mdAUcEWCrqIQygjNRtiJKVuoxMGFXL =mdAUcEWCrqIQygjNRtiJKVuoxMGFkb
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXY={'title':mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,'plot':mdAUcEWCrqIQygjNRtiJKVuoxMGFXT}
   if mdAUcEWCrqIQygjNRtiJKVuoxMGFXh.get('mode')=='XXX':mdAUcEWCrqIQygjNRtiJKVuoxMGFXY=mdAUcEWCrqIQygjNRtiJKVuoxMGFkB
   if 'icon' in mdAUcEWCrqIQygjNRtiJKVuoxMGFXh:mdAUcEWCrqIQygjNRtiJKVuoxMGFXH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',mdAUcEWCrqIQygjNRtiJKVuoxMGFXh.get('icon')) 
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.add_dir(mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,sublabel='',img=mdAUcEWCrqIQygjNRtiJKVuoxMGFXH,infoLabels=mdAUcEWCrqIQygjNRtiJKVuoxMGFXY,isFolder=mdAUcEWCrqIQygjNRtiJKVuoxMGFXD,params=mdAUcEWCrqIQygjNRtiJKVuoxMGFXa,isLink=mdAUcEWCrqIQygjNRtiJKVuoxMGFXL)
  xbmcplugin.endOfDirectory(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP._addon_handle,cacheToDisc=mdAUcEWCrqIQygjNRtiJKVuoxMGFkT)
 def dp_Search_Group(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP,args):
  if 'search_key' in args:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFzX=args.get('search_key')
  else:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFzX=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not mdAUcEWCrqIQygjNRtiJKVuoxMGFzX:
    return
  for mdAUcEWCrqIQygjNRtiJKVuoxMGFzp in mdAUcEWCrqIQygjNRtiJKVuoxMGFvp:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFze =mdAUcEWCrqIQygjNRtiJKVuoxMGFzp.get('mode')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFzO=mdAUcEWCrqIQygjNRtiJKVuoxMGFzp.get('sType')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXT=mdAUcEWCrqIQygjNRtiJKVuoxMGFzp.get('title')
   (mdAUcEWCrqIQygjNRtiJKVuoxMGFzs,mdAUcEWCrqIQygjNRtiJKVuoxMGFzk)=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.Get_Search_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFzX,mdAUcEWCrqIQygjNRtiJKVuoxMGFzO,1,exclusion21=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.get_settings_exclusion21())
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXY={'plot':'검색어 : '+mdAUcEWCrqIQygjNRtiJKVuoxMGFzX+'\n\n'+mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.Search_FreeList(mdAUcEWCrqIQygjNRtiJKVuoxMGFzs)}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa={'mode':mdAUcEWCrqIQygjNRtiJKVuoxMGFze,'sType':mdAUcEWCrqIQygjNRtiJKVuoxMGFzO,'search_key':mdAUcEWCrqIQygjNRtiJKVuoxMGFzX,'page':'1',}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.add_dir(mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,sublabel='',img='',infoLabels=mdAUcEWCrqIQygjNRtiJKVuoxMGFXY,isFolder=mdAUcEWCrqIQygjNRtiJKVuoxMGFkT,params=mdAUcEWCrqIQygjNRtiJKVuoxMGFXa)
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFka(mdAUcEWCrqIQygjNRtiJKVuoxMGFvp)>0:xbmcplugin.endOfDirectory(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP._addon_handle,cacheToDisc=mdAUcEWCrqIQygjNRtiJKVuoxMGFkT)
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.Save_Searched_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFzX)
 def Search_FreeList(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP,search_list):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFzP=''
  mdAUcEWCrqIQygjNRtiJKVuoxMGFzn=7
  try:
   if mdAUcEWCrqIQygjNRtiJKVuoxMGFka(search_list)==0:return '검색결과 없음'
   for i in mdAUcEWCrqIQygjNRtiJKVuoxMGFkD(mdAUcEWCrqIQygjNRtiJKVuoxMGFka(search_list)):
    if i>=mdAUcEWCrqIQygjNRtiJKVuoxMGFzn:
     mdAUcEWCrqIQygjNRtiJKVuoxMGFzP=mdAUcEWCrqIQygjNRtiJKVuoxMGFzP+'...'
     break
    mdAUcEWCrqIQygjNRtiJKVuoxMGFzP=mdAUcEWCrqIQygjNRtiJKVuoxMGFzP+search_list[i]['title']+'\n'
  except:
   return ''
  return mdAUcEWCrqIQygjNRtiJKVuoxMGFzP
 def dp_Watch_Group(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP,args):
  for mdAUcEWCrqIQygjNRtiJKVuoxMGFzB in mdAUcEWCrqIQygjNRtiJKVuoxMGFve:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXT=mdAUcEWCrqIQygjNRtiJKVuoxMGFzB.get('title')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa={'mode':mdAUcEWCrqIQygjNRtiJKVuoxMGFzB.get('mode'),'sType':mdAUcEWCrqIQygjNRtiJKVuoxMGFzB.get('sType')}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.add_dir(mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,sublabel='',img='',infoLabels=mdAUcEWCrqIQygjNRtiJKVuoxMGFkB,isFolder=mdAUcEWCrqIQygjNRtiJKVuoxMGFkT,params=mdAUcEWCrqIQygjNRtiJKVuoxMGFXa)
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFka(mdAUcEWCrqIQygjNRtiJKVuoxMGFve)>0:xbmcplugin.endOfDirectory(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP._addon_handle,cacheToDisc=mdAUcEWCrqIQygjNRtiJKVuoxMGFkT)
 def dp_Search_History(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP,args):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFzl=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.Load_List_File('search')
  for mdAUcEWCrqIQygjNRtiJKVuoxMGFzT in mdAUcEWCrqIQygjNRtiJKVuoxMGFzl:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFzb=mdAUcEWCrqIQygjNRtiJKVuoxMGFkw(urllib.parse.parse_qsl(mdAUcEWCrqIQygjNRtiJKVuoxMGFzT))
   mdAUcEWCrqIQygjNRtiJKVuoxMGFzS=mdAUcEWCrqIQygjNRtiJKVuoxMGFzb.get('skey').strip()
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa={'mode':'SEARCH_GROUP','search_key':mdAUcEWCrqIQygjNRtiJKVuoxMGFzS,}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFzw={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':mdAUcEWCrqIQygjNRtiJKVuoxMGFzS,'vType':'-',}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFzh=urllib.parse.urlencode(mdAUcEWCrqIQygjNRtiJKVuoxMGFzw)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFzH=[('선택된 검색어 ( %s ) 삭제'%(mdAUcEWCrqIQygjNRtiJKVuoxMGFzS),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(mdAUcEWCrqIQygjNRtiJKVuoxMGFzh))]
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.add_dir(mdAUcEWCrqIQygjNRtiJKVuoxMGFzS,sublabel='',img=mdAUcEWCrqIQygjNRtiJKVuoxMGFkB,infoLabels=mdAUcEWCrqIQygjNRtiJKVuoxMGFkB,isFolder=mdAUcEWCrqIQygjNRtiJKVuoxMGFkT,params=mdAUcEWCrqIQygjNRtiJKVuoxMGFXa,ContextMenu=mdAUcEWCrqIQygjNRtiJKVuoxMGFzH)
  mdAUcEWCrqIQygjNRtiJKVuoxMGFza={'plot':'검색목록 전체를 삭제합니다.'}
  mdAUcEWCrqIQygjNRtiJKVuoxMGFXT='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  mdAUcEWCrqIQygjNRtiJKVuoxMGFXa={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  mdAUcEWCrqIQygjNRtiJKVuoxMGFXH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.add_dir(mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,sublabel='',img=mdAUcEWCrqIQygjNRtiJKVuoxMGFXH,infoLabels=mdAUcEWCrqIQygjNRtiJKVuoxMGFza,isFolder=mdAUcEWCrqIQygjNRtiJKVuoxMGFkb,params=mdAUcEWCrqIQygjNRtiJKVuoxMGFXa,isLink=mdAUcEWCrqIQygjNRtiJKVuoxMGFkT)
  xbmcplugin.endOfDirectory(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP._addon_handle,cacheToDisc=mdAUcEWCrqIQygjNRtiJKVuoxMGFkb)
 def dp_Search_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP,args):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFzO =args.get('sType')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFzD =mdAUcEWCrqIQygjNRtiJKVuoxMGFkl(args.get('page'))
  if 'search_key' in args:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFzX=args.get('search_key')
  else:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFzX=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not mdAUcEWCrqIQygjNRtiJKVuoxMGFzX:
    xbmcplugin.endOfDirectory(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP._addon_handle)
    return
  mdAUcEWCrqIQygjNRtiJKVuoxMGFzL,mdAUcEWCrqIQygjNRtiJKVuoxMGFzk=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.Get_Search_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFzX,mdAUcEWCrqIQygjNRtiJKVuoxMGFzO,mdAUcEWCrqIQygjNRtiJKVuoxMGFzD,exclusion21=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.get_settings_exclusion21())
  for mdAUcEWCrqIQygjNRtiJKVuoxMGFzY in mdAUcEWCrqIQygjNRtiJKVuoxMGFzL:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFzf =mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('videoid')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpv =mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('vidtype')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXT =mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('title')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpX=mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('thumbnail')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpz =mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('age')
   if mdAUcEWCrqIQygjNRtiJKVuoxMGFpz=='18' or mdAUcEWCrqIQygjNRtiJKVuoxMGFpz=='19' or mdAUcEWCrqIQygjNRtiJKVuoxMGFpz=='21':mdAUcEWCrqIQygjNRtiJKVuoxMGFXT+=' (%s)'%(mdAUcEWCrqIQygjNRtiJKVuoxMGFpz)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFza={'mediatype':'tvshow' if mdAUcEWCrqIQygjNRtiJKVuoxMGFzO=='vod' else 'movie','mpaa':mdAUcEWCrqIQygjNRtiJKVuoxMGFpz,'title':mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,'plot':mdAUcEWCrqIQygjNRtiJKVuoxMGFXT}
   if mdAUcEWCrqIQygjNRtiJKVuoxMGFzO=='vod':
    mdAUcEWCrqIQygjNRtiJKVuoxMGFXa={'mode':'EPISODE_LIST','seasonid':mdAUcEWCrqIQygjNRtiJKVuoxMGFzf,'page':'1',}
    mdAUcEWCrqIQygjNRtiJKVuoxMGFXD=mdAUcEWCrqIQygjNRtiJKVuoxMGFkT
   else:
    mdAUcEWCrqIQygjNRtiJKVuoxMGFXa={'mode':'MOVIE','contentid':mdAUcEWCrqIQygjNRtiJKVuoxMGFzf,'title':mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,'thumbnail':mdAUcEWCrqIQygjNRtiJKVuoxMGFpX,'age':mdAUcEWCrqIQygjNRtiJKVuoxMGFpz,}
    mdAUcEWCrqIQygjNRtiJKVuoxMGFXD=mdAUcEWCrqIQygjNRtiJKVuoxMGFkb
   mdAUcEWCrqIQygjNRtiJKVuoxMGFzH=[]
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpe={'mode':'VIEW_DETAIL','values':{'videoid':mdAUcEWCrqIQygjNRtiJKVuoxMGFzf,'vidtype':'tvshow' if mdAUcEWCrqIQygjNRtiJKVuoxMGFzO=='vod' else 'movie','contenttype':mdAUcEWCrqIQygjNRtiJKVuoxMGFpv,}}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpO=json.dumps(mdAUcEWCrqIQygjNRtiJKVuoxMGFpe,separators=(',',':'))
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpO=base64.standard_b64encode(mdAUcEWCrqIQygjNRtiJKVuoxMGFpO.encode()).decode('utf-8')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpO=mdAUcEWCrqIQygjNRtiJKVuoxMGFpO.replace('+','%2B')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFps='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(mdAUcEWCrqIQygjNRtiJKVuoxMGFpO)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFzH.append(('상세정보 조회',mdAUcEWCrqIQygjNRtiJKVuoxMGFps))
   if mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.get_settings_makebookmark():
    mdAUcEWCrqIQygjNRtiJKVuoxMGFpe={'videoid':mdAUcEWCrqIQygjNRtiJKVuoxMGFzf,'vidtype':'tvshow' if mdAUcEWCrqIQygjNRtiJKVuoxMGFzO=='vod' else 'movie','vtitle':mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,'vsubtitle':'','contenttype':mdAUcEWCrqIQygjNRtiJKVuoxMGFpv,}
    mdAUcEWCrqIQygjNRtiJKVuoxMGFpk=json.dumps(mdAUcEWCrqIQygjNRtiJKVuoxMGFpe)
    mdAUcEWCrqIQygjNRtiJKVuoxMGFpk=urllib.parse.quote(mdAUcEWCrqIQygjNRtiJKVuoxMGFpk)
    mdAUcEWCrqIQygjNRtiJKVuoxMGFps='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(mdAUcEWCrqIQygjNRtiJKVuoxMGFpk)
    mdAUcEWCrqIQygjNRtiJKVuoxMGFzH.append(('(통합) 찜 영상에 추가',mdAUcEWCrqIQygjNRtiJKVuoxMGFps))
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.add_dir(mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,sublabel='',img=mdAUcEWCrqIQygjNRtiJKVuoxMGFpX,infoLabels=mdAUcEWCrqIQygjNRtiJKVuoxMGFza,isFolder=mdAUcEWCrqIQygjNRtiJKVuoxMGFXD,params=mdAUcEWCrqIQygjNRtiJKVuoxMGFXa,ContextMenu=mdAUcEWCrqIQygjNRtiJKVuoxMGFzH)
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFzk:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa['mode'] ='SEARCH_LIST' 
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa['sType']=mdAUcEWCrqIQygjNRtiJKVuoxMGFzO 
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa['page'] =mdAUcEWCrqIQygjNRtiJKVuoxMGFkL(mdAUcEWCrqIQygjNRtiJKVuoxMGFzD+1)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa['search_key']=mdAUcEWCrqIQygjNRtiJKVuoxMGFzX
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXT='[B]%s >>[/B]'%'다음 페이지'
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpP=mdAUcEWCrqIQygjNRtiJKVuoxMGFkL(mdAUcEWCrqIQygjNRtiJKVuoxMGFzD+1)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.add_dir(mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,sublabel=mdAUcEWCrqIQygjNRtiJKVuoxMGFpP,img=mdAUcEWCrqIQygjNRtiJKVuoxMGFXH,infoLabels=mdAUcEWCrqIQygjNRtiJKVuoxMGFkB,isFolder=mdAUcEWCrqIQygjNRtiJKVuoxMGFkT,params=mdAUcEWCrqIQygjNRtiJKVuoxMGFXa)
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFzO=='movie':xbmcplugin.setContent(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP._addon_handle,'movies')
  else:xbmcplugin.setContent(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP._addon_handle,cacheToDisc=mdAUcEWCrqIQygjNRtiJKVuoxMGFkb)
 def dp_Watch_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP,args):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFzO =args.get('sType')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFXn=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.get_settings_direct_replay()
  mdAUcEWCrqIQygjNRtiJKVuoxMGFzL=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.Load_List_File(mdAUcEWCrqIQygjNRtiJKVuoxMGFzO)
  for mdAUcEWCrqIQygjNRtiJKVuoxMGFzY in mdAUcEWCrqIQygjNRtiJKVuoxMGFzL:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFzb=mdAUcEWCrqIQygjNRtiJKVuoxMGFkw(urllib.parse.parse_qsl(mdAUcEWCrqIQygjNRtiJKVuoxMGFzY))
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpn =mdAUcEWCrqIQygjNRtiJKVuoxMGFzb.get('code').strip()
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXT =mdAUcEWCrqIQygjNRtiJKVuoxMGFzb.get('title').strip()
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpP =mdAUcEWCrqIQygjNRtiJKVuoxMGFzb.get('subtitle').strip()
   if mdAUcEWCrqIQygjNRtiJKVuoxMGFpP=='None':mdAUcEWCrqIQygjNRtiJKVuoxMGFpP=''
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpX=mdAUcEWCrqIQygjNRtiJKVuoxMGFzb.get('img').strip()
   mdAUcEWCrqIQygjNRtiJKVuoxMGFzf =mdAUcEWCrqIQygjNRtiJKVuoxMGFzb.get('videoid').strip()
   try:
    mdAUcEWCrqIQygjNRtiJKVuoxMGFpX=mdAUcEWCrqIQygjNRtiJKVuoxMGFpX.replace('\'','\"')
    mdAUcEWCrqIQygjNRtiJKVuoxMGFpX=json.loads(mdAUcEWCrqIQygjNRtiJKVuoxMGFpX)
   except:
    mdAUcEWCrqIQygjNRtiJKVuoxMGFkB
   mdAUcEWCrqIQygjNRtiJKVuoxMGFza={'plot':'%s\n%s'%(mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,mdAUcEWCrqIQygjNRtiJKVuoxMGFpP)}
   if mdAUcEWCrqIQygjNRtiJKVuoxMGFzO=='vod':
    if mdAUcEWCrqIQygjNRtiJKVuoxMGFXn==mdAUcEWCrqIQygjNRtiJKVuoxMGFkb or mdAUcEWCrqIQygjNRtiJKVuoxMGFzf==mdAUcEWCrqIQygjNRtiJKVuoxMGFkB:
     mdAUcEWCrqIQygjNRtiJKVuoxMGFza['mediatype']='tvshow'
     mdAUcEWCrqIQygjNRtiJKVuoxMGFXa={'mode':'SEASON_LIST','videoid':mdAUcEWCrqIQygjNRtiJKVuoxMGFzf,'vidtype':'contentid',}
     mdAUcEWCrqIQygjNRtiJKVuoxMGFXD=mdAUcEWCrqIQygjNRtiJKVuoxMGFkT
    else:
     mdAUcEWCrqIQygjNRtiJKVuoxMGFza['mediatype']='episode'
     mdAUcEWCrqIQygjNRtiJKVuoxMGFXa={'mode':'VOD','programid':mdAUcEWCrqIQygjNRtiJKVuoxMGFpn,'contentid':mdAUcEWCrqIQygjNRtiJKVuoxMGFzf,'title':mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,'subtitle':mdAUcEWCrqIQygjNRtiJKVuoxMGFpP,'thumbnail':mdAUcEWCrqIQygjNRtiJKVuoxMGFpX}
     mdAUcEWCrqIQygjNRtiJKVuoxMGFXD=mdAUcEWCrqIQygjNRtiJKVuoxMGFkb
   else:
    mdAUcEWCrqIQygjNRtiJKVuoxMGFza['mediatype']='movie'
    mdAUcEWCrqIQygjNRtiJKVuoxMGFXa={'mode':'MOVIE','contentid':mdAUcEWCrqIQygjNRtiJKVuoxMGFpn,'title':mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,'subtitle':mdAUcEWCrqIQygjNRtiJKVuoxMGFpP,'thumbnail':mdAUcEWCrqIQygjNRtiJKVuoxMGFpX}
    mdAUcEWCrqIQygjNRtiJKVuoxMGFXD=mdAUcEWCrqIQygjNRtiJKVuoxMGFkb
   mdAUcEWCrqIQygjNRtiJKVuoxMGFzw={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':mdAUcEWCrqIQygjNRtiJKVuoxMGFpn,'vType':mdAUcEWCrqIQygjNRtiJKVuoxMGFzO,}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFzh=urllib.parse.urlencode(mdAUcEWCrqIQygjNRtiJKVuoxMGFzw)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFzH=[('선택된 시청이력 ( %s ) 삭제'%(mdAUcEWCrqIQygjNRtiJKVuoxMGFXT),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(mdAUcEWCrqIQygjNRtiJKVuoxMGFzh))]
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.add_dir(mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,sublabel=mdAUcEWCrqIQygjNRtiJKVuoxMGFpP,img=mdAUcEWCrqIQygjNRtiJKVuoxMGFpX,infoLabels=mdAUcEWCrqIQygjNRtiJKVuoxMGFza,isFolder=mdAUcEWCrqIQygjNRtiJKVuoxMGFXD,params=mdAUcEWCrqIQygjNRtiJKVuoxMGFXa,ContextMenu=mdAUcEWCrqIQygjNRtiJKVuoxMGFzH)
  mdAUcEWCrqIQygjNRtiJKVuoxMGFza={'plot':'시청목록을 삭제합니다.'}
  mdAUcEWCrqIQygjNRtiJKVuoxMGFXT='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  mdAUcEWCrqIQygjNRtiJKVuoxMGFXa={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':mdAUcEWCrqIQygjNRtiJKVuoxMGFzO,}
  mdAUcEWCrqIQygjNRtiJKVuoxMGFXH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.add_dir(mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,sublabel='',img=mdAUcEWCrqIQygjNRtiJKVuoxMGFXH,infoLabels=mdAUcEWCrqIQygjNRtiJKVuoxMGFza,isFolder=mdAUcEWCrqIQygjNRtiJKVuoxMGFkb,params=mdAUcEWCrqIQygjNRtiJKVuoxMGFXa,isLink=mdAUcEWCrqIQygjNRtiJKVuoxMGFkT)
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFzO=='movie':xbmcplugin.setContent(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP._addon_handle,'movies')
  else:xbmcplugin.setContent(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP._addon_handle,cacheToDisc=mdAUcEWCrqIQygjNRtiJKVuoxMGFkb)
 def Load_List_File(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP,stype): 
  try:
   if stype=='search':
    mdAUcEWCrqIQygjNRtiJKVuoxMGFpB=mdAUcEWCrqIQygjNRtiJKVuoxMGFvk
   elif stype in['vod','movie']:
    mdAUcEWCrqIQygjNRtiJKVuoxMGFpB=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   else:
    return[]
   fp=mdAUcEWCrqIQygjNRtiJKVuoxMGFkY(mdAUcEWCrqIQygjNRtiJKVuoxMGFpB,'r',-1,'utf-8')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpl=fp.readlines()
   fp.close()
  except:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpl=[]
  return mdAUcEWCrqIQygjNRtiJKVuoxMGFpl
 def Save_Watched_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP,mdAUcEWCrqIQygjNRtiJKVuoxMGFsH,mdAUcEWCrqIQygjNRtiJKVuoxMGFvl):
  try:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpT=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%mdAUcEWCrqIQygjNRtiJKVuoxMGFsH))
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpb=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.Load_List_File(mdAUcEWCrqIQygjNRtiJKVuoxMGFsH) 
   fp=mdAUcEWCrqIQygjNRtiJKVuoxMGFkY(mdAUcEWCrqIQygjNRtiJKVuoxMGFpT,'w',-1,'utf-8')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpS=urllib.parse.urlencode(mdAUcEWCrqIQygjNRtiJKVuoxMGFvl)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpS=mdAUcEWCrqIQygjNRtiJKVuoxMGFpS+'\n'
   fp.write(mdAUcEWCrqIQygjNRtiJKVuoxMGFpS)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpw=0
   for mdAUcEWCrqIQygjNRtiJKVuoxMGFph in mdAUcEWCrqIQygjNRtiJKVuoxMGFpb:
    mdAUcEWCrqIQygjNRtiJKVuoxMGFpH=mdAUcEWCrqIQygjNRtiJKVuoxMGFkw(urllib.parse.parse_qsl(mdAUcEWCrqIQygjNRtiJKVuoxMGFph))
    mdAUcEWCrqIQygjNRtiJKVuoxMGFpa=mdAUcEWCrqIQygjNRtiJKVuoxMGFvl.get('code').strip()
    mdAUcEWCrqIQygjNRtiJKVuoxMGFpD=mdAUcEWCrqIQygjNRtiJKVuoxMGFpH.get('code').strip()
    if mdAUcEWCrqIQygjNRtiJKVuoxMGFsH=='vod' and mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.get_settings_direct_replay()==mdAUcEWCrqIQygjNRtiJKVuoxMGFkT:
     mdAUcEWCrqIQygjNRtiJKVuoxMGFpa=mdAUcEWCrqIQygjNRtiJKVuoxMGFvl.get('videoid').strip()
     mdAUcEWCrqIQygjNRtiJKVuoxMGFpD=mdAUcEWCrqIQygjNRtiJKVuoxMGFpH.get('videoid').strip()if mdAUcEWCrqIQygjNRtiJKVuoxMGFpD!=mdAUcEWCrqIQygjNRtiJKVuoxMGFkB else '-'
    if mdAUcEWCrqIQygjNRtiJKVuoxMGFpa!=mdAUcEWCrqIQygjNRtiJKVuoxMGFpD:
     fp.write(mdAUcEWCrqIQygjNRtiJKVuoxMGFph)
     mdAUcEWCrqIQygjNRtiJKVuoxMGFpw+=1
     if mdAUcEWCrqIQygjNRtiJKVuoxMGFpw>=50:break
   fp.close()
  except:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFkB
 def dp_History_Remove(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP,args):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFpL=args.get('delType')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFpY =args.get('sKey')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFpf =args.get('vType')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvb=xbmcgui.Dialog()
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFpL=='SEARCH_ALL':
   mdAUcEWCrqIQygjNRtiJKVuoxMGFev=mdAUcEWCrqIQygjNRtiJKVuoxMGFvb.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif mdAUcEWCrqIQygjNRtiJKVuoxMGFpL=='SEARCH_ONE':
   mdAUcEWCrqIQygjNRtiJKVuoxMGFev=mdAUcEWCrqIQygjNRtiJKVuoxMGFvb.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif mdAUcEWCrqIQygjNRtiJKVuoxMGFpL=='WATCH_ALL':
   mdAUcEWCrqIQygjNRtiJKVuoxMGFev=mdAUcEWCrqIQygjNRtiJKVuoxMGFvb.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif mdAUcEWCrqIQygjNRtiJKVuoxMGFpL=='WATCH_ONE':
   mdAUcEWCrqIQygjNRtiJKVuoxMGFev=mdAUcEWCrqIQygjNRtiJKVuoxMGFvb.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFev==mdAUcEWCrqIQygjNRtiJKVuoxMGFkb:sys.exit()
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFpL=='SEARCH_ALL':
   if os.path.isfile(mdAUcEWCrqIQygjNRtiJKVuoxMGFvk):os.remove(mdAUcEWCrqIQygjNRtiJKVuoxMGFvk)
  elif mdAUcEWCrqIQygjNRtiJKVuoxMGFpL=='SEARCH_ONE':
   try:
    mdAUcEWCrqIQygjNRtiJKVuoxMGFpB=mdAUcEWCrqIQygjNRtiJKVuoxMGFvk
    mdAUcEWCrqIQygjNRtiJKVuoxMGFpb=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.Load_List_File('search') 
    fp=mdAUcEWCrqIQygjNRtiJKVuoxMGFkY(mdAUcEWCrqIQygjNRtiJKVuoxMGFpB,'w',-1,'utf-8')
    for mdAUcEWCrqIQygjNRtiJKVuoxMGFph in mdAUcEWCrqIQygjNRtiJKVuoxMGFpb:
     mdAUcEWCrqIQygjNRtiJKVuoxMGFpH=mdAUcEWCrqIQygjNRtiJKVuoxMGFkw(urllib.parse.parse_qsl(mdAUcEWCrqIQygjNRtiJKVuoxMGFph))
     mdAUcEWCrqIQygjNRtiJKVuoxMGFeX=mdAUcEWCrqIQygjNRtiJKVuoxMGFpH.get('skey').strip()
     if mdAUcEWCrqIQygjNRtiJKVuoxMGFpY!=mdAUcEWCrqIQygjNRtiJKVuoxMGFeX:
      fp.write(mdAUcEWCrqIQygjNRtiJKVuoxMGFph)
    fp.close()
   except:
    mdAUcEWCrqIQygjNRtiJKVuoxMGFkB
  elif mdAUcEWCrqIQygjNRtiJKVuoxMGFpL=='WATCH_ALL':
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpB=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%mdAUcEWCrqIQygjNRtiJKVuoxMGFpf))
   if os.path.isfile(mdAUcEWCrqIQygjNRtiJKVuoxMGFpB):os.remove(mdAUcEWCrqIQygjNRtiJKVuoxMGFpB)
  elif mdAUcEWCrqIQygjNRtiJKVuoxMGFpL=='WATCH_ONE':
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpB=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%mdAUcEWCrqIQygjNRtiJKVuoxMGFpf))
   try:
    mdAUcEWCrqIQygjNRtiJKVuoxMGFpb=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.Load_List_File(mdAUcEWCrqIQygjNRtiJKVuoxMGFpf) 
    fp=mdAUcEWCrqIQygjNRtiJKVuoxMGFkY(mdAUcEWCrqIQygjNRtiJKVuoxMGFpB,'w',-1,'utf-8')
    for mdAUcEWCrqIQygjNRtiJKVuoxMGFph in mdAUcEWCrqIQygjNRtiJKVuoxMGFpb:
     mdAUcEWCrqIQygjNRtiJKVuoxMGFpH=mdAUcEWCrqIQygjNRtiJKVuoxMGFkw(urllib.parse.parse_qsl(mdAUcEWCrqIQygjNRtiJKVuoxMGFph))
     mdAUcEWCrqIQygjNRtiJKVuoxMGFeX=mdAUcEWCrqIQygjNRtiJKVuoxMGFpH.get('code').strip()
     if mdAUcEWCrqIQygjNRtiJKVuoxMGFpY!=mdAUcEWCrqIQygjNRtiJKVuoxMGFeX:
      fp.write(mdAUcEWCrqIQygjNRtiJKVuoxMGFph)
    fp.close()
   except:
    mdAUcEWCrqIQygjNRtiJKVuoxMGFkB
  xbmc.executebuiltin("Container.Refresh")
 def Save_Searched_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP,mdAUcEWCrqIQygjNRtiJKVuoxMGFzX):
  try:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFez=mdAUcEWCrqIQygjNRtiJKVuoxMGFvk
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpb=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.Load_List_File('search') 
   mdAUcEWCrqIQygjNRtiJKVuoxMGFep={'skey':mdAUcEWCrqIQygjNRtiJKVuoxMGFzX.strip()}
   fp=mdAUcEWCrqIQygjNRtiJKVuoxMGFkY(mdAUcEWCrqIQygjNRtiJKVuoxMGFez,'w',-1,'utf-8')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpS=urllib.parse.urlencode(mdAUcEWCrqIQygjNRtiJKVuoxMGFep)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpS=mdAUcEWCrqIQygjNRtiJKVuoxMGFpS+'\n'
   fp.write(mdAUcEWCrqIQygjNRtiJKVuoxMGFpS)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpw=0
   for mdAUcEWCrqIQygjNRtiJKVuoxMGFph in mdAUcEWCrqIQygjNRtiJKVuoxMGFpb:
    mdAUcEWCrqIQygjNRtiJKVuoxMGFpH=mdAUcEWCrqIQygjNRtiJKVuoxMGFkw(urllib.parse.parse_qsl(mdAUcEWCrqIQygjNRtiJKVuoxMGFph))
    mdAUcEWCrqIQygjNRtiJKVuoxMGFpa=mdAUcEWCrqIQygjNRtiJKVuoxMGFep.get('skey').strip()
    mdAUcEWCrqIQygjNRtiJKVuoxMGFpD=mdAUcEWCrqIQygjNRtiJKVuoxMGFpH.get('skey').strip()
    if mdAUcEWCrqIQygjNRtiJKVuoxMGFpa!=mdAUcEWCrqIQygjNRtiJKVuoxMGFpD:
     fp.write(mdAUcEWCrqIQygjNRtiJKVuoxMGFph)
     mdAUcEWCrqIQygjNRtiJKVuoxMGFpw+=1
     if mdAUcEWCrqIQygjNRtiJKVuoxMGFpw>=50:break
   fp.close()
  except:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFkB
 def dp_Global_Search(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP,args):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFze=args.get('mode')
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFze=='TOTAL_SEARCH':
   mdAUcEWCrqIQygjNRtiJKVuoxMGFeO='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFeO='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(mdAUcEWCrqIQygjNRtiJKVuoxMGFeO)
 def dp_Bookmark_Menu(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP,args):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFeO='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(mdAUcEWCrqIQygjNRtiJKVuoxMGFeO)
 def login_main(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP):
  (mdAUcEWCrqIQygjNRtiJKVuoxMGFes,mdAUcEWCrqIQygjNRtiJKVuoxMGFek,mdAUcEWCrqIQygjNRtiJKVuoxMGFeP)=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.get_settings_account()
  if not(mdAUcEWCrqIQygjNRtiJKVuoxMGFes and mdAUcEWCrqIQygjNRtiJKVuoxMGFek):
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvb=xbmcgui.Dialog()
   mdAUcEWCrqIQygjNRtiJKVuoxMGFev=mdAUcEWCrqIQygjNRtiJKVuoxMGFvb.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if mdAUcEWCrqIQygjNRtiJKVuoxMGFev==mdAUcEWCrqIQygjNRtiJKVuoxMGFkT:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.cookiefile_check()==mdAUcEWCrqIQygjNRtiJKVuoxMGFkT:return
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   mdAUcEWCrqIQygjNRtiJKVuoxMGFen=0
   while mdAUcEWCrqIQygjNRtiJKVuoxMGFkT:
    mdAUcEWCrqIQygjNRtiJKVuoxMGFen+=1
    time.sleep(0.05)
    if mdAUcEWCrqIQygjNRtiJKVuoxMGFen>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFeB=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.GetCredential(mdAUcEWCrqIQygjNRtiJKVuoxMGFes,mdAUcEWCrqIQygjNRtiJKVuoxMGFek,mdAUcEWCrqIQygjNRtiJKVuoxMGFeP)
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFeB:mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFeB==mdAUcEWCrqIQygjNRtiJKVuoxMGFkb:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_setEpOrderby(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP,args):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFXB =args.get('orderby')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.set_winEpisodeOrderby(mdAUcEWCrqIQygjNRtiJKVuoxMGFXB)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP,args):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFze =args.get('mode')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFel =args.get('contentid')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFeT =args.get('pvrmode')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFeb=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.get_selQuality()
  mdAUcEWCrqIQygjNRtiJKVuoxMGFXp =mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.get_settings_play()
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.addon_log(mdAUcEWCrqIQygjNRtiJKVuoxMGFel+' - '+mdAUcEWCrqIQygjNRtiJKVuoxMGFze)
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFze=='SPORTS':
   mdAUcEWCrqIQygjNRtiJKVuoxMGFeS=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.GetSportsURL(mdAUcEWCrqIQygjNRtiJKVuoxMGFel,mdAUcEWCrqIQygjNRtiJKVuoxMGFeb)
  else:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFeS=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.GetStreamingURL(mdAUcEWCrqIQygjNRtiJKVuoxMGFze,mdAUcEWCrqIQygjNRtiJKVuoxMGFel,mdAUcEWCrqIQygjNRtiJKVuoxMGFeb,mdAUcEWCrqIQygjNRtiJKVuoxMGFeT,playOption=mdAUcEWCrqIQygjNRtiJKVuoxMGFXp)
  mdAUcEWCrqIQygjNRtiJKVuoxMGFew={'user-agent':mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.USER_AGENT}
  mdAUcEWCrqIQygjNRtiJKVuoxMGFeh=mdAUcEWCrqIQygjNRtiJKVuoxMGFeS['stream_cookie'] 
  mdAUcEWCrqIQygjNRtiJKVuoxMGFeH=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.make_stream_header(mdAUcEWCrqIQygjNRtiJKVuoxMGFew,mdAUcEWCrqIQygjNRtiJKVuoxMGFeh)
  mdAUcEWCrqIQygjNRtiJKVuoxMGFea='{}|{}'.format(mdAUcEWCrqIQygjNRtiJKVuoxMGFeS['stream_url'],mdAUcEWCrqIQygjNRtiJKVuoxMGFeH)
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.addon_log('surl : '+mdAUcEWCrqIQygjNRtiJKVuoxMGFea)
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFeS['stream_url']=='':
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.addon_noti(__language__(30907).encode('utf8'))
   return
  mdAUcEWCrqIQygjNRtiJKVuoxMGFXe,mdAUcEWCrqIQygjNRtiJKVuoxMGFXO=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.get_settings_proxyport()
  mdAUcEWCrqIQygjNRtiJKVuoxMGFeD=urllib.parse.urlparse(mdAUcEWCrqIQygjNRtiJKVuoxMGFeS['stream_url'])
  mdAUcEWCrqIQygjNRtiJKVuoxMGFeD=mdAUcEWCrqIQygjNRtiJKVuoxMGFeD.path.strip('/').split('/')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFeD=mdAUcEWCrqIQygjNRtiJKVuoxMGFeD[mdAUcEWCrqIQygjNRtiJKVuoxMGFka(mdAUcEWCrqIQygjNRtiJKVuoxMGFeD)-1] 
  if (mdAUcEWCrqIQygjNRtiJKVuoxMGFXe==mdAUcEWCrqIQygjNRtiJKVuoxMGFkT and args.get('mode')in['VOD','MOVIE']and(mdAUcEWCrqIQygjNRtiJKVuoxMGFeS['playParam']['hdr']=='hdr' or mdAUcEWCrqIQygjNRtiJKVuoxMGFeS['playParam']['uhd']=='uhd')):
   if mdAUcEWCrqIQygjNRtiJKVuoxMGFeD.split('.')[1]=='mpd':
    mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.Wavve_Parse_mpd(mdAUcEWCrqIQygjNRtiJKVuoxMGFeS)
   else:
    mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.Wavve_Parse_m3u8(mdAUcEWCrqIQygjNRtiJKVuoxMGFeS)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFeL={'addon':'wavvem','playOption':mdAUcEWCrqIQygjNRtiJKVuoxMGFXp,}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFeL=json.dumps(mdAUcEWCrqIQygjNRtiJKVuoxMGFeL,separators=(',',':'))
   mdAUcEWCrqIQygjNRtiJKVuoxMGFeL=base64.standard_b64encode(mdAUcEWCrqIQygjNRtiJKVuoxMGFeL.encode()).decode('utf-8')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFea ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(mdAUcEWCrqIQygjNRtiJKVuoxMGFXO,mdAUcEWCrqIQygjNRtiJKVuoxMGFea,mdAUcEWCrqIQygjNRtiJKVuoxMGFeL)
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.addon_log('surl : '+mdAUcEWCrqIQygjNRtiJKVuoxMGFea)
  mdAUcEWCrqIQygjNRtiJKVuoxMGFeY=xbmcgui.ListItem(path=mdAUcEWCrqIQygjNRtiJKVuoxMGFea)
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFeS['stream_drm']:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.addon_log('!!streaming_drm!!')
   if 'licensetoken' in mdAUcEWCrqIQygjNRtiJKVuoxMGFeS['stream_drm']:
    mdAUcEWCrqIQygjNRtiJKVuoxMGFef=mdAUcEWCrqIQygjNRtiJKVuoxMGFeS['stream_drm']['licensetoken']
    mdAUcEWCrqIQygjNRtiJKVuoxMGFOv =mdAUcEWCrqIQygjNRtiJKVuoxMGFeS['stream_drm']['licenseurl']
    if mdAUcEWCrqIQygjNRtiJKVuoxMGFze=='MOVIE':
     mdAUcEWCrqIQygjNRtiJKVuoxMGFOX='https://www.wavve.com/player/movie?movieid=%s'%mdAUcEWCrqIQygjNRtiJKVuoxMGFel
    else:
     mdAUcEWCrqIQygjNRtiJKVuoxMGFOX='https://www.wavve.com/player/vod?programid=%s&page=1'%mdAUcEWCrqIQygjNRtiJKVuoxMGFel
    mdAUcEWCrqIQygjNRtiJKVuoxMGFOz={'content-type':'application/octet-stream','origin':'https://www.wavve.com','License-Token':mdAUcEWCrqIQygjNRtiJKVuoxMGFef,'referer':mdAUcEWCrqIQygjNRtiJKVuoxMGFOX,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.USER_AGENT,}
   else:
    mdAUcEWCrqIQygjNRtiJKVuoxMGFef=mdAUcEWCrqIQygjNRtiJKVuoxMGFeS['stream_drm']['customdata']
    mdAUcEWCrqIQygjNRtiJKVuoxMGFOv =mdAUcEWCrqIQygjNRtiJKVuoxMGFeS['stream_drm']['drmhost']
    if mdAUcEWCrqIQygjNRtiJKVuoxMGFze=='MOVIE':
     mdAUcEWCrqIQygjNRtiJKVuoxMGFOX='https://www.wavve.com/player/movie?movieid=%s'%mdAUcEWCrqIQygjNRtiJKVuoxMGFel
    else:
     mdAUcEWCrqIQygjNRtiJKVuoxMGFOX='https://www.wavve.com/player/vod?programid=%s&page=1'%mdAUcEWCrqIQygjNRtiJKVuoxMGFel
    mdAUcEWCrqIQygjNRtiJKVuoxMGFOz={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':mdAUcEWCrqIQygjNRtiJKVuoxMGFef,'referer':mdAUcEWCrqIQygjNRtiJKVuoxMGFOX,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.USER_AGENT,}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFOp=mdAUcEWCrqIQygjNRtiJKVuoxMGFOv+'|'+urllib.parse.urlencode(mdAUcEWCrqIQygjNRtiJKVuoxMGFOz)+'|R{SSM}|'
   mdAUcEWCrqIQygjNRtiJKVuoxMGFeY.setProperty('inputstream','inputstream.adaptive')
   if mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.KodiVersion<=20:
    mdAUcEWCrqIQygjNRtiJKVuoxMGFeY.setProperty('inputstream.adaptive.manifest_type','mpd')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFeY.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFeY.setProperty('inputstream.adaptive.license_key',mdAUcEWCrqIQygjNRtiJKVuoxMGFOp)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFeY.setProperty('inputstream.adaptive.stream_headers',mdAUcEWCrqIQygjNRtiJKVuoxMGFeH)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFeY.setProperty('inputstream.adaptive.manifest_headers',mdAUcEWCrqIQygjNRtiJKVuoxMGFeH)
  elif mdAUcEWCrqIQygjNRtiJKVuoxMGFze in['VOD','MOVIE']:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFeY.setContentLookup(mdAUcEWCrqIQygjNRtiJKVuoxMGFkb)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFeY.setMimeType('application/x-mpegURL')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFeY.setProperty('inputstream','inputstream.adaptive')
   if mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.KodiVersion<=20:
    if mdAUcEWCrqIQygjNRtiJKVuoxMGFeS['stream_action']=='hls':
     mdAUcEWCrqIQygjNRtiJKVuoxMGFeY.setProperty('inputstream.adaptive.manifest_type','hls')
    else:
     mdAUcEWCrqIQygjNRtiJKVuoxMGFeY.setProperty('inputstream.adaptive.manifest_type','mpd')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFeY.setProperty('inputstream.adaptive.stream_headers',mdAUcEWCrqIQygjNRtiJKVuoxMGFeH)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFeY.setProperty('inputstream.adaptive.manifest_headers',mdAUcEWCrqIQygjNRtiJKVuoxMGFeH)
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFeS['stream_vtt']:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFeY.setSubtitles([mdAUcEWCrqIQygjNRtiJKVuoxMGFeS['stream_vtt']])
  xbmcplugin.setResolvedUrl(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP._addon_handle,mdAUcEWCrqIQygjNRtiJKVuoxMGFkT,mdAUcEWCrqIQygjNRtiJKVuoxMGFeY)
  mdAUcEWCrqIQygjNRtiJKVuoxMGFOe=mdAUcEWCrqIQygjNRtiJKVuoxMGFkb
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFeS['stream_preview']:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.addon_noti(mdAUcEWCrqIQygjNRtiJKVuoxMGFeS['stream_preview'].encode('utf-8'))
   mdAUcEWCrqIQygjNRtiJKVuoxMGFOe=mdAUcEWCrqIQygjNRtiJKVuoxMGFkT
  else:
   if '/preview.' in urllib.parse.urlsplit(mdAUcEWCrqIQygjNRtiJKVuoxMGFeS['stream_url']).path:
    mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.addon_noti(__language__(30908).encode('utf8'))
    mdAUcEWCrqIQygjNRtiJKVuoxMGFOe=mdAUcEWCrqIQygjNRtiJKVuoxMGFkT
  try:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFOs=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and mdAUcEWCrqIQygjNRtiJKVuoxMGFOe==mdAUcEWCrqIQygjNRtiJKVuoxMGFkb and mdAUcEWCrqIQygjNRtiJKVuoxMGFOs!='-':
    mdAUcEWCrqIQygjNRtiJKVuoxMGFXa={'code':mdAUcEWCrqIQygjNRtiJKVuoxMGFOs,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.Save_Watched_List(args.get('mode').lower(),mdAUcEWCrqIQygjNRtiJKVuoxMGFXa)
  except:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFkB
 def logout(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvb=xbmcgui.Dialog()
  mdAUcEWCrqIQygjNRtiJKVuoxMGFev=mdAUcEWCrqIQygjNRtiJKVuoxMGFvb.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFev==mdAUcEWCrqIQygjNRtiJKVuoxMGFkb:sys.exit()
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.Init_WV_Total()
  if os.path.isfile(mdAUcEWCrqIQygjNRtiJKVuoxMGFvs):os.remove(mdAUcEWCrqIQygjNRtiJKVuoxMGFvs)
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFOk =mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.Get_Now_Datetime()
  mdAUcEWCrqIQygjNRtiJKVuoxMGFOP=mdAUcEWCrqIQygjNRtiJKVuoxMGFOk+datetime.timedelta(days=mdAUcEWCrqIQygjNRtiJKVuoxMGFkl(__addon__.getSetting('cache_ttl')))
  (mdAUcEWCrqIQygjNRtiJKVuoxMGFes,mdAUcEWCrqIQygjNRtiJKVuoxMGFek,mdAUcEWCrqIQygjNRtiJKVuoxMGFeP)=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.get_settings_account()
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.Save_session_acount(mdAUcEWCrqIQygjNRtiJKVuoxMGFes,mdAUcEWCrqIQygjNRtiJKVuoxMGFek,mdAUcEWCrqIQygjNRtiJKVuoxMGFeP)
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.WV['account']['token_limit']=mdAUcEWCrqIQygjNRtiJKVuoxMGFOP.strftime('%Y%m%d')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.JsonFile_Save(mdAUcEWCrqIQygjNRtiJKVuoxMGFvs,mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.WV)
 def cookiefile_check(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.WV=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.JsonFile_Load(mdAUcEWCrqIQygjNRtiJKVuoxMGFvs)
  if 'account' not in mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.WV:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.Init_WV_Total()
   return mdAUcEWCrqIQygjNRtiJKVuoxMGFkb
  if 'uuid' not in mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.WV.get('cookies'):
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.Init_WV_Total()
   return mdAUcEWCrqIQygjNRtiJKVuoxMGFkb
  (mdAUcEWCrqIQygjNRtiJKVuoxMGFOn,mdAUcEWCrqIQygjNRtiJKVuoxMGFOB,mdAUcEWCrqIQygjNRtiJKVuoxMGFOl)=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.get_settings_account()
  (mdAUcEWCrqIQygjNRtiJKVuoxMGFOT,mdAUcEWCrqIQygjNRtiJKVuoxMGFOb,mdAUcEWCrqIQygjNRtiJKVuoxMGFOS)=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.Load_session_acount()
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFOn!=mdAUcEWCrqIQygjNRtiJKVuoxMGFOT or mdAUcEWCrqIQygjNRtiJKVuoxMGFOB!=mdAUcEWCrqIQygjNRtiJKVuoxMGFOb or mdAUcEWCrqIQygjNRtiJKVuoxMGFOl!=mdAUcEWCrqIQygjNRtiJKVuoxMGFOS:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.Init_WV_Total()
   return mdAUcEWCrqIQygjNRtiJKVuoxMGFkb
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFkl(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))>mdAUcEWCrqIQygjNRtiJKVuoxMGFkl(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.WV['account']['token_limit']):
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.Init_WV_Total()
   return mdAUcEWCrqIQygjNRtiJKVuoxMGFkb
  return mdAUcEWCrqIQygjNRtiJKVuoxMGFkT
 def dp_LiveCatagory_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP,args):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFOw =args.get('sCode')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFOh=args.get('sIndex')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFzL,mdAUcEWCrqIQygjNRtiJKVuoxMGFOH=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.Get_LiveCatagory_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFOw,mdAUcEWCrqIQygjNRtiJKVuoxMGFOh)
  for mdAUcEWCrqIQygjNRtiJKVuoxMGFzY in mdAUcEWCrqIQygjNRtiJKVuoxMGFzL:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXT =mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('title')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa={'mode':'LIVE_LIST','genre':mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('genre'),'baseapi':mdAUcEWCrqIQygjNRtiJKVuoxMGFOH}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXY={'title':mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,'plot':mdAUcEWCrqIQygjNRtiJKVuoxMGFXT}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.add_dir(mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,sublabel='',img='',infoLabels=mdAUcEWCrqIQygjNRtiJKVuoxMGFXY,isFolder=mdAUcEWCrqIQygjNRtiJKVuoxMGFkT,params=mdAUcEWCrqIQygjNRtiJKVuoxMGFXa)
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFka(mdAUcEWCrqIQygjNRtiJKVuoxMGFzL)>0:xbmcplugin.endOfDirectory(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP._addon_handle,cacheToDisc=mdAUcEWCrqIQygjNRtiJKVuoxMGFkb)
 def dp_MainCatagory_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP,args):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFOw =args.get('sCode')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFOh=args.get('sIndex')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFzO =args.get('sType')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFzL=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.Get_MainCatagory_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFOw,mdAUcEWCrqIQygjNRtiJKVuoxMGFOh,mdAUcEWCrqIQygjNRtiJKVuoxMGFzO)
  for mdAUcEWCrqIQygjNRtiJKVuoxMGFzY in mdAUcEWCrqIQygjNRtiJKVuoxMGFzL:
   if mdAUcEWCrqIQygjNRtiJKVuoxMGFzO in['vod','vod09']:
    if mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('subtype')=='catagory':
     mdAUcEWCrqIQygjNRtiJKVuoxMGFze='PROGRAM_LIST'
    else:
     mdAUcEWCrqIQygjNRtiJKVuoxMGFze='SUPERSECTION_LIST'
   elif mdAUcEWCrqIQygjNRtiJKVuoxMGFzO=='movie':
    mdAUcEWCrqIQygjNRtiJKVuoxMGFze='MOVIE_LIST'
   else:
    mdAUcEWCrqIQygjNRtiJKVuoxMGFze=''
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXT='%s (%s)'%(mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('title'),args.get('ordernm'))
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa={'mode':mdAUcEWCrqIQygjNRtiJKVuoxMGFze,'suburl':mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('suburl'),'subapi':mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.get_settings_exclusion21():
    if mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('title')=='성인' or mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('title')=='성인+' or mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('title')=='에로티시즘' or mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('title')=='19':continue
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXY={'title':mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,'plot':mdAUcEWCrqIQygjNRtiJKVuoxMGFXT}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.add_dir(mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,sublabel='',img='',infoLabels=mdAUcEWCrqIQygjNRtiJKVuoxMGFXY,isFolder=mdAUcEWCrqIQygjNRtiJKVuoxMGFkT,params=mdAUcEWCrqIQygjNRtiJKVuoxMGFXa)
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFka(mdAUcEWCrqIQygjNRtiJKVuoxMGFzL)>0:xbmcplugin.endOfDirectory(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP._addon_handle,cacheToDisc=mdAUcEWCrqIQygjNRtiJKVuoxMGFkb)
 def dp_Program_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP,args):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFOa =args.get('subapi')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFzD=mdAUcEWCrqIQygjNRtiJKVuoxMGFkl(args.get('page'))
  mdAUcEWCrqIQygjNRtiJKVuoxMGFXB =args.get('orderby')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.addon_log('dp_Program_List')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.addon_log(mdAUcEWCrqIQygjNRtiJKVuoxMGFOa)
  mdAUcEWCrqIQygjNRtiJKVuoxMGFzL,mdAUcEWCrqIQygjNRtiJKVuoxMGFzk=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.Get_Program_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFOa,mdAUcEWCrqIQygjNRtiJKVuoxMGFzD,mdAUcEWCrqIQygjNRtiJKVuoxMGFXB)
  for mdAUcEWCrqIQygjNRtiJKVuoxMGFzY in mdAUcEWCrqIQygjNRtiJKVuoxMGFzL:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFzf =mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('videoid')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpv =mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('vidtype')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXT =mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('title')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpX=mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('thumbnail')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpz =mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('age')
   if mdAUcEWCrqIQygjNRtiJKVuoxMGFpz=='18' or mdAUcEWCrqIQygjNRtiJKVuoxMGFpz=='19' or mdAUcEWCrqIQygjNRtiJKVuoxMGFpz=='21':mdAUcEWCrqIQygjNRtiJKVuoxMGFXT+=' (%s)'%(mdAUcEWCrqIQygjNRtiJKVuoxMGFpz)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXY={'plot':mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,'mpaa':mdAUcEWCrqIQygjNRtiJKVuoxMGFpz,'mediatype':'tvshow','title':mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa={'mode':'SEASON_LIST','videoid':mdAUcEWCrqIQygjNRtiJKVuoxMGFzf,'vidtype':mdAUcEWCrqIQygjNRtiJKVuoxMGFpv,}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFzH=[]
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpe={'mode':'VIEW_DETAIL','values':{'videoid':mdAUcEWCrqIQygjNRtiJKVuoxMGFzf,'vidtype':'tvshow','contenttype':mdAUcEWCrqIQygjNRtiJKVuoxMGFpv,}}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpO=json.dumps(mdAUcEWCrqIQygjNRtiJKVuoxMGFpe,separators=(',',':'))
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpO=base64.standard_b64encode(mdAUcEWCrqIQygjNRtiJKVuoxMGFpO.encode()).decode('utf-8')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpO=mdAUcEWCrqIQygjNRtiJKVuoxMGFpO.replace('+','%2B')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFps='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(mdAUcEWCrqIQygjNRtiJKVuoxMGFpO)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFzH.append(('상세정보 조회',mdAUcEWCrqIQygjNRtiJKVuoxMGFps))
   if mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.get_settings_makebookmark():
    mdAUcEWCrqIQygjNRtiJKVuoxMGFpe={'videoid':mdAUcEWCrqIQygjNRtiJKVuoxMGFzf,'vidtype':'tvshow','vtitle':mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,'vsubtitle':'','contenttype':mdAUcEWCrqIQygjNRtiJKVuoxMGFpv,}
    mdAUcEWCrqIQygjNRtiJKVuoxMGFpk=json.dumps(mdAUcEWCrqIQygjNRtiJKVuoxMGFpe)
    mdAUcEWCrqIQygjNRtiJKVuoxMGFpk=urllib.parse.quote(mdAUcEWCrqIQygjNRtiJKVuoxMGFpk)
    mdAUcEWCrqIQygjNRtiJKVuoxMGFps='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(mdAUcEWCrqIQygjNRtiJKVuoxMGFpk)
    mdAUcEWCrqIQygjNRtiJKVuoxMGFzH.append(('(통합) 찜 영상에 추가',mdAUcEWCrqIQygjNRtiJKVuoxMGFps))
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.add_dir(mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,sublabel='',img=mdAUcEWCrqIQygjNRtiJKVuoxMGFpX,infoLabels=mdAUcEWCrqIQygjNRtiJKVuoxMGFXY,isFolder=mdAUcEWCrqIQygjNRtiJKVuoxMGFkT,params=mdAUcEWCrqIQygjNRtiJKVuoxMGFXa,ContextMenu=mdAUcEWCrqIQygjNRtiJKVuoxMGFzH)
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFzk:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa={}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa['mode'] ='PROGRAM_LIST' 
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa['subapi']=mdAUcEWCrqIQygjNRtiJKVuoxMGFOa 
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa['page'] =mdAUcEWCrqIQygjNRtiJKVuoxMGFkL(mdAUcEWCrqIQygjNRtiJKVuoxMGFzD+1)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXT='[B]%s >>[/B]'%'다음 페이지'
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpP=mdAUcEWCrqIQygjNRtiJKVuoxMGFkL(mdAUcEWCrqIQygjNRtiJKVuoxMGFzD+1)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.add_dir(mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,sublabel=mdAUcEWCrqIQygjNRtiJKVuoxMGFpP,img=mdAUcEWCrqIQygjNRtiJKVuoxMGFXH,infoLabels=mdAUcEWCrqIQygjNRtiJKVuoxMGFkB,isFolder=mdAUcEWCrqIQygjNRtiJKVuoxMGFkT,params=mdAUcEWCrqIQygjNRtiJKVuoxMGFXa)
  xbmcplugin.setContent(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP._addon_handle,'tvshows')
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFka(mdAUcEWCrqIQygjNRtiJKVuoxMGFzL)>0:xbmcplugin.endOfDirectory(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP._addon_handle,cacheToDisc=mdAUcEWCrqIQygjNRtiJKVuoxMGFkb)
 def dp_Season_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP,args):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFzf=args.get('videoid')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFpv=args.get('vidtype')
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFpv=='contentid':
   mdAUcEWCrqIQygjNRtiJKVuoxMGFel=mdAUcEWCrqIQygjNRtiJKVuoxMGFzf
   mdAUcEWCrqIQygjNRtiJKVuoxMGFOD =mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.ContentidToSeasonid(mdAUcEWCrqIQygjNRtiJKVuoxMGFzf)
  else:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFel=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.ProgramidToContentid(mdAUcEWCrqIQygjNRtiJKVuoxMGFzf)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFOD =mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.ContentidToSeasonid(mdAUcEWCrqIQygjNRtiJKVuoxMGFel)
  mdAUcEWCrqIQygjNRtiJKVuoxMGFOL=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.Get_Season_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFOD)
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFka(mdAUcEWCrqIQygjNRtiJKVuoxMGFOL)>1:
   for mdAUcEWCrqIQygjNRtiJKVuoxMGFOY in mdAUcEWCrqIQygjNRtiJKVuoxMGFOL:
    mdAUcEWCrqIQygjNRtiJKVuoxMGFOf=mdAUcEWCrqIQygjNRtiJKVuoxMGFOY.get('season_Id')
    mdAUcEWCrqIQygjNRtiJKVuoxMGFsv=mdAUcEWCrqIQygjNRtiJKVuoxMGFOY.get('season_Nm')
    mdAUcEWCrqIQygjNRtiJKVuoxMGFsX=mdAUcEWCrqIQygjNRtiJKVuoxMGFOY.get('programNm')
    mdAUcEWCrqIQygjNRtiJKVuoxMGFpX=mdAUcEWCrqIQygjNRtiJKVuoxMGFOY.get('thumbnail')
    mdAUcEWCrqIQygjNRtiJKVuoxMGFsz =mdAUcEWCrqIQygjNRtiJKVuoxMGFOY.get('synopsis')
    mdAUcEWCrqIQygjNRtiJKVuoxMGFza={'mediatype':'tvshow','title':mdAUcEWCrqIQygjNRtiJKVuoxMGFsv,'plot':mdAUcEWCrqIQygjNRtiJKVuoxMGFsz,}
    mdAUcEWCrqIQygjNRtiJKVuoxMGFXa={'mode':'EPISODE_LIST','seasonid':mdAUcEWCrqIQygjNRtiJKVuoxMGFOf,'page':'1',}
    mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.add_dir(mdAUcEWCrqIQygjNRtiJKVuoxMGFsv,sublabel=mdAUcEWCrqIQygjNRtiJKVuoxMGFsX,img=mdAUcEWCrqIQygjNRtiJKVuoxMGFpX,infoLabels=mdAUcEWCrqIQygjNRtiJKVuoxMGFza,isFolder=mdAUcEWCrqIQygjNRtiJKVuoxMGFkT,params=mdAUcEWCrqIQygjNRtiJKVuoxMGFXa,ContextMenu=mdAUcEWCrqIQygjNRtiJKVuoxMGFkB)
   xbmcplugin.setContent(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP._addon_handle,'seasons')
   xbmcplugin.endOfDirectory(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP._addon_handle,cacheToDisc=mdAUcEWCrqIQygjNRtiJKVuoxMGFkb)
  else:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFsp={'seasonid':mdAUcEWCrqIQygjNRtiJKVuoxMGFOD,'page':'1',}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.dp_Episode_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFsp)
 def dp_Episode_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP,args):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFOD =args.get('seasonid')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFzD =mdAUcEWCrqIQygjNRtiJKVuoxMGFkl(args.get('page'))
  mdAUcEWCrqIQygjNRtiJKVuoxMGFzL,mdAUcEWCrqIQygjNRtiJKVuoxMGFzk=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.Get_Episode_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFOD,mdAUcEWCrqIQygjNRtiJKVuoxMGFzD,orderby=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.get_winEpisodeOrderby())
  for mdAUcEWCrqIQygjNRtiJKVuoxMGFzY in mdAUcEWCrqIQygjNRtiJKVuoxMGFzL:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpP=mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('episodenumber')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFse ='[%s]\n\n%s'%(mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('episodetitle'),mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('synopsis'))
   mdAUcEWCrqIQygjNRtiJKVuoxMGFza={'mediatype':'episode','title':mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('programtitle'),'plot':mdAUcEWCrqIQygjNRtiJKVuoxMGFse,'cast':mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('episodeactors'),}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa={'mode':'VOD','programid':mdAUcEWCrqIQygjNRtiJKVuoxMGFOD,'contentid':mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('contentid'),'thumbnail':mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('thumbnail'),'title':mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('programtitle'),'subtitle':mdAUcEWCrqIQygjNRtiJKVuoxMGFpP,}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.add_dir(mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('programtitle'),sublabel=mdAUcEWCrqIQygjNRtiJKVuoxMGFpP,img=mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('thumbnail'),infoLabels=mdAUcEWCrqIQygjNRtiJKVuoxMGFza,isFolder=mdAUcEWCrqIQygjNRtiJKVuoxMGFkb,params=mdAUcEWCrqIQygjNRtiJKVuoxMGFXa)
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFzD==1:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFza={'plot':'정렬순서를 변경합니다.'}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa={}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa['mode'] ='ORDER_BY' 
   if mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.get_winEpisodeOrderby()=='desc':
    mdAUcEWCrqIQygjNRtiJKVuoxMGFXT='정렬순서변경 : 최신화부터 -> 1회부터'
    mdAUcEWCrqIQygjNRtiJKVuoxMGFXa['orderby']='asc'
   else:
    mdAUcEWCrqIQygjNRtiJKVuoxMGFXT='정렬순서변경 : 1회부터 -> 최신화부터'
    mdAUcEWCrqIQygjNRtiJKVuoxMGFXa['orderby']='desc'
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.add_dir(mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,sublabel='',img=mdAUcEWCrqIQygjNRtiJKVuoxMGFXH,infoLabels=mdAUcEWCrqIQygjNRtiJKVuoxMGFza,isFolder=mdAUcEWCrqIQygjNRtiJKVuoxMGFkb,params=mdAUcEWCrqIQygjNRtiJKVuoxMGFXa,isLink=mdAUcEWCrqIQygjNRtiJKVuoxMGFkT)
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFzk:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa={}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa['mode'] ='EPISODE_LIST' 
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa['seasonid']=mdAUcEWCrqIQygjNRtiJKVuoxMGFOD
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa['page'] =mdAUcEWCrqIQygjNRtiJKVuoxMGFkL(mdAUcEWCrqIQygjNRtiJKVuoxMGFzD+1)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXT='[B]%s >>[/B]'%'다음 페이지'
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpP=mdAUcEWCrqIQygjNRtiJKVuoxMGFkL(mdAUcEWCrqIQygjNRtiJKVuoxMGFzD+1)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.add_dir(mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,sublabel=mdAUcEWCrqIQygjNRtiJKVuoxMGFpP,img=mdAUcEWCrqIQygjNRtiJKVuoxMGFXH,infoLabels=mdAUcEWCrqIQygjNRtiJKVuoxMGFkB,isFolder=mdAUcEWCrqIQygjNRtiJKVuoxMGFkT,params=mdAUcEWCrqIQygjNRtiJKVuoxMGFXa)
  xbmcplugin.setContent(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP._addon_handle,'episodes')
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFka(mdAUcEWCrqIQygjNRtiJKVuoxMGFzL)>0:xbmcplugin.endOfDirectory(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP._addon_handle,cacheToDisc=mdAUcEWCrqIQygjNRtiJKVuoxMGFkb)
 def dp_SuperSection_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP,args):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFsO =args.get('suburl')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFOa =args.get('subapi')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.addon_log('dp_SuperSection_List')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.addon_log('suburl : '+mdAUcEWCrqIQygjNRtiJKVuoxMGFsO)
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.addon_log('subapi : '+mdAUcEWCrqIQygjNRtiJKVuoxMGFOa)
  mdAUcEWCrqIQygjNRtiJKVuoxMGFzL=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.Get_SuperMultiSection_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFsO)
  for mdAUcEWCrqIQygjNRtiJKVuoxMGFzY in mdAUcEWCrqIQygjNRtiJKVuoxMGFzL:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXT =mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('title')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFOa =mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('subapi')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFsk=mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('cell_type')
   if mdAUcEWCrqIQygjNRtiJKVuoxMGFOa.find('contenttype=movie')>=0 or mdAUcEWCrqIQygjNRtiJKVuoxMGFOa.find('mtype=svod')>=0:
    mdAUcEWCrqIQygjNRtiJKVuoxMGFze='MOVIE_LIST'
   elif re.search('themes/2\d{4}',mdAUcEWCrqIQygjNRtiJKVuoxMGFOa)or re.search('themes-band/9\d{4}',mdAUcEWCrqIQygjNRtiJKVuoxMGFOa):
    mdAUcEWCrqIQygjNRtiJKVuoxMGFze='MOVIE_LIST'
   else:
    mdAUcEWCrqIQygjNRtiJKVuoxMGFze='PROGRAM_LIST'
   '''
   if subapi.find('mtype=svod') >= 0 or subapi.find('mtype=ppv') >= 0 or subapi.find('contenttype=movie') >= 0: #영화 #20201107
    mode = 'MOVIE_LIST'
   elif subapi.find('contenttype=program') >= 0:
    mode = 'PROGRAM_LIST'
   elif cell_type == 'band_71': # band_71 #20201107
    mode   = 'SUPERSECTION_LIST'
    (temp_url, temp_api) = self.WavveObj.Baseapi_Parse(subapi)
    suburl = temp_api.get('api')
    subapi = ''
   elif cell_type == 'band_2': # band_2
    mode = 'BAND2SECTION_LIST'
   elif cell_type == 'band_live':
    mode = 'BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}', subapi) :
    mode = 'MOVIE_LIST'
   else: # band_10
    mode = 'PROGRAM_LIST'
   '''   
   mdAUcEWCrqIQygjNRtiJKVuoxMGFza={'plot':mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,'mediatype':'tvshow',}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa={'mode':mdAUcEWCrqIQygjNRtiJKVuoxMGFze,'suburl':mdAUcEWCrqIQygjNRtiJKVuoxMGFsO,'subapi':mdAUcEWCrqIQygjNRtiJKVuoxMGFOa,'page':'1',}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.add_dir(mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,sublabel='',img=mdAUcEWCrqIQygjNRtiJKVuoxMGFkB,infoLabels=mdAUcEWCrqIQygjNRtiJKVuoxMGFza,isFolder=mdAUcEWCrqIQygjNRtiJKVuoxMGFkT,params=mdAUcEWCrqIQygjNRtiJKVuoxMGFXa)
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFka(mdAUcEWCrqIQygjNRtiJKVuoxMGFzL)>0:xbmcplugin.endOfDirectory(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP._addon_handle,cacheToDisc=mdAUcEWCrqIQygjNRtiJKVuoxMGFkb)
 def dp_BandLiveSection_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP,args):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFOa =args.get('subapi')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFzD=mdAUcEWCrqIQygjNRtiJKVuoxMGFkl(args.get('page'))
  mdAUcEWCrqIQygjNRtiJKVuoxMGFzL,mdAUcEWCrqIQygjNRtiJKVuoxMGFzk=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.Get_BandLiveSection_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFOa,mdAUcEWCrqIQygjNRtiJKVuoxMGFzD)
  for mdAUcEWCrqIQygjNRtiJKVuoxMGFzY in mdAUcEWCrqIQygjNRtiJKVuoxMGFzL:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFsP =mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('channelid')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFsn =mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('studio')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFsB=mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('tvshowtitle')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpX =mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('thumbnail')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpz =mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('age')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFza={'mediatype':'tvshow','mpaa':mdAUcEWCrqIQygjNRtiJKVuoxMGFpz,'title':'%s < %s >'%(mdAUcEWCrqIQygjNRtiJKVuoxMGFsn,mdAUcEWCrqIQygjNRtiJKVuoxMGFsB),'tvshowtitle':mdAUcEWCrqIQygjNRtiJKVuoxMGFsB,'studio':mdAUcEWCrqIQygjNRtiJKVuoxMGFsn,'plot':mdAUcEWCrqIQygjNRtiJKVuoxMGFsn}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa={'mode':'LIVE','contentid':mdAUcEWCrqIQygjNRtiJKVuoxMGFsP}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.add_dir(mdAUcEWCrqIQygjNRtiJKVuoxMGFsn,sublabel=mdAUcEWCrqIQygjNRtiJKVuoxMGFsB,img=mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('thumbnail'),infoLabels=mdAUcEWCrqIQygjNRtiJKVuoxMGFza,isFolder=mdAUcEWCrqIQygjNRtiJKVuoxMGFkb,params=mdAUcEWCrqIQygjNRtiJKVuoxMGFXa)
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFzk:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa={}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa['mode'] ='BANDLIVESECTION_LIST' 
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa['subapi']=mdAUcEWCrqIQygjNRtiJKVuoxMGFOa
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa['page'] =mdAUcEWCrqIQygjNRtiJKVuoxMGFkL(mdAUcEWCrqIQygjNRtiJKVuoxMGFzD+1)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXT='[B]%s >>[/B]'%'다음 페이지'
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpP=mdAUcEWCrqIQygjNRtiJKVuoxMGFkL(mdAUcEWCrqIQygjNRtiJKVuoxMGFzD+1)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.add_dir(mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,sublabel=mdAUcEWCrqIQygjNRtiJKVuoxMGFpP,img=mdAUcEWCrqIQygjNRtiJKVuoxMGFXH,infoLabels=mdAUcEWCrqIQygjNRtiJKVuoxMGFkB,isFolder=mdAUcEWCrqIQygjNRtiJKVuoxMGFkT,params=mdAUcEWCrqIQygjNRtiJKVuoxMGFXa)
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFka(mdAUcEWCrqIQygjNRtiJKVuoxMGFzL)>0:xbmcplugin.endOfDirectory(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP._addon_handle,cacheToDisc=mdAUcEWCrqIQygjNRtiJKVuoxMGFkb)
 def dp_Band2Section_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP,args):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFOa =args.get('subapi')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFzD=mdAUcEWCrqIQygjNRtiJKVuoxMGFkl(args.get('page'))
  mdAUcEWCrqIQygjNRtiJKVuoxMGFzL,mdAUcEWCrqIQygjNRtiJKVuoxMGFzk=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.Get_Band2Section_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFOa,mdAUcEWCrqIQygjNRtiJKVuoxMGFzD)
  for mdAUcEWCrqIQygjNRtiJKVuoxMGFzY in mdAUcEWCrqIQygjNRtiJKVuoxMGFzL:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXT =mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('programtitle')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpP =mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('episodetitle')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFza={'plot':mdAUcEWCrqIQygjNRtiJKVuoxMGFXT+'\n\n'+mdAUcEWCrqIQygjNRtiJKVuoxMGFpP,'mpaa':mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('age'),'mediatype':'episode'}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa={'mode':'VOD','programid':'-','contentid':mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('videoid'),'thumbnail':mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('thumbnail'),'title':mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,'subtitle':mdAUcEWCrqIQygjNRtiJKVuoxMGFpP}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.add_dir(mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,sublabel=mdAUcEWCrqIQygjNRtiJKVuoxMGFpP,img=mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('thumbnail'),infoLabels=mdAUcEWCrqIQygjNRtiJKVuoxMGFza,isFolder=mdAUcEWCrqIQygjNRtiJKVuoxMGFkb,params=mdAUcEWCrqIQygjNRtiJKVuoxMGFXa)
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFzk:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa={}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa['mode'] ='BAND2SECTION_LIST' 
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa['subapi']=mdAUcEWCrqIQygjNRtiJKVuoxMGFOa
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa['page'] =mdAUcEWCrqIQygjNRtiJKVuoxMGFkL(mdAUcEWCrqIQygjNRtiJKVuoxMGFzD+1)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXT='[B]%s >>[/B]'%'다음 페이지'
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpP=mdAUcEWCrqIQygjNRtiJKVuoxMGFkL(mdAUcEWCrqIQygjNRtiJKVuoxMGFzD+1)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.add_dir(mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,sublabel=mdAUcEWCrqIQygjNRtiJKVuoxMGFpP,img=mdAUcEWCrqIQygjNRtiJKVuoxMGFXH,infoLabels=mdAUcEWCrqIQygjNRtiJKVuoxMGFkB,isFolder=mdAUcEWCrqIQygjNRtiJKVuoxMGFkT,params=mdAUcEWCrqIQygjNRtiJKVuoxMGFXa)
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFka(mdAUcEWCrqIQygjNRtiJKVuoxMGFzL)>0:xbmcplugin.endOfDirectory(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP._addon_handle,cacheToDisc=mdAUcEWCrqIQygjNRtiJKVuoxMGFkb)
 def dp_Movie_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP,args):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFOa =args.get('subapi')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFzD=mdAUcEWCrqIQygjNRtiJKVuoxMGFkl(args.get('page'))
  mdAUcEWCrqIQygjNRtiJKVuoxMGFXB =args.get('orderby')or '-'
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.addon_log('dp_Movie_List')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.addon_log(mdAUcEWCrqIQygjNRtiJKVuoxMGFOa)
  mdAUcEWCrqIQygjNRtiJKVuoxMGFzL,mdAUcEWCrqIQygjNRtiJKVuoxMGFzk=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.Get_Movie_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFOa,mdAUcEWCrqIQygjNRtiJKVuoxMGFzD,mdAUcEWCrqIQygjNRtiJKVuoxMGFXB)
  for mdAUcEWCrqIQygjNRtiJKVuoxMGFzY in mdAUcEWCrqIQygjNRtiJKVuoxMGFzL:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFzf =mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('videoid')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpv =mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('vidtype')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXT =mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('title')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpX=mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('thumbnail')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpz =mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('age')
   if mdAUcEWCrqIQygjNRtiJKVuoxMGFpz=='18' or mdAUcEWCrqIQygjNRtiJKVuoxMGFpz=='19' or mdAUcEWCrqIQygjNRtiJKVuoxMGFpz=='21':mdAUcEWCrqIQygjNRtiJKVuoxMGFXT+=' (%s)'%(mdAUcEWCrqIQygjNRtiJKVuoxMGFpz)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFza={'plot':mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,'mpaa':mdAUcEWCrqIQygjNRtiJKVuoxMGFpz,'mediatype':'movie'}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa={'mode':'MOVIE','contentid':mdAUcEWCrqIQygjNRtiJKVuoxMGFzf,'title':mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,'thumbnail':mdAUcEWCrqIQygjNRtiJKVuoxMGFpX,'age':mdAUcEWCrqIQygjNRtiJKVuoxMGFpz,}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFzH=[]
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpe={'mode':'VIEW_DETAIL','values':{'videoid':mdAUcEWCrqIQygjNRtiJKVuoxMGFzf,'vidtype':'movie','contenttype':mdAUcEWCrqIQygjNRtiJKVuoxMGFpv,}}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpO=json.dumps(mdAUcEWCrqIQygjNRtiJKVuoxMGFpe,separators=(',',':'))
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpO=base64.standard_b64encode(mdAUcEWCrqIQygjNRtiJKVuoxMGFpO.encode()).decode('utf-8')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpO=mdAUcEWCrqIQygjNRtiJKVuoxMGFpO.replace('+','%2B')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFps='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(mdAUcEWCrqIQygjNRtiJKVuoxMGFpO)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFzH.append(('상세정보 조회',mdAUcEWCrqIQygjNRtiJKVuoxMGFps))
   if mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.get_settings_makebookmark():
    mdAUcEWCrqIQygjNRtiJKVuoxMGFpe={'videoid':mdAUcEWCrqIQygjNRtiJKVuoxMGFzf,'vidtype':'movie','vtitle':mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,'vsubtitle':'','contenttype':'programid',}
    mdAUcEWCrqIQygjNRtiJKVuoxMGFpk=json.dumps(mdAUcEWCrqIQygjNRtiJKVuoxMGFpe)
    mdAUcEWCrqIQygjNRtiJKVuoxMGFpk=urllib.parse.quote(mdAUcEWCrqIQygjNRtiJKVuoxMGFpk)
    mdAUcEWCrqIQygjNRtiJKVuoxMGFps='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(mdAUcEWCrqIQygjNRtiJKVuoxMGFpk)
    mdAUcEWCrqIQygjNRtiJKVuoxMGFzH.append(('(통합) 찜 영상에 추가',mdAUcEWCrqIQygjNRtiJKVuoxMGFps))
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.add_dir(mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,sublabel='',img=mdAUcEWCrqIQygjNRtiJKVuoxMGFpX,infoLabels=mdAUcEWCrqIQygjNRtiJKVuoxMGFza,isFolder=mdAUcEWCrqIQygjNRtiJKVuoxMGFkb,params=mdAUcEWCrqIQygjNRtiJKVuoxMGFXa,ContextMenu=mdAUcEWCrqIQygjNRtiJKVuoxMGFzH)
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFzk:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa={}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa['mode'] ='MOVIE_LIST' 
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa['subapi']=mdAUcEWCrqIQygjNRtiJKVuoxMGFOa 
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa['page'] =mdAUcEWCrqIQygjNRtiJKVuoxMGFkL(mdAUcEWCrqIQygjNRtiJKVuoxMGFzD+1)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa['orderby']=mdAUcEWCrqIQygjNRtiJKVuoxMGFXB
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXT='[B]%s >>[/B]'%'다음 페이지'
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpP=mdAUcEWCrqIQygjNRtiJKVuoxMGFkL(mdAUcEWCrqIQygjNRtiJKVuoxMGFzD+1)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.add_dir(mdAUcEWCrqIQygjNRtiJKVuoxMGFXT,sublabel=mdAUcEWCrqIQygjNRtiJKVuoxMGFpP,img=mdAUcEWCrqIQygjNRtiJKVuoxMGFXH,infoLabels=mdAUcEWCrqIQygjNRtiJKVuoxMGFkB,isFolder=mdAUcEWCrqIQygjNRtiJKVuoxMGFkT,params=mdAUcEWCrqIQygjNRtiJKVuoxMGFXa)
  xbmcplugin.setContent(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP._addon_handle,'movies')
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFka(mdAUcEWCrqIQygjNRtiJKVuoxMGFzL)>0:xbmcplugin.endOfDirectory(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP._addon_handle,cacheToDisc=mdAUcEWCrqIQygjNRtiJKVuoxMGFkb)
 def dp_Set_Bookmark(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP,args):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFsl=urllib.parse.unquote(args.get('bm_param'))
  mdAUcEWCrqIQygjNRtiJKVuoxMGFsl=json.loads(mdAUcEWCrqIQygjNRtiJKVuoxMGFsl)
  mdAUcEWCrqIQygjNRtiJKVuoxMGFzf =mdAUcEWCrqIQygjNRtiJKVuoxMGFsl.get('videoid')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFpv =mdAUcEWCrqIQygjNRtiJKVuoxMGFsl.get('vidtype')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFsT =mdAUcEWCrqIQygjNRtiJKVuoxMGFsl.get('vtitle')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFsb =mdAUcEWCrqIQygjNRtiJKVuoxMGFsl.get('vsubtitle')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFsS=mdAUcEWCrqIQygjNRtiJKVuoxMGFsl.get('contenttype')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvb=xbmcgui.Dialog()
  mdAUcEWCrqIQygjNRtiJKVuoxMGFev=mdAUcEWCrqIQygjNRtiJKVuoxMGFvb.yesno(__language__(30913).encode('utf8'),mdAUcEWCrqIQygjNRtiJKVuoxMGFsT+' \n\n'+__language__(30914))
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFev==mdAUcEWCrqIQygjNRtiJKVuoxMGFkb:return
  mdAUcEWCrqIQygjNRtiJKVuoxMGFsw=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.GetBookmarkInfo(mdAUcEWCrqIQygjNRtiJKVuoxMGFzf,mdAUcEWCrqIQygjNRtiJKVuoxMGFpv,mdAUcEWCrqIQygjNRtiJKVuoxMGFsS)
  mdAUcEWCrqIQygjNRtiJKVuoxMGFsh=json.dumps(mdAUcEWCrqIQygjNRtiJKVuoxMGFsw)
  mdAUcEWCrqIQygjNRtiJKVuoxMGFsh=urllib.parse.quote(mdAUcEWCrqIQygjNRtiJKVuoxMGFsh)
  mdAUcEWCrqIQygjNRtiJKVuoxMGFps ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(mdAUcEWCrqIQygjNRtiJKVuoxMGFsh)
  xbmc.executebuiltin(mdAUcEWCrqIQygjNRtiJKVuoxMGFps)
 def dp_LiveChannel_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP,args):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFsH =args.get('genre')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFOH=args.get('baseapi')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFzL=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.Get_LiveChannel_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFsH,mdAUcEWCrqIQygjNRtiJKVuoxMGFOH)
  for mdAUcEWCrqIQygjNRtiJKVuoxMGFzY in mdAUcEWCrqIQygjNRtiJKVuoxMGFzL:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFsP =mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('channelid')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFsn =mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('studio')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFsB=mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('tvshowtitle')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpX =mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('thumbnail')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFpz =mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('age')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFsa =mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('epg')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFza={'mediatype':'episode','mpaa':mdAUcEWCrqIQygjNRtiJKVuoxMGFpz,'title':'%s < %s >'%(mdAUcEWCrqIQygjNRtiJKVuoxMGFsn,mdAUcEWCrqIQygjNRtiJKVuoxMGFsB),'tvshowtitle':mdAUcEWCrqIQygjNRtiJKVuoxMGFsB,'studio':mdAUcEWCrqIQygjNRtiJKVuoxMGFsn,'plot':'%s\n\n%s'%(mdAUcEWCrqIQygjNRtiJKVuoxMGFsn,mdAUcEWCrqIQygjNRtiJKVuoxMGFsa)}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa={'mode':'LIVE','contentid':mdAUcEWCrqIQygjNRtiJKVuoxMGFsP}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.add_dir(mdAUcEWCrqIQygjNRtiJKVuoxMGFsn,sublabel=mdAUcEWCrqIQygjNRtiJKVuoxMGFsB,img=mdAUcEWCrqIQygjNRtiJKVuoxMGFpX,infoLabels=mdAUcEWCrqIQygjNRtiJKVuoxMGFza,isFolder=mdAUcEWCrqIQygjNRtiJKVuoxMGFkb,params=mdAUcEWCrqIQygjNRtiJKVuoxMGFXa)
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFka(mdAUcEWCrqIQygjNRtiJKVuoxMGFzL)>0:xbmcplugin.endOfDirectory(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP._addon_handle,cacheToDisc=mdAUcEWCrqIQygjNRtiJKVuoxMGFkb)
 def dp_Sports_GameList(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP,args):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFzL=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.Get_Sports_Gamelist()
  for mdAUcEWCrqIQygjNRtiJKVuoxMGFzY in mdAUcEWCrqIQygjNRtiJKVuoxMGFzL:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFsD =mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('game_date')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFsL =mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('game_time')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFsY =mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('svc_id')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFsf =mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('away_team')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFkv =mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('home_team')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFkX=mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('game_status')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFkz =mdAUcEWCrqIQygjNRtiJKVuoxMGFzY.get('game_place')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFkp ='%s vs %s (%s)'%(mdAUcEWCrqIQygjNRtiJKVuoxMGFsf,mdAUcEWCrqIQygjNRtiJKVuoxMGFkv,mdAUcEWCrqIQygjNRtiJKVuoxMGFkz)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFke =mdAUcEWCrqIQygjNRtiJKVuoxMGFsD+' '+mdAUcEWCrqIQygjNRtiJKVuoxMGFsL
   if mdAUcEWCrqIQygjNRtiJKVuoxMGFkX=='LIVE':
    mdAUcEWCrqIQygjNRtiJKVuoxMGFkX='~경기중~'
   elif mdAUcEWCrqIQygjNRtiJKVuoxMGFkX=='END':
    mdAUcEWCrqIQygjNRtiJKVuoxMGFkX='경기종료'
   elif mdAUcEWCrqIQygjNRtiJKVuoxMGFkX=='CANCEL':
    mdAUcEWCrqIQygjNRtiJKVuoxMGFkX='취소'
   else:
    mdAUcEWCrqIQygjNRtiJKVuoxMGFkX=''
   if mdAUcEWCrqIQygjNRtiJKVuoxMGFkX=='':
    mdAUcEWCrqIQygjNRtiJKVuoxMGFpP=mdAUcEWCrqIQygjNRtiJKVuoxMGFkp
   else:
    mdAUcEWCrqIQygjNRtiJKVuoxMGFpP=mdAUcEWCrqIQygjNRtiJKVuoxMGFkp+'  '+mdAUcEWCrqIQygjNRtiJKVuoxMGFkX
   mdAUcEWCrqIQygjNRtiJKVuoxMGFza={'mediatype':'episode','title':mdAUcEWCrqIQygjNRtiJKVuoxMGFkp,'plot':'%s\n\n%s\n\n%s'%(mdAUcEWCrqIQygjNRtiJKVuoxMGFke,mdAUcEWCrqIQygjNRtiJKVuoxMGFkp,mdAUcEWCrqIQygjNRtiJKVuoxMGFkX)}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa={'mode':'SPORTS','contentid':mdAUcEWCrqIQygjNRtiJKVuoxMGFsY}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.add_dir(mdAUcEWCrqIQygjNRtiJKVuoxMGFke,sublabel=mdAUcEWCrqIQygjNRtiJKVuoxMGFpP,img='',infoLabels=mdAUcEWCrqIQygjNRtiJKVuoxMGFza,isFolder=mdAUcEWCrqIQygjNRtiJKVuoxMGFkb,params=mdAUcEWCrqIQygjNRtiJKVuoxMGFXa)
  xbmcplugin.endOfDirectory(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP._addon_handle,cacheToDisc=mdAUcEWCrqIQygjNRtiJKVuoxMGFkb)
 def dp_View_Detail(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP,mdAUcEWCrqIQygjNRtiJKVuoxMGFkP):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFzf =mdAUcEWCrqIQygjNRtiJKVuoxMGFkP.get('videoid')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFpv =mdAUcEWCrqIQygjNRtiJKVuoxMGFkP.get('vidtype') 
  mdAUcEWCrqIQygjNRtiJKVuoxMGFsS=mdAUcEWCrqIQygjNRtiJKVuoxMGFkP.get('contenttype')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.addon_log(mdAUcEWCrqIQygjNRtiJKVuoxMGFzf)
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.addon_log(mdAUcEWCrqIQygjNRtiJKVuoxMGFpv)
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.addon_log(mdAUcEWCrqIQygjNRtiJKVuoxMGFsS)
  mdAUcEWCrqIQygjNRtiJKVuoxMGFsw=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.GetBookmarkInfo(mdAUcEWCrqIQygjNRtiJKVuoxMGFzf,mdAUcEWCrqIQygjNRtiJKVuoxMGFpv,mdAUcEWCrqIQygjNRtiJKVuoxMGFsS)
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFpv=='tvshow':
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa={'mode':'SEASON_LIST','videoid':mdAUcEWCrqIQygjNRtiJKVuoxMGFsw['indexinfo']['videoid'],'vidtype':mdAUcEWCrqIQygjNRtiJKVuoxMGFsw['indexinfo']['vidtype'],}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFeO='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(mdAUcEWCrqIQygjNRtiJKVuoxMGFXa))
  else:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXa={'mode':'MOVIE','contentid':mdAUcEWCrqIQygjNRtiJKVuoxMGFsw['indexinfo']['videoid'],'title':mdAUcEWCrqIQygjNRtiJKVuoxMGFsw['saveinfo']['infoLabels']['title'],'thumbnail':mdAUcEWCrqIQygjNRtiJKVuoxMGFsw['saveinfo']['thumbnail'],'age':mdAUcEWCrqIQygjNRtiJKVuoxMGFsw['saveinfo']['infoLabels']['mpaa'],}
   mdAUcEWCrqIQygjNRtiJKVuoxMGFeO='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(mdAUcEWCrqIQygjNRtiJKVuoxMGFXa))
  mdAUcEWCrqIQygjNRtiJKVuoxMGFXb=xbmcgui.ListItem(label=mdAUcEWCrqIQygjNRtiJKVuoxMGFsw['saveinfo']['title'],path=mdAUcEWCrqIQygjNRtiJKVuoxMGFeO)
  mdAUcEWCrqIQygjNRtiJKVuoxMGFXb.setArt(mdAUcEWCrqIQygjNRtiJKVuoxMGFsw['saveinfo']['thumbnail'])
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.Set_InfoTag(mdAUcEWCrqIQygjNRtiJKVuoxMGFXb.getVideoInfoTag(),mdAUcEWCrqIQygjNRtiJKVuoxMGFsw['saveinfo']['infoLabels'])
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFpv=='movie':
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXb.setIsFolder(mdAUcEWCrqIQygjNRtiJKVuoxMGFkb)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXb.setProperty('IsPlayable','true')
  else:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXb.setIsFolder(mdAUcEWCrqIQygjNRtiJKVuoxMGFkT)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFXb.setProperty('IsPlayable','false')
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvb=xbmcgui.Dialog()
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvb.info(mdAUcEWCrqIQygjNRtiJKVuoxMGFXb)
 def wavve_main(mdAUcEWCrqIQygjNRtiJKVuoxMGFvP):
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.WavveObj.KodiVersion=mdAUcEWCrqIQygjNRtiJKVuoxMGFkl(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  mdAUcEWCrqIQygjNRtiJKVuoxMGFkO=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.main_params.get('params')
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFkO:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFks =base64.standard_b64decode(mdAUcEWCrqIQygjNRtiJKVuoxMGFkO).decode('utf-8')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFks =json.loads(mdAUcEWCrqIQygjNRtiJKVuoxMGFks)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFze =mdAUcEWCrqIQygjNRtiJKVuoxMGFks.get('mode')
   mdAUcEWCrqIQygjNRtiJKVuoxMGFkP =mdAUcEWCrqIQygjNRtiJKVuoxMGFks.get('values')
  else:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFze=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.main_params.get('mode',mdAUcEWCrqIQygjNRtiJKVuoxMGFkB)
   mdAUcEWCrqIQygjNRtiJKVuoxMGFkP=mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.main_params
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFze=='LOGOUT':
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.logout()
   return
  mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.login_main()
  if mdAUcEWCrqIQygjNRtiJKVuoxMGFze is mdAUcEWCrqIQygjNRtiJKVuoxMGFkB:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.dp_Main_List()
  elif mdAUcEWCrqIQygjNRtiJKVuoxMGFze in['LIVE','VOD','MOVIE','SPORTS']:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.play_VIDEO(mdAUcEWCrqIQygjNRtiJKVuoxMGFkP)
  elif mdAUcEWCrqIQygjNRtiJKVuoxMGFze=='LIVE_CATAGORY':
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.dp_LiveCatagory_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFkP)
  elif mdAUcEWCrqIQygjNRtiJKVuoxMGFze=='MAIN_CATAGORY':
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.dp_MainCatagory_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFkP)
  elif mdAUcEWCrqIQygjNRtiJKVuoxMGFze=='SUPERSECTION_LIST':
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.dp_SuperSection_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFkP)
  elif mdAUcEWCrqIQygjNRtiJKVuoxMGFze=='BANDLIVESECTION_LIST':
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.dp_BandLiveSection_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFkP)
  elif mdAUcEWCrqIQygjNRtiJKVuoxMGFze=='BAND2SECTION_LIST':
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.dp_Band2Section_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFkP)
  elif mdAUcEWCrqIQygjNRtiJKVuoxMGFze=='PROGRAM_LIST':
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.dp_Program_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFkP)
  elif mdAUcEWCrqIQygjNRtiJKVuoxMGFze=='SEASON_LIST':
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.dp_Season_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFkP)
  elif mdAUcEWCrqIQygjNRtiJKVuoxMGFze=='EPISODE_LIST':
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.dp_Episode_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFkP)
  elif mdAUcEWCrqIQygjNRtiJKVuoxMGFze=='MOVIE_LIST':
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.dp_Movie_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFkP)
  elif mdAUcEWCrqIQygjNRtiJKVuoxMGFze=='LIVE_LIST':
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.dp_LiveChannel_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFkP)
  elif mdAUcEWCrqIQygjNRtiJKVuoxMGFze=='ORDER_BY':
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.dp_setEpOrderby(mdAUcEWCrqIQygjNRtiJKVuoxMGFkP)
  elif mdAUcEWCrqIQygjNRtiJKVuoxMGFze=='SEARCH_GROUP':
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.dp_Search_Group(mdAUcEWCrqIQygjNRtiJKVuoxMGFkP)
  elif mdAUcEWCrqIQygjNRtiJKVuoxMGFze in['SEARCH_LIST','LOCAL_SEARCH']:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.dp_Search_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFkP)
  elif mdAUcEWCrqIQygjNRtiJKVuoxMGFze=='WATCH_GROUP':
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.dp_Watch_Group(mdAUcEWCrqIQygjNRtiJKVuoxMGFkP)
  elif mdAUcEWCrqIQygjNRtiJKVuoxMGFze=='WATCH_LIST':
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.dp_Watch_List(mdAUcEWCrqIQygjNRtiJKVuoxMGFkP)
  elif mdAUcEWCrqIQygjNRtiJKVuoxMGFze=='SET_BOOKMARK':
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.dp_Set_Bookmark(mdAUcEWCrqIQygjNRtiJKVuoxMGFkP)
  elif mdAUcEWCrqIQygjNRtiJKVuoxMGFze in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.dp_History_Remove(mdAUcEWCrqIQygjNRtiJKVuoxMGFkP)
  elif mdAUcEWCrqIQygjNRtiJKVuoxMGFze in['TOTAL_SEARCH','TOTAL_HISTORY']:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.dp_Global_Search(mdAUcEWCrqIQygjNRtiJKVuoxMGFkP)
  elif mdAUcEWCrqIQygjNRtiJKVuoxMGFze=='SEARCH_HISTORY':
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.dp_Search_History(mdAUcEWCrqIQygjNRtiJKVuoxMGFkP)
  elif mdAUcEWCrqIQygjNRtiJKVuoxMGFze=='MENU_BOOKMARK':
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.dp_Bookmark_Menu(mdAUcEWCrqIQygjNRtiJKVuoxMGFkP)
  elif mdAUcEWCrqIQygjNRtiJKVuoxMGFze=='GAME_LIST':
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.dp_Sports_GameList(mdAUcEWCrqIQygjNRtiJKVuoxMGFkP)
  elif mdAUcEWCrqIQygjNRtiJKVuoxMGFze=='VIEW_DETAIL':
   mdAUcEWCrqIQygjNRtiJKVuoxMGFvP.dp_View_Detail(mdAUcEWCrqIQygjNRtiJKVuoxMGFkP)
  else:
   mdAUcEWCrqIQygjNRtiJKVuoxMGFkB
# Created by pyminifier (https://github.com/liftoff/pyminifier)
