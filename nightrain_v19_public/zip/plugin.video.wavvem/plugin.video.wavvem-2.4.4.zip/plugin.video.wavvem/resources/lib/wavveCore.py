__author__="NightRain"
tkNzmWicyQJYlqXCHEFOSarRTLpgew=object
tkNzmWicyQJYlqXCHEFOSarRTLpgex=None
tkNzmWicyQJYlqXCHEFOSarRTLpgeI=False
tkNzmWicyQJYlqXCHEFOSarRTLpgeU=open
tkNzmWicyQJYlqXCHEFOSarRTLpgDB=True
tkNzmWicyQJYlqXCHEFOSarRTLpgDv=range
tkNzmWicyQJYlqXCHEFOSarRTLpgDd=str
tkNzmWicyQJYlqXCHEFOSarRTLpgDA=len
tkNzmWicyQJYlqXCHEFOSarRTLpgDn=Exception
tkNzmWicyQJYlqXCHEFOSarRTLpgDV=print
tkNzmWicyQJYlqXCHEFOSarRTLpgDe=dict
tkNzmWicyQJYlqXCHEFOSarRTLpgDs=int
import urllib
import re
import json
import sys
import requests
import datetime
import base64
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
tkNzmWicyQJYlqXCHEFOSarRTLpgBd =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
class tkNzmWicyQJYlqXCHEFOSarRTLpgBv(tkNzmWicyQJYlqXCHEFOSarRTLpgew):
 def __init__(tkNzmWicyQJYlqXCHEFOSarRTLpgBA):
  tkNzmWicyQJYlqXCHEFOSarRTLpgBA.API_DOMAIN='https://apis.wavve.com'
  tkNzmWicyQJYlqXCHEFOSarRTLpgBA.WV ={}
  tkNzmWicyQJYlqXCHEFOSarRTLpgBA.Init_WV_Total()
  tkNzmWicyQJYlqXCHEFOSarRTLpgBA.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  tkNzmWicyQJYlqXCHEFOSarRTLpgBA.DEVICE ='pc'
  tkNzmWicyQJYlqXCHEFOSarRTLpgBA.DRM ='wm'
  tkNzmWicyQJYlqXCHEFOSarRTLpgBA.PARTNER ='pooq'
  tkNzmWicyQJYlqXCHEFOSarRTLpgBA.POOQZONE ='none'
  tkNzmWicyQJYlqXCHEFOSarRTLpgBA.REGION ='kor'
  tkNzmWicyQJYlqXCHEFOSarRTLpgBA.TARGETAGE ='all'
  tkNzmWicyQJYlqXCHEFOSarRTLpgBA.HTTPTAG ='https://'
  tkNzmWicyQJYlqXCHEFOSarRTLpgBA.LIST_LIMIT=30 
  tkNzmWicyQJYlqXCHEFOSarRTLpgBA.EP_LIMIT =30 
  tkNzmWicyQJYlqXCHEFOSarRTLpgBA.MV_LIMIT =24 
  tkNzmWicyQJYlqXCHEFOSarRTLpgBA.SEARCH_LIMIT=20 
  tkNzmWicyQJYlqXCHEFOSarRTLpgBA.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
  tkNzmWicyQJYlqXCHEFOSarRTLpgBA.DEFAULT_HEADER={'user-agent':tkNzmWicyQJYlqXCHEFOSarRTLpgBA.USER_AGENT}
  tkNzmWicyQJYlqXCHEFOSarRTLpgBA.KodiVersion=20
  tkNzmWicyQJYlqXCHEFOSarRTLpgBA.WV_SESSION_COOKIES1=''
  tkNzmWicyQJYlqXCHEFOSarRTLpgBA.WV_SESSION_COOKIES2=''
  tkNzmWicyQJYlqXCHEFOSarRTLpgBA.COOKIE_FILE_NAME =''
  tkNzmWicyQJYlqXCHEFOSarRTLpgBA.WV_STREAM_FILENAME =''
 def Init_WV_Total(tkNzmWicyQJYlqXCHEFOSarRTLpgBA):
  tkNzmWicyQJYlqXCHEFOSarRTLpgBA.WV={'account':{},'cookies':{},}
 def callRequestCookies(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,jobtype,tkNzmWicyQJYlqXCHEFOSarRTLpgvh,payload=tkNzmWicyQJYlqXCHEFOSarRTLpgex,params=tkNzmWicyQJYlqXCHEFOSarRTLpgex,headers=tkNzmWicyQJYlqXCHEFOSarRTLpgex,cookies=tkNzmWicyQJYlqXCHEFOSarRTLpgex,redirects=tkNzmWicyQJYlqXCHEFOSarRTLpgeI):
  tkNzmWicyQJYlqXCHEFOSarRTLpgBn=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.DEFAULT_HEADER
  if headers:tkNzmWicyQJYlqXCHEFOSarRTLpgBn.update(headers)
  if jobtype=='Get':
   tkNzmWicyQJYlqXCHEFOSarRTLpgBV=requests.get(tkNzmWicyQJYlqXCHEFOSarRTLpgvh,params=params,headers=tkNzmWicyQJYlqXCHEFOSarRTLpgBn,cookies=cookies,allow_redirects=redirects)
  else:
   tkNzmWicyQJYlqXCHEFOSarRTLpgBV=requests.post(tkNzmWicyQJYlqXCHEFOSarRTLpgvh,json=payload,params=params,headers=tkNzmWicyQJYlqXCHEFOSarRTLpgBn,cookies=cookies,allow_redirects=redirects)
  return tkNzmWicyQJYlqXCHEFOSarRTLpgBV
 def JsonFile_Save(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,filename,tkNzmWicyQJYlqXCHEFOSarRTLpgBe):
  if filename=='':return tkNzmWicyQJYlqXCHEFOSarRTLpgeI
  try:
   fp=tkNzmWicyQJYlqXCHEFOSarRTLpgeU(filename,'w',-1,'utf-8')
   json.dump(tkNzmWicyQJYlqXCHEFOSarRTLpgBe,fp,indent=4,ensure_ascii=tkNzmWicyQJYlqXCHEFOSarRTLpgeI)
   fp.close()
  except:
   return tkNzmWicyQJYlqXCHEFOSarRTLpgeI
  return tkNzmWicyQJYlqXCHEFOSarRTLpgDB
 def JsonFile_Load(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,filename):
  if filename=='':return{}
  try:
   fp=tkNzmWicyQJYlqXCHEFOSarRTLpgeU(filename,'r',-1,'utf-8')
   tkNzmWicyQJYlqXCHEFOSarRTLpgBs=json.load(fp)
   fp.close()
  except:
   return{}
  return tkNzmWicyQJYlqXCHEFOSarRTLpgBs
 def TextFile_Save(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,filename,resText):
  if filename=='':return tkNzmWicyQJYlqXCHEFOSarRTLpgeI
  try:
   fp=tkNzmWicyQJYlqXCHEFOSarRTLpgeU(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return tkNzmWicyQJYlqXCHEFOSarRTLpgeI
  return tkNzmWicyQJYlqXCHEFOSarRTLpgDB
 def Save_session_acount(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,tkNzmWicyQJYlqXCHEFOSarRTLpgBu,tkNzmWicyQJYlqXCHEFOSarRTLpgBh,tkNzmWicyQJYlqXCHEFOSarRTLpgBb):
  tkNzmWicyQJYlqXCHEFOSarRTLpgBA.WV['account']['wvid']=base64.standard_b64encode(tkNzmWicyQJYlqXCHEFOSarRTLpgBu.encode()).decode('utf-8')
  tkNzmWicyQJYlqXCHEFOSarRTLpgBA.WV['account']['wvpw']=base64.standard_b64encode(tkNzmWicyQJYlqXCHEFOSarRTLpgBh.encode()).decode('utf-8')
  tkNzmWicyQJYlqXCHEFOSarRTLpgBA.WV['account']['wvpf']=tkNzmWicyQJYlqXCHEFOSarRTLpgBb 
 def Load_session_acount(tkNzmWicyQJYlqXCHEFOSarRTLpgBA):
  try:
   tkNzmWicyQJYlqXCHEFOSarRTLpgBu=base64.standard_b64decode(tkNzmWicyQJYlqXCHEFOSarRTLpgBA.WV['account']['wvid']).decode('utf-8')
   tkNzmWicyQJYlqXCHEFOSarRTLpgBh=base64.standard_b64decode(tkNzmWicyQJYlqXCHEFOSarRTLpgBA.WV['account']['wvpw']).decode('utf-8')
   tkNzmWicyQJYlqXCHEFOSarRTLpgBb=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.WV['account']['wvpf']
  except:
   return '','',0
  return tkNzmWicyQJYlqXCHEFOSarRTLpgBu,tkNzmWicyQJYlqXCHEFOSarRTLpgBh,tkNzmWicyQJYlqXCHEFOSarRTLpgBb
 def GetDefaultParams(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,login=tkNzmWicyQJYlqXCHEFOSarRTLpgDB):
  tkNzmWicyQJYlqXCHEFOSarRTLpgBf={'apikey':tkNzmWicyQJYlqXCHEFOSarRTLpgBA.APIKEY,'credential':tkNzmWicyQJYlqXCHEFOSarRTLpgBA.WV['cookies']['credential']if login else 'none','device':tkNzmWicyQJYlqXCHEFOSarRTLpgBA.DEVICE,'drm':tkNzmWicyQJYlqXCHEFOSarRTLpgBA.DRM,'partner':tkNzmWicyQJYlqXCHEFOSarRTLpgBA.PARTNER,'pooqzone':tkNzmWicyQJYlqXCHEFOSarRTLpgBA.POOQZONE,'region':tkNzmWicyQJYlqXCHEFOSarRTLpgBA.REGION,'targetage':tkNzmWicyQJYlqXCHEFOSarRTLpgBA.TARGETAGE,}
  return tkNzmWicyQJYlqXCHEFOSarRTLpgBf
 def GetDefaultParams_AND(tkNzmWicyQJYlqXCHEFOSarRTLpgBA):
  tkNzmWicyQJYlqXCHEFOSarRTLpgBf={'apikey':'6A87455D54481A536DFB8AD397C5EC4D','credential':tkNzmWicyQJYlqXCHEFOSarRTLpgBA.WV['cookies']['credential'],'device':'ott','drm':tkNzmWicyQJYlqXCHEFOSarRTLpgBA.DRM,'partner':tkNzmWicyQJYlqXCHEFOSarRTLpgBA.PARTNER,'pooqzone':tkNzmWicyQJYlqXCHEFOSarRTLpgBA.POOQZONE,'region':tkNzmWicyQJYlqXCHEFOSarRTLpgBA.REGION,'targetage':tkNzmWicyQJYlqXCHEFOSarRTLpgBA.TARGETAGE,}
  return tkNzmWicyQJYlqXCHEFOSarRTLpgBf
 def GetGUID(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   tkNzmWicyQJYlqXCHEFOSarRTLpgBo=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   tkNzmWicyQJYlqXCHEFOSarRTLpgBG=GenerateRandomString(5)
   tkNzmWicyQJYlqXCHEFOSarRTLpgBj=tkNzmWicyQJYlqXCHEFOSarRTLpgBG+media+tkNzmWicyQJYlqXCHEFOSarRTLpgBo
   return tkNzmWicyQJYlqXCHEFOSarRTLpgBj
  def GenerateRandomString(num):
   from random import randint
   tkNzmWicyQJYlqXCHEFOSarRTLpgBP=""
   for i in tkNzmWicyQJYlqXCHEFOSarRTLpgDv(0,num):
    s=tkNzmWicyQJYlqXCHEFOSarRTLpgDd(randint(1,5))
    tkNzmWicyQJYlqXCHEFOSarRTLpgBP+=s
   return tkNzmWicyQJYlqXCHEFOSarRTLpgBP
  if guidType==3:
   tkNzmWicyQJYlqXCHEFOSarRTLpgBj=guid_str
  else:
   tkNzmWicyQJYlqXCHEFOSarRTLpgBj=GenerateID(guid_str)
  tkNzmWicyQJYlqXCHEFOSarRTLpgBK=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.GetHash(tkNzmWicyQJYlqXCHEFOSarRTLpgBj)
  if guidType in[2,3]:
   tkNzmWicyQJYlqXCHEFOSarRTLpgBK='%s-%s-%s-%s-%s'%(tkNzmWicyQJYlqXCHEFOSarRTLpgBK[:8],tkNzmWicyQJYlqXCHEFOSarRTLpgBK[8:12],tkNzmWicyQJYlqXCHEFOSarRTLpgBK[12:16],tkNzmWicyQJYlqXCHEFOSarRTLpgBK[16:20],tkNzmWicyQJYlqXCHEFOSarRTLpgBK[20:])
  return tkNzmWicyQJYlqXCHEFOSarRTLpgBK
 def GetHash(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return tkNzmWicyQJYlqXCHEFOSarRTLpgDd(m.hexdigest())
 def CheckQuality(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,sel_qt,qt_list):
  tkNzmWicyQJYlqXCHEFOSarRTLpgBM=0
  for tkNzmWicyQJYlqXCHEFOSarRTLpgBw in qt_list:
   if sel_qt>=tkNzmWicyQJYlqXCHEFOSarRTLpgBw:return tkNzmWicyQJYlqXCHEFOSarRTLpgBw
   tkNzmWicyQJYlqXCHEFOSarRTLpgBM=tkNzmWicyQJYlqXCHEFOSarRTLpgBw
  return tkNzmWicyQJYlqXCHEFOSarRTLpgBM
 def Get_Now_Datetime(tkNzmWicyQJYlqXCHEFOSarRTLpgBA):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,in_text):
  tkNzmWicyQJYlqXCHEFOSarRTLpgBI=in_text.replace('&lt;','<').replace('&gt;','>')
  tkNzmWicyQJYlqXCHEFOSarRTLpgBI=tkNzmWicyQJYlqXCHEFOSarRTLpgBI.replace('<br>','\n')
  tkNzmWicyQJYlqXCHEFOSarRTLpgBI=tkNzmWicyQJYlqXCHEFOSarRTLpgBI.replace('$O$','')
  tkNzmWicyQJYlqXCHEFOSarRTLpgBI=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',tkNzmWicyQJYlqXCHEFOSarRTLpgBI)
  tkNzmWicyQJYlqXCHEFOSarRTLpgBI=tkNzmWicyQJYlqXCHEFOSarRTLpgBI.lstrip('#')
  return tkNzmWicyQJYlqXCHEFOSarRTLpgBI
 def make_str_ToCookie(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,cookieStr):
  tkNzmWicyQJYlqXCHEFOSarRTLpgBU={}
  for tkNzmWicyQJYlqXCHEFOSarRTLpgvB in cookieStr.split(';'):
   tkNzmWicyQJYlqXCHEFOSarRTLpgvd=tkNzmWicyQJYlqXCHEFOSarRTLpgvB.split('=')
   tkNzmWicyQJYlqXCHEFOSarRTLpgBU[tkNzmWicyQJYlqXCHEFOSarRTLpgvd[0]]=tkNzmWicyQJYlqXCHEFOSarRTLpgvd[1]
  return tkNzmWicyQJYlqXCHEFOSarRTLpgBU 
 def make_stream_header(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,tkNzmWicyQJYlqXCHEFOSarRTLpgvD,tkNzmWicyQJYlqXCHEFOSarRTLpgBU):
  tkNzmWicyQJYlqXCHEFOSarRTLpgvA=''
  if tkNzmWicyQJYlqXCHEFOSarRTLpgBU not in[{},tkNzmWicyQJYlqXCHEFOSarRTLpgex,'']:
   tkNzmWicyQJYlqXCHEFOSarRTLpgvn=tkNzmWicyQJYlqXCHEFOSarRTLpgDA(tkNzmWicyQJYlqXCHEFOSarRTLpgBU)
   for tkNzmWicyQJYlqXCHEFOSarRTLpgvV,tkNzmWicyQJYlqXCHEFOSarRTLpgve in tkNzmWicyQJYlqXCHEFOSarRTLpgBU.items():
    tkNzmWicyQJYlqXCHEFOSarRTLpgvA+='{}={}'.format(tkNzmWicyQJYlqXCHEFOSarRTLpgvV,tkNzmWicyQJYlqXCHEFOSarRTLpgve)
    tkNzmWicyQJYlqXCHEFOSarRTLpgvn+=-1
    if tkNzmWicyQJYlqXCHEFOSarRTLpgvn>0:tkNzmWicyQJYlqXCHEFOSarRTLpgvA+='; '
   tkNzmWicyQJYlqXCHEFOSarRTLpgvD['cookie']=tkNzmWicyQJYlqXCHEFOSarRTLpgvA
  tkNzmWicyQJYlqXCHEFOSarRTLpgvs=''
  i=0
  for tkNzmWicyQJYlqXCHEFOSarRTLpgvV,tkNzmWicyQJYlqXCHEFOSarRTLpgve in tkNzmWicyQJYlqXCHEFOSarRTLpgvD.items():
   i=i+1
   if i>1:tkNzmWicyQJYlqXCHEFOSarRTLpgvs+='&'
   tkNzmWicyQJYlqXCHEFOSarRTLpgvs+='{}={}'.format(tkNzmWicyQJYlqXCHEFOSarRTLpgvV,urllib.parse.quote(tkNzmWicyQJYlqXCHEFOSarRTLpgve))
  return tkNzmWicyQJYlqXCHEFOSarRTLpgvs
 def GetCredential(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,user_id,user_pw,user_pf):
  tkNzmWicyQJYlqXCHEFOSarRTLpgvu=tkNzmWicyQJYlqXCHEFOSarRTLpgeI
  try:
   tkNzmWicyQJYlqXCHEFOSarRTLpgvh=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.API_DOMAIN+ '/login'
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.GetDefaultParams(login=tkNzmWicyQJYlqXCHEFOSarRTLpgeI)
   tkNzmWicyQJYlqXCHEFOSarRTLpgvb={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   tkNzmWicyQJYlqXCHEFOSarRTLpgvf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.callRequestCookies('Post',tkNzmWicyQJYlqXCHEFOSarRTLpgvh,payload=tkNzmWicyQJYlqXCHEFOSarRTLpgvb,params=tkNzmWicyQJYlqXCHEFOSarRTLpgBf,headers=tkNzmWicyQJYlqXCHEFOSarRTLpgex,cookies=tkNzmWicyQJYlqXCHEFOSarRTLpgex)
   tkNzmWicyQJYlqXCHEFOSarRTLpgvo=json.loads(tkNzmWicyQJYlqXCHEFOSarRTLpgvf.text)
   tkNzmWicyQJYlqXCHEFOSarRTLpgBA.WV['cookies']['credential']=tkNzmWicyQJYlqXCHEFOSarRTLpgvo['credential']
   if user_pf!=0:
    tkNzmWicyQJYlqXCHEFOSarRTLpgvb={'id':tkNzmWicyQJYlqXCHEFOSarRTLpgBA.WV['cookies']['credential'],'password':'','profile':tkNzmWicyQJYlqXCHEFOSarRTLpgDd(user_pf),'pushid':'','type':'credential'}
    tkNzmWicyQJYlqXCHEFOSarRTLpgBf =tkNzmWicyQJYlqXCHEFOSarRTLpgBA.GetDefaultParams(login=tkNzmWicyQJYlqXCHEFOSarRTLpgDB) 
    tkNzmWicyQJYlqXCHEFOSarRTLpgvf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.callRequestCookies('Post',tkNzmWicyQJYlqXCHEFOSarRTLpgvh,payload=tkNzmWicyQJYlqXCHEFOSarRTLpgvb,params=tkNzmWicyQJYlqXCHEFOSarRTLpgBf,headers=tkNzmWicyQJYlqXCHEFOSarRTLpgex,cookies=tkNzmWicyQJYlqXCHEFOSarRTLpgex)
    tkNzmWicyQJYlqXCHEFOSarRTLpgvo=json.loads(tkNzmWicyQJYlqXCHEFOSarRTLpgvf.text)
    tkNzmWicyQJYlqXCHEFOSarRTLpgBA.WV['cookies']['credential']=tkNzmWicyQJYlqXCHEFOSarRTLpgvo['credential']
   tkNzmWicyQJYlqXCHEFOSarRTLpgvG=user_id+tkNzmWicyQJYlqXCHEFOSarRTLpgDd(user_pf) 
   tkNzmWicyQJYlqXCHEFOSarRTLpgBA.WV['cookies']['uuid']=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.GetGUID(guid_str=tkNzmWicyQJYlqXCHEFOSarRTLpgvG,guidType=3)
   tkNzmWicyQJYlqXCHEFOSarRTLpgvu=tkNzmWicyQJYlqXCHEFOSarRTLpgDB
  except tkNzmWicyQJYlqXCHEFOSarRTLpgDn as exception:
   tkNzmWicyQJYlqXCHEFOSarRTLpgDV(exception)
   tkNzmWicyQJYlqXCHEFOSarRTLpgBA.Init_WV_Total()
  return tkNzmWicyQJYlqXCHEFOSarRTLpgvu
 def GetIssue(tkNzmWicyQJYlqXCHEFOSarRTLpgBA):
  tkNzmWicyQJYlqXCHEFOSarRTLpgvj=tkNzmWicyQJYlqXCHEFOSarRTLpgeI
  try:
   tkNzmWicyQJYlqXCHEFOSarRTLpgvh=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.API_DOMAIN+'/guid/issue'
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.GetDefaultParams()
   tkNzmWicyQJYlqXCHEFOSarRTLpgvf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.callRequestCookies('Get',tkNzmWicyQJYlqXCHEFOSarRTLpgvh,payload=tkNzmWicyQJYlqXCHEFOSarRTLpgex,params=tkNzmWicyQJYlqXCHEFOSarRTLpgBf,headers=tkNzmWicyQJYlqXCHEFOSarRTLpgex,cookies=tkNzmWicyQJYlqXCHEFOSarRTLpgex)
   tkNzmWicyQJYlqXCHEFOSarRTLpgvo=json.loads(tkNzmWicyQJYlqXCHEFOSarRTLpgvf.text)
   tkNzmWicyQJYlqXCHEFOSarRTLpgvP=tkNzmWicyQJYlqXCHEFOSarRTLpgvo['guid']
   tkNzmWicyQJYlqXCHEFOSarRTLpgvK=tkNzmWicyQJYlqXCHEFOSarRTLpgvo['guidtimestamp']
   if tkNzmWicyQJYlqXCHEFOSarRTLpgvP:tkNzmWicyQJYlqXCHEFOSarRTLpgvj=tkNzmWicyQJYlqXCHEFOSarRTLpgDB
  except tkNzmWicyQJYlqXCHEFOSarRTLpgDn as exception:
   tkNzmWicyQJYlqXCHEFOSarRTLpgDV(exception)
   tkNzmWicyQJYlqXCHEFOSarRTLpgvP='none'
   tkNzmWicyQJYlqXCHEFOSarRTLpgvK='none' 
  tkNzmWicyQJYlqXCHEFOSarRTLpgBA.guid=tkNzmWicyQJYlqXCHEFOSarRTLpgvP
  tkNzmWicyQJYlqXCHEFOSarRTLpgBA.guidtimestamp=tkNzmWicyQJYlqXCHEFOSarRTLpgvK
  return tkNzmWicyQJYlqXCHEFOSarRTLpgvj
 def Baseapi_Parse(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,tkNzmWicyQJYlqXCHEFOSarRTLpgvI):
  try:
   tkNzmWicyQJYlqXCHEFOSarRTLpgvM =urllib.parse.urlsplit(tkNzmWicyQJYlqXCHEFOSarRTLpgvI)
   if tkNzmWicyQJYlqXCHEFOSarRTLpgvM.netloc=='':
    tkNzmWicyQJYlqXCHEFOSarRTLpgvh=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.HTTPTAG+tkNzmWicyQJYlqXCHEFOSarRTLpgvM.netloc+tkNzmWicyQJYlqXCHEFOSarRTLpgvM.path
   else:
    tkNzmWicyQJYlqXCHEFOSarRTLpgvh=tkNzmWicyQJYlqXCHEFOSarRTLpgvM.scheme+'://'+tkNzmWicyQJYlqXCHEFOSarRTLpgvM.netloc+tkNzmWicyQJYlqXCHEFOSarRTLpgvM.path
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf=tkNzmWicyQJYlqXCHEFOSarRTLpgDe(urllib.parse.parse_qsl(tkNzmWicyQJYlqXCHEFOSarRTLpgvM.query))
  except tkNzmWicyQJYlqXCHEFOSarRTLpgDn as exception:
   tkNzmWicyQJYlqXCHEFOSarRTLpgDV(exception)
   return '',{}
  return tkNzmWicyQJYlqXCHEFOSarRTLpgvh,tkNzmWicyQJYlqXCHEFOSarRTLpgBf
 def GetSupermultiUrl(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,sCode,sIndex='0'):
  try:
   tkNzmWicyQJYlqXCHEFOSarRTLpgvh=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.API_DOMAIN+'/cf/supermultisections/'+sCode
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.GetDefaultParams(login=tkNzmWicyQJYlqXCHEFOSarRTLpgeI)
   tkNzmWicyQJYlqXCHEFOSarRTLpgvf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.callRequestCookies('Get',tkNzmWicyQJYlqXCHEFOSarRTLpgvh,payload=tkNzmWicyQJYlqXCHEFOSarRTLpgex,params=tkNzmWicyQJYlqXCHEFOSarRTLpgBf,headers=tkNzmWicyQJYlqXCHEFOSarRTLpgex,cookies=tkNzmWicyQJYlqXCHEFOSarRTLpgex)
   tkNzmWicyQJYlqXCHEFOSarRTLpgvo=json.loads(tkNzmWicyQJYlqXCHEFOSarRTLpgvf.text)
   tkNzmWicyQJYlqXCHEFOSarRTLpgvw=tkNzmWicyQJYlqXCHEFOSarRTLpgvo['multisectionlist'][tkNzmWicyQJYlqXCHEFOSarRTLpgDs(sIndex)]['eventlist'][1]['url']
  except tkNzmWicyQJYlqXCHEFOSarRTLpgDn as exception:
   tkNzmWicyQJYlqXCHEFOSarRTLpgDV(exception)
   return ''
  return tkNzmWicyQJYlqXCHEFOSarRTLpgvw
 def Get_LiveCatagory_List(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,sCode,sIndex='0'):
  tkNzmWicyQJYlqXCHEFOSarRTLpgvx=[]
  tkNzmWicyQJYlqXCHEFOSarRTLpgvI =tkNzmWicyQJYlqXCHEFOSarRTLpgBA.GetSupermultiUrl(sCode,sIndex)
  (tkNzmWicyQJYlqXCHEFOSarRTLpgvh,tkNzmWicyQJYlqXCHEFOSarRTLpgBf)=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.Baseapi_Parse(tkNzmWicyQJYlqXCHEFOSarRTLpgvI)
  if tkNzmWicyQJYlqXCHEFOSarRTLpgvh=='':return tkNzmWicyQJYlqXCHEFOSarRTLpgvx,''
  try:
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf.update(tkNzmWicyQJYlqXCHEFOSarRTLpgBA.GetDefaultParams(login=tkNzmWicyQJYlqXCHEFOSarRTLpgeI))
   tkNzmWicyQJYlqXCHEFOSarRTLpgvf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.callRequestCookies('Get',tkNzmWicyQJYlqXCHEFOSarRTLpgvh,payload=tkNzmWicyQJYlqXCHEFOSarRTLpgex,params=tkNzmWicyQJYlqXCHEFOSarRTLpgBf,headers=tkNzmWicyQJYlqXCHEFOSarRTLpgex,cookies=tkNzmWicyQJYlqXCHEFOSarRTLpgex)
   tkNzmWicyQJYlqXCHEFOSarRTLpgvo=json.loads(tkNzmWicyQJYlqXCHEFOSarRTLpgvf.text)
   if not('filter_item_list' in tkNzmWicyQJYlqXCHEFOSarRTLpgvo['filter']['filterlist'][0]):return[],''
   tkNzmWicyQJYlqXCHEFOSarRTLpgdB=tkNzmWicyQJYlqXCHEFOSarRTLpgvo['filter']['filterlist'][0]['filter_item_list']
   for tkNzmWicyQJYlqXCHEFOSarRTLpgdv in tkNzmWicyQJYlqXCHEFOSarRTLpgdB:
    tkNzmWicyQJYlqXCHEFOSarRTLpgdA={'title':tkNzmWicyQJYlqXCHEFOSarRTLpgdv['title'],'genre':tkNzmWicyQJYlqXCHEFOSarRTLpgdv['api_parameters'][tkNzmWicyQJYlqXCHEFOSarRTLpgdv['api_parameters'].index('=')+1:]}
    tkNzmWicyQJYlqXCHEFOSarRTLpgvx.append(tkNzmWicyQJYlqXCHEFOSarRTLpgdA)
  except tkNzmWicyQJYlqXCHEFOSarRTLpgDn as exception:
   tkNzmWicyQJYlqXCHEFOSarRTLpgDV(exception)
   return[],''
  return tkNzmWicyQJYlqXCHEFOSarRTLpgvx,tkNzmWicyQJYlqXCHEFOSarRTLpgvI
 def Get_MainCatagory_List(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,sCode,sIndex,sType):
  tkNzmWicyQJYlqXCHEFOSarRTLpgvx=[]
  tkNzmWicyQJYlqXCHEFOSarRTLpgvh='https://apis.wavve.com/es/category/launcher-band'
  tkNzmWicyQJYlqXCHEFOSarRTLpgBf={'uitype':sCode,'uiparent':'GN52-'+sCode,'uirank':sIndex,'broadcastid':sCode,'offset':'0','limit':'20','uicode':sCode,'mtype':'N','ctype':sType,'orderby':'default',}
  try:
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf.update(tkNzmWicyQJYlqXCHEFOSarRTLpgBA.GetDefaultParams(login=tkNzmWicyQJYlqXCHEFOSarRTLpgeI))
   tkNzmWicyQJYlqXCHEFOSarRTLpgvf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.callRequestCookies('Get',tkNzmWicyQJYlqXCHEFOSarRTLpgvh,payload=tkNzmWicyQJYlqXCHEFOSarRTLpgex,params=tkNzmWicyQJYlqXCHEFOSarRTLpgBf,headers=tkNzmWicyQJYlqXCHEFOSarRTLpgex,cookies=tkNzmWicyQJYlqXCHEFOSarRTLpgex)
   tkNzmWicyQJYlqXCHEFOSarRTLpgvo=json.loads(tkNzmWicyQJYlqXCHEFOSarRTLpgvf.text)
   if not('celllist' in tkNzmWicyQJYlqXCHEFOSarRTLpgvo['band']):return[]
   tkNzmWicyQJYlqXCHEFOSarRTLpgdB=tkNzmWicyQJYlqXCHEFOSarRTLpgvo['band']['celllist']
   for tkNzmWicyQJYlqXCHEFOSarRTLpgdv in tkNzmWicyQJYlqXCHEFOSarRTLpgdB:
    tkNzmWicyQJYlqXCHEFOSarRTLpgdn =tkNzmWicyQJYlqXCHEFOSarRTLpgdv['event_list'][1]['url']
    (tkNzmWicyQJYlqXCHEFOSarRTLpgdV,tkNzmWicyQJYlqXCHEFOSarRTLpgde)=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.Baseapi_Parse(tkNzmWicyQJYlqXCHEFOSarRTLpgdn)
    tkNzmWicyQJYlqXCHEFOSarRTLpgdA={'title':tkNzmWicyQJYlqXCHEFOSarRTLpgdv['title_list'][0]['text'],'suburl':tkNzmWicyQJYlqXCHEFOSarRTLpgdV,'subapi':tkNzmWicyQJYlqXCHEFOSarRTLpgde.get('api'),'subtype':'catagory' if tkNzmWicyQJYlqXCHEFOSarRTLpgde else 'supersection'}
    tkNzmWicyQJYlqXCHEFOSarRTLpgvx.append(tkNzmWicyQJYlqXCHEFOSarRTLpgdA)
  except tkNzmWicyQJYlqXCHEFOSarRTLpgDn as exception:
   tkNzmWicyQJYlqXCHEFOSarRTLpgDV(exception)
   return[]
  return tkNzmWicyQJYlqXCHEFOSarRTLpgvx
 def Get_SuperMultiSection_List(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,subapi_text):
  tkNzmWicyQJYlqXCHEFOSarRTLpgvx=[]
  if '/multiband/' in subapi_text: 
   tkNzmWicyQJYlqXCHEFOSarRTLpgvh=subapi_text 
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf={'client':'40'}
  else:
   tkNzmWicyQJYlqXCHEFOSarRTLpgvh=subapi_text 
   tkNzmWicyQJYlqXCHEFOSarRTLpgvh=tkNzmWicyQJYlqXCHEFOSarRTLpgvh.replace('www.wavve.com','apis.wavve.com').replace('supermultisection','v1/multiband')
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf={}
  try:
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf.update(tkNzmWicyQJYlqXCHEFOSarRTLpgBA.GetDefaultParams(login=tkNzmWicyQJYlqXCHEFOSarRTLpgeI))
   tkNzmWicyQJYlqXCHEFOSarRTLpgvf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.callRequestCookies('Get',tkNzmWicyQJYlqXCHEFOSarRTLpgvh,payload=tkNzmWicyQJYlqXCHEFOSarRTLpgex,params=tkNzmWicyQJYlqXCHEFOSarRTLpgBf,headers=tkNzmWicyQJYlqXCHEFOSarRTLpgex,cookies=tkNzmWicyQJYlqXCHEFOSarRTLpgex)
   tkNzmWicyQJYlqXCHEFOSarRTLpgvo=json.loads(tkNzmWicyQJYlqXCHEFOSarRTLpgvf.text)
   if not('multisectionlist' in tkNzmWicyQJYlqXCHEFOSarRTLpgvo):return[]
   tkNzmWicyQJYlqXCHEFOSarRTLpgdB=tkNzmWicyQJYlqXCHEFOSarRTLpgvo['multisectionlist']
   for tkNzmWicyQJYlqXCHEFOSarRTLpgdv in tkNzmWicyQJYlqXCHEFOSarRTLpgdB:
    tkNzmWicyQJYlqXCHEFOSarRTLpgdD=tkNzmWicyQJYlqXCHEFOSarRTLpgdv['title']
    if tkNzmWicyQJYlqXCHEFOSarRTLpgDA(tkNzmWicyQJYlqXCHEFOSarRTLpgdD)==0:continue
    if tkNzmWicyQJYlqXCHEFOSarRTLpgdD=='minor':continue
    if re.search(u'베너',tkNzmWicyQJYlqXCHEFOSarRTLpgdD):continue
    if re.search(u'배너',tkNzmWicyQJYlqXCHEFOSarRTLpgdD):continue 
    if tkNzmWicyQJYlqXCHEFOSarRTLpgdv['force_refresh']=='y':continue
    if tkNzmWicyQJYlqXCHEFOSarRTLpgDA(tkNzmWicyQJYlqXCHEFOSarRTLpgdv['eventlist'])>=3:
     tkNzmWicyQJYlqXCHEFOSarRTLpgde =tkNzmWicyQJYlqXCHEFOSarRTLpgdv['eventlist'][2]['url']
    else:
     tkNzmWicyQJYlqXCHEFOSarRTLpgde =tkNzmWicyQJYlqXCHEFOSarRTLpgdv['eventlist'][1]['url']
    tkNzmWicyQJYlqXCHEFOSarRTLpgds=tkNzmWicyQJYlqXCHEFOSarRTLpgdv['cell_type']
    if tkNzmWicyQJYlqXCHEFOSarRTLpgds=='band_2':
     if tkNzmWicyQJYlqXCHEFOSarRTLpgde.find('channellist=')>=0:
      tkNzmWicyQJYlqXCHEFOSarRTLpgds='band_live'
    tkNzmWicyQJYlqXCHEFOSarRTLpgdA={'title':tkNzmWicyQJYlqXCHEFOSarRTLpgBA.Get_ChangeText(tkNzmWicyQJYlqXCHEFOSarRTLpgdD),'subapi':tkNzmWicyQJYlqXCHEFOSarRTLpgde,'cell_type':tkNzmWicyQJYlqXCHEFOSarRTLpgds}
    tkNzmWicyQJYlqXCHEFOSarRTLpgvx.append(tkNzmWicyQJYlqXCHEFOSarRTLpgdA)
  except tkNzmWicyQJYlqXCHEFOSarRTLpgDn as exception:
   tkNzmWicyQJYlqXCHEFOSarRTLpgDV(exception)
   return[]
  return tkNzmWicyQJYlqXCHEFOSarRTLpgvx
 def Get_BandLiveSection_List(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,tkNzmWicyQJYlqXCHEFOSarRTLpgvI,page_int=1):
  tkNzmWicyQJYlqXCHEFOSarRTLpgdu=[]
  tkNzmWicyQJYlqXCHEFOSarRTLpgdh=tkNzmWicyQJYlqXCHEFOSarRTLpgdP=1
  tkNzmWicyQJYlqXCHEFOSarRTLpgdb=tkNzmWicyQJYlqXCHEFOSarRTLpgeI
  try:
   (tkNzmWicyQJYlqXCHEFOSarRTLpgvh,tkNzmWicyQJYlqXCHEFOSarRTLpgBf)=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.Baseapi_Parse(tkNzmWicyQJYlqXCHEFOSarRTLpgvI)
  except tkNzmWicyQJYlqXCHEFOSarRTLpgDn as exception:
   tkNzmWicyQJYlqXCHEFOSarRTLpgDV(exception)
   return[],tkNzmWicyQJYlqXCHEFOSarRTLpgeI
  try:
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf['limit']=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.LIST_LIMIT
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf['offset']=tkNzmWicyQJYlqXCHEFOSarRTLpgDd((page_int-1)*tkNzmWicyQJYlqXCHEFOSarRTLpgBA.LIST_LIMIT)
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf.update(tkNzmWicyQJYlqXCHEFOSarRTLpgBA.GetDefaultParams(login=tkNzmWicyQJYlqXCHEFOSarRTLpgeI))
   tkNzmWicyQJYlqXCHEFOSarRTLpgvf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.callRequestCookies('Get',tkNzmWicyQJYlqXCHEFOSarRTLpgvh,payload=tkNzmWicyQJYlqXCHEFOSarRTLpgex,params=tkNzmWicyQJYlqXCHEFOSarRTLpgBf,headers=tkNzmWicyQJYlqXCHEFOSarRTLpgex,cookies=tkNzmWicyQJYlqXCHEFOSarRTLpgex)
   tkNzmWicyQJYlqXCHEFOSarRTLpgvo=json.loads(tkNzmWicyQJYlqXCHEFOSarRTLpgvf.text)
   if not('celllist' in tkNzmWicyQJYlqXCHEFOSarRTLpgvo['cell_toplist']):return[],tkNzmWicyQJYlqXCHEFOSarRTLpgeI
   tkNzmWicyQJYlqXCHEFOSarRTLpgdB=tkNzmWicyQJYlqXCHEFOSarRTLpgvo['cell_toplist']['celllist']
   for tkNzmWicyQJYlqXCHEFOSarRTLpgdv in tkNzmWicyQJYlqXCHEFOSarRTLpgdB:
    tkNzmWicyQJYlqXCHEFOSarRTLpgdf =tkNzmWicyQJYlqXCHEFOSarRTLpgdv['event_list'][1]['url']
    tkNzmWicyQJYlqXCHEFOSarRTLpgdo=urllib.parse.urlsplit(tkNzmWicyQJYlqXCHEFOSarRTLpgdf).query
    tkNzmWicyQJYlqXCHEFOSarRTLpgdo=tkNzmWicyQJYlqXCHEFOSarRTLpgDe(urllib.parse.parse_qsl(tkNzmWicyQJYlqXCHEFOSarRTLpgdo))
    tkNzmWicyQJYlqXCHEFOSarRTLpgdG='channelid'
    tkNzmWicyQJYlqXCHEFOSarRTLpgdj=tkNzmWicyQJYlqXCHEFOSarRTLpgdo[tkNzmWicyQJYlqXCHEFOSarRTLpgdG]
    tkNzmWicyQJYlqXCHEFOSarRTLpgdA={'studio':tkNzmWicyQJYlqXCHEFOSarRTLpgdv['title_list'][0]['text'],'tvshowtitle':tkNzmWicyQJYlqXCHEFOSarRTLpgBA.Get_ChangeText(tkNzmWicyQJYlqXCHEFOSarRTLpgdv['title_list'][1]['text']),'channelid':tkNzmWicyQJYlqXCHEFOSarRTLpgdj,'age':tkNzmWicyQJYlqXCHEFOSarRTLpgdv.get('age'),'thumbnail':'https://%s'%tkNzmWicyQJYlqXCHEFOSarRTLpgdv.get('thumbnail')}
    tkNzmWicyQJYlqXCHEFOSarRTLpgdu.append(tkNzmWicyQJYlqXCHEFOSarRTLpgdA)
   tkNzmWicyQJYlqXCHEFOSarRTLpgdh=tkNzmWicyQJYlqXCHEFOSarRTLpgDs(tkNzmWicyQJYlqXCHEFOSarRTLpgvo['cell_toplist']['pagecount'])
   if tkNzmWicyQJYlqXCHEFOSarRTLpgvo['cell_toplist']['count']:tkNzmWicyQJYlqXCHEFOSarRTLpgdP =tkNzmWicyQJYlqXCHEFOSarRTLpgDs(tkNzmWicyQJYlqXCHEFOSarRTLpgvo['cell_toplist']['count'])
   else:tkNzmWicyQJYlqXCHEFOSarRTLpgdP=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.LIST_LIMIT*page_int
   tkNzmWicyQJYlqXCHEFOSarRTLpgdb=tkNzmWicyQJYlqXCHEFOSarRTLpgdh>tkNzmWicyQJYlqXCHEFOSarRTLpgdP
  except tkNzmWicyQJYlqXCHEFOSarRTLpgDn as exception:
   tkNzmWicyQJYlqXCHEFOSarRTLpgDV(exception)
   return[],tkNzmWicyQJYlqXCHEFOSarRTLpgeI
  return tkNzmWicyQJYlqXCHEFOSarRTLpgdu,tkNzmWicyQJYlqXCHEFOSarRTLpgdb
 def Get_Band2Section_List(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,tkNzmWicyQJYlqXCHEFOSarRTLpgvI,page_int=1):
  tkNzmWicyQJYlqXCHEFOSarRTLpgdK=[]
  tkNzmWicyQJYlqXCHEFOSarRTLpgdh=tkNzmWicyQJYlqXCHEFOSarRTLpgdP=1
  tkNzmWicyQJYlqXCHEFOSarRTLpgdb=tkNzmWicyQJYlqXCHEFOSarRTLpgeI
  try:
   (tkNzmWicyQJYlqXCHEFOSarRTLpgvh,tkNzmWicyQJYlqXCHEFOSarRTLpgBf)=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.Baseapi_Parse(tkNzmWicyQJYlqXCHEFOSarRTLpgvI)
  except tkNzmWicyQJYlqXCHEFOSarRTLpgDn as exception:
   tkNzmWicyQJYlqXCHEFOSarRTLpgDV(exception)
   return[],tkNzmWicyQJYlqXCHEFOSarRTLpgeI
  try:
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf['came'] ='BandView'
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf['limit']=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.LIST_LIMIT
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf['offset']=tkNzmWicyQJYlqXCHEFOSarRTLpgDd((page_int-1)*tkNzmWicyQJYlqXCHEFOSarRTLpgBA.LIST_LIMIT)
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf.update(tkNzmWicyQJYlqXCHEFOSarRTLpgBA.GetDefaultParams(login=tkNzmWicyQJYlqXCHEFOSarRTLpgeI))
   tkNzmWicyQJYlqXCHEFOSarRTLpgvf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.callRequestCookies('Get',tkNzmWicyQJYlqXCHEFOSarRTLpgvh,payload=tkNzmWicyQJYlqXCHEFOSarRTLpgex,params=tkNzmWicyQJYlqXCHEFOSarRTLpgBf,headers=tkNzmWicyQJYlqXCHEFOSarRTLpgex,cookies=tkNzmWicyQJYlqXCHEFOSarRTLpgex)
   tkNzmWicyQJYlqXCHEFOSarRTLpgvo=json.loads(tkNzmWicyQJYlqXCHEFOSarRTLpgvf.text)
   if not('celllist' in tkNzmWicyQJYlqXCHEFOSarRTLpgvo['cell_toplist']):return[],tkNzmWicyQJYlqXCHEFOSarRTLpgeI
   tkNzmWicyQJYlqXCHEFOSarRTLpgdB=tkNzmWicyQJYlqXCHEFOSarRTLpgvo['cell_toplist']['celllist']
   for tkNzmWicyQJYlqXCHEFOSarRTLpgdv in tkNzmWicyQJYlqXCHEFOSarRTLpgdB:
    tkNzmWicyQJYlqXCHEFOSarRTLpgdf =tkNzmWicyQJYlqXCHEFOSarRTLpgdv['event_list'][1]['url']
    tkNzmWicyQJYlqXCHEFOSarRTLpgdo=urllib.parse.urlsplit(tkNzmWicyQJYlqXCHEFOSarRTLpgdf).query
    tkNzmWicyQJYlqXCHEFOSarRTLpgdo=tkNzmWicyQJYlqXCHEFOSarRTLpgDe(urllib.parse.parse_qsl(tkNzmWicyQJYlqXCHEFOSarRTLpgdo))
    tkNzmWicyQJYlqXCHEFOSarRTLpgdG='contentid'
    tkNzmWicyQJYlqXCHEFOSarRTLpgdj=tkNzmWicyQJYlqXCHEFOSarRTLpgdo[tkNzmWicyQJYlqXCHEFOSarRTLpgdG]
    tkNzmWicyQJYlqXCHEFOSarRTLpgdA={'programtitle':tkNzmWicyQJYlqXCHEFOSarRTLpgdv['title_list'][0]['text'],'episodetitle':tkNzmWicyQJYlqXCHEFOSarRTLpgBA.Get_ChangeText(tkNzmWicyQJYlqXCHEFOSarRTLpgdv['title_list'][1]['text']),'age':tkNzmWicyQJYlqXCHEFOSarRTLpgdv.get('age'),'thumbnail':tkNzmWicyQJYlqXCHEFOSarRTLpgBA.HTTPTAG+tkNzmWicyQJYlqXCHEFOSarRTLpgdv.get('thumbnail'),'vidtype':tkNzmWicyQJYlqXCHEFOSarRTLpgdG,'videoid':tkNzmWicyQJYlqXCHEFOSarRTLpgdj}
    tkNzmWicyQJYlqXCHEFOSarRTLpgdK.append(tkNzmWicyQJYlqXCHEFOSarRTLpgdA)
   tkNzmWicyQJYlqXCHEFOSarRTLpgdh=tkNzmWicyQJYlqXCHEFOSarRTLpgDs(tkNzmWicyQJYlqXCHEFOSarRTLpgvo['cell_toplist']['pagecount'])
   if tkNzmWicyQJYlqXCHEFOSarRTLpgvo['cell_toplist']['count']:tkNzmWicyQJYlqXCHEFOSarRTLpgdP =tkNzmWicyQJYlqXCHEFOSarRTLpgDs(tkNzmWicyQJYlqXCHEFOSarRTLpgvo['cell_toplist']['count'])
   else:tkNzmWicyQJYlqXCHEFOSarRTLpgdP=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.LIST_LIMIT*page_int
   tkNzmWicyQJYlqXCHEFOSarRTLpgdb=tkNzmWicyQJYlqXCHEFOSarRTLpgdh>tkNzmWicyQJYlqXCHEFOSarRTLpgdP
  except tkNzmWicyQJYlqXCHEFOSarRTLpgDn as exception:
   tkNzmWicyQJYlqXCHEFOSarRTLpgDV(exception)
   return[],tkNzmWicyQJYlqXCHEFOSarRTLpgeI
  return tkNzmWicyQJYlqXCHEFOSarRTLpgdK,tkNzmWicyQJYlqXCHEFOSarRTLpgdb
 def Get_Program_List(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,tkNzmWicyQJYlqXCHEFOSarRTLpgvI,page_int=1,orderby='-'):
  tkNzmWicyQJYlqXCHEFOSarRTLpgdM=[]
  tkNzmWicyQJYlqXCHEFOSarRTLpgdh=tkNzmWicyQJYlqXCHEFOSarRTLpgdP=1
  tkNzmWicyQJYlqXCHEFOSarRTLpgdb=tkNzmWicyQJYlqXCHEFOSarRTLpgeI
  (tkNzmWicyQJYlqXCHEFOSarRTLpgvh,tkNzmWicyQJYlqXCHEFOSarRTLpgBf)=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.Baseapi_Parse(tkNzmWicyQJYlqXCHEFOSarRTLpgvI)
  if tkNzmWicyQJYlqXCHEFOSarRTLpgvh=='':return tkNzmWicyQJYlqXCHEFOSarRTLpgdM,tkNzmWicyQJYlqXCHEFOSarRTLpgdb
  try:
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf['limit'] =tkNzmWicyQJYlqXCHEFOSarRTLpgBA.LIST_LIMIT
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf['offset']=tkNzmWicyQJYlqXCHEFOSarRTLpgDd((page_int-1)*tkNzmWicyQJYlqXCHEFOSarRTLpgBA.LIST_LIMIT)
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf['page'] =tkNzmWicyQJYlqXCHEFOSarRTLpgDd(page_int)
   if tkNzmWicyQJYlqXCHEFOSarRTLpgBf.get('orderby')!='' and tkNzmWicyQJYlqXCHEFOSarRTLpgBf.get('orderby')!='regdatefirst' and orderby!='-':
    tkNzmWicyQJYlqXCHEFOSarRTLpgBf['orderby']=orderby 
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf.update(tkNzmWicyQJYlqXCHEFOSarRTLpgBA.GetDefaultParams(login=tkNzmWicyQJYlqXCHEFOSarRTLpgeI))
   tkNzmWicyQJYlqXCHEFOSarRTLpgvf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.callRequestCookies('Get',tkNzmWicyQJYlqXCHEFOSarRTLpgvh,payload=tkNzmWicyQJYlqXCHEFOSarRTLpgex,params=tkNzmWicyQJYlqXCHEFOSarRTLpgBf,headers=tkNzmWicyQJYlqXCHEFOSarRTLpgex,cookies=tkNzmWicyQJYlqXCHEFOSarRTLpgex)
   tkNzmWicyQJYlqXCHEFOSarRTLpgvo=json.loads(tkNzmWicyQJYlqXCHEFOSarRTLpgvf.text)
   if tkNzmWicyQJYlqXCHEFOSarRTLpgvo.get('cell_toplist')not in[{},tkNzmWicyQJYlqXCHEFOSarRTLpgex,'']:
    tkNzmWicyQJYlqXCHEFOSarRTLpgdB=tkNzmWicyQJYlqXCHEFOSarRTLpgvo['cell_toplist']['celllist']
   elif tkNzmWicyQJYlqXCHEFOSarRTLpgvo.get('band')not in[{},tkNzmWicyQJYlqXCHEFOSarRTLpgex,'']:
    tkNzmWicyQJYlqXCHEFOSarRTLpgdB=tkNzmWicyQJYlqXCHEFOSarRTLpgvo['band']['celllist']
   else:
    return tkNzmWicyQJYlqXCHEFOSarRTLpgdM,tkNzmWicyQJYlqXCHEFOSarRTLpgdb
   for tkNzmWicyQJYlqXCHEFOSarRTLpgdv in tkNzmWicyQJYlqXCHEFOSarRTLpgdB:
    for tkNzmWicyQJYlqXCHEFOSarRTLpgdw in tkNzmWicyQJYlqXCHEFOSarRTLpgdv['event_list']:
     if tkNzmWicyQJYlqXCHEFOSarRTLpgdw.get('type')=='on-navigation':
      tkNzmWicyQJYlqXCHEFOSarRTLpgdf =tkNzmWicyQJYlqXCHEFOSarRTLpgdw['url']
    tkNzmWicyQJYlqXCHEFOSarRTLpgdo=urllib.parse.urlsplit(tkNzmWicyQJYlqXCHEFOSarRTLpgdf).query
    tkNzmWicyQJYlqXCHEFOSarRTLpgdG=tkNzmWicyQJYlqXCHEFOSarRTLpgdo[0:tkNzmWicyQJYlqXCHEFOSarRTLpgdo.find('=')]
    tkNzmWicyQJYlqXCHEFOSarRTLpgdx=tkNzmWicyQJYlqXCHEFOSarRTLpgDe(urllib.parse.parse_qsl(tkNzmWicyQJYlqXCHEFOSarRTLpgdo))
    tkNzmWicyQJYlqXCHEFOSarRTLpgdj=tkNzmWicyQJYlqXCHEFOSarRTLpgdx.get(tkNzmWicyQJYlqXCHEFOSarRTLpgdG)
    tkNzmWicyQJYlqXCHEFOSarRTLpgdA={'title':tkNzmWicyQJYlqXCHEFOSarRTLpgdv.get('alt')or tkNzmWicyQJYlqXCHEFOSarRTLpgdv.get('title_list')[0].get('text'),'age':tkNzmWicyQJYlqXCHEFOSarRTLpgdv.get('age'),'thumbnail':tkNzmWicyQJYlqXCHEFOSarRTLpgdv.get('thumbnail'),'videoid':tkNzmWicyQJYlqXCHEFOSarRTLpgdj,'vidtype':tkNzmWicyQJYlqXCHEFOSarRTLpgdG,}
    if not tkNzmWicyQJYlqXCHEFOSarRTLpgdA.get('thumbnail').startswith('http'):
     tkNzmWicyQJYlqXCHEFOSarRTLpgdA['thumbnail']='https://%s'%tkNzmWicyQJYlqXCHEFOSarRTLpgdA['thumbnail']
    tkNzmWicyQJYlqXCHEFOSarRTLpgdM.append(tkNzmWicyQJYlqXCHEFOSarRTLpgdA)
   if tkNzmWicyQJYlqXCHEFOSarRTLpgvo.get('cell_toplist')not in[{},tkNzmWicyQJYlqXCHEFOSarRTLpgex,'']:
    tkNzmWicyQJYlqXCHEFOSarRTLpgdh=tkNzmWicyQJYlqXCHEFOSarRTLpgDs(tkNzmWicyQJYlqXCHEFOSarRTLpgvo['cell_toplist']['pagecount'])
    if tkNzmWicyQJYlqXCHEFOSarRTLpgvo['cell_toplist']['count']:tkNzmWicyQJYlqXCHEFOSarRTLpgdP =tkNzmWicyQJYlqXCHEFOSarRTLpgDs(tkNzmWicyQJYlqXCHEFOSarRTLpgvo['cell_toplist']['count'])
    else:tkNzmWicyQJYlqXCHEFOSarRTLpgdP=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.LIST_LIMIT*page_int
    tkNzmWicyQJYlqXCHEFOSarRTLpgdb=tkNzmWicyQJYlqXCHEFOSarRTLpgdh>tkNzmWicyQJYlqXCHEFOSarRTLpgdP
  except tkNzmWicyQJYlqXCHEFOSarRTLpgDn as exception:
   tkNzmWicyQJYlqXCHEFOSarRTLpgDV(exception)
   return[],tkNzmWicyQJYlqXCHEFOSarRTLpgeI
  return tkNzmWicyQJYlqXCHEFOSarRTLpgdM,tkNzmWicyQJYlqXCHEFOSarRTLpgdb
 def Get_Movie_List(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,tkNzmWicyQJYlqXCHEFOSarRTLpgvI,page_int=1,orderby='-'):
  tkNzmWicyQJYlqXCHEFOSarRTLpgdI=[]
  tkNzmWicyQJYlqXCHEFOSarRTLpgdh=tkNzmWicyQJYlqXCHEFOSarRTLpgdP=1
  tkNzmWicyQJYlqXCHEFOSarRTLpgdb=tkNzmWicyQJYlqXCHEFOSarRTLpgeI
  (tkNzmWicyQJYlqXCHEFOSarRTLpgvh,tkNzmWicyQJYlqXCHEFOSarRTLpgBf)=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.Baseapi_Parse(tkNzmWicyQJYlqXCHEFOSarRTLpgvI)
  if tkNzmWicyQJYlqXCHEFOSarRTLpgvh=='':return tkNzmWicyQJYlqXCHEFOSarRTLpgdI,tkNzmWicyQJYlqXCHEFOSarRTLpgdb
  try:
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf['limit']=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.MV_LIMIT
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf['offset']=tkNzmWicyQJYlqXCHEFOSarRTLpgDd((page_int-1)*tkNzmWicyQJYlqXCHEFOSarRTLpgBA.MV_LIMIT)
   if tkNzmWicyQJYlqXCHEFOSarRTLpgBf.get('orderby')!='' and tkNzmWicyQJYlqXCHEFOSarRTLpgBf.get('orderby')!='regdatefirst' and orderby!='-':
    tkNzmWicyQJYlqXCHEFOSarRTLpgBf['orderby']=orderby 
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf.update(tkNzmWicyQJYlqXCHEFOSarRTLpgBA.GetDefaultParams(login=tkNzmWicyQJYlqXCHEFOSarRTLpgeI))
   tkNzmWicyQJYlqXCHEFOSarRTLpgvf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.callRequestCookies('Get',tkNzmWicyQJYlqXCHEFOSarRTLpgvh,payload=tkNzmWicyQJYlqXCHEFOSarRTLpgex,params=tkNzmWicyQJYlqXCHEFOSarRTLpgBf,headers=tkNzmWicyQJYlqXCHEFOSarRTLpgex,cookies=tkNzmWicyQJYlqXCHEFOSarRTLpgex)
   tkNzmWicyQJYlqXCHEFOSarRTLpgvo=json.loads(tkNzmWicyQJYlqXCHEFOSarRTLpgvf.text)
   if tkNzmWicyQJYlqXCHEFOSarRTLpgvo.get('cell_toplist')not in[{},tkNzmWicyQJYlqXCHEFOSarRTLpgex,'']:
    tkNzmWicyQJYlqXCHEFOSarRTLpgdB=tkNzmWicyQJYlqXCHEFOSarRTLpgvo['cell_toplist']['celllist']
   elif tkNzmWicyQJYlqXCHEFOSarRTLpgvo.get('band')not in[{},tkNzmWicyQJYlqXCHEFOSarRTLpgex,'']:
    tkNzmWicyQJYlqXCHEFOSarRTLpgdB=tkNzmWicyQJYlqXCHEFOSarRTLpgvo['band']['celllist']
   else:
    return tkNzmWicyQJYlqXCHEFOSarRTLpgdI,tkNzmWicyQJYlqXCHEFOSarRTLpgdb
   for tkNzmWicyQJYlqXCHEFOSarRTLpgdv in tkNzmWicyQJYlqXCHEFOSarRTLpgdB:
    tkNzmWicyQJYlqXCHEFOSarRTLpgdf =tkNzmWicyQJYlqXCHEFOSarRTLpgdv['event_list'][1]['url']
    tkNzmWicyQJYlqXCHEFOSarRTLpgdo=urllib.parse.urlsplit(tkNzmWicyQJYlqXCHEFOSarRTLpgdf).query
    tkNzmWicyQJYlqXCHEFOSarRTLpgdG=tkNzmWicyQJYlqXCHEFOSarRTLpgdo[0:tkNzmWicyQJYlqXCHEFOSarRTLpgdo.find('=')]
    tkNzmWicyQJYlqXCHEFOSarRTLpgdx=tkNzmWicyQJYlqXCHEFOSarRTLpgDe(urllib.parse.parse_qsl(tkNzmWicyQJYlqXCHEFOSarRTLpgdo))
    tkNzmWicyQJYlqXCHEFOSarRTLpgdj=tkNzmWicyQJYlqXCHEFOSarRTLpgdx.get(tkNzmWicyQJYlqXCHEFOSarRTLpgdG)
    tkNzmWicyQJYlqXCHEFOSarRTLpgdA={'title':tkNzmWicyQJYlqXCHEFOSarRTLpgdv.get('alt')or tkNzmWicyQJYlqXCHEFOSarRTLpgdv.get('title_list')[0].get('text'),'age':tkNzmWicyQJYlqXCHEFOSarRTLpgdv.get('age'),'thumbnail':tkNzmWicyQJYlqXCHEFOSarRTLpgdv.get('thumbnail'),'videoid':tkNzmWicyQJYlqXCHEFOSarRTLpgdj,'vidtype':tkNzmWicyQJYlqXCHEFOSarRTLpgdG,}
    if not tkNzmWicyQJYlqXCHEFOSarRTLpgdA.get('thumbnail').startswith('http'):
     tkNzmWicyQJYlqXCHEFOSarRTLpgdA['thumbnail']='https://%s'%tkNzmWicyQJYlqXCHEFOSarRTLpgdA['thumbnail']
    tkNzmWicyQJYlqXCHEFOSarRTLpgdI.append(tkNzmWicyQJYlqXCHEFOSarRTLpgdA)
   if tkNzmWicyQJYlqXCHEFOSarRTLpgvo.get('cell_toplist')not in[{},tkNzmWicyQJYlqXCHEFOSarRTLpgex,'']:
    tkNzmWicyQJYlqXCHEFOSarRTLpgdh=tkNzmWicyQJYlqXCHEFOSarRTLpgDs(tkNzmWicyQJYlqXCHEFOSarRTLpgvo['cell_toplist']['pagecount'])
    if tkNzmWicyQJYlqXCHEFOSarRTLpgvo['cell_toplist']['count']:tkNzmWicyQJYlqXCHEFOSarRTLpgdP =tkNzmWicyQJYlqXCHEFOSarRTLpgDs(tkNzmWicyQJYlqXCHEFOSarRTLpgvo['cell_toplist']['count'])
    else:tkNzmWicyQJYlqXCHEFOSarRTLpgdP=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.MV_LIMIT*page_int
    tkNzmWicyQJYlqXCHEFOSarRTLpgdb=tkNzmWicyQJYlqXCHEFOSarRTLpgdh>tkNzmWicyQJYlqXCHEFOSarRTLpgdP
  except tkNzmWicyQJYlqXCHEFOSarRTLpgDn as exception:
   tkNzmWicyQJYlqXCHEFOSarRTLpgDV(exception)
   return[],tkNzmWicyQJYlqXCHEFOSarRTLpgeI
  return tkNzmWicyQJYlqXCHEFOSarRTLpgdI,tkNzmWicyQJYlqXCHEFOSarRTLpgdb
 def ProgramidToContentid(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,tkNzmWicyQJYlqXCHEFOSarRTLpgAv):
  tkNzmWicyQJYlqXCHEFOSarRTLpgdU=''
  try:
   tkNzmWicyQJYlqXCHEFOSarRTLpgvh =tkNzmWicyQJYlqXCHEFOSarRTLpgBA.API_DOMAIN+'/vod/programs-contentid/'+tkNzmWicyQJYlqXCHEFOSarRTLpgAv
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.GetDefaultParams(login=tkNzmWicyQJYlqXCHEFOSarRTLpgeI)
   tkNzmWicyQJYlqXCHEFOSarRTLpgvf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.callRequestCookies('Get',tkNzmWicyQJYlqXCHEFOSarRTLpgvh,payload=tkNzmWicyQJYlqXCHEFOSarRTLpgex,params=tkNzmWicyQJYlqXCHEFOSarRTLpgBf,headers=tkNzmWicyQJYlqXCHEFOSarRTLpgex,cookies=tkNzmWicyQJYlqXCHEFOSarRTLpgex)
   tkNzmWicyQJYlqXCHEFOSarRTLpgAB=json.loads(tkNzmWicyQJYlqXCHEFOSarRTLpgvf.text)
   if not('contentid' in tkNzmWicyQJYlqXCHEFOSarRTLpgAB):return tkNzmWicyQJYlqXCHEFOSarRTLpgdU 
   tkNzmWicyQJYlqXCHEFOSarRTLpgdU=tkNzmWicyQJYlqXCHEFOSarRTLpgAB['contentid']
  except tkNzmWicyQJYlqXCHEFOSarRTLpgDn as exception:
   tkNzmWicyQJYlqXCHEFOSarRTLpgDV(exception)
  return tkNzmWicyQJYlqXCHEFOSarRTLpgdU
 def ContentidToSeasonid(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,tkNzmWicyQJYlqXCHEFOSarRTLpgdU):
  tkNzmWicyQJYlqXCHEFOSarRTLpgAv=''
  try:
   tkNzmWicyQJYlqXCHEFOSarRTLpgvh =tkNzmWicyQJYlqXCHEFOSarRTLpgBA.API_DOMAIN+'/fz/vod/contents/'+tkNzmWicyQJYlqXCHEFOSarRTLpgdU
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.GetDefaultParams(login=tkNzmWicyQJYlqXCHEFOSarRTLpgeI)
   tkNzmWicyQJYlqXCHEFOSarRTLpgvf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.callRequestCookies('Get',tkNzmWicyQJYlqXCHEFOSarRTLpgvh,payload=tkNzmWicyQJYlqXCHEFOSarRTLpgex,params=tkNzmWicyQJYlqXCHEFOSarRTLpgBf,headers=tkNzmWicyQJYlqXCHEFOSarRTLpgex,cookies=tkNzmWicyQJYlqXCHEFOSarRTLpgex)
   tkNzmWicyQJYlqXCHEFOSarRTLpgAB=json.loads(tkNzmWicyQJYlqXCHEFOSarRTLpgvf.text)
   if not('programid' in tkNzmWicyQJYlqXCHEFOSarRTLpgAB):return tkNzmWicyQJYlqXCHEFOSarRTLpgAv 
   tkNzmWicyQJYlqXCHEFOSarRTLpgAv=tkNzmWicyQJYlqXCHEFOSarRTLpgAB['programid']
  except tkNzmWicyQJYlqXCHEFOSarRTLpgDn as exception:
   tkNzmWicyQJYlqXCHEFOSarRTLpgDV(exception)
  return tkNzmWicyQJYlqXCHEFOSarRTLpgAv
 def GetProgramInfo(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,tkNzmWicyQJYlqXCHEFOSarRTLpgdU):
  tkNzmWicyQJYlqXCHEFOSarRTLpgAd={}
  try:
   tkNzmWicyQJYlqXCHEFOSarRTLpgvh=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.API_DOMAIN+'/fz/vod/contents/'+tkNzmWicyQJYlqXCHEFOSarRTLpgdU
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.GetDefaultParams(login=tkNzmWicyQJYlqXCHEFOSarRTLpgeI)
   tkNzmWicyQJYlqXCHEFOSarRTLpgvf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.callRequestCookies('Get',tkNzmWicyQJYlqXCHEFOSarRTLpgvh,payload=tkNzmWicyQJYlqXCHEFOSarRTLpgex,params=tkNzmWicyQJYlqXCHEFOSarRTLpgBf,headers=tkNzmWicyQJYlqXCHEFOSarRTLpgex,cookies=tkNzmWicyQJYlqXCHEFOSarRTLpgex)
   tkNzmWicyQJYlqXCHEFOSarRTLpgAB=json.loads(tkNzmWicyQJYlqXCHEFOSarRTLpgvf.text)
   tkNzmWicyQJYlqXCHEFOSarRTLpgAn=img_fanart=tkNzmWicyQJYlqXCHEFOSarRTLpgAV=''
   if tkNzmWicyQJYlqXCHEFOSarRTLpgAB.get('programposterimage')!='':tkNzmWicyQJYlqXCHEFOSarRTLpgAn =tkNzmWicyQJYlqXCHEFOSarRTLpgBA.HTTPTAG+tkNzmWicyQJYlqXCHEFOSarRTLpgAB.get('programposterimage')
   if tkNzmWicyQJYlqXCHEFOSarRTLpgAB.get('programimage') !='':img_fanart =tkNzmWicyQJYlqXCHEFOSarRTLpgBA.HTTPTAG+tkNzmWicyQJYlqXCHEFOSarRTLpgAB.get('programimage')
   if tkNzmWicyQJYlqXCHEFOSarRTLpgAB.get('programcircleimage')!='':tkNzmWicyQJYlqXCHEFOSarRTLpgAV=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.HTTPTAG+tkNzmWicyQJYlqXCHEFOSarRTLpgAB.get('programcircleimage')
   if 'poster_default' in tkNzmWicyQJYlqXCHEFOSarRTLpgAn:
    tkNzmWicyQJYlqXCHEFOSarRTLpgAn =img_fanart
    tkNzmWicyQJYlqXCHEFOSarRTLpgAV=''
   tkNzmWicyQJYlqXCHEFOSarRTLpgAd={'imgPoster':tkNzmWicyQJYlqXCHEFOSarRTLpgAn,'imgFanart':img_fanart,'imgClearlogo':tkNzmWicyQJYlqXCHEFOSarRTLpgAV,'programtitle':tkNzmWicyQJYlqXCHEFOSarRTLpgAB.get('programtitle'),'programid':tkNzmWicyQJYlqXCHEFOSarRTLpgAB.get('programid'),'synopsis':tkNzmWicyQJYlqXCHEFOSarRTLpgBA.Get_ChangeText(tkNzmWicyQJYlqXCHEFOSarRTLpgAB.get('programsynopsis')),}
  except tkNzmWicyQJYlqXCHEFOSarRTLpgDn as exception:
   tkNzmWicyQJYlqXCHEFOSarRTLpgDV(exception)
  return tkNzmWicyQJYlqXCHEFOSarRTLpgAd
 def Get_Season_List(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,seasonid):
  tkNzmWicyQJYlqXCHEFOSarRTLpgAe=[]
  tkNzmWicyQJYlqXCHEFOSarRTLpgdU=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.ProgramidToContentid(seasonid)
  tkNzmWicyQJYlqXCHEFOSarRTLpgAD=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.GetProgramInfo(tkNzmWicyQJYlqXCHEFOSarRTLpgdU)
  tkNzmWicyQJYlqXCHEFOSarRTLpgAs={'poster':tkNzmWicyQJYlqXCHEFOSarRTLpgAD.get('imgPoster'),'fanart':tkNzmWicyQJYlqXCHEFOSarRTLpgAD.get('imgFanart'),'clearlogo':tkNzmWicyQJYlqXCHEFOSarRTLpgAD.get('imgClearlogo'),}
  try:
   tkNzmWicyQJYlqXCHEFOSarRTLpgvh=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.API_DOMAIN+'/fz/vod/programs-contents/'+seasonid
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf={'limit':'10','offset':'0','orderby':'new',}
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf.update(tkNzmWicyQJYlqXCHEFOSarRTLpgBA.GetDefaultParams(login=tkNzmWicyQJYlqXCHEFOSarRTLpgeI))
   tkNzmWicyQJYlqXCHEFOSarRTLpgvf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.callRequestCookies('Get',tkNzmWicyQJYlqXCHEFOSarRTLpgvh,payload=tkNzmWicyQJYlqXCHEFOSarRTLpgex,params=tkNzmWicyQJYlqXCHEFOSarRTLpgBf,headers=tkNzmWicyQJYlqXCHEFOSarRTLpgex,cookies=tkNzmWicyQJYlqXCHEFOSarRTLpgex)
   tkNzmWicyQJYlqXCHEFOSarRTLpgvo=json.loads(tkNzmWicyQJYlqXCHEFOSarRTLpgvf.text)
   for tkNzmWicyQJYlqXCHEFOSarRTLpgAu in tkNzmWicyQJYlqXCHEFOSarRTLpgvo['filter']['filterlist'][0]['filter_item_list']:
    tkNzmWicyQJYlqXCHEFOSarRTLpgdA={'season_Nm':tkNzmWicyQJYlqXCHEFOSarRTLpgAu.get('title'),'season_Id':tkNzmWicyQJYlqXCHEFOSarRTLpgAu.get('api_path'),'thumbnail':tkNzmWicyQJYlqXCHEFOSarRTLpgAs,'programNm':tkNzmWicyQJYlqXCHEFOSarRTLpgAD.get('programtitle'),'synopsis':tkNzmWicyQJYlqXCHEFOSarRTLpgBA.Get_ChangeText(tkNzmWicyQJYlqXCHEFOSarRTLpgAD.get('synopsis')),}
    tkNzmWicyQJYlqXCHEFOSarRTLpgAe.append(tkNzmWicyQJYlqXCHEFOSarRTLpgdA)
  except tkNzmWicyQJYlqXCHEFOSarRTLpgDn as exception:
   tkNzmWicyQJYlqXCHEFOSarRTLpgDV(exception)
   return[]
  return tkNzmWicyQJYlqXCHEFOSarRTLpgAe
 def Get_Episode_List(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,seasionid,page_int=1,orderby='desc'):
  tkNzmWicyQJYlqXCHEFOSarRTLpgAh=[]
  tkNzmWicyQJYlqXCHEFOSarRTLpgdh=tkNzmWicyQJYlqXCHEFOSarRTLpgdP=1
  tkNzmWicyQJYlqXCHEFOSarRTLpgdb=tkNzmWicyQJYlqXCHEFOSarRTLpgeI
  tkNzmWicyQJYlqXCHEFOSarRTLpgAD={}
  tkNzmWicyQJYlqXCHEFOSarRTLpgdU=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.ProgramidToContentid(seasionid)
  tkNzmWicyQJYlqXCHEFOSarRTLpgAD=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.GetProgramInfo(tkNzmWicyQJYlqXCHEFOSarRTLpgdU)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   tkNzmWicyQJYlqXCHEFOSarRTLpgvh=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.API_DOMAIN+'/fz/vod/programs-contents/'+seasionid
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf={'limit':tkNzmWicyQJYlqXCHEFOSarRTLpgBA.EP_LIMIT,'offset':tkNzmWicyQJYlqXCHEFOSarRTLpgDd((page_int-1)*tkNzmWicyQJYlqXCHEFOSarRTLpgBA.EP_LIMIT),'orderby':orderby,}
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf.update(tkNzmWicyQJYlqXCHEFOSarRTLpgBA.GetDefaultParams(login=tkNzmWicyQJYlqXCHEFOSarRTLpgeI))
   tkNzmWicyQJYlqXCHEFOSarRTLpgvf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.callRequestCookies('Get',tkNzmWicyQJYlqXCHEFOSarRTLpgvh,payload=tkNzmWicyQJYlqXCHEFOSarRTLpgex,params=tkNzmWicyQJYlqXCHEFOSarRTLpgBf,headers=tkNzmWicyQJYlqXCHEFOSarRTLpgex,cookies=tkNzmWicyQJYlqXCHEFOSarRTLpgex)
   tkNzmWicyQJYlqXCHEFOSarRTLpgvo=json.loads(tkNzmWicyQJYlqXCHEFOSarRTLpgvf.text)
   tkNzmWicyQJYlqXCHEFOSarRTLpgdB=tkNzmWicyQJYlqXCHEFOSarRTLpgvo['cell_toplist']['celllist']
   for tkNzmWicyQJYlqXCHEFOSarRTLpgdv in tkNzmWicyQJYlqXCHEFOSarRTLpgdB:
    tkNzmWicyQJYlqXCHEFOSarRTLpgAf=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',tkNzmWicyQJYlqXCHEFOSarRTLpgdv.get('synopsis'))
    tkNzmWicyQJYlqXCHEFOSarRTLpgAo=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.HTTPTAG+tkNzmWicyQJYlqXCHEFOSarRTLpgdv.get('thumbnail')
    tkNzmWicyQJYlqXCHEFOSarRTLpgAG=tkNzmWicyQJYlqXCHEFOSarRTLpgAj=tkNzmWicyQJYlqXCHEFOSarRTLpgAP=''
    tkNzmWicyQJYlqXCHEFOSarRTLpgAG =tkNzmWicyQJYlqXCHEFOSarRTLpgAD.get('imgPoster')
    tkNzmWicyQJYlqXCHEFOSarRTLpgAj =tkNzmWicyQJYlqXCHEFOSarRTLpgAD.get('imgFanart')
    tkNzmWicyQJYlqXCHEFOSarRTLpgAP =tkNzmWicyQJYlqXCHEFOSarRTLpgAD.get('imgClearlogo')
    tkNzmWicyQJYlqXCHEFOSarRTLpgAK=tkNzmWicyQJYlqXCHEFOSarRTLpgAD.get('programtitle')
    tkNzmWicyQJYlqXCHEFOSarRTLpgAs={'thumb':tkNzmWicyQJYlqXCHEFOSarRTLpgAo,'poster':tkNzmWicyQJYlqXCHEFOSarRTLpgAG,'fanart':tkNzmWicyQJYlqXCHEFOSarRTLpgAj,'clearlogo':tkNzmWicyQJYlqXCHEFOSarRTLpgAP}
    tkNzmWicyQJYlqXCHEFOSarRTLpgdA={'programtitle':tkNzmWicyQJYlqXCHEFOSarRTLpgAK,'episodetitle':tkNzmWicyQJYlqXCHEFOSarRTLpgdv['title_list'][0]['text'],'episodenumber':tkNzmWicyQJYlqXCHEFOSarRTLpgdv['title_list'][1]['text'].replace('$O$',''),'contentid':tkNzmWicyQJYlqXCHEFOSarRTLpgdv['contentid'],'synopsis':tkNzmWicyQJYlqXCHEFOSarRTLpgBA.Get_ChangeText(tkNzmWicyQJYlqXCHEFOSarRTLpgAf),'episodeactors':tkNzmWicyQJYlqXCHEFOSarRTLpgdv.get('actors').split(',')if tkNzmWicyQJYlqXCHEFOSarRTLpgdv.get('actors')!='' else[],'thumbnail':tkNzmWicyQJYlqXCHEFOSarRTLpgAs,}
    tkNzmWicyQJYlqXCHEFOSarRTLpgAh.append(tkNzmWicyQJYlqXCHEFOSarRTLpgdA)
   tkNzmWicyQJYlqXCHEFOSarRTLpgdh=tkNzmWicyQJYlqXCHEFOSarRTLpgDs(tkNzmWicyQJYlqXCHEFOSarRTLpgvo['cell_toplist']['pagecount'])
   if tkNzmWicyQJYlqXCHEFOSarRTLpgvo['cell_toplist']['count']:tkNzmWicyQJYlqXCHEFOSarRTLpgdP =tkNzmWicyQJYlqXCHEFOSarRTLpgDs(tkNzmWicyQJYlqXCHEFOSarRTLpgvo['cell_toplist']['count'])
   else:tkNzmWicyQJYlqXCHEFOSarRTLpgdP=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.EP_LIMIT*page_int
   tkNzmWicyQJYlqXCHEFOSarRTLpgdb=tkNzmWicyQJYlqXCHEFOSarRTLpgdh>tkNzmWicyQJYlqXCHEFOSarRTLpgdP
  except tkNzmWicyQJYlqXCHEFOSarRTLpgDn as exception:
   tkNzmWicyQJYlqXCHEFOSarRTLpgDV(exception)
   return[],tkNzmWicyQJYlqXCHEFOSarRTLpgeI
  return tkNzmWicyQJYlqXCHEFOSarRTLpgAh,tkNzmWicyQJYlqXCHEFOSarRTLpgdb
 def GetEPGList(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,genre):
  tkNzmWicyQJYlqXCHEFOSarRTLpgAM={}
  try:
   tkNzmWicyQJYlqXCHEFOSarRTLpgAw=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.Get_Now_Datetime()
   if genre=='all':
    tkNzmWicyQJYlqXCHEFOSarRTLpgAx =tkNzmWicyQJYlqXCHEFOSarRTLpgAw+datetime.timedelta(hours=3)
   else:
    tkNzmWicyQJYlqXCHEFOSarRTLpgAx =tkNzmWicyQJYlqXCHEFOSarRTLpgAw+datetime.timedelta(hours=3)
   tkNzmWicyQJYlqXCHEFOSarRTLpgvh=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.API_DOMAIN+'/live/epgs'
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf={'limit':'100','offset':'0','genre':genre,'startdatetime':tkNzmWicyQJYlqXCHEFOSarRTLpgAw.strftime('%Y-%m-%d %H:00'),'enddatetime':tkNzmWicyQJYlqXCHEFOSarRTLpgAx.strftime('%Y-%m-%d %H:00')}
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf.update(tkNzmWicyQJYlqXCHEFOSarRTLpgBA.GetDefaultParams(login=tkNzmWicyQJYlqXCHEFOSarRTLpgeI))
   tkNzmWicyQJYlqXCHEFOSarRTLpgvf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.callRequestCookies('Get',tkNzmWicyQJYlqXCHEFOSarRTLpgvh,payload=tkNzmWicyQJYlqXCHEFOSarRTLpgex,params=tkNzmWicyQJYlqXCHEFOSarRTLpgBf,headers=tkNzmWicyQJYlqXCHEFOSarRTLpgex,cookies=tkNzmWicyQJYlqXCHEFOSarRTLpgex)
   tkNzmWicyQJYlqXCHEFOSarRTLpgvo=json.loads(tkNzmWicyQJYlqXCHEFOSarRTLpgvf.text)
   tkNzmWicyQJYlqXCHEFOSarRTLpgAI=tkNzmWicyQJYlqXCHEFOSarRTLpgvo['list']
   for tkNzmWicyQJYlqXCHEFOSarRTLpgdv in tkNzmWicyQJYlqXCHEFOSarRTLpgAI:
    tkNzmWicyQJYlqXCHEFOSarRTLpgAU=''
    for tkNzmWicyQJYlqXCHEFOSarRTLpgnB in tkNzmWicyQJYlqXCHEFOSarRTLpgdv['list']:
     if tkNzmWicyQJYlqXCHEFOSarRTLpgAU:tkNzmWicyQJYlqXCHEFOSarRTLpgAU+='\n'
     tkNzmWicyQJYlqXCHEFOSarRTLpgAU+=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.Get_ChangeText(tkNzmWicyQJYlqXCHEFOSarRTLpgnB['title'])+'\n'
     tkNzmWicyQJYlqXCHEFOSarRTLpgAU+=' [%s ~ %s]'%(tkNzmWicyQJYlqXCHEFOSarRTLpgnB['starttime'][-5:],tkNzmWicyQJYlqXCHEFOSarRTLpgnB['endtime'][-5:])+'\n'
    tkNzmWicyQJYlqXCHEFOSarRTLpgAM[tkNzmWicyQJYlqXCHEFOSarRTLpgdv['channelid']]=tkNzmWicyQJYlqXCHEFOSarRTLpgAU
  except tkNzmWicyQJYlqXCHEFOSarRTLpgDn as exception:
   tkNzmWicyQJYlqXCHEFOSarRTLpgDV(exception)
  return tkNzmWicyQJYlqXCHEFOSarRTLpgAM
 def Get_LiveChannel_List(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,genre,tkNzmWicyQJYlqXCHEFOSarRTLpgvI):
  tkNzmWicyQJYlqXCHEFOSarRTLpgdu=[]
  (tkNzmWicyQJYlqXCHEFOSarRTLpgvh,tkNzmWicyQJYlqXCHEFOSarRTLpgBf)=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.Baseapi_Parse(tkNzmWicyQJYlqXCHEFOSarRTLpgvI)
  if tkNzmWicyQJYlqXCHEFOSarRTLpgvh=='':return tkNzmWicyQJYlqXCHEFOSarRTLpgdu
  tkNzmWicyQJYlqXCHEFOSarRTLpgnv=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.GetEPGList(genre)
  try:
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf.update(tkNzmWicyQJYlqXCHEFOSarRTLpgBA.GetDefaultParams(login=tkNzmWicyQJYlqXCHEFOSarRTLpgeI))
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf['genre']=genre
   tkNzmWicyQJYlqXCHEFOSarRTLpgvf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.callRequestCookies('Get',tkNzmWicyQJYlqXCHEFOSarRTLpgvh,payload=tkNzmWicyQJYlqXCHEFOSarRTLpgex,params=tkNzmWicyQJYlqXCHEFOSarRTLpgBf,headers=tkNzmWicyQJYlqXCHEFOSarRTLpgex,cookies=tkNzmWicyQJYlqXCHEFOSarRTLpgex)
   tkNzmWicyQJYlqXCHEFOSarRTLpgvo=json.loads(tkNzmWicyQJYlqXCHEFOSarRTLpgvf.text)
   if not('celllist' in tkNzmWicyQJYlqXCHEFOSarRTLpgvo['cell_toplist']):return[]
   tkNzmWicyQJYlqXCHEFOSarRTLpgdB=tkNzmWicyQJYlqXCHEFOSarRTLpgvo['cell_toplist']['celllist']
   for tkNzmWicyQJYlqXCHEFOSarRTLpgdv in tkNzmWicyQJYlqXCHEFOSarRTLpgdB:
    tkNzmWicyQJYlqXCHEFOSarRTLpgdU=tkNzmWicyQJYlqXCHEFOSarRTLpgdv['contentid']
    if tkNzmWicyQJYlqXCHEFOSarRTLpgdU in tkNzmWicyQJYlqXCHEFOSarRTLpgnv:
     tkNzmWicyQJYlqXCHEFOSarRTLpgnd=tkNzmWicyQJYlqXCHEFOSarRTLpgnv[tkNzmWicyQJYlqXCHEFOSarRTLpgdU]
    else:
     tkNzmWicyQJYlqXCHEFOSarRTLpgnd=''
    tkNzmWicyQJYlqXCHEFOSarRTLpgdA={'studio':tkNzmWicyQJYlqXCHEFOSarRTLpgdv['title_list'][0]['text'],'tvshowtitle':tkNzmWicyQJYlqXCHEFOSarRTLpgBA.Get_ChangeText(tkNzmWicyQJYlqXCHEFOSarRTLpgdv['title_list'][1]['text']),'channelid':tkNzmWicyQJYlqXCHEFOSarRTLpgdU,'age':tkNzmWicyQJYlqXCHEFOSarRTLpgdv['age'],'thumbnail':'https://%s'%tkNzmWicyQJYlqXCHEFOSarRTLpgdv.get('thumbnail'),'epg':tkNzmWicyQJYlqXCHEFOSarRTLpgnd}
    tkNzmWicyQJYlqXCHEFOSarRTLpgdu.append(tkNzmWicyQJYlqXCHEFOSarRTLpgdA)
  except tkNzmWicyQJYlqXCHEFOSarRTLpgDn as exception:
   tkNzmWicyQJYlqXCHEFOSarRTLpgDV(exception)
   return[]
  return tkNzmWicyQJYlqXCHEFOSarRTLpgdu
 def Get_Search_List(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,search_key,sType,page_int,exclusion21=tkNzmWicyQJYlqXCHEFOSarRTLpgeI):
  tkNzmWicyQJYlqXCHEFOSarRTLpgnA=[]
  tkNzmWicyQJYlqXCHEFOSarRTLpgdh=tkNzmWicyQJYlqXCHEFOSarRTLpgdP=1
  tkNzmWicyQJYlqXCHEFOSarRTLpgdb=tkNzmWicyQJYlqXCHEFOSarRTLpgeI
  try:
   tkNzmWicyQJYlqXCHEFOSarRTLpgvh=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.API_DOMAIN+'/fz/search/band.js'
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':tkNzmWicyQJYlqXCHEFOSarRTLpgDd((page_int-1)*tkNzmWicyQJYlqXCHEFOSarRTLpgBA.SEARCH_LIMIT),'limit':tkNzmWicyQJYlqXCHEFOSarRTLpgBA.SEARCH_LIMIT,'orderby':'score','mtype':'svod',}
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf.update(tkNzmWicyQJYlqXCHEFOSarRTLpgBA.GetDefaultParams(login=tkNzmWicyQJYlqXCHEFOSarRTLpgeI))
   tkNzmWicyQJYlqXCHEFOSarRTLpgvf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.callRequestCookies('Get',tkNzmWicyQJYlqXCHEFOSarRTLpgvh,payload=tkNzmWicyQJYlqXCHEFOSarRTLpgex,params=tkNzmWicyQJYlqXCHEFOSarRTLpgBf,headers=tkNzmWicyQJYlqXCHEFOSarRTLpgex,cookies=tkNzmWicyQJYlqXCHEFOSarRTLpgex)
   tkNzmWicyQJYlqXCHEFOSarRTLpgAB=json.loads(tkNzmWicyQJYlqXCHEFOSarRTLpgvf.text)
   if not('celllist' in tkNzmWicyQJYlqXCHEFOSarRTLpgAB['band']):return tkNzmWicyQJYlqXCHEFOSarRTLpgnA,tkNzmWicyQJYlqXCHEFOSarRTLpgdb
   tkNzmWicyQJYlqXCHEFOSarRTLpgdB=tkNzmWicyQJYlqXCHEFOSarRTLpgAB['band']['celllist']
   for tkNzmWicyQJYlqXCHEFOSarRTLpgdv in tkNzmWicyQJYlqXCHEFOSarRTLpgdB:
    tkNzmWicyQJYlqXCHEFOSarRTLpgdf =tkNzmWicyQJYlqXCHEFOSarRTLpgdv['event_list'][1]['url']
    tkNzmWicyQJYlqXCHEFOSarRTLpgdo=urllib.parse.urlsplit(tkNzmWicyQJYlqXCHEFOSarRTLpgdf).query
    tkNzmWicyQJYlqXCHEFOSarRTLpgdG=tkNzmWicyQJYlqXCHEFOSarRTLpgdo[0:tkNzmWicyQJYlqXCHEFOSarRTLpgdo.find('=')]
    tkNzmWicyQJYlqXCHEFOSarRTLpgdx=tkNzmWicyQJYlqXCHEFOSarRTLpgDe(urllib.parse.parse_qsl(tkNzmWicyQJYlqXCHEFOSarRTLpgdo))
    tkNzmWicyQJYlqXCHEFOSarRTLpgdj=tkNzmWicyQJYlqXCHEFOSarRTLpgdx.get(tkNzmWicyQJYlqXCHEFOSarRTLpgdG)
    tkNzmWicyQJYlqXCHEFOSarRTLpgdA={'title':tkNzmWicyQJYlqXCHEFOSarRTLpgdv['title_list'][0]['text'],'age':tkNzmWicyQJYlqXCHEFOSarRTLpgdv['age'],'thumbnail':'https://%s'%tkNzmWicyQJYlqXCHEFOSarRTLpgdv.get('thumbnail'),'videoid':tkNzmWicyQJYlqXCHEFOSarRTLpgdj,'vidtype':tkNzmWicyQJYlqXCHEFOSarRTLpgdG,}
    tkNzmWicyQJYlqXCHEFOSarRTLpgnV=tkNzmWicyQJYlqXCHEFOSarRTLpgeI
    for tkNzmWicyQJYlqXCHEFOSarRTLpgne in tkNzmWicyQJYlqXCHEFOSarRTLpgdv['bottom_taglist']:
     if tkNzmWicyQJYlqXCHEFOSarRTLpgne=='won':
      tkNzmWicyQJYlqXCHEFOSarRTLpgnV=tkNzmWicyQJYlqXCHEFOSarRTLpgDB
      break
    if tkNzmWicyQJYlqXCHEFOSarRTLpgnV==tkNzmWicyQJYlqXCHEFOSarRTLpgDB: 
     tkNzmWicyQJYlqXCHEFOSarRTLpgdA['title']=tkNzmWicyQJYlqXCHEFOSarRTLpgdA['title']+' [개별구매]'
    if exclusion21==tkNzmWicyQJYlqXCHEFOSarRTLpgeI or tkNzmWicyQJYlqXCHEFOSarRTLpgdv.get('age')!='21':
     tkNzmWicyQJYlqXCHEFOSarRTLpgnA.append(tkNzmWicyQJYlqXCHEFOSarRTLpgdA)
   tkNzmWicyQJYlqXCHEFOSarRTLpgdh=tkNzmWicyQJYlqXCHEFOSarRTLpgDs(tkNzmWicyQJYlqXCHEFOSarRTLpgAB['band']['pagecount'])
   if tkNzmWicyQJYlqXCHEFOSarRTLpgAB['band']['count']:tkNzmWicyQJYlqXCHEFOSarRTLpgdP =tkNzmWicyQJYlqXCHEFOSarRTLpgDs(tkNzmWicyQJYlqXCHEFOSarRTLpgAB['band']['count'])
   else:tkNzmWicyQJYlqXCHEFOSarRTLpgdP=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.LIST_LIMIT
   tkNzmWicyQJYlqXCHEFOSarRTLpgdb=tkNzmWicyQJYlqXCHEFOSarRTLpgdh>tkNzmWicyQJYlqXCHEFOSarRTLpgdP
  except tkNzmWicyQJYlqXCHEFOSarRTLpgDn as exception:
   tkNzmWicyQJYlqXCHEFOSarRTLpgDV(exception)
  return tkNzmWicyQJYlqXCHEFOSarRTLpgnA,tkNzmWicyQJYlqXCHEFOSarRTLpgdb 
 def GetSecureToken(tkNzmWicyQJYlqXCHEFOSarRTLpgBA):
  tkNzmWicyQJYlqXCHEFOSarRTLpgvh=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.API_DOMAIN+'/ip'
  tkNzmWicyQJYlqXCHEFOSarRTLpgBf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.GetDefaultParams(login=tkNzmWicyQJYlqXCHEFOSarRTLpgeI)
  tkNzmWicyQJYlqXCHEFOSarRTLpgvf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.callRequestCookies('Get',tkNzmWicyQJYlqXCHEFOSarRTLpgvh,payload=tkNzmWicyQJYlqXCHEFOSarRTLpgex,params=tkNzmWicyQJYlqXCHEFOSarRTLpgBf,headers=tkNzmWicyQJYlqXCHEFOSarRTLpgex,cookies=tkNzmWicyQJYlqXCHEFOSarRTLpgex)
  tkNzmWicyQJYlqXCHEFOSarRTLpgvo=json.loads(tkNzmWicyQJYlqXCHEFOSarRTLpgvf.text)
  return tkNzmWicyQJYlqXCHEFOSarRTLpgvo['securetoken']
 def Wavve_Parse_m3u8(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,tkNzmWicyQJYlqXCHEFOSarRTLpgVD):
  try:
   tkNzmWicyQJYlqXCHEFOSarRTLpgvD={'user-agent':'pooqV2/5.6.0 (Linux;Android 10) ExoPlayerLib/2.13.3'}
   tkNzmWicyQJYlqXCHEFOSarRTLpgvf=requests.get(url=tkNzmWicyQJYlqXCHEFOSarRTLpgVD['stream_url'],headers=tkNzmWicyQJYlqXCHEFOSarRTLpgvD,cookies=tkNzmWicyQJYlqXCHEFOSarRTLpgVD['stream_cookie'])
   tkNzmWicyQJYlqXCHEFOSarRTLpgnD=tkNzmWicyQJYlqXCHEFOSarRTLpgvf.content.decode('utf-8')
   if '#EXTM3U' not in tkNzmWicyQJYlqXCHEFOSarRTLpgnD:
    return tkNzmWicyQJYlqXCHEFOSarRTLpgeI
   if '#EXT-X-STREAM-INF' not in tkNzmWicyQJYlqXCHEFOSarRTLpgnD: 
    return tkNzmWicyQJYlqXCHEFOSarRTLpgeI
   tkNzmWicyQJYlqXCHEFOSarRTLpgns=0
   for tkNzmWicyQJYlqXCHEFOSarRTLpgnu in tkNzmWicyQJYlqXCHEFOSarRTLpgnD.splitlines():
    if tkNzmWicyQJYlqXCHEFOSarRTLpgnu.startswith('#EXT-X-STREAM-INF'):
     tkNzmWicyQJYlqXCHEFOSarRTLpgnh=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.MediaLine_Parse(tkNzmWicyQJYlqXCHEFOSarRTLpgnu,'#EXT-X-STREAM-INF')
     if tkNzmWicyQJYlqXCHEFOSarRTLpgns<tkNzmWicyQJYlqXCHEFOSarRTLpgDs(tkNzmWicyQJYlqXCHEFOSarRTLpgnh.get('BANDWIDTH')):
      tkNzmWicyQJYlqXCHEFOSarRTLpgns=tkNzmWicyQJYlqXCHEFOSarRTLpgDs(tkNzmWicyQJYlqXCHEFOSarRTLpgnh.get('BANDWIDTH'))
   tkNzmWicyQJYlqXCHEFOSarRTLpgnb=[]
   tkNzmWicyQJYlqXCHEFOSarRTLpgnf=tkNzmWicyQJYlqXCHEFOSarRTLpgeI
   for tkNzmWicyQJYlqXCHEFOSarRTLpgnu in tkNzmWicyQJYlqXCHEFOSarRTLpgnD.splitlines():
    if tkNzmWicyQJYlqXCHEFOSarRTLpgnf==tkNzmWicyQJYlqXCHEFOSarRTLpgDB:
     tkNzmWicyQJYlqXCHEFOSarRTLpgnf=tkNzmWicyQJYlqXCHEFOSarRTLpgeI
     continue
    if tkNzmWicyQJYlqXCHEFOSarRTLpgnu.startswith('#EXT-X-STREAM-INF'):
     tkNzmWicyQJYlqXCHEFOSarRTLpgnh=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.MediaLine_Parse(tkNzmWicyQJYlqXCHEFOSarRTLpgnu,'#EXT-X-STREAM-INF')
     if tkNzmWicyQJYlqXCHEFOSarRTLpgns!=tkNzmWicyQJYlqXCHEFOSarRTLpgDs(tkNzmWicyQJYlqXCHEFOSarRTLpgnh.get('BANDWIDTH')):
      tkNzmWicyQJYlqXCHEFOSarRTLpgnf=tkNzmWicyQJYlqXCHEFOSarRTLpgDB
      continue
    tkNzmWicyQJYlqXCHEFOSarRTLpgnb.append(tkNzmWicyQJYlqXCHEFOSarRTLpgnu)
  except tkNzmWicyQJYlqXCHEFOSarRTLpgDn as exception:
   tkNzmWicyQJYlqXCHEFOSarRTLpgDV(exception)
   return tkNzmWicyQJYlqXCHEFOSarRTLpgeI
  tkNzmWicyQJYlqXCHEFOSarRTLpgno='\n'.join(tkNzmWicyQJYlqXCHEFOSarRTLpgnb)
  tkNzmWicyQJYlqXCHEFOSarRTLpgBA.TextFile_Save(tkNzmWicyQJYlqXCHEFOSarRTLpgBA.WV_STREAM_FILENAME,tkNzmWicyQJYlqXCHEFOSarRTLpgno)
  return tkNzmWicyQJYlqXCHEFOSarRTLpgDB
 def Wavve_Parse_mpd(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,tkNzmWicyQJYlqXCHEFOSarRTLpgVD):
  tkNzmWicyQJYlqXCHEFOSarRTLpgvD={'user-agent':'pooqV2/5.6.0 (Linux;Android 10) ExoPlayerLib/2.13.3'}
  tkNzmWicyQJYlqXCHEFOSarRTLpgvf=requests.get(url=tkNzmWicyQJYlqXCHEFOSarRTLpgVD['stream_url'],headers=tkNzmWicyQJYlqXCHEFOSarRTLpgvD,cookies=tkNzmWicyQJYlqXCHEFOSarRTLpgVD['stream_cookie'])
  tkNzmWicyQJYlqXCHEFOSarRTLpgnG=tkNzmWicyQJYlqXCHEFOSarRTLpgvf.content.decode('utf-8')
  tkNzmWicyQJYlqXCHEFOSarRTLpgnj =ET.ElementTree(ET.fromstring(tkNzmWicyQJYlqXCHEFOSarRTLpgnG))
  tkNzmWicyQJYlqXCHEFOSarRTLpgnP =tkNzmWicyQJYlqXCHEFOSarRTLpgnj.getroot()
  tkNzmWicyQJYlqXCHEFOSarRTLpgnK=re.match(r'\{.*\}',tkNzmWicyQJYlqXCHEFOSarRTLpgnP.tag)[0] 
  tkNzmWicyQJYlqXCHEFOSarRTLpgnM=tkNzmWicyQJYlqXCHEFOSarRTLpgDe([node for _,node in ET.iterparse(io.StringIO(tkNzmWicyQJYlqXCHEFOSarRTLpgnG),events=['start-ns'])])
  for tkNzmWicyQJYlqXCHEFOSarRTLpgvV,tkNzmWicyQJYlqXCHEFOSarRTLpgVe in tkNzmWicyQJYlqXCHEFOSarRTLpgnM.items():
   ET.register_namespace(tkNzmWicyQJYlqXCHEFOSarRTLpgvV,tkNzmWicyQJYlqXCHEFOSarRTLpgVe)
  tkNzmWicyQJYlqXCHEFOSarRTLpgnw=tkNzmWicyQJYlqXCHEFOSarRTLpgnP.find(tkNzmWicyQJYlqXCHEFOSarRTLpgnK+'Period')
  for tkNzmWicyQJYlqXCHEFOSarRTLpgnx in tkNzmWicyQJYlqXCHEFOSarRTLpgnw.findall(tkNzmWicyQJYlqXCHEFOSarRTLpgnK+'AdaptationSet'):
   if tkNzmWicyQJYlqXCHEFOSarRTLpgnx.attrib.get('mimeType')=='video/mp4':
    tkNzmWicyQJYlqXCHEFOSarRTLpgnI=0
    for tkNzmWicyQJYlqXCHEFOSarRTLpgnU in tkNzmWicyQJYlqXCHEFOSarRTLpgnx.findall(tkNzmWicyQJYlqXCHEFOSarRTLpgnK+'Representation'):
     tkNzmWicyQJYlqXCHEFOSarRTLpgVB=tkNzmWicyQJYlqXCHEFOSarRTLpgDs(tkNzmWicyQJYlqXCHEFOSarRTLpgnU.attrib.get('bandwidth'))
     if tkNzmWicyQJYlqXCHEFOSarRTLpgnI<tkNzmWicyQJYlqXCHEFOSarRTLpgVB:tkNzmWicyQJYlqXCHEFOSarRTLpgnI=tkNzmWicyQJYlqXCHEFOSarRTLpgVB
    for tkNzmWicyQJYlqXCHEFOSarRTLpgnU in tkNzmWicyQJYlqXCHEFOSarRTLpgnx.findall(tkNzmWicyQJYlqXCHEFOSarRTLpgnK+'Representation'):
     if tkNzmWicyQJYlqXCHEFOSarRTLpgnI>tkNzmWicyQJYlqXCHEFOSarRTLpgDs(tkNzmWicyQJYlqXCHEFOSarRTLpgnU.attrib.get('bandwidth')):
      tkNzmWicyQJYlqXCHEFOSarRTLpgnx.remove(tkNzmWicyQJYlqXCHEFOSarRTLpgnU)
   elif tkNzmWicyQJYlqXCHEFOSarRTLpgnx.attrib.get('mimeType')=='audio/mp4':
    tkNzmWicyQJYlqXCHEFOSarRTLpgnI=0
    for tkNzmWicyQJYlqXCHEFOSarRTLpgnU in tkNzmWicyQJYlqXCHEFOSarRTLpgnx.findall(tkNzmWicyQJYlqXCHEFOSarRTLpgnK+'Representation'):
     tkNzmWicyQJYlqXCHEFOSarRTLpgVB=tkNzmWicyQJYlqXCHEFOSarRTLpgDs(tkNzmWicyQJYlqXCHEFOSarRTLpgnU.attrib.get('bandwidth'))
     if tkNzmWicyQJYlqXCHEFOSarRTLpgnI<tkNzmWicyQJYlqXCHEFOSarRTLpgVB:tkNzmWicyQJYlqXCHEFOSarRTLpgnI=tkNzmWicyQJYlqXCHEFOSarRTLpgVB
    for tkNzmWicyQJYlqXCHEFOSarRTLpgnU in tkNzmWicyQJYlqXCHEFOSarRTLpgnx.findall(tkNzmWicyQJYlqXCHEFOSarRTLpgnK+'Representation'):
     if tkNzmWicyQJYlqXCHEFOSarRTLpgnI>tkNzmWicyQJYlqXCHEFOSarRTLpgDs(tkNzmWicyQJYlqXCHEFOSarRTLpgnU.attrib.get('bandwidth')):
      tkNzmWicyQJYlqXCHEFOSarRTLpgnx.remove(tkNzmWicyQJYlqXCHEFOSarRTLpgnU)
   else:
    continue
  tkNzmWicyQJYlqXCHEFOSarRTLpgVv=ET.tostring(tkNzmWicyQJYlqXCHEFOSarRTLpgnP).decode('utf-8')
  tkNzmWicyQJYlqXCHEFOSarRTLpgVd='<?xml version="1.0" encoding="UTF-8"?>\n'
  tkNzmWicyQJYlqXCHEFOSarRTLpgBA.TextFile_Save(tkNzmWicyQJYlqXCHEFOSarRTLpgBA.WV_STREAM_FILENAME,tkNzmWicyQJYlqXCHEFOSarRTLpgVd+tkNzmWicyQJYlqXCHEFOSarRTLpgVv)
  return tkNzmWicyQJYlqXCHEFOSarRTLpgDB
 def MediaLine_Parse(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,tkNzmWicyQJYlqXCHEFOSarRTLpgnu,prefix):
  tkNzmWicyQJYlqXCHEFOSarRTLpgnh={}
  for tkNzmWicyQJYlqXCHEFOSarRTLpgVA in tkNzmWicyQJYlqXCHEFOSarRTLpgBd.split(tkNzmWicyQJYlqXCHEFOSarRTLpgnu.replace(prefix+':',''))[1::2]:
   tkNzmWicyQJYlqXCHEFOSarRTLpgVn,tkNzmWicyQJYlqXCHEFOSarRTLpgVe=tkNzmWicyQJYlqXCHEFOSarRTLpgVA.split('=',1)
   tkNzmWicyQJYlqXCHEFOSarRTLpgnh[tkNzmWicyQJYlqXCHEFOSarRTLpgVn.upper()]=tkNzmWicyQJYlqXCHEFOSarRTLpgVe.replace('"','').strip()
  return tkNzmWicyQJYlqXCHEFOSarRTLpgnh
 def GetStreamingURL(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,mode,tkNzmWicyQJYlqXCHEFOSarRTLpgdU,quality_int,pvrmode='-',playOption={}):
  tkNzmWicyQJYlqXCHEFOSarRTLpgVD ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  tkNzmWicyQJYlqXCHEFOSarRTLpgVs=[]
  if mode=='LIVE':
   tkNzmWicyQJYlqXCHEFOSarRTLpgvh =tkNzmWicyQJYlqXCHEFOSarRTLpgBA.API_DOMAIN+'/live/channels/'+tkNzmWicyQJYlqXCHEFOSarRTLpgdU
   tkNzmWicyQJYlqXCHEFOSarRTLpgVu='live'
  elif mode=='VOD':
   tkNzmWicyQJYlqXCHEFOSarRTLpgvh =tkNzmWicyQJYlqXCHEFOSarRTLpgBA.API_DOMAIN+'/fz/vod/contents-detail/'+tkNzmWicyQJYlqXCHEFOSarRTLpgdU 
   tkNzmWicyQJYlqXCHEFOSarRTLpgVu='vod'
  elif mode=='MOVIE':
   tkNzmWicyQJYlqXCHEFOSarRTLpgvh =tkNzmWicyQJYlqXCHEFOSarRTLpgBA.API_DOMAIN+'/fz/movie/contents/'+tkNzmWicyQJYlqXCHEFOSarRTLpgdU
   tkNzmWicyQJYlqXCHEFOSarRTLpgVu='movie'
  tkNzmWicyQJYlqXCHEFOSarRTLpgVh={'hdr':'sdr','uhd':'-',}
  try:
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.GetDefaultParams(login=tkNzmWicyQJYlqXCHEFOSarRTLpgeI)
   tkNzmWicyQJYlqXCHEFOSarRTLpgvf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.callRequestCookies('Get',tkNzmWicyQJYlqXCHEFOSarRTLpgvh,payload=tkNzmWicyQJYlqXCHEFOSarRTLpgex,params=tkNzmWicyQJYlqXCHEFOSarRTLpgBf,headers=tkNzmWicyQJYlqXCHEFOSarRTLpgex,cookies=tkNzmWicyQJYlqXCHEFOSarRTLpgex)
   tkNzmWicyQJYlqXCHEFOSarRTLpgvo=json.loads(tkNzmWicyQJYlqXCHEFOSarRTLpgvf.text)
   tkNzmWicyQJYlqXCHEFOSarRTLpgVb=tkNzmWicyQJYlqXCHEFOSarRTLpgvo['qualities']['list']
   if tkNzmWicyQJYlqXCHEFOSarRTLpgVb==tkNzmWicyQJYlqXCHEFOSarRTLpgex:return tkNzmWicyQJYlqXCHEFOSarRTLpgVD
   for tkNzmWicyQJYlqXCHEFOSarRTLpgVf in tkNzmWicyQJYlqXCHEFOSarRTLpgVb:
    tkNzmWicyQJYlqXCHEFOSarRTLpgVs.append(tkNzmWicyQJYlqXCHEFOSarRTLpgDs(tkNzmWicyQJYlqXCHEFOSarRTLpgVf.get('id').rstrip('p')))
   if 'type' in tkNzmWicyQJYlqXCHEFOSarRTLpgvo:
    if tkNzmWicyQJYlqXCHEFOSarRTLpgvo['type']=='onair':
     tkNzmWicyQJYlqXCHEFOSarRTLpgVu='onairvod'
   if 'drms' in tkNzmWicyQJYlqXCHEFOSarRTLpgvo:
    if tkNzmWicyQJYlqXCHEFOSarRTLpgvo['drms']:
     tkNzmWicyQJYlqXCHEFOSarRTLpgVD['stream_action']='dash' 
   if playOption.get('enable_hdr'):
    if 'mediatypes' in tkNzmWicyQJYlqXCHEFOSarRTLpgvo.get('qualities'):
     for tkNzmWicyQJYlqXCHEFOSarRTLpgVo in tkNzmWicyQJYlqXCHEFOSarRTLpgvo.get('qualities').get('mediatypes'):
      if tkNzmWicyQJYlqXCHEFOSarRTLpgVo=='HDR10':
       tkNzmWicyQJYlqXCHEFOSarRTLpgVh['hdr']='hdr'
       tkNzmWicyQJYlqXCHEFOSarRTLpgVD['stream_action']='dash'
       break
   if playOption.get('enable_uhd'):
    for tkNzmWicyQJYlqXCHEFOSarRTLpgVo in tkNzmWicyQJYlqXCHEFOSarRTLpgvo.get('qualities').get('list'):
     if tkNzmWicyQJYlqXCHEFOSarRTLpgVo.get('name')=='UHD':
      tkNzmWicyQJYlqXCHEFOSarRTLpgVh['uhd']='uhd'
      break
  except tkNzmWicyQJYlqXCHEFOSarRTLpgDn as exception:
   tkNzmWicyQJYlqXCHEFOSarRTLpgDV(exception)
   return tkNzmWicyQJYlqXCHEFOSarRTLpgVD
  tkNzmWicyQJYlqXCHEFOSarRTLpgDV('stream_action : '+tkNzmWicyQJYlqXCHEFOSarRTLpgVD['stream_action'])
  try:
   tkNzmWicyQJYlqXCHEFOSarRTLpgVG=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.CheckQuality(quality_int,tkNzmWicyQJYlqXCHEFOSarRTLpgVs)
   tkNzmWicyQJYlqXCHEFOSarRTLpgDV(tkNzmWicyQJYlqXCHEFOSarRTLpgVG)
   if tkNzmWicyQJYlqXCHEFOSarRTLpgVG<1080:
    tkNzmWicyQJYlqXCHEFOSarRTLpgVh['uhd']='-'
    tkNzmWicyQJYlqXCHEFOSarRTLpgVh['hdr']='sdr'
   if tkNzmWicyQJYlqXCHEFOSarRTLpgVh['uhd']=='uhd':tkNzmWicyQJYlqXCHEFOSarRTLpgVG=2160 
   tkNzmWicyQJYlqXCHEFOSarRTLpgVj=tkNzmWicyQJYlqXCHEFOSarRTLpgDd(tkNzmWicyQJYlqXCHEFOSarRTLpgVG)+'p'
   tkNzmWicyQJYlqXCHEFOSarRTLpgDV(tkNzmWicyQJYlqXCHEFOSarRTLpgVj)
   tkNzmWicyQJYlqXCHEFOSarRTLpgvh=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.API_DOMAIN+'/fz/streaming'
   if tkNzmWicyQJYlqXCHEFOSarRTLpgVh['hdr']=='hdr' or tkNzmWicyQJYlqXCHEFOSarRTLpgVh['uhd']=='uhd':
    tkNzmWicyQJYlqXCHEFOSarRTLpgBf={'contentid':tkNzmWicyQJYlqXCHEFOSarRTLpgdU,'contenttype':tkNzmWicyQJYlqXCHEFOSarRTLpgVu,'quality':tkNzmWicyQJYlqXCHEFOSarRTLpgVj,'modelid':'SHIELD Android TV','guid':tkNzmWicyQJYlqXCHEFOSarRTLpgBA.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n','protocol':tkNzmWicyQJYlqXCHEFOSarRTLpgVD['stream_action'],'hdr':'HDR10','videocodec':'HEVC','audiocodec':'AAC','issurround':'y','format':'normal','withinsubtitle':'n',}
    tkNzmWicyQJYlqXCHEFOSarRTLpgBf.update(tkNzmWicyQJYlqXCHEFOSarRTLpgBA.GetDefaultParams_AND())
   else:
    tkNzmWicyQJYlqXCHEFOSarRTLpgBf={'contentid':tkNzmWicyQJYlqXCHEFOSarRTLpgdU,'contenttype':tkNzmWicyQJYlqXCHEFOSarRTLpgVu,'quality':tkNzmWicyQJYlqXCHEFOSarRTLpgVj,'deviceModelId':'Windows 10','guid':tkNzmWicyQJYlqXCHEFOSarRTLpgBA.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n','action':tkNzmWicyQJYlqXCHEFOSarRTLpgVD['stream_action'],'protocol':tkNzmWicyQJYlqXCHEFOSarRTLpgVD['stream_action'],'hdr':'sdr','videocodec':'avc','audiocodec':'aac','issurround':'n','format':'normal','withinsubtitle':'n',}
    tkNzmWicyQJYlqXCHEFOSarRTLpgBf.update(tkNzmWicyQJYlqXCHEFOSarRTLpgBA.GetDefaultParams(login=tkNzmWicyQJYlqXCHEFOSarRTLpgDB))
   tkNzmWicyQJYlqXCHEFOSarRTLpgvf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.callRequestCookies('Get',tkNzmWicyQJYlqXCHEFOSarRTLpgvh,payload=tkNzmWicyQJYlqXCHEFOSarRTLpgex,params=tkNzmWicyQJYlqXCHEFOSarRTLpgBf,headers=tkNzmWicyQJYlqXCHEFOSarRTLpgex,cookies=tkNzmWicyQJYlqXCHEFOSarRTLpgex)
   tkNzmWicyQJYlqXCHEFOSarRTLpgvo=json.loads(tkNzmWicyQJYlqXCHEFOSarRTLpgvf.text)
   tkNzmWicyQJYlqXCHEFOSarRTLpgVD['stream_url']=tkNzmWicyQJYlqXCHEFOSarRTLpgvo['playurl']
   if tkNzmWicyQJYlqXCHEFOSarRTLpgVD['stream_url']==tkNzmWicyQJYlqXCHEFOSarRTLpgex:return tkNzmWicyQJYlqXCHEFOSarRTLpgVD
   tkNzmWicyQJYlqXCHEFOSarRTLpgVD['stream_cookie']=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.make_str_ToCookie(tkNzmWicyQJYlqXCHEFOSarRTLpgvo['awscookie'])
   tkNzmWicyQJYlqXCHEFOSarRTLpgVD['stream_drm'] =tkNzmWicyQJYlqXCHEFOSarRTLpgvo['drm']
   if 'previewmsg' in tkNzmWicyQJYlqXCHEFOSarRTLpgvo['preview']:tkNzmWicyQJYlqXCHEFOSarRTLpgVD['stream_preview']=tkNzmWicyQJYlqXCHEFOSarRTLpgvo['preview']['previewmsg']
   if 'subtitles' in tkNzmWicyQJYlqXCHEFOSarRTLpgvo:
    for tkNzmWicyQJYlqXCHEFOSarRTLpgVP in tkNzmWicyQJYlqXCHEFOSarRTLpgvo['subtitles']:
     if tkNzmWicyQJYlqXCHEFOSarRTLpgVP.get('languagecode')=='ko':
      tkNzmWicyQJYlqXCHEFOSarRTLpgVD['stream_vtt']=tkNzmWicyQJYlqXCHEFOSarRTLpgVP.get('url')
      break
    if tkNzmWicyQJYlqXCHEFOSarRTLpgVD['stream_vtt']=='':
     for tkNzmWicyQJYlqXCHEFOSarRTLpgVP in tkNzmWicyQJYlqXCHEFOSarRTLpgvo['subtitles']:
      if tkNzmWicyQJYlqXCHEFOSarRTLpgVP.get('languagecode')=='ko_cc':
       tkNzmWicyQJYlqXCHEFOSarRTLpgVD['stream_vtt']=tkNzmWicyQJYlqXCHEFOSarRTLpgVP.get('url')
       break
   tkNzmWicyQJYlqXCHEFOSarRTLpgVD['playParam']=tkNzmWicyQJYlqXCHEFOSarRTLpgVh 
  except tkNzmWicyQJYlqXCHEFOSarRTLpgDn as exception:
   tkNzmWicyQJYlqXCHEFOSarRTLpgDV(exception)
  return tkNzmWicyQJYlqXCHEFOSarRTLpgVD 
 def GetSportsURL(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,tkNzmWicyQJYlqXCHEFOSarRTLpgdU,quality_int):
  tkNzmWicyQJYlqXCHEFOSarRTLpgVD ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  tkNzmWicyQJYlqXCHEFOSarRTLpgVs=[]
  try:
   tkNzmWicyQJYlqXCHEFOSarRTLpgvh=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.API_DOMAIN+'/streaming/other'
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf={'contentid':tkNzmWicyQJYlqXCHEFOSarRTLpgdU,'contenttype':'live','action':tkNzmWicyQJYlqXCHEFOSarRTLpgVD['stream_action'],'quality':tkNzmWicyQJYlqXCHEFOSarRTLpgDd(quality_int)+'p','deviceModelId':'Windows 10','guid':tkNzmWicyQJYlqXCHEFOSarRTLpgBA.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n',}
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf.update(tkNzmWicyQJYlqXCHEFOSarRTLpgBA.GetDefaultParams(login=tkNzmWicyQJYlqXCHEFOSarRTLpgDB))
   tkNzmWicyQJYlqXCHEFOSarRTLpgvf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.callRequestCookies('Get',tkNzmWicyQJYlqXCHEFOSarRTLpgvh,payload=tkNzmWicyQJYlqXCHEFOSarRTLpgex,params=tkNzmWicyQJYlqXCHEFOSarRTLpgBf,headers=tkNzmWicyQJYlqXCHEFOSarRTLpgex,cookies=tkNzmWicyQJYlqXCHEFOSarRTLpgex)
   tkNzmWicyQJYlqXCHEFOSarRTLpgvo=json.loads(tkNzmWicyQJYlqXCHEFOSarRTLpgvf.text)
   tkNzmWicyQJYlqXCHEFOSarRTLpgVD['stream_url']=tkNzmWicyQJYlqXCHEFOSarRTLpgvo['playurl']
   if tkNzmWicyQJYlqXCHEFOSarRTLpgVD['stream_url']==tkNzmWicyQJYlqXCHEFOSarRTLpgex:return tkNzmWicyQJYlqXCHEFOSarRTLpgVD
   tkNzmWicyQJYlqXCHEFOSarRTLpgVD['stream_cookie']=tkNzmWicyQJYlqXCHEFOSarRTLpgvo['awscookie']
  except tkNzmWicyQJYlqXCHEFOSarRTLpgDn as exception:
   tkNzmWicyQJYlqXCHEFOSarRTLpgDV(exception)
  return tkNzmWicyQJYlqXCHEFOSarRTLpgVD
 def make_viewdate(tkNzmWicyQJYlqXCHEFOSarRTLpgBA):
  tkNzmWicyQJYlqXCHEFOSarRTLpgVK =tkNzmWicyQJYlqXCHEFOSarRTLpgBA.Get_Now_Datetime()
  tkNzmWicyQJYlqXCHEFOSarRTLpgVM =tkNzmWicyQJYlqXCHEFOSarRTLpgVK+datetime.timedelta(days=-1)
  tkNzmWicyQJYlqXCHEFOSarRTLpgVw =tkNzmWicyQJYlqXCHEFOSarRTLpgVK+datetime.timedelta(days=1)
  tkNzmWicyQJYlqXCHEFOSarRTLpgVx=[tkNzmWicyQJYlqXCHEFOSarRTLpgVK.strftime('%Y%m%d'),tkNzmWicyQJYlqXCHEFOSarRTLpgVw.strftime('%Y%m%d'),]
  return tkNzmWicyQJYlqXCHEFOSarRTLpgVx
 def Get_Sports_Gamelist(tkNzmWicyQJYlqXCHEFOSarRTLpgBA):
  tkNzmWicyQJYlqXCHEFOSarRTLpgVI =tkNzmWicyQJYlqXCHEFOSarRTLpgBA.make_viewdate()
  tkNzmWicyQJYlqXCHEFOSarRTLpgVU=[]
  tkNzmWicyQJYlqXCHEFOSarRTLpgeB =[]
  for tkNzmWicyQJYlqXCHEFOSarRTLpgev in tkNzmWicyQJYlqXCHEFOSarRTLpgVI:
   tkNzmWicyQJYlqXCHEFOSarRTLpged=tkNzmWicyQJYlqXCHEFOSarRTLpgev[:6]
   if tkNzmWicyQJYlqXCHEFOSarRTLpged not in tkNzmWicyQJYlqXCHEFOSarRTLpgVU:
    tkNzmWicyQJYlqXCHEFOSarRTLpgVU.append(tkNzmWicyQJYlqXCHEFOSarRTLpged)
  try:
   tkNzmWicyQJYlqXCHEFOSarRTLpgvh='https://annexapi.wavve.com/skb/baseball/teammonthlycalendarlist'
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf={'IF':'IF-PORG-002','m':'getTeamCalendarListBand','response_format':'json','spo_itm_cd':'KBO','teamcd':'all','tgroup':'B','tvalue':'BC123','ver':'2.0',}
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf.update(tkNzmWicyQJYlqXCHEFOSarRTLpgBA.GetDefaultParams(login=tkNzmWicyQJYlqXCHEFOSarRTLpgeI))
   for tkNzmWicyQJYlqXCHEFOSarRTLpgeA in tkNzmWicyQJYlqXCHEFOSarRTLpgVU:
    tkNzmWicyQJYlqXCHEFOSarRTLpgBf['date']=tkNzmWicyQJYlqXCHEFOSarRTLpgeA
    tkNzmWicyQJYlqXCHEFOSarRTLpgvf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.callRequestCookies('Get',tkNzmWicyQJYlqXCHEFOSarRTLpgvh,payload=tkNzmWicyQJYlqXCHEFOSarRTLpgex,params=tkNzmWicyQJYlqXCHEFOSarRTLpgBf,headers=tkNzmWicyQJYlqXCHEFOSarRTLpgex,cookies=tkNzmWicyQJYlqXCHEFOSarRTLpgex)
    tkNzmWicyQJYlqXCHEFOSarRTLpgvo=json.loads(tkNzmWicyQJYlqXCHEFOSarRTLpgvf.text)
    tkNzmWicyQJYlqXCHEFOSarRTLpgdB=tkNzmWicyQJYlqXCHEFOSarRTLpgvo['cell_toplist']['celllist']
    for tkNzmWicyQJYlqXCHEFOSarRTLpgdv in tkNzmWicyQJYlqXCHEFOSarRTLpgdB:
     tkNzmWicyQJYlqXCHEFOSarRTLpgen=tkNzmWicyQJYlqXCHEFOSarRTLpgdv.get('game_date')
     tkNzmWicyQJYlqXCHEFOSarRTLpgeV =tkNzmWicyQJYlqXCHEFOSarRTLpgdv.get('svc_id')
     if tkNzmWicyQJYlqXCHEFOSarRTLpgeV=='':continue
     if tkNzmWicyQJYlqXCHEFOSarRTLpgen in tkNzmWicyQJYlqXCHEFOSarRTLpgVI:
      tkNzmWicyQJYlqXCHEFOSarRTLpgeD=tkNzmWicyQJYlqXCHEFOSarRTLpgdv.get('game_status') 
      tkNzmWicyQJYlqXCHEFOSarRTLpges =tkNzmWicyQJYlqXCHEFOSarRTLpgdv.get('title_list')[0].get('text')
      tkNzmWicyQJYlqXCHEFOSarRTLpgen =tkNzmWicyQJYlqXCHEFOSarRTLpgen[:4]+'-'+tkNzmWicyQJYlqXCHEFOSarRTLpgen[4:6]+'-'+tkNzmWicyQJYlqXCHEFOSarRTLpgen[-2:]
      tkNzmWicyQJYlqXCHEFOSarRTLpgeu =tkNzmWicyQJYlqXCHEFOSarRTLpgdv.get('game_time')
      tkNzmWicyQJYlqXCHEFOSarRTLpgeu =tkNzmWicyQJYlqXCHEFOSarRTLpgeu[:2]+':'+tkNzmWicyQJYlqXCHEFOSarRTLpgeu[-2:]
      tkNzmWicyQJYlqXCHEFOSarRTLpgdA={'game_date':tkNzmWicyQJYlqXCHEFOSarRTLpgen,'game_time':tkNzmWicyQJYlqXCHEFOSarRTLpgeu,'svc_id':tkNzmWicyQJYlqXCHEFOSarRTLpgeV,'away_team':tkNzmWicyQJYlqXCHEFOSarRTLpgdv.get('away_team').get('team_name'),'home_team':tkNzmWicyQJYlqXCHEFOSarRTLpgdv.get('home_team').get('team_name'),'game_status':tkNzmWicyQJYlqXCHEFOSarRTLpgeD,'game_place':tkNzmWicyQJYlqXCHEFOSarRTLpgdv.get('game_place'),}
      tkNzmWicyQJYlqXCHEFOSarRTLpgeB.append(tkNzmWicyQJYlqXCHEFOSarRTLpgdA)
  except tkNzmWicyQJYlqXCHEFOSarRTLpgDn as exception:
   tkNzmWicyQJYlqXCHEFOSarRTLpgDV(exception)
   return[]
  tkNzmWicyQJYlqXCHEFOSarRTLpgeh=[]
  for i in tkNzmWicyQJYlqXCHEFOSarRTLpgDv(2):
   for tkNzmWicyQJYlqXCHEFOSarRTLpgdv in tkNzmWicyQJYlqXCHEFOSarRTLpgeB:
    if i==0 and tkNzmWicyQJYlqXCHEFOSarRTLpgdv.get('game_status')=='LIVE':
     tkNzmWicyQJYlqXCHEFOSarRTLpgeh.append(tkNzmWicyQJYlqXCHEFOSarRTLpgdv)
    elif i==1 and tkNzmWicyQJYlqXCHEFOSarRTLpgdv.get('game_status')!='LIVE':
     tkNzmWicyQJYlqXCHEFOSarRTLpgeh.append(tkNzmWicyQJYlqXCHEFOSarRTLpgdv)
  return tkNzmWicyQJYlqXCHEFOSarRTLpgeh
 def GetBookmarkInfo(tkNzmWicyQJYlqXCHEFOSarRTLpgBA,tkNzmWicyQJYlqXCHEFOSarRTLpgdj,tkNzmWicyQJYlqXCHEFOSarRTLpgdG,tkNzmWicyQJYlqXCHEFOSarRTLpgVu):
  if tkNzmWicyQJYlqXCHEFOSarRTLpgdG=='tvshow':
   if tkNzmWicyQJYlqXCHEFOSarRTLpgVu=='contentid':
    tkNzmWicyQJYlqXCHEFOSarRTLpgdU=tkNzmWicyQJYlqXCHEFOSarRTLpgdj
    tkNzmWicyQJYlqXCHEFOSarRTLpgdj =tkNzmWicyQJYlqXCHEFOSarRTLpgBA.ContentidToSeasonid(tkNzmWicyQJYlqXCHEFOSarRTLpgdU)
   else:
    tkNzmWicyQJYlqXCHEFOSarRTLpgdU=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.ProgramidToContentid(tkNzmWicyQJYlqXCHEFOSarRTLpgdj)
  else:
   tkNzmWicyQJYlqXCHEFOSarRTLpgdU=''
  tkNzmWicyQJYlqXCHEFOSarRTLpgeb={'indexinfo':{'ott':'wavve','videoid':tkNzmWicyQJYlqXCHEFOSarRTLpgdj,'vidtype':tkNzmWicyQJYlqXCHEFOSarRTLpgdG,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':tkNzmWicyQJYlqXCHEFOSarRTLpgdG,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if tkNzmWicyQJYlqXCHEFOSarRTLpgdG=='tvshow':
   tkNzmWicyQJYlqXCHEFOSarRTLpgvh=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.API_DOMAIN+'/fz/vod/contents/'+tkNzmWicyQJYlqXCHEFOSarRTLpgdU 
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.GetDefaultParams(login=tkNzmWicyQJYlqXCHEFOSarRTLpgeI)
   tkNzmWicyQJYlqXCHEFOSarRTLpgvf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.callRequestCookies('Get',tkNzmWicyQJYlqXCHEFOSarRTLpgvh,payload=tkNzmWicyQJYlqXCHEFOSarRTLpgex,params=tkNzmWicyQJYlqXCHEFOSarRTLpgBf,headers=tkNzmWicyQJYlqXCHEFOSarRTLpgex,cookies=tkNzmWicyQJYlqXCHEFOSarRTLpgex)
   tkNzmWicyQJYlqXCHEFOSarRTLpgvo=json.loads(tkNzmWicyQJYlqXCHEFOSarRTLpgvf.text)
   if not('programtitle' in tkNzmWicyQJYlqXCHEFOSarRTLpgvo):return{}
   tkNzmWicyQJYlqXCHEFOSarRTLpgef=tkNzmWicyQJYlqXCHEFOSarRTLpgvo
   tkNzmWicyQJYlqXCHEFOSarRTLpgeo=tkNzmWicyQJYlqXCHEFOSarRTLpgef.get('programtitle')
   tkNzmWicyQJYlqXCHEFOSarRTLpgeb['saveinfo']['infoLabels']['title']=tkNzmWicyQJYlqXCHEFOSarRTLpgeo
   if tkNzmWicyQJYlqXCHEFOSarRTLpgef.get('targetage')=='18' or tkNzmWicyQJYlqXCHEFOSarRTLpgef.get('targetage')=='19' or tkNzmWicyQJYlqXCHEFOSarRTLpgef.get('targetage')=='21':
    tkNzmWicyQJYlqXCHEFOSarRTLpgeo +=u' (%s)'%(tkNzmWicyQJYlqXCHEFOSarRTLpgef.get('targetage'))
   tkNzmWicyQJYlqXCHEFOSarRTLpgeb['saveinfo']['title'] =tkNzmWicyQJYlqXCHEFOSarRTLpgeo
   tkNzmWicyQJYlqXCHEFOSarRTLpgeb['saveinfo']['infoLabels']['mpaa'] =tkNzmWicyQJYlqXCHEFOSarRTLpgef.get('targetage')
   tkNzmWicyQJYlqXCHEFOSarRTLpgeb['saveinfo']['infoLabels']['plot'] =tkNzmWicyQJYlqXCHEFOSarRTLpgBA.Get_ChangeText(tkNzmWicyQJYlqXCHEFOSarRTLpgef.get('programsynopsis'))
   tkNzmWicyQJYlqXCHEFOSarRTLpgeb['saveinfo']['infoLabels']['studio'] =tkNzmWicyQJYlqXCHEFOSarRTLpgef.get('channelname')
   if tkNzmWicyQJYlqXCHEFOSarRTLpgef.get('firstreleaseyear')!='':tkNzmWicyQJYlqXCHEFOSarRTLpgeb['saveinfo']['infoLabels']['year'] =tkNzmWicyQJYlqXCHEFOSarRTLpgef.get('firstreleaseyear')
   if tkNzmWicyQJYlqXCHEFOSarRTLpgef.get('firstreleasedate')!='':tkNzmWicyQJYlqXCHEFOSarRTLpgeb['saveinfo']['infoLabels']['premiered']=tkNzmWicyQJYlqXCHEFOSarRTLpgef.get('firstreleasedate')
   if tkNzmWicyQJYlqXCHEFOSarRTLpgef.get('genretext') !='':tkNzmWicyQJYlqXCHEFOSarRTLpgeb['saveinfo']['infoLabels']['genre'] =[tkNzmWicyQJYlqXCHEFOSarRTLpgef.get('genretext')]
   tkNzmWicyQJYlqXCHEFOSarRTLpgeG=[]
   for tkNzmWicyQJYlqXCHEFOSarRTLpgej in tkNzmWicyQJYlqXCHEFOSarRTLpgef['actors']['list']:tkNzmWicyQJYlqXCHEFOSarRTLpgeG.append(tkNzmWicyQJYlqXCHEFOSarRTLpgej.get('text'))
   if tkNzmWicyQJYlqXCHEFOSarRTLpgDA(tkNzmWicyQJYlqXCHEFOSarRTLpgeG)>0:
    if tkNzmWicyQJYlqXCHEFOSarRTLpgeG[0]!='':tkNzmWicyQJYlqXCHEFOSarRTLpgeb['saveinfo']['infoLabels']['cast']=tkNzmWicyQJYlqXCHEFOSarRTLpgeG
   tkNzmWicyQJYlqXCHEFOSarRTLpgAG =''
   tkNzmWicyQJYlqXCHEFOSarRTLpgAj =''
   tkNzmWicyQJYlqXCHEFOSarRTLpgAP=''
   if tkNzmWicyQJYlqXCHEFOSarRTLpgef.get('programposterimage')!='':tkNzmWicyQJYlqXCHEFOSarRTLpgAG =tkNzmWicyQJYlqXCHEFOSarRTLpgBA.HTTPTAG+tkNzmWicyQJYlqXCHEFOSarRTLpgef.get('programposterimage')
   if tkNzmWicyQJYlqXCHEFOSarRTLpgef.get('programimage') !='':tkNzmWicyQJYlqXCHEFOSarRTLpgAj =tkNzmWicyQJYlqXCHEFOSarRTLpgBA.HTTPTAG+tkNzmWicyQJYlqXCHEFOSarRTLpgef.get('programimage')
   if tkNzmWicyQJYlqXCHEFOSarRTLpgef.get('programcircleimage')!='':tkNzmWicyQJYlqXCHEFOSarRTLpgAP=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.HTTPTAG+tkNzmWicyQJYlqXCHEFOSarRTLpgef.get('programcircleimage')
   if 'poster_default' in tkNzmWicyQJYlqXCHEFOSarRTLpgAG:
    tkNzmWicyQJYlqXCHEFOSarRTLpgAG =tkNzmWicyQJYlqXCHEFOSarRTLpgAj
    tkNzmWicyQJYlqXCHEFOSarRTLpgAP=''
   tkNzmWicyQJYlqXCHEFOSarRTLpgeb['saveinfo']['thumbnail']['poster']=tkNzmWicyQJYlqXCHEFOSarRTLpgAG
   tkNzmWicyQJYlqXCHEFOSarRTLpgeb['saveinfo']['thumbnail']['thumb']=tkNzmWicyQJYlqXCHEFOSarRTLpgAj
   tkNzmWicyQJYlqXCHEFOSarRTLpgeb['saveinfo']['thumbnail']['clearlogo']=tkNzmWicyQJYlqXCHEFOSarRTLpgAP
   tkNzmWicyQJYlqXCHEFOSarRTLpgeb['saveinfo']['thumbnail']['fanart']=tkNzmWicyQJYlqXCHEFOSarRTLpgAj
  else:
   tkNzmWicyQJYlqXCHEFOSarRTLpgvh=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.API_DOMAIN+'/movie/contents/'+tkNzmWicyQJYlqXCHEFOSarRTLpgdj 
   tkNzmWicyQJYlqXCHEFOSarRTLpgBf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.GetDefaultParams(login=tkNzmWicyQJYlqXCHEFOSarRTLpgeI)
   tkNzmWicyQJYlqXCHEFOSarRTLpgvf=tkNzmWicyQJYlqXCHEFOSarRTLpgBA.callRequestCookies('Get',tkNzmWicyQJYlqXCHEFOSarRTLpgvh,payload=tkNzmWicyQJYlqXCHEFOSarRTLpgex,params=tkNzmWicyQJYlqXCHEFOSarRTLpgBf,headers=tkNzmWicyQJYlqXCHEFOSarRTLpgex,cookies=tkNzmWicyQJYlqXCHEFOSarRTLpgex)
   tkNzmWicyQJYlqXCHEFOSarRTLpgvo=json.loads(tkNzmWicyQJYlqXCHEFOSarRTLpgvf.text)
   if not('title' in tkNzmWicyQJYlqXCHEFOSarRTLpgvo):return{}
   tkNzmWicyQJYlqXCHEFOSarRTLpgef=tkNzmWicyQJYlqXCHEFOSarRTLpgvo
   tkNzmWicyQJYlqXCHEFOSarRTLpgeo=tkNzmWicyQJYlqXCHEFOSarRTLpgef.get('title')
   tkNzmWicyQJYlqXCHEFOSarRTLpgeb['saveinfo']['infoLabels']['title']=tkNzmWicyQJYlqXCHEFOSarRTLpgeo
   if tkNzmWicyQJYlqXCHEFOSarRTLpgef.get('targetage')=='18' or tkNzmWicyQJYlqXCHEFOSarRTLpgef.get('targetage')=='19' or tkNzmWicyQJYlqXCHEFOSarRTLpgef.get('targetage')=='21':
    tkNzmWicyQJYlqXCHEFOSarRTLpgeo +=u' (%s)'%(tkNzmWicyQJYlqXCHEFOSarRTLpgef.get('targetage'))
   tkNzmWicyQJYlqXCHEFOSarRTLpgeb['saveinfo']['title'] =tkNzmWicyQJYlqXCHEFOSarRTLpgeo
   tkNzmWicyQJYlqXCHEFOSarRTLpgeb['saveinfo']['infoLabels']['mpaa'] =tkNzmWicyQJYlqXCHEFOSarRTLpgef.get('targetage')
   tkNzmWicyQJYlqXCHEFOSarRTLpgeb['saveinfo']['infoLabels']['plot'] =tkNzmWicyQJYlqXCHEFOSarRTLpgBA.Get_ChangeText(tkNzmWicyQJYlqXCHEFOSarRTLpgef.get('synopsis'))
   tkNzmWicyQJYlqXCHEFOSarRTLpgeb['saveinfo']['infoLabels']['duration']=tkNzmWicyQJYlqXCHEFOSarRTLpgef.get('playtime')
   tkNzmWicyQJYlqXCHEFOSarRTLpgeb['saveinfo']['infoLabels']['country']=tkNzmWicyQJYlqXCHEFOSarRTLpgef.get('country')
   tkNzmWicyQJYlqXCHEFOSarRTLpgeb['saveinfo']['infoLabels']['studio'] =tkNzmWicyQJYlqXCHEFOSarRTLpgef.get('cpname')
   if tkNzmWicyQJYlqXCHEFOSarRTLpgef.get('releasedate')!='':
    tkNzmWicyQJYlqXCHEFOSarRTLpgeb['saveinfo']['infoLabels']['year'] =tkNzmWicyQJYlqXCHEFOSarRTLpgef.get('releasedate')[:4]
    tkNzmWicyQJYlqXCHEFOSarRTLpgeb['saveinfo']['infoLabels']['premiered']=tkNzmWicyQJYlqXCHEFOSarRTLpgef.get('releasedate')
   tkNzmWicyQJYlqXCHEFOSarRTLpgeG=[]
   for tkNzmWicyQJYlqXCHEFOSarRTLpgej in tkNzmWicyQJYlqXCHEFOSarRTLpgef['actors']['list']:tkNzmWicyQJYlqXCHEFOSarRTLpgeG.append(tkNzmWicyQJYlqXCHEFOSarRTLpgej.get('text'))
   if tkNzmWicyQJYlqXCHEFOSarRTLpgDA(tkNzmWicyQJYlqXCHEFOSarRTLpgeG)>0:
    if tkNzmWicyQJYlqXCHEFOSarRTLpgeG[0]!='':tkNzmWicyQJYlqXCHEFOSarRTLpgeb['saveinfo']['infoLabels']['cast']=tkNzmWicyQJYlqXCHEFOSarRTLpgeG
   tkNzmWicyQJYlqXCHEFOSarRTLpgeP=[]
   for tkNzmWicyQJYlqXCHEFOSarRTLpgeK in tkNzmWicyQJYlqXCHEFOSarRTLpgef['directors']['list']:tkNzmWicyQJYlqXCHEFOSarRTLpgeP.append(tkNzmWicyQJYlqXCHEFOSarRTLpgeK.get('text'))
   if tkNzmWicyQJYlqXCHEFOSarRTLpgDA(tkNzmWicyQJYlqXCHEFOSarRTLpgeP)>0:
    if tkNzmWicyQJYlqXCHEFOSarRTLpgeP[0]!='':tkNzmWicyQJYlqXCHEFOSarRTLpgeb['saveinfo']['infoLabels']['director']=tkNzmWicyQJYlqXCHEFOSarRTLpgeP
   tkNzmWicyQJYlqXCHEFOSarRTLpgvx=[]
   for tkNzmWicyQJYlqXCHEFOSarRTLpgeM in tkNzmWicyQJYlqXCHEFOSarRTLpgef['genre']['list']:tkNzmWicyQJYlqXCHEFOSarRTLpgvx.append(tkNzmWicyQJYlqXCHEFOSarRTLpgeM.get('text'))
   if tkNzmWicyQJYlqXCHEFOSarRTLpgDA(tkNzmWicyQJYlqXCHEFOSarRTLpgvx)>0:
    if tkNzmWicyQJYlqXCHEFOSarRTLpgvx[0]!='':tkNzmWicyQJYlqXCHEFOSarRTLpgeb['saveinfo']['infoLabels']['genre']=tkNzmWicyQJYlqXCHEFOSarRTLpgvx
   tkNzmWicyQJYlqXCHEFOSarRTLpgAG ='https://%s'%tkNzmWicyQJYlqXCHEFOSarRTLpgef['image']
   tkNzmWicyQJYlqXCHEFOSarRTLpgeb['saveinfo']['thumbnail']['poster'] =tkNzmWicyQJYlqXCHEFOSarRTLpgAG
   tkNzmWicyQJYlqXCHEFOSarRTLpgeb['saveinfo']['thumbnail']['thumb'] =tkNzmWicyQJYlqXCHEFOSarRTLpgAG
  return tkNzmWicyQJYlqXCHEFOSarRTLpgeb
# Created by pyminifier (https://github.com/liftoff/pyminifier)
