__author__="NightRain"
SyVwtjPFGmaLolQcpzNTBJAMeWnDuq=object
SyVwtjPFGmaLolQcpzNTBJAMeWnDub=None
SyVwtjPFGmaLolQcpzNTBJAMeWnDuK=True
SyVwtjPFGmaLolQcpzNTBJAMeWnDus=False
SyVwtjPFGmaLolQcpzNTBJAMeWnDuI=int
SyVwtjPFGmaLolQcpzNTBJAMeWnDuO=type
SyVwtjPFGmaLolQcpzNTBJAMeWnDuE=dict
SyVwtjPFGmaLolQcpzNTBJAMeWnDuH=len
SyVwtjPFGmaLolQcpzNTBJAMeWnDuf=range
SyVwtjPFGmaLolQcpzNTBJAMeWnDuk=str
SyVwtjPFGmaLolQcpzNTBJAMeWnDuY=open
SyVwtjPFGmaLolQcpzNTBJAMeWnDuX=Exception
SyVwtjPFGmaLolQcpzNTBJAMeWnDCr=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
SyVwtjPFGmaLolQcpzNTBJAMeWnDrd=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://www.wavve.com/supermultisection/GN51','icon':'home.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&offset=0&limit=20&uicode=VN500','page':'1','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=01&WeekDay=all&uitype=VN4&uiparent=FN0&uirank=0&broadcastid=847243&uicode=VN4','page':'1','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=02&WeekDay=all&uitype=VN3&uiparent=FN0&uirank=0&broadcastid=783664&uicode=VN3','page':'1','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'1','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'paid','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'displaystart','ordernm':'업데이트순','icon':''},{'title':'프로야구 - 경기중 시청가능','mode':'GAME_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'(웨이브) 검색','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'(웨이브) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
SyVwtjPFGmaLolQcpzNTBJAMeWnDrR=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
SyVwtjPFGmaLolQcpzNTBJAMeWnDrh=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
SyVwtjPFGmaLolQcpzNTBJAMeWnDrg =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
SyVwtjPFGmaLolQcpzNTBJAMeWnDru=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_searched.txt'))
from wavveCore import*
class SyVwtjPFGmaLolQcpzNTBJAMeWnDrU(SyVwtjPFGmaLolQcpzNTBJAMeWnDuq):
 def __init__(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC,SyVwtjPFGmaLolQcpzNTBJAMeWnDrx,SyVwtjPFGmaLolQcpzNTBJAMeWnDrv,SyVwtjPFGmaLolQcpzNTBJAMeWnDri):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrC._addon_url =SyVwtjPFGmaLolQcpzNTBJAMeWnDrx
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrC._addon_handle=SyVwtjPFGmaLolQcpzNTBJAMeWnDrv
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.main_params =SyVwtjPFGmaLolQcpzNTBJAMeWnDri
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj =ezjMGVLWCImXFvarhUgRYsyAnKHiPu() 
 def addon_noti(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC,sting):
  try:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrb=xbmcgui.Dialog()
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrb.notification(__addonname__,sting)
  except:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDub
 def addon_log(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC,string):
  try:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrK=string.encode('utf-8','ignore')
  except:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrK='addonException: addon_log'
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrs=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,SyVwtjPFGmaLolQcpzNTBJAMeWnDrK),level=SyVwtjPFGmaLolQcpzNTBJAMeWnDrs)
 def get_keyboard_input(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC,SyVwtjPFGmaLolQcpzNTBJAMeWnDUx):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrI=SyVwtjPFGmaLolQcpzNTBJAMeWnDub
  kb=xbmc.Keyboard()
  kb.setHeading(SyVwtjPFGmaLolQcpzNTBJAMeWnDUx)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrI=kb.getText()
  return SyVwtjPFGmaLolQcpzNTBJAMeWnDrI
 def get_settings_login_info(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrO =__addon__.getSetting('id')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrE =__addon__.getSetting('pw')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrH=__addon__.getSetting('selected_profile')
  return(SyVwtjPFGmaLolQcpzNTBJAMeWnDrO,SyVwtjPFGmaLolQcpzNTBJAMeWnDrE,SyVwtjPFGmaLolQcpzNTBJAMeWnDrH)
 def get_settings_totalsearch(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrf =SyVwtjPFGmaLolQcpzNTBJAMeWnDuK if __addon__.getSetting('local_search')=='true' else SyVwtjPFGmaLolQcpzNTBJAMeWnDus
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrk=SyVwtjPFGmaLolQcpzNTBJAMeWnDuK if __addon__.getSetting('local_history')=='true' else SyVwtjPFGmaLolQcpzNTBJAMeWnDus
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrY =SyVwtjPFGmaLolQcpzNTBJAMeWnDuK if __addon__.getSetting('total_search')=='true' else SyVwtjPFGmaLolQcpzNTBJAMeWnDus
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrX=SyVwtjPFGmaLolQcpzNTBJAMeWnDuK if __addon__.getSetting('total_history')=='true' else SyVwtjPFGmaLolQcpzNTBJAMeWnDus
  SyVwtjPFGmaLolQcpzNTBJAMeWnDUr=SyVwtjPFGmaLolQcpzNTBJAMeWnDuK if __addon__.getSetting('menu_bookmark')=='true' else SyVwtjPFGmaLolQcpzNTBJAMeWnDus
  return(SyVwtjPFGmaLolQcpzNTBJAMeWnDrf,SyVwtjPFGmaLolQcpzNTBJAMeWnDrk,SyVwtjPFGmaLolQcpzNTBJAMeWnDrY,SyVwtjPFGmaLolQcpzNTBJAMeWnDrX,SyVwtjPFGmaLolQcpzNTBJAMeWnDUr)
 def get_settings_makebookmark(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC):
  return SyVwtjPFGmaLolQcpzNTBJAMeWnDuK if __addon__.getSetting('make_bookmark')=='true' else SyVwtjPFGmaLolQcpzNTBJAMeWnDus
 def get_selQuality(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC):
  try:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUd=[1080,720,480,360]
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUR=SyVwtjPFGmaLolQcpzNTBJAMeWnDuI(__addon__.getSetting('selected_quality'))
   return SyVwtjPFGmaLolQcpzNTBJAMeWnDUd[SyVwtjPFGmaLolQcpzNTBJAMeWnDUR]
  except:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDub
  return 1080 
 def get_settings_exclusion21(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDUh =__addon__.getSetting('exclusion21')
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDUh=='false':
   return SyVwtjPFGmaLolQcpzNTBJAMeWnDus
  else:
   return SyVwtjPFGmaLolQcpzNTBJAMeWnDuK
 def get_settings_direct_replay(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDUg=SyVwtjPFGmaLolQcpzNTBJAMeWnDuI(__addon__.getSetting('direct_replay'))
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDUg==0:
   return SyVwtjPFGmaLolQcpzNTBJAMeWnDus
  else:
   return SyVwtjPFGmaLolQcpzNTBJAMeWnDuK
 def set_winCredential(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC,credential):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDUu=xbmcgui.Window(10000)
  SyVwtjPFGmaLolQcpzNTBJAMeWnDUu.setProperty('WAVVE_M_CREDENTIAL',credential)
  SyVwtjPFGmaLolQcpzNTBJAMeWnDUu.setProperty('WAVVE_M_LOGINTIME',SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDUu=xbmcgui.Window(10000)
  return SyVwtjPFGmaLolQcpzNTBJAMeWnDUu.getProperty('WAVVE_M_CREDENTIAL')
 def set_winEpisodeOrderby(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC,SyVwtjPFGmaLolQcpzNTBJAMeWnDhU):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDUu=xbmcgui.Window(10000)
  SyVwtjPFGmaLolQcpzNTBJAMeWnDUu.setProperty('WAVVE_M_ORDERBY',SyVwtjPFGmaLolQcpzNTBJAMeWnDhU)
 def get_winEpisodeOrderby(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDUu=xbmcgui.Window(10000)
  return SyVwtjPFGmaLolQcpzNTBJAMeWnDUu.getProperty('WAVVE_M_ORDERBY')
 def add_dir(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC,label,sublabel='',img='',infoLabels=SyVwtjPFGmaLolQcpzNTBJAMeWnDub,isFolder=SyVwtjPFGmaLolQcpzNTBJAMeWnDuK,params='',isLink=SyVwtjPFGmaLolQcpzNTBJAMeWnDus,ContextMenu=SyVwtjPFGmaLolQcpzNTBJAMeWnDub):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDUC='%s?%s'%(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC._addon_url,urllib.parse.urlencode(params))
  if sublabel:SyVwtjPFGmaLolQcpzNTBJAMeWnDUx='%s < %s >'%(label,sublabel)
  else: SyVwtjPFGmaLolQcpzNTBJAMeWnDUx=label
  if not img:img='DefaultFolder.png'
  SyVwtjPFGmaLolQcpzNTBJAMeWnDUv=xbmcgui.ListItem(SyVwtjPFGmaLolQcpzNTBJAMeWnDUx)
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDuO(img)==SyVwtjPFGmaLolQcpzNTBJAMeWnDuE:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUv.setArt(img)
  else:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUv.setArt({'thumb':img,'poster':img})
  if infoLabels:SyVwtjPFGmaLolQcpzNTBJAMeWnDUv.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUv.setProperty('IsPlayable','true')
  if ContextMenu:SyVwtjPFGmaLolQcpzNTBJAMeWnDUv.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC._addon_handle,SyVwtjPFGmaLolQcpzNTBJAMeWnDUC,SyVwtjPFGmaLolQcpzNTBJAMeWnDUv,isFolder)
 def dp_Main_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC):
  (SyVwtjPFGmaLolQcpzNTBJAMeWnDrf,SyVwtjPFGmaLolQcpzNTBJAMeWnDrk,SyVwtjPFGmaLolQcpzNTBJAMeWnDrY,SyVwtjPFGmaLolQcpzNTBJAMeWnDrX,SyVwtjPFGmaLolQcpzNTBJAMeWnDUr)=SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.get_settings_totalsearch()
  for SyVwtjPFGmaLolQcpzNTBJAMeWnDUi in SyVwtjPFGmaLolQcpzNTBJAMeWnDrd:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUx=SyVwtjPFGmaLolQcpzNTBJAMeWnDUi.get('title')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUq=''
   if SyVwtjPFGmaLolQcpzNTBJAMeWnDUi.get('mode')=='SEARCH_GROUP' and SyVwtjPFGmaLolQcpzNTBJAMeWnDrf ==SyVwtjPFGmaLolQcpzNTBJAMeWnDus:continue
   elif SyVwtjPFGmaLolQcpzNTBJAMeWnDUi.get('mode')=='SEARCH_HISTORY' and SyVwtjPFGmaLolQcpzNTBJAMeWnDrk==SyVwtjPFGmaLolQcpzNTBJAMeWnDus:continue
   elif SyVwtjPFGmaLolQcpzNTBJAMeWnDUi.get('mode')=='TOTAL_SEARCH' and SyVwtjPFGmaLolQcpzNTBJAMeWnDrY ==SyVwtjPFGmaLolQcpzNTBJAMeWnDus:continue
   elif SyVwtjPFGmaLolQcpzNTBJAMeWnDUi.get('mode')=='TOTAL_HISTORY' and SyVwtjPFGmaLolQcpzNTBJAMeWnDrX==SyVwtjPFGmaLolQcpzNTBJAMeWnDus:continue
   elif SyVwtjPFGmaLolQcpzNTBJAMeWnDUi.get('mode')=='MENU_BOOKMARK' and SyVwtjPFGmaLolQcpzNTBJAMeWnDUr==SyVwtjPFGmaLolQcpzNTBJAMeWnDus:continue
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb={'mode':SyVwtjPFGmaLolQcpzNTBJAMeWnDUi.get('mode'),'sCode':SyVwtjPFGmaLolQcpzNTBJAMeWnDUi.get('sCode'),'sIndex':SyVwtjPFGmaLolQcpzNTBJAMeWnDUi.get('sIndex'),'sType':SyVwtjPFGmaLolQcpzNTBJAMeWnDUi.get('sType'),'suburl':SyVwtjPFGmaLolQcpzNTBJAMeWnDUi.get('suburl'),'subapi':SyVwtjPFGmaLolQcpzNTBJAMeWnDUi.get('subapi'),'page':SyVwtjPFGmaLolQcpzNTBJAMeWnDUi.get('page'),'orderby':SyVwtjPFGmaLolQcpzNTBJAMeWnDUi.get('orderby'),'ordernm':SyVwtjPFGmaLolQcpzNTBJAMeWnDUi.get('ordernm')}
   if SyVwtjPFGmaLolQcpzNTBJAMeWnDUi.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    SyVwtjPFGmaLolQcpzNTBJAMeWnDUK=SyVwtjPFGmaLolQcpzNTBJAMeWnDus
    SyVwtjPFGmaLolQcpzNTBJAMeWnDUs =SyVwtjPFGmaLolQcpzNTBJAMeWnDuK
   else:
    SyVwtjPFGmaLolQcpzNTBJAMeWnDUK=SyVwtjPFGmaLolQcpzNTBJAMeWnDuK
    SyVwtjPFGmaLolQcpzNTBJAMeWnDUs =SyVwtjPFGmaLolQcpzNTBJAMeWnDus
   if 'icon' in SyVwtjPFGmaLolQcpzNTBJAMeWnDUi:SyVwtjPFGmaLolQcpzNTBJAMeWnDUq=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',SyVwtjPFGmaLolQcpzNTBJAMeWnDUi.get('icon')) 
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.add_dir(SyVwtjPFGmaLolQcpzNTBJAMeWnDUx,sublabel='',img=SyVwtjPFGmaLolQcpzNTBJAMeWnDUq,infoLabels=SyVwtjPFGmaLolQcpzNTBJAMeWnDub,isFolder=SyVwtjPFGmaLolQcpzNTBJAMeWnDUK,params=SyVwtjPFGmaLolQcpzNTBJAMeWnDUb,isLink=SyVwtjPFGmaLolQcpzNTBJAMeWnDUs)
  xbmcplugin.endOfDirectory(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC._addon_handle,cacheToDisc=SyVwtjPFGmaLolQcpzNTBJAMeWnDuK)
 def dp_Search_Group(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC,args):
  if 'search_key' in args:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUE=args.get('search_key')
  else:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUE=SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not SyVwtjPFGmaLolQcpzNTBJAMeWnDUE:
    return
  for SyVwtjPFGmaLolQcpzNTBJAMeWnDUH in SyVwtjPFGmaLolQcpzNTBJAMeWnDrR:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUf =SyVwtjPFGmaLolQcpzNTBJAMeWnDUH.get('mode')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUk=SyVwtjPFGmaLolQcpzNTBJAMeWnDUH.get('sType')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUx=SyVwtjPFGmaLolQcpzNTBJAMeWnDUH.get('title')
   (SyVwtjPFGmaLolQcpzNTBJAMeWnDUY,SyVwtjPFGmaLolQcpzNTBJAMeWnDUX)=SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.Get_Search_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDUE,SyVwtjPFGmaLolQcpzNTBJAMeWnDUk,1,exclusion21=SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.get_settings_exclusion21())
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdr={'plot':'검색어 : '+SyVwtjPFGmaLolQcpzNTBJAMeWnDUE+'\n\n'+SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.Search_FreeList(SyVwtjPFGmaLolQcpzNTBJAMeWnDUY)}
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb={'mode':SyVwtjPFGmaLolQcpzNTBJAMeWnDUf,'sType':SyVwtjPFGmaLolQcpzNTBJAMeWnDUk,'search_key':SyVwtjPFGmaLolQcpzNTBJAMeWnDUE,'page':'1',}
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.add_dir(SyVwtjPFGmaLolQcpzNTBJAMeWnDUx,sublabel='',img='',infoLabels=SyVwtjPFGmaLolQcpzNTBJAMeWnDdr,isFolder=SyVwtjPFGmaLolQcpzNTBJAMeWnDuK,params=SyVwtjPFGmaLolQcpzNTBJAMeWnDUb)
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDuH(SyVwtjPFGmaLolQcpzNTBJAMeWnDrR)>0:xbmcplugin.endOfDirectory(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC._addon_handle,cacheToDisc=SyVwtjPFGmaLolQcpzNTBJAMeWnDuK)
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.Save_Searched_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDUE)
 def Search_FreeList(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC,search_list):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDdU=''
  SyVwtjPFGmaLolQcpzNTBJAMeWnDdR=7
  try:
   if SyVwtjPFGmaLolQcpzNTBJAMeWnDuH(search_list)==0:return '검색결과 없음'
   for i in SyVwtjPFGmaLolQcpzNTBJAMeWnDuf(SyVwtjPFGmaLolQcpzNTBJAMeWnDuH(search_list)):
    if i>=SyVwtjPFGmaLolQcpzNTBJAMeWnDdR:
     SyVwtjPFGmaLolQcpzNTBJAMeWnDdU=SyVwtjPFGmaLolQcpzNTBJAMeWnDdU+'...'
     break
    SyVwtjPFGmaLolQcpzNTBJAMeWnDdU=SyVwtjPFGmaLolQcpzNTBJAMeWnDdU+search_list[i]['title']+'\n'
  except:
   return ''
  return SyVwtjPFGmaLolQcpzNTBJAMeWnDdU
 def dp_Watch_Group(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC,args):
  for SyVwtjPFGmaLolQcpzNTBJAMeWnDdh in SyVwtjPFGmaLolQcpzNTBJAMeWnDrh:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUx=SyVwtjPFGmaLolQcpzNTBJAMeWnDdh.get('title')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb={'mode':SyVwtjPFGmaLolQcpzNTBJAMeWnDdh.get('mode'),'sType':SyVwtjPFGmaLolQcpzNTBJAMeWnDdh.get('sType')}
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.add_dir(SyVwtjPFGmaLolQcpzNTBJAMeWnDUx,sublabel='',img='',infoLabels=SyVwtjPFGmaLolQcpzNTBJAMeWnDub,isFolder=SyVwtjPFGmaLolQcpzNTBJAMeWnDuK,params=SyVwtjPFGmaLolQcpzNTBJAMeWnDUb)
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDuH(SyVwtjPFGmaLolQcpzNTBJAMeWnDrh)>0:xbmcplugin.endOfDirectory(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC._addon_handle,cacheToDisc=SyVwtjPFGmaLolQcpzNTBJAMeWnDuK)
 def dp_Search_History(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC,args):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDdg=SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.Load_List_File('search')
  for SyVwtjPFGmaLolQcpzNTBJAMeWnDdu in SyVwtjPFGmaLolQcpzNTBJAMeWnDdg:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdC=SyVwtjPFGmaLolQcpzNTBJAMeWnDuE(urllib.parse.parse_qsl(SyVwtjPFGmaLolQcpzNTBJAMeWnDdu))
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdx=SyVwtjPFGmaLolQcpzNTBJAMeWnDdC.get('skey').strip()
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb={'mode':'SEARCH_GROUP','search_key':SyVwtjPFGmaLolQcpzNTBJAMeWnDdx,}
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdv={'mode':'SEARCH_REMOVE','sType':'ONE','skey':SyVwtjPFGmaLolQcpzNTBJAMeWnDdx,}
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdi=urllib.parse.urlencode(SyVwtjPFGmaLolQcpzNTBJAMeWnDdv)
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdq=[('선택된 검색어 ( %s ) 삭제'%(SyVwtjPFGmaLolQcpzNTBJAMeWnDdx),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(SyVwtjPFGmaLolQcpzNTBJAMeWnDdi))]
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.add_dir(SyVwtjPFGmaLolQcpzNTBJAMeWnDdx,sublabel='',img=SyVwtjPFGmaLolQcpzNTBJAMeWnDub,infoLabels=SyVwtjPFGmaLolQcpzNTBJAMeWnDub,isFolder=SyVwtjPFGmaLolQcpzNTBJAMeWnDuK,params=SyVwtjPFGmaLolQcpzNTBJAMeWnDUb,ContextMenu=SyVwtjPFGmaLolQcpzNTBJAMeWnDdq)
  SyVwtjPFGmaLolQcpzNTBJAMeWnDdb={'plot':'검색목록 전체를 삭제합니다.'}
  SyVwtjPFGmaLolQcpzNTBJAMeWnDUx='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  SyVwtjPFGmaLolQcpzNTBJAMeWnDUb={'mode':'SEARCH_REMOVE','sType':'ALL','skey':'-',}
  SyVwtjPFGmaLolQcpzNTBJAMeWnDUq=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.add_dir(SyVwtjPFGmaLolQcpzNTBJAMeWnDUx,sublabel='',img=SyVwtjPFGmaLolQcpzNTBJAMeWnDUq,infoLabels=SyVwtjPFGmaLolQcpzNTBJAMeWnDdb,isFolder=SyVwtjPFGmaLolQcpzNTBJAMeWnDus,params=SyVwtjPFGmaLolQcpzNTBJAMeWnDUb,isLink=SyVwtjPFGmaLolQcpzNTBJAMeWnDuK)
  xbmcplugin.endOfDirectory(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC._addon_handle,cacheToDisc=SyVwtjPFGmaLolQcpzNTBJAMeWnDus)
 def dp_Search_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC,args):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.SaveCredential(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.get_winCredential())
  SyVwtjPFGmaLolQcpzNTBJAMeWnDUk =args.get('sType')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDdK =SyVwtjPFGmaLolQcpzNTBJAMeWnDuI(args.get('page'))
  if 'search_key' in args:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUE=args.get('search_key')
  else:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUE=SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not SyVwtjPFGmaLolQcpzNTBJAMeWnDUE:
    xbmcplugin.endOfDirectory(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC._addon_handle)
    return
  SyVwtjPFGmaLolQcpzNTBJAMeWnDds,SyVwtjPFGmaLolQcpzNTBJAMeWnDUX=SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.Get_Search_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDUE,SyVwtjPFGmaLolQcpzNTBJAMeWnDUk,SyVwtjPFGmaLolQcpzNTBJAMeWnDdK,exclusion21=SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.get_settings_exclusion21())
  for SyVwtjPFGmaLolQcpzNTBJAMeWnDdI in SyVwtjPFGmaLolQcpzNTBJAMeWnDds:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUx =SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('title')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdO=SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('thumbnail')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdE =SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('age')
   if SyVwtjPFGmaLolQcpzNTBJAMeWnDdE=='18' or SyVwtjPFGmaLolQcpzNTBJAMeWnDdE=='19' or SyVwtjPFGmaLolQcpzNTBJAMeWnDdE=='21':SyVwtjPFGmaLolQcpzNTBJAMeWnDUx+=' (%s)'%(SyVwtjPFGmaLolQcpzNTBJAMeWnDdE)
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdb={'mediatype':'tvshow' if SyVwtjPFGmaLolQcpzNTBJAMeWnDUk=='vod' else 'movie','mpaa':SyVwtjPFGmaLolQcpzNTBJAMeWnDdE,'title':SyVwtjPFGmaLolQcpzNTBJAMeWnDUx,'plot':SyVwtjPFGmaLolQcpzNTBJAMeWnDUx}
   if SyVwtjPFGmaLolQcpzNTBJAMeWnDUk=='vod':
    SyVwtjPFGmaLolQcpzNTBJAMeWnDUb={'mode':'EPISODE_LIST','videoid':SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('videoid'),'vidtype':SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('vidtype'),'page':'1'}
    SyVwtjPFGmaLolQcpzNTBJAMeWnDUK=SyVwtjPFGmaLolQcpzNTBJAMeWnDuK
   else:
    SyVwtjPFGmaLolQcpzNTBJAMeWnDUb={'mode':'MOVIE','contentid':SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('videoid'),'title':SyVwtjPFGmaLolQcpzNTBJAMeWnDUx,'thumbnail':SyVwtjPFGmaLolQcpzNTBJAMeWnDdO,'age':SyVwtjPFGmaLolQcpzNTBJAMeWnDdE}
    SyVwtjPFGmaLolQcpzNTBJAMeWnDUK=SyVwtjPFGmaLolQcpzNTBJAMeWnDus
   if SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.get_settings_makebookmark():
    SyVwtjPFGmaLolQcpzNTBJAMeWnDdH={'videoid':SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('videoid'),'vidtype':'tvshow' if SyVwtjPFGmaLolQcpzNTBJAMeWnDUk=='vod' else 'movie','vtitle':SyVwtjPFGmaLolQcpzNTBJAMeWnDUx,'vsubtitle':'','contenttype':SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('vidtype'),}
    SyVwtjPFGmaLolQcpzNTBJAMeWnDdf=json.dumps(SyVwtjPFGmaLolQcpzNTBJAMeWnDdH)
    SyVwtjPFGmaLolQcpzNTBJAMeWnDdf=urllib.parse.quote(SyVwtjPFGmaLolQcpzNTBJAMeWnDdf)
    SyVwtjPFGmaLolQcpzNTBJAMeWnDdk='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(SyVwtjPFGmaLolQcpzNTBJAMeWnDdf)
    SyVwtjPFGmaLolQcpzNTBJAMeWnDdq=[('(통합) 찜 영상에 추가',SyVwtjPFGmaLolQcpzNTBJAMeWnDdk)]
   else:
    SyVwtjPFGmaLolQcpzNTBJAMeWnDdq=SyVwtjPFGmaLolQcpzNTBJAMeWnDub
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.add_dir(SyVwtjPFGmaLolQcpzNTBJAMeWnDUx,sublabel='',img=SyVwtjPFGmaLolQcpzNTBJAMeWnDdO,infoLabels=SyVwtjPFGmaLolQcpzNTBJAMeWnDdb,isFolder=SyVwtjPFGmaLolQcpzNTBJAMeWnDUK,params=SyVwtjPFGmaLolQcpzNTBJAMeWnDUb,ContextMenu=SyVwtjPFGmaLolQcpzNTBJAMeWnDdq)
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDUX:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb['mode'] ='SEARCH_LIST' 
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb['sType']=SyVwtjPFGmaLolQcpzNTBJAMeWnDUk 
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb['page'] =SyVwtjPFGmaLolQcpzNTBJAMeWnDuk(SyVwtjPFGmaLolQcpzNTBJAMeWnDdK+1)
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb['search_key']=SyVwtjPFGmaLolQcpzNTBJAMeWnDUE
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUx='[B]%s >>[/B]'%'다음 페이지'
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdY=SyVwtjPFGmaLolQcpzNTBJAMeWnDuk(SyVwtjPFGmaLolQcpzNTBJAMeWnDdK+1)
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUq=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.add_dir(SyVwtjPFGmaLolQcpzNTBJAMeWnDUx,sublabel=SyVwtjPFGmaLolQcpzNTBJAMeWnDdY,img=SyVwtjPFGmaLolQcpzNTBJAMeWnDUq,infoLabels=SyVwtjPFGmaLolQcpzNTBJAMeWnDub,isFolder=SyVwtjPFGmaLolQcpzNTBJAMeWnDuK,params=SyVwtjPFGmaLolQcpzNTBJAMeWnDUb)
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDUk=='movie':xbmcplugin.setContent(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC._addon_handle,'movies')
  else:xbmcplugin.setContent(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC._addon_handle,cacheToDisc=SyVwtjPFGmaLolQcpzNTBJAMeWnDus)
 def dp_Watch_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC,args):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDUk =args.get('sType')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDUg=SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.get_settings_direct_replay()
  SyVwtjPFGmaLolQcpzNTBJAMeWnDds=SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.Load_List_File(SyVwtjPFGmaLolQcpzNTBJAMeWnDUk)
  for SyVwtjPFGmaLolQcpzNTBJAMeWnDdI in SyVwtjPFGmaLolQcpzNTBJAMeWnDds:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdC=SyVwtjPFGmaLolQcpzNTBJAMeWnDuE(urllib.parse.parse_qsl(SyVwtjPFGmaLolQcpzNTBJAMeWnDdI))
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdX =SyVwtjPFGmaLolQcpzNTBJAMeWnDdC.get('code').strip()
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUx =SyVwtjPFGmaLolQcpzNTBJAMeWnDdC.get('title').strip()
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdY =SyVwtjPFGmaLolQcpzNTBJAMeWnDdC.get('subtitle').strip()
   if SyVwtjPFGmaLolQcpzNTBJAMeWnDdY=='None':SyVwtjPFGmaLolQcpzNTBJAMeWnDdY=''
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdO=SyVwtjPFGmaLolQcpzNTBJAMeWnDdC.get('img').strip()
   SyVwtjPFGmaLolQcpzNTBJAMeWnDRr =SyVwtjPFGmaLolQcpzNTBJAMeWnDdC.get('videoid').strip()
   try:
    SyVwtjPFGmaLolQcpzNTBJAMeWnDdO=SyVwtjPFGmaLolQcpzNTBJAMeWnDdO.replace('\'','\"')
    SyVwtjPFGmaLolQcpzNTBJAMeWnDdO=json.loads(SyVwtjPFGmaLolQcpzNTBJAMeWnDdO)
   except:
    SyVwtjPFGmaLolQcpzNTBJAMeWnDub
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdb={'plot':'%s\n%s'%(SyVwtjPFGmaLolQcpzNTBJAMeWnDUx,SyVwtjPFGmaLolQcpzNTBJAMeWnDdY)}
   if SyVwtjPFGmaLolQcpzNTBJAMeWnDUk=='vod':
    if SyVwtjPFGmaLolQcpzNTBJAMeWnDUg==SyVwtjPFGmaLolQcpzNTBJAMeWnDus or SyVwtjPFGmaLolQcpzNTBJAMeWnDRr==SyVwtjPFGmaLolQcpzNTBJAMeWnDub:
     SyVwtjPFGmaLolQcpzNTBJAMeWnDUb={'mode':'EPISODE_LIST','videoid':SyVwtjPFGmaLolQcpzNTBJAMeWnDdX,'vidtype':'programid','page':'1'}
     SyVwtjPFGmaLolQcpzNTBJAMeWnDUK=SyVwtjPFGmaLolQcpzNTBJAMeWnDuK
    else:
     SyVwtjPFGmaLolQcpzNTBJAMeWnDUb={'mode':'VOD','programid':SyVwtjPFGmaLolQcpzNTBJAMeWnDdX,'contentid':SyVwtjPFGmaLolQcpzNTBJAMeWnDRr,'title':SyVwtjPFGmaLolQcpzNTBJAMeWnDUx,'subtitle':SyVwtjPFGmaLolQcpzNTBJAMeWnDdY,'thumbnail':SyVwtjPFGmaLolQcpzNTBJAMeWnDdO}
     SyVwtjPFGmaLolQcpzNTBJAMeWnDUK=SyVwtjPFGmaLolQcpzNTBJAMeWnDus
   else:
    SyVwtjPFGmaLolQcpzNTBJAMeWnDUb={'mode':'MOVIE','contentid':SyVwtjPFGmaLolQcpzNTBJAMeWnDdX,'title':SyVwtjPFGmaLolQcpzNTBJAMeWnDUx,'subtitle':SyVwtjPFGmaLolQcpzNTBJAMeWnDdY,'thumbnail':SyVwtjPFGmaLolQcpzNTBJAMeWnDdO}
    SyVwtjPFGmaLolQcpzNTBJAMeWnDUK=SyVwtjPFGmaLolQcpzNTBJAMeWnDus
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.add_dir(SyVwtjPFGmaLolQcpzNTBJAMeWnDUx,sublabel=SyVwtjPFGmaLolQcpzNTBJAMeWnDdY,img=SyVwtjPFGmaLolQcpzNTBJAMeWnDdO,infoLabels=SyVwtjPFGmaLolQcpzNTBJAMeWnDdb,isFolder=SyVwtjPFGmaLolQcpzNTBJAMeWnDUK,params=SyVwtjPFGmaLolQcpzNTBJAMeWnDUb)
  SyVwtjPFGmaLolQcpzNTBJAMeWnDdb={'plot':'시청목록을 삭제합니다.'}
  SyVwtjPFGmaLolQcpzNTBJAMeWnDUx='*** 시청목록 삭제 ***'
  SyVwtjPFGmaLolQcpzNTBJAMeWnDUb={'mode':'MYVIEW_REMOVE','sType':SyVwtjPFGmaLolQcpzNTBJAMeWnDUk,'skey':'-',}
  SyVwtjPFGmaLolQcpzNTBJAMeWnDUq=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.add_dir(SyVwtjPFGmaLolQcpzNTBJAMeWnDUx,sublabel='',img=SyVwtjPFGmaLolQcpzNTBJAMeWnDUq,infoLabels=SyVwtjPFGmaLolQcpzNTBJAMeWnDdb,isFolder=SyVwtjPFGmaLolQcpzNTBJAMeWnDus,params=SyVwtjPFGmaLolQcpzNTBJAMeWnDUb,isLink=SyVwtjPFGmaLolQcpzNTBJAMeWnDuK)
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDUk=='movie':xbmcplugin.setContent(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC._addon_handle,'movies')
  else:xbmcplugin.setContent(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC._addon_handle,cacheToDisc=SyVwtjPFGmaLolQcpzNTBJAMeWnDus)
 def Load_List_File(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC,SyVwtjPFGmaLolQcpzNTBJAMeWnDRK): 
  try:
   if SyVwtjPFGmaLolQcpzNTBJAMeWnDRK=='search':
    SyVwtjPFGmaLolQcpzNTBJAMeWnDRU=SyVwtjPFGmaLolQcpzNTBJAMeWnDru
   elif SyVwtjPFGmaLolQcpzNTBJAMeWnDRK in['vod','movie']:
    SyVwtjPFGmaLolQcpzNTBJAMeWnDRU=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%SyVwtjPFGmaLolQcpzNTBJAMeWnDRK))
   else:
    return[]
   fp=SyVwtjPFGmaLolQcpzNTBJAMeWnDuY(SyVwtjPFGmaLolQcpzNTBJAMeWnDRU,'r',-1,'utf-8')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDRd=fp.readlines()
   fp.close()
  except:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDRd=[]
  return SyVwtjPFGmaLolQcpzNTBJAMeWnDRd
 def Save_Watched_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC,SyVwtjPFGmaLolQcpzNTBJAMeWnDgX,SyVwtjPFGmaLolQcpzNTBJAMeWnDri):
  try:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDRh=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%SyVwtjPFGmaLolQcpzNTBJAMeWnDgX))
   SyVwtjPFGmaLolQcpzNTBJAMeWnDRg=SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.Load_List_File(SyVwtjPFGmaLolQcpzNTBJAMeWnDgX) 
   fp=SyVwtjPFGmaLolQcpzNTBJAMeWnDuY(SyVwtjPFGmaLolQcpzNTBJAMeWnDRh,'w',-1,'utf-8')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDRu=urllib.parse.urlencode(SyVwtjPFGmaLolQcpzNTBJAMeWnDri)
   SyVwtjPFGmaLolQcpzNTBJAMeWnDRu=SyVwtjPFGmaLolQcpzNTBJAMeWnDRu+'\n'
   fp.write(SyVwtjPFGmaLolQcpzNTBJAMeWnDRu)
   SyVwtjPFGmaLolQcpzNTBJAMeWnDRC=0
   for SyVwtjPFGmaLolQcpzNTBJAMeWnDRx in SyVwtjPFGmaLolQcpzNTBJAMeWnDRg:
    SyVwtjPFGmaLolQcpzNTBJAMeWnDRv=SyVwtjPFGmaLolQcpzNTBJAMeWnDuE(urllib.parse.parse_qsl(SyVwtjPFGmaLolQcpzNTBJAMeWnDRx))
    SyVwtjPFGmaLolQcpzNTBJAMeWnDRi=SyVwtjPFGmaLolQcpzNTBJAMeWnDri.get('code').strip()
    SyVwtjPFGmaLolQcpzNTBJAMeWnDRq=SyVwtjPFGmaLolQcpzNTBJAMeWnDRv.get('code').strip()
    if SyVwtjPFGmaLolQcpzNTBJAMeWnDgX=='vod' and SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.get_settings_direct_replay()==SyVwtjPFGmaLolQcpzNTBJAMeWnDuK:
     SyVwtjPFGmaLolQcpzNTBJAMeWnDRi=SyVwtjPFGmaLolQcpzNTBJAMeWnDri.get('videoid').strip()
     SyVwtjPFGmaLolQcpzNTBJAMeWnDRq=SyVwtjPFGmaLolQcpzNTBJAMeWnDRv.get('videoid').strip()if SyVwtjPFGmaLolQcpzNTBJAMeWnDRq!=SyVwtjPFGmaLolQcpzNTBJAMeWnDub else '-'
    if SyVwtjPFGmaLolQcpzNTBJAMeWnDRi!=SyVwtjPFGmaLolQcpzNTBJAMeWnDRq:
     fp.write(SyVwtjPFGmaLolQcpzNTBJAMeWnDRx)
     SyVwtjPFGmaLolQcpzNTBJAMeWnDRC+=1
     if SyVwtjPFGmaLolQcpzNTBJAMeWnDRC>=50:break
   fp.close()
  except:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDub
 def Delete_List_File(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC,SyVwtjPFGmaLolQcpzNTBJAMeWnDRK,skey='-'):
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDRK=='ALL':
   try:
    SyVwtjPFGmaLolQcpzNTBJAMeWnDRU=SyVwtjPFGmaLolQcpzNTBJAMeWnDru
    fp=SyVwtjPFGmaLolQcpzNTBJAMeWnDuY(SyVwtjPFGmaLolQcpzNTBJAMeWnDRU,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    SyVwtjPFGmaLolQcpzNTBJAMeWnDub
  elif SyVwtjPFGmaLolQcpzNTBJAMeWnDRK=='ONE':
   try:
    SyVwtjPFGmaLolQcpzNTBJAMeWnDRU=SyVwtjPFGmaLolQcpzNTBJAMeWnDru
    SyVwtjPFGmaLolQcpzNTBJAMeWnDRg=SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.Load_List_File('search') 
    fp=SyVwtjPFGmaLolQcpzNTBJAMeWnDuY(SyVwtjPFGmaLolQcpzNTBJAMeWnDRU,'w',-1,'utf-8')
    for SyVwtjPFGmaLolQcpzNTBJAMeWnDRx in SyVwtjPFGmaLolQcpzNTBJAMeWnDRg:
     SyVwtjPFGmaLolQcpzNTBJAMeWnDRv=SyVwtjPFGmaLolQcpzNTBJAMeWnDuE(urllib.parse.parse_qsl(SyVwtjPFGmaLolQcpzNTBJAMeWnDRx))
     SyVwtjPFGmaLolQcpzNTBJAMeWnDRb=SyVwtjPFGmaLolQcpzNTBJAMeWnDRv.get('skey').strip()
     if skey!=SyVwtjPFGmaLolQcpzNTBJAMeWnDRb:
      fp.write(SyVwtjPFGmaLolQcpzNTBJAMeWnDRx)
    fp.close()
   except:
    SyVwtjPFGmaLolQcpzNTBJAMeWnDub
  elif SyVwtjPFGmaLolQcpzNTBJAMeWnDRK in['vod','movie']:
   try:
    SyVwtjPFGmaLolQcpzNTBJAMeWnDRU=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%SyVwtjPFGmaLolQcpzNTBJAMeWnDRK))
    fp=SyVwtjPFGmaLolQcpzNTBJAMeWnDuY(SyVwtjPFGmaLolQcpzNTBJAMeWnDRU,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    SyVwtjPFGmaLolQcpzNTBJAMeWnDub
 def dp_Listfile_Delete(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC,args):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDRK=args.get('sType')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDdx =args.get('skey')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrb=xbmcgui.Dialog()
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDRK=='ALL':
   SyVwtjPFGmaLolQcpzNTBJAMeWnDRs=SyVwtjPFGmaLolQcpzNTBJAMeWnDrb.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif SyVwtjPFGmaLolQcpzNTBJAMeWnDRK=='ONE':
   SyVwtjPFGmaLolQcpzNTBJAMeWnDRs=SyVwtjPFGmaLolQcpzNTBJAMeWnDrb.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif SyVwtjPFGmaLolQcpzNTBJAMeWnDRK in['vod','movie']:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDRs=SyVwtjPFGmaLolQcpzNTBJAMeWnDrb.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDRs==SyVwtjPFGmaLolQcpzNTBJAMeWnDus:sys.exit()
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.Delete_List_File(SyVwtjPFGmaLolQcpzNTBJAMeWnDRK,skey=SyVwtjPFGmaLolQcpzNTBJAMeWnDdx)
  xbmc.executebuiltin("Container.Refresh")
 def Save_Searched_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC,SyVwtjPFGmaLolQcpzNTBJAMeWnDUE):
  try:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDRI=SyVwtjPFGmaLolQcpzNTBJAMeWnDru
   SyVwtjPFGmaLolQcpzNTBJAMeWnDRg=SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.Load_List_File('search') 
   SyVwtjPFGmaLolQcpzNTBJAMeWnDRO={'skey':SyVwtjPFGmaLolQcpzNTBJAMeWnDUE.strip()}
   fp=SyVwtjPFGmaLolQcpzNTBJAMeWnDuY(SyVwtjPFGmaLolQcpzNTBJAMeWnDRI,'w',-1,'utf-8')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDRu=urllib.parse.urlencode(SyVwtjPFGmaLolQcpzNTBJAMeWnDRO)
   SyVwtjPFGmaLolQcpzNTBJAMeWnDRu=SyVwtjPFGmaLolQcpzNTBJAMeWnDRu+'\n'
   fp.write(SyVwtjPFGmaLolQcpzNTBJAMeWnDRu)
   SyVwtjPFGmaLolQcpzNTBJAMeWnDRC=0
   for SyVwtjPFGmaLolQcpzNTBJAMeWnDRx in SyVwtjPFGmaLolQcpzNTBJAMeWnDRg:
    SyVwtjPFGmaLolQcpzNTBJAMeWnDRv=SyVwtjPFGmaLolQcpzNTBJAMeWnDuE(urllib.parse.parse_qsl(SyVwtjPFGmaLolQcpzNTBJAMeWnDRx))
    SyVwtjPFGmaLolQcpzNTBJAMeWnDRi=SyVwtjPFGmaLolQcpzNTBJAMeWnDRO.get('skey').strip()
    SyVwtjPFGmaLolQcpzNTBJAMeWnDRq=SyVwtjPFGmaLolQcpzNTBJAMeWnDRv.get('skey').strip()
    if SyVwtjPFGmaLolQcpzNTBJAMeWnDRi!=SyVwtjPFGmaLolQcpzNTBJAMeWnDRq:
     fp.write(SyVwtjPFGmaLolQcpzNTBJAMeWnDRx)
     SyVwtjPFGmaLolQcpzNTBJAMeWnDRC+=1
     if SyVwtjPFGmaLolQcpzNTBJAMeWnDRC>=50:break
   fp.close()
  except:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDub
 def dp_Global_Search(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC,args):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDUf=args.get('mode')
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDUf=='TOTAL_SEARCH':
   SyVwtjPFGmaLolQcpzNTBJAMeWnDRE='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDRE='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(SyVwtjPFGmaLolQcpzNTBJAMeWnDRE)
 def dp_Bookmark_Menu(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC,args):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDRE='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(SyVwtjPFGmaLolQcpzNTBJAMeWnDRE)
 def login_main(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC):
  (SyVwtjPFGmaLolQcpzNTBJAMeWnDRH,SyVwtjPFGmaLolQcpzNTBJAMeWnDRf,SyVwtjPFGmaLolQcpzNTBJAMeWnDRk)=SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.get_settings_login_info()
  if not(SyVwtjPFGmaLolQcpzNTBJAMeWnDRH and SyVwtjPFGmaLolQcpzNTBJAMeWnDRf):
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrb=xbmcgui.Dialog()
   SyVwtjPFGmaLolQcpzNTBJAMeWnDRs=SyVwtjPFGmaLolQcpzNTBJAMeWnDrb.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if SyVwtjPFGmaLolQcpzNTBJAMeWnDRs==SyVwtjPFGmaLolQcpzNTBJAMeWnDuK:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.get_winEpisodeOrderby()=='':
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.set_winEpisodeOrderby('desc')
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.cookiefile_check():return
  SyVwtjPFGmaLolQcpzNTBJAMeWnDRY =SyVwtjPFGmaLolQcpzNTBJAMeWnDuI(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  SyVwtjPFGmaLolQcpzNTBJAMeWnDRX=xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINTIME')
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDRX==SyVwtjPFGmaLolQcpzNTBJAMeWnDub or SyVwtjPFGmaLolQcpzNTBJAMeWnDRX=='':
   SyVwtjPFGmaLolQcpzNTBJAMeWnDRX=SyVwtjPFGmaLolQcpzNTBJAMeWnDuI('19000101')
  else:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDRX=SyVwtjPFGmaLolQcpzNTBJAMeWnDuI(re.sub('-','',SyVwtjPFGmaLolQcpzNTBJAMeWnDRX))
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   SyVwtjPFGmaLolQcpzNTBJAMeWnDhr=0
   while SyVwtjPFGmaLolQcpzNTBJAMeWnDuK:
    SyVwtjPFGmaLolQcpzNTBJAMeWnDhr+=1
    time.sleep(0.05)
    if SyVwtjPFGmaLolQcpzNTBJAMeWnDRX>=SyVwtjPFGmaLolQcpzNTBJAMeWnDRY:return
    if SyVwtjPFGmaLolQcpzNTBJAMeWnDhr>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDRX>=SyVwtjPFGmaLolQcpzNTBJAMeWnDRY:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   return
  if not SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.GetCredential(SyVwtjPFGmaLolQcpzNTBJAMeWnDRH,SyVwtjPFGmaLolQcpzNTBJAMeWnDRf,SyVwtjPFGmaLolQcpzNTBJAMeWnDRk):
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   sys.exit()
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.set_winCredential(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.LoadCredential())
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
 def dp_setEpOrderby(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC,args):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDhU =args.get('orderby')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.set_winEpisodeOrderby(SyVwtjPFGmaLolQcpzNTBJAMeWnDhU)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC,args):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.SaveCredential(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.get_winCredential())
  SyVwtjPFGmaLolQcpzNTBJAMeWnDUf =args.get('mode')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDhd =args.get('contentid')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDhR =args.get('pvrmode')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDhg=SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.get_selQuality()
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.addon_log(SyVwtjPFGmaLolQcpzNTBJAMeWnDhd+' - '+SyVwtjPFGmaLolQcpzNTBJAMeWnDUf)
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDUf=='SPORTS':
   SyVwtjPFGmaLolQcpzNTBJAMeWnDhu,SyVwtjPFGmaLolQcpzNTBJAMeWnDhC=SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.GetSportsURL(SyVwtjPFGmaLolQcpzNTBJAMeWnDhd,SyVwtjPFGmaLolQcpzNTBJAMeWnDhg)
   SyVwtjPFGmaLolQcpzNTBJAMeWnDhx =''
   SyVwtjPFGmaLolQcpzNTBJAMeWnDhv=''
  else:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDhu,SyVwtjPFGmaLolQcpzNTBJAMeWnDhC,SyVwtjPFGmaLolQcpzNTBJAMeWnDhx,SyVwtjPFGmaLolQcpzNTBJAMeWnDhv=SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.GetStreamingURL(SyVwtjPFGmaLolQcpzNTBJAMeWnDUf,SyVwtjPFGmaLolQcpzNTBJAMeWnDhd,SyVwtjPFGmaLolQcpzNTBJAMeWnDhg,SyVwtjPFGmaLolQcpzNTBJAMeWnDhR)
  SyVwtjPFGmaLolQcpzNTBJAMeWnDhi='%s|Cookie=%s'%(SyVwtjPFGmaLolQcpzNTBJAMeWnDhu,SyVwtjPFGmaLolQcpzNTBJAMeWnDhC)
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.addon_log(SyVwtjPFGmaLolQcpzNTBJAMeWnDhi)
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDhu=='':
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.addon_noti(__language__(30907).encode('utf8'))
   return
  SyVwtjPFGmaLolQcpzNTBJAMeWnDhq=xbmcgui.ListItem(path=SyVwtjPFGmaLolQcpzNTBJAMeWnDhi)
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDhx:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.addon_log('!!streaming_drm!!')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDhb=SyVwtjPFGmaLolQcpzNTBJAMeWnDhx['customdata']
   SyVwtjPFGmaLolQcpzNTBJAMeWnDhK =SyVwtjPFGmaLolQcpzNTBJAMeWnDhx['drmhost']
   SyVwtjPFGmaLolQcpzNTBJAMeWnDhs =inputstreamhelper.Helper('mpd',drm='widevine')
   if SyVwtjPFGmaLolQcpzNTBJAMeWnDhs.check_inputstream():
    if SyVwtjPFGmaLolQcpzNTBJAMeWnDUf=='MOVIE':
     SyVwtjPFGmaLolQcpzNTBJAMeWnDhI='https://www.wavve.com/player/movie?movieid=%s'%SyVwtjPFGmaLolQcpzNTBJAMeWnDhd
    else:
     SyVwtjPFGmaLolQcpzNTBJAMeWnDhI='https://www.wavve.com/player/vod?programid=%s&page=1'%SyVwtjPFGmaLolQcpzNTBJAMeWnDhd
    SyVwtjPFGmaLolQcpzNTBJAMeWnDhO={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':SyVwtjPFGmaLolQcpzNTBJAMeWnDhb,'referer':SyVwtjPFGmaLolQcpzNTBJAMeWnDhI,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.USER_AGENT}
    SyVwtjPFGmaLolQcpzNTBJAMeWnDhE=SyVwtjPFGmaLolQcpzNTBJAMeWnDhK+'|'+urllib.parse.urlencode(SyVwtjPFGmaLolQcpzNTBJAMeWnDhO)+'|R{SSM}|'
    SyVwtjPFGmaLolQcpzNTBJAMeWnDhq.setProperty('inputstream',SyVwtjPFGmaLolQcpzNTBJAMeWnDhs.inputstream_addon)
    SyVwtjPFGmaLolQcpzNTBJAMeWnDhq.setProperty('inputstream.adaptive.manifest_type','mpd')
    SyVwtjPFGmaLolQcpzNTBJAMeWnDhq.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    SyVwtjPFGmaLolQcpzNTBJAMeWnDhq.setProperty('inputstream.adaptive.license_key',SyVwtjPFGmaLolQcpzNTBJAMeWnDhE)
    SyVwtjPFGmaLolQcpzNTBJAMeWnDhq.setProperty('inputstream.adaptive.stream_headers','user-agent=%s&Cookie=%s'%(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.USER_AGENT,SyVwtjPFGmaLolQcpzNTBJAMeWnDhC))
  xbmcplugin.setResolvedUrl(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC._addon_handle,SyVwtjPFGmaLolQcpzNTBJAMeWnDuK,SyVwtjPFGmaLolQcpzNTBJAMeWnDhq)
  SyVwtjPFGmaLolQcpzNTBJAMeWnDhH=SyVwtjPFGmaLolQcpzNTBJAMeWnDus
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDhv:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.addon_noti(SyVwtjPFGmaLolQcpzNTBJAMeWnDhv.encode('utf-8'))
   SyVwtjPFGmaLolQcpzNTBJAMeWnDhH=SyVwtjPFGmaLolQcpzNTBJAMeWnDuK
  else:
   if '/preview.' in urllib.parse.urlsplit(SyVwtjPFGmaLolQcpzNTBJAMeWnDhu).path:
    SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.addon_noti(__language__(30908).encode('utf8'))
    SyVwtjPFGmaLolQcpzNTBJAMeWnDhH=SyVwtjPFGmaLolQcpzNTBJAMeWnDuK
  try:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDhf=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and SyVwtjPFGmaLolQcpzNTBJAMeWnDhH==SyVwtjPFGmaLolQcpzNTBJAMeWnDus and SyVwtjPFGmaLolQcpzNTBJAMeWnDhf!='-':
    SyVwtjPFGmaLolQcpzNTBJAMeWnDUb={'code':SyVwtjPFGmaLolQcpzNTBJAMeWnDhf,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.Save_Watched_List(args.get('mode').lower(),SyVwtjPFGmaLolQcpzNTBJAMeWnDUb)
  except:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDub
 def logout(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrb=xbmcgui.Dialog()
  SyVwtjPFGmaLolQcpzNTBJAMeWnDRs=SyVwtjPFGmaLolQcpzNTBJAMeWnDrb.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDRs==SyVwtjPFGmaLolQcpzNTBJAMeWnDus:sys.exit()
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.wininfo_clear()
  if os.path.isfile(SyVwtjPFGmaLolQcpzNTBJAMeWnDrg):os.remove(SyVwtjPFGmaLolQcpzNTBJAMeWnDrg)
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDUu=xbmcgui.Window(10000)
  SyVwtjPFGmaLolQcpzNTBJAMeWnDUu.setProperty('WAVVE_M_CREDENTIAL','')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDUu.setProperty('WAVVE_M_LOGINTIME','')
 def cookiefile_save(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDhk =SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.Get_Now_Datetime()
  SyVwtjPFGmaLolQcpzNTBJAMeWnDhY=SyVwtjPFGmaLolQcpzNTBJAMeWnDhk+datetime.timedelta(days=SyVwtjPFGmaLolQcpzNTBJAMeWnDuI(__addon__.getSetting('cache_ttl')))
  SyVwtjPFGmaLolQcpzNTBJAMeWnDUu=xbmcgui.Window(10000)
  SyVwtjPFGmaLolQcpzNTBJAMeWnDhX={'wavve_token':SyVwtjPFGmaLolQcpzNTBJAMeWnDUu.getProperty('WAVVE_M_CREDENTIAL'),'wavve_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'wavve_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'wavve_profile':__addon__.getSetting('selected_profile'),'wavve_limitdate':SyVwtjPFGmaLolQcpzNTBJAMeWnDhY.strftime('%Y-%m-%d')}
  try: 
   fp=SyVwtjPFGmaLolQcpzNTBJAMeWnDuY(SyVwtjPFGmaLolQcpzNTBJAMeWnDrg,'w',-1,'utf-8')
   json.dump(SyVwtjPFGmaLolQcpzNTBJAMeWnDhX,fp)
   fp.close()
  except SyVwtjPFGmaLolQcpzNTBJAMeWnDuX as exception:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDCr(exception)
 def cookiefile_check(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDhX={}
  try: 
   fp=SyVwtjPFGmaLolQcpzNTBJAMeWnDuY(SyVwtjPFGmaLolQcpzNTBJAMeWnDrg,'r',-1,'utf-8')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDhX= json.load(fp)
   fp.close()
  except SyVwtjPFGmaLolQcpzNTBJAMeWnDuX as exception:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.wininfo_clear()
   return SyVwtjPFGmaLolQcpzNTBJAMeWnDus
  SyVwtjPFGmaLolQcpzNTBJAMeWnDRH =__addon__.getSetting('id')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDRf =__addon__.getSetting('pw')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDgr =__addon__.getSetting('selected_profile')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDhX['wavve_id']=base64.standard_b64decode(SyVwtjPFGmaLolQcpzNTBJAMeWnDhX['wavve_id']).decode('utf-8')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDhX['wavve_pw']=base64.standard_b64decode(SyVwtjPFGmaLolQcpzNTBJAMeWnDhX['wavve_pw']).decode('utf-8')
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDRH!=SyVwtjPFGmaLolQcpzNTBJAMeWnDhX['wavve_id']or SyVwtjPFGmaLolQcpzNTBJAMeWnDRf!=SyVwtjPFGmaLolQcpzNTBJAMeWnDhX['wavve_pw']or SyVwtjPFGmaLolQcpzNTBJAMeWnDgr!=SyVwtjPFGmaLolQcpzNTBJAMeWnDhX['wavve_profile']:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.wininfo_clear()
   return SyVwtjPFGmaLolQcpzNTBJAMeWnDus
  SyVwtjPFGmaLolQcpzNTBJAMeWnDRY =SyVwtjPFGmaLolQcpzNTBJAMeWnDuI(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  SyVwtjPFGmaLolQcpzNTBJAMeWnDgU=SyVwtjPFGmaLolQcpzNTBJAMeWnDhX['wavve_limitdate']
  SyVwtjPFGmaLolQcpzNTBJAMeWnDRX =SyVwtjPFGmaLolQcpzNTBJAMeWnDuI(re.sub('-','',SyVwtjPFGmaLolQcpzNTBJAMeWnDgU))
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDRX<SyVwtjPFGmaLolQcpzNTBJAMeWnDRY:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.wininfo_clear()
   return SyVwtjPFGmaLolQcpzNTBJAMeWnDus
  SyVwtjPFGmaLolQcpzNTBJAMeWnDUu=xbmcgui.Window(10000)
  SyVwtjPFGmaLolQcpzNTBJAMeWnDUu.setProperty('WAVVE_M_CREDENTIAL',SyVwtjPFGmaLolQcpzNTBJAMeWnDhX['wavve_token'])
  SyVwtjPFGmaLolQcpzNTBJAMeWnDUu.setProperty('WAVVE_M_LOGINTIME',SyVwtjPFGmaLolQcpzNTBJAMeWnDgU)
  return SyVwtjPFGmaLolQcpzNTBJAMeWnDuK
 def dp_LiveCatagory_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC,args):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.SaveCredential(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.get_winCredential())
  SyVwtjPFGmaLolQcpzNTBJAMeWnDgd =args.get('sCode')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDgR=args.get('sIndex')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDds,SyVwtjPFGmaLolQcpzNTBJAMeWnDgh=SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.Get_LiveCatagory_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDgd,SyVwtjPFGmaLolQcpzNTBJAMeWnDgR)
  for SyVwtjPFGmaLolQcpzNTBJAMeWnDdI in SyVwtjPFGmaLolQcpzNTBJAMeWnDds:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUx =SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('title')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb={'mode':'LIVE_LIST','genre':SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('genre'),'baseapi':SyVwtjPFGmaLolQcpzNTBJAMeWnDgh}
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.add_dir(SyVwtjPFGmaLolQcpzNTBJAMeWnDUx,sublabel='',img='',infoLabels=SyVwtjPFGmaLolQcpzNTBJAMeWnDub,isFolder=SyVwtjPFGmaLolQcpzNTBJAMeWnDuK,params=SyVwtjPFGmaLolQcpzNTBJAMeWnDUb)
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDuH(SyVwtjPFGmaLolQcpzNTBJAMeWnDds)>0:xbmcplugin.endOfDirectory(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC._addon_handle,cacheToDisc=SyVwtjPFGmaLolQcpzNTBJAMeWnDus)
 def dp_MainCatagory_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC,args):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.SaveCredential(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.get_winCredential())
  SyVwtjPFGmaLolQcpzNTBJAMeWnDgd =args.get('sCode')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDgR=args.get('sIndex')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDUk =args.get('sType')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDds=SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.Get_MainCatagory_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDgd,SyVwtjPFGmaLolQcpzNTBJAMeWnDgR)
  for SyVwtjPFGmaLolQcpzNTBJAMeWnDdI in SyVwtjPFGmaLolQcpzNTBJAMeWnDds:
   if SyVwtjPFGmaLolQcpzNTBJAMeWnDUk=='vod':
    if SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('subtype')=='catagory':
     SyVwtjPFGmaLolQcpzNTBJAMeWnDUf='PROGRAM_LIST'
    else:
     SyVwtjPFGmaLolQcpzNTBJAMeWnDUf='SUPERSECTION_LIST'
   elif SyVwtjPFGmaLolQcpzNTBJAMeWnDUk=='movie':
    SyVwtjPFGmaLolQcpzNTBJAMeWnDUf='MOVIE_LIST'
   else:
    SyVwtjPFGmaLolQcpzNTBJAMeWnDUf=''
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUx='%s (%s)'%(SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('title'),args.get('ordernm'))
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb={'mode':SyVwtjPFGmaLolQcpzNTBJAMeWnDUf,'suburl':SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('suburl'),'subapi':SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.get_settings_exclusion21():
    if SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('title')=='성인' or SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('title')=='성인+':continue
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.add_dir(SyVwtjPFGmaLolQcpzNTBJAMeWnDUx,sublabel='',img='',infoLabels=SyVwtjPFGmaLolQcpzNTBJAMeWnDub,isFolder=SyVwtjPFGmaLolQcpzNTBJAMeWnDuK,params=SyVwtjPFGmaLolQcpzNTBJAMeWnDUb)
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDuH(SyVwtjPFGmaLolQcpzNTBJAMeWnDds)>0:xbmcplugin.endOfDirectory(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC._addon_handle,cacheToDisc=SyVwtjPFGmaLolQcpzNTBJAMeWnDus)
 def dp_Program_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC,args):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.SaveCredential(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.get_winCredential())
  SyVwtjPFGmaLolQcpzNTBJAMeWnDgu =args.get('subapi')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDdK=SyVwtjPFGmaLolQcpzNTBJAMeWnDuI(args.get('page'))
  SyVwtjPFGmaLolQcpzNTBJAMeWnDhU =args.get('orderby')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDds,SyVwtjPFGmaLolQcpzNTBJAMeWnDUX=SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.Get_Program_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDgu,SyVwtjPFGmaLolQcpzNTBJAMeWnDdK,SyVwtjPFGmaLolQcpzNTBJAMeWnDhU)
  for SyVwtjPFGmaLolQcpzNTBJAMeWnDdI in SyVwtjPFGmaLolQcpzNTBJAMeWnDds:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUx =SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('title')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdO=SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('thumbnail')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdE =SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('age')
   if SyVwtjPFGmaLolQcpzNTBJAMeWnDdE=='18' or SyVwtjPFGmaLolQcpzNTBJAMeWnDdE=='19' or SyVwtjPFGmaLolQcpzNTBJAMeWnDdE=='21':SyVwtjPFGmaLolQcpzNTBJAMeWnDUx+=' (%s)'%(SyVwtjPFGmaLolQcpzNTBJAMeWnDdE)
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdb={'plot':SyVwtjPFGmaLolQcpzNTBJAMeWnDUx,'mpaa':SyVwtjPFGmaLolQcpzNTBJAMeWnDdE,'mediatype':'tvshow'}
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb={'mode':'EPISODE_LIST','videoid':SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('videoid'),'vidtype':SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('vidtype'),'page':'1'}
   if SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.get_settings_makebookmark():
    SyVwtjPFGmaLolQcpzNTBJAMeWnDdH={'videoid':SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('videoid'),'vidtype':'tvshow','vtitle':SyVwtjPFGmaLolQcpzNTBJAMeWnDUx,'vsubtitle':'','contenttype':SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('vidtype'),}
    SyVwtjPFGmaLolQcpzNTBJAMeWnDdf=json.dumps(SyVwtjPFGmaLolQcpzNTBJAMeWnDdH)
    SyVwtjPFGmaLolQcpzNTBJAMeWnDdf=urllib.parse.quote(SyVwtjPFGmaLolQcpzNTBJAMeWnDdf)
    SyVwtjPFGmaLolQcpzNTBJAMeWnDdk='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(SyVwtjPFGmaLolQcpzNTBJAMeWnDdf)
    SyVwtjPFGmaLolQcpzNTBJAMeWnDdq=[('(통합) 찜 영상에 추가',SyVwtjPFGmaLolQcpzNTBJAMeWnDdk)]
   else:
    SyVwtjPFGmaLolQcpzNTBJAMeWnDdq=SyVwtjPFGmaLolQcpzNTBJAMeWnDub
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.add_dir(SyVwtjPFGmaLolQcpzNTBJAMeWnDUx,sublabel='',img=SyVwtjPFGmaLolQcpzNTBJAMeWnDdO,infoLabels=SyVwtjPFGmaLolQcpzNTBJAMeWnDdb,isFolder=SyVwtjPFGmaLolQcpzNTBJAMeWnDuK,params=SyVwtjPFGmaLolQcpzNTBJAMeWnDUb,ContextMenu=SyVwtjPFGmaLolQcpzNTBJAMeWnDdq)
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDUX:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb={}
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb['mode'] ='PROGRAM_LIST' 
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb['subapi']=SyVwtjPFGmaLolQcpzNTBJAMeWnDgu 
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb['page'] =SyVwtjPFGmaLolQcpzNTBJAMeWnDuk(SyVwtjPFGmaLolQcpzNTBJAMeWnDdK+1)
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUx='[B]%s >>[/B]'%'다음 페이지'
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdY=SyVwtjPFGmaLolQcpzNTBJAMeWnDuk(SyVwtjPFGmaLolQcpzNTBJAMeWnDdK+1)
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUq=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.add_dir(SyVwtjPFGmaLolQcpzNTBJAMeWnDUx,sublabel=SyVwtjPFGmaLolQcpzNTBJAMeWnDdY,img=SyVwtjPFGmaLolQcpzNTBJAMeWnDUq,infoLabels=SyVwtjPFGmaLolQcpzNTBJAMeWnDub,isFolder=SyVwtjPFGmaLolQcpzNTBJAMeWnDuK,params=SyVwtjPFGmaLolQcpzNTBJAMeWnDUb)
  xbmcplugin.setContent(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC._addon_handle,'tvshows')
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDuH(SyVwtjPFGmaLolQcpzNTBJAMeWnDds)>0:xbmcplugin.endOfDirectory(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC._addon_handle,cacheToDisc=SyVwtjPFGmaLolQcpzNTBJAMeWnDus)
 def dp_SuperSection_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC,args):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.SaveCredential(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.get_winCredential())
  SyVwtjPFGmaLolQcpzNTBJAMeWnDgC =args.get('suburl')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDds=SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.Get_SuperMultiSection_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDgC)
  for SyVwtjPFGmaLolQcpzNTBJAMeWnDdI in SyVwtjPFGmaLolQcpzNTBJAMeWnDds:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUx =SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('title')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDgu =SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('subapi')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDgx=SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('cell_type')
   if SyVwtjPFGmaLolQcpzNTBJAMeWnDgu.find('mtype=svod')>=0 or SyVwtjPFGmaLolQcpzNTBJAMeWnDgu.find('mtype=ppv')>=0:
    SyVwtjPFGmaLolQcpzNTBJAMeWnDUf='MOVIE_LIST'
   elif SyVwtjPFGmaLolQcpzNTBJAMeWnDgx=='band_71':
    SyVwtjPFGmaLolQcpzNTBJAMeWnDUf ='SUPERSECTION_LIST'
    (SyVwtjPFGmaLolQcpzNTBJAMeWnDgv,SyVwtjPFGmaLolQcpzNTBJAMeWnDgi)=SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.Baseapi_Parse(SyVwtjPFGmaLolQcpzNTBJAMeWnDgu)
    SyVwtjPFGmaLolQcpzNTBJAMeWnDgC=SyVwtjPFGmaLolQcpzNTBJAMeWnDgi.get('api')
    SyVwtjPFGmaLolQcpzNTBJAMeWnDgu=''
   elif SyVwtjPFGmaLolQcpzNTBJAMeWnDgx=='band_2':
    SyVwtjPFGmaLolQcpzNTBJAMeWnDUf='BAND2SECTION_LIST'
   elif SyVwtjPFGmaLolQcpzNTBJAMeWnDgx=='band_live':
    SyVwtjPFGmaLolQcpzNTBJAMeWnDUf='BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}',SyVwtjPFGmaLolQcpzNTBJAMeWnDgu):
    SyVwtjPFGmaLolQcpzNTBJAMeWnDUf='MOVIE_LIST'
   else:
    SyVwtjPFGmaLolQcpzNTBJAMeWnDUf='PROGRAM_LIST'
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdb={'plot':SyVwtjPFGmaLolQcpzNTBJAMeWnDUx,'mediatype':'tvshow'}
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb={'mode':SyVwtjPFGmaLolQcpzNTBJAMeWnDUf,'suburl':SyVwtjPFGmaLolQcpzNTBJAMeWnDgC,'subapi':SyVwtjPFGmaLolQcpzNTBJAMeWnDgu,'page':'1'}
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.add_dir(SyVwtjPFGmaLolQcpzNTBJAMeWnDUx,sublabel='',img=SyVwtjPFGmaLolQcpzNTBJAMeWnDub,infoLabels=SyVwtjPFGmaLolQcpzNTBJAMeWnDdb,isFolder=SyVwtjPFGmaLolQcpzNTBJAMeWnDuK,params=SyVwtjPFGmaLolQcpzNTBJAMeWnDUb)
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDuH(SyVwtjPFGmaLolQcpzNTBJAMeWnDds)>0:xbmcplugin.endOfDirectory(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC._addon_handle,cacheToDisc=SyVwtjPFGmaLolQcpzNTBJAMeWnDus)
 def dp_BandLiveSection_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC,args):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.SaveCredential(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.get_winCredential())
  SyVwtjPFGmaLolQcpzNTBJAMeWnDgu =args.get('subapi')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDdK=SyVwtjPFGmaLolQcpzNTBJAMeWnDuI(args.get('page'))
  SyVwtjPFGmaLolQcpzNTBJAMeWnDds,SyVwtjPFGmaLolQcpzNTBJAMeWnDUX=SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.Get_BandLiveSection_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDgu,SyVwtjPFGmaLolQcpzNTBJAMeWnDdK)
  for SyVwtjPFGmaLolQcpzNTBJAMeWnDdI in SyVwtjPFGmaLolQcpzNTBJAMeWnDds:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDgq =SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('channelid')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDgb =SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('studio')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDgK=SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('tvshowtitle')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdO =SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('thumbnail')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdE =SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('age')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdb={'mediatype':'tvshow','mpaa':SyVwtjPFGmaLolQcpzNTBJAMeWnDdE,'title':'%s < %s >'%(SyVwtjPFGmaLolQcpzNTBJAMeWnDgb,SyVwtjPFGmaLolQcpzNTBJAMeWnDgK),'tvshowtitle':SyVwtjPFGmaLolQcpzNTBJAMeWnDgK,'studio':SyVwtjPFGmaLolQcpzNTBJAMeWnDgb,'plot':SyVwtjPFGmaLolQcpzNTBJAMeWnDgb}
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb={'mode':'LIVE','contentid':SyVwtjPFGmaLolQcpzNTBJAMeWnDgq}
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.add_dir(SyVwtjPFGmaLolQcpzNTBJAMeWnDgb,sublabel=SyVwtjPFGmaLolQcpzNTBJAMeWnDgK,img=SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('thumbnail'),infoLabels=SyVwtjPFGmaLolQcpzNTBJAMeWnDdb,isFolder=SyVwtjPFGmaLolQcpzNTBJAMeWnDus,params=SyVwtjPFGmaLolQcpzNTBJAMeWnDUb)
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDUX:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb={}
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb['mode'] ='BANDLIVESECTION_LIST' 
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb['subapi']=SyVwtjPFGmaLolQcpzNTBJAMeWnDgu
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb['page'] =SyVwtjPFGmaLolQcpzNTBJAMeWnDuk(SyVwtjPFGmaLolQcpzNTBJAMeWnDdK+1)
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUx='[B]%s >>[/B]'%'다음 페이지'
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdY=SyVwtjPFGmaLolQcpzNTBJAMeWnDuk(SyVwtjPFGmaLolQcpzNTBJAMeWnDdK+1)
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUq=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.add_dir(SyVwtjPFGmaLolQcpzNTBJAMeWnDUx,sublabel=SyVwtjPFGmaLolQcpzNTBJAMeWnDdY,img=SyVwtjPFGmaLolQcpzNTBJAMeWnDUq,infoLabels=SyVwtjPFGmaLolQcpzNTBJAMeWnDub,isFolder=SyVwtjPFGmaLolQcpzNTBJAMeWnDuK,params=SyVwtjPFGmaLolQcpzNTBJAMeWnDUb)
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDuH(SyVwtjPFGmaLolQcpzNTBJAMeWnDds)>0:xbmcplugin.endOfDirectory(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC._addon_handle,cacheToDisc=SyVwtjPFGmaLolQcpzNTBJAMeWnDus)
 def dp_Band2Section_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC,args):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.SaveCredential(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.get_winCredential())
  SyVwtjPFGmaLolQcpzNTBJAMeWnDgu =args.get('subapi')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDdK=SyVwtjPFGmaLolQcpzNTBJAMeWnDuI(args.get('page'))
  SyVwtjPFGmaLolQcpzNTBJAMeWnDds,SyVwtjPFGmaLolQcpzNTBJAMeWnDUX=SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.Get_Band2Section_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDgu,SyVwtjPFGmaLolQcpzNTBJAMeWnDdK)
  for SyVwtjPFGmaLolQcpzNTBJAMeWnDdI in SyVwtjPFGmaLolQcpzNTBJAMeWnDds:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUx =SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('programtitle')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdY =SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('episodetitle')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdb={'plot':SyVwtjPFGmaLolQcpzNTBJAMeWnDUx+'\n\n'+SyVwtjPFGmaLolQcpzNTBJAMeWnDdY,'mpaa':SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('age'),'mediatype':'episode'}
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb={'mode':'VOD','programid':'-','contentid':SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('videoid'),'thumbnail':SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('thumbnail'),'title':SyVwtjPFGmaLolQcpzNTBJAMeWnDUx,'subtitle':SyVwtjPFGmaLolQcpzNTBJAMeWnDdY}
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.add_dir(SyVwtjPFGmaLolQcpzNTBJAMeWnDUx,sublabel=SyVwtjPFGmaLolQcpzNTBJAMeWnDdY,img=SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('thumbnail'),infoLabels=SyVwtjPFGmaLolQcpzNTBJAMeWnDdb,isFolder=SyVwtjPFGmaLolQcpzNTBJAMeWnDus,params=SyVwtjPFGmaLolQcpzNTBJAMeWnDUb)
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDUX:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb={}
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb['mode'] ='BAND2SECTION_LIST' 
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb['subapi']=SyVwtjPFGmaLolQcpzNTBJAMeWnDgu
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb['page'] =SyVwtjPFGmaLolQcpzNTBJAMeWnDuk(SyVwtjPFGmaLolQcpzNTBJAMeWnDdK+1)
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUx='[B]%s >>[/B]'%'다음 페이지'
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdY=SyVwtjPFGmaLolQcpzNTBJAMeWnDuk(SyVwtjPFGmaLolQcpzNTBJAMeWnDdK+1)
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUq=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.add_dir(SyVwtjPFGmaLolQcpzNTBJAMeWnDUx,sublabel=SyVwtjPFGmaLolQcpzNTBJAMeWnDdY,img=SyVwtjPFGmaLolQcpzNTBJAMeWnDUq,infoLabels=SyVwtjPFGmaLolQcpzNTBJAMeWnDub,isFolder=SyVwtjPFGmaLolQcpzNTBJAMeWnDuK,params=SyVwtjPFGmaLolQcpzNTBJAMeWnDUb)
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDuH(SyVwtjPFGmaLolQcpzNTBJAMeWnDds)>0:xbmcplugin.endOfDirectory(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC._addon_handle,cacheToDisc=SyVwtjPFGmaLolQcpzNTBJAMeWnDus)
 def dp_Movie_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC,args):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.SaveCredential(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.get_winCredential())
  SyVwtjPFGmaLolQcpzNTBJAMeWnDgu =args.get('subapi')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDdK=SyVwtjPFGmaLolQcpzNTBJAMeWnDuI(args.get('page'))
  SyVwtjPFGmaLolQcpzNTBJAMeWnDds,SyVwtjPFGmaLolQcpzNTBJAMeWnDUX=SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.Get_Movie_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDgu,SyVwtjPFGmaLolQcpzNTBJAMeWnDdK)
  for SyVwtjPFGmaLolQcpzNTBJAMeWnDdI in SyVwtjPFGmaLolQcpzNTBJAMeWnDds:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUx =SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('title')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdO=SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('thumbnail')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdE =SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('age')
   if SyVwtjPFGmaLolQcpzNTBJAMeWnDdE=='18' or SyVwtjPFGmaLolQcpzNTBJAMeWnDdE=='19' or SyVwtjPFGmaLolQcpzNTBJAMeWnDdE=='21':SyVwtjPFGmaLolQcpzNTBJAMeWnDUx+=' (%s)'%(SyVwtjPFGmaLolQcpzNTBJAMeWnDdE)
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdb={'plot':SyVwtjPFGmaLolQcpzNTBJAMeWnDUx,'mpaa':SyVwtjPFGmaLolQcpzNTBJAMeWnDdE,'mediatype':'movie'}
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb={'mode':'MOVIE','contentid':SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('videoid'),'title':SyVwtjPFGmaLolQcpzNTBJAMeWnDUx,'thumbnail':SyVwtjPFGmaLolQcpzNTBJAMeWnDdO,'age':SyVwtjPFGmaLolQcpzNTBJAMeWnDdE}
   if SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.get_settings_makebookmark():
    SyVwtjPFGmaLolQcpzNTBJAMeWnDdH={'videoid':SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('videoid'),'vidtype':'movie','vtitle':SyVwtjPFGmaLolQcpzNTBJAMeWnDUx,'vsubtitle':'','contenttype':'programid',}
    SyVwtjPFGmaLolQcpzNTBJAMeWnDdf=json.dumps(SyVwtjPFGmaLolQcpzNTBJAMeWnDdH)
    SyVwtjPFGmaLolQcpzNTBJAMeWnDdf=urllib.parse.quote(SyVwtjPFGmaLolQcpzNTBJAMeWnDdf)
    SyVwtjPFGmaLolQcpzNTBJAMeWnDdk='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(SyVwtjPFGmaLolQcpzNTBJAMeWnDdf)
    SyVwtjPFGmaLolQcpzNTBJAMeWnDdq=[('(통합) 찜 영상에 추가',SyVwtjPFGmaLolQcpzNTBJAMeWnDdk)]
   else:
    SyVwtjPFGmaLolQcpzNTBJAMeWnDdq=SyVwtjPFGmaLolQcpzNTBJAMeWnDub
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.add_dir(SyVwtjPFGmaLolQcpzNTBJAMeWnDUx,sublabel='',img=SyVwtjPFGmaLolQcpzNTBJAMeWnDdO,infoLabels=SyVwtjPFGmaLolQcpzNTBJAMeWnDdb,isFolder=SyVwtjPFGmaLolQcpzNTBJAMeWnDus,params=SyVwtjPFGmaLolQcpzNTBJAMeWnDUb,ContextMenu=SyVwtjPFGmaLolQcpzNTBJAMeWnDdq)
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDUX:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb={}
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb['mode'] ='MOVIE_LIST' 
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb['subapi']=SyVwtjPFGmaLolQcpzNTBJAMeWnDgu 
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb['page'] =SyVwtjPFGmaLolQcpzNTBJAMeWnDuk(SyVwtjPFGmaLolQcpzNTBJAMeWnDdK+1)
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUx='[B]%s >>[/B]'%'다음 페이지'
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdY=SyVwtjPFGmaLolQcpzNTBJAMeWnDuk(SyVwtjPFGmaLolQcpzNTBJAMeWnDdK+1)
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUq=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.add_dir(SyVwtjPFGmaLolQcpzNTBJAMeWnDUx,sublabel=SyVwtjPFGmaLolQcpzNTBJAMeWnDdY,img=SyVwtjPFGmaLolQcpzNTBJAMeWnDUq,infoLabels=SyVwtjPFGmaLolQcpzNTBJAMeWnDub,isFolder=SyVwtjPFGmaLolQcpzNTBJAMeWnDuK,params=SyVwtjPFGmaLolQcpzNTBJAMeWnDUb)
  xbmcplugin.setContent(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC._addon_handle,'movies')
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDuH(SyVwtjPFGmaLolQcpzNTBJAMeWnDds)>0:xbmcplugin.endOfDirectory(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC._addon_handle,cacheToDisc=SyVwtjPFGmaLolQcpzNTBJAMeWnDus)
 def dp_Set_Bookmark(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC,args):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDgs=urllib.parse.unquote(args.get('bm_param'))
  SyVwtjPFGmaLolQcpzNTBJAMeWnDgs=json.loads(SyVwtjPFGmaLolQcpzNTBJAMeWnDgs)
  SyVwtjPFGmaLolQcpzNTBJAMeWnDRr =SyVwtjPFGmaLolQcpzNTBJAMeWnDgs.get('videoid')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDgI =SyVwtjPFGmaLolQcpzNTBJAMeWnDgs.get('vidtype')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDgO =SyVwtjPFGmaLolQcpzNTBJAMeWnDgs.get('vtitle')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDgE =SyVwtjPFGmaLolQcpzNTBJAMeWnDgs.get('vsubtitle')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDgH=SyVwtjPFGmaLolQcpzNTBJAMeWnDgs.get('contenttype')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrb=xbmcgui.Dialog()
  SyVwtjPFGmaLolQcpzNTBJAMeWnDRs=SyVwtjPFGmaLolQcpzNTBJAMeWnDrb.yesno(__language__(30913).encode('utf8'),SyVwtjPFGmaLolQcpzNTBJAMeWnDgO+' \n\n'+__language__(30914))
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDRs==SyVwtjPFGmaLolQcpzNTBJAMeWnDus:return
  SyVwtjPFGmaLolQcpzNTBJAMeWnDgf=SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.GetBookmarkInfo(SyVwtjPFGmaLolQcpzNTBJAMeWnDRr,SyVwtjPFGmaLolQcpzNTBJAMeWnDgI,SyVwtjPFGmaLolQcpzNTBJAMeWnDgH)
  SyVwtjPFGmaLolQcpzNTBJAMeWnDgk=json.dumps(SyVwtjPFGmaLolQcpzNTBJAMeWnDgf)
  SyVwtjPFGmaLolQcpzNTBJAMeWnDgk=urllib.parse.quote(SyVwtjPFGmaLolQcpzNTBJAMeWnDgk)
  SyVwtjPFGmaLolQcpzNTBJAMeWnDdk ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(SyVwtjPFGmaLolQcpzNTBJAMeWnDgk)
  xbmc.executebuiltin(SyVwtjPFGmaLolQcpzNTBJAMeWnDdk)
 def dp_Episode_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC,args):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.SaveCredential(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.get_winCredential())
  SyVwtjPFGmaLolQcpzNTBJAMeWnDRr =args.get('videoid')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDgI =args.get('vidtype')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDdK=SyVwtjPFGmaLolQcpzNTBJAMeWnDuI(args.get('page'))
  SyVwtjPFGmaLolQcpzNTBJAMeWnDds,SyVwtjPFGmaLolQcpzNTBJAMeWnDUX=SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.Get_Episode_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDRr,SyVwtjPFGmaLolQcpzNTBJAMeWnDgI,SyVwtjPFGmaLolQcpzNTBJAMeWnDdK,orderby=SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.get_winEpisodeOrderby())
  for SyVwtjPFGmaLolQcpzNTBJAMeWnDdI in SyVwtjPFGmaLolQcpzNTBJAMeWnDds:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdY='%s회, %s(%s)'%(SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('episodenumber'),SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('releasedate'),SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('releaseweekday'))
   SyVwtjPFGmaLolQcpzNTBJAMeWnDgY ='[%s]\n\n%s'%(SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('episodetitle'),SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('synopsis'))
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdb={'mediatype':'episode','title':SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('programtitle'),'year':SyVwtjPFGmaLolQcpzNTBJAMeWnDuI(SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('releasedate')[:4]),'aired':SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('releasedate'),'mpaa':SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('age'),'episode':SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('episodenumber'),'duration':SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('playtime'),'plot':SyVwtjPFGmaLolQcpzNTBJAMeWnDgY,'cast':SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('episodeactors')}
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb={'mode':'VOD','programid':SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('programid'),'contentid':SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('contentid'),'thumbnail':SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('thumbnail'),'title':SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('programtitle'),'subtitle':SyVwtjPFGmaLolQcpzNTBJAMeWnDdY}
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.add_dir(SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('programtitle'),sublabel=SyVwtjPFGmaLolQcpzNTBJAMeWnDdY,img=SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('thumbnail'),infoLabels=SyVwtjPFGmaLolQcpzNTBJAMeWnDdb,isFolder=SyVwtjPFGmaLolQcpzNTBJAMeWnDus,params=SyVwtjPFGmaLolQcpzNTBJAMeWnDUb)
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDdK==1:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdb={'plot':'정렬순서를 변경합니다.'}
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb={}
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb['mode'] ='ORDER_BY' 
   if SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.get_winEpisodeOrderby()=='desc':
    SyVwtjPFGmaLolQcpzNTBJAMeWnDUx='정렬순서변경 : 최신화부터 -> 1회부터'
    SyVwtjPFGmaLolQcpzNTBJAMeWnDUb['orderby']='asc'
   else:
    SyVwtjPFGmaLolQcpzNTBJAMeWnDUx='정렬순서변경 : 1회부터 -> 최신화부터'
    SyVwtjPFGmaLolQcpzNTBJAMeWnDUb['orderby']='desc'
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUq=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.add_dir(SyVwtjPFGmaLolQcpzNTBJAMeWnDUx,sublabel='',img=SyVwtjPFGmaLolQcpzNTBJAMeWnDUq,infoLabels=SyVwtjPFGmaLolQcpzNTBJAMeWnDdb,isFolder=SyVwtjPFGmaLolQcpzNTBJAMeWnDus,params=SyVwtjPFGmaLolQcpzNTBJAMeWnDUb,isLink=SyVwtjPFGmaLolQcpzNTBJAMeWnDuK)
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDUX:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb={}
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb['mode'] ='EPISODE_LIST' 
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb['videoid']=SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('programid')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb['vidtype']='programid'
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb['page'] =SyVwtjPFGmaLolQcpzNTBJAMeWnDuk(SyVwtjPFGmaLolQcpzNTBJAMeWnDdK+1)
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUx='[B]%s >>[/B]'%'다음 페이지'
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdY=SyVwtjPFGmaLolQcpzNTBJAMeWnDuk(SyVwtjPFGmaLolQcpzNTBJAMeWnDdK+1)
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUq=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.add_dir(SyVwtjPFGmaLolQcpzNTBJAMeWnDUx,sublabel=SyVwtjPFGmaLolQcpzNTBJAMeWnDdY,img=SyVwtjPFGmaLolQcpzNTBJAMeWnDUq,infoLabels=SyVwtjPFGmaLolQcpzNTBJAMeWnDub,isFolder=SyVwtjPFGmaLolQcpzNTBJAMeWnDuK,params=SyVwtjPFGmaLolQcpzNTBJAMeWnDUb)
  xbmcplugin.setContent(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC._addon_handle,'episodes')
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDuH(SyVwtjPFGmaLolQcpzNTBJAMeWnDds)>0:xbmcplugin.endOfDirectory(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC._addon_handle,cacheToDisc=SyVwtjPFGmaLolQcpzNTBJAMeWnDus)
 def dp_LiveChannel_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC,args):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.SaveCredential(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.get_winCredential())
  SyVwtjPFGmaLolQcpzNTBJAMeWnDgX =args.get('genre')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDgh=args.get('baseapi')
  SyVwtjPFGmaLolQcpzNTBJAMeWnDds=SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.Get_LiveChannel_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDgX,SyVwtjPFGmaLolQcpzNTBJAMeWnDgh)
  for SyVwtjPFGmaLolQcpzNTBJAMeWnDdI in SyVwtjPFGmaLolQcpzNTBJAMeWnDds:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDgq =SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('channelid')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDgb =SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('studio')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDgK=SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('tvshowtitle')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdO =SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('thumbnail')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdE =SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('age')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDur =SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('epg')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdb={'mediatype':'episode','mpaa':SyVwtjPFGmaLolQcpzNTBJAMeWnDdE,'title':'%s < %s >'%(SyVwtjPFGmaLolQcpzNTBJAMeWnDgb,SyVwtjPFGmaLolQcpzNTBJAMeWnDgK),'tvshowtitle':SyVwtjPFGmaLolQcpzNTBJAMeWnDgK,'studio':SyVwtjPFGmaLolQcpzNTBJAMeWnDgb,'plot':'%s\n\n%s'%(SyVwtjPFGmaLolQcpzNTBJAMeWnDgb,SyVwtjPFGmaLolQcpzNTBJAMeWnDur)}
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb={'mode':'LIVE','contentid':SyVwtjPFGmaLolQcpzNTBJAMeWnDgq}
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.add_dir(SyVwtjPFGmaLolQcpzNTBJAMeWnDgb,sublabel=SyVwtjPFGmaLolQcpzNTBJAMeWnDgK,img=SyVwtjPFGmaLolQcpzNTBJAMeWnDdO,infoLabels=SyVwtjPFGmaLolQcpzNTBJAMeWnDdb,isFolder=SyVwtjPFGmaLolQcpzNTBJAMeWnDus,params=SyVwtjPFGmaLolQcpzNTBJAMeWnDUb)
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDuH(SyVwtjPFGmaLolQcpzNTBJAMeWnDds)>0:xbmcplugin.endOfDirectory(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC._addon_handle,cacheToDisc=SyVwtjPFGmaLolQcpzNTBJAMeWnDus)
 def dp_Sports_GameList(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC,args):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.SaveCredential(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.get_winCredential())
  SyVwtjPFGmaLolQcpzNTBJAMeWnDds=SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.WavveObj.Get_Sports_Gamelist()
  for SyVwtjPFGmaLolQcpzNTBJAMeWnDdI in SyVwtjPFGmaLolQcpzNTBJAMeWnDds:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDuU =SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('game_date')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDud =SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('game_time')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDuR =SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('svc_id')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDuh =SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('away_team')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDug =SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('home_team')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDuC=SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('game_status')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDux =SyVwtjPFGmaLolQcpzNTBJAMeWnDdI.get('game_place')
   SyVwtjPFGmaLolQcpzNTBJAMeWnDuv ='%s vs %s (%s)'%(SyVwtjPFGmaLolQcpzNTBJAMeWnDuh,SyVwtjPFGmaLolQcpzNTBJAMeWnDug,SyVwtjPFGmaLolQcpzNTBJAMeWnDux)
   SyVwtjPFGmaLolQcpzNTBJAMeWnDui =SyVwtjPFGmaLolQcpzNTBJAMeWnDuU+' '+SyVwtjPFGmaLolQcpzNTBJAMeWnDud
   if SyVwtjPFGmaLolQcpzNTBJAMeWnDuC=='LIVE':
    SyVwtjPFGmaLolQcpzNTBJAMeWnDuC='~경기중~'
   elif SyVwtjPFGmaLolQcpzNTBJAMeWnDuC=='END':
    SyVwtjPFGmaLolQcpzNTBJAMeWnDuC='경기종료'
   elif SyVwtjPFGmaLolQcpzNTBJAMeWnDuC=='CANCEL':
    SyVwtjPFGmaLolQcpzNTBJAMeWnDuC='취소'
   else:
    SyVwtjPFGmaLolQcpzNTBJAMeWnDuC=''
   if SyVwtjPFGmaLolQcpzNTBJAMeWnDuC=='':
    SyVwtjPFGmaLolQcpzNTBJAMeWnDdY=SyVwtjPFGmaLolQcpzNTBJAMeWnDuv
   else:
    SyVwtjPFGmaLolQcpzNTBJAMeWnDdY=SyVwtjPFGmaLolQcpzNTBJAMeWnDuv+'  '+SyVwtjPFGmaLolQcpzNTBJAMeWnDuC
   SyVwtjPFGmaLolQcpzNTBJAMeWnDdb={'mediatype':'episode','title':SyVwtjPFGmaLolQcpzNTBJAMeWnDuv,'plot':'%s\n\n%s\n\n%s'%(SyVwtjPFGmaLolQcpzNTBJAMeWnDui,SyVwtjPFGmaLolQcpzNTBJAMeWnDuv,SyVwtjPFGmaLolQcpzNTBJAMeWnDuC)}
   SyVwtjPFGmaLolQcpzNTBJAMeWnDUb={'mode':'SPORTS','contentid':SyVwtjPFGmaLolQcpzNTBJAMeWnDuR}
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.add_dir(SyVwtjPFGmaLolQcpzNTBJAMeWnDui,sublabel=SyVwtjPFGmaLolQcpzNTBJAMeWnDdY,img='',infoLabels=SyVwtjPFGmaLolQcpzNTBJAMeWnDdb,isFolder=SyVwtjPFGmaLolQcpzNTBJAMeWnDus,params=SyVwtjPFGmaLolQcpzNTBJAMeWnDUb)
  xbmcplugin.endOfDirectory(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC._addon_handle,cacheToDisc=SyVwtjPFGmaLolQcpzNTBJAMeWnDus)
 def wavve_main(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC):
  SyVwtjPFGmaLolQcpzNTBJAMeWnDUf=SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.main_params.get('mode',SyVwtjPFGmaLolQcpzNTBJAMeWnDub)
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDUf=='LOGOUT':
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.logout()
   return
  SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.login_main()
  if SyVwtjPFGmaLolQcpzNTBJAMeWnDUf is SyVwtjPFGmaLolQcpzNTBJAMeWnDub:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.dp_Main_List()
  elif SyVwtjPFGmaLolQcpzNTBJAMeWnDUf in['LIVE','VOD','MOVIE','SPORTS']:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.play_VIDEO(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.main_params)
  elif SyVwtjPFGmaLolQcpzNTBJAMeWnDUf=='LIVE_CATAGORY':
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.dp_LiveCatagory_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.main_params)
  elif SyVwtjPFGmaLolQcpzNTBJAMeWnDUf=='MAIN_CATAGORY':
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.dp_MainCatagory_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.main_params)
  elif SyVwtjPFGmaLolQcpzNTBJAMeWnDUf=='SUPERSECTION_LIST':
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.dp_SuperSection_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.main_params)
  elif SyVwtjPFGmaLolQcpzNTBJAMeWnDUf=='BANDLIVESECTION_LIST':
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.dp_BandLiveSection_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.main_params)
  elif SyVwtjPFGmaLolQcpzNTBJAMeWnDUf=='BAND2SECTION_LIST':
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.dp_Band2Section_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.main_params)
  elif SyVwtjPFGmaLolQcpzNTBJAMeWnDUf=='PROGRAM_LIST':
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.dp_Program_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.main_params)
  elif SyVwtjPFGmaLolQcpzNTBJAMeWnDUf=='EPISODE_LIST':
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.dp_Episode_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.main_params)
  elif SyVwtjPFGmaLolQcpzNTBJAMeWnDUf=='MOVIE_LIST':
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.dp_Movie_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.main_params)
  elif SyVwtjPFGmaLolQcpzNTBJAMeWnDUf=='LIVE_LIST':
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.dp_LiveChannel_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.main_params)
  elif SyVwtjPFGmaLolQcpzNTBJAMeWnDUf=='ORDER_BY':
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.dp_setEpOrderby(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.main_params)
  elif SyVwtjPFGmaLolQcpzNTBJAMeWnDUf=='SEARCH_GROUP':
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.dp_Search_Group(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.main_params)
  elif SyVwtjPFGmaLolQcpzNTBJAMeWnDUf in['SEARCH_LIST','LOCAL_SEARCH']:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.dp_Search_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.main_params)
  elif SyVwtjPFGmaLolQcpzNTBJAMeWnDUf=='WATCH_GROUP':
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.dp_Watch_Group(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.main_params)
  elif SyVwtjPFGmaLolQcpzNTBJAMeWnDUf=='WATCH_LIST':
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.dp_Watch_List(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.main_params)
  elif SyVwtjPFGmaLolQcpzNTBJAMeWnDUf=='SET_BOOKMARK':
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.dp_Set_Bookmark(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.main_params)
  elif SyVwtjPFGmaLolQcpzNTBJAMeWnDUf in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.dp_Listfile_Delete(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.main_params)
  elif SyVwtjPFGmaLolQcpzNTBJAMeWnDUf in['TOTAL_SEARCH','TOTAL_HISTORY']:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.dp_Global_Search(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.main_params)
  elif SyVwtjPFGmaLolQcpzNTBJAMeWnDUf=='SEARCH_HISTORY':
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.dp_Search_History(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.main_params)
  elif SyVwtjPFGmaLolQcpzNTBJAMeWnDUf=='MENU_BOOKMARK':
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.dp_Bookmark_Menu(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.main_params)
  elif SyVwtjPFGmaLolQcpzNTBJAMeWnDUf=='GAME_LIST':
   SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.dp_Sports_GameList(SyVwtjPFGmaLolQcpzNTBJAMeWnDrC.main_params)
  else:
   SyVwtjPFGmaLolQcpzNTBJAMeWnDub
# Created by pyminifier (https://github.com/liftoff/pyminifier)
