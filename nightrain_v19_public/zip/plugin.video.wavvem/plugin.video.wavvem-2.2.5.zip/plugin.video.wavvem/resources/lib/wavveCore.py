__author__="NightRain"
ezjMGVLWCImXFvarhUgRYsyAnKHiBD=object
ezjMGVLWCImXFvarhUgRYsyAnKHiBf=None
ezjMGVLWCImXFvarhUgRYsyAnKHiBd=False
ezjMGVLWCImXFvarhUgRYsyAnKHiBw=True
ezjMGVLWCImXFvarhUgRYsyAnKHiTP=range
ezjMGVLWCImXFvarhUgRYsyAnKHiTu=str
ezjMGVLWCImXFvarhUgRYsyAnKHiTx=Exception
ezjMGVLWCImXFvarhUgRYsyAnKHiTc=print
ezjMGVLWCImXFvarhUgRYsyAnKHiTB=dict
ezjMGVLWCImXFvarhUgRYsyAnKHiTS=int
ezjMGVLWCImXFvarhUgRYsyAnKHiTJ=len
import urllib
import re
import json
import sys
import requests
import datetime
class ezjMGVLWCImXFvarhUgRYsyAnKHiPu(ezjMGVLWCImXFvarhUgRYsyAnKHiBD):
 def __init__(ezjMGVLWCImXFvarhUgRYsyAnKHiPx):
  ezjMGVLWCImXFvarhUgRYsyAnKHiPx.API_DOMAIN='https://apis.wavve.com'
  ezjMGVLWCImXFvarhUgRYsyAnKHiPx.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  ezjMGVLWCImXFvarhUgRYsyAnKHiPx.CREDENTIAL='none'
  ezjMGVLWCImXFvarhUgRYsyAnKHiPx.DEVICE ='pc'
  ezjMGVLWCImXFvarhUgRYsyAnKHiPx.DRM ='wm'
  ezjMGVLWCImXFvarhUgRYsyAnKHiPx.PARTNER ='pooq'
  ezjMGVLWCImXFvarhUgRYsyAnKHiPx.POOQZONE ='none'
  ezjMGVLWCImXFvarhUgRYsyAnKHiPx.REGION ='kor'
  ezjMGVLWCImXFvarhUgRYsyAnKHiPx.TARGETAGE ='all'
  ezjMGVLWCImXFvarhUgRYsyAnKHiPx.HTTPTAG ='https://'
  ezjMGVLWCImXFvarhUgRYsyAnKHiPx.LIST_LIMIT=30 
  ezjMGVLWCImXFvarhUgRYsyAnKHiPx.EP_LIMIT =30 
  ezjMGVLWCImXFvarhUgRYsyAnKHiPx.MV_LIMIT =24 
  ezjMGVLWCImXFvarhUgRYsyAnKHiPx.SEARCH_LIMIT=20 
  ezjMGVLWCImXFvarhUgRYsyAnKHiPx.guid ='none' 
  ezjMGVLWCImXFvarhUgRYsyAnKHiPx.guidtimestamp='none' 
  ezjMGVLWCImXFvarhUgRYsyAnKHiPx.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  ezjMGVLWCImXFvarhUgRYsyAnKHiPx.DEFAULT_HEADER={'user-agent':ezjMGVLWCImXFvarhUgRYsyAnKHiPx.USER_AGENT}
 def callRequestCookies(ezjMGVLWCImXFvarhUgRYsyAnKHiPx,jobtype,ezjMGVLWCImXFvarhUgRYsyAnKHiPk,payload=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,params=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,headers=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,cookies=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,redirects=ezjMGVLWCImXFvarhUgRYsyAnKHiBd):
  ezjMGVLWCImXFvarhUgRYsyAnKHiPc=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.DEFAULT_HEADER
  if headers:ezjMGVLWCImXFvarhUgRYsyAnKHiPc.update(headers)
  if jobtype=='Get':
   ezjMGVLWCImXFvarhUgRYsyAnKHiPB=requests.get(ezjMGVLWCImXFvarhUgRYsyAnKHiPk,params=params,headers=ezjMGVLWCImXFvarhUgRYsyAnKHiPc,cookies=cookies,allow_redirects=redirects)
  else:
   ezjMGVLWCImXFvarhUgRYsyAnKHiPB=requests.post(ezjMGVLWCImXFvarhUgRYsyAnKHiPk,data=payload,params=params,headers=ezjMGVLWCImXFvarhUgRYsyAnKHiPc,cookies=cookies,allow_redirects=redirects)
  return ezjMGVLWCImXFvarhUgRYsyAnKHiPB
 def SaveCredential(ezjMGVLWCImXFvarhUgRYsyAnKHiPx,ezjMGVLWCImXFvarhUgRYsyAnKHiPT):
  ezjMGVLWCImXFvarhUgRYsyAnKHiPx.CREDENTIAL=ezjMGVLWCImXFvarhUgRYsyAnKHiPT
 def LoadCredential(ezjMGVLWCImXFvarhUgRYsyAnKHiPx):
  return ezjMGVLWCImXFvarhUgRYsyAnKHiPx.CREDENTIAL
 def GetDefaultParams(ezjMGVLWCImXFvarhUgRYsyAnKHiPx,login=ezjMGVLWCImXFvarhUgRYsyAnKHiBw):
  ezjMGVLWCImXFvarhUgRYsyAnKHiPS={'apikey':ezjMGVLWCImXFvarhUgRYsyAnKHiPx.APIKEY,'credential':ezjMGVLWCImXFvarhUgRYsyAnKHiPx.CREDENTIAL if login else 'none','device':ezjMGVLWCImXFvarhUgRYsyAnKHiPx.DEVICE,'drm':ezjMGVLWCImXFvarhUgRYsyAnKHiPx.DRM,'partner':ezjMGVLWCImXFvarhUgRYsyAnKHiPx.PARTNER,'pooqzone':ezjMGVLWCImXFvarhUgRYsyAnKHiPx.POOQZONE,'region':ezjMGVLWCImXFvarhUgRYsyAnKHiPx.REGION,'targetage':ezjMGVLWCImXFvarhUgRYsyAnKHiPx.TARGETAGE}
  return ezjMGVLWCImXFvarhUgRYsyAnKHiPS
 def GetGUID(ezjMGVLWCImXFvarhUgRYsyAnKHiPx,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   ezjMGVLWCImXFvarhUgRYsyAnKHiPJ=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   ezjMGVLWCImXFvarhUgRYsyAnKHiPE=GenerateRandomString(5)
   ezjMGVLWCImXFvarhUgRYsyAnKHiPb=ezjMGVLWCImXFvarhUgRYsyAnKHiPE+media+ezjMGVLWCImXFvarhUgRYsyAnKHiPJ
   return ezjMGVLWCImXFvarhUgRYsyAnKHiPb
  def GenerateRandomString(num):
   from random import randint
   ezjMGVLWCImXFvarhUgRYsyAnKHiPq=""
   for i in ezjMGVLWCImXFvarhUgRYsyAnKHiTP(0,num):
    s=ezjMGVLWCImXFvarhUgRYsyAnKHiTu(randint(1,5))
    ezjMGVLWCImXFvarhUgRYsyAnKHiPq+=s
   return ezjMGVLWCImXFvarhUgRYsyAnKHiPq
  ezjMGVLWCImXFvarhUgRYsyAnKHiPb=GenerateID(guid_str)
  ezjMGVLWCImXFvarhUgRYsyAnKHiPQ=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.GetHash(ezjMGVLWCImXFvarhUgRYsyAnKHiPb)
  if guidType==2:
   ezjMGVLWCImXFvarhUgRYsyAnKHiPQ='%s-%s-%s-%s-%s'%(ezjMGVLWCImXFvarhUgRYsyAnKHiPQ[:8],ezjMGVLWCImXFvarhUgRYsyAnKHiPQ[8:12],ezjMGVLWCImXFvarhUgRYsyAnKHiPQ[12:16],ezjMGVLWCImXFvarhUgRYsyAnKHiPQ[16:20],ezjMGVLWCImXFvarhUgRYsyAnKHiPQ[20:])
  return ezjMGVLWCImXFvarhUgRYsyAnKHiPQ
 def GetHash(ezjMGVLWCImXFvarhUgRYsyAnKHiPx,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return ezjMGVLWCImXFvarhUgRYsyAnKHiTu(m.hexdigest())
 def CheckQuality(ezjMGVLWCImXFvarhUgRYsyAnKHiPx,sel_qt,qt_list):
  ezjMGVLWCImXFvarhUgRYsyAnKHiPo=0
  for ezjMGVLWCImXFvarhUgRYsyAnKHiPp in qt_list:
   if sel_qt>=ezjMGVLWCImXFvarhUgRYsyAnKHiPp:return ezjMGVLWCImXFvarhUgRYsyAnKHiPp
   ezjMGVLWCImXFvarhUgRYsyAnKHiPo=ezjMGVLWCImXFvarhUgRYsyAnKHiPp
  return ezjMGVLWCImXFvarhUgRYsyAnKHiPo
 def Get_Now_Datetime(ezjMGVLWCImXFvarhUgRYsyAnKHiPx):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(ezjMGVLWCImXFvarhUgRYsyAnKHiPx,in_text):
  ezjMGVLWCImXFvarhUgRYsyAnKHiPl=in_text.replace('&lt;','<').replace('&gt;','>')
  ezjMGVLWCImXFvarhUgRYsyAnKHiPl=ezjMGVLWCImXFvarhUgRYsyAnKHiPl.replace('$O$','')
  ezjMGVLWCImXFvarhUgRYsyAnKHiPl=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',ezjMGVLWCImXFvarhUgRYsyAnKHiPl)
  ezjMGVLWCImXFvarhUgRYsyAnKHiPl=ezjMGVLWCImXFvarhUgRYsyAnKHiPl.lstrip('#')
  return ezjMGVLWCImXFvarhUgRYsyAnKHiPl
 def GetCredential(ezjMGVLWCImXFvarhUgRYsyAnKHiPx,user_id,user_pw,user_pf):
  ezjMGVLWCImXFvarhUgRYsyAnKHiPN=ezjMGVLWCImXFvarhUgRYsyAnKHiBd
  try:
   ezjMGVLWCImXFvarhUgRYsyAnKHiPk=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.API_DOMAIN+ '/login'
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.GetDefaultParams()
   ezjMGVLWCImXFvarhUgRYsyAnKHiPt={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   ezjMGVLWCImXFvarhUgRYsyAnKHiPD=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.callRequestCookies('Post',ezjMGVLWCImXFvarhUgRYsyAnKHiPk,payload=ezjMGVLWCImXFvarhUgRYsyAnKHiPt,params=ezjMGVLWCImXFvarhUgRYsyAnKHiPS,headers=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,cookies=ezjMGVLWCImXFvarhUgRYsyAnKHiBf)
   ezjMGVLWCImXFvarhUgRYsyAnKHiPf=json.loads(ezjMGVLWCImXFvarhUgRYsyAnKHiPD.text)
   ezjMGVLWCImXFvarhUgRYsyAnKHiPT=ezjMGVLWCImXFvarhUgRYsyAnKHiPf['credential']
   if user_pf!=0:
    ezjMGVLWCImXFvarhUgRYsyAnKHiPt={'id':ezjMGVLWCImXFvarhUgRYsyAnKHiPT,'password':'','profile':ezjMGVLWCImXFvarhUgRYsyAnKHiTu(user_pf),'pushid':'','type':'credential'}
    ezjMGVLWCImXFvarhUgRYsyAnKHiPS['credential']=ezjMGVLWCImXFvarhUgRYsyAnKHiPT 
    ezjMGVLWCImXFvarhUgRYsyAnKHiPD=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.callRequestCookies('Post',ezjMGVLWCImXFvarhUgRYsyAnKHiPk,payload=ezjMGVLWCImXFvarhUgRYsyAnKHiPt,params=ezjMGVLWCImXFvarhUgRYsyAnKHiPS,headers=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,cookies=ezjMGVLWCImXFvarhUgRYsyAnKHiBf)
    ezjMGVLWCImXFvarhUgRYsyAnKHiPf=json.loads(ezjMGVLWCImXFvarhUgRYsyAnKHiPD.text)
    ezjMGVLWCImXFvarhUgRYsyAnKHiPT=ezjMGVLWCImXFvarhUgRYsyAnKHiPf['credential']
   if ezjMGVLWCImXFvarhUgRYsyAnKHiPT:ezjMGVLWCImXFvarhUgRYsyAnKHiPN=ezjMGVLWCImXFvarhUgRYsyAnKHiBw
  except ezjMGVLWCImXFvarhUgRYsyAnKHiTx as exception:
   ezjMGVLWCImXFvarhUgRYsyAnKHiTc(exception)
   ezjMGVLWCImXFvarhUgRYsyAnKHiPT='none' 
  ezjMGVLWCImXFvarhUgRYsyAnKHiPx.SaveCredential(ezjMGVLWCImXFvarhUgRYsyAnKHiPT)
  return ezjMGVLWCImXFvarhUgRYsyAnKHiPN
 def GetIssue(ezjMGVLWCImXFvarhUgRYsyAnKHiPx):
  ezjMGVLWCImXFvarhUgRYsyAnKHiPd=ezjMGVLWCImXFvarhUgRYsyAnKHiBd
  try:
   ezjMGVLWCImXFvarhUgRYsyAnKHiPk=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.API_DOMAIN+'/guid/issue'
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.GetDefaultParams()
   ezjMGVLWCImXFvarhUgRYsyAnKHiPD=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.callRequestCookies('Get',ezjMGVLWCImXFvarhUgRYsyAnKHiPk,payload=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,params=ezjMGVLWCImXFvarhUgRYsyAnKHiPS,headers=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,cookies=ezjMGVLWCImXFvarhUgRYsyAnKHiBf)
   ezjMGVLWCImXFvarhUgRYsyAnKHiPf=json.loads(ezjMGVLWCImXFvarhUgRYsyAnKHiPD.text)
   ezjMGVLWCImXFvarhUgRYsyAnKHiPw=ezjMGVLWCImXFvarhUgRYsyAnKHiPf['guid']
   ezjMGVLWCImXFvarhUgRYsyAnKHiuP=ezjMGVLWCImXFvarhUgRYsyAnKHiPf['guidtimestamp']
   if ezjMGVLWCImXFvarhUgRYsyAnKHiPw:ezjMGVLWCImXFvarhUgRYsyAnKHiPd=ezjMGVLWCImXFvarhUgRYsyAnKHiBw
  except ezjMGVLWCImXFvarhUgRYsyAnKHiTx as exception:
   ezjMGVLWCImXFvarhUgRYsyAnKHiTc(exception)
   ezjMGVLWCImXFvarhUgRYsyAnKHiPw='none'
   ezjMGVLWCImXFvarhUgRYsyAnKHiuP='none' 
  ezjMGVLWCImXFvarhUgRYsyAnKHiPx.guid=ezjMGVLWCImXFvarhUgRYsyAnKHiPw
  ezjMGVLWCImXFvarhUgRYsyAnKHiPx.guidtimestamp=ezjMGVLWCImXFvarhUgRYsyAnKHiuP
  return ezjMGVLWCImXFvarhUgRYsyAnKHiPd
 def Baseapi_Parse(ezjMGVLWCImXFvarhUgRYsyAnKHiPx,ezjMGVLWCImXFvarhUgRYsyAnKHiuT):
  try:
   ezjMGVLWCImXFvarhUgRYsyAnKHiux =urllib.parse.urlsplit(ezjMGVLWCImXFvarhUgRYsyAnKHiuT)
   if ezjMGVLWCImXFvarhUgRYsyAnKHiux.netloc=='':
    ezjMGVLWCImXFvarhUgRYsyAnKHiPk=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.HTTPTAG+ezjMGVLWCImXFvarhUgRYsyAnKHiux.netloc+ezjMGVLWCImXFvarhUgRYsyAnKHiux.path
   else:
    ezjMGVLWCImXFvarhUgRYsyAnKHiPk=ezjMGVLWCImXFvarhUgRYsyAnKHiux.scheme+'://'+ezjMGVLWCImXFvarhUgRYsyAnKHiux.netloc+ezjMGVLWCImXFvarhUgRYsyAnKHiux.path
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS=ezjMGVLWCImXFvarhUgRYsyAnKHiTB(urllib.parse.parse_qsl(ezjMGVLWCImXFvarhUgRYsyAnKHiux.query))
  except:
   ezjMGVLWCImXFvarhUgRYsyAnKHiTc(exception)
   return '',{}
  return ezjMGVLWCImXFvarhUgRYsyAnKHiPk,ezjMGVLWCImXFvarhUgRYsyAnKHiPS
 def GetSupermultiUrl(ezjMGVLWCImXFvarhUgRYsyAnKHiPx,sCode,sIndex='0'):
  try:
   ezjMGVLWCImXFvarhUgRYsyAnKHiPk=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.API_DOMAIN+'/cf/supermultisections/'+sCode
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.GetDefaultParams(login=ezjMGVLWCImXFvarhUgRYsyAnKHiBd)
   ezjMGVLWCImXFvarhUgRYsyAnKHiPD=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.callRequestCookies('Get',ezjMGVLWCImXFvarhUgRYsyAnKHiPk,payload=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,params=ezjMGVLWCImXFvarhUgRYsyAnKHiPS,headers=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,cookies=ezjMGVLWCImXFvarhUgRYsyAnKHiBf)
   ezjMGVLWCImXFvarhUgRYsyAnKHiPf=json.loads(ezjMGVLWCImXFvarhUgRYsyAnKHiPD.text)
   ezjMGVLWCImXFvarhUgRYsyAnKHiuc=ezjMGVLWCImXFvarhUgRYsyAnKHiPf['multisectionlist'][ezjMGVLWCImXFvarhUgRYsyAnKHiTS(sIndex)]['eventlist'][1]['url']
  except ezjMGVLWCImXFvarhUgRYsyAnKHiTx as exception:
   ezjMGVLWCImXFvarhUgRYsyAnKHiTc(exception)
   return ''
  return ezjMGVLWCImXFvarhUgRYsyAnKHiuc
 def Get_LiveCatagory_List(ezjMGVLWCImXFvarhUgRYsyAnKHiPx,sCode,sIndex='0'):
  ezjMGVLWCImXFvarhUgRYsyAnKHiuB=[]
  ezjMGVLWCImXFvarhUgRYsyAnKHiuT =ezjMGVLWCImXFvarhUgRYsyAnKHiPx.GetSupermultiUrl(sCode,sIndex)
  (ezjMGVLWCImXFvarhUgRYsyAnKHiPk,ezjMGVLWCImXFvarhUgRYsyAnKHiPS)=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.Baseapi_Parse(ezjMGVLWCImXFvarhUgRYsyAnKHiuT)
  if ezjMGVLWCImXFvarhUgRYsyAnKHiPk=='':return ezjMGVLWCImXFvarhUgRYsyAnKHiuB,''
  try:
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS.update(ezjMGVLWCImXFvarhUgRYsyAnKHiPx.GetDefaultParams(login=ezjMGVLWCImXFvarhUgRYsyAnKHiBd))
   ezjMGVLWCImXFvarhUgRYsyAnKHiPD=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.callRequestCookies('Get',ezjMGVLWCImXFvarhUgRYsyAnKHiPk,payload=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,params=ezjMGVLWCImXFvarhUgRYsyAnKHiPS,headers=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,cookies=ezjMGVLWCImXFvarhUgRYsyAnKHiBf)
   ezjMGVLWCImXFvarhUgRYsyAnKHiPf=json.loads(ezjMGVLWCImXFvarhUgRYsyAnKHiPD.text)
   if not('filter_item_list' in ezjMGVLWCImXFvarhUgRYsyAnKHiPf['filter']['filterlist'][0]):return[],''
   ezjMGVLWCImXFvarhUgRYsyAnKHiuJ=ezjMGVLWCImXFvarhUgRYsyAnKHiPf['filter']['filterlist'][0]['filter_item_list']
   for ezjMGVLWCImXFvarhUgRYsyAnKHiuE in ezjMGVLWCImXFvarhUgRYsyAnKHiuJ:
    ezjMGVLWCImXFvarhUgRYsyAnKHiub={'title':ezjMGVLWCImXFvarhUgRYsyAnKHiuE['title'],'genre':ezjMGVLWCImXFvarhUgRYsyAnKHiuE['api_parameters'][ezjMGVLWCImXFvarhUgRYsyAnKHiuE['api_parameters'].index('=')+1:]}
    ezjMGVLWCImXFvarhUgRYsyAnKHiuB.append(ezjMGVLWCImXFvarhUgRYsyAnKHiub)
  except ezjMGVLWCImXFvarhUgRYsyAnKHiTx as exception:
   ezjMGVLWCImXFvarhUgRYsyAnKHiTc(exception)
   return[],''
  return ezjMGVLWCImXFvarhUgRYsyAnKHiuB,ezjMGVLWCImXFvarhUgRYsyAnKHiuT
 def Get_MainCatagory_List(ezjMGVLWCImXFvarhUgRYsyAnKHiPx,sCode,sIndex='0'):
  ezjMGVLWCImXFvarhUgRYsyAnKHiuB=[]
  ezjMGVLWCImXFvarhUgRYsyAnKHiuT =ezjMGVLWCImXFvarhUgRYsyAnKHiPx.GetSupermultiUrl(sCode,sIndex)
  (ezjMGVLWCImXFvarhUgRYsyAnKHiPk,ezjMGVLWCImXFvarhUgRYsyAnKHiPS)=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.Baseapi_Parse(ezjMGVLWCImXFvarhUgRYsyAnKHiuT)
  if ezjMGVLWCImXFvarhUgRYsyAnKHiPk=='':return ezjMGVLWCImXFvarhUgRYsyAnKHiuB
  try:
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS.update(ezjMGVLWCImXFvarhUgRYsyAnKHiPx.GetDefaultParams(login=ezjMGVLWCImXFvarhUgRYsyAnKHiBd))
   ezjMGVLWCImXFvarhUgRYsyAnKHiPD=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.callRequestCookies('Get',ezjMGVLWCImXFvarhUgRYsyAnKHiPk,payload=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,params=ezjMGVLWCImXFvarhUgRYsyAnKHiPS,headers=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,cookies=ezjMGVLWCImXFvarhUgRYsyAnKHiBf)
   ezjMGVLWCImXFvarhUgRYsyAnKHiPf=json.loads(ezjMGVLWCImXFvarhUgRYsyAnKHiPD.text)
   if not('celllist' in ezjMGVLWCImXFvarhUgRYsyAnKHiPf['band']):return[]
   ezjMGVLWCImXFvarhUgRYsyAnKHiuJ=ezjMGVLWCImXFvarhUgRYsyAnKHiPf['band']['celllist']
   for ezjMGVLWCImXFvarhUgRYsyAnKHiuE in ezjMGVLWCImXFvarhUgRYsyAnKHiuJ:
    ezjMGVLWCImXFvarhUgRYsyAnKHiuq =ezjMGVLWCImXFvarhUgRYsyAnKHiuE['event_list'][1]['url']
    (ezjMGVLWCImXFvarhUgRYsyAnKHiuQ,ezjMGVLWCImXFvarhUgRYsyAnKHiuo)=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.Baseapi_Parse(ezjMGVLWCImXFvarhUgRYsyAnKHiuq)
    ezjMGVLWCImXFvarhUgRYsyAnKHiub={'title':ezjMGVLWCImXFvarhUgRYsyAnKHiuE['title_list'][0]['text'],'suburl':ezjMGVLWCImXFvarhUgRYsyAnKHiuQ,'subapi':ezjMGVLWCImXFvarhUgRYsyAnKHiuo.get('api'),'subtype':'catagory' if ezjMGVLWCImXFvarhUgRYsyAnKHiuo else 'supersection'}
    ezjMGVLWCImXFvarhUgRYsyAnKHiuB.append(ezjMGVLWCImXFvarhUgRYsyAnKHiub)
  except ezjMGVLWCImXFvarhUgRYsyAnKHiTx as exception:
   ezjMGVLWCImXFvarhUgRYsyAnKHiTc(exception)
   return[]
  return ezjMGVLWCImXFvarhUgRYsyAnKHiuB
 def Get_SuperMultiSection_List(ezjMGVLWCImXFvarhUgRYsyAnKHiPx,subapi_text):
  ezjMGVLWCImXFvarhUgRYsyAnKHiuB=[]
  ezjMGVLWCImXFvarhUgRYsyAnKHiPS={}
  try:
   ezjMGVLWCImXFvarhUgRYsyAnKHiux =urllib.parse.urlsplit(subapi_text)
   if ezjMGVLWCImXFvarhUgRYsyAnKHiux.path.find('apis.wavve.com')>=0: 
    ezjMGVLWCImXFvarhUgRYsyAnKHiPk=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.HTTPTAG+ezjMGVLWCImXFvarhUgRYsyAnKHiux.path 
    ezjMGVLWCImXFvarhUgRYsyAnKHiPS=ezjMGVLWCImXFvarhUgRYsyAnKHiTB(urllib.parse.parse_qsl(ezjMGVLWCImXFvarhUgRYsyAnKHiux.query))
   else:
    ezjMGVLWCImXFvarhUgRYsyAnKHiPk=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.API_DOMAIN+'/cf'+ezjMGVLWCImXFvarhUgRYsyAnKHiux.path 
   ezjMGVLWCImXFvarhUgRYsyAnKHiPk=ezjMGVLWCImXFvarhUgRYsyAnKHiPk.replace('supermultisection/','supermultisections/')
  except ezjMGVLWCImXFvarhUgRYsyAnKHiTx as exception:
   ezjMGVLWCImXFvarhUgRYsyAnKHiTc(exception)
   return[]
  try:
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS.update(ezjMGVLWCImXFvarhUgRYsyAnKHiPx.GetDefaultParams(login=ezjMGVLWCImXFvarhUgRYsyAnKHiBd))
   ezjMGVLWCImXFvarhUgRYsyAnKHiPD=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.callRequestCookies('Get',ezjMGVLWCImXFvarhUgRYsyAnKHiPk,payload=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,params=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,headers=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,cookies=ezjMGVLWCImXFvarhUgRYsyAnKHiBf)
   ezjMGVLWCImXFvarhUgRYsyAnKHiPf=json.loads(ezjMGVLWCImXFvarhUgRYsyAnKHiPD.text)
   if not('multisectionlist' in ezjMGVLWCImXFvarhUgRYsyAnKHiPf):return[]
   ezjMGVLWCImXFvarhUgRYsyAnKHiuJ=ezjMGVLWCImXFvarhUgRYsyAnKHiPf['multisectionlist']
   for ezjMGVLWCImXFvarhUgRYsyAnKHiuE in ezjMGVLWCImXFvarhUgRYsyAnKHiuJ:
    ezjMGVLWCImXFvarhUgRYsyAnKHiup=ezjMGVLWCImXFvarhUgRYsyAnKHiuE['title']
    if ezjMGVLWCImXFvarhUgRYsyAnKHiTJ(ezjMGVLWCImXFvarhUgRYsyAnKHiup)==0:continue
    if ezjMGVLWCImXFvarhUgRYsyAnKHiup=='minor':continue
    if re.search(u'베너',ezjMGVLWCImXFvarhUgRYsyAnKHiup):continue
    if re.search(u'배너',ezjMGVLWCImXFvarhUgRYsyAnKHiup):continue 
    if ezjMGVLWCImXFvarhUgRYsyAnKHiTJ(ezjMGVLWCImXFvarhUgRYsyAnKHiuE['eventlist'])>=3:
     ezjMGVLWCImXFvarhUgRYsyAnKHiuo =ezjMGVLWCImXFvarhUgRYsyAnKHiuE['eventlist'][2]['url']
    else:
     ezjMGVLWCImXFvarhUgRYsyAnKHiuo =ezjMGVLWCImXFvarhUgRYsyAnKHiuE['eventlist'][1]['url']
    ezjMGVLWCImXFvarhUgRYsyAnKHiuO=ezjMGVLWCImXFvarhUgRYsyAnKHiuE['cell_type']
    if ezjMGVLWCImXFvarhUgRYsyAnKHiuO=='band_2':
     if ezjMGVLWCImXFvarhUgRYsyAnKHiuo.find('channellist=')>=0:
      ezjMGVLWCImXFvarhUgRYsyAnKHiuO='band_live'
    ezjMGVLWCImXFvarhUgRYsyAnKHiub={'title':ezjMGVLWCImXFvarhUgRYsyAnKHiPx.Get_ChangeText(ezjMGVLWCImXFvarhUgRYsyAnKHiup),'subapi':ezjMGVLWCImXFvarhUgRYsyAnKHiuo,'cell_type':ezjMGVLWCImXFvarhUgRYsyAnKHiuO}
    ezjMGVLWCImXFvarhUgRYsyAnKHiuB.append(ezjMGVLWCImXFvarhUgRYsyAnKHiub)
  except ezjMGVLWCImXFvarhUgRYsyAnKHiTx as exception:
   ezjMGVLWCImXFvarhUgRYsyAnKHiTc(exception)
   return[]
  return ezjMGVLWCImXFvarhUgRYsyAnKHiuB
 def Get_BandLiveSection_List(ezjMGVLWCImXFvarhUgRYsyAnKHiPx,ezjMGVLWCImXFvarhUgRYsyAnKHiuT,page_int=1):
  ezjMGVLWCImXFvarhUgRYsyAnKHiul=[]
  ezjMGVLWCImXFvarhUgRYsyAnKHiuN=ezjMGVLWCImXFvarhUgRYsyAnKHiuw=1
  ezjMGVLWCImXFvarhUgRYsyAnKHiuk=ezjMGVLWCImXFvarhUgRYsyAnKHiBd
  try:
   (ezjMGVLWCImXFvarhUgRYsyAnKHiPk,ezjMGVLWCImXFvarhUgRYsyAnKHiPS)=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.Baseapi_Parse(ezjMGVLWCImXFvarhUgRYsyAnKHiuT)
  except ezjMGVLWCImXFvarhUgRYsyAnKHiTx as exception:
   ezjMGVLWCImXFvarhUgRYsyAnKHiTc(exception)
   return[],ezjMGVLWCImXFvarhUgRYsyAnKHiBd
  try:
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS['limit']=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.LIST_LIMIT
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS['offset']=ezjMGVLWCImXFvarhUgRYsyAnKHiTu((page_int-1)*ezjMGVLWCImXFvarhUgRYsyAnKHiPx.LIST_LIMIT)
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS.update(ezjMGVLWCImXFvarhUgRYsyAnKHiPx.GetDefaultParams(login=ezjMGVLWCImXFvarhUgRYsyAnKHiBd))
   ezjMGVLWCImXFvarhUgRYsyAnKHiPD=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.callRequestCookies('Get',ezjMGVLWCImXFvarhUgRYsyAnKHiPk,payload=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,params=ezjMGVLWCImXFvarhUgRYsyAnKHiPS,headers=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,cookies=ezjMGVLWCImXFvarhUgRYsyAnKHiBf)
   ezjMGVLWCImXFvarhUgRYsyAnKHiPf=json.loads(ezjMGVLWCImXFvarhUgRYsyAnKHiPD.text)
   if not('celllist' in ezjMGVLWCImXFvarhUgRYsyAnKHiPf['cell_toplist']):return[],ezjMGVLWCImXFvarhUgRYsyAnKHiBd
   ezjMGVLWCImXFvarhUgRYsyAnKHiuJ=ezjMGVLWCImXFvarhUgRYsyAnKHiPf['cell_toplist']['celllist']
   for ezjMGVLWCImXFvarhUgRYsyAnKHiuE in ezjMGVLWCImXFvarhUgRYsyAnKHiuJ:
    ezjMGVLWCImXFvarhUgRYsyAnKHiut =ezjMGVLWCImXFvarhUgRYsyAnKHiuE['event_list'][1]['url']
    ezjMGVLWCImXFvarhUgRYsyAnKHiuD=urllib.parse.urlsplit(ezjMGVLWCImXFvarhUgRYsyAnKHiut).query
    ezjMGVLWCImXFvarhUgRYsyAnKHiuD=ezjMGVLWCImXFvarhUgRYsyAnKHiTB(urllib.parse.parse_qsl(ezjMGVLWCImXFvarhUgRYsyAnKHiuD))
    ezjMGVLWCImXFvarhUgRYsyAnKHiuf='channelid'
    ezjMGVLWCImXFvarhUgRYsyAnKHiud=ezjMGVLWCImXFvarhUgRYsyAnKHiuD[ezjMGVLWCImXFvarhUgRYsyAnKHiuf]
    ezjMGVLWCImXFvarhUgRYsyAnKHiub={'studio':ezjMGVLWCImXFvarhUgRYsyAnKHiuE['title_list'][0]['text'],'tvshowtitle':ezjMGVLWCImXFvarhUgRYsyAnKHiPx.Get_ChangeText(ezjMGVLWCImXFvarhUgRYsyAnKHiuE['title_list'][1]['text']),'channelid':ezjMGVLWCImXFvarhUgRYsyAnKHiud,'age':ezjMGVLWCImXFvarhUgRYsyAnKHiuE.get('age'),'thumbnail':'https://%s'%ezjMGVLWCImXFvarhUgRYsyAnKHiuE.get('thumbnail')}
    ezjMGVLWCImXFvarhUgRYsyAnKHiul.append(ezjMGVLWCImXFvarhUgRYsyAnKHiub)
   ezjMGVLWCImXFvarhUgRYsyAnKHiuN=ezjMGVLWCImXFvarhUgRYsyAnKHiTS(ezjMGVLWCImXFvarhUgRYsyAnKHiPf['cell_toplist']['pagecount'])
   if ezjMGVLWCImXFvarhUgRYsyAnKHiPf['cell_toplist']['count']:ezjMGVLWCImXFvarhUgRYsyAnKHiuw =ezjMGVLWCImXFvarhUgRYsyAnKHiTS(ezjMGVLWCImXFvarhUgRYsyAnKHiPf['cell_toplist']['count'])
   else:ezjMGVLWCImXFvarhUgRYsyAnKHiuw=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.LIST_LIMIT*page_int
   ezjMGVLWCImXFvarhUgRYsyAnKHiuk=ezjMGVLWCImXFvarhUgRYsyAnKHiuN>ezjMGVLWCImXFvarhUgRYsyAnKHiuw
  except ezjMGVLWCImXFvarhUgRYsyAnKHiTx as exception:
   ezjMGVLWCImXFvarhUgRYsyAnKHiTc(exception)
   return[],ezjMGVLWCImXFvarhUgRYsyAnKHiBd
  return ezjMGVLWCImXFvarhUgRYsyAnKHiul,ezjMGVLWCImXFvarhUgRYsyAnKHiuk
 def Get_Band2Section_List(ezjMGVLWCImXFvarhUgRYsyAnKHiPx,ezjMGVLWCImXFvarhUgRYsyAnKHiuT,page_int=1):
  ezjMGVLWCImXFvarhUgRYsyAnKHixP=[]
  ezjMGVLWCImXFvarhUgRYsyAnKHiuN=ezjMGVLWCImXFvarhUgRYsyAnKHiuw=1
  ezjMGVLWCImXFvarhUgRYsyAnKHiuk=ezjMGVLWCImXFvarhUgRYsyAnKHiBd
  try:
   (ezjMGVLWCImXFvarhUgRYsyAnKHiPk,ezjMGVLWCImXFvarhUgRYsyAnKHiPS)=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.Baseapi_Parse(ezjMGVLWCImXFvarhUgRYsyAnKHiuT)
  except ezjMGVLWCImXFvarhUgRYsyAnKHiTx as exception:
   ezjMGVLWCImXFvarhUgRYsyAnKHiTc(exception)
   return[],ezjMGVLWCImXFvarhUgRYsyAnKHiBd
  try:
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS['came'] ='BandView'
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS['limit']=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.LIST_LIMIT
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS['offset']=ezjMGVLWCImXFvarhUgRYsyAnKHiTu((page_int-1)*ezjMGVLWCImXFvarhUgRYsyAnKHiPx.LIST_LIMIT)
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS.update(ezjMGVLWCImXFvarhUgRYsyAnKHiPx.GetDefaultParams(login=ezjMGVLWCImXFvarhUgRYsyAnKHiBd))
   ezjMGVLWCImXFvarhUgRYsyAnKHiPD=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.callRequestCookies('Get',ezjMGVLWCImXFvarhUgRYsyAnKHiPk,payload=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,params=ezjMGVLWCImXFvarhUgRYsyAnKHiPS,headers=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,cookies=ezjMGVLWCImXFvarhUgRYsyAnKHiBf)
   ezjMGVLWCImXFvarhUgRYsyAnKHiPf=json.loads(ezjMGVLWCImXFvarhUgRYsyAnKHiPD.text)
   if not('celllist' in ezjMGVLWCImXFvarhUgRYsyAnKHiPf['cell_toplist']):return[],ezjMGVLWCImXFvarhUgRYsyAnKHiBd
   ezjMGVLWCImXFvarhUgRYsyAnKHiuJ=ezjMGVLWCImXFvarhUgRYsyAnKHiPf['cell_toplist']['celllist']
   for ezjMGVLWCImXFvarhUgRYsyAnKHiuE in ezjMGVLWCImXFvarhUgRYsyAnKHiuJ:
    ezjMGVLWCImXFvarhUgRYsyAnKHiut =ezjMGVLWCImXFvarhUgRYsyAnKHiuE['event_list'][1]['url']
    ezjMGVLWCImXFvarhUgRYsyAnKHiuD=urllib.parse.urlsplit(ezjMGVLWCImXFvarhUgRYsyAnKHiut).query
    ezjMGVLWCImXFvarhUgRYsyAnKHiuD=ezjMGVLWCImXFvarhUgRYsyAnKHiTB(urllib.parse.parse_qsl(ezjMGVLWCImXFvarhUgRYsyAnKHiuD))
    ezjMGVLWCImXFvarhUgRYsyAnKHiuf='contentid'
    ezjMGVLWCImXFvarhUgRYsyAnKHiud=ezjMGVLWCImXFvarhUgRYsyAnKHiuD[ezjMGVLWCImXFvarhUgRYsyAnKHiuf]
    ezjMGVLWCImXFvarhUgRYsyAnKHiub={'programtitle':ezjMGVLWCImXFvarhUgRYsyAnKHiuE['title_list'][0]['text'],'episodetitle':ezjMGVLWCImXFvarhUgRYsyAnKHiPx.Get_ChangeText(ezjMGVLWCImXFvarhUgRYsyAnKHiuE['title_list'][1]['text']),'age':ezjMGVLWCImXFvarhUgRYsyAnKHiuE.get('age'),'thumbnail':ezjMGVLWCImXFvarhUgRYsyAnKHiPx.HTTPTAG+ezjMGVLWCImXFvarhUgRYsyAnKHiuE.get('thumbnail'),'vidtype':ezjMGVLWCImXFvarhUgRYsyAnKHiuf,'videoid':ezjMGVLWCImXFvarhUgRYsyAnKHiud}
    ezjMGVLWCImXFvarhUgRYsyAnKHixP.append(ezjMGVLWCImXFvarhUgRYsyAnKHiub)
   ezjMGVLWCImXFvarhUgRYsyAnKHiuN=ezjMGVLWCImXFvarhUgRYsyAnKHiTS(ezjMGVLWCImXFvarhUgRYsyAnKHiPf['cell_toplist']['pagecount'])
   if ezjMGVLWCImXFvarhUgRYsyAnKHiPf['cell_toplist']['count']:ezjMGVLWCImXFvarhUgRYsyAnKHiuw =ezjMGVLWCImXFvarhUgRYsyAnKHiTS(ezjMGVLWCImXFvarhUgRYsyAnKHiPf['cell_toplist']['count'])
   else:ezjMGVLWCImXFvarhUgRYsyAnKHiuw=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.LIST_LIMIT*page_int
   ezjMGVLWCImXFvarhUgRYsyAnKHiuk=ezjMGVLWCImXFvarhUgRYsyAnKHiuN>ezjMGVLWCImXFvarhUgRYsyAnKHiuw
  except ezjMGVLWCImXFvarhUgRYsyAnKHiTx as exception:
   ezjMGVLWCImXFvarhUgRYsyAnKHiTc(exception)
   return[],ezjMGVLWCImXFvarhUgRYsyAnKHiBd
  return ezjMGVLWCImXFvarhUgRYsyAnKHixP,ezjMGVLWCImXFvarhUgRYsyAnKHiuk
 def Get_Program_List(ezjMGVLWCImXFvarhUgRYsyAnKHiPx,ezjMGVLWCImXFvarhUgRYsyAnKHiuT,page_int=1,orderby='-'):
  ezjMGVLWCImXFvarhUgRYsyAnKHixu=[]
  ezjMGVLWCImXFvarhUgRYsyAnKHiuN=ezjMGVLWCImXFvarhUgRYsyAnKHiuw=1
  ezjMGVLWCImXFvarhUgRYsyAnKHiuk=ezjMGVLWCImXFvarhUgRYsyAnKHiBd
  (ezjMGVLWCImXFvarhUgRYsyAnKHiPk,ezjMGVLWCImXFvarhUgRYsyAnKHiPS)=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.Baseapi_Parse(ezjMGVLWCImXFvarhUgRYsyAnKHiuT)
  if ezjMGVLWCImXFvarhUgRYsyAnKHiPk=='':return ezjMGVLWCImXFvarhUgRYsyAnKHixu,ezjMGVLWCImXFvarhUgRYsyAnKHiuk
  try:
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS['limit'] =ezjMGVLWCImXFvarhUgRYsyAnKHiPx.LIST_LIMIT
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS['offset']=ezjMGVLWCImXFvarhUgRYsyAnKHiTu((page_int-1)*ezjMGVLWCImXFvarhUgRYsyAnKHiPx.LIST_LIMIT)
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS['page'] =ezjMGVLWCImXFvarhUgRYsyAnKHiTu(page_int)
   if ezjMGVLWCImXFvarhUgRYsyAnKHiPS.get('orderby')!='' and ezjMGVLWCImXFvarhUgRYsyAnKHiPS.get('orderby')!='regdatefirst' and orderby!='-':
    ezjMGVLWCImXFvarhUgRYsyAnKHiPS['orderby']=orderby 
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS.update(ezjMGVLWCImXFvarhUgRYsyAnKHiPx.GetDefaultParams(login=ezjMGVLWCImXFvarhUgRYsyAnKHiBd))
   ezjMGVLWCImXFvarhUgRYsyAnKHiPD=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.callRequestCookies('Get',ezjMGVLWCImXFvarhUgRYsyAnKHiPk,payload=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,params=ezjMGVLWCImXFvarhUgRYsyAnKHiPS,headers=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,cookies=ezjMGVLWCImXFvarhUgRYsyAnKHiBf)
   ezjMGVLWCImXFvarhUgRYsyAnKHiPf=json.loads(ezjMGVLWCImXFvarhUgRYsyAnKHiPD.text)
   if ezjMGVLWCImXFvarhUgRYsyAnKHiuT.find('instantplay')>=0:
    if not('celllist' in ezjMGVLWCImXFvarhUgRYsyAnKHiPf['band']):return ezjMGVLWCImXFvarhUgRYsyAnKHixu,ezjMGVLWCImXFvarhUgRYsyAnKHiuk
    ezjMGVLWCImXFvarhUgRYsyAnKHiuJ=ezjMGVLWCImXFvarhUgRYsyAnKHiPf['band']['celllist']
   else:
    if not('celllist' in ezjMGVLWCImXFvarhUgRYsyAnKHiPf['cell_toplist']):return ezjMGVLWCImXFvarhUgRYsyAnKHixu,ezjMGVLWCImXFvarhUgRYsyAnKHiuk
    ezjMGVLWCImXFvarhUgRYsyAnKHiuJ=ezjMGVLWCImXFvarhUgRYsyAnKHiPf['cell_toplist']['celllist']
   for ezjMGVLWCImXFvarhUgRYsyAnKHiuE in ezjMGVLWCImXFvarhUgRYsyAnKHiuJ:
    for ezjMGVLWCImXFvarhUgRYsyAnKHixc in ezjMGVLWCImXFvarhUgRYsyAnKHiuE['event_list']:
     if ezjMGVLWCImXFvarhUgRYsyAnKHixc.get('type')=='on-navigation':
      ezjMGVLWCImXFvarhUgRYsyAnKHiut =ezjMGVLWCImXFvarhUgRYsyAnKHixc['url']
    ezjMGVLWCImXFvarhUgRYsyAnKHiuD=urllib.parse.urlsplit(ezjMGVLWCImXFvarhUgRYsyAnKHiut).query
    ezjMGVLWCImXFvarhUgRYsyAnKHiuf=ezjMGVLWCImXFvarhUgRYsyAnKHiuD[0:ezjMGVLWCImXFvarhUgRYsyAnKHiuD.find('=')]
    ezjMGVLWCImXFvarhUgRYsyAnKHiud=ezjMGVLWCImXFvarhUgRYsyAnKHiuD[ezjMGVLWCImXFvarhUgRYsyAnKHiuD.find('=')+1:]
    ezjMGVLWCImXFvarhUgRYsyAnKHiub={'title':ezjMGVLWCImXFvarhUgRYsyAnKHiuE['title_list'][0]['text'],'age':ezjMGVLWCImXFvarhUgRYsyAnKHiuE['age'],'thumbnail':'https://%s'%ezjMGVLWCImXFvarhUgRYsyAnKHiuE.get('thumbnail'),'videoid':ezjMGVLWCImXFvarhUgRYsyAnKHiud,'vidtype':ezjMGVLWCImXFvarhUgRYsyAnKHiuf}
    ezjMGVLWCImXFvarhUgRYsyAnKHixu.append(ezjMGVLWCImXFvarhUgRYsyAnKHiub)
   if ezjMGVLWCImXFvarhUgRYsyAnKHiuT.find('instantplay')<0:
    ezjMGVLWCImXFvarhUgRYsyAnKHiuN=ezjMGVLWCImXFvarhUgRYsyAnKHiTS(ezjMGVLWCImXFvarhUgRYsyAnKHiPf['cell_toplist']['pagecount'])
    if ezjMGVLWCImXFvarhUgRYsyAnKHiPf['cell_toplist']['count']:ezjMGVLWCImXFvarhUgRYsyAnKHiuw =ezjMGVLWCImXFvarhUgRYsyAnKHiTS(ezjMGVLWCImXFvarhUgRYsyAnKHiPf['cell_toplist']['count'])
    else:ezjMGVLWCImXFvarhUgRYsyAnKHiuw=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.LIST_LIMIT*page_int
    ezjMGVLWCImXFvarhUgRYsyAnKHiuk=ezjMGVLWCImXFvarhUgRYsyAnKHiuN>ezjMGVLWCImXFvarhUgRYsyAnKHiuw
  except ezjMGVLWCImXFvarhUgRYsyAnKHiTx as exception:
   ezjMGVLWCImXFvarhUgRYsyAnKHiTc(exception)
   return[],ezjMGVLWCImXFvarhUgRYsyAnKHiBd
  return ezjMGVLWCImXFvarhUgRYsyAnKHixu,ezjMGVLWCImXFvarhUgRYsyAnKHiuk
 def Get_Movie_List(ezjMGVLWCImXFvarhUgRYsyAnKHiPx,ezjMGVLWCImXFvarhUgRYsyAnKHiuT,page_int=1):
  ezjMGVLWCImXFvarhUgRYsyAnKHixB=[]
  ezjMGVLWCImXFvarhUgRYsyAnKHiuN=ezjMGVLWCImXFvarhUgRYsyAnKHiuw=1
  ezjMGVLWCImXFvarhUgRYsyAnKHiuk=ezjMGVLWCImXFvarhUgRYsyAnKHiBd
  (ezjMGVLWCImXFvarhUgRYsyAnKHiPk,ezjMGVLWCImXFvarhUgRYsyAnKHiPS)=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.Baseapi_Parse(ezjMGVLWCImXFvarhUgRYsyAnKHiuT)
  if ezjMGVLWCImXFvarhUgRYsyAnKHiPk=='':return ezjMGVLWCImXFvarhUgRYsyAnKHixB,ezjMGVLWCImXFvarhUgRYsyAnKHiuk
  try:
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS['limit']=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.MV_LIMIT
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS['offset']=ezjMGVLWCImXFvarhUgRYsyAnKHiTu((page_int-1)*ezjMGVLWCImXFvarhUgRYsyAnKHiPx.MV_LIMIT)
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS.update(ezjMGVLWCImXFvarhUgRYsyAnKHiPx.GetDefaultParams(login=ezjMGVLWCImXFvarhUgRYsyAnKHiBd))
   ezjMGVLWCImXFvarhUgRYsyAnKHiPD=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.callRequestCookies('Get',ezjMGVLWCImXFvarhUgRYsyAnKHiPk,payload=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,params=ezjMGVLWCImXFvarhUgRYsyAnKHiPS,headers=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,cookies=ezjMGVLWCImXFvarhUgRYsyAnKHiBf)
   ezjMGVLWCImXFvarhUgRYsyAnKHiPf=json.loads(ezjMGVLWCImXFvarhUgRYsyAnKHiPD.text)
   if not('celllist' in ezjMGVLWCImXFvarhUgRYsyAnKHiPf['cell_toplist']):return ezjMGVLWCImXFvarhUgRYsyAnKHixB,ezjMGVLWCImXFvarhUgRYsyAnKHiuk
   ezjMGVLWCImXFvarhUgRYsyAnKHiuJ=ezjMGVLWCImXFvarhUgRYsyAnKHiPf['cell_toplist']['celllist']
   for ezjMGVLWCImXFvarhUgRYsyAnKHiuE in ezjMGVLWCImXFvarhUgRYsyAnKHiuJ:
    ezjMGVLWCImXFvarhUgRYsyAnKHiut =ezjMGVLWCImXFvarhUgRYsyAnKHiuE['event_list'][1]['url']
    ezjMGVLWCImXFvarhUgRYsyAnKHiuD=urllib.parse.urlsplit(ezjMGVLWCImXFvarhUgRYsyAnKHiut).query
    ezjMGVLWCImXFvarhUgRYsyAnKHiuf=ezjMGVLWCImXFvarhUgRYsyAnKHiuD[0:ezjMGVLWCImXFvarhUgRYsyAnKHiuD.find('=')]
    ezjMGVLWCImXFvarhUgRYsyAnKHiud=ezjMGVLWCImXFvarhUgRYsyAnKHiuD[ezjMGVLWCImXFvarhUgRYsyAnKHiuD.find('=')+1:]
    ezjMGVLWCImXFvarhUgRYsyAnKHiub={'title':ezjMGVLWCImXFvarhUgRYsyAnKHiuE['title_list'][0]['text'],'age':ezjMGVLWCImXFvarhUgRYsyAnKHiuE['age'],'thumbnail':'https://%s'%ezjMGVLWCImXFvarhUgRYsyAnKHiuE.get('thumbnail'),'videoid':ezjMGVLWCImXFvarhUgRYsyAnKHiud,'vidtype':ezjMGVLWCImXFvarhUgRYsyAnKHiuf}
    ezjMGVLWCImXFvarhUgRYsyAnKHixB.append(ezjMGVLWCImXFvarhUgRYsyAnKHiub)
   ezjMGVLWCImXFvarhUgRYsyAnKHiuN=ezjMGVLWCImXFvarhUgRYsyAnKHiTS(ezjMGVLWCImXFvarhUgRYsyAnKHiPf['cell_toplist']['pagecount'])
   if ezjMGVLWCImXFvarhUgRYsyAnKHiPf['cell_toplist']['count']:ezjMGVLWCImXFvarhUgRYsyAnKHiuw =ezjMGVLWCImXFvarhUgRYsyAnKHiTS(ezjMGVLWCImXFvarhUgRYsyAnKHiPf['cell_toplist']['count'])
   else:ezjMGVLWCImXFvarhUgRYsyAnKHiuw=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.MV_LIMIT*page_int
   ezjMGVLWCImXFvarhUgRYsyAnKHiuk=ezjMGVLWCImXFvarhUgRYsyAnKHiuN>ezjMGVLWCImXFvarhUgRYsyAnKHiuw
  except ezjMGVLWCImXFvarhUgRYsyAnKHiTx as exception:
   ezjMGVLWCImXFvarhUgRYsyAnKHiTc(exception)
   return[],ezjMGVLWCImXFvarhUgRYsyAnKHiBd
  return ezjMGVLWCImXFvarhUgRYsyAnKHixB,ezjMGVLWCImXFvarhUgRYsyAnKHiuk
 def ProgramidToContentid(ezjMGVLWCImXFvarhUgRYsyAnKHiPx,ezjMGVLWCImXFvarhUgRYsyAnKHixJ):
  ezjMGVLWCImXFvarhUgRYsyAnKHixT=''
  try:
   ezjMGVLWCImXFvarhUgRYsyAnKHiPk =ezjMGVLWCImXFvarhUgRYsyAnKHiPx.API_DOMAIN+'/vod/programs-contentid/'+ezjMGVLWCImXFvarhUgRYsyAnKHixJ
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.GetDefaultParams(login=ezjMGVLWCImXFvarhUgRYsyAnKHiBd)
   ezjMGVLWCImXFvarhUgRYsyAnKHiPD=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.callRequestCookies('Get',ezjMGVLWCImXFvarhUgRYsyAnKHiPk,payload=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,params=ezjMGVLWCImXFvarhUgRYsyAnKHiPS,headers=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,cookies=ezjMGVLWCImXFvarhUgRYsyAnKHiBf)
   ezjMGVLWCImXFvarhUgRYsyAnKHixS=json.loads(ezjMGVLWCImXFvarhUgRYsyAnKHiPD.text)
   if not('contentid' in ezjMGVLWCImXFvarhUgRYsyAnKHixS):return ezjMGVLWCImXFvarhUgRYsyAnKHixT 
   ezjMGVLWCImXFvarhUgRYsyAnKHixT=ezjMGVLWCImXFvarhUgRYsyAnKHixS['contentid']
  except ezjMGVLWCImXFvarhUgRYsyAnKHiTx as exception:
   ezjMGVLWCImXFvarhUgRYsyAnKHiTc(exception)
  return ezjMGVLWCImXFvarhUgRYsyAnKHixT
 def ContentidToProgramid(ezjMGVLWCImXFvarhUgRYsyAnKHiPx,ezjMGVLWCImXFvarhUgRYsyAnKHixT):
  ezjMGVLWCImXFvarhUgRYsyAnKHixJ=''
  try:
   ezjMGVLWCImXFvarhUgRYsyAnKHiPk =ezjMGVLWCImXFvarhUgRYsyAnKHiPx.API_DOMAIN+'/cf/vod/contents/'+ezjMGVLWCImXFvarhUgRYsyAnKHixT
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.GetDefaultParams(login=ezjMGVLWCImXFvarhUgRYsyAnKHiBd)
   ezjMGVLWCImXFvarhUgRYsyAnKHiPD=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.callRequestCookies('Get',ezjMGVLWCImXFvarhUgRYsyAnKHiPk,payload=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,params=ezjMGVLWCImXFvarhUgRYsyAnKHiPS,headers=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,cookies=ezjMGVLWCImXFvarhUgRYsyAnKHiBf)
   ezjMGVLWCImXFvarhUgRYsyAnKHixS=json.loads(ezjMGVLWCImXFvarhUgRYsyAnKHiPD.text)
   if not('programid' in ezjMGVLWCImXFvarhUgRYsyAnKHixS):return ezjMGVLWCImXFvarhUgRYsyAnKHixJ 
   ezjMGVLWCImXFvarhUgRYsyAnKHixJ=ezjMGVLWCImXFvarhUgRYsyAnKHixS['programid']
  except ezjMGVLWCImXFvarhUgRYsyAnKHiTx as exception:
   ezjMGVLWCImXFvarhUgRYsyAnKHiTc(exception)
  return ezjMGVLWCImXFvarhUgRYsyAnKHixJ
 def GetProgramInfo(ezjMGVLWCImXFvarhUgRYsyAnKHiPx,program_code):
  ezjMGVLWCImXFvarhUgRYsyAnKHixE={}
  try:
   ezjMGVLWCImXFvarhUgRYsyAnKHiPk=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.API_DOMAIN+'/cf/vod/contents/'+program_code
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.GetDefaultParams(login=ezjMGVLWCImXFvarhUgRYsyAnKHiBd)
   ezjMGVLWCImXFvarhUgRYsyAnKHiPD=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.callRequestCookies('Get',ezjMGVLWCImXFvarhUgRYsyAnKHiPk,payload=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,params=ezjMGVLWCImXFvarhUgRYsyAnKHiPS,headers=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,cookies=ezjMGVLWCImXFvarhUgRYsyAnKHiBf)
   ezjMGVLWCImXFvarhUgRYsyAnKHixS=json.loads(ezjMGVLWCImXFvarhUgRYsyAnKHiPD.text)
   ezjMGVLWCImXFvarhUgRYsyAnKHiTc(ezjMGVLWCImXFvarhUgRYsyAnKHixS)
   ezjMGVLWCImXFvarhUgRYsyAnKHixb=img_fanart=ezjMGVLWCImXFvarhUgRYsyAnKHixq=''
   if ezjMGVLWCImXFvarhUgRYsyAnKHixS.get('programposterimage')!='':ezjMGVLWCImXFvarhUgRYsyAnKHixb =ezjMGVLWCImXFvarhUgRYsyAnKHiPx.HTTPTAG+ezjMGVLWCImXFvarhUgRYsyAnKHixS.get('programposterimage')
   if ezjMGVLWCImXFvarhUgRYsyAnKHixS.get('programimage') !='':img_fanart =ezjMGVLWCImXFvarhUgRYsyAnKHiPx.HTTPTAG+ezjMGVLWCImXFvarhUgRYsyAnKHixS.get('programimage')
   if ezjMGVLWCImXFvarhUgRYsyAnKHixS.get('programcirlceimage')!='':ezjMGVLWCImXFvarhUgRYsyAnKHixq=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.HTTPTAG+ezjMGVLWCImXFvarhUgRYsyAnKHixS.get('programcirlceimage')
   if 'poster_default' in ezjMGVLWCImXFvarhUgRYsyAnKHixb:
    ezjMGVLWCImXFvarhUgRYsyAnKHixb =img_fanart
    ezjMGVLWCImXFvarhUgRYsyAnKHixq=''
   ezjMGVLWCImXFvarhUgRYsyAnKHixE={'imgPoster':ezjMGVLWCImXFvarhUgRYsyAnKHixb,'imgFanart':img_fanart,'imgClearlogo':ezjMGVLWCImXFvarhUgRYsyAnKHixq}
  except ezjMGVLWCImXFvarhUgRYsyAnKHiTx as exception:
   ezjMGVLWCImXFvarhUgRYsyAnKHiTc(exception)
  return ezjMGVLWCImXFvarhUgRYsyAnKHixE
 def Get_Episode_List(ezjMGVLWCImXFvarhUgRYsyAnKHiPx,ezjMGVLWCImXFvarhUgRYsyAnKHiud,ezjMGVLWCImXFvarhUgRYsyAnKHiuf,page_int=1,orderby='desc'):
  ezjMGVLWCImXFvarhUgRYsyAnKHixQ=[]
  ezjMGVLWCImXFvarhUgRYsyAnKHiuN=ezjMGVLWCImXFvarhUgRYsyAnKHiuw=1
  ezjMGVLWCImXFvarhUgRYsyAnKHiuk=ezjMGVLWCImXFvarhUgRYsyAnKHiBd
  ezjMGVLWCImXFvarhUgRYsyAnKHixo={}
  if ezjMGVLWCImXFvarhUgRYsyAnKHiuf=='contentid':
   ezjMGVLWCImXFvarhUgRYsyAnKHixJ=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.ContentidToProgramid(ezjMGVLWCImXFvarhUgRYsyAnKHiud)
   ezjMGVLWCImXFvarhUgRYsyAnKHixo=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.GetProgramInfo(ezjMGVLWCImXFvarhUgRYsyAnKHiud)
  else:
   ezjMGVLWCImXFvarhUgRYsyAnKHixJ=ezjMGVLWCImXFvarhUgRYsyAnKHiud
   ezjMGVLWCImXFvarhUgRYsyAnKHixT=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.ProgramidToContentid(ezjMGVLWCImXFvarhUgRYsyAnKHiud)
   if ezjMGVLWCImXFvarhUgRYsyAnKHixT!='':ezjMGVLWCImXFvarhUgRYsyAnKHixo=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.GetProgramInfo(ezjMGVLWCImXFvarhUgRYsyAnKHixT)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   ezjMGVLWCImXFvarhUgRYsyAnKHiPk=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.API_DOMAIN+'/vod/programs-contents/'+ezjMGVLWCImXFvarhUgRYsyAnKHixJ
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS={}
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS['limit'] =ezjMGVLWCImXFvarhUgRYsyAnKHiPx.EP_LIMIT
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS['offset']=ezjMGVLWCImXFvarhUgRYsyAnKHiTu((page_int-1)*ezjMGVLWCImXFvarhUgRYsyAnKHiPx.EP_LIMIT)
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS['orderby']=orderby 
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS.update(ezjMGVLWCImXFvarhUgRYsyAnKHiPx.GetDefaultParams(login=ezjMGVLWCImXFvarhUgRYsyAnKHiBd))
   ezjMGVLWCImXFvarhUgRYsyAnKHiPD=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.callRequestCookies('Get',ezjMGVLWCImXFvarhUgRYsyAnKHiPk,payload=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,params=ezjMGVLWCImXFvarhUgRYsyAnKHiPS,headers=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,cookies=ezjMGVLWCImXFvarhUgRYsyAnKHiBf)
   ezjMGVLWCImXFvarhUgRYsyAnKHiPf=json.loads(ezjMGVLWCImXFvarhUgRYsyAnKHiPD.text)
   ezjMGVLWCImXFvarhUgRYsyAnKHiuJ=ezjMGVLWCImXFvarhUgRYsyAnKHiPf['list']
   for ezjMGVLWCImXFvarhUgRYsyAnKHiuE in ezjMGVLWCImXFvarhUgRYsyAnKHiuJ:
    ezjMGVLWCImXFvarhUgRYsyAnKHixO=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',ezjMGVLWCImXFvarhUgRYsyAnKHiuE.get('synopsis'))
    ezjMGVLWCImXFvarhUgRYsyAnKHixl=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.HTTPTAG+ezjMGVLWCImXFvarhUgRYsyAnKHiuE.get('image')
    ezjMGVLWCImXFvarhUgRYsyAnKHixN=ezjMGVLWCImXFvarhUgRYsyAnKHixk=ezjMGVLWCImXFvarhUgRYsyAnKHixt=''
    if ezjMGVLWCImXFvarhUgRYsyAnKHixo!={}:
     ezjMGVLWCImXFvarhUgRYsyAnKHixN =ezjMGVLWCImXFvarhUgRYsyAnKHixo.get('imgPoster')
     ezjMGVLWCImXFvarhUgRYsyAnKHixk =ezjMGVLWCImXFvarhUgRYsyAnKHixo.get('imgFanart')
     ezjMGVLWCImXFvarhUgRYsyAnKHixt=ezjMGVLWCImXFvarhUgRYsyAnKHixo.get('imgClearlogo')
     ezjMGVLWCImXFvarhUgRYsyAnKHixD={'thumb':ezjMGVLWCImXFvarhUgRYsyAnKHixl,'poster':ezjMGVLWCImXFvarhUgRYsyAnKHixN,'fanart':ezjMGVLWCImXFvarhUgRYsyAnKHixk,'clearlogo':ezjMGVLWCImXFvarhUgRYsyAnKHixt}
    else:
     ezjMGVLWCImXFvarhUgRYsyAnKHixD=ezjMGVLWCImXFvarhUgRYsyAnKHixl
    ezjMGVLWCImXFvarhUgRYsyAnKHiub={'programtitle':ezjMGVLWCImXFvarhUgRYsyAnKHiuE.get('programtitle'),'episodetitle':ezjMGVLWCImXFvarhUgRYsyAnKHiuE.get('episodetitle'),'episodenumber':ezjMGVLWCImXFvarhUgRYsyAnKHiuE.get('episodenumber'),'releasedate':ezjMGVLWCImXFvarhUgRYsyAnKHiuE.get('releasedate'),'releaseweekday':ezjMGVLWCImXFvarhUgRYsyAnKHiuE.get('releaseweekday'),'programid':ezjMGVLWCImXFvarhUgRYsyAnKHiuE.get('programid'),'contentid':ezjMGVLWCImXFvarhUgRYsyAnKHiuE.get('contentid'),'age':ezjMGVLWCImXFvarhUgRYsyAnKHiuE.get('targetage'),'playtime':ezjMGVLWCImXFvarhUgRYsyAnKHiuE.get('playtime'),'synopsis':ezjMGVLWCImXFvarhUgRYsyAnKHixO,'episodeactors':ezjMGVLWCImXFvarhUgRYsyAnKHiuE.get('episodeactors').split(',')if ezjMGVLWCImXFvarhUgRYsyAnKHiuE.get('episodeactors')!='' else[],'thumbnail':ezjMGVLWCImXFvarhUgRYsyAnKHixD}
    ezjMGVLWCImXFvarhUgRYsyAnKHixQ.append(ezjMGVLWCImXFvarhUgRYsyAnKHiub)
   ezjMGVLWCImXFvarhUgRYsyAnKHiuN=ezjMGVLWCImXFvarhUgRYsyAnKHiTS(ezjMGVLWCImXFvarhUgRYsyAnKHiPf['pagecount'])
   if ezjMGVLWCImXFvarhUgRYsyAnKHiPf['count']:ezjMGVLWCImXFvarhUgRYsyAnKHiuw =ezjMGVLWCImXFvarhUgRYsyAnKHiTS(ezjMGVLWCImXFvarhUgRYsyAnKHiPf['count'])
   else:ezjMGVLWCImXFvarhUgRYsyAnKHiuw=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.EP_LIMIT*page_int
   ezjMGVLWCImXFvarhUgRYsyAnKHiuk=ezjMGVLWCImXFvarhUgRYsyAnKHiuN>ezjMGVLWCImXFvarhUgRYsyAnKHiuw
  except ezjMGVLWCImXFvarhUgRYsyAnKHiTx as exception:
   ezjMGVLWCImXFvarhUgRYsyAnKHiTc(exception)
   return[],ezjMGVLWCImXFvarhUgRYsyAnKHiBd
  return ezjMGVLWCImXFvarhUgRYsyAnKHixQ,ezjMGVLWCImXFvarhUgRYsyAnKHiuk
 def GetEPGList(ezjMGVLWCImXFvarhUgRYsyAnKHiPx,genre):
  ezjMGVLWCImXFvarhUgRYsyAnKHixf={}
  try:
   ezjMGVLWCImXFvarhUgRYsyAnKHixd=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.Get_Now_Datetime()
   if genre=='all':
    ezjMGVLWCImXFvarhUgRYsyAnKHixw =ezjMGVLWCImXFvarhUgRYsyAnKHixd+datetime.timedelta(hours=3)
   else:
    ezjMGVLWCImXFvarhUgRYsyAnKHixw =ezjMGVLWCImXFvarhUgRYsyAnKHixd+datetime.timedelta(hours=3)
   ezjMGVLWCImXFvarhUgRYsyAnKHiPk=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.API_DOMAIN+'/live/epgs'
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS={'limit':'100','offset':'0','genre':genre,'startdatetime':ezjMGVLWCImXFvarhUgRYsyAnKHixd.strftime('%Y-%m-%d %H:00'),'enddatetime':ezjMGVLWCImXFvarhUgRYsyAnKHixw.strftime('%Y-%m-%d %H:00')}
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS.update(ezjMGVLWCImXFvarhUgRYsyAnKHiPx.GetDefaultParams(login=ezjMGVLWCImXFvarhUgRYsyAnKHiBd))
   ezjMGVLWCImXFvarhUgRYsyAnKHiPD=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.callRequestCookies('Get',ezjMGVLWCImXFvarhUgRYsyAnKHiPk,payload=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,params=ezjMGVLWCImXFvarhUgRYsyAnKHiPS,headers=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,cookies=ezjMGVLWCImXFvarhUgRYsyAnKHiBf)
   ezjMGVLWCImXFvarhUgRYsyAnKHiPf=json.loads(ezjMGVLWCImXFvarhUgRYsyAnKHiPD.text)
   ezjMGVLWCImXFvarhUgRYsyAnKHicP=ezjMGVLWCImXFvarhUgRYsyAnKHiPf['list']
   for ezjMGVLWCImXFvarhUgRYsyAnKHiuE in ezjMGVLWCImXFvarhUgRYsyAnKHicP:
    ezjMGVLWCImXFvarhUgRYsyAnKHicu=''
    for ezjMGVLWCImXFvarhUgRYsyAnKHicx in ezjMGVLWCImXFvarhUgRYsyAnKHiuE['list']:
     if ezjMGVLWCImXFvarhUgRYsyAnKHicu:ezjMGVLWCImXFvarhUgRYsyAnKHicu+='\n'
     ezjMGVLWCImXFvarhUgRYsyAnKHicu+=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.Get_ChangeText(ezjMGVLWCImXFvarhUgRYsyAnKHicx['title'])+'\n'
     ezjMGVLWCImXFvarhUgRYsyAnKHicu+=' [%s ~ %s]'%(ezjMGVLWCImXFvarhUgRYsyAnKHicx['starttime'][-5:],ezjMGVLWCImXFvarhUgRYsyAnKHicx['endtime'][-5:])+'\n'
    ezjMGVLWCImXFvarhUgRYsyAnKHixf[ezjMGVLWCImXFvarhUgRYsyAnKHiuE['channelid']]=ezjMGVLWCImXFvarhUgRYsyAnKHicu
  except ezjMGVLWCImXFvarhUgRYsyAnKHiTx as exception:
   ezjMGVLWCImXFvarhUgRYsyAnKHiTc(exception)
  return ezjMGVLWCImXFvarhUgRYsyAnKHixf
 def Get_LiveChannel_List(ezjMGVLWCImXFvarhUgRYsyAnKHiPx,genre,ezjMGVLWCImXFvarhUgRYsyAnKHiuT):
  ezjMGVLWCImXFvarhUgRYsyAnKHiul=[]
  (ezjMGVLWCImXFvarhUgRYsyAnKHiPk,ezjMGVLWCImXFvarhUgRYsyAnKHiPS)=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.Baseapi_Parse(ezjMGVLWCImXFvarhUgRYsyAnKHiuT)
  if ezjMGVLWCImXFvarhUgRYsyAnKHiPk=='':return ezjMGVLWCImXFvarhUgRYsyAnKHiul
  ezjMGVLWCImXFvarhUgRYsyAnKHicB=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.GetEPGList(genre)
  try:
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS.update(ezjMGVLWCImXFvarhUgRYsyAnKHiPx.GetDefaultParams(login=ezjMGVLWCImXFvarhUgRYsyAnKHiBd))
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS['genre']=genre
   ezjMGVLWCImXFvarhUgRYsyAnKHiPD=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.callRequestCookies('Get',ezjMGVLWCImXFvarhUgRYsyAnKHiPk,payload=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,params=ezjMGVLWCImXFvarhUgRYsyAnKHiPS,headers=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,cookies=ezjMGVLWCImXFvarhUgRYsyAnKHiBf)
   ezjMGVLWCImXFvarhUgRYsyAnKHiPf=json.loads(ezjMGVLWCImXFvarhUgRYsyAnKHiPD.text)
   if not('celllist' in ezjMGVLWCImXFvarhUgRYsyAnKHiPf['cell_toplist']):return[]
   ezjMGVLWCImXFvarhUgRYsyAnKHiuJ=ezjMGVLWCImXFvarhUgRYsyAnKHiPf['cell_toplist']['celllist']
   for ezjMGVLWCImXFvarhUgRYsyAnKHiuE in ezjMGVLWCImXFvarhUgRYsyAnKHiuJ:
    ezjMGVLWCImXFvarhUgRYsyAnKHixT=ezjMGVLWCImXFvarhUgRYsyAnKHiuE['contentid']
    if ezjMGVLWCImXFvarhUgRYsyAnKHixT in ezjMGVLWCImXFvarhUgRYsyAnKHicB:
     ezjMGVLWCImXFvarhUgRYsyAnKHicT=ezjMGVLWCImXFvarhUgRYsyAnKHicB[ezjMGVLWCImXFvarhUgRYsyAnKHixT]
    else:
     ezjMGVLWCImXFvarhUgRYsyAnKHicT=''
    ezjMGVLWCImXFvarhUgRYsyAnKHiub={'studio':ezjMGVLWCImXFvarhUgRYsyAnKHiuE['title_list'][0]['text'],'tvshowtitle':ezjMGVLWCImXFvarhUgRYsyAnKHiPx.Get_ChangeText(ezjMGVLWCImXFvarhUgRYsyAnKHiuE['title_list'][1]['text']),'channelid':ezjMGVLWCImXFvarhUgRYsyAnKHixT,'age':ezjMGVLWCImXFvarhUgRYsyAnKHiuE['age'],'thumbnail':'https://%s'%ezjMGVLWCImXFvarhUgRYsyAnKHiuE.get('thumbnail'),'epg':ezjMGVLWCImXFvarhUgRYsyAnKHicT}
    ezjMGVLWCImXFvarhUgRYsyAnKHiul.append(ezjMGVLWCImXFvarhUgRYsyAnKHiub)
  except ezjMGVLWCImXFvarhUgRYsyAnKHiTx as exception:
   ezjMGVLWCImXFvarhUgRYsyAnKHiTc(exception)
   return[]
  return ezjMGVLWCImXFvarhUgRYsyAnKHiul
 def Get_Search_List(ezjMGVLWCImXFvarhUgRYsyAnKHiPx,search_key,sType,page_int,exclusion21=ezjMGVLWCImXFvarhUgRYsyAnKHiBd):
  ezjMGVLWCImXFvarhUgRYsyAnKHicS=[]
  ezjMGVLWCImXFvarhUgRYsyAnKHiuN=ezjMGVLWCImXFvarhUgRYsyAnKHiuw=1
  ezjMGVLWCImXFvarhUgRYsyAnKHiuk=ezjMGVLWCImXFvarhUgRYsyAnKHiBd
  try:
   ezjMGVLWCImXFvarhUgRYsyAnKHiPk=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.API_DOMAIN+'/cf/search/list.js'
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':ezjMGVLWCImXFvarhUgRYsyAnKHiTu((page_int-1)*ezjMGVLWCImXFvarhUgRYsyAnKHiPx.SEARCH_LIMIT),'limit':ezjMGVLWCImXFvarhUgRYsyAnKHiPx.SEARCH_LIMIT,'orderby':'score'}
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS.update(ezjMGVLWCImXFvarhUgRYsyAnKHiPx.GetDefaultParams(login=ezjMGVLWCImXFvarhUgRYsyAnKHiBd))
   ezjMGVLWCImXFvarhUgRYsyAnKHiPD=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.callRequestCookies('Get',ezjMGVLWCImXFvarhUgRYsyAnKHiPk,payload=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,params=ezjMGVLWCImXFvarhUgRYsyAnKHiPS,headers=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,cookies=ezjMGVLWCImXFvarhUgRYsyAnKHiBf)
   ezjMGVLWCImXFvarhUgRYsyAnKHixS=json.loads(ezjMGVLWCImXFvarhUgRYsyAnKHiPD.text)
   if not('celllist' in ezjMGVLWCImXFvarhUgRYsyAnKHixS['cell_toplist']):return ezjMGVLWCImXFvarhUgRYsyAnKHicS,ezjMGVLWCImXFvarhUgRYsyAnKHiuk
   ezjMGVLWCImXFvarhUgRYsyAnKHiuJ=ezjMGVLWCImXFvarhUgRYsyAnKHixS['cell_toplist']['celllist']
   for ezjMGVLWCImXFvarhUgRYsyAnKHiuE in ezjMGVLWCImXFvarhUgRYsyAnKHiuJ:
    ezjMGVLWCImXFvarhUgRYsyAnKHiut =ezjMGVLWCImXFvarhUgRYsyAnKHiuE['event_list'][1]['url']
    ezjMGVLWCImXFvarhUgRYsyAnKHiuD=urllib.parse.urlsplit(ezjMGVLWCImXFvarhUgRYsyAnKHiut).query
    ezjMGVLWCImXFvarhUgRYsyAnKHiuf=ezjMGVLWCImXFvarhUgRYsyAnKHiuD[0:ezjMGVLWCImXFvarhUgRYsyAnKHiuD.find('=')]
    ezjMGVLWCImXFvarhUgRYsyAnKHiud=ezjMGVLWCImXFvarhUgRYsyAnKHiuD[ezjMGVLWCImXFvarhUgRYsyAnKHiuD.find('=')+1:]
    ezjMGVLWCImXFvarhUgRYsyAnKHiub={'title':ezjMGVLWCImXFvarhUgRYsyAnKHiuE['title_list'][0]['text'],'age':ezjMGVLWCImXFvarhUgRYsyAnKHiuE['age'],'thumbnail':'https://%s'%ezjMGVLWCImXFvarhUgRYsyAnKHiuE.get('thumbnail'),'videoid':ezjMGVLWCImXFvarhUgRYsyAnKHiud,'vidtype':ezjMGVLWCImXFvarhUgRYsyAnKHiuf}
    if exclusion21==ezjMGVLWCImXFvarhUgRYsyAnKHiBd or ezjMGVLWCImXFvarhUgRYsyAnKHiuE.get('age')!='21':
     ezjMGVLWCImXFvarhUgRYsyAnKHicS.append(ezjMGVLWCImXFvarhUgRYsyAnKHiub)
   ezjMGVLWCImXFvarhUgRYsyAnKHiuN=ezjMGVLWCImXFvarhUgRYsyAnKHiTS(ezjMGVLWCImXFvarhUgRYsyAnKHixS['cell_toplist']['pagecount'])
   if ezjMGVLWCImXFvarhUgRYsyAnKHixS['cell_toplist']['count']:ezjMGVLWCImXFvarhUgRYsyAnKHiuw =ezjMGVLWCImXFvarhUgRYsyAnKHiTS(ezjMGVLWCImXFvarhUgRYsyAnKHixS['cell_toplist']['count'])
   else:ezjMGVLWCImXFvarhUgRYsyAnKHiuw=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.LIST_LIMIT
   ezjMGVLWCImXFvarhUgRYsyAnKHiuk=ezjMGVLWCImXFvarhUgRYsyAnKHiuN>ezjMGVLWCImXFvarhUgRYsyAnKHiuw
  except ezjMGVLWCImXFvarhUgRYsyAnKHiTx as exception:
   ezjMGVLWCImXFvarhUgRYsyAnKHiTc(exception)
  return ezjMGVLWCImXFvarhUgRYsyAnKHicS,ezjMGVLWCImXFvarhUgRYsyAnKHiuk 
 def GetStreamingURL(ezjMGVLWCImXFvarhUgRYsyAnKHiPx,mode,ezjMGVLWCImXFvarhUgRYsyAnKHixT,quality_int,pvrmode='-'):
  ezjMGVLWCImXFvarhUgRYsyAnKHicJ=ezjMGVLWCImXFvarhUgRYsyAnKHicl=ezjMGVLWCImXFvarhUgRYsyAnKHicN=streaming_preview=''
  ezjMGVLWCImXFvarhUgRYsyAnKHicE=[]
  ezjMGVLWCImXFvarhUgRYsyAnKHicb='hls'
  if mode=='LIVE':
   ezjMGVLWCImXFvarhUgRYsyAnKHiPk =ezjMGVLWCImXFvarhUgRYsyAnKHiPx.API_DOMAIN+'/live/channels/'+ezjMGVLWCImXFvarhUgRYsyAnKHixT
   ezjMGVLWCImXFvarhUgRYsyAnKHicq='live'
  elif mode=='VOD':
   ezjMGVLWCImXFvarhUgRYsyAnKHiPk =ezjMGVLWCImXFvarhUgRYsyAnKHiPx.API_DOMAIN+'/cf/vod/contents/'+ezjMGVLWCImXFvarhUgRYsyAnKHixT
   ezjMGVLWCImXFvarhUgRYsyAnKHicq='vod'
  elif mode=='MOVIE':
   ezjMGVLWCImXFvarhUgRYsyAnKHiPk =ezjMGVLWCImXFvarhUgRYsyAnKHiPx.API_DOMAIN+'/cf/movie/contents/'+ezjMGVLWCImXFvarhUgRYsyAnKHixT
   ezjMGVLWCImXFvarhUgRYsyAnKHicq='movie'
  try:
   if mode!='LIVE' or pvrmode=='-':
    ezjMGVLWCImXFvarhUgRYsyAnKHiPS=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.GetDefaultParams(login=ezjMGVLWCImXFvarhUgRYsyAnKHiBd)
    ezjMGVLWCImXFvarhUgRYsyAnKHiPD=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.callRequestCookies('Get',ezjMGVLWCImXFvarhUgRYsyAnKHiPk,payload=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,params=ezjMGVLWCImXFvarhUgRYsyAnKHiPS,headers=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,cookies=ezjMGVLWCImXFvarhUgRYsyAnKHiBf)
    ezjMGVLWCImXFvarhUgRYsyAnKHiPf=json.loads(ezjMGVLWCImXFvarhUgRYsyAnKHiPD.text)
    ezjMGVLWCImXFvarhUgRYsyAnKHicQ=ezjMGVLWCImXFvarhUgRYsyAnKHiPf['qualities']['list']
    if ezjMGVLWCImXFvarhUgRYsyAnKHicQ==ezjMGVLWCImXFvarhUgRYsyAnKHiBf:return(ezjMGVLWCImXFvarhUgRYsyAnKHicJ,ezjMGVLWCImXFvarhUgRYsyAnKHicl,ezjMGVLWCImXFvarhUgRYsyAnKHicN,streaming_preview)
    for ezjMGVLWCImXFvarhUgRYsyAnKHico in ezjMGVLWCImXFvarhUgRYsyAnKHicQ:
     ezjMGVLWCImXFvarhUgRYsyAnKHicE.append(ezjMGVLWCImXFvarhUgRYsyAnKHiTS(ezjMGVLWCImXFvarhUgRYsyAnKHico.get('id').rstrip('p')))
    if 'type' in ezjMGVLWCImXFvarhUgRYsyAnKHiPf:
     if ezjMGVLWCImXFvarhUgRYsyAnKHiPf['type']=='onair':
      ezjMGVLWCImXFvarhUgRYsyAnKHicq='onairvod'
    if 'drms' in ezjMGVLWCImXFvarhUgRYsyAnKHiPf:
     if ezjMGVLWCImXFvarhUgRYsyAnKHiPf['drms']:
      ezjMGVLWCImXFvarhUgRYsyAnKHicb='dash'
  except ezjMGVLWCImXFvarhUgRYsyAnKHiTx as exception:
   ezjMGVLWCImXFvarhUgRYsyAnKHiTc(exception)
   return(ezjMGVLWCImXFvarhUgRYsyAnKHicJ,ezjMGVLWCImXFvarhUgRYsyAnKHicl,ezjMGVLWCImXFvarhUgRYsyAnKHicN,streaming_preview)
  try:
   ezjMGVLWCImXFvarhUgRYsyAnKHicp=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.CheckQuality(quality_int,ezjMGVLWCImXFvarhUgRYsyAnKHicE)
   if mode=='LIVE' and pvrmode!='-':
    ezjMGVLWCImXFvarhUgRYsyAnKHicO='auto'
   else:
    ezjMGVLWCImXFvarhUgRYsyAnKHicO=ezjMGVLWCImXFvarhUgRYsyAnKHiTu(ezjMGVLWCImXFvarhUgRYsyAnKHicp)+'p'
   ezjMGVLWCImXFvarhUgRYsyAnKHiPk=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.API_DOMAIN+'/streaming'
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS={'contentid':ezjMGVLWCImXFvarhUgRYsyAnKHixT,'contenttype':ezjMGVLWCImXFvarhUgRYsyAnKHicq,'action':ezjMGVLWCImXFvarhUgRYsyAnKHicb,'quality':ezjMGVLWCImXFvarhUgRYsyAnKHicO,'deviceModelId':'Windows 10','guid':ezjMGVLWCImXFvarhUgRYsyAnKHiPx.GetGUID(guidType=2),'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n'}
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS.update(ezjMGVLWCImXFvarhUgRYsyAnKHiPx.GetDefaultParams(login=ezjMGVLWCImXFvarhUgRYsyAnKHiBw))
   ezjMGVLWCImXFvarhUgRYsyAnKHiPD=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.callRequestCookies('Get',ezjMGVLWCImXFvarhUgRYsyAnKHiPk,payload=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,params=ezjMGVLWCImXFvarhUgRYsyAnKHiPS,headers=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,cookies=ezjMGVLWCImXFvarhUgRYsyAnKHiBf)
   ezjMGVLWCImXFvarhUgRYsyAnKHiPf=json.loads(ezjMGVLWCImXFvarhUgRYsyAnKHiPD.text)
   ezjMGVLWCImXFvarhUgRYsyAnKHicJ=ezjMGVLWCImXFvarhUgRYsyAnKHiPf['playurl']
   if ezjMGVLWCImXFvarhUgRYsyAnKHicJ==ezjMGVLWCImXFvarhUgRYsyAnKHiBf:return(ezjMGVLWCImXFvarhUgRYsyAnKHicJ,ezjMGVLWCImXFvarhUgRYsyAnKHicl,ezjMGVLWCImXFvarhUgRYsyAnKHicN,streaming_preview)
   ezjMGVLWCImXFvarhUgRYsyAnKHicl=ezjMGVLWCImXFvarhUgRYsyAnKHiPf['awscookie']
   ezjMGVLWCImXFvarhUgRYsyAnKHicN =ezjMGVLWCImXFvarhUgRYsyAnKHiPf['drm']
   if 'previewmsg' in ezjMGVLWCImXFvarhUgRYsyAnKHiPf['preview']:streaming_preview=ezjMGVLWCImXFvarhUgRYsyAnKHiPf['preview']['previewmsg']
  except ezjMGVLWCImXFvarhUgRYsyAnKHiTx as exception:
   ezjMGVLWCImXFvarhUgRYsyAnKHiTc(exception)
  return(ezjMGVLWCImXFvarhUgRYsyAnKHicJ,ezjMGVLWCImXFvarhUgRYsyAnKHicl,ezjMGVLWCImXFvarhUgRYsyAnKHicN,streaming_preview) 
 def GetSportsURL(ezjMGVLWCImXFvarhUgRYsyAnKHiPx,ezjMGVLWCImXFvarhUgRYsyAnKHixT,quality_int):
  ezjMGVLWCImXFvarhUgRYsyAnKHicJ=ezjMGVLWCImXFvarhUgRYsyAnKHicl=''
  ezjMGVLWCImXFvarhUgRYsyAnKHicE=[]
  try:
   ezjMGVLWCImXFvarhUgRYsyAnKHiPk=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.API_DOMAIN+'/streaming/other'
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS={'contentid':ezjMGVLWCImXFvarhUgRYsyAnKHixT,'contenttype':'live','action':'hls','quality':ezjMGVLWCImXFvarhUgRYsyAnKHiTu(quality_int)+'p','deviceModelId':'Windows 10','guid':ezjMGVLWCImXFvarhUgRYsyAnKHiPx.GetGUID(guidType=2),'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n'}
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS.update(ezjMGVLWCImXFvarhUgRYsyAnKHiPx.GetDefaultParams(login=ezjMGVLWCImXFvarhUgRYsyAnKHiBw))
   ezjMGVLWCImXFvarhUgRYsyAnKHiPD=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.callRequestCookies('Get',ezjMGVLWCImXFvarhUgRYsyAnKHiPk,payload=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,params=ezjMGVLWCImXFvarhUgRYsyAnKHiPS,headers=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,cookies=ezjMGVLWCImXFvarhUgRYsyAnKHiBf)
   ezjMGVLWCImXFvarhUgRYsyAnKHiPf=json.loads(ezjMGVLWCImXFvarhUgRYsyAnKHiPD.text)
   ezjMGVLWCImXFvarhUgRYsyAnKHicJ=ezjMGVLWCImXFvarhUgRYsyAnKHiPf['playurl']
   if ezjMGVLWCImXFvarhUgRYsyAnKHicJ==ezjMGVLWCImXFvarhUgRYsyAnKHiBf:return(ezjMGVLWCImXFvarhUgRYsyAnKHicJ,ezjMGVLWCImXFvarhUgRYsyAnKHicl)
   ezjMGVLWCImXFvarhUgRYsyAnKHicl=ezjMGVLWCImXFvarhUgRYsyAnKHiPf['awscookie']
  except ezjMGVLWCImXFvarhUgRYsyAnKHiTx as exception:
   ezjMGVLWCImXFvarhUgRYsyAnKHiTc(exception)
  return(ezjMGVLWCImXFvarhUgRYsyAnKHicJ,ezjMGVLWCImXFvarhUgRYsyAnKHicl) 
 def make_viewdate(ezjMGVLWCImXFvarhUgRYsyAnKHiPx):
  ezjMGVLWCImXFvarhUgRYsyAnKHick =ezjMGVLWCImXFvarhUgRYsyAnKHiPx.Get_Now_Datetime()
  ezjMGVLWCImXFvarhUgRYsyAnKHict =ezjMGVLWCImXFvarhUgRYsyAnKHick+datetime.timedelta(days=-1)
  ezjMGVLWCImXFvarhUgRYsyAnKHicD =ezjMGVLWCImXFvarhUgRYsyAnKHick+datetime.timedelta(days=1)
  ezjMGVLWCImXFvarhUgRYsyAnKHicf=[ezjMGVLWCImXFvarhUgRYsyAnKHick.strftime('%Y%m%d'),ezjMGVLWCImXFvarhUgRYsyAnKHicD.strftime('%Y%m%d'),]
  return ezjMGVLWCImXFvarhUgRYsyAnKHicf
 def Get_Sports_Gamelist(ezjMGVLWCImXFvarhUgRYsyAnKHiPx):
  ezjMGVLWCImXFvarhUgRYsyAnKHicd =ezjMGVLWCImXFvarhUgRYsyAnKHiPx.make_viewdate()
  ezjMGVLWCImXFvarhUgRYsyAnKHicw=[]
  ezjMGVLWCImXFvarhUgRYsyAnKHiBP =[]
  for ezjMGVLWCImXFvarhUgRYsyAnKHiBu in ezjMGVLWCImXFvarhUgRYsyAnKHicd:
   ezjMGVLWCImXFvarhUgRYsyAnKHiBx=ezjMGVLWCImXFvarhUgRYsyAnKHiBu[:6]
   if ezjMGVLWCImXFvarhUgRYsyAnKHiBx not in ezjMGVLWCImXFvarhUgRYsyAnKHicw:
    ezjMGVLWCImXFvarhUgRYsyAnKHicw.append(ezjMGVLWCImXFvarhUgRYsyAnKHiBx)
  try:
   ezjMGVLWCImXFvarhUgRYsyAnKHiPk='https://annexapi.wavve.com/skb/baseball/teammonthlycalendarlist'
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS={'IF':'IF-PORG-002','m':'getTeamCalendarListBand','response_format':'json','spo_itm_cd':'KBO','teamcd':'all','tgroup':'B','tvalue':'BC123','ver':'2.0',}
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS.update(ezjMGVLWCImXFvarhUgRYsyAnKHiPx.GetDefaultParams(login=ezjMGVLWCImXFvarhUgRYsyAnKHiBd))
   for ezjMGVLWCImXFvarhUgRYsyAnKHiBc in ezjMGVLWCImXFvarhUgRYsyAnKHicw:
    ezjMGVLWCImXFvarhUgRYsyAnKHiPS['date']=ezjMGVLWCImXFvarhUgRYsyAnKHiBc
    ezjMGVLWCImXFvarhUgRYsyAnKHiPD=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.callRequestCookies('Get',ezjMGVLWCImXFvarhUgRYsyAnKHiPk,payload=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,params=ezjMGVLWCImXFvarhUgRYsyAnKHiPS,headers=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,cookies=ezjMGVLWCImXFvarhUgRYsyAnKHiBf)
    ezjMGVLWCImXFvarhUgRYsyAnKHiPf=json.loads(ezjMGVLWCImXFvarhUgRYsyAnKHiPD.text)
    ezjMGVLWCImXFvarhUgRYsyAnKHiuJ=ezjMGVLWCImXFvarhUgRYsyAnKHiPf['cell_toplist']['celllist']
    for ezjMGVLWCImXFvarhUgRYsyAnKHiuE in ezjMGVLWCImXFvarhUgRYsyAnKHiuJ:
     ezjMGVLWCImXFvarhUgRYsyAnKHiBT=ezjMGVLWCImXFvarhUgRYsyAnKHiuE.get('game_date')
     ezjMGVLWCImXFvarhUgRYsyAnKHiBS =ezjMGVLWCImXFvarhUgRYsyAnKHiuE.get('svc_id')
     if ezjMGVLWCImXFvarhUgRYsyAnKHiBS=='':continue
     if ezjMGVLWCImXFvarhUgRYsyAnKHiBT in ezjMGVLWCImXFvarhUgRYsyAnKHicd:
      ezjMGVLWCImXFvarhUgRYsyAnKHiBJ=ezjMGVLWCImXFvarhUgRYsyAnKHiuE.get('game_status') 
      ezjMGVLWCImXFvarhUgRYsyAnKHiBE =ezjMGVLWCImXFvarhUgRYsyAnKHiuE.get('title_list')[0].get('text')
      ezjMGVLWCImXFvarhUgRYsyAnKHiBT =ezjMGVLWCImXFvarhUgRYsyAnKHiBT[:4]+'-'+ezjMGVLWCImXFvarhUgRYsyAnKHiBT[4:6]+'-'+ezjMGVLWCImXFvarhUgRYsyAnKHiBT[-2:]
      ezjMGVLWCImXFvarhUgRYsyAnKHiBb =ezjMGVLWCImXFvarhUgRYsyAnKHiuE.get('game_time')
      ezjMGVLWCImXFvarhUgRYsyAnKHiBb =ezjMGVLWCImXFvarhUgRYsyAnKHiBb[:2]+':'+ezjMGVLWCImXFvarhUgRYsyAnKHiBb[-2:]
      ezjMGVLWCImXFvarhUgRYsyAnKHiub={'game_date':ezjMGVLWCImXFvarhUgRYsyAnKHiBT,'game_time':ezjMGVLWCImXFvarhUgRYsyAnKHiBb,'svc_id':ezjMGVLWCImXFvarhUgRYsyAnKHiBS,'away_team':ezjMGVLWCImXFvarhUgRYsyAnKHiuE.get('away_team').get('team_name'),'home_team':ezjMGVLWCImXFvarhUgRYsyAnKHiuE.get('home_team').get('team_name'),'game_status':ezjMGVLWCImXFvarhUgRYsyAnKHiBJ,'game_place':ezjMGVLWCImXFvarhUgRYsyAnKHiuE.get('game_place'),}
      ezjMGVLWCImXFvarhUgRYsyAnKHiBP.append(ezjMGVLWCImXFvarhUgRYsyAnKHiub)
  except ezjMGVLWCImXFvarhUgRYsyAnKHiTx as exception:
   ezjMGVLWCImXFvarhUgRYsyAnKHiTc(exception)
   return[]
  ezjMGVLWCImXFvarhUgRYsyAnKHiBq=[]
  for i in ezjMGVLWCImXFvarhUgRYsyAnKHiTP(2):
   for ezjMGVLWCImXFvarhUgRYsyAnKHiuE in ezjMGVLWCImXFvarhUgRYsyAnKHiBP:
    if i==0 and ezjMGVLWCImXFvarhUgRYsyAnKHiuE.get('game_status')=='LIVE':
     ezjMGVLWCImXFvarhUgRYsyAnKHiBq.append(ezjMGVLWCImXFvarhUgRYsyAnKHiuE)
    elif i==1 and ezjMGVLWCImXFvarhUgRYsyAnKHiuE.get('game_status')!='LIVE':
     ezjMGVLWCImXFvarhUgRYsyAnKHiBq.append(ezjMGVLWCImXFvarhUgRYsyAnKHiuE)
  return ezjMGVLWCImXFvarhUgRYsyAnKHiBq
 def GetBookmarkInfo(ezjMGVLWCImXFvarhUgRYsyAnKHiPx,ezjMGVLWCImXFvarhUgRYsyAnKHiud,ezjMGVLWCImXFvarhUgRYsyAnKHiuf,ezjMGVLWCImXFvarhUgRYsyAnKHicq):
  if ezjMGVLWCImXFvarhUgRYsyAnKHiuf=='tvshow':
   if ezjMGVLWCImXFvarhUgRYsyAnKHicq=='contentid':
    ezjMGVLWCImXFvarhUgRYsyAnKHixT=ezjMGVLWCImXFvarhUgRYsyAnKHiud
    ezjMGVLWCImXFvarhUgRYsyAnKHiud =ezjMGVLWCImXFvarhUgRYsyAnKHiPx.ContentidToProgramid(ezjMGVLWCImXFvarhUgRYsyAnKHixT)
   else:
    ezjMGVLWCImXFvarhUgRYsyAnKHixT=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.ProgramidToContentid(ezjMGVLWCImXFvarhUgRYsyAnKHiud)
  else:
   ezjMGVLWCImXFvarhUgRYsyAnKHixT=''
  ezjMGVLWCImXFvarhUgRYsyAnKHiBQ={'indexinfo':{'ott':'wavve','videoid':ezjMGVLWCImXFvarhUgRYsyAnKHiud,'vidtype':ezjMGVLWCImXFvarhUgRYsyAnKHiuf,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':ezjMGVLWCImXFvarhUgRYsyAnKHiuf,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if ezjMGVLWCImXFvarhUgRYsyAnKHiuf=='tvshow':
   ezjMGVLWCImXFvarhUgRYsyAnKHiPk=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.API_DOMAIN+'/cf/vod/contents/'+ezjMGVLWCImXFvarhUgRYsyAnKHixT 
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.GetDefaultParams(login=ezjMGVLWCImXFvarhUgRYsyAnKHiBd)
   ezjMGVLWCImXFvarhUgRYsyAnKHiPD=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.callRequestCookies('Get',ezjMGVLWCImXFvarhUgRYsyAnKHiPk,payload=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,params=ezjMGVLWCImXFvarhUgRYsyAnKHiPS,headers=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,cookies=ezjMGVLWCImXFvarhUgRYsyAnKHiBf)
   ezjMGVLWCImXFvarhUgRYsyAnKHiPf=json.loads(ezjMGVLWCImXFvarhUgRYsyAnKHiPD.text)
   if not('programtitle' in ezjMGVLWCImXFvarhUgRYsyAnKHiPf):return{}
   ezjMGVLWCImXFvarhUgRYsyAnKHiBo=ezjMGVLWCImXFvarhUgRYsyAnKHiPf
   ezjMGVLWCImXFvarhUgRYsyAnKHiBp=ezjMGVLWCImXFvarhUgRYsyAnKHiBo.get('programtitle')
   ezjMGVLWCImXFvarhUgRYsyAnKHiBQ['saveinfo']['infoLabels']['title']=ezjMGVLWCImXFvarhUgRYsyAnKHiBp
   if ezjMGVLWCImXFvarhUgRYsyAnKHiBo.get('targetage')=='18' or ezjMGVLWCImXFvarhUgRYsyAnKHiBo.get('targetage')=='19' or ezjMGVLWCImXFvarhUgRYsyAnKHiBo.get('targetage')=='21':
    ezjMGVLWCImXFvarhUgRYsyAnKHiBp +=u' (%s)'%(ezjMGVLWCImXFvarhUgRYsyAnKHiBo.get('targetage'))
   ezjMGVLWCImXFvarhUgRYsyAnKHiBQ['saveinfo']['title'] =ezjMGVLWCImXFvarhUgRYsyAnKHiBp
   ezjMGVLWCImXFvarhUgRYsyAnKHiBQ['saveinfo']['infoLabels']['mpaa'] =ezjMGVLWCImXFvarhUgRYsyAnKHiBo.get('targetage')
   ezjMGVLWCImXFvarhUgRYsyAnKHiBQ['saveinfo']['infoLabels']['plot'] =ezjMGVLWCImXFvarhUgRYsyAnKHiBo.get('programsynopsis').replace('<br>','\n')
   ezjMGVLWCImXFvarhUgRYsyAnKHiBQ['saveinfo']['infoLabels']['studio'] =ezjMGVLWCImXFvarhUgRYsyAnKHiBo.get('channelname')
   if ezjMGVLWCImXFvarhUgRYsyAnKHiBo.get('firstreleaseyear')!='':ezjMGVLWCImXFvarhUgRYsyAnKHiBQ['saveinfo']['infoLabels']['year'] =ezjMGVLWCImXFvarhUgRYsyAnKHiBo.get('firstreleaseyear')
   if ezjMGVLWCImXFvarhUgRYsyAnKHiBo.get('firstreleasedate')!='':ezjMGVLWCImXFvarhUgRYsyAnKHiBQ['saveinfo']['infoLabels']['premiered']=ezjMGVLWCImXFvarhUgRYsyAnKHiBo.get('firstreleasedate')
   if ezjMGVLWCImXFvarhUgRYsyAnKHiBo.get('genretext') !='':ezjMGVLWCImXFvarhUgRYsyAnKHiBQ['saveinfo']['infoLabels']['genre'] =[ezjMGVLWCImXFvarhUgRYsyAnKHiBo.get('genretext')]
   ezjMGVLWCImXFvarhUgRYsyAnKHiBO=[]
   for ezjMGVLWCImXFvarhUgRYsyAnKHiBl in ezjMGVLWCImXFvarhUgRYsyAnKHiBo['actors']['list']:ezjMGVLWCImXFvarhUgRYsyAnKHiBO.append(ezjMGVLWCImXFvarhUgRYsyAnKHiBl.get('text'))
   if ezjMGVLWCImXFvarhUgRYsyAnKHiTJ(ezjMGVLWCImXFvarhUgRYsyAnKHiBO)>0:
    if ezjMGVLWCImXFvarhUgRYsyAnKHiBO[0]!='':ezjMGVLWCImXFvarhUgRYsyAnKHiBQ['saveinfo']['infoLabels']['cast']=ezjMGVLWCImXFvarhUgRYsyAnKHiBO
   ezjMGVLWCImXFvarhUgRYsyAnKHixN =''
   ezjMGVLWCImXFvarhUgRYsyAnKHixk =''
   ezjMGVLWCImXFvarhUgRYsyAnKHixt=''
   if ezjMGVLWCImXFvarhUgRYsyAnKHiBo.get('programposterimage')!='':ezjMGVLWCImXFvarhUgRYsyAnKHixN =ezjMGVLWCImXFvarhUgRYsyAnKHiPx.HTTPTAG+ezjMGVLWCImXFvarhUgRYsyAnKHiBo.get('programposterimage')
   if ezjMGVLWCImXFvarhUgRYsyAnKHiBo.get('programimage') !='':ezjMGVLWCImXFvarhUgRYsyAnKHixk =ezjMGVLWCImXFvarhUgRYsyAnKHiPx.HTTPTAG+ezjMGVLWCImXFvarhUgRYsyAnKHiBo.get('programimage')
   if ezjMGVLWCImXFvarhUgRYsyAnKHiBo.get('programcirlceimage')!='':ezjMGVLWCImXFvarhUgRYsyAnKHixt=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.HTTPTAG+ezjMGVLWCImXFvarhUgRYsyAnKHiBo.get('programcirlceimage')
   if 'poster_default' in ezjMGVLWCImXFvarhUgRYsyAnKHixN:
    ezjMGVLWCImXFvarhUgRYsyAnKHixN =ezjMGVLWCImXFvarhUgRYsyAnKHixk
    ezjMGVLWCImXFvarhUgRYsyAnKHixt=''
   ezjMGVLWCImXFvarhUgRYsyAnKHiBQ['saveinfo']['thumbnail']['poster']=ezjMGVLWCImXFvarhUgRYsyAnKHixN
   ezjMGVLWCImXFvarhUgRYsyAnKHiBQ['saveinfo']['thumbnail']['thumb']=ezjMGVLWCImXFvarhUgRYsyAnKHixk
   ezjMGVLWCImXFvarhUgRYsyAnKHiBQ['saveinfo']['thumbnail']['clearlogo']=ezjMGVLWCImXFvarhUgRYsyAnKHixt
   ezjMGVLWCImXFvarhUgRYsyAnKHiBQ['saveinfo']['thumbnail']['fanart']=ezjMGVLWCImXFvarhUgRYsyAnKHixk
  else:
   ezjMGVLWCImXFvarhUgRYsyAnKHiPk=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.API_DOMAIN+'/movie/contents/'+ezjMGVLWCImXFvarhUgRYsyAnKHiud 
   ezjMGVLWCImXFvarhUgRYsyAnKHiPS=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.GetDefaultParams(login=ezjMGVLWCImXFvarhUgRYsyAnKHiBd)
   ezjMGVLWCImXFvarhUgRYsyAnKHiPD=ezjMGVLWCImXFvarhUgRYsyAnKHiPx.callRequestCookies('Get',ezjMGVLWCImXFvarhUgRYsyAnKHiPk,payload=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,params=ezjMGVLWCImXFvarhUgRYsyAnKHiPS,headers=ezjMGVLWCImXFvarhUgRYsyAnKHiBf,cookies=ezjMGVLWCImXFvarhUgRYsyAnKHiBf)
   ezjMGVLWCImXFvarhUgRYsyAnKHiPf=json.loads(ezjMGVLWCImXFvarhUgRYsyAnKHiPD.text)
   if not('title' in ezjMGVLWCImXFvarhUgRYsyAnKHiPf):return{}
   ezjMGVLWCImXFvarhUgRYsyAnKHiBo=ezjMGVLWCImXFvarhUgRYsyAnKHiPf
   ezjMGVLWCImXFvarhUgRYsyAnKHiBp=ezjMGVLWCImXFvarhUgRYsyAnKHiBo.get('title')
   ezjMGVLWCImXFvarhUgRYsyAnKHiBQ['saveinfo']['infoLabels']['title']=ezjMGVLWCImXFvarhUgRYsyAnKHiBp
   if ezjMGVLWCImXFvarhUgRYsyAnKHiBo.get('targetage')=='18' or ezjMGVLWCImXFvarhUgRYsyAnKHiBo.get('targetage')=='19' or ezjMGVLWCImXFvarhUgRYsyAnKHiBo.get('targetage')=='21':
    ezjMGVLWCImXFvarhUgRYsyAnKHiBp +=u' (%s)'%(ezjMGVLWCImXFvarhUgRYsyAnKHiBo.get('targetage'))
   ezjMGVLWCImXFvarhUgRYsyAnKHiBQ['saveinfo']['title'] =ezjMGVLWCImXFvarhUgRYsyAnKHiBp
   ezjMGVLWCImXFvarhUgRYsyAnKHiBQ['saveinfo']['infoLabels']['mpaa'] =ezjMGVLWCImXFvarhUgRYsyAnKHiBo.get('targetage')
   ezjMGVLWCImXFvarhUgRYsyAnKHiBQ['saveinfo']['infoLabels']['plot'] =ezjMGVLWCImXFvarhUgRYsyAnKHiBo.get('synopsis').replace('<br>','\n')
   ezjMGVLWCImXFvarhUgRYsyAnKHiBQ['saveinfo']['infoLabels']['duration']=ezjMGVLWCImXFvarhUgRYsyAnKHiBo.get('playtime')
   ezjMGVLWCImXFvarhUgRYsyAnKHiBQ['saveinfo']['infoLabels']['country']=ezjMGVLWCImXFvarhUgRYsyAnKHiBo.get('country')
   ezjMGVLWCImXFvarhUgRYsyAnKHiBQ['saveinfo']['infoLabels']['studio'] =ezjMGVLWCImXFvarhUgRYsyAnKHiBo.get('cpname')
   if ezjMGVLWCImXFvarhUgRYsyAnKHiBo.get('releasedate')!='':
    ezjMGVLWCImXFvarhUgRYsyAnKHiBQ['saveinfo']['infoLabels']['year'] =ezjMGVLWCImXFvarhUgRYsyAnKHiBo.get('releasedate')[:4]
    ezjMGVLWCImXFvarhUgRYsyAnKHiBQ['saveinfo']['infoLabels']['premiered']=ezjMGVLWCImXFvarhUgRYsyAnKHiBo.get('releasedate')
   ezjMGVLWCImXFvarhUgRYsyAnKHiBO=[]
   for ezjMGVLWCImXFvarhUgRYsyAnKHiBl in ezjMGVLWCImXFvarhUgRYsyAnKHiBo['actors']['list']:ezjMGVLWCImXFvarhUgRYsyAnKHiBO.append(ezjMGVLWCImXFvarhUgRYsyAnKHiBl.get('text'))
   if ezjMGVLWCImXFvarhUgRYsyAnKHiTJ(ezjMGVLWCImXFvarhUgRYsyAnKHiBO)>0:
    if ezjMGVLWCImXFvarhUgRYsyAnKHiBO[0]!='':ezjMGVLWCImXFvarhUgRYsyAnKHiBQ['saveinfo']['infoLabels']['cast']=ezjMGVLWCImXFvarhUgRYsyAnKHiBO
   ezjMGVLWCImXFvarhUgRYsyAnKHiBN=[]
   for ezjMGVLWCImXFvarhUgRYsyAnKHiBk in ezjMGVLWCImXFvarhUgRYsyAnKHiBo['directors']['list']:ezjMGVLWCImXFvarhUgRYsyAnKHiBN.append(ezjMGVLWCImXFvarhUgRYsyAnKHiBk.get('text'))
   if ezjMGVLWCImXFvarhUgRYsyAnKHiTJ(ezjMGVLWCImXFvarhUgRYsyAnKHiBN)>0:
    if ezjMGVLWCImXFvarhUgRYsyAnKHiBN[0]!='':ezjMGVLWCImXFvarhUgRYsyAnKHiBQ['saveinfo']['infoLabels']['director']=ezjMGVLWCImXFvarhUgRYsyAnKHiBN
   ezjMGVLWCImXFvarhUgRYsyAnKHiuB=[]
   for ezjMGVLWCImXFvarhUgRYsyAnKHiBt in ezjMGVLWCImXFvarhUgRYsyAnKHiBo['genre']['list']:ezjMGVLWCImXFvarhUgRYsyAnKHiuB.append(ezjMGVLWCImXFvarhUgRYsyAnKHiBt.get('text'))
   if ezjMGVLWCImXFvarhUgRYsyAnKHiTJ(ezjMGVLWCImXFvarhUgRYsyAnKHiuB)>0:
    if ezjMGVLWCImXFvarhUgRYsyAnKHiuB[0]!='':ezjMGVLWCImXFvarhUgRYsyAnKHiBQ['saveinfo']['infoLabels']['genre']=ezjMGVLWCImXFvarhUgRYsyAnKHiuB
   ezjMGVLWCImXFvarhUgRYsyAnKHixN ='https://%s'%ezjMGVLWCImXFvarhUgRYsyAnKHiBo['image']
   ezjMGVLWCImXFvarhUgRYsyAnKHiBQ['saveinfo']['thumbnail']['poster'] =ezjMGVLWCImXFvarhUgRYsyAnKHixN
   ezjMGVLWCImXFvarhUgRYsyAnKHiBQ['saveinfo']['thumbnail']['thumb'] =ezjMGVLWCImXFvarhUgRYsyAnKHixN
  return ezjMGVLWCImXFvarhUgRYsyAnKHiBQ
# Created by pyminifier (https://github.com/liftoff/pyminifier)
