__author__="NightRain"
VBKGCJOrAgvNRsQXhiUpPMneELkcyq=object
VBKGCJOrAgvNRsQXhiUpPMneELkcyD=None
VBKGCJOrAgvNRsQXhiUpPMneELkcyl=False
VBKGCJOrAgvNRsQXhiUpPMneELkcyF=open
VBKGCJOrAgvNRsQXhiUpPMneELkcyW=True
VBKGCJOrAgvNRsQXhiUpPMneELkcyw=range
VBKGCJOrAgvNRsQXhiUpPMneELkcyx=str
VBKGCJOrAgvNRsQXhiUpPMneELkcyz=Exception
VBKGCJOrAgvNRsQXhiUpPMneELkcyt=print
VBKGCJOrAgvNRsQXhiUpPMneELkcyo=dict
VBKGCJOrAgvNRsQXhiUpPMneELkcyI=int
VBKGCJOrAgvNRsQXhiUpPMneELkcyu=len
import urllib
import re
import json
import sys
import requests
import datetime
import base64
class VBKGCJOrAgvNRsQXhiUpPMneELkcTd(VBKGCJOrAgvNRsQXhiUpPMneELkcyq):
 def __init__(VBKGCJOrAgvNRsQXhiUpPMneELkcTH):
  VBKGCJOrAgvNRsQXhiUpPMneELkcTH.API_DOMAIN='https://apis.wavve.com'
  VBKGCJOrAgvNRsQXhiUpPMneELkcTH.WV ={}
  VBKGCJOrAgvNRsQXhiUpPMneELkcTH.Init_WV_Total()
  VBKGCJOrAgvNRsQXhiUpPMneELkcTH.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  VBKGCJOrAgvNRsQXhiUpPMneELkcTH.DEVICE ='pc'
  VBKGCJOrAgvNRsQXhiUpPMneELkcTH.DRM ='wm'
  VBKGCJOrAgvNRsQXhiUpPMneELkcTH.PARTNER ='pooq'
  VBKGCJOrAgvNRsQXhiUpPMneELkcTH.POOQZONE ='none'
  VBKGCJOrAgvNRsQXhiUpPMneELkcTH.REGION ='kor'
  VBKGCJOrAgvNRsQXhiUpPMneELkcTH.TARGETAGE ='all'
  VBKGCJOrAgvNRsQXhiUpPMneELkcTH.HTTPTAG ='https://'
  VBKGCJOrAgvNRsQXhiUpPMneELkcTH.LIST_LIMIT=30 
  VBKGCJOrAgvNRsQXhiUpPMneELkcTH.EP_LIMIT =30 
  VBKGCJOrAgvNRsQXhiUpPMneELkcTH.MV_LIMIT =24 
  VBKGCJOrAgvNRsQXhiUpPMneELkcTH.SEARCH_LIMIT=20 
  VBKGCJOrAgvNRsQXhiUpPMneELkcTH.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36'
  VBKGCJOrAgvNRsQXhiUpPMneELkcTH.DEFAULT_HEADER={'user-agent':VBKGCJOrAgvNRsQXhiUpPMneELkcTH.USER_AGENT}
  VBKGCJOrAgvNRsQXhiUpPMneELkcTH.KodiVersion=20
 def Init_WV_Total(VBKGCJOrAgvNRsQXhiUpPMneELkcTH):
  VBKGCJOrAgvNRsQXhiUpPMneELkcTH.WV={'account':{},'cookies':{},}
 def callRequestCookies(VBKGCJOrAgvNRsQXhiUpPMneELkcTH,jobtype,VBKGCJOrAgvNRsQXhiUpPMneELkcTY,payload=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,params=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,headers=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,cookies=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,redirects=VBKGCJOrAgvNRsQXhiUpPMneELkcyl):
  VBKGCJOrAgvNRsQXhiUpPMneELkcTa=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.DEFAULT_HEADER
  if headers:VBKGCJOrAgvNRsQXhiUpPMneELkcTa.update(headers)
  if jobtype=='Get':
   VBKGCJOrAgvNRsQXhiUpPMneELkcTf=requests.get(VBKGCJOrAgvNRsQXhiUpPMneELkcTY,params=params,headers=VBKGCJOrAgvNRsQXhiUpPMneELkcTa,cookies=cookies,allow_redirects=redirects)
  else:
   VBKGCJOrAgvNRsQXhiUpPMneELkcTf=requests.post(VBKGCJOrAgvNRsQXhiUpPMneELkcTY,json=payload,params=params,headers=VBKGCJOrAgvNRsQXhiUpPMneELkcTa,cookies=cookies,allow_redirects=redirects)
  return VBKGCJOrAgvNRsQXhiUpPMneELkcTf
 def JsonFile_Save(VBKGCJOrAgvNRsQXhiUpPMneELkcTH,filename,VBKGCJOrAgvNRsQXhiUpPMneELkcTy):
  if filename=='':return VBKGCJOrAgvNRsQXhiUpPMneELkcyl
  try:
   fp=VBKGCJOrAgvNRsQXhiUpPMneELkcyF(filename,'w',-1,'utf-8')
   json.dump(VBKGCJOrAgvNRsQXhiUpPMneELkcTy,fp,indent=4,ensure_ascii=VBKGCJOrAgvNRsQXhiUpPMneELkcyl)
   fp.close()
  except:
   return VBKGCJOrAgvNRsQXhiUpPMneELkcyl
  return VBKGCJOrAgvNRsQXhiUpPMneELkcyW
 def JsonFile_Load(VBKGCJOrAgvNRsQXhiUpPMneELkcTH,filename):
  if filename=='':return{}
  try:
   fp=VBKGCJOrAgvNRsQXhiUpPMneELkcyF(filename,'r',-1,'utf-8')
   VBKGCJOrAgvNRsQXhiUpPMneELkcTj=json.load(fp)
   fp.close()
  except:
   return{}
  return VBKGCJOrAgvNRsQXhiUpPMneELkcTj
 def Save_session_acount(VBKGCJOrAgvNRsQXhiUpPMneELkcTH,VBKGCJOrAgvNRsQXhiUpPMneELkcTm,VBKGCJOrAgvNRsQXhiUpPMneELkcTq,VBKGCJOrAgvNRsQXhiUpPMneELkcTD):
  VBKGCJOrAgvNRsQXhiUpPMneELkcTH.WV['account']['wvid']=base64.standard_b64encode(VBKGCJOrAgvNRsQXhiUpPMneELkcTm.encode()).decode('utf-8')
  VBKGCJOrAgvNRsQXhiUpPMneELkcTH.WV['account']['wvpw']=base64.standard_b64encode(VBKGCJOrAgvNRsQXhiUpPMneELkcTq.encode()).decode('utf-8')
  VBKGCJOrAgvNRsQXhiUpPMneELkcTH.WV['account']['wvpf']=VBKGCJOrAgvNRsQXhiUpPMneELkcTD 
 def Load_session_acount(VBKGCJOrAgvNRsQXhiUpPMneELkcTH):
  try:
   VBKGCJOrAgvNRsQXhiUpPMneELkcTm=base64.standard_b64decode(VBKGCJOrAgvNRsQXhiUpPMneELkcTH.WV['account']['wvid']).decode('utf-8')
   VBKGCJOrAgvNRsQXhiUpPMneELkcTq=base64.standard_b64decode(VBKGCJOrAgvNRsQXhiUpPMneELkcTH.WV['account']['wvpw']).decode('utf-8')
   VBKGCJOrAgvNRsQXhiUpPMneELkcTD=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.WV['account']['wvpf']
  except:
   return '','',0
  return VBKGCJOrAgvNRsQXhiUpPMneELkcTm,VBKGCJOrAgvNRsQXhiUpPMneELkcTq,VBKGCJOrAgvNRsQXhiUpPMneELkcTD
 def GetDefaultParams(VBKGCJOrAgvNRsQXhiUpPMneELkcTH,login=VBKGCJOrAgvNRsQXhiUpPMneELkcyW):
  VBKGCJOrAgvNRsQXhiUpPMneELkcTl={'apikey':VBKGCJOrAgvNRsQXhiUpPMneELkcTH.APIKEY,'credential':VBKGCJOrAgvNRsQXhiUpPMneELkcTH.WV['cookies']['credential']if login else 'none','device':VBKGCJOrAgvNRsQXhiUpPMneELkcTH.DEVICE,'drm':VBKGCJOrAgvNRsQXhiUpPMneELkcTH.DRM,'partner':VBKGCJOrAgvNRsQXhiUpPMneELkcTH.PARTNER,'pooqzone':VBKGCJOrAgvNRsQXhiUpPMneELkcTH.POOQZONE,'region':VBKGCJOrAgvNRsQXhiUpPMneELkcTH.REGION,'targetage':VBKGCJOrAgvNRsQXhiUpPMneELkcTH.TARGETAGE,}
  return VBKGCJOrAgvNRsQXhiUpPMneELkcTl
 def GetDefaultParams_AND(VBKGCJOrAgvNRsQXhiUpPMneELkcTH):
  VBKGCJOrAgvNRsQXhiUpPMneELkcTl={'apikey':'6A87455D54481A536DFB8AD397C5EC4D','credential':VBKGCJOrAgvNRsQXhiUpPMneELkcTH.WV['cookies']['credential'],'device':'ott','drm':VBKGCJOrAgvNRsQXhiUpPMneELkcTH.DRM,'partner':VBKGCJOrAgvNRsQXhiUpPMneELkcTH.PARTNER,'pooqzone':VBKGCJOrAgvNRsQXhiUpPMneELkcTH.POOQZONE,'region':VBKGCJOrAgvNRsQXhiUpPMneELkcTH.REGION,'targetage':VBKGCJOrAgvNRsQXhiUpPMneELkcTH.TARGETAGE,}
  return VBKGCJOrAgvNRsQXhiUpPMneELkcTl
 def GetGUID(VBKGCJOrAgvNRsQXhiUpPMneELkcTH,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   VBKGCJOrAgvNRsQXhiUpPMneELkcTF=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   VBKGCJOrAgvNRsQXhiUpPMneELkcTW=GenerateRandomString(5)
   VBKGCJOrAgvNRsQXhiUpPMneELkcTw=VBKGCJOrAgvNRsQXhiUpPMneELkcTW+media+VBKGCJOrAgvNRsQXhiUpPMneELkcTF
   return VBKGCJOrAgvNRsQXhiUpPMneELkcTw
  def GenerateRandomString(num):
   from random import randint
   VBKGCJOrAgvNRsQXhiUpPMneELkcTx=""
   for i in VBKGCJOrAgvNRsQXhiUpPMneELkcyw(0,num):
    s=VBKGCJOrAgvNRsQXhiUpPMneELkcyx(randint(1,5))
    VBKGCJOrAgvNRsQXhiUpPMneELkcTx+=s
   return VBKGCJOrAgvNRsQXhiUpPMneELkcTx
  if guidType==3:
   VBKGCJOrAgvNRsQXhiUpPMneELkcTw=guid_str
  else:
   VBKGCJOrAgvNRsQXhiUpPMneELkcTw=GenerateID(guid_str)
  VBKGCJOrAgvNRsQXhiUpPMneELkcTz=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.GetHash(VBKGCJOrAgvNRsQXhiUpPMneELkcTw)
  if guidType in[2,3]:
   VBKGCJOrAgvNRsQXhiUpPMneELkcTz='%s-%s-%s-%s-%s'%(VBKGCJOrAgvNRsQXhiUpPMneELkcTz[:8],VBKGCJOrAgvNRsQXhiUpPMneELkcTz[8:12],VBKGCJOrAgvNRsQXhiUpPMneELkcTz[12:16],VBKGCJOrAgvNRsQXhiUpPMneELkcTz[16:20],VBKGCJOrAgvNRsQXhiUpPMneELkcTz[20:])
  return VBKGCJOrAgvNRsQXhiUpPMneELkcTz
 def GetHash(VBKGCJOrAgvNRsQXhiUpPMneELkcTH,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return VBKGCJOrAgvNRsQXhiUpPMneELkcyx(m.hexdigest())
 def CheckQuality(VBKGCJOrAgvNRsQXhiUpPMneELkcTH,sel_qt,qt_list):
  VBKGCJOrAgvNRsQXhiUpPMneELkcTt=0
  for VBKGCJOrAgvNRsQXhiUpPMneELkcTo in qt_list:
   if sel_qt>=VBKGCJOrAgvNRsQXhiUpPMneELkcTo:return VBKGCJOrAgvNRsQXhiUpPMneELkcTo
   VBKGCJOrAgvNRsQXhiUpPMneELkcTt=VBKGCJOrAgvNRsQXhiUpPMneELkcTo
  return VBKGCJOrAgvNRsQXhiUpPMneELkcTt
 def Get_Now_Datetime(VBKGCJOrAgvNRsQXhiUpPMneELkcTH):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(VBKGCJOrAgvNRsQXhiUpPMneELkcTH,in_text):
  VBKGCJOrAgvNRsQXhiUpPMneELkcTu=in_text.replace('&lt;','<').replace('&gt;','>')
  VBKGCJOrAgvNRsQXhiUpPMneELkcTu=VBKGCJOrAgvNRsQXhiUpPMneELkcTu.replace('$O$','')
  VBKGCJOrAgvNRsQXhiUpPMneELkcTu=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',VBKGCJOrAgvNRsQXhiUpPMneELkcTu)
  VBKGCJOrAgvNRsQXhiUpPMneELkcTu=VBKGCJOrAgvNRsQXhiUpPMneELkcTu.lstrip('#')
  return VBKGCJOrAgvNRsQXhiUpPMneELkcTu
 def GetCredential(VBKGCJOrAgvNRsQXhiUpPMneELkcTH,user_id,user_pw,user_pf):
  VBKGCJOrAgvNRsQXhiUpPMneELkcTb=VBKGCJOrAgvNRsQXhiUpPMneELkcyl
  try:
   VBKGCJOrAgvNRsQXhiUpPMneELkcTY=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.API_DOMAIN+ '/login'
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.GetDefaultParams(login=VBKGCJOrAgvNRsQXhiUpPMneELkcyl)
   VBKGCJOrAgvNRsQXhiUpPMneELkcdT={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   VBKGCJOrAgvNRsQXhiUpPMneELkcdH=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.callRequestCookies('Post',VBKGCJOrAgvNRsQXhiUpPMneELkcTY,payload=VBKGCJOrAgvNRsQXhiUpPMneELkcdT,params=VBKGCJOrAgvNRsQXhiUpPMneELkcTl,headers=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,cookies=VBKGCJOrAgvNRsQXhiUpPMneELkcyD)
   VBKGCJOrAgvNRsQXhiUpPMneELkcda=json.loads(VBKGCJOrAgvNRsQXhiUpPMneELkcdH.text)
   VBKGCJOrAgvNRsQXhiUpPMneELkcTH.WV['cookies']['credential']=VBKGCJOrAgvNRsQXhiUpPMneELkcda['credential']
   if user_pf!=0:
    VBKGCJOrAgvNRsQXhiUpPMneELkcdT={'id':VBKGCJOrAgvNRsQXhiUpPMneELkcTH.WV['cookies']['credential'],'password':'','profile':VBKGCJOrAgvNRsQXhiUpPMneELkcyx(user_pf),'pushid':'','type':'credential'}
    VBKGCJOrAgvNRsQXhiUpPMneELkcTl =VBKGCJOrAgvNRsQXhiUpPMneELkcTH.GetDefaultParams(login=VBKGCJOrAgvNRsQXhiUpPMneELkcyW) 
    VBKGCJOrAgvNRsQXhiUpPMneELkcdH=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.callRequestCookies('Post',VBKGCJOrAgvNRsQXhiUpPMneELkcTY,payload=VBKGCJOrAgvNRsQXhiUpPMneELkcdT,params=VBKGCJOrAgvNRsQXhiUpPMneELkcTl,headers=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,cookies=VBKGCJOrAgvNRsQXhiUpPMneELkcyD)
    VBKGCJOrAgvNRsQXhiUpPMneELkcda=json.loads(VBKGCJOrAgvNRsQXhiUpPMneELkcdH.text)
    VBKGCJOrAgvNRsQXhiUpPMneELkcTH.WV['cookies']['credential']=VBKGCJOrAgvNRsQXhiUpPMneELkcda['credential']
   VBKGCJOrAgvNRsQXhiUpPMneELkcdf=user_id+VBKGCJOrAgvNRsQXhiUpPMneELkcyx(user_pf) 
   VBKGCJOrAgvNRsQXhiUpPMneELkcTH.WV['cookies']['uuid']=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.GetGUID(guid_str=VBKGCJOrAgvNRsQXhiUpPMneELkcdf,guidType=3)
   VBKGCJOrAgvNRsQXhiUpPMneELkcTb=VBKGCJOrAgvNRsQXhiUpPMneELkcyW
  except VBKGCJOrAgvNRsQXhiUpPMneELkcyz as exception:
   VBKGCJOrAgvNRsQXhiUpPMneELkcyt(exception)
   VBKGCJOrAgvNRsQXhiUpPMneELkcTH.Init_WV_Total()
  return VBKGCJOrAgvNRsQXhiUpPMneELkcTb
 def GetIssue(VBKGCJOrAgvNRsQXhiUpPMneELkcTH):
  VBKGCJOrAgvNRsQXhiUpPMneELkcdy=VBKGCJOrAgvNRsQXhiUpPMneELkcyl
  try:
   VBKGCJOrAgvNRsQXhiUpPMneELkcTY=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.API_DOMAIN+'/guid/issue'
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.GetDefaultParams()
   VBKGCJOrAgvNRsQXhiUpPMneELkcdH=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.callRequestCookies('Get',VBKGCJOrAgvNRsQXhiUpPMneELkcTY,payload=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,params=VBKGCJOrAgvNRsQXhiUpPMneELkcTl,headers=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,cookies=VBKGCJOrAgvNRsQXhiUpPMneELkcyD)
   VBKGCJOrAgvNRsQXhiUpPMneELkcda=json.loads(VBKGCJOrAgvNRsQXhiUpPMneELkcdH.text)
   VBKGCJOrAgvNRsQXhiUpPMneELkcdS=VBKGCJOrAgvNRsQXhiUpPMneELkcda['guid']
   VBKGCJOrAgvNRsQXhiUpPMneELkcdj=VBKGCJOrAgvNRsQXhiUpPMneELkcda['guidtimestamp']
   if VBKGCJOrAgvNRsQXhiUpPMneELkcdS:VBKGCJOrAgvNRsQXhiUpPMneELkcdy=VBKGCJOrAgvNRsQXhiUpPMneELkcyW
  except VBKGCJOrAgvNRsQXhiUpPMneELkcyz as exception:
   VBKGCJOrAgvNRsQXhiUpPMneELkcyt(exception)
   VBKGCJOrAgvNRsQXhiUpPMneELkcdS='none'
   VBKGCJOrAgvNRsQXhiUpPMneELkcdj='none' 
  VBKGCJOrAgvNRsQXhiUpPMneELkcTH.guid=VBKGCJOrAgvNRsQXhiUpPMneELkcdS
  VBKGCJOrAgvNRsQXhiUpPMneELkcTH.guidtimestamp=VBKGCJOrAgvNRsQXhiUpPMneELkcdj
  return VBKGCJOrAgvNRsQXhiUpPMneELkcdy
 def Baseapi_Parse(VBKGCJOrAgvNRsQXhiUpPMneELkcTH,VBKGCJOrAgvNRsQXhiUpPMneELkcdl):
  try:
   VBKGCJOrAgvNRsQXhiUpPMneELkcdm =urllib.parse.urlsplit(VBKGCJOrAgvNRsQXhiUpPMneELkcdl)
   if VBKGCJOrAgvNRsQXhiUpPMneELkcdm.netloc=='':
    VBKGCJOrAgvNRsQXhiUpPMneELkcTY=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.HTTPTAG+VBKGCJOrAgvNRsQXhiUpPMneELkcdm.netloc+VBKGCJOrAgvNRsQXhiUpPMneELkcdm.path
   else:
    VBKGCJOrAgvNRsQXhiUpPMneELkcTY=VBKGCJOrAgvNRsQXhiUpPMneELkcdm.scheme+'://'+VBKGCJOrAgvNRsQXhiUpPMneELkcdm.netloc+VBKGCJOrAgvNRsQXhiUpPMneELkcdm.path
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl=VBKGCJOrAgvNRsQXhiUpPMneELkcyo(urllib.parse.parse_qsl(VBKGCJOrAgvNRsQXhiUpPMneELkcdm.query))
  except VBKGCJOrAgvNRsQXhiUpPMneELkcyz as exception:
   VBKGCJOrAgvNRsQXhiUpPMneELkcyt(exception)
   return '',{}
  return VBKGCJOrAgvNRsQXhiUpPMneELkcTY,VBKGCJOrAgvNRsQXhiUpPMneELkcTl
 def GetSupermultiUrl(VBKGCJOrAgvNRsQXhiUpPMneELkcTH,sCode,sIndex='0'):
  try:
   VBKGCJOrAgvNRsQXhiUpPMneELkcTY=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.API_DOMAIN+'/cf/supermultisections/'+sCode
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.GetDefaultParams(login=VBKGCJOrAgvNRsQXhiUpPMneELkcyl)
   VBKGCJOrAgvNRsQXhiUpPMneELkcdH=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.callRequestCookies('Get',VBKGCJOrAgvNRsQXhiUpPMneELkcTY,payload=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,params=VBKGCJOrAgvNRsQXhiUpPMneELkcTl,headers=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,cookies=VBKGCJOrAgvNRsQXhiUpPMneELkcyD)
   VBKGCJOrAgvNRsQXhiUpPMneELkcda=json.loads(VBKGCJOrAgvNRsQXhiUpPMneELkcdH.text)
   VBKGCJOrAgvNRsQXhiUpPMneELkcdq=VBKGCJOrAgvNRsQXhiUpPMneELkcda['multisectionlist'][VBKGCJOrAgvNRsQXhiUpPMneELkcyI(sIndex)]['eventlist'][1]['url']
  except VBKGCJOrAgvNRsQXhiUpPMneELkcyz as exception:
   VBKGCJOrAgvNRsQXhiUpPMneELkcyt(exception)
   return ''
  return VBKGCJOrAgvNRsQXhiUpPMneELkcdq
 def Get_LiveCatagory_List(VBKGCJOrAgvNRsQXhiUpPMneELkcTH,sCode,sIndex='0'):
  VBKGCJOrAgvNRsQXhiUpPMneELkcdD=[]
  VBKGCJOrAgvNRsQXhiUpPMneELkcdl =VBKGCJOrAgvNRsQXhiUpPMneELkcTH.GetSupermultiUrl(sCode,sIndex)
  (VBKGCJOrAgvNRsQXhiUpPMneELkcTY,VBKGCJOrAgvNRsQXhiUpPMneELkcTl)=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.Baseapi_Parse(VBKGCJOrAgvNRsQXhiUpPMneELkcdl)
  if VBKGCJOrAgvNRsQXhiUpPMneELkcTY=='':return VBKGCJOrAgvNRsQXhiUpPMneELkcdD,''
  try:
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl.update(VBKGCJOrAgvNRsQXhiUpPMneELkcTH.GetDefaultParams(login=VBKGCJOrAgvNRsQXhiUpPMneELkcyl))
   VBKGCJOrAgvNRsQXhiUpPMneELkcdH=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.callRequestCookies('Get',VBKGCJOrAgvNRsQXhiUpPMneELkcTY,payload=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,params=VBKGCJOrAgvNRsQXhiUpPMneELkcTl,headers=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,cookies=VBKGCJOrAgvNRsQXhiUpPMneELkcyD)
   VBKGCJOrAgvNRsQXhiUpPMneELkcda=json.loads(VBKGCJOrAgvNRsQXhiUpPMneELkcdH.text)
   if not('filter_item_list' in VBKGCJOrAgvNRsQXhiUpPMneELkcda['filter']['filterlist'][0]):return[],''
   VBKGCJOrAgvNRsQXhiUpPMneELkcdW=VBKGCJOrAgvNRsQXhiUpPMneELkcda['filter']['filterlist'][0]['filter_item_list']
   for VBKGCJOrAgvNRsQXhiUpPMneELkcdw in VBKGCJOrAgvNRsQXhiUpPMneELkcdW:
    VBKGCJOrAgvNRsQXhiUpPMneELkcdx={'title':VBKGCJOrAgvNRsQXhiUpPMneELkcdw['title'],'genre':VBKGCJOrAgvNRsQXhiUpPMneELkcdw['api_parameters'][VBKGCJOrAgvNRsQXhiUpPMneELkcdw['api_parameters'].index('=')+1:]}
    VBKGCJOrAgvNRsQXhiUpPMneELkcdD.append(VBKGCJOrAgvNRsQXhiUpPMneELkcdx)
  except VBKGCJOrAgvNRsQXhiUpPMneELkcyz as exception:
   VBKGCJOrAgvNRsQXhiUpPMneELkcyt(exception)
   return[],''
  return VBKGCJOrAgvNRsQXhiUpPMneELkcdD,VBKGCJOrAgvNRsQXhiUpPMneELkcdl
 def Get_MainCatagory_List(VBKGCJOrAgvNRsQXhiUpPMneELkcTH,sCode,sIndex,sType):
  VBKGCJOrAgvNRsQXhiUpPMneELkcdD=[]
  VBKGCJOrAgvNRsQXhiUpPMneELkcTY='https://apis.wavve.com/es/category/launcher-band'
  VBKGCJOrAgvNRsQXhiUpPMneELkcTl={'uitype':sCode,'uiparent':'GN52-'+sCode,'uirank':sIndex,'broadcastid':sCode,'offset':'0','limit':'20','uicode':sCode,'mtype':'N','ctype':sType,'orderby':'default',}
  try:
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl.update(VBKGCJOrAgvNRsQXhiUpPMneELkcTH.GetDefaultParams(login=VBKGCJOrAgvNRsQXhiUpPMneELkcyl))
   VBKGCJOrAgvNRsQXhiUpPMneELkcdH=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.callRequestCookies('Get',VBKGCJOrAgvNRsQXhiUpPMneELkcTY,payload=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,params=VBKGCJOrAgvNRsQXhiUpPMneELkcTl,headers=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,cookies=VBKGCJOrAgvNRsQXhiUpPMneELkcyD)
   VBKGCJOrAgvNRsQXhiUpPMneELkcda=json.loads(VBKGCJOrAgvNRsQXhiUpPMneELkcdH.text)
   if not('celllist' in VBKGCJOrAgvNRsQXhiUpPMneELkcda['band']):return[]
   VBKGCJOrAgvNRsQXhiUpPMneELkcdW=VBKGCJOrAgvNRsQXhiUpPMneELkcda['band']['celllist']
   for VBKGCJOrAgvNRsQXhiUpPMneELkcdw in VBKGCJOrAgvNRsQXhiUpPMneELkcdW:
    VBKGCJOrAgvNRsQXhiUpPMneELkcdz =VBKGCJOrAgvNRsQXhiUpPMneELkcdw['event_list'][1]['url']
    (VBKGCJOrAgvNRsQXhiUpPMneELkcdt,VBKGCJOrAgvNRsQXhiUpPMneELkcdo)=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.Baseapi_Parse(VBKGCJOrAgvNRsQXhiUpPMneELkcdz)
    VBKGCJOrAgvNRsQXhiUpPMneELkcdx={'title':VBKGCJOrAgvNRsQXhiUpPMneELkcdw['title_list'][0]['text'],'suburl':VBKGCJOrAgvNRsQXhiUpPMneELkcdt,'subapi':VBKGCJOrAgvNRsQXhiUpPMneELkcdo.get('api'),'subtype':'catagory' if VBKGCJOrAgvNRsQXhiUpPMneELkcdo else 'supersection'}
    VBKGCJOrAgvNRsQXhiUpPMneELkcdD.append(VBKGCJOrAgvNRsQXhiUpPMneELkcdx)
  except VBKGCJOrAgvNRsQXhiUpPMneELkcyz as exception:
   VBKGCJOrAgvNRsQXhiUpPMneELkcyt(exception)
   return[]
  return VBKGCJOrAgvNRsQXhiUpPMneELkcdD
 def Get_SuperMultiSection_List(VBKGCJOrAgvNRsQXhiUpPMneELkcTH,subapi_text):
  VBKGCJOrAgvNRsQXhiUpPMneELkcdD=[]
  if '/multiband/' in subapi_text: 
   VBKGCJOrAgvNRsQXhiUpPMneELkcTY=subapi_text 
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl={'client':'40'}
  else:
   VBKGCJOrAgvNRsQXhiUpPMneELkcTY=subapi_text 
   VBKGCJOrAgvNRsQXhiUpPMneELkcTY=VBKGCJOrAgvNRsQXhiUpPMneELkcTY.replace('www.wavve.com','apis.wavve.com').replace('supermultisection','v1/multiband')
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl={}
  try:
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl.update(VBKGCJOrAgvNRsQXhiUpPMneELkcTH.GetDefaultParams(login=VBKGCJOrAgvNRsQXhiUpPMneELkcyl))
   VBKGCJOrAgvNRsQXhiUpPMneELkcdH=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.callRequestCookies('Get',VBKGCJOrAgvNRsQXhiUpPMneELkcTY,payload=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,params=VBKGCJOrAgvNRsQXhiUpPMneELkcTl,headers=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,cookies=VBKGCJOrAgvNRsQXhiUpPMneELkcyD)
   VBKGCJOrAgvNRsQXhiUpPMneELkcda=json.loads(VBKGCJOrAgvNRsQXhiUpPMneELkcdH.text)
   if not('multisectionlist' in VBKGCJOrAgvNRsQXhiUpPMneELkcda):return[]
   VBKGCJOrAgvNRsQXhiUpPMneELkcdW=VBKGCJOrAgvNRsQXhiUpPMneELkcda['multisectionlist']
   for VBKGCJOrAgvNRsQXhiUpPMneELkcdw in VBKGCJOrAgvNRsQXhiUpPMneELkcdW:
    VBKGCJOrAgvNRsQXhiUpPMneELkcdI=VBKGCJOrAgvNRsQXhiUpPMneELkcdw['title']
    if VBKGCJOrAgvNRsQXhiUpPMneELkcyu(VBKGCJOrAgvNRsQXhiUpPMneELkcdI)==0:continue
    if VBKGCJOrAgvNRsQXhiUpPMneELkcdI=='minor':continue
    if re.search(u'베너',VBKGCJOrAgvNRsQXhiUpPMneELkcdI):continue
    if re.search(u'배너',VBKGCJOrAgvNRsQXhiUpPMneELkcdI):continue 
    if VBKGCJOrAgvNRsQXhiUpPMneELkcdw['force_refresh']=='y':continue
    if VBKGCJOrAgvNRsQXhiUpPMneELkcyu(VBKGCJOrAgvNRsQXhiUpPMneELkcdw['eventlist'])>=3:
     VBKGCJOrAgvNRsQXhiUpPMneELkcdo =VBKGCJOrAgvNRsQXhiUpPMneELkcdw['eventlist'][2]['url']
    else:
     VBKGCJOrAgvNRsQXhiUpPMneELkcdo =VBKGCJOrAgvNRsQXhiUpPMneELkcdw['eventlist'][1]['url']
    VBKGCJOrAgvNRsQXhiUpPMneELkcdu=VBKGCJOrAgvNRsQXhiUpPMneELkcdw['cell_type']
    if VBKGCJOrAgvNRsQXhiUpPMneELkcdu=='band_2':
     if VBKGCJOrAgvNRsQXhiUpPMneELkcdo.find('channellist=')>=0:
      VBKGCJOrAgvNRsQXhiUpPMneELkcdu='band_live'
    VBKGCJOrAgvNRsQXhiUpPMneELkcdx={'title':VBKGCJOrAgvNRsQXhiUpPMneELkcTH.Get_ChangeText(VBKGCJOrAgvNRsQXhiUpPMneELkcdI),'subapi':VBKGCJOrAgvNRsQXhiUpPMneELkcdo,'cell_type':VBKGCJOrAgvNRsQXhiUpPMneELkcdu}
    VBKGCJOrAgvNRsQXhiUpPMneELkcdD.append(VBKGCJOrAgvNRsQXhiUpPMneELkcdx)
  except VBKGCJOrAgvNRsQXhiUpPMneELkcyz as exception:
   VBKGCJOrAgvNRsQXhiUpPMneELkcyt(exception)
   return[]
  return VBKGCJOrAgvNRsQXhiUpPMneELkcdD
 def Get_BandLiveSection_List(VBKGCJOrAgvNRsQXhiUpPMneELkcTH,VBKGCJOrAgvNRsQXhiUpPMneELkcdl,page_int=1):
  VBKGCJOrAgvNRsQXhiUpPMneELkcdb=[]
  VBKGCJOrAgvNRsQXhiUpPMneELkcdY=VBKGCJOrAgvNRsQXhiUpPMneELkcHS=1
  VBKGCJOrAgvNRsQXhiUpPMneELkcHT=VBKGCJOrAgvNRsQXhiUpPMneELkcyl
  try:
   (VBKGCJOrAgvNRsQXhiUpPMneELkcTY,VBKGCJOrAgvNRsQXhiUpPMneELkcTl)=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.Baseapi_Parse(VBKGCJOrAgvNRsQXhiUpPMneELkcdl)
  except VBKGCJOrAgvNRsQXhiUpPMneELkcyz as exception:
   VBKGCJOrAgvNRsQXhiUpPMneELkcyt(exception)
   return[],VBKGCJOrAgvNRsQXhiUpPMneELkcyl
  try:
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl['limit']=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.LIST_LIMIT
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl['offset']=VBKGCJOrAgvNRsQXhiUpPMneELkcyx((page_int-1)*VBKGCJOrAgvNRsQXhiUpPMneELkcTH.LIST_LIMIT)
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl.update(VBKGCJOrAgvNRsQXhiUpPMneELkcTH.GetDefaultParams(login=VBKGCJOrAgvNRsQXhiUpPMneELkcyl))
   VBKGCJOrAgvNRsQXhiUpPMneELkcdH=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.callRequestCookies('Get',VBKGCJOrAgvNRsQXhiUpPMneELkcTY,payload=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,params=VBKGCJOrAgvNRsQXhiUpPMneELkcTl,headers=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,cookies=VBKGCJOrAgvNRsQXhiUpPMneELkcyD)
   VBKGCJOrAgvNRsQXhiUpPMneELkcda=json.loads(VBKGCJOrAgvNRsQXhiUpPMneELkcdH.text)
   if not('celllist' in VBKGCJOrAgvNRsQXhiUpPMneELkcda['cell_toplist']):return[],VBKGCJOrAgvNRsQXhiUpPMneELkcyl
   VBKGCJOrAgvNRsQXhiUpPMneELkcdW=VBKGCJOrAgvNRsQXhiUpPMneELkcda['cell_toplist']['celllist']
   for VBKGCJOrAgvNRsQXhiUpPMneELkcdw in VBKGCJOrAgvNRsQXhiUpPMneELkcdW:
    VBKGCJOrAgvNRsQXhiUpPMneELkcHd =VBKGCJOrAgvNRsQXhiUpPMneELkcdw['event_list'][1]['url']
    VBKGCJOrAgvNRsQXhiUpPMneELkcHa=urllib.parse.urlsplit(VBKGCJOrAgvNRsQXhiUpPMneELkcHd).query
    VBKGCJOrAgvNRsQXhiUpPMneELkcHa=VBKGCJOrAgvNRsQXhiUpPMneELkcyo(urllib.parse.parse_qsl(VBKGCJOrAgvNRsQXhiUpPMneELkcHa))
    VBKGCJOrAgvNRsQXhiUpPMneELkcHf='channelid'
    VBKGCJOrAgvNRsQXhiUpPMneELkcHy=VBKGCJOrAgvNRsQXhiUpPMneELkcHa[VBKGCJOrAgvNRsQXhiUpPMneELkcHf]
    VBKGCJOrAgvNRsQXhiUpPMneELkcdx={'studio':VBKGCJOrAgvNRsQXhiUpPMneELkcdw['title_list'][0]['text'],'tvshowtitle':VBKGCJOrAgvNRsQXhiUpPMneELkcTH.Get_ChangeText(VBKGCJOrAgvNRsQXhiUpPMneELkcdw['title_list'][1]['text']),'channelid':VBKGCJOrAgvNRsQXhiUpPMneELkcHy,'age':VBKGCJOrAgvNRsQXhiUpPMneELkcdw.get('age'),'thumbnail':'https://%s'%VBKGCJOrAgvNRsQXhiUpPMneELkcdw.get('thumbnail')}
    VBKGCJOrAgvNRsQXhiUpPMneELkcdb.append(VBKGCJOrAgvNRsQXhiUpPMneELkcdx)
   VBKGCJOrAgvNRsQXhiUpPMneELkcdY=VBKGCJOrAgvNRsQXhiUpPMneELkcyI(VBKGCJOrAgvNRsQXhiUpPMneELkcda['cell_toplist']['pagecount'])
   if VBKGCJOrAgvNRsQXhiUpPMneELkcda['cell_toplist']['count']:VBKGCJOrAgvNRsQXhiUpPMneELkcHS =VBKGCJOrAgvNRsQXhiUpPMneELkcyI(VBKGCJOrAgvNRsQXhiUpPMneELkcda['cell_toplist']['count'])
   else:VBKGCJOrAgvNRsQXhiUpPMneELkcHS=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.LIST_LIMIT*page_int
   VBKGCJOrAgvNRsQXhiUpPMneELkcHT=VBKGCJOrAgvNRsQXhiUpPMneELkcdY>VBKGCJOrAgvNRsQXhiUpPMneELkcHS
  except VBKGCJOrAgvNRsQXhiUpPMneELkcyz as exception:
   VBKGCJOrAgvNRsQXhiUpPMneELkcyt(exception)
   return[],VBKGCJOrAgvNRsQXhiUpPMneELkcyl
  return VBKGCJOrAgvNRsQXhiUpPMneELkcdb,VBKGCJOrAgvNRsQXhiUpPMneELkcHT
 def Get_Band2Section_List(VBKGCJOrAgvNRsQXhiUpPMneELkcTH,VBKGCJOrAgvNRsQXhiUpPMneELkcdl,page_int=1):
  VBKGCJOrAgvNRsQXhiUpPMneELkcHj=[]
  VBKGCJOrAgvNRsQXhiUpPMneELkcdY=VBKGCJOrAgvNRsQXhiUpPMneELkcHS=1
  VBKGCJOrAgvNRsQXhiUpPMneELkcHT=VBKGCJOrAgvNRsQXhiUpPMneELkcyl
  try:
   (VBKGCJOrAgvNRsQXhiUpPMneELkcTY,VBKGCJOrAgvNRsQXhiUpPMneELkcTl)=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.Baseapi_Parse(VBKGCJOrAgvNRsQXhiUpPMneELkcdl)
  except VBKGCJOrAgvNRsQXhiUpPMneELkcyz as exception:
   VBKGCJOrAgvNRsQXhiUpPMneELkcyt(exception)
   return[],VBKGCJOrAgvNRsQXhiUpPMneELkcyl
  try:
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl['came'] ='BandView'
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl['limit']=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.LIST_LIMIT
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl['offset']=VBKGCJOrAgvNRsQXhiUpPMneELkcyx((page_int-1)*VBKGCJOrAgvNRsQXhiUpPMneELkcTH.LIST_LIMIT)
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl.update(VBKGCJOrAgvNRsQXhiUpPMneELkcTH.GetDefaultParams(login=VBKGCJOrAgvNRsQXhiUpPMneELkcyl))
   VBKGCJOrAgvNRsQXhiUpPMneELkcdH=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.callRequestCookies('Get',VBKGCJOrAgvNRsQXhiUpPMneELkcTY,payload=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,params=VBKGCJOrAgvNRsQXhiUpPMneELkcTl,headers=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,cookies=VBKGCJOrAgvNRsQXhiUpPMneELkcyD)
   VBKGCJOrAgvNRsQXhiUpPMneELkcda=json.loads(VBKGCJOrAgvNRsQXhiUpPMneELkcdH.text)
   if not('celllist' in VBKGCJOrAgvNRsQXhiUpPMneELkcda['cell_toplist']):return[],VBKGCJOrAgvNRsQXhiUpPMneELkcyl
   VBKGCJOrAgvNRsQXhiUpPMneELkcdW=VBKGCJOrAgvNRsQXhiUpPMneELkcda['cell_toplist']['celllist']
   for VBKGCJOrAgvNRsQXhiUpPMneELkcdw in VBKGCJOrAgvNRsQXhiUpPMneELkcdW:
    VBKGCJOrAgvNRsQXhiUpPMneELkcHd =VBKGCJOrAgvNRsQXhiUpPMneELkcdw['event_list'][1]['url']
    VBKGCJOrAgvNRsQXhiUpPMneELkcHa=urllib.parse.urlsplit(VBKGCJOrAgvNRsQXhiUpPMneELkcHd).query
    VBKGCJOrAgvNRsQXhiUpPMneELkcHa=VBKGCJOrAgvNRsQXhiUpPMneELkcyo(urllib.parse.parse_qsl(VBKGCJOrAgvNRsQXhiUpPMneELkcHa))
    VBKGCJOrAgvNRsQXhiUpPMneELkcHf='contentid'
    VBKGCJOrAgvNRsQXhiUpPMneELkcHy=VBKGCJOrAgvNRsQXhiUpPMneELkcHa[VBKGCJOrAgvNRsQXhiUpPMneELkcHf]
    VBKGCJOrAgvNRsQXhiUpPMneELkcdx={'programtitle':VBKGCJOrAgvNRsQXhiUpPMneELkcdw['title_list'][0]['text'],'episodetitle':VBKGCJOrAgvNRsQXhiUpPMneELkcTH.Get_ChangeText(VBKGCJOrAgvNRsQXhiUpPMneELkcdw['title_list'][1]['text']),'age':VBKGCJOrAgvNRsQXhiUpPMneELkcdw.get('age'),'thumbnail':VBKGCJOrAgvNRsQXhiUpPMneELkcTH.HTTPTAG+VBKGCJOrAgvNRsQXhiUpPMneELkcdw.get('thumbnail'),'vidtype':VBKGCJOrAgvNRsQXhiUpPMneELkcHf,'videoid':VBKGCJOrAgvNRsQXhiUpPMneELkcHy}
    VBKGCJOrAgvNRsQXhiUpPMneELkcHj.append(VBKGCJOrAgvNRsQXhiUpPMneELkcdx)
   VBKGCJOrAgvNRsQXhiUpPMneELkcdY=VBKGCJOrAgvNRsQXhiUpPMneELkcyI(VBKGCJOrAgvNRsQXhiUpPMneELkcda['cell_toplist']['pagecount'])
   if VBKGCJOrAgvNRsQXhiUpPMneELkcda['cell_toplist']['count']:VBKGCJOrAgvNRsQXhiUpPMneELkcHS =VBKGCJOrAgvNRsQXhiUpPMneELkcyI(VBKGCJOrAgvNRsQXhiUpPMneELkcda['cell_toplist']['count'])
   else:VBKGCJOrAgvNRsQXhiUpPMneELkcHS=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.LIST_LIMIT*page_int
   VBKGCJOrAgvNRsQXhiUpPMneELkcHT=VBKGCJOrAgvNRsQXhiUpPMneELkcdY>VBKGCJOrAgvNRsQXhiUpPMneELkcHS
  except VBKGCJOrAgvNRsQXhiUpPMneELkcyz as exception:
   VBKGCJOrAgvNRsQXhiUpPMneELkcyt(exception)
   return[],VBKGCJOrAgvNRsQXhiUpPMneELkcyl
  return VBKGCJOrAgvNRsQXhiUpPMneELkcHj,VBKGCJOrAgvNRsQXhiUpPMneELkcHT
 def Get_Program_List(VBKGCJOrAgvNRsQXhiUpPMneELkcTH,VBKGCJOrAgvNRsQXhiUpPMneELkcdl,page_int=1,orderby='-'):
  VBKGCJOrAgvNRsQXhiUpPMneELkcHm=[]
  VBKGCJOrAgvNRsQXhiUpPMneELkcdY=VBKGCJOrAgvNRsQXhiUpPMneELkcHS=1
  VBKGCJOrAgvNRsQXhiUpPMneELkcHT=VBKGCJOrAgvNRsQXhiUpPMneELkcyl
  (VBKGCJOrAgvNRsQXhiUpPMneELkcTY,VBKGCJOrAgvNRsQXhiUpPMneELkcTl)=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.Baseapi_Parse(VBKGCJOrAgvNRsQXhiUpPMneELkcdl)
  if VBKGCJOrAgvNRsQXhiUpPMneELkcTY=='':return VBKGCJOrAgvNRsQXhiUpPMneELkcHm,VBKGCJOrAgvNRsQXhiUpPMneELkcHT
  try:
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl['limit'] =VBKGCJOrAgvNRsQXhiUpPMneELkcTH.LIST_LIMIT
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl['offset']=VBKGCJOrAgvNRsQXhiUpPMneELkcyx((page_int-1)*VBKGCJOrAgvNRsQXhiUpPMneELkcTH.LIST_LIMIT)
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl['page'] =VBKGCJOrAgvNRsQXhiUpPMneELkcyx(page_int)
   if VBKGCJOrAgvNRsQXhiUpPMneELkcTl.get('orderby')!='' and VBKGCJOrAgvNRsQXhiUpPMneELkcTl.get('orderby')!='regdatefirst' and orderby!='-':
    VBKGCJOrAgvNRsQXhiUpPMneELkcTl['orderby']=orderby 
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl.update(VBKGCJOrAgvNRsQXhiUpPMneELkcTH.GetDefaultParams(login=VBKGCJOrAgvNRsQXhiUpPMneELkcyl))
   VBKGCJOrAgvNRsQXhiUpPMneELkcdH=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.callRequestCookies('Get',VBKGCJOrAgvNRsQXhiUpPMneELkcTY,payload=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,params=VBKGCJOrAgvNRsQXhiUpPMneELkcTl,headers=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,cookies=VBKGCJOrAgvNRsQXhiUpPMneELkcyD)
   VBKGCJOrAgvNRsQXhiUpPMneELkcda=json.loads(VBKGCJOrAgvNRsQXhiUpPMneELkcdH.text)
   if VBKGCJOrAgvNRsQXhiUpPMneELkcda.get('cell_toplist')not in[{},VBKGCJOrAgvNRsQXhiUpPMneELkcyD,'']:
    VBKGCJOrAgvNRsQXhiUpPMneELkcdW=VBKGCJOrAgvNRsQXhiUpPMneELkcda['cell_toplist']['celllist']
   elif VBKGCJOrAgvNRsQXhiUpPMneELkcda.get('band')not in[{},VBKGCJOrAgvNRsQXhiUpPMneELkcyD,'']:
    VBKGCJOrAgvNRsQXhiUpPMneELkcdW=VBKGCJOrAgvNRsQXhiUpPMneELkcda['band']['celllist']
   else:
    return VBKGCJOrAgvNRsQXhiUpPMneELkcHm,VBKGCJOrAgvNRsQXhiUpPMneELkcHT
   for VBKGCJOrAgvNRsQXhiUpPMneELkcdw in VBKGCJOrAgvNRsQXhiUpPMneELkcdW:
    for VBKGCJOrAgvNRsQXhiUpPMneELkcHq in VBKGCJOrAgvNRsQXhiUpPMneELkcdw['event_list']:
     if VBKGCJOrAgvNRsQXhiUpPMneELkcHq.get('type')=='on-navigation':
      VBKGCJOrAgvNRsQXhiUpPMneELkcHd =VBKGCJOrAgvNRsQXhiUpPMneELkcHq['url']
    VBKGCJOrAgvNRsQXhiUpPMneELkcHa=urllib.parse.urlsplit(VBKGCJOrAgvNRsQXhiUpPMneELkcHd).query
    VBKGCJOrAgvNRsQXhiUpPMneELkcHf=VBKGCJOrAgvNRsQXhiUpPMneELkcHa[0:VBKGCJOrAgvNRsQXhiUpPMneELkcHa.find('=')]
    VBKGCJOrAgvNRsQXhiUpPMneELkcHD=VBKGCJOrAgvNRsQXhiUpPMneELkcyo(urllib.parse.parse_qsl(VBKGCJOrAgvNRsQXhiUpPMneELkcHa))
    VBKGCJOrAgvNRsQXhiUpPMneELkcHy=VBKGCJOrAgvNRsQXhiUpPMneELkcHD.get(VBKGCJOrAgvNRsQXhiUpPMneELkcHf)
    VBKGCJOrAgvNRsQXhiUpPMneELkcdx={'title':VBKGCJOrAgvNRsQXhiUpPMneELkcdw.get('alt')or VBKGCJOrAgvNRsQXhiUpPMneELkcdw.get('title_list')[0].get('text'),'age':VBKGCJOrAgvNRsQXhiUpPMneELkcdw.get('age'),'thumbnail':VBKGCJOrAgvNRsQXhiUpPMneELkcdw.get('thumbnail'),'videoid':VBKGCJOrAgvNRsQXhiUpPMneELkcHy,'vidtype':VBKGCJOrAgvNRsQXhiUpPMneELkcHf,}
    if not VBKGCJOrAgvNRsQXhiUpPMneELkcdx.get('thumbnail').startswith('http'):
     VBKGCJOrAgvNRsQXhiUpPMneELkcdx['thumbnail']='https://%s'%VBKGCJOrAgvNRsQXhiUpPMneELkcdx['thumbnail']
    VBKGCJOrAgvNRsQXhiUpPMneELkcHm.append(VBKGCJOrAgvNRsQXhiUpPMneELkcdx)
   if VBKGCJOrAgvNRsQXhiUpPMneELkcda.get('cell_toplist')not in[{},VBKGCJOrAgvNRsQXhiUpPMneELkcyD,'']:
    VBKGCJOrAgvNRsQXhiUpPMneELkcdY=VBKGCJOrAgvNRsQXhiUpPMneELkcyI(VBKGCJOrAgvNRsQXhiUpPMneELkcda['cell_toplist']['pagecount'])
    if VBKGCJOrAgvNRsQXhiUpPMneELkcda['cell_toplist']['count']:VBKGCJOrAgvNRsQXhiUpPMneELkcHS =VBKGCJOrAgvNRsQXhiUpPMneELkcyI(VBKGCJOrAgvNRsQXhiUpPMneELkcda['cell_toplist']['count'])
    else:VBKGCJOrAgvNRsQXhiUpPMneELkcHS=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.LIST_LIMIT*page_int
    VBKGCJOrAgvNRsQXhiUpPMneELkcHT=VBKGCJOrAgvNRsQXhiUpPMneELkcdY>VBKGCJOrAgvNRsQXhiUpPMneELkcHS
  except VBKGCJOrAgvNRsQXhiUpPMneELkcyz as exception:
   VBKGCJOrAgvNRsQXhiUpPMneELkcyt(exception)
   return[],VBKGCJOrAgvNRsQXhiUpPMneELkcyl
  return VBKGCJOrAgvNRsQXhiUpPMneELkcHm,VBKGCJOrAgvNRsQXhiUpPMneELkcHT
 def Get_Movie_List(VBKGCJOrAgvNRsQXhiUpPMneELkcTH,VBKGCJOrAgvNRsQXhiUpPMneELkcdl,page_int=1,orderby='-'):
  VBKGCJOrAgvNRsQXhiUpPMneELkcHl=[]
  VBKGCJOrAgvNRsQXhiUpPMneELkcdY=VBKGCJOrAgvNRsQXhiUpPMneELkcHS=1
  VBKGCJOrAgvNRsQXhiUpPMneELkcHT=VBKGCJOrAgvNRsQXhiUpPMneELkcyl
  (VBKGCJOrAgvNRsQXhiUpPMneELkcTY,VBKGCJOrAgvNRsQXhiUpPMneELkcTl)=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.Baseapi_Parse(VBKGCJOrAgvNRsQXhiUpPMneELkcdl)
  if VBKGCJOrAgvNRsQXhiUpPMneELkcTY=='':return VBKGCJOrAgvNRsQXhiUpPMneELkcHl,VBKGCJOrAgvNRsQXhiUpPMneELkcHT
  try:
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl['limit']=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.MV_LIMIT
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl['offset']=VBKGCJOrAgvNRsQXhiUpPMneELkcyx((page_int-1)*VBKGCJOrAgvNRsQXhiUpPMneELkcTH.MV_LIMIT)
   if VBKGCJOrAgvNRsQXhiUpPMneELkcTl.get('orderby')!='' and VBKGCJOrAgvNRsQXhiUpPMneELkcTl.get('orderby')!='regdatefirst' and orderby!='-':
    VBKGCJOrAgvNRsQXhiUpPMneELkcTl['orderby']=orderby 
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl.update(VBKGCJOrAgvNRsQXhiUpPMneELkcTH.GetDefaultParams(login=VBKGCJOrAgvNRsQXhiUpPMneELkcyl))
   VBKGCJOrAgvNRsQXhiUpPMneELkcdH=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.callRequestCookies('Get',VBKGCJOrAgvNRsQXhiUpPMneELkcTY,payload=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,params=VBKGCJOrAgvNRsQXhiUpPMneELkcTl,headers=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,cookies=VBKGCJOrAgvNRsQXhiUpPMneELkcyD)
   VBKGCJOrAgvNRsQXhiUpPMneELkcda=json.loads(VBKGCJOrAgvNRsQXhiUpPMneELkcdH.text)
   if VBKGCJOrAgvNRsQXhiUpPMneELkcda.get('cell_toplist')not in[{},VBKGCJOrAgvNRsQXhiUpPMneELkcyD,'']:
    VBKGCJOrAgvNRsQXhiUpPMneELkcdW=VBKGCJOrAgvNRsQXhiUpPMneELkcda['cell_toplist']['celllist']
   elif VBKGCJOrAgvNRsQXhiUpPMneELkcda.get('band')not in[{},VBKGCJOrAgvNRsQXhiUpPMneELkcyD,'']:
    VBKGCJOrAgvNRsQXhiUpPMneELkcdW=VBKGCJOrAgvNRsQXhiUpPMneELkcda['band']['celllist']
   else:
    return VBKGCJOrAgvNRsQXhiUpPMneELkcHl,VBKGCJOrAgvNRsQXhiUpPMneELkcHT
   for VBKGCJOrAgvNRsQXhiUpPMneELkcdw in VBKGCJOrAgvNRsQXhiUpPMneELkcdW:
    VBKGCJOrAgvNRsQXhiUpPMneELkcHd =VBKGCJOrAgvNRsQXhiUpPMneELkcdw['event_list'][1]['url']
    VBKGCJOrAgvNRsQXhiUpPMneELkcHa=urllib.parse.urlsplit(VBKGCJOrAgvNRsQXhiUpPMneELkcHd).query
    VBKGCJOrAgvNRsQXhiUpPMneELkcHf=VBKGCJOrAgvNRsQXhiUpPMneELkcHa[0:VBKGCJOrAgvNRsQXhiUpPMneELkcHa.find('=')]
    VBKGCJOrAgvNRsQXhiUpPMneELkcHD=VBKGCJOrAgvNRsQXhiUpPMneELkcyo(urllib.parse.parse_qsl(VBKGCJOrAgvNRsQXhiUpPMneELkcHa))
    VBKGCJOrAgvNRsQXhiUpPMneELkcHy=VBKGCJOrAgvNRsQXhiUpPMneELkcHD.get(VBKGCJOrAgvNRsQXhiUpPMneELkcHf)
    VBKGCJOrAgvNRsQXhiUpPMneELkcdx={'title':VBKGCJOrAgvNRsQXhiUpPMneELkcdw.get('alt')or VBKGCJOrAgvNRsQXhiUpPMneELkcdw.get('title_list')[0].get('text'),'age':VBKGCJOrAgvNRsQXhiUpPMneELkcdw.get('age'),'thumbnail':VBKGCJOrAgvNRsQXhiUpPMneELkcdw.get('thumbnail'),'videoid':VBKGCJOrAgvNRsQXhiUpPMneELkcHy,'vidtype':VBKGCJOrAgvNRsQXhiUpPMneELkcHf,}
    if not VBKGCJOrAgvNRsQXhiUpPMneELkcdx.get('thumbnail').startswith('http'):
     VBKGCJOrAgvNRsQXhiUpPMneELkcdx['thumbnail']='https://%s'%VBKGCJOrAgvNRsQXhiUpPMneELkcdx['thumbnail']
    VBKGCJOrAgvNRsQXhiUpPMneELkcHl.append(VBKGCJOrAgvNRsQXhiUpPMneELkcdx)
   if VBKGCJOrAgvNRsQXhiUpPMneELkcda.get('cell_toplist')not in[{},VBKGCJOrAgvNRsQXhiUpPMneELkcyD,'']:
    VBKGCJOrAgvNRsQXhiUpPMneELkcdY=VBKGCJOrAgvNRsQXhiUpPMneELkcyI(VBKGCJOrAgvNRsQXhiUpPMneELkcda['cell_toplist']['pagecount'])
    if VBKGCJOrAgvNRsQXhiUpPMneELkcda['cell_toplist']['count']:VBKGCJOrAgvNRsQXhiUpPMneELkcHS =VBKGCJOrAgvNRsQXhiUpPMneELkcyI(VBKGCJOrAgvNRsQXhiUpPMneELkcda['cell_toplist']['count'])
    else:VBKGCJOrAgvNRsQXhiUpPMneELkcHS=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.MV_LIMIT*page_int
    VBKGCJOrAgvNRsQXhiUpPMneELkcHT=VBKGCJOrAgvNRsQXhiUpPMneELkcdY>VBKGCJOrAgvNRsQXhiUpPMneELkcHS
  except VBKGCJOrAgvNRsQXhiUpPMneELkcyz as exception:
   VBKGCJOrAgvNRsQXhiUpPMneELkcyt(exception)
   return[],VBKGCJOrAgvNRsQXhiUpPMneELkcyl
  return VBKGCJOrAgvNRsQXhiUpPMneELkcHl,VBKGCJOrAgvNRsQXhiUpPMneELkcHT
 def ProgramidToContentid(VBKGCJOrAgvNRsQXhiUpPMneELkcTH,VBKGCJOrAgvNRsQXhiUpPMneELkcHw):
  VBKGCJOrAgvNRsQXhiUpPMneELkcHF=''
  try:
   VBKGCJOrAgvNRsQXhiUpPMneELkcTY =VBKGCJOrAgvNRsQXhiUpPMneELkcTH.API_DOMAIN+'/vod/programs-contentid/'+VBKGCJOrAgvNRsQXhiUpPMneELkcHw
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.GetDefaultParams(login=VBKGCJOrAgvNRsQXhiUpPMneELkcyl)
   VBKGCJOrAgvNRsQXhiUpPMneELkcdH=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.callRequestCookies('Get',VBKGCJOrAgvNRsQXhiUpPMneELkcTY,payload=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,params=VBKGCJOrAgvNRsQXhiUpPMneELkcTl,headers=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,cookies=VBKGCJOrAgvNRsQXhiUpPMneELkcyD)
   VBKGCJOrAgvNRsQXhiUpPMneELkcHW=json.loads(VBKGCJOrAgvNRsQXhiUpPMneELkcdH.text)
   if not('contentid' in VBKGCJOrAgvNRsQXhiUpPMneELkcHW):return VBKGCJOrAgvNRsQXhiUpPMneELkcHF 
   VBKGCJOrAgvNRsQXhiUpPMneELkcHF=VBKGCJOrAgvNRsQXhiUpPMneELkcHW['contentid']
  except VBKGCJOrAgvNRsQXhiUpPMneELkcyz as exception:
   VBKGCJOrAgvNRsQXhiUpPMneELkcyt(exception)
  return VBKGCJOrAgvNRsQXhiUpPMneELkcHF
 def ContentidToSeasonid(VBKGCJOrAgvNRsQXhiUpPMneELkcTH,VBKGCJOrAgvNRsQXhiUpPMneELkcHF):
  VBKGCJOrAgvNRsQXhiUpPMneELkcHw=''
  try:
   VBKGCJOrAgvNRsQXhiUpPMneELkcTY =VBKGCJOrAgvNRsQXhiUpPMneELkcTH.API_DOMAIN+'/fz/vod/contents/'+VBKGCJOrAgvNRsQXhiUpPMneELkcHF
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.GetDefaultParams(login=VBKGCJOrAgvNRsQXhiUpPMneELkcyl)
   VBKGCJOrAgvNRsQXhiUpPMneELkcdH=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.callRequestCookies('Get',VBKGCJOrAgvNRsQXhiUpPMneELkcTY,payload=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,params=VBKGCJOrAgvNRsQXhiUpPMneELkcTl,headers=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,cookies=VBKGCJOrAgvNRsQXhiUpPMneELkcyD)
   VBKGCJOrAgvNRsQXhiUpPMneELkcHW=json.loads(VBKGCJOrAgvNRsQXhiUpPMneELkcdH.text)
   if not('programid' in VBKGCJOrAgvNRsQXhiUpPMneELkcHW):return VBKGCJOrAgvNRsQXhiUpPMneELkcHw 
   VBKGCJOrAgvNRsQXhiUpPMneELkcHw=VBKGCJOrAgvNRsQXhiUpPMneELkcHW['programid']
  except VBKGCJOrAgvNRsQXhiUpPMneELkcyz as exception:
   VBKGCJOrAgvNRsQXhiUpPMneELkcyt(exception)
  return VBKGCJOrAgvNRsQXhiUpPMneELkcHw
 def GetProgramInfo(VBKGCJOrAgvNRsQXhiUpPMneELkcTH,VBKGCJOrAgvNRsQXhiUpPMneELkcHF):
  VBKGCJOrAgvNRsQXhiUpPMneELkcHx={}
  try:
   VBKGCJOrAgvNRsQXhiUpPMneELkcTY=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.API_DOMAIN+'/fz/vod/contents/'+VBKGCJOrAgvNRsQXhiUpPMneELkcHF
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.GetDefaultParams(login=VBKGCJOrAgvNRsQXhiUpPMneELkcyl)
   VBKGCJOrAgvNRsQXhiUpPMneELkcdH=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.callRequestCookies('Get',VBKGCJOrAgvNRsQXhiUpPMneELkcTY,payload=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,params=VBKGCJOrAgvNRsQXhiUpPMneELkcTl,headers=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,cookies=VBKGCJOrAgvNRsQXhiUpPMneELkcyD)
   VBKGCJOrAgvNRsQXhiUpPMneELkcHW=json.loads(VBKGCJOrAgvNRsQXhiUpPMneELkcdH.text)
   VBKGCJOrAgvNRsQXhiUpPMneELkcHz=img_fanart=VBKGCJOrAgvNRsQXhiUpPMneELkcHt=''
   if VBKGCJOrAgvNRsQXhiUpPMneELkcHW.get('programposterimage')!='':VBKGCJOrAgvNRsQXhiUpPMneELkcHz =VBKGCJOrAgvNRsQXhiUpPMneELkcTH.HTTPTAG+VBKGCJOrAgvNRsQXhiUpPMneELkcHW.get('programposterimage')
   if VBKGCJOrAgvNRsQXhiUpPMneELkcHW.get('programimage') !='':img_fanart =VBKGCJOrAgvNRsQXhiUpPMneELkcTH.HTTPTAG+VBKGCJOrAgvNRsQXhiUpPMneELkcHW.get('programimage')
   if VBKGCJOrAgvNRsQXhiUpPMneELkcHW.get('programcircleimage')!='':VBKGCJOrAgvNRsQXhiUpPMneELkcHt=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.HTTPTAG+VBKGCJOrAgvNRsQXhiUpPMneELkcHW.get('programcircleimage')
   if 'poster_default' in VBKGCJOrAgvNRsQXhiUpPMneELkcHz:
    VBKGCJOrAgvNRsQXhiUpPMneELkcHz =img_fanart
    VBKGCJOrAgvNRsQXhiUpPMneELkcHt=''
   VBKGCJOrAgvNRsQXhiUpPMneELkcHx={'imgPoster':VBKGCJOrAgvNRsQXhiUpPMneELkcHz,'imgFanart':img_fanart,'imgClearlogo':VBKGCJOrAgvNRsQXhiUpPMneELkcHt,'programtitle':VBKGCJOrAgvNRsQXhiUpPMneELkcHW.get('programtitle'),'programid':VBKGCJOrAgvNRsQXhiUpPMneELkcHW.get('programid'),'synopsis':VBKGCJOrAgvNRsQXhiUpPMneELkcHW.get('programsynopsis').replace('<br>','\n'),}
  except VBKGCJOrAgvNRsQXhiUpPMneELkcyz as exception:
   VBKGCJOrAgvNRsQXhiUpPMneELkcyt(exception)
  return VBKGCJOrAgvNRsQXhiUpPMneELkcHx
 def Get_Season_List(VBKGCJOrAgvNRsQXhiUpPMneELkcTH,seasonid):
  VBKGCJOrAgvNRsQXhiUpPMneELkcHo=[]
  VBKGCJOrAgvNRsQXhiUpPMneELkcHF=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.ProgramidToContentid(seasonid)
  VBKGCJOrAgvNRsQXhiUpPMneELkcHI=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.GetProgramInfo(VBKGCJOrAgvNRsQXhiUpPMneELkcHF)
  VBKGCJOrAgvNRsQXhiUpPMneELkcHu={'poster':VBKGCJOrAgvNRsQXhiUpPMneELkcHI.get('imgPoster'),'fanart':VBKGCJOrAgvNRsQXhiUpPMneELkcHI.get('imgFanart'),'clearlogo':VBKGCJOrAgvNRsQXhiUpPMneELkcHI.get('imgClearlogo'),}
  try:
   VBKGCJOrAgvNRsQXhiUpPMneELkcTY=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.API_DOMAIN+'/fz/vod/programs-contents/'+seasonid
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl={'limit':'10','offset':'0','orderby':'new',}
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl.update(VBKGCJOrAgvNRsQXhiUpPMneELkcTH.GetDefaultParams(login=VBKGCJOrAgvNRsQXhiUpPMneELkcyl))
   VBKGCJOrAgvNRsQXhiUpPMneELkcdH=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.callRequestCookies('Get',VBKGCJOrAgvNRsQXhiUpPMneELkcTY,payload=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,params=VBKGCJOrAgvNRsQXhiUpPMneELkcTl,headers=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,cookies=VBKGCJOrAgvNRsQXhiUpPMneELkcyD)
   VBKGCJOrAgvNRsQXhiUpPMneELkcda=json.loads(VBKGCJOrAgvNRsQXhiUpPMneELkcdH.text)
   for VBKGCJOrAgvNRsQXhiUpPMneELkcHb in VBKGCJOrAgvNRsQXhiUpPMneELkcda['filter']['filterlist'][0]['filter_item_list']:
    VBKGCJOrAgvNRsQXhiUpPMneELkcdx={'season_Nm':VBKGCJOrAgvNRsQXhiUpPMneELkcHb.get('title'),'season_Id':VBKGCJOrAgvNRsQXhiUpPMneELkcHb.get('api_path'),'thumbnail':VBKGCJOrAgvNRsQXhiUpPMneELkcHu,'programNm':VBKGCJOrAgvNRsQXhiUpPMneELkcHI.get('programtitle'),'synopsis':VBKGCJOrAgvNRsQXhiUpPMneELkcHI.get('synopsis'),}
    VBKGCJOrAgvNRsQXhiUpPMneELkcHo.append(VBKGCJOrAgvNRsQXhiUpPMneELkcdx)
  except VBKGCJOrAgvNRsQXhiUpPMneELkcyz as exception:
   VBKGCJOrAgvNRsQXhiUpPMneELkcyt(exception)
   return[]
  return VBKGCJOrAgvNRsQXhiUpPMneELkcHo
 def Get_Episode_List(VBKGCJOrAgvNRsQXhiUpPMneELkcTH,seasionid,page_int=1,orderby='desc'):
  VBKGCJOrAgvNRsQXhiUpPMneELkcHY=[]
  VBKGCJOrAgvNRsQXhiUpPMneELkcdY=VBKGCJOrAgvNRsQXhiUpPMneELkcHS=1
  VBKGCJOrAgvNRsQXhiUpPMneELkcHT=VBKGCJOrAgvNRsQXhiUpPMneELkcyl
  VBKGCJOrAgvNRsQXhiUpPMneELkcHI={}
  VBKGCJOrAgvNRsQXhiUpPMneELkcHF=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.ProgramidToContentid(seasionid)
  VBKGCJOrAgvNRsQXhiUpPMneELkcHI=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.GetProgramInfo(VBKGCJOrAgvNRsQXhiUpPMneELkcHF)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   VBKGCJOrAgvNRsQXhiUpPMneELkcTY=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.API_DOMAIN+'/fz/vod/programs-contents/'+seasionid
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl={'limit':VBKGCJOrAgvNRsQXhiUpPMneELkcTH.EP_LIMIT,'offset':VBKGCJOrAgvNRsQXhiUpPMneELkcyx((page_int-1)*VBKGCJOrAgvNRsQXhiUpPMneELkcTH.EP_LIMIT),'orderby':orderby,}
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl.update(VBKGCJOrAgvNRsQXhiUpPMneELkcTH.GetDefaultParams(login=VBKGCJOrAgvNRsQXhiUpPMneELkcyl))
   VBKGCJOrAgvNRsQXhiUpPMneELkcdH=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.callRequestCookies('Get',VBKGCJOrAgvNRsQXhiUpPMneELkcTY,payload=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,params=VBKGCJOrAgvNRsQXhiUpPMneELkcTl,headers=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,cookies=VBKGCJOrAgvNRsQXhiUpPMneELkcyD)
   VBKGCJOrAgvNRsQXhiUpPMneELkcda=json.loads(VBKGCJOrAgvNRsQXhiUpPMneELkcdH.text)
   VBKGCJOrAgvNRsQXhiUpPMneELkcdW=VBKGCJOrAgvNRsQXhiUpPMneELkcda['cell_toplist']['celllist']
   for VBKGCJOrAgvNRsQXhiUpPMneELkcdw in VBKGCJOrAgvNRsQXhiUpPMneELkcdW:
    VBKGCJOrAgvNRsQXhiUpPMneELkcad=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',VBKGCJOrAgvNRsQXhiUpPMneELkcdw.get('synopsis'))
    VBKGCJOrAgvNRsQXhiUpPMneELkcaH=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.HTTPTAG+VBKGCJOrAgvNRsQXhiUpPMneELkcdw.get('thumbnail')
    VBKGCJOrAgvNRsQXhiUpPMneELkcaf=VBKGCJOrAgvNRsQXhiUpPMneELkcay=VBKGCJOrAgvNRsQXhiUpPMneELkcaS=''
    VBKGCJOrAgvNRsQXhiUpPMneELkcaf =VBKGCJOrAgvNRsQXhiUpPMneELkcHI.get('imgPoster')
    VBKGCJOrAgvNRsQXhiUpPMneELkcay =VBKGCJOrAgvNRsQXhiUpPMneELkcHI.get('imgFanart')
    VBKGCJOrAgvNRsQXhiUpPMneELkcaS =VBKGCJOrAgvNRsQXhiUpPMneELkcHI.get('imgClearlogo')
    VBKGCJOrAgvNRsQXhiUpPMneELkcaj=VBKGCJOrAgvNRsQXhiUpPMneELkcHI.get('programtitle')
    VBKGCJOrAgvNRsQXhiUpPMneELkcHu={'thumb':VBKGCJOrAgvNRsQXhiUpPMneELkcaH,'poster':VBKGCJOrAgvNRsQXhiUpPMneELkcaf,'fanart':VBKGCJOrAgvNRsQXhiUpPMneELkcay,'clearlogo':VBKGCJOrAgvNRsQXhiUpPMneELkcaS}
    VBKGCJOrAgvNRsQXhiUpPMneELkcdx={'programtitle':VBKGCJOrAgvNRsQXhiUpPMneELkcaj,'episodetitle':VBKGCJOrAgvNRsQXhiUpPMneELkcdw['title_list'][0]['text'],'episodenumber':VBKGCJOrAgvNRsQXhiUpPMneELkcdw['title_list'][1]['text'].replace('$O$',''),'contentid':VBKGCJOrAgvNRsQXhiUpPMneELkcdw['contentid'],'synopsis':VBKGCJOrAgvNRsQXhiUpPMneELkcad,'episodeactors':VBKGCJOrAgvNRsQXhiUpPMneELkcdw.get('actors').split(',')if VBKGCJOrAgvNRsQXhiUpPMneELkcdw.get('actors')!='' else[],'thumbnail':VBKGCJOrAgvNRsQXhiUpPMneELkcHu,}
    VBKGCJOrAgvNRsQXhiUpPMneELkcHY.append(VBKGCJOrAgvNRsQXhiUpPMneELkcdx)
   VBKGCJOrAgvNRsQXhiUpPMneELkcdY=VBKGCJOrAgvNRsQXhiUpPMneELkcyI(VBKGCJOrAgvNRsQXhiUpPMneELkcda['cell_toplist']['pagecount'])
   if VBKGCJOrAgvNRsQXhiUpPMneELkcda['cell_toplist']['count']:VBKGCJOrAgvNRsQXhiUpPMneELkcHS =VBKGCJOrAgvNRsQXhiUpPMneELkcyI(VBKGCJOrAgvNRsQXhiUpPMneELkcda['cell_toplist']['count'])
   else:VBKGCJOrAgvNRsQXhiUpPMneELkcHS=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.EP_LIMIT*page_int
   VBKGCJOrAgvNRsQXhiUpPMneELkcHT=VBKGCJOrAgvNRsQXhiUpPMneELkcdY>VBKGCJOrAgvNRsQXhiUpPMneELkcHS
  except VBKGCJOrAgvNRsQXhiUpPMneELkcyz as exception:
   VBKGCJOrAgvNRsQXhiUpPMneELkcyt(exception)
   return[],VBKGCJOrAgvNRsQXhiUpPMneELkcyl
  return VBKGCJOrAgvNRsQXhiUpPMneELkcHY,VBKGCJOrAgvNRsQXhiUpPMneELkcHT
 def GetEPGList(VBKGCJOrAgvNRsQXhiUpPMneELkcTH,genre):
  VBKGCJOrAgvNRsQXhiUpPMneELkcam={}
  try:
   VBKGCJOrAgvNRsQXhiUpPMneELkcaq=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.Get_Now_Datetime()
   if genre=='all':
    VBKGCJOrAgvNRsQXhiUpPMneELkcaD =VBKGCJOrAgvNRsQXhiUpPMneELkcaq+datetime.timedelta(hours=3)
   else:
    VBKGCJOrAgvNRsQXhiUpPMneELkcaD =VBKGCJOrAgvNRsQXhiUpPMneELkcaq+datetime.timedelta(hours=3)
   VBKGCJOrAgvNRsQXhiUpPMneELkcTY=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.API_DOMAIN+'/live/epgs'
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl={'limit':'100','offset':'0','genre':genre,'startdatetime':VBKGCJOrAgvNRsQXhiUpPMneELkcaq.strftime('%Y-%m-%d %H:00'),'enddatetime':VBKGCJOrAgvNRsQXhiUpPMneELkcaD.strftime('%Y-%m-%d %H:00')}
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl.update(VBKGCJOrAgvNRsQXhiUpPMneELkcTH.GetDefaultParams(login=VBKGCJOrAgvNRsQXhiUpPMneELkcyl))
   VBKGCJOrAgvNRsQXhiUpPMneELkcdH=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.callRequestCookies('Get',VBKGCJOrAgvNRsQXhiUpPMneELkcTY,payload=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,params=VBKGCJOrAgvNRsQXhiUpPMneELkcTl,headers=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,cookies=VBKGCJOrAgvNRsQXhiUpPMneELkcyD)
   VBKGCJOrAgvNRsQXhiUpPMneELkcda=json.loads(VBKGCJOrAgvNRsQXhiUpPMneELkcdH.text)
   VBKGCJOrAgvNRsQXhiUpPMneELkcal=VBKGCJOrAgvNRsQXhiUpPMneELkcda['list']
   for VBKGCJOrAgvNRsQXhiUpPMneELkcdw in VBKGCJOrAgvNRsQXhiUpPMneELkcal:
    VBKGCJOrAgvNRsQXhiUpPMneELkcaF=''
    for VBKGCJOrAgvNRsQXhiUpPMneELkcaW in VBKGCJOrAgvNRsQXhiUpPMneELkcdw['list']:
     if VBKGCJOrAgvNRsQXhiUpPMneELkcaF:VBKGCJOrAgvNRsQXhiUpPMneELkcaF+='\n'
     VBKGCJOrAgvNRsQXhiUpPMneELkcaF+=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.Get_ChangeText(VBKGCJOrAgvNRsQXhiUpPMneELkcaW['title'])+'\n'
     VBKGCJOrAgvNRsQXhiUpPMneELkcaF+=' [%s ~ %s]'%(VBKGCJOrAgvNRsQXhiUpPMneELkcaW['starttime'][-5:],VBKGCJOrAgvNRsQXhiUpPMneELkcaW['endtime'][-5:])+'\n'
    VBKGCJOrAgvNRsQXhiUpPMneELkcam[VBKGCJOrAgvNRsQXhiUpPMneELkcdw['channelid']]=VBKGCJOrAgvNRsQXhiUpPMneELkcaF
  except VBKGCJOrAgvNRsQXhiUpPMneELkcyz as exception:
   VBKGCJOrAgvNRsQXhiUpPMneELkcyt(exception)
  return VBKGCJOrAgvNRsQXhiUpPMneELkcam
 def Get_LiveChannel_List(VBKGCJOrAgvNRsQXhiUpPMneELkcTH,genre,VBKGCJOrAgvNRsQXhiUpPMneELkcdl):
  VBKGCJOrAgvNRsQXhiUpPMneELkcdb=[]
  (VBKGCJOrAgvNRsQXhiUpPMneELkcTY,VBKGCJOrAgvNRsQXhiUpPMneELkcTl)=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.Baseapi_Parse(VBKGCJOrAgvNRsQXhiUpPMneELkcdl)
  if VBKGCJOrAgvNRsQXhiUpPMneELkcTY=='':return VBKGCJOrAgvNRsQXhiUpPMneELkcdb
  VBKGCJOrAgvNRsQXhiUpPMneELkcaw=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.GetEPGList(genre)
  try:
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl.update(VBKGCJOrAgvNRsQXhiUpPMneELkcTH.GetDefaultParams(login=VBKGCJOrAgvNRsQXhiUpPMneELkcyl))
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl['genre']=genre
   VBKGCJOrAgvNRsQXhiUpPMneELkcdH=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.callRequestCookies('Get',VBKGCJOrAgvNRsQXhiUpPMneELkcTY,payload=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,params=VBKGCJOrAgvNRsQXhiUpPMneELkcTl,headers=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,cookies=VBKGCJOrAgvNRsQXhiUpPMneELkcyD)
   VBKGCJOrAgvNRsQXhiUpPMneELkcda=json.loads(VBKGCJOrAgvNRsQXhiUpPMneELkcdH.text)
   if not('celllist' in VBKGCJOrAgvNRsQXhiUpPMneELkcda['cell_toplist']):return[]
   VBKGCJOrAgvNRsQXhiUpPMneELkcdW=VBKGCJOrAgvNRsQXhiUpPMneELkcda['cell_toplist']['celllist']
   for VBKGCJOrAgvNRsQXhiUpPMneELkcdw in VBKGCJOrAgvNRsQXhiUpPMneELkcdW:
    VBKGCJOrAgvNRsQXhiUpPMneELkcHF=VBKGCJOrAgvNRsQXhiUpPMneELkcdw['contentid']
    if VBKGCJOrAgvNRsQXhiUpPMneELkcHF in VBKGCJOrAgvNRsQXhiUpPMneELkcaw:
     VBKGCJOrAgvNRsQXhiUpPMneELkcax=VBKGCJOrAgvNRsQXhiUpPMneELkcaw[VBKGCJOrAgvNRsQXhiUpPMneELkcHF]
    else:
     VBKGCJOrAgvNRsQXhiUpPMneELkcax=''
    VBKGCJOrAgvNRsQXhiUpPMneELkcdx={'studio':VBKGCJOrAgvNRsQXhiUpPMneELkcdw['title_list'][0]['text'],'tvshowtitle':VBKGCJOrAgvNRsQXhiUpPMneELkcTH.Get_ChangeText(VBKGCJOrAgvNRsQXhiUpPMneELkcdw['title_list'][1]['text']),'channelid':VBKGCJOrAgvNRsQXhiUpPMneELkcHF,'age':VBKGCJOrAgvNRsQXhiUpPMneELkcdw['age'],'thumbnail':'https://%s'%VBKGCJOrAgvNRsQXhiUpPMneELkcdw.get('thumbnail'),'epg':VBKGCJOrAgvNRsQXhiUpPMneELkcax}
    VBKGCJOrAgvNRsQXhiUpPMneELkcdb.append(VBKGCJOrAgvNRsQXhiUpPMneELkcdx)
  except VBKGCJOrAgvNRsQXhiUpPMneELkcyz as exception:
   VBKGCJOrAgvNRsQXhiUpPMneELkcyt(exception)
   return[]
  return VBKGCJOrAgvNRsQXhiUpPMneELkcdb
 def Get_Search_List(VBKGCJOrAgvNRsQXhiUpPMneELkcTH,search_key,sType,page_int,exclusion21=VBKGCJOrAgvNRsQXhiUpPMneELkcyl):
  VBKGCJOrAgvNRsQXhiUpPMneELkcaz=[]
  VBKGCJOrAgvNRsQXhiUpPMneELkcdY=VBKGCJOrAgvNRsQXhiUpPMneELkcHS=1
  VBKGCJOrAgvNRsQXhiUpPMneELkcHT=VBKGCJOrAgvNRsQXhiUpPMneELkcyl
  try:
   VBKGCJOrAgvNRsQXhiUpPMneELkcTY=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.API_DOMAIN+'/fz/search/band.js'
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':VBKGCJOrAgvNRsQXhiUpPMneELkcyx((page_int-1)*VBKGCJOrAgvNRsQXhiUpPMneELkcTH.SEARCH_LIMIT),'limit':VBKGCJOrAgvNRsQXhiUpPMneELkcTH.SEARCH_LIMIT,'orderby':'score','mtype':'svod',}
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl.update(VBKGCJOrAgvNRsQXhiUpPMneELkcTH.GetDefaultParams(login=VBKGCJOrAgvNRsQXhiUpPMneELkcyl))
   VBKGCJOrAgvNRsQXhiUpPMneELkcdH=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.callRequestCookies('Get',VBKGCJOrAgvNRsQXhiUpPMneELkcTY,payload=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,params=VBKGCJOrAgvNRsQXhiUpPMneELkcTl,headers=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,cookies=VBKGCJOrAgvNRsQXhiUpPMneELkcyD)
   VBKGCJOrAgvNRsQXhiUpPMneELkcHW=json.loads(VBKGCJOrAgvNRsQXhiUpPMneELkcdH.text)
   if not('celllist' in VBKGCJOrAgvNRsQXhiUpPMneELkcHW['band']):return VBKGCJOrAgvNRsQXhiUpPMneELkcaz,VBKGCJOrAgvNRsQXhiUpPMneELkcHT
   VBKGCJOrAgvNRsQXhiUpPMneELkcdW=VBKGCJOrAgvNRsQXhiUpPMneELkcHW['band']['celllist']
   for VBKGCJOrAgvNRsQXhiUpPMneELkcdw in VBKGCJOrAgvNRsQXhiUpPMneELkcdW:
    VBKGCJOrAgvNRsQXhiUpPMneELkcHd =VBKGCJOrAgvNRsQXhiUpPMneELkcdw['event_list'][1]['url']
    VBKGCJOrAgvNRsQXhiUpPMneELkcHa=urllib.parse.urlsplit(VBKGCJOrAgvNRsQXhiUpPMneELkcHd).query
    VBKGCJOrAgvNRsQXhiUpPMneELkcHf=VBKGCJOrAgvNRsQXhiUpPMneELkcHa[0:VBKGCJOrAgvNRsQXhiUpPMneELkcHa.find('=')]
    VBKGCJOrAgvNRsQXhiUpPMneELkcHD=VBKGCJOrAgvNRsQXhiUpPMneELkcyo(urllib.parse.parse_qsl(VBKGCJOrAgvNRsQXhiUpPMneELkcHa))
    VBKGCJOrAgvNRsQXhiUpPMneELkcHy=VBKGCJOrAgvNRsQXhiUpPMneELkcHD.get(VBKGCJOrAgvNRsQXhiUpPMneELkcHf)
    VBKGCJOrAgvNRsQXhiUpPMneELkcdx={'title':VBKGCJOrAgvNRsQXhiUpPMneELkcdw['title_list'][0]['text'],'age':VBKGCJOrAgvNRsQXhiUpPMneELkcdw['age'],'thumbnail':'https://%s'%VBKGCJOrAgvNRsQXhiUpPMneELkcdw.get('thumbnail'),'videoid':VBKGCJOrAgvNRsQXhiUpPMneELkcHy,'vidtype':VBKGCJOrAgvNRsQXhiUpPMneELkcHf,}
    VBKGCJOrAgvNRsQXhiUpPMneELkcat=VBKGCJOrAgvNRsQXhiUpPMneELkcyl
    for VBKGCJOrAgvNRsQXhiUpPMneELkcao in VBKGCJOrAgvNRsQXhiUpPMneELkcdw['bottom_taglist']:
     if VBKGCJOrAgvNRsQXhiUpPMneELkcao=='won':
      VBKGCJOrAgvNRsQXhiUpPMneELkcat=VBKGCJOrAgvNRsQXhiUpPMneELkcyW
      break
    if VBKGCJOrAgvNRsQXhiUpPMneELkcat==VBKGCJOrAgvNRsQXhiUpPMneELkcyW: 
     VBKGCJOrAgvNRsQXhiUpPMneELkcdx['title']=VBKGCJOrAgvNRsQXhiUpPMneELkcdx['title']+' [개별구매]'
    if exclusion21==VBKGCJOrAgvNRsQXhiUpPMneELkcyl or VBKGCJOrAgvNRsQXhiUpPMneELkcdw.get('age')!='21':
     VBKGCJOrAgvNRsQXhiUpPMneELkcaz.append(VBKGCJOrAgvNRsQXhiUpPMneELkcdx)
   VBKGCJOrAgvNRsQXhiUpPMneELkcdY=VBKGCJOrAgvNRsQXhiUpPMneELkcyI(VBKGCJOrAgvNRsQXhiUpPMneELkcHW['band']['pagecount'])
   if VBKGCJOrAgvNRsQXhiUpPMneELkcHW['band']['count']:VBKGCJOrAgvNRsQXhiUpPMneELkcHS =VBKGCJOrAgvNRsQXhiUpPMneELkcyI(VBKGCJOrAgvNRsQXhiUpPMneELkcHW['band']['count'])
   else:VBKGCJOrAgvNRsQXhiUpPMneELkcHS=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.LIST_LIMIT
   VBKGCJOrAgvNRsQXhiUpPMneELkcHT=VBKGCJOrAgvNRsQXhiUpPMneELkcdY>VBKGCJOrAgvNRsQXhiUpPMneELkcHS
  except VBKGCJOrAgvNRsQXhiUpPMneELkcyz as exception:
   VBKGCJOrAgvNRsQXhiUpPMneELkcyt(exception)
  return VBKGCJOrAgvNRsQXhiUpPMneELkcaz,VBKGCJOrAgvNRsQXhiUpPMneELkcHT 
 def GetSecureToken(VBKGCJOrAgvNRsQXhiUpPMneELkcTH):
  VBKGCJOrAgvNRsQXhiUpPMneELkcTY=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.API_DOMAIN+'/ip'
  VBKGCJOrAgvNRsQXhiUpPMneELkcTl=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.GetDefaultParams(login=VBKGCJOrAgvNRsQXhiUpPMneELkcyl)
  VBKGCJOrAgvNRsQXhiUpPMneELkcdH=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.callRequestCookies('Get',VBKGCJOrAgvNRsQXhiUpPMneELkcTY,payload=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,params=VBKGCJOrAgvNRsQXhiUpPMneELkcTl,headers=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,cookies=VBKGCJOrAgvNRsQXhiUpPMneELkcyD)
  VBKGCJOrAgvNRsQXhiUpPMneELkcda=json.loads(VBKGCJOrAgvNRsQXhiUpPMneELkcdH.text)
  return VBKGCJOrAgvNRsQXhiUpPMneELkcda['securetoken']
 def GetStreamingURL(VBKGCJOrAgvNRsQXhiUpPMneELkcTH,mode,VBKGCJOrAgvNRsQXhiUpPMneELkcHF,quality_int,pvrmode='-',playOption={}):
  VBKGCJOrAgvNRsQXhiUpPMneELkcaI ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  VBKGCJOrAgvNRsQXhiUpPMneELkcau=[]
  if mode=='LIVE':
   VBKGCJOrAgvNRsQXhiUpPMneELkcTY =VBKGCJOrAgvNRsQXhiUpPMneELkcTH.API_DOMAIN+'/live/channels/'+VBKGCJOrAgvNRsQXhiUpPMneELkcHF
   VBKGCJOrAgvNRsQXhiUpPMneELkcab='live'
  elif mode=='VOD':
   VBKGCJOrAgvNRsQXhiUpPMneELkcTY =VBKGCJOrAgvNRsQXhiUpPMneELkcTH.API_DOMAIN+'/fz/vod/contents-detail/'+VBKGCJOrAgvNRsQXhiUpPMneELkcHF 
   VBKGCJOrAgvNRsQXhiUpPMneELkcab='vod'
  elif mode=='MOVIE':
   VBKGCJOrAgvNRsQXhiUpPMneELkcTY =VBKGCJOrAgvNRsQXhiUpPMneELkcTH.API_DOMAIN+'/fz/movie/contents/'+VBKGCJOrAgvNRsQXhiUpPMneELkcHF
   VBKGCJOrAgvNRsQXhiUpPMneELkcab='movie'
  VBKGCJOrAgvNRsQXhiUpPMneELkcaY={'hdr':'sdr',}
  try:
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.GetDefaultParams(login=VBKGCJOrAgvNRsQXhiUpPMneELkcyl)
   VBKGCJOrAgvNRsQXhiUpPMneELkcdH=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.callRequestCookies('Get',VBKGCJOrAgvNRsQXhiUpPMneELkcTY,payload=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,params=VBKGCJOrAgvNRsQXhiUpPMneELkcTl,headers=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,cookies=VBKGCJOrAgvNRsQXhiUpPMneELkcyD)
   VBKGCJOrAgvNRsQXhiUpPMneELkcda=json.loads(VBKGCJOrAgvNRsQXhiUpPMneELkcdH.text)
   VBKGCJOrAgvNRsQXhiUpPMneELkcfT=VBKGCJOrAgvNRsQXhiUpPMneELkcda['qualities']['list']
   if VBKGCJOrAgvNRsQXhiUpPMneELkcfT==VBKGCJOrAgvNRsQXhiUpPMneELkcyD:return VBKGCJOrAgvNRsQXhiUpPMneELkcaI
   for VBKGCJOrAgvNRsQXhiUpPMneELkcfd in VBKGCJOrAgvNRsQXhiUpPMneELkcfT:
    VBKGCJOrAgvNRsQXhiUpPMneELkcau.append(VBKGCJOrAgvNRsQXhiUpPMneELkcyI(VBKGCJOrAgvNRsQXhiUpPMneELkcfd.get('id').rstrip('p')))
   if 'type' in VBKGCJOrAgvNRsQXhiUpPMneELkcda:
    if VBKGCJOrAgvNRsQXhiUpPMneELkcda['type']=='onair':
     VBKGCJOrAgvNRsQXhiUpPMneELkcab='onairvod'
   if 'drms' in VBKGCJOrAgvNRsQXhiUpPMneELkcda:
    if VBKGCJOrAgvNRsQXhiUpPMneELkcda['drms']:
     VBKGCJOrAgvNRsQXhiUpPMneELkcaI['stream_action']='dash'
   if playOption.get('enable_hdr'):
    if 'mediatypes' in VBKGCJOrAgvNRsQXhiUpPMneELkcda.get('qualities'):
     for VBKGCJOrAgvNRsQXhiUpPMneELkcfH in VBKGCJOrAgvNRsQXhiUpPMneELkcda.get('qualities').get('mediatypes'):
      if VBKGCJOrAgvNRsQXhiUpPMneELkcfH=='HDR10':
       VBKGCJOrAgvNRsQXhiUpPMneELkcaY['hdr']='hdr'
       VBKGCJOrAgvNRsQXhiUpPMneELkcaI['stream_action']='dash'
       break
  except VBKGCJOrAgvNRsQXhiUpPMneELkcyz as exception:
   VBKGCJOrAgvNRsQXhiUpPMneELkcyt(exception)
   return VBKGCJOrAgvNRsQXhiUpPMneELkcaI
  VBKGCJOrAgvNRsQXhiUpPMneELkcyt(VBKGCJOrAgvNRsQXhiUpPMneELkcaI['stream_action'])
  try:
   VBKGCJOrAgvNRsQXhiUpPMneELkcfa=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.CheckQuality(quality_int,VBKGCJOrAgvNRsQXhiUpPMneELkcau)
   VBKGCJOrAgvNRsQXhiUpPMneELkcfy=VBKGCJOrAgvNRsQXhiUpPMneELkcyx(VBKGCJOrAgvNRsQXhiUpPMneELkcfa)+'p'
   VBKGCJOrAgvNRsQXhiUpPMneELkcTY=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.API_DOMAIN+'/fz/streaming'
   if VBKGCJOrAgvNRsQXhiUpPMneELkcaY['hdr']=='hdr':
    VBKGCJOrAgvNRsQXhiUpPMneELkcTl={'contentid':VBKGCJOrAgvNRsQXhiUpPMneELkcHF,'contenttype':VBKGCJOrAgvNRsQXhiUpPMneELkcab,'quality':VBKGCJOrAgvNRsQXhiUpPMneELkcfy,'modelid':'SHIELD Android TV','guid':VBKGCJOrAgvNRsQXhiUpPMneELkcTH.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n','protocol':VBKGCJOrAgvNRsQXhiUpPMneELkcaI['stream_action'],'hdr':'HDR10','videocodec':'HEVC','audiocodec':'AAC','issurround':'y','format':'normal','withinsubtitle':'n',}
    VBKGCJOrAgvNRsQXhiUpPMneELkcTl.update(VBKGCJOrAgvNRsQXhiUpPMneELkcTH.GetDefaultParams_AND())
   else:
    VBKGCJOrAgvNRsQXhiUpPMneELkcTl={'contentid':VBKGCJOrAgvNRsQXhiUpPMneELkcHF,'contenttype':VBKGCJOrAgvNRsQXhiUpPMneELkcab,'quality':VBKGCJOrAgvNRsQXhiUpPMneELkcfy,'deviceModelId':'Windows 10','guid':VBKGCJOrAgvNRsQXhiUpPMneELkcTH.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n','action':VBKGCJOrAgvNRsQXhiUpPMneELkcaI['stream_action'],'protocol':VBKGCJOrAgvNRsQXhiUpPMneELkcaI['stream_action'],'hdr':'sdr','videocodec':'avc','audiocodec':'aac','issurround':'n','format':'normal','withinsubtitle':'n',}
    VBKGCJOrAgvNRsQXhiUpPMneELkcTl.update(VBKGCJOrAgvNRsQXhiUpPMneELkcTH.GetDefaultParams(login=VBKGCJOrAgvNRsQXhiUpPMneELkcyW))
   VBKGCJOrAgvNRsQXhiUpPMneELkcdH=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.callRequestCookies('Get',VBKGCJOrAgvNRsQXhiUpPMneELkcTY,payload=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,params=VBKGCJOrAgvNRsQXhiUpPMneELkcTl,headers=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,cookies=VBKGCJOrAgvNRsQXhiUpPMneELkcyD)
   VBKGCJOrAgvNRsQXhiUpPMneELkcda=json.loads(VBKGCJOrAgvNRsQXhiUpPMneELkcdH.text)
   VBKGCJOrAgvNRsQXhiUpPMneELkcaI['stream_url']=VBKGCJOrAgvNRsQXhiUpPMneELkcda['playurl']
   if VBKGCJOrAgvNRsQXhiUpPMneELkcaI['stream_url']==VBKGCJOrAgvNRsQXhiUpPMneELkcyD:return VBKGCJOrAgvNRsQXhiUpPMneELkcaI
   VBKGCJOrAgvNRsQXhiUpPMneELkcaI['stream_cookie']=VBKGCJOrAgvNRsQXhiUpPMneELkcda['awscookie']
   VBKGCJOrAgvNRsQXhiUpPMneELkcaI['stream_drm'] =VBKGCJOrAgvNRsQXhiUpPMneELkcda['drm']
   if 'previewmsg' in VBKGCJOrAgvNRsQXhiUpPMneELkcda['preview']:VBKGCJOrAgvNRsQXhiUpPMneELkcaI['stream_preview']=VBKGCJOrAgvNRsQXhiUpPMneELkcda['preview']['previewmsg']
   if 'subtitles' in VBKGCJOrAgvNRsQXhiUpPMneELkcda:
    for VBKGCJOrAgvNRsQXhiUpPMneELkcfS in VBKGCJOrAgvNRsQXhiUpPMneELkcda['subtitles']:
     if VBKGCJOrAgvNRsQXhiUpPMneELkcfS.get('languagecode')=='ko':
      VBKGCJOrAgvNRsQXhiUpPMneELkcaI['stream_vtt']=VBKGCJOrAgvNRsQXhiUpPMneELkcfS.get('url')
      break
    if VBKGCJOrAgvNRsQXhiUpPMneELkcaI['stream_vtt']=='':
     for VBKGCJOrAgvNRsQXhiUpPMneELkcfS in VBKGCJOrAgvNRsQXhiUpPMneELkcda['subtitles']:
      if VBKGCJOrAgvNRsQXhiUpPMneELkcfS.get('languagecode')=='ko_cc':
       VBKGCJOrAgvNRsQXhiUpPMneELkcaI['stream_vtt']=VBKGCJOrAgvNRsQXhiUpPMneELkcfS.get('url')
       break
  except VBKGCJOrAgvNRsQXhiUpPMneELkcyz as exception:
   VBKGCJOrAgvNRsQXhiUpPMneELkcyt(exception)
  return VBKGCJOrAgvNRsQXhiUpPMneELkcaI 
 def GetSportsURL(VBKGCJOrAgvNRsQXhiUpPMneELkcTH,VBKGCJOrAgvNRsQXhiUpPMneELkcHF,quality_int):
  VBKGCJOrAgvNRsQXhiUpPMneELkcaI ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  VBKGCJOrAgvNRsQXhiUpPMneELkcau=[]
  try:
   VBKGCJOrAgvNRsQXhiUpPMneELkcTY=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.API_DOMAIN+'/streaming/other'
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl={'contentid':VBKGCJOrAgvNRsQXhiUpPMneELkcHF,'contenttype':'live','action':VBKGCJOrAgvNRsQXhiUpPMneELkcaI['stream_action'],'quality':VBKGCJOrAgvNRsQXhiUpPMneELkcyx(quality_int)+'p','deviceModelId':'Windows 10','guid':VBKGCJOrAgvNRsQXhiUpPMneELkcTH.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n',}
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl.update(VBKGCJOrAgvNRsQXhiUpPMneELkcTH.GetDefaultParams(login=VBKGCJOrAgvNRsQXhiUpPMneELkcyW))
   VBKGCJOrAgvNRsQXhiUpPMneELkcdH=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.callRequestCookies('Get',VBKGCJOrAgvNRsQXhiUpPMneELkcTY,payload=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,params=VBKGCJOrAgvNRsQXhiUpPMneELkcTl,headers=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,cookies=VBKGCJOrAgvNRsQXhiUpPMneELkcyD)
   VBKGCJOrAgvNRsQXhiUpPMneELkcda=json.loads(VBKGCJOrAgvNRsQXhiUpPMneELkcdH.text)
   VBKGCJOrAgvNRsQXhiUpPMneELkcaI['stream_url']=VBKGCJOrAgvNRsQXhiUpPMneELkcda['playurl']
   if VBKGCJOrAgvNRsQXhiUpPMneELkcaI['stream_url']==VBKGCJOrAgvNRsQXhiUpPMneELkcyD:return VBKGCJOrAgvNRsQXhiUpPMneELkcaI
   VBKGCJOrAgvNRsQXhiUpPMneELkcaI['stream_cookie']=VBKGCJOrAgvNRsQXhiUpPMneELkcda['awscookie']
  except VBKGCJOrAgvNRsQXhiUpPMneELkcyz as exception:
   VBKGCJOrAgvNRsQXhiUpPMneELkcyt(exception)
  return VBKGCJOrAgvNRsQXhiUpPMneELkcaI
 def make_viewdate(VBKGCJOrAgvNRsQXhiUpPMneELkcTH):
  VBKGCJOrAgvNRsQXhiUpPMneELkcfj =VBKGCJOrAgvNRsQXhiUpPMneELkcTH.Get_Now_Datetime()
  VBKGCJOrAgvNRsQXhiUpPMneELkcfm =VBKGCJOrAgvNRsQXhiUpPMneELkcfj+datetime.timedelta(days=-1)
  VBKGCJOrAgvNRsQXhiUpPMneELkcfq =VBKGCJOrAgvNRsQXhiUpPMneELkcfj+datetime.timedelta(days=1)
  VBKGCJOrAgvNRsQXhiUpPMneELkcfD=[VBKGCJOrAgvNRsQXhiUpPMneELkcfj.strftime('%Y%m%d'),VBKGCJOrAgvNRsQXhiUpPMneELkcfq.strftime('%Y%m%d'),]
  return VBKGCJOrAgvNRsQXhiUpPMneELkcfD
 def Get_Sports_Gamelist(VBKGCJOrAgvNRsQXhiUpPMneELkcTH):
  VBKGCJOrAgvNRsQXhiUpPMneELkcfl =VBKGCJOrAgvNRsQXhiUpPMneELkcTH.make_viewdate()
  VBKGCJOrAgvNRsQXhiUpPMneELkcfF=[]
  VBKGCJOrAgvNRsQXhiUpPMneELkcfW =[]
  for VBKGCJOrAgvNRsQXhiUpPMneELkcfw in VBKGCJOrAgvNRsQXhiUpPMneELkcfl:
   VBKGCJOrAgvNRsQXhiUpPMneELkcfx=VBKGCJOrAgvNRsQXhiUpPMneELkcfw[:6]
   if VBKGCJOrAgvNRsQXhiUpPMneELkcfx not in VBKGCJOrAgvNRsQXhiUpPMneELkcfF:
    VBKGCJOrAgvNRsQXhiUpPMneELkcfF.append(VBKGCJOrAgvNRsQXhiUpPMneELkcfx)
  try:
   VBKGCJOrAgvNRsQXhiUpPMneELkcTY='https://annexapi.wavve.com/skb/baseball/teammonthlycalendarlist'
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl={'IF':'IF-PORG-002','m':'getTeamCalendarListBand','response_format':'json','spo_itm_cd':'KBO','teamcd':'all','tgroup':'B','tvalue':'BC123','ver':'2.0',}
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl.update(VBKGCJOrAgvNRsQXhiUpPMneELkcTH.GetDefaultParams(login=VBKGCJOrAgvNRsQXhiUpPMneELkcyl))
   for VBKGCJOrAgvNRsQXhiUpPMneELkcfz in VBKGCJOrAgvNRsQXhiUpPMneELkcfF:
    VBKGCJOrAgvNRsQXhiUpPMneELkcTl['date']=VBKGCJOrAgvNRsQXhiUpPMneELkcfz
    VBKGCJOrAgvNRsQXhiUpPMneELkcdH=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.callRequestCookies('Get',VBKGCJOrAgvNRsQXhiUpPMneELkcTY,payload=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,params=VBKGCJOrAgvNRsQXhiUpPMneELkcTl,headers=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,cookies=VBKGCJOrAgvNRsQXhiUpPMneELkcyD)
    VBKGCJOrAgvNRsQXhiUpPMneELkcda=json.loads(VBKGCJOrAgvNRsQXhiUpPMneELkcdH.text)
    VBKGCJOrAgvNRsQXhiUpPMneELkcdW=VBKGCJOrAgvNRsQXhiUpPMneELkcda['cell_toplist']['celllist']
    for VBKGCJOrAgvNRsQXhiUpPMneELkcdw in VBKGCJOrAgvNRsQXhiUpPMneELkcdW:
     VBKGCJOrAgvNRsQXhiUpPMneELkcft=VBKGCJOrAgvNRsQXhiUpPMneELkcdw.get('game_date')
     VBKGCJOrAgvNRsQXhiUpPMneELkcfo =VBKGCJOrAgvNRsQXhiUpPMneELkcdw.get('svc_id')
     if VBKGCJOrAgvNRsQXhiUpPMneELkcfo=='':continue
     if VBKGCJOrAgvNRsQXhiUpPMneELkcft in VBKGCJOrAgvNRsQXhiUpPMneELkcfl:
      VBKGCJOrAgvNRsQXhiUpPMneELkcfI=VBKGCJOrAgvNRsQXhiUpPMneELkcdw.get('game_status') 
      VBKGCJOrAgvNRsQXhiUpPMneELkcfu =VBKGCJOrAgvNRsQXhiUpPMneELkcdw.get('title_list')[0].get('text')
      VBKGCJOrAgvNRsQXhiUpPMneELkcft =VBKGCJOrAgvNRsQXhiUpPMneELkcft[:4]+'-'+VBKGCJOrAgvNRsQXhiUpPMneELkcft[4:6]+'-'+VBKGCJOrAgvNRsQXhiUpPMneELkcft[-2:]
      VBKGCJOrAgvNRsQXhiUpPMneELkcfb =VBKGCJOrAgvNRsQXhiUpPMneELkcdw.get('game_time')
      VBKGCJOrAgvNRsQXhiUpPMneELkcfb =VBKGCJOrAgvNRsQXhiUpPMneELkcfb[:2]+':'+VBKGCJOrAgvNRsQXhiUpPMneELkcfb[-2:]
      VBKGCJOrAgvNRsQXhiUpPMneELkcdx={'game_date':VBKGCJOrAgvNRsQXhiUpPMneELkcft,'game_time':VBKGCJOrAgvNRsQXhiUpPMneELkcfb,'svc_id':VBKGCJOrAgvNRsQXhiUpPMneELkcfo,'away_team':VBKGCJOrAgvNRsQXhiUpPMneELkcdw.get('away_team').get('team_name'),'home_team':VBKGCJOrAgvNRsQXhiUpPMneELkcdw.get('home_team').get('team_name'),'game_status':VBKGCJOrAgvNRsQXhiUpPMneELkcfI,'game_place':VBKGCJOrAgvNRsQXhiUpPMneELkcdw.get('game_place'),}
      VBKGCJOrAgvNRsQXhiUpPMneELkcfW.append(VBKGCJOrAgvNRsQXhiUpPMneELkcdx)
  except VBKGCJOrAgvNRsQXhiUpPMneELkcyz as exception:
   VBKGCJOrAgvNRsQXhiUpPMneELkcyt(exception)
   return[]
  VBKGCJOrAgvNRsQXhiUpPMneELkcfY=[]
  for i in VBKGCJOrAgvNRsQXhiUpPMneELkcyw(2):
   for VBKGCJOrAgvNRsQXhiUpPMneELkcdw in VBKGCJOrAgvNRsQXhiUpPMneELkcfW:
    if i==0 and VBKGCJOrAgvNRsQXhiUpPMneELkcdw.get('game_status')=='LIVE':
     VBKGCJOrAgvNRsQXhiUpPMneELkcfY.append(VBKGCJOrAgvNRsQXhiUpPMneELkcdw)
    elif i==1 and VBKGCJOrAgvNRsQXhiUpPMneELkcdw.get('game_status')!='LIVE':
     VBKGCJOrAgvNRsQXhiUpPMneELkcfY.append(VBKGCJOrAgvNRsQXhiUpPMneELkcdw)
  return VBKGCJOrAgvNRsQXhiUpPMneELkcfY
 def GetBookmarkInfo(VBKGCJOrAgvNRsQXhiUpPMneELkcTH,VBKGCJOrAgvNRsQXhiUpPMneELkcHy,VBKGCJOrAgvNRsQXhiUpPMneELkcHf,VBKGCJOrAgvNRsQXhiUpPMneELkcab):
  if VBKGCJOrAgvNRsQXhiUpPMneELkcHf=='tvshow':
   if VBKGCJOrAgvNRsQXhiUpPMneELkcab=='contentid':
    VBKGCJOrAgvNRsQXhiUpPMneELkcHF=VBKGCJOrAgvNRsQXhiUpPMneELkcHy
    VBKGCJOrAgvNRsQXhiUpPMneELkcHy =VBKGCJOrAgvNRsQXhiUpPMneELkcTH.ContentidToSeasonid(VBKGCJOrAgvNRsQXhiUpPMneELkcHF)
   else:
    VBKGCJOrAgvNRsQXhiUpPMneELkcHF=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.ProgramidToContentid(VBKGCJOrAgvNRsQXhiUpPMneELkcHy)
  else:
   VBKGCJOrAgvNRsQXhiUpPMneELkcHF=''
  VBKGCJOrAgvNRsQXhiUpPMneELkcyT={'indexinfo':{'ott':'wavve','videoid':VBKGCJOrAgvNRsQXhiUpPMneELkcHy,'vidtype':VBKGCJOrAgvNRsQXhiUpPMneELkcHf,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':VBKGCJOrAgvNRsQXhiUpPMneELkcHf,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if VBKGCJOrAgvNRsQXhiUpPMneELkcHf=='tvshow':
   VBKGCJOrAgvNRsQXhiUpPMneELkcTY=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.API_DOMAIN+'/fz/vod/contents/'+VBKGCJOrAgvNRsQXhiUpPMneELkcHF 
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.GetDefaultParams(login=VBKGCJOrAgvNRsQXhiUpPMneELkcyl)
   VBKGCJOrAgvNRsQXhiUpPMneELkcdH=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.callRequestCookies('Get',VBKGCJOrAgvNRsQXhiUpPMneELkcTY,payload=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,params=VBKGCJOrAgvNRsQXhiUpPMneELkcTl,headers=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,cookies=VBKGCJOrAgvNRsQXhiUpPMneELkcyD)
   VBKGCJOrAgvNRsQXhiUpPMneELkcda=json.loads(VBKGCJOrAgvNRsQXhiUpPMneELkcdH.text)
   if not('programtitle' in VBKGCJOrAgvNRsQXhiUpPMneELkcda):return{}
   VBKGCJOrAgvNRsQXhiUpPMneELkcyd=VBKGCJOrAgvNRsQXhiUpPMneELkcda
   VBKGCJOrAgvNRsQXhiUpPMneELkcyH=VBKGCJOrAgvNRsQXhiUpPMneELkcyd.get('programtitle')
   VBKGCJOrAgvNRsQXhiUpPMneELkcyT['saveinfo']['infoLabels']['title']=VBKGCJOrAgvNRsQXhiUpPMneELkcyH
   if VBKGCJOrAgvNRsQXhiUpPMneELkcyd.get('targetage')=='18' or VBKGCJOrAgvNRsQXhiUpPMneELkcyd.get('targetage')=='19' or VBKGCJOrAgvNRsQXhiUpPMneELkcyd.get('targetage')=='21':
    VBKGCJOrAgvNRsQXhiUpPMneELkcyH +=u' (%s)'%(VBKGCJOrAgvNRsQXhiUpPMneELkcyd.get('targetage'))
   VBKGCJOrAgvNRsQXhiUpPMneELkcyT['saveinfo']['title'] =VBKGCJOrAgvNRsQXhiUpPMneELkcyH
   VBKGCJOrAgvNRsQXhiUpPMneELkcyT['saveinfo']['infoLabels']['mpaa'] =VBKGCJOrAgvNRsQXhiUpPMneELkcyd.get('targetage')
   VBKGCJOrAgvNRsQXhiUpPMneELkcyT['saveinfo']['infoLabels']['plot'] =VBKGCJOrAgvNRsQXhiUpPMneELkcyd.get('programsynopsis').replace('<br>','\n')
   VBKGCJOrAgvNRsQXhiUpPMneELkcyT['saveinfo']['infoLabels']['studio'] =VBKGCJOrAgvNRsQXhiUpPMneELkcyd.get('channelname')
   if VBKGCJOrAgvNRsQXhiUpPMneELkcyd.get('firstreleaseyear')!='':VBKGCJOrAgvNRsQXhiUpPMneELkcyT['saveinfo']['infoLabels']['year'] =VBKGCJOrAgvNRsQXhiUpPMneELkcyd.get('firstreleaseyear')
   if VBKGCJOrAgvNRsQXhiUpPMneELkcyd.get('firstreleasedate')!='':VBKGCJOrAgvNRsQXhiUpPMneELkcyT['saveinfo']['infoLabels']['premiered']=VBKGCJOrAgvNRsQXhiUpPMneELkcyd.get('firstreleasedate')
   if VBKGCJOrAgvNRsQXhiUpPMneELkcyd.get('genretext') !='':VBKGCJOrAgvNRsQXhiUpPMneELkcyT['saveinfo']['infoLabels']['genre'] =[VBKGCJOrAgvNRsQXhiUpPMneELkcyd.get('genretext')]
   VBKGCJOrAgvNRsQXhiUpPMneELkcya=[]
   for VBKGCJOrAgvNRsQXhiUpPMneELkcyf in VBKGCJOrAgvNRsQXhiUpPMneELkcyd['actors']['list']:VBKGCJOrAgvNRsQXhiUpPMneELkcya.append(VBKGCJOrAgvNRsQXhiUpPMneELkcyf.get('text'))
   if VBKGCJOrAgvNRsQXhiUpPMneELkcyu(VBKGCJOrAgvNRsQXhiUpPMneELkcya)>0:
    if VBKGCJOrAgvNRsQXhiUpPMneELkcya[0]!='':VBKGCJOrAgvNRsQXhiUpPMneELkcyT['saveinfo']['infoLabels']['cast']=VBKGCJOrAgvNRsQXhiUpPMneELkcya
   VBKGCJOrAgvNRsQXhiUpPMneELkcaf =''
   VBKGCJOrAgvNRsQXhiUpPMneELkcay =''
   VBKGCJOrAgvNRsQXhiUpPMneELkcaS=''
   if VBKGCJOrAgvNRsQXhiUpPMneELkcyd.get('programposterimage')!='':VBKGCJOrAgvNRsQXhiUpPMneELkcaf =VBKGCJOrAgvNRsQXhiUpPMneELkcTH.HTTPTAG+VBKGCJOrAgvNRsQXhiUpPMneELkcyd.get('programposterimage')
   if VBKGCJOrAgvNRsQXhiUpPMneELkcyd.get('programimage') !='':VBKGCJOrAgvNRsQXhiUpPMneELkcay =VBKGCJOrAgvNRsQXhiUpPMneELkcTH.HTTPTAG+VBKGCJOrAgvNRsQXhiUpPMneELkcyd.get('programimage')
   if VBKGCJOrAgvNRsQXhiUpPMneELkcyd.get('programcircleimage')!='':VBKGCJOrAgvNRsQXhiUpPMneELkcaS=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.HTTPTAG+VBKGCJOrAgvNRsQXhiUpPMneELkcyd.get('programcircleimage')
   if 'poster_default' in VBKGCJOrAgvNRsQXhiUpPMneELkcaf:
    VBKGCJOrAgvNRsQXhiUpPMneELkcaf =VBKGCJOrAgvNRsQXhiUpPMneELkcay
    VBKGCJOrAgvNRsQXhiUpPMneELkcaS=''
   VBKGCJOrAgvNRsQXhiUpPMneELkcyT['saveinfo']['thumbnail']['poster']=VBKGCJOrAgvNRsQXhiUpPMneELkcaf
   VBKGCJOrAgvNRsQXhiUpPMneELkcyT['saveinfo']['thumbnail']['thumb']=VBKGCJOrAgvNRsQXhiUpPMneELkcay
   VBKGCJOrAgvNRsQXhiUpPMneELkcyT['saveinfo']['thumbnail']['clearlogo']=VBKGCJOrAgvNRsQXhiUpPMneELkcaS
   VBKGCJOrAgvNRsQXhiUpPMneELkcyT['saveinfo']['thumbnail']['fanart']=VBKGCJOrAgvNRsQXhiUpPMneELkcay
  else:
   VBKGCJOrAgvNRsQXhiUpPMneELkcTY=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.API_DOMAIN+'/movie/contents/'+VBKGCJOrAgvNRsQXhiUpPMneELkcHy 
   VBKGCJOrAgvNRsQXhiUpPMneELkcTl=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.GetDefaultParams(login=VBKGCJOrAgvNRsQXhiUpPMneELkcyl)
   VBKGCJOrAgvNRsQXhiUpPMneELkcdH=VBKGCJOrAgvNRsQXhiUpPMneELkcTH.callRequestCookies('Get',VBKGCJOrAgvNRsQXhiUpPMneELkcTY,payload=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,params=VBKGCJOrAgvNRsQXhiUpPMneELkcTl,headers=VBKGCJOrAgvNRsQXhiUpPMneELkcyD,cookies=VBKGCJOrAgvNRsQXhiUpPMneELkcyD)
   VBKGCJOrAgvNRsQXhiUpPMneELkcda=json.loads(VBKGCJOrAgvNRsQXhiUpPMneELkcdH.text)
   if not('title' in VBKGCJOrAgvNRsQXhiUpPMneELkcda):return{}
   VBKGCJOrAgvNRsQXhiUpPMneELkcyd=VBKGCJOrAgvNRsQXhiUpPMneELkcda
   VBKGCJOrAgvNRsQXhiUpPMneELkcyH=VBKGCJOrAgvNRsQXhiUpPMneELkcyd.get('title')
   VBKGCJOrAgvNRsQXhiUpPMneELkcyT['saveinfo']['infoLabels']['title']=VBKGCJOrAgvNRsQXhiUpPMneELkcyH
   if VBKGCJOrAgvNRsQXhiUpPMneELkcyd.get('targetage')=='18' or VBKGCJOrAgvNRsQXhiUpPMneELkcyd.get('targetage')=='19' or VBKGCJOrAgvNRsQXhiUpPMneELkcyd.get('targetage')=='21':
    VBKGCJOrAgvNRsQXhiUpPMneELkcyH +=u' (%s)'%(VBKGCJOrAgvNRsQXhiUpPMneELkcyd.get('targetage'))
   VBKGCJOrAgvNRsQXhiUpPMneELkcyT['saveinfo']['title'] =VBKGCJOrAgvNRsQXhiUpPMneELkcyH
   VBKGCJOrAgvNRsQXhiUpPMneELkcyT['saveinfo']['infoLabels']['mpaa'] =VBKGCJOrAgvNRsQXhiUpPMneELkcyd.get('targetage')
   VBKGCJOrAgvNRsQXhiUpPMneELkcyT['saveinfo']['infoLabels']['plot'] =VBKGCJOrAgvNRsQXhiUpPMneELkcyd.get('synopsis').replace('<br>','\n')
   VBKGCJOrAgvNRsQXhiUpPMneELkcyT['saveinfo']['infoLabels']['duration']=VBKGCJOrAgvNRsQXhiUpPMneELkcyd.get('playtime')
   VBKGCJOrAgvNRsQXhiUpPMneELkcyT['saveinfo']['infoLabels']['country']=VBKGCJOrAgvNRsQXhiUpPMneELkcyd.get('country')
   VBKGCJOrAgvNRsQXhiUpPMneELkcyT['saveinfo']['infoLabels']['studio'] =VBKGCJOrAgvNRsQXhiUpPMneELkcyd.get('cpname')
   if VBKGCJOrAgvNRsQXhiUpPMneELkcyd.get('releasedate')!='':
    VBKGCJOrAgvNRsQXhiUpPMneELkcyT['saveinfo']['infoLabels']['year'] =VBKGCJOrAgvNRsQXhiUpPMneELkcyd.get('releasedate')[:4]
    VBKGCJOrAgvNRsQXhiUpPMneELkcyT['saveinfo']['infoLabels']['premiered']=VBKGCJOrAgvNRsQXhiUpPMneELkcyd.get('releasedate')
   VBKGCJOrAgvNRsQXhiUpPMneELkcya=[]
   for VBKGCJOrAgvNRsQXhiUpPMneELkcyf in VBKGCJOrAgvNRsQXhiUpPMneELkcyd['actors']['list']:VBKGCJOrAgvNRsQXhiUpPMneELkcya.append(VBKGCJOrAgvNRsQXhiUpPMneELkcyf.get('text'))
   if VBKGCJOrAgvNRsQXhiUpPMneELkcyu(VBKGCJOrAgvNRsQXhiUpPMneELkcya)>0:
    if VBKGCJOrAgvNRsQXhiUpPMneELkcya[0]!='':VBKGCJOrAgvNRsQXhiUpPMneELkcyT['saveinfo']['infoLabels']['cast']=VBKGCJOrAgvNRsQXhiUpPMneELkcya
   VBKGCJOrAgvNRsQXhiUpPMneELkcyS=[]
   for VBKGCJOrAgvNRsQXhiUpPMneELkcyj in VBKGCJOrAgvNRsQXhiUpPMneELkcyd['directors']['list']:VBKGCJOrAgvNRsQXhiUpPMneELkcyS.append(VBKGCJOrAgvNRsQXhiUpPMneELkcyj.get('text'))
   if VBKGCJOrAgvNRsQXhiUpPMneELkcyu(VBKGCJOrAgvNRsQXhiUpPMneELkcyS)>0:
    if VBKGCJOrAgvNRsQXhiUpPMneELkcyS[0]!='':VBKGCJOrAgvNRsQXhiUpPMneELkcyT['saveinfo']['infoLabels']['director']=VBKGCJOrAgvNRsQXhiUpPMneELkcyS
   VBKGCJOrAgvNRsQXhiUpPMneELkcdD=[]
   for VBKGCJOrAgvNRsQXhiUpPMneELkcym in VBKGCJOrAgvNRsQXhiUpPMneELkcyd['genre']['list']:VBKGCJOrAgvNRsQXhiUpPMneELkcdD.append(VBKGCJOrAgvNRsQXhiUpPMneELkcym.get('text'))
   if VBKGCJOrAgvNRsQXhiUpPMneELkcyu(VBKGCJOrAgvNRsQXhiUpPMneELkcdD)>0:
    if VBKGCJOrAgvNRsQXhiUpPMneELkcdD[0]!='':VBKGCJOrAgvNRsQXhiUpPMneELkcyT['saveinfo']['infoLabels']['genre']=VBKGCJOrAgvNRsQXhiUpPMneELkcdD
   VBKGCJOrAgvNRsQXhiUpPMneELkcaf ='https://%s'%VBKGCJOrAgvNRsQXhiUpPMneELkcyd['image']
   VBKGCJOrAgvNRsQXhiUpPMneELkcyT['saveinfo']['thumbnail']['poster'] =VBKGCJOrAgvNRsQXhiUpPMneELkcaf
   VBKGCJOrAgvNRsQXhiUpPMneELkcyT['saveinfo']['thumbnail']['thumb'] =VBKGCJOrAgvNRsQXhiUpPMneELkcaf
  return VBKGCJOrAgvNRsQXhiUpPMneELkcyT
# Created by pyminifier (https://github.com/liftoff/pyminifier)
