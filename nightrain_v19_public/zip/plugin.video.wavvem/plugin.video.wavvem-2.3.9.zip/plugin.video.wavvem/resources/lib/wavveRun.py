__author__="NightRain"
egWdYKRbqTIBkcFtiwEVOlQAuCUaSH=object
egWdYKRbqTIBkcFtiwEVOlQAuCUaSG=None
egWdYKRbqTIBkcFtiwEVOlQAuCUaSh=int
egWdYKRbqTIBkcFtiwEVOlQAuCUaSr=True
egWdYKRbqTIBkcFtiwEVOlQAuCUaSn=False
egWdYKRbqTIBkcFtiwEVOlQAuCUaSL=type
egWdYKRbqTIBkcFtiwEVOlQAuCUaSy=dict
egWdYKRbqTIBkcFtiwEVOlQAuCUaSN=getattr
egWdYKRbqTIBkcFtiwEVOlQAuCUaSs=list
egWdYKRbqTIBkcFtiwEVOlQAuCUaSp=len
egWdYKRbqTIBkcFtiwEVOlQAuCUaSP=range
egWdYKRbqTIBkcFtiwEVOlQAuCUaSo=str
egWdYKRbqTIBkcFtiwEVOlQAuCUaSj=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import json
egWdYKRbqTIBkcFtiwEVOlQAuCUamz=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://apis.wavve.com/v1/multiband/GN51','icon':'home.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&uicode=VN500','page':'1','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?WeekDay=all&broadcastid=1390539&contenttype=vod&genre=01&orderby=viewtime&uicode=VN4&uiparent=FN0&uirank=0&uitype=VN4','page':'1','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?WeekDay=all&broadcastid=1311034&contenttype=vod&genre=02&orderby=viewtime&uicode=VN3&uiparent=FN0&uirank=0&uitype=VN3','page':'1','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'CN21','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'vod09','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'vod09','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'4','sType':'movie','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'4','sType':'movie','orderby':'modifydate','ordernm':'업데이트순','icon':''},{'title':'프로야구 - 경기중 시청가능','mode':'GAME_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'(웨이브) 검색','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'(웨이브) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
egWdYKRbqTIBkcFtiwEVOlQAuCUamH=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
egWdYKRbqTIBkcFtiwEVOlQAuCUamG=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
egWdYKRbqTIBkcFtiwEVOlQAuCUamh={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
egWdYKRbqTIBkcFtiwEVOlQAuCUamr =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
egWdYKRbqTIBkcFtiwEVOlQAuCUamS=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_searched.txt'))
from wavveCore import*
class egWdYKRbqTIBkcFtiwEVOlQAuCUamv(egWdYKRbqTIBkcFtiwEVOlQAuCUaSH):
 def __init__(egWdYKRbqTIBkcFtiwEVOlQAuCUamn,egWdYKRbqTIBkcFtiwEVOlQAuCUamL,egWdYKRbqTIBkcFtiwEVOlQAuCUamy,egWdYKRbqTIBkcFtiwEVOlQAuCUamN):
  egWdYKRbqTIBkcFtiwEVOlQAuCUamn._addon_url =egWdYKRbqTIBkcFtiwEVOlQAuCUamL
  egWdYKRbqTIBkcFtiwEVOlQAuCUamn._addon_handle=egWdYKRbqTIBkcFtiwEVOlQAuCUamy
  egWdYKRbqTIBkcFtiwEVOlQAuCUamn.main_params =egWdYKRbqTIBkcFtiwEVOlQAuCUamN
  egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj =VBKGCJOrAgvNRsQXhiUpPMneELkcTd() 
 def addon_noti(egWdYKRbqTIBkcFtiwEVOlQAuCUamn,sting):
  try:
   egWdYKRbqTIBkcFtiwEVOlQAuCUamp=xbmcgui.Dialog()
   egWdYKRbqTIBkcFtiwEVOlQAuCUamp.notification(__addonname__,sting)
  except:
   egWdYKRbqTIBkcFtiwEVOlQAuCUaSG
 def addon_log(egWdYKRbqTIBkcFtiwEVOlQAuCUamn,string):
  try:
   egWdYKRbqTIBkcFtiwEVOlQAuCUamP=string.encode('utf-8','ignore')
  except:
   egWdYKRbqTIBkcFtiwEVOlQAuCUamP='addonException: addon_log'
  egWdYKRbqTIBkcFtiwEVOlQAuCUamo=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,egWdYKRbqTIBkcFtiwEVOlQAuCUamP),level=egWdYKRbqTIBkcFtiwEVOlQAuCUamo)
 def get_keyboard_input(egWdYKRbqTIBkcFtiwEVOlQAuCUamn,egWdYKRbqTIBkcFtiwEVOlQAuCUavy):
  egWdYKRbqTIBkcFtiwEVOlQAuCUamj=egWdYKRbqTIBkcFtiwEVOlQAuCUaSG
  kb=xbmc.Keyboard()
  kb.setHeading(egWdYKRbqTIBkcFtiwEVOlQAuCUavy)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   egWdYKRbqTIBkcFtiwEVOlQAuCUamj=kb.getText()
  return egWdYKRbqTIBkcFtiwEVOlQAuCUamj
 def get_settings_account(egWdYKRbqTIBkcFtiwEVOlQAuCUamn):
  egWdYKRbqTIBkcFtiwEVOlQAuCUamX =__addon__.getSetting('id')
  egWdYKRbqTIBkcFtiwEVOlQAuCUamM =__addon__.getSetting('pw')
  egWdYKRbqTIBkcFtiwEVOlQAuCUamJ=egWdYKRbqTIBkcFtiwEVOlQAuCUaSh(__addon__.getSetting('selected_profile'))
  return(egWdYKRbqTIBkcFtiwEVOlQAuCUamX,egWdYKRbqTIBkcFtiwEVOlQAuCUamM,egWdYKRbqTIBkcFtiwEVOlQAuCUamJ)
 def get_settings_totalsearch(egWdYKRbqTIBkcFtiwEVOlQAuCUamn):
  egWdYKRbqTIBkcFtiwEVOlQAuCUamD =egWdYKRbqTIBkcFtiwEVOlQAuCUaSr if __addon__.getSetting('local_search')=='true' else egWdYKRbqTIBkcFtiwEVOlQAuCUaSn
  egWdYKRbqTIBkcFtiwEVOlQAuCUamx=egWdYKRbqTIBkcFtiwEVOlQAuCUaSr if __addon__.getSetting('local_history')=='true' else egWdYKRbqTIBkcFtiwEVOlQAuCUaSn
  egWdYKRbqTIBkcFtiwEVOlQAuCUamf =egWdYKRbqTIBkcFtiwEVOlQAuCUaSr if __addon__.getSetting('total_search')=='true' else egWdYKRbqTIBkcFtiwEVOlQAuCUaSn
  egWdYKRbqTIBkcFtiwEVOlQAuCUavm=egWdYKRbqTIBkcFtiwEVOlQAuCUaSr if __addon__.getSetting('total_history')=='true' else egWdYKRbqTIBkcFtiwEVOlQAuCUaSn
  egWdYKRbqTIBkcFtiwEVOlQAuCUavz=egWdYKRbqTIBkcFtiwEVOlQAuCUaSr if __addon__.getSetting('menu_bookmark')=='true' else egWdYKRbqTIBkcFtiwEVOlQAuCUaSn
  return(egWdYKRbqTIBkcFtiwEVOlQAuCUamD,egWdYKRbqTIBkcFtiwEVOlQAuCUamx,egWdYKRbqTIBkcFtiwEVOlQAuCUamf,egWdYKRbqTIBkcFtiwEVOlQAuCUavm,egWdYKRbqTIBkcFtiwEVOlQAuCUavz)
 def get_settings_makebookmark(egWdYKRbqTIBkcFtiwEVOlQAuCUamn):
  return egWdYKRbqTIBkcFtiwEVOlQAuCUaSr if __addon__.getSetting('make_bookmark')=='true' else egWdYKRbqTIBkcFtiwEVOlQAuCUaSn
 def get_settings_play(egWdYKRbqTIBkcFtiwEVOlQAuCUamn):
  egWdYKRbqTIBkcFtiwEVOlQAuCUavH={'enable_hdr':egWdYKRbqTIBkcFtiwEVOlQAuCUaSr if __addon__.getSetting('enable_hdr')=='true' else egWdYKRbqTIBkcFtiwEVOlQAuCUaSn,}
  if egWdYKRbqTIBkcFtiwEVOlQAuCUavH['enable_hdr']==egWdYKRbqTIBkcFtiwEVOlQAuCUaSr:
   if egWdYKRbqTIBkcFtiwEVOlQAuCUamn.get_selQuality()<1080:egWdYKRbqTIBkcFtiwEVOlQAuCUavH['enable_hdr']=egWdYKRbqTIBkcFtiwEVOlQAuCUaSn
  return(egWdYKRbqTIBkcFtiwEVOlQAuCUavH)
 def get_selQuality(egWdYKRbqTIBkcFtiwEVOlQAuCUamn):
  try:
   egWdYKRbqTIBkcFtiwEVOlQAuCUavG=[1080,720,480,360]
   egWdYKRbqTIBkcFtiwEVOlQAuCUavh=egWdYKRbqTIBkcFtiwEVOlQAuCUaSh(__addon__.getSetting('selected_quality'))
   return egWdYKRbqTIBkcFtiwEVOlQAuCUavG[egWdYKRbqTIBkcFtiwEVOlQAuCUavh]
  except:
   egWdYKRbqTIBkcFtiwEVOlQAuCUaSG
  return 1080 
 def get_settings_exclusion21(egWdYKRbqTIBkcFtiwEVOlQAuCUamn):
  egWdYKRbqTIBkcFtiwEVOlQAuCUavr =__addon__.getSetting('exclusion21')
  if egWdYKRbqTIBkcFtiwEVOlQAuCUavr=='false':
   return egWdYKRbqTIBkcFtiwEVOlQAuCUaSn
  else:
   return egWdYKRbqTIBkcFtiwEVOlQAuCUaSr
 def get_settings_direct_replay(egWdYKRbqTIBkcFtiwEVOlQAuCUamn):
  egWdYKRbqTIBkcFtiwEVOlQAuCUavS=egWdYKRbqTIBkcFtiwEVOlQAuCUaSh(__addon__.getSetting('direct_replay'))
  if egWdYKRbqTIBkcFtiwEVOlQAuCUavS==0:
   return egWdYKRbqTIBkcFtiwEVOlQAuCUaSn
  else:
   return egWdYKRbqTIBkcFtiwEVOlQAuCUaSr
 def set_winEpisodeOrderby(egWdYKRbqTIBkcFtiwEVOlQAuCUamn,egWdYKRbqTIBkcFtiwEVOlQAuCUavn):
  __addon__.setSetting('wavve_orderby',egWdYKRbqTIBkcFtiwEVOlQAuCUavn)
 def get_winEpisodeOrderby(egWdYKRbqTIBkcFtiwEVOlQAuCUamn):
  egWdYKRbqTIBkcFtiwEVOlQAuCUavn=__addon__.getSetting('wavve_orderby')
  if egWdYKRbqTIBkcFtiwEVOlQAuCUavn in['',egWdYKRbqTIBkcFtiwEVOlQAuCUaSG]:egWdYKRbqTIBkcFtiwEVOlQAuCUavn='desc'
  return egWdYKRbqTIBkcFtiwEVOlQAuCUavn
 def add_dir(egWdYKRbqTIBkcFtiwEVOlQAuCUamn,label,sublabel='',img='',infoLabels=egWdYKRbqTIBkcFtiwEVOlQAuCUaSG,isFolder=egWdYKRbqTIBkcFtiwEVOlQAuCUaSr,params='',isLink=egWdYKRbqTIBkcFtiwEVOlQAuCUaSn,ContextMenu=egWdYKRbqTIBkcFtiwEVOlQAuCUaSG):
  egWdYKRbqTIBkcFtiwEVOlQAuCUavL='%s?%s'%(egWdYKRbqTIBkcFtiwEVOlQAuCUamn._addon_url,urllib.parse.urlencode(params))
  if sublabel:egWdYKRbqTIBkcFtiwEVOlQAuCUavy='%s < %s >'%(label,sublabel)
  else: egWdYKRbqTIBkcFtiwEVOlQAuCUavy=label
  if not img:img='DefaultFolder.png'
  egWdYKRbqTIBkcFtiwEVOlQAuCUavN=xbmcgui.ListItem(egWdYKRbqTIBkcFtiwEVOlQAuCUavy)
  if egWdYKRbqTIBkcFtiwEVOlQAuCUaSL(img)==egWdYKRbqTIBkcFtiwEVOlQAuCUaSy:
   egWdYKRbqTIBkcFtiwEVOlQAuCUavN.setArt(img)
  else:
   egWdYKRbqTIBkcFtiwEVOlQAuCUavN.setArt({'thumb':img,'poster':img})
  if egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.KodiVersion>=20:
   if infoLabels:egWdYKRbqTIBkcFtiwEVOlQAuCUamn.Set_InfoTag(egWdYKRbqTIBkcFtiwEVOlQAuCUavN.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:egWdYKRbqTIBkcFtiwEVOlQAuCUavN.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   egWdYKRbqTIBkcFtiwEVOlQAuCUavN.setProperty('IsPlayable','true')
  if ContextMenu:egWdYKRbqTIBkcFtiwEVOlQAuCUavN.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(egWdYKRbqTIBkcFtiwEVOlQAuCUamn._addon_handle,egWdYKRbqTIBkcFtiwEVOlQAuCUavL,egWdYKRbqTIBkcFtiwEVOlQAuCUavN,isFolder)
 def Set_InfoTag(egWdYKRbqTIBkcFtiwEVOlQAuCUamn,video_InfoTag:xbmc.InfoTagVideo,egWdYKRbqTIBkcFtiwEVOlQAuCUavJ):
  for egWdYKRbqTIBkcFtiwEVOlQAuCUavs,value in egWdYKRbqTIBkcFtiwEVOlQAuCUavJ.items():
   if egWdYKRbqTIBkcFtiwEVOlQAuCUamh[egWdYKRbqTIBkcFtiwEVOlQAuCUavs]['type']=='string':
    egWdYKRbqTIBkcFtiwEVOlQAuCUaSN(video_InfoTag,egWdYKRbqTIBkcFtiwEVOlQAuCUamh[egWdYKRbqTIBkcFtiwEVOlQAuCUavs]['func'])(value)
   elif egWdYKRbqTIBkcFtiwEVOlQAuCUamh[egWdYKRbqTIBkcFtiwEVOlQAuCUavs]['type']=='int':
    if egWdYKRbqTIBkcFtiwEVOlQAuCUaSL(value)==egWdYKRbqTIBkcFtiwEVOlQAuCUaSh:
     egWdYKRbqTIBkcFtiwEVOlQAuCUavp=egWdYKRbqTIBkcFtiwEVOlQAuCUaSh(value)
    else:
     egWdYKRbqTIBkcFtiwEVOlQAuCUavp=0
    egWdYKRbqTIBkcFtiwEVOlQAuCUaSN(video_InfoTag,egWdYKRbqTIBkcFtiwEVOlQAuCUamh[egWdYKRbqTIBkcFtiwEVOlQAuCUavs]['func'])(egWdYKRbqTIBkcFtiwEVOlQAuCUavp)
   elif egWdYKRbqTIBkcFtiwEVOlQAuCUamh[egWdYKRbqTIBkcFtiwEVOlQAuCUavs]['type']=='actor':
    if value!=[]:
     egWdYKRbqTIBkcFtiwEVOlQAuCUaSN(video_InfoTag,egWdYKRbqTIBkcFtiwEVOlQAuCUamh[egWdYKRbqTIBkcFtiwEVOlQAuCUavs]['func'])([xbmc.Actor(name)for name in value])
   elif egWdYKRbqTIBkcFtiwEVOlQAuCUamh[egWdYKRbqTIBkcFtiwEVOlQAuCUavs]['type']=='list':
    if egWdYKRbqTIBkcFtiwEVOlQAuCUaSL(value)==egWdYKRbqTIBkcFtiwEVOlQAuCUaSs:
     egWdYKRbqTIBkcFtiwEVOlQAuCUaSN(video_InfoTag,egWdYKRbqTIBkcFtiwEVOlQAuCUamh[egWdYKRbqTIBkcFtiwEVOlQAuCUavs]['func'])(value)
    else:
     egWdYKRbqTIBkcFtiwEVOlQAuCUaSN(video_InfoTag,egWdYKRbqTIBkcFtiwEVOlQAuCUamh[egWdYKRbqTIBkcFtiwEVOlQAuCUavs]['func'])([value])
 def dp_Main_List(egWdYKRbqTIBkcFtiwEVOlQAuCUamn):
  (egWdYKRbqTIBkcFtiwEVOlQAuCUamD,egWdYKRbqTIBkcFtiwEVOlQAuCUamx,egWdYKRbqTIBkcFtiwEVOlQAuCUamf,egWdYKRbqTIBkcFtiwEVOlQAuCUavm,egWdYKRbqTIBkcFtiwEVOlQAuCUavz)=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.get_settings_totalsearch()
  for egWdYKRbqTIBkcFtiwEVOlQAuCUavP in egWdYKRbqTIBkcFtiwEVOlQAuCUamz:
   egWdYKRbqTIBkcFtiwEVOlQAuCUavy=egWdYKRbqTIBkcFtiwEVOlQAuCUavP.get('title')
   egWdYKRbqTIBkcFtiwEVOlQAuCUavo=''
   if egWdYKRbqTIBkcFtiwEVOlQAuCUavP.get('mode')=='SEARCH_GROUP' and egWdYKRbqTIBkcFtiwEVOlQAuCUamD ==egWdYKRbqTIBkcFtiwEVOlQAuCUaSn:continue
   elif egWdYKRbqTIBkcFtiwEVOlQAuCUavP.get('mode')=='SEARCH_HISTORY' and egWdYKRbqTIBkcFtiwEVOlQAuCUamx==egWdYKRbqTIBkcFtiwEVOlQAuCUaSn:continue
   elif egWdYKRbqTIBkcFtiwEVOlQAuCUavP.get('mode')=='TOTAL_SEARCH' and egWdYKRbqTIBkcFtiwEVOlQAuCUamf ==egWdYKRbqTIBkcFtiwEVOlQAuCUaSn:continue
   elif egWdYKRbqTIBkcFtiwEVOlQAuCUavP.get('mode')=='TOTAL_HISTORY' and egWdYKRbqTIBkcFtiwEVOlQAuCUavm==egWdYKRbqTIBkcFtiwEVOlQAuCUaSn:continue
   elif egWdYKRbqTIBkcFtiwEVOlQAuCUavP.get('mode')=='MENU_BOOKMARK' and egWdYKRbqTIBkcFtiwEVOlQAuCUavz==egWdYKRbqTIBkcFtiwEVOlQAuCUaSn:continue
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj={'mode':egWdYKRbqTIBkcFtiwEVOlQAuCUavP.get('mode'),'sCode':egWdYKRbqTIBkcFtiwEVOlQAuCUavP.get('sCode'),'sIndex':egWdYKRbqTIBkcFtiwEVOlQAuCUavP.get('sIndex'),'sType':egWdYKRbqTIBkcFtiwEVOlQAuCUavP.get('sType'),'suburl':egWdYKRbqTIBkcFtiwEVOlQAuCUavP.get('suburl'),'subapi':egWdYKRbqTIBkcFtiwEVOlQAuCUavP.get('subapi'),'page':egWdYKRbqTIBkcFtiwEVOlQAuCUavP.get('page'),'orderby':egWdYKRbqTIBkcFtiwEVOlQAuCUavP.get('orderby'),'ordernm':egWdYKRbqTIBkcFtiwEVOlQAuCUavP.get('ordernm')}
   if egWdYKRbqTIBkcFtiwEVOlQAuCUavP.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    egWdYKRbqTIBkcFtiwEVOlQAuCUavX=egWdYKRbqTIBkcFtiwEVOlQAuCUaSn
    egWdYKRbqTIBkcFtiwEVOlQAuCUavM =egWdYKRbqTIBkcFtiwEVOlQAuCUaSr
   else:
    egWdYKRbqTIBkcFtiwEVOlQAuCUavX=egWdYKRbqTIBkcFtiwEVOlQAuCUaSr
    egWdYKRbqTIBkcFtiwEVOlQAuCUavM =egWdYKRbqTIBkcFtiwEVOlQAuCUaSn
   egWdYKRbqTIBkcFtiwEVOlQAuCUavJ={'title':egWdYKRbqTIBkcFtiwEVOlQAuCUavy,'plot':egWdYKRbqTIBkcFtiwEVOlQAuCUavy}
   if egWdYKRbqTIBkcFtiwEVOlQAuCUavP.get('mode')=='XXX':egWdYKRbqTIBkcFtiwEVOlQAuCUavJ=egWdYKRbqTIBkcFtiwEVOlQAuCUaSG
   if 'icon' in egWdYKRbqTIBkcFtiwEVOlQAuCUavP:egWdYKRbqTIBkcFtiwEVOlQAuCUavo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',egWdYKRbqTIBkcFtiwEVOlQAuCUavP.get('icon')) 
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.add_dir(egWdYKRbqTIBkcFtiwEVOlQAuCUavy,sublabel='',img=egWdYKRbqTIBkcFtiwEVOlQAuCUavo,infoLabels=egWdYKRbqTIBkcFtiwEVOlQAuCUavJ,isFolder=egWdYKRbqTIBkcFtiwEVOlQAuCUavX,params=egWdYKRbqTIBkcFtiwEVOlQAuCUavj,isLink=egWdYKRbqTIBkcFtiwEVOlQAuCUavM)
  xbmcplugin.endOfDirectory(egWdYKRbqTIBkcFtiwEVOlQAuCUamn._addon_handle,cacheToDisc=egWdYKRbqTIBkcFtiwEVOlQAuCUaSr)
 def dp_Search_Group(egWdYKRbqTIBkcFtiwEVOlQAuCUamn,args):
  if 'search_key' in args:
   egWdYKRbqTIBkcFtiwEVOlQAuCUavf=args.get('search_key')
  else:
   egWdYKRbqTIBkcFtiwEVOlQAuCUavf=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not egWdYKRbqTIBkcFtiwEVOlQAuCUavf:
    return
  for egWdYKRbqTIBkcFtiwEVOlQAuCUazm in egWdYKRbqTIBkcFtiwEVOlQAuCUamH:
   egWdYKRbqTIBkcFtiwEVOlQAuCUazv =egWdYKRbqTIBkcFtiwEVOlQAuCUazm.get('mode')
   egWdYKRbqTIBkcFtiwEVOlQAuCUazH=egWdYKRbqTIBkcFtiwEVOlQAuCUazm.get('sType')
   egWdYKRbqTIBkcFtiwEVOlQAuCUavy=egWdYKRbqTIBkcFtiwEVOlQAuCUazm.get('title')
   (egWdYKRbqTIBkcFtiwEVOlQAuCUazG,egWdYKRbqTIBkcFtiwEVOlQAuCUazh)=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.Get_Search_List(egWdYKRbqTIBkcFtiwEVOlQAuCUavf,egWdYKRbqTIBkcFtiwEVOlQAuCUazH,1,exclusion21=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.get_settings_exclusion21())
   egWdYKRbqTIBkcFtiwEVOlQAuCUavJ={'plot':'검색어 : '+egWdYKRbqTIBkcFtiwEVOlQAuCUavf+'\n\n'+egWdYKRbqTIBkcFtiwEVOlQAuCUamn.Search_FreeList(egWdYKRbqTIBkcFtiwEVOlQAuCUazG)}
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj={'mode':egWdYKRbqTIBkcFtiwEVOlQAuCUazv,'sType':egWdYKRbqTIBkcFtiwEVOlQAuCUazH,'search_key':egWdYKRbqTIBkcFtiwEVOlQAuCUavf,'page':'1',}
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.add_dir(egWdYKRbqTIBkcFtiwEVOlQAuCUavy,sublabel='',img='',infoLabels=egWdYKRbqTIBkcFtiwEVOlQAuCUavJ,isFolder=egWdYKRbqTIBkcFtiwEVOlQAuCUaSr,params=egWdYKRbqTIBkcFtiwEVOlQAuCUavj)
  if egWdYKRbqTIBkcFtiwEVOlQAuCUaSp(egWdYKRbqTIBkcFtiwEVOlQAuCUamH)>0:xbmcplugin.endOfDirectory(egWdYKRbqTIBkcFtiwEVOlQAuCUamn._addon_handle,cacheToDisc=egWdYKRbqTIBkcFtiwEVOlQAuCUaSr)
  egWdYKRbqTIBkcFtiwEVOlQAuCUamn.Save_Searched_List(egWdYKRbqTIBkcFtiwEVOlQAuCUavf)
 def Search_FreeList(egWdYKRbqTIBkcFtiwEVOlQAuCUamn,search_list):
  egWdYKRbqTIBkcFtiwEVOlQAuCUazr=''
  egWdYKRbqTIBkcFtiwEVOlQAuCUazS=7
  try:
   if egWdYKRbqTIBkcFtiwEVOlQAuCUaSp(search_list)==0:return '검색결과 없음'
   for i in egWdYKRbqTIBkcFtiwEVOlQAuCUaSP(egWdYKRbqTIBkcFtiwEVOlQAuCUaSp(search_list)):
    if i>=egWdYKRbqTIBkcFtiwEVOlQAuCUazS:
     egWdYKRbqTIBkcFtiwEVOlQAuCUazr=egWdYKRbqTIBkcFtiwEVOlQAuCUazr+'...'
     break
    egWdYKRbqTIBkcFtiwEVOlQAuCUazr=egWdYKRbqTIBkcFtiwEVOlQAuCUazr+search_list[i]['title']+'\n'
  except:
   return ''
  return egWdYKRbqTIBkcFtiwEVOlQAuCUazr
 def dp_Watch_Group(egWdYKRbqTIBkcFtiwEVOlQAuCUamn,args):
  for egWdYKRbqTIBkcFtiwEVOlQAuCUazn in egWdYKRbqTIBkcFtiwEVOlQAuCUamG:
   egWdYKRbqTIBkcFtiwEVOlQAuCUavy=egWdYKRbqTIBkcFtiwEVOlQAuCUazn.get('title')
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj={'mode':egWdYKRbqTIBkcFtiwEVOlQAuCUazn.get('mode'),'sType':egWdYKRbqTIBkcFtiwEVOlQAuCUazn.get('sType')}
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.add_dir(egWdYKRbqTIBkcFtiwEVOlQAuCUavy,sublabel='',img='',infoLabels=egWdYKRbqTIBkcFtiwEVOlQAuCUaSG,isFolder=egWdYKRbqTIBkcFtiwEVOlQAuCUaSr,params=egWdYKRbqTIBkcFtiwEVOlQAuCUavj)
  if egWdYKRbqTIBkcFtiwEVOlQAuCUaSp(egWdYKRbqTIBkcFtiwEVOlQAuCUamG)>0:xbmcplugin.endOfDirectory(egWdYKRbqTIBkcFtiwEVOlQAuCUamn._addon_handle,cacheToDisc=egWdYKRbqTIBkcFtiwEVOlQAuCUaSr)
 def dp_Search_History(egWdYKRbqTIBkcFtiwEVOlQAuCUamn,args):
  egWdYKRbqTIBkcFtiwEVOlQAuCUazL=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.Load_List_File('search')
  for egWdYKRbqTIBkcFtiwEVOlQAuCUazy in egWdYKRbqTIBkcFtiwEVOlQAuCUazL:
   egWdYKRbqTIBkcFtiwEVOlQAuCUazN=egWdYKRbqTIBkcFtiwEVOlQAuCUaSy(urllib.parse.parse_qsl(egWdYKRbqTIBkcFtiwEVOlQAuCUazy))
   egWdYKRbqTIBkcFtiwEVOlQAuCUazs=egWdYKRbqTIBkcFtiwEVOlQAuCUazN.get('skey').strip()
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj={'mode':'SEARCH_GROUP','search_key':egWdYKRbqTIBkcFtiwEVOlQAuCUazs,}
   egWdYKRbqTIBkcFtiwEVOlQAuCUazp={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':egWdYKRbqTIBkcFtiwEVOlQAuCUazs,'vType':'-',}
   egWdYKRbqTIBkcFtiwEVOlQAuCUazP=urllib.parse.urlencode(egWdYKRbqTIBkcFtiwEVOlQAuCUazp)
   egWdYKRbqTIBkcFtiwEVOlQAuCUazo=[('선택된 검색어 ( %s ) 삭제'%(egWdYKRbqTIBkcFtiwEVOlQAuCUazs),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(egWdYKRbqTIBkcFtiwEVOlQAuCUazP))]
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.add_dir(egWdYKRbqTIBkcFtiwEVOlQAuCUazs,sublabel='',img=egWdYKRbqTIBkcFtiwEVOlQAuCUaSG,infoLabels=egWdYKRbqTIBkcFtiwEVOlQAuCUaSG,isFolder=egWdYKRbqTIBkcFtiwEVOlQAuCUaSr,params=egWdYKRbqTIBkcFtiwEVOlQAuCUavj,ContextMenu=egWdYKRbqTIBkcFtiwEVOlQAuCUazo)
  egWdYKRbqTIBkcFtiwEVOlQAuCUazj={'plot':'검색목록 전체를 삭제합니다.'}
  egWdYKRbqTIBkcFtiwEVOlQAuCUavy='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  egWdYKRbqTIBkcFtiwEVOlQAuCUavj={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  egWdYKRbqTIBkcFtiwEVOlQAuCUavo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  egWdYKRbqTIBkcFtiwEVOlQAuCUamn.add_dir(egWdYKRbqTIBkcFtiwEVOlQAuCUavy,sublabel='',img=egWdYKRbqTIBkcFtiwEVOlQAuCUavo,infoLabels=egWdYKRbqTIBkcFtiwEVOlQAuCUazj,isFolder=egWdYKRbqTIBkcFtiwEVOlQAuCUaSn,params=egWdYKRbqTIBkcFtiwEVOlQAuCUavj,isLink=egWdYKRbqTIBkcFtiwEVOlQAuCUaSr)
  xbmcplugin.endOfDirectory(egWdYKRbqTIBkcFtiwEVOlQAuCUamn._addon_handle,cacheToDisc=egWdYKRbqTIBkcFtiwEVOlQAuCUaSn)
 def dp_Search_List(egWdYKRbqTIBkcFtiwEVOlQAuCUamn,args):
  egWdYKRbqTIBkcFtiwEVOlQAuCUazH =args.get('sType')
  egWdYKRbqTIBkcFtiwEVOlQAuCUazX =egWdYKRbqTIBkcFtiwEVOlQAuCUaSh(args.get('page'))
  if 'search_key' in args:
   egWdYKRbqTIBkcFtiwEVOlQAuCUavf=args.get('search_key')
  else:
   egWdYKRbqTIBkcFtiwEVOlQAuCUavf=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not egWdYKRbqTIBkcFtiwEVOlQAuCUavf:
    xbmcplugin.endOfDirectory(egWdYKRbqTIBkcFtiwEVOlQAuCUamn._addon_handle)
    return
  egWdYKRbqTIBkcFtiwEVOlQAuCUazM,egWdYKRbqTIBkcFtiwEVOlQAuCUazh=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.Get_Search_List(egWdYKRbqTIBkcFtiwEVOlQAuCUavf,egWdYKRbqTIBkcFtiwEVOlQAuCUazH,egWdYKRbqTIBkcFtiwEVOlQAuCUazX,exclusion21=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.get_settings_exclusion21())
  for egWdYKRbqTIBkcFtiwEVOlQAuCUazJ in egWdYKRbqTIBkcFtiwEVOlQAuCUazM:
   egWdYKRbqTIBkcFtiwEVOlQAuCUazD =egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('videoid')
   egWdYKRbqTIBkcFtiwEVOlQAuCUazx =egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('vidtype')
   egWdYKRbqTIBkcFtiwEVOlQAuCUavy =egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('title')
   egWdYKRbqTIBkcFtiwEVOlQAuCUazf=egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('thumbnail')
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHm =egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('age')
   if egWdYKRbqTIBkcFtiwEVOlQAuCUaHm=='18' or egWdYKRbqTIBkcFtiwEVOlQAuCUaHm=='19' or egWdYKRbqTIBkcFtiwEVOlQAuCUaHm=='21':egWdYKRbqTIBkcFtiwEVOlQAuCUavy+=' (%s)'%(egWdYKRbqTIBkcFtiwEVOlQAuCUaHm)
   egWdYKRbqTIBkcFtiwEVOlQAuCUazj={'mediatype':'tvshow' if egWdYKRbqTIBkcFtiwEVOlQAuCUazH=='vod' else 'movie','mpaa':egWdYKRbqTIBkcFtiwEVOlQAuCUaHm,'title':egWdYKRbqTIBkcFtiwEVOlQAuCUavy,'plot':egWdYKRbqTIBkcFtiwEVOlQAuCUavy}
   if egWdYKRbqTIBkcFtiwEVOlQAuCUazH=='vod':
    egWdYKRbqTIBkcFtiwEVOlQAuCUavj={'mode':'EPISODE_LIST','seasonid':egWdYKRbqTIBkcFtiwEVOlQAuCUazD,'page':'1',}
    egWdYKRbqTIBkcFtiwEVOlQAuCUavX=egWdYKRbqTIBkcFtiwEVOlQAuCUaSr
   else:
    egWdYKRbqTIBkcFtiwEVOlQAuCUavj={'mode':'MOVIE','contentid':egWdYKRbqTIBkcFtiwEVOlQAuCUazD,'title':egWdYKRbqTIBkcFtiwEVOlQAuCUavy,'thumbnail':egWdYKRbqTIBkcFtiwEVOlQAuCUazf,'age':egWdYKRbqTIBkcFtiwEVOlQAuCUaHm,}
    egWdYKRbqTIBkcFtiwEVOlQAuCUavX=egWdYKRbqTIBkcFtiwEVOlQAuCUaSn
   egWdYKRbqTIBkcFtiwEVOlQAuCUazo=[]
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHv={'mode':'VIEW_DETAIL','values':{'videoid':egWdYKRbqTIBkcFtiwEVOlQAuCUazD,'vidtype':'tvshow' if egWdYKRbqTIBkcFtiwEVOlQAuCUazH=='vod' else 'movie','contenttype':egWdYKRbqTIBkcFtiwEVOlQAuCUazx,}}
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHz=json.dumps(egWdYKRbqTIBkcFtiwEVOlQAuCUaHv,separators=(',',':'))
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHz=base64.standard_b64encode(egWdYKRbqTIBkcFtiwEVOlQAuCUaHz.encode()).decode('utf-8')
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHz=egWdYKRbqTIBkcFtiwEVOlQAuCUaHz.replace('+','%2B')
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHG='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(egWdYKRbqTIBkcFtiwEVOlQAuCUaHz)
   egWdYKRbqTIBkcFtiwEVOlQAuCUazo.append(('상세정보 조회',egWdYKRbqTIBkcFtiwEVOlQAuCUaHG))
   if egWdYKRbqTIBkcFtiwEVOlQAuCUamn.get_settings_makebookmark():
    egWdYKRbqTIBkcFtiwEVOlQAuCUaHv={'videoid':egWdYKRbqTIBkcFtiwEVOlQAuCUazD,'vidtype':'tvshow' if egWdYKRbqTIBkcFtiwEVOlQAuCUazH=='vod' else 'movie','vtitle':egWdYKRbqTIBkcFtiwEVOlQAuCUavy,'vsubtitle':'','contenttype':egWdYKRbqTIBkcFtiwEVOlQAuCUazx,}
    egWdYKRbqTIBkcFtiwEVOlQAuCUaHh=json.dumps(egWdYKRbqTIBkcFtiwEVOlQAuCUaHv)
    egWdYKRbqTIBkcFtiwEVOlQAuCUaHh=urllib.parse.quote(egWdYKRbqTIBkcFtiwEVOlQAuCUaHh)
    egWdYKRbqTIBkcFtiwEVOlQAuCUaHG='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(egWdYKRbqTIBkcFtiwEVOlQAuCUaHh)
    egWdYKRbqTIBkcFtiwEVOlQAuCUazo.append(('(통합) 찜 영상에 추가',egWdYKRbqTIBkcFtiwEVOlQAuCUaHG))
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.add_dir(egWdYKRbqTIBkcFtiwEVOlQAuCUavy,sublabel='',img=egWdYKRbqTIBkcFtiwEVOlQAuCUazf,infoLabels=egWdYKRbqTIBkcFtiwEVOlQAuCUazj,isFolder=egWdYKRbqTIBkcFtiwEVOlQAuCUavX,params=egWdYKRbqTIBkcFtiwEVOlQAuCUavj,ContextMenu=egWdYKRbqTIBkcFtiwEVOlQAuCUazo)
  if egWdYKRbqTIBkcFtiwEVOlQAuCUazh:
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj['mode'] ='SEARCH_LIST' 
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj['sType']=egWdYKRbqTIBkcFtiwEVOlQAuCUazH 
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj['page'] =egWdYKRbqTIBkcFtiwEVOlQAuCUaSo(egWdYKRbqTIBkcFtiwEVOlQAuCUazX+1)
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj['search_key']=egWdYKRbqTIBkcFtiwEVOlQAuCUavf
   egWdYKRbqTIBkcFtiwEVOlQAuCUavy='[B]%s >>[/B]'%'다음 페이지'
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHr=egWdYKRbqTIBkcFtiwEVOlQAuCUaSo(egWdYKRbqTIBkcFtiwEVOlQAuCUazX+1)
   egWdYKRbqTIBkcFtiwEVOlQAuCUavo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.add_dir(egWdYKRbqTIBkcFtiwEVOlQAuCUavy,sublabel=egWdYKRbqTIBkcFtiwEVOlQAuCUaHr,img=egWdYKRbqTIBkcFtiwEVOlQAuCUavo,infoLabels=egWdYKRbqTIBkcFtiwEVOlQAuCUaSG,isFolder=egWdYKRbqTIBkcFtiwEVOlQAuCUaSr,params=egWdYKRbqTIBkcFtiwEVOlQAuCUavj)
  if egWdYKRbqTIBkcFtiwEVOlQAuCUazH=='movie':xbmcplugin.setContent(egWdYKRbqTIBkcFtiwEVOlQAuCUamn._addon_handle,'movies')
  else:xbmcplugin.setContent(egWdYKRbqTIBkcFtiwEVOlQAuCUamn._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(egWdYKRbqTIBkcFtiwEVOlQAuCUamn._addon_handle,cacheToDisc=egWdYKRbqTIBkcFtiwEVOlQAuCUaSn)
 def dp_Watch_List(egWdYKRbqTIBkcFtiwEVOlQAuCUamn,args):
  egWdYKRbqTIBkcFtiwEVOlQAuCUazH =args.get('sType')
  egWdYKRbqTIBkcFtiwEVOlQAuCUavS=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.get_settings_direct_replay()
  egWdYKRbqTIBkcFtiwEVOlQAuCUazM=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.Load_List_File(egWdYKRbqTIBkcFtiwEVOlQAuCUazH)
  for egWdYKRbqTIBkcFtiwEVOlQAuCUazJ in egWdYKRbqTIBkcFtiwEVOlQAuCUazM:
   egWdYKRbqTIBkcFtiwEVOlQAuCUazN=egWdYKRbqTIBkcFtiwEVOlQAuCUaSy(urllib.parse.parse_qsl(egWdYKRbqTIBkcFtiwEVOlQAuCUazJ))
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHS =egWdYKRbqTIBkcFtiwEVOlQAuCUazN.get('code').strip()
   egWdYKRbqTIBkcFtiwEVOlQAuCUavy =egWdYKRbqTIBkcFtiwEVOlQAuCUazN.get('title').strip()
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHr =egWdYKRbqTIBkcFtiwEVOlQAuCUazN.get('subtitle').strip()
   if egWdYKRbqTIBkcFtiwEVOlQAuCUaHr=='None':egWdYKRbqTIBkcFtiwEVOlQAuCUaHr=''
   egWdYKRbqTIBkcFtiwEVOlQAuCUazf=egWdYKRbqTIBkcFtiwEVOlQAuCUazN.get('img').strip()
   egWdYKRbqTIBkcFtiwEVOlQAuCUazD =egWdYKRbqTIBkcFtiwEVOlQAuCUazN.get('videoid').strip()
   try:
    egWdYKRbqTIBkcFtiwEVOlQAuCUazf=egWdYKRbqTIBkcFtiwEVOlQAuCUazf.replace('\'','\"')
    egWdYKRbqTIBkcFtiwEVOlQAuCUazf=json.loads(egWdYKRbqTIBkcFtiwEVOlQAuCUazf)
   except:
    egWdYKRbqTIBkcFtiwEVOlQAuCUaSG
   egWdYKRbqTIBkcFtiwEVOlQAuCUazj={'plot':'%s\n%s'%(egWdYKRbqTIBkcFtiwEVOlQAuCUavy,egWdYKRbqTIBkcFtiwEVOlQAuCUaHr)}
   if egWdYKRbqTIBkcFtiwEVOlQAuCUazH=='vod':
    if egWdYKRbqTIBkcFtiwEVOlQAuCUavS==egWdYKRbqTIBkcFtiwEVOlQAuCUaSn or egWdYKRbqTIBkcFtiwEVOlQAuCUazD==egWdYKRbqTIBkcFtiwEVOlQAuCUaSG:
     egWdYKRbqTIBkcFtiwEVOlQAuCUazj['mediatype']='tvshow'
     egWdYKRbqTIBkcFtiwEVOlQAuCUavj={'mode':'SEASON_LIST','videoid':egWdYKRbqTIBkcFtiwEVOlQAuCUazD,'vidtype':'contentid',}
     egWdYKRbqTIBkcFtiwEVOlQAuCUavX=egWdYKRbqTIBkcFtiwEVOlQAuCUaSr
    else:
     egWdYKRbqTIBkcFtiwEVOlQAuCUazj['mediatype']='episode'
     egWdYKRbqTIBkcFtiwEVOlQAuCUavj={'mode':'VOD','programid':egWdYKRbqTIBkcFtiwEVOlQAuCUaHS,'contentid':egWdYKRbqTIBkcFtiwEVOlQAuCUazD,'title':egWdYKRbqTIBkcFtiwEVOlQAuCUavy,'subtitle':egWdYKRbqTIBkcFtiwEVOlQAuCUaHr,'thumbnail':egWdYKRbqTIBkcFtiwEVOlQAuCUazf}
     egWdYKRbqTIBkcFtiwEVOlQAuCUavX=egWdYKRbqTIBkcFtiwEVOlQAuCUaSn
   else:
    egWdYKRbqTIBkcFtiwEVOlQAuCUazj['mediatype']='movie'
    egWdYKRbqTIBkcFtiwEVOlQAuCUavj={'mode':'MOVIE','contentid':egWdYKRbqTIBkcFtiwEVOlQAuCUaHS,'title':egWdYKRbqTIBkcFtiwEVOlQAuCUavy,'subtitle':egWdYKRbqTIBkcFtiwEVOlQAuCUaHr,'thumbnail':egWdYKRbqTIBkcFtiwEVOlQAuCUazf}
    egWdYKRbqTIBkcFtiwEVOlQAuCUavX=egWdYKRbqTIBkcFtiwEVOlQAuCUaSn
   egWdYKRbqTIBkcFtiwEVOlQAuCUazp={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':egWdYKRbqTIBkcFtiwEVOlQAuCUaHS,'vType':egWdYKRbqTIBkcFtiwEVOlQAuCUazH,}
   egWdYKRbqTIBkcFtiwEVOlQAuCUazP=urllib.parse.urlencode(egWdYKRbqTIBkcFtiwEVOlQAuCUazp)
   egWdYKRbqTIBkcFtiwEVOlQAuCUazo=[('선택된 시청이력 ( %s ) 삭제'%(egWdYKRbqTIBkcFtiwEVOlQAuCUavy),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(egWdYKRbqTIBkcFtiwEVOlQAuCUazP))]
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.add_dir(egWdYKRbqTIBkcFtiwEVOlQAuCUavy,sublabel=egWdYKRbqTIBkcFtiwEVOlQAuCUaHr,img=egWdYKRbqTIBkcFtiwEVOlQAuCUazf,infoLabels=egWdYKRbqTIBkcFtiwEVOlQAuCUazj,isFolder=egWdYKRbqTIBkcFtiwEVOlQAuCUavX,params=egWdYKRbqTIBkcFtiwEVOlQAuCUavj,ContextMenu=egWdYKRbqTIBkcFtiwEVOlQAuCUazo)
  egWdYKRbqTIBkcFtiwEVOlQAuCUazj={'plot':'시청목록을 삭제합니다.'}
  egWdYKRbqTIBkcFtiwEVOlQAuCUavy='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  egWdYKRbqTIBkcFtiwEVOlQAuCUavj={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':egWdYKRbqTIBkcFtiwEVOlQAuCUazH,}
  egWdYKRbqTIBkcFtiwEVOlQAuCUavo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  egWdYKRbqTIBkcFtiwEVOlQAuCUamn.add_dir(egWdYKRbqTIBkcFtiwEVOlQAuCUavy,sublabel='',img=egWdYKRbqTIBkcFtiwEVOlQAuCUavo,infoLabels=egWdYKRbqTIBkcFtiwEVOlQAuCUazj,isFolder=egWdYKRbqTIBkcFtiwEVOlQAuCUaSn,params=egWdYKRbqTIBkcFtiwEVOlQAuCUavj,isLink=egWdYKRbqTIBkcFtiwEVOlQAuCUaSr)
  if egWdYKRbqTIBkcFtiwEVOlQAuCUazH=='movie':xbmcplugin.setContent(egWdYKRbqTIBkcFtiwEVOlQAuCUamn._addon_handle,'movies')
  else:xbmcplugin.setContent(egWdYKRbqTIBkcFtiwEVOlQAuCUamn._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(egWdYKRbqTIBkcFtiwEVOlQAuCUamn._addon_handle,cacheToDisc=egWdYKRbqTIBkcFtiwEVOlQAuCUaSn)
 def Load_List_File(egWdYKRbqTIBkcFtiwEVOlQAuCUamn,stype): 
  try:
   if stype=='search':
    egWdYKRbqTIBkcFtiwEVOlQAuCUaHn=egWdYKRbqTIBkcFtiwEVOlQAuCUamS
   elif stype in['vod','movie']:
    egWdYKRbqTIBkcFtiwEVOlQAuCUaHn=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   else:
    return[]
   fp=egWdYKRbqTIBkcFtiwEVOlQAuCUaSj(egWdYKRbqTIBkcFtiwEVOlQAuCUaHn,'r',-1,'utf-8')
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHL=fp.readlines()
   fp.close()
  except:
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHL=[]
  return egWdYKRbqTIBkcFtiwEVOlQAuCUaHL
 def Save_Watched_List(egWdYKRbqTIBkcFtiwEVOlQAuCUamn,egWdYKRbqTIBkcFtiwEVOlQAuCUars,egWdYKRbqTIBkcFtiwEVOlQAuCUamN):
  try:
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHy=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%egWdYKRbqTIBkcFtiwEVOlQAuCUars))
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHN=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.Load_List_File(egWdYKRbqTIBkcFtiwEVOlQAuCUars) 
   fp=egWdYKRbqTIBkcFtiwEVOlQAuCUaSj(egWdYKRbqTIBkcFtiwEVOlQAuCUaHy,'w',-1,'utf-8')
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHs=urllib.parse.urlencode(egWdYKRbqTIBkcFtiwEVOlQAuCUamN)
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHs=egWdYKRbqTIBkcFtiwEVOlQAuCUaHs+'\n'
   fp.write(egWdYKRbqTIBkcFtiwEVOlQAuCUaHs)
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHp=0
   for egWdYKRbqTIBkcFtiwEVOlQAuCUaHP in egWdYKRbqTIBkcFtiwEVOlQAuCUaHN:
    egWdYKRbqTIBkcFtiwEVOlQAuCUaHo=egWdYKRbqTIBkcFtiwEVOlQAuCUaSy(urllib.parse.parse_qsl(egWdYKRbqTIBkcFtiwEVOlQAuCUaHP))
    egWdYKRbqTIBkcFtiwEVOlQAuCUaHj=egWdYKRbqTIBkcFtiwEVOlQAuCUamN.get('code').strip()
    egWdYKRbqTIBkcFtiwEVOlQAuCUaHX=egWdYKRbqTIBkcFtiwEVOlQAuCUaHo.get('code').strip()
    if egWdYKRbqTIBkcFtiwEVOlQAuCUars=='vod' and egWdYKRbqTIBkcFtiwEVOlQAuCUamn.get_settings_direct_replay()==egWdYKRbqTIBkcFtiwEVOlQAuCUaSr:
     egWdYKRbqTIBkcFtiwEVOlQAuCUaHj=egWdYKRbqTIBkcFtiwEVOlQAuCUamN.get('videoid').strip()
     egWdYKRbqTIBkcFtiwEVOlQAuCUaHX=egWdYKRbqTIBkcFtiwEVOlQAuCUaHo.get('videoid').strip()if egWdYKRbqTIBkcFtiwEVOlQAuCUaHX!=egWdYKRbqTIBkcFtiwEVOlQAuCUaSG else '-'
    if egWdYKRbqTIBkcFtiwEVOlQAuCUaHj!=egWdYKRbqTIBkcFtiwEVOlQAuCUaHX:
     fp.write(egWdYKRbqTIBkcFtiwEVOlQAuCUaHP)
     egWdYKRbqTIBkcFtiwEVOlQAuCUaHp+=1
     if egWdYKRbqTIBkcFtiwEVOlQAuCUaHp>=50:break
   fp.close()
  except:
   egWdYKRbqTIBkcFtiwEVOlQAuCUaSG
 def dp_History_Remove(egWdYKRbqTIBkcFtiwEVOlQAuCUamn,args):
  egWdYKRbqTIBkcFtiwEVOlQAuCUaHM=args.get('delType')
  egWdYKRbqTIBkcFtiwEVOlQAuCUaHJ =args.get('sKey')
  egWdYKRbqTIBkcFtiwEVOlQAuCUaHD =args.get('vType')
  egWdYKRbqTIBkcFtiwEVOlQAuCUamp=xbmcgui.Dialog()
  if egWdYKRbqTIBkcFtiwEVOlQAuCUaHM=='SEARCH_ALL':
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHx=egWdYKRbqTIBkcFtiwEVOlQAuCUamp.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif egWdYKRbqTIBkcFtiwEVOlQAuCUaHM=='SEARCH_ONE':
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHx=egWdYKRbqTIBkcFtiwEVOlQAuCUamp.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif egWdYKRbqTIBkcFtiwEVOlQAuCUaHM=='WATCH_ALL':
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHx=egWdYKRbqTIBkcFtiwEVOlQAuCUamp.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif egWdYKRbqTIBkcFtiwEVOlQAuCUaHM=='WATCH_ONE':
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHx=egWdYKRbqTIBkcFtiwEVOlQAuCUamp.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if egWdYKRbqTIBkcFtiwEVOlQAuCUaHx==egWdYKRbqTIBkcFtiwEVOlQAuCUaSn:sys.exit()
  if egWdYKRbqTIBkcFtiwEVOlQAuCUaHM=='SEARCH_ALL':
   if os.path.isfile(egWdYKRbqTIBkcFtiwEVOlQAuCUamS):os.remove(egWdYKRbqTIBkcFtiwEVOlQAuCUamS)
  elif egWdYKRbqTIBkcFtiwEVOlQAuCUaHM=='SEARCH_ONE':
   try:
    egWdYKRbqTIBkcFtiwEVOlQAuCUaHn=egWdYKRbqTIBkcFtiwEVOlQAuCUamS
    egWdYKRbqTIBkcFtiwEVOlQAuCUaHN=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.Load_List_File('search') 
    fp=egWdYKRbqTIBkcFtiwEVOlQAuCUaSj(egWdYKRbqTIBkcFtiwEVOlQAuCUaHn,'w',-1,'utf-8')
    for egWdYKRbqTIBkcFtiwEVOlQAuCUaHP in egWdYKRbqTIBkcFtiwEVOlQAuCUaHN:
     egWdYKRbqTIBkcFtiwEVOlQAuCUaHo=egWdYKRbqTIBkcFtiwEVOlQAuCUaSy(urllib.parse.parse_qsl(egWdYKRbqTIBkcFtiwEVOlQAuCUaHP))
     egWdYKRbqTIBkcFtiwEVOlQAuCUaHf=egWdYKRbqTIBkcFtiwEVOlQAuCUaHo.get('skey').strip()
     if egWdYKRbqTIBkcFtiwEVOlQAuCUaHJ!=egWdYKRbqTIBkcFtiwEVOlQAuCUaHf:
      fp.write(egWdYKRbqTIBkcFtiwEVOlQAuCUaHP)
    fp.close()
   except:
    egWdYKRbqTIBkcFtiwEVOlQAuCUaSG
  elif egWdYKRbqTIBkcFtiwEVOlQAuCUaHM=='WATCH_ALL':
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHn=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%egWdYKRbqTIBkcFtiwEVOlQAuCUaHD))
   if os.path.isfile(egWdYKRbqTIBkcFtiwEVOlQAuCUaHn):os.remove(egWdYKRbqTIBkcFtiwEVOlQAuCUaHn)
  elif egWdYKRbqTIBkcFtiwEVOlQAuCUaHM=='WATCH_ONE':
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHn=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%egWdYKRbqTIBkcFtiwEVOlQAuCUaHD))
   try:
    egWdYKRbqTIBkcFtiwEVOlQAuCUaHN=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.Load_List_File(egWdYKRbqTIBkcFtiwEVOlQAuCUaHD) 
    fp=egWdYKRbqTIBkcFtiwEVOlQAuCUaSj(egWdYKRbqTIBkcFtiwEVOlQAuCUaHn,'w',-1,'utf-8')
    for egWdYKRbqTIBkcFtiwEVOlQAuCUaHP in egWdYKRbqTIBkcFtiwEVOlQAuCUaHN:
     egWdYKRbqTIBkcFtiwEVOlQAuCUaHo=egWdYKRbqTIBkcFtiwEVOlQAuCUaSy(urllib.parse.parse_qsl(egWdYKRbqTIBkcFtiwEVOlQAuCUaHP))
     egWdYKRbqTIBkcFtiwEVOlQAuCUaHf=egWdYKRbqTIBkcFtiwEVOlQAuCUaHo.get('code').strip()
     if egWdYKRbqTIBkcFtiwEVOlQAuCUaHJ!=egWdYKRbqTIBkcFtiwEVOlQAuCUaHf:
      fp.write(egWdYKRbqTIBkcFtiwEVOlQAuCUaHP)
    fp.close()
   except:
    egWdYKRbqTIBkcFtiwEVOlQAuCUaSG
  xbmc.executebuiltin("Container.Refresh")
 def Save_Searched_List(egWdYKRbqTIBkcFtiwEVOlQAuCUamn,egWdYKRbqTIBkcFtiwEVOlQAuCUavf):
  try:
   egWdYKRbqTIBkcFtiwEVOlQAuCUaGm=egWdYKRbqTIBkcFtiwEVOlQAuCUamS
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHN=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.Load_List_File('search') 
   egWdYKRbqTIBkcFtiwEVOlQAuCUaGv={'skey':egWdYKRbqTIBkcFtiwEVOlQAuCUavf.strip()}
   fp=egWdYKRbqTIBkcFtiwEVOlQAuCUaSj(egWdYKRbqTIBkcFtiwEVOlQAuCUaGm,'w',-1,'utf-8')
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHs=urllib.parse.urlencode(egWdYKRbqTIBkcFtiwEVOlQAuCUaGv)
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHs=egWdYKRbqTIBkcFtiwEVOlQAuCUaHs+'\n'
   fp.write(egWdYKRbqTIBkcFtiwEVOlQAuCUaHs)
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHp=0
   for egWdYKRbqTIBkcFtiwEVOlQAuCUaHP in egWdYKRbqTIBkcFtiwEVOlQAuCUaHN:
    egWdYKRbqTIBkcFtiwEVOlQAuCUaHo=egWdYKRbqTIBkcFtiwEVOlQAuCUaSy(urllib.parse.parse_qsl(egWdYKRbqTIBkcFtiwEVOlQAuCUaHP))
    egWdYKRbqTIBkcFtiwEVOlQAuCUaHj=egWdYKRbqTIBkcFtiwEVOlQAuCUaGv.get('skey').strip()
    egWdYKRbqTIBkcFtiwEVOlQAuCUaHX=egWdYKRbqTIBkcFtiwEVOlQAuCUaHo.get('skey').strip()
    if egWdYKRbqTIBkcFtiwEVOlQAuCUaHj!=egWdYKRbqTIBkcFtiwEVOlQAuCUaHX:
     fp.write(egWdYKRbqTIBkcFtiwEVOlQAuCUaHP)
     egWdYKRbqTIBkcFtiwEVOlQAuCUaHp+=1
     if egWdYKRbqTIBkcFtiwEVOlQAuCUaHp>=50:break
   fp.close()
  except:
   egWdYKRbqTIBkcFtiwEVOlQAuCUaSG
 def dp_Global_Search(egWdYKRbqTIBkcFtiwEVOlQAuCUamn,args):
  egWdYKRbqTIBkcFtiwEVOlQAuCUazv=args.get('mode')
  if egWdYKRbqTIBkcFtiwEVOlQAuCUazv=='TOTAL_SEARCH':
   egWdYKRbqTIBkcFtiwEVOlQAuCUaGz='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   egWdYKRbqTIBkcFtiwEVOlQAuCUaGz='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(egWdYKRbqTIBkcFtiwEVOlQAuCUaGz)
 def dp_Bookmark_Menu(egWdYKRbqTIBkcFtiwEVOlQAuCUamn,args):
  egWdYKRbqTIBkcFtiwEVOlQAuCUaGz='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(egWdYKRbqTIBkcFtiwEVOlQAuCUaGz)
 def login_main(egWdYKRbqTIBkcFtiwEVOlQAuCUamn):
  (egWdYKRbqTIBkcFtiwEVOlQAuCUaGH,egWdYKRbqTIBkcFtiwEVOlQAuCUaGh,egWdYKRbqTIBkcFtiwEVOlQAuCUaGr)=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.get_settings_account()
  if not(egWdYKRbqTIBkcFtiwEVOlQAuCUaGH and egWdYKRbqTIBkcFtiwEVOlQAuCUaGh):
   egWdYKRbqTIBkcFtiwEVOlQAuCUamp=xbmcgui.Dialog()
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHx=egWdYKRbqTIBkcFtiwEVOlQAuCUamp.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if egWdYKRbqTIBkcFtiwEVOlQAuCUaHx==egWdYKRbqTIBkcFtiwEVOlQAuCUaSr:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if egWdYKRbqTIBkcFtiwEVOlQAuCUamn.cookiefile_check()==egWdYKRbqTIBkcFtiwEVOlQAuCUaSr:return
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   egWdYKRbqTIBkcFtiwEVOlQAuCUaGS=0
   while egWdYKRbqTIBkcFtiwEVOlQAuCUaSr:
    egWdYKRbqTIBkcFtiwEVOlQAuCUaGS+=1
    time.sleep(0.05)
    if egWdYKRbqTIBkcFtiwEVOlQAuCUaGS>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  egWdYKRbqTIBkcFtiwEVOlQAuCUaGn=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.GetCredential(egWdYKRbqTIBkcFtiwEVOlQAuCUaGH,egWdYKRbqTIBkcFtiwEVOlQAuCUaGh,egWdYKRbqTIBkcFtiwEVOlQAuCUaGr)
  if egWdYKRbqTIBkcFtiwEVOlQAuCUaGn:egWdYKRbqTIBkcFtiwEVOlQAuCUamn.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
  if egWdYKRbqTIBkcFtiwEVOlQAuCUaGn==egWdYKRbqTIBkcFtiwEVOlQAuCUaSn:
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_setEpOrderby(egWdYKRbqTIBkcFtiwEVOlQAuCUamn,args):
  egWdYKRbqTIBkcFtiwEVOlQAuCUavn =args.get('orderby')
  egWdYKRbqTIBkcFtiwEVOlQAuCUamn.set_winEpisodeOrderby(egWdYKRbqTIBkcFtiwEVOlQAuCUavn)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(egWdYKRbqTIBkcFtiwEVOlQAuCUamn,args):
  egWdYKRbqTIBkcFtiwEVOlQAuCUazv =args.get('mode')
  egWdYKRbqTIBkcFtiwEVOlQAuCUaGL =args.get('contentid')
  egWdYKRbqTIBkcFtiwEVOlQAuCUaGy =args.get('pvrmode')
  egWdYKRbqTIBkcFtiwEVOlQAuCUaGN=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.get_selQuality()
  egWdYKRbqTIBkcFtiwEVOlQAuCUavH =egWdYKRbqTIBkcFtiwEVOlQAuCUamn.get_settings_play()
  egWdYKRbqTIBkcFtiwEVOlQAuCUamn.addon_log(egWdYKRbqTIBkcFtiwEVOlQAuCUaGL+' - '+egWdYKRbqTIBkcFtiwEVOlQAuCUazv)
  if egWdYKRbqTIBkcFtiwEVOlQAuCUazv=='SPORTS':
   egWdYKRbqTIBkcFtiwEVOlQAuCUaGs=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.GetSportsURL(egWdYKRbqTIBkcFtiwEVOlQAuCUaGL,egWdYKRbqTIBkcFtiwEVOlQAuCUaGN)
  else:
   egWdYKRbqTIBkcFtiwEVOlQAuCUaGs=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.GetStreamingURL(egWdYKRbqTIBkcFtiwEVOlQAuCUazv,egWdYKRbqTIBkcFtiwEVOlQAuCUaGL,egWdYKRbqTIBkcFtiwEVOlQAuCUaGN,egWdYKRbqTIBkcFtiwEVOlQAuCUaGy,playOption=egWdYKRbqTIBkcFtiwEVOlQAuCUavH)
  egWdYKRbqTIBkcFtiwEVOlQAuCUaGp=egWdYKRbqTIBkcFtiwEVOlQAuCUaGs['stream_cookie']
  egWdYKRbqTIBkcFtiwEVOlQAuCUaGP='{}|Cookie={}'.format(egWdYKRbqTIBkcFtiwEVOlQAuCUaGs['stream_url'],egWdYKRbqTIBkcFtiwEVOlQAuCUaGp)
  egWdYKRbqTIBkcFtiwEVOlQAuCUamn.addon_log(egWdYKRbqTIBkcFtiwEVOlQAuCUaGP)
  if egWdYKRbqTIBkcFtiwEVOlQAuCUaGs['stream_url']=='':
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.addon_noti(__language__(30907).encode('utf8'))
   return
  egWdYKRbqTIBkcFtiwEVOlQAuCUaGo=xbmcgui.ListItem(path=egWdYKRbqTIBkcFtiwEVOlQAuCUaGP)
  if egWdYKRbqTIBkcFtiwEVOlQAuCUaGs['stream_drm']:
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.addon_log('!!streaming_drm!!')
   egWdYKRbqTIBkcFtiwEVOlQAuCUaGj=egWdYKRbqTIBkcFtiwEVOlQAuCUaGs['stream_drm']['customdata']
   egWdYKRbqTIBkcFtiwEVOlQAuCUaGX =egWdYKRbqTIBkcFtiwEVOlQAuCUaGs['stream_drm']['drmhost']
   egWdYKRbqTIBkcFtiwEVOlQAuCUaGM =inputstreamhelper.Helper('mpd',drm='widevine')
   if egWdYKRbqTIBkcFtiwEVOlQAuCUaGM.check_inputstream():
    if egWdYKRbqTIBkcFtiwEVOlQAuCUazv=='MOVIE':
     egWdYKRbqTIBkcFtiwEVOlQAuCUaGJ='https://www.wavve.com/player/movie?movieid=%s'%egWdYKRbqTIBkcFtiwEVOlQAuCUaGL
    else:
     egWdYKRbqTIBkcFtiwEVOlQAuCUaGJ='https://www.wavve.com/player/vod?programid=%s&page=1'%egWdYKRbqTIBkcFtiwEVOlQAuCUaGL
    egWdYKRbqTIBkcFtiwEVOlQAuCUaGD={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':egWdYKRbqTIBkcFtiwEVOlQAuCUaGj,'referer':egWdYKRbqTIBkcFtiwEVOlQAuCUaGJ,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.USER_AGENT,}
    egWdYKRbqTIBkcFtiwEVOlQAuCUaGx=egWdYKRbqTIBkcFtiwEVOlQAuCUaGX+'|'+urllib.parse.urlencode(egWdYKRbqTIBkcFtiwEVOlQAuCUaGD)+'|R{SSM}|'
    egWdYKRbqTIBkcFtiwEVOlQAuCUaGo.setProperty('inputstream',egWdYKRbqTIBkcFtiwEVOlQAuCUaGM.inputstream_addon)
    egWdYKRbqTIBkcFtiwEVOlQAuCUaGo.setProperty('inputstream.adaptive.manifest_type','mpd')
    egWdYKRbqTIBkcFtiwEVOlQAuCUaGo.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    egWdYKRbqTIBkcFtiwEVOlQAuCUaGo.setProperty('inputstream.adaptive.license_key',egWdYKRbqTIBkcFtiwEVOlQAuCUaGx)
    egWdYKRbqTIBkcFtiwEVOlQAuCUaGo.setProperty('inputstream.adaptive.stream_headers','user-agent={}&Cookie={}'.format(egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.USER_AGENT,egWdYKRbqTIBkcFtiwEVOlQAuCUaGp))
  elif egWdYKRbqTIBkcFtiwEVOlQAuCUazv in['VOD','MOVIE']:
   egWdYKRbqTIBkcFtiwEVOlQAuCUaGo.setContentLookup(egWdYKRbqTIBkcFtiwEVOlQAuCUaSn)
   egWdYKRbqTIBkcFtiwEVOlQAuCUaGo.setMimeType('application/x-mpegURL')
   egWdYKRbqTIBkcFtiwEVOlQAuCUaGo.setProperty('inputstream','inputstream.adaptive')
   if egWdYKRbqTIBkcFtiwEVOlQAuCUaGs['stream_action']=='hls':
    egWdYKRbqTIBkcFtiwEVOlQAuCUaGo.setProperty('inputstream.adaptive.manifest_type','hls')
   else:
    egWdYKRbqTIBkcFtiwEVOlQAuCUaGo.setProperty('inputstream.adaptive.manifest_type','mpd')
   egWdYKRbqTIBkcFtiwEVOlQAuCUaGo.setProperty('inputstream.adaptive.stream_headers','user-agent={}&Cookie={}'.format(egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.USER_AGENT,egWdYKRbqTIBkcFtiwEVOlQAuCUaGp))
  if egWdYKRbqTIBkcFtiwEVOlQAuCUaGs['stream_vtt']:
   egWdYKRbqTIBkcFtiwEVOlQAuCUaGo.setSubtitles([egWdYKRbqTIBkcFtiwEVOlQAuCUaGs['stream_vtt']])
  xbmcplugin.setResolvedUrl(egWdYKRbqTIBkcFtiwEVOlQAuCUamn._addon_handle,egWdYKRbqTIBkcFtiwEVOlQAuCUaSr,egWdYKRbqTIBkcFtiwEVOlQAuCUaGo)
  egWdYKRbqTIBkcFtiwEVOlQAuCUaGf=egWdYKRbqTIBkcFtiwEVOlQAuCUaSn
  if egWdYKRbqTIBkcFtiwEVOlQAuCUaGs['stream_preview']:
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.addon_noti(egWdYKRbqTIBkcFtiwEVOlQAuCUaGs['stream_preview'].encode('utf-8'))
   egWdYKRbqTIBkcFtiwEVOlQAuCUaGf=egWdYKRbqTIBkcFtiwEVOlQAuCUaSr
  else:
   if '/preview.' in urllib.parse.urlsplit(egWdYKRbqTIBkcFtiwEVOlQAuCUaGs['stream_url']).path:
    egWdYKRbqTIBkcFtiwEVOlQAuCUamn.addon_noti(__language__(30908).encode('utf8'))
    egWdYKRbqTIBkcFtiwEVOlQAuCUaGf=egWdYKRbqTIBkcFtiwEVOlQAuCUaSr
  try:
   egWdYKRbqTIBkcFtiwEVOlQAuCUahm=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and egWdYKRbqTIBkcFtiwEVOlQAuCUaGf==egWdYKRbqTIBkcFtiwEVOlQAuCUaSn and egWdYKRbqTIBkcFtiwEVOlQAuCUahm!='-':
    egWdYKRbqTIBkcFtiwEVOlQAuCUavj={'code':egWdYKRbqTIBkcFtiwEVOlQAuCUahm,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    egWdYKRbqTIBkcFtiwEVOlQAuCUamn.Save_Watched_List(args.get('mode').lower(),egWdYKRbqTIBkcFtiwEVOlQAuCUavj)
  except:
   egWdYKRbqTIBkcFtiwEVOlQAuCUaSG
 def logout(egWdYKRbqTIBkcFtiwEVOlQAuCUamn):
  egWdYKRbqTIBkcFtiwEVOlQAuCUamp=xbmcgui.Dialog()
  egWdYKRbqTIBkcFtiwEVOlQAuCUaHx=egWdYKRbqTIBkcFtiwEVOlQAuCUamp.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if egWdYKRbqTIBkcFtiwEVOlQAuCUaHx==egWdYKRbqTIBkcFtiwEVOlQAuCUaSn:sys.exit()
  egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.Init_WV_Total()
  if os.path.isfile(egWdYKRbqTIBkcFtiwEVOlQAuCUamr):os.remove(egWdYKRbqTIBkcFtiwEVOlQAuCUamr)
  egWdYKRbqTIBkcFtiwEVOlQAuCUamn.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(egWdYKRbqTIBkcFtiwEVOlQAuCUamn):
  egWdYKRbqTIBkcFtiwEVOlQAuCUahv =egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.Get_Now_Datetime()
  egWdYKRbqTIBkcFtiwEVOlQAuCUahz=egWdYKRbqTIBkcFtiwEVOlQAuCUahv+datetime.timedelta(days=egWdYKRbqTIBkcFtiwEVOlQAuCUaSh(__addon__.getSetting('cache_ttl')))
  (egWdYKRbqTIBkcFtiwEVOlQAuCUaGH,egWdYKRbqTIBkcFtiwEVOlQAuCUaGh,egWdYKRbqTIBkcFtiwEVOlQAuCUaGr)=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.get_settings_account()
  egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.Save_session_acount(egWdYKRbqTIBkcFtiwEVOlQAuCUaGH,egWdYKRbqTIBkcFtiwEVOlQAuCUaGh,egWdYKRbqTIBkcFtiwEVOlQAuCUaGr)
  egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.WV['account']['token_limit']=egWdYKRbqTIBkcFtiwEVOlQAuCUahz.strftime('%Y%m%d')
  egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.JsonFile_Save(egWdYKRbqTIBkcFtiwEVOlQAuCUamr,egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.WV)
 def cookiefile_check(egWdYKRbqTIBkcFtiwEVOlQAuCUamn):
  egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.WV=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.JsonFile_Load(egWdYKRbqTIBkcFtiwEVOlQAuCUamr)
  if 'account' not in egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.WV:
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.Init_WV_Total()
   return egWdYKRbqTIBkcFtiwEVOlQAuCUaSn
  if 'uuid' not in egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.WV.get('cookies'):
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.Init_WV_Total()
   return egWdYKRbqTIBkcFtiwEVOlQAuCUaSn
  (egWdYKRbqTIBkcFtiwEVOlQAuCUahH,egWdYKRbqTIBkcFtiwEVOlQAuCUahG,egWdYKRbqTIBkcFtiwEVOlQAuCUahr)=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.get_settings_account()
  (egWdYKRbqTIBkcFtiwEVOlQAuCUahS,egWdYKRbqTIBkcFtiwEVOlQAuCUahn,egWdYKRbqTIBkcFtiwEVOlQAuCUahL)=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.Load_session_acount()
  if egWdYKRbqTIBkcFtiwEVOlQAuCUahH!=egWdYKRbqTIBkcFtiwEVOlQAuCUahS or egWdYKRbqTIBkcFtiwEVOlQAuCUahG!=egWdYKRbqTIBkcFtiwEVOlQAuCUahn or egWdYKRbqTIBkcFtiwEVOlQAuCUahr!=egWdYKRbqTIBkcFtiwEVOlQAuCUahL:
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.Init_WV_Total()
   return egWdYKRbqTIBkcFtiwEVOlQAuCUaSn
  if egWdYKRbqTIBkcFtiwEVOlQAuCUaSh(egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))>egWdYKRbqTIBkcFtiwEVOlQAuCUaSh(egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.WV['account']['token_limit']):
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.Init_WV_Total()
   return egWdYKRbqTIBkcFtiwEVOlQAuCUaSn
  return egWdYKRbqTIBkcFtiwEVOlQAuCUaSr
 def dp_LiveCatagory_List(egWdYKRbqTIBkcFtiwEVOlQAuCUamn,args):
  egWdYKRbqTIBkcFtiwEVOlQAuCUahy =args.get('sCode')
  egWdYKRbqTIBkcFtiwEVOlQAuCUahN=args.get('sIndex')
  egWdYKRbqTIBkcFtiwEVOlQAuCUazM,egWdYKRbqTIBkcFtiwEVOlQAuCUahs=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.Get_LiveCatagory_List(egWdYKRbqTIBkcFtiwEVOlQAuCUahy,egWdYKRbqTIBkcFtiwEVOlQAuCUahN)
  for egWdYKRbqTIBkcFtiwEVOlQAuCUazJ in egWdYKRbqTIBkcFtiwEVOlQAuCUazM:
   egWdYKRbqTIBkcFtiwEVOlQAuCUavy =egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('title')
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj={'mode':'LIVE_LIST','genre':egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('genre'),'baseapi':egWdYKRbqTIBkcFtiwEVOlQAuCUahs}
   egWdYKRbqTIBkcFtiwEVOlQAuCUavJ={'title':egWdYKRbqTIBkcFtiwEVOlQAuCUavy,'plot':egWdYKRbqTIBkcFtiwEVOlQAuCUavy}
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.add_dir(egWdYKRbqTIBkcFtiwEVOlQAuCUavy,sublabel='',img='',infoLabels=egWdYKRbqTIBkcFtiwEVOlQAuCUavJ,isFolder=egWdYKRbqTIBkcFtiwEVOlQAuCUaSr,params=egWdYKRbqTIBkcFtiwEVOlQAuCUavj)
  if egWdYKRbqTIBkcFtiwEVOlQAuCUaSp(egWdYKRbqTIBkcFtiwEVOlQAuCUazM)>0:xbmcplugin.endOfDirectory(egWdYKRbqTIBkcFtiwEVOlQAuCUamn._addon_handle,cacheToDisc=egWdYKRbqTIBkcFtiwEVOlQAuCUaSn)
 def dp_MainCatagory_List(egWdYKRbqTIBkcFtiwEVOlQAuCUamn,args):
  egWdYKRbqTIBkcFtiwEVOlQAuCUahy =args.get('sCode')
  egWdYKRbqTIBkcFtiwEVOlQAuCUahN=args.get('sIndex')
  egWdYKRbqTIBkcFtiwEVOlQAuCUazH =args.get('sType')
  egWdYKRbqTIBkcFtiwEVOlQAuCUazM=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.Get_MainCatagory_List(egWdYKRbqTIBkcFtiwEVOlQAuCUahy,egWdYKRbqTIBkcFtiwEVOlQAuCUahN,egWdYKRbqTIBkcFtiwEVOlQAuCUazH)
  for egWdYKRbqTIBkcFtiwEVOlQAuCUazJ in egWdYKRbqTIBkcFtiwEVOlQAuCUazM:
   if egWdYKRbqTIBkcFtiwEVOlQAuCUazH in['vod','vod09']:
    if egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('subtype')=='catagory':
     egWdYKRbqTIBkcFtiwEVOlQAuCUazv='PROGRAM_LIST'
    else:
     egWdYKRbqTIBkcFtiwEVOlQAuCUazv='SUPERSECTION_LIST'
   elif egWdYKRbqTIBkcFtiwEVOlQAuCUazH=='movie':
    egWdYKRbqTIBkcFtiwEVOlQAuCUazv='MOVIE_LIST'
   else:
    egWdYKRbqTIBkcFtiwEVOlQAuCUazv=''
   egWdYKRbqTIBkcFtiwEVOlQAuCUavy='%s (%s)'%(egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('title'),args.get('ordernm'))
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj={'mode':egWdYKRbqTIBkcFtiwEVOlQAuCUazv,'suburl':egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('suburl'),'subapi':egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if egWdYKRbqTIBkcFtiwEVOlQAuCUamn.get_settings_exclusion21():
    if egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('title')=='성인' or egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('title')=='성인+' or egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('title')=='에로티시즘' or egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('title')=='19':continue
   egWdYKRbqTIBkcFtiwEVOlQAuCUavJ={'title':egWdYKRbqTIBkcFtiwEVOlQAuCUavy,'plot':egWdYKRbqTIBkcFtiwEVOlQAuCUavy}
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.add_dir(egWdYKRbqTIBkcFtiwEVOlQAuCUavy,sublabel='',img='',infoLabels=egWdYKRbqTIBkcFtiwEVOlQAuCUavJ,isFolder=egWdYKRbqTIBkcFtiwEVOlQAuCUaSr,params=egWdYKRbqTIBkcFtiwEVOlQAuCUavj)
  if egWdYKRbqTIBkcFtiwEVOlQAuCUaSp(egWdYKRbqTIBkcFtiwEVOlQAuCUazM)>0:xbmcplugin.endOfDirectory(egWdYKRbqTIBkcFtiwEVOlQAuCUamn._addon_handle,cacheToDisc=egWdYKRbqTIBkcFtiwEVOlQAuCUaSn)
 def dp_Program_List(egWdYKRbqTIBkcFtiwEVOlQAuCUamn,args):
  egWdYKRbqTIBkcFtiwEVOlQAuCUahp =args.get('subapi')
  egWdYKRbqTIBkcFtiwEVOlQAuCUazX=egWdYKRbqTIBkcFtiwEVOlQAuCUaSh(args.get('page'))
  egWdYKRbqTIBkcFtiwEVOlQAuCUavn =args.get('orderby')
  egWdYKRbqTIBkcFtiwEVOlQAuCUamn.addon_log('dp_Program_List')
  egWdYKRbqTIBkcFtiwEVOlQAuCUamn.addon_log(egWdYKRbqTIBkcFtiwEVOlQAuCUahp)
  egWdYKRbqTIBkcFtiwEVOlQAuCUazM,egWdYKRbqTIBkcFtiwEVOlQAuCUazh=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.Get_Program_List(egWdYKRbqTIBkcFtiwEVOlQAuCUahp,egWdYKRbqTIBkcFtiwEVOlQAuCUazX,egWdYKRbqTIBkcFtiwEVOlQAuCUavn)
  for egWdYKRbqTIBkcFtiwEVOlQAuCUazJ in egWdYKRbqTIBkcFtiwEVOlQAuCUazM:
   egWdYKRbqTIBkcFtiwEVOlQAuCUazD =egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('videoid')
   egWdYKRbqTIBkcFtiwEVOlQAuCUazx =egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('vidtype')
   egWdYKRbqTIBkcFtiwEVOlQAuCUavy =egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('title')
   egWdYKRbqTIBkcFtiwEVOlQAuCUazf=egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('thumbnail')
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHm =egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('age')
   if egWdYKRbqTIBkcFtiwEVOlQAuCUaHm=='18' or egWdYKRbqTIBkcFtiwEVOlQAuCUaHm=='19' or egWdYKRbqTIBkcFtiwEVOlQAuCUaHm=='21':egWdYKRbqTIBkcFtiwEVOlQAuCUavy+=' (%s)'%(egWdYKRbqTIBkcFtiwEVOlQAuCUaHm)
   egWdYKRbqTIBkcFtiwEVOlQAuCUavJ={'plot':egWdYKRbqTIBkcFtiwEVOlQAuCUavy,'mpaa':egWdYKRbqTIBkcFtiwEVOlQAuCUaHm,'mediatype':'tvshow','title':egWdYKRbqTIBkcFtiwEVOlQAuCUavy,}
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj={'mode':'SEASON_LIST','videoid':egWdYKRbqTIBkcFtiwEVOlQAuCUazD,'vidtype':egWdYKRbqTIBkcFtiwEVOlQAuCUazx,}
   egWdYKRbqTIBkcFtiwEVOlQAuCUazo=[]
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHv={'mode':'VIEW_DETAIL','values':{'videoid':egWdYKRbqTIBkcFtiwEVOlQAuCUazD,'vidtype':'tvshow','contenttype':egWdYKRbqTIBkcFtiwEVOlQAuCUazx,}}
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHz=json.dumps(egWdYKRbqTIBkcFtiwEVOlQAuCUaHv,separators=(',',':'))
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHz=base64.standard_b64encode(egWdYKRbqTIBkcFtiwEVOlQAuCUaHz.encode()).decode('utf-8')
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHz=egWdYKRbqTIBkcFtiwEVOlQAuCUaHz.replace('+','%2B')
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHG='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(egWdYKRbqTIBkcFtiwEVOlQAuCUaHz)
   egWdYKRbqTIBkcFtiwEVOlQAuCUazo.append(('상세정보 조회',egWdYKRbqTIBkcFtiwEVOlQAuCUaHG))
   if egWdYKRbqTIBkcFtiwEVOlQAuCUamn.get_settings_makebookmark():
    egWdYKRbqTIBkcFtiwEVOlQAuCUaHv={'videoid':egWdYKRbqTIBkcFtiwEVOlQAuCUazD,'vidtype':'tvshow','vtitle':egWdYKRbqTIBkcFtiwEVOlQAuCUavy,'vsubtitle':'','contenttype':egWdYKRbqTIBkcFtiwEVOlQAuCUazx,}
    egWdYKRbqTIBkcFtiwEVOlQAuCUaHh=json.dumps(egWdYKRbqTIBkcFtiwEVOlQAuCUaHv)
    egWdYKRbqTIBkcFtiwEVOlQAuCUaHh=urllib.parse.quote(egWdYKRbqTIBkcFtiwEVOlQAuCUaHh)
    egWdYKRbqTIBkcFtiwEVOlQAuCUaHG='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(egWdYKRbqTIBkcFtiwEVOlQAuCUaHh)
    egWdYKRbqTIBkcFtiwEVOlQAuCUazo.append(('(통합) 찜 영상에 추가',egWdYKRbqTIBkcFtiwEVOlQAuCUaHG))
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.add_dir(egWdYKRbqTIBkcFtiwEVOlQAuCUavy,sublabel='',img=egWdYKRbqTIBkcFtiwEVOlQAuCUazf,infoLabels=egWdYKRbqTIBkcFtiwEVOlQAuCUavJ,isFolder=egWdYKRbqTIBkcFtiwEVOlQAuCUaSr,params=egWdYKRbqTIBkcFtiwEVOlQAuCUavj,ContextMenu=egWdYKRbqTIBkcFtiwEVOlQAuCUazo)
  if egWdYKRbqTIBkcFtiwEVOlQAuCUazh:
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj={}
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj['mode'] ='PROGRAM_LIST' 
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj['subapi']=egWdYKRbqTIBkcFtiwEVOlQAuCUahp 
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj['page'] =egWdYKRbqTIBkcFtiwEVOlQAuCUaSo(egWdYKRbqTIBkcFtiwEVOlQAuCUazX+1)
   egWdYKRbqTIBkcFtiwEVOlQAuCUavy='[B]%s >>[/B]'%'다음 페이지'
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHr=egWdYKRbqTIBkcFtiwEVOlQAuCUaSo(egWdYKRbqTIBkcFtiwEVOlQAuCUazX+1)
   egWdYKRbqTIBkcFtiwEVOlQAuCUavo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.add_dir(egWdYKRbqTIBkcFtiwEVOlQAuCUavy,sublabel=egWdYKRbqTIBkcFtiwEVOlQAuCUaHr,img=egWdYKRbqTIBkcFtiwEVOlQAuCUavo,infoLabels=egWdYKRbqTIBkcFtiwEVOlQAuCUaSG,isFolder=egWdYKRbqTIBkcFtiwEVOlQAuCUaSr,params=egWdYKRbqTIBkcFtiwEVOlQAuCUavj)
  xbmcplugin.setContent(egWdYKRbqTIBkcFtiwEVOlQAuCUamn._addon_handle,'tvshows')
  if egWdYKRbqTIBkcFtiwEVOlQAuCUaSp(egWdYKRbqTIBkcFtiwEVOlQAuCUazM)>0:xbmcplugin.endOfDirectory(egWdYKRbqTIBkcFtiwEVOlQAuCUamn._addon_handle,cacheToDisc=egWdYKRbqTIBkcFtiwEVOlQAuCUaSn)
 def dp_Season_List(egWdYKRbqTIBkcFtiwEVOlQAuCUamn,args):
  egWdYKRbqTIBkcFtiwEVOlQAuCUazD=args.get('videoid')
  egWdYKRbqTIBkcFtiwEVOlQAuCUazx=args.get('vidtype')
  if egWdYKRbqTIBkcFtiwEVOlQAuCUazx=='contentid':
   egWdYKRbqTIBkcFtiwEVOlQAuCUaGL=egWdYKRbqTIBkcFtiwEVOlQAuCUazD
   egWdYKRbqTIBkcFtiwEVOlQAuCUahP =egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.ContentidToSeasonid(egWdYKRbqTIBkcFtiwEVOlQAuCUazD)
  else:
   egWdYKRbqTIBkcFtiwEVOlQAuCUaGL=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.ProgramidToContentid(egWdYKRbqTIBkcFtiwEVOlQAuCUazD)
   egWdYKRbqTIBkcFtiwEVOlQAuCUahP =egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.ContentidToSeasonid(egWdYKRbqTIBkcFtiwEVOlQAuCUaGL)
  egWdYKRbqTIBkcFtiwEVOlQAuCUaho=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.Get_Season_List(egWdYKRbqTIBkcFtiwEVOlQAuCUahP)
  if egWdYKRbqTIBkcFtiwEVOlQAuCUaSp(egWdYKRbqTIBkcFtiwEVOlQAuCUaho)>1:
   for egWdYKRbqTIBkcFtiwEVOlQAuCUahj in egWdYKRbqTIBkcFtiwEVOlQAuCUaho:
    egWdYKRbqTIBkcFtiwEVOlQAuCUahX=egWdYKRbqTIBkcFtiwEVOlQAuCUahj.get('season_Id')
    egWdYKRbqTIBkcFtiwEVOlQAuCUahM=egWdYKRbqTIBkcFtiwEVOlQAuCUahj.get('season_Nm')
    egWdYKRbqTIBkcFtiwEVOlQAuCUahJ=egWdYKRbqTIBkcFtiwEVOlQAuCUahj.get('programNm')
    egWdYKRbqTIBkcFtiwEVOlQAuCUazf=egWdYKRbqTIBkcFtiwEVOlQAuCUahj.get('thumbnail')
    egWdYKRbqTIBkcFtiwEVOlQAuCUahD =egWdYKRbqTIBkcFtiwEVOlQAuCUahj.get('synopsis')
    egWdYKRbqTIBkcFtiwEVOlQAuCUazj={'mediatype':'tvshow','title':egWdYKRbqTIBkcFtiwEVOlQAuCUahM,'plot':egWdYKRbqTIBkcFtiwEVOlQAuCUahD,}
    egWdYKRbqTIBkcFtiwEVOlQAuCUavj={'mode':'EPISODE_LIST','seasonid':egWdYKRbqTIBkcFtiwEVOlQAuCUahX,'page':'1',}
    egWdYKRbqTIBkcFtiwEVOlQAuCUamn.add_dir(egWdYKRbqTIBkcFtiwEVOlQAuCUahM,sublabel=egWdYKRbqTIBkcFtiwEVOlQAuCUahJ,img=egWdYKRbqTIBkcFtiwEVOlQAuCUazf,infoLabels=egWdYKRbqTIBkcFtiwEVOlQAuCUazj,isFolder=egWdYKRbqTIBkcFtiwEVOlQAuCUaSr,params=egWdYKRbqTIBkcFtiwEVOlQAuCUavj,ContextMenu=egWdYKRbqTIBkcFtiwEVOlQAuCUaSG)
   xbmcplugin.setContent(egWdYKRbqTIBkcFtiwEVOlQAuCUamn._addon_handle,'seasons')
   xbmcplugin.endOfDirectory(egWdYKRbqTIBkcFtiwEVOlQAuCUamn._addon_handle,cacheToDisc=egWdYKRbqTIBkcFtiwEVOlQAuCUaSn)
  else:
   egWdYKRbqTIBkcFtiwEVOlQAuCUahx={'seasonid':egWdYKRbqTIBkcFtiwEVOlQAuCUahP,'page':'1',}
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.dp_Episode_List(egWdYKRbqTIBkcFtiwEVOlQAuCUahx)
 def dp_Episode_List(egWdYKRbqTIBkcFtiwEVOlQAuCUamn,args):
  egWdYKRbqTIBkcFtiwEVOlQAuCUahP =args.get('seasonid')
  egWdYKRbqTIBkcFtiwEVOlQAuCUazX =egWdYKRbqTIBkcFtiwEVOlQAuCUaSh(args.get('page'))
  egWdYKRbqTIBkcFtiwEVOlQAuCUazM,egWdYKRbqTIBkcFtiwEVOlQAuCUazh=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.Get_Episode_List(egWdYKRbqTIBkcFtiwEVOlQAuCUahP,egWdYKRbqTIBkcFtiwEVOlQAuCUazX,orderby=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.get_winEpisodeOrderby())
  for egWdYKRbqTIBkcFtiwEVOlQAuCUazJ in egWdYKRbqTIBkcFtiwEVOlQAuCUazM:
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHr=egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('episodenumber')
   egWdYKRbqTIBkcFtiwEVOlQAuCUahf ='[%s]\n\n%s'%(egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('episodetitle'),egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('synopsis'))
   egWdYKRbqTIBkcFtiwEVOlQAuCUazj={'mediatype':'episode','title':egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('programtitle'),'plot':egWdYKRbqTIBkcFtiwEVOlQAuCUahf,'cast':egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('episodeactors'),}
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj={'mode':'VOD','programid':egWdYKRbqTIBkcFtiwEVOlQAuCUahP,'contentid':egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('contentid'),'thumbnail':egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('thumbnail'),'title':egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('programtitle'),'subtitle':egWdYKRbqTIBkcFtiwEVOlQAuCUaHr,}
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.add_dir(egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('programtitle'),sublabel=egWdYKRbqTIBkcFtiwEVOlQAuCUaHr,img=egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('thumbnail'),infoLabels=egWdYKRbqTIBkcFtiwEVOlQAuCUazj,isFolder=egWdYKRbqTIBkcFtiwEVOlQAuCUaSn,params=egWdYKRbqTIBkcFtiwEVOlQAuCUavj)
  if egWdYKRbqTIBkcFtiwEVOlQAuCUazX==1:
   egWdYKRbqTIBkcFtiwEVOlQAuCUazj={'plot':'정렬순서를 변경합니다.'}
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj={}
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj['mode'] ='ORDER_BY' 
   if egWdYKRbqTIBkcFtiwEVOlQAuCUamn.get_winEpisodeOrderby()=='desc':
    egWdYKRbqTIBkcFtiwEVOlQAuCUavy='정렬순서변경 : 최신화부터 -> 1회부터'
    egWdYKRbqTIBkcFtiwEVOlQAuCUavj['orderby']='asc'
   else:
    egWdYKRbqTIBkcFtiwEVOlQAuCUavy='정렬순서변경 : 1회부터 -> 최신화부터'
    egWdYKRbqTIBkcFtiwEVOlQAuCUavj['orderby']='desc'
   egWdYKRbqTIBkcFtiwEVOlQAuCUavo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.add_dir(egWdYKRbqTIBkcFtiwEVOlQAuCUavy,sublabel='',img=egWdYKRbqTIBkcFtiwEVOlQAuCUavo,infoLabels=egWdYKRbqTIBkcFtiwEVOlQAuCUazj,isFolder=egWdYKRbqTIBkcFtiwEVOlQAuCUaSn,params=egWdYKRbqTIBkcFtiwEVOlQAuCUavj,isLink=egWdYKRbqTIBkcFtiwEVOlQAuCUaSr)
  if egWdYKRbqTIBkcFtiwEVOlQAuCUazh:
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj={}
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj['mode'] ='EPISODE_LIST' 
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj['seasonid']=egWdYKRbqTIBkcFtiwEVOlQAuCUahP
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj['page'] =egWdYKRbqTIBkcFtiwEVOlQAuCUaSo(egWdYKRbqTIBkcFtiwEVOlQAuCUazX+1)
   egWdYKRbqTIBkcFtiwEVOlQAuCUavy='[B]%s >>[/B]'%'다음 페이지'
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHr=egWdYKRbqTIBkcFtiwEVOlQAuCUaSo(egWdYKRbqTIBkcFtiwEVOlQAuCUazX+1)
   egWdYKRbqTIBkcFtiwEVOlQAuCUavo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.add_dir(egWdYKRbqTIBkcFtiwEVOlQAuCUavy,sublabel=egWdYKRbqTIBkcFtiwEVOlQAuCUaHr,img=egWdYKRbqTIBkcFtiwEVOlQAuCUavo,infoLabels=egWdYKRbqTIBkcFtiwEVOlQAuCUaSG,isFolder=egWdYKRbqTIBkcFtiwEVOlQAuCUaSr,params=egWdYKRbqTIBkcFtiwEVOlQAuCUavj)
  xbmcplugin.setContent(egWdYKRbqTIBkcFtiwEVOlQAuCUamn._addon_handle,'episodes')
  if egWdYKRbqTIBkcFtiwEVOlQAuCUaSp(egWdYKRbqTIBkcFtiwEVOlQAuCUazM)>0:xbmcplugin.endOfDirectory(egWdYKRbqTIBkcFtiwEVOlQAuCUamn._addon_handle,cacheToDisc=egWdYKRbqTIBkcFtiwEVOlQAuCUaSn)
 def dp_SuperSection_List(egWdYKRbqTIBkcFtiwEVOlQAuCUamn,args):
  egWdYKRbqTIBkcFtiwEVOlQAuCUarm =args.get('suburl')
  egWdYKRbqTIBkcFtiwEVOlQAuCUahp =args.get('subapi')
  egWdYKRbqTIBkcFtiwEVOlQAuCUamn.addon_log('dp_SuperSection_List')
  egWdYKRbqTIBkcFtiwEVOlQAuCUamn.addon_log('suburl : '+egWdYKRbqTIBkcFtiwEVOlQAuCUarm)
  egWdYKRbqTIBkcFtiwEVOlQAuCUamn.addon_log('subapi : '+egWdYKRbqTIBkcFtiwEVOlQAuCUahp)
  egWdYKRbqTIBkcFtiwEVOlQAuCUazM=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.Get_SuperMultiSection_List(egWdYKRbqTIBkcFtiwEVOlQAuCUarm)
  for egWdYKRbqTIBkcFtiwEVOlQAuCUazJ in egWdYKRbqTIBkcFtiwEVOlQAuCUazM:
   egWdYKRbqTIBkcFtiwEVOlQAuCUavy =egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('title')
   egWdYKRbqTIBkcFtiwEVOlQAuCUahp =egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('subapi')
   egWdYKRbqTIBkcFtiwEVOlQAuCUarv=egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('cell_type')
   if egWdYKRbqTIBkcFtiwEVOlQAuCUahp.find('contenttype=movie')>=0 or egWdYKRbqTIBkcFtiwEVOlQAuCUahp.find('mtype=svod')>=0:
    egWdYKRbqTIBkcFtiwEVOlQAuCUazv='MOVIE_LIST'
   elif re.search('themes/2\d{4}',egWdYKRbqTIBkcFtiwEVOlQAuCUahp)or re.search('themes-band/9\d{4}',egWdYKRbqTIBkcFtiwEVOlQAuCUahp):
    egWdYKRbqTIBkcFtiwEVOlQAuCUazv='MOVIE_LIST'
   else:
    egWdYKRbqTIBkcFtiwEVOlQAuCUazv='PROGRAM_LIST'
   '''
   if subapi.find('mtype=svod') >= 0 or subapi.find('mtype=ppv') >= 0 or subapi.find('contenttype=movie') >= 0: #영화 #20201107
    mode = 'MOVIE_LIST'
   elif subapi.find('contenttype=program') >= 0:
    mode = 'PROGRAM_LIST'
   elif cell_type == 'band_71': # band_71 #20201107
    mode   = 'SUPERSECTION_LIST'
    (temp_url, temp_api) = self.WavveObj.Baseapi_Parse(subapi)
    suburl = temp_api.get('api')
    subapi = ''
   elif cell_type == 'band_2': # band_2
    mode = 'BAND2SECTION_LIST'
   elif cell_type == 'band_live':
    mode = 'BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}', subapi) :
    mode = 'MOVIE_LIST'
   else: # band_10
    mode = 'PROGRAM_LIST'
   '''   
   egWdYKRbqTIBkcFtiwEVOlQAuCUazj={'plot':egWdYKRbqTIBkcFtiwEVOlQAuCUavy,'mediatype':'tvshow',}
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj={'mode':egWdYKRbqTIBkcFtiwEVOlQAuCUazv,'suburl':egWdYKRbqTIBkcFtiwEVOlQAuCUarm,'subapi':egWdYKRbqTIBkcFtiwEVOlQAuCUahp,'page':'1',}
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.add_dir(egWdYKRbqTIBkcFtiwEVOlQAuCUavy,sublabel='',img=egWdYKRbqTIBkcFtiwEVOlQAuCUaSG,infoLabels=egWdYKRbqTIBkcFtiwEVOlQAuCUazj,isFolder=egWdYKRbqTIBkcFtiwEVOlQAuCUaSr,params=egWdYKRbqTIBkcFtiwEVOlQAuCUavj)
  if egWdYKRbqTIBkcFtiwEVOlQAuCUaSp(egWdYKRbqTIBkcFtiwEVOlQAuCUazM)>0:xbmcplugin.endOfDirectory(egWdYKRbqTIBkcFtiwEVOlQAuCUamn._addon_handle,cacheToDisc=egWdYKRbqTIBkcFtiwEVOlQAuCUaSn)
 def dp_BandLiveSection_List(egWdYKRbqTIBkcFtiwEVOlQAuCUamn,args):
  egWdYKRbqTIBkcFtiwEVOlQAuCUahp =args.get('subapi')
  egWdYKRbqTIBkcFtiwEVOlQAuCUazX=egWdYKRbqTIBkcFtiwEVOlQAuCUaSh(args.get('page'))
  egWdYKRbqTIBkcFtiwEVOlQAuCUazM,egWdYKRbqTIBkcFtiwEVOlQAuCUazh=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.Get_BandLiveSection_List(egWdYKRbqTIBkcFtiwEVOlQAuCUahp,egWdYKRbqTIBkcFtiwEVOlQAuCUazX)
  for egWdYKRbqTIBkcFtiwEVOlQAuCUazJ in egWdYKRbqTIBkcFtiwEVOlQAuCUazM:
   egWdYKRbqTIBkcFtiwEVOlQAuCUarz =egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('channelid')
   egWdYKRbqTIBkcFtiwEVOlQAuCUarH =egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('studio')
   egWdYKRbqTIBkcFtiwEVOlQAuCUarG=egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('tvshowtitle')
   egWdYKRbqTIBkcFtiwEVOlQAuCUazf =egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('thumbnail')
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHm =egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('age')
   egWdYKRbqTIBkcFtiwEVOlQAuCUazj={'mediatype':'tvshow','mpaa':egWdYKRbqTIBkcFtiwEVOlQAuCUaHm,'title':'%s < %s >'%(egWdYKRbqTIBkcFtiwEVOlQAuCUarH,egWdYKRbqTIBkcFtiwEVOlQAuCUarG),'tvshowtitle':egWdYKRbqTIBkcFtiwEVOlQAuCUarG,'studio':egWdYKRbqTIBkcFtiwEVOlQAuCUarH,'plot':egWdYKRbqTIBkcFtiwEVOlQAuCUarH}
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj={'mode':'LIVE','contentid':egWdYKRbqTIBkcFtiwEVOlQAuCUarz}
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.add_dir(egWdYKRbqTIBkcFtiwEVOlQAuCUarH,sublabel=egWdYKRbqTIBkcFtiwEVOlQAuCUarG,img=egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('thumbnail'),infoLabels=egWdYKRbqTIBkcFtiwEVOlQAuCUazj,isFolder=egWdYKRbqTIBkcFtiwEVOlQAuCUaSn,params=egWdYKRbqTIBkcFtiwEVOlQAuCUavj)
  if egWdYKRbqTIBkcFtiwEVOlQAuCUazh:
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj={}
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj['mode'] ='BANDLIVESECTION_LIST' 
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj['subapi']=egWdYKRbqTIBkcFtiwEVOlQAuCUahp
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj['page'] =egWdYKRbqTIBkcFtiwEVOlQAuCUaSo(egWdYKRbqTIBkcFtiwEVOlQAuCUazX+1)
   egWdYKRbqTIBkcFtiwEVOlQAuCUavy='[B]%s >>[/B]'%'다음 페이지'
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHr=egWdYKRbqTIBkcFtiwEVOlQAuCUaSo(egWdYKRbqTIBkcFtiwEVOlQAuCUazX+1)
   egWdYKRbqTIBkcFtiwEVOlQAuCUavo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.add_dir(egWdYKRbqTIBkcFtiwEVOlQAuCUavy,sublabel=egWdYKRbqTIBkcFtiwEVOlQAuCUaHr,img=egWdYKRbqTIBkcFtiwEVOlQAuCUavo,infoLabels=egWdYKRbqTIBkcFtiwEVOlQAuCUaSG,isFolder=egWdYKRbqTIBkcFtiwEVOlQAuCUaSr,params=egWdYKRbqTIBkcFtiwEVOlQAuCUavj)
  if egWdYKRbqTIBkcFtiwEVOlQAuCUaSp(egWdYKRbqTIBkcFtiwEVOlQAuCUazM)>0:xbmcplugin.endOfDirectory(egWdYKRbqTIBkcFtiwEVOlQAuCUamn._addon_handle,cacheToDisc=egWdYKRbqTIBkcFtiwEVOlQAuCUaSn)
 def dp_Band2Section_List(egWdYKRbqTIBkcFtiwEVOlQAuCUamn,args):
  egWdYKRbqTIBkcFtiwEVOlQAuCUahp =args.get('subapi')
  egWdYKRbqTIBkcFtiwEVOlQAuCUazX=egWdYKRbqTIBkcFtiwEVOlQAuCUaSh(args.get('page'))
  egWdYKRbqTIBkcFtiwEVOlQAuCUazM,egWdYKRbqTIBkcFtiwEVOlQAuCUazh=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.Get_Band2Section_List(egWdYKRbqTIBkcFtiwEVOlQAuCUahp,egWdYKRbqTIBkcFtiwEVOlQAuCUazX)
  for egWdYKRbqTIBkcFtiwEVOlQAuCUazJ in egWdYKRbqTIBkcFtiwEVOlQAuCUazM:
   egWdYKRbqTIBkcFtiwEVOlQAuCUavy =egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('programtitle')
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHr =egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('episodetitle')
   egWdYKRbqTIBkcFtiwEVOlQAuCUazj={'plot':egWdYKRbqTIBkcFtiwEVOlQAuCUavy+'\n\n'+egWdYKRbqTIBkcFtiwEVOlQAuCUaHr,'mpaa':egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('age'),'mediatype':'episode'}
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj={'mode':'VOD','programid':'-','contentid':egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('videoid'),'thumbnail':egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('thumbnail'),'title':egWdYKRbqTIBkcFtiwEVOlQAuCUavy,'subtitle':egWdYKRbqTIBkcFtiwEVOlQAuCUaHr}
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.add_dir(egWdYKRbqTIBkcFtiwEVOlQAuCUavy,sublabel=egWdYKRbqTIBkcFtiwEVOlQAuCUaHr,img=egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('thumbnail'),infoLabels=egWdYKRbqTIBkcFtiwEVOlQAuCUazj,isFolder=egWdYKRbqTIBkcFtiwEVOlQAuCUaSn,params=egWdYKRbqTIBkcFtiwEVOlQAuCUavj)
  if egWdYKRbqTIBkcFtiwEVOlQAuCUazh:
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj={}
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj['mode'] ='BAND2SECTION_LIST' 
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj['subapi']=egWdYKRbqTIBkcFtiwEVOlQAuCUahp
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj['page'] =egWdYKRbqTIBkcFtiwEVOlQAuCUaSo(egWdYKRbqTIBkcFtiwEVOlQAuCUazX+1)
   egWdYKRbqTIBkcFtiwEVOlQAuCUavy='[B]%s >>[/B]'%'다음 페이지'
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHr=egWdYKRbqTIBkcFtiwEVOlQAuCUaSo(egWdYKRbqTIBkcFtiwEVOlQAuCUazX+1)
   egWdYKRbqTIBkcFtiwEVOlQAuCUavo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.add_dir(egWdYKRbqTIBkcFtiwEVOlQAuCUavy,sublabel=egWdYKRbqTIBkcFtiwEVOlQAuCUaHr,img=egWdYKRbqTIBkcFtiwEVOlQAuCUavo,infoLabels=egWdYKRbqTIBkcFtiwEVOlQAuCUaSG,isFolder=egWdYKRbqTIBkcFtiwEVOlQAuCUaSr,params=egWdYKRbqTIBkcFtiwEVOlQAuCUavj)
  if egWdYKRbqTIBkcFtiwEVOlQAuCUaSp(egWdYKRbqTIBkcFtiwEVOlQAuCUazM)>0:xbmcplugin.endOfDirectory(egWdYKRbqTIBkcFtiwEVOlQAuCUamn._addon_handle,cacheToDisc=egWdYKRbqTIBkcFtiwEVOlQAuCUaSn)
 def dp_Movie_List(egWdYKRbqTIBkcFtiwEVOlQAuCUamn,args):
  egWdYKRbqTIBkcFtiwEVOlQAuCUahp =args.get('subapi')
  egWdYKRbqTIBkcFtiwEVOlQAuCUazX=egWdYKRbqTIBkcFtiwEVOlQAuCUaSh(args.get('page'))
  egWdYKRbqTIBkcFtiwEVOlQAuCUavn =args.get('orderby')or '-'
  egWdYKRbqTIBkcFtiwEVOlQAuCUamn.addon_log('dp_Movie_List')
  egWdYKRbqTIBkcFtiwEVOlQAuCUamn.addon_log(egWdYKRbqTIBkcFtiwEVOlQAuCUahp)
  egWdYKRbqTIBkcFtiwEVOlQAuCUazM,egWdYKRbqTIBkcFtiwEVOlQAuCUazh=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.Get_Movie_List(egWdYKRbqTIBkcFtiwEVOlQAuCUahp,egWdYKRbqTIBkcFtiwEVOlQAuCUazX,egWdYKRbqTIBkcFtiwEVOlQAuCUavn)
  for egWdYKRbqTIBkcFtiwEVOlQAuCUazJ in egWdYKRbqTIBkcFtiwEVOlQAuCUazM:
   egWdYKRbqTIBkcFtiwEVOlQAuCUazD =egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('videoid')
   egWdYKRbqTIBkcFtiwEVOlQAuCUazx =egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('vidtype')
   egWdYKRbqTIBkcFtiwEVOlQAuCUavy =egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('title')
   egWdYKRbqTIBkcFtiwEVOlQAuCUazf=egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('thumbnail')
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHm =egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('age')
   if egWdYKRbqTIBkcFtiwEVOlQAuCUaHm=='18' or egWdYKRbqTIBkcFtiwEVOlQAuCUaHm=='19' or egWdYKRbqTIBkcFtiwEVOlQAuCUaHm=='21':egWdYKRbqTIBkcFtiwEVOlQAuCUavy+=' (%s)'%(egWdYKRbqTIBkcFtiwEVOlQAuCUaHm)
   egWdYKRbqTIBkcFtiwEVOlQAuCUazj={'plot':egWdYKRbqTIBkcFtiwEVOlQAuCUavy,'mpaa':egWdYKRbqTIBkcFtiwEVOlQAuCUaHm,'mediatype':'movie'}
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj={'mode':'MOVIE','contentid':egWdYKRbqTIBkcFtiwEVOlQAuCUazD,'title':egWdYKRbqTIBkcFtiwEVOlQAuCUavy,'thumbnail':egWdYKRbqTIBkcFtiwEVOlQAuCUazf,'age':egWdYKRbqTIBkcFtiwEVOlQAuCUaHm,}
   egWdYKRbqTIBkcFtiwEVOlQAuCUazo=[]
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHv={'mode':'VIEW_DETAIL','values':{'videoid':egWdYKRbqTIBkcFtiwEVOlQAuCUazD,'vidtype':'movie','contenttype':egWdYKRbqTIBkcFtiwEVOlQAuCUazx,}}
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHz=json.dumps(egWdYKRbqTIBkcFtiwEVOlQAuCUaHv,separators=(',',':'))
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHz=base64.standard_b64encode(egWdYKRbqTIBkcFtiwEVOlQAuCUaHz.encode()).decode('utf-8')
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHz=egWdYKRbqTIBkcFtiwEVOlQAuCUaHz.replace('+','%2B')
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHG='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(egWdYKRbqTIBkcFtiwEVOlQAuCUaHz)
   egWdYKRbqTIBkcFtiwEVOlQAuCUazo.append(('상세정보 조회',egWdYKRbqTIBkcFtiwEVOlQAuCUaHG))
   if egWdYKRbqTIBkcFtiwEVOlQAuCUamn.get_settings_makebookmark():
    egWdYKRbqTIBkcFtiwEVOlQAuCUaHv={'videoid':egWdYKRbqTIBkcFtiwEVOlQAuCUazD,'vidtype':'movie','vtitle':egWdYKRbqTIBkcFtiwEVOlQAuCUavy,'vsubtitle':'','contenttype':'programid',}
    egWdYKRbqTIBkcFtiwEVOlQAuCUaHh=json.dumps(egWdYKRbqTIBkcFtiwEVOlQAuCUaHv)
    egWdYKRbqTIBkcFtiwEVOlQAuCUaHh=urllib.parse.quote(egWdYKRbqTIBkcFtiwEVOlQAuCUaHh)
    egWdYKRbqTIBkcFtiwEVOlQAuCUaHG='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(egWdYKRbqTIBkcFtiwEVOlQAuCUaHh)
    egWdYKRbqTIBkcFtiwEVOlQAuCUazo.append(('(통합) 찜 영상에 추가',egWdYKRbqTIBkcFtiwEVOlQAuCUaHG))
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.add_dir(egWdYKRbqTIBkcFtiwEVOlQAuCUavy,sublabel='',img=egWdYKRbqTIBkcFtiwEVOlQAuCUazf,infoLabels=egWdYKRbqTIBkcFtiwEVOlQAuCUazj,isFolder=egWdYKRbqTIBkcFtiwEVOlQAuCUaSn,params=egWdYKRbqTIBkcFtiwEVOlQAuCUavj,ContextMenu=egWdYKRbqTIBkcFtiwEVOlQAuCUazo)
  if egWdYKRbqTIBkcFtiwEVOlQAuCUazh:
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj={}
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj['mode'] ='MOVIE_LIST' 
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj['subapi']=egWdYKRbqTIBkcFtiwEVOlQAuCUahp 
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj['page'] =egWdYKRbqTIBkcFtiwEVOlQAuCUaSo(egWdYKRbqTIBkcFtiwEVOlQAuCUazX+1)
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj['orderby']=egWdYKRbqTIBkcFtiwEVOlQAuCUavn
   egWdYKRbqTIBkcFtiwEVOlQAuCUavy='[B]%s >>[/B]'%'다음 페이지'
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHr=egWdYKRbqTIBkcFtiwEVOlQAuCUaSo(egWdYKRbqTIBkcFtiwEVOlQAuCUazX+1)
   egWdYKRbqTIBkcFtiwEVOlQAuCUavo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.add_dir(egWdYKRbqTIBkcFtiwEVOlQAuCUavy,sublabel=egWdYKRbqTIBkcFtiwEVOlQAuCUaHr,img=egWdYKRbqTIBkcFtiwEVOlQAuCUavo,infoLabels=egWdYKRbqTIBkcFtiwEVOlQAuCUaSG,isFolder=egWdYKRbqTIBkcFtiwEVOlQAuCUaSr,params=egWdYKRbqTIBkcFtiwEVOlQAuCUavj)
  xbmcplugin.setContent(egWdYKRbqTIBkcFtiwEVOlQAuCUamn._addon_handle,'movies')
  if egWdYKRbqTIBkcFtiwEVOlQAuCUaSp(egWdYKRbqTIBkcFtiwEVOlQAuCUazM)>0:xbmcplugin.endOfDirectory(egWdYKRbqTIBkcFtiwEVOlQAuCUamn._addon_handle,cacheToDisc=egWdYKRbqTIBkcFtiwEVOlQAuCUaSn)
 def dp_Set_Bookmark(egWdYKRbqTIBkcFtiwEVOlQAuCUamn,args):
  egWdYKRbqTIBkcFtiwEVOlQAuCUarh=urllib.parse.unquote(args.get('bm_param'))
  egWdYKRbqTIBkcFtiwEVOlQAuCUarh=json.loads(egWdYKRbqTIBkcFtiwEVOlQAuCUarh)
  egWdYKRbqTIBkcFtiwEVOlQAuCUazD =egWdYKRbqTIBkcFtiwEVOlQAuCUarh.get('videoid')
  egWdYKRbqTIBkcFtiwEVOlQAuCUazx =egWdYKRbqTIBkcFtiwEVOlQAuCUarh.get('vidtype')
  egWdYKRbqTIBkcFtiwEVOlQAuCUarS =egWdYKRbqTIBkcFtiwEVOlQAuCUarh.get('vtitle')
  egWdYKRbqTIBkcFtiwEVOlQAuCUarn =egWdYKRbqTIBkcFtiwEVOlQAuCUarh.get('vsubtitle')
  egWdYKRbqTIBkcFtiwEVOlQAuCUarL=egWdYKRbqTIBkcFtiwEVOlQAuCUarh.get('contenttype')
  egWdYKRbqTIBkcFtiwEVOlQAuCUamp=xbmcgui.Dialog()
  egWdYKRbqTIBkcFtiwEVOlQAuCUaHx=egWdYKRbqTIBkcFtiwEVOlQAuCUamp.yesno(__language__(30913).encode('utf8'),egWdYKRbqTIBkcFtiwEVOlQAuCUarS+' \n\n'+__language__(30914))
  if egWdYKRbqTIBkcFtiwEVOlQAuCUaHx==egWdYKRbqTIBkcFtiwEVOlQAuCUaSn:return
  egWdYKRbqTIBkcFtiwEVOlQAuCUary=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.GetBookmarkInfo(egWdYKRbqTIBkcFtiwEVOlQAuCUazD,egWdYKRbqTIBkcFtiwEVOlQAuCUazx,egWdYKRbqTIBkcFtiwEVOlQAuCUarL)
  egWdYKRbqTIBkcFtiwEVOlQAuCUarN=json.dumps(egWdYKRbqTIBkcFtiwEVOlQAuCUary)
  egWdYKRbqTIBkcFtiwEVOlQAuCUarN=urllib.parse.quote(egWdYKRbqTIBkcFtiwEVOlQAuCUarN)
  egWdYKRbqTIBkcFtiwEVOlQAuCUaHG ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(egWdYKRbqTIBkcFtiwEVOlQAuCUarN)
  xbmc.executebuiltin(egWdYKRbqTIBkcFtiwEVOlQAuCUaHG)
 def dp_LiveChannel_List(egWdYKRbqTIBkcFtiwEVOlQAuCUamn,args):
  egWdYKRbqTIBkcFtiwEVOlQAuCUars =args.get('genre')
  egWdYKRbqTIBkcFtiwEVOlQAuCUahs=args.get('baseapi')
  egWdYKRbqTIBkcFtiwEVOlQAuCUazM=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.Get_LiveChannel_List(egWdYKRbqTIBkcFtiwEVOlQAuCUars,egWdYKRbqTIBkcFtiwEVOlQAuCUahs)
  for egWdYKRbqTIBkcFtiwEVOlQAuCUazJ in egWdYKRbqTIBkcFtiwEVOlQAuCUazM:
   egWdYKRbqTIBkcFtiwEVOlQAuCUarz =egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('channelid')
   egWdYKRbqTIBkcFtiwEVOlQAuCUarH =egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('studio')
   egWdYKRbqTIBkcFtiwEVOlQAuCUarG=egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('tvshowtitle')
   egWdYKRbqTIBkcFtiwEVOlQAuCUazf =egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('thumbnail')
   egWdYKRbqTIBkcFtiwEVOlQAuCUaHm =egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('age')
   egWdYKRbqTIBkcFtiwEVOlQAuCUarp =egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('epg')
   egWdYKRbqTIBkcFtiwEVOlQAuCUazj={'mediatype':'episode','mpaa':egWdYKRbqTIBkcFtiwEVOlQAuCUaHm,'title':'%s < %s >'%(egWdYKRbqTIBkcFtiwEVOlQAuCUarH,egWdYKRbqTIBkcFtiwEVOlQAuCUarG),'tvshowtitle':egWdYKRbqTIBkcFtiwEVOlQAuCUarG,'studio':egWdYKRbqTIBkcFtiwEVOlQAuCUarH,'plot':'%s\n\n%s'%(egWdYKRbqTIBkcFtiwEVOlQAuCUarH,egWdYKRbqTIBkcFtiwEVOlQAuCUarp)}
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj={'mode':'LIVE','contentid':egWdYKRbqTIBkcFtiwEVOlQAuCUarz}
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.add_dir(egWdYKRbqTIBkcFtiwEVOlQAuCUarH,sublabel=egWdYKRbqTIBkcFtiwEVOlQAuCUarG,img=egWdYKRbqTIBkcFtiwEVOlQAuCUazf,infoLabels=egWdYKRbqTIBkcFtiwEVOlQAuCUazj,isFolder=egWdYKRbqTIBkcFtiwEVOlQAuCUaSn,params=egWdYKRbqTIBkcFtiwEVOlQAuCUavj)
  if egWdYKRbqTIBkcFtiwEVOlQAuCUaSp(egWdYKRbqTIBkcFtiwEVOlQAuCUazM)>0:xbmcplugin.endOfDirectory(egWdYKRbqTIBkcFtiwEVOlQAuCUamn._addon_handle,cacheToDisc=egWdYKRbqTIBkcFtiwEVOlQAuCUaSn)
 def dp_Sports_GameList(egWdYKRbqTIBkcFtiwEVOlQAuCUamn,args):
  egWdYKRbqTIBkcFtiwEVOlQAuCUazM=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.Get_Sports_Gamelist()
  for egWdYKRbqTIBkcFtiwEVOlQAuCUazJ in egWdYKRbqTIBkcFtiwEVOlQAuCUazM:
   egWdYKRbqTIBkcFtiwEVOlQAuCUarP =egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('game_date')
   egWdYKRbqTIBkcFtiwEVOlQAuCUaro =egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('game_time')
   egWdYKRbqTIBkcFtiwEVOlQAuCUarj =egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('svc_id')
   egWdYKRbqTIBkcFtiwEVOlQAuCUarX =egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('away_team')
   egWdYKRbqTIBkcFtiwEVOlQAuCUarM =egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('home_team')
   egWdYKRbqTIBkcFtiwEVOlQAuCUarJ=egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('game_status')
   egWdYKRbqTIBkcFtiwEVOlQAuCUarD =egWdYKRbqTIBkcFtiwEVOlQAuCUazJ.get('game_place')
   egWdYKRbqTIBkcFtiwEVOlQAuCUarx ='%s vs %s (%s)'%(egWdYKRbqTIBkcFtiwEVOlQAuCUarX,egWdYKRbqTIBkcFtiwEVOlQAuCUarM,egWdYKRbqTIBkcFtiwEVOlQAuCUarD)
   egWdYKRbqTIBkcFtiwEVOlQAuCUarf =egWdYKRbqTIBkcFtiwEVOlQAuCUarP+' '+egWdYKRbqTIBkcFtiwEVOlQAuCUaro
   if egWdYKRbqTIBkcFtiwEVOlQAuCUarJ=='LIVE':
    egWdYKRbqTIBkcFtiwEVOlQAuCUarJ='~경기중~'
   elif egWdYKRbqTIBkcFtiwEVOlQAuCUarJ=='END':
    egWdYKRbqTIBkcFtiwEVOlQAuCUarJ='경기종료'
   elif egWdYKRbqTIBkcFtiwEVOlQAuCUarJ=='CANCEL':
    egWdYKRbqTIBkcFtiwEVOlQAuCUarJ='취소'
   else:
    egWdYKRbqTIBkcFtiwEVOlQAuCUarJ=''
   if egWdYKRbqTIBkcFtiwEVOlQAuCUarJ=='':
    egWdYKRbqTIBkcFtiwEVOlQAuCUaHr=egWdYKRbqTIBkcFtiwEVOlQAuCUarx
   else:
    egWdYKRbqTIBkcFtiwEVOlQAuCUaHr=egWdYKRbqTIBkcFtiwEVOlQAuCUarx+'  '+egWdYKRbqTIBkcFtiwEVOlQAuCUarJ
   egWdYKRbqTIBkcFtiwEVOlQAuCUazj={'mediatype':'episode','title':egWdYKRbqTIBkcFtiwEVOlQAuCUarx,'plot':'%s\n\n%s\n\n%s'%(egWdYKRbqTIBkcFtiwEVOlQAuCUarf,egWdYKRbqTIBkcFtiwEVOlQAuCUarx,egWdYKRbqTIBkcFtiwEVOlQAuCUarJ)}
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj={'mode':'SPORTS','contentid':egWdYKRbqTIBkcFtiwEVOlQAuCUarj}
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.add_dir(egWdYKRbqTIBkcFtiwEVOlQAuCUarf,sublabel=egWdYKRbqTIBkcFtiwEVOlQAuCUaHr,img='',infoLabels=egWdYKRbqTIBkcFtiwEVOlQAuCUazj,isFolder=egWdYKRbqTIBkcFtiwEVOlQAuCUaSn,params=egWdYKRbqTIBkcFtiwEVOlQAuCUavj)
  xbmcplugin.endOfDirectory(egWdYKRbqTIBkcFtiwEVOlQAuCUamn._addon_handle,cacheToDisc=egWdYKRbqTIBkcFtiwEVOlQAuCUaSn)
 def dp_View_Detail(egWdYKRbqTIBkcFtiwEVOlQAuCUamn,egWdYKRbqTIBkcFtiwEVOlQAuCUaSz):
  egWdYKRbqTIBkcFtiwEVOlQAuCUazD =egWdYKRbqTIBkcFtiwEVOlQAuCUaSz.get('videoid')
  egWdYKRbqTIBkcFtiwEVOlQAuCUazx =egWdYKRbqTIBkcFtiwEVOlQAuCUaSz.get('vidtype') 
  egWdYKRbqTIBkcFtiwEVOlQAuCUarL=egWdYKRbqTIBkcFtiwEVOlQAuCUaSz.get('contenttype')
  egWdYKRbqTIBkcFtiwEVOlQAuCUamn.addon_log(egWdYKRbqTIBkcFtiwEVOlQAuCUazD)
  egWdYKRbqTIBkcFtiwEVOlQAuCUamn.addon_log(egWdYKRbqTIBkcFtiwEVOlQAuCUazx)
  egWdYKRbqTIBkcFtiwEVOlQAuCUamn.addon_log(egWdYKRbqTIBkcFtiwEVOlQAuCUarL)
  egWdYKRbqTIBkcFtiwEVOlQAuCUary=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.GetBookmarkInfo(egWdYKRbqTIBkcFtiwEVOlQAuCUazD,egWdYKRbqTIBkcFtiwEVOlQAuCUazx,egWdYKRbqTIBkcFtiwEVOlQAuCUarL)
  if egWdYKRbqTIBkcFtiwEVOlQAuCUazx=='tvshow':
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj={'mode':'SEASON_LIST','videoid':egWdYKRbqTIBkcFtiwEVOlQAuCUary['indexinfo']['videoid'],'vidtype':egWdYKRbqTIBkcFtiwEVOlQAuCUary['indexinfo']['vidtype'],}
   egWdYKRbqTIBkcFtiwEVOlQAuCUaGz='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(egWdYKRbqTIBkcFtiwEVOlQAuCUavj))
  else:
   egWdYKRbqTIBkcFtiwEVOlQAuCUavj={'mode':'MOVIE','contentid':egWdYKRbqTIBkcFtiwEVOlQAuCUary['indexinfo']['videoid'],'title':egWdYKRbqTIBkcFtiwEVOlQAuCUary['saveinfo']['infoLabels']['title'],'thumbnail':egWdYKRbqTIBkcFtiwEVOlQAuCUary['saveinfo']['thumbnail'],'age':egWdYKRbqTIBkcFtiwEVOlQAuCUary['saveinfo']['infoLabels']['mpaa'],}
   egWdYKRbqTIBkcFtiwEVOlQAuCUaGz='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(egWdYKRbqTIBkcFtiwEVOlQAuCUavj))
  egWdYKRbqTIBkcFtiwEVOlQAuCUavN=xbmcgui.ListItem(label=egWdYKRbqTIBkcFtiwEVOlQAuCUary['saveinfo']['title'],path=egWdYKRbqTIBkcFtiwEVOlQAuCUaGz)
  egWdYKRbqTIBkcFtiwEVOlQAuCUavN.setArt(egWdYKRbqTIBkcFtiwEVOlQAuCUary['saveinfo']['thumbnail'])
  egWdYKRbqTIBkcFtiwEVOlQAuCUamn.Set_InfoTag(egWdYKRbqTIBkcFtiwEVOlQAuCUavN.getVideoInfoTag(),egWdYKRbqTIBkcFtiwEVOlQAuCUary['saveinfo']['infoLabels'])
  if egWdYKRbqTIBkcFtiwEVOlQAuCUazx=='movie':
   egWdYKRbqTIBkcFtiwEVOlQAuCUavN.setIsFolder(egWdYKRbqTIBkcFtiwEVOlQAuCUaSn)
   egWdYKRbqTIBkcFtiwEVOlQAuCUavN.setProperty('IsPlayable','true')
  else:
   egWdYKRbqTIBkcFtiwEVOlQAuCUavN.setIsFolder(egWdYKRbqTIBkcFtiwEVOlQAuCUaSr)
   egWdYKRbqTIBkcFtiwEVOlQAuCUavN.setProperty('IsPlayable','false')
  egWdYKRbqTIBkcFtiwEVOlQAuCUamp=xbmcgui.Dialog()
  egWdYKRbqTIBkcFtiwEVOlQAuCUamp.info(egWdYKRbqTIBkcFtiwEVOlQAuCUavN)
 def wavve_main(egWdYKRbqTIBkcFtiwEVOlQAuCUamn):
  egWdYKRbqTIBkcFtiwEVOlQAuCUamn.WavveObj.KodiVersion=egWdYKRbqTIBkcFtiwEVOlQAuCUaSh(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  egWdYKRbqTIBkcFtiwEVOlQAuCUaSm=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.main_params.get('params')
  if egWdYKRbqTIBkcFtiwEVOlQAuCUaSm:
   egWdYKRbqTIBkcFtiwEVOlQAuCUaSv =base64.standard_b64decode(egWdYKRbqTIBkcFtiwEVOlQAuCUaSm).decode('utf-8')
   egWdYKRbqTIBkcFtiwEVOlQAuCUaSv =json.loads(egWdYKRbqTIBkcFtiwEVOlQAuCUaSv)
   egWdYKRbqTIBkcFtiwEVOlQAuCUazv =egWdYKRbqTIBkcFtiwEVOlQAuCUaSv.get('mode')
   egWdYKRbqTIBkcFtiwEVOlQAuCUaSz =egWdYKRbqTIBkcFtiwEVOlQAuCUaSv.get('values')
  else:
   egWdYKRbqTIBkcFtiwEVOlQAuCUazv=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.main_params.get('mode',egWdYKRbqTIBkcFtiwEVOlQAuCUaSG)
   egWdYKRbqTIBkcFtiwEVOlQAuCUaSz=egWdYKRbqTIBkcFtiwEVOlQAuCUamn.main_params
  if egWdYKRbqTIBkcFtiwEVOlQAuCUazv=='LOGOUT':
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.logout()
   return
  egWdYKRbqTIBkcFtiwEVOlQAuCUamn.login_main()
  if egWdYKRbqTIBkcFtiwEVOlQAuCUazv is egWdYKRbqTIBkcFtiwEVOlQAuCUaSG:
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.dp_Main_List()
  elif egWdYKRbqTIBkcFtiwEVOlQAuCUazv in['LIVE','VOD','MOVIE','SPORTS']:
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.play_VIDEO(egWdYKRbqTIBkcFtiwEVOlQAuCUaSz)
  elif egWdYKRbqTIBkcFtiwEVOlQAuCUazv=='LIVE_CATAGORY':
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.dp_LiveCatagory_List(egWdYKRbqTIBkcFtiwEVOlQAuCUaSz)
  elif egWdYKRbqTIBkcFtiwEVOlQAuCUazv=='MAIN_CATAGORY':
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.dp_MainCatagory_List(egWdYKRbqTIBkcFtiwEVOlQAuCUaSz)
  elif egWdYKRbqTIBkcFtiwEVOlQAuCUazv=='SUPERSECTION_LIST':
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.dp_SuperSection_List(egWdYKRbqTIBkcFtiwEVOlQAuCUaSz)
  elif egWdYKRbqTIBkcFtiwEVOlQAuCUazv=='BANDLIVESECTION_LIST':
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.dp_BandLiveSection_List(egWdYKRbqTIBkcFtiwEVOlQAuCUaSz)
  elif egWdYKRbqTIBkcFtiwEVOlQAuCUazv=='BAND2SECTION_LIST':
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.dp_Band2Section_List(egWdYKRbqTIBkcFtiwEVOlQAuCUaSz)
  elif egWdYKRbqTIBkcFtiwEVOlQAuCUazv=='PROGRAM_LIST':
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.dp_Program_List(egWdYKRbqTIBkcFtiwEVOlQAuCUaSz)
  elif egWdYKRbqTIBkcFtiwEVOlQAuCUazv=='SEASON_LIST':
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.dp_Season_List(egWdYKRbqTIBkcFtiwEVOlQAuCUaSz)
  elif egWdYKRbqTIBkcFtiwEVOlQAuCUazv=='EPISODE_LIST':
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.dp_Episode_List(egWdYKRbqTIBkcFtiwEVOlQAuCUaSz)
  elif egWdYKRbqTIBkcFtiwEVOlQAuCUazv=='MOVIE_LIST':
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.dp_Movie_List(egWdYKRbqTIBkcFtiwEVOlQAuCUaSz)
  elif egWdYKRbqTIBkcFtiwEVOlQAuCUazv=='LIVE_LIST':
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.dp_LiveChannel_List(egWdYKRbqTIBkcFtiwEVOlQAuCUaSz)
  elif egWdYKRbqTIBkcFtiwEVOlQAuCUazv=='ORDER_BY':
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.dp_setEpOrderby(egWdYKRbqTIBkcFtiwEVOlQAuCUaSz)
  elif egWdYKRbqTIBkcFtiwEVOlQAuCUazv=='SEARCH_GROUP':
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.dp_Search_Group(egWdYKRbqTIBkcFtiwEVOlQAuCUaSz)
  elif egWdYKRbqTIBkcFtiwEVOlQAuCUazv in['SEARCH_LIST','LOCAL_SEARCH']:
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.dp_Search_List(egWdYKRbqTIBkcFtiwEVOlQAuCUaSz)
  elif egWdYKRbqTIBkcFtiwEVOlQAuCUazv=='WATCH_GROUP':
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.dp_Watch_Group(egWdYKRbqTIBkcFtiwEVOlQAuCUaSz)
  elif egWdYKRbqTIBkcFtiwEVOlQAuCUazv=='WATCH_LIST':
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.dp_Watch_List(egWdYKRbqTIBkcFtiwEVOlQAuCUaSz)
  elif egWdYKRbqTIBkcFtiwEVOlQAuCUazv=='SET_BOOKMARK':
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.dp_Set_Bookmark(egWdYKRbqTIBkcFtiwEVOlQAuCUaSz)
  elif egWdYKRbqTIBkcFtiwEVOlQAuCUazv in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.dp_History_Remove(egWdYKRbqTIBkcFtiwEVOlQAuCUaSz)
  elif egWdYKRbqTIBkcFtiwEVOlQAuCUazv in['TOTAL_SEARCH','TOTAL_HISTORY']:
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.dp_Global_Search(egWdYKRbqTIBkcFtiwEVOlQAuCUaSz)
  elif egWdYKRbqTIBkcFtiwEVOlQAuCUazv=='SEARCH_HISTORY':
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.dp_Search_History(egWdYKRbqTIBkcFtiwEVOlQAuCUaSz)
  elif egWdYKRbqTIBkcFtiwEVOlQAuCUazv=='MENU_BOOKMARK':
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.dp_Bookmark_Menu(egWdYKRbqTIBkcFtiwEVOlQAuCUaSz)
  elif egWdYKRbqTIBkcFtiwEVOlQAuCUazv=='GAME_LIST':
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.dp_Sports_GameList(egWdYKRbqTIBkcFtiwEVOlQAuCUaSz)
  elif egWdYKRbqTIBkcFtiwEVOlQAuCUazv=='VIEW_DETAIL':
   egWdYKRbqTIBkcFtiwEVOlQAuCUamn.dp_View_Detail(egWdYKRbqTIBkcFtiwEVOlQAuCUaSz)
  else:
   egWdYKRbqTIBkcFtiwEVOlQAuCUaSG
# Created by pyminifier (https://github.com/liftoff/pyminifier)
