__author__="NightRain"
WphxrkBgtInjPuUQdKDTSMYvlXCsFc=object
WphxrkBgtInjPuUQdKDTSMYvlXCsFV=None
WphxrkBgtInjPuUQdKDTSMYvlXCsFo=int
WphxrkBgtInjPuUQdKDTSMYvlXCsFA=False
WphxrkBgtInjPuUQdKDTSMYvlXCsFz=True
WphxrkBgtInjPuUQdKDTSMYvlXCsFO=type
WphxrkBgtInjPuUQdKDTSMYvlXCsFm=dict
WphxrkBgtInjPuUQdKDTSMYvlXCsFN=len
WphxrkBgtInjPuUQdKDTSMYvlXCsFL=open
WphxrkBgtInjPuUQdKDTSMYvlXCsEa=Exception
WphxrkBgtInjPuUQdKDTSMYvlXCsEb=print
WphxrkBgtInjPuUQdKDTSMYvlXCsEe=str
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
WphxrkBgtInjPuUQdKDTSMYvlXCsae=[{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://www.wavve.com/supermultisection/GN51','icon':'home.png'},{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&offset=0&limit=20&uicode=VN500','page':'1','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=01&WeekDay=all&uitype=VN4&uiparent=FN0&uirank=0&broadcastid=847243&uicode=VN4','page':'1','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=02&WeekDay=all&uitype=VN3&uiparent=FN0&uirank=0&broadcastid=783664&uicode=VN3','page':'1','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'1','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'paid','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'displaystart','ordernm':'업데이트순','icon':''},{'title':'검색 (search)','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'}]
WphxrkBgtInjPuUQdKDTSMYvlXCsay=[{'title':'VOD 검색','mode':'SEARCH_LIST','sType':'vod'},{'title':'영화 검색','mode':'SEARCH_LIST','sType':'movie'}]
WphxrkBgtInjPuUQdKDTSMYvlXCsaF=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
WphxrkBgtInjPuUQdKDTSMYvlXCsaE=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
from wavveCore import*
class WphxrkBgtInjPuUQdKDTSMYvlXCsab(WphxrkBgtInjPuUQdKDTSMYvlXCsFc):
 def __init__(WphxrkBgtInjPuUQdKDTSMYvlXCsaR,WphxrkBgtInjPuUQdKDTSMYvlXCsai,WphxrkBgtInjPuUQdKDTSMYvlXCsaq,WphxrkBgtInjPuUQdKDTSMYvlXCsaH):
  WphxrkBgtInjPuUQdKDTSMYvlXCsaR._addon_url =WphxrkBgtInjPuUQdKDTSMYvlXCsai
  WphxrkBgtInjPuUQdKDTSMYvlXCsaR._addon_handle=WphxrkBgtInjPuUQdKDTSMYvlXCsaq
  WphxrkBgtInjPuUQdKDTSMYvlXCsaR.main_params =WphxrkBgtInjPuUQdKDTSMYvlXCsaH
  WphxrkBgtInjPuUQdKDTSMYvlXCsaR.WavveObj =FbqHspimQocudKlnzjRDgMatXCLSBT() 
 def addon_noti(WphxrkBgtInjPuUQdKDTSMYvlXCsaR,sting):
  try:
   WphxrkBgtInjPuUQdKDTSMYvlXCsaG=xbmcgui.Dialog()
   WphxrkBgtInjPuUQdKDTSMYvlXCsaG.notification(__addonname__,sting)
  except:
   WphxrkBgtInjPuUQdKDTSMYvlXCsFV
 def addon_log(WphxrkBgtInjPuUQdKDTSMYvlXCsaR,string):
  try:
   WphxrkBgtInjPuUQdKDTSMYvlXCsaf=string.encode('utf-8','ignore')
  except:
   WphxrkBgtInjPuUQdKDTSMYvlXCsaf='addonException: addon_log'
  WphxrkBgtInjPuUQdKDTSMYvlXCsaw=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,WphxrkBgtInjPuUQdKDTSMYvlXCsaf),level=WphxrkBgtInjPuUQdKDTSMYvlXCsaw)
 def get_keyboard_input(WphxrkBgtInjPuUQdKDTSMYvlXCsaR,WphxrkBgtInjPuUQdKDTSMYvlXCsbe):
  WphxrkBgtInjPuUQdKDTSMYvlXCsac=WphxrkBgtInjPuUQdKDTSMYvlXCsFV
  kb=xbmc.Keyboard()
  kb.setHeading(WphxrkBgtInjPuUQdKDTSMYvlXCsbe)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   WphxrkBgtInjPuUQdKDTSMYvlXCsac=kb.getText()
  return WphxrkBgtInjPuUQdKDTSMYvlXCsac
 def get_settings_login_info(WphxrkBgtInjPuUQdKDTSMYvlXCsaR):
  WphxrkBgtInjPuUQdKDTSMYvlXCsaV =__addon__.getSetting('id')
  WphxrkBgtInjPuUQdKDTSMYvlXCsao =__addon__.getSetting('pw')
  WphxrkBgtInjPuUQdKDTSMYvlXCsaA=__addon__.getSetting('selected_profile')
  return(WphxrkBgtInjPuUQdKDTSMYvlXCsaV,WphxrkBgtInjPuUQdKDTSMYvlXCsao,WphxrkBgtInjPuUQdKDTSMYvlXCsaA)
 def get_selQuality(WphxrkBgtInjPuUQdKDTSMYvlXCsaR):
  try:
   WphxrkBgtInjPuUQdKDTSMYvlXCsaz=[1080,720,480,360]
   WphxrkBgtInjPuUQdKDTSMYvlXCsaO=WphxrkBgtInjPuUQdKDTSMYvlXCsFo(__addon__.getSetting('selected_quality'))
   return WphxrkBgtInjPuUQdKDTSMYvlXCsaz[WphxrkBgtInjPuUQdKDTSMYvlXCsaO]
  except:
   WphxrkBgtInjPuUQdKDTSMYvlXCsFV
  return 1080 
 def get_settings_exclusion21(WphxrkBgtInjPuUQdKDTSMYvlXCsaR):
  WphxrkBgtInjPuUQdKDTSMYvlXCsam =__addon__.getSetting('exclusion21')
  if WphxrkBgtInjPuUQdKDTSMYvlXCsam=='false':
   return WphxrkBgtInjPuUQdKDTSMYvlXCsFA
  else:
   return WphxrkBgtInjPuUQdKDTSMYvlXCsFz
 def get_settings_direct_replay(WphxrkBgtInjPuUQdKDTSMYvlXCsaR):
  WphxrkBgtInjPuUQdKDTSMYvlXCsaN=WphxrkBgtInjPuUQdKDTSMYvlXCsFo(__addon__.getSetting('direct_replay'))
  if WphxrkBgtInjPuUQdKDTSMYvlXCsaN==0:
   return WphxrkBgtInjPuUQdKDTSMYvlXCsFA
  else:
   return WphxrkBgtInjPuUQdKDTSMYvlXCsFz
 def set_winCredential(WphxrkBgtInjPuUQdKDTSMYvlXCsaR,credential):
  WphxrkBgtInjPuUQdKDTSMYvlXCsaL=xbmcgui.Window(10000)
  WphxrkBgtInjPuUQdKDTSMYvlXCsaL.setProperty('WAVVE_M_CREDENTIAL',credential)
  WphxrkBgtInjPuUQdKDTSMYvlXCsaL.setProperty('WAVVE_M_LOGINTIME',WphxrkBgtInjPuUQdKDTSMYvlXCsaR.WavveObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(WphxrkBgtInjPuUQdKDTSMYvlXCsaR):
  WphxrkBgtInjPuUQdKDTSMYvlXCsaL=xbmcgui.Window(10000)
  return WphxrkBgtInjPuUQdKDTSMYvlXCsaL.getProperty('WAVVE_M_CREDENTIAL')
 def set_winEpisodeOrderby(WphxrkBgtInjPuUQdKDTSMYvlXCsaR,WphxrkBgtInjPuUQdKDTSMYvlXCsbz):
  WphxrkBgtInjPuUQdKDTSMYvlXCsaL=xbmcgui.Window(10000)
  WphxrkBgtInjPuUQdKDTSMYvlXCsaL.setProperty('WAVVE_M_ORDERBY',WphxrkBgtInjPuUQdKDTSMYvlXCsbz)
 def get_winEpisodeOrderby(WphxrkBgtInjPuUQdKDTSMYvlXCsaR):
  WphxrkBgtInjPuUQdKDTSMYvlXCsaL=xbmcgui.Window(10000)
  return WphxrkBgtInjPuUQdKDTSMYvlXCsaL.getProperty('WAVVE_M_ORDERBY')
 def add_dir(WphxrkBgtInjPuUQdKDTSMYvlXCsaR,label,sublabel='',img='',infoLabels=WphxrkBgtInjPuUQdKDTSMYvlXCsFV,isFolder=WphxrkBgtInjPuUQdKDTSMYvlXCsFz,params=''):
  WphxrkBgtInjPuUQdKDTSMYvlXCsba='%s?%s'%(WphxrkBgtInjPuUQdKDTSMYvlXCsaR._addon_url,urllib.parse.urlencode(params))
  if sublabel:WphxrkBgtInjPuUQdKDTSMYvlXCsbe='%s < %s >'%(label,sublabel)
  else: WphxrkBgtInjPuUQdKDTSMYvlXCsbe=label
  if not img:img='DefaultFolder.png'
  WphxrkBgtInjPuUQdKDTSMYvlXCsby=xbmcgui.ListItem(WphxrkBgtInjPuUQdKDTSMYvlXCsbe)
  if WphxrkBgtInjPuUQdKDTSMYvlXCsFO(img)==WphxrkBgtInjPuUQdKDTSMYvlXCsFm:
   WphxrkBgtInjPuUQdKDTSMYvlXCsby.setArt(img)
  else:
   WphxrkBgtInjPuUQdKDTSMYvlXCsby.setArt({'thumb':img,'poster':img})
  if infoLabels:WphxrkBgtInjPuUQdKDTSMYvlXCsby.setInfo('Video',infoLabels)
  if not isFolder:WphxrkBgtInjPuUQdKDTSMYvlXCsby.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(WphxrkBgtInjPuUQdKDTSMYvlXCsaR._addon_handle,WphxrkBgtInjPuUQdKDTSMYvlXCsba,WphxrkBgtInjPuUQdKDTSMYvlXCsby,isFolder)
 def dp_Main_List(WphxrkBgtInjPuUQdKDTSMYvlXCsaR):
  for WphxrkBgtInjPuUQdKDTSMYvlXCsbF in WphxrkBgtInjPuUQdKDTSMYvlXCsae:
   WphxrkBgtInjPuUQdKDTSMYvlXCsbe=WphxrkBgtInjPuUQdKDTSMYvlXCsbF.get('title')
   WphxrkBgtInjPuUQdKDTSMYvlXCsbE=''
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR={'mode':WphxrkBgtInjPuUQdKDTSMYvlXCsbF.get('mode'),'sCode':WphxrkBgtInjPuUQdKDTSMYvlXCsbF.get('sCode'),'sIndex':WphxrkBgtInjPuUQdKDTSMYvlXCsbF.get('sIndex'),'sType':WphxrkBgtInjPuUQdKDTSMYvlXCsbF.get('sType'),'suburl':WphxrkBgtInjPuUQdKDTSMYvlXCsbF.get('suburl'),'subapi':WphxrkBgtInjPuUQdKDTSMYvlXCsbF.get('subapi'),'page':WphxrkBgtInjPuUQdKDTSMYvlXCsbF.get('page'),'orderby':WphxrkBgtInjPuUQdKDTSMYvlXCsbF.get('orderby'),'ordernm':WphxrkBgtInjPuUQdKDTSMYvlXCsbF.get('ordernm')}
   if WphxrkBgtInjPuUQdKDTSMYvlXCsbF.get('mode')=='XXX':
    WphxrkBgtInjPuUQdKDTSMYvlXCsbi=WphxrkBgtInjPuUQdKDTSMYvlXCsFA
   else:
    if 'icon' in WphxrkBgtInjPuUQdKDTSMYvlXCsbF:
     WphxrkBgtInjPuUQdKDTSMYvlXCsbE=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',WphxrkBgtInjPuUQdKDTSMYvlXCsbF.get('icon')) 
    WphxrkBgtInjPuUQdKDTSMYvlXCsbi=WphxrkBgtInjPuUQdKDTSMYvlXCsFz
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.add_dir(WphxrkBgtInjPuUQdKDTSMYvlXCsbe,sublabel='',img=WphxrkBgtInjPuUQdKDTSMYvlXCsbE,infoLabels=WphxrkBgtInjPuUQdKDTSMYvlXCsFV,isFolder=WphxrkBgtInjPuUQdKDTSMYvlXCsbi,params=WphxrkBgtInjPuUQdKDTSMYvlXCsbR)
  if WphxrkBgtInjPuUQdKDTSMYvlXCsFN(WphxrkBgtInjPuUQdKDTSMYvlXCsae)>0:xbmcplugin.endOfDirectory(WphxrkBgtInjPuUQdKDTSMYvlXCsaR._addon_handle,cacheToDisc=WphxrkBgtInjPuUQdKDTSMYvlXCsFz)
 def dp_Search_Group(WphxrkBgtInjPuUQdKDTSMYvlXCsaR,args):
  for WphxrkBgtInjPuUQdKDTSMYvlXCsbH in WphxrkBgtInjPuUQdKDTSMYvlXCsay:
   WphxrkBgtInjPuUQdKDTSMYvlXCsbe=WphxrkBgtInjPuUQdKDTSMYvlXCsbH.get('title')
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR={'mode':WphxrkBgtInjPuUQdKDTSMYvlXCsbH.get('mode'),'sType':WphxrkBgtInjPuUQdKDTSMYvlXCsbH.get('sType'),'page':'1'}
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.add_dir(WphxrkBgtInjPuUQdKDTSMYvlXCsbe,sublabel='',img='',infoLabels=WphxrkBgtInjPuUQdKDTSMYvlXCsFV,isFolder=WphxrkBgtInjPuUQdKDTSMYvlXCsFz,params=WphxrkBgtInjPuUQdKDTSMYvlXCsbR)
  if WphxrkBgtInjPuUQdKDTSMYvlXCsFN(WphxrkBgtInjPuUQdKDTSMYvlXCsay)>0:xbmcplugin.endOfDirectory(WphxrkBgtInjPuUQdKDTSMYvlXCsaR._addon_handle,cacheToDisc=WphxrkBgtInjPuUQdKDTSMYvlXCsFz)
 def dp_Watch_Group(WphxrkBgtInjPuUQdKDTSMYvlXCsaR,args):
  for WphxrkBgtInjPuUQdKDTSMYvlXCsbJ in WphxrkBgtInjPuUQdKDTSMYvlXCsaF:
   WphxrkBgtInjPuUQdKDTSMYvlXCsbe=WphxrkBgtInjPuUQdKDTSMYvlXCsbJ.get('title')
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR={'mode':WphxrkBgtInjPuUQdKDTSMYvlXCsbJ.get('mode'),'sType':WphxrkBgtInjPuUQdKDTSMYvlXCsbJ.get('sType')}
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.add_dir(WphxrkBgtInjPuUQdKDTSMYvlXCsbe,sublabel='',img='',infoLabels=WphxrkBgtInjPuUQdKDTSMYvlXCsFV,isFolder=WphxrkBgtInjPuUQdKDTSMYvlXCsFz,params=WphxrkBgtInjPuUQdKDTSMYvlXCsbR)
  if WphxrkBgtInjPuUQdKDTSMYvlXCsFN(WphxrkBgtInjPuUQdKDTSMYvlXCsaF)>0:xbmcplugin.endOfDirectory(WphxrkBgtInjPuUQdKDTSMYvlXCsaR._addon_handle,cacheToDisc=WphxrkBgtInjPuUQdKDTSMYvlXCsFz)
 def login_main(WphxrkBgtInjPuUQdKDTSMYvlXCsaR):
  (WphxrkBgtInjPuUQdKDTSMYvlXCsbG,WphxrkBgtInjPuUQdKDTSMYvlXCsbf,WphxrkBgtInjPuUQdKDTSMYvlXCsbw)=WphxrkBgtInjPuUQdKDTSMYvlXCsaR.get_settings_login_info()
  if not(WphxrkBgtInjPuUQdKDTSMYvlXCsbG and WphxrkBgtInjPuUQdKDTSMYvlXCsbf):
   WphxrkBgtInjPuUQdKDTSMYvlXCsaG=xbmcgui.Dialog()
   WphxrkBgtInjPuUQdKDTSMYvlXCsbc=WphxrkBgtInjPuUQdKDTSMYvlXCsaG.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if WphxrkBgtInjPuUQdKDTSMYvlXCsbc==WphxrkBgtInjPuUQdKDTSMYvlXCsFz:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if WphxrkBgtInjPuUQdKDTSMYvlXCsaR.get_winEpisodeOrderby()=='':
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.set_winEpisodeOrderby('desc')
  if WphxrkBgtInjPuUQdKDTSMYvlXCsaR.cookiefile_check():return
  WphxrkBgtInjPuUQdKDTSMYvlXCsbV =WphxrkBgtInjPuUQdKDTSMYvlXCsFo(WphxrkBgtInjPuUQdKDTSMYvlXCsaR.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  WphxrkBgtInjPuUQdKDTSMYvlXCsbo=xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINTIME')
  if WphxrkBgtInjPuUQdKDTSMYvlXCsbo==WphxrkBgtInjPuUQdKDTSMYvlXCsFV or WphxrkBgtInjPuUQdKDTSMYvlXCsbo=='':
   WphxrkBgtInjPuUQdKDTSMYvlXCsbo=WphxrkBgtInjPuUQdKDTSMYvlXCsFo('19000101')
  else:
   WphxrkBgtInjPuUQdKDTSMYvlXCsbo=WphxrkBgtInjPuUQdKDTSMYvlXCsFo(re.sub('-','',WphxrkBgtInjPuUQdKDTSMYvlXCsbo))
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   WphxrkBgtInjPuUQdKDTSMYvlXCsbA=0
   while WphxrkBgtInjPuUQdKDTSMYvlXCsFz:
    WphxrkBgtInjPuUQdKDTSMYvlXCsbA+=1
    time.sleep(0.05)
    if WphxrkBgtInjPuUQdKDTSMYvlXCsbo>=WphxrkBgtInjPuUQdKDTSMYvlXCsbV:return
    if WphxrkBgtInjPuUQdKDTSMYvlXCsbA>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  if WphxrkBgtInjPuUQdKDTSMYvlXCsbo>=WphxrkBgtInjPuUQdKDTSMYvlXCsbV:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   return
  if not WphxrkBgtInjPuUQdKDTSMYvlXCsaR.WavveObj.GetCredential(WphxrkBgtInjPuUQdKDTSMYvlXCsbG,WphxrkBgtInjPuUQdKDTSMYvlXCsbf,WphxrkBgtInjPuUQdKDTSMYvlXCsbw):
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   sys.exit()
  WphxrkBgtInjPuUQdKDTSMYvlXCsaR.set_winCredential(WphxrkBgtInjPuUQdKDTSMYvlXCsaR.WavveObj.LoadCredential())
  WphxrkBgtInjPuUQdKDTSMYvlXCsaR.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
 def dp_setEpOrderby(WphxrkBgtInjPuUQdKDTSMYvlXCsaR,args):
  WphxrkBgtInjPuUQdKDTSMYvlXCsbz =args.get('orderby')
  WphxrkBgtInjPuUQdKDTSMYvlXCsaR.set_winEpisodeOrderby(WphxrkBgtInjPuUQdKDTSMYvlXCsbz)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(WphxrkBgtInjPuUQdKDTSMYvlXCsaR,args):
  WphxrkBgtInjPuUQdKDTSMYvlXCsaR.WavveObj.SaveCredential(WphxrkBgtInjPuUQdKDTSMYvlXCsaR.get_winCredential())
  WphxrkBgtInjPuUQdKDTSMYvlXCsbO =args.get('mode')
  WphxrkBgtInjPuUQdKDTSMYvlXCsbm =args.get('contentid')
  WphxrkBgtInjPuUQdKDTSMYvlXCsbN =args.get('pvrmode')
  WphxrkBgtInjPuUQdKDTSMYvlXCsbL=WphxrkBgtInjPuUQdKDTSMYvlXCsaR.get_selQuality()
  WphxrkBgtInjPuUQdKDTSMYvlXCsaR.addon_log(WphxrkBgtInjPuUQdKDTSMYvlXCsbm+' - '+WphxrkBgtInjPuUQdKDTSMYvlXCsbO)
  WphxrkBgtInjPuUQdKDTSMYvlXCsea,WphxrkBgtInjPuUQdKDTSMYvlXCseb,WphxrkBgtInjPuUQdKDTSMYvlXCsey,WphxrkBgtInjPuUQdKDTSMYvlXCseF=WphxrkBgtInjPuUQdKDTSMYvlXCsaR.WavveObj.GetStreamingURL(WphxrkBgtInjPuUQdKDTSMYvlXCsbO,WphxrkBgtInjPuUQdKDTSMYvlXCsbm,WphxrkBgtInjPuUQdKDTSMYvlXCsbL,WphxrkBgtInjPuUQdKDTSMYvlXCsbN)
  WphxrkBgtInjPuUQdKDTSMYvlXCseE='%s|Cookie=%s'%(WphxrkBgtInjPuUQdKDTSMYvlXCsea,WphxrkBgtInjPuUQdKDTSMYvlXCseb)
  WphxrkBgtInjPuUQdKDTSMYvlXCsaR.addon_log(WphxrkBgtInjPuUQdKDTSMYvlXCseE)
  if WphxrkBgtInjPuUQdKDTSMYvlXCsea=='':
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.addon_noti(__language__(30907).encode('utf8'))
   return
  WphxrkBgtInjPuUQdKDTSMYvlXCseR=xbmcgui.ListItem(path=WphxrkBgtInjPuUQdKDTSMYvlXCseE)
  if WphxrkBgtInjPuUQdKDTSMYvlXCsey:
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.addon_log('!!streaming_drm!!')
   WphxrkBgtInjPuUQdKDTSMYvlXCsei=WphxrkBgtInjPuUQdKDTSMYvlXCsey['customdata']
   WphxrkBgtInjPuUQdKDTSMYvlXCseq =WphxrkBgtInjPuUQdKDTSMYvlXCsey['drmhost']
   WphxrkBgtInjPuUQdKDTSMYvlXCseH =inputstreamhelper.Helper('mpd',drm='widevine')
   if WphxrkBgtInjPuUQdKDTSMYvlXCseH.check_inputstream():
    if WphxrkBgtInjPuUQdKDTSMYvlXCsbO=='MOVIE':
     WphxrkBgtInjPuUQdKDTSMYvlXCseJ='https://www.wavve.com/player/movie?movieid=%s'%WphxrkBgtInjPuUQdKDTSMYvlXCsbm
    else:
     WphxrkBgtInjPuUQdKDTSMYvlXCseJ='https://www.wavve.com/player/vod?programid=%s&page=1'%WphxrkBgtInjPuUQdKDTSMYvlXCsbm
    WphxrkBgtInjPuUQdKDTSMYvlXCseG={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':WphxrkBgtInjPuUQdKDTSMYvlXCsei,'referer':WphxrkBgtInjPuUQdKDTSMYvlXCseJ,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':WphxrkBgtInjPuUQdKDTSMYvlXCsaR.WavveObj.USER_AGENT}
    WphxrkBgtInjPuUQdKDTSMYvlXCsef=WphxrkBgtInjPuUQdKDTSMYvlXCseq+'|'+urllib.parse.urlencode(WphxrkBgtInjPuUQdKDTSMYvlXCseG)+'|R{SSM}|'
    WphxrkBgtInjPuUQdKDTSMYvlXCseR.setProperty('inputstream',WphxrkBgtInjPuUQdKDTSMYvlXCseH.inputstream_addon)
    WphxrkBgtInjPuUQdKDTSMYvlXCseR.setProperty('inputstream.adaptive.manifest_type','mpd')
    WphxrkBgtInjPuUQdKDTSMYvlXCseR.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    WphxrkBgtInjPuUQdKDTSMYvlXCseR.setProperty('inputstream.adaptive.license_key',WphxrkBgtInjPuUQdKDTSMYvlXCsef)
    WphxrkBgtInjPuUQdKDTSMYvlXCseR.setProperty('inputstream.adaptive.stream_headers','user-agent=%s&Cookie=%s'%(WphxrkBgtInjPuUQdKDTSMYvlXCsaR.WavveObj.USER_AGENT,WphxrkBgtInjPuUQdKDTSMYvlXCseb))
  xbmcplugin.setResolvedUrl(WphxrkBgtInjPuUQdKDTSMYvlXCsaR._addon_handle,WphxrkBgtInjPuUQdKDTSMYvlXCsFz,WphxrkBgtInjPuUQdKDTSMYvlXCseR)
  WphxrkBgtInjPuUQdKDTSMYvlXCsew=WphxrkBgtInjPuUQdKDTSMYvlXCsFA
  if WphxrkBgtInjPuUQdKDTSMYvlXCseF:
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.addon_noti(WphxrkBgtInjPuUQdKDTSMYvlXCseF.encode('utf-8'))
   WphxrkBgtInjPuUQdKDTSMYvlXCsew=WphxrkBgtInjPuUQdKDTSMYvlXCsFz
  else:
   if '/preview.' in urllib.parse.urlsplit(WphxrkBgtInjPuUQdKDTSMYvlXCsea).path:
    WphxrkBgtInjPuUQdKDTSMYvlXCsaR.addon_noti(__language__(30908).encode('utf8'))
    WphxrkBgtInjPuUQdKDTSMYvlXCsew=WphxrkBgtInjPuUQdKDTSMYvlXCsFz
  try:
   WphxrkBgtInjPuUQdKDTSMYvlXCsec=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and WphxrkBgtInjPuUQdKDTSMYvlXCsew==WphxrkBgtInjPuUQdKDTSMYvlXCsFA and WphxrkBgtInjPuUQdKDTSMYvlXCsec!='-':
    WphxrkBgtInjPuUQdKDTSMYvlXCsbR={'code':WphxrkBgtInjPuUQdKDTSMYvlXCsec,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    WphxrkBgtInjPuUQdKDTSMYvlXCsaR.Save_Watched_List(args.get('mode').lower(),WphxrkBgtInjPuUQdKDTSMYvlXCsbR)
  except:
   WphxrkBgtInjPuUQdKDTSMYvlXCsFV
 def Load_Watched_List(WphxrkBgtInjPuUQdKDTSMYvlXCsaR,WphxrkBgtInjPuUQdKDTSMYvlXCsFq):
  try:
   WphxrkBgtInjPuUQdKDTSMYvlXCseV=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%WphxrkBgtInjPuUQdKDTSMYvlXCsFq))
   fp=WphxrkBgtInjPuUQdKDTSMYvlXCsFL(WphxrkBgtInjPuUQdKDTSMYvlXCseV,'r',-1,'utf-8')
   WphxrkBgtInjPuUQdKDTSMYvlXCseo=fp.readlines()
   fp.close()
  except:
   WphxrkBgtInjPuUQdKDTSMYvlXCseo=[]
  return WphxrkBgtInjPuUQdKDTSMYvlXCseo
 def Save_Watched_List(WphxrkBgtInjPuUQdKDTSMYvlXCsaR,WphxrkBgtInjPuUQdKDTSMYvlXCsFq,WphxrkBgtInjPuUQdKDTSMYvlXCsaH):
  try:
   WphxrkBgtInjPuUQdKDTSMYvlXCseV=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%WphxrkBgtInjPuUQdKDTSMYvlXCsFq))
   WphxrkBgtInjPuUQdKDTSMYvlXCseA=WphxrkBgtInjPuUQdKDTSMYvlXCsaR.Load_Watched_List(WphxrkBgtInjPuUQdKDTSMYvlXCsFq) 
   fp=WphxrkBgtInjPuUQdKDTSMYvlXCsFL(WphxrkBgtInjPuUQdKDTSMYvlXCseV,'w',-1,'utf-8')
   WphxrkBgtInjPuUQdKDTSMYvlXCsez=urllib.parse.urlencode(WphxrkBgtInjPuUQdKDTSMYvlXCsaH)
   WphxrkBgtInjPuUQdKDTSMYvlXCsez=WphxrkBgtInjPuUQdKDTSMYvlXCsez+'\n'
   fp.write(WphxrkBgtInjPuUQdKDTSMYvlXCsez)
   WphxrkBgtInjPuUQdKDTSMYvlXCseO=0
   for WphxrkBgtInjPuUQdKDTSMYvlXCsem in WphxrkBgtInjPuUQdKDTSMYvlXCseA:
    WphxrkBgtInjPuUQdKDTSMYvlXCseN=WphxrkBgtInjPuUQdKDTSMYvlXCsFm(urllib.parse.parse_qsl(WphxrkBgtInjPuUQdKDTSMYvlXCsem))
    WphxrkBgtInjPuUQdKDTSMYvlXCseL=WphxrkBgtInjPuUQdKDTSMYvlXCsaH.get('code').strip()
    WphxrkBgtInjPuUQdKDTSMYvlXCsya=WphxrkBgtInjPuUQdKDTSMYvlXCseN.get('code').strip()
    if WphxrkBgtInjPuUQdKDTSMYvlXCsFq=='vod' and WphxrkBgtInjPuUQdKDTSMYvlXCsaR.get_settings_direct_replay()==WphxrkBgtInjPuUQdKDTSMYvlXCsFz:
     WphxrkBgtInjPuUQdKDTSMYvlXCseL=WphxrkBgtInjPuUQdKDTSMYvlXCsaH.get('videoid').strip()
     WphxrkBgtInjPuUQdKDTSMYvlXCsya=WphxrkBgtInjPuUQdKDTSMYvlXCseN.get('videoid').strip()if WphxrkBgtInjPuUQdKDTSMYvlXCsya!=WphxrkBgtInjPuUQdKDTSMYvlXCsFV else '-'
    if WphxrkBgtInjPuUQdKDTSMYvlXCseL!=WphxrkBgtInjPuUQdKDTSMYvlXCsya:
     fp.write(WphxrkBgtInjPuUQdKDTSMYvlXCsem)
     WphxrkBgtInjPuUQdKDTSMYvlXCseO+=1
     if WphxrkBgtInjPuUQdKDTSMYvlXCseO>=50:break
   fp.close()
  except:
   WphxrkBgtInjPuUQdKDTSMYvlXCsFV
 def Delete_Watched_List(WphxrkBgtInjPuUQdKDTSMYvlXCsaR,WphxrkBgtInjPuUQdKDTSMYvlXCsFq):
  try:
   WphxrkBgtInjPuUQdKDTSMYvlXCseV=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%WphxrkBgtInjPuUQdKDTSMYvlXCsFq))
   fp=WphxrkBgtInjPuUQdKDTSMYvlXCsFL(WphxrkBgtInjPuUQdKDTSMYvlXCseV,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   WphxrkBgtInjPuUQdKDTSMYvlXCsFV
 def dp_WatchList_Delete(WphxrkBgtInjPuUQdKDTSMYvlXCsaR,args):
  WphxrkBgtInjPuUQdKDTSMYvlXCsyb=args.get('sType')
  WphxrkBgtInjPuUQdKDTSMYvlXCsaG=xbmcgui.Dialog()
  WphxrkBgtInjPuUQdKDTSMYvlXCsbc=WphxrkBgtInjPuUQdKDTSMYvlXCsaG.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if WphxrkBgtInjPuUQdKDTSMYvlXCsbc==WphxrkBgtInjPuUQdKDTSMYvlXCsFA:sys.exit()
  WphxrkBgtInjPuUQdKDTSMYvlXCsaR.Delete_Watched_List(WphxrkBgtInjPuUQdKDTSMYvlXCsyb)
  xbmc.executebuiltin("Container.Refresh")
 def logout(WphxrkBgtInjPuUQdKDTSMYvlXCsaR):
  WphxrkBgtInjPuUQdKDTSMYvlXCsaG=xbmcgui.Dialog()
  WphxrkBgtInjPuUQdKDTSMYvlXCsbc=WphxrkBgtInjPuUQdKDTSMYvlXCsaG.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if WphxrkBgtInjPuUQdKDTSMYvlXCsbc==WphxrkBgtInjPuUQdKDTSMYvlXCsFA:sys.exit()
  WphxrkBgtInjPuUQdKDTSMYvlXCsaR.wininfo_clear()
  if os.path.isfile(WphxrkBgtInjPuUQdKDTSMYvlXCsaE):os.remove(WphxrkBgtInjPuUQdKDTSMYvlXCsaE)
  WphxrkBgtInjPuUQdKDTSMYvlXCsaR.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(WphxrkBgtInjPuUQdKDTSMYvlXCsaR):
  WphxrkBgtInjPuUQdKDTSMYvlXCsaL=xbmcgui.Window(10000)
  WphxrkBgtInjPuUQdKDTSMYvlXCsaL.setProperty('WAVVE_M_CREDENTIAL','')
  WphxrkBgtInjPuUQdKDTSMYvlXCsaL.setProperty('WAVVE_M_LOGINTIME','')
 def cookiefile_save(WphxrkBgtInjPuUQdKDTSMYvlXCsaR):
  WphxrkBgtInjPuUQdKDTSMYvlXCsye =WphxrkBgtInjPuUQdKDTSMYvlXCsaR.WavveObj.Get_Now_Datetime()
  WphxrkBgtInjPuUQdKDTSMYvlXCsyF=WphxrkBgtInjPuUQdKDTSMYvlXCsye+datetime.timedelta(days=WphxrkBgtInjPuUQdKDTSMYvlXCsFo(__addon__.getSetting('cache_ttl')))
  WphxrkBgtInjPuUQdKDTSMYvlXCsaL=xbmcgui.Window(10000)
  WphxrkBgtInjPuUQdKDTSMYvlXCsyE={'wavve_token':WphxrkBgtInjPuUQdKDTSMYvlXCsaL.getProperty('WAVVE_M_CREDENTIAL'),'wavve_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'wavve_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'wavve_profile':__addon__.getSetting('selected_profile'),'wavve_limitdate':WphxrkBgtInjPuUQdKDTSMYvlXCsyF.strftime('%Y-%m-%d')}
  try: 
   fp=WphxrkBgtInjPuUQdKDTSMYvlXCsFL(WphxrkBgtInjPuUQdKDTSMYvlXCsaE,'w',-1,'utf-8')
   json.dump(WphxrkBgtInjPuUQdKDTSMYvlXCsyE,fp)
   fp.close()
  except WphxrkBgtInjPuUQdKDTSMYvlXCsEa as exception:
   WphxrkBgtInjPuUQdKDTSMYvlXCsEb(exception)
 def cookiefile_check(WphxrkBgtInjPuUQdKDTSMYvlXCsaR):
  WphxrkBgtInjPuUQdKDTSMYvlXCsyE={}
  try: 
   fp=WphxrkBgtInjPuUQdKDTSMYvlXCsFL(WphxrkBgtInjPuUQdKDTSMYvlXCsaE,'r',-1,'utf-8')
   WphxrkBgtInjPuUQdKDTSMYvlXCsyE= json.load(fp)
   fp.close()
  except WphxrkBgtInjPuUQdKDTSMYvlXCsEa as exception:
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.wininfo_clear()
   return WphxrkBgtInjPuUQdKDTSMYvlXCsFA
  WphxrkBgtInjPuUQdKDTSMYvlXCsbG =__addon__.getSetting('id')
  WphxrkBgtInjPuUQdKDTSMYvlXCsbf =__addon__.getSetting('pw')
  WphxrkBgtInjPuUQdKDTSMYvlXCsyR =__addon__.getSetting('selected_profile')
  WphxrkBgtInjPuUQdKDTSMYvlXCsyE['wavve_id']=base64.standard_b64decode(WphxrkBgtInjPuUQdKDTSMYvlXCsyE['wavve_id']).decode('utf-8')
  WphxrkBgtInjPuUQdKDTSMYvlXCsyE['wavve_pw']=base64.standard_b64decode(WphxrkBgtInjPuUQdKDTSMYvlXCsyE['wavve_pw']).decode('utf-8')
  if WphxrkBgtInjPuUQdKDTSMYvlXCsbG!=WphxrkBgtInjPuUQdKDTSMYvlXCsyE['wavve_id']or WphxrkBgtInjPuUQdKDTSMYvlXCsbf!=WphxrkBgtInjPuUQdKDTSMYvlXCsyE['wavve_pw']or WphxrkBgtInjPuUQdKDTSMYvlXCsyR!=WphxrkBgtInjPuUQdKDTSMYvlXCsyE['wavve_profile']:
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.wininfo_clear()
   return WphxrkBgtInjPuUQdKDTSMYvlXCsFA
  WphxrkBgtInjPuUQdKDTSMYvlXCsbV =WphxrkBgtInjPuUQdKDTSMYvlXCsFo(WphxrkBgtInjPuUQdKDTSMYvlXCsaR.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  WphxrkBgtInjPuUQdKDTSMYvlXCsyi=WphxrkBgtInjPuUQdKDTSMYvlXCsyE['wavve_limitdate']
  WphxrkBgtInjPuUQdKDTSMYvlXCsbo =WphxrkBgtInjPuUQdKDTSMYvlXCsFo(re.sub('-','',WphxrkBgtInjPuUQdKDTSMYvlXCsyi))
  if WphxrkBgtInjPuUQdKDTSMYvlXCsbo<WphxrkBgtInjPuUQdKDTSMYvlXCsbV:
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.wininfo_clear()
   return WphxrkBgtInjPuUQdKDTSMYvlXCsFA
  WphxrkBgtInjPuUQdKDTSMYvlXCsaL=xbmcgui.Window(10000)
  WphxrkBgtInjPuUQdKDTSMYvlXCsaL.setProperty('WAVVE_M_CREDENTIAL',WphxrkBgtInjPuUQdKDTSMYvlXCsyE['wavve_token'])
  WphxrkBgtInjPuUQdKDTSMYvlXCsaL.setProperty('WAVVE_M_LOGINTIME',WphxrkBgtInjPuUQdKDTSMYvlXCsyi)
  return WphxrkBgtInjPuUQdKDTSMYvlXCsFz
 def dp_LiveCatagory_List(WphxrkBgtInjPuUQdKDTSMYvlXCsaR,args):
  WphxrkBgtInjPuUQdKDTSMYvlXCsaR.WavveObj.SaveCredential(WphxrkBgtInjPuUQdKDTSMYvlXCsaR.get_winCredential())
  WphxrkBgtInjPuUQdKDTSMYvlXCsyq =args.get('sCode')
  WphxrkBgtInjPuUQdKDTSMYvlXCsyH=args.get('sIndex')
  WphxrkBgtInjPuUQdKDTSMYvlXCsyJ,WphxrkBgtInjPuUQdKDTSMYvlXCsyG=WphxrkBgtInjPuUQdKDTSMYvlXCsaR.WavveObj.Get_LiveCatagory_List(WphxrkBgtInjPuUQdKDTSMYvlXCsyq,WphxrkBgtInjPuUQdKDTSMYvlXCsyH)
  for WphxrkBgtInjPuUQdKDTSMYvlXCsyf in WphxrkBgtInjPuUQdKDTSMYvlXCsyJ:
   WphxrkBgtInjPuUQdKDTSMYvlXCsbe =WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('title')
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR={'mode':'LIVE_LIST','genre':WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('genre'),'baseapi':WphxrkBgtInjPuUQdKDTSMYvlXCsyG}
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.add_dir(WphxrkBgtInjPuUQdKDTSMYvlXCsbe,sublabel='',img='',infoLabels=WphxrkBgtInjPuUQdKDTSMYvlXCsFV,isFolder=WphxrkBgtInjPuUQdKDTSMYvlXCsFz,params=WphxrkBgtInjPuUQdKDTSMYvlXCsbR)
  if WphxrkBgtInjPuUQdKDTSMYvlXCsFN(WphxrkBgtInjPuUQdKDTSMYvlXCsyJ)>0:xbmcplugin.endOfDirectory(WphxrkBgtInjPuUQdKDTSMYvlXCsaR._addon_handle,cacheToDisc=WphxrkBgtInjPuUQdKDTSMYvlXCsFA)
 def dp_MainCatagory_List(WphxrkBgtInjPuUQdKDTSMYvlXCsaR,args):
  WphxrkBgtInjPuUQdKDTSMYvlXCsaR.WavveObj.SaveCredential(WphxrkBgtInjPuUQdKDTSMYvlXCsaR.get_winCredential())
  WphxrkBgtInjPuUQdKDTSMYvlXCsyq =args.get('sCode')
  WphxrkBgtInjPuUQdKDTSMYvlXCsyH=args.get('sIndex')
  WphxrkBgtInjPuUQdKDTSMYvlXCsyb =args.get('sType')
  WphxrkBgtInjPuUQdKDTSMYvlXCsyJ=WphxrkBgtInjPuUQdKDTSMYvlXCsaR.WavveObj.Get_MainCatagory_List(WphxrkBgtInjPuUQdKDTSMYvlXCsyq,WphxrkBgtInjPuUQdKDTSMYvlXCsyH)
  for WphxrkBgtInjPuUQdKDTSMYvlXCsyf in WphxrkBgtInjPuUQdKDTSMYvlXCsyJ:
   if WphxrkBgtInjPuUQdKDTSMYvlXCsyb=='vod':
    if WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('subtype')=='catagory':
     WphxrkBgtInjPuUQdKDTSMYvlXCsbO='PROGRAM_LIST'
    else:
     WphxrkBgtInjPuUQdKDTSMYvlXCsbO='SUPERSECTION_LIST'
   elif WphxrkBgtInjPuUQdKDTSMYvlXCsyb=='movie':
    WphxrkBgtInjPuUQdKDTSMYvlXCsbO='MOVIE_LIST'
   else:
    WphxrkBgtInjPuUQdKDTSMYvlXCsbO=''
   WphxrkBgtInjPuUQdKDTSMYvlXCsbe='%s (%s)'%(WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('title'),args.get('ordernm'))
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR={'mode':WphxrkBgtInjPuUQdKDTSMYvlXCsbO,'suburl':WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('suburl'),'subapi':WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if WphxrkBgtInjPuUQdKDTSMYvlXCsaR.get_settings_exclusion21():
    if WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('title')=='성인' or WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('title')=='성인+':continue
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.add_dir(WphxrkBgtInjPuUQdKDTSMYvlXCsbe,sublabel='',img='',infoLabels=WphxrkBgtInjPuUQdKDTSMYvlXCsFV,isFolder=WphxrkBgtInjPuUQdKDTSMYvlXCsFz,params=WphxrkBgtInjPuUQdKDTSMYvlXCsbR)
  if WphxrkBgtInjPuUQdKDTSMYvlXCsFN(WphxrkBgtInjPuUQdKDTSMYvlXCsyJ)>0:xbmcplugin.endOfDirectory(WphxrkBgtInjPuUQdKDTSMYvlXCsaR._addon_handle,cacheToDisc=WphxrkBgtInjPuUQdKDTSMYvlXCsFA)
 def dp_Program_List(WphxrkBgtInjPuUQdKDTSMYvlXCsaR,args):
  WphxrkBgtInjPuUQdKDTSMYvlXCsaR.WavveObj.SaveCredential(WphxrkBgtInjPuUQdKDTSMYvlXCsaR.get_winCredential())
  WphxrkBgtInjPuUQdKDTSMYvlXCsyw =args.get('subapi')
  WphxrkBgtInjPuUQdKDTSMYvlXCsyc=WphxrkBgtInjPuUQdKDTSMYvlXCsFo(args.get('page'))
  WphxrkBgtInjPuUQdKDTSMYvlXCsbz =args.get('orderby')
  WphxrkBgtInjPuUQdKDTSMYvlXCsyJ,WphxrkBgtInjPuUQdKDTSMYvlXCsyV=WphxrkBgtInjPuUQdKDTSMYvlXCsaR.WavveObj.Get_Program_List(WphxrkBgtInjPuUQdKDTSMYvlXCsyw,WphxrkBgtInjPuUQdKDTSMYvlXCsyc,WphxrkBgtInjPuUQdKDTSMYvlXCsbz)
  for WphxrkBgtInjPuUQdKDTSMYvlXCsyf in WphxrkBgtInjPuUQdKDTSMYvlXCsyJ:
   WphxrkBgtInjPuUQdKDTSMYvlXCsbe =WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('title')
   WphxrkBgtInjPuUQdKDTSMYvlXCsyo=WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('thumbnail')
   WphxrkBgtInjPuUQdKDTSMYvlXCsyA =WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('age')
   if WphxrkBgtInjPuUQdKDTSMYvlXCsyA=='18' or WphxrkBgtInjPuUQdKDTSMYvlXCsyA=='19' or WphxrkBgtInjPuUQdKDTSMYvlXCsyA=='21':WphxrkBgtInjPuUQdKDTSMYvlXCsbe+=' (%s)'%(WphxrkBgtInjPuUQdKDTSMYvlXCsyA)
   WphxrkBgtInjPuUQdKDTSMYvlXCsyz={'plot':WphxrkBgtInjPuUQdKDTSMYvlXCsbe,'mpaa':WphxrkBgtInjPuUQdKDTSMYvlXCsyA,'mediatype':'tvshow'}
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR={'mode':'EPISODE_LIST','videoid':WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('videoid'),'vidtype':WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('vidtype'),'page':'1'}
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.add_dir(WphxrkBgtInjPuUQdKDTSMYvlXCsbe,sublabel='',img=WphxrkBgtInjPuUQdKDTSMYvlXCsyo,infoLabels=WphxrkBgtInjPuUQdKDTSMYvlXCsyz,isFolder=WphxrkBgtInjPuUQdKDTSMYvlXCsFz,params=WphxrkBgtInjPuUQdKDTSMYvlXCsbR)
  if WphxrkBgtInjPuUQdKDTSMYvlXCsyV:
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR={}
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR['mode'] ='PROGRAM_LIST' 
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR['subapi']=WphxrkBgtInjPuUQdKDTSMYvlXCsyw 
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR['page'] =WphxrkBgtInjPuUQdKDTSMYvlXCsEe(WphxrkBgtInjPuUQdKDTSMYvlXCsyc+1)
   WphxrkBgtInjPuUQdKDTSMYvlXCsbe='[B]%s >>[/B]'%'다음 페이지'
   WphxrkBgtInjPuUQdKDTSMYvlXCsyO=WphxrkBgtInjPuUQdKDTSMYvlXCsEe(WphxrkBgtInjPuUQdKDTSMYvlXCsyc+1)
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.add_dir(WphxrkBgtInjPuUQdKDTSMYvlXCsbe,sublabel=WphxrkBgtInjPuUQdKDTSMYvlXCsyO,img='',infoLabels=WphxrkBgtInjPuUQdKDTSMYvlXCsFV,isFolder=WphxrkBgtInjPuUQdKDTSMYvlXCsFz,params=WphxrkBgtInjPuUQdKDTSMYvlXCsbR)
  if WphxrkBgtInjPuUQdKDTSMYvlXCsFN(WphxrkBgtInjPuUQdKDTSMYvlXCsyJ)>0:xbmcplugin.endOfDirectory(WphxrkBgtInjPuUQdKDTSMYvlXCsaR._addon_handle,cacheToDisc=WphxrkBgtInjPuUQdKDTSMYvlXCsFA)
 def dp_SuperSection_List(WphxrkBgtInjPuUQdKDTSMYvlXCsaR,args):
  WphxrkBgtInjPuUQdKDTSMYvlXCsaR.WavveObj.SaveCredential(WphxrkBgtInjPuUQdKDTSMYvlXCsaR.get_winCredential())
  WphxrkBgtInjPuUQdKDTSMYvlXCsym =args.get('suburl')
  WphxrkBgtInjPuUQdKDTSMYvlXCsyJ=WphxrkBgtInjPuUQdKDTSMYvlXCsaR.WavveObj.Get_SuperMultiSection_List(WphxrkBgtInjPuUQdKDTSMYvlXCsym)
  for WphxrkBgtInjPuUQdKDTSMYvlXCsyf in WphxrkBgtInjPuUQdKDTSMYvlXCsyJ:
   WphxrkBgtInjPuUQdKDTSMYvlXCsbe =WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('title')
   WphxrkBgtInjPuUQdKDTSMYvlXCsyw =WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('subapi')
   WphxrkBgtInjPuUQdKDTSMYvlXCsyN=WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('cell_type')
   if WphxrkBgtInjPuUQdKDTSMYvlXCsyw.find('mtype=svod')>=0 or WphxrkBgtInjPuUQdKDTSMYvlXCsyw.find('mtype=ppv')>=0:
    WphxrkBgtInjPuUQdKDTSMYvlXCsbO='MOVIE_LIST'
   elif WphxrkBgtInjPuUQdKDTSMYvlXCsyN=='band_71':
    WphxrkBgtInjPuUQdKDTSMYvlXCsbO ='SUPERSECTION_LIST'
    (WphxrkBgtInjPuUQdKDTSMYvlXCsyL,WphxrkBgtInjPuUQdKDTSMYvlXCsFa)=WphxrkBgtInjPuUQdKDTSMYvlXCsaR.WavveObj.Baseapi_Parse(WphxrkBgtInjPuUQdKDTSMYvlXCsyw)
    WphxrkBgtInjPuUQdKDTSMYvlXCsym=WphxrkBgtInjPuUQdKDTSMYvlXCsFa.get('api')
    WphxrkBgtInjPuUQdKDTSMYvlXCsyw=''
   elif WphxrkBgtInjPuUQdKDTSMYvlXCsyN=='band_2':
    WphxrkBgtInjPuUQdKDTSMYvlXCsbO='BAND2SECTION_LIST'
   elif WphxrkBgtInjPuUQdKDTSMYvlXCsyN=='band_live':
    WphxrkBgtInjPuUQdKDTSMYvlXCsbO='BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}',WphxrkBgtInjPuUQdKDTSMYvlXCsyw):
    WphxrkBgtInjPuUQdKDTSMYvlXCsbO='MOVIE_LIST'
   else:
    WphxrkBgtInjPuUQdKDTSMYvlXCsbO='PROGRAM_LIST'
   WphxrkBgtInjPuUQdKDTSMYvlXCsyz={'plot':WphxrkBgtInjPuUQdKDTSMYvlXCsbe,'mediatype':'tvshow'}
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR={'mode':WphxrkBgtInjPuUQdKDTSMYvlXCsbO,'suburl':WphxrkBgtInjPuUQdKDTSMYvlXCsym,'subapi':WphxrkBgtInjPuUQdKDTSMYvlXCsyw,'page':'1'}
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.add_dir(WphxrkBgtInjPuUQdKDTSMYvlXCsbe,sublabel='',img=WphxrkBgtInjPuUQdKDTSMYvlXCsFV,infoLabels=WphxrkBgtInjPuUQdKDTSMYvlXCsyz,isFolder=WphxrkBgtInjPuUQdKDTSMYvlXCsFz,params=WphxrkBgtInjPuUQdKDTSMYvlXCsbR)
  if WphxrkBgtInjPuUQdKDTSMYvlXCsFN(WphxrkBgtInjPuUQdKDTSMYvlXCsyJ)>0:xbmcplugin.endOfDirectory(WphxrkBgtInjPuUQdKDTSMYvlXCsaR._addon_handle,cacheToDisc=WphxrkBgtInjPuUQdKDTSMYvlXCsFA)
 def dp_BandLiveSection_List(WphxrkBgtInjPuUQdKDTSMYvlXCsaR,args):
  WphxrkBgtInjPuUQdKDTSMYvlXCsaR.WavveObj.SaveCredential(WphxrkBgtInjPuUQdKDTSMYvlXCsaR.get_winCredential())
  WphxrkBgtInjPuUQdKDTSMYvlXCsyw =args.get('subapi')
  WphxrkBgtInjPuUQdKDTSMYvlXCsyc=WphxrkBgtInjPuUQdKDTSMYvlXCsFo(args.get('page'))
  WphxrkBgtInjPuUQdKDTSMYvlXCsyJ,WphxrkBgtInjPuUQdKDTSMYvlXCsyV=WphxrkBgtInjPuUQdKDTSMYvlXCsaR.WavveObj.Get_BandLiveSection_List(WphxrkBgtInjPuUQdKDTSMYvlXCsyw,WphxrkBgtInjPuUQdKDTSMYvlXCsyc)
  for WphxrkBgtInjPuUQdKDTSMYvlXCsyf in WphxrkBgtInjPuUQdKDTSMYvlXCsyJ:
   WphxrkBgtInjPuUQdKDTSMYvlXCsFb =WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('channelid')
   WphxrkBgtInjPuUQdKDTSMYvlXCsFe =WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('studio')
   WphxrkBgtInjPuUQdKDTSMYvlXCsFy=WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('tvshowtitle')
   WphxrkBgtInjPuUQdKDTSMYvlXCsyo =WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('thumbnail')
   WphxrkBgtInjPuUQdKDTSMYvlXCsyA =WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('age')
   WphxrkBgtInjPuUQdKDTSMYvlXCsyz={'mediatype':'tvshow','mpaa':WphxrkBgtInjPuUQdKDTSMYvlXCsyA,'title':'%s < %s >'%(WphxrkBgtInjPuUQdKDTSMYvlXCsFe,WphxrkBgtInjPuUQdKDTSMYvlXCsFy),'tvshowtitle':WphxrkBgtInjPuUQdKDTSMYvlXCsFy,'studio':WphxrkBgtInjPuUQdKDTSMYvlXCsFe,'plot':WphxrkBgtInjPuUQdKDTSMYvlXCsFe}
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR={'mode':'LIVE','contentid':WphxrkBgtInjPuUQdKDTSMYvlXCsFb}
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.add_dir(WphxrkBgtInjPuUQdKDTSMYvlXCsFe,sublabel=WphxrkBgtInjPuUQdKDTSMYvlXCsFy,img=WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('thumbnail'),infoLabels=WphxrkBgtInjPuUQdKDTSMYvlXCsyz,isFolder=WphxrkBgtInjPuUQdKDTSMYvlXCsFA,params=WphxrkBgtInjPuUQdKDTSMYvlXCsbR)
  if WphxrkBgtInjPuUQdKDTSMYvlXCsyV:
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR={}
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR['mode'] ='BANDLIVESECTION_LIST' 
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR['subapi']=WphxrkBgtInjPuUQdKDTSMYvlXCsyw
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR['page'] =WphxrkBgtInjPuUQdKDTSMYvlXCsEe(WphxrkBgtInjPuUQdKDTSMYvlXCsyc+1)
   WphxrkBgtInjPuUQdKDTSMYvlXCsbe='[B]%s >>[/B]'%'다음 페이지'
   WphxrkBgtInjPuUQdKDTSMYvlXCsyO=WphxrkBgtInjPuUQdKDTSMYvlXCsEe(WphxrkBgtInjPuUQdKDTSMYvlXCsyc+1)
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.add_dir(WphxrkBgtInjPuUQdKDTSMYvlXCsbe,sublabel=WphxrkBgtInjPuUQdKDTSMYvlXCsyO,img='',infoLabels=WphxrkBgtInjPuUQdKDTSMYvlXCsFV,isFolder=WphxrkBgtInjPuUQdKDTSMYvlXCsFz,params=WphxrkBgtInjPuUQdKDTSMYvlXCsbR)
  if WphxrkBgtInjPuUQdKDTSMYvlXCsFN(WphxrkBgtInjPuUQdKDTSMYvlXCsyJ)>0:xbmcplugin.endOfDirectory(WphxrkBgtInjPuUQdKDTSMYvlXCsaR._addon_handle,cacheToDisc=WphxrkBgtInjPuUQdKDTSMYvlXCsFA)
 def dp_Band2Section_List(WphxrkBgtInjPuUQdKDTSMYvlXCsaR,args):
  WphxrkBgtInjPuUQdKDTSMYvlXCsaR.WavveObj.SaveCredential(WphxrkBgtInjPuUQdKDTSMYvlXCsaR.get_winCredential())
  WphxrkBgtInjPuUQdKDTSMYvlXCsyw =args.get('subapi')
  WphxrkBgtInjPuUQdKDTSMYvlXCsyc=WphxrkBgtInjPuUQdKDTSMYvlXCsFo(args.get('page'))
  WphxrkBgtInjPuUQdKDTSMYvlXCsyJ,WphxrkBgtInjPuUQdKDTSMYvlXCsyV=WphxrkBgtInjPuUQdKDTSMYvlXCsaR.WavveObj.Get_Band2Section_List(WphxrkBgtInjPuUQdKDTSMYvlXCsyw,WphxrkBgtInjPuUQdKDTSMYvlXCsyc)
  for WphxrkBgtInjPuUQdKDTSMYvlXCsyf in WphxrkBgtInjPuUQdKDTSMYvlXCsyJ:
   WphxrkBgtInjPuUQdKDTSMYvlXCsbe =WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('programtitle')
   WphxrkBgtInjPuUQdKDTSMYvlXCsyO =WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('episodetitle')
   WphxrkBgtInjPuUQdKDTSMYvlXCsyz={'plot':WphxrkBgtInjPuUQdKDTSMYvlXCsbe+'\n\n'+WphxrkBgtInjPuUQdKDTSMYvlXCsyO,'mpaa':WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('age'),'mediatype':'episode'}
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR={'mode':'VOD','programid':'-','contentid':WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('videoid'),'thumbnail':WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('thumbnail'),'title':WphxrkBgtInjPuUQdKDTSMYvlXCsbe,'subtitle':WphxrkBgtInjPuUQdKDTSMYvlXCsyO}
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.add_dir(WphxrkBgtInjPuUQdKDTSMYvlXCsbe,sublabel=WphxrkBgtInjPuUQdKDTSMYvlXCsyO,img=WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('thumbnail'),infoLabels=WphxrkBgtInjPuUQdKDTSMYvlXCsyz,isFolder=WphxrkBgtInjPuUQdKDTSMYvlXCsFA,params=WphxrkBgtInjPuUQdKDTSMYvlXCsbR)
  if WphxrkBgtInjPuUQdKDTSMYvlXCsyV:
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR={}
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR['mode'] ='BAND2SECTION_LIST' 
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR['subapi']=WphxrkBgtInjPuUQdKDTSMYvlXCsyw
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR['page'] =WphxrkBgtInjPuUQdKDTSMYvlXCsEe(WphxrkBgtInjPuUQdKDTSMYvlXCsyc+1)
   WphxrkBgtInjPuUQdKDTSMYvlXCsbe='[B]%s >>[/B]'%'다음 페이지'
   WphxrkBgtInjPuUQdKDTSMYvlXCsyO=WphxrkBgtInjPuUQdKDTSMYvlXCsEe(WphxrkBgtInjPuUQdKDTSMYvlXCsyc+1)
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.add_dir(WphxrkBgtInjPuUQdKDTSMYvlXCsbe,sublabel=WphxrkBgtInjPuUQdKDTSMYvlXCsyO,img='',infoLabels=WphxrkBgtInjPuUQdKDTSMYvlXCsFV,isFolder=WphxrkBgtInjPuUQdKDTSMYvlXCsFz,params=WphxrkBgtInjPuUQdKDTSMYvlXCsbR)
  if WphxrkBgtInjPuUQdKDTSMYvlXCsFN(WphxrkBgtInjPuUQdKDTSMYvlXCsyJ)>0:xbmcplugin.endOfDirectory(WphxrkBgtInjPuUQdKDTSMYvlXCsaR._addon_handle,cacheToDisc=WphxrkBgtInjPuUQdKDTSMYvlXCsFA)
 def dp_Movie_List(WphxrkBgtInjPuUQdKDTSMYvlXCsaR,args):
  WphxrkBgtInjPuUQdKDTSMYvlXCsaR.WavveObj.SaveCredential(WphxrkBgtInjPuUQdKDTSMYvlXCsaR.get_winCredential())
  WphxrkBgtInjPuUQdKDTSMYvlXCsyw =args.get('subapi')
  WphxrkBgtInjPuUQdKDTSMYvlXCsyc=WphxrkBgtInjPuUQdKDTSMYvlXCsFo(args.get('page'))
  WphxrkBgtInjPuUQdKDTSMYvlXCsyJ,WphxrkBgtInjPuUQdKDTSMYvlXCsyV=WphxrkBgtInjPuUQdKDTSMYvlXCsaR.WavveObj.Get_Movie_List(WphxrkBgtInjPuUQdKDTSMYvlXCsyw,WphxrkBgtInjPuUQdKDTSMYvlXCsyc)
  for WphxrkBgtInjPuUQdKDTSMYvlXCsyf in WphxrkBgtInjPuUQdKDTSMYvlXCsyJ:
   WphxrkBgtInjPuUQdKDTSMYvlXCsbe =WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('title')
   WphxrkBgtInjPuUQdKDTSMYvlXCsyo=WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('thumbnail')
   WphxrkBgtInjPuUQdKDTSMYvlXCsyA =WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('age')
   if WphxrkBgtInjPuUQdKDTSMYvlXCsyA=='18' or WphxrkBgtInjPuUQdKDTSMYvlXCsyA=='19' or WphxrkBgtInjPuUQdKDTSMYvlXCsyA=='21':WphxrkBgtInjPuUQdKDTSMYvlXCsbe+=' (%s)'%(WphxrkBgtInjPuUQdKDTSMYvlXCsyA)
   WphxrkBgtInjPuUQdKDTSMYvlXCsyz={'plot':WphxrkBgtInjPuUQdKDTSMYvlXCsbe,'mpaa':WphxrkBgtInjPuUQdKDTSMYvlXCsyA,'mediatype':'movie'}
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR={'mode':'MOVIE','contentid':WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('videoid'),'title':WphxrkBgtInjPuUQdKDTSMYvlXCsbe,'thumbnail':WphxrkBgtInjPuUQdKDTSMYvlXCsyo,'age':WphxrkBgtInjPuUQdKDTSMYvlXCsyA}
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.add_dir(WphxrkBgtInjPuUQdKDTSMYvlXCsbe,sublabel='',img=WphxrkBgtInjPuUQdKDTSMYvlXCsyo,infoLabels=WphxrkBgtInjPuUQdKDTSMYvlXCsyz,isFolder=WphxrkBgtInjPuUQdKDTSMYvlXCsFA,params=WphxrkBgtInjPuUQdKDTSMYvlXCsbR)
  if WphxrkBgtInjPuUQdKDTSMYvlXCsyV:
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR={}
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR['mode'] ='MOVIE_LIST' 
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR['subapi']=WphxrkBgtInjPuUQdKDTSMYvlXCsyw 
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR['page'] =WphxrkBgtInjPuUQdKDTSMYvlXCsEe(WphxrkBgtInjPuUQdKDTSMYvlXCsyc+1)
   WphxrkBgtInjPuUQdKDTSMYvlXCsbe='[B]%s >>[/B]'%'다음 페이지'
   WphxrkBgtInjPuUQdKDTSMYvlXCsyO=WphxrkBgtInjPuUQdKDTSMYvlXCsEe(WphxrkBgtInjPuUQdKDTSMYvlXCsyc+1)
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.add_dir(WphxrkBgtInjPuUQdKDTSMYvlXCsbe,sublabel=WphxrkBgtInjPuUQdKDTSMYvlXCsyO,img='',infoLabels=WphxrkBgtInjPuUQdKDTSMYvlXCsFV,isFolder=WphxrkBgtInjPuUQdKDTSMYvlXCsFz,params=WphxrkBgtInjPuUQdKDTSMYvlXCsbR)
  if WphxrkBgtInjPuUQdKDTSMYvlXCsFN(WphxrkBgtInjPuUQdKDTSMYvlXCsyJ)>0:xbmcplugin.endOfDirectory(WphxrkBgtInjPuUQdKDTSMYvlXCsaR._addon_handle,cacheToDisc=WphxrkBgtInjPuUQdKDTSMYvlXCsFA)
 def dp_Episode_List(WphxrkBgtInjPuUQdKDTSMYvlXCsaR,args):
  WphxrkBgtInjPuUQdKDTSMYvlXCsaR.WavveObj.SaveCredential(WphxrkBgtInjPuUQdKDTSMYvlXCsaR.get_winCredential())
  WphxrkBgtInjPuUQdKDTSMYvlXCsFE =args.get('videoid')
  WphxrkBgtInjPuUQdKDTSMYvlXCsFR =args.get('vidtype')
  WphxrkBgtInjPuUQdKDTSMYvlXCsyc=WphxrkBgtInjPuUQdKDTSMYvlXCsFo(args.get('page'))
  WphxrkBgtInjPuUQdKDTSMYvlXCsyJ,WphxrkBgtInjPuUQdKDTSMYvlXCsyV=WphxrkBgtInjPuUQdKDTSMYvlXCsaR.WavveObj.Get_Episode_List(WphxrkBgtInjPuUQdKDTSMYvlXCsFE,WphxrkBgtInjPuUQdKDTSMYvlXCsFR,WphxrkBgtInjPuUQdKDTSMYvlXCsyc,orderby=WphxrkBgtInjPuUQdKDTSMYvlXCsaR.get_winEpisodeOrderby())
  for WphxrkBgtInjPuUQdKDTSMYvlXCsyf in WphxrkBgtInjPuUQdKDTSMYvlXCsyJ:
   WphxrkBgtInjPuUQdKDTSMYvlXCsyO='%s회, %s(%s)'%(WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('episodenumber'),WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('releasedate'),WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('releaseweekday'))
   WphxrkBgtInjPuUQdKDTSMYvlXCsFi ='[%s]\n\n%s'%(WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('episodetitle'),WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('synopsis'))
   WphxrkBgtInjPuUQdKDTSMYvlXCsyz={'mediatype':'episode','title':WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('programtitle'),'year':WphxrkBgtInjPuUQdKDTSMYvlXCsFo(WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('releasedate')[:4]),'aired':WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('releasedate'),'mpaa':WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('age'),'episode':WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('episodenumber'),'duration':WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('playtime'),'plot':WphxrkBgtInjPuUQdKDTSMYvlXCsFi,'cast':WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('episodeactors')}
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR={'mode':'VOD','programid':WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('programid'),'contentid':WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('contentid'),'thumbnail':WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('thumbnail'),'title':WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('programtitle'),'subtitle':WphxrkBgtInjPuUQdKDTSMYvlXCsyO}
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.add_dir(WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('programtitle'),sublabel=WphxrkBgtInjPuUQdKDTSMYvlXCsyO,img=WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('thumbnail'),infoLabels=WphxrkBgtInjPuUQdKDTSMYvlXCsyz,isFolder=WphxrkBgtInjPuUQdKDTSMYvlXCsFA,params=WphxrkBgtInjPuUQdKDTSMYvlXCsbR)
  if WphxrkBgtInjPuUQdKDTSMYvlXCsyc==1:
   WphxrkBgtInjPuUQdKDTSMYvlXCsyz={'plot':'정렬순서를 변경합니다.'}
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR={}
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR['mode'] ='ORDER_BY' 
   if WphxrkBgtInjPuUQdKDTSMYvlXCsaR.get_winEpisodeOrderby()=='desc':
    WphxrkBgtInjPuUQdKDTSMYvlXCsbe='정렬순서변경 : 최신화부터 -> 1회부터'
    WphxrkBgtInjPuUQdKDTSMYvlXCsbR['orderby']='asc'
   else:
    WphxrkBgtInjPuUQdKDTSMYvlXCsbe='정렬순서변경 : 1회부터 -> 최신화부터'
    WphxrkBgtInjPuUQdKDTSMYvlXCsbR['orderby']='desc'
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.add_dir(WphxrkBgtInjPuUQdKDTSMYvlXCsbe,sublabel='',img='',infoLabels=WphxrkBgtInjPuUQdKDTSMYvlXCsyz,isFolder=WphxrkBgtInjPuUQdKDTSMYvlXCsFA,params=WphxrkBgtInjPuUQdKDTSMYvlXCsbR)
  if WphxrkBgtInjPuUQdKDTSMYvlXCsyV:
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR={}
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR['mode'] ='EPISODE_LIST' 
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR['videoid']=WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('programid')
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR['vidtype']='programid'
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR['page'] =WphxrkBgtInjPuUQdKDTSMYvlXCsEe(WphxrkBgtInjPuUQdKDTSMYvlXCsyc+1)
   WphxrkBgtInjPuUQdKDTSMYvlXCsbe='[B]%s >>[/B]'%'다음 페이지'
   WphxrkBgtInjPuUQdKDTSMYvlXCsyO=WphxrkBgtInjPuUQdKDTSMYvlXCsEe(WphxrkBgtInjPuUQdKDTSMYvlXCsyc+1)
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.add_dir(WphxrkBgtInjPuUQdKDTSMYvlXCsbe,sublabel=WphxrkBgtInjPuUQdKDTSMYvlXCsyO,img='',infoLabels=WphxrkBgtInjPuUQdKDTSMYvlXCsFV,isFolder=WphxrkBgtInjPuUQdKDTSMYvlXCsFz,params=WphxrkBgtInjPuUQdKDTSMYvlXCsbR)
  if WphxrkBgtInjPuUQdKDTSMYvlXCsFN(WphxrkBgtInjPuUQdKDTSMYvlXCsyJ)>0:xbmcplugin.endOfDirectory(WphxrkBgtInjPuUQdKDTSMYvlXCsaR._addon_handle,cacheToDisc=WphxrkBgtInjPuUQdKDTSMYvlXCsFA)
 def dp_LiveChannel_List(WphxrkBgtInjPuUQdKDTSMYvlXCsaR,args):
  WphxrkBgtInjPuUQdKDTSMYvlXCsaR.WavveObj.SaveCredential(WphxrkBgtInjPuUQdKDTSMYvlXCsaR.get_winCredential())
  WphxrkBgtInjPuUQdKDTSMYvlXCsFq =args.get('genre')
  WphxrkBgtInjPuUQdKDTSMYvlXCsyG=args.get('baseapi')
  WphxrkBgtInjPuUQdKDTSMYvlXCsyJ=WphxrkBgtInjPuUQdKDTSMYvlXCsaR.WavveObj.Get_LiveChannel_List(WphxrkBgtInjPuUQdKDTSMYvlXCsFq,WphxrkBgtInjPuUQdKDTSMYvlXCsyG)
  for WphxrkBgtInjPuUQdKDTSMYvlXCsyf in WphxrkBgtInjPuUQdKDTSMYvlXCsyJ:
   WphxrkBgtInjPuUQdKDTSMYvlXCsFb =WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('channelid')
   WphxrkBgtInjPuUQdKDTSMYvlXCsFe =WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('studio')
   WphxrkBgtInjPuUQdKDTSMYvlXCsFy=WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('tvshowtitle')
   WphxrkBgtInjPuUQdKDTSMYvlXCsyo =WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('thumbnail')
   WphxrkBgtInjPuUQdKDTSMYvlXCsyA =WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('age')
   WphxrkBgtInjPuUQdKDTSMYvlXCsFH =WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('epg')
   WphxrkBgtInjPuUQdKDTSMYvlXCsyz={'mediatype':'episode','mpaa':WphxrkBgtInjPuUQdKDTSMYvlXCsyA,'title':'%s < %s >'%(WphxrkBgtInjPuUQdKDTSMYvlXCsFe,WphxrkBgtInjPuUQdKDTSMYvlXCsFy),'tvshowtitle':WphxrkBgtInjPuUQdKDTSMYvlXCsFy,'studio':WphxrkBgtInjPuUQdKDTSMYvlXCsFe,'plot':'%s\n\n%s'%(WphxrkBgtInjPuUQdKDTSMYvlXCsFe,WphxrkBgtInjPuUQdKDTSMYvlXCsFH)}
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR={'mode':'LIVE','contentid':WphxrkBgtInjPuUQdKDTSMYvlXCsFb}
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.add_dir(WphxrkBgtInjPuUQdKDTSMYvlXCsFe,sublabel=WphxrkBgtInjPuUQdKDTSMYvlXCsFy,img=WphxrkBgtInjPuUQdKDTSMYvlXCsyo,infoLabels=WphxrkBgtInjPuUQdKDTSMYvlXCsyz,isFolder=WphxrkBgtInjPuUQdKDTSMYvlXCsFA,params=WphxrkBgtInjPuUQdKDTSMYvlXCsbR)
  if WphxrkBgtInjPuUQdKDTSMYvlXCsFN(WphxrkBgtInjPuUQdKDTSMYvlXCsyJ)>0:xbmcplugin.endOfDirectory(WphxrkBgtInjPuUQdKDTSMYvlXCsaR._addon_handle,cacheToDisc=WphxrkBgtInjPuUQdKDTSMYvlXCsFA)
 def dp_Search_List(WphxrkBgtInjPuUQdKDTSMYvlXCsaR,args):
  WphxrkBgtInjPuUQdKDTSMYvlXCsaR.WavveObj.SaveCredential(WphxrkBgtInjPuUQdKDTSMYvlXCsaR.get_winCredential())
  WphxrkBgtInjPuUQdKDTSMYvlXCsyb =args.get('sType')
  WphxrkBgtInjPuUQdKDTSMYvlXCsyc =WphxrkBgtInjPuUQdKDTSMYvlXCsFo(args.get('page'))
  if 'search_key' in args:
   WphxrkBgtInjPuUQdKDTSMYvlXCsFJ=args.get('search_key')
  else:
   WphxrkBgtInjPuUQdKDTSMYvlXCsFJ=WphxrkBgtInjPuUQdKDTSMYvlXCsaR.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not WphxrkBgtInjPuUQdKDTSMYvlXCsFJ:return
  WphxrkBgtInjPuUQdKDTSMYvlXCsyJ,WphxrkBgtInjPuUQdKDTSMYvlXCsyV=WphxrkBgtInjPuUQdKDTSMYvlXCsaR.WavveObj.Get_Search_List(WphxrkBgtInjPuUQdKDTSMYvlXCsFJ,WphxrkBgtInjPuUQdKDTSMYvlXCsyb,WphxrkBgtInjPuUQdKDTSMYvlXCsyc,exclusion21=WphxrkBgtInjPuUQdKDTSMYvlXCsaR.get_settings_exclusion21())
  for WphxrkBgtInjPuUQdKDTSMYvlXCsyf in WphxrkBgtInjPuUQdKDTSMYvlXCsyJ:
   WphxrkBgtInjPuUQdKDTSMYvlXCsbe =WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('title')
   WphxrkBgtInjPuUQdKDTSMYvlXCsyo=WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('thumbnail')
   WphxrkBgtInjPuUQdKDTSMYvlXCsyA =WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('age')
   if WphxrkBgtInjPuUQdKDTSMYvlXCsyA=='18' or WphxrkBgtInjPuUQdKDTSMYvlXCsyA=='19' or WphxrkBgtInjPuUQdKDTSMYvlXCsyA=='21':WphxrkBgtInjPuUQdKDTSMYvlXCsbe+=' (%s)'%(WphxrkBgtInjPuUQdKDTSMYvlXCsyA)
   WphxrkBgtInjPuUQdKDTSMYvlXCsyz={'mediatype':'tvshow' if WphxrkBgtInjPuUQdKDTSMYvlXCsyb=='vod' else 'movie','mpaa':WphxrkBgtInjPuUQdKDTSMYvlXCsyA,'title':WphxrkBgtInjPuUQdKDTSMYvlXCsbe,'plot':WphxrkBgtInjPuUQdKDTSMYvlXCsbe}
   if WphxrkBgtInjPuUQdKDTSMYvlXCsyb=='vod':
    WphxrkBgtInjPuUQdKDTSMYvlXCsbR={'mode':'EPISODE_LIST','videoid':WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('videoid'),'vidtype':WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('vidtype'),'page':'1'}
    WphxrkBgtInjPuUQdKDTSMYvlXCsbi=WphxrkBgtInjPuUQdKDTSMYvlXCsFz
   else:
    WphxrkBgtInjPuUQdKDTSMYvlXCsbR={'mode':'MOVIE','contentid':WphxrkBgtInjPuUQdKDTSMYvlXCsyf.get('videoid'),'title':WphxrkBgtInjPuUQdKDTSMYvlXCsbe,'thumbnail':WphxrkBgtInjPuUQdKDTSMYvlXCsyo,'age':WphxrkBgtInjPuUQdKDTSMYvlXCsyA}
    WphxrkBgtInjPuUQdKDTSMYvlXCsbi=WphxrkBgtInjPuUQdKDTSMYvlXCsFA
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.add_dir(WphxrkBgtInjPuUQdKDTSMYvlXCsbe,sublabel='',img=WphxrkBgtInjPuUQdKDTSMYvlXCsyo,infoLabels=WphxrkBgtInjPuUQdKDTSMYvlXCsyz,isFolder=WphxrkBgtInjPuUQdKDTSMYvlXCsbi,params=WphxrkBgtInjPuUQdKDTSMYvlXCsbR)
  if WphxrkBgtInjPuUQdKDTSMYvlXCsyV:
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR['mode'] ='SEARCH_LIST' 
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR['sType']=WphxrkBgtInjPuUQdKDTSMYvlXCsyb 
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR['page'] =WphxrkBgtInjPuUQdKDTSMYvlXCsEe(WphxrkBgtInjPuUQdKDTSMYvlXCsyc+1)
   WphxrkBgtInjPuUQdKDTSMYvlXCsbR['search_key']=WphxrkBgtInjPuUQdKDTSMYvlXCsFJ
   WphxrkBgtInjPuUQdKDTSMYvlXCsbe='[B]%s >>[/B]'%'다음 페이지'
   WphxrkBgtInjPuUQdKDTSMYvlXCsyO=WphxrkBgtInjPuUQdKDTSMYvlXCsEe(WphxrkBgtInjPuUQdKDTSMYvlXCsyc+1)
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.add_dir(WphxrkBgtInjPuUQdKDTSMYvlXCsbe,sublabel=WphxrkBgtInjPuUQdKDTSMYvlXCsyO,img='',infoLabels=WphxrkBgtInjPuUQdKDTSMYvlXCsFV,isFolder=WphxrkBgtInjPuUQdKDTSMYvlXCsFz,params=WphxrkBgtInjPuUQdKDTSMYvlXCsbR)
  if WphxrkBgtInjPuUQdKDTSMYvlXCsFN(WphxrkBgtInjPuUQdKDTSMYvlXCsyJ)>0:xbmcplugin.endOfDirectory(WphxrkBgtInjPuUQdKDTSMYvlXCsaR._addon_handle)
 def dp_Watch_List(WphxrkBgtInjPuUQdKDTSMYvlXCsaR,args):
  WphxrkBgtInjPuUQdKDTSMYvlXCsyb =args.get('sType')
  WphxrkBgtInjPuUQdKDTSMYvlXCsaN=WphxrkBgtInjPuUQdKDTSMYvlXCsaR.get_settings_direct_replay()
  WphxrkBgtInjPuUQdKDTSMYvlXCsyJ=WphxrkBgtInjPuUQdKDTSMYvlXCsaR.Load_Watched_List(WphxrkBgtInjPuUQdKDTSMYvlXCsyb)
  for WphxrkBgtInjPuUQdKDTSMYvlXCsyf in WphxrkBgtInjPuUQdKDTSMYvlXCsyJ:
   WphxrkBgtInjPuUQdKDTSMYvlXCsFG=WphxrkBgtInjPuUQdKDTSMYvlXCsFm(urllib.parse.parse_qsl(WphxrkBgtInjPuUQdKDTSMYvlXCsyf))
   WphxrkBgtInjPuUQdKDTSMYvlXCsFf =WphxrkBgtInjPuUQdKDTSMYvlXCsFG.get('code').strip()
   WphxrkBgtInjPuUQdKDTSMYvlXCsbe =WphxrkBgtInjPuUQdKDTSMYvlXCsFG.get('title').strip()
   WphxrkBgtInjPuUQdKDTSMYvlXCsyO =WphxrkBgtInjPuUQdKDTSMYvlXCsFG.get('subtitle').strip()
   if WphxrkBgtInjPuUQdKDTSMYvlXCsyO=='None':WphxrkBgtInjPuUQdKDTSMYvlXCsyO=''
   WphxrkBgtInjPuUQdKDTSMYvlXCsyo=WphxrkBgtInjPuUQdKDTSMYvlXCsFG.get('img').strip()
   WphxrkBgtInjPuUQdKDTSMYvlXCsFE =WphxrkBgtInjPuUQdKDTSMYvlXCsFG.get('videoid').strip()
   try:
    WphxrkBgtInjPuUQdKDTSMYvlXCsyo=WphxrkBgtInjPuUQdKDTSMYvlXCsyo.replace('\'','\"')
    WphxrkBgtInjPuUQdKDTSMYvlXCsyo=json.loads(WphxrkBgtInjPuUQdKDTSMYvlXCsyo)
   except:
    WphxrkBgtInjPuUQdKDTSMYvlXCsFV
   WphxrkBgtInjPuUQdKDTSMYvlXCsyz={'plot':'%s\n%s'%(WphxrkBgtInjPuUQdKDTSMYvlXCsbe,WphxrkBgtInjPuUQdKDTSMYvlXCsyO)}
   if WphxrkBgtInjPuUQdKDTSMYvlXCsyb=='vod':
    if WphxrkBgtInjPuUQdKDTSMYvlXCsaN==WphxrkBgtInjPuUQdKDTSMYvlXCsFA or WphxrkBgtInjPuUQdKDTSMYvlXCsFE==WphxrkBgtInjPuUQdKDTSMYvlXCsFV:
     WphxrkBgtInjPuUQdKDTSMYvlXCsbR={'mode':'EPISODE_LIST','videoid':WphxrkBgtInjPuUQdKDTSMYvlXCsFf,'vidtype':'programid','page':'1'}
     WphxrkBgtInjPuUQdKDTSMYvlXCsbi=WphxrkBgtInjPuUQdKDTSMYvlXCsFz
    else:
     WphxrkBgtInjPuUQdKDTSMYvlXCsbR={'mode':'VOD','programid':WphxrkBgtInjPuUQdKDTSMYvlXCsFf,'contentid':WphxrkBgtInjPuUQdKDTSMYvlXCsFE,'title':WphxrkBgtInjPuUQdKDTSMYvlXCsbe,'subtitle':WphxrkBgtInjPuUQdKDTSMYvlXCsyO,'thumbnail':WphxrkBgtInjPuUQdKDTSMYvlXCsyo}
     WphxrkBgtInjPuUQdKDTSMYvlXCsbi=WphxrkBgtInjPuUQdKDTSMYvlXCsFA
   else:
    WphxrkBgtInjPuUQdKDTSMYvlXCsbR={'mode':'MOVIE','contentid':WphxrkBgtInjPuUQdKDTSMYvlXCsFf,'title':WphxrkBgtInjPuUQdKDTSMYvlXCsbe,'subtitle':WphxrkBgtInjPuUQdKDTSMYvlXCsyO,'thumbnail':WphxrkBgtInjPuUQdKDTSMYvlXCsyo}
    WphxrkBgtInjPuUQdKDTSMYvlXCsbi=WphxrkBgtInjPuUQdKDTSMYvlXCsFA
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.add_dir(WphxrkBgtInjPuUQdKDTSMYvlXCsbe,sublabel=WphxrkBgtInjPuUQdKDTSMYvlXCsyO,img=WphxrkBgtInjPuUQdKDTSMYvlXCsyo,infoLabels=WphxrkBgtInjPuUQdKDTSMYvlXCsyz,isFolder=WphxrkBgtInjPuUQdKDTSMYvlXCsbi,params=WphxrkBgtInjPuUQdKDTSMYvlXCsbR)
  WphxrkBgtInjPuUQdKDTSMYvlXCsyz={'plot':'시청목록을 삭제합니다.'}
  WphxrkBgtInjPuUQdKDTSMYvlXCsbe='*** 시청목록 삭제 ***'
  WphxrkBgtInjPuUQdKDTSMYvlXCsbR={'mode':'MYVIEW_REMOVE','sType':WphxrkBgtInjPuUQdKDTSMYvlXCsyb}
  WphxrkBgtInjPuUQdKDTSMYvlXCsaR.add_dir(WphxrkBgtInjPuUQdKDTSMYvlXCsbe,sublabel='',img='',infoLabels=WphxrkBgtInjPuUQdKDTSMYvlXCsyz,isFolder=WphxrkBgtInjPuUQdKDTSMYvlXCsFA,params=WphxrkBgtInjPuUQdKDTSMYvlXCsbR)
  xbmcplugin.endOfDirectory(WphxrkBgtInjPuUQdKDTSMYvlXCsaR._addon_handle,cacheToDisc=WphxrkBgtInjPuUQdKDTSMYvlXCsFA)
 def wavve_main(WphxrkBgtInjPuUQdKDTSMYvlXCsaR):
  WphxrkBgtInjPuUQdKDTSMYvlXCsbO=WphxrkBgtInjPuUQdKDTSMYvlXCsaR.main_params.get('mode',WphxrkBgtInjPuUQdKDTSMYvlXCsFV)
  if WphxrkBgtInjPuUQdKDTSMYvlXCsbO=='LOGOUT':
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.logout()
   return
  WphxrkBgtInjPuUQdKDTSMYvlXCsaR.login_main()
  if WphxrkBgtInjPuUQdKDTSMYvlXCsbO is WphxrkBgtInjPuUQdKDTSMYvlXCsFV:
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.dp_Main_List()
  elif WphxrkBgtInjPuUQdKDTSMYvlXCsbO in['LIVE','VOD','MOVIE']:
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.play_VIDEO(WphxrkBgtInjPuUQdKDTSMYvlXCsaR.main_params)
  elif WphxrkBgtInjPuUQdKDTSMYvlXCsbO=='LIVE_CATAGORY':
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.dp_LiveCatagory_List(WphxrkBgtInjPuUQdKDTSMYvlXCsaR.main_params)
  elif WphxrkBgtInjPuUQdKDTSMYvlXCsbO=='MAIN_CATAGORY':
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.dp_MainCatagory_List(WphxrkBgtInjPuUQdKDTSMYvlXCsaR.main_params)
  elif WphxrkBgtInjPuUQdKDTSMYvlXCsbO=='SUPERSECTION_LIST':
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.dp_SuperSection_List(WphxrkBgtInjPuUQdKDTSMYvlXCsaR.main_params)
  elif WphxrkBgtInjPuUQdKDTSMYvlXCsbO=='BANDLIVESECTION_LIST':
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.dp_BandLiveSection_List(WphxrkBgtInjPuUQdKDTSMYvlXCsaR.main_params)
  elif WphxrkBgtInjPuUQdKDTSMYvlXCsbO=='BAND2SECTION_LIST':
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.dp_Band2Section_List(WphxrkBgtInjPuUQdKDTSMYvlXCsaR.main_params)
  elif WphxrkBgtInjPuUQdKDTSMYvlXCsbO=='PROGRAM_LIST':
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.dp_Program_List(WphxrkBgtInjPuUQdKDTSMYvlXCsaR.main_params)
  elif WphxrkBgtInjPuUQdKDTSMYvlXCsbO=='EPISODE_LIST':
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.dp_Episode_List(WphxrkBgtInjPuUQdKDTSMYvlXCsaR.main_params)
  elif WphxrkBgtInjPuUQdKDTSMYvlXCsbO=='MOVIE_LIST':
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.dp_Movie_List(WphxrkBgtInjPuUQdKDTSMYvlXCsaR.main_params)
  elif WphxrkBgtInjPuUQdKDTSMYvlXCsbO=='LIVE_LIST':
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.dp_LiveChannel_List(WphxrkBgtInjPuUQdKDTSMYvlXCsaR.main_params)
  elif WphxrkBgtInjPuUQdKDTSMYvlXCsbO=='ORDER_BY':
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.dp_setEpOrderby(WphxrkBgtInjPuUQdKDTSMYvlXCsaR.main_params)
  elif WphxrkBgtInjPuUQdKDTSMYvlXCsbO=='SEARCH_GROUP':
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.dp_Search_Group(WphxrkBgtInjPuUQdKDTSMYvlXCsaR.main_params)
  elif WphxrkBgtInjPuUQdKDTSMYvlXCsbO=='SEARCH_LIST':
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.dp_Search_List(WphxrkBgtInjPuUQdKDTSMYvlXCsaR.main_params)
  elif WphxrkBgtInjPuUQdKDTSMYvlXCsbO=='WATCH_GROUP':
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.dp_Watch_Group(WphxrkBgtInjPuUQdKDTSMYvlXCsaR.main_params)
  elif WphxrkBgtInjPuUQdKDTSMYvlXCsbO=='WATCH_LIST':
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.dp_Watch_List(WphxrkBgtInjPuUQdKDTSMYvlXCsaR.main_params)
  elif WphxrkBgtInjPuUQdKDTSMYvlXCsbO=='MYVIEW_REMOVE':
   WphxrkBgtInjPuUQdKDTSMYvlXCsaR.dp_WatchList_Delete(WphxrkBgtInjPuUQdKDTSMYvlXCsaR.main_params)
  else:
   WphxrkBgtInjPuUQdKDTSMYvlXCsFV
# Created by pyminifier (https://github.com/liftoff/pyminifier)
