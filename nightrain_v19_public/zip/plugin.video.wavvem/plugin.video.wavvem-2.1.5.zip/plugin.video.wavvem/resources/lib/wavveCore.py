__author__="NightRain"
FbqHspimQocudKlnzjRDgMatXCLSvY=object
FbqHspimQocudKlnzjRDgMatXCLSvJ=None
FbqHspimQocudKlnzjRDgMatXCLSvI=False
FbqHspimQocudKlnzjRDgMatXCLSvN=True
FbqHspimQocudKlnzjRDgMatXCLSvA=range
FbqHspimQocudKlnzjRDgMatXCLSvO=str
FbqHspimQocudKlnzjRDgMatXCLSEB=Exception
FbqHspimQocudKlnzjRDgMatXCLSET=print
FbqHspimQocudKlnzjRDgMatXCLSEr=dict
FbqHspimQocudKlnzjRDgMatXCLSEv=int
FbqHspimQocudKlnzjRDgMatXCLSEU=len
import urllib
import http.cookiejar 
import re
import json
import sys
import requests
import datetime
class FbqHspimQocudKlnzjRDgMatXCLSBT(FbqHspimQocudKlnzjRDgMatXCLSvY):
 def __init__(FbqHspimQocudKlnzjRDgMatXCLSBr):
  FbqHspimQocudKlnzjRDgMatXCLSBr.API_DOMAIN='https://apis.wavve.com'
  FbqHspimQocudKlnzjRDgMatXCLSBr.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  FbqHspimQocudKlnzjRDgMatXCLSBr.CREDENTIAL='none'
  FbqHspimQocudKlnzjRDgMatXCLSBr.DEVICE ='pc'
  FbqHspimQocudKlnzjRDgMatXCLSBr.DRM ='wm'
  FbqHspimQocudKlnzjRDgMatXCLSBr.PARTNER ='pooq'
  FbqHspimQocudKlnzjRDgMatXCLSBr.POOQZONE ='none'
  FbqHspimQocudKlnzjRDgMatXCLSBr.REGION ='kor'
  FbqHspimQocudKlnzjRDgMatXCLSBr.TARGETAGE ='all'
  FbqHspimQocudKlnzjRDgMatXCLSBr.HTTPTAG ='https://'
  FbqHspimQocudKlnzjRDgMatXCLSBr.LIST_LIMIT=30 
  FbqHspimQocudKlnzjRDgMatXCLSBr.EP_LIMIT =30 
  FbqHspimQocudKlnzjRDgMatXCLSBr.MV_LIMIT =24 
  FbqHspimQocudKlnzjRDgMatXCLSBr.SEARCH_LIMIT=20 
  FbqHspimQocudKlnzjRDgMatXCLSBr.guid ='none' 
  FbqHspimQocudKlnzjRDgMatXCLSBr.guidtimestamp='none' 
  FbqHspimQocudKlnzjRDgMatXCLSBr.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
  FbqHspimQocudKlnzjRDgMatXCLSBr.DEFAULT_HEADER={'user-agent':FbqHspimQocudKlnzjRDgMatXCLSBr.USER_AGENT}
 def callRequestCookies(FbqHspimQocudKlnzjRDgMatXCLSBr,jobtype,FbqHspimQocudKlnzjRDgMatXCLSBY,payload=FbqHspimQocudKlnzjRDgMatXCLSvJ,params=FbqHspimQocudKlnzjRDgMatXCLSvJ,headers=FbqHspimQocudKlnzjRDgMatXCLSvJ,cookies=FbqHspimQocudKlnzjRDgMatXCLSvJ,redirects=FbqHspimQocudKlnzjRDgMatXCLSvI):
  FbqHspimQocudKlnzjRDgMatXCLSBv=FbqHspimQocudKlnzjRDgMatXCLSBr.DEFAULT_HEADER
  if headers:FbqHspimQocudKlnzjRDgMatXCLSBv.update(headers)
  if jobtype=='Get':
   FbqHspimQocudKlnzjRDgMatXCLSBE=requests.get(FbqHspimQocudKlnzjRDgMatXCLSBY,params=params,headers=FbqHspimQocudKlnzjRDgMatXCLSBv,cookies=cookies,allow_redirects=redirects)
  else:
   FbqHspimQocudKlnzjRDgMatXCLSBE=requests.post(FbqHspimQocudKlnzjRDgMatXCLSBY,data=payload,params=params,headers=FbqHspimQocudKlnzjRDgMatXCLSBv,cookies=cookies,allow_redirects=redirects)
  return FbqHspimQocudKlnzjRDgMatXCLSBE
 def SaveCredential(FbqHspimQocudKlnzjRDgMatXCLSBr,FbqHspimQocudKlnzjRDgMatXCLSBU):
  FbqHspimQocudKlnzjRDgMatXCLSBr.CREDENTIAL=FbqHspimQocudKlnzjRDgMatXCLSBU
 def LoadCredential(FbqHspimQocudKlnzjRDgMatXCLSBr):
  return FbqHspimQocudKlnzjRDgMatXCLSBr.CREDENTIAL
 def GetDefaultParams(FbqHspimQocudKlnzjRDgMatXCLSBr,login=FbqHspimQocudKlnzjRDgMatXCLSvN):
  FbqHspimQocudKlnzjRDgMatXCLSBe={'apikey':FbqHspimQocudKlnzjRDgMatXCLSBr.APIKEY,'credential':FbqHspimQocudKlnzjRDgMatXCLSBr.CREDENTIAL if login else 'none','device':FbqHspimQocudKlnzjRDgMatXCLSBr.DEVICE,'drm':FbqHspimQocudKlnzjRDgMatXCLSBr.DRM,'partner':FbqHspimQocudKlnzjRDgMatXCLSBr.PARTNER,'pooqzone':FbqHspimQocudKlnzjRDgMatXCLSBr.POOQZONE,'region':FbqHspimQocudKlnzjRDgMatXCLSBr.REGION,'targetage':FbqHspimQocudKlnzjRDgMatXCLSBr.TARGETAGE}
  return FbqHspimQocudKlnzjRDgMatXCLSBe
 def GetGUID(FbqHspimQocudKlnzjRDgMatXCLSBr,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   FbqHspimQocudKlnzjRDgMatXCLSBw=FbqHspimQocudKlnzjRDgMatXCLSBr.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   FbqHspimQocudKlnzjRDgMatXCLSBk=GenerateRandomString(5)
   FbqHspimQocudKlnzjRDgMatXCLSBW=FbqHspimQocudKlnzjRDgMatXCLSBk+media+FbqHspimQocudKlnzjRDgMatXCLSBw
   return FbqHspimQocudKlnzjRDgMatXCLSBW
  def GenerateRandomString(num):
   from random import randint
   FbqHspimQocudKlnzjRDgMatXCLSBf=""
   for i in FbqHspimQocudKlnzjRDgMatXCLSvA(0,num):
    s=FbqHspimQocudKlnzjRDgMatXCLSvO(randint(1,5))
    FbqHspimQocudKlnzjRDgMatXCLSBf+=s
   return FbqHspimQocudKlnzjRDgMatXCLSBf
  FbqHspimQocudKlnzjRDgMatXCLSBW=GenerateID(guid_str)
  FbqHspimQocudKlnzjRDgMatXCLSBP=FbqHspimQocudKlnzjRDgMatXCLSBr.GetHash(FbqHspimQocudKlnzjRDgMatXCLSBW)
  if guidType==2:
   FbqHspimQocudKlnzjRDgMatXCLSBP='%s-%s-%s-%s-%s'%(FbqHspimQocudKlnzjRDgMatXCLSBP[:8],FbqHspimQocudKlnzjRDgMatXCLSBP[8:12],FbqHspimQocudKlnzjRDgMatXCLSBP[12:16],FbqHspimQocudKlnzjRDgMatXCLSBP[16:20],FbqHspimQocudKlnzjRDgMatXCLSBP[20:])
  return FbqHspimQocudKlnzjRDgMatXCLSBP
 def GetHash(FbqHspimQocudKlnzjRDgMatXCLSBr,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return FbqHspimQocudKlnzjRDgMatXCLSvO(m.hexdigest())
 def CheckQuality(FbqHspimQocudKlnzjRDgMatXCLSBr,sel_qt,qt_list):
  FbqHspimQocudKlnzjRDgMatXCLSBV=0
  for FbqHspimQocudKlnzjRDgMatXCLSBG in qt_list:
   if sel_qt>=FbqHspimQocudKlnzjRDgMatXCLSBG:return FbqHspimQocudKlnzjRDgMatXCLSBG
   FbqHspimQocudKlnzjRDgMatXCLSBV=FbqHspimQocudKlnzjRDgMatXCLSBG
  return FbqHspimQocudKlnzjRDgMatXCLSBV
 def Get_Now_Datetime(FbqHspimQocudKlnzjRDgMatXCLSBr):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(FbqHspimQocudKlnzjRDgMatXCLSBr,in_text):
  FbqHspimQocudKlnzjRDgMatXCLSBx=in_text.replace('&lt;','<').replace('&gt;','>')
  FbqHspimQocudKlnzjRDgMatXCLSBx=FbqHspimQocudKlnzjRDgMatXCLSBx.replace('$O$','')
  FbqHspimQocudKlnzjRDgMatXCLSBx=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',FbqHspimQocudKlnzjRDgMatXCLSBx)
  FbqHspimQocudKlnzjRDgMatXCLSBx=FbqHspimQocudKlnzjRDgMatXCLSBx.lstrip('#')
  return FbqHspimQocudKlnzjRDgMatXCLSBx
 def GetCredential(FbqHspimQocudKlnzjRDgMatXCLSBr,user_id,user_pw,user_pf):
  FbqHspimQocudKlnzjRDgMatXCLSBh=FbqHspimQocudKlnzjRDgMatXCLSvI
  try:
   FbqHspimQocudKlnzjRDgMatXCLSBY=FbqHspimQocudKlnzjRDgMatXCLSBr.API_DOMAIN+ '/login'
   FbqHspimQocudKlnzjRDgMatXCLSBe=FbqHspimQocudKlnzjRDgMatXCLSBr.GetDefaultParams()
   FbqHspimQocudKlnzjRDgMatXCLSBJ={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   FbqHspimQocudKlnzjRDgMatXCLSBI=FbqHspimQocudKlnzjRDgMatXCLSBr.callRequestCookies('Post',FbqHspimQocudKlnzjRDgMatXCLSBY,payload=FbqHspimQocudKlnzjRDgMatXCLSBJ,params=FbqHspimQocudKlnzjRDgMatXCLSBe,headers=FbqHspimQocudKlnzjRDgMatXCLSvJ,cookies=FbqHspimQocudKlnzjRDgMatXCLSvJ)
   FbqHspimQocudKlnzjRDgMatXCLSBN=json.loads(FbqHspimQocudKlnzjRDgMatXCLSBI.text)
   FbqHspimQocudKlnzjRDgMatXCLSBU=FbqHspimQocudKlnzjRDgMatXCLSBN['credential']
   if user_pf!=0:
    FbqHspimQocudKlnzjRDgMatXCLSBJ={'id':FbqHspimQocudKlnzjRDgMatXCLSBU,'password':'','profile':FbqHspimQocudKlnzjRDgMatXCLSvO(user_pf),'pushid':'','type':'credential'}
    FbqHspimQocudKlnzjRDgMatXCLSBe['credential']=FbqHspimQocudKlnzjRDgMatXCLSBU 
    FbqHspimQocudKlnzjRDgMatXCLSBI=FbqHspimQocudKlnzjRDgMatXCLSBr.callRequestCookies('Post',FbqHspimQocudKlnzjRDgMatXCLSBY,payload=FbqHspimQocudKlnzjRDgMatXCLSBJ,params=FbqHspimQocudKlnzjRDgMatXCLSBe,headers=FbqHspimQocudKlnzjRDgMatXCLSvJ,cookies=FbqHspimQocudKlnzjRDgMatXCLSvJ)
    FbqHspimQocudKlnzjRDgMatXCLSBN=json.loads(FbqHspimQocudKlnzjRDgMatXCLSBI.text)
    FbqHspimQocudKlnzjRDgMatXCLSBU=FbqHspimQocudKlnzjRDgMatXCLSBN['credential']
   if FbqHspimQocudKlnzjRDgMatXCLSBU:FbqHspimQocudKlnzjRDgMatXCLSBh=FbqHspimQocudKlnzjRDgMatXCLSvN
  except FbqHspimQocudKlnzjRDgMatXCLSEB as exception:
   FbqHspimQocudKlnzjRDgMatXCLSET(exception)
   FbqHspimQocudKlnzjRDgMatXCLSBU='none' 
  FbqHspimQocudKlnzjRDgMatXCLSBr.SaveCredential(FbqHspimQocudKlnzjRDgMatXCLSBU)
  return FbqHspimQocudKlnzjRDgMatXCLSBh
 def GetIssue(FbqHspimQocudKlnzjRDgMatXCLSBr):
  FbqHspimQocudKlnzjRDgMatXCLSBA=FbqHspimQocudKlnzjRDgMatXCLSvI
  try:
   FbqHspimQocudKlnzjRDgMatXCLSBY=FbqHspimQocudKlnzjRDgMatXCLSBr.API_DOMAIN+'/guid/issue'
   FbqHspimQocudKlnzjRDgMatXCLSBe=FbqHspimQocudKlnzjRDgMatXCLSBr.GetDefaultParams()
   FbqHspimQocudKlnzjRDgMatXCLSBI=FbqHspimQocudKlnzjRDgMatXCLSBr.callRequestCookies('Get',FbqHspimQocudKlnzjRDgMatXCLSBY,payload=FbqHspimQocudKlnzjRDgMatXCLSvJ,params=FbqHspimQocudKlnzjRDgMatXCLSBe,headers=FbqHspimQocudKlnzjRDgMatXCLSvJ,cookies=FbqHspimQocudKlnzjRDgMatXCLSvJ)
   FbqHspimQocudKlnzjRDgMatXCLSBN=json.loads(FbqHspimQocudKlnzjRDgMatXCLSBI.text)
   FbqHspimQocudKlnzjRDgMatXCLSBO=FbqHspimQocudKlnzjRDgMatXCLSBN['guid']
   FbqHspimQocudKlnzjRDgMatXCLSTB=FbqHspimQocudKlnzjRDgMatXCLSBN['guidtimestamp']
   if FbqHspimQocudKlnzjRDgMatXCLSBO:FbqHspimQocudKlnzjRDgMatXCLSBA=FbqHspimQocudKlnzjRDgMatXCLSvN
  except FbqHspimQocudKlnzjRDgMatXCLSEB as exception:
   FbqHspimQocudKlnzjRDgMatXCLSET(exception)
   FbqHspimQocudKlnzjRDgMatXCLSBO='none'
   FbqHspimQocudKlnzjRDgMatXCLSTB='none' 
  FbqHspimQocudKlnzjRDgMatXCLSBr.guid=FbqHspimQocudKlnzjRDgMatXCLSBO
  FbqHspimQocudKlnzjRDgMatXCLSBr.guidtimestamp=FbqHspimQocudKlnzjRDgMatXCLSTB
  return FbqHspimQocudKlnzjRDgMatXCLSBA
 def Baseapi_Parse(FbqHspimQocudKlnzjRDgMatXCLSBr,FbqHspimQocudKlnzjRDgMatXCLSTU):
  try:
   FbqHspimQocudKlnzjRDgMatXCLSTr =urllib.parse.urlsplit(FbqHspimQocudKlnzjRDgMatXCLSTU)
   if FbqHspimQocudKlnzjRDgMatXCLSTr.netloc=='':
    FbqHspimQocudKlnzjRDgMatXCLSBY=FbqHspimQocudKlnzjRDgMatXCLSBr.HTTPTAG+FbqHspimQocudKlnzjRDgMatXCLSTr.netloc+FbqHspimQocudKlnzjRDgMatXCLSTr.path
   else:
    FbqHspimQocudKlnzjRDgMatXCLSBY=FbqHspimQocudKlnzjRDgMatXCLSTr.scheme+'://'+FbqHspimQocudKlnzjRDgMatXCLSTr.netloc+FbqHspimQocudKlnzjRDgMatXCLSTr.path
   FbqHspimQocudKlnzjRDgMatXCLSBe=FbqHspimQocudKlnzjRDgMatXCLSEr(urllib.parse.parse_qsl(FbqHspimQocudKlnzjRDgMatXCLSTr.query))
  except:
   FbqHspimQocudKlnzjRDgMatXCLSET(exception)
   return '',{}
  return FbqHspimQocudKlnzjRDgMatXCLSBY,FbqHspimQocudKlnzjRDgMatXCLSBe
 def GetSupermultiUrl(FbqHspimQocudKlnzjRDgMatXCLSBr,sCode,sIndex='0'):
  try:
   FbqHspimQocudKlnzjRDgMatXCLSBY=FbqHspimQocudKlnzjRDgMatXCLSBr.API_DOMAIN+'/cf/supermultisections/'+sCode
   FbqHspimQocudKlnzjRDgMatXCLSBe=FbqHspimQocudKlnzjRDgMatXCLSBr.GetDefaultParams(login=FbqHspimQocudKlnzjRDgMatXCLSvI)
   FbqHspimQocudKlnzjRDgMatXCLSBI=FbqHspimQocudKlnzjRDgMatXCLSBr.callRequestCookies('Get',FbqHspimQocudKlnzjRDgMatXCLSBY,payload=FbqHspimQocudKlnzjRDgMatXCLSvJ,params=FbqHspimQocudKlnzjRDgMatXCLSBe,headers=FbqHspimQocudKlnzjRDgMatXCLSvJ,cookies=FbqHspimQocudKlnzjRDgMatXCLSvJ)
   FbqHspimQocudKlnzjRDgMatXCLSBN=json.loads(FbqHspimQocudKlnzjRDgMatXCLSBI.text)
   FbqHspimQocudKlnzjRDgMatXCLSTv=FbqHspimQocudKlnzjRDgMatXCLSBN['multisectionlist'][FbqHspimQocudKlnzjRDgMatXCLSEv(sIndex)]['eventlist'][1]['url']
  except FbqHspimQocudKlnzjRDgMatXCLSEB as exception:
   FbqHspimQocudKlnzjRDgMatXCLSET(exception)
   return ''
  return FbqHspimQocudKlnzjRDgMatXCLSTv
 def Get_LiveCatagory_List(FbqHspimQocudKlnzjRDgMatXCLSBr,sCode,sIndex='0'):
  FbqHspimQocudKlnzjRDgMatXCLSTE=[]
  FbqHspimQocudKlnzjRDgMatXCLSTU =FbqHspimQocudKlnzjRDgMatXCLSBr.GetSupermultiUrl(sCode,sIndex)
  (FbqHspimQocudKlnzjRDgMatXCLSBY,FbqHspimQocudKlnzjRDgMatXCLSBe)=FbqHspimQocudKlnzjRDgMatXCLSBr.Baseapi_Parse(FbqHspimQocudKlnzjRDgMatXCLSTU)
  if FbqHspimQocudKlnzjRDgMatXCLSBY=='':return FbqHspimQocudKlnzjRDgMatXCLSTE,''
  try:
   FbqHspimQocudKlnzjRDgMatXCLSBe.update(FbqHspimQocudKlnzjRDgMatXCLSBr.GetDefaultParams(login=FbqHspimQocudKlnzjRDgMatXCLSvI))
   FbqHspimQocudKlnzjRDgMatXCLSBI=FbqHspimQocudKlnzjRDgMatXCLSBr.callRequestCookies('Get',FbqHspimQocudKlnzjRDgMatXCLSBY,payload=FbqHspimQocudKlnzjRDgMatXCLSvJ,params=FbqHspimQocudKlnzjRDgMatXCLSBe,headers=FbqHspimQocudKlnzjRDgMatXCLSvJ,cookies=FbqHspimQocudKlnzjRDgMatXCLSvJ)
   FbqHspimQocudKlnzjRDgMatXCLSBN=json.loads(FbqHspimQocudKlnzjRDgMatXCLSBI.text)
   if not('filter_item_list' in FbqHspimQocudKlnzjRDgMatXCLSBN['filter']['filterlist'][0]):return[],''
   FbqHspimQocudKlnzjRDgMatXCLSTw=FbqHspimQocudKlnzjRDgMatXCLSBN['filter']['filterlist'][0]['filter_item_list']
   for FbqHspimQocudKlnzjRDgMatXCLSTk in FbqHspimQocudKlnzjRDgMatXCLSTw:
    FbqHspimQocudKlnzjRDgMatXCLSTW={'title':FbqHspimQocudKlnzjRDgMatXCLSTk['title'],'genre':FbqHspimQocudKlnzjRDgMatXCLSTk['api_parameters'][FbqHspimQocudKlnzjRDgMatXCLSTk['api_parameters'].index('=')+1:]}
    FbqHspimQocudKlnzjRDgMatXCLSTE.append(FbqHspimQocudKlnzjRDgMatXCLSTW)
  except FbqHspimQocudKlnzjRDgMatXCLSEB as exception:
   FbqHspimQocudKlnzjRDgMatXCLSET(exception)
   return[],''
  return FbqHspimQocudKlnzjRDgMatXCLSTE,FbqHspimQocudKlnzjRDgMatXCLSTU
 def Get_MainCatagory_List(FbqHspimQocudKlnzjRDgMatXCLSBr,sCode,sIndex='0'):
  FbqHspimQocudKlnzjRDgMatXCLSTE=[]
  FbqHspimQocudKlnzjRDgMatXCLSTU =FbqHspimQocudKlnzjRDgMatXCLSBr.GetSupermultiUrl(sCode,sIndex)
  (FbqHspimQocudKlnzjRDgMatXCLSBY,FbqHspimQocudKlnzjRDgMatXCLSBe)=FbqHspimQocudKlnzjRDgMatXCLSBr.Baseapi_Parse(FbqHspimQocudKlnzjRDgMatXCLSTU)
  if FbqHspimQocudKlnzjRDgMatXCLSBY=='':return FbqHspimQocudKlnzjRDgMatXCLSTE
  try:
   FbqHspimQocudKlnzjRDgMatXCLSBe.update(FbqHspimQocudKlnzjRDgMatXCLSBr.GetDefaultParams(login=FbqHspimQocudKlnzjRDgMatXCLSvI))
   FbqHspimQocudKlnzjRDgMatXCLSBI=FbqHspimQocudKlnzjRDgMatXCLSBr.callRequestCookies('Get',FbqHspimQocudKlnzjRDgMatXCLSBY,payload=FbqHspimQocudKlnzjRDgMatXCLSvJ,params=FbqHspimQocudKlnzjRDgMatXCLSBe,headers=FbqHspimQocudKlnzjRDgMatXCLSvJ,cookies=FbqHspimQocudKlnzjRDgMatXCLSvJ)
   FbqHspimQocudKlnzjRDgMatXCLSBN=json.loads(FbqHspimQocudKlnzjRDgMatXCLSBI.text)
   if not('celllist' in FbqHspimQocudKlnzjRDgMatXCLSBN['band']):return[]
   FbqHspimQocudKlnzjRDgMatXCLSTw=FbqHspimQocudKlnzjRDgMatXCLSBN['band']['celllist']
   for FbqHspimQocudKlnzjRDgMatXCLSTk in FbqHspimQocudKlnzjRDgMatXCLSTw:
    FbqHspimQocudKlnzjRDgMatXCLSTf =FbqHspimQocudKlnzjRDgMatXCLSTk['event_list'][1]['url']
    (FbqHspimQocudKlnzjRDgMatXCLSTP,FbqHspimQocudKlnzjRDgMatXCLSTV)=FbqHspimQocudKlnzjRDgMatXCLSBr.Baseapi_Parse(FbqHspimQocudKlnzjRDgMatXCLSTf)
    FbqHspimQocudKlnzjRDgMatXCLSTW={'title':FbqHspimQocudKlnzjRDgMatXCLSTk['title_list'][0]['text'],'suburl':FbqHspimQocudKlnzjRDgMatXCLSTP,'subapi':FbqHspimQocudKlnzjRDgMatXCLSTV.get('api'),'subtype':'catagory' if FbqHspimQocudKlnzjRDgMatXCLSTV else 'supersection'}
    FbqHspimQocudKlnzjRDgMatXCLSTE.append(FbqHspimQocudKlnzjRDgMatXCLSTW)
  except FbqHspimQocudKlnzjRDgMatXCLSEB as exception:
   FbqHspimQocudKlnzjRDgMatXCLSET(exception)
   return[]
  return FbqHspimQocudKlnzjRDgMatXCLSTE
 def Get_SuperMultiSection_List(FbqHspimQocudKlnzjRDgMatXCLSBr,subapi_text):
  FbqHspimQocudKlnzjRDgMatXCLSTE=[]
  FbqHspimQocudKlnzjRDgMatXCLSBe={}
  try:
   FbqHspimQocudKlnzjRDgMatXCLSTr =urllib.parse.urlsplit(subapi_text)
   if FbqHspimQocudKlnzjRDgMatXCLSTr.path.find('apis.wavve.com')>=0: 
    FbqHspimQocudKlnzjRDgMatXCLSBY=FbqHspimQocudKlnzjRDgMatXCLSBr.HTTPTAG+FbqHspimQocudKlnzjRDgMatXCLSTr.path 
    FbqHspimQocudKlnzjRDgMatXCLSBe=FbqHspimQocudKlnzjRDgMatXCLSEr(urllib.parse.parse_qsl(FbqHspimQocudKlnzjRDgMatXCLSTr.query))
   else:
    FbqHspimQocudKlnzjRDgMatXCLSBY=FbqHspimQocudKlnzjRDgMatXCLSBr.API_DOMAIN+'/cf'+FbqHspimQocudKlnzjRDgMatXCLSTr.path 
   FbqHspimQocudKlnzjRDgMatXCLSBY=FbqHspimQocudKlnzjRDgMatXCLSBY.replace('supermultisection/','supermultisections/')
  except FbqHspimQocudKlnzjRDgMatXCLSEB as exception:
   FbqHspimQocudKlnzjRDgMatXCLSET(exception)
   return[]
  try:
   FbqHspimQocudKlnzjRDgMatXCLSBe.update(FbqHspimQocudKlnzjRDgMatXCLSBr.GetDefaultParams(login=FbqHspimQocudKlnzjRDgMatXCLSvI))
   FbqHspimQocudKlnzjRDgMatXCLSBI=FbqHspimQocudKlnzjRDgMatXCLSBr.callRequestCookies('Get',FbqHspimQocudKlnzjRDgMatXCLSBY,payload=FbqHspimQocudKlnzjRDgMatXCLSvJ,params=FbqHspimQocudKlnzjRDgMatXCLSvJ,headers=FbqHspimQocudKlnzjRDgMatXCLSvJ,cookies=FbqHspimQocudKlnzjRDgMatXCLSvJ)
   FbqHspimQocudKlnzjRDgMatXCLSBN=json.loads(FbqHspimQocudKlnzjRDgMatXCLSBI.text)
   if not('multisectionlist' in FbqHspimQocudKlnzjRDgMatXCLSBN):return[]
   FbqHspimQocudKlnzjRDgMatXCLSTw=FbqHspimQocudKlnzjRDgMatXCLSBN['multisectionlist']
   for FbqHspimQocudKlnzjRDgMatXCLSTk in FbqHspimQocudKlnzjRDgMatXCLSTw:
    FbqHspimQocudKlnzjRDgMatXCLSTG=FbqHspimQocudKlnzjRDgMatXCLSTk['title']
    if FbqHspimQocudKlnzjRDgMatXCLSEU(FbqHspimQocudKlnzjRDgMatXCLSTG)==0:continue
    if FbqHspimQocudKlnzjRDgMatXCLSTG=='minor':continue
    if re.search(u'베너',FbqHspimQocudKlnzjRDgMatXCLSTG):continue
    if re.search(u'배너',FbqHspimQocudKlnzjRDgMatXCLSTG):continue 
    if FbqHspimQocudKlnzjRDgMatXCLSEU(FbqHspimQocudKlnzjRDgMatXCLSTk['eventlist'])>=3:
     FbqHspimQocudKlnzjRDgMatXCLSTV =FbqHspimQocudKlnzjRDgMatXCLSTk['eventlist'][2]['url']
    else:
     FbqHspimQocudKlnzjRDgMatXCLSTV =FbqHspimQocudKlnzjRDgMatXCLSTk['eventlist'][1]['url']
    FbqHspimQocudKlnzjRDgMatXCLSTy=FbqHspimQocudKlnzjRDgMatXCLSTk['cell_type']
    if FbqHspimQocudKlnzjRDgMatXCLSTy=='band_2':
     if FbqHspimQocudKlnzjRDgMatXCLSTV.find('channellist=')>=0:
      FbqHspimQocudKlnzjRDgMatXCLSTy='band_live'
    FbqHspimQocudKlnzjRDgMatXCLSTW={'title':FbqHspimQocudKlnzjRDgMatXCLSBr.Get_ChangeText(FbqHspimQocudKlnzjRDgMatXCLSTG),'subapi':FbqHspimQocudKlnzjRDgMatXCLSTV,'cell_type':FbqHspimQocudKlnzjRDgMatXCLSTy}
    FbqHspimQocudKlnzjRDgMatXCLSTE.append(FbqHspimQocudKlnzjRDgMatXCLSTW)
  except FbqHspimQocudKlnzjRDgMatXCLSEB as exception:
   FbqHspimQocudKlnzjRDgMatXCLSET(exception)
   return[]
  return FbqHspimQocudKlnzjRDgMatXCLSTE
 def Get_BandLiveSection_List(FbqHspimQocudKlnzjRDgMatXCLSBr,FbqHspimQocudKlnzjRDgMatXCLSTU,page_int=1):
  FbqHspimQocudKlnzjRDgMatXCLSTx=[]
  FbqHspimQocudKlnzjRDgMatXCLSTh=FbqHspimQocudKlnzjRDgMatXCLSTO=1
  FbqHspimQocudKlnzjRDgMatXCLSTY=FbqHspimQocudKlnzjRDgMatXCLSvI
  try:
   (FbqHspimQocudKlnzjRDgMatXCLSBY,FbqHspimQocudKlnzjRDgMatXCLSBe)=FbqHspimQocudKlnzjRDgMatXCLSBr.Baseapi_Parse(FbqHspimQocudKlnzjRDgMatXCLSTU)
  except FbqHspimQocudKlnzjRDgMatXCLSEB as exception:
   FbqHspimQocudKlnzjRDgMatXCLSET(exception)
   return[],FbqHspimQocudKlnzjRDgMatXCLSvI
  try:
   FbqHspimQocudKlnzjRDgMatXCLSBe['limit']=FbqHspimQocudKlnzjRDgMatXCLSBr.LIST_LIMIT
   FbqHspimQocudKlnzjRDgMatXCLSBe['offset']=FbqHspimQocudKlnzjRDgMatXCLSvO((page_int-1)*FbqHspimQocudKlnzjRDgMatXCLSBr.LIST_LIMIT)
   FbqHspimQocudKlnzjRDgMatXCLSBe.update(FbqHspimQocudKlnzjRDgMatXCLSBr.GetDefaultParams(login=FbqHspimQocudKlnzjRDgMatXCLSvI))
   FbqHspimQocudKlnzjRDgMatXCLSBI=FbqHspimQocudKlnzjRDgMatXCLSBr.callRequestCookies('Get',FbqHspimQocudKlnzjRDgMatXCLSBY,payload=FbqHspimQocudKlnzjRDgMatXCLSvJ,params=FbqHspimQocudKlnzjRDgMatXCLSBe,headers=FbqHspimQocudKlnzjRDgMatXCLSvJ,cookies=FbqHspimQocudKlnzjRDgMatXCLSvJ)
   FbqHspimQocudKlnzjRDgMatXCLSBN=json.loads(FbqHspimQocudKlnzjRDgMatXCLSBI.text)
   if not('celllist' in FbqHspimQocudKlnzjRDgMatXCLSBN['cell_toplist']):return[],FbqHspimQocudKlnzjRDgMatXCLSvI
   FbqHspimQocudKlnzjRDgMatXCLSTw=FbqHspimQocudKlnzjRDgMatXCLSBN['cell_toplist']['celllist']
   for FbqHspimQocudKlnzjRDgMatXCLSTk in FbqHspimQocudKlnzjRDgMatXCLSTw:
    FbqHspimQocudKlnzjRDgMatXCLSTJ =FbqHspimQocudKlnzjRDgMatXCLSTk['event_list'][1]['url']
    FbqHspimQocudKlnzjRDgMatXCLSTI=urllib.parse.urlsplit(FbqHspimQocudKlnzjRDgMatXCLSTJ).query
    FbqHspimQocudKlnzjRDgMatXCLSTI=FbqHspimQocudKlnzjRDgMatXCLSEr(urllib.parse.parse_qsl(FbqHspimQocudKlnzjRDgMatXCLSTI))
    FbqHspimQocudKlnzjRDgMatXCLSTN='channelid'
    FbqHspimQocudKlnzjRDgMatXCLSTA=FbqHspimQocudKlnzjRDgMatXCLSTI[FbqHspimQocudKlnzjRDgMatXCLSTN]
    FbqHspimQocudKlnzjRDgMatXCLSTW={'studio':FbqHspimQocudKlnzjRDgMatXCLSTk['title_list'][0]['text'],'tvshowtitle':FbqHspimQocudKlnzjRDgMatXCLSBr.Get_ChangeText(FbqHspimQocudKlnzjRDgMatXCLSTk['title_list'][1]['text']),'channelid':FbqHspimQocudKlnzjRDgMatXCLSTA,'age':FbqHspimQocudKlnzjRDgMatXCLSTk.get('age'),'thumbnail':'https://%s'%FbqHspimQocudKlnzjRDgMatXCLSTk.get('thumbnail')}
    FbqHspimQocudKlnzjRDgMatXCLSTx.append(FbqHspimQocudKlnzjRDgMatXCLSTW)
   FbqHspimQocudKlnzjRDgMatXCLSTh=FbqHspimQocudKlnzjRDgMatXCLSEv(FbqHspimQocudKlnzjRDgMatXCLSBN['cell_toplist']['pagecount'])
   if FbqHspimQocudKlnzjRDgMatXCLSBN['cell_toplist']['count']:FbqHspimQocudKlnzjRDgMatXCLSTO =FbqHspimQocudKlnzjRDgMatXCLSEv(FbqHspimQocudKlnzjRDgMatXCLSBN['cell_toplist']['count'])
   else:FbqHspimQocudKlnzjRDgMatXCLSTO=FbqHspimQocudKlnzjRDgMatXCLSBr.LIST_LIMIT*page_int
   FbqHspimQocudKlnzjRDgMatXCLSTY=FbqHspimQocudKlnzjRDgMatXCLSTh>FbqHspimQocudKlnzjRDgMatXCLSTO
  except FbqHspimQocudKlnzjRDgMatXCLSEB as exception:
   FbqHspimQocudKlnzjRDgMatXCLSET(exception)
   return[],FbqHspimQocudKlnzjRDgMatXCLSvI
  return FbqHspimQocudKlnzjRDgMatXCLSTx,FbqHspimQocudKlnzjRDgMatXCLSTY
 def Get_Band2Section_List(FbqHspimQocudKlnzjRDgMatXCLSBr,FbqHspimQocudKlnzjRDgMatXCLSTU,page_int=1):
  FbqHspimQocudKlnzjRDgMatXCLSrB=[]
  FbqHspimQocudKlnzjRDgMatXCLSTh=FbqHspimQocudKlnzjRDgMatXCLSTO=1
  FbqHspimQocudKlnzjRDgMatXCLSTY=FbqHspimQocudKlnzjRDgMatXCLSvI
  try:
   (FbqHspimQocudKlnzjRDgMatXCLSBY,FbqHspimQocudKlnzjRDgMatXCLSBe)=FbqHspimQocudKlnzjRDgMatXCLSBr.Baseapi_Parse(FbqHspimQocudKlnzjRDgMatXCLSTU)
  except FbqHspimQocudKlnzjRDgMatXCLSEB as exception:
   FbqHspimQocudKlnzjRDgMatXCLSET(exception)
   return[],FbqHspimQocudKlnzjRDgMatXCLSvI
  try:
   FbqHspimQocudKlnzjRDgMatXCLSBe['came'] ='BandView'
   FbqHspimQocudKlnzjRDgMatXCLSBe['limit']=FbqHspimQocudKlnzjRDgMatXCLSBr.LIST_LIMIT
   FbqHspimQocudKlnzjRDgMatXCLSBe['offset']=FbqHspimQocudKlnzjRDgMatXCLSvO((page_int-1)*FbqHspimQocudKlnzjRDgMatXCLSBr.LIST_LIMIT)
   FbqHspimQocudKlnzjRDgMatXCLSBe.update(FbqHspimQocudKlnzjRDgMatXCLSBr.GetDefaultParams(login=FbqHspimQocudKlnzjRDgMatXCLSvI))
   FbqHspimQocudKlnzjRDgMatXCLSBI=FbqHspimQocudKlnzjRDgMatXCLSBr.callRequestCookies('Get',FbqHspimQocudKlnzjRDgMatXCLSBY,payload=FbqHspimQocudKlnzjRDgMatXCLSvJ,params=FbqHspimQocudKlnzjRDgMatXCLSBe,headers=FbqHspimQocudKlnzjRDgMatXCLSvJ,cookies=FbqHspimQocudKlnzjRDgMatXCLSvJ)
   FbqHspimQocudKlnzjRDgMatXCLSBN=json.loads(FbqHspimQocudKlnzjRDgMatXCLSBI.text)
   if not('celllist' in FbqHspimQocudKlnzjRDgMatXCLSBN['cell_toplist']):return[],FbqHspimQocudKlnzjRDgMatXCLSvI
   FbqHspimQocudKlnzjRDgMatXCLSTw=FbqHspimQocudKlnzjRDgMatXCLSBN['cell_toplist']['celllist']
   for FbqHspimQocudKlnzjRDgMatXCLSTk in FbqHspimQocudKlnzjRDgMatXCLSTw:
    FbqHspimQocudKlnzjRDgMatXCLSTJ =FbqHspimQocudKlnzjRDgMatXCLSTk['event_list'][1]['url']
    FbqHspimQocudKlnzjRDgMatXCLSTI=urllib.parse.urlsplit(FbqHspimQocudKlnzjRDgMatXCLSTJ).query
    FbqHspimQocudKlnzjRDgMatXCLSTI=FbqHspimQocudKlnzjRDgMatXCLSEr(urllib.parse.parse_qsl(FbqHspimQocudKlnzjRDgMatXCLSTI))
    FbqHspimQocudKlnzjRDgMatXCLSTN='contentid'
    FbqHspimQocudKlnzjRDgMatXCLSTA=FbqHspimQocudKlnzjRDgMatXCLSTI[FbqHspimQocudKlnzjRDgMatXCLSTN]
    FbqHspimQocudKlnzjRDgMatXCLSTW={'programtitle':FbqHspimQocudKlnzjRDgMatXCLSTk['title_list'][0]['text'],'episodetitle':FbqHspimQocudKlnzjRDgMatXCLSBr.Get_ChangeText(FbqHspimQocudKlnzjRDgMatXCLSTk['title_list'][1]['text']),'age':FbqHspimQocudKlnzjRDgMatXCLSTk.get('age'),'thumbnail':FbqHspimQocudKlnzjRDgMatXCLSBr.HTTPTAG+FbqHspimQocudKlnzjRDgMatXCLSTk.get('thumbnail'),'vidtype':FbqHspimQocudKlnzjRDgMatXCLSTN,'videoid':FbqHspimQocudKlnzjRDgMatXCLSTA}
    FbqHspimQocudKlnzjRDgMatXCLSrB.append(FbqHspimQocudKlnzjRDgMatXCLSTW)
   FbqHspimQocudKlnzjRDgMatXCLSTh=FbqHspimQocudKlnzjRDgMatXCLSEv(FbqHspimQocudKlnzjRDgMatXCLSBN['cell_toplist']['pagecount'])
   if FbqHspimQocudKlnzjRDgMatXCLSBN['cell_toplist']['count']:FbqHspimQocudKlnzjRDgMatXCLSTO =FbqHspimQocudKlnzjRDgMatXCLSEv(FbqHspimQocudKlnzjRDgMatXCLSBN['cell_toplist']['count'])
   else:FbqHspimQocudKlnzjRDgMatXCLSTO=FbqHspimQocudKlnzjRDgMatXCLSBr.LIST_LIMIT*page_int
   FbqHspimQocudKlnzjRDgMatXCLSTY=FbqHspimQocudKlnzjRDgMatXCLSTh>FbqHspimQocudKlnzjRDgMatXCLSTO
  except FbqHspimQocudKlnzjRDgMatXCLSEB as exception:
   FbqHspimQocudKlnzjRDgMatXCLSET(exception)
   return[],FbqHspimQocudKlnzjRDgMatXCLSvI
  return FbqHspimQocudKlnzjRDgMatXCLSrB,FbqHspimQocudKlnzjRDgMatXCLSTY
 def Get_Program_List(FbqHspimQocudKlnzjRDgMatXCLSBr,FbqHspimQocudKlnzjRDgMatXCLSTU,page_int=1,orderby='-'):
  FbqHspimQocudKlnzjRDgMatXCLSrT=[]
  FbqHspimQocudKlnzjRDgMatXCLSTh=FbqHspimQocudKlnzjRDgMatXCLSTO=1
  FbqHspimQocudKlnzjRDgMatXCLSTY=FbqHspimQocudKlnzjRDgMatXCLSvI
  (FbqHspimQocudKlnzjRDgMatXCLSBY,FbqHspimQocudKlnzjRDgMatXCLSBe)=FbqHspimQocudKlnzjRDgMatXCLSBr.Baseapi_Parse(FbqHspimQocudKlnzjRDgMatXCLSTU)
  if FbqHspimQocudKlnzjRDgMatXCLSBY=='':return FbqHspimQocudKlnzjRDgMatXCLSrT,FbqHspimQocudKlnzjRDgMatXCLSTY
  try:
   FbqHspimQocudKlnzjRDgMatXCLSBe['limit'] =FbqHspimQocudKlnzjRDgMatXCLSBr.LIST_LIMIT
   FbqHspimQocudKlnzjRDgMatXCLSBe['offset']=FbqHspimQocudKlnzjRDgMatXCLSvO((page_int-1)*FbqHspimQocudKlnzjRDgMatXCLSBr.LIST_LIMIT)
   FbqHspimQocudKlnzjRDgMatXCLSBe['page'] =FbqHspimQocudKlnzjRDgMatXCLSvO(page_int)
   if FbqHspimQocudKlnzjRDgMatXCLSBe.get('orderby')!='' and FbqHspimQocudKlnzjRDgMatXCLSBe.get('orderby')!='regdatefirst' and orderby!='-':
    FbqHspimQocudKlnzjRDgMatXCLSBe['orderby']=orderby 
   FbqHspimQocudKlnzjRDgMatXCLSBe.update(FbqHspimQocudKlnzjRDgMatXCLSBr.GetDefaultParams(login=FbqHspimQocudKlnzjRDgMatXCLSvI))
   FbqHspimQocudKlnzjRDgMatXCLSBI=FbqHspimQocudKlnzjRDgMatXCLSBr.callRequestCookies('Get',FbqHspimQocudKlnzjRDgMatXCLSBY,payload=FbqHspimQocudKlnzjRDgMatXCLSvJ,params=FbqHspimQocudKlnzjRDgMatXCLSBe,headers=FbqHspimQocudKlnzjRDgMatXCLSvJ,cookies=FbqHspimQocudKlnzjRDgMatXCLSvJ)
   FbqHspimQocudKlnzjRDgMatXCLSBN=json.loads(FbqHspimQocudKlnzjRDgMatXCLSBI.text)
   if FbqHspimQocudKlnzjRDgMatXCLSTU.find('instantplay')>=0:
    if not('celllist' in FbqHspimQocudKlnzjRDgMatXCLSBN['band']):return FbqHspimQocudKlnzjRDgMatXCLSrT,FbqHspimQocudKlnzjRDgMatXCLSTY
    FbqHspimQocudKlnzjRDgMatXCLSTw=FbqHspimQocudKlnzjRDgMatXCLSBN['band']['celllist']
   else:
    if not('celllist' in FbqHspimQocudKlnzjRDgMatXCLSBN['cell_toplist']):return FbqHspimQocudKlnzjRDgMatXCLSrT,FbqHspimQocudKlnzjRDgMatXCLSTY
    FbqHspimQocudKlnzjRDgMatXCLSTw=FbqHspimQocudKlnzjRDgMatXCLSBN['cell_toplist']['celllist']
   for FbqHspimQocudKlnzjRDgMatXCLSTk in FbqHspimQocudKlnzjRDgMatXCLSTw:
    for FbqHspimQocudKlnzjRDgMatXCLSrv in FbqHspimQocudKlnzjRDgMatXCLSTk['event_list']:
     if FbqHspimQocudKlnzjRDgMatXCLSrv.get('type')=='on-navigation':
      FbqHspimQocudKlnzjRDgMatXCLSTJ =FbqHspimQocudKlnzjRDgMatXCLSrv['url']
    FbqHspimQocudKlnzjRDgMatXCLSTI=urllib.parse.urlsplit(FbqHspimQocudKlnzjRDgMatXCLSTJ).query
    FbqHspimQocudKlnzjRDgMatXCLSTN=FbqHspimQocudKlnzjRDgMatXCLSTI[0:FbqHspimQocudKlnzjRDgMatXCLSTI.find('=')]
    FbqHspimQocudKlnzjRDgMatXCLSTA=FbqHspimQocudKlnzjRDgMatXCLSTI[FbqHspimQocudKlnzjRDgMatXCLSTI.find('=')+1:]
    FbqHspimQocudKlnzjRDgMatXCLSTW={'title':FbqHspimQocudKlnzjRDgMatXCLSTk['title_list'][0]['text'],'age':FbqHspimQocudKlnzjRDgMatXCLSTk['age'],'thumbnail':'https://%s'%FbqHspimQocudKlnzjRDgMatXCLSTk.get('thumbnail'),'videoid':FbqHspimQocudKlnzjRDgMatXCLSTA,'vidtype':FbqHspimQocudKlnzjRDgMatXCLSTN}
    FbqHspimQocudKlnzjRDgMatXCLSrT.append(FbqHspimQocudKlnzjRDgMatXCLSTW)
   if FbqHspimQocudKlnzjRDgMatXCLSTU.find('instantplay')<0:
    FbqHspimQocudKlnzjRDgMatXCLSTh=FbqHspimQocudKlnzjRDgMatXCLSEv(FbqHspimQocudKlnzjRDgMatXCLSBN['cell_toplist']['pagecount'])
    if FbqHspimQocudKlnzjRDgMatXCLSBN['cell_toplist']['count']:FbqHspimQocudKlnzjRDgMatXCLSTO =FbqHspimQocudKlnzjRDgMatXCLSEv(FbqHspimQocudKlnzjRDgMatXCLSBN['cell_toplist']['count'])
    else:FbqHspimQocudKlnzjRDgMatXCLSTO=FbqHspimQocudKlnzjRDgMatXCLSBr.LIST_LIMIT*page_int
    FbqHspimQocudKlnzjRDgMatXCLSTY=FbqHspimQocudKlnzjRDgMatXCLSTh>FbqHspimQocudKlnzjRDgMatXCLSTO
  except FbqHspimQocudKlnzjRDgMatXCLSEB as exception:
   FbqHspimQocudKlnzjRDgMatXCLSET(exception)
   return[],FbqHspimQocudKlnzjRDgMatXCLSvI
  return FbqHspimQocudKlnzjRDgMatXCLSrT,FbqHspimQocudKlnzjRDgMatXCLSTY
 def Get_Movie_List(FbqHspimQocudKlnzjRDgMatXCLSBr,FbqHspimQocudKlnzjRDgMatXCLSTU,page_int=1):
  FbqHspimQocudKlnzjRDgMatXCLSrE=[]
  FbqHspimQocudKlnzjRDgMatXCLSTh=FbqHspimQocudKlnzjRDgMatXCLSTO=1
  FbqHspimQocudKlnzjRDgMatXCLSTY=FbqHspimQocudKlnzjRDgMatXCLSvI
  (FbqHspimQocudKlnzjRDgMatXCLSBY,FbqHspimQocudKlnzjRDgMatXCLSBe)=FbqHspimQocudKlnzjRDgMatXCLSBr.Baseapi_Parse(FbqHspimQocudKlnzjRDgMatXCLSTU)
  if FbqHspimQocudKlnzjRDgMatXCLSBY=='':return FbqHspimQocudKlnzjRDgMatXCLSrE,FbqHspimQocudKlnzjRDgMatXCLSTY
  try:
   FbqHspimQocudKlnzjRDgMatXCLSBe['limit']=FbqHspimQocudKlnzjRDgMatXCLSBr.MV_LIMIT
   FbqHspimQocudKlnzjRDgMatXCLSBe['offset']=FbqHspimQocudKlnzjRDgMatXCLSvO((page_int-1)*FbqHspimQocudKlnzjRDgMatXCLSBr.MV_LIMIT)
   FbqHspimQocudKlnzjRDgMatXCLSBe.update(FbqHspimQocudKlnzjRDgMatXCLSBr.GetDefaultParams(login=FbqHspimQocudKlnzjRDgMatXCLSvI))
   FbqHspimQocudKlnzjRDgMatXCLSBI=FbqHspimQocudKlnzjRDgMatXCLSBr.callRequestCookies('Get',FbqHspimQocudKlnzjRDgMatXCLSBY,payload=FbqHspimQocudKlnzjRDgMatXCLSvJ,params=FbqHspimQocudKlnzjRDgMatXCLSBe,headers=FbqHspimQocudKlnzjRDgMatXCLSvJ,cookies=FbqHspimQocudKlnzjRDgMatXCLSvJ)
   FbqHspimQocudKlnzjRDgMatXCLSBN=json.loads(FbqHspimQocudKlnzjRDgMatXCLSBI.text)
   if not('celllist' in FbqHspimQocudKlnzjRDgMatXCLSBN['cell_toplist']):return FbqHspimQocudKlnzjRDgMatXCLSrE,FbqHspimQocudKlnzjRDgMatXCLSTY
   FbqHspimQocudKlnzjRDgMatXCLSTw=FbqHspimQocudKlnzjRDgMatXCLSBN['cell_toplist']['celllist']
   for FbqHspimQocudKlnzjRDgMatXCLSTk in FbqHspimQocudKlnzjRDgMatXCLSTw:
    FbqHspimQocudKlnzjRDgMatXCLSTJ =FbqHspimQocudKlnzjRDgMatXCLSTk['event_list'][1]['url']
    FbqHspimQocudKlnzjRDgMatXCLSTI=urllib.parse.urlsplit(FbqHspimQocudKlnzjRDgMatXCLSTJ).query
    FbqHspimQocudKlnzjRDgMatXCLSTN=FbqHspimQocudKlnzjRDgMatXCLSTI[0:FbqHspimQocudKlnzjRDgMatXCLSTI.find('=')]
    FbqHspimQocudKlnzjRDgMatXCLSTA=FbqHspimQocudKlnzjRDgMatXCLSTI[FbqHspimQocudKlnzjRDgMatXCLSTI.find('=')+1:]
    FbqHspimQocudKlnzjRDgMatXCLSTW={'title':FbqHspimQocudKlnzjRDgMatXCLSTk['title_list'][0]['text'],'age':FbqHspimQocudKlnzjRDgMatXCLSTk['age'],'thumbnail':'https://%s'%FbqHspimQocudKlnzjRDgMatXCLSTk.get('thumbnail'),'videoid':FbqHspimQocudKlnzjRDgMatXCLSTA,'vidtype':FbqHspimQocudKlnzjRDgMatXCLSTN}
    FbqHspimQocudKlnzjRDgMatXCLSrE.append(FbqHspimQocudKlnzjRDgMatXCLSTW)
   FbqHspimQocudKlnzjRDgMatXCLSTh=FbqHspimQocudKlnzjRDgMatXCLSEv(FbqHspimQocudKlnzjRDgMatXCLSBN['cell_toplist']['pagecount'])
   if FbqHspimQocudKlnzjRDgMatXCLSBN['cell_toplist']['count']:FbqHspimQocudKlnzjRDgMatXCLSTO =FbqHspimQocudKlnzjRDgMatXCLSEv(FbqHspimQocudKlnzjRDgMatXCLSBN['cell_toplist']['count'])
   else:FbqHspimQocudKlnzjRDgMatXCLSTO=FbqHspimQocudKlnzjRDgMatXCLSBr.MV_LIMIT*page_int
   FbqHspimQocudKlnzjRDgMatXCLSTY=FbqHspimQocudKlnzjRDgMatXCLSTh>FbqHspimQocudKlnzjRDgMatXCLSTO
  except FbqHspimQocudKlnzjRDgMatXCLSEB as exception:
   FbqHspimQocudKlnzjRDgMatXCLSET(exception)
   return[],FbqHspimQocudKlnzjRDgMatXCLSvI
  return FbqHspimQocudKlnzjRDgMatXCLSrE,FbqHspimQocudKlnzjRDgMatXCLSTY
 def ProgramidToContentid(FbqHspimQocudKlnzjRDgMatXCLSBr,FbqHspimQocudKlnzjRDgMatXCLSrw):
  FbqHspimQocudKlnzjRDgMatXCLSrU=''
  try:
   FbqHspimQocudKlnzjRDgMatXCLSBY =FbqHspimQocudKlnzjRDgMatXCLSBr.API_DOMAIN+'/vod/programs-contentid/'+FbqHspimQocudKlnzjRDgMatXCLSrw
   FbqHspimQocudKlnzjRDgMatXCLSBe=FbqHspimQocudKlnzjRDgMatXCLSBr.GetDefaultParams(login=FbqHspimQocudKlnzjRDgMatXCLSvI)
   FbqHspimQocudKlnzjRDgMatXCLSBI=FbqHspimQocudKlnzjRDgMatXCLSBr.callRequestCookies('Get',FbqHspimQocudKlnzjRDgMatXCLSBY,payload=FbqHspimQocudKlnzjRDgMatXCLSvJ,params=FbqHspimQocudKlnzjRDgMatXCLSBe,headers=FbqHspimQocudKlnzjRDgMatXCLSvJ,cookies=FbqHspimQocudKlnzjRDgMatXCLSvJ)
   FbqHspimQocudKlnzjRDgMatXCLSre=json.loads(FbqHspimQocudKlnzjRDgMatXCLSBI.text)
   if not('contentid' in FbqHspimQocudKlnzjRDgMatXCLSre):return FbqHspimQocudKlnzjRDgMatXCLSrU 
   FbqHspimQocudKlnzjRDgMatXCLSrU=FbqHspimQocudKlnzjRDgMatXCLSre['contentid']
  except FbqHspimQocudKlnzjRDgMatXCLSEB as exception:
   FbqHspimQocudKlnzjRDgMatXCLSET(exception)
  return FbqHspimQocudKlnzjRDgMatXCLSrU
 def ContentidToProgramid(FbqHspimQocudKlnzjRDgMatXCLSBr,FbqHspimQocudKlnzjRDgMatXCLSrU):
  FbqHspimQocudKlnzjRDgMatXCLSrw=''
  try:
   FbqHspimQocudKlnzjRDgMatXCLSBY =FbqHspimQocudKlnzjRDgMatXCLSBr.API_DOMAIN+'/cf/vod/contents/'+FbqHspimQocudKlnzjRDgMatXCLSrU
   FbqHspimQocudKlnzjRDgMatXCLSBe=FbqHspimQocudKlnzjRDgMatXCLSBr.GetDefaultParams(login=FbqHspimQocudKlnzjRDgMatXCLSvI)
   FbqHspimQocudKlnzjRDgMatXCLSBI=FbqHspimQocudKlnzjRDgMatXCLSBr.callRequestCookies('Get',FbqHspimQocudKlnzjRDgMatXCLSBY,payload=FbqHspimQocudKlnzjRDgMatXCLSvJ,params=FbqHspimQocudKlnzjRDgMatXCLSBe,headers=FbqHspimQocudKlnzjRDgMatXCLSvJ,cookies=FbqHspimQocudKlnzjRDgMatXCLSvJ)
   FbqHspimQocudKlnzjRDgMatXCLSre=json.loads(FbqHspimQocudKlnzjRDgMatXCLSBI.text)
   if not('programid' in FbqHspimQocudKlnzjRDgMatXCLSre):return FbqHspimQocudKlnzjRDgMatXCLSrw 
   FbqHspimQocudKlnzjRDgMatXCLSrw=FbqHspimQocudKlnzjRDgMatXCLSre['programid']
  except FbqHspimQocudKlnzjRDgMatXCLSEB as exception:
   FbqHspimQocudKlnzjRDgMatXCLSET(exception)
  return FbqHspimQocudKlnzjRDgMatXCLSrw
 def GetProgramInfo(FbqHspimQocudKlnzjRDgMatXCLSBr,program_code):
  FbqHspimQocudKlnzjRDgMatXCLSrk={}
  try:
   FbqHspimQocudKlnzjRDgMatXCLSBY=FbqHspimQocudKlnzjRDgMatXCLSBr.API_DOMAIN+'/cf/vod/contents/'+program_code
   FbqHspimQocudKlnzjRDgMatXCLSBe=FbqHspimQocudKlnzjRDgMatXCLSBr.GetDefaultParams(login=FbqHspimQocudKlnzjRDgMatXCLSvI)
   FbqHspimQocudKlnzjRDgMatXCLSBI=FbqHspimQocudKlnzjRDgMatXCLSBr.callRequestCookies('Get',FbqHspimQocudKlnzjRDgMatXCLSBY,payload=FbqHspimQocudKlnzjRDgMatXCLSvJ,params=FbqHspimQocudKlnzjRDgMatXCLSBe,headers=FbqHspimQocudKlnzjRDgMatXCLSvJ,cookies=FbqHspimQocudKlnzjRDgMatXCLSvJ)
   FbqHspimQocudKlnzjRDgMatXCLSre=json.loads(FbqHspimQocudKlnzjRDgMatXCLSBI.text)
   FbqHspimQocudKlnzjRDgMatXCLSET(FbqHspimQocudKlnzjRDgMatXCLSre)
   FbqHspimQocudKlnzjRDgMatXCLSrW=img_fanart=FbqHspimQocudKlnzjRDgMatXCLSrf=''
   if FbqHspimQocudKlnzjRDgMatXCLSre.get('programposterimage')!='':FbqHspimQocudKlnzjRDgMatXCLSrW =FbqHspimQocudKlnzjRDgMatXCLSBr.HTTPTAG+FbqHspimQocudKlnzjRDgMatXCLSre.get('programposterimage')
   if FbqHspimQocudKlnzjRDgMatXCLSre.get('programimage') !='':img_fanart =FbqHspimQocudKlnzjRDgMatXCLSBr.HTTPTAG+FbqHspimQocudKlnzjRDgMatXCLSre.get('programimage')
   if FbqHspimQocudKlnzjRDgMatXCLSre.get('programcirlceimage')!='':FbqHspimQocudKlnzjRDgMatXCLSrf=FbqHspimQocudKlnzjRDgMatXCLSBr.HTTPTAG+FbqHspimQocudKlnzjRDgMatXCLSre.get('programcirlceimage')
   if 'poster_default' in FbqHspimQocudKlnzjRDgMatXCLSrW:
    FbqHspimQocudKlnzjRDgMatXCLSrW =img_fanart
    FbqHspimQocudKlnzjRDgMatXCLSrf=''
   FbqHspimQocudKlnzjRDgMatXCLSrk={'imgPoster':FbqHspimQocudKlnzjRDgMatXCLSrW,'imgFanart':img_fanart,'imgClearlogo':FbqHspimQocudKlnzjRDgMatXCLSrf}
  except FbqHspimQocudKlnzjRDgMatXCLSEB as exception:
   FbqHspimQocudKlnzjRDgMatXCLSET(exception)
  return FbqHspimQocudKlnzjRDgMatXCLSrk
 def Get_Episode_List(FbqHspimQocudKlnzjRDgMatXCLSBr,FbqHspimQocudKlnzjRDgMatXCLSTA,FbqHspimQocudKlnzjRDgMatXCLSTN,page_int=1,orderby='desc'):
  FbqHspimQocudKlnzjRDgMatXCLSrP=[]
  FbqHspimQocudKlnzjRDgMatXCLSTh=FbqHspimQocudKlnzjRDgMatXCLSTO=1
  FbqHspimQocudKlnzjRDgMatXCLSTY=FbqHspimQocudKlnzjRDgMatXCLSvI
  FbqHspimQocudKlnzjRDgMatXCLSrV={}
  if FbqHspimQocudKlnzjRDgMatXCLSTN=='contentid':
   FbqHspimQocudKlnzjRDgMatXCLSrw=FbqHspimQocudKlnzjRDgMatXCLSBr.ContentidToProgramid(FbqHspimQocudKlnzjRDgMatXCLSTA)
   FbqHspimQocudKlnzjRDgMatXCLSrV=FbqHspimQocudKlnzjRDgMatXCLSBr.GetProgramInfo(FbqHspimQocudKlnzjRDgMatXCLSTA)
  else:
   FbqHspimQocudKlnzjRDgMatXCLSrw=FbqHspimQocudKlnzjRDgMatXCLSTA
   FbqHspimQocudKlnzjRDgMatXCLSrU=FbqHspimQocudKlnzjRDgMatXCLSBr.ProgramidToContentid(FbqHspimQocudKlnzjRDgMatXCLSTA)
   if FbqHspimQocudKlnzjRDgMatXCLSrU!='':FbqHspimQocudKlnzjRDgMatXCLSrV=FbqHspimQocudKlnzjRDgMatXCLSBr.GetProgramInfo(FbqHspimQocudKlnzjRDgMatXCLSrU)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   FbqHspimQocudKlnzjRDgMatXCLSBY=FbqHspimQocudKlnzjRDgMatXCLSBr.API_DOMAIN+'/vod/programs-contents/'+FbqHspimQocudKlnzjRDgMatXCLSrw
   FbqHspimQocudKlnzjRDgMatXCLSBe={}
   FbqHspimQocudKlnzjRDgMatXCLSBe['limit'] =FbqHspimQocudKlnzjRDgMatXCLSBr.EP_LIMIT
   FbqHspimQocudKlnzjRDgMatXCLSBe['offset']=FbqHspimQocudKlnzjRDgMatXCLSvO((page_int-1)*FbqHspimQocudKlnzjRDgMatXCLSBr.EP_LIMIT)
   FbqHspimQocudKlnzjRDgMatXCLSBe['orderby']=orderby 
   FbqHspimQocudKlnzjRDgMatXCLSBe.update(FbqHspimQocudKlnzjRDgMatXCLSBr.GetDefaultParams(login=FbqHspimQocudKlnzjRDgMatXCLSvI))
   FbqHspimQocudKlnzjRDgMatXCLSBI=FbqHspimQocudKlnzjRDgMatXCLSBr.callRequestCookies('Get',FbqHspimQocudKlnzjRDgMatXCLSBY,payload=FbqHspimQocudKlnzjRDgMatXCLSvJ,params=FbqHspimQocudKlnzjRDgMatXCLSBe,headers=FbqHspimQocudKlnzjRDgMatXCLSvJ,cookies=FbqHspimQocudKlnzjRDgMatXCLSvJ)
   FbqHspimQocudKlnzjRDgMatXCLSBN=json.loads(FbqHspimQocudKlnzjRDgMatXCLSBI.text)
   FbqHspimQocudKlnzjRDgMatXCLSTw=FbqHspimQocudKlnzjRDgMatXCLSBN['list']
   for FbqHspimQocudKlnzjRDgMatXCLSTk in FbqHspimQocudKlnzjRDgMatXCLSTw:
    FbqHspimQocudKlnzjRDgMatXCLSry=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',FbqHspimQocudKlnzjRDgMatXCLSTk.get('synopsis'))
    FbqHspimQocudKlnzjRDgMatXCLSrx=FbqHspimQocudKlnzjRDgMatXCLSBr.HTTPTAG+FbqHspimQocudKlnzjRDgMatXCLSTk.get('image')
    FbqHspimQocudKlnzjRDgMatXCLSrh=FbqHspimQocudKlnzjRDgMatXCLSrY=FbqHspimQocudKlnzjRDgMatXCLSrJ=''
    if FbqHspimQocudKlnzjRDgMatXCLSrV!={}:
     FbqHspimQocudKlnzjRDgMatXCLSrh =FbqHspimQocudKlnzjRDgMatXCLSrV.get('imgPoster')
     FbqHspimQocudKlnzjRDgMatXCLSrY =FbqHspimQocudKlnzjRDgMatXCLSrV.get('imgFanart')
     FbqHspimQocudKlnzjRDgMatXCLSrJ=FbqHspimQocudKlnzjRDgMatXCLSrV.get('imgClearlogo')
     FbqHspimQocudKlnzjRDgMatXCLSrI={'thumb':FbqHspimQocudKlnzjRDgMatXCLSrx,'poster':FbqHspimQocudKlnzjRDgMatXCLSrh,'fanart':FbqHspimQocudKlnzjRDgMatXCLSrY,'clearlogo':FbqHspimQocudKlnzjRDgMatXCLSrJ}
    else:
     FbqHspimQocudKlnzjRDgMatXCLSrI=FbqHspimQocudKlnzjRDgMatXCLSrx
    FbqHspimQocudKlnzjRDgMatXCLSTW={'programtitle':FbqHspimQocudKlnzjRDgMatXCLSTk.get('programtitle'),'episodetitle':FbqHspimQocudKlnzjRDgMatXCLSTk.get('episodetitle'),'episodenumber':FbqHspimQocudKlnzjRDgMatXCLSTk.get('episodenumber'),'releasedate':FbqHspimQocudKlnzjRDgMatXCLSTk.get('releasedate'),'releaseweekday':FbqHspimQocudKlnzjRDgMatXCLSTk.get('releaseweekday'),'programid':FbqHspimQocudKlnzjRDgMatXCLSTk.get('programid'),'contentid':FbqHspimQocudKlnzjRDgMatXCLSTk.get('contentid'),'age':FbqHspimQocudKlnzjRDgMatXCLSTk.get('targetage'),'playtime':FbqHspimQocudKlnzjRDgMatXCLSTk.get('playtime'),'synopsis':FbqHspimQocudKlnzjRDgMatXCLSry,'episodeactors':FbqHspimQocudKlnzjRDgMatXCLSTk.get('episodeactors').split(',')if FbqHspimQocudKlnzjRDgMatXCLSTk.get('episodeactors')!='' else[],'thumbnail':FbqHspimQocudKlnzjRDgMatXCLSrI}
    FbqHspimQocudKlnzjRDgMatXCLSrP.append(FbqHspimQocudKlnzjRDgMatXCLSTW)
   FbqHspimQocudKlnzjRDgMatXCLSTh=FbqHspimQocudKlnzjRDgMatXCLSEv(FbqHspimQocudKlnzjRDgMatXCLSBN['pagecount'])
   if FbqHspimQocudKlnzjRDgMatXCLSBN['count']:FbqHspimQocudKlnzjRDgMatXCLSTO =FbqHspimQocudKlnzjRDgMatXCLSEv(FbqHspimQocudKlnzjRDgMatXCLSBN['count'])
   else:FbqHspimQocudKlnzjRDgMatXCLSTO=FbqHspimQocudKlnzjRDgMatXCLSBr.EP_LIMIT*page_int
   FbqHspimQocudKlnzjRDgMatXCLSTY=FbqHspimQocudKlnzjRDgMatXCLSTh>FbqHspimQocudKlnzjRDgMatXCLSTO
  except FbqHspimQocudKlnzjRDgMatXCLSEB as exception:
   FbqHspimQocudKlnzjRDgMatXCLSET(exception)
   return[],FbqHspimQocudKlnzjRDgMatXCLSvI
  return FbqHspimQocudKlnzjRDgMatXCLSrP,FbqHspimQocudKlnzjRDgMatXCLSTY
 def GetEPGList(FbqHspimQocudKlnzjRDgMatXCLSBr,genre):
  FbqHspimQocudKlnzjRDgMatXCLSrN={}
  try:
   FbqHspimQocudKlnzjRDgMatXCLSrA=FbqHspimQocudKlnzjRDgMatXCLSBr.Get_Now_Datetime()
   if genre=='all':
    FbqHspimQocudKlnzjRDgMatXCLSrO =FbqHspimQocudKlnzjRDgMatXCLSrA+datetime.timedelta(hours=3)
   else:
    FbqHspimQocudKlnzjRDgMatXCLSrO =FbqHspimQocudKlnzjRDgMatXCLSrA+datetime.timedelta(hours=3)
   FbqHspimQocudKlnzjRDgMatXCLSBY=FbqHspimQocudKlnzjRDgMatXCLSBr.API_DOMAIN+'/live/epgs'
   FbqHspimQocudKlnzjRDgMatXCLSBe={'limit':'100','offset':'0','genre':genre,'startdatetime':FbqHspimQocudKlnzjRDgMatXCLSrA.strftime('%Y-%m-%d %H:00'),'enddatetime':FbqHspimQocudKlnzjRDgMatXCLSrO.strftime('%Y-%m-%d %H:00')}
   FbqHspimQocudKlnzjRDgMatXCLSBe.update(FbqHspimQocudKlnzjRDgMatXCLSBr.GetDefaultParams(login=FbqHspimQocudKlnzjRDgMatXCLSvI))
   FbqHspimQocudKlnzjRDgMatXCLSBI=FbqHspimQocudKlnzjRDgMatXCLSBr.callRequestCookies('Get',FbqHspimQocudKlnzjRDgMatXCLSBY,payload=FbqHspimQocudKlnzjRDgMatXCLSvJ,params=FbqHspimQocudKlnzjRDgMatXCLSBe,headers=FbqHspimQocudKlnzjRDgMatXCLSvJ,cookies=FbqHspimQocudKlnzjRDgMatXCLSvJ)
   FbqHspimQocudKlnzjRDgMatXCLSBN=json.loads(FbqHspimQocudKlnzjRDgMatXCLSBI.text)
   FbqHspimQocudKlnzjRDgMatXCLSvB=FbqHspimQocudKlnzjRDgMatXCLSBN['list']
   for FbqHspimQocudKlnzjRDgMatXCLSTk in FbqHspimQocudKlnzjRDgMatXCLSvB:
    FbqHspimQocudKlnzjRDgMatXCLSvT=''
    for FbqHspimQocudKlnzjRDgMatXCLSvr in FbqHspimQocudKlnzjRDgMatXCLSTk['list']:
     if FbqHspimQocudKlnzjRDgMatXCLSvT:FbqHspimQocudKlnzjRDgMatXCLSvT+='\n'
     FbqHspimQocudKlnzjRDgMatXCLSvT+=FbqHspimQocudKlnzjRDgMatXCLSBr.Get_ChangeText(FbqHspimQocudKlnzjRDgMatXCLSvr['title'])+'\n'
     FbqHspimQocudKlnzjRDgMatXCLSvT+=' [%s ~ %s]'%(FbqHspimQocudKlnzjRDgMatXCLSvr['starttime'][-5:],FbqHspimQocudKlnzjRDgMatXCLSvr['endtime'][-5:])+'\n'
    FbqHspimQocudKlnzjRDgMatXCLSrN[FbqHspimQocudKlnzjRDgMatXCLSTk['channelid']]=FbqHspimQocudKlnzjRDgMatXCLSvT
  except FbqHspimQocudKlnzjRDgMatXCLSEB as exception:
   FbqHspimQocudKlnzjRDgMatXCLSET(exception)
  return FbqHspimQocudKlnzjRDgMatXCLSrN
 def Get_LiveChannel_List(FbqHspimQocudKlnzjRDgMatXCLSBr,genre,FbqHspimQocudKlnzjRDgMatXCLSTU):
  FbqHspimQocudKlnzjRDgMatXCLSTx=[]
  (FbqHspimQocudKlnzjRDgMatXCLSBY,FbqHspimQocudKlnzjRDgMatXCLSBe)=FbqHspimQocudKlnzjRDgMatXCLSBr.Baseapi_Parse(FbqHspimQocudKlnzjRDgMatXCLSTU)
  if FbqHspimQocudKlnzjRDgMatXCLSBY=='':return FbqHspimQocudKlnzjRDgMatXCLSTx
  FbqHspimQocudKlnzjRDgMatXCLSvE=FbqHspimQocudKlnzjRDgMatXCLSBr.GetEPGList(genre)
  try:
   FbqHspimQocudKlnzjRDgMatXCLSBe.update(FbqHspimQocudKlnzjRDgMatXCLSBr.GetDefaultParams(login=FbqHspimQocudKlnzjRDgMatXCLSvI))
   FbqHspimQocudKlnzjRDgMatXCLSBe['genre']=genre
   FbqHspimQocudKlnzjRDgMatXCLSBI=FbqHspimQocudKlnzjRDgMatXCLSBr.callRequestCookies('Get',FbqHspimQocudKlnzjRDgMatXCLSBY,payload=FbqHspimQocudKlnzjRDgMatXCLSvJ,params=FbqHspimQocudKlnzjRDgMatXCLSBe,headers=FbqHspimQocudKlnzjRDgMatXCLSvJ,cookies=FbqHspimQocudKlnzjRDgMatXCLSvJ)
   FbqHspimQocudKlnzjRDgMatXCLSBN=json.loads(FbqHspimQocudKlnzjRDgMatXCLSBI.text)
   if not('celllist' in FbqHspimQocudKlnzjRDgMatXCLSBN['cell_toplist']):return[]
   FbqHspimQocudKlnzjRDgMatXCLSTw=FbqHspimQocudKlnzjRDgMatXCLSBN['cell_toplist']['celllist']
   for FbqHspimQocudKlnzjRDgMatXCLSTk in FbqHspimQocudKlnzjRDgMatXCLSTw:
    FbqHspimQocudKlnzjRDgMatXCLSrU=FbqHspimQocudKlnzjRDgMatXCLSTk['contentid']
    if FbqHspimQocudKlnzjRDgMatXCLSrU in FbqHspimQocudKlnzjRDgMatXCLSvE:
     FbqHspimQocudKlnzjRDgMatXCLSvU=FbqHspimQocudKlnzjRDgMatXCLSvE[FbqHspimQocudKlnzjRDgMatXCLSrU]
    else:
     FbqHspimQocudKlnzjRDgMatXCLSvU=''
    FbqHspimQocudKlnzjRDgMatXCLSTW={'studio':FbqHspimQocudKlnzjRDgMatXCLSTk['title_list'][0]['text'],'tvshowtitle':FbqHspimQocudKlnzjRDgMatXCLSBr.Get_ChangeText(FbqHspimQocudKlnzjRDgMatXCLSTk['title_list'][1]['text']),'channelid':FbqHspimQocudKlnzjRDgMatXCLSrU,'age':FbqHspimQocudKlnzjRDgMatXCLSTk['age'],'thumbnail':'https://%s'%FbqHspimQocudKlnzjRDgMatXCLSTk.get('thumbnail'),'epg':FbqHspimQocudKlnzjRDgMatXCLSvU}
    FbqHspimQocudKlnzjRDgMatXCLSTx.append(FbqHspimQocudKlnzjRDgMatXCLSTW)
  except FbqHspimQocudKlnzjRDgMatXCLSEB as exception:
   FbqHspimQocudKlnzjRDgMatXCLSET(exception)
   return[]
  return FbqHspimQocudKlnzjRDgMatXCLSTx
 def Get_Search_List(FbqHspimQocudKlnzjRDgMatXCLSBr,search_key,sType,page_int,exclusion21=FbqHspimQocudKlnzjRDgMatXCLSvI):
  FbqHspimQocudKlnzjRDgMatXCLSve=[]
  FbqHspimQocudKlnzjRDgMatXCLSTh=FbqHspimQocudKlnzjRDgMatXCLSTO=1
  FbqHspimQocudKlnzjRDgMatXCLSTY=FbqHspimQocudKlnzjRDgMatXCLSvI
  try:
   FbqHspimQocudKlnzjRDgMatXCLSBY=FbqHspimQocudKlnzjRDgMatXCLSBr.API_DOMAIN+'/cf/search/list.js'
   FbqHspimQocudKlnzjRDgMatXCLSBe={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':FbqHspimQocudKlnzjRDgMatXCLSvO((page_int-1)*FbqHspimQocudKlnzjRDgMatXCLSBr.SEARCH_LIMIT),'limit':FbqHspimQocudKlnzjRDgMatXCLSBr.SEARCH_LIMIT,'orderby':'score'}
   FbqHspimQocudKlnzjRDgMatXCLSBe.update(FbqHspimQocudKlnzjRDgMatXCLSBr.GetDefaultParams(login=FbqHspimQocudKlnzjRDgMatXCLSvI))
   FbqHspimQocudKlnzjRDgMatXCLSBI=FbqHspimQocudKlnzjRDgMatXCLSBr.callRequestCookies('Get',FbqHspimQocudKlnzjRDgMatXCLSBY,payload=FbqHspimQocudKlnzjRDgMatXCLSvJ,params=FbqHspimQocudKlnzjRDgMatXCLSBe,headers=FbqHspimQocudKlnzjRDgMatXCLSvJ,cookies=FbqHspimQocudKlnzjRDgMatXCLSvJ)
   FbqHspimQocudKlnzjRDgMatXCLSre=json.loads(FbqHspimQocudKlnzjRDgMatXCLSBI.text)
   if not('celllist' in FbqHspimQocudKlnzjRDgMatXCLSre['cell_toplist']):return FbqHspimQocudKlnzjRDgMatXCLSve,FbqHspimQocudKlnzjRDgMatXCLSTY
   FbqHspimQocudKlnzjRDgMatXCLSTw=FbqHspimQocudKlnzjRDgMatXCLSre['cell_toplist']['celllist']
   for FbqHspimQocudKlnzjRDgMatXCLSTk in FbqHspimQocudKlnzjRDgMatXCLSTw:
    FbqHspimQocudKlnzjRDgMatXCLSTJ =FbqHspimQocudKlnzjRDgMatXCLSTk['event_list'][1]['url']
    FbqHspimQocudKlnzjRDgMatXCLSTI=urllib.parse.urlsplit(FbqHspimQocudKlnzjRDgMatXCLSTJ).query
    FbqHspimQocudKlnzjRDgMatXCLSTN=FbqHspimQocudKlnzjRDgMatXCLSTI[0:FbqHspimQocudKlnzjRDgMatXCLSTI.find('=')]
    FbqHspimQocudKlnzjRDgMatXCLSTA=FbqHspimQocudKlnzjRDgMatXCLSTI[FbqHspimQocudKlnzjRDgMatXCLSTI.find('=')+1:]
    FbqHspimQocudKlnzjRDgMatXCLSTW={'title':FbqHspimQocudKlnzjRDgMatXCLSTk['title_list'][0]['text'],'age':FbqHspimQocudKlnzjRDgMatXCLSTk['age'],'thumbnail':'https://%s'%FbqHspimQocudKlnzjRDgMatXCLSTk.get('thumbnail'),'videoid':FbqHspimQocudKlnzjRDgMatXCLSTA,'vidtype':FbqHspimQocudKlnzjRDgMatXCLSTN}
    if exclusion21==FbqHspimQocudKlnzjRDgMatXCLSvI or FbqHspimQocudKlnzjRDgMatXCLSTk.get('age')!='21':
     FbqHspimQocudKlnzjRDgMatXCLSve.append(FbqHspimQocudKlnzjRDgMatXCLSTW)
   FbqHspimQocudKlnzjRDgMatXCLSTh=FbqHspimQocudKlnzjRDgMatXCLSEv(FbqHspimQocudKlnzjRDgMatXCLSre['cell_toplist']['pagecount'])
   if FbqHspimQocudKlnzjRDgMatXCLSre['cell_toplist']['count']:FbqHspimQocudKlnzjRDgMatXCLSTO =FbqHspimQocudKlnzjRDgMatXCLSEv(FbqHspimQocudKlnzjRDgMatXCLSre['cell_toplist']['count'])
   else:FbqHspimQocudKlnzjRDgMatXCLSTO=FbqHspimQocudKlnzjRDgMatXCLSBr.LIST_LIMIT
   FbqHspimQocudKlnzjRDgMatXCLSTY=FbqHspimQocudKlnzjRDgMatXCLSTh>FbqHspimQocudKlnzjRDgMatXCLSTO
  except FbqHspimQocudKlnzjRDgMatXCLSEB as exception:
   FbqHspimQocudKlnzjRDgMatXCLSET(exception)
  return FbqHspimQocudKlnzjRDgMatXCLSve,FbqHspimQocudKlnzjRDgMatXCLSTY 
 def GetStreamingURL(FbqHspimQocudKlnzjRDgMatXCLSBr,mode,FbqHspimQocudKlnzjRDgMatXCLSrU,quality_int,pvrmode='-'):
  FbqHspimQocudKlnzjRDgMatXCLSvw=FbqHspimQocudKlnzjRDgMatXCLSvx=FbqHspimQocudKlnzjRDgMatXCLSvh=streaming_preview=''
  FbqHspimQocudKlnzjRDgMatXCLSvk=[]
  FbqHspimQocudKlnzjRDgMatXCLSvW='hls'
  if mode=='LIVE':
   FbqHspimQocudKlnzjRDgMatXCLSBY =FbqHspimQocudKlnzjRDgMatXCLSBr.API_DOMAIN+'/live/channels/'+FbqHspimQocudKlnzjRDgMatXCLSrU
   FbqHspimQocudKlnzjRDgMatXCLSvf='live'
  elif mode=='VOD':
   FbqHspimQocudKlnzjRDgMatXCLSBY =FbqHspimQocudKlnzjRDgMatXCLSBr.API_DOMAIN+'/cf/vod/contents/'+FbqHspimQocudKlnzjRDgMatXCLSrU
   FbqHspimQocudKlnzjRDgMatXCLSvf='vod'
  elif mode=='MOVIE':
   FbqHspimQocudKlnzjRDgMatXCLSBY =FbqHspimQocudKlnzjRDgMatXCLSBr.API_DOMAIN+'/cf/movie/contents/'+FbqHspimQocudKlnzjRDgMatXCLSrU
   FbqHspimQocudKlnzjRDgMatXCLSvf='movie'
  try:
   if mode!='LIVE' or pvrmode=='-':
    FbqHspimQocudKlnzjRDgMatXCLSBe=FbqHspimQocudKlnzjRDgMatXCLSBr.GetDefaultParams(login=FbqHspimQocudKlnzjRDgMatXCLSvI)
    FbqHspimQocudKlnzjRDgMatXCLSBI=FbqHspimQocudKlnzjRDgMatXCLSBr.callRequestCookies('Get',FbqHspimQocudKlnzjRDgMatXCLSBY,payload=FbqHspimQocudKlnzjRDgMatXCLSvJ,params=FbqHspimQocudKlnzjRDgMatXCLSBe,headers=FbqHspimQocudKlnzjRDgMatXCLSvJ,cookies=FbqHspimQocudKlnzjRDgMatXCLSvJ)
    FbqHspimQocudKlnzjRDgMatXCLSBN=json.loads(FbqHspimQocudKlnzjRDgMatXCLSBI.text)
    FbqHspimQocudKlnzjRDgMatXCLSvP=FbqHspimQocudKlnzjRDgMatXCLSBN['qualities']['list']
    if FbqHspimQocudKlnzjRDgMatXCLSvP==FbqHspimQocudKlnzjRDgMatXCLSvJ:return(FbqHspimQocudKlnzjRDgMatXCLSvw,FbqHspimQocudKlnzjRDgMatXCLSvx,FbqHspimQocudKlnzjRDgMatXCLSvh,streaming_preview)
    for FbqHspimQocudKlnzjRDgMatXCLSvV in FbqHspimQocudKlnzjRDgMatXCLSvP:
     FbqHspimQocudKlnzjRDgMatXCLSvk.append(FbqHspimQocudKlnzjRDgMatXCLSEv(FbqHspimQocudKlnzjRDgMatXCLSvV.get('id').rstrip('p')))
    if 'type' in FbqHspimQocudKlnzjRDgMatXCLSBN:
     if FbqHspimQocudKlnzjRDgMatXCLSBN['type']=='onair':
      FbqHspimQocudKlnzjRDgMatXCLSvf='onairvod'
    if 'drms' in FbqHspimQocudKlnzjRDgMatXCLSBN:
     if FbqHspimQocudKlnzjRDgMatXCLSBN['drms']:
      FbqHspimQocudKlnzjRDgMatXCLSvW='dash'
  except FbqHspimQocudKlnzjRDgMatXCLSEB as exception:
   FbqHspimQocudKlnzjRDgMatXCLSET(exception)
   return(FbqHspimQocudKlnzjRDgMatXCLSvw,FbqHspimQocudKlnzjRDgMatXCLSvx,FbqHspimQocudKlnzjRDgMatXCLSvh,streaming_preview)
  try:
   FbqHspimQocudKlnzjRDgMatXCLSvG=FbqHspimQocudKlnzjRDgMatXCLSBr.CheckQuality(quality_int,FbqHspimQocudKlnzjRDgMatXCLSvk)
   if mode=='LIVE' and pvrmode!='-':
    FbqHspimQocudKlnzjRDgMatXCLSvy='auto'
   else:
    FbqHspimQocudKlnzjRDgMatXCLSvy=FbqHspimQocudKlnzjRDgMatXCLSvO(FbqHspimQocudKlnzjRDgMatXCLSvG)+'p'
   FbqHspimQocudKlnzjRDgMatXCLSBY=FbqHspimQocudKlnzjRDgMatXCLSBr.API_DOMAIN+'/streaming'
   FbqHspimQocudKlnzjRDgMatXCLSBe={'contentid':FbqHspimQocudKlnzjRDgMatXCLSrU,'contenttype':FbqHspimQocudKlnzjRDgMatXCLSvf,'action':FbqHspimQocudKlnzjRDgMatXCLSvW,'quality':FbqHspimQocudKlnzjRDgMatXCLSvy,'deviceModelId':'Windows 10','guid':FbqHspimQocudKlnzjRDgMatXCLSBr.GetGUID(guidType=2),'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n'}
   FbqHspimQocudKlnzjRDgMatXCLSBe.update(FbqHspimQocudKlnzjRDgMatXCLSBr.GetDefaultParams(login=FbqHspimQocudKlnzjRDgMatXCLSvN))
   FbqHspimQocudKlnzjRDgMatXCLSBI=FbqHspimQocudKlnzjRDgMatXCLSBr.callRequestCookies('Get',FbqHspimQocudKlnzjRDgMatXCLSBY,payload=FbqHspimQocudKlnzjRDgMatXCLSvJ,params=FbqHspimQocudKlnzjRDgMatXCLSBe,headers=FbqHspimQocudKlnzjRDgMatXCLSvJ,cookies=FbqHspimQocudKlnzjRDgMatXCLSvJ)
   FbqHspimQocudKlnzjRDgMatXCLSBN=json.loads(FbqHspimQocudKlnzjRDgMatXCLSBI.text)
   FbqHspimQocudKlnzjRDgMatXCLSvw=FbqHspimQocudKlnzjRDgMatXCLSBN['playurl']
   if FbqHspimQocudKlnzjRDgMatXCLSvw==FbqHspimQocudKlnzjRDgMatXCLSvJ:return(FbqHspimQocudKlnzjRDgMatXCLSvw,FbqHspimQocudKlnzjRDgMatXCLSvx,FbqHspimQocudKlnzjRDgMatXCLSvh,streaming_preview)
   FbqHspimQocudKlnzjRDgMatXCLSvx=FbqHspimQocudKlnzjRDgMatXCLSBN['awscookie']
   FbqHspimQocudKlnzjRDgMatXCLSvh =FbqHspimQocudKlnzjRDgMatXCLSBN['drm']
   if 'previewmsg' in FbqHspimQocudKlnzjRDgMatXCLSBN['preview']:streaming_preview=FbqHspimQocudKlnzjRDgMatXCLSBN['preview']['previewmsg']
  except FbqHspimQocudKlnzjRDgMatXCLSEB as exception:
   FbqHspimQocudKlnzjRDgMatXCLSET(exception)
  return(FbqHspimQocudKlnzjRDgMatXCLSvw,FbqHspimQocudKlnzjRDgMatXCLSvx,FbqHspimQocudKlnzjRDgMatXCLSvh,streaming_preview) 
# Created by pyminifier (https://github.com/liftoff/pyminifier)
