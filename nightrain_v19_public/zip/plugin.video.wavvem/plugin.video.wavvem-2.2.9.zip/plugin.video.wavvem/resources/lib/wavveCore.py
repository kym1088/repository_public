__author__="NightRain"
dwYFCTRLPBoJMzeUqQlyNWiEvfnbDA=object
dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK=None
dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm=False
dwYFCTRLPBoJMzeUqQlyNWiEvfnbDt=open
dwYFCTRLPBoJMzeUqQlyNWiEvfnbDp=True
dwYFCTRLPBoJMzeUqQlyNWiEvfnbDx=range
dwYFCTRLPBoJMzeUqQlyNWiEvfnbDk=str
dwYFCTRLPBoJMzeUqQlyNWiEvfnbDG=Exception
dwYFCTRLPBoJMzeUqQlyNWiEvfnbDc=print
dwYFCTRLPBoJMzeUqQlyNWiEvfnbDu=dict
dwYFCTRLPBoJMzeUqQlyNWiEvfnbDO=int
dwYFCTRLPBoJMzeUqQlyNWiEvfnbDI=len
import urllib
import re
import json
import sys
import requests
import datetime
import base64
class dwYFCTRLPBoJMzeUqQlyNWiEvfnbgA(dwYFCTRLPBoJMzeUqQlyNWiEvfnbDA):
 def __init__(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK):
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.API_DOMAIN='https://apis.wavve.com'
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.WV ={}
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.Init_WV_Total()
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.DEVICE ='pc'
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.DRM ='wm'
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.PARTNER ='pooq'
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.POOQZONE ='none'
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.REGION ='kor'
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.TARGETAGE ='all'
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.HTTPTAG ='https://'
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.LIST_LIMIT=30 
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.EP_LIMIT =30 
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.MV_LIMIT =24 
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.SEARCH_LIMIT=20 
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.82 Safari/537.36'
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.DEFAULT_HEADER={'user-agent':dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.USER_AGENT}
 def Init_WV_Total(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK):
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.WV={'account':{},'cookies':{},}
 def callRequestCookies(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK,jobtype,dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,payload=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,params=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,headers=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,cookies=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,redirects=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm):
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbgm=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.DEFAULT_HEADER
  if headers:dwYFCTRLPBoJMzeUqQlyNWiEvfnbgm.update(headers)
  if jobtype=='Get':
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgt=requests.get(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,params=params,headers=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgm,cookies=cookies,allow_redirects=redirects)
  else:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgt=requests.post(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,data=payload,params=params,headers=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgm,cookies=cookies,allow_redirects=redirects)
  return dwYFCTRLPBoJMzeUqQlyNWiEvfnbgt
 def JsonFile_Save(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK,filename,dwYFCTRLPBoJMzeUqQlyNWiEvfnbgD):
  if filename=='':return dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm
  try:
   fp=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDt(filename,'w',-1,'utf-8')
   json.dump(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgD,fp,indent=4,ensure_ascii=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm)
   fp.close()
  except:
   return dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm
  return dwYFCTRLPBoJMzeUqQlyNWiEvfnbDp
 def JsonFile_Load(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK,filename):
  if filename=='':return{}
  try:
   fp=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDt(filename,'r',-1,'utf-8')
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgx=json.load(fp)
   fp.close()
  except:
   return{}
  return dwYFCTRLPBoJMzeUqQlyNWiEvfnbgx
 def Save_session_acount(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK,dwYFCTRLPBoJMzeUqQlyNWiEvfnbgk,dwYFCTRLPBoJMzeUqQlyNWiEvfnbgG,dwYFCTRLPBoJMzeUqQlyNWiEvfnbgc):
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.WV['account']['wvid']=base64.standard_b64encode(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgk.encode()).decode('utf-8')
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.WV['account']['wvpw']=base64.standard_b64encode(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgG.encode()).decode('utf-8')
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.WV['account']['wvpf']=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgc 
 def Load_session_acount(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK):
  try:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgk=base64.standard_b64decode(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.WV['account']['wvid']).decode('utf-8')
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgG=base64.standard_b64decode(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.WV['account']['wvpw']).decode('utf-8')
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgc=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.WV['account']['wvpf']
  except:
   return '','',0
  return dwYFCTRLPBoJMzeUqQlyNWiEvfnbgk,dwYFCTRLPBoJMzeUqQlyNWiEvfnbgG,dwYFCTRLPBoJMzeUqQlyNWiEvfnbgc
 def GetDefaultParams(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK,login=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDp):
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu={'apikey':dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.APIKEY,'credential':dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.WV['cookies']['credential']if login else 'none','device':dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.DEVICE,'drm':dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.DRM,'partner':dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.PARTNER,'pooqzone':dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.POOQZONE,'region':dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.REGION,'targetage':dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.TARGETAGE}
  return dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu
 def GetGUID(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgO=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgI=GenerateRandomString(5)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgX=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgI+media+dwYFCTRLPBoJMzeUqQlyNWiEvfnbgO
   return dwYFCTRLPBoJMzeUqQlyNWiEvfnbgX
  def GenerateRandomString(num):
   from random import randint
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgj=""
   for i in dwYFCTRLPBoJMzeUqQlyNWiEvfnbDx(0,num):
    s=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDk(randint(1,5))
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbgj+=s
   return dwYFCTRLPBoJMzeUqQlyNWiEvfnbgj
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbgX=GenerateID(guid_str)
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbga=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.GetHash(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgX)
  if guidType==2:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbga='%s-%s-%s-%s-%s'%(dwYFCTRLPBoJMzeUqQlyNWiEvfnbga[:8],dwYFCTRLPBoJMzeUqQlyNWiEvfnbga[8:12],dwYFCTRLPBoJMzeUqQlyNWiEvfnbga[12:16],dwYFCTRLPBoJMzeUqQlyNWiEvfnbga[16:20],dwYFCTRLPBoJMzeUqQlyNWiEvfnbga[20:])
  return dwYFCTRLPBoJMzeUqQlyNWiEvfnbga
 def GetHash(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return dwYFCTRLPBoJMzeUqQlyNWiEvfnbDk(m.hexdigest())
 def CheckQuality(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK,sel_qt,qt_list):
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbgh=0
  for dwYFCTRLPBoJMzeUqQlyNWiEvfnbgV in qt_list:
   if sel_qt>=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgV:return dwYFCTRLPBoJMzeUqQlyNWiEvfnbgV
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgh=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgV
  return dwYFCTRLPBoJMzeUqQlyNWiEvfnbgh
 def Get_Now_Datetime(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK,in_text):
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbgH=in_text.replace('&lt;','<').replace('&gt;','>')
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbgH=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgH.replace('$O$','')
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbgH=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',dwYFCTRLPBoJMzeUqQlyNWiEvfnbgH)
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbgH=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgH.lstrip('#')
  return dwYFCTRLPBoJMzeUqQlyNWiEvfnbgH
 def GetCredential(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK,user_id,user_pw,user_pf):
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbgs=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm
  try:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.API_DOMAIN+ '/login'
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.GetDefaultParams(login=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAg={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.callRequestCookies('Post',dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,payload=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAg,params=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu,headers=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,cookies=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm=json.loads(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK.text)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.WV['cookies']['credential']=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['credential']
   if user_pf!=0:
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbAg={'id':dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.WV['cookies']['credential'],'password':'','profile':dwYFCTRLPBoJMzeUqQlyNWiEvfnbDk(user_pf),'pushid':'','type':'credential'}
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu =dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.GetDefaultParams(login=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDp) 
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.callRequestCookies('Post',dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,payload=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAg,params=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu,headers=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,cookies=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK)
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm=json.loads(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK.text)
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.WV['cookies']['credential']=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['credential']
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgs=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDp
  except dwYFCTRLPBoJMzeUqQlyNWiEvfnbDG as exception:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbDc(exception)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.Init_WV_Total()
  return dwYFCTRLPBoJMzeUqQlyNWiEvfnbgs
 def GetIssue(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK):
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbAt=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm
  try:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.API_DOMAIN+'/guid/issue'
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.GetDefaultParams()
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.callRequestCookies('Get',dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,payload=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,params=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu,headers=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,cookies=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm=json.loads(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK.text)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAD=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['guid']
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAp=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['guidtimestamp']
   if dwYFCTRLPBoJMzeUqQlyNWiEvfnbAD:dwYFCTRLPBoJMzeUqQlyNWiEvfnbAt=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDp
  except dwYFCTRLPBoJMzeUqQlyNWiEvfnbDG as exception:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbDc(exception)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAD='none'
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAp='none' 
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.guid=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAD
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.guidtimestamp=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAp
  return dwYFCTRLPBoJMzeUqQlyNWiEvfnbAt
 def Baseapi_Parse(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK,dwYFCTRLPBoJMzeUqQlyNWiEvfnbAc):
  try:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAx =urllib.parse.urlsplit(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAc)
   if dwYFCTRLPBoJMzeUqQlyNWiEvfnbAx.netloc=='':
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.HTTPTAG+dwYFCTRLPBoJMzeUqQlyNWiEvfnbAx.netloc+dwYFCTRLPBoJMzeUqQlyNWiEvfnbAx.path
   else:
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAx.scheme+'://'+dwYFCTRLPBoJMzeUqQlyNWiEvfnbAx.netloc+dwYFCTRLPBoJMzeUqQlyNWiEvfnbAx.path
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDu(urllib.parse.parse_qsl(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAx.query))
  except dwYFCTRLPBoJMzeUqQlyNWiEvfnbDG as exception:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbDc(exception)
   return '',{}
  return dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu
 def GetSupermultiUrl(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK,sCode,sIndex='0'):
  try:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.API_DOMAIN+'/cf/supermultisections/'+sCode
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.GetDefaultParams(login=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.callRequestCookies('Get',dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,payload=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,params=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu,headers=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,cookies=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm=json.loads(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK.text)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAk=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['multisectionlist'][dwYFCTRLPBoJMzeUqQlyNWiEvfnbDO(sIndex)]['eventlist'][1]['url']
  except dwYFCTRLPBoJMzeUqQlyNWiEvfnbDG as exception:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbDc(exception)
   return ''
  return dwYFCTRLPBoJMzeUqQlyNWiEvfnbAk
 def Get_LiveCatagory_List(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK,sCode,sIndex='0'):
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbAG=[]
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbAc =dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.GetSupermultiUrl(sCode,sIndex)
  (dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu)=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.Baseapi_Parse(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAc)
  if dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS=='':return dwYFCTRLPBoJMzeUqQlyNWiEvfnbAG,''
  try:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu.update(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.GetDefaultParams(login=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm))
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.callRequestCookies('Get',dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,payload=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,params=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu,headers=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,cookies=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm=json.loads(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK.text)
   if not('filter_item_list' in dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['filter']['filterlist'][0]):return[],''
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAO=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['filter']['filterlist'][0]['filter_item_list']
   for dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI in dwYFCTRLPBoJMzeUqQlyNWiEvfnbAO:
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbAX={'title':dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI['title'],'genre':dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI['api_parameters'][dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI['api_parameters'].index('=')+1:]}
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbAG.append(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAX)
  except dwYFCTRLPBoJMzeUqQlyNWiEvfnbDG as exception:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbDc(exception)
   return[],''
  return dwYFCTRLPBoJMzeUqQlyNWiEvfnbAG,dwYFCTRLPBoJMzeUqQlyNWiEvfnbAc
 def Get_MainCatagory_List(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK,sCode,sIndex='0'):
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbAG=[]
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbAc =dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.GetSupermultiUrl(sCode,sIndex)
  (dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu)=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.Baseapi_Parse(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAc)
  if dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS=='':return dwYFCTRLPBoJMzeUqQlyNWiEvfnbAG
  try:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu.update(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.GetDefaultParams(login=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm))
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.callRequestCookies('Get',dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,payload=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,params=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu,headers=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,cookies=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm=json.loads(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK.text)
   if not('celllist' in dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['band']):return[]
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAO=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['band']['celllist']
   for dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI in dwYFCTRLPBoJMzeUqQlyNWiEvfnbAO:
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbAj =dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI['event_list'][1]['url']
    (dwYFCTRLPBoJMzeUqQlyNWiEvfnbAa,dwYFCTRLPBoJMzeUqQlyNWiEvfnbAh)=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.Baseapi_Parse(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAj)
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbAX={'title':dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI['title_list'][0]['text'],'suburl':dwYFCTRLPBoJMzeUqQlyNWiEvfnbAa,'subapi':dwYFCTRLPBoJMzeUqQlyNWiEvfnbAh.get('api'),'subtype':'catagory' if dwYFCTRLPBoJMzeUqQlyNWiEvfnbAh else 'supersection'}
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbAG.append(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAX)
  except dwYFCTRLPBoJMzeUqQlyNWiEvfnbDG as exception:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbDc(exception)
   return[]
  return dwYFCTRLPBoJMzeUqQlyNWiEvfnbAG
 def Get_SuperMultiSection_List(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK,subapi_text):
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbAG=[]
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu={}
  try:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAx =urllib.parse.urlsplit(subapi_text)
   if dwYFCTRLPBoJMzeUqQlyNWiEvfnbAx.path.find('apis.wavve.com')>=0: 
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.HTTPTAG+dwYFCTRLPBoJMzeUqQlyNWiEvfnbAx.path 
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDu(urllib.parse.parse_qsl(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAx.query))
   else:
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.API_DOMAIN+'/cf'+dwYFCTRLPBoJMzeUqQlyNWiEvfnbAx.path 
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS.replace('supermultisection/','supermultisections/')
  except dwYFCTRLPBoJMzeUqQlyNWiEvfnbDG as exception:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbDc(exception)
   return[]
  try:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu.update(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.GetDefaultParams(login=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm))
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.callRequestCookies('Get',dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,payload=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,params=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,headers=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,cookies=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm=json.loads(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK.text)
   if not('multisectionlist' in dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm):return[]
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAO=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['multisectionlist']
   for dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI in dwYFCTRLPBoJMzeUqQlyNWiEvfnbAO:
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbAV=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI['title']
    if dwYFCTRLPBoJMzeUqQlyNWiEvfnbDI(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAV)==0:continue
    if dwYFCTRLPBoJMzeUqQlyNWiEvfnbAV=='minor':continue
    if re.search(u'베너',dwYFCTRLPBoJMzeUqQlyNWiEvfnbAV):continue
    if re.search(u'배너',dwYFCTRLPBoJMzeUqQlyNWiEvfnbAV):continue 
    if dwYFCTRLPBoJMzeUqQlyNWiEvfnbDI(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI['eventlist'])>=3:
     dwYFCTRLPBoJMzeUqQlyNWiEvfnbAh =dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI['eventlist'][2]['url']
    else:
     dwYFCTRLPBoJMzeUqQlyNWiEvfnbAh =dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI['eventlist'][1]['url']
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbAr=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI['cell_type']
    if dwYFCTRLPBoJMzeUqQlyNWiEvfnbAr=='band_2':
     if dwYFCTRLPBoJMzeUqQlyNWiEvfnbAh.find('channellist=')>=0:
      dwYFCTRLPBoJMzeUqQlyNWiEvfnbAr='band_live'
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbAX={'title':dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.Get_ChangeText(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAV),'subapi':dwYFCTRLPBoJMzeUqQlyNWiEvfnbAh,'cell_type':dwYFCTRLPBoJMzeUqQlyNWiEvfnbAr}
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbAG.append(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAX)
  except dwYFCTRLPBoJMzeUqQlyNWiEvfnbDG as exception:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbDc(exception)
   return[]
  return dwYFCTRLPBoJMzeUqQlyNWiEvfnbAG
 def Get_BandLiveSection_List(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK,dwYFCTRLPBoJMzeUqQlyNWiEvfnbAc,page_int=1):
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbAH=[]
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbAs=dwYFCTRLPBoJMzeUqQlyNWiEvfnbKD=1
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbAS=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm
  try:
   (dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu)=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.Baseapi_Parse(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAc)
  except dwYFCTRLPBoJMzeUqQlyNWiEvfnbDG as exception:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbDc(exception)
   return[],dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm
  try:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu['limit']=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.LIST_LIMIT
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu['offset']=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDk((page_int-1)*dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.LIST_LIMIT)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu.update(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.GetDefaultParams(login=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm))
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.callRequestCookies('Get',dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,payload=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,params=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu,headers=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,cookies=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm=json.loads(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK.text)
   if not('celllist' in dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['cell_toplist']):return[],dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAO=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['cell_toplist']['celllist']
   for dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI in dwYFCTRLPBoJMzeUqQlyNWiEvfnbAO:
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKg =dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI['event_list'][1]['url']
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKA=urllib.parse.urlsplit(dwYFCTRLPBoJMzeUqQlyNWiEvfnbKg).query
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKA=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDu(urllib.parse.parse_qsl(dwYFCTRLPBoJMzeUqQlyNWiEvfnbKA))
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKm='channelid'
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKt=dwYFCTRLPBoJMzeUqQlyNWiEvfnbKA[dwYFCTRLPBoJMzeUqQlyNWiEvfnbKm]
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbAX={'studio':dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI['title_list'][0]['text'],'tvshowtitle':dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.Get_ChangeText(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI['title_list'][1]['text']),'channelid':dwYFCTRLPBoJMzeUqQlyNWiEvfnbKt,'age':dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI.get('age'),'thumbnail':'https://%s'%dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI.get('thumbnail')}
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbAH.append(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAX)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAs=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDO(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['cell_toplist']['pagecount'])
   if dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['cell_toplist']['count']:dwYFCTRLPBoJMzeUqQlyNWiEvfnbKD =dwYFCTRLPBoJMzeUqQlyNWiEvfnbDO(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['cell_toplist']['count'])
   else:dwYFCTRLPBoJMzeUqQlyNWiEvfnbKD=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.LIST_LIMIT*page_int
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAS=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAs>dwYFCTRLPBoJMzeUqQlyNWiEvfnbKD
  except dwYFCTRLPBoJMzeUqQlyNWiEvfnbDG as exception:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbDc(exception)
   return[],dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm
  return dwYFCTRLPBoJMzeUqQlyNWiEvfnbAH,dwYFCTRLPBoJMzeUqQlyNWiEvfnbAS
 def Get_Band2Section_List(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK,dwYFCTRLPBoJMzeUqQlyNWiEvfnbAc,page_int=1):
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbKp=[]
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbAs=dwYFCTRLPBoJMzeUqQlyNWiEvfnbKD=1
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbAS=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm
  try:
   (dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu)=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.Baseapi_Parse(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAc)
  except dwYFCTRLPBoJMzeUqQlyNWiEvfnbDG as exception:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbDc(exception)
   return[],dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm
  try:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu['came'] ='BandView'
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu['limit']=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.LIST_LIMIT
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu['offset']=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDk((page_int-1)*dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.LIST_LIMIT)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu.update(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.GetDefaultParams(login=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm))
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.callRequestCookies('Get',dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,payload=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,params=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu,headers=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,cookies=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm=json.loads(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK.text)
   if not('celllist' in dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['cell_toplist']):return[],dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAO=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['cell_toplist']['celllist']
   for dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI in dwYFCTRLPBoJMzeUqQlyNWiEvfnbAO:
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKg =dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI['event_list'][1]['url']
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKA=urllib.parse.urlsplit(dwYFCTRLPBoJMzeUqQlyNWiEvfnbKg).query
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKA=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDu(urllib.parse.parse_qsl(dwYFCTRLPBoJMzeUqQlyNWiEvfnbKA))
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKm='contentid'
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKt=dwYFCTRLPBoJMzeUqQlyNWiEvfnbKA[dwYFCTRLPBoJMzeUqQlyNWiEvfnbKm]
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbAX={'programtitle':dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI['title_list'][0]['text'],'episodetitle':dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.Get_ChangeText(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI['title_list'][1]['text']),'age':dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI.get('age'),'thumbnail':dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.HTTPTAG+dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI.get('thumbnail'),'vidtype':dwYFCTRLPBoJMzeUqQlyNWiEvfnbKm,'videoid':dwYFCTRLPBoJMzeUqQlyNWiEvfnbKt}
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKp.append(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAX)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAs=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDO(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['cell_toplist']['pagecount'])
   if dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['cell_toplist']['count']:dwYFCTRLPBoJMzeUqQlyNWiEvfnbKD =dwYFCTRLPBoJMzeUqQlyNWiEvfnbDO(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['cell_toplist']['count'])
   else:dwYFCTRLPBoJMzeUqQlyNWiEvfnbKD=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.LIST_LIMIT*page_int
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAS=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAs>dwYFCTRLPBoJMzeUqQlyNWiEvfnbKD
  except dwYFCTRLPBoJMzeUqQlyNWiEvfnbDG as exception:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbDc(exception)
   return[],dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm
  return dwYFCTRLPBoJMzeUqQlyNWiEvfnbKp,dwYFCTRLPBoJMzeUqQlyNWiEvfnbAS
 def Get_Program_List(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK,dwYFCTRLPBoJMzeUqQlyNWiEvfnbAc,page_int=1,orderby='-'):
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbKx=[]
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbAs=dwYFCTRLPBoJMzeUqQlyNWiEvfnbKD=1
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbAS=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm
  (dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu)=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.Baseapi_Parse(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAc)
  if dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS=='':return dwYFCTRLPBoJMzeUqQlyNWiEvfnbKx,dwYFCTRLPBoJMzeUqQlyNWiEvfnbAS
  try:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu['limit'] =dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.LIST_LIMIT
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu['offset']=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDk((page_int-1)*dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.LIST_LIMIT)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu['page'] =dwYFCTRLPBoJMzeUqQlyNWiEvfnbDk(page_int)
   if dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu.get('orderby')!='' and dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu.get('orderby')!='regdatefirst' and orderby!='-':
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu['orderby']=orderby 
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu.update(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.GetDefaultParams(login=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm))
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.callRequestCookies('Get',dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,payload=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,params=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu,headers=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,cookies=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm=json.loads(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK.text)
   if dwYFCTRLPBoJMzeUqQlyNWiEvfnbAc.find('instantplay')>=0:
    if not('celllist' in dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['band']):return dwYFCTRLPBoJMzeUqQlyNWiEvfnbKx,dwYFCTRLPBoJMzeUqQlyNWiEvfnbAS
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbAO=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['band']['celllist']
   else:
    if not('celllist' in dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['cell_toplist']):return dwYFCTRLPBoJMzeUqQlyNWiEvfnbKx,dwYFCTRLPBoJMzeUqQlyNWiEvfnbAS
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbAO=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['cell_toplist']['celllist']
   for dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI in dwYFCTRLPBoJMzeUqQlyNWiEvfnbAO:
    for dwYFCTRLPBoJMzeUqQlyNWiEvfnbKk in dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI['event_list']:
     if dwYFCTRLPBoJMzeUqQlyNWiEvfnbKk.get('type')=='on-navigation':
      dwYFCTRLPBoJMzeUqQlyNWiEvfnbKg =dwYFCTRLPBoJMzeUqQlyNWiEvfnbKk['url']
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKA=urllib.parse.urlsplit(dwYFCTRLPBoJMzeUqQlyNWiEvfnbKg).query
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKm=dwYFCTRLPBoJMzeUqQlyNWiEvfnbKA[0:dwYFCTRLPBoJMzeUqQlyNWiEvfnbKA.find('=')]
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKt=dwYFCTRLPBoJMzeUqQlyNWiEvfnbKA[dwYFCTRLPBoJMzeUqQlyNWiEvfnbKA.find('=')+1:]
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbAX={'title':dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI['title_list'][0]['text'],'age':dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI['age'],'thumbnail':'https://%s'%dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI.get('thumbnail'),'videoid':dwYFCTRLPBoJMzeUqQlyNWiEvfnbKt,'vidtype':dwYFCTRLPBoJMzeUqQlyNWiEvfnbKm}
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKx.append(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAX)
   if dwYFCTRLPBoJMzeUqQlyNWiEvfnbAc.find('instantplay')<0:
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbAs=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDO(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['cell_toplist']['pagecount'])
    if dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['cell_toplist']['count']:dwYFCTRLPBoJMzeUqQlyNWiEvfnbKD =dwYFCTRLPBoJMzeUqQlyNWiEvfnbDO(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['cell_toplist']['count'])
    else:dwYFCTRLPBoJMzeUqQlyNWiEvfnbKD=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.LIST_LIMIT*page_int
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbAS=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAs>dwYFCTRLPBoJMzeUqQlyNWiEvfnbKD
  except dwYFCTRLPBoJMzeUqQlyNWiEvfnbDG as exception:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbDc(exception)
   return[],dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm
  return dwYFCTRLPBoJMzeUqQlyNWiEvfnbKx,dwYFCTRLPBoJMzeUqQlyNWiEvfnbAS
 def Get_Movie_List(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK,dwYFCTRLPBoJMzeUqQlyNWiEvfnbAc,page_int=1):
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbKG=[]
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbAs=dwYFCTRLPBoJMzeUqQlyNWiEvfnbKD=1
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbAS=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm
  (dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu)=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.Baseapi_Parse(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAc)
  if dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS=='':return dwYFCTRLPBoJMzeUqQlyNWiEvfnbKG,dwYFCTRLPBoJMzeUqQlyNWiEvfnbAS
  try:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu['limit']=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.MV_LIMIT
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu['offset']=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDk((page_int-1)*dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.MV_LIMIT)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu.update(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.GetDefaultParams(login=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm))
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.callRequestCookies('Get',dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,payload=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,params=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu,headers=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,cookies=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm=json.loads(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK.text)
   if not('celllist' in dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['cell_toplist']):return dwYFCTRLPBoJMzeUqQlyNWiEvfnbKG,dwYFCTRLPBoJMzeUqQlyNWiEvfnbAS
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAO=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['cell_toplist']['celllist']
   for dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI in dwYFCTRLPBoJMzeUqQlyNWiEvfnbAO:
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKg =dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI['event_list'][1]['url']
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKA=urllib.parse.urlsplit(dwYFCTRLPBoJMzeUqQlyNWiEvfnbKg).query
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKm=dwYFCTRLPBoJMzeUqQlyNWiEvfnbKA[0:dwYFCTRLPBoJMzeUqQlyNWiEvfnbKA.find('=')]
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKt=dwYFCTRLPBoJMzeUqQlyNWiEvfnbKA[dwYFCTRLPBoJMzeUqQlyNWiEvfnbKA.find('=')+1:]
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbAX={'title':dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI['title_list'][0]['text'],'age':dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI['age'],'thumbnail':'https://%s'%dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI.get('thumbnail'),'videoid':dwYFCTRLPBoJMzeUqQlyNWiEvfnbKt,'vidtype':dwYFCTRLPBoJMzeUqQlyNWiEvfnbKm}
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKG.append(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAX)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAs=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDO(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['cell_toplist']['pagecount'])
   if dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['cell_toplist']['count']:dwYFCTRLPBoJMzeUqQlyNWiEvfnbKD =dwYFCTRLPBoJMzeUqQlyNWiEvfnbDO(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['cell_toplist']['count'])
   else:dwYFCTRLPBoJMzeUqQlyNWiEvfnbKD=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.MV_LIMIT*page_int
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAS=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAs>dwYFCTRLPBoJMzeUqQlyNWiEvfnbKD
  except dwYFCTRLPBoJMzeUqQlyNWiEvfnbDG as exception:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbDc(exception)
   return[],dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm
  return dwYFCTRLPBoJMzeUqQlyNWiEvfnbKG,dwYFCTRLPBoJMzeUqQlyNWiEvfnbAS
 def ProgramidToContentid(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK,dwYFCTRLPBoJMzeUqQlyNWiEvfnbKO):
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbKc=''
  try:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS =dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.API_DOMAIN+'/vod/programs-contentid/'+dwYFCTRLPBoJMzeUqQlyNWiEvfnbKO
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.GetDefaultParams(login=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.callRequestCookies('Get',dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,payload=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,params=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu,headers=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,cookies=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbKu=json.loads(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK.text)
   if not('contentid' in dwYFCTRLPBoJMzeUqQlyNWiEvfnbKu):return dwYFCTRLPBoJMzeUqQlyNWiEvfnbKc 
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbKc=dwYFCTRLPBoJMzeUqQlyNWiEvfnbKu['contentid']
  except dwYFCTRLPBoJMzeUqQlyNWiEvfnbDG as exception:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbDc(exception)
  return dwYFCTRLPBoJMzeUqQlyNWiEvfnbKc
 def ContentidToProgramid(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK,dwYFCTRLPBoJMzeUqQlyNWiEvfnbKc):
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbKO=''
  try:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS =dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.API_DOMAIN+'/cf/vod/contents/'+dwYFCTRLPBoJMzeUqQlyNWiEvfnbKc
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.GetDefaultParams(login=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.callRequestCookies('Get',dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,payload=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,params=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu,headers=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,cookies=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbKu=json.loads(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK.text)
   if not('programid' in dwYFCTRLPBoJMzeUqQlyNWiEvfnbKu):return dwYFCTRLPBoJMzeUqQlyNWiEvfnbKO 
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbKO=dwYFCTRLPBoJMzeUqQlyNWiEvfnbKu['programid']
  except dwYFCTRLPBoJMzeUqQlyNWiEvfnbDG as exception:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbDc(exception)
  return dwYFCTRLPBoJMzeUqQlyNWiEvfnbKO
 def GetProgramInfo(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK,program_code):
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbKI={}
  try:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.API_DOMAIN+'/cf/vod/contents/'+program_code
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.GetDefaultParams(login=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.callRequestCookies('Get',dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,payload=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,params=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu,headers=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,cookies=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbKu=json.loads(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK.text)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbDc(dwYFCTRLPBoJMzeUqQlyNWiEvfnbKu)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbKX=img_fanart=dwYFCTRLPBoJMzeUqQlyNWiEvfnbKj=''
   if dwYFCTRLPBoJMzeUqQlyNWiEvfnbKu.get('programposterimage')!='':dwYFCTRLPBoJMzeUqQlyNWiEvfnbKX =dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.HTTPTAG+dwYFCTRLPBoJMzeUqQlyNWiEvfnbKu.get('programposterimage')
   if dwYFCTRLPBoJMzeUqQlyNWiEvfnbKu.get('programimage') !='':img_fanart =dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.HTTPTAG+dwYFCTRLPBoJMzeUqQlyNWiEvfnbKu.get('programimage')
   if dwYFCTRLPBoJMzeUqQlyNWiEvfnbKu.get('programcirlceimage')!='':dwYFCTRLPBoJMzeUqQlyNWiEvfnbKj=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.HTTPTAG+dwYFCTRLPBoJMzeUqQlyNWiEvfnbKu.get('programcirlceimage')
   if 'poster_default' in dwYFCTRLPBoJMzeUqQlyNWiEvfnbKX:
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKX =img_fanart
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKj=''
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbKI={'imgPoster':dwYFCTRLPBoJMzeUqQlyNWiEvfnbKX,'imgFanart':img_fanart,'imgClearlogo':dwYFCTRLPBoJMzeUqQlyNWiEvfnbKj}
  except dwYFCTRLPBoJMzeUqQlyNWiEvfnbDG as exception:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbDc(exception)
  return dwYFCTRLPBoJMzeUqQlyNWiEvfnbKI
 def Get_Episode_List(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK,dwYFCTRLPBoJMzeUqQlyNWiEvfnbKt,dwYFCTRLPBoJMzeUqQlyNWiEvfnbKm,page_int=1,orderby='desc'):
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbKa=[]
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbAs=dwYFCTRLPBoJMzeUqQlyNWiEvfnbKD=1
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbAS=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbKh={}
  if dwYFCTRLPBoJMzeUqQlyNWiEvfnbKm=='contentid':
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbKO=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.ContentidToProgramid(dwYFCTRLPBoJMzeUqQlyNWiEvfnbKt)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbKh=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.GetProgramInfo(dwYFCTRLPBoJMzeUqQlyNWiEvfnbKt)
  else:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbKO=dwYFCTRLPBoJMzeUqQlyNWiEvfnbKt
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbKc=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.ProgramidToContentid(dwYFCTRLPBoJMzeUqQlyNWiEvfnbKt)
   if dwYFCTRLPBoJMzeUqQlyNWiEvfnbKc!='':dwYFCTRLPBoJMzeUqQlyNWiEvfnbKh=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.GetProgramInfo(dwYFCTRLPBoJMzeUqQlyNWiEvfnbKc)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.API_DOMAIN+'/vod/programs-contents/'+dwYFCTRLPBoJMzeUqQlyNWiEvfnbKO
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu={}
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu['limit'] =dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.EP_LIMIT
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu['offset']=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDk((page_int-1)*dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.EP_LIMIT)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu['orderby']=orderby 
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu.update(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.GetDefaultParams(login=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm))
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.callRequestCookies('Get',dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,payload=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,params=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu,headers=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,cookies=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm=json.loads(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK.text)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAO=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['list']
   for dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI in dwYFCTRLPBoJMzeUqQlyNWiEvfnbAO:
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKr=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI.get('synopsis'))
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKH=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.HTTPTAG+dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI.get('image')
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKs=dwYFCTRLPBoJMzeUqQlyNWiEvfnbKS=dwYFCTRLPBoJMzeUqQlyNWiEvfnbmg=''
    if dwYFCTRLPBoJMzeUqQlyNWiEvfnbKh!={}:
     dwYFCTRLPBoJMzeUqQlyNWiEvfnbKs =dwYFCTRLPBoJMzeUqQlyNWiEvfnbKh.get('imgPoster')
     dwYFCTRLPBoJMzeUqQlyNWiEvfnbKS =dwYFCTRLPBoJMzeUqQlyNWiEvfnbKh.get('imgFanart')
     dwYFCTRLPBoJMzeUqQlyNWiEvfnbmg=dwYFCTRLPBoJMzeUqQlyNWiEvfnbKh.get('imgClearlogo')
     dwYFCTRLPBoJMzeUqQlyNWiEvfnbmA={'thumb':dwYFCTRLPBoJMzeUqQlyNWiEvfnbKH,'poster':dwYFCTRLPBoJMzeUqQlyNWiEvfnbKs,'fanart':dwYFCTRLPBoJMzeUqQlyNWiEvfnbKS,'clearlogo':dwYFCTRLPBoJMzeUqQlyNWiEvfnbmg}
    else:
     dwYFCTRLPBoJMzeUqQlyNWiEvfnbmA=dwYFCTRLPBoJMzeUqQlyNWiEvfnbKH
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbAX={'programtitle':dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI.get('programtitle'),'episodetitle':dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI.get('episodetitle'),'episodenumber':dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI.get('episodenumber'),'releasedate':dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI.get('releasedate'),'releaseweekday':dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI.get('releaseweekday'),'programid':dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI.get('programid'),'contentid':dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI.get('contentid'),'age':dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI.get('targetage'),'playtime':dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI.get('playtime'),'synopsis':dwYFCTRLPBoJMzeUqQlyNWiEvfnbKr,'episodeactors':dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI.get('episodeactors').split(',')if dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI.get('episodeactors')!='' else[],'thumbnail':dwYFCTRLPBoJMzeUqQlyNWiEvfnbmA}
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKa.append(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAX)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAs=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDO(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['pagecount'])
   if dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['count']:dwYFCTRLPBoJMzeUqQlyNWiEvfnbKD =dwYFCTRLPBoJMzeUqQlyNWiEvfnbDO(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['count'])
   else:dwYFCTRLPBoJMzeUqQlyNWiEvfnbKD=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.EP_LIMIT*page_int
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAS=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAs>dwYFCTRLPBoJMzeUqQlyNWiEvfnbKD
  except dwYFCTRLPBoJMzeUqQlyNWiEvfnbDG as exception:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbDc(exception)
   return[],dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm
  return dwYFCTRLPBoJMzeUqQlyNWiEvfnbKa,dwYFCTRLPBoJMzeUqQlyNWiEvfnbAS
 def GetEPGList(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK,genre):
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbmK={}
  try:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbmt=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.Get_Now_Datetime()
   if genre=='all':
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbmD =dwYFCTRLPBoJMzeUqQlyNWiEvfnbmt+datetime.timedelta(hours=3)
   else:
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbmD =dwYFCTRLPBoJMzeUqQlyNWiEvfnbmt+datetime.timedelta(hours=3)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.API_DOMAIN+'/live/epgs'
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu={'limit':'100','offset':'0','genre':genre,'startdatetime':dwYFCTRLPBoJMzeUqQlyNWiEvfnbmt.strftime('%Y-%m-%d %H:00'),'enddatetime':dwYFCTRLPBoJMzeUqQlyNWiEvfnbmD.strftime('%Y-%m-%d %H:00')}
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu.update(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.GetDefaultParams(login=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm))
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.callRequestCookies('Get',dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,payload=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,params=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu,headers=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,cookies=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm=json.loads(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK.text)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbmp=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['list']
   for dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI in dwYFCTRLPBoJMzeUqQlyNWiEvfnbmp:
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbmx=''
    for dwYFCTRLPBoJMzeUqQlyNWiEvfnbmk in dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI['list']:
     if dwYFCTRLPBoJMzeUqQlyNWiEvfnbmx:dwYFCTRLPBoJMzeUqQlyNWiEvfnbmx+='\n'
     dwYFCTRLPBoJMzeUqQlyNWiEvfnbmx+=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.Get_ChangeText(dwYFCTRLPBoJMzeUqQlyNWiEvfnbmk['title'])+'\n'
     dwYFCTRLPBoJMzeUqQlyNWiEvfnbmx+=' [%s ~ %s]'%(dwYFCTRLPBoJMzeUqQlyNWiEvfnbmk['starttime'][-5:],dwYFCTRLPBoJMzeUqQlyNWiEvfnbmk['endtime'][-5:])+'\n'
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbmK[dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI['channelid']]=dwYFCTRLPBoJMzeUqQlyNWiEvfnbmx
  except dwYFCTRLPBoJMzeUqQlyNWiEvfnbDG as exception:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbDc(exception)
  return dwYFCTRLPBoJMzeUqQlyNWiEvfnbmK
 def Get_LiveChannel_List(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK,genre,dwYFCTRLPBoJMzeUqQlyNWiEvfnbAc):
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbAH=[]
  (dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu)=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.Baseapi_Parse(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAc)
  if dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS=='':return dwYFCTRLPBoJMzeUqQlyNWiEvfnbAH
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbmG=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.GetEPGList(genre)
  try:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu.update(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.GetDefaultParams(login=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm))
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu['genre']=genre
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.callRequestCookies('Get',dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,payload=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,params=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu,headers=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,cookies=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm=json.loads(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK.text)
   if not('celllist' in dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['cell_toplist']):return[]
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAO=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['cell_toplist']['celllist']
   for dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI in dwYFCTRLPBoJMzeUqQlyNWiEvfnbAO:
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKc=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI['contentid']
    if dwYFCTRLPBoJMzeUqQlyNWiEvfnbKc in dwYFCTRLPBoJMzeUqQlyNWiEvfnbmG:
     dwYFCTRLPBoJMzeUqQlyNWiEvfnbmc=dwYFCTRLPBoJMzeUqQlyNWiEvfnbmG[dwYFCTRLPBoJMzeUqQlyNWiEvfnbKc]
    else:
     dwYFCTRLPBoJMzeUqQlyNWiEvfnbmc=''
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbAX={'studio':dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI['title_list'][0]['text'],'tvshowtitle':dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.Get_ChangeText(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI['title_list'][1]['text']),'channelid':dwYFCTRLPBoJMzeUqQlyNWiEvfnbKc,'age':dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI['age'],'thumbnail':'https://%s'%dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI.get('thumbnail'),'epg':dwYFCTRLPBoJMzeUqQlyNWiEvfnbmc}
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbAH.append(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAX)
  except dwYFCTRLPBoJMzeUqQlyNWiEvfnbDG as exception:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbDc(exception)
   return[]
  return dwYFCTRLPBoJMzeUqQlyNWiEvfnbAH
 def Get_Search_List(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK,search_key,sType,page_int,exclusion21=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm):
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbmu=[]
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbAs=dwYFCTRLPBoJMzeUqQlyNWiEvfnbKD=1
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbAS=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm
  try:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.API_DOMAIN+'/cf/search/list.js'
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':dwYFCTRLPBoJMzeUqQlyNWiEvfnbDk((page_int-1)*dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.SEARCH_LIMIT),'limit':dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.SEARCH_LIMIT,'orderby':'score'}
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu.update(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.GetDefaultParams(login=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm))
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.callRequestCookies('Get',dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,payload=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,params=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu,headers=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,cookies=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbKu=json.loads(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK.text)
   if not('celllist' in dwYFCTRLPBoJMzeUqQlyNWiEvfnbKu['cell_toplist']):return dwYFCTRLPBoJMzeUqQlyNWiEvfnbmu,dwYFCTRLPBoJMzeUqQlyNWiEvfnbAS
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAO=dwYFCTRLPBoJMzeUqQlyNWiEvfnbKu['cell_toplist']['celllist']
   for dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI in dwYFCTRLPBoJMzeUqQlyNWiEvfnbAO:
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKg =dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI['event_list'][1]['url']
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKA=urllib.parse.urlsplit(dwYFCTRLPBoJMzeUqQlyNWiEvfnbKg).query
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKm=dwYFCTRLPBoJMzeUqQlyNWiEvfnbKA[0:dwYFCTRLPBoJMzeUqQlyNWiEvfnbKA.find('=')]
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKt=dwYFCTRLPBoJMzeUqQlyNWiEvfnbKA[dwYFCTRLPBoJMzeUqQlyNWiEvfnbKA.find('=')+1:]
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbAX={'title':dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI['title_list'][0]['text'],'age':dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI['age'],'thumbnail':'https://%s'%dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI.get('thumbnail'),'videoid':dwYFCTRLPBoJMzeUqQlyNWiEvfnbKt,'vidtype':dwYFCTRLPBoJMzeUqQlyNWiEvfnbKm}
    if exclusion21==dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm or dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI.get('age')!='21':
     dwYFCTRLPBoJMzeUqQlyNWiEvfnbmu.append(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAX)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAs=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDO(dwYFCTRLPBoJMzeUqQlyNWiEvfnbKu['cell_toplist']['pagecount'])
   if dwYFCTRLPBoJMzeUqQlyNWiEvfnbKu['cell_toplist']['count']:dwYFCTRLPBoJMzeUqQlyNWiEvfnbKD =dwYFCTRLPBoJMzeUqQlyNWiEvfnbDO(dwYFCTRLPBoJMzeUqQlyNWiEvfnbKu['cell_toplist']['count'])
   else:dwYFCTRLPBoJMzeUqQlyNWiEvfnbKD=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.LIST_LIMIT
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAS=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAs>dwYFCTRLPBoJMzeUqQlyNWiEvfnbKD
  except dwYFCTRLPBoJMzeUqQlyNWiEvfnbDG as exception:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbDc(exception)
  return dwYFCTRLPBoJMzeUqQlyNWiEvfnbmu,dwYFCTRLPBoJMzeUqQlyNWiEvfnbAS 
 def GetStreamingURL(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK,mode,dwYFCTRLPBoJMzeUqQlyNWiEvfnbKc,quality_int,pvrmode='-'):
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbmO=dwYFCTRLPBoJMzeUqQlyNWiEvfnbmH=dwYFCTRLPBoJMzeUqQlyNWiEvfnbms=streaming_preview=''
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbmI=[]
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbmX='hls'
  if mode=='LIVE':
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS =dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.API_DOMAIN+'/live/channels/'+dwYFCTRLPBoJMzeUqQlyNWiEvfnbKc
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbmj='live'
  elif mode=='VOD':
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS =dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.API_DOMAIN+'/cf/vod/contents/'+dwYFCTRLPBoJMzeUqQlyNWiEvfnbKc
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbmj='vod'
  elif mode=='MOVIE':
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS =dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.API_DOMAIN+'/cf/movie/contents/'+dwYFCTRLPBoJMzeUqQlyNWiEvfnbKc
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbmj='movie'
  try:
   if mode!='LIVE' or pvrmode=='-':
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.GetDefaultParams(login=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm)
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.callRequestCookies('Get',dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,payload=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,params=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu,headers=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,cookies=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK)
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm=json.loads(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK.text)
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbma=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['qualities']['list']
    if dwYFCTRLPBoJMzeUqQlyNWiEvfnbma==dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK:return(dwYFCTRLPBoJMzeUqQlyNWiEvfnbmO,dwYFCTRLPBoJMzeUqQlyNWiEvfnbmH,dwYFCTRLPBoJMzeUqQlyNWiEvfnbms,streaming_preview)
    for dwYFCTRLPBoJMzeUqQlyNWiEvfnbmh in dwYFCTRLPBoJMzeUqQlyNWiEvfnbma:
     dwYFCTRLPBoJMzeUqQlyNWiEvfnbmI.append(dwYFCTRLPBoJMzeUqQlyNWiEvfnbDO(dwYFCTRLPBoJMzeUqQlyNWiEvfnbmh.get('id').rstrip('p')))
    if 'type' in dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm:
     if dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['type']=='onair':
      dwYFCTRLPBoJMzeUqQlyNWiEvfnbmj='onairvod'
    if 'drms' in dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm:
     if dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['drms']:
      dwYFCTRLPBoJMzeUqQlyNWiEvfnbmX='dash'
  except dwYFCTRLPBoJMzeUqQlyNWiEvfnbDG as exception:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbDc(exception)
   return(dwYFCTRLPBoJMzeUqQlyNWiEvfnbmO,dwYFCTRLPBoJMzeUqQlyNWiEvfnbmH,dwYFCTRLPBoJMzeUqQlyNWiEvfnbms,streaming_preview)
  try:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbmV=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.CheckQuality(quality_int,dwYFCTRLPBoJMzeUqQlyNWiEvfnbmI)
   if mode=='LIVE' and pvrmode!='-':
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbmr='auto'
   else:
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbmr=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDk(dwYFCTRLPBoJMzeUqQlyNWiEvfnbmV)+'p'
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.API_DOMAIN+'/streaming'
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu={'contentid':dwYFCTRLPBoJMzeUqQlyNWiEvfnbKc,'contenttype':dwYFCTRLPBoJMzeUqQlyNWiEvfnbmj,'action':dwYFCTRLPBoJMzeUqQlyNWiEvfnbmX,'quality':dwYFCTRLPBoJMzeUqQlyNWiEvfnbmr,'deviceModelId':'Windows 10','guid':dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.GetGUID(guidType=2),'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n'}
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu.update(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.GetDefaultParams(login=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDp))
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.callRequestCookies('Get',dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,payload=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,params=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu,headers=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,cookies=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm=json.loads(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK.text)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbmO=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['playurl']
   if dwYFCTRLPBoJMzeUqQlyNWiEvfnbmO==dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK:return(dwYFCTRLPBoJMzeUqQlyNWiEvfnbmO,dwYFCTRLPBoJMzeUqQlyNWiEvfnbmH,dwYFCTRLPBoJMzeUqQlyNWiEvfnbms,streaming_preview)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbmH=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['awscookie']
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbms =dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['drm']
   if 'previewmsg' in dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['preview']:streaming_preview=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['preview']['previewmsg']
  except dwYFCTRLPBoJMzeUqQlyNWiEvfnbDG as exception:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbDc(exception)
  return(dwYFCTRLPBoJMzeUqQlyNWiEvfnbmO,dwYFCTRLPBoJMzeUqQlyNWiEvfnbmH,dwYFCTRLPBoJMzeUqQlyNWiEvfnbms,streaming_preview) 
 def GetSportsURL(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK,dwYFCTRLPBoJMzeUqQlyNWiEvfnbKc,quality_int):
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbmO=dwYFCTRLPBoJMzeUqQlyNWiEvfnbmH=''
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbmI=[]
  try:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.API_DOMAIN+'/streaming/other'
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu={'contentid':dwYFCTRLPBoJMzeUqQlyNWiEvfnbKc,'contenttype':'live','action':'hls','quality':dwYFCTRLPBoJMzeUqQlyNWiEvfnbDk(quality_int)+'p','deviceModelId':'Windows 10','guid':dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.GetGUID(guidType=2),'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n'}
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu.update(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.GetDefaultParams(login=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDp))
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.callRequestCookies('Get',dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,payload=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,params=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu,headers=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,cookies=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm=json.loads(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK.text)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbmO=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['playurl']
   if dwYFCTRLPBoJMzeUqQlyNWiEvfnbmO==dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK:return(dwYFCTRLPBoJMzeUqQlyNWiEvfnbmO,dwYFCTRLPBoJMzeUqQlyNWiEvfnbmH)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbmH=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['awscookie']
  except dwYFCTRLPBoJMzeUqQlyNWiEvfnbDG as exception:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbDc(exception)
  return(dwYFCTRLPBoJMzeUqQlyNWiEvfnbmO,dwYFCTRLPBoJMzeUqQlyNWiEvfnbmH) 
 def make_viewdate(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK):
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbmS =dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.Get_Now_Datetime()
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbtg =dwYFCTRLPBoJMzeUqQlyNWiEvfnbmS+datetime.timedelta(days=-1)
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbtA =dwYFCTRLPBoJMzeUqQlyNWiEvfnbmS+datetime.timedelta(days=1)
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbtK=[dwYFCTRLPBoJMzeUqQlyNWiEvfnbmS.strftime('%Y%m%d'),dwYFCTRLPBoJMzeUqQlyNWiEvfnbtA.strftime('%Y%m%d'),]
  return dwYFCTRLPBoJMzeUqQlyNWiEvfnbtK
 def Get_Sports_Gamelist(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK):
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbtm =dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.make_viewdate()
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbtD=[]
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbtp =[]
  for dwYFCTRLPBoJMzeUqQlyNWiEvfnbtx in dwYFCTRLPBoJMzeUqQlyNWiEvfnbtm:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbtk=dwYFCTRLPBoJMzeUqQlyNWiEvfnbtx[:6]
   if dwYFCTRLPBoJMzeUqQlyNWiEvfnbtk not in dwYFCTRLPBoJMzeUqQlyNWiEvfnbtD:
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbtD.append(dwYFCTRLPBoJMzeUqQlyNWiEvfnbtk)
  try:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS='https://annexapi.wavve.com/skb/baseball/teammonthlycalendarlist'
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu={'IF':'IF-PORG-002','m':'getTeamCalendarListBand','response_format':'json','spo_itm_cd':'KBO','teamcd':'all','tgroup':'B','tvalue':'BC123','ver':'2.0',}
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu.update(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.GetDefaultParams(login=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm))
   for dwYFCTRLPBoJMzeUqQlyNWiEvfnbtG in dwYFCTRLPBoJMzeUqQlyNWiEvfnbtD:
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu['date']=dwYFCTRLPBoJMzeUqQlyNWiEvfnbtG
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.callRequestCookies('Get',dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,payload=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,params=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu,headers=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,cookies=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK)
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm=json.loads(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK.text)
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbAO=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm['cell_toplist']['celllist']
    for dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI in dwYFCTRLPBoJMzeUqQlyNWiEvfnbAO:
     dwYFCTRLPBoJMzeUqQlyNWiEvfnbtc=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI.get('game_date')
     dwYFCTRLPBoJMzeUqQlyNWiEvfnbtu =dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI.get('svc_id')
     if dwYFCTRLPBoJMzeUqQlyNWiEvfnbtu=='':continue
     if dwYFCTRLPBoJMzeUqQlyNWiEvfnbtc in dwYFCTRLPBoJMzeUqQlyNWiEvfnbtm:
      dwYFCTRLPBoJMzeUqQlyNWiEvfnbtO=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI.get('game_status') 
      dwYFCTRLPBoJMzeUqQlyNWiEvfnbtI =dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI.get('title_list')[0].get('text')
      dwYFCTRLPBoJMzeUqQlyNWiEvfnbtc =dwYFCTRLPBoJMzeUqQlyNWiEvfnbtc[:4]+'-'+dwYFCTRLPBoJMzeUqQlyNWiEvfnbtc[4:6]+'-'+dwYFCTRLPBoJMzeUqQlyNWiEvfnbtc[-2:]
      dwYFCTRLPBoJMzeUqQlyNWiEvfnbtX =dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI.get('game_time')
      dwYFCTRLPBoJMzeUqQlyNWiEvfnbtX =dwYFCTRLPBoJMzeUqQlyNWiEvfnbtX[:2]+':'+dwYFCTRLPBoJMzeUqQlyNWiEvfnbtX[-2:]
      dwYFCTRLPBoJMzeUqQlyNWiEvfnbAX={'game_date':dwYFCTRLPBoJMzeUqQlyNWiEvfnbtc,'game_time':dwYFCTRLPBoJMzeUqQlyNWiEvfnbtX,'svc_id':dwYFCTRLPBoJMzeUqQlyNWiEvfnbtu,'away_team':dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI.get('away_team').get('team_name'),'home_team':dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI.get('home_team').get('team_name'),'game_status':dwYFCTRLPBoJMzeUqQlyNWiEvfnbtO,'game_place':dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI.get('game_place'),}
      dwYFCTRLPBoJMzeUqQlyNWiEvfnbtp.append(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAX)
  except dwYFCTRLPBoJMzeUqQlyNWiEvfnbDG as exception:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbDc(exception)
   return[]
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbtj=[]
  for i in dwYFCTRLPBoJMzeUqQlyNWiEvfnbDx(2):
   for dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI in dwYFCTRLPBoJMzeUqQlyNWiEvfnbtp:
    if i==0 and dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI.get('game_status')=='LIVE':
     dwYFCTRLPBoJMzeUqQlyNWiEvfnbtj.append(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI)
    elif i==1 and dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI.get('game_status')!='LIVE':
     dwYFCTRLPBoJMzeUqQlyNWiEvfnbtj.append(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAI)
  return dwYFCTRLPBoJMzeUqQlyNWiEvfnbtj
 def GetBookmarkInfo(dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK,dwYFCTRLPBoJMzeUqQlyNWiEvfnbKt,dwYFCTRLPBoJMzeUqQlyNWiEvfnbKm,dwYFCTRLPBoJMzeUqQlyNWiEvfnbmj):
  if dwYFCTRLPBoJMzeUqQlyNWiEvfnbKm=='tvshow':
   if dwYFCTRLPBoJMzeUqQlyNWiEvfnbmj=='contentid':
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKc=dwYFCTRLPBoJMzeUqQlyNWiEvfnbKt
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKt =dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.ContentidToProgramid(dwYFCTRLPBoJMzeUqQlyNWiEvfnbKc)
   else:
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKc=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.ProgramidToContentid(dwYFCTRLPBoJMzeUqQlyNWiEvfnbKt)
  else:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbKc=''
  dwYFCTRLPBoJMzeUqQlyNWiEvfnbta={'indexinfo':{'ott':'wavve','videoid':dwYFCTRLPBoJMzeUqQlyNWiEvfnbKt,'vidtype':dwYFCTRLPBoJMzeUqQlyNWiEvfnbKm,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':dwYFCTRLPBoJMzeUqQlyNWiEvfnbKm,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if dwYFCTRLPBoJMzeUqQlyNWiEvfnbKm=='tvshow':
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.API_DOMAIN+'/cf/vod/contents/'+dwYFCTRLPBoJMzeUqQlyNWiEvfnbKc 
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.GetDefaultParams(login=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.callRequestCookies('Get',dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,payload=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,params=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu,headers=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,cookies=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm=json.loads(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK.text)
   if not('programtitle' in dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm):return{}
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbth=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbtV=dwYFCTRLPBoJMzeUqQlyNWiEvfnbth.get('programtitle')
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbta['saveinfo']['infoLabels']['title']=dwYFCTRLPBoJMzeUqQlyNWiEvfnbtV
   if dwYFCTRLPBoJMzeUqQlyNWiEvfnbth.get('targetage')=='18' or dwYFCTRLPBoJMzeUqQlyNWiEvfnbth.get('targetage')=='19' or dwYFCTRLPBoJMzeUqQlyNWiEvfnbth.get('targetage')=='21':
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbtV +=u' (%s)'%(dwYFCTRLPBoJMzeUqQlyNWiEvfnbth.get('targetage'))
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbta['saveinfo']['title'] =dwYFCTRLPBoJMzeUqQlyNWiEvfnbtV
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbta['saveinfo']['infoLabels']['mpaa'] =dwYFCTRLPBoJMzeUqQlyNWiEvfnbth.get('targetage')
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbta['saveinfo']['infoLabels']['plot'] =dwYFCTRLPBoJMzeUqQlyNWiEvfnbth.get('programsynopsis').replace('<br>','\n')
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbta['saveinfo']['infoLabels']['studio'] =dwYFCTRLPBoJMzeUqQlyNWiEvfnbth.get('channelname')
   if dwYFCTRLPBoJMzeUqQlyNWiEvfnbth.get('firstreleaseyear')!='':dwYFCTRLPBoJMzeUqQlyNWiEvfnbta['saveinfo']['infoLabels']['year'] =dwYFCTRLPBoJMzeUqQlyNWiEvfnbth.get('firstreleaseyear')
   if dwYFCTRLPBoJMzeUqQlyNWiEvfnbth.get('firstreleasedate')!='':dwYFCTRLPBoJMzeUqQlyNWiEvfnbta['saveinfo']['infoLabels']['premiered']=dwYFCTRLPBoJMzeUqQlyNWiEvfnbth.get('firstreleasedate')
   if dwYFCTRLPBoJMzeUqQlyNWiEvfnbth.get('genretext') !='':dwYFCTRLPBoJMzeUqQlyNWiEvfnbta['saveinfo']['infoLabels']['genre'] =[dwYFCTRLPBoJMzeUqQlyNWiEvfnbth.get('genretext')]
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbtr=[]
   for dwYFCTRLPBoJMzeUqQlyNWiEvfnbtH in dwYFCTRLPBoJMzeUqQlyNWiEvfnbth['actors']['list']:dwYFCTRLPBoJMzeUqQlyNWiEvfnbtr.append(dwYFCTRLPBoJMzeUqQlyNWiEvfnbtH.get('text'))
   if dwYFCTRLPBoJMzeUqQlyNWiEvfnbDI(dwYFCTRLPBoJMzeUqQlyNWiEvfnbtr)>0:
    if dwYFCTRLPBoJMzeUqQlyNWiEvfnbtr[0]!='':dwYFCTRLPBoJMzeUqQlyNWiEvfnbta['saveinfo']['infoLabels']['cast']=dwYFCTRLPBoJMzeUqQlyNWiEvfnbtr
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbKs =''
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbKS =''
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbmg=''
   if dwYFCTRLPBoJMzeUqQlyNWiEvfnbth.get('programposterimage')!='':dwYFCTRLPBoJMzeUqQlyNWiEvfnbKs =dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.HTTPTAG+dwYFCTRLPBoJMzeUqQlyNWiEvfnbth.get('programposterimage')
   if dwYFCTRLPBoJMzeUqQlyNWiEvfnbth.get('programimage') !='':dwYFCTRLPBoJMzeUqQlyNWiEvfnbKS =dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.HTTPTAG+dwYFCTRLPBoJMzeUqQlyNWiEvfnbth.get('programimage')
   if dwYFCTRLPBoJMzeUqQlyNWiEvfnbth.get('programcirlceimage')!='':dwYFCTRLPBoJMzeUqQlyNWiEvfnbmg=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.HTTPTAG+dwYFCTRLPBoJMzeUqQlyNWiEvfnbth.get('programcirlceimage')
   if 'poster_default' in dwYFCTRLPBoJMzeUqQlyNWiEvfnbKs:
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbKs =dwYFCTRLPBoJMzeUqQlyNWiEvfnbKS
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbmg=''
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbta['saveinfo']['thumbnail']['poster']=dwYFCTRLPBoJMzeUqQlyNWiEvfnbKs
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbta['saveinfo']['thumbnail']['thumb']=dwYFCTRLPBoJMzeUqQlyNWiEvfnbKS
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbta['saveinfo']['thumbnail']['clearlogo']=dwYFCTRLPBoJMzeUqQlyNWiEvfnbmg
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbta['saveinfo']['thumbnail']['fanart']=dwYFCTRLPBoJMzeUqQlyNWiEvfnbKS
  else:
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.API_DOMAIN+'/movie/contents/'+dwYFCTRLPBoJMzeUqQlyNWiEvfnbKt 
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.GetDefaultParams(login=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDm)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgK.callRequestCookies('Get',dwYFCTRLPBoJMzeUqQlyNWiEvfnbgS,payload=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,params=dwYFCTRLPBoJMzeUqQlyNWiEvfnbgu,headers=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK,cookies=dwYFCTRLPBoJMzeUqQlyNWiEvfnbDK)
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm=json.loads(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAK.text)
   if not('title' in dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm):return{}
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbth=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAm
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbtV=dwYFCTRLPBoJMzeUqQlyNWiEvfnbth.get('title')
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbta['saveinfo']['infoLabels']['title']=dwYFCTRLPBoJMzeUqQlyNWiEvfnbtV
   if dwYFCTRLPBoJMzeUqQlyNWiEvfnbth.get('targetage')=='18' or dwYFCTRLPBoJMzeUqQlyNWiEvfnbth.get('targetage')=='19' or dwYFCTRLPBoJMzeUqQlyNWiEvfnbth.get('targetage')=='21':
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbtV +=u' (%s)'%(dwYFCTRLPBoJMzeUqQlyNWiEvfnbth.get('targetage'))
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbta['saveinfo']['title'] =dwYFCTRLPBoJMzeUqQlyNWiEvfnbtV
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbta['saveinfo']['infoLabels']['mpaa'] =dwYFCTRLPBoJMzeUqQlyNWiEvfnbth.get('targetage')
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbta['saveinfo']['infoLabels']['plot'] =dwYFCTRLPBoJMzeUqQlyNWiEvfnbth.get('synopsis').replace('<br>','\n')
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbta['saveinfo']['infoLabels']['duration']=dwYFCTRLPBoJMzeUqQlyNWiEvfnbth.get('playtime')
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbta['saveinfo']['infoLabels']['country']=dwYFCTRLPBoJMzeUqQlyNWiEvfnbth.get('country')
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbta['saveinfo']['infoLabels']['studio'] =dwYFCTRLPBoJMzeUqQlyNWiEvfnbth.get('cpname')
   if dwYFCTRLPBoJMzeUqQlyNWiEvfnbth.get('releasedate')!='':
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbta['saveinfo']['infoLabels']['year'] =dwYFCTRLPBoJMzeUqQlyNWiEvfnbth.get('releasedate')[:4]
    dwYFCTRLPBoJMzeUqQlyNWiEvfnbta['saveinfo']['infoLabels']['premiered']=dwYFCTRLPBoJMzeUqQlyNWiEvfnbth.get('releasedate')
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbtr=[]
   for dwYFCTRLPBoJMzeUqQlyNWiEvfnbtH in dwYFCTRLPBoJMzeUqQlyNWiEvfnbth['actors']['list']:dwYFCTRLPBoJMzeUqQlyNWiEvfnbtr.append(dwYFCTRLPBoJMzeUqQlyNWiEvfnbtH.get('text'))
   if dwYFCTRLPBoJMzeUqQlyNWiEvfnbDI(dwYFCTRLPBoJMzeUqQlyNWiEvfnbtr)>0:
    if dwYFCTRLPBoJMzeUqQlyNWiEvfnbtr[0]!='':dwYFCTRLPBoJMzeUqQlyNWiEvfnbta['saveinfo']['infoLabels']['cast']=dwYFCTRLPBoJMzeUqQlyNWiEvfnbtr
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbts=[]
   for dwYFCTRLPBoJMzeUqQlyNWiEvfnbtS in dwYFCTRLPBoJMzeUqQlyNWiEvfnbth['directors']['list']:dwYFCTRLPBoJMzeUqQlyNWiEvfnbts.append(dwYFCTRLPBoJMzeUqQlyNWiEvfnbtS.get('text'))
   if dwYFCTRLPBoJMzeUqQlyNWiEvfnbDI(dwYFCTRLPBoJMzeUqQlyNWiEvfnbts)>0:
    if dwYFCTRLPBoJMzeUqQlyNWiEvfnbts[0]!='':dwYFCTRLPBoJMzeUqQlyNWiEvfnbta['saveinfo']['infoLabels']['director']=dwYFCTRLPBoJMzeUqQlyNWiEvfnbts
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbAG=[]
   for dwYFCTRLPBoJMzeUqQlyNWiEvfnbDg in dwYFCTRLPBoJMzeUqQlyNWiEvfnbth['genre']['list']:dwYFCTRLPBoJMzeUqQlyNWiEvfnbAG.append(dwYFCTRLPBoJMzeUqQlyNWiEvfnbDg.get('text'))
   if dwYFCTRLPBoJMzeUqQlyNWiEvfnbDI(dwYFCTRLPBoJMzeUqQlyNWiEvfnbAG)>0:
    if dwYFCTRLPBoJMzeUqQlyNWiEvfnbAG[0]!='':dwYFCTRLPBoJMzeUqQlyNWiEvfnbta['saveinfo']['infoLabels']['genre']=dwYFCTRLPBoJMzeUqQlyNWiEvfnbAG
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbKs ='https://%s'%dwYFCTRLPBoJMzeUqQlyNWiEvfnbth['image']
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbta['saveinfo']['thumbnail']['poster'] =dwYFCTRLPBoJMzeUqQlyNWiEvfnbKs
   dwYFCTRLPBoJMzeUqQlyNWiEvfnbta['saveinfo']['thumbnail']['thumb'] =dwYFCTRLPBoJMzeUqQlyNWiEvfnbKs
  return dwYFCTRLPBoJMzeUqQlyNWiEvfnbta
# Created by pyminifier (https://github.com/liftoff/pyminifier)
