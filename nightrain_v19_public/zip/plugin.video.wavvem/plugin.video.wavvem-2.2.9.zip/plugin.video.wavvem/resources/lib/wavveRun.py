__author__="NightRain"
oRjzYEqdXTWwyUvPDmKNkarlGJuMFB=object
oRjzYEqdXTWwyUvPDmKNkarlGJuMFb=None
oRjzYEqdXTWwyUvPDmKNkarlGJuMFe=int
oRjzYEqdXTWwyUvPDmKNkarlGJuMFH=True
oRjzYEqdXTWwyUvPDmKNkarlGJuMFf=False
oRjzYEqdXTWwyUvPDmKNkarlGJuMSC=type
oRjzYEqdXTWwyUvPDmKNkarlGJuMSI=dict
oRjzYEqdXTWwyUvPDmKNkarlGJuMSx=len
oRjzYEqdXTWwyUvPDmKNkarlGJuMSn=range
oRjzYEqdXTWwyUvPDmKNkarlGJuMSQ=str
oRjzYEqdXTWwyUvPDmKNkarlGJuMSg=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import json
oRjzYEqdXTWwyUvPDmKNkarlGJuMCx=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://www.wavve.com/supermultisection/GN51','icon':'home.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&offset=0&limit=20&uicode=VN500','page':'1','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=01&WeekDay=all&uitype=VN4&uiparent=FN0&uirank=0&broadcastid=847243&uicode=VN4','page':'1','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=02&WeekDay=all&uitype=VN3&uiparent=FN0&uirank=0&broadcastid=783664&uicode=VN3','page':'1','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'1','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'paid','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'displaystart','ordernm':'업데이트순','icon':''},{'title':'프로야구 - 경기중 시청가능','mode':'GAME_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'(웨이브) 검색','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'(웨이브) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
oRjzYEqdXTWwyUvPDmKNkarlGJuMCn=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
oRjzYEqdXTWwyUvPDmKNkarlGJuMCQ=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
oRjzYEqdXTWwyUvPDmKNkarlGJuMCg =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
oRjzYEqdXTWwyUvPDmKNkarlGJuMCF=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_searched.txt'))
from wavveCore import*
class oRjzYEqdXTWwyUvPDmKNkarlGJuMCI(oRjzYEqdXTWwyUvPDmKNkarlGJuMFB):
 def __init__(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS,oRjzYEqdXTWwyUvPDmKNkarlGJuMCs,oRjzYEqdXTWwyUvPDmKNkarlGJuMCV,oRjzYEqdXTWwyUvPDmKNkarlGJuMCc):
  oRjzYEqdXTWwyUvPDmKNkarlGJuMCS._addon_url =oRjzYEqdXTWwyUvPDmKNkarlGJuMCs
  oRjzYEqdXTWwyUvPDmKNkarlGJuMCS._addon_handle=oRjzYEqdXTWwyUvPDmKNkarlGJuMCV
  oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.main_params =oRjzYEqdXTWwyUvPDmKNkarlGJuMCc
  oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj =dwYFCTRLPBoJMzeUqQlyNWiEvfnbgA() 
 def addon_noti(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS,sting):
  try:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCi=xbmcgui.Dialog()
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCi.notification(__addonname__,sting)
  except:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMFb
 def addon_log(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS,string):
  try:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCp=string.encode('utf-8','ignore')
  except:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCp='addonException: addon_log'
  oRjzYEqdXTWwyUvPDmKNkarlGJuMCh=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,oRjzYEqdXTWwyUvPDmKNkarlGJuMCp),level=oRjzYEqdXTWwyUvPDmKNkarlGJuMCh)
 def get_keyboard_input(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS,oRjzYEqdXTWwyUvPDmKNkarlGJuMIs):
  oRjzYEqdXTWwyUvPDmKNkarlGJuMCt=oRjzYEqdXTWwyUvPDmKNkarlGJuMFb
  kb=xbmc.Keyboard()
  kb.setHeading(oRjzYEqdXTWwyUvPDmKNkarlGJuMIs)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCt=kb.getText()
  return oRjzYEqdXTWwyUvPDmKNkarlGJuMCt
 def get_settings_account(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS):
  oRjzYEqdXTWwyUvPDmKNkarlGJuMCL =__addon__.getSetting('id')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMCO =__addon__.getSetting('pw')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMCB=oRjzYEqdXTWwyUvPDmKNkarlGJuMFe(__addon__.getSetting('selected_profile'))
  return(oRjzYEqdXTWwyUvPDmKNkarlGJuMCL,oRjzYEqdXTWwyUvPDmKNkarlGJuMCO,oRjzYEqdXTWwyUvPDmKNkarlGJuMCB)
 def get_settings_totalsearch(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS):
  oRjzYEqdXTWwyUvPDmKNkarlGJuMCb =oRjzYEqdXTWwyUvPDmKNkarlGJuMFH if __addon__.getSetting('local_search')=='true' else oRjzYEqdXTWwyUvPDmKNkarlGJuMFf
  oRjzYEqdXTWwyUvPDmKNkarlGJuMCe=oRjzYEqdXTWwyUvPDmKNkarlGJuMFH if __addon__.getSetting('local_history')=='true' else oRjzYEqdXTWwyUvPDmKNkarlGJuMFf
  oRjzYEqdXTWwyUvPDmKNkarlGJuMCH =oRjzYEqdXTWwyUvPDmKNkarlGJuMFH if __addon__.getSetting('total_search')=='true' else oRjzYEqdXTWwyUvPDmKNkarlGJuMFf
  oRjzYEqdXTWwyUvPDmKNkarlGJuMCf=oRjzYEqdXTWwyUvPDmKNkarlGJuMFH if __addon__.getSetting('total_history')=='true' else oRjzYEqdXTWwyUvPDmKNkarlGJuMFf
  oRjzYEqdXTWwyUvPDmKNkarlGJuMIC=oRjzYEqdXTWwyUvPDmKNkarlGJuMFH if __addon__.getSetting('menu_bookmark')=='true' else oRjzYEqdXTWwyUvPDmKNkarlGJuMFf
  return(oRjzYEqdXTWwyUvPDmKNkarlGJuMCb,oRjzYEqdXTWwyUvPDmKNkarlGJuMCe,oRjzYEqdXTWwyUvPDmKNkarlGJuMCH,oRjzYEqdXTWwyUvPDmKNkarlGJuMCf,oRjzYEqdXTWwyUvPDmKNkarlGJuMIC)
 def get_settings_makebookmark(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS):
  return oRjzYEqdXTWwyUvPDmKNkarlGJuMFH if __addon__.getSetting('make_bookmark')=='true' else oRjzYEqdXTWwyUvPDmKNkarlGJuMFf
 def get_selQuality(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS):
  try:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIx=[1080,720,480,360]
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIn=oRjzYEqdXTWwyUvPDmKNkarlGJuMFe(__addon__.getSetting('selected_quality'))
   return oRjzYEqdXTWwyUvPDmKNkarlGJuMIx[oRjzYEqdXTWwyUvPDmKNkarlGJuMIn]
  except:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMFb
  return 1080 
 def get_settings_exclusion21(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS):
  oRjzYEqdXTWwyUvPDmKNkarlGJuMIQ =__addon__.getSetting('exclusion21')
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMIQ=='false':
   return oRjzYEqdXTWwyUvPDmKNkarlGJuMFf
  else:
   return oRjzYEqdXTWwyUvPDmKNkarlGJuMFH
 def get_settings_direct_replay(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS):
  oRjzYEqdXTWwyUvPDmKNkarlGJuMIg=oRjzYEqdXTWwyUvPDmKNkarlGJuMFe(__addon__.getSetting('direct_replay'))
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMIg==0:
   return oRjzYEqdXTWwyUvPDmKNkarlGJuMFf
  else:
   return oRjzYEqdXTWwyUvPDmKNkarlGJuMFH
 def set_winEpisodeOrderby(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS,oRjzYEqdXTWwyUvPDmKNkarlGJuMIF):
  __addon__.setSetting('wavve_orderby',oRjzYEqdXTWwyUvPDmKNkarlGJuMIF)
 def get_winEpisodeOrderby(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS):
  oRjzYEqdXTWwyUvPDmKNkarlGJuMIF=__addon__.getSetting('wavve_orderby')
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMIF in['',oRjzYEqdXTWwyUvPDmKNkarlGJuMFb]:oRjzYEqdXTWwyUvPDmKNkarlGJuMIF='desc'
  return oRjzYEqdXTWwyUvPDmKNkarlGJuMIF
 def add_dir(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS,label,sublabel='',img='',infoLabels=oRjzYEqdXTWwyUvPDmKNkarlGJuMFb,isFolder=oRjzYEqdXTWwyUvPDmKNkarlGJuMFH,params='',isLink=oRjzYEqdXTWwyUvPDmKNkarlGJuMFf,ContextMenu=oRjzYEqdXTWwyUvPDmKNkarlGJuMFb):
  oRjzYEqdXTWwyUvPDmKNkarlGJuMIS='%s?%s'%(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS._addon_url,urllib.parse.urlencode(params))
  if sublabel:oRjzYEqdXTWwyUvPDmKNkarlGJuMIs='%s < %s >'%(label,sublabel)
  else: oRjzYEqdXTWwyUvPDmKNkarlGJuMIs=label
  if not img:img='DefaultFolder.png'
  oRjzYEqdXTWwyUvPDmKNkarlGJuMIV=xbmcgui.ListItem(oRjzYEqdXTWwyUvPDmKNkarlGJuMIs)
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMSC(img)==oRjzYEqdXTWwyUvPDmKNkarlGJuMSI:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIV.setArt(img)
  else:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIV.setArt({'thumb':img,'poster':img})
  if infoLabels:oRjzYEqdXTWwyUvPDmKNkarlGJuMIV.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIV.setProperty('IsPlayable','true')
  if ContextMenu:oRjzYEqdXTWwyUvPDmKNkarlGJuMIV.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS._addon_handle,oRjzYEqdXTWwyUvPDmKNkarlGJuMIS,oRjzYEqdXTWwyUvPDmKNkarlGJuMIV,isFolder)
 def dp_Main_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS):
  (oRjzYEqdXTWwyUvPDmKNkarlGJuMCb,oRjzYEqdXTWwyUvPDmKNkarlGJuMCe,oRjzYEqdXTWwyUvPDmKNkarlGJuMCH,oRjzYEqdXTWwyUvPDmKNkarlGJuMCf,oRjzYEqdXTWwyUvPDmKNkarlGJuMIC)=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.get_settings_totalsearch()
  for oRjzYEqdXTWwyUvPDmKNkarlGJuMIc in oRjzYEqdXTWwyUvPDmKNkarlGJuMCx:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIs=oRjzYEqdXTWwyUvPDmKNkarlGJuMIc.get('title')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIA=''
   if oRjzYEqdXTWwyUvPDmKNkarlGJuMIc.get('mode')=='SEARCH_GROUP' and oRjzYEqdXTWwyUvPDmKNkarlGJuMCb ==oRjzYEqdXTWwyUvPDmKNkarlGJuMFf:continue
   elif oRjzYEqdXTWwyUvPDmKNkarlGJuMIc.get('mode')=='SEARCH_HISTORY' and oRjzYEqdXTWwyUvPDmKNkarlGJuMCe==oRjzYEqdXTWwyUvPDmKNkarlGJuMFf:continue
   elif oRjzYEqdXTWwyUvPDmKNkarlGJuMIc.get('mode')=='TOTAL_SEARCH' and oRjzYEqdXTWwyUvPDmKNkarlGJuMCH ==oRjzYEqdXTWwyUvPDmKNkarlGJuMFf:continue
   elif oRjzYEqdXTWwyUvPDmKNkarlGJuMIc.get('mode')=='TOTAL_HISTORY' and oRjzYEqdXTWwyUvPDmKNkarlGJuMCf==oRjzYEqdXTWwyUvPDmKNkarlGJuMFf:continue
   elif oRjzYEqdXTWwyUvPDmKNkarlGJuMIc.get('mode')=='MENU_BOOKMARK' and oRjzYEqdXTWwyUvPDmKNkarlGJuMIC==oRjzYEqdXTWwyUvPDmKNkarlGJuMFf:continue
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi={'mode':oRjzYEqdXTWwyUvPDmKNkarlGJuMIc.get('mode'),'sCode':oRjzYEqdXTWwyUvPDmKNkarlGJuMIc.get('sCode'),'sIndex':oRjzYEqdXTWwyUvPDmKNkarlGJuMIc.get('sIndex'),'sType':oRjzYEqdXTWwyUvPDmKNkarlGJuMIc.get('sType'),'suburl':oRjzYEqdXTWwyUvPDmKNkarlGJuMIc.get('suburl'),'subapi':oRjzYEqdXTWwyUvPDmKNkarlGJuMIc.get('subapi'),'page':oRjzYEqdXTWwyUvPDmKNkarlGJuMIc.get('page'),'orderby':oRjzYEqdXTWwyUvPDmKNkarlGJuMIc.get('orderby'),'ordernm':oRjzYEqdXTWwyUvPDmKNkarlGJuMIc.get('ordernm')}
   if oRjzYEqdXTWwyUvPDmKNkarlGJuMIc.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    oRjzYEqdXTWwyUvPDmKNkarlGJuMIp=oRjzYEqdXTWwyUvPDmKNkarlGJuMFf
    oRjzYEqdXTWwyUvPDmKNkarlGJuMIh =oRjzYEqdXTWwyUvPDmKNkarlGJuMFH
   else:
    oRjzYEqdXTWwyUvPDmKNkarlGJuMIp=oRjzYEqdXTWwyUvPDmKNkarlGJuMFH
    oRjzYEqdXTWwyUvPDmKNkarlGJuMIh =oRjzYEqdXTWwyUvPDmKNkarlGJuMFf
   if 'icon' in oRjzYEqdXTWwyUvPDmKNkarlGJuMIc:oRjzYEqdXTWwyUvPDmKNkarlGJuMIA=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',oRjzYEqdXTWwyUvPDmKNkarlGJuMIc.get('icon')) 
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.add_dir(oRjzYEqdXTWwyUvPDmKNkarlGJuMIs,sublabel='',img=oRjzYEqdXTWwyUvPDmKNkarlGJuMIA,infoLabels=oRjzYEqdXTWwyUvPDmKNkarlGJuMFb,isFolder=oRjzYEqdXTWwyUvPDmKNkarlGJuMIp,params=oRjzYEqdXTWwyUvPDmKNkarlGJuMIi,isLink=oRjzYEqdXTWwyUvPDmKNkarlGJuMIh)
  xbmcplugin.endOfDirectory(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS._addon_handle,cacheToDisc=oRjzYEqdXTWwyUvPDmKNkarlGJuMFH)
 def dp_Search_Group(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS,args):
  if 'search_key' in args:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIO=args.get('search_key')
  else:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIO=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not oRjzYEqdXTWwyUvPDmKNkarlGJuMIO:
    return
  for oRjzYEqdXTWwyUvPDmKNkarlGJuMIB in oRjzYEqdXTWwyUvPDmKNkarlGJuMCn:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIb =oRjzYEqdXTWwyUvPDmKNkarlGJuMIB.get('mode')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIe=oRjzYEqdXTWwyUvPDmKNkarlGJuMIB.get('sType')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIs=oRjzYEqdXTWwyUvPDmKNkarlGJuMIB.get('title')
   (oRjzYEqdXTWwyUvPDmKNkarlGJuMIH,oRjzYEqdXTWwyUvPDmKNkarlGJuMIf)=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.Get_Search_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMIO,oRjzYEqdXTWwyUvPDmKNkarlGJuMIe,1,exclusion21=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.get_settings_exclusion21())
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxC={'plot':'검색어 : '+oRjzYEqdXTWwyUvPDmKNkarlGJuMIO+'\n\n'+oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.Search_FreeList(oRjzYEqdXTWwyUvPDmKNkarlGJuMIH)}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi={'mode':oRjzYEqdXTWwyUvPDmKNkarlGJuMIb,'sType':oRjzYEqdXTWwyUvPDmKNkarlGJuMIe,'search_key':oRjzYEqdXTWwyUvPDmKNkarlGJuMIO,'page':'1',}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.add_dir(oRjzYEqdXTWwyUvPDmKNkarlGJuMIs,sublabel='',img='',infoLabels=oRjzYEqdXTWwyUvPDmKNkarlGJuMxC,isFolder=oRjzYEqdXTWwyUvPDmKNkarlGJuMFH,params=oRjzYEqdXTWwyUvPDmKNkarlGJuMIi)
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMSx(oRjzYEqdXTWwyUvPDmKNkarlGJuMCn)>0:xbmcplugin.endOfDirectory(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS._addon_handle,cacheToDisc=oRjzYEqdXTWwyUvPDmKNkarlGJuMFH)
  oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.Save_Searched_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMIO)
 def Search_FreeList(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS,search_list):
  oRjzYEqdXTWwyUvPDmKNkarlGJuMxI=''
  oRjzYEqdXTWwyUvPDmKNkarlGJuMxn=7
  try:
   if oRjzYEqdXTWwyUvPDmKNkarlGJuMSx(search_list)==0:return '검색결과 없음'
   for i in oRjzYEqdXTWwyUvPDmKNkarlGJuMSn(oRjzYEqdXTWwyUvPDmKNkarlGJuMSx(search_list)):
    if i>=oRjzYEqdXTWwyUvPDmKNkarlGJuMxn:
     oRjzYEqdXTWwyUvPDmKNkarlGJuMxI=oRjzYEqdXTWwyUvPDmKNkarlGJuMxI+'...'
     break
    oRjzYEqdXTWwyUvPDmKNkarlGJuMxI=oRjzYEqdXTWwyUvPDmKNkarlGJuMxI+search_list[i]['title']+'\n'
  except:
   return ''
  return oRjzYEqdXTWwyUvPDmKNkarlGJuMxI
 def dp_Watch_Group(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS,args):
  for oRjzYEqdXTWwyUvPDmKNkarlGJuMxQ in oRjzYEqdXTWwyUvPDmKNkarlGJuMCQ:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIs=oRjzYEqdXTWwyUvPDmKNkarlGJuMxQ.get('title')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi={'mode':oRjzYEqdXTWwyUvPDmKNkarlGJuMxQ.get('mode'),'sType':oRjzYEqdXTWwyUvPDmKNkarlGJuMxQ.get('sType')}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.add_dir(oRjzYEqdXTWwyUvPDmKNkarlGJuMIs,sublabel='',img='',infoLabels=oRjzYEqdXTWwyUvPDmKNkarlGJuMFb,isFolder=oRjzYEqdXTWwyUvPDmKNkarlGJuMFH,params=oRjzYEqdXTWwyUvPDmKNkarlGJuMIi)
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMSx(oRjzYEqdXTWwyUvPDmKNkarlGJuMCQ)>0:xbmcplugin.endOfDirectory(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS._addon_handle,cacheToDisc=oRjzYEqdXTWwyUvPDmKNkarlGJuMFH)
 def dp_Search_History(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS,args):
  oRjzYEqdXTWwyUvPDmKNkarlGJuMxg=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.Load_List_File('search')
  for oRjzYEqdXTWwyUvPDmKNkarlGJuMxF in oRjzYEqdXTWwyUvPDmKNkarlGJuMxg:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxS=oRjzYEqdXTWwyUvPDmKNkarlGJuMSI(urllib.parse.parse_qsl(oRjzYEqdXTWwyUvPDmKNkarlGJuMxF))
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxs=oRjzYEqdXTWwyUvPDmKNkarlGJuMxS.get('skey').strip()
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi={'mode':'SEARCH_GROUP','search_key':oRjzYEqdXTWwyUvPDmKNkarlGJuMxs,}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxV={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':oRjzYEqdXTWwyUvPDmKNkarlGJuMxs,'vType':'-',}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxc=urllib.parse.urlencode(oRjzYEqdXTWwyUvPDmKNkarlGJuMxV)
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxA=[('선택된 검색어 ( %s ) 삭제'%(oRjzYEqdXTWwyUvPDmKNkarlGJuMxs),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(oRjzYEqdXTWwyUvPDmKNkarlGJuMxc))]
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.add_dir(oRjzYEqdXTWwyUvPDmKNkarlGJuMxs,sublabel='',img=oRjzYEqdXTWwyUvPDmKNkarlGJuMFb,infoLabels=oRjzYEqdXTWwyUvPDmKNkarlGJuMFb,isFolder=oRjzYEqdXTWwyUvPDmKNkarlGJuMFH,params=oRjzYEqdXTWwyUvPDmKNkarlGJuMIi,ContextMenu=oRjzYEqdXTWwyUvPDmKNkarlGJuMxA)
  oRjzYEqdXTWwyUvPDmKNkarlGJuMxi={'plot':'검색목록 전체를 삭제합니다.'}
  oRjzYEqdXTWwyUvPDmKNkarlGJuMIs='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  oRjzYEqdXTWwyUvPDmKNkarlGJuMIi={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  oRjzYEqdXTWwyUvPDmKNkarlGJuMIA=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.add_dir(oRjzYEqdXTWwyUvPDmKNkarlGJuMIs,sublabel='',img=oRjzYEqdXTWwyUvPDmKNkarlGJuMIA,infoLabels=oRjzYEqdXTWwyUvPDmKNkarlGJuMxi,isFolder=oRjzYEqdXTWwyUvPDmKNkarlGJuMFf,params=oRjzYEqdXTWwyUvPDmKNkarlGJuMIi,isLink=oRjzYEqdXTWwyUvPDmKNkarlGJuMFH)
  xbmcplugin.endOfDirectory(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS._addon_handle,cacheToDisc=oRjzYEqdXTWwyUvPDmKNkarlGJuMFf)
 def dp_Search_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS,args):
  oRjzYEqdXTWwyUvPDmKNkarlGJuMIe =args.get('sType')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMxp =oRjzYEqdXTWwyUvPDmKNkarlGJuMFe(args.get('page'))
  if 'search_key' in args:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIO=args.get('search_key')
  else:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIO=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not oRjzYEqdXTWwyUvPDmKNkarlGJuMIO:
    xbmcplugin.endOfDirectory(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS._addon_handle)
    return
  oRjzYEqdXTWwyUvPDmKNkarlGJuMxh,oRjzYEqdXTWwyUvPDmKNkarlGJuMIf=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.Get_Search_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMIO,oRjzYEqdXTWwyUvPDmKNkarlGJuMIe,oRjzYEqdXTWwyUvPDmKNkarlGJuMxp,exclusion21=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.get_settings_exclusion21())
  for oRjzYEqdXTWwyUvPDmKNkarlGJuMxt in oRjzYEqdXTWwyUvPDmKNkarlGJuMxh:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxL =oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('videoid')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxO =oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('vidtype')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIs =oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('title')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxB=oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('thumbnail')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxb =oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('age')
   if oRjzYEqdXTWwyUvPDmKNkarlGJuMxb=='18' or oRjzYEqdXTWwyUvPDmKNkarlGJuMxb=='19' or oRjzYEqdXTWwyUvPDmKNkarlGJuMxb=='21':oRjzYEqdXTWwyUvPDmKNkarlGJuMIs+=' (%s)'%(oRjzYEqdXTWwyUvPDmKNkarlGJuMxb)
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxi={'mediatype':'tvshow' if oRjzYEqdXTWwyUvPDmKNkarlGJuMIe=='vod' else 'movie','mpaa':oRjzYEqdXTWwyUvPDmKNkarlGJuMxb,'title':oRjzYEqdXTWwyUvPDmKNkarlGJuMIs,'plot':oRjzYEqdXTWwyUvPDmKNkarlGJuMIs}
   if oRjzYEqdXTWwyUvPDmKNkarlGJuMIe=='vod':
    oRjzYEqdXTWwyUvPDmKNkarlGJuMIi={'mode':'EPISODE_LIST','videoid':oRjzYEqdXTWwyUvPDmKNkarlGJuMxL,'vidtype':oRjzYEqdXTWwyUvPDmKNkarlGJuMxO,'page':'1'}
    oRjzYEqdXTWwyUvPDmKNkarlGJuMIp=oRjzYEqdXTWwyUvPDmKNkarlGJuMFH
   else:
    oRjzYEqdXTWwyUvPDmKNkarlGJuMIi={'mode':'MOVIE','contentid':oRjzYEqdXTWwyUvPDmKNkarlGJuMxL,'title':oRjzYEqdXTWwyUvPDmKNkarlGJuMIs,'thumbnail':oRjzYEqdXTWwyUvPDmKNkarlGJuMxB,'age':oRjzYEqdXTWwyUvPDmKNkarlGJuMxb}
    oRjzYEqdXTWwyUvPDmKNkarlGJuMIp=oRjzYEqdXTWwyUvPDmKNkarlGJuMFf
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxA=[]
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxe={'mode':'VIEW_DETAIL','values':{'videoid':oRjzYEqdXTWwyUvPDmKNkarlGJuMxL,'vidtype':'tvshow' if oRjzYEqdXTWwyUvPDmKNkarlGJuMIe=='vod' else 'movie','contenttype':oRjzYEqdXTWwyUvPDmKNkarlGJuMxO,}}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxH=json.dumps(oRjzYEqdXTWwyUvPDmKNkarlGJuMxe,separators=(',',':'))
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxH=base64.standard_b64encode(oRjzYEqdXTWwyUvPDmKNkarlGJuMxH.encode()).decode('utf-8')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxH=oRjzYEqdXTWwyUvPDmKNkarlGJuMxH.replace('+','%2B')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxf='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(oRjzYEqdXTWwyUvPDmKNkarlGJuMxH)
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxA.append(('상세정보 조회',oRjzYEqdXTWwyUvPDmKNkarlGJuMxf))
   if oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.get_settings_makebookmark():
    oRjzYEqdXTWwyUvPDmKNkarlGJuMxe={'videoid':oRjzYEqdXTWwyUvPDmKNkarlGJuMxL,'vidtype':'tvshow' if oRjzYEqdXTWwyUvPDmKNkarlGJuMIe=='vod' else 'movie','vtitle':oRjzYEqdXTWwyUvPDmKNkarlGJuMIs,'vsubtitle':'','contenttype':oRjzYEqdXTWwyUvPDmKNkarlGJuMxO,}
    oRjzYEqdXTWwyUvPDmKNkarlGJuMnC=json.dumps(oRjzYEqdXTWwyUvPDmKNkarlGJuMxe)
    oRjzYEqdXTWwyUvPDmKNkarlGJuMnC=urllib.parse.quote(oRjzYEqdXTWwyUvPDmKNkarlGJuMnC)
    oRjzYEqdXTWwyUvPDmKNkarlGJuMxf='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(oRjzYEqdXTWwyUvPDmKNkarlGJuMnC)
    oRjzYEqdXTWwyUvPDmKNkarlGJuMxA.append(('(통합) 찜 영상에 추가',oRjzYEqdXTWwyUvPDmKNkarlGJuMxf))
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.add_dir(oRjzYEqdXTWwyUvPDmKNkarlGJuMIs,sublabel='',img=oRjzYEqdXTWwyUvPDmKNkarlGJuMxB,infoLabels=oRjzYEqdXTWwyUvPDmKNkarlGJuMxi,isFolder=oRjzYEqdXTWwyUvPDmKNkarlGJuMIp,params=oRjzYEqdXTWwyUvPDmKNkarlGJuMIi,ContextMenu=oRjzYEqdXTWwyUvPDmKNkarlGJuMxA)
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMIf:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi['mode'] ='SEARCH_LIST' 
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi['sType']=oRjzYEqdXTWwyUvPDmKNkarlGJuMIe 
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi['page'] =oRjzYEqdXTWwyUvPDmKNkarlGJuMSQ(oRjzYEqdXTWwyUvPDmKNkarlGJuMxp+1)
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi['search_key']=oRjzYEqdXTWwyUvPDmKNkarlGJuMIO
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIs='[B]%s >>[/B]'%'다음 페이지'
   oRjzYEqdXTWwyUvPDmKNkarlGJuMnI=oRjzYEqdXTWwyUvPDmKNkarlGJuMSQ(oRjzYEqdXTWwyUvPDmKNkarlGJuMxp+1)
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIA=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.add_dir(oRjzYEqdXTWwyUvPDmKNkarlGJuMIs,sublabel=oRjzYEqdXTWwyUvPDmKNkarlGJuMnI,img=oRjzYEqdXTWwyUvPDmKNkarlGJuMIA,infoLabels=oRjzYEqdXTWwyUvPDmKNkarlGJuMFb,isFolder=oRjzYEqdXTWwyUvPDmKNkarlGJuMFH,params=oRjzYEqdXTWwyUvPDmKNkarlGJuMIi)
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMIe=='movie':xbmcplugin.setContent(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS._addon_handle,'movies')
  else:xbmcplugin.setContent(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS._addon_handle,cacheToDisc=oRjzYEqdXTWwyUvPDmKNkarlGJuMFf)
 def dp_Watch_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS,args):
  oRjzYEqdXTWwyUvPDmKNkarlGJuMIe =args.get('sType')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMIg=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.get_settings_direct_replay()
  oRjzYEqdXTWwyUvPDmKNkarlGJuMxh=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.Load_List_File(oRjzYEqdXTWwyUvPDmKNkarlGJuMIe)
  for oRjzYEqdXTWwyUvPDmKNkarlGJuMxt in oRjzYEqdXTWwyUvPDmKNkarlGJuMxh:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxS=oRjzYEqdXTWwyUvPDmKNkarlGJuMSI(urllib.parse.parse_qsl(oRjzYEqdXTWwyUvPDmKNkarlGJuMxt))
   oRjzYEqdXTWwyUvPDmKNkarlGJuMnx =oRjzYEqdXTWwyUvPDmKNkarlGJuMxS.get('code').strip()
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIs =oRjzYEqdXTWwyUvPDmKNkarlGJuMxS.get('title').strip()
   oRjzYEqdXTWwyUvPDmKNkarlGJuMnI =oRjzYEqdXTWwyUvPDmKNkarlGJuMxS.get('subtitle').strip()
   if oRjzYEqdXTWwyUvPDmKNkarlGJuMnI=='None':oRjzYEqdXTWwyUvPDmKNkarlGJuMnI=''
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxB=oRjzYEqdXTWwyUvPDmKNkarlGJuMxS.get('img').strip()
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxL =oRjzYEqdXTWwyUvPDmKNkarlGJuMxS.get('videoid').strip()
   try:
    oRjzYEqdXTWwyUvPDmKNkarlGJuMxB=oRjzYEqdXTWwyUvPDmKNkarlGJuMxB.replace('\'','\"')
    oRjzYEqdXTWwyUvPDmKNkarlGJuMxB=json.loads(oRjzYEqdXTWwyUvPDmKNkarlGJuMxB)
   except:
    oRjzYEqdXTWwyUvPDmKNkarlGJuMFb
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxi={'plot':'%s\n%s'%(oRjzYEqdXTWwyUvPDmKNkarlGJuMIs,oRjzYEqdXTWwyUvPDmKNkarlGJuMnI)}
   if oRjzYEqdXTWwyUvPDmKNkarlGJuMIe=='vod':
    if oRjzYEqdXTWwyUvPDmKNkarlGJuMIg==oRjzYEqdXTWwyUvPDmKNkarlGJuMFf or oRjzYEqdXTWwyUvPDmKNkarlGJuMxL==oRjzYEqdXTWwyUvPDmKNkarlGJuMFb:
     oRjzYEqdXTWwyUvPDmKNkarlGJuMxi['mediatype']='tvshow'
     oRjzYEqdXTWwyUvPDmKNkarlGJuMIi={'mode':'EPISODE_LIST','videoid':oRjzYEqdXTWwyUvPDmKNkarlGJuMnx,'vidtype':'programid','page':'1'}
     oRjzYEqdXTWwyUvPDmKNkarlGJuMIp=oRjzYEqdXTWwyUvPDmKNkarlGJuMFH
    else:
     oRjzYEqdXTWwyUvPDmKNkarlGJuMxi['mediatype']='episode'
     oRjzYEqdXTWwyUvPDmKNkarlGJuMIi={'mode':'VOD','programid':oRjzYEqdXTWwyUvPDmKNkarlGJuMnx,'contentid':oRjzYEqdXTWwyUvPDmKNkarlGJuMxL,'title':oRjzYEqdXTWwyUvPDmKNkarlGJuMIs,'subtitle':oRjzYEqdXTWwyUvPDmKNkarlGJuMnI,'thumbnail':oRjzYEqdXTWwyUvPDmKNkarlGJuMxB}
     oRjzYEqdXTWwyUvPDmKNkarlGJuMIp=oRjzYEqdXTWwyUvPDmKNkarlGJuMFf
   else:
    oRjzYEqdXTWwyUvPDmKNkarlGJuMxi['mediatype']='movie'
    oRjzYEqdXTWwyUvPDmKNkarlGJuMIi={'mode':'MOVIE','contentid':oRjzYEqdXTWwyUvPDmKNkarlGJuMnx,'title':oRjzYEqdXTWwyUvPDmKNkarlGJuMIs,'subtitle':oRjzYEqdXTWwyUvPDmKNkarlGJuMnI,'thumbnail':oRjzYEqdXTWwyUvPDmKNkarlGJuMxB}
    oRjzYEqdXTWwyUvPDmKNkarlGJuMIp=oRjzYEqdXTWwyUvPDmKNkarlGJuMFf
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxV={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':oRjzYEqdXTWwyUvPDmKNkarlGJuMnx,'vType':oRjzYEqdXTWwyUvPDmKNkarlGJuMIe,}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxc=urllib.parse.urlencode(oRjzYEqdXTWwyUvPDmKNkarlGJuMxV)
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxA=[('선택된 시청이력 ( %s ) 삭제'%(oRjzYEqdXTWwyUvPDmKNkarlGJuMIs),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(oRjzYEqdXTWwyUvPDmKNkarlGJuMxc))]
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.add_dir(oRjzYEqdXTWwyUvPDmKNkarlGJuMIs,sublabel=oRjzYEqdXTWwyUvPDmKNkarlGJuMnI,img=oRjzYEqdXTWwyUvPDmKNkarlGJuMxB,infoLabels=oRjzYEqdXTWwyUvPDmKNkarlGJuMxi,isFolder=oRjzYEqdXTWwyUvPDmKNkarlGJuMIp,params=oRjzYEqdXTWwyUvPDmKNkarlGJuMIi,ContextMenu=oRjzYEqdXTWwyUvPDmKNkarlGJuMxA)
  oRjzYEqdXTWwyUvPDmKNkarlGJuMxi={'plot':'시청목록을 삭제합니다.'}
  oRjzYEqdXTWwyUvPDmKNkarlGJuMIs='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  oRjzYEqdXTWwyUvPDmKNkarlGJuMIi={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':oRjzYEqdXTWwyUvPDmKNkarlGJuMIe,}
  oRjzYEqdXTWwyUvPDmKNkarlGJuMIA=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.add_dir(oRjzYEqdXTWwyUvPDmKNkarlGJuMIs,sublabel='',img=oRjzYEqdXTWwyUvPDmKNkarlGJuMIA,infoLabels=oRjzYEqdXTWwyUvPDmKNkarlGJuMxi,isFolder=oRjzYEqdXTWwyUvPDmKNkarlGJuMFf,params=oRjzYEqdXTWwyUvPDmKNkarlGJuMIi,isLink=oRjzYEqdXTWwyUvPDmKNkarlGJuMFH)
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMIe=='movie':xbmcplugin.setContent(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS._addon_handle,'movies')
  else:xbmcplugin.setContent(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS._addon_handle,cacheToDisc=oRjzYEqdXTWwyUvPDmKNkarlGJuMFf)
 def Load_List_File(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS,stype): 
  try:
   if stype=='search':
    oRjzYEqdXTWwyUvPDmKNkarlGJuMnQ=oRjzYEqdXTWwyUvPDmKNkarlGJuMCF
   elif stype in['vod','movie']:
    oRjzYEqdXTWwyUvPDmKNkarlGJuMnQ=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   else:
    return[]
   fp=oRjzYEqdXTWwyUvPDmKNkarlGJuMSg(oRjzYEqdXTWwyUvPDmKNkarlGJuMnQ,'r',-1,'utf-8')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMng=fp.readlines()
   fp.close()
  except:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMng=[]
  return oRjzYEqdXTWwyUvPDmKNkarlGJuMng
 def Save_Watched_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS,oRjzYEqdXTWwyUvPDmKNkarlGJuMFn,oRjzYEqdXTWwyUvPDmKNkarlGJuMCc):
  try:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMnF=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%oRjzYEqdXTWwyUvPDmKNkarlGJuMFn))
   oRjzYEqdXTWwyUvPDmKNkarlGJuMnS=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.Load_List_File(oRjzYEqdXTWwyUvPDmKNkarlGJuMFn) 
   fp=oRjzYEqdXTWwyUvPDmKNkarlGJuMSg(oRjzYEqdXTWwyUvPDmKNkarlGJuMnF,'w',-1,'utf-8')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMns=urllib.parse.urlencode(oRjzYEqdXTWwyUvPDmKNkarlGJuMCc)
   oRjzYEqdXTWwyUvPDmKNkarlGJuMns=oRjzYEqdXTWwyUvPDmKNkarlGJuMns+'\n'
   fp.write(oRjzYEqdXTWwyUvPDmKNkarlGJuMns)
   oRjzYEqdXTWwyUvPDmKNkarlGJuMnV=0
   for oRjzYEqdXTWwyUvPDmKNkarlGJuMnc in oRjzYEqdXTWwyUvPDmKNkarlGJuMnS:
    oRjzYEqdXTWwyUvPDmKNkarlGJuMnA=oRjzYEqdXTWwyUvPDmKNkarlGJuMSI(urllib.parse.parse_qsl(oRjzYEqdXTWwyUvPDmKNkarlGJuMnc))
    oRjzYEqdXTWwyUvPDmKNkarlGJuMni=oRjzYEqdXTWwyUvPDmKNkarlGJuMCc.get('code').strip()
    oRjzYEqdXTWwyUvPDmKNkarlGJuMnp=oRjzYEqdXTWwyUvPDmKNkarlGJuMnA.get('code').strip()
    if oRjzYEqdXTWwyUvPDmKNkarlGJuMFn=='vod' and oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.get_settings_direct_replay()==oRjzYEqdXTWwyUvPDmKNkarlGJuMFH:
     oRjzYEqdXTWwyUvPDmKNkarlGJuMni=oRjzYEqdXTWwyUvPDmKNkarlGJuMCc.get('videoid').strip()
     oRjzYEqdXTWwyUvPDmKNkarlGJuMnp=oRjzYEqdXTWwyUvPDmKNkarlGJuMnA.get('videoid').strip()if oRjzYEqdXTWwyUvPDmKNkarlGJuMnp!=oRjzYEqdXTWwyUvPDmKNkarlGJuMFb else '-'
    if oRjzYEqdXTWwyUvPDmKNkarlGJuMni!=oRjzYEqdXTWwyUvPDmKNkarlGJuMnp:
     fp.write(oRjzYEqdXTWwyUvPDmKNkarlGJuMnc)
     oRjzYEqdXTWwyUvPDmKNkarlGJuMnV+=1
     if oRjzYEqdXTWwyUvPDmKNkarlGJuMnV>=50:break
   fp.close()
  except:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMFb
 def dp_History_Remove(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS,args):
  oRjzYEqdXTWwyUvPDmKNkarlGJuMnh=args.get('delType')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMnt =args.get('sKey')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMnL =args.get('vType')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMCi=xbmcgui.Dialog()
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMnh=='SEARCH_ALL':
   oRjzYEqdXTWwyUvPDmKNkarlGJuMnO=oRjzYEqdXTWwyUvPDmKNkarlGJuMCi.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif oRjzYEqdXTWwyUvPDmKNkarlGJuMnh=='SEARCH_ONE':
   oRjzYEqdXTWwyUvPDmKNkarlGJuMnO=oRjzYEqdXTWwyUvPDmKNkarlGJuMCi.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif oRjzYEqdXTWwyUvPDmKNkarlGJuMnh=='WATCH_ALL':
   oRjzYEqdXTWwyUvPDmKNkarlGJuMnO=oRjzYEqdXTWwyUvPDmKNkarlGJuMCi.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif oRjzYEqdXTWwyUvPDmKNkarlGJuMnh=='WATCH_ONE':
   oRjzYEqdXTWwyUvPDmKNkarlGJuMnO=oRjzYEqdXTWwyUvPDmKNkarlGJuMCi.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMnO==oRjzYEqdXTWwyUvPDmKNkarlGJuMFf:sys.exit()
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMnh=='SEARCH_ALL':
   if os.path.isfile(oRjzYEqdXTWwyUvPDmKNkarlGJuMCF):os.remove(oRjzYEqdXTWwyUvPDmKNkarlGJuMCF)
  elif oRjzYEqdXTWwyUvPDmKNkarlGJuMnh=='SEARCH_ONE':
   try:
    oRjzYEqdXTWwyUvPDmKNkarlGJuMnQ=oRjzYEqdXTWwyUvPDmKNkarlGJuMCF
    oRjzYEqdXTWwyUvPDmKNkarlGJuMnS=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.Load_List_File('search') 
    fp=oRjzYEqdXTWwyUvPDmKNkarlGJuMSg(oRjzYEqdXTWwyUvPDmKNkarlGJuMnQ,'w',-1,'utf-8')
    for oRjzYEqdXTWwyUvPDmKNkarlGJuMnc in oRjzYEqdXTWwyUvPDmKNkarlGJuMnS:
     oRjzYEqdXTWwyUvPDmKNkarlGJuMnA=oRjzYEqdXTWwyUvPDmKNkarlGJuMSI(urllib.parse.parse_qsl(oRjzYEqdXTWwyUvPDmKNkarlGJuMnc))
     oRjzYEqdXTWwyUvPDmKNkarlGJuMnB=oRjzYEqdXTWwyUvPDmKNkarlGJuMnA.get('skey').strip()
     if oRjzYEqdXTWwyUvPDmKNkarlGJuMnt!=oRjzYEqdXTWwyUvPDmKNkarlGJuMnB:
      fp.write(oRjzYEqdXTWwyUvPDmKNkarlGJuMnc)
    fp.close()
   except:
    oRjzYEqdXTWwyUvPDmKNkarlGJuMFb
  elif oRjzYEqdXTWwyUvPDmKNkarlGJuMnh=='WATCH_ALL':
   oRjzYEqdXTWwyUvPDmKNkarlGJuMnQ=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%oRjzYEqdXTWwyUvPDmKNkarlGJuMnL))
   if os.path.isfile(oRjzYEqdXTWwyUvPDmKNkarlGJuMnQ):os.remove(oRjzYEqdXTWwyUvPDmKNkarlGJuMnQ)
  elif oRjzYEqdXTWwyUvPDmKNkarlGJuMnh=='WATCH_ONE':
   oRjzYEqdXTWwyUvPDmKNkarlGJuMnQ=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%oRjzYEqdXTWwyUvPDmKNkarlGJuMnL))
   try:
    oRjzYEqdXTWwyUvPDmKNkarlGJuMnS=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.Load_List_File(oRjzYEqdXTWwyUvPDmKNkarlGJuMnL) 
    fp=oRjzYEqdXTWwyUvPDmKNkarlGJuMSg(oRjzYEqdXTWwyUvPDmKNkarlGJuMnQ,'w',-1,'utf-8')
    for oRjzYEqdXTWwyUvPDmKNkarlGJuMnc in oRjzYEqdXTWwyUvPDmKNkarlGJuMnS:
     oRjzYEqdXTWwyUvPDmKNkarlGJuMnA=oRjzYEqdXTWwyUvPDmKNkarlGJuMSI(urllib.parse.parse_qsl(oRjzYEqdXTWwyUvPDmKNkarlGJuMnc))
     oRjzYEqdXTWwyUvPDmKNkarlGJuMnB=oRjzYEqdXTWwyUvPDmKNkarlGJuMnA.get('code').strip()
     if oRjzYEqdXTWwyUvPDmKNkarlGJuMnt!=oRjzYEqdXTWwyUvPDmKNkarlGJuMnB:
      fp.write(oRjzYEqdXTWwyUvPDmKNkarlGJuMnc)
    fp.close()
   except:
    oRjzYEqdXTWwyUvPDmKNkarlGJuMFb
  xbmc.executebuiltin("Container.Refresh")
 def Save_Searched_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS,oRjzYEqdXTWwyUvPDmKNkarlGJuMIO):
  try:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMnb=oRjzYEqdXTWwyUvPDmKNkarlGJuMCF
   oRjzYEqdXTWwyUvPDmKNkarlGJuMnS=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.Load_List_File('search') 
   oRjzYEqdXTWwyUvPDmKNkarlGJuMne={'skey':oRjzYEqdXTWwyUvPDmKNkarlGJuMIO.strip()}
   fp=oRjzYEqdXTWwyUvPDmKNkarlGJuMSg(oRjzYEqdXTWwyUvPDmKNkarlGJuMnb,'w',-1,'utf-8')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMns=urllib.parse.urlencode(oRjzYEqdXTWwyUvPDmKNkarlGJuMne)
   oRjzYEqdXTWwyUvPDmKNkarlGJuMns=oRjzYEqdXTWwyUvPDmKNkarlGJuMns+'\n'
   fp.write(oRjzYEqdXTWwyUvPDmKNkarlGJuMns)
   oRjzYEqdXTWwyUvPDmKNkarlGJuMnV=0
   for oRjzYEqdXTWwyUvPDmKNkarlGJuMnc in oRjzYEqdXTWwyUvPDmKNkarlGJuMnS:
    oRjzYEqdXTWwyUvPDmKNkarlGJuMnA=oRjzYEqdXTWwyUvPDmKNkarlGJuMSI(urllib.parse.parse_qsl(oRjzYEqdXTWwyUvPDmKNkarlGJuMnc))
    oRjzYEqdXTWwyUvPDmKNkarlGJuMni=oRjzYEqdXTWwyUvPDmKNkarlGJuMne.get('skey').strip()
    oRjzYEqdXTWwyUvPDmKNkarlGJuMnp=oRjzYEqdXTWwyUvPDmKNkarlGJuMnA.get('skey').strip()
    if oRjzYEqdXTWwyUvPDmKNkarlGJuMni!=oRjzYEqdXTWwyUvPDmKNkarlGJuMnp:
     fp.write(oRjzYEqdXTWwyUvPDmKNkarlGJuMnc)
     oRjzYEqdXTWwyUvPDmKNkarlGJuMnV+=1
     if oRjzYEqdXTWwyUvPDmKNkarlGJuMnV>=50:break
   fp.close()
  except:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMFb
 def dp_Global_Search(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS,args):
  oRjzYEqdXTWwyUvPDmKNkarlGJuMIb=args.get('mode')
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMIb=='TOTAL_SEARCH':
   oRjzYEqdXTWwyUvPDmKNkarlGJuMnH='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMnH='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(oRjzYEqdXTWwyUvPDmKNkarlGJuMnH)
 def dp_Bookmark_Menu(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS,args):
  oRjzYEqdXTWwyUvPDmKNkarlGJuMnH='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(oRjzYEqdXTWwyUvPDmKNkarlGJuMnH)
 def login_main(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS):
  (oRjzYEqdXTWwyUvPDmKNkarlGJuMnf,oRjzYEqdXTWwyUvPDmKNkarlGJuMQC,oRjzYEqdXTWwyUvPDmKNkarlGJuMQI)=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.get_settings_account()
  if not(oRjzYEqdXTWwyUvPDmKNkarlGJuMnf and oRjzYEqdXTWwyUvPDmKNkarlGJuMQC):
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCi=xbmcgui.Dialog()
   oRjzYEqdXTWwyUvPDmKNkarlGJuMnO=oRjzYEqdXTWwyUvPDmKNkarlGJuMCi.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if oRjzYEqdXTWwyUvPDmKNkarlGJuMnO==oRjzYEqdXTWwyUvPDmKNkarlGJuMFH:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.cookiefile_check()==oRjzYEqdXTWwyUvPDmKNkarlGJuMFH:return
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   oRjzYEqdXTWwyUvPDmKNkarlGJuMQx=0
   while oRjzYEqdXTWwyUvPDmKNkarlGJuMFH:
    oRjzYEqdXTWwyUvPDmKNkarlGJuMQx+=1
    time.sleep(0.05)
    if oRjzYEqdXTWwyUvPDmKNkarlGJuMQx>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMQn=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.GetCredential(oRjzYEqdXTWwyUvPDmKNkarlGJuMnf,oRjzYEqdXTWwyUvPDmKNkarlGJuMQC,oRjzYEqdXTWwyUvPDmKNkarlGJuMQI)
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMQn:oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMQn==oRjzYEqdXTWwyUvPDmKNkarlGJuMFf:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_setEpOrderby(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS,args):
  oRjzYEqdXTWwyUvPDmKNkarlGJuMIF =args.get('orderby')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.set_winEpisodeOrderby(oRjzYEqdXTWwyUvPDmKNkarlGJuMIF)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS,args):
  oRjzYEqdXTWwyUvPDmKNkarlGJuMIb =args.get('mode')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMQg =args.get('contentid')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMQF =args.get('pvrmode')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMQS=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.get_selQuality()
  oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.addon_log(oRjzYEqdXTWwyUvPDmKNkarlGJuMQg+' - '+oRjzYEqdXTWwyUvPDmKNkarlGJuMIb)
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMIb=='SPORTS':
   oRjzYEqdXTWwyUvPDmKNkarlGJuMQs,oRjzYEqdXTWwyUvPDmKNkarlGJuMQV=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.GetSportsURL(oRjzYEqdXTWwyUvPDmKNkarlGJuMQg,oRjzYEqdXTWwyUvPDmKNkarlGJuMQS)
   oRjzYEqdXTWwyUvPDmKNkarlGJuMQc =''
   oRjzYEqdXTWwyUvPDmKNkarlGJuMQA=''
  else:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMQs,oRjzYEqdXTWwyUvPDmKNkarlGJuMQV,oRjzYEqdXTWwyUvPDmKNkarlGJuMQc,oRjzYEqdXTWwyUvPDmKNkarlGJuMQA=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.GetStreamingURL(oRjzYEqdXTWwyUvPDmKNkarlGJuMIb,oRjzYEqdXTWwyUvPDmKNkarlGJuMQg,oRjzYEqdXTWwyUvPDmKNkarlGJuMQS,oRjzYEqdXTWwyUvPDmKNkarlGJuMQF)
  oRjzYEqdXTWwyUvPDmKNkarlGJuMQi='%s|Cookie=%s'%(oRjzYEqdXTWwyUvPDmKNkarlGJuMQs,oRjzYEqdXTWwyUvPDmKNkarlGJuMQV)
  oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.addon_log(oRjzYEqdXTWwyUvPDmKNkarlGJuMQi)
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMQs=='':
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.addon_noti(__language__(30907).encode('utf8'))
   return
  oRjzYEqdXTWwyUvPDmKNkarlGJuMQp=xbmcgui.ListItem(path=oRjzYEqdXTWwyUvPDmKNkarlGJuMQi)
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMQc:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.addon_log('!!streaming_drm!!')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMQh=oRjzYEqdXTWwyUvPDmKNkarlGJuMQc['customdata']
   oRjzYEqdXTWwyUvPDmKNkarlGJuMQt =oRjzYEqdXTWwyUvPDmKNkarlGJuMQc['drmhost']
   oRjzYEqdXTWwyUvPDmKNkarlGJuMQL =inputstreamhelper.Helper('mpd',drm='widevine')
   if oRjzYEqdXTWwyUvPDmKNkarlGJuMQL.check_inputstream():
    if oRjzYEqdXTWwyUvPDmKNkarlGJuMIb=='MOVIE':
     oRjzYEqdXTWwyUvPDmKNkarlGJuMQO='https://www.wavve.com/player/movie?movieid=%s'%oRjzYEqdXTWwyUvPDmKNkarlGJuMQg
    else:
     oRjzYEqdXTWwyUvPDmKNkarlGJuMQO='https://www.wavve.com/player/vod?programid=%s&page=1'%oRjzYEqdXTWwyUvPDmKNkarlGJuMQg
    oRjzYEqdXTWwyUvPDmKNkarlGJuMQB={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':oRjzYEqdXTWwyUvPDmKNkarlGJuMQh,'referer':oRjzYEqdXTWwyUvPDmKNkarlGJuMQO,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.USER_AGENT}
    oRjzYEqdXTWwyUvPDmKNkarlGJuMQb=oRjzYEqdXTWwyUvPDmKNkarlGJuMQt+'|'+urllib.parse.urlencode(oRjzYEqdXTWwyUvPDmKNkarlGJuMQB)+'|R{SSM}|'
    oRjzYEqdXTWwyUvPDmKNkarlGJuMQp.setProperty('inputstream',oRjzYEqdXTWwyUvPDmKNkarlGJuMQL.inputstream_addon)
    oRjzYEqdXTWwyUvPDmKNkarlGJuMQp.setProperty('inputstream.adaptive.manifest_type','mpd')
    oRjzYEqdXTWwyUvPDmKNkarlGJuMQp.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    oRjzYEqdXTWwyUvPDmKNkarlGJuMQp.setProperty('inputstream.adaptive.license_key',oRjzYEqdXTWwyUvPDmKNkarlGJuMQb)
    oRjzYEqdXTWwyUvPDmKNkarlGJuMQp.setProperty('inputstream.adaptive.stream_headers','user-agent=%s&Cookie=%s'%(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.USER_AGENT,oRjzYEqdXTWwyUvPDmKNkarlGJuMQV))
  xbmcplugin.setResolvedUrl(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS._addon_handle,oRjzYEqdXTWwyUvPDmKNkarlGJuMFH,oRjzYEqdXTWwyUvPDmKNkarlGJuMQp)
  oRjzYEqdXTWwyUvPDmKNkarlGJuMQe=oRjzYEqdXTWwyUvPDmKNkarlGJuMFf
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMQA:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.addon_noti(oRjzYEqdXTWwyUvPDmKNkarlGJuMQA.encode('utf-8'))
   oRjzYEqdXTWwyUvPDmKNkarlGJuMQe=oRjzYEqdXTWwyUvPDmKNkarlGJuMFH
  else:
   if '/preview.' in urllib.parse.urlsplit(oRjzYEqdXTWwyUvPDmKNkarlGJuMQs).path:
    oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.addon_noti(__language__(30908).encode('utf8'))
    oRjzYEqdXTWwyUvPDmKNkarlGJuMQe=oRjzYEqdXTWwyUvPDmKNkarlGJuMFH
  try:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMQH=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and oRjzYEqdXTWwyUvPDmKNkarlGJuMQe==oRjzYEqdXTWwyUvPDmKNkarlGJuMFf and oRjzYEqdXTWwyUvPDmKNkarlGJuMQH!='-':
    oRjzYEqdXTWwyUvPDmKNkarlGJuMIi={'code':oRjzYEqdXTWwyUvPDmKNkarlGJuMQH,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.Save_Watched_List(args.get('mode').lower(),oRjzYEqdXTWwyUvPDmKNkarlGJuMIi)
  except:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMFb
 def logout(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS):
  oRjzYEqdXTWwyUvPDmKNkarlGJuMCi=xbmcgui.Dialog()
  oRjzYEqdXTWwyUvPDmKNkarlGJuMnO=oRjzYEqdXTWwyUvPDmKNkarlGJuMCi.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMnO==oRjzYEqdXTWwyUvPDmKNkarlGJuMFf:sys.exit()
  oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.Init_WV_Total()
  if os.path.isfile(oRjzYEqdXTWwyUvPDmKNkarlGJuMCg):os.remove(oRjzYEqdXTWwyUvPDmKNkarlGJuMCg)
  oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS):
  oRjzYEqdXTWwyUvPDmKNkarlGJuMQf =oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.Get_Now_Datetime()
  oRjzYEqdXTWwyUvPDmKNkarlGJuMgC=oRjzYEqdXTWwyUvPDmKNkarlGJuMQf+datetime.timedelta(days=oRjzYEqdXTWwyUvPDmKNkarlGJuMFe(__addon__.getSetting('cache_ttl')))
  (oRjzYEqdXTWwyUvPDmKNkarlGJuMnf,oRjzYEqdXTWwyUvPDmKNkarlGJuMQC,oRjzYEqdXTWwyUvPDmKNkarlGJuMQI)=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.get_settings_account()
  oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.Save_session_acount(oRjzYEqdXTWwyUvPDmKNkarlGJuMnf,oRjzYEqdXTWwyUvPDmKNkarlGJuMQC,oRjzYEqdXTWwyUvPDmKNkarlGJuMQI)
  oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.WV['account']['token_limit']=oRjzYEqdXTWwyUvPDmKNkarlGJuMgC.strftime('%Y%m%d')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.JsonFile_Save(oRjzYEqdXTWwyUvPDmKNkarlGJuMCg,oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.WV)
 def cookiefile_check(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS):
  oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.WV=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.JsonFile_Load(oRjzYEqdXTWwyUvPDmKNkarlGJuMCg)
  if 'account' not in oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.WV:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.Init_WV_Total()
   return oRjzYEqdXTWwyUvPDmKNkarlGJuMFf
  (oRjzYEqdXTWwyUvPDmKNkarlGJuMgI,oRjzYEqdXTWwyUvPDmKNkarlGJuMgx,oRjzYEqdXTWwyUvPDmKNkarlGJuMgn)=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.get_settings_account()
  (oRjzYEqdXTWwyUvPDmKNkarlGJuMgQ,oRjzYEqdXTWwyUvPDmKNkarlGJuMgF,oRjzYEqdXTWwyUvPDmKNkarlGJuMgS)=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.Load_session_acount()
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMgI!=oRjzYEqdXTWwyUvPDmKNkarlGJuMgQ or oRjzYEqdXTWwyUvPDmKNkarlGJuMgx!=oRjzYEqdXTWwyUvPDmKNkarlGJuMgF or oRjzYEqdXTWwyUvPDmKNkarlGJuMgn!=oRjzYEqdXTWwyUvPDmKNkarlGJuMgS:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.Init_WV_Total()
   return oRjzYEqdXTWwyUvPDmKNkarlGJuMFf
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMFe(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))>oRjzYEqdXTWwyUvPDmKNkarlGJuMFe(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.WV['account']['token_limit']):
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.Init_WV_Total()
   return oRjzYEqdXTWwyUvPDmKNkarlGJuMFf
  return oRjzYEqdXTWwyUvPDmKNkarlGJuMFH
 def dp_LiveCatagory_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS,args):
  oRjzYEqdXTWwyUvPDmKNkarlGJuMgs =args.get('sCode')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMgV=args.get('sIndex')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMxh,oRjzYEqdXTWwyUvPDmKNkarlGJuMgc=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.Get_LiveCatagory_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMgs,oRjzYEqdXTWwyUvPDmKNkarlGJuMgV)
  for oRjzYEqdXTWwyUvPDmKNkarlGJuMxt in oRjzYEqdXTWwyUvPDmKNkarlGJuMxh:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIs =oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('title')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi={'mode':'LIVE_LIST','genre':oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('genre'),'baseapi':oRjzYEqdXTWwyUvPDmKNkarlGJuMgc}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.add_dir(oRjzYEqdXTWwyUvPDmKNkarlGJuMIs,sublabel='',img='',infoLabels=oRjzYEqdXTWwyUvPDmKNkarlGJuMFb,isFolder=oRjzYEqdXTWwyUvPDmKNkarlGJuMFH,params=oRjzYEqdXTWwyUvPDmKNkarlGJuMIi)
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMSx(oRjzYEqdXTWwyUvPDmKNkarlGJuMxh)>0:xbmcplugin.endOfDirectory(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS._addon_handle,cacheToDisc=oRjzYEqdXTWwyUvPDmKNkarlGJuMFf)
 def dp_MainCatagory_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS,args):
  oRjzYEqdXTWwyUvPDmKNkarlGJuMgs =args.get('sCode')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMgV=args.get('sIndex')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMIe =args.get('sType')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMxh=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.Get_MainCatagory_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMgs,oRjzYEqdXTWwyUvPDmKNkarlGJuMgV)
  for oRjzYEqdXTWwyUvPDmKNkarlGJuMxt in oRjzYEqdXTWwyUvPDmKNkarlGJuMxh:
   if oRjzYEqdXTWwyUvPDmKNkarlGJuMIe=='vod':
    if oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('subtype')=='catagory':
     oRjzYEqdXTWwyUvPDmKNkarlGJuMIb='PROGRAM_LIST'
    else:
     oRjzYEqdXTWwyUvPDmKNkarlGJuMIb='SUPERSECTION_LIST'
   elif oRjzYEqdXTWwyUvPDmKNkarlGJuMIe=='movie':
    oRjzYEqdXTWwyUvPDmKNkarlGJuMIb='MOVIE_LIST'
   else:
    oRjzYEqdXTWwyUvPDmKNkarlGJuMIb=''
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIs='%s (%s)'%(oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('title'),args.get('ordernm'))
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi={'mode':oRjzYEqdXTWwyUvPDmKNkarlGJuMIb,'suburl':oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('suburl'),'subapi':oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.get_settings_exclusion21():
    if oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('title')=='성인' or oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('title')=='성인+' or oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('title')=='에로티시즘' or oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('title')=='19':continue
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.add_dir(oRjzYEqdXTWwyUvPDmKNkarlGJuMIs,sublabel='',img='',infoLabels=oRjzYEqdXTWwyUvPDmKNkarlGJuMFb,isFolder=oRjzYEqdXTWwyUvPDmKNkarlGJuMFH,params=oRjzYEqdXTWwyUvPDmKNkarlGJuMIi)
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMSx(oRjzYEqdXTWwyUvPDmKNkarlGJuMxh)>0:xbmcplugin.endOfDirectory(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS._addon_handle,cacheToDisc=oRjzYEqdXTWwyUvPDmKNkarlGJuMFf)
 def dp_Program_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS,args):
  oRjzYEqdXTWwyUvPDmKNkarlGJuMgA =args.get('subapi')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMxp=oRjzYEqdXTWwyUvPDmKNkarlGJuMFe(args.get('page'))
  oRjzYEqdXTWwyUvPDmKNkarlGJuMIF =args.get('orderby')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMxh,oRjzYEqdXTWwyUvPDmKNkarlGJuMIf=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.Get_Program_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMgA,oRjzYEqdXTWwyUvPDmKNkarlGJuMxp,oRjzYEqdXTWwyUvPDmKNkarlGJuMIF)
  for oRjzYEqdXTWwyUvPDmKNkarlGJuMxt in oRjzYEqdXTWwyUvPDmKNkarlGJuMxh:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxL =oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('videoid')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxO =oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('vidtype')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIs =oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('title')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxB=oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('thumbnail')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxb =oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('age')
   if oRjzYEqdXTWwyUvPDmKNkarlGJuMxb=='18' or oRjzYEqdXTWwyUvPDmKNkarlGJuMxb=='19' or oRjzYEqdXTWwyUvPDmKNkarlGJuMxb=='21':oRjzYEqdXTWwyUvPDmKNkarlGJuMIs+=' (%s)'%(oRjzYEqdXTWwyUvPDmKNkarlGJuMxb)
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxi={'plot':oRjzYEqdXTWwyUvPDmKNkarlGJuMIs,'mpaa':oRjzYEqdXTWwyUvPDmKNkarlGJuMxb,'mediatype':'tvshow'}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi={'mode':'EPISODE_LIST','videoid':oRjzYEqdXTWwyUvPDmKNkarlGJuMxL,'vidtype':oRjzYEqdXTWwyUvPDmKNkarlGJuMxO,'page':'1'}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxA=[]
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxe={'mode':'VIEW_DETAIL','values':{'videoid':oRjzYEqdXTWwyUvPDmKNkarlGJuMxL,'vidtype':'tvshow','contenttype':oRjzYEqdXTWwyUvPDmKNkarlGJuMxO,}}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxH=json.dumps(oRjzYEqdXTWwyUvPDmKNkarlGJuMxe,separators=(',',':'))
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxH=base64.standard_b64encode(oRjzYEqdXTWwyUvPDmKNkarlGJuMxH.encode()).decode('utf-8')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxH=oRjzYEqdXTWwyUvPDmKNkarlGJuMxH.replace('+','%2B')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxf='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(oRjzYEqdXTWwyUvPDmKNkarlGJuMxH)
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxA.append(('상세정보 조회',oRjzYEqdXTWwyUvPDmKNkarlGJuMxf))
   if oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.get_settings_makebookmark():
    oRjzYEqdXTWwyUvPDmKNkarlGJuMxe={'videoid':oRjzYEqdXTWwyUvPDmKNkarlGJuMxL,'vidtype':'tvshow','vtitle':oRjzYEqdXTWwyUvPDmKNkarlGJuMIs,'vsubtitle':'','contenttype':oRjzYEqdXTWwyUvPDmKNkarlGJuMxO,}
    oRjzYEqdXTWwyUvPDmKNkarlGJuMnC=json.dumps(oRjzYEqdXTWwyUvPDmKNkarlGJuMxe)
    oRjzYEqdXTWwyUvPDmKNkarlGJuMnC=urllib.parse.quote(oRjzYEqdXTWwyUvPDmKNkarlGJuMnC)
    oRjzYEqdXTWwyUvPDmKNkarlGJuMxf='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(oRjzYEqdXTWwyUvPDmKNkarlGJuMnC)
    oRjzYEqdXTWwyUvPDmKNkarlGJuMxA.append(('(통합) 찜 영상에 추가',oRjzYEqdXTWwyUvPDmKNkarlGJuMxf))
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.add_dir(oRjzYEqdXTWwyUvPDmKNkarlGJuMIs,sublabel='',img=oRjzYEqdXTWwyUvPDmKNkarlGJuMxB,infoLabels=oRjzYEqdXTWwyUvPDmKNkarlGJuMxi,isFolder=oRjzYEqdXTWwyUvPDmKNkarlGJuMFH,params=oRjzYEqdXTWwyUvPDmKNkarlGJuMIi,ContextMenu=oRjzYEqdXTWwyUvPDmKNkarlGJuMxA)
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMIf:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi={}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi['mode'] ='PROGRAM_LIST' 
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi['subapi']=oRjzYEqdXTWwyUvPDmKNkarlGJuMgA 
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi['page'] =oRjzYEqdXTWwyUvPDmKNkarlGJuMSQ(oRjzYEqdXTWwyUvPDmKNkarlGJuMxp+1)
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIs='[B]%s >>[/B]'%'다음 페이지'
   oRjzYEqdXTWwyUvPDmKNkarlGJuMnI=oRjzYEqdXTWwyUvPDmKNkarlGJuMSQ(oRjzYEqdXTWwyUvPDmKNkarlGJuMxp+1)
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIA=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.add_dir(oRjzYEqdXTWwyUvPDmKNkarlGJuMIs,sublabel=oRjzYEqdXTWwyUvPDmKNkarlGJuMnI,img=oRjzYEqdXTWwyUvPDmKNkarlGJuMIA,infoLabels=oRjzYEqdXTWwyUvPDmKNkarlGJuMFb,isFolder=oRjzYEqdXTWwyUvPDmKNkarlGJuMFH,params=oRjzYEqdXTWwyUvPDmKNkarlGJuMIi)
  xbmcplugin.setContent(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS._addon_handle,'tvshows')
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMSx(oRjzYEqdXTWwyUvPDmKNkarlGJuMxh)>0:xbmcplugin.endOfDirectory(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS._addon_handle,cacheToDisc=oRjzYEqdXTWwyUvPDmKNkarlGJuMFf)
 def dp_SuperSection_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS,args):
  oRjzYEqdXTWwyUvPDmKNkarlGJuMgi =args.get('suburl')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMxh=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.Get_SuperMultiSection_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMgi)
  for oRjzYEqdXTWwyUvPDmKNkarlGJuMxt in oRjzYEqdXTWwyUvPDmKNkarlGJuMxh:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIs =oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('title')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMgA =oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('subapi')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMgp=oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('cell_type')
   if oRjzYEqdXTWwyUvPDmKNkarlGJuMgA.find('mtype=svod')>=0 or oRjzYEqdXTWwyUvPDmKNkarlGJuMgA.find('mtype=ppv')>=0:
    oRjzYEqdXTWwyUvPDmKNkarlGJuMIb='MOVIE_LIST'
   elif oRjzYEqdXTWwyUvPDmKNkarlGJuMgp=='band_71':
    oRjzYEqdXTWwyUvPDmKNkarlGJuMIb ='SUPERSECTION_LIST'
    (oRjzYEqdXTWwyUvPDmKNkarlGJuMgh,oRjzYEqdXTWwyUvPDmKNkarlGJuMgt)=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.Baseapi_Parse(oRjzYEqdXTWwyUvPDmKNkarlGJuMgA)
    oRjzYEqdXTWwyUvPDmKNkarlGJuMgi=oRjzYEqdXTWwyUvPDmKNkarlGJuMgt.get('api')
    oRjzYEqdXTWwyUvPDmKNkarlGJuMgA=''
   elif oRjzYEqdXTWwyUvPDmKNkarlGJuMgp=='band_2':
    oRjzYEqdXTWwyUvPDmKNkarlGJuMIb='BAND2SECTION_LIST'
   elif oRjzYEqdXTWwyUvPDmKNkarlGJuMgp=='band_live':
    oRjzYEqdXTWwyUvPDmKNkarlGJuMIb='BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}',oRjzYEqdXTWwyUvPDmKNkarlGJuMgA):
    oRjzYEqdXTWwyUvPDmKNkarlGJuMIb='MOVIE_LIST'
   else:
    oRjzYEqdXTWwyUvPDmKNkarlGJuMIb='PROGRAM_LIST'
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxi={'plot':oRjzYEqdXTWwyUvPDmKNkarlGJuMIs,'mediatype':'tvshow'}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi={'mode':oRjzYEqdXTWwyUvPDmKNkarlGJuMIb,'suburl':oRjzYEqdXTWwyUvPDmKNkarlGJuMgi,'subapi':oRjzYEqdXTWwyUvPDmKNkarlGJuMgA,'page':'1'}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.add_dir(oRjzYEqdXTWwyUvPDmKNkarlGJuMIs,sublabel='',img=oRjzYEqdXTWwyUvPDmKNkarlGJuMFb,infoLabels=oRjzYEqdXTWwyUvPDmKNkarlGJuMxi,isFolder=oRjzYEqdXTWwyUvPDmKNkarlGJuMFH,params=oRjzYEqdXTWwyUvPDmKNkarlGJuMIi)
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMSx(oRjzYEqdXTWwyUvPDmKNkarlGJuMxh)>0:xbmcplugin.endOfDirectory(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS._addon_handle,cacheToDisc=oRjzYEqdXTWwyUvPDmKNkarlGJuMFf)
 def dp_BandLiveSection_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS,args):
  oRjzYEqdXTWwyUvPDmKNkarlGJuMgA =args.get('subapi')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMxp=oRjzYEqdXTWwyUvPDmKNkarlGJuMFe(args.get('page'))
  oRjzYEqdXTWwyUvPDmKNkarlGJuMxh,oRjzYEqdXTWwyUvPDmKNkarlGJuMIf=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.Get_BandLiveSection_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMgA,oRjzYEqdXTWwyUvPDmKNkarlGJuMxp)
  for oRjzYEqdXTWwyUvPDmKNkarlGJuMxt in oRjzYEqdXTWwyUvPDmKNkarlGJuMxh:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMgL =oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('channelid')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMgO =oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('studio')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMgB=oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('tvshowtitle')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxB =oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('thumbnail')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxb =oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('age')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxi={'mediatype':'tvshow','mpaa':oRjzYEqdXTWwyUvPDmKNkarlGJuMxb,'title':'%s < %s >'%(oRjzYEqdXTWwyUvPDmKNkarlGJuMgO,oRjzYEqdXTWwyUvPDmKNkarlGJuMgB),'tvshowtitle':oRjzYEqdXTWwyUvPDmKNkarlGJuMgB,'studio':oRjzYEqdXTWwyUvPDmKNkarlGJuMgO,'plot':oRjzYEqdXTWwyUvPDmKNkarlGJuMgO}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi={'mode':'LIVE','contentid':oRjzYEqdXTWwyUvPDmKNkarlGJuMgL}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.add_dir(oRjzYEqdXTWwyUvPDmKNkarlGJuMgO,sublabel=oRjzYEqdXTWwyUvPDmKNkarlGJuMgB,img=oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('thumbnail'),infoLabels=oRjzYEqdXTWwyUvPDmKNkarlGJuMxi,isFolder=oRjzYEqdXTWwyUvPDmKNkarlGJuMFf,params=oRjzYEqdXTWwyUvPDmKNkarlGJuMIi)
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMIf:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi={}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi['mode'] ='BANDLIVESECTION_LIST' 
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi['subapi']=oRjzYEqdXTWwyUvPDmKNkarlGJuMgA
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi['page'] =oRjzYEqdXTWwyUvPDmKNkarlGJuMSQ(oRjzYEqdXTWwyUvPDmKNkarlGJuMxp+1)
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIs='[B]%s >>[/B]'%'다음 페이지'
   oRjzYEqdXTWwyUvPDmKNkarlGJuMnI=oRjzYEqdXTWwyUvPDmKNkarlGJuMSQ(oRjzYEqdXTWwyUvPDmKNkarlGJuMxp+1)
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIA=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.add_dir(oRjzYEqdXTWwyUvPDmKNkarlGJuMIs,sublabel=oRjzYEqdXTWwyUvPDmKNkarlGJuMnI,img=oRjzYEqdXTWwyUvPDmKNkarlGJuMIA,infoLabels=oRjzYEqdXTWwyUvPDmKNkarlGJuMFb,isFolder=oRjzYEqdXTWwyUvPDmKNkarlGJuMFH,params=oRjzYEqdXTWwyUvPDmKNkarlGJuMIi)
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMSx(oRjzYEqdXTWwyUvPDmKNkarlGJuMxh)>0:xbmcplugin.endOfDirectory(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS._addon_handle,cacheToDisc=oRjzYEqdXTWwyUvPDmKNkarlGJuMFf)
 def dp_Band2Section_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS,args):
  oRjzYEqdXTWwyUvPDmKNkarlGJuMgA =args.get('subapi')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMxp=oRjzYEqdXTWwyUvPDmKNkarlGJuMFe(args.get('page'))
  oRjzYEqdXTWwyUvPDmKNkarlGJuMxh,oRjzYEqdXTWwyUvPDmKNkarlGJuMIf=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.Get_Band2Section_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMgA,oRjzYEqdXTWwyUvPDmKNkarlGJuMxp)
  for oRjzYEqdXTWwyUvPDmKNkarlGJuMxt in oRjzYEqdXTWwyUvPDmKNkarlGJuMxh:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIs =oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('programtitle')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMnI =oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('episodetitle')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxi={'plot':oRjzYEqdXTWwyUvPDmKNkarlGJuMIs+'\n\n'+oRjzYEqdXTWwyUvPDmKNkarlGJuMnI,'mpaa':oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('age'),'mediatype':'episode'}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi={'mode':'VOD','programid':'-','contentid':oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('videoid'),'thumbnail':oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('thumbnail'),'title':oRjzYEqdXTWwyUvPDmKNkarlGJuMIs,'subtitle':oRjzYEqdXTWwyUvPDmKNkarlGJuMnI}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.add_dir(oRjzYEqdXTWwyUvPDmKNkarlGJuMIs,sublabel=oRjzYEqdXTWwyUvPDmKNkarlGJuMnI,img=oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('thumbnail'),infoLabels=oRjzYEqdXTWwyUvPDmKNkarlGJuMxi,isFolder=oRjzYEqdXTWwyUvPDmKNkarlGJuMFf,params=oRjzYEqdXTWwyUvPDmKNkarlGJuMIi)
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMIf:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi={}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi['mode'] ='BAND2SECTION_LIST' 
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi['subapi']=oRjzYEqdXTWwyUvPDmKNkarlGJuMgA
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi['page'] =oRjzYEqdXTWwyUvPDmKNkarlGJuMSQ(oRjzYEqdXTWwyUvPDmKNkarlGJuMxp+1)
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIs='[B]%s >>[/B]'%'다음 페이지'
   oRjzYEqdXTWwyUvPDmKNkarlGJuMnI=oRjzYEqdXTWwyUvPDmKNkarlGJuMSQ(oRjzYEqdXTWwyUvPDmKNkarlGJuMxp+1)
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIA=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.add_dir(oRjzYEqdXTWwyUvPDmKNkarlGJuMIs,sublabel=oRjzYEqdXTWwyUvPDmKNkarlGJuMnI,img=oRjzYEqdXTWwyUvPDmKNkarlGJuMIA,infoLabels=oRjzYEqdXTWwyUvPDmKNkarlGJuMFb,isFolder=oRjzYEqdXTWwyUvPDmKNkarlGJuMFH,params=oRjzYEqdXTWwyUvPDmKNkarlGJuMIi)
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMSx(oRjzYEqdXTWwyUvPDmKNkarlGJuMxh)>0:xbmcplugin.endOfDirectory(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS._addon_handle,cacheToDisc=oRjzYEqdXTWwyUvPDmKNkarlGJuMFf)
 def dp_Movie_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS,args):
  oRjzYEqdXTWwyUvPDmKNkarlGJuMgA =args.get('subapi')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMxp=oRjzYEqdXTWwyUvPDmKNkarlGJuMFe(args.get('page'))
  oRjzYEqdXTWwyUvPDmKNkarlGJuMxh,oRjzYEqdXTWwyUvPDmKNkarlGJuMIf=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.Get_Movie_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMgA,oRjzYEqdXTWwyUvPDmKNkarlGJuMxp)
  for oRjzYEqdXTWwyUvPDmKNkarlGJuMxt in oRjzYEqdXTWwyUvPDmKNkarlGJuMxh:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxL =oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('videoid')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxO =oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('vidtype')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIs =oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('title')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxB=oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('thumbnail')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxb =oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('age')
   if oRjzYEqdXTWwyUvPDmKNkarlGJuMxb=='18' or oRjzYEqdXTWwyUvPDmKNkarlGJuMxb=='19' or oRjzYEqdXTWwyUvPDmKNkarlGJuMxb=='21':oRjzYEqdXTWwyUvPDmKNkarlGJuMIs+=' (%s)'%(oRjzYEqdXTWwyUvPDmKNkarlGJuMxb)
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxi={'plot':oRjzYEqdXTWwyUvPDmKNkarlGJuMIs,'mpaa':oRjzYEqdXTWwyUvPDmKNkarlGJuMxb,'mediatype':'movie'}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi={'mode':'MOVIE','contentid':oRjzYEqdXTWwyUvPDmKNkarlGJuMxL,'title':oRjzYEqdXTWwyUvPDmKNkarlGJuMIs,'thumbnail':oRjzYEqdXTWwyUvPDmKNkarlGJuMxB,'age':oRjzYEqdXTWwyUvPDmKNkarlGJuMxb,}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxA=[]
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxe={'mode':'VIEW_DETAIL','values':{'videoid':oRjzYEqdXTWwyUvPDmKNkarlGJuMxL,'vidtype':'movie','contenttype':oRjzYEqdXTWwyUvPDmKNkarlGJuMxO,}}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxH=json.dumps(oRjzYEqdXTWwyUvPDmKNkarlGJuMxe,separators=(',',':'))
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxH=base64.standard_b64encode(oRjzYEqdXTWwyUvPDmKNkarlGJuMxH.encode()).decode('utf-8')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxH=oRjzYEqdXTWwyUvPDmKNkarlGJuMxH.replace('+','%2B')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxf='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(oRjzYEqdXTWwyUvPDmKNkarlGJuMxH)
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxA.append(('상세정보 조회',oRjzYEqdXTWwyUvPDmKNkarlGJuMxf))
   if oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.get_settings_makebookmark():
    oRjzYEqdXTWwyUvPDmKNkarlGJuMxe={'videoid':oRjzYEqdXTWwyUvPDmKNkarlGJuMxL,'vidtype':'movie','vtitle':oRjzYEqdXTWwyUvPDmKNkarlGJuMIs,'vsubtitle':'','contenttype':'programid',}
    oRjzYEqdXTWwyUvPDmKNkarlGJuMnC=json.dumps(oRjzYEqdXTWwyUvPDmKNkarlGJuMxe)
    oRjzYEqdXTWwyUvPDmKNkarlGJuMnC=urllib.parse.quote(oRjzYEqdXTWwyUvPDmKNkarlGJuMnC)
    oRjzYEqdXTWwyUvPDmKNkarlGJuMxf='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(oRjzYEqdXTWwyUvPDmKNkarlGJuMnC)
    oRjzYEqdXTWwyUvPDmKNkarlGJuMxA.append(('(통합) 찜 영상에 추가',oRjzYEqdXTWwyUvPDmKNkarlGJuMxf))
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.add_dir(oRjzYEqdXTWwyUvPDmKNkarlGJuMIs,sublabel='',img=oRjzYEqdXTWwyUvPDmKNkarlGJuMxB,infoLabels=oRjzYEqdXTWwyUvPDmKNkarlGJuMxi,isFolder=oRjzYEqdXTWwyUvPDmKNkarlGJuMFf,params=oRjzYEqdXTWwyUvPDmKNkarlGJuMIi,ContextMenu=oRjzYEqdXTWwyUvPDmKNkarlGJuMxA)
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMIf:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi={}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi['mode'] ='MOVIE_LIST' 
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi['subapi']=oRjzYEqdXTWwyUvPDmKNkarlGJuMgA 
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi['page'] =oRjzYEqdXTWwyUvPDmKNkarlGJuMSQ(oRjzYEqdXTWwyUvPDmKNkarlGJuMxp+1)
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIs='[B]%s >>[/B]'%'다음 페이지'
   oRjzYEqdXTWwyUvPDmKNkarlGJuMnI=oRjzYEqdXTWwyUvPDmKNkarlGJuMSQ(oRjzYEqdXTWwyUvPDmKNkarlGJuMxp+1)
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIA=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.add_dir(oRjzYEqdXTWwyUvPDmKNkarlGJuMIs,sublabel=oRjzYEqdXTWwyUvPDmKNkarlGJuMnI,img=oRjzYEqdXTWwyUvPDmKNkarlGJuMIA,infoLabels=oRjzYEqdXTWwyUvPDmKNkarlGJuMFb,isFolder=oRjzYEqdXTWwyUvPDmKNkarlGJuMFH,params=oRjzYEqdXTWwyUvPDmKNkarlGJuMIi)
  xbmcplugin.setContent(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS._addon_handle,'movies')
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMSx(oRjzYEqdXTWwyUvPDmKNkarlGJuMxh)>0:xbmcplugin.endOfDirectory(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS._addon_handle,cacheToDisc=oRjzYEqdXTWwyUvPDmKNkarlGJuMFf)
 def dp_Set_Bookmark(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS,args):
  oRjzYEqdXTWwyUvPDmKNkarlGJuMgb=urllib.parse.unquote(args.get('bm_param'))
  oRjzYEqdXTWwyUvPDmKNkarlGJuMgb=json.loads(oRjzYEqdXTWwyUvPDmKNkarlGJuMgb)
  oRjzYEqdXTWwyUvPDmKNkarlGJuMxL =oRjzYEqdXTWwyUvPDmKNkarlGJuMgb.get('videoid')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMxO =oRjzYEqdXTWwyUvPDmKNkarlGJuMgb.get('vidtype')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMge =oRjzYEqdXTWwyUvPDmKNkarlGJuMgb.get('vtitle')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMgH =oRjzYEqdXTWwyUvPDmKNkarlGJuMgb.get('vsubtitle')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMgf=oRjzYEqdXTWwyUvPDmKNkarlGJuMgb.get('contenttype')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMCi=xbmcgui.Dialog()
  oRjzYEqdXTWwyUvPDmKNkarlGJuMnO=oRjzYEqdXTWwyUvPDmKNkarlGJuMCi.yesno(__language__(30913).encode('utf8'),oRjzYEqdXTWwyUvPDmKNkarlGJuMge+' \n\n'+__language__(30914))
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMnO==oRjzYEqdXTWwyUvPDmKNkarlGJuMFf:return
  oRjzYEqdXTWwyUvPDmKNkarlGJuMFC=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.GetBookmarkInfo(oRjzYEqdXTWwyUvPDmKNkarlGJuMxL,oRjzYEqdXTWwyUvPDmKNkarlGJuMxO,oRjzYEqdXTWwyUvPDmKNkarlGJuMgf)
  oRjzYEqdXTWwyUvPDmKNkarlGJuMFI=json.dumps(oRjzYEqdXTWwyUvPDmKNkarlGJuMFC)
  oRjzYEqdXTWwyUvPDmKNkarlGJuMFI=urllib.parse.quote(oRjzYEqdXTWwyUvPDmKNkarlGJuMFI)
  oRjzYEqdXTWwyUvPDmKNkarlGJuMxf ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(oRjzYEqdXTWwyUvPDmKNkarlGJuMFI)
  xbmc.executebuiltin(oRjzYEqdXTWwyUvPDmKNkarlGJuMxf)
 def dp_Episode_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS,args):
  oRjzYEqdXTWwyUvPDmKNkarlGJuMxL =args.get('videoid')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMxO =args.get('vidtype')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMxp=oRjzYEqdXTWwyUvPDmKNkarlGJuMFe(args.get('page'))
  oRjzYEqdXTWwyUvPDmKNkarlGJuMxh,oRjzYEqdXTWwyUvPDmKNkarlGJuMIf=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.Get_Episode_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMxL,oRjzYEqdXTWwyUvPDmKNkarlGJuMxO,oRjzYEqdXTWwyUvPDmKNkarlGJuMxp,orderby=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.get_winEpisodeOrderby())
  for oRjzYEqdXTWwyUvPDmKNkarlGJuMxt in oRjzYEqdXTWwyUvPDmKNkarlGJuMxh:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMnI='%s회, %s(%s)'%(oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('episodenumber'),oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('releasedate'),oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('releaseweekday'))
   oRjzYEqdXTWwyUvPDmKNkarlGJuMFx ='[%s]\n\n%s'%(oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('episodetitle'),oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('synopsis'))
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxi={'mediatype':'episode','title':oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('programtitle'),'year':oRjzYEqdXTWwyUvPDmKNkarlGJuMFe(oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('releasedate')[:4]),'aired':oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('releasedate'),'mpaa':oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('age'),'episode':oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('episodenumber'),'duration':oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('playtime'),'plot':oRjzYEqdXTWwyUvPDmKNkarlGJuMFx,'cast':oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('episodeactors')}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi={'mode':'VOD','programid':oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('programid'),'contentid':oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('contentid'),'thumbnail':oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('thumbnail'),'title':oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('programtitle'),'subtitle':oRjzYEqdXTWwyUvPDmKNkarlGJuMnI}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.add_dir(oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('programtitle'),sublabel=oRjzYEqdXTWwyUvPDmKNkarlGJuMnI,img=oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('thumbnail'),infoLabels=oRjzYEqdXTWwyUvPDmKNkarlGJuMxi,isFolder=oRjzYEqdXTWwyUvPDmKNkarlGJuMFf,params=oRjzYEqdXTWwyUvPDmKNkarlGJuMIi)
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMxp==1:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxi={'plot':'정렬순서를 변경합니다.'}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi={}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi['mode'] ='ORDER_BY' 
   if oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.get_winEpisodeOrderby()=='desc':
    oRjzYEqdXTWwyUvPDmKNkarlGJuMIs='정렬순서변경 : 최신화부터 -> 1회부터'
    oRjzYEqdXTWwyUvPDmKNkarlGJuMIi['orderby']='asc'
   else:
    oRjzYEqdXTWwyUvPDmKNkarlGJuMIs='정렬순서변경 : 1회부터 -> 최신화부터'
    oRjzYEqdXTWwyUvPDmKNkarlGJuMIi['orderby']='desc'
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIA=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.add_dir(oRjzYEqdXTWwyUvPDmKNkarlGJuMIs,sublabel='',img=oRjzYEqdXTWwyUvPDmKNkarlGJuMIA,infoLabels=oRjzYEqdXTWwyUvPDmKNkarlGJuMxi,isFolder=oRjzYEqdXTWwyUvPDmKNkarlGJuMFf,params=oRjzYEqdXTWwyUvPDmKNkarlGJuMIi,isLink=oRjzYEqdXTWwyUvPDmKNkarlGJuMFH)
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMIf:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi={}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi['mode'] ='EPISODE_LIST' 
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi['videoid']=oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('programid')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi['vidtype']='programid'
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi['page'] =oRjzYEqdXTWwyUvPDmKNkarlGJuMSQ(oRjzYEqdXTWwyUvPDmKNkarlGJuMxp+1)
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIs='[B]%s >>[/B]'%'다음 페이지'
   oRjzYEqdXTWwyUvPDmKNkarlGJuMnI=oRjzYEqdXTWwyUvPDmKNkarlGJuMSQ(oRjzYEqdXTWwyUvPDmKNkarlGJuMxp+1)
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIA=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.add_dir(oRjzYEqdXTWwyUvPDmKNkarlGJuMIs,sublabel=oRjzYEqdXTWwyUvPDmKNkarlGJuMnI,img=oRjzYEqdXTWwyUvPDmKNkarlGJuMIA,infoLabels=oRjzYEqdXTWwyUvPDmKNkarlGJuMFb,isFolder=oRjzYEqdXTWwyUvPDmKNkarlGJuMFH,params=oRjzYEqdXTWwyUvPDmKNkarlGJuMIi)
  xbmcplugin.setContent(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS._addon_handle,'episodes')
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMSx(oRjzYEqdXTWwyUvPDmKNkarlGJuMxh)>0:xbmcplugin.endOfDirectory(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS._addon_handle,cacheToDisc=oRjzYEqdXTWwyUvPDmKNkarlGJuMFf)
 def dp_LiveChannel_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS,args):
  oRjzYEqdXTWwyUvPDmKNkarlGJuMFn =args.get('genre')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMgc=args.get('baseapi')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMxh=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.Get_LiveChannel_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMFn,oRjzYEqdXTWwyUvPDmKNkarlGJuMgc)
  for oRjzYEqdXTWwyUvPDmKNkarlGJuMxt in oRjzYEqdXTWwyUvPDmKNkarlGJuMxh:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMgL =oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('channelid')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMgO =oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('studio')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMgB=oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('tvshowtitle')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxB =oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('thumbnail')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxb =oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('age')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMFQ =oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('epg')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxi={'mediatype':'episode','mpaa':oRjzYEqdXTWwyUvPDmKNkarlGJuMxb,'title':'%s < %s >'%(oRjzYEqdXTWwyUvPDmKNkarlGJuMgO,oRjzYEqdXTWwyUvPDmKNkarlGJuMgB),'tvshowtitle':oRjzYEqdXTWwyUvPDmKNkarlGJuMgB,'studio':oRjzYEqdXTWwyUvPDmKNkarlGJuMgO,'plot':'%s\n\n%s'%(oRjzYEqdXTWwyUvPDmKNkarlGJuMgO,oRjzYEqdXTWwyUvPDmKNkarlGJuMFQ)}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi={'mode':'LIVE','contentid':oRjzYEqdXTWwyUvPDmKNkarlGJuMgL}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.add_dir(oRjzYEqdXTWwyUvPDmKNkarlGJuMgO,sublabel=oRjzYEqdXTWwyUvPDmKNkarlGJuMgB,img=oRjzYEqdXTWwyUvPDmKNkarlGJuMxB,infoLabels=oRjzYEqdXTWwyUvPDmKNkarlGJuMxi,isFolder=oRjzYEqdXTWwyUvPDmKNkarlGJuMFf,params=oRjzYEqdXTWwyUvPDmKNkarlGJuMIi)
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMSx(oRjzYEqdXTWwyUvPDmKNkarlGJuMxh)>0:xbmcplugin.endOfDirectory(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS._addon_handle,cacheToDisc=oRjzYEqdXTWwyUvPDmKNkarlGJuMFf)
 def dp_Sports_GameList(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS,args):
  oRjzYEqdXTWwyUvPDmKNkarlGJuMxh=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.Get_Sports_Gamelist()
  for oRjzYEqdXTWwyUvPDmKNkarlGJuMxt in oRjzYEqdXTWwyUvPDmKNkarlGJuMxh:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMFg =oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('game_date')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMFS =oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('game_time')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMFs =oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('svc_id')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMFV =oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('away_team')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMFc =oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('home_team')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMFA=oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('game_status')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMFi =oRjzYEqdXTWwyUvPDmKNkarlGJuMxt.get('game_place')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMFp ='%s vs %s (%s)'%(oRjzYEqdXTWwyUvPDmKNkarlGJuMFV,oRjzYEqdXTWwyUvPDmKNkarlGJuMFc,oRjzYEqdXTWwyUvPDmKNkarlGJuMFi)
   oRjzYEqdXTWwyUvPDmKNkarlGJuMFh =oRjzYEqdXTWwyUvPDmKNkarlGJuMFg+' '+oRjzYEqdXTWwyUvPDmKNkarlGJuMFS
   if oRjzYEqdXTWwyUvPDmKNkarlGJuMFA=='LIVE':
    oRjzYEqdXTWwyUvPDmKNkarlGJuMFA='~경기중~'
   elif oRjzYEqdXTWwyUvPDmKNkarlGJuMFA=='END':
    oRjzYEqdXTWwyUvPDmKNkarlGJuMFA='경기종료'
   elif oRjzYEqdXTWwyUvPDmKNkarlGJuMFA=='CANCEL':
    oRjzYEqdXTWwyUvPDmKNkarlGJuMFA='취소'
   else:
    oRjzYEqdXTWwyUvPDmKNkarlGJuMFA=''
   if oRjzYEqdXTWwyUvPDmKNkarlGJuMFA=='':
    oRjzYEqdXTWwyUvPDmKNkarlGJuMnI=oRjzYEqdXTWwyUvPDmKNkarlGJuMFp
   else:
    oRjzYEqdXTWwyUvPDmKNkarlGJuMnI=oRjzYEqdXTWwyUvPDmKNkarlGJuMFp+'  '+oRjzYEqdXTWwyUvPDmKNkarlGJuMFA
   oRjzYEqdXTWwyUvPDmKNkarlGJuMxi={'mediatype':'episode','title':oRjzYEqdXTWwyUvPDmKNkarlGJuMFp,'plot':'%s\n\n%s\n\n%s'%(oRjzYEqdXTWwyUvPDmKNkarlGJuMFh,oRjzYEqdXTWwyUvPDmKNkarlGJuMFp,oRjzYEqdXTWwyUvPDmKNkarlGJuMFA)}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi={'mode':'SPORTS','contentid':oRjzYEqdXTWwyUvPDmKNkarlGJuMFs}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.add_dir(oRjzYEqdXTWwyUvPDmKNkarlGJuMFh,sublabel=oRjzYEqdXTWwyUvPDmKNkarlGJuMnI,img='',infoLabels=oRjzYEqdXTWwyUvPDmKNkarlGJuMxi,isFolder=oRjzYEqdXTWwyUvPDmKNkarlGJuMFf,params=oRjzYEqdXTWwyUvPDmKNkarlGJuMIi)
  xbmcplugin.endOfDirectory(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS._addon_handle,cacheToDisc=oRjzYEqdXTWwyUvPDmKNkarlGJuMFf)
 def dp_View_Detail(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS,oRjzYEqdXTWwyUvPDmKNkarlGJuMFO):
  oRjzYEqdXTWwyUvPDmKNkarlGJuMxL =oRjzYEqdXTWwyUvPDmKNkarlGJuMFO.get('videoid')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMxO =oRjzYEqdXTWwyUvPDmKNkarlGJuMFO.get('vidtype') 
  oRjzYEqdXTWwyUvPDmKNkarlGJuMgf=oRjzYEqdXTWwyUvPDmKNkarlGJuMFO.get('contenttype')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.addon_log(oRjzYEqdXTWwyUvPDmKNkarlGJuMxL)
  oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.addon_log(oRjzYEqdXTWwyUvPDmKNkarlGJuMxO)
  oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.addon_log(oRjzYEqdXTWwyUvPDmKNkarlGJuMgf)
  oRjzYEqdXTWwyUvPDmKNkarlGJuMFC=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.WavveObj.GetBookmarkInfo(oRjzYEqdXTWwyUvPDmKNkarlGJuMxL,oRjzYEqdXTWwyUvPDmKNkarlGJuMxO,oRjzYEqdXTWwyUvPDmKNkarlGJuMgf)
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMxO=='tvshow':
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi={'mode':'EPISODE_LIST','videoid':oRjzYEqdXTWwyUvPDmKNkarlGJuMFC['indexinfo']['videoid'],'vidtype':oRjzYEqdXTWwyUvPDmKNkarlGJuMFC['indexinfo']['vidtype'],'page':'1',}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMnH='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(oRjzYEqdXTWwyUvPDmKNkarlGJuMIi))
  else:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIi={'mode':'MOVIE','contentid':oRjzYEqdXTWwyUvPDmKNkarlGJuMFC['indexinfo']['videoid'],'title':oRjzYEqdXTWwyUvPDmKNkarlGJuMFC['saveinfo']['infoLabels']['title'],'thumbnail':oRjzYEqdXTWwyUvPDmKNkarlGJuMFC['saveinfo']['thumbnail'],'age':oRjzYEqdXTWwyUvPDmKNkarlGJuMFC['saveinfo']['infoLabels']['mpaa'],}
   oRjzYEqdXTWwyUvPDmKNkarlGJuMnH='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(oRjzYEqdXTWwyUvPDmKNkarlGJuMIi))
  oRjzYEqdXTWwyUvPDmKNkarlGJuMIV=xbmcgui.ListItem(label=oRjzYEqdXTWwyUvPDmKNkarlGJuMFC['saveinfo']['title'],path=oRjzYEqdXTWwyUvPDmKNkarlGJuMnH)
  oRjzYEqdXTWwyUvPDmKNkarlGJuMIV.setArt(oRjzYEqdXTWwyUvPDmKNkarlGJuMFC['saveinfo']['thumbnail'])
  oRjzYEqdXTWwyUvPDmKNkarlGJuMIV.setInfo('Video',oRjzYEqdXTWwyUvPDmKNkarlGJuMFC['saveinfo']['infoLabels'])
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMxO=='movie':
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIV.setIsFolder(oRjzYEqdXTWwyUvPDmKNkarlGJuMFf)
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIV.setProperty('IsPlayable','true')
  else:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIV.setIsFolder(oRjzYEqdXTWwyUvPDmKNkarlGJuMFH)
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIV.setProperty('IsPlayable','false')
  oRjzYEqdXTWwyUvPDmKNkarlGJuMCi=xbmcgui.Dialog()
  oRjzYEqdXTWwyUvPDmKNkarlGJuMCi.info(oRjzYEqdXTWwyUvPDmKNkarlGJuMIV)
 def wavve_main(oRjzYEqdXTWwyUvPDmKNkarlGJuMCS):
  oRjzYEqdXTWwyUvPDmKNkarlGJuMFt=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.main_params.get('params')
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMFt:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMFL =base64.standard_b64decode(oRjzYEqdXTWwyUvPDmKNkarlGJuMFt).decode('utf-8')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMFL =json.loads(oRjzYEqdXTWwyUvPDmKNkarlGJuMFL)
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIb =oRjzYEqdXTWwyUvPDmKNkarlGJuMFL.get('mode')
   oRjzYEqdXTWwyUvPDmKNkarlGJuMFO =oRjzYEqdXTWwyUvPDmKNkarlGJuMFL.get('values')
  else:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMIb=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.main_params.get('mode',oRjzYEqdXTWwyUvPDmKNkarlGJuMFb)
   oRjzYEqdXTWwyUvPDmKNkarlGJuMFO=oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.main_params
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMIb=='LOGOUT':
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.logout()
   return
  oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.login_main()
  if oRjzYEqdXTWwyUvPDmKNkarlGJuMIb is oRjzYEqdXTWwyUvPDmKNkarlGJuMFb:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.dp_Main_List()
  elif oRjzYEqdXTWwyUvPDmKNkarlGJuMIb in['LIVE','VOD','MOVIE','SPORTS']:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.play_VIDEO(oRjzYEqdXTWwyUvPDmKNkarlGJuMFO)
  elif oRjzYEqdXTWwyUvPDmKNkarlGJuMIb=='LIVE_CATAGORY':
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.dp_LiveCatagory_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMFO)
  elif oRjzYEqdXTWwyUvPDmKNkarlGJuMIb=='MAIN_CATAGORY':
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.dp_MainCatagory_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMFO)
  elif oRjzYEqdXTWwyUvPDmKNkarlGJuMIb=='SUPERSECTION_LIST':
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.dp_SuperSection_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMFO)
  elif oRjzYEqdXTWwyUvPDmKNkarlGJuMIb=='BANDLIVESECTION_LIST':
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.dp_BandLiveSection_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMFO)
  elif oRjzYEqdXTWwyUvPDmKNkarlGJuMIb=='BAND2SECTION_LIST':
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.dp_Band2Section_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMFO)
  elif oRjzYEqdXTWwyUvPDmKNkarlGJuMIb=='PROGRAM_LIST':
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.dp_Program_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMFO)
  elif oRjzYEqdXTWwyUvPDmKNkarlGJuMIb=='EPISODE_LIST':
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.dp_Episode_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMFO)
  elif oRjzYEqdXTWwyUvPDmKNkarlGJuMIb=='MOVIE_LIST':
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.dp_Movie_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMFO)
  elif oRjzYEqdXTWwyUvPDmKNkarlGJuMIb=='LIVE_LIST':
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.dp_LiveChannel_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMFO)
  elif oRjzYEqdXTWwyUvPDmKNkarlGJuMIb=='ORDER_BY':
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.dp_setEpOrderby(oRjzYEqdXTWwyUvPDmKNkarlGJuMFO)
  elif oRjzYEqdXTWwyUvPDmKNkarlGJuMIb=='SEARCH_GROUP':
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.dp_Search_Group(oRjzYEqdXTWwyUvPDmKNkarlGJuMFO)
  elif oRjzYEqdXTWwyUvPDmKNkarlGJuMIb in['SEARCH_LIST','LOCAL_SEARCH']:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.dp_Search_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMFO)
  elif oRjzYEqdXTWwyUvPDmKNkarlGJuMIb=='WATCH_GROUP':
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.dp_Watch_Group(oRjzYEqdXTWwyUvPDmKNkarlGJuMFO)
  elif oRjzYEqdXTWwyUvPDmKNkarlGJuMIb=='WATCH_LIST':
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.dp_Watch_List(oRjzYEqdXTWwyUvPDmKNkarlGJuMFO)
  elif oRjzYEqdXTWwyUvPDmKNkarlGJuMIb=='SET_BOOKMARK':
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.dp_Set_Bookmark(oRjzYEqdXTWwyUvPDmKNkarlGJuMFO)
  elif oRjzYEqdXTWwyUvPDmKNkarlGJuMIb in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.dp_History_Remove(oRjzYEqdXTWwyUvPDmKNkarlGJuMFO)
  elif oRjzYEqdXTWwyUvPDmKNkarlGJuMIb in['TOTAL_SEARCH','TOTAL_HISTORY']:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.dp_Global_Search(oRjzYEqdXTWwyUvPDmKNkarlGJuMFO)
  elif oRjzYEqdXTWwyUvPDmKNkarlGJuMIb=='SEARCH_HISTORY':
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.dp_Search_History(oRjzYEqdXTWwyUvPDmKNkarlGJuMFO)
  elif oRjzYEqdXTWwyUvPDmKNkarlGJuMIb=='MENU_BOOKMARK':
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.dp_Bookmark_Menu(oRjzYEqdXTWwyUvPDmKNkarlGJuMFO)
  elif oRjzYEqdXTWwyUvPDmKNkarlGJuMIb=='GAME_LIST':
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.dp_Sports_GameList(oRjzYEqdXTWwyUvPDmKNkarlGJuMFO)
  elif oRjzYEqdXTWwyUvPDmKNkarlGJuMIb=='VIEW_DETAIL':
   oRjzYEqdXTWwyUvPDmKNkarlGJuMCS.dp_View_Detail(oRjzYEqdXTWwyUvPDmKNkarlGJuMFO)
  else:
   oRjzYEqdXTWwyUvPDmKNkarlGJuMFb
# Created by pyminifier (https://github.com/liftoff/pyminifier)
