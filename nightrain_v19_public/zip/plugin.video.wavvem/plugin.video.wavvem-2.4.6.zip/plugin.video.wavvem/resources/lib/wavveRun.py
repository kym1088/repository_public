__author__="NightRain"
VmBQOIMHNRAulbsCJxKPgwzcSnkUWT=object
VmBQOIMHNRAulbsCJxKPgwzcSnkUWi=None
VmBQOIMHNRAulbsCJxKPgwzcSnkUWt=int
VmBQOIMHNRAulbsCJxKPgwzcSnkUWL=True
VmBQOIMHNRAulbsCJxKPgwzcSnkUWd=False
VmBQOIMHNRAulbsCJxKPgwzcSnkUWv=type
VmBQOIMHNRAulbsCJxKPgwzcSnkUWD=dict
VmBQOIMHNRAulbsCJxKPgwzcSnkUWp=getattr
VmBQOIMHNRAulbsCJxKPgwzcSnkUWX=list
VmBQOIMHNRAulbsCJxKPgwzcSnkUWa=len
VmBQOIMHNRAulbsCJxKPgwzcSnkUWE=range
VmBQOIMHNRAulbsCJxKPgwzcSnkUWf=str
VmBQOIMHNRAulbsCJxKPgwzcSnkUWY=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import json
VmBQOIMHNRAulbsCJxKPgwzcSnkUeF=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://apis.wavve.com/v1/multiband/GN51','icon':'home.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&uicode=VN500','page':'1','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/allprograms?WeekDay=all&broadcastid=VN1000&came=MainCategory&contenttype=program&genre=01&uicode=VN1000&uiparent=GN56&uirank=21&uitype=VN1000','page':'1','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/allprograms?WeekDay=all&adult=n&broadcastid=VN1001&came=MainCategory&contenttype=program&genre=02&subgenre=all&uicode=VN1001&uiparent=GN57&uirank=17&uitype=VN1001','page':'1','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'CN21','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'vod09','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'vod09','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'4','sType':'movie','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'4','sType':'movie','orderby':'modifydate','ordernm':'업데이트순','icon':''},{'title':'프로야구 - 경기중 시청가능','mode':'GAME_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'(웨이브) 검색','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'(웨이브) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
VmBQOIMHNRAulbsCJxKPgwzcSnkUey=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
VmBQOIMHNRAulbsCJxKPgwzcSnkUer=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
VmBQOIMHNRAulbsCJxKPgwzcSnkUeo={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
VmBQOIMHNRAulbsCJxKPgwzcSnkUeG =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
VmBQOIMHNRAulbsCJxKPgwzcSnkUeW=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_searched.txt'))
from wavveCore import*
class VmBQOIMHNRAulbsCJxKPgwzcSnkUeh(VmBQOIMHNRAulbsCJxKPgwzcSnkUWT):
 def __init__(VmBQOIMHNRAulbsCJxKPgwzcSnkUej,VmBQOIMHNRAulbsCJxKPgwzcSnkUeq,VmBQOIMHNRAulbsCJxKPgwzcSnkUeT,VmBQOIMHNRAulbsCJxKPgwzcSnkUei):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUej._addon_url =VmBQOIMHNRAulbsCJxKPgwzcSnkUeq
  VmBQOIMHNRAulbsCJxKPgwzcSnkUej._addon_handle=VmBQOIMHNRAulbsCJxKPgwzcSnkUeT
  VmBQOIMHNRAulbsCJxKPgwzcSnkUej.main_params =VmBQOIMHNRAulbsCJxKPgwzcSnkUei
  VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj =kJweEUzCRBodXmSnYFiKxthWMrcfPl() 
  VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.WV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_stream(mpd,m3u8)'))
 def addon_noti(VmBQOIMHNRAulbsCJxKPgwzcSnkUej,sting):
  try:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUeL=xbmcgui.Dialog()
   VmBQOIMHNRAulbsCJxKPgwzcSnkUeL.notification(__addonname__,sting)
  except:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUWi
 def addon_log(VmBQOIMHNRAulbsCJxKPgwzcSnkUej,string):
  try:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUed=string.encode('utf-8','ignore')
  except:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUed='addonException: addon_log'
  VmBQOIMHNRAulbsCJxKPgwzcSnkUev=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,VmBQOIMHNRAulbsCJxKPgwzcSnkUed),level=VmBQOIMHNRAulbsCJxKPgwzcSnkUev)
 def get_keyboard_input(VmBQOIMHNRAulbsCJxKPgwzcSnkUej,VmBQOIMHNRAulbsCJxKPgwzcSnkUht):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUeD=VmBQOIMHNRAulbsCJxKPgwzcSnkUWi
  kb=xbmc.Keyboard()
  kb.setHeading(VmBQOIMHNRAulbsCJxKPgwzcSnkUht)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   VmBQOIMHNRAulbsCJxKPgwzcSnkUeD=kb.getText()
  return VmBQOIMHNRAulbsCJxKPgwzcSnkUeD
 def get_settings_account(VmBQOIMHNRAulbsCJxKPgwzcSnkUej):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUep =__addon__.getSetting('id')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUeX =__addon__.getSetting('pw')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUea=VmBQOIMHNRAulbsCJxKPgwzcSnkUWt(__addon__.getSetting('selected_profile'))
  return(VmBQOIMHNRAulbsCJxKPgwzcSnkUep,VmBQOIMHNRAulbsCJxKPgwzcSnkUeX,VmBQOIMHNRAulbsCJxKPgwzcSnkUea)
 def get_settings_totalsearch(VmBQOIMHNRAulbsCJxKPgwzcSnkUej):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUeE =VmBQOIMHNRAulbsCJxKPgwzcSnkUWL if __addon__.getSetting('local_search')=='true' else VmBQOIMHNRAulbsCJxKPgwzcSnkUWd
  VmBQOIMHNRAulbsCJxKPgwzcSnkUef=VmBQOIMHNRAulbsCJxKPgwzcSnkUWL if __addon__.getSetting('local_history')=='true' else VmBQOIMHNRAulbsCJxKPgwzcSnkUWd
  VmBQOIMHNRAulbsCJxKPgwzcSnkUeY =VmBQOIMHNRAulbsCJxKPgwzcSnkUWL if __addon__.getSetting('total_search')=='true' else VmBQOIMHNRAulbsCJxKPgwzcSnkUWd
  VmBQOIMHNRAulbsCJxKPgwzcSnkUhe=VmBQOIMHNRAulbsCJxKPgwzcSnkUWL if __addon__.getSetting('total_history')=='true' else VmBQOIMHNRAulbsCJxKPgwzcSnkUWd
  VmBQOIMHNRAulbsCJxKPgwzcSnkUhF=VmBQOIMHNRAulbsCJxKPgwzcSnkUWL if __addon__.getSetting('menu_bookmark')=='true' else VmBQOIMHNRAulbsCJxKPgwzcSnkUWd
  return(VmBQOIMHNRAulbsCJxKPgwzcSnkUeE,VmBQOIMHNRAulbsCJxKPgwzcSnkUef,VmBQOIMHNRAulbsCJxKPgwzcSnkUeY,VmBQOIMHNRAulbsCJxKPgwzcSnkUhe,VmBQOIMHNRAulbsCJxKPgwzcSnkUhF)
 def get_settings_makebookmark(VmBQOIMHNRAulbsCJxKPgwzcSnkUej):
  return VmBQOIMHNRAulbsCJxKPgwzcSnkUWL if __addon__.getSetting('make_bookmark')=='true' else VmBQOIMHNRAulbsCJxKPgwzcSnkUWd
 def get_settings_play(VmBQOIMHNRAulbsCJxKPgwzcSnkUej):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUhy={'enable_hdr':VmBQOIMHNRAulbsCJxKPgwzcSnkUWL if __addon__.getSetting('enable_hdr')=='true' else VmBQOIMHNRAulbsCJxKPgwzcSnkUWd,'enable_uhd':VmBQOIMHNRAulbsCJxKPgwzcSnkUWL if __addon__.getSetting('enable_uhd')=='true' else VmBQOIMHNRAulbsCJxKPgwzcSnkUWd,'streamFilename':VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.WV_STREAM_FILENAME,}
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUej.get_selQuality()<1080:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhy['enable_hdr']=VmBQOIMHNRAulbsCJxKPgwzcSnkUWd
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhy['enable_uhd']=VmBQOIMHNRAulbsCJxKPgwzcSnkUWd
  return(VmBQOIMHNRAulbsCJxKPgwzcSnkUhy)
 def get_settings_proxyport(VmBQOIMHNRAulbsCJxKPgwzcSnkUej):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUhr =VmBQOIMHNRAulbsCJxKPgwzcSnkUWL if __addon__.getSetting('proxyYn')=='true' else VmBQOIMHNRAulbsCJxKPgwzcSnkUWd
  VmBQOIMHNRAulbsCJxKPgwzcSnkUho=VmBQOIMHNRAulbsCJxKPgwzcSnkUWt(__addon__.getSetting('proxyPort'))
  return VmBQOIMHNRAulbsCJxKPgwzcSnkUhr,VmBQOIMHNRAulbsCJxKPgwzcSnkUho
 def get_selQuality(VmBQOIMHNRAulbsCJxKPgwzcSnkUej):
  try:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhG=[1080,720,480,360]
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhW=VmBQOIMHNRAulbsCJxKPgwzcSnkUWt(__addon__.getSetting('selected_quality'))
   return VmBQOIMHNRAulbsCJxKPgwzcSnkUhG[VmBQOIMHNRAulbsCJxKPgwzcSnkUhW]
  except:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUWi
  return 1080 
 def get_settings_exclusion21(VmBQOIMHNRAulbsCJxKPgwzcSnkUej):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUhj =__addon__.getSetting('exclusion21')
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUhj=='false':
   return VmBQOIMHNRAulbsCJxKPgwzcSnkUWd
  else:
   return VmBQOIMHNRAulbsCJxKPgwzcSnkUWL
 def get_settings_direct_replay(VmBQOIMHNRAulbsCJxKPgwzcSnkUej):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUhq=VmBQOIMHNRAulbsCJxKPgwzcSnkUWt(__addon__.getSetting('direct_replay'))
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUhq==0:
   return VmBQOIMHNRAulbsCJxKPgwzcSnkUWd
  else:
   return VmBQOIMHNRAulbsCJxKPgwzcSnkUWL
 def set_winEpisodeOrderby(VmBQOIMHNRAulbsCJxKPgwzcSnkUej,VmBQOIMHNRAulbsCJxKPgwzcSnkUhT):
  __addon__.setSetting('wavve_orderby',VmBQOIMHNRAulbsCJxKPgwzcSnkUhT)
 def get_winEpisodeOrderby(VmBQOIMHNRAulbsCJxKPgwzcSnkUej):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUhT=__addon__.getSetting('wavve_orderby')
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUhT in['',VmBQOIMHNRAulbsCJxKPgwzcSnkUWi]:VmBQOIMHNRAulbsCJxKPgwzcSnkUhT='desc'
  return VmBQOIMHNRAulbsCJxKPgwzcSnkUhT
 def add_dir(VmBQOIMHNRAulbsCJxKPgwzcSnkUej,label,sublabel='',img='',infoLabels=VmBQOIMHNRAulbsCJxKPgwzcSnkUWi,isFolder=VmBQOIMHNRAulbsCJxKPgwzcSnkUWL,params='',isLink=VmBQOIMHNRAulbsCJxKPgwzcSnkUWd,ContextMenu=VmBQOIMHNRAulbsCJxKPgwzcSnkUWi):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUhi='%s?%s'%(VmBQOIMHNRAulbsCJxKPgwzcSnkUej._addon_url,urllib.parse.urlencode(params))
  if sublabel:VmBQOIMHNRAulbsCJxKPgwzcSnkUht='%s < %s >'%(label,sublabel)
  else: VmBQOIMHNRAulbsCJxKPgwzcSnkUht=label
  if not img:img='DefaultFolder.png'
  VmBQOIMHNRAulbsCJxKPgwzcSnkUhL=xbmcgui.ListItem(VmBQOIMHNRAulbsCJxKPgwzcSnkUht)
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUWv(img)==VmBQOIMHNRAulbsCJxKPgwzcSnkUWD:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhL.setArt(img)
  else:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhL.setArt({'thumb':img,'poster':img})
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.KodiVersion>=20:
   if infoLabels:VmBQOIMHNRAulbsCJxKPgwzcSnkUej.Set_InfoTag(VmBQOIMHNRAulbsCJxKPgwzcSnkUhL.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:VmBQOIMHNRAulbsCJxKPgwzcSnkUhL.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhL.setProperty('IsPlayable','true')
  if ContextMenu:VmBQOIMHNRAulbsCJxKPgwzcSnkUhL.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(VmBQOIMHNRAulbsCJxKPgwzcSnkUej._addon_handle,VmBQOIMHNRAulbsCJxKPgwzcSnkUhi,VmBQOIMHNRAulbsCJxKPgwzcSnkUhL,isFolder)
 def Set_InfoTag(VmBQOIMHNRAulbsCJxKPgwzcSnkUej,video_InfoTag:xbmc.InfoTagVideo,VmBQOIMHNRAulbsCJxKPgwzcSnkUhf):
  for VmBQOIMHNRAulbsCJxKPgwzcSnkUhd,value in VmBQOIMHNRAulbsCJxKPgwzcSnkUhf.items():
   if VmBQOIMHNRAulbsCJxKPgwzcSnkUeo[VmBQOIMHNRAulbsCJxKPgwzcSnkUhd]['type']=='string':
    VmBQOIMHNRAulbsCJxKPgwzcSnkUWp(video_InfoTag,VmBQOIMHNRAulbsCJxKPgwzcSnkUeo[VmBQOIMHNRAulbsCJxKPgwzcSnkUhd]['func'])(value)
   elif VmBQOIMHNRAulbsCJxKPgwzcSnkUeo[VmBQOIMHNRAulbsCJxKPgwzcSnkUhd]['type']=='int':
    if VmBQOIMHNRAulbsCJxKPgwzcSnkUWv(value)==VmBQOIMHNRAulbsCJxKPgwzcSnkUWt:
     VmBQOIMHNRAulbsCJxKPgwzcSnkUhv=VmBQOIMHNRAulbsCJxKPgwzcSnkUWt(value)
    else:
     VmBQOIMHNRAulbsCJxKPgwzcSnkUhv=0
    VmBQOIMHNRAulbsCJxKPgwzcSnkUWp(video_InfoTag,VmBQOIMHNRAulbsCJxKPgwzcSnkUeo[VmBQOIMHNRAulbsCJxKPgwzcSnkUhd]['func'])(VmBQOIMHNRAulbsCJxKPgwzcSnkUhv)
   elif VmBQOIMHNRAulbsCJxKPgwzcSnkUeo[VmBQOIMHNRAulbsCJxKPgwzcSnkUhd]['type']=='actor':
    if value!=[]:
     VmBQOIMHNRAulbsCJxKPgwzcSnkUWp(video_InfoTag,VmBQOIMHNRAulbsCJxKPgwzcSnkUeo[VmBQOIMHNRAulbsCJxKPgwzcSnkUhd]['func'])([xbmc.Actor(name)for name in value])
   elif VmBQOIMHNRAulbsCJxKPgwzcSnkUeo[VmBQOIMHNRAulbsCJxKPgwzcSnkUhd]['type']=='list':
    if VmBQOIMHNRAulbsCJxKPgwzcSnkUWv(value)==VmBQOIMHNRAulbsCJxKPgwzcSnkUWX:
     VmBQOIMHNRAulbsCJxKPgwzcSnkUWp(video_InfoTag,VmBQOIMHNRAulbsCJxKPgwzcSnkUeo[VmBQOIMHNRAulbsCJxKPgwzcSnkUhd]['func'])(value)
    else:
     VmBQOIMHNRAulbsCJxKPgwzcSnkUWp(video_InfoTag,VmBQOIMHNRAulbsCJxKPgwzcSnkUeo[VmBQOIMHNRAulbsCJxKPgwzcSnkUhd]['func'])([value])
 def dp_Main_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUej):
  (VmBQOIMHNRAulbsCJxKPgwzcSnkUeE,VmBQOIMHNRAulbsCJxKPgwzcSnkUef,VmBQOIMHNRAulbsCJxKPgwzcSnkUeY,VmBQOIMHNRAulbsCJxKPgwzcSnkUhe,VmBQOIMHNRAulbsCJxKPgwzcSnkUhF)=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.get_settings_totalsearch()
  for VmBQOIMHNRAulbsCJxKPgwzcSnkUhD in VmBQOIMHNRAulbsCJxKPgwzcSnkUeF:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUht=VmBQOIMHNRAulbsCJxKPgwzcSnkUhD.get('title')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhp=''
   if VmBQOIMHNRAulbsCJxKPgwzcSnkUhD.get('mode')=='SEARCH_GROUP' and VmBQOIMHNRAulbsCJxKPgwzcSnkUeE ==VmBQOIMHNRAulbsCJxKPgwzcSnkUWd:continue
   elif VmBQOIMHNRAulbsCJxKPgwzcSnkUhD.get('mode')=='SEARCH_HISTORY' and VmBQOIMHNRAulbsCJxKPgwzcSnkUef==VmBQOIMHNRAulbsCJxKPgwzcSnkUWd:continue
   elif VmBQOIMHNRAulbsCJxKPgwzcSnkUhD.get('mode')=='TOTAL_SEARCH' and VmBQOIMHNRAulbsCJxKPgwzcSnkUeY ==VmBQOIMHNRAulbsCJxKPgwzcSnkUWd:continue
   elif VmBQOIMHNRAulbsCJxKPgwzcSnkUhD.get('mode')=='TOTAL_HISTORY' and VmBQOIMHNRAulbsCJxKPgwzcSnkUhe==VmBQOIMHNRAulbsCJxKPgwzcSnkUWd:continue
   elif VmBQOIMHNRAulbsCJxKPgwzcSnkUhD.get('mode')=='MENU_BOOKMARK' and VmBQOIMHNRAulbsCJxKPgwzcSnkUhF==VmBQOIMHNRAulbsCJxKPgwzcSnkUWd:continue
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX={'mode':VmBQOIMHNRAulbsCJxKPgwzcSnkUhD.get('mode'),'sCode':VmBQOIMHNRAulbsCJxKPgwzcSnkUhD.get('sCode'),'sIndex':VmBQOIMHNRAulbsCJxKPgwzcSnkUhD.get('sIndex'),'sType':VmBQOIMHNRAulbsCJxKPgwzcSnkUhD.get('sType'),'suburl':VmBQOIMHNRAulbsCJxKPgwzcSnkUhD.get('suburl'),'subapi':VmBQOIMHNRAulbsCJxKPgwzcSnkUhD.get('subapi'),'page':VmBQOIMHNRAulbsCJxKPgwzcSnkUhD.get('page'),'orderby':VmBQOIMHNRAulbsCJxKPgwzcSnkUhD.get('orderby'),'ordernm':VmBQOIMHNRAulbsCJxKPgwzcSnkUhD.get('ordernm')}
   if VmBQOIMHNRAulbsCJxKPgwzcSnkUhD.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    VmBQOIMHNRAulbsCJxKPgwzcSnkUha=VmBQOIMHNRAulbsCJxKPgwzcSnkUWd
    VmBQOIMHNRAulbsCJxKPgwzcSnkUhE =VmBQOIMHNRAulbsCJxKPgwzcSnkUWL
   else:
    VmBQOIMHNRAulbsCJxKPgwzcSnkUha=VmBQOIMHNRAulbsCJxKPgwzcSnkUWL
    VmBQOIMHNRAulbsCJxKPgwzcSnkUhE =VmBQOIMHNRAulbsCJxKPgwzcSnkUWd
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhf={'title':VmBQOIMHNRAulbsCJxKPgwzcSnkUht,'plot':VmBQOIMHNRAulbsCJxKPgwzcSnkUht}
   if VmBQOIMHNRAulbsCJxKPgwzcSnkUhD.get('mode')=='XXX':VmBQOIMHNRAulbsCJxKPgwzcSnkUhf=VmBQOIMHNRAulbsCJxKPgwzcSnkUWi
   if 'icon' in VmBQOIMHNRAulbsCJxKPgwzcSnkUhD:VmBQOIMHNRAulbsCJxKPgwzcSnkUhp=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',VmBQOIMHNRAulbsCJxKPgwzcSnkUhD.get('icon')) 
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.add_dir(VmBQOIMHNRAulbsCJxKPgwzcSnkUht,sublabel='',img=VmBQOIMHNRAulbsCJxKPgwzcSnkUhp,infoLabels=VmBQOIMHNRAulbsCJxKPgwzcSnkUhf,isFolder=VmBQOIMHNRAulbsCJxKPgwzcSnkUha,params=VmBQOIMHNRAulbsCJxKPgwzcSnkUhX,isLink=VmBQOIMHNRAulbsCJxKPgwzcSnkUhE)
  xbmcplugin.endOfDirectory(VmBQOIMHNRAulbsCJxKPgwzcSnkUej._addon_handle,cacheToDisc=VmBQOIMHNRAulbsCJxKPgwzcSnkUWL)
 def dp_Search_Group(VmBQOIMHNRAulbsCJxKPgwzcSnkUej,args):
  if 'search_key' in args:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFh=args.get('search_key')
  else:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFh=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not VmBQOIMHNRAulbsCJxKPgwzcSnkUFh:
    return
  for VmBQOIMHNRAulbsCJxKPgwzcSnkUFy in VmBQOIMHNRAulbsCJxKPgwzcSnkUey:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFr =VmBQOIMHNRAulbsCJxKPgwzcSnkUFy.get('mode')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFo=VmBQOIMHNRAulbsCJxKPgwzcSnkUFy.get('sType')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUht=VmBQOIMHNRAulbsCJxKPgwzcSnkUFy.get('title')
   (VmBQOIMHNRAulbsCJxKPgwzcSnkUFG,VmBQOIMHNRAulbsCJxKPgwzcSnkUFW)=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.Get_Search_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUFh,VmBQOIMHNRAulbsCJxKPgwzcSnkUFo,1,exclusion21=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.get_settings_exclusion21())
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhf={'plot':'검색어 : '+VmBQOIMHNRAulbsCJxKPgwzcSnkUFh+'\n\n'+VmBQOIMHNRAulbsCJxKPgwzcSnkUej.Search_FreeList(VmBQOIMHNRAulbsCJxKPgwzcSnkUFG)}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX={'mode':VmBQOIMHNRAulbsCJxKPgwzcSnkUFr,'sType':VmBQOIMHNRAulbsCJxKPgwzcSnkUFo,'search_key':VmBQOIMHNRAulbsCJxKPgwzcSnkUFh,'page':'1',}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.add_dir(VmBQOIMHNRAulbsCJxKPgwzcSnkUht,sublabel='',img='',infoLabels=VmBQOIMHNRAulbsCJxKPgwzcSnkUhf,isFolder=VmBQOIMHNRAulbsCJxKPgwzcSnkUWL,params=VmBQOIMHNRAulbsCJxKPgwzcSnkUhX)
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUWa(VmBQOIMHNRAulbsCJxKPgwzcSnkUey)>0:xbmcplugin.endOfDirectory(VmBQOIMHNRAulbsCJxKPgwzcSnkUej._addon_handle,cacheToDisc=VmBQOIMHNRAulbsCJxKPgwzcSnkUWL)
  VmBQOIMHNRAulbsCJxKPgwzcSnkUej.Save_Searched_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUFh)
 def Search_FreeList(VmBQOIMHNRAulbsCJxKPgwzcSnkUej,search_list):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUFj=''
  VmBQOIMHNRAulbsCJxKPgwzcSnkUFq=7
  try:
   if VmBQOIMHNRAulbsCJxKPgwzcSnkUWa(search_list)==0:return '검색결과 없음'
   for i in VmBQOIMHNRAulbsCJxKPgwzcSnkUWE(VmBQOIMHNRAulbsCJxKPgwzcSnkUWa(search_list)):
    if i>=VmBQOIMHNRAulbsCJxKPgwzcSnkUFq:
     VmBQOIMHNRAulbsCJxKPgwzcSnkUFj=VmBQOIMHNRAulbsCJxKPgwzcSnkUFj+'...'
     break
    VmBQOIMHNRAulbsCJxKPgwzcSnkUFj=VmBQOIMHNRAulbsCJxKPgwzcSnkUFj+search_list[i]['title']+'\n'
  except:
   return ''
  return VmBQOIMHNRAulbsCJxKPgwzcSnkUFj
 def dp_Watch_Group(VmBQOIMHNRAulbsCJxKPgwzcSnkUej,args):
  for VmBQOIMHNRAulbsCJxKPgwzcSnkUFT in VmBQOIMHNRAulbsCJxKPgwzcSnkUer:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUht=VmBQOIMHNRAulbsCJxKPgwzcSnkUFT.get('title')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX={'mode':VmBQOIMHNRAulbsCJxKPgwzcSnkUFT.get('mode'),'sType':VmBQOIMHNRAulbsCJxKPgwzcSnkUFT.get('sType')}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.add_dir(VmBQOIMHNRAulbsCJxKPgwzcSnkUht,sublabel='',img='',infoLabels=VmBQOIMHNRAulbsCJxKPgwzcSnkUWi,isFolder=VmBQOIMHNRAulbsCJxKPgwzcSnkUWL,params=VmBQOIMHNRAulbsCJxKPgwzcSnkUhX)
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUWa(VmBQOIMHNRAulbsCJxKPgwzcSnkUer)>0:xbmcplugin.endOfDirectory(VmBQOIMHNRAulbsCJxKPgwzcSnkUej._addon_handle,cacheToDisc=VmBQOIMHNRAulbsCJxKPgwzcSnkUWL)
 def dp_Search_History(VmBQOIMHNRAulbsCJxKPgwzcSnkUej,args):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUFi=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.Load_List_File('search')
  for VmBQOIMHNRAulbsCJxKPgwzcSnkUFt in VmBQOIMHNRAulbsCJxKPgwzcSnkUFi:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFL=VmBQOIMHNRAulbsCJxKPgwzcSnkUWD(urllib.parse.parse_qsl(VmBQOIMHNRAulbsCJxKPgwzcSnkUFt))
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFd=VmBQOIMHNRAulbsCJxKPgwzcSnkUFL.get('skey').strip()
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX={'mode':'SEARCH_GROUP','search_key':VmBQOIMHNRAulbsCJxKPgwzcSnkUFd,}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFv={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':VmBQOIMHNRAulbsCJxKPgwzcSnkUFd,'vType':'-',}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFD=urllib.parse.urlencode(VmBQOIMHNRAulbsCJxKPgwzcSnkUFv)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFp=[('선택된 검색어 ( %s ) 삭제'%(VmBQOIMHNRAulbsCJxKPgwzcSnkUFd),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(VmBQOIMHNRAulbsCJxKPgwzcSnkUFD))]
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.add_dir(VmBQOIMHNRAulbsCJxKPgwzcSnkUFd,sublabel='',img=VmBQOIMHNRAulbsCJxKPgwzcSnkUWi,infoLabels=VmBQOIMHNRAulbsCJxKPgwzcSnkUWi,isFolder=VmBQOIMHNRAulbsCJxKPgwzcSnkUWL,params=VmBQOIMHNRAulbsCJxKPgwzcSnkUhX,ContextMenu=VmBQOIMHNRAulbsCJxKPgwzcSnkUFp)
  VmBQOIMHNRAulbsCJxKPgwzcSnkUFX={'plot':'검색목록 전체를 삭제합니다.'}
  VmBQOIMHNRAulbsCJxKPgwzcSnkUht='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  VmBQOIMHNRAulbsCJxKPgwzcSnkUhX={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  VmBQOIMHNRAulbsCJxKPgwzcSnkUhp=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  VmBQOIMHNRAulbsCJxKPgwzcSnkUej.add_dir(VmBQOIMHNRAulbsCJxKPgwzcSnkUht,sublabel='',img=VmBQOIMHNRAulbsCJxKPgwzcSnkUhp,infoLabels=VmBQOIMHNRAulbsCJxKPgwzcSnkUFX,isFolder=VmBQOIMHNRAulbsCJxKPgwzcSnkUWd,params=VmBQOIMHNRAulbsCJxKPgwzcSnkUhX,isLink=VmBQOIMHNRAulbsCJxKPgwzcSnkUWL)
  xbmcplugin.endOfDirectory(VmBQOIMHNRAulbsCJxKPgwzcSnkUej._addon_handle,cacheToDisc=VmBQOIMHNRAulbsCJxKPgwzcSnkUWd)
 def dp_Search_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUej,args):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUFo =args.get('sType')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUFa =VmBQOIMHNRAulbsCJxKPgwzcSnkUWt(args.get('page'))
  if 'search_key' in args:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFh=args.get('search_key')
  else:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFh=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not VmBQOIMHNRAulbsCJxKPgwzcSnkUFh:
    xbmcplugin.endOfDirectory(VmBQOIMHNRAulbsCJxKPgwzcSnkUej._addon_handle)
    return
  VmBQOIMHNRAulbsCJxKPgwzcSnkUFE,VmBQOIMHNRAulbsCJxKPgwzcSnkUFW=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.Get_Search_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUFh,VmBQOIMHNRAulbsCJxKPgwzcSnkUFo,VmBQOIMHNRAulbsCJxKPgwzcSnkUFa,exclusion21=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.get_settings_exclusion21())
  for VmBQOIMHNRAulbsCJxKPgwzcSnkUFf in VmBQOIMHNRAulbsCJxKPgwzcSnkUFE:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFY =VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('videoid')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUye =VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('vidtype')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUht =VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('title')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyh=VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('thumbnail')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyF =VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('age')
   if VmBQOIMHNRAulbsCJxKPgwzcSnkUyF=='18' or VmBQOIMHNRAulbsCJxKPgwzcSnkUyF=='19' or VmBQOIMHNRAulbsCJxKPgwzcSnkUyF=='21':VmBQOIMHNRAulbsCJxKPgwzcSnkUht+=' (%s)'%(VmBQOIMHNRAulbsCJxKPgwzcSnkUyF)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFX={'mediatype':'tvshow' if VmBQOIMHNRAulbsCJxKPgwzcSnkUFo=='vod' else 'movie','mpaa':VmBQOIMHNRAulbsCJxKPgwzcSnkUyF,'title':VmBQOIMHNRAulbsCJxKPgwzcSnkUht,'plot':VmBQOIMHNRAulbsCJxKPgwzcSnkUht}
   if VmBQOIMHNRAulbsCJxKPgwzcSnkUFo=='vod':
    VmBQOIMHNRAulbsCJxKPgwzcSnkUhX={'mode':'EPISODE_LIST','seasonid':VmBQOIMHNRAulbsCJxKPgwzcSnkUFY,'page':'1',}
    VmBQOIMHNRAulbsCJxKPgwzcSnkUha=VmBQOIMHNRAulbsCJxKPgwzcSnkUWL
   else:
    VmBQOIMHNRAulbsCJxKPgwzcSnkUhX={'mode':'MOVIE','contentid':VmBQOIMHNRAulbsCJxKPgwzcSnkUFY,'title':VmBQOIMHNRAulbsCJxKPgwzcSnkUht,'thumbnail':VmBQOIMHNRAulbsCJxKPgwzcSnkUyh,'age':VmBQOIMHNRAulbsCJxKPgwzcSnkUyF,}
    VmBQOIMHNRAulbsCJxKPgwzcSnkUha=VmBQOIMHNRAulbsCJxKPgwzcSnkUWd
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFp=[]
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyr={'mode':'VIEW_DETAIL','values':{'videoid':VmBQOIMHNRAulbsCJxKPgwzcSnkUFY,'vidtype':'tvshow' if VmBQOIMHNRAulbsCJxKPgwzcSnkUFo=='vod' else 'movie','contenttype':VmBQOIMHNRAulbsCJxKPgwzcSnkUye,}}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyo=json.dumps(VmBQOIMHNRAulbsCJxKPgwzcSnkUyr,separators=(',',':'))
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyo=base64.standard_b64encode(VmBQOIMHNRAulbsCJxKPgwzcSnkUyo.encode()).decode('utf-8')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyo=VmBQOIMHNRAulbsCJxKPgwzcSnkUyo.replace('+','%2B')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyG='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(VmBQOIMHNRAulbsCJxKPgwzcSnkUyo)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFp.append(('상세정보 조회',VmBQOIMHNRAulbsCJxKPgwzcSnkUyG))
   if VmBQOIMHNRAulbsCJxKPgwzcSnkUej.get_settings_makebookmark():
    VmBQOIMHNRAulbsCJxKPgwzcSnkUyr={'videoid':VmBQOIMHNRAulbsCJxKPgwzcSnkUFY,'vidtype':'tvshow' if VmBQOIMHNRAulbsCJxKPgwzcSnkUFo=='vod' else 'movie','vtitle':VmBQOIMHNRAulbsCJxKPgwzcSnkUht,'vsubtitle':'','contenttype':VmBQOIMHNRAulbsCJxKPgwzcSnkUye,}
    VmBQOIMHNRAulbsCJxKPgwzcSnkUyW=json.dumps(VmBQOIMHNRAulbsCJxKPgwzcSnkUyr)
    VmBQOIMHNRAulbsCJxKPgwzcSnkUyW=urllib.parse.quote(VmBQOIMHNRAulbsCJxKPgwzcSnkUyW)
    VmBQOIMHNRAulbsCJxKPgwzcSnkUyG='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(VmBQOIMHNRAulbsCJxKPgwzcSnkUyW)
    VmBQOIMHNRAulbsCJxKPgwzcSnkUFp.append(('(통합) 찜 영상에 추가',VmBQOIMHNRAulbsCJxKPgwzcSnkUyG))
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.add_dir(VmBQOIMHNRAulbsCJxKPgwzcSnkUht,sublabel='',img=VmBQOIMHNRAulbsCJxKPgwzcSnkUyh,infoLabels=VmBQOIMHNRAulbsCJxKPgwzcSnkUFX,isFolder=VmBQOIMHNRAulbsCJxKPgwzcSnkUha,params=VmBQOIMHNRAulbsCJxKPgwzcSnkUhX,ContextMenu=VmBQOIMHNRAulbsCJxKPgwzcSnkUFp)
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUFW:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX['mode'] ='SEARCH_LIST' 
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX['sType']=VmBQOIMHNRAulbsCJxKPgwzcSnkUFo 
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX['page'] =VmBQOIMHNRAulbsCJxKPgwzcSnkUWf(VmBQOIMHNRAulbsCJxKPgwzcSnkUFa+1)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX['search_key']=VmBQOIMHNRAulbsCJxKPgwzcSnkUFh
   VmBQOIMHNRAulbsCJxKPgwzcSnkUht='[B]%s >>[/B]'%'다음 페이지'
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyj=VmBQOIMHNRAulbsCJxKPgwzcSnkUWf(VmBQOIMHNRAulbsCJxKPgwzcSnkUFa+1)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhp=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.add_dir(VmBQOIMHNRAulbsCJxKPgwzcSnkUht,sublabel=VmBQOIMHNRAulbsCJxKPgwzcSnkUyj,img=VmBQOIMHNRAulbsCJxKPgwzcSnkUhp,infoLabels=VmBQOIMHNRAulbsCJxKPgwzcSnkUWi,isFolder=VmBQOIMHNRAulbsCJxKPgwzcSnkUWL,params=VmBQOIMHNRAulbsCJxKPgwzcSnkUhX)
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUFo=='movie':xbmcplugin.setContent(VmBQOIMHNRAulbsCJxKPgwzcSnkUej._addon_handle,'movies')
  else:xbmcplugin.setContent(VmBQOIMHNRAulbsCJxKPgwzcSnkUej._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(VmBQOIMHNRAulbsCJxKPgwzcSnkUej._addon_handle,cacheToDisc=VmBQOIMHNRAulbsCJxKPgwzcSnkUWd)
 def dp_Watch_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUej,args):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUFo =args.get('sType')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUhq=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.get_settings_direct_replay()
  VmBQOIMHNRAulbsCJxKPgwzcSnkUFE=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.Load_List_File(VmBQOIMHNRAulbsCJxKPgwzcSnkUFo)
  for VmBQOIMHNRAulbsCJxKPgwzcSnkUFf in VmBQOIMHNRAulbsCJxKPgwzcSnkUFE:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFL=VmBQOIMHNRAulbsCJxKPgwzcSnkUWD(urllib.parse.parse_qsl(VmBQOIMHNRAulbsCJxKPgwzcSnkUFf))
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyq =VmBQOIMHNRAulbsCJxKPgwzcSnkUFL.get('code').strip()
   VmBQOIMHNRAulbsCJxKPgwzcSnkUht =VmBQOIMHNRAulbsCJxKPgwzcSnkUFL.get('title').strip()
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyj =VmBQOIMHNRAulbsCJxKPgwzcSnkUFL.get('subtitle').strip()
   if VmBQOIMHNRAulbsCJxKPgwzcSnkUyj=='None':VmBQOIMHNRAulbsCJxKPgwzcSnkUyj=''
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyh=VmBQOIMHNRAulbsCJxKPgwzcSnkUFL.get('img').strip()
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFY =VmBQOIMHNRAulbsCJxKPgwzcSnkUFL.get('videoid').strip()
   try:
    VmBQOIMHNRAulbsCJxKPgwzcSnkUyh=VmBQOIMHNRAulbsCJxKPgwzcSnkUyh.replace('\'','\"')
    VmBQOIMHNRAulbsCJxKPgwzcSnkUyh=json.loads(VmBQOIMHNRAulbsCJxKPgwzcSnkUyh)
   except:
    VmBQOIMHNRAulbsCJxKPgwzcSnkUWi
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFX={'plot':'%s\n%s'%(VmBQOIMHNRAulbsCJxKPgwzcSnkUht,VmBQOIMHNRAulbsCJxKPgwzcSnkUyj)}
   if VmBQOIMHNRAulbsCJxKPgwzcSnkUFo=='vod':
    if VmBQOIMHNRAulbsCJxKPgwzcSnkUhq==VmBQOIMHNRAulbsCJxKPgwzcSnkUWd or VmBQOIMHNRAulbsCJxKPgwzcSnkUFY==VmBQOIMHNRAulbsCJxKPgwzcSnkUWi:
     VmBQOIMHNRAulbsCJxKPgwzcSnkUFX['mediatype']='tvshow'
     VmBQOIMHNRAulbsCJxKPgwzcSnkUhX={'mode':'SEASON_LIST','videoid':VmBQOIMHNRAulbsCJxKPgwzcSnkUFY,'vidtype':'contentid',}
     VmBQOIMHNRAulbsCJxKPgwzcSnkUha=VmBQOIMHNRAulbsCJxKPgwzcSnkUWL
    else:
     VmBQOIMHNRAulbsCJxKPgwzcSnkUFX['mediatype']='episode'
     VmBQOIMHNRAulbsCJxKPgwzcSnkUhX={'mode':'VOD','programid':VmBQOIMHNRAulbsCJxKPgwzcSnkUyq,'contentid':VmBQOIMHNRAulbsCJxKPgwzcSnkUFY,'title':VmBQOIMHNRAulbsCJxKPgwzcSnkUht,'subtitle':VmBQOIMHNRAulbsCJxKPgwzcSnkUyj,'thumbnail':VmBQOIMHNRAulbsCJxKPgwzcSnkUyh}
     VmBQOIMHNRAulbsCJxKPgwzcSnkUha=VmBQOIMHNRAulbsCJxKPgwzcSnkUWd
   else:
    VmBQOIMHNRAulbsCJxKPgwzcSnkUFX['mediatype']='movie'
    VmBQOIMHNRAulbsCJxKPgwzcSnkUhX={'mode':'MOVIE','contentid':VmBQOIMHNRAulbsCJxKPgwzcSnkUyq,'title':VmBQOIMHNRAulbsCJxKPgwzcSnkUht,'subtitle':VmBQOIMHNRAulbsCJxKPgwzcSnkUyj,'thumbnail':VmBQOIMHNRAulbsCJxKPgwzcSnkUyh}
    VmBQOIMHNRAulbsCJxKPgwzcSnkUha=VmBQOIMHNRAulbsCJxKPgwzcSnkUWd
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFv={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':VmBQOIMHNRAulbsCJxKPgwzcSnkUyq,'vType':VmBQOIMHNRAulbsCJxKPgwzcSnkUFo,}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFD=urllib.parse.urlencode(VmBQOIMHNRAulbsCJxKPgwzcSnkUFv)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFp=[('선택된 시청이력 ( %s ) 삭제'%(VmBQOIMHNRAulbsCJxKPgwzcSnkUht),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(VmBQOIMHNRAulbsCJxKPgwzcSnkUFD))]
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.add_dir(VmBQOIMHNRAulbsCJxKPgwzcSnkUht,sublabel=VmBQOIMHNRAulbsCJxKPgwzcSnkUyj,img=VmBQOIMHNRAulbsCJxKPgwzcSnkUyh,infoLabels=VmBQOIMHNRAulbsCJxKPgwzcSnkUFX,isFolder=VmBQOIMHNRAulbsCJxKPgwzcSnkUha,params=VmBQOIMHNRAulbsCJxKPgwzcSnkUhX,ContextMenu=VmBQOIMHNRAulbsCJxKPgwzcSnkUFp)
  VmBQOIMHNRAulbsCJxKPgwzcSnkUFX={'plot':'시청목록을 삭제합니다.'}
  VmBQOIMHNRAulbsCJxKPgwzcSnkUht='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  VmBQOIMHNRAulbsCJxKPgwzcSnkUhX={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':VmBQOIMHNRAulbsCJxKPgwzcSnkUFo,}
  VmBQOIMHNRAulbsCJxKPgwzcSnkUhp=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUej.add_dir(VmBQOIMHNRAulbsCJxKPgwzcSnkUht,sublabel='',img=VmBQOIMHNRAulbsCJxKPgwzcSnkUhp,infoLabels=VmBQOIMHNRAulbsCJxKPgwzcSnkUFX,isFolder=VmBQOIMHNRAulbsCJxKPgwzcSnkUWd,params=VmBQOIMHNRAulbsCJxKPgwzcSnkUhX,isLink=VmBQOIMHNRAulbsCJxKPgwzcSnkUWL)
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUFo=='movie':xbmcplugin.setContent(VmBQOIMHNRAulbsCJxKPgwzcSnkUej._addon_handle,'movies')
  else:xbmcplugin.setContent(VmBQOIMHNRAulbsCJxKPgwzcSnkUej._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(VmBQOIMHNRAulbsCJxKPgwzcSnkUej._addon_handle,cacheToDisc=VmBQOIMHNRAulbsCJxKPgwzcSnkUWd)
 def Load_List_File(VmBQOIMHNRAulbsCJxKPgwzcSnkUej,stype): 
  try:
   if stype=='search':
    VmBQOIMHNRAulbsCJxKPgwzcSnkUyT=VmBQOIMHNRAulbsCJxKPgwzcSnkUeW
   elif stype in['vod','movie']:
    VmBQOIMHNRAulbsCJxKPgwzcSnkUyT=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   else:
    return[]
   fp=VmBQOIMHNRAulbsCJxKPgwzcSnkUWY(VmBQOIMHNRAulbsCJxKPgwzcSnkUyT,'r',-1,'utf-8')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyi=fp.readlines()
   fp.close()
  except:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyi=[]
  return VmBQOIMHNRAulbsCJxKPgwzcSnkUyi
 def Save_Watched_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUej,VmBQOIMHNRAulbsCJxKPgwzcSnkUGX,VmBQOIMHNRAulbsCJxKPgwzcSnkUei):
  try:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyt=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%VmBQOIMHNRAulbsCJxKPgwzcSnkUGX))
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyL=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.Load_List_File(VmBQOIMHNRAulbsCJxKPgwzcSnkUGX) 
   fp=VmBQOIMHNRAulbsCJxKPgwzcSnkUWY(VmBQOIMHNRAulbsCJxKPgwzcSnkUyt,'w',-1,'utf-8')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyd=urllib.parse.urlencode(VmBQOIMHNRAulbsCJxKPgwzcSnkUei)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyd=VmBQOIMHNRAulbsCJxKPgwzcSnkUyd+'\n'
   fp.write(VmBQOIMHNRAulbsCJxKPgwzcSnkUyd)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyv=0
   for VmBQOIMHNRAulbsCJxKPgwzcSnkUyD in VmBQOIMHNRAulbsCJxKPgwzcSnkUyL:
    VmBQOIMHNRAulbsCJxKPgwzcSnkUyp=VmBQOIMHNRAulbsCJxKPgwzcSnkUWD(urllib.parse.parse_qsl(VmBQOIMHNRAulbsCJxKPgwzcSnkUyD))
    VmBQOIMHNRAulbsCJxKPgwzcSnkUyX=VmBQOIMHNRAulbsCJxKPgwzcSnkUei.get('code').strip()
    VmBQOIMHNRAulbsCJxKPgwzcSnkUya=VmBQOIMHNRAulbsCJxKPgwzcSnkUyp.get('code').strip()
    if VmBQOIMHNRAulbsCJxKPgwzcSnkUGX=='vod' and VmBQOIMHNRAulbsCJxKPgwzcSnkUej.get_settings_direct_replay()==VmBQOIMHNRAulbsCJxKPgwzcSnkUWL:
     VmBQOIMHNRAulbsCJxKPgwzcSnkUyX=VmBQOIMHNRAulbsCJxKPgwzcSnkUei.get('videoid').strip()
     VmBQOIMHNRAulbsCJxKPgwzcSnkUya=VmBQOIMHNRAulbsCJxKPgwzcSnkUyp.get('videoid').strip()if VmBQOIMHNRAulbsCJxKPgwzcSnkUya!=VmBQOIMHNRAulbsCJxKPgwzcSnkUWi else '-'
    if VmBQOIMHNRAulbsCJxKPgwzcSnkUyX!=VmBQOIMHNRAulbsCJxKPgwzcSnkUya:
     fp.write(VmBQOIMHNRAulbsCJxKPgwzcSnkUyD)
     VmBQOIMHNRAulbsCJxKPgwzcSnkUyv+=1
     if VmBQOIMHNRAulbsCJxKPgwzcSnkUyv>=50:break
   fp.close()
  except:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUWi
 def dp_History_Remove(VmBQOIMHNRAulbsCJxKPgwzcSnkUej,args):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUyE=args.get('delType')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUyf =args.get('sKey')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUyY =args.get('vType')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUeL=xbmcgui.Dialog()
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUyE=='SEARCH_ALL':
   VmBQOIMHNRAulbsCJxKPgwzcSnkUre=VmBQOIMHNRAulbsCJxKPgwzcSnkUeL.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif VmBQOIMHNRAulbsCJxKPgwzcSnkUyE=='SEARCH_ONE':
   VmBQOIMHNRAulbsCJxKPgwzcSnkUre=VmBQOIMHNRAulbsCJxKPgwzcSnkUeL.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif VmBQOIMHNRAulbsCJxKPgwzcSnkUyE=='WATCH_ALL':
   VmBQOIMHNRAulbsCJxKPgwzcSnkUre=VmBQOIMHNRAulbsCJxKPgwzcSnkUeL.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif VmBQOIMHNRAulbsCJxKPgwzcSnkUyE=='WATCH_ONE':
   VmBQOIMHNRAulbsCJxKPgwzcSnkUre=VmBQOIMHNRAulbsCJxKPgwzcSnkUeL.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUre==VmBQOIMHNRAulbsCJxKPgwzcSnkUWd:sys.exit()
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUyE=='SEARCH_ALL':
   if os.path.isfile(VmBQOIMHNRAulbsCJxKPgwzcSnkUeW):os.remove(VmBQOIMHNRAulbsCJxKPgwzcSnkUeW)
  elif VmBQOIMHNRAulbsCJxKPgwzcSnkUyE=='SEARCH_ONE':
   try:
    VmBQOIMHNRAulbsCJxKPgwzcSnkUyT=VmBQOIMHNRAulbsCJxKPgwzcSnkUeW
    VmBQOIMHNRAulbsCJxKPgwzcSnkUyL=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.Load_List_File('search') 
    fp=VmBQOIMHNRAulbsCJxKPgwzcSnkUWY(VmBQOIMHNRAulbsCJxKPgwzcSnkUyT,'w',-1,'utf-8')
    for VmBQOIMHNRAulbsCJxKPgwzcSnkUyD in VmBQOIMHNRAulbsCJxKPgwzcSnkUyL:
     VmBQOIMHNRAulbsCJxKPgwzcSnkUyp=VmBQOIMHNRAulbsCJxKPgwzcSnkUWD(urllib.parse.parse_qsl(VmBQOIMHNRAulbsCJxKPgwzcSnkUyD))
     VmBQOIMHNRAulbsCJxKPgwzcSnkUrh=VmBQOIMHNRAulbsCJxKPgwzcSnkUyp.get('skey').strip()
     if VmBQOIMHNRAulbsCJxKPgwzcSnkUyf!=VmBQOIMHNRAulbsCJxKPgwzcSnkUrh:
      fp.write(VmBQOIMHNRAulbsCJxKPgwzcSnkUyD)
    fp.close()
   except:
    VmBQOIMHNRAulbsCJxKPgwzcSnkUWi
  elif VmBQOIMHNRAulbsCJxKPgwzcSnkUyE=='WATCH_ALL':
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyT=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%VmBQOIMHNRAulbsCJxKPgwzcSnkUyY))
   if os.path.isfile(VmBQOIMHNRAulbsCJxKPgwzcSnkUyT):os.remove(VmBQOIMHNRAulbsCJxKPgwzcSnkUyT)
  elif VmBQOIMHNRAulbsCJxKPgwzcSnkUyE=='WATCH_ONE':
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyT=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%VmBQOIMHNRAulbsCJxKPgwzcSnkUyY))
   try:
    VmBQOIMHNRAulbsCJxKPgwzcSnkUyL=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.Load_List_File(VmBQOIMHNRAulbsCJxKPgwzcSnkUyY) 
    fp=VmBQOIMHNRAulbsCJxKPgwzcSnkUWY(VmBQOIMHNRAulbsCJxKPgwzcSnkUyT,'w',-1,'utf-8')
    for VmBQOIMHNRAulbsCJxKPgwzcSnkUyD in VmBQOIMHNRAulbsCJxKPgwzcSnkUyL:
     VmBQOIMHNRAulbsCJxKPgwzcSnkUyp=VmBQOIMHNRAulbsCJxKPgwzcSnkUWD(urllib.parse.parse_qsl(VmBQOIMHNRAulbsCJxKPgwzcSnkUyD))
     VmBQOIMHNRAulbsCJxKPgwzcSnkUrh=VmBQOIMHNRAulbsCJxKPgwzcSnkUyp.get('code').strip()
     if VmBQOIMHNRAulbsCJxKPgwzcSnkUyf!=VmBQOIMHNRAulbsCJxKPgwzcSnkUrh:
      fp.write(VmBQOIMHNRAulbsCJxKPgwzcSnkUyD)
    fp.close()
   except:
    VmBQOIMHNRAulbsCJxKPgwzcSnkUWi
  xbmc.executebuiltin("Container.Refresh")
 def Save_Searched_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUej,VmBQOIMHNRAulbsCJxKPgwzcSnkUFh):
  try:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUrF=VmBQOIMHNRAulbsCJxKPgwzcSnkUeW
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyL=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.Load_List_File('search') 
   VmBQOIMHNRAulbsCJxKPgwzcSnkUry={'skey':VmBQOIMHNRAulbsCJxKPgwzcSnkUFh.strip()}
   fp=VmBQOIMHNRAulbsCJxKPgwzcSnkUWY(VmBQOIMHNRAulbsCJxKPgwzcSnkUrF,'w',-1,'utf-8')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyd=urllib.parse.urlencode(VmBQOIMHNRAulbsCJxKPgwzcSnkUry)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyd=VmBQOIMHNRAulbsCJxKPgwzcSnkUyd+'\n'
   fp.write(VmBQOIMHNRAulbsCJxKPgwzcSnkUyd)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyv=0
   for VmBQOIMHNRAulbsCJxKPgwzcSnkUyD in VmBQOIMHNRAulbsCJxKPgwzcSnkUyL:
    VmBQOIMHNRAulbsCJxKPgwzcSnkUyp=VmBQOIMHNRAulbsCJxKPgwzcSnkUWD(urllib.parse.parse_qsl(VmBQOIMHNRAulbsCJxKPgwzcSnkUyD))
    VmBQOIMHNRAulbsCJxKPgwzcSnkUyX=VmBQOIMHNRAulbsCJxKPgwzcSnkUry.get('skey').strip()
    VmBQOIMHNRAulbsCJxKPgwzcSnkUya=VmBQOIMHNRAulbsCJxKPgwzcSnkUyp.get('skey').strip()
    if VmBQOIMHNRAulbsCJxKPgwzcSnkUyX!=VmBQOIMHNRAulbsCJxKPgwzcSnkUya:
     fp.write(VmBQOIMHNRAulbsCJxKPgwzcSnkUyD)
     VmBQOIMHNRAulbsCJxKPgwzcSnkUyv+=1
     if VmBQOIMHNRAulbsCJxKPgwzcSnkUyv>=50:break
   fp.close()
  except:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUWi
 def dp_Global_Search(VmBQOIMHNRAulbsCJxKPgwzcSnkUej,args):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUFr=args.get('mode')
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUFr=='TOTAL_SEARCH':
   VmBQOIMHNRAulbsCJxKPgwzcSnkUro='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUro='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(VmBQOIMHNRAulbsCJxKPgwzcSnkUro)
 def dp_Bookmark_Menu(VmBQOIMHNRAulbsCJxKPgwzcSnkUej,args):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUro='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(VmBQOIMHNRAulbsCJxKPgwzcSnkUro)
 def login_main(VmBQOIMHNRAulbsCJxKPgwzcSnkUej):
  (VmBQOIMHNRAulbsCJxKPgwzcSnkUrG,VmBQOIMHNRAulbsCJxKPgwzcSnkUrW,VmBQOIMHNRAulbsCJxKPgwzcSnkUrj)=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.get_settings_account()
  if not(VmBQOIMHNRAulbsCJxKPgwzcSnkUrG and VmBQOIMHNRAulbsCJxKPgwzcSnkUrW):
   VmBQOIMHNRAulbsCJxKPgwzcSnkUeL=xbmcgui.Dialog()
   VmBQOIMHNRAulbsCJxKPgwzcSnkUre=VmBQOIMHNRAulbsCJxKPgwzcSnkUeL.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if VmBQOIMHNRAulbsCJxKPgwzcSnkUre==VmBQOIMHNRAulbsCJxKPgwzcSnkUWL:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUej.cookiefile_check()==VmBQOIMHNRAulbsCJxKPgwzcSnkUWL:return
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   VmBQOIMHNRAulbsCJxKPgwzcSnkUrq=0
   while VmBQOIMHNRAulbsCJxKPgwzcSnkUWL:
    VmBQOIMHNRAulbsCJxKPgwzcSnkUrq+=1
    time.sleep(0.05)
    if VmBQOIMHNRAulbsCJxKPgwzcSnkUrq>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUrT=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.GetCredential(VmBQOIMHNRAulbsCJxKPgwzcSnkUrG,VmBQOIMHNRAulbsCJxKPgwzcSnkUrW,VmBQOIMHNRAulbsCJxKPgwzcSnkUrj)
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUrT:VmBQOIMHNRAulbsCJxKPgwzcSnkUej.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUrT==VmBQOIMHNRAulbsCJxKPgwzcSnkUWd:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_setEpOrderby(VmBQOIMHNRAulbsCJxKPgwzcSnkUej,args):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUhT =args.get('orderby')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUej.set_winEpisodeOrderby(VmBQOIMHNRAulbsCJxKPgwzcSnkUhT)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(VmBQOIMHNRAulbsCJxKPgwzcSnkUej,args):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUFr =args.get('mode')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUri =args.get('contentid')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUrt =args.get('pvrmode')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUrL=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.get_selQuality()
  VmBQOIMHNRAulbsCJxKPgwzcSnkUhy =VmBQOIMHNRAulbsCJxKPgwzcSnkUej.get_settings_play()
  VmBQOIMHNRAulbsCJxKPgwzcSnkUej.addon_log(VmBQOIMHNRAulbsCJxKPgwzcSnkUri+' - '+VmBQOIMHNRAulbsCJxKPgwzcSnkUFr)
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUFr=='SPORTS':
   VmBQOIMHNRAulbsCJxKPgwzcSnkUrd=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.GetSportsURL(VmBQOIMHNRAulbsCJxKPgwzcSnkUri,VmBQOIMHNRAulbsCJxKPgwzcSnkUrL)
  else:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUrd=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.GetStreamingURL(VmBQOIMHNRAulbsCJxKPgwzcSnkUFr,VmBQOIMHNRAulbsCJxKPgwzcSnkUri,VmBQOIMHNRAulbsCJxKPgwzcSnkUrL,VmBQOIMHNRAulbsCJxKPgwzcSnkUrt,playOption=VmBQOIMHNRAulbsCJxKPgwzcSnkUhy)
  VmBQOIMHNRAulbsCJxKPgwzcSnkUrv={'user-agent':VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.USER_AGENT}
  VmBQOIMHNRAulbsCJxKPgwzcSnkUrD=VmBQOIMHNRAulbsCJxKPgwzcSnkUrd['stream_cookie'] 
  VmBQOIMHNRAulbsCJxKPgwzcSnkUrp=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.make_stream_header(VmBQOIMHNRAulbsCJxKPgwzcSnkUrv,VmBQOIMHNRAulbsCJxKPgwzcSnkUrD)
  VmBQOIMHNRAulbsCJxKPgwzcSnkUrX='{}|{}'.format(VmBQOIMHNRAulbsCJxKPgwzcSnkUrd['stream_url'],VmBQOIMHNRAulbsCJxKPgwzcSnkUrp)
  VmBQOIMHNRAulbsCJxKPgwzcSnkUej.addon_log('surl : '+VmBQOIMHNRAulbsCJxKPgwzcSnkUrX)
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUrd['stream_url']=='':
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.addon_noti(__language__(30907).encode('utf8'))
   return
  VmBQOIMHNRAulbsCJxKPgwzcSnkUhr,VmBQOIMHNRAulbsCJxKPgwzcSnkUho=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.get_settings_proxyport()
  VmBQOIMHNRAulbsCJxKPgwzcSnkUra=urllib.parse.urlparse(VmBQOIMHNRAulbsCJxKPgwzcSnkUrd['stream_url'])
  VmBQOIMHNRAulbsCJxKPgwzcSnkUra=VmBQOIMHNRAulbsCJxKPgwzcSnkUra.path.strip('/').split('/')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUra=VmBQOIMHNRAulbsCJxKPgwzcSnkUra[VmBQOIMHNRAulbsCJxKPgwzcSnkUWa(VmBQOIMHNRAulbsCJxKPgwzcSnkUra)-1] 
  if (VmBQOIMHNRAulbsCJxKPgwzcSnkUhr==VmBQOIMHNRAulbsCJxKPgwzcSnkUWL and args.get('mode')in['VOD','MOVIE']and(VmBQOIMHNRAulbsCJxKPgwzcSnkUrd['playParam']['hdr']=='hdr' or VmBQOIMHNRAulbsCJxKPgwzcSnkUrd['playParam']['uhd']=='uhd')):
   if VmBQOIMHNRAulbsCJxKPgwzcSnkUra.split('.')[1]=='mpd':
    VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.Wavve_Parse_mpd(VmBQOIMHNRAulbsCJxKPgwzcSnkUrd)
   else:
    VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.Wavve_Parse_m3u8(VmBQOIMHNRAulbsCJxKPgwzcSnkUrd)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUrE={'addon':'wavvem','playOption':VmBQOIMHNRAulbsCJxKPgwzcSnkUhy,}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUrE=json.dumps(VmBQOIMHNRAulbsCJxKPgwzcSnkUrE,separators=(',',':'))
   VmBQOIMHNRAulbsCJxKPgwzcSnkUrE=base64.standard_b64encode(VmBQOIMHNRAulbsCJxKPgwzcSnkUrE.encode()).decode('utf-8')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUrX ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(VmBQOIMHNRAulbsCJxKPgwzcSnkUho,VmBQOIMHNRAulbsCJxKPgwzcSnkUrX,VmBQOIMHNRAulbsCJxKPgwzcSnkUrE)
  VmBQOIMHNRAulbsCJxKPgwzcSnkUej.addon_log('surl : '+VmBQOIMHNRAulbsCJxKPgwzcSnkUrX)
  VmBQOIMHNRAulbsCJxKPgwzcSnkUrf=xbmcgui.ListItem(path=VmBQOIMHNRAulbsCJxKPgwzcSnkUrX)
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUrd['stream_drm']:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.addon_log('!!streaming_drm!!')
   inputstreamhelper.Helper('mpd',drm='com.widevine.alpha').check_inputstream()
   if 'licensetoken' in VmBQOIMHNRAulbsCJxKPgwzcSnkUrd['stream_drm']:
    VmBQOIMHNRAulbsCJxKPgwzcSnkUoe=VmBQOIMHNRAulbsCJxKPgwzcSnkUrd['stream_drm']['licensetoken']
    VmBQOIMHNRAulbsCJxKPgwzcSnkUoh =VmBQOIMHNRAulbsCJxKPgwzcSnkUrd['stream_drm']['licenseurl']
    if VmBQOIMHNRAulbsCJxKPgwzcSnkUFr=='MOVIE':
     VmBQOIMHNRAulbsCJxKPgwzcSnkUoF='https://www.wavve.com/player/movie?movieid=%s'%VmBQOIMHNRAulbsCJxKPgwzcSnkUri
    else:
     VmBQOIMHNRAulbsCJxKPgwzcSnkUoF='https://www.wavve.com/player/vod?programid=%s&page=1'%VmBQOIMHNRAulbsCJxKPgwzcSnkUri
    VmBQOIMHNRAulbsCJxKPgwzcSnkUoy={'content-type':'application/octet-stream','origin':'https://www.wavve.com','License-Token':VmBQOIMHNRAulbsCJxKPgwzcSnkUoe,'referer':VmBQOIMHNRAulbsCJxKPgwzcSnkUoF,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.USER_AGENT,}
   else:
    VmBQOIMHNRAulbsCJxKPgwzcSnkUoe=VmBQOIMHNRAulbsCJxKPgwzcSnkUrd['stream_drm']['customdata']
    VmBQOIMHNRAulbsCJxKPgwzcSnkUoh =VmBQOIMHNRAulbsCJxKPgwzcSnkUrd['stream_drm']['drmhost']
    if VmBQOIMHNRAulbsCJxKPgwzcSnkUFr=='MOVIE':
     VmBQOIMHNRAulbsCJxKPgwzcSnkUoF='https://www.wavve.com/player/movie?movieid=%s'%VmBQOIMHNRAulbsCJxKPgwzcSnkUri
    else:
     VmBQOIMHNRAulbsCJxKPgwzcSnkUoF='https://www.wavve.com/player/vod?programid=%s&page=1'%VmBQOIMHNRAulbsCJxKPgwzcSnkUri
    VmBQOIMHNRAulbsCJxKPgwzcSnkUoy={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':VmBQOIMHNRAulbsCJxKPgwzcSnkUoe,'referer':VmBQOIMHNRAulbsCJxKPgwzcSnkUoF,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.USER_AGENT,}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUor=VmBQOIMHNRAulbsCJxKPgwzcSnkUoh+'|'+urllib.parse.urlencode(VmBQOIMHNRAulbsCJxKPgwzcSnkUoy)+'|R{SSM}|'
   VmBQOIMHNRAulbsCJxKPgwzcSnkUrf.setProperty('inputstream','inputstream.adaptive')
   if VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.KodiVersion<=20:
    VmBQOIMHNRAulbsCJxKPgwzcSnkUrf.setProperty('inputstream.adaptive.manifest_type','mpd')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUrf.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUrf.setProperty('inputstream.adaptive.license_key',VmBQOIMHNRAulbsCJxKPgwzcSnkUor)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUrf.setProperty('inputstream.adaptive.stream_headers',VmBQOIMHNRAulbsCJxKPgwzcSnkUrp)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUrf.setProperty('inputstream.adaptive.manifest_headers',VmBQOIMHNRAulbsCJxKPgwzcSnkUrp)
  elif VmBQOIMHNRAulbsCJxKPgwzcSnkUFr in['VOD','MOVIE']:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUrf.setContentLookup(VmBQOIMHNRAulbsCJxKPgwzcSnkUWd)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUrf.setMimeType('application/x-mpegURL')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUrf.setProperty('inputstream','inputstream.adaptive')
   if VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.KodiVersion<=20:
    if VmBQOIMHNRAulbsCJxKPgwzcSnkUrd['stream_action']=='hls':
     VmBQOIMHNRAulbsCJxKPgwzcSnkUrf.setProperty('inputstream.adaptive.manifest_type','hls')
    else:
     VmBQOIMHNRAulbsCJxKPgwzcSnkUrf.setProperty('inputstream.adaptive.manifest_type','mpd')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUrf.setProperty('inputstream.adaptive.stream_headers',VmBQOIMHNRAulbsCJxKPgwzcSnkUrp)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUrf.setProperty('inputstream.adaptive.manifest_headers',VmBQOIMHNRAulbsCJxKPgwzcSnkUrp)
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUrd['stream_vtt']:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUrf.setSubtitles([VmBQOIMHNRAulbsCJxKPgwzcSnkUrd['stream_vtt']])
  xbmcplugin.setResolvedUrl(VmBQOIMHNRAulbsCJxKPgwzcSnkUej._addon_handle,VmBQOIMHNRAulbsCJxKPgwzcSnkUWL,VmBQOIMHNRAulbsCJxKPgwzcSnkUrf)
  VmBQOIMHNRAulbsCJxKPgwzcSnkUoG=VmBQOIMHNRAulbsCJxKPgwzcSnkUWd
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUrd['stream_preview']:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.addon_noti(VmBQOIMHNRAulbsCJxKPgwzcSnkUrd['stream_preview'].encode('utf-8'))
   VmBQOIMHNRAulbsCJxKPgwzcSnkUoG=VmBQOIMHNRAulbsCJxKPgwzcSnkUWL
  else:
   if '/preview.' in urllib.parse.urlsplit(VmBQOIMHNRAulbsCJxKPgwzcSnkUrd['stream_url']).path:
    VmBQOIMHNRAulbsCJxKPgwzcSnkUej.addon_noti(__language__(30908).encode('utf8'))
    VmBQOIMHNRAulbsCJxKPgwzcSnkUoG=VmBQOIMHNRAulbsCJxKPgwzcSnkUWL
  try:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUoW=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and VmBQOIMHNRAulbsCJxKPgwzcSnkUoG==VmBQOIMHNRAulbsCJxKPgwzcSnkUWd and VmBQOIMHNRAulbsCJxKPgwzcSnkUoW!='-':
    VmBQOIMHNRAulbsCJxKPgwzcSnkUhX={'code':VmBQOIMHNRAulbsCJxKPgwzcSnkUoW,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    VmBQOIMHNRAulbsCJxKPgwzcSnkUej.Save_Watched_List(args.get('mode').lower(),VmBQOIMHNRAulbsCJxKPgwzcSnkUhX)
  except:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUWi
 def logout(VmBQOIMHNRAulbsCJxKPgwzcSnkUej):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUeL=xbmcgui.Dialog()
  VmBQOIMHNRAulbsCJxKPgwzcSnkUre=VmBQOIMHNRAulbsCJxKPgwzcSnkUeL.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUre==VmBQOIMHNRAulbsCJxKPgwzcSnkUWd:sys.exit()
  VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.Init_WV_Total()
  if os.path.isfile(VmBQOIMHNRAulbsCJxKPgwzcSnkUeG):os.remove(VmBQOIMHNRAulbsCJxKPgwzcSnkUeG)
  VmBQOIMHNRAulbsCJxKPgwzcSnkUej.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(VmBQOIMHNRAulbsCJxKPgwzcSnkUej):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUoj =VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.Get_Now_Datetime()
  VmBQOIMHNRAulbsCJxKPgwzcSnkUoq=VmBQOIMHNRAulbsCJxKPgwzcSnkUoj+datetime.timedelta(days=VmBQOIMHNRAulbsCJxKPgwzcSnkUWt(__addon__.getSetting('cache_ttl')))
  (VmBQOIMHNRAulbsCJxKPgwzcSnkUrG,VmBQOIMHNRAulbsCJxKPgwzcSnkUrW,VmBQOIMHNRAulbsCJxKPgwzcSnkUrj)=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.get_settings_account()
  VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.Save_session_acount(VmBQOIMHNRAulbsCJxKPgwzcSnkUrG,VmBQOIMHNRAulbsCJxKPgwzcSnkUrW,VmBQOIMHNRAulbsCJxKPgwzcSnkUrj)
  VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.WV['account']['token_limit']=VmBQOIMHNRAulbsCJxKPgwzcSnkUoq.strftime('%Y%m%d')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.JsonFile_Save(VmBQOIMHNRAulbsCJxKPgwzcSnkUeG,VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.WV)
 def cookiefile_check(VmBQOIMHNRAulbsCJxKPgwzcSnkUej):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.WV=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.JsonFile_Load(VmBQOIMHNRAulbsCJxKPgwzcSnkUeG)
  if 'account' not in VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.WV:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.Init_WV_Total()
   return VmBQOIMHNRAulbsCJxKPgwzcSnkUWd
  if 'uuid' not in VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.WV.get('cookies'):
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.Init_WV_Total()
   return VmBQOIMHNRAulbsCJxKPgwzcSnkUWd
  (VmBQOIMHNRAulbsCJxKPgwzcSnkUoT,VmBQOIMHNRAulbsCJxKPgwzcSnkUoi,VmBQOIMHNRAulbsCJxKPgwzcSnkUot)=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.get_settings_account()
  (VmBQOIMHNRAulbsCJxKPgwzcSnkUoL,VmBQOIMHNRAulbsCJxKPgwzcSnkUod,VmBQOIMHNRAulbsCJxKPgwzcSnkUov)=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.Load_session_acount()
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUoT!=VmBQOIMHNRAulbsCJxKPgwzcSnkUoL or VmBQOIMHNRAulbsCJxKPgwzcSnkUoi!=VmBQOIMHNRAulbsCJxKPgwzcSnkUod or VmBQOIMHNRAulbsCJxKPgwzcSnkUot!=VmBQOIMHNRAulbsCJxKPgwzcSnkUov:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.Init_WV_Total()
   return VmBQOIMHNRAulbsCJxKPgwzcSnkUWd
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUWt(VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))>VmBQOIMHNRAulbsCJxKPgwzcSnkUWt(VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.WV['account']['token_limit']):
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.Init_WV_Total()
   return VmBQOIMHNRAulbsCJxKPgwzcSnkUWd
  return VmBQOIMHNRAulbsCJxKPgwzcSnkUWL
 def dp_LiveCatagory_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUej,args):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUoD =args.get('sCode')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUop=args.get('sIndex')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUFE,VmBQOIMHNRAulbsCJxKPgwzcSnkUoX=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.Get_LiveCatagory_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUoD,VmBQOIMHNRAulbsCJxKPgwzcSnkUop)
  for VmBQOIMHNRAulbsCJxKPgwzcSnkUFf in VmBQOIMHNRAulbsCJxKPgwzcSnkUFE:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUht =VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('title')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX={'mode':'LIVE_LIST','genre':VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('genre'),'baseapi':VmBQOIMHNRAulbsCJxKPgwzcSnkUoX}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhf={'title':VmBQOIMHNRAulbsCJxKPgwzcSnkUht,'plot':VmBQOIMHNRAulbsCJxKPgwzcSnkUht}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.add_dir(VmBQOIMHNRAulbsCJxKPgwzcSnkUht,sublabel='',img='',infoLabels=VmBQOIMHNRAulbsCJxKPgwzcSnkUhf,isFolder=VmBQOIMHNRAulbsCJxKPgwzcSnkUWL,params=VmBQOIMHNRAulbsCJxKPgwzcSnkUhX)
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUWa(VmBQOIMHNRAulbsCJxKPgwzcSnkUFE)>0:xbmcplugin.endOfDirectory(VmBQOIMHNRAulbsCJxKPgwzcSnkUej._addon_handle,cacheToDisc=VmBQOIMHNRAulbsCJxKPgwzcSnkUWd)
 def dp_MainCatagory_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUej,args):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUoD =args.get('sCode')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUop=args.get('sIndex')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUFo =args.get('sType')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUFE=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.Get_MainCatagory_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUoD,VmBQOIMHNRAulbsCJxKPgwzcSnkUop,VmBQOIMHNRAulbsCJxKPgwzcSnkUFo)
  for VmBQOIMHNRAulbsCJxKPgwzcSnkUFf in VmBQOIMHNRAulbsCJxKPgwzcSnkUFE:
   if VmBQOIMHNRAulbsCJxKPgwzcSnkUFo in['vod','vod09']:
    if VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('subtype')=='catagory':
     VmBQOIMHNRAulbsCJxKPgwzcSnkUFr='PROGRAM_LIST'
    else:
     VmBQOIMHNRAulbsCJxKPgwzcSnkUFr='SUPERSECTION_LIST'
   elif VmBQOIMHNRAulbsCJxKPgwzcSnkUFo=='movie':
    VmBQOIMHNRAulbsCJxKPgwzcSnkUFr='MOVIE_LIST'
   else:
    VmBQOIMHNRAulbsCJxKPgwzcSnkUFr=''
   VmBQOIMHNRAulbsCJxKPgwzcSnkUht='%s (%s)'%(VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('title'),args.get('ordernm'))
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX={'mode':VmBQOIMHNRAulbsCJxKPgwzcSnkUFr,'suburl':VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('suburl'),'subapi':VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if VmBQOIMHNRAulbsCJxKPgwzcSnkUej.get_settings_exclusion21():
    if VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('title')=='성인' or VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('title')=='성인+' or VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('title')=='에로티시즘' or VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('title')=='19':continue
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhf={'title':VmBQOIMHNRAulbsCJxKPgwzcSnkUht,'plot':VmBQOIMHNRAulbsCJxKPgwzcSnkUht}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.add_dir(VmBQOIMHNRAulbsCJxKPgwzcSnkUht,sublabel='',img='',infoLabels=VmBQOIMHNRAulbsCJxKPgwzcSnkUhf,isFolder=VmBQOIMHNRAulbsCJxKPgwzcSnkUWL,params=VmBQOIMHNRAulbsCJxKPgwzcSnkUhX)
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUWa(VmBQOIMHNRAulbsCJxKPgwzcSnkUFE)>0:xbmcplugin.endOfDirectory(VmBQOIMHNRAulbsCJxKPgwzcSnkUej._addon_handle,cacheToDisc=VmBQOIMHNRAulbsCJxKPgwzcSnkUWd)
 def dp_Program_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUej,args):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUoa =args.get('subapi')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUFa=VmBQOIMHNRAulbsCJxKPgwzcSnkUWt(args.get('page'))
  VmBQOIMHNRAulbsCJxKPgwzcSnkUhT =args.get('orderby')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUej.addon_log('dp_Program_List')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUej.addon_log(VmBQOIMHNRAulbsCJxKPgwzcSnkUoa)
  VmBQOIMHNRAulbsCJxKPgwzcSnkUFE,VmBQOIMHNRAulbsCJxKPgwzcSnkUFW=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.Get_Program_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUoa,VmBQOIMHNRAulbsCJxKPgwzcSnkUFa,VmBQOIMHNRAulbsCJxKPgwzcSnkUhT)
  for VmBQOIMHNRAulbsCJxKPgwzcSnkUFf in VmBQOIMHNRAulbsCJxKPgwzcSnkUFE:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFY =VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('videoid')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUye =VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('vidtype')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUht =VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('title')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyh=VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('thumbnail')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyF =VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('age')
   if VmBQOIMHNRAulbsCJxKPgwzcSnkUyF=='18' or VmBQOIMHNRAulbsCJxKPgwzcSnkUyF=='19' or VmBQOIMHNRAulbsCJxKPgwzcSnkUyF=='21':VmBQOIMHNRAulbsCJxKPgwzcSnkUht+=' (%s)'%(VmBQOIMHNRAulbsCJxKPgwzcSnkUyF)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhf={'plot':VmBQOIMHNRAulbsCJxKPgwzcSnkUht,'mpaa':VmBQOIMHNRAulbsCJxKPgwzcSnkUyF,'mediatype':'tvshow','title':VmBQOIMHNRAulbsCJxKPgwzcSnkUht,}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX={'mode':'SEASON_LIST','videoid':VmBQOIMHNRAulbsCJxKPgwzcSnkUFY,'vidtype':VmBQOIMHNRAulbsCJxKPgwzcSnkUye,}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFp=[]
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyr={'mode':'VIEW_DETAIL','values':{'videoid':VmBQOIMHNRAulbsCJxKPgwzcSnkUFY,'vidtype':'tvshow','contenttype':VmBQOIMHNRAulbsCJxKPgwzcSnkUye,}}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyo=json.dumps(VmBQOIMHNRAulbsCJxKPgwzcSnkUyr,separators=(',',':'))
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyo=base64.standard_b64encode(VmBQOIMHNRAulbsCJxKPgwzcSnkUyo.encode()).decode('utf-8')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyo=VmBQOIMHNRAulbsCJxKPgwzcSnkUyo.replace('+','%2B')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyG='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(VmBQOIMHNRAulbsCJxKPgwzcSnkUyo)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFp.append(('상세정보 조회',VmBQOIMHNRAulbsCJxKPgwzcSnkUyG))
   if VmBQOIMHNRAulbsCJxKPgwzcSnkUej.get_settings_makebookmark():
    VmBQOIMHNRAulbsCJxKPgwzcSnkUyr={'videoid':VmBQOIMHNRAulbsCJxKPgwzcSnkUFY,'vidtype':'tvshow','vtitle':VmBQOIMHNRAulbsCJxKPgwzcSnkUht,'vsubtitle':'','contenttype':VmBQOIMHNRAulbsCJxKPgwzcSnkUye,}
    VmBQOIMHNRAulbsCJxKPgwzcSnkUyW=json.dumps(VmBQOIMHNRAulbsCJxKPgwzcSnkUyr)
    VmBQOIMHNRAulbsCJxKPgwzcSnkUyW=urllib.parse.quote(VmBQOIMHNRAulbsCJxKPgwzcSnkUyW)
    VmBQOIMHNRAulbsCJxKPgwzcSnkUyG='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(VmBQOIMHNRAulbsCJxKPgwzcSnkUyW)
    VmBQOIMHNRAulbsCJxKPgwzcSnkUFp.append(('(통합) 찜 영상에 추가',VmBQOIMHNRAulbsCJxKPgwzcSnkUyG))
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.add_dir(VmBQOIMHNRAulbsCJxKPgwzcSnkUht,sublabel='',img=VmBQOIMHNRAulbsCJxKPgwzcSnkUyh,infoLabels=VmBQOIMHNRAulbsCJxKPgwzcSnkUhf,isFolder=VmBQOIMHNRAulbsCJxKPgwzcSnkUWL,params=VmBQOIMHNRAulbsCJxKPgwzcSnkUhX,ContextMenu=VmBQOIMHNRAulbsCJxKPgwzcSnkUFp)
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUFW:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX={}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX['mode'] ='PROGRAM_LIST' 
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX['subapi']=VmBQOIMHNRAulbsCJxKPgwzcSnkUoa 
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX['page'] =VmBQOIMHNRAulbsCJxKPgwzcSnkUWf(VmBQOIMHNRAulbsCJxKPgwzcSnkUFa+1)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUht='[B]%s >>[/B]'%'다음 페이지'
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyj=VmBQOIMHNRAulbsCJxKPgwzcSnkUWf(VmBQOIMHNRAulbsCJxKPgwzcSnkUFa+1)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhp=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.add_dir(VmBQOIMHNRAulbsCJxKPgwzcSnkUht,sublabel=VmBQOIMHNRAulbsCJxKPgwzcSnkUyj,img=VmBQOIMHNRAulbsCJxKPgwzcSnkUhp,infoLabels=VmBQOIMHNRAulbsCJxKPgwzcSnkUWi,isFolder=VmBQOIMHNRAulbsCJxKPgwzcSnkUWL,params=VmBQOIMHNRAulbsCJxKPgwzcSnkUhX)
  xbmcplugin.setContent(VmBQOIMHNRAulbsCJxKPgwzcSnkUej._addon_handle,'tvshows')
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUWa(VmBQOIMHNRAulbsCJxKPgwzcSnkUFE)>0:xbmcplugin.endOfDirectory(VmBQOIMHNRAulbsCJxKPgwzcSnkUej._addon_handle,cacheToDisc=VmBQOIMHNRAulbsCJxKPgwzcSnkUWd)
 def dp_Season_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUej,args):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUFY=args.get('videoid')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUye=args.get('vidtype')
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUye=='contentid':
   VmBQOIMHNRAulbsCJxKPgwzcSnkUri=VmBQOIMHNRAulbsCJxKPgwzcSnkUFY
   VmBQOIMHNRAulbsCJxKPgwzcSnkUoE =VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.ContentidToSeasonid(VmBQOIMHNRAulbsCJxKPgwzcSnkUFY)
  else:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUri=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.ProgramidToContentid(VmBQOIMHNRAulbsCJxKPgwzcSnkUFY)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUoE =VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.ContentidToSeasonid(VmBQOIMHNRAulbsCJxKPgwzcSnkUri)
  VmBQOIMHNRAulbsCJxKPgwzcSnkUof=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.Get_Season_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUoE)
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUWa(VmBQOIMHNRAulbsCJxKPgwzcSnkUof)>1:
   for VmBQOIMHNRAulbsCJxKPgwzcSnkUoY in VmBQOIMHNRAulbsCJxKPgwzcSnkUof:
    VmBQOIMHNRAulbsCJxKPgwzcSnkUGe=VmBQOIMHNRAulbsCJxKPgwzcSnkUoY.get('season_Id')
    VmBQOIMHNRAulbsCJxKPgwzcSnkUGh=VmBQOIMHNRAulbsCJxKPgwzcSnkUoY.get('season_Nm')
    VmBQOIMHNRAulbsCJxKPgwzcSnkUGF=VmBQOIMHNRAulbsCJxKPgwzcSnkUoY.get('programNm')
    VmBQOIMHNRAulbsCJxKPgwzcSnkUyh=VmBQOIMHNRAulbsCJxKPgwzcSnkUoY.get('thumbnail')
    VmBQOIMHNRAulbsCJxKPgwzcSnkUGy =VmBQOIMHNRAulbsCJxKPgwzcSnkUoY.get('synopsis')
    VmBQOIMHNRAulbsCJxKPgwzcSnkUFX={'mediatype':'tvshow','title':VmBQOIMHNRAulbsCJxKPgwzcSnkUGh,'plot':VmBQOIMHNRAulbsCJxKPgwzcSnkUGy,}
    VmBQOIMHNRAulbsCJxKPgwzcSnkUhX={'mode':'EPISODE_LIST','seasonid':VmBQOIMHNRAulbsCJxKPgwzcSnkUGe,'page':'1',}
    VmBQOIMHNRAulbsCJxKPgwzcSnkUej.add_dir(VmBQOIMHNRAulbsCJxKPgwzcSnkUGh,sublabel=VmBQOIMHNRAulbsCJxKPgwzcSnkUGF,img=VmBQOIMHNRAulbsCJxKPgwzcSnkUyh,infoLabels=VmBQOIMHNRAulbsCJxKPgwzcSnkUFX,isFolder=VmBQOIMHNRAulbsCJxKPgwzcSnkUWL,params=VmBQOIMHNRAulbsCJxKPgwzcSnkUhX,ContextMenu=VmBQOIMHNRAulbsCJxKPgwzcSnkUWi)
   xbmcplugin.setContent(VmBQOIMHNRAulbsCJxKPgwzcSnkUej._addon_handle,'seasons')
   xbmcplugin.endOfDirectory(VmBQOIMHNRAulbsCJxKPgwzcSnkUej._addon_handle,cacheToDisc=VmBQOIMHNRAulbsCJxKPgwzcSnkUWd)
  else:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUGr={'seasonid':VmBQOIMHNRAulbsCJxKPgwzcSnkUoE,'page':'1',}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.dp_Episode_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUGr)
 def dp_Episode_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUej,args):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUoE =args.get('seasonid')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUFa =VmBQOIMHNRAulbsCJxKPgwzcSnkUWt(args.get('page'))
  VmBQOIMHNRAulbsCJxKPgwzcSnkUFE,VmBQOIMHNRAulbsCJxKPgwzcSnkUFW=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.Get_Episode_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUoE,VmBQOIMHNRAulbsCJxKPgwzcSnkUFa,orderby=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.get_winEpisodeOrderby())
  for VmBQOIMHNRAulbsCJxKPgwzcSnkUFf in VmBQOIMHNRAulbsCJxKPgwzcSnkUFE:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyj=VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('episodenumber')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUGo ='[%s]\n\n%s'%(VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('episodetitle'),VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('synopsis'))
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFX={'mediatype':'episode','title':VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('programtitle'),'plot':VmBQOIMHNRAulbsCJxKPgwzcSnkUGo,'cast':VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('episodeactors'),}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX={'mode':'VOD','programid':VmBQOIMHNRAulbsCJxKPgwzcSnkUoE,'contentid':VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('contentid'),'thumbnail':VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('thumbnail'),'title':VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('programtitle'),'subtitle':VmBQOIMHNRAulbsCJxKPgwzcSnkUyj,}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.add_dir(VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('programtitle'),sublabel=VmBQOIMHNRAulbsCJxKPgwzcSnkUyj,img=VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('thumbnail'),infoLabels=VmBQOIMHNRAulbsCJxKPgwzcSnkUFX,isFolder=VmBQOIMHNRAulbsCJxKPgwzcSnkUWd,params=VmBQOIMHNRAulbsCJxKPgwzcSnkUhX)
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUFa==1:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFX={'plot':'정렬순서를 변경합니다.'}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX={}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX['mode'] ='ORDER_BY' 
   if VmBQOIMHNRAulbsCJxKPgwzcSnkUej.get_winEpisodeOrderby()=='desc':
    VmBQOIMHNRAulbsCJxKPgwzcSnkUht='정렬순서변경 : 최신화부터 -> 1회부터'
    VmBQOIMHNRAulbsCJxKPgwzcSnkUhX['orderby']='asc'
   else:
    VmBQOIMHNRAulbsCJxKPgwzcSnkUht='정렬순서변경 : 1회부터 -> 최신화부터'
    VmBQOIMHNRAulbsCJxKPgwzcSnkUhX['orderby']='desc'
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhp=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.add_dir(VmBQOIMHNRAulbsCJxKPgwzcSnkUht,sublabel='',img=VmBQOIMHNRAulbsCJxKPgwzcSnkUhp,infoLabels=VmBQOIMHNRAulbsCJxKPgwzcSnkUFX,isFolder=VmBQOIMHNRAulbsCJxKPgwzcSnkUWd,params=VmBQOIMHNRAulbsCJxKPgwzcSnkUhX,isLink=VmBQOIMHNRAulbsCJxKPgwzcSnkUWL)
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUFW:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX={}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX['mode'] ='EPISODE_LIST' 
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX['seasonid']=VmBQOIMHNRAulbsCJxKPgwzcSnkUoE
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX['page'] =VmBQOIMHNRAulbsCJxKPgwzcSnkUWf(VmBQOIMHNRAulbsCJxKPgwzcSnkUFa+1)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUht='[B]%s >>[/B]'%'다음 페이지'
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyj=VmBQOIMHNRAulbsCJxKPgwzcSnkUWf(VmBQOIMHNRAulbsCJxKPgwzcSnkUFa+1)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhp=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.add_dir(VmBQOIMHNRAulbsCJxKPgwzcSnkUht,sublabel=VmBQOIMHNRAulbsCJxKPgwzcSnkUyj,img=VmBQOIMHNRAulbsCJxKPgwzcSnkUhp,infoLabels=VmBQOIMHNRAulbsCJxKPgwzcSnkUWi,isFolder=VmBQOIMHNRAulbsCJxKPgwzcSnkUWL,params=VmBQOIMHNRAulbsCJxKPgwzcSnkUhX)
  xbmcplugin.setContent(VmBQOIMHNRAulbsCJxKPgwzcSnkUej._addon_handle,'episodes')
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUWa(VmBQOIMHNRAulbsCJxKPgwzcSnkUFE)>0:xbmcplugin.endOfDirectory(VmBQOIMHNRAulbsCJxKPgwzcSnkUej._addon_handle,cacheToDisc=VmBQOIMHNRAulbsCJxKPgwzcSnkUWd)
 def dp_SuperSection_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUej,args):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUGW =args.get('suburl')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUoa =args.get('subapi')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUej.addon_log('dp_SuperSection_List')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUej.addon_log('suburl : '+VmBQOIMHNRAulbsCJxKPgwzcSnkUGW)
  VmBQOIMHNRAulbsCJxKPgwzcSnkUej.addon_log('subapi : '+VmBQOIMHNRAulbsCJxKPgwzcSnkUoa)
  VmBQOIMHNRAulbsCJxKPgwzcSnkUFE=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.Get_SuperMultiSection_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUGW)
  for VmBQOIMHNRAulbsCJxKPgwzcSnkUFf in VmBQOIMHNRAulbsCJxKPgwzcSnkUFE:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUht =VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('title')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUoa =VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('subapi')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUGj=VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('cell_type')
   if VmBQOIMHNRAulbsCJxKPgwzcSnkUoa.find('contenttype=movie')>=0 or VmBQOIMHNRAulbsCJxKPgwzcSnkUoa.find('mtype=svod')>=0:
    VmBQOIMHNRAulbsCJxKPgwzcSnkUFr='MOVIE_LIST'
   elif re.search('themes/2\d{4}',VmBQOIMHNRAulbsCJxKPgwzcSnkUoa)or re.search('themes-band/9\d{4}',VmBQOIMHNRAulbsCJxKPgwzcSnkUoa):
    VmBQOIMHNRAulbsCJxKPgwzcSnkUFr='MOVIE_LIST'
   else:
    VmBQOIMHNRAulbsCJxKPgwzcSnkUFr='PROGRAM_LIST'
   '''
   if subapi.find('mtype=svod') >= 0 or subapi.find('mtype=ppv') >= 0 or subapi.find('contenttype=movie') >= 0: #영화 #20201107
    mode = 'MOVIE_LIST'
   elif subapi.find('contenttype=program') >= 0:
    mode = 'PROGRAM_LIST'
   elif cell_type == 'band_71': # band_71 #20201107
    mode   = 'SUPERSECTION_LIST'
    (temp_url, temp_api) = self.WavveObj.Baseapi_Parse(subapi)
    suburl = temp_api.get('api')
    subapi = ''
   elif cell_type == 'band_2': # band_2
    mode = 'BAND2SECTION_LIST'
   elif cell_type == 'band_live':
    mode = 'BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}', subapi) :
    mode = 'MOVIE_LIST'
   else: # band_10
    mode = 'PROGRAM_LIST'
   '''   
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFX={'plot':VmBQOIMHNRAulbsCJxKPgwzcSnkUht,'mediatype':'tvshow',}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX={'mode':VmBQOIMHNRAulbsCJxKPgwzcSnkUFr,'suburl':VmBQOIMHNRAulbsCJxKPgwzcSnkUGW,'subapi':VmBQOIMHNRAulbsCJxKPgwzcSnkUoa,'page':'1',}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.add_dir(VmBQOIMHNRAulbsCJxKPgwzcSnkUht,sublabel='',img=VmBQOIMHNRAulbsCJxKPgwzcSnkUWi,infoLabels=VmBQOIMHNRAulbsCJxKPgwzcSnkUFX,isFolder=VmBQOIMHNRAulbsCJxKPgwzcSnkUWL,params=VmBQOIMHNRAulbsCJxKPgwzcSnkUhX)
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUWa(VmBQOIMHNRAulbsCJxKPgwzcSnkUFE)>0:xbmcplugin.endOfDirectory(VmBQOIMHNRAulbsCJxKPgwzcSnkUej._addon_handle,cacheToDisc=VmBQOIMHNRAulbsCJxKPgwzcSnkUWd)
 def dp_BandLiveSection_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUej,args):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUoa =args.get('subapi')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUFa=VmBQOIMHNRAulbsCJxKPgwzcSnkUWt(args.get('page'))
  VmBQOIMHNRAulbsCJxKPgwzcSnkUFE,VmBQOIMHNRAulbsCJxKPgwzcSnkUFW=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.Get_BandLiveSection_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUoa,VmBQOIMHNRAulbsCJxKPgwzcSnkUFa)
  for VmBQOIMHNRAulbsCJxKPgwzcSnkUFf in VmBQOIMHNRAulbsCJxKPgwzcSnkUFE:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUGq =VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('channelid')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUGT =VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('studio')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUGi=VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('tvshowtitle')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyh =VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('thumbnail')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyF =VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('age')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFX={'mediatype':'tvshow','mpaa':VmBQOIMHNRAulbsCJxKPgwzcSnkUyF,'title':'%s < %s >'%(VmBQOIMHNRAulbsCJxKPgwzcSnkUGT,VmBQOIMHNRAulbsCJxKPgwzcSnkUGi),'tvshowtitle':VmBQOIMHNRAulbsCJxKPgwzcSnkUGi,'studio':VmBQOIMHNRAulbsCJxKPgwzcSnkUGT,'plot':VmBQOIMHNRAulbsCJxKPgwzcSnkUGT}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX={'mode':'LIVE','contentid':VmBQOIMHNRAulbsCJxKPgwzcSnkUGq}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.add_dir(VmBQOIMHNRAulbsCJxKPgwzcSnkUGT,sublabel=VmBQOIMHNRAulbsCJxKPgwzcSnkUGi,img=VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('thumbnail'),infoLabels=VmBQOIMHNRAulbsCJxKPgwzcSnkUFX,isFolder=VmBQOIMHNRAulbsCJxKPgwzcSnkUWd,params=VmBQOIMHNRAulbsCJxKPgwzcSnkUhX)
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUFW:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX={}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX['mode'] ='BANDLIVESECTION_LIST' 
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX['subapi']=VmBQOIMHNRAulbsCJxKPgwzcSnkUoa
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX['page'] =VmBQOIMHNRAulbsCJxKPgwzcSnkUWf(VmBQOIMHNRAulbsCJxKPgwzcSnkUFa+1)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUht='[B]%s >>[/B]'%'다음 페이지'
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyj=VmBQOIMHNRAulbsCJxKPgwzcSnkUWf(VmBQOIMHNRAulbsCJxKPgwzcSnkUFa+1)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhp=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.add_dir(VmBQOIMHNRAulbsCJxKPgwzcSnkUht,sublabel=VmBQOIMHNRAulbsCJxKPgwzcSnkUyj,img=VmBQOIMHNRAulbsCJxKPgwzcSnkUhp,infoLabels=VmBQOIMHNRAulbsCJxKPgwzcSnkUWi,isFolder=VmBQOIMHNRAulbsCJxKPgwzcSnkUWL,params=VmBQOIMHNRAulbsCJxKPgwzcSnkUhX)
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUWa(VmBQOIMHNRAulbsCJxKPgwzcSnkUFE)>0:xbmcplugin.endOfDirectory(VmBQOIMHNRAulbsCJxKPgwzcSnkUej._addon_handle,cacheToDisc=VmBQOIMHNRAulbsCJxKPgwzcSnkUWd)
 def dp_Band2Section_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUej,args):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUoa =args.get('subapi')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUFa=VmBQOIMHNRAulbsCJxKPgwzcSnkUWt(args.get('page'))
  VmBQOIMHNRAulbsCJxKPgwzcSnkUFE,VmBQOIMHNRAulbsCJxKPgwzcSnkUFW=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.Get_Band2Section_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUoa,VmBQOIMHNRAulbsCJxKPgwzcSnkUFa)
  for VmBQOIMHNRAulbsCJxKPgwzcSnkUFf in VmBQOIMHNRAulbsCJxKPgwzcSnkUFE:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUht =VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('programtitle')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyj =VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('episodetitle')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFX={'plot':VmBQOIMHNRAulbsCJxKPgwzcSnkUht+'\n\n'+VmBQOIMHNRAulbsCJxKPgwzcSnkUyj,'mpaa':VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('age'),'mediatype':'episode'}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX={'mode':'VOD','programid':'-','contentid':VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('videoid'),'thumbnail':VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('thumbnail'),'title':VmBQOIMHNRAulbsCJxKPgwzcSnkUht,'subtitle':VmBQOIMHNRAulbsCJxKPgwzcSnkUyj}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.add_dir(VmBQOIMHNRAulbsCJxKPgwzcSnkUht,sublabel=VmBQOIMHNRAulbsCJxKPgwzcSnkUyj,img=VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('thumbnail'),infoLabels=VmBQOIMHNRAulbsCJxKPgwzcSnkUFX,isFolder=VmBQOIMHNRAulbsCJxKPgwzcSnkUWd,params=VmBQOIMHNRAulbsCJxKPgwzcSnkUhX)
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUFW:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX={}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX['mode'] ='BAND2SECTION_LIST' 
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX['subapi']=VmBQOIMHNRAulbsCJxKPgwzcSnkUoa
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX['page'] =VmBQOIMHNRAulbsCJxKPgwzcSnkUWf(VmBQOIMHNRAulbsCJxKPgwzcSnkUFa+1)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUht='[B]%s >>[/B]'%'다음 페이지'
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyj=VmBQOIMHNRAulbsCJxKPgwzcSnkUWf(VmBQOIMHNRAulbsCJxKPgwzcSnkUFa+1)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhp=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.add_dir(VmBQOIMHNRAulbsCJxKPgwzcSnkUht,sublabel=VmBQOIMHNRAulbsCJxKPgwzcSnkUyj,img=VmBQOIMHNRAulbsCJxKPgwzcSnkUhp,infoLabels=VmBQOIMHNRAulbsCJxKPgwzcSnkUWi,isFolder=VmBQOIMHNRAulbsCJxKPgwzcSnkUWL,params=VmBQOIMHNRAulbsCJxKPgwzcSnkUhX)
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUWa(VmBQOIMHNRAulbsCJxKPgwzcSnkUFE)>0:xbmcplugin.endOfDirectory(VmBQOIMHNRAulbsCJxKPgwzcSnkUej._addon_handle,cacheToDisc=VmBQOIMHNRAulbsCJxKPgwzcSnkUWd)
 def dp_Movie_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUej,args):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUoa =args.get('subapi')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUFa=VmBQOIMHNRAulbsCJxKPgwzcSnkUWt(args.get('page'))
  VmBQOIMHNRAulbsCJxKPgwzcSnkUhT =args.get('orderby')or '-'
  VmBQOIMHNRAulbsCJxKPgwzcSnkUej.addon_log('dp_Movie_List')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUej.addon_log(VmBQOIMHNRAulbsCJxKPgwzcSnkUoa)
  VmBQOIMHNRAulbsCJxKPgwzcSnkUFE,VmBQOIMHNRAulbsCJxKPgwzcSnkUFW=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.Get_Movie_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUoa,VmBQOIMHNRAulbsCJxKPgwzcSnkUFa,VmBQOIMHNRAulbsCJxKPgwzcSnkUhT)
  for VmBQOIMHNRAulbsCJxKPgwzcSnkUFf in VmBQOIMHNRAulbsCJxKPgwzcSnkUFE:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFY =VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('videoid')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUye =VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('vidtype')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUht =VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('title')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyh=VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('thumbnail')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyF =VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('age')
   if VmBQOIMHNRAulbsCJxKPgwzcSnkUyF=='18' or VmBQOIMHNRAulbsCJxKPgwzcSnkUyF=='19' or VmBQOIMHNRAulbsCJxKPgwzcSnkUyF=='21':VmBQOIMHNRAulbsCJxKPgwzcSnkUht+=' (%s)'%(VmBQOIMHNRAulbsCJxKPgwzcSnkUyF)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFX={'plot':VmBQOIMHNRAulbsCJxKPgwzcSnkUht,'mpaa':VmBQOIMHNRAulbsCJxKPgwzcSnkUyF,'mediatype':'movie'}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX={'mode':'MOVIE','contentid':VmBQOIMHNRAulbsCJxKPgwzcSnkUFY,'title':VmBQOIMHNRAulbsCJxKPgwzcSnkUht,'thumbnail':VmBQOIMHNRAulbsCJxKPgwzcSnkUyh,'age':VmBQOIMHNRAulbsCJxKPgwzcSnkUyF,}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFp=[]
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyr={'mode':'VIEW_DETAIL','values':{'videoid':VmBQOIMHNRAulbsCJxKPgwzcSnkUFY,'vidtype':'movie','contenttype':VmBQOIMHNRAulbsCJxKPgwzcSnkUye,}}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyo=json.dumps(VmBQOIMHNRAulbsCJxKPgwzcSnkUyr,separators=(',',':'))
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyo=base64.standard_b64encode(VmBQOIMHNRAulbsCJxKPgwzcSnkUyo.encode()).decode('utf-8')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyo=VmBQOIMHNRAulbsCJxKPgwzcSnkUyo.replace('+','%2B')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyG='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(VmBQOIMHNRAulbsCJxKPgwzcSnkUyo)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFp.append(('상세정보 조회',VmBQOIMHNRAulbsCJxKPgwzcSnkUyG))
   if VmBQOIMHNRAulbsCJxKPgwzcSnkUej.get_settings_makebookmark():
    VmBQOIMHNRAulbsCJxKPgwzcSnkUyr={'videoid':VmBQOIMHNRAulbsCJxKPgwzcSnkUFY,'vidtype':'movie','vtitle':VmBQOIMHNRAulbsCJxKPgwzcSnkUht,'vsubtitle':'','contenttype':'programid',}
    VmBQOIMHNRAulbsCJxKPgwzcSnkUyW=json.dumps(VmBQOIMHNRAulbsCJxKPgwzcSnkUyr)
    VmBQOIMHNRAulbsCJxKPgwzcSnkUyW=urllib.parse.quote(VmBQOIMHNRAulbsCJxKPgwzcSnkUyW)
    VmBQOIMHNRAulbsCJxKPgwzcSnkUyG='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(VmBQOIMHNRAulbsCJxKPgwzcSnkUyW)
    VmBQOIMHNRAulbsCJxKPgwzcSnkUFp.append(('(통합) 찜 영상에 추가',VmBQOIMHNRAulbsCJxKPgwzcSnkUyG))
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.add_dir(VmBQOIMHNRAulbsCJxKPgwzcSnkUht,sublabel='',img=VmBQOIMHNRAulbsCJxKPgwzcSnkUyh,infoLabels=VmBQOIMHNRAulbsCJxKPgwzcSnkUFX,isFolder=VmBQOIMHNRAulbsCJxKPgwzcSnkUWd,params=VmBQOIMHNRAulbsCJxKPgwzcSnkUhX,ContextMenu=VmBQOIMHNRAulbsCJxKPgwzcSnkUFp)
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUFW:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX={}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX['mode'] ='MOVIE_LIST' 
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX['subapi']=VmBQOIMHNRAulbsCJxKPgwzcSnkUoa 
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX['page'] =VmBQOIMHNRAulbsCJxKPgwzcSnkUWf(VmBQOIMHNRAulbsCJxKPgwzcSnkUFa+1)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX['orderby']=VmBQOIMHNRAulbsCJxKPgwzcSnkUhT
   VmBQOIMHNRAulbsCJxKPgwzcSnkUht='[B]%s >>[/B]'%'다음 페이지'
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyj=VmBQOIMHNRAulbsCJxKPgwzcSnkUWf(VmBQOIMHNRAulbsCJxKPgwzcSnkUFa+1)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhp=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.add_dir(VmBQOIMHNRAulbsCJxKPgwzcSnkUht,sublabel=VmBQOIMHNRAulbsCJxKPgwzcSnkUyj,img=VmBQOIMHNRAulbsCJxKPgwzcSnkUhp,infoLabels=VmBQOIMHNRAulbsCJxKPgwzcSnkUWi,isFolder=VmBQOIMHNRAulbsCJxKPgwzcSnkUWL,params=VmBQOIMHNRAulbsCJxKPgwzcSnkUhX)
  xbmcplugin.setContent(VmBQOIMHNRAulbsCJxKPgwzcSnkUej._addon_handle,'movies')
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUWa(VmBQOIMHNRAulbsCJxKPgwzcSnkUFE)>0:xbmcplugin.endOfDirectory(VmBQOIMHNRAulbsCJxKPgwzcSnkUej._addon_handle,cacheToDisc=VmBQOIMHNRAulbsCJxKPgwzcSnkUWd)
 def dp_Set_Bookmark(VmBQOIMHNRAulbsCJxKPgwzcSnkUej,args):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUGt=urllib.parse.unquote(args.get('bm_param'))
  VmBQOIMHNRAulbsCJxKPgwzcSnkUGt=json.loads(VmBQOIMHNRAulbsCJxKPgwzcSnkUGt)
  VmBQOIMHNRAulbsCJxKPgwzcSnkUFY =VmBQOIMHNRAulbsCJxKPgwzcSnkUGt.get('videoid')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUye =VmBQOIMHNRAulbsCJxKPgwzcSnkUGt.get('vidtype')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUGL =VmBQOIMHNRAulbsCJxKPgwzcSnkUGt.get('vtitle')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUGd =VmBQOIMHNRAulbsCJxKPgwzcSnkUGt.get('vsubtitle')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUGv=VmBQOIMHNRAulbsCJxKPgwzcSnkUGt.get('contenttype')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUeL=xbmcgui.Dialog()
  VmBQOIMHNRAulbsCJxKPgwzcSnkUre=VmBQOIMHNRAulbsCJxKPgwzcSnkUeL.yesno(__language__(30913).encode('utf8'),VmBQOIMHNRAulbsCJxKPgwzcSnkUGL+' \n\n'+__language__(30914))
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUre==VmBQOIMHNRAulbsCJxKPgwzcSnkUWd:return
  VmBQOIMHNRAulbsCJxKPgwzcSnkUGD=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.GetBookmarkInfo(VmBQOIMHNRAulbsCJxKPgwzcSnkUFY,VmBQOIMHNRAulbsCJxKPgwzcSnkUye,VmBQOIMHNRAulbsCJxKPgwzcSnkUGv)
  VmBQOIMHNRAulbsCJxKPgwzcSnkUGp=json.dumps(VmBQOIMHNRAulbsCJxKPgwzcSnkUGD)
  VmBQOIMHNRAulbsCJxKPgwzcSnkUGp=urllib.parse.quote(VmBQOIMHNRAulbsCJxKPgwzcSnkUGp)
  VmBQOIMHNRAulbsCJxKPgwzcSnkUyG ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(VmBQOIMHNRAulbsCJxKPgwzcSnkUGp)
  xbmc.executebuiltin(VmBQOIMHNRAulbsCJxKPgwzcSnkUyG)
 def dp_LiveChannel_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUej,args):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUGX =args.get('genre')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUoX=args.get('baseapi')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUFE=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.Get_LiveChannel_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUGX,VmBQOIMHNRAulbsCJxKPgwzcSnkUoX)
  for VmBQOIMHNRAulbsCJxKPgwzcSnkUFf in VmBQOIMHNRAulbsCJxKPgwzcSnkUFE:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUGq =VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('channelid')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUGT =VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('studio')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUGi=VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('tvshowtitle')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyh =VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('thumbnail')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUyF =VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('age')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUGa =VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('epg')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFX={'mediatype':'episode','mpaa':VmBQOIMHNRAulbsCJxKPgwzcSnkUyF,'title':'%s < %s >'%(VmBQOIMHNRAulbsCJxKPgwzcSnkUGT,VmBQOIMHNRAulbsCJxKPgwzcSnkUGi),'tvshowtitle':VmBQOIMHNRAulbsCJxKPgwzcSnkUGi,'studio':VmBQOIMHNRAulbsCJxKPgwzcSnkUGT,'plot':'%s\n\n%s'%(VmBQOIMHNRAulbsCJxKPgwzcSnkUGT,VmBQOIMHNRAulbsCJxKPgwzcSnkUGa)}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX={'mode':'LIVE','contentid':VmBQOIMHNRAulbsCJxKPgwzcSnkUGq}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.add_dir(VmBQOIMHNRAulbsCJxKPgwzcSnkUGT,sublabel=VmBQOIMHNRAulbsCJxKPgwzcSnkUGi,img=VmBQOIMHNRAulbsCJxKPgwzcSnkUyh,infoLabels=VmBQOIMHNRAulbsCJxKPgwzcSnkUFX,isFolder=VmBQOIMHNRAulbsCJxKPgwzcSnkUWd,params=VmBQOIMHNRAulbsCJxKPgwzcSnkUhX)
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUWa(VmBQOIMHNRAulbsCJxKPgwzcSnkUFE)>0:xbmcplugin.endOfDirectory(VmBQOIMHNRAulbsCJxKPgwzcSnkUej._addon_handle,cacheToDisc=VmBQOIMHNRAulbsCJxKPgwzcSnkUWd)
 def dp_Sports_GameList(VmBQOIMHNRAulbsCJxKPgwzcSnkUej,args):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUFE=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.Get_Sports_Gamelist()
  for VmBQOIMHNRAulbsCJxKPgwzcSnkUFf in VmBQOIMHNRAulbsCJxKPgwzcSnkUFE:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUGE =VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('game_date')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUGf =VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('game_time')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUGY =VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('svc_id')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUWe =VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('away_team')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUWh =VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('home_team')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUWF=VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('game_status')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUWy =VmBQOIMHNRAulbsCJxKPgwzcSnkUFf.get('game_place')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUWr ='%s vs %s (%s)'%(VmBQOIMHNRAulbsCJxKPgwzcSnkUWe,VmBQOIMHNRAulbsCJxKPgwzcSnkUWh,VmBQOIMHNRAulbsCJxKPgwzcSnkUWy)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUWo =VmBQOIMHNRAulbsCJxKPgwzcSnkUGE+' '+VmBQOIMHNRAulbsCJxKPgwzcSnkUGf
   if VmBQOIMHNRAulbsCJxKPgwzcSnkUWF=='LIVE':
    VmBQOIMHNRAulbsCJxKPgwzcSnkUWF='~경기중~'
   elif VmBQOIMHNRAulbsCJxKPgwzcSnkUWF=='END':
    VmBQOIMHNRAulbsCJxKPgwzcSnkUWF='경기종료'
   elif VmBQOIMHNRAulbsCJxKPgwzcSnkUWF=='CANCEL':
    VmBQOIMHNRAulbsCJxKPgwzcSnkUWF='취소'
   else:
    VmBQOIMHNRAulbsCJxKPgwzcSnkUWF=''
   if VmBQOIMHNRAulbsCJxKPgwzcSnkUWF=='':
    VmBQOIMHNRAulbsCJxKPgwzcSnkUyj=VmBQOIMHNRAulbsCJxKPgwzcSnkUWr
   else:
    VmBQOIMHNRAulbsCJxKPgwzcSnkUyj=VmBQOIMHNRAulbsCJxKPgwzcSnkUWr+'  '+VmBQOIMHNRAulbsCJxKPgwzcSnkUWF
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFX={'mediatype':'episode','title':VmBQOIMHNRAulbsCJxKPgwzcSnkUWr,'plot':'%s\n\n%s\n\n%s'%(VmBQOIMHNRAulbsCJxKPgwzcSnkUWo,VmBQOIMHNRAulbsCJxKPgwzcSnkUWr,VmBQOIMHNRAulbsCJxKPgwzcSnkUWF)}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX={'mode':'SPORTS','contentid':VmBQOIMHNRAulbsCJxKPgwzcSnkUGY}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.add_dir(VmBQOIMHNRAulbsCJxKPgwzcSnkUWo,sublabel=VmBQOIMHNRAulbsCJxKPgwzcSnkUyj,img='',infoLabels=VmBQOIMHNRAulbsCJxKPgwzcSnkUFX,isFolder=VmBQOIMHNRAulbsCJxKPgwzcSnkUWd,params=VmBQOIMHNRAulbsCJxKPgwzcSnkUhX)
  xbmcplugin.endOfDirectory(VmBQOIMHNRAulbsCJxKPgwzcSnkUej._addon_handle,cacheToDisc=VmBQOIMHNRAulbsCJxKPgwzcSnkUWd)
 def dp_View_Detail(VmBQOIMHNRAulbsCJxKPgwzcSnkUej,VmBQOIMHNRAulbsCJxKPgwzcSnkUWq):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUFY =VmBQOIMHNRAulbsCJxKPgwzcSnkUWq.get('videoid')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUye =VmBQOIMHNRAulbsCJxKPgwzcSnkUWq.get('vidtype') 
  VmBQOIMHNRAulbsCJxKPgwzcSnkUGv=VmBQOIMHNRAulbsCJxKPgwzcSnkUWq.get('contenttype')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUej.addon_log(VmBQOIMHNRAulbsCJxKPgwzcSnkUFY)
  VmBQOIMHNRAulbsCJxKPgwzcSnkUej.addon_log(VmBQOIMHNRAulbsCJxKPgwzcSnkUye)
  VmBQOIMHNRAulbsCJxKPgwzcSnkUej.addon_log(VmBQOIMHNRAulbsCJxKPgwzcSnkUGv)
  VmBQOIMHNRAulbsCJxKPgwzcSnkUGD=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.GetBookmarkInfo(VmBQOIMHNRAulbsCJxKPgwzcSnkUFY,VmBQOIMHNRAulbsCJxKPgwzcSnkUye,VmBQOIMHNRAulbsCJxKPgwzcSnkUGv)
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUye=='tvshow':
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX={'mode':'SEASON_LIST','videoid':VmBQOIMHNRAulbsCJxKPgwzcSnkUGD['indexinfo']['videoid'],'vidtype':VmBQOIMHNRAulbsCJxKPgwzcSnkUGD['indexinfo']['vidtype'],}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUro='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(VmBQOIMHNRAulbsCJxKPgwzcSnkUhX))
  else:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhX={'mode':'MOVIE','contentid':VmBQOIMHNRAulbsCJxKPgwzcSnkUGD['indexinfo']['videoid'],'title':VmBQOIMHNRAulbsCJxKPgwzcSnkUGD['saveinfo']['infoLabels']['title'],'thumbnail':VmBQOIMHNRAulbsCJxKPgwzcSnkUGD['saveinfo']['thumbnail'],'age':VmBQOIMHNRAulbsCJxKPgwzcSnkUGD['saveinfo']['infoLabels']['mpaa'],}
   VmBQOIMHNRAulbsCJxKPgwzcSnkUro='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(VmBQOIMHNRAulbsCJxKPgwzcSnkUhX))
  VmBQOIMHNRAulbsCJxKPgwzcSnkUhL=xbmcgui.ListItem(label=VmBQOIMHNRAulbsCJxKPgwzcSnkUGD['saveinfo']['title'],path=VmBQOIMHNRAulbsCJxKPgwzcSnkUro)
  VmBQOIMHNRAulbsCJxKPgwzcSnkUhL.setArt(VmBQOIMHNRAulbsCJxKPgwzcSnkUGD['saveinfo']['thumbnail'])
  VmBQOIMHNRAulbsCJxKPgwzcSnkUej.Set_InfoTag(VmBQOIMHNRAulbsCJxKPgwzcSnkUhL.getVideoInfoTag(),VmBQOIMHNRAulbsCJxKPgwzcSnkUGD['saveinfo']['infoLabels'])
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUye=='movie':
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhL.setIsFolder(VmBQOIMHNRAulbsCJxKPgwzcSnkUWd)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhL.setProperty('IsPlayable','true')
  else:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhL.setIsFolder(VmBQOIMHNRAulbsCJxKPgwzcSnkUWL)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUhL.setProperty('IsPlayable','false')
  VmBQOIMHNRAulbsCJxKPgwzcSnkUeL=xbmcgui.Dialog()
  VmBQOIMHNRAulbsCJxKPgwzcSnkUeL.info(VmBQOIMHNRAulbsCJxKPgwzcSnkUhL)
 def wavve_main(VmBQOIMHNRAulbsCJxKPgwzcSnkUej):
  VmBQOIMHNRAulbsCJxKPgwzcSnkUej.WavveObj.KodiVersion=VmBQOIMHNRAulbsCJxKPgwzcSnkUWt(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  VmBQOIMHNRAulbsCJxKPgwzcSnkUWG=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.main_params.get('params')
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUWG:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUWj =base64.standard_b64decode(VmBQOIMHNRAulbsCJxKPgwzcSnkUWG).decode('utf-8')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUWj =json.loads(VmBQOIMHNRAulbsCJxKPgwzcSnkUWj)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFr =VmBQOIMHNRAulbsCJxKPgwzcSnkUWj.get('mode')
   VmBQOIMHNRAulbsCJxKPgwzcSnkUWq =VmBQOIMHNRAulbsCJxKPgwzcSnkUWj.get('values')
  else:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUFr=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.main_params.get('mode',VmBQOIMHNRAulbsCJxKPgwzcSnkUWi)
   VmBQOIMHNRAulbsCJxKPgwzcSnkUWq=VmBQOIMHNRAulbsCJxKPgwzcSnkUej.main_params
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUFr=='LOGOUT':
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.logout()
   return
  VmBQOIMHNRAulbsCJxKPgwzcSnkUej.login_main()
  if VmBQOIMHNRAulbsCJxKPgwzcSnkUFr is VmBQOIMHNRAulbsCJxKPgwzcSnkUWi:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.dp_Main_List()
  elif VmBQOIMHNRAulbsCJxKPgwzcSnkUFr in['LIVE','VOD','MOVIE','SPORTS']:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.play_VIDEO(VmBQOIMHNRAulbsCJxKPgwzcSnkUWq)
  elif VmBQOIMHNRAulbsCJxKPgwzcSnkUFr=='LIVE_CATAGORY':
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.dp_LiveCatagory_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUWq)
  elif VmBQOIMHNRAulbsCJxKPgwzcSnkUFr=='MAIN_CATAGORY':
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.dp_MainCatagory_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUWq)
  elif VmBQOIMHNRAulbsCJxKPgwzcSnkUFr=='SUPERSECTION_LIST':
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.dp_SuperSection_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUWq)
  elif VmBQOIMHNRAulbsCJxKPgwzcSnkUFr=='BANDLIVESECTION_LIST':
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.dp_BandLiveSection_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUWq)
  elif VmBQOIMHNRAulbsCJxKPgwzcSnkUFr=='BAND2SECTION_LIST':
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.dp_Band2Section_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUWq)
  elif VmBQOIMHNRAulbsCJxKPgwzcSnkUFr=='PROGRAM_LIST':
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.dp_Program_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUWq)
  elif VmBQOIMHNRAulbsCJxKPgwzcSnkUFr=='SEASON_LIST':
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.dp_Season_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUWq)
  elif VmBQOIMHNRAulbsCJxKPgwzcSnkUFr=='EPISODE_LIST':
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.dp_Episode_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUWq)
  elif VmBQOIMHNRAulbsCJxKPgwzcSnkUFr=='MOVIE_LIST':
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.dp_Movie_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUWq)
  elif VmBQOIMHNRAulbsCJxKPgwzcSnkUFr=='LIVE_LIST':
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.dp_LiveChannel_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUWq)
  elif VmBQOIMHNRAulbsCJxKPgwzcSnkUFr=='ORDER_BY':
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.dp_setEpOrderby(VmBQOIMHNRAulbsCJxKPgwzcSnkUWq)
  elif VmBQOIMHNRAulbsCJxKPgwzcSnkUFr=='SEARCH_GROUP':
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.dp_Search_Group(VmBQOIMHNRAulbsCJxKPgwzcSnkUWq)
  elif VmBQOIMHNRAulbsCJxKPgwzcSnkUFr in['SEARCH_LIST','LOCAL_SEARCH']:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.dp_Search_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUWq)
  elif VmBQOIMHNRAulbsCJxKPgwzcSnkUFr=='WATCH_GROUP':
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.dp_Watch_Group(VmBQOIMHNRAulbsCJxKPgwzcSnkUWq)
  elif VmBQOIMHNRAulbsCJxKPgwzcSnkUFr=='WATCH_LIST':
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.dp_Watch_List(VmBQOIMHNRAulbsCJxKPgwzcSnkUWq)
  elif VmBQOIMHNRAulbsCJxKPgwzcSnkUFr=='SET_BOOKMARK':
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.dp_Set_Bookmark(VmBQOIMHNRAulbsCJxKPgwzcSnkUWq)
  elif VmBQOIMHNRAulbsCJxKPgwzcSnkUFr in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.dp_History_Remove(VmBQOIMHNRAulbsCJxKPgwzcSnkUWq)
  elif VmBQOIMHNRAulbsCJxKPgwzcSnkUFr in['TOTAL_SEARCH','TOTAL_HISTORY']:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.dp_Global_Search(VmBQOIMHNRAulbsCJxKPgwzcSnkUWq)
  elif VmBQOIMHNRAulbsCJxKPgwzcSnkUFr=='SEARCH_HISTORY':
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.dp_Search_History(VmBQOIMHNRAulbsCJxKPgwzcSnkUWq)
  elif VmBQOIMHNRAulbsCJxKPgwzcSnkUFr=='MENU_BOOKMARK':
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.dp_Bookmark_Menu(VmBQOIMHNRAulbsCJxKPgwzcSnkUWq)
  elif VmBQOIMHNRAulbsCJxKPgwzcSnkUFr=='GAME_LIST':
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.dp_Sports_GameList(VmBQOIMHNRAulbsCJxKPgwzcSnkUWq)
  elif VmBQOIMHNRAulbsCJxKPgwzcSnkUFr=='VIEW_DETAIL':
   VmBQOIMHNRAulbsCJxKPgwzcSnkUej.dp_View_Detail(VmBQOIMHNRAulbsCJxKPgwzcSnkUWq)
  else:
   VmBQOIMHNRAulbsCJxKPgwzcSnkUWi
# Created by pyminifier (https://github.com/liftoff/pyminifier)
