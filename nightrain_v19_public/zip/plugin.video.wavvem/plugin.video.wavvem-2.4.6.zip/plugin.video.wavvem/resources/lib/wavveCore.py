__author__="NightRain"
kJweEUzCRBodXmSnYFiKxthWMrcfGN=object
kJweEUzCRBodXmSnYFiKxthWMrcfGu=None
kJweEUzCRBodXmSnYFiKxthWMrcfGb=False
kJweEUzCRBodXmSnYFiKxthWMrcfGp=open
kJweEUzCRBodXmSnYFiKxthWMrcfyP=True
kJweEUzCRBodXmSnYFiKxthWMrcfyl=range
kJweEUzCRBodXmSnYFiKxthWMrcfyD=str
kJweEUzCRBodXmSnYFiKxthWMrcfyg=len
kJweEUzCRBodXmSnYFiKxthWMrcfyO=Exception
kJweEUzCRBodXmSnYFiKxthWMrcfyH=print
kJweEUzCRBodXmSnYFiKxthWMrcfyG=dict
kJweEUzCRBodXmSnYFiKxthWMrcfyQ=int
import urllib
import re
import json
import sys
import requests
import datetime
import base64
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
kJweEUzCRBodXmSnYFiKxthWMrcfPD =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
class kJweEUzCRBodXmSnYFiKxthWMrcfPl(kJweEUzCRBodXmSnYFiKxthWMrcfGN):
 def __init__(kJweEUzCRBodXmSnYFiKxthWMrcfPg):
  kJweEUzCRBodXmSnYFiKxthWMrcfPg.API_DOMAIN='https://apis.wavve.com'
  kJweEUzCRBodXmSnYFiKxthWMrcfPg.WV ={}
  kJweEUzCRBodXmSnYFiKxthWMrcfPg.Init_WV_Total()
  kJweEUzCRBodXmSnYFiKxthWMrcfPg.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  kJweEUzCRBodXmSnYFiKxthWMrcfPg.DEVICE ='pc'
  kJweEUzCRBodXmSnYFiKxthWMrcfPg.DRM ='wm'
  kJweEUzCRBodXmSnYFiKxthWMrcfPg.PARTNER ='pooq'
  kJweEUzCRBodXmSnYFiKxthWMrcfPg.POOQZONE ='none'
  kJweEUzCRBodXmSnYFiKxthWMrcfPg.REGION ='kor'
  kJweEUzCRBodXmSnYFiKxthWMrcfPg.TARGETAGE ='all'
  kJweEUzCRBodXmSnYFiKxthWMrcfPg.HTTPTAG ='https://'
  kJweEUzCRBodXmSnYFiKxthWMrcfPg.LIST_LIMIT=30 
  kJweEUzCRBodXmSnYFiKxthWMrcfPg.EP_LIMIT =30 
  kJweEUzCRBodXmSnYFiKxthWMrcfPg.MV_LIMIT =24 
  kJweEUzCRBodXmSnYFiKxthWMrcfPg.SEARCH_LIMIT=20 
  kJweEUzCRBodXmSnYFiKxthWMrcfPg.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
  kJweEUzCRBodXmSnYFiKxthWMrcfPg.DEFAULT_HEADER={'user-agent':kJweEUzCRBodXmSnYFiKxthWMrcfPg.USER_AGENT}
  kJweEUzCRBodXmSnYFiKxthWMrcfPg.KodiVersion=20
  kJweEUzCRBodXmSnYFiKxthWMrcfPg.WV_SESSION_COOKIES1=''
  kJweEUzCRBodXmSnYFiKxthWMrcfPg.WV_SESSION_COOKIES2=''
  kJweEUzCRBodXmSnYFiKxthWMrcfPg.COOKIE_FILE_NAME =''
  kJweEUzCRBodXmSnYFiKxthWMrcfPg.WV_STREAM_FILENAME =''
 def Init_WV_Total(kJweEUzCRBodXmSnYFiKxthWMrcfPg):
  kJweEUzCRBodXmSnYFiKxthWMrcfPg.WV={'account':{},'cookies':{},}
 def callRequestCookies(kJweEUzCRBodXmSnYFiKxthWMrcfPg,jobtype,kJweEUzCRBodXmSnYFiKxthWMrcflq,payload=kJweEUzCRBodXmSnYFiKxthWMrcfGu,params=kJweEUzCRBodXmSnYFiKxthWMrcfGu,headers=kJweEUzCRBodXmSnYFiKxthWMrcfGu,cookies=kJweEUzCRBodXmSnYFiKxthWMrcfGu,redirects=kJweEUzCRBodXmSnYFiKxthWMrcfGb):
  kJweEUzCRBodXmSnYFiKxthWMrcfPO=kJweEUzCRBodXmSnYFiKxthWMrcfPg.DEFAULT_HEADER
  if headers:kJweEUzCRBodXmSnYFiKxthWMrcfPO.update(headers)
  if jobtype=='Get':
   kJweEUzCRBodXmSnYFiKxthWMrcfPH=requests.get(kJweEUzCRBodXmSnYFiKxthWMrcflq,params=params,headers=kJweEUzCRBodXmSnYFiKxthWMrcfPO,cookies=cookies,allow_redirects=redirects)
  else:
   kJweEUzCRBodXmSnYFiKxthWMrcfPH=requests.post(kJweEUzCRBodXmSnYFiKxthWMrcflq,json=payload,params=params,headers=kJweEUzCRBodXmSnYFiKxthWMrcfPO,cookies=cookies,allow_redirects=redirects)
  return kJweEUzCRBodXmSnYFiKxthWMrcfPH
 def JsonFile_Save(kJweEUzCRBodXmSnYFiKxthWMrcfPg,filename,kJweEUzCRBodXmSnYFiKxthWMrcfPG):
  if filename=='':return kJweEUzCRBodXmSnYFiKxthWMrcfGb
  try:
   fp=kJweEUzCRBodXmSnYFiKxthWMrcfGp(filename,'w',-1,'utf-8')
   json.dump(kJweEUzCRBodXmSnYFiKxthWMrcfPG,fp,indent=4,ensure_ascii=kJweEUzCRBodXmSnYFiKxthWMrcfGb)
   fp.close()
  except:
   return kJweEUzCRBodXmSnYFiKxthWMrcfGb
  return kJweEUzCRBodXmSnYFiKxthWMrcfyP
 def JsonFile_Load(kJweEUzCRBodXmSnYFiKxthWMrcfPg,filename):
  if filename=='':return{}
  try:
   fp=kJweEUzCRBodXmSnYFiKxthWMrcfGp(filename,'r',-1,'utf-8')
   kJweEUzCRBodXmSnYFiKxthWMrcfPQ=json.load(fp)
   fp.close()
  except:
   return{}
  return kJweEUzCRBodXmSnYFiKxthWMrcfPQ
 def TextFile_Save(kJweEUzCRBodXmSnYFiKxthWMrcfPg,filename,resText):
  if filename=='':return kJweEUzCRBodXmSnYFiKxthWMrcfGb
  try:
   fp=kJweEUzCRBodXmSnYFiKxthWMrcfGp(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return kJweEUzCRBodXmSnYFiKxthWMrcfGb
  return kJweEUzCRBodXmSnYFiKxthWMrcfyP
 def Save_session_acount(kJweEUzCRBodXmSnYFiKxthWMrcfPg,kJweEUzCRBodXmSnYFiKxthWMrcfPA,kJweEUzCRBodXmSnYFiKxthWMrcfPq,kJweEUzCRBodXmSnYFiKxthWMrcfPT):
  kJweEUzCRBodXmSnYFiKxthWMrcfPg.WV['account']['wvid']=base64.standard_b64encode(kJweEUzCRBodXmSnYFiKxthWMrcfPA.encode()).decode('utf-8')
  kJweEUzCRBodXmSnYFiKxthWMrcfPg.WV['account']['wvpw']=base64.standard_b64encode(kJweEUzCRBodXmSnYFiKxthWMrcfPq.encode()).decode('utf-8')
  kJweEUzCRBodXmSnYFiKxthWMrcfPg.WV['account']['wvpf']=kJweEUzCRBodXmSnYFiKxthWMrcfPT 
 def Load_session_acount(kJweEUzCRBodXmSnYFiKxthWMrcfPg):
  try:
   kJweEUzCRBodXmSnYFiKxthWMrcfPA=base64.standard_b64decode(kJweEUzCRBodXmSnYFiKxthWMrcfPg.WV['account']['wvid']).decode('utf-8')
   kJweEUzCRBodXmSnYFiKxthWMrcfPq=base64.standard_b64decode(kJweEUzCRBodXmSnYFiKxthWMrcfPg.WV['account']['wvpw']).decode('utf-8')
   kJweEUzCRBodXmSnYFiKxthWMrcfPT=kJweEUzCRBodXmSnYFiKxthWMrcfPg.WV['account']['wvpf']
  except:
   return '','',0
  return kJweEUzCRBodXmSnYFiKxthWMrcfPA,kJweEUzCRBodXmSnYFiKxthWMrcfPq,kJweEUzCRBodXmSnYFiKxthWMrcfPT
 def GetDefaultParams(kJweEUzCRBodXmSnYFiKxthWMrcfPg,login=kJweEUzCRBodXmSnYFiKxthWMrcfyP):
  kJweEUzCRBodXmSnYFiKxthWMrcfPL={'apikey':kJweEUzCRBodXmSnYFiKxthWMrcfPg.APIKEY,'credential':kJweEUzCRBodXmSnYFiKxthWMrcfPg.WV['cookies']['credential']if login else 'none','device':kJweEUzCRBodXmSnYFiKxthWMrcfPg.DEVICE,'drm':kJweEUzCRBodXmSnYFiKxthWMrcfPg.DRM,'partner':kJweEUzCRBodXmSnYFiKxthWMrcfPg.PARTNER,'pooqzone':kJweEUzCRBodXmSnYFiKxthWMrcfPg.POOQZONE,'region':kJweEUzCRBodXmSnYFiKxthWMrcfPg.REGION,'targetage':kJweEUzCRBodXmSnYFiKxthWMrcfPg.TARGETAGE,'client_version':'6.0.1',}
  return kJweEUzCRBodXmSnYFiKxthWMrcfPL
 def GetDefaultParams_AND(kJweEUzCRBodXmSnYFiKxthWMrcfPg):
  kJweEUzCRBodXmSnYFiKxthWMrcfPL={'apikey':'6A87455D54481A536DFB8AD397C5EC4D','credential':kJweEUzCRBodXmSnYFiKxthWMrcfPg.WV['cookies']['credential'],'device':'ott','drm':kJweEUzCRBodXmSnYFiKxthWMrcfPg.DRM,'partner':kJweEUzCRBodXmSnYFiKxthWMrcfPg.PARTNER,'pooqzone':kJweEUzCRBodXmSnYFiKxthWMrcfPg.POOQZONE,'region':kJweEUzCRBodXmSnYFiKxthWMrcfPg.REGION,'targetage':kJweEUzCRBodXmSnYFiKxthWMrcfPg.TARGETAGE,}
  return kJweEUzCRBodXmSnYFiKxthWMrcfPL
 def GetGUID(kJweEUzCRBodXmSnYFiKxthWMrcfPg,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   kJweEUzCRBodXmSnYFiKxthWMrcfPV=kJweEUzCRBodXmSnYFiKxthWMrcfPg.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   kJweEUzCRBodXmSnYFiKxthWMrcfPa=GenerateRandomString(5)
   kJweEUzCRBodXmSnYFiKxthWMrcfPj=kJweEUzCRBodXmSnYFiKxthWMrcfPa+media+kJweEUzCRBodXmSnYFiKxthWMrcfPV
   return kJweEUzCRBodXmSnYFiKxthWMrcfPj
  def GenerateRandomString(num):
   from random import randint
   kJweEUzCRBodXmSnYFiKxthWMrcfPv=""
   for i in kJweEUzCRBodXmSnYFiKxthWMrcfyl(0,num):
    s=kJweEUzCRBodXmSnYFiKxthWMrcfyD(randint(1,5))
    kJweEUzCRBodXmSnYFiKxthWMrcfPv+=s
   return kJweEUzCRBodXmSnYFiKxthWMrcfPv
  if guidType==3:
   kJweEUzCRBodXmSnYFiKxthWMrcfPj=guid_str
  else:
   kJweEUzCRBodXmSnYFiKxthWMrcfPj=GenerateID(guid_str)
  kJweEUzCRBodXmSnYFiKxthWMrcfPI=kJweEUzCRBodXmSnYFiKxthWMrcfPg.GetHash(kJweEUzCRBodXmSnYFiKxthWMrcfPj)
  if guidType in[2,3]:
   kJweEUzCRBodXmSnYFiKxthWMrcfPI='%s-%s-%s-%s-%s'%(kJweEUzCRBodXmSnYFiKxthWMrcfPI[:8],kJweEUzCRBodXmSnYFiKxthWMrcfPI[8:12],kJweEUzCRBodXmSnYFiKxthWMrcfPI[12:16],kJweEUzCRBodXmSnYFiKxthWMrcfPI[16:20],kJweEUzCRBodXmSnYFiKxthWMrcfPI[20:])
  return kJweEUzCRBodXmSnYFiKxthWMrcfPI
 def GetHash(kJweEUzCRBodXmSnYFiKxthWMrcfPg,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return kJweEUzCRBodXmSnYFiKxthWMrcfyD(m.hexdigest())
 def CheckQuality(kJweEUzCRBodXmSnYFiKxthWMrcfPg,sel_qt,qt_list):
  kJweEUzCRBodXmSnYFiKxthWMrcfPs=0
  for kJweEUzCRBodXmSnYFiKxthWMrcfPN in qt_list:
   if sel_qt>=kJweEUzCRBodXmSnYFiKxthWMrcfPN:return kJweEUzCRBodXmSnYFiKxthWMrcfPN
   kJweEUzCRBodXmSnYFiKxthWMrcfPs=kJweEUzCRBodXmSnYFiKxthWMrcfPN
  return kJweEUzCRBodXmSnYFiKxthWMrcfPs
 def Get_Now_Datetime(kJweEUzCRBodXmSnYFiKxthWMrcfPg):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(kJweEUzCRBodXmSnYFiKxthWMrcfPg,in_text):
  kJweEUzCRBodXmSnYFiKxthWMrcfPb=in_text.replace('&lt;','<').replace('&gt;','>')
  kJweEUzCRBodXmSnYFiKxthWMrcfPb=kJweEUzCRBodXmSnYFiKxthWMrcfPb.replace('<br>','\n')
  kJweEUzCRBodXmSnYFiKxthWMrcfPb=kJweEUzCRBodXmSnYFiKxthWMrcfPb.replace('$O$','')
  kJweEUzCRBodXmSnYFiKxthWMrcfPb=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',kJweEUzCRBodXmSnYFiKxthWMrcfPb)
  kJweEUzCRBodXmSnYFiKxthWMrcfPb=kJweEUzCRBodXmSnYFiKxthWMrcfPb.lstrip('#')
  return kJweEUzCRBodXmSnYFiKxthWMrcfPb
 def make_str_ToCookie(kJweEUzCRBodXmSnYFiKxthWMrcfPg,cookieStr):
  kJweEUzCRBodXmSnYFiKxthWMrcfPp={}
  for kJweEUzCRBodXmSnYFiKxthWMrcflP in cookieStr.split(';'):
   kJweEUzCRBodXmSnYFiKxthWMrcflD=kJweEUzCRBodXmSnYFiKxthWMrcflP.split('=')
   kJweEUzCRBodXmSnYFiKxthWMrcfPp[kJweEUzCRBodXmSnYFiKxthWMrcflD[0]]=kJweEUzCRBodXmSnYFiKxthWMrcflD[1]
  return kJweEUzCRBodXmSnYFiKxthWMrcfPp 
 def make_stream_header(kJweEUzCRBodXmSnYFiKxthWMrcfPg,kJweEUzCRBodXmSnYFiKxthWMrcfly,kJweEUzCRBodXmSnYFiKxthWMrcfPp):
  kJweEUzCRBodXmSnYFiKxthWMrcflg=''
  if kJweEUzCRBodXmSnYFiKxthWMrcfPp not in[{},kJweEUzCRBodXmSnYFiKxthWMrcfGu,'']:
   kJweEUzCRBodXmSnYFiKxthWMrcflO=kJweEUzCRBodXmSnYFiKxthWMrcfyg(kJweEUzCRBodXmSnYFiKxthWMrcfPp)
   for kJweEUzCRBodXmSnYFiKxthWMrcflH,kJweEUzCRBodXmSnYFiKxthWMrcflG in kJweEUzCRBodXmSnYFiKxthWMrcfPp.items():
    kJweEUzCRBodXmSnYFiKxthWMrcflg+='{}={}'.format(kJweEUzCRBodXmSnYFiKxthWMrcflH,kJweEUzCRBodXmSnYFiKxthWMrcflG)
    kJweEUzCRBodXmSnYFiKxthWMrcflO+=-1
    if kJweEUzCRBodXmSnYFiKxthWMrcflO>0:kJweEUzCRBodXmSnYFiKxthWMrcflg+='; '
   kJweEUzCRBodXmSnYFiKxthWMrcfly['cookie']=kJweEUzCRBodXmSnYFiKxthWMrcflg
  kJweEUzCRBodXmSnYFiKxthWMrcflQ=''
  i=0
  for kJweEUzCRBodXmSnYFiKxthWMrcflH,kJweEUzCRBodXmSnYFiKxthWMrcflG in kJweEUzCRBodXmSnYFiKxthWMrcfly.items():
   i=i+1
   if i>1:kJweEUzCRBodXmSnYFiKxthWMrcflQ+='&'
   kJweEUzCRBodXmSnYFiKxthWMrcflQ+='{}={}'.format(kJweEUzCRBodXmSnYFiKxthWMrcflH,urllib.parse.quote(kJweEUzCRBodXmSnYFiKxthWMrcflG))
  return kJweEUzCRBodXmSnYFiKxthWMrcflQ
 def GetCredential(kJweEUzCRBodXmSnYFiKxthWMrcfPg,user_id,user_pw,user_pf):
  kJweEUzCRBodXmSnYFiKxthWMrcflA=kJweEUzCRBodXmSnYFiKxthWMrcfGb
  try:
   kJweEUzCRBodXmSnYFiKxthWMrcflq=kJweEUzCRBodXmSnYFiKxthWMrcfPg.API_DOMAIN+ '/login'
   kJweEUzCRBodXmSnYFiKxthWMrcfPL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.GetDefaultParams(login=kJweEUzCRBodXmSnYFiKxthWMrcfGb)
   kJweEUzCRBodXmSnYFiKxthWMrcflT={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   kJweEUzCRBodXmSnYFiKxthWMrcflL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.callRequestCookies('Post',kJweEUzCRBodXmSnYFiKxthWMrcflq,payload=kJweEUzCRBodXmSnYFiKxthWMrcflT,params=kJweEUzCRBodXmSnYFiKxthWMrcfPL,headers=kJweEUzCRBodXmSnYFiKxthWMrcfGu,cookies=kJweEUzCRBodXmSnYFiKxthWMrcfGu)
   kJweEUzCRBodXmSnYFiKxthWMrcflV=json.loads(kJweEUzCRBodXmSnYFiKxthWMrcflL.text)
   kJweEUzCRBodXmSnYFiKxthWMrcfPg.WV['cookies']['credential']=kJweEUzCRBodXmSnYFiKxthWMrcflV['credential']
   if user_pf!=0:
    kJweEUzCRBodXmSnYFiKxthWMrcflT={'id':kJweEUzCRBodXmSnYFiKxthWMrcfPg.WV['cookies']['credential'],'password':'','profile':kJweEUzCRBodXmSnYFiKxthWMrcfyD(user_pf),'pushid':'','type':'credential'}
    kJweEUzCRBodXmSnYFiKxthWMrcfPL =kJweEUzCRBodXmSnYFiKxthWMrcfPg.GetDefaultParams(login=kJweEUzCRBodXmSnYFiKxthWMrcfyP) 
    kJweEUzCRBodXmSnYFiKxthWMrcflL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.callRequestCookies('Post',kJweEUzCRBodXmSnYFiKxthWMrcflq,payload=kJweEUzCRBodXmSnYFiKxthWMrcflT,params=kJweEUzCRBodXmSnYFiKxthWMrcfPL,headers=kJweEUzCRBodXmSnYFiKxthWMrcfGu,cookies=kJweEUzCRBodXmSnYFiKxthWMrcfGu)
    kJweEUzCRBodXmSnYFiKxthWMrcflV=json.loads(kJweEUzCRBodXmSnYFiKxthWMrcflL.text)
    kJweEUzCRBodXmSnYFiKxthWMrcfPg.WV['cookies']['credential']=kJweEUzCRBodXmSnYFiKxthWMrcflV['credential']
   kJweEUzCRBodXmSnYFiKxthWMrcfla=user_id+kJweEUzCRBodXmSnYFiKxthWMrcfyD(user_pf) 
   kJweEUzCRBodXmSnYFiKxthWMrcfPg.WV['cookies']['uuid']=kJweEUzCRBodXmSnYFiKxthWMrcfPg.GetGUID(guid_str=kJweEUzCRBodXmSnYFiKxthWMrcfla,guidType=3)
   kJweEUzCRBodXmSnYFiKxthWMrcflA=kJweEUzCRBodXmSnYFiKxthWMrcfyP
  except kJweEUzCRBodXmSnYFiKxthWMrcfyO as exception:
   kJweEUzCRBodXmSnYFiKxthWMrcfyH(exception)
   kJweEUzCRBodXmSnYFiKxthWMrcfPg.Init_WV_Total()
  return kJweEUzCRBodXmSnYFiKxthWMrcflA
 def GetIssue(kJweEUzCRBodXmSnYFiKxthWMrcfPg):
  kJweEUzCRBodXmSnYFiKxthWMrcflj=kJweEUzCRBodXmSnYFiKxthWMrcfGb
  try:
   kJweEUzCRBodXmSnYFiKxthWMrcflq=kJweEUzCRBodXmSnYFiKxthWMrcfPg.API_DOMAIN+'/guid/issue'
   kJweEUzCRBodXmSnYFiKxthWMrcfPL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.GetDefaultParams()
   kJweEUzCRBodXmSnYFiKxthWMrcflL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.callRequestCookies('Get',kJweEUzCRBodXmSnYFiKxthWMrcflq,payload=kJweEUzCRBodXmSnYFiKxthWMrcfGu,params=kJweEUzCRBodXmSnYFiKxthWMrcfPL,headers=kJweEUzCRBodXmSnYFiKxthWMrcfGu,cookies=kJweEUzCRBodXmSnYFiKxthWMrcfGu)
   kJweEUzCRBodXmSnYFiKxthWMrcflV=json.loads(kJweEUzCRBodXmSnYFiKxthWMrcflL.text)
   kJweEUzCRBodXmSnYFiKxthWMrcflv=kJweEUzCRBodXmSnYFiKxthWMrcflV['guid']
   kJweEUzCRBodXmSnYFiKxthWMrcflI=kJweEUzCRBodXmSnYFiKxthWMrcflV['guidtimestamp']
   if kJweEUzCRBodXmSnYFiKxthWMrcflv:kJweEUzCRBodXmSnYFiKxthWMrcflj=kJweEUzCRBodXmSnYFiKxthWMrcfyP
  except kJweEUzCRBodXmSnYFiKxthWMrcfyO as exception:
   kJweEUzCRBodXmSnYFiKxthWMrcfyH(exception)
   kJweEUzCRBodXmSnYFiKxthWMrcflv='none'
   kJweEUzCRBodXmSnYFiKxthWMrcflI='none' 
  kJweEUzCRBodXmSnYFiKxthWMrcfPg.guid=kJweEUzCRBodXmSnYFiKxthWMrcflv
  kJweEUzCRBodXmSnYFiKxthWMrcfPg.guidtimestamp=kJweEUzCRBodXmSnYFiKxthWMrcflI
  return kJweEUzCRBodXmSnYFiKxthWMrcflj
 def Baseapi_Parse(kJweEUzCRBodXmSnYFiKxthWMrcfPg,kJweEUzCRBodXmSnYFiKxthWMrcflb):
  try:
   kJweEUzCRBodXmSnYFiKxthWMrcfls =urllib.parse.urlsplit(kJweEUzCRBodXmSnYFiKxthWMrcflb)
   if kJweEUzCRBodXmSnYFiKxthWMrcfls.netloc=='':
    kJweEUzCRBodXmSnYFiKxthWMrcflq=kJweEUzCRBodXmSnYFiKxthWMrcfPg.HTTPTAG+kJweEUzCRBodXmSnYFiKxthWMrcfls.netloc+kJweEUzCRBodXmSnYFiKxthWMrcfls.path
   else:
    kJweEUzCRBodXmSnYFiKxthWMrcflq=kJweEUzCRBodXmSnYFiKxthWMrcfls.scheme+'://'+kJweEUzCRBodXmSnYFiKxthWMrcfls.netloc+kJweEUzCRBodXmSnYFiKxthWMrcfls.path
   kJweEUzCRBodXmSnYFiKxthWMrcfPL=kJweEUzCRBodXmSnYFiKxthWMrcfyG(urllib.parse.parse_qsl(kJweEUzCRBodXmSnYFiKxthWMrcfls.query))
  except kJweEUzCRBodXmSnYFiKxthWMrcfyO as exception:
   kJweEUzCRBodXmSnYFiKxthWMrcfyH(exception)
   return '',{}
  return kJweEUzCRBodXmSnYFiKxthWMrcflq,kJweEUzCRBodXmSnYFiKxthWMrcfPL
 def GetSupermultiUrl(kJweEUzCRBodXmSnYFiKxthWMrcfPg,sCode,sIndex='0'):
  try:
   kJweEUzCRBodXmSnYFiKxthWMrcflq=kJweEUzCRBodXmSnYFiKxthWMrcfPg.API_DOMAIN+'/cf/supermultisections/'+sCode
   kJweEUzCRBodXmSnYFiKxthWMrcfPL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.GetDefaultParams(login=kJweEUzCRBodXmSnYFiKxthWMrcfGb)
   kJweEUzCRBodXmSnYFiKxthWMrcflL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.callRequestCookies('Get',kJweEUzCRBodXmSnYFiKxthWMrcflq,payload=kJweEUzCRBodXmSnYFiKxthWMrcfGu,params=kJweEUzCRBodXmSnYFiKxthWMrcfPL,headers=kJweEUzCRBodXmSnYFiKxthWMrcfGu,cookies=kJweEUzCRBodXmSnYFiKxthWMrcfGu)
   kJweEUzCRBodXmSnYFiKxthWMrcflV=json.loads(kJweEUzCRBodXmSnYFiKxthWMrcflL.text)
   kJweEUzCRBodXmSnYFiKxthWMrcflN=kJweEUzCRBodXmSnYFiKxthWMrcflV['multisectionlist'][kJweEUzCRBodXmSnYFiKxthWMrcfyQ(sIndex)]['eventlist'][1]['url']
  except kJweEUzCRBodXmSnYFiKxthWMrcfyO as exception:
   kJweEUzCRBodXmSnYFiKxthWMrcfyH(exception)
   return ''
  return kJweEUzCRBodXmSnYFiKxthWMrcflN
 def Get_LiveCatagory_List(kJweEUzCRBodXmSnYFiKxthWMrcfPg,sCode,sIndex='0'):
  kJweEUzCRBodXmSnYFiKxthWMrcflu=[]
  kJweEUzCRBodXmSnYFiKxthWMrcflb =kJweEUzCRBodXmSnYFiKxthWMrcfPg.GetSupermultiUrl(sCode,sIndex)
  (kJweEUzCRBodXmSnYFiKxthWMrcflq,kJweEUzCRBodXmSnYFiKxthWMrcfPL)=kJweEUzCRBodXmSnYFiKxthWMrcfPg.Baseapi_Parse(kJweEUzCRBodXmSnYFiKxthWMrcflb)
  if kJweEUzCRBodXmSnYFiKxthWMrcflq=='':return kJweEUzCRBodXmSnYFiKxthWMrcflu,''
  try:
   kJweEUzCRBodXmSnYFiKxthWMrcfPL.update(kJweEUzCRBodXmSnYFiKxthWMrcfPg.GetDefaultParams(login=kJweEUzCRBodXmSnYFiKxthWMrcfGb))
   kJweEUzCRBodXmSnYFiKxthWMrcflL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.callRequestCookies('Get',kJweEUzCRBodXmSnYFiKxthWMrcflq,payload=kJweEUzCRBodXmSnYFiKxthWMrcfGu,params=kJweEUzCRBodXmSnYFiKxthWMrcfPL,headers=kJweEUzCRBodXmSnYFiKxthWMrcfGu,cookies=kJweEUzCRBodXmSnYFiKxthWMrcfGu)
   kJweEUzCRBodXmSnYFiKxthWMrcflV=json.loads(kJweEUzCRBodXmSnYFiKxthWMrcflL.text)
   if not('filter_item_list' in kJweEUzCRBodXmSnYFiKxthWMrcflV['filter']['filterlist'][0]):return[],''
   kJweEUzCRBodXmSnYFiKxthWMrcfDP=kJweEUzCRBodXmSnYFiKxthWMrcflV['filter']['filterlist'][0]['filter_item_list']
   for kJweEUzCRBodXmSnYFiKxthWMrcfDl in kJweEUzCRBodXmSnYFiKxthWMrcfDP:
    kJweEUzCRBodXmSnYFiKxthWMrcfDg={'title':kJweEUzCRBodXmSnYFiKxthWMrcfDl['title'],'genre':kJweEUzCRBodXmSnYFiKxthWMrcfDl['api_parameters'][kJweEUzCRBodXmSnYFiKxthWMrcfDl['api_parameters'].index('=')+1:]}
    kJweEUzCRBodXmSnYFiKxthWMrcflu.append(kJweEUzCRBodXmSnYFiKxthWMrcfDg)
  except kJweEUzCRBodXmSnYFiKxthWMrcfyO as exception:
   kJweEUzCRBodXmSnYFiKxthWMrcfyH(exception)
   return[],''
  return kJweEUzCRBodXmSnYFiKxthWMrcflu,kJweEUzCRBodXmSnYFiKxthWMrcflb
 def Get_MainCatagory_List(kJweEUzCRBodXmSnYFiKxthWMrcfPg,sCode,sIndex,sType):
  kJweEUzCRBodXmSnYFiKxthWMrcflu=[]
  kJweEUzCRBodXmSnYFiKxthWMrcflq='https://apis.wavve.com/es/category/launcher-band'
  kJweEUzCRBodXmSnYFiKxthWMrcfPL={'uitype':sCode,'uiparent':'GN52-'+sCode,'uirank':sIndex,'broadcastid':sCode,'offset':'0','limit':'20','uicode':sCode,'mtype':'N','ctype':sType,'orderby':'default',}
  try:
   kJweEUzCRBodXmSnYFiKxthWMrcfPL.update(kJweEUzCRBodXmSnYFiKxthWMrcfPg.GetDefaultParams(login=kJweEUzCRBodXmSnYFiKxthWMrcfGb))
   kJweEUzCRBodXmSnYFiKxthWMrcflL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.callRequestCookies('Get',kJweEUzCRBodXmSnYFiKxthWMrcflq,payload=kJweEUzCRBodXmSnYFiKxthWMrcfGu,params=kJweEUzCRBodXmSnYFiKxthWMrcfPL,headers=kJweEUzCRBodXmSnYFiKxthWMrcfGu,cookies=kJweEUzCRBodXmSnYFiKxthWMrcfGu)
   kJweEUzCRBodXmSnYFiKxthWMrcflV=json.loads(kJweEUzCRBodXmSnYFiKxthWMrcflL.text)
   if not('celllist' in kJweEUzCRBodXmSnYFiKxthWMrcflV['band']):return[]
   kJweEUzCRBodXmSnYFiKxthWMrcfDP=kJweEUzCRBodXmSnYFiKxthWMrcflV['band']['celllist']
   for kJweEUzCRBodXmSnYFiKxthWMrcfDl in kJweEUzCRBodXmSnYFiKxthWMrcfDP:
    kJweEUzCRBodXmSnYFiKxthWMrcfDO =kJweEUzCRBodXmSnYFiKxthWMrcfDl['event_list'][1]['url']
    (kJweEUzCRBodXmSnYFiKxthWMrcfDH,kJweEUzCRBodXmSnYFiKxthWMrcfDG)=kJweEUzCRBodXmSnYFiKxthWMrcfPg.Baseapi_Parse(kJweEUzCRBodXmSnYFiKxthWMrcfDO)
    kJweEUzCRBodXmSnYFiKxthWMrcfDg={'title':kJweEUzCRBodXmSnYFiKxthWMrcfDl['title_list'][0]['text'],'suburl':kJweEUzCRBodXmSnYFiKxthWMrcfDH,'subapi':kJweEUzCRBodXmSnYFiKxthWMrcfDG.get('api'),'subtype':'catagory' if kJweEUzCRBodXmSnYFiKxthWMrcfDG else 'supersection'}
    kJweEUzCRBodXmSnYFiKxthWMrcflu.append(kJweEUzCRBodXmSnYFiKxthWMrcfDg)
  except kJweEUzCRBodXmSnYFiKxthWMrcfyO as exception:
   kJweEUzCRBodXmSnYFiKxthWMrcfyH(exception)
   return[]
  return kJweEUzCRBodXmSnYFiKxthWMrcflu
 def Get_SuperMultiSection_List(kJweEUzCRBodXmSnYFiKxthWMrcfPg,subapi_text):
  kJweEUzCRBodXmSnYFiKxthWMrcflu=[]
  if '/multiband/' in subapi_text: 
   kJweEUzCRBodXmSnYFiKxthWMrcflq=subapi_text 
   kJweEUzCRBodXmSnYFiKxthWMrcfPL={'client':'40'}
  else:
   kJweEUzCRBodXmSnYFiKxthWMrcflq=subapi_text 
   kJweEUzCRBodXmSnYFiKxthWMrcflq=kJweEUzCRBodXmSnYFiKxthWMrcflq.replace('www.wavve.com','apis.wavve.com').replace('supermultisection','v1/multiband')
   kJweEUzCRBodXmSnYFiKxthWMrcfPL={}
  try:
   kJweEUzCRBodXmSnYFiKxthWMrcfPL.update(kJweEUzCRBodXmSnYFiKxthWMrcfPg.GetDefaultParams(login=kJweEUzCRBodXmSnYFiKxthWMrcfGb))
   kJweEUzCRBodXmSnYFiKxthWMrcflL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.callRequestCookies('Get',kJweEUzCRBodXmSnYFiKxthWMrcflq,payload=kJweEUzCRBodXmSnYFiKxthWMrcfGu,params=kJweEUzCRBodXmSnYFiKxthWMrcfPL,headers=kJweEUzCRBodXmSnYFiKxthWMrcfGu,cookies=kJweEUzCRBodXmSnYFiKxthWMrcfGu)
   kJweEUzCRBodXmSnYFiKxthWMrcflV=json.loads(kJweEUzCRBodXmSnYFiKxthWMrcflL.text)
   if not('multisectionlist' in kJweEUzCRBodXmSnYFiKxthWMrcflV):return[]
   kJweEUzCRBodXmSnYFiKxthWMrcfDP=kJweEUzCRBodXmSnYFiKxthWMrcflV['multisectionlist']
   for kJweEUzCRBodXmSnYFiKxthWMrcfDl in kJweEUzCRBodXmSnYFiKxthWMrcfDP:
    kJweEUzCRBodXmSnYFiKxthWMrcfDy=kJweEUzCRBodXmSnYFiKxthWMrcfDl['title']
    if kJweEUzCRBodXmSnYFiKxthWMrcfyg(kJweEUzCRBodXmSnYFiKxthWMrcfDy)==0:continue
    if kJweEUzCRBodXmSnYFiKxthWMrcfDy=='minor':continue
    if re.search(u'베너',kJweEUzCRBodXmSnYFiKxthWMrcfDy):continue
    if re.search(u'배너',kJweEUzCRBodXmSnYFiKxthWMrcfDy):continue 
    if kJweEUzCRBodXmSnYFiKxthWMrcfDl['force_refresh']=='y':continue
    if kJweEUzCRBodXmSnYFiKxthWMrcfyg(kJweEUzCRBodXmSnYFiKxthWMrcfDl['eventlist'])>=3:
     kJweEUzCRBodXmSnYFiKxthWMrcfDG =kJweEUzCRBodXmSnYFiKxthWMrcfDl['eventlist'][2]['url']
    else:
     kJweEUzCRBodXmSnYFiKxthWMrcfDG =kJweEUzCRBodXmSnYFiKxthWMrcfDl['eventlist'][1]['url']
    kJweEUzCRBodXmSnYFiKxthWMrcfDQ=kJweEUzCRBodXmSnYFiKxthWMrcfDl['cell_type']
    if kJweEUzCRBodXmSnYFiKxthWMrcfDQ=='band_2':
     if kJweEUzCRBodXmSnYFiKxthWMrcfDG.find('channellist=')>=0:
      kJweEUzCRBodXmSnYFiKxthWMrcfDQ='band_live'
    kJweEUzCRBodXmSnYFiKxthWMrcfDg={'title':kJweEUzCRBodXmSnYFiKxthWMrcfPg.Get_ChangeText(kJweEUzCRBodXmSnYFiKxthWMrcfDy),'subapi':kJweEUzCRBodXmSnYFiKxthWMrcfDG,'cell_type':kJweEUzCRBodXmSnYFiKxthWMrcfDQ}
    kJweEUzCRBodXmSnYFiKxthWMrcflu.append(kJweEUzCRBodXmSnYFiKxthWMrcfDg)
  except kJweEUzCRBodXmSnYFiKxthWMrcfyO as exception:
   kJweEUzCRBodXmSnYFiKxthWMrcfyH(exception)
   return[]
  return kJweEUzCRBodXmSnYFiKxthWMrcflu
 def Get_BandLiveSection_List(kJweEUzCRBodXmSnYFiKxthWMrcfPg,kJweEUzCRBodXmSnYFiKxthWMrcflb,page_int=1):
  kJweEUzCRBodXmSnYFiKxthWMrcfDA=[]
  kJweEUzCRBodXmSnYFiKxthWMrcfDq=kJweEUzCRBodXmSnYFiKxthWMrcfDv=1
  kJweEUzCRBodXmSnYFiKxthWMrcfDT=kJweEUzCRBodXmSnYFiKxthWMrcfGb
  try:
   (kJweEUzCRBodXmSnYFiKxthWMrcflq,kJweEUzCRBodXmSnYFiKxthWMrcfPL)=kJweEUzCRBodXmSnYFiKxthWMrcfPg.Baseapi_Parse(kJweEUzCRBodXmSnYFiKxthWMrcflb)
  except kJweEUzCRBodXmSnYFiKxthWMrcfyO as exception:
   kJweEUzCRBodXmSnYFiKxthWMrcfyH(exception)
   return[],kJweEUzCRBodXmSnYFiKxthWMrcfGb
  try:
   kJweEUzCRBodXmSnYFiKxthWMrcfPL['limit']=kJweEUzCRBodXmSnYFiKxthWMrcfPg.LIST_LIMIT
   kJweEUzCRBodXmSnYFiKxthWMrcfPL['offset']=kJweEUzCRBodXmSnYFiKxthWMrcfyD((page_int-1)*kJweEUzCRBodXmSnYFiKxthWMrcfPg.LIST_LIMIT)
   kJweEUzCRBodXmSnYFiKxthWMrcfPL.update(kJweEUzCRBodXmSnYFiKxthWMrcfPg.GetDefaultParams(login=kJweEUzCRBodXmSnYFiKxthWMrcfGb))
   kJweEUzCRBodXmSnYFiKxthWMrcflL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.callRequestCookies('Get',kJweEUzCRBodXmSnYFiKxthWMrcflq,payload=kJweEUzCRBodXmSnYFiKxthWMrcfGu,params=kJweEUzCRBodXmSnYFiKxthWMrcfPL,headers=kJweEUzCRBodXmSnYFiKxthWMrcfGu,cookies=kJweEUzCRBodXmSnYFiKxthWMrcfGu)
   kJweEUzCRBodXmSnYFiKxthWMrcflV=json.loads(kJweEUzCRBodXmSnYFiKxthWMrcflL.text)
   if not('celllist' in kJweEUzCRBodXmSnYFiKxthWMrcflV['cell_toplist']):return[],kJweEUzCRBodXmSnYFiKxthWMrcfGb
   kJweEUzCRBodXmSnYFiKxthWMrcfDP=kJweEUzCRBodXmSnYFiKxthWMrcflV['cell_toplist']['celllist']
   for kJweEUzCRBodXmSnYFiKxthWMrcfDl in kJweEUzCRBodXmSnYFiKxthWMrcfDP:
    kJweEUzCRBodXmSnYFiKxthWMrcfDL =kJweEUzCRBodXmSnYFiKxthWMrcfDl['event_list'][1]['url']
    kJweEUzCRBodXmSnYFiKxthWMrcfDV=urllib.parse.urlsplit(kJweEUzCRBodXmSnYFiKxthWMrcfDL).query
    kJweEUzCRBodXmSnYFiKxthWMrcfDV=kJweEUzCRBodXmSnYFiKxthWMrcfyG(urllib.parse.parse_qsl(kJweEUzCRBodXmSnYFiKxthWMrcfDV))
    kJweEUzCRBodXmSnYFiKxthWMrcfDa='channelid'
    kJweEUzCRBodXmSnYFiKxthWMrcfDj=kJweEUzCRBodXmSnYFiKxthWMrcfDV[kJweEUzCRBodXmSnYFiKxthWMrcfDa]
    kJweEUzCRBodXmSnYFiKxthWMrcfDg={'studio':kJweEUzCRBodXmSnYFiKxthWMrcfDl['title_list'][0]['text'],'tvshowtitle':kJweEUzCRBodXmSnYFiKxthWMrcfPg.Get_ChangeText(kJweEUzCRBodXmSnYFiKxthWMrcfDl['title_list'][1]['text']),'channelid':kJweEUzCRBodXmSnYFiKxthWMrcfDj,'age':kJweEUzCRBodXmSnYFiKxthWMrcfDl.get('age'),'thumbnail':'https://%s'%kJweEUzCRBodXmSnYFiKxthWMrcfDl.get('thumbnail')}
    kJweEUzCRBodXmSnYFiKxthWMrcfDA.append(kJweEUzCRBodXmSnYFiKxthWMrcfDg)
   kJweEUzCRBodXmSnYFiKxthWMrcfDq=kJweEUzCRBodXmSnYFiKxthWMrcfyQ(kJweEUzCRBodXmSnYFiKxthWMrcflV['cell_toplist']['pagecount'])
   if kJweEUzCRBodXmSnYFiKxthWMrcflV['cell_toplist']['count']:kJweEUzCRBodXmSnYFiKxthWMrcfDv =kJweEUzCRBodXmSnYFiKxthWMrcfyQ(kJweEUzCRBodXmSnYFiKxthWMrcflV['cell_toplist']['count'])
   else:kJweEUzCRBodXmSnYFiKxthWMrcfDv=kJweEUzCRBodXmSnYFiKxthWMrcfPg.LIST_LIMIT*page_int
   kJweEUzCRBodXmSnYFiKxthWMrcfDT=kJweEUzCRBodXmSnYFiKxthWMrcfDq>kJweEUzCRBodXmSnYFiKxthWMrcfDv
  except kJweEUzCRBodXmSnYFiKxthWMrcfyO as exception:
   kJweEUzCRBodXmSnYFiKxthWMrcfyH(exception)
   return[],kJweEUzCRBodXmSnYFiKxthWMrcfGb
  return kJweEUzCRBodXmSnYFiKxthWMrcfDA,kJweEUzCRBodXmSnYFiKxthWMrcfDT
 def Get_Band2Section_List(kJweEUzCRBodXmSnYFiKxthWMrcfPg,kJweEUzCRBodXmSnYFiKxthWMrcflb,page_int=1):
  kJweEUzCRBodXmSnYFiKxthWMrcfDI=[]
  kJweEUzCRBodXmSnYFiKxthWMrcfDq=kJweEUzCRBodXmSnYFiKxthWMrcfDv=1
  kJweEUzCRBodXmSnYFiKxthWMrcfDT=kJweEUzCRBodXmSnYFiKxthWMrcfGb
  try:
   (kJweEUzCRBodXmSnYFiKxthWMrcflq,kJweEUzCRBodXmSnYFiKxthWMrcfPL)=kJweEUzCRBodXmSnYFiKxthWMrcfPg.Baseapi_Parse(kJweEUzCRBodXmSnYFiKxthWMrcflb)
  except kJweEUzCRBodXmSnYFiKxthWMrcfyO as exception:
   kJweEUzCRBodXmSnYFiKxthWMrcfyH(exception)
   return[],kJweEUzCRBodXmSnYFiKxthWMrcfGb
  try:
   kJweEUzCRBodXmSnYFiKxthWMrcfPL['came'] ='BandView'
   kJweEUzCRBodXmSnYFiKxthWMrcfPL['limit']=kJweEUzCRBodXmSnYFiKxthWMrcfPg.LIST_LIMIT
   kJweEUzCRBodXmSnYFiKxthWMrcfPL['offset']=kJweEUzCRBodXmSnYFiKxthWMrcfyD((page_int-1)*kJweEUzCRBodXmSnYFiKxthWMrcfPg.LIST_LIMIT)
   kJweEUzCRBodXmSnYFiKxthWMrcfPL.update(kJweEUzCRBodXmSnYFiKxthWMrcfPg.GetDefaultParams(login=kJweEUzCRBodXmSnYFiKxthWMrcfGb))
   kJweEUzCRBodXmSnYFiKxthWMrcflL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.callRequestCookies('Get',kJweEUzCRBodXmSnYFiKxthWMrcflq,payload=kJweEUzCRBodXmSnYFiKxthWMrcfGu,params=kJweEUzCRBodXmSnYFiKxthWMrcfPL,headers=kJweEUzCRBodXmSnYFiKxthWMrcfGu,cookies=kJweEUzCRBodXmSnYFiKxthWMrcfGu)
   kJweEUzCRBodXmSnYFiKxthWMrcflV=json.loads(kJweEUzCRBodXmSnYFiKxthWMrcflL.text)
   if not('celllist' in kJweEUzCRBodXmSnYFiKxthWMrcflV['cell_toplist']):return[],kJweEUzCRBodXmSnYFiKxthWMrcfGb
   kJweEUzCRBodXmSnYFiKxthWMrcfDP=kJweEUzCRBodXmSnYFiKxthWMrcflV['cell_toplist']['celllist']
   for kJweEUzCRBodXmSnYFiKxthWMrcfDl in kJweEUzCRBodXmSnYFiKxthWMrcfDP:
    kJweEUzCRBodXmSnYFiKxthWMrcfDL =kJweEUzCRBodXmSnYFiKxthWMrcfDl['event_list'][1]['url']
    kJweEUzCRBodXmSnYFiKxthWMrcfDV=urllib.parse.urlsplit(kJweEUzCRBodXmSnYFiKxthWMrcfDL).query
    kJweEUzCRBodXmSnYFiKxthWMrcfDV=kJweEUzCRBodXmSnYFiKxthWMrcfyG(urllib.parse.parse_qsl(kJweEUzCRBodXmSnYFiKxthWMrcfDV))
    kJweEUzCRBodXmSnYFiKxthWMrcfDa='contentid'
    kJweEUzCRBodXmSnYFiKxthWMrcfDj=kJweEUzCRBodXmSnYFiKxthWMrcfDV[kJweEUzCRBodXmSnYFiKxthWMrcfDa]
    kJweEUzCRBodXmSnYFiKxthWMrcfDg={'programtitle':kJweEUzCRBodXmSnYFiKxthWMrcfDl['title_list'][0]['text'],'episodetitle':kJweEUzCRBodXmSnYFiKxthWMrcfPg.Get_ChangeText(kJweEUzCRBodXmSnYFiKxthWMrcfDl['title_list'][1]['text']),'age':kJweEUzCRBodXmSnYFiKxthWMrcfDl.get('age'),'thumbnail':kJweEUzCRBodXmSnYFiKxthWMrcfPg.HTTPTAG+kJweEUzCRBodXmSnYFiKxthWMrcfDl.get('thumbnail'),'vidtype':kJweEUzCRBodXmSnYFiKxthWMrcfDa,'videoid':kJweEUzCRBodXmSnYFiKxthWMrcfDj}
    kJweEUzCRBodXmSnYFiKxthWMrcfDI.append(kJweEUzCRBodXmSnYFiKxthWMrcfDg)
   kJweEUzCRBodXmSnYFiKxthWMrcfDq=kJweEUzCRBodXmSnYFiKxthWMrcfyQ(kJweEUzCRBodXmSnYFiKxthWMrcflV['cell_toplist']['pagecount'])
   if kJweEUzCRBodXmSnYFiKxthWMrcflV['cell_toplist']['count']:kJweEUzCRBodXmSnYFiKxthWMrcfDv =kJweEUzCRBodXmSnYFiKxthWMrcfyQ(kJweEUzCRBodXmSnYFiKxthWMrcflV['cell_toplist']['count'])
   else:kJweEUzCRBodXmSnYFiKxthWMrcfDv=kJweEUzCRBodXmSnYFiKxthWMrcfPg.LIST_LIMIT*page_int
   kJweEUzCRBodXmSnYFiKxthWMrcfDT=kJweEUzCRBodXmSnYFiKxthWMrcfDq>kJweEUzCRBodXmSnYFiKxthWMrcfDv
  except kJweEUzCRBodXmSnYFiKxthWMrcfyO as exception:
   kJweEUzCRBodXmSnYFiKxthWMrcfyH(exception)
   return[],kJweEUzCRBodXmSnYFiKxthWMrcfGb
  return kJweEUzCRBodXmSnYFiKxthWMrcfDI,kJweEUzCRBodXmSnYFiKxthWMrcfDT
 def Get_Program_List(kJweEUzCRBodXmSnYFiKxthWMrcfPg,kJweEUzCRBodXmSnYFiKxthWMrcflb,page_int=1,orderby='-'):
  kJweEUzCRBodXmSnYFiKxthWMrcfDs=[]
  kJweEUzCRBodXmSnYFiKxthWMrcfDq=kJweEUzCRBodXmSnYFiKxthWMrcfDv=1
  kJweEUzCRBodXmSnYFiKxthWMrcfDT=kJweEUzCRBodXmSnYFiKxthWMrcfGb
  (kJweEUzCRBodXmSnYFiKxthWMrcflq,kJweEUzCRBodXmSnYFiKxthWMrcfPL)=kJweEUzCRBodXmSnYFiKxthWMrcfPg.Baseapi_Parse(kJweEUzCRBodXmSnYFiKxthWMrcflb)
  if kJweEUzCRBodXmSnYFiKxthWMrcflq=='':return kJweEUzCRBodXmSnYFiKxthWMrcfDs,kJweEUzCRBodXmSnYFiKxthWMrcfDT
  try:
   kJweEUzCRBodXmSnYFiKxthWMrcfPL['limit'] =kJweEUzCRBodXmSnYFiKxthWMrcfPg.LIST_LIMIT
   kJweEUzCRBodXmSnYFiKxthWMrcfPL['offset']=kJweEUzCRBodXmSnYFiKxthWMrcfyD((page_int-1)*kJweEUzCRBodXmSnYFiKxthWMrcfPg.LIST_LIMIT)
   kJweEUzCRBodXmSnYFiKxthWMrcfPL['page'] =kJweEUzCRBodXmSnYFiKxthWMrcfyD(page_int)
   if kJweEUzCRBodXmSnYFiKxthWMrcfPL.get('orderby')!='' and kJweEUzCRBodXmSnYFiKxthWMrcfPL.get('orderby')!='regdatefirst' and orderby!='-':
    kJweEUzCRBodXmSnYFiKxthWMrcfPL['orderby']=orderby 
   kJweEUzCRBodXmSnYFiKxthWMrcfPL.update(kJweEUzCRBodXmSnYFiKxthWMrcfPg.GetDefaultParams(login=kJweEUzCRBodXmSnYFiKxthWMrcfGb))
   kJweEUzCRBodXmSnYFiKxthWMrcflL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.callRequestCookies('Get',kJweEUzCRBodXmSnYFiKxthWMrcflq,payload=kJweEUzCRBodXmSnYFiKxthWMrcfGu,params=kJweEUzCRBodXmSnYFiKxthWMrcfPL,headers=kJweEUzCRBodXmSnYFiKxthWMrcfGu,cookies=kJweEUzCRBodXmSnYFiKxthWMrcfGu)
   kJweEUzCRBodXmSnYFiKxthWMrcflV=json.loads(kJweEUzCRBodXmSnYFiKxthWMrcflL.text)
   if kJweEUzCRBodXmSnYFiKxthWMrcflV.get('cell_toplist')not in[{},kJweEUzCRBodXmSnYFiKxthWMrcfGu,'']:
    kJweEUzCRBodXmSnYFiKxthWMrcfDP=kJweEUzCRBodXmSnYFiKxthWMrcflV['cell_toplist']['celllist']
   elif kJweEUzCRBodXmSnYFiKxthWMrcflV.get('band')not in[{},kJweEUzCRBodXmSnYFiKxthWMrcfGu,'']:
    kJweEUzCRBodXmSnYFiKxthWMrcfDP=kJweEUzCRBodXmSnYFiKxthWMrcflV['band']['celllist']
   else:
    return kJweEUzCRBodXmSnYFiKxthWMrcfDs,kJweEUzCRBodXmSnYFiKxthWMrcfDT
   for kJweEUzCRBodXmSnYFiKxthWMrcfDl in kJweEUzCRBodXmSnYFiKxthWMrcfDP:
    for kJweEUzCRBodXmSnYFiKxthWMrcfDN in kJweEUzCRBodXmSnYFiKxthWMrcfDl['event_list']:
     if kJweEUzCRBodXmSnYFiKxthWMrcfDN.get('type')=='on-navigation':
      kJweEUzCRBodXmSnYFiKxthWMrcfDL =kJweEUzCRBodXmSnYFiKxthWMrcfDN['url']
    kJweEUzCRBodXmSnYFiKxthWMrcfDV=urllib.parse.urlsplit(kJweEUzCRBodXmSnYFiKxthWMrcfDL).query
    kJweEUzCRBodXmSnYFiKxthWMrcfDa=kJweEUzCRBodXmSnYFiKxthWMrcfDV[0:kJweEUzCRBodXmSnYFiKxthWMrcfDV.find('=')]
    kJweEUzCRBodXmSnYFiKxthWMrcfDu=kJweEUzCRBodXmSnYFiKxthWMrcfyG(urllib.parse.parse_qsl(kJweEUzCRBodXmSnYFiKxthWMrcfDV))
    kJweEUzCRBodXmSnYFiKxthWMrcfDj=kJweEUzCRBodXmSnYFiKxthWMrcfDu.get(kJweEUzCRBodXmSnYFiKxthWMrcfDa)
    kJweEUzCRBodXmSnYFiKxthWMrcfDg={'title':kJweEUzCRBodXmSnYFiKxthWMrcfDl.get('alt')or kJweEUzCRBodXmSnYFiKxthWMrcfDl.get('title_list')[0].get('text'),'age':kJweEUzCRBodXmSnYFiKxthWMrcfDl.get('age'),'thumbnail':kJweEUzCRBodXmSnYFiKxthWMrcfDl.get('thumbnail'),'videoid':kJweEUzCRBodXmSnYFiKxthWMrcfDj,'vidtype':kJweEUzCRBodXmSnYFiKxthWMrcfDa,}
    if not kJweEUzCRBodXmSnYFiKxthWMrcfDg.get('thumbnail').startswith('http'):
     kJweEUzCRBodXmSnYFiKxthWMrcfDg['thumbnail']='https://%s'%kJweEUzCRBodXmSnYFiKxthWMrcfDg['thumbnail']
    kJweEUzCRBodXmSnYFiKxthWMrcfDs.append(kJweEUzCRBodXmSnYFiKxthWMrcfDg)
   if kJweEUzCRBodXmSnYFiKxthWMrcflV.get('cell_toplist')not in[{},kJweEUzCRBodXmSnYFiKxthWMrcfGu,'']:
    kJweEUzCRBodXmSnYFiKxthWMrcfDq=kJweEUzCRBodXmSnYFiKxthWMrcfyQ(kJweEUzCRBodXmSnYFiKxthWMrcflV['cell_toplist']['pagecount'])
    if kJweEUzCRBodXmSnYFiKxthWMrcflV['cell_toplist']['count']:kJweEUzCRBodXmSnYFiKxthWMrcfDv =kJweEUzCRBodXmSnYFiKxthWMrcfyQ(kJweEUzCRBodXmSnYFiKxthWMrcflV['cell_toplist']['count'])
    else:kJweEUzCRBodXmSnYFiKxthWMrcfDv=kJweEUzCRBodXmSnYFiKxthWMrcfPg.LIST_LIMIT*page_int
    kJweEUzCRBodXmSnYFiKxthWMrcfDT=kJweEUzCRBodXmSnYFiKxthWMrcfDq>kJweEUzCRBodXmSnYFiKxthWMrcfDv
  except kJweEUzCRBodXmSnYFiKxthWMrcfyO as exception:
   kJweEUzCRBodXmSnYFiKxthWMrcfyH(exception)
   return[],kJweEUzCRBodXmSnYFiKxthWMrcfGb
  return kJweEUzCRBodXmSnYFiKxthWMrcfDs,kJweEUzCRBodXmSnYFiKxthWMrcfDT
 def Get_Movie_List(kJweEUzCRBodXmSnYFiKxthWMrcfPg,kJweEUzCRBodXmSnYFiKxthWMrcflb,page_int=1,orderby='-'):
  kJweEUzCRBodXmSnYFiKxthWMrcfDb=[]
  kJweEUzCRBodXmSnYFiKxthWMrcfDq=kJweEUzCRBodXmSnYFiKxthWMrcfDv=1
  kJweEUzCRBodXmSnYFiKxthWMrcfDT=kJweEUzCRBodXmSnYFiKxthWMrcfGb
  (kJweEUzCRBodXmSnYFiKxthWMrcflq,kJweEUzCRBodXmSnYFiKxthWMrcfPL)=kJweEUzCRBodXmSnYFiKxthWMrcfPg.Baseapi_Parse(kJweEUzCRBodXmSnYFiKxthWMrcflb)
  if kJweEUzCRBodXmSnYFiKxthWMrcflq=='':return kJweEUzCRBodXmSnYFiKxthWMrcfDb,kJweEUzCRBodXmSnYFiKxthWMrcfDT
  try:
   kJweEUzCRBodXmSnYFiKxthWMrcfPL['limit']=kJweEUzCRBodXmSnYFiKxthWMrcfPg.MV_LIMIT
   kJweEUzCRBodXmSnYFiKxthWMrcfPL['offset']=kJweEUzCRBodXmSnYFiKxthWMrcfyD((page_int-1)*kJweEUzCRBodXmSnYFiKxthWMrcfPg.MV_LIMIT)
   if kJweEUzCRBodXmSnYFiKxthWMrcfPL.get('orderby')!='' and kJweEUzCRBodXmSnYFiKxthWMrcfPL.get('orderby')!='regdatefirst' and orderby!='-':
    kJweEUzCRBodXmSnYFiKxthWMrcfPL['orderby']=orderby 
   kJweEUzCRBodXmSnYFiKxthWMrcfPL.update(kJweEUzCRBodXmSnYFiKxthWMrcfPg.GetDefaultParams(login=kJweEUzCRBodXmSnYFiKxthWMrcfGb))
   kJweEUzCRBodXmSnYFiKxthWMrcflL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.callRequestCookies('Get',kJweEUzCRBodXmSnYFiKxthWMrcflq,payload=kJweEUzCRBodXmSnYFiKxthWMrcfGu,params=kJweEUzCRBodXmSnYFiKxthWMrcfPL,headers=kJweEUzCRBodXmSnYFiKxthWMrcfGu,cookies=kJweEUzCRBodXmSnYFiKxthWMrcfGu)
   kJweEUzCRBodXmSnYFiKxthWMrcflV=json.loads(kJweEUzCRBodXmSnYFiKxthWMrcflL.text)
   if kJweEUzCRBodXmSnYFiKxthWMrcflV.get('cell_toplist')not in[{},kJweEUzCRBodXmSnYFiKxthWMrcfGu,'']:
    kJweEUzCRBodXmSnYFiKxthWMrcfDP=kJweEUzCRBodXmSnYFiKxthWMrcflV['cell_toplist']['celllist']
   elif kJweEUzCRBodXmSnYFiKxthWMrcflV.get('band')not in[{},kJweEUzCRBodXmSnYFiKxthWMrcfGu,'']:
    kJweEUzCRBodXmSnYFiKxthWMrcfDP=kJweEUzCRBodXmSnYFiKxthWMrcflV['band']['celllist']
   else:
    return kJweEUzCRBodXmSnYFiKxthWMrcfDb,kJweEUzCRBodXmSnYFiKxthWMrcfDT
   for kJweEUzCRBodXmSnYFiKxthWMrcfDl in kJweEUzCRBodXmSnYFiKxthWMrcfDP:
    kJweEUzCRBodXmSnYFiKxthWMrcfDL =kJweEUzCRBodXmSnYFiKxthWMrcfDl['event_list'][1]['url']
    kJweEUzCRBodXmSnYFiKxthWMrcfDV=urllib.parse.urlsplit(kJweEUzCRBodXmSnYFiKxthWMrcfDL).query
    kJweEUzCRBodXmSnYFiKxthWMrcfDa=kJweEUzCRBodXmSnYFiKxthWMrcfDV[0:kJweEUzCRBodXmSnYFiKxthWMrcfDV.find('=')]
    kJweEUzCRBodXmSnYFiKxthWMrcfDu=kJweEUzCRBodXmSnYFiKxthWMrcfyG(urllib.parse.parse_qsl(kJweEUzCRBodXmSnYFiKxthWMrcfDV))
    kJweEUzCRBodXmSnYFiKxthWMrcfDj=kJweEUzCRBodXmSnYFiKxthWMrcfDu.get(kJweEUzCRBodXmSnYFiKxthWMrcfDa)
    kJweEUzCRBodXmSnYFiKxthWMrcfDg={'title':kJweEUzCRBodXmSnYFiKxthWMrcfDl.get('alt')or kJweEUzCRBodXmSnYFiKxthWMrcfDl.get('title_list')[0].get('text'),'age':kJweEUzCRBodXmSnYFiKxthWMrcfDl.get('age'),'thumbnail':kJweEUzCRBodXmSnYFiKxthWMrcfDl.get('thumbnail'),'videoid':kJweEUzCRBodXmSnYFiKxthWMrcfDj,'vidtype':kJweEUzCRBodXmSnYFiKxthWMrcfDa,}
    if not kJweEUzCRBodXmSnYFiKxthWMrcfDg.get('thumbnail').startswith('http'):
     kJweEUzCRBodXmSnYFiKxthWMrcfDg['thumbnail']='https://%s'%kJweEUzCRBodXmSnYFiKxthWMrcfDg['thumbnail']
    kJweEUzCRBodXmSnYFiKxthWMrcfDb.append(kJweEUzCRBodXmSnYFiKxthWMrcfDg)
   if kJweEUzCRBodXmSnYFiKxthWMrcflV.get('cell_toplist')not in[{},kJweEUzCRBodXmSnYFiKxthWMrcfGu,'']:
    kJweEUzCRBodXmSnYFiKxthWMrcfDq=kJweEUzCRBodXmSnYFiKxthWMrcfyQ(kJweEUzCRBodXmSnYFiKxthWMrcflV['cell_toplist']['pagecount'])
    if kJweEUzCRBodXmSnYFiKxthWMrcflV['cell_toplist']['count']:kJweEUzCRBodXmSnYFiKxthWMrcfDv =kJweEUzCRBodXmSnYFiKxthWMrcfyQ(kJweEUzCRBodXmSnYFiKxthWMrcflV['cell_toplist']['count'])
    else:kJweEUzCRBodXmSnYFiKxthWMrcfDv=kJweEUzCRBodXmSnYFiKxthWMrcfPg.MV_LIMIT*page_int
    kJweEUzCRBodXmSnYFiKxthWMrcfDT=kJweEUzCRBodXmSnYFiKxthWMrcfDq>kJweEUzCRBodXmSnYFiKxthWMrcfDv
  except kJweEUzCRBodXmSnYFiKxthWMrcfyO as exception:
   kJweEUzCRBodXmSnYFiKxthWMrcfyH(exception)
   return[],kJweEUzCRBodXmSnYFiKxthWMrcfGb
  return kJweEUzCRBodXmSnYFiKxthWMrcfDb,kJweEUzCRBodXmSnYFiKxthWMrcfDT
 def ProgramidToContentid(kJweEUzCRBodXmSnYFiKxthWMrcfPg,kJweEUzCRBodXmSnYFiKxthWMrcfgl):
  kJweEUzCRBodXmSnYFiKxthWMrcfDp=''
  try:
   kJweEUzCRBodXmSnYFiKxthWMrcflq =kJweEUzCRBodXmSnYFiKxthWMrcfPg.API_DOMAIN+'/vod/programs-contentid/'+kJweEUzCRBodXmSnYFiKxthWMrcfgl
   kJweEUzCRBodXmSnYFiKxthWMrcfPL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.GetDefaultParams(login=kJweEUzCRBodXmSnYFiKxthWMrcfGb)
   kJweEUzCRBodXmSnYFiKxthWMrcflL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.callRequestCookies('Get',kJweEUzCRBodXmSnYFiKxthWMrcflq,payload=kJweEUzCRBodXmSnYFiKxthWMrcfGu,params=kJweEUzCRBodXmSnYFiKxthWMrcfPL,headers=kJweEUzCRBodXmSnYFiKxthWMrcfGu,cookies=kJweEUzCRBodXmSnYFiKxthWMrcfGu)
   kJweEUzCRBodXmSnYFiKxthWMrcfgP=json.loads(kJweEUzCRBodXmSnYFiKxthWMrcflL.text)
   if not('contentid' in kJweEUzCRBodXmSnYFiKxthWMrcfgP):return kJweEUzCRBodXmSnYFiKxthWMrcfDp 
   kJweEUzCRBodXmSnYFiKxthWMrcfDp=kJweEUzCRBodXmSnYFiKxthWMrcfgP['contentid']
  except kJweEUzCRBodXmSnYFiKxthWMrcfyO as exception:
   kJweEUzCRBodXmSnYFiKxthWMrcfyH(exception)
  return kJweEUzCRBodXmSnYFiKxthWMrcfDp
 def ContentidToSeasonid(kJweEUzCRBodXmSnYFiKxthWMrcfPg,kJweEUzCRBodXmSnYFiKxthWMrcfDp):
  kJweEUzCRBodXmSnYFiKxthWMrcfgl=''
  try:
   kJweEUzCRBodXmSnYFiKxthWMrcflq =kJweEUzCRBodXmSnYFiKxthWMrcfPg.API_DOMAIN+'/fz/vod/contents/'+kJweEUzCRBodXmSnYFiKxthWMrcfDp
   kJweEUzCRBodXmSnYFiKxthWMrcfPL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.GetDefaultParams(login=kJweEUzCRBodXmSnYFiKxthWMrcfGb)
   kJweEUzCRBodXmSnYFiKxthWMrcflL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.callRequestCookies('Get',kJweEUzCRBodXmSnYFiKxthWMrcflq,payload=kJweEUzCRBodXmSnYFiKxthWMrcfGu,params=kJweEUzCRBodXmSnYFiKxthWMrcfPL,headers=kJweEUzCRBodXmSnYFiKxthWMrcfGu,cookies=kJweEUzCRBodXmSnYFiKxthWMrcfGu)
   kJweEUzCRBodXmSnYFiKxthWMrcfgP=json.loads(kJweEUzCRBodXmSnYFiKxthWMrcflL.text)
   if not('programid' in kJweEUzCRBodXmSnYFiKxthWMrcfgP):return kJweEUzCRBodXmSnYFiKxthWMrcfgl 
   kJweEUzCRBodXmSnYFiKxthWMrcfgl=kJweEUzCRBodXmSnYFiKxthWMrcfgP['programid']
  except kJweEUzCRBodXmSnYFiKxthWMrcfyO as exception:
   kJweEUzCRBodXmSnYFiKxthWMrcfyH(exception)
  return kJweEUzCRBodXmSnYFiKxthWMrcfgl
 def GetProgramInfo(kJweEUzCRBodXmSnYFiKxthWMrcfPg,kJweEUzCRBodXmSnYFiKxthWMrcfDp):
  kJweEUzCRBodXmSnYFiKxthWMrcfgD={}
  try:
   kJweEUzCRBodXmSnYFiKxthWMrcflq=kJweEUzCRBodXmSnYFiKxthWMrcfPg.API_DOMAIN+'/fz/vod/contents/'+kJweEUzCRBodXmSnYFiKxthWMrcfDp
   kJweEUzCRBodXmSnYFiKxthWMrcfPL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.GetDefaultParams(login=kJweEUzCRBodXmSnYFiKxthWMrcfGb)
   kJweEUzCRBodXmSnYFiKxthWMrcflL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.callRequestCookies('Get',kJweEUzCRBodXmSnYFiKxthWMrcflq,payload=kJweEUzCRBodXmSnYFiKxthWMrcfGu,params=kJweEUzCRBodXmSnYFiKxthWMrcfPL,headers=kJweEUzCRBodXmSnYFiKxthWMrcfGu,cookies=kJweEUzCRBodXmSnYFiKxthWMrcfGu)
   kJweEUzCRBodXmSnYFiKxthWMrcfgP=json.loads(kJweEUzCRBodXmSnYFiKxthWMrcflL.text)
   kJweEUzCRBodXmSnYFiKxthWMrcfgO=img_fanart=kJweEUzCRBodXmSnYFiKxthWMrcfgH=''
   if kJweEUzCRBodXmSnYFiKxthWMrcfgP.get('programposterimage')!='':kJweEUzCRBodXmSnYFiKxthWMrcfgO =kJweEUzCRBodXmSnYFiKxthWMrcfPg.HTTPTAG+kJweEUzCRBodXmSnYFiKxthWMrcfgP.get('programposterimage')
   if kJweEUzCRBodXmSnYFiKxthWMrcfgP.get('programimage') !='':img_fanart =kJweEUzCRBodXmSnYFiKxthWMrcfPg.HTTPTAG+kJweEUzCRBodXmSnYFiKxthWMrcfgP.get('programimage')
   if kJweEUzCRBodXmSnYFiKxthWMrcfgP.get('programcircleimage')!='':kJweEUzCRBodXmSnYFiKxthWMrcfgH=kJweEUzCRBodXmSnYFiKxthWMrcfPg.HTTPTAG+kJweEUzCRBodXmSnYFiKxthWMrcfgP.get('programcircleimage')
   if 'poster_default' in kJweEUzCRBodXmSnYFiKxthWMrcfgO:
    kJweEUzCRBodXmSnYFiKxthWMrcfgO =img_fanart
    kJweEUzCRBodXmSnYFiKxthWMrcfgH=''
   kJweEUzCRBodXmSnYFiKxthWMrcfgD={'imgPoster':kJweEUzCRBodXmSnYFiKxthWMrcfgO,'imgFanart':img_fanart,'imgClearlogo':kJweEUzCRBodXmSnYFiKxthWMrcfgH,'programtitle':kJweEUzCRBodXmSnYFiKxthWMrcfPg.Get_ChangeText(kJweEUzCRBodXmSnYFiKxthWMrcfgP.get('programtitle')),'programid':kJweEUzCRBodXmSnYFiKxthWMrcfgP.get('programid'),'synopsis':kJweEUzCRBodXmSnYFiKxthWMrcfPg.Get_ChangeText(kJweEUzCRBodXmSnYFiKxthWMrcfgP.get('programsynopsis')),}
  except kJweEUzCRBodXmSnYFiKxthWMrcfyO as exception:
   kJweEUzCRBodXmSnYFiKxthWMrcfyH(exception)
  return kJweEUzCRBodXmSnYFiKxthWMrcfgD
 def Get_Season_List(kJweEUzCRBodXmSnYFiKxthWMrcfPg,seasonid):
  kJweEUzCRBodXmSnYFiKxthWMrcfgG=[]
  kJweEUzCRBodXmSnYFiKxthWMrcfDp=kJweEUzCRBodXmSnYFiKxthWMrcfPg.ProgramidToContentid(seasonid)
  kJweEUzCRBodXmSnYFiKxthWMrcfgy=kJweEUzCRBodXmSnYFiKxthWMrcfPg.GetProgramInfo(kJweEUzCRBodXmSnYFiKxthWMrcfDp)
  kJweEUzCRBodXmSnYFiKxthWMrcfgQ={'poster':kJweEUzCRBodXmSnYFiKxthWMrcfgy.get('imgPoster'),'fanart':kJweEUzCRBodXmSnYFiKxthWMrcfgy.get('imgFanart'),'clearlogo':kJweEUzCRBodXmSnYFiKxthWMrcfgy.get('imgClearlogo'),}
  try:
   kJweEUzCRBodXmSnYFiKxthWMrcflq=kJweEUzCRBodXmSnYFiKxthWMrcfPg.API_DOMAIN+'/fz/vod/programs-contents/'+seasonid
   kJweEUzCRBodXmSnYFiKxthWMrcfPL={'limit':'10','offset':'0','orderby':'new',}
   kJweEUzCRBodXmSnYFiKxthWMrcfPL.update(kJweEUzCRBodXmSnYFiKxthWMrcfPg.GetDefaultParams(login=kJweEUzCRBodXmSnYFiKxthWMrcfGb))
   kJweEUzCRBodXmSnYFiKxthWMrcflL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.callRequestCookies('Get',kJweEUzCRBodXmSnYFiKxthWMrcflq,payload=kJweEUzCRBodXmSnYFiKxthWMrcfGu,params=kJweEUzCRBodXmSnYFiKxthWMrcfPL,headers=kJweEUzCRBodXmSnYFiKxthWMrcfGu,cookies=kJweEUzCRBodXmSnYFiKxthWMrcfGu)
   kJweEUzCRBodXmSnYFiKxthWMrcflV=json.loads(kJweEUzCRBodXmSnYFiKxthWMrcflL.text)
   for kJweEUzCRBodXmSnYFiKxthWMrcfgA in kJweEUzCRBodXmSnYFiKxthWMrcflV['filter']['filterlist'][0]['filter_item_list']:
    kJweEUzCRBodXmSnYFiKxthWMrcfDg={'season_Nm':kJweEUzCRBodXmSnYFiKxthWMrcfPg.Get_ChangeText(kJweEUzCRBodXmSnYFiKxthWMrcfgA.get('title')),'season_Id':kJweEUzCRBodXmSnYFiKxthWMrcfgA.get('api_path'),'thumbnail':kJweEUzCRBodXmSnYFiKxthWMrcfgQ,'programNm':kJweEUzCRBodXmSnYFiKxthWMrcfPg.Get_ChangeText(kJweEUzCRBodXmSnYFiKxthWMrcfgy.get('programtitle')),'synopsis':kJweEUzCRBodXmSnYFiKxthWMrcfPg.Get_ChangeText(kJweEUzCRBodXmSnYFiKxthWMrcfgy.get('synopsis')),}
    kJweEUzCRBodXmSnYFiKxthWMrcfgG.append(kJweEUzCRBodXmSnYFiKxthWMrcfDg)
  except kJweEUzCRBodXmSnYFiKxthWMrcfyO as exception:
   kJweEUzCRBodXmSnYFiKxthWMrcfyH(exception)
   return[]
  return kJweEUzCRBodXmSnYFiKxthWMrcfgG
 def Get_Episode_List(kJweEUzCRBodXmSnYFiKxthWMrcfPg,seasionid,page_int=1,orderby='desc'):
  kJweEUzCRBodXmSnYFiKxthWMrcfgq=[]
  kJweEUzCRBodXmSnYFiKxthWMrcfDq=kJweEUzCRBodXmSnYFiKxthWMrcfDv=1
  kJweEUzCRBodXmSnYFiKxthWMrcfDT=kJweEUzCRBodXmSnYFiKxthWMrcfGb
  kJweEUzCRBodXmSnYFiKxthWMrcfgy={}
  kJweEUzCRBodXmSnYFiKxthWMrcfDp=kJweEUzCRBodXmSnYFiKxthWMrcfPg.ProgramidToContentid(seasionid)
  kJweEUzCRBodXmSnYFiKxthWMrcfgy=kJweEUzCRBodXmSnYFiKxthWMrcfPg.GetProgramInfo(kJweEUzCRBodXmSnYFiKxthWMrcfDp)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   kJweEUzCRBodXmSnYFiKxthWMrcflq=kJweEUzCRBodXmSnYFiKxthWMrcfPg.API_DOMAIN+'/fz/vod/programs-contents/'+seasionid
   kJweEUzCRBodXmSnYFiKxthWMrcfPL={'limit':kJweEUzCRBodXmSnYFiKxthWMrcfPg.EP_LIMIT,'offset':kJweEUzCRBodXmSnYFiKxthWMrcfyD((page_int-1)*kJweEUzCRBodXmSnYFiKxthWMrcfPg.EP_LIMIT),'orderby':orderby,}
   kJweEUzCRBodXmSnYFiKxthWMrcfPL.update(kJweEUzCRBodXmSnYFiKxthWMrcfPg.GetDefaultParams(login=kJweEUzCRBodXmSnYFiKxthWMrcfGb))
   kJweEUzCRBodXmSnYFiKxthWMrcflL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.callRequestCookies('Get',kJweEUzCRBodXmSnYFiKxthWMrcflq,payload=kJweEUzCRBodXmSnYFiKxthWMrcfGu,params=kJweEUzCRBodXmSnYFiKxthWMrcfPL,headers=kJweEUzCRBodXmSnYFiKxthWMrcfGu,cookies=kJweEUzCRBodXmSnYFiKxthWMrcfGu)
   kJweEUzCRBodXmSnYFiKxthWMrcflV=json.loads(kJweEUzCRBodXmSnYFiKxthWMrcflL.text)
   kJweEUzCRBodXmSnYFiKxthWMrcfDP=kJweEUzCRBodXmSnYFiKxthWMrcflV['cell_toplist']['celllist']
   for kJweEUzCRBodXmSnYFiKxthWMrcfDl in kJweEUzCRBodXmSnYFiKxthWMrcfDP:
    kJweEUzCRBodXmSnYFiKxthWMrcfgL=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',kJweEUzCRBodXmSnYFiKxthWMrcfDl.get('synopsis'))
    kJweEUzCRBodXmSnYFiKxthWMrcfgV=kJweEUzCRBodXmSnYFiKxthWMrcfPg.HTTPTAG+kJweEUzCRBodXmSnYFiKxthWMrcfDl.get('thumbnail')
    kJweEUzCRBodXmSnYFiKxthWMrcfga=kJweEUzCRBodXmSnYFiKxthWMrcfgj=kJweEUzCRBodXmSnYFiKxthWMrcfgv=''
    kJweEUzCRBodXmSnYFiKxthWMrcfga =kJweEUzCRBodXmSnYFiKxthWMrcfgy.get('imgPoster')
    kJweEUzCRBodXmSnYFiKxthWMrcfgj =kJweEUzCRBodXmSnYFiKxthWMrcfgy.get('imgFanart')
    kJweEUzCRBodXmSnYFiKxthWMrcfgv =kJweEUzCRBodXmSnYFiKxthWMrcfgy.get('imgClearlogo')
    kJweEUzCRBodXmSnYFiKxthWMrcfgI=kJweEUzCRBodXmSnYFiKxthWMrcfgy.get('programtitle')
    kJweEUzCRBodXmSnYFiKxthWMrcfgQ={'thumb':kJweEUzCRBodXmSnYFiKxthWMrcfgV,'poster':kJweEUzCRBodXmSnYFiKxthWMrcfga,'fanart':kJweEUzCRBodXmSnYFiKxthWMrcfgj,'clearlogo':kJweEUzCRBodXmSnYFiKxthWMrcfgv}
    kJweEUzCRBodXmSnYFiKxthWMrcfDg={'programtitle':kJweEUzCRBodXmSnYFiKxthWMrcfPg.Get_ChangeText(kJweEUzCRBodXmSnYFiKxthWMrcfgI),'episodetitle':kJweEUzCRBodXmSnYFiKxthWMrcfPg.Get_ChangeText(kJweEUzCRBodXmSnYFiKxthWMrcfDl['title_list'][0]['text']),'episodenumber':kJweEUzCRBodXmSnYFiKxthWMrcfDl['title_list'][1]['text'].replace('$O$',''),'contentid':kJweEUzCRBodXmSnYFiKxthWMrcfDl['contentid'],'synopsis':kJweEUzCRBodXmSnYFiKxthWMrcfPg.Get_ChangeText(kJweEUzCRBodXmSnYFiKxthWMrcfgL),'episodeactors':kJweEUzCRBodXmSnYFiKxthWMrcfDl.get('actors').split(',')if kJweEUzCRBodXmSnYFiKxthWMrcfDl.get('actors')!='' else[],'thumbnail':kJweEUzCRBodXmSnYFiKxthWMrcfgQ,}
    kJweEUzCRBodXmSnYFiKxthWMrcfgq.append(kJweEUzCRBodXmSnYFiKxthWMrcfDg)
   kJweEUzCRBodXmSnYFiKxthWMrcfDq=kJweEUzCRBodXmSnYFiKxthWMrcfyQ(kJweEUzCRBodXmSnYFiKxthWMrcflV['cell_toplist']['pagecount'])
   if kJweEUzCRBodXmSnYFiKxthWMrcflV['cell_toplist']['count']:kJweEUzCRBodXmSnYFiKxthWMrcfDv =kJweEUzCRBodXmSnYFiKxthWMrcfyQ(kJweEUzCRBodXmSnYFiKxthWMrcflV['cell_toplist']['count'])
   else:kJweEUzCRBodXmSnYFiKxthWMrcfDv=kJweEUzCRBodXmSnYFiKxthWMrcfPg.EP_LIMIT*page_int
   kJweEUzCRBodXmSnYFiKxthWMrcfDT=kJweEUzCRBodXmSnYFiKxthWMrcfDq>kJweEUzCRBodXmSnYFiKxthWMrcfDv
  except kJweEUzCRBodXmSnYFiKxthWMrcfyO as exception:
   kJweEUzCRBodXmSnYFiKxthWMrcfyH(exception)
   return[],kJweEUzCRBodXmSnYFiKxthWMrcfGb
  return kJweEUzCRBodXmSnYFiKxthWMrcfgq,kJweEUzCRBodXmSnYFiKxthWMrcfDT
 def GetEPGList(kJweEUzCRBodXmSnYFiKxthWMrcfPg,genre):
  kJweEUzCRBodXmSnYFiKxthWMrcfgs={}
  try:
   kJweEUzCRBodXmSnYFiKxthWMrcfgN=kJweEUzCRBodXmSnYFiKxthWMrcfPg.Get_Now_Datetime()
   if genre=='all':
    kJweEUzCRBodXmSnYFiKxthWMrcfgu =kJweEUzCRBodXmSnYFiKxthWMrcfgN+datetime.timedelta(hours=3)
   else:
    kJweEUzCRBodXmSnYFiKxthWMrcfgu =kJweEUzCRBodXmSnYFiKxthWMrcfgN+datetime.timedelta(hours=3)
   kJweEUzCRBodXmSnYFiKxthWMrcflq=kJweEUzCRBodXmSnYFiKxthWMrcfPg.API_DOMAIN+'/live/epgs'
   kJweEUzCRBodXmSnYFiKxthWMrcfPL={'limit':'100','offset':'0','genre':genre,'startdatetime':kJweEUzCRBodXmSnYFiKxthWMrcfgN.strftime('%Y-%m-%d %H:00'),'enddatetime':kJweEUzCRBodXmSnYFiKxthWMrcfgu.strftime('%Y-%m-%d %H:00')}
   kJweEUzCRBodXmSnYFiKxthWMrcfPL.update(kJweEUzCRBodXmSnYFiKxthWMrcfPg.GetDefaultParams(login=kJweEUzCRBodXmSnYFiKxthWMrcfGb))
   kJweEUzCRBodXmSnYFiKxthWMrcflL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.callRequestCookies('Get',kJweEUzCRBodXmSnYFiKxthWMrcflq,payload=kJweEUzCRBodXmSnYFiKxthWMrcfGu,params=kJweEUzCRBodXmSnYFiKxthWMrcfPL,headers=kJweEUzCRBodXmSnYFiKxthWMrcfGu,cookies=kJweEUzCRBodXmSnYFiKxthWMrcfGu)
   kJweEUzCRBodXmSnYFiKxthWMrcflV=json.loads(kJweEUzCRBodXmSnYFiKxthWMrcflL.text)
   kJweEUzCRBodXmSnYFiKxthWMrcfgb=kJweEUzCRBodXmSnYFiKxthWMrcflV['list']
   for kJweEUzCRBodXmSnYFiKxthWMrcfDl in kJweEUzCRBodXmSnYFiKxthWMrcfgb:
    kJweEUzCRBodXmSnYFiKxthWMrcfgp=''
    for kJweEUzCRBodXmSnYFiKxthWMrcfOP in kJweEUzCRBodXmSnYFiKxthWMrcfDl['list']:
     if kJweEUzCRBodXmSnYFiKxthWMrcfgp:kJweEUzCRBodXmSnYFiKxthWMrcfgp+='\n'
     kJweEUzCRBodXmSnYFiKxthWMrcfgp+=kJweEUzCRBodXmSnYFiKxthWMrcfPg.Get_ChangeText(kJweEUzCRBodXmSnYFiKxthWMrcfOP['title'])+'\n'
     kJweEUzCRBodXmSnYFiKxthWMrcfgp+=' [%s ~ %s]'%(kJweEUzCRBodXmSnYFiKxthWMrcfOP['starttime'][-5:],kJweEUzCRBodXmSnYFiKxthWMrcfOP['endtime'][-5:])+'\n'
    kJweEUzCRBodXmSnYFiKxthWMrcfgs[kJweEUzCRBodXmSnYFiKxthWMrcfDl['channelid']]=kJweEUzCRBodXmSnYFiKxthWMrcfgp
  except kJweEUzCRBodXmSnYFiKxthWMrcfyO as exception:
   kJweEUzCRBodXmSnYFiKxthWMrcfyH(exception)
  return kJweEUzCRBodXmSnYFiKxthWMrcfgs
 def Get_LiveChannel_List(kJweEUzCRBodXmSnYFiKxthWMrcfPg,genre,kJweEUzCRBodXmSnYFiKxthWMrcflb):
  kJweEUzCRBodXmSnYFiKxthWMrcfDA=[]
  (kJweEUzCRBodXmSnYFiKxthWMrcflq,kJweEUzCRBodXmSnYFiKxthWMrcfPL)=kJweEUzCRBodXmSnYFiKxthWMrcfPg.Baseapi_Parse(kJweEUzCRBodXmSnYFiKxthWMrcflb)
  if kJweEUzCRBodXmSnYFiKxthWMrcflq=='':return kJweEUzCRBodXmSnYFiKxthWMrcfDA
  kJweEUzCRBodXmSnYFiKxthWMrcfOl=kJweEUzCRBodXmSnYFiKxthWMrcfPg.GetEPGList(genre)
  try:
   kJweEUzCRBodXmSnYFiKxthWMrcfPL.update(kJweEUzCRBodXmSnYFiKxthWMrcfPg.GetDefaultParams(login=kJweEUzCRBodXmSnYFiKxthWMrcfGb))
   kJweEUzCRBodXmSnYFiKxthWMrcfPL['genre']=genre
   kJweEUzCRBodXmSnYFiKxthWMrcflL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.callRequestCookies('Get',kJweEUzCRBodXmSnYFiKxthWMrcflq,payload=kJweEUzCRBodXmSnYFiKxthWMrcfGu,params=kJweEUzCRBodXmSnYFiKxthWMrcfPL,headers=kJweEUzCRBodXmSnYFiKxthWMrcfGu,cookies=kJweEUzCRBodXmSnYFiKxthWMrcfGu)
   kJweEUzCRBodXmSnYFiKxthWMrcflV=json.loads(kJweEUzCRBodXmSnYFiKxthWMrcflL.text)
   if not('celllist' in kJweEUzCRBodXmSnYFiKxthWMrcflV['cell_toplist']):return[]
   kJweEUzCRBodXmSnYFiKxthWMrcfDP=kJweEUzCRBodXmSnYFiKxthWMrcflV['cell_toplist']['celllist']
   for kJweEUzCRBodXmSnYFiKxthWMrcfDl in kJweEUzCRBodXmSnYFiKxthWMrcfDP:
    kJweEUzCRBodXmSnYFiKxthWMrcfDp=kJweEUzCRBodXmSnYFiKxthWMrcfDl['contentid']
    if kJweEUzCRBodXmSnYFiKxthWMrcfDp in kJweEUzCRBodXmSnYFiKxthWMrcfOl:
     kJweEUzCRBodXmSnYFiKxthWMrcfOD=kJweEUzCRBodXmSnYFiKxthWMrcfOl[kJweEUzCRBodXmSnYFiKxthWMrcfDp]
    else:
     kJweEUzCRBodXmSnYFiKxthWMrcfOD=''
    kJweEUzCRBodXmSnYFiKxthWMrcfDg={'studio':kJweEUzCRBodXmSnYFiKxthWMrcfDl['title_list'][0]['text'],'tvshowtitle':kJweEUzCRBodXmSnYFiKxthWMrcfPg.Get_ChangeText(kJweEUzCRBodXmSnYFiKxthWMrcfDl['title_list'][1]['text']),'channelid':kJweEUzCRBodXmSnYFiKxthWMrcfDp,'age':kJweEUzCRBodXmSnYFiKxthWMrcfDl['age'],'thumbnail':'https://%s'%kJweEUzCRBodXmSnYFiKxthWMrcfDl.get('thumbnail'),'epg':kJweEUzCRBodXmSnYFiKxthWMrcfOD}
    kJweEUzCRBodXmSnYFiKxthWMrcfDA.append(kJweEUzCRBodXmSnYFiKxthWMrcfDg)
  except kJweEUzCRBodXmSnYFiKxthWMrcfyO as exception:
   kJweEUzCRBodXmSnYFiKxthWMrcfyH(exception)
   return[]
  return kJweEUzCRBodXmSnYFiKxthWMrcfDA
 def Get_Search_List(kJweEUzCRBodXmSnYFiKxthWMrcfPg,search_key,sType,page_int,exclusion21=kJweEUzCRBodXmSnYFiKxthWMrcfGb):
  kJweEUzCRBodXmSnYFiKxthWMrcfOg=[]
  kJweEUzCRBodXmSnYFiKxthWMrcfDq=kJweEUzCRBodXmSnYFiKxthWMrcfDv=1
  kJweEUzCRBodXmSnYFiKxthWMrcfDT=kJweEUzCRBodXmSnYFiKxthWMrcfGb
  try:
   kJweEUzCRBodXmSnYFiKxthWMrcflq=kJweEUzCRBodXmSnYFiKxthWMrcfPg.API_DOMAIN+'/fz/search/band.js'
   kJweEUzCRBodXmSnYFiKxthWMrcfPL={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':kJweEUzCRBodXmSnYFiKxthWMrcfyD((page_int-1)*kJweEUzCRBodXmSnYFiKxthWMrcfPg.SEARCH_LIMIT),'limit':kJweEUzCRBodXmSnYFiKxthWMrcfPg.SEARCH_LIMIT,'orderby':'score','mtype':'svod',}
   kJweEUzCRBodXmSnYFiKxthWMrcfPL.update(kJweEUzCRBodXmSnYFiKxthWMrcfPg.GetDefaultParams(login=kJweEUzCRBodXmSnYFiKxthWMrcfGb))
   kJweEUzCRBodXmSnYFiKxthWMrcflL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.callRequestCookies('Get',kJweEUzCRBodXmSnYFiKxthWMrcflq,payload=kJweEUzCRBodXmSnYFiKxthWMrcfGu,params=kJweEUzCRBodXmSnYFiKxthWMrcfPL,headers=kJweEUzCRBodXmSnYFiKxthWMrcfGu,cookies=kJweEUzCRBodXmSnYFiKxthWMrcfGu)
   kJweEUzCRBodXmSnYFiKxthWMrcfgP=json.loads(kJweEUzCRBodXmSnYFiKxthWMrcflL.text)
   if not('celllist' in kJweEUzCRBodXmSnYFiKxthWMrcfgP['band']):return kJweEUzCRBodXmSnYFiKxthWMrcfOg,kJweEUzCRBodXmSnYFiKxthWMrcfDT
   kJweEUzCRBodXmSnYFiKxthWMrcfDP=kJweEUzCRBodXmSnYFiKxthWMrcfgP['band']['celllist']
   for kJweEUzCRBodXmSnYFiKxthWMrcfDl in kJweEUzCRBodXmSnYFiKxthWMrcfDP:
    kJweEUzCRBodXmSnYFiKxthWMrcfDL =kJweEUzCRBodXmSnYFiKxthWMrcfDl['event_list'][1]['url']
    kJweEUzCRBodXmSnYFiKxthWMrcfDV=urllib.parse.urlsplit(kJweEUzCRBodXmSnYFiKxthWMrcfDL).query
    kJweEUzCRBodXmSnYFiKxthWMrcfDa=kJweEUzCRBodXmSnYFiKxthWMrcfDV[0:kJweEUzCRBodXmSnYFiKxthWMrcfDV.find('=')]
    kJweEUzCRBodXmSnYFiKxthWMrcfDu=kJweEUzCRBodXmSnYFiKxthWMrcfyG(urllib.parse.parse_qsl(kJweEUzCRBodXmSnYFiKxthWMrcfDV))
    kJweEUzCRBodXmSnYFiKxthWMrcfDj=kJweEUzCRBodXmSnYFiKxthWMrcfDu.get(kJweEUzCRBodXmSnYFiKxthWMrcfDa)
    kJweEUzCRBodXmSnYFiKxthWMrcfDg={'title':kJweEUzCRBodXmSnYFiKxthWMrcfDl['title_list'][0]['text'],'age':kJweEUzCRBodXmSnYFiKxthWMrcfDl['age'],'thumbnail':'https://%s'%kJweEUzCRBodXmSnYFiKxthWMrcfDl.get('thumbnail'),'videoid':kJweEUzCRBodXmSnYFiKxthWMrcfDj,'vidtype':kJweEUzCRBodXmSnYFiKxthWMrcfDa,}
    kJweEUzCRBodXmSnYFiKxthWMrcfOH=kJweEUzCRBodXmSnYFiKxthWMrcfGb
    for kJweEUzCRBodXmSnYFiKxthWMrcfOG in kJweEUzCRBodXmSnYFiKxthWMrcfDl['bottom_taglist']:
     if kJweEUzCRBodXmSnYFiKxthWMrcfOG=='won':
      kJweEUzCRBodXmSnYFiKxthWMrcfOH=kJweEUzCRBodXmSnYFiKxthWMrcfyP
      break
    if kJweEUzCRBodXmSnYFiKxthWMrcfOH==kJweEUzCRBodXmSnYFiKxthWMrcfyP: 
     kJweEUzCRBodXmSnYFiKxthWMrcfDg['title']=kJweEUzCRBodXmSnYFiKxthWMrcfDg['title']+' [개별구매]'
    if exclusion21==kJweEUzCRBodXmSnYFiKxthWMrcfGb or kJweEUzCRBodXmSnYFiKxthWMrcfDl.get('age')!='21':
     kJweEUzCRBodXmSnYFiKxthWMrcfOg.append(kJweEUzCRBodXmSnYFiKxthWMrcfDg)
   kJweEUzCRBodXmSnYFiKxthWMrcfDq=kJweEUzCRBodXmSnYFiKxthWMrcfyQ(kJweEUzCRBodXmSnYFiKxthWMrcfgP['band']['pagecount'])
   if kJweEUzCRBodXmSnYFiKxthWMrcfgP['band']['count']:kJweEUzCRBodXmSnYFiKxthWMrcfDv =kJweEUzCRBodXmSnYFiKxthWMrcfyQ(kJweEUzCRBodXmSnYFiKxthWMrcfgP['band']['count'])
   else:kJweEUzCRBodXmSnYFiKxthWMrcfDv=kJweEUzCRBodXmSnYFiKxthWMrcfPg.LIST_LIMIT
   kJweEUzCRBodXmSnYFiKxthWMrcfDT=kJweEUzCRBodXmSnYFiKxthWMrcfDq>kJweEUzCRBodXmSnYFiKxthWMrcfDv
  except kJweEUzCRBodXmSnYFiKxthWMrcfyO as exception:
   kJweEUzCRBodXmSnYFiKxthWMrcfyH(exception)
  return kJweEUzCRBodXmSnYFiKxthWMrcfOg,kJweEUzCRBodXmSnYFiKxthWMrcfDT 
 def GetSecureToken(kJweEUzCRBodXmSnYFiKxthWMrcfPg):
  kJweEUzCRBodXmSnYFiKxthWMrcflq=kJweEUzCRBodXmSnYFiKxthWMrcfPg.API_DOMAIN+'/ip'
  kJweEUzCRBodXmSnYFiKxthWMrcfPL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.GetDefaultParams(login=kJweEUzCRBodXmSnYFiKxthWMrcfGb)
  kJweEUzCRBodXmSnYFiKxthWMrcflL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.callRequestCookies('Get',kJweEUzCRBodXmSnYFiKxthWMrcflq,payload=kJweEUzCRBodXmSnYFiKxthWMrcfGu,params=kJweEUzCRBodXmSnYFiKxthWMrcfPL,headers=kJweEUzCRBodXmSnYFiKxthWMrcfGu,cookies=kJweEUzCRBodXmSnYFiKxthWMrcfGu)
  kJweEUzCRBodXmSnYFiKxthWMrcflV=json.loads(kJweEUzCRBodXmSnYFiKxthWMrcflL.text)
  return kJweEUzCRBodXmSnYFiKxthWMrcflV['securetoken']
 def Wavve_Parse_m3u8(kJweEUzCRBodXmSnYFiKxthWMrcfPg,kJweEUzCRBodXmSnYFiKxthWMrcfHy):
  try:
   kJweEUzCRBodXmSnYFiKxthWMrcfly={'user-agent':'pooqV2/5.6.0 (Linux;Android 10) ExoPlayerLib/2.13.3'}
   kJweEUzCRBodXmSnYFiKxthWMrcflL=requests.get(url=kJweEUzCRBodXmSnYFiKxthWMrcfHy['stream_url'],headers=kJweEUzCRBodXmSnYFiKxthWMrcfly,cookies=kJweEUzCRBodXmSnYFiKxthWMrcfHy['stream_cookie'])
   kJweEUzCRBodXmSnYFiKxthWMrcfOy=kJweEUzCRBodXmSnYFiKxthWMrcflL.content.decode('utf-8')
   if '#EXTM3U' not in kJweEUzCRBodXmSnYFiKxthWMrcfOy:
    return kJweEUzCRBodXmSnYFiKxthWMrcfGb
   if '#EXT-X-STREAM-INF' not in kJweEUzCRBodXmSnYFiKxthWMrcfOy: 
    return kJweEUzCRBodXmSnYFiKxthWMrcfGb
   kJweEUzCRBodXmSnYFiKxthWMrcfOQ=0
   for kJweEUzCRBodXmSnYFiKxthWMrcfOA in kJweEUzCRBodXmSnYFiKxthWMrcfOy.splitlines():
    if kJweEUzCRBodXmSnYFiKxthWMrcfOA.startswith('#EXT-X-STREAM-INF'):
     kJweEUzCRBodXmSnYFiKxthWMrcfOq=kJweEUzCRBodXmSnYFiKxthWMrcfPg.MediaLine_Parse(kJweEUzCRBodXmSnYFiKxthWMrcfOA,'#EXT-X-STREAM-INF')
     if kJweEUzCRBodXmSnYFiKxthWMrcfOQ<kJweEUzCRBodXmSnYFiKxthWMrcfyQ(kJweEUzCRBodXmSnYFiKxthWMrcfOq.get('BANDWIDTH')):
      kJweEUzCRBodXmSnYFiKxthWMrcfOQ=kJweEUzCRBodXmSnYFiKxthWMrcfyQ(kJweEUzCRBodXmSnYFiKxthWMrcfOq.get('BANDWIDTH'))
   kJweEUzCRBodXmSnYFiKxthWMrcfOT=[]
   kJweEUzCRBodXmSnYFiKxthWMrcfOL=kJweEUzCRBodXmSnYFiKxthWMrcfGb
   for kJweEUzCRBodXmSnYFiKxthWMrcfOA in kJweEUzCRBodXmSnYFiKxthWMrcfOy.splitlines():
    if kJweEUzCRBodXmSnYFiKxthWMrcfOL==kJweEUzCRBodXmSnYFiKxthWMrcfyP:
     kJweEUzCRBodXmSnYFiKxthWMrcfOL=kJweEUzCRBodXmSnYFiKxthWMrcfGb
     continue
    if kJweEUzCRBodXmSnYFiKxthWMrcfOA.startswith('#EXT-X-STREAM-INF'):
     kJweEUzCRBodXmSnYFiKxthWMrcfOq=kJweEUzCRBodXmSnYFiKxthWMrcfPg.MediaLine_Parse(kJweEUzCRBodXmSnYFiKxthWMrcfOA,'#EXT-X-STREAM-INF')
     if kJweEUzCRBodXmSnYFiKxthWMrcfOQ!=kJweEUzCRBodXmSnYFiKxthWMrcfyQ(kJweEUzCRBodXmSnYFiKxthWMrcfOq.get('BANDWIDTH')):
      kJweEUzCRBodXmSnYFiKxthWMrcfOL=kJweEUzCRBodXmSnYFiKxthWMrcfyP
      continue
    kJweEUzCRBodXmSnYFiKxthWMrcfOT.append(kJweEUzCRBodXmSnYFiKxthWMrcfOA)
  except kJweEUzCRBodXmSnYFiKxthWMrcfyO as exception:
   kJweEUzCRBodXmSnYFiKxthWMrcfyH(exception)
   return kJweEUzCRBodXmSnYFiKxthWMrcfGb
  kJweEUzCRBodXmSnYFiKxthWMrcfOV='\n'.join(kJweEUzCRBodXmSnYFiKxthWMrcfOT)
  kJweEUzCRBodXmSnYFiKxthWMrcfPg.TextFile_Save(kJweEUzCRBodXmSnYFiKxthWMrcfPg.WV_STREAM_FILENAME,kJweEUzCRBodXmSnYFiKxthWMrcfOV)
  return kJweEUzCRBodXmSnYFiKxthWMrcfyP
 def Wavve_Parse_mpd(kJweEUzCRBodXmSnYFiKxthWMrcfPg,kJweEUzCRBodXmSnYFiKxthWMrcfHy):
  kJweEUzCRBodXmSnYFiKxthWMrcfly={'user-agent':'pooqV2/5.6.0 (Linux;Android 10) ExoPlayerLib/2.13.3'}
  kJweEUzCRBodXmSnYFiKxthWMrcflL=requests.get(url=kJweEUzCRBodXmSnYFiKxthWMrcfHy['stream_url'],headers=kJweEUzCRBodXmSnYFiKxthWMrcfly,cookies=kJweEUzCRBodXmSnYFiKxthWMrcfHy['stream_cookie'])
  kJweEUzCRBodXmSnYFiKxthWMrcfOa=kJweEUzCRBodXmSnYFiKxthWMrcflL.content.decode('utf-8')
  kJweEUzCRBodXmSnYFiKxthWMrcfOj =ET.ElementTree(ET.fromstring(kJweEUzCRBodXmSnYFiKxthWMrcfOa))
  kJweEUzCRBodXmSnYFiKxthWMrcfOv =kJweEUzCRBodXmSnYFiKxthWMrcfOj.getroot()
  kJweEUzCRBodXmSnYFiKxthWMrcfOI=re.match(r'\{.*\}',kJweEUzCRBodXmSnYFiKxthWMrcfOv.tag)[0] 
  kJweEUzCRBodXmSnYFiKxthWMrcfOs=kJweEUzCRBodXmSnYFiKxthWMrcfyG([node for _,node in ET.iterparse(io.StringIO(kJweEUzCRBodXmSnYFiKxthWMrcfOa),events=['start-ns'])])
  for kJweEUzCRBodXmSnYFiKxthWMrcflH,kJweEUzCRBodXmSnYFiKxthWMrcfHG in kJweEUzCRBodXmSnYFiKxthWMrcfOs.items():
   ET.register_namespace(kJweEUzCRBodXmSnYFiKxthWMrcflH,kJweEUzCRBodXmSnYFiKxthWMrcfHG)
  kJweEUzCRBodXmSnYFiKxthWMrcfON=kJweEUzCRBodXmSnYFiKxthWMrcfOv.find(kJweEUzCRBodXmSnYFiKxthWMrcfOI+'Period')
  for kJweEUzCRBodXmSnYFiKxthWMrcfOu in kJweEUzCRBodXmSnYFiKxthWMrcfON.findall(kJweEUzCRBodXmSnYFiKxthWMrcfOI+'AdaptationSet'):
   if kJweEUzCRBodXmSnYFiKxthWMrcfOu.attrib.get('mimeType')=='video/mp4':
    kJweEUzCRBodXmSnYFiKxthWMrcfOb=0
    for kJweEUzCRBodXmSnYFiKxthWMrcfOp in kJweEUzCRBodXmSnYFiKxthWMrcfOu.findall(kJweEUzCRBodXmSnYFiKxthWMrcfOI+'Representation'):
     kJweEUzCRBodXmSnYFiKxthWMrcfHP=kJweEUzCRBodXmSnYFiKxthWMrcfyQ(kJweEUzCRBodXmSnYFiKxthWMrcfOp.attrib.get('bandwidth'))
     if kJweEUzCRBodXmSnYFiKxthWMrcfOb<kJweEUzCRBodXmSnYFiKxthWMrcfHP:kJweEUzCRBodXmSnYFiKxthWMrcfOb=kJweEUzCRBodXmSnYFiKxthWMrcfHP
    for kJweEUzCRBodXmSnYFiKxthWMrcfOp in kJweEUzCRBodXmSnYFiKxthWMrcfOu.findall(kJweEUzCRBodXmSnYFiKxthWMrcfOI+'Representation'):
     if kJweEUzCRBodXmSnYFiKxthWMrcfOb>kJweEUzCRBodXmSnYFiKxthWMrcfyQ(kJweEUzCRBodXmSnYFiKxthWMrcfOp.attrib.get('bandwidth')):
      kJweEUzCRBodXmSnYFiKxthWMrcfOu.remove(kJweEUzCRBodXmSnYFiKxthWMrcfOp)
   elif kJweEUzCRBodXmSnYFiKxthWMrcfOu.attrib.get('mimeType')=='audio/mp4':
    kJweEUzCRBodXmSnYFiKxthWMrcfOb=0
    for kJweEUzCRBodXmSnYFiKxthWMrcfOp in kJweEUzCRBodXmSnYFiKxthWMrcfOu.findall(kJweEUzCRBodXmSnYFiKxthWMrcfOI+'Representation'):
     kJweEUzCRBodXmSnYFiKxthWMrcfHP=kJweEUzCRBodXmSnYFiKxthWMrcfyQ(kJweEUzCRBodXmSnYFiKxthWMrcfOp.attrib.get('bandwidth'))
     if kJweEUzCRBodXmSnYFiKxthWMrcfOb<kJweEUzCRBodXmSnYFiKxthWMrcfHP:kJweEUzCRBodXmSnYFiKxthWMrcfOb=kJweEUzCRBodXmSnYFiKxthWMrcfHP
    for kJweEUzCRBodXmSnYFiKxthWMrcfOp in kJweEUzCRBodXmSnYFiKxthWMrcfOu.findall(kJweEUzCRBodXmSnYFiKxthWMrcfOI+'Representation'):
     if kJweEUzCRBodXmSnYFiKxthWMrcfOb>kJweEUzCRBodXmSnYFiKxthWMrcfyQ(kJweEUzCRBodXmSnYFiKxthWMrcfOp.attrib.get('bandwidth')):
      kJweEUzCRBodXmSnYFiKxthWMrcfOu.remove(kJweEUzCRBodXmSnYFiKxthWMrcfOp)
   else:
    continue
  kJweEUzCRBodXmSnYFiKxthWMrcfHl=ET.tostring(kJweEUzCRBodXmSnYFiKxthWMrcfOv).decode('utf-8')
  kJweEUzCRBodXmSnYFiKxthWMrcfHD='<?xml version="1.0" encoding="UTF-8"?>\n'
  kJweEUzCRBodXmSnYFiKxthWMrcfPg.TextFile_Save(kJweEUzCRBodXmSnYFiKxthWMrcfPg.WV_STREAM_FILENAME,kJweEUzCRBodXmSnYFiKxthWMrcfHD+kJweEUzCRBodXmSnYFiKxthWMrcfHl)
  return kJweEUzCRBodXmSnYFiKxthWMrcfyP
 def MediaLine_Parse(kJweEUzCRBodXmSnYFiKxthWMrcfPg,kJweEUzCRBodXmSnYFiKxthWMrcfOA,prefix):
  kJweEUzCRBodXmSnYFiKxthWMrcfOq={}
  for kJweEUzCRBodXmSnYFiKxthWMrcfHg in kJweEUzCRBodXmSnYFiKxthWMrcfPD.split(kJweEUzCRBodXmSnYFiKxthWMrcfOA.replace(prefix+':',''))[1::2]:
   kJweEUzCRBodXmSnYFiKxthWMrcfHO,kJweEUzCRBodXmSnYFiKxthWMrcfHG=kJweEUzCRBodXmSnYFiKxthWMrcfHg.split('=',1)
   kJweEUzCRBodXmSnYFiKxthWMrcfOq[kJweEUzCRBodXmSnYFiKxthWMrcfHO.upper()]=kJweEUzCRBodXmSnYFiKxthWMrcfHG.replace('"','').strip()
  return kJweEUzCRBodXmSnYFiKxthWMrcfOq
 def GetStreamingURL(kJweEUzCRBodXmSnYFiKxthWMrcfPg,mode,kJweEUzCRBodXmSnYFiKxthWMrcfDp,quality_int,pvrmode='-',playOption={}):
  kJweEUzCRBodXmSnYFiKxthWMrcfHy ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  kJweEUzCRBodXmSnYFiKxthWMrcfHQ=[]
  if mode=='LIVE':
   kJweEUzCRBodXmSnYFiKxthWMrcflq =kJweEUzCRBodXmSnYFiKxthWMrcfPg.API_DOMAIN+'/live/channels/'+kJweEUzCRBodXmSnYFiKxthWMrcfDp
   kJweEUzCRBodXmSnYFiKxthWMrcfHA='live'
  elif mode=='VOD':
   kJweEUzCRBodXmSnYFiKxthWMrcflq =kJweEUzCRBodXmSnYFiKxthWMrcfPg.API_DOMAIN+'/fz/vod/contents-detail/'+kJweEUzCRBodXmSnYFiKxthWMrcfDp 
   kJweEUzCRBodXmSnYFiKxthWMrcfHA='vod'
  elif mode=='MOVIE':
   kJweEUzCRBodXmSnYFiKxthWMrcflq =kJweEUzCRBodXmSnYFiKxthWMrcfPg.API_DOMAIN+'/fz/movie/contents/'+kJweEUzCRBodXmSnYFiKxthWMrcfDp
   kJweEUzCRBodXmSnYFiKxthWMrcfHA='movie'
  kJweEUzCRBodXmSnYFiKxthWMrcfHq={'hdr':'sdr','uhd':'-',}
  try:
   kJweEUzCRBodXmSnYFiKxthWMrcfPL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.GetDefaultParams(login=kJweEUzCRBodXmSnYFiKxthWMrcfGb)
   kJweEUzCRBodXmSnYFiKxthWMrcflL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.callRequestCookies('Get',kJweEUzCRBodXmSnYFiKxthWMrcflq,payload=kJweEUzCRBodXmSnYFiKxthWMrcfGu,params=kJweEUzCRBodXmSnYFiKxthWMrcfPL,headers=kJweEUzCRBodXmSnYFiKxthWMrcfGu,cookies=kJweEUzCRBodXmSnYFiKxthWMrcfGu)
   kJweEUzCRBodXmSnYFiKxthWMrcflV=json.loads(kJweEUzCRBodXmSnYFiKxthWMrcflL.text)
   kJweEUzCRBodXmSnYFiKxthWMrcfHT=kJweEUzCRBodXmSnYFiKxthWMrcflV['qualities']['list']
   if kJweEUzCRBodXmSnYFiKxthWMrcfHT==kJweEUzCRBodXmSnYFiKxthWMrcfGu:return kJweEUzCRBodXmSnYFiKxthWMrcfHy
   for kJweEUzCRBodXmSnYFiKxthWMrcfHL in kJweEUzCRBodXmSnYFiKxthWMrcfHT:
    kJweEUzCRBodXmSnYFiKxthWMrcfHQ.append(kJweEUzCRBodXmSnYFiKxthWMrcfyQ(kJweEUzCRBodXmSnYFiKxthWMrcfHL.get('id').rstrip('p')))
   if 'type' in kJweEUzCRBodXmSnYFiKxthWMrcflV:
    if kJweEUzCRBodXmSnYFiKxthWMrcflV['type']=='onair':
     kJweEUzCRBodXmSnYFiKxthWMrcfHA='onairvod'
   if 'drms' in kJweEUzCRBodXmSnYFiKxthWMrcflV:
    if kJweEUzCRBodXmSnYFiKxthWMrcflV['drms']:
     kJweEUzCRBodXmSnYFiKxthWMrcfHy['stream_action']='dash' 
   if playOption.get('enable_hdr'):
    if 'mediatypes' in kJweEUzCRBodXmSnYFiKxthWMrcflV.get('qualities'):
     for kJweEUzCRBodXmSnYFiKxthWMrcfHV in kJweEUzCRBodXmSnYFiKxthWMrcflV.get('qualities').get('mediatypes'):
      if kJweEUzCRBodXmSnYFiKxthWMrcfHV=='HDR10':
       kJweEUzCRBodXmSnYFiKxthWMrcfHq['hdr']='hdr'
       kJweEUzCRBodXmSnYFiKxthWMrcfHy['stream_action']='dash'
       break
   if playOption.get('enable_uhd'):
    for kJweEUzCRBodXmSnYFiKxthWMrcfHV in kJweEUzCRBodXmSnYFiKxthWMrcflV.get('qualities').get('list'):
     if kJweEUzCRBodXmSnYFiKxthWMrcfHV.get('name')=='UHD':
      kJweEUzCRBodXmSnYFiKxthWMrcfHq['uhd']='uhd'
      break
  except kJweEUzCRBodXmSnYFiKxthWMrcfyO as exception:
   kJweEUzCRBodXmSnYFiKxthWMrcfyH(exception)
   return kJweEUzCRBodXmSnYFiKxthWMrcfHy
  kJweEUzCRBodXmSnYFiKxthWMrcfyH('stream_action : '+kJweEUzCRBodXmSnYFiKxthWMrcfHy['stream_action'])
  try:
   kJweEUzCRBodXmSnYFiKxthWMrcfHa=kJweEUzCRBodXmSnYFiKxthWMrcfPg.CheckQuality(quality_int,kJweEUzCRBodXmSnYFiKxthWMrcfHQ)
   kJweEUzCRBodXmSnYFiKxthWMrcfyH(kJweEUzCRBodXmSnYFiKxthWMrcfHa)
   if kJweEUzCRBodXmSnYFiKxthWMrcfHa<1080:
    kJweEUzCRBodXmSnYFiKxthWMrcfHq['uhd']='-'
    kJweEUzCRBodXmSnYFiKxthWMrcfHq['hdr']='sdr'
   if kJweEUzCRBodXmSnYFiKxthWMrcfHq['uhd']=='uhd':kJweEUzCRBodXmSnYFiKxthWMrcfHa=2160 
   kJweEUzCRBodXmSnYFiKxthWMrcfHj=kJweEUzCRBodXmSnYFiKxthWMrcfyD(kJweEUzCRBodXmSnYFiKxthWMrcfHa)+'p'
   kJweEUzCRBodXmSnYFiKxthWMrcfyH(kJweEUzCRBodXmSnYFiKxthWMrcfHj)
   kJweEUzCRBodXmSnYFiKxthWMrcflq=kJweEUzCRBodXmSnYFiKxthWMrcfPg.API_DOMAIN+'/fz/streaming'
   if kJweEUzCRBodXmSnYFiKxthWMrcfHq['hdr']=='hdr' or kJweEUzCRBodXmSnYFiKxthWMrcfHq['uhd']=='uhd':
    kJweEUzCRBodXmSnYFiKxthWMrcfPL={'contentid':kJweEUzCRBodXmSnYFiKxthWMrcfDp,'contenttype':kJweEUzCRBodXmSnYFiKxthWMrcfHA,'quality':kJweEUzCRBodXmSnYFiKxthWMrcfHj,'modelid':'SHIELD Android TV','guid':kJweEUzCRBodXmSnYFiKxthWMrcfPg.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n','protocol':kJweEUzCRBodXmSnYFiKxthWMrcfHy['stream_action'],'hdr':'HDR10','videocodec':'HEVC','audiocodec':'AAC','issurround':'y','format':'normal','withinsubtitle':'n',}
    kJweEUzCRBodXmSnYFiKxthWMrcfPL.update(kJweEUzCRBodXmSnYFiKxthWMrcfPg.GetDefaultParams_AND())
   else:
    kJweEUzCRBodXmSnYFiKxthWMrcfPL={'contentid':kJweEUzCRBodXmSnYFiKxthWMrcfDp,'contenttype':kJweEUzCRBodXmSnYFiKxthWMrcfHA,'quality':kJweEUzCRBodXmSnYFiKxthWMrcfHj,'deviceModelId':'Windows 10','guid':kJweEUzCRBodXmSnYFiKxthWMrcfPg.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n','action':kJweEUzCRBodXmSnYFiKxthWMrcfHy['stream_action'],'protocol':kJweEUzCRBodXmSnYFiKxthWMrcfHy['stream_action'],'hdr':'sdr','videocodec':'avc','audiocodec':'aac','issurround':'n','format':'normal','withinsubtitle':'n',}
    kJweEUzCRBodXmSnYFiKxthWMrcfPL.update(kJweEUzCRBodXmSnYFiKxthWMrcfPg.GetDefaultParams(login=kJweEUzCRBodXmSnYFiKxthWMrcfyP))
   kJweEUzCRBodXmSnYFiKxthWMrcflL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.callRequestCookies('Get',kJweEUzCRBodXmSnYFiKxthWMrcflq,payload=kJweEUzCRBodXmSnYFiKxthWMrcfGu,params=kJweEUzCRBodXmSnYFiKxthWMrcfPL,headers=kJweEUzCRBodXmSnYFiKxthWMrcfGu,cookies=kJweEUzCRBodXmSnYFiKxthWMrcfGu)
   kJweEUzCRBodXmSnYFiKxthWMrcflV=json.loads(kJweEUzCRBodXmSnYFiKxthWMrcflL.text)
   kJweEUzCRBodXmSnYFiKxthWMrcfHy['stream_url']=kJweEUzCRBodXmSnYFiKxthWMrcflV['playurl']
   if kJweEUzCRBodXmSnYFiKxthWMrcfHy['stream_url']==kJweEUzCRBodXmSnYFiKxthWMrcfGu:return kJweEUzCRBodXmSnYFiKxthWMrcfHy
   kJweEUzCRBodXmSnYFiKxthWMrcfHy['stream_cookie']=kJweEUzCRBodXmSnYFiKxthWMrcfPg.make_str_ToCookie(kJweEUzCRBodXmSnYFiKxthWMrcflV['awscookie'])
   kJweEUzCRBodXmSnYFiKxthWMrcfHy['stream_drm'] =kJweEUzCRBodXmSnYFiKxthWMrcflV['drm']
   if 'previewmsg' in kJweEUzCRBodXmSnYFiKxthWMrcflV['preview']:kJweEUzCRBodXmSnYFiKxthWMrcfHy['stream_preview']=kJweEUzCRBodXmSnYFiKxthWMrcflV['preview']['previewmsg']
   if 'subtitles' in kJweEUzCRBodXmSnYFiKxthWMrcflV:
    for kJweEUzCRBodXmSnYFiKxthWMrcfHv in kJweEUzCRBodXmSnYFiKxthWMrcflV['subtitles']:
     if kJweEUzCRBodXmSnYFiKxthWMrcfHv.get('languagecode')=='ko':
      kJweEUzCRBodXmSnYFiKxthWMrcfHy['stream_vtt']=kJweEUzCRBodXmSnYFiKxthWMrcfHv.get('url')
      break
    if kJweEUzCRBodXmSnYFiKxthWMrcfHy['stream_vtt']=='':
     for kJweEUzCRBodXmSnYFiKxthWMrcfHv in kJweEUzCRBodXmSnYFiKxthWMrcflV['subtitles']:
      if kJweEUzCRBodXmSnYFiKxthWMrcfHv.get('languagecode')=='ko_cc':
       kJweEUzCRBodXmSnYFiKxthWMrcfHy['stream_vtt']=kJweEUzCRBodXmSnYFiKxthWMrcfHv.get('url')
       break
   kJweEUzCRBodXmSnYFiKxthWMrcfHy['playParam']=kJweEUzCRBodXmSnYFiKxthWMrcfHq 
  except kJweEUzCRBodXmSnYFiKxthWMrcfyO as exception:
   kJweEUzCRBodXmSnYFiKxthWMrcfyH(exception)
  return kJweEUzCRBodXmSnYFiKxthWMrcfHy 
 def GetSportsURL(kJweEUzCRBodXmSnYFiKxthWMrcfPg,kJweEUzCRBodXmSnYFiKxthWMrcfDp,quality_int):
  kJweEUzCRBodXmSnYFiKxthWMrcfHy ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  kJweEUzCRBodXmSnYFiKxthWMrcfHQ=[]
  try:
   kJweEUzCRBodXmSnYFiKxthWMrcflq=kJweEUzCRBodXmSnYFiKxthWMrcfPg.API_DOMAIN+'/streaming/other'
   kJweEUzCRBodXmSnYFiKxthWMrcfPL={'contentid':kJweEUzCRBodXmSnYFiKxthWMrcfDp,'contenttype':'live','action':kJweEUzCRBodXmSnYFiKxthWMrcfHy['stream_action'],'quality':kJweEUzCRBodXmSnYFiKxthWMrcfyD(quality_int)+'p','deviceModelId':'Windows 10','guid':kJweEUzCRBodXmSnYFiKxthWMrcfPg.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n',}
   kJweEUzCRBodXmSnYFiKxthWMrcfPL.update(kJweEUzCRBodXmSnYFiKxthWMrcfPg.GetDefaultParams(login=kJweEUzCRBodXmSnYFiKxthWMrcfyP))
   kJweEUzCRBodXmSnYFiKxthWMrcflL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.callRequestCookies('Get',kJweEUzCRBodXmSnYFiKxthWMrcflq,payload=kJweEUzCRBodXmSnYFiKxthWMrcfGu,params=kJweEUzCRBodXmSnYFiKxthWMrcfPL,headers=kJweEUzCRBodXmSnYFiKxthWMrcfGu,cookies=kJweEUzCRBodXmSnYFiKxthWMrcfGu)
   kJweEUzCRBodXmSnYFiKxthWMrcflV=json.loads(kJweEUzCRBodXmSnYFiKxthWMrcflL.text)
   kJweEUzCRBodXmSnYFiKxthWMrcfHy['stream_url']=kJweEUzCRBodXmSnYFiKxthWMrcflV['playurl']
   if kJweEUzCRBodXmSnYFiKxthWMrcfHy['stream_url']==kJweEUzCRBodXmSnYFiKxthWMrcfGu:return kJweEUzCRBodXmSnYFiKxthWMrcfHy
   kJweEUzCRBodXmSnYFiKxthWMrcfHy['stream_cookie']=kJweEUzCRBodXmSnYFiKxthWMrcflV['awscookie']
  except kJweEUzCRBodXmSnYFiKxthWMrcfyO as exception:
   kJweEUzCRBodXmSnYFiKxthWMrcfyH(exception)
  return kJweEUzCRBodXmSnYFiKxthWMrcfHy
 def make_viewdate(kJweEUzCRBodXmSnYFiKxthWMrcfPg):
  kJweEUzCRBodXmSnYFiKxthWMrcfHI =kJweEUzCRBodXmSnYFiKxthWMrcfPg.Get_Now_Datetime()
  kJweEUzCRBodXmSnYFiKxthWMrcfHs =kJweEUzCRBodXmSnYFiKxthWMrcfHI+datetime.timedelta(days=-1)
  kJweEUzCRBodXmSnYFiKxthWMrcfHN =kJweEUzCRBodXmSnYFiKxthWMrcfHI+datetime.timedelta(days=1)
  kJweEUzCRBodXmSnYFiKxthWMrcfHu=[kJweEUzCRBodXmSnYFiKxthWMrcfHI.strftime('%Y%m%d'),kJweEUzCRBodXmSnYFiKxthWMrcfHN.strftime('%Y%m%d'),]
  return kJweEUzCRBodXmSnYFiKxthWMrcfHu
 def Get_Sports_Gamelist(kJweEUzCRBodXmSnYFiKxthWMrcfPg):
  kJweEUzCRBodXmSnYFiKxthWMrcfHb =kJweEUzCRBodXmSnYFiKxthWMrcfPg.make_viewdate()
  kJweEUzCRBodXmSnYFiKxthWMrcfHp=[]
  kJweEUzCRBodXmSnYFiKxthWMrcfGP =[]
  for kJweEUzCRBodXmSnYFiKxthWMrcfGl in kJweEUzCRBodXmSnYFiKxthWMrcfHb:
   kJweEUzCRBodXmSnYFiKxthWMrcfGD=kJweEUzCRBodXmSnYFiKxthWMrcfGl[:6]
   if kJweEUzCRBodXmSnYFiKxthWMrcfGD not in kJweEUzCRBodXmSnYFiKxthWMrcfHp:
    kJweEUzCRBodXmSnYFiKxthWMrcfHp.append(kJweEUzCRBodXmSnYFiKxthWMrcfGD)
  try:
   kJweEUzCRBodXmSnYFiKxthWMrcflq='https://annexapi.wavve.com/skb/baseball/teammonthlycalendarlist'
   kJweEUzCRBodXmSnYFiKxthWMrcfPL={'IF':'IF-PORG-002','m':'getTeamCalendarListBand','response_format':'json','spo_itm_cd':'KBO','teamcd':'all','tgroup':'B','tvalue':'BC123','ver':'2.0',}
   kJweEUzCRBodXmSnYFiKxthWMrcfPL.update(kJweEUzCRBodXmSnYFiKxthWMrcfPg.GetDefaultParams(login=kJweEUzCRBodXmSnYFiKxthWMrcfGb))
   for kJweEUzCRBodXmSnYFiKxthWMrcfGg in kJweEUzCRBodXmSnYFiKxthWMrcfHp:
    kJweEUzCRBodXmSnYFiKxthWMrcfPL['date']=kJweEUzCRBodXmSnYFiKxthWMrcfGg
    kJweEUzCRBodXmSnYFiKxthWMrcflL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.callRequestCookies('Get',kJweEUzCRBodXmSnYFiKxthWMrcflq,payload=kJweEUzCRBodXmSnYFiKxthWMrcfGu,params=kJweEUzCRBodXmSnYFiKxthWMrcfPL,headers=kJweEUzCRBodXmSnYFiKxthWMrcfGu,cookies=kJweEUzCRBodXmSnYFiKxthWMrcfGu)
    kJweEUzCRBodXmSnYFiKxthWMrcflV=json.loads(kJweEUzCRBodXmSnYFiKxthWMrcflL.text)
    kJweEUzCRBodXmSnYFiKxthWMrcfDP=kJweEUzCRBodXmSnYFiKxthWMrcflV['cell_toplist']['celllist']
    for kJweEUzCRBodXmSnYFiKxthWMrcfDl in kJweEUzCRBodXmSnYFiKxthWMrcfDP:
     kJweEUzCRBodXmSnYFiKxthWMrcfGO=kJweEUzCRBodXmSnYFiKxthWMrcfDl.get('game_date')
     kJweEUzCRBodXmSnYFiKxthWMrcfGH =kJweEUzCRBodXmSnYFiKxthWMrcfDl.get('svc_id')
     if kJweEUzCRBodXmSnYFiKxthWMrcfGH=='':continue
     if kJweEUzCRBodXmSnYFiKxthWMrcfGO in kJweEUzCRBodXmSnYFiKxthWMrcfHb:
      kJweEUzCRBodXmSnYFiKxthWMrcfGy=kJweEUzCRBodXmSnYFiKxthWMrcfDl.get('game_status') 
      kJweEUzCRBodXmSnYFiKxthWMrcfGQ =kJweEUzCRBodXmSnYFiKxthWMrcfDl.get('title_list')[0].get('text')
      kJweEUzCRBodXmSnYFiKxthWMrcfGO =kJweEUzCRBodXmSnYFiKxthWMrcfGO[:4]+'-'+kJweEUzCRBodXmSnYFiKxthWMrcfGO[4:6]+'-'+kJweEUzCRBodXmSnYFiKxthWMrcfGO[-2:]
      kJweEUzCRBodXmSnYFiKxthWMrcfGA =kJweEUzCRBodXmSnYFiKxthWMrcfDl.get('game_time')
      kJweEUzCRBodXmSnYFiKxthWMrcfGA =kJweEUzCRBodXmSnYFiKxthWMrcfGA[:2]+':'+kJweEUzCRBodXmSnYFiKxthWMrcfGA[-2:]
      kJweEUzCRBodXmSnYFiKxthWMrcfDg={'game_date':kJweEUzCRBodXmSnYFiKxthWMrcfGO,'game_time':kJweEUzCRBodXmSnYFiKxthWMrcfGA,'svc_id':kJweEUzCRBodXmSnYFiKxthWMrcfGH,'away_team':kJweEUzCRBodXmSnYFiKxthWMrcfDl.get('away_team').get('team_name'),'home_team':kJweEUzCRBodXmSnYFiKxthWMrcfDl.get('home_team').get('team_name'),'game_status':kJweEUzCRBodXmSnYFiKxthWMrcfGy,'game_place':kJweEUzCRBodXmSnYFiKxthWMrcfDl.get('game_place'),}
      kJweEUzCRBodXmSnYFiKxthWMrcfGP.append(kJweEUzCRBodXmSnYFiKxthWMrcfDg)
  except kJweEUzCRBodXmSnYFiKxthWMrcfyO as exception:
   kJweEUzCRBodXmSnYFiKxthWMrcfyH(exception)
   return[]
  kJweEUzCRBodXmSnYFiKxthWMrcfGq=[]
  for i in kJweEUzCRBodXmSnYFiKxthWMrcfyl(2):
   for kJweEUzCRBodXmSnYFiKxthWMrcfDl in kJweEUzCRBodXmSnYFiKxthWMrcfGP:
    if i==0 and kJweEUzCRBodXmSnYFiKxthWMrcfDl.get('game_status')=='LIVE':
     kJweEUzCRBodXmSnYFiKxthWMrcfGq.append(kJweEUzCRBodXmSnYFiKxthWMrcfDl)
    elif i==1 and kJweEUzCRBodXmSnYFiKxthWMrcfDl.get('game_status')!='LIVE':
     kJweEUzCRBodXmSnYFiKxthWMrcfGq.append(kJweEUzCRBodXmSnYFiKxthWMrcfDl)
  return kJweEUzCRBodXmSnYFiKxthWMrcfGq
 def GetBookmarkInfo(kJweEUzCRBodXmSnYFiKxthWMrcfPg,kJweEUzCRBodXmSnYFiKxthWMrcfDj,kJweEUzCRBodXmSnYFiKxthWMrcfDa,kJweEUzCRBodXmSnYFiKxthWMrcfHA):
  if kJweEUzCRBodXmSnYFiKxthWMrcfDa=='tvshow':
   if kJweEUzCRBodXmSnYFiKxthWMrcfHA=='contentid':
    kJweEUzCRBodXmSnYFiKxthWMrcfDp=kJweEUzCRBodXmSnYFiKxthWMrcfDj
    kJweEUzCRBodXmSnYFiKxthWMrcfDj =kJweEUzCRBodXmSnYFiKxthWMrcfPg.ContentidToSeasonid(kJweEUzCRBodXmSnYFiKxthWMrcfDp)
   else:
    kJweEUzCRBodXmSnYFiKxthWMrcfDp=kJweEUzCRBodXmSnYFiKxthWMrcfPg.ProgramidToContentid(kJweEUzCRBodXmSnYFiKxthWMrcfDj)
  else:
   kJweEUzCRBodXmSnYFiKxthWMrcfDp=''
  kJweEUzCRBodXmSnYFiKxthWMrcfGT={'indexinfo':{'ott':'wavve','videoid':kJweEUzCRBodXmSnYFiKxthWMrcfDj,'vidtype':kJweEUzCRBodXmSnYFiKxthWMrcfDa,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':kJweEUzCRBodXmSnYFiKxthWMrcfDa,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if kJweEUzCRBodXmSnYFiKxthWMrcfDa=='tvshow':
   kJweEUzCRBodXmSnYFiKxthWMrcflq=kJweEUzCRBodXmSnYFiKxthWMrcfPg.API_DOMAIN+'/fz/vod/contents/'+kJweEUzCRBodXmSnYFiKxthWMrcfDp 
   kJweEUzCRBodXmSnYFiKxthWMrcfPL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.GetDefaultParams(login=kJweEUzCRBodXmSnYFiKxthWMrcfGb)
   kJweEUzCRBodXmSnYFiKxthWMrcflL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.callRequestCookies('Get',kJweEUzCRBodXmSnYFiKxthWMrcflq,payload=kJweEUzCRBodXmSnYFiKxthWMrcfGu,params=kJweEUzCRBodXmSnYFiKxthWMrcfPL,headers=kJweEUzCRBodXmSnYFiKxthWMrcfGu,cookies=kJweEUzCRBodXmSnYFiKxthWMrcfGu)
   kJweEUzCRBodXmSnYFiKxthWMrcflV=json.loads(kJweEUzCRBodXmSnYFiKxthWMrcflL.text)
   if not('programtitle' in kJweEUzCRBodXmSnYFiKxthWMrcflV):return{}
   kJweEUzCRBodXmSnYFiKxthWMrcfGL=kJweEUzCRBodXmSnYFiKxthWMrcflV
   kJweEUzCRBodXmSnYFiKxthWMrcfGV=kJweEUzCRBodXmSnYFiKxthWMrcfGL.get('programtitle')
   kJweEUzCRBodXmSnYFiKxthWMrcfGT['saveinfo']['infoLabels']['title']=kJweEUzCRBodXmSnYFiKxthWMrcfGV
   if kJweEUzCRBodXmSnYFiKxthWMrcfGL.get('targetage')=='18' or kJweEUzCRBodXmSnYFiKxthWMrcfGL.get('targetage')=='19' or kJweEUzCRBodXmSnYFiKxthWMrcfGL.get('targetage')=='21':
    kJweEUzCRBodXmSnYFiKxthWMrcfGV +=u' (%s)'%(kJweEUzCRBodXmSnYFiKxthWMrcfGL.get('targetage'))
   kJweEUzCRBodXmSnYFiKxthWMrcfGT['saveinfo']['title'] =kJweEUzCRBodXmSnYFiKxthWMrcfGV
   kJweEUzCRBodXmSnYFiKxthWMrcfGT['saveinfo']['infoLabels']['mpaa'] =kJweEUzCRBodXmSnYFiKxthWMrcfGL.get('targetage')
   kJweEUzCRBodXmSnYFiKxthWMrcfGT['saveinfo']['infoLabels']['plot'] =kJweEUzCRBodXmSnYFiKxthWMrcfPg.Get_ChangeText(kJweEUzCRBodXmSnYFiKxthWMrcfGL.get('programsynopsis'))
   kJweEUzCRBodXmSnYFiKxthWMrcfGT['saveinfo']['infoLabels']['studio'] =kJweEUzCRBodXmSnYFiKxthWMrcfGL.get('channelname')
   if kJweEUzCRBodXmSnYFiKxthWMrcfGL.get('firstreleaseyear')!='':kJweEUzCRBodXmSnYFiKxthWMrcfGT['saveinfo']['infoLabels']['year'] =kJweEUzCRBodXmSnYFiKxthWMrcfGL.get('firstreleaseyear')
   if kJweEUzCRBodXmSnYFiKxthWMrcfGL.get('firstreleasedate')!='':kJweEUzCRBodXmSnYFiKxthWMrcfGT['saveinfo']['infoLabels']['premiered']=kJweEUzCRBodXmSnYFiKxthWMrcfGL.get('firstreleasedate')
   if kJweEUzCRBodXmSnYFiKxthWMrcfGL.get('genretext') !='':kJweEUzCRBodXmSnYFiKxthWMrcfGT['saveinfo']['infoLabels']['genre'] =[kJweEUzCRBodXmSnYFiKxthWMrcfGL.get('genretext')]
   kJweEUzCRBodXmSnYFiKxthWMrcfGa=[]
   for kJweEUzCRBodXmSnYFiKxthWMrcfGj in kJweEUzCRBodXmSnYFiKxthWMrcfGL['actors']['list']:kJweEUzCRBodXmSnYFiKxthWMrcfGa.append(kJweEUzCRBodXmSnYFiKxthWMrcfGj.get('text'))
   if kJweEUzCRBodXmSnYFiKxthWMrcfyg(kJweEUzCRBodXmSnYFiKxthWMrcfGa)>0:
    if kJweEUzCRBodXmSnYFiKxthWMrcfGa[0]!='':kJweEUzCRBodXmSnYFiKxthWMrcfGT['saveinfo']['infoLabels']['cast']=kJweEUzCRBodXmSnYFiKxthWMrcfGa
   kJweEUzCRBodXmSnYFiKxthWMrcfga =''
   kJweEUzCRBodXmSnYFiKxthWMrcfgj =''
   kJweEUzCRBodXmSnYFiKxthWMrcfgv=''
   if kJweEUzCRBodXmSnYFiKxthWMrcfGL.get('programposterimage')!='':kJweEUzCRBodXmSnYFiKxthWMrcfga =kJweEUzCRBodXmSnYFiKxthWMrcfPg.HTTPTAG+kJweEUzCRBodXmSnYFiKxthWMrcfGL.get('programposterimage')
   if kJweEUzCRBodXmSnYFiKxthWMrcfGL.get('programimage') !='':kJweEUzCRBodXmSnYFiKxthWMrcfgj =kJweEUzCRBodXmSnYFiKxthWMrcfPg.HTTPTAG+kJweEUzCRBodXmSnYFiKxthWMrcfGL.get('programimage')
   if kJweEUzCRBodXmSnYFiKxthWMrcfGL.get('programcircleimage')!='':kJweEUzCRBodXmSnYFiKxthWMrcfgv=kJweEUzCRBodXmSnYFiKxthWMrcfPg.HTTPTAG+kJweEUzCRBodXmSnYFiKxthWMrcfGL.get('programcircleimage')
   if 'poster_default' in kJweEUzCRBodXmSnYFiKxthWMrcfga:
    kJweEUzCRBodXmSnYFiKxthWMrcfga =kJweEUzCRBodXmSnYFiKxthWMrcfgj
    kJweEUzCRBodXmSnYFiKxthWMrcfgv=''
   kJweEUzCRBodXmSnYFiKxthWMrcfGT['saveinfo']['thumbnail']['poster']=kJweEUzCRBodXmSnYFiKxthWMrcfga
   kJweEUzCRBodXmSnYFiKxthWMrcfGT['saveinfo']['thumbnail']['thumb']=kJweEUzCRBodXmSnYFiKxthWMrcfgj
   kJweEUzCRBodXmSnYFiKxthWMrcfGT['saveinfo']['thumbnail']['clearlogo']=kJweEUzCRBodXmSnYFiKxthWMrcfgv
   kJweEUzCRBodXmSnYFiKxthWMrcfGT['saveinfo']['thumbnail']['fanart']=kJweEUzCRBodXmSnYFiKxthWMrcfgj
  else:
   kJweEUzCRBodXmSnYFiKxthWMrcflq=kJweEUzCRBodXmSnYFiKxthWMrcfPg.API_DOMAIN+'/movie/contents/'+kJweEUzCRBodXmSnYFiKxthWMrcfDj 
   kJweEUzCRBodXmSnYFiKxthWMrcfPL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.GetDefaultParams(login=kJweEUzCRBodXmSnYFiKxthWMrcfGb)
   kJweEUzCRBodXmSnYFiKxthWMrcflL=kJweEUzCRBodXmSnYFiKxthWMrcfPg.callRequestCookies('Get',kJweEUzCRBodXmSnYFiKxthWMrcflq,payload=kJweEUzCRBodXmSnYFiKxthWMrcfGu,params=kJweEUzCRBodXmSnYFiKxthWMrcfPL,headers=kJweEUzCRBodXmSnYFiKxthWMrcfGu,cookies=kJweEUzCRBodXmSnYFiKxthWMrcfGu)
   kJweEUzCRBodXmSnYFiKxthWMrcflV=json.loads(kJweEUzCRBodXmSnYFiKxthWMrcflL.text)
   if not('title' in kJweEUzCRBodXmSnYFiKxthWMrcflV):return{}
   kJweEUzCRBodXmSnYFiKxthWMrcfGL=kJweEUzCRBodXmSnYFiKxthWMrcflV
   kJweEUzCRBodXmSnYFiKxthWMrcfGV=kJweEUzCRBodXmSnYFiKxthWMrcfGL.get('title')
   kJweEUzCRBodXmSnYFiKxthWMrcfGT['saveinfo']['infoLabels']['title']=kJweEUzCRBodXmSnYFiKxthWMrcfGV
   if kJweEUzCRBodXmSnYFiKxthWMrcfGL.get('targetage')=='18' or kJweEUzCRBodXmSnYFiKxthWMrcfGL.get('targetage')=='19' or kJweEUzCRBodXmSnYFiKxthWMrcfGL.get('targetage')=='21':
    kJweEUzCRBodXmSnYFiKxthWMrcfGV +=u' (%s)'%(kJweEUzCRBodXmSnYFiKxthWMrcfGL.get('targetage'))
   kJweEUzCRBodXmSnYFiKxthWMrcfGT['saveinfo']['title'] =kJweEUzCRBodXmSnYFiKxthWMrcfGV
   kJweEUzCRBodXmSnYFiKxthWMrcfGT['saveinfo']['infoLabels']['mpaa'] =kJweEUzCRBodXmSnYFiKxthWMrcfGL.get('targetage')
   kJweEUzCRBodXmSnYFiKxthWMrcfGT['saveinfo']['infoLabels']['plot'] =kJweEUzCRBodXmSnYFiKxthWMrcfPg.Get_ChangeText(kJweEUzCRBodXmSnYFiKxthWMrcfGL.get('synopsis'))
   kJweEUzCRBodXmSnYFiKxthWMrcfGT['saveinfo']['infoLabels']['duration']=kJweEUzCRBodXmSnYFiKxthWMrcfGL.get('playtime')
   kJweEUzCRBodXmSnYFiKxthWMrcfGT['saveinfo']['infoLabels']['country']=kJweEUzCRBodXmSnYFiKxthWMrcfGL.get('country')
   kJweEUzCRBodXmSnYFiKxthWMrcfGT['saveinfo']['infoLabels']['studio'] =kJweEUzCRBodXmSnYFiKxthWMrcfGL.get('cpname')
   if kJweEUzCRBodXmSnYFiKxthWMrcfGL.get('releasedate')!='':
    kJweEUzCRBodXmSnYFiKxthWMrcfGT['saveinfo']['infoLabels']['year'] =kJweEUzCRBodXmSnYFiKxthWMrcfGL.get('releasedate')[:4]
    kJweEUzCRBodXmSnYFiKxthWMrcfGT['saveinfo']['infoLabels']['premiered']=kJweEUzCRBodXmSnYFiKxthWMrcfGL.get('releasedate')
   kJweEUzCRBodXmSnYFiKxthWMrcfGa=[]
   for kJweEUzCRBodXmSnYFiKxthWMrcfGj in kJweEUzCRBodXmSnYFiKxthWMrcfGL['actors']['list']:kJweEUzCRBodXmSnYFiKxthWMrcfGa.append(kJweEUzCRBodXmSnYFiKxthWMrcfGj.get('text'))
   if kJweEUzCRBodXmSnYFiKxthWMrcfyg(kJweEUzCRBodXmSnYFiKxthWMrcfGa)>0:
    if kJweEUzCRBodXmSnYFiKxthWMrcfGa[0]!='':kJweEUzCRBodXmSnYFiKxthWMrcfGT['saveinfo']['infoLabels']['cast']=kJweEUzCRBodXmSnYFiKxthWMrcfGa
   kJweEUzCRBodXmSnYFiKxthWMrcfGv=[]
   for kJweEUzCRBodXmSnYFiKxthWMrcfGI in kJweEUzCRBodXmSnYFiKxthWMrcfGL['directors']['list']:kJweEUzCRBodXmSnYFiKxthWMrcfGv.append(kJweEUzCRBodXmSnYFiKxthWMrcfGI.get('text'))
   if kJweEUzCRBodXmSnYFiKxthWMrcfyg(kJweEUzCRBodXmSnYFiKxthWMrcfGv)>0:
    if kJweEUzCRBodXmSnYFiKxthWMrcfGv[0]!='':kJweEUzCRBodXmSnYFiKxthWMrcfGT['saveinfo']['infoLabels']['director']=kJweEUzCRBodXmSnYFiKxthWMrcfGv
   kJweEUzCRBodXmSnYFiKxthWMrcflu=[]
   for kJweEUzCRBodXmSnYFiKxthWMrcfGs in kJweEUzCRBodXmSnYFiKxthWMrcfGL['genre']['list']:kJweEUzCRBodXmSnYFiKxthWMrcflu.append(kJweEUzCRBodXmSnYFiKxthWMrcfGs.get('text'))
   if kJweEUzCRBodXmSnYFiKxthWMrcfyg(kJweEUzCRBodXmSnYFiKxthWMrcflu)>0:
    if kJweEUzCRBodXmSnYFiKxthWMrcflu[0]!='':kJweEUzCRBodXmSnYFiKxthWMrcfGT['saveinfo']['infoLabels']['genre']=kJweEUzCRBodXmSnYFiKxthWMrcflu
   kJweEUzCRBodXmSnYFiKxthWMrcfga ='https://%s'%kJweEUzCRBodXmSnYFiKxthWMrcfGL['image']
   kJweEUzCRBodXmSnYFiKxthWMrcfGT['saveinfo']['thumbnail']['poster'] =kJweEUzCRBodXmSnYFiKxthWMrcfga
   kJweEUzCRBodXmSnYFiKxthWMrcfGT['saveinfo']['thumbnail']['thumb'] =kJweEUzCRBodXmSnYFiKxthWMrcfga
  return kJweEUzCRBodXmSnYFiKxthWMrcfGT
# Created by pyminifier (https://github.com/liftoff/pyminifier)
