__author__="NightRain"
EPxhCnbMqyimvlIoOrjkAUQNTJKHLF=object
EPxhCnbMqyimvlIoOrjkAUQNTJKHLX=None
EPxhCnbMqyimvlIoOrjkAUQNTJKHLu=int
EPxhCnbMqyimvlIoOrjkAUQNTJKHLd=True
EPxhCnbMqyimvlIoOrjkAUQNTJKHLg=False
EPxhCnbMqyimvlIoOrjkAUQNTJKHLV=type
EPxhCnbMqyimvlIoOrjkAUQNTJKHLp=dict
EPxhCnbMqyimvlIoOrjkAUQNTJKHLf=getattr
EPxhCnbMqyimvlIoOrjkAUQNTJKHLs=list
EPxhCnbMqyimvlIoOrjkAUQNTJKHLz=len
EPxhCnbMqyimvlIoOrjkAUQNTJKHLR=range
EPxhCnbMqyimvlIoOrjkAUQNTJKHLw=str
EPxhCnbMqyimvlIoOrjkAUQNTJKHLG=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import json
EPxhCnbMqyimvlIoOrjkAUQNTJKHSe=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://apis.wavve.com/v1/multiband/GN51','icon':'home.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&uicode=VN500','page':'1','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/allprograms?WeekDay=all&broadcastid=VN1000&came=MainCategory&contenttype=program&genre=01&uicode=VN1000&uiparent=GN56&uirank=21&uitype=VN1000','page':'1','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/allprograms?WeekDay=all&adult=n&broadcastid=VN1001&came=MainCategory&contenttype=program&genre=02&subgenre=all&uicode=VN1001&uiparent=GN57&uirank=17&uitype=VN1001','page':'1','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'CN21','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'vod09','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'vod09','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'4','sType':'movie','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'4','sType':'movie','orderby':'modifydate','ordernm':'업데이트순','icon':''},{'title':'프로야구 - 경기중 시청가능','mode':'GAME_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'(웨이브) 검색','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'(웨이브) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
EPxhCnbMqyimvlIoOrjkAUQNTJKHSY=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
EPxhCnbMqyimvlIoOrjkAUQNTJKHSc=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
EPxhCnbMqyimvlIoOrjkAUQNTJKHSD={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
EPxhCnbMqyimvlIoOrjkAUQNTJKHSB =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
EPxhCnbMqyimvlIoOrjkAUQNTJKHSL=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_searched.txt'))
from wavveCore import*
class EPxhCnbMqyimvlIoOrjkAUQNTJKHSa(EPxhCnbMqyimvlIoOrjkAUQNTJKHLF):
 def __init__(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW,EPxhCnbMqyimvlIoOrjkAUQNTJKHSt,EPxhCnbMqyimvlIoOrjkAUQNTJKHSF,EPxhCnbMqyimvlIoOrjkAUQNTJKHSX):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSW._addon_url =EPxhCnbMqyimvlIoOrjkAUQNTJKHSt
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSW._addon_handle=EPxhCnbMqyimvlIoOrjkAUQNTJKHSF
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.main_params =EPxhCnbMqyimvlIoOrjkAUQNTJKHSX
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj =bdLRKMcHWAUDiPpwJgzBtEuevrxslF() 
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.WV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_stream(mpd,m3u8)'))
 def addon_noti(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW,sting):
  try:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSd=xbmcgui.Dialog()
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSd.notification(__addonname__,sting)
  except:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHLX
 def addon_log(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW,string):
  try:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSg=string.encode('utf-8','ignore')
  except:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSg='addonException: addon_log'
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSV=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,EPxhCnbMqyimvlIoOrjkAUQNTJKHSg),level=EPxhCnbMqyimvlIoOrjkAUQNTJKHSV)
 def get_keyboard_input(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW,EPxhCnbMqyimvlIoOrjkAUQNTJKHau):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSp=EPxhCnbMqyimvlIoOrjkAUQNTJKHLX
  kb=xbmc.Keyboard()
  kb.setHeading(EPxhCnbMqyimvlIoOrjkAUQNTJKHau)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSp=kb.getText()
  return EPxhCnbMqyimvlIoOrjkAUQNTJKHSp
 def get_settings_account(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSf =__addon__.getSetting('id')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSs =__addon__.getSetting('pw')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSz=EPxhCnbMqyimvlIoOrjkAUQNTJKHLu(__addon__.getSetting('selected_profile'))
  return(EPxhCnbMqyimvlIoOrjkAUQNTJKHSf,EPxhCnbMqyimvlIoOrjkAUQNTJKHSs,EPxhCnbMqyimvlIoOrjkAUQNTJKHSz)
 def get_settings_totalsearch(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSR =EPxhCnbMqyimvlIoOrjkAUQNTJKHLd if __addon__.getSetting('local_search')=='true' else EPxhCnbMqyimvlIoOrjkAUQNTJKHLg
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSw=EPxhCnbMqyimvlIoOrjkAUQNTJKHLd if __addon__.getSetting('local_history')=='true' else EPxhCnbMqyimvlIoOrjkAUQNTJKHLg
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSG =EPxhCnbMqyimvlIoOrjkAUQNTJKHLd if __addon__.getSetting('total_search')=='true' else EPxhCnbMqyimvlIoOrjkAUQNTJKHLg
  EPxhCnbMqyimvlIoOrjkAUQNTJKHaS=EPxhCnbMqyimvlIoOrjkAUQNTJKHLd if __addon__.getSetting('total_history')=='true' else EPxhCnbMqyimvlIoOrjkAUQNTJKHLg
  EPxhCnbMqyimvlIoOrjkAUQNTJKHae=EPxhCnbMqyimvlIoOrjkAUQNTJKHLd if __addon__.getSetting('menu_bookmark')=='true' else EPxhCnbMqyimvlIoOrjkAUQNTJKHLg
  return(EPxhCnbMqyimvlIoOrjkAUQNTJKHSR,EPxhCnbMqyimvlIoOrjkAUQNTJKHSw,EPxhCnbMqyimvlIoOrjkAUQNTJKHSG,EPxhCnbMqyimvlIoOrjkAUQNTJKHaS,EPxhCnbMqyimvlIoOrjkAUQNTJKHae)
 def get_settings_makebookmark(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW):
  return EPxhCnbMqyimvlIoOrjkAUQNTJKHLd if __addon__.getSetting('make_bookmark')=='true' else EPxhCnbMqyimvlIoOrjkAUQNTJKHLg
 def get_settings_play(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHaY={'enable_hdr':EPxhCnbMqyimvlIoOrjkAUQNTJKHLd if __addon__.getSetting('enable_hdr')=='true' else EPxhCnbMqyimvlIoOrjkAUQNTJKHLg,'enable_uhd':EPxhCnbMqyimvlIoOrjkAUQNTJKHLd if __addon__.getSetting('enable_uhd')=='true' else EPxhCnbMqyimvlIoOrjkAUQNTJKHLg,'streamFilename':EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.WV_STREAM_FILENAME,}
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.get_selQuality()<1080:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHaY['enable_hdr']=EPxhCnbMqyimvlIoOrjkAUQNTJKHLg
   EPxhCnbMqyimvlIoOrjkAUQNTJKHaY['enable_uhd']=EPxhCnbMqyimvlIoOrjkAUQNTJKHLg
  return(EPxhCnbMqyimvlIoOrjkAUQNTJKHaY)
 def get_settings_proxyport(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHac =EPxhCnbMqyimvlIoOrjkAUQNTJKHLd if __addon__.getSetting('proxyYn')=='true' else EPxhCnbMqyimvlIoOrjkAUQNTJKHLg
  EPxhCnbMqyimvlIoOrjkAUQNTJKHaD=EPxhCnbMqyimvlIoOrjkAUQNTJKHLu(__addon__.getSetting('proxyPort'))
  return EPxhCnbMqyimvlIoOrjkAUQNTJKHac,EPxhCnbMqyimvlIoOrjkAUQNTJKHaD
 def get_selQuality(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW):
  try:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHaB=[1080,720,480,360]
   EPxhCnbMqyimvlIoOrjkAUQNTJKHaL=EPxhCnbMqyimvlIoOrjkAUQNTJKHLu(__addon__.getSetting('selected_quality'))
   return EPxhCnbMqyimvlIoOrjkAUQNTJKHaB[EPxhCnbMqyimvlIoOrjkAUQNTJKHaL]
  except:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHLX
  return 1080 
 def get_settings_exclusion21(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHaW =__addon__.getSetting('exclusion21')
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHaW=='false':
   return EPxhCnbMqyimvlIoOrjkAUQNTJKHLg
  else:
   return EPxhCnbMqyimvlIoOrjkAUQNTJKHLd
 def get_settings_direct_replay(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHat=EPxhCnbMqyimvlIoOrjkAUQNTJKHLu(__addon__.getSetting('direct_replay'))
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHat==0:
   return EPxhCnbMqyimvlIoOrjkAUQNTJKHLg
  else:
   return EPxhCnbMqyimvlIoOrjkAUQNTJKHLd
 def set_winEpisodeOrderby(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW,EPxhCnbMqyimvlIoOrjkAUQNTJKHaF):
  __addon__.setSetting('wavve_orderby',EPxhCnbMqyimvlIoOrjkAUQNTJKHaF)
 def get_winEpisodeOrderby(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHaF=__addon__.getSetting('wavve_orderby')
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHaF in['',EPxhCnbMqyimvlIoOrjkAUQNTJKHLX]:EPxhCnbMqyimvlIoOrjkAUQNTJKHaF='desc'
  return EPxhCnbMqyimvlIoOrjkAUQNTJKHaF
 def add_dir(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW,label,sublabel='',img='',infoLabels=EPxhCnbMqyimvlIoOrjkAUQNTJKHLX,isFolder=EPxhCnbMqyimvlIoOrjkAUQNTJKHLd,params='',isLink=EPxhCnbMqyimvlIoOrjkAUQNTJKHLg,ContextMenu=EPxhCnbMqyimvlIoOrjkAUQNTJKHLX):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHaX='%s?%s'%(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW._addon_url,urllib.parse.urlencode(params))
  if sublabel:EPxhCnbMqyimvlIoOrjkAUQNTJKHau='%s < %s >'%(label,sublabel)
  else: EPxhCnbMqyimvlIoOrjkAUQNTJKHau=label
  if not img:img='DefaultFolder.png'
  EPxhCnbMqyimvlIoOrjkAUQNTJKHad=xbmcgui.ListItem(EPxhCnbMqyimvlIoOrjkAUQNTJKHau)
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHLV(img)==EPxhCnbMqyimvlIoOrjkAUQNTJKHLp:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHad.setArt(img)
  else:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHad.setArt({'thumb':img,'poster':img})
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.KodiVersion>=20:
   if infoLabels:EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.Set_InfoTag(EPxhCnbMqyimvlIoOrjkAUQNTJKHad.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:EPxhCnbMqyimvlIoOrjkAUQNTJKHad.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHad.setProperty('IsPlayable','true')
  if ContextMenu:EPxhCnbMqyimvlIoOrjkAUQNTJKHad.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW._addon_handle,EPxhCnbMqyimvlIoOrjkAUQNTJKHaX,EPxhCnbMqyimvlIoOrjkAUQNTJKHad,isFolder)
 def Set_InfoTag(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW,video_InfoTag:xbmc.InfoTagVideo,EPxhCnbMqyimvlIoOrjkAUQNTJKHaw):
  for EPxhCnbMqyimvlIoOrjkAUQNTJKHag,value in EPxhCnbMqyimvlIoOrjkAUQNTJKHaw.items():
   if EPxhCnbMqyimvlIoOrjkAUQNTJKHSD[EPxhCnbMqyimvlIoOrjkAUQNTJKHag]['type']=='string':
    EPxhCnbMqyimvlIoOrjkAUQNTJKHLf(video_InfoTag,EPxhCnbMqyimvlIoOrjkAUQNTJKHSD[EPxhCnbMqyimvlIoOrjkAUQNTJKHag]['func'])(value)
   elif EPxhCnbMqyimvlIoOrjkAUQNTJKHSD[EPxhCnbMqyimvlIoOrjkAUQNTJKHag]['type']=='int':
    if EPxhCnbMqyimvlIoOrjkAUQNTJKHLV(value)==EPxhCnbMqyimvlIoOrjkAUQNTJKHLu:
     EPxhCnbMqyimvlIoOrjkAUQNTJKHaV=EPxhCnbMqyimvlIoOrjkAUQNTJKHLu(value)
    else:
     EPxhCnbMqyimvlIoOrjkAUQNTJKHaV=0
    EPxhCnbMqyimvlIoOrjkAUQNTJKHLf(video_InfoTag,EPxhCnbMqyimvlIoOrjkAUQNTJKHSD[EPxhCnbMqyimvlIoOrjkAUQNTJKHag]['func'])(EPxhCnbMqyimvlIoOrjkAUQNTJKHaV)
   elif EPxhCnbMqyimvlIoOrjkAUQNTJKHSD[EPxhCnbMqyimvlIoOrjkAUQNTJKHag]['type']=='actor':
    if value!=[]:
     EPxhCnbMqyimvlIoOrjkAUQNTJKHLf(video_InfoTag,EPxhCnbMqyimvlIoOrjkAUQNTJKHSD[EPxhCnbMqyimvlIoOrjkAUQNTJKHag]['func'])([xbmc.Actor(name)for name in value])
   elif EPxhCnbMqyimvlIoOrjkAUQNTJKHSD[EPxhCnbMqyimvlIoOrjkAUQNTJKHag]['type']=='list':
    if EPxhCnbMqyimvlIoOrjkAUQNTJKHLV(value)==EPxhCnbMqyimvlIoOrjkAUQNTJKHLs:
     EPxhCnbMqyimvlIoOrjkAUQNTJKHLf(video_InfoTag,EPxhCnbMqyimvlIoOrjkAUQNTJKHSD[EPxhCnbMqyimvlIoOrjkAUQNTJKHag]['func'])(value)
    else:
     EPxhCnbMqyimvlIoOrjkAUQNTJKHLf(video_InfoTag,EPxhCnbMqyimvlIoOrjkAUQNTJKHSD[EPxhCnbMqyimvlIoOrjkAUQNTJKHag]['func'])([value])
 def dp_Main_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW):
  (EPxhCnbMqyimvlIoOrjkAUQNTJKHSR,EPxhCnbMqyimvlIoOrjkAUQNTJKHSw,EPxhCnbMqyimvlIoOrjkAUQNTJKHSG,EPxhCnbMqyimvlIoOrjkAUQNTJKHaS,EPxhCnbMqyimvlIoOrjkAUQNTJKHae)=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.get_settings_totalsearch()
  for EPxhCnbMqyimvlIoOrjkAUQNTJKHap in EPxhCnbMqyimvlIoOrjkAUQNTJKHSe:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHau=EPxhCnbMqyimvlIoOrjkAUQNTJKHap.get('title')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHaf=''
   if EPxhCnbMqyimvlIoOrjkAUQNTJKHap.get('mode')=='SEARCH_GROUP' and EPxhCnbMqyimvlIoOrjkAUQNTJKHSR ==EPxhCnbMqyimvlIoOrjkAUQNTJKHLg:continue
   elif EPxhCnbMqyimvlIoOrjkAUQNTJKHap.get('mode')=='SEARCH_HISTORY' and EPxhCnbMqyimvlIoOrjkAUQNTJKHSw==EPxhCnbMqyimvlIoOrjkAUQNTJKHLg:continue
   elif EPxhCnbMqyimvlIoOrjkAUQNTJKHap.get('mode')=='TOTAL_SEARCH' and EPxhCnbMqyimvlIoOrjkAUQNTJKHSG ==EPxhCnbMqyimvlIoOrjkAUQNTJKHLg:continue
   elif EPxhCnbMqyimvlIoOrjkAUQNTJKHap.get('mode')=='TOTAL_HISTORY' and EPxhCnbMqyimvlIoOrjkAUQNTJKHaS==EPxhCnbMqyimvlIoOrjkAUQNTJKHLg:continue
   elif EPxhCnbMqyimvlIoOrjkAUQNTJKHap.get('mode')=='MENU_BOOKMARK' and EPxhCnbMqyimvlIoOrjkAUQNTJKHae==EPxhCnbMqyimvlIoOrjkAUQNTJKHLg:continue
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas={'mode':EPxhCnbMqyimvlIoOrjkAUQNTJKHap.get('mode'),'sCode':EPxhCnbMqyimvlIoOrjkAUQNTJKHap.get('sCode'),'sIndex':EPxhCnbMqyimvlIoOrjkAUQNTJKHap.get('sIndex'),'sType':EPxhCnbMqyimvlIoOrjkAUQNTJKHap.get('sType'),'suburl':EPxhCnbMqyimvlIoOrjkAUQNTJKHap.get('suburl'),'subapi':EPxhCnbMqyimvlIoOrjkAUQNTJKHap.get('subapi'),'page':EPxhCnbMqyimvlIoOrjkAUQNTJKHap.get('page'),'orderby':EPxhCnbMqyimvlIoOrjkAUQNTJKHap.get('orderby'),'ordernm':EPxhCnbMqyimvlIoOrjkAUQNTJKHap.get('ordernm')}
   if EPxhCnbMqyimvlIoOrjkAUQNTJKHap.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    EPxhCnbMqyimvlIoOrjkAUQNTJKHaz=EPxhCnbMqyimvlIoOrjkAUQNTJKHLg
    EPxhCnbMqyimvlIoOrjkAUQNTJKHaR =EPxhCnbMqyimvlIoOrjkAUQNTJKHLd
   else:
    EPxhCnbMqyimvlIoOrjkAUQNTJKHaz=EPxhCnbMqyimvlIoOrjkAUQNTJKHLd
    EPxhCnbMqyimvlIoOrjkAUQNTJKHaR =EPxhCnbMqyimvlIoOrjkAUQNTJKHLg
   EPxhCnbMqyimvlIoOrjkAUQNTJKHaw={'title':EPxhCnbMqyimvlIoOrjkAUQNTJKHau,'plot':EPxhCnbMqyimvlIoOrjkAUQNTJKHau}
   if EPxhCnbMqyimvlIoOrjkAUQNTJKHap.get('mode')=='XXX':EPxhCnbMqyimvlIoOrjkAUQNTJKHaw=EPxhCnbMqyimvlIoOrjkAUQNTJKHLX
   if 'icon' in EPxhCnbMqyimvlIoOrjkAUQNTJKHap:EPxhCnbMqyimvlIoOrjkAUQNTJKHaf=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',EPxhCnbMqyimvlIoOrjkAUQNTJKHap.get('icon')) 
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.add_dir(EPxhCnbMqyimvlIoOrjkAUQNTJKHau,sublabel='',img=EPxhCnbMqyimvlIoOrjkAUQNTJKHaf,infoLabels=EPxhCnbMqyimvlIoOrjkAUQNTJKHaw,isFolder=EPxhCnbMqyimvlIoOrjkAUQNTJKHaz,params=EPxhCnbMqyimvlIoOrjkAUQNTJKHas,isLink=EPxhCnbMqyimvlIoOrjkAUQNTJKHaR)
  xbmcplugin.endOfDirectory(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW._addon_handle,cacheToDisc=EPxhCnbMqyimvlIoOrjkAUQNTJKHLd)
 def dp_Search_Group(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW,args):
  if 'search_key' in args:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHea=args.get('search_key')
  else:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHea=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not EPxhCnbMqyimvlIoOrjkAUQNTJKHea:
    return
  for EPxhCnbMqyimvlIoOrjkAUQNTJKHeY in EPxhCnbMqyimvlIoOrjkAUQNTJKHSY:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHec =EPxhCnbMqyimvlIoOrjkAUQNTJKHeY.get('mode')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHeD=EPxhCnbMqyimvlIoOrjkAUQNTJKHeY.get('sType')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHau=EPxhCnbMqyimvlIoOrjkAUQNTJKHeY.get('title')
   (EPxhCnbMqyimvlIoOrjkAUQNTJKHeB,EPxhCnbMqyimvlIoOrjkAUQNTJKHeL)=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.Get_Search_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHea,EPxhCnbMqyimvlIoOrjkAUQNTJKHeD,1,exclusion21=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.get_settings_exclusion21())
   EPxhCnbMqyimvlIoOrjkAUQNTJKHaw={'plot':'검색어 : '+EPxhCnbMqyimvlIoOrjkAUQNTJKHea+'\n\n'+EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.Search_FreeList(EPxhCnbMqyimvlIoOrjkAUQNTJKHeB)}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas={'mode':EPxhCnbMqyimvlIoOrjkAUQNTJKHec,'sType':EPxhCnbMqyimvlIoOrjkAUQNTJKHeD,'search_key':EPxhCnbMqyimvlIoOrjkAUQNTJKHea,'page':'1',}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.add_dir(EPxhCnbMqyimvlIoOrjkAUQNTJKHau,sublabel='',img='',infoLabels=EPxhCnbMqyimvlIoOrjkAUQNTJKHaw,isFolder=EPxhCnbMqyimvlIoOrjkAUQNTJKHLd,params=EPxhCnbMqyimvlIoOrjkAUQNTJKHas)
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHLz(EPxhCnbMqyimvlIoOrjkAUQNTJKHSY)>0:xbmcplugin.endOfDirectory(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW._addon_handle,cacheToDisc=EPxhCnbMqyimvlIoOrjkAUQNTJKHLd)
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.Save_Searched_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHea)
 def Search_FreeList(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW,search_list):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHeW=''
  EPxhCnbMqyimvlIoOrjkAUQNTJKHet=7
  try:
   if EPxhCnbMqyimvlIoOrjkAUQNTJKHLz(search_list)==0:return '검색결과 없음'
   for i in EPxhCnbMqyimvlIoOrjkAUQNTJKHLR(EPxhCnbMqyimvlIoOrjkAUQNTJKHLz(search_list)):
    if i>=EPxhCnbMqyimvlIoOrjkAUQNTJKHet:
     EPxhCnbMqyimvlIoOrjkAUQNTJKHeW=EPxhCnbMqyimvlIoOrjkAUQNTJKHeW+'...'
     break
    EPxhCnbMqyimvlIoOrjkAUQNTJKHeW=EPxhCnbMqyimvlIoOrjkAUQNTJKHeW+search_list[i]['title']+'\n'
  except:
   return ''
  return EPxhCnbMqyimvlIoOrjkAUQNTJKHeW
 def dp_Watch_Group(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW,args):
  for EPxhCnbMqyimvlIoOrjkAUQNTJKHeF in EPxhCnbMqyimvlIoOrjkAUQNTJKHSc:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHau=EPxhCnbMqyimvlIoOrjkAUQNTJKHeF.get('title')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas={'mode':EPxhCnbMqyimvlIoOrjkAUQNTJKHeF.get('mode'),'sType':EPxhCnbMqyimvlIoOrjkAUQNTJKHeF.get('sType')}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.add_dir(EPxhCnbMqyimvlIoOrjkAUQNTJKHau,sublabel='',img='',infoLabels=EPxhCnbMqyimvlIoOrjkAUQNTJKHLX,isFolder=EPxhCnbMqyimvlIoOrjkAUQNTJKHLd,params=EPxhCnbMqyimvlIoOrjkAUQNTJKHas)
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHLz(EPxhCnbMqyimvlIoOrjkAUQNTJKHSc)>0:xbmcplugin.endOfDirectory(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW._addon_handle,cacheToDisc=EPxhCnbMqyimvlIoOrjkAUQNTJKHLd)
 def dp_Search_History(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW,args):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHeX=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.Load_List_File('search')
  for EPxhCnbMqyimvlIoOrjkAUQNTJKHeu in EPxhCnbMqyimvlIoOrjkAUQNTJKHeX:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHed=EPxhCnbMqyimvlIoOrjkAUQNTJKHLp(urllib.parse.parse_qsl(EPxhCnbMqyimvlIoOrjkAUQNTJKHeu))
   EPxhCnbMqyimvlIoOrjkAUQNTJKHeg=EPxhCnbMqyimvlIoOrjkAUQNTJKHed.get('skey').strip()
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas={'mode':'SEARCH_GROUP','search_key':EPxhCnbMqyimvlIoOrjkAUQNTJKHeg,}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHeV={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':EPxhCnbMqyimvlIoOrjkAUQNTJKHeg,'vType':'-',}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHep=urllib.parse.urlencode(EPxhCnbMqyimvlIoOrjkAUQNTJKHeV)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHef=[('선택된 검색어 ( %s ) 삭제'%(EPxhCnbMqyimvlIoOrjkAUQNTJKHeg),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(EPxhCnbMqyimvlIoOrjkAUQNTJKHep))]
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.add_dir(EPxhCnbMqyimvlIoOrjkAUQNTJKHeg,sublabel='',img=EPxhCnbMqyimvlIoOrjkAUQNTJKHLX,infoLabels=EPxhCnbMqyimvlIoOrjkAUQNTJKHLX,isFolder=EPxhCnbMqyimvlIoOrjkAUQNTJKHLd,params=EPxhCnbMqyimvlIoOrjkAUQNTJKHas,ContextMenu=EPxhCnbMqyimvlIoOrjkAUQNTJKHef)
  EPxhCnbMqyimvlIoOrjkAUQNTJKHes={'plot':'검색목록 전체를 삭제합니다.'}
  EPxhCnbMqyimvlIoOrjkAUQNTJKHau='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  EPxhCnbMqyimvlIoOrjkAUQNTJKHas={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  EPxhCnbMqyimvlIoOrjkAUQNTJKHaf=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.add_dir(EPxhCnbMqyimvlIoOrjkAUQNTJKHau,sublabel='',img=EPxhCnbMqyimvlIoOrjkAUQNTJKHaf,infoLabels=EPxhCnbMqyimvlIoOrjkAUQNTJKHes,isFolder=EPxhCnbMqyimvlIoOrjkAUQNTJKHLg,params=EPxhCnbMqyimvlIoOrjkAUQNTJKHas,isLink=EPxhCnbMqyimvlIoOrjkAUQNTJKHLd)
  xbmcplugin.endOfDirectory(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW._addon_handle,cacheToDisc=EPxhCnbMqyimvlIoOrjkAUQNTJKHLg)
 def dp_Search_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW,args):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHeD =args.get('sType')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHez =EPxhCnbMqyimvlIoOrjkAUQNTJKHLu(args.get('page'))
  if 'search_key' in args:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHea=args.get('search_key')
  else:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHea=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not EPxhCnbMqyimvlIoOrjkAUQNTJKHea:
    xbmcplugin.endOfDirectory(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW._addon_handle)
    return
  EPxhCnbMqyimvlIoOrjkAUQNTJKHeR,EPxhCnbMqyimvlIoOrjkAUQNTJKHeL=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.Get_Search_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHea,EPxhCnbMqyimvlIoOrjkAUQNTJKHeD,EPxhCnbMqyimvlIoOrjkAUQNTJKHez,exclusion21=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.get_settings_exclusion21())
  for EPxhCnbMqyimvlIoOrjkAUQNTJKHew in EPxhCnbMqyimvlIoOrjkAUQNTJKHeR:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHeG =EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('videoid')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYS =EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('vidtype')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHau =EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('title')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYa=EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('thumbnail')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYe =EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('age')
   if EPxhCnbMqyimvlIoOrjkAUQNTJKHYe=='18' or EPxhCnbMqyimvlIoOrjkAUQNTJKHYe=='19' or EPxhCnbMqyimvlIoOrjkAUQNTJKHYe=='21':EPxhCnbMqyimvlIoOrjkAUQNTJKHau+=' (%s)'%(EPxhCnbMqyimvlIoOrjkAUQNTJKHYe)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHes={'mediatype':'tvshow' if EPxhCnbMqyimvlIoOrjkAUQNTJKHeD=='vod' else 'movie','mpaa':EPxhCnbMqyimvlIoOrjkAUQNTJKHYe,'title':EPxhCnbMqyimvlIoOrjkAUQNTJKHau,'plot':EPxhCnbMqyimvlIoOrjkAUQNTJKHau}
   if EPxhCnbMqyimvlIoOrjkAUQNTJKHeD=='vod':
    EPxhCnbMqyimvlIoOrjkAUQNTJKHas={'mode':'EPISODE_LIST','seasonid':EPxhCnbMqyimvlIoOrjkAUQNTJKHeG,'page':'1',}
    EPxhCnbMqyimvlIoOrjkAUQNTJKHaz=EPxhCnbMqyimvlIoOrjkAUQNTJKHLd
   else:
    EPxhCnbMqyimvlIoOrjkAUQNTJKHas={'mode':'MOVIE','contentid':EPxhCnbMqyimvlIoOrjkAUQNTJKHeG,'title':EPxhCnbMqyimvlIoOrjkAUQNTJKHau,'thumbnail':EPxhCnbMqyimvlIoOrjkAUQNTJKHYa,'age':EPxhCnbMqyimvlIoOrjkAUQNTJKHYe,}
    EPxhCnbMqyimvlIoOrjkAUQNTJKHaz=EPxhCnbMqyimvlIoOrjkAUQNTJKHLg
   EPxhCnbMqyimvlIoOrjkAUQNTJKHef=[]
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYc={'mode':'VIEW_DETAIL','values':{'videoid':EPxhCnbMqyimvlIoOrjkAUQNTJKHeG,'vidtype':'tvshow' if EPxhCnbMqyimvlIoOrjkAUQNTJKHeD=='vod' else 'movie','contenttype':EPxhCnbMqyimvlIoOrjkAUQNTJKHYS,}}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYD=json.dumps(EPxhCnbMqyimvlIoOrjkAUQNTJKHYc,separators=(',',':'))
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYD=base64.standard_b64encode(EPxhCnbMqyimvlIoOrjkAUQNTJKHYD.encode()).decode('utf-8')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYD=EPxhCnbMqyimvlIoOrjkAUQNTJKHYD.replace('+','%2B')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYB='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(EPxhCnbMqyimvlIoOrjkAUQNTJKHYD)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHef.append(('상세정보 조회',EPxhCnbMqyimvlIoOrjkAUQNTJKHYB))
   if EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.get_settings_makebookmark():
    EPxhCnbMqyimvlIoOrjkAUQNTJKHYc={'videoid':EPxhCnbMqyimvlIoOrjkAUQNTJKHeG,'vidtype':'tvshow' if EPxhCnbMqyimvlIoOrjkAUQNTJKHeD=='vod' else 'movie','vtitle':EPxhCnbMqyimvlIoOrjkAUQNTJKHau,'vsubtitle':'','contenttype':EPxhCnbMqyimvlIoOrjkAUQNTJKHYS,}
    EPxhCnbMqyimvlIoOrjkAUQNTJKHYL=json.dumps(EPxhCnbMqyimvlIoOrjkAUQNTJKHYc)
    EPxhCnbMqyimvlIoOrjkAUQNTJKHYL=urllib.parse.quote(EPxhCnbMqyimvlIoOrjkAUQNTJKHYL)
    EPxhCnbMqyimvlIoOrjkAUQNTJKHYB='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(EPxhCnbMqyimvlIoOrjkAUQNTJKHYL)
    EPxhCnbMqyimvlIoOrjkAUQNTJKHef.append(('(통합) 찜 영상에 추가',EPxhCnbMqyimvlIoOrjkAUQNTJKHYB))
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.add_dir(EPxhCnbMqyimvlIoOrjkAUQNTJKHau,sublabel='',img=EPxhCnbMqyimvlIoOrjkAUQNTJKHYa,infoLabels=EPxhCnbMqyimvlIoOrjkAUQNTJKHes,isFolder=EPxhCnbMqyimvlIoOrjkAUQNTJKHaz,params=EPxhCnbMqyimvlIoOrjkAUQNTJKHas,ContextMenu=EPxhCnbMqyimvlIoOrjkAUQNTJKHef)
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHeL:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas['mode'] ='SEARCH_LIST' 
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas['sType']=EPxhCnbMqyimvlIoOrjkAUQNTJKHeD 
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas['page'] =EPxhCnbMqyimvlIoOrjkAUQNTJKHLw(EPxhCnbMqyimvlIoOrjkAUQNTJKHez+1)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas['search_key']=EPxhCnbMqyimvlIoOrjkAUQNTJKHea
   EPxhCnbMqyimvlIoOrjkAUQNTJKHau='[B]%s >>[/B]'%'다음 페이지'
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYW=EPxhCnbMqyimvlIoOrjkAUQNTJKHLw(EPxhCnbMqyimvlIoOrjkAUQNTJKHez+1)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHaf=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.add_dir(EPxhCnbMqyimvlIoOrjkAUQNTJKHau,sublabel=EPxhCnbMqyimvlIoOrjkAUQNTJKHYW,img=EPxhCnbMqyimvlIoOrjkAUQNTJKHaf,infoLabels=EPxhCnbMqyimvlIoOrjkAUQNTJKHLX,isFolder=EPxhCnbMqyimvlIoOrjkAUQNTJKHLd,params=EPxhCnbMqyimvlIoOrjkAUQNTJKHas)
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHeD=='movie':xbmcplugin.setContent(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW._addon_handle,'movies')
  else:xbmcplugin.setContent(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW._addon_handle,cacheToDisc=EPxhCnbMqyimvlIoOrjkAUQNTJKHLg)
 def dp_Watch_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW,args):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHeD =args.get('sType')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHat=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.get_settings_direct_replay()
  EPxhCnbMqyimvlIoOrjkAUQNTJKHeR=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.Load_List_File(EPxhCnbMqyimvlIoOrjkAUQNTJKHeD)
  for EPxhCnbMqyimvlIoOrjkAUQNTJKHew in EPxhCnbMqyimvlIoOrjkAUQNTJKHeR:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHed=EPxhCnbMqyimvlIoOrjkAUQNTJKHLp(urllib.parse.parse_qsl(EPxhCnbMqyimvlIoOrjkAUQNTJKHew))
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYt =EPxhCnbMqyimvlIoOrjkAUQNTJKHed.get('code').strip()
   EPxhCnbMqyimvlIoOrjkAUQNTJKHau =EPxhCnbMqyimvlIoOrjkAUQNTJKHed.get('title').strip()
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYW =EPxhCnbMqyimvlIoOrjkAUQNTJKHed.get('subtitle').strip()
   if EPxhCnbMqyimvlIoOrjkAUQNTJKHYW=='None':EPxhCnbMqyimvlIoOrjkAUQNTJKHYW=''
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYa=EPxhCnbMqyimvlIoOrjkAUQNTJKHed.get('img').strip()
   EPxhCnbMqyimvlIoOrjkAUQNTJKHeG =EPxhCnbMqyimvlIoOrjkAUQNTJKHed.get('videoid').strip()
   try:
    EPxhCnbMqyimvlIoOrjkAUQNTJKHYa=EPxhCnbMqyimvlIoOrjkAUQNTJKHYa.replace('\'','\"')
    EPxhCnbMqyimvlIoOrjkAUQNTJKHYa=json.loads(EPxhCnbMqyimvlIoOrjkAUQNTJKHYa)
   except:
    EPxhCnbMqyimvlIoOrjkAUQNTJKHLX
   EPxhCnbMqyimvlIoOrjkAUQNTJKHes={'plot':'%s\n%s'%(EPxhCnbMqyimvlIoOrjkAUQNTJKHau,EPxhCnbMqyimvlIoOrjkAUQNTJKHYW)}
   if EPxhCnbMqyimvlIoOrjkAUQNTJKHeD=='vod':
    if EPxhCnbMqyimvlIoOrjkAUQNTJKHat==EPxhCnbMqyimvlIoOrjkAUQNTJKHLg or EPxhCnbMqyimvlIoOrjkAUQNTJKHeG==EPxhCnbMqyimvlIoOrjkAUQNTJKHLX:
     EPxhCnbMqyimvlIoOrjkAUQNTJKHes['mediatype']='tvshow'
     EPxhCnbMqyimvlIoOrjkAUQNTJKHas={'mode':'SEASON_LIST','videoid':EPxhCnbMqyimvlIoOrjkAUQNTJKHeG,'vidtype':'contentid',}
     EPxhCnbMqyimvlIoOrjkAUQNTJKHaz=EPxhCnbMqyimvlIoOrjkAUQNTJKHLd
    else:
     EPxhCnbMqyimvlIoOrjkAUQNTJKHes['mediatype']='episode'
     EPxhCnbMqyimvlIoOrjkAUQNTJKHas={'mode':'VOD','programid':EPxhCnbMqyimvlIoOrjkAUQNTJKHYt,'contentid':EPxhCnbMqyimvlIoOrjkAUQNTJKHeG,'title':EPxhCnbMqyimvlIoOrjkAUQNTJKHau,'subtitle':EPxhCnbMqyimvlIoOrjkAUQNTJKHYW,'thumbnail':EPxhCnbMqyimvlIoOrjkAUQNTJKHYa}
     EPxhCnbMqyimvlIoOrjkAUQNTJKHaz=EPxhCnbMqyimvlIoOrjkAUQNTJKHLg
   else:
    EPxhCnbMqyimvlIoOrjkAUQNTJKHes['mediatype']='movie'
    EPxhCnbMqyimvlIoOrjkAUQNTJKHas={'mode':'MOVIE','contentid':EPxhCnbMqyimvlIoOrjkAUQNTJKHYt,'title':EPxhCnbMqyimvlIoOrjkAUQNTJKHau,'subtitle':EPxhCnbMqyimvlIoOrjkAUQNTJKHYW,'thumbnail':EPxhCnbMqyimvlIoOrjkAUQNTJKHYa}
    EPxhCnbMqyimvlIoOrjkAUQNTJKHaz=EPxhCnbMqyimvlIoOrjkAUQNTJKHLg
   EPxhCnbMqyimvlIoOrjkAUQNTJKHeV={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':EPxhCnbMqyimvlIoOrjkAUQNTJKHYt,'vType':EPxhCnbMqyimvlIoOrjkAUQNTJKHeD,}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHep=urllib.parse.urlencode(EPxhCnbMqyimvlIoOrjkAUQNTJKHeV)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHef=[('선택된 시청이력 ( %s ) 삭제'%(EPxhCnbMqyimvlIoOrjkAUQNTJKHau),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(EPxhCnbMqyimvlIoOrjkAUQNTJKHep))]
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.add_dir(EPxhCnbMqyimvlIoOrjkAUQNTJKHau,sublabel=EPxhCnbMqyimvlIoOrjkAUQNTJKHYW,img=EPxhCnbMqyimvlIoOrjkAUQNTJKHYa,infoLabels=EPxhCnbMqyimvlIoOrjkAUQNTJKHes,isFolder=EPxhCnbMqyimvlIoOrjkAUQNTJKHaz,params=EPxhCnbMqyimvlIoOrjkAUQNTJKHas,ContextMenu=EPxhCnbMqyimvlIoOrjkAUQNTJKHef)
  EPxhCnbMqyimvlIoOrjkAUQNTJKHes={'plot':'시청목록을 삭제합니다.'}
  EPxhCnbMqyimvlIoOrjkAUQNTJKHau='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  EPxhCnbMqyimvlIoOrjkAUQNTJKHas={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':EPxhCnbMqyimvlIoOrjkAUQNTJKHeD,}
  EPxhCnbMqyimvlIoOrjkAUQNTJKHaf=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.add_dir(EPxhCnbMqyimvlIoOrjkAUQNTJKHau,sublabel='',img=EPxhCnbMqyimvlIoOrjkAUQNTJKHaf,infoLabels=EPxhCnbMqyimvlIoOrjkAUQNTJKHes,isFolder=EPxhCnbMqyimvlIoOrjkAUQNTJKHLg,params=EPxhCnbMqyimvlIoOrjkAUQNTJKHas,isLink=EPxhCnbMqyimvlIoOrjkAUQNTJKHLd)
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHeD=='movie':xbmcplugin.setContent(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW._addon_handle,'movies')
  else:xbmcplugin.setContent(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW._addon_handle,cacheToDisc=EPxhCnbMqyimvlIoOrjkAUQNTJKHLg)
 def Load_List_File(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW,stype): 
  try:
   if stype=='search':
    EPxhCnbMqyimvlIoOrjkAUQNTJKHYF=EPxhCnbMqyimvlIoOrjkAUQNTJKHSL
   elif stype in['vod','movie']:
    EPxhCnbMqyimvlIoOrjkAUQNTJKHYF=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   else:
    return[]
   fp=EPxhCnbMqyimvlIoOrjkAUQNTJKHLG(EPxhCnbMqyimvlIoOrjkAUQNTJKHYF,'r',-1,'utf-8')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYX=fp.readlines()
   fp.close()
  except:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYX=[]
  return EPxhCnbMqyimvlIoOrjkAUQNTJKHYX
 def Save_Watched_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW,EPxhCnbMqyimvlIoOrjkAUQNTJKHBs,EPxhCnbMqyimvlIoOrjkAUQNTJKHSX):
  try:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYu=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%EPxhCnbMqyimvlIoOrjkAUQNTJKHBs))
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYd=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.Load_List_File(EPxhCnbMqyimvlIoOrjkAUQNTJKHBs) 
   fp=EPxhCnbMqyimvlIoOrjkAUQNTJKHLG(EPxhCnbMqyimvlIoOrjkAUQNTJKHYu,'w',-1,'utf-8')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYg=urllib.parse.urlencode(EPxhCnbMqyimvlIoOrjkAUQNTJKHSX)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYg=EPxhCnbMqyimvlIoOrjkAUQNTJKHYg+'\n'
   fp.write(EPxhCnbMqyimvlIoOrjkAUQNTJKHYg)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYV=0
   for EPxhCnbMqyimvlIoOrjkAUQNTJKHYp in EPxhCnbMqyimvlIoOrjkAUQNTJKHYd:
    EPxhCnbMqyimvlIoOrjkAUQNTJKHYf=EPxhCnbMqyimvlIoOrjkAUQNTJKHLp(urllib.parse.parse_qsl(EPxhCnbMqyimvlIoOrjkAUQNTJKHYp))
    EPxhCnbMqyimvlIoOrjkAUQNTJKHYs=EPxhCnbMqyimvlIoOrjkAUQNTJKHSX.get('code').strip()
    EPxhCnbMqyimvlIoOrjkAUQNTJKHYz=EPxhCnbMqyimvlIoOrjkAUQNTJKHYf.get('code').strip()
    if EPxhCnbMqyimvlIoOrjkAUQNTJKHBs=='vod' and EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.get_settings_direct_replay()==EPxhCnbMqyimvlIoOrjkAUQNTJKHLd:
     EPxhCnbMqyimvlIoOrjkAUQNTJKHYs=EPxhCnbMqyimvlIoOrjkAUQNTJKHSX.get('videoid').strip()
     EPxhCnbMqyimvlIoOrjkAUQNTJKHYz=EPxhCnbMqyimvlIoOrjkAUQNTJKHYf.get('videoid').strip()if EPxhCnbMqyimvlIoOrjkAUQNTJKHYz!=EPxhCnbMqyimvlIoOrjkAUQNTJKHLX else '-'
    if EPxhCnbMqyimvlIoOrjkAUQNTJKHYs!=EPxhCnbMqyimvlIoOrjkAUQNTJKHYz:
     fp.write(EPxhCnbMqyimvlIoOrjkAUQNTJKHYp)
     EPxhCnbMqyimvlIoOrjkAUQNTJKHYV+=1
     if EPxhCnbMqyimvlIoOrjkAUQNTJKHYV>=50:break
   fp.close()
  except:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHLX
 def dp_History_Remove(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW,args):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHYR=args.get('delType')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHYw =args.get('sKey')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHYG =args.get('vType')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSd=xbmcgui.Dialog()
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHYR=='SEARCH_ALL':
   EPxhCnbMqyimvlIoOrjkAUQNTJKHcS=EPxhCnbMqyimvlIoOrjkAUQNTJKHSd.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif EPxhCnbMqyimvlIoOrjkAUQNTJKHYR=='SEARCH_ONE':
   EPxhCnbMqyimvlIoOrjkAUQNTJKHcS=EPxhCnbMqyimvlIoOrjkAUQNTJKHSd.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif EPxhCnbMqyimvlIoOrjkAUQNTJKHYR=='WATCH_ALL':
   EPxhCnbMqyimvlIoOrjkAUQNTJKHcS=EPxhCnbMqyimvlIoOrjkAUQNTJKHSd.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif EPxhCnbMqyimvlIoOrjkAUQNTJKHYR=='WATCH_ONE':
   EPxhCnbMqyimvlIoOrjkAUQNTJKHcS=EPxhCnbMqyimvlIoOrjkAUQNTJKHSd.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHcS==EPxhCnbMqyimvlIoOrjkAUQNTJKHLg:sys.exit()
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHYR=='SEARCH_ALL':
   if os.path.isfile(EPxhCnbMqyimvlIoOrjkAUQNTJKHSL):os.remove(EPxhCnbMqyimvlIoOrjkAUQNTJKHSL)
  elif EPxhCnbMqyimvlIoOrjkAUQNTJKHYR=='SEARCH_ONE':
   try:
    EPxhCnbMqyimvlIoOrjkAUQNTJKHYF=EPxhCnbMqyimvlIoOrjkAUQNTJKHSL
    EPxhCnbMqyimvlIoOrjkAUQNTJKHYd=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.Load_List_File('search') 
    fp=EPxhCnbMqyimvlIoOrjkAUQNTJKHLG(EPxhCnbMqyimvlIoOrjkAUQNTJKHYF,'w',-1,'utf-8')
    for EPxhCnbMqyimvlIoOrjkAUQNTJKHYp in EPxhCnbMqyimvlIoOrjkAUQNTJKHYd:
     EPxhCnbMqyimvlIoOrjkAUQNTJKHYf=EPxhCnbMqyimvlIoOrjkAUQNTJKHLp(urllib.parse.parse_qsl(EPxhCnbMqyimvlIoOrjkAUQNTJKHYp))
     EPxhCnbMqyimvlIoOrjkAUQNTJKHca=EPxhCnbMqyimvlIoOrjkAUQNTJKHYf.get('skey').strip()
     if EPxhCnbMqyimvlIoOrjkAUQNTJKHYw!=EPxhCnbMqyimvlIoOrjkAUQNTJKHca:
      fp.write(EPxhCnbMqyimvlIoOrjkAUQNTJKHYp)
    fp.close()
   except:
    EPxhCnbMqyimvlIoOrjkAUQNTJKHLX
  elif EPxhCnbMqyimvlIoOrjkAUQNTJKHYR=='WATCH_ALL':
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYF=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%EPxhCnbMqyimvlIoOrjkAUQNTJKHYG))
   if os.path.isfile(EPxhCnbMqyimvlIoOrjkAUQNTJKHYF):os.remove(EPxhCnbMqyimvlIoOrjkAUQNTJKHYF)
  elif EPxhCnbMqyimvlIoOrjkAUQNTJKHYR=='WATCH_ONE':
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYF=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%EPxhCnbMqyimvlIoOrjkAUQNTJKHYG))
   try:
    EPxhCnbMqyimvlIoOrjkAUQNTJKHYd=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.Load_List_File(EPxhCnbMqyimvlIoOrjkAUQNTJKHYG) 
    fp=EPxhCnbMqyimvlIoOrjkAUQNTJKHLG(EPxhCnbMqyimvlIoOrjkAUQNTJKHYF,'w',-1,'utf-8')
    for EPxhCnbMqyimvlIoOrjkAUQNTJKHYp in EPxhCnbMqyimvlIoOrjkAUQNTJKHYd:
     EPxhCnbMqyimvlIoOrjkAUQNTJKHYf=EPxhCnbMqyimvlIoOrjkAUQNTJKHLp(urllib.parse.parse_qsl(EPxhCnbMqyimvlIoOrjkAUQNTJKHYp))
     EPxhCnbMqyimvlIoOrjkAUQNTJKHca=EPxhCnbMqyimvlIoOrjkAUQNTJKHYf.get('code').strip()
     if EPxhCnbMqyimvlIoOrjkAUQNTJKHYw!=EPxhCnbMqyimvlIoOrjkAUQNTJKHca:
      fp.write(EPxhCnbMqyimvlIoOrjkAUQNTJKHYp)
    fp.close()
   except:
    EPxhCnbMqyimvlIoOrjkAUQNTJKHLX
  xbmc.executebuiltin("Container.Refresh")
 def Save_Searched_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW,EPxhCnbMqyimvlIoOrjkAUQNTJKHea):
  try:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHce=EPxhCnbMqyimvlIoOrjkAUQNTJKHSL
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYd=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.Load_List_File('search') 
   EPxhCnbMqyimvlIoOrjkAUQNTJKHcY={'skey':EPxhCnbMqyimvlIoOrjkAUQNTJKHea.strip()}
   fp=EPxhCnbMqyimvlIoOrjkAUQNTJKHLG(EPxhCnbMqyimvlIoOrjkAUQNTJKHce,'w',-1,'utf-8')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYg=urllib.parse.urlencode(EPxhCnbMqyimvlIoOrjkAUQNTJKHcY)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYg=EPxhCnbMqyimvlIoOrjkAUQNTJKHYg+'\n'
   fp.write(EPxhCnbMqyimvlIoOrjkAUQNTJKHYg)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYV=0
   for EPxhCnbMqyimvlIoOrjkAUQNTJKHYp in EPxhCnbMqyimvlIoOrjkAUQNTJKHYd:
    EPxhCnbMqyimvlIoOrjkAUQNTJKHYf=EPxhCnbMqyimvlIoOrjkAUQNTJKHLp(urllib.parse.parse_qsl(EPxhCnbMqyimvlIoOrjkAUQNTJKHYp))
    EPxhCnbMqyimvlIoOrjkAUQNTJKHYs=EPxhCnbMqyimvlIoOrjkAUQNTJKHcY.get('skey').strip()
    EPxhCnbMqyimvlIoOrjkAUQNTJKHYz=EPxhCnbMqyimvlIoOrjkAUQNTJKHYf.get('skey').strip()
    if EPxhCnbMqyimvlIoOrjkAUQNTJKHYs!=EPxhCnbMqyimvlIoOrjkAUQNTJKHYz:
     fp.write(EPxhCnbMqyimvlIoOrjkAUQNTJKHYp)
     EPxhCnbMqyimvlIoOrjkAUQNTJKHYV+=1
     if EPxhCnbMqyimvlIoOrjkAUQNTJKHYV>=50:break
   fp.close()
  except:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHLX
 def dp_Global_Search(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW,args):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHec=args.get('mode')
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHec=='TOTAL_SEARCH':
   EPxhCnbMqyimvlIoOrjkAUQNTJKHcD='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHcD='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(EPxhCnbMqyimvlIoOrjkAUQNTJKHcD)
 def dp_Bookmark_Menu(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW,args):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHcD='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(EPxhCnbMqyimvlIoOrjkAUQNTJKHcD)
 def login_main(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW):
  (EPxhCnbMqyimvlIoOrjkAUQNTJKHcB,EPxhCnbMqyimvlIoOrjkAUQNTJKHcL,EPxhCnbMqyimvlIoOrjkAUQNTJKHcW)=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.get_settings_account()
  if not(EPxhCnbMqyimvlIoOrjkAUQNTJKHcB and EPxhCnbMqyimvlIoOrjkAUQNTJKHcL):
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSd=xbmcgui.Dialog()
   EPxhCnbMqyimvlIoOrjkAUQNTJKHcS=EPxhCnbMqyimvlIoOrjkAUQNTJKHSd.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if EPxhCnbMqyimvlIoOrjkAUQNTJKHcS==EPxhCnbMqyimvlIoOrjkAUQNTJKHLd:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.cookiefile_check()==EPxhCnbMqyimvlIoOrjkAUQNTJKHLd:return
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   EPxhCnbMqyimvlIoOrjkAUQNTJKHct=0
   while EPxhCnbMqyimvlIoOrjkAUQNTJKHLd:
    EPxhCnbMqyimvlIoOrjkAUQNTJKHct+=1
    time.sleep(0.05)
    if EPxhCnbMqyimvlIoOrjkAUQNTJKHct>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHcF=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.GetCredential(EPxhCnbMqyimvlIoOrjkAUQNTJKHcB,EPxhCnbMqyimvlIoOrjkAUQNTJKHcL,EPxhCnbMqyimvlIoOrjkAUQNTJKHcW)
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHcF:EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHcF==EPxhCnbMqyimvlIoOrjkAUQNTJKHLg:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_setEpOrderby(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW,args):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHaF =args.get('orderby')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.set_winEpisodeOrderby(EPxhCnbMqyimvlIoOrjkAUQNTJKHaF)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW,args):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHec =args.get('mode')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHcX =args.get('contentid')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHcu =args.get('pvrmode')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHcd=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.get_selQuality()
  EPxhCnbMqyimvlIoOrjkAUQNTJKHaY =EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.get_settings_play()
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.addon_log(EPxhCnbMqyimvlIoOrjkAUQNTJKHcX+' - '+EPxhCnbMqyimvlIoOrjkAUQNTJKHec)
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHec=='SPORTS':
   EPxhCnbMqyimvlIoOrjkAUQNTJKHcg=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.GetSportsURL(EPxhCnbMqyimvlIoOrjkAUQNTJKHcX,EPxhCnbMqyimvlIoOrjkAUQNTJKHcd)
  else:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHcg=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.GetStreamingURL(EPxhCnbMqyimvlIoOrjkAUQNTJKHec,EPxhCnbMqyimvlIoOrjkAUQNTJKHcX,EPxhCnbMqyimvlIoOrjkAUQNTJKHcd,EPxhCnbMqyimvlIoOrjkAUQNTJKHcu,playOption=EPxhCnbMqyimvlIoOrjkAUQNTJKHaY)
  EPxhCnbMqyimvlIoOrjkAUQNTJKHcV={'user-agent':EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.USER_AGENT}
  EPxhCnbMqyimvlIoOrjkAUQNTJKHcp=EPxhCnbMqyimvlIoOrjkAUQNTJKHcg['stream_cookie'] 
  EPxhCnbMqyimvlIoOrjkAUQNTJKHcf=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.make_stream_header(EPxhCnbMqyimvlIoOrjkAUQNTJKHcV,EPxhCnbMqyimvlIoOrjkAUQNTJKHcp)
  EPxhCnbMqyimvlIoOrjkAUQNTJKHcs='{}|{}'.format(EPxhCnbMqyimvlIoOrjkAUQNTJKHcg['stream_url'],EPxhCnbMqyimvlIoOrjkAUQNTJKHcf)
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.addon_log('surl : '+EPxhCnbMqyimvlIoOrjkAUQNTJKHcs)
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHcg['stream_url']=='':
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.addon_noti(__language__(30907).encode('utf8'))
   return
  EPxhCnbMqyimvlIoOrjkAUQNTJKHac,EPxhCnbMqyimvlIoOrjkAUQNTJKHaD=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.get_settings_proxyport()
  EPxhCnbMqyimvlIoOrjkAUQNTJKHcz=urllib.parse.urlparse(EPxhCnbMqyimvlIoOrjkAUQNTJKHcg['stream_url'])
  EPxhCnbMqyimvlIoOrjkAUQNTJKHcz=EPxhCnbMqyimvlIoOrjkAUQNTJKHcz.path.strip('/').split('/')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHcz=EPxhCnbMqyimvlIoOrjkAUQNTJKHcz[EPxhCnbMqyimvlIoOrjkAUQNTJKHLz(EPxhCnbMqyimvlIoOrjkAUQNTJKHcz)-1] 
  if (EPxhCnbMqyimvlIoOrjkAUQNTJKHac==EPxhCnbMqyimvlIoOrjkAUQNTJKHLd and args.get('mode')in['VOD','MOVIE']and(EPxhCnbMqyimvlIoOrjkAUQNTJKHcg['playParam']['hdr']=='hdr' or EPxhCnbMqyimvlIoOrjkAUQNTJKHcg['playParam']['uhd']=='uhd')):
   if EPxhCnbMqyimvlIoOrjkAUQNTJKHcz.split('.')[1]=='mpd':
    EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.Wavve_Parse_mpd(EPxhCnbMqyimvlIoOrjkAUQNTJKHcg)
   else:
    EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.Wavve_Parse_m3u8(EPxhCnbMqyimvlIoOrjkAUQNTJKHcg)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHcR={'addon':'wavvem','playOption':EPxhCnbMqyimvlIoOrjkAUQNTJKHaY,}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHcR=json.dumps(EPxhCnbMqyimvlIoOrjkAUQNTJKHcR,separators=(',',':'))
   EPxhCnbMqyimvlIoOrjkAUQNTJKHcR=base64.standard_b64encode(EPxhCnbMqyimvlIoOrjkAUQNTJKHcR.encode()).decode('utf-8')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHcs ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(EPxhCnbMqyimvlIoOrjkAUQNTJKHaD,EPxhCnbMqyimvlIoOrjkAUQNTJKHcs,EPxhCnbMqyimvlIoOrjkAUQNTJKHcR)
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.addon_log('surl : '+EPxhCnbMqyimvlIoOrjkAUQNTJKHcs)
  EPxhCnbMqyimvlIoOrjkAUQNTJKHcw=xbmcgui.ListItem(path=EPxhCnbMqyimvlIoOrjkAUQNTJKHcs)
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHcg['stream_drm']:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.addon_log('!!streaming_drm!!')
   inputstreamhelper.Helper('mpd',drm='com.widevine.alpha').check_inputstream()
   if 'licensetoken' in EPxhCnbMqyimvlIoOrjkAUQNTJKHcg['stream_drm']:
    EPxhCnbMqyimvlIoOrjkAUQNTJKHDS=EPxhCnbMqyimvlIoOrjkAUQNTJKHcg['stream_drm']['licensetoken']
    EPxhCnbMqyimvlIoOrjkAUQNTJKHDa =EPxhCnbMqyimvlIoOrjkAUQNTJKHcg['stream_drm']['licenseurl']
    if EPxhCnbMqyimvlIoOrjkAUQNTJKHec=='MOVIE':
     EPxhCnbMqyimvlIoOrjkAUQNTJKHDe='https://www.wavve.com/player/movie?movieid=%s'%EPxhCnbMqyimvlIoOrjkAUQNTJKHcX
    else:
     EPxhCnbMqyimvlIoOrjkAUQNTJKHDe='https://www.wavve.com/player/vod?programid=%s&page=1'%EPxhCnbMqyimvlIoOrjkAUQNTJKHcX
    EPxhCnbMqyimvlIoOrjkAUQNTJKHDY={'content-type':'application/octet-stream','origin':'https://www.wavve.com','License-Token':EPxhCnbMqyimvlIoOrjkAUQNTJKHDS,'referer':EPxhCnbMqyimvlIoOrjkAUQNTJKHDe,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.USER_AGENT,}
   else:
    EPxhCnbMqyimvlIoOrjkAUQNTJKHDS=EPxhCnbMqyimvlIoOrjkAUQNTJKHcg['stream_drm']['customdata']
    EPxhCnbMqyimvlIoOrjkAUQNTJKHDa =EPxhCnbMqyimvlIoOrjkAUQNTJKHcg['stream_drm']['drmhost']
    if EPxhCnbMqyimvlIoOrjkAUQNTJKHec=='MOVIE':
     EPxhCnbMqyimvlIoOrjkAUQNTJKHDe='https://www.wavve.com/player/movie?movieid=%s'%EPxhCnbMqyimvlIoOrjkAUQNTJKHcX
    else:
     EPxhCnbMqyimvlIoOrjkAUQNTJKHDe='https://www.wavve.com/player/vod?programid=%s&page=1'%EPxhCnbMqyimvlIoOrjkAUQNTJKHcX
    EPxhCnbMqyimvlIoOrjkAUQNTJKHDY={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':EPxhCnbMqyimvlIoOrjkAUQNTJKHDS,'referer':EPxhCnbMqyimvlIoOrjkAUQNTJKHDe,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.USER_AGENT,}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHDc=EPxhCnbMqyimvlIoOrjkAUQNTJKHDa+'|'+urllib.parse.urlencode(EPxhCnbMqyimvlIoOrjkAUQNTJKHDY)+'|R{SSM}|'
   EPxhCnbMqyimvlIoOrjkAUQNTJKHcw.setProperty('inputstream','inputstream.adaptive')
   if EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.KodiVersion<=20:
    EPxhCnbMqyimvlIoOrjkAUQNTJKHcw.setProperty('inputstream.adaptive.manifest_type','mpd')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHcw.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHcw.setProperty('inputstream.adaptive.license_key',EPxhCnbMqyimvlIoOrjkAUQNTJKHDc)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHcw.setProperty('inputstream.adaptive.stream_headers',EPxhCnbMqyimvlIoOrjkAUQNTJKHcf)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHcw.setProperty('inputstream.adaptive.manifest_headers',EPxhCnbMqyimvlIoOrjkAUQNTJKHcf)
  elif EPxhCnbMqyimvlIoOrjkAUQNTJKHec in['VOD','MOVIE']:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHcw.setContentLookup(EPxhCnbMqyimvlIoOrjkAUQNTJKHLg)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHcw.setMimeType('application/x-mpegURL')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHcw.setProperty('inputstream','inputstream.adaptive')
   if EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.KodiVersion<=20:
    if EPxhCnbMqyimvlIoOrjkAUQNTJKHcg['stream_action']=='hls':
     EPxhCnbMqyimvlIoOrjkAUQNTJKHcw.setProperty('inputstream.adaptive.manifest_type','hls')
    else:
     EPxhCnbMqyimvlIoOrjkAUQNTJKHcw.setProperty('inputstream.adaptive.manifest_type','mpd')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHcw.setProperty('inputstream.adaptive.stream_headers',EPxhCnbMqyimvlIoOrjkAUQNTJKHcf)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHcw.setProperty('inputstream.adaptive.manifest_headers',EPxhCnbMqyimvlIoOrjkAUQNTJKHcf)
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHcg['stream_vtt']:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHcw.setSubtitles([EPxhCnbMqyimvlIoOrjkAUQNTJKHcg['stream_vtt']])
  xbmcplugin.setResolvedUrl(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW._addon_handle,EPxhCnbMqyimvlIoOrjkAUQNTJKHLd,EPxhCnbMqyimvlIoOrjkAUQNTJKHcw)
  EPxhCnbMqyimvlIoOrjkAUQNTJKHDB=EPxhCnbMqyimvlIoOrjkAUQNTJKHLg
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHcg['stream_preview']:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.addon_noti(EPxhCnbMqyimvlIoOrjkAUQNTJKHcg['stream_preview'].encode('utf-8'))
   EPxhCnbMqyimvlIoOrjkAUQNTJKHDB=EPxhCnbMqyimvlIoOrjkAUQNTJKHLd
  else:
   if '/preview.' in urllib.parse.urlsplit(EPxhCnbMqyimvlIoOrjkAUQNTJKHcg['stream_url']).path:
    EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.addon_noti(__language__(30908).encode('utf8'))
    EPxhCnbMqyimvlIoOrjkAUQNTJKHDB=EPxhCnbMqyimvlIoOrjkAUQNTJKHLd
  try:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHDL=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and EPxhCnbMqyimvlIoOrjkAUQNTJKHDB==EPxhCnbMqyimvlIoOrjkAUQNTJKHLg and EPxhCnbMqyimvlIoOrjkAUQNTJKHDL!='-':
    EPxhCnbMqyimvlIoOrjkAUQNTJKHas={'code':EPxhCnbMqyimvlIoOrjkAUQNTJKHDL,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.Save_Watched_List(args.get('mode').lower(),EPxhCnbMqyimvlIoOrjkAUQNTJKHas)
  except:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHLX
 def logout(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSd=xbmcgui.Dialog()
  EPxhCnbMqyimvlIoOrjkAUQNTJKHcS=EPxhCnbMqyimvlIoOrjkAUQNTJKHSd.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHcS==EPxhCnbMqyimvlIoOrjkAUQNTJKHLg:sys.exit()
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.Init_WV_Total()
  if os.path.isfile(EPxhCnbMqyimvlIoOrjkAUQNTJKHSB):os.remove(EPxhCnbMqyimvlIoOrjkAUQNTJKHSB)
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHDW =EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.Get_Now_Datetime()
  EPxhCnbMqyimvlIoOrjkAUQNTJKHDt=EPxhCnbMqyimvlIoOrjkAUQNTJKHDW+datetime.timedelta(days=EPxhCnbMqyimvlIoOrjkAUQNTJKHLu(__addon__.getSetting('cache_ttl')))
  (EPxhCnbMqyimvlIoOrjkAUQNTJKHcB,EPxhCnbMqyimvlIoOrjkAUQNTJKHcL,EPxhCnbMqyimvlIoOrjkAUQNTJKHcW)=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.get_settings_account()
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.Save_session_acount(EPxhCnbMqyimvlIoOrjkAUQNTJKHcB,EPxhCnbMqyimvlIoOrjkAUQNTJKHcL,EPxhCnbMqyimvlIoOrjkAUQNTJKHcW)
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.WV['account']['token_limit']=EPxhCnbMqyimvlIoOrjkAUQNTJKHDt.strftime('%Y%m%d')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.JsonFile_Save(EPxhCnbMqyimvlIoOrjkAUQNTJKHSB,EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.WV)
 def cookiefile_check(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.WV=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.JsonFile_Load(EPxhCnbMqyimvlIoOrjkAUQNTJKHSB)
  if 'account' not in EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.WV:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.Init_WV_Total()
   return EPxhCnbMqyimvlIoOrjkAUQNTJKHLg
  if 'uuid' not in EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.WV.get('cookies'):
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.Init_WV_Total()
   return EPxhCnbMqyimvlIoOrjkAUQNTJKHLg
  (EPxhCnbMqyimvlIoOrjkAUQNTJKHDF,EPxhCnbMqyimvlIoOrjkAUQNTJKHDX,EPxhCnbMqyimvlIoOrjkAUQNTJKHDu)=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.get_settings_account()
  (EPxhCnbMqyimvlIoOrjkAUQNTJKHDd,EPxhCnbMqyimvlIoOrjkAUQNTJKHDg,EPxhCnbMqyimvlIoOrjkAUQNTJKHDV)=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.Load_session_acount()
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHDF!=EPxhCnbMqyimvlIoOrjkAUQNTJKHDd or EPxhCnbMqyimvlIoOrjkAUQNTJKHDX!=EPxhCnbMqyimvlIoOrjkAUQNTJKHDg or EPxhCnbMqyimvlIoOrjkAUQNTJKHDu!=EPxhCnbMqyimvlIoOrjkAUQNTJKHDV:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.Init_WV_Total()
   return EPxhCnbMqyimvlIoOrjkAUQNTJKHLg
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHLu(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))>EPxhCnbMqyimvlIoOrjkAUQNTJKHLu(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.WV['account']['token_limit']):
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.Init_WV_Total()
   return EPxhCnbMqyimvlIoOrjkAUQNTJKHLg
  return EPxhCnbMqyimvlIoOrjkAUQNTJKHLd
 def dp_LiveCatagory_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW,args):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHDp =args.get('sCode')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHDf=args.get('sIndex')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHeR,EPxhCnbMqyimvlIoOrjkAUQNTJKHDs=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.Get_LiveCatagory_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHDp,EPxhCnbMqyimvlIoOrjkAUQNTJKHDf)
  for EPxhCnbMqyimvlIoOrjkAUQNTJKHew in EPxhCnbMqyimvlIoOrjkAUQNTJKHeR:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHau =EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('title')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas={'mode':'LIVE_LIST','genre':EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('genre'),'baseapi':EPxhCnbMqyimvlIoOrjkAUQNTJKHDs}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHaw={'title':EPxhCnbMqyimvlIoOrjkAUQNTJKHau,'plot':EPxhCnbMqyimvlIoOrjkAUQNTJKHau}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.add_dir(EPxhCnbMqyimvlIoOrjkAUQNTJKHau,sublabel='',img='',infoLabels=EPxhCnbMqyimvlIoOrjkAUQNTJKHaw,isFolder=EPxhCnbMqyimvlIoOrjkAUQNTJKHLd,params=EPxhCnbMqyimvlIoOrjkAUQNTJKHas)
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHLz(EPxhCnbMqyimvlIoOrjkAUQNTJKHeR)>0:xbmcplugin.endOfDirectory(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW._addon_handle,cacheToDisc=EPxhCnbMqyimvlIoOrjkAUQNTJKHLg)
 def dp_MainCatagory_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW,args):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHDp =args.get('sCode')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHDf=args.get('sIndex')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHeD =args.get('sType')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHeR=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.Get_MainCatagory_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHDp,EPxhCnbMqyimvlIoOrjkAUQNTJKHDf,EPxhCnbMqyimvlIoOrjkAUQNTJKHeD)
  for EPxhCnbMqyimvlIoOrjkAUQNTJKHew in EPxhCnbMqyimvlIoOrjkAUQNTJKHeR:
   if EPxhCnbMqyimvlIoOrjkAUQNTJKHeD in['vod','vod09']:
    if EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('subtype')=='catagory':
     EPxhCnbMqyimvlIoOrjkAUQNTJKHec='PROGRAM_LIST'
    else:
     EPxhCnbMqyimvlIoOrjkAUQNTJKHec='SUPERSECTION_LIST'
   elif EPxhCnbMqyimvlIoOrjkAUQNTJKHeD=='movie':
    EPxhCnbMqyimvlIoOrjkAUQNTJKHec='MOVIE_LIST'
   else:
    EPxhCnbMqyimvlIoOrjkAUQNTJKHec=''
   EPxhCnbMqyimvlIoOrjkAUQNTJKHau='%s (%s)'%(EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('title'),args.get('ordernm'))
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas={'mode':EPxhCnbMqyimvlIoOrjkAUQNTJKHec,'suburl':EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('suburl'),'subapi':EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.get_settings_exclusion21():
    if EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('title')=='성인' or EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('title')=='성인+' or EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('title')=='에로티시즘' or EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('title')=='19':continue
   EPxhCnbMqyimvlIoOrjkAUQNTJKHaw={'title':EPxhCnbMqyimvlIoOrjkAUQNTJKHau,'plot':EPxhCnbMqyimvlIoOrjkAUQNTJKHau}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.add_dir(EPxhCnbMqyimvlIoOrjkAUQNTJKHau,sublabel='',img='',infoLabels=EPxhCnbMqyimvlIoOrjkAUQNTJKHaw,isFolder=EPxhCnbMqyimvlIoOrjkAUQNTJKHLd,params=EPxhCnbMqyimvlIoOrjkAUQNTJKHas)
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHLz(EPxhCnbMqyimvlIoOrjkAUQNTJKHeR)>0:xbmcplugin.endOfDirectory(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW._addon_handle,cacheToDisc=EPxhCnbMqyimvlIoOrjkAUQNTJKHLg)
 def dp_Program_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW,args):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHDz =args.get('subapi')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHez=EPxhCnbMqyimvlIoOrjkAUQNTJKHLu(args.get('page'))
  EPxhCnbMqyimvlIoOrjkAUQNTJKHaF =args.get('orderby')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.addon_log('dp_Program_List')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.addon_log(EPxhCnbMqyimvlIoOrjkAUQNTJKHDz)
  EPxhCnbMqyimvlIoOrjkAUQNTJKHeR,EPxhCnbMqyimvlIoOrjkAUQNTJKHeL=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.Get_Program_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHDz,EPxhCnbMqyimvlIoOrjkAUQNTJKHez,EPxhCnbMqyimvlIoOrjkAUQNTJKHaF)
  for EPxhCnbMqyimvlIoOrjkAUQNTJKHew in EPxhCnbMqyimvlIoOrjkAUQNTJKHeR:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHeG =EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('videoid')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYS =EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('vidtype')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHau =EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('title')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYa=EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('thumbnail')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYe =EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('age')
   if EPxhCnbMqyimvlIoOrjkAUQNTJKHYe=='18' or EPxhCnbMqyimvlIoOrjkAUQNTJKHYe=='19' or EPxhCnbMqyimvlIoOrjkAUQNTJKHYe=='21':EPxhCnbMqyimvlIoOrjkAUQNTJKHau+=' (%s)'%(EPxhCnbMqyimvlIoOrjkAUQNTJKHYe)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHaw={'plot':EPxhCnbMqyimvlIoOrjkAUQNTJKHau,'mpaa':EPxhCnbMqyimvlIoOrjkAUQNTJKHYe,'mediatype':'tvshow','title':EPxhCnbMqyimvlIoOrjkAUQNTJKHau,}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas={'mode':'SEASON_LIST','videoid':EPxhCnbMqyimvlIoOrjkAUQNTJKHeG,'vidtype':EPxhCnbMqyimvlIoOrjkAUQNTJKHYS,}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHef=[]
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYc={'mode':'VIEW_DETAIL','values':{'videoid':EPxhCnbMqyimvlIoOrjkAUQNTJKHeG,'vidtype':'tvshow','contenttype':EPxhCnbMqyimvlIoOrjkAUQNTJKHYS,}}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYD=json.dumps(EPxhCnbMqyimvlIoOrjkAUQNTJKHYc,separators=(',',':'))
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYD=base64.standard_b64encode(EPxhCnbMqyimvlIoOrjkAUQNTJKHYD.encode()).decode('utf-8')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYD=EPxhCnbMqyimvlIoOrjkAUQNTJKHYD.replace('+','%2B')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYB='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(EPxhCnbMqyimvlIoOrjkAUQNTJKHYD)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHef.append(('상세정보 조회',EPxhCnbMqyimvlIoOrjkAUQNTJKHYB))
   if EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.get_settings_makebookmark():
    EPxhCnbMqyimvlIoOrjkAUQNTJKHYc={'videoid':EPxhCnbMqyimvlIoOrjkAUQNTJKHeG,'vidtype':'tvshow','vtitle':EPxhCnbMqyimvlIoOrjkAUQNTJKHau,'vsubtitle':'','contenttype':EPxhCnbMqyimvlIoOrjkAUQNTJKHYS,}
    EPxhCnbMqyimvlIoOrjkAUQNTJKHYL=json.dumps(EPxhCnbMqyimvlIoOrjkAUQNTJKHYc)
    EPxhCnbMqyimvlIoOrjkAUQNTJKHYL=urllib.parse.quote(EPxhCnbMqyimvlIoOrjkAUQNTJKHYL)
    EPxhCnbMqyimvlIoOrjkAUQNTJKHYB='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(EPxhCnbMqyimvlIoOrjkAUQNTJKHYL)
    EPxhCnbMqyimvlIoOrjkAUQNTJKHef.append(('(통합) 찜 영상에 추가',EPxhCnbMqyimvlIoOrjkAUQNTJKHYB))
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.add_dir(EPxhCnbMqyimvlIoOrjkAUQNTJKHau,sublabel='',img=EPxhCnbMqyimvlIoOrjkAUQNTJKHYa,infoLabels=EPxhCnbMqyimvlIoOrjkAUQNTJKHaw,isFolder=EPxhCnbMqyimvlIoOrjkAUQNTJKHLd,params=EPxhCnbMqyimvlIoOrjkAUQNTJKHas,ContextMenu=EPxhCnbMqyimvlIoOrjkAUQNTJKHef)
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHeL:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas={}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas['mode'] ='PROGRAM_LIST' 
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas['subapi']=EPxhCnbMqyimvlIoOrjkAUQNTJKHDz 
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas['page'] =EPxhCnbMqyimvlIoOrjkAUQNTJKHLw(EPxhCnbMqyimvlIoOrjkAUQNTJKHez+1)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHau='[B]%s >>[/B]'%'다음 페이지'
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYW=EPxhCnbMqyimvlIoOrjkAUQNTJKHLw(EPxhCnbMqyimvlIoOrjkAUQNTJKHez+1)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHaf=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.add_dir(EPxhCnbMqyimvlIoOrjkAUQNTJKHau,sublabel=EPxhCnbMqyimvlIoOrjkAUQNTJKHYW,img=EPxhCnbMqyimvlIoOrjkAUQNTJKHaf,infoLabels=EPxhCnbMqyimvlIoOrjkAUQNTJKHLX,isFolder=EPxhCnbMqyimvlIoOrjkAUQNTJKHLd,params=EPxhCnbMqyimvlIoOrjkAUQNTJKHas)
  xbmcplugin.setContent(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW._addon_handle,'tvshows')
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHLz(EPxhCnbMqyimvlIoOrjkAUQNTJKHeR)>0:xbmcplugin.endOfDirectory(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW._addon_handle,cacheToDisc=EPxhCnbMqyimvlIoOrjkAUQNTJKHLg)
 def dp_Season_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW,args):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHeG=args.get('videoid')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHYS=args.get('vidtype')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.addon_log('videoid : '+EPxhCnbMqyimvlIoOrjkAUQNTJKHeG)
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.addon_log('vidtype : '+EPxhCnbMqyimvlIoOrjkAUQNTJKHYS)
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHYS=='contentid':
   EPxhCnbMqyimvlIoOrjkAUQNTJKHcX=EPxhCnbMqyimvlIoOrjkAUQNTJKHeG
   EPxhCnbMqyimvlIoOrjkAUQNTJKHDR =EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.ContentidToSeasonid(EPxhCnbMqyimvlIoOrjkAUQNTJKHeG)
  else:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHcX=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.ProgramidToContentid(EPxhCnbMqyimvlIoOrjkAUQNTJKHeG)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHDR =EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.ContentidToSeasonid(EPxhCnbMqyimvlIoOrjkAUQNTJKHcX)
  EPxhCnbMqyimvlIoOrjkAUQNTJKHDw=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.Get_Season_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHDR)
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHLz(EPxhCnbMqyimvlIoOrjkAUQNTJKHDw)>1:
   for EPxhCnbMqyimvlIoOrjkAUQNTJKHDG in EPxhCnbMqyimvlIoOrjkAUQNTJKHDw:
    EPxhCnbMqyimvlIoOrjkAUQNTJKHBS=EPxhCnbMqyimvlIoOrjkAUQNTJKHDG.get('season_Id')
    EPxhCnbMqyimvlIoOrjkAUQNTJKHBa=EPxhCnbMqyimvlIoOrjkAUQNTJKHDG.get('season_Nm')
    EPxhCnbMqyimvlIoOrjkAUQNTJKHBe=EPxhCnbMqyimvlIoOrjkAUQNTJKHDG.get('programNm')
    EPxhCnbMqyimvlIoOrjkAUQNTJKHYa=EPxhCnbMqyimvlIoOrjkAUQNTJKHDG.get('thumbnail')
    EPxhCnbMqyimvlIoOrjkAUQNTJKHBY =EPxhCnbMqyimvlIoOrjkAUQNTJKHDG.get('synopsis')
    EPxhCnbMqyimvlIoOrjkAUQNTJKHes={'mediatype':'tvshow','title':EPxhCnbMqyimvlIoOrjkAUQNTJKHBa,'plot':EPxhCnbMqyimvlIoOrjkAUQNTJKHBY,}
    EPxhCnbMqyimvlIoOrjkAUQNTJKHas={'mode':'EPISODE_LIST','seasonid':EPxhCnbMqyimvlIoOrjkAUQNTJKHBS,'page':'1',}
    EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.add_dir(EPxhCnbMqyimvlIoOrjkAUQNTJKHBa,sublabel=EPxhCnbMqyimvlIoOrjkAUQNTJKHBe,img=EPxhCnbMqyimvlIoOrjkAUQNTJKHYa,infoLabels=EPxhCnbMqyimvlIoOrjkAUQNTJKHes,isFolder=EPxhCnbMqyimvlIoOrjkAUQNTJKHLd,params=EPxhCnbMqyimvlIoOrjkAUQNTJKHas,ContextMenu=EPxhCnbMqyimvlIoOrjkAUQNTJKHLX)
   xbmcplugin.setContent(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW._addon_handle,'seasons')
   xbmcplugin.endOfDirectory(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW._addon_handle,cacheToDisc=EPxhCnbMqyimvlIoOrjkAUQNTJKHLg)
  else:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHBc={'seasonid':EPxhCnbMqyimvlIoOrjkAUQNTJKHDR,'page':'1',}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.dp_Episode_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHBc)
 def dp_Episode_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW,args):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHDR =args.get('seasonid')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHez =EPxhCnbMqyimvlIoOrjkAUQNTJKHLu(args.get('page'))
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.addon_log('seasonid : '+EPxhCnbMqyimvlIoOrjkAUQNTJKHDR)
  EPxhCnbMqyimvlIoOrjkAUQNTJKHeR,EPxhCnbMqyimvlIoOrjkAUQNTJKHeL=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.Get_Episode_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHDR,EPxhCnbMqyimvlIoOrjkAUQNTJKHez,orderby=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.get_winEpisodeOrderby())
  for EPxhCnbMqyimvlIoOrjkAUQNTJKHew in EPxhCnbMqyimvlIoOrjkAUQNTJKHeR:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYW=EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('episodenumber')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHBD ='[%s]\n\n%s'%(EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('episodetitle'),EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('synopsis'))
   EPxhCnbMqyimvlIoOrjkAUQNTJKHes={'mediatype':'episode','title':EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('programtitle'),'plot':EPxhCnbMqyimvlIoOrjkAUQNTJKHBD,'cast':EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('episodeactors'),}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas={'mode':'VOD','programid':EPxhCnbMqyimvlIoOrjkAUQNTJKHDR,'contentid':EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('contentid'),'thumbnail':EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('thumbnail'),'title':EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('programtitle'),'subtitle':EPxhCnbMqyimvlIoOrjkAUQNTJKHYW,}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.add_dir(EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('programtitle'),sublabel=EPxhCnbMqyimvlIoOrjkAUQNTJKHYW,img=EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('thumbnail'),infoLabels=EPxhCnbMqyimvlIoOrjkAUQNTJKHes,isFolder=EPxhCnbMqyimvlIoOrjkAUQNTJKHLg,params=EPxhCnbMqyimvlIoOrjkAUQNTJKHas)
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHez==1:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHes={'plot':'정렬순서를 변경합니다.'}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas={}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas['mode'] ='ORDER_BY' 
   if EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.get_winEpisodeOrderby()=='desc':
    EPxhCnbMqyimvlIoOrjkAUQNTJKHau='정렬순서변경 : 최신화부터 -> 1회부터'
    EPxhCnbMqyimvlIoOrjkAUQNTJKHas['orderby']='asc'
   else:
    EPxhCnbMqyimvlIoOrjkAUQNTJKHau='정렬순서변경 : 1회부터 -> 최신화부터'
    EPxhCnbMqyimvlIoOrjkAUQNTJKHas['orderby']='desc'
   EPxhCnbMqyimvlIoOrjkAUQNTJKHaf=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.add_dir(EPxhCnbMqyimvlIoOrjkAUQNTJKHau,sublabel='',img=EPxhCnbMqyimvlIoOrjkAUQNTJKHaf,infoLabels=EPxhCnbMqyimvlIoOrjkAUQNTJKHes,isFolder=EPxhCnbMqyimvlIoOrjkAUQNTJKHLg,params=EPxhCnbMqyimvlIoOrjkAUQNTJKHas,isLink=EPxhCnbMqyimvlIoOrjkAUQNTJKHLd)
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHeL:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas={}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas['mode'] ='EPISODE_LIST' 
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas['seasonid']=EPxhCnbMqyimvlIoOrjkAUQNTJKHDR
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas['page'] =EPxhCnbMqyimvlIoOrjkAUQNTJKHLw(EPxhCnbMqyimvlIoOrjkAUQNTJKHez+1)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHau='[B]%s >>[/B]'%'다음 페이지'
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYW=EPxhCnbMqyimvlIoOrjkAUQNTJKHLw(EPxhCnbMqyimvlIoOrjkAUQNTJKHez+1)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHaf=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.add_dir(EPxhCnbMqyimvlIoOrjkAUQNTJKHau,sublabel=EPxhCnbMqyimvlIoOrjkAUQNTJKHYW,img=EPxhCnbMqyimvlIoOrjkAUQNTJKHaf,infoLabels=EPxhCnbMqyimvlIoOrjkAUQNTJKHLX,isFolder=EPxhCnbMqyimvlIoOrjkAUQNTJKHLd,params=EPxhCnbMqyimvlIoOrjkAUQNTJKHas)
  xbmcplugin.setContent(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW._addon_handle,'episodes')
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHLz(EPxhCnbMqyimvlIoOrjkAUQNTJKHeR)>0:xbmcplugin.endOfDirectory(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW._addon_handle,cacheToDisc=EPxhCnbMqyimvlIoOrjkAUQNTJKHLg)
 def dp_SuperSection_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW,args):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHBL =args.get('suburl')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHDz =args.get('subapi')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.addon_log('dp_SuperSection_List')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.addon_log('suburl : '+EPxhCnbMqyimvlIoOrjkAUQNTJKHBL)
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.addon_log('subapi : '+EPxhCnbMqyimvlIoOrjkAUQNTJKHDz)
  EPxhCnbMqyimvlIoOrjkAUQNTJKHeR=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.Get_SuperMultiSection_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHBL)
  for EPxhCnbMqyimvlIoOrjkAUQNTJKHew in EPxhCnbMqyimvlIoOrjkAUQNTJKHeR:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHau =EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('title')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHDz =EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('subapi')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHBW=EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('cell_type')
   if EPxhCnbMqyimvlIoOrjkAUQNTJKHDz.find('contenttype=movie')>=0 or EPxhCnbMqyimvlIoOrjkAUQNTJKHDz.find('mtype=svod')>=0:
    EPxhCnbMqyimvlIoOrjkAUQNTJKHec='MOVIE_LIST'
   elif re.search('themes/2\d{4}',EPxhCnbMqyimvlIoOrjkAUQNTJKHDz)or re.search('themes-band/9\d{4}',EPxhCnbMqyimvlIoOrjkAUQNTJKHDz):
    EPxhCnbMqyimvlIoOrjkAUQNTJKHec='MOVIE_LIST'
   else:
    EPxhCnbMqyimvlIoOrjkAUQNTJKHec='PROGRAM_LIST'
   '''
   if subapi.find('mtype=svod') >= 0 or subapi.find('mtype=ppv') >= 0 or subapi.find('contenttype=movie') >= 0: #영화 #20201107
    mode = 'MOVIE_LIST'
   elif subapi.find('contenttype=program') >= 0:
    mode = 'PROGRAM_LIST'
   elif cell_type == 'band_71': # band_71 #20201107
    mode   = 'SUPERSECTION_LIST'
    (temp_url, temp_api) = self.WavveObj.Baseapi_Parse(subapi)
    suburl = temp_api.get('api')
    subapi = ''
   elif cell_type == 'band_2': # band_2
    mode = 'BAND2SECTION_LIST'
   elif cell_type == 'band_live':
    mode = 'BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}', subapi) :
    mode = 'MOVIE_LIST'
   else: # band_10
    mode = 'PROGRAM_LIST'
   '''   
   EPxhCnbMqyimvlIoOrjkAUQNTJKHes={'plot':EPxhCnbMqyimvlIoOrjkAUQNTJKHau,'mediatype':'tvshow',}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas={'mode':EPxhCnbMqyimvlIoOrjkAUQNTJKHec,'suburl':EPxhCnbMqyimvlIoOrjkAUQNTJKHBL,'subapi':EPxhCnbMqyimvlIoOrjkAUQNTJKHDz,'page':'1',}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.add_dir(EPxhCnbMqyimvlIoOrjkAUQNTJKHau,sublabel='',img=EPxhCnbMqyimvlIoOrjkAUQNTJKHLX,infoLabels=EPxhCnbMqyimvlIoOrjkAUQNTJKHes,isFolder=EPxhCnbMqyimvlIoOrjkAUQNTJKHLd,params=EPxhCnbMqyimvlIoOrjkAUQNTJKHas)
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHLz(EPxhCnbMqyimvlIoOrjkAUQNTJKHeR)>0:xbmcplugin.endOfDirectory(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW._addon_handle,cacheToDisc=EPxhCnbMqyimvlIoOrjkAUQNTJKHLg)
 def dp_BandLiveSection_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW,args):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHDz =args.get('subapi')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHez=EPxhCnbMqyimvlIoOrjkAUQNTJKHLu(args.get('page'))
  EPxhCnbMqyimvlIoOrjkAUQNTJKHeR,EPxhCnbMqyimvlIoOrjkAUQNTJKHeL=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.Get_BandLiveSection_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHDz,EPxhCnbMqyimvlIoOrjkAUQNTJKHez)
  for EPxhCnbMqyimvlIoOrjkAUQNTJKHew in EPxhCnbMqyimvlIoOrjkAUQNTJKHeR:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHBt =EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('channelid')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHBF =EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('studio')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHBX=EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('tvshowtitle')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYa =EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('thumbnail')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYe =EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('age')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHes={'mediatype':'tvshow','mpaa':EPxhCnbMqyimvlIoOrjkAUQNTJKHYe,'title':'%s < %s >'%(EPxhCnbMqyimvlIoOrjkAUQNTJKHBF,EPxhCnbMqyimvlIoOrjkAUQNTJKHBX),'tvshowtitle':EPxhCnbMqyimvlIoOrjkAUQNTJKHBX,'studio':EPxhCnbMqyimvlIoOrjkAUQNTJKHBF,'plot':EPxhCnbMqyimvlIoOrjkAUQNTJKHBF}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas={'mode':'LIVE','contentid':EPxhCnbMqyimvlIoOrjkAUQNTJKHBt}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.add_dir(EPxhCnbMqyimvlIoOrjkAUQNTJKHBF,sublabel=EPxhCnbMqyimvlIoOrjkAUQNTJKHBX,img=EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('thumbnail'),infoLabels=EPxhCnbMqyimvlIoOrjkAUQNTJKHes,isFolder=EPxhCnbMqyimvlIoOrjkAUQNTJKHLg,params=EPxhCnbMqyimvlIoOrjkAUQNTJKHas)
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHeL:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas={}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas['mode'] ='BANDLIVESECTION_LIST' 
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas['subapi']=EPxhCnbMqyimvlIoOrjkAUQNTJKHDz
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas['page'] =EPxhCnbMqyimvlIoOrjkAUQNTJKHLw(EPxhCnbMqyimvlIoOrjkAUQNTJKHez+1)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHau='[B]%s >>[/B]'%'다음 페이지'
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYW=EPxhCnbMqyimvlIoOrjkAUQNTJKHLw(EPxhCnbMqyimvlIoOrjkAUQNTJKHez+1)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHaf=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.add_dir(EPxhCnbMqyimvlIoOrjkAUQNTJKHau,sublabel=EPxhCnbMqyimvlIoOrjkAUQNTJKHYW,img=EPxhCnbMqyimvlIoOrjkAUQNTJKHaf,infoLabels=EPxhCnbMqyimvlIoOrjkAUQNTJKHLX,isFolder=EPxhCnbMqyimvlIoOrjkAUQNTJKHLd,params=EPxhCnbMqyimvlIoOrjkAUQNTJKHas)
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHLz(EPxhCnbMqyimvlIoOrjkAUQNTJKHeR)>0:xbmcplugin.endOfDirectory(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW._addon_handle,cacheToDisc=EPxhCnbMqyimvlIoOrjkAUQNTJKHLg)
 def dp_Band2Section_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW,args):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHDz =args.get('subapi')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHez=EPxhCnbMqyimvlIoOrjkAUQNTJKHLu(args.get('page'))
  EPxhCnbMqyimvlIoOrjkAUQNTJKHeR,EPxhCnbMqyimvlIoOrjkAUQNTJKHeL=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.Get_Band2Section_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHDz,EPxhCnbMqyimvlIoOrjkAUQNTJKHez)
  for EPxhCnbMqyimvlIoOrjkAUQNTJKHew in EPxhCnbMqyimvlIoOrjkAUQNTJKHeR:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHau =EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('programtitle')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYW =EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('episodetitle')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHes={'plot':EPxhCnbMqyimvlIoOrjkAUQNTJKHau+'\n\n'+EPxhCnbMqyimvlIoOrjkAUQNTJKHYW,'mpaa':EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('age'),'mediatype':'episode'}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas={'mode':'VOD','programid':'-','contentid':EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('videoid'),'thumbnail':EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('thumbnail'),'title':EPxhCnbMqyimvlIoOrjkAUQNTJKHau,'subtitle':EPxhCnbMqyimvlIoOrjkAUQNTJKHYW}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.add_dir(EPxhCnbMqyimvlIoOrjkAUQNTJKHau,sublabel=EPxhCnbMqyimvlIoOrjkAUQNTJKHYW,img=EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('thumbnail'),infoLabels=EPxhCnbMqyimvlIoOrjkAUQNTJKHes,isFolder=EPxhCnbMqyimvlIoOrjkAUQNTJKHLg,params=EPxhCnbMqyimvlIoOrjkAUQNTJKHas)
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHeL:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas={}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas['mode'] ='BAND2SECTION_LIST' 
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas['subapi']=EPxhCnbMqyimvlIoOrjkAUQNTJKHDz
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas['page'] =EPxhCnbMqyimvlIoOrjkAUQNTJKHLw(EPxhCnbMqyimvlIoOrjkAUQNTJKHez+1)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHau='[B]%s >>[/B]'%'다음 페이지'
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYW=EPxhCnbMqyimvlIoOrjkAUQNTJKHLw(EPxhCnbMqyimvlIoOrjkAUQNTJKHez+1)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHaf=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.add_dir(EPxhCnbMqyimvlIoOrjkAUQNTJKHau,sublabel=EPxhCnbMqyimvlIoOrjkAUQNTJKHYW,img=EPxhCnbMqyimvlIoOrjkAUQNTJKHaf,infoLabels=EPxhCnbMqyimvlIoOrjkAUQNTJKHLX,isFolder=EPxhCnbMqyimvlIoOrjkAUQNTJKHLd,params=EPxhCnbMqyimvlIoOrjkAUQNTJKHas)
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHLz(EPxhCnbMqyimvlIoOrjkAUQNTJKHeR)>0:xbmcplugin.endOfDirectory(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW._addon_handle,cacheToDisc=EPxhCnbMqyimvlIoOrjkAUQNTJKHLg)
 def dp_Movie_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW,args):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHDz =args.get('subapi')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHez=EPxhCnbMqyimvlIoOrjkAUQNTJKHLu(args.get('page'))
  EPxhCnbMqyimvlIoOrjkAUQNTJKHaF =args.get('orderby')or '-'
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.addon_log('dp_Movie_List')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.addon_log(EPxhCnbMqyimvlIoOrjkAUQNTJKHDz)
  EPxhCnbMqyimvlIoOrjkAUQNTJKHeR,EPxhCnbMqyimvlIoOrjkAUQNTJKHeL=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.Get_Movie_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHDz,EPxhCnbMqyimvlIoOrjkAUQNTJKHez,EPxhCnbMqyimvlIoOrjkAUQNTJKHaF)
  for EPxhCnbMqyimvlIoOrjkAUQNTJKHew in EPxhCnbMqyimvlIoOrjkAUQNTJKHeR:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHeG =EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('videoid')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYS =EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('vidtype')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHau =EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('title')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYa=EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('thumbnail')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYe =EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('age')
   if EPxhCnbMqyimvlIoOrjkAUQNTJKHYe=='18' or EPxhCnbMqyimvlIoOrjkAUQNTJKHYe=='19' or EPxhCnbMqyimvlIoOrjkAUQNTJKHYe=='21':EPxhCnbMqyimvlIoOrjkAUQNTJKHau+=' (%s)'%(EPxhCnbMqyimvlIoOrjkAUQNTJKHYe)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHes={'plot':EPxhCnbMqyimvlIoOrjkAUQNTJKHau,'mpaa':EPxhCnbMqyimvlIoOrjkAUQNTJKHYe,'mediatype':'movie'}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas={'mode':'MOVIE','contentid':EPxhCnbMqyimvlIoOrjkAUQNTJKHeG,'title':EPxhCnbMqyimvlIoOrjkAUQNTJKHau,'thumbnail':EPxhCnbMqyimvlIoOrjkAUQNTJKHYa,'age':EPxhCnbMqyimvlIoOrjkAUQNTJKHYe,}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHef=[]
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYc={'mode':'VIEW_DETAIL','values':{'videoid':EPxhCnbMqyimvlIoOrjkAUQNTJKHeG,'vidtype':'movie','contenttype':EPxhCnbMqyimvlIoOrjkAUQNTJKHYS,}}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYD=json.dumps(EPxhCnbMqyimvlIoOrjkAUQNTJKHYc,separators=(',',':'))
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYD=base64.standard_b64encode(EPxhCnbMqyimvlIoOrjkAUQNTJKHYD.encode()).decode('utf-8')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYD=EPxhCnbMqyimvlIoOrjkAUQNTJKHYD.replace('+','%2B')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYB='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(EPxhCnbMqyimvlIoOrjkAUQNTJKHYD)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHef.append(('상세정보 조회',EPxhCnbMqyimvlIoOrjkAUQNTJKHYB))
   if EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.get_settings_makebookmark():
    EPxhCnbMqyimvlIoOrjkAUQNTJKHYc={'videoid':EPxhCnbMqyimvlIoOrjkAUQNTJKHeG,'vidtype':'movie','vtitle':EPxhCnbMqyimvlIoOrjkAUQNTJKHau,'vsubtitle':'','contenttype':'programid',}
    EPxhCnbMqyimvlIoOrjkAUQNTJKHYL=json.dumps(EPxhCnbMqyimvlIoOrjkAUQNTJKHYc)
    EPxhCnbMqyimvlIoOrjkAUQNTJKHYL=urllib.parse.quote(EPxhCnbMqyimvlIoOrjkAUQNTJKHYL)
    EPxhCnbMqyimvlIoOrjkAUQNTJKHYB='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(EPxhCnbMqyimvlIoOrjkAUQNTJKHYL)
    EPxhCnbMqyimvlIoOrjkAUQNTJKHef.append(('(통합) 찜 영상에 추가',EPxhCnbMqyimvlIoOrjkAUQNTJKHYB))
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.add_dir(EPxhCnbMqyimvlIoOrjkAUQNTJKHau,sublabel='',img=EPxhCnbMqyimvlIoOrjkAUQNTJKHYa,infoLabels=EPxhCnbMqyimvlIoOrjkAUQNTJKHes,isFolder=EPxhCnbMqyimvlIoOrjkAUQNTJKHLg,params=EPxhCnbMqyimvlIoOrjkAUQNTJKHas,ContextMenu=EPxhCnbMqyimvlIoOrjkAUQNTJKHef)
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHeL:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas={}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas['mode'] ='MOVIE_LIST' 
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas['subapi']=EPxhCnbMqyimvlIoOrjkAUQNTJKHDz 
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas['page'] =EPxhCnbMqyimvlIoOrjkAUQNTJKHLw(EPxhCnbMqyimvlIoOrjkAUQNTJKHez+1)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas['orderby']=EPxhCnbMqyimvlIoOrjkAUQNTJKHaF
   EPxhCnbMqyimvlIoOrjkAUQNTJKHau='[B]%s >>[/B]'%'다음 페이지'
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYW=EPxhCnbMqyimvlIoOrjkAUQNTJKHLw(EPxhCnbMqyimvlIoOrjkAUQNTJKHez+1)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHaf=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.add_dir(EPxhCnbMqyimvlIoOrjkAUQNTJKHau,sublabel=EPxhCnbMqyimvlIoOrjkAUQNTJKHYW,img=EPxhCnbMqyimvlIoOrjkAUQNTJKHaf,infoLabels=EPxhCnbMqyimvlIoOrjkAUQNTJKHLX,isFolder=EPxhCnbMqyimvlIoOrjkAUQNTJKHLd,params=EPxhCnbMqyimvlIoOrjkAUQNTJKHas)
  xbmcplugin.setContent(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW._addon_handle,'movies')
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHLz(EPxhCnbMqyimvlIoOrjkAUQNTJKHeR)>0:xbmcplugin.endOfDirectory(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW._addon_handle,cacheToDisc=EPxhCnbMqyimvlIoOrjkAUQNTJKHLg)
 def dp_Set_Bookmark(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW,args):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHBu=urllib.parse.unquote(args.get('bm_param'))
  EPxhCnbMqyimvlIoOrjkAUQNTJKHBu=json.loads(EPxhCnbMqyimvlIoOrjkAUQNTJKHBu)
  EPxhCnbMqyimvlIoOrjkAUQNTJKHeG =EPxhCnbMqyimvlIoOrjkAUQNTJKHBu.get('videoid')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHYS =EPxhCnbMqyimvlIoOrjkAUQNTJKHBu.get('vidtype')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHBd =EPxhCnbMqyimvlIoOrjkAUQNTJKHBu.get('vtitle')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHBg =EPxhCnbMqyimvlIoOrjkAUQNTJKHBu.get('vsubtitle')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHBV=EPxhCnbMqyimvlIoOrjkAUQNTJKHBu.get('contenttype')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSd=xbmcgui.Dialog()
  EPxhCnbMqyimvlIoOrjkAUQNTJKHcS=EPxhCnbMqyimvlIoOrjkAUQNTJKHSd.yesno(__language__(30913).encode('utf8'),EPxhCnbMqyimvlIoOrjkAUQNTJKHBd+' \n\n'+__language__(30914))
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHcS==EPxhCnbMqyimvlIoOrjkAUQNTJKHLg:return
  EPxhCnbMqyimvlIoOrjkAUQNTJKHBp=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.GetBookmarkInfo(EPxhCnbMqyimvlIoOrjkAUQNTJKHeG,EPxhCnbMqyimvlIoOrjkAUQNTJKHYS,EPxhCnbMqyimvlIoOrjkAUQNTJKHBV)
  EPxhCnbMqyimvlIoOrjkAUQNTJKHBf=json.dumps(EPxhCnbMqyimvlIoOrjkAUQNTJKHBp)
  EPxhCnbMqyimvlIoOrjkAUQNTJKHBf=urllib.parse.quote(EPxhCnbMqyimvlIoOrjkAUQNTJKHBf)
  EPxhCnbMqyimvlIoOrjkAUQNTJKHYB ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(EPxhCnbMqyimvlIoOrjkAUQNTJKHBf)
  xbmc.executebuiltin(EPxhCnbMqyimvlIoOrjkAUQNTJKHYB)
 def dp_LiveChannel_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW,args):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHBs =args.get('genre')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHDs=args.get('baseapi')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHeR=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.Get_LiveChannel_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHBs,EPxhCnbMqyimvlIoOrjkAUQNTJKHDs)
  for EPxhCnbMqyimvlIoOrjkAUQNTJKHew in EPxhCnbMqyimvlIoOrjkAUQNTJKHeR:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHBt =EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('channelid')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHBF =EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('studio')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHBX=EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('tvshowtitle')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYa =EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('thumbnail')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHYe =EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('age')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHBz =EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('epg')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHes={'mediatype':'episode','mpaa':EPxhCnbMqyimvlIoOrjkAUQNTJKHYe,'title':'%s < %s >'%(EPxhCnbMqyimvlIoOrjkAUQNTJKHBF,EPxhCnbMqyimvlIoOrjkAUQNTJKHBX),'tvshowtitle':EPxhCnbMqyimvlIoOrjkAUQNTJKHBX,'studio':EPxhCnbMqyimvlIoOrjkAUQNTJKHBF,'plot':'%s\n\n%s'%(EPxhCnbMqyimvlIoOrjkAUQNTJKHBF,EPxhCnbMqyimvlIoOrjkAUQNTJKHBz)}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas={'mode':'LIVE','contentid':EPxhCnbMqyimvlIoOrjkAUQNTJKHBt}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.add_dir(EPxhCnbMqyimvlIoOrjkAUQNTJKHBF,sublabel=EPxhCnbMqyimvlIoOrjkAUQNTJKHBX,img=EPxhCnbMqyimvlIoOrjkAUQNTJKHYa,infoLabels=EPxhCnbMqyimvlIoOrjkAUQNTJKHes,isFolder=EPxhCnbMqyimvlIoOrjkAUQNTJKHLg,params=EPxhCnbMqyimvlIoOrjkAUQNTJKHas)
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHLz(EPxhCnbMqyimvlIoOrjkAUQNTJKHeR)>0:xbmcplugin.endOfDirectory(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW._addon_handle,cacheToDisc=EPxhCnbMqyimvlIoOrjkAUQNTJKHLg)
 def dp_Sports_GameList(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW,args):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHeR=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.Get_Sports_Gamelist()
  for EPxhCnbMqyimvlIoOrjkAUQNTJKHew in EPxhCnbMqyimvlIoOrjkAUQNTJKHeR:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHBR =EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('game_date')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHBw =EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('game_time')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHBG =EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('svc_id')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHLS =EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('away_team')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHLa =EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('home_team')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHLe=EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('game_status')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHLY =EPxhCnbMqyimvlIoOrjkAUQNTJKHew.get('game_place')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHLc ='%s vs %s (%s)'%(EPxhCnbMqyimvlIoOrjkAUQNTJKHLS,EPxhCnbMqyimvlIoOrjkAUQNTJKHLa,EPxhCnbMqyimvlIoOrjkAUQNTJKHLY)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHLD =EPxhCnbMqyimvlIoOrjkAUQNTJKHBR+' '+EPxhCnbMqyimvlIoOrjkAUQNTJKHBw
   if EPxhCnbMqyimvlIoOrjkAUQNTJKHLe=='LIVE':
    EPxhCnbMqyimvlIoOrjkAUQNTJKHLe='~경기중~'
   elif EPxhCnbMqyimvlIoOrjkAUQNTJKHLe=='END':
    EPxhCnbMqyimvlIoOrjkAUQNTJKHLe='경기종료'
   elif EPxhCnbMqyimvlIoOrjkAUQNTJKHLe=='CANCEL':
    EPxhCnbMqyimvlIoOrjkAUQNTJKHLe='취소'
   else:
    EPxhCnbMqyimvlIoOrjkAUQNTJKHLe=''
   if EPxhCnbMqyimvlIoOrjkAUQNTJKHLe=='':
    EPxhCnbMqyimvlIoOrjkAUQNTJKHYW=EPxhCnbMqyimvlIoOrjkAUQNTJKHLc
   else:
    EPxhCnbMqyimvlIoOrjkAUQNTJKHYW=EPxhCnbMqyimvlIoOrjkAUQNTJKHLc+'  '+EPxhCnbMqyimvlIoOrjkAUQNTJKHLe
   EPxhCnbMqyimvlIoOrjkAUQNTJKHes={'mediatype':'episode','title':EPxhCnbMqyimvlIoOrjkAUQNTJKHLc,'plot':'%s\n\n%s\n\n%s'%(EPxhCnbMqyimvlIoOrjkAUQNTJKHLD,EPxhCnbMqyimvlIoOrjkAUQNTJKHLc,EPxhCnbMqyimvlIoOrjkAUQNTJKHLe)}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas={'mode':'SPORTS','contentid':EPxhCnbMqyimvlIoOrjkAUQNTJKHBG}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.add_dir(EPxhCnbMqyimvlIoOrjkAUQNTJKHLD,sublabel=EPxhCnbMqyimvlIoOrjkAUQNTJKHYW,img='',infoLabels=EPxhCnbMqyimvlIoOrjkAUQNTJKHes,isFolder=EPxhCnbMqyimvlIoOrjkAUQNTJKHLg,params=EPxhCnbMqyimvlIoOrjkAUQNTJKHas)
  xbmcplugin.endOfDirectory(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW._addon_handle,cacheToDisc=EPxhCnbMqyimvlIoOrjkAUQNTJKHLg)
 def dp_View_Detail(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW,EPxhCnbMqyimvlIoOrjkAUQNTJKHLt):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHeG =EPxhCnbMqyimvlIoOrjkAUQNTJKHLt.get('videoid')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHYS =EPxhCnbMqyimvlIoOrjkAUQNTJKHLt.get('vidtype') 
  EPxhCnbMqyimvlIoOrjkAUQNTJKHBV=EPxhCnbMqyimvlIoOrjkAUQNTJKHLt.get('contenttype')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.addon_log(EPxhCnbMqyimvlIoOrjkAUQNTJKHeG)
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.addon_log(EPxhCnbMqyimvlIoOrjkAUQNTJKHYS)
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.addon_log(EPxhCnbMqyimvlIoOrjkAUQNTJKHBV)
  EPxhCnbMqyimvlIoOrjkAUQNTJKHBp=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.GetBookmarkInfo(EPxhCnbMqyimvlIoOrjkAUQNTJKHeG,EPxhCnbMqyimvlIoOrjkAUQNTJKHYS,EPxhCnbMqyimvlIoOrjkAUQNTJKHBV)
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHYS=='tvshow':
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas={'mode':'SEASON_LIST','videoid':EPxhCnbMqyimvlIoOrjkAUQNTJKHBp['indexinfo']['videoid'],'vidtype':EPxhCnbMqyimvlIoOrjkAUQNTJKHBp['indexinfo']['vidtype'],}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHcD='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(EPxhCnbMqyimvlIoOrjkAUQNTJKHas))
  else:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHas={'mode':'MOVIE','contentid':EPxhCnbMqyimvlIoOrjkAUQNTJKHBp['indexinfo']['videoid'],'title':EPxhCnbMqyimvlIoOrjkAUQNTJKHBp['saveinfo']['infoLabels']['title'],'thumbnail':EPxhCnbMqyimvlIoOrjkAUQNTJKHBp['saveinfo']['thumbnail'],'age':EPxhCnbMqyimvlIoOrjkAUQNTJKHBp['saveinfo']['infoLabels']['mpaa'],}
   EPxhCnbMqyimvlIoOrjkAUQNTJKHcD='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(EPxhCnbMqyimvlIoOrjkAUQNTJKHas))
  EPxhCnbMqyimvlIoOrjkAUQNTJKHad=xbmcgui.ListItem(label=EPxhCnbMqyimvlIoOrjkAUQNTJKHBp['saveinfo']['title'],path=EPxhCnbMqyimvlIoOrjkAUQNTJKHcD)
  EPxhCnbMqyimvlIoOrjkAUQNTJKHad.setArt(EPxhCnbMqyimvlIoOrjkAUQNTJKHBp['saveinfo']['thumbnail'])
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.Set_InfoTag(EPxhCnbMqyimvlIoOrjkAUQNTJKHad.getVideoInfoTag(),EPxhCnbMqyimvlIoOrjkAUQNTJKHBp['saveinfo']['infoLabels'])
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHYS=='movie':
   EPxhCnbMqyimvlIoOrjkAUQNTJKHad.setIsFolder(EPxhCnbMqyimvlIoOrjkAUQNTJKHLg)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHad.setProperty('IsPlayable','true')
  else:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHad.setIsFolder(EPxhCnbMqyimvlIoOrjkAUQNTJKHLd)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHad.setProperty('IsPlayable','false')
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSd=xbmcgui.Dialog()
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSd.info(EPxhCnbMqyimvlIoOrjkAUQNTJKHad)
 def wavve_main(EPxhCnbMqyimvlIoOrjkAUQNTJKHSW):
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.WavveObj.KodiVersion=EPxhCnbMqyimvlIoOrjkAUQNTJKHLu(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  EPxhCnbMqyimvlIoOrjkAUQNTJKHLB=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.main_params.get('params')
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHLB:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHLW =base64.standard_b64decode(EPxhCnbMqyimvlIoOrjkAUQNTJKHLB).decode('utf-8')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHLW =json.loads(EPxhCnbMqyimvlIoOrjkAUQNTJKHLW)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHec =EPxhCnbMqyimvlIoOrjkAUQNTJKHLW.get('mode')
   EPxhCnbMqyimvlIoOrjkAUQNTJKHLt =EPxhCnbMqyimvlIoOrjkAUQNTJKHLW.get('values')
  else:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHec=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.main_params.get('mode',EPxhCnbMqyimvlIoOrjkAUQNTJKHLX)
   EPxhCnbMqyimvlIoOrjkAUQNTJKHLt=EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.main_params
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHec=='LOGOUT':
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.logout()
   return
  EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.login_main()
  if EPxhCnbMqyimvlIoOrjkAUQNTJKHec is EPxhCnbMqyimvlIoOrjkAUQNTJKHLX:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.dp_Main_List()
  elif EPxhCnbMqyimvlIoOrjkAUQNTJKHec in['LIVE','VOD','MOVIE','SPORTS']:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.play_VIDEO(EPxhCnbMqyimvlIoOrjkAUQNTJKHLt)
  elif EPxhCnbMqyimvlIoOrjkAUQNTJKHec=='LIVE_CATAGORY':
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.dp_LiveCatagory_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHLt)
  elif EPxhCnbMqyimvlIoOrjkAUQNTJKHec=='MAIN_CATAGORY':
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.dp_MainCatagory_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHLt)
  elif EPxhCnbMqyimvlIoOrjkAUQNTJKHec=='SUPERSECTION_LIST':
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.dp_SuperSection_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHLt)
  elif EPxhCnbMqyimvlIoOrjkAUQNTJKHec=='BANDLIVESECTION_LIST':
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.dp_BandLiveSection_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHLt)
  elif EPxhCnbMqyimvlIoOrjkAUQNTJKHec=='BAND2SECTION_LIST':
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.dp_Band2Section_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHLt)
  elif EPxhCnbMqyimvlIoOrjkAUQNTJKHec=='PROGRAM_LIST':
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.dp_Program_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHLt)
  elif EPxhCnbMqyimvlIoOrjkAUQNTJKHec=='SEASON_LIST':
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.dp_Season_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHLt)
  elif EPxhCnbMqyimvlIoOrjkAUQNTJKHec=='EPISODE_LIST':
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.dp_Episode_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHLt)
  elif EPxhCnbMqyimvlIoOrjkAUQNTJKHec=='MOVIE_LIST':
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.dp_Movie_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHLt)
  elif EPxhCnbMqyimvlIoOrjkAUQNTJKHec=='LIVE_LIST':
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.dp_LiveChannel_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHLt)
  elif EPxhCnbMqyimvlIoOrjkAUQNTJKHec=='ORDER_BY':
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.dp_setEpOrderby(EPxhCnbMqyimvlIoOrjkAUQNTJKHLt)
  elif EPxhCnbMqyimvlIoOrjkAUQNTJKHec=='SEARCH_GROUP':
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.dp_Search_Group(EPxhCnbMqyimvlIoOrjkAUQNTJKHLt)
  elif EPxhCnbMqyimvlIoOrjkAUQNTJKHec in['SEARCH_LIST','LOCAL_SEARCH']:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.dp_Search_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHLt)
  elif EPxhCnbMqyimvlIoOrjkAUQNTJKHec=='WATCH_GROUP':
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.dp_Watch_Group(EPxhCnbMqyimvlIoOrjkAUQNTJKHLt)
  elif EPxhCnbMqyimvlIoOrjkAUQNTJKHec=='WATCH_LIST':
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.dp_Watch_List(EPxhCnbMqyimvlIoOrjkAUQNTJKHLt)
  elif EPxhCnbMqyimvlIoOrjkAUQNTJKHec=='SET_BOOKMARK':
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.dp_Set_Bookmark(EPxhCnbMqyimvlIoOrjkAUQNTJKHLt)
  elif EPxhCnbMqyimvlIoOrjkAUQNTJKHec in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.dp_History_Remove(EPxhCnbMqyimvlIoOrjkAUQNTJKHLt)
  elif EPxhCnbMqyimvlIoOrjkAUQNTJKHec in['TOTAL_SEARCH','TOTAL_HISTORY']:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.dp_Global_Search(EPxhCnbMqyimvlIoOrjkAUQNTJKHLt)
  elif EPxhCnbMqyimvlIoOrjkAUQNTJKHec=='SEARCH_HISTORY':
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.dp_Search_History(EPxhCnbMqyimvlIoOrjkAUQNTJKHLt)
  elif EPxhCnbMqyimvlIoOrjkAUQNTJKHec=='MENU_BOOKMARK':
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.dp_Bookmark_Menu(EPxhCnbMqyimvlIoOrjkAUQNTJKHLt)
  elif EPxhCnbMqyimvlIoOrjkAUQNTJKHec=='GAME_LIST':
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.dp_Sports_GameList(EPxhCnbMqyimvlIoOrjkAUQNTJKHLt)
  elif EPxhCnbMqyimvlIoOrjkAUQNTJKHec=='VIEW_DETAIL':
   EPxhCnbMqyimvlIoOrjkAUQNTJKHSW.dp_View_Detail(EPxhCnbMqyimvlIoOrjkAUQNTJKHLt)
  else:
   EPxhCnbMqyimvlIoOrjkAUQNTJKHLX
# Created by pyminifier (https://github.com/liftoff/pyminifier)
