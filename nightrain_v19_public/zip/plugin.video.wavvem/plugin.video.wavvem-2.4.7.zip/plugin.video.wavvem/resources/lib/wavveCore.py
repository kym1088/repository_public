__author__="NightRain"
bdLRKMcHWAUDiPpwJgzBtEuevrxshj=object
bdLRKMcHWAUDiPpwJgzBtEuevrxshG=None
bdLRKMcHWAUDiPpwJgzBtEuevrxshN=False
bdLRKMcHWAUDiPpwJgzBtEuevrxshS=open
bdLRKMcHWAUDiPpwJgzBtEuevrxsCl=True
bdLRKMcHWAUDiPpwJgzBtEuevrxsCF=range
bdLRKMcHWAUDiPpwJgzBtEuevrxsCa=str
bdLRKMcHWAUDiPpwJgzBtEuevrxsCY=len
bdLRKMcHWAUDiPpwJgzBtEuevrxsCX=Exception
bdLRKMcHWAUDiPpwJgzBtEuevrxsCk=print
bdLRKMcHWAUDiPpwJgzBtEuevrxsCh=dict
bdLRKMcHWAUDiPpwJgzBtEuevrxsCT=int
import urllib
import re
import json
import sys
import requests
import datetime
import base64
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
bdLRKMcHWAUDiPpwJgzBtEuevrxsla =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
class bdLRKMcHWAUDiPpwJgzBtEuevrxslF(bdLRKMcHWAUDiPpwJgzBtEuevrxshj):
 def __init__(bdLRKMcHWAUDiPpwJgzBtEuevrxslY):
  bdLRKMcHWAUDiPpwJgzBtEuevrxslY.API_DOMAIN='https://apis.wavve.com'
  bdLRKMcHWAUDiPpwJgzBtEuevrxslY.WV ={}
  bdLRKMcHWAUDiPpwJgzBtEuevrxslY.Init_WV_Total()
  bdLRKMcHWAUDiPpwJgzBtEuevrxslY.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  bdLRKMcHWAUDiPpwJgzBtEuevrxslY.DEVICE ='pc'
  bdLRKMcHWAUDiPpwJgzBtEuevrxslY.DRM ='wm'
  bdLRKMcHWAUDiPpwJgzBtEuevrxslY.PARTNER ='pooq'
  bdLRKMcHWAUDiPpwJgzBtEuevrxslY.POOQZONE ='none'
  bdLRKMcHWAUDiPpwJgzBtEuevrxslY.REGION ='kor'
  bdLRKMcHWAUDiPpwJgzBtEuevrxslY.TARGETAGE ='all'
  bdLRKMcHWAUDiPpwJgzBtEuevrxslY.HTTPTAG ='https://'
  bdLRKMcHWAUDiPpwJgzBtEuevrxslY.LIST_LIMIT=30 
  bdLRKMcHWAUDiPpwJgzBtEuevrxslY.EP_LIMIT =30 
  bdLRKMcHWAUDiPpwJgzBtEuevrxslY.MV_LIMIT =24 
  bdLRKMcHWAUDiPpwJgzBtEuevrxslY.SEARCH_LIMIT=20 
  bdLRKMcHWAUDiPpwJgzBtEuevrxslY.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
  bdLRKMcHWAUDiPpwJgzBtEuevrxslY.DEFAULT_HEADER={'user-agent':bdLRKMcHWAUDiPpwJgzBtEuevrxslY.USER_AGENT}
  bdLRKMcHWAUDiPpwJgzBtEuevrxslY.KodiVersion=20
  bdLRKMcHWAUDiPpwJgzBtEuevrxslY.WV_SESSION_COOKIES1=''
  bdLRKMcHWAUDiPpwJgzBtEuevrxslY.WV_SESSION_COOKIES2=''
  bdLRKMcHWAUDiPpwJgzBtEuevrxslY.COOKIE_FILE_NAME =''
  bdLRKMcHWAUDiPpwJgzBtEuevrxslY.WV_STREAM_FILENAME =''
 def Init_WV_Total(bdLRKMcHWAUDiPpwJgzBtEuevrxslY):
  bdLRKMcHWAUDiPpwJgzBtEuevrxslY.WV={'account':{},'cookies':{},}
 def callRequestCookies(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,jobtype,bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,payload=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,params=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,headers=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,cookies=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,redirects=bdLRKMcHWAUDiPpwJgzBtEuevrxshN):
  bdLRKMcHWAUDiPpwJgzBtEuevrxslX=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.DEFAULT_HEADER
  if headers:bdLRKMcHWAUDiPpwJgzBtEuevrxslX.update(headers)
  if jobtype=='Get':
   bdLRKMcHWAUDiPpwJgzBtEuevrxslk=requests.get(bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,params=params,headers=bdLRKMcHWAUDiPpwJgzBtEuevrxslX,cookies=cookies,allow_redirects=redirects)
  else:
   bdLRKMcHWAUDiPpwJgzBtEuevrxslk=requests.post(bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,json=payload,params=params,headers=bdLRKMcHWAUDiPpwJgzBtEuevrxslX,cookies=cookies,allow_redirects=redirects)
  return bdLRKMcHWAUDiPpwJgzBtEuevrxslk
 def JsonFile_Save(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,filename,bdLRKMcHWAUDiPpwJgzBtEuevrxslh):
  if filename=='':return bdLRKMcHWAUDiPpwJgzBtEuevrxshN
  try:
   fp=bdLRKMcHWAUDiPpwJgzBtEuevrxshS(filename,'w',-1,'utf-8')
   json.dump(bdLRKMcHWAUDiPpwJgzBtEuevrxslh,fp,indent=4,ensure_ascii=bdLRKMcHWAUDiPpwJgzBtEuevrxshN)
   fp.close()
  except:
   return bdLRKMcHWAUDiPpwJgzBtEuevrxshN
  return bdLRKMcHWAUDiPpwJgzBtEuevrxsCl
 def JsonFile_Load(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,filename):
  if filename=='':return{}
  try:
   fp=bdLRKMcHWAUDiPpwJgzBtEuevrxshS(filename,'r',-1,'utf-8')
   bdLRKMcHWAUDiPpwJgzBtEuevrxslT=json.load(fp)
   fp.close()
  except:
   return{}
  return bdLRKMcHWAUDiPpwJgzBtEuevrxslT
 def TextFile_Save(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,filename,resText):
  if filename=='':return bdLRKMcHWAUDiPpwJgzBtEuevrxshN
  try:
   fp=bdLRKMcHWAUDiPpwJgzBtEuevrxshS(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return bdLRKMcHWAUDiPpwJgzBtEuevrxshN
  return bdLRKMcHWAUDiPpwJgzBtEuevrxsCl
 def Save_session_acount(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,bdLRKMcHWAUDiPpwJgzBtEuevrxslO,bdLRKMcHWAUDiPpwJgzBtEuevrxslf,bdLRKMcHWAUDiPpwJgzBtEuevrxslV):
  bdLRKMcHWAUDiPpwJgzBtEuevrxslY.WV['account']['wvid']=base64.standard_b64encode(bdLRKMcHWAUDiPpwJgzBtEuevrxslO.encode()).decode('utf-8')
  bdLRKMcHWAUDiPpwJgzBtEuevrxslY.WV['account']['wvpw']=base64.standard_b64encode(bdLRKMcHWAUDiPpwJgzBtEuevrxslf.encode()).decode('utf-8')
  bdLRKMcHWAUDiPpwJgzBtEuevrxslY.WV['account']['wvpf']=bdLRKMcHWAUDiPpwJgzBtEuevrxslV 
 def Load_session_acount(bdLRKMcHWAUDiPpwJgzBtEuevrxslY):
  try:
   bdLRKMcHWAUDiPpwJgzBtEuevrxslO=base64.standard_b64decode(bdLRKMcHWAUDiPpwJgzBtEuevrxslY.WV['account']['wvid']).decode('utf-8')
   bdLRKMcHWAUDiPpwJgzBtEuevrxslf=base64.standard_b64decode(bdLRKMcHWAUDiPpwJgzBtEuevrxslY.WV['account']['wvpw']).decode('utf-8')
   bdLRKMcHWAUDiPpwJgzBtEuevrxslV=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.WV['account']['wvpf']
  except:
   return '','',0
  return bdLRKMcHWAUDiPpwJgzBtEuevrxslO,bdLRKMcHWAUDiPpwJgzBtEuevrxslf,bdLRKMcHWAUDiPpwJgzBtEuevrxslV
 def GetDefaultParams(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,login=bdLRKMcHWAUDiPpwJgzBtEuevrxsCl):
  bdLRKMcHWAUDiPpwJgzBtEuevrxslo={'apikey':bdLRKMcHWAUDiPpwJgzBtEuevrxslY.APIKEY,'credential':bdLRKMcHWAUDiPpwJgzBtEuevrxslY.WV['cookies']['credential']if login else 'none','device':bdLRKMcHWAUDiPpwJgzBtEuevrxslY.DEVICE,'drm':bdLRKMcHWAUDiPpwJgzBtEuevrxslY.DRM,'partner':bdLRKMcHWAUDiPpwJgzBtEuevrxslY.PARTNER,'pooqzone':bdLRKMcHWAUDiPpwJgzBtEuevrxslY.POOQZONE,'region':bdLRKMcHWAUDiPpwJgzBtEuevrxslY.REGION,'targetage':bdLRKMcHWAUDiPpwJgzBtEuevrxslY.TARGETAGE,'client_version':'6.0.1',}
  return bdLRKMcHWAUDiPpwJgzBtEuevrxslo
 def GetDefaultParams_AND(bdLRKMcHWAUDiPpwJgzBtEuevrxslY):
  bdLRKMcHWAUDiPpwJgzBtEuevrxslo={'apikey':'6A87455D54481A536DFB8AD397C5EC4D','credential':bdLRKMcHWAUDiPpwJgzBtEuevrxslY.WV['cookies']['credential'],'device':'ott','drm':bdLRKMcHWAUDiPpwJgzBtEuevrxslY.DRM,'partner':bdLRKMcHWAUDiPpwJgzBtEuevrxslY.PARTNER,'pooqzone':bdLRKMcHWAUDiPpwJgzBtEuevrxslY.POOQZONE,'region':bdLRKMcHWAUDiPpwJgzBtEuevrxslY.REGION,'targetage':bdLRKMcHWAUDiPpwJgzBtEuevrxslY.TARGETAGE,}
  return bdLRKMcHWAUDiPpwJgzBtEuevrxslo
 def GetGUID(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   bdLRKMcHWAUDiPpwJgzBtEuevrxsln=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   bdLRKMcHWAUDiPpwJgzBtEuevrxslq=GenerateRandomString(5)
   bdLRKMcHWAUDiPpwJgzBtEuevrxslm=bdLRKMcHWAUDiPpwJgzBtEuevrxslq+media+bdLRKMcHWAUDiPpwJgzBtEuevrxsln
   return bdLRKMcHWAUDiPpwJgzBtEuevrxslm
  def GenerateRandomString(num):
   from random import randint
   bdLRKMcHWAUDiPpwJgzBtEuevrxslI=""
   for i in bdLRKMcHWAUDiPpwJgzBtEuevrxsCF(0,num):
    s=bdLRKMcHWAUDiPpwJgzBtEuevrxsCa(randint(1,5))
    bdLRKMcHWAUDiPpwJgzBtEuevrxslI+=s
   return bdLRKMcHWAUDiPpwJgzBtEuevrxslI
  if guidType==3:
   bdLRKMcHWAUDiPpwJgzBtEuevrxslm=guid_str
  else:
   bdLRKMcHWAUDiPpwJgzBtEuevrxslm=GenerateID(guid_str)
  bdLRKMcHWAUDiPpwJgzBtEuevrxsly=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.GetHash(bdLRKMcHWAUDiPpwJgzBtEuevrxslm)
  if guidType in[2,3]:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsly='%s-%s-%s-%s-%s'%(bdLRKMcHWAUDiPpwJgzBtEuevrxsly[:8],bdLRKMcHWAUDiPpwJgzBtEuevrxsly[8:12],bdLRKMcHWAUDiPpwJgzBtEuevrxsly[12:16],bdLRKMcHWAUDiPpwJgzBtEuevrxsly[16:20],bdLRKMcHWAUDiPpwJgzBtEuevrxsly[20:])
  return bdLRKMcHWAUDiPpwJgzBtEuevrxsly
 def GetHash(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return bdLRKMcHWAUDiPpwJgzBtEuevrxsCa(m.hexdigest())
 def CheckQuality(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,sel_qt,qt_list):
  bdLRKMcHWAUDiPpwJgzBtEuevrxslQ=0
  for bdLRKMcHWAUDiPpwJgzBtEuevrxslj in qt_list:
   if sel_qt>=bdLRKMcHWAUDiPpwJgzBtEuevrxslj:return bdLRKMcHWAUDiPpwJgzBtEuevrxslj
   bdLRKMcHWAUDiPpwJgzBtEuevrxslQ=bdLRKMcHWAUDiPpwJgzBtEuevrxslj
  return bdLRKMcHWAUDiPpwJgzBtEuevrxslQ
 def Get_Now_Datetime(bdLRKMcHWAUDiPpwJgzBtEuevrxslY):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,in_text):
  bdLRKMcHWAUDiPpwJgzBtEuevrxslN=in_text.replace('&lt;','<').replace('&gt;','>')
  bdLRKMcHWAUDiPpwJgzBtEuevrxslN=bdLRKMcHWAUDiPpwJgzBtEuevrxslN.replace('<br>','\n')
  bdLRKMcHWAUDiPpwJgzBtEuevrxslN=bdLRKMcHWAUDiPpwJgzBtEuevrxslN.replace('$O$','')
  bdLRKMcHWAUDiPpwJgzBtEuevrxslN=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',bdLRKMcHWAUDiPpwJgzBtEuevrxslN)
  bdLRKMcHWAUDiPpwJgzBtEuevrxslN=bdLRKMcHWAUDiPpwJgzBtEuevrxslN.lstrip('#')
  return bdLRKMcHWAUDiPpwJgzBtEuevrxslN
 def make_str_ToCookie(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,cookieStr):
  bdLRKMcHWAUDiPpwJgzBtEuevrxslS={}
  for bdLRKMcHWAUDiPpwJgzBtEuevrxsFl in cookieStr.split(';'):
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFa=bdLRKMcHWAUDiPpwJgzBtEuevrxsFl.split('=')
   bdLRKMcHWAUDiPpwJgzBtEuevrxslS[bdLRKMcHWAUDiPpwJgzBtEuevrxsFa[0]]=bdLRKMcHWAUDiPpwJgzBtEuevrxsFa[1]
  return bdLRKMcHWAUDiPpwJgzBtEuevrxslS 
 def make_stream_header(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,bdLRKMcHWAUDiPpwJgzBtEuevrxsFC,bdLRKMcHWAUDiPpwJgzBtEuevrxslS):
  bdLRKMcHWAUDiPpwJgzBtEuevrxsFY=''
  if bdLRKMcHWAUDiPpwJgzBtEuevrxslS not in[{},bdLRKMcHWAUDiPpwJgzBtEuevrxshG,'']:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFX=bdLRKMcHWAUDiPpwJgzBtEuevrxsCY(bdLRKMcHWAUDiPpwJgzBtEuevrxslS)
   for bdLRKMcHWAUDiPpwJgzBtEuevrxsFk,bdLRKMcHWAUDiPpwJgzBtEuevrxsFh in bdLRKMcHWAUDiPpwJgzBtEuevrxslS.items():
    bdLRKMcHWAUDiPpwJgzBtEuevrxsFY+='{}={}'.format(bdLRKMcHWAUDiPpwJgzBtEuevrxsFk,bdLRKMcHWAUDiPpwJgzBtEuevrxsFh)
    bdLRKMcHWAUDiPpwJgzBtEuevrxsFX+=-1
    if bdLRKMcHWAUDiPpwJgzBtEuevrxsFX>0:bdLRKMcHWAUDiPpwJgzBtEuevrxsFY+='; '
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFC['cookie']=bdLRKMcHWAUDiPpwJgzBtEuevrxsFY
  bdLRKMcHWAUDiPpwJgzBtEuevrxsFT=''
  i=0
  for bdLRKMcHWAUDiPpwJgzBtEuevrxsFk,bdLRKMcHWAUDiPpwJgzBtEuevrxsFh in bdLRKMcHWAUDiPpwJgzBtEuevrxsFC.items():
   i=i+1
   if i>1:bdLRKMcHWAUDiPpwJgzBtEuevrxsFT+='&'
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFT+='{}={}'.format(bdLRKMcHWAUDiPpwJgzBtEuevrxsFk,urllib.parse.quote(bdLRKMcHWAUDiPpwJgzBtEuevrxsFh))
  return bdLRKMcHWAUDiPpwJgzBtEuevrxsFT
 def GetCredential(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,user_id,user_pw,user_pf):
  bdLRKMcHWAUDiPpwJgzBtEuevrxsFO=bdLRKMcHWAUDiPpwJgzBtEuevrxshN
  try:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFf=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.API_DOMAIN+ '/login'
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.GetDefaultParams(login=bdLRKMcHWAUDiPpwJgzBtEuevrxshN)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFV={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.callRequestCookies('Post',bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,payload=bdLRKMcHWAUDiPpwJgzBtEuevrxsFV,params=bdLRKMcHWAUDiPpwJgzBtEuevrxslo,headers=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,cookies=bdLRKMcHWAUDiPpwJgzBtEuevrxshG)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFn=json.loads(bdLRKMcHWAUDiPpwJgzBtEuevrxsFo.text)
   bdLRKMcHWAUDiPpwJgzBtEuevrxslY.WV['cookies']['credential']=bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['credential']
   if user_pf!=0:
    bdLRKMcHWAUDiPpwJgzBtEuevrxsFV={'id':bdLRKMcHWAUDiPpwJgzBtEuevrxslY.WV['cookies']['credential'],'password':'','profile':bdLRKMcHWAUDiPpwJgzBtEuevrxsCa(user_pf),'pushid':'','type':'credential'}
    bdLRKMcHWAUDiPpwJgzBtEuevrxslo =bdLRKMcHWAUDiPpwJgzBtEuevrxslY.GetDefaultParams(login=bdLRKMcHWAUDiPpwJgzBtEuevrxsCl) 
    bdLRKMcHWAUDiPpwJgzBtEuevrxsFo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.callRequestCookies('Post',bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,payload=bdLRKMcHWAUDiPpwJgzBtEuevrxsFV,params=bdLRKMcHWAUDiPpwJgzBtEuevrxslo,headers=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,cookies=bdLRKMcHWAUDiPpwJgzBtEuevrxshG)
    bdLRKMcHWAUDiPpwJgzBtEuevrxsFn=json.loads(bdLRKMcHWAUDiPpwJgzBtEuevrxsFo.text)
    bdLRKMcHWAUDiPpwJgzBtEuevrxslY.WV['cookies']['credential']=bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['credential']
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFq=user_id+bdLRKMcHWAUDiPpwJgzBtEuevrxsCa(user_pf) 
   bdLRKMcHWAUDiPpwJgzBtEuevrxslY.WV['cookies']['uuid']=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.GetGUID(guid_str=bdLRKMcHWAUDiPpwJgzBtEuevrxsFq,guidType=3)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFO=bdLRKMcHWAUDiPpwJgzBtEuevrxsCl
  except bdLRKMcHWAUDiPpwJgzBtEuevrxsCX as exception:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsCk(exception)
   bdLRKMcHWAUDiPpwJgzBtEuevrxslY.Init_WV_Total()
  return bdLRKMcHWAUDiPpwJgzBtEuevrxsFO
 def GetIssue(bdLRKMcHWAUDiPpwJgzBtEuevrxslY):
  bdLRKMcHWAUDiPpwJgzBtEuevrxsFm=bdLRKMcHWAUDiPpwJgzBtEuevrxshN
  try:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFf=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.API_DOMAIN+'/guid/issue'
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.GetDefaultParams()
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.callRequestCookies('Get',bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,payload=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,params=bdLRKMcHWAUDiPpwJgzBtEuevrxslo,headers=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,cookies=bdLRKMcHWAUDiPpwJgzBtEuevrxshG)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFn=json.loads(bdLRKMcHWAUDiPpwJgzBtEuevrxsFo.text)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFI=bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['guid']
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFy=bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['guidtimestamp']
   if bdLRKMcHWAUDiPpwJgzBtEuevrxsFI:bdLRKMcHWAUDiPpwJgzBtEuevrxsFm=bdLRKMcHWAUDiPpwJgzBtEuevrxsCl
  except bdLRKMcHWAUDiPpwJgzBtEuevrxsCX as exception:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsCk(exception)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFI='none'
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFy='none' 
  bdLRKMcHWAUDiPpwJgzBtEuevrxslY.guid=bdLRKMcHWAUDiPpwJgzBtEuevrxsFI
  bdLRKMcHWAUDiPpwJgzBtEuevrxslY.guidtimestamp=bdLRKMcHWAUDiPpwJgzBtEuevrxsFy
  return bdLRKMcHWAUDiPpwJgzBtEuevrxsFm
 def Baseapi_Parse(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,bdLRKMcHWAUDiPpwJgzBtEuevrxsFN):
  try:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFQ =urllib.parse.urlsplit(bdLRKMcHWAUDiPpwJgzBtEuevrxsFN)
   if bdLRKMcHWAUDiPpwJgzBtEuevrxsFQ.netloc=='':
    bdLRKMcHWAUDiPpwJgzBtEuevrxsFf=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.HTTPTAG+bdLRKMcHWAUDiPpwJgzBtEuevrxsFQ.netloc+bdLRKMcHWAUDiPpwJgzBtEuevrxsFQ.path
   else:
    bdLRKMcHWAUDiPpwJgzBtEuevrxsFf=bdLRKMcHWAUDiPpwJgzBtEuevrxsFQ.scheme+'://'+bdLRKMcHWAUDiPpwJgzBtEuevrxsFQ.netloc+bdLRKMcHWAUDiPpwJgzBtEuevrxsFQ.path
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo=bdLRKMcHWAUDiPpwJgzBtEuevrxsCh(urllib.parse.parse_qsl(bdLRKMcHWAUDiPpwJgzBtEuevrxsFQ.query))
  except bdLRKMcHWAUDiPpwJgzBtEuevrxsCX as exception:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsCk(exception)
   return '',{}
  return bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,bdLRKMcHWAUDiPpwJgzBtEuevrxslo
 def GetSupermultiUrl(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,sCode,sIndex='0'):
  try:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFf=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.API_DOMAIN+'/cf/supermultisections/'+sCode
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.GetDefaultParams(login=bdLRKMcHWAUDiPpwJgzBtEuevrxshN)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.callRequestCookies('Get',bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,payload=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,params=bdLRKMcHWAUDiPpwJgzBtEuevrxslo,headers=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,cookies=bdLRKMcHWAUDiPpwJgzBtEuevrxshG)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFn=json.loads(bdLRKMcHWAUDiPpwJgzBtEuevrxsFo.text)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFj=bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['multisectionlist'][bdLRKMcHWAUDiPpwJgzBtEuevrxsCT(sIndex)]['eventlist'][1]['url']
  except bdLRKMcHWAUDiPpwJgzBtEuevrxsCX as exception:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsCk(exception)
   return ''
  return bdLRKMcHWAUDiPpwJgzBtEuevrxsFj
 def Get_LiveCatagory_List(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,sCode,sIndex='0'):
  bdLRKMcHWAUDiPpwJgzBtEuevrxsFG=[]
  bdLRKMcHWAUDiPpwJgzBtEuevrxsFN =bdLRKMcHWAUDiPpwJgzBtEuevrxslY.GetSupermultiUrl(sCode,sIndex)
  (bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,bdLRKMcHWAUDiPpwJgzBtEuevrxslo)=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.Baseapi_Parse(bdLRKMcHWAUDiPpwJgzBtEuevrxsFN)
  if bdLRKMcHWAUDiPpwJgzBtEuevrxsFf=='':return bdLRKMcHWAUDiPpwJgzBtEuevrxsFG,''
  try:
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo.update(bdLRKMcHWAUDiPpwJgzBtEuevrxslY.GetDefaultParams(login=bdLRKMcHWAUDiPpwJgzBtEuevrxshN))
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.callRequestCookies('Get',bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,payload=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,params=bdLRKMcHWAUDiPpwJgzBtEuevrxslo,headers=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,cookies=bdLRKMcHWAUDiPpwJgzBtEuevrxshG)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFn=json.loads(bdLRKMcHWAUDiPpwJgzBtEuevrxsFo.text)
   if not('filter_item_list' in bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['filter']['filterlist'][0]):return[],''
   bdLRKMcHWAUDiPpwJgzBtEuevrxsal=bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['filter']['filterlist'][0]['filter_item_list']
   for bdLRKMcHWAUDiPpwJgzBtEuevrxsaF in bdLRKMcHWAUDiPpwJgzBtEuevrxsal:
    bdLRKMcHWAUDiPpwJgzBtEuevrxsaY={'title':bdLRKMcHWAUDiPpwJgzBtEuevrxsaF['title'],'genre':bdLRKMcHWAUDiPpwJgzBtEuevrxsaF['api_parameters'][bdLRKMcHWAUDiPpwJgzBtEuevrxsaF['api_parameters'].index('=')+1:]}
    bdLRKMcHWAUDiPpwJgzBtEuevrxsFG.append(bdLRKMcHWAUDiPpwJgzBtEuevrxsaY)
  except bdLRKMcHWAUDiPpwJgzBtEuevrxsCX as exception:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsCk(exception)
   return[],''
  return bdLRKMcHWAUDiPpwJgzBtEuevrxsFG,bdLRKMcHWAUDiPpwJgzBtEuevrxsFN
 def Get_MainCatagory_List(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,sCode,sIndex,sType):
  bdLRKMcHWAUDiPpwJgzBtEuevrxsFG=[]
  bdLRKMcHWAUDiPpwJgzBtEuevrxsFf='https://apis.wavve.com/es/category/launcher-band'
  bdLRKMcHWAUDiPpwJgzBtEuevrxslo={'uitype':sCode,'uiparent':'GN52-'+sCode,'uirank':sIndex,'broadcastid':sCode,'offset':'0','limit':'20','uicode':sCode,'mtype':'N','ctype':sType,'orderby':'default',}
  try:
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo.update(bdLRKMcHWAUDiPpwJgzBtEuevrxslY.GetDefaultParams(login=bdLRKMcHWAUDiPpwJgzBtEuevrxshN))
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.callRequestCookies('Get',bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,payload=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,params=bdLRKMcHWAUDiPpwJgzBtEuevrxslo,headers=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,cookies=bdLRKMcHWAUDiPpwJgzBtEuevrxshG)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFn=json.loads(bdLRKMcHWAUDiPpwJgzBtEuevrxsFo.text)
   if not('celllist' in bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['band']):return[]
   bdLRKMcHWAUDiPpwJgzBtEuevrxsal=bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['band']['celllist']
   for bdLRKMcHWAUDiPpwJgzBtEuevrxsaF in bdLRKMcHWAUDiPpwJgzBtEuevrxsal:
    bdLRKMcHWAUDiPpwJgzBtEuevrxsaX =bdLRKMcHWAUDiPpwJgzBtEuevrxsaF['event_list'][1]['url']
    (bdLRKMcHWAUDiPpwJgzBtEuevrxsak,bdLRKMcHWAUDiPpwJgzBtEuevrxsah)=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.Baseapi_Parse(bdLRKMcHWAUDiPpwJgzBtEuevrxsaX)
    bdLRKMcHWAUDiPpwJgzBtEuevrxsaY={'title':bdLRKMcHWAUDiPpwJgzBtEuevrxsaF['title_list'][0]['text'],'suburl':bdLRKMcHWAUDiPpwJgzBtEuevrxsak,'subapi':bdLRKMcHWAUDiPpwJgzBtEuevrxsah.get('api'),'subtype':'catagory' if bdLRKMcHWAUDiPpwJgzBtEuevrxsah else 'supersection'}
    bdLRKMcHWAUDiPpwJgzBtEuevrxsFG.append(bdLRKMcHWAUDiPpwJgzBtEuevrxsaY)
  except bdLRKMcHWAUDiPpwJgzBtEuevrxsCX as exception:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsCk(exception)
   return[]
  return bdLRKMcHWAUDiPpwJgzBtEuevrxsFG
 def Get_SuperMultiSection_List(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,subapi_text):
  bdLRKMcHWAUDiPpwJgzBtEuevrxsFG=[]
  if '/multiband/' in subapi_text: 
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFf=subapi_text 
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo={'client':'40'}
  else:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFf=subapi_text 
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFf=bdLRKMcHWAUDiPpwJgzBtEuevrxsFf.replace('www.wavve.com','apis.wavve.com').replace('supermultisection','v1/multiband')
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo={}
  try:
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo.update(bdLRKMcHWAUDiPpwJgzBtEuevrxslY.GetDefaultParams(login=bdLRKMcHWAUDiPpwJgzBtEuevrxshN))
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.callRequestCookies('Get',bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,payload=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,params=bdLRKMcHWAUDiPpwJgzBtEuevrxslo,headers=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,cookies=bdLRKMcHWAUDiPpwJgzBtEuevrxshG)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFn=json.loads(bdLRKMcHWAUDiPpwJgzBtEuevrxsFo.text)
   if not('multisectionlist' in bdLRKMcHWAUDiPpwJgzBtEuevrxsFn):return[]
   bdLRKMcHWAUDiPpwJgzBtEuevrxsal=bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['multisectionlist']
   for bdLRKMcHWAUDiPpwJgzBtEuevrxsaF in bdLRKMcHWAUDiPpwJgzBtEuevrxsal:
    bdLRKMcHWAUDiPpwJgzBtEuevrxsaC=bdLRKMcHWAUDiPpwJgzBtEuevrxsaF['title']
    if bdLRKMcHWAUDiPpwJgzBtEuevrxsCY(bdLRKMcHWAUDiPpwJgzBtEuevrxsaC)==0:continue
    if bdLRKMcHWAUDiPpwJgzBtEuevrxsaC=='minor':continue
    if re.search(u'베너',bdLRKMcHWAUDiPpwJgzBtEuevrxsaC):continue
    if re.search(u'배너',bdLRKMcHWAUDiPpwJgzBtEuevrxsaC):continue 
    if bdLRKMcHWAUDiPpwJgzBtEuevrxsaF['force_refresh']=='y':continue
    if bdLRKMcHWAUDiPpwJgzBtEuevrxsCY(bdLRKMcHWAUDiPpwJgzBtEuevrxsaF['eventlist'])>=3:
     bdLRKMcHWAUDiPpwJgzBtEuevrxsah =bdLRKMcHWAUDiPpwJgzBtEuevrxsaF['eventlist'][2]['url']
    else:
     bdLRKMcHWAUDiPpwJgzBtEuevrxsah =bdLRKMcHWAUDiPpwJgzBtEuevrxsaF['eventlist'][1]['url']
    bdLRKMcHWAUDiPpwJgzBtEuevrxsaT=bdLRKMcHWAUDiPpwJgzBtEuevrxsaF['cell_type']
    if bdLRKMcHWAUDiPpwJgzBtEuevrxsaT=='band_2':
     if bdLRKMcHWAUDiPpwJgzBtEuevrxsah.find('channellist=')>=0:
      bdLRKMcHWAUDiPpwJgzBtEuevrxsaT='band_live'
    bdLRKMcHWAUDiPpwJgzBtEuevrxsaY={'title':bdLRKMcHWAUDiPpwJgzBtEuevrxslY.Get_ChangeText(bdLRKMcHWAUDiPpwJgzBtEuevrxsaC),'subapi':bdLRKMcHWAUDiPpwJgzBtEuevrxsah,'cell_type':bdLRKMcHWAUDiPpwJgzBtEuevrxsaT}
    bdLRKMcHWAUDiPpwJgzBtEuevrxsFG.append(bdLRKMcHWAUDiPpwJgzBtEuevrxsaY)
  except bdLRKMcHWAUDiPpwJgzBtEuevrxsCX as exception:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsCk(exception)
   return[]
  return bdLRKMcHWAUDiPpwJgzBtEuevrxsFG
 def Get_BandLiveSection_List(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,bdLRKMcHWAUDiPpwJgzBtEuevrxsFN,page_int=1):
  bdLRKMcHWAUDiPpwJgzBtEuevrxsaO=[]
  bdLRKMcHWAUDiPpwJgzBtEuevrxsaf=bdLRKMcHWAUDiPpwJgzBtEuevrxsaI=1
  bdLRKMcHWAUDiPpwJgzBtEuevrxsaV=bdLRKMcHWAUDiPpwJgzBtEuevrxshN
  try:
   (bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,bdLRKMcHWAUDiPpwJgzBtEuevrxslo)=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.Baseapi_Parse(bdLRKMcHWAUDiPpwJgzBtEuevrxsFN)
  except bdLRKMcHWAUDiPpwJgzBtEuevrxsCX as exception:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsCk(exception)
   return[],bdLRKMcHWAUDiPpwJgzBtEuevrxshN
  try:
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo['limit']=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.LIST_LIMIT
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo['offset']=bdLRKMcHWAUDiPpwJgzBtEuevrxsCa((page_int-1)*bdLRKMcHWAUDiPpwJgzBtEuevrxslY.LIST_LIMIT)
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo.update(bdLRKMcHWAUDiPpwJgzBtEuevrxslY.GetDefaultParams(login=bdLRKMcHWAUDiPpwJgzBtEuevrxshN))
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.callRequestCookies('Get',bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,payload=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,params=bdLRKMcHWAUDiPpwJgzBtEuevrxslo,headers=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,cookies=bdLRKMcHWAUDiPpwJgzBtEuevrxshG)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFn=json.loads(bdLRKMcHWAUDiPpwJgzBtEuevrxsFo.text)
   if not('celllist' in bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['cell_toplist']):return[],bdLRKMcHWAUDiPpwJgzBtEuevrxshN
   bdLRKMcHWAUDiPpwJgzBtEuevrxsal=bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['cell_toplist']['celllist']
   for bdLRKMcHWAUDiPpwJgzBtEuevrxsaF in bdLRKMcHWAUDiPpwJgzBtEuevrxsal:
    bdLRKMcHWAUDiPpwJgzBtEuevrxsao =bdLRKMcHWAUDiPpwJgzBtEuevrxsaF['event_list'][1]['url']
    bdLRKMcHWAUDiPpwJgzBtEuevrxsan=urllib.parse.urlsplit(bdLRKMcHWAUDiPpwJgzBtEuevrxsao).query
    bdLRKMcHWAUDiPpwJgzBtEuevrxsan=bdLRKMcHWAUDiPpwJgzBtEuevrxsCh(urllib.parse.parse_qsl(bdLRKMcHWAUDiPpwJgzBtEuevrxsan))
    bdLRKMcHWAUDiPpwJgzBtEuevrxsaq='channelid'
    bdLRKMcHWAUDiPpwJgzBtEuevrxsam=bdLRKMcHWAUDiPpwJgzBtEuevrxsan[bdLRKMcHWAUDiPpwJgzBtEuevrxsaq]
    bdLRKMcHWAUDiPpwJgzBtEuevrxsaY={'studio':bdLRKMcHWAUDiPpwJgzBtEuevrxsaF['title_list'][0]['text'],'tvshowtitle':bdLRKMcHWAUDiPpwJgzBtEuevrxslY.Get_ChangeText(bdLRKMcHWAUDiPpwJgzBtEuevrxsaF['title_list'][1]['text']),'channelid':bdLRKMcHWAUDiPpwJgzBtEuevrxsam,'age':bdLRKMcHWAUDiPpwJgzBtEuevrxsaF.get('age'),'thumbnail':'https://%s'%bdLRKMcHWAUDiPpwJgzBtEuevrxsaF.get('thumbnail')}
    bdLRKMcHWAUDiPpwJgzBtEuevrxsaO.append(bdLRKMcHWAUDiPpwJgzBtEuevrxsaY)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsaf=bdLRKMcHWAUDiPpwJgzBtEuevrxsCT(bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['cell_toplist']['pagecount'])
   if bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['cell_toplist']['count']:bdLRKMcHWAUDiPpwJgzBtEuevrxsaI =bdLRKMcHWAUDiPpwJgzBtEuevrxsCT(bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['cell_toplist']['count'])
   else:bdLRKMcHWAUDiPpwJgzBtEuevrxsaI=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.LIST_LIMIT*page_int
   bdLRKMcHWAUDiPpwJgzBtEuevrxsaV=bdLRKMcHWAUDiPpwJgzBtEuevrxsaf>bdLRKMcHWAUDiPpwJgzBtEuevrxsaI
  except bdLRKMcHWAUDiPpwJgzBtEuevrxsCX as exception:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsCk(exception)
   return[],bdLRKMcHWAUDiPpwJgzBtEuevrxshN
  return bdLRKMcHWAUDiPpwJgzBtEuevrxsaO,bdLRKMcHWAUDiPpwJgzBtEuevrxsaV
 def Get_Band2Section_List(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,bdLRKMcHWAUDiPpwJgzBtEuevrxsFN,page_int=1):
  bdLRKMcHWAUDiPpwJgzBtEuevrxsay=[]
  bdLRKMcHWAUDiPpwJgzBtEuevrxsaf=bdLRKMcHWAUDiPpwJgzBtEuevrxsaI=1
  bdLRKMcHWAUDiPpwJgzBtEuevrxsaV=bdLRKMcHWAUDiPpwJgzBtEuevrxshN
  try:
   (bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,bdLRKMcHWAUDiPpwJgzBtEuevrxslo)=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.Baseapi_Parse(bdLRKMcHWAUDiPpwJgzBtEuevrxsFN)
  except bdLRKMcHWAUDiPpwJgzBtEuevrxsCX as exception:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsCk(exception)
   return[],bdLRKMcHWAUDiPpwJgzBtEuevrxshN
  try:
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo['came'] ='BandView'
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo['limit']=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.LIST_LIMIT
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo['offset']=bdLRKMcHWAUDiPpwJgzBtEuevrxsCa((page_int-1)*bdLRKMcHWAUDiPpwJgzBtEuevrxslY.LIST_LIMIT)
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo.update(bdLRKMcHWAUDiPpwJgzBtEuevrxslY.GetDefaultParams(login=bdLRKMcHWAUDiPpwJgzBtEuevrxshN))
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.callRequestCookies('Get',bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,payload=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,params=bdLRKMcHWAUDiPpwJgzBtEuevrxslo,headers=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,cookies=bdLRKMcHWAUDiPpwJgzBtEuevrxshG)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFn=json.loads(bdLRKMcHWAUDiPpwJgzBtEuevrxsFo.text)
   if not('celllist' in bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['cell_toplist']):return[],bdLRKMcHWAUDiPpwJgzBtEuevrxshN
   bdLRKMcHWAUDiPpwJgzBtEuevrxsal=bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['cell_toplist']['celllist']
   for bdLRKMcHWAUDiPpwJgzBtEuevrxsaF in bdLRKMcHWAUDiPpwJgzBtEuevrxsal:
    bdLRKMcHWAUDiPpwJgzBtEuevrxsao =bdLRKMcHWAUDiPpwJgzBtEuevrxsaF['event_list'][1]['url']
    bdLRKMcHWAUDiPpwJgzBtEuevrxsan=urllib.parse.urlsplit(bdLRKMcHWAUDiPpwJgzBtEuevrxsao).query
    bdLRKMcHWAUDiPpwJgzBtEuevrxsan=bdLRKMcHWAUDiPpwJgzBtEuevrxsCh(urllib.parse.parse_qsl(bdLRKMcHWAUDiPpwJgzBtEuevrxsan))
    bdLRKMcHWAUDiPpwJgzBtEuevrxsaq='contentid'
    bdLRKMcHWAUDiPpwJgzBtEuevrxsam=bdLRKMcHWAUDiPpwJgzBtEuevrxsan[bdLRKMcHWAUDiPpwJgzBtEuevrxsaq]
    bdLRKMcHWAUDiPpwJgzBtEuevrxsaY={'programtitle':bdLRKMcHWAUDiPpwJgzBtEuevrxsaF['title_list'][0]['text'],'episodetitle':bdLRKMcHWAUDiPpwJgzBtEuevrxslY.Get_ChangeText(bdLRKMcHWAUDiPpwJgzBtEuevrxsaF['title_list'][1]['text']),'age':bdLRKMcHWAUDiPpwJgzBtEuevrxsaF.get('age'),'thumbnail':bdLRKMcHWAUDiPpwJgzBtEuevrxslY.HTTPTAG+bdLRKMcHWAUDiPpwJgzBtEuevrxsaF.get('thumbnail'),'vidtype':bdLRKMcHWAUDiPpwJgzBtEuevrxsaq,'videoid':bdLRKMcHWAUDiPpwJgzBtEuevrxsam}
    bdLRKMcHWAUDiPpwJgzBtEuevrxsay.append(bdLRKMcHWAUDiPpwJgzBtEuevrxsaY)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsaf=bdLRKMcHWAUDiPpwJgzBtEuevrxsCT(bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['cell_toplist']['pagecount'])
   if bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['cell_toplist']['count']:bdLRKMcHWAUDiPpwJgzBtEuevrxsaI =bdLRKMcHWAUDiPpwJgzBtEuevrxsCT(bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['cell_toplist']['count'])
   else:bdLRKMcHWAUDiPpwJgzBtEuevrxsaI=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.LIST_LIMIT*page_int
   bdLRKMcHWAUDiPpwJgzBtEuevrxsaV=bdLRKMcHWAUDiPpwJgzBtEuevrxsaf>bdLRKMcHWAUDiPpwJgzBtEuevrxsaI
  except bdLRKMcHWAUDiPpwJgzBtEuevrxsCX as exception:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsCk(exception)
   return[],bdLRKMcHWAUDiPpwJgzBtEuevrxshN
  return bdLRKMcHWAUDiPpwJgzBtEuevrxsay,bdLRKMcHWAUDiPpwJgzBtEuevrxsaV
 def Get_Program_List(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,bdLRKMcHWAUDiPpwJgzBtEuevrxsFN,page_int=1,orderby='-'):
  bdLRKMcHWAUDiPpwJgzBtEuevrxsaQ=[]
  bdLRKMcHWAUDiPpwJgzBtEuevrxsaf=bdLRKMcHWAUDiPpwJgzBtEuevrxsaI=1
  bdLRKMcHWAUDiPpwJgzBtEuevrxsaV=bdLRKMcHWAUDiPpwJgzBtEuevrxshN
  (bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,bdLRKMcHWAUDiPpwJgzBtEuevrxslo)=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.Baseapi_Parse(bdLRKMcHWAUDiPpwJgzBtEuevrxsFN)
  if bdLRKMcHWAUDiPpwJgzBtEuevrxsFf=='':return bdLRKMcHWAUDiPpwJgzBtEuevrxsaQ,bdLRKMcHWAUDiPpwJgzBtEuevrxsaV
  try:
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo['limit'] =bdLRKMcHWAUDiPpwJgzBtEuevrxslY.LIST_LIMIT
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo['offset']=bdLRKMcHWAUDiPpwJgzBtEuevrxsCa((page_int-1)*bdLRKMcHWAUDiPpwJgzBtEuevrxslY.LIST_LIMIT)
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo['page'] =bdLRKMcHWAUDiPpwJgzBtEuevrxsCa(page_int)
   if bdLRKMcHWAUDiPpwJgzBtEuevrxslo.get('orderby')!='' and bdLRKMcHWAUDiPpwJgzBtEuevrxslo.get('orderby')!='regdatefirst' and orderby!='-':
    bdLRKMcHWAUDiPpwJgzBtEuevrxslo['orderby']=orderby 
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo.update(bdLRKMcHWAUDiPpwJgzBtEuevrxslY.GetDefaultParams(login=bdLRKMcHWAUDiPpwJgzBtEuevrxshN))
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.callRequestCookies('Get',bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,payload=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,params=bdLRKMcHWAUDiPpwJgzBtEuevrxslo,headers=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,cookies=bdLRKMcHWAUDiPpwJgzBtEuevrxshG)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFn=json.loads(bdLRKMcHWAUDiPpwJgzBtEuevrxsFo.text)
   if bdLRKMcHWAUDiPpwJgzBtEuevrxsFn.get('cell_toplist')not in[{},bdLRKMcHWAUDiPpwJgzBtEuevrxshG,'']:
    bdLRKMcHWAUDiPpwJgzBtEuevrxsal=bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['cell_toplist']['celllist']
   elif bdLRKMcHWAUDiPpwJgzBtEuevrxsFn.get('band')not in[{},bdLRKMcHWAUDiPpwJgzBtEuevrxshG,'']:
    bdLRKMcHWAUDiPpwJgzBtEuevrxsal=bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['band']['celllist']
   else:
    return bdLRKMcHWAUDiPpwJgzBtEuevrxsaQ,bdLRKMcHWAUDiPpwJgzBtEuevrxsaV
   for bdLRKMcHWAUDiPpwJgzBtEuevrxsaF in bdLRKMcHWAUDiPpwJgzBtEuevrxsal:
    for bdLRKMcHWAUDiPpwJgzBtEuevrxsaj in bdLRKMcHWAUDiPpwJgzBtEuevrxsaF['event_list']:
     if bdLRKMcHWAUDiPpwJgzBtEuevrxsaj.get('type')=='on-navigation':
      bdLRKMcHWAUDiPpwJgzBtEuevrxsao =bdLRKMcHWAUDiPpwJgzBtEuevrxsaj['url']
    bdLRKMcHWAUDiPpwJgzBtEuevrxsan=urllib.parse.urlsplit(bdLRKMcHWAUDiPpwJgzBtEuevrxsao).query
    bdLRKMcHWAUDiPpwJgzBtEuevrxsaq=bdLRKMcHWAUDiPpwJgzBtEuevrxsan[0:bdLRKMcHWAUDiPpwJgzBtEuevrxsan.find('=')]
    bdLRKMcHWAUDiPpwJgzBtEuevrxsaG=bdLRKMcHWAUDiPpwJgzBtEuevrxsCh(urllib.parse.parse_qsl(bdLRKMcHWAUDiPpwJgzBtEuevrxsan))
    bdLRKMcHWAUDiPpwJgzBtEuevrxsam=bdLRKMcHWAUDiPpwJgzBtEuevrxsaG.get(bdLRKMcHWAUDiPpwJgzBtEuevrxsaq)
    bdLRKMcHWAUDiPpwJgzBtEuevrxsaY={'title':bdLRKMcHWAUDiPpwJgzBtEuevrxsaF.get('alt')or bdLRKMcHWAUDiPpwJgzBtEuevrxsaF.get('title_list')[0].get('text'),'age':bdLRKMcHWAUDiPpwJgzBtEuevrxsaF.get('age'),'thumbnail':bdLRKMcHWAUDiPpwJgzBtEuevrxsaF.get('thumbnail'),'videoid':bdLRKMcHWAUDiPpwJgzBtEuevrxsam,'vidtype':bdLRKMcHWAUDiPpwJgzBtEuevrxsaq,}
    if not bdLRKMcHWAUDiPpwJgzBtEuevrxsaY.get('thumbnail').startswith('http'):
     bdLRKMcHWAUDiPpwJgzBtEuevrxsaY['thumbnail']='https://%s'%bdLRKMcHWAUDiPpwJgzBtEuevrxsaY['thumbnail']
    bdLRKMcHWAUDiPpwJgzBtEuevrxsaQ.append(bdLRKMcHWAUDiPpwJgzBtEuevrxsaY)
   if bdLRKMcHWAUDiPpwJgzBtEuevrxsFn.get('cell_toplist')not in[{},bdLRKMcHWAUDiPpwJgzBtEuevrxshG,'']:
    bdLRKMcHWAUDiPpwJgzBtEuevrxsaf=bdLRKMcHWAUDiPpwJgzBtEuevrxsCT(bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['cell_toplist']['pagecount'])
    if bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['cell_toplist']['count']:bdLRKMcHWAUDiPpwJgzBtEuevrxsaI =bdLRKMcHWAUDiPpwJgzBtEuevrxsCT(bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['cell_toplist']['count'])
    else:bdLRKMcHWAUDiPpwJgzBtEuevrxsaI=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.LIST_LIMIT*page_int
    bdLRKMcHWAUDiPpwJgzBtEuevrxsaV=bdLRKMcHWAUDiPpwJgzBtEuevrxsaf>bdLRKMcHWAUDiPpwJgzBtEuevrxsaI
  except bdLRKMcHWAUDiPpwJgzBtEuevrxsCX as exception:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsCk(exception)
   return[],bdLRKMcHWAUDiPpwJgzBtEuevrxshN
  return bdLRKMcHWAUDiPpwJgzBtEuevrxsaQ,bdLRKMcHWAUDiPpwJgzBtEuevrxsaV
 def Get_Movie_List(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,bdLRKMcHWAUDiPpwJgzBtEuevrxsFN,page_int=1,orderby='-'):
  bdLRKMcHWAUDiPpwJgzBtEuevrxsaN=[]
  bdLRKMcHWAUDiPpwJgzBtEuevrxsaf=bdLRKMcHWAUDiPpwJgzBtEuevrxsaI=1
  bdLRKMcHWAUDiPpwJgzBtEuevrxsaV=bdLRKMcHWAUDiPpwJgzBtEuevrxshN
  (bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,bdLRKMcHWAUDiPpwJgzBtEuevrxslo)=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.Baseapi_Parse(bdLRKMcHWAUDiPpwJgzBtEuevrxsFN)
  if bdLRKMcHWAUDiPpwJgzBtEuevrxsFf=='':return bdLRKMcHWAUDiPpwJgzBtEuevrxsaN,bdLRKMcHWAUDiPpwJgzBtEuevrxsaV
  try:
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo['limit']=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.MV_LIMIT
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo['offset']=bdLRKMcHWAUDiPpwJgzBtEuevrxsCa((page_int-1)*bdLRKMcHWAUDiPpwJgzBtEuevrxslY.MV_LIMIT)
   if bdLRKMcHWAUDiPpwJgzBtEuevrxslo.get('orderby')!='' and bdLRKMcHWAUDiPpwJgzBtEuevrxslo.get('orderby')!='regdatefirst' and orderby!='-':
    bdLRKMcHWAUDiPpwJgzBtEuevrxslo['orderby']=orderby 
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo.update(bdLRKMcHWAUDiPpwJgzBtEuevrxslY.GetDefaultParams(login=bdLRKMcHWAUDiPpwJgzBtEuevrxshN))
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.callRequestCookies('Get',bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,payload=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,params=bdLRKMcHWAUDiPpwJgzBtEuevrxslo,headers=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,cookies=bdLRKMcHWAUDiPpwJgzBtEuevrxshG)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFn=json.loads(bdLRKMcHWAUDiPpwJgzBtEuevrxsFo.text)
   if bdLRKMcHWAUDiPpwJgzBtEuevrxsFn.get('cell_toplist')not in[{},bdLRKMcHWAUDiPpwJgzBtEuevrxshG,'']:
    bdLRKMcHWAUDiPpwJgzBtEuevrxsal=bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['cell_toplist']['celllist']
   elif bdLRKMcHWAUDiPpwJgzBtEuevrxsFn.get('band')not in[{},bdLRKMcHWAUDiPpwJgzBtEuevrxshG,'']:
    bdLRKMcHWAUDiPpwJgzBtEuevrxsal=bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['band']['celllist']
   else:
    return bdLRKMcHWAUDiPpwJgzBtEuevrxsaN,bdLRKMcHWAUDiPpwJgzBtEuevrxsaV
   for bdLRKMcHWAUDiPpwJgzBtEuevrxsaF in bdLRKMcHWAUDiPpwJgzBtEuevrxsal:
    bdLRKMcHWAUDiPpwJgzBtEuevrxsao =bdLRKMcHWAUDiPpwJgzBtEuevrxsaF['event_list'][1]['url']
    bdLRKMcHWAUDiPpwJgzBtEuevrxsan=urllib.parse.urlsplit(bdLRKMcHWAUDiPpwJgzBtEuevrxsao).query
    bdLRKMcHWAUDiPpwJgzBtEuevrxsaq=bdLRKMcHWAUDiPpwJgzBtEuevrxsan[0:bdLRKMcHWAUDiPpwJgzBtEuevrxsan.find('=')]
    bdLRKMcHWAUDiPpwJgzBtEuevrxsaG=bdLRKMcHWAUDiPpwJgzBtEuevrxsCh(urllib.parse.parse_qsl(bdLRKMcHWAUDiPpwJgzBtEuevrxsan))
    bdLRKMcHWAUDiPpwJgzBtEuevrxsam=bdLRKMcHWAUDiPpwJgzBtEuevrxsaG.get(bdLRKMcHWAUDiPpwJgzBtEuevrxsaq)
    bdLRKMcHWAUDiPpwJgzBtEuevrxsaY={'title':bdLRKMcHWAUDiPpwJgzBtEuevrxsaF.get('alt')or bdLRKMcHWAUDiPpwJgzBtEuevrxsaF.get('title_list')[0].get('text'),'age':bdLRKMcHWAUDiPpwJgzBtEuevrxsaF.get('age'),'thumbnail':bdLRKMcHWAUDiPpwJgzBtEuevrxsaF.get('thumbnail'),'videoid':bdLRKMcHWAUDiPpwJgzBtEuevrxsam,'vidtype':bdLRKMcHWAUDiPpwJgzBtEuevrxsaq,}
    if not bdLRKMcHWAUDiPpwJgzBtEuevrxsaY.get('thumbnail').startswith('http'):
     bdLRKMcHWAUDiPpwJgzBtEuevrxsaY['thumbnail']='https://%s'%bdLRKMcHWAUDiPpwJgzBtEuevrxsaY['thumbnail']
    bdLRKMcHWAUDiPpwJgzBtEuevrxsaN.append(bdLRKMcHWAUDiPpwJgzBtEuevrxsaY)
   if bdLRKMcHWAUDiPpwJgzBtEuevrxsFn.get('cell_toplist')not in[{},bdLRKMcHWAUDiPpwJgzBtEuevrxshG,'']:
    bdLRKMcHWAUDiPpwJgzBtEuevrxsaf=bdLRKMcHWAUDiPpwJgzBtEuevrxsCT(bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['cell_toplist']['pagecount'])
    if bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['cell_toplist']['count']:bdLRKMcHWAUDiPpwJgzBtEuevrxsaI =bdLRKMcHWAUDiPpwJgzBtEuevrxsCT(bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['cell_toplist']['count'])
    else:bdLRKMcHWAUDiPpwJgzBtEuevrxsaI=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.MV_LIMIT*page_int
    bdLRKMcHWAUDiPpwJgzBtEuevrxsaV=bdLRKMcHWAUDiPpwJgzBtEuevrxsaf>bdLRKMcHWAUDiPpwJgzBtEuevrxsaI
  except bdLRKMcHWAUDiPpwJgzBtEuevrxsCX as exception:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsCk(exception)
   return[],bdLRKMcHWAUDiPpwJgzBtEuevrxshN
  return bdLRKMcHWAUDiPpwJgzBtEuevrxsaN,bdLRKMcHWAUDiPpwJgzBtEuevrxsaV
 def ProgramidToContentid(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,bdLRKMcHWAUDiPpwJgzBtEuevrxsYF):
  bdLRKMcHWAUDiPpwJgzBtEuevrxsaS=''
  try:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFf =bdLRKMcHWAUDiPpwJgzBtEuevrxslY.API_DOMAIN+'/vod/programs-contentid/'+bdLRKMcHWAUDiPpwJgzBtEuevrxsYF
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.GetDefaultParams(login=bdLRKMcHWAUDiPpwJgzBtEuevrxshN)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.callRequestCookies('Get',bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,payload=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,params=bdLRKMcHWAUDiPpwJgzBtEuevrxslo,headers=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,cookies=bdLRKMcHWAUDiPpwJgzBtEuevrxshG)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsYl=json.loads(bdLRKMcHWAUDiPpwJgzBtEuevrxsFo.text)
   if not('contentid' in bdLRKMcHWAUDiPpwJgzBtEuevrxsYl):return bdLRKMcHWAUDiPpwJgzBtEuevrxsaS 
   bdLRKMcHWAUDiPpwJgzBtEuevrxsaS=bdLRKMcHWAUDiPpwJgzBtEuevrxsYl['contentid']
  except bdLRKMcHWAUDiPpwJgzBtEuevrxsCX as exception:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsCk(exception)
  return bdLRKMcHWAUDiPpwJgzBtEuevrxsaS
 def ContentidToSeasonid(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,bdLRKMcHWAUDiPpwJgzBtEuevrxsaS):
  bdLRKMcHWAUDiPpwJgzBtEuevrxsYF=''
  try:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFf =bdLRKMcHWAUDiPpwJgzBtEuevrxslY.API_DOMAIN+'/fz/vod/contents/'+bdLRKMcHWAUDiPpwJgzBtEuevrxsaS
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.GetDefaultParams(login=bdLRKMcHWAUDiPpwJgzBtEuevrxshN)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.callRequestCookies('Get',bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,payload=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,params=bdLRKMcHWAUDiPpwJgzBtEuevrxslo,headers=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,cookies=bdLRKMcHWAUDiPpwJgzBtEuevrxshG)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsYl=json.loads(bdLRKMcHWAUDiPpwJgzBtEuevrxsFo.text)
   if not('programid' in bdLRKMcHWAUDiPpwJgzBtEuevrxsYl):return bdLRKMcHWAUDiPpwJgzBtEuevrxsYF 
   bdLRKMcHWAUDiPpwJgzBtEuevrxsYF=bdLRKMcHWAUDiPpwJgzBtEuevrxsYl['programid']
  except bdLRKMcHWAUDiPpwJgzBtEuevrxsCX as exception:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsCk(exception)
  return bdLRKMcHWAUDiPpwJgzBtEuevrxsYF
 def GetProgramInfo(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,bdLRKMcHWAUDiPpwJgzBtEuevrxsaS):
  bdLRKMcHWAUDiPpwJgzBtEuevrxsYa={}
  try:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFf=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.API_DOMAIN+'/fz/vod/contents/'+bdLRKMcHWAUDiPpwJgzBtEuevrxsaS
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.GetDefaultParams(login=bdLRKMcHWAUDiPpwJgzBtEuevrxshN)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.callRequestCookies('Get',bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,payload=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,params=bdLRKMcHWAUDiPpwJgzBtEuevrxslo,headers=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,cookies=bdLRKMcHWAUDiPpwJgzBtEuevrxshG)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsYl=json.loads(bdLRKMcHWAUDiPpwJgzBtEuevrxsFo.text)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsYX=img_fanart=bdLRKMcHWAUDiPpwJgzBtEuevrxsYk=''
   if bdLRKMcHWAUDiPpwJgzBtEuevrxsYl.get('programposterimage')!='':bdLRKMcHWAUDiPpwJgzBtEuevrxsYX =bdLRKMcHWAUDiPpwJgzBtEuevrxslY.HTTPTAG+bdLRKMcHWAUDiPpwJgzBtEuevrxsYl.get('programposterimage')
   if bdLRKMcHWAUDiPpwJgzBtEuevrxsYl.get('programimage') !='':img_fanart =bdLRKMcHWAUDiPpwJgzBtEuevrxslY.HTTPTAG+bdLRKMcHWAUDiPpwJgzBtEuevrxsYl.get('programimage')
   if bdLRKMcHWAUDiPpwJgzBtEuevrxsYl.get('programcircleimage')!='':bdLRKMcHWAUDiPpwJgzBtEuevrxsYk=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.HTTPTAG+bdLRKMcHWAUDiPpwJgzBtEuevrxsYl.get('programcircleimage')
   if 'poster_default' in bdLRKMcHWAUDiPpwJgzBtEuevrxsYX:
    bdLRKMcHWAUDiPpwJgzBtEuevrxsYX =img_fanart
    bdLRKMcHWAUDiPpwJgzBtEuevrxsYk=''
   bdLRKMcHWAUDiPpwJgzBtEuevrxsYa={'imgPoster':bdLRKMcHWAUDiPpwJgzBtEuevrxsYX,'imgFanart':img_fanart,'imgClearlogo':bdLRKMcHWAUDiPpwJgzBtEuevrxsYk,'programtitle':bdLRKMcHWAUDiPpwJgzBtEuevrxslY.Get_ChangeText(bdLRKMcHWAUDiPpwJgzBtEuevrxsYl.get('programtitle')),'programid':bdLRKMcHWAUDiPpwJgzBtEuevrxsYl.get('programid'),'synopsis':bdLRKMcHWAUDiPpwJgzBtEuevrxslY.Get_ChangeText(bdLRKMcHWAUDiPpwJgzBtEuevrxsYl.get('programsynopsis')),}
  except bdLRKMcHWAUDiPpwJgzBtEuevrxsCX as exception:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsCk(exception)
  return bdLRKMcHWAUDiPpwJgzBtEuevrxsYa
 def Get_Season_List(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,seasonid):
  bdLRKMcHWAUDiPpwJgzBtEuevrxsYh=[]
  bdLRKMcHWAUDiPpwJgzBtEuevrxsaS=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.ProgramidToContentid(seasonid)
  bdLRKMcHWAUDiPpwJgzBtEuevrxsYC=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.GetProgramInfo(bdLRKMcHWAUDiPpwJgzBtEuevrxsaS)
  bdLRKMcHWAUDiPpwJgzBtEuevrxsYT={'poster':bdLRKMcHWAUDiPpwJgzBtEuevrxsYC.get('imgPoster'),'fanart':bdLRKMcHWAUDiPpwJgzBtEuevrxsYC.get('imgFanart'),'clearlogo':bdLRKMcHWAUDiPpwJgzBtEuevrxsYC.get('imgClearlogo'),}
  try:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFf=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.API_DOMAIN+'/fz/vod/programs-contents/'+seasonid
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo={'limit':'10','offset':'0','orderby':'new',}
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo.update(bdLRKMcHWAUDiPpwJgzBtEuevrxslY.GetDefaultParams(login=bdLRKMcHWAUDiPpwJgzBtEuevrxshN))
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.callRequestCookies('Get',bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,payload=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,params=bdLRKMcHWAUDiPpwJgzBtEuevrxslo,headers=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,cookies=bdLRKMcHWAUDiPpwJgzBtEuevrxshG)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFn=json.loads(bdLRKMcHWAUDiPpwJgzBtEuevrxsFo.text)
   for bdLRKMcHWAUDiPpwJgzBtEuevrxsYO in bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['filter']['filterlist'][0]['filter_item_list']:
    bdLRKMcHWAUDiPpwJgzBtEuevrxsaY={'season_Nm':bdLRKMcHWAUDiPpwJgzBtEuevrxslY.Get_ChangeText(bdLRKMcHWAUDiPpwJgzBtEuevrxsYO.get('title')),'season_Id':bdLRKMcHWAUDiPpwJgzBtEuevrxsYO.get('api_path'),'thumbnail':bdLRKMcHWAUDiPpwJgzBtEuevrxsYT,'programNm':bdLRKMcHWAUDiPpwJgzBtEuevrxslY.Get_ChangeText(bdLRKMcHWAUDiPpwJgzBtEuevrxsYC.get('programtitle')),'synopsis':bdLRKMcHWAUDiPpwJgzBtEuevrxslY.Get_ChangeText(bdLRKMcHWAUDiPpwJgzBtEuevrxsYC.get('synopsis')),}
    bdLRKMcHWAUDiPpwJgzBtEuevrxsYh.append(bdLRKMcHWAUDiPpwJgzBtEuevrxsaY)
  except bdLRKMcHWAUDiPpwJgzBtEuevrxsCX as exception:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsCk(exception)
   return[]
  return bdLRKMcHWAUDiPpwJgzBtEuevrxsYh
 def Get_Episode_List(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,seasionid,page_int=1,orderby='desc'):
  bdLRKMcHWAUDiPpwJgzBtEuevrxsYf=[]
  bdLRKMcHWAUDiPpwJgzBtEuevrxsaf=bdLRKMcHWAUDiPpwJgzBtEuevrxsaI=1
  bdLRKMcHWAUDiPpwJgzBtEuevrxsaV=bdLRKMcHWAUDiPpwJgzBtEuevrxshN
  bdLRKMcHWAUDiPpwJgzBtEuevrxsYC={}
  bdLRKMcHWAUDiPpwJgzBtEuevrxsaS=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.ProgramidToContentid(seasionid)
  bdLRKMcHWAUDiPpwJgzBtEuevrxsYC=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.GetProgramInfo(bdLRKMcHWAUDiPpwJgzBtEuevrxsaS)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFf=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.API_DOMAIN+'/fz/vod/programs-contents/'+seasionid
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo={'limit':bdLRKMcHWAUDiPpwJgzBtEuevrxslY.EP_LIMIT,'offset':bdLRKMcHWAUDiPpwJgzBtEuevrxsCa((page_int-1)*bdLRKMcHWAUDiPpwJgzBtEuevrxslY.EP_LIMIT),'orderby':orderby,}
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo.update(bdLRKMcHWAUDiPpwJgzBtEuevrxslY.GetDefaultParams(login=bdLRKMcHWAUDiPpwJgzBtEuevrxshN))
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.callRequestCookies('Get',bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,payload=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,params=bdLRKMcHWAUDiPpwJgzBtEuevrxslo,headers=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,cookies=bdLRKMcHWAUDiPpwJgzBtEuevrxshG)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFn=json.loads(bdLRKMcHWAUDiPpwJgzBtEuevrxsFo.text)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsal=bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['cell_toplist']['celllist']
   for bdLRKMcHWAUDiPpwJgzBtEuevrxsaF in bdLRKMcHWAUDiPpwJgzBtEuevrxsal:
    bdLRKMcHWAUDiPpwJgzBtEuevrxsYo=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',bdLRKMcHWAUDiPpwJgzBtEuevrxsaF.get('synopsis'))
    bdLRKMcHWAUDiPpwJgzBtEuevrxsYn=bdLRKMcHWAUDiPpwJgzBtEuevrxsaF.get('thumbnail')
    if not bdLRKMcHWAUDiPpwJgzBtEuevrxsYn.startswith('http'):
     bdLRKMcHWAUDiPpwJgzBtEuevrxsYn=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.HTTPTAG+bdLRKMcHWAUDiPpwJgzBtEuevrxsYn
    bdLRKMcHWAUDiPpwJgzBtEuevrxsYq=bdLRKMcHWAUDiPpwJgzBtEuevrxsYm=bdLRKMcHWAUDiPpwJgzBtEuevrxsYI=''
    bdLRKMcHWAUDiPpwJgzBtEuevrxsYq =bdLRKMcHWAUDiPpwJgzBtEuevrxsYC.get('imgPoster')
    bdLRKMcHWAUDiPpwJgzBtEuevrxsYm =bdLRKMcHWAUDiPpwJgzBtEuevrxsYC.get('imgFanart')
    bdLRKMcHWAUDiPpwJgzBtEuevrxsYI =bdLRKMcHWAUDiPpwJgzBtEuevrxsYC.get('imgClearlogo')
    bdLRKMcHWAUDiPpwJgzBtEuevrxsYy=bdLRKMcHWAUDiPpwJgzBtEuevrxsYC.get('programtitle')
    bdLRKMcHWAUDiPpwJgzBtEuevrxsYT={'thumb':bdLRKMcHWAUDiPpwJgzBtEuevrxsYn,'poster':bdLRKMcHWAUDiPpwJgzBtEuevrxsYq,'fanart':bdLRKMcHWAUDiPpwJgzBtEuevrxsYm,'clearlogo':bdLRKMcHWAUDiPpwJgzBtEuevrxsYI}
    bdLRKMcHWAUDiPpwJgzBtEuevrxsaY={'programtitle':bdLRKMcHWAUDiPpwJgzBtEuevrxslY.Get_ChangeText(bdLRKMcHWAUDiPpwJgzBtEuevrxsYy),'episodetitle':bdLRKMcHWAUDiPpwJgzBtEuevrxslY.Get_ChangeText(bdLRKMcHWAUDiPpwJgzBtEuevrxsaF['title_list'][0]['text']),'episodenumber':bdLRKMcHWAUDiPpwJgzBtEuevrxsaF['title_list'][1]['text'].replace('$O$',''),'contentid':bdLRKMcHWAUDiPpwJgzBtEuevrxsaF['contentid'],'synopsis':bdLRKMcHWAUDiPpwJgzBtEuevrxslY.Get_ChangeText(bdLRKMcHWAUDiPpwJgzBtEuevrxsYo),'episodeactors':bdLRKMcHWAUDiPpwJgzBtEuevrxsaF.get('actors').split(',')if bdLRKMcHWAUDiPpwJgzBtEuevrxsaF.get('actors')!='' else[],'thumbnail':bdLRKMcHWAUDiPpwJgzBtEuevrxsYT,}
    bdLRKMcHWAUDiPpwJgzBtEuevrxsYf.append(bdLRKMcHWAUDiPpwJgzBtEuevrxsaY)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsaf=bdLRKMcHWAUDiPpwJgzBtEuevrxsCT(bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['cell_toplist']['pagecount'])
   if bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['cell_toplist']['count']:bdLRKMcHWAUDiPpwJgzBtEuevrxsaI =bdLRKMcHWAUDiPpwJgzBtEuevrxsCT(bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['cell_toplist']['count'])
   else:bdLRKMcHWAUDiPpwJgzBtEuevrxsaI=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.EP_LIMIT*page_int
   bdLRKMcHWAUDiPpwJgzBtEuevrxsaV=bdLRKMcHWAUDiPpwJgzBtEuevrxsaf>bdLRKMcHWAUDiPpwJgzBtEuevrxsaI
  except bdLRKMcHWAUDiPpwJgzBtEuevrxsCX as exception:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsCk(exception)
   return[],bdLRKMcHWAUDiPpwJgzBtEuevrxshN
  return bdLRKMcHWAUDiPpwJgzBtEuevrxsYf,bdLRKMcHWAUDiPpwJgzBtEuevrxsaV
 def GetEPGList(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,genre):
  bdLRKMcHWAUDiPpwJgzBtEuevrxsYQ={}
  try:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsYj=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.Get_Now_Datetime()
   if genre=='all':
    bdLRKMcHWAUDiPpwJgzBtEuevrxsYG =bdLRKMcHWAUDiPpwJgzBtEuevrxsYj+datetime.timedelta(hours=3)
   else:
    bdLRKMcHWAUDiPpwJgzBtEuevrxsYG =bdLRKMcHWAUDiPpwJgzBtEuevrxsYj+datetime.timedelta(hours=3)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFf=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.API_DOMAIN+'/live/epgs'
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo={'limit':'100','offset':'0','genre':genre,'startdatetime':bdLRKMcHWAUDiPpwJgzBtEuevrxsYj.strftime('%Y-%m-%d %H:00'),'enddatetime':bdLRKMcHWAUDiPpwJgzBtEuevrxsYG.strftime('%Y-%m-%d %H:00')}
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo.update(bdLRKMcHWAUDiPpwJgzBtEuevrxslY.GetDefaultParams(login=bdLRKMcHWAUDiPpwJgzBtEuevrxshN))
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.callRequestCookies('Get',bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,payload=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,params=bdLRKMcHWAUDiPpwJgzBtEuevrxslo,headers=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,cookies=bdLRKMcHWAUDiPpwJgzBtEuevrxshG)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFn=json.loads(bdLRKMcHWAUDiPpwJgzBtEuevrxsFo.text)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsYN=bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['list']
   for bdLRKMcHWAUDiPpwJgzBtEuevrxsaF in bdLRKMcHWAUDiPpwJgzBtEuevrxsYN:
    bdLRKMcHWAUDiPpwJgzBtEuevrxsYS=''
    for bdLRKMcHWAUDiPpwJgzBtEuevrxsXl in bdLRKMcHWAUDiPpwJgzBtEuevrxsaF['list']:
     if bdLRKMcHWAUDiPpwJgzBtEuevrxsYS:bdLRKMcHWAUDiPpwJgzBtEuevrxsYS+='\n'
     bdLRKMcHWAUDiPpwJgzBtEuevrxsYS+=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.Get_ChangeText(bdLRKMcHWAUDiPpwJgzBtEuevrxsXl['title'])+'\n'
     bdLRKMcHWAUDiPpwJgzBtEuevrxsYS+=' [%s ~ %s]'%(bdLRKMcHWAUDiPpwJgzBtEuevrxsXl['starttime'][-5:],bdLRKMcHWAUDiPpwJgzBtEuevrxsXl['endtime'][-5:])+'\n'
    bdLRKMcHWAUDiPpwJgzBtEuevrxsYQ[bdLRKMcHWAUDiPpwJgzBtEuevrxsaF['channelid']]=bdLRKMcHWAUDiPpwJgzBtEuevrxsYS
  except bdLRKMcHWAUDiPpwJgzBtEuevrxsCX as exception:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsCk(exception)
  return bdLRKMcHWAUDiPpwJgzBtEuevrxsYQ
 def Get_LiveChannel_List(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,genre,bdLRKMcHWAUDiPpwJgzBtEuevrxsFN):
  bdLRKMcHWAUDiPpwJgzBtEuevrxsaO=[]
  (bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,bdLRKMcHWAUDiPpwJgzBtEuevrxslo)=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.Baseapi_Parse(bdLRKMcHWAUDiPpwJgzBtEuevrxsFN)
  if bdLRKMcHWAUDiPpwJgzBtEuevrxsFf=='':return bdLRKMcHWAUDiPpwJgzBtEuevrxsaO
  bdLRKMcHWAUDiPpwJgzBtEuevrxsXF=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.GetEPGList(genre)
  try:
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo.update(bdLRKMcHWAUDiPpwJgzBtEuevrxslY.GetDefaultParams(login=bdLRKMcHWAUDiPpwJgzBtEuevrxshN))
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo['genre']=genre
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.callRequestCookies('Get',bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,payload=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,params=bdLRKMcHWAUDiPpwJgzBtEuevrxslo,headers=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,cookies=bdLRKMcHWAUDiPpwJgzBtEuevrxshG)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFn=json.loads(bdLRKMcHWAUDiPpwJgzBtEuevrxsFo.text)
   if not('celllist' in bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['cell_toplist']):return[]
   bdLRKMcHWAUDiPpwJgzBtEuevrxsal=bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['cell_toplist']['celllist']
   for bdLRKMcHWAUDiPpwJgzBtEuevrxsaF in bdLRKMcHWAUDiPpwJgzBtEuevrxsal:
    bdLRKMcHWAUDiPpwJgzBtEuevrxsaS=bdLRKMcHWAUDiPpwJgzBtEuevrxsaF['contentid']
    if bdLRKMcHWAUDiPpwJgzBtEuevrxsaS in bdLRKMcHWAUDiPpwJgzBtEuevrxsXF:
     bdLRKMcHWAUDiPpwJgzBtEuevrxsXa=bdLRKMcHWAUDiPpwJgzBtEuevrxsXF[bdLRKMcHWAUDiPpwJgzBtEuevrxsaS]
    else:
     bdLRKMcHWAUDiPpwJgzBtEuevrxsXa=''
    bdLRKMcHWAUDiPpwJgzBtEuevrxsaY={'studio':bdLRKMcHWAUDiPpwJgzBtEuevrxsaF['title_list'][0]['text'],'tvshowtitle':bdLRKMcHWAUDiPpwJgzBtEuevrxslY.Get_ChangeText(bdLRKMcHWAUDiPpwJgzBtEuevrxsaF['title_list'][1]['text']),'channelid':bdLRKMcHWAUDiPpwJgzBtEuevrxsaS,'age':bdLRKMcHWAUDiPpwJgzBtEuevrxsaF['age'],'thumbnail':'https://%s'%bdLRKMcHWAUDiPpwJgzBtEuevrxsaF.get('thumbnail'),'epg':bdLRKMcHWAUDiPpwJgzBtEuevrxsXa}
    bdLRKMcHWAUDiPpwJgzBtEuevrxsaO.append(bdLRKMcHWAUDiPpwJgzBtEuevrxsaY)
  except bdLRKMcHWAUDiPpwJgzBtEuevrxsCX as exception:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsCk(exception)
   return[]
  return bdLRKMcHWAUDiPpwJgzBtEuevrxsaO
 def Get_Search_List(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,search_key,sType,page_int,exclusion21=bdLRKMcHWAUDiPpwJgzBtEuevrxshN):
  bdLRKMcHWAUDiPpwJgzBtEuevrxsXY=[]
  bdLRKMcHWAUDiPpwJgzBtEuevrxsaf=bdLRKMcHWAUDiPpwJgzBtEuevrxsaI=1
  bdLRKMcHWAUDiPpwJgzBtEuevrxsaV=bdLRKMcHWAUDiPpwJgzBtEuevrxshN
  try:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFf=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.API_DOMAIN+'/fz/search/band.js'
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':bdLRKMcHWAUDiPpwJgzBtEuevrxsCa((page_int-1)*bdLRKMcHWAUDiPpwJgzBtEuevrxslY.SEARCH_LIMIT),'limit':bdLRKMcHWAUDiPpwJgzBtEuevrxslY.SEARCH_LIMIT,'orderby':'score','mtype':'svod',}
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo.update(bdLRKMcHWAUDiPpwJgzBtEuevrxslY.GetDefaultParams(login=bdLRKMcHWAUDiPpwJgzBtEuevrxshN))
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.callRequestCookies('Get',bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,payload=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,params=bdLRKMcHWAUDiPpwJgzBtEuevrxslo,headers=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,cookies=bdLRKMcHWAUDiPpwJgzBtEuevrxshG)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsYl=json.loads(bdLRKMcHWAUDiPpwJgzBtEuevrxsFo.text)
   if not('celllist' in bdLRKMcHWAUDiPpwJgzBtEuevrxsYl['band']):return bdLRKMcHWAUDiPpwJgzBtEuevrxsXY,bdLRKMcHWAUDiPpwJgzBtEuevrxsaV
   bdLRKMcHWAUDiPpwJgzBtEuevrxsal=bdLRKMcHWAUDiPpwJgzBtEuevrxsYl['band']['celllist']
   for bdLRKMcHWAUDiPpwJgzBtEuevrxsaF in bdLRKMcHWAUDiPpwJgzBtEuevrxsal:
    bdLRKMcHWAUDiPpwJgzBtEuevrxsao =bdLRKMcHWAUDiPpwJgzBtEuevrxsaF['event_list'][1]['url']
    bdLRKMcHWAUDiPpwJgzBtEuevrxsan=urllib.parse.urlsplit(bdLRKMcHWAUDiPpwJgzBtEuevrxsao).query
    bdLRKMcHWAUDiPpwJgzBtEuevrxsaq=bdLRKMcHWAUDiPpwJgzBtEuevrxsan[0:bdLRKMcHWAUDiPpwJgzBtEuevrxsan.find('=')]
    bdLRKMcHWAUDiPpwJgzBtEuevrxsaG=bdLRKMcHWAUDiPpwJgzBtEuevrxsCh(urllib.parse.parse_qsl(bdLRKMcHWAUDiPpwJgzBtEuevrxsan))
    bdLRKMcHWAUDiPpwJgzBtEuevrxsam=bdLRKMcHWAUDiPpwJgzBtEuevrxsaG.get(bdLRKMcHWAUDiPpwJgzBtEuevrxsaq)
    bdLRKMcHWAUDiPpwJgzBtEuevrxsaY={'title':bdLRKMcHWAUDiPpwJgzBtEuevrxsaF['title_list'][0]['text'],'age':bdLRKMcHWAUDiPpwJgzBtEuevrxsaF['age'],'thumbnail':'https://%s'%bdLRKMcHWAUDiPpwJgzBtEuevrxsaF.get('thumbnail'),'videoid':bdLRKMcHWAUDiPpwJgzBtEuevrxsam,'vidtype':bdLRKMcHWAUDiPpwJgzBtEuevrxsaq,}
    bdLRKMcHWAUDiPpwJgzBtEuevrxsXk=bdLRKMcHWAUDiPpwJgzBtEuevrxshN
    for bdLRKMcHWAUDiPpwJgzBtEuevrxsXh in bdLRKMcHWAUDiPpwJgzBtEuevrxsaF['bottom_taglist']:
     if bdLRKMcHWAUDiPpwJgzBtEuevrxsXh=='won':
      bdLRKMcHWAUDiPpwJgzBtEuevrxsXk=bdLRKMcHWAUDiPpwJgzBtEuevrxsCl
      break
    if bdLRKMcHWAUDiPpwJgzBtEuevrxsXk==bdLRKMcHWAUDiPpwJgzBtEuevrxsCl: 
     bdLRKMcHWAUDiPpwJgzBtEuevrxsaY['title']=bdLRKMcHWAUDiPpwJgzBtEuevrxsaY['title']+' [개별구매]'
    if exclusion21==bdLRKMcHWAUDiPpwJgzBtEuevrxshN or bdLRKMcHWAUDiPpwJgzBtEuevrxsaF.get('age')!='21':
     bdLRKMcHWAUDiPpwJgzBtEuevrxsXY.append(bdLRKMcHWAUDiPpwJgzBtEuevrxsaY)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsaf=bdLRKMcHWAUDiPpwJgzBtEuevrxsCT(bdLRKMcHWAUDiPpwJgzBtEuevrxsYl['band']['pagecount'])
   if bdLRKMcHWAUDiPpwJgzBtEuevrxsYl['band']['count']:bdLRKMcHWAUDiPpwJgzBtEuevrxsaI =bdLRKMcHWAUDiPpwJgzBtEuevrxsCT(bdLRKMcHWAUDiPpwJgzBtEuevrxsYl['band']['count'])
   else:bdLRKMcHWAUDiPpwJgzBtEuevrxsaI=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.LIST_LIMIT
   bdLRKMcHWAUDiPpwJgzBtEuevrxsaV=bdLRKMcHWAUDiPpwJgzBtEuevrxsaf>bdLRKMcHWAUDiPpwJgzBtEuevrxsaI
  except bdLRKMcHWAUDiPpwJgzBtEuevrxsCX as exception:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsCk(exception)
  return bdLRKMcHWAUDiPpwJgzBtEuevrxsXY,bdLRKMcHWAUDiPpwJgzBtEuevrxsaV 
 def GetSecureToken(bdLRKMcHWAUDiPpwJgzBtEuevrxslY):
  bdLRKMcHWAUDiPpwJgzBtEuevrxsFf=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.API_DOMAIN+'/ip'
  bdLRKMcHWAUDiPpwJgzBtEuevrxslo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.GetDefaultParams(login=bdLRKMcHWAUDiPpwJgzBtEuevrxshN)
  bdLRKMcHWAUDiPpwJgzBtEuevrxsFo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.callRequestCookies('Get',bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,payload=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,params=bdLRKMcHWAUDiPpwJgzBtEuevrxslo,headers=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,cookies=bdLRKMcHWAUDiPpwJgzBtEuevrxshG)
  bdLRKMcHWAUDiPpwJgzBtEuevrxsFn=json.loads(bdLRKMcHWAUDiPpwJgzBtEuevrxsFo.text)
  return bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['securetoken']
 def Wavve_Parse_m3u8(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,bdLRKMcHWAUDiPpwJgzBtEuevrxskC):
  try:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFC={'user-agent':'pooqV2/5.6.0 (Linux;Android 10) ExoPlayerLib/2.13.3'}
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFo=requests.get(url=bdLRKMcHWAUDiPpwJgzBtEuevrxskC['stream_url'],headers=bdLRKMcHWAUDiPpwJgzBtEuevrxsFC,cookies=bdLRKMcHWAUDiPpwJgzBtEuevrxskC['stream_cookie'])
   bdLRKMcHWAUDiPpwJgzBtEuevrxsXC=bdLRKMcHWAUDiPpwJgzBtEuevrxsFo.content.decode('utf-8')
   if '#EXTM3U' not in bdLRKMcHWAUDiPpwJgzBtEuevrxsXC:
    return bdLRKMcHWAUDiPpwJgzBtEuevrxshN
   if '#EXT-X-STREAM-INF' not in bdLRKMcHWAUDiPpwJgzBtEuevrxsXC: 
    return bdLRKMcHWAUDiPpwJgzBtEuevrxshN
   bdLRKMcHWAUDiPpwJgzBtEuevrxsXT=0
   for bdLRKMcHWAUDiPpwJgzBtEuevrxsXO in bdLRKMcHWAUDiPpwJgzBtEuevrxsXC.splitlines():
    if bdLRKMcHWAUDiPpwJgzBtEuevrxsXO.startswith('#EXT-X-STREAM-INF'):
     bdLRKMcHWAUDiPpwJgzBtEuevrxsXf=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.MediaLine_Parse(bdLRKMcHWAUDiPpwJgzBtEuevrxsXO,'#EXT-X-STREAM-INF')
     if bdLRKMcHWAUDiPpwJgzBtEuevrxsXT<bdLRKMcHWAUDiPpwJgzBtEuevrxsCT(bdLRKMcHWAUDiPpwJgzBtEuevrxsXf.get('BANDWIDTH')):
      bdLRKMcHWAUDiPpwJgzBtEuevrxsXT=bdLRKMcHWAUDiPpwJgzBtEuevrxsCT(bdLRKMcHWAUDiPpwJgzBtEuevrxsXf.get('BANDWIDTH'))
   bdLRKMcHWAUDiPpwJgzBtEuevrxsXV=[]
   bdLRKMcHWAUDiPpwJgzBtEuevrxsXo=bdLRKMcHWAUDiPpwJgzBtEuevrxshN
   for bdLRKMcHWAUDiPpwJgzBtEuevrxsXO in bdLRKMcHWAUDiPpwJgzBtEuevrxsXC.splitlines():
    if bdLRKMcHWAUDiPpwJgzBtEuevrxsXo==bdLRKMcHWAUDiPpwJgzBtEuevrxsCl:
     bdLRKMcHWAUDiPpwJgzBtEuevrxsXo=bdLRKMcHWAUDiPpwJgzBtEuevrxshN
     continue
    if bdLRKMcHWAUDiPpwJgzBtEuevrxsXO.startswith('#EXT-X-STREAM-INF'):
     bdLRKMcHWAUDiPpwJgzBtEuevrxsXf=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.MediaLine_Parse(bdLRKMcHWAUDiPpwJgzBtEuevrxsXO,'#EXT-X-STREAM-INF')
     if bdLRKMcHWAUDiPpwJgzBtEuevrxsXT!=bdLRKMcHWAUDiPpwJgzBtEuevrxsCT(bdLRKMcHWAUDiPpwJgzBtEuevrxsXf.get('BANDWIDTH')):
      bdLRKMcHWAUDiPpwJgzBtEuevrxsXo=bdLRKMcHWAUDiPpwJgzBtEuevrxsCl
      continue
    bdLRKMcHWAUDiPpwJgzBtEuevrxsXV.append(bdLRKMcHWAUDiPpwJgzBtEuevrxsXO)
  except bdLRKMcHWAUDiPpwJgzBtEuevrxsCX as exception:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsCk(exception)
   return bdLRKMcHWAUDiPpwJgzBtEuevrxshN
  bdLRKMcHWAUDiPpwJgzBtEuevrxsXn='\n'.join(bdLRKMcHWAUDiPpwJgzBtEuevrxsXV)
  bdLRKMcHWAUDiPpwJgzBtEuevrxslY.TextFile_Save(bdLRKMcHWAUDiPpwJgzBtEuevrxslY.WV_STREAM_FILENAME,bdLRKMcHWAUDiPpwJgzBtEuevrxsXn)
  return bdLRKMcHWAUDiPpwJgzBtEuevrxsCl
 def Wavve_Parse_mpd(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,bdLRKMcHWAUDiPpwJgzBtEuevrxskC):
  bdLRKMcHWAUDiPpwJgzBtEuevrxsFC={'user-agent':'pooqV2/5.6.0 (Linux;Android 10) ExoPlayerLib/2.13.3'}
  bdLRKMcHWAUDiPpwJgzBtEuevrxsFo=requests.get(url=bdLRKMcHWAUDiPpwJgzBtEuevrxskC['stream_url'],headers=bdLRKMcHWAUDiPpwJgzBtEuevrxsFC,cookies=bdLRKMcHWAUDiPpwJgzBtEuevrxskC['stream_cookie'])
  bdLRKMcHWAUDiPpwJgzBtEuevrxsXq=bdLRKMcHWAUDiPpwJgzBtEuevrxsFo.content.decode('utf-8')
  bdLRKMcHWAUDiPpwJgzBtEuevrxsXm =ET.ElementTree(ET.fromstring(bdLRKMcHWAUDiPpwJgzBtEuevrxsXq))
  bdLRKMcHWAUDiPpwJgzBtEuevrxsXI =bdLRKMcHWAUDiPpwJgzBtEuevrxsXm.getroot()
  bdLRKMcHWAUDiPpwJgzBtEuevrxsXy=re.match(r'\{.*\}',bdLRKMcHWAUDiPpwJgzBtEuevrxsXI.tag)[0] 
  bdLRKMcHWAUDiPpwJgzBtEuevrxsXQ=bdLRKMcHWAUDiPpwJgzBtEuevrxsCh([node for _,node in ET.iterparse(io.StringIO(bdLRKMcHWAUDiPpwJgzBtEuevrxsXq),events=['start-ns'])])
  for bdLRKMcHWAUDiPpwJgzBtEuevrxsFk,bdLRKMcHWAUDiPpwJgzBtEuevrxskh in bdLRKMcHWAUDiPpwJgzBtEuevrxsXQ.items():
   ET.register_namespace(bdLRKMcHWAUDiPpwJgzBtEuevrxsFk,bdLRKMcHWAUDiPpwJgzBtEuevrxskh)
  bdLRKMcHWAUDiPpwJgzBtEuevrxsXj=bdLRKMcHWAUDiPpwJgzBtEuevrxsXI.find(bdLRKMcHWAUDiPpwJgzBtEuevrxsXy+'Period')
  for bdLRKMcHWAUDiPpwJgzBtEuevrxsXG in bdLRKMcHWAUDiPpwJgzBtEuevrxsXj.findall(bdLRKMcHWAUDiPpwJgzBtEuevrxsXy+'AdaptationSet'):
   if bdLRKMcHWAUDiPpwJgzBtEuevrxsXG.attrib.get('mimeType')=='video/mp4':
    bdLRKMcHWAUDiPpwJgzBtEuevrxsXN=0
    for bdLRKMcHWAUDiPpwJgzBtEuevrxsXS in bdLRKMcHWAUDiPpwJgzBtEuevrxsXG.findall(bdLRKMcHWAUDiPpwJgzBtEuevrxsXy+'Representation'):
     bdLRKMcHWAUDiPpwJgzBtEuevrxskl=bdLRKMcHWAUDiPpwJgzBtEuevrxsCT(bdLRKMcHWAUDiPpwJgzBtEuevrxsXS.attrib.get('bandwidth'))
     if bdLRKMcHWAUDiPpwJgzBtEuevrxsXN<bdLRKMcHWAUDiPpwJgzBtEuevrxskl:bdLRKMcHWAUDiPpwJgzBtEuevrxsXN=bdLRKMcHWAUDiPpwJgzBtEuevrxskl
    for bdLRKMcHWAUDiPpwJgzBtEuevrxsXS in bdLRKMcHWAUDiPpwJgzBtEuevrxsXG.findall(bdLRKMcHWAUDiPpwJgzBtEuevrxsXy+'Representation'):
     if bdLRKMcHWAUDiPpwJgzBtEuevrxsXN>bdLRKMcHWAUDiPpwJgzBtEuevrxsCT(bdLRKMcHWAUDiPpwJgzBtEuevrxsXS.attrib.get('bandwidth')):
      bdLRKMcHWAUDiPpwJgzBtEuevrxsXG.remove(bdLRKMcHWAUDiPpwJgzBtEuevrxsXS)
   elif bdLRKMcHWAUDiPpwJgzBtEuevrxsXG.attrib.get('mimeType')=='audio/mp4':
    bdLRKMcHWAUDiPpwJgzBtEuevrxsXN=0
    for bdLRKMcHWAUDiPpwJgzBtEuevrxsXS in bdLRKMcHWAUDiPpwJgzBtEuevrxsXG.findall(bdLRKMcHWAUDiPpwJgzBtEuevrxsXy+'Representation'):
     bdLRKMcHWAUDiPpwJgzBtEuevrxskl=bdLRKMcHWAUDiPpwJgzBtEuevrxsCT(bdLRKMcHWAUDiPpwJgzBtEuevrxsXS.attrib.get('bandwidth'))
     if bdLRKMcHWAUDiPpwJgzBtEuevrxsXN<bdLRKMcHWAUDiPpwJgzBtEuevrxskl:bdLRKMcHWAUDiPpwJgzBtEuevrxsXN=bdLRKMcHWAUDiPpwJgzBtEuevrxskl
    for bdLRKMcHWAUDiPpwJgzBtEuevrxsXS in bdLRKMcHWAUDiPpwJgzBtEuevrxsXG.findall(bdLRKMcHWAUDiPpwJgzBtEuevrxsXy+'Representation'):
     if bdLRKMcHWAUDiPpwJgzBtEuevrxsXN>bdLRKMcHWAUDiPpwJgzBtEuevrxsCT(bdLRKMcHWAUDiPpwJgzBtEuevrxsXS.attrib.get('bandwidth')):
      bdLRKMcHWAUDiPpwJgzBtEuevrxsXG.remove(bdLRKMcHWAUDiPpwJgzBtEuevrxsXS)
   else:
    continue
  bdLRKMcHWAUDiPpwJgzBtEuevrxskF=ET.tostring(bdLRKMcHWAUDiPpwJgzBtEuevrxsXI).decode('utf-8')
  bdLRKMcHWAUDiPpwJgzBtEuevrxska='<?xml version="1.0" encoding="UTF-8"?>\n'
  bdLRKMcHWAUDiPpwJgzBtEuevrxslY.TextFile_Save(bdLRKMcHWAUDiPpwJgzBtEuevrxslY.WV_STREAM_FILENAME,bdLRKMcHWAUDiPpwJgzBtEuevrxska+bdLRKMcHWAUDiPpwJgzBtEuevrxskF)
  return bdLRKMcHWAUDiPpwJgzBtEuevrxsCl
 def MediaLine_Parse(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,bdLRKMcHWAUDiPpwJgzBtEuevrxsXO,prefix):
  bdLRKMcHWAUDiPpwJgzBtEuevrxsXf={}
  for bdLRKMcHWAUDiPpwJgzBtEuevrxskY in bdLRKMcHWAUDiPpwJgzBtEuevrxsla.split(bdLRKMcHWAUDiPpwJgzBtEuevrxsXO.replace(prefix+':',''))[1::2]:
   bdLRKMcHWAUDiPpwJgzBtEuevrxskX,bdLRKMcHWAUDiPpwJgzBtEuevrxskh=bdLRKMcHWAUDiPpwJgzBtEuevrxskY.split('=',1)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsXf[bdLRKMcHWAUDiPpwJgzBtEuevrxskX.upper()]=bdLRKMcHWAUDiPpwJgzBtEuevrxskh.replace('"','').strip()
  return bdLRKMcHWAUDiPpwJgzBtEuevrxsXf
 def GetStreamingURL(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,mode,bdLRKMcHWAUDiPpwJgzBtEuevrxsaS,quality_int,pvrmode='-',playOption={}):
  bdLRKMcHWAUDiPpwJgzBtEuevrxskC ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  bdLRKMcHWAUDiPpwJgzBtEuevrxskT=[]
  if mode=='LIVE':
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFf =bdLRKMcHWAUDiPpwJgzBtEuevrxslY.API_DOMAIN+'/live/channels/'+bdLRKMcHWAUDiPpwJgzBtEuevrxsaS
   bdLRKMcHWAUDiPpwJgzBtEuevrxskO='live'
  elif mode=='VOD':
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFf =bdLRKMcHWAUDiPpwJgzBtEuevrxslY.API_DOMAIN+'/fz/vod/contents-detail/'+bdLRKMcHWAUDiPpwJgzBtEuevrxsaS 
   bdLRKMcHWAUDiPpwJgzBtEuevrxskO='vod'
  elif mode=='MOVIE':
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFf =bdLRKMcHWAUDiPpwJgzBtEuevrxslY.API_DOMAIN+'/fz/movie/contents/'+bdLRKMcHWAUDiPpwJgzBtEuevrxsaS
   bdLRKMcHWAUDiPpwJgzBtEuevrxskO='movie'
  bdLRKMcHWAUDiPpwJgzBtEuevrxskf={'hdr':'sdr','uhd':'-',}
  try:
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.GetDefaultParams(login=bdLRKMcHWAUDiPpwJgzBtEuevrxshN)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.callRequestCookies('Get',bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,payload=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,params=bdLRKMcHWAUDiPpwJgzBtEuevrxslo,headers=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,cookies=bdLRKMcHWAUDiPpwJgzBtEuevrxshG)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFn=json.loads(bdLRKMcHWAUDiPpwJgzBtEuevrxsFo.text)
   bdLRKMcHWAUDiPpwJgzBtEuevrxskV=bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['qualities']['list']
   if bdLRKMcHWAUDiPpwJgzBtEuevrxskV==bdLRKMcHWAUDiPpwJgzBtEuevrxshG:return bdLRKMcHWAUDiPpwJgzBtEuevrxskC
   for bdLRKMcHWAUDiPpwJgzBtEuevrxsko in bdLRKMcHWAUDiPpwJgzBtEuevrxskV:
    bdLRKMcHWAUDiPpwJgzBtEuevrxskT.append(bdLRKMcHWAUDiPpwJgzBtEuevrxsCT(bdLRKMcHWAUDiPpwJgzBtEuevrxsko.get('id').rstrip('p')))
   if 'type' in bdLRKMcHWAUDiPpwJgzBtEuevrxsFn:
    if bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['type']=='onair':
     bdLRKMcHWAUDiPpwJgzBtEuevrxskO='onairvod'
   if 'drms' in bdLRKMcHWAUDiPpwJgzBtEuevrxsFn:
    if bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['drms']:
     bdLRKMcHWAUDiPpwJgzBtEuevrxskC['stream_action']='dash' 
   if playOption.get('enable_hdr'):
    if 'mediatypes' in bdLRKMcHWAUDiPpwJgzBtEuevrxsFn.get('qualities'):
     for bdLRKMcHWAUDiPpwJgzBtEuevrxskn in bdLRKMcHWAUDiPpwJgzBtEuevrxsFn.get('qualities').get('mediatypes'):
      if bdLRKMcHWAUDiPpwJgzBtEuevrxskn=='HDR10':
       bdLRKMcHWAUDiPpwJgzBtEuevrxskf['hdr']='hdr'
       bdLRKMcHWAUDiPpwJgzBtEuevrxskC['stream_action']='dash'
       break
   if playOption.get('enable_uhd'):
    for bdLRKMcHWAUDiPpwJgzBtEuevrxskn in bdLRKMcHWAUDiPpwJgzBtEuevrxsFn.get('qualities').get('list'):
     if bdLRKMcHWAUDiPpwJgzBtEuevrxskn.get('name')=='UHD':
      bdLRKMcHWAUDiPpwJgzBtEuevrxskf['uhd']='uhd'
      break
  except bdLRKMcHWAUDiPpwJgzBtEuevrxsCX as exception:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsCk(exception)
   return bdLRKMcHWAUDiPpwJgzBtEuevrxskC
  bdLRKMcHWAUDiPpwJgzBtEuevrxsCk('stream_action : '+bdLRKMcHWAUDiPpwJgzBtEuevrxskC['stream_action'])
  try:
   bdLRKMcHWAUDiPpwJgzBtEuevrxskq=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.CheckQuality(quality_int,bdLRKMcHWAUDiPpwJgzBtEuevrxskT)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsCk(bdLRKMcHWAUDiPpwJgzBtEuevrxskq)
   if bdLRKMcHWAUDiPpwJgzBtEuevrxskq<1080:
    bdLRKMcHWAUDiPpwJgzBtEuevrxskf['uhd']='-'
    bdLRKMcHWAUDiPpwJgzBtEuevrxskf['hdr']='sdr'
   if bdLRKMcHWAUDiPpwJgzBtEuevrxskf['uhd']=='uhd':bdLRKMcHWAUDiPpwJgzBtEuevrxskq=2160 
   bdLRKMcHWAUDiPpwJgzBtEuevrxskm=bdLRKMcHWAUDiPpwJgzBtEuevrxsCa(bdLRKMcHWAUDiPpwJgzBtEuevrxskq)+'p'
   bdLRKMcHWAUDiPpwJgzBtEuevrxsCk(bdLRKMcHWAUDiPpwJgzBtEuevrxskm)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFf=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.API_DOMAIN+'/fz/streaming'
   if bdLRKMcHWAUDiPpwJgzBtEuevrxskf['hdr']=='hdr' or bdLRKMcHWAUDiPpwJgzBtEuevrxskf['uhd']=='uhd':
    bdLRKMcHWAUDiPpwJgzBtEuevrxslo={'contentid':bdLRKMcHWAUDiPpwJgzBtEuevrxsaS,'contenttype':bdLRKMcHWAUDiPpwJgzBtEuevrxskO,'quality':bdLRKMcHWAUDiPpwJgzBtEuevrxskm,'modelid':'SHIELD Android TV','guid':bdLRKMcHWAUDiPpwJgzBtEuevrxslY.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n','protocol':bdLRKMcHWAUDiPpwJgzBtEuevrxskC['stream_action'],'hdr':'HDR10','videocodec':'HEVC','audiocodec':'AAC','issurround':'y','format':'normal','withinsubtitle':'n',}
    bdLRKMcHWAUDiPpwJgzBtEuevrxslo.update(bdLRKMcHWAUDiPpwJgzBtEuevrxslY.GetDefaultParams_AND())
   else:
    bdLRKMcHWAUDiPpwJgzBtEuevrxslo={'contentid':bdLRKMcHWAUDiPpwJgzBtEuevrxsaS,'contenttype':bdLRKMcHWAUDiPpwJgzBtEuevrxskO,'quality':bdLRKMcHWAUDiPpwJgzBtEuevrxskm,'deviceModelId':'Windows 10','guid':bdLRKMcHWAUDiPpwJgzBtEuevrxslY.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n','action':bdLRKMcHWAUDiPpwJgzBtEuevrxskC['stream_action'],'protocol':bdLRKMcHWAUDiPpwJgzBtEuevrxskC['stream_action'],'hdr':'sdr','videocodec':'avc','audiocodec':'aac','issurround':'n','format':'normal','withinsubtitle':'n',}
    bdLRKMcHWAUDiPpwJgzBtEuevrxslo.update(bdLRKMcHWAUDiPpwJgzBtEuevrxslY.GetDefaultParams(login=bdLRKMcHWAUDiPpwJgzBtEuevrxsCl))
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.callRequestCookies('Get',bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,payload=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,params=bdLRKMcHWAUDiPpwJgzBtEuevrxslo,headers=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,cookies=bdLRKMcHWAUDiPpwJgzBtEuevrxshG)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFn=json.loads(bdLRKMcHWAUDiPpwJgzBtEuevrxsFo.text)
   bdLRKMcHWAUDiPpwJgzBtEuevrxskC['stream_url']=bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['playurl']
   if bdLRKMcHWAUDiPpwJgzBtEuevrxskC['stream_url']==bdLRKMcHWAUDiPpwJgzBtEuevrxshG:return bdLRKMcHWAUDiPpwJgzBtEuevrxskC
   bdLRKMcHWAUDiPpwJgzBtEuevrxskC['stream_cookie']=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.make_str_ToCookie(bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['awscookie'])
   bdLRKMcHWAUDiPpwJgzBtEuevrxskC['stream_drm'] =bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['drm']
   if 'previewmsg' in bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['preview']:bdLRKMcHWAUDiPpwJgzBtEuevrxskC['stream_preview']=bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['preview']['previewmsg']
   if 'subtitles' in bdLRKMcHWAUDiPpwJgzBtEuevrxsFn:
    for bdLRKMcHWAUDiPpwJgzBtEuevrxskI in bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['subtitles']:
     if bdLRKMcHWAUDiPpwJgzBtEuevrxskI.get('languagecode')=='ko':
      bdLRKMcHWAUDiPpwJgzBtEuevrxskC['stream_vtt']=bdLRKMcHWAUDiPpwJgzBtEuevrxskI.get('url')
      break
    if bdLRKMcHWAUDiPpwJgzBtEuevrxskC['stream_vtt']=='':
     for bdLRKMcHWAUDiPpwJgzBtEuevrxskI in bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['subtitles']:
      if bdLRKMcHWAUDiPpwJgzBtEuevrxskI.get('languagecode')=='ko_cc':
       bdLRKMcHWAUDiPpwJgzBtEuevrxskC['stream_vtt']=bdLRKMcHWAUDiPpwJgzBtEuevrxskI.get('url')
       break
   bdLRKMcHWAUDiPpwJgzBtEuevrxskC['playParam']=bdLRKMcHWAUDiPpwJgzBtEuevrxskf 
  except bdLRKMcHWAUDiPpwJgzBtEuevrxsCX as exception:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsCk(exception)
  return bdLRKMcHWAUDiPpwJgzBtEuevrxskC 
 def GetSportsURL(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,bdLRKMcHWAUDiPpwJgzBtEuevrxsaS,quality_int):
  bdLRKMcHWAUDiPpwJgzBtEuevrxskC ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  bdLRKMcHWAUDiPpwJgzBtEuevrxskT=[]
  try:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFf=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.API_DOMAIN+'/streaming/other'
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo={'contentid':bdLRKMcHWAUDiPpwJgzBtEuevrxsaS,'contenttype':'live','action':bdLRKMcHWAUDiPpwJgzBtEuevrxskC['stream_action'],'quality':bdLRKMcHWAUDiPpwJgzBtEuevrxsCa(quality_int)+'p','deviceModelId':'Windows 10','guid':bdLRKMcHWAUDiPpwJgzBtEuevrxslY.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n',}
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo.update(bdLRKMcHWAUDiPpwJgzBtEuevrxslY.GetDefaultParams(login=bdLRKMcHWAUDiPpwJgzBtEuevrxsCl))
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.callRequestCookies('Get',bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,payload=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,params=bdLRKMcHWAUDiPpwJgzBtEuevrxslo,headers=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,cookies=bdLRKMcHWAUDiPpwJgzBtEuevrxshG)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFn=json.loads(bdLRKMcHWAUDiPpwJgzBtEuevrxsFo.text)
   bdLRKMcHWAUDiPpwJgzBtEuevrxskC['stream_url']=bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['playurl']
   if bdLRKMcHWAUDiPpwJgzBtEuevrxskC['stream_url']==bdLRKMcHWAUDiPpwJgzBtEuevrxshG:return bdLRKMcHWAUDiPpwJgzBtEuevrxskC
   bdLRKMcHWAUDiPpwJgzBtEuevrxskC['stream_cookie']=bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['awscookie']
  except bdLRKMcHWAUDiPpwJgzBtEuevrxsCX as exception:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsCk(exception)
  return bdLRKMcHWAUDiPpwJgzBtEuevrxskC
 def make_viewdate(bdLRKMcHWAUDiPpwJgzBtEuevrxslY):
  bdLRKMcHWAUDiPpwJgzBtEuevrxsky =bdLRKMcHWAUDiPpwJgzBtEuevrxslY.Get_Now_Datetime()
  bdLRKMcHWAUDiPpwJgzBtEuevrxskQ =bdLRKMcHWAUDiPpwJgzBtEuevrxsky+datetime.timedelta(days=-1)
  bdLRKMcHWAUDiPpwJgzBtEuevrxskj =bdLRKMcHWAUDiPpwJgzBtEuevrxsky+datetime.timedelta(days=1)
  bdLRKMcHWAUDiPpwJgzBtEuevrxskG=[bdLRKMcHWAUDiPpwJgzBtEuevrxsky.strftime('%Y%m%d'),bdLRKMcHWAUDiPpwJgzBtEuevrxskj.strftime('%Y%m%d'),]
  return bdLRKMcHWAUDiPpwJgzBtEuevrxskG
 def Get_Sports_Gamelist(bdLRKMcHWAUDiPpwJgzBtEuevrxslY):
  bdLRKMcHWAUDiPpwJgzBtEuevrxskN =bdLRKMcHWAUDiPpwJgzBtEuevrxslY.make_viewdate()
  bdLRKMcHWAUDiPpwJgzBtEuevrxskS=[]
  bdLRKMcHWAUDiPpwJgzBtEuevrxshl =[]
  for bdLRKMcHWAUDiPpwJgzBtEuevrxshF in bdLRKMcHWAUDiPpwJgzBtEuevrxskN:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsha=bdLRKMcHWAUDiPpwJgzBtEuevrxshF[:6]
   if bdLRKMcHWAUDiPpwJgzBtEuevrxsha not in bdLRKMcHWAUDiPpwJgzBtEuevrxskS:
    bdLRKMcHWAUDiPpwJgzBtEuevrxskS.append(bdLRKMcHWAUDiPpwJgzBtEuevrxsha)
  try:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFf='https://annexapi.wavve.com/skb/baseball/teammonthlycalendarlist'
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo={'IF':'IF-PORG-002','m':'getTeamCalendarListBand','response_format':'json','spo_itm_cd':'KBO','teamcd':'all','tgroup':'B','tvalue':'BC123','ver':'2.0',}
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo.update(bdLRKMcHWAUDiPpwJgzBtEuevrxslY.GetDefaultParams(login=bdLRKMcHWAUDiPpwJgzBtEuevrxshN))
   for bdLRKMcHWAUDiPpwJgzBtEuevrxshY in bdLRKMcHWAUDiPpwJgzBtEuevrxskS:
    bdLRKMcHWAUDiPpwJgzBtEuevrxslo['date']=bdLRKMcHWAUDiPpwJgzBtEuevrxshY
    bdLRKMcHWAUDiPpwJgzBtEuevrxsFo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.callRequestCookies('Get',bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,payload=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,params=bdLRKMcHWAUDiPpwJgzBtEuevrxslo,headers=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,cookies=bdLRKMcHWAUDiPpwJgzBtEuevrxshG)
    bdLRKMcHWAUDiPpwJgzBtEuevrxsFn=json.loads(bdLRKMcHWAUDiPpwJgzBtEuevrxsFo.text)
    bdLRKMcHWAUDiPpwJgzBtEuevrxsal=bdLRKMcHWAUDiPpwJgzBtEuevrxsFn['cell_toplist']['celllist']
    for bdLRKMcHWAUDiPpwJgzBtEuevrxsaF in bdLRKMcHWAUDiPpwJgzBtEuevrxsal:
     bdLRKMcHWAUDiPpwJgzBtEuevrxshX=bdLRKMcHWAUDiPpwJgzBtEuevrxsaF.get('game_date')
     bdLRKMcHWAUDiPpwJgzBtEuevrxshk =bdLRKMcHWAUDiPpwJgzBtEuevrxsaF.get('svc_id')
     if bdLRKMcHWAUDiPpwJgzBtEuevrxshk=='':continue
     if bdLRKMcHWAUDiPpwJgzBtEuevrxshX in bdLRKMcHWAUDiPpwJgzBtEuevrxskN:
      bdLRKMcHWAUDiPpwJgzBtEuevrxshC=bdLRKMcHWAUDiPpwJgzBtEuevrxsaF.get('game_status') 
      bdLRKMcHWAUDiPpwJgzBtEuevrxshT =bdLRKMcHWAUDiPpwJgzBtEuevrxsaF.get('title_list')[0].get('text')
      bdLRKMcHWAUDiPpwJgzBtEuevrxshX =bdLRKMcHWAUDiPpwJgzBtEuevrxshX[:4]+'-'+bdLRKMcHWAUDiPpwJgzBtEuevrxshX[4:6]+'-'+bdLRKMcHWAUDiPpwJgzBtEuevrxshX[-2:]
      bdLRKMcHWAUDiPpwJgzBtEuevrxshO =bdLRKMcHWAUDiPpwJgzBtEuevrxsaF.get('game_time')
      bdLRKMcHWAUDiPpwJgzBtEuevrxshO =bdLRKMcHWAUDiPpwJgzBtEuevrxshO[:2]+':'+bdLRKMcHWAUDiPpwJgzBtEuevrxshO[-2:]
      bdLRKMcHWAUDiPpwJgzBtEuevrxsaY={'game_date':bdLRKMcHWAUDiPpwJgzBtEuevrxshX,'game_time':bdLRKMcHWAUDiPpwJgzBtEuevrxshO,'svc_id':bdLRKMcHWAUDiPpwJgzBtEuevrxshk,'away_team':bdLRKMcHWAUDiPpwJgzBtEuevrxsaF.get('away_team').get('team_name'),'home_team':bdLRKMcHWAUDiPpwJgzBtEuevrxsaF.get('home_team').get('team_name'),'game_status':bdLRKMcHWAUDiPpwJgzBtEuevrxshC,'game_place':bdLRKMcHWAUDiPpwJgzBtEuevrxsaF.get('game_place'),}
      bdLRKMcHWAUDiPpwJgzBtEuevrxshl.append(bdLRKMcHWAUDiPpwJgzBtEuevrxsaY)
  except bdLRKMcHWAUDiPpwJgzBtEuevrxsCX as exception:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsCk(exception)
   return[]
  bdLRKMcHWAUDiPpwJgzBtEuevrxshf=[]
  for i in bdLRKMcHWAUDiPpwJgzBtEuevrxsCF(2):
   for bdLRKMcHWAUDiPpwJgzBtEuevrxsaF in bdLRKMcHWAUDiPpwJgzBtEuevrxshl:
    if i==0 and bdLRKMcHWAUDiPpwJgzBtEuevrxsaF.get('game_status')=='LIVE':
     bdLRKMcHWAUDiPpwJgzBtEuevrxshf.append(bdLRKMcHWAUDiPpwJgzBtEuevrxsaF)
    elif i==1 and bdLRKMcHWAUDiPpwJgzBtEuevrxsaF.get('game_status')!='LIVE':
     bdLRKMcHWAUDiPpwJgzBtEuevrxshf.append(bdLRKMcHWAUDiPpwJgzBtEuevrxsaF)
  return bdLRKMcHWAUDiPpwJgzBtEuevrxshf
 def GetBookmarkInfo(bdLRKMcHWAUDiPpwJgzBtEuevrxslY,bdLRKMcHWAUDiPpwJgzBtEuevrxsam,bdLRKMcHWAUDiPpwJgzBtEuevrxsaq,bdLRKMcHWAUDiPpwJgzBtEuevrxskO):
  if bdLRKMcHWAUDiPpwJgzBtEuevrxsaq=='tvshow':
   if bdLRKMcHWAUDiPpwJgzBtEuevrxskO=='contentid':
    bdLRKMcHWAUDiPpwJgzBtEuevrxsaS=bdLRKMcHWAUDiPpwJgzBtEuevrxsam
    bdLRKMcHWAUDiPpwJgzBtEuevrxsam =bdLRKMcHWAUDiPpwJgzBtEuevrxslY.ContentidToSeasonid(bdLRKMcHWAUDiPpwJgzBtEuevrxsaS)
   else:
    bdLRKMcHWAUDiPpwJgzBtEuevrxsaS=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.ProgramidToContentid(bdLRKMcHWAUDiPpwJgzBtEuevrxsam)
  else:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsaS=''
  bdLRKMcHWAUDiPpwJgzBtEuevrxshV={'indexinfo':{'ott':'wavve','videoid':bdLRKMcHWAUDiPpwJgzBtEuevrxsam,'vidtype':bdLRKMcHWAUDiPpwJgzBtEuevrxsaq,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':bdLRKMcHWAUDiPpwJgzBtEuevrxsaq,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if bdLRKMcHWAUDiPpwJgzBtEuevrxsaq=='tvshow':
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFf=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.API_DOMAIN+'/fz/vod/contents/'+bdLRKMcHWAUDiPpwJgzBtEuevrxsaS 
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.GetDefaultParams(login=bdLRKMcHWAUDiPpwJgzBtEuevrxshN)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.callRequestCookies('Get',bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,payload=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,params=bdLRKMcHWAUDiPpwJgzBtEuevrxslo,headers=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,cookies=bdLRKMcHWAUDiPpwJgzBtEuevrxshG)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFn=json.loads(bdLRKMcHWAUDiPpwJgzBtEuevrxsFo.text)
   if not('programtitle' in bdLRKMcHWAUDiPpwJgzBtEuevrxsFn):return{}
   bdLRKMcHWAUDiPpwJgzBtEuevrxsho=bdLRKMcHWAUDiPpwJgzBtEuevrxsFn
   bdLRKMcHWAUDiPpwJgzBtEuevrxshn=bdLRKMcHWAUDiPpwJgzBtEuevrxsho.get('programtitle')
   bdLRKMcHWAUDiPpwJgzBtEuevrxshV['saveinfo']['infoLabels']['title']=bdLRKMcHWAUDiPpwJgzBtEuevrxshn
   if bdLRKMcHWAUDiPpwJgzBtEuevrxsho.get('targetage')=='18' or bdLRKMcHWAUDiPpwJgzBtEuevrxsho.get('targetage')=='19' or bdLRKMcHWAUDiPpwJgzBtEuevrxsho.get('targetage')=='21':
    bdLRKMcHWAUDiPpwJgzBtEuevrxshn +=u' (%s)'%(bdLRKMcHWAUDiPpwJgzBtEuevrxsho.get('targetage'))
   bdLRKMcHWAUDiPpwJgzBtEuevrxshV['saveinfo']['title'] =bdLRKMcHWAUDiPpwJgzBtEuevrxshn
   bdLRKMcHWAUDiPpwJgzBtEuevrxshV['saveinfo']['infoLabels']['mpaa'] =bdLRKMcHWAUDiPpwJgzBtEuevrxsho.get('targetage')
   bdLRKMcHWAUDiPpwJgzBtEuevrxshV['saveinfo']['infoLabels']['plot'] =bdLRKMcHWAUDiPpwJgzBtEuevrxslY.Get_ChangeText(bdLRKMcHWAUDiPpwJgzBtEuevrxsho.get('programsynopsis'))
   bdLRKMcHWAUDiPpwJgzBtEuevrxshV['saveinfo']['infoLabels']['studio'] =bdLRKMcHWAUDiPpwJgzBtEuevrxsho.get('channelname')
   if bdLRKMcHWAUDiPpwJgzBtEuevrxsho.get('firstreleaseyear')!='':bdLRKMcHWAUDiPpwJgzBtEuevrxshV['saveinfo']['infoLabels']['year'] =bdLRKMcHWAUDiPpwJgzBtEuevrxsho.get('firstreleaseyear')
   if bdLRKMcHWAUDiPpwJgzBtEuevrxsho.get('firstreleasedate')!='':bdLRKMcHWAUDiPpwJgzBtEuevrxshV['saveinfo']['infoLabels']['premiered']=bdLRKMcHWAUDiPpwJgzBtEuevrxsho.get('firstreleasedate')
   if bdLRKMcHWAUDiPpwJgzBtEuevrxsho.get('genretext') !='':bdLRKMcHWAUDiPpwJgzBtEuevrxshV['saveinfo']['infoLabels']['genre'] =[bdLRKMcHWAUDiPpwJgzBtEuevrxsho.get('genretext')]
   bdLRKMcHWAUDiPpwJgzBtEuevrxshq=[]
   for bdLRKMcHWAUDiPpwJgzBtEuevrxshm in bdLRKMcHWAUDiPpwJgzBtEuevrxsho['actors']['list']:bdLRKMcHWAUDiPpwJgzBtEuevrxshq.append(bdLRKMcHWAUDiPpwJgzBtEuevrxshm.get('text'))
   if bdLRKMcHWAUDiPpwJgzBtEuevrxsCY(bdLRKMcHWAUDiPpwJgzBtEuevrxshq)>0:
    if bdLRKMcHWAUDiPpwJgzBtEuevrxshq[0]!='':bdLRKMcHWAUDiPpwJgzBtEuevrxshV['saveinfo']['infoLabels']['cast']=bdLRKMcHWAUDiPpwJgzBtEuevrxshq
   bdLRKMcHWAUDiPpwJgzBtEuevrxsYq =''
   bdLRKMcHWAUDiPpwJgzBtEuevrxsYm =''
   bdLRKMcHWAUDiPpwJgzBtEuevrxsYI=''
   if bdLRKMcHWAUDiPpwJgzBtEuevrxsho.get('programposterimage')!='':bdLRKMcHWAUDiPpwJgzBtEuevrxsYq =bdLRKMcHWAUDiPpwJgzBtEuevrxslY.HTTPTAG+bdLRKMcHWAUDiPpwJgzBtEuevrxsho.get('programposterimage')
   if bdLRKMcHWAUDiPpwJgzBtEuevrxsho.get('programimage') !='':bdLRKMcHWAUDiPpwJgzBtEuevrxsYm =bdLRKMcHWAUDiPpwJgzBtEuevrxslY.HTTPTAG+bdLRKMcHWAUDiPpwJgzBtEuevrxsho.get('programimage')
   if bdLRKMcHWAUDiPpwJgzBtEuevrxsho.get('programcircleimage')!='':bdLRKMcHWAUDiPpwJgzBtEuevrxsYI=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.HTTPTAG+bdLRKMcHWAUDiPpwJgzBtEuevrxsho.get('programcircleimage')
   if 'poster_default' in bdLRKMcHWAUDiPpwJgzBtEuevrxsYq:
    bdLRKMcHWAUDiPpwJgzBtEuevrxsYq =bdLRKMcHWAUDiPpwJgzBtEuevrxsYm
    bdLRKMcHWAUDiPpwJgzBtEuevrxsYI=''
   bdLRKMcHWAUDiPpwJgzBtEuevrxshV['saveinfo']['thumbnail']['poster']=bdLRKMcHWAUDiPpwJgzBtEuevrxsYq
   bdLRKMcHWAUDiPpwJgzBtEuevrxshV['saveinfo']['thumbnail']['thumb']=bdLRKMcHWAUDiPpwJgzBtEuevrxsYm
   bdLRKMcHWAUDiPpwJgzBtEuevrxshV['saveinfo']['thumbnail']['clearlogo']=bdLRKMcHWAUDiPpwJgzBtEuevrxsYI
   bdLRKMcHWAUDiPpwJgzBtEuevrxshV['saveinfo']['thumbnail']['fanart']=bdLRKMcHWAUDiPpwJgzBtEuevrxsYm
  else:
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFf=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.API_DOMAIN+'/movie/contents/'+bdLRKMcHWAUDiPpwJgzBtEuevrxsam 
   bdLRKMcHWAUDiPpwJgzBtEuevrxslo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.GetDefaultParams(login=bdLRKMcHWAUDiPpwJgzBtEuevrxshN)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFo=bdLRKMcHWAUDiPpwJgzBtEuevrxslY.callRequestCookies('Get',bdLRKMcHWAUDiPpwJgzBtEuevrxsFf,payload=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,params=bdLRKMcHWAUDiPpwJgzBtEuevrxslo,headers=bdLRKMcHWAUDiPpwJgzBtEuevrxshG,cookies=bdLRKMcHWAUDiPpwJgzBtEuevrxshG)
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFn=json.loads(bdLRKMcHWAUDiPpwJgzBtEuevrxsFo.text)
   if not('title' in bdLRKMcHWAUDiPpwJgzBtEuevrxsFn):return{}
   bdLRKMcHWAUDiPpwJgzBtEuevrxsho=bdLRKMcHWAUDiPpwJgzBtEuevrxsFn
   bdLRKMcHWAUDiPpwJgzBtEuevrxshn=bdLRKMcHWAUDiPpwJgzBtEuevrxsho.get('title')
   bdLRKMcHWAUDiPpwJgzBtEuevrxshV['saveinfo']['infoLabels']['title']=bdLRKMcHWAUDiPpwJgzBtEuevrxshn
   if bdLRKMcHWAUDiPpwJgzBtEuevrxsho.get('targetage')=='18' or bdLRKMcHWAUDiPpwJgzBtEuevrxsho.get('targetage')=='19' or bdLRKMcHWAUDiPpwJgzBtEuevrxsho.get('targetage')=='21':
    bdLRKMcHWAUDiPpwJgzBtEuevrxshn +=u' (%s)'%(bdLRKMcHWAUDiPpwJgzBtEuevrxsho.get('targetage'))
   bdLRKMcHWAUDiPpwJgzBtEuevrxshV['saveinfo']['title'] =bdLRKMcHWAUDiPpwJgzBtEuevrxshn
   bdLRKMcHWAUDiPpwJgzBtEuevrxshV['saveinfo']['infoLabels']['mpaa'] =bdLRKMcHWAUDiPpwJgzBtEuevrxsho.get('targetage')
   bdLRKMcHWAUDiPpwJgzBtEuevrxshV['saveinfo']['infoLabels']['plot'] =bdLRKMcHWAUDiPpwJgzBtEuevrxslY.Get_ChangeText(bdLRKMcHWAUDiPpwJgzBtEuevrxsho.get('synopsis'))
   bdLRKMcHWAUDiPpwJgzBtEuevrxshV['saveinfo']['infoLabels']['duration']=bdLRKMcHWAUDiPpwJgzBtEuevrxsho.get('playtime')
   bdLRKMcHWAUDiPpwJgzBtEuevrxshV['saveinfo']['infoLabels']['country']=bdLRKMcHWAUDiPpwJgzBtEuevrxsho.get('country')
   bdLRKMcHWAUDiPpwJgzBtEuevrxshV['saveinfo']['infoLabels']['studio'] =bdLRKMcHWAUDiPpwJgzBtEuevrxsho.get('cpname')
   if bdLRKMcHWAUDiPpwJgzBtEuevrxsho.get('releasedate')!='':
    bdLRKMcHWAUDiPpwJgzBtEuevrxshV['saveinfo']['infoLabels']['year'] =bdLRKMcHWAUDiPpwJgzBtEuevrxsho.get('releasedate')[:4]
    bdLRKMcHWAUDiPpwJgzBtEuevrxshV['saveinfo']['infoLabels']['premiered']=bdLRKMcHWAUDiPpwJgzBtEuevrxsho.get('releasedate')
   bdLRKMcHWAUDiPpwJgzBtEuevrxshq=[]
   for bdLRKMcHWAUDiPpwJgzBtEuevrxshm in bdLRKMcHWAUDiPpwJgzBtEuevrxsho['actors']['list']:bdLRKMcHWAUDiPpwJgzBtEuevrxshq.append(bdLRKMcHWAUDiPpwJgzBtEuevrxshm.get('text'))
   if bdLRKMcHWAUDiPpwJgzBtEuevrxsCY(bdLRKMcHWAUDiPpwJgzBtEuevrxshq)>0:
    if bdLRKMcHWAUDiPpwJgzBtEuevrxshq[0]!='':bdLRKMcHWAUDiPpwJgzBtEuevrxshV['saveinfo']['infoLabels']['cast']=bdLRKMcHWAUDiPpwJgzBtEuevrxshq
   bdLRKMcHWAUDiPpwJgzBtEuevrxshI=[]
   for bdLRKMcHWAUDiPpwJgzBtEuevrxshy in bdLRKMcHWAUDiPpwJgzBtEuevrxsho['directors']['list']:bdLRKMcHWAUDiPpwJgzBtEuevrxshI.append(bdLRKMcHWAUDiPpwJgzBtEuevrxshy.get('text'))
   if bdLRKMcHWAUDiPpwJgzBtEuevrxsCY(bdLRKMcHWAUDiPpwJgzBtEuevrxshI)>0:
    if bdLRKMcHWAUDiPpwJgzBtEuevrxshI[0]!='':bdLRKMcHWAUDiPpwJgzBtEuevrxshV['saveinfo']['infoLabels']['director']=bdLRKMcHWAUDiPpwJgzBtEuevrxshI
   bdLRKMcHWAUDiPpwJgzBtEuevrxsFG=[]
   for bdLRKMcHWAUDiPpwJgzBtEuevrxshQ in bdLRKMcHWAUDiPpwJgzBtEuevrxsho['genre']['list']:bdLRKMcHWAUDiPpwJgzBtEuevrxsFG.append(bdLRKMcHWAUDiPpwJgzBtEuevrxshQ.get('text'))
   if bdLRKMcHWAUDiPpwJgzBtEuevrxsCY(bdLRKMcHWAUDiPpwJgzBtEuevrxsFG)>0:
    if bdLRKMcHWAUDiPpwJgzBtEuevrxsFG[0]!='':bdLRKMcHWAUDiPpwJgzBtEuevrxshV['saveinfo']['infoLabels']['genre']=bdLRKMcHWAUDiPpwJgzBtEuevrxsFG
   bdLRKMcHWAUDiPpwJgzBtEuevrxsYq ='https://%s'%bdLRKMcHWAUDiPpwJgzBtEuevrxsho['image']
   bdLRKMcHWAUDiPpwJgzBtEuevrxshV['saveinfo']['thumbnail']['poster'] =bdLRKMcHWAUDiPpwJgzBtEuevrxsYq
   bdLRKMcHWAUDiPpwJgzBtEuevrxshV['saveinfo']['thumbnail']['thumb'] =bdLRKMcHWAUDiPpwJgzBtEuevrxsYq
  return bdLRKMcHWAUDiPpwJgzBtEuevrxshV
# Created by pyminifier (https://github.com/liftoff/pyminifier)
