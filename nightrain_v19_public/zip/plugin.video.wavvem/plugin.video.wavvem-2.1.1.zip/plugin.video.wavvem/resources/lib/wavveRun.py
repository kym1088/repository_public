__author__="NightRain"
QfGlIxRWpzPSBrsbwODuHLvecjTiYn=object
QfGlIxRWpzPSBrsbwODuHLvecjTiYg=None
QfGlIxRWpzPSBrsbwODuHLvecjTiYa=int
QfGlIxRWpzPSBrsbwODuHLvecjTiYo=False
QfGlIxRWpzPSBrsbwODuHLvecjTiYU=True
QfGlIxRWpzPSBrsbwODuHLvecjTiYk=len
QfGlIxRWpzPSBrsbwODuHLvecjTiYE=open
QfGlIxRWpzPSBrsbwODuHLvecjTiYA=dict
QfGlIxRWpzPSBrsbwODuHLvecjTiXh=Exception
QfGlIxRWpzPSBrsbwODuHLvecjTiXM=print
QfGlIxRWpzPSBrsbwODuHLvecjTiXd=str
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
QfGlIxRWpzPSBrsbwODuHLvecjTihd=[{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://www.wavve.com/supermultisection/GN51'},{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=01&WeekDay=all&uitype=VN4&uiparent=FN0&uirank=0&broadcastid=847243&uicode=VN4','page':'1'},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=02&WeekDay=all&uitype=VN3&uiparent=FN0&uirank=0&broadcastid=783664&uicode=VN3','page':'1'},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'1','sType':'vod','orderby':'new','ordernm':'최신순'},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'viewtime','ordernm':'인기순'},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순'},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'paid','ordernm':'인기순'},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'displaystart','ordernm':'업데이트순'},{'title':'검색 (search)','mode':'SEARCH_GROUP'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP'}]
QfGlIxRWpzPSBrsbwODuHLvecjTihq=[{'title':'VOD 검색','mode':'SEARCH_LIST','sType':'vod'},{'title':'영화 검색','mode':'SEARCH_LIST','sType':'movie'}]
QfGlIxRWpzPSBrsbwODuHLvecjTihY=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
QfGlIxRWpzPSBrsbwODuHLvecjTihX='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
QfGlIxRWpzPSBrsbwODuHLvecjTihC=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
from wavveCore import*
class QfGlIxRWpzPSBrsbwODuHLvecjTihM(QfGlIxRWpzPSBrsbwODuHLvecjTiYn):
 def __init__(QfGlIxRWpzPSBrsbwODuHLvecjTiht,QfGlIxRWpzPSBrsbwODuHLvecjTihK,QfGlIxRWpzPSBrsbwODuHLvecjTihV,QfGlIxRWpzPSBrsbwODuHLvecjTihF):
  QfGlIxRWpzPSBrsbwODuHLvecjTiht._addon_url =QfGlIxRWpzPSBrsbwODuHLvecjTihK
  QfGlIxRWpzPSBrsbwODuHLvecjTiht._addon_handle=QfGlIxRWpzPSBrsbwODuHLvecjTihV
  QfGlIxRWpzPSBrsbwODuHLvecjTiht.main_params =QfGlIxRWpzPSBrsbwODuHLvecjTihF
  QfGlIxRWpzPSBrsbwODuHLvecjTiht.WavveObj =GSplofuUIabRjBVckdenvxQLmNzMEi() 
 def addon_noti(QfGlIxRWpzPSBrsbwODuHLvecjTiht,sting):
  try:
   QfGlIxRWpzPSBrsbwODuHLvecjTihN=xbmcgui.Dialog()
   QfGlIxRWpzPSBrsbwODuHLvecjTihN.notification(__addonname__,sting)
  except:
   QfGlIxRWpzPSBrsbwODuHLvecjTiYg
 def addon_log(QfGlIxRWpzPSBrsbwODuHLvecjTiht,string):
  try:
   QfGlIxRWpzPSBrsbwODuHLvecjTihJ=string.encode('utf-8','ignore')
  except:
   QfGlIxRWpzPSBrsbwODuHLvecjTihJ='addonException: addon_log'
  QfGlIxRWpzPSBrsbwODuHLvecjTihy=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,QfGlIxRWpzPSBrsbwODuHLvecjTihJ),level=QfGlIxRWpzPSBrsbwODuHLvecjTihy)
 def get_keyboard_input(QfGlIxRWpzPSBrsbwODuHLvecjTiht,QfGlIxRWpzPSBrsbwODuHLvecjTiMY):
  QfGlIxRWpzPSBrsbwODuHLvecjTihn=QfGlIxRWpzPSBrsbwODuHLvecjTiYg
  kb=xbmc.Keyboard()
  kb.setHeading(QfGlIxRWpzPSBrsbwODuHLvecjTiMY)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   QfGlIxRWpzPSBrsbwODuHLvecjTihn=kb.getText()
  return QfGlIxRWpzPSBrsbwODuHLvecjTihn
 def get_settings_login_info(QfGlIxRWpzPSBrsbwODuHLvecjTiht):
  QfGlIxRWpzPSBrsbwODuHLvecjTihg =__addon__.getSetting('id')
  QfGlIxRWpzPSBrsbwODuHLvecjTiha =__addon__.getSetting('pw')
  QfGlIxRWpzPSBrsbwODuHLvecjTiho=__addon__.getSetting('selected_profile')
  return(QfGlIxRWpzPSBrsbwODuHLvecjTihg,QfGlIxRWpzPSBrsbwODuHLvecjTiha,QfGlIxRWpzPSBrsbwODuHLvecjTiho)
 def get_selQuality(QfGlIxRWpzPSBrsbwODuHLvecjTiht):
  try:
   QfGlIxRWpzPSBrsbwODuHLvecjTihU=[1080,720,480,360]
   QfGlIxRWpzPSBrsbwODuHLvecjTihk=QfGlIxRWpzPSBrsbwODuHLvecjTiYa(__addon__.getSetting('selected_quality'))
   return QfGlIxRWpzPSBrsbwODuHLvecjTihU[QfGlIxRWpzPSBrsbwODuHLvecjTihk]
  except:
   QfGlIxRWpzPSBrsbwODuHLvecjTiYg
  return 1080 
 def get_settings_exclusion21(QfGlIxRWpzPSBrsbwODuHLvecjTiht):
  QfGlIxRWpzPSBrsbwODuHLvecjTihE =__addon__.getSetting('exclusion21')
  if QfGlIxRWpzPSBrsbwODuHLvecjTihE=='false':
   return QfGlIxRWpzPSBrsbwODuHLvecjTiYo
  else:
   return QfGlIxRWpzPSBrsbwODuHLvecjTiYU
 def get_settings_direct_replay(QfGlIxRWpzPSBrsbwODuHLvecjTiht):
  QfGlIxRWpzPSBrsbwODuHLvecjTihA=QfGlIxRWpzPSBrsbwODuHLvecjTiYa(__addon__.getSetting('direct_replay'))
  if QfGlIxRWpzPSBrsbwODuHLvecjTihA==0:
   return QfGlIxRWpzPSBrsbwODuHLvecjTiYo
  else:
   return QfGlIxRWpzPSBrsbwODuHLvecjTiYU
 def get_settings_addinfo(QfGlIxRWpzPSBrsbwODuHLvecjTiht):
  QfGlIxRWpzPSBrsbwODuHLvecjTiMh =__addon__.getSetting('add_infoyn')
  if QfGlIxRWpzPSBrsbwODuHLvecjTiMh=='false':
   return QfGlIxRWpzPSBrsbwODuHLvecjTiYo
  else:
   return QfGlIxRWpzPSBrsbwODuHLvecjTiYU
 def set_winCredential(QfGlIxRWpzPSBrsbwODuHLvecjTiht,credential):
  QfGlIxRWpzPSBrsbwODuHLvecjTiMd=xbmcgui.Window(10000)
  QfGlIxRWpzPSBrsbwODuHLvecjTiMd.setProperty('WAVVE_M_CREDENTIAL',credential)
  QfGlIxRWpzPSBrsbwODuHLvecjTiMd.setProperty('WAVVE_M_LOGINTIME',QfGlIxRWpzPSBrsbwODuHLvecjTiht.WavveObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(QfGlIxRWpzPSBrsbwODuHLvecjTiht):
  QfGlIxRWpzPSBrsbwODuHLvecjTiMd=xbmcgui.Window(10000)
  return QfGlIxRWpzPSBrsbwODuHLvecjTiMd.getProperty('WAVVE_M_CREDENTIAL')
 def set_winEpisodeOrderby(QfGlIxRWpzPSBrsbwODuHLvecjTiht,QfGlIxRWpzPSBrsbwODuHLvecjTiMU):
  QfGlIxRWpzPSBrsbwODuHLvecjTiMd=xbmcgui.Window(10000)
  QfGlIxRWpzPSBrsbwODuHLvecjTiMd.setProperty('WAVVE_M_ORDERBY',QfGlIxRWpzPSBrsbwODuHLvecjTiMU)
 def get_winEpisodeOrderby(QfGlIxRWpzPSBrsbwODuHLvecjTiht):
  QfGlIxRWpzPSBrsbwODuHLvecjTiMd=xbmcgui.Window(10000)
  return QfGlIxRWpzPSBrsbwODuHLvecjTiMd.getProperty('WAVVE_M_ORDERBY')
 def add_dir(QfGlIxRWpzPSBrsbwODuHLvecjTiht,label,sublabel='',img='',infoLabels=QfGlIxRWpzPSBrsbwODuHLvecjTiYg,isFolder=QfGlIxRWpzPSBrsbwODuHLvecjTiYU,params=''):
  QfGlIxRWpzPSBrsbwODuHLvecjTiMq='%s?%s'%(QfGlIxRWpzPSBrsbwODuHLvecjTiht._addon_url,urllib.parse.urlencode(params))
  if sublabel:QfGlIxRWpzPSBrsbwODuHLvecjTiMY='%s < %s >'%(label,sublabel)
  else: QfGlIxRWpzPSBrsbwODuHLvecjTiMY=label
  if not img:img='DefaultFolder.png'
  QfGlIxRWpzPSBrsbwODuHLvecjTiMX=xbmcgui.ListItem(QfGlIxRWpzPSBrsbwODuHLvecjTiMY)
  QfGlIxRWpzPSBrsbwODuHLvecjTiMX.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:QfGlIxRWpzPSBrsbwODuHLvecjTiMX.setInfo(type="video",infoLabels=infoLabels)
  if not isFolder:QfGlIxRWpzPSBrsbwODuHLvecjTiMX.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(QfGlIxRWpzPSBrsbwODuHLvecjTiht._addon_handle,QfGlIxRWpzPSBrsbwODuHLvecjTiMq,QfGlIxRWpzPSBrsbwODuHLvecjTiMX,isFolder)
 def dp_Main_List(QfGlIxRWpzPSBrsbwODuHLvecjTiht):
  for QfGlIxRWpzPSBrsbwODuHLvecjTiMC in QfGlIxRWpzPSBrsbwODuHLvecjTihd:
   QfGlIxRWpzPSBrsbwODuHLvecjTiMY=QfGlIxRWpzPSBrsbwODuHLvecjTiMC.get('title')
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt={'mode':QfGlIxRWpzPSBrsbwODuHLvecjTiMC.get('mode'),'sCode':QfGlIxRWpzPSBrsbwODuHLvecjTiMC.get('sCode'),'sIndex':QfGlIxRWpzPSBrsbwODuHLvecjTiMC.get('sIndex'),'sType':QfGlIxRWpzPSBrsbwODuHLvecjTiMC.get('sType'),'suburl':QfGlIxRWpzPSBrsbwODuHLvecjTiMC.get('suburl'),'subapi':QfGlIxRWpzPSBrsbwODuHLvecjTiMC.get('subapi'),'page':QfGlIxRWpzPSBrsbwODuHLvecjTiMC.get('page'),'orderby':QfGlIxRWpzPSBrsbwODuHLvecjTiMC.get('orderby'),'ordernm':QfGlIxRWpzPSBrsbwODuHLvecjTiMC.get('ordernm')}
   if QfGlIxRWpzPSBrsbwODuHLvecjTiMC.get('mode')=='XXX':
    QfGlIxRWpzPSBrsbwODuHLvecjTiMK=QfGlIxRWpzPSBrsbwODuHLvecjTiYo
   else:
    QfGlIxRWpzPSBrsbwODuHLvecjTiMK=QfGlIxRWpzPSBrsbwODuHLvecjTiYU
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.add_dir(QfGlIxRWpzPSBrsbwODuHLvecjTiMY,sublabel='',img='',infoLabels=QfGlIxRWpzPSBrsbwODuHLvecjTiYg,isFolder=QfGlIxRWpzPSBrsbwODuHLvecjTiMK,params=QfGlIxRWpzPSBrsbwODuHLvecjTiMt)
  if QfGlIxRWpzPSBrsbwODuHLvecjTiYk(QfGlIxRWpzPSBrsbwODuHLvecjTihd)>0:xbmcplugin.endOfDirectory(QfGlIxRWpzPSBrsbwODuHLvecjTiht._addon_handle,cacheToDisc=QfGlIxRWpzPSBrsbwODuHLvecjTiYU)
 def dp_Search_Group(QfGlIxRWpzPSBrsbwODuHLvecjTiht,args):
  for QfGlIxRWpzPSBrsbwODuHLvecjTiMF in QfGlIxRWpzPSBrsbwODuHLvecjTihq:
   QfGlIxRWpzPSBrsbwODuHLvecjTiMY=QfGlIxRWpzPSBrsbwODuHLvecjTiMF.get('title')
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt={'mode':QfGlIxRWpzPSBrsbwODuHLvecjTiMF.get('mode'),'sType':QfGlIxRWpzPSBrsbwODuHLvecjTiMF.get('sType'),'page':'1'}
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.add_dir(QfGlIxRWpzPSBrsbwODuHLvecjTiMY,sublabel='',img='',infoLabels=QfGlIxRWpzPSBrsbwODuHLvecjTiYg,isFolder=QfGlIxRWpzPSBrsbwODuHLvecjTiYU,params=QfGlIxRWpzPSBrsbwODuHLvecjTiMt)
  if QfGlIxRWpzPSBrsbwODuHLvecjTiYk(QfGlIxRWpzPSBrsbwODuHLvecjTihq)>0:xbmcplugin.endOfDirectory(QfGlIxRWpzPSBrsbwODuHLvecjTiht._addon_handle,cacheToDisc=QfGlIxRWpzPSBrsbwODuHLvecjTiYU)
 def dp_Watch_Group(QfGlIxRWpzPSBrsbwODuHLvecjTiht,args):
  for QfGlIxRWpzPSBrsbwODuHLvecjTiMm in QfGlIxRWpzPSBrsbwODuHLvecjTihY:
   QfGlIxRWpzPSBrsbwODuHLvecjTiMY=QfGlIxRWpzPSBrsbwODuHLvecjTiMm.get('title')
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt={'mode':QfGlIxRWpzPSBrsbwODuHLvecjTiMm.get('mode'),'sType':QfGlIxRWpzPSBrsbwODuHLvecjTiMm.get('sType')}
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.add_dir(QfGlIxRWpzPSBrsbwODuHLvecjTiMY,sublabel='',img='',infoLabels=QfGlIxRWpzPSBrsbwODuHLvecjTiYg,isFolder=QfGlIxRWpzPSBrsbwODuHLvecjTiYU,params=QfGlIxRWpzPSBrsbwODuHLvecjTiMt)
  if QfGlIxRWpzPSBrsbwODuHLvecjTiYk(QfGlIxRWpzPSBrsbwODuHLvecjTihY)>0:xbmcplugin.endOfDirectory(QfGlIxRWpzPSBrsbwODuHLvecjTiht._addon_handle,cacheToDisc=QfGlIxRWpzPSBrsbwODuHLvecjTiYU)
 def login_main(QfGlIxRWpzPSBrsbwODuHLvecjTiht):
  (QfGlIxRWpzPSBrsbwODuHLvecjTiMN,QfGlIxRWpzPSBrsbwODuHLvecjTiMJ,QfGlIxRWpzPSBrsbwODuHLvecjTiMy)=QfGlIxRWpzPSBrsbwODuHLvecjTiht.get_settings_login_info()
  if not(QfGlIxRWpzPSBrsbwODuHLvecjTiMN and QfGlIxRWpzPSBrsbwODuHLvecjTiMJ):
   QfGlIxRWpzPSBrsbwODuHLvecjTihN=xbmcgui.Dialog()
   QfGlIxRWpzPSBrsbwODuHLvecjTiMn=QfGlIxRWpzPSBrsbwODuHLvecjTihN.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if QfGlIxRWpzPSBrsbwODuHLvecjTiMn==QfGlIxRWpzPSBrsbwODuHLvecjTiYU:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if QfGlIxRWpzPSBrsbwODuHLvecjTiht.get_winEpisodeOrderby()=='':
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.set_winEpisodeOrderby('desc')
  if QfGlIxRWpzPSBrsbwODuHLvecjTiht.cookiefile_check():return
  QfGlIxRWpzPSBrsbwODuHLvecjTiMg =QfGlIxRWpzPSBrsbwODuHLvecjTiYa(QfGlIxRWpzPSBrsbwODuHLvecjTiht.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  QfGlIxRWpzPSBrsbwODuHLvecjTiMa=xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINTIME')
  if QfGlIxRWpzPSBrsbwODuHLvecjTiMa==QfGlIxRWpzPSBrsbwODuHLvecjTiYg or QfGlIxRWpzPSBrsbwODuHLvecjTiMa=='':
   QfGlIxRWpzPSBrsbwODuHLvecjTiMa=QfGlIxRWpzPSBrsbwODuHLvecjTiYa('19000101')
  else:
   QfGlIxRWpzPSBrsbwODuHLvecjTiMa=QfGlIxRWpzPSBrsbwODuHLvecjTiYa(re.sub('-','',QfGlIxRWpzPSBrsbwODuHLvecjTiMa))
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   QfGlIxRWpzPSBrsbwODuHLvecjTiMo=0
   while QfGlIxRWpzPSBrsbwODuHLvecjTiYU:
    QfGlIxRWpzPSBrsbwODuHLvecjTiMo+=1
    time.sleep(0.05)
    if QfGlIxRWpzPSBrsbwODuHLvecjTiMa>=QfGlIxRWpzPSBrsbwODuHLvecjTiMg:return
    if QfGlIxRWpzPSBrsbwODuHLvecjTiMo>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  if QfGlIxRWpzPSBrsbwODuHLvecjTiMa>=QfGlIxRWpzPSBrsbwODuHLvecjTiMg:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   return
  if not QfGlIxRWpzPSBrsbwODuHLvecjTiht.WavveObj.GetCredential(QfGlIxRWpzPSBrsbwODuHLvecjTiMN,QfGlIxRWpzPSBrsbwODuHLvecjTiMJ,QfGlIxRWpzPSBrsbwODuHLvecjTiMy):
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   sys.exit()
  QfGlIxRWpzPSBrsbwODuHLvecjTiht.set_winCredential(QfGlIxRWpzPSBrsbwODuHLvecjTiht.WavveObj.LoadCredential())
  QfGlIxRWpzPSBrsbwODuHLvecjTiht.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
 def dp_setEpOrderby(QfGlIxRWpzPSBrsbwODuHLvecjTiht,args):
  QfGlIxRWpzPSBrsbwODuHLvecjTiMU =args.get('orderby')
  QfGlIxRWpzPSBrsbwODuHLvecjTiht.set_winEpisodeOrderby(QfGlIxRWpzPSBrsbwODuHLvecjTiMU)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(QfGlIxRWpzPSBrsbwODuHLvecjTiht,args):
  QfGlIxRWpzPSBrsbwODuHLvecjTiht.WavveObj.SaveCredential(QfGlIxRWpzPSBrsbwODuHLvecjTiht.get_winCredential())
  QfGlIxRWpzPSBrsbwODuHLvecjTiMk =args.get('mode')
  QfGlIxRWpzPSBrsbwODuHLvecjTiME =args.get('contentid')
  QfGlIxRWpzPSBrsbwODuHLvecjTiMA =args.get('pvrmode')
  QfGlIxRWpzPSBrsbwODuHLvecjTidh=QfGlIxRWpzPSBrsbwODuHLvecjTiht.get_selQuality()
  QfGlIxRWpzPSBrsbwODuHLvecjTiht.addon_log(QfGlIxRWpzPSBrsbwODuHLvecjTiME+' - '+QfGlIxRWpzPSBrsbwODuHLvecjTiMk)
  QfGlIxRWpzPSBrsbwODuHLvecjTidM,QfGlIxRWpzPSBrsbwODuHLvecjTidq,QfGlIxRWpzPSBrsbwODuHLvecjTidY,QfGlIxRWpzPSBrsbwODuHLvecjTidX=QfGlIxRWpzPSBrsbwODuHLvecjTiht.WavveObj.GetStreamingURL(QfGlIxRWpzPSBrsbwODuHLvecjTiMk,QfGlIxRWpzPSBrsbwODuHLvecjTiME,QfGlIxRWpzPSBrsbwODuHLvecjTidh,QfGlIxRWpzPSBrsbwODuHLvecjTiMA)
  QfGlIxRWpzPSBrsbwODuHLvecjTidC='%s|Cookie=%s'%(QfGlIxRWpzPSBrsbwODuHLvecjTidM,QfGlIxRWpzPSBrsbwODuHLvecjTidq)
  QfGlIxRWpzPSBrsbwODuHLvecjTiht.addon_log(QfGlIxRWpzPSBrsbwODuHLvecjTidC)
  if QfGlIxRWpzPSBrsbwODuHLvecjTidM=='':
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.addon_noti(__language__(30907).encode('utf8'))
   return
  QfGlIxRWpzPSBrsbwODuHLvecjTidt=xbmcgui.ListItem(path=QfGlIxRWpzPSBrsbwODuHLvecjTidC)
  if QfGlIxRWpzPSBrsbwODuHLvecjTidY:
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.addon_log('!!streaming_drm!!')
   QfGlIxRWpzPSBrsbwODuHLvecjTidK=QfGlIxRWpzPSBrsbwODuHLvecjTidY['customdata']
   QfGlIxRWpzPSBrsbwODuHLvecjTidV =QfGlIxRWpzPSBrsbwODuHLvecjTidY['drmhost']
   QfGlIxRWpzPSBrsbwODuHLvecjTidF =inputstreamhelper.Helper('mpd',drm='widevine')
   if QfGlIxRWpzPSBrsbwODuHLvecjTidF.check_inputstream():
    if QfGlIxRWpzPSBrsbwODuHLvecjTiMk=='MOVIE':
     QfGlIxRWpzPSBrsbwODuHLvecjTidm='https://www.wavve.com/player/movie?movieid=%s'%QfGlIxRWpzPSBrsbwODuHLvecjTiME
    else:
     QfGlIxRWpzPSBrsbwODuHLvecjTidm='https://www.wavve.com/player/vod?programid=%s&page=1'%QfGlIxRWpzPSBrsbwODuHLvecjTiME
    QfGlIxRWpzPSBrsbwODuHLvecjTidN={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':QfGlIxRWpzPSBrsbwODuHLvecjTidK,'referer':QfGlIxRWpzPSBrsbwODuHLvecjTidm,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':QfGlIxRWpzPSBrsbwODuHLvecjTihX}
    QfGlIxRWpzPSBrsbwODuHLvecjTidJ=QfGlIxRWpzPSBrsbwODuHLvecjTidV+'|'+urllib.parse.urlencode(QfGlIxRWpzPSBrsbwODuHLvecjTidN)+'|R{SSM}|'
    QfGlIxRWpzPSBrsbwODuHLvecjTidt.setProperty('inputstream',QfGlIxRWpzPSBrsbwODuHLvecjTidF.inputstream_addon)
    QfGlIxRWpzPSBrsbwODuHLvecjTidt.setProperty('inputstream.adaptive.manifest_type','mpd')
    QfGlIxRWpzPSBrsbwODuHLvecjTidt.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    QfGlIxRWpzPSBrsbwODuHLvecjTidt.setProperty('inputstream.adaptive.license_key',QfGlIxRWpzPSBrsbwODuHLvecjTidJ)
    QfGlIxRWpzPSBrsbwODuHLvecjTidt.setProperty('inputstream.adaptive.stream_headers','user-agent=%s&Cookie=%s'%(QfGlIxRWpzPSBrsbwODuHLvecjTihX,QfGlIxRWpzPSBrsbwODuHLvecjTidq))
  xbmcplugin.setResolvedUrl(QfGlIxRWpzPSBrsbwODuHLvecjTiht._addon_handle,QfGlIxRWpzPSBrsbwODuHLvecjTiYU,QfGlIxRWpzPSBrsbwODuHLvecjTidt)
  QfGlIxRWpzPSBrsbwODuHLvecjTidy=QfGlIxRWpzPSBrsbwODuHLvecjTiYo
  if QfGlIxRWpzPSBrsbwODuHLvecjTidX:
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.addon_noti(QfGlIxRWpzPSBrsbwODuHLvecjTidX.encode('utf-8'))
   QfGlIxRWpzPSBrsbwODuHLvecjTidy=QfGlIxRWpzPSBrsbwODuHLvecjTiYU
  else:
   if '/preview.' in urllib.parse.urlsplit(QfGlIxRWpzPSBrsbwODuHLvecjTidM).path:
    QfGlIxRWpzPSBrsbwODuHLvecjTiht.addon_noti(__language__(30908).encode('utf8'))
    QfGlIxRWpzPSBrsbwODuHLvecjTidy=QfGlIxRWpzPSBrsbwODuHLvecjTiYU
  try:
   QfGlIxRWpzPSBrsbwODuHLvecjTidn=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and QfGlIxRWpzPSBrsbwODuHLvecjTidy==QfGlIxRWpzPSBrsbwODuHLvecjTiYo and QfGlIxRWpzPSBrsbwODuHLvecjTidn!='-':
    QfGlIxRWpzPSBrsbwODuHLvecjTiMt={'code':QfGlIxRWpzPSBrsbwODuHLvecjTidn,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    QfGlIxRWpzPSBrsbwODuHLvecjTiht.Save_Watched_List(args.get('mode').lower(),QfGlIxRWpzPSBrsbwODuHLvecjTiMt)
  except:
   QfGlIxRWpzPSBrsbwODuHLvecjTiYg
 def Load_Watched_List(QfGlIxRWpzPSBrsbwODuHLvecjTiht,QfGlIxRWpzPSBrsbwODuHLvecjTiYV):
  try:
   QfGlIxRWpzPSBrsbwODuHLvecjTidg=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%QfGlIxRWpzPSBrsbwODuHLvecjTiYV))
   fp=QfGlIxRWpzPSBrsbwODuHLvecjTiYE(QfGlIxRWpzPSBrsbwODuHLvecjTidg,'r',-1,'utf-8')
   QfGlIxRWpzPSBrsbwODuHLvecjTida=fp.readlines()
   fp.close()
  except:
   QfGlIxRWpzPSBrsbwODuHLvecjTida=[]
  return QfGlIxRWpzPSBrsbwODuHLvecjTida
 def Save_Watched_List(QfGlIxRWpzPSBrsbwODuHLvecjTiht,QfGlIxRWpzPSBrsbwODuHLvecjTiYV,QfGlIxRWpzPSBrsbwODuHLvecjTihF):
  try:
   QfGlIxRWpzPSBrsbwODuHLvecjTidg=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%QfGlIxRWpzPSBrsbwODuHLvecjTiYV))
   QfGlIxRWpzPSBrsbwODuHLvecjTido=QfGlIxRWpzPSBrsbwODuHLvecjTiht.Load_Watched_List(QfGlIxRWpzPSBrsbwODuHLvecjTiYV) 
   fp=QfGlIxRWpzPSBrsbwODuHLvecjTiYE(QfGlIxRWpzPSBrsbwODuHLvecjTidg,'w',-1,'utf-8')
   QfGlIxRWpzPSBrsbwODuHLvecjTidU=urllib.parse.urlencode(QfGlIxRWpzPSBrsbwODuHLvecjTihF)
   QfGlIxRWpzPSBrsbwODuHLvecjTidU=QfGlIxRWpzPSBrsbwODuHLvecjTidU+'\n'
   fp.write(QfGlIxRWpzPSBrsbwODuHLvecjTidU)
   QfGlIxRWpzPSBrsbwODuHLvecjTidk=0
   for QfGlIxRWpzPSBrsbwODuHLvecjTidE in QfGlIxRWpzPSBrsbwODuHLvecjTido:
    QfGlIxRWpzPSBrsbwODuHLvecjTidA=QfGlIxRWpzPSBrsbwODuHLvecjTiYA(urllib.parse.parse_qsl(QfGlIxRWpzPSBrsbwODuHLvecjTidE))
    QfGlIxRWpzPSBrsbwODuHLvecjTiqh=QfGlIxRWpzPSBrsbwODuHLvecjTihF.get('code').strip()
    QfGlIxRWpzPSBrsbwODuHLvecjTiqM=QfGlIxRWpzPSBrsbwODuHLvecjTidA.get('code').strip()
    if QfGlIxRWpzPSBrsbwODuHLvecjTiYV=='vod' and QfGlIxRWpzPSBrsbwODuHLvecjTiht.get_settings_direct_replay()==QfGlIxRWpzPSBrsbwODuHLvecjTiYU:
     QfGlIxRWpzPSBrsbwODuHLvecjTiqh=QfGlIxRWpzPSBrsbwODuHLvecjTihF.get('videoid').strip()
     QfGlIxRWpzPSBrsbwODuHLvecjTiqM=QfGlIxRWpzPSBrsbwODuHLvecjTidA.get('videoid').strip()if QfGlIxRWpzPSBrsbwODuHLvecjTiqM!=QfGlIxRWpzPSBrsbwODuHLvecjTiYg else '-'
    if QfGlIxRWpzPSBrsbwODuHLvecjTiqh!=QfGlIxRWpzPSBrsbwODuHLvecjTiqM:
     fp.write(QfGlIxRWpzPSBrsbwODuHLvecjTidE)
     QfGlIxRWpzPSBrsbwODuHLvecjTidk+=1
     if QfGlIxRWpzPSBrsbwODuHLvecjTidk>=50:break
   fp.close()
  except:
   QfGlIxRWpzPSBrsbwODuHLvecjTiYg
 def Delete_Watched_List(QfGlIxRWpzPSBrsbwODuHLvecjTiht,QfGlIxRWpzPSBrsbwODuHLvecjTiYV):
  try:
   QfGlIxRWpzPSBrsbwODuHLvecjTidg=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%QfGlIxRWpzPSBrsbwODuHLvecjTiYV))
   fp=QfGlIxRWpzPSBrsbwODuHLvecjTiYE(QfGlIxRWpzPSBrsbwODuHLvecjTidg,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   QfGlIxRWpzPSBrsbwODuHLvecjTiYg
 def dp_WatchList_Delete(QfGlIxRWpzPSBrsbwODuHLvecjTiht,args):
  QfGlIxRWpzPSBrsbwODuHLvecjTiqd=args.get('sType')
  QfGlIxRWpzPSBrsbwODuHLvecjTihN=xbmcgui.Dialog()
  QfGlIxRWpzPSBrsbwODuHLvecjTiMn=QfGlIxRWpzPSBrsbwODuHLvecjTihN.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if QfGlIxRWpzPSBrsbwODuHLvecjTiMn==QfGlIxRWpzPSBrsbwODuHLvecjTiYo:sys.exit()
  QfGlIxRWpzPSBrsbwODuHLvecjTiht.Delete_Watched_List(QfGlIxRWpzPSBrsbwODuHLvecjTiqd)
  xbmc.executebuiltin("Container.Refresh")
 def logout(QfGlIxRWpzPSBrsbwODuHLvecjTiht):
  QfGlIxRWpzPSBrsbwODuHLvecjTihN=xbmcgui.Dialog()
  QfGlIxRWpzPSBrsbwODuHLvecjTiMn=QfGlIxRWpzPSBrsbwODuHLvecjTihN.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if QfGlIxRWpzPSBrsbwODuHLvecjTiMn==QfGlIxRWpzPSBrsbwODuHLvecjTiYo:sys.exit()
  QfGlIxRWpzPSBrsbwODuHLvecjTiht.wininfo_clear()
  if os.path.isfile(QfGlIxRWpzPSBrsbwODuHLvecjTihC):os.remove(QfGlIxRWpzPSBrsbwODuHLvecjTihC)
  QfGlIxRWpzPSBrsbwODuHLvecjTiht.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(QfGlIxRWpzPSBrsbwODuHLvecjTiht):
  QfGlIxRWpzPSBrsbwODuHLvecjTiMd=xbmcgui.Window(10000)
  QfGlIxRWpzPSBrsbwODuHLvecjTiMd.setProperty('WAVVE_M_CREDENTIAL','')
  QfGlIxRWpzPSBrsbwODuHLvecjTiMd.setProperty('WAVVE_M_LOGINTIME','')
 def cookiefile_save(QfGlIxRWpzPSBrsbwODuHLvecjTiht):
  QfGlIxRWpzPSBrsbwODuHLvecjTiqY =QfGlIxRWpzPSBrsbwODuHLvecjTiht.WavveObj.Get_Now_Datetime()
  QfGlIxRWpzPSBrsbwODuHLvecjTiqX=QfGlIxRWpzPSBrsbwODuHLvecjTiqY+datetime.timedelta(days=QfGlIxRWpzPSBrsbwODuHLvecjTiYa(__addon__.getSetting('cache_ttl')))
  QfGlIxRWpzPSBrsbwODuHLvecjTiMd=xbmcgui.Window(10000)
  QfGlIxRWpzPSBrsbwODuHLvecjTiqC={'wavve_token':QfGlIxRWpzPSBrsbwODuHLvecjTiMd.getProperty('WAVVE_M_CREDENTIAL'),'wavve_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'wavve_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'wavve_profile':__addon__.getSetting('selected_profile'),'wavve_limitdate':QfGlIxRWpzPSBrsbwODuHLvecjTiqX.strftime('%Y-%m-%d')}
  try: 
   fp=QfGlIxRWpzPSBrsbwODuHLvecjTiYE(QfGlIxRWpzPSBrsbwODuHLvecjTihC,'w',-1,'utf-8')
   json.dump(QfGlIxRWpzPSBrsbwODuHLvecjTiqC,fp)
   fp.close()
  except QfGlIxRWpzPSBrsbwODuHLvecjTiXh as exception:
   QfGlIxRWpzPSBrsbwODuHLvecjTiXM(exception)
 def cookiefile_check(QfGlIxRWpzPSBrsbwODuHLvecjTiht):
  QfGlIxRWpzPSBrsbwODuHLvecjTiqC={}
  try: 
   fp=QfGlIxRWpzPSBrsbwODuHLvecjTiYE(QfGlIxRWpzPSBrsbwODuHLvecjTihC,'r',-1,'utf-8')
   QfGlIxRWpzPSBrsbwODuHLvecjTiqC= json.load(fp)
   fp.close()
  except QfGlIxRWpzPSBrsbwODuHLvecjTiXh as exception:
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.wininfo_clear()
   return QfGlIxRWpzPSBrsbwODuHLvecjTiYo
  QfGlIxRWpzPSBrsbwODuHLvecjTiMN =__addon__.getSetting('id')
  QfGlIxRWpzPSBrsbwODuHLvecjTiMJ =__addon__.getSetting('pw')
  QfGlIxRWpzPSBrsbwODuHLvecjTiqt =__addon__.getSetting('selected_profile')
  QfGlIxRWpzPSBrsbwODuHLvecjTiqC['wavve_id']=base64.standard_b64decode(QfGlIxRWpzPSBrsbwODuHLvecjTiqC['wavve_id']).decode('utf-8')
  QfGlIxRWpzPSBrsbwODuHLvecjTiqC['wavve_pw']=base64.standard_b64decode(QfGlIxRWpzPSBrsbwODuHLvecjTiqC['wavve_pw']).decode('utf-8')
  if QfGlIxRWpzPSBrsbwODuHLvecjTiMN!=QfGlIxRWpzPSBrsbwODuHLvecjTiqC['wavve_id']or QfGlIxRWpzPSBrsbwODuHLvecjTiMJ!=QfGlIxRWpzPSBrsbwODuHLvecjTiqC['wavve_pw']or QfGlIxRWpzPSBrsbwODuHLvecjTiqt!=QfGlIxRWpzPSBrsbwODuHLvecjTiqC['wavve_profile']:
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.wininfo_clear()
   return QfGlIxRWpzPSBrsbwODuHLvecjTiYo
  QfGlIxRWpzPSBrsbwODuHLvecjTiMg =QfGlIxRWpzPSBrsbwODuHLvecjTiYa(QfGlIxRWpzPSBrsbwODuHLvecjTiht.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  QfGlIxRWpzPSBrsbwODuHLvecjTiqK=QfGlIxRWpzPSBrsbwODuHLvecjTiqC['wavve_limitdate']
  QfGlIxRWpzPSBrsbwODuHLvecjTiMa =QfGlIxRWpzPSBrsbwODuHLvecjTiYa(re.sub('-','',QfGlIxRWpzPSBrsbwODuHLvecjTiqK))
  if QfGlIxRWpzPSBrsbwODuHLvecjTiMa<QfGlIxRWpzPSBrsbwODuHLvecjTiMg:
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.wininfo_clear()
   return QfGlIxRWpzPSBrsbwODuHLvecjTiYo
  QfGlIxRWpzPSBrsbwODuHLvecjTiMd=xbmcgui.Window(10000)
  QfGlIxRWpzPSBrsbwODuHLvecjTiMd.setProperty('WAVVE_M_CREDENTIAL',QfGlIxRWpzPSBrsbwODuHLvecjTiqC['wavve_token'])
  QfGlIxRWpzPSBrsbwODuHLvecjTiMd.setProperty('WAVVE_M_LOGINTIME',QfGlIxRWpzPSBrsbwODuHLvecjTiqK)
  return QfGlIxRWpzPSBrsbwODuHLvecjTiYU
 def dp_LiveCatagory_List(QfGlIxRWpzPSBrsbwODuHLvecjTiht,args):
  QfGlIxRWpzPSBrsbwODuHLvecjTiht.WavveObj.SaveCredential(QfGlIxRWpzPSBrsbwODuHLvecjTiht.get_winCredential())
  QfGlIxRWpzPSBrsbwODuHLvecjTiqV =args.get('sCode')
  QfGlIxRWpzPSBrsbwODuHLvecjTiqF=args.get('sIndex')
  QfGlIxRWpzPSBrsbwODuHLvecjTiqm,QfGlIxRWpzPSBrsbwODuHLvecjTiqN=QfGlIxRWpzPSBrsbwODuHLvecjTiht.WavveObj.Get_LiveCatagory_List(QfGlIxRWpzPSBrsbwODuHLvecjTiqV,QfGlIxRWpzPSBrsbwODuHLvecjTiqF)
  for QfGlIxRWpzPSBrsbwODuHLvecjTiqJ in QfGlIxRWpzPSBrsbwODuHLvecjTiqm:
   QfGlIxRWpzPSBrsbwODuHLvecjTiMY =QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('title')
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt={'mode':'LIVE_LIST','genre':QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('genre'),'baseapi':QfGlIxRWpzPSBrsbwODuHLvecjTiqN}
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.add_dir(QfGlIxRWpzPSBrsbwODuHLvecjTiMY,sublabel='',img='',infoLabels=QfGlIxRWpzPSBrsbwODuHLvecjTiYg,isFolder=QfGlIxRWpzPSBrsbwODuHLvecjTiYU,params=QfGlIxRWpzPSBrsbwODuHLvecjTiMt)
  if QfGlIxRWpzPSBrsbwODuHLvecjTiYk(QfGlIxRWpzPSBrsbwODuHLvecjTiqm)>0:xbmcplugin.endOfDirectory(QfGlIxRWpzPSBrsbwODuHLvecjTiht._addon_handle,cacheToDisc=QfGlIxRWpzPSBrsbwODuHLvecjTiYo)
 def dp_MainCatagory_List(QfGlIxRWpzPSBrsbwODuHLvecjTiht,args):
  QfGlIxRWpzPSBrsbwODuHLvecjTiht.WavveObj.SaveCredential(QfGlIxRWpzPSBrsbwODuHLvecjTiht.get_winCredential())
  QfGlIxRWpzPSBrsbwODuHLvecjTiqV =args.get('sCode')
  QfGlIxRWpzPSBrsbwODuHLvecjTiqF=args.get('sIndex')
  QfGlIxRWpzPSBrsbwODuHLvecjTiqd =args.get('sType')
  QfGlIxRWpzPSBrsbwODuHLvecjTiqm=QfGlIxRWpzPSBrsbwODuHLvecjTiht.WavveObj.Get_MainCatagory_List(QfGlIxRWpzPSBrsbwODuHLvecjTiqV,QfGlIxRWpzPSBrsbwODuHLvecjTiqF)
  for QfGlIxRWpzPSBrsbwODuHLvecjTiqJ in QfGlIxRWpzPSBrsbwODuHLvecjTiqm:
   if QfGlIxRWpzPSBrsbwODuHLvecjTiqd=='vod':
    if QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('subtype')=='catagory':
     QfGlIxRWpzPSBrsbwODuHLvecjTiMk='PROGRAM_LIST'
    else:
     QfGlIxRWpzPSBrsbwODuHLvecjTiMk='SUPERSECTION_LIST'
   elif QfGlIxRWpzPSBrsbwODuHLvecjTiqd=='movie':
    QfGlIxRWpzPSBrsbwODuHLvecjTiMk='MOVIE_LIST'
   else:
    QfGlIxRWpzPSBrsbwODuHLvecjTiMk=''
   QfGlIxRWpzPSBrsbwODuHLvecjTiMY='%s (%s)'%(QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('title'),args.get('ordernm'))
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt={'mode':QfGlIxRWpzPSBrsbwODuHLvecjTiMk,'suburl':QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('suburl'),'subapi':QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if QfGlIxRWpzPSBrsbwODuHLvecjTiht.get_settings_exclusion21():
    if QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('title')=='성인' or QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('title')=='성인+':continue
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.add_dir(QfGlIxRWpzPSBrsbwODuHLvecjTiMY,sublabel='',img='',infoLabels=QfGlIxRWpzPSBrsbwODuHLvecjTiYg,isFolder=QfGlIxRWpzPSBrsbwODuHLvecjTiYU,params=QfGlIxRWpzPSBrsbwODuHLvecjTiMt)
  if QfGlIxRWpzPSBrsbwODuHLvecjTiYk(QfGlIxRWpzPSBrsbwODuHLvecjTiqm)>0:xbmcplugin.endOfDirectory(QfGlIxRWpzPSBrsbwODuHLvecjTiht._addon_handle,cacheToDisc=QfGlIxRWpzPSBrsbwODuHLvecjTiYo)
 def dp_Program_List(QfGlIxRWpzPSBrsbwODuHLvecjTiht,args):
  QfGlIxRWpzPSBrsbwODuHLvecjTiht.WavveObj.SaveCredential(QfGlIxRWpzPSBrsbwODuHLvecjTiht.get_winCredential())
  QfGlIxRWpzPSBrsbwODuHLvecjTiqy =args.get('subapi')
  QfGlIxRWpzPSBrsbwODuHLvecjTiqn=QfGlIxRWpzPSBrsbwODuHLvecjTiYa(args.get('page'))
  QfGlIxRWpzPSBrsbwODuHLvecjTiMU =args.get('orderby')
  QfGlIxRWpzPSBrsbwODuHLvecjTiqm,QfGlIxRWpzPSBrsbwODuHLvecjTiqg=QfGlIxRWpzPSBrsbwODuHLvecjTiht.WavveObj.Get_Program_List(QfGlIxRWpzPSBrsbwODuHLvecjTiqy,QfGlIxRWpzPSBrsbwODuHLvecjTiqn,QfGlIxRWpzPSBrsbwODuHLvecjTiMU)
  for QfGlIxRWpzPSBrsbwODuHLvecjTiqJ in QfGlIxRWpzPSBrsbwODuHLvecjTiqm:
   QfGlIxRWpzPSBrsbwODuHLvecjTiMY =QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('title')
   QfGlIxRWpzPSBrsbwODuHLvecjTiqa=QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('thumbnail')
   QfGlIxRWpzPSBrsbwODuHLvecjTiqo =QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('age')
   if QfGlIxRWpzPSBrsbwODuHLvecjTiqo=='18' or QfGlIxRWpzPSBrsbwODuHLvecjTiqo=='19' or QfGlIxRWpzPSBrsbwODuHLvecjTiqo=='21':QfGlIxRWpzPSBrsbwODuHLvecjTiMY+=' (%s)'%(QfGlIxRWpzPSBrsbwODuHLvecjTiqo)
   QfGlIxRWpzPSBrsbwODuHLvecjTiqU={'plot':QfGlIxRWpzPSBrsbwODuHLvecjTiMY,'mpaa':QfGlIxRWpzPSBrsbwODuHLvecjTiqo,'mediatype':'episode'}
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt={'mode':'EPISODE_LIST','videoid':QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('videoid'),'vidtype':QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('vidtype'),'page':'1'}
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.add_dir(QfGlIxRWpzPSBrsbwODuHLvecjTiMY,sublabel='',img=QfGlIxRWpzPSBrsbwODuHLvecjTiqa,infoLabels=QfGlIxRWpzPSBrsbwODuHLvecjTiqU,isFolder=QfGlIxRWpzPSBrsbwODuHLvecjTiYU,params=QfGlIxRWpzPSBrsbwODuHLvecjTiMt)
  if QfGlIxRWpzPSBrsbwODuHLvecjTiqg:
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt={}
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt['mode'] ='PROGRAM_LIST' 
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt['subapi']=QfGlIxRWpzPSBrsbwODuHLvecjTiqy 
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt['page'] =QfGlIxRWpzPSBrsbwODuHLvecjTiXd(QfGlIxRWpzPSBrsbwODuHLvecjTiqn+1)
   QfGlIxRWpzPSBrsbwODuHLvecjTiMY='[B]%s >>[/B]'%'다음 페이지'
   QfGlIxRWpzPSBrsbwODuHLvecjTiqk=QfGlIxRWpzPSBrsbwODuHLvecjTiXd(QfGlIxRWpzPSBrsbwODuHLvecjTiqn+1)
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.add_dir(QfGlIxRWpzPSBrsbwODuHLvecjTiMY,sublabel=QfGlIxRWpzPSBrsbwODuHLvecjTiqk,img='',infoLabels=QfGlIxRWpzPSBrsbwODuHLvecjTiYg,isFolder=QfGlIxRWpzPSBrsbwODuHLvecjTiYU,params=QfGlIxRWpzPSBrsbwODuHLvecjTiMt)
  if QfGlIxRWpzPSBrsbwODuHLvecjTiYk(QfGlIxRWpzPSBrsbwODuHLvecjTiqm)>0:xbmcplugin.endOfDirectory(QfGlIxRWpzPSBrsbwODuHLvecjTiht._addon_handle,cacheToDisc=QfGlIxRWpzPSBrsbwODuHLvecjTiYo)
 def dp_SuperSection_List(QfGlIxRWpzPSBrsbwODuHLvecjTiht,args):
  QfGlIxRWpzPSBrsbwODuHLvecjTiht.WavveObj.SaveCredential(QfGlIxRWpzPSBrsbwODuHLvecjTiht.get_winCredential())
  QfGlIxRWpzPSBrsbwODuHLvecjTiqE =args.get('suburl')
  QfGlIxRWpzPSBrsbwODuHLvecjTiqm=QfGlIxRWpzPSBrsbwODuHLvecjTiht.WavveObj.Get_SuperMultiSection_List(QfGlIxRWpzPSBrsbwODuHLvecjTiqE)
  for QfGlIxRWpzPSBrsbwODuHLvecjTiqJ in QfGlIxRWpzPSBrsbwODuHLvecjTiqm:
   QfGlIxRWpzPSBrsbwODuHLvecjTiMY =QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('title')
   QfGlIxRWpzPSBrsbwODuHLvecjTiqy =QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('subapi')
   QfGlIxRWpzPSBrsbwODuHLvecjTiqA=QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('cell_type')
   if QfGlIxRWpzPSBrsbwODuHLvecjTiqy.find('mtype=svod')>=0 or QfGlIxRWpzPSBrsbwODuHLvecjTiqy.find('mtype=ppv')>=0:
    QfGlIxRWpzPSBrsbwODuHLvecjTiMk='MOVIE_LIST'
   elif QfGlIxRWpzPSBrsbwODuHLvecjTiqA=='band_71':
    QfGlIxRWpzPSBrsbwODuHLvecjTiMk ='SUPERSECTION_LIST'
    (QfGlIxRWpzPSBrsbwODuHLvecjTiYh,QfGlIxRWpzPSBrsbwODuHLvecjTiYM)=QfGlIxRWpzPSBrsbwODuHLvecjTiht.WavveObj.Baseapi_Parse(QfGlIxRWpzPSBrsbwODuHLvecjTiqy)
    QfGlIxRWpzPSBrsbwODuHLvecjTiqE=QfGlIxRWpzPSBrsbwODuHLvecjTiYM.get('api')
    QfGlIxRWpzPSBrsbwODuHLvecjTiqy=''
   elif QfGlIxRWpzPSBrsbwODuHLvecjTiqA=='band_2':
    QfGlIxRWpzPSBrsbwODuHLvecjTiMk='BAND2SECTION_LIST'
   elif QfGlIxRWpzPSBrsbwODuHLvecjTiqA=='band_live':
    QfGlIxRWpzPSBrsbwODuHLvecjTiMk='BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}',QfGlIxRWpzPSBrsbwODuHLvecjTiqy):
    QfGlIxRWpzPSBrsbwODuHLvecjTiMk='MOVIE_LIST'
   else:
    QfGlIxRWpzPSBrsbwODuHLvecjTiMk='PROGRAM_LIST'
   QfGlIxRWpzPSBrsbwODuHLvecjTiqU={'plot':QfGlIxRWpzPSBrsbwODuHLvecjTiMY,'mediatype':'episode'}
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt={'mode':QfGlIxRWpzPSBrsbwODuHLvecjTiMk,'suburl':QfGlIxRWpzPSBrsbwODuHLvecjTiqE,'subapi':QfGlIxRWpzPSBrsbwODuHLvecjTiqy,'page':'1'}
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.add_dir(QfGlIxRWpzPSBrsbwODuHLvecjTiMY,sublabel='',img=QfGlIxRWpzPSBrsbwODuHLvecjTiYg,infoLabels=QfGlIxRWpzPSBrsbwODuHLvecjTiqU,isFolder=QfGlIxRWpzPSBrsbwODuHLvecjTiYU,params=QfGlIxRWpzPSBrsbwODuHLvecjTiMt)
  if QfGlIxRWpzPSBrsbwODuHLvecjTiYk(QfGlIxRWpzPSBrsbwODuHLvecjTiqm)>0:xbmcplugin.endOfDirectory(QfGlIxRWpzPSBrsbwODuHLvecjTiht._addon_handle,cacheToDisc=QfGlIxRWpzPSBrsbwODuHLvecjTiYo)
 def dp_BandLiveSection_List(QfGlIxRWpzPSBrsbwODuHLvecjTiht,args):
  QfGlIxRWpzPSBrsbwODuHLvecjTiht.WavveObj.SaveCredential(QfGlIxRWpzPSBrsbwODuHLvecjTiht.get_winCredential())
  QfGlIxRWpzPSBrsbwODuHLvecjTiqy =args.get('subapi')
  QfGlIxRWpzPSBrsbwODuHLvecjTiqn=QfGlIxRWpzPSBrsbwODuHLvecjTiYa(args.get('page'))
  QfGlIxRWpzPSBrsbwODuHLvecjTiqm,QfGlIxRWpzPSBrsbwODuHLvecjTiqg=QfGlIxRWpzPSBrsbwODuHLvecjTiht.WavveObj.Get_BandLiveSection_List(QfGlIxRWpzPSBrsbwODuHLvecjTiqy,QfGlIxRWpzPSBrsbwODuHLvecjTiqn)
  for QfGlIxRWpzPSBrsbwODuHLvecjTiqJ in QfGlIxRWpzPSBrsbwODuHLvecjTiqm:
   QfGlIxRWpzPSBrsbwODuHLvecjTiYd =QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('channelid')
   QfGlIxRWpzPSBrsbwODuHLvecjTiYq =QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('studio')
   QfGlIxRWpzPSBrsbwODuHLvecjTiYX=QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('tvshowtitle')
   QfGlIxRWpzPSBrsbwODuHLvecjTiqa =QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('thumbnail')
   QfGlIxRWpzPSBrsbwODuHLvecjTiqo =QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('age')
   QfGlIxRWpzPSBrsbwODuHLvecjTiqU={'mediatype':'video','mpaa':QfGlIxRWpzPSBrsbwODuHLvecjTiqo,'title':'%s < %s >'%(QfGlIxRWpzPSBrsbwODuHLvecjTiYq,QfGlIxRWpzPSBrsbwODuHLvecjTiYX),'tvshowtitle':QfGlIxRWpzPSBrsbwODuHLvecjTiYX,'studio':QfGlIxRWpzPSBrsbwODuHLvecjTiYq,'plot':QfGlIxRWpzPSBrsbwODuHLvecjTiYq}
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt={'mode':'LIVE','contentid':QfGlIxRWpzPSBrsbwODuHLvecjTiYd}
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.add_dir(QfGlIxRWpzPSBrsbwODuHLvecjTiYq,sublabel=QfGlIxRWpzPSBrsbwODuHLvecjTiYX,img=QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('thumbnail'),infoLabels=QfGlIxRWpzPSBrsbwODuHLvecjTiqU,isFolder=QfGlIxRWpzPSBrsbwODuHLvecjTiYo,params=QfGlIxRWpzPSBrsbwODuHLvecjTiMt)
  if QfGlIxRWpzPSBrsbwODuHLvecjTiqg:
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt={}
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt['mode'] ='BANDLIVESECTION_LIST' 
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt['subapi']=QfGlIxRWpzPSBrsbwODuHLvecjTiqy
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt['page'] =QfGlIxRWpzPSBrsbwODuHLvecjTiXd(QfGlIxRWpzPSBrsbwODuHLvecjTiqn+1)
   QfGlIxRWpzPSBrsbwODuHLvecjTiMY='[B]%s >>[/B]'%'다음 페이지'
   QfGlIxRWpzPSBrsbwODuHLvecjTiqk=QfGlIxRWpzPSBrsbwODuHLvecjTiXd(QfGlIxRWpzPSBrsbwODuHLvecjTiqn+1)
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.add_dir(QfGlIxRWpzPSBrsbwODuHLvecjTiMY,sublabel=QfGlIxRWpzPSBrsbwODuHLvecjTiqk,img='',infoLabels=QfGlIxRWpzPSBrsbwODuHLvecjTiYg,isFolder=QfGlIxRWpzPSBrsbwODuHLvecjTiYU,params=QfGlIxRWpzPSBrsbwODuHLvecjTiMt)
  if QfGlIxRWpzPSBrsbwODuHLvecjTiYk(QfGlIxRWpzPSBrsbwODuHLvecjTiqm)>0:xbmcplugin.endOfDirectory(QfGlIxRWpzPSBrsbwODuHLvecjTiht._addon_handle,cacheToDisc=QfGlIxRWpzPSBrsbwODuHLvecjTiYo)
 def dp_Band2Section_List(QfGlIxRWpzPSBrsbwODuHLvecjTiht,args):
  QfGlIxRWpzPSBrsbwODuHLvecjTiht.WavveObj.SaveCredential(QfGlIxRWpzPSBrsbwODuHLvecjTiht.get_winCredential())
  QfGlIxRWpzPSBrsbwODuHLvecjTiqy =args.get('subapi')
  QfGlIxRWpzPSBrsbwODuHLvecjTiqn=QfGlIxRWpzPSBrsbwODuHLvecjTiYa(args.get('page'))
  QfGlIxRWpzPSBrsbwODuHLvecjTiqm,QfGlIxRWpzPSBrsbwODuHLvecjTiqg=QfGlIxRWpzPSBrsbwODuHLvecjTiht.WavveObj.Get_Band2Section_List(QfGlIxRWpzPSBrsbwODuHLvecjTiqy,QfGlIxRWpzPSBrsbwODuHLvecjTiqn)
  for QfGlIxRWpzPSBrsbwODuHLvecjTiqJ in QfGlIxRWpzPSBrsbwODuHLvecjTiqm:
   QfGlIxRWpzPSBrsbwODuHLvecjTiMY =QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('programtitle')
   QfGlIxRWpzPSBrsbwODuHLvecjTiqk =QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('episodetitle')
   QfGlIxRWpzPSBrsbwODuHLvecjTiqU={'plot':QfGlIxRWpzPSBrsbwODuHLvecjTiMY+'\n\n'+QfGlIxRWpzPSBrsbwODuHLvecjTiqk,'mpaa':QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('age'),'mediatype':'episode'}
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt={'mode':'VOD','programid':'-','contentid':QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('videoid'),'thumbnail':QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('thumbnail'),'title':QfGlIxRWpzPSBrsbwODuHLvecjTiMY,'subtitle':QfGlIxRWpzPSBrsbwODuHLvecjTiqk}
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.add_dir(QfGlIxRWpzPSBrsbwODuHLvecjTiMY,sublabel=QfGlIxRWpzPSBrsbwODuHLvecjTiqk,img=QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('thumbnail'),infoLabels=QfGlIxRWpzPSBrsbwODuHLvecjTiqU,isFolder=QfGlIxRWpzPSBrsbwODuHLvecjTiYo,params=QfGlIxRWpzPSBrsbwODuHLvecjTiMt)
  if QfGlIxRWpzPSBrsbwODuHLvecjTiqg:
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt={}
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt['mode'] ='BAND2SECTION_LIST' 
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt['subapi']=QfGlIxRWpzPSBrsbwODuHLvecjTiqy
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt['page'] =QfGlIxRWpzPSBrsbwODuHLvecjTiXd(QfGlIxRWpzPSBrsbwODuHLvecjTiqn+1)
   QfGlIxRWpzPSBrsbwODuHLvecjTiMY='[B]%s >>[/B]'%'다음 페이지'
   QfGlIxRWpzPSBrsbwODuHLvecjTiqk=QfGlIxRWpzPSBrsbwODuHLvecjTiXd(QfGlIxRWpzPSBrsbwODuHLvecjTiqn+1)
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.add_dir(QfGlIxRWpzPSBrsbwODuHLvecjTiMY,sublabel=QfGlIxRWpzPSBrsbwODuHLvecjTiqk,img='',infoLabels=QfGlIxRWpzPSBrsbwODuHLvecjTiYg,isFolder=QfGlIxRWpzPSBrsbwODuHLvecjTiYU,params=QfGlIxRWpzPSBrsbwODuHLvecjTiMt)
  if QfGlIxRWpzPSBrsbwODuHLvecjTiYk(QfGlIxRWpzPSBrsbwODuHLvecjTiqm)>0:xbmcplugin.endOfDirectory(QfGlIxRWpzPSBrsbwODuHLvecjTiht._addon_handle,cacheToDisc=QfGlIxRWpzPSBrsbwODuHLvecjTiYo)
 def dp_Movie_List(QfGlIxRWpzPSBrsbwODuHLvecjTiht,args):
  QfGlIxRWpzPSBrsbwODuHLvecjTiht.WavveObj.SaveCredential(QfGlIxRWpzPSBrsbwODuHLvecjTiht.get_winCredential())
  QfGlIxRWpzPSBrsbwODuHLvecjTiqy =args.get('subapi')
  QfGlIxRWpzPSBrsbwODuHLvecjTiqn=QfGlIxRWpzPSBrsbwODuHLvecjTiYa(args.get('page'))
  QfGlIxRWpzPSBrsbwODuHLvecjTiqm,QfGlIxRWpzPSBrsbwODuHLvecjTiqg=QfGlIxRWpzPSBrsbwODuHLvecjTiht.WavveObj.Get_Movie_List(QfGlIxRWpzPSBrsbwODuHLvecjTiqy,QfGlIxRWpzPSBrsbwODuHLvecjTiqn)
  for QfGlIxRWpzPSBrsbwODuHLvecjTiqJ in QfGlIxRWpzPSBrsbwODuHLvecjTiqm:
   QfGlIxRWpzPSBrsbwODuHLvecjTiMY =QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('title')
   QfGlIxRWpzPSBrsbwODuHLvecjTiqa=QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('thumbnail')
   QfGlIxRWpzPSBrsbwODuHLvecjTiqo =QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('age')
   if QfGlIxRWpzPSBrsbwODuHLvecjTiqo=='18' or QfGlIxRWpzPSBrsbwODuHLvecjTiqo=='19' or QfGlIxRWpzPSBrsbwODuHLvecjTiqo=='21':QfGlIxRWpzPSBrsbwODuHLvecjTiMY+=' (%s)'%(QfGlIxRWpzPSBrsbwODuHLvecjTiqo)
   QfGlIxRWpzPSBrsbwODuHLvecjTiqU={'plot':QfGlIxRWpzPSBrsbwODuHLvecjTiMY,'mpaa':QfGlIxRWpzPSBrsbwODuHLvecjTiqo,'mediatype':'movie'}
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt={'mode':'MOVIE','contentid':QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('videoid'),'title':QfGlIxRWpzPSBrsbwODuHLvecjTiMY,'thumbnail':QfGlIxRWpzPSBrsbwODuHLvecjTiqa,'age':QfGlIxRWpzPSBrsbwODuHLvecjTiqo}
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.add_dir(QfGlIxRWpzPSBrsbwODuHLvecjTiMY,sublabel='',img=QfGlIxRWpzPSBrsbwODuHLvecjTiqa,infoLabels=QfGlIxRWpzPSBrsbwODuHLvecjTiqU,isFolder=QfGlIxRWpzPSBrsbwODuHLvecjTiYo,params=QfGlIxRWpzPSBrsbwODuHLvecjTiMt)
  if QfGlIxRWpzPSBrsbwODuHLvecjTiqg:
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt={}
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt['mode'] ='MOVIE_LIST' 
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt['subapi']=QfGlIxRWpzPSBrsbwODuHLvecjTiqy 
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt['page'] =QfGlIxRWpzPSBrsbwODuHLvecjTiXd(QfGlIxRWpzPSBrsbwODuHLvecjTiqn+1)
   QfGlIxRWpzPSBrsbwODuHLvecjTiMY='[B]%s >>[/B]'%'다음 페이지'
   QfGlIxRWpzPSBrsbwODuHLvecjTiqk=QfGlIxRWpzPSBrsbwODuHLvecjTiXd(QfGlIxRWpzPSBrsbwODuHLvecjTiqn+1)
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.add_dir(QfGlIxRWpzPSBrsbwODuHLvecjTiMY,sublabel=QfGlIxRWpzPSBrsbwODuHLvecjTiqk,img='',infoLabels=QfGlIxRWpzPSBrsbwODuHLvecjTiYg,isFolder=QfGlIxRWpzPSBrsbwODuHLvecjTiYU,params=QfGlIxRWpzPSBrsbwODuHLvecjTiMt)
  if QfGlIxRWpzPSBrsbwODuHLvecjTiYk(QfGlIxRWpzPSBrsbwODuHLvecjTiqm)>0:xbmcplugin.endOfDirectory(QfGlIxRWpzPSBrsbwODuHLvecjTiht._addon_handle,cacheToDisc=QfGlIxRWpzPSBrsbwODuHLvecjTiYo)
 def dp_Episode_List(QfGlIxRWpzPSBrsbwODuHLvecjTiht,args):
  QfGlIxRWpzPSBrsbwODuHLvecjTiht.WavveObj.SaveCredential(QfGlIxRWpzPSBrsbwODuHLvecjTiht.get_winCredential())
  QfGlIxRWpzPSBrsbwODuHLvecjTiYC =args.get('videoid')
  QfGlIxRWpzPSBrsbwODuHLvecjTiYt =args.get('vidtype')
  QfGlIxRWpzPSBrsbwODuHLvecjTiqn=QfGlIxRWpzPSBrsbwODuHLvecjTiYa(args.get('page'))
  QfGlIxRWpzPSBrsbwODuHLvecjTiqm,QfGlIxRWpzPSBrsbwODuHLvecjTiqg=QfGlIxRWpzPSBrsbwODuHLvecjTiht.WavveObj.Get_Episode_List(QfGlIxRWpzPSBrsbwODuHLvecjTiYC,QfGlIxRWpzPSBrsbwODuHLvecjTiYt,QfGlIxRWpzPSBrsbwODuHLvecjTiqn,orderby=QfGlIxRWpzPSBrsbwODuHLvecjTiht.get_winEpisodeOrderby())
  for QfGlIxRWpzPSBrsbwODuHLvecjTiqJ in QfGlIxRWpzPSBrsbwODuHLvecjTiqm:
   QfGlIxRWpzPSBrsbwODuHLvecjTiqk='%s회, %s(%s)'%(QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('episodenumber'),QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('releasedate'),QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('releaseweekday'))
   QfGlIxRWpzPSBrsbwODuHLvecjTiYK ='[%s]\n\n%s'%(QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('episodetitle'),QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('synopsis'))
   QfGlIxRWpzPSBrsbwODuHLvecjTiqU={'mediatype':'episode','title':QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('programtitle'),'year':QfGlIxRWpzPSBrsbwODuHLvecjTiYa(QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('releasedate')[:4]),'aired':QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('releasedate'),'mpaa':QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('age'),'episode':QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('episodenumber'),'duration':QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('playtime'),'plot':QfGlIxRWpzPSBrsbwODuHLvecjTiYK,'cast':QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('episodeactors')}
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt={'mode':'VOD','programid':QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('programid'),'contentid':QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('contentid'),'thumbnail':QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('thumbnail'),'title':QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('programtitle'),'subtitle':QfGlIxRWpzPSBrsbwODuHLvecjTiqk}
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.add_dir(QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('programtitle'),sublabel=QfGlIxRWpzPSBrsbwODuHLvecjTiqk,img=QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('thumbnail'),infoLabels=QfGlIxRWpzPSBrsbwODuHLvecjTiqU,isFolder=QfGlIxRWpzPSBrsbwODuHLvecjTiYo,params=QfGlIxRWpzPSBrsbwODuHLvecjTiMt)
  if QfGlIxRWpzPSBrsbwODuHLvecjTiqn==1:
   QfGlIxRWpzPSBrsbwODuHLvecjTiqU={'plot':'정렬순서를 변경합니다.'}
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt={}
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt['mode'] ='ORDER_BY' 
   if QfGlIxRWpzPSBrsbwODuHLvecjTiht.get_winEpisodeOrderby()=='desc':
    QfGlIxRWpzPSBrsbwODuHLvecjTiMY='정렬순서변경 : 최신화부터 -> 1회부터'
    QfGlIxRWpzPSBrsbwODuHLvecjTiMt['orderby']='asc'
   else:
    QfGlIxRWpzPSBrsbwODuHLvecjTiMY='정렬순서변경 : 1회부터 -> 최신화부터'
    QfGlIxRWpzPSBrsbwODuHLvecjTiMt['orderby']='desc'
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.add_dir(QfGlIxRWpzPSBrsbwODuHLvecjTiMY,sublabel='',img='',infoLabels=QfGlIxRWpzPSBrsbwODuHLvecjTiqU,isFolder=QfGlIxRWpzPSBrsbwODuHLvecjTiYo,params=QfGlIxRWpzPSBrsbwODuHLvecjTiMt)
  if QfGlIxRWpzPSBrsbwODuHLvecjTiqg:
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt={}
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt['mode'] ='EPISODE_LIST' 
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt['videoid']=QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('programid')
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt['vidtype']='programid'
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt['page'] =QfGlIxRWpzPSBrsbwODuHLvecjTiXd(QfGlIxRWpzPSBrsbwODuHLvecjTiqn+1)
   QfGlIxRWpzPSBrsbwODuHLvecjTiMY='[B]%s >>[/B]'%'다음 페이지'
   QfGlIxRWpzPSBrsbwODuHLvecjTiqk=QfGlIxRWpzPSBrsbwODuHLvecjTiXd(QfGlIxRWpzPSBrsbwODuHLvecjTiqn+1)
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.add_dir(QfGlIxRWpzPSBrsbwODuHLvecjTiMY,sublabel=QfGlIxRWpzPSBrsbwODuHLvecjTiqk,img='',infoLabels=QfGlIxRWpzPSBrsbwODuHLvecjTiYg,isFolder=QfGlIxRWpzPSBrsbwODuHLvecjTiYU,params=QfGlIxRWpzPSBrsbwODuHLvecjTiMt)
  if QfGlIxRWpzPSBrsbwODuHLvecjTiYk(QfGlIxRWpzPSBrsbwODuHLvecjTiqm)>0:xbmcplugin.endOfDirectory(QfGlIxRWpzPSBrsbwODuHLvecjTiht._addon_handle,cacheToDisc=QfGlIxRWpzPSBrsbwODuHLvecjTiYo)
 def dp_LiveChannel_List(QfGlIxRWpzPSBrsbwODuHLvecjTiht,args):
  QfGlIxRWpzPSBrsbwODuHLvecjTiht.WavveObj.SaveCredential(QfGlIxRWpzPSBrsbwODuHLvecjTiht.get_winCredential())
  QfGlIxRWpzPSBrsbwODuHLvecjTiYV =args.get('genre')
  QfGlIxRWpzPSBrsbwODuHLvecjTiqN=args.get('baseapi')
  QfGlIxRWpzPSBrsbwODuHLvecjTiqm=QfGlIxRWpzPSBrsbwODuHLvecjTiht.WavveObj.Get_LiveChannel_List(QfGlIxRWpzPSBrsbwODuHLvecjTiYV,QfGlIxRWpzPSBrsbwODuHLvecjTiqN)
  for QfGlIxRWpzPSBrsbwODuHLvecjTiqJ in QfGlIxRWpzPSBrsbwODuHLvecjTiqm:
   QfGlIxRWpzPSBrsbwODuHLvecjTiYd =QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('channelid')
   QfGlIxRWpzPSBrsbwODuHLvecjTiYq =QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('studio')
   QfGlIxRWpzPSBrsbwODuHLvecjTiYX=QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('tvshowtitle')
   QfGlIxRWpzPSBrsbwODuHLvecjTiqa =QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('thumbnail')
   QfGlIxRWpzPSBrsbwODuHLvecjTiqo =QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('age')
   QfGlIxRWpzPSBrsbwODuHLvecjTiYF =QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('epg')
   QfGlIxRWpzPSBrsbwODuHLvecjTiqU={'mediatype':'video','mpaa':QfGlIxRWpzPSBrsbwODuHLvecjTiqo,'title':'%s < %s >'%(QfGlIxRWpzPSBrsbwODuHLvecjTiYq,QfGlIxRWpzPSBrsbwODuHLvecjTiYX),'tvshowtitle':QfGlIxRWpzPSBrsbwODuHLvecjTiYX,'studio':QfGlIxRWpzPSBrsbwODuHLvecjTiYq,'plot':'%s\n\n%s'%(QfGlIxRWpzPSBrsbwODuHLvecjTiYq,QfGlIxRWpzPSBrsbwODuHLvecjTiYF)}
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt={'mode':'LIVE','contentid':QfGlIxRWpzPSBrsbwODuHLvecjTiYd}
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.add_dir(QfGlIxRWpzPSBrsbwODuHLvecjTiYq,sublabel=QfGlIxRWpzPSBrsbwODuHLvecjTiYX,img=QfGlIxRWpzPSBrsbwODuHLvecjTiqa,infoLabels=QfGlIxRWpzPSBrsbwODuHLvecjTiqU,isFolder=QfGlIxRWpzPSBrsbwODuHLvecjTiYo,params=QfGlIxRWpzPSBrsbwODuHLvecjTiMt)
  if QfGlIxRWpzPSBrsbwODuHLvecjTiYk(QfGlIxRWpzPSBrsbwODuHLvecjTiqm)>0:xbmcplugin.endOfDirectory(QfGlIxRWpzPSBrsbwODuHLvecjTiht._addon_handle,cacheToDisc=QfGlIxRWpzPSBrsbwODuHLvecjTiYo)
 def dp_Search_List(QfGlIxRWpzPSBrsbwODuHLvecjTiht,args):
  QfGlIxRWpzPSBrsbwODuHLvecjTiht.WavveObj.SaveCredential(QfGlIxRWpzPSBrsbwODuHLvecjTiht.get_winCredential())
  QfGlIxRWpzPSBrsbwODuHLvecjTiqd =args.get('sType')
  QfGlIxRWpzPSBrsbwODuHLvecjTiqn =QfGlIxRWpzPSBrsbwODuHLvecjTiYa(args.get('page'))
  if 'search_key' in args:
   QfGlIxRWpzPSBrsbwODuHLvecjTiYm=args.get('search_key')
  else:
   QfGlIxRWpzPSBrsbwODuHLvecjTiYm=QfGlIxRWpzPSBrsbwODuHLvecjTiht.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not QfGlIxRWpzPSBrsbwODuHLvecjTiYm:return
  QfGlIxRWpzPSBrsbwODuHLvecjTiqm,QfGlIxRWpzPSBrsbwODuHLvecjTiqg=QfGlIxRWpzPSBrsbwODuHLvecjTiht.WavveObj.Get_Search_List(QfGlIxRWpzPSBrsbwODuHLvecjTiYm,QfGlIxRWpzPSBrsbwODuHLvecjTiqd,QfGlIxRWpzPSBrsbwODuHLvecjTiqn,exclusion21=QfGlIxRWpzPSBrsbwODuHLvecjTiht.get_settings_exclusion21())
  for QfGlIxRWpzPSBrsbwODuHLvecjTiqJ in QfGlIxRWpzPSBrsbwODuHLvecjTiqm:
   QfGlIxRWpzPSBrsbwODuHLvecjTiMY =QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('title')
   QfGlIxRWpzPSBrsbwODuHLvecjTiqa=QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('thumbnail')
   QfGlIxRWpzPSBrsbwODuHLvecjTiqo =QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('age')
   if QfGlIxRWpzPSBrsbwODuHLvecjTiqo=='18' or QfGlIxRWpzPSBrsbwODuHLvecjTiqo=='19' or QfGlIxRWpzPSBrsbwODuHLvecjTiqo=='21':QfGlIxRWpzPSBrsbwODuHLvecjTiMY+=' (%s)'%(QfGlIxRWpzPSBrsbwODuHLvecjTiqo)
   QfGlIxRWpzPSBrsbwODuHLvecjTiqU={'mediatype':'episode' if QfGlIxRWpzPSBrsbwODuHLvecjTiqd=='vod' else 'movie','mpaa':QfGlIxRWpzPSBrsbwODuHLvecjTiqo,'title':QfGlIxRWpzPSBrsbwODuHLvecjTiMY,'plot':QfGlIxRWpzPSBrsbwODuHLvecjTiMY}
   if QfGlIxRWpzPSBrsbwODuHLvecjTiqd=='vod':
    QfGlIxRWpzPSBrsbwODuHLvecjTiMt={'mode':'EPISODE_LIST','videoid':QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('videoid'),'vidtype':QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('vidtype'),'page':'1'}
    QfGlIxRWpzPSBrsbwODuHLvecjTiMK=QfGlIxRWpzPSBrsbwODuHLvecjTiYU
   else:
    QfGlIxRWpzPSBrsbwODuHLvecjTiMt={'mode':'MOVIE','contentid':QfGlIxRWpzPSBrsbwODuHLvecjTiqJ.get('videoid'),'title':QfGlIxRWpzPSBrsbwODuHLvecjTiMY,'thumbnail':QfGlIxRWpzPSBrsbwODuHLvecjTiqa,'age':QfGlIxRWpzPSBrsbwODuHLvecjTiqo}
    QfGlIxRWpzPSBrsbwODuHLvecjTiMK=QfGlIxRWpzPSBrsbwODuHLvecjTiYo
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.add_dir(QfGlIxRWpzPSBrsbwODuHLvecjTiMY,sublabel='',img=QfGlIxRWpzPSBrsbwODuHLvecjTiqa,infoLabels=QfGlIxRWpzPSBrsbwODuHLvecjTiqU,isFolder=QfGlIxRWpzPSBrsbwODuHLvecjTiMK,params=QfGlIxRWpzPSBrsbwODuHLvecjTiMt)
  if QfGlIxRWpzPSBrsbwODuHLvecjTiqg:
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt['mode'] ='SEARCH_LIST' 
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt['sType']=QfGlIxRWpzPSBrsbwODuHLvecjTiqd 
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt['page'] =QfGlIxRWpzPSBrsbwODuHLvecjTiXd(QfGlIxRWpzPSBrsbwODuHLvecjTiqn+1)
   QfGlIxRWpzPSBrsbwODuHLvecjTiMt['search_key']=QfGlIxRWpzPSBrsbwODuHLvecjTiYm
   QfGlIxRWpzPSBrsbwODuHLvecjTiMY='[B]%s >>[/B]'%'다음 페이지'
   QfGlIxRWpzPSBrsbwODuHLvecjTiqk=QfGlIxRWpzPSBrsbwODuHLvecjTiXd(QfGlIxRWpzPSBrsbwODuHLvecjTiqn+1)
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.add_dir(QfGlIxRWpzPSBrsbwODuHLvecjTiMY,sublabel=QfGlIxRWpzPSBrsbwODuHLvecjTiqk,img='',infoLabels=QfGlIxRWpzPSBrsbwODuHLvecjTiYg,isFolder=QfGlIxRWpzPSBrsbwODuHLvecjTiYU,params=QfGlIxRWpzPSBrsbwODuHLvecjTiMt)
  if QfGlIxRWpzPSBrsbwODuHLvecjTiYk(QfGlIxRWpzPSBrsbwODuHLvecjTiqm)>0:xbmcplugin.endOfDirectory(QfGlIxRWpzPSBrsbwODuHLvecjTiht._addon_handle)
 def dp_Watch_List(QfGlIxRWpzPSBrsbwODuHLvecjTiht,args):
  QfGlIxRWpzPSBrsbwODuHLvecjTiqd =args.get('sType')
  QfGlIxRWpzPSBrsbwODuHLvecjTihA=QfGlIxRWpzPSBrsbwODuHLvecjTiht.get_settings_direct_replay()
  QfGlIxRWpzPSBrsbwODuHLvecjTiqm=QfGlIxRWpzPSBrsbwODuHLvecjTiht.Load_Watched_List(QfGlIxRWpzPSBrsbwODuHLvecjTiqd)
  for QfGlIxRWpzPSBrsbwODuHLvecjTiqJ in QfGlIxRWpzPSBrsbwODuHLvecjTiqm:
   QfGlIxRWpzPSBrsbwODuHLvecjTiYN=QfGlIxRWpzPSBrsbwODuHLvecjTiYA(urllib.parse.parse_qsl(QfGlIxRWpzPSBrsbwODuHLvecjTiqJ))
   QfGlIxRWpzPSBrsbwODuHLvecjTiYJ =QfGlIxRWpzPSBrsbwODuHLvecjTiYN.get('code').strip()
   QfGlIxRWpzPSBrsbwODuHLvecjTiMY =QfGlIxRWpzPSBrsbwODuHLvecjTiYN.get('title').strip()
   QfGlIxRWpzPSBrsbwODuHLvecjTiqk =QfGlIxRWpzPSBrsbwODuHLvecjTiYN.get('subtitle').strip()
   if QfGlIxRWpzPSBrsbwODuHLvecjTiqk=='None':QfGlIxRWpzPSBrsbwODuHLvecjTiqk=''
   QfGlIxRWpzPSBrsbwODuHLvecjTiqa=QfGlIxRWpzPSBrsbwODuHLvecjTiYN.get('img').strip()
   QfGlIxRWpzPSBrsbwODuHLvecjTiYC =QfGlIxRWpzPSBrsbwODuHLvecjTiYN.get('videoid').strip()
   QfGlIxRWpzPSBrsbwODuHLvecjTiqU={'plot':'%s\n%s'%(QfGlIxRWpzPSBrsbwODuHLvecjTiMY,QfGlIxRWpzPSBrsbwODuHLvecjTiqk)}
   if QfGlIxRWpzPSBrsbwODuHLvecjTiqd=='vod':
    if QfGlIxRWpzPSBrsbwODuHLvecjTihA==QfGlIxRWpzPSBrsbwODuHLvecjTiYo or QfGlIxRWpzPSBrsbwODuHLvecjTiYC==QfGlIxRWpzPSBrsbwODuHLvecjTiYg:
     QfGlIxRWpzPSBrsbwODuHLvecjTiMt={'mode':'EPISODE_LIST','videoid':QfGlIxRWpzPSBrsbwODuHLvecjTiYJ,'vidtype':'programid','page':'1'}
     QfGlIxRWpzPSBrsbwODuHLvecjTiMK=QfGlIxRWpzPSBrsbwODuHLvecjTiYU
    else:
     QfGlIxRWpzPSBrsbwODuHLvecjTiMt={'mode':'VOD','programid':QfGlIxRWpzPSBrsbwODuHLvecjTiYJ,'contentid':QfGlIxRWpzPSBrsbwODuHLvecjTiYC,'title':QfGlIxRWpzPSBrsbwODuHLvecjTiMY,'subtitle':QfGlIxRWpzPSBrsbwODuHLvecjTiqk,'thumbnail':QfGlIxRWpzPSBrsbwODuHLvecjTiqa}
     QfGlIxRWpzPSBrsbwODuHLvecjTiMK=QfGlIxRWpzPSBrsbwODuHLvecjTiYo
   else:
    QfGlIxRWpzPSBrsbwODuHLvecjTiMt={'mode':'MOVIE','contentid':QfGlIxRWpzPSBrsbwODuHLvecjTiYJ,'title':QfGlIxRWpzPSBrsbwODuHLvecjTiMY,'subtitle':QfGlIxRWpzPSBrsbwODuHLvecjTiqk,'thumbnail':QfGlIxRWpzPSBrsbwODuHLvecjTiqa}
    QfGlIxRWpzPSBrsbwODuHLvecjTiMK=QfGlIxRWpzPSBrsbwODuHLvecjTiYo
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.add_dir(QfGlIxRWpzPSBrsbwODuHLvecjTiMY,sublabel=QfGlIxRWpzPSBrsbwODuHLvecjTiqk,img=QfGlIxRWpzPSBrsbwODuHLvecjTiqa,infoLabels=QfGlIxRWpzPSBrsbwODuHLvecjTiqU,isFolder=QfGlIxRWpzPSBrsbwODuHLvecjTiMK,params=QfGlIxRWpzPSBrsbwODuHLvecjTiMt)
  QfGlIxRWpzPSBrsbwODuHLvecjTiqU={'plot':'시청목록을 삭제합니다.'}
  QfGlIxRWpzPSBrsbwODuHLvecjTiMY='*** 시청목록 삭제 ***'
  QfGlIxRWpzPSBrsbwODuHLvecjTiMt={'mode':'MYVIEW_REMOVE','sType':QfGlIxRWpzPSBrsbwODuHLvecjTiqd}
  QfGlIxRWpzPSBrsbwODuHLvecjTiht.add_dir(QfGlIxRWpzPSBrsbwODuHLvecjTiMY,sublabel='',img='',infoLabels=QfGlIxRWpzPSBrsbwODuHLvecjTiqU,isFolder=QfGlIxRWpzPSBrsbwODuHLvecjTiYo,params=QfGlIxRWpzPSBrsbwODuHLvecjTiMt)
  xbmcplugin.endOfDirectory(QfGlIxRWpzPSBrsbwODuHLvecjTiht._addon_handle,cacheToDisc=QfGlIxRWpzPSBrsbwODuHLvecjTiYo)
 def wavve_main(QfGlIxRWpzPSBrsbwODuHLvecjTiht):
  QfGlIxRWpzPSBrsbwODuHLvecjTiMk=QfGlIxRWpzPSBrsbwODuHLvecjTiht.main_params.get('mode',QfGlIxRWpzPSBrsbwODuHLvecjTiYg)
  if QfGlIxRWpzPSBrsbwODuHLvecjTiMk=='LOGOUT':
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.logout()
   return
  QfGlIxRWpzPSBrsbwODuHLvecjTiht.login_main()
  if QfGlIxRWpzPSBrsbwODuHLvecjTiMk is QfGlIxRWpzPSBrsbwODuHLvecjTiYg:
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.dp_Main_List()
  elif QfGlIxRWpzPSBrsbwODuHLvecjTiMk in['LIVE','VOD','MOVIE']:
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.play_VIDEO(QfGlIxRWpzPSBrsbwODuHLvecjTiht.main_params)
  elif QfGlIxRWpzPSBrsbwODuHLvecjTiMk=='LIVE_CATAGORY':
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.dp_LiveCatagory_List(QfGlIxRWpzPSBrsbwODuHLvecjTiht.main_params)
  elif QfGlIxRWpzPSBrsbwODuHLvecjTiMk=='MAIN_CATAGORY':
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.dp_MainCatagory_List(QfGlIxRWpzPSBrsbwODuHLvecjTiht.main_params)
  elif QfGlIxRWpzPSBrsbwODuHLvecjTiMk=='SUPERSECTION_LIST':
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.dp_SuperSection_List(QfGlIxRWpzPSBrsbwODuHLvecjTiht.main_params)
  elif QfGlIxRWpzPSBrsbwODuHLvecjTiMk=='BANDLIVESECTION_LIST':
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.dp_BandLiveSection_List(QfGlIxRWpzPSBrsbwODuHLvecjTiht.main_params)
  elif QfGlIxRWpzPSBrsbwODuHLvecjTiMk=='BAND2SECTION_LIST':
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.dp_Band2Section_List(QfGlIxRWpzPSBrsbwODuHLvecjTiht.main_params)
  elif QfGlIxRWpzPSBrsbwODuHLvecjTiMk=='PROGRAM_LIST':
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.dp_Program_List(QfGlIxRWpzPSBrsbwODuHLvecjTiht.main_params)
  elif QfGlIxRWpzPSBrsbwODuHLvecjTiMk=='EPISODE_LIST':
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.dp_Episode_List(QfGlIxRWpzPSBrsbwODuHLvecjTiht.main_params)
  elif QfGlIxRWpzPSBrsbwODuHLvecjTiMk=='MOVIE_LIST':
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.dp_Movie_List(QfGlIxRWpzPSBrsbwODuHLvecjTiht.main_params)
  elif QfGlIxRWpzPSBrsbwODuHLvecjTiMk=='LIVE_LIST':
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.dp_LiveChannel_List(QfGlIxRWpzPSBrsbwODuHLvecjTiht.main_params)
  elif QfGlIxRWpzPSBrsbwODuHLvecjTiMk=='ORDER_BY':
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.dp_setEpOrderby(QfGlIxRWpzPSBrsbwODuHLvecjTiht.main_params)
  elif QfGlIxRWpzPSBrsbwODuHLvecjTiMk=='SEARCH_GROUP':
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.dp_Search_Group(QfGlIxRWpzPSBrsbwODuHLvecjTiht.main_params)
  elif QfGlIxRWpzPSBrsbwODuHLvecjTiMk=='SEARCH_LIST':
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.dp_Search_List(QfGlIxRWpzPSBrsbwODuHLvecjTiht.main_params)
  elif QfGlIxRWpzPSBrsbwODuHLvecjTiMk=='WATCH_GROUP':
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.dp_Watch_Group(QfGlIxRWpzPSBrsbwODuHLvecjTiht.main_params)
  elif QfGlIxRWpzPSBrsbwODuHLvecjTiMk=='WATCH_LIST':
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.dp_Watch_List(QfGlIxRWpzPSBrsbwODuHLvecjTiht.main_params)
  elif QfGlIxRWpzPSBrsbwODuHLvecjTiMk=='MYVIEW_REMOVE':
   QfGlIxRWpzPSBrsbwODuHLvecjTiht.dp_WatchList_Delete(QfGlIxRWpzPSBrsbwODuHLvecjTiht.main_params)
  else:
   QfGlIxRWpzPSBrsbwODuHLvecjTiYg
# Created by pyminifier (https://github.com/liftoff/pyminifier)
