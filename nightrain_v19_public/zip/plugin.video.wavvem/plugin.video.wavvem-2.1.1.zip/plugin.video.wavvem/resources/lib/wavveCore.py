__author__="NightRain"
GSplofuUIabRjBVckdenvxQLmNzMsD=object
GSplofuUIabRjBVckdenvxQLmNzMsH=None
GSplofuUIabRjBVckdenvxQLmNzMst=False
GSplofuUIabRjBVckdenvxQLmNzMsy=True
GSplofuUIabRjBVckdenvxQLmNzMsJ=range
GSplofuUIabRjBVckdenvxQLmNzMsA=str
GSplofuUIabRjBVckdenvxQLmNzMsq=Exception
GSplofuUIabRjBVckdenvxQLmNzMsO=print
GSplofuUIabRjBVckdenvxQLmNzMsY=dict
GSplofuUIabRjBVckdenvxQLmNzMsr=int
GSplofuUIabRjBVckdenvxQLmNzMsW=len
import urllib
import http.cookiejar 
import re
import json
import sys
import requests
import datetime
GSplofuUIabRjBVckdenvxQLmNzMEF='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
class GSplofuUIabRjBVckdenvxQLmNzMEi(GSplofuUIabRjBVckdenvxQLmNzMsD):
 def __init__(GSplofuUIabRjBVckdenvxQLmNzMEs):
  GSplofuUIabRjBVckdenvxQLmNzMEs.API_DOMAIN='https://apis.wavve.com'
  GSplofuUIabRjBVckdenvxQLmNzMEs.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  GSplofuUIabRjBVckdenvxQLmNzMEs.CREDENTIAL='none'
  GSplofuUIabRjBVckdenvxQLmNzMEs.DEVICE ='pc'
  GSplofuUIabRjBVckdenvxQLmNzMEs.DRM ='wm'
  GSplofuUIabRjBVckdenvxQLmNzMEs.PARTNER ='pooq'
  GSplofuUIabRjBVckdenvxQLmNzMEs.POOQZONE ='none'
  GSplofuUIabRjBVckdenvxQLmNzMEs.REGION ='kor'
  GSplofuUIabRjBVckdenvxQLmNzMEs.TARGETAGE ='all'
  GSplofuUIabRjBVckdenvxQLmNzMEs.HTTPTAG ='https://'
  GSplofuUIabRjBVckdenvxQLmNzMEs.LIST_LIMIT=30 
  GSplofuUIabRjBVckdenvxQLmNzMEs.EP_LIMIT =30 
  GSplofuUIabRjBVckdenvxQLmNzMEs.MV_LIMIT =24 
  GSplofuUIabRjBVckdenvxQLmNzMEs.guid ='none' 
  GSplofuUIabRjBVckdenvxQLmNzMEs.guidtimestamp='none' 
  GSplofuUIabRjBVckdenvxQLmNzMEs.DEFAULT_HEADER={'user-agent':GSplofuUIabRjBVckdenvxQLmNzMEF}
 def callRequestCookies(GSplofuUIabRjBVckdenvxQLmNzMEs,jobtype,GSplofuUIabRjBVckdenvxQLmNzMEr,payload=GSplofuUIabRjBVckdenvxQLmNzMsH,params=GSplofuUIabRjBVckdenvxQLmNzMsH,headers=GSplofuUIabRjBVckdenvxQLmNzMsH,cookies=GSplofuUIabRjBVckdenvxQLmNzMsH,redirects=GSplofuUIabRjBVckdenvxQLmNzMst):
  GSplofuUIabRjBVckdenvxQLmNzMEP=GSplofuUIabRjBVckdenvxQLmNzMEs.DEFAULT_HEADER
  if headers:GSplofuUIabRjBVckdenvxQLmNzMEP.update(headers)
  if jobtype=='Get':
   GSplofuUIabRjBVckdenvxQLmNzMEg=requests.get(GSplofuUIabRjBVckdenvxQLmNzMEr,params=params,headers=GSplofuUIabRjBVckdenvxQLmNzMEP,cookies=cookies,allow_redirects=redirects)
  else:
   GSplofuUIabRjBVckdenvxQLmNzMEg=requests.post(GSplofuUIabRjBVckdenvxQLmNzMEr,data=payload,params=params,headers=GSplofuUIabRjBVckdenvxQLmNzMEP,cookies=cookies,allow_redirects=redirects)
  return GSplofuUIabRjBVckdenvxQLmNzMEg
 def SaveCredential(GSplofuUIabRjBVckdenvxQLmNzMEs,GSplofuUIabRjBVckdenvxQLmNzMEC):
  GSplofuUIabRjBVckdenvxQLmNzMEs.CREDENTIAL=GSplofuUIabRjBVckdenvxQLmNzMEC
 def LoadCredential(GSplofuUIabRjBVckdenvxQLmNzMEs):
  return GSplofuUIabRjBVckdenvxQLmNzMEs.CREDENTIAL
 def GetDefaultParams(GSplofuUIabRjBVckdenvxQLmNzMEs,login=GSplofuUIabRjBVckdenvxQLmNzMsy):
  GSplofuUIabRjBVckdenvxQLmNzMEK={'apikey':GSplofuUIabRjBVckdenvxQLmNzMEs.APIKEY,'credential':GSplofuUIabRjBVckdenvxQLmNzMEs.CREDENTIAL if login else 'none','device':GSplofuUIabRjBVckdenvxQLmNzMEs.DEVICE,'drm':GSplofuUIabRjBVckdenvxQLmNzMEs.DRM,'partner':GSplofuUIabRjBVckdenvxQLmNzMEs.PARTNER,'pooqzone':GSplofuUIabRjBVckdenvxQLmNzMEs.POOQZONE,'region':GSplofuUIabRjBVckdenvxQLmNzMEs.REGION,'targetage':GSplofuUIabRjBVckdenvxQLmNzMEs.TARGETAGE}
  return GSplofuUIabRjBVckdenvxQLmNzMEK
 def GetGUID(GSplofuUIabRjBVckdenvxQLmNzMEs,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   GSplofuUIabRjBVckdenvxQLmNzMEw=GSplofuUIabRjBVckdenvxQLmNzMEs.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   GSplofuUIabRjBVckdenvxQLmNzMED=GenerateRandomString(5)
   GSplofuUIabRjBVckdenvxQLmNzMEH=GSplofuUIabRjBVckdenvxQLmNzMED+media+GSplofuUIabRjBVckdenvxQLmNzMEw
   return GSplofuUIabRjBVckdenvxQLmNzMEH
  def GenerateRandomString(num):
   from random import randint
   GSplofuUIabRjBVckdenvxQLmNzMEt=""
   for i in GSplofuUIabRjBVckdenvxQLmNzMsJ(0,num):
    s=GSplofuUIabRjBVckdenvxQLmNzMsA(randint(1,5))
    GSplofuUIabRjBVckdenvxQLmNzMEt+=s
   return GSplofuUIabRjBVckdenvxQLmNzMEt
  GSplofuUIabRjBVckdenvxQLmNzMEH=GenerateID(guid_str)
  GSplofuUIabRjBVckdenvxQLmNzMEy=GSplofuUIabRjBVckdenvxQLmNzMEs.GetHash(GSplofuUIabRjBVckdenvxQLmNzMEH)
  if guidType==2:
   GSplofuUIabRjBVckdenvxQLmNzMEy='%s-%s-%s-%s-%s'%(GSplofuUIabRjBVckdenvxQLmNzMEy[:8],GSplofuUIabRjBVckdenvxQLmNzMEy[8:12],GSplofuUIabRjBVckdenvxQLmNzMEy[12:16],GSplofuUIabRjBVckdenvxQLmNzMEy[16:20],GSplofuUIabRjBVckdenvxQLmNzMEy[20:])
  return GSplofuUIabRjBVckdenvxQLmNzMEy
 def GetHash(GSplofuUIabRjBVckdenvxQLmNzMEs,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return GSplofuUIabRjBVckdenvxQLmNzMsA(m.hexdigest())
 def CheckQuality(GSplofuUIabRjBVckdenvxQLmNzMEs,sel_qt,qt_list):
  GSplofuUIabRjBVckdenvxQLmNzMEJ=0
  for GSplofuUIabRjBVckdenvxQLmNzMEA in qt_list:
   if sel_qt>=GSplofuUIabRjBVckdenvxQLmNzMEA:return GSplofuUIabRjBVckdenvxQLmNzMEA
   GSplofuUIabRjBVckdenvxQLmNzMEJ=GSplofuUIabRjBVckdenvxQLmNzMEA
  return GSplofuUIabRjBVckdenvxQLmNzMEJ
 def Get_Now_Datetime(GSplofuUIabRjBVckdenvxQLmNzMEs):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(GSplofuUIabRjBVckdenvxQLmNzMEs,in_text):
  GSplofuUIabRjBVckdenvxQLmNzMEO=in_text.replace('&lt;','<').replace('&gt;','>')
  GSplofuUIabRjBVckdenvxQLmNzMEO=GSplofuUIabRjBVckdenvxQLmNzMEO.replace('$O$','')
  GSplofuUIabRjBVckdenvxQLmNzMEO=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',GSplofuUIabRjBVckdenvxQLmNzMEO)
  GSplofuUIabRjBVckdenvxQLmNzMEO=GSplofuUIabRjBVckdenvxQLmNzMEO.lstrip('#')
  return GSplofuUIabRjBVckdenvxQLmNzMEO
 def GetCredential(GSplofuUIabRjBVckdenvxQLmNzMEs,user_id,user_pw,user_pf):
  GSplofuUIabRjBVckdenvxQLmNzMEY=GSplofuUIabRjBVckdenvxQLmNzMst
  try:
   GSplofuUIabRjBVckdenvxQLmNzMEr=GSplofuUIabRjBVckdenvxQLmNzMEs.API_DOMAIN+ '/login'
   GSplofuUIabRjBVckdenvxQLmNzMEK=GSplofuUIabRjBVckdenvxQLmNzMEs.GetDefaultParams()
   GSplofuUIabRjBVckdenvxQLmNzMEW={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   GSplofuUIabRjBVckdenvxQLmNzMEX=GSplofuUIabRjBVckdenvxQLmNzMEs.callRequestCookies('Post',GSplofuUIabRjBVckdenvxQLmNzMEr,payload=GSplofuUIabRjBVckdenvxQLmNzMEW,params=GSplofuUIabRjBVckdenvxQLmNzMEK,headers=GSplofuUIabRjBVckdenvxQLmNzMsH,cookies=GSplofuUIabRjBVckdenvxQLmNzMsH)
   GSplofuUIabRjBVckdenvxQLmNzMET=json.loads(GSplofuUIabRjBVckdenvxQLmNzMEX.text)
   GSplofuUIabRjBVckdenvxQLmNzMEC=GSplofuUIabRjBVckdenvxQLmNzMET['credential']
   if user_pf!=0:
    GSplofuUIabRjBVckdenvxQLmNzMEW={'id':GSplofuUIabRjBVckdenvxQLmNzMEC,'password':'','profile':GSplofuUIabRjBVckdenvxQLmNzMsA(user_pf),'pushid':'','type':'credential'}
    GSplofuUIabRjBVckdenvxQLmNzMEK['credential']=GSplofuUIabRjBVckdenvxQLmNzMEC 
    GSplofuUIabRjBVckdenvxQLmNzMEX=GSplofuUIabRjBVckdenvxQLmNzMEs.callRequestCookies('Post',GSplofuUIabRjBVckdenvxQLmNzMEr,payload=GSplofuUIabRjBVckdenvxQLmNzMEW,params=GSplofuUIabRjBVckdenvxQLmNzMEK,headers=GSplofuUIabRjBVckdenvxQLmNzMsH,cookies=GSplofuUIabRjBVckdenvxQLmNzMsH)
    GSplofuUIabRjBVckdenvxQLmNzMET=json.loads(GSplofuUIabRjBVckdenvxQLmNzMEX.text)
    GSplofuUIabRjBVckdenvxQLmNzMEC=GSplofuUIabRjBVckdenvxQLmNzMET['credential']
   if GSplofuUIabRjBVckdenvxQLmNzMEC:GSplofuUIabRjBVckdenvxQLmNzMEY=GSplofuUIabRjBVckdenvxQLmNzMsy
  except GSplofuUIabRjBVckdenvxQLmNzMsq as exception:
   GSplofuUIabRjBVckdenvxQLmNzMsO(exception)
   GSplofuUIabRjBVckdenvxQLmNzMEC='none' 
  GSplofuUIabRjBVckdenvxQLmNzMEs.SaveCredential(GSplofuUIabRjBVckdenvxQLmNzMEC)
  return GSplofuUIabRjBVckdenvxQLmNzMEY
 def GetIssue(GSplofuUIabRjBVckdenvxQLmNzMEs):
  GSplofuUIabRjBVckdenvxQLmNzMEh=GSplofuUIabRjBVckdenvxQLmNzMst
  try:
   GSplofuUIabRjBVckdenvxQLmNzMEr=GSplofuUIabRjBVckdenvxQLmNzMEs.API_DOMAIN+'/guid/issue'
   GSplofuUIabRjBVckdenvxQLmNzMEK=GSplofuUIabRjBVckdenvxQLmNzMEs.GetDefaultParams()
   GSplofuUIabRjBVckdenvxQLmNzMEX=GSplofuUIabRjBVckdenvxQLmNzMEs.callRequestCookies('Get',GSplofuUIabRjBVckdenvxQLmNzMEr,payload=GSplofuUIabRjBVckdenvxQLmNzMsH,params=GSplofuUIabRjBVckdenvxQLmNzMEK,headers=GSplofuUIabRjBVckdenvxQLmNzMsH,cookies=GSplofuUIabRjBVckdenvxQLmNzMsH)
   GSplofuUIabRjBVckdenvxQLmNzMET=json.loads(GSplofuUIabRjBVckdenvxQLmNzMEX.text)
   GSplofuUIabRjBVckdenvxQLmNzMiE=GSplofuUIabRjBVckdenvxQLmNzMET['guid']
   GSplofuUIabRjBVckdenvxQLmNzMiF=GSplofuUIabRjBVckdenvxQLmNzMET['guidtimestamp']
   if GSplofuUIabRjBVckdenvxQLmNzMiE:GSplofuUIabRjBVckdenvxQLmNzMEh=GSplofuUIabRjBVckdenvxQLmNzMsy
  except GSplofuUIabRjBVckdenvxQLmNzMsq as exception:
   GSplofuUIabRjBVckdenvxQLmNzMsO(exception)
   GSplofuUIabRjBVckdenvxQLmNzMiE='none'
   GSplofuUIabRjBVckdenvxQLmNzMiF='none' 
  GSplofuUIabRjBVckdenvxQLmNzMEs.guid=GSplofuUIabRjBVckdenvxQLmNzMiE
  GSplofuUIabRjBVckdenvxQLmNzMEs.guidtimestamp=GSplofuUIabRjBVckdenvxQLmNzMiF
  return GSplofuUIabRjBVckdenvxQLmNzMEh
 def Baseapi_Parse(GSplofuUIabRjBVckdenvxQLmNzMEs,GSplofuUIabRjBVckdenvxQLmNzMiC):
  try:
   GSplofuUIabRjBVckdenvxQLmNzMis =urllib.parse.urlsplit(GSplofuUIabRjBVckdenvxQLmNzMiC)
   if GSplofuUIabRjBVckdenvxQLmNzMis.netloc=='':
    GSplofuUIabRjBVckdenvxQLmNzMEr=GSplofuUIabRjBVckdenvxQLmNzMEs.HTTPTAG+GSplofuUIabRjBVckdenvxQLmNzMis.netloc+GSplofuUIabRjBVckdenvxQLmNzMis.path
   else:
    GSplofuUIabRjBVckdenvxQLmNzMEr=GSplofuUIabRjBVckdenvxQLmNzMis.scheme+'://'+GSplofuUIabRjBVckdenvxQLmNzMis.netloc+GSplofuUIabRjBVckdenvxQLmNzMis.path
   GSplofuUIabRjBVckdenvxQLmNzMEK=GSplofuUIabRjBVckdenvxQLmNzMsY(urllib.parse.parse_qsl(GSplofuUIabRjBVckdenvxQLmNzMis.query))
  except:
   GSplofuUIabRjBVckdenvxQLmNzMsO(exception)
   return '',{}
  return GSplofuUIabRjBVckdenvxQLmNzMEr,GSplofuUIabRjBVckdenvxQLmNzMEK
 def GetSupermultiUrl(GSplofuUIabRjBVckdenvxQLmNzMEs,sCode,sIndex='0'):
  try:
   GSplofuUIabRjBVckdenvxQLmNzMEr=GSplofuUIabRjBVckdenvxQLmNzMEs.API_DOMAIN+'/cf/supermultisections/'+sCode
   GSplofuUIabRjBVckdenvxQLmNzMEK=GSplofuUIabRjBVckdenvxQLmNzMEs.GetDefaultParams(login=GSplofuUIabRjBVckdenvxQLmNzMst)
   GSplofuUIabRjBVckdenvxQLmNzMEX=GSplofuUIabRjBVckdenvxQLmNzMEs.callRequestCookies('Get',GSplofuUIabRjBVckdenvxQLmNzMEr,payload=GSplofuUIabRjBVckdenvxQLmNzMsH,params=GSplofuUIabRjBVckdenvxQLmNzMEK,headers=GSplofuUIabRjBVckdenvxQLmNzMsH,cookies=GSplofuUIabRjBVckdenvxQLmNzMsH)
   GSplofuUIabRjBVckdenvxQLmNzMET=json.loads(GSplofuUIabRjBVckdenvxQLmNzMEX.text)
   GSplofuUIabRjBVckdenvxQLmNzMiP=GSplofuUIabRjBVckdenvxQLmNzMET['multisectionlist'][GSplofuUIabRjBVckdenvxQLmNzMsr(sIndex)]['eventlist'][1]['url']
  except GSplofuUIabRjBVckdenvxQLmNzMsq as exception:
   GSplofuUIabRjBVckdenvxQLmNzMsO(exception)
   return ''
  return GSplofuUIabRjBVckdenvxQLmNzMiP
 def Get_LiveCatagory_List(GSplofuUIabRjBVckdenvxQLmNzMEs,sCode,sIndex='0'):
  GSplofuUIabRjBVckdenvxQLmNzMig=[]
  GSplofuUIabRjBVckdenvxQLmNzMiC =GSplofuUIabRjBVckdenvxQLmNzMEs.GetSupermultiUrl(sCode,sIndex)
  (GSplofuUIabRjBVckdenvxQLmNzMEr,GSplofuUIabRjBVckdenvxQLmNzMEK)=GSplofuUIabRjBVckdenvxQLmNzMEs.Baseapi_Parse(GSplofuUIabRjBVckdenvxQLmNzMiC)
  if GSplofuUIabRjBVckdenvxQLmNzMEr=='':return GSplofuUIabRjBVckdenvxQLmNzMig,''
  try:
   GSplofuUIabRjBVckdenvxQLmNzMEK.update(GSplofuUIabRjBVckdenvxQLmNzMEs.GetDefaultParams(login=GSplofuUIabRjBVckdenvxQLmNzMst))
   GSplofuUIabRjBVckdenvxQLmNzMEX=GSplofuUIabRjBVckdenvxQLmNzMEs.callRequestCookies('Get',GSplofuUIabRjBVckdenvxQLmNzMEr,payload=GSplofuUIabRjBVckdenvxQLmNzMsH,params=GSplofuUIabRjBVckdenvxQLmNzMEK,headers=GSplofuUIabRjBVckdenvxQLmNzMsH,cookies=GSplofuUIabRjBVckdenvxQLmNzMsH)
   GSplofuUIabRjBVckdenvxQLmNzMET=json.loads(GSplofuUIabRjBVckdenvxQLmNzMEX.text)
   if not('filter_item_list' in GSplofuUIabRjBVckdenvxQLmNzMET['filter']['filterlist'][0]):return[],''
   GSplofuUIabRjBVckdenvxQLmNzMiw=GSplofuUIabRjBVckdenvxQLmNzMET['filter']['filterlist'][0]['filter_item_list']
   for GSplofuUIabRjBVckdenvxQLmNzMiD in GSplofuUIabRjBVckdenvxQLmNzMiw:
    GSplofuUIabRjBVckdenvxQLmNzMiH={'title':GSplofuUIabRjBVckdenvxQLmNzMiD['title'],'genre':GSplofuUIabRjBVckdenvxQLmNzMiD['api_parameters'][GSplofuUIabRjBVckdenvxQLmNzMiD['api_parameters'].index('=')+1:]}
    GSplofuUIabRjBVckdenvxQLmNzMig.append(GSplofuUIabRjBVckdenvxQLmNzMiH)
  except GSplofuUIabRjBVckdenvxQLmNzMsq as exception:
   GSplofuUIabRjBVckdenvxQLmNzMsO(exception)
   return[],''
  return GSplofuUIabRjBVckdenvxQLmNzMig,GSplofuUIabRjBVckdenvxQLmNzMiC
 def Get_MainCatagory_List(GSplofuUIabRjBVckdenvxQLmNzMEs,sCode,sIndex='0'):
  GSplofuUIabRjBVckdenvxQLmNzMig=[]
  GSplofuUIabRjBVckdenvxQLmNzMiC =GSplofuUIabRjBVckdenvxQLmNzMEs.GetSupermultiUrl(sCode,sIndex)
  (GSplofuUIabRjBVckdenvxQLmNzMEr,GSplofuUIabRjBVckdenvxQLmNzMEK)=GSplofuUIabRjBVckdenvxQLmNzMEs.Baseapi_Parse(GSplofuUIabRjBVckdenvxQLmNzMiC)
  if GSplofuUIabRjBVckdenvxQLmNzMEr=='':return GSplofuUIabRjBVckdenvxQLmNzMig
  try:
   GSplofuUIabRjBVckdenvxQLmNzMEK.update(GSplofuUIabRjBVckdenvxQLmNzMEs.GetDefaultParams(login=GSplofuUIabRjBVckdenvxQLmNzMst))
   GSplofuUIabRjBVckdenvxQLmNzMEX=GSplofuUIabRjBVckdenvxQLmNzMEs.callRequestCookies('Get',GSplofuUIabRjBVckdenvxQLmNzMEr,payload=GSplofuUIabRjBVckdenvxQLmNzMsH,params=GSplofuUIabRjBVckdenvxQLmNzMEK,headers=GSplofuUIabRjBVckdenvxQLmNzMsH,cookies=GSplofuUIabRjBVckdenvxQLmNzMsH)
   GSplofuUIabRjBVckdenvxQLmNzMET=json.loads(GSplofuUIabRjBVckdenvxQLmNzMEX.text)
   if not('celllist' in GSplofuUIabRjBVckdenvxQLmNzMET['band']):return[]
   GSplofuUIabRjBVckdenvxQLmNzMiw=GSplofuUIabRjBVckdenvxQLmNzMET['band']['celllist']
   for GSplofuUIabRjBVckdenvxQLmNzMiD in GSplofuUIabRjBVckdenvxQLmNzMiw:
    GSplofuUIabRjBVckdenvxQLmNzMit =GSplofuUIabRjBVckdenvxQLmNzMiD['event_list'][1]['url']
    (GSplofuUIabRjBVckdenvxQLmNzMiy,GSplofuUIabRjBVckdenvxQLmNzMiJ)=GSplofuUIabRjBVckdenvxQLmNzMEs.Baseapi_Parse(GSplofuUIabRjBVckdenvxQLmNzMit)
    GSplofuUIabRjBVckdenvxQLmNzMiH={'title':GSplofuUIabRjBVckdenvxQLmNzMiD['title_list'][0]['text'],'suburl':GSplofuUIabRjBVckdenvxQLmNzMiy,'subapi':GSplofuUIabRjBVckdenvxQLmNzMiJ.get('api'),'subtype':'catagory' if GSplofuUIabRjBVckdenvxQLmNzMiJ else 'supersection'}
    GSplofuUIabRjBVckdenvxQLmNzMig.append(GSplofuUIabRjBVckdenvxQLmNzMiH)
  except GSplofuUIabRjBVckdenvxQLmNzMsq as exception:
   GSplofuUIabRjBVckdenvxQLmNzMsO(exception)
   return[]
  return GSplofuUIabRjBVckdenvxQLmNzMig
 def Get_SuperMultiSection_List(GSplofuUIabRjBVckdenvxQLmNzMEs,subapi_text):
  GSplofuUIabRjBVckdenvxQLmNzMig=[]
  GSplofuUIabRjBVckdenvxQLmNzMEK={}
  try:
   GSplofuUIabRjBVckdenvxQLmNzMis =urllib.parse.urlsplit(subapi_text)
   if GSplofuUIabRjBVckdenvxQLmNzMis.path.find('apis.wavve.com')>=0: 
    GSplofuUIabRjBVckdenvxQLmNzMEr=GSplofuUIabRjBVckdenvxQLmNzMEs.HTTPTAG+GSplofuUIabRjBVckdenvxQLmNzMis.path 
    GSplofuUIabRjBVckdenvxQLmNzMEK=GSplofuUIabRjBVckdenvxQLmNzMsY(urllib.parse.parse_qsl(GSplofuUIabRjBVckdenvxQLmNzMis.query))
   else:
    GSplofuUIabRjBVckdenvxQLmNzMEr=GSplofuUIabRjBVckdenvxQLmNzMEs.API_DOMAIN+'/cf'+GSplofuUIabRjBVckdenvxQLmNzMis.path 
   GSplofuUIabRjBVckdenvxQLmNzMEr=GSplofuUIabRjBVckdenvxQLmNzMEr.replace('supermultisection/','supermultisections/')
  except GSplofuUIabRjBVckdenvxQLmNzMsq as exception:
   GSplofuUIabRjBVckdenvxQLmNzMsO(exception)
   return[]
  try:
   GSplofuUIabRjBVckdenvxQLmNzMEK.update(GSplofuUIabRjBVckdenvxQLmNzMEs.GetDefaultParams(login=GSplofuUIabRjBVckdenvxQLmNzMst))
   GSplofuUIabRjBVckdenvxQLmNzMEX=GSplofuUIabRjBVckdenvxQLmNzMEs.callRequestCookies('Get',GSplofuUIabRjBVckdenvxQLmNzMEr,payload=GSplofuUIabRjBVckdenvxQLmNzMsH,params=GSplofuUIabRjBVckdenvxQLmNzMsH,headers=GSplofuUIabRjBVckdenvxQLmNzMsH,cookies=GSplofuUIabRjBVckdenvxQLmNzMsH)
   GSplofuUIabRjBVckdenvxQLmNzMET=json.loads(GSplofuUIabRjBVckdenvxQLmNzMEX.text)
   if not('multisectionlist' in GSplofuUIabRjBVckdenvxQLmNzMET):return[]
   GSplofuUIabRjBVckdenvxQLmNzMiw=GSplofuUIabRjBVckdenvxQLmNzMET['multisectionlist']
   for GSplofuUIabRjBVckdenvxQLmNzMiD in GSplofuUIabRjBVckdenvxQLmNzMiw:
    GSplofuUIabRjBVckdenvxQLmNzMiA=GSplofuUIabRjBVckdenvxQLmNzMiD['title']
    if GSplofuUIabRjBVckdenvxQLmNzMsW(GSplofuUIabRjBVckdenvxQLmNzMiA)==0:continue
    if GSplofuUIabRjBVckdenvxQLmNzMiA=='minor':continue
    if re.search(u'베너',GSplofuUIabRjBVckdenvxQLmNzMiA):continue
    if re.search(u'배너',GSplofuUIabRjBVckdenvxQLmNzMiA):continue 
    if GSplofuUIabRjBVckdenvxQLmNzMsW(GSplofuUIabRjBVckdenvxQLmNzMiD['eventlist'])>=3:
     GSplofuUIabRjBVckdenvxQLmNzMiJ =GSplofuUIabRjBVckdenvxQLmNzMiD['eventlist'][2]['url']
    else:
     GSplofuUIabRjBVckdenvxQLmNzMiJ =GSplofuUIabRjBVckdenvxQLmNzMiD['eventlist'][1]['url']
    GSplofuUIabRjBVckdenvxQLmNzMiq=GSplofuUIabRjBVckdenvxQLmNzMiD['cell_type']
    if GSplofuUIabRjBVckdenvxQLmNzMiq=='band_2':
     if GSplofuUIabRjBVckdenvxQLmNzMiJ.find('channellist=')>=0:
      GSplofuUIabRjBVckdenvxQLmNzMiq='band_live'
    GSplofuUIabRjBVckdenvxQLmNzMiH={'title':GSplofuUIabRjBVckdenvxQLmNzMEs.Get_ChangeText(GSplofuUIabRjBVckdenvxQLmNzMiA),'subapi':GSplofuUIabRjBVckdenvxQLmNzMiJ,'cell_type':GSplofuUIabRjBVckdenvxQLmNzMiq}
    GSplofuUIabRjBVckdenvxQLmNzMig.append(GSplofuUIabRjBVckdenvxQLmNzMiH)
  except GSplofuUIabRjBVckdenvxQLmNzMsq as exception:
   GSplofuUIabRjBVckdenvxQLmNzMsO(exception)
   return[]
  return GSplofuUIabRjBVckdenvxQLmNzMig
 def Get_BandLiveSection_List(GSplofuUIabRjBVckdenvxQLmNzMEs,GSplofuUIabRjBVckdenvxQLmNzMiC,page_int=1):
  GSplofuUIabRjBVckdenvxQLmNzMiO=[]
  GSplofuUIabRjBVckdenvxQLmNzMiY=GSplofuUIabRjBVckdenvxQLmNzMFE=1
  GSplofuUIabRjBVckdenvxQLmNzMir=GSplofuUIabRjBVckdenvxQLmNzMst
  try:
   (GSplofuUIabRjBVckdenvxQLmNzMEr,GSplofuUIabRjBVckdenvxQLmNzMEK)=GSplofuUIabRjBVckdenvxQLmNzMEs.Baseapi_Parse(GSplofuUIabRjBVckdenvxQLmNzMiC)
  except GSplofuUIabRjBVckdenvxQLmNzMsq as exception:
   GSplofuUIabRjBVckdenvxQLmNzMsO(exception)
   return[],GSplofuUIabRjBVckdenvxQLmNzMst
  try:
   GSplofuUIabRjBVckdenvxQLmNzMEK['limit']=GSplofuUIabRjBVckdenvxQLmNzMEs.LIST_LIMIT
   GSplofuUIabRjBVckdenvxQLmNzMEK['offset']=GSplofuUIabRjBVckdenvxQLmNzMsA((page_int-1)*GSplofuUIabRjBVckdenvxQLmNzMEs.LIST_LIMIT)
   GSplofuUIabRjBVckdenvxQLmNzMEK.update(GSplofuUIabRjBVckdenvxQLmNzMEs.GetDefaultParams(login=GSplofuUIabRjBVckdenvxQLmNzMst))
   GSplofuUIabRjBVckdenvxQLmNzMEX=GSplofuUIabRjBVckdenvxQLmNzMEs.callRequestCookies('Get',GSplofuUIabRjBVckdenvxQLmNzMEr,payload=GSplofuUIabRjBVckdenvxQLmNzMsH,params=GSplofuUIabRjBVckdenvxQLmNzMEK,headers=GSplofuUIabRjBVckdenvxQLmNzMsH,cookies=GSplofuUIabRjBVckdenvxQLmNzMsH)
   GSplofuUIabRjBVckdenvxQLmNzMET=json.loads(GSplofuUIabRjBVckdenvxQLmNzMEX.text)
   if not('celllist' in GSplofuUIabRjBVckdenvxQLmNzMET['cell_toplist']):return[],GSplofuUIabRjBVckdenvxQLmNzMst
   GSplofuUIabRjBVckdenvxQLmNzMiw=GSplofuUIabRjBVckdenvxQLmNzMET['cell_toplist']['celllist']
   for GSplofuUIabRjBVckdenvxQLmNzMiD in GSplofuUIabRjBVckdenvxQLmNzMiw:
    GSplofuUIabRjBVckdenvxQLmNzMiW =GSplofuUIabRjBVckdenvxQLmNzMiD['event_list'][1]['url']
    GSplofuUIabRjBVckdenvxQLmNzMiX=urllib.parse.urlsplit(GSplofuUIabRjBVckdenvxQLmNzMiW).query
    GSplofuUIabRjBVckdenvxQLmNzMiX=GSplofuUIabRjBVckdenvxQLmNzMsY(urllib.parse.parse_qsl(GSplofuUIabRjBVckdenvxQLmNzMiX))
    GSplofuUIabRjBVckdenvxQLmNzMiT='channelid'
    GSplofuUIabRjBVckdenvxQLmNzMih=GSplofuUIabRjBVckdenvxQLmNzMiX[GSplofuUIabRjBVckdenvxQLmNzMiT]
    GSplofuUIabRjBVckdenvxQLmNzMiH={'studio':GSplofuUIabRjBVckdenvxQLmNzMiD['title_list'][0]['text'],'tvshowtitle':GSplofuUIabRjBVckdenvxQLmNzMEs.Get_ChangeText(GSplofuUIabRjBVckdenvxQLmNzMiD['title_list'][1]['text']),'channelid':GSplofuUIabRjBVckdenvxQLmNzMih,'age':GSplofuUIabRjBVckdenvxQLmNzMiD.get('age'),'thumbnail':'https://%s'%GSplofuUIabRjBVckdenvxQLmNzMiD.get('thumbnail')}
    GSplofuUIabRjBVckdenvxQLmNzMiO.append(GSplofuUIabRjBVckdenvxQLmNzMiH)
   GSplofuUIabRjBVckdenvxQLmNzMiY=GSplofuUIabRjBVckdenvxQLmNzMsr(GSplofuUIabRjBVckdenvxQLmNzMET['cell_toplist']['pagecount'])
   if GSplofuUIabRjBVckdenvxQLmNzMET['cell_toplist']['count']:GSplofuUIabRjBVckdenvxQLmNzMFE =GSplofuUIabRjBVckdenvxQLmNzMsr(GSplofuUIabRjBVckdenvxQLmNzMET['cell_toplist']['count'])
   else:GSplofuUIabRjBVckdenvxQLmNzMFE=GSplofuUIabRjBVckdenvxQLmNzMEs.LIST_LIMIT*page_int
   GSplofuUIabRjBVckdenvxQLmNzMir=GSplofuUIabRjBVckdenvxQLmNzMiY>GSplofuUIabRjBVckdenvxQLmNzMFE
  except GSplofuUIabRjBVckdenvxQLmNzMsq as exception:
   GSplofuUIabRjBVckdenvxQLmNzMsO(exception)
   return[],GSplofuUIabRjBVckdenvxQLmNzMst
  return GSplofuUIabRjBVckdenvxQLmNzMiO,GSplofuUIabRjBVckdenvxQLmNzMir
 def Get_Band2Section_List(GSplofuUIabRjBVckdenvxQLmNzMEs,GSplofuUIabRjBVckdenvxQLmNzMiC,page_int=1):
  GSplofuUIabRjBVckdenvxQLmNzMFi=[]
  GSplofuUIabRjBVckdenvxQLmNzMiY=GSplofuUIabRjBVckdenvxQLmNzMFE=1
  GSplofuUIabRjBVckdenvxQLmNzMir=GSplofuUIabRjBVckdenvxQLmNzMst
  try:
   (GSplofuUIabRjBVckdenvxQLmNzMEr,GSplofuUIabRjBVckdenvxQLmNzMEK)=GSplofuUIabRjBVckdenvxQLmNzMEs.Baseapi_Parse(GSplofuUIabRjBVckdenvxQLmNzMiC)
  except GSplofuUIabRjBVckdenvxQLmNzMsq as exception:
   GSplofuUIabRjBVckdenvxQLmNzMsO(exception)
   return[],GSplofuUIabRjBVckdenvxQLmNzMst
  try:
   GSplofuUIabRjBVckdenvxQLmNzMEK['came'] ='BandView'
   GSplofuUIabRjBVckdenvxQLmNzMEK['limit']=GSplofuUIabRjBVckdenvxQLmNzMEs.LIST_LIMIT
   GSplofuUIabRjBVckdenvxQLmNzMEK['offset']=GSplofuUIabRjBVckdenvxQLmNzMsA((page_int-1)*GSplofuUIabRjBVckdenvxQLmNzMEs.LIST_LIMIT)
   GSplofuUIabRjBVckdenvxQLmNzMEK.update(GSplofuUIabRjBVckdenvxQLmNzMEs.GetDefaultParams(login=GSplofuUIabRjBVckdenvxQLmNzMst))
   GSplofuUIabRjBVckdenvxQLmNzMEX=GSplofuUIabRjBVckdenvxQLmNzMEs.callRequestCookies('Get',GSplofuUIabRjBVckdenvxQLmNzMEr,payload=GSplofuUIabRjBVckdenvxQLmNzMsH,params=GSplofuUIabRjBVckdenvxQLmNzMEK,headers=GSplofuUIabRjBVckdenvxQLmNzMsH,cookies=GSplofuUIabRjBVckdenvxQLmNzMsH)
   GSplofuUIabRjBVckdenvxQLmNzMET=json.loads(GSplofuUIabRjBVckdenvxQLmNzMEX.text)
   if not('celllist' in GSplofuUIabRjBVckdenvxQLmNzMET['cell_toplist']):return[],GSplofuUIabRjBVckdenvxQLmNzMst
   GSplofuUIabRjBVckdenvxQLmNzMiw=GSplofuUIabRjBVckdenvxQLmNzMET['cell_toplist']['celllist']
   for GSplofuUIabRjBVckdenvxQLmNzMiD in GSplofuUIabRjBVckdenvxQLmNzMiw:
    GSplofuUIabRjBVckdenvxQLmNzMiW =GSplofuUIabRjBVckdenvxQLmNzMiD['event_list'][1]['url']
    GSplofuUIabRjBVckdenvxQLmNzMiX=urllib.parse.urlsplit(GSplofuUIabRjBVckdenvxQLmNzMiW).query
    GSplofuUIabRjBVckdenvxQLmNzMiX=GSplofuUIabRjBVckdenvxQLmNzMsY(urllib.parse.parse_qsl(GSplofuUIabRjBVckdenvxQLmNzMiX))
    GSplofuUIabRjBVckdenvxQLmNzMiT='contentid'
    GSplofuUIabRjBVckdenvxQLmNzMih=GSplofuUIabRjBVckdenvxQLmNzMiX[GSplofuUIabRjBVckdenvxQLmNzMiT]
    GSplofuUIabRjBVckdenvxQLmNzMiH={'programtitle':GSplofuUIabRjBVckdenvxQLmNzMiD['title_list'][0]['text'],'episodetitle':GSplofuUIabRjBVckdenvxQLmNzMEs.Get_ChangeText(GSplofuUIabRjBVckdenvxQLmNzMiD['title_list'][1]['text']),'age':GSplofuUIabRjBVckdenvxQLmNzMiD.get('age'),'thumbnail':GSplofuUIabRjBVckdenvxQLmNzMEs.HTTPTAG+GSplofuUIabRjBVckdenvxQLmNzMiD.get('thumbnail'),'vidtype':GSplofuUIabRjBVckdenvxQLmNzMiT,'videoid':GSplofuUIabRjBVckdenvxQLmNzMih}
    GSplofuUIabRjBVckdenvxQLmNzMFi.append(GSplofuUIabRjBVckdenvxQLmNzMiH)
   GSplofuUIabRjBVckdenvxQLmNzMiY=GSplofuUIabRjBVckdenvxQLmNzMsr(GSplofuUIabRjBVckdenvxQLmNzMET['cell_toplist']['pagecount'])
   if GSplofuUIabRjBVckdenvxQLmNzMET['cell_toplist']['count']:GSplofuUIabRjBVckdenvxQLmNzMFE =GSplofuUIabRjBVckdenvxQLmNzMsr(GSplofuUIabRjBVckdenvxQLmNzMET['cell_toplist']['count'])
   else:GSplofuUIabRjBVckdenvxQLmNzMFE=GSplofuUIabRjBVckdenvxQLmNzMEs.LIST_LIMIT*page_int
   GSplofuUIabRjBVckdenvxQLmNzMir=GSplofuUIabRjBVckdenvxQLmNzMiY>GSplofuUIabRjBVckdenvxQLmNzMFE
  except GSplofuUIabRjBVckdenvxQLmNzMsq as exception:
   GSplofuUIabRjBVckdenvxQLmNzMsO(exception)
   return[],GSplofuUIabRjBVckdenvxQLmNzMst
  return GSplofuUIabRjBVckdenvxQLmNzMFi,GSplofuUIabRjBVckdenvxQLmNzMir
 def Get_Program_List(GSplofuUIabRjBVckdenvxQLmNzMEs,GSplofuUIabRjBVckdenvxQLmNzMiC,page_int=1,orderby='-'):
  GSplofuUIabRjBVckdenvxQLmNzMFs=[]
  GSplofuUIabRjBVckdenvxQLmNzMiY=GSplofuUIabRjBVckdenvxQLmNzMFE=1
  GSplofuUIabRjBVckdenvxQLmNzMir=GSplofuUIabRjBVckdenvxQLmNzMst
  (GSplofuUIabRjBVckdenvxQLmNzMEr,GSplofuUIabRjBVckdenvxQLmNzMEK)=GSplofuUIabRjBVckdenvxQLmNzMEs.Baseapi_Parse(GSplofuUIabRjBVckdenvxQLmNzMiC)
  if GSplofuUIabRjBVckdenvxQLmNzMEr=='':return GSplofuUIabRjBVckdenvxQLmNzMFs,GSplofuUIabRjBVckdenvxQLmNzMir
  try:
   GSplofuUIabRjBVckdenvxQLmNzMEK['limit'] =GSplofuUIabRjBVckdenvxQLmNzMEs.LIST_LIMIT
   GSplofuUIabRjBVckdenvxQLmNzMEK['offset']=GSplofuUIabRjBVckdenvxQLmNzMsA((page_int-1)*GSplofuUIabRjBVckdenvxQLmNzMEs.LIST_LIMIT)
   GSplofuUIabRjBVckdenvxQLmNzMEK['page'] =GSplofuUIabRjBVckdenvxQLmNzMsA(page_int)
   if GSplofuUIabRjBVckdenvxQLmNzMEK.get('orderby')!='' and GSplofuUIabRjBVckdenvxQLmNzMEK.get('orderby')!='regdatefirst' and orderby!='-':
    GSplofuUIabRjBVckdenvxQLmNzMEK['orderby']=orderby 
   GSplofuUIabRjBVckdenvxQLmNzMEK.update(GSplofuUIabRjBVckdenvxQLmNzMEs.GetDefaultParams(login=GSplofuUIabRjBVckdenvxQLmNzMst))
   GSplofuUIabRjBVckdenvxQLmNzMEX=GSplofuUIabRjBVckdenvxQLmNzMEs.callRequestCookies('Get',GSplofuUIabRjBVckdenvxQLmNzMEr,payload=GSplofuUIabRjBVckdenvxQLmNzMsH,params=GSplofuUIabRjBVckdenvxQLmNzMEK,headers=GSplofuUIabRjBVckdenvxQLmNzMsH,cookies=GSplofuUIabRjBVckdenvxQLmNzMsH)
   GSplofuUIabRjBVckdenvxQLmNzMET=json.loads(GSplofuUIabRjBVckdenvxQLmNzMEX.text)
   if GSplofuUIabRjBVckdenvxQLmNzMiC.find('instantplay')>=0:
    if not('celllist' in GSplofuUIabRjBVckdenvxQLmNzMET['band']):return GSplofuUIabRjBVckdenvxQLmNzMFs,GSplofuUIabRjBVckdenvxQLmNzMir
    GSplofuUIabRjBVckdenvxQLmNzMiw=GSplofuUIabRjBVckdenvxQLmNzMET['band']['celllist']
   else:
    if not('celllist' in GSplofuUIabRjBVckdenvxQLmNzMET['cell_toplist']):return GSplofuUIabRjBVckdenvxQLmNzMFs,GSplofuUIabRjBVckdenvxQLmNzMir
    GSplofuUIabRjBVckdenvxQLmNzMiw=GSplofuUIabRjBVckdenvxQLmNzMET['cell_toplist']['celllist']
   for GSplofuUIabRjBVckdenvxQLmNzMiD in GSplofuUIabRjBVckdenvxQLmNzMiw:
    for GSplofuUIabRjBVckdenvxQLmNzMFP in GSplofuUIabRjBVckdenvxQLmNzMiD['event_list']:
     if GSplofuUIabRjBVckdenvxQLmNzMFP.get('type')=='on-navigation':
      GSplofuUIabRjBVckdenvxQLmNzMiW =GSplofuUIabRjBVckdenvxQLmNzMFP['url']
    GSplofuUIabRjBVckdenvxQLmNzMiX=urllib.parse.urlsplit(GSplofuUIabRjBVckdenvxQLmNzMiW).query
    GSplofuUIabRjBVckdenvxQLmNzMiT=GSplofuUIabRjBVckdenvxQLmNzMiX[0:GSplofuUIabRjBVckdenvxQLmNzMiX.find('=')]
    GSplofuUIabRjBVckdenvxQLmNzMih=GSplofuUIabRjBVckdenvxQLmNzMiX[GSplofuUIabRjBVckdenvxQLmNzMiX.find('=')+1:]
    GSplofuUIabRjBVckdenvxQLmNzMiH={'title':GSplofuUIabRjBVckdenvxQLmNzMiD['title_list'][0]['text'],'age':GSplofuUIabRjBVckdenvxQLmNzMiD['age'],'thumbnail':'https://%s'%GSplofuUIabRjBVckdenvxQLmNzMiD.get('thumbnail'),'videoid':GSplofuUIabRjBVckdenvxQLmNzMih,'vidtype':GSplofuUIabRjBVckdenvxQLmNzMiT}
    GSplofuUIabRjBVckdenvxQLmNzMFs.append(GSplofuUIabRjBVckdenvxQLmNzMiH)
   if GSplofuUIabRjBVckdenvxQLmNzMiC.find('instantplay')<0:
    GSplofuUIabRjBVckdenvxQLmNzMiY=GSplofuUIabRjBVckdenvxQLmNzMsr(GSplofuUIabRjBVckdenvxQLmNzMET['cell_toplist']['pagecount'])
    if GSplofuUIabRjBVckdenvxQLmNzMET['cell_toplist']['count']:GSplofuUIabRjBVckdenvxQLmNzMFE =GSplofuUIabRjBVckdenvxQLmNzMsr(GSplofuUIabRjBVckdenvxQLmNzMET['cell_toplist']['count'])
    else:GSplofuUIabRjBVckdenvxQLmNzMFE=GSplofuUIabRjBVckdenvxQLmNzMEs.LIST_LIMIT*page_int
    GSplofuUIabRjBVckdenvxQLmNzMir=GSplofuUIabRjBVckdenvxQLmNzMiY>GSplofuUIabRjBVckdenvxQLmNzMFE
  except GSplofuUIabRjBVckdenvxQLmNzMsq as exception:
   GSplofuUIabRjBVckdenvxQLmNzMsO(exception)
   return[],GSplofuUIabRjBVckdenvxQLmNzMst
  return GSplofuUIabRjBVckdenvxQLmNzMFs,GSplofuUIabRjBVckdenvxQLmNzMir
 def Get_Movie_List(GSplofuUIabRjBVckdenvxQLmNzMEs,GSplofuUIabRjBVckdenvxQLmNzMiC,page_int=1):
  GSplofuUIabRjBVckdenvxQLmNzMFg=[]
  GSplofuUIabRjBVckdenvxQLmNzMiY=GSplofuUIabRjBVckdenvxQLmNzMFE=1
  GSplofuUIabRjBVckdenvxQLmNzMir=GSplofuUIabRjBVckdenvxQLmNzMst
  (GSplofuUIabRjBVckdenvxQLmNzMEr,GSplofuUIabRjBVckdenvxQLmNzMEK)=GSplofuUIabRjBVckdenvxQLmNzMEs.Baseapi_Parse(GSplofuUIabRjBVckdenvxQLmNzMiC)
  if GSplofuUIabRjBVckdenvxQLmNzMEr=='':return GSplofuUIabRjBVckdenvxQLmNzMFg,GSplofuUIabRjBVckdenvxQLmNzMir
  try:
   GSplofuUIabRjBVckdenvxQLmNzMEK['limit']=GSplofuUIabRjBVckdenvxQLmNzMEs.MV_LIMIT
   GSplofuUIabRjBVckdenvxQLmNzMEK['offset']=GSplofuUIabRjBVckdenvxQLmNzMsA((page_int-1)*GSplofuUIabRjBVckdenvxQLmNzMEs.MV_LIMIT)
   GSplofuUIabRjBVckdenvxQLmNzMEK.update(GSplofuUIabRjBVckdenvxQLmNzMEs.GetDefaultParams(login=GSplofuUIabRjBVckdenvxQLmNzMst))
   GSplofuUIabRjBVckdenvxQLmNzMEX=GSplofuUIabRjBVckdenvxQLmNzMEs.callRequestCookies('Get',GSplofuUIabRjBVckdenvxQLmNzMEr,payload=GSplofuUIabRjBVckdenvxQLmNzMsH,params=GSplofuUIabRjBVckdenvxQLmNzMEK,headers=GSplofuUIabRjBVckdenvxQLmNzMsH,cookies=GSplofuUIabRjBVckdenvxQLmNzMsH)
   GSplofuUIabRjBVckdenvxQLmNzMET=json.loads(GSplofuUIabRjBVckdenvxQLmNzMEX.text)
   if not('celllist' in GSplofuUIabRjBVckdenvxQLmNzMET['cell_toplist']):return GSplofuUIabRjBVckdenvxQLmNzMFg,GSplofuUIabRjBVckdenvxQLmNzMir
   GSplofuUIabRjBVckdenvxQLmNzMiw=GSplofuUIabRjBVckdenvxQLmNzMET['cell_toplist']['celllist']
   for GSplofuUIabRjBVckdenvxQLmNzMiD in GSplofuUIabRjBVckdenvxQLmNzMiw:
    GSplofuUIabRjBVckdenvxQLmNzMiW =GSplofuUIabRjBVckdenvxQLmNzMiD['event_list'][1]['url']
    GSplofuUIabRjBVckdenvxQLmNzMiX=urllib.parse.urlsplit(GSplofuUIabRjBVckdenvxQLmNzMiW).query
    GSplofuUIabRjBVckdenvxQLmNzMiT=GSplofuUIabRjBVckdenvxQLmNzMiX[0:GSplofuUIabRjBVckdenvxQLmNzMiX.find('=')]
    GSplofuUIabRjBVckdenvxQLmNzMih=GSplofuUIabRjBVckdenvxQLmNzMiX[GSplofuUIabRjBVckdenvxQLmNzMiX.find('=')+1:]
    GSplofuUIabRjBVckdenvxQLmNzMiH={'title':GSplofuUIabRjBVckdenvxQLmNzMiD['title_list'][0]['text'],'age':GSplofuUIabRjBVckdenvxQLmNzMiD['age'],'thumbnail':'https://%s'%GSplofuUIabRjBVckdenvxQLmNzMiD.get('thumbnail'),'videoid':GSplofuUIabRjBVckdenvxQLmNzMih,'vidtype':GSplofuUIabRjBVckdenvxQLmNzMiT}
    GSplofuUIabRjBVckdenvxQLmNzMFg.append(GSplofuUIabRjBVckdenvxQLmNzMiH)
   GSplofuUIabRjBVckdenvxQLmNzMiY=GSplofuUIabRjBVckdenvxQLmNzMsr(GSplofuUIabRjBVckdenvxQLmNzMET['cell_toplist']['pagecount'])
   if GSplofuUIabRjBVckdenvxQLmNzMET['cell_toplist']['count']:GSplofuUIabRjBVckdenvxQLmNzMFE =GSplofuUIabRjBVckdenvxQLmNzMsr(GSplofuUIabRjBVckdenvxQLmNzMET['cell_toplist']['count'])
   else:GSplofuUIabRjBVckdenvxQLmNzMFE=GSplofuUIabRjBVckdenvxQLmNzMEs.MV_LIMIT*page_int
   GSplofuUIabRjBVckdenvxQLmNzMir=GSplofuUIabRjBVckdenvxQLmNzMiY>GSplofuUIabRjBVckdenvxQLmNzMFE
  except GSplofuUIabRjBVckdenvxQLmNzMsq as exception:
   GSplofuUIabRjBVckdenvxQLmNzMsO(exception)
   return[],GSplofuUIabRjBVckdenvxQLmNzMst
  return GSplofuUIabRjBVckdenvxQLmNzMFg,GSplofuUIabRjBVckdenvxQLmNzMir
 def ChangeToProgramid(GSplofuUIabRjBVckdenvxQLmNzMEs,GSplofuUIabRjBVckdenvxQLmNzMFr):
  GSplofuUIabRjBVckdenvxQLmNzMFC=''
  try:
   GSplofuUIabRjBVckdenvxQLmNzMEr =GSplofuUIabRjBVckdenvxQLmNzMEs.API_DOMAIN+'/cf/vod/contents/'+GSplofuUIabRjBVckdenvxQLmNzMFr
   GSplofuUIabRjBVckdenvxQLmNzMEK=GSplofuUIabRjBVckdenvxQLmNzMEs.GetDefaultParams(login=GSplofuUIabRjBVckdenvxQLmNzMst)
   GSplofuUIabRjBVckdenvxQLmNzMEX=GSplofuUIabRjBVckdenvxQLmNzMEs.callRequestCookies('Get',GSplofuUIabRjBVckdenvxQLmNzMEr,payload=GSplofuUIabRjBVckdenvxQLmNzMsH,params=GSplofuUIabRjBVckdenvxQLmNzMEK,headers=GSplofuUIabRjBVckdenvxQLmNzMsH,cookies=GSplofuUIabRjBVckdenvxQLmNzMsH)
   GSplofuUIabRjBVckdenvxQLmNzMFK=json.loads(GSplofuUIabRjBVckdenvxQLmNzMEX.text)
   if not('programid' in GSplofuUIabRjBVckdenvxQLmNzMFK):return GSplofuUIabRjBVckdenvxQLmNzMFC 
   GSplofuUIabRjBVckdenvxQLmNzMFC=GSplofuUIabRjBVckdenvxQLmNzMFK['programid']
  except GSplofuUIabRjBVckdenvxQLmNzMsq as exception:
   GSplofuUIabRjBVckdenvxQLmNzMsO(exception)
  return GSplofuUIabRjBVckdenvxQLmNzMFC
 def Get_Episode_List(GSplofuUIabRjBVckdenvxQLmNzMEs,GSplofuUIabRjBVckdenvxQLmNzMih,GSplofuUIabRjBVckdenvxQLmNzMiT,page_int=1,orderby='desc'):
  GSplofuUIabRjBVckdenvxQLmNzMFw=[]
  GSplofuUIabRjBVckdenvxQLmNzMiY=GSplofuUIabRjBVckdenvxQLmNzMFE=1
  GSplofuUIabRjBVckdenvxQLmNzMir=GSplofuUIabRjBVckdenvxQLmNzMst
  if GSplofuUIabRjBVckdenvxQLmNzMiT=='contentid':
   GSplofuUIabRjBVckdenvxQLmNzMFC=GSplofuUIabRjBVckdenvxQLmNzMEs.ChangeToProgramid(GSplofuUIabRjBVckdenvxQLmNzMih)
  else:
   GSplofuUIabRjBVckdenvxQLmNzMFC=GSplofuUIabRjBVckdenvxQLmNzMih
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   GSplofuUIabRjBVckdenvxQLmNzMEr=GSplofuUIabRjBVckdenvxQLmNzMEs.API_DOMAIN+'/vod/programs-contents/'+GSplofuUIabRjBVckdenvxQLmNzMFC
   GSplofuUIabRjBVckdenvxQLmNzMEK={}
   GSplofuUIabRjBVckdenvxQLmNzMEK['limit'] =GSplofuUIabRjBVckdenvxQLmNzMEs.EP_LIMIT
   GSplofuUIabRjBVckdenvxQLmNzMEK['offset']=GSplofuUIabRjBVckdenvxQLmNzMsA((page_int-1)*GSplofuUIabRjBVckdenvxQLmNzMEs.EP_LIMIT)
   GSplofuUIabRjBVckdenvxQLmNzMEK['orderby']=orderby 
   GSplofuUIabRjBVckdenvxQLmNzMEK.update(GSplofuUIabRjBVckdenvxQLmNzMEs.GetDefaultParams(login=GSplofuUIabRjBVckdenvxQLmNzMst))
   GSplofuUIabRjBVckdenvxQLmNzMEX=GSplofuUIabRjBVckdenvxQLmNzMEs.callRequestCookies('Get',GSplofuUIabRjBVckdenvxQLmNzMEr,payload=GSplofuUIabRjBVckdenvxQLmNzMsH,params=GSplofuUIabRjBVckdenvxQLmNzMEK,headers=GSplofuUIabRjBVckdenvxQLmNzMsH,cookies=GSplofuUIabRjBVckdenvxQLmNzMsH)
   GSplofuUIabRjBVckdenvxQLmNzMET=json.loads(GSplofuUIabRjBVckdenvxQLmNzMEX.text)
   GSplofuUIabRjBVckdenvxQLmNzMiw=GSplofuUIabRjBVckdenvxQLmNzMET['list']
   for GSplofuUIabRjBVckdenvxQLmNzMiD in GSplofuUIabRjBVckdenvxQLmNzMiw:
    GSplofuUIabRjBVckdenvxQLmNzMFH=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',GSplofuUIabRjBVckdenvxQLmNzMiD.get('synopsis'))
    GSplofuUIabRjBVckdenvxQLmNzMiH={'programtitle':GSplofuUIabRjBVckdenvxQLmNzMiD.get('programtitle'),'episodetitle':GSplofuUIabRjBVckdenvxQLmNzMiD.get('episodetitle'),'episodenumber':GSplofuUIabRjBVckdenvxQLmNzMiD.get('episodenumber'),'releasedate':GSplofuUIabRjBVckdenvxQLmNzMiD.get('releasedate'),'releaseweekday':GSplofuUIabRjBVckdenvxQLmNzMiD.get('releaseweekday'),'programid':GSplofuUIabRjBVckdenvxQLmNzMiD.get('programid'),'contentid':GSplofuUIabRjBVckdenvxQLmNzMiD.get('contentid'),'age':GSplofuUIabRjBVckdenvxQLmNzMiD.get('targetage'),'playtime':GSplofuUIabRjBVckdenvxQLmNzMiD.get('playtime'),'synopsis':GSplofuUIabRjBVckdenvxQLmNzMFH,'episodeactors':GSplofuUIabRjBVckdenvxQLmNzMiD.get('episodeactors').split(','),'thumbnail':GSplofuUIabRjBVckdenvxQLmNzMEs.HTTPTAG+GSplofuUIabRjBVckdenvxQLmNzMiD.get('image')}
    GSplofuUIabRjBVckdenvxQLmNzMFw.append(GSplofuUIabRjBVckdenvxQLmNzMiH)
   GSplofuUIabRjBVckdenvxQLmNzMiY=GSplofuUIabRjBVckdenvxQLmNzMsr(GSplofuUIabRjBVckdenvxQLmNzMET['pagecount'])
   if GSplofuUIabRjBVckdenvxQLmNzMET['count']:GSplofuUIabRjBVckdenvxQLmNzMFE =GSplofuUIabRjBVckdenvxQLmNzMsr(GSplofuUIabRjBVckdenvxQLmNzMET['count'])
   else:GSplofuUIabRjBVckdenvxQLmNzMFE=GSplofuUIabRjBVckdenvxQLmNzMEs.EP_LIMIT*page_int
   GSplofuUIabRjBVckdenvxQLmNzMir=GSplofuUIabRjBVckdenvxQLmNzMiY>GSplofuUIabRjBVckdenvxQLmNzMFE
  except GSplofuUIabRjBVckdenvxQLmNzMsq as exception:
   GSplofuUIabRjBVckdenvxQLmNzMsO(exception)
   return[],GSplofuUIabRjBVckdenvxQLmNzMst
  return GSplofuUIabRjBVckdenvxQLmNzMFw,GSplofuUIabRjBVckdenvxQLmNzMir
 def GetEPGList(GSplofuUIabRjBVckdenvxQLmNzMEs,genre):
  GSplofuUIabRjBVckdenvxQLmNzMFt={}
  try:
   GSplofuUIabRjBVckdenvxQLmNzMFy=GSplofuUIabRjBVckdenvxQLmNzMEs.Get_Now_Datetime()
   if genre=='all':
    GSplofuUIabRjBVckdenvxQLmNzMFJ =GSplofuUIabRjBVckdenvxQLmNzMFy+datetime.timedelta(hours=3)
   else:
    GSplofuUIabRjBVckdenvxQLmNzMFJ =GSplofuUIabRjBVckdenvxQLmNzMFy+datetime.timedelta(hours=3)
   GSplofuUIabRjBVckdenvxQLmNzMEr=GSplofuUIabRjBVckdenvxQLmNzMEs.API_DOMAIN+'/live/epgs'
   GSplofuUIabRjBVckdenvxQLmNzMEK={'limit':'100','offset':'0','genre':genre,'startdatetime':GSplofuUIabRjBVckdenvxQLmNzMFy.strftime('%Y-%m-%d %H:00'),'enddatetime':GSplofuUIabRjBVckdenvxQLmNzMFJ.strftime('%Y-%m-%d %H:00')}
   GSplofuUIabRjBVckdenvxQLmNzMEK.update(GSplofuUIabRjBVckdenvxQLmNzMEs.GetDefaultParams(login=GSplofuUIabRjBVckdenvxQLmNzMst))
   GSplofuUIabRjBVckdenvxQLmNzMEX=GSplofuUIabRjBVckdenvxQLmNzMEs.callRequestCookies('Get',GSplofuUIabRjBVckdenvxQLmNzMEr,payload=GSplofuUIabRjBVckdenvxQLmNzMsH,params=GSplofuUIabRjBVckdenvxQLmNzMEK,headers=GSplofuUIabRjBVckdenvxQLmNzMsH,cookies=GSplofuUIabRjBVckdenvxQLmNzMsH)
   GSplofuUIabRjBVckdenvxQLmNzMET=json.loads(GSplofuUIabRjBVckdenvxQLmNzMEX.text)
   GSplofuUIabRjBVckdenvxQLmNzMFA=GSplofuUIabRjBVckdenvxQLmNzMET['list']
   for GSplofuUIabRjBVckdenvxQLmNzMiD in GSplofuUIabRjBVckdenvxQLmNzMFA:
    GSplofuUIabRjBVckdenvxQLmNzMFq=''
    for GSplofuUIabRjBVckdenvxQLmNzMFO in GSplofuUIabRjBVckdenvxQLmNzMiD['list']:
     if GSplofuUIabRjBVckdenvxQLmNzMFq:GSplofuUIabRjBVckdenvxQLmNzMFq+='\n'
     GSplofuUIabRjBVckdenvxQLmNzMFq+=GSplofuUIabRjBVckdenvxQLmNzMEs.Get_ChangeText(GSplofuUIabRjBVckdenvxQLmNzMFO['title'])+'\n'
     GSplofuUIabRjBVckdenvxQLmNzMFq+=' [%s ~ %s]'%(GSplofuUIabRjBVckdenvxQLmNzMFO['starttime'][-5:],GSplofuUIabRjBVckdenvxQLmNzMFO['endtime'][-5:])+'\n'
    GSplofuUIabRjBVckdenvxQLmNzMFt[GSplofuUIabRjBVckdenvxQLmNzMiD['channelid']]=GSplofuUIabRjBVckdenvxQLmNzMFq
  except GSplofuUIabRjBVckdenvxQLmNzMsq as exception:
   GSplofuUIabRjBVckdenvxQLmNzMsO(exception)
  return GSplofuUIabRjBVckdenvxQLmNzMFt
 def Get_LiveChannel_List(GSplofuUIabRjBVckdenvxQLmNzMEs,genre,GSplofuUIabRjBVckdenvxQLmNzMiC):
  GSplofuUIabRjBVckdenvxQLmNzMiO=[]
  (GSplofuUIabRjBVckdenvxQLmNzMEr,GSplofuUIabRjBVckdenvxQLmNzMEK)=GSplofuUIabRjBVckdenvxQLmNzMEs.Baseapi_Parse(GSplofuUIabRjBVckdenvxQLmNzMiC)
  if GSplofuUIabRjBVckdenvxQLmNzMEr=='':return GSplofuUIabRjBVckdenvxQLmNzMiO
  GSplofuUIabRjBVckdenvxQLmNzMFY=GSplofuUIabRjBVckdenvxQLmNzMEs.GetEPGList(genre)
  try:
   GSplofuUIabRjBVckdenvxQLmNzMEK.update(GSplofuUIabRjBVckdenvxQLmNzMEs.GetDefaultParams(login=GSplofuUIabRjBVckdenvxQLmNzMst))
   GSplofuUIabRjBVckdenvxQLmNzMEK['genre']=genre
   GSplofuUIabRjBVckdenvxQLmNzMEX=GSplofuUIabRjBVckdenvxQLmNzMEs.callRequestCookies('Get',GSplofuUIabRjBVckdenvxQLmNzMEr,payload=GSplofuUIabRjBVckdenvxQLmNzMsH,params=GSplofuUIabRjBVckdenvxQLmNzMEK,headers=GSplofuUIabRjBVckdenvxQLmNzMsH,cookies=GSplofuUIabRjBVckdenvxQLmNzMsH)
   GSplofuUIabRjBVckdenvxQLmNzMET=json.loads(GSplofuUIabRjBVckdenvxQLmNzMEX.text)
   if not('celllist' in GSplofuUIabRjBVckdenvxQLmNzMET['cell_toplist']):return[]
   GSplofuUIabRjBVckdenvxQLmNzMiw=GSplofuUIabRjBVckdenvxQLmNzMET['cell_toplist']['celllist']
   for GSplofuUIabRjBVckdenvxQLmNzMiD in GSplofuUIabRjBVckdenvxQLmNzMiw:
    GSplofuUIabRjBVckdenvxQLmNzMFr=GSplofuUIabRjBVckdenvxQLmNzMiD['contentid']
    if GSplofuUIabRjBVckdenvxQLmNzMFr in GSplofuUIabRjBVckdenvxQLmNzMFY:
     GSplofuUIabRjBVckdenvxQLmNzMFW=GSplofuUIabRjBVckdenvxQLmNzMFY[GSplofuUIabRjBVckdenvxQLmNzMFr]
    else:
     GSplofuUIabRjBVckdenvxQLmNzMFW=''
    GSplofuUIabRjBVckdenvxQLmNzMiH={'studio':GSplofuUIabRjBVckdenvxQLmNzMiD['title_list'][0]['text'],'tvshowtitle':GSplofuUIabRjBVckdenvxQLmNzMEs.Get_ChangeText(GSplofuUIabRjBVckdenvxQLmNzMiD['title_list'][1]['text']),'channelid':GSplofuUIabRjBVckdenvxQLmNzMFr,'age':GSplofuUIabRjBVckdenvxQLmNzMiD['age'],'thumbnail':'https://%s'%GSplofuUIabRjBVckdenvxQLmNzMiD.get('thumbnail'),'epg':GSplofuUIabRjBVckdenvxQLmNzMFW}
    GSplofuUIabRjBVckdenvxQLmNzMiO.append(GSplofuUIabRjBVckdenvxQLmNzMiH)
  except GSplofuUIabRjBVckdenvxQLmNzMsq as exception:
   GSplofuUIabRjBVckdenvxQLmNzMsO(exception)
   return[]
  return GSplofuUIabRjBVckdenvxQLmNzMiO
 def Get_Search_List(GSplofuUIabRjBVckdenvxQLmNzMEs,search_key,sType,page_int,exclusion21=GSplofuUIabRjBVckdenvxQLmNzMst):
  GSplofuUIabRjBVckdenvxQLmNzMFX=[]
  GSplofuUIabRjBVckdenvxQLmNzMiY=GSplofuUIabRjBVckdenvxQLmNzMFE=1
  GSplofuUIabRjBVckdenvxQLmNzMir=GSplofuUIabRjBVckdenvxQLmNzMst
  try:
   GSplofuUIabRjBVckdenvxQLmNzMEr=GSplofuUIabRjBVckdenvxQLmNzMEs.API_DOMAIN+'/cf/search/list.js'
   GSplofuUIabRjBVckdenvxQLmNzMEK={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':GSplofuUIabRjBVckdenvxQLmNzMsA((page_int-1)*GSplofuUIabRjBVckdenvxQLmNzMEs.LIST_LIMIT),'limit':GSplofuUIabRjBVckdenvxQLmNzMEs.LIST_LIMIT,'orderby':'score'}
   GSplofuUIabRjBVckdenvxQLmNzMEK.update(GSplofuUIabRjBVckdenvxQLmNzMEs.GetDefaultParams(login=GSplofuUIabRjBVckdenvxQLmNzMst))
   GSplofuUIabRjBVckdenvxQLmNzMEX=GSplofuUIabRjBVckdenvxQLmNzMEs.callRequestCookies('Get',GSplofuUIabRjBVckdenvxQLmNzMEr,payload=GSplofuUIabRjBVckdenvxQLmNzMsH,params=GSplofuUIabRjBVckdenvxQLmNzMEK,headers=GSplofuUIabRjBVckdenvxQLmNzMsH,cookies=GSplofuUIabRjBVckdenvxQLmNzMsH)
   GSplofuUIabRjBVckdenvxQLmNzMFK=json.loads(GSplofuUIabRjBVckdenvxQLmNzMEX.text)
   if not('celllist' in GSplofuUIabRjBVckdenvxQLmNzMFK['cell_toplist']):return GSplofuUIabRjBVckdenvxQLmNzMFX,GSplofuUIabRjBVckdenvxQLmNzMir
   GSplofuUIabRjBVckdenvxQLmNzMiw=GSplofuUIabRjBVckdenvxQLmNzMFK['cell_toplist']['celllist']
   for GSplofuUIabRjBVckdenvxQLmNzMiD in GSplofuUIabRjBVckdenvxQLmNzMiw:
    GSplofuUIabRjBVckdenvxQLmNzMiW =GSplofuUIabRjBVckdenvxQLmNzMiD['event_list'][1]['url']
    GSplofuUIabRjBVckdenvxQLmNzMiX=urllib.parse.urlsplit(GSplofuUIabRjBVckdenvxQLmNzMiW).query
    GSplofuUIabRjBVckdenvxQLmNzMiT=GSplofuUIabRjBVckdenvxQLmNzMiX[0:GSplofuUIabRjBVckdenvxQLmNzMiX.find('=')]
    GSplofuUIabRjBVckdenvxQLmNzMih=GSplofuUIabRjBVckdenvxQLmNzMiX[GSplofuUIabRjBVckdenvxQLmNzMiX.find('=')+1:]
    GSplofuUIabRjBVckdenvxQLmNzMiH={'title':GSplofuUIabRjBVckdenvxQLmNzMiD['title_list'][0]['text'],'age':GSplofuUIabRjBVckdenvxQLmNzMiD['age'],'thumbnail':'https://%s'%GSplofuUIabRjBVckdenvxQLmNzMiD.get('thumbnail'),'videoid':GSplofuUIabRjBVckdenvxQLmNzMih,'vidtype':GSplofuUIabRjBVckdenvxQLmNzMiT}
    if exclusion21==GSplofuUIabRjBVckdenvxQLmNzMst or GSplofuUIabRjBVckdenvxQLmNzMiD.get('age')!='21':
     GSplofuUIabRjBVckdenvxQLmNzMFX.append(GSplofuUIabRjBVckdenvxQLmNzMiH)
   GSplofuUIabRjBVckdenvxQLmNzMiY=GSplofuUIabRjBVckdenvxQLmNzMsr(GSplofuUIabRjBVckdenvxQLmNzMFK['cell_toplist']['pagecount'])
   if GSplofuUIabRjBVckdenvxQLmNzMFK['cell_toplist']['count']:GSplofuUIabRjBVckdenvxQLmNzMFE =GSplofuUIabRjBVckdenvxQLmNzMsr(GSplofuUIabRjBVckdenvxQLmNzMFK['cell_toplist']['count'])
   else:GSplofuUIabRjBVckdenvxQLmNzMFE=GSplofuUIabRjBVckdenvxQLmNzMEs.LIST_LIMIT
   GSplofuUIabRjBVckdenvxQLmNzMir=GSplofuUIabRjBVckdenvxQLmNzMiY>GSplofuUIabRjBVckdenvxQLmNzMFE
  except GSplofuUIabRjBVckdenvxQLmNzMsq as exception:
   GSplofuUIabRjBVckdenvxQLmNzMsO(exception)
  return GSplofuUIabRjBVckdenvxQLmNzMFX,GSplofuUIabRjBVckdenvxQLmNzMir 
 def GetStreamingURL(GSplofuUIabRjBVckdenvxQLmNzMEs,mode,GSplofuUIabRjBVckdenvxQLmNzMFr,quality_int,pvrmode='-'):
  GSplofuUIabRjBVckdenvxQLmNzMFT=GSplofuUIabRjBVckdenvxQLmNzMsK=GSplofuUIabRjBVckdenvxQLmNzMsw=streaming_preview=''
  GSplofuUIabRjBVckdenvxQLmNzMFh=[]
  GSplofuUIabRjBVckdenvxQLmNzMsE='hls'
  if mode=='LIVE':
   GSplofuUIabRjBVckdenvxQLmNzMEr =GSplofuUIabRjBVckdenvxQLmNzMEs.API_DOMAIN+'/live/channels/'+GSplofuUIabRjBVckdenvxQLmNzMFr
   GSplofuUIabRjBVckdenvxQLmNzMsi='live'
  elif mode=='VOD':
   GSplofuUIabRjBVckdenvxQLmNzMEr =GSplofuUIabRjBVckdenvxQLmNzMEs.API_DOMAIN+'/cf/vod/contents/'+GSplofuUIabRjBVckdenvxQLmNzMFr
   GSplofuUIabRjBVckdenvxQLmNzMsi='vod'
  elif mode=='MOVIE':
   GSplofuUIabRjBVckdenvxQLmNzMEr =GSplofuUIabRjBVckdenvxQLmNzMEs.API_DOMAIN+'/cf/movie/contents/'+GSplofuUIabRjBVckdenvxQLmNzMFr
   GSplofuUIabRjBVckdenvxQLmNzMsi='movie'
  try:
   if mode!='LIVE' or pvrmode=='-':
    GSplofuUIabRjBVckdenvxQLmNzMEK=GSplofuUIabRjBVckdenvxQLmNzMEs.GetDefaultParams(login=GSplofuUIabRjBVckdenvxQLmNzMst)
    GSplofuUIabRjBVckdenvxQLmNzMEX=GSplofuUIabRjBVckdenvxQLmNzMEs.callRequestCookies('Get',GSplofuUIabRjBVckdenvxQLmNzMEr,payload=GSplofuUIabRjBVckdenvxQLmNzMsH,params=GSplofuUIabRjBVckdenvxQLmNzMEK,headers=GSplofuUIabRjBVckdenvxQLmNzMsH,cookies=GSplofuUIabRjBVckdenvxQLmNzMsH)
    GSplofuUIabRjBVckdenvxQLmNzMET=json.loads(GSplofuUIabRjBVckdenvxQLmNzMEX.text)
    GSplofuUIabRjBVckdenvxQLmNzMsF=GSplofuUIabRjBVckdenvxQLmNzMET['qualities']['list']
    if GSplofuUIabRjBVckdenvxQLmNzMsF==GSplofuUIabRjBVckdenvxQLmNzMsH:return(GSplofuUIabRjBVckdenvxQLmNzMFT,GSplofuUIabRjBVckdenvxQLmNzMsK,GSplofuUIabRjBVckdenvxQLmNzMsw,streaming_preview)
    for GSplofuUIabRjBVckdenvxQLmNzMsP in GSplofuUIabRjBVckdenvxQLmNzMsF:
     GSplofuUIabRjBVckdenvxQLmNzMFh.append(GSplofuUIabRjBVckdenvxQLmNzMsr(GSplofuUIabRjBVckdenvxQLmNzMsP.get('id').rstrip('p')))
    if 'type' in GSplofuUIabRjBVckdenvxQLmNzMET:
     if GSplofuUIabRjBVckdenvxQLmNzMET['type']=='onair':
      GSplofuUIabRjBVckdenvxQLmNzMsi='onairvod'
    if 'drms' in GSplofuUIabRjBVckdenvxQLmNzMET:
     if GSplofuUIabRjBVckdenvxQLmNzMET['drms']:
      GSplofuUIabRjBVckdenvxQLmNzMsE='dash'
  except GSplofuUIabRjBVckdenvxQLmNzMsq as exception:
   GSplofuUIabRjBVckdenvxQLmNzMsO(exception)
   return(GSplofuUIabRjBVckdenvxQLmNzMFT,GSplofuUIabRjBVckdenvxQLmNzMsK,GSplofuUIabRjBVckdenvxQLmNzMsw,streaming_preview)
  try:
   GSplofuUIabRjBVckdenvxQLmNzMsg=GSplofuUIabRjBVckdenvxQLmNzMEs.CheckQuality(quality_int,GSplofuUIabRjBVckdenvxQLmNzMFh)
   if mode=='LIVE' and pvrmode!='-':
    GSplofuUIabRjBVckdenvxQLmNzMsC='auto'
   else:
    GSplofuUIabRjBVckdenvxQLmNzMsC=GSplofuUIabRjBVckdenvxQLmNzMsA(GSplofuUIabRjBVckdenvxQLmNzMsg)+'p'
   GSplofuUIabRjBVckdenvxQLmNzMEr=GSplofuUIabRjBVckdenvxQLmNzMEs.API_DOMAIN+'/streaming'
   GSplofuUIabRjBVckdenvxQLmNzMEK={'contentid':GSplofuUIabRjBVckdenvxQLmNzMFr,'contenttype':GSplofuUIabRjBVckdenvxQLmNzMsi,'action':GSplofuUIabRjBVckdenvxQLmNzMsE,'quality':GSplofuUIabRjBVckdenvxQLmNzMsC,'deviceModelId':'Windows 10','guid':GSplofuUIabRjBVckdenvxQLmNzMEs.GetGUID(guidType=2),'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n'}
   GSplofuUIabRjBVckdenvxQLmNzMEK.update(GSplofuUIabRjBVckdenvxQLmNzMEs.GetDefaultParams(login=GSplofuUIabRjBVckdenvxQLmNzMsy))
   GSplofuUIabRjBVckdenvxQLmNzMEX=GSplofuUIabRjBVckdenvxQLmNzMEs.callRequestCookies('Get',GSplofuUIabRjBVckdenvxQLmNzMEr,payload=GSplofuUIabRjBVckdenvxQLmNzMsH,params=GSplofuUIabRjBVckdenvxQLmNzMEK,headers=GSplofuUIabRjBVckdenvxQLmNzMsH,cookies=GSplofuUIabRjBVckdenvxQLmNzMsH)
   GSplofuUIabRjBVckdenvxQLmNzMET=json.loads(GSplofuUIabRjBVckdenvxQLmNzMEX.text)
   GSplofuUIabRjBVckdenvxQLmNzMFT=GSplofuUIabRjBVckdenvxQLmNzMET['playurl']
   if GSplofuUIabRjBVckdenvxQLmNzMFT==GSplofuUIabRjBVckdenvxQLmNzMsH:return(GSplofuUIabRjBVckdenvxQLmNzMFT,GSplofuUIabRjBVckdenvxQLmNzMsK,GSplofuUIabRjBVckdenvxQLmNzMsw,streaming_preview)
   GSplofuUIabRjBVckdenvxQLmNzMsK=GSplofuUIabRjBVckdenvxQLmNzMET['awscookie']
   GSplofuUIabRjBVckdenvxQLmNzMsw =GSplofuUIabRjBVckdenvxQLmNzMET['drm']
   if 'previewmsg' in GSplofuUIabRjBVckdenvxQLmNzMET['preview']:streaming_preview=GSplofuUIabRjBVckdenvxQLmNzMET['preview']['previewmsg']
  except GSplofuUIabRjBVckdenvxQLmNzMsq as exception:
   GSplofuUIabRjBVckdenvxQLmNzMsO(exception)
  return(GSplofuUIabRjBVckdenvxQLmNzMFT,GSplofuUIabRjBVckdenvxQLmNzMsK,GSplofuUIabRjBVckdenvxQLmNzMsw,streaming_preview) 
# Created by pyminifier (https://github.com/liftoff/pyminifier)
