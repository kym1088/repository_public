__author__="NightRain"
CmfXEusxiNSzqnQJokdjRWLYhayGKM=object
CmfXEusxiNSzqnQJokdjRWLYhayGKD=None
CmfXEusxiNSzqnQJokdjRWLYhayGKF=int
CmfXEusxiNSzqnQJokdjRWLYhayGKO=True
CmfXEusxiNSzqnQJokdjRWLYhayGKP=False
CmfXEusxiNSzqnQJokdjRWLYhayGKg=type
CmfXEusxiNSzqnQJokdjRWLYhayGKA=dict
CmfXEusxiNSzqnQJokdjRWLYhayGKc=getattr
CmfXEusxiNSzqnQJokdjRWLYhayGKb=list
CmfXEusxiNSzqnQJokdjRWLYhayGKI=len
CmfXEusxiNSzqnQJokdjRWLYhayGKw=range
CmfXEusxiNSzqnQJokdjRWLYhayGKH=str
CmfXEusxiNSzqnQJokdjRWLYhayGKp=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import json
CmfXEusxiNSzqnQJokdjRWLYhayGvt=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://apis.wavve.com/v1/multiband/GN51','icon':'home.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/v1/catalog?broadcastid=VN500&catalogType=ranking&category=all&code=VN500----GN51&&rankingType=realtime&uicode=VN500&uiparent=GN51-VN500&uirank=0&uitype=band_14','page':'1','orderby':'viewtime','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/v1/catalog?broadcastid=VN561&catalogType=ranking&category=vod&genre=drama&rankingType=realtime&uicode=VN561&uiparent=GN56-VN561&uirank=1&uitype=band_98','page':'1','orderby':'viewtime','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/v1/catalog?broadcastid=VN562&catalogType=ranking&category=vod&genre=variety&rankingType=realtime&uicode=VN562&uiparent=GN57-VN562&uirank=1&uitype=band_98','page':'1','orderby':'viewtime','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'CN21','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'vod09','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'vod09','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'4','sType':'movie','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'4','sType':'movie','orderby':'modifydate','ordernm':'업데이트순','icon':''},{'title':'프로야구 - 경기중 시청가능','mode':'GAME_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'(웨이브) 검색','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'(웨이브) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
CmfXEusxiNSzqnQJokdjRWLYhayGve=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
CmfXEusxiNSzqnQJokdjRWLYhayGvl=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
CmfXEusxiNSzqnQJokdjRWLYhayGvT={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
CmfXEusxiNSzqnQJokdjRWLYhayGvB =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
CmfXEusxiNSzqnQJokdjRWLYhayGvK=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_searched.txt'))
from wavveCore import*
class CmfXEusxiNSzqnQJokdjRWLYhayGvr(CmfXEusxiNSzqnQJokdjRWLYhayGKM):
 def __init__(CmfXEusxiNSzqnQJokdjRWLYhayGvU,CmfXEusxiNSzqnQJokdjRWLYhayGvV,CmfXEusxiNSzqnQJokdjRWLYhayGvM,CmfXEusxiNSzqnQJokdjRWLYhayGvD):
  CmfXEusxiNSzqnQJokdjRWLYhayGvU._addon_url =CmfXEusxiNSzqnQJokdjRWLYhayGvV
  CmfXEusxiNSzqnQJokdjRWLYhayGvU._addon_handle=CmfXEusxiNSzqnQJokdjRWLYhayGvM
  CmfXEusxiNSzqnQJokdjRWLYhayGvU.main_params =CmfXEusxiNSzqnQJokdjRWLYhayGvD
  CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj =kdVapybKnRfLuAgvosjQtYPWFzcDEO() 
  CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.WV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_stream(mpd,m3u8)'))
 def addon_noti(CmfXEusxiNSzqnQJokdjRWLYhayGvU,sting):
  try:
   CmfXEusxiNSzqnQJokdjRWLYhayGvO=xbmcgui.Dialog()
   CmfXEusxiNSzqnQJokdjRWLYhayGvO.notification(__addonname__,sting)
  except:
   CmfXEusxiNSzqnQJokdjRWLYhayGKD
 def addon_log(CmfXEusxiNSzqnQJokdjRWLYhayGvU,string):
  try:
   CmfXEusxiNSzqnQJokdjRWLYhayGvP=string.encode('utf-8','ignore')
  except:
   CmfXEusxiNSzqnQJokdjRWLYhayGvP='addonException: addon_log'
  CmfXEusxiNSzqnQJokdjRWLYhayGvg=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,CmfXEusxiNSzqnQJokdjRWLYhayGvP),level=CmfXEusxiNSzqnQJokdjRWLYhayGvg)
 def get_keyboard_input(CmfXEusxiNSzqnQJokdjRWLYhayGvU,CmfXEusxiNSzqnQJokdjRWLYhayGrF):
  CmfXEusxiNSzqnQJokdjRWLYhayGvA=CmfXEusxiNSzqnQJokdjRWLYhayGKD
  kb=xbmc.Keyboard()
  kb.setHeading(CmfXEusxiNSzqnQJokdjRWLYhayGrF)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   CmfXEusxiNSzqnQJokdjRWLYhayGvA=kb.getText()
  return CmfXEusxiNSzqnQJokdjRWLYhayGvA
 def get_settings_account(CmfXEusxiNSzqnQJokdjRWLYhayGvU):
  CmfXEusxiNSzqnQJokdjRWLYhayGvc =__addon__.getSetting('id')
  CmfXEusxiNSzqnQJokdjRWLYhayGvb =__addon__.getSetting('pw')
  CmfXEusxiNSzqnQJokdjRWLYhayGvI=CmfXEusxiNSzqnQJokdjRWLYhayGKF(__addon__.getSetting('selected_profile'))
  return(CmfXEusxiNSzqnQJokdjRWLYhayGvc,CmfXEusxiNSzqnQJokdjRWLYhayGvb,CmfXEusxiNSzqnQJokdjRWLYhayGvI)
 def get_settings_totalsearch(CmfXEusxiNSzqnQJokdjRWLYhayGvU):
  CmfXEusxiNSzqnQJokdjRWLYhayGvw =CmfXEusxiNSzqnQJokdjRWLYhayGKO if __addon__.getSetting('local_search')=='true' else CmfXEusxiNSzqnQJokdjRWLYhayGKP
  CmfXEusxiNSzqnQJokdjRWLYhayGvH=CmfXEusxiNSzqnQJokdjRWLYhayGKO if __addon__.getSetting('local_history')=='true' else CmfXEusxiNSzqnQJokdjRWLYhayGKP
  CmfXEusxiNSzqnQJokdjRWLYhayGvp =CmfXEusxiNSzqnQJokdjRWLYhayGKO if __addon__.getSetting('total_search')=='true' else CmfXEusxiNSzqnQJokdjRWLYhayGKP
  CmfXEusxiNSzqnQJokdjRWLYhayGrv=CmfXEusxiNSzqnQJokdjRWLYhayGKO if __addon__.getSetting('total_history')=='true' else CmfXEusxiNSzqnQJokdjRWLYhayGKP
  CmfXEusxiNSzqnQJokdjRWLYhayGrt=CmfXEusxiNSzqnQJokdjRWLYhayGKO if __addon__.getSetting('menu_bookmark')=='true' else CmfXEusxiNSzqnQJokdjRWLYhayGKP
  return(CmfXEusxiNSzqnQJokdjRWLYhayGvw,CmfXEusxiNSzqnQJokdjRWLYhayGvH,CmfXEusxiNSzqnQJokdjRWLYhayGvp,CmfXEusxiNSzqnQJokdjRWLYhayGrv,CmfXEusxiNSzqnQJokdjRWLYhayGrt)
 def get_settings_makebookmark(CmfXEusxiNSzqnQJokdjRWLYhayGvU):
  return CmfXEusxiNSzqnQJokdjRWLYhayGKO if __addon__.getSetting('make_bookmark')=='true' else CmfXEusxiNSzqnQJokdjRWLYhayGKP
 def get_settings_play(CmfXEusxiNSzqnQJokdjRWLYhayGvU):
  CmfXEusxiNSzqnQJokdjRWLYhayGre={'enable_hdr':CmfXEusxiNSzqnQJokdjRWLYhayGKO if __addon__.getSetting('enable_hdr')=='true' else CmfXEusxiNSzqnQJokdjRWLYhayGKP,'enable_uhd':CmfXEusxiNSzqnQJokdjRWLYhayGKO if __addon__.getSetting('enable_uhd')=='true' else CmfXEusxiNSzqnQJokdjRWLYhayGKP,'streamFilename':CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.WV_STREAM_FILENAME,}
  if CmfXEusxiNSzqnQJokdjRWLYhayGvU.get_selQuality()<1080:
   CmfXEusxiNSzqnQJokdjRWLYhayGre['enable_hdr']=CmfXEusxiNSzqnQJokdjRWLYhayGKP
   CmfXEusxiNSzqnQJokdjRWLYhayGre['enable_uhd']=CmfXEusxiNSzqnQJokdjRWLYhayGKP
  return(CmfXEusxiNSzqnQJokdjRWLYhayGre)
 def get_settings_proxyport(CmfXEusxiNSzqnQJokdjRWLYhayGvU):
  CmfXEusxiNSzqnQJokdjRWLYhayGrl =CmfXEusxiNSzqnQJokdjRWLYhayGKO if __addon__.getSetting('proxyYn')=='true' else CmfXEusxiNSzqnQJokdjRWLYhayGKP
  CmfXEusxiNSzqnQJokdjRWLYhayGrT=CmfXEusxiNSzqnQJokdjRWLYhayGKF(__addon__.getSetting('proxyPort'))
  return CmfXEusxiNSzqnQJokdjRWLYhayGrl,CmfXEusxiNSzqnQJokdjRWLYhayGrT
 def get_selQuality(CmfXEusxiNSzqnQJokdjRWLYhayGvU):
  try:
   CmfXEusxiNSzqnQJokdjRWLYhayGrB=[1080,720,480,360]
   CmfXEusxiNSzqnQJokdjRWLYhayGrK=CmfXEusxiNSzqnQJokdjRWLYhayGKF(__addon__.getSetting('selected_quality'))
   return CmfXEusxiNSzqnQJokdjRWLYhayGrB[CmfXEusxiNSzqnQJokdjRWLYhayGrK]
  except:
   CmfXEusxiNSzqnQJokdjRWLYhayGKD
  return 1080 
 def get_settings_exclusion21(CmfXEusxiNSzqnQJokdjRWLYhayGvU):
  CmfXEusxiNSzqnQJokdjRWLYhayGrU =__addon__.getSetting('exclusion21')
  if CmfXEusxiNSzqnQJokdjRWLYhayGrU=='false':
   return CmfXEusxiNSzqnQJokdjRWLYhayGKP
  else:
   return CmfXEusxiNSzqnQJokdjRWLYhayGKO
 def get_settings_direct_replay(CmfXEusxiNSzqnQJokdjRWLYhayGvU):
  CmfXEusxiNSzqnQJokdjRWLYhayGrV=CmfXEusxiNSzqnQJokdjRWLYhayGKF(__addon__.getSetting('direct_replay'))
  if CmfXEusxiNSzqnQJokdjRWLYhayGrV==0:
   return CmfXEusxiNSzqnQJokdjRWLYhayGKP
  else:
   return CmfXEusxiNSzqnQJokdjRWLYhayGKO
 def set_winEpisodeOrderby(CmfXEusxiNSzqnQJokdjRWLYhayGvU,CmfXEusxiNSzqnQJokdjRWLYhayGrM):
  __addon__.setSetting('wavve_orderby',CmfXEusxiNSzqnQJokdjRWLYhayGrM)
 def get_winEpisodeOrderby(CmfXEusxiNSzqnQJokdjRWLYhayGvU):
  CmfXEusxiNSzqnQJokdjRWLYhayGrM=__addon__.getSetting('wavve_orderby')
  if CmfXEusxiNSzqnQJokdjRWLYhayGrM in['',CmfXEusxiNSzqnQJokdjRWLYhayGKD]:CmfXEusxiNSzqnQJokdjRWLYhayGrM='desc'
  return CmfXEusxiNSzqnQJokdjRWLYhayGrM
 def add_dir(CmfXEusxiNSzqnQJokdjRWLYhayGvU,label,sublabel='',img='',infoLabels=CmfXEusxiNSzqnQJokdjRWLYhayGKD,isFolder=CmfXEusxiNSzqnQJokdjRWLYhayGKO,params='',isLink=CmfXEusxiNSzqnQJokdjRWLYhayGKP,ContextMenu=CmfXEusxiNSzqnQJokdjRWLYhayGKD):
  CmfXEusxiNSzqnQJokdjRWLYhayGrD='%s?%s'%(CmfXEusxiNSzqnQJokdjRWLYhayGvU._addon_url,urllib.parse.urlencode(params))
  if sublabel:CmfXEusxiNSzqnQJokdjRWLYhayGrF='%s < %s >'%(label,sublabel)
  else: CmfXEusxiNSzqnQJokdjRWLYhayGrF=label
  if not img:img='DefaultFolder.png'
  CmfXEusxiNSzqnQJokdjRWLYhayGrO=xbmcgui.ListItem(CmfXEusxiNSzqnQJokdjRWLYhayGrF)
  if CmfXEusxiNSzqnQJokdjRWLYhayGKg(img)==CmfXEusxiNSzqnQJokdjRWLYhayGKA:
   CmfXEusxiNSzqnQJokdjRWLYhayGrO.setArt(img)
  else:
   CmfXEusxiNSzqnQJokdjRWLYhayGrO.setArt({'thumb':img,'poster':img})
  if CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.KodiVersion>=20:
   if infoLabels:CmfXEusxiNSzqnQJokdjRWLYhayGvU.Set_InfoTag(CmfXEusxiNSzqnQJokdjRWLYhayGrO.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:CmfXEusxiNSzqnQJokdjRWLYhayGrO.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   CmfXEusxiNSzqnQJokdjRWLYhayGrO.setProperty('IsPlayable','true')
  if ContextMenu:CmfXEusxiNSzqnQJokdjRWLYhayGrO.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(CmfXEusxiNSzqnQJokdjRWLYhayGvU._addon_handle,CmfXEusxiNSzqnQJokdjRWLYhayGrD,CmfXEusxiNSzqnQJokdjRWLYhayGrO,isFolder)
 def Set_InfoTag(CmfXEusxiNSzqnQJokdjRWLYhayGvU,video_InfoTag:xbmc.InfoTagVideo,CmfXEusxiNSzqnQJokdjRWLYhayGrH):
  for CmfXEusxiNSzqnQJokdjRWLYhayGrP,value in CmfXEusxiNSzqnQJokdjRWLYhayGrH.items():
   if CmfXEusxiNSzqnQJokdjRWLYhayGvT[CmfXEusxiNSzqnQJokdjRWLYhayGrP]['type']=='string':
    CmfXEusxiNSzqnQJokdjRWLYhayGKc(video_InfoTag,CmfXEusxiNSzqnQJokdjRWLYhayGvT[CmfXEusxiNSzqnQJokdjRWLYhayGrP]['func'])(value)
   elif CmfXEusxiNSzqnQJokdjRWLYhayGvT[CmfXEusxiNSzqnQJokdjRWLYhayGrP]['type']=='int':
    if CmfXEusxiNSzqnQJokdjRWLYhayGKg(value)==CmfXEusxiNSzqnQJokdjRWLYhayGKF:
     CmfXEusxiNSzqnQJokdjRWLYhayGrg=CmfXEusxiNSzqnQJokdjRWLYhayGKF(value)
    else:
     CmfXEusxiNSzqnQJokdjRWLYhayGrg=0
    CmfXEusxiNSzqnQJokdjRWLYhayGKc(video_InfoTag,CmfXEusxiNSzqnQJokdjRWLYhayGvT[CmfXEusxiNSzqnQJokdjRWLYhayGrP]['func'])(CmfXEusxiNSzqnQJokdjRWLYhayGrg)
   elif CmfXEusxiNSzqnQJokdjRWLYhayGvT[CmfXEusxiNSzqnQJokdjRWLYhayGrP]['type']=='actor':
    if value!=[]:
     CmfXEusxiNSzqnQJokdjRWLYhayGKc(video_InfoTag,CmfXEusxiNSzqnQJokdjRWLYhayGvT[CmfXEusxiNSzqnQJokdjRWLYhayGrP]['func'])([xbmc.Actor(name)for name in value])
   elif CmfXEusxiNSzqnQJokdjRWLYhayGvT[CmfXEusxiNSzqnQJokdjRWLYhayGrP]['type']=='list':
    if CmfXEusxiNSzqnQJokdjRWLYhayGKg(value)==CmfXEusxiNSzqnQJokdjRWLYhayGKb:
     CmfXEusxiNSzqnQJokdjRWLYhayGKc(video_InfoTag,CmfXEusxiNSzqnQJokdjRWLYhayGvT[CmfXEusxiNSzqnQJokdjRWLYhayGrP]['func'])(value)
    else:
     CmfXEusxiNSzqnQJokdjRWLYhayGKc(video_InfoTag,CmfXEusxiNSzqnQJokdjRWLYhayGvT[CmfXEusxiNSzqnQJokdjRWLYhayGrP]['func'])([value])
 def dp_Main_List(CmfXEusxiNSzqnQJokdjRWLYhayGvU):
  (CmfXEusxiNSzqnQJokdjRWLYhayGvw,CmfXEusxiNSzqnQJokdjRWLYhayGvH,CmfXEusxiNSzqnQJokdjRWLYhayGvp,CmfXEusxiNSzqnQJokdjRWLYhayGrv,CmfXEusxiNSzqnQJokdjRWLYhayGrt)=CmfXEusxiNSzqnQJokdjRWLYhayGvU.get_settings_totalsearch()
  for CmfXEusxiNSzqnQJokdjRWLYhayGrA in CmfXEusxiNSzqnQJokdjRWLYhayGvt:
   CmfXEusxiNSzqnQJokdjRWLYhayGrF=CmfXEusxiNSzqnQJokdjRWLYhayGrA.get('title')
   CmfXEusxiNSzqnQJokdjRWLYhayGrc=''
   if CmfXEusxiNSzqnQJokdjRWLYhayGrA.get('mode')=='SEARCH_GROUP' and CmfXEusxiNSzqnQJokdjRWLYhayGvw ==CmfXEusxiNSzqnQJokdjRWLYhayGKP:continue
   elif CmfXEusxiNSzqnQJokdjRWLYhayGrA.get('mode')=='SEARCH_HISTORY' and CmfXEusxiNSzqnQJokdjRWLYhayGvH==CmfXEusxiNSzqnQJokdjRWLYhayGKP:continue
   elif CmfXEusxiNSzqnQJokdjRWLYhayGrA.get('mode')=='TOTAL_SEARCH' and CmfXEusxiNSzqnQJokdjRWLYhayGvp ==CmfXEusxiNSzqnQJokdjRWLYhayGKP:continue
   elif CmfXEusxiNSzqnQJokdjRWLYhayGrA.get('mode')=='TOTAL_HISTORY' and CmfXEusxiNSzqnQJokdjRWLYhayGrv==CmfXEusxiNSzqnQJokdjRWLYhayGKP:continue
   elif CmfXEusxiNSzqnQJokdjRWLYhayGrA.get('mode')=='MENU_BOOKMARK' and CmfXEusxiNSzqnQJokdjRWLYhayGrt==CmfXEusxiNSzqnQJokdjRWLYhayGKP:continue
   CmfXEusxiNSzqnQJokdjRWLYhayGrb={'mode':CmfXEusxiNSzqnQJokdjRWLYhayGrA.get('mode'),'sCode':CmfXEusxiNSzqnQJokdjRWLYhayGrA.get('sCode'),'sIndex':CmfXEusxiNSzqnQJokdjRWLYhayGrA.get('sIndex'),'sType':CmfXEusxiNSzqnQJokdjRWLYhayGrA.get('sType'),'suburl':CmfXEusxiNSzqnQJokdjRWLYhayGrA.get('suburl'),'subapi':CmfXEusxiNSzqnQJokdjRWLYhayGrA.get('subapi'),'page':CmfXEusxiNSzqnQJokdjRWLYhayGrA.get('page'),'orderby':CmfXEusxiNSzqnQJokdjRWLYhayGrA.get('orderby'),'ordernm':CmfXEusxiNSzqnQJokdjRWLYhayGrA.get('ordernm')}
   if CmfXEusxiNSzqnQJokdjRWLYhayGrA.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    CmfXEusxiNSzqnQJokdjRWLYhayGrI=CmfXEusxiNSzqnQJokdjRWLYhayGKP
    CmfXEusxiNSzqnQJokdjRWLYhayGrw =CmfXEusxiNSzqnQJokdjRWLYhayGKO
   else:
    CmfXEusxiNSzqnQJokdjRWLYhayGrI=CmfXEusxiNSzqnQJokdjRWLYhayGKO
    CmfXEusxiNSzqnQJokdjRWLYhayGrw =CmfXEusxiNSzqnQJokdjRWLYhayGKP
   CmfXEusxiNSzqnQJokdjRWLYhayGrH={'title':CmfXEusxiNSzqnQJokdjRWLYhayGrF,'plot':CmfXEusxiNSzqnQJokdjRWLYhayGrF}
   if CmfXEusxiNSzqnQJokdjRWLYhayGrA.get('mode')=='XXX':CmfXEusxiNSzqnQJokdjRWLYhayGrH=CmfXEusxiNSzqnQJokdjRWLYhayGKD
   if 'icon' in CmfXEusxiNSzqnQJokdjRWLYhayGrA:CmfXEusxiNSzqnQJokdjRWLYhayGrc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',CmfXEusxiNSzqnQJokdjRWLYhayGrA.get('icon')) 
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.add_dir(CmfXEusxiNSzqnQJokdjRWLYhayGrF,sublabel='',img=CmfXEusxiNSzqnQJokdjRWLYhayGrc,infoLabels=CmfXEusxiNSzqnQJokdjRWLYhayGrH,isFolder=CmfXEusxiNSzqnQJokdjRWLYhayGrI,params=CmfXEusxiNSzqnQJokdjRWLYhayGrb,isLink=CmfXEusxiNSzqnQJokdjRWLYhayGrw)
  xbmcplugin.endOfDirectory(CmfXEusxiNSzqnQJokdjRWLYhayGvU._addon_handle,cacheToDisc=CmfXEusxiNSzqnQJokdjRWLYhayGKO)
 def dp_Search_Group(CmfXEusxiNSzqnQJokdjRWLYhayGvU,args):
  if 'search_key' in args:
   CmfXEusxiNSzqnQJokdjRWLYhayGtr=args.get('search_key')
  else:
   CmfXEusxiNSzqnQJokdjRWLYhayGtr=CmfXEusxiNSzqnQJokdjRWLYhayGvU.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not CmfXEusxiNSzqnQJokdjRWLYhayGtr:
    return
  for CmfXEusxiNSzqnQJokdjRWLYhayGte in CmfXEusxiNSzqnQJokdjRWLYhayGve:
   CmfXEusxiNSzqnQJokdjRWLYhayGtl =CmfXEusxiNSzqnQJokdjRWLYhayGte.get('mode')
   CmfXEusxiNSzqnQJokdjRWLYhayGtT=CmfXEusxiNSzqnQJokdjRWLYhayGte.get('sType')
   CmfXEusxiNSzqnQJokdjRWLYhayGrF=CmfXEusxiNSzqnQJokdjRWLYhayGte.get('title')
   (CmfXEusxiNSzqnQJokdjRWLYhayGtB,CmfXEusxiNSzqnQJokdjRWLYhayGtK)=CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.Get_Search_List(CmfXEusxiNSzqnQJokdjRWLYhayGtr,CmfXEusxiNSzqnQJokdjRWLYhayGtT,1,exclusion21=CmfXEusxiNSzqnQJokdjRWLYhayGvU.get_settings_exclusion21())
   CmfXEusxiNSzqnQJokdjRWLYhayGrH={'plot':'검색어 : '+CmfXEusxiNSzqnQJokdjRWLYhayGtr+'\n\n'+CmfXEusxiNSzqnQJokdjRWLYhayGvU.Search_FreeList(CmfXEusxiNSzqnQJokdjRWLYhayGtB)}
   CmfXEusxiNSzqnQJokdjRWLYhayGrb={'mode':CmfXEusxiNSzqnQJokdjRWLYhayGtl,'sType':CmfXEusxiNSzqnQJokdjRWLYhayGtT,'search_key':CmfXEusxiNSzqnQJokdjRWLYhayGtr,'page':'1',}
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.add_dir(CmfXEusxiNSzqnQJokdjRWLYhayGrF,sublabel='',img='',infoLabels=CmfXEusxiNSzqnQJokdjRWLYhayGrH,isFolder=CmfXEusxiNSzqnQJokdjRWLYhayGKO,params=CmfXEusxiNSzqnQJokdjRWLYhayGrb)
  if CmfXEusxiNSzqnQJokdjRWLYhayGKI(CmfXEusxiNSzqnQJokdjRWLYhayGve)>0:xbmcplugin.endOfDirectory(CmfXEusxiNSzqnQJokdjRWLYhayGvU._addon_handle,cacheToDisc=CmfXEusxiNSzqnQJokdjRWLYhayGKO)
  CmfXEusxiNSzqnQJokdjRWLYhayGvU.Save_Searched_List(CmfXEusxiNSzqnQJokdjRWLYhayGtr)
 def Search_FreeList(CmfXEusxiNSzqnQJokdjRWLYhayGvU,search_list):
  CmfXEusxiNSzqnQJokdjRWLYhayGtU=''
  CmfXEusxiNSzqnQJokdjRWLYhayGtV=7
  try:
   if CmfXEusxiNSzqnQJokdjRWLYhayGKI(search_list)==0:return '검색결과 없음'
   for i in CmfXEusxiNSzqnQJokdjRWLYhayGKw(CmfXEusxiNSzqnQJokdjRWLYhayGKI(search_list)):
    if i>=CmfXEusxiNSzqnQJokdjRWLYhayGtV:
     CmfXEusxiNSzqnQJokdjRWLYhayGtU=CmfXEusxiNSzqnQJokdjRWLYhayGtU+'...'
     break
    CmfXEusxiNSzqnQJokdjRWLYhayGtU=CmfXEusxiNSzqnQJokdjRWLYhayGtU+search_list[i]['title']+'\n'
  except:
   return ''
  return CmfXEusxiNSzqnQJokdjRWLYhayGtU
 def dp_Watch_Group(CmfXEusxiNSzqnQJokdjRWLYhayGvU,args):
  for CmfXEusxiNSzqnQJokdjRWLYhayGtM in CmfXEusxiNSzqnQJokdjRWLYhayGvl:
   CmfXEusxiNSzqnQJokdjRWLYhayGrF=CmfXEusxiNSzqnQJokdjRWLYhayGtM.get('title')
   CmfXEusxiNSzqnQJokdjRWLYhayGrb={'mode':CmfXEusxiNSzqnQJokdjRWLYhayGtM.get('mode'),'sType':CmfXEusxiNSzqnQJokdjRWLYhayGtM.get('sType')}
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.add_dir(CmfXEusxiNSzqnQJokdjRWLYhayGrF,sublabel='',img='',infoLabels=CmfXEusxiNSzqnQJokdjRWLYhayGKD,isFolder=CmfXEusxiNSzqnQJokdjRWLYhayGKO,params=CmfXEusxiNSzqnQJokdjRWLYhayGrb)
  if CmfXEusxiNSzqnQJokdjRWLYhayGKI(CmfXEusxiNSzqnQJokdjRWLYhayGvl)>0:xbmcplugin.endOfDirectory(CmfXEusxiNSzqnQJokdjRWLYhayGvU._addon_handle,cacheToDisc=CmfXEusxiNSzqnQJokdjRWLYhayGKO)
 def dp_Search_History(CmfXEusxiNSzqnQJokdjRWLYhayGvU,args):
  CmfXEusxiNSzqnQJokdjRWLYhayGtD=CmfXEusxiNSzqnQJokdjRWLYhayGvU.Load_List_File('search')
  for CmfXEusxiNSzqnQJokdjRWLYhayGtF in CmfXEusxiNSzqnQJokdjRWLYhayGtD:
   CmfXEusxiNSzqnQJokdjRWLYhayGtO=CmfXEusxiNSzqnQJokdjRWLYhayGKA(urllib.parse.parse_qsl(CmfXEusxiNSzqnQJokdjRWLYhayGtF))
   CmfXEusxiNSzqnQJokdjRWLYhayGtP=CmfXEusxiNSzqnQJokdjRWLYhayGtO.get('skey').strip()
   CmfXEusxiNSzqnQJokdjRWLYhayGrb={'mode':'SEARCH_GROUP','search_key':CmfXEusxiNSzqnQJokdjRWLYhayGtP,}
   CmfXEusxiNSzqnQJokdjRWLYhayGtg={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':CmfXEusxiNSzqnQJokdjRWLYhayGtP,'vType':'-',}
   CmfXEusxiNSzqnQJokdjRWLYhayGtA=urllib.parse.urlencode(CmfXEusxiNSzqnQJokdjRWLYhayGtg)
   CmfXEusxiNSzqnQJokdjRWLYhayGtc=[('선택된 검색어 ( %s ) 삭제'%(CmfXEusxiNSzqnQJokdjRWLYhayGtP),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(CmfXEusxiNSzqnQJokdjRWLYhayGtA))]
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.add_dir(CmfXEusxiNSzqnQJokdjRWLYhayGtP,sublabel='',img=CmfXEusxiNSzqnQJokdjRWLYhayGKD,infoLabels=CmfXEusxiNSzqnQJokdjRWLYhayGKD,isFolder=CmfXEusxiNSzqnQJokdjRWLYhayGKO,params=CmfXEusxiNSzqnQJokdjRWLYhayGrb,ContextMenu=CmfXEusxiNSzqnQJokdjRWLYhayGtc)
  CmfXEusxiNSzqnQJokdjRWLYhayGtb={'plot':'검색목록 전체를 삭제합니다.'}
  CmfXEusxiNSzqnQJokdjRWLYhayGrF='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  CmfXEusxiNSzqnQJokdjRWLYhayGrb={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  CmfXEusxiNSzqnQJokdjRWLYhayGrc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  CmfXEusxiNSzqnQJokdjRWLYhayGvU.add_dir(CmfXEusxiNSzqnQJokdjRWLYhayGrF,sublabel='',img=CmfXEusxiNSzqnQJokdjRWLYhayGrc,infoLabels=CmfXEusxiNSzqnQJokdjRWLYhayGtb,isFolder=CmfXEusxiNSzqnQJokdjRWLYhayGKP,params=CmfXEusxiNSzqnQJokdjRWLYhayGrb,isLink=CmfXEusxiNSzqnQJokdjRWLYhayGKO)
  xbmcplugin.endOfDirectory(CmfXEusxiNSzqnQJokdjRWLYhayGvU._addon_handle,cacheToDisc=CmfXEusxiNSzqnQJokdjRWLYhayGKP)
 def dp_Search_List(CmfXEusxiNSzqnQJokdjRWLYhayGvU,args):
  CmfXEusxiNSzqnQJokdjRWLYhayGtT =args.get('sType')
  CmfXEusxiNSzqnQJokdjRWLYhayGtI =CmfXEusxiNSzqnQJokdjRWLYhayGKF(args.get('page'))
  if 'search_key' in args:
   CmfXEusxiNSzqnQJokdjRWLYhayGtr=args.get('search_key')
  else:
   CmfXEusxiNSzqnQJokdjRWLYhayGtr=CmfXEusxiNSzqnQJokdjRWLYhayGvU.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not CmfXEusxiNSzqnQJokdjRWLYhayGtr:
    xbmcplugin.endOfDirectory(CmfXEusxiNSzqnQJokdjRWLYhayGvU._addon_handle)
    return
  CmfXEusxiNSzqnQJokdjRWLYhayGtw,CmfXEusxiNSzqnQJokdjRWLYhayGtK=CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.Get_Search_List(CmfXEusxiNSzqnQJokdjRWLYhayGtr,CmfXEusxiNSzqnQJokdjRWLYhayGtT,CmfXEusxiNSzqnQJokdjRWLYhayGtI,exclusion21=CmfXEusxiNSzqnQJokdjRWLYhayGvU.get_settings_exclusion21())
  for CmfXEusxiNSzqnQJokdjRWLYhayGtH in CmfXEusxiNSzqnQJokdjRWLYhayGtw:
   CmfXEusxiNSzqnQJokdjRWLYhayGtp =CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('videoid')
   CmfXEusxiNSzqnQJokdjRWLYhayGev =CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('vidtype')
   CmfXEusxiNSzqnQJokdjRWLYhayGrF =CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('title')
   CmfXEusxiNSzqnQJokdjRWLYhayGer=CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('thumbnail')
   CmfXEusxiNSzqnQJokdjRWLYhayGet =CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('age')
   if CmfXEusxiNSzqnQJokdjRWLYhayGet=='18' or CmfXEusxiNSzqnQJokdjRWLYhayGet=='19' or CmfXEusxiNSzqnQJokdjRWLYhayGet=='21':CmfXEusxiNSzqnQJokdjRWLYhayGrF+=' (%s)'%(CmfXEusxiNSzqnQJokdjRWLYhayGet)
   CmfXEusxiNSzqnQJokdjRWLYhayGtb={'mediatype':'tvshow' if CmfXEusxiNSzqnQJokdjRWLYhayGtT=='vod' else 'movie','mpaa':CmfXEusxiNSzqnQJokdjRWLYhayGet,'title':CmfXEusxiNSzqnQJokdjRWLYhayGrF,'plot':CmfXEusxiNSzqnQJokdjRWLYhayGrF}
   if CmfXEusxiNSzqnQJokdjRWLYhayGtT=='vod':
    CmfXEusxiNSzqnQJokdjRWLYhayGrb={'mode':'EPISODE_LIST','seasonid':CmfXEusxiNSzqnQJokdjRWLYhayGtp,'page':'1',}
    CmfXEusxiNSzqnQJokdjRWLYhayGrI=CmfXEusxiNSzqnQJokdjRWLYhayGKO
   else:
    CmfXEusxiNSzqnQJokdjRWLYhayGrb={'mode':'MOVIE','contentid':CmfXEusxiNSzqnQJokdjRWLYhayGtp,'title':CmfXEusxiNSzqnQJokdjRWLYhayGrF,'thumbnail':CmfXEusxiNSzqnQJokdjRWLYhayGer,'age':CmfXEusxiNSzqnQJokdjRWLYhayGet,}
    CmfXEusxiNSzqnQJokdjRWLYhayGrI=CmfXEusxiNSzqnQJokdjRWLYhayGKP
   CmfXEusxiNSzqnQJokdjRWLYhayGtc=[]
   CmfXEusxiNSzqnQJokdjRWLYhayGel={'mode':'VIEW_DETAIL','values':{'videoid':CmfXEusxiNSzqnQJokdjRWLYhayGtp,'vidtype':'tvshow' if CmfXEusxiNSzqnQJokdjRWLYhayGtT=='vod' else 'movie','contenttype':CmfXEusxiNSzqnQJokdjRWLYhayGev,}}
   CmfXEusxiNSzqnQJokdjRWLYhayGeT=json.dumps(CmfXEusxiNSzqnQJokdjRWLYhayGel,separators=(',',':'))
   CmfXEusxiNSzqnQJokdjRWLYhayGeT=base64.standard_b64encode(CmfXEusxiNSzqnQJokdjRWLYhayGeT.encode()).decode('utf-8')
   CmfXEusxiNSzqnQJokdjRWLYhayGeT=CmfXEusxiNSzqnQJokdjRWLYhayGeT.replace('+','%2B')
   CmfXEusxiNSzqnQJokdjRWLYhayGeB='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(CmfXEusxiNSzqnQJokdjRWLYhayGeT)
   CmfXEusxiNSzqnQJokdjRWLYhayGtc.append(('상세정보 조회',CmfXEusxiNSzqnQJokdjRWLYhayGeB))
   if CmfXEusxiNSzqnQJokdjRWLYhayGvU.get_settings_makebookmark():
    CmfXEusxiNSzqnQJokdjRWLYhayGel={'videoid':CmfXEusxiNSzqnQJokdjRWLYhayGtp,'vidtype':'tvshow' if CmfXEusxiNSzqnQJokdjRWLYhayGtT=='vod' else 'movie','vtitle':CmfXEusxiNSzqnQJokdjRWLYhayGrF,'vsubtitle':'','contenttype':CmfXEusxiNSzqnQJokdjRWLYhayGev,}
    CmfXEusxiNSzqnQJokdjRWLYhayGeK=json.dumps(CmfXEusxiNSzqnQJokdjRWLYhayGel)
    CmfXEusxiNSzqnQJokdjRWLYhayGeK=urllib.parse.quote(CmfXEusxiNSzqnQJokdjRWLYhayGeK)
    CmfXEusxiNSzqnQJokdjRWLYhayGeB='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(CmfXEusxiNSzqnQJokdjRWLYhayGeK)
    CmfXEusxiNSzqnQJokdjRWLYhayGtc.append(('(통합) 찜 영상에 추가',CmfXEusxiNSzqnQJokdjRWLYhayGeB))
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.add_dir(CmfXEusxiNSzqnQJokdjRWLYhayGrF,sublabel='',img=CmfXEusxiNSzqnQJokdjRWLYhayGer,infoLabels=CmfXEusxiNSzqnQJokdjRWLYhayGtb,isFolder=CmfXEusxiNSzqnQJokdjRWLYhayGrI,params=CmfXEusxiNSzqnQJokdjRWLYhayGrb,ContextMenu=CmfXEusxiNSzqnQJokdjRWLYhayGtc)
  if CmfXEusxiNSzqnQJokdjRWLYhayGtK:
   CmfXEusxiNSzqnQJokdjRWLYhayGrb['mode'] ='SEARCH_LIST' 
   CmfXEusxiNSzqnQJokdjRWLYhayGrb['sType']=CmfXEusxiNSzqnQJokdjRWLYhayGtT 
   CmfXEusxiNSzqnQJokdjRWLYhayGrb['page'] =CmfXEusxiNSzqnQJokdjRWLYhayGKH(CmfXEusxiNSzqnQJokdjRWLYhayGtI+1)
   CmfXEusxiNSzqnQJokdjRWLYhayGrb['search_key']=CmfXEusxiNSzqnQJokdjRWLYhayGtr
   CmfXEusxiNSzqnQJokdjRWLYhayGrF='[B]%s >>[/B]'%'다음 페이지'
   CmfXEusxiNSzqnQJokdjRWLYhayGeU=CmfXEusxiNSzqnQJokdjRWLYhayGKH(CmfXEusxiNSzqnQJokdjRWLYhayGtI+1)
   CmfXEusxiNSzqnQJokdjRWLYhayGrc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.add_dir(CmfXEusxiNSzqnQJokdjRWLYhayGrF,sublabel=CmfXEusxiNSzqnQJokdjRWLYhayGeU,img=CmfXEusxiNSzqnQJokdjRWLYhayGrc,infoLabels=CmfXEusxiNSzqnQJokdjRWLYhayGKD,isFolder=CmfXEusxiNSzqnQJokdjRWLYhayGKO,params=CmfXEusxiNSzqnQJokdjRWLYhayGrb)
  if CmfXEusxiNSzqnQJokdjRWLYhayGtT=='movie':xbmcplugin.setContent(CmfXEusxiNSzqnQJokdjRWLYhayGvU._addon_handle,'movies')
  else:xbmcplugin.setContent(CmfXEusxiNSzqnQJokdjRWLYhayGvU._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(CmfXEusxiNSzqnQJokdjRWLYhayGvU._addon_handle,cacheToDisc=CmfXEusxiNSzqnQJokdjRWLYhayGKP)
 def dp_Watch_List(CmfXEusxiNSzqnQJokdjRWLYhayGvU,args):
  CmfXEusxiNSzqnQJokdjRWLYhayGtT =args.get('sType')
  CmfXEusxiNSzqnQJokdjRWLYhayGrV=CmfXEusxiNSzqnQJokdjRWLYhayGvU.get_settings_direct_replay()
  CmfXEusxiNSzqnQJokdjRWLYhayGtw=CmfXEusxiNSzqnQJokdjRWLYhayGvU.Load_List_File(CmfXEusxiNSzqnQJokdjRWLYhayGtT)
  for CmfXEusxiNSzqnQJokdjRWLYhayGtH in CmfXEusxiNSzqnQJokdjRWLYhayGtw:
   CmfXEusxiNSzqnQJokdjRWLYhayGtO=CmfXEusxiNSzqnQJokdjRWLYhayGKA(urllib.parse.parse_qsl(CmfXEusxiNSzqnQJokdjRWLYhayGtH))
   CmfXEusxiNSzqnQJokdjRWLYhayGeV =CmfXEusxiNSzqnQJokdjRWLYhayGtO.get('code').strip()
   CmfXEusxiNSzqnQJokdjRWLYhayGrF =CmfXEusxiNSzqnQJokdjRWLYhayGtO.get('title').strip()
   CmfXEusxiNSzqnQJokdjRWLYhayGeU =CmfXEusxiNSzqnQJokdjRWLYhayGtO.get('subtitle').strip()
   if CmfXEusxiNSzqnQJokdjRWLYhayGeU=='None':CmfXEusxiNSzqnQJokdjRWLYhayGeU=''
   CmfXEusxiNSzqnQJokdjRWLYhayGer=CmfXEusxiNSzqnQJokdjRWLYhayGtO.get('img').strip()
   CmfXEusxiNSzqnQJokdjRWLYhayGtp =CmfXEusxiNSzqnQJokdjRWLYhayGtO.get('videoid').strip()
   try:
    CmfXEusxiNSzqnQJokdjRWLYhayGer=CmfXEusxiNSzqnQJokdjRWLYhayGer.replace('\'','\"')
    CmfXEusxiNSzqnQJokdjRWLYhayGer=json.loads(CmfXEusxiNSzqnQJokdjRWLYhayGer)
   except:
    CmfXEusxiNSzqnQJokdjRWLYhayGKD
   CmfXEusxiNSzqnQJokdjRWLYhayGtb={'plot':'%s\n%s'%(CmfXEusxiNSzqnQJokdjRWLYhayGrF,CmfXEusxiNSzqnQJokdjRWLYhayGeU)}
   if CmfXEusxiNSzqnQJokdjRWLYhayGtT=='vod':
    if CmfXEusxiNSzqnQJokdjRWLYhayGrV==CmfXEusxiNSzqnQJokdjRWLYhayGKP or CmfXEusxiNSzqnQJokdjRWLYhayGtp==CmfXEusxiNSzqnQJokdjRWLYhayGKD:
     CmfXEusxiNSzqnQJokdjRWLYhayGtb['mediatype']='tvshow'
     CmfXEusxiNSzqnQJokdjRWLYhayGrb={'mode':'SEASON_LIST','videoid':CmfXEusxiNSzqnQJokdjRWLYhayGtp,'vidtype':'contentid',}
     CmfXEusxiNSzqnQJokdjRWLYhayGrI=CmfXEusxiNSzqnQJokdjRWLYhayGKO
    else:
     CmfXEusxiNSzqnQJokdjRWLYhayGtb['mediatype']='episode'
     CmfXEusxiNSzqnQJokdjRWLYhayGrb={'mode':'VOD','programid':CmfXEusxiNSzqnQJokdjRWLYhayGeV,'contentid':CmfXEusxiNSzqnQJokdjRWLYhayGtp,'title':CmfXEusxiNSzqnQJokdjRWLYhayGrF,'subtitle':CmfXEusxiNSzqnQJokdjRWLYhayGeU,'thumbnail':CmfXEusxiNSzqnQJokdjRWLYhayGer}
     CmfXEusxiNSzqnQJokdjRWLYhayGrI=CmfXEusxiNSzqnQJokdjRWLYhayGKP
   else:
    CmfXEusxiNSzqnQJokdjRWLYhayGtb['mediatype']='movie'
    CmfXEusxiNSzqnQJokdjRWLYhayGrb={'mode':'MOVIE','contentid':CmfXEusxiNSzqnQJokdjRWLYhayGeV,'title':CmfXEusxiNSzqnQJokdjRWLYhayGrF,'subtitle':CmfXEusxiNSzqnQJokdjRWLYhayGeU,'thumbnail':CmfXEusxiNSzqnQJokdjRWLYhayGer}
    CmfXEusxiNSzqnQJokdjRWLYhayGrI=CmfXEusxiNSzqnQJokdjRWLYhayGKP
   CmfXEusxiNSzqnQJokdjRWLYhayGtg={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':CmfXEusxiNSzqnQJokdjRWLYhayGeV,'vType':CmfXEusxiNSzqnQJokdjRWLYhayGtT,}
   CmfXEusxiNSzqnQJokdjRWLYhayGtA=urllib.parse.urlencode(CmfXEusxiNSzqnQJokdjRWLYhayGtg)
   CmfXEusxiNSzqnQJokdjRWLYhayGtc=[('선택된 시청이력 ( %s ) 삭제'%(CmfXEusxiNSzqnQJokdjRWLYhayGrF),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(CmfXEusxiNSzqnQJokdjRWLYhayGtA))]
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.add_dir(CmfXEusxiNSzqnQJokdjRWLYhayGrF,sublabel=CmfXEusxiNSzqnQJokdjRWLYhayGeU,img=CmfXEusxiNSzqnQJokdjRWLYhayGer,infoLabels=CmfXEusxiNSzqnQJokdjRWLYhayGtb,isFolder=CmfXEusxiNSzqnQJokdjRWLYhayGrI,params=CmfXEusxiNSzqnQJokdjRWLYhayGrb,ContextMenu=CmfXEusxiNSzqnQJokdjRWLYhayGtc)
  CmfXEusxiNSzqnQJokdjRWLYhayGtb={'plot':'시청목록을 삭제합니다.'}
  CmfXEusxiNSzqnQJokdjRWLYhayGrF='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  CmfXEusxiNSzqnQJokdjRWLYhayGrb={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':CmfXEusxiNSzqnQJokdjRWLYhayGtT,}
  CmfXEusxiNSzqnQJokdjRWLYhayGrc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  CmfXEusxiNSzqnQJokdjRWLYhayGvU.add_dir(CmfXEusxiNSzqnQJokdjRWLYhayGrF,sublabel='',img=CmfXEusxiNSzqnQJokdjRWLYhayGrc,infoLabels=CmfXEusxiNSzqnQJokdjRWLYhayGtb,isFolder=CmfXEusxiNSzqnQJokdjRWLYhayGKP,params=CmfXEusxiNSzqnQJokdjRWLYhayGrb,isLink=CmfXEusxiNSzqnQJokdjRWLYhayGKO)
  if CmfXEusxiNSzqnQJokdjRWLYhayGtT=='movie':xbmcplugin.setContent(CmfXEusxiNSzqnQJokdjRWLYhayGvU._addon_handle,'movies')
  else:xbmcplugin.setContent(CmfXEusxiNSzqnQJokdjRWLYhayGvU._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(CmfXEusxiNSzqnQJokdjRWLYhayGvU._addon_handle,cacheToDisc=CmfXEusxiNSzqnQJokdjRWLYhayGKP)
 def Load_List_File(CmfXEusxiNSzqnQJokdjRWLYhayGvU,stype): 
  try:
   if stype=='search':
    CmfXEusxiNSzqnQJokdjRWLYhayGeM=CmfXEusxiNSzqnQJokdjRWLYhayGvK
   elif stype in['vod','movie']:
    CmfXEusxiNSzqnQJokdjRWLYhayGeM=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   else:
    return[]
   fp=CmfXEusxiNSzqnQJokdjRWLYhayGKp(CmfXEusxiNSzqnQJokdjRWLYhayGeM,'r',-1,'utf-8')
   CmfXEusxiNSzqnQJokdjRWLYhayGeD=fp.readlines()
   fp.close()
  except:
   CmfXEusxiNSzqnQJokdjRWLYhayGeD=[]
  return CmfXEusxiNSzqnQJokdjRWLYhayGeD
 def Save_Watched_List(CmfXEusxiNSzqnQJokdjRWLYhayGvU,CmfXEusxiNSzqnQJokdjRWLYhayGBb,CmfXEusxiNSzqnQJokdjRWLYhayGvD):
  try:
   CmfXEusxiNSzqnQJokdjRWLYhayGeF=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%CmfXEusxiNSzqnQJokdjRWLYhayGBb))
   CmfXEusxiNSzqnQJokdjRWLYhayGeO=CmfXEusxiNSzqnQJokdjRWLYhayGvU.Load_List_File(CmfXEusxiNSzqnQJokdjRWLYhayGBb) 
   fp=CmfXEusxiNSzqnQJokdjRWLYhayGKp(CmfXEusxiNSzqnQJokdjRWLYhayGeF,'w',-1,'utf-8')
   CmfXEusxiNSzqnQJokdjRWLYhayGeP=urllib.parse.urlencode(CmfXEusxiNSzqnQJokdjRWLYhayGvD)
   CmfXEusxiNSzqnQJokdjRWLYhayGeP=CmfXEusxiNSzqnQJokdjRWLYhayGeP+'\n'
   fp.write(CmfXEusxiNSzqnQJokdjRWLYhayGeP)
   CmfXEusxiNSzqnQJokdjRWLYhayGeg=0
   for CmfXEusxiNSzqnQJokdjRWLYhayGeA in CmfXEusxiNSzqnQJokdjRWLYhayGeO:
    CmfXEusxiNSzqnQJokdjRWLYhayGec=CmfXEusxiNSzqnQJokdjRWLYhayGKA(urllib.parse.parse_qsl(CmfXEusxiNSzqnQJokdjRWLYhayGeA))
    CmfXEusxiNSzqnQJokdjRWLYhayGeb=CmfXEusxiNSzqnQJokdjRWLYhayGvD.get('code').strip()
    CmfXEusxiNSzqnQJokdjRWLYhayGeI=CmfXEusxiNSzqnQJokdjRWLYhayGec.get('code').strip()
    if CmfXEusxiNSzqnQJokdjRWLYhayGBb=='vod' and CmfXEusxiNSzqnQJokdjRWLYhayGvU.get_settings_direct_replay()==CmfXEusxiNSzqnQJokdjRWLYhayGKO:
     CmfXEusxiNSzqnQJokdjRWLYhayGeb=CmfXEusxiNSzqnQJokdjRWLYhayGvD.get('videoid').strip()
     CmfXEusxiNSzqnQJokdjRWLYhayGeI=CmfXEusxiNSzqnQJokdjRWLYhayGec.get('videoid').strip()if CmfXEusxiNSzqnQJokdjRWLYhayGeI!=CmfXEusxiNSzqnQJokdjRWLYhayGKD else '-'
    if CmfXEusxiNSzqnQJokdjRWLYhayGeb!=CmfXEusxiNSzqnQJokdjRWLYhayGeI:
     fp.write(CmfXEusxiNSzqnQJokdjRWLYhayGeA)
     CmfXEusxiNSzqnQJokdjRWLYhayGeg+=1
     if CmfXEusxiNSzqnQJokdjRWLYhayGeg>=50:break
   fp.close()
  except:
   CmfXEusxiNSzqnQJokdjRWLYhayGKD
 def dp_History_Remove(CmfXEusxiNSzqnQJokdjRWLYhayGvU,args):
  CmfXEusxiNSzqnQJokdjRWLYhayGew=args.get('delType')
  CmfXEusxiNSzqnQJokdjRWLYhayGeH =args.get('sKey')
  CmfXEusxiNSzqnQJokdjRWLYhayGep =args.get('vType')
  CmfXEusxiNSzqnQJokdjRWLYhayGvO=xbmcgui.Dialog()
  if CmfXEusxiNSzqnQJokdjRWLYhayGew=='SEARCH_ALL':
   CmfXEusxiNSzqnQJokdjRWLYhayGlv=CmfXEusxiNSzqnQJokdjRWLYhayGvO.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif CmfXEusxiNSzqnQJokdjRWLYhayGew=='SEARCH_ONE':
   CmfXEusxiNSzqnQJokdjRWLYhayGlv=CmfXEusxiNSzqnQJokdjRWLYhayGvO.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif CmfXEusxiNSzqnQJokdjRWLYhayGew=='WATCH_ALL':
   CmfXEusxiNSzqnQJokdjRWLYhayGlv=CmfXEusxiNSzqnQJokdjRWLYhayGvO.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif CmfXEusxiNSzqnQJokdjRWLYhayGew=='WATCH_ONE':
   CmfXEusxiNSzqnQJokdjRWLYhayGlv=CmfXEusxiNSzqnQJokdjRWLYhayGvO.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if CmfXEusxiNSzqnQJokdjRWLYhayGlv==CmfXEusxiNSzqnQJokdjRWLYhayGKP:sys.exit()
  if CmfXEusxiNSzqnQJokdjRWLYhayGew=='SEARCH_ALL':
   if os.path.isfile(CmfXEusxiNSzqnQJokdjRWLYhayGvK):os.remove(CmfXEusxiNSzqnQJokdjRWLYhayGvK)
  elif CmfXEusxiNSzqnQJokdjRWLYhayGew=='SEARCH_ONE':
   try:
    CmfXEusxiNSzqnQJokdjRWLYhayGeM=CmfXEusxiNSzqnQJokdjRWLYhayGvK
    CmfXEusxiNSzqnQJokdjRWLYhayGeO=CmfXEusxiNSzqnQJokdjRWLYhayGvU.Load_List_File('search') 
    fp=CmfXEusxiNSzqnQJokdjRWLYhayGKp(CmfXEusxiNSzqnQJokdjRWLYhayGeM,'w',-1,'utf-8')
    for CmfXEusxiNSzqnQJokdjRWLYhayGeA in CmfXEusxiNSzqnQJokdjRWLYhayGeO:
     CmfXEusxiNSzqnQJokdjRWLYhayGec=CmfXEusxiNSzqnQJokdjRWLYhayGKA(urllib.parse.parse_qsl(CmfXEusxiNSzqnQJokdjRWLYhayGeA))
     CmfXEusxiNSzqnQJokdjRWLYhayGlr=CmfXEusxiNSzqnQJokdjRWLYhayGec.get('skey').strip()
     if CmfXEusxiNSzqnQJokdjRWLYhayGeH!=CmfXEusxiNSzqnQJokdjRWLYhayGlr:
      fp.write(CmfXEusxiNSzqnQJokdjRWLYhayGeA)
    fp.close()
   except:
    CmfXEusxiNSzqnQJokdjRWLYhayGKD
  elif CmfXEusxiNSzqnQJokdjRWLYhayGew=='WATCH_ALL':
   CmfXEusxiNSzqnQJokdjRWLYhayGeM=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%CmfXEusxiNSzqnQJokdjRWLYhayGep))
   if os.path.isfile(CmfXEusxiNSzqnQJokdjRWLYhayGeM):os.remove(CmfXEusxiNSzqnQJokdjRWLYhayGeM)
  elif CmfXEusxiNSzqnQJokdjRWLYhayGew=='WATCH_ONE':
   CmfXEusxiNSzqnQJokdjRWLYhayGeM=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%CmfXEusxiNSzqnQJokdjRWLYhayGep))
   try:
    CmfXEusxiNSzqnQJokdjRWLYhayGeO=CmfXEusxiNSzqnQJokdjRWLYhayGvU.Load_List_File(CmfXEusxiNSzqnQJokdjRWLYhayGep) 
    fp=CmfXEusxiNSzqnQJokdjRWLYhayGKp(CmfXEusxiNSzqnQJokdjRWLYhayGeM,'w',-1,'utf-8')
    for CmfXEusxiNSzqnQJokdjRWLYhayGeA in CmfXEusxiNSzqnQJokdjRWLYhayGeO:
     CmfXEusxiNSzqnQJokdjRWLYhayGec=CmfXEusxiNSzqnQJokdjRWLYhayGKA(urllib.parse.parse_qsl(CmfXEusxiNSzqnQJokdjRWLYhayGeA))
     CmfXEusxiNSzqnQJokdjRWLYhayGlr=CmfXEusxiNSzqnQJokdjRWLYhayGec.get('code').strip()
     if CmfXEusxiNSzqnQJokdjRWLYhayGeH!=CmfXEusxiNSzqnQJokdjRWLYhayGlr:
      fp.write(CmfXEusxiNSzqnQJokdjRWLYhayGeA)
    fp.close()
   except:
    CmfXEusxiNSzqnQJokdjRWLYhayGKD
  xbmc.executebuiltin("Container.Refresh")
 def Save_Searched_List(CmfXEusxiNSzqnQJokdjRWLYhayGvU,CmfXEusxiNSzqnQJokdjRWLYhayGtr):
  try:
   CmfXEusxiNSzqnQJokdjRWLYhayGlt=CmfXEusxiNSzqnQJokdjRWLYhayGvK
   CmfXEusxiNSzqnQJokdjRWLYhayGeO=CmfXEusxiNSzqnQJokdjRWLYhayGvU.Load_List_File('search') 
   CmfXEusxiNSzqnQJokdjRWLYhayGle={'skey':CmfXEusxiNSzqnQJokdjRWLYhayGtr.strip()}
   fp=CmfXEusxiNSzqnQJokdjRWLYhayGKp(CmfXEusxiNSzqnQJokdjRWLYhayGlt,'w',-1,'utf-8')
   CmfXEusxiNSzqnQJokdjRWLYhayGeP=urllib.parse.urlencode(CmfXEusxiNSzqnQJokdjRWLYhayGle)
   CmfXEusxiNSzqnQJokdjRWLYhayGeP=CmfXEusxiNSzqnQJokdjRWLYhayGeP+'\n'
   fp.write(CmfXEusxiNSzqnQJokdjRWLYhayGeP)
   CmfXEusxiNSzqnQJokdjRWLYhayGeg=0
   for CmfXEusxiNSzqnQJokdjRWLYhayGeA in CmfXEusxiNSzqnQJokdjRWLYhayGeO:
    CmfXEusxiNSzqnQJokdjRWLYhayGec=CmfXEusxiNSzqnQJokdjRWLYhayGKA(urllib.parse.parse_qsl(CmfXEusxiNSzqnQJokdjRWLYhayGeA))
    CmfXEusxiNSzqnQJokdjRWLYhayGeb=CmfXEusxiNSzqnQJokdjRWLYhayGle.get('skey').strip()
    CmfXEusxiNSzqnQJokdjRWLYhayGeI=CmfXEusxiNSzqnQJokdjRWLYhayGec.get('skey').strip()
    if CmfXEusxiNSzqnQJokdjRWLYhayGeb!=CmfXEusxiNSzqnQJokdjRWLYhayGeI:
     fp.write(CmfXEusxiNSzqnQJokdjRWLYhayGeA)
     CmfXEusxiNSzqnQJokdjRWLYhayGeg+=1
     if CmfXEusxiNSzqnQJokdjRWLYhayGeg>=50:break
   fp.close()
  except:
   CmfXEusxiNSzqnQJokdjRWLYhayGKD
 def dp_Global_Search(CmfXEusxiNSzqnQJokdjRWLYhayGvU,args):
  CmfXEusxiNSzqnQJokdjRWLYhayGtl=args.get('mode')
  if CmfXEusxiNSzqnQJokdjRWLYhayGtl=='TOTAL_SEARCH':
   CmfXEusxiNSzqnQJokdjRWLYhayGlT='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   CmfXEusxiNSzqnQJokdjRWLYhayGlT='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(CmfXEusxiNSzqnQJokdjRWLYhayGlT)
 def dp_Bookmark_Menu(CmfXEusxiNSzqnQJokdjRWLYhayGvU,args):
  CmfXEusxiNSzqnQJokdjRWLYhayGlT='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(CmfXEusxiNSzqnQJokdjRWLYhayGlT)
 def login_main(CmfXEusxiNSzqnQJokdjRWLYhayGvU):
  (CmfXEusxiNSzqnQJokdjRWLYhayGlB,CmfXEusxiNSzqnQJokdjRWLYhayGlK,CmfXEusxiNSzqnQJokdjRWLYhayGlU)=CmfXEusxiNSzqnQJokdjRWLYhayGvU.get_settings_account()
  if not(CmfXEusxiNSzqnQJokdjRWLYhayGlB and CmfXEusxiNSzqnQJokdjRWLYhayGlK):
   CmfXEusxiNSzqnQJokdjRWLYhayGvO=xbmcgui.Dialog()
   CmfXEusxiNSzqnQJokdjRWLYhayGlv=CmfXEusxiNSzqnQJokdjRWLYhayGvO.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if CmfXEusxiNSzqnQJokdjRWLYhayGlv==CmfXEusxiNSzqnQJokdjRWLYhayGKO:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if CmfXEusxiNSzqnQJokdjRWLYhayGvU.cookiefile_check()==CmfXEusxiNSzqnQJokdjRWLYhayGKO:return
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   CmfXEusxiNSzqnQJokdjRWLYhayGlV=0
   while CmfXEusxiNSzqnQJokdjRWLYhayGKO:
    CmfXEusxiNSzqnQJokdjRWLYhayGlV+=1
    time.sleep(0.05)
    if CmfXEusxiNSzqnQJokdjRWLYhayGlV>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  CmfXEusxiNSzqnQJokdjRWLYhayGlM=CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.GetCredential_new(CmfXEusxiNSzqnQJokdjRWLYhayGlB,CmfXEusxiNSzqnQJokdjRWLYhayGlK,CmfXEusxiNSzqnQJokdjRWLYhayGlU)
  if CmfXEusxiNSzqnQJokdjRWLYhayGlM:CmfXEusxiNSzqnQJokdjRWLYhayGvU.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
  if CmfXEusxiNSzqnQJokdjRWLYhayGlM==CmfXEusxiNSzqnQJokdjRWLYhayGKP:
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_setEpOrderby(CmfXEusxiNSzqnQJokdjRWLYhayGvU,args):
  CmfXEusxiNSzqnQJokdjRWLYhayGrM =args.get('orderby')
  CmfXEusxiNSzqnQJokdjRWLYhayGvU.set_winEpisodeOrderby(CmfXEusxiNSzqnQJokdjRWLYhayGrM)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(CmfXEusxiNSzqnQJokdjRWLYhayGvU,args):
  CmfXEusxiNSzqnQJokdjRWLYhayGtl =args.get('mode')
  CmfXEusxiNSzqnQJokdjRWLYhayGlD =args.get('contentid')
  CmfXEusxiNSzqnQJokdjRWLYhayGlF =args.get('pvrmode')
  CmfXEusxiNSzqnQJokdjRWLYhayGlO=CmfXEusxiNSzqnQJokdjRWLYhayGvU.get_selQuality()
  CmfXEusxiNSzqnQJokdjRWLYhayGre =CmfXEusxiNSzqnQJokdjRWLYhayGvU.get_settings_play()
  CmfXEusxiNSzqnQJokdjRWLYhayGvU.addon_log(CmfXEusxiNSzqnQJokdjRWLYhayGlD+' - '+CmfXEusxiNSzqnQJokdjRWLYhayGtl)
  if CmfXEusxiNSzqnQJokdjRWLYhayGtl=='SPORTS':
   CmfXEusxiNSzqnQJokdjRWLYhayGlP=CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.GetSportsURL(CmfXEusxiNSzqnQJokdjRWLYhayGlD,CmfXEusxiNSzqnQJokdjRWLYhayGlO)
  else:
   CmfXEusxiNSzqnQJokdjRWLYhayGlP=CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.GetStreamingURL(CmfXEusxiNSzqnQJokdjRWLYhayGtl,CmfXEusxiNSzqnQJokdjRWLYhayGlD,CmfXEusxiNSzqnQJokdjRWLYhayGlO,CmfXEusxiNSzqnQJokdjRWLYhayGlF,playOption=CmfXEusxiNSzqnQJokdjRWLYhayGre)
  CmfXEusxiNSzqnQJokdjRWLYhayGlg={'user-agent':CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.USER_AGENT}
  CmfXEusxiNSzqnQJokdjRWLYhayGlA=CmfXEusxiNSzqnQJokdjRWLYhayGlP['stream_cookie'] 
  CmfXEusxiNSzqnQJokdjRWLYhayGlc=CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.make_stream_header(CmfXEusxiNSzqnQJokdjRWLYhayGlg,CmfXEusxiNSzqnQJokdjRWLYhayGlA)
  CmfXEusxiNSzqnQJokdjRWLYhayGlb='{}|{}'.format(CmfXEusxiNSzqnQJokdjRWLYhayGlP['stream_url'],CmfXEusxiNSzqnQJokdjRWLYhayGlc)
  CmfXEusxiNSzqnQJokdjRWLYhayGvU.addon_log('surl : '+CmfXEusxiNSzqnQJokdjRWLYhayGlb)
  if CmfXEusxiNSzqnQJokdjRWLYhayGlP['stream_url']=='':
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.addon_noti(__language__(30907).encode('utf8'))
   return
  CmfXEusxiNSzqnQJokdjRWLYhayGrl,CmfXEusxiNSzqnQJokdjRWLYhayGrT=CmfXEusxiNSzqnQJokdjRWLYhayGvU.get_settings_proxyport()
  CmfXEusxiNSzqnQJokdjRWLYhayGlI=urllib.parse.urlparse(CmfXEusxiNSzqnQJokdjRWLYhayGlP['stream_url'])
  CmfXEusxiNSzqnQJokdjRWLYhayGlI=CmfXEusxiNSzqnQJokdjRWLYhayGlI.path.strip('/').split('/')
  CmfXEusxiNSzqnQJokdjRWLYhayGlI=CmfXEusxiNSzqnQJokdjRWLYhayGlI[CmfXEusxiNSzqnQJokdjRWLYhayGKI(CmfXEusxiNSzqnQJokdjRWLYhayGlI)-1] 
  if (CmfXEusxiNSzqnQJokdjRWLYhayGrl==CmfXEusxiNSzqnQJokdjRWLYhayGKO and args.get('mode')in['VOD','MOVIE']and(CmfXEusxiNSzqnQJokdjRWLYhayGlP['playParam']['hdr']=='hdr' or CmfXEusxiNSzqnQJokdjRWLYhayGlP['playParam']['uhd']=='uhd')):
   if CmfXEusxiNSzqnQJokdjRWLYhayGlI.split('.')[1]=='mpd':
    CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.Wavve_Parse_mpd(CmfXEusxiNSzqnQJokdjRWLYhayGlP)
   else:
    CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.Wavve_Parse_m3u8(CmfXEusxiNSzqnQJokdjRWLYhayGlP)
   CmfXEusxiNSzqnQJokdjRWLYhayGlw={'addon':'wavvem','playOption':CmfXEusxiNSzqnQJokdjRWLYhayGre,}
   CmfXEusxiNSzqnQJokdjRWLYhayGlw=json.dumps(CmfXEusxiNSzqnQJokdjRWLYhayGlw,separators=(',',':'))
   CmfXEusxiNSzqnQJokdjRWLYhayGlw=base64.standard_b64encode(CmfXEusxiNSzqnQJokdjRWLYhayGlw.encode()).decode('utf-8')
   CmfXEusxiNSzqnQJokdjRWLYhayGlb ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(CmfXEusxiNSzqnQJokdjRWLYhayGrT,CmfXEusxiNSzqnQJokdjRWLYhayGlb,CmfXEusxiNSzqnQJokdjRWLYhayGlw)
  CmfXEusxiNSzqnQJokdjRWLYhayGvU.addon_log('surl : '+CmfXEusxiNSzqnQJokdjRWLYhayGlb)
  CmfXEusxiNSzqnQJokdjRWLYhayGlH=xbmcgui.ListItem(path=CmfXEusxiNSzqnQJokdjRWLYhayGlb)
  if CmfXEusxiNSzqnQJokdjRWLYhayGlP['stream_drm']:
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.addon_log('!!streaming_drm!!')
   inputstreamhelper.Helper('mpd',drm='com.widevine.alpha').check_inputstream()
   if 'licensetoken' in CmfXEusxiNSzqnQJokdjRWLYhayGlP['stream_drm']:
    CmfXEusxiNSzqnQJokdjRWLYhayGTv=CmfXEusxiNSzqnQJokdjRWLYhayGlP['stream_drm']['licensetoken']
    CmfXEusxiNSzqnQJokdjRWLYhayGTr =CmfXEusxiNSzqnQJokdjRWLYhayGlP['stream_drm']['licenseurl']
    if CmfXEusxiNSzqnQJokdjRWLYhayGtl=='MOVIE':
     CmfXEusxiNSzqnQJokdjRWLYhayGTt='https://www.wavve.com/player/movie?movieid=%s'%CmfXEusxiNSzqnQJokdjRWLYhayGlD
    else:
     CmfXEusxiNSzqnQJokdjRWLYhayGTt='https://www.wavve.com/player/vod?programid=%s&page=1'%CmfXEusxiNSzqnQJokdjRWLYhayGlD
    CmfXEusxiNSzqnQJokdjRWLYhayGTe={'content-type':'application/octet-stream','origin':'https://www.wavve.com','License-Token':CmfXEusxiNSzqnQJokdjRWLYhayGTv,'referer':CmfXEusxiNSzqnQJokdjRWLYhayGTt,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.USER_AGENT,}
   else:
    CmfXEusxiNSzqnQJokdjRWLYhayGTv=CmfXEusxiNSzqnQJokdjRWLYhayGlP['stream_drm']['customdata']
    CmfXEusxiNSzqnQJokdjRWLYhayGTr =CmfXEusxiNSzqnQJokdjRWLYhayGlP['stream_drm']['drmhost']
    if CmfXEusxiNSzqnQJokdjRWLYhayGtl=='MOVIE':
     CmfXEusxiNSzqnQJokdjRWLYhayGTt='https://www.wavve.com/player/movie?movieid=%s'%CmfXEusxiNSzqnQJokdjRWLYhayGlD
    else:
     CmfXEusxiNSzqnQJokdjRWLYhayGTt='https://www.wavve.com/player/vod?programid=%s&page=1'%CmfXEusxiNSzqnQJokdjRWLYhayGlD
    CmfXEusxiNSzqnQJokdjRWLYhayGTe={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':CmfXEusxiNSzqnQJokdjRWLYhayGTv,'referer':CmfXEusxiNSzqnQJokdjRWLYhayGTt,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.USER_AGENT,}
   CmfXEusxiNSzqnQJokdjRWLYhayGTl=CmfXEusxiNSzqnQJokdjRWLYhayGTr+'|'+urllib.parse.urlencode(CmfXEusxiNSzqnQJokdjRWLYhayGTe)+'|R{SSM}|'
   CmfXEusxiNSzqnQJokdjRWLYhayGlH.setProperty('inputstream','inputstream.adaptive')
   if CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.KodiVersion<=20:
    CmfXEusxiNSzqnQJokdjRWLYhayGlH.setProperty('inputstream.adaptive.manifest_type','mpd')
   CmfXEusxiNSzqnQJokdjRWLYhayGlH.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
   CmfXEusxiNSzqnQJokdjRWLYhayGlH.setProperty('inputstream.adaptive.license_key',CmfXEusxiNSzqnQJokdjRWLYhayGTl)
   CmfXEusxiNSzqnQJokdjRWLYhayGlH.setProperty('inputstream.adaptive.stream_headers',CmfXEusxiNSzqnQJokdjRWLYhayGlc)
   CmfXEusxiNSzqnQJokdjRWLYhayGlH.setProperty('inputstream.adaptive.manifest_headers',CmfXEusxiNSzqnQJokdjRWLYhayGlc)
  elif CmfXEusxiNSzqnQJokdjRWLYhayGtl in['VOD','MOVIE']:
   CmfXEusxiNSzqnQJokdjRWLYhayGlH.setContentLookup(CmfXEusxiNSzqnQJokdjRWLYhayGKP)
   CmfXEusxiNSzqnQJokdjRWLYhayGlH.setMimeType('application/x-mpegURL')
   CmfXEusxiNSzqnQJokdjRWLYhayGlH.setProperty('inputstream','inputstream.adaptive')
   if CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.KodiVersion<=20:
    if CmfXEusxiNSzqnQJokdjRWLYhayGlP['stream_action']=='hls':
     CmfXEusxiNSzqnQJokdjRWLYhayGlH.setProperty('inputstream.adaptive.manifest_type','hls')
    else:
     CmfXEusxiNSzqnQJokdjRWLYhayGlH.setProperty('inputstream.adaptive.manifest_type','mpd')
   CmfXEusxiNSzqnQJokdjRWLYhayGlH.setProperty('inputstream.adaptive.stream_headers',CmfXEusxiNSzqnQJokdjRWLYhayGlc)
   CmfXEusxiNSzqnQJokdjRWLYhayGlH.setProperty('inputstream.adaptive.manifest_headers',CmfXEusxiNSzqnQJokdjRWLYhayGlc)
  if CmfXEusxiNSzqnQJokdjRWLYhayGlP['stream_vtt']:
   CmfXEusxiNSzqnQJokdjRWLYhayGlH.setSubtitles([CmfXEusxiNSzqnQJokdjRWLYhayGlP['stream_vtt']])
  xbmcplugin.setResolvedUrl(CmfXEusxiNSzqnQJokdjRWLYhayGvU._addon_handle,CmfXEusxiNSzqnQJokdjRWLYhayGKO,CmfXEusxiNSzqnQJokdjRWLYhayGlH)
  CmfXEusxiNSzqnQJokdjRWLYhayGTB=CmfXEusxiNSzqnQJokdjRWLYhayGKP
  if CmfXEusxiNSzqnQJokdjRWLYhayGlP['stream_preview']:
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.addon_noti(CmfXEusxiNSzqnQJokdjRWLYhayGlP['stream_preview'].encode('utf-8'))
   CmfXEusxiNSzqnQJokdjRWLYhayGTB=CmfXEusxiNSzqnQJokdjRWLYhayGKO
  else:
   if '/preview.' in urllib.parse.urlsplit(CmfXEusxiNSzqnQJokdjRWLYhayGlP['stream_url']).path:
    CmfXEusxiNSzqnQJokdjRWLYhayGvU.addon_noti(__language__(30908).encode('utf8'))
    CmfXEusxiNSzqnQJokdjRWLYhayGTB=CmfXEusxiNSzqnQJokdjRWLYhayGKO
  try:
   CmfXEusxiNSzqnQJokdjRWLYhayGTK=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and CmfXEusxiNSzqnQJokdjRWLYhayGTB==CmfXEusxiNSzqnQJokdjRWLYhayGKP and CmfXEusxiNSzqnQJokdjRWLYhayGTK!='-':
    CmfXEusxiNSzqnQJokdjRWLYhayGrb={'code':CmfXEusxiNSzqnQJokdjRWLYhayGTK,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    CmfXEusxiNSzqnQJokdjRWLYhayGvU.Save_Watched_List(args.get('mode').lower(),CmfXEusxiNSzqnQJokdjRWLYhayGrb)
  except:
   CmfXEusxiNSzqnQJokdjRWLYhayGKD
 def logout(CmfXEusxiNSzqnQJokdjRWLYhayGvU):
  CmfXEusxiNSzqnQJokdjRWLYhayGvO=xbmcgui.Dialog()
  CmfXEusxiNSzqnQJokdjRWLYhayGlv=CmfXEusxiNSzqnQJokdjRWLYhayGvO.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if CmfXEusxiNSzqnQJokdjRWLYhayGlv==CmfXEusxiNSzqnQJokdjRWLYhayGKP:sys.exit()
  CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.Init_WV_Total()
  if os.path.isfile(CmfXEusxiNSzqnQJokdjRWLYhayGvB):os.remove(CmfXEusxiNSzqnQJokdjRWLYhayGvB)
  CmfXEusxiNSzqnQJokdjRWLYhayGvU.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(CmfXEusxiNSzqnQJokdjRWLYhayGvU):
  CmfXEusxiNSzqnQJokdjRWLYhayGTU =CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.Get_Now_Datetime()
  CmfXEusxiNSzqnQJokdjRWLYhayGTV=CmfXEusxiNSzqnQJokdjRWLYhayGTU+datetime.timedelta(days=CmfXEusxiNSzqnQJokdjRWLYhayGKF(__addon__.getSetting('cache_ttl')))
  (CmfXEusxiNSzqnQJokdjRWLYhayGlB,CmfXEusxiNSzqnQJokdjRWLYhayGlK,CmfXEusxiNSzqnQJokdjRWLYhayGlU)=CmfXEusxiNSzqnQJokdjRWLYhayGvU.get_settings_account()
  CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.Save_session_acount(CmfXEusxiNSzqnQJokdjRWLYhayGlB,CmfXEusxiNSzqnQJokdjRWLYhayGlK,CmfXEusxiNSzqnQJokdjRWLYhayGlU)
  CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.WV['account']['token_limit']=CmfXEusxiNSzqnQJokdjRWLYhayGTV.strftime('%Y%m%d')
  CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.JsonFile_Save(CmfXEusxiNSzqnQJokdjRWLYhayGvB,CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.WV)
 def cookiefile_check(CmfXEusxiNSzqnQJokdjRWLYhayGvU):
  CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.WV=CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.JsonFile_Load(CmfXEusxiNSzqnQJokdjRWLYhayGvB)
  if 'account' not in CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.WV:
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.Init_WV_Total()
   return CmfXEusxiNSzqnQJokdjRWLYhayGKP
  if 'uuid' not in CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.WV.get('cookies'):
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.Init_WV_Total()
   return CmfXEusxiNSzqnQJokdjRWLYhayGKP
  (CmfXEusxiNSzqnQJokdjRWLYhayGTM,CmfXEusxiNSzqnQJokdjRWLYhayGTD,CmfXEusxiNSzqnQJokdjRWLYhayGTF)=CmfXEusxiNSzqnQJokdjRWLYhayGvU.get_settings_account()
  (CmfXEusxiNSzqnQJokdjRWLYhayGTO,CmfXEusxiNSzqnQJokdjRWLYhayGTP,CmfXEusxiNSzqnQJokdjRWLYhayGTg)=CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.Load_session_acount()
  if CmfXEusxiNSzqnQJokdjRWLYhayGTM!=CmfXEusxiNSzqnQJokdjRWLYhayGTO or CmfXEusxiNSzqnQJokdjRWLYhayGTD!=CmfXEusxiNSzqnQJokdjRWLYhayGTP or CmfXEusxiNSzqnQJokdjRWLYhayGTF!=CmfXEusxiNSzqnQJokdjRWLYhayGTg:
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.Init_WV_Total()
   return CmfXEusxiNSzqnQJokdjRWLYhayGKP
  if CmfXEusxiNSzqnQJokdjRWLYhayGKF(CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))>CmfXEusxiNSzqnQJokdjRWLYhayGKF(CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.WV['account']['token_limit']):
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.Init_WV_Total()
   return CmfXEusxiNSzqnQJokdjRWLYhayGKP
  return CmfXEusxiNSzqnQJokdjRWLYhayGKO
 def dp_LiveCatagory_List(CmfXEusxiNSzqnQJokdjRWLYhayGvU,args):
  CmfXEusxiNSzqnQJokdjRWLYhayGTA =args.get('sCode')
  CmfXEusxiNSzqnQJokdjRWLYhayGTc=args.get('sIndex')
  addon_log('sCode  : {}'.format(CmfXEusxiNSzqnQJokdjRWLYhayGTA)) 
  addon_log('sIndex : {}'.format(CmfXEusxiNSzqnQJokdjRWLYhayGTc)) 
  CmfXEusxiNSzqnQJokdjRWLYhayGtw,CmfXEusxiNSzqnQJokdjRWLYhayGTb=CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.Get_LiveCatagory_List(CmfXEusxiNSzqnQJokdjRWLYhayGTA,CmfXEusxiNSzqnQJokdjRWLYhayGTc)
  for CmfXEusxiNSzqnQJokdjRWLYhayGtH in CmfXEusxiNSzqnQJokdjRWLYhayGtw:
   CmfXEusxiNSzqnQJokdjRWLYhayGrF =CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('title')
   CmfXEusxiNSzqnQJokdjRWLYhayGrb={'mode':'LIVE_LIST','genre':CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('genre'),'baseapi':CmfXEusxiNSzqnQJokdjRWLYhayGTb}
   CmfXEusxiNSzqnQJokdjRWLYhayGrH={'title':CmfXEusxiNSzqnQJokdjRWLYhayGrF,'plot':CmfXEusxiNSzqnQJokdjRWLYhayGrF}
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.add_dir(CmfXEusxiNSzqnQJokdjRWLYhayGrF,sublabel='',img='',infoLabels=CmfXEusxiNSzqnQJokdjRWLYhayGrH,isFolder=CmfXEusxiNSzqnQJokdjRWLYhayGKO,params=CmfXEusxiNSzqnQJokdjRWLYhayGrb)
  if CmfXEusxiNSzqnQJokdjRWLYhayGKI(CmfXEusxiNSzqnQJokdjRWLYhayGtw)>0:xbmcplugin.endOfDirectory(CmfXEusxiNSzqnQJokdjRWLYhayGvU._addon_handle,cacheToDisc=CmfXEusxiNSzqnQJokdjRWLYhayGKP)
 def dp_MainCatagory_List(CmfXEusxiNSzqnQJokdjRWLYhayGvU,args):
  CmfXEusxiNSzqnQJokdjRWLYhayGTA =args.get('sCode')
  CmfXEusxiNSzqnQJokdjRWLYhayGTc=args.get('sIndex')
  CmfXEusxiNSzqnQJokdjRWLYhayGtT =args.get('sType')
  CmfXEusxiNSzqnQJokdjRWLYhayGtw=CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.Get_MainCatagory_List(CmfXEusxiNSzqnQJokdjRWLYhayGTA,CmfXEusxiNSzqnQJokdjRWLYhayGTc,CmfXEusxiNSzqnQJokdjRWLYhayGtT)
  for CmfXEusxiNSzqnQJokdjRWLYhayGtH in CmfXEusxiNSzqnQJokdjRWLYhayGtw:
   if CmfXEusxiNSzqnQJokdjRWLYhayGtT in['vod','vod09']:
    if CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('subtype')=='catagory':
     CmfXEusxiNSzqnQJokdjRWLYhayGtl='PROGRAM_LIST'
    else:
     CmfXEusxiNSzqnQJokdjRWLYhayGtl='SUPERSECTION_LIST'
   elif CmfXEusxiNSzqnQJokdjRWLYhayGtT=='movie':
    CmfXEusxiNSzqnQJokdjRWLYhayGtl='MOVIE_LIST'
   else:
    CmfXEusxiNSzqnQJokdjRWLYhayGtl=''
   CmfXEusxiNSzqnQJokdjRWLYhayGrF='%s (%s)'%(CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('title'),args.get('ordernm'))
   CmfXEusxiNSzqnQJokdjRWLYhayGrb={'mode':CmfXEusxiNSzqnQJokdjRWLYhayGtl,'suburl':CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('suburl'),'subapi':CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if CmfXEusxiNSzqnQJokdjRWLYhayGvU.get_settings_exclusion21():
    if CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('title')=='성인' or CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('title')=='성인+' or CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('title')=='에로티시즘' or CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('title')=='19':continue
   CmfXEusxiNSzqnQJokdjRWLYhayGrH={'title':CmfXEusxiNSzqnQJokdjRWLYhayGrF,'plot':CmfXEusxiNSzqnQJokdjRWLYhayGrF}
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.add_dir(CmfXEusxiNSzqnQJokdjRWLYhayGrF,sublabel='',img='',infoLabels=CmfXEusxiNSzqnQJokdjRWLYhayGrH,isFolder=CmfXEusxiNSzqnQJokdjRWLYhayGKO,params=CmfXEusxiNSzqnQJokdjRWLYhayGrb)
  if CmfXEusxiNSzqnQJokdjRWLYhayGKI(CmfXEusxiNSzqnQJokdjRWLYhayGtw)>0:xbmcplugin.endOfDirectory(CmfXEusxiNSzqnQJokdjRWLYhayGvU._addon_handle,cacheToDisc=CmfXEusxiNSzqnQJokdjRWLYhayGKP)
 def dp_Program_List(CmfXEusxiNSzqnQJokdjRWLYhayGvU,args):
  CmfXEusxiNSzqnQJokdjRWLYhayGTI =args.get('subapi')
  CmfXEusxiNSzqnQJokdjRWLYhayGtI=CmfXEusxiNSzqnQJokdjRWLYhayGKF(args.get('page'))
  CmfXEusxiNSzqnQJokdjRWLYhayGrM =args.get('orderby')
  CmfXEusxiNSzqnQJokdjRWLYhayGvU.addon_log('dp_Program_List')
  CmfXEusxiNSzqnQJokdjRWLYhayGvU.addon_log(CmfXEusxiNSzqnQJokdjRWLYhayGTI)
  CmfXEusxiNSzqnQJokdjRWLYhayGtw,CmfXEusxiNSzqnQJokdjRWLYhayGtK=CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.Get_Program_List(CmfXEusxiNSzqnQJokdjRWLYhayGTI,CmfXEusxiNSzqnQJokdjRWLYhayGtI,CmfXEusxiNSzqnQJokdjRWLYhayGrM)
  for CmfXEusxiNSzqnQJokdjRWLYhayGtH in CmfXEusxiNSzqnQJokdjRWLYhayGtw:
   CmfXEusxiNSzqnQJokdjRWLYhayGtp =CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('videoid')
   CmfXEusxiNSzqnQJokdjRWLYhayGev =CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('vidtype')
   CmfXEusxiNSzqnQJokdjRWLYhayGrF =CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('title')
   CmfXEusxiNSzqnQJokdjRWLYhayGer=CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('thumbnail')
   CmfXEusxiNSzqnQJokdjRWLYhayGrH={'plot':CmfXEusxiNSzqnQJokdjRWLYhayGrF+'\n\n'+CmfXEusxiNSzqnQJokdjRWLYhayGtp+'\n'+CmfXEusxiNSzqnQJokdjRWLYhayGev,'mediatype':'tvshow','title':CmfXEusxiNSzqnQJokdjRWLYhayGrF,}
   CmfXEusxiNSzqnQJokdjRWLYhayGrb={'mode':'SEASON_LIST','videoid':CmfXEusxiNSzqnQJokdjRWLYhayGtp,'vidtype':CmfXEusxiNSzqnQJokdjRWLYhayGev,}
   CmfXEusxiNSzqnQJokdjRWLYhayGtc=[]
   CmfXEusxiNSzqnQJokdjRWLYhayGel={'mode':'VIEW_DETAIL','values':{'videoid':CmfXEusxiNSzqnQJokdjRWLYhayGtp,'vidtype':'tvshow','contenttype':CmfXEusxiNSzqnQJokdjRWLYhayGev,}}
   CmfXEusxiNSzqnQJokdjRWLYhayGeT=json.dumps(CmfXEusxiNSzqnQJokdjRWLYhayGel,separators=(',',':'))
   CmfXEusxiNSzqnQJokdjRWLYhayGeT=base64.standard_b64encode(CmfXEusxiNSzqnQJokdjRWLYhayGeT.encode()).decode('utf-8')
   CmfXEusxiNSzqnQJokdjRWLYhayGeT=CmfXEusxiNSzqnQJokdjRWLYhayGeT.replace('+','%2B')
   CmfXEusxiNSzqnQJokdjRWLYhayGeB='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(CmfXEusxiNSzqnQJokdjRWLYhayGeT)
   CmfXEusxiNSzqnQJokdjRWLYhayGtc.append(('상세정보 조회',CmfXEusxiNSzqnQJokdjRWLYhayGeB))
   if CmfXEusxiNSzqnQJokdjRWLYhayGvU.get_settings_makebookmark():
    CmfXEusxiNSzqnQJokdjRWLYhayGel={'videoid':CmfXEusxiNSzqnQJokdjRWLYhayGtp,'vidtype':'tvshow','vtitle':CmfXEusxiNSzqnQJokdjRWLYhayGrF,'vsubtitle':'','contenttype':CmfXEusxiNSzqnQJokdjRWLYhayGev,}
    CmfXEusxiNSzqnQJokdjRWLYhayGeK=json.dumps(CmfXEusxiNSzqnQJokdjRWLYhayGel)
    CmfXEusxiNSzqnQJokdjRWLYhayGeK=urllib.parse.quote(CmfXEusxiNSzqnQJokdjRWLYhayGeK)
    CmfXEusxiNSzqnQJokdjRWLYhayGeB='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(CmfXEusxiNSzqnQJokdjRWLYhayGeK)
    CmfXEusxiNSzqnQJokdjRWLYhayGtc.append(('(통합) 찜 영상에 추가',CmfXEusxiNSzqnQJokdjRWLYhayGeB))
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.add_dir(CmfXEusxiNSzqnQJokdjRWLYhayGrF,sublabel='',img=CmfXEusxiNSzqnQJokdjRWLYhayGer,infoLabels=CmfXEusxiNSzqnQJokdjRWLYhayGrH,isFolder=CmfXEusxiNSzqnQJokdjRWLYhayGKO,params=CmfXEusxiNSzqnQJokdjRWLYhayGrb,ContextMenu=CmfXEusxiNSzqnQJokdjRWLYhayGtc)
  if CmfXEusxiNSzqnQJokdjRWLYhayGtK:
   CmfXEusxiNSzqnQJokdjRWLYhayGrb={}
   CmfXEusxiNSzqnQJokdjRWLYhayGrb['mode'] ='PROGRAM_LIST' 
   CmfXEusxiNSzqnQJokdjRWLYhayGrb['subapi']=CmfXEusxiNSzqnQJokdjRWLYhayGTI 
   CmfXEusxiNSzqnQJokdjRWLYhayGrb['page'] =CmfXEusxiNSzqnQJokdjRWLYhayGKH(CmfXEusxiNSzqnQJokdjRWLYhayGtI+1)
   CmfXEusxiNSzqnQJokdjRWLYhayGrF='[B]%s >>[/B]'%'다음 페이지'
   CmfXEusxiNSzqnQJokdjRWLYhayGeU=CmfXEusxiNSzqnQJokdjRWLYhayGKH(CmfXEusxiNSzqnQJokdjRWLYhayGtI+1)
   CmfXEusxiNSzqnQJokdjRWLYhayGrc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.add_dir(CmfXEusxiNSzqnQJokdjRWLYhayGrF,sublabel=CmfXEusxiNSzqnQJokdjRWLYhayGeU,img=CmfXEusxiNSzqnQJokdjRWLYhayGrc,infoLabels=CmfXEusxiNSzqnQJokdjRWLYhayGKD,isFolder=CmfXEusxiNSzqnQJokdjRWLYhayGKO,params=CmfXEusxiNSzqnQJokdjRWLYhayGrb)
  xbmcplugin.setContent(CmfXEusxiNSzqnQJokdjRWLYhayGvU._addon_handle,'tvshows')
  if CmfXEusxiNSzqnQJokdjRWLYhayGKI(CmfXEusxiNSzqnQJokdjRWLYhayGtw)>0:xbmcplugin.endOfDirectory(CmfXEusxiNSzqnQJokdjRWLYhayGvU._addon_handle,cacheToDisc=CmfXEusxiNSzqnQJokdjRWLYhayGKP)
 def dp_Season_List(CmfXEusxiNSzqnQJokdjRWLYhayGvU,args):
  CmfXEusxiNSzqnQJokdjRWLYhayGtp=args.get('videoid')
  CmfXEusxiNSzqnQJokdjRWLYhayGev=args.get('vidtype')
  CmfXEusxiNSzqnQJokdjRWLYhayGvU.addon_log('dp_Season_List')
  CmfXEusxiNSzqnQJokdjRWLYhayGvU.addon_log('videoid : '+CmfXEusxiNSzqnQJokdjRWLYhayGtp)
  CmfXEusxiNSzqnQJokdjRWLYhayGvU.addon_log('vidtype : '+CmfXEusxiNSzqnQJokdjRWLYhayGev)
  if CmfXEusxiNSzqnQJokdjRWLYhayGev=='contentid':
   CmfXEusxiNSzqnQJokdjRWLYhayGlD=CmfXEusxiNSzqnQJokdjRWLYhayGtp
   CmfXEusxiNSzqnQJokdjRWLYhayGTw =CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.ContentidToSeasonid(CmfXEusxiNSzqnQJokdjRWLYhayGtp)
  else:
   CmfXEusxiNSzqnQJokdjRWLYhayGlD=CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.ProgramidToContentid(CmfXEusxiNSzqnQJokdjRWLYhayGtp)
   CmfXEusxiNSzqnQJokdjRWLYhayGTw =CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.ContentidToSeasonid(CmfXEusxiNSzqnQJokdjRWLYhayGlD)
  CmfXEusxiNSzqnQJokdjRWLYhayGTH=CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.Get_Season_List(CmfXEusxiNSzqnQJokdjRWLYhayGTw)
  if CmfXEusxiNSzqnQJokdjRWLYhayGKI(CmfXEusxiNSzqnQJokdjRWLYhayGTH)>1:
   for CmfXEusxiNSzqnQJokdjRWLYhayGTp in CmfXEusxiNSzqnQJokdjRWLYhayGTH:
    CmfXEusxiNSzqnQJokdjRWLYhayGBv=CmfXEusxiNSzqnQJokdjRWLYhayGTp.get('season_Id')
    CmfXEusxiNSzqnQJokdjRWLYhayGBr=CmfXEusxiNSzqnQJokdjRWLYhayGTp.get('season_Nm')
    CmfXEusxiNSzqnQJokdjRWLYhayGBt=CmfXEusxiNSzqnQJokdjRWLYhayGTp.get('programNm')
    CmfXEusxiNSzqnQJokdjRWLYhayGer=CmfXEusxiNSzqnQJokdjRWLYhayGTp.get('thumbnail')
    CmfXEusxiNSzqnQJokdjRWLYhayGBe =CmfXEusxiNSzqnQJokdjRWLYhayGTp.get('synopsis')
    CmfXEusxiNSzqnQJokdjRWLYhayGtb={'mediatype':'tvshow','title':CmfXEusxiNSzqnQJokdjRWLYhayGBr,'plot':CmfXEusxiNSzqnQJokdjRWLYhayGBe,}
    CmfXEusxiNSzqnQJokdjRWLYhayGrb={'mode':'EPISODE_LIST','seasonid':CmfXEusxiNSzqnQJokdjRWLYhayGBv,'page':'1',}
    CmfXEusxiNSzqnQJokdjRWLYhayGvU.add_dir(CmfXEusxiNSzqnQJokdjRWLYhayGBr,sublabel=CmfXEusxiNSzqnQJokdjRWLYhayGBt,img=CmfXEusxiNSzqnQJokdjRWLYhayGer,infoLabels=CmfXEusxiNSzqnQJokdjRWLYhayGtb,isFolder=CmfXEusxiNSzqnQJokdjRWLYhayGKO,params=CmfXEusxiNSzqnQJokdjRWLYhayGrb,ContextMenu=CmfXEusxiNSzqnQJokdjRWLYhayGKD)
   xbmcplugin.setContent(CmfXEusxiNSzqnQJokdjRWLYhayGvU._addon_handle,'seasons')
   xbmcplugin.endOfDirectory(CmfXEusxiNSzqnQJokdjRWLYhayGvU._addon_handle,cacheToDisc=CmfXEusxiNSzqnQJokdjRWLYhayGKP)
  else:
   CmfXEusxiNSzqnQJokdjRWLYhayGBl={'seasonid':CmfXEusxiNSzqnQJokdjRWLYhayGTw,'page':'1',}
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.dp_Episode_List(CmfXEusxiNSzqnQJokdjRWLYhayGBl)
 def dp_Episode_List(CmfXEusxiNSzqnQJokdjRWLYhayGvU,args):
  CmfXEusxiNSzqnQJokdjRWLYhayGTw =args.get('seasonid')
  CmfXEusxiNSzqnQJokdjRWLYhayGtI =CmfXEusxiNSzqnQJokdjRWLYhayGKF(args.get('page'))
  CmfXEusxiNSzqnQJokdjRWLYhayGvU.addon_log('seasonid : '+CmfXEusxiNSzqnQJokdjRWLYhayGTw)
  CmfXEusxiNSzqnQJokdjRWLYhayGtw,CmfXEusxiNSzqnQJokdjRWLYhayGtK=CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.Get_Episode_List(CmfXEusxiNSzqnQJokdjRWLYhayGTw,CmfXEusxiNSzqnQJokdjRWLYhayGtI,orderby=CmfXEusxiNSzqnQJokdjRWLYhayGvU.get_winEpisodeOrderby())
  for CmfXEusxiNSzqnQJokdjRWLYhayGtH in CmfXEusxiNSzqnQJokdjRWLYhayGtw:
   CmfXEusxiNSzqnQJokdjRWLYhayGeU=CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('episodenumber')
   CmfXEusxiNSzqnQJokdjRWLYhayGBT ='[%s]\n\n%s'%(CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('episodetitle'),CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('synopsis'))
   CmfXEusxiNSzqnQJokdjRWLYhayGtb={'mediatype':'episode','title':CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('programtitle'),'plot':CmfXEusxiNSzqnQJokdjRWLYhayGBT,'cast':CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('episodeactors'),}
   CmfXEusxiNSzqnQJokdjRWLYhayGrb={'mode':'VOD','programid':CmfXEusxiNSzqnQJokdjRWLYhayGTw,'contentid':CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('contentid'),'thumbnail':CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('thumbnail'),'title':CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('programtitle'),'subtitle':CmfXEusxiNSzqnQJokdjRWLYhayGeU,}
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.add_dir(CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('programtitle'),sublabel=CmfXEusxiNSzqnQJokdjRWLYhayGeU,img=CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('thumbnail'),infoLabels=CmfXEusxiNSzqnQJokdjRWLYhayGtb,isFolder=CmfXEusxiNSzqnQJokdjRWLYhayGKP,params=CmfXEusxiNSzqnQJokdjRWLYhayGrb)
  if CmfXEusxiNSzqnQJokdjRWLYhayGtI==1:
   CmfXEusxiNSzqnQJokdjRWLYhayGtb={'plot':'정렬순서를 변경합니다.'}
   CmfXEusxiNSzqnQJokdjRWLYhayGrb={}
   CmfXEusxiNSzqnQJokdjRWLYhayGrb['mode'] ='ORDER_BY' 
   if CmfXEusxiNSzqnQJokdjRWLYhayGvU.get_winEpisodeOrderby()=='desc':
    CmfXEusxiNSzqnQJokdjRWLYhayGrF='정렬순서변경 : 최신화부터 -> 1회부터'
    CmfXEusxiNSzqnQJokdjRWLYhayGrb['orderby']='asc'
   else:
    CmfXEusxiNSzqnQJokdjRWLYhayGrF='정렬순서변경 : 1회부터 -> 최신화부터'
    CmfXEusxiNSzqnQJokdjRWLYhayGrb['orderby']='desc'
   CmfXEusxiNSzqnQJokdjRWLYhayGrc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.add_dir(CmfXEusxiNSzqnQJokdjRWLYhayGrF,sublabel='',img=CmfXEusxiNSzqnQJokdjRWLYhayGrc,infoLabels=CmfXEusxiNSzqnQJokdjRWLYhayGtb,isFolder=CmfXEusxiNSzqnQJokdjRWLYhayGKP,params=CmfXEusxiNSzqnQJokdjRWLYhayGrb,isLink=CmfXEusxiNSzqnQJokdjRWLYhayGKO)
  if CmfXEusxiNSzqnQJokdjRWLYhayGtK:
   CmfXEusxiNSzqnQJokdjRWLYhayGrb={}
   CmfXEusxiNSzqnQJokdjRWLYhayGrb['mode'] ='EPISODE_LIST' 
   CmfXEusxiNSzqnQJokdjRWLYhayGrb['seasonid']=CmfXEusxiNSzqnQJokdjRWLYhayGTw
   CmfXEusxiNSzqnQJokdjRWLYhayGrb['page'] =CmfXEusxiNSzqnQJokdjRWLYhayGKH(CmfXEusxiNSzqnQJokdjRWLYhayGtI+1)
   CmfXEusxiNSzqnQJokdjRWLYhayGrF='[B]%s >>[/B]'%'다음 페이지'
   CmfXEusxiNSzqnQJokdjRWLYhayGeU=CmfXEusxiNSzqnQJokdjRWLYhayGKH(CmfXEusxiNSzqnQJokdjRWLYhayGtI+1)
   CmfXEusxiNSzqnQJokdjRWLYhayGrc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.add_dir(CmfXEusxiNSzqnQJokdjRWLYhayGrF,sublabel=CmfXEusxiNSzqnQJokdjRWLYhayGeU,img=CmfXEusxiNSzqnQJokdjRWLYhayGrc,infoLabels=CmfXEusxiNSzqnQJokdjRWLYhayGKD,isFolder=CmfXEusxiNSzqnQJokdjRWLYhayGKO,params=CmfXEusxiNSzqnQJokdjRWLYhayGrb)
  xbmcplugin.setContent(CmfXEusxiNSzqnQJokdjRWLYhayGvU._addon_handle,'episodes')
  if CmfXEusxiNSzqnQJokdjRWLYhayGKI(CmfXEusxiNSzqnQJokdjRWLYhayGtw)>0:xbmcplugin.endOfDirectory(CmfXEusxiNSzqnQJokdjRWLYhayGvU._addon_handle,cacheToDisc=CmfXEusxiNSzqnQJokdjRWLYhayGKP)
 def dp_SuperSection_List(CmfXEusxiNSzqnQJokdjRWLYhayGvU,args):
  CmfXEusxiNSzqnQJokdjRWLYhayGBK =args.get('suburl')
  CmfXEusxiNSzqnQJokdjRWLYhayGTI =args.get('subapi')
  CmfXEusxiNSzqnQJokdjRWLYhayGvU.addon_log('dp_SuperSection_List')
  CmfXEusxiNSzqnQJokdjRWLYhayGvU.addon_log('suburl : '+CmfXEusxiNSzqnQJokdjRWLYhayGBK)
  CmfXEusxiNSzqnQJokdjRWLYhayGvU.addon_log('subapi : '+CmfXEusxiNSzqnQJokdjRWLYhayGTI)
  CmfXEusxiNSzqnQJokdjRWLYhayGtw=CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.Get_SuperMultiSection_List(CmfXEusxiNSzqnQJokdjRWLYhayGBK)
  for CmfXEusxiNSzqnQJokdjRWLYhayGtH in CmfXEusxiNSzqnQJokdjRWLYhayGtw:
   CmfXEusxiNSzqnQJokdjRWLYhayGrF =CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('title')
   CmfXEusxiNSzqnQJokdjRWLYhayGTI =CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('subapi')
   CmfXEusxiNSzqnQJokdjRWLYhayGBU=CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('cell_type')
   if CmfXEusxiNSzqnQJokdjRWLYhayGTI.find('contenttype=movie')>=0 or CmfXEusxiNSzqnQJokdjRWLYhayGTI.find('mtype=svod')>=0:
    CmfXEusxiNSzqnQJokdjRWLYhayGtl='MOVIE_LIST'
   elif re.search('themes/2\d{4}',CmfXEusxiNSzqnQJokdjRWLYhayGTI)or re.search('themes-band/9\d{4}',CmfXEusxiNSzqnQJokdjRWLYhayGTI):
    CmfXEusxiNSzqnQJokdjRWLYhayGtl='MOVIE_LIST'
   else:
    CmfXEusxiNSzqnQJokdjRWLYhayGtl='PROGRAM_LIST'
   '''
   if subapi.find('mtype=svod') >= 0 or subapi.find('mtype=ppv') >= 0 or subapi.find('contenttype=movie') >= 0: #영화 #20201107
    mode = 'MOVIE_LIST'
   elif subapi.find('contenttype=program') >= 0:
    mode = 'PROGRAM_LIST'
   elif cell_type == 'band_71': # band_71 #20201107
    mode   = 'SUPERSECTION_LIST'
    (temp_url, temp_api) = self.WavveObj.Baseapi_Parse(subapi)
    suburl = temp_api.get('api')
    subapi = ''
   elif cell_type == 'band_2': # band_2
    mode = 'BAND2SECTION_LIST'
   elif cell_type == 'band_live':
    mode = 'BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}', subapi) :
    mode = 'MOVIE_LIST'
   else: # band_10
    mode = 'PROGRAM_LIST'
   '''   
   CmfXEusxiNSzqnQJokdjRWLYhayGtb={'plot':CmfXEusxiNSzqnQJokdjRWLYhayGrF,'mediatype':'tvshow',}
   CmfXEusxiNSzqnQJokdjRWLYhayGrb={'mode':CmfXEusxiNSzqnQJokdjRWLYhayGtl,'suburl':CmfXEusxiNSzqnQJokdjRWLYhayGBK,'subapi':CmfXEusxiNSzqnQJokdjRWLYhayGTI,'page':'1',}
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.add_dir(CmfXEusxiNSzqnQJokdjRWLYhayGrF,sublabel='',img=CmfXEusxiNSzqnQJokdjRWLYhayGKD,infoLabels=CmfXEusxiNSzqnQJokdjRWLYhayGtb,isFolder=CmfXEusxiNSzqnQJokdjRWLYhayGKO,params=CmfXEusxiNSzqnQJokdjRWLYhayGrb)
  if CmfXEusxiNSzqnQJokdjRWLYhayGKI(CmfXEusxiNSzqnQJokdjRWLYhayGtw)>0:xbmcplugin.endOfDirectory(CmfXEusxiNSzqnQJokdjRWLYhayGvU._addon_handle,cacheToDisc=CmfXEusxiNSzqnQJokdjRWLYhayGKP)
 def dp_BandLiveSection_List(CmfXEusxiNSzqnQJokdjRWLYhayGvU,args):
  CmfXEusxiNSzqnQJokdjRWLYhayGTI =args.get('subapi')
  CmfXEusxiNSzqnQJokdjRWLYhayGtI=CmfXEusxiNSzqnQJokdjRWLYhayGKF(args.get('page'))
  CmfXEusxiNSzqnQJokdjRWLYhayGtw,CmfXEusxiNSzqnQJokdjRWLYhayGtK=CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.Get_BandLiveSection_List(CmfXEusxiNSzqnQJokdjRWLYhayGTI,CmfXEusxiNSzqnQJokdjRWLYhayGtI)
  for CmfXEusxiNSzqnQJokdjRWLYhayGtH in CmfXEusxiNSzqnQJokdjRWLYhayGtw:
   CmfXEusxiNSzqnQJokdjRWLYhayGBV =CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('channelid')
   CmfXEusxiNSzqnQJokdjRWLYhayGBM =CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('studio')
   CmfXEusxiNSzqnQJokdjRWLYhayGBD=CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('tvshowtitle')
   CmfXEusxiNSzqnQJokdjRWLYhayGer =CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('thumbnail')
   CmfXEusxiNSzqnQJokdjRWLYhayGet =CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('age')
   CmfXEusxiNSzqnQJokdjRWLYhayGtb={'mediatype':'tvshow','mpaa':CmfXEusxiNSzqnQJokdjRWLYhayGet,'title':'%s < %s >'%(CmfXEusxiNSzqnQJokdjRWLYhayGBM,CmfXEusxiNSzqnQJokdjRWLYhayGBD),'tvshowtitle':CmfXEusxiNSzqnQJokdjRWLYhayGBD,'studio':CmfXEusxiNSzqnQJokdjRWLYhayGBM,'plot':CmfXEusxiNSzqnQJokdjRWLYhayGBM}
   CmfXEusxiNSzqnQJokdjRWLYhayGrb={'mode':'LIVE','contentid':CmfXEusxiNSzqnQJokdjRWLYhayGBV}
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.add_dir(CmfXEusxiNSzqnQJokdjRWLYhayGBM,sublabel=CmfXEusxiNSzqnQJokdjRWLYhayGBD,img=CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('thumbnail'),infoLabels=CmfXEusxiNSzqnQJokdjRWLYhayGtb,isFolder=CmfXEusxiNSzqnQJokdjRWLYhayGKP,params=CmfXEusxiNSzqnQJokdjRWLYhayGrb)
  if CmfXEusxiNSzqnQJokdjRWLYhayGtK:
   CmfXEusxiNSzqnQJokdjRWLYhayGrb={}
   CmfXEusxiNSzqnQJokdjRWLYhayGrb['mode'] ='BANDLIVESECTION_LIST' 
   CmfXEusxiNSzqnQJokdjRWLYhayGrb['subapi']=CmfXEusxiNSzqnQJokdjRWLYhayGTI
   CmfXEusxiNSzqnQJokdjRWLYhayGrb['page'] =CmfXEusxiNSzqnQJokdjRWLYhayGKH(CmfXEusxiNSzqnQJokdjRWLYhayGtI+1)
   CmfXEusxiNSzqnQJokdjRWLYhayGrF='[B]%s >>[/B]'%'다음 페이지'
   CmfXEusxiNSzqnQJokdjRWLYhayGeU=CmfXEusxiNSzqnQJokdjRWLYhayGKH(CmfXEusxiNSzqnQJokdjRWLYhayGtI+1)
   CmfXEusxiNSzqnQJokdjRWLYhayGrc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.add_dir(CmfXEusxiNSzqnQJokdjRWLYhayGrF,sublabel=CmfXEusxiNSzqnQJokdjRWLYhayGeU,img=CmfXEusxiNSzqnQJokdjRWLYhayGrc,infoLabels=CmfXEusxiNSzqnQJokdjRWLYhayGKD,isFolder=CmfXEusxiNSzqnQJokdjRWLYhayGKO,params=CmfXEusxiNSzqnQJokdjRWLYhayGrb)
  if CmfXEusxiNSzqnQJokdjRWLYhayGKI(CmfXEusxiNSzqnQJokdjRWLYhayGtw)>0:xbmcplugin.endOfDirectory(CmfXEusxiNSzqnQJokdjRWLYhayGvU._addon_handle,cacheToDisc=CmfXEusxiNSzqnQJokdjRWLYhayGKP)
 def dp_Band2Section_List(CmfXEusxiNSzqnQJokdjRWLYhayGvU,args):
  CmfXEusxiNSzqnQJokdjRWLYhayGTI =args.get('subapi')
  CmfXEusxiNSzqnQJokdjRWLYhayGtI=CmfXEusxiNSzqnQJokdjRWLYhayGKF(args.get('page'))
  CmfXEusxiNSzqnQJokdjRWLYhayGtw,CmfXEusxiNSzqnQJokdjRWLYhayGtK=CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.Get_Band2Section_List(CmfXEusxiNSzqnQJokdjRWLYhayGTI,CmfXEusxiNSzqnQJokdjRWLYhayGtI)
  for CmfXEusxiNSzqnQJokdjRWLYhayGtH in CmfXEusxiNSzqnQJokdjRWLYhayGtw:
   CmfXEusxiNSzqnQJokdjRWLYhayGrF =CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('programtitle')
   CmfXEusxiNSzqnQJokdjRWLYhayGeU =CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('episodetitle')
   CmfXEusxiNSzqnQJokdjRWLYhayGtb={'plot':CmfXEusxiNSzqnQJokdjRWLYhayGrF+'\n\n'+CmfXEusxiNSzqnQJokdjRWLYhayGeU,'mpaa':CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('age'),'mediatype':'episode'}
   CmfXEusxiNSzqnQJokdjRWLYhayGrb={'mode':'VOD','programid':'-','contentid':CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('videoid'),'thumbnail':CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('thumbnail'),'title':CmfXEusxiNSzqnQJokdjRWLYhayGrF,'subtitle':CmfXEusxiNSzqnQJokdjRWLYhayGeU}
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.add_dir(CmfXEusxiNSzqnQJokdjRWLYhayGrF,sublabel=CmfXEusxiNSzqnQJokdjRWLYhayGeU,img=CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('thumbnail'),infoLabels=CmfXEusxiNSzqnQJokdjRWLYhayGtb,isFolder=CmfXEusxiNSzqnQJokdjRWLYhayGKP,params=CmfXEusxiNSzqnQJokdjRWLYhayGrb)
  if CmfXEusxiNSzqnQJokdjRWLYhayGtK:
   CmfXEusxiNSzqnQJokdjRWLYhayGrb={}
   CmfXEusxiNSzqnQJokdjRWLYhayGrb['mode'] ='BAND2SECTION_LIST' 
   CmfXEusxiNSzqnQJokdjRWLYhayGrb['subapi']=CmfXEusxiNSzqnQJokdjRWLYhayGTI
   CmfXEusxiNSzqnQJokdjRWLYhayGrb['page'] =CmfXEusxiNSzqnQJokdjRWLYhayGKH(CmfXEusxiNSzqnQJokdjRWLYhayGtI+1)
   CmfXEusxiNSzqnQJokdjRWLYhayGrF='[B]%s >>[/B]'%'다음 페이지'
   CmfXEusxiNSzqnQJokdjRWLYhayGeU=CmfXEusxiNSzqnQJokdjRWLYhayGKH(CmfXEusxiNSzqnQJokdjRWLYhayGtI+1)
   CmfXEusxiNSzqnQJokdjRWLYhayGrc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.add_dir(CmfXEusxiNSzqnQJokdjRWLYhayGrF,sublabel=CmfXEusxiNSzqnQJokdjRWLYhayGeU,img=CmfXEusxiNSzqnQJokdjRWLYhayGrc,infoLabels=CmfXEusxiNSzqnQJokdjRWLYhayGKD,isFolder=CmfXEusxiNSzqnQJokdjRWLYhayGKO,params=CmfXEusxiNSzqnQJokdjRWLYhayGrb)
  if CmfXEusxiNSzqnQJokdjRWLYhayGKI(CmfXEusxiNSzqnQJokdjRWLYhayGtw)>0:xbmcplugin.endOfDirectory(CmfXEusxiNSzqnQJokdjRWLYhayGvU._addon_handle,cacheToDisc=CmfXEusxiNSzqnQJokdjRWLYhayGKP)
 def dp_Movie_List(CmfXEusxiNSzqnQJokdjRWLYhayGvU,args):
  CmfXEusxiNSzqnQJokdjRWLYhayGTI =args.get('subapi')
  CmfXEusxiNSzqnQJokdjRWLYhayGtI=CmfXEusxiNSzqnQJokdjRWLYhayGKF(args.get('page'))
  CmfXEusxiNSzqnQJokdjRWLYhayGrM =args.get('orderby')or '-'
  CmfXEusxiNSzqnQJokdjRWLYhayGvU.addon_log('dp_Movie_List')
  CmfXEusxiNSzqnQJokdjRWLYhayGvU.addon_log(CmfXEusxiNSzqnQJokdjRWLYhayGTI)
  CmfXEusxiNSzqnQJokdjRWLYhayGtw,CmfXEusxiNSzqnQJokdjRWLYhayGtK=CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.Get_Movie_List(CmfXEusxiNSzqnQJokdjRWLYhayGTI,CmfXEusxiNSzqnQJokdjRWLYhayGtI,CmfXEusxiNSzqnQJokdjRWLYhayGrM)
  for CmfXEusxiNSzqnQJokdjRWLYhayGtH in CmfXEusxiNSzqnQJokdjRWLYhayGtw:
   CmfXEusxiNSzqnQJokdjRWLYhayGtp =CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('videoid')
   CmfXEusxiNSzqnQJokdjRWLYhayGev =CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('vidtype')
   CmfXEusxiNSzqnQJokdjRWLYhayGrF =CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('title')
   CmfXEusxiNSzqnQJokdjRWLYhayGer=CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('thumbnail')
   CmfXEusxiNSzqnQJokdjRWLYhayGet =CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('age')
   if CmfXEusxiNSzqnQJokdjRWLYhayGet=='18' or CmfXEusxiNSzqnQJokdjRWLYhayGet=='19' or CmfXEusxiNSzqnQJokdjRWLYhayGet=='21':CmfXEusxiNSzqnQJokdjRWLYhayGrF+=' (%s)'%(CmfXEusxiNSzqnQJokdjRWLYhayGet)
   CmfXEusxiNSzqnQJokdjRWLYhayGtb={'plot':CmfXEusxiNSzqnQJokdjRWLYhayGrF,'mpaa':CmfXEusxiNSzqnQJokdjRWLYhayGet,'mediatype':'movie'}
   CmfXEusxiNSzqnQJokdjRWLYhayGrb={'mode':'MOVIE','contentid':CmfXEusxiNSzqnQJokdjRWLYhayGtp,'title':CmfXEusxiNSzqnQJokdjRWLYhayGrF,'thumbnail':CmfXEusxiNSzqnQJokdjRWLYhayGer,'age':CmfXEusxiNSzqnQJokdjRWLYhayGet,}
   CmfXEusxiNSzqnQJokdjRWLYhayGtc=[]
   CmfXEusxiNSzqnQJokdjRWLYhayGel={'mode':'VIEW_DETAIL','values':{'videoid':CmfXEusxiNSzqnQJokdjRWLYhayGtp,'vidtype':'movie','contenttype':CmfXEusxiNSzqnQJokdjRWLYhayGev,}}
   CmfXEusxiNSzqnQJokdjRWLYhayGeT=json.dumps(CmfXEusxiNSzqnQJokdjRWLYhayGel,separators=(',',':'))
   CmfXEusxiNSzqnQJokdjRWLYhayGeT=base64.standard_b64encode(CmfXEusxiNSzqnQJokdjRWLYhayGeT.encode()).decode('utf-8')
   CmfXEusxiNSzqnQJokdjRWLYhayGeT=CmfXEusxiNSzqnQJokdjRWLYhayGeT.replace('+','%2B')
   CmfXEusxiNSzqnQJokdjRWLYhayGeB='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(CmfXEusxiNSzqnQJokdjRWLYhayGeT)
   CmfXEusxiNSzqnQJokdjRWLYhayGtc.append(('상세정보 조회',CmfXEusxiNSzqnQJokdjRWLYhayGeB))
   if CmfXEusxiNSzqnQJokdjRWLYhayGvU.get_settings_makebookmark():
    CmfXEusxiNSzqnQJokdjRWLYhayGel={'videoid':CmfXEusxiNSzqnQJokdjRWLYhayGtp,'vidtype':'movie','vtitle':CmfXEusxiNSzqnQJokdjRWLYhayGrF,'vsubtitle':'','contenttype':'programid',}
    CmfXEusxiNSzqnQJokdjRWLYhayGeK=json.dumps(CmfXEusxiNSzqnQJokdjRWLYhayGel)
    CmfXEusxiNSzqnQJokdjRWLYhayGeK=urllib.parse.quote(CmfXEusxiNSzqnQJokdjRWLYhayGeK)
    CmfXEusxiNSzqnQJokdjRWLYhayGeB='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(CmfXEusxiNSzqnQJokdjRWLYhayGeK)
    CmfXEusxiNSzqnQJokdjRWLYhayGtc.append(('(통합) 찜 영상에 추가',CmfXEusxiNSzqnQJokdjRWLYhayGeB))
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.add_dir(CmfXEusxiNSzqnQJokdjRWLYhayGrF,sublabel='',img=CmfXEusxiNSzqnQJokdjRWLYhayGer,infoLabels=CmfXEusxiNSzqnQJokdjRWLYhayGtb,isFolder=CmfXEusxiNSzqnQJokdjRWLYhayGKP,params=CmfXEusxiNSzqnQJokdjRWLYhayGrb,ContextMenu=CmfXEusxiNSzqnQJokdjRWLYhayGtc)
  if CmfXEusxiNSzqnQJokdjRWLYhayGtK:
   CmfXEusxiNSzqnQJokdjRWLYhayGrb={}
   CmfXEusxiNSzqnQJokdjRWLYhayGrb['mode'] ='MOVIE_LIST' 
   CmfXEusxiNSzqnQJokdjRWLYhayGrb['subapi']=CmfXEusxiNSzqnQJokdjRWLYhayGTI 
   CmfXEusxiNSzqnQJokdjRWLYhayGrb['page'] =CmfXEusxiNSzqnQJokdjRWLYhayGKH(CmfXEusxiNSzqnQJokdjRWLYhayGtI+1)
   CmfXEusxiNSzqnQJokdjRWLYhayGrb['orderby']=CmfXEusxiNSzqnQJokdjRWLYhayGrM
   CmfXEusxiNSzqnQJokdjRWLYhayGrF='[B]%s >>[/B]'%'다음 페이지'
   CmfXEusxiNSzqnQJokdjRWLYhayGeU=CmfXEusxiNSzqnQJokdjRWLYhayGKH(CmfXEusxiNSzqnQJokdjRWLYhayGtI+1)
   CmfXEusxiNSzqnQJokdjRWLYhayGrc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.add_dir(CmfXEusxiNSzqnQJokdjRWLYhayGrF,sublabel=CmfXEusxiNSzqnQJokdjRWLYhayGeU,img=CmfXEusxiNSzqnQJokdjRWLYhayGrc,infoLabels=CmfXEusxiNSzqnQJokdjRWLYhayGKD,isFolder=CmfXEusxiNSzqnQJokdjRWLYhayGKO,params=CmfXEusxiNSzqnQJokdjRWLYhayGrb)
  xbmcplugin.setContent(CmfXEusxiNSzqnQJokdjRWLYhayGvU._addon_handle,'movies')
  if CmfXEusxiNSzqnQJokdjRWLYhayGKI(CmfXEusxiNSzqnQJokdjRWLYhayGtw)>0:xbmcplugin.endOfDirectory(CmfXEusxiNSzqnQJokdjRWLYhayGvU._addon_handle,cacheToDisc=CmfXEusxiNSzqnQJokdjRWLYhayGKP)
 def dp_Set_Bookmark(CmfXEusxiNSzqnQJokdjRWLYhayGvU,args):
  CmfXEusxiNSzqnQJokdjRWLYhayGBF=urllib.parse.unquote(args.get('bm_param'))
  CmfXEusxiNSzqnQJokdjRWLYhayGBF=json.loads(CmfXEusxiNSzqnQJokdjRWLYhayGBF)
  CmfXEusxiNSzqnQJokdjRWLYhayGtp =CmfXEusxiNSzqnQJokdjRWLYhayGBF.get('videoid')
  CmfXEusxiNSzqnQJokdjRWLYhayGev =CmfXEusxiNSzqnQJokdjRWLYhayGBF.get('vidtype')
  CmfXEusxiNSzqnQJokdjRWLYhayGBO =CmfXEusxiNSzqnQJokdjRWLYhayGBF.get('vtitle')
  CmfXEusxiNSzqnQJokdjRWLYhayGBP =CmfXEusxiNSzqnQJokdjRWLYhayGBF.get('vsubtitle')
  CmfXEusxiNSzqnQJokdjRWLYhayGBg=CmfXEusxiNSzqnQJokdjRWLYhayGBF.get('contenttype')
  CmfXEusxiNSzqnQJokdjRWLYhayGvO=xbmcgui.Dialog()
  CmfXEusxiNSzqnQJokdjRWLYhayGlv=CmfXEusxiNSzqnQJokdjRWLYhayGvO.yesno(__language__(30913).encode('utf8'),CmfXEusxiNSzqnQJokdjRWLYhayGBO+' \n\n'+__language__(30914))
  if CmfXEusxiNSzqnQJokdjRWLYhayGlv==CmfXEusxiNSzqnQJokdjRWLYhayGKP:return
  CmfXEusxiNSzqnQJokdjRWLYhayGBA=CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.GetBookmarkInfo(CmfXEusxiNSzqnQJokdjRWLYhayGtp,CmfXEusxiNSzqnQJokdjRWLYhayGev,CmfXEusxiNSzqnQJokdjRWLYhayGBg)
  CmfXEusxiNSzqnQJokdjRWLYhayGBc=json.dumps(CmfXEusxiNSzqnQJokdjRWLYhayGBA)
  CmfXEusxiNSzqnQJokdjRWLYhayGBc=urllib.parse.quote(CmfXEusxiNSzqnQJokdjRWLYhayGBc)
  CmfXEusxiNSzqnQJokdjRWLYhayGeB ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(CmfXEusxiNSzqnQJokdjRWLYhayGBc)
  xbmc.executebuiltin(CmfXEusxiNSzqnQJokdjRWLYhayGeB)
 def dp_LiveChannel_List(CmfXEusxiNSzqnQJokdjRWLYhayGvU,args):
  CmfXEusxiNSzqnQJokdjRWLYhayGBb =args.get('genre')
  CmfXEusxiNSzqnQJokdjRWLYhayGTb=args.get('baseapi')
  CmfXEusxiNSzqnQJokdjRWLYhayGtw=CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.Get_LiveChannel_List(CmfXEusxiNSzqnQJokdjRWLYhayGBb,CmfXEusxiNSzqnQJokdjRWLYhayGTb)
  for CmfXEusxiNSzqnQJokdjRWLYhayGtH in CmfXEusxiNSzqnQJokdjRWLYhayGtw:
   CmfXEusxiNSzqnQJokdjRWLYhayGBV =CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('channelid')
   CmfXEusxiNSzqnQJokdjRWLYhayGBM =CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('studio')
   CmfXEusxiNSzqnQJokdjRWLYhayGBD=CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('tvshowtitle')
   CmfXEusxiNSzqnQJokdjRWLYhayGer =CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('thumbnail')
   CmfXEusxiNSzqnQJokdjRWLYhayGet =CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('age')
   CmfXEusxiNSzqnQJokdjRWLYhayGBI =CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('epg')
   CmfXEusxiNSzqnQJokdjRWLYhayGtb={'mediatype':'episode','mpaa':CmfXEusxiNSzqnQJokdjRWLYhayGet,'title':'%s < %s >'%(CmfXEusxiNSzqnQJokdjRWLYhayGBM,CmfXEusxiNSzqnQJokdjRWLYhayGBD),'tvshowtitle':CmfXEusxiNSzqnQJokdjRWLYhayGBD,'studio':CmfXEusxiNSzqnQJokdjRWLYhayGBM,'plot':'%s\n\n%s'%(CmfXEusxiNSzqnQJokdjRWLYhayGBM,CmfXEusxiNSzqnQJokdjRWLYhayGBI)}
   CmfXEusxiNSzqnQJokdjRWLYhayGrb={'mode':'LIVE','contentid':CmfXEusxiNSzqnQJokdjRWLYhayGBV}
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.add_dir(CmfXEusxiNSzqnQJokdjRWLYhayGBM,sublabel=CmfXEusxiNSzqnQJokdjRWLYhayGBD,img=CmfXEusxiNSzqnQJokdjRWLYhayGer,infoLabels=CmfXEusxiNSzqnQJokdjRWLYhayGtb,isFolder=CmfXEusxiNSzqnQJokdjRWLYhayGKP,params=CmfXEusxiNSzqnQJokdjRWLYhayGrb)
  if CmfXEusxiNSzqnQJokdjRWLYhayGKI(CmfXEusxiNSzqnQJokdjRWLYhayGtw)>0:xbmcplugin.endOfDirectory(CmfXEusxiNSzqnQJokdjRWLYhayGvU._addon_handle,cacheToDisc=CmfXEusxiNSzqnQJokdjRWLYhayGKP)
 def dp_Sports_GameList(CmfXEusxiNSzqnQJokdjRWLYhayGvU,args):
  CmfXEusxiNSzqnQJokdjRWLYhayGtw=CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.Get_Sports_Gamelist()
  for CmfXEusxiNSzqnQJokdjRWLYhayGtH in CmfXEusxiNSzqnQJokdjRWLYhayGtw:
   CmfXEusxiNSzqnQJokdjRWLYhayGBw =CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('game_date')
   CmfXEusxiNSzqnQJokdjRWLYhayGBH =CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('game_time')
   CmfXEusxiNSzqnQJokdjRWLYhayGBp =CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('svc_id')
   CmfXEusxiNSzqnQJokdjRWLYhayGKv =CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('away_team')
   CmfXEusxiNSzqnQJokdjRWLYhayGKr =CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('home_team')
   CmfXEusxiNSzqnQJokdjRWLYhayGKt=CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('game_status')
   CmfXEusxiNSzqnQJokdjRWLYhayGKe =CmfXEusxiNSzqnQJokdjRWLYhayGtH.get('game_place')
   CmfXEusxiNSzqnQJokdjRWLYhayGKl ='%s vs %s (%s)'%(CmfXEusxiNSzqnQJokdjRWLYhayGKv,CmfXEusxiNSzqnQJokdjRWLYhayGKr,CmfXEusxiNSzqnQJokdjRWLYhayGKe)
   CmfXEusxiNSzqnQJokdjRWLYhayGKT =CmfXEusxiNSzqnQJokdjRWLYhayGBw+' '+CmfXEusxiNSzqnQJokdjRWLYhayGBH
   if CmfXEusxiNSzqnQJokdjRWLYhayGKt=='LIVE':
    CmfXEusxiNSzqnQJokdjRWLYhayGKt='~경기중~'
   elif CmfXEusxiNSzqnQJokdjRWLYhayGKt=='END':
    CmfXEusxiNSzqnQJokdjRWLYhayGKt='경기종료'
   elif CmfXEusxiNSzqnQJokdjRWLYhayGKt=='CANCEL':
    CmfXEusxiNSzqnQJokdjRWLYhayGKt='취소'
   else:
    CmfXEusxiNSzqnQJokdjRWLYhayGKt=''
   if CmfXEusxiNSzqnQJokdjRWLYhayGKt=='':
    CmfXEusxiNSzqnQJokdjRWLYhayGeU=CmfXEusxiNSzqnQJokdjRWLYhayGKl
   else:
    CmfXEusxiNSzqnQJokdjRWLYhayGeU=CmfXEusxiNSzqnQJokdjRWLYhayGKl+'  '+CmfXEusxiNSzqnQJokdjRWLYhayGKt
   CmfXEusxiNSzqnQJokdjRWLYhayGtb={'mediatype':'episode','title':CmfXEusxiNSzqnQJokdjRWLYhayGKl,'plot':'%s\n\n%s\n\n%s'%(CmfXEusxiNSzqnQJokdjRWLYhayGKT,CmfXEusxiNSzqnQJokdjRWLYhayGKl,CmfXEusxiNSzqnQJokdjRWLYhayGKt)}
   CmfXEusxiNSzqnQJokdjRWLYhayGrb={'mode':'SPORTS','contentid':CmfXEusxiNSzqnQJokdjRWLYhayGBp}
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.add_dir(CmfXEusxiNSzqnQJokdjRWLYhayGKT,sublabel=CmfXEusxiNSzqnQJokdjRWLYhayGeU,img='',infoLabels=CmfXEusxiNSzqnQJokdjRWLYhayGtb,isFolder=CmfXEusxiNSzqnQJokdjRWLYhayGKP,params=CmfXEusxiNSzqnQJokdjRWLYhayGrb)
  xbmcplugin.endOfDirectory(CmfXEusxiNSzqnQJokdjRWLYhayGvU._addon_handle,cacheToDisc=CmfXEusxiNSzqnQJokdjRWLYhayGKP)
 def dp_View_Detail(CmfXEusxiNSzqnQJokdjRWLYhayGvU,CmfXEusxiNSzqnQJokdjRWLYhayGKV):
  CmfXEusxiNSzqnQJokdjRWLYhayGtp =CmfXEusxiNSzqnQJokdjRWLYhayGKV.get('videoid')
  CmfXEusxiNSzqnQJokdjRWLYhayGev =CmfXEusxiNSzqnQJokdjRWLYhayGKV.get('vidtype') 
  CmfXEusxiNSzqnQJokdjRWLYhayGBg=CmfXEusxiNSzqnQJokdjRWLYhayGKV.get('contenttype')
  CmfXEusxiNSzqnQJokdjRWLYhayGvU.addon_log(CmfXEusxiNSzqnQJokdjRWLYhayGtp)
  CmfXEusxiNSzqnQJokdjRWLYhayGvU.addon_log(CmfXEusxiNSzqnQJokdjRWLYhayGev)
  CmfXEusxiNSzqnQJokdjRWLYhayGvU.addon_log(CmfXEusxiNSzqnQJokdjRWLYhayGBg)
  CmfXEusxiNSzqnQJokdjRWLYhayGBA=CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.GetBookmarkInfo(CmfXEusxiNSzqnQJokdjRWLYhayGtp,CmfXEusxiNSzqnQJokdjRWLYhayGev,CmfXEusxiNSzqnQJokdjRWLYhayGBg)
  if CmfXEusxiNSzqnQJokdjRWLYhayGev=='tvshow':
   CmfXEusxiNSzqnQJokdjRWLYhayGrb={'mode':'SEASON_LIST','videoid':CmfXEusxiNSzqnQJokdjRWLYhayGBA['indexinfo']['videoid'],'vidtype':CmfXEusxiNSzqnQJokdjRWLYhayGBA['indexinfo']['vidtype'],}
   CmfXEusxiNSzqnQJokdjRWLYhayGlT='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(CmfXEusxiNSzqnQJokdjRWLYhayGrb))
  else:
   CmfXEusxiNSzqnQJokdjRWLYhayGrb={'mode':'MOVIE','contentid':CmfXEusxiNSzqnQJokdjRWLYhayGBA['indexinfo']['videoid'],'title':CmfXEusxiNSzqnQJokdjRWLYhayGBA['saveinfo']['infoLabels']['title'],'thumbnail':CmfXEusxiNSzqnQJokdjRWLYhayGBA['saveinfo']['thumbnail'],'age':CmfXEusxiNSzqnQJokdjRWLYhayGBA['saveinfo']['infoLabels']['mpaa'],}
   CmfXEusxiNSzqnQJokdjRWLYhayGlT='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(CmfXEusxiNSzqnQJokdjRWLYhayGrb))
  CmfXEusxiNSzqnQJokdjRWLYhayGrO=xbmcgui.ListItem(label=CmfXEusxiNSzqnQJokdjRWLYhayGBA['saveinfo']['title'],path=CmfXEusxiNSzqnQJokdjRWLYhayGlT)
  CmfXEusxiNSzqnQJokdjRWLYhayGrO.setArt(CmfXEusxiNSzqnQJokdjRWLYhayGBA['saveinfo']['thumbnail'])
  CmfXEusxiNSzqnQJokdjRWLYhayGvU.Set_InfoTag(CmfXEusxiNSzqnQJokdjRWLYhayGrO.getVideoInfoTag(),CmfXEusxiNSzqnQJokdjRWLYhayGBA['saveinfo']['infoLabels'])
  if CmfXEusxiNSzqnQJokdjRWLYhayGev=='movie':
   CmfXEusxiNSzqnQJokdjRWLYhayGrO.setIsFolder(CmfXEusxiNSzqnQJokdjRWLYhayGKP)
   CmfXEusxiNSzqnQJokdjRWLYhayGrO.setProperty('IsPlayable','true')
  else:
   CmfXEusxiNSzqnQJokdjRWLYhayGrO.setIsFolder(CmfXEusxiNSzqnQJokdjRWLYhayGKO)
   CmfXEusxiNSzqnQJokdjRWLYhayGrO.setProperty('IsPlayable','false')
  CmfXEusxiNSzqnQJokdjRWLYhayGvO=xbmcgui.Dialog()
  CmfXEusxiNSzqnQJokdjRWLYhayGvO.info(CmfXEusxiNSzqnQJokdjRWLYhayGrO)
 def wavve_main(CmfXEusxiNSzqnQJokdjRWLYhayGvU):
  CmfXEusxiNSzqnQJokdjRWLYhayGvU.WavveObj.KodiVersion=CmfXEusxiNSzqnQJokdjRWLYhayGKF(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  CmfXEusxiNSzqnQJokdjRWLYhayGKB=CmfXEusxiNSzqnQJokdjRWLYhayGvU.main_params.get('params')
  if CmfXEusxiNSzqnQJokdjRWLYhayGKB:
   CmfXEusxiNSzqnQJokdjRWLYhayGKU =base64.standard_b64decode(CmfXEusxiNSzqnQJokdjRWLYhayGKB).decode('utf-8')
   CmfXEusxiNSzqnQJokdjRWLYhayGKU =json.loads(CmfXEusxiNSzqnQJokdjRWLYhayGKU)
   CmfXEusxiNSzqnQJokdjRWLYhayGtl =CmfXEusxiNSzqnQJokdjRWLYhayGKU.get('mode')
   CmfXEusxiNSzqnQJokdjRWLYhayGKV =CmfXEusxiNSzqnQJokdjRWLYhayGKU.get('values')
  else:
   CmfXEusxiNSzqnQJokdjRWLYhayGtl=CmfXEusxiNSzqnQJokdjRWLYhayGvU.main_params.get('mode',CmfXEusxiNSzqnQJokdjRWLYhayGKD)
   CmfXEusxiNSzqnQJokdjRWLYhayGKV=CmfXEusxiNSzqnQJokdjRWLYhayGvU.main_params
  if CmfXEusxiNSzqnQJokdjRWLYhayGtl=='LOGOUT':
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.logout()
   return
  CmfXEusxiNSzqnQJokdjRWLYhayGvU.login_main()
  if CmfXEusxiNSzqnQJokdjRWLYhayGtl is CmfXEusxiNSzqnQJokdjRWLYhayGKD:
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.dp_Main_List()
  elif CmfXEusxiNSzqnQJokdjRWLYhayGtl in['LIVE','VOD','MOVIE','SPORTS']:
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.play_VIDEO(CmfXEusxiNSzqnQJokdjRWLYhayGKV)
  elif CmfXEusxiNSzqnQJokdjRWLYhayGtl=='LIVE_CATAGORY':
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.dp_LiveCatagory_List(CmfXEusxiNSzqnQJokdjRWLYhayGKV)
  elif CmfXEusxiNSzqnQJokdjRWLYhayGtl=='MAIN_CATAGORY':
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.dp_MainCatagory_List(CmfXEusxiNSzqnQJokdjRWLYhayGKV)
  elif CmfXEusxiNSzqnQJokdjRWLYhayGtl=='SUPERSECTION_LIST':
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.dp_SuperSection_List(CmfXEusxiNSzqnQJokdjRWLYhayGKV)
  elif CmfXEusxiNSzqnQJokdjRWLYhayGtl=='BANDLIVESECTION_LIST':
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.dp_BandLiveSection_List(CmfXEusxiNSzqnQJokdjRWLYhayGKV)
  elif CmfXEusxiNSzqnQJokdjRWLYhayGtl=='BAND2SECTION_LIST':
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.dp_Band2Section_List(CmfXEusxiNSzqnQJokdjRWLYhayGKV)
  elif CmfXEusxiNSzqnQJokdjRWLYhayGtl=='PROGRAM_LIST':
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.dp_Program_List(CmfXEusxiNSzqnQJokdjRWLYhayGKV)
  elif CmfXEusxiNSzqnQJokdjRWLYhayGtl=='SEASON_LIST':
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.dp_Season_List(CmfXEusxiNSzqnQJokdjRWLYhayGKV)
  elif CmfXEusxiNSzqnQJokdjRWLYhayGtl=='EPISODE_LIST':
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.dp_Episode_List(CmfXEusxiNSzqnQJokdjRWLYhayGKV)
  elif CmfXEusxiNSzqnQJokdjRWLYhayGtl=='MOVIE_LIST':
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.dp_Movie_List(CmfXEusxiNSzqnQJokdjRWLYhayGKV)
  elif CmfXEusxiNSzqnQJokdjRWLYhayGtl=='LIVE_LIST':
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.dp_LiveChannel_List(CmfXEusxiNSzqnQJokdjRWLYhayGKV)
  elif CmfXEusxiNSzqnQJokdjRWLYhayGtl=='ORDER_BY':
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.dp_setEpOrderby(CmfXEusxiNSzqnQJokdjRWLYhayGKV)
  elif CmfXEusxiNSzqnQJokdjRWLYhayGtl=='SEARCH_GROUP':
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.dp_Search_Group(CmfXEusxiNSzqnQJokdjRWLYhayGKV)
  elif CmfXEusxiNSzqnQJokdjRWLYhayGtl in['SEARCH_LIST','LOCAL_SEARCH']:
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.dp_Search_List(CmfXEusxiNSzqnQJokdjRWLYhayGKV)
  elif CmfXEusxiNSzqnQJokdjRWLYhayGtl=='WATCH_GROUP':
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.dp_Watch_Group(CmfXEusxiNSzqnQJokdjRWLYhayGKV)
  elif CmfXEusxiNSzqnQJokdjRWLYhayGtl=='WATCH_LIST':
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.dp_Watch_List(CmfXEusxiNSzqnQJokdjRWLYhayGKV)
  elif CmfXEusxiNSzqnQJokdjRWLYhayGtl=='SET_BOOKMARK':
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.dp_Set_Bookmark(CmfXEusxiNSzqnQJokdjRWLYhayGKV)
  elif CmfXEusxiNSzqnQJokdjRWLYhayGtl in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.dp_History_Remove(CmfXEusxiNSzqnQJokdjRWLYhayGKV)
  elif CmfXEusxiNSzqnQJokdjRWLYhayGtl in['TOTAL_SEARCH','TOTAL_HISTORY']:
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.dp_Global_Search(CmfXEusxiNSzqnQJokdjRWLYhayGKV)
  elif CmfXEusxiNSzqnQJokdjRWLYhayGtl=='SEARCH_HISTORY':
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.dp_Search_History(CmfXEusxiNSzqnQJokdjRWLYhayGKV)
  elif CmfXEusxiNSzqnQJokdjRWLYhayGtl=='MENU_BOOKMARK':
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.dp_Bookmark_Menu(CmfXEusxiNSzqnQJokdjRWLYhayGKV)
  elif CmfXEusxiNSzqnQJokdjRWLYhayGtl=='GAME_LIST':
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.dp_Sports_GameList(CmfXEusxiNSzqnQJokdjRWLYhayGKV)
  elif CmfXEusxiNSzqnQJokdjRWLYhayGtl=='VIEW_DETAIL':
   CmfXEusxiNSzqnQJokdjRWLYhayGvU.dp_View_Detail(CmfXEusxiNSzqnQJokdjRWLYhayGKV)
  else:
   CmfXEusxiNSzqnQJokdjRWLYhayGKD
# Created by pyminifier (https://github.com/liftoff/pyminifier)
