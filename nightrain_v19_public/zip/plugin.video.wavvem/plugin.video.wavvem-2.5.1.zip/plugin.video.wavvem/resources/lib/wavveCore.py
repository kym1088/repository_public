__author__="NightRain"
kdVapybKnRfLuAgvosjQtYPWFzcDBG=None
kdVapybKnRfLuAgvosjQtYPWFzcDBH=object
kdVapybKnRfLuAgvosjQtYPWFzcDBM=print
kdVapybKnRfLuAgvosjQtYPWFzcDqE=str
kdVapybKnRfLuAgvosjQtYPWFzcDqO=False
kdVapybKnRfLuAgvosjQtYPWFzcDql=open
kdVapybKnRfLuAgvosjQtYPWFzcDqh=True
kdVapybKnRfLuAgvosjQtYPWFzcDqC=range
kdVapybKnRfLuAgvosjQtYPWFzcDqN=len
kdVapybKnRfLuAgvosjQtYPWFzcDqB=Exception
kdVapybKnRfLuAgvosjQtYPWFzcDqI=dict
kdVapybKnRfLuAgvosjQtYPWFzcDqw=int
import urllib
import re
import json
import sys
import requests
import datetime
import base64
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
import httpx
try:
 import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
 __addon__=xbmcaddon.Addon()
 __language__ =__addon__.getLocalizedString
 __profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
 __version__=__addon__.getAddonInfo('version')
 __addonid__=__addon__.getAddonInfo('id')
 __addonname__=__addon__.getAddonInfo('name')
except:
 kdVapybKnRfLuAgvosjQtYPWFzcDBG
def addon_log(string):
 try:
  kdVapybKnRfLuAgvosjQtYPWFzcDEl=string.encode('utf-8','ignore')
  kdVapybKnRfLuAgvosjQtYPWFzcDEh=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,kdVapybKnRfLuAgvosjQtYPWFzcDEl),level=kdVapybKnRfLuAgvosjQtYPWFzcDEh)
 except:
  kdVapybKnRfLuAgvosjQtYPWFzcDEl='addonException: addon_log'
kdVapybKnRfLuAgvosjQtYPWFzcDEC =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
class kdVapybKnRfLuAgvosjQtYPWFzcDEO(kdVapybKnRfLuAgvosjQtYPWFzcDBH):
 def __init__(kdVapybKnRfLuAgvosjQtYPWFzcDEN):
  kdVapybKnRfLuAgvosjQtYPWFzcDEN.API_DOMAIN='https://apis.wavve.com'
  kdVapybKnRfLuAgvosjQtYPWFzcDEN.WV ={}
  kdVapybKnRfLuAgvosjQtYPWFzcDEN.Init_WV_Total()
  kdVapybKnRfLuAgvosjQtYPWFzcDEN.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  kdVapybKnRfLuAgvosjQtYPWFzcDEN.DEVICE ='pc'
  kdVapybKnRfLuAgvosjQtYPWFzcDEN.DRM ='wm'
  kdVapybKnRfLuAgvosjQtYPWFzcDEN.PARTNER ='pooq'
  kdVapybKnRfLuAgvosjQtYPWFzcDEN.POOQZONE ='none'
  kdVapybKnRfLuAgvosjQtYPWFzcDEN.REGION ='kor'
  kdVapybKnRfLuAgvosjQtYPWFzcDEN.TARGETAGE ='all'
  kdVapybKnRfLuAgvosjQtYPWFzcDEN.HTTPTAG ='https://'
  kdVapybKnRfLuAgvosjQtYPWFzcDEN.LIST_LIMIT=40 
  kdVapybKnRfLuAgvosjQtYPWFzcDEN.EP_LIMIT =30 
  kdVapybKnRfLuAgvosjQtYPWFzcDEN.MV_LIMIT =24 
  kdVapybKnRfLuAgvosjQtYPWFzcDEN.SEARCH_LIMIT=20 
  kdVapybKnRfLuAgvosjQtYPWFzcDEN.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36'
  kdVapybKnRfLuAgvosjQtYPWFzcDEN.DEFAULT_HEADER={'user-agent':kdVapybKnRfLuAgvosjQtYPWFzcDEN.USER_AGENT}
  kdVapybKnRfLuAgvosjQtYPWFzcDEN.KodiVersion=20
  kdVapybKnRfLuAgvosjQtYPWFzcDEN.WV_SESSION_COOKIES1=''
  kdVapybKnRfLuAgvosjQtYPWFzcDEN.WV_SESSION_COOKIES2=''
  kdVapybKnRfLuAgvosjQtYPWFzcDEN.COOKIE_FILE_NAME =''
  kdVapybKnRfLuAgvosjQtYPWFzcDEN.WV_STREAM_FILENAME =''
 def Init_WV_Total(kdVapybKnRfLuAgvosjQtYPWFzcDEN):
  kdVapybKnRfLuAgvosjQtYPWFzcDEN.WV={'account':{},'cookies':{},}
 def make_auth_header(kdVapybKnRfLuAgvosjQtYPWFzcDEN):
  return{'authorization':'Bearer {}'.format(kdVapybKnRfLuAgvosjQtYPWFzcDEN.WV['cookies']['credential']),'wavve-credential':kdVapybKnRfLuAgvosjQtYPWFzcDEN.WV['cookies']['credential'],}
 def callRequestCookies(kdVapybKnRfLuAgvosjQtYPWFzcDEN,jobtype,kdVapybKnRfLuAgvosjQtYPWFzcDOe,payload=kdVapybKnRfLuAgvosjQtYPWFzcDBG,params=kdVapybKnRfLuAgvosjQtYPWFzcDBG,headers=kdVapybKnRfLuAgvosjQtYPWFzcDBG,cookies=kdVapybKnRfLuAgvosjQtYPWFzcDBG):
  kdVapybKnRfLuAgvosjQtYPWFzcDEB=kdVapybKnRfLuAgvosjQtYPWFzcDEN.DEFAULT_HEADER
  if headers:kdVapybKnRfLuAgvosjQtYPWFzcDEB.update(headers)
  if jobtype=='Get':
   kdVapybKnRfLuAgvosjQtYPWFzcDEq=httpx.get(kdVapybKnRfLuAgvosjQtYPWFzcDOe,params=params,headers=kdVapybKnRfLuAgvosjQtYPWFzcDEB,cookies=cookies)
  else:
   kdVapybKnRfLuAgvosjQtYPWFzcDEq=httpx.post(kdVapybKnRfLuAgvosjQtYPWFzcDOe,json=payload,params=params,headers=kdVapybKnRfLuAgvosjQtYPWFzcDEB,cookies=cookies)
  kdVapybKnRfLuAgvosjQtYPWFzcDBM(kdVapybKnRfLuAgvosjQtYPWFzcDqE(kdVapybKnRfLuAgvosjQtYPWFzcDEq.status_code)+' - '+kdVapybKnRfLuAgvosjQtYPWFzcDqE(kdVapybKnRfLuAgvosjQtYPWFzcDEq.url))
  return kdVapybKnRfLuAgvosjQtYPWFzcDEq
 def JsonFile_Save(kdVapybKnRfLuAgvosjQtYPWFzcDEN,filename,kdVapybKnRfLuAgvosjQtYPWFzcDEI):
  if filename=='':return kdVapybKnRfLuAgvosjQtYPWFzcDqO
  try:
   fp=kdVapybKnRfLuAgvosjQtYPWFzcDql(filename,'w',-1,'utf-8')
   json.dump(kdVapybKnRfLuAgvosjQtYPWFzcDEI,fp,indent=4,ensure_ascii=kdVapybKnRfLuAgvosjQtYPWFzcDqO)
   fp.close()
  except:
   return kdVapybKnRfLuAgvosjQtYPWFzcDqO
  return kdVapybKnRfLuAgvosjQtYPWFzcDqh
 def JsonFile_Load(kdVapybKnRfLuAgvosjQtYPWFzcDEN,filename):
  if filename=='':return{}
  try:
   fp=kdVapybKnRfLuAgvosjQtYPWFzcDql(filename,'r',-1,'utf-8')
   kdVapybKnRfLuAgvosjQtYPWFzcDEX=json.load(fp)
   fp.close()
  except:
   return{}
  return kdVapybKnRfLuAgvosjQtYPWFzcDEX
 def TextFile_Save(kdVapybKnRfLuAgvosjQtYPWFzcDEN,filename,resText):
  if filename=='':return kdVapybKnRfLuAgvosjQtYPWFzcDqO
  try:
   fp=kdVapybKnRfLuAgvosjQtYPWFzcDql(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return kdVapybKnRfLuAgvosjQtYPWFzcDqO
  return kdVapybKnRfLuAgvosjQtYPWFzcDqh
 def Save_session_acount(kdVapybKnRfLuAgvosjQtYPWFzcDEN,kdVapybKnRfLuAgvosjQtYPWFzcDEJ,kdVapybKnRfLuAgvosjQtYPWFzcDEe,kdVapybKnRfLuAgvosjQtYPWFzcDEU):
  kdVapybKnRfLuAgvosjQtYPWFzcDEN.WV['account']['wvid']=base64.standard_b64encode(kdVapybKnRfLuAgvosjQtYPWFzcDEJ.encode()).decode('utf-8')
  kdVapybKnRfLuAgvosjQtYPWFzcDEN.WV['account']['wvpw']=base64.standard_b64encode(kdVapybKnRfLuAgvosjQtYPWFzcDEe.encode()).decode('utf-8')
  kdVapybKnRfLuAgvosjQtYPWFzcDEN.WV['account']['wvpf']=kdVapybKnRfLuAgvosjQtYPWFzcDEU 
 def Load_session_acount(kdVapybKnRfLuAgvosjQtYPWFzcDEN):
  try:
   kdVapybKnRfLuAgvosjQtYPWFzcDEJ=base64.standard_b64decode(kdVapybKnRfLuAgvosjQtYPWFzcDEN.WV['account']['wvid']).decode('utf-8')
   kdVapybKnRfLuAgvosjQtYPWFzcDEe=base64.standard_b64decode(kdVapybKnRfLuAgvosjQtYPWFzcDEN.WV['account']['wvpw']).decode('utf-8')
   kdVapybKnRfLuAgvosjQtYPWFzcDEU=kdVapybKnRfLuAgvosjQtYPWFzcDEN.WV['account']['wvpf']
  except:
   return '','',0
  return kdVapybKnRfLuAgvosjQtYPWFzcDEJ,kdVapybKnRfLuAgvosjQtYPWFzcDEe,kdVapybKnRfLuAgvosjQtYPWFzcDEU
 def GetDefaultParams(kdVapybKnRfLuAgvosjQtYPWFzcDEN):
  kdVapybKnRfLuAgvosjQtYPWFzcDEx={'apikey':kdVapybKnRfLuAgvosjQtYPWFzcDEN.APIKEY,'device':kdVapybKnRfLuAgvosjQtYPWFzcDEN.DEVICE,'drm':kdVapybKnRfLuAgvosjQtYPWFzcDEN.DRM,'partner':kdVapybKnRfLuAgvosjQtYPWFzcDEN.PARTNER,'pooqzone':kdVapybKnRfLuAgvosjQtYPWFzcDEN.POOQZONE,'region':kdVapybKnRfLuAgvosjQtYPWFzcDEN.REGION,'targetage':kdVapybKnRfLuAgvosjQtYPWFzcDEN.TARGETAGE,'client_version':'7.1.40',}
  return kdVapybKnRfLuAgvosjQtYPWFzcDEx
 def GetDefaultParams_AND(kdVapybKnRfLuAgvosjQtYPWFzcDEN):
  kdVapybKnRfLuAgvosjQtYPWFzcDEx={'apikey':'6A87455D54481A536DFB8AD397C5EC4D','credential':kdVapybKnRfLuAgvosjQtYPWFzcDEN.WV['cookies']['credential'],'device':'ott','drm':kdVapybKnRfLuAgvosjQtYPWFzcDEN.DRM,'partner':kdVapybKnRfLuAgvosjQtYPWFzcDEN.PARTNER,'pooqzone':kdVapybKnRfLuAgvosjQtYPWFzcDEN.POOQZONE,'region':kdVapybKnRfLuAgvosjQtYPWFzcDEN.REGION,'targetage':kdVapybKnRfLuAgvosjQtYPWFzcDEN.TARGETAGE,}
  return kdVapybKnRfLuAgvosjQtYPWFzcDEx
 def GetGUID(kdVapybKnRfLuAgvosjQtYPWFzcDEN,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   kdVapybKnRfLuAgvosjQtYPWFzcDEm=kdVapybKnRfLuAgvosjQtYPWFzcDEN.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   kdVapybKnRfLuAgvosjQtYPWFzcDEi=GenerateRandomString(5)
   kdVapybKnRfLuAgvosjQtYPWFzcDEr=kdVapybKnRfLuAgvosjQtYPWFzcDEi+media+kdVapybKnRfLuAgvosjQtYPWFzcDEm
   return kdVapybKnRfLuAgvosjQtYPWFzcDEr
  def GenerateRandomString(num):
   from random import randint
   kdVapybKnRfLuAgvosjQtYPWFzcDET=""
   for i in kdVapybKnRfLuAgvosjQtYPWFzcDqC(0,num):
    s=kdVapybKnRfLuAgvosjQtYPWFzcDqE(randint(1,5))
    kdVapybKnRfLuAgvosjQtYPWFzcDET+=s
   return kdVapybKnRfLuAgvosjQtYPWFzcDET
  if guidType==3:
   kdVapybKnRfLuAgvosjQtYPWFzcDEr=guid_str
  else:
   kdVapybKnRfLuAgvosjQtYPWFzcDEr=GenerateID(guid_str)
  kdVapybKnRfLuAgvosjQtYPWFzcDES=kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetHash(kdVapybKnRfLuAgvosjQtYPWFzcDEr)
  if guidType in[2,3]:
   kdVapybKnRfLuAgvosjQtYPWFzcDES='%s-%s-%s-%s-%s'%(kdVapybKnRfLuAgvosjQtYPWFzcDES[:8],kdVapybKnRfLuAgvosjQtYPWFzcDES[8:12],kdVapybKnRfLuAgvosjQtYPWFzcDES[12:16],kdVapybKnRfLuAgvosjQtYPWFzcDES[16:20],kdVapybKnRfLuAgvosjQtYPWFzcDES[20:])
  return kdVapybKnRfLuAgvosjQtYPWFzcDES
 def GetHash(kdVapybKnRfLuAgvosjQtYPWFzcDEN,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return kdVapybKnRfLuAgvosjQtYPWFzcDqE(m.hexdigest())
 def CheckQuality(kdVapybKnRfLuAgvosjQtYPWFzcDEN,sel_qt,qt_list):
  kdVapybKnRfLuAgvosjQtYPWFzcDEG=0
  for kdVapybKnRfLuAgvosjQtYPWFzcDEH in qt_list:
   if sel_qt>=kdVapybKnRfLuAgvosjQtYPWFzcDEH:return kdVapybKnRfLuAgvosjQtYPWFzcDEH
   kdVapybKnRfLuAgvosjQtYPWFzcDEG=kdVapybKnRfLuAgvosjQtYPWFzcDEH
  return kdVapybKnRfLuAgvosjQtYPWFzcDEG
 def Get_Now_Datetime(kdVapybKnRfLuAgvosjQtYPWFzcDEN):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(kdVapybKnRfLuAgvosjQtYPWFzcDEN,in_text):
  kdVapybKnRfLuAgvosjQtYPWFzcDOE=in_text.replace('&lt;','<').replace('&gt;','>')
  kdVapybKnRfLuAgvosjQtYPWFzcDOE=kdVapybKnRfLuAgvosjQtYPWFzcDOE.replace('<br>','\n')
  kdVapybKnRfLuAgvosjQtYPWFzcDOE=kdVapybKnRfLuAgvosjQtYPWFzcDOE.replace('$O$','')
  kdVapybKnRfLuAgvosjQtYPWFzcDOE=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',kdVapybKnRfLuAgvosjQtYPWFzcDOE)
  kdVapybKnRfLuAgvosjQtYPWFzcDOE=kdVapybKnRfLuAgvosjQtYPWFzcDOE.lstrip('#')
  return kdVapybKnRfLuAgvosjQtYPWFzcDOE
 def make_str_ToCookie(kdVapybKnRfLuAgvosjQtYPWFzcDEN,cookieStr):
  kdVapybKnRfLuAgvosjQtYPWFzcDOl={}
  for kdVapybKnRfLuAgvosjQtYPWFzcDOh in cookieStr.split(';'):
   kdVapybKnRfLuAgvosjQtYPWFzcDOC=kdVapybKnRfLuAgvosjQtYPWFzcDOh.split('=')
   kdVapybKnRfLuAgvosjQtYPWFzcDOl[kdVapybKnRfLuAgvosjQtYPWFzcDOC[0]]=kdVapybKnRfLuAgvosjQtYPWFzcDOC[1]
  return kdVapybKnRfLuAgvosjQtYPWFzcDOl 
 def make_stream_header(kdVapybKnRfLuAgvosjQtYPWFzcDEN,kdVapybKnRfLuAgvosjQtYPWFzcDOw,kdVapybKnRfLuAgvosjQtYPWFzcDOl):
  kdVapybKnRfLuAgvosjQtYPWFzcDON=''
  if kdVapybKnRfLuAgvosjQtYPWFzcDOl not in[{},kdVapybKnRfLuAgvosjQtYPWFzcDBG,'']:
   kdVapybKnRfLuAgvosjQtYPWFzcDOB=kdVapybKnRfLuAgvosjQtYPWFzcDqN(kdVapybKnRfLuAgvosjQtYPWFzcDOl)
   for kdVapybKnRfLuAgvosjQtYPWFzcDOq,kdVapybKnRfLuAgvosjQtYPWFzcDOI in kdVapybKnRfLuAgvosjQtYPWFzcDOl.items():
    kdVapybKnRfLuAgvosjQtYPWFzcDON+='{}={}'.format(kdVapybKnRfLuAgvosjQtYPWFzcDOq,kdVapybKnRfLuAgvosjQtYPWFzcDOI)
    kdVapybKnRfLuAgvosjQtYPWFzcDOB+=-1
    if kdVapybKnRfLuAgvosjQtYPWFzcDOB>0:kdVapybKnRfLuAgvosjQtYPWFzcDON+='; '
   kdVapybKnRfLuAgvosjQtYPWFzcDOw['cookie']=kdVapybKnRfLuAgvosjQtYPWFzcDON
  kdVapybKnRfLuAgvosjQtYPWFzcDOX=''
  i=0
  for kdVapybKnRfLuAgvosjQtYPWFzcDOq,kdVapybKnRfLuAgvosjQtYPWFzcDOI in kdVapybKnRfLuAgvosjQtYPWFzcDOw.items():
   i=i+1
   if i>1:kdVapybKnRfLuAgvosjQtYPWFzcDOX+='&'
   kdVapybKnRfLuAgvosjQtYPWFzcDOX+='{}={}'.format(kdVapybKnRfLuAgvosjQtYPWFzcDOq,urllib.parse.quote(kdVapybKnRfLuAgvosjQtYPWFzcDOI))
  return kdVapybKnRfLuAgvosjQtYPWFzcDOX
 def GetCredential(kdVapybKnRfLuAgvosjQtYPWFzcDEN,user_id,user_pw,user_pf):
  kdVapybKnRfLuAgvosjQtYPWFzcDOJ=kdVapybKnRfLuAgvosjQtYPWFzcDqO
  try:
   kdVapybKnRfLuAgvosjQtYPWFzcDOe=kdVapybKnRfLuAgvosjQtYPWFzcDEN.API_DOMAIN+ '/login'
   kdVapybKnRfLuAgvosjQtYPWFzcDEx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetDefaultParams()
   kdVapybKnRfLuAgvosjQtYPWFzcDOw={'content-type':'application/json',}
   kdVapybKnRfLuAgvosjQtYPWFzcDOU={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   kdVapybKnRfLuAgvosjQtYPWFzcDOx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.callRequestCookies('Post',kdVapybKnRfLuAgvosjQtYPWFzcDOe,payload=kdVapybKnRfLuAgvosjQtYPWFzcDOU,params=kdVapybKnRfLuAgvosjQtYPWFzcDEx,headers=kdVapybKnRfLuAgvosjQtYPWFzcDOw,cookies=kdVapybKnRfLuAgvosjQtYPWFzcDBG)
   addon_log('url : {}'.format(kdVapybKnRfLuAgvosjQtYPWFzcDOe))
   addon_log('res : {}'.format(kdVapybKnRfLuAgvosjQtYPWFzcDOx.text))
   kdVapybKnRfLuAgvosjQtYPWFzcDOm=json.loads(kdVapybKnRfLuAgvosjQtYPWFzcDOx.text)
   kdVapybKnRfLuAgvosjQtYPWFzcDEN.WV['cookies']['credential']=kdVapybKnRfLuAgvosjQtYPWFzcDOm['credential']
   if user_pf!=0:
    kdVapybKnRfLuAgvosjQtYPWFzcDOU={'id':kdVapybKnRfLuAgvosjQtYPWFzcDEN.WV['cookies']['credential'],'password':'','profile':kdVapybKnRfLuAgvosjQtYPWFzcDqE(user_pf),'pushid':'','type':'credential'}
    kdVapybKnRfLuAgvosjQtYPWFzcDEx =kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetDefaultParams() 
    kdVapybKnRfLuAgvosjQtYPWFzcDOx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.callRequestCookies('Post',kdVapybKnRfLuAgvosjQtYPWFzcDOe,payload=kdVapybKnRfLuAgvosjQtYPWFzcDOU,params=kdVapybKnRfLuAgvosjQtYPWFzcDEx,headers=kdVapybKnRfLuAgvosjQtYPWFzcDBG,cookies=kdVapybKnRfLuAgvosjQtYPWFzcDBG)
    kdVapybKnRfLuAgvosjQtYPWFzcDOm=json.loads(kdVapybKnRfLuAgvosjQtYPWFzcDOx.text)
    kdVapybKnRfLuAgvosjQtYPWFzcDEN.WV['cookies']['credential']=kdVapybKnRfLuAgvosjQtYPWFzcDOm['credential']
   kdVapybKnRfLuAgvosjQtYPWFzcDOi=user_id+kdVapybKnRfLuAgvosjQtYPWFzcDqE(user_pf) 
   kdVapybKnRfLuAgvosjQtYPWFzcDEN.WV['cookies']['uuid']=kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetGUID(guid_str=kdVapybKnRfLuAgvosjQtYPWFzcDOi,guidType=3)
   kdVapybKnRfLuAgvosjQtYPWFzcDOJ=kdVapybKnRfLuAgvosjQtYPWFzcDqh
  except kdVapybKnRfLuAgvosjQtYPWFzcDqB as exception:
   kdVapybKnRfLuAgvosjQtYPWFzcDBM(exception)
   kdVapybKnRfLuAgvosjQtYPWFzcDEN.Init_WV_Total()
  return kdVapybKnRfLuAgvosjQtYPWFzcDOJ
 def GetCredential_new(kdVapybKnRfLuAgvosjQtYPWFzcDEN,user_id,user_pw,user_pf):
  kdVapybKnRfLuAgvosjQtYPWFzcDOJ=kdVapybKnRfLuAgvosjQtYPWFzcDqO
  try:
   kdVapybKnRfLuAgvosjQtYPWFzcDOe='https://account-api.wavve.com/v1/signin/wavve'
   kdVapybKnRfLuAgvosjQtYPWFzcDEx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetDefaultParams()
   kdVapybKnRfLuAgvosjQtYPWFzcDOw={'wavve-credential':'none','content-type':'application/json',}
   kdVapybKnRfLuAgvosjQtYPWFzcDOU={'id':user_id,'password':user_pw,'device':'pc','type':'wavve',}
   kdVapybKnRfLuAgvosjQtYPWFzcDOx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.callRequestCookies('Post',kdVapybKnRfLuAgvosjQtYPWFzcDOe,payload=kdVapybKnRfLuAgvosjQtYPWFzcDOU,params=kdVapybKnRfLuAgvosjQtYPWFzcDEx,headers=kdVapybKnRfLuAgvosjQtYPWFzcDOw,cookies=kdVapybKnRfLuAgvosjQtYPWFzcDBG)
   addon_log('url : {}'.format(kdVapybKnRfLuAgvosjQtYPWFzcDOe))
   addon_log('res : {}'.format(kdVapybKnRfLuAgvosjQtYPWFzcDOx.text))
   kdVapybKnRfLuAgvosjQtYPWFzcDOm=json.loads(kdVapybKnRfLuAgvosjQtYPWFzcDOx.text)
   kdVapybKnRfLuAgvosjQtYPWFzcDEN.WV['cookies']['credential']=kdVapybKnRfLuAgvosjQtYPWFzcDOm['credential']
   kdVapybKnRfLuAgvosjQtYPWFzcDOe='https://account-api.wavve.com/v1/signin'
   kdVapybKnRfLuAgvosjQtYPWFzcDOw={'wavve-credential':kdVapybKnRfLuAgvosjQtYPWFzcDEN.WV['cookies']['credential'],'content-type':'application/json',}
   kdVapybKnRfLuAgvosjQtYPWFzcDOU={'id':kdVapybKnRfLuAgvosjQtYPWFzcDEN.WV['cookies']['credential'],'profile':kdVapybKnRfLuAgvosjQtYPWFzcDqE(user_pf),'device':'pc','type':'credential',}
   kdVapybKnRfLuAgvosjQtYPWFzcDOx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.callRequestCookies('Post',kdVapybKnRfLuAgvosjQtYPWFzcDOe,payload=kdVapybKnRfLuAgvosjQtYPWFzcDOU,params=kdVapybKnRfLuAgvosjQtYPWFzcDEx,headers=kdVapybKnRfLuAgvosjQtYPWFzcDOw,cookies=kdVapybKnRfLuAgvosjQtYPWFzcDBG)
   kdVapybKnRfLuAgvosjQtYPWFzcDOm=json.loads(kdVapybKnRfLuAgvosjQtYPWFzcDOx.text)
   kdVapybKnRfLuAgvosjQtYPWFzcDEN.WV['cookies']['credential']=kdVapybKnRfLuAgvosjQtYPWFzcDOm['credential']
   kdVapybKnRfLuAgvosjQtYPWFzcDEN.WV['cookies']['uuid'] =kdVapybKnRfLuAgvosjQtYPWFzcDOm['device_id']
   kdVapybKnRfLuAgvosjQtYPWFzcDOJ=kdVapybKnRfLuAgvosjQtYPWFzcDqh
  except kdVapybKnRfLuAgvosjQtYPWFzcDqB as exception:
   kdVapybKnRfLuAgvosjQtYPWFzcDBM(exception)
   kdVapybKnRfLuAgvosjQtYPWFzcDEN.Init_WV_Total()
  return kdVapybKnRfLuAgvosjQtYPWFzcDOJ
 def GetIssue(kdVapybKnRfLuAgvosjQtYPWFzcDEN):
  kdVapybKnRfLuAgvosjQtYPWFzcDOr=kdVapybKnRfLuAgvosjQtYPWFzcDqO
  try:
   kdVapybKnRfLuAgvosjQtYPWFzcDOe=kdVapybKnRfLuAgvosjQtYPWFzcDEN.API_DOMAIN+'/guid/issue'
   kdVapybKnRfLuAgvosjQtYPWFzcDEx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetDefaultParams()
   kdVapybKnRfLuAgvosjQtYPWFzcDOx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.callRequestCookies('Get',kdVapybKnRfLuAgvosjQtYPWFzcDOe,payload=kdVapybKnRfLuAgvosjQtYPWFzcDBG,params=kdVapybKnRfLuAgvosjQtYPWFzcDEx,headers=kdVapybKnRfLuAgvosjQtYPWFzcDBG,cookies=kdVapybKnRfLuAgvosjQtYPWFzcDBG)
   kdVapybKnRfLuAgvosjQtYPWFzcDOm=json.loads(kdVapybKnRfLuAgvosjQtYPWFzcDOx.text)
   kdVapybKnRfLuAgvosjQtYPWFzcDOT=kdVapybKnRfLuAgvosjQtYPWFzcDOm['guid']
   kdVapybKnRfLuAgvosjQtYPWFzcDOS=kdVapybKnRfLuAgvosjQtYPWFzcDOm['guidtimestamp']
   if kdVapybKnRfLuAgvosjQtYPWFzcDOT:kdVapybKnRfLuAgvosjQtYPWFzcDOr=kdVapybKnRfLuAgvosjQtYPWFzcDqh
  except kdVapybKnRfLuAgvosjQtYPWFzcDqB as exception:
   kdVapybKnRfLuAgvosjQtYPWFzcDBM(exception)
   kdVapybKnRfLuAgvosjQtYPWFzcDOT='none'
   kdVapybKnRfLuAgvosjQtYPWFzcDOS='none' 
  kdVapybKnRfLuAgvosjQtYPWFzcDEN.guid=kdVapybKnRfLuAgvosjQtYPWFzcDOT
  kdVapybKnRfLuAgvosjQtYPWFzcDEN.guidtimestamp=kdVapybKnRfLuAgvosjQtYPWFzcDOS
  return kdVapybKnRfLuAgvosjQtYPWFzcDOr
 def Baseapi_Parse(kdVapybKnRfLuAgvosjQtYPWFzcDEN,kdVapybKnRfLuAgvosjQtYPWFzcDlE):
  try:
   kdVapybKnRfLuAgvosjQtYPWFzcDOG =urllib.parse.urlsplit(kdVapybKnRfLuAgvosjQtYPWFzcDlE)
   if kdVapybKnRfLuAgvosjQtYPWFzcDOG.netloc=='':
    kdVapybKnRfLuAgvosjQtYPWFzcDOe=kdVapybKnRfLuAgvosjQtYPWFzcDEN.HTTPTAG+kdVapybKnRfLuAgvosjQtYPWFzcDOG.netloc+kdVapybKnRfLuAgvosjQtYPWFzcDOG.path
   else:
    kdVapybKnRfLuAgvosjQtYPWFzcDOe=kdVapybKnRfLuAgvosjQtYPWFzcDOG.scheme+'://'+kdVapybKnRfLuAgvosjQtYPWFzcDOG.netloc+kdVapybKnRfLuAgvosjQtYPWFzcDOG.path
   kdVapybKnRfLuAgvosjQtYPWFzcDEx=kdVapybKnRfLuAgvosjQtYPWFzcDqI(urllib.parse.parse_qsl(kdVapybKnRfLuAgvosjQtYPWFzcDOG.query))
  except kdVapybKnRfLuAgvosjQtYPWFzcDqB as exception:
   kdVapybKnRfLuAgvosjQtYPWFzcDBM(exception)
   return '',{}
  return kdVapybKnRfLuAgvosjQtYPWFzcDOe,kdVapybKnRfLuAgvosjQtYPWFzcDEx
 def GetSupermultiUrl(kdVapybKnRfLuAgvosjQtYPWFzcDEN,sCode,sIndex='0'):
  try:
   kdVapybKnRfLuAgvosjQtYPWFzcDOe=kdVapybKnRfLuAgvosjQtYPWFzcDEN.API_DOMAIN+'/cf/supermultisections/'+sCode
   kdVapybKnRfLuAgvosjQtYPWFzcDEx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetDefaultParams()
   kdVapybKnRfLuAgvosjQtYPWFzcDOx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.callRequestCookies('Get',kdVapybKnRfLuAgvosjQtYPWFzcDOe,payload=kdVapybKnRfLuAgvosjQtYPWFzcDBG,params=kdVapybKnRfLuAgvosjQtYPWFzcDEx,headers=kdVapybKnRfLuAgvosjQtYPWFzcDBG,cookies=kdVapybKnRfLuAgvosjQtYPWFzcDBG)
   kdVapybKnRfLuAgvosjQtYPWFzcDOm=json.loads(kdVapybKnRfLuAgvosjQtYPWFzcDOx.text)
   kdVapybKnRfLuAgvosjQtYPWFzcDOH=kdVapybKnRfLuAgvosjQtYPWFzcDOm['multisectionlist'][kdVapybKnRfLuAgvosjQtYPWFzcDqw(sIndex)]['eventlist'][1]['url']
  except kdVapybKnRfLuAgvosjQtYPWFzcDqB as exception:
   kdVapybKnRfLuAgvosjQtYPWFzcDBM(exception)
   return ''
  return kdVapybKnRfLuAgvosjQtYPWFzcDOH
 def Get_LiveCatagory_List(kdVapybKnRfLuAgvosjQtYPWFzcDEN,sCode,sIndex='0'):
  kdVapybKnRfLuAgvosjQtYPWFzcDOM=[]
  kdVapybKnRfLuAgvosjQtYPWFzcDlE =kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetSupermultiUrl(sCode,sIndex)
  (kdVapybKnRfLuAgvosjQtYPWFzcDOe,kdVapybKnRfLuAgvosjQtYPWFzcDEx)=kdVapybKnRfLuAgvosjQtYPWFzcDEN.Baseapi_Parse(kdVapybKnRfLuAgvosjQtYPWFzcDlE)
  if kdVapybKnRfLuAgvosjQtYPWFzcDOe=='':return kdVapybKnRfLuAgvosjQtYPWFzcDOM,''
  addon_log('Get_LiveCatagory_List url : {}'.format(kdVapybKnRfLuAgvosjQtYPWFzcDOe))
  try:
   kdVapybKnRfLuAgvosjQtYPWFzcDEx.update(kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetDefaultParams())
   kdVapybKnRfLuAgvosjQtYPWFzcDOx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.callRequestCookies('Get',kdVapybKnRfLuAgvosjQtYPWFzcDOe,payload=kdVapybKnRfLuAgvosjQtYPWFzcDBG,params=kdVapybKnRfLuAgvosjQtYPWFzcDEx,headers=kdVapybKnRfLuAgvosjQtYPWFzcDBG,cookies=kdVapybKnRfLuAgvosjQtYPWFzcDBG)
   kdVapybKnRfLuAgvosjQtYPWFzcDOm=json.loads(kdVapybKnRfLuAgvosjQtYPWFzcDOx.text)
   if not('filter_item_list' in kdVapybKnRfLuAgvosjQtYPWFzcDOm['filter']['filterlist'][0]):return[],''
   kdVapybKnRfLuAgvosjQtYPWFzcDlO=kdVapybKnRfLuAgvosjQtYPWFzcDOm['filter']['filterlist'][0]['filter_item_list']
   for kdVapybKnRfLuAgvosjQtYPWFzcDlh in kdVapybKnRfLuAgvosjQtYPWFzcDlO:
    kdVapybKnRfLuAgvosjQtYPWFzcDlC={'title':kdVapybKnRfLuAgvosjQtYPWFzcDlh['title'],'genre':kdVapybKnRfLuAgvosjQtYPWFzcDlh['api_parameters'][kdVapybKnRfLuAgvosjQtYPWFzcDlh['api_parameters'].index('=')+1:]}
    kdVapybKnRfLuAgvosjQtYPWFzcDOM.append(kdVapybKnRfLuAgvosjQtYPWFzcDlC)
  except kdVapybKnRfLuAgvosjQtYPWFzcDqB as exception:
   kdVapybKnRfLuAgvosjQtYPWFzcDBM(exception)
   return[],''
  return kdVapybKnRfLuAgvosjQtYPWFzcDOM,kdVapybKnRfLuAgvosjQtYPWFzcDlE
 def Get_MainCatagory_List(kdVapybKnRfLuAgvosjQtYPWFzcDEN,sCode,sIndex,sType):
  kdVapybKnRfLuAgvosjQtYPWFzcDOM=[]
  kdVapybKnRfLuAgvosjQtYPWFzcDOe='https://apis.wavve.com/es/category/launcher-band'
  kdVapybKnRfLuAgvosjQtYPWFzcDEx={'uitype':sCode,'uiparent':'GN52-'+sCode,'uirank':sIndex,'broadcastid':sCode,'offset':'0','limit':'20','uicode':sCode,'mtype':'N','ctype':sType,'orderby':'default',}
  try:
   kdVapybKnRfLuAgvosjQtYPWFzcDEx.update(kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetDefaultParams())
   kdVapybKnRfLuAgvosjQtYPWFzcDOx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.callRequestCookies('Get',kdVapybKnRfLuAgvosjQtYPWFzcDOe,payload=kdVapybKnRfLuAgvosjQtYPWFzcDBG,params=kdVapybKnRfLuAgvosjQtYPWFzcDEx,headers=kdVapybKnRfLuAgvosjQtYPWFzcDBG,cookies=kdVapybKnRfLuAgvosjQtYPWFzcDBG)
   kdVapybKnRfLuAgvosjQtYPWFzcDOm=json.loads(kdVapybKnRfLuAgvosjQtYPWFzcDOx.text)
   if not('celllist' in kdVapybKnRfLuAgvosjQtYPWFzcDOm['band']):return[]
   kdVapybKnRfLuAgvosjQtYPWFzcDlO=kdVapybKnRfLuAgvosjQtYPWFzcDOm['band']['celllist']
   for kdVapybKnRfLuAgvosjQtYPWFzcDlh in kdVapybKnRfLuAgvosjQtYPWFzcDlO:
    kdVapybKnRfLuAgvosjQtYPWFzcDlN =kdVapybKnRfLuAgvosjQtYPWFzcDlh['event_list'][1]['url']
    (kdVapybKnRfLuAgvosjQtYPWFzcDlB,kdVapybKnRfLuAgvosjQtYPWFzcDlq)=kdVapybKnRfLuAgvosjQtYPWFzcDEN.Baseapi_Parse(kdVapybKnRfLuAgvosjQtYPWFzcDlN)
    kdVapybKnRfLuAgvosjQtYPWFzcDlC={'title':kdVapybKnRfLuAgvosjQtYPWFzcDlh['title_list'][0]['text'],'suburl':kdVapybKnRfLuAgvosjQtYPWFzcDlB,'subapi':kdVapybKnRfLuAgvosjQtYPWFzcDlq.get('api'),'subtype':'catagory' if kdVapybKnRfLuAgvosjQtYPWFzcDlq else 'supersection'}
    kdVapybKnRfLuAgvosjQtYPWFzcDOM.append(kdVapybKnRfLuAgvosjQtYPWFzcDlC)
  except kdVapybKnRfLuAgvosjQtYPWFzcDqB as exception:
   kdVapybKnRfLuAgvosjQtYPWFzcDBM(exception)
   return[]
  return kdVapybKnRfLuAgvosjQtYPWFzcDOM
 def Get_SuperMultiSection_List(kdVapybKnRfLuAgvosjQtYPWFzcDEN,subapi_text):
  kdVapybKnRfLuAgvosjQtYPWFzcDOM=[]
  if '/multiband/' in subapi_text: 
   kdVapybKnRfLuAgvosjQtYPWFzcDOe=subapi_text 
   kdVapybKnRfLuAgvosjQtYPWFzcDEx={'client':'40'}
  else:
   kdVapybKnRfLuAgvosjQtYPWFzcDOe=subapi_text 
   kdVapybKnRfLuAgvosjQtYPWFzcDOe=kdVapybKnRfLuAgvosjQtYPWFzcDOe.replace('www.wavve.com','apis.wavve.com').replace('supermultisection','v1/multiband')
   kdVapybKnRfLuAgvosjQtYPWFzcDEx={}
  try:
   kdVapybKnRfLuAgvosjQtYPWFzcDEx.update(kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetDefaultParams())
   kdVapybKnRfLuAgvosjQtYPWFzcDOx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.callRequestCookies('Get',kdVapybKnRfLuAgvosjQtYPWFzcDOe,payload=kdVapybKnRfLuAgvosjQtYPWFzcDBG,params=kdVapybKnRfLuAgvosjQtYPWFzcDEx,headers=kdVapybKnRfLuAgvosjQtYPWFzcDBG,cookies=kdVapybKnRfLuAgvosjQtYPWFzcDBG)
   kdVapybKnRfLuAgvosjQtYPWFzcDOm=json.loads(kdVapybKnRfLuAgvosjQtYPWFzcDOx.text)
   if not('multisectionlist' in kdVapybKnRfLuAgvosjQtYPWFzcDOm):return[]
   kdVapybKnRfLuAgvosjQtYPWFzcDlO=kdVapybKnRfLuAgvosjQtYPWFzcDOm['multisectionlist']
   for kdVapybKnRfLuAgvosjQtYPWFzcDlh in kdVapybKnRfLuAgvosjQtYPWFzcDlO:
    kdVapybKnRfLuAgvosjQtYPWFzcDlI=kdVapybKnRfLuAgvosjQtYPWFzcDlh['title']
    if kdVapybKnRfLuAgvosjQtYPWFzcDqN(kdVapybKnRfLuAgvosjQtYPWFzcDlI)==0:continue
    if kdVapybKnRfLuAgvosjQtYPWFzcDlI=='minor':continue
    if re.search(u'베너',kdVapybKnRfLuAgvosjQtYPWFzcDlI):continue
    if re.search(u'배너',kdVapybKnRfLuAgvosjQtYPWFzcDlI):continue 
    if kdVapybKnRfLuAgvosjQtYPWFzcDlh['force_refresh']=='y':continue
    if kdVapybKnRfLuAgvosjQtYPWFzcDqN(kdVapybKnRfLuAgvosjQtYPWFzcDlh['eventlist'])>=3:
     kdVapybKnRfLuAgvosjQtYPWFzcDlq =kdVapybKnRfLuAgvosjQtYPWFzcDlh['eventlist'][2]['url']
    else:
     kdVapybKnRfLuAgvosjQtYPWFzcDlq =kdVapybKnRfLuAgvosjQtYPWFzcDlh['eventlist'][1]['url']
    kdVapybKnRfLuAgvosjQtYPWFzcDlw=kdVapybKnRfLuAgvosjQtYPWFzcDlh['cell_type']
    if kdVapybKnRfLuAgvosjQtYPWFzcDlw=='band_2':
     if kdVapybKnRfLuAgvosjQtYPWFzcDlq.find('channellist=')>=0:
      kdVapybKnRfLuAgvosjQtYPWFzcDlw='band_live'
    kdVapybKnRfLuAgvosjQtYPWFzcDlC={'title':kdVapybKnRfLuAgvosjQtYPWFzcDEN.Get_ChangeText(kdVapybKnRfLuAgvosjQtYPWFzcDlI),'subapi':kdVapybKnRfLuAgvosjQtYPWFzcDlq,'cell_type':kdVapybKnRfLuAgvosjQtYPWFzcDlw}
    kdVapybKnRfLuAgvosjQtYPWFzcDOM.append(kdVapybKnRfLuAgvosjQtYPWFzcDlC)
  except kdVapybKnRfLuAgvosjQtYPWFzcDqB as exception:
   kdVapybKnRfLuAgvosjQtYPWFzcDBM(exception)
   return[]
  return kdVapybKnRfLuAgvosjQtYPWFzcDOM
 def Get_BandLiveSection_List(kdVapybKnRfLuAgvosjQtYPWFzcDEN,kdVapybKnRfLuAgvosjQtYPWFzcDlE,page_int=1):
  kdVapybKnRfLuAgvosjQtYPWFzcDlX=[]
  kdVapybKnRfLuAgvosjQtYPWFzcDlJ=kdVapybKnRfLuAgvosjQtYPWFzcDlr=1
  kdVapybKnRfLuAgvosjQtYPWFzcDle=kdVapybKnRfLuAgvosjQtYPWFzcDqO
  try:
   (kdVapybKnRfLuAgvosjQtYPWFzcDOe,kdVapybKnRfLuAgvosjQtYPWFzcDEx)=kdVapybKnRfLuAgvosjQtYPWFzcDEN.Baseapi_Parse(kdVapybKnRfLuAgvosjQtYPWFzcDlE)
  except kdVapybKnRfLuAgvosjQtYPWFzcDqB as exception:
   kdVapybKnRfLuAgvosjQtYPWFzcDBM(exception)
   return[],kdVapybKnRfLuAgvosjQtYPWFzcDqO
  try:
   kdVapybKnRfLuAgvosjQtYPWFzcDEx['limit']=kdVapybKnRfLuAgvosjQtYPWFzcDEN.LIST_LIMIT
   kdVapybKnRfLuAgvosjQtYPWFzcDEx['offset']=kdVapybKnRfLuAgvosjQtYPWFzcDqE((page_int-1)*kdVapybKnRfLuAgvosjQtYPWFzcDEN.LIST_LIMIT)
   kdVapybKnRfLuAgvosjQtYPWFzcDEx.update(kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetDefaultParams())
   kdVapybKnRfLuAgvosjQtYPWFzcDOx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.callRequestCookies('Get',kdVapybKnRfLuAgvosjQtYPWFzcDOe,payload=kdVapybKnRfLuAgvosjQtYPWFzcDBG,params=kdVapybKnRfLuAgvosjQtYPWFzcDEx,headers=kdVapybKnRfLuAgvosjQtYPWFzcDBG,cookies=kdVapybKnRfLuAgvosjQtYPWFzcDBG)
   kdVapybKnRfLuAgvosjQtYPWFzcDOm=json.loads(kdVapybKnRfLuAgvosjQtYPWFzcDOx.text)
   if not('celllist' in kdVapybKnRfLuAgvosjQtYPWFzcDOm['cell_toplist']):return[],kdVapybKnRfLuAgvosjQtYPWFzcDqO
   kdVapybKnRfLuAgvosjQtYPWFzcDlO=kdVapybKnRfLuAgvosjQtYPWFzcDOm['cell_toplist']['celllist']
   for kdVapybKnRfLuAgvosjQtYPWFzcDlh in kdVapybKnRfLuAgvosjQtYPWFzcDlO:
    kdVapybKnRfLuAgvosjQtYPWFzcDlU =kdVapybKnRfLuAgvosjQtYPWFzcDlh['event_list'][1]['url']
    kdVapybKnRfLuAgvosjQtYPWFzcDlx=urllib.parse.urlsplit(kdVapybKnRfLuAgvosjQtYPWFzcDlU).query
    kdVapybKnRfLuAgvosjQtYPWFzcDlx=kdVapybKnRfLuAgvosjQtYPWFzcDqI(urllib.parse.parse_qsl(kdVapybKnRfLuAgvosjQtYPWFzcDlx))
    kdVapybKnRfLuAgvosjQtYPWFzcDlm='channelid'
    kdVapybKnRfLuAgvosjQtYPWFzcDli=kdVapybKnRfLuAgvosjQtYPWFzcDlx[kdVapybKnRfLuAgvosjQtYPWFzcDlm]
    kdVapybKnRfLuAgvosjQtYPWFzcDlC={'studio':kdVapybKnRfLuAgvosjQtYPWFzcDlh['title_list'][0]['text'],'tvshowtitle':kdVapybKnRfLuAgvosjQtYPWFzcDEN.Get_ChangeText(kdVapybKnRfLuAgvosjQtYPWFzcDlh['title_list'][1]['text']),'channelid':kdVapybKnRfLuAgvosjQtYPWFzcDli,'age':kdVapybKnRfLuAgvosjQtYPWFzcDlh.get('age'),'thumbnail':'https://%s'%kdVapybKnRfLuAgvosjQtYPWFzcDlh.get('thumbnail')}
    kdVapybKnRfLuAgvosjQtYPWFzcDlX.append(kdVapybKnRfLuAgvosjQtYPWFzcDlC)
   kdVapybKnRfLuAgvosjQtYPWFzcDlJ=kdVapybKnRfLuAgvosjQtYPWFzcDqw(kdVapybKnRfLuAgvosjQtYPWFzcDOm['cell_toplist']['pagecount'])
   if kdVapybKnRfLuAgvosjQtYPWFzcDOm['cell_toplist']['count']:kdVapybKnRfLuAgvosjQtYPWFzcDlr =kdVapybKnRfLuAgvosjQtYPWFzcDqw(kdVapybKnRfLuAgvosjQtYPWFzcDOm['cell_toplist']['count'])
   else:kdVapybKnRfLuAgvosjQtYPWFzcDlr=kdVapybKnRfLuAgvosjQtYPWFzcDEN.LIST_LIMIT*page_int
   kdVapybKnRfLuAgvosjQtYPWFzcDle=kdVapybKnRfLuAgvosjQtYPWFzcDlJ>kdVapybKnRfLuAgvosjQtYPWFzcDlr
  except kdVapybKnRfLuAgvosjQtYPWFzcDqB as exception:
   kdVapybKnRfLuAgvosjQtYPWFzcDBM(exception)
   return[],kdVapybKnRfLuAgvosjQtYPWFzcDqO
  return kdVapybKnRfLuAgvosjQtYPWFzcDlX,kdVapybKnRfLuAgvosjQtYPWFzcDle
 def Get_Band2Section_List(kdVapybKnRfLuAgvosjQtYPWFzcDEN,kdVapybKnRfLuAgvosjQtYPWFzcDlE,page_int=1):
  kdVapybKnRfLuAgvosjQtYPWFzcDlT=[]
  kdVapybKnRfLuAgvosjQtYPWFzcDlJ=kdVapybKnRfLuAgvosjQtYPWFzcDlr=1
  kdVapybKnRfLuAgvosjQtYPWFzcDle=kdVapybKnRfLuAgvosjQtYPWFzcDqO
  try:
   (kdVapybKnRfLuAgvosjQtYPWFzcDOe,kdVapybKnRfLuAgvosjQtYPWFzcDEx)=kdVapybKnRfLuAgvosjQtYPWFzcDEN.Baseapi_Parse(kdVapybKnRfLuAgvosjQtYPWFzcDlE)
  except kdVapybKnRfLuAgvosjQtYPWFzcDqB as exception:
   kdVapybKnRfLuAgvosjQtYPWFzcDBM(exception)
   return[],kdVapybKnRfLuAgvosjQtYPWFzcDqO
  try:
   kdVapybKnRfLuAgvosjQtYPWFzcDEx['came'] ='BandView'
   kdVapybKnRfLuAgvosjQtYPWFzcDEx['limit']=kdVapybKnRfLuAgvosjQtYPWFzcDEN.LIST_LIMIT
   kdVapybKnRfLuAgvosjQtYPWFzcDEx['offset']=kdVapybKnRfLuAgvosjQtYPWFzcDqE((page_int-1)*kdVapybKnRfLuAgvosjQtYPWFzcDEN.LIST_LIMIT)
   kdVapybKnRfLuAgvosjQtYPWFzcDEx.update(kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetDefaultParams())
   kdVapybKnRfLuAgvosjQtYPWFzcDOx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.callRequestCookies('Get',kdVapybKnRfLuAgvosjQtYPWFzcDOe,payload=kdVapybKnRfLuAgvosjQtYPWFzcDBG,params=kdVapybKnRfLuAgvosjQtYPWFzcDEx,headers=kdVapybKnRfLuAgvosjQtYPWFzcDBG,cookies=kdVapybKnRfLuAgvosjQtYPWFzcDBG)
   kdVapybKnRfLuAgvosjQtYPWFzcDOm=json.loads(kdVapybKnRfLuAgvosjQtYPWFzcDOx.text)
   if not('celllist' in kdVapybKnRfLuAgvosjQtYPWFzcDOm['cell_toplist']):return[],kdVapybKnRfLuAgvosjQtYPWFzcDqO
   kdVapybKnRfLuAgvosjQtYPWFzcDlO=kdVapybKnRfLuAgvosjQtYPWFzcDOm['cell_toplist']['celllist']
   for kdVapybKnRfLuAgvosjQtYPWFzcDlh in kdVapybKnRfLuAgvosjQtYPWFzcDlO:
    kdVapybKnRfLuAgvosjQtYPWFzcDlU =kdVapybKnRfLuAgvosjQtYPWFzcDlh['event_list'][1]['url']
    kdVapybKnRfLuAgvosjQtYPWFzcDlx=urllib.parse.urlsplit(kdVapybKnRfLuAgvosjQtYPWFzcDlU).query
    kdVapybKnRfLuAgvosjQtYPWFzcDlx=kdVapybKnRfLuAgvosjQtYPWFzcDqI(urllib.parse.parse_qsl(kdVapybKnRfLuAgvosjQtYPWFzcDlx))
    kdVapybKnRfLuAgvosjQtYPWFzcDlm='contentid'
    kdVapybKnRfLuAgvosjQtYPWFzcDli=kdVapybKnRfLuAgvosjQtYPWFzcDlx[kdVapybKnRfLuAgvosjQtYPWFzcDlm]
    kdVapybKnRfLuAgvosjQtYPWFzcDlC={'programtitle':kdVapybKnRfLuAgvosjQtYPWFzcDlh['title_list'][0]['text'],'episodetitle':kdVapybKnRfLuAgvosjQtYPWFzcDEN.Get_ChangeText(kdVapybKnRfLuAgvosjQtYPWFzcDlh['title_list'][1]['text']),'age':kdVapybKnRfLuAgvosjQtYPWFzcDlh.get('age'),'thumbnail':kdVapybKnRfLuAgvosjQtYPWFzcDEN.HTTPTAG+kdVapybKnRfLuAgvosjQtYPWFzcDlh.get('thumbnail'),'vidtype':kdVapybKnRfLuAgvosjQtYPWFzcDlm,'videoid':kdVapybKnRfLuAgvosjQtYPWFzcDli}
    kdVapybKnRfLuAgvosjQtYPWFzcDlT.append(kdVapybKnRfLuAgvosjQtYPWFzcDlC)
   kdVapybKnRfLuAgvosjQtYPWFzcDlJ=kdVapybKnRfLuAgvosjQtYPWFzcDqw(kdVapybKnRfLuAgvosjQtYPWFzcDOm['cell_toplist']['pagecount'])
   if kdVapybKnRfLuAgvosjQtYPWFzcDOm['cell_toplist']['count']:kdVapybKnRfLuAgvosjQtYPWFzcDlr =kdVapybKnRfLuAgvosjQtYPWFzcDqw(kdVapybKnRfLuAgvosjQtYPWFzcDOm['cell_toplist']['count'])
   else:kdVapybKnRfLuAgvosjQtYPWFzcDlr=kdVapybKnRfLuAgvosjQtYPWFzcDEN.LIST_LIMIT*page_int
   kdVapybKnRfLuAgvosjQtYPWFzcDle=kdVapybKnRfLuAgvosjQtYPWFzcDlJ>kdVapybKnRfLuAgvosjQtYPWFzcDlr
  except kdVapybKnRfLuAgvosjQtYPWFzcDqB as exception:
   kdVapybKnRfLuAgvosjQtYPWFzcDBM(exception)
   return[],kdVapybKnRfLuAgvosjQtYPWFzcDqO
  return kdVapybKnRfLuAgvosjQtYPWFzcDlT,kdVapybKnRfLuAgvosjQtYPWFzcDle
 def Get_Program_List(kdVapybKnRfLuAgvosjQtYPWFzcDEN,kdVapybKnRfLuAgvosjQtYPWFzcDlE,page_int=1,orderby='-'):
  kdVapybKnRfLuAgvosjQtYPWFzcDlS=[]
  kdVapybKnRfLuAgvosjQtYPWFzcDle=kdVapybKnRfLuAgvosjQtYPWFzcDqO
  (kdVapybKnRfLuAgvosjQtYPWFzcDOe,kdVapybKnRfLuAgvosjQtYPWFzcDEx)=kdVapybKnRfLuAgvosjQtYPWFzcDEN.Baseapi_Parse(kdVapybKnRfLuAgvosjQtYPWFzcDlE)
  if kdVapybKnRfLuAgvosjQtYPWFzcDOe=='':return kdVapybKnRfLuAgvosjQtYPWFzcDlS,kdVapybKnRfLuAgvosjQtYPWFzcDle
  try:
   kdVapybKnRfLuAgvosjQtYPWFzcDEx['limit'] =kdVapybKnRfLuAgvosjQtYPWFzcDEN.LIST_LIMIT
   kdVapybKnRfLuAgvosjQtYPWFzcDEx['offset']=kdVapybKnRfLuAgvosjQtYPWFzcDqE((page_int-1)*kdVapybKnRfLuAgvosjQtYPWFzcDEN.LIST_LIMIT)
   if orderby not in['-','',kdVapybKnRfLuAgvosjQtYPWFzcDBG]:
    kdVapybKnRfLuAgvosjQtYPWFzcDEx['orderby']=orderby 
   kdVapybKnRfLuAgvosjQtYPWFzcDEx.update(kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetDefaultParams())
   kdVapybKnRfLuAgvosjQtYPWFzcDOx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.callRequestCookies('Get',kdVapybKnRfLuAgvosjQtYPWFzcDOe,payload=kdVapybKnRfLuAgvosjQtYPWFzcDBG,params=kdVapybKnRfLuAgvosjQtYPWFzcDEx,headers=kdVapybKnRfLuAgvosjQtYPWFzcDBG,cookies=kdVapybKnRfLuAgvosjQtYPWFzcDBG)
   kdVapybKnRfLuAgvosjQtYPWFzcDOm=json.loads(kdVapybKnRfLuAgvosjQtYPWFzcDOx.text)
   kdVapybKnRfLuAgvosjQtYPWFzcDlO=kdVapybKnRfLuAgvosjQtYPWFzcDOm['data']['context_list']
   for kdVapybKnRfLuAgvosjQtYPWFzcDlh in kdVapybKnRfLuAgvosjQtYPWFzcDlO:
    kdVapybKnRfLuAgvosjQtYPWFzcDlC={'title':kdVapybKnRfLuAgvosjQtYPWFzcDlh['program']['title'],'thumbnail':kdVapybKnRfLuAgvosjQtYPWFzcDlh['program']['vertical_logo_y_image'],'videoid':kdVapybKnRfLuAgvosjQtYPWFzcDlh['context_id'],'vidtype':'contentid',}
    kdVapybKnRfLuAgvosjQtYPWFzcDlS.append(kdVapybKnRfLuAgvosjQtYPWFzcDlC)
   if kdVapybKnRfLuAgvosjQtYPWFzcDqw(kdVapybKnRfLuAgvosjQtYPWFzcDOm['data']['pagecount'])>page_int:
    kdVapybKnRfLuAgvosjQtYPWFzcDle=kdVapybKnRfLuAgvosjQtYPWFzcDqh
  except kdVapybKnRfLuAgvosjQtYPWFzcDqB as exception:
   kdVapybKnRfLuAgvosjQtYPWFzcDBM(exception)
   addon_log('error : {}'.format(exception))
   return[],kdVapybKnRfLuAgvosjQtYPWFzcDqO
  return kdVapybKnRfLuAgvosjQtYPWFzcDlS,kdVapybKnRfLuAgvosjQtYPWFzcDle
 def Get_Program_List_old(kdVapybKnRfLuAgvosjQtYPWFzcDEN,kdVapybKnRfLuAgvosjQtYPWFzcDlE,page_int=1,orderby='-'):
  kdVapybKnRfLuAgvosjQtYPWFzcDlS=[]
  kdVapybKnRfLuAgvosjQtYPWFzcDlJ=kdVapybKnRfLuAgvosjQtYPWFzcDlr=1
  kdVapybKnRfLuAgvosjQtYPWFzcDle=kdVapybKnRfLuAgvosjQtYPWFzcDqO
  (kdVapybKnRfLuAgvosjQtYPWFzcDOe,kdVapybKnRfLuAgvosjQtYPWFzcDEx)=kdVapybKnRfLuAgvosjQtYPWFzcDEN.Baseapi_Parse(kdVapybKnRfLuAgvosjQtYPWFzcDlE)
  if kdVapybKnRfLuAgvosjQtYPWFzcDOe=='':return kdVapybKnRfLuAgvosjQtYPWFzcDlS,kdVapybKnRfLuAgvosjQtYPWFzcDle
  try:
   kdVapybKnRfLuAgvosjQtYPWFzcDEx['limit'] =kdVapybKnRfLuAgvosjQtYPWFzcDEN.LIST_LIMIT
   kdVapybKnRfLuAgvosjQtYPWFzcDEx['offset']=kdVapybKnRfLuAgvosjQtYPWFzcDqE((page_int-1)*kdVapybKnRfLuAgvosjQtYPWFzcDEN.LIST_LIMIT)
   kdVapybKnRfLuAgvosjQtYPWFzcDEx['page'] =kdVapybKnRfLuAgvosjQtYPWFzcDqE(page_int)
   if kdVapybKnRfLuAgvosjQtYPWFzcDEx.get('orderby')!='' and kdVapybKnRfLuAgvosjQtYPWFzcDEx.get('orderby')!='regdatefirst' and orderby!='-':
    kdVapybKnRfLuAgvosjQtYPWFzcDEx['orderby']=orderby 
   kdVapybKnRfLuAgvosjQtYPWFzcDEx.update(kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetDefaultParams())
   kdVapybKnRfLuAgvosjQtYPWFzcDOx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.callRequestCookies('Get',kdVapybKnRfLuAgvosjQtYPWFzcDOe,payload=kdVapybKnRfLuAgvosjQtYPWFzcDBG,params=kdVapybKnRfLuAgvosjQtYPWFzcDEx,headers=kdVapybKnRfLuAgvosjQtYPWFzcDBG,cookies=kdVapybKnRfLuAgvosjQtYPWFzcDBG)
   kdVapybKnRfLuAgvosjQtYPWFzcDOm=json.loads(kdVapybKnRfLuAgvosjQtYPWFzcDOx.text)
   if kdVapybKnRfLuAgvosjQtYPWFzcDOm.get('cell_toplist')not in[{},kdVapybKnRfLuAgvosjQtYPWFzcDBG,'']:
    kdVapybKnRfLuAgvosjQtYPWFzcDlO=kdVapybKnRfLuAgvosjQtYPWFzcDOm['cell_toplist']['celllist']
   elif kdVapybKnRfLuAgvosjQtYPWFzcDOm.get('band')not in[{},kdVapybKnRfLuAgvosjQtYPWFzcDBG,'']:
    kdVapybKnRfLuAgvosjQtYPWFzcDlO=kdVapybKnRfLuAgvosjQtYPWFzcDOm['band']['celllist']
   else:
    return kdVapybKnRfLuAgvosjQtYPWFzcDlS,kdVapybKnRfLuAgvosjQtYPWFzcDle
   for kdVapybKnRfLuAgvosjQtYPWFzcDlh in kdVapybKnRfLuAgvosjQtYPWFzcDlO:
    for kdVapybKnRfLuAgvosjQtYPWFzcDlG in kdVapybKnRfLuAgvosjQtYPWFzcDlh['event_list']:
     if kdVapybKnRfLuAgvosjQtYPWFzcDlG.get('type')=='on-navigation':
      kdVapybKnRfLuAgvosjQtYPWFzcDlU =kdVapybKnRfLuAgvosjQtYPWFzcDlG['url']
    kdVapybKnRfLuAgvosjQtYPWFzcDlx=urllib.parse.urlsplit(kdVapybKnRfLuAgvosjQtYPWFzcDlU).query
    kdVapybKnRfLuAgvosjQtYPWFzcDlm=kdVapybKnRfLuAgvosjQtYPWFzcDlx[0:kdVapybKnRfLuAgvosjQtYPWFzcDlx.find('=')]
    kdVapybKnRfLuAgvosjQtYPWFzcDlH=kdVapybKnRfLuAgvosjQtYPWFzcDqI(urllib.parse.parse_qsl(kdVapybKnRfLuAgvosjQtYPWFzcDlx))
    kdVapybKnRfLuAgvosjQtYPWFzcDli=kdVapybKnRfLuAgvosjQtYPWFzcDlH.get(kdVapybKnRfLuAgvosjQtYPWFzcDlm)
    kdVapybKnRfLuAgvosjQtYPWFzcDlC={'title':kdVapybKnRfLuAgvosjQtYPWFzcDlh.get('alt')or kdVapybKnRfLuAgvosjQtYPWFzcDlh.get('title_list')[0].get('text'),'age':kdVapybKnRfLuAgvosjQtYPWFzcDlh.get('age'),'thumbnail':kdVapybKnRfLuAgvosjQtYPWFzcDlh.get('thumbnail'),'videoid':kdVapybKnRfLuAgvosjQtYPWFzcDli,'vidtype':kdVapybKnRfLuAgvosjQtYPWFzcDlm,}
    if not kdVapybKnRfLuAgvosjQtYPWFzcDlC.get('thumbnail').startswith('http'):
     kdVapybKnRfLuAgvosjQtYPWFzcDlC['thumbnail']='https://%s'%kdVapybKnRfLuAgvosjQtYPWFzcDlC['thumbnail']
    kdVapybKnRfLuAgvosjQtYPWFzcDlS.append(kdVapybKnRfLuAgvosjQtYPWFzcDlC)
   if kdVapybKnRfLuAgvosjQtYPWFzcDOm.get('cell_toplist')not in[{},kdVapybKnRfLuAgvosjQtYPWFzcDBG,'']:
    kdVapybKnRfLuAgvosjQtYPWFzcDlJ=kdVapybKnRfLuAgvosjQtYPWFzcDqw(kdVapybKnRfLuAgvosjQtYPWFzcDOm['cell_toplist']['pagecount'])
    if kdVapybKnRfLuAgvosjQtYPWFzcDOm['cell_toplist']['count']:kdVapybKnRfLuAgvosjQtYPWFzcDlr =kdVapybKnRfLuAgvosjQtYPWFzcDqw(kdVapybKnRfLuAgvosjQtYPWFzcDOm['cell_toplist']['count'])
    else:kdVapybKnRfLuAgvosjQtYPWFzcDlr=kdVapybKnRfLuAgvosjQtYPWFzcDEN.LIST_LIMIT*page_int
    kdVapybKnRfLuAgvosjQtYPWFzcDle=kdVapybKnRfLuAgvosjQtYPWFzcDlJ>kdVapybKnRfLuAgvosjQtYPWFzcDlr
  except kdVapybKnRfLuAgvosjQtYPWFzcDqB as exception:
   kdVapybKnRfLuAgvosjQtYPWFzcDBM(exception)
   return[],kdVapybKnRfLuAgvosjQtYPWFzcDqO
  return kdVapybKnRfLuAgvosjQtYPWFzcDlS,kdVapybKnRfLuAgvosjQtYPWFzcDle
 def Get_Movie_List(kdVapybKnRfLuAgvosjQtYPWFzcDEN,kdVapybKnRfLuAgvosjQtYPWFzcDlE,page_int=1,orderby='-'):
  kdVapybKnRfLuAgvosjQtYPWFzcDlM=[]
  kdVapybKnRfLuAgvosjQtYPWFzcDlJ=kdVapybKnRfLuAgvosjQtYPWFzcDlr=1
  kdVapybKnRfLuAgvosjQtYPWFzcDle=kdVapybKnRfLuAgvosjQtYPWFzcDqO
  (kdVapybKnRfLuAgvosjQtYPWFzcDOe,kdVapybKnRfLuAgvosjQtYPWFzcDEx)=kdVapybKnRfLuAgvosjQtYPWFzcDEN.Baseapi_Parse(kdVapybKnRfLuAgvosjQtYPWFzcDlE)
  if kdVapybKnRfLuAgvosjQtYPWFzcDOe=='':return kdVapybKnRfLuAgvosjQtYPWFzcDlM,kdVapybKnRfLuAgvosjQtYPWFzcDle
  try:
   kdVapybKnRfLuAgvosjQtYPWFzcDEx['limit']=kdVapybKnRfLuAgvosjQtYPWFzcDEN.MV_LIMIT
   kdVapybKnRfLuAgvosjQtYPWFzcDEx['offset']=kdVapybKnRfLuAgvosjQtYPWFzcDqE((page_int-1)*kdVapybKnRfLuAgvosjQtYPWFzcDEN.MV_LIMIT)
   if kdVapybKnRfLuAgvosjQtYPWFzcDEx.get('orderby')!='' and kdVapybKnRfLuAgvosjQtYPWFzcDEx.get('orderby')!='regdatefirst' and orderby!='-':
    kdVapybKnRfLuAgvosjQtYPWFzcDEx['orderby']=orderby 
   kdVapybKnRfLuAgvosjQtYPWFzcDEx.update(kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetDefaultParams())
   kdVapybKnRfLuAgvosjQtYPWFzcDOx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.callRequestCookies('Get',kdVapybKnRfLuAgvosjQtYPWFzcDOe,payload=kdVapybKnRfLuAgvosjQtYPWFzcDBG,params=kdVapybKnRfLuAgvosjQtYPWFzcDEx,headers=kdVapybKnRfLuAgvosjQtYPWFzcDBG,cookies=kdVapybKnRfLuAgvosjQtYPWFzcDBG)
   kdVapybKnRfLuAgvosjQtYPWFzcDOm=json.loads(kdVapybKnRfLuAgvosjQtYPWFzcDOx.text)
   if kdVapybKnRfLuAgvosjQtYPWFzcDOm.get('cell_toplist')not in[{},kdVapybKnRfLuAgvosjQtYPWFzcDBG,'']:
    kdVapybKnRfLuAgvosjQtYPWFzcDlO=kdVapybKnRfLuAgvosjQtYPWFzcDOm['cell_toplist']['celllist']
   elif kdVapybKnRfLuAgvosjQtYPWFzcDOm.get('band')not in[{},kdVapybKnRfLuAgvosjQtYPWFzcDBG,'']:
    kdVapybKnRfLuAgvosjQtYPWFzcDlO=kdVapybKnRfLuAgvosjQtYPWFzcDOm['band']['celllist']
   else:
    return kdVapybKnRfLuAgvosjQtYPWFzcDlM,kdVapybKnRfLuAgvosjQtYPWFzcDle
   for kdVapybKnRfLuAgvosjQtYPWFzcDlh in kdVapybKnRfLuAgvosjQtYPWFzcDlO:
    kdVapybKnRfLuAgvosjQtYPWFzcDlU =kdVapybKnRfLuAgvosjQtYPWFzcDlh['event_list'][1]['url']
    kdVapybKnRfLuAgvosjQtYPWFzcDlx=urllib.parse.urlsplit(kdVapybKnRfLuAgvosjQtYPWFzcDlU).query
    kdVapybKnRfLuAgvosjQtYPWFzcDlm=kdVapybKnRfLuAgvosjQtYPWFzcDlx[0:kdVapybKnRfLuAgvosjQtYPWFzcDlx.find('=')]
    kdVapybKnRfLuAgvosjQtYPWFzcDlH=kdVapybKnRfLuAgvosjQtYPWFzcDqI(urllib.parse.parse_qsl(kdVapybKnRfLuAgvosjQtYPWFzcDlx))
    kdVapybKnRfLuAgvosjQtYPWFzcDli=kdVapybKnRfLuAgvosjQtYPWFzcDlH.get(kdVapybKnRfLuAgvosjQtYPWFzcDlm)
    kdVapybKnRfLuAgvosjQtYPWFzcDlC={'title':kdVapybKnRfLuAgvosjQtYPWFzcDlh.get('alt')or kdVapybKnRfLuAgvosjQtYPWFzcDlh.get('title_list')[0].get('text'),'age':kdVapybKnRfLuAgvosjQtYPWFzcDlh.get('age'),'thumbnail':kdVapybKnRfLuAgvosjQtYPWFzcDlh.get('thumbnail'),'videoid':kdVapybKnRfLuAgvosjQtYPWFzcDli,'vidtype':kdVapybKnRfLuAgvosjQtYPWFzcDlm,}
    if not kdVapybKnRfLuAgvosjQtYPWFzcDlC.get('thumbnail').startswith('http'):
     kdVapybKnRfLuAgvosjQtYPWFzcDlC['thumbnail']='https://%s'%kdVapybKnRfLuAgvosjQtYPWFzcDlC['thumbnail']
    kdVapybKnRfLuAgvosjQtYPWFzcDlM.append(kdVapybKnRfLuAgvosjQtYPWFzcDlC)
   if kdVapybKnRfLuAgvosjQtYPWFzcDOm.get('cell_toplist')not in[{},kdVapybKnRfLuAgvosjQtYPWFzcDBG,'']:
    kdVapybKnRfLuAgvosjQtYPWFzcDlJ=kdVapybKnRfLuAgvosjQtYPWFzcDqw(kdVapybKnRfLuAgvosjQtYPWFzcDOm['cell_toplist']['pagecount'])
    if kdVapybKnRfLuAgvosjQtYPWFzcDOm['cell_toplist']['count']:kdVapybKnRfLuAgvosjQtYPWFzcDlr =kdVapybKnRfLuAgvosjQtYPWFzcDqw(kdVapybKnRfLuAgvosjQtYPWFzcDOm['cell_toplist']['count'])
    else:kdVapybKnRfLuAgvosjQtYPWFzcDlr=kdVapybKnRfLuAgvosjQtYPWFzcDEN.MV_LIMIT*page_int
    kdVapybKnRfLuAgvosjQtYPWFzcDle=kdVapybKnRfLuAgvosjQtYPWFzcDlJ>kdVapybKnRfLuAgvosjQtYPWFzcDlr
  except kdVapybKnRfLuAgvosjQtYPWFzcDqB as exception:
   kdVapybKnRfLuAgvosjQtYPWFzcDBM(exception)
   return[],kdVapybKnRfLuAgvosjQtYPWFzcDqO
  return kdVapybKnRfLuAgvosjQtYPWFzcDlM,kdVapybKnRfLuAgvosjQtYPWFzcDle
 def ProgramidToContentid(kdVapybKnRfLuAgvosjQtYPWFzcDEN,kdVapybKnRfLuAgvosjQtYPWFzcDhl):
  kdVapybKnRfLuAgvosjQtYPWFzcDhE=''
  try:
   kdVapybKnRfLuAgvosjQtYPWFzcDOe =kdVapybKnRfLuAgvosjQtYPWFzcDEN.API_DOMAIN+'/vod/programs-contentid/'+kdVapybKnRfLuAgvosjQtYPWFzcDhl
   kdVapybKnRfLuAgvosjQtYPWFzcDEx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetDefaultParams()
   kdVapybKnRfLuAgvosjQtYPWFzcDOx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.callRequestCookies('Get',kdVapybKnRfLuAgvosjQtYPWFzcDOe,payload=kdVapybKnRfLuAgvosjQtYPWFzcDBG,params=kdVapybKnRfLuAgvosjQtYPWFzcDEx,headers=kdVapybKnRfLuAgvosjQtYPWFzcDBG,cookies=kdVapybKnRfLuAgvosjQtYPWFzcDBG)
   kdVapybKnRfLuAgvosjQtYPWFzcDhO=json.loads(kdVapybKnRfLuAgvosjQtYPWFzcDOx.text)
   if not('contentid' in kdVapybKnRfLuAgvosjQtYPWFzcDhO):return kdVapybKnRfLuAgvosjQtYPWFzcDhE 
   kdVapybKnRfLuAgvosjQtYPWFzcDhE=kdVapybKnRfLuAgvosjQtYPWFzcDhO['contentid']
  except kdVapybKnRfLuAgvosjQtYPWFzcDqB as exception:
   kdVapybKnRfLuAgvosjQtYPWFzcDBM(exception)
  return kdVapybKnRfLuAgvosjQtYPWFzcDhE
 def ContentidToSeasonid(kdVapybKnRfLuAgvosjQtYPWFzcDEN,kdVapybKnRfLuAgvosjQtYPWFzcDhE):
  kdVapybKnRfLuAgvosjQtYPWFzcDhl=''
  try:
   kdVapybKnRfLuAgvosjQtYPWFzcDOe =kdVapybKnRfLuAgvosjQtYPWFzcDEN.API_DOMAIN+'/fz/vod/contents/'+kdVapybKnRfLuAgvosjQtYPWFzcDhE
   kdVapybKnRfLuAgvosjQtYPWFzcDEx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetDefaultParams()
   kdVapybKnRfLuAgvosjQtYPWFzcDOx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.callRequestCookies('Get',kdVapybKnRfLuAgvosjQtYPWFzcDOe,payload=kdVapybKnRfLuAgvosjQtYPWFzcDBG,params=kdVapybKnRfLuAgvosjQtYPWFzcDEx,headers=kdVapybKnRfLuAgvosjQtYPWFzcDBG,cookies=kdVapybKnRfLuAgvosjQtYPWFzcDBG)
   kdVapybKnRfLuAgvosjQtYPWFzcDhO=json.loads(kdVapybKnRfLuAgvosjQtYPWFzcDOx.text)
   if not('programid' in kdVapybKnRfLuAgvosjQtYPWFzcDhO):return kdVapybKnRfLuAgvosjQtYPWFzcDhl 
   kdVapybKnRfLuAgvosjQtYPWFzcDhl=kdVapybKnRfLuAgvosjQtYPWFzcDhO['programid']
  except kdVapybKnRfLuAgvosjQtYPWFzcDqB as exception:
   kdVapybKnRfLuAgvosjQtYPWFzcDBM(exception)
  return kdVapybKnRfLuAgvosjQtYPWFzcDhl
 def GetProgramInfo(kdVapybKnRfLuAgvosjQtYPWFzcDEN,kdVapybKnRfLuAgvosjQtYPWFzcDhE):
  kdVapybKnRfLuAgvosjQtYPWFzcDhC={}
  try:
   kdVapybKnRfLuAgvosjQtYPWFzcDOe=kdVapybKnRfLuAgvosjQtYPWFzcDEN.API_DOMAIN+'/fz/vod/contents/'+kdVapybKnRfLuAgvosjQtYPWFzcDhE
   kdVapybKnRfLuAgvosjQtYPWFzcDEx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetDefaultParams()
   kdVapybKnRfLuAgvosjQtYPWFzcDOx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.callRequestCookies('Get',kdVapybKnRfLuAgvosjQtYPWFzcDOe,payload=kdVapybKnRfLuAgvosjQtYPWFzcDBG,params=kdVapybKnRfLuAgvosjQtYPWFzcDEx,headers=kdVapybKnRfLuAgvosjQtYPWFzcDBG,cookies=kdVapybKnRfLuAgvosjQtYPWFzcDBG)
   kdVapybKnRfLuAgvosjQtYPWFzcDhO=json.loads(kdVapybKnRfLuAgvosjQtYPWFzcDOx.text)
   kdVapybKnRfLuAgvosjQtYPWFzcDhN=img_fanart=kdVapybKnRfLuAgvosjQtYPWFzcDhB=''
   if kdVapybKnRfLuAgvosjQtYPWFzcDhO.get('programposterimage')!='':kdVapybKnRfLuAgvosjQtYPWFzcDhN =kdVapybKnRfLuAgvosjQtYPWFzcDEN.HTTPTAG+kdVapybKnRfLuAgvosjQtYPWFzcDhO.get('programposterimage')
   if kdVapybKnRfLuAgvosjQtYPWFzcDhO.get('programimage') !='':img_fanart =kdVapybKnRfLuAgvosjQtYPWFzcDEN.HTTPTAG+kdVapybKnRfLuAgvosjQtYPWFzcDhO.get('programimage')
   if kdVapybKnRfLuAgvosjQtYPWFzcDhO.get('programcircleimage')!='':kdVapybKnRfLuAgvosjQtYPWFzcDhB=kdVapybKnRfLuAgvosjQtYPWFzcDEN.HTTPTAG+kdVapybKnRfLuAgvosjQtYPWFzcDhO.get('programcircleimage')
   if 'poster_default' in kdVapybKnRfLuAgvosjQtYPWFzcDhN:
    kdVapybKnRfLuAgvosjQtYPWFzcDhN =img_fanart
    kdVapybKnRfLuAgvosjQtYPWFzcDhB=''
   kdVapybKnRfLuAgvosjQtYPWFzcDhC={'imgPoster':kdVapybKnRfLuAgvosjQtYPWFzcDhN,'imgFanart':img_fanart,'imgClearlogo':kdVapybKnRfLuAgvosjQtYPWFzcDhB,'programtitle':kdVapybKnRfLuAgvosjQtYPWFzcDEN.Get_ChangeText(kdVapybKnRfLuAgvosjQtYPWFzcDhO.get('programtitle')),'programid':kdVapybKnRfLuAgvosjQtYPWFzcDhO.get('programid'),'synopsis':kdVapybKnRfLuAgvosjQtYPWFzcDEN.Get_ChangeText(kdVapybKnRfLuAgvosjQtYPWFzcDhO.get('programsynopsis')),}
  except kdVapybKnRfLuAgvosjQtYPWFzcDqB as exception:
   kdVapybKnRfLuAgvosjQtYPWFzcDBM(exception)
  return kdVapybKnRfLuAgvosjQtYPWFzcDhC
 def Get_Season_List_old(kdVapybKnRfLuAgvosjQtYPWFzcDEN,seasonid):
  kdVapybKnRfLuAgvosjQtYPWFzcDhq=[]
  kdVapybKnRfLuAgvosjQtYPWFzcDhE=kdVapybKnRfLuAgvosjQtYPWFzcDEN.ProgramidToContentid(seasonid)
  kdVapybKnRfLuAgvosjQtYPWFzcDhI=kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetProgramInfo(kdVapybKnRfLuAgvosjQtYPWFzcDhE)
  kdVapybKnRfLuAgvosjQtYPWFzcDhw={'poster':kdVapybKnRfLuAgvosjQtYPWFzcDhI.get('imgPoster'),'fanart':kdVapybKnRfLuAgvosjQtYPWFzcDhI.get('imgFanart'),'clearlogo':kdVapybKnRfLuAgvosjQtYPWFzcDhI.get('imgClearlogo'),}
  try:
   kdVapybKnRfLuAgvosjQtYPWFzcDOe=kdVapybKnRfLuAgvosjQtYPWFzcDEN.API_DOMAIN+'/fz/vod/programs-contents/'+seasonid
   kdVapybKnRfLuAgvosjQtYPWFzcDEx={'limit':'10','offset':'0','orderby':'new',}
   kdVapybKnRfLuAgvosjQtYPWFzcDEx.update(kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetDefaultParams())
   kdVapybKnRfLuAgvosjQtYPWFzcDOx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.callRequestCookies('Get',kdVapybKnRfLuAgvosjQtYPWFzcDOe,payload=kdVapybKnRfLuAgvosjQtYPWFzcDBG,params=kdVapybKnRfLuAgvosjQtYPWFzcDEx,headers=kdVapybKnRfLuAgvosjQtYPWFzcDBG,cookies=kdVapybKnRfLuAgvosjQtYPWFzcDBG)
   kdVapybKnRfLuAgvosjQtYPWFzcDOm=json.loads(kdVapybKnRfLuAgvosjQtYPWFzcDOx.text)
   for kdVapybKnRfLuAgvosjQtYPWFzcDhX in kdVapybKnRfLuAgvosjQtYPWFzcDOm['filter']['filterlist'][0]['filter_item_list']:
    kdVapybKnRfLuAgvosjQtYPWFzcDlC={'season_Nm':kdVapybKnRfLuAgvosjQtYPWFzcDEN.Get_ChangeText(kdVapybKnRfLuAgvosjQtYPWFzcDhX.get('title')),'season_Id':kdVapybKnRfLuAgvosjQtYPWFzcDhX.get('api_path'),'thumbnail':kdVapybKnRfLuAgvosjQtYPWFzcDhw,'programNm':kdVapybKnRfLuAgvosjQtYPWFzcDEN.Get_ChangeText(kdVapybKnRfLuAgvosjQtYPWFzcDhI.get('programtitle')),'synopsis':kdVapybKnRfLuAgvosjQtYPWFzcDEN.Get_ChangeText(kdVapybKnRfLuAgvosjQtYPWFzcDhI.get('synopsis')),}
    kdVapybKnRfLuAgvosjQtYPWFzcDhq.append(kdVapybKnRfLuAgvosjQtYPWFzcDlC)
  except kdVapybKnRfLuAgvosjQtYPWFzcDqB as exception:
   kdVapybKnRfLuAgvosjQtYPWFzcDBM(exception)
   return[]
  return kdVapybKnRfLuAgvosjQtYPWFzcDhq
 def Get_Season_List(kdVapybKnRfLuAgvosjQtYPWFzcDEN,kdVapybKnRfLuAgvosjQtYPWFzcDhE):
  kdVapybKnRfLuAgvosjQtYPWFzcDhq=[]
  kdVapybKnRfLuAgvosjQtYPWFzcDhI=kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetProgramInfo(kdVapybKnRfLuAgvosjQtYPWFzcDhE)
  kdVapybKnRfLuAgvosjQtYPWFzcDhw={'poster':kdVapybKnRfLuAgvosjQtYPWFzcDhI.get('imgPoster'),'fanart':kdVapybKnRfLuAgvosjQtYPWFzcDhI.get('imgFanart'),'clearlogo':kdVapybKnRfLuAgvosjQtYPWFzcDhI.get('imgClearlogo'),}
  try:
   kdVapybKnRfLuAgvosjQtYPWFzcDOe='{}/fz/vod/contents-detail/{}'.format(kdVapybKnRfLuAgvosjQtYPWFzcDEN.API_DOMAIN,kdVapybKnRfLuAgvosjQtYPWFzcDhE)
   kdVapybKnRfLuAgvosjQtYPWFzcDEx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetDefaultParams()
   kdVapybKnRfLuAgvosjQtYPWFzcDOx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.callRequestCookies('Get',kdVapybKnRfLuAgvosjQtYPWFzcDOe,payload=kdVapybKnRfLuAgvosjQtYPWFzcDBG,params=kdVapybKnRfLuAgvosjQtYPWFzcDEx,headers=kdVapybKnRfLuAgvosjQtYPWFzcDBG,cookies=kdVapybKnRfLuAgvosjQtYPWFzcDBG)
   kdVapybKnRfLuAgvosjQtYPWFzcDOm=json.loads(kdVapybKnRfLuAgvosjQtYPWFzcDOx.text)
   for kdVapybKnRfLuAgvosjQtYPWFzcDhX in kdVapybKnRfLuAgvosjQtYPWFzcDOm['season_list']['season_item_list']:
    kdVapybKnRfLuAgvosjQtYPWFzcDlC={'season_Nm':kdVapybKnRfLuAgvosjQtYPWFzcDEN.Get_ChangeText(kdVapybKnRfLuAgvosjQtYPWFzcDhX.get('title')),'season_Id':kdVapybKnRfLuAgvosjQtYPWFzcDhX.get('id'),'thumbnail':kdVapybKnRfLuAgvosjQtYPWFzcDhw,'programNm':kdVapybKnRfLuAgvosjQtYPWFzcDEN.Get_ChangeText(kdVapybKnRfLuAgvosjQtYPWFzcDOm['programtitle']),'synopsis':kdVapybKnRfLuAgvosjQtYPWFzcDEN.Get_ChangeText(kdVapybKnRfLuAgvosjQtYPWFzcDhI.get('synopsis')),}
    kdVapybKnRfLuAgvosjQtYPWFzcDhq.append(kdVapybKnRfLuAgvosjQtYPWFzcDlC)
  except kdVapybKnRfLuAgvosjQtYPWFzcDqB as exception:
   kdVapybKnRfLuAgvosjQtYPWFzcDBM(exception)
   return[]
  return kdVapybKnRfLuAgvosjQtYPWFzcDhq
 def Get_Episode_List(kdVapybKnRfLuAgvosjQtYPWFzcDEN,seasionid,page_int=1,orderby='desc'):
  kdVapybKnRfLuAgvosjQtYPWFzcDhJ=[]
  kdVapybKnRfLuAgvosjQtYPWFzcDlJ=kdVapybKnRfLuAgvosjQtYPWFzcDlr=1
  kdVapybKnRfLuAgvosjQtYPWFzcDle=kdVapybKnRfLuAgvosjQtYPWFzcDqO
  kdVapybKnRfLuAgvosjQtYPWFzcDhI={}
  kdVapybKnRfLuAgvosjQtYPWFzcDhE=kdVapybKnRfLuAgvosjQtYPWFzcDEN.ProgramidToContentid(seasionid)
  kdVapybKnRfLuAgvosjQtYPWFzcDhI=kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetProgramInfo(kdVapybKnRfLuAgvosjQtYPWFzcDhE)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   kdVapybKnRfLuAgvosjQtYPWFzcDOe=kdVapybKnRfLuAgvosjQtYPWFzcDEN.API_DOMAIN+'/fz/vod/programs-contents/'+seasionid
   kdVapybKnRfLuAgvosjQtYPWFzcDEx={'limit':kdVapybKnRfLuAgvosjQtYPWFzcDEN.EP_LIMIT,'offset':kdVapybKnRfLuAgvosjQtYPWFzcDqE((page_int-1)*kdVapybKnRfLuAgvosjQtYPWFzcDEN.EP_LIMIT),'orderby':orderby,}
   kdVapybKnRfLuAgvosjQtYPWFzcDEx.update(kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetDefaultParams())
   kdVapybKnRfLuAgvosjQtYPWFzcDOx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.callRequestCookies('Get',kdVapybKnRfLuAgvosjQtYPWFzcDOe,payload=kdVapybKnRfLuAgvosjQtYPWFzcDBG,params=kdVapybKnRfLuAgvosjQtYPWFzcDEx,headers=kdVapybKnRfLuAgvosjQtYPWFzcDBG,cookies=kdVapybKnRfLuAgvosjQtYPWFzcDBG)
   kdVapybKnRfLuAgvosjQtYPWFzcDOm=json.loads(kdVapybKnRfLuAgvosjQtYPWFzcDOx.text)
   kdVapybKnRfLuAgvosjQtYPWFzcDlO=kdVapybKnRfLuAgvosjQtYPWFzcDOm['cell_toplist']['celllist']
   for kdVapybKnRfLuAgvosjQtYPWFzcDlh in kdVapybKnRfLuAgvosjQtYPWFzcDlO:
    kdVapybKnRfLuAgvosjQtYPWFzcDhU=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',kdVapybKnRfLuAgvosjQtYPWFzcDlh.get('synopsis'))
    kdVapybKnRfLuAgvosjQtYPWFzcDhx=kdVapybKnRfLuAgvosjQtYPWFzcDlh.get('thumbnail')
    if not kdVapybKnRfLuAgvosjQtYPWFzcDhx.startswith('http'):
     kdVapybKnRfLuAgvosjQtYPWFzcDhx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.HTTPTAG+kdVapybKnRfLuAgvosjQtYPWFzcDhx
    kdVapybKnRfLuAgvosjQtYPWFzcDhm=kdVapybKnRfLuAgvosjQtYPWFzcDhi=kdVapybKnRfLuAgvosjQtYPWFzcDhr=''
    kdVapybKnRfLuAgvosjQtYPWFzcDhm =kdVapybKnRfLuAgvosjQtYPWFzcDhI.get('imgPoster')
    kdVapybKnRfLuAgvosjQtYPWFzcDhi =kdVapybKnRfLuAgvosjQtYPWFzcDhI.get('imgFanart')
    kdVapybKnRfLuAgvosjQtYPWFzcDhr =kdVapybKnRfLuAgvosjQtYPWFzcDhI.get('imgClearlogo')
    kdVapybKnRfLuAgvosjQtYPWFzcDhT=kdVapybKnRfLuAgvosjQtYPWFzcDhI.get('programtitle')
    kdVapybKnRfLuAgvosjQtYPWFzcDhw={'thumb':kdVapybKnRfLuAgvosjQtYPWFzcDhx,'poster':kdVapybKnRfLuAgvosjQtYPWFzcDhm,'fanart':kdVapybKnRfLuAgvosjQtYPWFzcDhi,'clearlogo':kdVapybKnRfLuAgvosjQtYPWFzcDhr}
    kdVapybKnRfLuAgvosjQtYPWFzcDlC={'programtitle':kdVapybKnRfLuAgvosjQtYPWFzcDEN.Get_ChangeText(kdVapybKnRfLuAgvosjQtYPWFzcDhT),'episodetitle':kdVapybKnRfLuAgvosjQtYPWFzcDEN.Get_ChangeText(kdVapybKnRfLuAgvosjQtYPWFzcDlh['title_list'][0]['text']),'episodenumber':kdVapybKnRfLuAgvosjQtYPWFzcDlh['title_list'][1]['text'].replace('$O$',''),'contentid':kdVapybKnRfLuAgvosjQtYPWFzcDlh['contentid'],'synopsis':kdVapybKnRfLuAgvosjQtYPWFzcDEN.Get_ChangeText(kdVapybKnRfLuAgvosjQtYPWFzcDhU),'episodeactors':kdVapybKnRfLuAgvosjQtYPWFzcDlh.get('actors').split(',')if kdVapybKnRfLuAgvosjQtYPWFzcDlh.get('actors')!='' else[],'thumbnail':kdVapybKnRfLuAgvosjQtYPWFzcDhw,}
    kdVapybKnRfLuAgvosjQtYPWFzcDhJ.append(kdVapybKnRfLuAgvosjQtYPWFzcDlC)
   kdVapybKnRfLuAgvosjQtYPWFzcDlJ=kdVapybKnRfLuAgvosjQtYPWFzcDqw(kdVapybKnRfLuAgvosjQtYPWFzcDOm['cell_toplist']['pagecount'])
   if kdVapybKnRfLuAgvosjQtYPWFzcDOm['cell_toplist']['count']:kdVapybKnRfLuAgvosjQtYPWFzcDlr =kdVapybKnRfLuAgvosjQtYPWFzcDqw(kdVapybKnRfLuAgvosjQtYPWFzcDOm['cell_toplist']['count'])
   else:kdVapybKnRfLuAgvosjQtYPWFzcDlr=kdVapybKnRfLuAgvosjQtYPWFzcDEN.EP_LIMIT*page_int
   kdVapybKnRfLuAgvosjQtYPWFzcDle=kdVapybKnRfLuAgvosjQtYPWFzcDlJ>kdVapybKnRfLuAgvosjQtYPWFzcDlr
  except kdVapybKnRfLuAgvosjQtYPWFzcDqB as exception:
   kdVapybKnRfLuAgvosjQtYPWFzcDBM(exception)
   return[],kdVapybKnRfLuAgvosjQtYPWFzcDqO
  return kdVapybKnRfLuAgvosjQtYPWFzcDhJ,kdVapybKnRfLuAgvosjQtYPWFzcDle
 def GetEPGList(kdVapybKnRfLuAgvosjQtYPWFzcDEN,genre):
  kdVapybKnRfLuAgvosjQtYPWFzcDhS={}
  try:
   kdVapybKnRfLuAgvosjQtYPWFzcDhG=kdVapybKnRfLuAgvosjQtYPWFzcDEN.Get_Now_Datetime()
   if genre=='all':
    kdVapybKnRfLuAgvosjQtYPWFzcDhH =kdVapybKnRfLuAgvosjQtYPWFzcDhG+datetime.timedelta(hours=3)
   else:
    kdVapybKnRfLuAgvosjQtYPWFzcDhH =kdVapybKnRfLuAgvosjQtYPWFzcDhG+datetime.timedelta(hours=3)
   kdVapybKnRfLuAgvosjQtYPWFzcDOe=kdVapybKnRfLuAgvosjQtYPWFzcDEN.API_DOMAIN+'/live/epgs'
   kdVapybKnRfLuAgvosjQtYPWFzcDEx={'limit':'100','offset':'0','genre':genre,'startdatetime':kdVapybKnRfLuAgvosjQtYPWFzcDhG.strftime('%Y-%m-%d %H:00'),'enddatetime':kdVapybKnRfLuAgvosjQtYPWFzcDhH.strftime('%Y-%m-%d %H:00')}
   kdVapybKnRfLuAgvosjQtYPWFzcDEx.update(kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetDefaultParams())
   kdVapybKnRfLuAgvosjQtYPWFzcDOx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.callRequestCookies('Get',kdVapybKnRfLuAgvosjQtYPWFzcDOe,payload=kdVapybKnRfLuAgvosjQtYPWFzcDBG,params=kdVapybKnRfLuAgvosjQtYPWFzcDEx,headers=kdVapybKnRfLuAgvosjQtYPWFzcDBG,cookies=kdVapybKnRfLuAgvosjQtYPWFzcDBG)
   kdVapybKnRfLuAgvosjQtYPWFzcDOm=json.loads(kdVapybKnRfLuAgvosjQtYPWFzcDOx.text)
   kdVapybKnRfLuAgvosjQtYPWFzcDhM=kdVapybKnRfLuAgvosjQtYPWFzcDOm['list']
   for kdVapybKnRfLuAgvosjQtYPWFzcDlh in kdVapybKnRfLuAgvosjQtYPWFzcDhM:
    kdVapybKnRfLuAgvosjQtYPWFzcDCE=''
    for kdVapybKnRfLuAgvosjQtYPWFzcDCO in kdVapybKnRfLuAgvosjQtYPWFzcDlh['list']:
     if kdVapybKnRfLuAgvosjQtYPWFzcDCE:kdVapybKnRfLuAgvosjQtYPWFzcDCE+='\n'
     kdVapybKnRfLuAgvosjQtYPWFzcDCE+=kdVapybKnRfLuAgvosjQtYPWFzcDEN.Get_ChangeText(kdVapybKnRfLuAgvosjQtYPWFzcDCO['title'])+'\n'
     kdVapybKnRfLuAgvosjQtYPWFzcDCE+=' [%s ~ %s]'%(kdVapybKnRfLuAgvosjQtYPWFzcDCO['starttime'][-5:],kdVapybKnRfLuAgvosjQtYPWFzcDCO['endtime'][-5:])+'\n'
    kdVapybKnRfLuAgvosjQtYPWFzcDhS[kdVapybKnRfLuAgvosjQtYPWFzcDlh['channelid']]=kdVapybKnRfLuAgvosjQtYPWFzcDCE
  except kdVapybKnRfLuAgvosjQtYPWFzcDqB as exception:
   kdVapybKnRfLuAgvosjQtYPWFzcDBM(exception)
  return kdVapybKnRfLuAgvosjQtYPWFzcDhS
 def Get_LiveChannel_List(kdVapybKnRfLuAgvosjQtYPWFzcDEN,genre,kdVapybKnRfLuAgvosjQtYPWFzcDlE):
  kdVapybKnRfLuAgvosjQtYPWFzcDlX=[]
  (kdVapybKnRfLuAgvosjQtYPWFzcDOe,kdVapybKnRfLuAgvosjQtYPWFzcDEx)=kdVapybKnRfLuAgvosjQtYPWFzcDEN.Baseapi_Parse(kdVapybKnRfLuAgvosjQtYPWFzcDlE)
  if kdVapybKnRfLuAgvosjQtYPWFzcDOe=='':return kdVapybKnRfLuAgvosjQtYPWFzcDlX
  kdVapybKnRfLuAgvosjQtYPWFzcDCl=kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetEPGList(genre)
  try:
   kdVapybKnRfLuAgvosjQtYPWFzcDEx.update(kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetDefaultParams())
   kdVapybKnRfLuAgvosjQtYPWFzcDEx['genre']=genre
   kdVapybKnRfLuAgvosjQtYPWFzcDOx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.callRequestCookies('Get',kdVapybKnRfLuAgvosjQtYPWFzcDOe,payload=kdVapybKnRfLuAgvosjQtYPWFzcDBG,params=kdVapybKnRfLuAgvosjQtYPWFzcDEx,headers=kdVapybKnRfLuAgvosjQtYPWFzcDBG,cookies=kdVapybKnRfLuAgvosjQtYPWFzcDBG)
   kdVapybKnRfLuAgvosjQtYPWFzcDOm=json.loads(kdVapybKnRfLuAgvosjQtYPWFzcDOx.text)
   if not('celllist' in kdVapybKnRfLuAgvosjQtYPWFzcDOm['cell_toplist']):return[]
   kdVapybKnRfLuAgvosjQtYPWFzcDlO=kdVapybKnRfLuAgvosjQtYPWFzcDOm['cell_toplist']['celllist']
   for kdVapybKnRfLuAgvosjQtYPWFzcDlh in kdVapybKnRfLuAgvosjQtYPWFzcDlO:
    kdVapybKnRfLuAgvosjQtYPWFzcDhE=kdVapybKnRfLuAgvosjQtYPWFzcDlh['contentid']
    if kdVapybKnRfLuAgvosjQtYPWFzcDhE in kdVapybKnRfLuAgvosjQtYPWFzcDCl:
     kdVapybKnRfLuAgvosjQtYPWFzcDCh=kdVapybKnRfLuAgvosjQtYPWFzcDCl[kdVapybKnRfLuAgvosjQtYPWFzcDhE]
    else:
     kdVapybKnRfLuAgvosjQtYPWFzcDCh=''
    kdVapybKnRfLuAgvosjQtYPWFzcDlC={'studio':kdVapybKnRfLuAgvosjQtYPWFzcDlh['title_list'][0]['text'],'tvshowtitle':kdVapybKnRfLuAgvosjQtYPWFzcDEN.Get_ChangeText(kdVapybKnRfLuAgvosjQtYPWFzcDlh['title_list'][1]['text']),'channelid':kdVapybKnRfLuAgvosjQtYPWFzcDhE,'age':kdVapybKnRfLuAgvosjQtYPWFzcDlh['age'],'thumbnail':'https://%s'%kdVapybKnRfLuAgvosjQtYPWFzcDlh.get('thumbnail'),'epg':kdVapybKnRfLuAgvosjQtYPWFzcDCh}
    kdVapybKnRfLuAgvosjQtYPWFzcDlX.append(kdVapybKnRfLuAgvosjQtYPWFzcDlC)
  except kdVapybKnRfLuAgvosjQtYPWFzcDqB as exception:
   kdVapybKnRfLuAgvosjQtYPWFzcDBM(exception)
   return[]
  return kdVapybKnRfLuAgvosjQtYPWFzcDlX
 def Get_Search_List(kdVapybKnRfLuAgvosjQtYPWFzcDEN,search_key,sType,page_int,exclusion21=kdVapybKnRfLuAgvosjQtYPWFzcDqO):
  kdVapybKnRfLuAgvosjQtYPWFzcDCN=[]
  kdVapybKnRfLuAgvosjQtYPWFzcDlJ=kdVapybKnRfLuAgvosjQtYPWFzcDlr=1
  kdVapybKnRfLuAgvosjQtYPWFzcDle=kdVapybKnRfLuAgvosjQtYPWFzcDqO
  try:
   kdVapybKnRfLuAgvosjQtYPWFzcDOe=kdVapybKnRfLuAgvosjQtYPWFzcDEN.API_DOMAIN+'/fz/search/band.js'
   kdVapybKnRfLuAgvosjQtYPWFzcDEx={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':kdVapybKnRfLuAgvosjQtYPWFzcDqE((page_int-1)*kdVapybKnRfLuAgvosjQtYPWFzcDEN.SEARCH_LIMIT),'limit':kdVapybKnRfLuAgvosjQtYPWFzcDEN.SEARCH_LIMIT,'orderby':'score','mtype':'svod',}
   kdVapybKnRfLuAgvosjQtYPWFzcDEx.update(kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetDefaultParams())
   kdVapybKnRfLuAgvosjQtYPWFzcDOx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.callRequestCookies('Get',kdVapybKnRfLuAgvosjQtYPWFzcDOe,payload=kdVapybKnRfLuAgvosjQtYPWFzcDBG,params=kdVapybKnRfLuAgvosjQtYPWFzcDEx,headers=kdVapybKnRfLuAgvosjQtYPWFzcDBG,cookies=kdVapybKnRfLuAgvosjQtYPWFzcDBG)
   kdVapybKnRfLuAgvosjQtYPWFzcDhO=json.loads(kdVapybKnRfLuAgvosjQtYPWFzcDOx.text)
   if not('celllist' in kdVapybKnRfLuAgvosjQtYPWFzcDhO['band']):return kdVapybKnRfLuAgvosjQtYPWFzcDCN,kdVapybKnRfLuAgvosjQtYPWFzcDle
   kdVapybKnRfLuAgvosjQtYPWFzcDlO=kdVapybKnRfLuAgvosjQtYPWFzcDhO['band']['celllist']
   for kdVapybKnRfLuAgvosjQtYPWFzcDlh in kdVapybKnRfLuAgvosjQtYPWFzcDlO:
    kdVapybKnRfLuAgvosjQtYPWFzcDlU=''
    for kdVapybKnRfLuAgvosjQtYPWFzcDhX in kdVapybKnRfLuAgvosjQtYPWFzcDlh['event_list']:
     if kdVapybKnRfLuAgvosjQtYPWFzcDhX['type']=='on-navigation':
      kdVapybKnRfLuAgvosjQtYPWFzcDlU=kdVapybKnRfLuAgvosjQtYPWFzcDhX['url']
    if kdVapybKnRfLuAgvosjQtYPWFzcDlU=='':break
    kdVapybKnRfLuAgvosjQtYPWFzcDlx=urllib.parse.urlsplit(kdVapybKnRfLuAgvosjQtYPWFzcDlU).query
    kdVapybKnRfLuAgvosjQtYPWFzcDlm=kdVapybKnRfLuAgvosjQtYPWFzcDlx[0:kdVapybKnRfLuAgvosjQtYPWFzcDlx.find('=')]
    kdVapybKnRfLuAgvosjQtYPWFzcDlH=kdVapybKnRfLuAgvosjQtYPWFzcDqI(urllib.parse.parse_qsl(kdVapybKnRfLuAgvosjQtYPWFzcDlx))
    kdVapybKnRfLuAgvosjQtYPWFzcDli=kdVapybKnRfLuAgvosjQtYPWFzcDlH.get(kdVapybKnRfLuAgvosjQtYPWFzcDlm)
    kdVapybKnRfLuAgvosjQtYPWFzcDlC={'title':kdVapybKnRfLuAgvosjQtYPWFzcDlh['title_list'][0]['text'],'age':kdVapybKnRfLuAgvosjQtYPWFzcDlh['age'],'thumbnail':'https://%s'%kdVapybKnRfLuAgvosjQtYPWFzcDlh.get('thumbnail'),'videoid':kdVapybKnRfLuAgvosjQtYPWFzcDli,'vidtype':kdVapybKnRfLuAgvosjQtYPWFzcDlm,}
    kdVapybKnRfLuAgvosjQtYPWFzcDCB=kdVapybKnRfLuAgvosjQtYPWFzcDqO
    for kdVapybKnRfLuAgvosjQtYPWFzcDCq in kdVapybKnRfLuAgvosjQtYPWFzcDlh['bottom_taglist']:
     if kdVapybKnRfLuAgvosjQtYPWFzcDCq=='won':
      kdVapybKnRfLuAgvosjQtYPWFzcDCB=kdVapybKnRfLuAgvosjQtYPWFzcDqh
      break
    if kdVapybKnRfLuAgvosjQtYPWFzcDCB==kdVapybKnRfLuAgvosjQtYPWFzcDqh: 
     kdVapybKnRfLuAgvosjQtYPWFzcDlC['title']=kdVapybKnRfLuAgvosjQtYPWFzcDlC['title']+' [개별구매]'
    if exclusion21==kdVapybKnRfLuAgvosjQtYPWFzcDqO or kdVapybKnRfLuAgvosjQtYPWFzcDlh.get('age')!='21':
     kdVapybKnRfLuAgvosjQtYPWFzcDCN.append(kdVapybKnRfLuAgvosjQtYPWFzcDlC)
   kdVapybKnRfLuAgvosjQtYPWFzcDlJ=kdVapybKnRfLuAgvosjQtYPWFzcDqw(kdVapybKnRfLuAgvosjQtYPWFzcDhO['band']['pagecount'])
   if kdVapybKnRfLuAgvosjQtYPWFzcDhO['band']['count']:kdVapybKnRfLuAgvosjQtYPWFzcDlr =kdVapybKnRfLuAgvosjQtYPWFzcDqw(kdVapybKnRfLuAgvosjQtYPWFzcDhO['band']['count'])
   else:kdVapybKnRfLuAgvosjQtYPWFzcDlr=kdVapybKnRfLuAgvosjQtYPWFzcDEN.LIST_LIMIT
   kdVapybKnRfLuAgvosjQtYPWFzcDle=kdVapybKnRfLuAgvosjQtYPWFzcDlJ>kdVapybKnRfLuAgvosjQtYPWFzcDlr
  except kdVapybKnRfLuAgvosjQtYPWFzcDqB as exception:
   kdVapybKnRfLuAgvosjQtYPWFzcDBM(exception)
  return kdVapybKnRfLuAgvosjQtYPWFzcDCN,kdVapybKnRfLuAgvosjQtYPWFzcDle 
 def GetSecureToken(kdVapybKnRfLuAgvosjQtYPWFzcDEN):
  kdVapybKnRfLuAgvosjQtYPWFzcDOe=kdVapybKnRfLuAgvosjQtYPWFzcDEN.API_DOMAIN+'/ip'
  kdVapybKnRfLuAgvosjQtYPWFzcDEx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetDefaultParams()
  kdVapybKnRfLuAgvosjQtYPWFzcDOx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.callRequestCookies('Get',kdVapybKnRfLuAgvosjQtYPWFzcDOe,payload=kdVapybKnRfLuAgvosjQtYPWFzcDBG,params=kdVapybKnRfLuAgvosjQtYPWFzcDEx,headers=kdVapybKnRfLuAgvosjQtYPWFzcDBG,cookies=kdVapybKnRfLuAgvosjQtYPWFzcDBG)
  kdVapybKnRfLuAgvosjQtYPWFzcDOm=json.loads(kdVapybKnRfLuAgvosjQtYPWFzcDOx.text)
  return kdVapybKnRfLuAgvosjQtYPWFzcDOm['securetoken']
 def Wavve_Parse_m3u8(kdVapybKnRfLuAgvosjQtYPWFzcDEN,kdVapybKnRfLuAgvosjQtYPWFzcDNI):
  try:
   kdVapybKnRfLuAgvosjQtYPWFzcDOw={'user-agent':'pooqV2/5.6.0 (Linux;Android 10) ExoPlayerLib/2.13.3'}
   kdVapybKnRfLuAgvosjQtYPWFzcDOx=requests.get(url=kdVapybKnRfLuAgvosjQtYPWFzcDNI['stream_url'],headers=kdVapybKnRfLuAgvosjQtYPWFzcDOw,cookies=kdVapybKnRfLuAgvosjQtYPWFzcDNI['stream_cookie'])
   kdVapybKnRfLuAgvosjQtYPWFzcDCI=kdVapybKnRfLuAgvosjQtYPWFzcDOx.content.decode('utf-8')
   if '#EXTM3U' not in kdVapybKnRfLuAgvosjQtYPWFzcDCI:
    return kdVapybKnRfLuAgvosjQtYPWFzcDqO
   if '#EXT-X-STREAM-INF' not in kdVapybKnRfLuAgvosjQtYPWFzcDCI: 
    return kdVapybKnRfLuAgvosjQtYPWFzcDqO
   kdVapybKnRfLuAgvosjQtYPWFzcDCw=0
   for kdVapybKnRfLuAgvosjQtYPWFzcDCX in kdVapybKnRfLuAgvosjQtYPWFzcDCI.splitlines():
    if kdVapybKnRfLuAgvosjQtYPWFzcDCX.startswith('#EXT-X-STREAM-INF'):
     kdVapybKnRfLuAgvosjQtYPWFzcDCJ=kdVapybKnRfLuAgvosjQtYPWFzcDEN.MediaLine_Parse(kdVapybKnRfLuAgvosjQtYPWFzcDCX,'#EXT-X-STREAM-INF')
     if kdVapybKnRfLuAgvosjQtYPWFzcDCw<kdVapybKnRfLuAgvosjQtYPWFzcDqw(kdVapybKnRfLuAgvosjQtYPWFzcDCJ.get('BANDWIDTH')):
      kdVapybKnRfLuAgvosjQtYPWFzcDCw=kdVapybKnRfLuAgvosjQtYPWFzcDqw(kdVapybKnRfLuAgvosjQtYPWFzcDCJ.get('BANDWIDTH'))
   kdVapybKnRfLuAgvosjQtYPWFzcDCe=[]
   kdVapybKnRfLuAgvosjQtYPWFzcDCU=kdVapybKnRfLuAgvosjQtYPWFzcDqO
   for kdVapybKnRfLuAgvosjQtYPWFzcDCX in kdVapybKnRfLuAgvosjQtYPWFzcDCI.splitlines():
    if kdVapybKnRfLuAgvosjQtYPWFzcDCU==kdVapybKnRfLuAgvosjQtYPWFzcDqh:
     kdVapybKnRfLuAgvosjQtYPWFzcDCU=kdVapybKnRfLuAgvosjQtYPWFzcDqO
     continue
    if kdVapybKnRfLuAgvosjQtYPWFzcDCX.startswith('#EXT-X-STREAM-INF'):
     kdVapybKnRfLuAgvosjQtYPWFzcDCJ=kdVapybKnRfLuAgvosjQtYPWFzcDEN.MediaLine_Parse(kdVapybKnRfLuAgvosjQtYPWFzcDCX,'#EXT-X-STREAM-INF')
     if kdVapybKnRfLuAgvosjQtYPWFzcDCw!=kdVapybKnRfLuAgvosjQtYPWFzcDqw(kdVapybKnRfLuAgvosjQtYPWFzcDCJ.get('BANDWIDTH')):
      kdVapybKnRfLuAgvosjQtYPWFzcDCU=kdVapybKnRfLuAgvosjQtYPWFzcDqh
      continue
    kdVapybKnRfLuAgvosjQtYPWFzcDCe.append(kdVapybKnRfLuAgvosjQtYPWFzcDCX)
  except kdVapybKnRfLuAgvosjQtYPWFzcDqB as exception:
   kdVapybKnRfLuAgvosjQtYPWFzcDBM(exception)
   return kdVapybKnRfLuAgvosjQtYPWFzcDqO
  kdVapybKnRfLuAgvosjQtYPWFzcDCx='\n'.join(kdVapybKnRfLuAgvosjQtYPWFzcDCe)
  kdVapybKnRfLuAgvosjQtYPWFzcDEN.TextFile_Save(kdVapybKnRfLuAgvosjQtYPWFzcDEN.WV_STREAM_FILENAME,kdVapybKnRfLuAgvosjQtYPWFzcDCx)
  return kdVapybKnRfLuAgvosjQtYPWFzcDqh
 def Wavve_Parse_mpd(kdVapybKnRfLuAgvosjQtYPWFzcDEN,kdVapybKnRfLuAgvosjQtYPWFzcDNI):
  kdVapybKnRfLuAgvosjQtYPWFzcDOw={'user-agent':'pooqV2/5.6.0 (Linux;Android 10) ExoPlayerLib/2.13.3'}
  kdVapybKnRfLuAgvosjQtYPWFzcDOx=requests.get(url=kdVapybKnRfLuAgvosjQtYPWFzcDNI['stream_url'],headers=kdVapybKnRfLuAgvosjQtYPWFzcDOw,cookies=kdVapybKnRfLuAgvosjQtYPWFzcDNI['stream_cookie'])
  kdVapybKnRfLuAgvosjQtYPWFzcDCm=kdVapybKnRfLuAgvosjQtYPWFzcDOx.content.decode('utf-8')
  kdVapybKnRfLuAgvosjQtYPWFzcDCi =ET.ElementTree(ET.fromstring(kdVapybKnRfLuAgvosjQtYPWFzcDCm))
  kdVapybKnRfLuAgvosjQtYPWFzcDCr =kdVapybKnRfLuAgvosjQtYPWFzcDCi.getroot()
  kdVapybKnRfLuAgvosjQtYPWFzcDCT=re.match(r'\{.*\}',kdVapybKnRfLuAgvosjQtYPWFzcDCr.tag)[0] 
  kdVapybKnRfLuAgvosjQtYPWFzcDCS=kdVapybKnRfLuAgvosjQtYPWFzcDqI([node for _,node in ET.iterparse(io.StringIO(kdVapybKnRfLuAgvosjQtYPWFzcDCm),events=['start-ns'])])
  for kdVapybKnRfLuAgvosjQtYPWFzcDOq,kdVapybKnRfLuAgvosjQtYPWFzcDNq in kdVapybKnRfLuAgvosjQtYPWFzcDCS.items():
   ET.register_namespace(kdVapybKnRfLuAgvosjQtYPWFzcDOq,kdVapybKnRfLuAgvosjQtYPWFzcDNq)
  kdVapybKnRfLuAgvosjQtYPWFzcDCG=kdVapybKnRfLuAgvosjQtYPWFzcDCr.find(kdVapybKnRfLuAgvosjQtYPWFzcDCT+'Period')
  for kdVapybKnRfLuAgvosjQtYPWFzcDCH in kdVapybKnRfLuAgvosjQtYPWFzcDCG.findall(kdVapybKnRfLuAgvosjQtYPWFzcDCT+'AdaptationSet'):
   if kdVapybKnRfLuAgvosjQtYPWFzcDCH.attrib.get('mimeType')=='video/mp4':
    kdVapybKnRfLuAgvosjQtYPWFzcDCM=0
    for kdVapybKnRfLuAgvosjQtYPWFzcDNE in kdVapybKnRfLuAgvosjQtYPWFzcDCH.findall(kdVapybKnRfLuAgvosjQtYPWFzcDCT+'Representation'):
     kdVapybKnRfLuAgvosjQtYPWFzcDNO=kdVapybKnRfLuAgvosjQtYPWFzcDqw(kdVapybKnRfLuAgvosjQtYPWFzcDNE.attrib.get('bandwidth'))
     if kdVapybKnRfLuAgvosjQtYPWFzcDCM<kdVapybKnRfLuAgvosjQtYPWFzcDNO:kdVapybKnRfLuAgvosjQtYPWFzcDCM=kdVapybKnRfLuAgvosjQtYPWFzcDNO
    for kdVapybKnRfLuAgvosjQtYPWFzcDNE in kdVapybKnRfLuAgvosjQtYPWFzcDCH.findall(kdVapybKnRfLuAgvosjQtYPWFzcDCT+'Representation'):
     if kdVapybKnRfLuAgvosjQtYPWFzcDCM>kdVapybKnRfLuAgvosjQtYPWFzcDqw(kdVapybKnRfLuAgvosjQtYPWFzcDNE.attrib.get('bandwidth')):
      kdVapybKnRfLuAgvosjQtYPWFzcDCH.remove(kdVapybKnRfLuAgvosjQtYPWFzcDNE)
   elif kdVapybKnRfLuAgvosjQtYPWFzcDCH.attrib.get('mimeType')=='audio/mp4':
    kdVapybKnRfLuAgvosjQtYPWFzcDCM=0
    for kdVapybKnRfLuAgvosjQtYPWFzcDNE in kdVapybKnRfLuAgvosjQtYPWFzcDCH.findall(kdVapybKnRfLuAgvosjQtYPWFzcDCT+'Representation'):
     kdVapybKnRfLuAgvosjQtYPWFzcDNO=kdVapybKnRfLuAgvosjQtYPWFzcDqw(kdVapybKnRfLuAgvosjQtYPWFzcDNE.attrib.get('bandwidth'))
     if kdVapybKnRfLuAgvosjQtYPWFzcDCM<kdVapybKnRfLuAgvosjQtYPWFzcDNO:kdVapybKnRfLuAgvosjQtYPWFzcDCM=kdVapybKnRfLuAgvosjQtYPWFzcDNO
    for kdVapybKnRfLuAgvosjQtYPWFzcDNE in kdVapybKnRfLuAgvosjQtYPWFzcDCH.findall(kdVapybKnRfLuAgvosjQtYPWFzcDCT+'Representation'):
     if kdVapybKnRfLuAgvosjQtYPWFzcDCM>kdVapybKnRfLuAgvosjQtYPWFzcDqw(kdVapybKnRfLuAgvosjQtYPWFzcDNE.attrib.get('bandwidth')):
      kdVapybKnRfLuAgvosjQtYPWFzcDCH.remove(kdVapybKnRfLuAgvosjQtYPWFzcDNE)
   else:
    continue
  kdVapybKnRfLuAgvosjQtYPWFzcDNl=ET.tostring(kdVapybKnRfLuAgvosjQtYPWFzcDCr).decode('utf-8')
  kdVapybKnRfLuAgvosjQtYPWFzcDNh='<?xml version="1.0" encoding="UTF-8"?>\n'
  kdVapybKnRfLuAgvosjQtYPWFzcDEN.TextFile_Save(kdVapybKnRfLuAgvosjQtYPWFzcDEN.WV_STREAM_FILENAME,kdVapybKnRfLuAgvosjQtYPWFzcDNh+kdVapybKnRfLuAgvosjQtYPWFzcDNl)
  return kdVapybKnRfLuAgvosjQtYPWFzcDqh
 def MediaLine_Parse(kdVapybKnRfLuAgvosjQtYPWFzcDEN,kdVapybKnRfLuAgvosjQtYPWFzcDCX,prefix):
  kdVapybKnRfLuAgvosjQtYPWFzcDCJ={}
  for kdVapybKnRfLuAgvosjQtYPWFzcDNC in kdVapybKnRfLuAgvosjQtYPWFzcDEC.split(kdVapybKnRfLuAgvosjQtYPWFzcDCX.replace(prefix+':',''))[1::2]:
   kdVapybKnRfLuAgvosjQtYPWFzcDNB,kdVapybKnRfLuAgvosjQtYPWFzcDNq=kdVapybKnRfLuAgvosjQtYPWFzcDNC.split('=',1)
   kdVapybKnRfLuAgvosjQtYPWFzcDCJ[kdVapybKnRfLuAgvosjQtYPWFzcDNB.upper()]=kdVapybKnRfLuAgvosjQtYPWFzcDNq.replace('"','').strip()
  return kdVapybKnRfLuAgvosjQtYPWFzcDCJ
 def GetStreamingURL(kdVapybKnRfLuAgvosjQtYPWFzcDEN,mode,kdVapybKnRfLuAgvosjQtYPWFzcDhE,quality_int,pvrmode='-',playOption={}):
  kdVapybKnRfLuAgvosjQtYPWFzcDNI ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  kdVapybKnRfLuAgvosjQtYPWFzcDNw=[]
  if mode=='LIVE':
   kdVapybKnRfLuAgvosjQtYPWFzcDOe =kdVapybKnRfLuAgvosjQtYPWFzcDEN.API_DOMAIN+'/live/channels/'+kdVapybKnRfLuAgvosjQtYPWFzcDhE
   kdVapybKnRfLuAgvosjQtYPWFzcDNX='live'
  elif mode=='VOD':
   kdVapybKnRfLuAgvosjQtYPWFzcDOe =kdVapybKnRfLuAgvosjQtYPWFzcDEN.API_DOMAIN+'/fz/vod/contents-detail/'+kdVapybKnRfLuAgvosjQtYPWFzcDhE 
   kdVapybKnRfLuAgvosjQtYPWFzcDNX='vod'
  elif mode=='MOVIE':
   kdVapybKnRfLuAgvosjQtYPWFzcDOe =kdVapybKnRfLuAgvosjQtYPWFzcDEN.API_DOMAIN+'/fz/movie/contents/'+kdVapybKnRfLuAgvosjQtYPWFzcDhE
   kdVapybKnRfLuAgvosjQtYPWFzcDNX='movie'
  kdVapybKnRfLuAgvosjQtYPWFzcDNJ={'hdr':'sdr','uhd':'-',}
  try:
   kdVapybKnRfLuAgvosjQtYPWFzcDEx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetDefaultParams()
   kdVapybKnRfLuAgvosjQtYPWFzcDOx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.callRequestCookies('Get',kdVapybKnRfLuAgvosjQtYPWFzcDOe,payload=kdVapybKnRfLuAgvosjQtYPWFzcDBG,params=kdVapybKnRfLuAgvosjQtYPWFzcDEx,headers=kdVapybKnRfLuAgvosjQtYPWFzcDBG,cookies=kdVapybKnRfLuAgvosjQtYPWFzcDBG)
   kdVapybKnRfLuAgvosjQtYPWFzcDOm=json.loads(kdVapybKnRfLuAgvosjQtYPWFzcDOx.text)
   kdVapybKnRfLuAgvosjQtYPWFzcDNe=kdVapybKnRfLuAgvosjQtYPWFzcDOm['qualities']['list']
   if kdVapybKnRfLuAgvosjQtYPWFzcDNe==kdVapybKnRfLuAgvosjQtYPWFzcDBG:return kdVapybKnRfLuAgvosjQtYPWFzcDNI
   for kdVapybKnRfLuAgvosjQtYPWFzcDNU in kdVapybKnRfLuAgvosjQtYPWFzcDNe:
    kdVapybKnRfLuAgvosjQtYPWFzcDNw.append(kdVapybKnRfLuAgvosjQtYPWFzcDqw(kdVapybKnRfLuAgvosjQtYPWFzcDNU.get('id').rstrip('p')))
   if 'drms' in kdVapybKnRfLuAgvosjQtYPWFzcDOm:
    if kdVapybKnRfLuAgvosjQtYPWFzcDOm['drms']:
     kdVapybKnRfLuAgvosjQtYPWFzcDNI['stream_action']='dash' 
   if playOption.get('enable_hdr'):
    if 'mediatypes' in kdVapybKnRfLuAgvosjQtYPWFzcDOm.get('qualities'):
     for kdVapybKnRfLuAgvosjQtYPWFzcDNx in kdVapybKnRfLuAgvosjQtYPWFzcDOm.get('qualities').get('mediatypes'):
      if kdVapybKnRfLuAgvosjQtYPWFzcDNx=='HDR10':
       kdVapybKnRfLuAgvosjQtYPWFzcDNJ['hdr']='hdr'
       kdVapybKnRfLuAgvosjQtYPWFzcDNI['stream_action']='dash'
       break
   if playOption.get('enable_uhd'):
    for kdVapybKnRfLuAgvosjQtYPWFzcDNx in kdVapybKnRfLuAgvosjQtYPWFzcDOm.get('qualities').get('list'):
     if kdVapybKnRfLuAgvosjQtYPWFzcDNx.get('name')=='UHD':
      kdVapybKnRfLuAgvosjQtYPWFzcDNJ['uhd']='uhd'
      break
  except kdVapybKnRfLuAgvosjQtYPWFzcDqB as exception:
   kdVapybKnRfLuAgvosjQtYPWFzcDBM(exception)
   return kdVapybKnRfLuAgvosjQtYPWFzcDNI
  kdVapybKnRfLuAgvosjQtYPWFzcDBM('stream_action : '+kdVapybKnRfLuAgvosjQtYPWFzcDNI['stream_action'])
  try:
   kdVapybKnRfLuAgvosjQtYPWFzcDNm=kdVapybKnRfLuAgvosjQtYPWFzcDEN.CheckQuality(quality_int,kdVapybKnRfLuAgvosjQtYPWFzcDNw)
   kdVapybKnRfLuAgvosjQtYPWFzcDBM(kdVapybKnRfLuAgvosjQtYPWFzcDNm)
   if kdVapybKnRfLuAgvosjQtYPWFzcDNm<1080:
    kdVapybKnRfLuAgvosjQtYPWFzcDNJ['uhd']='-'
    kdVapybKnRfLuAgvosjQtYPWFzcDNJ['hdr']='sdr'
   if kdVapybKnRfLuAgvosjQtYPWFzcDNJ['uhd']=='uhd':kdVapybKnRfLuAgvosjQtYPWFzcDNm=2160 
   kdVapybKnRfLuAgvosjQtYPWFzcDNi=kdVapybKnRfLuAgvosjQtYPWFzcDqE(kdVapybKnRfLuAgvosjQtYPWFzcDNm)+'p'
   kdVapybKnRfLuAgvosjQtYPWFzcDBM(kdVapybKnRfLuAgvosjQtYPWFzcDNi)
   kdVapybKnRfLuAgvosjQtYPWFzcDOe='https://delivery.wavve.com/v1/streaming/{}'.format(kdVapybKnRfLuAgvosjQtYPWFzcDNX)
   if kdVapybKnRfLuAgvosjQtYPWFzcDNJ['hdr']=='hdr' or kdVapybKnRfLuAgvosjQtYPWFzcDNJ['uhd']=='uhd':
    kdVapybKnRfLuAgvosjQtYPWFzcDEx={'service':'wavve','contentid':kdVapybKnRfLuAgvosjQtYPWFzcDhE,'audioChannel':'2ch','contenttype':kdVapybKnRfLuAgvosjQtYPWFzcDNX,'hdr':'HDR10','videocodec':'HEVC','audiocodec':'AAC','issurround':'y','format':'normal','withinsubtitle':'n','action':kdVapybKnRfLuAgvosjQtYPWFzcDNI['stream_action'],'protocol':kdVapybKnRfLuAgvosjQtYPWFzcDNI['stream_action'],'quality':kdVapybKnRfLuAgvosjQtYPWFzcDNi,'modelid':'SHIELD Android TV','guid':kdVapybKnRfLuAgvosjQtYPWFzcDEN.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n',}
    kdVapybKnRfLuAgvosjQtYPWFzcDEx.update(kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetDefaultParams_AND())
   else:
    kdVapybKnRfLuAgvosjQtYPWFzcDEx={'service':'wavve','contentid':kdVapybKnRfLuAgvosjQtYPWFzcDhE,'audioChannel':'2ch','contenttype':kdVapybKnRfLuAgvosjQtYPWFzcDNX,'hdr':'sdr','videocodec':'avc','audiocodec':'aac','issurround':'n','format':'normal','withinsubtitle':'n','action':kdVapybKnRfLuAgvosjQtYPWFzcDNI['stream_action'],'protocol':kdVapybKnRfLuAgvosjQtYPWFzcDNI['stream_action'],'quality':kdVapybKnRfLuAgvosjQtYPWFzcDNi,'deviceModelId':'Windows 10','guid':kdVapybKnRfLuAgvosjQtYPWFzcDEN.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n',}
    '''
    params = {'contentid' : contentid, 'contenttype' : contenttype, 'quality' : quality_param, ###### if login=False : 체크 미비 (auto, 1080p) ###### 'deviceModelId' : 'Windows 10', 'guid' : self.WV['cookies']['uuid'], # self.GetGUID(guidType=2), 'lastplayid' : '', #self.guid 'authtype' : 'cookie', 'isabr' : 'y', 'ishevc' : 'n', 'action' : url_info['stream_action'], # 기본 hls / DRM dash ##### 'protocol' : url_info['stream_action'], # hls ? 확인필요 'hdr' : 'sdr', # hdr 'videocodec' : 'avc', 'audiocodec' : 'aac', 'issurround' : 'n', 'format' : 'normal', 'withinsubtitle' : 'n', }
    '''    
    kdVapybKnRfLuAgvosjQtYPWFzcDEx.update(kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetDefaultParams())
   kdVapybKnRfLuAgvosjQtYPWFzcDOw={'wavve-credential':kdVapybKnRfLuAgvosjQtYPWFzcDEN.WV['cookies']['credential'],}
   kdVapybKnRfLuAgvosjQtYPWFzcDOx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.callRequestCookies('Get',kdVapybKnRfLuAgvosjQtYPWFzcDOe,payload=kdVapybKnRfLuAgvosjQtYPWFzcDBG,params=kdVapybKnRfLuAgvosjQtYPWFzcDEx,headers=kdVapybKnRfLuAgvosjQtYPWFzcDOw,cookies=kdVapybKnRfLuAgvosjQtYPWFzcDBG)
   kdVapybKnRfLuAgvosjQtYPWFzcDOm=json.loads(kdVapybKnRfLuAgvosjQtYPWFzcDOx.text)
   kdVapybKnRfLuAgvosjQtYPWFzcDNI['stream_url']=kdVapybKnRfLuAgvosjQtYPWFzcDOm['playurl']
   if kdVapybKnRfLuAgvosjQtYPWFzcDNI['stream_url']==kdVapybKnRfLuAgvosjQtYPWFzcDBG:return kdVapybKnRfLuAgvosjQtYPWFzcDNI
   kdVapybKnRfLuAgvosjQtYPWFzcDNI['stream_cookie']=kdVapybKnRfLuAgvosjQtYPWFzcDEN.make_str_ToCookie(kdVapybKnRfLuAgvosjQtYPWFzcDOm['awscookie'])
   kdVapybKnRfLuAgvosjQtYPWFzcDNI['stream_drm'] =kdVapybKnRfLuAgvosjQtYPWFzcDOm['drm']
   if 'previewmsg' in kdVapybKnRfLuAgvosjQtYPWFzcDOm['preview']:kdVapybKnRfLuAgvosjQtYPWFzcDNI['stream_preview']=kdVapybKnRfLuAgvosjQtYPWFzcDOm['preview']['previewmsg']
   if 'subtitles' in kdVapybKnRfLuAgvosjQtYPWFzcDOm:
    for kdVapybKnRfLuAgvosjQtYPWFzcDNr in kdVapybKnRfLuAgvosjQtYPWFzcDOm['subtitles']:
     if kdVapybKnRfLuAgvosjQtYPWFzcDNr.get('languagecode')=='ko':
      kdVapybKnRfLuAgvosjQtYPWFzcDNI['stream_vtt']=kdVapybKnRfLuAgvosjQtYPWFzcDNr.get('url')
      break
    if kdVapybKnRfLuAgvosjQtYPWFzcDNI['stream_vtt']=='':
     for kdVapybKnRfLuAgvosjQtYPWFzcDNr in kdVapybKnRfLuAgvosjQtYPWFzcDOm['subtitles']:
      if kdVapybKnRfLuAgvosjQtYPWFzcDNr.get('languagecode')=='ko_cc':
       kdVapybKnRfLuAgvosjQtYPWFzcDNI['stream_vtt']=kdVapybKnRfLuAgvosjQtYPWFzcDNr.get('url')
       break
   kdVapybKnRfLuAgvosjQtYPWFzcDNI['playParam']=kdVapybKnRfLuAgvosjQtYPWFzcDNJ 
  except kdVapybKnRfLuAgvosjQtYPWFzcDqB as exception:
   kdVapybKnRfLuAgvosjQtYPWFzcDBM(exception)
  return kdVapybKnRfLuAgvosjQtYPWFzcDNI 
 def GetSportsURL(kdVapybKnRfLuAgvosjQtYPWFzcDEN,kdVapybKnRfLuAgvosjQtYPWFzcDhE,quality_int):
  kdVapybKnRfLuAgvosjQtYPWFzcDNI ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  kdVapybKnRfLuAgvosjQtYPWFzcDNw=[]
  try:
   kdVapybKnRfLuAgvosjQtYPWFzcDOe=kdVapybKnRfLuAgvosjQtYPWFzcDEN.API_DOMAIN+'/streaming/other'
   kdVapybKnRfLuAgvosjQtYPWFzcDEx={'contentid':kdVapybKnRfLuAgvosjQtYPWFzcDhE,'contenttype':'live','action':kdVapybKnRfLuAgvosjQtYPWFzcDNI['stream_action'],'quality':kdVapybKnRfLuAgvosjQtYPWFzcDqE(quality_int)+'p','deviceModelId':'Windows 10','guid':kdVapybKnRfLuAgvosjQtYPWFzcDEN.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n',}
   kdVapybKnRfLuAgvosjQtYPWFzcDEx.update(kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetDefaultParams())
   kdVapybKnRfLuAgvosjQtYPWFzcDOx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.callRequestCookies('Get',kdVapybKnRfLuAgvosjQtYPWFzcDOe,payload=kdVapybKnRfLuAgvosjQtYPWFzcDBG,params=kdVapybKnRfLuAgvosjQtYPWFzcDEx,headers=kdVapybKnRfLuAgvosjQtYPWFzcDBG,cookies=kdVapybKnRfLuAgvosjQtYPWFzcDBG)
   kdVapybKnRfLuAgvosjQtYPWFzcDOm=json.loads(kdVapybKnRfLuAgvosjQtYPWFzcDOx.text)
   kdVapybKnRfLuAgvosjQtYPWFzcDNI['stream_url']=kdVapybKnRfLuAgvosjQtYPWFzcDOm['playurl']
   if kdVapybKnRfLuAgvosjQtYPWFzcDNI['stream_url']==kdVapybKnRfLuAgvosjQtYPWFzcDBG:return kdVapybKnRfLuAgvosjQtYPWFzcDNI
   kdVapybKnRfLuAgvosjQtYPWFzcDNI['stream_cookie']=kdVapybKnRfLuAgvosjQtYPWFzcDOm['awscookie']
  except kdVapybKnRfLuAgvosjQtYPWFzcDqB as exception:
   kdVapybKnRfLuAgvosjQtYPWFzcDBM(exception)
  return kdVapybKnRfLuAgvosjQtYPWFzcDNI
 def make_viewdate(kdVapybKnRfLuAgvosjQtYPWFzcDEN):
  kdVapybKnRfLuAgvosjQtYPWFzcDNT =kdVapybKnRfLuAgvosjQtYPWFzcDEN.Get_Now_Datetime()
  kdVapybKnRfLuAgvosjQtYPWFzcDNS =kdVapybKnRfLuAgvosjQtYPWFzcDNT+datetime.timedelta(days=-1)
  kdVapybKnRfLuAgvosjQtYPWFzcDNG =kdVapybKnRfLuAgvosjQtYPWFzcDNT+datetime.timedelta(days=1)
  kdVapybKnRfLuAgvosjQtYPWFzcDNH=[kdVapybKnRfLuAgvosjQtYPWFzcDNT.strftime('%Y%m%d'),kdVapybKnRfLuAgvosjQtYPWFzcDNG.strftime('%Y%m%d'),]
  return kdVapybKnRfLuAgvosjQtYPWFzcDNH
 def Get_Sports_Gamelist(kdVapybKnRfLuAgvosjQtYPWFzcDEN):
  kdVapybKnRfLuAgvosjQtYPWFzcDNM =kdVapybKnRfLuAgvosjQtYPWFzcDEN.make_viewdate()
  kdVapybKnRfLuAgvosjQtYPWFzcDBE=[]
  kdVapybKnRfLuAgvosjQtYPWFzcDBO =[]
  for kdVapybKnRfLuAgvosjQtYPWFzcDBl in kdVapybKnRfLuAgvosjQtYPWFzcDNM:
   kdVapybKnRfLuAgvosjQtYPWFzcDBh=kdVapybKnRfLuAgvosjQtYPWFzcDBl[:6]
   if kdVapybKnRfLuAgvosjQtYPWFzcDBh not in kdVapybKnRfLuAgvosjQtYPWFzcDBE:
    kdVapybKnRfLuAgvosjQtYPWFzcDBE.append(kdVapybKnRfLuAgvosjQtYPWFzcDBh)
  try:
   kdVapybKnRfLuAgvosjQtYPWFzcDOe='https://annexapi.wavve.com/skb/baseball/teammonthlycalendarlist'
   kdVapybKnRfLuAgvosjQtYPWFzcDEx={'IF':'IF-PORG-002','m':'getTeamCalendarListBand','response_format':'json','spo_itm_cd':'KBO','teamcd':'all','tgroup':'B','tvalue':'BC123','ver':'2.0',}
   kdVapybKnRfLuAgvosjQtYPWFzcDEx.update(kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetDefaultParams())
   for kdVapybKnRfLuAgvosjQtYPWFzcDBC in kdVapybKnRfLuAgvosjQtYPWFzcDBE:
    kdVapybKnRfLuAgvosjQtYPWFzcDEx['date']=kdVapybKnRfLuAgvosjQtYPWFzcDBC
    kdVapybKnRfLuAgvosjQtYPWFzcDOx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.callRequestCookies('Get',kdVapybKnRfLuAgvosjQtYPWFzcDOe,payload=kdVapybKnRfLuAgvosjQtYPWFzcDBG,params=kdVapybKnRfLuAgvosjQtYPWFzcDEx,headers=kdVapybKnRfLuAgvosjQtYPWFzcDBG,cookies=kdVapybKnRfLuAgvosjQtYPWFzcDBG)
    kdVapybKnRfLuAgvosjQtYPWFzcDOm=json.loads(kdVapybKnRfLuAgvosjQtYPWFzcDOx.text)
    kdVapybKnRfLuAgvosjQtYPWFzcDlO=kdVapybKnRfLuAgvosjQtYPWFzcDOm['cell_toplist']['celllist']
    for kdVapybKnRfLuAgvosjQtYPWFzcDlh in kdVapybKnRfLuAgvosjQtYPWFzcDlO:
     kdVapybKnRfLuAgvosjQtYPWFzcDBN=kdVapybKnRfLuAgvosjQtYPWFzcDlh.get('game_date')
     kdVapybKnRfLuAgvosjQtYPWFzcDBq =kdVapybKnRfLuAgvosjQtYPWFzcDlh.get('svc_id')
     if kdVapybKnRfLuAgvosjQtYPWFzcDBq=='':continue
     if kdVapybKnRfLuAgvosjQtYPWFzcDBN in kdVapybKnRfLuAgvosjQtYPWFzcDNM:
      kdVapybKnRfLuAgvosjQtYPWFzcDBI=kdVapybKnRfLuAgvosjQtYPWFzcDlh.get('game_status') 
      kdVapybKnRfLuAgvosjQtYPWFzcDBw =kdVapybKnRfLuAgvosjQtYPWFzcDlh.get('title_list')[0].get('text')
      kdVapybKnRfLuAgvosjQtYPWFzcDBN =kdVapybKnRfLuAgvosjQtYPWFzcDBN[:4]+'-'+kdVapybKnRfLuAgvosjQtYPWFzcDBN[4:6]+'-'+kdVapybKnRfLuAgvosjQtYPWFzcDBN[-2:]
      kdVapybKnRfLuAgvosjQtYPWFzcDBX =kdVapybKnRfLuAgvosjQtYPWFzcDlh.get('game_time')
      kdVapybKnRfLuAgvosjQtYPWFzcDBX =kdVapybKnRfLuAgvosjQtYPWFzcDBX[:2]+':'+kdVapybKnRfLuAgvosjQtYPWFzcDBX[-2:]
      kdVapybKnRfLuAgvosjQtYPWFzcDlC={'game_date':kdVapybKnRfLuAgvosjQtYPWFzcDBN,'game_time':kdVapybKnRfLuAgvosjQtYPWFzcDBX,'svc_id':kdVapybKnRfLuAgvosjQtYPWFzcDBq,'away_team':kdVapybKnRfLuAgvosjQtYPWFzcDlh.get('away_team').get('team_name'),'home_team':kdVapybKnRfLuAgvosjQtYPWFzcDlh.get('home_team').get('team_name'),'game_status':kdVapybKnRfLuAgvosjQtYPWFzcDBI,'game_place':kdVapybKnRfLuAgvosjQtYPWFzcDlh.get('game_place'),}
      kdVapybKnRfLuAgvosjQtYPWFzcDBO.append(kdVapybKnRfLuAgvosjQtYPWFzcDlC)
  except kdVapybKnRfLuAgvosjQtYPWFzcDqB as exception:
   kdVapybKnRfLuAgvosjQtYPWFzcDBM(exception)
   return[]
  kdVapybKnRfLuAgvosjQtYPWFzcDBJ=[]
  for i in kdVapybKnRfLuAgvosjQtYPWFzcDqC(2):
   for kdVapybKnRfLuAgvosjQtYPWFzcDlh in kdVapybKnRfLuAgvosjQtYPWFzcDBO:
    if i==0 and kdVapybKnRfLuAgvosjQtYPWFzcDlh.get('game_status')=='LIVE':
     kdVapybKnRfLuAgvosjQtYPWFzcDBJ.append(kdVapybKnRfLuAgvosjQtYPWFzcDlh)
    elif i==1 and kdVapybKnRfLuAgvosjQtYPWFzcDlh.get('game_status')!='LIVE':
     kdVapybKnRfLuAgvosjQtYPWFzcDBJ.append(kdVapybKnRfLuAgvosjQtYPWFzcDlh)
  return kdVapybKnRfLuAgvosjQtYPWFzcDBJ
 def GetBookmarkInfo(kdVapybKnRfLuAgvosjQtYPWFzcDEN,kdVapybKnRfLuAgvosjQtYPWFzcDli,kdVapybKnRfLuAgvosjQtYPWFzcDlm,kdVapybKnRfLuAgvosjQtYPWFzcDNX):
  if kdVapybKnRfLuAgvosjQtYPWFzcDlm=='tvshow':
   if kdVapybKnRfLuAgvosjQtYPWFzcDNX=='contentid':
    kdVapybKnRfLuAgvosjQtYPWFzcDhE=kdVapybKnRfLuAgvosjQtYPWFzcDli
    kdVapybKnRfLuAgvosjQtYPWFzcDli =kdVapybKnRfLuAgvosjQtYPWFzcDEN.ContentidToSeasonid(kdVapybKnRfLuAgvosjQtYPWFzcDhE)
   else:
    kdVapybKnRfLuAgvosjQtYPWFzcDhE=kdVapybKnRfLuAgvosjQtYPWFzcDEN.ProgramidToContentid(kdVapybKnRfLuAgvosjQtYPWFzcDli)
  else:
   kdVapybKnRfLuAgvosjQtYPWFzcDhE=''
  kdVapybKnRfLuAgvosjQtYPWFzcDBe={'indexinfo':{'ott':'wavve','videoid':kdVapybKnRfLuAgvosjQtYPWFzcDli,'vidtype':kdVapybKnRfLuAgvosjQtYPWFzcDlm,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':kdVapybKnRfLuAgvosjQtYPWFzcDlm,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if kdVapybKnRfLuAgvosjQtYPWFzcDlm=='tvshow':
   kdVapybKnRfLuAgvosjQtYPWFzcDOe=kdVapybKnRfLuAgvosjQtYPWFzcDEN.API_DOMAIN+'/fz/vod/contents/'+kdVapybKnRfLuAgvosjQtYPWFzcDhE 
   kdVapybKnRfLuAgvosjQtYPWFzcDEx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetDefaultParams()
   kdVapybKnRfLuAgvosjQtYPWFzcDOx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.callRequestCookies('Get',kdVapybKnRfLuAgvosjQtYPWFzcDOe,payload=kdVapybKnRfLuAgvosjQtYPWFzcDBG,params=kdVapybKnRfLuAgvosjQtYPWFzcDEx,headers=kdVapybKnRfLuAgvosjQtYPWFzcDBG,cookies=kdVapybKnRfLuAgvosjQtYPWFzcDBG)
   kdVapybKnRfLuAgvosjQtYPWFzcDOm=json.loads(kdVapybKnRfLuAgvosjQtYPWFzcDOx.text)
   if not('programtitle' in kdVapybKnRfLuAgvosjQtYPWFzcDOm):return{}
   kdVapybKnRfLuAgvosjQtYPWFzcDBU=kdVapybKnRfLuAgvosjQtYPWFzcDOm
   kdVapybKnRfLuAgvosjQtYPWFzcDBx=kdVapybKnRfLuAgvosjQtYPWFzcDBU.get('programtitle')
   kdVapybKnRfLuAgvosjQtYPWFzcDBe['saveinfo']['infoLabels']['title']=kdVapybKnRfLuAgvosjQtYPWFzcDBx
   if kdVapybKnRfLuAgvosjQtYPWFzcDBU.get('targetage')=='18' or kdVapybKnRfLuAgvosjQtYPWFzcDBU.get('targetage')=='19' or kdVapybKnRfLuAgvosjQtYPWFzcDBU.get('targetage')=='21':
    kdVapybKnRfLuAgvosjQtYPWFzcDBx +=u' (%s)'%(kdVapybKnRfLuAgvosjQtYPWFzcDBU.get('targetage'))
   kdVapybKnRfLuAgvosjQtYPWFzcDBe['saveinfo']['title'] =kdVapybKnRfLuAgvosjQtYPWFzcDBx
   kdVapybKnRfLuAgvosjQtYPWFzcDBe['saveinfo']['infoLabels']['mpaa'] =kdVapybKnRfLuAgvosjQtYPWFzcDBU.get('targetage')
   kdVapybKnRfLuAgvosjQtYPWFzcDBe['saveinfo']['infoLabels']['plot'] =kdVapybKnRfLuAgvosjQtYPWFzcDEN.Get_ChangeText(kdVapybKnRfLuAgvosjQtYPWFzcDBU.get('programsynopsis'))
   kdVapybKnRfLuAgvosjQtYPWFzcDBe['saveinfo']['infoLabels']['studio'] =kdVapybKnRfLuAgvosjQtYPWFzcDBU.get('channelname')
   if kdVapybKnRfLuAgvosjQtYPWFzcDBU.get('firstreleaseyear')!='':kdVapybKnRfLuAgvosjQtYPWFzcDBe['saveinfo']['infoLabels']['year'] =kdVapybKnRfLuAgvosjQtYPWFzcDBU.get('firstreleaseyear')
   if kdVapybKnRfLuAgvosjQtYPWFzcDBU.get('firstreleasedate')!='':kdVapybKnRfLuAgvosjQtYPWFzcDBe['saveinfo']['infoLabels']['premiered']=kdVapybKnRfLuAgvosjQtYPWFzcDBU.get('firstreleasedate')
   if kdVapybKnRfLuAgvosjQtYPWFzcDBU.get('genretext') !='':kdVapybKnRfLuAgvosjQtYPWFzcDBe['saveinfo']['infoLabels']['genre'] =[kdVapybKnRfLuAgvosjQtYPWFzcDBU.get('genretext')]
   kdVapybKnRfLuAgvosjQtYPWFzcDBm=[]
   for kdVapybKnRfLuAgvosjQtYPWFzcDBi in kdVapybKnRfLuAgvosjQtYPWFzcDBU['actors']['list']:kdVapybKnRfLuAgvosjQtYPWFzcDBm.append(kdVapybKnRfLuAgvosjQtYPWFzcDBi.get('text'))
   if kdVapybKnRfLuAgvosjQtYPWFzcDqN(kdVapybKnRfLuAgvosjQtYPWFzcDBm)>0:
    if kdVapybKnRfLuAgvosjQtYPWFzcDBm[0]!='':kdVapybKnRfLuAgvosjQtYPWFzcDBe['saveinfo']['infoLabels']['cast']=kdVapybKnRfLuAgvosjQtYPWFzcDBm
   kdVapybKnRfLuAgvosjQtYPWFzcDhm =''
   kdVapybKnRfLuAgvosjQtYPWFzcDhi =''
   kdVapybKnRfLuAgvosjQtYPWFzcDhr=''
   if kdVapybKnRfLuAgvosjQtYPWFzcDBU.get('programposterimage')!='':kdVapybKnRfLuAgvosjQtYPWFzcDhm =kdVapybKnRfLuAgvosjQtYPWFzcDEN.HTTPTAG+kdVapybKnRfLuAgvosjQtYPWFzcDBU.get('programposterimage')
   if kdVapybKnRfLuAgvosjQtYPWFzcDBU.get('programimage') !='':kdVapybKnRfLuAgvosjQtYPWFzcDhi =kdVapybKnRfLuAgvosjQtYPWFzcDEN.HTTPTAG+kdVapybKnRfLuAgvosjQtYPWFzcDBU.get('programimage')
   if kdVapybKnRfLuAgvosjQtYPWFzcDBU.get('programcircleimage')!='':kdVapybKnRfLuAgvosjQtYPWFzcDhr=kdVapybKnRfLuAgvosjQtYPWFzcDEN.HTTPTAG+kdVapybKnRfLuAgvosjQtYPWFzcDBU.get('programcircleimage')
   if 'poster_default' in kdVapybKnRfLuAgvosjQtYPWFzcDhm:
    kdVapybKnRfLuAgvosjQtYPWFzcDhm =kdVapybKnRfLuAgvosjQtYPWFzcDhi
    kdVapybKnRfLuAgvosjQtYPWFzcDhr=''
   kdVapybKnRfLuAgvosjQtYPWFzcDBe['saveinfo']['thumbnail']['poster']=kdVapybKnRfLuAgvosjQtYPWFzcDhm
   kdVapybKnRfLuAgvosjQtYPWFzcDBe['saveinfo']['thumbnail']['thumb']=kdVapybKnRfLuAgvosjQtYPWFzcDhi
   kdVapybKnRfLuAgvosjQtYPWFzcDBe['saveinfo']['thumbnail']['clearlogo']=kdVapybKnRfLuAgvosjQtYPWFzcDhr
   kdVapybKnRfLuAgvosjQtYPWFzcDBe['saveinfo']['thumbnail']['fanart']=kdVapybKnRfLuAgvosjQtYPWFzcDhi
  else:
   kdVapybKnRfLuAgvosjQtYPWFzcDOe=kdVapybKnRfLuAgvosjQtYPWFzcDEN.API_DOMAIN+'/movie/contents/'+kdVapybKnRfLuAgvosjQtYPWFzcDli 
   kdVapybKnRfLuAgvosjQtYPWFzcDEx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.GetDefaultParams()
   kdVapybKnRfLuAgvosjQtYPWFzcDOx=kdVapybKnRfLuAgvosjQtYPWFzcDEN.callRequestCookies('Get',kdVapybKnRfLuAgvosjQtYPWFzcDOe,payload=kdVapybKnRfLuAgvosjQtYPWFzcDBG,params=kdVapybKnRfLuAgvosjQtYPWFzcDEx,headers=kdVapybKnRfLuAgvosjQtYPWFzcDBG,cookies=kdVapybKnRfLuAgvosjQtYPWFzcDBG)
   kdVapybKnRfLuAgvosjQtYPWFzcDOm=json.loads(kdVapybKnRfLuAgvosjQtYPWFzcDOx.text)
   if not('title' in kdVapybKnRfLuAgvosjQtYPWFzcDOm):return{}
   kdVapybKnRfLuAgvosjQtYPWFzcDBU=kdVapybKnRfLuAgvosjQtYPWFzcDOm
   kdVapybKnRfLuAgvosjQtYPWFzcDBx=kdVapybKnRfLuAgvosjQtYPWFzcDBU.get('title')
   kdVapybKnRfLuAgvosjQtYPWFzcDBe['saveinfo']['infoLabels']['title']=kdVapybKnRfLuAgvosjQtYPWFzcDBx
   if kdVapybKnRfLuAgvosjQtYPWFzcDBU.get('targetage')=='18' or kdVapybKnRfLuAgvosjQtYPWFzcDBU.get('targetage')=='19' or kdVapybKnRfLuAgvosjQtYPWFzcDBU.get('targetage')=='21':
    kdVapybKnRfLuAgvosjQtYPWFzcDBx +=u' (%s)'%(kdVapybKnRfLuAgvosjQtYPWFzcDBU.get('targetage'))
   kdVapybKnRfLuAgvosjQtYPWFzcDBe['saveinfo']['title'] =kdVapybKnRfLuAgvosjQtYPWFzcDBx
   kdVapybKnRfLuAgvosjQtYPWFzcDBe['saveinfo']['infoLabels']['mpaa'] =kdVapybKnRfLuAgvosjQtYPWFzcDBU.get('targetage')
   kdVapybKnRfLuAgvosjQtYPWFzcDBe['saveinfo']['infoLabels']['plot'] =kdVapybKnRfLuAgvosjQtYPWFzcDEN.Get_ChangeText(kdVapybKnRfLuAgvosjQtYPWFzcDBU.get('synopsis'))
   kdVapybKnRfLuAgvosjQtYPWFzcDBe['saveinfo']['infoLabels']['duration']=kdVapybKnRfLuAgvosjQtYPWFzcDBU.get('playtime')
   kdVapybKnRfLuAgvosjQtYPWFzcDBe['saveinfo']['infoLabels']['country']=kdVapybKnRfLuAgvosjQtYPWFzcDBU.get('country')
   kdVapybKnRfLuAgvosjQtYPWFzcDBe['saveinfo']['infoLabels']['studio'] =kdVapybKnRfLuAgvosjQtYPWFzcDBU.get('cpname')
   if kdVapybKnRfLuAgvosjQtYPWFzcDBU.get('releasedate')!='':
    kdVapybKnRfLuAgvosjQtYPWFzcDBe['saveinfo']['infoLabels']['year'] =kdVapybKnRfLuAgvosjQtYPWFzcDBU.get('releasedate')[:4]
    kdVapybKnRfLuAgvosjQtYPWFzcDBe['saveinfo']['infoLabels']['premiered']=kdVapybKnRfLuAgvosjQtYPWFzcDBU.get('releasedate')
   kdVapybKnRfLuAgvosjQtYPWFzcDBm=[]
   for kdVapybKnRfLuAgvosjQtYPWFzcDBi in kdVapybKnRfLuAgvosjQtYPWFzcDBU['actors']['list']:kdVapybKnRfLuAgvosjQtYPWFzcDBm.append(kdVapybKnRfLuAgvosjQtYPWFzcDBi.get('text'))
   if kdVapybKnRfLuAgvosjQtYPWFzcDqN(kdVapybKnRfLuAgvosjQtYPWFzcDBm)>0:
    if kdVapybKnRfLuAgvosjQtYPWFzcDBm[0]!='':kdVapybKnRfLuAgvosjQtYPWFzcDBe['saveinfo']['infoLabels']['cast']=kdVapybKnRfLuAgvosjQtYPWFzcDBm
   kdVapybKnRfLuAgvosjQtYPWFzcDBr=[]
   for kdVapybKnRfLuAgvosjQtYPWFzcDBT in kdVapybKnRfLuAgvosjQtYPWFzcDBU['directors']['list']:kdVapybKnRfLuAgvosjQtYPWFzcDBr.append(kdVapybKnRfLuAgvosjQtYPWFzcDBT.get('text'))
   if kdVapybKnRfLuAgvosjQtYPWFzcDqN(kdVapybKnRfLuAgvosjQtYPWFzcDBr)>0:
    if kdVapybKnRfLuAgvosjQtYPWFzcDBr[0]!='':kdVapybKnRfLuAgvosjQtYPWFzcDBe['saveinfo']['infoLabels']['director']=kdVapybKnRfLuAgvosjQtYPWFzcDBr
   kdVapybKnRfLuAgvosjQtYPWFzcDOM=[]
   for kdVapybKnRfLuAgvosjQtYPWFzcDBS in kdVapybKnRfLuAgvosjQtYPWFzcDBU['genre']['list']:kdVapybKnRfLuAgvosjQtYPWFzcDOM.append(kdVapybKnRfLuAgvosjQtYPWFzcDBS.get('text'))
   if kdVapybKnRfLuAgvosjQtYPWFzcDqN(kdVapybKnRfLuAgvosjQtYPWFzcDOM)>0:
    if kdVapybKnRfLuAgvosjQtYPWFzcDOM[0]!='':kdVapybKnRfLuAgvosjQtYPWFzcDBe['saveinfo']['infoLabels']['genre']=kdVapybKnRfLuAgvosjQtYPWFzcDOM
   kdVapybKnRfLuAgvosjQtYPWFzcDhm ='https://%s'%kdVapybKnRfLuAgvosjQtYPWFzcDBU['image']
   kdVapybKnRfLuAgvosjQtYPWFzcDBe['saveinfo']['thumbnail']['poster'] =kdVapybKnRfLuAgvosjQtYPWFzcDhm
   kdVapybKnRfLuAgvosjQtYPWFzcDBe['saveinfo']['thumbnail']['thumb'] =kdVapybKnRfLuAgvosjQtYPWFzcDhm
  return kdVapybKnRfLuAgvosjQtYPWFzcDBe
# Created by pyminifier (https://github.com/liftoff/pyminifier)
