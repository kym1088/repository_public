__author__="NightRain"
bxaXHhMEKCGPTSfiqknouJOtvVBcUl=object
bxaXHhMEKCGPTSfiqknouJOtvVBcUz=None
bxaXHhMEKCGPTSfiqknouJOtvVBcUe=int
bxaXHhMEKCGPTSfiqknouJOtvVBcUw=False
bxaXHhMEKCGPTSfiqknouJOtvVBcUF=True
bxaXHhMEKCGPTSfiqknouJOtvVBcUg=type
bxaXHhMEKCGPTSfiqknouJOtvVBcUD=dict
bxaXHhMEKCGPTSfiqknouJOtvVBcUR=len
bxaXHhMEKCGPTSfiqknouJOtvVBcUN=open
bxaXHhMEKCGPTSfiqknouJOtvVBcUy=Exception
bxaXHhMEKCGPTSfiqknouJOtvVBcQr=print
bxaXHhMEKCGPTSfiqknouJOtvVBcQA=str
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
bxaXHhMEKCGPTSfiqknouJOtvVBcrs=[{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://www.wavve.com/supermultisection/GN51'},{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&offset=0&limit=20&uicode=VN500','page':'1'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=01&WeekDay=all&uitype=VN4&uiparent=FN0&uirank=0&broadcastid=847243&uicode=VN4','page':'1'},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=02&WeekDay=all&uitype=VN3&uiparent=FN0&uirank=0&broadcastid=783664&uicode=VN3','page':'1'},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'1','sType':'vod','orderby':'new','ordernm':'최신순'},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'viewtime','ordernm':'인기순'},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순'},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'paid','ordernm':'인기순'},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'displaystart','ordernm':'업데이트순'},{'title':'검색 (search)','mode':'SEARCH_GROUP'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP'}]
bxaXHhMEKCGPTSfiqknouJOtvVBcrp=[{'title':'VOD 검색','mode':'SEARCH_LIST','sType':'vod'},{'title':'영화 검색','mode':'SEARCH_LIST','sType':'movie'}]
bxaXHhMEKCGPTSfiqknouJOtvVBcrU=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
bxaXHhMEKCGPTSfiqknouJOtvVBcrQ=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
from wavveCore import*
class bxaXHhMEKCGPTSfiqknouJOtvVBcrA(bxaXHhMEKCGPTSfiqknouJOtvVBcUl):
 def __init__(bxaXHhMEKCGPTSfiqknouJOtvVBcrm,bxaXHhMEKCGPTSfiqknouJOtvVBcrj,bxaXHhMEKCGPTSfiqknouJOtvVBcrd,bxaXHhMEKCGPTSfiqknouJOtvVBcrW):
  bxaXHhMEKCGPTSfiqknouJOtvVBcrm._addon_url =bxaXHhMEKCGPTSfiqknouJOtvVBcrj
  bxaXHhMEKCGPTSfiqknouJOtvVBcrm._addon_handle=bxaXHhMEKCGPTSfiqknouJOtvVBcrd
  bxaXHhMEKCGPTSfiqknouJOtvVBcrm.main_params =bxaXHhMEKCGPTSfiqknouJOtvVBcrW
  bxaXHhMEKCGPTSfiqknouJOtvVBcrm.WavveObj =kKBJodUHvXewabhlicTxAzyYrqRSCt() 
 def addon_noti(bxaXHhMEKCGPTSfiqknouJOtvVBcrm,sting):
  try:
   bxaXHhMEKCGPTSfiqknouJOtvVBcrL=xbmcgui.Dialog()
   bxaXHhMEKCGPTSfiqknouJOtvVBcrL.notification(__addonname__,sting)
  except:
   bxaXHhMEKCGPTSfiqknouJOtvVBcUz
 def addon_log(bxaXHhMEKCGPTSfiqknouJOtvVBcrm,string):
  try:
   bxaXHhMEKCGPTSfiqknouJOtvVBcrI=string.encode('utf-8','ignore')
  except:
   bxaXHhMEKCGPTSfiqknouJOtvVBcrI='addonException: addon_log'
  bxaXHhMEKCGPTSfiqknouJOtvVBcrl=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,bxaXHhMEKCGPTSfiqknouJOtvVBcrI),level=bxaXHhMEKCGPTSfiqknouJOtvVBcrl)
 def get_keyboard_input(bxaXHhMEKCGPTSfiqknouJOtvVBcrm,bxaXHhMEKCGPTSfiqknouJOtvVBcAs):
  bxaXHhMEKCGPTSfiqknouJOtvVBcrz=bxaXHhMEKCGPTSfiqknouJOtvVBcUz
  kb=xbmc.Keyboard()
  kb.setHeading(bxaXHhMEKCGPTSfiqknouJOtvVBcAs)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   bxaXHhMEKCGPTSfiqknouJOtvVBcrz=kb.getText()
  return bxaXHhMEKCGPTSfiqknouJOtvVBcrz
 def get_settings_login_info(bxaXHhMEKCGPTSfiqknouJOtvVBcrm):
  bxaXHhMEKCGPTSfiqknouJOtvVBcre =__addon__.getSetting('id')
  bxaXHhMEKCGPTSfiqknouJOtvVBcrw =__addon__.getSetting('pw')
  bxaXHhMEKCGPTSfiqknouJOtvVBcrF=__addon__.getSetting('selected_profile')
  return(bxaXHhMEKCGPTSfiqknouJOtvVBcre,bxaXHhMEKCGPTSfiqknouJOtvVBcrw,bxaXHhMEKCGPTSfiqknouJOtvVBcrF)
 def get_selQuality(bxaXHhMEKCGPTSfiqknouJOtvVBcrm):
  try:
   bxaXHhMEKCGPTSfiqknouJOtvVBcrg=[1080,720,480,360]
   bxaXHhMEKCGPTSfiqknouJOtvVBcrD=bxaXHhMEKCGPTSfiqknouJOtvVBcUe(__addon__.getSetting('selected_quality'))
   return bxaXHhMEKCGPTSfiqknouJOtvVBcrg[bxaXHhMEKCGPTSfiqknouJOtvVBcrD]
  except:
   bxaXHhMEKCGPTSfiqknouJOtvVBcUz
  return 1080 
 def get_settings_exclusion21(bxaXHhMEKCGPTSfiqknouJOtvVBcrm):
  bxaXHhMEKCGPTSfiqknouJOtvVBcrR =__addon__.getSetting('exclusion21')
  if bxaXHhMEKCGPTSfiqknouJOtvVBcrR=='false':
   return bxaXHhMEKCGPTSfiqknouJOtvVBcUw
  else:
   return bxaXHhMEKCGPTSfiqknouJOtvVBcUF
 def get_settings_direct_replay(bxaXHhMEKCGPTSfiqknouJOtvVBcrm):
  bxaXHhMEKCGPTSfiqknouJOtvVBcrN=bxaXHhMEKCGPTSfiqknouJOtvVBcUe(__addon__.getSetting('direct_replay'))
  if bxaXHhMEKCGPTSfiqknouJOtvVBcrN==0:
   return bxaXHhMEKCGPTSfiqknouJOtvVBcUw
  else:
   return bxaXHhMEKCGPTSfiqknouJOtvVBcUF
 def set_winCredential(bxaXHhMEKCGPTSfiqknouJOtvVBcrm,credential):
  bxaXHhMEKCGPTSfiqknouJOtvVBcry=xbmcgui.Window(10000)
  bxaXHhMEKCGPTSfiqknouJOtvVBcry.setProperty('WAVVE_M_CREDENTIAL',credential)
  bxaXHhMEKCGPTSfiqknouJOtvVBcry.setProperty('WAVVE_M_LOGINTIME',bxaXHhMEKCGPTSfiqknouJOtvVBcrm.WavveObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(bxaXHhMEKCGPTSfiqknouJOtvVBcrm):
  bxaXHhMEKCGPTSfiqknouJOtvVBcry=xbmcgui.Window(10000)
  return bxaXHhMEKCGPTSfiqknouJOtvVBcry.getProperty('WAVVE_M_CREDENTIAL')
 def set_winEpisodeOrderby(bxaXHhMEKCGPTSfiqknouJOtvVBcrm,bxaXHhMEKCGPTSfiqknouJOtvVBcAF):
  bxaXHhMEKCGPTSfiqknouJOtvVBcry=xbmcgui.Window(10000)
  bxaXHhMEKCGPTSfiqknouJOtvVBcry.setProperty('WAVVE_M_ORDERBY',bxaXHhMEKCGPTSfiqknouJOtvVBcAF)
 def get_winEpisodeOrderby(bxaXHhMEKCGPTSfiqknouJOtvVBcrm):
  bxaXHhMEKCGPTSfiqknouJOtvVBcry=xbmcgui.Window(10000)
  return bxaXHhMEKCGPTSfiqknouJOtvVBcry.getProperty('WAVVE_M_ORDERBY')
 def add_dir(bxaXHhMEKCGPTSfiqknouJOtvVBcrm,label,sublabel='',img='',infoLabels=bxaXHhMEKCGPTSfiqknouJOtvVBcUz,isFolder=bxaXHhMEKCGPTSfiqknouJOtvVBcUF,params=''):
  bxaXHhMEKCGPTSfiqknouJOtvVBcAr='%s?%s'%(bxaXHhMEKCGPTSfiqknouJOtvVBcrm._addon_url,urllib.parse.urlencode(params))
  if sublabel:bxaXHhMEKCGPTSfiqknouJOtvVBcAs='%s < %s >'%(label,sublabel)
  else: bxaXHhMEKCGPTSfiqknouJOtvVBcAs=label
  if not img:img='DefaultFolder.png'
  bxaXHhMEKCGPTSfiqknouJOtvVBcAp=xbmcgui.ListItem(bxaXHhMEKCGPTSfiqknouJOtvVBcAs)
  if bxaXHhMEKCGPTSfiqknouJOtvVBcUg(img)==bxaXHhMEKCGPTSfiqknouJOtvVBcUD:
   bxaXHhMEKCGPTSfiqknouJOtvVBcAp.setArt(img)
  else:
   bxaXHhMEKCGPTSfiqknouJOtvVBcAp.setArt({'thumb':img,'poster':img})
  if infoLabels:bxaXHhMEKCGPTSfiqknouJOtvVBcAp.setInfo('Video',infoLabels)
  if not isFolder:bxaXHhMEKCGPTSfiqknouJOtvVBcAp.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(bxaXHhMEKCGPTSfiqknouJOtvVBcrm._addon_handle,bxaXHhMEKCGPTSfiqknouJOtvVBcAr,bxaXHhMEKCGPTSfiqknouJOtvVBcAp,isFolder)
 def dp_Main_List(bxaXHhMEKCGPTSfiqknouJOtvVBcrm):
  for bxaXHhMEKCGPTSfiqknouJOtvVBcAU in bxaXHhMEKCGPTSfiqknouJOtvVBcrs:
   bxaXHhMEKCGPTSfiqknouJOtvVBcAs=bxaXHhMEKCGPTSfiqknouJOtvVBcAU.get('title')
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ={'mode':bxaXHhMEKCGPTSfiqknouJOtvVBcAU.get('mode'),'sCode':bxaXHhMEKCGPTSfiqknouJOtvVBcAU.get('sCode'),'sIndex':bxaXHhMEKCGPTSfiqknouJOtvVBcAU.get('sIndex'),'sType':bxaXHhMEKCGPTSfiqknouJOtvVBcAU.get('sType'),'suburl':bxaXHhMEKCGPTSfiqknouJOtvVBcAU.get('suburl'),'subapi':bxaXHhMEKCGPTSfiqknouJOtvVBcAU.get('subapi'),'page':bxaXHhMEKCGPTSfiqknouJOtvVBcAU.get('page'),'orderby':bxaXHhMEKCGPTSfiqknouJOtvVBcAU.get('orderby'),'ordernm':bxaXHhMEKCGPTSfiqknouJOtvVBcAU.get('ordernm')}
   if bxaXHhMEKCGPTSfiqknouJOtvVBcAU.get('mode')=='XXX':
    bxaXHhMEKCGPTSfiqknouJOtvVBcAm=bxaXHhMEKCGPTSfiqknouJOtvVBcUw
   else:
    bxaXHhMEKCGPTSfiqknouJOtvVBcAm=bxaXHhMEKCGPTSfiqknouJOtvVBcUF
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.add_dir(bxaXHhMEKCGPTSfiqknouJOtvVBcAs,sublabel='',img='',infoLabels=bxaXHhMEKCGPTSfiqknouJOtvVBcUz,isFolder=bxaXHhMEKCGPTSfiqknouJOtvVBcAm,params=bxaXHhMEKCGPTSfiqknouJOtvVBcAQ)
  if bxaXHhMEKCGPTSfiqknouJOtvVBcUR(bxaXHhMEKCGPTSfiqknouJOtvVBcrs)>0:xbmcplugin.endOfDirectory(bxaXHhMEKCGPTSfiqknouJOtvVBcrm._addon_handle,cacheToDisc=bxaXHhMEKCGPTSfiqknouJOtvVBcUF)
 def dp_Search_Group(bxaXHhMEKCGPTSfiqknouJOtvVBcrm,args):
  for bxaXHhMEKCGPTSfiqknouJOtvVBcAd in bxaXHhMEKCGPTSfiqknouJOtvVBcrp:
   bxaXHhMEKCGPTSfiqknouJOtvVBcAs=bxaXHhMEKCGPTSfiqknouJOtvVBcAd.get('title')
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ={'mode':bxaXHhMEKCGPTSfiqknouJOtvVBcAd.get('mode'),'sType':bxaXHhMEKCGPTSfiqknouJOtvVBcAd.get('sType'),'page':'1'}
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.add_dir(bxaXHhMEKCGPTSfiqknouJOtvVBcAs,sublabel='',img='',infoLabels=bxaXHhMEKCGPTSfiqknouJOtvVBcUz,isFolder=bxaXHhMEKCGPTSfiqknouJOtvVBcUF,params=bxaXHhMEKCGPTSfiqknouJOtvVBcAQ)
  if bxaXHhMEKCGPTSfiqknouJOtvVBcUR(bxaXHhMEKCGPTSfiqknouJOtvVBcrp)>0:xbmcplugin.endOfDirectory(bxaXHhMEKCGPTSfiqknouJOtvVBcrm._addon_handle,cacheToDisc=bxaXHhMEKCGPTSfiqknouJOtvVBcUF)
 def dp_Watch_Group(bxaXHhMEKCGPTSfiqknouJOtvVBcrm,args):
  for bxaXHhMEKCGPTSfiqknouJOtvVBcAW in bxaXHhMEKCGPTSfiqknouJOtvVBcrU:
   bxaXHhMEKCGPTSfiqknouJOtvVBcAs=bxaXHhMEKCGPTSfiqknouJOtvVBcAW.get('title')
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ={'mode':bxaXHhMEKCGPTSfiqknouJOtvVBcAW.get('mode'),'sType':bxaXHhMEKCGPTSfiqknouJOtvVBcAW.get('sType')}
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.add_dir(bxaXHhMEKCGPTSfiqknouJOtvVBcAs,sublabel='',img='',infoLabels=bxaXHhMEKCGPTSfiqknouJOtvVBcUz,isFolder=bxaXHhMEKCGPTSfiqknouJOtvVBcUF,params=bxaXHhMEKCGPTSfiqknouJOtvVBcAQ)
  if bxaXHhMEKCGPTSfiqknouJOtvVBcUR(bxaXHhMEKCGPTSfiqknouJOtvVBcrU)>0:xbmcplugin.endOfDirectory(bxaXHhMEKCGPTSfiqknouJOtvVBcrm._addon_handle,cacheToDisc=bxaXHhMEKCGPTSfiqknouJOtvVBcUF)
 def login_main(bxaXHhMEKCGPTSfiqknouJOtvVBcrm):
  (bxaXHhMEKCGPTSfiqknouJOtvVBcAY,bxaXHhMEKCGPTSfiqknouJOtvVBcAL,bxaXHhMEKCGPTSfiqknouJOtvVBcAI)=bxaXHhMEKCGPTSfiqknouJOtvVBcrm.get_settings_login_info()
  if not(bxaXHhMEKCGPTSfiqknouJOtvVBcAY and bxaXHhMEKCGPTSfiqknouJOtvVBcAL):
   bxaXHhMEKCGPTSfiqknouJOtvVBcrL=xbmcgui.Dialog()
   bxaXHhMEKCGPTSfiqknouJOtvVBcAl=bxaXHhMEKCGPTSfiqknouJOtvVBcrL.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if bxaXHhMEKCGPTSfiqknouJOtvVBcAl==bxaXHhMEKCGPTSfiqknouJOtvVBcUF:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if bxaXHhMEKCGPTSfiqknouJOtvVBcrm.get_winEpisodeOrderby()=='':
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.set_winEpisodeOrderby('desc')
  if bxaXHhMEKCGPTSfiqknouJOtvVBcrm.cookiefile_check():return
  bxaXHhMEKCGPTSfiqknouJOtvVBcAz =bxaXHhMEKCGPTSfiqknouJOtvVBcUe(bxaXHhMEKCGPTSfiqknouJOtvVBcrm.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  bxaXHhMEKCGPTSfiqknouJOtvVBcAe=xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINTIME')
  if bxaXHhMEKCGPTSfiqknouJOtvVBcAe==bxaXHhMEKCGPTSfiqknouJOtvVBcUz or bxaXHhMEKCGPTSfiqknouJOtvVBcAe=='':
   bxaXHhMEKCGPTSfiqknouJOtvVBcAe=bxaXHhMEKCGPTSfiqknouJOtvVBcUe('19000101')
  else:
   bxaXHhMEKCGPTSfiqknouJOtvVBcAe=bxaXHhMEKCGPTSfiqknouJOtvVBcUe(re.sub('-','',bxaXHhMEKCGPTSfiqknouJOtvVBcAe))
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   bxaXHhMEKCGPTSfiqknouJOtvVBcAw=0
   while bxaXHhMEKCGPTSfiqknouJOtvVBcUF:
    bxaXHhMEKCGPTSfiqknouJOtvVBcAw+=1
    time.sleep(0.05)
    if bxaXHhMEKCGPTSfiqknouJOtvVBcAe>=bxaXHhMEKCGPTSfiqknouJOtvVBcAz:return
    if bxaXHhMEKCGPTSfiqknouJOtvVBcAw>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  if bxaXHhMEKCGPTSfiqknouJOtvVBcAe>=bxaXHhMEKCGPTSfiqknouJOtvVBcAz:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   return
  if not bxaXHhMEKCGPTSfiqknouJOtvVBcrm.WavveObj.GetCredential(bxaXHhMEKCGPTSfiqknouJOtvVBcAY,bxaXHhMEKCGPTSfiqknouJOtvVBcAL,bxaXHhMEKCGPTSfiqknouJOtvVBcAI):
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   sys.exit()
  bxaXHhMEKCGPTSfiqknouJOtvVBcrm.set_winCredential(bxaXHhMEKCGPTSfiqknouJOtvVBcrm.WavveObj.LoadCredential())
  bxaXHhMEKCGPTSfiqknouJOtvVBcrm.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
 def dp_setEpOrderby(bxaXHhMEKCGPTSfiqknouJOtvVBcrm,args):
  bxaXHhMEKCGPTSfiqknouJOtvVBcAF =args.get('orderby')
  bxaXHhMEKCGPTSfiqknouJOtvVBcrm.set_winEpisodeOrderby(bxaXHhMEKCGPTSfiqknouJOtvVBcAF)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(bxaXHhMEKCGPTSfiqknouJOtvVBcrm,args):
  bxaXHhMEKCGPTSfiqknouJOtvVBcrm.WavveObj.SaveCredential(bxaXHhMEKCGPTSfiqknouJOtvVBcrm.get_winCredential())
  bxaXHhMEKCGPTSfiqknouJOtvVBcAg =args.get('mode')
  bxaXHhMEKCGPTSfiqknouJOtvVBcAD =args.get('contentid')
  bxaXHhMEKCGPTSfiqknouJOtvVBcAR =args.get('pvrmode')
  bxaXHhMEKCGPTSfiqknouJOtvVBcAN=bxaXHhMEKCGPTSfiqknouJOtvVBcrm.get_selQuality()
  bxaXHhMEKCGPTSfiqknouJOtvVBcrm.addon_log(bxaXHhMEKCGPTSfiqknouJOtvVBcAD+' - '+bxaXHhMEKCGPTSfiqknouJOtvVBcAg)
  bxaXHhMEKCGPTSfiqknouJOtvVBcAy,bxaXHhMEKCGPTSfiqknouJOtvVBcsr,bxaXHhMEKCGPTSfiqknouJOtvVBcsA,bxaXHhMEKCGPTSfiqknouJOtvVBcsp=bxaXHhMEKCGPTSfiqknouJOtvVBcrm.WavveObj.GetStreamingURL(bxaXHhMEKCGPTSfiqknouJOtvVBcAg,bxaXHhMEKCGPTSfiqknouJOtvVBcAD,bxaXHhMEKCGPTSfiqknouJOtvVBcAN,bxaXHhMEKCGPTSfiqknouJOtvVBcAR)
  bxaXHhMEKCGPTSfiqknouJOtvVBcsU='%s|Cookie=%s'%(bxaXHhMEKCGPTSfiqknouJOtvVBcAy,bxaXHhMEKCGPTSfiqknouJOtvVBcsr)
  bxaXHhMEKCGPTSfiqknouJOtvVBcrm.addon_log(bxaXHhMEKCGPTSfiqknouJOtvVBcsU)
  if bxaXHhMEKCGPTSfiqknouJOtvVBcAy=='':
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.addon_noti(__language__(30907).encode('utf8'))
   return
  bxaXHhMEKCGPTSfiqknouJOtvVBcsQ=xbmcgui.ListItem(path=bxaXHhMEKCGPTSfiqknouJOtvVBcsU)
  if bxaXHhMEKCGPTSfiqknouJOtvVBcsA:
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.addon_log('!!streaming_drm!!')
   bxaXHhMEKCGPTSfiqknouJOtvVBcsm=bxaXHhMEKCGPTSfiqknouJOtvVBcsA['customdata']
   bxaXHhMEKCGPTSfiqknouJOtvVBcsj =bxaXHhMEKCGPTSfiqknouJOtvVBcsA['drmhost']
   bxaXHhMEKCGPTSfiqknouJOtvVBcsd =inputstreamhelper.Helper('mpd',drm='widevine')
   if bxaXHhMEKCGPTSfiqknouJOtvVBcsd.check_inputstream():
    if bxaXHhMEKCGPTSfiqknouJOtvVBcAg=='MOVIE':
     bxaXHhMEKCGPTSfiqknouJOtvVBcsW='https://www.wavve.com/player/movie?movieid=%s'%bxaXHhMEKCGPTSfiqknouJOtvVBcAD
    else:
     bxaXHhMEKCGPTSfiqknouJOtvVBcsW='https://www.wavve.com/player/vod?programid=%s&page=1'%bxaXHhMEKCGPTSfiqknouJOtvVBcAD
    bxaXHhMEKCGPTSfiqknouJOtvVBcsY={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':bxaXHhMEKCGPTSfiqknouJOtvVBcsm,'referer':bxaXHhMEKCGPTSfiqknouJOtvVBcsW,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':bxaXHhMEKCGPTSfiqknouJOtvVBcrm.WavveObj.USER_AGENT}
    bxaXHhMEKCGPTSfiqknouJOtvVBcsL=bxaXHhMEKCGPTSfiqknouJOtvVBcsj+'|'+urllib.parse.urlencode(bxaXHhMEKCGPTSfiqknouJOtvVBcsY)+'|R{SSM}|'
    bxaXHhMEKCGPTSfiqknouJOtvVBcsQ.setProperty('inputstream',bxaXHhMEKCGPTSfiqknouJOtvVBcsd.inputstream_addon)
    bxaXHhMEKCGPTSfiqknouJOtvVBcsQ.setProperty('inputstream.adaptive.manifest_type','mpd')
    bxaXHhMEKCGPTSfiqknouJOtvVBcsQ.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    bxaXHhMEKCGPTSfiqknouJOtvVBcsQ.setProperty('inputstream.adaptive.license_key',bxaXHhMEKCGPTSfiqknouJOtvVBcsL)
    bxaXHhMEKCGPTSfiqknouJOtvVBcsQ.setProperty('inputstream.adaptive.stream_headers','user-agent=%s&Cookie=%s'%(bxaXHhMEKCGPTSfiqknouJOtvVBcrm.WavveObj.USER_AGENT,bxaXHhMEKCGPTSfiqknouJOtvVBcsr))
  xbmcplugin.setResolvedUrl(bxaXHhMEKCGPTSfiqknouJOtvVBcrm._addon_handle,bxaXHhMEKCGPTSfiqknouJOtvVBcUF,bxaXHhMEKCGPTSfiqknouJOtvVBcsQ)
  bxaXHhMEKCGPTSfiqknouJOtvVBcsI=bxaXHhMEKCGPTSfiqknouJOtvVBcUw
  if bxaXHhMEKCGPTSfiqknouJOtvVBcsp:
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.addon_noti(bxaXHhMEKCGPTSfiqknouJOtvVBcsp.encode('utf-8'))
   bxaXHhMEKCGPTSfiqknouJOtvVBcsI=bxaXHhMEKCGPTSfiqknouJOtvVBcUF
  else:
   if '/preview.' in urllib.parse.urlsplit(bxaXHhMEKCGPTSfiqknouJOtvVBcAy).path:
    bxaXHhMEKCGPTSfiqknouJOtvVBcrm.addon_noti(__language__(30908).encode('utf8'))
    bxaXHhMEKCGPTSfiqknouJOtvVBcsI=bxaXHhMEKCGPTSfiqknouJOtvVBcUF
  try:
   bxaXHhMEKCGPTSfiqknouJOtvVBcsl=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and bxaXHhMEKCGPTSfiqknouJOtvVBcsI==bxaXHhMEKCGPTSfiqknouJOtvVBcUw and bxaXHhMEKCGPTSfiqknouJOtvVBcsl!='-':
    bxaXHhMEKCGPTSfiqknouJOtvVBcAQ={'code':bxaXHhMEKCGPTSfiqknouJOtvVBcsl,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    bxaXHhMEKCGPTSfiqknouJOtvVBcrm.Save_Watched_List(args.get('mode').lower(),bxaXHhMEKCGPTSfiqknouJOtvVBcAQ)
  except:
   bxaXHhMEKCGPTSfiqknouJOtvVBcUz
 def Load_Watched_List(bxaXHhMEKCGPTSfiqknouJOtvVBcrm,bxaXHhMEKCGPTSfiqknouJOtvVBcUj):
  try:
   bxaXHhMEKCGPTSfiqknouJOtvVBcsz=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%bxaXHhMEKCGPTSfiqknouJOtvVBcUj))
   fp=bxaXHhMEKCGPTSfiqknouJOtvVBcUN(bxaXHhMEKCGPTSfiqknouJOtvVBcsz,'r',-1,'utf-8')
   bxaXHhMEKCGPTSfiqknouJOtvVBcse=fp.readlines()
   fp.close()
  except:
   bxaXHhMEKCGPTSfiqknouJOtvVBcse=[]
  return bxaXHhMEKCGPTSfiqknouJOtvVBcse
 def Save_Watched_List(bxaXHhMEKCGPTSfiqknouJOtvVBcrm,bxaXHhMEKCGPTSfiqknouJOtvVBcUj,bxaXHhMEKCGPTSfiqknouJOtvVBcrW):
  try:
   bxaXHhMEKCGPTSfiqknouJOtvVBcsz=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%bxaXHhMEKCGPTSfiqknouJOtvVBcUj))
   bxaXHhMEKCGPTSfiqknouJOtvVBcsw=bxaXHhMEKCGPTSfiqknouJOtvVBcrm.Load_Watched_List(bxaXHhMEKCGPTSfiqknouJOtvVBcUj) 
   fp=bxaXHhMEKCGPTSfiqknouJOtvVBcUN(bxaXHhMEKCGPTSfiqknouJOtvVBcsz,'w',-1,'utf-8')
   bxaXHhMEKCGPTSfiqknouJOtvVBcsF=urllib.parse.urlencode(bxaXHhMEKCGPTSfiqknouJOtvVBcrW)
   bxaXHhMEKCGPTSfiqknouJOtvVBcsF=bxaXHhMEKCGPTSfiqknouJOtvVBcsF+'\n'
   fp.write(bxaXHhMEKCGPTSfiqknouJOtvVBcsF)
   bxaXHhMEKCGPTSfiqknouJOtvVBcsg=0
   for bxaXHhMEKCGPTSfiqknouJOtvVBcsD in bxaXHhMEKCGPTSfiqknouJOtvVBcsw:
    bxaXHhMEKCGPTSfiqknouJOtvVBcsR=bxaXHhMEKCGPTSfiqknouJOtvVBcUD(urllib.parse.parse_qsl(bxaXHhMEKCGPTSfiqknouJOtvVBcsD))
    bxaXHhMEKCGPTSfiqknouJOtvVBcsN=bxaXHhMEKCGPTSfiqknouJOtvVBcrW.get('code').strip()
    bxaXHhMEKCGPTSfiqknouJOtvVBcsy=bxaXHhMEKCGPTSfiqknouJOtvVBcsR.get('code').strip()
    if bxaXHhMEKCGPTSfiqknouJOtvVBcUj=='vod' and bxaXHhMEKCGPTSfiqknouJOtvVBcrm.get_settings_direct_replay()==bxaXHhMEKCGPTSfiqknouJOtvVBcUF:
     bxaXHhMEKCGPTSfiqknouJOtvVBcsN=bxaXHhMEKCGPTSfiqknouJOtvVBcrW.get('videoid').strip()
     bxaXHhMEKCGPTSfiqknouJOtvVBcsy=bxaXHhMEKCGPTSfiqknouJOtvVBcsR.get('videoid').strip()if bxaXHhMEKCGPTSfiqknouJOtvVBcsy!=bxaXHhMEKCGPTSfiqknouJOtvVBcUz else '-'
    if bxaXHhMEKCGPTSfiqknouJOtvVBcsN!=bxaXHhMEKCGPTSfiqknouJOtvVBcsy:
     fp.write(bxaXHhMEKCGPTSfiqknouJOtvVBcsD)
     bxaXHhMEKCGPTSfiqknouJOtvVBcsg+=1
     if bxaXHhMEKCGPTSfiqknouJOtvVBcsg>=50:break
   fp.close()
  except:
   bxaXHhMEKCGPTSfiqknouJOtvVBcUz
 def Delete_Watched_List(bxaXHhMEKCGPTSfiqknouJOtvVBcrm,bxaXHhMEKCGPTSfiqknouJOtvVBcUj):
  try:
   bxaXHhMEKCGPTSfiqknouJOtvVBcsz=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%bxaXHhMEKCGPTSfiqknouJOtvVBcUj))
   fp=bxaXHhMEKCGPTSfiqknouJOtvVBcUN(bxaXHhMEKCGPTSfiqknouJOtvVBcsz,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   bxaXHhMEKCGPTSfiqknouJOtvVBcUz
 def dp_WatchList_Delete(bxaXHhMEKCGPTSfiqknouJOtvVBcrm,args):
  bxaXHhMEKCGPTSfiqknouJOtvVBcpr=args.get('sType')
  bxaXHhMEKCGPTSfiqknouJOtvVBcrL=xbmcgui.Dialog()
  bxaXHhMEKCGPTSfiqknouJOtvVBcAl=bxaXHhMEKCGPTSfiqknouJOtvVBcrL.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if bxaXHhMEKCGPTSfiqknouJOtvVBcAl==bxaXHhMEKCGPTSfiqknouJOtvVBcUw:sys.exit()
  bxaXHhMEKCGPTSfiqknouJOtvVBcrm.Delete_Watched_List(bxaXHhMEKCGPTSfiqknouJOtvVBcpr)
  xbmc.executebuiltin("Container.Refresh")
 def logout(bxaXHhMEKCGPTSfiqknouJOtvVBcrm):
  bxaXHhMEKCGPTSfiqknouJOtvVBcrL=xbmcgui.Dialog()
  bxaXHhMEKCGPTSfiqknouJOtvVBcAl=bxaXHhMEKCGPTSfiqknouJOtvVBcrL.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if bxaXHhMEKCGPTSfiqknouJOtvVBcAl==bxaXHhMEKCGPTSfiqknouJOtvVBcUw:sys.exit()
  bxaXHhMEKCGPTSfiqknouJOtvVBcrm.wininfo_clear()
  if os.path.isfile(bxaXHhMEKCGPTSfiqknouJOtvVBcrQ):os.remove(bxaXHhMEKCGPTSfiqknouJOtvVBcrQ)
  bxaXHhMEKCGPTSfiqknouJOtvVBcrm.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(bxaXHhMEKCGPTSfiqknouJOtvVBcrm):
  bxaXHhMEKCGPTSfiqknouJOtvVBcry=xbmcgui.Window(10000)
  bxaXHhMEKCGPTSfiqknouJOtvVBcry.setProperty('WAVVE_M_CREDENTIAL','')
  bxaXHhMEKCGPTSfiqknouJOtvVBcry.setProperty('WAVVE_M_LOGINTIME','')
 def cookiefile_save(bxaXHhMEKCGPTSfiqknouJOtvVBcrm):
  bxaXHhMEKCGPTSfiqknouJOtvVBcpA =bxaXHhMEKCGPTSfiqknouJOtvVBcrm.WavveObj.Get_Now_Datetime()
  bxaXHhMEKCGPTSfiqknouJOtvVBcps=bxaXHhMEKCGPTSfiqknouJOtvVBcpA+datetime.timedelta(days=bxaXHhMEKCGPTSfiqknouJOtvVBcUe(__addon__.getSetting('cache_ttl')))
  bxaXHhMEKCGPTSfiqknouJOtvVBcry=xbmcgui.Window(10000)
  bxaXHhMEKCGPTSfiqknouJOtvVBcpU={'wavve_token':bxaXHhMEKCGPTSfiqknouJOtvVBcry.getProperty('WAVVE_M_CREDENTIAL'),'wavve_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'wavve_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'wavve_profile':__addon__.getSetting('selected_profile'),'wavve_limitdate':bxaXHhMEKCGPTSfiqknouJOtvVBcps.strftime('%Y-%m-%d')}
  try: 
   fp=bxaXHhMEKCGPTSfiqknouJOtvVBcUN(bxaXHhMEKCGPTSfiqknouJOtvVBcrQ,'w',-1,'utf-8')
   json.dump(bxaXHhMEKCGPTSfiqknouJOtvVBcpU,fp)
   fp.close()
  except bxaXHhMEKCGPTSfiqknouJOtvVBcUy as exception:
   bxaXHhMEKCGPTSfiqknouJOtvVBcQr(exception)
 def cookiefile_check(bxaXHhMEKCGPTSfiqknouJOtvVBcrm):
  bxaXHhMEKCGPTSfiqknouJOtvVBcpU={}
  try: 
   fp=bxaXHhMEKCGPTSfiqknouJOtvVBcUN(bxaXHhMEKCGPTSfiqknouJOtvVBcrQ,'r',-1,'utf-8')
   bxaXHhMEKCGPTSfiqknouJOtvVBcpU= json.load(fp)
   fp.close()
  except bxaXHhMEKCGPTSfiqknouJOtvVBcUy as exception:
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.wininfo_clear()
   return bxaXHhMEKCGPTSfiqknouJOtvVBcUw
  bxaXHhMEKCGPTSfiqknouJOtvVBcAY =__addon__.getSetting('id')
  bxaXHhMEKCGPTSfiqknouJOtvVBcAL =__addon__.getSetting('pw')
  bxaXHhMEKCGPTSfiqknouJOtvVBcpQ =__addon__.getSetting('selected_profile')
  bxaXHhMEKCGPTSfiqknouJOtvVBcpU['wavve_id']=base64.standard_b64decode(bxaXHhMEKCGPTSfiqknouJOtvVBcpU['wavve_id']).decode('utf-8')
  bxaXHhMEKCGPTSfiqknouJOtvVBcpU['wavve_pw']=base64.standard_b64decode(bxaXHhMEKCGPTSfiqknouJOtvVBcpU['wavve_pw']).decode('utf-8')
  if bxaXHhMEKCGPTSfiqknouJOtvVBcAY!=bxaXHhMEKCGPTSfiqknouJOtvVBcpU['wavve_id']or bxaXHhMEKCGPTSfiqknouJOtvVBcAL!=bxaXHhMEKCGPTSfiqknouJOtvVBcpU['wavve_pw']or bxaXHhMEKCGPTSfiqknouJOtvVBcpQ!=bxaXHhMEKCGPTSfiqknouJOtvVBcpU['wavve_profile']:
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.wininfo_clear()
   return bxaXHhMEKCGPTSfiqknouJOtvVBcUw
  bxaXHhMEKCGPTSfiqknouJOtvVBcAz =bxaXHhMEKCGPTSfiqknouJOtvVBcUe(bxaXHhMEKCGPTSfiqknouJOtvVBcrm.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  bxaXHhMEKCGPTSfiqknouJOtvVBcpm=bxaXHhMEKCGPTSfiqknouJOtvVBcpU['wavve_limitdate']
  bxaXHhMEKCGPTSfiqknouJOtvVBcAe =bxaXHhMEKCGPTSfiqknouJOtvVBcUe(re.sub('-','',bxaXHhMEKCGPTSfiqknouJOtvVBcpm))
  if bxaXHhMEKCGPTSfiqknouJOtvVBcAe<bxaXHhMEKCGPTSfiqknouJOtvVBcAz:
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.wininfo_clear()
   return bxaXHhMEKCGPTSfiqknouJOtvVBcUw
  bxaXHhMEKCGPTSfiqknouJOtvVBcry=xbmcgui.Window(10000)
  bxaXHhMEKCGPTSfiqknouJOtvVBcry.setProperty('WAVVE_M_CREDENTIAL',bxaXHhMEKCGPTSfiqknouJOtvVBcpU['wavve_token'])
  bxaXHhMEKCGPTSfiqknouJOtvVBcry.setProperty('WAVVE_M_LOGINTIME',bxaXHhMEKCGPTSfiqknouJOtvVBcpm)
  return bxaXHhMEKCGPTSfiqknouJOtvVBcUF
 def dp_LiveCatagory_List(bxaXHhMEKCGPTSfiqknouJOtvVBcrm,args):
  bxaXHhMEKCGPTSfiqknouJOtvVBcrm.WavveObj.SaveCredential(bxaXHhMEKCGPTSfiqknouJOtvVBcrm.get_winCredential())
  bxaXHhMEKCGPTSfiqknouJOtvVBcpj =args.get('sCode')
  bxaXHhMEKCGPTSfiqknouJOtvVBcpd=args.get('sIndex')
  bxaXHhMEKCGPTSfiqknouJOtvVBcpW,bxaXHhMEKCGPTSfiqknouJOtvVBcpY=bxaXHhMEKCGPTSfiqknouJOtvVBcrm.WavveObj.Get_LiveCatagory_List(bxaXHhMEKCGPTSfiqknouJOtvVBcpj,bxaXHhMEKCGPTSfiqknouJOtvVBcpd)
  for bxaXHhMEKCGPTSfiqknouJOtvVBcpL in bxaXHhMEKCGPTSfiqknouJOtvVBcpW:
   bxaXHhMEKCGPTSfiqknouJOtvVBcAs =bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('title')
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ={'mode':'LIVE_LIST','genre':bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('genre'),'baseapi':bxaXHhMEKCGPTSfiqknouJOtvVBcpY}
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.add_dir(bxaXHhMEKCGPTSfiqknouJOtvVBcAs,sublabel='',img='',infoLabels=bxaXHhMEKCGPTSfiqknouJOtvVBcUz,isFolder=bxaXHhMEKCGPTSfiqknouJOtvVBcUF,params=bxaXHhMEKCGPTSfiqknouJOtvVBcAQ)
  if bxaXHhMEKCGPTSfiqknouJOtvVBcUR(bxaXHhMEKCGPTSfiqknouJOtvVBcpW)>0:xbmcplugin.endOfDirectory(bxaXHhMEKCGPTSfiqknouJOtvVBcrm._addon_handle,cacheToDisc=bxaXHhMEKCGPTSfiqknouJOtvVBcUw)
 def dp_MainCatagory_List(bxaXHhMEKCGPTSfiqknouJOtvVBcrm,args):
  bxaXHhMEKCGPTSfiqknouJOtvVBcrm.WavveObj.SaveCredential(bxaXHhMEKCGPTSfiqknouJOtvVBcrm.get_winCredential())
  bxaXHhMEKCGPTSfiqknouJOtvVBcpj =args.get('sCode')
  bxaXHhMEKCGPTSfiqknouJOtvVBcpd=args.get('sIndex')
  bxaXHhMEKCGPTSfiqknouJOtvVBcpr =args.get('sType')
  bxaXHhMEKCGPTSfiqknouJOtvVBcpW=bxaXHhMEKCGPTSfiqknouJOtvVBcrm.WavveObj.Get_MainCatagory_List(bxaXHhMEKCGPTSfiqknouJOtvVBcpj,bxaXHhMEKCGPTSfiqknouJOtvVBcpd)
  for bxaXHhMEKCGPTSfiqknouJOtvVBcpL in bxaXHhMEKCGPTSfiqknouJOtvVBcpW:
   if bxaXHhMEKCGPTSfiqknouJOtvVBcpr=='vod':
    if bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('subtype')=='catagory':
     bxaXHhMEKCGPTSfiqknouJOtvVBcAg='PROGRAM_LIST'
    else:
     bxaXHhMEKCGPTSfiqknouJOtvVBcAg='SUPERSECTION_LIST'
   elif bxaXHhMEKCGPTSfiqknouJOtvVBcpr=='movie':
    bxaXHhMEKCGPTSfiqknouJOtvVBcAg='MOVIE_LIST'
   else:
    bxaXHhMEKCGPTSfiqknouJOtvVBcAg=''
   bxaXHhMEKCGPTSfiqknouJOtvVBcAs='%s (%s)'%(bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('title'),args.get('ordernm'))
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ={'mode':bxaXHhMEKCGPTSfiqknouJOtvVBcAg,'suburl':bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('suburl'),'subapi':bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if bxaXHhMEKCGPTSfiqknouJOtvVBcrm.get_settings_exclusion21():
    if bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('title')=='성인' or bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('title')=='성인+':continue
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.add_dir(bxaXHhMEKCGPTSfiqknouJOtvVBcAs,sublabel='',img='',infoLabels=bxaXHhMEKCGPTSfiqknouJOtvVBcUz,isFolder=bxaXHhMEKCGPTSfiqknouJOtvVBcUF,params=bxaXHhMEKCGPTSfiqknouJOtvVBcAQ)
  if bxaXHhMEKCGPTSfiqknouJOtvVBcUR(bxaXHhMEKCGPTSfiqknouJOtvVBcpW)>0:xbmcplugin.endOfDirectory(bxaXHhMEKCGPTSfiqknouJOtvVBcrm._addon_handle,cacheToDisc=bxaXHhMEKCGPTSfiqknouJOtvVBcUw)
 def dp_Program_List(bxaXHhMEKCGPTSfiqknouJOtvVBcrm,args):
  bxaXHhMEKCGPTSfiqknouJOtvVBcrm.WavveObj.SaveCredential(bxaXHhMEKCGPTSfiqknouJOtvVBcrm.get_winCredential())
  bxaXHhMEKCGPTSfiqknouJOtvVBcpI =args.get('subapi')
  bxaXHhMEKCGPTSfiqknouJOtvVBcpl=bxaXHhMEKCGPTSfiqknouJOtvVBcUe(args.get('page'))
  bxaXHhMEKCGPTSfiqknouJOtvVBcAF =args.get('orderby')
  bxaXHhMEKCGPTSfiqknouJOtvVBcpW,bxaXHhMEKCGPTSfiqknouJOtvVBcpz=bxaXHhMEKCGPTSfiqknouJOtvVBcrm.WavveObj.Get_Program_List(bxaXHhMEKCGPTSfiqknouJOtvVBcpI,bxaXHhMEKCGPTSfiqknouJOtvVBcpl,bxaXHhMEKCGPTSfiqknouJOtvVBcAF)
  for bxaXHhMEKCGPTSfiqknouJOtvVBcpL in bxaXHhMEKCGPTSfiqknouJOtvVBcpW:
   bxaXHhMEKCGPTSfiqknouJOtvVBcAs =bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('title')
   bxaXHhMEKCGPTSfiqknouJOtvVBcpe=bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('thumbnail')
   bxaXHhMEKCGPTSfiqknouJOtvVBcpw =bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('age')
   if bxaXHhMEKCGPTSfiqknouJOtvVBcpw=='18' or bxaXHhMEKCGPTSfiqknouJOtvVBcpw=='19' or bxaXHhMEKCGPTSfiqknouJOtvVBcpw=='21':bxaXHhMEKCGPTSfiqknouJOtvVBcAs+=' (%s)'%(bxaXHhMEKCGPTSfiqknouJOtvVBcpw)
   bxaXHhMEKCGPTSfiqknouJOtvVBcpF={'plot':bxaXHhMEKCGPTSfiqknouJOtvVBcAs,'mpaa':bxaXHhMEKCGPTSfiqknouJOtvVBcpw,'mediatype':'tvshow'}
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ={'mode':'EPISODE_LIST','videoid':bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('videoid'),'vidtype':bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('vidtype'),'page':'1'}
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.add_dir(bxaXHhMEKCGPTSfiqknouJOtvVBcAs,sublabel='',img=bxaXHhMEKCGPTSfiqknouJOtvVBcpe,infoLabels=bxaXHhMEKCGPTSfiqknouJOtvVBcpF,isFolder=bxaXHhMEKCGPTSfiqknouJOtvVBcUF,params=bxaXHhMEKCGPTSfiqknouJOtvVBcAQ)
  if bxaXHhMEKCGPTSfiqknouJOtvVBcpz:
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ={}
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ['mode'] ='PROGRAM_LIST' 
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ['subapi']=bxaXHhMEKCGPTSfiqknouJOtvVBcpI 
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ['page'] =bxaXHhMEKCGPTSfiqknouJOtvVBcQA(bxaXHhMEKCGPTSfiqknouJOtvVBcpl+1)
   bxaXHhMEKCGPTSfiqknouJOtvVBcAs='[B]%s >>[/B]'%'다음 페이지'
   bxaXHhMEKCGPTSfiqknouJOtvVBcpg=bxaXHhMEKCGPTSfiqknouJOtvVBcQA(bxaXHhMEKCGPTSfiqknouJOtvVBcpl+1)
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.add_dir(bxaXHhMEKCGPTSfiqknouJOtvVBcAs,sublabel=bxaXHhMEKCGPTSfiqknouJOtvVBcpg,img='',infoLabels=bxaXHhMEKCGPTSfiqknouJOtvVBcUz,isFolder=bxaXHhMEKCGPTSfiqknouJOtvVBcUF,params=bxaXHhMEKCGPTSfiqknouJOtvVBcAQ)
  if bxaXHhMEKCGPTSfiqknouJOtvVBcUR(bxaXHhMEKCGPTSfiqknouJOtvVBcpW)>0:xbmcplugin.endOfDirectory(bxaXHhMEKCGPTSfiqknouJOtvVBcrm._addon_handle,cacheToDisc=bxaXHhMEKCGPTSfiqknouJOtvVBcUw)
 def dp_SuperSection_List(bxaXHhMEKCGPTSfiqknouJOtvVBcrm,args):
  bxaXHhMEKCGPTSfiqknouJOtvVBcrm.WavveObj.SaveCredential(bxaXHhMEKCGPTSfiqknouJOtvVBcrm.get_winCredential())
  bxaXHhMEKCGPTSfiqknouJOtvVBcpD =args.get('suburl')
  bxaXHhMEKCGPTSfiqknouJOtvVBcpW=bxaXHhMEKCGPTSfiqknouJOtvVBcrm.WavveObj.Get_SuperMultiSection_List(bxaXHhMEKCGPTSfiqknouJOtvVBcpD)
  for bxaXHhMEKCGPTSfiqknouJOtvVBcpL in bxaXHhMEKCGPTSfiqknouJOtvVBcpW:
   bxaXHhMEKCGPTSfiqknouJOtvVBcAs =bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('title')
   bxaXHhMEKCGPTSfiqknouJOtvVBcpI =bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('subapi')
   bxaXHhMEKCGPTSfiqknouJOtvVBcpR=bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('cell_type')
   if bxaXHhMEKCGPTSfiqknouJOtvVBcpI.find('mtype=svod')>=0 or bxaXHhMEKCGPTSfiqknouJOtvVBcpI.find('mtype=ppv')>=0:
    bxaXHhMEKCGPTSfiqknouJOtvVBcAg='MOVIE_LIST'
   elif bxaXHhMEKCGPTSfiqknouJOtvVBcpR=='band_71':
    bxaXHhMEKCGPTSfiqknouJOtvVBcAg ='SUPERSECTION_LIST'
    (bxaXHhMEKCGPTSfiqknouJOtvVBcpN,bxaXHhMEKCGPTSfiqknouJOtvVBcpy)=bxaXHhMEKCGPTSfiqknouJOtvVBcrm.WavveObj.Baseapi_Parse(bxaXHhMEKCGPTSfiqknouJOtvVBcpI)
    bxaXHhMEKCGPTSfiqknouJOtvVBcpD=bxaXHhMEKCGPTSfiqknouJOtvVBcpy.get('api')
    bxaXHhMEKCGPTSfiqknouJOtvVBcpI=''
   elif bxaXHhMEKCGPTSfiqknouJOtvVBcpR=='band_2':
    bxaXHhMEKCGPTSfiqknouJOtvVBcAg='BAND2SECTION_LIST'
   elif bxaXHhMEKCGPTSfiqknouJOtvVBcpR=='band_live':
    bxaXHhMEKCGPTSfiqknouJOtvVBcAg='BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}',bxaXHhMEKCGPTSfiqknouJOtvVBcpI):
    bxaXHhMEKCGPTSfiqknouJOtvVBcAg='MOVIE_LIST'
   else:
    bxaXHhMEKCGPTSfiqknouJOtvVBcAg='PROGRAM_LIST'
   bxaXHhMEKCGPTSfiqknouJOtvVBcpF={'plot':bxaXHhMEKCGPTSfiqknouJOtvVBcAs,'mediatype':'tvshow'}
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ={'mode':bxaXHhMEKCGPTSfiqknouJOtvVBcAg,'suburl':bxaXHhMEKCGPTSfiqknouJOtvVBcpD,'subapi':bxaXHhMEKCGPTSfiqknouJOtvVBcpI,'page':'1'}
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.add_dir(bxaXHhMEKCGPTSfiqknouJOtvVBcAs,sublabel='',img=bxaXHhMEKCGPTSfiqknouJOtvVBcUz,infoLabels=bxaXHhMEKCGPTSfiqknouJOtvVBcpF,isFolder=bxaXHhMEKCGPTSfiqknouJOtvVBcUF,params=bxaXHhMEKCGPTSfiqknouJOtvVBcAQ)
  if bxaXHhMEKCGPTSfiqknouJOtvVBcUR(bxaXHhMEKCGPTSfiqknouJOtvVBcpW)>0:xbmcplugin.endOfDirectory(bxaXHhMEKCGPTSfiqknouJOtvVBcrm._addon_handle,cacheToDisc=bxaXHhMEKCGPTSfiqknouJOtvVBcUw)
 def dp_BandLiveSection_List(bxaXHhMEKCGPTSfiqknouJOtvVBcrm,args):
  bxaXHhMEKCGPTSfiqknouJOtvVBcrm.WavveObj.SaveCredential(bxaXHhMEKCGPTSfiqknouJOtvVBcrm.get_winCredential())
  bxaXHhMEKCGPTSfiqknouJOtvVBcpI =args.get('subapi')
  bxaXHhMEKCGPTSfiqknouJOtvVBcpl=bxaXHhMEKCGPTSfiqknouJOtvVBcUe(args.get('page'))
  bxaXHhMEKCGPTSfiqknouJOtvVBcpW,bxaXHhMEKCGPTSfiqknouJOtvVBcpz=bxaXHhMEKCGPTSfiqknouJOtvVBcrm.WavveObj.Get_BandLiveSection_List(bxaXHhMEKCGPTSfiqknouJOtvVBcpI,bxaXHhMEKCGPTSfiqknouJOtvVBcpl)
  for bxaXHhMEKCGPTSfiqknouJOtvVBcpL in bxaXHhMEKCGPTSfiqknouJOtvVBcpW:
   bxaXHhMEKCGPTSfiqknouJOtvVBcUr =bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('channelid')
   bxaXHhMEKCGPTSfiqknouJOtvVBcUA =bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('studio')
   bxaXHhMEKCGPTSfiqknouJOtvVBcUs=bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('tvshowtitle')
   bxaXHhMEKCGPTSfiqknouJOtvVBcpe =bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('thumbnail')
   bxaXHhMEKCGPTSfiqknouJOtvVBcpw =bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('age')
   bxaXHhMEKCGPTSfiqknouJOtvVBcpF={'mediatype':'tvshow','mpaa':bxaXHhMEKCGPTSfiqknouJOtvVBcpw,'title':'%s < %s >'%(bxaXHhMEKCGPTSfiqknouJOtvVBcUA,bxaXHhMEKCGPTSfiqknouJOtvVBcUs),'tvshowtitle':bxaXHhMEKCGPTSfiqknouJOtvVBcUs,'studio':bxaXHhMEKCGPTSfiqknouJOtvVBcUA,'plot':bxaXHhMEKCGPTSfiqknouJOtvVBcUA}
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ={'mode':'LIVE','contentid':bxaXHhMEKCGPTSfiqknouJOtvVBcUr}
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.add_dir(bxaXHhMEKCGPTSfiqknouJOtvVBcUA,sublabel=bxaXHhMEKCGPTSfiqknouJOtvVBcUs,img=bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('thumbnail'),infoLabels=bxaXHhMEKCGPTSfiqknouJOtvVBcpF,isFolder=bxaXHhMEKCGPTSfiqknouJOtvVBcUw,params=bxaXHhMEKCGPTSfiqknouJOtvVBcAQ)
  if bxaXHhMEKCGPTSfiqknouJOtvVBcpz:
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ={}
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ['mode'] ='BANDLIVESECTION_LIST' 
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ['subapi']=bxaXHhMEKCGPTSfiqknouJOtvVBcpI
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ['page'] =bxaXHhMEKCGPTSfiqknouJOtvVBcQA(bxaXHhMEKCGPTSfiqknouJOtvVBcpl+1)
   bxaXHhMEKCGPTSfiqknouJOtvVBcAs='[B]%s >>[/B]'%'다음 페이지'
   bxaXHhMEKCGPTSfiqknouJOtvVBcpg=bxaXHhMEKCGPTSfiqknouJOtvVBcQA(bxaXHhMEKCGPTSfiqknouJOtvVBcpl+1)
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.add_dir(bxaXHhMEKCGPTSfiqknouJOtvVBcAs,sublabel=bxaXHhMEKCGPTSfiqknouJOtvVBcpg,img='',infoLabels=bxaXHhMEKCGPTSfiqknouJOtvVBcUz,isFolder=bxaXHhMEKCGPTSfiqknouJOtvVBcUF,params=bxaXHhMEKCGPTSfiqknouJOtvVBcAQ)
  if bxaXHhMEKCGPTSfiqknouJOtvVBcUR(bxaXHhMEKCGPTSfiqknouJOtvVBcpW)>0:xbmcplugin.endOfDirectory(bxaXHhMEKCGPTSfiqknouJOtvVBcrm._addon_handle,cacheToDisc=bxaXHhMEKCGPTSfiqknouJOtvVBcUw)
 def dp_Band2Section_List(bxaXHhMEKCGPTSfiqknouJOtvVBcrm,args):
  bxaXHhMEKCGPTSfiqknouJOtvVBcrm.WavveObj.SaveCredential(bxaXHhMEKCGPTSfiqknouJOtvVBcrm.get_winCredential())
  bxaXHhMEKCGPTSfiqknouJOtvVBcpI =args.get('subapi')
  bxaXHhMEKCGPTSfiqknouJOtvVBcpl=bxaXHhMEKCGPTSfiqknouJOtvVBcUe(args.get('page'))
  bxaXHhMEKCGPTSfiqknouJOtvVBcpW,bxaXHhMEKCGPTSfiqknouJOtvVBcpz=bxaXHhMEKCGPTSfiqknouJOtvVBcrm.WavveObj.Get_Band2Section_List(bxaXHhMEKCGPTSfiqknouJOtvVBcpI,bxaXHhMEKCGPTSfiqknouJOtvVBcpl)
  for bxaXHhMEKCGPTSfiqknouJOtvVBcpL in bxaXHhMEKCGPTSfiqknouJOtvVBcpW:
   bxaXHhMEKCGPTSfiqknouJOtvVBcAs =bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('programtitle')
   bxaXHhMEKCGPTSfiqknouJOtvVBcpg =bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('episodetitle')
   bxaXHhMEKCGPTSfiqknouJOtvVBcpF={'plot':bxaXHhMEKCGPTSfiqknouJOtvVBcAs+'\n\n'+bxaXHhMEKCGPTSfiqknouJOtvVBcpg,'mpaa':bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('age'),'mediatype':'episode'}
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ={'mode':'VOD','programid':'-','contentid':bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('videoid'),'thumbnail':bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('thumbnail'),'title':bxaXHhMEKCGPTSfiqknouJOtvVBcAs,'subtitle':bxaXHhMEKCGPTSfiqknouJOtvVBcpg}
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.add_dir(bxaXHhMEKCGPTSfiqknouJOtvVBcAs,sublabel=bxaXHhMEKCGPTSfiqknouJOtvVBcpg,img=bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('thumbnail'),infoLabels=bxaXHhMEKCGPTSfiqknouJOtvVBcpF,isFolder=bxaXHhMEKCGPTSfiqknouJOtvVBcUw,params=bxaXHhMEKCGPTSfiqknouJOtvVBcAQ)
  if bxaXHhMEKCGPTSfiqknouJOtvVBcpz:
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ={}
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ['mode'] ='BAND2SECTION_LIST' 
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ['subapi']=bxaXHhMEKCGPTSfiqknouJOtvVBcpI
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ['page'] =bxaXHhMEKCGPTSfiqknouJOtvVBcQA(bxaXHhMEKCGPTSfiqknouJOtvVBcpl+1)
   bxaXHhMEKCGPTSfiqknouJOtvVBcAs='[B]%s >>[/B]'%'다음 페이지'
   bxaXHhMEKCGPTSfiqknouJOtvVBcpg=bxaXHhMEKCGPTSfiqknouJOtvVBcQA(bxaXHhMEKCGPTSfiqknouJOtvVBcpl+1)
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.add_dir(bxaXHhMEKCGPTSfiqknouJOtvVBcAs,sublabel=bxaXHhMEKCGPTSfiqknouJOtvVBcpg,img='',infoLabels=bxaXHhMEKCGPTSfiqknouJOtvVBcUz,isFolder=bxaXHhMEKCGPTSfiqknouJOtvVBcUF,params=bxaXHhMEKCGPTSfiqknouJOtvVBcAQ)
  if bxaXHhMEKCGPTSfiqknouJOtvVBcUR(bxaXHhMEKCGPTSfiqknouJOtvVBcpW)>0:xbmcplugin.endOfDirectory(bxaXHhMEKCGPTSfiqknouJOtvVBcrm._addon_handle,cacheToDisc=bxaXHhMEKCGPTSfiqknouJOtvVBcUw)
 def dp_Movie_List(bxaXHhMEKCGPTSfiqknouJOtvVBcrm,args):
  bxaXHhMEKCGPTSfiqknouJOtvVBcrm.WavveObj.SaveCredential(bxaXHhMEKCGPTSfiqknouJOtvVBcrm.get_winCredential())
  bxaXHhMEKCGPTSfiqknouJOtvVBcpI =args.get('subapi')
  bxaXHhMEKCGPTSfiqknouJOtvVBcpl=bxaXHhMEKCGPTSfiqknouJOtvVBcUe(args.get('page'))
  bxaXHhMEKCGPTSfiqknouJOtvVBcpW,bxaXHhMEKCGPTSfiqknouJOtvVBcpz=bxaXHhMEKCGPTSfiqknouJOtvVBcrm.WavveObj.Get_Movie_List(bxaXHhMEKCGPTSfiqknouJOtvVBcpI,bxaXHhMEKCGPTSfiqknouJOtvVBcpl)
  for bxaXHhMEKCGPTSfiqknouJOtvVBcpL in bxaXHhMEKCGPTSfiqknouJOtvVBcpW:
   bxaXHhMEKCGPTSfiqknouJOtvVBcAs =bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('title')
   bxaXHhMEKCGPTSfiqknouJOtvVBcpe=bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('thumbnail')
   bxaXHhMEKCGPTSfiqknouJOtvVBcpw =bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('age')
   if bxaXHhMEKCGPTSfiqknouJOtvVBcpw=='18' or bxaXHhMEKCGPTSfiqknouJOtvVBcpw=='19' or bxaXHhMEKCGPTSfiqknouJOtvVBcpw=='21':bxaXHhMEKCGPTSfiqknouJOtvVBcAs+=' (%s)'%(bxaXHhMEKCGPTSfiqknouJOtvVBcpw)
   bxaXHhMEKCGPTSfiqknouJOtvVBcpF={'plot':bxaXHhMEKCGPTSfiqknouJOtvVBcAs,'mpaa':bxaXHhMEKCGPTSfiqknouJOtvVBcpw,'mediatype':'movie'}
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ={'mode':'MOVIE','contentid':bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('videoid'),'title':bxaXHhMEKCGPTSfiqknouJOtvVBcAs,'thumbnail':bxaXHhMEKCGPTSfiqknouJOtvVBcpe,'age':bxaXHhMEKCGPTSfiqknouJOtvVBcpw}
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.add_dir(bxaXHhMEKCGPTSfiqknouJOtvVBcAs,sublabel='',img=bxaXHhMEKCGPTSfiqknouJOtvVBcpe,infoLabels=bxaXHhMEKCGPTSfiqknouJOtvVBcpF,isFolder=bxaXHhMEKCGPTSfiqknouJOtvVBcUw,params=bxaXHhMEKCGPTSfiqknouJOtvVBcAQ)
  if bxaXHhMEKCGPTSfiqknouJOtvVBcpz:
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ={}
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ['mode'] ='MOVIE_LIST' 
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ['subapi']=bxaXHhMEKCGPTSfiqknouJOtvVBcpI 
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ['page'] =bxaXHhMEKCGPTSfiqknouJOtvVBcQA(bxaXHhMEKCGPTSfiqknouJOtvVBcpl+1)
   bxaXHhMEKCGPTSfiqknouJOtvVBcAs='[B]%s >>[/B]'%'다음 페이지'
   bxaXHhMEKCGPTSfiqknouJOtvVBcpg=bxaXHhMEKCGPTSfiqknouJOtvVBcQA(bxaXHhMEKCGPTSfiqknouJOtvVBcpl+1)
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.add_dir(bxaXHhMEKCGPTSfiqknouJOtvVBcAs,sublabel=bxaXHhMEKCGPTSfiqknouJOtvVBcpg,img='',infoLabels=bxaXHhMEKCGPTSfiqknouJOtvVBcUz,isFolder=bxaXHhMEKCGPTSfiqknouJOtvVBcUF,params=bxaXHhMEKCGPTSfiqknouJOtvVBcAQ)
  if bxaXHhMEKCGPTSfiqknouJOtvVBcUR(bxaXHhMEKCGPTSfiqknouJOtvVBcpW)>0:xbmcplugin.endOfDirectory(bxaXHhMEKCGPTSfiqknouJOtvVBcrm._addon_handle,cacheToDisc=bxaXHhMEKCGPTSfiqknouJOtvVBcUw)
 def dp_Episode_List(bxaXHhMEKCGPTSfiqknouJOtvVBcrm,args):
  bxaXHhMEKCGPTSfiqknouJOtvVBcrm.WavveObj.SaveCredential(bxaXHhMEKCGPTSfiqknouJOtvVBcrm.get_winCredential())
  bxaXHhMEKCGPTSfiqknouJOtvVBcUp =args.get('videoid')
  bxaXHhMEKCGPTSfiqknouJOtvVBcUQ =args.get('vidtype')
  bxaXHhMEKCGPTSfiqknouJOtvVBcpl=bxaXHhMEKCGPTSfiqknouJOtvVBcUe(args.get('page'))
  bxaXHhMEKCGPTSfiqknouJOtvVBcpW,bxaXHhMEKCGPTSfiqknouJOtvVBcpz=bxaXHhMEKCGPTSfiqknouJOtvVBcrm.WavveObj.Get_Episode_List(bxaXHhMEKCGPTSfiqknouJOtvVBcUp,bxaXHhMEKCGPTSfiqknouJOtvVBcUQ,bxaXHhMEKCGPTSfiqknouJOtvVBcpl,orderby=bxaXHhMEKCGPTSfiqknouJOtvVBcrm.get_winEpisodeOrderby())
  for bxaXHhMEKCGPTSfiqknouJOtvVBcpL in bxaXHhMEKCGPTSfiqknouJOtvVBcpW:
   bxaXHhMEKCGPTSfiqknouJOtvVBcpg='%s회, %s(%s)'%(bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('episodenumber'),bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('releasedate'),bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('releaseweekday'))
   bxaXHhMEKCGPTSfiqknouJOtvVBcUm ='[%s]\n\n%s'%(bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('episodetitle'),bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('synopsis'))
   bxaXHhMEKCGPTSfiqknouJOtvVBcpF={'mediatype':'episode','title':bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('programtitle'),'year':bxaXHhMEKCGPTSfiqknouJOtvVBcUe(bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('releasedate')[:4]),'aired':bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('releasedate'),'mpaa':bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('age'),'episode':bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('episodenumber'),'duration':bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('playtime'),'plot':bxaXHhMEKCGPTSfiqknouJOtvVBcUm,'cast':bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('episodeactors')}
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ={'mode':'VOD','programid':bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('programid'),'contentid':bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('contentid'),'thumbnail':bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('thumbnail'),'title':bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('programtitle'),'subtitle':bxaXHhMEKCGPTSfiqknouJOtvVBcpg}
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.add_dir(bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('programtitle'),sublabel=bxaXHhMEKCGPTSfiqknouJOtvVBcpg,img=bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('thumbnail'),infoLabels=bxaXHhMEKCGPTSfiqknouJOtvVBcpF,isFolder=bxaXHhMEKCGPTSfiqknouJOtvVBcUw,params=bxaXHhMEKCGPTSfiqknouJOtvVBcAQ)
  if bxaXHhMEKCGPTSfiqknouJOtvVBcpl==1:
   bxaXHhMEKCGPTSfiqknouJOtvVBcpF={'plot':'정렬순서를 변경합니다.'}
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ={}
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ['mode'] ='ORDER_BY' 
   if bxaXHhMEKCGPTSfiqknouJOtvVBcrm.get_winEpisodeOrderby()=='desc':
    bxaXHhMEKCGPTSfiqknouJOtvVBcAs='정렬순서변경 : 최신화부터 -> 1회부터'
    bxaXHhMEKCGPTSfiqknouJOtvVBcAQ['orderby']='asc'
   else:
    bxaXHhMEKCGPTSfiqknouJOtvVBcAs='정렬순서변경 : 1회부터 -> 최신화부터'
    bxaXHhMEKCGPTSfiqknouJOtvVBcAQ['orderby']='desc'
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.add_dir(bxaXHhMEKCGPTSfiqknouJOtvVBcAs,sublabel='',img='',infoLabels=bxaXHhMEKCGPTSfiqknouJOtvVBcpF,isFolder=bxaXHhMEKCGPTSfiqknouJOtvVBcUw,params=bxaXHhMEKCGPTSfiqknouJOtvVBcAQ)
  if bxaXHhMEKCGPTSfiqknouJOtvVBcpz:
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ={}
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ['mode'] ='EPISODE_LIST' 
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ['videoid']=bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('programid')
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ['vidtype']='programid'
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ['page'] =bxaXHhMEKCGPTSfiqknouJOtvVBcQA(bxaXHhMEKCGPTSfiqknouJOtvVBcpl+1)
   bxaXHhMEKCGPTSfiqknouJOtvVBcAs='[B]%s >>[/B]'%'다음 페이지'
   bxaXHhMEKCGPTSfiqknouJOtvVBcpg=bxaXHhMEKCGPTSfiqknouJOtvVBcQA(bxaXHhMEKCGPTSfiqknouJOtvVBcpl+1)
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.add_dir(bxaXHhMEKCGPTSfiqknouJOtvVBcAs,sublabel=bxaXHhMEKCGPTSfiqknouJOtvVBcpg,img='',infoLabels=bxaXHhMEKCGPTSfiqknouJOtvVBcUz,isFolder=bxaXHhMEKCGPTSfiqknouJOtvVBcUF,params=bxaXHhMEKCGPTSfiqknouJOtvVBcAQ)
  if bxaXHhMEKCGPTSfiqknouJOtvVBcUR(bxaXHhMEKCGPTSfiqknouJOtvVBcpW)>0:xbmcplugin.endOfDirectory(bxaXHhMEKCGPTSfiqknouJOtvVBcrm._addon_handle,cacheToDisc=bxaXHhMEKCGPTSfiqknouJOtvVBcUw)
 def dp_LiveChannel_List(bxaXHhMEKCGPTSfiqknouJOtvVBcrm,args):
  bxaXHhMEKCGPTSfiqknouJOtvVBcrm.WavveObj.SaveCredential(bxaXHhMEKCGPTSfiqknouJOtvVBcrm.get_winCredential())
  bxaXHhMEKCGPTSfiqknouJOtvVBcUj =args.get('genre')
  bxaXHhMEKCGPTSfiqknouJOtvVBcpY=args.get('baseapi')
  bxaXHhMEKCGPTSfiqknouJOtvVBcpW=bxaXHhMEKCGPTSfiqknouJOtvVBcrm.WavveObj.Get_LiveChannel_List(bxaXHhMEKCGPTSfiqknouJOtvVBcUj,bxaXHhMEKCGPTSfiqknouJOtvVBcpY)
  for bxaXHhMEKCGPTSfiqknouJOtvVBcpL in bxaXHhMEKCGPTSfiqknouJOtvVBcpW:
   bxaXHhMEKCGPTSfiqknouJOtvVBcUr =bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('channelid')
   bxaXHhMEKCGPTSfiqknouJOtvVBcUA =bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('studio')
   bxaXHhMEKCGPTSfiqknouJOtvVBcUs=bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('tvshowtitle')
   bxaXHhMEKCGPTSfiqknouJOtvVBcpe =bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('thumbnail')
   bxaXHhMEKCGPTSfiqknouJOtvVBcpw =bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('age')
   bxaXHhMEKCGPTSfiqknouJOtvVBcUd =bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('epg')
   bxaXHhMEKCGPTSfiqknouJOtvVBcpF={'mediatype':'episode','mpaa':bxaXHhMEKCGPTSfiqknouJOtvVBcpw,'title':'%s < %s >'%(bxaXHhMEKCGPTSfiqknouJOtvVBcUA,bxaXHhMEKCGPTSfiqknouJOtvVBcUs),'tvshowtitle':bxaXHhMEKCGPTSfiqknouJOtvVBcUs,'studio':bxaXHhMEKCGPTSfiqknouJOtvVBcUA,'plot':'%s\n\n%s'%(bxaXHhMEKCGPTSfiqknouJOtvVBcUA,bxaXHhMEKCGPTSfiqknouJOtvVBcUd)}
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ={'mode':'LIVE','contentid':bxaXHhMEKCGPTSfiqknouJOtvVBcUr}
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.add_dir(bxaXHhMEKCGPTSfiqknouJOtvVBcUA,sublabel=bxaXHhMEKCGPTSfiqknouJOtvVBcUs,img=bxaXHhMEKCGPTSfiqknouJOtvVBcpe,infoLabels=bxaXHhMEKCGPTSfiqknouJOtvVBcpF,isFolder=bxaXHhMEKCGPTSfiqknouJOtvVBcUw,params=bxaXHhMEKCGPTSfiqknouJOtvVBcAQ)
  if bxaXHhMEKCGPTSfiqknouJOtvVBcUR(bxaXHhMEKCGPTSfiqknouJOtvVBcpW)>0:xbmcplugin.endOfDirectory(bxaXHhMEKCGPTSfiqknouJOtvVBcrm._addon_handle,cacheToDisc=bxaXHhMEKCGPTSfiqknouJOtvVBcUw)
 def dp_Search_List(bxaXHhMEKCGPTSfiqknouJOtvVBcrm,args):
  bxaXHhMEKCGPTSfiqknouJOtvVBcrm.WavveObj.SaveCredential(bxaXHhMEKCGPTSfiqknouJOtvVBcrm.get_winCredential())
  bxaXHhMEKCGPTSfiqknouJOtvVBcpr =args.get('sType')
  bxaXHhMEKCGPTSfiqknouJOtvVBcpl =bxaXHhMEKCGPTSfiqknouJOtvVBcUe(args.get('page'))
  if 'search_key' in args:
   bxaXHhMEKCGPTSfiqknouJOtvVBcUW=args.get('search_key')
  else:
   bxaXHhMEKCGPTSfiqknouJOtvVBcUW=bxaXHhMEKCGPTSfiqknouJOtvVBcrm.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not bxaXHhMEKCGPTSfiqknouJOtvVBcUW:return
  bxaXHhMEKCGPTSfiqknouJOtvVBcpW,bxaXHhMEKCGPTSfiqknouJOtvVBcpz=bxaXHhMEKCGPTSfiqknouJOtvVBcrm.WavveObj.Get_Search_List(bxaXHhMEKCGPTSfiqknouJOtvVBcUW,bxaXHhMEKCGPTSfiqknouJOtvVBcpr,bxaXHhMEKCGPTSfiqknouJOtvVBcpl,exclusion21=bxaXHhMEKCGPTSfiqknouJOtvVBcrm.get_settings_exclusion21())
  for bxaXHhMEKCGPTSfiqknouJOtvVBcpL in bxaXHhMEKCGPTSfiqknouJOtvVBcpW:
   bxaXHhMEKCGPTSfiqknouJOtvVBcAs =bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('title')
   bxaXHhMEKCGPTSfiqknouJOtvVBcpe=bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('thumbnail')
   bxaXHhMEKCGPTSfiqknouJOtvVBcpw =bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('age')
   if bxaXHhMEKCGPTSfiqknouJOtvVBcpw=='18' or bxaXHhMEKCGPTSfiqknouJOtvVBcpw=='19' or bxaXHhMEKCGPTSfiqknouJOtvVBcpw=='21':bxaXHhMEKCGPTSfiqknouJOtvVBcAs+=' (%s)'%(bxaXHhMEKCGPTSfiqknouJOtvVBcpw)
   bxaXHhMEKCGPTSfiqknouJOtvVBcpF={'mediatype':'tvshow' if bxaXHhMEKCGPTSfiqknouJOtvVBcpr=='vod' else 'movie','mpaa':bxaXHhMEKCGPTSfiqknouJOtvVBcpw,'title':bxaXHhMEKCGPTSfiqknouJOtvVBcAs,'plot':bxaXHhMEKCGPTSfiqknouJOtvVBcAs}
   if bxaXHhMEKCGPTSfiqknouJOtvVBcpr=='vod':
    bxaXHhMEKCGPTSfiqknouJOtvVBcAQ={'mode':'EPISODE_LIST','videoid':bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('videoid'),'vidtype':bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('vidtype'),'page':'1'}
    bxaXHhMEKCGPTSfiqknouJOtvVBcAm=bxaXHhMEKCGPTSfiqknouJOtvVBcUF
   else:
    bxaXHhMEKCGPTSfiqknouJOtvVBcAQ={'mode':'MOVIE','contentid':bxaXHhMEKCGPTSfiqknouJOtvVBcpL.get('videoid'),'title':bxaXHhMEKCGPTSfiqknouJOtvVBcAs,'thumbnail':bxaXHhMEKCGPTSfiqknouJOtvVBcpe,'age':bxaXHhMEKCGPTSfiqknouJOtvVBcpw}
    bxaXHhMEKCGPTSfiqknouJOtvVBcAm=bxaXHhMEKCGPTSfiqknouJOtvVBcUw
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.add_dir(bxaXHhMEKCGPTSfiqknouJOtvVBcAs,sublabel='',img=bxaXHhMEKCGPTSfiqknouJOtvVBcpe,infoLabels=bxaXHhMEKCGPTSfiqknouJOtvVBcpF,isFolder=bxaXHhMEKCGPTSfiqknouJOtvVBcAm,params=bxaXHhMEKCGPTSfiqknouJOtvVBcAQ)
  if bxaXHhMEKCGPTSfiqknouJOtvVBcpz:
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ['mode'] ='SEARCH_LIST' 
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ['sType']=bxaXHhMEKCGPTSfiqknouJOtvVBcpr 
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ['page'] =bxaXHhMEKCGPTSfiqknouJOtvVBcQA(bxaXHhMEKCGPTSfiqknouJOtvVBcpl+1)
   bxaXHhMEKCGPTSfiqknouJOtvVBcAQ['search_key']=bxaXHhMEKCGPTSfiqknouJOtvVBcUW
   bxaXHhMEKCGPTSfiqknouJOtvVBcAs='[B]%s >>[/B]'%'다음 페이지'
   bxaXHhMEKCGPTSfiqknouJOtvVBcpg=bxaXHhMEKCGPTSfiqknouJOtvVBcQA(bxaXHhMEKCGPTSfiqknouJOtvVBcpl+1)
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.add_dir(bxaXHhMEKCGPTSfiqknouJOtvVBcAs,sublabel=bxaXHhMEKCGPTSfiqknouJOtvVBcpg,img='',infoLabels=bxaXHhMEKCGPTSfiqknouJOtvVBcUz,isFolder=bxaXHhMEKCGPTSfiqknouJOtvVBcUF,params=bxaXHhMEKCGPTSfiqknouJOtvVBcAQ)
  if bxaXHhMEKCGPTSfiqknouJOtvVBcUR(bxaXHhMEKCGPTSfiqknouJOtvVBcpW)>0:xbmcplugin.endOfDirectory(bxaXHhMEKCGPTSfiqknouJOtvVBcrm._addon_handle)
 def dp_Watch_List(bxaXHhMEKCGPTSfiqknouJOtvVBcrm,args):
  bxaXHhMEKCGPTSfiqknouJOtvVBcpr =args.get('sType')
  bxaXHhMEKCGPTSfiqknouJOtvVBcrN=bxaXHhMEKCGPTSfiqknouJOtvVBcrm.get_settings_direct_replay()
  bxaXHhMEKCGPTSfiqknouJOtvVBcpW=bxaXHhMEKCGPTSfiqknouJOtvVBcrm.Load_Watched_List(bxaXHhMEKCGPTSfiqknouJOtvVBcpr)
  for bxaXHhMEKCGPTSfiqknouJOtvVBcpL in bxaXHhMEKCGPTSfiqknouJOtvVBcpW:
   bxaXHhMEKCGPTSfiqknouJOtvVBcUY=bxaXHhMEKCGPTSfiqknouJOtvVBcUD(urllib.parse.parse_qsl(bxaXHhMEKCGPTSfiqknouJOtvVBcpL))
   bxaXHhMEKCGPTSfiqknouJOtvVBcUL =bxaXHhMEKCGPTSfiqknouJOtvVBcUY.get('code').strip()
   bxaXHhMEKCGPTSfiqknouJOtvVBcAs =bxaXHhMEKCGPTSfiqknouJOtvVBcUY.get('title').strip()
   bxaXHhMEKCGPTSfiqknouJOtvVBcpg =bxaXHhMEKCGPTSfiqknouJOtvVBcUY.get('subtitle').strip()
   if bxaXHhMEKCGPTSfiqknouJOtvVBcpg=='None':bxaXHhMEKCGPTSfiqknouJOtvVBcpg=''
   bxaXHhMEKCGPTSfiqknouJOtvVBcpe=bxaXHhMEKCGPTSfiqknouJOtvVBcUY.get('img').strip()
   bxaXHhMEKCGPTSfiqknouJOtvVBcUp =bxaXHhMEKCGPTSfiqknouJOtvVBcUY.get('videoid').strip()
   try:
    bxaXHhMEKCGPTSfiqknouJOtvVBcpe=bxaXHhMEKCGPTSfiqknouJOtvVBcpe.replace('\'','\"')
    bxaXHhMEKCGPTSfiqknouJOtvVBcpe=json.loads(bxaXHhMEKCGPTSfiqknouJOtvVBcpe)
   except:
    bxaXHhMEKCGPTSfiqknouJOtvVBcUz
   bxaXHhMEKCGPTSfiqknouJOtvVBcpF={'plot':'%s\n%s'%(bxaXHhMEKCGPTSfiqknouJOtvVBcAs,bxaXHhMEKCGPTSfiqknouJOtvVBcpg)}
   if bxaXHhMEKCGPTSfiqknouJOtvVBcpr=='vod':
    if bxaXHhMEKCGPTSfiqknouJOtvVBcrN==bxaXHhMEKCGPTSfiqknouJOtvVBcUw or bxaXHhMEKCGPTSfiqknouJOtvVBcUp==bxaXHhMEKCGPTSfiqknouJOtvVBcUz:
     bxaXHhMEKCGPTSfiqknouJOtvVBcAQ={'mode':'EPISODE_LIST','videoid':bxaXHhMEKCGPTSfiqknouJOtvVBcUL,'vidtype':'programid','page':'1'}
     bxaXHhMEKCGPTSfiqknouJOtvVBcAm=bxaXHhMEKCGPTSfiqknouJOtvVBcUF
    else:
     bxaXHhMEKCGPTSfiqknouJOtvVBcAQ={'mode':'VOD','programid':bxaXHhMEKCGPTSfiqknouJOtvVBcUL,'contentid':bxaXHhMEKCGPTSfiqknouJOtvVBcUp,'title':bxaXHhMEKCGPTSfiqknouJOtvVBcAs,'subtitle':bxaXHhMEKCGPTSfiqknouJOtvVBcpg,'thumbnail':bxaXHhMEKCGPTSfiqknouJOtvVBcpe}
     bxaXHhMEKCGPTSfiqknouJOtvVBcAm=bxaXHhMEKCGPTSfiqknouJOtvVBcUw
   else:
    bxaXHhMEKCGPTSfiqknouJOtvVBcAQ={'mode':'MOVIE','contentid':bxaXHhMEKCGPTSfiqknouJOtvVBcUL,'title':bxaXHhMEKCGPTSfiqknouJOtvVBcAs,'subtitle':bxaXHhMEKCGPTSfiqknouJOtvVBcpg,'thumbnail':bxaXHhMEKCGPTSfiqknouJOtvVBcpe}
    bxaXHhMEKCGPTSfiqknouJOtvVBcAm=bxaXHhMEKCGPTSfiqknouJOtvVBcUw
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.add_dir(bxaXHhMEKCGPTSfiqknouJOtvVBcAs,sublabel=bxaXHhMEKCGPTSfiqknouJOtvVBcpg,img=bxaXHhMEKCGPTSfiqknouJOtvVBcpe,infoLabels=bxaXHhMEKCGPTSfiqknouJOtvVBcpF,isFolder=bxaXHhMEKCGPTSfiqknouJOtvVBcAm,params=bxaXHhMEKCGPTSfiqknouJOtvVBcAQ)
  bxaXHhMEKCGPTSfiqknouJOtvVBcpF={'plot':'시청목록을 삭제합니다.'}
  bxaXHhMEKCGPTSfiqknouJOtvVBcAs='*** 시청목록 삭제 ***'
  bxaXHhMEKCGPTSfiqknouJOtvVBcAQ={'mode':'MYVIEW_REMOVE','sType':bxaXHhMEKCGPTSfiqknouJOtvVBcpr}
  bxaXHhMEKCGPTSfiqknouJOtvVBcrm.add_dir(bxaXHhMEKCGPTSfiqknouJOtvVBcAs,sublabel='',img='',infoLabels=bxaXHhMEKCGPTSfiqknouJOtvVBcpF,isFolder=bxaXHhMEKCGPTSfiqknouJOtvVBcUw,params=bxaXHhMEKCGPTSfiqknouJOtvVBcAQ)
  xbmcplugin.endOfDirectory(bxaXHhMEKCGPTSfiqknouJOtvVBcrm._addon_handle,cacheToDisc=bxaXHhMEKCGPTSfiqknouJOtvVBcUw)
 def wavve_main(bxaXHhMEKCGPTSfiqknouJOtvVBcrm):
  bxaXHhMEKCGPTSfiqknouJOtvVBcAg=bxaXHhMEKCGPTSfiqknouJOtvVBcrm.main_params.get('mode',bxaXHhMEKCGPTSfiqknouJOtvVBcUz)
  if bxaXHhMEKCGPTSfiqknouJOtvVBcAg=='LOGOUT':
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.logout()
   return
  bxaXHhMEKCGPTSfiqknouJOtvVBcrm.login_main()
  if bxaXHhMEKCGPTSfiqknouJOtvVBcAg is bxaXHhMEKCGPTSfiqknouJOtvVBcUz:
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.dp_Main_List()
  elif bxaXHhMEKCGPTSfiqknouJOtvVBcAg in['LIVE','VOD','MOVIE']:
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.play_VIDEO(bxaXHhMEKCGPTSfiqknouJOtvVBcrm.main_params)
  elif bxaXHhMEKCGPTSfiqknouJOtvVBcAg=='LIVE_CATAGORY':
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.dp_LiveCatagory_List(bxaXHhMEKCGPTSfiqknouJOtvVBcrm.main_params)
  elif bxaXHhMEKCGPTSfiqknouJOtvVBcAg=='MAIN_CATAGORY':
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.dp_MainCatagory_List(bxaXHhMEKCGPTSfiqknouJOtvVBcrm.main_params)
  elif bxaXHhMEKCGPTSfiqknouJOtvVBcAg=='SUPERSECTION_LIST':
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.dp_SuperSection_List(bxaXHhMEKCGPTSfiqknouJOtvVBcrm.main_params)
  elif bxaXHhMEKCGPTSfiqknouJOtvVBcAg=='BANDLIVESECTION_LIST':
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.dp_BandLiveSection_List(bxaXHhMEKCGPTSfiqknouJOtvVBcrm.main_params)
  elif bxaXHhMEKCGPTSfiqknouJOtvVBcAg=='BAND2SECTION_LIST':
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.dp_Band2Section_List(bxaXHhMEKCGPTSfiqknouJOtvVBcrm.main_params)
  elif bxaXHhMEKCGPTSfiqknouJOtvVBcAg=='PROGRAM_LIST':
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.dp_Program_List(bxaXHhMEKCGPTSfiqknouJOtvVBcrm.main_params)
  elif bxaXHhMEKCGPTSfiqknouJOtvVBcAg=='EPISODE_LIST':
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.dp_Episode_List(bxaXHhMEKCGPTSfiqknouJOtvVBcrm.main_params)
  elif bxaXHhMEKCGPTSfiqknouJOtvVBcAg=='MOVIE_LIST':
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.dp_Movie_List(bxaXHhMEKCGPTSfiqknouJOtvVBcrm.main_params)
  elif bxaXHhMEKCGPTSfiqknouJOtvVBcAg=='LIVE_LIST':
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.dp_LiveChannel_List(bxaXHhMEKCGPTSfiqknouJOtvVBcrm.main_params)
  elif bxaXHhMEKCGPTSfiqknouJOtvVBcAg=='ORDER_BY':
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.dp_setEpOrderby(bxaXHhMEKCGPTSfiqknouJOtvVBcrm.main_params)
  elif bxaXHhMEKCGPTSfiqknouJOtvVBcAg=='SEARCH_GROUP':
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.dp_Search_Group(bxaXHhMEKCGPTSfiqknouJOtvVBcrm.main_params)
  elif bxaXHhMEKCGPTSfiqknouJOtvVBcAg=='SEARCH_LIST':
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.dp_Search_List(bxaXHhMEKCGPTSfiqknouJOtvVBcrm.main_params)
  elif bxaXHhMEKCGPTSfiqknouJOtvVBcAg=='WATCH_GROUP':
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.dp_Watch_Group(bxaXHhMEKCGPTSfiqknouJOtvVBcrm.main_params)
  elif bxaXHhMEKCGPTSfiqknouJOtvVBcAg=='WATCH_LIST':
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.dp_Watch_List(bxaXHhMEKCGPTSfiqknouJOtvVBcrm.main_params)
  elif bxaXHhMEKCGPTSfiqknouJOtvVBcAg=='MYVIEW_REMOVE':
   bxaXHhMEKCGPTSfiqknouJOtvVBcrm.dp_WatchList_Delete(bxaXHhMEKCGPTSfiqknouJOtvVBcrm.main_params)
  else:
   bxaXHhMEKCGPTSfiqknouJOtvVBcUz
# Created by pyminifier (https://github.com/liftoff/pyminifier)
