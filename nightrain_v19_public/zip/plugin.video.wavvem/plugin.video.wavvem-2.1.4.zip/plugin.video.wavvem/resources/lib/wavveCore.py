__author__="NightRain"
kKBJodUHvXewabhlicTxAzyYrqRSsQ=object
kKBJodUHvXewabhlicTxAzyYrqRSsg=None
kKBJodUHvXewabhlicTxAzyYrqRSsP=False
kKBJodUHvXewabhlicTxAzyYrqRSsD=True
kKBJodUHvXewabhlicTxAzyYrqRSsn=range
kKBJodUHvXewabhlicTxAzyYrqRSsG=str
kKBJodUHvXewabhlicTxAzyYrqRSfC=Exception
kKBJodUHvXewabhlicTxAzyYrqRSft=print
kKBJodUHvXewabhlicTxAzyYrqRSfj=dict
kKBJodUHvXewabhlicTxAzyYrqRSfs=int
kKBJodUHvXewabhlicTxAzyYrqRSfV=len
import urllib
import http.cookiejar 
import re
import json
import sys
import requests
import datetime
class kKBJodUHvXewabhlicTxAzyYrqRSCt(kKBJodUHvXewabhlicTxAzyYrqRSsQ):
 def __init__(kKBJodUHvXewabhlicTxAzyYrqRSCj):
  kKBJodUHvXewabhlicTxAzyYrqRSCj.API_DOMAIN='https://apis.wavve.com'
  kKBJodUHvXewabhlicTxAzyYrqRSCj.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  kKBJodUHvXewabhlicTxAzyYrqRSCj.CREDENTIAL='none'
  kKBJodUHvXewabhlicTxAzyYrqRSCj.DEVICE ='pc'
  kKBJodUHvXewabhlicTxAzyYrqRSCj.DRM ='wm'
  kKBJodUHvXewabhlicTxAzyYrqRSCj.PARTNER ='pooq'
  kKBJodUHvXewabhlicTxAzyYrqRSCj.POOQZONE ='none'
  kKBJodUHvXewabhlicTxAzyYrqRSCj.REGION ='kor'
  kKBJodUHvXewabhlicTxAzyYrqRSCj.TARGETAGE ='all'
  kKBJodUHvXewabhlicTxAzyYrqRSCj.HTTPTAG ='https://'
  kKBJodUHvXewabhlicTxAzyYrqRSCj.LIST_LIMIT=30 
  kKBJodUHvXewabhlicTxAzyYrqRSCj.EP_LIMIT =30 
  kKBJodUHvXewabhlicTxAzyYrqRSCj.MV_LIMIT =24 
  kKBJodUHvXewabhlicTxAzyYrqRSCj.guid ='none' 
  kKBJodUHvXewabhlicTxAzyYrqRSCj.guidtimestamp='none' 
  kKBJodUHvXewabhlicTxAzyYrqRSCj.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
  kKBJodUHvXewabhlicTxAzyYrqRSCj.DEFAULT_HEADER={'user-agent':kKBJodUHvXewabhlicTxAzyYrqRSCj.USER_AGENT}
 def callRequestCookies(kKBJodUHvXewabhlicTxAzyYrqRSCj,jobtype,kKBJodUHvXewabhlicTxAzyYrqRSCQ,payload=kKBJodUHvXewabhlicTxAzyYrqRSsg,params=kKBJodUHvXewabhlicTxAzyYrqRSsg,headers=kKBJodUHvXewabhlicTxAzyYrqRSsg,cookies=kKBJodUHvXewabhlicTxAzyYrqRSsg,redirects=kKBJodUHvXewabhlicTxAzyYrqRSsP):
  kKBJodUHvXewabhlicTxAzyYrqRSCs=kKBJodUHvXewabhlicTxAzyYrqRSCj.DEFAULT_HEADER
  if headers:kKBJodUHvXewabhlicTxAzyYrqRSCs.update(headers)
  if jobtype=='Get':
   kKBJodUHvXewabhlicTxAzyYrqRSCf=requests.get(kKBJodUHvXewabhlicTxAzyYrqRSCQ,params=params,headers=kKBJodUHvXewabhlicTxAzyYrqRSCs,cookies=cookies,allow_redirects=redirects)
  else:
   kKBJodUHvXewabhlicTxAzyYrqRSCf=requests.post(kKBJodUHvXewabhlicTxAzyYrqRSCQ,data=payload,params=params,headers=kKBJodUHvXewabhlicTxAzyYrqRSCs,cookies=cookies,allow_redirects=redirects)
  return kKBJodUHvXewabhlicTxAzyYrqRSCf
 def SaveCredential(kKBJodUHvXewabhlicTxAzyYrqRSCj,kKBJodUHvXewabhlicTxAzyYrqRSCV):
  kKBJodUHvXewabhlicTxAzyYrqRSCj.CREDENTIAL=kKBJodUHvXewabhlicTxAzyYrqRSCV
 def LoadCredential(kKBJodUHvXewabhlicTxAzyYrqRSCj):
  return kKBJodUHvXewabhlicTxAzyYrqRSCj.CREDENTIAL
 def GetDefaultParams(kKBJodUHvXewabhlicTxAzyYrqRSCj,login=kKBJodUHvXewabhlicTxAzyYrqRSsD):
  kKBJodUHvXewabhlicTxAzyYrqRSCI={'apikey':kKBJodUHvXewabhlicTxAzyYrqRSCj.APIKEY,'credential':kKBJodUHvXewabhlicTxAzyYrqRSCj.CREDENTIAL if login else 'none','device':kKBJodUHvXewabhlicTxAzyYrqRSCj.DEVICE,'drm':kKBJodUHvXewabhlicTxAzyYrqRSCj.DRM,'partner':kKBJodUHvXewabhlicTxAzyYrqRSCj.PARTNER,'pooqzone':kKBJodUHvXewabhlicTxAzyYrqRSCj.POOQZONE,'region':kKBJodUHvXewabhlicTxAzyYrqRSCj.REGION,'targetage':kKBJodUHvXewabhlicTxAzyYrqRSCj.TARGETAGE}
  return kKBJodUHvXewabhlicTxAzyYrqRSCI
 def GetGUID(kKBJodUHvXewabhlicTxAzyYrqRSCj,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   kKBJodUHvXewabhlicTxAzyYrqRSCE=kKBJodUHvXewabhlicTxAzyYrqRSCj.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   kKBJodUHvXewabhlicTxAzyYrqRSCm=GenerateRandomString(5)
   kKBJodUHvXewabhlicTxAzyYrqRSCp=kKBJodUHvXewabhlicTxAzyYrqRSCm+media+kKBJodUHvXewabhlicTxAzyYrqRSCE
   return kKBJodUHvXewabhlicTxAzyYrqRSCp
  def GenerateRandomString(num):
   from random import randint
   kKBJodUHvXewabhlicTxAzyYrqRSCO=""
   for i in kKBJodUHvXewabhlicTxAzyYrqRSsn(0,num):
    s=kKBJodUHvXewabhlicTxAzyYrqRSsG(randint(1,5))
    kKBJodUHvXewabhlicTxAzyYrqRSCO+=s
   return kKBJodUHvXewabhlicTxAzyYrqRSCO
  kKBJodUHvXewabhlicTxAzyYrqRSCp=GenerateID(guid_str)
  kKBJodUHvXewabhlicTxAzyYrqRSCu=kKBJodUHvXewabhlicTxAzyYrqRSCj.GetHash(kKBJodUHvXewabhlicTxAzyYrqRSCp)
  if guidType==2:
   kKBJodUHvXewabhlicTxAzyYrqRSCu='%s-%s-%s-%s-%s'%(kKBJodUHvXewabhlicTxAzyYrqRSCu[:8],kKBJodUHvXewabhlicTxAzyYrqRSCu[8:12],kKBJodUHvXewabhlicTxAzyYrqRSCu[12:16],kKBJodUHvXewabhlicTxAzyYrqRSCu[16:20],kKBJodUHvXewabhlicTxAzyYrqRSCu[20:])
  return kKBJodUHvXewabhlicTxAzyYrqRSCu
 def GetHash(kKBJodUHvXewabhlicTxAzyYrqRSCj,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return kKBJodUHvXewabhlicTxAzyYrqRSsG(m.hexdigest())
 def CheckQuality(kKBJodUHvXewabhlicTxAzyYrqRSCj,sel_qt,qt_list):
  kKBJodUHvXewabhlicTxAzyYrqRSCM=0
  for kKBJodUHvXewabhlicTxAzyYrqRSCL in qt_list:
   if sel_qt>=kKBJodUHvXewabhlicTxAzyYrqRSCL:return kKBJodUHvXewabhlicTxAzyYrqRSCL
   kKBJodUHvXewabhlicTxAzyYrqRSCM=kKBJodUHvXewabhlicTxAzyYrqRSCL
  return kKBJodUHvXewabhlicTxAzyYrqRSCM
 def Get_Now_Datetime(kKBJodUHvXewabhlicTxAzyYrqRSCj):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(kKBJodUHvXewabhlicTxAzyYrqRSCj,in_text):
  kKBJodUHvXewabhlicTxAzyYrqRSCW=in_text.replace('&lt;','<').replace('&gt;','>')
  kKBJodUHvXewabhlicTxAzyYrqRSCW=kKBJodUHvXewabhlicTxAzyYrqRSCW.replace('$O$','')
  kKBJodUHvXewabhlicTxAzyYrqRSCW=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',kKBJodUHvXewabhlicTxAzyYrqRSCW)
  kKBJodUHvXewabhlicTxAzyYrqRSCW=kKBJodUHvXewabhlicTxAzyYrqRSCW.lstrip('#')
  return kKBJodUHvXewabhlicTxAzyYrqRSCW
 def GetCredential(kKBJodUHvXewabhlicTxAzyYrqRSCj,user_id,user_pw,user_pf):
  kKBJodUHvXewabhlicTxAzyYrqRSCN=kKBJodUHvXewabhlicTxAzyYrqRSsP
  try:
   kKBJodUHvXewabhlicTxAzyYrqRSCQ=kKBJodUHvXewabhlicTxAzyYrqRSCj.API_DOMAIN+ '/login'
   kKBJodUHvXewabhlicTxAzyYrqRSCI=kKBJodUHvXewabhlicTxAzyYrqRSCj.GetDefaultParams()
   kKBJodUHvXewabhlicTxAzyYrqRSCg={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   kKBJodUHvXewabhlicTxAzyYrqRSCP=kKBJodUHvXewabhlicTxAzyYrqRSCj.callRequestCookies('Post',kKBJodUHvXewabhlicTxAzyYrqRSCQ,payload=kKBJodUHvXewabhlicTxAzyYrqRSCg,params=kKBJodUHvXewabhlicTxAzyYrqRSCI,headers=kKBJodUHvXewabhlicTxAzyYrqRSsg,cookies=kKBJodUHvXewabhlicTxAzyYrqRSsg)
   kKBJodUHvXewabhlicTxAzyYrqRSCD=json.loads(kKBJodUHvXewabhlicTxAzyYrqRSCP.text)
   kKBJodUHvXewabhlicTxAzyYrqRSCV=kKBJodUHvXewabhlicTxAzyYrqRSCD['credential']
   if user_pf!=0:
    kKBJodUHvXewabhlicTxAzyYrqRSCg={'id':kKBJodUHvXewabhlicTxAzyYrqRSCV,'password':'','profile':kKBJodUHvXewabhlicTxAzyYrqRSsG(user_pf),'pushid':'','type':'credential'}
    kKBJodUHvXewabhlicTxAzyYrqRSCI['credential']=kKBJodUHvXewabhlicTxAzyYrqRSCV 
    kKBJodUHvXewabhlicTxAzyYrqRSCP=kKBJodUHvXewabhlicTxAzyYrqRSCj.callRequestCookies('Post',kKBJodUHvXewabhlicTxAzyYrqRSCQ,payload=kKBJodUHvXewabhlicTxAzyYrqRSCg,params=kKBJodUHvXewabhlicTxAzyYrqRSCI,headers=kKBJodUHvXewabhlicTxAzyYrqRSsg,cookies=kKBJodUHvXewabhlicTxAzyYrqRSsg)
    kKBJodUHvXewabhlicTxAzyYrqRSCD=json.loads(kKBJodUHvXewabhlicTxAzyYrqRSCP.text)
    kKBJodUHvXewabhlicTxAzyYrqRSCV=kKBJodUHvXewabhlicTxAzyYrqRSCD['credential']
   if kKBJodUHvXewabhlicTxAzyYrqRSCV:kKBJodUHvXewabhlicTxAzyYrqRSCN=kKBJodUHvXewabhlicTxAzyYrqRSsD
  except kKBJodUHvXewabhlicTxAzyYrqRSfC as exception:
   kKBJodUHvXewabhlicTxAzyYrqRSft(exception)
   kKBJodUHvXewabhlicTxAzyYrqRSCV='none' 
  kKBJodUHvXewabhlicTxAzyYrqRSCj.SaveCredential(kKBJodUHvXewabhlicTxAzyYrqRSCV)
  return kKBJodUHvXewabhlicTxAzyYrqRSCN
 def GetIssue(kKBJodUHvXewabhlicTxAzyYrqRSCj):
  kKBJodUHvXewabhlicTxAzyYrqRSCn=kKBJodUHvXewabhlicTxAzyYrqRSsP
  try:
   kKBJodUHvXewabhlicTxAzyYrqRSCQ=kKBJodUHvXewabhlicTxAzyYrqRSCj.API_DOMAIN+'/guid/issue'
   kKBJodUHvXewabhlicTxAzyYrqRSCI=kKBJodUHvXewabhlicTxAzyYrqRSCj.GetDefaultParams()
   kKBJodUHvXewabhlicTxAzyYrqRSCP=kKBJodUHvXewabhlicTxAzyYrqRSCj.callRequestCookies('Get',kKBJodUHvXewabhlicTxAzyYrqRSCQ,payload=kKBJodUHvXewabhlicTxAzyYrqRSsg,params=kKBJodUHvXewabhlicTxAzyYrqRSCI,headers=kKBJodUHvXewabhlicTxAzyYrqRSsg,cookies=kKBJodUHvXewabhlicTxAzyYrqRSsg)
   kKBJodUHvXewabhlicTxAzyYrqRSCD=json.loads(kKBJodUHvXewabhlicTxAzyYrqRSCP.text)
   kKBJodUHvXewabhlicTxAzyYrqRSCG=kKBJodUHvXewabhlicTxAzyYrqRSCD['guid']
   kKBJodUHvXewabhlicTxAzyYrqRStC=kKBJodUHvXewabhlicTxAzyYrqRSCD['guidtimestamp']
   if kKBJodUHvXewabhlicTxAzyYrqRSCG:kKBJodUHvXewabhlicTxAzyYrqRSCn=kKBJodUHvXewabhlicTxAzyYrqRSsD
  except kKBJodUHvXewabhlicTxAzyYrqRSfC as exception:
   kKBJodUHvXewabhlicTxAzyYrqRSft(exception)
   kKBJodUHvXewabhlicTxAzyYrqRSCG='none'
   kKBJodUHvXewabhlicTxAzyYrqRStC='none' 
  kKBJodUHvXewabhlicTxAzyYrqRSCj.guid=kKBJodUHvXewabhlicTxAzyYrqRSCG
  kKBJodUHvXewabhlicTxAzyYrqRSCj.guidtimestamp=kKBJodUHvXewabhlicTxAzyYrqRStC
  return kKBJodUHvXewabhlicTxAzyYrqRSCn
 def Baseapi_Parse(kKBJodUHvXewabhlicTxAzyYrqRSCj,kKBJodUHvXewabhlicTxAzyYrqRStV):
  try:
   kKBJodUHvXewabhlicTxAzyYrqRStj =urllib.parse.urlsplit(kKBJodUHvXewabhlicTxAzyYrqRStV)
   if kKBJodUHvXewabhlicTxAzyYrqRStj.netloc=='':
    kKBJodUHvXewabhlicTxAzyYrqRSCQ=kKBJodUHvXewabhlicTxAzyYrqRSCj.HTTPTAG+kKBJodUHvXewabhlicTxAzyYrqRStj.netloc+kKBJodUHvXewabhlicTxAzyYrqRStj.path
   else:
    kKBJodUHvXewabhlicTxAzyYrqRSCQ=kKBJodUHvXewabhlicTxAzyYrqRStj.scheme+'://'+kKBJodUHvXewabhlicTxAzyYrqRStj.netloc+kKBJodUHvXewabhlicTxAzyYrqRStj.path
   kKBJodUHvXewabhlicTxAzyYrqRSCI=kKBJodUHvXewabhlicTxAzyYrqRSfj(urllib.parse.parse_qsl(kKBJodUHvXewabhlicTxAzyYrqRStj.query))
  except:
   kKBJodUHvXewabhlicTxAzyYrqRSft(exception)
   return '',{}
  return kKBJodUHvXewabhlicTxAzyYrqRSCQ,kKBJodUHvXewabhlicTxAzyYrqRSCI
 def GetSupermultiUrl(kKBJodUHvXewabhlicTxAzyYrqRSCj,sCode,sIndex='0'):
  try:
   kKBJodUHvXewabhlicTxAzyYrqRSCQ=kKBJodUHvXewabhlicTxAzyYrqRSCj.API_DOMAIN+'/cf/supermultisections/'+sCode
   kKBJodUHvXewabhlicTxAzyYrqRSCI=kKBJodUHvXewabhlicTxAzyYrqRSCj.GetDefaultParams(login=kKBJodUHvXewabhlicTxAzyYrqRSsP)
   kKBJodUHvXewabhlicTxAzyYrqRSCP=kKBJodUHvXewabhlicTxAzyYrqRSCj.callRequestCookies('Get',kKBJodUHvXewabhlicTxAzyYrqRSCQ,payload=kKBJodUHvXewabhlicTxAzyYrqRSsg,params=kKBJodUHvXewabhlicTxAzyYrqRSCI,headers=kKBJodUHvXewabhlicTxAzyYrqRSsg,cookies=kKBJodUHvXewabhlicTxAzyYrqRSsg)
   kKBJodUHvXewabhlicTxAzyYrqRSCD=json.loads(kKBJodUHvXewabhlicTxAzyYrqRSCP.text)
   kKBJodUHvXewabhlicTxAzyYrqRSts=kKBJodUHvXewabhlicTxAzyYrqRSCD['multisectionlist'][kKBJodUHvXewabhlicTxAzyYrqRSfs(sIndex)]['eventlist'][1]['url']
  except kKBJodUHvXewabhlicTxAzyYrqRSfC as exception:
   kKBJodUHvXewabhlicTxAzyYrqRSft(exception)
   return ''
  return kKBJodUHvXewabhlicTxAzyYrqRSts
 def Get_LiveCatagory_List(kKBJodUHvXewabhlicTxAzyYrqRSCj,sCode,sIndex='0'):
  kKBJodUHvXewabhlicTxAzyYrqRStf=[]
  kKBJodUHvXewabhlicTxAzyYrqRStV =kKBJodUHvXewabhlicTxAzyYrqRSCj.GetSupermultiUrl(sCode,sIndex)
  (kKBJodUHvXewabhlicTxAzyYrqRSCQ,kKBJodUHvXewabhlicTxAzyYrqRSCI)=kKBJodUHvXewabhlicTxAzyYrqRSCj.Baseapi_Parse(kKBJodUHvXewabhlicTxAzyYrqRStV)
  if kKBJodUHvXewabhlicTxAzyYrqRSCQ=='':return kKBJodUHvXewabhlicTxAzyYrqRStf,''
  try:
   kKBJodUHvXewabhlicTxAzyYrqRSCI.update(kKBJodUHvXewabhlicTxAzyYrqRSCj.GetDefaultParams(login=kKBJodUHvXewabhlicTxAzyYrqRSsP))
   kKBJodUHvXewabhlicTxAzyYrqRSCP=kKBJodUHvXewabhlicTxAzyYrqRSCj.callRequestCookies('Get',kKBJodUHvXewabhlicTxAzyYrqRSCQ,payload=kKBJodUHvXewabhlicTxAzyYrqRSsg,params=kKBJodUHvXewabhlicTxAzyYrqRSCI,headers=kKBJodUHvXewabhlicTxAzyYrqRSsg,cookies=kKBJodUHvXewabhlicTxAzyYrqRSsg)
   kKBJodUHvXewabhlicTxAzyYrqRSCD=json.loads(kKBJodUHvXewabhlicTxAzyYrqRSCP.text)
   if not('filter_item_list' in kKBJodUHvXewabhlicTxAzyYrqRSCD['filter']['filterlist'][0]):return[],''
   kKBJodUHvXewabhlicTxAzyYrqRStE=kKBJodUHvXewabhlicTxAzyYrqRSCD['filter']['filterlist'][0]['filter_item_list']
   for kKBJodUHvXewabhlicTxAzyYrqRStm in kKBJodUHvXewabhlicTxAzyYrqRStE:
    kKBJodUHvXewabhlicTxAzyYrqRStp={'title':kKBJodUHvXewabhlicTxAzyYrqRStm['title'],'genre':kKBJodUHvXewabhlicTxAzyYrqRStm['api_parameters'][kKBJodUHvXewabhlicTxAzyYrqRStm['api_parameters'].index('=')+1:]}
    kKBJodUHvXewabhlicTxAzyYrqRStf.append(kKBJodUHvXewabhlicTxAzyYrqRStp)
  except kKBJodUHvXewabhlicTxAzyYrqRSfC as exception:
   kKBJodUHvXewabhlicTxAzyYrqRSft(exception)
   return[],''
  return kKBJodUHvXewabhlicTxAzyYrqRStf,kKBJodUHvXewabhlicTxAzyYrqRStV
 def Get_MainCatagory_List(kKBJodUHvXewabhlicTxAzyYrqRSCj,sCode,sIndex='0'):
  kKBJodUHvXewabhlicTxAzyYrqRStf=[]
  kKBJodUHvXewabhlicTxAzyYrqRStV =kKBJodUHvXewabhlicTxAzyYrqRSCj.GetSupermultiUrl(sCode,sIndex)
  (kKBJodUHvXewabhlicTxAzyYrqRSCQ,kKBJodUHvXewabhlicTxAzyYrqRSCI)=kKBJodUHvXewabhlicTxAzyYrqRSCj.Baseapi_Parse(kKBJodUHvXewabhlicTxAzyYrqRStV)
  if kKBJodUHvXewabhlicTxAzyYrqRSCQ=='':return kKBJodUHvXewabhlicTxAzyYrqRStf
  try:
   kKBJodUHvXewabhlicTxAzyYrqRSCI.update(kKBJodUHvXewabhlicTxAzyYrqRSCj.GetDefaultParams(login=kKBJodUHvXewabhlicTxAzyYrqRSsP))
   kKBJodUHvXewabhlicTxAzyYrqRSCP=kKBJodUHvXewabhlicTxAzyYrqRSCj.callRequestCookies('Get',kKBJodUHvXewabhlicTxAzyYrqRSCQ,payload=kKBJodUHvXewabhlicTxAzyYrqRSsg,params=kKBJodUHvXewabhlicTxAzyYrqRSCI,headers=kKBJodUHvXewabhlicTxAzyYrqRSsg,cookies=kKBJodUHvXewabhlicTxAzyYrqRSsg)
   kKBJodUHvXewabhlicTxAzyYrqRSCD=json.loads(kKBJodUHvXewabhlicTxAzyYrqRSCP.text)
   if not('celllist' in kKBJodUHvXewabhlicTxAzyYrqRSCD['band']):return[]
   kKBJodUHvXewabhlicTxAzyYrqRStE=kKBJodUHvXewabhlicTxAzyYrqRSCD['band']['celllist']
   for kKBJodUHvXewabhlicTxAzyYrqRStm in kKBJodUHvXewabhlicTxAzyYrqRStE:
    kKBJodUHvXewabhlicTxAzyYrqRStO =kKBJodUHvXewabhlicTxAzyYrqRStm['event_list'][1]['url']
    (kKBJodUHvXewabhlicTxAzyYrqRStu,kKBJodUHvXewabhlicTxAzyYrqRStM)=kKBJodUHvXewabhlicTxAzyYrqRSCj.Baseapi_Parse(kKBJodUHvXewabhlicTxAzyYrqRStO)
    kKBJodUHvXewabhlicTxAzyYrqRStp={'title':kKBJodUHvXewabhlicTxAzyYrqRStm['title_list'][0]['text'],'suburl':kKBJodUHvXewabhlicTxAzyYrqRStu,'subapi':kKBJodUHvXewabhlicTxAzyYrqRStM.get('api'),'subtype':'catagory' if kKBJodUHvXewabhlicTxAzyYrqRStM else 'supersection'}
    kKBJodUHvXewabhlicTxAzyYrqRStf.append(kKBJodUHvXewabhlicTxAzyYrqRStp)
  except kKBJodUHvXewabhlicTxAzyYrqRSfC as exception:
   kKBJodUHvXewabhlicTxAzyYrqRSft(exception)
   return[]
  return kKBJodUHvXewabhlicTxAzyYrqRStf
 def Get_SuperMultiSection_List(kKBJodUHvXewabhlicTxAzyYrqRSCj,subapi_text):
  kKBJodUHvXewabhlicTxAzyYrqRStf=[]
  kKBJodUHvXewabhlicTxAzyYrqRSCI={}
  try:
   kKBJodUHvXewabhlicTxAzyYrqRStj =urllib.parse.urlsplit(subapi_text)
   if kKBJodUHvXewabhlicTxAzyYrqRStj.path.find('apis.wavve.com')>=0: 
    kKBJodUHvXewabhlicTxAzyYrqRSCQ=kKBJodUHvXewabhlicTxAzyYrqRSCj.HTTPTAG+kKBJodUHvXewabhlicTxAzyYrqRStj.path 
    kKBJodUHvXewabhlicTxAzyYrqRSCI=kKBJodUHvXewabhlicTxAzyYrqRSfj(urllib.parse.parse_qsl(kKBJodUHvXewabhlicTxAzyYrqRStj.query))
   else:
    kKBJodUHvXewabhlicTxAzyYrqRSCQ=kKBJodUHvXewabhlicTxAzyYrqRSCj.API_DOMAIN+'/cf'+kKBJodUHvXewabhlicTxAzyYrqRStj.path 
   kKBJodUHvXewabhlicTxAzyYrqRSCQ=kKBJodUHvXewabhlicTxAzyYrqRSCQ.replace('supermultisection/','supermultisections/')
  except kKBJodUHvXewabhlicTxAzyYrqRSfC as exception:
   kKBJodUHvXewabhlicTxAzyYrqRSft(exception)
   return[]
  try:
   kKBJodUHvXewabhlicTxAzyYrqRSCI.update(kKBJodUHvXewabhlicTxAzyYrqRSCj.GetDefaultParams(login=kKBJodUHvXewabhlicTxAzyYrqRSsP))
   kKBJodUHvXewabhlicTxAzyYrqRSCP=kKBJodUHvXewabhlicTxAzyYrqRSCj.callRequestCookies('Get',kKBJodUHvXewabhlicTxAzyYrqRSCQ,payload=kKBJodUHvXewabhlicTxAzyYrqRSsg,params=kKBJodUHvXewabhlicTxAzyYrqRSsg,headers=kKBJodUHvXewabhlicTxAzyYrqRSsg,cookies=kKBJodUHvXewabhlicTxAzyYrqRSsg)
   kKBJodUHvXewabhlicTxAzyYrqRSCD=json.loads(kKBJodUHvXewabhlicTxAzyYrqRSCP.text)
   if not('multisectionlist' in kKBJodUHvXewabhlicTxAzyYrqRSCD):return[]
   kKBJodUHvXewabhlicTxAzyYrqRStE=kKBJodUHvXewabhlicTxAzyYrqRSCD['multisectionlist']
   for kKBJodUHvXewabhlicTxAzyYrqRStm in kKBJodUHvXewabhlicTxAzyYrqRStE:
    kKBJodUHvXewabhlicTxAzyYrqRStL=kKBJodUHvXewabhlicTxAzyYrqRStm['title']
    if kKBJodUHvXewabhlicTxAzyYrqRSfV(kKBJodUHvXewabhlicTxAzyYrqRStL)==0:continue
    if kKBJodUHvXewabhlicTxAzyYrqRStL=='minor':continue
    if re.search(u'베너',kKBJodUHvXewabhlicTxAzyYrqRStL):continue
    if re.search(u'배너',kKBJodUHvXewabhlicTxAzyYrqRStL):continue 
    if kKBJodUHvXewabhlicTxAzyYrqRSfV(kKBJodUHvXewabhlicTxAzyYrqRStm['eventlist'])>=3:
     kKBJodUHvXewabhlicTxAzyYrqRStM =kKBJodUHvXewabhlicTxAzyYrqRStm['eventlist'][2]['url']
    else:
     kKBJodUHvXewabhlicTxAzyYrqRStM =kKBJodUHvXewabhlicTxAzyYrqRStm['eventlist'][1]['url']
    kKBJodUHvXewabhlicTxAzyYrqRStF=kKBJodUHvXewabhlicTxAzyYrqRStm['cell_type']
    if kKBJodUHvXewabhlicTxAzyYrqRStF=='band_2':
     if kKBJodUHvXewabhlicTxAzyYrqRStM.find('channellist=')>=0:
      kKBJodUHvXewabhlicTxAzyYrqRStF='band_live'
    kKBJodUHvXewabhlicTxAzyYrqRStp={'title':kKBJodUHvXewabhlicTxAzyYrqRSCj.Get_ChangeText(kKBJodUHvXewabhlicTxAzyYrqRStL),'subapi':kKBJodUHvXewabhlicTxAzyYrqRStM,'cell_type':kKBJodUHvXewabhlicTxAzyYrqRStF}
    kKBJodUHvXewabhlicTxAzyYrqRStf.append(kKBJodUHvXewabhlicTxAzyYrqRStp)
  except kKBJodUHvXewabhlicTxAzyYrqRSfC as exception:
   kKBJodUHvXewabhlicTxAzyYrqRSft(exception)
   return[]
  return kKBJodUHvXewabhlicTxAzyYrqRStf
 def Get_BandLiveSection_List(kKBJodUHvXewabhlicTxAzyYrqRSCj,kKBJodUHvXewabhlicTxAzyYrqRStV,page_int=1):
  kKBJodUHvXewabhlicTxAzyYrqRStW=[]
  kKBJodUHvXewabhlicTxAzyYrqRStN=kKBJodUHvXewabhlicTxAzyYrqRStG=1
  kKBJodUHvXewabhlicTxAzyYrqRStQ=kKBJodUHvXewabhlicTxAzyYrqRSsP
  try:
   (kKBJodUHvXewabhlicTxAzyYrqRSCQ,kKBJodUHvXewabhlicTxAzyYrqRSCI)=kKBJodUHvXewabhlicTxAzyYrqRSCj.Baseapi_Parse(kKBJodUHvXewabhlicTxAzyYrqRStV)
  except kKBJodUHvXewabhlicTxAzyYrqRSfC as exception:
   kKBJodUHvXewabhlicTxAzyYrqRSft(exception)
   return[],kKBJodUHvXewabhlicTxAzyYrqRSsP
  try:
   kKBJodUHvXewabhlicTxAzyYrqRSCI['limit']=kKBJodUHvXewabhlicTxAzyYrqRSCj.LIST_LIMIT
   kKBJodUHvXewabhlicTxAzyYrqRSCI['offset']=kKBJodUHvXewabhlicTxAzyYrqRSsG((page_int-1)*kKBJodUHvXewabhlicTxAzyYrqRSCj.LIST_LIMIT)
   kKBJodUHvXewabhlicTxAzyYrqRSCI.update(kKBJodUHvXewabhlicTxAzyYrqRSCj.GetDefaultParams(login=kKBJodUHvXewabhlicTxAzyYrqRSsP))
   kKBJodUHvXewabhlicTxAzyYrqRSCP=kKBJodUHvXewabhlicTxAzyYrqRSCj.callRequestCookies('Get',kKBJodUHvXewabhlicTxAzyYrqRSCQ,payload=kKBJodUHvXewabhlicTxAzyYrqRSsg,params=kKBJodUHvXewabhlicTxAzyYrqRSCI,headers=kKBJodUHvXewabhlicTxAzyYrqRSsg,cookies=kKBJodUHvXewabhlicTxAzyYrqRSsg)
   kKBJodUHvXewabhlicTxAzyYrqRSCD=json.loads(kKBJodUHvXewabhlicTxAzyYrqRSCP.text)
   if not('celllist' in kKBJodUHvXewabhlicTxAzyYrqRSCD['cell_toplist']):return[],kKBJodUHvXewabhlicTxAzyYrqRSsP
   kKBJodUHvXewabhlicTxAzyYrqRStE=kKBJodUHvXewabhlicTxAzyYrqRSCD['cell_toplist']['celllist']
   for kKBJodUHvXewabhlicTxAzyYrqRStm in kKBJodUHvXewabhlicTxAzyYrqRStE:
    kKBJodUHvXewabhlicTxAzyYrqRStg =kKBJodUHvXewabhlicTxAzyYrqRStm['event_list'][1]['url']
    kKBJodUHvXewabhlicTxAzyYrqRStP=urllib.parse.urlsplit(kKBJodUHvXewabhlicTxAzyYrqRStg).query
    kKBJodUHvXewabhlicTxAzyYrqRStP=kKBJodUHvXewabhlicTxAzyYrqRSfj(urllib.parse.parse_qsl(kKBJodUHvXewabhlicTxAzyYrqRStP))
    kKBJodUHvXewabhlicTxAzyYrqRStD='channelid'
    kKBJodUHvXewabhlicTxAzyYrqRStn=kKBJodUHvXewabhlicTxAzyYrqRStP[kKBJodUHvXewabhlicTxAzyYrqRStD]
    kKBJodUHvXewabhlicTxAzyYrqRStp={'studio':kKBJodUHvXewabhlicTxAzyYrqRStm['title_list'][0]['text'],'tvshowtitle':kKBJodUHvXewabhlicTxAzyYrqRSCj.Get_ChangeText(kKBJodUHvXewabhlicTxAzyYrqRStm['title_list'][1]['text']),'channelid':kKBJodUHvXewabhlicTxAzyYrqRStn,'age':kKBJodUHvXewabhlicTxAzyYrqRStm.get('age'),'thumbnail':'https://%s'%kKBJodUHvXewabhlicTxAzyYrqRStm.get('thumbnail')}
    kKBJodUHvXewabhlicTxAzyYrqRStW.append(kKBJodUHvXewabhlicTxAzyYrqRStp)
   kKBJodUHvXewabhlicTxAzyYrqRStN=kKBJodUHvXewabhlicTxAzyYrqRSfs(kKBJodUHvXewabhlicTxAzyYrqRSCD['cell_toplist']['pagecount'])
   if kKBJodUHvXewabhlicTxAzyYrqRSCD['cell_toplist']['count']:kKBJodUHvXewabhlicTxAzyYrqRStG =kKBJodUHvXewabhlicTxAzyYrqRSfs(kKBJodUHvXewabhlicTxAzyYrqRSCD['cell_toplist']['count'])
   else:kKBJodUHvXewabhlicTxAzyYrqRStG=kKBJodUHvXewabhlicTxAzyYrqRSCj.LIST_LIMIT*page_int
   kKBJodUHvXewabhlicTxAzyYrqRStQ=kKBJodUHvXewabhlicTxAzyYrqRStN>kKBJodUHvXewabhlicTxAzyYrqRStG
  except kKBJodUHvXewabhlicTxAzyYrqRSfC as exception:
   kKBJodUHvXewabhlicTxAzyYrqRSft(exception)
   return[],kKBJodUHvXewabhlicTxAzyYrqRSsP
  return kKBJodUHvXewabhlicTxAzyYrqRStW,kKBJodUHvXewabhlicTxAzyYrqRStQ
 def Get_Band2Section_List(kKBJodUHvXewabhlicTxAzyYrqRSCj,kKBJodUHvXewabhlicTxAzyYrqRStV,page_int=1):
  kKBJodUHvXewabhlicTxAzyYrqRSjC=[]
  kKBJodUHvXewabhlicTxAzyYrqRStN=kKBJodUHvXewabhlicTxAzyYrqRStG=1
  kKBJodUHvXewabhlicTxAzyYrqRStQ=kKBJodUHvXewabhlicTxAzyYrqRSsP
  try:
   (kKBJodUHvXewabhlicTxAzyYrqRSCQ,kKBJodUHvXewabhlicTxAzyYrqRSCI)=kKBJodUHvXewabhlicTxAzyYrqRSCj.Baseapi_Parse(kKBJodUHvXewabhlicTxAzyYrqRStV)
  except kKBJodUHvXewabhlicTxAzyYrqRSfC as exception:
   kKBJodUHvXewabhlicTxAzyYrqRSft(exception)
   return[],kKBJodUHvXewabhlicTxAzyYrqRSsP
  try:
   kKBJodUHvXewabhlicTxAzyYrqRSCI['came'] ='BandView'
   kKBJodUHvXewabhlicTxAzyYrqRSCI['limit']=kKBJodUHvXewabhlicTxAzyYrqRSCj.LIST_LIMIT
   kKBJodUHvXewabhlicTxAzyYrqRSCI['offset']=kKBJodUHvXewabhlicTxAzyYrqRSsG((page_int-1)*kKBJodUHvXewabhlicTxAzyYrqRSCj.LIST_LIMIT)
   kKBJodUHvXewabhlicTxAzyYrqRSCI.update(kKBJodUHvXewabhlicTxAzyYrqRSCj.GetDefaultParams(login=kKBJodUHvXewabhlicTxAzyYrqRSsP))
   kKBJodUHvXewabhlicTxAzyYrqRSCP=kKBJodUHvXewabhlicTxAzyYrqRSCj.callRequestCookies('Get',kKBJodUHvXewabhlicTxAzyYrqRSCQ,payload=kKBJodUHvXewabhlicTxAzyYrqRSsg,params=kKBJodUHvXewabhlicTxAzyYrqRSCI,headers=kKBJodUHvXewabhlicTxAzyYrqRSsg,cookies=kKBJodUHvXewabhlicTxAzyYrqRSsg)
   kKBJodUHvXewabhlicTxAzyYrqRSCD=json.loads(kKBJodUHvXewabhlicTxAzyYrqRSCP.text)
   if not('celllist' in kKBJodUHvXewabhlicTxAzyYrqRSCD['cell_toplist']):return[],kKBJodUHvXewabhlicTxAzyYrqRSsP
   kKBJodUHvXewabhlicTxAzyYrqRStE=kKBJodUHvXewabhlicTxAzyYrqRSCD['cell_toplist']['celllist']
   for kKBJodUHvXewabhlicTxAzyYrqRStm in kKBJodUHvXewabhlicTxAzyYrqRStE:
    kKBJodUHvXewabhlicTxAzyYrqRStg =kKBJodUHvXewabhlicTxAzyYrqRStm['event_list'][1]['url']
    kKBJodUHvXewabhlicTxAzyYrqRStP=urllib.parse.urlsplit(kKBJodUHvXewabhlicTxAzyYrqRStg).query
    kKBJodUHvXewabhlicTxAzyYrqRStP=kKBJodUHvXewabhlicTxAzyYrqRSfj(urllib.parse.parse_qsl(kKBJodUHvXewabhlicTxAzyYrqRStP))
    kKBJodUHvXewabhlicTxAzyYrqRStD='contentid'
    kKBJodUHvXewabhlicTxAzyYrqRStn=kKBJodUHvXewabhlicTxAzyYrqRStP[kKBJodUHvXewabhlicTxAzyYrqRStD]
    kKBJodUHvXewabhlicTxAzyYrqRStp={'programtitle':kKBJodUHvXewabhlicTxAzyYrqRStm['title_list'][0]['text'],'episodetitle':kKBJodUHvXewabhlicTxAzyYrqRSCj.Get_ChangeText(kKBJodUHvXewabhlicTxAzyYrqRStm['title_list'][1]['text']),'age':kKBJodUHvXewabhlicTxAzyYrqRStm.get('age'),'thumbnail':kKBJodUHvXewabhlicTxAzyYrqRSCj.HTTPTAG+kKBJodUHvXewabhlicTxAzyYrqRStm.get('thumbnail'),'vidtype':kKBJodUHvXewabhlicTxAzyYrqRStD,'videoid':kKBJodUHvXewabhlicTxAzyYrqRStn}
    kKBJodUHvXewabhlicTxAzyYrqRSjC.append(kKBJodUHvXewabhlicTxAzyYrqRStp)
   kKBJodUHvXewabhlicTxAzyYrqRStN=kKBJodUHvXewabhlicTxAzyYrqRSfs(kKBJodUHvXewabhlicTxAzyYrqRSCD['cell_toplist']['pagecount'])
   if kKBJodUHvXewabhlicTxAzyYrqRSCD['cell_toplist']['count']:kKBJodUHvXewabhlicTxAzyYrqRStG =kKBJodUHvXewabhlicTxAzyYrqRSfs(kKBJodUHvXewabhlicTxAzyYrqRSCD['cell_toplist']['count'])
   else:kKBJodUHvXewabhlicTxAzyYrqRStG=kKBJodUHvXewabhlicTxAzyYrqRSCj.LIST_LIMIT*page_int
   kKBJodUHvXewabhlicTxAzyYrqRStQ=kKBJodUHvXewabhlicTxAzyYrqRStN>kKBJodUHvXewabhlicTxAzyYrqRStG
  except kKBJodUHvXewabhlicTxAzyYrqRSfC as exception:
   kKBJodUHvXewabhlicTxAzyYrqRSft(exception)
   return[],kKBJodUHvXewabhlicTxAzyYrqRSsP
  return kKBJodUHvXewabhlicTxAzyYrqRSjC,kKBJodUHvXewabhlicTxAzyYrqRStQ
 def Get_Program_List(kKBJodUHvXewabhlicTxAzyYrqRSCj,kKBJodUHvXewabhlicTxAzyYrqRStV,page_int=1,orderby='-'):
  kKBJodUHvXewabhlicTxAzyYrqRSjt=[]
  kKBJodUHvXewabhlicTxAzyYrqRStN=kKBJodUHvXewabhlicTxAzyYrqRStG=1
  kKBJodUHvXewabhlicTxAzyYrqRStQ=kKBJodUHvXewabhlicTxAzyYrqRSsP
  (kKBJodUHvXewabhlicTxAzyYrqRSCQ,kKBJodUHvXewabhlicTxAzyYrqRSCI)=kKBJodUHvXewabhlicTxAzyYrqRSCj.Baseapi_Parse(kKBJodUHvXewabhlicTxAzyYrqRStV)
  if kKBJodUHvXewabhlicTxAzyYrqRSCQ=='':return kKBJodUHvXewabhlicTxAzyYrqRSjt,kKBJodUHvXewabhlicTxAzyYrqRStQ
  try:
   kKBJodUHvXewabhlicTxAzyYrqRSCI['limit'] =kKBJodUHvXewabhlicTxAzyYrqRSCj.LIST_LIMIT
   kKBJodUHvXewabhlicTxAzyYrqRSCI['offset']=kKBJodUHvXewabhlicTxAzyYrqRSsG((page_int-1)*kKBJodUHvXewabhlicTxAzyYrqRSCj.LIST_LIMIT)
   kKBJodUHvXewabhlicTxAzyYrqRSCI['page'] =kKBJodUHvXewabhlicTxAzyYrqRSsG(page_int)
   if kKBJodUHvXewabhlicTxAzyYrqRSCI.get('orderby')!='' and kKBJodUHvXewabhlicTxAzyYrqRSCI.get('orderby')!='regdatefirst' and orderby!='-':
    kKBJodUHvXewabhlicTxAzyYrqRSCI['orderby']=orderby 
   kKBJodUHvXewabhlicTxAzyYrqRSCI.update(kKBJodUHvXewabhlicTxAzyYrqRSCj.GetDefaultParams(login=kKBJodUHvXewabhlicTxAzyYrqRSsP))
   kKBJodUHvXewabhlicTxAzyYrqRSCP=kKBJodUHvXewabhlicTxAzyYrqRSCj.callRequestCookies('Get',kKBJodUHvXewabhlicTxAzyYrqRSCQ,payload=kKBJodUHvXewabhlicTxAzyYrqRSsg,params=kKBJodUHvXewabhlicTxAzyYrqRSCI,headers=kKBJodUHvXewabhlicTxAzyYrqRSsg,cookies=kKBJodUHvXewabhlicTxAzyYrqRSsg)
   kKBJodUHvXewabhlicTxAzyYrqRSCD=json.loads(kKBJodUHvXewabhlicTxAzyYrqRSCP.text)
   if kKBJodUHvXewabhlicTxAzyYrqRStV.find('instantplay')>=0:
    if not('celllist' in kKBJodUHvXewabhlicTxAzyYrqRSCD['band']):return kKBJodUHvXewabhlicTxAzyYrqRSjt,kKBJodUHvXewabhlicTxAzyYrqRStQ
    kKBJodUHvXewabhlicTxAzyYrqRStE=kKBJodUHvXewabhlicTxAzyYrqRSCD['band']['celllist']
   else:
    if not('celllist' in kKBJodUHvXewabhlicTxAzyYrqRSCD['cell_toplist']):return kKBJodUHvXewabhlicTxAzyYrqRSjt,kKBJodUHvXewabhlicTxAzyYrqRStQ
    kKBJodUHvXewabhlicTxAzyYrqRStE=kKBJodUHvXewabhlicTxAzyYrqRSCD['cell_toplist']['celllist']
   for kKBJodUHvXewabhlicTxAzyYrqRStm in kKBJodUHvXewabhlicTxAzyYrqRStE:
    for kKBJodUHvXewabhlicTxAzyYrqRSjs in kKBJodUHvXewabhlicTxAzyYrqRStm['event_list']:
     if kKBJodUHvXewabhlicTxAzyYrqRSjs.get('type')=='on-navigation':
      kKBJodUHvXewabhlicTxAzyYrqRStg =kKBJodUHvXewabhlicTxAzyYrqRSjs['url']
    kKBJodUHvXewabhlicTxAzyYrqRStP=urllib.parse.urlsplit(kKBJodUHvXewabhlicTxAzyYrqRStg).query
    kKBJodUHvXewabhlicTxAzyYrqRStD=kKBJodUHvXewabhlicTxAzyYrqRStP[0:kKBJodUHvXewabhlicTxAzyYrqRStP.find('=')]
    kKBJodUHvXewabhlicTxAzyYrqRStn=kKBJodUHvXewabhlicTxAzyYrqRStP[kKBJodUHvXewabhlicTxAzyYrqRStP.find('=')+1:]
    kKBJodUHvXewabhlicTxAzyYrqRStp={'title':kKBJodUHvXewabhlicTxAzyYrqRStm['title_list'][0]['text'],'age':kKBJodUHvXewabhlicTxAzyYrqRStm['age'],'thumbnail':'https://%s'%kKBJodUHvXewabhlicTxAzyYrqRStm.get('thumbnail'),'videoid':kKBJodUHvXewabhlicTxAzyYrqRStn,'vidtype':kKBJodUHvXewabhlicTxAzyYrqRStD}
    kKBJodUHvXewabhlicTxAzyYrqRSjt.append(kKBJodUHvXewabhlicTxAzyYrqRStp)
   if kKBJodUHvXewabhlicTxAzyYrqRStV.find('instantplay')<0:
    kKBJodUHvXewabhlicTxAzyYrqRStN=kKBJodUHvXewabhlicTxAzyYrqRSfs(kKBJodUHvXewabhlicTxAzyYrqRSCD['cell_toplist']['pagecount'])
    if kKBJodUHvXewabhlicTxAzyYrqRSCD['cell_toplist']['count']:kKBJodUHvXewabhlicTxAzyYrqRStG =kKBJodUHvXewabhlicTxAzyYrqRSfs(kKBJodUHvXewabhlicTxAzyYrqRSCD['cell_toplist']['count'])
    else:kKBJodUHvXewabhlicTxAzyYrqRStG=kKBJodUHvXewabhlicTxAzyYrqRSCj.LIST_LIMIT*page_int
    kKBJodUHvXewabhlicTxAzyYrqRStQ=kKBJodUHvXewabhlicTxAzyYrqRStN>kKBJodUHvXewabhlicTxAzyYrqRStG
  except kKBJodUHvXewabhlicTxAzyYrqRSfC as exception:
   kKBJodUHvXewabhlicTxAzyYrqRSft(exception)
   return[],kKBJodUHvXewabhlicTxAzyYrqRSsP
  return kKBJodUHvXewabhlicTxAzyYrqRSjt,kKBJodUHvXewabhlicTxAzyYrqRStQ
 def Get_Movie_List(kKBJodUHvXewabhlicTxAzyYrqRSCj,kKBJodUHvXewabhlicTxAzyYrqRStV,page_int=1):
  kKBJodUHvXewabhlicTxAzyYrqRSjf=[]
  kKBJodUHvXewabhlicTxAzyYrqRStN=kKBJodUHvXewabhlicTxAzyYrqRStG=1
  kKBJodUHvXewabhlicTxAzyYrqRStQ=kKBJodUHvXewabhlicTxAzyYrqRSsP
  (kKBJodUHvXewabhlicTxAzyYrqRSCQ,kKBJodUHvXewabhlicTxAzyYrqRSCI)=kKBJodUHvXewabhlicTxAzyYrqRSCj.Baseapi_Parse(kKBJodUHvXewabhlicTxAzyYrqRStV)
  if kKBJodUHvXewabhlicTxAzyYrqRSCQ=='':return kKBJodUHvXewabhlicTxAzyYrqRSjf,kKBJodUHvXewabhlicTxAzyYrqRStQ
  try:
   kKBJodUHvXewabhlicTxAzyYrqRSCI['limit']=kKBJodUHvXewabhlicTxAzyYrqRSCj.MV_LIMIT
   kKBJodUHvXewabhlicTxAzyYrqRSCI['offset']=kKBJodUHvXewabhlicTxAzyYrqRSsG((page_int-1)*kKBJodUHvXewabhlicTxAzyYrqRSCj.MV_LIMIT)
   kKBJodUHvXewabhlicTxAzyYrqRSCI.update(kKBJodUHvXewabhlicTxAzyYrqRSCj.GetDefaultParams(login=kKBJodUHvXewabhlicTxAzyYrqRSsP))
   kKBJodUHvXewabhlicTxAzyYrqRSCP=kKBJodUHvXewabhlicTxAzyYrqRSCj.callRequestCookies('Get',kKBJodUHvXewabhlicTxAzyYrqRSCQ,payload=kKBJodUHvXewabhlicTxAzyYrqRSsg,params=kKBJodUHvXewabhlicTxAzyYrqRSCI,headers=kKBJodUHvXewabhlicTxAzyYrqRSsg,cookies=kKBJodUHvXewabhlicTxAzyYrqRSsg)
   kKBJodUHvXewabhlicTxAzyYrqRSCD=json.loads(kKBJodUHvXewabhlicTxAzyYrqRSCP.text)
   if not('celllist' in kKBJodUHvXewabhlicTxAzyYrqRSCD['cell_toplist']):return kKBJodUHvXewabhlicTxAzyYrqRSjf,kKBJodUHvXewabhlicTxAzyYrqRStQ
   kKBJodUHvXewabhlicTxAzyYrqRStE=kKBJodUHvXewabhlicTxAzyYrqRSCD['cell_toplist']['celllist']
   for kKBJodUHvXewabhlicTxAzyYrqRStm in kKBJodUHvXewabhlicTxAzyYrqRStE:
    kKBJodUHvXewabhlicTxAzyYrqRStg =kKBJodUHvXewabhlicTxAzyYrqRStm['event_list'][1]['url']
    kKBJodUHvXewabhlicTxAzyYrqRStP=urllib.parse.urlsplit(kKBJodUHvXewabhlicTxAzyYrqRStg).query
    kKBJodUHvXewabhlicTxAzyYrqRStD=kKBJodUHvXewabhlicTxAzyYrqRStP[0:kKBJodUHvXewabhlicTxAzyYrqRStP.find('=')]
    kKBJodUHvXewabhlicTxAzyYrqRStn=kKBJodUHvXewabhlicTxAzyYrqRStP[kKBJodUHvXewabhlicTxAzyYrqRStP.find('=')+1:]
    kKBJodUHvXewabhlicTxAzyYrqRStp={'title':kKBJodUHvXewabhlicTxAzyYrqRStm['title_list'][0]['text'],'age':kKBJodUHvXewabhlicTxAzyYrqRStm['age'],'thumbnail':'https://%s'%kKBJodUHvXewabhlicTxAzyYrqRStm.get('thumbnail'),'videoid':kKBJodUHvXewabhlicTxAzyYrqRStn,'vidtype':kKBJodUHvXewabhlicTxAzyYrqRStD}
    kKBJodUHvXewabhlicTxAzyYrqRSjf.append(kKBJodUHvXewabhlicTxAzyYrqRStp)
   kKBJodUHvXewabhlicTxAzyYrqRStN=kKBJodUHvXewabhlicTxAzyYrqRSfs(kKBJodUHvXewabhlicTxAzyYrqRSCD['cell_toplist']['pagecount'])
   if kKBJodUHvXewabhlicTxAzyYrqRSCD['cell_toplist']['count']:kKBJodUHvXewabhlicTxAzyYrqRStG =kKBJodUHvXewabhlicTxAzyYrqRSfs(kKBJodUHvXewabhlicTxAzyYrqRSCD['cell_toplist']['count'])
   else:kKBJodUHvXewabhlicTxAzyYrqRStG=kKBJodUHvXewabhlicTxAzyYrqRSCj.MV_LIMIT*page_int
   kKBJodUHvXewabhlicTxAzyYrqRStQ=kKBJodUHvXewabhlicTxAzyYrqRStN>kKBJodUHvXewabhlicTxAzyYrqRStG
  except kKBJodUHvXewabhlicTxAzyYrqRSfC as exception:
   kKBJodUHvXewabhlicTxAzyYrqRSft(exception)
   return[],kKBJodUHvXewabhlicTxAzyYrqRSsP
  return kKBJodUHvXewabhlicTxAzyYrqRSjf,kKBJodUHvXewabhlicTxAzyYrqRStQ
 def ProgramidToContentid(kKBJodUHvXewabhlicTxAzyYrqRSCj,kKBJodUHvXewabhlicTxAzyYrqRSjE):
  kKBJodUHvXewabhlicTxAzyYrqRSjV=''
  try:
   kKBJodUHvXewabhlicTxAzyYrqRSCQ =kKBJodUHvXewabhlicTxAzyYrqRSCj.API_DOMAIN+'/vod/programs-contentid/'+kKBJodUHvXewabhlicTxAzyYrqRSjE
   kKBJodUHvXewabhlicTxAzyYrqRSCI=kKBJodUHvXewabhlicTxAzyYrqRSCj.GetDefaultParams(login=kKBJodUHvXewabhlicTxAzyYrqRSsP)
   kKBJodUHvXewabhlicTxAzyYrqRSCP=kKBJodUHvXewabhlicTxAzyYrqRSCj.callRequestCookies('Get',kKBJodUHvXewabhlicTxAzyYrqRSCQ,payload=kKBJodUHvXewabhlicTxAzyYrqRSsg,params=kKBJodUHvXewabhlicTxAzyYrqRSCI,headers=kKBJodUHvXewabhlicTxAzyYrqRSsg,cookies=kKBJodUHvXewabhlicTxAzyYrqRSsg)
   kKBJodUHvXewabhlicTxAzyYrqRSjI=json.loads(kKBJodUHvXewabhlicTxAzyYrqRSCP.text)
   if not('contentid' in kKBJodUHvXewabhlicTxAzyYrqRSjI):return kKBJodUHvXewabhlicTxAzyYrqRSjV 
   kKBJodUHvXewabhlicTxAzyYrqRSjV=kKBJodUHvXewabhlicTxAzyYrqRSjI['contentid']
  except kKBJodUHvXewabhlicTxAzyYrqRSfC as exception:
   kKBJodUHvXewabhlicTxAzyYrqRSft(exception)
  return kKBJodUHvXewabhlicTxAzyYrqRSjV
 def ContentidToProgramid(kKBJodUHvXewabhlicTxAzyYrqRSCj,kKBJodUHvXewabhlicTxAzyYrqRSjV):
  kKBJodUHvXewabhlicTxAzyYrqRSjE=''
  try:
   kKBJodUHvXewabhlicTxAzyYrqRSCQ =kKBJodUHvXewabhlicTxAzyYrqRSCj.API_DOMAIN+'/cf/vod/contents/'+kKBJodUHvXewabhlicTxAzyYrqRSjV
   kKBJodUHvXewabhlicTxAzyYrqRSCI=kKBJodUHvXewabhlicTxAzyYrqRSCj.GetDefaultParams(login=kKBJodUHvXewabhlicTxAzyYrqRSsP)
   kKBJodUHvXewabhlicTxAzyYrqRSCP=kKBJodUHvXewabhlicTxAzyYrqRSCj.callRequestCookies('Get',kKBJodUHvXewabhlicTxAzyYrqRSCQ,payload=kKBJodUHvXewabhlicTxAzyYrqRSsg,params=kKBJodUHvXewabhlicTxAzyYrqRSCI,headers=kKBJodUHvXewabhlicTxAzyYrqRSsg,cookies=kKBJodUHvXewabhlicTxAzyYrqRSsg)
   kKBJodUHvXewabhlicTxAzyYrqRSjI=json.loads(kKBJodUHvXewabhlicTxAzyYrqRSCP.text)
   if not('programid' in kKBJodUHvXewabhlicTxAzyYrqRSjI):return kKBJodUHvXewabhlicTxAzyYrqRSjE 
   kKBJodUHvXewabhlicTxAzyYrqRSjE=kKBJodUHvXewabhlicTxAzyYrqRSjI['programid']
  except kKBJodUHvXewabhlicTxAzyYrqRSfC as exception:
   kKBJodUHvXewabhlicTxAzyYrqRSft(exception)
  return kKBJodUHvXewabhlicTxAzyYrqRSjE
 def GetProgramInfo(kKBJodUHvXewabhlicTxAzyYrqRSCj,program_code):
  kKBJodUHvXewabhlicTxAzyYrqRSjm={}
  try:
   kKBJodUHvXewabhlicTxAzyYrqRSCQ=kKBJodUHvXewabhlicTxAzyYrqRSCj.API_DOMAIN+'/cf/vod/contents/'+program_code
   kKBJodUHvXewabhlicTxAzyYrqRSCI=kKBJodUHvXewabhlicTxAzyYrqRSCj.GetDefaultParams(login=kKBJodUHvXewabhlicTxAzyYrqRSsP)
   kKBJodUHvXewabhlicTxAzyYrqRSCP=kKBJodUHvXewabhlicTxAzyYrqRSCj.callRequestCookies('Get',kKBJodUHvXewabhlicTxAzyYrqRSCQ,payload=kKBJodUHvXewabhlicTxAzyYrqRSsg,params=kKBJodUHvXewabhlicTxAzyYrqRSCI,headers=kKBJodUHvXewabhlicTxAzyYrqRSsg,cookies=kKBJodUHvXewabhlicTxAzyYrqRSsg)
   kKBJodUHvXewabhlicTxAzyYrqRSjI=json.loads(kKBJodUHvXewabhlicTxAzyYrqRSCP.text)
   kKBJodUHvXewabhlicTxAzyYrqRSft(kKBJodUHvXewabhlicTxAzyYrqRSjI)
   kKBJodUHvXewabhlicTxAzyYrqRSjp=img_fanart=kKBJodUHvXewabhlicTxAzyYrqRSjO=''
   if kKBJodUHvXewabhlicTxAzyYrqRSjI.get('programposterimage')!='':kKBJodUHvXewabhlicTxAzyYrqRSjp =kKBJodUHvXewabhlicTxAzyYrqRSCj.HTTPTAG+kKBJodUHvXewabhlicTxAzyYrqRSjI.get('programposterimage')
   if kKBJodUHvXewabhlicTxAzyYrqRSjI.get('programimage') !='':img_fanart =kKBJodUHvXewabhlicTxAzyYrqRSCj.HTTPTAG+kKBJodUHvXewabhlicTxAzyYrqRSjI.get('programimage')
   if kKBJodUHvXewabhlicTxAzyYrqRSjI.get('programcirlceimage')!='':kKBJodUHvXewabhlicTxAzyYrqRSjO=kKBJodUHvXewabhlicTxAzyYrqRSCj.HTTPTAG+kKBJodUHvXewabhlicTxAzyYrqRSjI.get('programcirlceimage')
   if 'poster_default' in kKBJodUHvXewabhlicTxAzyYrqRSjp:
    kKBJodUHvXewabhlicTxAzyYrqRSjp =img_fanart
    kKBJodUHvXewabhlicTxAzyYrqRSjO=''
   kKBJodUHvXewabhlicTxAzyYrqRSjm={'imgPoster':kKBJodUHvXewabhlicTxAzyYrqRSjp,'imgFanart':img_fanart,'imgClearlogo':kKBJodUHvXewabhlicTxAzyYrqRSjO}
  except kKBJodUHvXewabhlicTxAzyYrqRSfC as exception:
   kKBJodUHvXewabhlicTxAzyYrqRSft(exception)
  return kKBJodUHvXewabhlicTxAzyYrqRSjm
 def Get_Episode_List(kKBJodUHvXewabhlicTxAzyYrqRSCj,kKBJodUHvXewabhlicTxAzyYrqRStn,kKBJodUHvXewabhlicTxAzyYrqRStD,page_int=1,orderby='desc'):
  kKBJodUHvXewabhlicTxAzyYrqRSju=[]
  kKBJodUHvXewabhlicTxAzyYrqRStN=kKBJodUHvXewabhlicTxAzyYrqRStG=1
  kKBJodUHvXewabhlicTxAzyYrqRStQ=kKBJodUHvXewabhlicTxAzyYrqRSsP
  kKBJodUHvXewabhlicTxAzyYrqRSjM={}
  if kKBJodUHvXewabhlicTxAzyYrqRStD=='contentid':
   kKBJodUHvXewabhlicTxAzyYrqRSjE=kKBJodUHvXewabhlicTxAzyYrqRSCj.ContentidToProgramid(kKBJodUHvXewabhlicTxAzyYrqRStn)
   kKBJodUHvXewabhlicTxAzyYrqRSjM=kKBJodUHvXewabhlicTxAzyYrqRSCj.GetProgramInfo(kKBJodUHvXewabhlicTxAzyYrqRStn)
  else:
   kKBJodUHvXewabhlicTxAzyYrqRSjE=kKBJodUHvXewabhlicTxAzyYrqRStn
   kKBJodUHvXewabhlicTxAzyYrqRSjV=kKBJodUHvXewabhlicTxAzyYrqRSCj.ProgramidToContentid(kKBJodUHvXewabhlicTxAzyYrqRStn)
   if kKBJodUHvXewabhlicTxAzyYrqRSjV!='':kKBJodUHvXewabhlicTxAzyYrqRSjM=kKBJodUHvXewabhlicTxAzyYrqRSCj.GetProgramInfo(kKBJodUHvXewabhlicTxAzyYrqRSjV)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   kKBJodUHvXewabhlicTxAzyYrqRSCQ=kKBJodUHvXewabhlicTxAzyYrqRSCj.API_DOMAIN+'/vod/programs-contents/'+kKBJodUHvXewabhlicTxAzyYrqRSjE
   kKBJodUHvXewabhlicTxAzyYrqRSCI={}
   kKBJodUHvXewabhlicTxAzyYrqRSCI['limit'] =kKBJodUHvXewabhlicTxAzyYrqRSCj.EP_LIMIT
   kKBJodUHvXewabhlicTxAzyYrqRSCI['offset']=kKBJodUHvXewabhlicTxAzyYrqRSsG((page_int-1)*kKBJodUHvXewabhlicTxAzyYrqRSCj.EP_LIMIT)
   kKBJodUHvXewabhlicTxAzyYrqRSCI['orderby']=orderby 
   kKBJodUHvXewabhlicTxAzyYrqRSCI.update(kKBJodUHvXewabhlicTxAzyYrqRSCj.GetDefaultParams(login=kKBJodUHvXewabhlicTxAzyYrqRSsP))
   kKBJodUHvXewabhlicTxAzyYrqRSCP=kKBJodUHvXewabhlicTxAzyYrqRSCj.callRequestCookies('Get',kKBJodUHvXewabhlicTxAzyYrqRSCQ,payload=kKBJodUHvXewabhlicTxAzyYrqRSsg,params=kKBJodUHvXewabhlicTxAzyYrqRSCI,headers=kKBJodUHvXewabhlicTxAzyYrqRSsg,cookies=kKBJodUHvXewabhlicTxAzyYrqRSsg)
   kKBJodUHvXewabhlicTxAzyYrqRSCD=json.loads(kKBJodUHvXewabhlicTxAzyYrqRSCP.text)
   kKBJodUHvXewabhlicTxAzyYrqRStE=kKBJodUHvXewabhlicTxAzyYrqRSCD['list']
   for kKBJodUHvXewabhlicTxAzyYrqRStm in kKBJodUHvXewabhlicTxAzyYrqRStE:
    kKBJodUHvXewabhlicTxAzyYrqRSjF=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',kKBJodUHvXewabhlicTxAzyYrqRStm.get('synopsis'))
    kKBJodUHvXewabhlicTxAzyYrqRSjW=kKBJodUHvXewabhlicTxAzyYrqRSCj.HTTPTAG+kKBJodUHvXewabhlicTxAzyYrqRStm.get('image')
    kKBJodUHvXewabhlicTxAzyYrqRSjN=kKBJodUHvXewabhlicTxAzyYrqRSjQ=kKBJodUHvXewabhlicTxAzyYrqRSjg=''
    if kKBJodUHvXewabhlicTxAzyYrqRSjM!={}:
     kKBJodUHvXewabhlicTxAzyYrqRSjN =kKBJodUHvXewabhlicTxAzyYrqRSjM.get('imgPoster')
     kKBJodUHvXewabhlicTxAzyYrqRSjQ =kKBJodUHvXewabhlicTxAzyYrqRSjM.get('imgFanart')
     kKBJodUHvXewabhlicTxAzyYrqRSjg=kKBJodUHvXewabhlicTxAzyYrqRSjM.get('imgClearlogo')
     kKBJodUHvXewabhlicTxAzyYrqRSjP={'thumb':kKBJodUHvXewabhlicTxAzyYrqRSjW,'poster':kKBJodUHvXewabhlicTxAzyYrqRSjN,'fanart':kKBJodUHvXewabhlicTxAzyYrqRSjQ,'clearlogo':kKBJodUHvXewabhlicTxAzyYrqRSjg}
    else:
     kKBJodUHvXewabhlicTxAzyYrqRSjP=kKBJodUHvXewabhlicTxAzyYrqRSjW
    kKBJodUHvXewabhlicTxAzyYrqRStp={'programtitle':kKBJodUHvXewabhlicTxAzyYrqRStm.get('programtitle'),'episodetitle':kKBJodUHvXewabhlicTxAzyYrqRStm.get('episodetitle'),'episodenumber':kKBJodUHvXewabhlicTxAzyYrqRStm.get('episodenumber'),'releasedate':kKBJodUHvXewabhlicTxAzyYrqRStm.get('releasedate'),'releaseweekday':kKBJodUHvXewabhlicTxAzyYrqRStm.get('releaseweekday'),'programid':kKBJodUHvXewabhlicTxAzyYrqRStm.get('programid'),'contentid':kKBJodUHvXewabhlicTxAzyYrqRStm.get('contentid'),'age':kKBJodUHvXewabhlicTxAzyYrqRStm.get('targetage'),'playtime':kKBJodUHvXewabhlicTxAzyYrqRStm.get('playtime'),'synopsis':kKBJodUHvXewabhlicTxAzyYrqRSjF,'episodeactors':kKBJodUHvXewabhlicTxAzyYrqRStm.get('episodeactors').split(',')if kKBJodUHvXewabhlicTxAzyYrqRStm.get('episodeactors')!='' else[],'thumbnail':kKBJodUHvXewabhlicTxAzyYrqRSjP}
    kKBJodUHvXewabhlicTxAzyYrqRSju.append(kKBJodUHvXewabhlicTxAzyYrqRStp)
   kKBJodUHvXewabhlicTxAzyYrqRStN=kKBJodUHvXewabhlicTxAzyYrqRSfs(kKBJodUHvXewabhlicTxAzyYrqRSCD['pagecount'])
   if kKBJodUHvXewabhlicTxAzyYrqRSCD['count']:kKBJodUHvXewabhlicTxAzyYrqRStG =kKBJodUHvXewabhlicTxAzyYrqRSfs(kKBJodUHvXewabhlicTxAzyYrqRSCD['count'])
   else:kKBJodUHvXewabhlicTxAzyYrqRStG=kKBJodUHvXewabhlicTxAzyYrqRSCj.EP_LIMIT*page_int
   kKBJodUHvXewabhlicTxAzyYrqRStQ=kKBJodUHvXewabhlicTxAzyYrqRStN>kKBJodUHvXewabhlicTxAzyYrqRStG
  except kKBJodUHvXewabhlicTxAzyYrqRSfC as exception:
   kKBJodUHvXewabhlicTxAzyYrqRSft(exception)
   return[],kKBJodUHvXewabhlicTxAzyYrqRSsP
  return kKBJodUHvXewabhlicTxAzyYrqRSju,kKBJodUHvXewabhlicTxAzyYrqRStQ
 def GetEPGList(kKBJodUHvXewabhlicTxAzyYrqRSCj,genre):
  kKBJodUHvXewabhlicTxAzyYrqRSjD={}
  try:
   kKBJodUHvXewabhlicTxAzyYrqRSjn=kKBJodUHvXewabhlicTxAzyYrqRSCj.Get_Now_Datetime()
   if genre=='all':
    kKBJodUHvXewabhlicTxAzyYrqRSjG =kKBJodUHvXewabhlicTxAzyYrqRSjn+datetime.timedelta(hours=3)
   else:
    kKBJodUHvXewabhlicTxAzyYrqRSjG =kKBJodUHvXewabhlicTxAzyYrqRSjn+datetime.timedelta(hours=3)
   kKBJodUHvXewabhlicTxAzyYrqRSCQ=kKBJodUHvXewabhlicTxAzyYrqRSCj.API_DOMAIN+'/live/epgs'
   kKBJodUHvXewabhlicTxAzyYrqRSCI={'limit':'100','offset':'0','genre':genre,'startdatetime':kKBJodUHvXewabhlicTxAzyYrqRSjn.strftime('%Y-%m-%d %H:00'),'enddatetime':kKBJodUHvXewabhlicTxAzyYrqRSjG.strftime('%Y-%m-%d %H:00')}
   kKBJodUHvXewabhlicTxAzyYrqRSCI.update(kKBJodUHvXewabhlicTxAzyYrqRSCj.GetDefaultParams(login=kKBJodUHvXewabhlicTxAzyYrqRSsP))
   kKBJodUHvXewabhlicTxAzyYrqRSCP=kKBJodUHvXewabhlicTxAzyYrqRSCj.callRequestCookies('Get',kKBJodUHvXewabhlicTxAzyYrqRSCQ,payload=kKBJodUHvXewabhlicTxAzyYrqRSsg,params=kKBJodUHvXewabhlicTxAzyYrqRSCI,headers=kKBJodUHvXewabhlicTxAzyYrqRSsg,cookies=kKBJodUHvXewabhlicTxAzyYrqRSsg)
   kKBJodUHvXewabhlicTxAzyYrqRSCD=json.loads(kKBJodUHvXewabhlicTxAzyYrqRSCP.text)
   kKBJodUHvXewabhlicTxAzyYrqRSsC=kKBJodUHvXewabhlicTxAzyYrqRSCD['list']
   for kKBJodUHvXewabhlicTxAzyYrqRStm in kKBJodUHvXewabhlicTxAzyYrqRSsC:
    kKBJodUHvXewabhlicTxAzyYrqRSst=''
    for kKBJodUHvXewabhlicTxAzyYrqRSsj in kKBJodUHvXewabhlicTxAzyYrqRStm['list']:
     if kKBJodUHvXewabhlicTxAzyYrqRSst:kKBJodUHvXewabhlicTxAzyYrqRSst+='\n'
     kKBJodUHvXewabhlicTxAzyYrqRSst+=kKBJodUHvXewabhlicTxAzyYrqRSCj.Get_ChangeText(kKBJodUHvXewabhlicTxAzyYrqRSsj['title'])+'\n'
     kKBJodUHvXewabhlicTxAzyYrqRSst+=' [%s ~ %s]'%(kKBJodUHvXewabhlicTxAzyYrqRSsj['starttime'][-5:],kKBJodUHvXewabhlicTxAzyYrqRSsj['endtime'][-5:])+'\n'
    kKBJodUHvXewabhlicTxAzyYrqRSjD[kKBJodUHvXewabhlicTxAzyYrqRStm['channelid']]=kKBJodUHvXewabhlicTxAzyYrqRSst
  except kKBJodUHvXewabhlicTxAzyYrqRSfC as exception:
   kKBJodUHvXewabhlicTxAzyYrqRSft(exception)
  return kKBJodUHvXewabhlicTxAzyYrqRSjD
 def Get_LiveChannel_List(kKBJodUHvXewabhlicTxAzyYrqRSCj,genre,kKBJodUHvXewabhlicTxAzyYrqRStV):
  kKBJodUHvXewabhlicTxAzyYrqRStW=[]
  (kKBJodUHvXewabhlicTxAzyYrqRSCQ,kKBJodUHvXewabhlicTxAzyYrqRSCI)=kKBJodUHvXewabhlicTxAzyYrqRSCj.Baseapi_Parse(kKBJodUHvXewabhlicTxAzyYrqRStV)
  if kKBJodUHvXewabhlicTxAzyYrqRSCQ=='':return kKBJodUHvXewabhlicTxAzyYrqRStW
  kKBJodUHvXewabhlicTxAzyYrqRSsf=kKBJodUHvXewabhlicTxAzyYrqRSCj.GetEPGList(genre)
  try:
   kKBJodUHvXewabhlicTxAzyYrqRSCI.update(kKBJodUHvXewabhlicTxAzyYrqRSCj.GetDefaultParams(login=kKBJodUHvXewabhlicTxAzyYrqRSsP))
   kKBJodUHvXewabhlicTxAzyYrqRSCI['genre']=genre
   kKBJodUHvXewabhlicTxAzyYrqRSCP=kKBJodUHvXewabhlicTxAzyYrqRSCj.callRequestCookies('Get',kKBJodUHvXewabhlicTxAzyYrqRSCQ,payload=kKBJodUHvXewabhlicTxAzyYrqRSsg,params=kKBJodUHvXewabhlicTxAzyYrqRSCI,headers=kKBJodUHvXewabhlicTxAzyYrqRSsg,cookies=kKBJodUHvXewabhlicTxAzyYrqRSsg)
   kKBJodUHvXewabhlicTxAzyYrqRSCD=json.loads(kKBJodUHvXewabhlicTxAzyYrqRSCP.text)
   if not('celllist' in kKBJodUHvXewabhlicTxAzyYrqRSCD['cell_toplist']):return[]
   kKBJodUHvXewabhlicTxAzyYrqRStE=kKBJodUHvXewabhlicTxAzyYrqRSCD['cell_toplist']['celllist']
   for kKBJodUHvXewabhlicTxAzyYrqRStm in kKBJodUHvXewabhlicTxAzyYrqRStE:
    kKBJodUHvXewabhlicTxAzyYrqRSjV=kKBJodUHvXewabhlicTxAzyYrqRStm['contentid']
    if kKBJodUHvXewabhlicTxAzyYrqRSjV in kKBJodUHvXewabhlicTxAzyYrqRSsf:
     kKBJodUHvXewabhlicTxAzyYrqRSsV=kKBJodUHvXewabhlicTxAzyYrqRSsf[kKBJodUHvXewabhlicTxAzyYrqRSjV]
    else:
     kKBJodUHvXewabhlicTxAzyYrqRSsV=''
    kKBJodUHvXewabhlicTxAzyYrqRStp={'studio':kKBJodUHvXewabhlicTxAzyYrqRStm['title_list'][0]['text'],'tvshowtitle':kKBJodUHvXewabhlicTxAzyYrqRSCj.Get_ChangeText(kKBJodUHvXewabhlicTxAzyYrqRStm['title_list'][1]['text']),'channelid':kKBJodUHvXewabhlicTxAzyYrqRSjV,'age':kKBJodUHvXewabhlicTxAzyYrqRStm['age'],'thumbnail':'https://%s'%kKBJodUHvXewabhlicTxAzyYrqRStm.get('thumbnail'),'epg':kKBJodUHvXewabhlicTxAzyYrqRSsV}
    kKBJodUHvXewabhlicTxAzyYrqRStW.append(kKBJodUHvXewabhlicTxAzyYrqRStp)
  except kKBJodUHvXewabhlicTxAzyYrqRSfC as exception:
   kKBJodUHvXewabhlicTxAzyYrqRSft(exception)
   return[]
  return kKBJodUHvXewabhlicTxAzyYrqRStW
 def Get_Search_List(kKBJodUHvXewabhlicTxAzyYrqRSCj,search_key,sType,page_int,exclusion21=kKBJodUHvXewabhlicTxAzyYrqRSsP):
  kKBJodUHvXewabhlicTxAzyYrqRSsI=[]
  kKBJodUHvXewabhlicTxAzyYrqRStN=kKBJodUHvXewabhlicTxAzyYrqRStG=1
  kKBJodUHvXewabhlicTxAzyYrqRStQ=kKBJodUHvXewabhlicTxAzyYrqRSsP
  try:
   kKBJodUHvXewabhlicTxAzyYrqRSCQ=kKBJodUHvXewabhlicTxAzyYrqRSCj.API_DOMAIN+'/cf/search/list.js'
   kKBJodUHvXewabhlicTxAzyYrqRSCI={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':kKBJodUHvXewabhlicTxAzyYrqRSsG((page_int-1)*kKBJodUHvXewabhlicTxAzyYrqRSCj.LIST_LIMIT),'limit':kKBJodUHvXewabhlicTxAzyYrqRSCj.LIST_LIMIT,'orderby':'score'}
   kKBJodUHvXewabhlicTxAzyYrqRSCI.update(kKBJodUHvXewabhlicTxAzyYrqRSCj.GetDefaultParams(login=kKBJodUHvXewabhlicTxAzyYrqRSsP))
   kKBJodUHvXewabhlicTxAzyYrqRSCP=kKBJodUHvXewabhlicTxAzyYrqRSCj.callRequestCookies('Get',kKBJodUHvXewabhlicTxAzyYrqRSCQ,payload=kKBJodUHvXewabhlicTxAzyYrqRSsg,params=kKBJodUHvXewabhlicTxAzyYrqRSCI,headers=kKBJodUHvXewabhlicTxAzyYrqRSsg,cookies=kKBJodUHvXewabhlicTxAzyYrqRSsg)
   kKBJodUHvXewabhlicTxAzyYrqRSjI=json.loads(kKBJodUHvXewabhlicTxAzyYrqRSCP.text)
   if not('celllist' in kKBJodUHvXewabhlicTxAzyYrqRSjI['cell_toplist']):return kKBJodUHvXewabhlicTxAzyYrqRSsI,kKBJodUHvXewabhlicTxAzyYrqRStQ
   kKBJodUHvXewabhlicTxAzyYrqRStE=kKBJodUHvXewabhlicTxAzyYrqRSjI['cell_toplist']['celllist']
   for kKBJodUHvXewabhlicTxAzyYrqRStm in kKBJodUHvXewabhlicTxAzyYrqRStE:
    kKBJodUHvXewabhlicTxAzyYrqRStg =kKBJodUHvXewabhlicTxAzyYrqRStm['event_list'][1]['url']
    kKBJodUHvXewabhlicTxAzyYrqRStP=urllib.parse.urlsplit(kKBJodUHvXewabhlicTxAzyYrqRStg).query
    kKBJodUHvXewabhlicTxAzyYrqRStD=kKBJodUHvXewabhlicTxAzyYrqRStP[0:kKBJodUHvXewabhlicTxAzyYrqRStP.find('=')]
    kKBJodUHvXewabhlicTxAzyYrqRStn=kKBJodUHvXewabhlicTxAzyYrqRStP[kKBJodUHvXewabhlicTxAzyYrqRStP.find('=')+1:]
    kKBJodUHvXewabhlicTxAzyYrqRStp={'title':kKBJodUHvXewabhlicTxAzyYrqRStm['title_list'][0]['text'],'age':kKBJodUHvXewabhlicTxAzyYrqRStm['age'],'thumbnail':'https://%s'%kKBJodUHvXewabhlicTxAzyYrqRStm.get('thumbnail'),'videoid':kKBJodUHvXewabhlicTxAzyYrqRStn,'vidtype':kKBJodUHvXewabhlicTxAzyYrqRStD}
    if exclusion21==kKBJodUHvXewabhlicTxAzyYrqRSsP or kKBJodUHvXewabhlicTxAzyYrqRStm.get('age')!='21':
     kKBJodUHvXewabhlicTxAzyYrqRSsI.append(kKBJodUHvXewabhlicTxAzyYrqRStp)
   kKBJodUHvXewabhlicTxAzyYrqRStN=kKBJodUHvXewabhlicTxAzyYrqRSfs(kKBJodUHvXewabhlicTxAzyYrqRSjI['cell_toplist']['pagecount'])
   if kKBJodUHvXewabhlicTxAzyYrqRSjI['cell_toplist']['count']:kKBJodUHvXewabhlicTxAzyYrqRStG =kKBJodUHvXewabhlicTxAzyYrqRSfs(kKBJodUHvXewabhlicTxAzyYrqRSjI['cell_toplist']['count'])
   else:kKBJodUHvXewabhlicTxAzyYrqRStG=kKBJodUHvXewabhlicTxAzyYrqRSCj.LIST_LIMIT
   kKBJodUHvXewabhlicTxAzyYrqRStQ=kKBJodUHvXewabhlicTxAzyYrqRStN>kKBJodUHvXewabhlicTxAzyYrqRStG
  except kKBJodUHvXewabhlicTxAzyYrqRSfC as exception:
   kKBJodUHvXewabhlicTxAzyYrqRSft(exception)
  return kKBJodUHvXewabhlicTxAzyYrqRSsI,kKBJodUHvXewabhlicTxAzyYrqRStQ 
 def GetStreamingURL(kKBJodUHvXewabhlicTxAzyYrqRSCj,mode,kKBJodUHvXewabhlicTxAzyYrqRSjV,quality_int,pvrmode='-'):
  kKBJodUHvXewabhlicTxAzyYrqRSsE=kKBJodUHvXewabhlicTxAzyYrqRSsW=kKBJodUHvXewabhlicTxAzyYrqRSsN=streaming_preview=''
  kKBJodUHvXewabhlicTxAzyYrqRSsm=[]
  kKBJodUHvXewabhlicTxAzyYrqRSsp='hls'
  if mode=='LIVE':
   kKBJodUHvXewabhlicTxAzyYrqRSCQ =kKBJodUHvXewabhlicTxAzyYrqRSCj.API_DOMAIN+'/live/channels/'+kKBJodUHvXewabhlicTxAzyYrqRSjV
   kKBJodUHvXewabhlicTxAzyYrqRSsO='live'
  elif mode=='VOD':
   kKBJodUHvXewabhlicTxAzyYrqRSCQ =kKBJodUHvXewabhlicTxAzyYrqRSCj.API_DOMAIN+'/cf/vod/contents/'+kKBJodUHvXewabhlicTxAzyYrqRSjV
   kKBJodUHvXewabhlicTxAzyYrqRSsO='vod'
  elif mode=='MOVIE':
   kKBJodUHvXewabhlicTxAzyYrqRSCQ =kKBJodUHvXewabhlicTxAzyYrqRSCj.API_DOMAIN+'/cf/movie/contents/'+kKBJodUHvXewabhlicTxAzyYrqRSjV
   kKBJodUHvXewabhlicTxAzyYrqRSsO='movie'
  try:
   if mode!='LIVE' or pvrmode=='-':
    kKBJodUHvXewabhlicTxAzyYrqRSCI=kKBJodUHvXewabhlicTxAzyYrqRSCj.GetDefaultParams(login=kKBJodUHvXewabhlicTxAzyYrqRSsP)
    kKBJodUHvXewabhlicTxAzyYrqRSCP=kKBJodUHvXewabhlicTxAzyYrqRSCj.callRequestCookies('Get',kKBJodUHvXewabhlicTxAzyYrqRSCQ,payload=kKBJodUHvXewabhlicTxAzyYrqRSsg,params=kKBJodUHvXewabhlicTxAzyYrqRSCI,headers=kKBJodUHvXewabhlicTxAzyYrqRSsg,cookies=kKBJodUHvXewabhlicTxAzyYrqRSsg)
    kKBJodUHvXewabhlicTxAzyYrqRSCD=json.loads(kKBJodUHvXewabhlicTxAzyYrqRSCP.text)
    kKBJodUHvXewabhlicTxAzyYrqRSsu=kKBJodUHvXewabhlicTxAzyYrqRSCD['qualities']['list']
    if kKBJodUHvXewabhlicTxAzyYrqRSsu==kKBJodUHvXewabhlicTxAzyYrqRSsg:return(kKBJodUHvXewabhlicTxAzyYrqRSsE,kKBJodUHvXewabhlicTxAzyYrqRSsW,kKBJodUHvXewabhlicTxAzyYrqRSsN,streaming_preview)
    for kKBJodUHvXewabhlicTxAzyYrqRSsM in kKBJodUHvXewabhlicTxAzyYrqRSsu:
     kKBJodUHvXewabhlicTxAzyYrqRSsm.append(kKBJodUHvXewabhlicTxAzyYrqRSfs(kKBJodUHvXewabhlicTxAzyYrqRSsM.get('id').rstrip('p')))
    if 'type' in kKBJodUHvXewabhlicTxAzyYrqRSCD:
     if kKBJodUHvXewabhlicTxAzyYrqRSCD['type']=='onair':
      kKBJodUHvXewabhlicTxAzyYrqRSsO='onairvod'
    if 'drms' in kKBJodUHvXewabhlicTxAzyYrqRSCD:
     if kKBJodUHvXewabhlicTxAzyYrqRSCD['drms']:
      kKBJodUHvXewabhlicTxAzyYrqRSsp='dash'
  except kKBJodUHvXewabhlicTxAzyYrqRSfC as exception:
   kKBJodUHvXewabhlicTxAzyYrqRSft(exception)
   return(kKBJodUHvXewabhlicTxAzyYrqRSsE,kKBJodUHvXewabhlicTxAzyYrqRSsW,kKBJodUHvXewabhlicTxAzyYrqRSsN,streaming_preview)
  try:
   kKBJodUHvXewabhlicTxAzyYrqRSsL=kKBJodUHvXewabhlicTxAzyYrqRSCj.CheckQuality(quality_int,kKBJodUHvXewabhlicTxAzyYrqRSsm)
   if mode=='LIVE' and pvrmode!='-':
    kKBJodUHvXewabhlicTxAzyYrqRSsF='auto'
   else:
    kKBJodUHvXewabhlicTxAzyYrqRSsF=kKBJodUHvXewabhlicTxAzyYrqRSsG(kKBJodUHvXewabhlicTxAzyYrqRSsL)+'p'
   kKBJodUHvXewabhlicTxAzyYrqRSCQ=kKBJodUHvXewabhlicTxAzyYrqRSCj.API_DOMAIN+'/streaming'
   kKBJodUHvXewabhlicTxAzyYrqRSCI={'contentid':kKBJodUHvXewabhlicTxAzyYrqRSjV,'contenttype':kKBJodUHvXewabhlicTxAzyYrqRSsO,'action':kKBJodUHvXewabhlicTxAzyYrqRSsp,'quality':kKBJodUHvXewabhlicTxAzyYrqRSsF,'deviceModelId':'Windows 10','guid':kKBJodUHvXewabhlicTxAzyYrqRSCj.GetGUID(guidType=2),'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n'}
   kKBJodUHvXewabhlicTxAzyYrqRSCI.update(kKBJodUHvXewabhlicTxAzyYrqRSCj.GetDefaultParams(login=kKBJodUHvXewabhlicTxAzyYrqRSsD))
   kKBJodUHvXewabhlicTxAzyYrqRSCP=kKBJodUHvXewabhlicTxAzyYrqRSCj.callRequestCookies('Get',kKBJodUHvXewabhlicTxAzyYrqRSCQ,payload=kKBJodUHvXewabhlicTxAzyYrqRSsg,params=kKBJodUHvXewabhlicTxAzyYrqRSCI,headers=kKBJodUHvXewabhlicTxAzyYrqRSsg,cookies=kKBJodUHvXewabhlicTxAzyYrqRSsg)
   kKBJodUHvXewabhlicTxAzyYrqRSCD=json.loads(kKBJodUHvXewabhlicTxAzyYrqRSCP.text)
   kKBJodUHvXewabhlicTxAzyYrqRSsE=kKBJodUHvXewabhlicTxAzyYrqRSCD['playurl']
   if kKBJodUHvXewabhlicTxAzyYrqRSsE==kKBJodUHvXewabhlicTxAzyYrqRSsg:return(kKBJodUHvXewabhlicTxAzyYrqRSsE,kKBJodUHvXewabhlicTxAzyYrqRSsW,kKBJodUHvXewabhlicTxAzyYrqRSsN,streaming_preview)
   kKBJodUHvXewabhlicTxAzyYrqRSsW=kKBJodUHvXewabhlicTxAzyYrqRSCD['awscookie']
   kKBJodUHvXewabhlicTxAzyYrqRSsN =kKBJodUHvXewabhlicTxAzyYrqRSCD['drm']
   if 'previewmsg' in kKBJodUHvXewabhlicTxAzyYrqRSCD['preview']:streaming_preview=kKBJodUHvXewabhlicTxAzyYrqRSCD['preview']['previewmsg']
  except kKBJodUHvXewabhlicTxAzyYrqRSfC as exception:
   kKBJodUHvXewabhlicTxAzyYrqRSft(exception)
  return(kKBJodUHvXewabhlicTxAzyYrqRSsE,kKBJodUHvXewabhlicTxAzyYrqRSsW,kKBJodUHvXewabhlicTxAzyYrqRSsN,streaming_preview) 
# Created by pyminifier (https://github.com/liftoff/pyminifier)
