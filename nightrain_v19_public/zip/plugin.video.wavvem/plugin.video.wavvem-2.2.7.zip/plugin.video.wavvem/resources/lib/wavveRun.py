__author__="NightRain"
GIBzFHJlEUgQcYykhmSpsKubMOfCNP=object
GIBzFHJlEUgQcYykhmSpsKubMOfCNR=None
GIBzFHJlEUgQcYykhmSpsKubMOfCNa=int
GIBzFHJlEUgQcYykhmSpsKubMOfCNW=True
GIBzFHJlEUgQcYykhmSpsKubMOfCNj=False
GIBzFHJlEUgQcYykhmSpsKubMOfCNd=type
GIBzFHJlEUgQcYykhmSpsKubMOfCNe=dict
GIBzFHJlEUgQcYykhmSpsKubMOfCNT=len
GIBzFHJlEUgQcYykhmSpsKubMOfCxr=range
GIBzFHJlEUgQcYykhmSpsKubMOfCxo=str
GIBzFHJlEUgQcYykhmSpsKubMOfCxA=open
GIBzFHJlEUgQcYykhmSpsKubMOfCxX=Exception
GIBzFHJlEUgQcYykhmSpsKubMOfCxV=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import json
GIBzFHJlEUgQcYykhmSpsKubMOfCrA=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://www.wavve.com/supermultisection/GN51','icon':'home.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&offset=0&limit=20&uicode=VN500','page':'1','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=01&WeekDay=all&uitype=VN4&uiparent=FN0&uirank=0&broadcastid=847243&uicode=VN4','page':'1','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=02&WeekDay=all&uitype=VN3&uiparent=FN0&uirank=0&broadcastid=783664&uicode=VN3','page':'1','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'1','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'paid','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'displaystart','ordernm':'업데이트순','icon':''},{'title':'프로야구 - 경기중 시청가능','mode':'GAME_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'(웨이브) 검색','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'(웨이브) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
GIBzFHJlEUgQcYykhmSpsKubMOfCrX=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
GIBzFHJlEUgQcYykhmSpsKubMOfCrV=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
GIBzFHJlEUgQcYykhmSpsKubMOfCrw =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
GIBzFHJlEUgQcYykhmSpsKubMOfCrN=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_searched.txt'))
from wavveCore import*
class GIBzFHJlEUgQcYykhmSpsKubMOfCro(GIBzFHJlEUgQcYykhmSpsKubMOfCNP):
 def __init__(GIBzFHJlEUgQcYykhmSpsKubMOfCrx,GIBzFHJlEUgQcYykhmSpsKubMOfCrt,GIBzFHJlEUgQcYykhmSpsKubMOfCrv,GIBzFHJlEUgQcYykhmSpsKubMOfCrL):
  GIBzFHJlEUgQcYykhmSpsKubMOfCrx._addon_url =GIBzFHJlEUgQcYykhmSpsKubMOfCrt
  GIBzFHJlEUgQcYykhmSpsKubMOfCrx._addon_handle=GIBzFHJlEUgQcYykhmSpsKubMOfCrv
  GIBzFHJlEUgQcYykhmSpsKubMOfCrx.main_params =GIBzFHJlEUgQcYykhmSpsKubMOfCrL
  GIBzFHJlEUgQcYykhmSpsKubMOfCrx.WavveObj =JUOAvmDgKdSHTwrfeGREjyqhnNPFCk() 
 def addon_noti(GIBzFHJlEUgQcYykhmSpsKubMOfCrx,sting):
  try:
   GIBzFHJlEUgQcYykhmSpsKubMOfCrD=xbmcgui.Dialog()
   GIBzFHJlEUgQcYykhmSpsKubMOfCrD.notification(__addonname__,sting)
  except:
   GIBzFHJlEUgQcYykhmSpsKubMOfCNR
 def addon_log(GIBzFHJlEUgQcYykhmSpsKubMOfCrx,string):
  try:
   GIBzFHJlEUgQcYykhmSpsKubMOfCrq=string.encode('utf-8','ignore')
  except:
   GIBzFHJlEUgQcYykhmSpsKubMOfCrq='addonException: addon_log'
  GIBzFHJlEUgQcYykhmSpsKubMOfCrn=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,GIBzFHJlEUgQcYykhmSpsKubMOfCrq),level=GIBzFHJlEUgQcYykhmSpsKubMOfCrn)
 def get_keyboard_input(GIBzFHJlEUgQcYykhmSpsKubMOfCrx,GIBzFHJlEUgQcYykhmSpsKubMOfCot):
  GIBzFHJlEUgQcYykhmSpsKubMOfCrP=GIBzFHJlEUgQcYykhmSpsKubMOfCNR
  kb=xbmc.Keyboard()
  kb.setHeading(GIBzFHJlEUgQcYykhmSpsKubMOfCot)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   GIBzFHJlEUgQcYykhmSpsKubMOfCrP=kb.getText()
  return GIBzFHJlEUgQcYykhmSpsKubMOfCrP
 def get_settings_account(GIBzFHJlEUgQcYykhmSpsKubMOfCrx):
  GIBzFHJlEUgQcYykhmSpsKubMOfCrR =__addon__.getSetting('id')
  GIBzFHJlEUgQcYykhmSpsKubMOfCra =__addon__.getSetting('pw')
  GIBzFHJlEUgQcYykhmSpsKubMOfCrW=GIBzFHJlEUgQcYykhmSpsKubMOfCNa(__addon__.getSetting('selected_profile'))
  return(GIBzFHJlEUgQcYykhmSpsKubMOfCrR,GIBzFHJlEUgQcYykhmSpsKubMOfCra,GIBzFHJlEUgQcYykhmSpsKubMOfCrW)
 def get_settings_totalsearch(GIBzFHJlEUgQcYykhmSpsKubMOfCrx):
  GIBzFHJlEUgQcYykhmSpsKubMOfCrj =GIBzFHJlEUgQcYykhmSpsKubMOfCNW if __addon__.getSetting('local_search')=='true' else GIBzFHJlEUgQcYykhmSpsKubMOfCNj
  GIBzFHJlEUgQcYykhmSpsKubMOfCrd=GIBzFHJlEUgQcYykhmSpsKubMOfCNW if __addon__.getSetting('local_history')=='true' else GIBzFHJlEUgQcYykhmSpsKubMOfCNj
  GIBzFHJlEUgQcYykhmSpsKubMOfCre =GIBzFHJlEUgQcYykhmSpsKubMOfCNW if __addon__.getSetting('total_search')=='true' else GIBzFHJlEUgQcYykhmSpsKubMOfCNj
  GIBzFHJlEUgQcYykhmSpsKubMOfCrT=GIBzFHJlEUgQcYykhmSpsKubMOfCNW if __addon__.getSetting('total_history')=='true' else GIBzFHJlEUgQcYykhmSpsKubMOfCNj
  GIBzFHJlEUgQcYykhmSpsKubMOfCor=GIBzFHJlEUgQcYykhmSpsKubMOfCNW if __addon__.getSetting('menu_bookmark')=='true' else GIBzFHJlEUgQcYykhmSpsKubMOfCNj
  return(GIBzFHJlEUgQcYykhmSpsKubMOfCrj,GIBzFHJlEUgQcYykhmSpsKubMOfCrd,GIBzFHJlEUgQcYykhmSpsKubMOfCre,GIBzFHJlEUgQcYykhmSpsKubMOfCrT,GIBzFHJlEUgQcYykhmSpsKubMOfCor)
 def get_settings_makebookmark(GIBzFHJlEUgQcYykhmSpsKubMOfCrx):
  return GIBzFHJlEUgQcYykhmSpsKubMOfCNW if __addon__.getSetting('make_bookmark')=='true' else GIBzFHJlEUgQcYykhmSpsKubMOfCNj
 def get_selQuality(GIBzFHJlEUgQcYykhmSpsKubMOfCrx):
  try:
   GIBzFHJlEUgQcYykhmSpsKubMOfCoA=[1080,720,480,360]
   GIBzFHJlEUgQcYykhmSpsKubMOfCoX=GIBzFHJlEUgQcYykhmSpsKubMOfCNa(__addon__.getSetting('selected_quality'))
   return GIBzFHJlEUgQcYykhmSpsKubMOfCoA[GIBzFHJlEUgQcYykhmSpsKubMOfCoX]
  except:
   GIBzFHJlEUgQcYykhmSpsKubMOfCNR
  return 1080 
 def get_settings_exclusion21(GIBzFHJlEUgQcYykhmSpsKubMOfCrx):
  GIBzFHJlEUgQcYykhmSpsKubMOfCoV =__addon__.getSetting('exclusion21')
  if GIBzFHJlEUgQcYykhmSpsKubMOfCoV=='false':
   return GIBzFHJlEUgQcYykhmSpsKubMOfCNj
  else:
   return GIBzFHJlEUgQcYykhmSpsKubMOfCNW
 def get_settings_direct_replay(GIBzFHJlEUgQcYykhmSpsKubMOfCrx):
  GIBzFHJlEUgQcYykhmSpsKubMOfCow=GIBzFHJlEUgQcYykhmSpsKubMOfCNa(__addon__.getSetting('direct_replay'))
  if GIBzFHJlEUgQcYykhmSpsKubMOfCow==0:
   return GIBzFHJlEUgQcYykhmSpsKubMOfCNj
  else:
   return GIBzFHJlEUgQcYykhmSpsKubMOfCNW
 def set_winEpisodeOrderby(GIBzFHJlEUgQcYykhmSpsKubMOfCrx,GIBzFHJlEUgQcYykhmSpsKubMOfCoN):
  __addon__.setSetting('wavve_orderby',GIBzFHJlEUgQcYykhmSpsKubMOfCoN)
 def get_winEpisodeOrderby(GIBzFHJlEUgQcYykhmSpsKubMOfCrx):
  GIBzFHJlEUgQcYykhmSpsKubMOfCoN=__addon__.getSetting('wavve_orderby')
  if GIBzFHJlEUgQcYykhmSpsKubMOfCoN in['',GIBzFHJlEUgQcYykhmSpsKubMOfCNR]:GIBzFHJlEUgQcYykhmSpsKubMOfCoN='desc'
  return GIBzFHJlEUgQcYykhmSpsKubMOfCoN
 def add_dir(GIBzFHJlEUgQcYykhmSpsKubMOfCrx,label,sublabel='',img='',infoLabels=GIBzFHJlEUgQcYykhmSpsKubMOfCNR,isFolder=GIBzFHJlEUgQcYykhmSpsKubMOfCNW,params='',isLink=GIBzFHJlEUgQcYykhmSpsKubMOfCNj,ContextMenu=GIBzFHJlEUgQcYykhmSpsKubMOfCNR):
  GIBzFHJlEUgQcYykhmSpsKubMOfCox='%s?%s'%(GIBzFHJlEUgQcYykhmSpsKubMOfCrx._addon_url,urllib.parse.urlencode(params))
  if sublabel:GIBzFHJlEUgQcYykhmSpsKubMOfCot='%s < %s >'%(label,sublabel)
  else: GIBzFHJlEUgQcYykhmSpsKubMOfCot=label
  if not img:img='DefaultFolder.png'
  GIBzFHJlEUgQcYykhmSpsKubMOfCov=xbmcgui.ListItem(GIBzFHJlEUgQcYykhmSpsKubMOfCot)
  if GIBzFHJlEUgQcYykhmSpsKubMOfCNd(img)==GIBzFHJlEUgQcYykhmSpsKubMOfCNe:
   GIBzFHJlEUgQcYykhmSpsKubMOfCov.setArt(img)
  else:
   GIBzFHJlEUgQcYykhmSpsKubMOfCov.setArt({'thumb':img,'poster':img})
  if infoLabels:GIBzFHJlEUgQcYykhmSpsKubMOfCov.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   GIBzFHJlEUgQcYykhmSpsKubMOfCov.setProperty('IsPlayable','true')
  if ContextMenu:GIBzFHJlEUgQcYykhmSpsKubMOfCov.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(GIBzFHJlEUgQcYykhmSpsKubMOfCrx._addon_handle,GIBzFHJlEUgQcYykhmSpsKubMOfCox,GIBzFHJlEUgQcYykhmSpsKubMOfCov,isFolder)
 def dp_Main_List(GIBzFHJlEUgQcYykhmSpsKubMOfCrx):
  (GIBzFHJlEUgQcYykhmSpsKubMOfCrj,GIBzFHJlEUgQcYykhmSpsKubMOfCrd,GIBzFHJlEUgQcYykhmSpsKubMOfCre,GIBzFHJlEUgQcYykhmSpsKubMOfCrT,GIBzFHJlEUgQcYykhmSpsKubMOfCor)=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.get_settings_totalsearch()
  for GIBzFHJlEUgQcYykhmSpsKubMOfCoL in GIBzFHJlEUgQcYykhmSpsKubMOfCrA:
   GIBzFHJlEUgQcYykhmSpsKubMOfCot=GIBzFHJlEUgQcYykhmSpsKubMOfCoL.get('title')
   GIBzFHJlEUgQcYykhmSpsKubMOfCoi=''
   if GIBzFHJlEUgQcYykhmSpsKubMOfCoL.get('mode')=='SEARCH_GROUP' and GIBzFHJlEUgQcYykhmSpsKubMOfCrj ==GIBzFHJlEUgQcYykhmSpsKubMOfCNj:continue
   elif GIBzFHJlEUgQcYykhmSpsKubMOfCoL.get('mode')=='SEARCH_HISTORY' and GIBzFHJlEUgQcYykhmSpsKubMOfCrd==GIBzFHJlEUgQcYykhmSpsKubMOfCNj:continue
   elif GIBzFHJlEUgQcYykhmSpsKubMOfCoL.get('mode')=='TOTAL_SEARCH' and GIBzFHJlEUgQcYykhmSpsKubMOfCre ==GIBzFHJlEUgQcYykhmSpsKubMOfCNj:continue
   elif GIBzFHJlEUgQcYykhmSpsKubMOfCoL.get('mode')=='TOTAL_HISTORY' and GIBzFHJlEUgQcYykhmSpsKubMOfCrT==GIBzFHJlEUgQcYykhmSpsKubMOfCNj:continue
   elif GIBzFHJlEUgQcYykhmSpsKubMOfCoL.get('mode')=='MENU_BOOKMARK' and GIBzFHJlEUgQcYykhmSpsKubMOfCor==GIBzFHJlEUgQcYykhmSpsKubMOfCNj:continue
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD={'mode':GIBzFHJlEUgQcYykhmSpsKubMOfCoL.get('mode'),'sCode':GIBzFHJlEUgQcYykhmSpsKubMOfCoL.get('sCode'),'sIndex':GIBzFHJlEUgQcYykhmSpsKubMOfCoL.get('sIndex'),'sType':GIBzFHJlEUgQcYykhmSpsKubMOfCoL.get('sType'),'suburl':GIBzFHJlEUgQcYykhmSpsKubMOfCoL.get('suburl'),'subapi':GIBzFHJlEUgQcYykhmSpsKubMOfCoL.get('subapi'),'page':GIBzFHJlEUgQcYykhmSpsKubMOfCoL.get('page'),'orderby':GIBzFHJlEUgQcYykhmSpsKubMOfCoL.get('orderby'),'ordernm':GIBzFHJlEUgQcYykhmSpsKubMOfCoL.get('ordernm')}
   if GIBzFHJlEUgQcYykhmSpsKubMOfCoL.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    GIBzFHJlEUgQcYykhmSpsKubMOfCoq=GIBzFHJlEUgQcYykhmSpsKubMOfCNj
    GIBzFHJlEUgQcYykhmSpsKubMOfCon =GIBzFHJlEUgQcYykhmSpsKubMOfCNW
   else:
    GIBzFHJlEUgQcYykhmSpsKubMOfCoq=GIBzFHJlEUgQcYykhmSpsKubMOfCNW
    GIBzFHJlEUgQcYykhmSpsKubMOfCon =GIBzFHJlEUgQcYykhmSpsKubMOfCNj
   if 'icon' in GIBzFHJlEUgQcYykhmSpsKubMOfCoL:GIBzFHJlEUgQcYykhmSpsKubMOfCoi=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',GIBzFHJlEUgQcYykhmSpsKubMOfCoL.get('icon')) 
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.add_dir(GIBzFHJlEUgQcYykhmSpsKubMOfCot,sublabel='',img=GIBzFHJlEUgQcYykhmSpsKubMOfCoi,infoLabels=GIBzFHJlEUgQcYykhmSpsKubMOfCNR,isFolder=GIBzFHJlEUgQcYykhmSpsKubMOfCoq,params=GIBzFHJlEUgQcYykhmSpsKubMOfCoD,isLink=GIBzFHJlEUgQcYykhmSpsKubMOfCon)
  xbmcplugin.endOfDirectory(GIBzFHJlEUgQcYykhmSpsKubMOfCrx._addon_handle,cacheToDisc=GIBzFHJlEUgQcYykhmSpsKubMOfCNW)
 def dp_Search_Group(GIBzFHJlEUgQcYykhmSpsKubMOfCrx,args):
  if 'search_key' in args:
   GIBzFHJlEUgQcYykhmSpsKubMOfCoa=args.get('search_key')
  else:
   GIBzFHJlEUgQcYykhmSpsKubMOfCoa=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not GIBzFHJlEUgQcYykhmSpsKubMOfCoa:
    return
  for GIBzFHJlEUgQcYykhmSpsKubMOfCoW in GIBzFHJlEUgQcYykhmSpsKubMOfCrX:
   GIBzFHJlEUgQcYykhmSpsKubMOfCoj =GIBzFHJlEUgQcYykhmSpsKubMOfCoW.get('mode')
   GIBzFHJlEUgQcYykhmSpsKubMOfCod=GIBzFHJlEUgQcYykhmSpsKubMOfCoW.get('sType')
   GIBzFHJlEUgQcYykhmSpsKubMOfCot=GIBzFHJlEUgQcYykhmSpsKubMOfCoW.get('title')
   (GIBzFHJlEUgQcYykhmSpsKubMOfCoe,GIBzFHJlEUgQcYykhmSpsKubMOfCoT)=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.WavveObj.Get_Search_List(GIBzFHJlEUgQcYykhmSpsKubMOfCoa,GIBzFHJlEUgQcYykhmSpsKubMOfCod,1,exclusion21=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.get_settings_exclusion21())
   GIBzFHJlEUgQcYykhmSpsKubMOfCAr={'plot':'검색어 : '+GIBzFHJlEUgQcYykhmSpsKubMOfCoa+'\n\n'+GIBzFHJlEUgQcYykhmSpsKubMOfCrx.Search_FreeList(GIBzFHJlEUgQcYykhmSpsKubMOfCoe)}
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD={'mode':GIBzFHJlEUgQcYykhmSpsKubMOfCoj,'sType':GIBzFHJlEUgQcYykhmSpsKubMOfCod,'search_key':GIBzFHJlEUgQcYykhmSpsKubMOfCoa,'page':'1',}
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.add_dir(GIBzFHJlEUgQcYykhmSpsKubMOfCot,sublabel='',img='',infoLabels=GIBzFHJlEUgQcYykhmSpsKubMOfCAr,isFolder=GIBzFHJlEUgQcYykhmSpsKubMOfCNW,params=GIBzFHJlEUgQcYykhmSpsKubMOfCoD)
  if GIBzFHJlEUgQcYykhmSpsKubMOfCNT(GIBzFHJlEUgQcYykhmSpsKubMOfCrX)>0:xbmcplugin.endOfDirectory(GIBzFHJlEUgQcYykhmSpsKubMOfCrx._addon_handle,cacheToDisc=GIBzFHJlEUgQcYykhmSpsKubMOfCNW)
  GIBzFHJlEUgQcYykhmSpsKubMOfCrx.Save_Searched_List(GIBzFHJlEUgQcYykhmSpsKubMOfCoa)
 def Search_FreeList(GIBzFHJlEUgQcYykhmSpsKubMOfCrx,search_list):
  GIBzFHJlEUgQcYykhmSpsKubMOfCAo=''
  GIBzFHJlEUgQcYykhmSpsKubMOfCAX=7
  try:
   if GIBzFHJlEUgQcYykhmSpsKubMOfCNT(search_list)==0:return '검색결과 없음'
   for i in GIBzFHJlEUgQcYykhmSpsKubMOfCxr(GIBzFHJlEUgQcYykhmSpsKubMOfCNT(search_list)):
    if i>=GIBzFHJlEUgQcYykhmSpsKubMOfCAX:
     GIBzFHJlEUgQcYykhmSpsKubMOfCAo=GIBzFHJlEUgQcYykhmSpsKubMOfCAo+'...'
     break
    GIBzFHJlEUgQcYykhmSpsKubMOfCAo=GIBzFHJlEUgQcYykhmSpsKubMOfCAo+search_list[i]['title']+'\n'
  except:
   return ''
  return GIBzFHJlEUgQcYykhmSpsKubMOfCAo
 def dp_Watch_Group(GIBzFHJlEUgQcYykhmSpsKubMOfCrx,args):
  for GIBzFHJlEUgQcYykhmSpsKubMOfCAV in GIBzFHJlEUgQcYykhmSpsKubMOfCrV:
   GIBzFHJlEUgQcYykhmSpsKubMOfCot=GIBzFHJlEUgQcYykhmSpsKubMOfCAV.get('title')
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD={'mode':GIBzFHJlEUgQcYykhmSpsKubMOfCAV.get('mode'),'sType':GIBzFHJlEUgQcYykhmSpsKubMOfCAV.get('sType')}
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.add_dir(GIBzFHJlEUgQcYykhmSpsKubMOfCot,sublabel='',img='',infoLabels=GIBzFHJlEUgQcYykhmSpsKubMOfCNR,isFolder=GIBzFHJlEUgQcYykhmSpsKubMOfCNW,params=GIBzFHJlEUgQcYykhmSpsKubMOfCoD)
  if GIBzFHJlEUgQcYykhmSpsKubMOfCNT(GIBzFHJlEUgQcYykhmSpsKubMOfCrV)>0:xbmcplugin.endOfDirectory(GIBzFHJlEUgQcYykhmSpsKubMOfCrx._addon_handle,cacheToDisc=GIBzFHJlEUgQcYykhmSpsKubMOfCNW)
 def dp_Search_History(GIBzFHJlEUgQcYykhmSpsKubMOfCrx,args):
  GIBzFHJlEUgQcYykhmSpsKubMOfCAw=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.Load_List_File('search')
  for GIBzFHJlEUgQcYykhmSpsKubMOfCAN in GIBzFHJlEUgQcYykhmSpsKubMOfCAw:
   GIBzFHJlEUgQcYykhmSpsKubMOfCAx=GIBzFHJlEUgQcYykhmSpsKubMOfCNe(urllib.parse.parse_qsl(GIBzFHJlEUgQcYykhmSpsKubMOfCAN))
   GIBzFHJlEUgQcYykhmSpsKubMOfCAt=GIBzFHJlEUgQcYykhmSpsKubMOfCAx.get('skey').strip()
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD={'mode':'SEARCH_GROUP','search_key':GIBzFHJlEUgQcYykhmSpsKubMOfCAt,}
   GIBzFHJlEUgQcYykhmSpsKubMOfCAv={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':GIBzFHJlEUgQcYykhmSpsKubMOfCAt,'vType':'-',}
   GIBzFHJlEUgQcYykhmSpsKubMOfCAL=urllib.parse.urlencode(GIBzFHJlEUgQcYykhmSpsKubMOfCAv)
   GIBzFHJlEUgQcYykhmSpsKubMOfCAi=[('선택된 검색어 ( %s ) 삭제'%(GIBzFHJlEUgQcYykhmSpsKubMOfCAt),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(GIBzFHJlEUgQcYykhmSpsKubMOfCAL))]
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.add_dir(GIBzFHJlEUgQcYykhmSpsKubMOfCAt,sublabel='',img=GIBzFHJlEUgQcYykhmSpsKubMOfCNR,infoLabels=GIBzFHJlEUgQcYykhmSpsKubMOfCNR,isFolder=GIBzFHJlEUgQcYykhmSpsKubMOfCNW,params=GIBzFHJlEUgQcYykhmSpsKubMOfCoD,ContextMenu=GIBzFHJlEUgQcYykhmSpsKubMOfCAi)
  GIBzFHJlEUgQcYykhmSpsKubMOfCAD={'plot':'검색목록 전체를 삭제합니다.'}
  GIBzFHJlEUgQcYykhmSpsKubMOfCot='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  GIBzFHJlEUgQcYykhmSpsKubMOfCoD={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  GIBzFHJlEUgQcYykhmSpsKubMOfCoi=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  GIBzFHJlEUgQcYykhmSpsKubMOfCrx.add_dir(GIBzFHJlEUgQcYykhmSpsKubMOfCot,sublabel='',img=GIBzFHJlEUgQcYykhmSpsKubMOfCoi,infoLabels=GIBzFHJlEUgQcYykhmSpsKubMOfCAD,isFolder=GIBzFHJlEUgQcYykhmSpsKubMOfCNj,params=GIBzFHJlEUgQcYykhmSpsKubMOfCoD,isLink=GIBzFHJlEUgQcYykhmSpsKubMOfCNW)
  xbmcplugin.endOfDirectory(GIBzFHJlEUgQcYykhmSpsKubMOfCrx._addon_handle,cacheToDisc=GIBzFHJlEUgQcYykhmSpsKubMOfCNj)
 def dp_Search_List(GIBzFHJlEUgQcYykhmSpsKubMOfCrx,args):
  GIBzFHJlEUgQcYykhmSpsKubMOfCod =args.get('sType')
  GIBzFHJlEUgQcYykhmSpsKubMOfCAq =GIBzFHJlEUgQcYykhmSpsKubMOfCNa(args.get('page'))
  if 'search_key' in args:
   GIBzFHJlEUgQcYykhmSpsKubMOfCoa=args.get('search_key')
  else:
   GIBzFHJlEUgQcYykhmSpsKubMOfCoa=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not GIBzFHJlEUgQcYykhmSpsKubMOfCoa:
    xbmcplugin.endOfDirectory(GIBzFHJlEUgQcYykhmSpsKubMOfCrx._addon_handle)
    return
  GIBzFHJlEUgQcYykhmSpsKubMOfCAn,GIBzFHJlEUgQcYykhmSpsKubMOfCoT=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.WavveObj.Get_Search_List(GIBzFHJlEUgQcYykhmSpsKubMOfCoa,GIBzFHJlEUgQcYykhmSpsKubMOfCod,GIBzFHJlEUgQcYykhmSpsKubMOfCAq,exclusion21=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.get_settings_exclusion21())
  for GIBzFHJlEUgQcYykhmSpsKubMOfCAP in GIBzFHJlEUgQcYykhmSpsKubMOfCAn:
   GIBzFHJlEUgQcYykhmSpsKubMOfCot =GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('title')
   GIBzFHJlEUgQcYykhmSpsKubMOfCAR=GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('thumbnail')
   GIBzFHJlEUgQcYykhmSpsKubMOfCAa =GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('age')
   if GIBzFHJlEUgQcYykhmSpsKubMOfCAa=='18' or GIBzFHJlEUgQcYykhmSpsKubMOfCAa=='19' or GIBzFHJlEUgQcYykhmSpsKubMOfCAa=='21':GIBzFHJlEUgQcYykhmSpsKubMOfCot+=' (%s)'%(GIBzFHJlEUgQcYykhmSpsKubMOfCAa)
   GIBzFHJlEUgQcYykhmSpsKubMOfCAD={'mediatype':'tvshow' if GIBzFHJlEUgQcYykhmSpsKubMOfCod=='vod' else 'movie','mpaa':GIBzFHJlEUgQcYykhmSpsKubMOfCAa,'title':GIBzFHJlEUgQcYykhmSpsKubMOfCot,'plot':GIBzFHJlEUgQcYykhmSpsKubMOfCot}
   if GIBzFHJlEUgQcYykhmSpsKubMOfCod=='vod':
    GIBzFHJlEUgQcYykhmSpsKubMOfCoD={'mode':'EPISODE_LIST','videoid':GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('videoid'),'vidtype':GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('vidtype'),'page':'1'}
    GIBzFHJlEUgQcYykhmSpsKubMOfCoq=GIBzFHJlEUgQcYykhmSpsKubMOfCNW
   else:
    GIBzFHJlEUgQcYykhmSpsKubMOfCoD={'mode':'MOVIE','contentid':GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('videoid'),'title':GIBzFHJlEUgQcYykhmSpsKubMOfCot,'thumbnail':GIBzFHJlEUgQcYykhmSpsKubMOfCAR,'age':GIBzFHJlEUgQcYykhmSpsKubMOfCAa}
    GIBzFHJlEUgQcYykhmSpsKubMOfCoq=GIBzFHJlEUgQcYykhmSpsKubMOfCNj
   if GIBzFHJlEUgQcYykhmSpsKubMOfCrx.get_settings_makebookmark():
    GIBzFHJlEUgQcYykhmSpsKubMOfCAW={'videoid':GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('videoid'),'vidtype':'tvshow' if GIBzFHJlEUgQcYykhmSpsKubMOfCod=='vod' else 'movie','vtitle':GIBzFHJlEUgQcYykhmSpsKubMOfCot,'vsubtitle':'','contenttype':GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('vidtype'),}
    GIBzFHJlEUgQcYykhmSpsKubMOfCAj=json.dumps(GIBzFHJlEUgQcYykhmSpsKubMOfCAW)
    GIBzFHJlEUgQcYykhmSpsKubMOfCAj=urllib.parse.quote(GIBzFHJlEUgQcYykhmSpsKubMOfCAj)
    GIBzFHJlEUgQcYykhmSpsKubMOfCAd='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(GIBzFHJlEUgQcYykhmSpsKubMOfCAj)
    GIBzFHJlEUgQcYykhmSpsKubMOfCAi=[('(통합) 찜 영상에 추가',GIBzFHJlEUgQcYykhmSpsKubMOfCAd)]
   else:
    GIBzFHJlEUgQcYykhmSpsKubMOfCAi=GIBzFHJlEUgQcYykhmSpsKubMOfCNR
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.add_dir(GIBzFHJlEUgQcYykhmSpsKubMOfCot,sublabel='',img=GIBzFHJlEUgQcYykhmSpsKubMOfCAR,infoLabels=GIBzFHJlEUgQcYykhmSpsKubMOfCAD,isFolder=GIBzFHJlEUgQcYykhmSpsKubMOfCoq,params=GIBzFHJlEUgQcYykhmSpsKubMOfCoD,ContextMenu=GIBzFHJlEUgQcYykhmSpsKubMOfCAi)
  if GIBzFHJlEUgQcYykhmSpsKubMOfCoT:
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD['mode'] ='SEARCH_LIST' 
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD['sType']=GIBzFHJlEUgQcYykhmSpsKubMOfCod 
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD['page'] =GIBzFHJlEUgQcYykhmSpsKubMOfCxo(GIBzFHJlEUgQcYykhmSpsKubMOfCAq+1)
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD['search_key']=GIBzFHJlEUgQcYykhmSpsKubMOfCoa
   GIBzFHJlEUgQcYykhmSpsKubMOfCot='[B]%s >>[/B]'%'다음 페이지'
   GIBzFHJlEUgQcYykhmSpsKubMOfCAe=GIBzFHJlEUgQcYykhmSpsKubMOfCxo(GIBzFHJlEUgQcYykhmSpsKubMOfCAq+1)
   GIBzFHJlEUgQcYykhmSpsKubMOfCoi=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.add_dir(GIBzFHJlEUgQcYykhmSpsKubMOfCot,sublabel=GIBzFHJlEUgQcYykhmSpsKubMOfCAe,img=GIBzFHJlEUgQcYykhmSpsKubMOfCoi,infoLabels=GIBzFHJlEUgQcYykhmSpsKubMOfCNR,isFolder=GIBzFHJlEUgQcYykhmSpsKubMOfCNW,params=GIBzFHJlEUgQcYykhmSpsKubMOfCoD)
  if GIBzFHJlEUgQcYykhmSpsKubMOfCod=='movie':xbmcplugin.setContent(GIBzFHJlEUgQcYykhmSpsKubMOfCrx._addon_handle,'movies')
  else:xbmcplugin.setContent(GIBzFHJlEUgQcYykhmSpsKubMOfCrx._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(GIBzFHJlEUgQcYykhmSpsKubMOfCrx._addon_handle,cacheToDisc=GIBzFHJlEUgQcYykhmSpsKubMOfCNj)
 def dp_Watch_List(GIBzFHJlEUgQcYykhmSpsKubMOfCrx,args):
  GIBzFHJlEUgQcYykhmSpsKubMOfCod =args.get('sType')
  GIBzFHJlEUgQcYykhmSpsKubMOfCow=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.get_settings_direct_replay()
  GIBzFHJlEUgQcYykhmSpsKubMOfCAn=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.Load_List_File(GIBzFHJlEUgQcYykhmSpsKubMOfCod)
  for GIBzFHJlEUgQcYykhmSpsKubMOfCAP in GIBzFHJlEUgQcYykhmSpsKubMOfCAn:
   GIBzFHJlEUgQcYykhmSpsKubMOfCAx=GIBzFHJlEUgQcYykhmSpsKubMOfCNe(urllib.parse.parse_qsl(GIBzFHJlEUgQcYykhmSpsKubMOfCAP))
   GIBzFHJlEUgQcYykhmSpsKubMOfCAT =GIBzFHJlEUgQcYykhmSpsKubMOfCAx.get('code').strip()
   GIBzFHJlEUgQcYykhmSpsKubMOfCot =GIBzFHJlEUgQcYykhmSpsKubMOfCAx.get('title').strip()
   GIBzFHJlEUgQcYykhmSpsKubMOfCAe =GIBzFHJlEUgQcYykhmSpsKubMOfCAx.get('subtitle').strip()
   if GIBzFHJlEUgQcYykhmSpsKubMOfCAe=='None':GIBzFHJlEUgQcYykhmSpsKubMOfCAe=''
   GIBzFHJlEUgQcYykhmSpsKubMOfCAR=GIBzFHJlEUgQcYykhmSpsKubMOfCAx.get('img').strip()
   GIBzFHJlEUgQcYykhmSpsKubMOfCXr =GIBzFHJlEUgQcYykhmSpsKubMOfCAx.get('videoid').strip()
   try:
    GIBzFHJlEUgQcYykhmSpsKubMOfCAR=GIBzFHJlEUgQcYykhmSpsKubMOfCAR.replace('\'','\"')
    GIBzFHJlEUgQcYykhmSpsKubMOfCAR=json.loads(GIBzFHJlEUgQcYykhmSpsKubMOfCAR)
   except:
    GIBzFHJlEUgQcYykhmSpsKubMOfCNR
   GIBzFHJlEUgQcYykhmSpsKubMOfCAD={'plot':'%s\n%s'%(GIBzFHJlEUgQcYykhmSpsKubMOfCot,GIBzFHJlEUgQcYykhmSpsKubMOfCAe)}
   if GIBzFHJlEUgQcYykhmSpsKubMOfCod=='vod':
    if GIBzFHJlEUgQcYykhmSpsKubMOfCow==GIBzFHJlEUgQcYykhmSpsKubMOfCNj or GIBzFHJlEUgQcYykhmSpsKubMOfCXr==GIBzFHJlEUgQcYykhmSpsKubMOfCNR:
     GIBzFHJlEUgQcYykhmSpsKubMOfCoD={'mode':'EPISODE_LIST','videoid':GIBzFHJlEUgQcYykhmSpsKubMOfCAT,'vidtype':'programid','page':'1'}
     GIBzFHJlEUgQcYykhmSpsKubMOfCoq=GIBzFHJlEUgQcYykhmSpsKubMOfCNW
    else:
     GIBzFHJlEUgQcYykhmSpsKubMOfCoD={'mode':'VOD','programid':GIBzFHJlEUgQcYykhmSpsKubMOfCAT,'contentid':GIBzFHJlEUgQcYykhmSpsKubMOfCXr,'title':GIBzFHJlEUgQcYykhmSpsKubMOfCot,'subtitle':GIBzFHJlEUgQcYykhmSpsKubMOfCAe,'thumbnail':GIBzFHJlEUgQcYykhmSpsKubMOfCAR}
     GIBzFHJlEUgQcYykhmSpsKubMOfCoq=GIBzFHJlEUgQcYykhmSpsKubMOfCNj
   else:
    GIBzFHJlEUgQcYykhmSpsKubMOfCoD={'mode':'MOVIE','contentid':GIBzFHJlEUgQcYykhmSpsKubMOfCAT,'title':GIBzFHJlEUgQcYykhmSpsKubMOfCot,'subtitle':GIBzFHJlEUgQcYykhmSpsKubMOfCAe,'thumbnail':GIBzFHJlEUgQcYykhmSpsKubMOfCAR}
    GIBzFHJlEUgQcYykhmSpsKubMOfCoq=GIBzFHJlEUgQcYykhmSpsKubMOfCNj
   GIBzFHJlEUgQcYykhmSpsKubMOfCAv={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':GIBzFHJlEUgQcYykhmSpsKubMOfCAT,'vType':GIBzFHJlEUgQcYykhmSpsKubMOfCod,}
   GIBzFHJlEUgQcYykhmSpsKubMOfCAL=urllib.parse.urlencode(GIBzFHJlEUgQcYykhmSpsKubMOfCAv)
   GIBzFHJlEUgQcYykhmSpsKubMOfCAi=[('선택된 시청이력 ( %s ) 삭제'%(GIBzFHJlEUgQcYykhmSpsKubMOfCot),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(GIBzFHJlEUgQcYykhmSpsKubMOfCAL))]
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.add_dir(GIBzFHJlEUgQcYykhmSpsKubMOfCot,sublabel=GIBzFHJlEUgQcYykhmSpsKubMOfCAe,img=GIBzFHJlEUgQcYykhmSpsKubMOfCAR,infoLabels=GIBzFHJlEUgQcYykhmSpsKubMOfCAD,isFolder=GIBzFHJlEUgQcYykhmSpsKubMOfCoq,params=GIBzFHJlEUgQcYykhmSpsKubMOfCoD,ContextMenu=GIBzFHJlEUgQcYykhmSpsKubMOfCAi)
  GIBzFHJlEUgQcYykhmSpsKubMOfCAD={'plot':'시청목록을 삭제합니다.'}
  GIBzFHJlEUgQcYykhmSpsKubMOfCot='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  GIBzFHJlEUgQcYykhmSpsKubMOfCoD={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':GIBzFHJlEUgQcYykhmSpsKubMOfCod,}
  GIBzFHJlEUgQcYykhmSpsKubMOfCoi=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  GIBzFHJlEUgQcYykhmSpsKubMOfCrx.add_dir(GIBzFHJlEUgQcYykhmSpsKubMOfCot,sublabel='',img=GIBzFHJlEUgQcYykhmSpsKubMOfCoi,infoLabels=GIBzFHJlEUgQcYykhmSpsKubMOfCAD,isFolder=GIBzFHJlEUgQcYykhmSpsKubMOfCNj,params=GIBzFHJlEUgQcYykhmSpsKubMOfCoD,isLink=GIBzFHJlEUgQcYykhmSpsKubMOfCNW)
  if GIBzFHJlEUgQcYykhmSpsKubMOfCod=='movie':xbmcplugin.setContent(GIBzFHJlEUgQcYykhmSpsKubMOfCrx._addon_handle,'movies')
  else:xbmcplugin.setContent(GIBzFHJlEUgQcYykhmSpsKubMOfCrx._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(GIBzFHJlEUgQcYykhmSpsKubMOfCrx._addon_handle,cacheToDisc=GIBzFHJlEUgQcYykhmSpsKubMOfCNj)
 def Load_List_File(GIBzFHJlEUgQcYykhmSpsKubMOfCrx,stype): 
  try:
   if stype=='search':
    GIBzFHJlEUgQcYykhmSpsKubMOfCXo=GIBzFHJlEUgQcYykhmSpsKubMOfCrN
   elif stype in['vod','movie']:
    GIBzFHJlEUgQcYykhmSpsKubMOfCXo=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   else:
    return[]
   fp=GIBzFHJlEUgQcYykhmSpsKubMOfCxA(GIBzFHJlEUgQcYykhmSpsKubMOfCXo,'r',-1,'utf-8')
   GIBzFHJlEUgQcYykhmSpsKubMOfCXA=fp.readlines()
   fp.close()
  except:
   GIBzFHJlEUgQcYykhmSpsKubMOfCXA=[]
  return GIBzFHJlEUgQcYykhmSpsKubMOfCXA
 def Save_Watched_List(GIBzFHJlEUgQcYykhmSpsKubMOfCrx,GIBzFHJlEUgQcYykhmSpsKubMOfCNX,GIBzFHJlEUgQcYykhmSpsKubMOfCrL):
  try:
   GIBzFHJlEUgQcYykhmSpsKubMOfCXV=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%GIBzFHJlEUgQcYykhmSpsKubMOfCNX))
   GIBzFHJlEUgQcYykhmSpsKubMOfCXw=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.Load_List_File(GIBzFHJlEUgQcYykhmSpsKubMOfCNX) 
   fp=GIBzFHJlEUgQcYykhmSpsKubMOfCxA(GIBzFHJlEUgQcYykhmSpsKubMOfCXV,'w',-1,'utf-8')
   GIBzFHJlEUgQcYykhmSpsKubMOfCXN=urllib.parse.urlencode(GIBzFHJlEUgQcYykhmSpsKubMOfCrL)
   GIBzFHJlEUgQcYykhmSpsKubMOfCXN=GIBzFHJlEUgQcYykhmSpsKubMOfCXN+'\n'
   fp.write(GIBzFHJlEUgQcYykhmSpsKubMOfCXN)
   GIBzFHJlEUgQcYykhmSpsKubMOfCXx=0
   for GIBzFHJlEUgQcYykhmSpsKubMOfCXt in GIBzFHJlEUgQcYykhmSpsKubMOfCXw:
    GIBzFHJlEUgQcYykhmSpsKubMOfCXv=GIBzFHJlEUgQcYykhmSpsKubMOfCNe(urllib.parse.parse_qsl(GIBzFHJlEUgQcYykhmSpsKubMOfCXt))
    GIBzFHJlEUgQcYykhmSpsKubMOfCXL=GIBzFHJlEUgQcYykhmSpsKubMOfCrL.get('code').strip()
    GIBzFHJlEUgQcYykhmSpsKubMOfCXi=GIBzFHJlEUgQcYykhmSpsKubMOfCXv.get('code').strip()
    if GIBzFHJlEUgQcYykhmSpsKubMOfCNX=='vod' and GIBzFHJlEUgQcYykhmSpsKubMOfCrx.get_settings_direct_replay()==GIBzFHJlEUgQcYykhmSpsKubMOfCNW:
     GIBzFHJlEUgQcYykhmSpsKubMOfCXL=GIBzFHJlEUgQcYykhmSpsKubMOfCrL.get('videoid').strip()
     GIBzFHJlEUgQcYykhmSpsKubMOfCXi=GIBzFHJlEUgQcYykhmSpsKubMOfCXv.get('videoid').strip()if GIBzFHJlEUgQcYykhmSpsKubMOfCXi!=GIBzFHJlEUgQcYykhmSpsKubMOfCNR else '-'
    if GIBzFHJlEUgQcYykhmSpsKubMOfCXL!=GIBzFHJlEUgQcYykhmSpsKubMOfCXi:
     fp.write(GIBzFHJlEUgQcYykhmSpsKubMOfCXt)
     GIBzFHJlEUgQcYykhmSpsKubMOfCXx+=1
     if GIBzFHJlEUgQcYykhmSpsKubMOfCXx>=50:break
   fp.close()
  except:
   GIBzFHJlEUgQcYykhmSpsKubMOfCNR
 def dp_History_Remove(GIBzFHJlEUgQcYykhmSpsKubMOfCrx,args):
  GIBzFHJlEUgQcYykhmSpsKubMOfCXD=args.get('delType')
  GIBzFHJlEUgQcYykhmSpsKubMOfCXq =args.get('sKey')
  GIBzFHJlEUgQcYykhmSpsKubMOfCXn =args.get('vType')
  GIBzFHJlEUgQcYykhmSpsKubMOfCrD=xbmcgui.Dialog()
  if GIBzFHJlEUgQcYykhmSpsKubMOfCXD=='SEARCH_ALL':
   GIBzFHJlEUgQcYykhmSpsKubMOfCXP=GIBzFHJlEUgQcYykhmSpsKubMOfCrD.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif GIBzFHJlEUgQcYykhmSpsKubMOfCXD=='SEARCH_ONE':
   GIBzFHJlEUgQcYykhmSpsKubMOfCXP=GIBzFHJlEUgQcYykhmSpsKubMOfCrD.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif GIBzFHJlEUgQcYykhmSpsKubMOfCXD=='WATCH_ALL':
   GIBzFHJlEUgQcYykhmSpsKubMOfCXP=GIBzFHJlEUgQcYykhmSpsKubMOfCrD.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif GIBzFHJlEUgQcYykhmSpsKubMOfCXD=='WATCH_ONE':
   GIBzFHJlEUgQcYykhmSpsKubMOfCXP=GIBzFHJlEUgQcYykhmSpsKubMOfCrD.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if GIBzFHJlEUgQcYykhmSpsKubMOfCXP==GIBzFHJlEUgQcYykhmSpsKubMOfCNj:sys.exit()
  if GIBzFHJlEUgQcYykhmSpsKubMOfCXD=='SEARCH_ALL':
   if os.path.isfile(GIBzFHJlEUgQcYykhmSpsKubMOfCrN):os.remove(GIBzFHJlEUgQcYykhmSpsKubMOfCrN)
  elif GIBzFHJlEUgQcYykhmSpsKubMOfCXD=='SEARCH_ONE':
   try:
    GIBzFHJlEUgQcYykhmSpsKubMOfCXo=GIBzFHJlEUgQcYykhmSpsKubMOfCrN
    GIBzFHJlEUgQcYykhmSpsKubMOfCXw=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.Load_List_File('search') 
    fp=GIBzFHJlEUgQcYykhmSpsKubMOfCxA(GIBzFHJlEUgQcYykhmSpsKubMOfCXo,'w',-1,'utf-8')
    for GIBzFHJlEUgQcYykhmSpsKubMOfCXt in GIBzFHJlEUgQcYykhmSpsKubMOfCXw:
     GIBzFHJlEUgQcYykhmSpsKubMOfCXv=GIBzFHJlEUgQcYykhmSpsKubMOfCNe(urllib.parse.parse_qsl(GIBzFHJlEUgQcYykhmSpsKubMOfCXt))
     GIBzFHJlEUgQcYykhmSpsKubMOfCXR=GIBzFHJlEUgQcYykhmSpsKubMOfCXv.get('skey').strip()
     if GIBzFHJlEUgQcYykhmSpsKubMOfCXq!=GIBzFHJlEUgQcYykhmSpsKubMOfCXR:
      fp.write(GIBzFHJlEUgQcYykhmSpsKubMOfCXt)
    fp.close()
   except:
    GIBzFHJlEUgQcYykhmSpsKubMOfCNR
  elif GIBzFHJlEUgQcYykhmSpsKubMOfCXD=='WATCH_ALL':
   GIBzFHJlEUgQcYykhmSpsKubMOfCXo=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%GIBzFHJlEUgQcYykhmSpsKubMOfCXn))
   if os.path.isfile(GIBzFHJlEUgQcYykhmSpsKubMOfCXo):os.remove(GIBzFHJlEUgQcYykhmSpsKubMOfCXo)
  elif GIBzFHJlEUgQcYykhmSpsKubMOfCXD=='WATCH_ONE':
   GIBzFHJlEUgQcYykhmSpsKubMOfCXo=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%GIBzFHJlEUgQcYykhmSpsKubMOfCXn))
   try:
    GIBzFHJlEUgQcYykhmSpsKubMOfCXw=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.Load_List_File(GIBzFHJlEUgQcYykhmSpsKubMOfCXn) 
    fp=GIBzFHJlEUgQcYykhmSpsKubMOfCxA(GIBzFHJlEUgQcYykhmSpsKubMOfCXo,'w',-1,'utf-8')
    for GIBzFHJlEUgQcYykhmSpsKubMOfCXt in GIBzFHJlEUgQcYykhmSpsKubMOfCXw:
     GIBzFHJlEUgQcYykhmSpsKubMOfCXv=GIBzFHJlEUgQcYykhmSpsKubMOfCNe(urllib.parse.parse_qsl(GIBzFHJlEUgQcYykhmSpsKubMOfCXt))
     GIBzFHJlEUgQcYykhmSpsKubMOfCXR=GIBzFHJlEUgQcYykhmSpsKubMOfCXv.get('code').strip()
     if GIBzFHJlEUgQcYykhmSpsKubMOfCXq!=GIBzFHJlEUgQcYykhmSpsKubMOfCXR:
      fp.write(GIBzFHJlEUgQcYykhmSpsKubMOfCXt)
    fp.close()
   except:
    GIBzFHJlEUgQcYykhmSpsKubMOfCNR
  xbmc.executebuiltin("Container.Refresh")
 def Save_Searched_List(GIBzFHJlEUgQcYykhmSpsKubMOfCrx,GIBzFHJlEUgQcYykhmSpsKubMOfCoa):
  try:
   GIBzFHJlEUgQcYykhmSpsKubMOfCXa=GIBzFHJlEUgQcYykhmSpsKubMOfCrN
   GIBzFHJlEUgQcYykhmSpsKubMOfCXw=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.Load_List_File('search') 
   GIBzFHJlEUgQcYykhmSpsKubMOfCXW={'skey':GIBzFHJlEUgQcYykhmSpsKubMOfCoa.strip()}
   fp=GIBzFHJlEUgQcYykhmSpsKubMOfCxA(GIBzFHJlEUgQcYykhmSpsKubMOfCXa,'w',-1,'utf-8')
   GIBzFHJlEUgQcYykhmSpsKubMOfCXN=urllib.parse.urlencode(GIBzFHJlEUgQcYykhmSpsKubMOfCXW)
   GIBzFHJlEUgQcYykhmSpsKubMOfCXN=GIBzFHJlEUgQcYykhmSpsKubMOfCXN+'\n'
   fp.write(GIBzFHJlEUgQcYykhmSpsKubMOfCXN)
   GIBzFHJlEUgQcYykhmSpsKubMOfCXx=0
   for GIBzFHJlEUgQcYykhmSpsKubMOfCXt in GIBzFHJlEUgQcYykhmSpsKubMOfCXw:
    GIBzFHJlEUgQcYykhmSpsKubMOfCXv=GIBzFHJlEUgQcYykhmSpsKubMOfCNe(urllib.parse.parse_qsl(GIBzFHJlEUgQcYykhmSpsKubMOfCXt))
    GIBzFHJlEUgQcYykhmSpsKubMOfCXL=GIBzFHJlEUgQcYykhmSpsKubMOfCXW.get('skey').strip()
    GIBzFHJlEUgQcYykhmSpsKubMOfCXi=GIBzFHJlEUgQcYykhmSpsKubMOfCXv.get('skey').strip()
    if GIBzFHJlEUgQcYykhmSpsKubMOfCXL!=GIBzFHJlEUgQcYykhmSpsKubMOfCXi:
     fp.write(GIBzFHJlEUgQcYykhmSpsKubMOfCXt)
     GIBzFHJlEUgQcYykhmSpsKubMOfCXx+=1
     if GIBzFHJlEUgQcYykhmSpsKubMOfCXx>=50:break
   fp.close()
  except:
   GIBzFHJlEUgQcYykhmSpsKubMOfCNR
 def dp_Global_Search(GIBzFHJlEUgQcYykhmSpsKubMOfCrx,args):
  GIBzFHJlEUgQcYykhmSpsKubMOfCoj=args.get('mode')
  if GIBzFHJlEUgQcYykhmSpsKubMOfCoj=='TOTAL_SEARCH':
   GIBzFHJlEUgQcYykhmSpsKubMOfCXj='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   GIBzFHJlEUgQcYykhmSpsKubMOfCXj='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(GIBzFHJlEUgQcYykhmSpsKubMOfCXj)
 def dp_Bookmark_Menu(GIBzFHJlEUgQcYykhmSpsKubMOfCrx,args):
  GIBzFHJlEUgQcYykhmSpsKubMOfCXj='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(GIBzFHJlEUgQcYykhmSpsKubMOfCXj)
 def login_main(GIBzFHJlEUgQcYykhmSpsKubMOfCrx):
  (GIBzFHJlEUgQcYykhmSpsKubMOfCXd,GIBzFHJlEUgQcYykhmSpsKubMOfCXe,GIBzFHJlEUgQcYykhmSpsKubMOfCXT)=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.get_settings_account()
  if not(GIBzFHJlEUgQcYykhmSpsKubMOfCXd and GIBzFHJlEUgQcYykhmSpsKubMOfCXe):
   GIBzFHJlEUgQcYykhmSpsKubMOfCrD=xbmcgui.Dialog()
   GIBzFHJlEUgQcYykhmSpsKubMOfCXP=GIBzFHJlEUgQcYykhmSpsKubMOfCrD.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if GIBzFHJlEUgQcYykhmSpsKubMOfCXP==GIBzFHJlEUgQcYykhmSpsKubMOfCNW:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if GIBzFHJlEUgQcYykhmSpsKubMOfCrx.cookiefile_check()==GIBzFHJlEUgQcYykhmSpsKubMOfCNW:return
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   GIBzFHJlEUgQcYykhmSpsKubMOfCVr=0
   while GIBzFHJlEUgQcYykhmSpsKubMOfCNW:
    GIBzFHJlEUgQcYykhmSpsKubMOfCVr+=1
    time.sleep(0.05)
    if GIBzFHJlEUgQcYykhmSpsKubMOfCVr>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  GIBzFHJlEUgQcYykhmSpsKubMOfCVo=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.WavveObj.GetCredential(GIBzFHJlEUgQcYykhmSpsKubMOfCXd,GIBzFHJlEUgQcYykhmSpsKubMOfCXe,GIBzFHJlEUgQcYykhmSpsKubMOfCXT)
  if GIBzFHJlEUgQcYykhmSpsKubMOfCVo:GIBzFHJlEUgQcYykhmSpsKubMOfCrx.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
  if GIBzFHJlEUgQcYykhmSpsKubMOfCVo==GIBzFHJlEUgQcYykhmSpsKubMOfCNj:
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_setEpOrderby(GIBzFHJlEUgQcYykhmSpsKubMOfCrx,args):
  GIBzFHJlEUgQcYykhmSpsKubMOfCoN =args.get('orderby')
  GIBzFHJlEUgQcYykhmSpsKubMOfCrx.set_winEpisodeOrderby(GIBzFHJlEUgQcYykhmSpsKubMOfCoN)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(GIBzFHJlEUgQcYykhmSpsKubMOfCrx,args):
  GIBzFHJlEUgQcYykhmSpsKubMOfCoj =args.get('mode')
  GIBzFHJlEUgQcYykhmSpsKubMOfCVA =args.get('contentid')
  GIBzFHJlEUgQcYykhmSpsKubMOfCVX =args.get('pvrmode')
  GIBzFHJlEUgQcYykhmSpsKubMOfCVw=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.get_selQuality()
  GIBzFHJlEUgQcYykhmSpsKubMOfCrx.addon_log(GIBzFHJlEUgQcYykhmSpsKubMOfCVA+' - '+GIBzFHJlEUgQcYykhmSpsKubMOfCoj)
  if GIBzFHJlEUgQcYykhmSpsKubMOfCoj=='SPORTS':
   GIBzFHJlEUgQcYykhmSpsKubMOfCVN,GIBzFHJlEUgQcYykhmSpsKubMOfCVx=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.WavveObj.GetSportsURL(GIBzFHJlEUgQcYykhmSpsKubMOfCVA,GIBzFHJlEUgQcYykhmSpsKubMOfCVw)
   GIBzFHJlEUgQcYykhmSpsKubMOfCVt =''
   GIBzFHJlEUgQcYykhmSpsKubMOfCVv=''
  else:
   GIBzFHJlEUgQcYykhmSpsKubMOfCVN,GIBzFHJlEUgQcYykhmSpsKubMOfCVx,GIBzFHJlEUgQcYykhmSpsKubMOfCVt,GIBzFHJlEUgQcYykhmSpsKubMOfCVv=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.WavveObj.GetStreamingURL(GIBzFHJlEUgQcYykhmSpsKubMOfCoj,GIBzFHJlEUgQcYykhmSpsKubMOfCVA,GIBzFHJlEUgQcYykhmSpsKubMOfCVw,GIBzFHJlEUgQcYykhmSpsKubMOfCVX)
  GIBzFHJlEUgQcYykhmSpsKubMOfCVL='%s|Cookie=%s'%(GIBzFHJlEUgQcYykhmSpsKubMOfCVN,GIBzFHJlEUgQcYykhmSpsKubMOfCVx)
  GIBzFHJlEUgQcYykhmSpsKubMOfCrx.addon_log(GIBzFHJlEUgQcYykhmSpsKubMOfCVL)
  if GIBzFHJlEUgQcYykhmSpsKubMOfCVN=='':
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.addon_noti(__language__(30907).encode('utf8'))
   return
  GIBzFHJlEUgQcYykhmSpsKubMOfCVi=xbmcgui.ListItem(path=GIBzFHJlEUgQcYykhmSpsKubMOfCVL)
  if GIBzFHJlEUgQcYykhmSpsKubMOfCVt:
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.addon_log('!!streaming_drm!!')
   GIBzFHJlEUgQcYykhmSpsKubMOfCVD=GIBzFHJlEUgQcYykhmSpsKubMOfCVt['customdata']
   GIBzFHJlEUgQcYykhmSpsKubMOfCVq =GIBzFHJlEUgQcYykhmSpsKubMOfCVt['drmhost']
   GIBzFHJlEUgQcYykhmSpsKubMOfCVn =inputstreamhelper.Helper('mpd',drm='widevine')
   if GIBzFHJlEUgQcYykhmSpsKubMOfCVn.check_inputstream():
    if GIBzFHJlEUgQcYykhmSpsKubMOfCoj=='MOVIE':
     GIBzFHJlEUgQcYykhmSpsKubMOfCVP='https://www.wavve.com/player/movie?movieid=%s'%GIBzFHJlEUgQcYykhmSpsKubMOfCVA
    else:
     GIBzFHJlEUgQcYykhmSpsKubMOfCVP='https://www.wavve.com/player/vod?programid=%s&page=1'%GIBzFHJlEUgQcYykhmSpsKubMOfCVA
    GIBzFHJlEUgQcYykhmSpsKubMOfCVR={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':GIBzFHJlEUgQcYykhmSpsKubMOfCVD,'referer':GIBzFHJlEUgQcYykhmSpsKubMOfCVP,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':GIBzFHJlEUgQcYykhmSpsKubMOfCrx.WavveObj.USER_AGENT}
    GIBzFHJlEUgQcYykhmSpsKubMOfCVa=GIBzFHJlEUgQcYykhmSpsKubMOfCVq+'|'+urllib.parse.urlencode(GIBzFHJlEUgQcYykhmSpsKubMOfCVR)+'|R{SSM}|'
    GIBzFHJlEUgQcYykhmSpsKubMOfCVi.setProperty('inputstream',GIBzFHJlEUgQcYykhmSpsKubMOfCVn.inputstream_addon)
    GIBzFHJlEUgQcYykhmSpsKubMOfCVi.setProperty('inputstream.adaptive.manifest_type','mpd')
    GIBzFHJlEUgQcYykhmSpsKubMOfCVi.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    GIBzFHJlEUgQcYykhmSpsKubMOfCVi.setProperty('inputstream.adaptive.license_key',GIBzFHJlEUgQcYykhmSpsKubMOfCVa)
    GIBzFHJlEUgQcYykhmSpsKubMOfCVi.setProperty('inputstream.adaptive.stream_headers','user-agent=%s&Cookie=%s'%(GIBzFHJlEUgQcYykhmSpsKubMOfCrx.WavveObj.USER_AGENT,GIBzFHJlEUgQcYykhmSpsKubMOfCVx))
  xbmcplugin.setResolvedUrl(GIBzFHJlEUgQcYykhmSpsKubMOfCrx._addon_handle,GIBzFHJlEUgQcYykhmSpsKubMOfCNW,GIBzFHJlEUgQcYykhmSpsKubMOfCVi)
  GIBzFHJlEUgQcYykhmSpsKubMOfCVW=GIBzFHJlEUgQcYykhmSpsKubMOfCNj
  if GIBzFHJlEUgQcYykhmSpsKubMOfCVv:
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.addon_noti(GIBzFHJlEUgQcYykhmSpsKubMOfCVv.encode('utf-8'))
   GIBzFHJlEUgQcYykhmSpsKubMOfCVW=GIBzFHJlEUgQcYykhmSpsKubMOfCNW
  else:
   if '/preview.' in urllib.parse.urlsplit(GIBzFHJlEUgQcYykhmSpsKubMOfCVN).path:
    GIBzFHJlEUgQcYykhmSpsKubMOfCrx.addon_noti(__language__(30908).encode('utf8'))
    GIBzFHJlEUgQcYykhmSpsKubMOfCVW=GIBzFHJlEUgQcYykhmSpsKubMOfCNW
  try:
   GIBzFHJlEUgQcYykhmSpsKubMOfCVj=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and GIBzFHJlEUgQcYykhmSpsKubMOfCVW==GIBzFHJlEUgQcYykhmSpsKubMOfCNj and GIBzFHJlEUgQcYykhmSpsKubMOfCVj!='-':
    GIBzFHJlEUgQcYykhmSpsKubMOfCoD={'code':GIBzFHJlEUgQcYykhmSpsKubMOfCVj,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    GIBzFHJlEUgQcYykhmSpsKubMOfCrx.Save_Watched_List(args.get('mode').lower(),GIBzFHJlEUgQcYykhmSpsKubMOfCoD)
  except:
   GIBzFHJlEUgQcYykhmSpsKubMOfCNR
 def logout(GIBzFHJlEUgQcYykhmSpsKubMOfCrx):
  GIBzFHJlEUgQcYykhmSpsKubMOfCrD=xbmcgui.Dialog()
  GIBzFHJlEUgQcYykhmSpsKubMOfCXP=GIBzFHJlEUgQcYykhmSpsKubMOfCrD.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if GIBzFHJlEUgQcYykhmSpsKubMOfCXP==GIBzFHJlEUgQcYykhmSpsKubMOfCNj:sys.exit()
  GIBzFHJlEUgQcYykhmSpsKubMOfCrx.WavveObj.Init_WV_Total()
  if os.path.isfile(GIBzFHJlEUgQcYykhmSpsKubMOfCrw):os.remove(GIBzFHJlEUgQcYykhmSpsKubMOfCrw)
  GIBzFHJlEUgQcYykhmSpsKubMOfCrx.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(GIBzFHJlEUgQcYykhmSpsKubMOfCrx):
  GIBzFHJlEUgQcYykhmSpsKubMOfCVd =GIBzFHJlEUgQcYykhmSpsKubMOfCrx.WavveObj.Get_Now_Datetime()
  GIBzFHJlEUgQcYykhmSpsKubMOfCVe=GIBzFHJlEUgQcYykhmSpsKubMOfCVd+datetime.timedelta(days=GIBzFHJlEUgQcYykhmSpsKubMOfCNa(__addon__.getSetting('cache_ttl')))
  (GIBzFHJlEUgQcYykhmSpsKubMOfCXd,GIBzFHJlEUgQcYykhmSpsKubMOfCXe,GIBzFHJlEUgQcYykhmSpsKubMOfCXT)=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.get_settings_account()
  GIBzFHJlEUgQcYykhmSpsKubMOfCrx.WavveObj.Save_session_acount(GIBzFHJlEUgQcYykhmSpsKubMOfCXd,GIBzFHJlEUgQcYykhmSpsKubMOfCXe,GIBzFHJlEUgQcYykhmSpsKubMOfCXT)
  GIBzFHJlEUgQcYykhmSpsKubMOfCrx.WavveObj.WV['account']['token_limit']=GIBzFHJlEUgQcYykhmSpsKubMOfCVe.strftime('%Y%m%d')
  try: 
   fp=GIBzFHJlEUgQcYykhmSpsKubMOfCxA(GIBzFHJlEUgQcYykhmSpsKubMOfCrw,'w',-1,'utf-8')
   json.dump(GIBzFHJlEUgQcYykhmSpsKubMOfCrx.WavveObj.WV,fp,indent=4,ensure_ascii=GIBzFHJlEUgQcYykhmSpsKubMOfCNj)
   fp.close()
  except GIBzFHJlEUgQcYykhmSpsKubMOfCxX as exception:
   GIBzFHJlEUgQcYykhmSpsKubMOfCxV(exception)
 def cookiefile_check(GIBzFHJlEUgQcYykhmSpsKubMOfCrx):
  GIBzFHJlEUgQcYykhmSpsKubMOfCrx.WavveObj.WV=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.WavveObj.JsonFile_Load(GIBzFHJlEUgQcYykhmSpsKubMOfCrw)
  if 'account' not in GIBzFHJlEUgQcYykhmSpsKubMOfCrx.WavveObj.WV:
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.WavveObj.Init_WV_Total()
   return GIBzFHJlEUgQcYykhmSpsKubMOfCNj
  (GIBzFHJlEUgQcYykhmSpsKubMOfCwr,GIBzFHJlEUgQcYykhmSpsKubMOfCwo,GIBzFHJlEUgQcYykhmSpsKubMOfCwA)=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.get_settings_account()
  (GIBzFHJlEUgQcYykhmSpsKubMOfCwX,GIBzFHJlEUgQcYykhmSpsKubMOfCwV,GIBzFHJlEUgQcYykhmSpsKubMOfCwN)=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.WavveObj.Load_session_acount()
  if GIBzFHJlEUgQcYykhmSpsKubMOfCwr!=GIBzFHJlEUgQcYykhmSpsKubMOfCwX or GIBzFHJlEUgQcYykhmSpsKubMOfCwo!=GIBzFHJlEUgQcYykhmSpsKubMOfCwV or GIBzFHJlEUgQcYykhmSpsKubMOfCwA!=GIBzFHJlEUgQcYykhmSpsKubMOfCwN:
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.WavveObj.Init_WV_Total()
   return GIBzFHJlEUgQcYykhmSpsKubMOfCNj
  if GIBzFHJlEUgQcYykhmSpsKubMOfCNa(GIBzFHJlEUgQcYykhmSpsKubMOfCrx.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))>GIBzFHJlEUgQcYykhmSpsKubMOfCNa(GIBzFHJlEUgQcYykhmSpsKubMOfCrx.WavveObj.WV['account']['token_limit']):
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.WavveObj.Init_WV_Total()
   return GIBzFHJlEUgQcYykhmSpsKubMOfCNj
  return GIBzFHJlEUgQcYykhmSpsKubMOfCNW
 def dp_LiveCatagory_List(GIBzFHJlEUgQcYykhmSpsKubMOfCrx,args):
  GIBzFHJlEUgQcYykhmSpsKubMOfCwx =args.get('sCode')
  GIBzFHJlEUgQcYykhmSpsKubMOfCwt=args.get('sIndex')
  GIBzFHJlEUgQcYykhmSpsKubMOfCAn,GIBzFHJlEUgQcYykhmSpsKubMOfCwv=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.WavveObj.Get_LiveCatagory_List(GIBzFHJlEUgQcYykhmSpsKubMOfCwx,GIBzFHJlEUgQcYykhmSpsKubMOfCwt)
  for GIBzFHJlEUgQcYykhmSpsKubMOfCAP in GIBzFHJlEUgQcYykhmSpsKubMOfCAn:
   GIBzFHJlEUgQcYykhmSpsKubMOfCot =GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('title')
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD={'mode':'LIVE_LIST','genre':GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('genre'),'baseapi':GIBzFHJlEUgQcYykhmSpsKubMOfCwv}
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.add_dir(GIBzFHJlEUgQcYykhmSpsKubMOfCot,sublabel='',img='',infoLabels=GIBzFHJlEUgQcYykhmSpsKubMOfCNR,isFolder=GIBzFHJlEUgQcYykhmSpsKubMOfCNW,params=GIBzFHJlEUgQcYykhmSpsKubMOfCoD)
  if GIBzFHJlEUgQcYykhmSpsKubMOfCNT(GIBzFHJlEUgQcYykhmSpsKubMOfCAn)>0:xbmcplugin.endOfDirectory(GIBzFHJlEUgQcYykhmSpsKubMOfCrx._addon_handle,cacheToDisc=GIBzFHJlEUgQcYykhmSpsKubMOfCNj)
 def dp_MainCatagory_List(GIBzFHJlEUgQcYykhmSpsKubMOfCrx,args):
  GIBzFHJlEUgQcYykhmSpsKubMOfCwx =args.get('sCode')
  GIBzFHJlEUgQcYykhmSpsKubMOfCwt=args.get('sIndex')
  GIBzFHJlEUgQcYykhmSpsKubMOfCod =args.get('sType')
  GIBzFHJlEUgQcYykhmSpsKubMOfCAn=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.WavveObj.Get_MainCatagory_List(GIBzFHJlEUgQcYykhmSpsKubMOfCwx,GIBzFHJlEUgQcYykhmSpsKubMOfCwt)
  for GIBzFHJlEUgQcYykhmSpsKubMOfCAP in GIBzFHJlEUgQcYykhmSpsKubMOfCAn:
   if GIBzFHJlEUgQcYykhmSpsKubMOfCod=='vod':
    if GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('subtype')=='catagory':
     GIBzFHJlEUgQcYykhmSpsKubMOfCoj='PROGRAM_LIST'
    else:
     GIBzFHJlEUgQcYykhmSpsKubMOfCoj='SUPERSECTION_LIST'
   elif GIBzFHJlEUgQcYykhmSpsKubMOfCod=='movie':
    GIBzFHJlEUgQcYykhmSpsKubMOfCoj='MOVIE_LIST'
   else:
    GIBzFHJlEUgQcYykhmSpsKubMOfCoj=''
   GIBzFHJlEUgQcYykhmSpsKubMOfCot='%s (%s)'%(GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('title'),args.get('ordernm'))
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD={'mode':GIBzFHJlEUgQcYykhmSpsKubMOfCoj,'suburl':GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('suburl'),'subapi':GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if GIBzFHJlEUgQcYykhmSpsKubMOfCrx.get_settings_exclusion21():
    if GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('title')=='성인' or GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('title')=='성인+' or GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('title')=='에로티시즘' or GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('title')=='19':continue
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.add_dir(GIBzFHJlEUgQcYykhmSpsKubMOfCot,sublabel='',img='',infoLabels=GIBzFHJlEUgQcYykhmSpsKubMOfCNR,isFolder=GIBzFHJlEUgQcYykhmSpsKubMOfCNW,params=GIBzFHJlEUgQcYykhmSpsKubMOfCoD)
  if GIBzFHJlEUgQcYykhmSpsKubMOfCNT(GIBzFHJlEUgQcYykhmSpsKubMOfCAn)>0:xbmcplugin.endOfDirectory(GIBzFHJlEUgQcYykhmSpsKubMOfCrx._addon_handle,cacheToDisc=GIBzFHJlEUgQcYykhmSpsKubMOfCNj)
 def dp_Program_List(GIBzFHJlEUgQcYykhmSpsKubMOfCrx,args):
  GIBzFHJlEUgQcYykhmSpsKubMOfCwL =args.get('subapi')
  GIBzFHJlEUgQcYykhmSpsKubMOfCAq=GIBzFHJlEUgQcYykhmSpsKubMOfCNa(args.get('page'))
  GIBzFHJlEUgQcYykhmSpsKubMOfCoN =args.get('orderby')
  GIBzFHJlEUgQcYykhmSpsKubMOfCAn,GIBzFHJlEUgQcYykhmSpsKubMOfCoT=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.WavveObj.Get_Program_List(GIBzFHJlEUgQcYykhmSpsKubMOfCwL,GIBzFHJlEUgQcYykhmSpsKubMOfCAq,GIBzFHJlEUgQcYykhmSpsKubMOfCoN)
  for GIBzFHJlEUgQcYykhmSpsKubMOfCAP in GIBzFHJlEUgQcYykhmSpsKubMOfCAn:
   GIBzFHJlEUgQcYykhmSpsKubMOfCot =GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('title')
   GIBzFHJlEUgQcYykhmSpsKubMOfCAR=GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('thumbnail')
   GIBzFHJlEUgQcYykhmSpsKubMOfCAa =GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('age')
   if GIBzFHJlEUgQcYykhmSpsKubMOfCAa=='18' or GIBzFHJlEUgQcYykhmSpsKubMOfCAa=='19' or GIBzFHJlEUgQcYykhmSpsKubMOfCAa=='21':GIBzFHJlEUgQcYykhmSpsKubMOfCot+=' (%s)'%(GIBzFHJlEUgQcYykhmSpsKubMOfCAa)
   GIBzFHJlEUgQcYykhmSpsKubMOfCAD={'plot':GIBzFHJlEUgQcYykhmSpsKubMOfCot,'mpaa':GIBzFHJlEUgQcYykhmSpsKubMOfCAa,'mediatype':'tvshow'}
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD={'mode':'EPISODE_LIST','videoid':GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('videoid'),'vidtype':GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('vidtype'),'page':'1'}
   if GIBzFHJlEUgQcYykhmSpsKubMOfCrx.get_settings_makebookmark():
    GIBzFHJlEUgQcYykhmSpsKubMOfCAW={'videoid':GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('videoid'),'vidtype':'tvshow','vtitle':GIBzFHJlEUgQcYykhmSpsKubMOfCot,'vsubtitle':'','contenttype':GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('vidtype'),}
    GIBzFHJlEUgQcYykhmSpsKubMOfCAj=json.dumps(GIBzFHJlEUgQcYykhmSpsKubMOfCAW)
    GIBzFHJlEUgQcYykhmSpsKubMOfCAj=urllib.parse.quote(GIBzFHJlEUgQcYykhmSpsKubMOfCAj)
    GIBzFHJlEUgQcYykhmSpsKubMOfCAd='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(GIBzFHJlEUgQcYykhmSpsKubMOfCAj)
    GIBzFHJlEUgQcYykhmSpsKubMOfCAi=[('(통합) 찜 영상에 추가',GIBzFHJlEUgQcYykhmSpsKubMOfCAd)]
   else:
    GIBzFHJlEUgQcYykhmSpsKubMOfCAi=GIBzFHJlEUgQcYykhmSpsKubMOfCNR
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.add_dir(GIBzFHJlEUgQcYykhmSpsKubMOfCot,sublabel='',img=GIBzFHJlEUgQcYykhmSpsKubMOfCAR,infoLabels=GIBzFHJlEUgQcYykhmSpsKubMOfCAD,isFolder=GIBzFHJlEUgQcYykhmSpsKubMOfCNW,params=GIBzFHJlEUgQcYykhmSpsKubMOfCoD,ContextMenu=GIBzFHJlEUgQcYykhmSpsKubMOfCAi)
  if GIBzFHJlEUgQcYykhmSpsKubMOfCoT:
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD={}
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD['mode'] ='PROGRAM_LIST' 
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD['subapi']=GIBzFHJlEUgQcYykhmSpsKubMOfCwL 
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD['page'] =GIBzFHJlEUgQcYykhmSpsKubMOfCxo(GIBzFHJlEUgQcYykhmSpsKubMOfCAq+1)
   GIBzFHJlEUgQcYykhmSpsKubMOfCot='[B]%s >>[/B]'%'다음 페이지'
   GIBzFHJlEUgQcYykhmSpsKubMOfCAe=GIBzFHJlEUgQcYykhmSpsKubMOfCxo(GIBzFHJlEUgQcYykhmSpsKubMOfCAq+1)
   GIBzFHJlEUgQcYykhmSpsKubMOfCoi=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.add_dir(GIBzFHJlEUgQcYykhmSpsKubMOfCot,sublabel=GIBzFHJlEUgQcYykhmSpsKubMOfCAe,img=GIBzFHJlEUgQcYykhmSpsKubMOfCoi,infoLabels=GIBzFHJlEUgQcYykhmSpsKubMOfCNR,isFolder=GIBzFHJlEUgQcYykhmSpsKubMOfCNW,params=GIBzFHJlEUgQcYykhmSpsKubMOfCoD)
  xbmcplugin.setContent(GIBzFHJlEUgQcYykhmSpsKubMOfCrx._addon_handle,'tvshows')
  if GIBzFHJlEUgQcYykhmSpsKubMOfCNT(GIBzFHJlEUgQcYykhmSpsKubMOfCAn)>0:xbmcplugin.endOfDirectory(GIBzFHJlEUgQcYykhmSpsKubMOfCrx._addon_handle,cacheToDisc=GIBzFHJlEUgQcYykhmSpsKubMOfCNj)
 def dp_SuperSection_List(GIBzFHJlEUgQcYykhmSpsKubMOfCrx,args):
  GIBzFHJlEUgQcYykhmSpsKubMOfCwi =args.get('suburl')
  GIBzFHJlEUgQcYykhmSpsKubMOfCAn=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.WavveObj.Get_SuperMultiSection_List(GIBzFHJlEUgQcYykhmSpsKubMOfCwi)
  for GIBzFHJlEUgQcYykhmSpsKubMOfCAP in GIBzFHJlEUgQcYykhmSpsKubMOfCAn:
   GIBzFHJlEUgQcYykhmSpsKubMOfCot =GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('title')
   GIBzFHJlEUgQcYykhmSpsKubMOfCwL =GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('subapi')
   GIBzFHJlEUgQcYykhmSpsKubMOfCwD=GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('cell_type')
   if GIBzFHJlEUgQcYykhmSpsKubMOfCwL.find('mtype=svod')>=0 or GIBzFHJlEUgQcYykhmSpsKubMOfCwL.find('mtype=ppv')>=0:
    GIBzFHJlEUgQcYykhmSpsKubMOfCoj='MOVIE_LIST'
   elif GIBzFHJlEUgQcYykhmSpsKubMOfCwD=='band_71':
    GIBzFHJlEUgQcYykhmSpsKubMOfCoj ='SUPERSECTION_LIST'
    (GIBzFHJlEUgQcYykhmSpsKubMOfCwq,GIBzFHJlEUgQcYykhmSpsKubMOfCwn)=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.WavveObj.Baseapi_Parse(GIBzFHJlEUgQcYykhmSpsKubMOfCwL)
    GIBzFHJlEUgQcYykhmSpsKubMOfCwi=GIBzFHJlEUgQcYykhmSpsKubMOfCwn.get('api')
    GIBzFHJlEUgQcYykhmSpsKubMOfCwL=''
   elif GIBzFHJlEUgQcYykhmSpsKubMOfCwD=='band_2':
    GIBzFHJlEUgQcYykhmSpsKubMOfCoj='BAND2SECTION_LIST'
   elif GIBzFHJlEUgQcYykhmSpsKubMOfCwD=='band_live':
    GIBzFHJlEUgQcYykhmSpsKubMOfCoj='BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}',GIBzFHJlEUgQcYykhmSpsKubMOfCwL):
    GIBzFHJlEUgQcYykhmSpsKubMOfCoj='MOVIE_LIST'
   else:
    GIBzFHJlEUgQcYykhmSpsKubMOfCoj='PROGRAM_LIST'
   GIBzFHJlEUgQcYykhmSpsKubMOfCAD={'plot':GIBzFHJlEUgQcYykhmSpsKubMOfCot,'mediatype':'tvshow'}
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD={'mode':GIBzFHJlEUgQcYykhmSpsKubMOfCoj,'suburl':GIBzFHJlEUgQcYykhmSpsKubMOfCwi,'subapi':GIBzFHJlEUgQcYykhmSpsKubMOfCwL,'page':'1'}
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.add_dir(GIBzFHJlEUgQcYykhmSpsKubMOfCot,sublabel='',img=GIBzFHJlEUgQcYykhmSpsKubMOfCNR,infoLabels=GIBzFHJlEUgQcYykhmSpsKubMOfCAD,isFolder=GIBzFHJlEUgQcYykhmSpsKubMOfCNW,params=GIBzFHJlEUgQcYykhmSpsKubMOfCoD)
  if GIBzFHJlEUgQcYykhmSpsKubMOfCNT(GIBzFHJlEUgQcYykhmSpsKubMOfCAn)>0:xbmcplugin.endOfDirectory(GIBzFHJlEUgQcYykhmSpsKubMOfCrx._addon_handle,cacheToDisc=GIBzFHJlEUgQcYykhmSpsKubMOfCNj)
 def dp_BandLiveSection_List(GIBzFHJlEUgQcYykhmSpsKubMOfCrx,args):
  GIBzFHJlEUgQcYykhmSpsKubMOfCwL =args.get('subapi')
  GIBzFHJlEUgQcYykhmSpsKubMOfCAq=GIBzFHJlEUgQcYykhmSpsKubMOfCNa(args.get('page'))
  GIBzFHJlEUgQcYykhmSpsKubMOfCAn,GIBzFHJlEUgQcYykhmSpsKubMOfCoT=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.WavveObj.Get_BandLiveSection_List(GIBzFHJlEUgQcYykhmSpsKubMOfCwL,GIBzFHJlEUgQcYykhmSpsKubMOfCAq)
  for GIBzFHJlEUgQcYykhmSpsKubMOfCAP in GIBzFHJlEUgQcYykhmSpsKubMOfCAn:
   GIBzFHJlEUgQcYykhmSpsKubMOfCwP =GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('channelid')
   GIBzFHJlEUgQcYykhmSpsKubMOfCwR =GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('studio')
   GIBzFHJlEUgQcYykhmSpsKubMOfCwa=GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('tvshowtitle')
   GIBzFHJlEUgQcYykhmSpsKubMOfCAR =GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('thumbnail')
   GIBzFHJlEUgQcYykhmSpsKubMOfCAa =GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('age')
   GIBzFHJlEUgQcYykhmSpsKubMOfCAD={'mediatype':'tvshow','mpaa':GIBzFHJlEUgQcYykhmSpsKubMOfCAa,'title':'%s < %s >'%(GIBzFHJlEUgQcYykhmSpsKubMOfCwR,GIBzFHJlEUgQcYykhmSpsKubMOfCwa),'tvshowtitle':GIBzFHJlEUgQcYykhmSpsKubMOfCwa,'studio':GIBzFHJlEUgQcYykhmSpsKubMOfCwR,'plot':GIBzFHJlEUgQcYykhmSpsKubMOfCwR}
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD={'mode':'LIVE','contentid':GIBzFHJlEUgQcYykhmSpsKubMOfCwP}
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.add_dir(GIBzFHJlEUgQcYykhmSpsKubMOfCwR,sublabel=GIBzFHJlEUgQcYykhmSpsKubMOfCwa,img=GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('thumbnail'),infoLabels=GIBzFHJlEUgQcYykhmSpsKubMOfCAD,isFolder=GIBzFHJlEUgQcYykhmSpsKubMOfCNj,params=GIBzFHJlEUgQcYykhmSpsKubMOfCoD)
  if GIBzFHJlEUgQcYykhmSpsKubMOfCoT:
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD={}
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD['mode'] ='BANDLIVESECTION_LIST' 
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD['subapi']=GIBzFHJlEUgQcYykhmSpsKubMOfCwL
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD['page'] =GIBzFHJlEUgQcYykhmSpsKubMOfCxo(GIBzFHJlEUgQcYykhmSpsKubMOfCAq+1)
   GIBzFHJlEUgQcYykhmSpsKubMOfCot='[B]%s >>[/B]'%'다음 페이지'
   GIBzFHJlEUgQcYykhmSpsKubMOfCAe=GIBzFHJlEUgQcYykhmSpsKubMOfCxo(GIBzFHJlEUgQcYykhmSpsKubMOfCAq+1)
   GIBzFHJlEUgQcYykhmSpsKubMOfCoi=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.add_dir(GIBzFHJlEUgQcYykhmSpsKubMOfCot,sublabel=GIBzFHJlEUgQcYykhmSpsKubMOfCAe,img=GIBzFHJlEUgQcYykhmSpsKubMOfCoi,infoLabels=GIBzFHJlEUgQcYykhmSpsKubMOfCNR,isFolder=GIBzFHJlEUgQcYykhmSpsKubMOfCNW,params=GIBzFHJlEUgQcYykhmSpsKubMOfCoD)
  if GIBzFHJlEUgQcYykhmSpsKubMOfCNT(GIBzFHJlEUgQcYykhmSpsKubMOfCAn)>0:xbmcplugin.endOfDirectory(GIBzFHJlEUgQcYykhmSpsKubMOfCrx._addon_handle,cacheToDisc=GIBzFHJlEUgQcYykhmSpsKubMOfCNj)
 def dp_Band2Section_List(GIBzFHJlEUgQcYykhmSpsKubMOfCrx,args):
  GIBzFHJlEUgQcYykhmSpsKubMOfCwL =args.get('subapi')
  GIBzFHJlEUgQcYykhmSpsKubMOfCAq=GIBzFHJlEUgQcYykhmSpsKubMOfCNa(args.get('page'))
  GIBzFHJlEUgQcYykhmSpsKubMOfCAn,GIBzFHJlEUgQcYykhmSpsKubMOfCoT=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.WavveObj.Get_Band2Section_List(GIBzFHJlEUgQcYykhmSpsKubMOfCwL,GIBzFHJlEUgQcYykhmSpsKubMOfCAq)
  for GIBzFHJlEUgQcYykhmSpsKubMOfCAP in GIBzFHJlEUgQcYykhmSpsKubMOfCAn:
   GIBzFHJlEUgQcYykhmSpsKubMOfCot =GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('programtitle')
   GIBzFHJlEUgQcYykhmSpsKubMOfCAe =GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('episodetitle')
   GIBzFHJlEUgQcYykhmSpsKubMOfCAD={'plot':GIBzFHJlEUgQcYykhmSpsKubMOfCot+'\n\n'+GIBzFHJlEUgQcYykhmSpsKubMOfCAe,'mpaa':GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('age'),'mediatype':'episode'}
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD={'mode':'VOD','programid':'-','contentid':GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('videoid'),'thumbnail':GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('thumbnail'),'title':GIBzFHJlEUgQcYykhmSpsKubMOfCot,'subtitle':GIBzFHJlEUgQcYykhmSpsKubMOfCAe}
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.add_dir(GIBzFHJlEUgQcYykhmSpsKubMOfCot,sublabel=GIBzFHJlEUgQcYykhmSpsKubMOfCAe,img=GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('thumbnail'),infoLabels=GIBzFHJlEUgQcYykhmSpsKubMOfCAD,isFolder=GIBzFHJlEUgQcYykhmSpsKubMOfCNj,params=GIBzFHJlEUgQcYykhmSpsKubMOfCoD)
  if GIBzFHJlEUgQcYykhmSpsKubMOfCoT:
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD={}
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD['mode'] ='BAND2SECTION_LIST' 
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD['subapi']=GIBzFHJlEUgQcYykhmSpsKubMOfCwL
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD['page'] =GIBzFHJlEUgQcYykhmSpsKubMOfCxo(GIBzFHJlEUgQcYykhmSpsKubMOfCAq+1)
   GIBzFHJlEUgQcYykhmSpsKubMOfCot='[B]%s >>[/B]'%'다음 페이지'
   GIBzFHJlEUgQcYykhmSpsKubMOfCAe=GIBzFHJlEUgQcYykhmSpsKubMOfCxo(GIBzFHJlEUgQcYykhmSpsKubMOfCAq+1)
   GIBzFHJlEUgQcYykhmSpsKubMOfCoi=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.add_dir(GIBzFHJlEUgQcYykhmSpsKubMOfCot,sublabel=GIBzFHJlEUgQcYykhmSpsKubMOfCAe,img=GIBzFHJlEUgQcYykhmSpsKubMOfCoi,infoLabels=GIBzFHJlEUgQcYykhmSpsKubMOfCNR,isFolder=GIBzFHJlEUgQcYykhmSpsKubMOfCNW,params=GIBzFHJlEUgQcYykhmSpsKubMOfCoD)
  if GIBzFHJlEUgQcYykhmSpsKubMOfCNT(GIBzFHJlEUgQcYykhmSpsKubMOfCAn)>0:xbmcplugin.endOfDirectory(GIBzFHJlEUgQcYykhmSpsKubMOfCrx._addon_handle,cacheToDisc=GIBzFHJlEUgQcYykhmSpsKubMOfCNj)
 def dp_Movie_List(GIBzFHJlEUgQcYykhmSpsKubMOfCrx,args):
  GIBzFHJlEUgQcYykhmSpsKubMOfCwL =args.get('subapi')
  GIBzFHJlEUgQcYykhmSpsKubMOfCAq=GIBzFHJlEUgQcYykhmSpsKubMOfCNa(args.get('page'))
  GIBzFHJlEUgQcYykhmSpsKubMOfCAn,GIBzFHJlEUgQcYykhmSpsKubMOfCoT=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.WavveObj.Get_Movie_List(GIBzFHJlEUgQcYykhmSpsKubMOfCwL,GIBzFHJlEUgQcYykhmSpsKubMOfCAq)
  for GIBzFHJlEUgQcYykhmSpsKubMOfCAP in GIBzFHJlEUgQcYykhmSpsKubMOfCAn:
   GIBzFHJlEUgQcYykhmSpsKubMOfCot =GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('title')
   GIBzFHJlEUgQcYykhmSpsKubMOfCAR=GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('thumbnail')
   GIBzFHJlEUgQcYykhmSpsKubMOfCAa =GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('age')
   if GIBzFHJlEUgQcYykhmSpsKubMOfCAa=='18' or GIBzFHJlEUgQcYykhmSpsKubMOfCAa=='19' or GIBzFHJlEUgQcYykhmSpsKubMOfCAa=='21':GIBzFHJlEUgQcYykhmSpsKubMOfCot+=' (%s)'%(GIBzFHJlEUgQcYykhmSpsKubMOfCAa)
   GIBzFHJlEUgQcYykhmSpsKubMOfCAD={'plot':GIBzFHJlEUgQcYykhmSpsKubMOfCot,'mpaa':GIBzFHJlEUgQcYykhmSpsKubMOfCAa,'mediatype':'movie'}
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD={'mode':'MOVIE','contentid':GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('videoid'),'title':GIBzFHJlEUgQcYykhmSpsKubMOfCot,'thumbnail':GIBzFHJlEUgQcYykhmSpsKubMOfCAR,'age':GIBzFHJlEUgQcYykhmSpsKubMOfCAa}
   if GIBzFHJlEUgQcYykhmSpsKubMOfCrx.get_settings_makebookmark():
    GIBzFHJlEUgQcYykhmSpsKubMOfCAW={'videoid':GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('videoid'),'vidtype':'movie','vtitle':GIBzFHJlEUgQcYykhmSpsKubMOfCot,'vsubtitle':'','contenttype':'programid',}
    GIBzFHJlEUgQcYykhmSpsKubMOfCAj=json.dumps(GIBzFHJlEUgQcYykhmSpsKubMOfCAW)
    GIBzFHJlEUgQcYykhmSpsKubMOfCAj=urllib.parse.quote(GIBzFHJlEUgQcYykhmSpsKubMOfCAj)
    GIBzFHJlEUgQcYykhmSpsKubMOfCAd='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(GIBzFHJlEUgQcYykhmSpsKubMOfCAj)
    GIBzFHJlEUgQcYykhmSpsKubMOfCAi=[('(통합) 찜 영상에 추가',GIBzFHJlEUgQcYykhmSpsKubMOfCAd)]
   else:
    GIBzFHJlEUgQcYykhmSpsKubMOfCAi=GIBzFHJlEUgQcYykhmSpsKubMOfCNR
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.add_dir(GIBzFHJlEUgQcYykhmSpsKubMOfCot,sublabel='',img=GIBzFHJlEUgQcYykhmSpsKubMOfCAR,infoLabels=GIBzFHJlEUgQcYykhmSpsKubMOfCAD,isFolder=GIBzFHJlEUgQcYykhmSpsKubMOfCNj,params=GIBzFHJlEUgQcYykhmSpsKubMOfCoD,ContextMenu=GIBzFHJlEUgQcYykhmSpsKubMOfCAi)
  if GIBzFHJlEUgQcYykhmSpsKubMOfCoT:
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD={}
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD['mode'] ='MOVIE_LIST' 
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD['subapi']=GIBzFHJlEUgQcYykhmSpsKubMOfCwL 
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD['page'] =GIBzFHJlEUgQcYykhmSpsKubMOfCxo(GIBzFHJlEUgQcYykhmSpsKubMOfCAq+1)
   GIBzFHJlEUgQcYykhmSpsKubMOfCot='[B]%s >>[/B]'%'다음 페이지'
   GIBzFHJlEUgQcYykhmSpsKubMOfCAe=GIBzFHJlEUgQcYykhmSpsKubMOfCxo(GIBzFHJlEUgQcYykhmSpsKubMOfCAq+1)
   GIBzFHJlEUgQcYykhmSpsKubMOfCoi=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.add_dir(GIBzFHJlEUgQcYykhmSpsKubMOfCot,sublabel=GIBzFHJlEUgQcYykhmSpsKubMOfCAe,img=GIBzFHJlEUgQcYykhmSpsKubMOfCoi,infoLabels=GIBzFHJlEUgQcYykhmSpsKubMOfCNR,isFolder=GIBzFHJlEUgQcYykhmSpsKubMOfCNW,params=GIBzFHJlEUgQcYykhmSpsKubMOfCoD)
  xbmcplugin.setContent(GIBzFHJlEUgQcYykhmSpsKubMOfCrx._addon_handle,'movies')
  if GIBzFHJlEUgQcYykhmSpsKubMOfCNT(GIBzFHJlEUgQcYykhmSpsKubMOfCAn)>0:xbmcplugin.endOfDirectory(GIBzFHJlEUgQcYykhmSpsKubMOfCrx._addon_handle,cacheToDisc=GIBzFHJlEUgQcYykhmSpsKubMOfCNj)
 def dp_Set_Bookmark(GIBzFHJlEUgQcYykhmSpsKubMOfCrx,args):
  GIBzFHJlEUgQcYykhmSpsKubMOfCwW=urllib.parse.unquote(args.get('bm_param'))
  GIBzFHJlEUgQcYykhmSpsKubMOfCwW=json.loads(GIBzFHJlEUgQcYykhmSpsKubMOfCwW)
  GIBzFHJlEUgQcYykhmSpsKubMOfCXr =GIBzFHJlEUgQcYykhmSpsKubMOfCwW.get('videoid')
  GIBzFHJlEUgQcYykhmSpsKubMOfCwj =GIBzFHJlEUgQcYykhmSpsKubMOfCwW.get('vidtype')
  GIBzFHJlEUgQcYykhmSpsKubMOfCwd =GIBzFHJlEUgQcYykhmSpsKubMOfCwW.get('vtitle')
  GIBzFHJlEUgQcYykhmSpsKubMOfCwe =GIBzFHJlEUgQcYykhmSpsKubMOfCwW.get('vsubtitle')
  GIBzFHJlEUgQcYykhmSpsKubMOfCwT=GIBzFHJlEUgQcYykhmSpsKubMOfCwW.get('contenttype')
  GIBzFHJlEUgQcYykhmSpsKubMOfCrD=xbmcgui.Dialog()
  GIBzFHJlEUgQcYykhmSpsKubMOfCXP=GIBzFHJlEUgQcYykhmSpsKubMOfCrD.yesno(__language__(30913).encode('utf8'),GIBzFHJlEUgQcYykhmSpsKubMOfCwd+' \n\n'+__language__(30914))
  if GIBzFHJlEUgQcYykhmSpsKubMOfCXP==GIBzFHJlEUgQcYykhmSpsKubMOfCNj:return
  GIBzFHJlEUgQcYykhmSpsKubMOfCNr=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.WavveObj.GetBookmarkInfo(GIBzFHJlEUgQcYykhmSpsKubMOfCXr,GIBzFHJlEUgQcYykhmSpsKubMOfCwj,GIBzFHJlEUgQcYykhmSpsKubMOfCwT)
  GIBzFHJlEUgQcYykhmSpsKubMOfCNo=json.dumps(GIBzFHJlEUgQcYykhmSpsKubMOfCNr)
  GIBzFHJlEUgQcYykhmSpsKubMOfCNo=urllib.parse.quote(GIBzFHJlEUgQcYykhmSpsKubMOfCNo)
  GIBzFHJlEUgQcYykhmSpsKubMOfCAd ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(GIBzFHJlEUgQcYykhmSpsKubMOfCNo)
  xbmc.executebuiltin(GIBzFHJlEUgQcYykhmSpsKubMOfCAd)
 def dp_Episode_List(GIBzFHJlEUgQcYykhmSpsKubMOfCrx,args):
  GIBzFHJlEUgQcYykhmSpsKubMOfCXr =args.get('videoid')
  GIBzFHJlEUgQcYykhmSpsKubMOfCwj =args.get('vidtype')
  GIBzFHJlEUgQcYykhmSpsKubMOfCAq=GIBzFHJlEUgQcYykhmSpsKubMOfCNa(args.get('page'))
  GIBzFHJlEUgQcYykhmSpsKubMOfCAn,GIBzFHJlEUgQcYykhmSpsKubMOfCoT=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.WavveObj.Get_Episode_List(GIBzFHJlEUgQcYykhmSpsKubMOfCXr,GIBzFHJlEUgQcYykhmSpsKubMOfCwj,GIBzFHJlEUgQcYykhmSpsKubMOfCAq,orderby=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.get_winEpisodeOrderby())
  for GIBzFHJlEUgQcYykhmSpsKubMOfCAP in GIBzFHJlEUgQcYykhmSpsKubMOfCAn:
   GIBzFHJlEUgQcYykhmSpsKubMOfCAe='%s회, %s(%s)'%(GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('episodenumber'),GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('releasedate'),GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('releaseweekday'))
   GIBzFHJlEUgQcYykhmSpsKubMOfCNA ='[%s]\n\n%s'%(GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('episodetitle'),GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('synopsis'))
   GIBzFHJlEUgQcYykhmSpsKubMOfCAD={'mediatype':'episode','title':GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('programtitle'),'year':GIBzFHJlEUgQcYykhmSpsKubMOfCNa(GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('releasedate')[:4]),'aired':GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('releasedate'),'mpaa':GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('age'),'episode':GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('episodenumber'),'duration':GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('playtime'),'plot':GIBzFHJlEUgQcYykhmSpsKubMOfCNA,'cast':GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('episodeactors')}
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD={'mode':'VOD','programid':GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('programid'),'contentid':GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('contentid'),'thumbnail':GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('thumbnail'),'title':GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('programtitle'),'subtitle':GIBzFHJlEUgQcYykhmSpsKubMOfCAe}
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.add_dir(GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('programtitle'),sublabel=GIBzFHJlEUgQcYykhmSpsKubMOfCAe,img=GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('thumbnail'),infoLabels=GIBzFHJlEUgQcYykhmSpsKubMOfCAD,isFolder=GIBzFHJlEUgQcYykhmSpsKubMOfCNj,params=GIBzFHJlEUgQcYykhmSpsKubMOfCoD)
  if GIBzFHJlEUgQcYykhmSpsKubMOfCAq==1:
   GIBzFHJlEUgQcYykhmSpsKubMOfCAD={'plot':'정렬순서를 변경합니다.'}
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD={}
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD['mode'] ='ORDER_BY' 
   if GIBzFHJlEUgQcYykhmSpsKubMOfCrx.get_winEpisodeOrderby()=='desc':
    GIBzFHJlEUgQcYykhmSpsKubMOfCot='정렬순서변경 : 최신화부터 -> 1회부터'
    GIBzFHJlEUgQcYykhmSpsKubMOfCoD['orderby']='asc'
   else:
    GIBzFHJlEUgQcYykhmSpsKubMOfCot='정렬순서변경 : 1회부터 -> 최신화부터'
    GIBzFHJlEUgQcYykhmSpsKubMOfCoD['orderby']='desc'
   GIBzFHJlEUgQcYykhmSpsKubMOfCoi=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.add_dir(GIBzFHJlEUgQcYykhmSpsKubMOfCot,sublabel='',img=GIBzFHJlEUgQcYykhmSpsKubMOfCoi,infoLabels=GIBzFHJlEUgQcYykhmSpsKubMOfCAD,isFolder=GIBzFHJlEUgQcYykhmSpsKubMOfCNj,params=GIBzFHJlEUgQcYykhmSpsKubMOfCoD,isLink=GIBzFHJlEUgQcYykhmSpsKubMOfCNW)
  if GIBzFHJlEUgQcYykhmSpsKubMOfCoT:
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD={}
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD['mode'] ='EPISODE_LIST' 
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD['videoid']=GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('programid')
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD['vidtype']='programid'
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD['page'] =GIBzFHJlEUgQcYykhmSpsKubMOfCxo(GIBzFHJlEUgQcYykhmSpsKubMOfCAq+1)
   GIBzFHJlEUgQcYykhmSpsKubMOfCot='[B]%s >>[/B]'%'다음 페이지'
   GIBzFHJlEUgQcYykhmSpsKubMOfCAe=GIBzFHJlEUgQcYykhmSpsKubMOfCxo(GIBzFHJlEUgQcYykhmSpsKubMOfCAq+1)
   GIBzFHJlEUgQcYykhmSpsKubMOfCoi=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.add_dir(GIBzFHJlEUgQcYykhmSpsKubMOfCot,sublabel=GIBzFHJlEUgQcYykhmSpsKubMOfCAe,img=GIBzFHJlEUgQcYykhmSpsKubMOfCoi,infoLabels=GIBzFHJlEUgQcYykhmSpsKubMOfCNR,isFolder=GIBzFHJlEUgQcYykhmSpsKubMOfCNW,params=GIBzFHJlEUgQcYykhmSpsKubMOfCoD)
  xbmcplugin.setContent(GIBzFHJlEUgQcYykhmSpsKubMOfCrx._addon_handle,'episodes')
  if GIBzFHJlEUgQcYykhmSpsKubMOfCNT(GIBzFHJlEUgQcYykhmSpsKubMOfCAn)>0:xbmcplugin.endOfDirectory(GIBzFHJlEUgQcYykhmSpsKubMOfCrx._addon_handle,cacheToDisc=GIBzFHJlEUgQcYykhmSpsKubMOfCNj)
 def dp_LiveChannel_List(GIBzFHJlEUgQcYykhmSpsKubMOfCrx,args):
  GIBzFHJlEUgQcYykhmSpsKubMOfCNX =args.get('genre')
  GIBzFHJlEUgQcYykhmSpsKubMOfCwv=args.get('baseapi')
  GIBzFHJlEUgQcYykhmSpsKubMOfCAn=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.WavveObj.Get_LiveChannel_List(GIBzFHJlEUgQcYykhmSpsKubMOfCNX,GIBzFHJlEUgQcYykhmSpsKubMOfCwv)
  for GIBzFHJlEUgQcYykhmSpsKubMOfCAP in GIBzFHJlEUgQcYykhmSpsKubMOfCAn:
   GIBzFHJlEUgQcYykhmSpsKubMOfCwP =GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('channelid')
   GIBzFHJlEUgQcYykhmSpsKubMOfCwR =GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('studio')
   GIBzFHJlEUgQcYykhmSpsKubMOfCwa=GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('tvshowtitle')
   GIBzFHJlEUgQcYykhmSpsKubMOfCAR =GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('thumbnail')
   GIBzFHJlEUgQcYykhmSpsKubMOfCAa =GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('age')
   GIBzFHJlEUgQcYykhmSpsKubMOfCNV =GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('epg')
   GIBzFHJlEUgQcYykhmSpsKubMOfCAD={'mediatype':'episode','mpaa':GIBzFHJlEUgQcYykhmSpsKubMOfCAa,'title':'%s < %s >'%(GIBzFHJlEUgQcYykhmSpsKubMOfCwR,GIBzFHJlEUgQcYykhmSpsKubMOfCwa),'tvshowtitle':GIBzFHJlEUgQcYykhmSpsKubMOfCwa,'studio':GIBzFHJlEUgQcYykhmSpsKubMOfCwR,'plot':'%s\n\n%s'%(GIBzFHJlEUgQcYykhmSpsKubMOfCwR,GIBzFHJlEUgQcYykhmSpsKubMOfCNV)}
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD={'mode':'LIVE','contentid':GIBzFHJlEUgQcYykhmSpsKubMOfCwP}
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.add_dir(GIBzFHJlEUgQcYykhmSpsKubMOfCwR,sublabel=GIBzFHJlEUgQcYykhmSpsKubMOfCwa,img=GIBzFHJlEUgQcYykhmSpsKubMOfCAR,infoLabels=GIBzFHJlEUgQcYykhmSpsKubMOfCAD,isFolder=GIBzFHJlEUgQcYykhmSpsKubMOfCNj,params=GIBzFHJlEUgQcYykhmSpsKubMOfCoD)
  if GIBzFHJlEUgQcYykhmSpsKubMOfCNT(GIBzFHJlEUgQcYykhmSpsKubMOfCAn)>0:xbmcplugin.endOfDirectory(GIBzFHJlEUgQcYykhmSpsKubMOfCrx._addon_handle,cacheToDisc=GIBzFHJlEUgQcYykhmSpsKubMOfCNj)
 def dp_Sports_GameList(GIBzFHJlEUgQcYykhmSpsKubMOfCrx,args):
  GIBzFHJlEUgQcYykhmSpsKubMOfCAn=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.WavveObj.Get_Sports_Gamelist()
  for GIBzFHJlEUgQcYykhmSpsKubMOfCAP in GIBzFHJlEUgQcYykhmSpsKubMOfCAn:
   GIBzFHJlEUgQcYykhmSpsKubMOfCNw =GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('game_date')
   GIBzFHJlEUgQcYykhmSpsKubMOfCNx =GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('game_time')
   GIBzFHJlEUgQcYykhmSpsKubMOfCNt =GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('svc_id')
   GIBzFHJlEUgQcYykhmSpsKubMOfCNv =GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('away_team')
   GIBzFHJlEUgQcYykhmSpsKubMOfCNL =GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('home_team')
   GIBzFHJlEUgQcYykhmSpsKubMOfCNi=GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('game_status')
   GIBzFHJlEUgQcYykhmSpsKubMOfCND =GIBzFHJlEUgQcYykhmSpsKubMOfCAP.get('game_place')
   GIBzFHJlEUgQcYykhmSpsKubMOfCNq ='%s vs %s (%s)'%(GIBzFHJlEUgQcYykhmSpsKubMOfCNv,GIBzFHJlEUgQcYykhmSpsKubMOfCNL,GIBzFHJlEUgQcYykhmSpsKubMOfCND)
   GIBzFHJlEUgQcYykhmSpsKubMOfCNn =GIBzFHJlEUgQcYykhmSpsKubMOfCNw+' '+GIBzFHJlEUgQcYykhmSpsKubMOfCNx
   if GIBzFHJlEUgQcYykhmSpsKubMOfCNi=='LIVE':
    GIBzFHJlEUgQcYykhmSpsKubMOfCNi='~경기중~'
   elif GIBzFHJlEUgQcYykhmSpsKubMOfCNi=='END':
    GIBzFHJlEUgQcYykhmSpsKubMOfCNi='경기종료'
   elif GIBzFHJlEUgQcYykhmSpsKubMOfCNi=='CANCEL':
    GIBzFHJlEUgQcYykhmSpsKubMOfCNi='취소'
   else:
    GIBzFHJlEUgQcYykhmSpsKubMOfCNi=''
   if GIBzFHJlEUgQcYykhmSpsKubMOfCNi=='':
    GIBzFHJlEUgQcYykhmSpsKubMOfCAe=GIBzFHJlEUgQcYykhmSpsKubMOfCNq
   else:
    GIBzFHJlEUgQcYykhmSpsKubMOfCAe=GIBzFHJlEUgQcYykhmSpsKubMOfCNq+'  '+GIBzFHJlEUgQcYykhmSpsKubMOfCNi
   GIBzFHJlEUgQcYykhmSpsKubMOfCAD={'mediatype':'episode','title':GIBzFHJlEUgQcYykhmSpsKubMOfCNq,'plot':'%s\n\n%s\n\n%s'%(GIBzFHJlEUgQcYykhmSpsKubMOfCNn,GIBzFHJlEUgQcYykhmSpsKubMOfCNq,GIBzFHJlEUgQcYykhmSpsKubMOfCNi)}
   GIBzFHJlEUgQcYykhmSpsKubMOfCoD={'mode':'SPORTS','contentid':GIBzFHJlEUgQcYykhmSpsKubMOfCNt}
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.add_dir(GIBzFHJlEUgQcYykhmSpsKubMOfCNn,sublabel=GIBzFHJlEUgQcYykhmSpsKubMOfCAe,img='',infoLabels=GIBzFHJlEUgQcYykhmSpsKubMOfCAD,isFolder=GIBzFHJlEUgQcYykhmSpsKubMOfCNj,params=GIBzFHJlEUgQcYykhmSpsKubMOfCoD)
  xbmcplugin.endOfDirectory(GIBzFHJlEUgQcYykhmSpsKubMOfCrx._addon_handle,cacheToDisc=GIBzFHJlEUgQcYykhmSpsKubMOfCNj)
 def wavve_main(GIBzFHJlEUgQcYykhmSpsKubMOfCrx):
  GIBzFHJlEUgQcYykhmSpsKubMOfCoj=GIBzFHJlEUgQcYykhmSpsKubMOfCrx.main_params.get('mode',GIBzFHJlEUgQcYykhmSpsKubMOfCNR)
  if GIBzFHJlEUgQcYykhmSpsKubMOfCoj=='LOGOUT':
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.logout()
   return
  GIBzFHJlEUgQcYykhmSpsKubMOfCrx.login_main()
  if GIBzFHJlEUgQcYykhmSpsKubMOfCoj is GIBzFHJlEUgQcYykhmSpsKubMOfCNR:
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.dp_Main_List()
  elif GIBzFHJlEUgQcYykhmSpsKubMOfCoj in['LIVE','VOD','MOVIE','SPORTS']:
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.play_VIDEO(GIBzFHJlEUgQcYykhmSpsKubMOfCrx.main_params)
  elif GIBzFHJlEUgQcYykhmSpsKubMOfCoj=='LIVE_CATAGORY':
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.dp_LiveCatagory_List(GIBzFHJlEUgQcYykhmSpsKubMOfCrx.main_params)
  elif GIBzFHJlEUgQcYykhmSpsKubMOfCoj=='MAIN_CATAGORY':
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.dp_MainCatagory_List(GIBzFHJlEUgQcYykhmSpsKubMOfCrx.main_params)
  elif GIBzFHJlEUgQcYykhmSpsKubMOfCoj=='SUPERSECTION_LIST':
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.dp_SuperSection_List(GIBzFHJlEUgQcYykhmSpsKubMOfCrx.main_params)
  elif GIBzFHJlEUgQcYykhmSpsKubMOfCoj=='BANDLIVESECTION_LIST':
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.dp_BandLiveSection_List(GIBzFHJlEUgQcYykhmSpsKubMOfCrx.main_params)
  elif GIBzFHJlEUgQcYykhmSpsKubMOfCoj=='BAND2SECTION_LIST':
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.dp_Band2Section_List(GIBzFHJlEUgQcYykhmSpsKubMOfCrx.main_params)
  elif GIBzFHJlEUgQcYykhmSpsKubMOfCoj=='PROGRAM_LIST':
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.dp_Program_List(GIBzFHJlEUgQcYykhmSpsKubMOfCrx.main_params)
  elif GIBzFHJlEUgQcYykhmSpsKubMOfCoj=='EPISODE_LIST':
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.dp_Episode_List(GIBzFHJlEUgQcYykhmSpsKubMOfCrx.main_params)
  elif GIBzFHJlEUgQcYykhmSpsKubMOfCoj=='MOVIE_LIST':
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.dp_Movie_List(GIBzFHJlEUgQcYykhmSpsKubMOfCrx.main_params)
  elif GIBzFHJlEUgQcYykhmSpsKubMOfCoj=='LIVE_LIST':
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.dp_LiveChannel_List(GIBzFHJlEUgQcYykhmSpsKubMOfCrx.main_params)
  elif GIBzFHJlEUgQcYykhmSpsKubMOfCoj=='ORDER_BY':
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.dp_setEpOrderby(GIBzFHJlEUgQcYykhmSpsKubMOfCrx.main_params)
  elif GIBzFHJlEUgQcYykhmSpsKubMOfCoj=='SEARCH_GROUP':
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.dp_Search_Group(GIBzFHJlEUgQcYykhmSpsKubMOfCrx.main_params)
  elif GIBzFHJlEUgQcYykhmSpsKubMOfCoj in['SEARCH_LIST','LOCAL_SEARCH']:
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.dp_Search_List(GIBzFHJlEUgQcYykhmSpsKubMOfCrx.main_params)
  elif GIBzFHJlEUgQcYykhmSpsKubMOfCoj=='WATCH_GROUP':
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.dp_Watch_Group(GIBzFHJlEUgQcYykhmSpsKubMOfCrx.main_params)
  elif GIBzFHJlEUgQcYykhmSpsKubMOfCoj=='WATCH_LIST':
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.dp_Watch_List(GIBzFHJlEUgQcYykhmSpsKubMOfCrx.main_params)
  elif GIBzFHJlEUgQcYykhmSpsKubMOfCoj=='SET_BOOKMARK':
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.dp_Set_Bookmark(GIBzFHJlEUgQcYykhmSpsKubMOfCrx.main_params)
  elif GIBzFHJlEUgQcYykhmSpsKubMOfCoj in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.dp_History_Remove(GIBzFHJlEUgQcYykhmSpsKubMOfCrx.main_params)
  elif GIBzFHJlEUgQcYykhmSpsKubMOfCoj in['TOTAL_SEARCH','TOTAL_HISTORY']:
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.dp_Global_Search(GIBzFHJlEUgQcYykhmSpsKubMOfCrx.main_params)
  elif GIBzFHJlEUgQcYykhmSpsKubMOfCoj=='SEARCH_HISTORY':
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.dp_Search_History(GIBzFHJlEUgQcYykhmSpsKubMOfCrx.main_params)
  elif GIBzFHJlEUgQcYykhmSpsKubMOfCoj=='MENU_BOOKMARK':
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.dp_Bookmark_Menu(GIBzFHJlEUgQcYykhmSpsKubMOfCrx.main_params)
  elif GIBzFHJlEUgQcYykhmSpsKubMOfCoj=='GAME_LIST':
   GIBzFHJlEUgQcYykhmSpsKubMOfCrx.dp_Sports_GameList(GIBzFHJlEUgQcYykhmSpsKubMOfCrx.main_params)
  else:
   GIBzFHJlEUgQcYykhmSpsKubMOfCNR
# Created by pyminifier (https://github.com/liftoff/pyminifier)
