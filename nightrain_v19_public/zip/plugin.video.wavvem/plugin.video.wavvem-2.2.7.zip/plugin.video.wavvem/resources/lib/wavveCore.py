__author__="NightRain"
JUOAvmDgKdSHTwrfeGREjyqhnNPFok=object
JUOAvmDgKdSHTwrfeGREjyqhnNPFob=None
JUOAvmDgKdSHTwrfeGREjyqhnNPFoL=False
JUOAvmDgKdSHTwrfeGREjyqhnNPFoV=open
JUOAvmDgKdSHTwrfeGREjyqhnNPFoY=True
JUOAvmDgKdSHTwrfeGREjyqhnNPFoW=range
JUOAvmDgKdSHTwrfeGREjyqhnNPFoi=str
JUOAvmDgKdSHTwrfeGREjyqhnNPFoI=Exception
JUOAvmDgKdSHTwrfeGREjyqhnNPFox=print
JUOAvmDgKdSHTwrfeGREjyqhnNPFoX=dict
JUOAvmDgKdSHTwrfeGREjyqhnNPFoa=int
JUOAvmDgKdSHTwrfeGREjyqhnNPFoQ=len
import urllib
import re
import json
import sys
import requests
import datetime
import base64
class JUOAvmDgKdSHTwrfeGREjyqhnNPFCk(JUOAvmDgKdSHTwrfeGREjyqhnNPFok):
 def __init__(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb):
  JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.API_DOMAIN='https://apis.wavve.com'
  JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.WV ={}
  JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.Init_WV_Total()
  JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.DEVICE ='pc'
  JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.DRM ='wm'
  JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.PARTNER ='pooq'
  JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.POOQZONE ='none'
  JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.REGION ='kor'
  JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.TARGETAGE ='all'
  JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.HTTPTAG ='https://'
  JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.LIST_LIMIT=30 
  JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.EP_LIMIT =30 
  JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.MV_LIMIT =24 
  JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.SEARCH_LIMIT=20 
  JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36'
  JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.DEFAULT_HEADER={'user-agent':JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.USER_AGENT}
 def Init_WV_Total(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb):
  JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.WV={'account':{},'cookies':{},}
 def callRequestCookies(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb,jobtype,JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,payload=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,params=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,headers=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,cookies=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,redirects=JUOAvmDgKdSHTwrfeGREjyqhnNPFoL):
  JUOAvmDgKdSHTwrfeGREjyqhnNPFCL=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.DEFAULT_HEADER
  if headers:JUOAvmDgKdSHTwrfeGREjyqhnNPFCL.update(headers)
  if jobtype=='Get':
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCV=requests.get(JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,params=params,headers=JUOAvmDgKdSHTwrfeGREjyqhnNPFCL,cookies=cookies,allow_redirects=redirects)
  else:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCV=requests.post(JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,data=payload,params=params,headers=JUOAvmDgKdSHTwrfeGREjyqhnNPFCL,cookies=cookies,allow_redirects=redirects)
  return JUOAvmDgKdSHTwrfeGREjyqhnNPFCV
 def JsonFile_Save(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb,filename,JUOAvmDgKdSHTwrfeGREjyqhnNPFCo):
  if filename=='':return JUOAvmDgKdSHTwrfeGREjyqhnNPFoL
  try:
   fp=JUOAvmDgKdSHTwrfeGREjyqhnNPFoV(filename,'w',-1,'utf-8')
   json.dump(JUOAvmDgKdSHTwrfeGREjyqhnNPFCo,fp,indent=4,ensure_ascii=JUOAvmDgKdSHTwrfeGREjyqhnNPFoL)
   fp.close()
  except:
   return JUOAvmDgKdSHTwrfeGREjyqhnNPFoL
  return JUOAvmDgKdSHTwrfeGREjyqhnNPFoY
 def JsonFile_Load(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb,filename):
  if filename=='':return{}
  try:
   fp=JUOAvmDgKdSHTwrfeGREjyqhnNPFoV(filename,'r',-1,'utf-8')
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCW=json.load(fp)
   fp.close()
  except:
   return{}
  return JUOAvmDgKdSHTwrfeGREjyqhnNPFCW
 def Save_session_acount(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb,JUOAvmDgKdSHTwrfeGREjyqhnNPFCi,JUOAvmDgKdSHTwrfeGREjyqhnNPFCI,JUOAvmDgKdSHTwrfeGREjyqhnNPFCx):
  JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.WV['account']['wvid']=base64.standard_b64encode(JUOAvmDgKdSHTwrfeGREjyqhnNPFCi.encode()).decode('utf-8')
  JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.WV['account']['wvpw']=base64.standard_b64encode(JUOAvmDgKdSHTwrfeGREjyqhnNPFCI.encode()).decode('utf-8')
  JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.WV['account']['wvpf']=JUOAvmDgKdSHTwrfeGREjyqhnNPFCx 
 def Load_session_acount(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb):
  try:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCi=base64.standard_b64decode(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.WV['account']['wvid']).decode('utf-8')
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCI=base64.standard_b64decode(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.WV['account']['wvpw']).decode('utf-8')
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCx=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.WV['account']['wvpf']
  except:
   return '','',0
  return JUOAvmDgKdSHTwrfeGREjyqhnNPFCi,JUOAvmDgKdSHTwrfeGREjyqhnNPFCI,JUOAvmDgKdSHTwrfeGREjyqhnNPFCx
 def GetDefaultParams(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb,login=JUOAvmDgKdSHTwrfeGREjyqhnNPFoY):
  JUOAvmDgKdSHTwrfeGREjyqhnNPFCX={'apikey':JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.APIKEY,'credential':JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.WV['cookies']['credential']if login else 'none','device':JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.DEVICE,'drm':JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.DRM,'partner':JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.PARTNER,'pooqzone':JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.POOQZONE,'region':JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.REGION,'targetage':JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.TARGETAGE}
  return JUOAvmDgKdSHTwrfeGREjyqhnNPFCX
 def GetGUID(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCa=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCQ=GenerateRandomString(5)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCp=JUOAvmDgKdSHTwrfeGREjyqhnNPFCQ+media+JUOAvmDgKdSHTwrfeGREjyqhnNPFCa
   return JUOAvmDgKdSHTwrfeGREjyqhnNPFCp
  def GenerateRandomString(num):
   from random import randint
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCM=""
   for i in JUOAvmDgKdSHTwrfeGREjyqhnNPFoW(0,num):
    s=JUOAvmDgKdSHTwrfeGREjyqhnNPFoi(randint(1,5))
    JUOAvmDgKdSHTwrfeGREjyqhnNPFCM+=s
   return JUOAvmDgKdSHTwrfeGREjyqhnNPFCM
  JUOAvmDgKdSHTwrfeGREjyqhnNPFCp=GenerateID(guid_str)
  JUOAvmDgKdSHTwrfeGREjyqhnNPFCu=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.GetHash(JUOAvmDgKdSHTwrfeGREjyqhnNPFCp)
  if guidType==2:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCu='%s-%s-%s-%s-%s'%(JUOAvmDgKdSHTwrfeGREjyqhnNPFCu[:8],JUOAvmDgKdSHTwrfeGREjyqhnNPFCu[8:12],JUOAvmDgKdSHTwrfeGREjyqhnNPFCu[12:16],JUOAvmDgKdSHTwrfeGREjyqhnNPFCu[16:20],JUOAvmDgKdSHTwrfeGREjyqhnNPFCu[20:])
  return JUOAvmDgKdSHTwrfeGREjyqhnNPFCu
 def GetHash(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return JUOAvmDgKdSHTwrfeGREjyqhnNPFoi(m.hexdigest())
 def CheckQuality(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb,sel_qt,qt_list):
  JUOAvmDgKdSHTwrfeGREjyqhnNPFCB=0
  for JUOAvmDgKdSHTwrfeGREjyqhnNPFCs in qt_list:
   if sel_qt>=JUOAvmDgKdSHTwrfeGREjyqhnNPFCs:return JUOAvmDgKdSHTwrfeGREjyqhnNPFCs
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCB=JUOAvmDgKdSHTwrfeGREjyqhnNPFCs
  return JUOAvmDgKdSHTwrfeGREjyqhnNPFCB
 def Get_Now_Datetime(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb,in_text):
  JUOAvmDgKdSHTwrfeGREjyqhnNPFCz=in_text.replace('&lt;','<').replace('&gt;','>')
  JUOAvmDgKdSHTwrfeGREjyqhnNPFCz=JUOAvmDgKdSHTwrfeGREjyqhnNPFCz.replace('$O$','')
  JUOAvmDgKdSHTwrfeGREjyqhnNPFCz=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',JUOAvmDgKdSHTwrfeGREjyqhnNPFCz)
  JUOAvmDgKdSHTwrfeGREjyqhnNPFCz=JUOAvmDgKdSHTwrfeGREjyqhnNPFCz.lstrip('#')
  return JUOAvmDgKdSHTwrfeGREjyqhnNPFCz
 def GetCredential(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb,user_id,user_pw,user_pf):
  JUOAvmDgKdSHTwrfeGREjyqhnNPFCl=JUOAvmDgKdSHTwrfeGREjyqhnNPFoL
  try:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCc=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.API_DOMAIN+ '/login'
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.GetDefaultParams(login=JUOAvmDgKdSHTwrfeGREjyqhnNPFoL)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkC={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkb=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.callRequestCookies('Post',JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,payload=JUOAvmDgKdSHTwrfeGREjyqhnNPFkC,params=JUOAvmDgKdSHTwrfeGREjyqhnNPFCX,headers=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,cookies=JUOAvmDgKdSHTwrfeGREjyqhnNPFob)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkL=json.loads(JUOAvmDgKdSHTwrfeGREjyqhnNPFkb.text)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.WV['cookies']['credential']=JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['credential']
   if user_pf!=0:
    JUOAvmDgKdSHTwrfeGREjyqhnNPFkC={'id':JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.WV['cookies']['credential'],'password':'','profile':JUOAvmDgKdSHTwrfeGREjyqhnNPFoi(user_pf),'pushid':'','type':'credential'}
    JUOAvmDgKdSHTwrfeGREjyqhnNPFCX =JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.GetDefaultParams(login=JUOAvmDgKdSHTwrfeGREjyqhnNPFoY) 
    JUOAvmDgKdSHTwrfeGREjyqhnNPFkb=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.callRequestCookies('Post',JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,payload=JUOAvmDgKdSHTwrfeGREjyqhnNPFkC,params=JUOAvmDgKdSHTwrfeGREjyqhnNPFCX,headers=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,cookies=JUOAvmDgKdSHTwrfeGREjyqhnNPFob)
    JUOAvmDgKdSHTwrfeGREjyqhnNPFkL=json.loads(JUOAvmDgKdSHTwrfeGREjyqhnNPFkb.text)
    JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.WV['cookies']['credential']=JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['credential']
    JUOAvmDgKdSHTwrfeGREjyqhnNPFCl=JUOAvmDgKdSHTwrfeGREjyqhnNPFoY
  except JUOAvmDgKdSHTwrfeGREjyqhnNPFoI as exception:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFox(exception)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.Init_WV_Total()
  return JUOAvmDgKdSHTwrfeGREjyqhnNPFCl
 def GetIssue(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb):
  JUOAvmDgKdSHTwrfeGREjyqhnNPFkV=JUOAvmDgKdSHTwrfeGREjyqhnNPFoL
  try:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCc=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.API_DOMAIN+'/guid/issue'
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.GetDefaultParams()
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkb=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.callRequestCookies('Get',JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,payload=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,params=JUOAvmDgKdSHTwrfeGREjyqhnNPFCX,headers=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,cookies=JUOAvmDgKdSHTwrfeGREjyqhnNPFob)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkL=json.loads(JUOAvmDgKdSHTwrfeGREjyqhnNPFkb.text)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFko=JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['guid']
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkY=JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['guidtimestamp']
   if JUOAvmDgKdSHTwrfeGREjyqhnNPFko:JUOAvmDgKdSHTwrfeGREjyqhnNPFkV=JUOAvmDgKdSHTwrfeGREjyqhnNPFoY
  except JUOAvmDgKdSHTwrfeGREjyqhnNPFoI as exception:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFox(exception)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFko='none'
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkY='none' 
  JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.guid=JUOAvmDgKdSHTwrfeGREjyqhnNPFko
  JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.guidtimestamp=JUOAvmDgKdSHTwrfeGREjyqhnNPFkY
  return JUOAvmDgKdSHTwrfeGREjyqhnNPFkV
 def Baseapi_Parse(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb,JUOAvmDgKdSHTwrfeGREjyqhnNPFkx):
  try:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkW =urllib.parse.urlsplit(JUOAvmDgKdSHTwrfeGREjyqhnNPFkx)
   if JUOAvmDgKdSHTwrfeGREjyqhnNPFkW.netloc=='':
    JUOAvmDgKdSHTwrfeGREjyqhnNPFCc=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.HTTPTAG+JUOAvmDgKdSHTwrfeGREjyqhnNPFkW.netloc+JUOAvmDgKdSHTwrfeGREjyqhnNPFkW.path
   else:
    JUOAvmDgKdSHTwrfeGREjyqhnNPFCc=JUOAvmDgKdSHTwrfeGREjyqhnNPFkW.scheme+'://'+JUOAvmDgKdSHTwrfeGREjyqhnNPFkW.netloc+JUOAvmDgKdSHTwrfeGREjyqhnNPFkW.path
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX=JUOAvmDgKdSHTwrfeGREjyqhnNPFoX(urllib.parse.parse_qsl(JUOAvmDgKdSHTwrfeGREjyqhnNPFkW.query))
  except JUOAvmDgKdSHTwrfeGREjyqhnNPFoI as exception:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFox(exception)
   return '',{}
  return JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,JUOAvmDgKdSHTwrfeGREjyqhnNPFCX
 def GetSupermultiUrl(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb,sCode,sIndex='0'):
  try:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCc=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.API_DOMAIN+'/cf/supermultisections/'+sCode
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.GetDefaultParams(login=JUOAvmDgKdSHTwrfeGREjyqhnNPFoL)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkb=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.callRequestCookies('Get',JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,payload=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,params=JUOAvmDgKdSHTwrfeGREjyqhnNPFCX,headers=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,cookies=JUOAvmDgKdSHTwrfeGREjyqhnNPFob)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkL=json.loads(JUOAvmDgKdSHTwrfeGREjyqhnNPFkb.text)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFki=JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['multisectionlist'][JUOAvmDgKdSHTwrfeGREjyqhnNPFoa(sIndex)]['eventlist'][1]['url']
  except JUOAvmDgKdSHTwrfeGREjyqhnNPFoI as exception:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFox(exception)
   return ''
  return JUOAvmDgKdSHTwrfeGREjyqhnNPFki
 def Get_LiveCatagory_List(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb,sCode,sIndex='0'):
  JUOAvmDgKdSHTwrfeGREjyqhnNPFkI=[]
  JUOAvmDgKdSHTwrfeGREjyqhnNPFkx =JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.GetSupermultiUrl(sCode,sIndex)
  (JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,JUOAvmDgKdSHTwrfeGREjyqhnNPFCX)=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.Baseapi_Parse(JUOAvmDgKdSHTwrfeGREjyqhnNPFkx)
  if JUOAvmDgKdSHTwrfeGREjyqhnNPFCc=='':return JUOAvmDgKdSHTwrfeGREjyqhnNPFkI,''
  try:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX.update(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.GetDefaultParams(login=JUOAvmDgKdSHTwrfeGREjyqhnNPFoL))
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkb=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.callRequestCookies('Get',JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,payload=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,params=JUOAvmDgKdSHTwrfeGREjyqhnNPFCX,headers=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,cookies=JUOAvmDgKdSHTwrfeGREjyqhnNPFob)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkL=json.loads(JUOAvmDgKdSHTwrfeGREjyqhnNPFkb.text)
   if not('filter_item_list' in JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['filter']['filterlist'][0]):return[],''
   JUOAvmDgKdSHTwrfeGREjyqhnNPFka=JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['filter']['filterlist'][0]['filter_item_list']
   for JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ in JUOAvmDgKdSHTwrfeGREjyqhnNPFka:
    JUOAvmDgKdSHTwrfeGREjyqhnNPFkp={'title':JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ['title'],'genre':JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ['api_parameters'][JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ['api_parameters'].index('=')+1:]}
    JUOAvmDgKdSHTwrfeGREjyqhnNPFkI.append(JUOAvmDgKdSHTwrfeGREjyqhnNPFkp)
  except JUOAvmDgKdSHTwrfeGREjyqhnNPFoI as exception:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFox(exception)
   return[],''
  return JUOAvmDgKdSHTwrfeGREjyqhnNPFkI,JUOAvmDgKdSHTwrfeGREjyqhnNPFkx
 def Get_MainCatagory_List(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb,sCode,sIndex='0'):
  JUOAvmDgKdSHTwrfeGREjyqhnNPFkI=[]
  JUOAvmDgKdSHTwrfeGREjyqhnNPFkx =JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.GetSupermultiUrl(sCode,sIndex)
  (JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,JUOAvmDgKdSHTwrfeGREjyqhnNPFCX)=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.Baseapi_Parse(JUOAvmDgKdSHTwrfeGREjyqhnNPFkx)
  if JUOAvmDgKdSHTwrfeGREjyqhnNPFCc=='':return JUOAvmDgKdSHTwrfeGREjyqhnNPFkI
  try:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX.update(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.GetDefaultParams(login=JUOAvmDgKdSHTwrfeGREjyqhnNPFoL))
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkb=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.callRequestCookies('Get',JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,payload=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,params=JUOAvmDgKdSHTwrfeGREjyqhnNPFCX,headers=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,cookies=JUOAvmDgKdSHTwrfeGREjyqhnNPFob)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkL=json.loads(JUOAvmDgKdSHTwrfeGREjyqhnNPFkb.text)
   if not('celllist' in JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['band']):return[]
   JUOAvmDgKdSHTwrfeGREjyqhnNPFka=JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['band']['celllist']
   for JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ in JUOAvmDgKdSHTwrfeGREjyqhnNPFka:
    JUOAvmDgKdSHTwrfeGREjyqhnNPFkM =JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ['event_list'][1]['url']
    (JUOAvmDgKdSHTwrfeGREjyqhnNPFku,JUOAvmDgKdSHTwrfeGREjyqhnNPFkB)=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.Baseapi_Parse(JUOAvmDgKdSHTwrfeGREjyqhnNPFkM)
    JUOAvmDgKdSHTwrfeGREjyqhnNPFkp={'title':JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ['title_list'][0]['text'],'suburl':JUOAvmDgKdSHTwrfeGREjyqhnNPFku,'subapi':JUOAvmDgKdSHTwrfeGREjyqhnNPFkB.get('api'),'subtype':'catagory' if JUOAvmDgKdSHTwrfeGREjyqhnNPFkB else 'supersection'}
    JUOAvmDgKdSHTwrfeGREjyqhnNPFkI.append(JUOAvmDgKdSHTwrfeGREjyqhnNPFkp)
  except JUOAvmDgKdSHTwrfeGREjyqhnNPFoI as exception:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFox(exception)
   return[]
  return JUOAvmDgKdSHTwrfeGREjyqhnNPFkI
 def Get_SuperMultiSection_List(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb,subapi_text):
  JUOAvmDgKdSHTwrfeGREjyqhnNPFkI=[]
  JUOAvmDgKdSHTwrfeGREjyqhnNPFCX={}
  try:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkW =urllib.parse.urlsplit(subapi_text)
   if JUOAvmDgKdSHTwrfeGREjyqhnNPFkW.path.find('apis.wavve.com')>=0: 
    JUOAvmDgKdSHTwrfeGREjyqhnNPFCc=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.HTTPTAG+JUOAvmDgKdSHTwrfeGREjyqhnNPFkW.path 
    JUOAvmDgKdSHTwrfeGREjyqhnNPFCX=JUOAvmDgKdSHTwrfeGREjyqhnNPFoX(urllib.parse.parse_qsl(JUOAvmDgKdSHTwrfeGREjyqhnNPFkW.query))
   else:
    JUOAvmDgKdSHTwrfeGREjyqhnNPFCc=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.API_DOMAIN+'/cf'+JUOAvmDgKdSHTwrfeGREjyqhnNPFkW.path 
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCc=JUOAvmDgKdSHTwrfeGREjyqhnNPFCc.replace('supermultisection/','supermultisections/')
  except JUOAvmDgKdSHTwrfeGREjyqhnNPFoI as exception:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFox(exception)
   return[]
  try:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX.update(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.GetDefaultParams(login=JUOAvmDgKdSHTwrfeGREjyqhnNPFoL))
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkb=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.callRequestCookies('Get',JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,payload=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,params=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,headers=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,cookies=JUOAvmDgKdSHTwrfeGREjyqhnNPFob)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkL=json.loads(JUOAvmDgKdSHTwrfeGREjyqhnNPFkb.text)
   if not('multisectionlist' in JUOAvmDgKdSHTwrfeGREjyqhnNPFkL):return[]
   JUOAvmDgKdSHTwrfeGREjyqhnNPFka=JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['multisectionlist']
   for JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ in JUOAvmDgKdSHTwrfeGREjyqhnNPFka:
    JUOAvmDgKdSHTwrfeGREjyqhnNPFks=JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ['title']
    if JUOAvmDgKdSHTwrfeGREjyqhnNPFoQ(JUOAvmDgKdSHTwrfeGREjyqhnNPFks)==0:continue
    if JUOAvmDgKdSHTwrfeGREjyqhnNPFks=='minor':continue
    if re.search(u'베너',JUOAvmDgKdSHTwrfeGREjyqhnNPFks):continue
    if re.search(u'배너',JUOAvmDgKdSHTwrfeGREjyqhnNPFks):continue 
    if JUOAvmDgKdSHTwrfeGREjyqhnNPFoQ(JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ['eventlist'])>=3:
     JUOAvmDgKdSHTwrfeGREjyqhnNPFkB =JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ['eventlist'][2]['url']
    else:
     JUOAvmDgKdSHTwrfeGREjyqhnNPFkB =JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ['eventlist'][1]['url']
    JUOAvmDgKdSHTwrfeGREjyqhnNPFkt=JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ['cell_type']
    if JUOAvmDgKdSHTwrfeGREjyqhnNPFkt=='band_2':
     if JUOAvmDgKdSHTwrfeGREjyqhnNPFkB.find('channellist=')>=0:
      JUOAvmDgKdSHTwrfeGREjyqhnNPFkt='band_live'
    JUOAvmDgKdSHTwrfeGREjyqhnNPFkp={'title':JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.Get_ChangeText(JUOAvmDgKdSHTwrfeGREjyqhnNPFks),'subapi':JUOAvmDgKdSHTwrfeGREjyqhnNPFkB,'cell_type':JUOAvmDgKdSHTwrfeGREjyqhnNPFkt}
    JUOAvmDgKdSHTwrfeGREjyqhnNPFkI.append(JUOAvmDgKdSHTwrfeGREjyqhnNPFkp)
  except JUOAvmDgKdSHTwrfeGREjyqhnNPFoI as exception:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFox(exception)
   return[]
  return JUOAvmDgKdSHTwrfeGREjyqhnNPFkI
 def Get_BandLiveSection_List(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb,JUOAvmDgKdSHTwrfeGREjyqhnNPFkx,page_int=1):
  JUOAvmDgKdSHTwrfeGREjyqhnNPFkz=[]
  JUOAvmDgKdSHTwrfeGREjyqhnNPFkl=JUOAvmDgKdSHTwrfeGREjyqhnNPFbo=1
  JUOAvmDgKdSHTwrfeGREjyqhnNPFkc=JUOAvmDgKdSHTwrfeGREjyqhnNPFoL
  try:
   (JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,JUOAvmDgKdSHTwrfeGREjyqhnNPFCX)=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.Baseapi_Parse(JUOAvmDgKdSHTwrfeGREjyqhnNPFkx)
  except JUOAvmDgKdSHTwrfeGREjyqhnNPFoI as exception:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFox(exception)
   return[],JUOAvmDgKdSHTwrfeGREjyqhnNPFoL
  try:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX['limit']=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.LIST_LIMIT
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX['offset']=JUOAvmDgKdSHTwrfeGREjyqhnNPFoi((page_int-1)*JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.LIST_LIMIT)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX.update(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.GetDefaultParams(login=JUOAvmDgKdSHTwrfeGREjyqhnNPFoL))
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkb=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.callRequestCookies('Get',JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,payload=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,params=JUOAvmDgKdSHTwrfeGREjyqhnNPFCX,headers=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,cookies=JUOAvmDgKdSHTwrfeGREjyqhnNPFob)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkL=json.loads(JUOAvmDgKdSHTwrfeGREjyqhnNPFkb.text)
   if not('celllist' in JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['cell_toplist']):return[],JUOAvmDgKdSHTwrfeGREjyqhnNPFoL
   JUOAvmDgKdSHTwrfeGREjyqhnNPFka=JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['cell_toplist']['celllist']
   for JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ in JUOAvmDgKdSHTwrfeGREjyqhnNPFka:
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbC =JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ['event_list'][1]['url']
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbk=urllib.parse.urlsplit(JUOAvmDgKdSHTwrfeGREjyqhnNPFbC).query
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbk=JUOAvmDgKdSHTwrfeGREjyqhnNPFoX(urllib.parse.parse_qsl(JUOAvmDgKdSHTwrfeGREjyqhnNPFbk))
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbL='channelid'
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbV=JUOAvmDgKdSHTwrfeGREjyqhnNPFbk[JUOAvmDgKdSHTwrfeGREjyqhnNPFbL]
    JUOAvmDgKdSHTwrfeGREjyqhnNPFkp={'studio':JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ['title_list'][0]['text'],'tvshowtitle':JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.Get_ChangeText(JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ['title_list'][1]['text']),'channelid':JUOAvmDgKdSHTwrfeGREjyqhnNPFbV,'age':JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ.get('age'),'thumbnail':'https://%s'%JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ.get('thumbnail')}
    JUOAvmDgKdSHTwrfeGREjyqhnNPFkz.append(JUOAvmDgKdSHTwrfeGREjyqhnNPFkp)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkl=JUOAvmDgKdSHTwrfeGREjyqhnNPFoa(JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['cell_toplist']['pagecount'])
   if JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['cell_toplist']['count']:JUOAvmDgKdSHTwrfeGREjyqhnNPFbo =JUOAvmDgKdSHTwrfeGREjyqhnNPFoa(JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['cell_toplist']['count'])
   else:JUOAvmDgKdSHTwrfeGREjyqhnNPFbo=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.LIST_LIMIT*page_int
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkc=JUOAvmDgKdSHTwrfeGREjyqhnNPFkl>JUOAvmDgKdSHTwrfeGREjyqhnNPFbo
  except JUOAvmDgKdSHTwrfeGREjyqhnNPFoI as exception:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFox(exception)
   return[],JUOAvmDgKdSHTwrfeGREjyqhnNPFoL
  return JUOAvmDgKdSHTwrfeGREjyqhnNPFkz,JUOAvmDgKdSHTwrfeGREjyqhnNPFkc
 def Get_Band2Section_List(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb,JUOAvmDgKdSHTwrfeGREjyqhnNPFkx,page_int=1):
  JUOAvmDgKdSHTwrfeGREjyqhnNPFbY=[]
  JUOAvmDgKdSHTwrfeGREjyqhnNPFkl=JUOAvmDgKdSHTwrfeGREjyqhnNPFbo=1
  JUOAvmDgKdSHTwrfeGREjyqhnNPFkc=JUOAvmDgKdSHTwrfeGREjyqhnNPFoL
  try:
   (JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,JUOAvmDgKdSHTwrfeGREjyqhnNPFCX)=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.Baseapi_Parse(JUOAvmDgKdSHTwrfeGREjyqhnNPFkx)
  except JUOAvmDgKdSHTwrfeGREjyqhnNPFoI as exception:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFox(exception)
   return[],JUOAvmDgKdSHTwrfeGREjyqhnNPFoL
  try:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX['came'] ='BandView'
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX['limit']=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.LIST_LIMIT
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX['offset']=JUOAvmDgKdSHTwrfeGREjyqhnNPFoi((page_int-1)*JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.LIST_LIMIT)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX.update(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.GetDefaultParams(login=JUOAvmDgKdSHTwrfeGREjyqhnNPFoL))
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkb=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.callRequestCookies('Get',JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,payload=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,params=JUOAvmDgKdSHTwrfeGREjyqhnNPFCX,headers=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,cookies=JUOAvmDgKdSHTwrfeGREjyqhnNPFob)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkL=json.loads(JUOAvmDgKdSHTwrfeGREjyqhnNPFkb.text)
   if not('celllist' in JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['cell_toplist']):return[],JUOAvmDgKdSHTwrfeGREjyqhnNPFoL
   JUOAvmDgKdSHTwrfeGREjyqhnNPFka=JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['cell_toplist']['celllist']
   for JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ in JUOAvmDgKdSHTwrfeGREjyqhnNPFka:
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbC =JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ['event_list'][1]['url']
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbk=urllib.parse.urlsplit(JUOAvmDgKdSHTwrfeGREjyqhnNPFbC).query
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbk=JUOAvmDgKdSHTwrfeGREjyqhnNPFoX(urllib.parse.parse_qsl(JUOAvmDgKdSHTwrfeGREjyqhnNPFbk))
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbL='contentid'
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbV=JUOAvmDgKdSHTwrfeGREjyqhnNPFbk[JUOAvmDgKdSHTwrfeGREjyqhnNPFbL]
    JUOAvmDgKdSHTwrfeGREjyqhnNPFkp={'programtitle':JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ['title_list'][0]['text'],'episodetitle':JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.Get_ChangeText(JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ['title_list'][1]['text']),'age':JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ.get('age'),'thumbnail':JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.HTTPTAG+JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ.get('thumbnail'),'vidtype':JUOAvmDgKdSHTwrfeGREjyqhnNPFbL,'videoid':JUOAvmDgKdSHTwrfeGREjyqhnNPFbV}
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbY.append(JUOAvmDgKdSHTwrfeGREjyqhnNPFkp)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkl=JUOAvmDgKdSHTwrfeGREjyqhnNPFoa(JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['cell_toplist']['pagecount'])
   if JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['cell_toplist']['count']:JUOAvmDgKdSHTwrfeGREjyqhnNPFbo =JUOAvmDgKdSHTwrfeGREjyqhnNPFoa(JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['cell_toplist']['count'])
   else:JUOAvmDgKdSHTwrfeGREjyqhnNPFbo=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.LIST_LIMIT*page_int
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkc=JUOAvmDgKdSHTwrfeGREjyqhnNPFkl>JUOAvmDgKdSHTwrfeGREjyqhnNPFbo
  except JUOAvmDgKdSHTwrfeGREjyqhnNPFoI as exception:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFox(exception)
   return[],JUOAvmDgKdSHTwrfeGREjyqhnNPFoL
  return JUOAvmDgKdSHTwrfeGREjyqhnNPFbY,JUOAvmDgKdSHTwrfeGREjyqhnNPFkc
 def Get_Program_List(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb,JUOAvmDgKdSHTwrfeGREjyqhnNPFkx,page_int=1,orderby='-'):
  JUOAvmDgKdSHTwrfeGREjyqhnNPFbW=[]
  JUOAvmDgKdSHTwrfeGREjyqhnNPFkl=JUOAvmDgKdSHTwrfeGREjyqhnNPFbo=1
  JUOAvmDgKdSHTwrfeGREjyqhnNPFkc=JUOAvmDgKdSHTwrfeGREjyqhnNPFoL
  (JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,JUOAvmDgKdSHTwrfeGREjyqhnNPFCX)=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.Baseapi_Parse(JUOAvmDgKdSHTwrfeGREjyqhnNPFkx)
  if JUOAvmDgKdSHTwrfeGREjyqhnNPFCc=='':return JUOAvmDgKdSHTwrfeGREjyqhnNPFbW,JUOAvmDgKdSHTwrfeGREjyqhnNPFkc
  try:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX['limit'] =JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.LIST_LIMIT
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX['offset']=JUOAvmDgKdSHTwrfeGREjyqhnNPFoi((page_int-1)*JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.LIST_LIMIT)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX['page'] =JUOAvmDgKdSHTwrfeGREjyqhnNPFoi(page_int)
   if JUOAvmDgKdSHTwrfeGREjyqhnNPFCX.get('orderby')!='' and JUOAvmDgKdSHTwrfeGREjyqhnNPFCX.get('orderby')!='regdatefirst' and orderby!='-':
    JUOAvmDgKdSHTwrfeGREjyqhnNPFCX['orderby']=orderby 
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX.update(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.GetDefaultParams(login=JUOAvmDgKdSHTwrfeGREjyqhnNPFoL))
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkb=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.callRequestCookies('Get',JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,payload=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,params=JUOAvmDgKdSHTwrfeGREjyqhnNPFCX,headers=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,cookies=JUOAvmDgKdSHTwrfeGREjyqhnNPFob)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkL=json.loads(JUOAvmDgKdSHTwrfeGREjyqhnNPFkb.text)
   if JUOAvmDgKdSHTwrfeGREjyqhnNPFkx.find('instantplay')>=0:
    if not('celllist' in JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['band']):return JUOAvmDgKdSHTwrfeGREjyqhnNPFbW,JUOAvmDgKdSHTwrfeGREjyqhnNPFkc
    JUOAvmDgKdSHTwrfeGREjyqhnNPFka=JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['band']['celllist']
   else:
    if not('celllist' in JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['cell_toplist']):return JUOAvmDgKdSHTwrfeGREjyqhnNPFbW,JUOAvmDgKdSHTwrfeGREjyqhnNPFkc
    JUOAvmDgKdSHTwrfeGREjyqhnNPFka=JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['cell_toplist']['celllist']
   for JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ in JUOAvmDgKdSHTwrfeGREjyqhnNPFka:
    for JUOAvmDgKdSHTwrfeGREjyqhnNPFbi in JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ['event_list']:
     if JUOAvmDgKdSHTwrfeGREjyqhnNPFbi.get('type')=='on-navigation':
      JUOAvmDgKdSHTwrfeGREjyqhnNPFbC =JUOAvmDgKdSHTwrfeGREjyqhnNPFbi['url']
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbk=urllib.parse.urlsplit(JUOAvmDgKdSHTwrfeGREjyqhnNPFbC).query
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbL=JUOAvmDgKdSHTwrfeGREjyqhnNPFbk[0:JUOAvmDgKdSHTwrfeGREjyqhnNPFbk.find('=')]
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbV=JUOAvmDgKdSHTwrfeGREjyqhnNPFbk[JUOAvmDgKdSHTwrfeGREjyqhnNPFbk.find('=')+1:]
    JUOAvmDgKdSHTwrfeGREjyqhnNPFkp={'title':JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ['title_list'][0]['text'],'age':JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ['age'],'thumbnail':'https://%s'%JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ.get('thumbnail'),'videoid':JUOAvmDgKdSHTwrfeGREjyqhnNPFbV,'vidtype':JUOAvmDgKdSHTwrfeGREjyqhnNPFbL}
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbW.append(JUOAvmDgKdSHTwrfeGREjyqhnNPFkp)
   if JUOAvmDgKdSHTwrfeGREjyqhnNPFkx.find('instantplay')<0:
    JUOAvmDgKdSHTwrfeGREjyqhnNPFkl=JUOAvmDgKdSHTwrfeGREjyqhnNPFoa(JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['cell_toplist']['pagecount'])
    if JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['cell_toplist']['count']:JUOAvmDgKdSHTwrfeGREjyqhnNPFbo =JUOAvmDgKdSHTwrfeGREjyqhnNPFoa(JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['cell_toplist']['count'])
    else:JUOAvmDgKdSHTwrfeGREjyqhnNPFbo=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.LIST_LIMIT*page_int
    JUOAvmDgKdSHTwrfeGREjyqhnNPFkc=JUOAvmDgKdSHTwrfeGREjyqhnNPFkl>JUOAvmDgKdSHTwrfeGREjyqhnNPFbo
  except JUOAvmDgKdSHTwrfeGREjyqhnNPFoI as exception:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFox(exception)
   return[],JUOAvmDgKdSHTwrfeGREjyqhnNPFoL
  return JUOAvmDgKdSHTwrfeGREjyqhnNPFbW,JUOAvmDgKdSHTwrfeGREjyqhnNPFkc
 def Get_Movie_List(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb,JUOAvmDgKdSHTwrfeGREjyqhnNPFkx,page_int=1):
  JUOAvmDgKdSHTwrfeGREjyqhnNPFbI=[]
  JUOAvmDgKdSHTwrfeGREjyqhnNPFkl=JUOAvmDgKdSHTwrfeGREjyqhnNPFbo=1
  JUOAvmDgKdSHTwrfeGREjyqhnNPFkc=JUOAvmDgKdSHTwrfeGREjyqhnNPFoL
  (JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,JUOAvmDgKdSHTwrfeGREjyqhnNPFCX)=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.Baseapi_Parse(JUOAvmDgKdSHTwrfeGREjyqhnNPFkx)
  if JUOAvmDgKdSHTwrfeGREjyqhnNPFCc=='':return JUOAvmDgKdSHTwrfeGREjyqhnNPFbI,JUOAvmDgKdSHTwrfeGREjyqhnNPFkc
  try:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX['limit']=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.MV_LIMIT
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX['offset']=JUOAvmDgKdSHTwrfeGREjyqhnNPFoi((page_int-1)*JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.MV_LIMIT)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX.update(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.GetDefaultParams(login=JUOAvmDgKdSHTwrfeGREjyqhnNPFoL))
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkb=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.callRequestCookies('Get',JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,payload=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,params=JUOAvmDgKdSHTwrfeGREjyqhnNPFCX,headers=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,cookies=JUOAvmDgKdSHTwrfeGREjyqhnNPFob)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkL=json.loads(JUOAvmDgKdSHTwrfeGREjyqhnNPFkb.text)
   if not('celllist' in JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['cell_toplist']):return JUOAvmDgKdSHTwrfeGREjyqhnNPFbI,JUOAvmDgKdSHTwrfeGREjyqhnNPFkc
   JUOAvmDgKdSHTwrfeGREjyqhnNPFka=JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['cell_toplist']['celllist']
   for JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ in JUOAvmDgKdSHTwrfeGREjyqhnNPFka:
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbC =JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ['event_list'][1]['url']
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbk=urllib.parse.urlsplit(JUOAvmDgKdSHTwrfeGREjyqhnNPFbC).query
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbL=JUOAvmDgKdSHTwrfeGREjyqhnNPFbk[0:JUOAvmDgKdSHTwrfeGREjyqhnNPFbk.find('=')]
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbV=JUOAvmDgKdSHTwrfeGREjyqhnNPFbk[JUOAvmDgKdSHTwrfeGREjyqhnNPFbk.find('=')+1:]
    JUOAvmDgKdSHTwrfeGREjyqhnNPFkp={'title':JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ['title_list'][0]['text'],'age':JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ['age'],'thumbnail':'https://%s'%JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ.get('thumbnail'),'videoid':JUOAvmDgKdSHTwrfeGREjyqhnNPFbV,'vidtype':JUOAvmDgKdSHTwrfeGREjyqhnNPFbL}
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbI.append(JUOAvmDgKdSHTwrfeGREjyqhnNPFkp)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkl=JUOAvmDgKdSHTwrfeGREjyqhnNPFoa(JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['cell_toplist']['pagecount'])
   if JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['cell_toplist']['count']:JUOAvmDgKdSHTwrfeGREjyqhnNPFbo =JUOAvmDgKdSHTwrfeGREjyqhnNPFoa(JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['cell_toplist']['count'])
   else:JUOAvmDgKdSHTwrfeGREjyqhnNPFbo=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.MV_LIMIT*page_int
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkc=JUOAvmDgKdSHTwrfeGREjyqhnNPFkl>JUOAvmDgKdSHTwrfeGREjyqhnNPFbo
  except JUOAvmDgKdSHTwrfeGREjyqhnNPFoI as exception:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFox(exception)
   return[],JUOAvmDgKdSHTwrfeGREjyqhnNPFoL
  return JUOAvmDgKdSHTwrfeGREjyqhnNPFbI,JUOAvmDgKdSHTwrfeGREjyqhnNPFkc
 def ProgramidToContentid(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb,JUOAvmDgKdSHTwrfeGREjyqhnNPFba):
  JUOAvmDgKdSHTwrfeGREjyqhnNPFbx=''
  try:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCc =JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.API_DOMAIN+'/vod/programs-contentid/'+JUOAvmDgKdSHTwrfeGREjyqhnNPFba
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.GetDefaultParams(login=JUOAvmDgKdSHTwrfeGREjyqhnNPFoL)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkb=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.callRequestCookies('Get',JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,payload=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,params=JUOAvmDgKdSHTwrfeGREjyqhnNPFCX,headers=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,cookies=JUOAvmDgKdSHTwrfeGREjyqhnNPFob)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFbX=json.loads(JUOAvmDgKdSHTwrfeGREjyqhnNPFkb.text)
   if not('contentid' in JUOAvmDgKdSHTwrfeGREjyqhnNPFbX):return JUOAvmDgKdSHTwrfeGREjyqhnNPFbx 
   JUOAvmDgKdSHTwrfeGREjyqhnNPFbx=JUOAvmDgKdSHTwrfeGREjyqhnNPFbX['contentid']
  except JUOAvmDgKdSHTwrfeGREjyqhnNPFoI as exception:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFox(exception)
  return JUOAvmDgKdSHTwrfeGREjyqhnNPFbx
 def ContentidToProgramid(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb,JUOAvmDgKdSHTwrfeGREjyqhnNPFbx):
  JUOAvmDgKdSHTwrfeGREjyqhnNPFba=''
  try:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCc =JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.API_DOMAIN+'/cf/vod/contents/'+JUOAvmDgKdSHTwrfeGREjyqhnNPFbx
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.GetDefaultParams(login=JUOAvmDgKdSHTwrfeGREjyqhnNPFoL)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkb=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.callRequestCookies('Get',JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,payload=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,params=JUOAvmDgKdSHTwrfeGREjyqhnNPFCX,headers=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,cookies=JUOAvmDgKdSHTwrfeGREjyqhnNPFob)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFbX=json.loads(JUOAvmDgKdSHTwrfeGREjyqhnNPFkb.text)
   if not('programid' in JUOAvmDgKdSHTwrfeGREjyqhnNPFbX):return JUOAvmDgKdSHTwrfeGREjyqhnNPFba 
   JUOAvmDgKdSHTwrfeGREjyqhnNPFba=JUOAvmDgKdSHTwrfeGREjyqhnNPFbX['programid']
  except JUOAvmDgKdSHTwrfeGREjyqhnNPFoI as exception:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFox(exception)
  return JUOAvmDgKdSHTwrfeGREjyqhnNPFba
 def GetProgramInfo(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb,program_code):
  JUOAvmDgKdSHTwrfeGREjyqhnNPFbQ={}
  try:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCc=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.API_DOMAIN+'/cf/vod/contents/'+program_code
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.GetDefaultParams(login=JUOAvmDgKdSHTwrfeGREjyqhnNPFoL)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkb=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.callRequestCookies('Get',JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,payload=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,params=JUOAvmDgKdSHTwrfeGREjyqhnNPFCX,headers=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,cookies=JUOAvmDgKdSHTwrfeGREjyqhnNPFob)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFbX=json.loads(JUOAvmDgKdSHTwrfeGREjyqhnNPFkb.text)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFox(JUOAvmDgKdSHTwrfeGREjyqhnNPFbX)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFbp=img_fanart=JUOAvmDgKdSHTwrfeGREjyqhnNPFbM=''
   if JUOAvmDgKdSHTwrfeGREjyqhnNPFbX.get('programposterimage')!='':JUOAvmDgKdSHTwrfeGREjyqhnNPFbp =JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.HTTPTAG+JUOAvmDgKdSHTwrfeGREjyqhnNPFbX.get('programposterimage')
   if JUOAvmDgKdSHTwrfeGREjyqhnNPFbX.get('programimage') !='':img_fanart =JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.HTTPTAG+JUOAvmDgKdSHTwrfeGREjyqhnNPFbX.get('programimage')
   if JUOAvmDgKdSHTwrfeGREjyqhnNPFbX.get('programcirlceimage')!='':JUOAvmDgKdSHTwrfeGREjyqhnNPFbM=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.HTTPTAG+JUOAvmDgKdSHTwrfeGREjyqhnNPFbX.get('programcirlceimage')
   if 'poster_default' in JUOAvmDgKdSHTwrfeGREjyqhnNPFbp:
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbp =img_fanart
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbM=''
   JUOAvmDgKdSHTwrfeGREjyqhnNPFbQ={'imgPoster':JUOAvmDgKdSHTwrfeGREjyqhnNPFbp,'imgFanart':img_fanart,'imgClearlogo':JUOAvmDgKdSHTwrfeGREjyqhnNPFbM}
  except JUOAvmDgKdSHTwrfeGREjyqhnNPFoI as exception:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFox(exception)
  return JUOAvmDgKdSHTwrfeGREjyqhnNPFbQ
 def Get_Episode_List(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb,JUOAvmDgKdSHTwrfeGREjyqhnNPFbV,JUOAvmDgKdSHTwrfeGREjyqhnNPFbL,page_int=1,orderby='desc'):
  JUOAvmDgKdSHTwrfeGREjyqhnNPFbu=[]
  JUOAvmDgKdSHTwrfeGREjyqhnNPFkl=JUOAvmDgKdSHTwrfeGREjyqhnNPFbo=1
  JUOAvmDgKdSHTwrfeGREjyqhnNPFkc=JUOAvmDgKdSHTwrfeGREjyqhnNPFoL
  JUOAvmDgKdSHTwrfeGREjyqhnNPFbB={}
  if JUOAvmDgKdSHTwrfeGREjyqhnNPFbL=='contentid':
   JUOAvmDgKdSHTwrfeGREjyqhnNPFba=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.ContentidToProgramid(JUOAvmDgKdSHTwrfeGREjyqhnNPFbV)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFbB=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.GetProgramInfo(JUOAvmDgKdSHTwrfeGREjyqhnNPFbV)
  else:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFba=JUOAvmDgKdSHTwrfeGREjyqhnNPFbV
   JUOAvmDgKdSHTwrfeGREjyqhnNPFbx=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.ProgramidToContentid(JUOAvmDgKdSHTwrfeGREjyqhnNPFbV)
   if JUOAvmDgKdSHTwrfeGREjyqhnNPFbx!='':JUOAvmDgKdSHTwrfeGREjyqhnNPFbB=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.GetProgramInfo(JUOAvmDgKdSHTwrfeGREjyqhnNPFbx)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCc=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.API_DOMAIN+'/vod/programs-contents/'+JUOAvmDgKdSHTwrfeGREjyqhnNPFba
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX={}
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX['limit'] =JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.EP_LIMIT
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX['offset']=JUOAvmDgKdSHTwrfeGREjyqhnNPFoi((page_int-1)*JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.EP_LIMIT)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX['orderby']=orderby 
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX.update(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.GetDefaultParams(login=JUOAvmDgKdSHTwrfeGREjyqhnNPFoL))
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkb=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.callRequestCookies('Get',JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,payload=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,params=JUOAvmDgKdSHTwrfeGREjyqhnNPFCX,headers=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,cookies=JUOAvmDgKdSHTwrfeGREjyqhnNPFob)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkL=json.loads(JUOAvmDgKdSHTwrfeGREjyqhnNPFkb.text)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFka=JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['list']
   for JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ in JUOAvmDgKdSHTwrfeGREjyqhnNPFka:
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbt=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ.get('synopsis'))
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbz=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.HTTPTAG+JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ.get('image')
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbl=JUOAvmDgKdSHTwrfeGREjyqhnNPFbc=JUOAvmDgKdSHTwrfeGREjyqhnNPFLC=''
    if JUOAvmDgKdSHTwrfeGREjyqhnNPFbB!={}:
     JUOAvmDgKdSHTwrfeGREjyqhnNPFbl =JUOAvmDgKdSHTwrfeGREjyqhnNPFbB.get('imgPoster')
     JUOAvmDgKdSHTwrfeGREjyqhnNPFbc =JUOAvmDgKdSHTwrfeGREjyqhnNPFbB.get('imgFanart')
     JUOAvmDgKdSHTwrfeGREjyqhnNPFLC=JUOAvmDgKdSHTwrfeGREjyqhnNPFbB.get('imgClearlogo')
     JUOAvmDgKdSHTwrfeGREjyqhnNPFLk={'thumb':JUOAvmDgKdSHTwrfeGREjyqhnNPFbz,'poster':JUOAvmDgKdSHTwrfeGREjyqhnNPFbl,'fanart':JUOAvmDgKdSHTwrfeGREjyqhnNPFbc,'clearlogo':JUOAvmDgKdSHTwrfeGREjyqhnNPFLC}
    else:
     JUOAvmDgKdSHTwrfeGREjyqhnNPFLk=JUOAvmDgKdSHTwrfeGREjyqhnNPFbz
    JUOAvmDgKdSHTwrfeGREjyqhnNPFkp={'programtitle':JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ.get('programtitle'),'episodetitle':JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ.get('episodetitle'),'episodenumber':JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ.get('episodenumber'),'releasedate':JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ.get('releasedate'),'releaseweekday':JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ.get('releaseweekday'),'programid':JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ.get('programid'),'contentid':JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ.get('contentid'),'age':JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ.get('targetage'),'playtime':JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ.get('playtime'),'synopsis':JUOAvmDgKdSHTwrfeGREjyqhnNPFbt,'episodeactors':JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ.get('episodeactors').split(',')if JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ.get('episodeactors')!='' else[],'thumbnail':JUOAvmDgKdSHTwrfeGREjyqhnNPFLk}
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbu.append(JUOAvmDgKdSHTwrfeGREjyqhnNPFkp)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkl=JUOAvmDgKdSHTwrfeGREjyqhnNPFoa(JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['pagecount'])
   if JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['count']:JUOAvmDgKdSHTwrfeGREjyqhnNPFbo =JUOAvmDgKdSHTwrfeGREjyqhnNPFoa(JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['count'])
   else:JUOAvmDgKdSHTwrfeGREjyqhnNPFbo=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.EP_LIMIT*page_int
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkc=JUOAvmDgKdSHTwrfeGREjyqhnNPFkl>JUOAvmDgKdSHTwrfeGREjyqhnNPFbo
  except JUOAvmDgKdSHTwrfeGREjyqhnNPFoI as exception:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFox(exception)
   return[],JUOAvmDgKdSHTwrfeGREjyqhnNPFoL
  return JUOAvmDgKdSHTwrfeGREjyqhnNPFbu,JUOAvmDgKdSHTwrfeGREjyqhnNPFkc
 def GetEPGList(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb,genre):
  JUOAvmDgKdSHTwrfeGREjyqhnNPFLb={}
  try:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFLV=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.Get_Now_Datetime()
   if genre=='all':
    JUOAvmDgKdSHTwrfeGREjyqhnNPFLo =JUOAvmDgKdSHTwrfeGREjyqhnNPFLV+datetime.timedelta(hours=3)
   else:
    JUOAvmDgKdSHTwrfeGREjyqhnNPFLo =JUOAvmDgKdSHTwrfeGREjyqhnNPFLV+datetime.timedelta(hours=3)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCc=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.API_DOMAIN+'/live/epgs'
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX={'limit':'100','offset':'0','genre':genre,'startdatetime':JUOAvmDgKdSHTwrfeGREjyqhnNPFLV.strftime('%Y-%m-%d %H:00'),'enddatetime':JUOAvmDgKdSHTwrfeGREjyqhnNPFLo.strftime('%Y-%m-%d %H:00')}
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX.update(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.GetDefaultParams(login=JUOAvmDgKdSHTwrfeGREjyqhnNPFoL))
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkb=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.callRequestCookies('Get',JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,payload=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,params=JUOAvmDgKdSHTwrfeGREjyqhnNPFCX,headers=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,cookies=JUOAvmDgKdSHTwrfeGREjyqhnNPFob)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkL=json.loads(JUOAvmDgKdSHTwrfeGREjyqhnNPFkb.text)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFLY=JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['list']
   for JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ in JUOAvmDgKdSHTwrfeGREjyqhnNPFLY:
    JUOAvmDgKdSHTwrfeGREjyqhnNPFLW=''
    for JUOAvmDgKdSHTwrfeGREjyqhnNPFLi in JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ['list']:
     if JUOAvmDgKdSHTwrfeGREjyqhnNPFLW:JUOAvmDgKdSHTwrfeGREjyqhnNPFLW+='\n'
     JUOAvmDgKdSHTwrfeGREjyqhnNPFLW+=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.Get_ChangeText(JUOAvmDgKdSHTwrfeGREjyqhnNPFLi['title'])+'\n'
     JUOAvmDgKdSHTwrfeGREjyqhnNPFLW+=' [%s ~ %s]'%(JUOAvmDgKdSHTwrfeGREjyqhnNPFLi['starttime'][-5:],JUOAvmDgKdSHTwrfeGREjyqhnNPFLi['endtime'][-5:])+'\n'
    JUOAvmDgKdSHTwrfeGREjyqhnNPFLb[JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ['channelid']]=JUOAvmDgKdSHTwrfeGREjyqhnNPFLW
  except JUOAvmDgKdSHTwrfeGREjyqhnNPFoI as exception:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFox(exception)
  return JUOAvmDgKdSHTwrfeGREjyqhnNPFLb
 def Get_LiveChannel_List(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb,genre,JUOAvmDgKdSHTwrfeGREjyqhnNPFkx):
  JUOAvmDgKdSHTwrfeGREjyqhnNPFkz=[]
  (JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,JUOAvmDgKdSHTwrfeGREjyqhnNPFCX)=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.Baseapi_Parse(JUOAvmDgKdSHTwrfeGREjyqhnNPFkx)
  if JUOAvmDgKdSHTwrfeGREjyqhnNPFCc=='':return JUOAvmDgKdSHTwrfeGREjyqhnNPFkz
  JUOAvmDgKdSHTwrfeGREjyqhnNPFLI=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.GetEPGList(genre)
  try:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX.update(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.GetDefaultParams(login=JUOAvmDgKdSHTwrfeGREjyqhnNPFoL))
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX['genre']=genre
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkb=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.callRequestCookies('Get',JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,payload=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,params=JUOAvmDgKdSHTwrfeGREjyqhnNPFCX,headers=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,cookies=JUOAvmDgKdSHTwrfeGREjyqhnNPFob)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkL=json.loads(JUOAvmDgKdSHTwrfeGREjyqhnNPFkb.text)
   if not('celllist' in JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['cell_toplist']):return[]
   JUOAvmDgKdSHTwrfeGREjyqhnNPFka=JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['cell_toplist']['celllist']
   for JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ in JUOAvmDgKdSHTwrfeGREjyqhnNPFka:
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbx=JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ['contentid']
    if JUOAvmDgKdSHTwrfeGREjyqhnNPFbx in JUOAvmDgKdSHTwrfeGREjyqhnNPFLI:
     JUOAvmDgKdSHTwrfeGREjyqhnNPFLx=JUOAvmDgKdSHTwrfeGREjyqhnNPFLI[JUOAvmDgKdSHTwrfeGREjyqhnNPFbx]
    else:
     JUOAvmDgKdSHTwrfeGREjyqhnNPFLx=''
    JUOAvmDgKdSHTwrfeGREjyqhnNPFkp={'studio':JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ['title_list'][0]['text'],'tvshowtitle':JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.Get_ChangeText(JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ['title_list'][1]['text']),'channelid':JUOAvmDgKdSHTwrfeGREjyqhnNPFbx,'age':JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ['age'],'thumbnail':'https://%s'%JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ.get('thumbnail'),'epg':JUOAvmDgKdSHTwrfeGREjyqhnNPFLx}
    JUOAvmDgKdSHTwrfeGREjyqhnNPFkz.append(JUOAvmDgKdSHTwrfeGREjyqhnNPFkp)
  except JUOAvmDgKdSHTwrfeGREjyqhnNPFoI as exception:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFox(exception)
   return[]
  return JUOAvmDgKdSHTwrfeGREjyqhnNPFkz
 def Get_Search_List(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb,search_key,sType,page_int,exclusion21=JUOAvmDgKdSHTwrfeGREjyqhnNPFoL):
  JUOAvmDgKdSHTwrfeGREjyqhnNPFLX=[]
  JUOAvmDgKdSHTwrfeGREjyqhnNPFkl=JUOAvmDgKdSHTwrfeGREjyqhnNPFbo=1
  JUOAvmDgKdSHTwrfeGREjyqhnNPFkc=JUOAvmDgKdSHTwrfeGREjyqhnNPFoL
  try:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCc=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.API_DOMAIN+'/cf/search/list.js'
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':JUOAvmDgKdSHTwrfeGREjyqhnNPFoi((page_int-1)*JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.SEARCH_LIMIT),'limit':JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.SEARCH_LIMIT,'orderby':'score'}
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX.update(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.GetDefaultParams(login=JUOAvmDgKdSHTwrfeGREjyqhnNPFoL))
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkb=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.callRequestCookies('Get',JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,payload=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,params=JUOAvmDgKdSHTwrfeGREjyqhnNPFCX,headers=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,cookies=JUOAvmDgKdSHTwrfeGREjyqhnNPFob)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFbX=json.loads(JUOAvmDgKdSHTwrfeGREjyqhnNPFkb.text)
   if not('celllist' in JUOAvmDgKdSHTwrfeGREjyqhnNPFbX['cell_toplist']):return JUOAvmDgKdSHTwrfeGREjyqhnNPFLX,JUOAvmDgKdSHTwrfeGREjyqhnNPFkc
   JUOAvmDgKdSHTwrfeGREjyqhnNPFka=JUOAvmDgKdSHTwrfeGREjyqhnNPFbX['cell_toplist']['celllist']
   for JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ in JUOAvmDgKdSHTwrfeGREjyqhnNPFka:
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbC =JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ['event_list'][1]['url']
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbk=urllib.parse.urlsplit(JUOAvmDgKdSHTwrfeGREjyqhnNPFbC).query
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbL=JUOAvmDgKdSHTwrfeGREjyqhnNPFbk[0:JUOAvmDgKdSHTwrfeGREjyqhnNPFbk.find('=')]
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbV=JUOAvmDgKdSHTwrfeGREjyqhnNPFbk[JUOAvmDgKdSHTwrfeGREjyqhnNPFbk.find('=')+1:]
    JUOAvmDgKdSHTwrfeGREjyqhnNPFkp={'title':JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ['title_list'][0]['text'],'age':JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ['age'],'thumbnail':'https://%s'%JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ.get('thumbnail'),'videoid':JUOAvmDgKdSHTwrfeGREjyqhnNPFbV,'vidtype':JUOAvmDgKdSHTwrfeGREjyqhnNPFbL}
    if exclusion21==JUOAvmDgKdSHTwrfeGREjyqhnNPFoL or JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ.get('age')!='21':
     JUOAvmDgKdSHTwrfeGREjyqhnNPFLX.append(JUOAvmDgKdSHTwrfeGREjyqhnNPFkp)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkl=JUOAvmDgKdSHTwrfeGREjyqhnNPFoa(JUOAvmDgKdSHTwrfeGREjyqhnNPFbX['cell_toplist']['pagecount'])
   if JUOAvmDgKdSHTwrfeGREjyqhnNPFbX['cell_toplist']['count']:JUOAvmDgKdSHTwrfeGREjyqhnNPFbo =JUOAvmDgKdSHTwrfeGREjyqhnNPFoa(JUOAvmDgKdSHTwrfeGREjyqhnNPFbX['cell_toplist']['count'])
   else:JUOAvmDgKdSHTwrfeGREjyqhnNPFbo=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.LIST_LIMIT
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkc=JUOAvmDgKdSHTwrfeGREjyqhnNPFkl>JUOAvmDgKdSHTwrfeGREjyqhnNPFbo
  except JUOAvmDgKdSHTwrfeGREjyqhnNPFoI as exception:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFox(exception)
  return JUOAvmDgKdSHTwrfeGREjyqhnNPFLX,JUOAvmDgKdSHTwrfeGREjyqhnNPFkc 
 def GetStreamingURL(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb,mode,JUOAvmDgKdSHTwrfeGREjyqhnNPFbx,quality_int,pvrmode='-'):
  JUOAvmDgKdSHTwrfeGREjyqhnNPFLa=JUOAvmDgKdSHTwrfeGREjyqhnNPFLz=JUOAvmDgKdSHTwrfeGREjyqhnNPFLl=streaming_preview=''
  JUOAvmDgKdSHTwrfeGREjyqhnNPFLQ=[]
  JUOAvmDgKdSHTwrfeGREjyqhnNPFLp='hls'
  if mode=='LIVE':
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCc =JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.API_DOMAIN+'/live/channels/'+JUOAvmDgKdSHTwrfeGREjyqhnNPFbx
   JUOAvmDgKdSHTwrfeGREjyqhnNPFLM='live'
  elif mode=='VOD':
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCc =JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.API_DOMAIN+'/cf/vod/contents/'+JUOAvmDgKdSHTwrfeGREjyqhnNPFbx
   JUOAvmDgKdSHTwrfeGREjyqhnNPFLM='vod'
  elif mode=='MOVIE':
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCc =JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.API_DOMAIN+'/cf/movie/contents/'+JUOAvmDgKdSHTwrfeGREjyqhnNPFbx
   JUOAvmDgKdSHTwrfeGREjyqhnNPFLM='movie'
  try:
   if mode!='LIVE' or pvrmode=='-':
    JUOAvmDgKdSHTwrfeGREjyqhnNPFCX=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.GetDefaultParams(login=JUOAvmDgKdSHTwrfeGREjyqhnNPFoL)
    JUOAvmDgKdSHTwrfeGREjyqhnNPFkb=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.callRequestCookies('Get',JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,payload=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,params=JUOAvmDgKdSHTwrfeGREjyqhnNPFCX,headers=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,cookies=JUOAvmDgKdSHTwrfeGREjyqhnNPFob)
    JUOAvmDgKdSHTwrfeGREjyqhnNPFkL=json.loads(JUOAvmDgKdSHTwrfeGREjyqhnNPFkb.text)
    JUOAvmDgKdSHTwrfeGREjyqhnNPFLu=JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['qualities']['list']
    if JUOAvmDgKdSHTwrfeGREjyqhnNPFLu==JUOAvmDgKdSHTwrfeGREjyqhnNPFob:return(JUOAvmDgKdSHTwrfeGREjyqhnNPFLa,JUOAvmDgKdSHTwrfeGREjyqhnNPFLz,JUOAvmDgKdSHTwrfeGREjyqhnNPFLl,streaming_preview)
    for JUOAvmDgKdSHTwrfeGREjyqhnNPFLB in JUOAvmDgKdSHTwrfeGREjyqhnNPFLu:
     JUOAvmDgKdSHTwrfeGREjyqhnNPFLQ.append(JUOAvmDgKdSHTwrfeGREjyqhnNPFoa(JUOAvmDgKdSHTwrfeGREjyqhnNPFLB.get('id').rstrip('p')))
    if 'type' in JUOAvmDgKdSHTwrfeGREjyqhnNPFkL:
     if JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['type']=='onair':
      JUOAvmDgKdSHTwrfeGREjyqhnNPFLM='onairvod'
    if 'drms' in JUOAvmDgKdSHTwrfeGREjyqhnNPFkL:
     if JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['drms']:
      JUOAvmDgKdSHTwrfeGREjyqhnNPFLp='dash'
  except JUOAvmDgKdSHTwrfeGREjyqhnNPFoI as exception:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFox(exception)
   return(JUOAvmDgKdSHTwrfeGREjyqhnNPFLa,JUOAvmDgKdSHTwrfeGREjyqhnNPFLz,JUOAvmDgKdSHTwrfeGREjyqhnNPFLl,streaming_preview)
  try:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFLs=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.CheckQuality(quality_int,JUOAvmDgKdSHTwrfeGREjyqhnNPFLQ)
   if mode=='LIVE' and pvrmode!='-':
    JUOAvmDgKdSHTwrfeGREjyqhnNPFLt='auto'
   else:
    JUOAvmDgKdSHTwrfeGREjyqhnNPFLt=JUOAvmDgKdSHTwrfeGREjyqhnNPFoi(JUOAvmDgKdSHTwrfeGREjyqhnNPFLs)+'p'
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCc=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.API_DOMAIN+'/streaming'
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX={'contentid':JUOAvmDgKdSHTwrfeGREjyqhnNPFbx,'contenttype':JUOAvmDgKdSHTwrfeGREjyqhnNPFLM,'action':JUOAvmDgKdSHTwrfeGREjyqhnNPFLp,'quality':JUOAvmDgKdSHTwrfeGREjyqhnNPFLt,'deviceModelId':'Windows 10','guid':JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.GetGUID(guidType=2),'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n'}
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX.update(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.GetDefaultParams(login=JUOAvmDgKdSHTwrfeGREjyqhnNPFoY))
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkb=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.callRequestCookies('Get',JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,payload=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,params=JUOAvmDgKdSHTwrfeGREjyqhnNPFCX,headers=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,cookies=JUOAvmDgKdSHTwrfeGREjyqhnNPFob)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkL=json.loads(JUOAvmDgKdSHTwrfeGREjyqhnNPFkb.text)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFLa=JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['playurl']
   if JUOAvmDgKdSHTwrfeGREjyqhnNPFLa==JUOAvmDgKdSHTwrfeGREjyqhnNPFob:return(JUOAvmDgKdSHTwrfeGREjyqhnNPFLa,JUOAvmDgKdSHTwrfeGREjyqhnNPFLz,JUOAvmDgKdSHTwrfeGREjyqhnNPFLl,streaming_preview)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFLz=JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['awscookie']
   JUOAvmDgKdSHTwrfeGREjyqhnNPFLl =JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['drm']
   if 'previewmsg' in JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['preview']:streaming_preview=JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['preview']['previewmsg']
  except JUOAvmDgKdSHTwrfeGREjyqhnNPFoI as exception:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFox(exception)
  return(JUOAvmDgKdSHTwrfeGREjyqhnNPFLa,JUOAvmDgKdSHTwrfeGREjyqhnNPFLz,JUOAvmDgKdSHTwrfeGREjyqhnNPFLl,streaming_preview) 
 def GetSportsURL(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb,JUOAvmDgKdSHTwrfeGREjyqhnNPFbx,quality_int):
  JUOAvmDgKdSHTwrfeGREjyqhnNPFLa=JUOAvmDgKdSHTwrfeGREjyqhnNPFLz=''
  JUOAvmDgKdSHTwrfeGREjyqhnNPFLQ=[]
  try:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCc=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.API_DOMAIN+'/streaming/other'
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX={'contentid':JUOAvmDgKdSHTwrfeGREjyqhnNPFbx,'contenttype':'live','action':'hls','quality':JUOAvmDgKdSHTwrfeGREjyqhnNPFoi(quality_int)+'p','deviceModelId':'Windows 10','guid':JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.GetGUID(guidType=2),'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n'}
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX.update(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.GetDefaultParams(login=JUOAvmDgKdSHTwrfeGREjyqhnNPFoY))
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkb=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.callRequestCookies('Get',JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,payload=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,params=JUOAvmDgKdSHTwrfeGREjyqhnNPFCX,headers=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,cookies=JUOAvmDgKdSHTwrfeGREjyqhnNPFob)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkL=json.loads(JUOAvmDgKdSHTwrfeGREjyqhnNPFkb.text)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFLa=JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['playurl']
   if JUOAvmDgKdSHTwrfeGREjyqhnNPFLa==JUOAvmDgKdSHTwrfeGREjyqhnNPFob:return(JUOAvmDgKdSHTwrfeGREjyqhnNPFLa,JUOAvmDgKdSHTwrfeGREjyqhnNPFLz)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFLz=JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['awscookie']
  except JUOAvmDgKdSHTwrfeGREjyqhnNPFoI as exception:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFox(exception)
  return(JUOAvmDgKdSHTwrfeGREjyqhnNPFLa,JUOAvmDgKdSHTwrfeGREjyqhnNPFLz) 
 def make_viewdate(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb):
  JUOAvmDgKdSHTwrfeGREjyqhnNPFLc =JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.Get_Now_Datetime()
  JUOAvmDgKdSHTwrfeGREjyqhnNPFVC =JUOAvmDgKdSHTwrfeGREjyqhnNPFLc+datetime.timedelta(days=-1)
  JUOAvmDgKdSHTwrfeGREjyqhnNPFVk =JUOAvmDgKdSHTwrfeGREjyqhnNPFLc+datetime.timedelta(days=1)
  JUOAvmDgKdSHTwrfeGREjyqhnNPFVb=[JUOAvmDgKdSHTwrfeGREjyqhnNPFLc.strftime('%Y%m%d'),JUOAvmDgKdSHTwrfeGREjyqhnNPFVk.strftime('%Y%m%d'),]
  return JUOAvmDgKdSHTwrfeGREjyqhnNPFVb
 def Get_Sports_Gamelist(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb):
  JUOAvmDgKdSHTwrfeGREjyqhnNPFVL =JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.make_viewdate()
  JUOAvmDgKdSHTwrfeGREjyqhnNPFVo=[]
  JUOAvmDgKdSHTwrfeGREjyqhnNPFVY =[]
  for JUOAvmDgKdSHTwrfeGREjyqhnNPFVW in JUOAvmDgKdSHTwrfeGREjyqhnNPFVL:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFVi=JUOAvmDgKdSHTwrfeGREjyqhnNPFVW[:6]
   if JUOAvmDgKdSHTwrfeGREjyqhnNPFVi not in JUOAvmDgKdSHTwrfeGREjyqhnNPFVo:
    JUOAvmDgKdSHTwrfeGREjyqhnNPFVo.append(JUOAvmDgKdSHTwrfeGREjyqhnNPFVi)
  try:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCc='https://annexapi.wavve.com/skb/baseball/teammonthlycalendarlist'
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX={'IF':'IF-PORG-002','m':'getTeamCalendarListBand','response_format':'json','spo_itm_cd':'KBO','teamcd':'all','tgroup':'B','tvalue':'BC123','ver':'2.0',}
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX.update(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.GetDefaultParams(login=JUOAvmDgKdSHTwrfeGREjyqhnNPFoL))
   for JUOAvmDgKdSHTwrfeGREjyqhnNPFVI in JUOAvmDgKdSHTwrfeGREjyqhnNPFVo:
    JUOAvmDgKdSHTwrfeGREjyqhnNPFCX['date']=JUOAvmDgKdSHTwrfeGREjyqhnNPFVI
    JUOAvmDgKdSHTwrfeGREjyqhnNPFkb=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.callRequestCookies('Get',JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,payload=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,params=JUOAvmDgKdSHTwrfeGREjyqhnNPFCX,headers=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,cookies=JUOAvmDgKdSHTwrfeGREjyqhnNPFob)
    JUOAvmDgKdSHTwrfeGREjyqhnNPFkL=json.loads(JUOAvmDgKdSHTwrfeGREjyqhnNPFkb.text)
    JUOAvmDgKdSHTwrfeGREjyqhnNPFka=JUOAvmDgKdSHTwrfeGREjyqhnNPFkL['cell_toplist']['celllist']
    for JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ in JUOAvmDgKdSHTwrfeGREjyqhnNPFka:
     JUOAvmDgKdSHTwrfeGREjyqhnNPFVx=JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ.get('game_date')
     JUOAvmDgKdSHTwrfeGREjyqhnNPFVX =JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ.get('svc_id')
     if JUOAvmDgKdSHTwrfeGREjyqhnNPFVX=='':continue
     if JUOAvmDgKdSHTwrfeGREjyqhnNPFVx in JUOAvmDgKdSHTwrfeGREjyqhnNPFVL:
      JUOAvmDgKdSHTwrfeGREjyqhnNPFVa=JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ.get('game_status') 
      JUOAvmDgKdSHTwrfeGREjyqhnNPFVQ =JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ.get('title_list')[0].get('text')
      JUOAvmDgKdSHTwrfeGREjyqhnNPFVx =JUOAvmDgKdSHTwrfeGREjyqhnNPFVx[:4]+'-'+JUOAvmDgKdSHTwrfeGREjyqhnNPFVx[4:6]+'-'+JUOAvmDgKdSHTwrfeGREjyqhnNPFVx[-2:]
      JUOAvmDgKdSHTwrfeGREjyqhnNPFVp =JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ.get('game_time')
      JUOAvmDgKdSHTwrfeGREjyqhnNPFVp =JUOAvmDgKdSHTwrfeGREjyqhnNPFVp[:2]+':'+JUOAvmDgKdSHTwrfeGREjyqhnNPFVp[-2:]
      JUOAvmDgKdSHTwrfeGREjyqhnNPFkp={'game_date':JUOAvmDgKdSHTwrfeGREjyqhnNPFVx,'game_time':JUOAvmDgKdSHTwrfeGREjyqhnNPFVp,'svc_id':JUOAvmDgKdSHTwrfeGREjyqhnNPFVX,'away_team':JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ.get('away_team').get('team_name'),'home_team':JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ.get('home_team').get('team_name'),'game_status':JUOAvmDgKdSHTwrfeGREjyqhnNPFVa,'game_place':JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ.get('game_place'),}
      JUOAvmDgKdSHTwrfeGREjyqhnNPFVY.append(JUOAvmDgKdSHTwrfeGREjyqhnNPFkp)
  except JUOAvmDgKdSHTwrfeGREjyqhnNPFoI as exception:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFox(exception)
   return[]
  JUOAvmDgKdSHTwrfeGREjyqhnNPFVM=[]
  for i in JUOAvmDgKdSHTwrfeGREjyqhnNPFoW(2):
   for JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ in JUOAvmDgKdSHTwrfeGREjyqhnNPFVY:
    if i==0 and JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ.get('game_status')=='LIVE':
     JUOAvmDgKdSHTwrfeGREjyqhnNPFVM.append(JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ)
    elif i==1 and JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ.get('game_status')!='LIVE':
     JUOAvmDgKdSHTwrfeGREjyqhnNPFVM.append(JUOAvmDgKdSHTwrfeGREjyqhnNPFkQ)
  return JUOAvmDgKdSHTwrfeGREjyqhnNPFVM
 def GetBookmarkInfo(JUOAvmDgKdSHTwrfeGREjyqhnNPFCb,JUOAvmDgKdSHTwrfeGREjyqhnNPFbV,JUOAvmDgKdSHTwrfeGREjyqhnNPFbL,JUOAvmDgKdSHTwrfeGREjyqhnNPFLM):
  if JUOAvmDgKdSHTwrfeGREjyqhnNPFbL=='tvshow':
   if JUOAvmDgKdSHTwrfeGREjyqhnNPFLM=='contentid':
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbx=JUOAvmDgKdSHTwrfeGREjyqhnNPFbV
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbV =JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.ContentidToProgramid(JUOAvmDgKdSHTwrfeGREjyqhnNPFbx)
   else:
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbx=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.ProgramidToContentid(JUOAvmDgKdSHTwrfeGREjyqhnNPFbV)
  else:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFbx=''
  JUOAvmDgKdSHTwrfeGREjyqhnNPFVu={'indexinfo':{'ott':'wavve','videoid':JUOAvmDgKdSHTwrfeGREjyqhnNPFbV,'vidtype':JUOAvmDgKdSHTwrfeGREjyqhnNPFbL,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':JUOAvmDgKdSHTwrfeGREjyqhnNPFbL,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if JUOAvmDgKdSHTwrfeGREjyqhnNPFbL=='tvshow':
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCc=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.API_DOMAIN+'/cf/vod/contents/'+JUOAvmDgKdSHTwrfeGREjyqhnNPFbx 
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.GetDefaultParams(login=JUOAvmDgKdSHTwrfeGREjyqhnNPFoL)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkb=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.callRequestCookies('Get',JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,payload=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,params=JUOAvmDgKdSHTwrfeGREjyqhnNPFCX,headers=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,cookies=JUOAvmDgKdSHTwrfeGREjyqhnNPFob)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkL=json.loads(JUOAvmDgKdSHTwrfeGREjyqhnNPFkb.text)
   if not('programtitle' in JUOAvmDgKdSHTwrfeGREjyqhnNPFkL):return{}
   JUOAvmDgKdSHTwrfeGREjyqhnNPFVB=JUOAvmDgKdSHTwrfeGREjyqhnNPFkL
   JUOAvmDgKdSHTwrfeGREjyqhnNPFVs=JUOAvmDgKdSHTwrfeGREjyqhnNPFVB.get('programtitle')
   JUOAvmDgKdSHTwrfeGREjyqhnNPFVu['saveinfo']['infoLabels']['title']=JUOAvmDgKdSHTwrfeGREjyqhnNPFVs
   if JUOAvmDgKdSHTwrfeGREjyqhnNPFVB.get('targetage')=='18' or JUOAvmDgKdSHTwrfeGREjyqhnNPFVB.get('targetage')=='19' or JUOAvmDgKdSHTwrfeGREjyqhnNPFVB.get('targetage')=='21':
    JUOAvmDgKdSHTwrfeGREjyqhnNPFVs +=u' (%s)'%(JUOAvmDgKdSHTwrfeGREjyqhnNPFVB.get('targetage'))
   JUOAvmDgKdSHTwrfeGREjyqhnNPFVu['saveinfo']['title'] =JUOAvmDgKdSHTwrfeGREjyqhnNPFVs
   JUOAvmDgKdSHTwrfeGREjyqhnNPFVu['saveinfo']['infoLabels']['mpaa'] =JUOAvmDgKdSHTwrfeGREjyqhnNPFVB.get('targetage')
   JUOAvmDgKdSHTwrfeGREjyqhnNPFVu['saveinfo']['infoLabels']['plot'] =JUOAvmDgKdSHTwrfeGREjyqhnNPFVB.get('programsynopsis').replace('<br>','\n')
   JUOAvmDgKdSHTwrfeGREjyqhnNPFVu['saveinfo']['infoLabels']['studio'] =JUOAvmDgKdSHTwrfeGREjyqhnNPFVB.get('channelname')
   if JUOAvmDgKdSHTwrfeGREjyqhnNPFVB.get('firstreleaseyear')!='':JUOAvmDgKdSHTwrfeGREjyqhnNPFVu['saveinfo']['infoLabels']['year'] =JUOAvmDgKdSHTwrfeGREjyqhnNPFVB.get('firstreleaseyear')
   if JUOAvmDgKdSHTwrfeGREjyqhnNPFVB.get('firstreleasedate')!='':JUOAvmDgKdSHTwrfeGREjyqhnNPFVu['saveinfo']['infoLabels']['premiered']=JUOAvmDgKdSHTwrfeGREjyqhnNPFVB.get('firstreleasedate')
   if JUOAvmDgKdSHTwrfeGREjyqhnNPFVB.get('genretext') !='':JUOAvmDgKdSHTwrfeGREjyqhnNPFVu['saveinfo']['infoLabels']['genre'] =[JUOAvmDgKdSHTwrfeGREjyqhnNPFVB.get('genretext')]
   JUOAvmDgKdSHTwrfeGREjyqhnNPFVt=[]
   for JUOAvmDgKdSHTwrfeGREjyqhnNPFVz in JUOAvmDgKdSHTwrfeGREjyqhnNPFVB['actors']['list']:JUOAvmDgKdSHTwrfeGREjyqhnNPFVt.append(JUOAvmDgKdSHTwrfeGREjyqhnNPFVz.get('text'))
   if JUOAvmDgKdSHTwrfeGREjyqhnNPFoQ(JUOAvmDgKdSHTwrfeGREjyqhnNPFVt)>0:
    if JUOAvmDgKdSHTwrfeGREjyqhnNPFVt[0]!='':JUOAvmDgKdSHTwrfeGREjyqhnNPFVu['saveinfo']['infoLabels']['cast']=JUOAvmDgKdSHTwrfeGREjyqhnNPFVt
   JUOAvmDgKdSHTwrfeGREjyqhnNPFbl =''
   JUOAvmDgKdSHTwrfeGREjyqhnNPFbc =''
   JUOAvmDgKdSHTwrfeGREjyqhnNPFLC=''
   if JUOAvmDgKdSHTwrfeGREjyqhnNPFVB.get('programposterimage')!='':JUOAvmDgKdSHTwrfeGREjyqhnNPFbl =JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.HTTPTAG+JUOAvmDgKdSHTwrfeGREjyqhnNPFVB.get('programposterimage')
   if JUOAvmDgKdSHTwrfeGREjyqhnNPFVB.get('programimage') !='':JUOAvmDgKdSHTwrfeGREjyqhnNPFbc =JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.HTTPTAG+JUOAvmDgKdSHTwrfeGREjyqhnNPFVB.get('programimage')
   if JUOAvmDgKdSHTwrfeGREjyqhnNPFVB.get('programcirlceimage')!='':JUOAvmDgKdSHTwrfeGREjyqhnNPFLC=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.HTTPTAG+JUOAvmDgKdSHTwrfeGREjyqhnNPFVB.get('programcirlceimage')
   if 'poster_default' in JUOAvmDgKdSHTwrfeGREjyqhnNPFbl:
    JUOAvmDgKdSHTwrfeGREjyqhnNPFbl =JUOAvmDgKdSHTwrfeGREjyqhnNPFbc
    JUOAvmDgKdSHTwrfeGREjyqhnNPFLC=''
   JUOAvmDgKdSHTwrfeGREjyqhnNPFVu['saveinfo']['thumbnail']['poster']=JUOAvmDgKdSHTwrfeGREjyqhnNPFbl
   JUOAvmDgKdSHTwrfeGREjyqhnNPFVu['saveinfo']['thumbnail']['thumb']=JUOAvmDgKdSHTwrfeGREjyqhnNPFbc
   JUOAvmDgKdSHTwrfeGREjyqhnNPFVu['saveinfo']['thumbnail']['clearlogo']=JUOAvmDgKdSHTwrfeGREjyqhnNPFLC
   JUOAvmDgKdSHTwrfeGREjyqhnNPFVu['saveinfo']['thumbnail']['fanart']=JUOAvmDgKdSHTwrfeGREjyqhnNPFbc
  else:
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCc=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.API_DOMAIN+'/movie/contents/'+JUOAvmDgKdSHTwrfeGREjyqhnNPFbV 
   JUOAvmDgKdSHTwrfeGREjyqhnNPFCX=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.GetDefaultParams(login=JUOAvmDgKdSHTwrfeGREjyqhnNPFoL)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkb=JUOAvmDgKdSHTwrfeGREjyqhnNPFCb.callRequestCookies('Get',JUOAvmDgKdSHTwrfeGREjyqhnNPFCc,payload=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,params=JUOAvmDgKdSHTwrfeGREjyqhnNPFCX,headers=JUOAvmDgKdSHTwrfeGREjyqhnNPFob,cookies=JUOAvmDgKdSHTwrfeGREjyqhnNPFob)
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkL=json.loads(JUOAvmDgKdSHTwrfeGREjyqhnNPFkb.text)
   if not('title' in JUOAvmDgKdSHTwrfeGREjyqhnNPFkL):return{}
   JUOAvmDgKdSHTwrfeGREjyqhnNPFVB=JUOAvmDgKdSHTwrfeGREjyqhnNPFkL
   JUOAvmDgKdSHTwrfeGREjyqhnNPFVs=JUOAvmDgKdSHTwrfeGREjyqhnNPFVB.get('title')
   JUOAvmDgKdSHTwrfeGREjyqhnNPFVu['saveinfo']['infoLabels']['title']=JUOAvmDgKdSHTwrfeGREjyqhnNPFVs
   if JUOAvmDgKdSHTwrfeGREjyqhnNPFVB.get('targetage')=='18' or JUOAvmDgKdSHTwrfeGREjyqhnNPFVB.get('targetage')=='19' or JUOAvmDgKdSHTwrfeGREjyqhnNPFVB.get('targetage')=='21':
    JUOAvmDgKdSHTwrfeGREjyqhnNPFVs +=u' (%s)'%(JUOAvmDgKdSHTwrfeGREjyqhnNPFVB.get('targetage'))
   JUOAvmDgKdSHTwrfeGREjyqhnNPFVu['saveinfo']['title'] =JUOAvmDgKdSHTwrfeGREjyqhnNPFVs
   JUOAvmDgKdSHTwrfeGREjyqhnNPFVu['saveinfo']['infoLabels']['mpaa'] =JUOAvmDgKdSHTwrfeGREjyqhnNPFVB.get('targetage')
   JUOAvmDgKdSHTwrfeGREjyqhnNPFVu['saveinfo']['infoLabels']['plot'] =JUOAvmDgKdSHTwrfeGREjyqhnNPFVB.get('synopsis').replace('<br>','\n')
   JUOAvmDgKdSHTwrfeGREjyqhnNPFVu['saveinfo']['infoLabels']['duration']=JUOAvmDgKdSHTwrfeGREjyqhnNPFVB.get('playtime')
   JUOAvmDgKdSHTwrfeGREjyqhnNPFVu['saveinfo']['infoLabels']['country']=JUOAvmDgKdSHTwrfeGREjyqhnNPFVB.get('country')
   JUOAvmDgKdSHTwrfeGREjyqhnNPFVu['saveinfo']['infoLabels']['studio'] =JUOAvmDgKdSHTwrfeGREjyqhnNPFVB.get('cpname')
   if JUOAvmDgKdSHTwrfeGREjyqhnNPFVB.get('releasedate')!='':
    JUOAvmDgKdSHTwrfeGREjyqhnNPFVu['saveinfo']['infoLabels']['year'] =JUOAvmDgKdSHTwrfeGREjyqhnNPFVB.get('releasedate')[:4]
    JUOAvmDgKdSHTwrfeGREjyqhnNPFVu['saveinfo']['infoLabels']['premiered']=JUOAvmDgKdSHTwrfeGREjyqhnNPFVB.get('releasedate')
   JUOAvmDgKdSHTwrfeGREjyqhnNPFVt=[]
   for JUOAvmDgKdSHTwrfeGREjyqhnNPFVz in JUOAvmDgKdSHTwrfeGREjyqhnNPFVB['actors']['list']:JUOAvmDgKdSHTwrfeGREjyqhnNPFVt.append(JUOAvmDgKdSHTwrfeGREjyqhnNPFVz.get('text'))
   if JUOAvmDgKdSHTwrfeGREjyqhnNPFoQ(JUOAvmDgKdSHTwrfeGREjyqhnNPFVt)>0:
    if JUOAvmDgKdSHTwrfeGREjyqhnNPFVt[0]!='':JUOAvmDgKdSHTwrfeGREjyqhnNPFVu['saveinfo']['infoLabels']['cast']=JUOAvmDgKdSHTwrfeGREjyqhnNPFVt
   JUOAvmDgKdSHTwrfeGREjyqhnNPFVl=[]
   for JUOAvmDgKdSHTwrfeGREjyqhnNPFVc in JUOAvmDgKdSHTwrfeGREjyqhnNPFVB['directors']['list']:JUOAvmDgKdSHTwrfeGREjyqhnNPFVl.append(JUOAvmDgKdSHTwrfeGREjyqhnNPFVc.get('text'))
   if JUOAvmDgKdSHTwrfeGREjyqhnNPFoQ(JUOAvmDgKdSHTwrfeGREjyqhnNPFVl)>0:
    if JUOAvmDgKdSHTwrfeGREjyqhnNPFVl[0]!='':JUOAvmDgKdSHTwrfeGREjyqhnNPFVu['saveinfo']['infoLabels']['director']=JUOAvmDgKdSHTwrfeGREjyqhnNPFVl
   JUOAvmDgKdSHTwrfeGREjyqhnNPFkI=[]
   for JUOAvmDgKdSHTwrfeGREjyqhnNPFoC in JUOAvmDgKdSHTwrfeGREjyqhnNPFVB['genre']['list']:JUOAvmDgKdSHTwrfeGREjyqhnNPFkI.append(JUOAvmDgKdSHTwrfeGREjyqhnNPFoC.get('text'))
   if JUOAvmDgKdSHTwrfeGREjyqhnNPFoQ(JUOAvmDgKdSHTwrfeGREjyqhnNPFkI)>0:
    if JUOAvmDgKdSHTwrfeGREjyqhnNPFkI[0]!='':JUOAvmDgKdSHTwrfeGREjyqhnNPFVu['saveinfo']['infoLabels']['genre']=JUOAvmDgKdSHTwrfeGREjyqhnNPFkI
   JUOAvmDgKdSHTwrfeGREjyqhnNPFbl ='https://%s'%JUOAvmDgKdSHTwrfeGREjyqhnNPFVB['image']
   JUOAvmDgKdSHTwrfeGREjyqhnNPFVu['saveinfo']['thumbnail']['poster'] =JUOAvmDgKdSHTwrfeGREjyqhnNPFbl
   JUOAvmDgKdSHTwrfeGREjyqhnNPFVu['saveinfo']['thumbnail']['thumb'] =JUOAvmDgKdSHTwrfeGREjyqhnNPFbl
  return JUOAvmDgKdSHTwrfeGREjyqhnNPFVu
# Created by pyminifier (https://github.com/liftoff/pyminifier)
