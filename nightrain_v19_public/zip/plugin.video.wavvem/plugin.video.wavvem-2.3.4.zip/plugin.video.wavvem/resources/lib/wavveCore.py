__author__="NightRain"
MPwXBVifFkcqTCtJlIgruHdbzROoGe=object
MPwXBVifFkcqTCtJlIgruHdbzROoGU=None
MPwXBVifFkcqTCtJlIgruHdbzROoGy=False
MPwXBVifFkcqTCtJlIgruHdbzROoGK=open
MPwXBVifFkcqTCtJlIgruHdbzROoGN=True
MPwXBVifFkcqTCtJlIgruHdbzROoGn=range
MPwXBVifFkcqTCtJlIgruHdbzROoGj=str
MPwXBVifFkcqTCtJlIgruHdbzROoGv=Exception
MPwXBVifFkcqTCtJlIgruHdbzROoGp=print
MPwXBVifFkcqTCtJlIgruHdbzROoGL=dict
MPwXBVifFkcqTCtJlIgruHdbzROoGs=int
MPwXBVifFkcqTCtJlIgruHdbzROoGh=len
import urllib
import re
import json
import sys
import requests
import datetime
import base64
class MPwXBVifFkcqTCtJlIgruHdbzROoax(MPwXBVifFkcqTCtJlIgruHdbzROoGe):
 def __init__(MPwXBVifFkcqTCtJlIgruHdbzROoaS):
  MPwXBVifFkcqTCtJlIgruHdbzROoaS.API_DOMAIN='https://apis.wavve.com'
  MPwXBVifFkcqTCtJlIgruHdbzROoaS.WV ={}
  MPwXBVifFkcqTCtJlIgruHdbzROoaS.Init_WV_Total()
  MPwXBVifFkcqTCtJlIgruHdbzROoaS.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  MPwXBVifFkcqTCtJlIgruHdbzROoaS.DEVICE ='pc'
  MPwXBVifFkcqTCtJlIgruHdbzROoaS.DRM ='wm'
  MPwXBVifFkcqTCtJlIgruHdbzROoaS.PARTNER ='pooq'
  MPwXBVifFkcqTCtJlIgruHdbzROoaS.POOQZONE ='none'
  MPwXBVifFkcqTCtJlIgruHdbzROoaS.REGION ='kor'
  MPwXBVifFkcqTCtJlIgruHdbzROoaS.TARGETAGE ='all'
  MPwXBVifFkcqTCtJlIgruHdbzROoaS.HTTPTAG ='https://'
  MPwXBVifFkcqTCtJlIgruHdbzROoaS.LIST_LIMIT=30 
  MPwXBVifFkcqTCtJlIgruHdbzROoaS.EP_LIMIT =30 
  MPwXBVifFkcqTCtJlIgruHdbzROoaS.MV_LIMIT =24 
  MPwXBVifFkcqTCtJlIgruHdbzROoaS.SEARCH_LIMIT=20 
  MPwXBVifFkcqTCtJlIgruHdbzROoaS.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.82 Safari/537.36'
  MPwXBVifFkcqTCtJlIgruHdbzROoaS.DEFAULT_HEADER={'user-agent':MPwXBVifFkcqTCtJlIgruHdbzROoaS.USER_AGENT}
 def Init_WV_Total(MPwXBVifFkcqTCtJlIgruHdbzROoaS):
  MPwXBVifFkcqTCtJlIgruHdbzROoaS.WV={'account':{},'cookies':{},}
 def callRequestCookies(MPwXBVifFkcqTCtJlIgruHdbzROoaS,jobtype,MPwXBVifFkcqTCtJlIgruHdbzROoaW,payload=MPwXBVifFkcqTCtJlIgruHdbzROoGU,params=MPwXBVifFkcqTCtJlIgruHdbzROoGU,headers=MPwXBVifFkcqTCtJlIgruHdbzROoGU,cookies=MPwXBVifFkcqTCtJlIgruHdbzROoGU,redirects=MPwXBVifFkcqTCtJlIgruHdbzROoGy):
  MPwXBVifFkcqTCtJlIgruHdbzROoaD=MPwXBVifFkcqTCtJlIgruHdbzROoaS.DEFAULT_HEADER
  if headers:MPwXBVifFkcqTCtJlIgruHdbzROoaD.update(headers)
  if jobtype=='Get':
   MPwXBVifFkcqTCtJlIgruHdbzROoam=requests.get(MPwXBVifFkcqTCtJlIgruHdbzROoaW,params=params,headers=MPwXBVifFkcqTCtJlIgruHdbzROoaD,cookies=cookies,allow_redirects=redirects)
  else:
   MPwXBVifFkcqTCtJlIgruHdbzROoam=requests.post(MPwXBVifFkcqTCtJlIgruHdbzROoaW,data=payload,params=params,headers=MPwXBVifFkcqTCtJlIgruHdbzROoaD,cookies=cookies,allow_redirects=redirects)
  return MPwXBVifFkcqTCtJlIgruHdbzROoam
 def JsonFile_Save(MPwXBVifFkcqTCtJlIgruHdbzROoaS,filename,MPwXBVifFkcqTCtJlIgruHdbzROoaG):
  if filename=='':return MPwXBVifFkcqTCtJlIgruHdbzROoGy
  try:
   fp=MPwXBVifFkcqTCtJlIgruHdbzROoGK(filename,'w',-1,'utf-8')
   json.dump(MPwXBVifFkcqTCtJlIgruHdbzROoaG,fp,indent=4,ensure_ascii=MPwXBVifFkcqTCtJlIgruHdbzROoGy)
   fp.close()
  except:
   return MPwXBVifFkcqTCtJlIgruHdbzROoGy
  return MPwXBVifFkcqTCtJlIgruHdbzROoGN
 def JsonFile_Load(MPwXBVifFkcqTCtJlIgruHdbzROoaS,filename):
  if filename=='':return{}
  try:
   fp=MPwXBVifFkcqTCtJlIgruHdbzROoGK(filename,'r',-1,'utf-8')
   MPwXBVifFkcqTCtJlIgruHdbzROoaE=json.load(fp)
   fp.close()
  except:
   return{}
  return MPwXBVifFkcqTCtJlIgruHdbzROoaE
 def Save_session_acount(MPwXBVifFkcqTCtJlIgruHdbzROoaS,MPwXBVifFkcqTCtJlIgruHdbzROoae,MPwXBVifFkcqTCtJlIgruHdbzROoaU,MPwXBVifFkcqTCtJlIgruHdbzROoay):
  MPwXBVifFkcqTCtJlIgruHdbzROoaS.WV['account']['wvid']=base64.standard_b64encode(MPwXBVifFkcqTCtJlIgruHdbzROoae.encode()).decode('utf-8')
  MPwXBVifFkcqTCtJlIgruHdbzROoaS.WV['account']['wvpw']=base64.standard_b64encode(MPwXBVifFkcqTCtJlIgruHdbzROoaU.encode()).decode('utf-8')
  MPwXBVifFkcqTCtJlIgruHdbzROoaS.WV['account']['wvpf']=MPwXBVifFkcqTCtJlIgruHdbzROoay 
 def Load_session_acount(MPwXBVifFkcqTCtJlIgruHdbzROoaS):
  try:
   MPwXBVifFkcqTCtJlIgruHdbzROoae=base64.standard_b64decode(MPwXBVifFkcqTCtJlIgruHdbzROoaS.WV['account']['wvid']).decode('utf-8')
   MPwXBVifFkcqTCtJlIgruHdbzROoaU=base64.standard_b64decode(MPwXBVifFkcqTCtJlIgruHdbzROoaS.WV['account']['wvpw']).decode('utf-8')
   MPwXBVifFkcqTCtJlIgruHdbzROoay=MPwXBVifFkcqTCtJlIgruHdbzROoaS.WV['account']['wvpf']
  except:
   return '','',0
  return MPwXBVifFkcqTCtJlIgruHdbzROoae,MPwXBVifFkcqTCtJlIgruHdbzROoaU,MPwXBVifFkcqTCtJlIgruHdbzROoay
 def GetDefaultParams(MPwXBVifFkcqTCtJlIgruHdbzROoaS,login=MPwXBVifFkcqTCtJlIgruHdbzROoGN):
  MPwXBVifFkcqTCtJlIgruHdbzROoaK={'apikey':MPwXBVifFkcqTCtJlIgruHdbzROoaS.APIKEY,'credential':MPwXBVifFkcqTCtJlIgruHdbzROoaS.WV['cookies']['credential']if login else 'none','device':MPwXBVifFkcqTCtJlIgruHdbzROoaS.DEVICE,'drm':MPwXBVifFkcqTCtJlIgruHdbzROoaS.DRM,'partner':MPwXBVifFkcqTCtJlIgruHdbzROoaS.PARTNER,'pooqzone':MPwXBVifFkcqTCtJlIgruHdbzROoaS.POOQZONE,'region':MPwXBVifFkcqTCtJlIgruHdbzROoaS.REGION,'targetage':MPwXBVifFkcqTCtJlIgruHdbzROoaS.TARGETAGE,}
  return MPwXBVifFkcqTCtJlIgruHdbzROoaK
 def GetDefaultParams_AND(MPwXBVifFkcqTCtJlIgruHdbzROoaS):
  MPwXBVifFkcqTCtJlIgruHdbzROoaK={'apikey':'6A87455D54481A536DFB8AD397C5EC4D','credential':MPwXBVifFkcqTCtJlIgruHdbzROoaS.WV['cookies']['credential'],'device':'ott','drm':MPwXBVifFkcqTCtJlIgruHdbzROoaS.DRM,'partner':MPwXBVifFkcqTCtJlIgruHdbzROoaS.PARTNER,'pooqzone':MPwXBVifFkcqTCtJlIgruHdbzROoaS.POOQZONE,'region':MPwXBVifFkcqTCtJlIgruHdbzROoaS.REGION,'targetage':MPwXBVifFkcqTCtJlIgruHdbzROoaS.TARGETAGE,}
  return MPwXBVifFkcqTCtJlIgruHdbzROoaK
 def GetGUID(MPwXBVifFkcqTCtJlIgruHdbzROoaS,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   MPwXBVifFkcqTCtJlIgruHdbzROoaN=MPwXBVifFkcqTCtJlIgruHdbzROoaS.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   MPwXBVifFkcqTCtJlIgruHdbzROoan=GenerateRandomString(5)
   MPwXBVifFkcqTCtJlIgruHdbzROoaj=MPwXBVifFkcqTCtJlIgruHdbzROoan+media+MPwXBVifFkcqTCtJlIgruHdbzROoaN
   return MPwXBVifFkcqTCtJlIgruHdbzROoaj
  def GenerateRandomString(num):
   from random import randint
   MPwXBVifFkcqTCtJlIgruHdbzROoav=""
   for i in MPwXBVifFkcqTCtJlIgruHdbzROoGn(0,num):
    s=MPwXBVifFkcqTCtJlIgruHdbzROoGj(randint(1,5))
    MPwXBVifFkcqTCtJlIgruHdbzROoav+=s
   return MPwXBVifFkcqTCtJlIgruHdbzROoav
  if guidType==3:
   MPwXBVifFkcqTCtJlIgruHdbzROoaj=guid_str
  else:
   MPwXBVifFkcqTCtJlIgruHdbzROoaj=GenerateID(guid_str)
  MPwXBVifFkcqTCtJlIgruHdbzROoap=MPwXBVifFkcqTCtJlIgruHdbzROoaS.GetHash(MPwXBVifFkcqTCtJlIgruHdbzROoaj)
  if guidType in[2,3]:
   MPwXBVifFkcqTCtJlIgruHdbzROoap='%s-%s-%s-%s-%s'%(MPwXBVifFkcqTCtJlIgruHdbzROoap[:8],MPwXBVifFkcqTCtJlIgruHdbzROoap[8:12],MPwXBVifFkcqTCtJlIgruHdbzROoap[12:16],MPwXBVifFkcqTCtJlIgruHdbzROoap[16:20],MPwXBVifFkcqTCtJlIgruHdbzROoap[20:])
  return MPwXBVifFkcqTCtJlIgruHdbzROoap
 def GetHash(MPwXBVifFkcqTCtJlIgruHdbzROoaS,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return MPwXBVifFkcqTCtJlIgruHdbzROoGj(m.hexdigest())
 def CheckQuality(MPwXBVifFkcqTCtJlIgruHdbzROoaS,sel_qt,qt_list):
  MPwXBVifFkcqTCtJlIgruHdbzROoaL=0
  for MPwXBVifFkcqTCtJlIgruHdbzROoas in qt_list:
   if sel_qt>=MPwXBVifFkcqTCtJlIgruHdbzROoas:return MPwXBVifFkcqTCtJlIgruHdbzROoas
   MPwXBVifFkcqTCtJlIgruHdbzROoaL=MPwXBVifFkcqTCtJlIgruHdbzROoas
  return MPwXBVifFkcqTCtJlIgruHdbzROoaL
 def Get_Now_Datetime(MPwXBVifFkcqTCtJlIgruHdbzROoaS):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(MPwXBVifFkcqTCtJlIgruHdbzROoaS,in_text):
  MPwXBVifFkcqTCtJlIgruHdbzROoaQ=in_text.replace('&lt;','<').replace('&gt;','>')
  MPwXBVifFkcqTCtJlIgruHdbzROoaQ=MPwXBVifFkcqTCtJlIgruHdbzROoaQ.replace('$O$','')
  MPwXBVifFkcqTCtJlIgruHdbzROoaQ=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',MPwXBVifFkcqTCtJlIgruHdbzROoaQ)
  MPwXBVifFkcqTCtJlIgruHdbzROoaQ=MPwXBVifFkcqTCtJlIgruHdbzROoaQ.lstrip('#')
  return MPwXBVifFkcqTCtJlIgruHdbzROoaQ
 def GetCredential(MPwXBVifFkcqTCtJlIgruHdbzROoaS,user_id,user_pw,user_pf):
  MPwXBVifFkcqTCtJlIgruHdbzROoaA=MPwXBVifFkcqTCtJlIgruHdbzROoGy
  try:
   MPwXBVifFkcqTCtJlIgruHdbzROoaW=MPwXBVifFkcqTCtJlIgruHdbzROoaS.API_DOMAIN+ '/login'
   MPwXBVifFkcqTCtJlIgruHdbzROoaK=MPwXBVifFkcqTCtJlIgruHdbzROoaS.GetDefaultParams(login=MPwXBVifFkcqTCtJlIgruHdbzROoGy)
   MPwXBVifFkcqTCtJlIgruHdbzROoxa={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   MPwXBVifFkcqTCtJlIgruHdbzROoxS=MPwXBVifFkcqTCtJlIgruHdbzROoaS.callRequestCookies('Post',MPwXBVifFkcqTCtJlIgruHdbzROoaW,payload=MPwXBVifFkcqTCtJlIgruHdbzROoxa,params=MPwXBVifFkcqTCtJlIgruHdbzROoaK,headers=MPwXBVifFkcqTCtJlIgruHdbzROoGU,cookies=MPwXBVifFkcqTCtJlIgruHdbzROoGU)
   MPwXBVifFkcqTCtJlIgruHdbzROoxD=json.loads(MPwXBVifFkcqTCtJlIgruHdbzROoxS.text)
   MPwXBVifFkcqTCtJlIgruHdbzROoaS.WV['cookies']['credential']=MPwXBVifFkcqTCtJlIgruHdbzROoxD['credential']
   if user_pf!=0:
    MPwXBVifFkcqTCtJlIgruHdbzROoxa={'id':MPwXBVifFkcqTCtJlIgruHdbzROoaS.WV['cookies']['credential'],'password':'','profile':MPwXBVifFkcqTCtJlIgruHdbzROoGj(user_pf),'pushid':'','type':'credential'}
    MPwXBVifFkcqTCtJlIgruHdbzROoaK =MPwXBVifFkcqTCtJlIgruHdbzROoaS.GetDefaultParams(login=MPwXBVifFkcqTCtJlIgruHdbzROoGN) 
    MPwXBVifFkcqTCtJlIgruHdbzROoxS=MPwXBVifFkcqTCtJlIgruHdbzROoaS.callRequestCookies('Post',MPwXBVifFkcqTCtJlIgruHdbzROoaW,payload=MPwXBVifFkcqTCtJlIgruHdbzROoxa,params=MPwXBVifFkcqTCtJlIgruHdbzROoaK,headers=MPwXBVifFkcqTCtJlIgruHdbzROoGU,cookies=MPwXBVifFkcqTCtJlIgruHdbzROoGU)
    MPwXBVifFkcqTCtJlIgruHdbzROoxD=json.loads(MPwXBVifFkcqTCtJlIgruHdbzROoxS.text)
    MPwXBVifFkcqTCtJlIgruHdbzROoaS.WV['cookies']['credential']=MPwXBVifFkcqTCtJlIgruHdbzROoxD['credential']
   MPwXBVifFkcqTCtJlIgruHdbzROoxm=user_id+MPwXBVifFkcqTCtJlIgruHdbzROoGj(user_pf) 
   MPwXBVifFkcqTCtJlIgruHdbzROoaS.WV['cookies']['uuid']=MPwXBVifFkcqTCtJlIgruHdbzROoaS.GetGUID(guid_str=MPwXBVifFkcqTCtJlIgruHdbzROoxm,guidType=3)
   MPwXBVifFkcqTCtJlIgruHdbzROoaA=MPwXBVifFkcqTCtJlIgruHdbzROoGN
  except MPwXBVifFkcqTCtJlIgruHdbzROoGv as exception:
   MPwXBVifFkcqTCtJlIgruHdbzROoGp(exception)
   MPwXBVifFkcqTCtJlIgruHdbzROoaS.Init_WV_Total()
  return MPwXBVifFkcqTCtJlIgruHdbzROoaA
 def GetIssue(MPwXBVifFkcqTCtJlIgruHdbzROoaS):
  MPwXBVifFkcqTCtJlIgruHdbzROoxG=MPwXBVifFkcqTCtJlIgruHdbzROoGy
  try:
   MPwXBVifFkcqTCtJlIgruHdbzROoaW=MPwXBVifFkcqTCtJlIgruHdbzROoaS.API_DOMAIN+'/guid/issue'
   MPwXBVifFkcqTCtJlIgruHdbzROoaK=MPwXBVifFkcqTCtJlIgruHdbzROoaS.GetDefaultParams()
   MPwXBVifFkcqTCtJlIgruHdbzROoxS=MPwXBVifFkcqTCtJlIgruHdbzROoaS.callRequestCookies('Get',MPwXBVifFkcqTCtJlIgruHdbzROoaW,payload=MPwXBVifFkcqTCtJlIgruHdbzROoGU,params=MPwXBVifFkcqTCtJlIgruHdbzROoaK,headers=MPwXBVifFkcqTCtJlIgruHdbzROoGU,cookies=MPwXBVifFkcqTCtJlIgruHdbzROoGU)
   MPwXBVifFkcqTCtJlIgruHdbzROoxD=json.loads(MPwXBVifFkcqTCtJlIgruHdbzROoxS.text)
   MPwXBVifFkcqTCtJlIgruHdbzROoxY=MPwXBVifFkcqTCtJlIgruHdbzROoxD['guid']
   MPwXBVifFkcqTCtJlIgruHdbzROoxE=MPwXBVifFkcqTCtJlIgruHdbzROoxD['guidtimestamp']
   if MPwXBVifFkcqTCtJlIgruHdbzROoxY:MPwXBVifFkcqTCtJlIgruHdbzROoxG=MPwXBVifFkcqTCtJlIgruHdbzROoGN
  except MPwXBVifFkcqTCtJlIgruHdbzROoGv as exception:
   MPwXBVifFkcqTCtJlIgruHdbzROoGp(exception)
   MPwXBVifFkcqTCtJlIgruHdbzROoxY='none'
   MPwXBVifFkcqTCtJlIgruHdbzROoxE='none' 
  MPwXBVifFkcqTCtJlIgruHdbzROoaS.guid=MPwXBVifFkcqTCtJlIgruHdbzROoxY
  MPwXBVifFkcqTCtJlIgruHdbzROoaS.guidtimestamp=MPwXBVifFkcqTCtJlIgruHdbzROoxE
  return MPwXBVifFkcqTCtJlIgruHdbzROoxG
 def Baseapi_Parse(MPwXBVifFkcqTCtJlIgruHdbzROoaS,MPwXBVifFkcqTCtJlIgruHdbzROoxK):
  try:
   MPwXBVifFkcqTCtJlIgruHdbzROoxe =urllib.parse.urlsplit(MPwXBVifFkcqTCtJlIgruHdbzROoxK)
   if MPwXBVifFkcqTCtJlIgruHdbzROoxe.netloc=='':
    MPwXBVifFkcqTCtJlIgruHdbzROoaW=MPwXBVifFkcqTCtJlIgruHdbzROoaS.HTTPTAG+MPwXBVifFkcqTCtJlIgruHdbzROoxe.netloc+MPwXBVifFkcqTCtJlIgruHdbzROoxe.path
   else:
    MPwXBVifFkcqTCtJlIgruHdbzROoaW=MPwXBVifFkcqTCtJlIgruHdbzROoxe.scheme+'://'+MPwXBVifFkcqTCtJlIgruHdbzROoxe.netloc+MPwXBVifFkcqTCtJlIgruHdbzROoxe.path
   MPwXBVifFkcqTCtJlIgruHdbzROoaK=MPwXBVifFkcqTCtJlIgruHdbzROoGL(urllib.parse.parse_qsl(MPwXBVifFkcqTCtJlIgruHdbzROoxe.query))
  except MPwXBVifFkcqTCtJlIgruHdbzROoGv as exception:
   MPwXBVifFkcqTCtJlIgruHdbzROoGp(exception)
   return '',{}
  return MPwXBVifFkcqTCtJlIgruHdbzROoaW,MPwXBVifFkcqTCtJlIgruHdbzROoaK
 def GetSupermultiUrl(MPwXBVifFkcqTCtJlIgruHdbzROoaS,sCode,sIndex='0'):
  try:
   MPwXBVifFkcqTCtJlIgruHdbzROoaW=MPwXBVifFkcqTCtJlIgruHdbzROoaS.API_DOMAIN+'/cf/supermultisections/'+sCode
   MPwXBVifFkcqTCtJlIgruHdbzROoaK=MPwXBVifFkcqTCtJlIgruHdbzROoaS.GetDefaultParams(login=MPwXBVifFkcqTCtJlIgruHdbzROoGy)
   MPwXBVifFkcqTCtJlIgruHdbzROoxS=MPwXBVifFkcqTCtJlIgruHdbzROoaS.callRequestCookies('Get',MPwXBVifFkcqTCtJlIgruHdbzROoaW,payload=MPwXBVifFkcqTCtJlIgruHdbzROoGU,params=MPwXBVifFkcqTCtJlIgruHdbzROoaK,headers=MPwXBVifFkcqTCtJlIgruHdbzROoGU,cookies=MPwXBVifFkcqTCtJlIgruHdbzROoGU)
   MPwXBVifFkcqTCtJlIgruHdbzROoxD=json.loads(MPwXBVifFkcqTCtJlIgruHdbzROoxS.text)
   MPwXBVifFkcqTCtJlIgruHdbzROoxU=MPwXBVifFkcqTCtJlIgruHdbzROoxD['multisectionlist'][MPwXBVifFkcqTCtJlIgruHdbzROoGs(sIndex)]['eventlist'][1]['url']
  except MPwXBVifFkcqTCtJlIgruHdbzROoGv as exception:
   MPwXBVifFkcqTCtJlIgruHdbzROoGp(exception)
   return ''
  return MPwXBVifFkcqTCtJlIgruHdbzROoxU
 def Get_LiveCatagory_List(MPwXBVifFkcqTCtJlIgruHdbzROoaS,sCode,sIndex='0'):
  MPwXBVifFkcqTCtJlIgruHdbzROoxy=[]
  MPwXBVifFkcqTCtJlIgruHdbzROoxK =MPwXBVifFkcqTCtJlIgruHdbzROoaS.GetSupermultiUrl(sCode,sIndex)
  (MPwXBVifFkcqTCtJlIgruHdbzROoaW,MPwXBVifFkcqTCtJlIgruHdbzROoaK)=MPwXBVifFkcqTCtJlIgruHdbzROoaS.Baseapi_Parse(MPwXBVifFkcqTCtJlIgruHdbzROoxK)
  if MPwXBVifFkcqTCtJlIgruHdbzROoaW=='':return MPwXBVifFkcqTCtJlIgruHdbzROoxy,''
  try:
   MPwXBVifFkcqTCtJlIgruHdbzROoaK.update(MPwXBVifFkcqTCtJlIgruHdbzROoaS.GetDefaultParams(login=MPwXBVifFkcqTCtJlIgruHdbzROoGy))
   MPwXBVifFkcqTCtJlIgruHdbzROoxS=MPwXBVifFkcqTCtJlIgruHdbzROoaS.callRequestCookies('Get',MPwXBVifFkcqTCtJlIgruHdbzROoaW,payload=MPwXBVifFkcqTCtJlIgruHdbzROoGU,params=MPwXBVifFkcqTCtJlIgruHdbzROoaK,headers=MPwXBVifFkcqTCtJlIgruHdbzROoGU,cookies=MPwXBVifFkcqTCtJlIgruHdbzROoGU)
   MPwXBVifFkcqTCtJlIgruHdbzROoxD=json.loads(MPwXBVifFkcqTCtJlIgruHdbzROoxS.text)
   if not('filter_item_list' in MPwXBVifFkcqTCtJlIgruHdbzROoxD['filter']['filterlist'][0]):return[],''
   MPwXBVifFkcqTCtJlIgruHdbzROoxn=MPwXBVifFkcqTCtJlIgruHdbzROoxD['filter']['filterlist'][0]['filter_item_list']
   for MPwXBVifFkcqTCtJlIgruHdbzROoxj in MPwXBVifFkcqTCtJlIgruHdbzROoxn:
    MPwXBVifFkcqTCtJlIgruHdbzROoxv={'title':MPwXBVifFkcqTCtJlIgruHdbzROoxj['title'],'genre':MPwXBVifFkcqTCtJlIgruHdbzROoxj['api_parameters'][MPwXBVifFkcqTCtJlIgruHdbzROoxj['api_parameters'].index('=')+1:]}
    MPwXBVifFkcqTCtJlIgruHdbzROoxy.append(MPwXBVifFkcqTCtJlIgruHdbzROoxv)
  except MPwXBVifFkcqTCtJlIgruHdbzROoGv as exception:
   MPwXBVifFkcqTCtJlIgruHdbzROoGp(exception)
   return[],''
  return MPwXBVifFkcqTCtJlIgruHdbzROoxy,MPwXBVifFkcqTCtJlIgruHdbzROoxK
 def Get_MainCatagory_List(MPwXBVifFkcqTCtJlIgruHdbzROoaS,sCode,sIndex='0'):
  MPwXBVifFkcqTCtJlIgruHdbzROoxy=[]
  MPwXBVifFkcqTCtJlIgruHdbzROoxK =MPwXBVifFkcqTCtJlIgruHdbzROoaS.GetSupermultiUrl(sCode,sIndex)
  (MPwXBVifFkcqTCtJlIgruHdbzROoaW,MPwXBVifFkcqTCtJlIgruHdbzROoaK)=MPwXBVifFkcqTCtJlIgruHdbzROoaS.Baseapi_Parse(MPwXBVifFkcqTCtJlIgruHdbzROoxK)
  if MPwXBVifFkcqTCtJlIgruHdbzROoaW=='':return MPwXBVifFkcqTCtJlIgruHdbzROoxy
  try:
   MPwXBVifFkcqTCtJlIgruHdbzROoaK.update(MPwXBVifFkcqTCtJlIgruHdbzROoaS.GetDefaultParams(login=MPwXBVifFkcqTCtJlIgruHdbzROoGy))
   MPwXBVifFkcqTCtJlIgruHdbzROoxS=MPwXBVifFkcqTCtJlIgruHdbzROoaS.callRequestCookies('Get',MPwXBVifFkcqTCtJlIgruHdbzROoaW,payload=MPwXBVifFkcqTCtJlIgruHdbzROoGU,params=MPwXBVifFkcqTCtJlIgruHdbzROoaK,headers=MPwXBVifFkcqTCtJlIgruHdbzROoGU,cookies=MPwXBVifFkcqTCtJlIgruHdbzROoGU)
   MPwXBVifFkcqTCtJlIgruHdbzROoxD=json.loads(MPwXBVifFkcqTCtJlIgruHdbzROoxS.text)
   if not('celllist' in MPwXBVifFkcqTCtJlIgruHdbzROoxD['band']):return[]
   MPwXBVifFkcqTCtJlIgruHdbzROoxn=MPwXBVifFkcqTCtJlIgruHdbzROoxD['band']['celllist']
   for MPwXBVifFkcqTCtJlIgruHdbzROoxj in MPwXBVifFkcqTCtJlIgruHdbzROoxn:
    MPwXBVifFkcqTCtJlIgruHdbzROoxp =MPwXBVifFkcqTCtJlIgruHdbzROoxj['event_list'][1]['url']
    (MPwXBVifFkcqTCtJlIgruHdbzROoxL,MPwXBVifFkcqTCtJlIgruHdbzROoxs)=MPwXBVifFkcqTCtJlIgruHdbzROoaS.Baseapi_Parse(MPwXBVifFkcqTCtJlIgruHdbzROoxp)
    MPwXBVifFkcqTCtJlIgruHdbzROoxv={'title':MPwXBVifFkcqTCtJlIgruHdbzROoxj['title_list'][0]['text'],'suburl':MPwXBVifFkcqTCtJlIgruHdbzROoxL,'subapi':MPwXBVifFkcqTCtJlIgruHdbzROoxs.get('api'),'subtype':'catagory' if MPwXBVifFkcqTCtJlIgruHdbzROoxs else 'supersection'}
    MPwXBVifFkcqTCtJlIgruHdbzROoxy.append(MPwXBVifFkcqTCtJlIgruHdbzROoxv)
  except MPwXBVifFkcqTCtJlIgruHdbzROoGv as exception:
   MPwXBVifFkcqTCtJlIgruHdbzROoGp(exception)
   return[]
  return MPwXBVifFkcqTCtJlIgruHdbzROoxy
 def Get_SuperMultiSection_List(MPwXBVifFkcqTCtJlIgruHdbzROoaS,subapi_text):
  MPwXBVifFkcqTCtJlIgruHdbzROoxy=[]
  MPwXBVifFkcqTCtJlIgruHdbzROoaK={}
  try:
   MPwXBVifFkcqTCtJlIgruHdbzROoxe =urllib.parse.urlsplit(subapi_text)
   if MPwXBVifFkcqTCtJlIgruHdbzROoxe.path.find('apis.wavve.com')>=0: 
    MPwXBVifFkcqTCtJlIgruHdbzROoaW=MPwXBVifFkcqTCtJlIgruHdbzROoaS.HTTPTAG+MPwXBVifFkcqTCtJlIgruHdbzROoxe.path 
    MPwXBVifFkcqTCtJlIgruHdbzROoaK=MPwXBVifFkcqTCtJlIgruHdbzROoGL(urllib.parse.parse_qsl(MPwXBVifFkcqTCtJlIgruHdbzROoxe.query))
   else:
    MPwXBVifFkcqTCtJlIgruHdbzROoaW=MPwXBVifFkcqTCtJlIgruHdbzROoaS.API_DOMAIN+'/cf'+MPwXBVifFkcqTCtJlIgruHdbzROoxe.path 
   MPwXBVifFkcqTCtJlIgruHdbzROoaW=MPwXBVifFkcqTCtJlIgruHdbzROoaW.replace('supermultisection/','supermultisections/')
  except MPwXBVifFkcqTCtJlIgruHdbzROoGv as exception:
   MPwXBVifFkcqTCtJlIgruHdbzROoGp(exception)
   return[]
  try:
   MPwXBVifFkcqTCtJlIgruHdbzROoaK.update(MPwXBVifFkcqTCtJlIgruHdbzROoaS.GetDefaultParams(login=MPwXBVifFkcqTCtJlIgruHdbzROoGy))
   MPwXBVifFkcqTCtJlIgruHdbzROoxS=MPwXBVifFkcqTCtJlIgruHdbzROoaS.callRequestCookies('Get',MPwXBVifFkcqTCtJlIgruHdbzROoaW,payload=MPwXBVifFkcqTCtJlIgruHdbzROoGU,params=MPwXBVifFkcqTCtJlIgruHdbzROoGU,headers=MPwXBVifFkcqTCtJlIgruHdbzROoGU,cookies=MPwXBVifFkcqTCtJlIgruHdbzROoGU)
   MPwXBVifFkcqTCtJlIgruHdbzROoxD=json.loads(MPwXBVifFkcqTCtJlIgruHdbzROoxS.text)
   if not('multisectionlist' in MPwXBVifFkcqTCtJlIgruHdbzROoxD):return[]
   MPwXBVifFkcqTCtJlIgruHdbzROoxn=MPwXBVifFkcqTCtJlIgruHdbzROoxD['multisectionlist']
   for MPwXBVifFkcqTCtJlIgruHdbzROoxj in MPwXBVifFkcqTCtJlIgruHdbzROoxn:
    MPwXBVifFkcqTCtJlIgruHdbzROoxh=MPwXBVifFkcqTCtJlIgruHdbzROoxj['title']
    if MPwXBVifFkcqTCtJlIgruHdbzROoGh(MPwXBVifFkcqTCtJlIgruHdbzROoxh)==0:continue
    if MPwXBVifFkcqTCtJlIgruHdbzROoxh=='minor':continue
    if re.search(u'베너',MPwXBVifFkcqTCtJlIgruHdbzROoxh):continue
    if re.search(u'배너',MPwXBVifFkcqTCtJlIgruHdbzROoxh):continue 
    if MPwXBVifFkcqTCtJlIgruHdbzROoxj['force_refresh']=='y':continue
    if MPwXBVifFkcqTCtJlIgruHdbzROoGh(MPwXBVifFkcqTCtJlIgruHdbzROoxj['eventlist'])>=3:
     MPwXBVifFkcqTCtJlIgruHdbzROoxs =MPwXBVifFkcqTCtJlIgruHdbzROoxj['eventlist'][2]['url']
    else:
     MPwXBVifFkcqTCtJlIgruHdbzROoxs =MPwXBVifFkcqTCtJlIgruHdbzROoxj['eventlist'][1]['url']
    MPwXBVifFkcqTCtJlIgruHdbzROoxQ=MPwXBVifFkcqTCtJlIgruHdbzROoxj['cell_type']
    if MPwXBVifFkcqTCtJlIgruHdbzROoxQ=='band_2':
     if MPwXBVifFkcqTCtJlIgruHdbzROoxs.find('channellist=')>=0:
      MPwXBVifFkcqTCtJlIgruHdbzROoxQ='band_live'
    MPwXBVifFkcqTCtJlIgruHdbzROoxv={'title':MPwXBVifFkcqTCtJlIgruHdbzROoaS.Get_ChangeText(MPwXBVifFkcqTCtJlIgruHdbzROoxh),'subapi':MPwXBVifFkcqTCtJlIgruHdbzROoxs,'cell_type':MPwXBVifFkcqTCtJlIgruHdbzROoxQ}
    MPwXBVifFkcqTCtJlIgruHdbzROoxy.append(MPwXBVifFkcqTCtJlIgruHdbzROoxv)
  except MPwXBVifFkcqTCtJlIgruHdbzROoGv as exception:
   MPwXBVifFkcqTCtJlIgruHdbzROoGp(exception)
   return[]
  return MPwXBVifFkcqTCtJlIgruHdbzROoxy
 def Get_BandLiveSection_List(MPwXBVifFkcqTCtJlIgruHdbzROoaS,MPwXBVifFkcqTCtJlIgruHdbzROoxK,page_int=1):
  MPwXBVifFkcqTCtJlIgruHdbzROoxA=[]
  MPwXBVifFkcqTCtJlIgruHdbzROoxW=MPwXBVifFkcqTCtJlIgruHdbzROoSY=1
  MPwXBVifFkcqTCtJlIgruHdbzROoSa=MPwXBVifFkcqTCtJlIgruHdbzROoGy
  try:
   (MPwXBVifFkcqTCtJlIgruHdbzROoaW,MPwXBVifFkcqTCtJlIgruHdbzROoaK)=MPwXBVifFkcqTCtJlIgruHdbzROoaS.Baseapi_Parse(MPwXBVifFkcqTCtJlIgruHdbzROoxK)
  except MPwXBVifFkcqTCtJlIgruHdbzROoGv as exception:
   MPwXBVifFkcqTCtJlIgruHdbzROoGp(exception)
   return[],MPwXBVifFkcqTCtJlIgruHdbzROoGy
  try:
   MPwXBVifFkcqTCtJlIgruHdbzROoaK['limit']=MPwXBVifFkcqTCtJlIgruHdbzROoaS.LIST_LIMIT
   MPwXBVifFkcqTCtJlIgruHdbzROoaK['offset']=MPwXBVifFkcqTCtJlIgruHdbzROoGj((page_int-1)*MPwXBVifFkcqTCtJlIgruHdbzROoaS.LIST_LIMIT)
   MPwXBVifFkcqTCtJlIgruHdbzROoaK.update(MPwXBVifFkcqTCtJlIgruHdbzROoaS.GetDefaultParams(login=MPwXBVifFkcqTCtJlIgruHdbzROoGy))
   MPwXBVifFkcqTCtJlIgruHdbzROoxS=MPwXBVifFkcqTCtJlIgruHdbzROoaS.callRequestCookies('Get',MPwXBVifFkcqTCtJlIgruHdbzROoaW,payload=MPwXBVifFkcqTCtJlIgruHdbzROoGU,params=MPwXBVifFkcqTCtJlIgruHdbzROoaK,headers=MPwXBVifFkcqTCtJlIgruHdbzROoGU,cookies=MPwXBVifFkcqTCtJlIgruHdbzROoGU)
   MPwXBVifFkcqTCtJlIgruHdbzROoxD=json.loads(MPwXBVifFkcqTCtJlIgruHdbzROoxS.text)
   if not('celllist' in MPwXBVifFkcqTCtJlIgruHdbzROoxD['cell_toplist']):return[],MPwXBVifFkcqTCtJlIgruHdbzROoGy
   MPwXBVifFkcqTCtJlIgruHdbzROoxn=MPwXBVifFkcqTCtJlIgruHdbzROoxD['cell_toplist']['celllist']
   for MPwXBVifFkcqTCtJlIgruHdbzROoxj in MPwXBVifFkcqTCtJlIgruHdbzROoxn:
    MPwXBVifFkcqTCtJlIgruHdbzROoSx =MPwXBVifFkcqTCtJlIgruHdbzROoxj['event_list'][1]['url']
    MPwXBVifFkcqTCtJlIgruHdbzROoSD=urllib.parse.urlsplit(MPwXBVifFkcqTCtJlIgruHdbzROoSx).query
    MPwXBVifFkcqTCtJlIgruHdbzROoSD=MPwXBVifFkcqTCtJlIgruHdbzROoGL(urllib.parse.parse_qsl(MPwXBVifFkcqTCtJlIgruHdbzROoSD))
    MPwXBVifFkcqTCtJlIgruHdbzROoSm='channelid'
    MPwXBVifFkcqTCtJlIgruHdbzROoSG=MPwXBVifFkcqTCtJlIgruHdbzROoSD[MPwXBVifFkcqTCtJlIgruHdbzROoSm]
    MPwXBVifFkcqTCtJlIgruHdbzROoxv={'studio':MPwXBVifFkcqTCtJlIgruHdbzROoxj['title_list'][0]['text'],'tvshowtitle':MPwXBVifFkcqTCtJlIgruHdbzROoaS.Get_ChangeText(MPwXBVifFkcqTCtJlIgruHdbzROoxj['title_list'][1]['text']),'channelid':MPwXBVifFkcqTCtJlIgruHdbzROoSG,'age':MPwXBVifFkcqTCtJlIgruHdbzROoxj.get('age'),'thumbnail':'https://%s'%MPwXBVifFkcqTCtJlIgruHdbzROoxj.get('thumbnail')}
    MPwXBVifFkcqTCtJlIgruHdbzROoxA.append(MPwXBVifFkcqTCtJlIgruHdbzROoxv)
   MPwXBVifFkcqTCtJlIgruHdbzROoxW=MPwXBVifFkcqTCtJlIgruHdbzROoGs(MPwXBVifFkcqTCtJlIgruHdbzROoxD['cell_toplist']['pagecount'])
   if MPwXBVifFkcqTCtJlIgruHdbzROoxD['cell_toplist']['count']:MPwXBVifFkcqTCtJlIgruHdbzROoSY =MPwXBVifFkcqTCtJlIgruHdbzROoGs(MPwXBVifFkcqTCtJlIgruHdbzROoxD['cell_toplist']['count'])
   else:MPwXBVifFkcqTCtJlIgruHdbzROoSY=MPwXBVifFkcqTCtJlIgruHdbzROoaS.LIST_LIMIT*page_int
   MPwXBVifFkcqTCtJlIgruHdbzROoSa=MPwXBVifFkcqTCtJlIgruHdbzROoxW>MPwXBVifFkcqTCtJlIgruHdbzROoSY
  except MPwXBVifFkcqTCtJlIgruHdbzROoGv as exception:
   MPwXBVifFkcqTCtJlIgruHdbzROoGp(exception)
   return[],MPwXBVifFkcqTCtJlIgruHdbzROoGy
  return MPwXBVifFkcqTCtJlIgruHdbzROoxA,MPwXBVifFkcqTCtJlIgruHdbzROoSa
 def Get_Band2Section_List(MPwXBVifFkcqTCtJlIgruHdbzROoaS,MPwXBVifFkcqTCtJlIgruHdbzROoxK,page_int=1):
  MPwXBVifFkcqTCtJlIgruHdbzROoSE=[]
  MPwXBVifFkcqTCtJlIgruHdbzROoxW=MPwXBVifFkcqTCtJlIgruHdbzROoSY=1
  MPwXBVifFkcqTCtJlIgruHdbzROoSa=MPwXBVifFkcqTCtJlIgruHdbzROoGy
  try:
   (MPwXBVifFkcqTCtJlIgruHdbzROoaW,MPwXBVifFkcqTCtJlIgruHdbzROoaK)=MPwXBVifFkcqTCtJlIgruHdbzROoaS.Baseapi_Parse(MPwXBVifFkcqTCtJlIgruHdbzROoxK)
  except MPwXBVifFkcqTCtJlIgruHdbzROoGv as exception:
   MPwXBVifFkcqTCtJlIgruHdbzROoGp(exception)
   return[],MPwXBVifFkcqTCtJlIgruHdbzROoGy
  try:
   MPwXBVifFkcqTCtJlIgruHdbzROoaK['came'] ='BandView'
   MPwXBVifFkcqTCtJlIgruHdbzROoaK['limit']=MPwXBVifFkcqTCtJlIgruHdbzROoaS.LIST_LIMIT
   MPwXBVifFkcqTCtJlIgruHdbzROoaK['offset']=MPwXBVifFkcqTCtJlIgruHdbzROoGj((page_int-1)*MPwXBVifFkcqTCtJlIgruHdbzROoaS.LIST_LIMIT)
   MPwXBVifFkcqTCtJlIgruHdbzROoaK.update(MPwXBVifFkcqTCtJlIgruHdbzROoaS.GetDefaultParams(login=MPwXBVifFkcqTCtJlIgruHdbzROoGy))
   MPwXBVifFkcqTCtJlIgruHdbzROoxS=MPwXBVifFkcqTCtJlIgruHdbzROoaS.callRequestCookies('Get',MPwXBVifFkcqTCtJlIgruHdbzROoaW,payload=MPwXBVifFkcqTCtJlIgruHdbzROoGU,params=MPwXBVifFkcqTCtJlIgruHdbzROoaK,headers=MPwXBVifFkcqTCtJlIgruHdbzROoGU,cookies=MPwXBVifFkcqTCtJlIgruHdbzROoGU)
   MPwXBVifFkcqTCtJlIgruHdbzROoxD=json.loads(MPwXBVifFkcqTCtJlIgruHdbzROoxS.text)
   if not('celllist' in MPwXBVifFkcqTCtJlIgruHdbzROoxD['cell_toplist']):return[],MPwXBVifFkcqTCtJlIgruHdbzROoGy
   MPwXBVifFkcqTCtJlIgruHdbzROoxn=MPwXBVifFkcqTCtJlIgruHdbzROoxD['cell_toplist']['celllist']
   for MPwXBVifFkcqTCtJlIgruHdbzROoxj in MPwXBVifFkcqTCtJlIgruHdbzROoxn:
    MPwXBVifFkcqTCtJlIgruHdbzROoSx =MPwXBVifFkcqTCtJlIgruHdbzROoxj['event_list'][1]['url']
    MPwXBVifFkcqTCtJlIgruHdbzROoSD=urllib.parse.urlsplit(MPwXBVifFkcqTCtJlIgruHdbzROoSx).query
    MPwXBVifFkcqTCtJlIgruHdbzROoSD=MPwXBVifFkcqTCtJlIgruHdbzROoGL(urllib.parse.parse_qsl(MPwXBVifFkcqTCtJlIgruHdbzROoSD))
    MPwXBVifFkcqTCtJlIgruHdbzROoSm='contentid'
    MPwXBVifFkcqTCtJlIgruHdbzROoSG=MPwXBVifFkcqTCtJlIgruHdbzROoSD[MPwXBVifFkcqTCtJlIgruHdbzROoSm]
    MPwXBVifFkcqTCtJlIgruHdbzROoxv={'programtitle':MPwXBVifFkcqTCtJlIgruHdbzROoxj['title_list'][0]['text'],'episodetitle':MPwXBVifFkcqTCtJlIgruHdbzROoaS.Get_ChangeText(MPwXBVifFkcqTCtJlIgruHdbzROoxj['title_list'][1]['text']),'age':MPwXBVifFkcqTCtJlIgruHdbzROoxj.get('age'),'thumbnail':MPwXBVifFkcqTCtJlIgruHdbzROoaS.HTTPTAG+MPwXBVifFkcqTCtJlIgruHdbzROoxj.get('thumbnail'),'vidtype':MPwXBVifFkcqTCtJlIgruHdbzROoSm,'videoid':MPwXBVifFkcqTCtJlIgruHdbzROoSG}
    MPwXBVifFkcqTCtJlIgruHdbzROoSE.append(MPwXBVifFkcqTCtJlIgruHdbzROoxv)
   MPwXBVifFkcqTCtJlIgruHdbzROoxW=MPwXBVifFkcqTCtJlIgruHdbzROoGs(MPwXBVifFkcqTCtJlIgruHdbzROoxD['cell_toplist']['pagecount'])
   if MPwXBVifFkcqTCtJlIgruHdbzROoxD['cell_toplist']['count']:MPwXBVifFkcqTCtJlIgruHdbzROoSY =MPwXBVifFkcqTCtJlIgruHdbzROoGs(MPwXBVifFkcqTCtJlIgruHdbzROoxD['cell_toplist']['count'])
   else:MPwXBVifFkcqTCtJlIgruHdbzROoSY=MPwXBVifFkcqTCtJlIgruHdbzROoaS.LIST_LIMIT*page_int
   MPwXBVifFkcqTCtJlIgruHdbzROoSa=MPwXBVifFkcqTCtJlIgruHdbzROoxW>MPwXBVifFkcqTCtJlIgruHdbzROoSY
  except MPwXBVifFkcqTCtJlIgruHdbzROoGv as exception:
   MPwXBVifFkcqTCtJlIgruHdbzROoGp(exception)
   return[],MPwXBVifFkcqTCtJlIgruHdbzROoGy
  return MPwXBVifFkcqTCtJlIgruHdbzROoSE,MPwXBVifFkcqTCtJlIgruHdbzROoSa
 def Get_Program_List(MPwXBVifFkcqTCtJlIgruHdbzROoaS,MPwXBVifFkcqTCtJlIgruHdbzROoxK,page_int=1,orderby='-'):
  MPwXBVifFkcqTCtJlIgruHdbzROoSe=[]
  MPwXBVifFkcqTCtJlIgruHdbzROoxW=MPwXBVifFkcqTCtJlIgruHdbzROoSY=1
  MPwXBVifFkcqTCtJlIgruHdbzROoSa=MPwXBVifFkcqTCtJlIgruHdbzROoGy
  (MPwXBVifFkcqTCtJlIgruHdbzROoaW,MPwXBVifFkcqTCtJlIgruHdbzROoaK)=MPwXBVifFkcqTCtJlIgruHdbzROoaS.Baseapi_Parse(MPwXBVifFkcqTCtJlIgruHdbzROoxK)
  if MPwXBVifFkcqTCtJlIgruHdbzROoaW=='':return MPwXBVifFkcqTCtJlIgruHdbzROoSe,MPwXBVifFkcqTCtJlIgruHdbzROoSa
  try:
   MPwXBVifFkcqTCtJlIgruHdbzROoaK['limit'] =MPwXBVifFkcqTCtJlIgruHdbzROoaS.LIST_LIMIT
   MPwXBVifFkcqTCtJlIgruHdbzROoaK['offset']=MPwXBVifFkcqTCtJlIgruHdbzROoGj((page_int-1)*MPwXBVifFkcqTCtJlIgruHdbzROoaS.LIST_LIMIT)
   MPwXBVifFkcqTCtJlIgruHdbzROoaK['page'] =MPwXBVifFkcqTCtJlIgruHdbzROoGj(page_int)
   if MPwXBVifFkcqTCtJlIgruHdbzROoaK.get('orderby')!='' and MPwXBVifFkcqTCtJlIgruHdbzROoaK.get('orderby')!='regdatefirst' and orderby!='-':
    MPwXBVifFkcqTCtJlIgruHdbzROoaK['orderby']=orderby 
   MPwXBVifFkcqTCtJlIgruHdbzROoaK.update(MPwXBVifFkcqTCtJlIgruHdbzROoaS.GetDefaultParams(login=MPwXBVifFkcqTCtJlIgruHdbzROoGy))
   MPwXBVifFkcqTCtJlIgruHdbzROoxS=MPwXBVifFkcqTCtJlIgruHdbzROoaS.callRequestCookies('Get',MPwXBVifFkcqTCtJlIgruHdbzROoaW,payload=MPwXBVifFkcqTCtJlIgruHdbzROoGU,params=MPwXBVifFkcqTCtJlIgruHdbzROoaK,headers=MPwXBVifFkcqTCtJlIgruHdbzROoGU,cookies=MPwXBVifFkcqTCtJlIgruHdbzROoGU)
   MPwXBVifFkcqTCtJlIgruHdbzROoxD=json.loads(MPwXBVifFkcqTCtJlIgruHdbzROoxS.text)
   if MPwXBVifFkcqTCtJlIgruHdbzROoxK.find('instantplay')>=0:
    if not('celllist' in MPwXBVifFkcqTCtJlIgruHdbzROoxD['band']):return MPwXBVifFkcqTCtJlIgruHdbzROoSe,MPwXBVifFkcqTCtJlIgruHdbzROoSa
    MPwXBVifFkcqTCtJlIgruHdbzROoxn=MPwXBVifFkcqTCtJlIgruHdbzROoxD['band']['celllist']
   else:
    if not('celllist' in MPwXBVifFkcqTCtJlIgruHdbzROoxD['cell_toplist']):return MPwXBVifFkcqTCtJlIgruHdbzROoSe,MPwXBVifFkcqTCtJlIgruHdbzROoSa
    MPwXBVifFkcqTCtJlIgruHdbzROoxn=MPwXBVifFkcqTCtJlIgruHdbzROoxD['cell_toplist']['celllist']
   for MPwXBVifFkcqTCtJlIgruHdbzROoxj in MPwXBVifFkcqTCtJlIgruHdbzROoxn:
    for MPwXBVifFkcqTCtJlIgruHdbzROoSU in MPwXBVifFkcqTCtJlIgruHdbzROoxj['event_list']:
     if MPwXBVifFkcqTCtJlIgruHdbzROoSU.get('type')=='on-navigation':
      MPwXBVifFkcqTCtJlIgruHdbzROoSx =MPwXBVifFkcqTCtJlIgruHdbzROoSU['url']
    MPwXBVifFkcqTCtJlIgruHdbzROoSD=urllib.parse.urlsplit(MPwXBVifFkcqTCtJlIgruHdbzROoSx).query
    MPwXBVifFkcqTCtJlIgruHdbzROoSm=MPwXBVifFkcqTCtJlIgruHdbzROoSD[0:MPwXBVifFkcqTCtJlIgruHdbzROoSD.find('=')]
    MPwXBVifFkcqTCtJlIgruHdbzROoSG=MPwXBVifFkcqTCtJlIgruHdbzROoSD[MPwXBVifFkcqTCtJlIgruHdbzROoSD.find('=')+1:]
    MPwXBVifFkcqTCtJlIgruHdbzROoxv={'title':MPwXBVifFkcqTCtJlIgruHdbzROoxj['title_list'][0]['text'],'age':MPwXBVifFkcqTCtJlIgruHdbzROoxj['age'],'thumbnail':'https://%s'%MPwXBVifFkcqTCtJlIgruHdbzROoxj.get('thumbnail'),'videoid':MPwXBVifFkcqTCtJlIgruHdbzROoSG,'vidtype':MPwXBVifFkcqTCtJlIgruHdbzROoSm}
    MPwXBVifFkcqTCtJlIgruHdbzROoSe.append(MPwXBVifFkcqTCtJlIgruHdbzROoxv)
   if MPwXBVifFkcqTCtJlIgruHdbzROoxK.find('instantplay')<0:
    MPwXBVifFkcqTCtJlIgruHdbzROoxW=MPwXBVifFkcqTCtJlIgruHdbzROoGs(MPwXBVifFkcqTCtJlIgruHdbzROoxD['cell_toplist']['pagecount'])
    if MPwXBVifFkcqTCtJlIgruHdbzROoxD['cell_toplist']['count']:MPwXBVifFkcqTCtJlIgruHdbzROoSY =MPwXBVifFkcqTCtJlIgruHdbzROoGs(MPwXBVifFkcqTCtJlIgruHdbzROoxD['cell_toplist']['count'])
    else:MPwXBVifFkcqTCtJlIgruHdbzROoSY=MPwXBVifFkcqTCtJlIgruHdbzROoaS.LIST_LIMIT*page_int
    MPwXBVifFkcqTCtJlIgruHdbzROoSa=MPwXBVifFkcqTCtJlIgruHdbzROoxW>MPwXBVifFkcqTCtJlIgruHdbzROoSY
  except MPwXBVifFkcqTCtJlIgruHdbzROoGv as exception:
   MPwXBVifFkcqTCtJlIgruHdbzROoGp(exception)
   return[],MPwXBVifFkcqTCtJlIgruHdbzROoGy
  return MPwXBVifFkcqTCtJlIgruHdbzROoSe,MPwXBVifFkcqTCtJlIgruHdbzROoSa
 def Get_Movie_List(MPwXBVifFkcqTCtJlIgruHdbzROoaS,MPwXBVifFkcqTCtJlIgruHdbzROoxK,page_int=1,orderby='-'):
  MPwXBVifFkcqTCtJlIgruHdbzROoSy=[]
  MPwXBVifFkcqTCtJlIgruHdbzROoxW=MPwXBVifFkcqTCtJlIgruHdbzROoSY=1
  MPwXBVifFkcqTCtJlIgruHdbzROoSa=MPwXBVifFkcqTCtJlIgruHdbzROoGy
  (MPwXBVifFkcqTCtJlIgruHdbzROoaW,MPwXBVifFkcqTCtJlIgruHdbzROoaK)=MPwXBVifFkcqTCtJlIgruHdbzROoaS.Baseapi_Parse(MPwXBVifFkcqTCtJlIgruHdbzROoxK)
  if MPwXBVifFkcqTCtJlIgruHdbzROoaW=='':return MPwXBVifFkcqTCtJlIgruHdbzROoSy,MPwXBVifFkcqTCtJlIgruHdbzROoSa
  try:
   MPwXBVifFkcqTCtJlIgruHdbzROoaK['limit']=MPwXBVifFkcqTCtJlIgruHdbzROoaS.MV_LIMIT
   MPwXBVifFkcqTCtJlIgruHdbzROoaK['offset']=MPwXBVifFkcqTCtJlIgruHdbzROoGj((page_int-1)*MPwXBVifFkcqTCtJlIgruHdbzROoaS.MV_LIMIT)
   if MPwXBVifFkcqTCtJlIgruHdbzROoaK.get('orderby')!='' and MPwXBVifFkcqTCtJlIgruHdbzROoaK.get('orderby')!='regdatefirst' and orderby!='-':
    MPwXBVifFkcqTCtJlIgruHdbzROoaK['orderby']=orderby 
   MPwXBVifFkcqTCtJlIgruHdbzROoaK.update(MPwXBVifFkcqTCtJlIgruHdbzROoaS.GetDefaultParams(login=MPwXBVifFkcqTCtJlIgruHdbzROoGy))
   MPwXBVifFkcqTCtJlIgruHdbzROoxS=MPwXBVifFkcqTCtJlIgruHdbzROoaS.callRequestCookies('Get',MPwXBVifFkcqTCtJlIgruHdbzROoaW,payload=MPwXBVifFkcqTCtJlIgruHdbzROoGU,params=MPwXBVifFkcqTCtJlIgruHdbzROoaK,headers=MPwXBVifFkcqTCtJlIgruHdbzROoGU,cookies=MPwXBVifFkcqTCtJlIgruHdbzROoGU)
   MPwXBVifFkcqTCtJlIgruHdbzROoxD=json.loads(MPwXBVifFkcqTCtJlIgruHdbzROoxS.text)
   if not('celllist' in MPwXBVifFkcqTCtJlIgruHdbzROoxD['cell_toplist']):return MPwXBVifFkcqTCtJlIgruHdbzROoSy,MPwXBVifFkcqTCtJlIgruHdbzROoSa
   MPwXBVifFkcqTCtJlIgruHdbzROoxn=MPwXBVifFkcqTCtJlIgruHdbzROoxD['cell_toplist']['celllist']
   for MPwXBVifFkcqTCtJlIgruHdbzROoxj in MPwXBVifFkcqTCtJlIgruHdbzROoxn:
    MPwXBVifFkcqTCtJlIgruHdbzROoSx =MPwXBVifFkcqTCtJlIgruHdbzROoxj['event_list'][1]['url']
    MPwXBVifFkcqTCtJlIgruHdbzROoSD=urllib.parse.urlsplit(MPwXBVifFkcqTCtJlIgruHdbzROoSx).query
    MPwXBVifFkcqTCtJlIgruHdbzROoSm=MPwXBVifFkcqTCtJlIgruHdbzROoSD[0:MPwXBVifFkcqTCtJlIgruHdbzROoSD.find('=')]
    MPwXBVifFkcqTCtJlIgruHdbzROoSG=MPwXBVifFkcqTCtJlIgruHdbzROoSD[MPwXBVifFkcqTCtJlIgruHdbzROoSD.find('=')+1:]
    MPwXBVifFkcqTCtJlIgruHdbzROoxv={'title':MPwXBVifFkcqTCtJlIgruHdbzROoxj['title_list'][0]['text'],'age':MPwXBVifFkcqTCtJlIgruHdbzROoxj['age'],'thumbnail':'https://%s'%MPwXBVifFkcqTCtJlIgruHdbzROoxj.get('thumbnail'),'videoid':MPwXBVifFkcqTCtJlIgruHdbzROoSG,'vidtype':MPwXBVifFkcqTCtJlIgruHdbzROoSm}
    MPwXBVifFkcqTCtJlIgruHdbzROoSy.append(MPwXBVifFkcqTCtJlIgruHdbzROoxv)
   MPwXBVifFkcqTCtJlIgruHdbzROoxW=MPwXBVifFkcqTCtJlIgruHdbzROoGs(MPwXBVifFkcqTCtJlIgruHdbzROoxD['cell_toplist']['pagecount'])
   if MPwXBVifFkcqTCtJlIgruHdbzROoxD['cell_toplist']['count']:MPwXBVifFkcqTCtJlIgruHdbzROoSY =MPwXBVifFkcqTCtJlIgruHdbzROoGs(MPwXBVifFkcqTCtJlIgruHdbzROoxD['cell_toplist']['count'])
   else:MPwXBVifFkcqTCtJlIgruHdbzROoSY=MPwXBVifFkcqTCtJlIgruHdbzROoaS.MV_LIMIT*page_int
   MPwXBVifFkcqTCtJlIgruHdbzROoSa=MPwXBVifFkcqTCtJlIgruHdbzROoxW>MPwXBVifFkcqTCtJlIgruHdbzROoSY
  except MPwXBVifFkcqTCtJlIgruHdbzROoGv as exception:
   MPwXBVifFkcqTCtJlIgruHdbzROoGp(exception)
   return[],MPwXBVifFkcqTCtJlIgruHdbzROoGy
  return MPwXBVifFkcqTCtJlIgruHdbzROoSy,MPwXBVifFkcqTCtJlIgruHdbzROoSa
 def ProgramidToContentid(MPwXBVifFkcqTCtJlIgruHdbzROoaS,MPwXBVifFkcqTCtJlIgruHdbzROoSn):
  MPwXBVifFkcqTCtJlIgruHdbzROoSK=''
  try:
   MPwXBVifFkcqTCtJlIgruHdbzROoaW =MPwXBVifFkcqTCtJlIgruHdbzROoaS.API_DOMAIN+'/vod/programs-contentid/'+MPwXBVifFkcqTCtJlIgruHdbzROoSn
   MPwXBVifFkcqTCtJlIgruHdbzROoaK=MPwXBVifFkcqTCtJlIgruHdbzROoaS.GetDefaultParams(login=MPwXBVifFkcqTCtJlIgruHdbzROoGy)
   MPwXBVifFkcqTCtJlIgruHdbzROoxS=MPwXBVifFkcqTCtJlIgruHdbzROoaS.callRequestCookies('Get',MPwXBVifFkcqTCtJlIgruHdbzROoaW,payload=MPwXBVifFkcqTCtJlIgruHdbzROoGU,params=MPwXBVifFkcqTCtJlIgruHdbzROoaK,headers=MPwXBVifFkcqTCtJlIgruHdbzROoGU,cookies=MPwXBVifFkcqTCtJlIgruHdbzROoGU)
   MPwXBVifFkcqTCtJlIgruHdbzROoSN=json.loads(MPwXBVifFkcqTCtJlIgruHdbzROoxS.text)
   if not('contentid' in MPwXBVifFkcqTCtJlIgruHdbzROoSN):return MPwXBVifFkcqTCtJlIgruHdbzROoSK 
   MPwXBVifFkcqTCtJlIgruHdbzROoSK=MPwXBVifFkcqTCtJlIgruHdbzROoSN['contentid']
  except MPwXBVifFkcqTCtJlIgruHdbzROoGv as exception:
   MPwXBVifFkcqTCtJlIgruHdbzROoGp(exception)
  return MPwXBVifFkcqTCtJlIgruHdbzROoSK
 def ContentidToSeasonid(MPwXBVifFkcqTCtJlIgruHdbzROoaS,MPwXBVifFkcqTCtJlIgruHdbzROoSK):
  MPwXBVifFkcqTCtJlIgruHdbzROoSn=''
  try:
   MPwXBVifFkcqTCtJlIgruHdbzROoaW =MPwXBVifFkcqTCtJlIgruHdbzROoaS.API_DOMAIN+'/fz/vod/contents/'+MPwXBVifFkcqTCtJlIgruHdbzROoSK
   MPwXBVifFkcqTCtJlIgruHdbzROoaK=MPwXBVifFkcqTCtJlIgruHdbzROoaS.GetDefaultParams(login=MPwXBVifFkcqTCtJlIgruHdbzROoGy)
   MPwXBVifFkcqTCtJlIgruHdbzROoxS=MPwXBVifFkcqTCtJlIgruHdbzROoaS.callRequestCookies('Get',MPwXBVifFkcqTCtJlIgruHdbzROoaW,payload=MPwXBVifFkcqTCtJlIgruHdbzROoGU,params=MPwXBVifFkcqTCtJlIgruHdbzROoaK,headers=MPwXBVifFkcqTCtJlIgruHdbzROoGU,cookies=MPwXBVifFkcqTCtJlIgruHdbzROoGU)
   MPwXBVifFkcqTCtJlIgruHdbzROoSN=json.loads(MPwXBVifFkcqTCtJlIgruHdbzROoxS.text)
   if not('programid' in MPwXBVifFkcqTCtJlIgruHdbzROoSN):return MPwXBVifFkcqTCtJlIgruHdbzROoSn 
   MPwXBVifFkcqTCtJlIgruHdbzROoSn=MPwXBVifFkcqTCtJlIgruHdbzROoSN['programid']
  except MPwXBVifFkcqTCtJlIgruHdbzROoGv as exception:
   MPwXBVifFkcqTCtJlIgruHdbzROoGp(exception)
  return MPwXBVifFkcqTCtJlIgruHdbzROoSn
 def GetProgramInfo(MPwXBVifFkcqTCtJlIgruHdbzROoaS,MPwXBVifFkcqTCtJlIgruHdbzROoSK):
  MPwXBVifFkcqTCtJlIgruHdbzROoSj={}
  try:
   MPwXBVifFkcqTCtJlIgruHdbzROoaW=MPwXBVifFkcqTCtJlIgruHdbzROoaS.API_DOMAIN+'/fz/vod/contents/'+MPwXBVifFkcqTCtJlIgruHdbzROoSK
   MPwXBVifFkcqTCtJlIgruHdbzROoaK=MPwXBVifFkcqTCtJlIgruHdbzROoaS.GetDefaultParams(login=MPwXBVifFkcqTCtJlIgruHdbzROoGy)
   MPwXBVifFkcqTCtJlIgruHdbzROoxS=MPwXBVifFkcqTCtJlIgruHdbzROoaS.callRequestCookies('Get',MPwXBVifFkcqTCtJlIgruHdbzROoaW,payload=MPwXBVifFkcqTCtJlIgruHdbzROoGU,params=MPwXBVifFkcqTCtJlIgruHdbzROoaK,headers=MPwXBVifFkcqTCtJlIgruHdbzROoGU,cookies=MPwXBVifFkcqTCtJlIgruHdbzROoGU)
   MPwXBVifFkcqTCtJlIgruHdbzROoSN=json.loads(MPwXBVifFkcqTCtJlIgruHdbzROoxS.text)
   MPwXBVifFkcqTCtJlIgruHdbzROoSv=img_fanart=MPwXBVifFkcqTCtJlIgruHdbzROoSp=''
   if MPwXBVifFkcqTCtJlIgruHdbzROoSN.get('programposterimage')!='':MPwXBVifFkcqTCtJlIgruHdbzROoSv =MPwXBVifFkcqTCtJlIgruHdbzROoaS.HTTPTAG+MPwXBVifFkcqTCtJlIgruHdbzROoSN.get('programposterimage')
   if MPwXBVifFkcqTCtJlIgruHdbzROoSN.get('programimage') !='':img_fanart =MPwXBVifFkcqTCtJlIgruHdbzROoaS.HTTPTAG+MPwXBVifFkcqTCtJlIgruHdbzROoSN.get('programimage')
   if MPwXBVifFkcqTCtJlIgruHdbzROoSN.get('programcircleimage')!='':MPwXBVifFkcqTCtJlIgruHdbzROoSp=MPwXBVifFkcqTCtJlIgruHdbzROoaS.HTTPTAG+MPwXBVifFkcqTCtJlIgruHdbzROoSN.get('programcircleimage')
   if 'poster_default' in MPwXBVifFkcqTCtJlIgruHdbzROoSv:
    MPwXBVifFkcqTCtJlIgruHdbzROoSv =img_fanart
    MPwXBVifFkcqTCtJlIgruHdbzROoSp=''
   MPwXBVifFkcqTCtJlIgruHdbzROoSj={'imgPoster':MPwXBVifFkcqTCtJlIgruHdbzROoSv,'imgFanart':img_fanart,'imgClearlogo':MPwXBVifFkcqTCtJlIgruHdbzROoSp,'programtitle':MPwXBVifFkcqTCtJlIgruHdbzROoSN.get('programtitle'),'programid':MPwXBVifFkcqTCtJlIgruHdbzROoSN.get('programid'),'synopsis':MPwXBVifFkcqTCtJlIgruHdbzROoSN.get('programsynopsis').replace('<br>','\n'),}
  except MPwXBVifFkcqTCtJlIgruHdbzROoGv as exception:
   MPwXBVifFkcqTCtJlIgruHdbzROoGp(exception)
  return MPwXBVifFkcqTCtJlIgruHdbzROoSj
 def Get_Season_List(MPwXBVifFkcqTCtJlIgruHdbzROoaS,seasonid):
  MPwXBVifFkcqTCtJlIgruHdbzROoSL=[]
  MPwXBVifFkcqTCtJlIgruHdbzROoSK=MPwXBVifFkcqTCtJlIgruHdbzROoaS.ProgramidToContentid(seasonid)
  MPwXBVifFkcqTCtJlIgruHdbzROoSs=MPwXBVifFkcqTCtJlIgruHdbzROoaS.GetProgramInfo(MPwXBVifFkcqTCtJlIgruHdbzROoSK)
  MPwXBVifFkcqTCtJlIgruHdbzROoSh={'poster':MPwXBVifFkcqTCtJlIgruHdbzROoSs.get('imgPoster'),'fanart':MPwXBVifFkcqTCtJlIgruHdbzROoSs.get('imgFanart'),'clearlogo':MPwXBVifFkcqTCtJlIgruHdbzROoSs.get('imgClearlogo'),}
  try:
   MPwXBVifFkcqTCtJlIgruHdbzROoaW=MPwXBVifFkcqTCtJlIgruHdbzROoaS.API_DOMAIN+'/fz/vod/programs-contents/'+seasonid
   MPwXBVifFkcqTCtJlIgruHdbzROoaK={'limit':'10','offset':'0','orderby':'new',}
   MPwXBVifFkcqTCtJlIgruHdbzROoaK.update(MPwXBVifFkcqTCtJlIgruHdbzROoaS.GetDefaultParams(login=MPwXBVifFkcqTCtJlIgruHdbzROoGy))
   MPwXBVifFkcqTCtJlIgruHdbzROoxS=MPwXBVifFkcqTCtJlIgruHdbzROoaS.callRequestCookies('Get',MPwXBVifFkcqTCtJlIgruHdbzROoaW,payload=MPwXBVifFkcqTCtJlIgruHdbzROoGU,params=MPwXBVifFkcqTCtJlIgruHdbzROoaK,headers=MPwXBVifFkcqTCtJlIgruHdbzROoGU,cookies=MPwXBVifFkcqTCtJlIgruHdbzROoGU)
   MPwXBVifFkcqTCtJlIgruHdbzROoxD=json.loads(MPwXBVifFkcqTCtJlIgruHdbzROoxS.text)
   for MPwXBVifFkcqTCtJlIgruHdbzROoSQ in MPwXBVifFkcqTCtJlIgruHdbzROoxD['filter']['filterlist'][0]['filter_item_list']:
    MPwXBVifFkcqTCtJlIgruHdbzROoxv={'season_Nm':MPwXBVifFkcqTCtJlIgruHdbzROoSQ.get('title'),'season_Id':MPwXBVifFkcqTCtJlIgruHdbzROoSQ.get('api_path'),'thumbnail':MPwXBVifFkcqTCtJlIgruHdbzROoSh,'programNm':MPwXBVifFkcqTCtJlIgruHdbzROoSs.get('programtitle'),'synopsis':MPwXBVifFkcqTCtJlIgruHdbzROoSs.get('synopsis'),}
    MPwXBVifFkcqTCtJlIgruHdbzROoSL.append(MPwXBVifFkcqTCtJlIgruHdbzROoxv)
  except MPwXBVifFkcqTCtJlIgruHdbzROoGv as exception:
   MPwXBVifFkcqTCtJlIgruHdbzROoGp(exception)
   return[]
  return MPwXBVifFkcqTCtJlIgruHdbzROoSL
 def Get_Episode_List(MPwXBVifFkcqTCtJlIgruHdbzROoaS,seasionid,page_int=1,orderby='desc'):
  MPwXBVifFkcqTCtJlIgruHdbzROoSA=[]
  MPwXBVifFkcqTCtJlIgruHdbzROoxW=MPwXBVifFkcqTCtJlIgruHdbzROoSY=1
  MPwXBVifFkcqTCtJlIgruHdbzROoSa=MPwXBVifFkcqTCtJlIgruHdbzROoGy
  MPwXBVifFkcqTCtJlIgruHdbzROoSs={}
  MPwXBVifFkcqTCtJlIgruHdbzROoSK=MPwXBVifFkcqTCtJlIgruHdbzROoaS.ProgramidToContentid(seasionid)
  MPwXBVifFkcqTCtJlIgruHdbzROoSs=MPwXBVifFkcqTCtJlIgruHdbzROoaS.GetProgramInfo(MPwXBVifFkcqTCtJlIgruHdbzROoSK)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   MPwXBVifFkcqTCtJlIgruHdbzROoaW=MPwXBVifFkcqTCtJlIgruHdbzROoaS.API_DOMAIN+'/fz/vod/programs-contents/'+seasionid
   MPwXBVifFkcqTCtJlIgruHdbzROoaK={'limit':MPwXBVifFkcqTCtJlIgruHdbzROoaS.EP_LIMIT,'offset':MPwXBVifFkcqTCtJlIgruHdbzROoGj((page_int-1)*MPwXBVifFkcqTCtJlIgruHdbzROoaS.EP_LIMIT),'orderby':orderby,}
   MPwXBVifFkcqTCtJlIgruHdbzROoaK.update(MPwXBVifFkcqTCtJlIgruHdbzROoaS.GetDefaultParams(login=MPwXBVifFkcqTCtJlIgruHdbzROoGy))
   MPwXBVifFkcqTCtJlIgruHdbzROoxS=MPwXBVifFkcqTCtJlIgruHdbzROoaS.callRequestCookies('Get',MPwXBVifFkcqTCtJlIgruHdbzROoaW,payload=MPwXBVifFkcqTCtJlIgruHdbzROoGU,params=MPwXBVifFkcqTCtJlIgruHdbzROoaK,headers=MPwXBVifFkcqTCtJlIgruHdbzROoGU,cookies=MPwXBVifFkcqTCtJlIgruHdbzROoGU)
   MPwXBVifFkcqTCtJlIgruHdbzROoxD=json.loads(MPwXBVifFkcqTCtJlIgruHdbzROoxS.text)
   MPwXBVifFkcqTCtJlIgruHdbzROoxn=MPwXBVifFkcqTCtJlIgruHdbzROoxD['cell_toplist']['celllist']
   for MPwXBVifFkcqTCtJlIgruHdbzROoxj in MPwXBVifFkcqTCtJlIgruHdbzROoxn:
    MPwXBVifFkcqTCtJlIgruHdbzROoDa=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',MPwXBVifFkcqTCtJlIgruHdbzROoxj.get('synopsis'))
    MPwXBVifFkcqTCtJlIgruHdbzROoDx=MPwXBVifFkcqTCtJlIgruHdbzROoaS.HTTPTAG+MPwXBVifFkcqTCtJlIgruHdbzROoxj.get('thumbnail')
    MPwXBVifFkcqTCtJlIgruHdbzROoDS=MPwXBVifFkcqTCtJlIgruHdbzROoDm=MPwXBVifFkcqTCtJlIgruHdbzROoDG=''
    MPwXBVifFkcqTCtJlIgruHdbzROoDS =MPwXBVifFkcqTCtJlIgruHdbzROoSs.get('imgPoster')
    MPwXBVifFkcqTCtJlIgruHdbzROoDm =MPwXBVifFkcqTCtJlIgruHdbzROoSs.get('imgFanart')
    MPwXBVifFkcqTCtJlIgruHdbzROoDG =MPwXBVifFkcqTCtJlIgruHdbzROoSs.get('imgClearlogo')
    MPwXBVifFkcqTCtJlIgruHdbzROoDY=MPwXBVifFkcqTCtJlIgruHdbzROoSs.get('programtitle')
    MPwXBVifFkcqTCtJlIgruHdbzROoSh={'thumb':MPwXBVifFkcqTCtJlIgruHdbzROoDx,'poster':MPwXBVifFkcqTCtJlIgruHdbzROoDS,'fanart':MPwXBVifFkcqTCtJlIgruHdbzROoDm,'clearlogo':MPwXBVifFkcqTCtJlIgruHdbzROoDG}
    MPwXBVifFkcqTCtJlIgruHdbzROoxv={'programtitle':MPwXBVifFkcqTCtJlIgruHdbzROoDY,'episodetitle':MPwXBVifFkcqTCtJlIgruHdbzROoxj['title_list'][0]['text'],'episodenumber':MPwXBVifFkcqTCtJlIgruHdbzROoxj['title_list'][1]['text'].replace('$O$',''),'contentid':MPwXBVifFkcqTCtJlIgruHdbzROoxj['contentid'],'synopsis':MPwXBVifFkcqTCtJlIgruHdbzROoDa,'episodeactors':MPwXBVifFkcqTCtJlIgruHdbzROoxj.get('actors').split(',')if MPwXBVifFkcqTCtJlIgruHdbzROoxj.get('actors')!='' else[],'thumbnail':MPwXBVifFkcqTCtJlIgruHdbzROoSh,}
    MPwXBVifFkcqTCtJlIgruHdbzROoSA.append(MPwXBVifFkcqTCtJlIgruHdbzROoxv)
   MPwXBVifFkcqTCtJlIgruHdbzROoxW=MPwXBVifFkcqTCtJlIgruHdbzROoGs(MPwXBVifFkcqTCtJlIgruHdbzROoxD['cell_toplist']['pagecount'])
   if MPwXBVifFkcqTCtJlIgruHdbzROoxD['cell_toplist']['count']:MPwXBVifFkcqTCtJlIgruHdbzROoSY =MPwXBVifFkcqTCtJlIgruHdbzROoGs(MPwXBVifFkcqTCtJlIgruHdbzROoxD['cell_toplist']['count'])
   else:MPwXBVifFkcqTCtJlIgruHdbzROoSY=MPwXBVifFkcqTCtJlIgruHdbzROoaS.EP_LIMIT*page_int
   MPwXBVifFkcqTCtJlIgruHdbzROoSa=MPwXBVifFkcqTCtJlIgruHdbzROoxW>MPwXBVifFkcqTCtJlIgruHdbzROoSY
  except MPwXBVifFkcqTCtJlIgruHdbzROoGv as exception:
   MPwXBVifFkcqTCtJlIgruHdbzROoGp(exception)
   return[],MPwXBVifFkcqTCtJlIgruHdbzROoGy
  return MPwXBVifFkcqTCtJlIgruHdbzROoSA,MPwXBVifFkcqTCtJlIgruHdbzROoSa
 def GetEPGList(MPwXBVifFkcqTCtJlIgruHdbzROoaS,genre):
  MPwXBVifFkcqTCtJlIgruHdbzROoDE={}
  try:
   MPwXBVifFkcqTCtJlIgruHdbzROoDe=MPwXBVifFkcqTCtJlIgruHdbzROoaS.Get_Now_Datetime()
   if genre=='all':
    MPwXBVifFkcqTCtJlIgruHdbzROoDU =MPwXBVifFkcqTCtJlIgruHdbzROoDe+datetime.timedelta(hours=3)
   else:
    MPwXBVifFkcqTCtJlIgruHdbzROoDU =MPwXBVifFkcqTCtJlIgruHdbzROoDe+datetime.timedelta(hours=3)
   MPwXBVifFkcqTCtJlIgruHdbzROoaW=MPwXBVifFkcqTCtJlIgruHdbzROoaS.API_DOMAIN+'/live/epgs'
   MPwXBVifFkcqTCtJlIgruHdbzROoaK={'limit':'100','offset':'0','genre':genre,'startdatetime':MPwXBVifFkcqTCtJlIgruHdbzROoDe.strftime('%Y-%m-%d %H:00'),'enddatetime':MPwXBVifFkcqTCtJlIgruHdbzROoDU.strftime('%Y-%m-%d %H:00')}
   MPwXBVifFkcqTCtJlIgruHdbzROoaK.update(MPwXBVifFkcqTCtJlIgruHdbzROoaS.GetDefaultParams(login=MPwXBVifFkcqTCtJlIgruHdbzROoGy))
   MPwXBVifFkcqTCtJlIgruHdbzROoxS=MPwXBVifFkcqTCtJlIgruHdbzROoaS.callRequestCookies('Get',MPwXBVifFkcqTCtJlIgruHdbzROoaW,payload=MPwXBVifFkcqTCtJlIgruHdbzROoGU,params=MPwXBVifFkcqTCtJlIgruHdbzROoaK,headers=MPwXBVifFkcqTCtJlIgruHdbzROoGU,cookies=MPwXBVifFkcqTCtJlIgruHdbzROoGU)
   MPwXBVifFkcqTCtJlIgruHdbzROoxD=json.loads(MPwXBVifFkcqTCtJlIgruHdbzROoxS.text)
   MPwXBVifFkcqTCtJlIgruHdbzROoDy=MPwXBVifFkcqTCtJlIgruHdbzROoxD['list']
   for MPwXBVifFkcqTCtJlIgruHdbzROoxj in MPwXBVifFkcqTCtJlIgruHdbzROoDy:
    MPwXBVifFkcqTCtJlIgruHdbzROoDK=''
    for MPwXBVifFkcqTCtJlIgruHdbzROoDN in MPwXBVifFkcqTCtJlIgruHdbzROoxj['list']:
     if MPwXBVifFkcqTCtJlIgruHdbzROoDK:MPwXBVifFkcqTCtJlIgruHdbzROoDK+='\n'
     MPwXBVifFkcqTCtJlIgruHdbzROoDK+=MPwXBVifFkcqTCtJlIgruHdbzROoaS.Get_ChangeText(MPwXBVifFkcqTCtJlIgruHdbzROoDN['title'])+'\n'
     MPwXBVifFkcqTCtJlIgruHdbzROoDK+=' [%s ~ %s]'%(MPwXBVifFkcqTCtJlIgruHdbzROoDN['starttime'][-5:],MPwXBVifFkcqTCtJlIgruHdbzROoDN['endtime'][-5:])+'\n'
    MPwXBVifFkcqTCtJlIgruHdbzROoDE[MPwXBVifFkcqTCtJlIgruHdbzROoxj['channelid']]=MPwXBVifFkcqTCtJlIgruHdbzROoDK
  except MPwXBVifFkcqTCtJlIgruHdbzROoGv as exception:
   MPwXBVifFkcqTCtJlIgruHdbzROoGp(exception)
  return MPwXBVifFkcqTCtJlIgruHdbzROoDE
 def Get_LiveChannel_List(MPwXBVifFkcqTCtJlIgruHdbzROoaS,genre,MPwXBVifFkcqTCtJlIgruHdbzROoxK):
  MPwXBVifFkcqTCtJlIgruHdbzROoxA=[]
  (MPwXBVifFkcqTCtJlIgruHdbzROoaW,MPwXBVifFkcqTCtJlIgruHdbzROoaK)=MPwXBVifFkcqTCtJlIgruHdbzROoaS.Baseapi_Parse(MPwXBVifFkcqTCtJlIgruHdbzROoxK)
  if MPwXBVifFkcqTCtJlIgruHdbzROoaW=='':return MPwXBVifFkcqTCtJlIgruHdbzROoxA
  MPwXBVifFkcqTCtJlIgruHdbzROoDn=MPwXBVifFkcqTCtJlIgruHdbzROoaS.GetEPGList(genre)
  try:
   MPwXBVifFkcqTCtJlIgruHdbzROoaK.update(MPwXBVifFkcqTCtJlIgruHdbzROoaS.GetDefaultParams(login=MPwXBVifFkcqTCtJlIgruHdbzROoGy))
   MPwXBVifFkcqTCtJlIgruHdbzROoaK['genre']=genre
   MPwXBVifFkcqTCtJlIgruHdbzROoxS=MPwXBVifFkcqTCtJlIgruHdbzROoaS.callRequestCookies('Get',MPwXBVifFkcqTCtJlIgruHdbzROoaW,payload=MPwXBVifFkcqTCtJlIgruHdbzROoGU,params=MPwXBVifFkcqTCtJlIgruHdbzROoaK,headers=MPwXBVifFkcqTCtJlIgruHdbzROoGU,cookies=MPwXBVifFkcqTCtJlIgruHdbzROoGU)
   MPwXBVifFkcqTCtJlIgruHdbzROoxD=json.loads(MPwXBVifFkcqTCtJlIgruHdbzROoxS.text)
   if not('celllist' in MPwXBVifFkcqTCtJlIgruHdbzROoxD['cell_toplist']):return[]
   MPwXBVifFkcqTCtJlIgruHdbzROoxn=MPwXBVifFkcqTCtJlIgruHdbzROoxD['cell_toplist']['celllist']
   for MPwXBVifFkcqTCtJlIgruHdbzROoxj in MPwXBVifFkcqTCtJlIgruHdbzROoxn:
    MPwXBVifFkcqTCtJlIgruHdbzROoSK=MPwXBVifFkcqTCtJlIgruHdbzROoxj['contentid']
    if MPwXBVifFkcqTCtJlIgruHdbzROoSK in MPwXBVifFkcqTCtJlIgruHdbzROoDn:
     MPwXBVifFkcqTCtJlIgruHdbzROoDj=MPwXBVifFkcqTCtJlIgruHdbzROoDn[MPwXBVifFkcqTCtJlIgruHdbzROoSK]
    else:
     MPwXBVifFkcqTCtJlIgruHdbzROoDj=''
    MPwXBVifFkcqTCtJlIgruHdbzROoxv={'studio':MPwXBVifFkcqTCtJlIgruHdbzROoxj['title_list'][0]['text'],'tvshowtitle':MPwXBVifFkcqTCtJlIgruHdbzROoaS.Get_ChangeText(MPwXBVifFkcqTCtJlIgruHdbzROoxj['title_list'][1]['text']),'channelid':MPwXBVifFkcqTCtJlIgruHdbzROoSK,'age':MPwXBVifFkcqTCtJlIgruHdbzROoxj['age'],'thumbnail':'https://%s'%MPwXBVifFkcqTCtJlIgruHdbzROoxj.get('thumbnail'),'epg':MPwXBVifFkcqTCtJlIgruHdbzROoDj}
    MPwXBVifFkcqTCtJlIgruHdbzROoxA.append(MPwXBVifFkcqTCtJlIgruHdbzROoxv)
  except MPwXBVifFkcqTCtJlIgruHdbzROoGv as exception:
   MPwXBVifFkcqTCtJlIgruHdbzROoGp(exception)
   return[]
  return MPwXBVifFkcqTCtJlIgruHdbzROoxA
 def Get_Search_List(MPwXBVifFkcqTCtJlIgruHdbzROoaS,search_key,sType,page_int,exclusion21=MPwXBVifFkcqTCtJlIgruHdbzROoGy):
  MPwXBVifFkcqTCtJlIgruHdbzROoDv=[]
  MPwXBVifFkcqTCtJlIgruHdbzROoxW=MPwXBVifFkcqTCtJlIgruHdbzROoSY=1
  MPwXBVifFkcqTCtJlIgruHdbzROoSa=MPwXBVifFkcqTCtJlIgruHdbzROoGy
  try:
   MPwXBVifFkcqTCtJlIgruHdbzROoaW=MPwXBVifFkcqTCtJlIgruHdbzROoaS.API_DOMAIN+'/fz/search/band.js'
   MPwXBVifFkcqTCtJlIgruHdbzROoaK={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':MPwXBVifFkcqTCtJlIgruHdbzROoGj((page_int-1)*MPwXBVifFkcqTCtJlIgruHdbzROoaS.SEARCH_LIMIT),'limit':MPwXBVifFkcqTCtJlIgruHdbzROoaS.SEARCH_LIMIT,'orderby':'score','mtype':'svod',}
   MPwXBVifFkcqTCtJlIgruHdbzROoaK.update(MPwXBVifFkcqTCtJlIgruHdbzROoaS.GetDefaultParams(login=MPwXBVifFkcqTCtJlIgruHdbzROoGy))
   MPwXBVifFkcqTCtJlIgruHdbzROoxS=MPwXBVifFkcqTCtJlIgruHdbzROoaS.callRequestCookies('Get',MPwXBVifFkcqTCtJlIgruHdbzROoaW,payload=MPwXBVifFkcqTCtJlIgruHdbzROoGU,params=MPwXBVifFkcqTCtJlIgruHdbzROoaK,headers=MPwXBVifFkcqTCtJlIgruHdbzROoGU,cookies=MPwXBVifFkcqTCtJlIgruHdbzROoGU)
   MPwXBVifFkcqTCtJlIgruHdbzROoSN=json.loads(MPwXBVifFkcqTCtJlIgruHdbzROoxS.text)
   if not('celllist' in MPwXBVifFkcqTCtJlIgruHdbzROoSN['band']):return MPwXBVifFkcqTCtJlIgruHdbzROoDv,MPwXBVifFkcqTCtJlIgruHdbzROoSa
   MPwXBVifFkcqTCtJlIgruHdbzROoxn=MPwXBVifFkcqTCtJlIgruHdbzROoSN['band']['celllist']
   for MPwXBVifFkcqTCtJlIgruHdbzROoxj in MPwXBVifFkcqTCtJlIgruHdbzROoxn:
    MPwXBVifFkcqTCtJlIgruHdbzROoSx =MPwXBVifFkcqTCtJlIgruHdbzROoxj['event_list'][1]['url']
    MPwXBVifFkcqTCtJlIgruHdbzROoSD=urllib.parse.urlsplit(MPwXBVifFkcqTCtJlIgruHdbzROoSx).query
    MPwXBVifFkcqTCtJlIgruHdbzROoSm=MPwXBVifFkcqTCtJlIgruHdbzROoSD[0:MPwXBVifFkcqTCtJlIgruHdbzROoSD.find('=')]
    MPwXBVifFkcqTCtJlIgruHdbzROoSG=MPwXBVifFkcqTCtJlIgruHdbzROoSD[MPwXBVifFkcqTCtJlIgruHdbzROoSD.find('=')+1:]
    MPwXBVifFkcqTCtJlIgruHdbzROoxv={'title':MPwXBVifFkcqTCtJlIgruHdbzROoxj['title_list'][0]['text'],'age':MPwXBVifFkcqTCtJlIgruHdbzROoxj['age'],'thumbnail':'https://%s'%MPwXBVifFkcqTCtJlIgruHdbzROoxj.get('thumbnail'),'videoid':MPwXBVifFkcqTCtJlIgruHdbzROoSG,'vidtype':MPwXBVifFkcqTCtJlIgruHdbzROoSm,}
    MPwXBVifFkcqTCtJlIgruHdbzROoDp=MPwXBVifFkcqTCtJlIgruHdbzROoGy
    for MPwXBVifFkcqTCtJlIgruHdbzROoDL in MPwXBVifFkcqTCtJlIgruHdbzROoxj['bottom_taglist']:
     if MPwXBVifFkcqTCtJlIgruHdbzROoDL=='won':
      MPwXBVifFkcqTCtJlIgruHdbzROoDp=MPwXBVifFkcqTCtJlIgruHdbzROoGN
      break
    if MPwXBVifFkcqTCtJlIgruHdbzROoDp==MPwXBVifFkcqTCtJlIgruHdbzROoGN: 
     MPwXBVifFkcqTCtJlIgruHdbzROoxv['title']=MPwXBVifFkcqTCtJlIgruHdbzROoxv['title']+' [개별구매]'
    if exclusion21==MPwXBVifFkcqTCtJlIgruHdbzROoGy or MPwXBVifFkcqTCtJlIgruHdbzROoxj.get('age')!='21':
     MPwXBVifFkcqTCtJlIgruHdbzROoDv.append(MPwXBVifFkcqTCtJlIgruHdbzROoxv)
   MPwXBVifFkcqTCtJlIgruHdbzROoxW=MPwXBVifFkcqTCtJlIgruHdbzROoGs(MPwXBVifFkcqTCtJlIgruHdbzROoSN['band']['pagecount'])
   if MPwXBVifFkcqTCtJlIgruHdbzROoSN['band']['count']:MPwXBVifFkcqTCtJlIgruHdbzROoSY =MPwXBVifFkcqTCtJlIgruHdbzROoGs(MPwXBVifFkcqTCtJlIgruHdbzROoSN['band']['count'])
   else:MPwXBVifFkcqTCtJlIgruHdbzROoSY=MPwXBVifFkcqTCtJlIgruHdbzROoaS.LIST_LIMIT
   MPwXBVifFkcqTCtJlIgruHdbzROoSa=MPwXBVifFkcqTCtJlIgruHdbzROoxW>MPwXBVifFkcqTCtJlIgruHdbzROoSY
  except MPwXBVifFkcqTCtJlIgruHdbzROoGv as exception:
   MPwXBVifFkcqTCtJlIgruHdbzROoGp(exception)
  return MPwXBVifFkcqTCtJlIgruHdbzROoDv,MPwXBVifFkcqTCtJlIgruHdbzROoSa 
 def GetSecureToken(MPwXBVifFkcqTCtJlIgruHdbzROoaS):
  MPwXBVifFkcqTCtJlIgruHdbzROoaW=MPwXBVifFkcqTCtJlIgruHdbzROoaS.API_DOMAIN+'/ip'
  MPwXBVifFkcqTCtJlIgruHdbzROoaK=MPwXBVifFkcqTCtJlIgruHdbzROoaS.GetDefaultParams(login=MPwXBVifFkcqTCtJlIgruHdbzROoGy)
  MPwXBVifFkcqTCtJlIgruHdbzROoxS=MPwXBVifFkcqTCtJlIgruHdbzROoaS.callRequestCookies('Get',MPwXBVifFkcqTCtJlIgruHdbzROoaW,payload=MPwXBVifFkcqTCtJlIgruHdbzROoGU,params=MPwXBVifFkcqTCtJlIgruHdbzROoaK,headers=MPwXBVifFkcqTCtJlIgruHdbzROoGU,cookies=MPwXBVifFkcqTCtJlIgruHdbzROoGU)
  MPwXBVifFkcqTCtJlIgruHdbzROoxD=json.loads(MPwXBVifFkcqTCtJlIgruHdbzROoxS.text)
  return MPwXBVifFkcqTCtJlIgruHdbzROoxD['securetoken']
 def GetStreamingURL(MPwXBVifFkcqTCtJlIgruHdbzROoaS,mode,MPwXBVifFkcqTCtJlIgruHdbzROoSK,quality_int,pvrmode='-',playOption={}):
  MPwXBVifFkcqTCtJlIgruHdbzROoDs ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  MPwXBVifFkcqTCtJlIgruHdbzROoDh=[]
  if mode=='LIVE':
   MPwXBVifFkcqTCtJlIgruHdbzROoaW =MPwXBVifFkcqTCtJlIgruHdbzROoaS.API_DOMAIN+'/live/channels/'+MPwXBVifFkcqTCtJlIgruHdbzROoSK
   MPwXBVifFkcqTCtJlIgruHdbzROoDQ='live'
  elif mode=='VOD':
   MPwXBVifFkcqTCtJlIgruHdbzROoaW =MPwXBVifFkcqTCtJlIgruHdbzROoaS.API_DOMAIN+'/fz/vod/contents/'+MPwXBVifFkcqTCtJlIgruHdbzROoSK
   MPwXBVifFkcqTCtJlIgruHdbzROoDQ='vod'
  elif mode=='MOVIE':
   MPwXBVifFkcqTCtJlIgruHdbzROoaW =MPwXBVifFkcqTCtJlIgruHdbzROoaS.API_DOMAIN+'/fz/movie/contents/'+MPwXBVifFkcqTCtJlIgruHdbzROoSK
   MPwXBVifFkcqTCtJlIgruHdbzROoDQ='movie'
  MPwXBVifFkcqTCtJlIgruHdbzROoDA={'hdr':'sdr',}
  try:
   MPwXBVifFkcqTCtJlIgruHdbzROoaK=MPwXBVifFkcqTCtJlIgruHdbzROoaS.GetDefaultParams(login=MPwXBVifFkcqTCtJlIgruHdbzROoGy)
   MPwXBVifFkcqTCtJlIgruHdbzROoxS=MPwXBVifFkcqTCtJlIgruHdbzROoaS.callRequestCookies('Get',MPwXBVifFkcqTCtJlIgruHdbzROoaW,payload=MPwXBVifFkcqTCtJlIgruHdbzROoGU,params=MPwXBVifFkcqTCtJlIgruHdbzROoaK,headers=MPwXBVifFkcqTCtJlIgruHdbzROoGU,cookies=MPwXBVifFkcqTCtJlIgruHdbzROoGU)
   MPwXBVifFkcqTCtJlIgruHdbzROoxD=json.loads(MPwXBVifFkcqTCtJlIgruHdbzROoxS.text)
   MPwXBVifFkcqTCtJlIgruHdbzROoDW=MPwXBVifFkcqTCtJlIgruHdbzROoxD['qualities']['list']
   if MPwXBVifFkcqTCtJlIgruHdbzROoDW==MPwXBVifFkcqTCtJlIgruHdbzROoGU:return MPwXBVifFkcqTCtJlIgruHdbzROoDs
   for MPwXBVifFkcqTCtJlIgruHdbzROoma in MPwXBVifFkcqTCtJlIgruHdbzROoDW:
    MPwXBVifFkcqTCtJlIgruHdbzROoDh.append(MPwXBVifFkcqTCtJlIgruHdbzROoGs(MPwXBVifFkcqTCtJlIgruHdbzROoma.get('id').rstrip('p')))
   if 'type' in MPwXBVifFkcqTCtJlIgruHdbzROoxD:
    if MPwXBVifFkcqTCtJlIgruHdbzROoxD['type']=='onair':
     MPwXBVifFkcqTCtJlIgruHdbzROoDQ='onairvod'
   if 'drms' in MPwXBVifFkcqTCtJlIgruHdbzROoxD:
    if MPwXBVifFkcqTCtJlIgruHdbzROoxD['drms']:
     MPwXBVifFkcqTCtJlIgruHdbzROoDs['stream_action']='dash'
   if playOption.get('enable_hdr'):
    if 'mediatypes' in MPwXBVifFkcqTCtJlIgruHdbzROoxD.get('qualities'):
     for MPwXBVifFkcqTCtJlIgruHdbzROomx in MPwXBVifFkcqTCtJlIgruHdbzROoxD.get('qualities').get('mediatypes'):
      if MPwXBVifFkcqTCtJlIgruHdbzROomx=='HDR10':
       MPwXBVifFkcqTCtJlIgruHdbzROoDA['hdr']='hdr'
       MPwXBVifFkcqTCtJlIgruHdbzROoDs['stream_action']='dash'
       break
  except MPwXBVifFkcqTCtJlIgruHdbzROoGv as exception:
   MPwXBVifFkcqTCtJlIgruHdbzROoGp(exception)
   return MPwXBVifFkcqTCtJlIgruHdbzROoDs
  MPwXBVifFkcqTCtJlIgruHdbzROoGp(MPwXBVifFkcqTCtJlIgruHdbzROoDs['stream_action'])
  try:
   MPwXBVifFkcqTCtJlIgruHdbzROomS=MPwXBVifFkcqTCtJlIgruHdbzROoaS.CheckQuality(quality_int,MPwXBVifFkcqTCtJlIgruHdbzROoDh)
   MPwXBVifFkcqTCtJlIgruHdbzROomD=MPwXBVifFkcqTCtJlIgruHdbzROoGj(MPwXBVifFkcqTCtJlIgruHdbzROomS)+'p'
   MPwXBVifFkcqTCtJlIgruHdbzROoaW=MPwXBVifFkcqTCtJlIgruHdbzROoaS.API_DOMAIN+'/fz/streaming'
   if MPwXBVifFkcqTCtJlIgruHdbzROoDA['hdr']=='hdr':
    MPwXBVifFkcqTCtJlIgruHdbzROoaK={'contentid':MPwXBVifFkcqTCtJlIgruHdbzROoSK,'contenttype':MPwXBVifFkcqTCtJlIgruHdbzROoDQ,'quality':MPwXBVifFkcqTCtJlIgruHdbzROomD,'modelid':'SHIELD Android TV','guid':MPwXBVifFkcqTCtJlIgruHdbzROoaS.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n','protocol':MPwXBVifFkcqTCtJlIgruHdbzROoDs['stream_action'],'hdr':'HDR10','videocodec':'HEVC','audiocodec':'AAC','issurround':'y','format':'normal','withinsubtitle':'n',}
    MPwXBVifFkcqTCtJlIgruHdbzROoaK.update(MPwXBVifFkcqTCtJlIgruHdbzROoaS.GetDefaultParams_AND())
   else:
    MPwXBVifFkcqTCtJlIgruHdbzROoaK={'contentid':MPwXBVifFkcqTCtJlIgruHdbzROoSK,'contenttype':MPwXBVifFkcqTCtJlIgruHdbzROoDQ,'quality':MPwXBVifFkcqTCtJlIgruHdbzROomD,'deviceModelId':'Windows 10','guid':MPwXBVifFkcqTCtJlIgruHdbzROoaS.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n','action':MPwXBVifFkcqTCtJlIgruHdbzROoDs['stream_action'],'protocol':MPwXBVifFkcqTCtJlIgruHdbzROoDs['stream_action'],'hdr':'sdr','videocodec':'avc','audiocodec':'aac','issurround':'n','format':'normal','withinsubtitle':'n',}
    MPwXBVifFkcqTCtJlIgruHdbzROoaK.update(MPwXBVifFkcqTCtJlIgruHdbzROoaS.GetDefaultParams(login=MPwXBVifFkcqTCtJlIgruHdbzROoGN))
   MPwXBVifFkcqTCtJlIgruHdbzROoxS=MPwXBVifFkcqTCtJlIgruHdbzROoaS.callRequestCookies('Get',MPwXBVifFkcqTCtJlIgruHdbzROoaW,payload=MPwXBVifFkcqTCtJlIgruHdbzROoGU,params=MPwXBVifFkcqTCtJlIgruHdbzROoaK,headers=MPwXBVifFkcqTCtJlIgruHdbzROoGU,cookies=MPwXBVifFkcqTCtJlIgruHdbzROoGU)
   MPwXBVifFkcqTCtJlIgruHdbzROoxD=json.loads(MPwXBVifFkcqTCtJlIgruHdbzROoxS.text)
   MPwXBVifFkcqTCtJlIgruHdbzROoDs['stream_url']=MPwXBVifFkcqTCtJlIgruHdbzROoxD['playurl']
   if MPwXBVifFkcqTCtJlIgruHdbzROoDs['stream_url']==MPwXBVifFkcqTCtJlIgruHdbzROoGU:return MPwXBVifFkcqTCtJlIgruHdbzROoDs
   MPwXBVifFkcqTCtJlIgruHdbzROoDs['stream_cookie']=MPwXBVifFkcqTCtJlIgruHdbzROoxD['awscookie']
   MPwXBVifFkcqTCtJlIgruHdbzROoDs['stream_drm'] =MPwXBVifFkcqTCtJlIgruHdbzROoxD['drm']
   if 'previewmsg' in MPwXBVifFkcqTCtJlIgruHdbzROoxD['preview']:MPwXBVifFkcqTCtJlIgruHdbzROoDs['stream_preview']=MPwXBVifFkcqTCtJlIgruHdbzROoxD['preview']['previewmsg']
   if 'subtitles' in MPwXBVifFkcqTCtJlIgruHdbzROoxD:
    for MPwXBVifFkcqTCtJlIgruHdbzROomG in MPwXBVifFkcqTCtJlIgruHdbzROoxD['subtitles']:
     if MPwXBVifFkcqTCtJlIgruHdbzROomG.get('languagecode')=='ko':
      MPwXBVifFkcqTCtJlIgruHdbzROoDs['stream_vtt']=MPwXBVifFkcqTCtJlIgruHdbzROomG.get('url')
      break
  except MPwXBVifFkcqTCtJlIgruHdbzROoGv as exception:
   MPwXBVifFkcqTCtJlIgruHdbzROoGp(exception)
  return MPwXBVifFkcqTCtJlIgruHdbzROoDs 
 def GetSportsURL(MPwXBVifFkcqTCtJlIgruHdbzROoaS,MPwXBVifFkcqTCtJlIgruHdbzROoSK,quality_int):
  MPwXBVifFkcqTCtJlIgruHdbzROoDs ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  MPwXBVifFkcqTCtJlIgruHdbzROoDh=[]
  try:
   MPwXBVifFkcqTCtJlIgruHdbzROoaW=MPwXBVifFkcqTCtJlIgruHdbzROoaS.API_DOMAIN+'/streaming/other'
   MPwXBVifFkcqTCtJlIgruHdbzROoaK={'contentid':MPwXBVifFkcqTCtJlIgruHdbzROoSK,'contenttype':'live','action':MPwXBVifFkcqTCtJlIgruHdbzROoDs['stream_action'],'quality':MPwXBVifFkcqTCtJlIgruHdbzROoGj(quality_int)+'p','deviceModelId':'Windows 10','guid':MPwXBVifFkcqTCtJlIgruHdbzROoaS.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n',}
   MPwXBVifFkcqTCtJlIgruHdbzROoaK.update(MPwXBVifFkcqTCtJlIgruHdbzROoaS.GetDefaultParams(login=MPwXBVifFkcqTCtJlIgruHdbzROoGN))
   MPwXBVifFkcqTCtJlIgruHdbzROoxS=MPwXBVifFkcqTCtJlIgruHdbzROoaS.callRequestCookies('Get',MPwXBVifFkcqTCtJlIgruHdbzROoaW,payload=MPwXBVifFkcqTCtJlIgruHdbzROoGU,params=MPwXBVifFkcqTCtJlIgruHdbzROoaK,headers=MPwXBVifFkcqTCtJlIgruHdbzROoGU,cookies=MPwXBVifFkcqTCtJlIgruHdbzROoGU)
   MPwXBVifFkcqTCtJlIgruHdbzROoxD=json.loads(MPwXBVifFkcqTCtJlIgruHdbzROoxS.text)
   MPwXBVifFkcqTCtJlIgruHdbzROoDs['stream_url']=MPwXBVifFkcqTCtJlIgruHdbzROoxD['playurl']
   if MPwXBVifFkcqTCtJlIgruHdbzROoDs['stream_url']==MPwXBVifFkcqTCtJlIgruHdbzROoGU:return MPwXBVifFkcqTCtJlIgruHdbzROoDs
   MPwXBVifFkcqTCtJlIgruHdbzROoDs['stream_cookie']=MPwXBVifFkcqTCtJlIgruHdbzROoxD['awscookie']
  except MPwXBVifFkcqTCtJlIgruHdbzROoGv as exception:
   MPwXBVifFkcqTCtJlIgruHdbzROoGp(exception)
  return MPwXBVifFkcqTCtJlIgruHdbzROoDs
 def make_viewdate(MPwXBVifFkcqTCtJlIgruHdbzROoaS):
  MPwXBVifFkcqTCtJlIgruHdbzROomY =MPwXBVifFkcqTCtJlIgruHdbzROoaS.Get_Now_Datetime()
  MPwXBVifFkcqTCtJlIgruHdbzROomE =MPwXBVifFkcqTCtJlIgruHdbzROomY+datetime.timedelta(days=-1)
  MPwXBVifFkcqTCtJlIgruHdbzROome =MPwXBVifFkcqTCtJlIgruHdbzROomY+datetime.timedelta(days=1)
  MPwXBVifFkcqTCtJlIgruHdbzROomU=[MPwXBVifFkcqTCtJlIgruHdbzROomY.strftime('%Y%m%d'),MPwXBVifFkcqTCtJlIgruHdbzROome.strftime('%Y%m%d'),]
  return MPwXBVifFkcqTCtJlIgruHdbzROomU
 def Get_Sports_Gamelist(MPwXBVifFkcqTCtJlIgruHdbzROoaS):
  MPwXBVifFkcqTCtJlIgruHdbzROomy =MPwXBVifFkcqTCtJlIgruHdbzROoaS.make_viewdate()
  MPwXBVifFkcqTCtJlIgruHdbzROomK=[]
  MPwXBVifFkcqTCtJlIgruHdbzROomN =[]
  for MPwXBVifFkcqTCtJlIgruHdbzROomn in MPwXBVifFkcqTCtJlIgruHdbzROomy:
   MPwXBVifFkcqTCtJlIgruHdbzROomj=MPwXBVifFkcqTCtJlIgruHdbzROomn[:6]
   if MPwXBVifFkcqTCtJlIgruHdbzROomj not in MPwXBVifFkcqTCtJlIgruHdbzROomK:
    MPwXBVifFkcqTCtJlIgruHdbzROomK.append(MPwXBVifFkcqTCtJlIgruHdbzROomj)
  try:
   MPwXBVifFkcqTCtJlIgruHdbzROoaW='https://annexapi.wavve.com/skb/baseball/teammonthlycalendarlist'
   MPwXBVifFkcqTCtJlIgruHdbzROoaK={'IF':'IF-PORG-002','m':'getTeamCalendarListBand','response_format':'json','spo_itm_cd':'KBO','teamcd':'all','tgroup':'B','tvalue':'BC123','ver':'2.0',}
   MPwXBVifFkcqTCtJlIgruHdbzROoaK.update(MPwXBVifFkcqTCtJlIgruHdbzROoaS.GetDefaultParams(login=MPwXBVifFkcqTCtJlIgruHdbzROoGy))
   for MPwXBVifFkcqTCtJlIgruHdbzROomv in MPwXBVifFkcqTCtJlIgruHdbzROomK:
    MPwXBVifFkcqTCtJlIgruHdbzROoaK['date']=MPwXBVifFkcqTCtJlIgruHdbzROomv
    MPwXBVifFkcqTCtJlIgruHdbzROoxS=MPwXBVifFkcqTCtJlIgruHdbzROoaS.callRequestCookies('Get',MPwXBVifFkcqTCtJlIgruHdbzROoaW,payload=MPwXBVifFkcqTCtJlIgruHdbzROoGU,params=MPwXBVifFkcqTCtJlIgruHdbzROoaK,headers=MPwXBVifFkcqTCtJlIgruHdbzROoGU,cookies=MPwXBVifFkcqTCtJlIgruHdbzROoGU)
    MPwXBVifFkcqTCtJlIgruHdbzROoxD=json.loads(MPwXBVifFkcqTCtJlIgruHdbzROoxS.text)
    MPwXBVifFkcqTCtJlIgruHdbzROoxn=MPwXBVifFkcqTCtJlIgruHdbzROoxD['cell_toplist']['celllist']
    for MPwXBVifFkcqTCtJlIgruHdbzROoxj in MPwXBVifFkcqTCtJlIgruHdbzROoxn:
     MPwXBVifFkcqTCtJlIgruHdbzROomp=MPwXBVifFkcqTCtJlIgruHdbzROoxj.get('game_date')
     MPwXBVifFkcqTCtJlIgruHdbzROomL =MPwXBVifFkcqTCtJlIgruHdbzROoxj.get('svc_id')
     if MPwXBVifFkcqTCtJlIgruHdbzROomL=='':continue
     if MPwXBVifFkcqTCtJlIgruHdbzROomp in MPwXBVifFkcqTCtJlIgruHdbzROomy:
      MPwXBVifFkcqTCtJlIgruHdbzROoms=MPwXBVifFkcqTCtJlIgruHdbzROoxj.get('game_status') 
      MPwXBVifFkcqTCtJlIgruHdbzROomh =MPwXBVifFkcqTCtJlIgruHdbzROoxj.get('title_list')[0].get('text')
      MPwXBVifFkcqTCtJlIgruHdbzROomp =MPwXBVifFkcqTCtJlIgruHdbzROomp[:4]+'-'+MPwXBVifFkcqTCtJlIgruHdbzROomp[4:6]+'-'+MPwXBVifFkcqTCtJlIgruHdbzROomp[-2:]
      MPwXBVifFkcqTCtJlIgruHdbzROomQ =MPwXBVifFkcqTCtJlIgruHdbzROoxj.get('game_time')
      MPwXBVifFkcqTCtJlIgruHdbzROomQ =MPwXBVifFkcqTCtJlIgruHdbzROomQ[:2]+':'+MPwXBVifFkcqTCtJlIgruHdbzROomQ[-2:]
      MPwXBVifFkcqTCtJlIgruHdbzROoxv={'game_date':MPwXBVifFkcqTCtJlIgruHdbzROomp,'game_time':MPwXBVifFkcqTCtJlIgruHdbzROomQ,'svc_id':MPwXBVifFkcqTCtJlIgruHdbzROomL,'away_team':MPwXBVifFkcqTCtJlIgruHdbzROoxj.get('away_team').get('team_name'),'home_team':MPwXBVifFkcqTCtJlIgruHdbzROoxj.get('home_team').get('team_name'),'game_status':MPwXBVifFkcqTCtJlIgruHdbzROoms,'game_place':MPwXBVifFkcqTCtJlIgruHdbzROoxj.get('game_place'),}
      MPwXBVifFkcqTCtJlIgruHdbzROomN.append(MPwXBVifFkcqTCtJlIgruHdbzROoxv)
  except MPwXBVifFkcqTCtJlIgruHdbzROoGv as exception:
   MPwXBVifFkcqTCtJlIgruHdbzROoGp(exception)
   return[]
  MPwXBVifFkcqTCtJlIgruHdbzROomA=[]
  for i in MPwXBVifFkcqTCtJlIgruHdbzROoGn(2):
   for MPwXBVifFkcqTCtJlIgruHdbzROoxj in MPwXBVifFkcqTCtJlIgruHdbzROomN:
    if i==0 and MPwXBVifFkcqTCtJlIgruHdbzROoxj.get('game_status')=='LIVE':
     MPwXBVifFkcqTCtJlIgruHdbzROomA.append(MPwXBVifFkcqTCtJlIgruHdbzROoxj)
    elif i==1 and MPwXBVifFkcqTCtJlIgruHdbzROoxj.get('game_status')!='LIVE':
     MPwXBVifFkcqTCtJlIgruHdbzROomA.append(MPwXBVifFkcqTCtJlIgruHdbzROoxj)
  return MPwXBVifFkcqTCtJlIgruHdbzROomA
 def GetBookmarkInfo(MPwXBVifFkcqTCtJlIgruHdbzROoaS,MPwXBVifFkcqTCtJlIgruHdbzROoSG,MPwXBVifFkcqTCtJlIgruHdbzROoSm,MPwXBVifFkcqTCtJlIgruHdbzROoDQ):
  if MPwXBVifFkcqTCtJlIgruHdbzROoSm=='tvshow':
   if MPwXBVifFkcqTCtJlIgruHdbzROoDQ=='contentid':
    MPwXBVifFkcqTCtJlIgruHdbzROoSK=MPwXBVifFkcqTCtJlIgruHdbzROoSG
    MPwXBVifFkcqTCtJlIgruHdbzROoSG =MPwXBVifFkcqTCtJlIgruHdbzROoaS.ContentidToSeasonid(MPwXBVifFkcqTCtJlIgruHdbzROoSK)
   else:
    MPwXBVifFkcqTCtJlIgruHdbzROoSK=MPwXBVifFkcqTCtJlIgruHdbzROoaS.ProgramidToContentid(MPwXBVifFkcqTCtJlIgruHdbzROoSG)
  else:
   MPwXBVifFkcqTCtJlIgruHdbzROoSK=''
  MPwXBVifFkcqTCtJlIgruHdbzROomW={'indexinfo':{'ott':'wavve','videoid':MPwXBVifFkcqTCtJlIgruHdbzROoSG,'vidtype':MPwXBVifFkcqTCtJlIgruHdbzROoSm,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':MPwXBVifFkcqTCtJlIgruHdbzROoSm,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if MPwXBVifFkcqTCtJlIgruHdbzROoSm=='tvshow':
   MPwXBVifFkcqTCtJlIgruHdbzROoaW=MPwXBVifFkcqTCtJlIgruHdbzROoaS.API_DOMAIN+'/fz/vod/contents/'+MPwXBVifFkcqTCtJlIgruHdbzROoSK 
   MPwXBVifFkcqTCtJlIgruHdbzROoaK=MPwXBVifFkcqTCtJlIgruHdbzROoaS.GetDefaultParams(login=MPwXBVifFkcqTCtJlIgruHdbzROoGy)
   MPwXBVifFkcqTCtJlIgruHdbzROoxS=MPwXBVifFkcqTCtJlIgruHdbzROoaS.callRequestCookies('Get',MPwXBVifFkcqTCtJlIgruHdbzROoaW,payload=MPwXBVifFkcqTCtJlIgruHdbzROoGU,params=MPwXBVifFkcqTCtJlIgruHdbzROoaK,headers=MPwXBVifFkcqTCtJlIgruHdbzROoGU,cookies=MPwXBVifFkcqTCtJlIgruHdbzROoGU)
   MPwXBVifFkcqTCtJlIgruHdbzROoxD=json.loads(MPwXBVifFkcqTCtJlIgruHdbzROoxS.text)
   if not('programtitle' in MPwXBVifFkcqTCtJlIgruHdbzROoxD):return{}
   MPwXBVifFkcqTCtJlIgruHdbzROoGa=MPwXBVifFkcqTCtJlIgruHdbzROoxD
   MPwXBVifFkcqTCtJlIgruHdbzROoGx=MPwXBVifFkcqTCtJlIgruHdbzROoGa.get('programtitle')
   MPwXBVifFkcqTCtJlIgruHdbzROomW['saveinfo']['infoLabels']['title']=MPwXBVifFkcqTCtJlIgruHdbzROoGx
   if MPwXBVifFkcqTCtJlIgruHdbzROoGa.get('targetage')=='18' or MPwXBVifFkcqTCtJlIgruHdbzROoGa.get('targetage')=='19' or MPwXBVifFkcqTCtJlIgruHdbzROoGa.get('targetage')=='21':
    MPwXBVifFkcqTCtJlIgruHdbzROoGx +=u' (%s)'%(MPwXBVifFkcqTCtJlIgruHdbzROoGa.get('targetage'))
   MPwXBVifFkcqTCtJlIgruHdbzROomW['saveinfo']['title'] =MPwXBVifFkcqTCtJlIgruHdbzROoGx
   MPwXBVifFkcqTCtJlIgruHdbzROomW['saveinfo']['infoLabels']['mpaa'] =MPwXBVifFkcqTCtJlIgruHdbzROoGa.get('targetage')
   MPwXBVifFkcqTCtJlIgruHdbzROomW['saveinfo']['infoLabels']['plot'] =MPwXBVifFkcqTCtJlIgruHdbzROoGa.get('programsynopsis').replace('<br>','\n')
   MPwXBVifFkcqTCtJlIgruHdbzROomW['saveinfo']['infoLabels']['studio'] =MPwXBVifFkcqTCtJlIgruHdbzROoGa.get('channelname')
   if MPwXBVifFkcqTCtJlIgruHdbzROoGa.get('firstreleaseyear')!='':MPwXBVifFkcqTCtJlIgruHdbzROomW['saveinfo']['infoLabels']['year'] =MPwXBVifFkcqTCtJlIgruHdbzROoGa.get('firstreleaseyear')
   if MPwXBVifFkcqTCtJlIgruHdbzROoGa.get('firstreleasedate')!='':MPwXBVifFkcqTCtJlIgruHdbzROomW['saveinfo']['infoLabels']['premiered']=MPwXBVifFkcqTCtJlIgruHdbzROoGa.get('firstreleasedate')
   if MPwXBVifFkcqTCtJlIgruHdbzROoGa.get('genretext') !='':MPwXBVifFkcqTCtJlIgruHdbzROomW['saveinfo']['infoLabels']['genre'] =[MPwXBVifFkcqTCtJlIgruHdbzROoGa.get('genretext')]
   MPwXBVifFkcqTCtJlIgruHdbzROoGS=[]
   for MPwXBVifFkcqTCtJlIgruHdbzROoGD in MPwXBVifFkcqTCtJlIgruHdbzROoGa['actors']['list']:MPwXBVifFkcqTCtJlIgruHdbzROoGS.append(MPwXBVifFkcqTCtJlIgruHdbzROoGD.get('text'))
   if MPwXBVifFkcqTCtJlIgruHdbzROoGh(MPwXBVifFkcqTCtJlIgruHdbzROoGS)>0:
    if MPwXBVifFkcqTCtJlIgruHdbzROoGS[0]!='':MPwXBVifFkcqTCtJlIgruHdbzROomW['saveinfo']['infoLabels']['cast']=MPwXBVifFkcqTCtJlIgruHdbzROoGS
   MPwXBVifFkcqTCtJlIgruHdbzROoDS =''
   MPwXBVifFkcqTCtJlIgruHdbzROoDm =''
   MPwXBVifFkcqTCtJlIgruHdbzROoDG=''
   if MPwXBVifFkcqTCtJlIgruHdbzROoGa.get('programposterimage')!='':MPwXBVifFkcqTCtJlIgruHdbzROoDS =MPwXBVifFkcqTCtJlIgruHdbzROoaS.HTTPTAG+MPwXBVifFkcqTCtJlIgruHdbzROoGa.get('programposterimage')
   if MPwXBVifFkcqTCtJlIgruHdbzROoGa.get('programimage') !='':MPwXBVifFkcqTCtJlIgruHdbzROoDm =MPwXBVifFkcqTCtJlIgruHdbzROoaS.HTTPTAG+MPwXBVifFkcqTCtJlIgruHdbzROoGa.get('programimage')
   if MPwXBVifFkcqTCtJlIgruHdbzROoGa.get('programcircleimage')!='':MPwXBVifFkcqTCtJlIgruHdbzROoDG=MPwXBVifFkcqTCtJlIgruHdbzROoaS.HTTPTAG+MPwXBVifFkcqTCtJlIgruHdbzROoGa.get('programcircleimage')
   if 'poster_default' in MPwXBVifFkcqTCtJlIgruHdbzROoDS:
    MPwXBVifFkcqTCtJlIgruHdbzROoDS =MPwXBVifFkcqTCtJlIgruHdbzROoDm
    MPwXBVifFkcqTCtJlIgruHdbzROoDG=''
   MPwXBVifFkcqTCtJlIgruHdbzROomW['saveinfo']['thumbnail']['poster']=MPwXBVifFkcqTCtJlIgruHdbzROoDS
   MPwXBVifFkcqTCtJlIgruHdbzROomW['saveinfo']['thumbnail']['thumb']=MPwXBVifFkcqTCtJlIgruHdbzROoDm
   MPwXBVifFkcqTCtJlIgruHdbzROomW['saveinfo']['thumbnail']['clearlogo']=MPwXBVifFkcqTCtJlIgruHdbzROoDG
   MPwXBVifFkcqTCtJlIgruHdbzROomW['saveinfo']['thumbnail']['fanart']=MPwXBVifFkcqTCtJlIgruHdbzROoDm
  else:
   MPwXBVifFkcqTCtJlIgruHdbzROoaW=MPwXBVifFkcqTCtJlIgruHdbzROoaS.API_DOMAIN+'/movie/contents/'+MPwXBVifFkcqTCtJlIgruHdbzROoSG 
   MPwXBVifFkcqTCtJlIgruHdbzROoaK=MPwXBVifFkcqTCtJlIgruHdbzROoaS.GetDefaultParams(login=MPwXBVifFkcqTCtJlIgruHdbzROoGy)
   MPwXBVifFkcqTCtJlIgruHdbzROoxS=MPwXBVifFkcqTCtJlIgruHdbzROoaS.callRequestCookies('Get',MPwXBVifFkcqTCtJlIgruHdbzROoaW,payload=MPwXBVifFkcqTCtJlIgruHdbzROoGU,params=MPwXBVifFkcqTCtJlIgruHdbzROoaK,headers=MPwXBVifFkcqTCtJlIgruHdbzROoGU,cookies=MPwXBVifFkcqTCtJlIgruHdbzROoGU)
   MPwXBVifFkcqTCtJlIgruHdbzROoxD=json.loads(MPwXBVifFkcqTCtJlIgruHdbzROoxS.text)
   if not('title' in MPwXBVifFkcqTCtJlIgruHdbzROoxD):return{}
   MPwXBVifFkcqTCtJlIgruHdbzROoGa=MPwXBVifFkcqTCtJlIgruHdbzROoxD
   MPwXBVifFkcqTCtJlIgruHdbzROoGx=MPwXBVifFkcqTCtJlIgruHdbzROoGa.get('title')
   MPwXBVifFkcqTCtJlIgruHdbzROomW['saveinfo']['infoLabels']['title']=MPwXBVifFkcqTCtJlIgruHdbzROoGx
   if MPwXBVifFkcqTCtJlIgruHdbzROoGa.get('targetage')=='18' or MPwXBVifFkcqTCtJlIgruHdbzROoGa.get('targetage')=='19' or MPwXBVifFkcqTCtJlIgruHdbzROoGa.get('targetage')=='21':
    MPwXBVifFkcqTCtJlIgruHdbzROoGx +=u' (%s)'%(MPwXBVifFkcqTCtJlIgruHdbzROoGa.get('targetage'))
   MPwXBVifFkcqTCtJlIgruHdbzROomW['saveinfo']['title'] =MPwXBVifFkcqTCtJlIgruHdbzROoGx
   MPwXBVifFkcqTCtJlIgruHdbzROomW['saveinfo']['infoLabels']['mpaa'] =MPwXBVifFkcqTCtJlIgruHdbzROoGa.get('targetage')
   MPwXBVifFkcqTCtJlIgruHdbzROomW['saveinfo']['infoLabels']['plot'] =MPwXBVifFkcqTCtJlIgruHdbzROoGa.get('synopsis').replace('<br>','\n')
   MPwXBVifFkcqTCtJlIgruHdbzROomW['saveinfo']['infoLabels']['duration']=MPwXBVifFkcqTCtJlIgruHdbzROoGa.get('playtime')
   MPwXBVifFkcqTCtJlIgruHdbzROomW['saveinfo']['infoLabels']['country']=MPwXBVifFkcqTCtJlIgruHdbzROoGa.get('country')
   MPwXBVifFkcqTCtJlIgruHdbzROomW['saveinfo']['infoLabels']['studio'] =MPwXBVifFkcqTCtJlIgruHdbzROoGa.get('cpname')
   if MPwXBVifFkcqTCtJlIgruHdbzROoGa.get('releasedate')!='':
    MPwXBVifFkcqTCtJlIgruHdbzROomW['saveinfo']['infoLabels']['year'] =MPwXBVifFkcqTCtJlIgruHdbzROoGa.get('releasedate')[:4]
    MPwXBVifFkcqTCtJlIgruHdbzROomW['saveinfo']['infoLabels']['premiered']=MPwXBVifFkcqTCtJlIgruHdbzROoGa.get('releasedate')
   MPwXBVifFkcqTCtJlIgruHdbzROoGS=[]
   for MPwXBVifFkcqTCtJlIgruHdbzROoGD in MPwXBVifFkcqTCtJlIgruHdbzROoGa['actors']['list']:MPwXBVifFkcqTCtJlIgruHdbzROoGS.append(MPwXBVifFkcqTCtJlIgruHdbzROoGD.get('text'))
   if MPwXBVifFkcqTCtJlIgruHdbzROoGh(MPwXBVifFkcqTCtJlIgruHdbzROoGS)>0:
    if MPwXBVifFkcqTCtJlIgruHdbzROoGS[0]!='':MPwXBVifFkcqTCtJlIgruHdbzROomW['saveinfo']['infoLabels']['cast']=MPwXBVifFkcqTCtJlIgruHdbzROoGS
   MPwXBVifFkcqTCtJlIgruHdbzROoGm=[]
   for MPwXBVifFkcqTCtJlIgruHdbzROoGY in MPwXBVifFkcqTCtJlIgruHdbzROoGa['directors']['list']:MPwXBVifFkcqTCtJlIgruHdbzROoGm.append(MPwXBVifFkcqTCtJlIgruHdbzROoGY.get('text'))
   if MPwXBVifFkcqTCtJlIgruHdbzROoGh(MPwXBVifFkcqTCtJlIgruHdbzROoGm)>0:
    if MPwXBVifFkcqTCtJlIgruHdbzROoGm[0]!='':MPwXBVifFkcqTCtJlIgruHdbzROomW['saveinfo']['infoLabels']['director']=MPwXBVifFkcqTCtJlIgruHdbzROoGm
   MPwXBVifFkcqTCtJlIgruHdbzROoxy=[]
   for MPwXBVifFkcqTCtJlIgruHdbzROoGE in MPwXBVifFkcqTCtJlIgruHdbzROoGa['genre']['list']:MPwXBVifFkcqTCtJlIgruHdbzROoxy.append(MPwXBVifFkcqTCtJlIgruHdbzROoGE.get('text'))
   if MPwXBVifFkcqTCtJlIgruHdbzROoGh(MPwXBVifFkcqTCtJlIgruHdbzROoxy)>0:
    if MPwXBVifFkcqTCtJlIgruHdbzROoxy[0]!='':MPwXBVifFkcqTCtJlIgruHdbzROomW['saveinfo']['infoLabels']['genre']=MPwXBVifFkcqTCtJlIgruHdbzROoxy
   MPwXBVifFkcqTCtJlIgruHdbzROoDS ='https://%s'%MPwXBVifFkcqTCtJlIgruHdbzROoGa['image']
   MPwXBVifFkcqTCtJlIgruHdbzROomW['saveinfo']['thumbnail']['poster'] =MPwXBVifFkcqTCtJlIgruHdbzROoDS
   MPwXBVifFkcqTCtJlIgruHdbzROomW['saveinfo']['thumbnail']['thumb'] =MPwXBVifFkcqTCtJlIgruHdbzROoDS
  return MPwXBVifFkcqTCtJlIgruHdbzROomW
# Created by pyminifier (https://github.com/liftoff/pyminifier)
