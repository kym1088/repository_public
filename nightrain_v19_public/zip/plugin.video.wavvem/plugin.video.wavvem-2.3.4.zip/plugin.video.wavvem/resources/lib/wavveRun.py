__author__="NightRain"
qOksalnUBApmLyKDNSHEzWIMQdrXfG=object
qOksalnUBApmLyKDNSHEzWIMQdrXfF=None
qOksalnUBApmLyKDNSHEzWIMQdrXfY=int
qOksalnUBApmLyKDNSHEzWIMQdrXfx=True
qOksalnUBApmLyKDNSHEzWIMQdrXfP=False
qOksalnUBApmLyKDNSHEzWIMQdrXfv=type
qOksalnUBApmLyKDNSHEzWIMQdrXfg=dict
qOksalnUBApmLyKDNSHEzWIMQdrXfT=len
qOksalnUBApmLyKDNSHEzWIMQdrXfw=range
qOksalnUBApmLyKDNSHEzWIMQdrXfo=str
qOksalnUBApmLyKDNSHEzWIMQdrXfc=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import json
qOksalnUBApmLyKDNSHEzWIMQdrXeG=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://www.wavve.com/supermultisection/GN51','icon':'home.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&uicode=VN500','page':'1','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?WeekDay=all&broadcastid=1390539&contenttype=vod&genre=01&orderby=viewtime&uicode=VN4&uiparent=FN0&uirank=0&uitype=VN4','page':'1','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?WeekDay=all&broadcastid=1311034&contenttype=vod&genre=02&orderby=viewtime&uicode=VN3&uiparent=FN0&uirank=0&uitype=VN3','page':'1','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'1','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'modifydate','ordernm':'업데이트순','icon':''},{'title':'프로야구 - 경기중 시청가능','mode':'GAME_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'(웨이브) 검색','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'(웨이브) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
qOksalnUBApmLyKDNSHEzWIMQdrXeF=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
qOksalnUBApmLyKDNSHEzWIMQdrXeY=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
qOksalnUBApmLyKDNSHEzWIMQdrXex =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
qOksalnUBApmLyKDNSHEzWIMQdrXeP=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_searched.txt'))
from wavveCore import*
class qOksalnUBApmLyKDNSHEzWIMQdrXeR(qOksalnUBApmLyKDNSHEzWIMQdrXfG):
 def __init__(qOksalnUBApmLyKDNSHEzWIMQdrXef,qOksalnUBApmLyKDNSHEzWIMQdrXev,qOksalnUBApmLyKDNSHEzWIMQdrXeg,qOksalnUBApmLyKDNSHEzWIMQdrXeT):
  qOksalnUBApmLyKDNSHEzWIMQdrXef._addon_url =qOksalnUBApmLyKDNSHEzWIMQdrXev
  qOksalnUBApmLyKDNSHEzWIMQdrXef._addon_handle=qOksalnUBApmLyKDNSHEzWIMQdrXeg
  qOksalnUBApmLyKDNSHEzWIMQdrXef.main_params =qOksalnUBApmLyKDNSHEzWIMQdrXeT
  qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj =MPwXBVifFkcqTCtJlIgruHdbzROoax() 
 def addon_noti(qOksalnUBApmLyKDNSHEzWIMQdrXef,sting):
  try:
   qOksalnUBApmLyKDNSHEzWIMQdrXeo=xbmcgui.Dialog()
   qOksalnUBApmLyKDNSHEzWIMQdrXeo.notification(__addonname__,sting)
  except:
   qOksalnUBApmLyKDNSHEzWIMQdrXfF
 def addon_log(qOksalnUBApmLyKDNSHEzWIMQdrXef,string):
  try:
   qOksalnUBApmLyKDNSHEzWIMQdrXec=string.encode('utf-8','ignore')
  except:
   qOksalnUBApmLyKDNSHEzWIMQdrXec='addonException: addon_log'
  qOksalnUBApmLyKDNSHEzWIMQdrXeb=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,qOksalnUBApmLyKDNSHEzWIMQdrXec),level=qOksalnUBApmLyKDNSHEzWIMQdrXeb)
 def get_keyboard_input(qOksalnUBApmLyKDNSHEzWIMQdrXef,qOksalnUBApmLyKDNSHEzWIMQdrXRg):
  qOksalnUBApmLyKDNSHEzWIMQdrXeu=qOksalnUBApmLyKDNSHEzWIMQdrXfF
  kb=xbmc.Keyboard()
  kb.setHeading(qOksalnUBApmLyKDNSHEzWIMQdrXRg)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   qOksalnUBApmLyKDNSHEzWIMQdrXeu=kb.getText()
  return qOksalnUBApmLyKDNSHEzWIMQdrXeu
 def get_settings_account(qOksalnUBApmLyKDNSHEzWIMQdrXef):
  qOksalnUBApmLyKDNSHEzWIMQdrXet =__addon__.getSetting('id')
  qOksalnUBApmLyKDNSHEzWIMQdrXeh =__addon__.getSetting('pw')
  qOksalnUBApmLyKDNSHEzWIMQdrXej=qOksalnUBApmLyKDNSHEzWIMQdrXfY(__addon__.getSetting('selected_profile'))
  return(qOksalnUBApmLyKDNSHEzWIMQdrXet,qOksalnUBApmLyKDNSHEzWIMQdrXeh,qOksalnUBApmLyKDNSHEzWIMQdrXej)
 def get_settings_totalsearch(qOksalnUBApmLyKDNSHEzWIMQdrXef):
  qOksalnUBApmLyKDNSHEzWIMQdrXeJ =qOksalnUBApmLyKDNSHEzWIMQdrXfx if __addon__.getSetting('local_search')=='true' else qOksalnUBApmLyKDNSHEzWIMQdrXfP
  qOksalnUBApmLyKDNSHEzWIMQdrXei=qOksalnUBApmLyKDNSHEzWIMQdrXfx if __addon__.getSetting('local_history')=='true' else qOksalnUBApmLyKDNSHEzWIMQdrXfP
  qOksalnUBApmLyKDNSHEzWIMQdrXeC =qOksalnUBApmLyKDNSHEzWIMQdrXfx if __addon__.getSetting('total_search')=='true' else qOksalnUBApmLyKDNSHEzWIMQdrXfP
  qOksalnUBApmLyKDNSHEzWIMQdrXeV=qOksalnUBApmLyKDNSHEzWIMQdrXfx if __addon__.getSetting('total_history')=='true' else qOksalnUBApmLyKDNSHEzWIMQdrXfP
  qOksalnUBApmLyKDNSHEzWIMQdrXRe=qOksalnUBApmLyKDNSHEzWIMQdrXfx if __addon__.getSetting('menu_bookmark')=='true' else qOksalnUBApmLyKDNSHEzWIMQdrXfP
  return(qOksalnUBApmLyKDNSHEzWIMQdrXeJ,qOksalnUBApmLyKDNSHEzWIMQdrXei,qOksalnUBApmLyKDNSHEzWIMQdrXeC,qOksalnUBApmLyKDNSHEzWIMQdrXeV,qOksalnUBApmLyKDNSHEzWIMQdrXRe)
 def get_settings_makebookmark(qOksalnUBApmLyKDNSHEzWIMQdrXef):
  return qOksalnUBApmLyKDNSHEzWIMQdrXfx if __addon__.getSetting('make_bookmark')=='true' else qOksalnUBApmLyKDNSHEzWIMQdrXfP
 def get_settings_play(qOksalnUBApmLyKDNSHEzWIMQdrXef):
  qOksalnUBApmLyKDNSHEzWIMQdrXRG={'enable_hdr':qOksalnUBApmLyKDNSHEzWIMQdrXfx if __addon__.getSetting('enable_hdr')=='true' else qOksalnUBApmLyKDNSHEzWIMQdrXfP,}
  if qOksalnUBApmLyKDNSHEzWIMQdrXRG['enable_hdr']==qOksalnUBApmLyKDNSHEzWIMQdrXfx:
   if qOksalnUBApmLyKDNSHEzWIMQdrXef.get_selQuality()<1080:qOksalnUBApmLyKDNSHEzWIMQdrXRG['enable_hdr']=qOksalnUBApmLyKDNSHEzWIMQdrXfP
  return(qOksalnUBApmLyKDNSHEzWIMQdrXRG)
 def get_selQuality(qOksalnUBApmLyKDNSHEzWIMQdrXef):
  try:
   qOksalnUBApmLyKDNSHEzWIMQdrXRF=[1080,720,480,360]
   qOksalnUBApmLyKDNSHEzWIMQdrXRY=qOksalnUBApmLyKDNSHEzWIMQdrXfY(__addon__.getSetting('selected_quality'))
   return qOksalnUBApmLyKDNSHEzWIMQdrXRF[qOksalnUBApmLyKDNSHEzWIMQdrXRY]
  except:
   qOksalnUBApmLyKDNSHEzWIMQdrXfF
  return 1080 
 def get_settings_exclusion21(qOksalnUBApmLyKDNSHEzWIMQdrXef):
  qOksalnUBApmLyKDNSHEzWIMQdrXRx =__addon__.getSetting('exclusion21')
  if qOksalnUBApmLyKDNSHEzWIMQdrXRx=='false':
   return qOksalnUBApmLyKDNSHEzWIMQdrXfP
  else:
   return qOksalnUBApmLyKDNSHEzWIMQdrXfx
 def get_settings_direct_replay(qOksalnUBApmLyKDNSHEzWIMQdrXef):
  qOksalnUBApmLyKDNSHEzWIMQdrXRP=qOksalnUBApmLyKDNSHEzWIMQdrXfY(__addon__.getSetting('direct_replay'))
  if qOksalnUBApmLyKDNSHEzWIMQdrXRP==0:
   return qOksalnUBApmLyKDNSHEzWIMQdrXfP
  else:
   return qOksalnUBApmLyKDNSHEzWIMQdrXfx
 def set_winEpisodeOrderby(qOksalnUBApmLyKDNSHEzWIMQdrXef,qOksalnUBApmLyKDNSHEzWIMQdrXRf):
  __addon__.setSetting('wavve_orderby',qOksalnUBApmLyKDNSHEzWIMQdrXRf)
 def get_winEpisodeOrderby(qOksalnUBApmLyKDNSHEzWIMQdrXef):
  qOksalnUBApmLyKDNSHEzWIMQdrXRf=__addon__.getSetting('wavve_orderby')
  if qOksalnUBApmLyKDNSHEzWIMQdrXRf in['',qOksalnUBApmLyKDNSHEzWIMQdrXfF]:qOksalnUBApmLyKDNSHEzWIMQdrXRf='desc'
  return qOksalnUBApmLyKDNSHEzWIMQdrXRf
 def add_dir(qOksalnUBApmLyKDNSHEzWIMQdrXef,label,sublabel='',img='',infoLabels=qOksalnUBApmLyKDNSHEzWIMQdrXfF,isFolder=qOksalnUBApmLyKDNSHEzWIMQdrXfx,params='',isLink=qOksalnUBApmLyKDNSHEzWIMQdrXfP,ContextMenu=qOksalnUBApmLyKDNSHEzWIMQdrXfF):
  qOksalnUBApmLyKDNSHEzWIMQdrXRv='%s?%s'%(qOksalnUBApmLyKDNSHEzWIMQdrXef._addon_url,urllib.parse.urlencode(params))
  if sublabel:qOksalnUBApmLyKDNSHEzWIMQdrXRg='%s < %s >'%(label,sublabel)
  else: qOksalnUBApmLyKDNSHEzWIMQdrXRg=label
  if not img:img='DefaultFolder.png'
  qOksalnUBApmLyKDNSHEzWIMQdrXRT=xbmcgui.ListItem(qOksalnUBApmLyKDNSHEzWIMQdrXRg)
  if qOksalnUBApmLyKDNSHEzWIMQdrXfv(img)==qOksalnUBApmLyKDNSHEzWIMQdrXfg:
   qOksalnUBApmLyKDNSHEzWIMQdrXRT.setArt(img)
  else:
   qOksalnUBApmLyKDNSHEzWIMQdrXRT.setArt({'thumb':img,'poster':img})
  if infoLabels:qOksalnUBApmLyKDNSHEzWIMQdrXRT.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   qOksalnUBApmLyKDNSHEzWIMQdrXRT.setProperty('IsPlayable','true')
  if ContextMenu:qOksalnUBApmLyKDNSHEzWIMQdrXRT.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(qOksalnUBApmLyKDNSHEzWIMQdrXef._addon_handle,qOksalnUBApmLyKDNSHEzWIMQdrXRv,qOksalnUBApmLyKDNSHEzWIMQdrXRT,isFolder)
 def dp_Main_List(qOksalnUBApmLyKDNSHEzWIMQdrXef):
  (qOksalnUBApmLyKDNSHEzWIMQdrXeJ,qOksalnUBApmLyKDNSHEzWIMQdrXei,qOksalnUBApmLyKDNSHEzWIMQdrXeC,qOksalnUBApmLyKDNSHEzWIMQdrXeV,qOksalnUBApmLyKDNSHEzWIMQdrXRe)=qOksalnUBApmLyKDNSHEzWIMQdrXef.get_settings_totalsearch()
  for qOksalnUBApmLyKDNSHEzWIMQdrXRw in qOksalnUBApmLyKDNSHEzWIMQdrXeG:
   qOksalnUBApmLyKDNSHEzWIMQdrXRg=qOksalnUBApmLyKDNSHEzWIMQdrXRw.get('title')
   qOksalnUBApmLyKDNSHEzWIMQdrXRo=''
   if qOksalnUBApmLyKDNSHEzWIMQdrXRw.get('mode')=='SEARCH_GROUP' and qOksalnUBApmLyKDNSHEzWIMQdrXeJ ==qOksalnUBApmLyKDNSHEzWIMQdrXfP:continue
   elif qOksalnUBApmLyKDNSHEzWIMQdrXRw.get('mode')=='SEARCH_HISTORY' and qOksalnUBApmLyKDNSHEzWIMQdrXei==qOksalnUBApmLyKDNSHEzWIMQdrXfP:continue
   elif qOksalnUBApmLyKDNSHEzWIMQdrXRw.get('mode')=='TOTAL_SEARCH' and qOksalnUBApmLyKDNSHEzWIMQdrXeC ==qOksalnUBApmLyKDNSHEzWIMQdrXfP:continue
   elif qOksalnUBApmLyKDNSHEzWIMQdrXRw.get('mode')=='TOTAL_HISTORY' and qOksalnUBApmLyKDNSHEzWIMQdrXeV==qOksalnUBApmLyKDNSHEzWIMQdrXfP:continue
   elif qOksalnUBApmLyKDNSHEzWIMQdrXRw.get('mode')=='MENU_BOOKMARK' and qOksalnUBApmLyKDNSHEzWIMQdrXRe==qOksalnUBApmLyKDNSHEzWIMQdrXfP:continue
   qOksalnUBApmLyKDNSHEzWIMQdrXRc={'mode':qOksalnUBApmLyKDNSHEzWIMQdrXRw.get('mode'),'sCode':qOksalnUBApmLyKDNSHEzWIMQdrXRw.get('sCode'),'sIndex':qOksalnUBApmLyKDNSHEzWIMQdrXRw.get('sIndex'),'sType':qOksalnUBApmLyKDNSHEzWIMQdrXRw.get('sType'),'suburl':qOksalnUBApmLyKDNSHEzWIMQdrXRw.get('suburl'),'subapi':qOksalnUBApmLyKDNSHEzWIMQdrXRw.get('subapi'),'page':qOksalnUBApmLyKDNSHEzWIMQdrXRw.get('page'),'orderby':qOksalnUBApmLyKDNSHEzWIMQdrXRw.get('orderby'),'ordernm':qOksalnUBApmLyKDNSHEzWIMQdrXRw.get('ordernm')}
   if qOksalnUBApmLyKDNSHEzWIMQdrXRw.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    qOksalnUBApmLyKDNSHEzWIMQdrXRb=qOksalnUBApmLyKDNSHEzWIMQdrXfP
    qOksalnUBApmLyKDNSHEzWIMQdrXRu =qOksalnUBApmLyKDNSHEzWIMQdrXfx
   else:
    qOksalnUBApmLyKDNSHEzWIMQdrXRb=qOksalnUBApmLyKDNSHEzWIMQdrXfx
    qOksalnUBApmLyKDNSHEzWIMQdrXRu =qOksalnUBApmLyKDNSHEzWIMQdrXfP
   if 'icon' in qOksalnUBApmLyKDNSHEzWIMQdrXRw:qOksalnUBApmLyKDNSHEzWIMQdrXRo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',qOksalnUBApmLyKDNSHEzWIMQdrXRw.get('icon')) 
   qOksalnUBApmLyKDNSHEzWIMQdrXef.add_dir(qOksalnUBApmLyKDNSHEzWIMQdrXRg,sublabel='',img=qOksalnUBApmLyKDNSHEzWIMQdrXRo,infoLabels=qOksalnUBApmLyKDNSHEzWIMQdrXfF,isFolder=qOksalnUBApmLyKDNSHEzWIMQdrXRb,params=qOksalnUBApmLyKDNSHEzWIMQdrXRc,isLink=qOksalnUBApmLyKDNSHEzWIMQdrXRu)
  xbmcplugin.endOfDirectory(qOksalnUBApmLyKDNSHEzWIMQdrXef._addon_handle,cacheToDisc=qOksalnUBApmLyKDNSHEzWIMQdrXfx)
 def dp_Search_Group(qOksalnUBApmLyKDNSHEzWIMQdrXef,args):
  if 'search_key' in args:
   qOksalnUBApmLyKDNSHEzWIMQdrXRj=args.get('search_key')
  else:
   qOksalnUBApmLyKDNSHEzWIMQdrXRj=qOksalnUBApmLyKDNSHEzWIMQdrXef.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not qOksalnUBApmLyKDNSHEzWIMQdrXRj:
    return
  for qOksalnUBApmLyKDNSHEzWIMQdrXRJ in qOksalnUBApmLyKDNSHEzWIMQdrXeF:
   qOksalnUBApmLyKDNSHEzWIMQdrXRi =qOksalnUBApmLyKDNSHEzWIMQdrXRJ.get('mode')
   qOksalnUBApmLyKDNSHEzWIMQdrXRC=qOksalnUBApmLyKDNSHEzWIMQdrXRJ.get('sType')
   qOksalnUBApmLyKDNSHEzWIMQdrXRg=qOksalnUBApmLyKDNSHEzWIMQdrXRJ.get('title')
   (qOksalnUBApmLyKDNSHEzWIMQdrXRV,qOksalnUBApmLyKDNSHEzWIMQdrXGe)=qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.Get_Search_List(qOksalnUBApmLyKDNSHEzWIMQdrXRj,qOksalnUBApmLyKDNSHEzWIMQdrXRC,1,exclusion21=qOksalnUBApmLyKDNSHEzWIMQdrXef.get_settings_exclusion21())
   qOksalnUBApmLyKDNSHEzWIMQdrXGR={'plot':'검색어 : '+qOksalnUBApmLyKDNSHEzWIMQdrXRj+'\n\n'+qOksalnUBApmLyKDNSHEzWIMQdrXef.Search_FreeList(qOksalnUBApmLyKDNSHEzWIMQdrXRV)}
   qOksalnUBApmLyKDNSHEzWIMQdrXRc={'mode':qOksalnUBApmLyKDNSHEzWIMQdrXRi,'sType':qOksalnUBApmLyKDNSHEzWIMQdrXRC,'search_key':qOksalnUBApmLyKDNSHEzWIMQdrXRj,'page':'1',}
   qOksalnUBApmLyKDNSHEzWIMQdrXef.add_dir(qOksalnUBApmLyKDNSHEzWIMQdrXRg,sublabel='',img='',infoLabels=qOksalnUBApmLyKDNSHEzWIMQdrXGR,isFolder=qOksalnUBApmLyKDNSHEzWIMQdrXfx,params=qOksalnUBApmLyKDNSHEzWIMQdrXRc)
  if qOksalnUBApmLyKDNSHEzWIMQdrXfT(qOksalnUBApmLyKDNSHEzWIMQdrXeF)>0:xbmcplugin.endOfDirectory(qOksalnUBApmLyKDNSHEzWIMQdrXef._addon_handle,cacheToDisc=qOksalnUBApmLyKDNSHEzWIMQdrXfx)
  qOksalnUBApmLyKDNSHEzWIMQdrXef.Save_Searched_List(qOksalnUBApmLyKDNSHEzWIMQdrXRj)
 def Search_FreeList(qOksalnUBApmLyKDNSHEzWIMQdrXef,search_list):
  qOksalnUBApmLyKDNSHEzWIMQdrXGF=''
  qOksalnUBApmLyKDNSHEzWIMQdrXGY=7
  try:
   if qOksalnUBApmLyKDNSHEzWIMQdrXfT(search_list)==0:return '검색결과 없음'
   for i in qOksalnUBApmLyKDNSHEzWIMQdrXfw(qOksalnUBApmLyKDNSHEzWIMQdrXfT(search_list)):
    if i>=qOksalnUBApmLyKDNSHEzWIMQdrXGY:
     qOksalnUBApmLyKDNSHEzWIMQdrXGF=qOksalnUBApmLyKDNSHEzWIMQdrXGF+'...'
     break
    qOksalnUBApmLyKDNSHEzWIMQdrXGF=qOksalnUBApmLyKDNSHEzWIMQdrXGF+search_list[i]['title']+'\n'
  except:
   return ''
  return qOksalnUBApmLyKDNSHEzWIMQdrXGF
 def dp_Watch_Group(qOksalnUBApmLyKDNSHEzWIMQdrXef,args):
  for qOksalnUBApmLyKDNSHEzWIMQdrXGx in qOksalnUBApmLyKDNSHEzWIMQdrXeY:
   qOksalnUBApmLyKDNSHEzWIMQdrXRg=qOksalnUBApmLyKDNSHEzWIMQdrXGx.get('title')
   qOksalnUBApmLyKDNSHEzWIMQdrXRc={'mode':qOksalnUBApmLyKDNSHEzWIMQdrXGx.get('mode'),'sType':qOksalnUBApmLyKDNSHEzWIMQdrXGx.get('sType')}
   qOksalnUBApmLyKDNSHEzWIMQdrXef.add_dir(qOksalnUBApmLyKDNSHEzWIMQdrXRg,sublabel='',img='',infoLabels=qOksalnUBApmLyKDNSHEzWIMQdrXfF,isFolder=qOksalnUBApmLyKDNSHEzWIMQdrXfx,params=qOksalnUBApmLyKDNSHEzWIMQdrXRc)
  if qOksalnUBApmLyKDNSHEzWIMQdrXfT(qOksalnUBApmLyKDNSHEzWIMQdrXeY)>0:xbmcplugin.endOfDirectory(qOksalnUBApmLyKDNSHEzWIMQdrXef._addon_handle,cacheToDisc=qOksalnUBApmLyKDNSHEzWIMQdrXfx)
 def dp_Search_History(qOksalnUBApmLyKDNSHEzWIMQdrXef,args):
  qOksalnUBApmLyKDNSHEzWIMQdrXGP=qOksalnUBApmLyKDNSHEzWIMQdrXef.Load_List_File('search')
  for qOksalnUBApmLyKDNSHEzWIMQdrXGf in qOksalnUBApmLyKDNSHEzWIMQdrXGP:
   qOksalnUBApmLyKDNSHEzWIMQdrXGv=qOksalnUBApmLyKDNSHEzWIMQdrXfg(urllib.parse.parse_qsl(qOksalnUBApmLyKDNSHEzWIMQdrXGf))
   qOksalnUBApmLyKDNSHEzWIMQdrXGg=qOksalnUBApmLyKDNSHEzWIMQdrXGv.get('skey').strip()
   qOksalnUBApmLyKDNSHEzWIMQdrXRc={'mode':'SEARCH_GROUP','search_key':qOksalnUBApmLyKDNSHEzWIMQdrXGg,}
   qOksalnUBApmLyKDNSHEzWIMQdrXGT={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':qOksalnUBApmLyKDNSHEzWIMQdrXGg,'vType':'-',}
   qOksalnUBApmLyKDNSHEzWIMQdrXGw=urllib.parse.urlencode(qOksalnUBApmLyKDNSHEzWIMQdrXGT)
   qOksalnUBApmLyKDNSHEzWIMQdrXGo=[('선택된 검색어 ( %s ) 삭제'%(qOksalnUBApmLyKDNSHEzWIMQdrXGg),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(qOksalnUBApmLyKDNSHEzWIMQdrXGw))]
   qOksalnUBApmLyKDNSHEzWIMQdrXef.add_dir(qOksalnUBApmLyKDNSHEzWIMQdrXGg,sublabel='',img=qOksalnUBApmLyKDNSHEzWIMQdrXfF,infoLabels=qOksalnUBApmLyKDNSHEzWIMQdrXfF,isFolder=qOksalnUBApmLyKDNSHEzWIMQdrXfx,params=qOksalnUBApmLyKDNSHEzWIMQdrXRc,ContextMenu=qOksalnUBApmLyKDNSHEzWIMQdrXGo)
  qOksalnUBApmLyKDNSHEzWIMQdrXGc={'plot':'검색목록 전체를 삭제합니다.'}
  qOksalnUBApmLyKDNSHEzWIMQdrXRg='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  qOksalnUBApmLyKDNSHEzWIMQdrXRc={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  qOksalnUBApmLyKDNSHEzWIMQdrXRo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  qOksalnUBApmLyKDNSHEzWIMQdrXef.add_dir(qOksalnUBApmLyKDNSHEzWIMQdrXRg,sublabel='',img=qOksalnUBApmLyKDNSHEzWIMQdrXRo,infoLabels=qOksalnUBApmLyKDNSHEzWIMQdrXGc,isFolder=qOksalnUBApmLyKDNSHEzWIMQdrXfP,params=qOksalnUBApmLyKDNSHEzWIMQdrXRc,isLink=qOksalnUBApmLyKDNSHEzWIMQdrXfx)
  xbmcplugin.endOfDirectory(qOksalnUBApmLyKDNSHEzWIMQdrXef._addon_handle,cacheToDisc=qOksalnUBApmLyKDNSHEzWIMQdrXfP)
 def dp_Search_List(qOksalnUBApmLyKDNSHEzWIMQdrXef,args):
  qOksalnUBApmLyKDNSHEzWIMQdrXRC =args.get('sType')
  qOksalnUBApmLyKDNSHEzWIMQdrXGb =qOksalnUBApmLyKDNSHEzWIMQdrXfY(args.get('page'))
  if 'search_key' in args:
   qOksalnUBApmLyKDNSHEzWIMQdrXRj=args.get('search_key')
  else:
   qOksalnUBApmLyKDNSHEzWIMQdrXRj=qOksalnUBApmLyKDNSHEzWIMQdrXef.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not qOksalnUBApmLyKDNSHEzWIMQdrXRj:
    xbmcplugin.endOfDirectory(qOksalnUBApmLyKDNSHEzWIMQdrXef._addon_handle)
    return
  qOksalnUBApmLyKDNSHEzWIMQdrXGu,qOksalnUBApmLyKDNSHEzWIMQdrXGe=qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.Get_Search_List(qOksalnUBApmLyKDNSHEzWIMQdrXRj,qOksalnUBApmLyKDNSHEzWIMQdrXRC,qOksalnUBApmLyKDNSHEzWIMQdrXGb,exclusion21=qOksalnUBApmLyKDNSHEzWIMQdrXef.get_settings_exclusion21())
  for qOksalnUBApmLyKDNSHEzWIMQdrXGt in qOksalnUBApmLyKDNSHEzWIMQdrXGu:
   qOksalnUBApmLyKDNSHEzWIMQdrXGh =qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('videoid')
   qOksalnUBApmLyKDNSHEzWIMQdrXGj =qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('vidtype')
   qOksalnUBApmLyKDNSHEzWIMQdrXRg =qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('title')
   qOksalnUBApmLyKDNSHEzWIMQdrXGJ=qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('thumbnail')
   qOksalnUBApmLyKDNSHEzWIMQdrXGi =qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('age')
   if qOksalnUBApmLyKDNSHEzWIMQdrXGi=='18' or qOksalnUBApmLyKDNSHEzWIMQdrXGi=='19' or qOksalnUBApmLyKDNSHEzWIMQdrXGi=='21':qOksalnUBApmLyKDNSHEzWIMQdrXRg+=' (%s)'%(qOksalnUBApmLyKDNSHEzWIMQdrXGi)
   qOksalnUBApmLyKDNSHEzWIMQdrXGc={'mediatype':'tvshow' if qOksalnUBApmLyKDNSHEzWIMQdrXRC=='vod' else 'movie','mpaa':qOksalnUBApmLyKDNSHEzWIMQdrXGi,'title':qOksalnUBApmLyKDNSHEzWIMQdrXRg,'plot':qOksalnUBApmLyKDNSHEzWIMQdrXRg}
   if qOksalnUBApmLyKDNSHEzWIMQdrXRC=='vod':
    qOksalnUBApmLyKDNSHEzWIMQdrXRc={'mode':'EPISODE_LIST','seasonid':qOksalnUBApmLyKDNSHEzWIMQdrXGh,'page':'1',}
    qOksalnUBApmLyKDNSHEzWIMQdrXRb=qOksalnUBApmLyKDNSHEzWIMQdrXfx
   else:
    qOksalnUBApmLyKDNSHEzWIMQdrXRc={'mode':'MOVIE','contentid':qOksalnUBApmLyKDNSHEzWIMQdrXGh,'title':qOksalnUBApmLyKDNSHEzWIMQdrXRg,'thumbnail':qOksalnUBApmLyKDNSHEzWIMQdrXGJ,'age':qOksalnUBApmLyKDNSHEzWIMQdrXGi,}
    qOksalnUBApmLyKDNSHEzWIMQdrXRb=qOksalnUBApmLyKDNSHEzWIMQdrXfP
   qOksalnUBApmLyKDNSHEzWIMQdrXGo=[]
   qOksalnUBApmLyKDNSHEzWIMQdrXGC={'mode':'VIEW_DETAIL','values':{'videoid':qOksalnUBApmLyKDNSHEzWIMQdrXGh,'vidtype':'tvshow' if qOksalnUBApmLyKDNSHEzWIMQdrXRC=='vod' else 'movie','contenttype':qOksalnUBApmLyKDNSHEzWIMQdrXGj,}}
   qOksalnUBApmLyKDNSHEzWIMQdrXGV=json.dumps(qOksalnUBApmLyKDNSHEzWIMQdrXGC,separators=(',',':'))
   qOksalnUBApmLyKDNSHEzWIMQdrXGV=base64.standard_b64encode(qOksalnUBApmLyKDNSHEzWIMQdrXGV.encode()).decode('utf-8')
   qOksalnUBApmLyKDNSHEzWIMQdrXGV=qOksalnUBApmLyKDNSHEzWIMQdrXGV.replace('+','%2B')
   qOksalnUBApmLyKDNSHEzWIMQdrXFe='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(qOksalnUBApmLyKDNSHEzWIMQdrXGV)
   qOksalnUBApmLyKDNSHEzWIMQdrXGo.append(('상세정보 조회',qOksalnUBApmLyKDNSHEzWIMQdrXFe))
   if qOksalnUBApmLyKDNSHEzWIMQdrXef.get_settings_makebookmark():
    qOksalnUBApmLyKDNSHEzWIMQdrXGC={'videoid':qOksalnUBApmLyKDNSHEzWIMQdrXGh,'vidtype':'tvshow' if qOksalnUBApmLyKDNSHEzWIMQdrXRC=='vod' else 'movie','vtitle':qOksalnUBApmLyKDNSHEzWIMQdrXRg,'vsubtitle':'','contenttype':qOksalnUBApmLyKDNSHEzWIMQdrXGj,}
    qOksalnUBApmLyKDNSHEzWIMQdrXFR=json.dumps(qOksalnUBApmLyKDNSHEzWIMQdrXGC)
    qOksalnUBApmLyKDNSHEzWIMQdrXFR=urllib.parse.quote(qOksalnUBApmLyKDNSHEzWIMQdrXFR)
    qOksalnUBApmLyKDNSHEzWIMQdrXFe='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(qOksalnUBApmLyKDNSHEzWIMQdrXFR)
    qOksalnUBApmLyKDNSHEzWIMQdrXGo.append(('(통합) 찜 영상에 추가',qOksalnUBApmLyKDNSHEzWIMQdrXFe))
   qOksalnUBApmLyKDNSHEzWIMQdrXef.add_dir(qOksalnUBApmLyKDNSHEzWIMQdrXRg,sublabel='',img=qOksalnUBApmLyKDNSHEzWIMQdrXGJ,infoLabels=qOksalnUBApmLyKDNSHEzWIMQdrXGc,isFolder=qOksalnUBApmLyKDNSHEzWIMQdrXRb,params=qOksalnUBApmLyKDNSHEzWIMQdrXRc,ContextMenu=qOksalnUBApmLyKDNSHEzWIMQdrXGo)
  if qOksalnUBApmLyKDNSHEzWIMQdrXGe:
   qOksalnUBApmLyKDNSHEzWIMQdrXRc['mode'] ='SEARCH_LIST' 
   qOksalnUBApmLyKDNSHEzWIMQdrXRc['sType']=qOksalnUBApmLyKDNSHEzWIMQdrXRC 
   qOksalnUBApmLyKDNSHEzWIMQdrXRc['page'] =qOksalnUBApmLyKDNSHEzWIMQdrXfo(qOksalnUBApmLyKDNSHEzWIMQdrXGb+1)
   qOksalnUBApmLyKDNSHEzWIMQdrXRc['search_key']=qOksalnUBApmLyKDNSHEzWIMQdrXRj
   qOksalnUBApmLyKDNSHEzWIMQdrXRg='[B]%s >>[/B]'%'다음 페이지'
   qOksalnUBApmLyKDNSHEzWIMQdrXFG=qOksalnUBApmLyKDNSHEzWIMQdrXfo(qOksalnUBApmLyKDNSHEzWIMQdrXGb+1)
   qOksalnUBApmLyKDNSHEzWIMQdrXRo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   qOksalnUBApmLyKDNSHEzWIMQdrXef.add_dir(qOksalnUBApmLyKDNSHEzWIMQdrXRg,sublabel=qOksalnUBApmLyKDNSHEzWIMQdrXFG,img=qOksalnUBApmLyKDNSHEzWIMQdrXRo,infoLabels=qOksalnUBApmLyKDNSHEzWIMQdrXfF,isFolder=qOksalnUBApmLyKDNSHEzWIMQdrXfx,params=qOksalnUBApmLyKDNSHEzWIMQdrXRc)
  if qOksalnUBApmLyKDNSHEzWIMQdrXRC=='movie':xbmcplugin.setContent(qOksalnUBApmLyKDNSHEzWIMQdrXef._addon_handle,'movies')
  else:xbmcplugin.setContent(qOksalnUBApmLyKDNSHEzWIMQdrXef._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(qOksalnUBApmLyKDNSHEzWIMQdrXef._addon_handle,cacheToDisc=qOksalnUBApmLyKDNSHEzWIMQdrXfP)
 def dp_Watch_List(qOksalnUBApmLyKDNSHEzWIMQdrXef,args):
  qOksalnUBApmLyKDNSHEzWIMQdrXRC =args.get('sType')
  qOksalnUBApmLyKDNSHEzWIMQdrXRP=qOksalnUBApmLyKDNSHEzWIMQdrXef.get_settings_direct_replay()
  qOksalnUBApmLyKDNSHEzWIMQdrXGu=qOksalnUBApmLyKDNSHEzWIMQdrXef.Load_List_File(qOksalnUBApmLyKDNSHEzWIMQdrXRC)
  for qOksalnUBApmLyKDNSHEzWIMQdrXGt in qOksalnUBApmLyKDNSHEzWIMQdrXGu:
   qOksalnUBApmLyKDNSHEzWIMQdrXGv=qOksalnUBApmLyKDNSHEzWIMQdrXfg(urllib.parse.parse_qsl(qOksalnUBApmLyKDNSHEzWIMQdrXGt))
   qOksalnUBApmLyKDNSHEzWIMQdrXFY =qOksalnUBApmLyKDNSHEzWIMQdrXGv.get('code').strip()
   qOksalnUBApmLyKDNSHEzWIMQdrXRg =qOksalnUBApmLyKDNSHEzWIMQdrXGv.get('title').strip()
   qOksalnUBApmLyKDNSHEzWIMQdrXFG =qOksalnUBApmLyKDNSHEzWIMQdrXGv.get('subtitle').strip()
   if qOksalnUBApmLyKDNSHEzWIMQdrXFG=='None':qOksalnUBApmLyKDNSHEzWIMQdrXFG=''
   qOksalnUBApmLyKDNSHEzWIMQdrXGJ=qOksalnUBApmLyKDNSHEzWIMQdrXGv.get('img').strip()
   qOksalnUBApmLyKDNSHEzWIMQdrXGh =qOksalnUBApmLyKDNSHEzWIMQdrXGv.get('videoid').strip()
   try:
    qOksalnUBApmLyKDNSHEzWIMQdrXGJ=qOksalnUBApmLyKDNSHEzWIMQdrXGJ.replace('\'','\"')
    qOksalnUBApmLyKDNSHEzWIMQdrXGJ=json.loads(qOksalnUBApmLyKDNSHEzWIMQdrXGJ)
   except:
    qOksalnUBApmLyKDNSHEzWIMQdrXfF
   qOksalnUBApmLyKDNSHEzWIMQdrXGc={'plot':'%s\n%s'%(qOksalnUBApmLyKDNSHEzWIMQdrXRg,qOksalnUBApmLyKDNSHEzWIMQdrXFG)}
   if qOksalnUBApmLyKDNSHEzWIMQdrXRC=='vod':
    if qOksalnUBApmLyKDNSHEzWIMQdrXRP==qOksalnUBApmLyKDNSHEzWIMQdrXfP or qOksalnUBApmLyKDNSHEzWIMQdrXGh==qOksalnUBApmLyKDNSHEzWIMQdrXfF:
     qOksalnUBApmLyKDNSHEzWIMQdrXGc['mediatype']='tvshow'
     qOksalnUBApmLyKDNSHEzWIMQdrXRc={'mode':'SEASON_LIST','videoid':qOksalnUBApmLyKDNSHEzWIMQdrXGh,'vidtype':'contentid',}
     qOksalnUBApmLyKDNSHEzWIMQdrXRb=qOksalnUBApmLyKDNSHEzWIMQdrXfx
    else:
     qOksalnUBApmLyKDNSHEzWIMQdrXGc['mediatype']='episode'
     qOksalnUBApmLyKDNSHEzWIMQdrXRc={'mode':'VOD','programid':qOksalnUBApmLyKDNSHEzWIMQdrXFY,'contentid':qOksalnUBApmLyKDNSHEzWIMQdrXGh,'title':qOksalnUBApmLyKDNSHEzWIMQdrXRg,'subtitle':qOksalnUBApmLyKDNSHEzWIMQdrXFG,'thumbnail':qOksalnUBApmLyKDNSHEzWIMQdrXGJ}
     qOksalnUBApmLyKDNSHEzWIMQdrXRb=qOksalnUBApmLyKDNSHEzWIMQdrXfP
   else:
    qOksalnUBApmLyKDNSHEzWIMQdrXGc['mediatype']='movie'
    qOksalnUBApmLyKDNSHEzWIMQdrXRc={'mode':'MOVIE','contentid':qOksalnUBApmLyKDNSHEzWIMQdrXFY,'title':qOksalnUBApmLyKDNSHEzWIMQdrXRg,'subtitle':qOksalnUBApmLyKDNSHEzWIMQdrXFG,'thumbnail':qOksalnUBApmLyKDNSHEzWIMQdrXGJ}
    qOksalnUBApmLyKDNSHEzWIMQdrXRb=qOksalnUBApmLyKDNSHEzWIMQdrXfP
   qOksalnUBApmLyKDNSHEzWIMQdrXGT={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':qOksalnUBApmLyKDNSHEzWIMQdrXFY,'vType':qOksalnUBApmLyKDNSHEzWIMQdrXRC,}
   qOksalnUBApmLyKDNSHEzWIMQdrXGw=urllib.parse.urlencode(qOksalnUBApmLyKDNSHEzWIMQdrXGT)
   qOksalnUBApmLyKDNSHEzWIMQdrXGo=[('선택된 시청이력 ( %s ) 삭제'%(qOksalnUBApmLyKDNSHEzWIMQdrXRg),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(qOksalnUBApmLyKDNSHEzWIMQdrXGw))]
   qOksalnUBApmLyKDNSHEzWIMQdrXef.add_dir(qOksalnUBApmLyKDNSHEzWIMQdrXRg,sublabel=qOksalnUBApmLyKDNSHEzWIMQdrXFG,img=qOksalnUBApmLyKDNSHEzWIMQdrXGJ,infoLabels=qOksalnUBApmLyKDNSHEzWIMQdrXGc,isFolder=qOksalnUBApmLyKDNSHEzWIMQdrXRb,params=qOksalnUBApmLyKDNSHEzWIMQdrXRc,ContextMenu=qOksalnUBApmLyKDNSHEzWIMQdrXGo)
  qOksalnUBApmLyKDNSHEzWIMQdrXGc={'plot':'시청목록을 삭제합니다.'}
  qOksalnUBApmLyKDNSHEzWIMQdrXRg='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  qOksalnUBApmLyKDNSHEzWIMQdrXRc={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':qOksalnUBApmLyKDNSHEzWIMQdrXRC,}
  qOksalnUBApmLyKDNSHEzWIMQdrXRo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  qOksalnUBApmLyKDNSHEzWIMQdrXef.add_dir(qOksalnUBApmLyKDNSHEzWIMQdrXRg,sublabel='',img=qOksalnUBApmLyKDNSHEzWIMQdrXRo,infoLabels=qOksalnUBApmLyKDNSHEzWIMQdrXGc,isFolder=qOksalnUBApmLyKDNSHEzWIMQdrXfP,params=qOksalnUBApmLyKDNSHEzWIMQdrXRc,isLink=qOksalnUBApmLyKDNSHEzWIMQdrXfx)
  if qOksalnUBApmLyKDNSHEzWIMQdrXRC=='movie':xbmcplugin.setContent(qOksalnUBApmLyKDNSHEzWIMQdrXef._addon_handle,'movies')
  else:xbmcplugin.setContent(qOksalnUBApmLyKDNSHEzWIMQdrXef._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(qOksalnUBApmLyKDNSHEzWIMQdrXef._addon_handle,cacheToDisc=qOksalnUBApmLyKDNSHEzWIMQdrXfP)
 def Load_List_File(qOksalnUBApmLyKDNSHEzWIMQdrXef,stype): 
  try:
   if stype=='search':
    qOksalnUBApmLyKDNSHEzWIMQdrXFx=qOksalnUBApmLyKDNSHEzWIMQdrXeP
   elif stype in['vod','movie']:
    qOksalnUBApmLyKDNSHEzWIMQdrXFx=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   else:
    return[]
   fp=qOksalnUBApmLyKDNSHEzWIMQdrXfc(qOksalnUBApmLyKDNSHEzWIMQdrXFx,'r',-1,'utf-8')
   qOksalnUBApmLyKDNSHEzWIMQdrXFP=fp.readlines()
   fp.close()
  except:
   qOksalnUBApmLyKDNSHEzWIMQdrXFP=[]
  return qOksalnUBApmLyKDNSHEzWIMQdrXFP
 def Save_Watched_List(qOksalnUBApmLyKDNSHEzWIMQdrXef,qOksalnUBApmLyKDNSHEzWIMQdrXPw,qOksalnUBApmLyKDNSHEzWIMQdrXeT):
  try:
   qOksalnUBApmLyKDNSHEzWIMQdrXFf=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%qOksalnUBApmLyKDNSHEzWIMQdrXPw))
   qOksalnUBApmLyKDNSHEzWIMQdrXFv=qOksalnUBApmLyKDNSHEzWIMQdrXef.Load_List_File(qOksalnUBApmLyKDNSHEzWIMQdrXPw) 
   fp=qOksalnUBApmLyKDNSHEzWIMQdrXfc(qOksalnUBApmLyKDNSHEzWIMQdrXFf,'w',-1,'utf-8')
   qOksalnUBApmLyKDNSHEzWIMQdrXFg=urllib.parse.urlencode(qOksalnUBApmLyKDNSHEzWIMQdrXeT)
   qOksalnUBApmLyKDNSHEzWIMQdrXFg=qOksalnUBApmLyKDNSHEzWIMQdrXFg+'\n'
   fp.write(qOksalnUBApmLyKDNSHEzWIMQdrXFg)
   qOksalnUBApmLyKDNSHEzWIMQdrXFT=0
   for qOksalnUBApmLyKDNSHEzWIMQdrXFw in qOksalnUBApmLyKDNSHEzWIMQdrXFv:
    qOksalnUBApmLyKDNSHEzWIMQdrXFo=qOksalnUBApmLyKDNSHEzWIMQdrXfg(urllib.parse.parse_qsl(qOksalnUBApmLyKDNSHEzWIMQdrXFw))
    qOksalnUBApmLyKDNSHEzWIMQdrXFc=qOksalnUBApmLyKDNSHEzWIMQdrXeT.get('code').strip()
    qOksalnUBApmLyKDNSHEzWIMQdrXFb=qOksalnUBApmLyKDNSHEzWIMQdrXFo.get('code').strip()
    if qOksalnUBApmLyKDNSHEzWIMQdrXPw=='vod' and qOksalnUBApmLyKDNSHEzWIMQdrXef.get_settings_direct_replay()==qOksalnUBApmLyKDNSHEzWIMQdrXfx:
     qOksalnUBApmLyKDNSHEzWIMQdrXFc=qOksalnUBApmLyKDNSHEzWIMQdrXeT.get('videoid').strip()
     qOksalnUBApmLyKDNSHEzWIMQdrXFb=qOksalnUBApmLyKDNSHEzWIMQdrXFo.get('videoid').strip()if qOksalnUBApmLyKDNSHEzWIMQdrXFb!=qOksalnUBApmLyKDNSHEzWIMQdrXfF else '-'
    if qOksalnUBApmLyKDNSHEzWIMQdrXFc!=qOksalnUBApmLyKDNSHEzWIMQdrXFb:
     fp.write(qOksalnUBApmLyKDNSHEzWIMQdrXFw)
     qOksalnUBApmLyKDNSHEzWIMQdrXFT+=1
     if qOksalnUBApmLyKDNSHEzWIMQdrXFT>=50:break
   fp.close()
  except:
   qOksalnUBApmLyKDNSHEzWIMQdrXfF
 def dp_History_Remove(qOksalnUBApmLyKDNSHEzWIMQdrXef,args):
  qOksalnUBApmLyKDNSHEzWIMQdrXFu=args.get('delType')
  qOksalnUBApmLyKDNSHEzWIMQdrXFt =args.get('sKey')
  qOksalnUBApmLyKDNSHEzWIMQdrXFh =args.get('vType')
  qOksalnUBApmLyKDNSHEzWIMQdrXeo=xbmcgui.Dialog()
  if qOksalnUBApmLyKDNSHEzWIMQdrXFu=='SEARCH_ALL':
   qOksalnUBApmLyKDNSHEzWIMQdrXFj=qOksalnUBApmLyKDNSHEzWIMQdrXeo.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif qOksalnUBApmLyKDNSHEzWIMQdrXFu=='SEARCH_ONE':
   qOksalnUBApmLyKDNSHEzWIMQdrXFj=qOksalnUBApmLyKDNSHEzWIMQdrXeo.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif qOksalnUBApmLyKDNSHEzWIMQdrXFu=='WATCH_ALL':
   qOksalnUBApmLyKDNSHEzWIMQdrXFj=qOksalnUBApmLyKDNSHEzWIMQdrXeo.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif qOksalnUBApmLyKDNSHEzWIMQdrXFu=='WATCH_ONE':
   qOksalnUBApmLyKDNSHEzWIMQdrXFj=qOksalnUBApmLyKDNSHEzWIMQdrXeo.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if qOksalnUBApmLyKDNSHEzWIMQdrXFj==qOksalnUBApmLyKDNSHEzWIMQdrXfP:sys.exit()
  if qOksalnUBApmLyKDNSHEzWIMQdrXFu=='SEARCH_ALL':
   if os.path.isfile(qOksalnUBApmLyKDNSHEzWIMQdrXeP):os.remove(qOksalnUBApmLyKDNSHEzWIMQdrXeP)
  elif qOksalnUBApmLyKDNSHEzWIMQdrXFu=='SEARCH_ONE':
   try:
    qOksalnUBApmLyKDNSHEzWIMQdrXFx=qOksalnUBApmLyKDNSHEzWIMQdrXeP
    qOksalnUBApmLyKDNSHEzWIMQdrXFv=qOksalnUBApmLyKDNSHEzWIMQdrXef.Load_List_File('search') 
    fp=qOksalnUBApmLyKDNSHEzWIMQdrXfc(qOksalnUBApmLyKDNSHEzWIMQdrXFx,'w',-1,'utf-8')
    for qOksalnUBApmLyKDNSHEzWIMQdrXFw in qOksalnUBApmLyKDNSHEzWIMQdrXFv:
     qOksalnUBApmLyKDNSHEzWIMQdrXFo=qOksalnUBApmLyKDNSHEzWIMQdrXfg(urllib.parse.parse_qsl(qOksalnUBApmLyKDNSHEzWIMQdrXFw))
     qOksalnUBApmLyKDNSHEzWIMQdrXFJ=qOksalnUBApmLyKDNSHEzWIMQdrXFo.get('skey').strip()
     if qOksalnUBApmLyKDNSHEzWIMQdrXFt!=qOksalnUBApmLyKDNSHEzWIMQdrXFJ:
      fp.write(qOksalnUBApmLyKDNSHEzWIMQdrXFw)
    fp.close()
   except:
    qOksalnUBApmLyKDNSHEzWIMQdrXfF
  elif qOksalnUBApmLyKDNSHEzWIMQdrXFu=='WATCH_ALL':
   qOksalnUBApmLyKDNSHEzWIMQdrXFx=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%qOksalnUBApmLyKDNSHEzWIMQdrXFh))
   if os.path.isfile(qOksalnUBApmLyKDNSHEzWIMQdrXFx):os.remove(qOksalnUBApmLyKDNSHEzWIMQdrXFx)
  elif qOksalnUBApmLyKDNSHEzWIMQdrXFu=='WATCH_ONE':
   qOksalnUBApmLyKDNSHEzWIMQdrXFx=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%qOksalnUBApmLyKDNSHEzWIMQdrXFh))
   try:
    qOksalnUBApmLyKDNSHEzWIMQdrXFv=qOksalnUBApmLyKDNSHEzWIMQdrXef.Load_List_File(qOksalnUBApmLyKDNSHEzWIMQdrXFh) 
    fp=qOksalnUBApmLyKDNSHEzWIMQdrXfc(qOksalnUBApmLyKDNSHEzWIMQdrXFx,'w',-1,'utf-8')
    for qOksalnUBApmLyKDNSHEzWIMQdrXFw in qOksalnUBApmLyKDNSHEzWIMQdrXFv:
     qOksalnUBApmLyKDNSHEzWIMQdrXFo=qOksalnUBApmLyKDNSHEzWIMQdrXfg(urllib.parse.parse_qsl(qOksalnUBApmLyKDNSHEzWIMQdrXFw))
     qOksalnUBApmLyKDNSHEzWIMQdrXFJ=qOksalnUBApmLyKDNSHEzWIMQdrXFo.get('code').strip()
     if qOksalnUBApmLyKDNSHEzWIMQdrXFt!=qOksalnUBApmLyKDNSHEzWIMQdrXFJ:
      fp.write(qOksalnUBApmLyKDNSHEzWIMQdrXFw)
    fp.close()
   except:
    qOksalnUBApmLyKDNSHEzWIMQdrXfF
  xbmc.executebuiltin("Container.Refresh")
 def Save_Searched_List(qOksalnUBApmLyKDNSHEzWIMQdrXef,qOksalnUBApmLyKDNSHEzWIMQdrXRj):
  try:
   qOksalnUBApmLyKDNSHEzWIMQdrXFi=qOksalnUBApmLyKDNSHEzWIMQdrXeP
   qOksalnUBApmLyKDNSHEzWIMQdrXFv=qOksalnUBApmLyKDNSHEzWIMQdrXef.Load_List_File('search') 
   qOksalnUBApmLyKDNSHEzWIMQdrXFC={'skey':qOksalnUBApmLyKDNSHEzWIMQdrXRj.strip()}
   fp=qOksalnUBApmLyKDNSHEzWIMQdrXfc(qOksalnUBApmLyKDNSHEzWIMQdrXFi,'w',-1,'utf-8')
   qOksalnUBApmLyKDNSHEzWIMQdrXFg=urllib.parse.urlencode(qOksalnUBApmLyKDNSHEzWIMQdrXFC)
   qOksalnUBApmLyKDNSHEzWIMQdrXFg=qOksalnUBApmLyKDNSHEzWIMQdrXFg+'\n'
   fp.write(qOksalnUBApmLyKDNSHEzWIMQdrXFg)
   qOksalnUBApmLyKDNSHEzWIMQdrXFT=0
   for qOksalnUBApmLyKDNSHEzWIMQdrXFw in qOksalnUBApmLyKDNSHEzWIMQdrXFv:
    qOksalnUBApmLyKDNSHEzWIMQdrXFo=qOksalnUBApmLyKDNSHEzWIMQdrXfg(urllib.parse.parse_qsl(qOksalnUBApmLyKDNSHEzWIMQdrXFw))
    qOksalnUBApmLyKDNSHEzWIMQdrXFc=qOksalnUBApmLyKDNSHEzWIMQdrXFC.get('skey').strip()
    qOksalnUBApmLyKDNSHEzWIMQdrXFb=qOksalnUBApmLyKDNSHEzWIMQdrXFo.get('skey').strip()
    if qOksalnUBApmLyKDNSHEzWIMQdrXFc!=qOksalnUBApmLyKDNSHEzWIMQdrXFb:
     fp.write(qOksalnUBApmLyKDNSHEzWIMQdrXFw)
     qOksalnUBApmLyKDNSHEzWIMQdrXFT+=1
     if qOksalnUBApmLyKDNSHEzWIMQdrXFT>=50:break
   fp.close()
  except:
   qOksalnUBApmLyKDNSHEzWIMQdrXfF
 def dp_Global_Search(qOksalnUBApmLyKDNSHEzWIMQdrXef,args):
  qOksalnUBApmLyKDNSHEzWIMQdrXRi=args.get('mode')
  if qOksalnUBApmLyKDNSHEzWIMQdrXRi=='TOTAL_SEARCH':
   qOksalnUBApmLyKDNSHEzWIMQdrXFV='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   qOksalnUBApmLyKDNSHEzWIMQdrXFV='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(qOksalnUBApmLyKDNSHEzWIMQdrXFV)
 def dp_Bookmark_Menu(qOksalnUBApmLyKDNSHEzWIMQdrXef,args):
  qOksalnUBApmLyKDNSHEzWIMQdrXFV='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(qOksalnUBApmLyKDNSHEzWIMQdrXFV)
 def login_main(qOksalnUBApmLyKDNSHEzWIMQdrXef):
  (qOksalnUBApmLyKDNSHEzWIMQdrXYe,qOksalnUBApmLyKDNSHEzWIMQdrXYR,qOksalnUBApmLyKDNSHEzWIMQdrXYG)=qOksalnUBApmLyKDNSHEzWIMQdrXef.get_settings_account()
  if not(qOksalnUBApmLyKDNSHEzWIMQdrXYe and qOksalnUBApmLyKDNSHEzWIMQdrXYR):
   qOksalnUBApmLyKDNSHEzWIMQdrXeo=xbmcgui.Dialog()
   qOksalnUBApmLyKDNSHEzWIMQdrXFj=qOksalnUBApmLyKDNSHEzWIMQdrXeo.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if qOksalnUBApmLyKDNSHEzWIMQdrXFj==qOksalnUBApmLyKDNSHEzWIMQdrXfx:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if qOksalnUBApmLyKDNSHEzWIMQdrXef.cookiefile_check()==qOksalnUBApmLyKDNSHEzWIMQdrXfx:return
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   qOksalnUBApmLyKDNSHEzWIMQdrXYF=0
   while qOksalnUBApmLyKDNSHEzWIMQdrXfx:
    qOksalnUBApmLyKDNSHEzWIMQdrXYF+=1
    time.sleep(0.05)
    if qOksalnUBApmLyKDNSHEzWIMQdrXYF>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  qOksalnUBApmLyKDNSHEzWIMQdrXYx=qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.GetCredential(qOksalnUBApmLyKDNSHEzWIMQdrXYe,qOksalnUBApmLyKDNSHEzWIMQdrXYR,qOksalnUBApmLyKDNSHEzWIMQdrXYG)
  if qOksalnUBApmLyKDNSHEzWIMQdrXYx:qOksalnUBApmLyKDNSHEzWIMQdrXef.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
  if qOksalnUBApmLyKDNSHEzWIMQdrXYx==qOksalnUBApmLyKDNSHEzWIMQdrXfP:
   qOksalnUBApmLyKDNSHEzWIMQdrXef.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_setEpOrderby(qOksalnUBApmLyKDNSHEzWIMQdrXef,args):
  qOksalnUBApmLyKDNSHEzWIMQdrXRf =args.get('orderby')
  qOksalnUBApmLyKDNSHEzWIMQdrXef.set_winEpisodeOrderby(qOksalnUBApmLyKDNSHEzWIMQdrXRf)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(qOksalnUBApmLyKDNSHEzWIMQdrXef,args):
  qOksalnUBApmLyKDNSHEzWIMQdrXRi =args.get('mode')
  qOksalnUBApmLyKDNSHEzWIMQdrXYP =args.get('contentid')
  qOksalnUBApmLyKDNSHEzWIMQdrXYf =args.get('pvrmode')
  qOksalnUBApmLyKDNSHEzWIMQdrXYv=qOksalnUBApmLyKDNSHEzWIMQdrXef.get_selQuality()
  qOksalnUBApmLyKDNSHEzWIMQdrXRG =qOksalnUBApmLyKDNSHEzWIMQdrXef.get_settings_play()
  qOksalnUBApmLyKDNSHEzWIMQdrXef.addon_log(qOksalnUBApmLyKDNSHEzWIMQdrXYP+' - '+qOksalnUBApmLyKDNSHEzWIMQdrXRi)
  if qOksalnUBApmLyKDNSHEzWIMQdrXRi=='SPORTS':
   qOksalnUBApmLyKDNSHEzWIMQdrXYg=qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.GetSportsURL(qOksalnUBApmLyKDNSHEzWIMQdrXYP,qOksalnUBApmLyKDNSHEzWIMQdrXYv)
  else:
   qOksalnUBApmLyKDNSHEzWIMQdrXYg=qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.GetStreamingURL(qOksalnUBApmLyKDNSHEzWIMQdrXRi,qOksalnUBApmLyKDNSHEzWIMQdrXYP,qOksalnUBApmLyKDNSHEzWIMQdrXYv,qOksalnUBApmLyKDNSHEzWIMQdrXYf,playOption=qOksalnUBApmLyKDNSHEzWIMQdrXRG)
  qOksalnUBApmLyKDNSHEzWIMQdrXYT=qOksalnUBApmLyKDNSHEzWIMQdrXYg['stream_cookie']
  qOksalnUBApmLyKDNSHEzWIMQdrXYw='{}|Cookie={}'.format(qOksalnUBApmLyKDNSHEzWIMQdrXYg['stream_url'],qOksalnUBApmLyKDNSHEzWIMQdrXYT)
  qOksalnUBApmLyKDNSHEzWIMQdrXef.addon_log(qOksalnUBApmLyKDNSHEzWIMQdrXYw)
  if qOksalnUBApmLyKDNSHEzWIMQdrXYg['stream_url']=='':
   qOksalnUBApmLyKDNSHEzWIMQdrXef.addon_noti(__language__(30907).encode('utf8'))
   return
  qOksalnUBApmLyKDNSHEzWIMQdrXYo=xbmcgui.ListItem(path=qOksalnUBApmLyKDNSHEzWIMQdrXYw)
  if qOksalnUBApmLyKDNSHEzWIMQdrXYg['stream_drm']:
   qOksalnUBApmLyKDNSHEzWIMQdrXef.addon_log('!!streaming_drm!!')
   qOksalnUBApmLyKDNSHEzWIMQdrXYc=qOksalnUBApmLyKDNSHEzWIMQdrXYg['stream_drm']['customdata']
   qOksalnUBApmLyKDNSHEzWIMQdrXYb =qOksalnUBApmLyKDNSHEzWIMQdrXYg['stream_drm']['drmhost']
   qOksalnUBApmLyKDNSHEzWIMQdrXYu =inputstreamhelper.Helper('mpd',drm='widevine')
   if qOksalnUBApmLyKDNSHEzWIMQdrXYu.check_inputstream():
    if qOksalnUBApmLyKDNSHEzWIMQdrXRi=='MOVIE':
     qOksalnUBApmLyKDNSHEzWIMQdrXYt='https://www.wavve.com/player/movie?movieid=%s'%qOksalnUBApmLyKDNSHEzWIMQdrXYP
    else:
     qOksalnUBApmLyKDNSHEzWIMQdrXYt='https://www.wavve.com/player/vod?programid=%s&page=1'%qOksalnUBApmLyKDNSHEzWIMQdrXYP
    qOksalnUBApmLyKDNSHEzWIMQdrXYh={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':qOksalnUBApmLyKDNSHEzWIMQdrXYc,'referer':qOksalnUBApmLyKDNSHEzWIMQdrXYt,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.USER_AGENT,}
    qOksalnUBApmLyKDNSHEzWIMQdrXYj=qOksalnUBApmLyKDNSHEzWIMQdrXYb+'|'+urllib.parse.urlencode(qOksalnUBApmLyKDNSHEzWIMQdrXYh)+'|R{SSM}|'
    qOksalnUBApmLyKDNSHEzWIMQdrXYo.setProperty('inputstream',qOksalnUBApmLyKDNSHEzWIMQdrXYu.inputstream_addon)
    qOksalnUBApmLyKDNSHEzWIMQdrXYo.setProperty('inputstream.adaptive.manifest_type','mpd')
    qOksalnUBApmLyKDNSHEzWIMQdrXYo.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    qOksalnUBApmLyKDNSHEzWIMQdrXYo.setProperty('inputstream.adaptive.license_key',qOksalnUBApmLyKDNSHEzWIMQdrXYj)
    qOksalnUBApmLyKDNSHEzWIMQdrXYo.setProperty('inputstream.adaptive.stream_headers','user-agent={}&Cookie={}'.format(qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.USER_AGENT,qOksalnUBApmLyKDNSHEzWIMQdrXYT))
  elif qOksalnUBApmLyKDNSHEzWIMQdrXRi in['VOD','MOVIE']:
   qOksalnUBApmLyKDNSHEzWIMQdrXYo.setContentLookup(qOksalnUBApmLyKDNSHEzWIMQdrXfP)
   qOksalnUBApmLyKDNSHEzWIMQdrXYo.setMimeType('application/x-mpegURL')
   qOksalnUBApmLyKDNSHEzWIMQdrXYo.setProperty('inputstream','inputstream.adaptive')
   if qOksalnUBApmLyKDNSHEzWIMQdrXYg['stream_action']=='hls':
    qOksalnUBApmLyKDNSHEzWIMQdrXYo.setProperty('inputstream.adaptive.manifest_type','hls')
   else:
    qOksalnUBApmLyKDNSHEzWIMQdrXYo.setProperty('inputstream.adaptive.manifest_type','mpd')
   qOksalnUBApmLyKDNSHEzWIMQdrXYo.setProperty('inputstream.adaptive.stream_headers','user-agent={}&Cookie={}'.format(qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.USER_AGENT,qOksalnUBApmLyKDNSHEzWIMQdrXYT))
  if qOksalnUBApmLyKDNSHEzWIMQdrXYg['stream_vtt']:
   qOksalnUBApmLyKDNSHEzWIMQdrXYo.setSubtitles([qOksalnUBApmLyKDNSHEzWIMQdrXYg['stream_vtt']])
  xbmcplugin.setResolvedUrl(qOksalnUBApmLyKDNSHEzWIMQdrXef._addon_handle,qOksalnUBApmLyKDNSHEzWIMQdrXfx,qOksalnUBApmLyKDNSHEzWIMQdrXYo)
  qOksalnUBApmLyKDNSHEzWIMQdrXYJ=qOksalnUBApmLyKDNSHEzWIMQdrXfP
  if qOksalnUBApmLyKDNSHEzWIMQdrXYg['stream_preview']:
   qOksalnUBApmLyKDNSHEzWIMQdrXef.addon_noti(qOksalnUBApmLyKDNSHEzWIMQdrXYg['stream_preview'].encode('utf-8'))
   qOksalnUBApmLyKDNSHEzWIMQdrXYJ=qOksalnUBApmLyKDNSHEzWIMQdrXfx
  else:
   if '/preview.' in urllib.parse.urlsplit(qOksalnUBApmLyKDNSHEzWIMQdrXYg['stream_url']).path:
    qOksalnUBApmLyKDNSHEzWIMQdrXef.addon_noti(__language__(30908).encode('utf8'))
    qOksalnUBApmLyKDNSHEzWIMQdrXYJ=qOksalnUBApmLyKDNSHEzWIMQdrXfx
  try:
   qOksalnUBApmLyKDNSHEzWIMQdrXYi=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and qOksalnUBApmLyKDNSHEzWIMQdrXYJ==qOksalnUBApmLyKDNSHEzWIMQdrXfP and qOksalnUBApmLyKDNSHEzWIMQdrXYi!='-':
    qOksalnUBApmLyKDNSHEzWIMQdrXRc={'code':qOksalnUBApmLyKDNSHEzWIMQdrXYi,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    qOksalnUBApmLyKDNSHEzWIMQdrXef.Save_Watched_List(args.get('mode').lower(),qOksalnUBApmLyKDNSHEzWIMQdrXRc)
  except:
   qOksalnUBApmLyKDNSHEzWIMQdrXfF
 def logout(qOksalnUBApmLyKDNSHEzWIMQdrXef):
  qOksalnUBApmLyKDNSHEzWIMQdrXeo=xbmcgui.Dialog()
  qOksalnUBApmLyKDNSHEzWIMQdrXFj=qOksalnUBApmLyKDNSHEzWIMQdrXeo.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if qOksalnUBApmLyKDNSHEzWIMQdrXFj==qOksalnUBApmLyKDNSHEzWIMQdrXfP:sys.exit()
  qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.Init_WV_Total()
  if os.path.isfile(qOksalnUBApmLyKDNSHEzWIMQdrXex):os.remove(qOksalnUBApmLyKDNSHEzWIMQdrXex)
  qOksalnUBApmLyKDNSHEzWIMQdrXef.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(qOksalnUBApmLyKDNSHEzWIMQdrXef):
  qOksalnUBApmLyKDNSHEzWIMQdrXYC =qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.Get_Now_Datetime()
  qOksalnUBApmLyKDNSHEzWIMQdrXYV=qOksalnUBApmLyKDNSHEzWIMQdrXYC+datetime.timedelta(days=qOksalnUBApmLyKDNSHEzWIMQdrXfY(__addon__.getSetting('cache_ttl')))
  (qOksalnUBApmLyKDNSHEzWIMQdrXYe,qOksalnUBApmLyKDNSHEzWIMQdrXYR,qOksalnUBApmLyKDNSHEzWIMQdrXYG)=qOksalnUBApmLyKDNSHEzWIMQdrXef.get_settings_account()
  qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.Save_session_acount(qOksalnUBApmLyKDNSHEzWIMQdrXYe,qOksalnUBApmLyKDNSHEzWIMQdrXYR,qOksalnUBApmLyKDNSHEzWIMQdrXYG)
  qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.WV['account']['token_limit']=qOksalnUBApmLyKDNSHEzWIMQdrXYV.strftime('%Y%m%d')
  qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.JsonFile_Save(qOksalnUBApmLyKDNSHEzWIMQdrXex,qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.WV)
 def cookiefile_check(qOksalnUBApmLyKDNSHEzWIMQdrXef):
  qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.WV=qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.JsonFile_Load(qOksalnUBApmLyKDNSHEzWIMQdrXex)
  if 'account' not in qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.WV:
   qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.Init_WV_Total()
   return qOksalnUBApmLyKDNSHEzWIMQdrXfP
  if 'uuid' not in qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.WV.get('cookies'):
   qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.Init_WV_Total()
   return qOksalnUBApmLyKDNSHEzWIMQdrXfP
  (qOksalnUBApmLyKDNSHEzWIMQdrXxe,qOksalnUBApmLyKDNSHEzWIMQdrXxR,qOksalnUBApmLyKDNSHEzWIMQdrXxG)=qOksalnUBApmLyKDNSHEzWIMQdrXef.get_settings_account()
  (qOksalnUBApmLyKDNSHEzWIMQdrXxF,qOksalnUBApmLyKDNSHEzWIMQdrXxY,qOksalnUBApmLyKDNSHEzWIMQdrXxP)=qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.Load_session_acount()
  if qOksalnUBApmLyKDNSHEzWIMQdrXxe!=qOksalnUBApmLyKDNSHEzWIMQdrXxF or qOksalnUBApmLyKDNSHEzWIMQdrXxR!=qOksalnUBApmLyKDNSHEzWIMQdrXxY or qOksalnUBApmLyKDNSHEzWIMQdrXxG!=qOksalnUBApmLyKDNSHEzWIMQdrXxP:
   qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.Init_WV_Total()
   return qOksalnUBApmLyKDNSHEzWIMQdrXfP
  if qOksalnUBApmLyKDNSHEzWIMQdrXfY(qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))>qOksalnUBApmLyKDNSHEzWIMQdrXfY(qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.WV['account']['token_limit']):
   qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.Init_WV_Total()
   return qOksalnUBApmLyKDNSHEzWIMQdrXfP
  return qOksalnUBApmLyKDNSHEzWIMQdrXfx
 def dp_LiveCatagory_List(qOksalnUBApmLyKDNSHEzWIMQdrXef,args):
  qOksalnUBApmLyKDNSHEzWIMQdrXxf =args.get('sCode')
  qOksalnUBApmLyKDNSHEzWIMQdrXxv=args.get('sIndex')
  qOksalnUBApmLyKDNSHEzWIMQdrXGu,qOksalnUBApmLyKDNSHEzWIMQdrXxg=qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.Get_LiveCatagory_List(qOksalnUBApmLyKDNSHEzWIMQdrXxf,qOksalnUBApmLyKDNSHEzWIMQdrXxv)
  for qOksalnUBApmLyKDNSHEzWIMQdrXGt in qOksalnUBApmLyKDNSHEzWIMQdrXGu:
   qOksalnUBApmLyKDNSHEzWIMQdrXRg =qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('title')
   qOksalnUBApmLyKDNSHEzWIMQdrXRc={'mode':'LIVE_LIST','genre':qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('genre'),'baseapi':qOksalnUBApmLyKDNSHEzWIMQdrXxg}
   qOksalnUBApmLyKDNSHEzWIMQdrXef.add_dir(qOksalnUBApmLyKDNSHEzWIMQdrXRg,sublabel='',img='',infoLabels=qOksalnUBApmLyKDNSHEzWIMQdrXfF,isFolder=qOksalnUBApmLyKDNSHEzWIMQdrXfx,params=qOksalnUBApmLyKDNSHEzWIMQdrXRc)
  if qOksalnUBApmLyKDNSHEzWIMQdrXfT(qOksalnUBApmLyKDNSHEzWIMQdrXGu)>0:xbmcplugin.endOfDirectory(qOksalnUBApmLyKDNSHEzWIMQdrXef._addon_handle,cacheToDisc=qOksalnUBApmLyKDNSHEzWIMQdrXfP)
 def dp_MainCatagory_List(qOksalnUBApmLyKDNSHEzWIMQdrXef,args):
  qOksalnUBApmLyKDNSHEzWIMQdrXxf =args.get('sCode')
  qOksalnUBApmLyKDNSHEzWIMQdrXxv=args.get('sIndex')
  qOksalnUBApmLyKDNSHEzWIMQdrXRC =args.get('sType')
  qOksalnUBApmLyKDNSHEzWIMQdrXGu=qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.Get_MainCatagory_List(qOksalnUBApmLyKDNSHEzWIMQdrXxf,qOksalnUBApmLyKDNSHEzWIMQdrXxv)
  for qOksalnUBApmLyKDNSHEzWIMQdrXGt in qOksalnUBApmLyKDNSHEzWIMQdrXGu:
   if qOksalnUBApmLyKDNSHEzWIMQdrXRC=='vod':
    if qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('subtype')=='catagory':
     qOksalnUBApmLyKDNSHEzWIMQdrXRi='PROGRAM_LIST'
    else:
     qOksalnUBApmLyKDNSHEzWIMQdrXRi='SUPERSECTION_LIST'
   elif qOksalnUBApmLyKDNSHEzWIMQdrXRC=='movie':
    qOksalnUBApmLyKDNSHEzWIMQdrXRi='MOVIE_LIST'
   else:
    qOksalnUBApmLyKDNSHEzWIMQdrXRi=''
   qOksalnUBApmLyKDNSHEzWIMQdrXRg='%s (%s)'%(qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('title'),args.get('ordernm'))
   qOksalnUBApmLyKDNSHEzWIMQdrXRc={'mode':qOksalnUBApmLyKDNSHEzWIMQdrXRi,'suburl':qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('suburl'),'subapi':qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if qOksalnUBApmLyKDNSHEzWIMQdrXef.get_settings_exclusion21():
    if qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('title')=='성인' or qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('title')=='성인+' or qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('title')=='에로티시즘' or qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('title')=='19':continue
   qOksalnUBApmLyKDNSHEzWIMQdrXef.add_dir(qOksalnUBApmLyKDNSHEzWIMQdrXRg,sublabel='',img='',infoLabels=qOksalnUBApmLyKDNSHEzWIMQdrXfF,isFolder=qOksalnUBApmLyKDNSHEzWIMQdrXfx,params=qOksalnUBApmLyKDNSHEzWIMQdrXRc)
  if qOksalnUBApmLyKDNSHEzWIMQdrXfT(qOksalnUBApmLyKDNSHEzWIMQdrXGu)>0:xbmcplugin.endOfDirectory(qOksalnUBApmLyKDNSHEzWIMQdrXef._addon_handle,cacheToDisc=qOksalnUBApmLyKDNSHEzWIMQdrXfP)
 def dp_Program_List(qOksalnUBApmLyKDNSHEzWIMQdrXef,args):
  qOksalnUBApmLyKDNSHEzWIMQdrXxT =args.get('subapi')
  qOksalnUBApmLyKDNSHEzWIMQdrXGb=qOksalnUBApmLyKDNSHEzWIMQdrXfY(args.get('page'))
  qOksalnUBApmLyKDNSHEzWIMQdrXRf =args.get('orderby')
  qOksalnUBApmLyKDNSHEzWIMQdrXGu,qOksalnUBApmLyKDNSHEzWIMQdrXGe=qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.Get_Program_List(qOksalnUBApmLyKDNSHEzWIMQdrXxT,qOksalnUBApmLyKDNSHEzWIMQdrXGb,qOksalnUBApmLyKDNSHEzWIMQdrXRf)
  for qOksalnUBApmLyKDNSHEzWIMQdrXGt in qOksalnUBApmLyKDNSHEzWIMQdrXGu:
   qOksalnUBApmLyKDNSHEzWIMQdrXGh =qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('videoid')
   qOksalnUBApmLyKDNSHEzWIMQdrXGj =qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('vidtype')
   qOksalnUBApmLyKDNSHEzWIMQdrXRg =qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('title')
   qOksalnUBApmLyKDNSHEzWIMQdrXGJ=qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('thumbnail')
   qOksalnUBApmLyKDNSHEzWIMQdrXGi =qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('age')
   if qOksalnUBApmLyKDNSHEzWIMQdrXGi=='18' or qOksalnUBApmLyKDNSHEzWIMQdrXGi=='19' or qOksalnUBApmLyKDNSHEzWIMQdrXGi=='21':qOksalnUBApmLyKDNSHEzWIMQdrXRg+=' (%s)'%(qOksalnUBApmLyKDNSHEzWIMQdrXGi)
   qOksalnUBApmLyKDNSHEzWIMQdrXGc={'plot':qOksalnUBApmLyKDNSHEzWIMQdrXRg,'mpaa':qOksalnUBApmLyKDNSHEzWIMQdrXGi,'mediatype':'tvshow',}
   qOksalnUBApmLyKDNSHEzWIMQdrXRc={'mode':'SEASON_LIST','videoid':qOksalnUBApmLyKDNSHEzWIMQdrXGh,'vidtype':qOksalnUBApmLyKDNSHEzWIMQdrXGj,}
   qOksalnUBApmLyKDNSHEzWIMQdrXGo=[]
   qOksalnUBApmLyKDNSHEzWIMQdrXGC={'mode':'VIEW_DETAIL','values':{'videoid':qOksalnUBApmLyKDNSHEzWIMQdrXGh,'vidtype':'tvshow','contenttype':qOksalnUBApmLyKDNSHEzWIMQdrXGj,}}
   qOksalnUBApmLyKDNSHEzWIMQdrXGV=json.dumps(qOksalnUBApmLyKDNSHEzWIMQdrXGC,separators=(',',':'))
   qOksalnUBApmLyKDNSHEzWIMQdrXGV=base64.standard_b64encode(qOksalnUBApmLyKDNSHEzWIMQdrXGV.encode()).decode('utf-8')
   qOksalnUBApmLyKDNSHEzWIMQdrXGV=qOksalnUBApmLyKDNSHEzWIMQdrXGV.replace('+','%2B')
   qOksalnUBApmLyKDNSHEzWIMQdrXFe='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(qOksalnUBApmLyKDNSHEzWIMQdrXGV)
   qOksalnUBApmLyKDNSHEzWIMQdrXGo.append(('상세정보 조회',qOksalnUBApmLyKDNSHEzWIMQdrXFe))
   if qOksalnUBApmLyKDNSHEzWIMQdrXef.get_settings_makebookmark():
    qOksalnUBApmLyKDNSHEzWIMQdrXGC={'videoid':qOksalnUBApmLyKDNSHEzWIMQdrXGh,'vidtype':'tvshow','vtitle':qOksalnUBApmLyKDNSHEzWIMQdrXRg,'vsubtitle':'','contenttype':qOksalnUBApmLyKDNSHEzWIMQdrXGj,}
    qOksalnUBApmLyKDNSHEzWIMQdrXFR=json.dumps(qOksalnUBApmLyKDNSHEzWIMQdrXGC)
    qOksalnUBApmLyKDNSHEzWIMQdrXFR=urllib.parse.quote(qOksalnUBApmLyKDNSHEzWIMQdrXFR)
    qOksalnUBApmLyKDNSHEzWIMQdrXFe='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(qOksalnUBApmLyKDNSHEzWIMQdrXFR)
    qOksalnUBApmLyKDNSHEzWIMQdrXGo.append(('(통합) 찜 영상에 추가',qOksalnUBApmLyKDNSHEzWIMQdrXFe))
   qOksalnUBApmLyKDNSHEzWIMQdrXef.add_dir(qOksalnUBApmLyKDNSHEzWIMQdrXRg,sublabel='',img=qOksalnUBApmLyKDNSHEzWIMQdrXGJ,infoLabels=qOksalnUBApmLyKDNSHEzWIMQdrXGc,isFolder=qOksalnUBApmLyKDNSHEzWIMQdrXfx,params=qOksalnUBApmLyKDNSHEzWIMQdrXRc,ContextMenu=qOksalnUBApmLyKDNSHEzWIMQdrXGo)
  if qOksalnUBApmLyKDNSHEzWIMQdrXGe:
   qOksalnUBApmLyKDNSHEzWIMQdrXRc={}
   qOksalnUBApmLyKDNSHEzWIMQdrXRc['mode'] ='PROGRAM_LIST' 
   qOksalnUBApmLyKDNSHEzWIMQdrXRc['subapi']=qOksalnUBApmLyKDNSHEzWIMQdrXxT 
   qOksalnUBApmLyKDNSHEzWIMQdrXRc['page'] =qOksalnUBApmLyKDNSHEzWIMQdrXfo(qOksalnUBApmLyKDNSHEzWIMQdrXGb+1)
   qOksalnUBApmLyKDNSHEzWIMQdrXRg='[B]%s >>[/B]'%'다음 페이지'
   qOksalnUBApmLyKDNSHEzWIMQdrXFG=qOksalnUBApmLyKDNSHEzWIMQdrXfo(qOksalnUBApmLyKDNSHEzWIMQdrXGb+1)
   qOksalnUBApmLyKDNSHEzWIMQdrXRo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   qOksalnUBApmLyKDNSHEzWIMQdrXef.add_dir(qOksalnUBApmLyKDNSHEzWIMQdrXRg,sublabel=qOksalnUBApmLyKDNSHEzWIMQdrXFG,img=qOksalnUBApmLyKDNSHEzWIMQdrXRo,infoLabels=qOksalnUBApmLyKDNSHEzWIMQdrXfF,isFolder=qOksalnUBApmLyKDNSHEzWIMQdrXfx,params=qOksalnUBApmLyKDNSHEzWIMQdrXRc)
  xbmcplugin.setContent(qOksalnUBApmLyKDNSHEzWIMQdrXef._addon_handle,'tvshows')
  if qOksalnUBApmLyKDNSHEzWIMQdrXfT(qOksalnUBApmLyKDNSHEzWIMQdrXGu)>0:xbmcplugin.endOfDirectory(qOksalnUBApmLyKDNSHEzWIMQdrXef._addon_handle,cacheToDisc=qOksalnUBApmLyKDNSHEzWIMQdrXfP)
 def dp_Season_List(qOksalnUBApmLyKDNSHEzWIMQdrXef,args):
  qOksalnUBApmLyKDNSHEzWIMQdrXGh=args.get('videoid')
  qOksalnUBApmLyKDNSHEzWIMQdrXGj=args.get('vidtype')
  if qOksalnUBApmLyKDNSHEzWIMQdrXGj=='contentid':
   qOksalnUBApmLyKDNSHEzWIMQdrXYP=qOksalnUBApmLyKDNSHEzWIMQdrXGh
   qOksalnUBApmLyKDNSHEzWIMQdrXxw =qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.ContentidToSeasonid(qOksalnUBApmLyKDNSHEzWIMQdrXGh)
  else:
   qOksalnUBApmLyKDNSHEzWIMQdrXYP=qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.ProgramidToContentid(qOksalnUBApmLyKDNSHEzWIMQdrXGh)
   qOksalnUBApmLyKDNSHEzWIMQdrXxw =qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.ContentidToSeasonid(qOksalnUBApmLyKDNSHEzWIMQdrXYP)
  qOksalnUBApmLyKDNSHEzWIMQdrXxo=qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.Get_Season_List(qOksalnUBApmLyKDNSHEzWIMQdrXxw)
  if qOksalnUBApmLyKDNSHEzWIMQdrXfT(qOksalnUBApmLyKDNSHEzWIMQdrXxo)>1:
   for qOksalnUBApmLyKDNSHEzWIMQdrXxc in qOksalnUBApmLyKDNSHEzWIMQdrXxo:
    qOksalnUBApmLyKDNSHEzWIMQdrXxb=qOksalnUBApmLyKDNSHEzWIMQdrXxc.get('season_Id')
    qOksalnUBApmLyKDNSHEzWIMQdrXxu=qOksalnUBApmLyKDNSHEzWIMQdrXxc.get('season_Nm')
    qOksalnUBApmLyKDNSHEzWIMQdrXxt=qOksalnUBApmLyKDNSHEzWIMQdrXxc.get('programNm')
    qOksalnUBApmLyKDNSHEzWIMQdrXGJ=qOksalnUBApmLyKDNSHEzWIMQdrXxc.get('thumbnail')
    qOksalnUBApmLyKDNSHEzWIMQdrXxh =qOksalnUBApmLyKDNSHEzWIMQdrXxc.get('synopsis')
    qOksalnUBApmLyKDNSHEzWIMQdrXGc={'mediatype':'tvshow','title':qOksalnUBApmLyKDNSHEzWIMQdrXxu,'plot':qOksalnUBApmLyKDNSHEzWIMQdrXxh,}
    qOksalnUBApmLyKDNSHEzWIMQdrXRc={'mode':'EPISODE_LIST','seasonid':qOksalnUBApmLyKDNSHEzWIMQdrXxb,'page':'1',}
    qOksalnUBApmLyKDNSHEzWIMQdrXef.add_dir(qOksalnUBApmLyKDNSHEzWIMQdrXxu,sublabel=qOksalnUBApmLyKDNSHEzWIMQdrXxt,img=qOksalnUBApmLyKDNSHEzWIMQdrXGJ,infoLabels=qOksalnUBApmLyKDNSHEzWIMQdrXGc,isFolder=qOksalnUBApmLyKDNSHEzWIMQdrXfx,params=qOksalnUBApmLyKDNSHEzWIMQdrXRc,ContextMenu=qOksalnUBApmLyKDNSHEzWIMQdrXfF)
   xbmcplugin.setContent(qOksalnUBApmLyKDNSHEzWIMQdrXef._addon_handle,'seasons')
   xbmcplugin.endOfDirectory(qOksalnUBApmLyKDNSHEzWIMQdrXef._addon_handle,cacheToDisc=qOksalnUBApmLyKDNSHEzWIMQdrXfP)
  else:
   qOksalnUBApmLyKDNSHEzWIMQdrXxj={'seasonid':qOksalnUBApmLyKDNSHEzWIMQdrXxw,'page':'1',}
   qOksalnUBApmLyKDNSHEzWIMQdrXef.dp_Episode_List(qOksalnUBApmLyKDNSHEzWIMQdrXxj)
 def dp_Episode_List(qOksalnUBApmLyKDNSHEzWIMQdrXef,args):
  qOksalnUBApmLyKDNSHEzWIMQdrXxw =args.get('seasonid')
  qOksalnUBApmLyKDNSHEzWIMQdrXGb =qOksalnUBApmLyKDNSHEzWIMQdrXfY(args.get('page'))
  qOksalnUBApmLyKDNSHEzWIMQdrXGu,qOksalnUBApmLyKDNSHEzWIMQdrXGe=qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.Get_Episode_List(qOksalnUBApmLyKDNSHEzWIMQdrXxw,qOksalnUBApmLyKDNSHEzWIMQdrXGb,orderby=qOksalnUBApmLyKDNSHEzWIMQdrXef.get_winEpisodeOrderby())
  for qOksalnUBApmLyKDNSHEzWIMQdrXGt in qOksalnUBApmLyKDNSHEzWIMQdrXGu:
   qOksalnUBApmLyKDNSHEzWIMQdrXFG=qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('episodenumber')
   qOksalnUBApmLyKDNSHEzWIMQdrXxJ ='[%s]\n\n%s'%(qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('episodetitle'),qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('synopsis'))
   qOksalnUBApmLyKDNSHEzWIMQdrXGc={'mediatype':'episode','title':qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('programtitle'),'plot':qOksalnUBApmLyKDNSHEzWIMQdrXxJ,'cast':qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('episodeactors'),}
   qOksalnUBApmLyKDNSHEzWIMQdrXRc={'mode':'VOD','programid':qOksalnUBApmLyKDNSHEzWIMQdrXxw,'contentid':qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('contentid'),'thumbnail':qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('thumbnail'),'title':qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('programtitle'),'subtitle':qOksalnUBApmLyKDNSHEzWIMQdrXFG,}
   qOksalnUBApmLyKDNSHEzWIMQdrXef.add_dir(qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('programtitle'),sublabel=qOksalnUBApmLyKDNSHEzWIMQdrXFG,img=qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('thumbnail'),infoLabels=qOksalnUBApmLyKDNSHEzWIMQdrXGc,isFolder=qOksalnUBApmLyKDNSHEzWIMQdrXfP,params=qOksalnUBApmLyKDNSHEzWIMQdrXRc)
  if qOksalnUBApmLyKDNSHEzWIMQdrXGb==1:
   qOksalnUBApmLyKDNSHEzWIMQdrXGc={'plot':'정렬순서를 변경합니다.'}
   qOksalnUBApmLyKDNSHEzWIMQdrXRc={}
   qOksalnUBApmLyKDNSHEzWIMQdrXRc['mode'] ='ORDER_BY' 
   if qOksalnUBApmLyKDNSHEzWIMQdrXef.get_winEpisodeOrderby()=='desc':
    qOksalnUBApmLyKDNSHEzWIMQdrXRg='정렬순서변경 : 최신화부터 -> 1회부터'
    qOksalnUBApmLyKDNSHEzWIMQdrXRc['orderby']='asc'
   else:
    qOksalnUBApmLyKDNSHEzWIMQdrXRg='정렬순서변경 : 1회부터 -> 최신화부터'
    qOksalnUBApmLyKDNSHEzWIMQdrXRc['orderby']='desc'
   qOksalnUBApmLyKDNSHEzWIMQdrXRo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   qOksalnUBApmLyKDNSHEzWIMQdrXef.add_dir(qOksalnUBApmLyKDNSHEzWIMQdrXRg,sublabel='',img=qOksalnUBApmLyKDNSHEzWIMQdrXRo,infoLabels=qOksalnUBApmLyKDNSHEzWIMQdrXGc,isFolder=qOksalnUBApmLyKDNSHEzWIMQdrXfP,params=qOksalnUBApmLyKDNSHEzWIMQdrXRc,isLink=qOksalnUBApmLyKDNSHEzWIMQdrXfx)
  if qOksalnUBApmLyKDNSHEzWIMQdrXGe:
   qOksalnUBApmLyKDNSHEzWIMQdrXRc={}
   qOksalnUBApmLyKDNSHEzWIMQdrXRc['mode'] ='EPISODE_LIST' 
   qOksalnUBApmLyKDNSHEzWIMQdrXRc['seasonid']=qOksalnUBApmLyKDNSHEzWIMQdrXxw
   qOksalnUBApmLyKDNSHEzWIMQdrXRc['page'] =qOksalnUBApmLyKDNSHEzWIMQdrXfo(qOksalnUBApmLyKDNSHEzWIMQdrXGb+1)
   qOksalnUBApmLyKDNSHEzWIMQdrXRg='[B]%s >>[/B]'%'다음 페이지'
   qOksalnUBApmLyKDNSHEzWIMQdrXFG=qOksalnUBApmLyKDNSHEzWIMQdrXfo(qOksalnUBApmLyKDNSHEzWIMQdrXGb+1)
   qOksalnUBApmLyKDNSHEzWIMQdrXRo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   qOksalnUBApmLyKDNSHEzWIMQdrXef.add_dir(qOksalnUBApmLyKDNSHEzWIMQdrXRg,sublabel=qOksalnUBApmLyKDNSHEzWIMQdrXFG,img=qOksalnUBApmLyKDNSHEzWIMQdrXRo,infoLabels=qOksalnUBApmLyKDNSHEzWIMQdrXfF,isFolder=qOksalnUBApmLyKDNSHEzWIMQdrXfx,params=qOksalnUBApmLyKDNSHEzWIMQdrXRc)
  xbmcplugin.setContent(qOksalnUBApmLyKDNSHEzWIMQdrXef._addon_handle,'episodes')
  if qOksalnUBApmLyKDNSHEzWIMQdrXfT(qOksalnUBApmLyKDNSHEzWIMQdrXGu)>0:xbmcplugin.endOfDirectory(qOksalnUBApmLyKDNSHEzWIMQdrXef._addon_handle,cacheToDisc=qOksalnUBApmLyKDNSHEzWIMQdrXfP)
 def dp_SuperSection_List(qOksalnUBApmLyKDNSHEzWIMQdrXef,args):
  qOksalnUBApmLyKDNSHEzWIMQdrXxi =args.get('suburl')
  qOksalnUBApmLyKDNSHEzWIMQdrXGu=qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.Get_SuperMultiSection_List(qOksalnUBApmLyKDNSHEzWIMQdrXxi)
  for qOksalnUBApmLyKDNSHEzWIMQdrXGt in qOksalnUBApmLyKDNSHEzWIMQdrXGu:
   qOksalnUBApmLyKDNSHEzWIMQdrXRg =qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('title')
   qOksalnUBApmLyKDNSHEzWIMQdrXxT =qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('subapi')
   qOksalnUBApmLyKDNSHEzWIMQdrXxC=qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('cell_type')
   if qOksalnUBApmLyKDNSHEzWIMQdrXxT.find('mtype=svod')>=0 or qOksalnUBApmLyKDNSHEzWIMQdrXxT.find('mtype=ppv')>=0 or qOksalnUBApmLyKDNSHEzWIMQdrXxT.find('contenttype=movie')>=0:
    qOksalnUBApmLyKDNSHEzWIMQdrXRi='MOVIE_LIST'
   elif qOksalnUBApmLyKDNSHEzWIMQdrXxT.find('contenttype=program')>=0:
    qOksalnUBApmLyKDNSHEzWIMQdrXRi='PROGRAM_LIST'
   elif qOksalnUBApmLyKDNSHEzWIMQdrXxC=='band_71':
    qOksalnUBApmLyKDNSHEzWIMQdrXRi ='SUPERSECTION_LIST'
    (qOksalnUBApmLyKDNSHEzWIMQdrXxV,qOksalnUBApmLyKDNSHEzWIMQdrXPe)=qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.Baseapi_Parse(qOksalnUBApmLyKDNSHEzWIMQdrXxT)
    qOksalnUBApmLyKDNSHEzWIMQdrXxi=qOksalnUBApmLyKDNSHEzWIMQdrXPe.get('api')
    qOksalnUBApmLyKDNSHEzWIMQdrXxT=''
   elif qOksalnUBApmLyKDNSHEzWIMQdrXxC=='band_2':
    qOksalnUBApmLyKDNSHEzWIMQdrXRi='BAND2SECTION_LIST'
   elif qOksalnUBApmLyKDNSHEzWIMQdrXxC=='band_live':
    qOksalnUBApmLyKDNSHEzWIMQdrXRi='BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}',qOksalnUBApmLyKDNSHEzWIMQdrXxT):
    qOksalnUBApmLyKDNSHEzWIMQdrXRi='MOVIE_LIST'
   else:
    qOksalnUBApmLyKDNSHEzWIMQdrXRi='PROGRAM_LIST'
   qOksalnUBApmLyKDNSHEzWIMQdrXGc={'plot':qOksalnUBApmLyKDNSHEzWIMQdrXRg,'mediatype':'tvshow'}
   qOksalnUBApmLyKDNSHEzWIMQdrXRc={'mode':qOksalnUBApmLyKDNSHEzWIMQdrXRi,'suburl':qOksalnUBApmLyKDNSHEzWIMQdrXxi,'subapi':qOksalnUBApmLyKDNSHEzWIMQdrXxT,'page':'1'}
   qOksalnUBApmLyKDNSHEzWIMQdrXef.add_dir(qOksalnUBApmLyKDNSHEzWIMQdrXRg,sublabel='',img=qOksalnUBApmLyKDNSHEzWIMQdrXfF,infoLabels=qOksalnUBApmLyKDNSHEzWIMQdrXGc,isFolder=qOksalnUBApmLyKDNSHEzWIMQdrXfx,params=qOksalnUBApmLyKDNSHEzWIMQdrXRc)
  if qOksalnUBApmLyKDNSHEzWIMQdrXfT(qOksalnUBApmLyKDNSHEzWIMQdrXGu)>0:xbmcplugin.endOfDirectory(qOksalnUBApmLyKDNSHEzWIMQdrXef._addon_handle,cacheToDisc=qOksalnUBApmLyKDNSHEzWIMQdrXfP)
 def dp_BandLiveSection_List(qOksalnUBApmLyKDNSHEzWIMQdrXef,args):
  qOksalnUBApmLyKDNSHEzWIMQdrXxT =args.get('subapi')
  qOksalnUBApmLyKDNSHEzWIMQdrXGb=qOksalnUBApmLyKDNSHEzWIMQdrXfY(args.get('page'))
  qOksalnUBApmLyKDNSHEzWIMQdrXGu,qOksalnUBApmLyKDNSHEzWIMQdrXGe=qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.Get_BandLiveSection_List(qOksalnUBApmLyKDNSHEzWIMQdrXxT,qOksalnUBApmLyKDNSHEzWIMQdrXGb)
  for qOksalnUBApmLyKDNSHEzWIMQdrXGt in qOksalnUBApmLyKDNSHEzWIMQdrXGu:
   qOksalnUBApmLyKDNSHEzWIMQdrXPR =qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('channelid')
   qOksalnUBApmLyKDNSHEzWIMQdrXPG =qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('studio')
   qOksalnUBApmLyKDNSHEzWIMQdrXPF=qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('tvshowtitle')
   qOksalnUBApmLyKDNSHEzWIMQdrXGJ =qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('thumbnail')
   qOksalnUBApmLyKDNSHEzWIMQdrXGi =qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('age')
   qOksalnUBApmLyKDNSHEzWIMQdrXGc={'mediatype':'tvshow','mpaa':qOksalnUBApmLyKDNSHEzWIMQdrXGi,'title':'%s < %s >'%(qOksalnUBApmLyKDNSHEzWIMQdrXPG,qOksalnUBApmLyKDNSHEzWIMQdrXPF),'tvshowtitle':qOksalnUBApmLyKDNSHEzWIMQdrXPF,'studio':qOksalnUBApmLyKDNSHEzWIMQdrXPG,'plot':qOksalnUBApmLyKDNSHEzWIMQdrXPG}
   qOksalnUBApmLyKDNSHEzWIMQdrXRc={'mode':'LIVE','contentid':qOksalnUBApmLyKDNSHEzWIMQdrXPR}
   qOksalnUBApmLyKDNSHEzWIMQdrXef.add_dir(qOksalnUBApmLyKDNSHEzWIMQdrXPG,sublabel=qOksalnUBApmLyKDNSHEzWIMQdrXPF,img=qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('thumbnail'),infoLabels=qOksalnUBApmLyKDNSHEzWIMQdrXGc,isFolder=qOksalnUBApmLyKDNSHEzWIMQdrXfP,params=qOksalnUBApmLyKDNSHEzWIMQdrXRc)
  if qOksalnUBApmLyKDNSHEzWIMQdrXGe:
   qOksalnUBApmLyKDNSHEzWIMQdrXRc={}
   qOksalnUBApmLyKDNSHEzWIMQdrXRc['mode'] ='BANDLIVESECTION_LIST' 
   qOksalnUBApmLyKDNSHEzWIMQdrXRc['subapi']=qOksalnUBApmLyKDNSHEzWIMQdrXxT
   qOksalnUBApmLyKDNSHEzWIMQdrXRc['page'] =qOksalnUBApmLyKDNSHEzWIMQdrXfo(qOksalnUBApmLyKDNSHEzWIMQdrXGb+1)
   qOksalnUBApmLyKDNSHEzWIMQdrXRg='[B]%s >>[/B]'%'다음 페이지'
   qOksalnUBApmLyKDNSHEzWIMQdrXFG=qOksalnUBApmLyKDNSHEzWIMQdrXfo(qOksalnUBApmLyKDNSHEzWIMQdrXGb+1)
   qOksalnUBApmLyKDNSHEzWIMQdrXRo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   qOksalnUBApmLyKDNSHEzWIMQdrXef.add_dir(qOksalnUBApmLyKDNSHEzWIMQdrXRg,sublabel=qOksalnUBApmLyKDNSHEzWIMQdrXFG,img=qOksalnUBApmLyKDNSHEzWIMQdrXRo,infoLabels=qOksalnUBApmLyKDNSHEzWIMQdrXfF,isFolder=qOksalnUBApmLyKDNSHEzWIMQdrXfx,params=qOksalnUBApmLyKDNSHEzWIMQdrXRc)
  if qOksalnUBApmLyKDNSHEzWIMQdrXfT(qOksalnUBApmLyKDNSHEzWIMQdrXGu)>0:xbmcplugin.endOfDirectory(qOksalnUBApmLyKDNSHEzWIMQdrXef._addon_handle,cacheToDisc=qOksalnUBApmLyKDNSHEzWIMQdrXfP)
 def dp_Band2Section_List(qOksalnUBApmLyKDNSHEzWIMQdrXef,args):
  qOksalnUBApmLyKDNSHEzWIMQdrXxT =args.get('subapi')
  qOksalnUBApmLyKDNSHEzWIMQdrXGb=qOksalnUBApmLyKDNSHEzWIMQdrXfY(args.get('page'))
  qOksalnUBApmLyKDNSHEzWIMQdrXGu,qOksalnUBApmLyKDNSHEzWIMQdrXGe=qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.Get_Band2Section_List(qOksalnUBApmLyKDNSHEzWIMQdrXxT,qOksalnUBApmLyKDNSHEzWIMQdrXGb)
  for qOksalnUBApmLyKDNSHEzWIMQdrXGt in qOksalnUBApmLyKDNSHEzWIMQdrXGu:
   qOksalnUBApmLyKDNSHEzWIMQdrXRg =qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('programtitle')
   qOksalnUBApmLyKDNSHEzWIMQdrXFG =qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('episodetitle')
   qOksalnUBApmLyKDNSHEzWIMQdrXGc={'plot':qOksalnUBApmLyKDNSHEzWIMQdrXRg+'\n\n'+qOksalnUBApmLyKDNSHEzWIMQdrXFG,'mpaa':qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('age'),'mediatype':'episode'}
   qOksalnUBApmLyKDNSHEzWIMQdrXRc={'mode':'VOD','programid':'-','contentid':qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('videoid'),'thumbnail':qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('thumbnail'),'title':qOksalnUBApmLyKDNSHEzWIMQdrXRg,'subtitle':qOksalnUBApmLyKDNSHEzWIMQdrXFG}
   qOksalnUBApmLyKDNSHEzWIMQdrXef.add_dir(qOksalnUBApmLyKDNSHEzWIMQdrXRg,sublabel=qOksalnUBApmLyKDNSHEzWIMQdrXFG,img=qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('thumbnail'),infoLabels=qOksalnUBApmLyKDNSHEzWIMQdrXGc,isFolder=qOksalnUBApmLyKDNSHEzWIMQdrXfP,params=qOksalnUBApmLyKDNSHEzWIMQdrXRc)
  if qOksalnUBApmLyKDNSHEzWIMQdrXGe:
   qOksalnUBApmLyKDNSHEzWIMQdrXRc={}
   qOksalnUBApmLyKDNSHEzWIMQdrXRc['mode'] ='BAND2SECTION_LIST' 
   qOksalnUBApmLyKDNSHEzWIMQdrXRc['subapi']=qOksalnUBApmLyKDNSHEzWIMQdrXxT
   qOksalnUBApmLyKDNSHEzWIMQdrXRc['page'] =qOksalnUBApmLyKDNSHEzWIMQdrXfo(qOksalnUBApmLyKDNSHEzWIMQdrXGb+1)
   qOksalnUBApmLyKDNSHEzWIMQdrXRg='[B]%s >>[/B]'%'다음 페이지'
   qOksalnUBApmLyKDNSHEzWIMQdrXFG=qOksalnUBApmLyKDNSHEzWIMQdrXfo(qOksalnUBApmLyKDNSHEzWIMQdrXGb+1)
   qOksalnUBApmLyKDNSHEzWIMQdrXRo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   qOksalnUBApmLyKDNSHEzWIMQdrXef.add_dir(qOksalnUBApmLyKDNSHEzWIMQdrXRg,sublabel=qOksalnUBApmLyKDNSHEzWIMQdrXFG,img=qOksalnUBApmLyKDNSHEzWIMQdrXRo,infoLabels=qOksalnUBApmLyKDNSHEzWIMQdrXfF,isFolder=qOksalnUBApmLyKDNSHEzWIMQdrXfx,params=qOksalnUBApmLyKDNSHEzWIMQdrXRc)
  if qOksalnUBApmLyKDNSHEzWIMQdrXfT(qOksalnUBApmLyKDNSHEzWIMQdrXGu)>0:xbmcplugin.endOfDirectory(qOksalnUBApmLyKDNSHEzWIMQdrXef._addon_handle,cacheToDisc=qOksalnUBApmLyKDNSHEzWIMQdrXfP)
 def dp_Movie_List(qOksalnUBApmLyKDNSHEzWIMQdrXef,args):
  qOksalnUBApmLyKDNSHEzWIMQdrXxT =args.get('subapi')
  qOksalnUBApmLyKDNSHEzWIMQdrXGb=qOksalnUBApmLyKDNSHEzWIMQdrXfY(args.get('page'))
  qOksalnUBApmLyKDNSHEzWIMQdrXRf =args.get('orderby')or '-'
  qOksalnUBApmLyKDNSHEzWIMQdrXGu,qOksalnUBApmLyKDNSHEzWIMQdrXGe=qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.Get_Movie_List(qOksalnUBApmLyKDNSHEzWIMQdrXxT,qOksalnUBApmLyKDNSHEzWIMQdrXGb,qOksalnUBApmLyKDNSHEzWIMQdrXRf)
  for qOksalnUBApmLyKDNSHEzWIMQdrXGt in qOksalnUBApmLyKDNSHEzWIMQdrXGu:
   qOksalnUBApmLyKDNSHEzWIMQdrXGh =qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('videoid')
   qOksalnUBApmLyKDNSHEzWIMQdrXGj =qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('vidtype')
   qOksalnUBApmLyKDNSHEzWIMQdrXRg =qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('title')
   qOksalnUBApmLyKDNSHEzWIMQdrXGJ=qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('thumbnail')
   qOksalnUBApmLyKDNSHEzWIMQdrXGi =qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('age')
   if qOksalnUBApmLyKDNSHEzWIMQdrXGi=='18' or qOksalnUBApmLyKDNSHEzWIMQdrXGi=='19' or qOksalnUBApmLyKDNSHEzWIMQdrXGi=='21':qOksalnUBApmLyKDNSHEzWIMQdrXRg+=' (%s)'%(qOksalnUBApmLyKDNSHEzWIMQdrXGi)
   qOksalnUBApmLyKDNSHEzWIMQdrXGc={'plot':qOksalnUBApmLyKDNSHEzWIMQdrXRg,'mpaa':qOksalnUBApmLyKDNSHEzWIMQdrXGi,'mediatype':'movie'}
   qOksalnUBApmLyKDNSHEzWIMQdrXRc={'mode':'MOVIE','contentid':qOksalnUBApmLyKDNSHEzWIMQdrXGh,'title':qOksalnUBApmLyKDNSHEzWIMQdrXRg,'thumbnail':qOksalnUBApmLyKDNSHEzWIMQdrXGJ,'age':qOksalnUBApmLyKDNSHEzWIMQdrXGi,}
   qOksalnUBApmLyKDNSHEzWIMQdrXGo=[]
   qOksalnUBApmLyKDNSHEzWIMQdrXGC={'mode':'VIEW_DETAIL','values':{'videoid':qOksalnUBApmLyKDNSHEzWIMQdrXGh,'vidtype':'movie','contenttype':qOksalnUBApmLyKDNSHEzWIMQdrXGj,}}
   qOksalnUBApmLyKDNSHEzWIMQdrXGV=json.dumps(qOksalnUBApmLyKDNSHEzWIMQdrXGC,separators=(',',':'))
   qOksalnUBApmLyKDNSHEzWIMQdrXGV=base64.standard_b64encode(qOksalnUBApmLyKDNSHEzWIMQdrXGV.encode()).decode('utf-8')
   qOksalnUBApmLyKDNSHEzWIMQdrXGV=qOksalnUBApmLyKDNSHEzWIMQdrXGV.replace('+','%2B')
   qOksalnUBApmLyKDNSHEzWIMQdrXFe='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(qOksalnUBApmLyKDNSHEzWIMQdrXGV)
   qOksalnUBApmLyKDNSHEzWIMQdrXGo.append(('상세정보 조회',qOksalnUBApmLyKDNSHEzWIMQdrXFe))
   if qOksalnUBApmLyKDNSHEzWIMQdrXef.get_settings_makebookmark():
    qOksalnUBApmLyKDNSHEzWIMQdrXGC={'videoid':qOksalnUBApmLyKDNSHEzWIMQdrXGh,'vidtype':'movie','vtitle':qOksalnUBApmLyKDNSHEzWIMQdrXRg,'vsubtitle':'','contenttype':'programid',}
    qOksalnUBApmLyKDNSHEzWIMQdrXFR=json.dumps(qOksalnUBApmLyKDNSHEzWIMQdrXGC)
    qOksalnUBApmLyKDNSHEzWIMQdrXFR=urllib.parse.quote(qOksalnUBApmLyKDNSHEzWIMQdrXFR)
    qOksalnUBApmLyKDNSHEzWIMQdrXFe='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(qOksalnUBApmLyKDNSHEzWIMQdrXFR)
    qOksalnUBApmLyKDNSHEzWIMQdrXGo.append(('(통합) 찜 영상에 추가',qOksalnUBApmLyKDNSHEzWIMQdrXFe))
   qOksalnUBApmLyKDNSHEzWIMQdrXef.add_dir(qOksalnUBApmLyKDNSHEzWIMQdrXRg,sublabel='',img=qOksalnUBApmLyKDNSHEzWIMQdrXGJ,infoLabels=qOksalnUBApmLyKDNSHEzWIMQdrXGc,isFolder=qOksalnUBApmLyKDNSHEzWIMQdrXfP,params=qOksalnUBApmLyKDNSHEzWIMQdrXRc,ContextMenu=qOksalnUBApmLyKDNSHEzWIMQdrXGo)
  if qOksalnUBApmLyKDNSHEzWIMQdrXGe:
   qOksalnUBApmLyKDNSHEzWIMQdrXRc={}
   qOksalnUBApmLyKDNSHEzWIMQdrXRc['mode'] ='MOVIE_LIST' 
   qOksalnUBApmLyKDNSHEzWIMQdrXRc['subapi']=qOksalnUBApmLyKDNSHEzWIMQdrXxT 
   qOksalnUBApmLyKDNSHEzWIMQdrXRc['page'] =qOksalnUBApmLyKDNSHEzWIMQdrXfo(qOksalnUBApmLyKDNSHEzWIMQdrXGb+1)
   qOksalnUBApmLyKDNSHEzWIMQdrXRc['orderby']=qOksalnUBApmLyKDNSHEzWIMQdrXRf
   qOksalnUBApmLyKDNSHEzWIMQdrXRg='[B]%s >>[/B]'%'다음 페이지'
   qOksalnUBApmLyKDNSHEzWIMQdrXFG=qOksalnUBApmLyKDNSHEzWIMQdrXfo(qOksalnUBApmLyKDNSHEzWIMQdrXGb+1)
   qOksalnUBApmLyKDNSHEzWIMQdrXRo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   qOksalnUBApmLyKDNSHEzWIMQdrXef.add_dir(qOksalnUBApmLyKDNSHEzWIMQdrXRg,sublabel=qOksalnUBApmLyKDNSHEzWIMQdrXFG,img=qOksalnUBApmLyKDNSHEzWIMQdrXRo,infoLabels=qOksalnUBApmLyKDNSHEzWIMQdrXfF,isFolder=qOksalnUBApmLyKDNSHEzWIMQdrXfx,params=qOksalnUBApmLyKDNSHEzWIMQdrXRc)
  xbmcplugin.setContent(qOksalnUBApmLyKDNSHEzWIMQdrXef._addon_handle,'movies')
  if qOksalnUBApmLyKDNSHEzWIMQdrXfT(qOksalnUBApmLyKDNSHEzWIMQdrXGu)>0:xbmcplugin.endOfDirectory(qOksalnUBApmLyKDNSHEzWIMQdrXef._addon_handle,cacheToDisc=qOksalnUBApmLyKDNSHEzWIMQdrXfP)
 def dp_Set_Bookmark(qOksalnUBApmLyKDNSHEzWIMQdrXef,args):
  qOksalnUBApmLyKDNSHEzWIMQdrXPY=urllib.parse.unquote(args.get('bm_param'))
  qOksalnUBApmLyKDNSHEzWIMQdrXPY=json.loads(qOksalnUBApmLyKDNSHEzWIMQdrXPY)
  qOksalnUBApmLyKDNSHEzWIMQdrXGh =qOksalnUBApmLyKDNSHEzWIMQdrXPY.get('videoid')
  qOksalnUBApmLyKDNSHEzWIMQdrXGj =qOksalnUBApmLyKDNSHEzWIMQdrXPY.get('vidtype')
  qOksalnUBApmLyKDNSHEzWIMQdrXPx =qOksalnUBApmLyKDNSHEzWIMQdrXPY.get('vtitle')
  qOksalnUBApmLyKDNSHEzWIMQdrXPf =qOksalnUBApmLyKDNSHEzWIMQdrXPY.get('vsubtitle')
  qOksalnUBApmLyKDNSHEzWIMQdrXPv=qOksalnUBApmLyKDNSHEzWIMQdrXPY.get('contenttype')
  qOksalnUBApmLyKDNSHEzWIMQdrXeo=xbmcgui.Dialog()
  qOksalnUBApmLyKDNSHEzWIMQdrXFj=qOksalnUBApmLyKDNSHEzWIMQdrXeo.yesno(__language__(30913).encode('utf8'),qOksalnUBApmLyKDNSHEzWIMQdrXPx+' \n\n'+__language__(30914))
  if qOksalnUBApmLyKDNSHEzWIMQdrXFj==qOksalnUBApmLyKDNSHEzWIMQdrXfP:return
  qOksalnUBApmLyKDNSHEzWIMQdrXPg=qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.GetBookmarkInfo(qOksalnUBApmLyKDNSHEzWIMQdrXGh,qOksalnUBApmLyKDNSHEzWIMQdrXGj,qOksalnUBApmLyKDNSHEzWIMQdrXPv)
  qOksalnUBApmLyKDNSHEzWIMQdrXPT=json.dumps(qOksalnUBApmLyKDNSHEzWIMQdrXPg)
  qOksalnUBApmLyKDNSHEzWIMQdrXPT=urllib.parse.quote(qOksalnUBApmLyKDNSHEzWIMQdrXPT)
  qOksalnUBApmLyKDNSHEzWIMQdrXFe ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(qOksalnUBApmLyKDNSHEzWIMQdrXPT)
  xbmc.executebuiltin(qOksalnUBApmLyKDNSHEzWIMQdrXFe)
 def dp_LiveChannel_List(qOksalnUBApmLyKDNSHEzWIMQdrXef,args):
  qOksalnUBApmLyKDNSHEzWIMQdrXPw =args.get('genre')
  qOksalnUBApmLyKDNSHEzWIMQdrXxg=args.get('baseapi')
  qOksalnUBApmLyKDNSHEzWIMQdrXGu=qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.Get_LiveChannel_List(qOksalnUBApmLyKDNSHEzWIMQdrXPw,qOksalnUBApmLyKDNSHEzWIMQdrXxg)
  for qOksalnUBApmLyKDNSHEzWIMQdrXGt in qOksalnUBApmLyKDNSHEzWIMQdrXGu:
   qOksalnUBApmLyKDNSHEzWIMQdrXPR =qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('channelid')
   qOksalnUBApmLyKDNSHEzWIMQdrXPG =qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('studio')
   qOksalnUBApmLyKDNSHEzWIMQdrXPF=qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('tvshowtitle')
   qOksalnUBApmLyKDNSHEzWIMQdrXGJ =qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('thumbnail')
   qOksalnUBApmLyKDNSHEzWIMQdrXGi =qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('age')
   qOksalnUBApmLyKDNSHEzWIMQdrXPo =qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('epg')
   qOksalnUBApmLyKDNSHEzWIMQdrXGc={'mediatype':'episode','mpaa':qOksalnUBApmLyKDNSHEzWIMQdrXGi,'title':'%s < %s >'%(qOksalnUBApmLyKDNSHEzWIMQdrXPG,qOksalnUBApmLyKDNSHEzWIMQdrXPF),'tvshowtitle':qOksalnUBApmLyKDNSHEzWIMQdrXPF,'studio':qOksalnUBApmLyKDNSHEzWIMQdrXPG,'plot':'%s\n\n%s'%(qOksalnUBApmLyKDNSHEzWIMQdrXPG,qOksalnUBApmLyKDNSHEzWIMQdrXPo)}
   qOksalnUBApmLyKDNSHEzWIMQdrXRc={'mode':'LIVE','contentid':qOksalnUBApmLyKDNSHEzWIMQdrXPR}
   qOksalnUBApmLyKDNSHEzWIMQdrXef.add_dir(qOksalnUBApmLyKDNSHEzWIMQdrXPG,sublabel=qOksalnUBApmLyKDNSHEzWIMQdrXPF,img=qOksalnUBApmLyKDNSHEzWIMQdrXGJ,infoLabels=qOksalnUBApmLyKDNSHEzWIMQdrXGc,isFolder=qOksalnUBApmLyKDNSHEzWIMQdrXfP,params=qOksalnUBApmLyKDNSHEzWIMQdrXRc)
  if qOksalnUBApmLyKDNSHEzWIMQdrXfT(qOksalnUBApmLyKDNSHEzWIMQdrXGu)>0:xbmcplugin.endOfDirectory(qOksalnUBApmLyKDNSHEzWIMQdrXef._addon_handle,cacheToDisc=qOksalnUBApmLyKDNSHEzWIMQdrXfP)
 def dp_Sports_GameList(qOksalnUBApmLyKDNSHEzWIMQdrXef,args):
  qOksalnUBApmLyKDNSHEzWIMQdrXGu=qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.Get_Sports_Gamelist()
  for qOksalnUBApmLyKDNSHEzWIMQdrXGt in qOksalnUBApmLyKDNSHEzWIMQdrXGu:
   qOksalnUBApmLyKDNSHEzWIMQdrXPc =qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('game_date')
   qOksalnUBApmLyKDNSHEzWIMQdrXPb =qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('game_time')
   qOksalnUBApmLyKDNSHEzWIMQdrXPu =qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('svc_id')
   qOksalnUBApmLyKDNSHEzWIMQdrXPt =qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('away_team')
   qOksalnUBApmLyKDNSHEzWIMQdrXPh =qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('home_team')
   qOksalnUBApmLyKDNSHEzWIMQdrXPj=qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('game_status')
   qOksalnUBApmLyKDNSHEzWIMQdrXPJ =qOksalnUBApmLyKDNSHEzWIMQdrXGt.get('game_place')
   qOksalnUBApmLyKDNSHEzWIMQdrXPi ='%s vs %s (%s)'%(qOksalnUBApmLyKDNSHEzWIMQdrXPt,qOksalnUBApmLyKDNSHEzWIMQdrXPh,qOksalnUBApmLyKDNSHEzWIMQdrXPJ)
   qOksalnUBApmLyKDNSHEzWIMQdrXPC =qOksalnUBApmLyKDNSHEzWIMQdrXPc+' '+qOksalnUBApmLyKDNSHEzWIMQdrXPb
   if qOksalnUBApmLyKDNSHEzWIMQdrXPj=='LIVE':
    qOksalnUBApmLyKDNSHEzWIMQdrXPj='~경기중~'
   elif qOksalnUBApmLyKDNSHEzWIMQdrXPj=='END':
    qOksalnUBApmLyKDNSHEzWIMQdrXPj='경기종료'
   elif qOksalnUBApmLyKDNSHEzWIMQdrXPj=='CANCEL':
    qOksalnUBApmLyKDNSHEzWIMQdrXPj='취소'
   else:
    qOksalnUBApmLyKDNSHEzWIMQdrXPj=''
   if qOksalnUBApmLyKDNSHEzWIMQdrXPj=='':
    qOksalnUBApmLyKDNSHEzWIMQdrXFG=qOksalnUBApmLyKDNSHEzWIMQdrXPi
   else:
    qOksalnUBApmLyKDNSHEzWIMQdrXFG=qOksalnUBApmLyKDNSHEzWIMQdrXPi+'  '+qOksalnUBApmLyKDNSHEzWIMQdrXPj
   qOksalnUBApmLyKDNSHEzWIMQdrXGc={'mediatype':'episode','title':qOksalnUBApmLyKDNSHEzWIMQdrXPi,'plot':'%s\n\n%s\n\n%s'%(qOksalnUBApmLyKDNSHEzWIMQdrXPC,qOksalnUBApmLyKDNSHEzWIMQdrXPi,qOksalnUBApmLyKDNSHEzWIMQdrXPj)}
   qOksalnUBApmLyKDNSHEzWIMQdrXRc={'mode':'SPORTS','contentid':qOksalnUBApmLyKDNSHEzWIMQdrXPu}
   qOksalnUBApmLyKDNSHEzWIMQdrXef.add_dir(qOksalnUBApmLyKDNSHEzWIMQdrXPC,sublabel=qOksalnUBApmLyKDNSHEzWIMQdrXFG,img='',infoLabels=qOksalnUBApmLyKDNSHEzWIMQdrXGc,isFolder=qOksalnUBApmLyKDNSHEzWIMQdrXfP,params=qOksalnUBApmLyKDNSHEzWIMQdrXRc)
  xbmcplugin.endOfDirectory(qOksalnUBApmLyKDNSHEzWIMQdrXef._addon_handle,cacheToDisc=qOksalnUBApmLyKDNSHEzWIMQdrXfP)
 def dp_View_Detail(qOksalnUBApmLyKDNSHEzWIMQdrXef,qOksalnUBApmLyKDNSHEzWIMQdrXfR):
  qOksalnUBApmLyKDNSHEzWIMQdrXGh =qOksalnUBApmLyKDNSHEzWIMQdrXfR.get('videoid')
  qOksalnUBApmLyKDNSHEzWIMQdrXGj =qOksalnUBApmLyKDNSHEzWIMQdrXfR.get('vidtype') 
  qOksalnUBApmLyKDNSHEzWIMQdrXPv=qOksalnUBApmLyKDNSHEzWIMQdrXfR.get('contenttype')
  qOksalnUBApmLyKDNSHEzWIMQdrXef.addon_log(qOksalnUBApmLyKDNSHEzWIMQdrXGh)
  qOksalnUBApmLyKDNSHEzWIMQdrXef.addon_log(qOksalnUBApmLyKDNSHEzWIMQdrXGj)
  qOksalnUBApmLyKDNSHEzWIMQdrXef.addon_log(qOksalnUBApmLyKDNSHEzWIMQdrXPv)
  qOksalnUBApmLyKDNSHEzWIMQdrXPg=qOksalnUBApmLyKDNSHEzWIMQdrXef.WavveObj.GetBookmarkInfo(qOksalnUBApmLyKDNSHEzWIMQdrXGh,qOksalnUBApmLyKDNSHEzWIMQdrXGj,qOksalnUBApmLyKDNSHEzWIMQdrXPv)
  if qOksalnUBApmLyKDNSHEzWIMQdrXGj=='tvshow':
   qOksalnUBApmLyKDNSHEzWIMQdrXRc={'mode':'SEASON_LIST','videoid':qOksalnUBApmLyKDNSHEzWIMQdrXPg['indexinfo']['videoid'],'vidtype':qOksalnUBApmLyKDNSHEzWIMQdrXPg['indexinfo']['vidtype'],}
   qOksalnUBApmLyKDNSHEzWIMQdrXFV='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(qOksalnUBApmLyKDNSHEzWIMQdrXRc))
  else:
   qOksalnUBApmLyKDNSHEzWIMQdrXRc={'mode':'MOVIE','contentid':qOksalnUBApmLyKDNSHEzWIMQdrXPg['indexinfo']['videoid'],'title':qOksalnUBApmLyKDNSHEzWIMQdrXPg['saveinfo']['infoLabels']['title'],'thumbnail':qOksalnUBApmLyKDNSHEzWIMQdrXPg['saveinfo']['thumbnail'],'age':qOksalnUBApmLyKDNSHEzWIMQdrXPg['saveinfo']['infoLabels']['mpaa'],}
   qOksalnUBApmLyKDNSHEzWIMQdrXFV='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(qOksalnUBApmLyKDNSHEzWIMQdrXRc))
  qOksalnUBApmLyKDNSHEzWIMQdrXRT=xbmcgui.ListItem(label=qOksalnUBApmLyKDNSHEzWIMQdrXPg['saveinfo']['title'],path=qOksalnUBApmLyKDNSHEzWIMQdrXFV)
  qOksalnUBApmLyKDNSHEzWIMQdrXRT.setArt(qOksalnUBApmLyKDNSHEzWIMQdrXPg['saveinfo']['thumbnail'])
  qOksalnUBApmLyKDNSHEzWIMQdrXRT.setInfo('Video',qOksalnUBApmLyKDNSHEzWIMQdrXPg['saveinfo']['infoLabels'])
  if qOksalnUBApmLyKDNSHEzWIMQdrXGj=='movie':
   qOksalnUBApmLyKDNSHEzWIMQdrXRT.setIsFolder(qOksalnUBApmLyKDNSHEzWIMQdrXfP)
   qOksalnUBApmLyKDNSHEzWIMQdrXRT.setProperty('IsPlayable','true')
  else:
   qOksalnUBApmLyKDNSHEzWIMQdrXRT.setIsFolder(qOksalnUBApmLyKDNSHEzWIMQdrXfx)
   qOksalnUBApmLyKDNSHEzWIMQdrXRT.setProperty('IsPlayable','false')
  qOksalnUBApmLyKDNSHEzWIMQdrXeo=xbmcgui.Dialog()
  qOksalnUBApmLyKDNSHEzWIMQdrXeo.info(qOksalnUBApmLyKDNSHEzWIMQdrXRT)
 def wavve_main(qOksalnUBApmLyKDNSHEzWIMQdrXef):
  qOksalnUBApmLyKDNSHEzWIMQdrXPV=qOksalnUBApmLyKDNSHEzWIMQdrXef.main_params.get('params')
  if qOksalnUBApmLyKDNSHEzWIMQdrXPV:
   qOksalnUBApmLyKDNSHEzWIMQdrXfe =base64.standard_b64decode(qOksalnUBApmLyKDNSHEzWIMQdrXPV).decode('utf-8')
   qOksalnUBApmLyKDNSHEzWIMQdrXfe =json.loads(qOksalnUBApmLyKDNSHEzWIMQdrXfe)
   qOksalnUBApmLyKDNSHEzWIMQdrXRi =qOksalnUBApmLyKDNSHEzWIMQdrXfe.get('mode')
   qOksalnUBApmLyKDNSHEzWIMQdrXfR =qOksalnUBApmLyKDNSHEzWIMQdrXfe.get('values')
  else:
   qOksalnUBApmLyKDNSHEzWIMQdrXRi=qOksalnUBApmLyKDNSHEzWIMQdrXef.main_params.get('mode',qOksalnUBApmLyKDNSHEzWIMQdrXfF)
   qOksalnUBApmLyKDNSHEzWIMQdrXfR=qOksalnUBApmLyKDNSHEzWIMQdrXef.main_params
  if qOksalnUBApmLyKDNSHEzWIMQdrXRi=='LOGOUT':
   qOksalnUBApmLyKDNSHEzWIMQdrXef.logout()
   return
  qOksalnUBApmLyKDNSHEzWIMQdrXef.login_main()
  if qOksalnUBApmLyKDNSHEzWIMQdrXRi is qOksalnUBApmLyKDNSHEzWIMQdrXfF:
   qOksalnUBApmLyKDNSHEzWIMQdrXef.dp_Main_List()
  elif qOksalnUBApmLyKDNSHEzWIMQdrXRi in['LIVE','VOD','MOVIE','SPORTS']:
   qOksalnUBApmLyKDNSHEzWIMQdrXef.play_VIDEO(qOksalnUBApmLyKDNSHEzWIMQdrXfR)
  elif qOksalnUBApmLyKDNSHEzWIMQdrXRi=='LIVE_CATAGORY':
   qOksalnUBApmLyKDNSHEzWIMQdrXef.dp_LiveCatagory_List(qOksalnUBApmLyKDNSHEzWIMQdrXfR)
  elif qOksalnUBApmLyKDNSHEzWIMQdrXRi=='MAIN_CATAGORY':
   qOksalnUBApmLyKDNSHEzWIMQdrXef.dp_MainCatagory_List(qOksalnUBApmLyKDNSHEzWIMQdrXfR)
  elif qOksalnUBApmLyKDNSHEzWIMQdrXRi=='SUPERSECTION_LIST':
   qOksalnUBApmLyKDNSHEzWIMQdrXef.dp_SuperSection_List(qOksalnUBApmLyKDNSHEzWIMQdrXfR)
  elif qOksalnUBApmLyKDNSHEzWIMQdrXRi=='BANDLIVESECTION_LIST':
   qOksalnUBApmLyKDNSHEzWIMQdrXef.dp_BandLiveSection_List(qOksalnUBApmLyKDNSHEzWIMQdrXfR)
  elif qOksalnUBApmLyKDNSHEzWIMQdrXRi=='BAND2SECTION_LIST':
   qOksalnUBApmLyKDNSHEzWIMQdrXef.dp_Band2Section_List(qOksalnUBApmLyKDNSHEzWIMQdrXfR)
  elif qOksalnUBApmLyKDNSHEzWIMQdrXRi=='PROGRAM_LIST':
   qOksalnUBApmLyKDNSHEzWIMQdrXef.dp_Program_List(qOksalnUBApmLyKDNSHEzWIMQdrXfR)
  elif qOksalnUBApmLyKDNSHEzWIMQdrXRi=='SEASON_LIST':
   qOksalnUBApmLyKDNSHEzWIMQdrXef.dp_Season_List(qOksalnUBApmLyKDNSHEzWIMQdrXfR)
  elif qOksalnUBApmLyKDNSHEzWIMQdrXRi=='EPISODE_LIST':
   qOksalnUBApmLyKDNSHEzWIMQdrXef.dp_Episode_List(qOksalnUBApmLyKDNSHEzWIMQdrXfR)
  elif qOksalnUBApmLyKDNSHEzWIMQdrXRi=='MOVIE_LIST':
   qOksalnUBApmLyKDNSHEzWIMQdrXef.dp_Movie_List(qOksalnUBApmLyKDNSHEzWIMQdrXfR)
  elif qOksalnUBApmLyKDNSHEzWIMQdrXRi=='LIVE_LIST':
   qOksalnUBApmLyKDNSHEzWIMQdrXef.dp_LiveChannel_List(qOksalnUBApmLyKDNSHEzWIMQdrXfR)
  elif qOksalnUBApmLyKDNSHEzWIMQdrXRi=='ORDER_BY':
   qOksalnUBApmLyKDNSHEzWIMQdrXef.dp_setEpOrderby(qOksalnUBApmLyKDNSHEzWIMQdrXfR)
  elif qOksalnUBApmLyKDNSHEzWIMQdrXRi=='SEARCH_GROUP':
   qOksalnUBApmLyKDNSHEzWIMQdrXef.dp_Search_Group(qOksalnUBApmLyKDNSHEzWIMQdrXfR)
  elif qOksalnUBApmLyKDNSHEzWIMQdrXRi in['SEARCH_LIST','LOCAL_SEARCH']:
   qOksalnUBApmLyKDNSHEzWIMQdrXef.dp_Search_List(qOksalnUBApmLyKDNSHEzWIMQdrXfR)
  elif qOksalnUBApmLyKDNSHEzWIMQdrXRi=='WATCH_GROUP':
   qOksalnUBApmLyKDNSHEzWIMQdrXef.dp_Watch_Group(qOksalnUBApmLyKDNSHEzWIMQdrXfR)
  elif qOksalnUBApmLyKDNSHEzWIMQdrXRi=='WATCH_LIST':
   qOksalnUBApmLyKDNSHEzWIMQdrXef.dp_Watch_List(qOksalnUBApmLyKDNSHEzWIMQdrXfR)
  elif qOksalnUBApmLyKDNSHEzWIMQdrXRi=='SET_BOOKMARK':
   qOksalnUBApmLyKDNSHEzWIMQdrXef.dp_Set_Bookmark(qOksalnUBApmLyKDNSHEzWIMQdrXfR)
  elif qOksalnUBApmLyKDNSHEzWIMQdrXRi in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   qOksalnUBApmLyKDNSHEzWIMQdrXef.dp_History_Remove(qOksalnUBApmLyKDNSHEzWIMQdrXfR)
  elif qOksalnUBApmLyKDNSHEzWIMQdrXRi in['TOTAL_SEARCH','TOTAL_HISTORY']:
   qOksalnUBApmLyKDNSHEzWIMQdrXef.dp_Global_Search(qOksalnUBApmLyKDNSHEzWIMQdrXfR)
  elif qOksalnUBApmLyKDNSHEzWIMQdrXRi=='SEARCH_HISTORY':
   qOksalnUBApmLyKDNSHEzWIMQdrXef.dp_Search_History(qOksalnUBApmLyKDNSHEzWIMQdrXfR)
  elif qOksalnUBApmLyKDNSHEzWIMQdrXRi=='MENU_BOOKMARK':
   qOksalnUBApmLyKDNSHEzWIMQdrXef.dp_Bookmark_Menu(qOksalnUBApmLyKDNSHEzWIMQdrXfR)
  elif qOksalnUBApmLyKDNSHEzWIMQdrXRi=='GAME_LIST':
   qOksalnUBApmLyKDNSHEzWIMQdrXef.dp_Sports_GameList(qOksalnUBApmLyKDNSHEzWIMQdrXfR)
  elif qOksalnUBApmLyKDNSHEzWIMQdrXRi=='VIEW_DETAIL':
   qOksalnUBApmLyKDNSHEzWIMQdrXef.dp_View_Detail(qOksalnUBApmLyKDNSHEzWIMQdrXfR)
  else:
   qOksalnUBApmLyKDNSHEzWIMQdrXfF
# Created by pyminifier (https://github.com/liftoff/pyminifier)
