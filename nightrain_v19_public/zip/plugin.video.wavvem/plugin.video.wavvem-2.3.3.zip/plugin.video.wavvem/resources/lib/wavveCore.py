__author__="NightRain"
iEdJQOuwambqojRUDvLxIcSysBXlMT=object
iEdJQOuwambqojRUDvLxIcSysBXlMY=None
iEdJQOuwambqojRUDvLxIcSysBXlMV=False
iEdJQOuwambqojRUDvLxIcSysBXlMg=open
iEdJQOuwambqojRUDvLxIcSysBXlMt=True
iEdJQOuwambqojRUDvLxIcSysBXlMF=range
iEdJQOuwambqojRUDvLxIcSysBXlMk=str
iEdJQOuwambqojRUDvLxIcSysBXlMh=Exception
iEdJQOuwambqojRUDvLxIcSysBXlMN=print
iEdJQOuwambqojRUDvLxIcSysBXlMn=dict
iEdJQOuwambqojRUDvLxIcSysBXlMH=int
iEdJQOuwambqojRUDvLxIcSysBXlMW=len
import urllib
import re
import json
import sys
import requests
import datetime
import base64
class iEdJQOuwambqojRUDvLxIcSysBXlrA(iEdJQOuwambqojRUDvLxIcSysBXlMT):
 def __init__(iEdJQOuwambqojRUDvLxIcSysBXlrp):
  iEdJQOuwambqojRUDvLxIcSysBXlrp.API_DOMAIN='https://apis.wavve.com'
  iEdJQOuwambqojRUDvLxIcSysBXlrp.WV ={}
  iEdJQOuwambqojRUDvLxIcSysBXlrp.Init_WV_Total()
  iEdJQOuwambqojRUDvLxIcSysBXlrp.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  iEdJQOuwambqojRUDvLxIcSysBXlrp.DEVICE ='pc'
  iEdJQOuwambqojRUDvLxIcSysBXlrp.DRM ='wm'
  iEdJQOuwambqojRUDvLxIcSysBXlrp.PARTNER ='pooq'
  iEdJQOuwambqojRUDvLxIcSysBXlrp.POOQZONE ='none'
  iEdJQOuwambqojRUDvLxIcSysBXlrp.REGION ='kor'
  iEdJQOuwambqojRUDvLxIcSysBXlrp.TARGETAGE ='all'
  iEdJQOuwambqojRUDvLxIcSysBXlrp.HTTPTAG ='https://'
  iEdJQOuwambqojRUDvLxIcSysBXlrp.LIST_LIMIT=30 
  iEdJQOuwambqojRUDvLxIcSysBXlrp.EP_LIMIT =30 
  iEdJQOuwambqojRUDvLxIcSysBXlrp.MV_LIMIT =24 
  iEdJQOuwambqojRUDvLxIcSysBXlrp.SEARCH_LIMIT=20 
  iEdJQOuwambqojRUDvLxIcSysBXlrp.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.82 Safari/537.36'
  iEdJQOuwambqojRUDvLxIcSysBXlrp.DEFAULT_HEADER={'user-agent':iEdJQOuwambqojRUDvLxIcSysBXlrp.USER_AGENT}
 def Init_WV_Total(iEdJQOuwambqojRUDvLxIcSysBXlrp):
  iEdJQOuwambqojRUDvLxIcSysBXlrp.WV={'account':{},'cookies':{},}
 def callRequestCookies(iEdJQOuwambqojRUDvLxIcSysBXlrp,jobtype,iEdJQOuwambqojRUDvLxIcSysBXlrC,payload=iEdJQOuwambqojRUDvLxIcSysBXlMY,params=iEdJQOuwambqojRUDvLxIcSysBXlMY,headers=iEdJQOuwambqojRUDvLxIcSysBXlMY,cookies=iEdJQOuwambqojRUDvLxIcSysBXlMY,redirects=iEdJQOuwambqojRUDvLxIcSysBXlMV):
  iEdJQOuwambqojRUDvLxIcSysBXlrK=iEdJQOuwambqojRUDvLxIcSysBXlrp.DEFAULT_HEADER
  if headers:iEdJQOuwambqojRUDvLxIcSysBXlrK.update(headers)
  if jobtype=='Get':
   iEdJQOuwambqojRUDvLxIcSysBXlrz=requests.get(iEdJQOuwambqojRUDvLxIcSysBXlrC,params=params,headers=iEdJQOuwambqojRUDvLxIcSysBXlrK,cookies=cookies,allow_redirects=redirects)
  else:
   iEdJQOuwambqojRUDvLxIcSysBXlrz=requests.post(iEdJQOuwambqojRUDvLxIcSysBXlrC,data=payload,params=params,headers=iEdJQOuwambqojRUDvLxIcSysBXlrK,cookies=cookies,allow_redirects=redirects)
  return iEdJQOuwambqojRUDvLxIcSysBXlrz
 def JsonFile_Save(iEdJQOuwambqojRUDvLxIcSysBXlrp,filename,iEdJQOuwambqojRUDvLxIcSysBXlrM):
  if filename=='':return iEdJQOuwambqojRUDvLxIcSysBXlMV
  try:
   fp=iEdJQOuwambqojRUDvLxIcSysBXlMg(filename,'w',-1,'utf-8')
   json.dump(iEdJQOuwambqojRUDvLxIcSysBXlrM,fp,indent=4,ensure_ascii=iEdJQOuwambqojRUDvLxIcSysBXlMV)
   fp.close()
  except:
   return iEdJQOuwambqojRUDvLxIcSysBXlMV
  return iEdJQOuwambqojRUDvLxIcSysBXlMt
 def JsonFile_Load(iEdJQOuwambqojRUDvLxIcSysBXlrp,filename):
  if filename=='':return{}
  try:
   fp=iEdJQOuwambqojRUDvLxIcSysBXlMg(filename,'r',-1,'utf-8')
   iEdJQOuwambqojRUDvLxIcSysBXlre=json.load(fp)
   fp.close()
  except:
   return{}
  return iEdJQOuwambqojRUDvLxIcSysBXlre
 def Save_session_acount(iEdJQOuwambqojRUDvLxIcSysBXlrp,iEdJQOuwambqojRUDvLxIcSysBXlrP,iEdJQOuwambqojRUDvLxIcSysBXlrT,iEdJQOuwambqojRUDvLxIcSysBXlrY):
  iEdJQOuwambqojRUDvLxIcSysBXlrp.WV['account']['wvid']=base64.standard_b64encode(iEdJQOuwambqojRUDvLxIcSysBXlrP.encode()).decode('utf-8')
  iEdJQOuwambqojRUDvLxIcSysBXlrp.WV['account']['wvpw']=base64.standard_b64encode(iEdJQOuwambqojRUDvLxIcSysBXlrT.encode()).decode('utf-8')
  iEdJQOuwambqojRUDvLxIcSysBXlrp.WV['account']['wvpf']=iEdJQOuwambqojRUDvLxIcSysBXlrY 
 def Load_session_acount(iEdJQOuwambqojRUDvLxIcSysBXlrp):
  try:
   iEdJQOuwambqojRUDvLxIcSysBXlrP=base64.standard_b64decode(iEdJQOuwambqojRUDvLxIcSysBXlrp.WV['account']['wvid']).decode('utf-8')
   iEdJQOuwambqojRUDvLxIcSysBXlrT=base64.standard_b64decode(iEdJQOuwambqojRUDvLxIcSysBXlrp.WV['account']['wvpw']).decode('utf-8')
   iEdJQOuwambqojRUDvLxIcSysBXlrY=iEdJQOuwambqojRUDvLxIcSysBXlrp.WV['account']['wvpf']
  except:
   return '','',0
  return iEdJQOuwambqojRUDvLxIcSysBXlrP,iEdJQOuwambqojRUDvLxIcSysBXlrT,iEdJQOuwambqojRUDvLxIcSysBXlrY
 def GetDefaultParams(iEdJQOuwambqojRUDvLxIcSysBXlrp,login=iEdJQOuwambqojRUDvLxIcSysBXlMt):
  iEdJQOuwambqojRUDvLxIcSysBXlrV={'apikey':iEdJQOuwambqojRUDvLxIcSysBXlrp.APIKEY,'credential':iEdJQOuwambqojRUDvLxIcSysBXlrp.WV['cookies']['credential']if login else 'none','device':iEdJQOuwambqojRUDvLxIcSysBXlrp.DEVICE,'drm':iEdJQOuwambqojRUDvLxIcSysBXlrp.DRM,'partner':iEdJQOuwambqojRUDvLxIcSysBXlrp.PARTNER,'pooqzone':iEdJQOuwambqojRUDvLxIcSysBXlrp.POOQZONE,'region':iEdJQOuwambqojRUDvLxIcSysBXlrp.REGION,'targetage':iEdJQOuwambqojRUDvLxIcSysBXlrp.TARGETAGE,}
  return iEdJQOuwambqojRUDvLxIcSysBXlrV
 def GetDefaultParams_AND(iEdJQOuwambqojRUDvLxIcSysBXlrp):
  iEdJQOuwambqojRUDvLxIcSysBXlrV={'apikey':'6A87455D54481A536DFB8AD397C5EC4D','credential':iEdJQOuwambqojRUDvLxIcSysBXlrp.WV['cookies']['credential'],'device':'ott','drm':iEdJQOuwambqojRUDvLxIcSysBXlrp.DRM,'partner':iEdJQOuwambqojRUDvLxIcSysBXlrp.PARTNER,'pooqzone':iEdJQOuwambqojRUDvLxIcSysBXlrp.POOQZONE,'region':iEdJQOuwambqojRUDvLxIcSysBXlrp.REGION,'targetage':iEdJQOuwambqojRUDvLxIcSysBXlrp.TARGETAGE,}
  return iEdJQOuwambqojRUDvLxIcSysBXlrV
 def GetGUID(iEdJQOuwambqojRUDvLxIcSysBXlrp,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   iEdJQOuwambqojRUDvLxIcSysBXlrg=iEdJQOuwambqojRUDvLxIcSysBXlrp.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   iEdJQOuwambqojRUDvLxIcSysBXlrt=GenerateRandomString(5)
   iEdJQOuwambqojRUDvLxIcSysBXlrF=iEdJQOuwambqojRUDvLxIcSysBXlrt+media+iEdJQOuwambqojRUDvLxIcSysBXlrg
   return iEdJQOuwambqojRUDvLxIcSysBXlrF
  def GenerateRandomString(num):
   from random import randint
   iEdJQOuwambqojRUDvLxIcSysBXlrk=""
   for i in iEdJQOuwambqojRUDvLxIcSysBXlMF(0,num):
    s=iEdJQOuwambqojRUDvLxIcSysBXlMk(randint(1,5))
    iEdJQOuwambqojRUDvLxIcSysBXlrk+=s
   return iEdJQOuwambqojRUDvLxIcSysBXlrk
  if guidType==3:
   iEdJQOuwambqojRUDvLxIcSysBXlrF=guid_str
  else:
   iEdJQOuwambqojRUDvLxIcSysBXlrF=GenerateID(guid_str)
  iEdJQOuwambqojRUDvLxIcSysBXlrh=iEdJQOuwambqojRUDvLxIcSysBXlrp.GetHash(iEdJQOuwambqojRUDvLxIcSysBXlrF)
  if guidType in[2,3]:
   iEdJQOuwambqojRUDvLxIcSysBXlrh='%s-%s-%s-%s-%s'%(iEdJQOuwambqojRUDvLxIcSysBXlrh[:8],iEdJQOuwambqojRUDvLxIcSysBXlrh[8:12],iEdJQOuwambqojRUDvLxIcSysBXlrh[12:16],iEdJQOuwambqojRUDvLxIcSysBXlrh[16:20],iEdJQOuwambqojRUDvLxIcSysBXlrh[20:])
  return iEdJQOuwambqojRUDvLxIcSysBXlrh
 def GetHash(iEdJQOuwambqojRUDvLxIcSysBXlrp,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return iEdJQOuwambqojRUDvLxIcSysBXlMk(m.hexdigest())
 def CheckQuality(iEdJQOuwambqojRUDvLxIcSysBXlrp,sel_qt,qt_list):
  iEdJQOuwambqojRUDvLxIcSysBXlrN=0
  for iEdJQOuwambqojRUDvLxIcSysBXlrn in qt_list:
   if sel_qt>=iEdJQOuwambqojRUDvLxIcSysBXlrn:return iEdJQOuwambqojRUDvLxIcSysBXlrn
   iEdJQOuwambqojRUDvLxIcSysBXlrN=iEdJQOuwambqojRUDvLxIcSysBXlrn
  return iEdJQOuwambqojRUDvLxIcSysBXlrN
 def Get_Now_Datetime(iEdJQOuwambqojRUDvLxIcSysBXlrp):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(iEdJQOuwambqojRUDvLxIcSysBXlrp,in_text):
  iEdJQOuwambqojRUDvLxIcSysBXlrW=in_text.replace('&lt;','<').replace('&gt;','>')
  iEdJQOuwambqojRUDvLxIcSysBXlrW=iEdJQOuwambqojRUDvLxIcSysBXlrW.replace('$O$','')
  iEdJQOuwambqojRUDvLxIcSysBXlrW=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',iEdJQOuwambqojRUDvLxIcSysBXlrW)
  iEdJQOuwambqojRUDvLxIcSysBXlrW=iEdJQOuwambqojRUDvLxIcSysBXlrW.lstrip('#')
  return iEdJQOuwambqojRUDvLxIcSysBXlrW
 def GetCredential(iEdJQOuwambqojRUDvLxIcSysBXlrp,user_id,user_pw,user_pf):
  iEdJQOuwambqojRUDvLxIcSysBXlrG=iEdJQOuwambqojRUDvLxIcSysBXlMV
  try:
   iEdJQOuwambqojRUDvLxIcSysBXlrC=iEdJQOuwambqojRUDvLxIcSysBXlrp.API_DOMAIN+ '/login'
   iEdJQOuwambqojRUDvLxIcSysBXlrV=iEdJQOuwambqojRUDvLxIcSysBXlrp.GetDefaultParams(login=iEdJQOuwambqojRUDvLxIcSysBXlMV)
   iEdJQOuwambqojRUDvLxIcSysBXlAr={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   iEdJQOuwambqojRUDvLxIcSysBXlAp=iEdJQOuwambqojRUDvLxIcSysBXlrp.callRequestCookies('Post',iEdJQOuwambqojRUDvLxIcSysBXlrC,payload=iEdJQOuwambqojRUDvLxIcSysBXlAr,params=iEdJQOuwambqojRUDvLxIcSysBXlrV,headers=iEdJQOuwambqojRUDvLxIcSysBXlMY,cookies=iEdJQOuwambqojRUDvLxIcSysBXlMY)
   iEdJQOuwambqojRUDvLxIcSysBXlAK=json.loads(iEdJQOuwambqojRUDvLxIcSysBXlAp.text)
   iEdJQOuwambqojRUDvLxIcSysBXlrp.WV['cookies']['credential']=iEdJQOuwambqojRUDvLxIcSysBXlAK['credential']
   if user_pf!=0:
    iEdJQOuwambqojRUDvLxIcSysBXlAr={'id':iEdJQOuwambqojRUDvLxIcSysBXlrp.WV['cookies']['credential'],'password':'','profile':iEdJQOuwambqojRUDvLxIcSysBXlMk(user_pf),'pushid':'','type':'credential'}
    iEdJQOuwambqojRUDvLxIcSysBXlrV =iEdJQOuwambqojRUDvLxIcSysBXlrp.GetDefaultParams(login=iEdJQOuwambqojRUDvLxIcSysBXlMt) 
    iEdJQOuwambqojRUDvLxIcSysBXlAp=iEdJQOuwambqojRUDvLxIcSysBXlrp.callRequestCookies('Post',iEdJQOuwambqojRUDvLxIcSysBXlrC,payload=iEdJQOuwambqojRUDvLxIcSysBXlAr,params=iEdJQOuwambqojRUDvLxIcSysBXlrV,headers=iEdJQOuwambqojRUDvLxIcSysBXlMY,cookies=iEdJQOuwambqojRUDvLxIcSysBXlMY)
    iEdJQOuwambqojRUDvLxIcSysBXlAK=json.loads(iEdJQOuwambqojRUDvLxIcSysBXlAp.text)
    iEdJQOuwambqojRUDvLxIcSysBXlrp.WV['cookies']['credential']=iEdJQOuwambqojRUDvLxIcSysBXlAK['credential']
   iEdJQOuwambqojRUDvLxIcSysBXlAz=user_id+iEdJQOuwambqojRUDvLxIcSysBXlMk(user_pf) 
   iEdJQOuwambqojRUDvLxIcSysBXlrp.WV['cookies']['uuid']=iEdJQOuwambqojRUDvLxIcSysBXlrp.GetGUID(guid_str=iEdJQOuwambqojRUDvLxIcSysBXlAz,guidType=3)
   iEdJQOuwambqojRUDvLxIcSysBXlrG=iEdJQOuwambqojRUDvLxIcSysBXlMt
  except iEdJQOuwambqojRUDvLxIcSysBXlMh as exception:
   iEdJQOuwambqojRUDvLxIcSysBXlMN(exception)
   iEdJQOuwambqojRUDvLxIcSysBXlrp.Init_WV_Total()
  return iEdJQOuwambqojRUDvLxIcSysBXlrG
 def GetIssue(iEdJQOuwambqojRUDvLxIcSysBXlrp):
  iEdJQOuwambqojRUDvLxIcSysBXlAM=iEdJQOuwambqojRUDvLxIcSysBXlMV
  try:
   iEdJQOuwambqojRUDvLxIcSysBXlrC=iEdJQOuwambqojRUDvLxIcSysBXlrp.API_DOMAIN+'/guid/issue'
   iEdJQOuwambqojRUDvLxIcSysBXlrV=iEdJQOuwambqojRUDvLxIcSysBXlrp.GetDefaultParams()
   iEdJQOuwambqojRUDvLxIcSysBXlAp=iEdJQOuwambqojRUDvLxIcSysBXlrp.callRequestCookies('Get',iEdJQOuwambqojRUDvLxIcSysBXlrC,payload=iEdJQOuwambqojRUDvLxIcSysBXlMY,params=iEdJQOuwambqojRUDvLxIcSysBXlrV,headers=iEdJQOuwambqojRUDvLxIcSysBXlMY,cookies=iEdJQOuwambqojRUDvLxIcSysBXlMY)
   iEdJQOuwambqojRUDvLxIcSysBXlAK=json.loads(iEdJQOuwambqojRUDvLxIcSysBXlAp.text)
   iEdJQOuwambqojRUDvLxIcSysBXlAf=iEdJQOuwambqojRUDvLxIcSysBXlAK['guid']
   iEdJQOuwambqojRUDvLxIcSysBXlAe=iEdJQOuwambqojRUDvLxIcSysBXlAK['guidtimestamp']
   if iEdJQOuwambqojRUDvLxIcSysBXlAf:iEdJQOuwambqojRUDvLxIcSysBXlAM=iEdJQOuwambqojRUDvLxIcSysBXlMt
  except iEdJQOuwambqojRUDvLxIcSysBXlMh as exception:
   iEdJQOuwambqojRUDvLxIcSysBXlMN(exception)
   iEdJQOuwambqojRUDvLxIcSysBXlAf='none'
   iEdJQOuwambqojRUDvLxIcSysBXlAe='none' 
  iEdJQOuwambqojRUDvLxIcSysBXlrp.guid=iEdJQOuwambqojRUDvLxIcSysBXlAf
  iEdJQOuwambqojRUDvLxIcSysBXlrp.guidtimestamp=iEdJQOuwambqojRUDvLxIcSysBXlAe
  return iEdJQOuwambqojRUDvLxIcSysBXlAM
 def Baseapi_Parse(iEdJQOuwambqojRUDvLxIcSysBXlrp,iEdJQOuwambqojRUDvLxIcSysBXlAV):
  try:
   iEdJQOuwambqojRUDvLxIcSysBXlAP =urllib.parse.urlsplit(iEdJQOuwambqojRUDvLxIcSysBXlAV)
   if iEdJQOuwambqojRUDvLxIcSysBXlAP.netloc=='':
    iEdJQOuwambqojRUDvLxIcSysBXlrC=iEdJQOuwambqojRUDvLxIcSysBXlrp.HTTPTAG+iEdJQOuwambqojRUDvLxIcSysBXlAP.netloc+iEdJQOuwambqojRUDvLxIcSysBXlAP.path
   else:
    iEdJQOuwambqojRUDvLxIcSysBXlrC=iEdJQOuwambqojRUDvLxIcSysBXlAP.scheme+'://'+iEdJQOuwambqojRUDvLxIcSysBXlAP.netloc+iEdJQOuwambqojRUDvLxIcSysBXlAP.path
   iEdJQOuwambqojRUDvLxIcSysBXlrV=iEdJQOuwambqojRUDvLxIcSysBXlMn(urllib.parse.parse_qsl(iEdJQOuwambqojRUDvLxIcSysBXlAP.query))
  except iEdJQOuwambqojRUDvLxIcSysBXlMh as exception:
   iEdJQOuwambqojRUDvLxIcSysBXlMN(exception)
   return '',{}
  return iEdJQOuwambqojRUDvLxIcSysBXlrC,iEdJQOuwambqojRUDvLxIcSysBXlrV
 def GetSupermultiUrl(iEdJQOuwambqojRUDvLxIcSysBXlrp,sCode,sIndex='0'):
  try:
   iEdJQOuwambqojRUDvLxIcSysBXlrC=iEdJQOuwambqojRUDvLxIcSysBXlrp.API_DOMAIN+'/cf/supermultisections/'+sCode
   iEdJQOuwambqojRUDvLxIcSysBXlrV=iEdJQOuwambqojRUDvLxIcSysBXlrp.GetDefaultParams(login=iEdJQOuwambqojRUDvLxIcSysBXlMV)
   iEdJQOuwambqojRUDvLxIcSysBXlAp=iEdJQOuwambqojRUDvLxIcSysBXlrp.callRequestCookies('Get',iEdJQOuwambqojRUDvLxIcSysBXlrC,payload=iEdJQOuwambqojRUDvLxIcSysBXlMY,params=iEdJQOuwambqojRUDvLxIcSysBXlrV,headers=iEdJQOuwambqojRUDvLxIcSysBXlMY,cookies=iEdJQOuwambqojRUDvLxIcSysBXlMY)
   iEdJQOuwambqojRUDvLxIcSysBXlAK=json.loads(iEdJQOuwambqojRUDvLxIcSysBXlAp.text)
   iEdJQOuwambqojRUDvLxIcSysBXlAT=iEdJQOuwambqojRUDvLxIcSysBXlAK['multisectionlist'][iEdJQOuwambqojRUDvLxIcSysBXlMH(sIndex)]['eventlist'][1]['url']
  except iEdJQOuwambqojRUDvLxIcSysBXlMh as exception:
   iEdJQOuwambqojRUDvLxIcSysBXlMN(exception)
   return ''
  return iEdJQOuwambqojRUDvLxIcSysBXlAT
 def Get_LiveCatagory_List(iEdJQOuwambqojRUDvLxIcSysBXlrp,sCode,sIndex='0'):
  iEdJQOuwambqojRUDvLxIcSysBXlAY=[]
  iEdJQOuwambqojRUDvLxIcSysBXlAV =iEdJQOuwambqojRUDvLxIcSysBXlrp.GetSupermultiUrl(sCode,sIndex)
  (iEdJQOuwambqojRUDvLxIcSysBXlrC,iEdJQOuwambqojRUDvLxIcSysBXlrV)=iEdJQOuwambqojRUDvLxIcSysBXlrp.Baseapi_Parse(iEdJQOuwambqojRUDvLxIcSysBXlAV)
  if iEdJQOuwambqojRUDvLxIcSysBXlrC=='':return iEdJQOuwambqojRUDvLxIcSysBXlAY,''
  try:
   iEdJQOuwambqojRUDvLxIcSysBXlrV.update(iEdJQOuwambqojRUDvLxIcSysBXlrp.GetDefaultParams(login=iEdJQOuwambqojRUDvLxIcSysBXlMV))
   iEdJQOuwambqojRUDvLxIcSysBXlAp=iEdJQOuwambqojRUDvLxIcSysBXlrp.callRequestCookies('Get',iEdJQOuwambqojRUDvLxIcSysBXlrC,payload=iEdJQOuwambqojRUDvLxIcSysBXlMY,params=iEdJQOuwambqojRUDvLxIcSysBXlrV,headers=iEdJQOuwambqojRUDvLxIcSysBXlMY,cookies=iEdJQOuwambqojRUDvLxIcSysBXlMY)
   iEdJQOuwambqojRUDvLxIcSysBXlAK=json.loads(iEdJQOuwambqojRUDvLxIcSysBXlAp.text)
   if not('filter_item_list' in iEdJQOuwambqojRUDvLxIcSysBXlAK['filter']['filterlist'][0]):return[],''
   iEdJQOuwambqojRUDvLxIcSysBXlAt=iEdJQOuwambqojRUDvLxIcSysBXlAK['filter']['filterlist'][0]['filter_item_list']
   for iEdJQOuwambqojRUDvLxIcSysBXlAF in iEdJQOuwambqojRUDvLxIcSysBXlAt:
    iEdJQOuwambqojRUDvLxIcSysBXlAk={'title':iEdJQOuwambqojRUDvLxIcSysBXlAF['title'],'genre':iEdJQOuwambqojRUDvLxIcSysBXlAF['api_parameters'][iEdJQOuwambqojRUDvLxIcSysBXlAF['api_parameters'].index('=')+1:]}
    iEdJQOuwambqojRUDvLxIcSysBXlAY.append(iEdJQOuwambqojRUDvLxIcSysBXlAk)
  except iEdJQOuwambqojRUDvLxIcSysBXlMh as exception:
   iEdJQOuwambqojRUDvLxIcSysBXlMN(exception)
   return[],''
  return iEdJQOuwambqojRUDvLxIcSysBXlAY,iEdJQOuwambqojRUDvLxIcSysBXlAV
 def Get_MainCatagory_List(iEdJQOuwambqojRUDvLxIcSysBXlrp,sCode,sIndex='0'):
  iEdJQOuwambqojRUDvLxIcSysBXlAY=[]
  iEdJQOuwambqojRUDvLxIcSysBXlAV =iEdJQOuwambqojRUDvLxIcSysBXlrp.GetSupermultiUrl(sCode,sIndex)
  (iEdJQOuwambqojRUDvLxIcSysBXlrC,iEdJQOuwambqojRUDvLxIcSysBXlrV)=iEdJQOuwambqojRUDvLxIcSysBXlrp.Baseapi_Parse(iEdJQOuwambqojRUDvLxIcSysBXlAV)
  if iEdJQOuwambqojRUDvLxIcSysBXlrC=='':return iEdJQOuwambqojRUDvLxIcSysBXlAY
  try:
   iEdJQOuwambqojRUDvLxIcSysBXlrV.update(iEdJQOuwambqojRUDvLxIcSysBXlrp.GetDefaultParams(login=iEdJQOuwambqojRUDvLxIcSysBXlMV))
   iEdJQOuwambqojRUDvLxIcSysBXlAp=iEdJQOuwambqojRUDvLxIcSysBXlrp.callRequestCookies('Get',iEdJQOuwambqojRUDvLxIcSysBXlrC,payload=iEdJQOuwambqojRUDvLxIcSysBXlMY,params=iEdJQOuwambqojRUDvLxIcSysBXlrV,headers=iEdJQOuwambqojRUDvLxIcSysBXlMY,cookies=iEdJQOuwambqojRUDvLxIcSysBXlMY)
   iEdJQOuwambqojRUDvLxIcSysBXlAK=json.loads(iEdJQOuwambqojRUDvLxIcSysBXlAp.text)
   if not('celllist' in iEdJQOuwambqojRUDvLxIcSysBXlAK['band']):return[]
   iEdJQOuwambqojRUDvLxIcSysBXlAt=iEdJQOuwambqojRUDvLxIcSysBXlAK['band']['celllist']
   for iEdJQOuwambqojRUDvLxIcSysBXlAF in iEdJQOuwambqojRUDvLxIcSysBXlAt:
    iEdJQOuwambqojRUDvLxIcSysBXlAh =iEdJQOuwambqojRUDvLxIcSysBXlAF['event_list'][1]['url']
    (iEdJQOuwambqojRUDvLxIcSysBXlAN,iEdJQOuwambqojRUDvLxIcSysBXlAn)=iEdJQOuwambqojRUDvLxIcSysBXlrp.Baseapi_Parse(iEdJQOuwambqojRUDvLxIcSysBXlAh)
    iEdJQOuwambqojRUDvLxIcSysBXlAk={'title':iEdJQOuwambqojRUDvLxIcSysBXlAF['title_list'][0]['text'],'suburl':iEdJQOuwambqojRUDvLxIcSysBXlAN,'subapi':iEdJQOuwambqojRUDvLxIcSysBXlAn.get('api'),'subtype':'catagory' if iEdJQOuwambqojRUDvLxIcSysBXlAn else 'supersection'}
    iEdJQOuwambqojRUDvLxIcSysBXlAY.append(iEdJQOuwambqojRUDvLxIcSysBXlAk)
  except iEdJQOuwambqojRUDvLxIcSysBXlMh as exception:
   iEdJQOuwambqojRUDvLxIcSysBXlMN(exception)
   return[]
  return iEdJQOuwambqojRUDvLxIcSysBXlAY
 def Get_SuperMultiSection_List(iEdJQOuwambqojRUDvLxIcSysBXlrp,subapi_text):
  iEdJQOuwambqojRUDvLxIcSysBXlAY=[]
  iEdJQOuwambqojRUDvLxIcSysBXlrV={}
  try:
   iEdJQOuwambqojRUDvLxIcSysBXlAP =urllib.parse.urlsplit(subapi_text)
   if iEdJQOuwambqojRUDvLxIcSysBXlAP.path.find('apis.wavve.com')>=0: 
    iEdJQOuwambqojRUDvLxIcSysBXlrC=iEdJQOuwambqojRUDvLxIcSysBXlrp.HTTPTAG+iEdJQOuwambqojRUDvLxIcSysBXlAP.path 
    iEdJQOuwambqojRUDvLxIcSysBXlrV=iEdJQOuwambqojRUDvLxIcSysBXlMn(urllib.parse.parse_qsl(iEdJQOuwambqojRUDvLxIcSysBXlAP.query))
   else:
    iEdJQOuwambqojRUDvLxIcSysBXlrC=iEdJQOuwambqojRUDvLxIcSysBXlrp.API_DOMAIN+'/cf'+iEdJQOuwambqojRUDvLxIcSysBXlAP.path 
   iEdJQOuwambqojRUDvLxIcSysBXlrC=iEdJQOuwambqojRUDvLxIcSysBXlrC.replace('supermultisection/','supermultisections/')
  except iEdJQOuwambqojRUDvLxIcSysBXlMh as exception:
   iEdJQOuwambqojRUDvLxIcSysBXlMN(exception)
   return[]
  try:
   iEdJQOuwambqojRUDvLxIcSysBXlrV.update(iEdJQOuwambqojRUDvLxIcSysBXlrp.GetDefaultParams(login=iEdJQOuwambqojRUDvLxIcSysBXlMV))
   iEdJQOuwambqojRUDvLxIcSysBXlAp=iEdJQOuwambqojRUDvLxIcSysBXlrp.callRequestCookies('Get',iEdJQOuwambqojRUDvLxIcSysBXlrC,payload=iEdJQOuwambqojRUDvLxIcSysBXlMY,params=iEdJQOuwambqojRUDvLxIcSysBXlMY,headers=iEdJQOuwambqojRUDvLxIcSysBXlMY,cookies=iEdJQOuwambqojRUDvLxIcSysBXlMY)
   iEdJQOuwambqojRUDvLxIcSysBXlAK=json.loads(iEdJQOuwambqojRUDvLxIcSysBXlAp.text)
   if not('multisectionlist' in iEdJQOuwambqojRUDvLxIcSysBXlAK):return[]
   iEdJQOuwambqojRUDvLxIcSysBXlAt=iEdJQOuwambqojRUDvLxIcSysBXlAK['multisectionlist']
   for iEdJQOuwambqojRUDvLxIcSysBXlAF in iEdJQOuwambqojRUDvLxIcSysBXlAt:
    iEdJQOuwambqojRUDvLxIcSysBXlAH=iEdJQOuwambqojRUDvLxIcSysBXlAF['title']
    if iEdJQOuwambqojRUDvLxIcSysBXlMW(iEdJQOuwambqojRUDvLxIcSysBXlAH)==0:continue
    if iEdJQOuwambqojRUDvLxIcSysBXlAH=='minor':continue
    if re.search(u'베너',iEdJQOuwambqojRUDvLxIcSysBXlAH):continue
    if re.search(u'배너',iEdJQOuwambqojRUDvLxIcSysBXlAH):continue 
    if iEdJQOuwambqojRUDvLxIcSysBXlAF['force_refresh']=='y':continue
    if iEdJQOuwambqojRUDvLxIcSysBXlMW(iEdJQOuwambqojRUDvLxIcSysBXlAF['eventlist'])>=3:
     iEdJQOuwambqojRUDvLxIcSysBXlAn =iEdJQOuwambqojRUDvLxIcSysBXlAF['eventlist'][2]['url']
    else:
     iEdJQOuwambqojRUDvLxIcSysBXlAn =iEdJQOuwambqojRUDvLxIcSysBXlAF['eventlist'][1]['url']
    iEdJQOuwambqojRUDvLxIcSysBXlAW=iEdJQOuwambqojRUDvLxIcSysBXlAF['cell_type']
    if iEdJQOuwambqojRUDvLxIcSysBXlAW=='band_2':
     if iEdJQOuwambqojRUDvLxIcSysBXlAn.find('channellist=')>=0:
      iEdJQOuwambqojRUDvLxIcSysBXlAW='band_live'
    iEdJQOuwambqojRUDvLxIcSysBXlAk={'title':iEdJQOuwambqojRUDvLxIcSysBXlrp.Get_ChangeText(iEdJQOuwambqojRUDvLxIcSysBXlAH),'subapi':iEdJQOuwambqojRUDvLxIcSysBXlAn,'cell_type':iEdJQOuwambqojRUDvLxIcSysBXlAW}
    iEdJQOuwambqojRUDvLxIcSysBXlAY.append(iEdJQOuwambqojRUDvLxIcSysBXlAk)
  except iEdJQOuwambqojRUDvLxIcSysBXlMh as exception:
   iEdJQOuwambqojRUDvLxIcSysBXlMN(exception)
   return[]
  return iEdJQOuwambqojRUDvLxIcSysBXlAY
 def Get_BandLiveSection_List(iEdJQOuwambqojRUDvLxIcSysBXlrp,iEdJQOuwambqojRUDvLxIcSysBXlAV,page_int=1):
  iEdJQOuwambqojRUDvLxIcSysBXlAG=[]
  iEdJQOuwambqojRUDvLxIcSysBXlAC=iEdJQOuwambqojRUDvLxIcSysBXlpf=1
  iEdJQOuwambqojRUDvLxIcSysBXlpr=iEdJQOuwambqojRUDvLxIcSysBXlMV
  try:
   (iEdJQOuwambqojRUDvLxIcSysBXlrC,iEdJQOuwambqojRUDvLxIcSysBXlrV)=iEdJQOuwambqojRUDvLxIcSysBXlrp.Baseapi_Parse(iEdJQOuwambqojRUDvLxIcSysBXlAV)
  except iEdJQOuwambqojRUDvLxIcSysBXlMh as exception:
   iEdJQOuwambqojRUDvLxIcSysBXlMN(exception)
   return[],iEdJQOuwambqojRUDvLxIcSysBXlMV
  try:
   iEdJQOuwambqojRUDvLxIcSysBXlrV['limit']=iEdJQOuwambqojRUDvLxIcSysBXlrp.LIST_LIMIT
   iEdJQOuwambqojRUDvLxIcSysBXlrV['offset']=iEdJQOuwambqojRUDvLxIcSysBXlMk((page_int-1)*iEdJQOuwambqojRUDvLxIcSysBXlrp.LIST_LIMIT)
   iEdJQOuwambqojRUDvLxIcSysBXlrV.update(iEdJQOuwambqojRUDvLxIcSysBXlrp.GetDefaultParams(login=iEdJQOuwambqojRUDvLxIcSysBXlMV))
   iEdJQOuwambqojRUDvLxIcSysBXlAp=iEdJQOuwambqojRUDvLxIcSysBXlrp.callRequestCookies('Get',iEdJQOuwambqojRUDvLxIcSysBXlrC,payload=iEdJQOuwambqojRUDvLxIcSysBXlMY,params=iEdJQOuwambqojRUDvLxIcSysBXlrV,headers=iEdJQOuwambqojRUDvLxIcSysBXlMY,cookies=iEdJQOuwambqojRUDvLxIcSysBXlMY)
   iEdJQOuwambqojRUDvLxIcSysBXlAK=json.loads(iEdJQOuwambqojRUDvLxIcSysBXlAp.text)
   if not('celllist' in iEdJQOuwambqojRUDvLxIcSysBXlAK['cell_toplist']):return[],iEdJQOuwambqojRUDvLxIcSysBXlMV
   iEdJQOuwambqojRUDvLxIcSysBXlAt=iEdJQOuwambqojRUDvLxIcSysBXlAK['cell_toplist']['celllist']
   for iEdJQOuwambqojRUDvLxIcSysBXlAF in iEdJQOuwambqojRUDvLxIcSysBXlAt:
    iEdJQOuwambqojRUDvLxIcSysBXlpA =iEdJQOuwambqojRUDvLxIcSysBXlAF['event_list'][1]['url']
    iEdJQOuwambqojRUDvLxIcSysBXlpK=urllib.parse.urlsplit(iEdJQOuwambqojRUDvLxIcSysBXlpA).query
    iEdJQOuwambqojRUDvLxIcSysBXlpK=iEdJQOuwambqojRUDvLxIcSysBXlMn(urllib.parse.parse_qsl(iEdJQOuwambqojRUDvLxIcSysBXlpK))
    iEdJQOuwambqojRUDvLxIcSysBXlpz='channelid'
    iEdJQOuwambqojRUDvLxIcSysBXlpM=iEdJQOuwambqojRUDvLxIcSysBXlpK[iEdJQOuwambqojRUDvLxIcSysBXlpz]
    iEdJQOuwambqojRUDvLxIcSysBXlAk={'studio':iEdJQOuwambqojRUDvLxIcSysBXlAF['title_list'][0]['text'],'tvshowtitle':iEdJQOuwambqojRUDvLxIcSysBXlrp.Get_ChangeText(iEdJQOuwambqojRUDvLxIcSysBXlAF['title_list'][1]['text']),'channelid':iEdJQOuwambqojRUDvLxIcSysBXlpM,'age':iEdJQOuwambqojRUDvLxIcSysBXlAF.get('age'),'thumbnail':'https://%s'%iEdJQOuwambqojRUDvLxIcSysBXlAF.get('thumbnail')}
    iEdJQOuwambqojRUDvLxIcSysBXlAG.append(iEdJQOuwambqojRUDvLxIcSysBXlAk)
   iEdJQOuwambqojRUDvLxIcSysBXlAC=iEdJQOuwambqojRUDvLxIcSysBXlMH(iEdJQOuwambqojRUDvLxIcSysBXlAK['cell_toplist']['pagecount'])
   if iEdJQOuwambqojRUDvLxIcSysBXlAK['cell_toplist']['count']:iEdJQOuwambqojRUDvLxIcSysBXlpf =iEdJQOuwambqojRUDvLxIcSysBXlMH(iEdJQOuwambqojRUDvLxIcSysBXlAK['cell_toplist']['count'])
   else:iEdJQOuwambqojRUDvLxIcSysBXlpf=iEdJQOuwambqojRUDvLxIcSysBXlrp.LIST_LIMIT*page_int
   iEdJQOuwambqojRUDvLxIcSysBXlpr=iEdJQOuwambqojRUDvLxIcSysBXlAC>iEdJQOuwambqojRUDvLxIcSysBXlpf
  except iEdJQOuwambqojRUDvLxIcSysBXlMh as exception:
   iEdJQOuwambqojRUDvLxIcSysBXlMN(exception)
   return[],iEdJQOuwambqojRUDvLxIcSysBXlMV
  return iEdJQOuwambqojRUDvLxIcSysBXlAG,iEdJQOuwambqojRUDvLxIcSysBXlpr
 def Get_Band2Section_List(iEdJQOuwambqojRUDvLxIcSysBXlrp,iEdJQOuwambqojRUDvLxIcSysBXlAV,page_int=1):
  iEdJQOuwambqojRUDvLxIcSysBXlpe=[]
  iEdJQOuwambqojRUDvLxIcSysBXlAC=iEdJQOuwambqojRUDvLxIcSysBXlpf=1
  iEdJQOuwambqojRUDvLxIcSysBXlpr=iEdJQOuwambqojRUDvLxIcSysBXlMV
  try:
   (iEdJQOuwambqojRUDvLxIcSysBXlrC,iEdJQOuwambqojRUDvLxIcSysBXlrV)=iEdJQOuwambqojRUDvLxIcSysBXlrp.Baseapi_Parse(iEdJQOuwambqojRUDvLxIcSysBXlAV)
  except iEdJQOuwambqojRUDvLxIcSysBXlMh as exception:
   iEdJQOuwambqojRUDvLxIcSysBXlMN(exception)
   return[],iEdJQOuwambqojRUDvLxIcSysBXlMV
  try:
   iEdJQOuwambqojRUDvLxIcSysBXlrV['came'] ='BandView'
   iEdJQOuwambqojRUDvLxIcSysBXlrV['limit']=iEdJQOuwambqojRUDvLxIcSysBXlrp.LIST_LIMIT
   iEdJQOuwambqojRUDvLxIcSysBXlrV['offset']=iEdJQOuwambqojRUDvLxIcSysBXlMk((page_int-1)*iEdJQOuwambqojRUDvLxIcSysBXlrp.LIST_LIMIT)
   iEdJQOuwambqojRUDvLxIcSysBXlrV.update(iEdJQOuwambqojRUDvLxIcSysBXlrp.GetDefaultParams(login=iEdJQOuwambqojRUDvLxIcSysBXlMV))
   iEdJQOuwambqojRUDvLxIcSysBXlAp=iEdJQOuwambqojRUDvLxIcSysBXlrp.callRequestCookies('Get',iEdJQOuwambqojRUDvLxIcSysBXlrC,payload=iEdJQOuwambqojRUDvLxIcSysBXlMY,params=iEdJQOuwambqojRUDvLxIcSysBXlrV,headers=iEdJQOuwambqojRUDvLxIcSysBXlMY,cookies=iEdJQOuwambqojRUDvLxIcSysBXlMY)
   iEdJQOuwambqojRUDvLxIcSysBXlAK=json.loads(iEdJQOuwambqojRUDvLxIcSysBXlAp.text)
   if not('celllist' in iEdJQOuwambqojRUDvLxIcSysBXlAK['cell_toplist']):return[],iEdJQOuwambqojRUDvLxIcSysBXlMV
   iEdJQOuwambqojRUDvLxIcSysBXlAt=iEdJQOuwambqojRUDvLxIcSysBXlAK['cell_toplist']['celllist']
   for iEdJQOuwambqojRUDvLxIcSysBXlAF in iEdJQOuwambqojRUDvLxIcSysBXlAt:
    iEdJQOuwambqojRUDvLxIcSysBXlpA =iEdJQOuwambqojRUDvLxIcSysBXlAF['event_list'][1]['url']
    iEdJQOuwambqojRUDvLxIcSysBXlpK=urllib.parse.urlsplit(iEdJQOuwambqojRUDvLxIcSysBXlpA).query
    iEdJQOuwambqojRUDvLxIcSysBXlpK=iEdJQOuwambqojRUDvLxIcSysBXlMn(urllib.parse.parse_qsl(iEdJQOuwambqojRUDvLxIcSysBXlpK))
    iEdJQOuwambqojRUDvLxIcSysBXlpz='contentid'
    iEdJQOuwambqojRUDvLxIcSysBXlpM=iEdJQOuwambqojRUDvLxIcSysBXlpK[iEdJQOuwambqojRUDvLxIcSysBXlpz]
    iEdJQOuwambqojRUDvLxIcSysBXlAk={'programtitle':iEdJQOuwambqojRUDvLxIcSysBXlAF['title_list'][0]['text'],'episodetitle':iEdJQOuwambqojRUDvLxIcSysBXlrp.Get_ChangeText(iEdJQOuwambqojRUDvLxIcSysBXlAF['title_list'][1]['text']),'age':iEdJQOuwambqojRUDvLxIcSysBXlAF.get('age'),'thumbnail':iEdJQOuwambqojRUDvLxIcSysBXlrp.HTTPTAG+iEdJQOuwambqojRUDvLxIcSysBXlAF.get('thumbnail'),'vidtype':iEdJQOuwambqojRUDvLxIcSysBXlpz,'videoid':iEdJQOuwambqojRUDvLxIcSysBXlpM}
    iEdJQOuwambqojRUDvLxIcSysBXlpe.append(iEdJQOuwambqojRUDvLxIcSysBXlAk)
   iEdJQOuwambqojRUDvLxIcSysBXlAC=iEdJQOuwambqojRUDvLxIcSysBXlMH(iEdJQOuwambqojRUDvLxIcSysBXlAK['cell_toplist']['pagecount'])
   if iEdJQOuwambqojRUDvLxIcSysBXlAK['cell_toplist']['count']:iEdJQOuwambqojRUDvLxIcSysBXlpf =iEdJQOuwambqojRUDvLxIcSysBXlMH(iEdJQOuwambqojRUDvLxIcSysBXlAK['cell_toplist']['count'])
   else:iEdJQOuwambqojRUDvLxIcSysBXlpf=iEdJQOuwambqojRUDvLxIcSysBXlrp.LIST_LIMIT*page_int
   iEdJQOuwambqojRUDvLxIcSysBXlpr=iEdJQOuwambqojRUDvLxIcSysBXlAC>iEdJQOuwambqojRUDvLxIcSysBXlpf
  except iEdJQOuwambqojRUDvLxIcSysBXlMh as exception:
   iEdJQOuwambqojRUDvLxIcSysBXlMN(exception)
   return[],iEdJQOuwambqojRUDvLxIcSysBXlMV
  return iEdJQOuwambqojRUDvLxIcSysBXlpe,iEdJQOuwambqojRUDvLxIcSysBXlpr
 def Get_Program_List(iEdJQOuwambqojRUDvLxIcSysBXlrp,iEdJQOuwambqojRUDvLxIcSysBXlAV,page_int=1,orderby='-'):
  iEdJQOuwambqojRUDvLxIcSysBXlpP=[]
  iEdJQOuwambqojRUDvLxIcSysBXlAC=iEdJQOuwambqojRUDvLxIcSysBXlpf=1
  iEdJQOuwambqojRUDvLxIcSysBXlpr=iEdJQOuwambqojRUDvLxIcSysBXlMV
  (iEdJQOuwambqojRUDvLxIcSysBXlrC,iEdJQOuwambqojRUDvLxIcSysBXlrV)=iEdJQOuwambqojRUDvLxIcSysBXlrp.Baseapi_Parse(iEdJQOuwambqojRUDvLxIcSysBXlAV)
  if iEdJQOuwambqojRUDvLxIcSysBXlrC=='':return iEdJQOuwambqojRUDvLxIcSysBXlpP,iEdJQOuwambqojRUDvLxIcSysBXlpr
  try:
   iEdJQOuwambqojRUDvLxIcSysBXlrV['limit'] =iEdJQOuwambqojRUDvLxIcSysBXlrp.LIST_LIMIT
   iEdJQOuwambqojRUDvLxIcSysBXlrV['offset']=iEdJQOuwambqojRUDvLxIcSysBXlMk((page_int-1)*iEdJQOuwambqojRUDvLxIcSysBXlrp.LIST_LIMIT)
   iEdJQOuwambqojRUDvLxIcSysBXlrV['page'] =iEdJQOuwambqojRUDvLxIcSysBXlMk(page_int)
   if iEdJQOuwambqojRUDvLxIcSysBXlrV.get('orderby')!='' and iEdJQOuwambqojRUDvLxIcSysBXlrV.get('orderby')!='regdatefirst' and orderby!='-':
    iEdJQOuwambqojRUDvLxIcSysBXlrV['orderby']=orderby 
   iEdJQOuwambqojRUDvLxIcSysBXlrV.update(iEdJQOuwambqojRUDvLxIcSysBXlrp.GetDefaultParams(login=iEdJQOuwambqojRUDvLxIcSysBXlMV))
   iEdJQOuwambqojRUDvLxIcSysBXlAp=iEdJQOuwambqojRUDvLxIcSysBXlrp.callRequestCookies('Get',iEdJQOuwambqojRUDvLxIcSysBXlrC,payload=iEdJQOuwambqojRUDvLxIcSysBXlMY,params=iEdJQOuwambqojRUDvLxIcSysBXlrV,headers=iEdJQOuwambqojRUDvLxIcSysBXlMY,cookies=iEdJQOuwambqojRUDvLxIcSysBXlMY)
   iEdJQOuwambqojRUDvLxIcSysBXlAK=json.loads(iEdJQOuwambqojRUDvLxIcSysBXlAp.text)
   if iEdJQOuwambqojRUDvLxIcSysBXlAV.find('instantplay')>=0:
    if not('celllist' in iEdJQOuwambqojRUDvLxIcSysBXlAK['band']):return iEdJQOuwambqojRUDvLxIcSysBXlpP,iEdJQOuwambqojRUDvLxIcSysBXlpr
    iEdJQOuwambqojRUDvLxIcSysBXlAt=iEdJQOuwambqojRUDvLxIcSysBXlAK['band']['celllist']
   else:
    if not('celllist' in iEdJQOuwambqojRUDvLxIcSysBXlAK['cell_toplist']):return iEdJQOuwambqojRUDvLxIcSysBXlpP,iEdJQOuwambqojRUDvLxIcSysBXlpr
    iEdJQOuwambqojRUDvLxIcSysBXlAt=iEdJQOuwambqojRUDvLxIcSysBXlAK['cell_toplist']['celllist']
   for iEdJQOuwambqojRUDvLxIcSysBXlAF in iEdJQOuwambqojRUDvLxIcSysBXlAt:
    for iEdJQOuwambqojRUDvLxIcSysBXlpT in iEdJQOuwambqojRUDvLxIcSysBXlAF['event_list']:
     if iEdJQOuwambqojRUDvLxIcSysBXlpT.get('type')=='on-navigation':
      iEdJQOuwambqojRUDvLxIcSysBXlpA =iEdJQOuwambqojRUDvLxIcSysBXlpT['url']
    iEdJQOuwambqojRUDvLxIcSysBXlpK=urllib.parse.urlsplit(iEdJQOuwambqojRUDvLxIcSysBXlpA).query
    iEdJQOuwambqojRUDvLxIcSysBXlpz=iEdJQOuwambqojRUDvLxIcSysBXlpK[0:iEdJQOuwambqojRUDvLxIcSysBXlpK.find('=')]
    iEdJQOuwambqojRUDvLxIcSysBXlpM=iEdJQOuwambqojRUDvLxIcSysBXlpK[iEdJQOuwambqojRUDvLxIcSysBXlpK.find('=')+1:]
    iEdJQOuwambqojRUDvLxIcSysBXlAk={'title':iEdJQOuwambqojRUDvLxIcSysBXlAF['title_list'][0]['text'],'age':iEdJQOuwambqojRUDvLxIcSysBXlAF['age'],'thumbnail':'https://%s'%iEdJQOuwambqojRUDvLxIcSysBXlAF.get('thumbnail'),'videoid':iEdJQOuwambqojRUDvLxIcSysBXlpM,'vidtype':iEdJQOuwambqojRUDvLxIcSysBXlpz}
    iEdJQOuwambqojRUDvLxIcSysBXlpP.append(iEdJQOuwambqojRUDvLxIcSysBXlAk)
   if iEdJQOuwambqojRUDvLxIcSysBXlAV.find('instantplay')<0:
    iEdJQOuwambqojRUDvLxIcSysBXlAC=iEdJQOuwambqojRUDvLxIcSysBXlMH(iEdJQOuwambqojRUDvLxIcSysBXlAK['cell_toplist']['pagecount'])
    if iEdJQOuwambqojRUDvLxIcSysBXlAK['cell_toplist']['count']:iEdJQOuwambqojRUDvLxIcSysBXlpf =iEdJQOuwambqojRUDvLxIcSysBXlMH(iEdJQOuwambqojRUDvLxIcSysBXlAK['cell_toplist']['count'])
    else:iEdJQOuwambqojRUDvLxIcSysBXlpf=iEdJQOuwambqojRUDvLxIcSysBXlrp.LIST_LIMIT*page_int
    iEdJQOuwambqojRUDvLxIcSysBXlpr=iEdJQOuwambqojRUDvLxIcSysBXlAC>iEdJQOuwambqojRUDvLxIcSysBXlpf
  except iEdJQOuwambqojRUDvLxIcSysBXlMh as exception:
   iEdJQOuwambqojRUDvLxIcSysBXlMN(exception)
   return[],iEdJQOuwambqojRUDvLxIcSysBXlMV
  return iEdJQOuwambqojRUDvLxIcSysBXlpP,iEdJQOuwambqojRUDvLxIcSysBXlpr
 def Get_Movie_List(iEdJQOuwambqojRUDvLxIcSysBXlrp,iEdJQOuwambqojRUDvLxIcSysBXlAV,page_int=1,orderby='-'):
  iEdJQOuwambqojRUDvLxIcSysBXlpY=[]
  iEdJQOuwambqojRUDvLxIcSysBXlAC=iEdJQOuwambqojRUDvLxIcSysBXlpf=1
  iEdJQOuwambqojRUDvLxIcSysBXlpr=iEdJQOuwambqojRUDvLxIcSysBXlMV
  (iEdJQOuwambqojRUDvLxIcSysBXlrC,iEdJQOuwambqojRUDvLxIcSysBXlrV)=iEdJQOuwambqojRUDvLxIcSysBXlrp.Baseapi_Parse(iEdJQOuwambqojRUDvLxIcSysBXlAV)
  if iEdJQOuwambqojRUDvLxIcSysBXlrC=='':return iEdJQOuwambqojRUDvLxIcSysBXlpY,iEdJQOuwambqojRUDvLxIcSysBXlpr
  try:
   iEdJQOuwambqojRUDvLxIcSysBXlrV['limit']=iEdJQOuwambqojRUDvLxIcSysBXlrp.MV_LIMIT
   iEdJQOuwambqojRUDvLxIcSysBXlrV['offset']=iEdJQOuwambqojRUDvLxIcSysBXlMk((page_int-1)*iEdJQOuwambqojRUDvLxIcSysBXlrp.MV_LIMIT)
   if iEdJQOuwambqojRUDvLxIcSysBXlrV.get('orderby')!='' and iEdJQOuwambqojRUDvLxIcSysBXlrV.get('orderby')!='regdatefirst' and orderby!='-':
    iEdJQOuwambqojRUDvLxIcSysBXlrV['orderby']=orderby 
   iEdJQOuwambqojRUDvLxIcSysBXlrV.update(iEdJQOuwambqojRUDvLxIcSysBXlrp.GetDefaultParams(login=iEdJQOuwambqojRUDvLxIcSysBXlMV))
   iEdJQOuwambqojRUDvLxIcSysBXlAp=iEdJQOuwambqojRUDvLxIcSysBXlrp.callRequestCookies('Get',iEdJQOuwambqojRUDvLxIcSysBXlrC,payload=iEdJQOuwambqojRUDvLxIcSysBXlMY,params=iEdJQOuwambqojRUDvLxIcSysBXlrV,headers=iEdJQOuwambqojRUDvLxIcSysBXlMY,cookies=iEdJQOuwambqojRUDvLxIcSysBXlMY)
   iEdJQOuwambqojRUDvLxIcSysBXlAK=json.loads(iEdJQOuwambqojRUDvLxIcSysBXlAp.text)
   if not('celllist' in iEdJQOuwambqojRUDvLxIcSysBXlAK['cell_toplist']):return iEdJQOuwambqojRUDvLxIcSysBXlpY,iEdJQOuwambqojRUDvLxIcSysBXlpr
   iEdJQOuwambqojRUDvLxIcSysBXlAt=iEdJQOuwambqojRUDvLxIcSysBXlAK['cell_toplist']['celllist']
   for iEdJQOuwambqojRUDvLxIcSysBXlAF in iEdJQOuwambqojRUDvLxIcSysBXlAt:
    iEdJQOuwambqojRUDvLxIcSysBXlpA =iEdJQOuwambqojRUDvLxIcSysBXlAF['event_list'][1]['url']
    iEdJQOuwambqojRUDvLxIcSysBXlpK=urllib.parse.urlsplit(iEdJQOuwambqojRUDvLxIcSysBXlpA).query
    iEdJQOuwambqojRUDvLxIcSysBXlpz=iEdJQOuwambqojRUDvLxIcSysBXlpK[0:iEdJQOuwambqojRUDvLxIcSysBXlpK.find('=')]
    iEdJQOuwambqojRUDvLxIcSysBXlpM=iEdJQOuwambqojRUDvLxIcSysBXlpK[iEdJQOuwambqojRUDvLxIcSysBXlpK.find('=')+1:]
    iEdJQOuwambqojRUDvLxIcSysBXlAk={'title':iEdJQOuwambqojRUDvLxIcSysBXlAF['title_list'][0]['text'],'age':iEdJQOuwambqojRUDvLxIcSysBXlAF['age'],'thumbnail':'https://%s'%iEdJQOuwambqojRUDvLxIcSysBXlAF.get('thumbnail'),'videoid':iEdJQOuwambqojRUDvLxIcSysBXlpM,'vidtype':iEdJQOuwambqojRUDvLxIcSysBXlpz}
    iEdJQOuwambqojRUDvLxIcSysBXlpY.append(iEdJQOuwambqojRUDvLxIcSysBXlAk)
   iEdJQOuwambqojRUDvLxIcSysBXlAC=iEdJQOuwambqojRUDvLxIcSysBXlMH(iEdJQOuwambqojRUDvLxIcSysBXlAK['cell_toplist']['pagecount'])
   if iEdJQOuwambqojRUDvLxIcSysBXlAK['cell_toplist']['count']:iEdJQOuwambqojRUDvLxIcSysBXlpf =iEdJQOuwambqojRUDvLxIcSysBXlMH(iEdJQOuwambqojRUDvLxIcSysBXlAK['cell_toplist']['count'])
   else:iEdJQOuwambqojRUDvLxIcSysBXlpf=iEdJQOuwambqojRUDvLxIcSysBXlrp.MV_LIMIT*page_int
   iEdJQOuwambqojRUDvLxIcSysBXlpr=iEdJQOuwambqojRUDvLxIcSysBXlAC>iEdJQOuwambqojRUDvLxIcSysBXlpf
  except iEdJQOuwambqojRUDvLxIcSysBXlMh as exception:
   iEdJQOuwambqojRUDvLxIcSysBXlMN(exception)
   return[],iEdJQOuwambqojRUDvLxIcSysBXlMV
  return iEdJQOuwambqojRUDvLxIcSysBXlpY,iEdJQOuwambqojRUDvLxIcSysBXlpr
 def ProgramidToContentid(iEdJQOuwambqojRUDvLxIcSysBXlrp,iEdJQOuwambqojRUDvLxIcSysBXlpt):
  iEdJQOuwambqojRUDvLxIcSysBXlpV=''
  try:
   iEdJQOuwambqojRUDvLxIcSysBXlrC =iEdJQOuwambqojRUDvLxIcSysBXlrp.API_DOMAIN+'/vod/programs-contentid/'+iEdJQOuwambqojRUDvLxIcSysBXlpt
   iEdJQOuwambqojRUDvLxIcSysBXlrV=iEdJQOuwambqojRUDvLxIcSysBXlrp.GetDefaultParams(login=iEdJQOuwambqojRUDvLxIcSysBXlMV)
   iEdJQOuwambqojRUDvLxIcSysBXlAp=iEdJQOuwambqojRUDvLxIcSysBXlrp.callRequestCookies('Get',iEdJQOuwambqojRUDvLxIcSysBXlrC,payload=iEdJQOuwambqojRUDvLxIcSysBXlMY,params=iEdJQOuwambqojRUDvLxIcSysBXlrV,headers=iEdJQOuwambqojRUDvLxIcSysBXlMY,cookies=iEdJQOuwambqojRUDvLxIcSysBXlMY)
   iEdJQOuwambqojRUDvLxIcSysBXlpg=json.loads(iEdJQOuwambqojRUDvLxIcSysBXlAp.text)
   if not('contentid' in iEdJQOuwambqojRUDvLxIcSysBXlpg):return iEdJQOuwambqojRUDvLxIcSysBXlpV 
   iEdJQOuwambqojRUDvLxIcSysBXlpV=iEdJQOuwambqojRUDvLxIcSysBXlpg['contentid']
  except iEdJQOuwambqojRUDvLxIcSysBXlMh as exception:
   iEdJQOuwambqojRUDvLxIcSysBXlMN(exception)
  return iEdJQOuwambqojRUDvLxIcSysBXlpV
 def ContentidToSeasonid(iEdJQOuwambqojRUDvLxIcSysBXlrp,iEdJQOuwambqojRUDvLxIcSysBXlpV):
  iEdJQOuwambqojRUDvLxIcSysBXlpt=''
  try:
   iEdJQOuwambqojRUDvLxIcSysBXlrC =iEdJQOuwambqojRUDvLxIcSysBXlrp.API_DOMAIN+'/fz/vod/contents/'+iEdJQOuwambqojRUDvLxIcSysBXlpV
   iEdJQOuwambqojRUDvLxIcSysBXlrV=iEdJQOuwambqojRUDvLxIcSysBXlrp.GetDefaultParams(login=iEdJQOuwambqojRUDvLxIcSysBXlMV)
   iEdJQOuwambqojRUDvLxIcSysBXlAp=iEdJQOuwambqojRUDvLxIcSysBXlrp.callRequestCookies('Get',iEdJQOuwambqojRUDvLxIcSysBXlrC,payload=iEdJQOuwambqojRUDvLxIcSysBXlMY,params=iEdJQOuwambqojRUDvLxIcSysBXlrV,headers=iEdJQOuwambqojRUDvLxIcSysBXlMY,cookies=iEdJQOuwambqojRUDvLxIcSysBXlMY)
   iEdJQOuwambqojRUDvLxIcSysBXlpg=json.loads(iEdJQOuwambqojRUDvLxIcSysBXlAp.text)
   if not('programid' in iEdJQOuwambqojRUDvLxIcSysBXlpg):return iEdJQOuwambqojRUDvLxIcSysBXlpt 
   iEdJQOuwambqojRUDvLxIcSysBXlpt=iEdJQOuwambqojRUDvLxIcSysBXlpg['programid']
  except iEdJQOuwambqojRUDvLxIcSysBXlMh as exception:
   iEdJQOuwambqojRUDvLxIcSysBXlMN(exception)
  return iEdJQOuwambqojRUDvLxIcSysBXlpt
 def GetProgramInfo(iEdJQOuwambqojRUDvLxIcSysBXlrp,iEdJQOuwambqojRUDvLxIcSysBXlpV):
  iEdJQOuwambqojRUDvLxIcSysBXlpF={}
  try:
   iEdJQOuwambqojRUDvLxIcSysBXlrC=iEdJQOuwambqojRUDvLxIcSysBXlrp.API_DOMAIN+'/fz/vod/contents/'+iEdJQOuwambqojRUDvLxIcSysBXlpV
   iEdJQOuwambqojRUDvLxIcSysBXlrV=iEdJQOuwambqojRUDvLxIcSysBXlrp.GetDefaultParams(login=iEdJQOuwambqojRUDvLxIcSysBXlMV)
   iEdJQOuwambqojRUDvLxIcSysBXlAp=iEdJQOuwambqojRUDvLxIcSysBXlrp.callRequestCookies('Get',iEdJQOuwambqojRUDvLxIcSysBXlrC,payload=iEdJQOuwambqojRUDvLxIcSysBXlMY,params=iEdJQOuwambqojRUDvLxIcSysBXlrV,headers=iEdJQOuwambqojRUDvLxIcSysBXlMY,cookies=iEdJQOuwambqojRUDvLxIcSysBXlMY)
   iEdJQOuwambqojRUDvLxIcSysBXlpg=json.loads(iEdJQOuwambqojRUDvLxIcSysBXlAp.text)
   iEdJQOuwambqojRUDvLxIcSysBXlpk=img_fanart=iEdJQOuwambqojRUDvLxIcSysBXlph=''
   if iEdJQOuwambqojRUDvLxIcSysBXlpg.get('programposterimage')!='':iEdJQOuwambqojRUDvLxIcSysBXlpk =iEdJQOuwambqojRUDvLxIcSysBXlrp.HTTPTAG+iEdJQOuwambqojRUDvLxIcSysBXlpg.get('programposterimage')
   if iEdJQOuwambqojRUDvLxIcSysBXlpg.get('programimage') !='':img_fanart =iEdJQOuwambqojRUDvLxIcSysBXlrp.HTTPTAG+iEdJQOuwambqojRUDvLxIcSysBXlpg.get('programimage')
   if iEdJQOuwambqojRUDvLxIcSysBXlpg.get('programcircleimage')!='':iEdJQOuwambqojRUDvLxIcSysBXlph=iEdJQOuwambqojRUDvLxIcSysBXlrp.HTTPTAG+iEdJQOuwambqojRUDvLxIcSysBXlpg.get('programcircleimage')
   if 'poster_default' in iEdJQOuwambqojRUDvLxIcSysBXlpk:
    iEdJQOuwambqojRUDvLxIcSysBXlpk =img_fanart
    iEdJQOuwambqojRUDvLxIcSysBXlph=''
   iEdJQOuwambqojRUDvLxIcSysBXlpF={'imgPoster':iEdJQOuwambqojRUDvLxIcSysBXlpk,'imgFanart':img_fanart,'imgClearlogo':iEdJQOuwambqojRUDvLxIcSysBXlph,'programtitle':iEdJQOuwambqojRUDvLxIcSysBXlpg.get('programtitle'),'programid':iEdJQOuwambqojRUDvLxIcSysBXlpg.get('programid'),'synopsis':iEdJQOuwambqojRUDvLxIcSysBXlpg.get('programsynopsis').replace('<br>','\n'),}
  except iEdJQOuwambqojRUDvLxIcSysBXlMh as exception:
   iEdJQOuwambqojRUDvLxIcSysBXlMN(exception)
  return iEdJQOuwambqojRUDvLxIcSysBXlpF
 def Get_Season_List(iEdJQOuwambqojRUDvLxIcSysBXlrp,seasonid):
  iEdJQOuwambqojRUDvLxIcSysBXlpN=[]
  iEdJQOuwambqojRUDvLxIcSysBXlpV=iEdJQOuwambqojRUDvLxIcSysBXlrp.ProgramidToContentid(seasonid)
  iEdJQOuwambqojRUDvLxIcSysBXlpn=iEdJQOuwambqojRUDvLxIcSysBXlrp.GetProgramInfo(iEdJQOuwambqojRUDvLxIcSysBXlpV)
  iEdJQOuwambqojRUDvLxIcSysBXlpH={'poster':iEdJQOuwambqojRUDvLxIcSysBXlpn.get('imgPoster'),'fanart':iEdJQOuwambqojRUDvLxIcSysBXlpn.get('imgFanart'),'clearlogo':iEdJQOuwambqojRUDvLxIcSysBXlpn.get('imgClearlogo'),}
  try:
   iEdJQOuwambqojRUDvLxIcSysBXlrC=iEdJQOuwambqojRUDvLxIcSysBXlrp.API_DOMAIN+'/fz/vod/programs-contents/'+seasonid
   iEdJQOuwambqojRUDvLxIcSysBXlrV={'limit':'10','offset':'0','orderby':'new',}
   iEdJQOuwambqojRUDvLxIcSysBXlrV.update(iEdJQOuwambqojRUDvLxIcSysBXlrp.GetDefaultParams(login=iEdJQOuwambqojRUDvLxIcSysBXlMV))
   iEdJQOuwambqojRUDvLxIcSysBXlAp=iEdJQOuwambqojRUDvLxIcSysBXlrp.callRequestCookies('Get',iEdJQOuwambqojRUDvLxIcSysBXlrC,payload=iEdJQOuwambqojRUDvLxIcSysBXlMY,params=iEdJQOuwambqojRUDvLxIcSysBXlrV,headers=iEdJQOuwambqojRUDvLxIcSysBXlMY,cookies=iEdJQOuwambqojRUDvLxIcSysBXlMY)
   iEdJQOuwambqojRUDvLxIcSysBXlAK=json.loads(iEdJQOuwambqojRUDvLxIcSysBXlAp.text)
   for iEdJQOuwambqojRUDvLxIcSysBXlpW in iEdJQOuwambqojRUDvLxIcSysBXlAK['filter']['filterlist'][0]['filter_item_list']:
    iEdJQOuwambqojRUDvLxIcSysBXlAk={'season_Nm':iEdJQOuwambqojRUDvLxIcSysBXlpW.get('title'),'season_Id':iEdJQOuwambqojRUDvLxIcSysBXlpW.get('api_path'),'thumbnail':iEdJQOuwambqojRUDvLxIcSysBXlpH,'programNm':iEdJQOuwambqojRUDvLxIcSysBXlpn.get('programtitle'),'synopsis':iEdJQOuwambqojRUDvLxIcSysBXlpn.get('synopsis'),}
    iEdJQOuwambqojRUDvLxIcSysBXlpN.append(iEdJQOuwambqojRUDvLxIcSysBXlAk)
  except iEdJQOuwambqojRUDvLxIcSysBXlMh as exception:
   iEdJQOuwambqojRUDvLxIcSysBXlMN(exception)
   return[]
  return iEdJQOuwambqojRUDvLxIcSysBXlpN
 def Get_Episode_List(iEdJQOuwambqojRUDvLxIcSysBXlrp,seasionid,page_int=1,orderby='desc'):
  iEdJQOuwambqojRUDvLxIcSysBXlpG=[]
  iEdJQOuwambqojRUDvLxIcSysBXlAC=iEdJQOuwambqojRUDvLxIcSysBXlpf=1
  iEdJQOuwambqojRUDvLxIcSysBXlpr=iEdJQOuwambqojRUDvLxIcSysBXlMV
  iEdJQOuwambqojRUDvLxIcSysBXlpn={}
  iEdJQOuwambqojRUDvLxIcSysBXlpV=iEdJQOuwambqojRUDvLxIcSysBXlrp.ProgramidToContentid(seasionid)
  iEdJQOuwambqojRUDvLxIcSysBXlpn=iEdJQOuwambqojRUDvLxIcSysBXlrp.GetProgramInfo(iEdJQOuwambqojRUDvLxIcSysBXlpV)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   iEdJQOuwambqojRUDvLxIcSysBXlrC=iEdJQOuwambqojRUDvLxIcSysBXlrp.API_DOMAIN+'/fz/vod/programs-contents/'+seasionid
   iEdJQOuwambqojRUDvLxIcSysBXlrV={'limit':iEdJQOuwambqojRUDvLxIcSysBXlrp.EP_LIMIT,'offset':iEdJQOuwambqojRUDvLxIcSysBXlMk((page_int-1)*iEdJQOuwambqojRUDvLxIcSysBXlrp.EP_LIMIT),'orderby':orderby,}
   iEdJQOuwambqojRUDvLxIcSysBXlrV.update(iEdJQOuwambqojRUDvLxIcSysBXlrp.GetDefaultParams(login=iEdJQOuwambqojRUDvLxIcSysBXlMV))
   iEdJQOuwambqojRUDvLxIcSysBXlAp=iEdJQOuwambqojRUDvLxIcSysBXlrp.callRequestCookies('Get',iEdJQOuwambqojRUDvLxIcSysBXlrC,payload=iEdJQOuwambqojRUDvLxIcSysBXlMY,params=iEdJQOuwambqojRUDvLxIcSysBXlrV,headers=iEdJQOuwambqojRUDvLxIcSysBXlMY,cookies=iEdJQOuwambqojRUDvLxIcSysBXlMY)
   iEdJQOuwambqojRUDvLxIcSysBXlAK=json.loads(iEdJQOuwambqojRUDvLxIcSysBXlAp.text)
   iEdJQOuwambqojRUDvLxIcSysBXlAt=iEdJQOuwambqojRUDvLxIcSysBXlAK['cell_toplist']['celllist']
   for iEdJQOuwambqojRUDvLxIcSysBXlAF in iEdJQOuwambqojRUDvLxIcSysBXlAt:
    iEdJQOuwambqojRUDvLxIcSysBXlKr=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',iEdJQOuwambqojRUDvLxIcSysBXlAF.get('synopsis'))
    iEdJQOuwambqojRUDvLxIcSysBXlKA=iEdJQOuwambqojRUDvLxIcSysBXlrp.HTTPTAG+iEdJQOuwambqojRUDvLxIcSysBXlAF.get('thumbnail')
    iEdJQOuwambqojRUDvLxIcSysBXlKp=iEdJQOuwambqojRUDvLxIcSysBXlKz=iEdJQOuwambqojRUDvLxIcSysBXlKM=''
    iEdJQOuwambqojRUDvLxIcSysBXlKp =iEdJQOuwambqojRUDvLxIcSysBXlpn.get('imgPoster')
    iEdJQOuwambqojRUDvLxIcSysBXlKz =iEdJQOuwambqojRUDvLxIcSysBXlpn.get('imgFanart')
    iEdJQOuwambqojRUDvLxIcSysBXlKM =iEdJQOuwambqojRUDvLxIcSysBXlpn.get('imgClearlogo')
    iEdJQOuwambqojRUDvLxIcSysBXlKf=iEdJQOuwambqojRUDvLxIcSysBXlpn.get('programtitle')
    iEdJQOuwambqojRUDvLxIcSysBXlpH={'thumb':iEdJQOuwambqojRUDvLxIcSysBXlKA,'poster':iEdJQOuwambqojRUDvLxIcSysBXlKp,'fanart':iEdJQOuwambqojRUDvLxIcSysBXlKz,'clearlogo':iEdJQOuwambqojRUDvLxIcSysBXlKM}
    iEdJQOuwambqojRUDvLxIcSysBXlAk={'programtitle':iEdJQOuwambqojRUDvLxIcSysBXlKf,'episodetitle':iEdJQOuwambqojRUDvLxIcSysBXlAF['title_list'][0]['text'],'episodenumber':iEdJQOuwambqojRUDvLxIcSysBXlAF['title_list'][1]['text'].replace('$O$',''),'contentid':iEdJQOuwambqojRUDvLxIcSysBXlAF['contentid'],'synopsis':iEdJQOuwambqojRUDvLxIcSysBXlKr,'episodeactors':iEdJQOuwambqojRUDvLxIcSysBXlAF.get('actors').split(',')if iEdJQOuwambqojRUDvLxIcSysBXlAF.get('actors')!='' else[],'thumbnail':iEdJQOuwambqojRUDvLxIcSysBXlpH,}
    iEdJQOuwambqojRUDvLxIcSysBXlpG.append(iEdJQOuwambqojRUDvLxIcSysBXlAk)
   iEdJQOuwambqojRUDvLxIcSysBXlAC=iEdJQOuwambqojRUDvLxIcSysBXlMH(iEdJQOuwambqojRUDvLxIcSysBXlAK['cell_toplist']['pagecount'])
   if iEdJQOuwambqojRUDvLxIcSysBXlAK['cell_toplist']['count']:iEdJQOuwambqojRUDvLxIcSysBXlpf =iEdJQOuwambqojRUDvLxIcSysBXlMH(iEdJQOuwambqojRUDvLxIcSysBXlAK['cell_toplist']['count'])
   else:iEdJQOuwambqojRUDvLxIcSysBXlpf=iEdJQOuwambqojRUDvLxIcSysBXlrp.EP_LIMIT*page_int
   iEdJQOuwambqojRUDvLxIcSysBXlpr=iEdJQOuwambqojRUDvLxIcSysBXlAC>iEdJQOuwambqojRUDvLxIcSysBXlpf
  except iEdJQOuwambqojRUDvLxIcSysBXlMh as exception:
   iEdJQOuwambqojRUDvLxIcSysBXlMN(exception)
   return[],iEdJQOuwambqojRUDvLxIcSysBXlMV
  return iEdJQOuwambqojRUDvLxIcSysBXlpG,iEdJQOuwambqojRUDvLxIcSysBXlpr
 def GetEPGList(iEdJQOuwambqojRUDvLxIcSysBXlrp,genre):
  iEdJQOuwambqojRUDvLxIcSysBXlKe={}
  try:
   iEdJQOuwambqojRUDvLxIcSysBXlKP=iEdJQOuwambqojRUDvLxIcSysBXlrp.Get_Now_Datetime()
   if genre=='all':
    iEdJQOuwambqojRUDvLxIcSysBXlKT =iEdJQOuwambqojRUDvLxIcSysBXlKP+datetime.timedelta(hours=3)
   else:
    iEdJQOuwambqojRUDvLxIcSysBXlKT =iEdJQOuwambqojRUDvLxIcSysBXlKP+datetime.timedelta(hours=3)
   iEdJQOuwambqojRUDvLxIcSysBXlrC=iEdJQOuwambqojRUDvLxIcSysBXlrp.API_DOMAIN+'/live/epgs'
   iEdJQOuwambqojRUDvLxIcSysBXlrV={'limit':'100','offset':'0','genre':genre,'startdatetime':iEdJQOuwambqojRUDvLxIcSysBXlKP.strftime('%Y-%m-%d %H:00'),'enddatetime':iEdJQOuwambqojRUDvLxIcSysBXlKT.strftime('%Y-%m-%d %H:00')}
   iEdJQOuwambqojRUDvLxIcSysBXlrV.update(iEdJQOuwambqojRUDvLxIcSysBXlrp.GetDefaultParams(login=iEdJQOuwambqojRUDvLxIcSysBXlMV))
   iEdJQOuwambqojRUDvLxIcSysBXlAp=iEdJQOuwambqojRUDvLxIcSysBXlrp.callRequestCookies('Get',iEdJQOuwambqojRUDvLxIcSysBXlrC,payload=iEdJQOuwambqojRUDvLxIcSysBXlMY,params=iEdJQOuwambqojRUDvLxIcSysBXlrV,headers=iEdJQOuwambqojRUDvLxIcSysBXlMY,cookies=iEdJQOuwambqojRUDvLxIcSysBXlMY)
   iEdJQOuwambqojRUDvLxIcSysBXlAK=json.loads(iEdJQOuwambqojRUDvLxIcSysBXlAp.text)
   iEdJQOuwambqojRUDvLxIcSysBXlKY=iEdJQOuwambqojRUDvLxIcSysBXlAK['list']
   for iEdJQOuwambqojRUDvLxIcSysBXlAF in iEdJQOuwambqojRUDvLxIcSysBXlKY:
    iEdJQOuwambqojRUDvLxIcSysBXlKV=''
    for iEdJQOuwambqojRUDvLxIcSysBXlKg in iEdJQOuwambqojRUDvLxIcSysBXlAF['list']:
     if iEdJQOuwambqojRUDvLxIcSysBXlKV:iEdJQOuwambqojRUDvLxIcSysBXlKV+='\n'
     iEdJQOuwambqojRUDvLxIcSysBXlKV+=iEdJQOuwambqojRUDvLxIcSysBXlrp.Get_ChangeText(iEdJQOuwambqojRUDvLxIcSysBXlKg['title'])+'\n'
     iEdJQOuwambqojRUDvLxIcSysBXlKV+=' [%s ~ %s]'%(iEdJQOuwambqojRUDvLxIcSysBXlKg['starttime'][-5:],iEdJQOuwambqojRUDvLxIcSysBXlKg['endtime'][-5:])+'\n'
    iEdJQOuwambqojRUDvLxIcSysBXlKe[iEdJQOuwambqojRUDvLxIcSysBXlAF['channelid']]=iEdJQOuwambqojRUDvLxIcSysBXlKV
  except iEdJQOuwambqojRUDvLxIcSysBXlMh as exception:
   iEdJQOuwambqojRUDvLxIcSysBXlMN(exception)
  return iEdJQOuwambqojRUDvLxIcSysBXlKe
 def Get_LiveChannel_List(iEdJQOuwambqojRUDvLxIcSysBXlrp,genre,iEdJQOuwambqojRUDvLxIcSysBXlAV):
  iEdJQOuwambqojRUDvLxIcSysBXlAG=[]
  (iEdJQOuwambqojRUDvLxIcSysBXlrC,iEdJQOuwambqojRUDvLxIcSysBXlrV)=iEdJQOuwambqojRUDvLxIcSysBXlrp.Baseapi_Parse(iEdJQOuwambqojRUDvLxIcSysBXlAV)
  if iEdJQOuwambqojRUDvLxIcSysBXlrC=='':return iEdJQOuwambqojRUDvLxIcSysBXlAG
  iEdJQOuwambqojRUDvLxIcSysBXlKt=iEdJQOuwambqojRUDvLxIcSysBXlrp.GetEPGList(genre)
  try:
   iEdJQOuwambqojRUDvLxIcSysBXlrV.update(iEdJQOuwambqojRUDvLxIcSysBXlrp.GetDefaultParams(login=iEdJQOuwambqojRUDvLxIcSysBXlMV))
   iEdJQOuwambqojRUDvLxIcSysBXlrV['genre']=genre
   iEdJQOuwambqojRUDvLxIcSysBXlAp=iEdJQOuwambqojRUDvLxIcSysBXlrp.callRequestCookies('Get',iEdJQOuwambqojRUDvLxIcSysBXlrC,payload=iEdJQOuwambqojRUDvLxIcSysBXlMY,params=iEdJQOuwambqojRUDvLxIcSysBXlrV,headers=iEdJQOuwambqojRUDvLxIcSysBXlMY,cookies=iEdJQOuwambqojRUDvLxIcSysBXlMY)
   iEdJQOuwambqojRUDvLxIcSysBXlAK=json.loads(iEdJQOuwambqojRUDvLxIcSysBXlAp.text)
   if not('celllist' in iEdJQOuwambqojRUDvLxIcSysBXlAK['cell_toplist']):return[]
   iEdJQOuwambqojRUDvLxIcSysBXlAt=iEdJQOuwambqojRUDvLxIcSysBXlAK['cell_toplist']['celllist']
   for iEdJQOuwambqojRUDvLxIcSysBXlAF in iEdJQOuwambqojRUDvLxIcSysBXlAt:
    iEdJQOuwambqojRUDvLxIcSysBXlpV=iEdJQOuwambqojRUDvLxIcSysBXlAF['contentid']
    if iEdJQOuwambqojRUDvLxIcSysBXlpV in iEdJQOuwambqojRUDvLxIcSysBXlKt:
     iEdJQOuwambqojRUDvLxIcSysBXlKF=iEdJQOuwambqojRUDvLxIcSysBXlKt[iEdJQOuwambqojRUDvLxIcSysBXlpV]
    else:
     iEdJQOuwambqojRUDvLxIcSysBXlKF=''
    iEdJQOuwambqojRUDvLxIcSysBXlAk={'studio':iEdJQOuwambqojRUDvLxIcSysBXlAF['title_list'][0]['text'],'tvshowtitle':iEdJQOuwambqojRUDvLxIcSysBXlrp.Get_ChangeText(iEdJQOuwambqojRUDvLxIcSysBXlAF['title_list'][1]['text']),'channelid':iEdJQOuwambqojRUDvLxIcSysBXlpV,'age':iEdJQOuwambqojRUDvLxIcSysBXlAF['age'],'thumbnail':'https://%s'%iEdJQOuwambqojRUDvLxIcSysBXlAF.get('thumbnail'),'epg':iEdJQOuwambqojRUDvLxIcSysBXlKF}
    iEdJQOuwambqojRUDvLxIcSysBXlAG.append(iEdJQOuwambqojRUDvLxIcSysBXlAk)
  except iEdJQOuwambqojRUDvLxIcSysBXlMh as exception:
   iEdJQOuwambqojRUDvLxIcSysBXlMN(exception)
   return[]
  return iEdJQOuwambqojRUDvLxIcSysBXlAG
 def Get_Search_List(iEdJQOuwambqojRUDvLxIcSysBXlrp,search_key,sType,page_int,exclusion21=iEdJQOuwambqojRUDvLxIcSysBXlMV):
  iEdJQOuwambqojRUDvLxIcSysBXlKk=[]
  iEdJQOuwambqojRUDvLxIcSysBXlAC=iEdJQOuwambqojRUDvLxIcSysBXlpf=1
  iEdJQOuwambqojRUDvLxIcSysBXlpr=iEdJQOuwambqojRUDvLxIcSysBXlMV
  try:
   iEdJQOuwambqojRUDvLxIcSysBXlrC=iEdJQOuwambqojRUDvLxIcSysBXlrp.API_DOMAIN+'/fz/search/band.js'
   iEdJQOuwambqojRUDvLxIcSysBXlrV={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':iEdJQOuwambqojRUDvLxIcSysBXlMk((page_int-1)*iEdJQOuwambqojRUDvLxIcSysBXlrp.SEARCH_LIMIT),'limit':iEdJQOuwambqojRUDvLxIcSysBXlrp.SEARCH_LIMIT,'orderby':'score','mtype':'svod',}
   iEdJQOuwambqojRUDvLxIcSysBXlrV.update(iEdJQOuwambqojRUDvLxIcSysBXlrp.GetDefaultParams(login=iEdJQOuwambqojRUDvLxIcSysBXlMV))
   iEdJQOuwambqojRUDvLxIcSysBXlAp=iEdJQOuwambqojRUDvLxIcSysBXlrp.callRequestCookies('Get',iEdJQOuwambqojRUDvLxIcSysBXlrC,payload=iEdJQOuwambqojRUDvLxIcSysBXlMY,params=iEdJQOuwambqojRUDvLxIcSysBXlrV,headers=iEdJQOuwambqojRUDvLxIcSysBXlMY,cookies=iEdJQOuwambqojRUDvLxIcSysBXlMY)
   iEdJQOuwambqojRUDvLxIcSysBXlpg=json.loads(iEdJQOuwambqojRUDvLxIcSysBXlAp.text)
   if not('celllist' in iEdJQOuwambqojRUDvLxIcSysBXlpg['band']):return iEdJQOuwambqojRUDvLxIcSysBXlKk,iEdJQOuwambqojRUDvLxIcSysBXlpr
   iEdJQOuwambqojRUDvLxIcSysBXlAt=iEdJQOuwambqojRUDvLxIcSysBXlpg['band']['celllist']
   for iEdJQOuwambqojRUDvLxIcSysBXlAF in iEdJQOuwambqojRUDvLxIcSysBXlAt:
    iEdJQOuwambqojRUDvLxIcSysBXlpA =iEdJQOuwambqojRUDvLxIcSysBXlAF['event_list'][1]['url']
    iEdJQOuwambqojRUDvLxIcSysBXlpK=urllib.parse.urlsplit(iEdJQOuwambqojRUDvLxIcSysBXlpA).query
    iEdJQOuwambqojRUDvLxIcSysBXlpz=iEdJQOuwambqojRUDvLxIcSysBXlpK[0:iEdJQOuwambqojRUDvLxIcSysBXlpK.find('=')]
    iEdJQOuwambqojRUDvLxIcSysBXlpM=iEdJQOuwambqojRUDvLxIcSysBXlpK[iEdJQOuwambqojRUDvLxIcSysBXlpK.find('=')+1:]
    iEdJQOuwambqojRUDvLxIcSysBXlAk={'title':iEdJQOuwambqojRUDvLxIcSysBXlAF['title_list'][0]['text'],'age':iEdJQOuwambqojRUDvLxIcSysBXlAF['age'],'thumbnail':'https://%s'%iEdJQOuwambqojRUDvLxIcSysBXlAF.get('thumbnail'),'videoid':iEdJQOuwambqojRUDvLxIcSysBXlpM,'vidtype':iEdJQOuwambqojRUDvLxIcSysBXlpz,}
    iEdJQOuwambqojRUDvLxIcSysBXlKh=iEdJQOuwambqojRUDvLxIcSysBXlMV
    for iEdJQOuwambqojRUDvLxIcSysBXlKN in iEdJQOuwambqojRUDvLxIcSysBXlAF['bottom_taglist']:
     if iEdJQOuwambqojRUDvLxIcSysBXlKN=='won':
      iEdJQOuwambqojRUDvLxIcSysBXlKh=iEdJQOuwambqojRUDvLxIcSysBXlMt
      break
    if iEdJQOuwambqojRUDvLxIcSysBXlKh==iEdJQOuwambqojRUDvLxIcSysBXlMt: 
     iEdJQOuwambqojRUDvLxIcSysBXlAk['title']=iEdJQOuwambqojRUDvLxIcSysBXlAk['title']+' [개별구매]'
    if exclusion21==iEdJQOuwambqojRUDvLxIcSysBXlMV or iEdJQOuwambqojRUDvLxIcSysBXlAF.get('age')!='21':
     iEdJQOuwambqojRUDvLxIcSysBXlKk.append(iEdJQOuwambqojRUDvLxIcSysBXlAk)
   iEdJQOuwambqojRUDvLxIcSysBXlAC=iEdJQOuwambqojRUDvLxIcSysBXlMH(iEdJQOuwambqojRUDvLxIcSysBXlpg['band']['pagecount'])
   if iEdJQOuwambqojRUDvLxIcSysBXlpg['band']['count']:iEdJQOuwambqojRUDvLxIcSysBXlpf =iEdJQOuwambqojRUDvLxIcSysBXlMH(iEdJQOuwambqojRUDvLxIcSysBXlpg['band']['count'])
   else:iEdJQOuwambqojRUDvLxIcSysBXlpf=iEdJQOuwambqojRUDvLxIcSysBXlrp.LIST_LIMIT
   iEdJQOuwambqojRUDvLxIcSysBXlpr=iEdJQOuwambqojRUDvLxIcSysBXlAC>iEdJQOuwambqojRUDvLxIcSysBXlpf
  except iEdJQOuwambqojRUDvLxIcSysBXlMh as exception:
   iEdJQOuwambqojRUDvLxIcSysBXlMN(exception)
  return iEdJQOuwambqojRUDvLxIcSysBXlKk,iEdJQOuwambqojRUDvLxIcSysBXlpr 
 def GetStreamingURL(iEdJQOuwambqojRUDvLxIcSysBXlrp,mode,iEdJQOuwambqojRUDvLxIcSysBXlpV,quality_int,pvrmode='-',playOption={}):
  iEdJQOuwambqojRUDvLxIcSysBXlKn ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'',}
  iEdJQOuwambqojRUDvLxIcSysBXlKH=[]
  iEdJQOuwambqojRUDvLxIcSysBXlKW='hls'
  if mode=='LIVE':
   iEdJQOuwambqojRUDvLxIcSysBXlrC =iEdJQOuwambqojRUDvLxIcSysBXlrp.API_DOMAIN+'/live/channels/'+iEdJQOuwambqojRUDvLxIcSysBXlpV
   iEdJQOuwambqojRUDvLxIcSysBXlKG='live'
  elif mode=='VOD':
   iEdJQOuwambqojRUDvLxIcSysBXlrC =iEdJQOuwambqojRUDvLxIcSysBXlrp.API_DOMAIN+'/fz/vod/contents/'+iEdJQOuwambqojRUDvLxIcSysBXlpV
   iEdJQOuwambqojRUDvLxIcSysBXlKG='vod'
  elif mode=='MOVIE':
   iEdJQOuwambqojRUDvLxIcSysBXlrC =iEdJQOuwambqojRUDvLxIcSysBXlrp.API_DOMAIN+'/fz/movie/contents/'+iEdJQOuwambqojRUDvLxIcSysBXlpV
   iEdJQOuwambqojRUDvLxIcSysBXlKG='movie'
  iEdJQOuwambqojRUDvLxIcSysBXlKC={'hdr':'sdr',}
  try:
   if mode!='LIVE' or pvrmode=='-':
    iEdJQOuwambqojRUDvLxIcSysBXlrV=iEdJQOuwambqojRUDvLxIcSysBXlrp.GetDefaultParams(login=iEdJQOuwambqojRUDvLxIcSysBXlMV)
    iEdJQOuwambqojRUDvLxIcSysBXlAp=iEdJQOuwambqojRUDvLxIcSysBXlrp.callRequestCookies('Get',iEdJQOuwambqojRUDvLxIcSysBXlrC,payload=iEdJQOuwambqojRUDvLxIcSysBXlMY,params=iEdJQOuwambqojRUDvLxIcSysBXlrV,headers=iEdJQOuwambqojRUDvLxIcSysBXlMY,cookies=iEdJQOuwambqojRUDvLxIcSysBXlMY)
    iEdJQOuwambqojRUDvLxIcSysBXlAK=json.loads(iEdJQOuwambqojRUDvLxIcSysBXlAp.text)
    iEdJQOuwambqojRUDvLxIcSysBXlzr=iEdJQOuwambqojRUDvLxIcSysBXlAK['qualities']['list']
    if iEdJQOuwambqojRUDvLxIcSysBXlzr==iEdJQOuwambqojRUDvLxIcSysBXlMY:return iEdJQOuwambqojRUDvLxIcSysBXlKn
    for iEdJQOuwambqojRUDvLxIcSysBXlzA in iEdJQOuwambqojRUDvLxIcSysBXlzr:
     iEdJQOuwambqojRUDvLxIcSysBXlKH.append(iEdJQOuwambqojRUDvLxIcSysBXlMH(iEdJQOuwambqojRUDvLxIcSysBXlzA.get('id').rstrip('p')))
    if 'type' in iEdJQOuwambqojRUDvLxIcSysBXlAK:
     if iEdJQOuwambqojRUDvLxIcSysBXlAK['type']=='onair':
      iEdJQOuwambqojRUDvLxIcSysBXlKG='onairvod'
    if 'drms' in iEdJQOuwambqojRUDvLxIcSysBXlAK:
     if iEdJQOuwambqojRUDvLxIcSysBXlAK['drms']:
      iEdJQOuwambqojRUDvLxIcSysBXlKW='dash'
    if playOption.get('enable_hdr'):
     for iEdJQOuwambqojRUDvLxIcSysBXlzp in iEdJQOuwambqojRUDvLxIcSysBXlAK.get('qualities').get('mediatypes'):
      if iEdJQOuwambqojRUDvLxIcSysBXlzp=='HDR10':
       iEdJQOuwambqojRUDvLxIcSysBXlKC['hdr']='hdr'
       break
  except iEdJQOuwambqojRUDvLxIcSysBXlMh as exception:
   iEdJQOuwambqojRUDvLxIcSysBXlMN(exception)
   return iEdJQOuwambqojRUDvLxIcSysBXlKn
  try:
   iEdJQOuwambqojRUDvLxIcSysBXlzK=iEdJQOuwambqojRUDvLxIcSysBXlrp.CheckQuality(quality_int,iEdJQOuwambqojRUDvLxIcSysBXlKH)
   if mode=='LIVE' and pvrmode!='-':
    iEdJQOuwambqojRUDvLxIcSysBXlzM='auto'
   else:
    iEdJQOuwambqojRUDvLxIcSysBXlzM=iEdJQOuwambqojRUDvLxIcSysBXlMk(iEdJQOuwambqojRUDvLxIcSysBXlzK)+'p'
   iEdJQOuwambqojRUDvLxIcSysBXlrC=iEdJQOuwambqojRUDvLxIcSysBXlrp.API_DOMAIN+'/fz/streaming'
   if iEdJQOuwambqojRUDvLxIcSysBXlKC['hdr']=='hdr':
    iEdJQOuwambqojRUDvLxIcSysBXlrV={'contentid':iEdJQOuwambqojRUDvLxIcSysBXlpV,'contenttype':iEdJQOuwambqojRUDvLxIcSysBXlKG,'quality':iEdJQOuwambqojRUDvLxIcSysBXlzM,'modelid':'SHIELD Android TV','guid':iEdJQOuwambqojRUDvLxIcSysBXlrp.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n','action':iEdJQOuwambqojRUDvLxIcSysBXlKW,'protocol':iEdJQOuwambqojRUDvLxIcSysBXlKW,'hdr':'HDR10','videocodec':'AVC','audiocodec':'AAC','issurround':'y','format':'normal','withinsubtitle':'n',}
    iEdJQOuwambqojRUDvLxIcSysBXlrV.update(iEdJQOuwambqojRUDvLxIcSysBXlrp.GetDefaultParams_AND())
   else:
    iEdJQOuwambqojRUDvLxIcSysBXlrV={'contentid':iEdJQOuwambqojRUDvLxIcSysBXlpV,'contenttype':iEdJQOuwambqojRUDvLxIcSysBXlKG,'quality':iEdJQOuwambqojRUDvLxIcSysBXlzM,'deviceModelId':'Windows 10','guid':iEdJQOuwambqojRUDvLxIcSysBXlrp.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n','action':iEdJQOuwambqojRUDvLxIcSysBXlKW,'protocol':iEdJQOuwambqojRUDvLxIcSysBXlKW,'hdr':'sdr','videocodec':'avc','audiocodec':'aac','issurround':'n','format':'normal','withinsubtitle':'n',}
    iEdJQOuwambqojRUDvLxIcSysBXlrV.update(iEdJQOuwambqojRUDvLxIcSysBXlrp.GetDefaultParams(login=iEdJQOuwambqojRUDvLxIcSysBXlMt))
   iEdJQOuwambqojRUDvLxIcSysBXlAp=iEdJQOuwambqojRUDvLxIcSysBXlrp.callRequestCookies('Get',iEdJQOuwambqojRUDvLxIcSysBXlrC,payload=iEdJQOuwambqojRUDvLxIcSysBXlMY,params=iEdJQOuwambqojRUDvLxIcSysBXlrV,headers=iEdJQOuwambqojRUDvLxIcSysBXlMY,cookies=iEdJQOuwambqojRUDvLxIcSysBXlMY)
   iEdJQOuwambqojRUDvLxIcSysBXlAK=json.loads(iEdJQOuwambqojRUDvLxIcSysBXlAp.text)
   iEdJQOuwambqojRUDvLxIcSysBXlKn['stream_url']=iEdJQOuwambqojRUDvLxIcSysBXlAK['playurl']
   if iEdJQOuwambqojRUDvLxIcSysBXlKn['stream_url']==iEdJQOuwambqojRUDvLxIcSysBXlMY:return iEdJQOuwambqojRUDvLxIcSysBXlKn
   iEdJQOuwambqojRUDvLxIcSysBXlKn['stream_cookie']=iEdJQOuwambqojRUDvLxIcSysBXlAK['awscookie']
   iEdJQOuwambqojRUDvLxIcSysBXlKn['stream_drm'] =iEdJQOuwambqojRUDvLxIcSysBXlAK['drm']
   if 'previewmsg' in iEdJQOuwambqojRUDvLxIcSysBXlAK['preview']:iEdJQOuwambqojRUDvLxIcSysBXlKn['stream_preview']=iEdJQOuwambqojRUDvLxIcSysBXlAK['preview']['previewmsg']
   if 'subtitles' in iEdJQOuwambqojRUDvLxIcSysBXlAK:
    for iEdJQOuwambqojRUDvLxIcSysBXlzf in iEdJQOuwambqojRUDvLxIcSysBXlAK['subtitles']:
     if iEdJQOuwambqojRUDvLxIcSysBXlzf.get('languagecode')=='ko':
      iEdJQOuwambqojRUDvLxIcSysBXlKn['stream_vtt']=iEdJQOuwambqojRUDvLxIcSysBXlzf.get('url')
      break
  except iEdJQOuwambqojRUDvLxIcSysBXlMh as exception:
   iEdJQOuwambqojRUDvLxIcSysBXlMN(exception)
  return iEdJQOuwambqojRUDvLxIcSysBXlKn 
 def GetSportsURL(iEdJQOuwambqojRUDvLxIcSysBXlrp,iEdJQOuwambqojRUDvLxIcSysBXlpV,quality_int):
  iEdJQOuwambqojRUDvLxIcSysBXlKn ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'',}
  iEdJQOuwambqojRUDvLxIcSysBXlKH=[]
  try:
   iEdJQOuwambqojRUDvLxIcSysBXlrC=iEdJQOuwambqojRUDvLxIcSysBXlrp.API_DOMAIN+'/streaming/other'
   iEdJQOuwambqojRUDvLxIcSysBXlrV={'contentid':iEdJQOuwambqojRUDvLxIcSysBXlpV,'contenttype':'live','action':'hls','quality':iEdJQOuwambqojRUDvLxIcSysBXlMk(quality_int)+'p','deviceModelId':'Windows 10','guid':iEdJQOuwambqojRUDvLxIcSysBXlrp.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n',}
   iEdJQOuwambqojRUDvLxIcSysBXlrV.update(iEdJQOuwambqojRUDvLxIcSysBXlrp.GetDefaultParams(login=iEdJQOuwambqojRUDvLxIcSysBXlMt))
   iEdJQOuwambqojRUDvLxIcSysBXlAp=iEdJQOuwambqojRUDvLxIcSysBXlrp.callRequestCookies('Get',iEdJQOuwambqojRUDvLxIcSysBXlrC,payload=iEdJQOuwambqojRUDvLxIcSysBXlMY,params=iEdJQOuwambqojRUDvLxIcSysBXlrV,headers=iEdJQOuwambqojRUDvLxIcSysBXlMY,cookies=iEdJQOuwambqojRUDvLxIcSysBXlMY)
   iEdJQOuwambqojRUDvLxIcSysBXlAK=json.loads(iEdJQOuwambqojRUDvLxIcSysBXlAp.text)
   iEdJQOuwambqojRUDvLxIcSysBXlKn['stream_url']=iEdJQOuwambqojRUDvLxIcSysBXlAK['playurl']
   if iEdJQOuwambqojRUDvLxIcSysBXlKn['stream_url']==iEdJQOuwambqojRUDvLxIcSysBXlMY:return iEdJQOuwambqojRUDvLxIcSysBXlKn
   iEdJQOuwambqojRUDvLxIcSysBXlKn['stream_cookie']=iEdJQOuwambqojRUDvLxIcSysBXlAK['awscookie']
  except iEdJQOuwambqojRUDvLxIcSysBXlMh as exception:
   iEdJQOuwambqojRUDvLxIcSysBXlMN(exception)
  return iEdJQOuwambqojRUDvLxIcSysBXlKn
 def make_viewdate(iEdJQOuwambqojRUDvLxIcSysBXlrp):
  iEdJQOuwambqojRUDvLxIcSysBXlze =iEdJQOuwambqojRUDvLxIcSysBXlrp.Get_Now_Datetime()
  iEdJQOuwambqojRUDvLxIcSysBXlzP =iEdJQOuwambqojRUDvLxIcSysBXlze+datetime.timedelta(days=-1)
  iEdJQOuwambqojRUDvLxIcSysBXlzT =iEdJQOuwambqojRUDvLxIcSysBXlze+datetime.timedelta(days=1)
  iEdJQOuwambqojRUDvLxIcSysBXlzY=[iEdJQOuwambqojRUDvLxIcSysBXlze.strftime('%Y%m%d'),iEdJQOuwambqojRUDvLxIcSysBXlzT.strftime('%Y%m%d'),]
  return iEdJQOuwambqojRUDvLxIcSysBXlzY
 def Get_Sports_Gamelist(iEdJQOuwambqojRUDvLxIcSysBXlrp):
  iEdJQOuwambqojRUDvLxIcSysBXlzV =iEdJQOuwambqojRUDvLxIcSysBXlrp.make_viewdate()
  iEdJQOuwambqojRUDvLxIcSysBXlzg=[]
  iEdJQOuwambqojRUDvLxIcSysBXlzt =[]
  for iEdJQOuwambqojRUDvLxIcSysBXlzF in iEdJQOuwambqojRUDvLxIcSysBXlzV:
   iEdJQOuwambqojRUDvLxIcSysBXlzk=iEdJQOuwambqojRUDvLxIcSysBXlzF[:6]
   if iEdJQOuwambqojRUDvLxIcSysBXlzk not in iEdJQOuwambqojRUDvLxIcSysBXlzg:
    iEdJQOuwambqojRUDvLxIcSysBXlzg.append(iEdJQOuwambqojRUDvLxIcSysBXlzk)
  try:
   iEdJQOuwambqojRUDvLxIcSysBXlrC='https://annexapi.wavve.com/skb/baseball/teammonthlycalendarlist'
   iEdJQOuwambqojRUDvLxIcSysBXlrV={'IF':'IF-PORG-002','m':'getTeamCalendarListBand','response_format':'json','spo_itm_cd':'KBO','teamcd':'all','tgroup':'B','tvalue':'BC123','ver':'2.0',}
   iEdJQOuwambqojRUDvLxIcSysBXlrV.update(iEdJQOuwambqojRUDvLxIcSysBXlrp.GetDefaultParams(login=iEdJQOuwambqojRUDvLxIcSysBXlMV))
   for iEdJQOuwambqojRUDvLxIcSysBXlzh in iEdJQOuwambqojRUDvLxIcSysBXlzg:
    iEdJQOuwambqojRUDvLxIcSysBXlrV['date']=iEdJQOuwambqojRUDvLxIcSysBXlzh
    iEdJQOuwambqojRUDvLxIcSysBXlAp=iEdJQOuwambqojRUDvLxIcSysBXlrp.callRequestCookies('Get',iEdJQOuwambqojRUDvLxIcSysBXlrC,payload=iEdJQOuwambqojRUDvLxIcSysBXlMY,params=iEdJQOuwambqojRUDvLxIcSysBXlrV,headers=iEdJQOuwambqojRUDvLxIcSysBXlMY,cookies=iEdJQOuwambqojRUDvLxIcSysBXlMY)
    iEdJQOuwambqojRUDvLxIcSysBXlAK=json.loads(iEdJQOuwambqojRUDvLxIcSysBXlAp.text)
    iEdJQOuwambqojRUDvLxIcSysBXlAt=iEdJQOuwambqojRUDvLxIcSysBXlAK['cell_toplist']['celllist']
    for iEdJQOuwambqojRUDvLxIcSysBXlAF in iEdJQOuwambqojRUDvLxIcSysBXlAt:
     iEdJQOuwambqojRUDvLxIcSysBXlzN=iEdJQOuwambqojRUDvLxIcSysBXlAF.get('game_date')
     iEdJQOuwambqojRUDvLxIcSysBXlzn =iEdJQOuwambqojRUDvLxIcSysBXlAF.get('svc_id')
     if iEdJQOuwambqojRUDvLxIcSysBXlzn=='':continue
     if iEdJQOuwambqojRUDvLxIcSysBXlzN in iEdJQOuwambqojRUDvLxIcSysBXlzV:
      iEdJQOuwambqojRUDvLxIcSysBXlzH=iEdJQOuwambqojRUDvLxIcSysBXlAF.get('game_status') 
      iEdJQOuwambqojRUDvLxIcSysBXlzW =iEdJQOuwambqojRUDvLxIcSysBXlAF.get('title_list')[0].get('text')
      iEdJQOuwambqojRUDvLxIcSysBXlzN =iEdJQOuwambqojRUDvLxIcSysBXlzN[:4]+'-'+iEdJQOuwambqojRUDvLxIcSysBXlzN[4:6]+'-'+iEdJQOuwambqojRUDvLxIcSysBXlzN[-2:]
      iEdJQOuwambqojRUDvLxIcSysBXlzG =iEdJQOuwambqojRUDvLxIcSysBXlAF.get('game_time')
      iEdJQOuwambqojRUDvLxIcSysBXlzG =iEdJQOuwambqojRUDvLxIcSysBXlzG[:2]+':'+iEdJQOuwambqojRUDvLxIcSysBXlzG[-2:]
      iEdJQOuwambqojRUDvLxIcSysBXlAk={'game_date':iEdJQOuwambqojRUDvLxIcSysBXlzN,'game_time':iEdJQOuwambqojRUDvLxIcSysBXlzG,'svc_id':iEdJQOuwambqojRUDvLxIcSysBXlzn,'away_team':iEdJQOuwambqojRUDvLxIcSysBXlAF.get('away_team').get('team_name'),'home_team':iEdJQOuwambqojRUDvLxIcSysBXlAF.get('home_team').get('team_name'),'game_status':iEdJQOuwambqojRUDvLxIcSysBXlzH,'game_place':iEdJQOuwambqojRUDvLxIcSysBXlAF.get('game_place'),}
      iEdJQOuwambqojRUDvLxIcSysBXlzt.append(iEdJQOuwambqojRUDvLxIcSysBXlAk)
  except iEdJQOuwambqojRUDvLxIcSysBXlMh as exception:
   iEdJQOuwambqojRUDvLxIcSysBXlMN(exception)
   return[]
  iEdJQOuwambqojRUDvLxIcSysBXlzC=[]
  for i in iEdJQOuwambqojRUDvLxIcSysBXlMF(2):
   for iEdJQOuwambqojRUDvLxIcSysBXlAF in iEdJQOuwambqojRUDvLxIcSysBXlzt:
    if i==0 and iEdJQOuwambqojRUDvLxIcSysBXlAF.get('game_status')=='LIVE':
     iEdJQOuwambqojRUDvLxIcSysBXlzC.append(iEdJQOuwambqojRUDvLxIcSysBXlAF)
    elif i==1 and iEdJQOuwambqojRUDvLxIcSysBXlAF.get('game_status')!='LIVE':
     iEdJQOuwambqojRUDvLxIcSysBXlzC.append(iEdJQOuwambqojRUDvLxIcSysBXlAF)
  return iEdJQOuwambqojRUDvLxIcSysBXlzC
 def GetBookmarkInfo(iEdJQOuwambqojRUDvLxIcSysBXlrp,iEdJQOuwambqojRUDvLxIcSysBXlpM,iEdJQOuwambqojRUDvLxIcSysBXlpz,iEdJQOuwambqojRUDvLxIcSysBXlKG):
  if iEdJQOuwambqojRUDvLxIcSysBXlpz=='tvshow':
   if iEdJQOuwambqojRUDvLxIcSysBXlKG=='contentid':
    iEdJQOuwambqojRUDvLxIcSysBXlpV=iEdJQOuwambqojRUDvLxIcSysBXlpM
    iEdJQOuwambqojRUDvLxIcSysBXlpM =iEdJQOuwambqojRUDvLxIcSysBXlrp.ContentidToSeasonid(iEdJQOuwambqojRUDvLxIcSysBXlpV)
   else:
    iEdJQOuwambqojRUDvLxIcSysBXlpV=iEdJQOuwambqojRUDvLxIcSysBXlrp.ProgramidToContentid(iEdJQOuwambqojRUDvLxIcSysBXlpM)
  else:
   iEdJQOuwambqojRUDvLxIcSysBXlpV=''
  iEdJQOuwambqojRUDvLxIcSysBXlMr={'indexinfo':{'ott':'wavve','videoid':iEdJQOuwambqojRUDvLxIcSysBXlpM,'vidtype':iEdJQOuwambqojRUDvLxIcSysBXlpz,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':iEdJQOuwambqojRUDvLxIcSysBXlpz,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if iEdJQOuwambqojRUDvLxIcSysBXlpz=='tvshow':
   iEdJQOuwambqojRUDvLxIcSysBXlrC=iEdJQOuwambqojRUDvLxIcSysBXlrp.API_DOMAIN+'/fz/vod/contents/'+iEdJQOuwambqojRUDvLxIcSysBXlpV 
   iEdJQOuwambqojRUDvLxIcSysBXlrV=iEdJQOuwambqojRUDvLxIcSysBXlrp.GetDefaultParams(login=iEdJQOuwambqojRUDvLxIcSysBXlMV)
   iEdJQOuwambqojRUDvLxIcSysBXlAp=iEdJQOuwambqojRUDvLxIcSysBXlrp.callRequestCookies('Get',iEdJQOuwambqojRUDvLxIcSysBXlrC,payload=iEdJQOuwambqojRUDvLxIcSysBXlMY,params=iEdJQOuwambqojRUDvLxIcSysBXlrV,headers=iEdJQOuwambqojRUDvLxIcSysBXlMY,cookies=iEdJQOuwambqojRUDvLxIcSysBXlMY)
   iEdJQOuwambqojRUDvLxIcSysBXlAK=json.loads(iEdJQOuwambqojRUDvLxIcSysBXlAp.text)
   if not('programtitle' in iEdJQOuwambqojRUDvLxIcSysBXlAK):return{}
   iEdJQOuwambqojRUDvLxIcSysBXlMA=iEdJQOuwambqojRUDvLxIcSysBXlAK
   iEdJQOuwambqojRUDvLxIcSysBXlMp=iEdJQOuwambqojRUDvLxIcSysBXlMA.get('programtitle')
   iEdJQOuwambqojRUDvLxIcSysBXlMr['saveinfo']['infoLabels']['title']=iEdJQOuwambqojRUDvLxIcSysBXlMp
   if iEdJQOuwambqojRUDvLxIcSysBXlMA.get('targetage')=='18' or iEdJQOuwambqojRUDvLxIcSysBXlMA.get('targetage')=='19' or iEdJQOuwambqojRUDvLxIcSysBXlMA.get('targetage')=='21':
    iEdJQOuwambqojRUDvLxIcSysBXlMp +=u' (%s)'%(iEdJQOuwambqojRUDvLxIcSysBXlMA.get('targetage'))
   iEdJQOuwambqojRUDvLxIcSysBXlMr['saveinfo']['title'] =iEdJQOuwambqojRUDvLxIcSysBXlMp
   iEdJQOuwambqojRUDvLxIcSysBXlMr['saveinfo']['infoLabels']['mpaa'] =iEdJQOuwambqojRUDvLxIcSysBXlMA.get('targetage')
   iEdJQOuwambqojRUDvLxIcSysBXlMr['saveinfo']['infoLabels']['plot'] =iEdJQOuwambqojRUDvLxIcSysBXlMA.get('programsynopsis').replace('<br>','\n')
   iEdJQOuwambqojRUDvLxIcSysBXlMr['saveinfo']['infoLabels']['studio'] =iEdJQOuwambqojRUDvLxIcSysBXlMA.get('channelname')
   if iEdJQOuwambqojRUDvLxIcSysBXlMA.get('firstreleaseyear')!='':iEdJQOuwambqojRUDvLxIcSysBXlMr['saveinfo']['infoLabels']['year'] =iEdJQOuwambqojRUDvLxIcSysBXlMA.get('firstreleaseyear')
   if iEdJQOuwambqojRUDvLxIcSysBXlMA.get('firstreleasedate')!='':iEdJQOuwambqojRUDvLxIcSysBXlMr['saveinfo']['infoLabels']['premiered']=iEdJQOuwambqojRUDvLxIcSysBXlMA.get('firstreleasedate')
   if iEdJQOuwambqojRUDvLxIcSysBXlMA.get('genretext') !='':iEdJQOuwambqojRUDvLxIcSysBXlMr['saveinfo']['infoLabels']['genre'] =[iEdJQOuwambqojRUDvLxIcSysBXlMA.get('genretext')]
   iEdJQOuwambqojRUDvLxIcSysBXlMK=[]
   for iEdJQOuwambqojRUDvLxIcSysBXlMz in iEdJQOuwambqojRUDvLxIcSysBXlMA['actors']['list']:iEdJQOuwambqojRUDvLxIcSysBXlMK.append(iEdJQOuwambqojRUDvLxIcSysBXlMz.get('text'))
   if iEdJQOuwambqojRUDvLxIcSysBXlMW(iEdJQOuwambqojRUDvLxIcSysBXlMK)>0:
    if iEdJQOuwambqojRUDvLxIcSysBXlMK[0]!='':iEdJQOuwambqojRUDvLxIcSysBXlMr['saveinfo']['infoLabels']['cast']=iEdJQOuwambqojRUDvLxIcSysBXlMK
   iEdJQOuwambqojRUDvLxIcSysBXlKp =''
   iEdJQOuwambqojRUDvLxIcSysBXlKz =''
   iEdJQOuwambqojRUDvLxIcSysBXlKM=''
   if iEdJQOuwambqojRUDvLxIcSysBXlMA.get('programposterimage')!='':iEdJQOuwambqojRUDvLxIcSysBXlKp =iEdJQOuwambqojRUDvLxIcSysBXlrp.HTTPTAG+iEdJQOuwambqojRUDvLxIcSysBXlMA.get('programposterimage')
   if iEdJQOuwambqojRUDvLxIcSysBXlMA.get('programimage') !='':iEdJQOuwambqojRUDvLxIcSysBXlKz =iEdJQOuwambqojRUDvLxIcSysBXlrp.HTTPTAG+iEdJQOuwambqojRUDvLxIcSysBXlMA.get('programimage')
   if iEdJQOuwambqojRUDvLxIcSysBXlMA.get('programcircleimage')!='':iEdJQOuwambqojRUDvLxIcSysBXlKM=iEdJQOuwambqojRUDvLxIcSysBXlrp.HTTPTAG+iEdJQOuwambqojRUDvLxIcSysBXlMA.get('programcircleimage')
   if 'poster_default' in iEdJQOuwambqojRUDvLxIcSysBXlKp:
    iEdJQOuwambqojRUDvLxIcSysBXlKp =iEdJQOuwambqojRUDvLxIcSysBXlKz
    iEdJQOuwambqojRUDvLxIcSysBXlKM=''
   iEdJQOuwambqojRUDvLxIcSysBXlMr['saveinfo']['thumbnail']['poster']=iEdJQOuwambqojRUDvLxIcSysBXlKp
   iEdJQOuwambqojRUDvLxIcSysBXlMr['saveinfo']['thumbnail']['thumb']=iEdJQOuwambqojRUDvLxIcSysBXlKz
   iEdJQOuwambqojRUDvLxIcSysBXlMr['saveinfo']['thumbnail']['clearlogo']=iEdJQOuwambqojRUDvLxIcSysBXlKM
   iEdJQOuwambqojRUDvLxIcSysBXlMr['saveinfo']['thumbnail']['fanart']=iEdJQOuwambqojRUDvLxIcSysBXlKz
  else:
   iEdJQOuwambqojRUDvLxIcSysBXlrC=iEdJQOuwambqojRUDvLxIcSysBXlrp.API_DOMAIN+'/movie/contents/'+iEdJQOuwambqojRUDvLxIcSysBXlpM 
   iEdJQOuwambqojRUDvLxIcSysBXlrV=iEdJQOuwambqojRUDvLxIcSysBXlrp.GetDefaultParams(login=iEdJQOuwambqojRUDvLxIcSysBXlMV)
   iEdJQOuwambqojRUDvLxIcSysBXlAp=iEdJQOuwambqojRUDvLxIcSysBXlrp.callRequestCookies('Get',iEdJQOuwambqojRUDvLxIcSysBXlrC,payload=iEdJQOuwambqojRUDvLxIcSysBXlMY,params=iEdJQOuwambqojRUDvLxIcSysBXlrV,headers=iEdJQOuwambqojRUDvLxIcSysBXlMY,cookies=iEdJQOuwambqojRUDvLxIcSysBXlMY)
   iEdJQOuwambqojRUDvLxIcSysBXlAK=json.loads(iEdJQOuwambqojRUDvLxIcSysBXlAp.text)
   if not('title' in iEdJQOuwambqojRUDvLxIcSysBXlAK):return{}
   iEdJQOuwambqojRUDvLxIcSysBXlMA=iEdJQOuwambqojRUDvLxIcSysBXlAK
   iEdJQOuwambqojRUDvLxIcSysBXlMp=iEdJQOuwambqojRUDvLxIcSysBXlMA.get('title')
   iEdJQOuwambqojRUDvLxIcSysBXlMr['saveinfo']['infoLabels']['title']=iEdJQOuwambqojRUDvLxIcSysBXlMp
   if iEdJQOuwambqojRUDvLxIcSysBXlMA.get('targetage')=='18' or iEdJQOuwambqojRUDvLxIcSysBXlMA.get('targetage')=='19' or iEdJQOuwambqojRUDvLxIcSysBXlMA.get('targetage')=='21':
    iEdJQOuwambqojRUDvLxIcSysBXlMp +=u' (%s)'%(iEdJQOuwambqojRUDvLxIcSysBXlMA.get('targetage'))
   iEdJQOuwambqojRUDvLxIcSysBXlMr['saveinfo']['title'] =iEdJQOuwambqojRUDvLxIcSysBXlMp
   iEdJQOuwambqojRUDvLxIcSysBXlMr['saveinfo']['infoLabels']['mpaa'] =iEdJQOuwambqojRUDvLxIcSysBXlMA.get('targetage')
   iEdJQOuwambqojRUDvLxIcSysBXlMr['saveinfo']['infoLabels']['plot'] =iEdJQOuwambqojRUDvLxIcSysBXlMA.get('synopsis').replace('<br>','\n')
   iEdJQOuwambqojRUDvLxIcSysBXlMr['saveinfo']['infoLabels']['duration']=iEdJQOuwambqojRUDvLxIcSysBXlMA.get('playtime')
   iEdJQOuwambqojRUDvLxIcSysBXlMr['saveinfo']['infoLabels']['country']=iEdJQOuwambqojRUDvLxIcSysBXlMA.get('country')
   iEdJQOuwambqojRUDvLxIcSysBXlMr['saveinfo']['infoLabels']['studio'] =iEdJQOuwambqojRUDvLxIcSysBXlMA.get('cpname')
   if iEdJQOuwambqojRUDvLxIcSysBXlMA.get('releasedate')!='':
    iEdJQOuwambqojRUDvLxIcSysBXlMr['saveinfo']['infoLabels']['year'] =iEdJQOuwambqojRUDvLxIcSysBXlMA.get('releasedate')[:4]
    iEdJQOuwambqojRUDvLxIcSysBXlMr['saveinfo']['infoLabels']['premiered']=iEdJQOuwambqojRUDvLxIcSysBXlMA.get('releasedate')
   iEdJQOuwambqojRUDvLxIcSysBXlMK=[]
   for iEdJQOuwambqojRUDvLxIcSysBXlMz in iEdJQOuwambqojRUDvLxIcSysBXlMA['actors']['list']:iEdJQOuwambqojRUDvLxIcSysBXlMK.append(iEdJQOuwambqojRUDvLxIcSysBXlMz.get('text'))
   if iEdJQOuwambqojRUDvLxIcSysBXlMW(iEdJQOuwambqojRUDvLxIcSysBXlMK)>0:
    if iEdJQOuwambqojRUDvLxIcSysBXlMK[0]!='':iEdJQOuwambqojRUDvLxIcSysBXlMr['saveinfo']['infoLabels']['cast']=iEdJQOuwambqojRUDvLxIcSysBXlMK
   iEdJQOuwambqojRUDvLxIcSysBXlMf=[]
   for iEdJQOuwambqojRUDvLxIcSysBXlMe in iEdJQOuwambqojRUDvLxIcSysBXlMA['directors']['list']:iEdJQOuwambqojRUDvLxIcSysBXlMf.append(iEdJQOuwambqojRUDvLxIcSysBXlMe.get('text'))
   if iEdJQOuwambqojRUDvLxIcSysBXlMW(iEdJQOuwambqojRUDvLxIcSysBXlMf)>0:
    if iEdJQOuwambqojRUDvLxIcSysBXlMf[0]!='':iEdJQOuwambqojRUDvLxIcSysBXlMr['saveinfo']['infoLabels']['director']=iEdJQOuwambqojRUDvLxIcSysBXlMf
   iEdJQOuwambqojRUDvLxIcSysBXlAY=[]
   for iEdJQOuwambqojRUDvLxIcSysBXlMP in iEdJQOuwambqojRUDvLxIcSysBXlMA['genre']['list']:iEdJQOuwambqojRUDvLxIcSysBXlAY.append(iEdJQOuwambqojRUDvLxIcSysBXlMP.get('text'))
   if iEdJQOuwambqojRUDvLxIcSysBXlMW(iEdJQOuwambqojRUDvLxIcSysBXlAY)>0:
    if iEdJQOuwambqojRUDvLxIcSysBXlAY[0]!='':iEdJQOuwambqojRUDvLxIcSysBXlMr['saveinfo']['infoLabels']['genre']=iEdJQOuwambqojRUDvLxIcSysBXlAY
   iEdJQOuwambqojRUDvLxIcSysBXlKp ='https://%s'%iEdJQOuwambqojRUDvLxIcSysBXlMA['image']
   iEdJQOuwambqojRUDvLxIcSysBXlMr['saveinfo']['thumbnail']['poster'] =iEdJQOuwambqojRUDvLxIcSysBXlKp
   iEdJQOuwambqojRUDvLxIcSysBXlMr['saveinfo']['thumbnail']['thumb'] =iEdJQOuwambqojRUDvLxIcSysBXlKp
  return iEdJQOuwambqojRUDvLxIcSysBXlMr
# Created by pyminifier (https://github.com/liftoff/pyminifier)
