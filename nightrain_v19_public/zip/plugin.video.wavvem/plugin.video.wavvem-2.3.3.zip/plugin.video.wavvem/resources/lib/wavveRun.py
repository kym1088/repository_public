__author__="NightRain"
XeCckmAJdpKVIzTFMwbilEajqgtOuD=object
XeCckmAJdpKVIzTFMwbilEajqgtOuy=None
XeCckmAJdpKVIzTFMwbilEajqgtOuU=int
XeCckmAJdpKVIzTFMwbilEajqgtOuS=True
XeCckmAJdpKVIzTFMwbilEajqgtOuB=False
XeCckmAJdpKVIzTFMwbilEajqgtOur=type
XeCckmAJdpKVIzTFMwbilEajqgtOuW=dict
XeCckmAJdpKVIzTFMwbilEajqgtOuY=len
XeCckmAJdpKVIzTFMwbilEajqgtOuN=range
XeCckmAJdpKVIzTFMwbilEajqgtOuQ=str
XeCckmAJdpKVIzTFMwbilEajqgtOun=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import json
XeCckmAJdpKVIzTFMwbilEajqgtOHv=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://www.wavve.com/supermultisection/GN51','icon':'home.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&uicode=VN500','page':'1','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?WeekDay=all&broadcastid=1390539&contenttype=vod&genre=01&orderby=viewtime&uicode=VN4&uiparent=FN0&uirank=0&uitype=VN4','page':'1','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?WeekDay=all&broadcastid=1311034&contenttype=vod&genre=02&orderby=viewtime&uicode=VN3&uiparent=FN0&uirank=0&uitype=VN3','page':'1','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'1','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'modifydate','ordernm':'업데이트순','icon':''},{'title':'프로야구 - 경기중 시청가능','mode':'GAME_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'(웨이브) 검색','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'(웨이브) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
XeCckmAJdpKVIzTFMwbilEajqgtOHD=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
XeCckmAJdpKVIzTFMwbilEajqgtOHy=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
XeCckmAJdpKVIzTFMwbilEajqgtOHU =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
XeCckmAJdpKVIzTFMwbilEajqgtOHS=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_searched.txt'))
from wavveCore import*
class XeCckmAJdpKVIzTFMwbilEajqgtOHG(XeCckmAJdpKVIzTFMwbilEajqgtOuD):
 def __init__(XeCckmAJdpKVIzTFMwbilEajqgtOHu,XeCckmAJdpKVIzTFMwbilEajqgtOHB,XeCckmAJdpKVIzTFMwbilEajqgtOHr,XeCckmAJdpKVIzTFMwbilEajqgtOHW):
  XeCckmAJdpKVIzTFMwbilEajqgtOHu._addon_url =XeCckmAJdpKVIzTFMwbilEajqgtOHB
  XeCckmAJdpKVIzTFMwbilEajqgtOHu._addon_handle=XeCckmAJdpKVIzTFMwbilEajqgtOHr
  XeCckmAJdpKVIzTFMwbilEajqgtOHu.main_params =XeCckmAJdpKVIzTFMwbilEajqgtOHW
  XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj =iEdJQOuwambqojRUDvLxIcSysBXlrA() 
 def addon_noti(XeCckmAJdpKVIzTFMwbilEajqgtOHu,sting):
  try:
   XeCckmAJdpKVIzTFMwbilEajqgtOHN=xbmcgui.Dialog()
   XeCckmAJdpKVIzTFMwbilEajqgtOHN.notification(__addonname__,sting)
  except:
   XeCckmAJdpKVIzTFMwbilEajqgtOuy
 def addon_log(XeCckmAJdpKVIzTFMwbilEajqgtOHu,string):
  try:
   XeCckmAJdpKVIzTFMwbilEajqgtOHQ=string.encode('utf-8','ignore')
  except:
   XeCckmAJdpKVIzTFMwbilEajqgtOHQ='addonException: addon_log'
  XeCckmAJdpKVIzTFMwbilEajqgtOHn=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,XeCckmAJdpKVIzTFMwbilEajqgtOHQ),level=XeCckmAJdpKVIzTFMwbilEajqgtOHn)
 def get_keyboard_input(XeCckmAJdpKVIzTFMwbilEajqgtOHu,XeCckmAJdpKVIzTFMwbilEajqgtOGr):
  XeCckmAJdpKVIzTFMwbilEajqgtOHL=XeCckmAJdpKVIzTFMwbilEajqgtOuy
  kb=xbmc.Keyboard()
  kb.setHeading(XeCckmAJdpKVIzTFMwbilEajqgtOGr)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   XeCckmAJdpKVIzTFMwbilEajqgtOHL=kb.getText()
  return XeCckmAJdpKVIzTFMwbilEajqgtOHL
 def get_settings_account(XeCckmAJdpKVIzTFMwbilEajqgtOHu):
  XeCckmAJdpKVIzTFMwbilEajqgtOHx =__addon__.getSetting('id')
  XeCckmAJdpKVIzTFMwbilEajqgtOHR =__addon__.getSetting('pw')
  XeCckmAJdpKVIzTFMwbilEajqgtOHo=XeCckmAJdpKVIzTFMwbilEajqgtOuU(__addon__.getSetting('selected_profile'))
  return(XeCckmAJdpKVIzTFMwbilEajqgtOHx,XeCckmAJdpKVIzTFMwbilEajqgtOHR,XeCckmAJdpKVIzTFMwbilEajqgtOHo)
 def get_settings_totalsearch(XeCckmAJdpKVIzTFMwbilEajqgtOHu):
  XeCckmAJdpKVIzTFMwbilEajqgtOHs =XeCckmAJdpKVIzTFMwbilEajqgtOuS if __addon__.getSetting('local_search')=='true' else XeCckmAJdpKVIzTFMwbilEajqgtOuB
  XeCckmAJdpKVIzTFMwbilEajqgtOHf=XeCckmAJdpKVIzTFMwbilEajqgtOuS if __addon__.getSetting('local_history')=='true' else XeCckmAJdpKVIzTFMwbilEajqgtOuB
  XeCckmAJdpKVIzTFMwbilEajqgtOHP =XeCckmAJdpKVIzTFMwbilEajqgtOuS if __addon__.getSetting('total_search')=='true' else XeCckmAJdpKVIzTFMwbilEajqgtOuB
  XeCckmAJdpKVIzTFMwbilEajqgtOHh=XeCckmAJdpKVIzTFMwbilEajqgtOuS if __addon__.getSetting('total_history')=='true' else XeCckmAJdpKVIzTFMwbilEajqgtOuB
  XeCckmAJdpKVIzTFMwbilEajqgtOGH=XeCckmAJdpKVIzTFMwbilEajqgtOuS if __addon__.getSetting('menu_bookmark')=='true' else XeCckmAJdpKVIzTFMwbilEajqgtOuB
  return(XeCckmAJdpKVIzTFMwbilEajqgtOHs,XeCckmAJdpKVIzTFMwbilEajqgtOHf,XeCckmAJdpKVIzTFMwbilEajqgtOHP,XeCckmAJdpKVIzTFMwbilEajqgtOHh,XeCckmAJdpKVIzTFMwbilEajqgtOGH)
 def get_settings_makebookmark(XeCckmAJdpKVIzTFMwbilEajqgtOHu):
  return XeCckmAJdpKVIzTFMwbilEajqgtOuS if __addon__.getSetting('make_bookmark')=='true' else XeCckmAJdpKVIzTFMwbilEajqgtOuB
 def get_settings_play(XeCckmAJdpKVIzTFMwbilEajqgtOHu):
  XeCckmAJdpKVIzTFMwbilEajqgtOGv={'enable_hdr':XeCckmAJdpKVIzTFMwbilEajqgtOuS if __addon__.getSetting('enable_hdr')=='true' else XeCckmAJdpKVIzTFMwbilEajqgtOuB,}
  if XeCckmAJdpKVIzTFMwbilEajqgtOGv['enable_hdr']==XeCckmAJdpKVIzTFMwbilEajqgtOuS:
   if XeCckmAJdpKVIzTFMwbilEajqgtOHu.get_selQuality()<1080:XeCckmAJdpKVIzTFMwbilEajqgtOGv['enable_hdr']=XeCckmAJdpKVIzTFMwbilEajqgtOuB
  return(XeCckmAJdpKVIzTFMwbilEajqgtOGv)
 def get_selQuality(XeCckmAJdpKVIzTFMwbilEajqgtOHu):
  try:
   XeCckmAJdpKVIzTFMwbilEajqgtOGD=[1080,720,480,360]
   XeCckmAJdpKVIzTFMwbilEajqgtOGy=XeCckmAJdpKVIzTFMwbilEajqgtOuU(__addon__.getSetting('selected_quality'))
   return XeCckmAJdpKVIzTFMwbilEajqgtOGD[XeCckmAJdpKVIzTFMwbilEajqgtOGy]
  except:
   XeCckmAJdpKVIzTFMwbilEajqgtOuy
  return 1080 
 def get_settings_exclusion21(XeCckmAJdpKVIzTFMwbilEajqgtOHu):
  XeCckmAJdpKVIzTFMwbilEajqgtOGU =__addon__.getSetting('exclusion21')
  if XeCckmAJdpKVIzTFMwbilEajqgtOGU=='false':
   return XeCckmAJdpKVIzTFMwbilEajqgtOuB
  else:
   return XeCckmAJdpKVIzTFMwbilEajqgtOuS
 def get_settings_direct_replay(XeCckmAJdpKVIzTFMwbilEajqgtOHu):
  XeCckmAJdpKVIzTFMwbilEajqgtOGS=XeCckmAJdpKVIzTFMwbilEajqgtOuU(__addon__.getSetting('direct_replay'))
  if XeCckmAJdpKVIzTFMwbilEajqgtOGS==0:
   return XeCckmAJdpKVIzTFMwbilEajqgtOuB
  else:
   return XeCckmAJdpKVIzTFMwbilEajqgtOuS
 def set_winEpisodeOrderby(XeCckmAJdpKVIzTFMwbilEajqgtOHu,XeCckmAJdpKVIzTFMwbilEajqgtOGu):
  __addon__.setSetting('wavve_orderby',XeCckmAJdpKVIzTFMwbilEajqgtOGu)
 def get_winEpisodeOrderby(XeCckmAJdpKVIzTFMwbilEajqgtOHu):
  XeCckmAJdpKVIzTFMwbilEajqgtOGu=__addon__.getSetting('wavve_orderby')
  if XeCckmAJdpKVIzTFMwbilEajqgtOGu in['',XeCckmAJdpKVIzTFMwbilEajqgtOuy]:XeCckmAJdpKVIzTFMwbilEajqgtOGu='desc'
  return XeCckmAJdpKVIzTFMwbilEajqgtOGu
 def add_dir(XeCckmAJdpKVIzTFMwbilEajqgtOHu,label,sublabel='',img='',infoLabels=XeCckmAJdpKVIzTFMwbilEajqgtOuy,isFolder=XeCckmAJdpKVIzTFMwbilEajqgtOuS,params='',isLink=XeCckmAJdpKVIzTFMwbilEajqgtOuB,ContextMenu=XeCckmAJdpKVIzTFMwbilEajqgtOuy):
  XeCckmAJdpKVIzTFMwbilEajqgtOGB='%s?%s'%(XeCckmAJdpKVIzTFMwbilEajqgtOHu._addon_url,urllib.parse.urlencode(params))
  if sublabel:XeCckmAJdpKVIzTFMwbilEajqgtOGr='%s < %s >'%(label,sublabel)
  else: XeCckmAJdpKVIzTFMwbilEajqgtOGr=label
  if not img:img='DefaultFolder.png'
  XeCckmAJdpKVIzTFMwbilEajqgtOGW=xbmcgui.ListItem(XeCckmAJdpKVIzTFMwbilEajqgtOGr)
  if XeCckmAJdpKVIzTFMwbilEajqgtOur(img)==XeCckmAJdpKVIzTFMwbilEajqgtOuW:
   XeCckmAJdpKVIzTFMwbilEajqgtOGW.setArt(img)
  else:
   XeCckmAJdpKVIzTFMwbilEajqgtOGW.setArt({'thumb':img,'poster':img})
  if infoLabels:XeCckmAJdpKVIzTFMwbilEajqgtOGW.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   XeCckmAJdpKVIzTFMwbilEajqgtOGW.setProperty('IsPlayable','true')
  if ContextMenu:XeCckmAJdpKVIzTFMwbilEajqgtOGW.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(XeCckmAJdpKVIzTFMwbilEajqgtOHu._addon_handle,XeCckmAJdpKVIzTFMwbilEajqgtOGB,XeCckmAJdpKVIzTFMwbilEajqgtOGW,isFolder)
 def dp_Main_List(XeCckmAJdpKVIzTFMwbilEajqgtOHu):
  (XeCckmAJdpKVIzTFMwbilEajqgtOHs,XeCckmAJdpKVIzTFMwbilEajqgtOHf,XeCckmAJdpKVIzTFMwbilEajqgtOHP,XeCckmAJdpKVIzTFMwbilEajqgtOHh,XeCckmAJdpKVIzTFMwbilEajqgtOGH)=XeCckmAJdpKVIzTFMwbilEajqgtOHu.get_settings_totalsearch()
  for XeCckmAJdpKVIzTFMwbilEajqgtOGY in XeCckmAJdpKVIzTFMwbilEajqgtOHv:
   XeCckmAJdpKVIzTFMwbilEajqgtOGr=XeCckmAJdpKVIzTFMwbilEajqgtOGY.get('title')
   XeCckmAJdpKVIzTFMwbilEajqgtOGN=''
   if XeCckmAJdpKVIzTFMwbilEajqgtOGY.get('mode')=='SEARCH_GROUP' and XeCckmAJdpKVIzTFMwbilEajqgtOHs ==XeCckmAJdpKVIzTFMwbilEajqgtOuB:continue
   elif XeCckmAJdpKVIzTFMwbilEajqgtOGY.get('mode')=='SEARCH_HISTORY' and XeCckmAJdpKVIzTFMwbilEajqgtOHf==XeCckmAJdpKVIzTFMwbilEajqgtOuB:continue
   elif XeCckmAJdpKVIzTFMwbilEajqgtOGY.get('mode')=='TOTAL_SEARCH' and XeCckmAJdpKVIzTFMwbilEajqgtOHP ==XeCckmAJdpKVIzTFMwbilEajqgtOuB:continue
   elif XeCckmAJdpKVIzTFMwbilEajqgtOGY.get('mode')=='TOTAL_HISTORY' and XeCckmAJdpKVIzTFMwbilEajqgtOHh==XeCckmAJdpKVIzTFMwbilEajqgtOuB:continue
   elif XeCckmAJdpKVIzTFMwbilEajqgtOGY.get('mode')=='MENU_BOOKMARK' and XeCckmAJdpKVIzTFMwbilEajqgtOGH==XeCckmAJdpKVIzTFMwbilEajqgtOuB:continue
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ={'mode':XeCckmAJdpKVIzTFMwbilEajqgtOGY.get('mode'),'sCode':XeCckmAJdpKVIzTFMwbilEajqgtOGY.get('sCode'),'sIndex':XeCckmAJdpKVIzTFMwbilEajqgtOGY.get('sIndex'),'sType':XeCckmAJdpKVIzTFMwbilEajqgtOGY.get('sType'),'suburl':XeCckmAJdpKVIzTFMwbilEajqgtOGY.get('suburl'),'subapi':XeCckmAJdpKVIzTFMwbilEajqgtOGY.get('subapi'),'page':XeCckmAJdpKVIzTFMwbilEajqgtOGY.get('page'),'orderby':XeCckmAJdpKVIzTFMwbilEajqgtOGY.get('orderby'),'ordernm':XeCckmAJdpKVIzTFMwbilEajqgtOGY.get('ordernm')}
   if XeCckmAJdpKVIzTFMwbilEajqgtOGY.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    XeCckmAJdpKVIzTFMwbilEajqgtOGn=XeCckmAJdpKVIzTFMwbilEajqgtOuB
    XeCckmAJdpKVIzTFMwbilEajqgtOGL =XeCckmAJdpKVIzTFMwbilEajqgtOuS
   else:
    XeCckmAJdpKVIzTFMwbilEajqgtOGn=XeCckmAJdpKVIzTFMwbilEajqgtOuS
    XeCckmAJdpKVIzTFMwbilEajqgtOGL =XeCckmAJdpKVIzTFMwbilEajqgtOuB
   if 'icon' in XeCckmAJdpKVIzTFMwbilEajqgtOGY:XeCckmAJdpKVIzTFMwbilEajqgtOGN=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',XeCckmAJdpKVIzTFMwbilEajqgtOGY.get('icon')) 
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.add_dir(XeCckmAJdpKVIzTFMwbilEajqgtOGr,sublabel='',img=XeCckmAJdpKVIzTFMwbilEajqgtOGN,infoLabels=XeCckmAJdpKVIzTFMwbilEajqgtOuy,isFolder=XeCckmAJdpKVIzTFMwbilEajqgtOGn,params=XeCckmAJdpKVIzTFMwbilEajqgtOGQ,isLink=XeCckmAJdpKVIzTFMwbilEajqgtOGL)
  xbmcplugin.endOfDirectory(XeCckmAJdpKVIzTFMwbilEajqgtOHu._addon_handle,cacheToDisc=XeCckmAJdpKVIzTFMwbilEajqgtOuS)
 def dp_Search_Group(XeCckmAJdpKVIzTFMwbilEajqgtOHu,args):
  if 'search_key' in args:
   XeCckmAJdpKVIzTFMwbilEajqgtOGo=args.get('search_key')
  else:
   XeCckmAJdpKVIzTFMwbilEajqgtOGo=XeCckmAJdpKVIzTFMwbilEajqgtOHu.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not XeCckmAJdpKVIzTFMwbilEajqgtOGo:
    return
  for XeCckmAJdpKVIzTFMwbilEajqgtOGs in XeCckmAJdpKVIzTFMwbilEajqgtOHD:
   XeCckmAJdpKVIzTFMwbilEajqgtOGf =XeCckmAJdpKVIzTFMwbilEajqgtOGs.get('mode')
   XeCckmAJdpKVIzTFMwbilEajqgtOGP=XeCckmAJdpKVIzTFMwbilEajqgtOGs.get('sType')
   XeCckmAJdpKVIzTFMwbilEajqgtOGr=XeCckmAJdpKVIzTFMwbilEajqgtOGs.get('title')
   (XeCckmAJdpKVIzTFMwbilEajqgtOGh,XeCckmAJdpKVIzTFMwbilEajqgtOvH)=XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.Get_Search_List(XeCckmAJdpKVIzTFMwbilEajqgtOGo,XeCckmAJdpKVIzTFMwbilEajqgtOGP,1,exclusion21=XeCckmAJdpKVIzTFMwbilEajqgtOHu.get_settings_exclusion21())
   XeCckmAJdpKVIzTFMwbilEajqgtOvG={'plot':'검색어 : '+XeCckmAJdpKVIzTFMwbilEajqgtOGo+'\n\n'+XeCckmAJdpKVIzTFMwbilEajqgtOHu.Search_FreeList(XeCckmAJdpKVIzTFMwbilEajqgtOGh)}
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ={'mode':XeCckmAJdpKVIzTFMwbilEajqgtOGf,'sType':XeCckmAJdpKVIzTFMwbilEajqgtOGP,'search_key':XeCckmAJdpKVIzTFMwbilEajqgtOGo,'page':'1',}
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.add_dir(XeCckmAJdpKVIzTFMwbilEajqgtOGr,sublabel='',img='',infoLabels=XeCckmAJdpKVIzTFMwbilEajqgtOvG,isFolder=XeCckmAJdpKVIzTFMwbilEajqgtOuS,params=XeCckmAJdpKVIzTFMwbilEajqgtOGQ)
  if XeCckmAJdpKVIzTFMwbilEajqgtOuY(XeCckmAJdpKVIzTFMwbilEajqgtOHD)>0:xbmcplugin.endOfDirectory(XeCckmAJdpKVIzTFMwbilEajqgtOHu._addon_handle,cacheToDisc=XeCckmAJdpKVIzTFMwbilEajqgtOuS)
  XeCckmAJdpKVIzTFMwbilEajqgtOHu.Save_Searched_List(XeCckmAJdpKVIzTFMwbilEajqgtOGo)
 def Search_FreeList(XeCckmAJdpKVIzTFMwbilEajqgtOHu,search_list):
  XeCckmAJdpKVIzTFMwbilEajqgtOvD=''
  XeCckmAJdpKVIzTFMwbilEajqgtOvy=7
  try:
   if XeCckmAJdpKVIzTFMwbilEajqgtOuY(search_list)==0:return '검색결과 없음'
   for i in XeCckmAJdpKVIzTFMwbilEajqgtOuN(XeCckmAJdpKVIzTFMwbilEajqgtOuY(search_list)):
    if i>=XeCckmAJdpKVIzTFMwbilEajqgtOvy:
     XeCckmAJdpKVIzTFMwbilEajqgtOvD=XeCckmAJdpKVIzTFMwbilEajqgtOvD+'...'
     break
    XeCckmAJdpKVIzTFMwbilEajqgtOvD=XeCckmAJdpKVIzTFMwbilEajqgtOvD+search_list[i]['title']+'\n'
  except:
   return ''
  return XeCckmAJdpKVIzTFMwbilEajqgtOvD
 def dp_Watch_Group(XeCckmAJdpKVIzTFMwbilEajqgtOHu,args):
  for XeCckmAJdpKVIzTFMwbilEajqgtOvU in XeCckmAJdpKVIzTFMwbilEajqgtOHy:
   XeCckmAJdpKVIzTFMwbilEajqgtOGr=XeCckmAJdpKVIzTFMwbilEajqgtOvU.get('title')
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ={'mode':XeCckmAJdpKVIzTFMwbilEajqgtOvU.get('mode'),'sType':XeCckmAJdpKVIzTFMwbilEajqgtOvU.get('sType')}
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.add_dir(XeCckmAJdpKVIzTFMwbilEajqgtOGr,sublabel='',img='',infoLabels=XeCckmAJdpKVIzTFMwbilEajqgtOuy,isFolder=XeCckmAJdpKVIzTFMwbilEajqgtOuS,params=XeCckmAJdpKVIzTFMwbilEajqgtOGQ)
  if XeCckmAJdpKVIzTFMwbilEajqgtOuY(XeCckmAJdpKVIzTFMwbilEajqgtOHy)>0:xbmcplugin.endOfDirectory(XeCckmAJdpKVIzTFMwbilEajqgtOHu._addon_handle,cacheToDisc=XeCckmAJdpKVIzTFMwbilEajqgtOuS)
 def dp_Search_History(XeCckmAJdpKVIzTFMwbilEajqgtOHu,args):
  XeCckmAJdpKVIzTFMwbilEajqgtOvS=XeCckmAJdpKVIzTFMwbilEajqgtOHu.Load_List_File('search')
  for XeCckmAJdpKVIzTFMwbilEajqgtOvu in XeCckmAJdpKVIzTFMwbilEajqgtOvS:
   XeCckmAJdpKVIzTFMwbilEajqgtOvB=XeCckmAJdpKVIzTFMwbilEajqgtOuW(urllib.parse.parse_qsl(XeCckmAJdpKVIzTFMwbilEajqgtOvu))
   XeCckmAJdpKVIzTFMwbilEajqgtOvr=XeCckmAJdpKVIzTFMwbilEajqgtOvB.get('skey').strip()
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ={'mode':'SEARCH_GROUP','search_key':XeCckmAJdpKVIzTFMwbilEajqgtOvr,}
   XeCckmAJdpKVIzTFMwbilEajqgtOvW={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':XeCckmAJdpKVIzTFMwbilEajqgtOvr,'vType':'-',}
   XeCckmAJdpKVIzTFMwbilEajqgtOvY=urllib.parse.urlencode(XeCckmAJdpKVIzTFMwbilEajqgtOvW)
   XeCckmAJdpKVIzTFMwbilEajqgtOvN=[('선택된 검색어 ( %s ) 삭제'%(XeCckmAJdpKVIzTFMwbilEajqgtOvr),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(XeCckmAJdpKVIzTFMwbilEajqgtOvY))]
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.add_dir(XeCckmAJdpKVIzTFMwbilEajqgtOvr,sublabel='',img=XeCckmAJdpKVIzTFMwbilEajqgtOuy,infoLabels=XeCckmAJdpKVIzTFMwbilEajqgtOuy,isFolder=XeCckmAJdpKVIzTFMwbilEajqgtOuS,params=XeCckmAJdpKVIzTFMwbilEajqgtOGQ,ContextMenu=XeCckmAJdpKVIzTFMwbilEajqgtOvN)
  XeCckmAJdpKVIzTFMwbilEajqgtOvQ={'plot':'검색목록 전체를 삭제합니다.'}
  XeCckmAJdpKVIzTFMwbilEajqgtOGr='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  XeCckmAJdpKVIzTFMwbilEajqgtOGQ={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  XeCckmAJdpKVIzTFMwbilEajqgtOGN=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  XeCckmAJdpKVIzTFMwbilEajqgtOHu.add_dir(XeCckmAJdpKVIzTFMwbilEajqgtOGr,sublabel='',img=XeCckmAJdpKVIzTFMwbilEajqgtOGN,infoLabels=XeCckmAJdpKVIzTFMwbilEajqgtOvQ,isFolder=XeCckmAJdpKVIzTFMwbilEajqgtOuB,params=XeCckmAJdpKVIzTFMwbilEajqgtOGQ,isLink=XeCckmAJdpKVIzTFMwbilEajqgtOuS)
  xbmcplugin.endOfDirectory(XeCckmAJdpKVIzTFMwbilEajqgtOHu._addon_handle,cacheToDisc=XeCckmAJdpKVIzTFMwbilEajqgtOuB)
 def dp_Search_List(XeCckmAJdpKVIzTFMwbilEajqgtOHu,args):
  XeCckmAJdpKVIzTFMwbilEajqgtOGP =args.get('sType')
  XeCckmAJdpKVIzTFMwbilEajqgtOvn =XeCckmAJdpKVIzTFMwbilEajqgtOuU(args.get('page'))
  if 'search_key' in args:
   XeCckmAJdpKVIzTFMwbilEajqgtOGo=args.get('search_key')
  else:
   XeCckmAJdpKVIzTFMwbilEajqgtOGo=XeCckmAJdpKVIzTFMwbilEajqgtOHu.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not XeCckmAJdpKVIzTFMwbilEajqgtOGo:
    xbmcplugin.endOfDirectory(XeCckmAJdpKVIzTFMwbilEajqgtOHu._addon_handle)
    return
  XeCckmAJdpKVIzTFMwbilEajqgtOvL,XeCckmAJdpKVIzTFMwbilEajqgtOvH=XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.Get_Search_List(XeCckmAJdpKVIzTFMwbilEajqgtOGo,XeCckmAJdpKVIzTFMwbilEajqgtOGP,XeCckmAJdpKVIzTFMwbilEajqgtOvn,exclusion21=XeCckmAJdpKVIzTFMwbilEajqgtOHu.get_settings_exclusion21())
  for XeCckmAJdpKVIzTFMwbilEajqgtOvx in XeCckmAJdpKVIzTFMwbilEajqgtOvL:
   XeCckmAJdpKVIzTFMwbilEajqgtOvR =XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('videoid')
   XeCckmAJdpKVIzTFMwbilEajqgtOvo =XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('vidtype')
   XeCckmAJdpKVIzTFMwbilEajqgtOGr =XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('title')
   XeCckmAJdpKVIzTFMwbilEajqgtOvs=XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('thumbnail')
   XeCckmAJdpKVIzTFMwbilEajqgtOvf =XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('age')
   if XeCckmAJdpKVIzTFMwbilEajqgtOvf=='18' or XeCckmAJdpKVIzTFMwbilEajqgtOvf=='19' or XeCckmAJdpKVIzTFMwbilEajqgtOvf=='21':XeCckmAJdpKVIzTFMwbilEajqgtOGr+=' (%s)'%(XeCckmAJdpKVIzTFMwbilEajqgtOvf)
   XeCckmAJdpKVIzTFMwbilEajqgtOvQ={'mediatype':'tvshow' if XeCckmAJdpKVIzTFMwbilEajqgtOGP=='vod' else 'movie','mpaa':XeCckmAJdpKVIzTFMwbilEajqgtOvf,'title':XeCckmAJdpKVIzTFMwbilEajqgtOGr,'plot':XeCckmAJdpKVIzTFMwbilEajqgtOGr}
   if XeCckmAJdpKVIzTFMwbilEajqgtOGP=='vod':
    XeCckmAJdpKVIzTFMwbilEajqgtOGQ={'mode':'EPISODE_LIST','seasonid':XeCckmAJdpKVIzTFMwbilEajqgtOvR,'page':'1',}
    XeCckmAJdpKVIzTFMwbilEajqgtOGn=XeCckmAJdpKVIzTFMwbilEajqgtOuS
   else:
    XeCckmAJdpKVIzTFMwbilEajqgtOGQ={'mode':'MOVIE','contentid':XeCckmAJdpKVIzTFMwbilEajqgtOvR,'title':XeCckmAJdpKVIzTFMwbilEajqgtOGr,'thumbnail':XeCckmAJdpKVIzTFMwbilEajqgtOvs,'age':XeCckmAJdpKVIzTFMwbilEajqgtOvf,}
    XeCckmAJdpKVIzTFMwbilEajqgtOGn=XeCckmAJdpKVIzTFMwbilEajqgtOuB
   XeCckmAJdpKVIzTFMwbilEajqgtOvN=[]
   XeCckmAJdpKVIzTFMwbilEajqgtOvP={'mode':'VIEW_DETAIL','values':{'videoid':XeCckmAJdpKVIzTFMwbilEajqgtOvR,'vidtype':'tvshow' if XeCckmAJdpKVIzTFMwbilEajqgtOGP=='vod' else 'movie','contenttype':XeCckmAJdpKVIzTFMwbilEajqgtOvo,}}
   XeCckmAJdpKVIzTFMwbilEajqgtOvh=json.dumps(XeCckmAJdpKVIzTFMwbilEajqgtOvP,separators=(',',':'))
   XeCckmAJdpKVIzTFMwbilEajqgtOvh=base64.standard_b64encode(XeCckmAJdpKVIzTFMwbilEajqgtOvh.encode()).decode('utf-8')
   XeCckmAJdpKVIzTFMwbilEajqgtOvh=XeCckmAJdpKVIzTFMwbilEajqgtOvh.replace('+','%2B')
   XeCckmAJdpKVIzTFMwbilEajqgtODH='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(XeCckmAJdpKVIzTFMwbilEajqgtOvh)
   XeCckmAJdpKVIzTFMwbilEajqgtOvN.append(('상세정보 조회',XeCckmAJdpKVIzTFMwbilEajqgtODH))
   if XeCckmAJdpKVIzTFMwbilEajqgtOHu.get_settings_makebookmark():
    XeCckmAJdpKVIzTFMwbilEajqgtOvP={'videoid':XeCckmAJdpKVIzTFMwbilEajqgtOvR,'vidtype':'tvshow' if XeCckmAJdpKVIzTFMwbilEajqgtOGP=='vod' else 'movie','vtitle':XeCckmAJdpKVIzTFMwbilEajqgtOGr,'vsubtitle':'','contenttype':XeCckmAJdpKVIzTFMwbilEajqgtOvo,}
    XeCckmAJdpKVIzTFMwbilEajqgtODG=json.dumps(XeCckmAJdpKVIzTFMwbilEajqgtOvP)
    XeCckmAJdpKVIzTFMwbilEajqgtODG=urllib.parse.quote(XeCckmAJdpKVIzTFMwbilEajqgtODG)
    XeCckmAJdpKVIzTFMwbilEajqgtODH='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(XeCckmAJdpKVIzTFMwbilEajqgtODG)
    XeCckmAJdpKVIzTFMwbilEajqgtOvN.append(('(통합) 찜 영상에 추가',XeCckmAJdpKVIzTFMwbilEajqgtODH))
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.add_dir(XeCckmAJdpKVIzTFMwbilEajqgtOGr,sublabel='',img=XeCckmAJdpKVIzTFMwbilEajqgtOvs,infoLabels=XeCckmAJdpKVIzTFMwbilEajqgtOvQ,isFolder=XeCckmAJdpKVIzTFMwbilEajqgtOGn,params=XeCckmAJdpKVIzTFMwbilEajqgtOGQ,ContextMenu=XeCckmAJdpKVIzTFMwbilEajqgtOvN)
  if XeCckmAJdpKVIzTFMwbilEajqgtOvH:
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ['mode'] ='SEARCH_LIST' 
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ['sType']=XeCckmAJdpKVIzTFMwbilEajqgtOGP 
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ['page'] =XeCckmAJdpKVIzTFMwbilEajqgtOuQ(XeCckmAJdpKVIzTFMwbilEajqgtOvn+1)
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ['search_key']=XeCckmAJdpKVIzTFMwbilEajqgtOGo
   XeCckmAJdpKVIzTFMwbilEajqgtOGr='[B]%s >>[/B]'%'다음 페이지'
   XeCckmAJdpKVIzTFMwbilEajqgtODv=XeCckmAJdpKVIzTFMwbilEajqgtOuQ(XeCckmAJdpKVIzTFMwbilEajqgtOvn+1)
   XeCckmAJdpKVIzTFMwbilEajqgtOGN=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.add_dir(XeCckmAJdpKVIzTFMwbilEajqgtOGr,sublabel=XeCckmAJdpKVIzTFMwbilEajqgtODv,img=XeCckmAJdpKVIzTFMwbilEajqgtOGN,infoLabels=XeCckmAJdpKVIzTFMwbilEajqgtOuy,isFolder=XeCckmAJdpKVIzTFMwbilEajqgtOuS,params=XeCckmAJdpKVIzTFMwbilEajqgtOGQ)
  if XeCckmAJdpKVIzTFMwbilEajqgtOGP=='movie':xbmcplugin.setContent(XeCckmAJdpKVIzTFMwbilEajqgtOHu._addon_handle,'movies')
  else:xbmcplugin.setContent(XeCckmAJdpKVIzTFMwbilEajqgtOHu._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(XeCckmAJdpKVIzTFMwbilEajqgtOHu._addon_handle,cacheToDisc=XeCckmAJdpKVIzTFMwbilEajqgtOuB)
 def dp_Watch_List(XeCckmAJdpKVIzTFMwbilEajqgtOHu,args):
  XeCckmAJdpKVIzTFMwbilEajqgtOGP =args.get('sType')
  XeCckmAJdpKVIzTFMwbilEajqgtOGS=XeCckmAJdpKVIzTFMwbilEajqgtOHu.get_settings_direct_replay()
  XeCckmAJdpKVIzTFMwbilEajqgtOvL=XeCckmAJdpKVIzTFMwbilEajqgtOHu.Load_List_File(XeCckmAJdpKVIzTFMwbilEajqgtOGP)
  for XeCckmAJdpKVIzTFMwbilEajqgtOvx in XeCckmAJdpKVIzTFMwbilEajqgtOvL:
   XeCckmAJdpKVIzTFMwbilEajqgtOvB=XeCckmAJdpKVIzTFMwbilEajqgtOuW(urllib.parse.parse_qsl(XeCckmAJdpKVIzTFMwbilEajqgtOvx))
   XeCckmAJdpKVIzTFMwbilEajqgtODy =XeCckmAJdpKVIzTFMwbilEajqgtOvB.get('code').strip()
   XeCckmAJdpKVIzTFMwbilEajqgtOGr =XeCckmAJdpKVIzTFMwbilEajqgtOvB.get('title').strip()
   XeCckmAJdpKVIzTFMwbilEajqgtODv =XeCckmAJdpKVIzTFMwbilEajqgtOvB.get('subtitle').strip()
   if XeCckmAJdpKVIzTFMwbilEajqgtODv=='None':XeCckmAJdpKVIzTFMwbilEajqgtODv=''
   XeCckmAJdpKVIzTFMwbilEajqgtOvs=XeCckmAJdpKVIzTFMwbilEajqgtOvB.get('img').strip()
   XeCckmAJdpKVIzTFMwbilEajqgtOvR =XeCckmAJdpKVIzTFMwbilEajqgtOvB.get('videoid').strip()
   try:
    XeCckmAJdpKVIzTFMwbilEajqgtOvs=XeCckmAJdpKVIzTFMwbilEajqgtOvs.replace('\'','\"')
    XeCckmAJdpKVIzTFMwbilEajqgtOvs=json.loads(XeCckmAJdpKVIzTFMwbilEajqgtOvs)
   except:
    XeCckmAJdpKVIzTFMwbilEajqgtOuy
   XeCckmAJdpKVIzTFMwbilEajqgtOvQ={'plot':'%s\n%s'%(XeCckmAJdpKVIzTFMwbilEajqgtOGr,XeCckmAJdpKVIzTFMwbilEajqgtODv)}
   if XeCckmAJdpKVIzTFMwbilEajqgtOGP=='vod':
    if XeCckmAJdpKVIzTFMwbilEajqgtOGS==XeCckmAJdpKVIzTFMwbilEajqgtOuB or XeCckmAJdpKVIzTFMwbilEajqgtOvR==XeCckmAJdpKVIzTFMwbilEajqgtOuy:
     XeCckmAJdpKVIzTFMwbilEajqgtOvQ['mediatype']='tvshow'
     XeCckmAJdpKVIzTFMwbilEajqgtOGQ={'mode':'SEASON_LIST','videoid':XeCckmAJdpKVIzTFMwbilEajqgtOvR,'vidtype':'contentid',}
     XeCckmAJdpKVIzTFMwbilEajqgtOGn=XeCckmAJdpKVIzTFMwbilEajqgtOuS
    else:
     XeCckmAJdpKVIzTFMwbilEajqgtOvQ['mediatype']='episode'
     XeCckmAJdpKVIzTFMwbilEajqgtOGQ={'mode':'VOD','programid':XeCckmAJdpKVIzTFMwbilEajqgtODy,'contentid':XeCckmAJdpKVIzTFMwbilEajqgtOvR,'title':XeCckmAJdpKVIzTFMwbilEajqgtOGr,'subtitle':XeCckmAJdpKVIzTFMwbilEajqgtODv,'thumbnail':XeCckmAJdpKVIzTFMwbilEajqgtOvs}
     XeCckmAJdpKVIzTFMwbilEajqgtOGn=XeCckmAJdpKVIzTFMwbilEajqgtOuB
   else:
    XeCckmAJdpKVIzTFMwbilEajqgtOvQ['mediatype']='movie'
    XeCckmAJdpKVIzTFMwbilEajqgtOGQ={'mode':'MOVIE','contentid':XeCckmAJdpKVIzTFMwbilEajqgtODy,'title':XeCckmAJdpKVIzTFMwbilEajqgtOGr,'subtitle':XeCckmAJdpKVIzTFMwbilEajqgtODv,'thumbnail':XeCckmAJdpKVIzTFMwbilEajqgtOvs}
    XeCckmAJdpKVIzTFMwbilEajqgtOGn=XeCckmAJdpKVIzTFMwbilEajqgtOuB
   XeCckmAJdpKVIzTFMwbilEajqgtOvW={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':XeCckmAJdpKVIzTFMwbilEajqgtODy,'vType':XeCckmAJdpKVIzTFMwbilEajqgtOGP,}
   XeCckmAJdpKVIzTFMwbilEajqgtOvY=urllib.parse.urlencode(XeCckmAJdpKVIzTFMwbilEajqgtOvW)
   XeCckmAJdpKVIzTFMwbilEajqgtOvN=[('선택된 시청이력 ( %s ) 삭제'%(XeCckmAJdpKVIzTFMwbilEajqgtOGr),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(XeCckmAJdpKVIzTFMwbilEajqgtOvY))]
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.add_dir(XeCckmAJdpKVIzTFMwbilEajqgtOGr,sublabel=XeCckmAJdpKVIzTFMwbilEajqgtODv,img=XeCckmAJdpKVIzTFMwbilEajqgtOvs,infoLabels=XeCckmAJdpKVIzTFMwbilEajqgtOvQ,isFolder=XeCckmAJdpKVIzTFMwbilEajqgtOGn,params=XeCckmAJdpKVIzTFMwbilEajqgtOGQ,ContextMenu=XeCckmAJdpKVIzTFMwbilEajqgtOvN)
  XeCckmAJdpKVIzTFMwbilEajqgtOvQ={'plot':'시청목록을 삭제합니다.'}
  XeCckmAJdpKVIzTFMwbilEajqgtOGr='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  XeCckmAJdpKVIzTFMwbilEajqgtOGQ={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':XeCckmAJdpKVIzTFMwbilEajqgtOGP,}
  XeCckmAJdpKVIzTFMwbilEajqgtOGN=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  XeCckmAJdpKVIzTFMwbilEajqgtOHu.add_dir(XeCckmAJdpKVIzTFMwbilEajqgtOGr,sublabel='',img=XeCckmAJdpKVIzTFMwbilEajqgtOGN,infoLabels=XeCckmAJdpKVIzTFMwbilEajqgtOvQ,isFolder=XeCckmAJdpKVIzTFMwbilEajqgtOuB,params=XeCckmAJdpKVIzTFMwbilEajqgtOGQ,isLink=XeCckmAJdpKVIzTFMwbilEajqgtOuS)
  if XeCckmAJdpKVIzTFMwbilEajqgtOGP=='movie':xbmcplugin.setContent(XeCckmAJdpKVIzTFMwbilEajqgtOHu._addon_handle,'movies')
  else:xbmcplugin.setContent(XeCckmAJdpKVIzTFMwbilEajqgtOHu._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(XeCckmAJdpKVIzTFMwbilEajqgtOHu._addon_handle,cacheToDisc=XeCckmAJdpKVIzTFMwbilEajqgtOuB)
 def Load_List_File(XeCckmAJdpKVIzTFMwbilEajqgtOHu,stype): 
  try:
   if stype=='search':
    XeCckmAJdpKVIzTFMwbilEajqgtODU=XeCckmAJdpKVIzTFMwbilEajqgtOHS
   elif stype in['vod','movie']:
    XeCckmAJdpKVIzTFMwbilEajqgtODU=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   else:
    return[]
   fp=XeCckmAJdpKVIzTFMwbilEajqgtOun(XeCckmAJdpKVIzTFMwbilEajqgtODU,'r',-1,'utf-8')
   XeCckmAJdpKVIzTFMwbilEajqgtODS=fp.readlines()
   fp.close()
  except:
   XeCckmAJdpKVIzTFMwbilEajqgtODS=[]
  return XeCckmAJdpKVIzTFMwbilEajqgtODS
 def Save_Watched_List(XeCckmAJdpKVIzTFMwbilEajqgtOHu,XeCckmAJdpKVIzTFMwbilEajqgtOSN,XeCckmAJdpKVIzTFMwbilEajqgtOHW):
  try:
   XeCckmAJdpKVIzTFMwbilEajqgtODu=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%XeCckmAJdpKVIzTFMwbilEajqgtOSN))
   XeCckmAJdpKVIzTFMwbilEajqgtODB=XeCckmAJdpKVIzTFMwbilEajqgtOHu.Load_List_File(XeCckmAJdpKVIzTFMwbilEajqgtOSN) 
   fp=XeCckmAJdpKVIzTFMwbilEajqgtOun(XeCckmAJdpKVIzTFMwbilEajqgtODu,'w',-1,'utf-8')
   XeCckmAJdpKVIzTFMwbilEajqgtODr=urllib.parse.urlencode(XeCckmAJdpKVIzTFMwbilEajqgtOHW)
   XeCckmAJdpKVIzTFMwbilEajqgtODr=XeCckmAJdpKVIzTFMwbilEajqgtODr+'\n'
   fp.write(XeCckmAJdpKVIzTFMwbilEajqgtODr)
   XeCckmAJdpKVIzTFMwbilEajqgtODW=0
   for XeCckmAJdpKVIzTFMwbilEajqgtODY in XeCckmAJdpKVIzTFMwbilEajqgtODB:
    XeCckmAJdpKVIzTFMwbilEajqgtODN=XeCckmAJdpKVIzTFMwbilEajqgtOuW(urllib.parse.parse_qsl(XeCckmAJdpKVIzTFMwbilEajqgtODY))
    XeCckmAJdpKVIzTFMwbilEajqgtODQ=XeCckmAJdpKVIzTFMwbilEajqgtOHW.get('code').strip()
    XeCckmAJdpKVIzTFMwbilEajqgtODn=XeCckmAJdpKVIzTFMwbilEajqgtODN.get('code').strip()
    if XeCckmAJdpKVIzTFMwbilEajqgtOSN=='vod' and XeCckmAJdpKVIzTFMwbilEajqgtOHu.get_settings_direct_replay()==XeCckmAJdpKVIzTFMwbilEajqgtOuS:
     XeCckmAJdpKVIzTFMwbilEajqgtODQ=XeCckmAJdpKVIzTFMwbilEajqgtOHW.get('videoid').strip()
     XeCckmAJdpKVIzTFMwbilEajqgtODn=XeCckmAJdpKVIzTFMwbilEajqgtODN.get('videoid').strip()if XeCckmAJdpKVIzTFMwbilEajqgtODn!=XeCckmAJdpKVIzTFMwbilEajqgtOuy else '-'
    if XeCckmAJdpKVIzTFMwbilEajqgtODQ!=XeCckmAJdpKVIzTFMwbilEajqgtODn:
     fp.write(XeCckmAJdpKVIzTFMwbilEajqgtODY)
     XeCckmAJdpKVIzTFMwbilEajqgtODW+=1
     if XeCckmAJdpKVIzTFMwbilEajqgtODW>=50:break
   fp.close()
  except:
   XeCckmAJdpKVIzTFMwbilEajqgtOuy
 def dp_History_Remove(XeCckmAJdpKVIzTFMwbilEajqgtOHu,args):
  XeCckmAJdpKVIzTFMwbilEajqgtODL=args.get('delType')
  XeCckmAJdpKVIzTFMwbilEajqgtODx =args.get('sKey')
  XeCckmAJdpKVIzTFMwbilEajqgtODR =args.get('vType')
  XeCckmAJdpKVIzTFMwbilEajqgtOHN=xbmcgui.Dialog()
  if XeCckmAJdpKVIzTFMwbilEajqgtODL=='SEARCH_ALL':
   XeCckmAJdpKVIzTFMwbilEajqgtODo=XeCckmAJdpKVIzTFMwbilEajqgtOHN.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif XeCckmAJdpKVIzTFMwbilEajqgtODL=='SEARCH_ONE':
   XeCckmAJdpKVIzTFMwbilEajqgtODo=XeCckmAJdpKVIzTFMwbilEajqgtOHN.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif XeCckmAJdpKVIzTFMwbilEajqgtODL=='WATCH_ALL':
   XeCckmAJdpKVIzTFMwbilEajqgtODo=XeCckmAJdpKVIzTFMwbilEajqgtOHN.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif XeCckmAJdpKVIzTFMwbilEajqgtODL=='WATCH_ONE':
   XeCckmAJdpKVIzTFMwbilEajqgtODo=XeCckmAJdpKVIzTFMwbilEajqgtOHN.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if XeCckmAJdpKVIzTFMwbilEajqgtODo==XeCckmAJdpKVIzTFMwbilEajqgtOuB:sys.exit()
  if XeCckmAJdpKVIzTFMwbilEajqgtODL=='SEARCH_ALL':
   if os.path.isfile(XeCckmAJdpKVIzTFMwbilEajqgtOHS):os.remove(XeCckmAJdpKVIzTFMwbilEajqgtOHS)
  elif XeCckmAJdpKVIzTFMwbilEajqgtODL=='SEARCH_ONE':
   try:
    XeCckmAJdpKVIzTFMwbilEajqgtODU=XeCckmAJdpKVIzTFMwbilEajqgtOHS
    XeCckmAJdpKVIzTFMwbilEajqgtODB=XeCckmAJdpKVIzTFMwbilEajqgtOHu.Load_List_File('search') 
    fp=XeCckmAJdpKVIzTFMwbilEajqgtOun(XeCckmAJdpKVIzTFMwbilEajqgtODU,'w',-1,'utf-8')
    for XeCckmAJdpKVIzTFMwbilEajqgtODY in XeCckmAJdpKVIzTFMwbilEajqgtODB:
     XeCckmAJdpKVIzTFMwbilEajqgtODN=XeCckmAJdpKVIzTFMwbilEajqgtOuW(urllib.parse.parse_qsl(XeCckmAJdpKVIzTFMwbilEajqgtODY))
     XeCckmAJdpKVIzTFMwbilEajqgtODs=XeCckmAJdpKVIzTFMwbilEajqgtODN.get('skey').strip()
     if XeCckmAJdpKVIzTFMwbilEajqgtODx!=XeCckmAJdpKVIzTFMwbilEajqgtODs:
      fp.write(XeCckmAJdpKVIzTFMwbilEajqgtODY)
    fp.close()
   except:
    XeCckmAJdpKVIzTFMwbilEajqgtOuy
  elif XeCckmAJdpKVIzTFMwbilEajqgtODL=='WATCH_ALL':
   XeCckmAJdpKVIzTFMwbilEajqgtODU=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%XeCckmAJdpKVIzTFMwbilEajqgtODR))
   if os.path.isfile(XeCckmAJdpKVIzTFMwbilEajqgtODU):os.remove(XeCckmAJdpKVIzTFMwbilEajqgtODU)
  elif XeCckmAJdpKVIzTFMwbilEajqgtODL=='WATCH_ONE':
   XeCckmAJdpKVIzTFMwbilEajqgtODU=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%XeCckmAJdpKVIzTFMwbilEajqgtODR))
   try:
    XeCckmAJdpKVIzTFMwbilEajqgtODB=XeCckmAJdpKVIzTFMwbilEajqgtOHu.Load_List_File(XeCckmAJdpKVIzTFMwbilEajqgtODR) 
    fp=XeCckmAJdpKVIzTFMwbilEajqgtOun(XeCckmAJdpKVIzTFMwbilEajqgtODU,'w',-1,'utf-8')
    for XeCckmAJdpKVIzTFMwbilEajqgtODY in XeCckmAJdpKVIzTFMwbilEajqgtODB:
     XeCckmAJdpKVIzTFMwbilEajqgtODN=XeCckmAJdpKVIzTFMwbilEajqgtOuW(urllib.parse.parse_qsl(XeCckmAJdpKVIzTFMwbilEajqgtODY))
     XeCckmAJdpKVIzTFMwbilEajqgtODs=XeCckmAJdpKVIzTFMwbilEajqgtODN.get('code').strip()
     if XeCckmAJdpKVIzTFMwbilEajqgtODx!=XeCckmAJdpKVIzTFMwbilEajqgtODs:
      fp.write(XeCckmAJdpKVIzTFMwbilEajqgtODY)
    fp.close()
   except:
    XeCckmAJdpKVIzTFMwbilEajqgtOuy
  xbmc.executebuiltin("Container.Refresh")
 def Save_Searched_List(XeCckmAJdpKVIzTFMwbilEajqgtOHu,XeCckmAJdpKVIzTFMwbilEajqgtOGo):
  try:
   XeCckmAJdpKVIzTFMwbilEajqgtODf=XeCckmAJdpKVIzTFMwbilEajqgtOHS
   XeCckmAJdpKVIzTFMwbilEajqgtODB=XeCckmAJdpKVIzTFMwbilEajqgtOHu.Load_List_File('search') 
   XeCckmAJdpKVIzTFMwbilEajqgtODP={'skey':XeCckmAJdpKVIzTFMwbilEajqgtOGo.strip()}
   fp=XeCckmAJdpKVIzTFMwbilEajqgtOun(XeCckmAJdpKVIzTFMwbilEajqgtODf,'w',-1,'utf-8')
   XeCckmAJdpKVIzTFMwbilEajqgtODr=urllib.parse.urlencode(XeCckmAJdpKVIzTFMwbilEajqgtODP)
   XeCckmAJdpKVIzTFMwbilEajqgtODr=XeCckmAJdpKVIzTFMwbilEajqgtODr+'\n'
   fp.write(XeCckmAJdpKVIzTFMwbilEajqgtODr)
   XeCckmAJdpKVIzTFMwbilEajqgtODW=0
   for XeCckmAJdpKVIzTFMwbilEajqgtODY in XeCckmAJdpKVIzTFMwbilEajqgtODB:
    XeCckmAJdpKVIzTFMwbilEajqgtODN=XeCckmAJdpKVIzTFMwbilEajqgtOuW(urllib.parse.parse_qsl(XeCckmAJdpKVIzTFMwbilEajqgtODY))
    XeCckmAJdpKVIzTFMwbilEajqgtODQ=XeCckmAJdpKVIzTFMwbilEajqgtODP.get('skey').strip()
    XeCckmAJdpKVIzTFMwbilEajqgtODn=XeCckmAJdpKVIzTFMwbilEajqgtODN.get('skey').strip()
    if XeCckmAJdpKVIzTFMwbilEajqgtODQ!=XeCckmAJdpKVIzTFMwbilEajqgtODn:
     fp.write(XeCckmAJdpKVIzTFMwbilEajqgtODY)
     XeCckmAJdpKVIzTFMwbilEajqgtODW+=1
     if XeCckmAJdpKVIzTFMwbilEajqgtODW>=50:break
   fp.close()
  except:
   XeCckmAJdpKVIzTFMwbilEajqgtOuy
 def dp_Global_Search(XeCckmAJdpKVIzTFMwbilEajqgtOHu,args):
  XeCckmAJdpKVIzTFMwbilEajqgtOGf=args.get('mode')
  if XeCckmAJdpKVIzTFMwbilEajqgtOGf=='TOTAL_SEARCH':
   XeCckmAJdpKVIzTFMwbilEajqgtODh='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   XeCckmAJdpKVIzTFMwbilEajqgtODh='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(XeCckmAJdpKVIzTFMwbilEajqgtODh)
 def dp_Bookmark_Menu(XeCckmAJdpKVIzTFMwbilEajqgtOHu,args):
  XeCckmAJdpKVIzTFMwbilEajqgtODh='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(XeCckmAJdpKVIzTFMwbilEajqgtODh)
 def login_main(XeCckmAJdpKVIzTFMwbilEajqgtOHu):
  (XeCckmAJdpKVIzTFMwbilEajqgtOyH,XeCckmAJdpKVIzTFMwbilEajqgtOyG,XeCckmAJdpKVIzTFMwbilEajqgtOyv)=XeCckmAJdpKVIzTFMwbilEajqgtOHu.get_settings_account()
  if not(XeCckmAJdpKVIzTFMwbilEajqgtOyH and XeCckmAJdpKVIzTFMwbilEajqgtOyG):
   XeCckmAJdpKVIzTFMwbilEajqgtOHN=xbmcgui.Dialog()
   XeCckmAJdpKVIzTFMwbilEajqgtODo=XeCckmAJdpKVIzTFMwbilEajqgtOHN.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if XeCckmAJdpKVIzTFMwbilEajqgtODo==XeCckmAJdpKVIzTFMwbilEajqgtOuS:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if XeCckmAJdpKVIzTFMwbilEajqgtOHu.cookiefile_check()==XeCckmAJdpKVIzTFMwbilEajqgtOuS:return
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   XeCckmAJdpKVIzTFMwbilEajqgtOyD=0
   while XeCckmAJdpKVIzTFMwbilEajqgtOuS:
    XeCckmAJdpKVIzTFMwbilEajqgtOyD+=1
    time.sleep(0.05)
    if XeCckmAJdpKVIzTFMwbilEajqgtOyD>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  XeCckmAJdpKVIzTFMwbilEajqgtOyU=XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.GetCredential(XeCckmAJdpKVIzTFMwbilEajqgtOyH,XeCckmAJdpKVIzTFMwbilEajqgtOyG,XeCckmAJdpKVIzTFMwbilEajqgtOyv)
  if XeCckmAJdpKVIzTFMwbilEajqgtOyU:XeCckmAJdpKVIzTFMwbilEajqgtOHu.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
  if XeCckmAJdpKVIzTFMwbilEajqgtOyU==XeCckmAJdpKVIzTFMwbilEajqgtOuB:
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_setEpOrderby(XeCckmAJdpKVIzTFMwbilEajqgtOHu,args):
  XeCckmAJdpKVIzTFMwbilEajqgtOGu =args.get('orderby')
  XeCckmAJdpKVIzTFMwbilEajqgtOHu.set_winEpisodeOrderby(XeCckmAJdpKVIzTFMwbilEajqgtOGu)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(XeCckmAJdpKVIzTFMwbilEajqgtOHu,args):
  XeCckmAJdpKVIzTFMwbilEajqgtOGf =args.get('mode')
  XeCckmAJdpKVIzTFMwbilEajqgtOyS =args.get('contentid')
  XeCckmAJdpKVIzTFMwbilEajqgtOyu =args.get('pvrmode')
  XeCckmAJdpKVIzTFMwbilEajqgtOyB=XeCckmAJdpKVIzTFMwbilEajqgtOHu.get_selQuality()
  XeCckmAJdpKVIzTFMwbilEajqgtOGv =XeCckmAJdpKVIzTFMwbilEajqgtOHu.get_settings_play()
  XeCckmAJdpKVIzTFMwbilEajqgtOHu.addon_log(XeCckmAJdpKVIzTFMwbilEajqgtOyS+' - '+XeCckmAJdpKVIzTFMwbilEajqgtOGf)
  if XeCckmAJdpKVIzTFMwbilEajqgtOGf=='SPORTS':
   XeCckmAJdpKVIzTFMwbilEajqgtOyr=XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.GetSportsURL(XeCckmAJdpKVIzTFMwbilEajqgtOyS,XeCckmAJdpKVIzTFMwbilEajqgtOyB)
  else:
   XeCckmAJdpKVIzTFMwbilEajqgtOyr=XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.GetStreamingURL(XeCckmAJdpKVIzTFMwbilEajqgtOGf,XeCckmAJdpKVIzTFMwbilEajqgtOyS,XeCckmAJdpKVIzTFMwbilEajqgtOyB,XeCckmAJdpKVIzTFMwbilEajqgtOyu,playOption=XeCckmAJdpKVIzTFMwbilEajqgtOGv)
  XeCckmAJdpKVIzTFMwbilEajqgtOyW=XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.WV['cookies']['credential']
  XeCckmAJdpKVIzTFMwbilEajqgtOyY=XeCckmAJdpKVIzTFMwbilEajqgtOyr['stream_cookie']
  XeCckmAJdpKVIzTFMwbilEajqgtOyN='{}|Cookie={}'.format(XeCckmAJdpKVIzTFMwbilEajqgtOyr['stream_url'],XeCckmAJdpKVIzTFMwbilEajqgtOyY)
  XeCckmAJdpKVIzTFMwbilEajqgtOHu.addon_log(XeCckmAJdpKVIzTFMwbilEajqgtOyN)
  if XeCckmAJdpKVIzTFMwbilEajqgtOyr['stream_url']=='':
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.addon_noti(__language__(30907).encode('utf8'))
   return
  XeCckmAJdpKVIzTFMwbilEajqgtOyQ=xbmcgui.ListItem(path=XeCckmAJdpKVIzTFMwbilEajqgtOyN)
  if XeCckmAJdpKVIzTFMwbilEajqgtOyr['stream_drm']:
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.addon_log('!!streaming_drm!!')
   XeCckmAJdpKVIzTFMwbilEajqgtOyn=XeCckmAJdpKVIzTFMwbilEajqgtOyr['stream_drm']['customdata']
   XeCckmAJdpKVIzTFMwbilEajqgtOyL =XeCckmAJdpKVIzTFMwbilEajqgtOyr['stream_drm']['drmhost']
   XeCckmAJdpKVIzTFMwbilEajqgtOyx =inputstreamhelper.Helper('mpd',drm='widevine')
   if XeCckmAJdpKVIzTFMwbilEajqgtOyx.check_inputstream():
    if XeCckmAJdpKVIzTFMwbilEajqgtOGf=='MOVIE':
     XeCckmAJdpKVIzTFMwbilEajqgtOyR='https://www.wavve.com/player/movie?movieid=%s'%XeCckmAJdpKVIzTFMwbilEajqgtOyS
    else:
     XeCckmAJdpKVIzTFMwbilEajqgtOyR='https://www.wavve.com/player/vod?programid=%s&page=1'%XeCckmAJdpKVIzTFMwbilEajqgtOyS
    XeCckmAJdpKVIzTFMwbilEajqgtOyo={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':XeCckmAJdpKVIzTFMwbilEajqgtOyn,'referer':XeCckmAJdpKVIzTFMwbilEajqgtOyR,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.USER_AGENT,}
    XeCckmAJdpKVIzTFMwbilEajqgtOys=XeCckmAJdpKVIzTFMwbilEajqgtOyL+'|'+urllib.parse.urlencode(XeCckmAJdpKVIzTFMwbilEajqgtOyo)+'|R{SSM}|'
    XeCckmAJdpKVIzTFMwbilEajqgtOyQ.setProperty('inputstream',XeCckmAJdpKVIzTFMwbilEajqgtOyx.inputstream_addon)
    XeCckmAJdpKVIzTFMwbilEajqgtOyQ.setProperty('inputstream.adaptive.manifest_type','mpd')
    XeCckmAJdpKVIzTFMwbilEajqgtOyQ.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    XeCckmAJdpKVIzTFMwbilEajqgtOyQ.setProperty('inputstream.adaptive.license_key',XeCckmAJdpKVIzTFMwbilEajqgtOys)
    XeCckmAJdpKVIzTFMwbilEajqgtOyQ.setProperty('inputstream.adaptive.stream_headers','user-agent={}&Cookie={}'.format(XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.USER_AGENT,XeCckmAJdpKVIzTFMwbilEajqgtOyY))
  elif XeCckmAJdpKVIzTFMwbilEajqgtOGf in['VOD','MOVIE']:
   XeCckmAJdpKVIzTFMwbilEajqgtOyQ.setContentLookup(XeCckmAJdpKVIzTFMwbilEajqgtOuB)
   XeCckmAJdpKVIzTFMwbilEajqgtOyQ.setMimeType('application/x-mpegURL')
   XeCckmAJdpKVIzTFMwbilEajqgtOyQ.setProperty('inputstream','inputstream.adaptive')
   XeCckmAJdpKVIzTFMwbilEajqgtOyQ.setProperty('inputstream.adaptive.manifest_type','hls')
   XeCckmAJdpKVIzTFMwbilEajqgtOyQ.setProperty('inputstream.adaptive.stream_headers','user-agent={}&Cookie={}'.format(XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.USER_AGENT,XeCckmAJdpKVIzTFMwbilEajqgtOyY))
  if XeCckmAJdpKVIzTFMwbilEajqgtOyr['stream_vtt']:
   XeCckmAJdpKVIzTFMwbilEajqgtOyQ.setSubtitles([XeCckmAJdpKVIzTFMwbilEajqgtOyr['stream_vtt']])
  xbmcplugin.setResolvedUrl(XeCckmAJdpKVIzTFMwbilEajqgtOHu._addon_handle,XeCckmAJdpKVIzTFMwbilEajqgtOuS,XeCckmAJdpKVIzTFMwbilEajqgtOyQ)
  XeCckmAJdpKVIzTFMwbilEajqgtOyf=XeCckmAJdpKVIzTFMwbilEajqgtOuB
  if XeCckmAJdpKVIzTFMwbilEajqgtOyr['stream_preview']:
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.addon_noti(XeCckmAJdpKVIzTFMwbilEajqgtOyr['stream_preview'].encode('utf-8'))
   XeCckmAJdpKVIzTFMwbilEajqgtOyf=XeCckmAJdpKVIzTFMwbilEajqgtOuS
  else:
   if '/preview.' in urllib.parse.urlsplit(XeCckmAJdpKVIzTFMwbilEajqgtOyr['stream_url']).path:
    XeCckmAJdpKVIzTFMwbilEajqgtOHu.addon_noti(__language__(30908).encode('utf8'))
    XeCckmAJdpKVIzTFMwbilEajqgtOyf=XeCckmAJdpKVIzTFMwbilEajqgtOuS
  try:
   XeCckmAJdpKVIzTFMwbilEajqgtOyP=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and XeCckmAJdpKVIzTFMwbilEajqgtOyf==XeCckmAJdpKVIzTFMwbilEajqgtOuB and XeCckmAJdpKVIzTFMwbilEajqgtOyP!='-':
    XeCckmAJdpKVIzTFMwbilEajqgtOGQ={'code':XeCckmAJdpKVIzTFMwbilEajqgtOyP,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    XeCckmAJdpKVIzTFMwbilEajqgtOHu.Save_Watched_List(args.get('mode').lower(),XeCckmAJdpKVIzTFMwbilEajqgtOGQ)
  except:
   XeCckmAJdpKVIzTFMwbilEajqgtOuy
 def logout(XeCckmAJdpKVIzTFMwbilEajqgtOHu):
  XeCckmAJdpKVIzTFMwbilEajqgtOHN=xbmcgui.Dialog()
  XeCckmAJdpKVIzTFMwbilEajqgtODo=XeCckmAJdpKVIzTFMwbilEajqgtOHN.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if XeCckmAJdpKVIzTFMwbilEajqgtODo==XeCckmAJdpKVIzTFMwbilEajqgtOuB:sys.exit()
  XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.Init_WV_Total()
  if os.path.isfile(XeCckmAJdpKVIzTFMwbilEajqgtOHU):os.remove(XeCckmAJdpKVIzTFMwbilEajqgtOHU)
  XeCckmAJdpKVIzTFMwbilEajqgtOHu.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(XeCckmAJdpKVIzTFMwbilEajqgtOHu):
  XeCckmAJdpKVIzTFMwbilEajqgtOyh =XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.Get_Now_Datetime()
  XeCckmAJdpKVIzTFMwbilEajqgtOUH=XeCckmAJdpKVIzTFMwbilEajqgtOyh+datetime.timedelta(days=XeCckmAJdpKVIzTFMwbilEajqgtOuU(__addon__.getSetting('cache_ttl')))
  (XeCckmAJdpKVIzTFMwbilEajqgtOyH,XeCckmAJdpKVIzTFMwbilEajqgtOyG,XeCckmAJdpKVIzTFMwbilEajqgtOyv)=XeCckmAJdpKVIzTFMwbilEajqgtOHu.get_settings_account()
  XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.Save_session_acount(XeCckmAJdpKVIzTFMwbilEajqgtOyH,XeCckmAJdpKVIzTFMwbilEajqgtOyG,XeCckmAJdpKVIzTFMwbilEajqgtOyv)
  XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.WV['account']['token_limit']=XeCckmAJdpKVIzTFMwbilEajqgtOUH.strftime('%Y%m%d')
  XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.JsonFile_Save(XeCckmAJdpKVIzTFMwbilEajqgtOHU,XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.WV)
 def cookiefile_check(XeCckmAJdpKVIzTFMwbilEajqgtOHu):
  XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.WV=XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.JsonFile_Load(XeCckmAJdpKVIzTFMwbilEajqgtOHU)
  if 'account' not in XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.WV:
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.Init_WV_Total()
   return XeCckmAJdpKVIzTFMwbilEajqgtOuB
  if 'uuid' not in XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.WV.get('cookies'):
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.Init_WV_Total()
   return XeCckmAJdpKVIzTFMwbilEajqgtOuB
  (XeCckmAJdpKVIzTFMwbilEajqgtOUG,XeCckmAJdpKVIzTFMwbilEajqgtOUv,XeCckmAJdpKVIzTFMwbilEajqgtOUD)=XeCckmAJdpKVIzTFMwbilEajqgtOHu.get_settings_account()
  (XeCckmAJdpKVIzTFMwbilEajqgtOUy,XeCckmAJdpKVIzTFMwbilEajqgtOUS,XeCckmAJdpKVIzTFMwbilEajqgtOUu)=XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.Load_session_acount()
  if XeCckmAJdpKVIzTFMwbilEajqgtOUG!=XeCckmAJdpKVIzTFMwbilEajqgtOUy or XeCckmAJdpKVIzTFMwbilEajqgtOUv!=XeCckmAJdpKVIzTFMwbilEajqgtOUS or XeCckmAJdpKVIzTFMwbilEajqgtOUD!=XeCckmAJdpKVIzTFMwbilEajqgtOUu:
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.Init_WV_Total()
   return XeCckmAJdpKVIzTFMwbilEajqgtOuB
  if XeCckmAJdpKVIzTFMwbilEajqgtOuU(XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))>XeCckmAJdpKVIzTFMwbilEajqgtOuU(XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.WV['account']['token_limit']):
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.Init_WV_Total()
   return XeCckmAJdpKVIzTFMwbilEajqgtOuB
  return XeCckmAJdpKVIzTFMwbilEajqgtOuS
 def dp_LiveCatagory_List(XeCckmAJdpKVIzTFMwbilEajqgtOHu,args):
  XeCckmAJdpKVIzTFMwbilEajqgtOUB =args.get('sCode')
  XeCckmAJdpKVIzTFMwbilEajqgtOUr=args.get('sIndex')
  XeCckmAJdpKVIzTFMwbilEajqgtOvL,XeCckmAJdpKVIzTFMwbilEajqgtOUW=XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.Get_LiveCatagory_List(XeCckmAJdpKVIzTFMwbilEajqgtOUB,XeCckmAJdpKVIzTFMwbilEajqgtOUr)
  for XeCckmAJdpKVIzTFMwbilEajqgtOvx in XeCckmAJdpKVIzTFMwbilEajqgtOvL:
   XeCckmAJdpKVIzTFMwbilEajqgtOGr =XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('title')
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ={'mode':'LIVE_LIST','genre':XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('genre'),'baseapi':XeCckmAJdpKVIzTFMwbilEajqgtOUW}
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.add_dir(XeCckmAJdpKVIzTFMwbilEajqgtOGr,sublabel='',img='',infoLabels=XeCckmAJdpKVIzTFMwbilEajqgtOuy,isFolder=XeCckmAJdpKVIzTFMwbilEajqgtOuS,params=XeCckmAJdpKVIzTFMwbilEajqgtOGQ)
  if XeCckmAJdpKVIzTFMwbilEajqgtOuY(XeCckmAJdpKVIzTFMwbilEajqgtOvL)>0:xbmcplugin.endOfDirectory(XeCckmAJdpKVIzTFMwbilEajqgtOHu._addon_handle,cacheToDisc=XeCckmAJdpKVIzTFMwbilEajqgtOuB)
 def dp_MainCatagory_List(XeCckmAJdpKVIzTFMwbilEajqgtOHu,args):
  XeCckmAJdpKVIzTFMwbilEajqgtOUB =args.get('sCode')
  XeCckmAJdpKVIzTFMwbilEajqgtOUr=args.get('sIndex')
  XeCckmAJdpKVIzTFMwbilEajqgtOGP =args.get('sType')
  XeCckmAJdpKVIzTFMwbilEajqgtOvL=XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.Get_MainCatagory_List(XeCckmAJdpKVIzTFMwbilEajqgtOUB,XeCckmAJdpKVIzTFMwbilEajqgtOUr)
  for XeCckmAJdpKVIzTFMwbilEajqgtOvx in XeCckmAJdpKVIzTFMwbilEajqgtOvL:
   if XeCckmAJdpKVIzTFMwbilEajqgtOGP=='vod':
    if XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('subtype')=='catagory':
     XeCckmAJdpKVIzTFMwbilEajqgtOGf='PROGRAM_LIST'
    else:
     XeCckmAJdpKVIzTFMwbilEajqgtOGf='SUPERSECTION_LIST'
   elif XeCckmAJdpKVIzTFMwbilEajqgtOGP=='movie':
    XeCckmAJdpKVIzTFMwbilEajqgtOGf='MOVIE_LIST'
   else:
    XeCckmAJdpKVIzTFMwbilEajqgtOGf=''
   XeCckmAJdpKVIzTFMwbilEajqgtOGr='%s (%s)'%(XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('title'),args.get('ordernm'))
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ={'mode':XeCckmAJdpKVIzTFMwbilEajqgtOGf,'suburl':XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('suburl'),'subapi':XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if XeCckmAJdpKVIzTFMwbilEajqgtOHu.get_settings_exclusion21():
    if XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('title')=='성인' or XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('title')=='성인+' or XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('title')=='에로티시즘' or XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('title')=='19':continue
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.add_dir(XeCckmAJdpKVIzTFMwbilEajqgtOGr,sublabel='',img='',infoLabels=XeCckmAJdpKVIzTFMwbilEajqgtOuy,isFolder=XeCckmAJdpKVIzTFMwbilEajqgtOuS,params=XeCckmAJdpKVIzTFMwbilEajqgtOGQ)
  if XeCckmAJdpKVIzTFMwbilEajqgtOuY(XeCckmAJdpKVIzTFMwbilEajqgtOvL)>0:xbmcplugin.endOfDirectory(XeCckmAJdpKVIzTFMwbilEajqgtOHu._addon_handle,cacheToDisc=XeCckmAJdpKVIzTFMwbilEajqgtOuB)
 def dp_Program_List(XeCckmAJdpKVIzTFMwbilEajqgtOHu,args):
  XeCckmAJdpKVIzTFMwbilEajqgtOUY =args.get('subapi')
  XeCckmAJdpKVIzTFMwbilEajqgtOvn=XeCckmAJdpKVIzTFMwbilEajqgtOuU(args.get('page'))
  XeCckmAJdpKVIzTFMwbilEajqgtOGu =args.get('orderby')
  XeCckmAJdpKVIzTFMwbilEajqgtOvL,XeCckmAJdpKVIzTFMwbilEajqgtOvH=XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.Get_Program_List(XeCckmAJdpKVIzTFMwbilEajqgtOUY,XeCckmAJdpKVIzTFMwbilEajqgtOvn,XeCckmAJdpKVIzTFMwbilEajqgtOGu)
  for XeCckmAJdpKVIzTFMwbilEajqgtOvx in XeCckmAJdpKVIzTFMwbilEajqgtOvL:
   XeCckmAJdpKVIzTFMwbilEajqgtOvR =XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('videoid')
   XeCckmAJdpKVIzTFMwbilEajqgtOvo =XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('vidtype')
   XeCckmAJdpKVIzTFMwbilEajqgtOGr =XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('title')
   XeCckmAJdpKVIzTFMwbilEajqgtOvs=XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('thumbnail')
   XeCckmAJdpKVIzTFMwbilEajqgtOvf =XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('age')
   if XeCckmAJdpKVIzTFMwbilEajqgtOvf=='18' or XeCckmAJdpKVIzTFMwbilEajqgtOvf=='19' or XeCckmAJdpKVIzTFMwbilEajqgtOvf=='21':XeCckmAJdpKVIzTFMwbilEajqgtOGr+=' (%s)'%(XeCckmAJdpKVIzTFMwbilEajqgtOvf)
   XeCckmAJdpKVIzTFMwbilEajqgtOvQ={'plot':XeCckmAJdpKVIzTFMwbilEajqgtOGr,'mpaa':XeCckmAJdpKVIzTFMwbilEajqgtOvf,'mediatype':'tvshow',}
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ={'mode':'SEASON_LIST','videoid':XeCckmAJdpKVIzTFMwbilEajqgtOvR,'vidtype':XeCckmAJdpKVIzTFMwbilEajqgtOvo,}
   XeCckmAJdpKVIzTFMwbilEajqgtOvN=[]
   XeCckmAJdpKVIzTFMwbilEajqgtOvP={'mode':'VIEW_DETAIL','values':{'videoid':XeCckmAJdpKVIzTFMwbilEajqgtOvR,'vidtype':'tvshow','contenttype':XeCckmAJdpKVIzTFMwbilEajqgtOvo,}}
   XeCckmAJdpKVIzTFMwbilEajqgtOvh=json.dumps(XeCckmAJdpKVIzTFMwbilEajqgtOvP,separators=(',',':'))
   XeCckmAJdpKVIzTFMwbilEajqgtOvh=base64.standard_b64encode(XeCckmAJdpKVIzTFMwbilEajqgtOvh.encode()).decode('utf-8')
   XeCckmAJdpKVIzTFMwbilEajqgtOvh=XeCckmAJdpKVIzTFMwbilEajqgtOvh.replace('+','%2B')
   XeCckmAJdpKVIzTFMwbilEajqgtODH='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(XeCckmAJdpKVIzTFMwbilEajqgtOvh)
   XeCckmAJdpKVIzTFMwbilEajqgtOvN.append(('상세정보 조회',XeCckmAJdpKVIzTFMwbilEajqgtODH))
   if XeCckmAJdpKVIzTFMwbilEajqgtOHu.get_settings_makebookmark():
    XeCckmAJdpKVIzTFMwbilEajqgtOvP={'videoid':XeCckmAJdpKVIzTFMwbilEajqgtOvR,'vidtype':'tvshow','vtitle':XeCckmAJdpKVIzTFMwbilEajqgtOGr,'vsubtitle':'','contenttype':XeCckmAJdpKVIzTFMwbilEajqgtOvo,}
    XeCckmAJdpKVIzTFMwbilEajqgtODG=json.dumps(XeCckmAJdpKVIzTFMwbilEajqgtOvP)
    XeCckmAJdpKVIzTFMwbilEajqgtODG=urllib.parse.quote(XeCckmAJdpKVIzTFMwbilEajqgtODG)
    XeCckmAJdpKVIzTFMwbilEajqgtODH='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(XeCckmAJdpKVIzTFMwbilEajqgtODG)
    XeCckmAJdpKVIzTFMwbilEajqgtOvN.append(('(통합) 찜 영상에 추가',XeCckmAJdpKVIzTFMwbilEajqgtODH))
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.add_dir(XeCckmAJdpKVIzTFMwbilEajqgtOGr,sublabel='',img=XeCckmAJdpKVIzTFMwbilEajqgtOvs,infoLabels=XeCckmAJdpKVIzTFMwbilEajqgtOvQ,isFolder=XeCckmAJdpKVIzTFMwbilEajqgtOuS,params=XeCckmAJdpKVIzTFMwbilEajqgtOGQ,ContextMenu=XeCckmAJdpKVIzTFMwbilEajqgtOvN)
  if XeCckmAJdpKVIzTFMwbilEajqgtOvH:
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ={}
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ['mode'] ='PROGRAM_LIST' 
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ['subapi']=XeCckmAJdpKVIzTFMwbilEajqgtOUY 
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ['page'] =XeCckmAJdpKVIzTFMwbilEajqgtOuQ(XeCckmAJdpKVIzTFMwbilEajqgtOvn+1)
   XeCckmAJdpKVIzTFMwbilEajqgtOGr='[B]%s >>[/B]'%'다음 페이지'
   XeCckmAJdpKVIzTFMwbilEajqgtODv=XeCckmAJdpKVIzTFMwbilEajqgtOuQ(XeCckmAJdpKVIzTFMwbilEajqgtOvn+1)
   XeCckmAJdpKVIzTFMwbilEajqgtOGN=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.add_dir(XeCckmAJdpKVIzTFMwbilEajqgtOGr,sublabel=XeCckmAJdpKVIzTFMwbilEajqgtODv,img=XeCckmAJdpKVIzTFMwbilEajqgtOGN,infoLabels=XeCckmAJdpKVIzTFMwbilEajqgtOuy,isFolder=XeCckmAJdpKVIzTFMwbilEajqgtOuS,params=XeCckmAJdpKVIzTFMwbilEajqgtOGQ)
  xbmcplugin.setContent(XeCckmAJdpKVIzTFMwbilEajqgtOHu._addon_handle,'tvshows')
  if XeCckmAJdpKVIzTFMwbilEajqgtOuY(XeCckmAJdpKVIzTFMwbilEajqgtOvL)>0:xbmcplugin.endOfDirectory(XeCckmAJdpKVIzTFMwbilEajqgtOHu._addon_handle,cacheToDisc=XeCckmAJdpKVIzTFMwbilEajqgtOuB)
 def dp_Season_List(XeCckmAJdpKVIzTFMwbilEajqgtOHu,args):
  XeCckmAJdpKVIzTFMwbilEajqgtOvR=args.get('videoid')
  XeCckmAJdpKVIzTFMwbilEajqgtOvo=args.get('vidtype')
  if XeCckmAJdpKVIzTFMwbilEajqgtOvo=='contentid':
   XeCckmAJdpKVIzTFMwbilEajqgtOyS=XeCckmAJdpKVIzTFMwbilEajqgtOvR
   XeCckmAJdpKVIzTFMwbilEajqgtOUN =XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.ContentidToSeasonid(XeCckmAJdpKVIzTFMwbilEajqgtOvR)
  else:
   XeCckmAJdpKVIzTFMwbilEajqgtOyS=XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.ProgramidToContentid(XeCckmAJdpKVIzTFMwbilEajqgtOvR)
   XeCckmAJdpKVIzTFMwbilEajqgtOUN =XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.ContentidToSeasonid(XeCckmAJdpKVIzTFMwbilEajqgtOyS)
  XeCckmAJdpKVIzTFMwbilEajqgtOUQ=XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.Get_Season_List(XeCckmAJdpKVIzTFMwbilEajqgtOUN)
  if XeCckmAJdpKVIzTFMwbilEajqgtOuY(XeCckmAJdpKVIzTFMwbilEajqgtOUQ)>1:
   for XeCckmAJdpKVIzTFMwbilEajqgtOUn in XeCckmAJdpKVIzTFMwbilEajqgtOUQ:
    XeCckmAJdpKVIzTFMwbilEajqgtOUL=XeCckmAJdpKVIzTFMwbilEajqgtOUn.get('season_Id')
    XeCckmAJdpKVIzTFMwbilEajqgtOUx=XeCckmAJdpKVIzTFMwbilEajqgtOUn.get('season_Nm')
    XeCckmAJdpKVIzTFMwbilEajqgtOUR=XeCckmAJdpKVIzTFMwbilEajqgtOUn.get('programNm')
    XeCckmAJdpKVIzTFMwbilEajqgtOvs=XeCckmAJdpKVIzTFMwbilEajqgtOUn.get('thumbnail')
    XeCckmAJdpKVIzTFMwbilEajqgtOUo =XeCckmAJdpKVIzTFMwbilEajqgtOUn.get('synopsis')
    XeCckmAJdpKVIzTFMwbilEajqgtOvQ={'mediatype':'tvshow','title':XeCckmAJdpKVIzTFMwbilEajqgtOUx,'plot':XeCckmAJdpKVIzTFMwbilEajqgtOUo,}
    XeCckmAJdpKVIzTFMwbilEajqgtOGQ={'mode':'EPISODE_LIST','seasonid':XeCckmAJdpKVIzTFMwbilEajqgtOUL,'page':'1',}
    XeCckmAJdpKVIzTFMwbilEajqgtOHu.add_dir(XeCckmAJdpKVIzTFMwbilEajqgtOUx,sublabel=XeCckmAJdpKVIzTFMwbilEajqgtOUR,img=XeCckmAJdpKVIzTFMwbilEajqgtOvs,infoLabels=XeCckmAJdpKVIzTFMwbilEajqgtOvQ,isFolder=XeCckmAJdpKVIzTFMwbilEajqgtOuS,params=XeCckmAJdpKVIzTFMwbilEajqgtOGQ,ContextMenu=XeCckmAJdpKVIzTFMwbilEajqgtOuy)
   xbmcplugin.setContent(XeCckmAJdpKVIzTFMwbilEajqgtOHu._addon_handle,'seasons')
   xbmcplugin.endOfDirectory(XeCckmAJdpKVIzTFMwbilEajqgtOHu._addon_handle,cacheToDisc=XeCckmAJdpKVIzTFMwbilEajqgtOuB)
  else:
   XeCckmAJdpKVIzTFMwbilEajqgtOUs={'seasonid':XeCckmAJdpKVIzTFMwbilEajqgtOUN,'page':'1',}
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.dp_Episode_List(XeCckmAJdpKVIzTFMwbilEajqgtOUs)
 def dp_Episode_List(XeCckmAJdpKVIzTFMwbilEajqgtOHu,args):
  XeCckmAJdpKVIzTFMwbilEajqgtOUN =args.get('seasonid')
  XeCckmAJdpKVIzTFMwbilEajqgtOvn =XeCckmAJdpKVIzTFMwbilEajqgtOuU(args.get('page'))
  XeCckmAJdpKVIzTFMwbilEajqgtOvL,XeCckmAJdpKVIzTFMwbilEajqgtOvH=XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.Get_Episode_List(XeCckmAJdpKVIzTFMwbilEajqgtOUN,XeCckmAJdpKVIzTFMwbilEajqgtOvn,orderby=XeCckmAJdpKVIzTFMwbilEajqgtOHu.get_winEpisodeOrderby())
  for XeCckmAJdpKVIzTFMwbilEajqgtOvx in XeCckmAJdpKVIzTFMwbilEajqgtOvL:
   XeCckmAJdpKVIzTFMwbilEajqgtODv=XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('episodenumber')
   XeCckmAJdpKVIzTFMwbilEajqgtOUf ='[%s]\n\n%s'%(XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('episodetitle'),XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('synopsis'))
   XeCckmAJdpKVIzTFMwbilEajqgtOvQ={'mediatype':'episode','title':XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('programtitle'),'plot':XeCckmAJdpKVIzTFMwbilEajqgtOUf,'cast':XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('episodeactors'),}
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ={'mode':'VOD','programid':XeCckmAJdpKVIzTFMwbilEajqgtOUN,'contentid':XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('contentid'),'thumbnail':XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('thumbnail'),'title':XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('programtitle'),'subtitle':XeCckmAJdpKVIzTFMwbilEajqgtODv,}
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.add_dir(XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('programtitle'),sublabel=XeCckmAJdpKVIzTFMwbilEajqgtODv,img=XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('thumbnail'),infoLabels=XeCckmAJdpKVIzTFMwbilEajqgtOvQ,isFolder=XeCckmAJdpKVIzTFMwbilEajqgtOuB,params=XeCckmAJdpKVIzTFMwbilEajqgtOGQ)
  if XeCckmAJdpKVIzTFMwbilEajqgtOvn==1:
   XeCckmAJdpKVIzTFMwbilEajqgtOvQ={'plot':'정렬순서를 변경합니다.'}
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ={}
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ['mode'] ='ORDER_BY' 
   if XeCckmAJdpKVIzTFMwbilEajqgtOHu.get_winEpisodeOrderby()=='desc':
    XeCckmAJdpKVIzTFMwbilEajqgtOGr='정렬순서변경 : 최신화부터 -> 1회부터'
    XeCckmAJdpKVIzTFMwbilEajqgtOGQ['orderby']='asc'
   else:
    XeCckmAJdpKVIzTFMwbilEajqgtOGr='정렬순서변경 : 1회부터 -> 최신화부터'
    XeCckmAJdpKVIzTFMwbilEajqgtOGQ['orderby']='desc'
   XeCckmAJdpKVIzTFMwbilEajqgtOGN=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.add_dir(XeCckmAJdpKVIzTFMwbilEajqgtOGr,sublabel='',img=XeCckmAJdpKVIzTFMwbilEajqgtOGN,infoLabels=XeCckmAJdpKVIzTFMwbilEajqgtOvQ,isFolder=XeCckmAJdpKVIzTFMwbilEajqgtOuB,params=XeCckmAJdpKVIzTFMwbilEajqgtOGQ,isLink=XeCckmAJdpKVIzTFMwbilEajqgtOuS)
  if XeCckmAJdpKVIzTFMwbilEajqgtOvH:
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ={}
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ['mode'] ='EPISODE_LIST' 
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ['seasonid']=XeCckmAJdpKVIzTFMwbilEajqgtOUN
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ['page'] =XeCckmAJdpKVIzTFMwbilEajqgtOuQ(XeCckmAJdpKVIzTFMwbilEajqgtOvn+1)
   XeCckmAJdpKVIzTFMwbilEajqgtOGr='[B]%s >>[/B]'%'다음 페이지'
   XeCckmAJdpKVIzTFMwbilEajqgtODv=XeCckmAJdpKVIzTFMwbilEajqgtOuQ(XeCckmAJdpKVIzTFMwbilEajqgtOvn+1)
   XeCckmAJdpKVIzTFMwbilEajqgtOGN=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.add_dir(XeCckmAJdpKVIzTFMwbilEajqgtOGr,sublabel=XeCckmAJdpKVIzTFMwbilEajqgtODv,img=XeCckmAJdpKVIzTFMwbilEajqgtOGN,infoLabels=XeCckmAJdpKVIzTFMwbilEajqgtOuy,isFolder=XeCckmAJdpKVIzTFMwbilEajqgtOuS,params=XeCckmAJdpKVIzTFMwbilEajqgtOGQ)
  xbmcplugin.setContent(XeCckmAJdpKVIzTFMwbilEajqgtOHu._addon_handle,'episodes')
  if XeCckmAJdpKVIzTFMwbilEajqgtOuY(XeCckmAJdpKVIzTFMwbilEajqgtOvL)>0:xbmcplugin.endOfDirectory(XeCckmAJdpKVIzTFMwbilEajqgtOHu._addon_handle,cacheToDisc=XeCckmAJdpKVIzTFMwbilEajqgtOuB)
 def dp_SuperSection_List(XeCckmAJdpKVIzTFMwbilEajqgtOHu,args):
  XeCckmAJdpKVIzTFMwbilEajqgtOUP =args.get('suburl')
  XeCckmAJdpKVIzTFMwbilEajqgtOvL=XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.Get_SuperMultiSection_List(XeCckmAJdpKVIzTFMwbilEajqgtOUP)
  for XeCckmAJdpKVIzTFMwbilEajqgtOvx in XeCckmAJdpKVIzTFMwbilEajqgtOvL:
   XeCckmAJdpKVIzTFMwbilEajqgtOGr =XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('title')
   XeCckmAJdpKVIzTFMwbilEajqgtOUY =XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('subapi')
   XeCckmAJdpKVIzTFMwbilEajqgtOUh=XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('cell_type')
   if XeCckmAJdpKVIzTFMwbilEajqgtOUY.find('mtype=svod')>=0 or XeCckmAJdpKVIzTFMwbilEajqgtOUY.find('mtype=ppv')>=0 or XeCckmAJdpKVIzTFMwbilEajqgtOUY.find('contenttype=movie')>=0:
    XeCckmAJdpKVIzTFMwbilEajqgtOGf='MOVIE_LIST'
   elif XeCckmAJdpKVIzTFMwbilEajqgtOUY.find('contenttype=program')>=0:
    XeCckmAJdpKVIzTFMwbilEajqgtOGf='PROGRAM_LIST'
   elif XeCckmAJdpKVIzTFMwbilEajqgtOUh=='band_71':
    XeCckmAJdpKVIzTFMwbilEajqgtOGf ='SUPERSECTION_LIST'
    (XeCckmAJdpKVIzTFMwbilEajqgtOSH,XeCckmAJdpKVIzTFMwbilEajqgtOSG)=XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.Baseapi_Parse(XeCckmAJdpKVIzTFMwbilEajqgtOUY)
    XeCckmAJdpKVIzTFMwbilEajqgtOUP=XeCckmAJdpKVIzTFMwbilEajqgtOSG.get('api')
    XeCckmAJdpKVIzTFMwbilEajqgtOUY=''
   elif XeCckmAJdpKVIzTFMwbilEajqgtOUh=='band_2':
    XeCckmAJdpKVIzTFMwbilEajqgtOGf='BAND2SECTION_LIST'
   elif XeCckmAJdpKVIzTFMwbilEajqgtOUh=='band_live':
    XeCckmAJdpKVIzTFMwbilEajqgtOGf='BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}',XeCckmAJdpKVIzTFMwbilEajqgtOUY):
    XeCckmAJdpKVIzTFMwbilEajqgtOGf='MOVIE_LIST'
   else:
    XeCckmAJdpKVIzTFMwbilEajqgtOGf='PROGRAM_LIST'
   XeCckmAJdpKVIzTFMwbilEajqgtOvQ={'plot':XeCckmAJdpKVIzTFMwbilEajqgtOGr,'mediatype':'tvshow'}
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ={'mode':XeCckmAJdpKVIzTFMwbilEajqgtOGf,'suburl':XeCckmAJdpKVIzTFMwbilEajqgtOUP,'subapi':XeCckmAJdpKVIzTFMwbilEajqgtOUY,'page':'1'}
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.add_dir(XeCckmAJdpKVIzTFMwbilEajqgtOGr,sublabel='',img=XeCckmAJdpKVIzTFMwbilEajqgtOuy,infoLabels=XeCckmAJdpKVIzTFMwbilEajqgtOvQ,isFolder=XeCckmAJdpKVIzTFMwbilEajqgtOuS,params=XeCckmAJdpKVIzTFMwbilEajqgtOGQ)
  if XeCckmAJdpKVIzTFMwbilEajqgtOuY(XeCckmAJdpKVIzTFMwbilEajqgtOvL)>0:xbmcplugin.endOfDirectory(XeCckmAJdpKVIzTFMwbilEajqgtOHu._addon_handle,cacheToDisc=XeCckmAJdpKVIzTFMwbilEajqgtOuB)
 def dp_BandLiveSection_List(XeCckmAJdpKVIzTFMwbilEajqgtOHu,args):
  XeCckmAJdpKVIzTFMwbilEajqgtOUY =args.get('subapi')
  XeCckmAJdpKVIzTFMwbilEajqgtOvn=XeCckmAJdpKVIzTFMwbilEajqgtOuU(args.get('page'))
  XeCckmAJdpKVIzTFMwbilEajqgtOvL,XeCckmAJdpKVIzTFMwbilEajqgtOvH=XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.Get_BandLiveSection_List(XeCckmAJdpKVIzTFMwbilEajqgtOUY,XeCckmAJdpKVIzTFMwbilEajqgtOvn)
  for XeCckmAJdpKVIzTFMwbilEajqgtOvx in XeCckmAJdpKVIzTFMwbilEajqgtOvL:
   XeCckmAJdpKVIzTFMwbilEajqgtOSv =XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('channelid')
   XeCckmAJdpKVIzTFMwbilEajqgtOSD =XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('studio')
   XeCckmAJdpKVIzTFMwbilEajqgtOSy=XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('tvshowtitle')
   XeCckmAJdpKVIzTFMwbilEajqgtOvs =XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('thumbnail')
   XeCckmAJdpKVIzTFMwbilEajqgtOvf =XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('age')
   XeCckmAJdpKVIzTFMwbilEajqgtOvQ={'mediatype':'tvshow','mpaa':XeCckmAJdpKVIzTFMwbilEajqgtOvf,'title':'%s < %s >'%(XeCckmAJdpKVIzTFMwbilEajqgtOSD,XeCckmAJdpKVIzTFMwbilEajqgtOSy),'tvshowtitle':XeCckmAJdpKVIzTFMwbilEajqgtOSy,'studio':XeCckmAJdpKVIzTFMwbilEajqgtOSD,'plot':XeCckmAJdpKVIzTFMwbilEajqgtOSD}
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ={'mode':'LIVE','contentid':XeCckmAJdpKVIzTFMwbilEajqgtOSv}
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.add_dir(XeCckmAJdpKVIzTFMwbilEajqgtOSD,sublabel=XeCckmAJdpKVIzTFMwbilEajqgtOSy,img=XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('thumbnail'),infoLabels=XeCckmAJdpKVIzTFMwbilEajqgtOvQ,isFolder=XeCckmAJdpKVIzTFMwbilEajqgtOuB,params=XeCckmAJdpKVIzTFMwbilEajqgtOGQ)
  if XeCckmAJdpKVIzTFMwbilEajqgtOvH:
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ={}
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ['mode'] ='BANDLIVESECTION_LIST' 
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ['subapi']=XeCckmAJdpKVIzTFMwbilEajqgtOUY
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ['page'] =XeCckmAJdpKVIzTFMwbilEajqgtOuQ(XeCckmAJdpKVIzTFMwbilEajqgtOvn+1)
   XeCckmAJdpKVIzTFMwbilEajqgtOGr='[B]%s >>[/B]'%'다음 페이지'
   XeCckmAJdpKVIzTFMwbilEajqgtODv=XeCckmAJdpKVIzTFMwbilEajqgtOuQ(XeCckmAJdpKVIzTFMwbilEajqgtOvn+1)
   XeCckmAJdpKVIzTFMwbilEajqgtOGN=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.add_dir(XeCckmAJdpKVIzTFMwbilEajqgtOGr,sublabel=XeCckmAJdpKVIzTFMwbilEajqgtODv,img=XeCckmAJdpKVIzTFMwbilEajqgtOGN,infoLabels=XeCckmAJdpKVIzTFMwbilEajqgtOuy,isFolder=XeCckmAJdpKVIzTFMwbilEajqgtOuS,params=XeCckmAJdpKVIzTFMwbilEajqgtOGQ)
  if XeCckmAJdpKVIzTFMwbilEajqgtOuY(XeCckmAJdpKVIzTFMwbilEajqgtOvL)>0:xbmcplugin.endOfDirectory(XeCckmAJdpKVIzTFMwbilEajqgtOHu._addon_handle,cacheToDisc=XeCckmAJdpKVIzTFMwbilEajqgtOuB)
 def dp_Band2Section_List(XeCckmAJdpKVIzTFMwbilEajqgtOHu,args):
  XeCckmAJdpKVIzTFMwbilEajqgtOUY =args.get('subapi')
  XeCckmAJdpKVIzTFMwbilEajqgtOvn=XeCckmAJdpKVIzTFMwbilEajqgtOuU(args.get('page'))
  XeCckmAJdpKVIzTFMwbilEajqgtOvL,XeCckmAJdpKVIzTFMwbilEajqgtOvH=XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.Get_Band2Section_List(XeCckmAJdpKVIzTFMwbilEajqgtOUY,XeCckmAJdpKVIzTFMwbilEajqgtOvn)
  for XeCckmAJdpKVIzTFMwbilEajqgtOvx in XeCckmAJdpKVIzTFMwbilEajqgtOvL:
   XeCckmAJdpKVIzTFMwbilEajqgtOGr =XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('programtitle')
   XeCckmAJdpKVIzTFMwbilEajqgtODv =XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('episodetitle')
   XeCckmAJdpKVIzTFMwbilEajqgtOvQ={'plot':XeCckmAJdpKVIzTFMwbilEajqgtOGr+'\n\n'+XeCckmAJdpKVIzTFMwbilEajqgtODv,'mpaa':XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('age'),'mediatype':'episode'}
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ={'mode':'VOD','programid':'-','contentid':XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('videoid'),'thumbnail':XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('thumbnail'),'title':XeCckmAJdpKVIzTFMwbilEajqgtOGr,'subtitle':XeCckmAJdpKVIzTFMwbilEajqgtODv}
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.add_dir(XeCckmAJdpKVIzTFMwbilEajqgtOGr,sublabel=XeCckmAJdpKVIzTFMwbilEajqgtODv,img=XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('thumbnail'),infoLabels=XeCckmAJdpKVIzTFMwbilEajqgtOvQ,isFolder=XeCckmAJdpKVIzTFMwbilEajqgtOuB,params=XeCckmAJdpKVIzTFMwbilEajqgtOGQ)
  if XeCckmAJdpKVIzTFMwbilEajqgtOvH:
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ={}
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ['mode'] ='BAND2SECTION_LIST' 
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ['subapi']=XeCckmAJdpKVIzTFMwbilEajqgtOUY
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ['page'] =XeCckmAJdpKVIzTFMwbilEajqgtOuQ(XeCckmAJdpKVIzTFMwbilEajqgtOvn+1)
   XeCckmAJdpKVIzTFMwbilEajqgtOGr='[B]%s >>[/B]'%'다음 페이지'
   XeCckmAJdpKVIzTFMwbilEajqgtODv=XeCckmAJdpKVIzTFMwbilEajqgtOuQ(XeCckmAJdpKVIzTFMwbilEajqgtOvn+1)
   XeCckmAJdpKVIzTFMwbilEajqgtOGN=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.add_dir(XeCckmAJdpKVIzTFMwbilEajqgtOGr,sublabel=XeCckmAJdpKVIzTFMwbilEajqgtODv,img=XeCckmAJdpKVIzTFMwbilEajqgtOGN,infoLabels=XeCckmAJdpKVIzTFMwbilEajqgtOuy,isFolder=XeCckmAJdpKVIzTFMwbilEajqgtOuS,params=XeCckmAJdpKVIzTFMwbilEajqgtOGQ)
  if XeCckmAJdpKVIzTFMwbilEajqgtOuY(XeCckmAJdpKVIzTFMwbilEajqgtOvL)>0:xbmcplugin.endOfDirectory(XeCckmAJdpKVIzTFMwbilEajqgtOHu._addon_handle,cacheToDisc=XeCckmAJdpKVIzTFMwbilEajqgtOuB)
 def dp_Movie_List(XeCckmAJdpKVIzTFMwbilEajqgtOHu,args):
  XeCckmAJdpKVIzTFMwbilEajqgtOUY =args.get('subapi')
  XeCckmAJdpKVIzTFMwbilEajqgtOvn=XeCckmAJdpKVIzTFMwbilEajqgtOuU(args.get('page'))
  XeCckmAJdpKVIzTFMwbilEajqgtOGu =args.get('orderby')or '-'
  XeCckmAJdpKVIzTFMwbilEajqgtOvL,XeCckmAJdpKVIzTFMwbilEajqgtOvH=XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.Get_Movie_List(XeCckmAJdpKVIzTFMwbilEajqgtOUY,XeCckmAJdpKVIzTFMwbilEajqgtOvn,XeCckmAJdpKVIzTFMwbilEajqgtOGu)
  for XeCckmAJdpKVIzTFMwbilEajqgtOvx in XeCckmAJdpKVIzTFMwbilEajqgtOvL:
   XeCckmAJdpKVIzTFMwbilEajqgtOvR =XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('videoid')
   XeCckmAJdpKVIzTFMwbilEajqgtOvo =XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('vidtype')
   XeCckmAJdpKVIzTFMwbilEajqgtOGr =XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('title')
   XeCckmAJdpKVIzTFMwbilEajqgtOvs=XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('thumbnail')
   XeCckmAJdpKVIzTFMwbilEajqgtOvf =XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('age')
   if XeCckmAJdpKVIzTFMwbilEajqgtOvf=='18' or XeCckmAJdpKVIzTFMwbilEajqgtOvf=='19' or XeCckmAJdpKVIzTFMwbilEajqgtOvf=='21':XeCckmAJdpKVIzTFMwbilEajqgtOGr+=' (%s)'%(XeCckmAJdpKVIzTFMwbilEajqgtOvf)
   XeCckmAJdpKVIzTFMwbilEajqgtOvQ={'plot':XeCckmAJdpKVIzTFMwbilEajqgtOGr,'mpaa':XeCckmAJdpKVIzTFMwbilEajqgtOvf,'mediatype':'movie'}
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ={'mode':'MOVIE','contentid':XeCckmAJdpKVIzTFMwbilEajqgtOvR,'title':XeCckmAJdpKVIzTFMwbilEajqgtOGr,'thumbnail':XeCckmAJdpKVIzTFMwbilEajqgtOvs,'age':XeCckmAJdpKVIzTFMwbilEajqgtOvf,}
   XeCckmAJdpKVIzTFMwbilEajqgtOvN=[]
   XeCckmAJdpKVIzTFMwbilEajqgtOvP={'mode':'VIEW_DETAIL','values':{'videoid':XeCckmAJdpKVIzTFMwbilEajqgtOvR,'vidtype':'movie','contenttype':XeCckmAJdpKVIzTFMwbilEajqgtOvo,}}
   XeCckmAJdpKVIzTFMwbilEajqgtOvh=json.dumps(XeCckmAJdpKVIzTFMwbilEajqgtOvP,separators=(',',':'))
   XeCckmAJdpKVIzTFMwbilEajqgtOvh=base64.standard_b64encode(XeCckmAJdpKVIzTFMwbilEajqgtOvh.encode()).decode('utf-8')
   XeCckmAJdpKVIzTFMwbilEajqgtOvh=XeCckmAJdpKVIzTFMwbilEajqgtOvh.replace('+','%2B')
   XeCckmAJdpKVIzTFMwbilEajqgtODH='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(XeCckmAJdpKVIzTFMwbilEajqgtOvh)
   XeCckmAJdpKVIzTFMwbilEajqgtOvN.append(('상세정보 조회',XeCckmAJdpKVIzTFMwbilEajqgtODH))
   if XeCckmAJdpKVIzTFMwbilEajqgtOHu.get_settings_makebookmark():
    XeCckmAJdpKVIzTFMwbilEajqgtOvP={'videoid':XeCckmAJdpKVIzTFMwbilEajqgtOvR,'vidtype':'movie','vtitle':XeCckmAJdpKVIzTFMwbilEajqgtOGr,'vsubtitle':'','contenttype':'programid',}
    XeCckmAJdpKVIzTFMwbilEajqgtODG=json.dumps(XeCckmAJdpKVIzTFMwbilEajqgtOvP)
    XeCckmAJdpKVIzTFMwbilEajqgtODG=urllib.parse.quote(XeCckmAJdpKVIzTFMwbilEajqgtODG)
    XeCckmAJdpKVIzTFMwbilEajqgtODH='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(XeCckmAJdpKVIzTFMwbilEajqgtODG)
    XeCckmAJdpKVIzTFMwbilEajqgtOvN.append(('(통합) 찜 영상에 추가',XeCckmAJdpKVIzTFMwbilEajqgtODH))
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.add_dir(XeCckmAJdpKVIzTFMwbilEajqgtOGr,sublabel='',img=XeCckmAJdpKVIzTFMwbilEajqgtOvs,infoLabels=XeCckmAJdpKVIzTFMwbilEajqgtOvQ,isFolder=XeCckmAJdpKVIzTFMwbilEajqgtOuB,params=XeCckmAJdpKVIzTFMwbilEajqgtOGQ,ContextMenu=XeCckmAJdpKVIzTFMwbilEajqgtOvN)
  if XeCckmAJdpKVIzTFMwbilEajqgtOvH:
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ={}
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ['mode'] ='MOVIE_LIST' 
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ['subapi']=XeCckmAJdpKVIzTFMwbilEajqgtOUY 
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ['page'] =XeCckmAJdpKVIzTFMwbilEajqgtOuQ(XeCckmAJdpKVIzTFMwbilEajqgtOvn+1)
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ['orderby']=XeCckmAJdpKVIzTFMwbilEajqgtOGu
   XeCckmAJdpKVIzTFMwbilEajqgtOGr='[B]%s >>[/B]'%'다음 페이지'
   XeCckmAJdpKVIzTFMwbilEajqgtODv=XeCckmAJdpKVIzTFMwbilEajqgtOuQ(XeCckmAJdpKVIzTFMwbilEajqgtOvn+1)
   XeCckmAJdpKVIzTFMwbilEajqgtOGN=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.add_dir(XeCckmAJdpKVIzTFMwbilEajqgtOGr,sublabel=XeCckmAJdpKVIzTFMwbilEajqgtODv,img=XeCckmAJdpKVIzTFMwbilEajqgtOGN,infoLabels=XeCckmAJdpKVIzTFMwbilEajqgtOuy,isFolder=XeCckmAJdpKVIzTFMwbilEajqgtOuS,params=XeCckmAJdpKVIzTFMwbilEajqgtOGQ)
  xbmcplugin.setContent(XeCckmAJdpKVIzTFMwbilEajqgtOHu._addon_handle,'movies')
  if XeCckmAJdpKVIzTFMwbilEajqgtOuY(XeCckmAJdpKVIzTFMwbilEajqgtOvL)>0:xbmcplugin.endOfDirectory(XeCckmAJdpKVIzTFMwbilEajqgtOHu._addon_handle,cacheToDisc=XeCckmAJdpKVIzTFMwbilEajqgtOuB)
 def dp_Set_Bookmark(XeCckmAJdpKVIzTFMwbilEajqgtOHu,args):
  XeCckmAJdpKVIzTFMwbilEajqgtOSU=urllib.parse.unquote(args.get('bm_param'))
  XeCckmAJdpKVIzTFMwbilEajqgtOSU=json.loads(XeCckmAJdpKVIzTFMwbilEajqgtOSU)
  XeCckmAJdpKVIzTFMwbilEajqgtOvR =XeCckmAJdpKVIzTFMwbilEajqgtOSU.get('videoid')
  XeCckmAJdpKVIzTFMwbilEajqgtOvo =XeCckmAJdpKVIzTFMwbilEajqgtOSU.get('vidtype')
  XeCckmAJdpKVIzTFMwbilEajqgtOSu =XeCckmAJdpKVIzTFMwbilEajqgtOSU.get('vtitle')
  XeCckmAJdpKVIzTFMwbilEajqgtOSB =XeCckmAJdpKVIzTFMwbilEajqgtOSU.get('vsubtitle')
  XeCckmAJdpKVIzTFMwbilEajqgtOSr=XeCckmAJdpKVIzTFMwbilEajqgtOSU.get('contenttype')
  XeCckmAJdpKVIzTFMwbilEajqgtOHN=xbmcgui.Dialog()
  XeCckmAJdpKVIzTFMwbilEajqgtODo=XeCckmAJdpKVIzTFMwbilEajqgtOHN.yesno(__language__(30913).encode('utf8'),XeCckmAJdpKVIzTFMwbilEajqgtOSu+' \n\n'+__language__(30914))
  if XeCckmAJdpKVIzTFMwbilEajqgtODo==XeCckmAJdpKVIzTFMwbilEajqgtOuB:return
  XeCckmAJdpKVIzTFMwbilEajqgtOSW=XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.GetBookmarkInfo(XeCckmAJdpKVIzTFMwbilEajqgtOvR,XeCckmAJdpKVIzTFMwbilEajqgtOvo,XeCckmAJdpKVIzTFMwbilEajqgtOSr)
  XeCckmAJdpKVIzTFMwbilEajqgtOSY=json.dumps(XeCckmAJdpKVIzTFMwbilEajqgtOSW)
  XeCckmAJdpKVIzTFMwbilEajqgtOSY=urllib.parse.quote(XeCckmAJdpKVIzTFMwbilEajqgtOSY)
  XeCckmAJdpKVIzTFMwbilEajqgtODH ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(XeCckmAJdpKVIzTFMwbilEajqgtOSY)
  xbmc.executebuiltin(XeCckmAJdpKVIzTFMwbilEajqgtODH)
 def dp_LiveChannel_List(XeCckmAJdpKVIzTFMwbilEajqgtOHu,args):
  XeCckmAJdpKVIzTFMwbilEajqgtOSN =args.get('genre')
  XeCckmAJdpKVIzTFMwbilEajqgtOUW=args.get('baseapi')
  XeCckmAJdpKVIzTFMwbilEajqgtOvL=XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.Get_LiveChannel_List(XeCckmAJdpKVIzTFMwbilEajqgtOSN,XeCckmAJdpKVIzTFMwbilEajqgtOUW)
  for XeCckmAJdpKVIzTFMwbilEajqgtOvx in XeCckmAJdpKVIzTFMwbilEajqgtOvL:
   XeCckmAJdpKVIzTFMwbilEajqgtOSv =XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('channelid')
   XeCckmAJdpKVIzTFMwbilEajqgtOSD =XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('studio')
   XeCckmAJdpKVIzTFMwbilEajqgtOSy=XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('tvshowtitle')
   XeCckmAJdpKVIzTFMwbilEajqgtOvs =XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('thumbnail')
   XeCckmAJdpKVIzTFMwbilEajqgtOvf =XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('age')
   XeCckmAJdpKVIzTFMwbilEajqgtOSQ =XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('epg')
   XeCckmAJdpKVIzTFMwbilEajqgtOvQ={'mediatype':'episode','mpaa':XeCckmAJdpKVIzTFMwbilEajqgtOvf,'title':'%s < %s >'%(XeCckmAJdpKVIzTFMwbilEajqgtOSD,XeCckmAJdpKVIzTFMwbilEajqgtOSy),'tvshowtitle':XeCckmAJdpKVIzTFMwbilEajqgtOSy,'studio':XeCckmAJdpKVIzTFMwbilEajqgtOSD,'plot':'%s\n\n%s'%(XeCckmAJdpKVIzTFMwbilEajqgtOSD,XeCckmAJdpKVIzTFMwbilEajqgtOSQ)}
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ={'mode':'LIVE','contentid':XeCckmAJdpKVIzTFMwbilEajqgtOSv}
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.add_dir(XeCckmAJdpKVIzTFMwbilEajqgtOSD,sublabel=XeCckmAJdpKVIzTFMwbilEajqgtOSy,img=XeCckmAJdpKVIzTFMwbilEajqgtOvs,infoLabels=XeCckmAJdpKVIzTFMwbilEajqgtOvQ,isFolder=XeCckmAJdpKVIzTFMwbilEajqgtOuB,params=XeCckmAJdpKVIzTFMwbilEajqgtOGQ)
  if XeCckmAJdpKVIzTFMwbilEajqgtOuY(XeCckmAJdpKVIzTFMwbilEajqgtOvL)>0:xbmcplugin.endOfDirectory(XeCckmAJdpKVIzTFMwbilEajqgtOHu._addon_handle,cacheToDisc=XeCckmAJdpKVIzTFMwbilEajqgtOuB)
 def dp_Sports_GameList(XeCckmAJdpKVIzTFMwbilEajqgtOHu,args):
  XeCckmAJdpKVIzTFMwbilEajqgtOvL=XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.Get_Sports_Gamelist()
  for XeCckmAJdpKVIzTFMwbilEajqgtOvx in XeCckmAJdpKVIzTFMwbilEajqgtOvL:
   XeCckmAJdpKVIzTFMwbilEajqgtOSn =XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('game_date')
   XeCckmAJdpKVIzTFMwbilEajqgtOSL =XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('game_time')
   XeCckmAJdpKVIzTFMwbilEajqgtOSx =XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('svc_id')
   XeCckmAJdpKVIzTFMwbilEajqgtOSR =XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('away_team')
   XeCckmAJdpKVIzTFMwbilEajqgtOSo =XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('home_team')
   XeCckmAJdpKVIzTFMwbilEajqgtOSs=XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('game_status')
   XeCckmAJdpKVIzTFMwbilEajqgtOSf =XeCckmAJdpKVIzTFMwbilEajqgtOvx.get('game_place')
   XeCckmAJdpKVIzTFMwbilEajqgtOSP ='%s vs %s (%s)'%(XeCckmAJdpKVIzTFMwbilEajqgtOSR,XeCckmAJdpKVIzTFMwbilEajqgtOSo,XeCckmAJdpKVIzTFMwbilEajqgtOSf)
   XeCckmAJdpKVIzTFMwbilEajqgtOSh =XeCckmAJdpKVIzTFMwbilEajqgtOSn+' '+XeCckmAJdpKVIzTFMwbilEajqgtOSL
   if XeCckmAJdpKVIzTFMwbilEajqgtOSs=='LIVE':
    XeCckmAJdpKVIzTFMwbilEajqgtOSs='~경기중~'
   elif XeCckmAJdpKVIzTFMwbilEajqgtOSs=='END':
    XeCckmAJdpKVIzTFMwbilEajqgtOSs='경기종료'
   elif XeCckmAJdpKVIzTFMwbilEajqgtOSs=='CANCEL':
    XeCckmAJdpKVIzTFMwbilEajqgtOSs='취소'
   else:
    XeCckmAJdpKVIzTFMwbilEajqgtOSs=''
   if XeCckmAJdpKVIzTFMwbilEajqgtOSs=='':
    XeCckmAJdpKVIzTFMwbilEajqgtODv=XeCckmAJdpKVIzTFMwbilEajqgtOSP
   else:
    XeCckmAJdpKVIzTFMwbilEajqgtODv=XeCckmAJdpKVIzTFMwbilEajqgtOSP+'  '+XeCckmAJdpKVIzTFMwbilEajqgtOSs
   XeCckmAJdpKVIzTFMwbilEajqgtOvQ={'mediatype':'episode','title':XeCckmAJdpKVIzTFMwbilEajqgtOSP,'plot':'%s\n\n%s\n\n%s'%(XeCckmAJdpKVIzTFMwbilEajqgtOSh,XeCckmAJdpKVIzTFMwbilEajqgtOSP,XeCckmAJdpKVIzTFMwbilEajqgtOSs)}
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ={'mode':'SPORTS','contentid':XeCckmAJdpKVIzTFMwbilEajqgtOSx}
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.add_dir(XeCckmAJdpKVIzTFMwbilEajqgtOSh,sublabel=XeCckmAJdpKVIzTFMwbilEajqgtODv,img='',infoLabels=XeCckmAJdpKVIzTFMwbilEajqgtOvQ,isFolder=XeCckmAJdpKVIzTFMwbilEajqgtOuB,params=XeCckmAJdpKVIzTFMwbilEajqgtOGQ)
  xbmcplugin.endOfDirectory(XeCckmAJdpKVIzTFMwbilEajqgtOHu._addon_handle,cacheToDisc=XeCckmAJdpKVIzTFMwbilEajqgtOuB)
 def dp_View_Detail(XeCckmAJdpKVIzTFMwbilEajqgtOHu,XeCckmAJdpKVIzTFMwbilEajqgtOuv):
  XeCckmAJdpKVIzTFMwbilEajqgtOvR =XeCckmAJdpKVIzTFMwbilEajqgtOuv.get('videoid')
  XeCckmAJdpKVIzTFMwbilEajqgtOvo =XeCckmAJdpKVIzTFMwbilEajqgtOuv.get('vidtype') 
  XeCckmAJdpKVIzTFMwbilEajqgtOSr=XeCckmAJdpKVIzTFMwbilEajqgtOuv.get('contenttype')
  XeCckmAJdpKVIzTFMwbilEajqgtOHu.addon_log(XeCckmAJdpKVIzTFMwbilEajqgtOvR)
  XeCckmAJdpKVIzTFMwbilEajqgtOHu.addon_log(XeCckmAJdpKVIzTFMwbilEajqgtOvo)
  XeCckmAJdpKVIzTFMwbilEajqgtOHu.addon_log(XeCckmAJdpKVIzTFMwbilEajqgtOSr)
  XeCckmAJdpKVIzTFMwbilEajqgtOSW=XeCckmAJdpKVIzTFMwbilEajqgtOHu.WavveObj.GetBookmarkInfo(XeCckmAJdpKVIzTFMwbilEajqgtOvR,XeCckmAJdpKVIzTFMwbilEajqgtOvo,XeCckmAJdpKVIzTFMwbilEajqgtOSr)
  if XeCckmAJdpKVIzTFMwbilEajqgtOvo=='tvshow':
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ={'mode':'SEASON_LIST','videoid':XeCckmAJdpKVIzTFMwbilEajqgtOSW['indexinfo']['videoid'],'vidtype':XeCckmAJdpKVIzTFMwbilEajqgtOSW['indexinfo']['vidtype'],}
   XeCckmAJdpKVIzTFMwbilEajqgtODh='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(XeCckmAJdpKVIzTFMwbilEajqgtOGQ))
  else:
   XeCckmAJdpKVIzTFMwbilEajqgtOGQ={'mode':'MOVIE','contentid':XeCckmAJdpKVIzTFMwbilEajqgtOSW['indexinfo']['videoid'],'title':XeCckmAJdpKVIzTFMwbilEajqgtOSW['saveinfo']['infoLabels']['title'],'thumbnail':XeCckmAJdpKVIzTFMwbilEajqgtOSW['saveinfo']['thumbnail'],'age':XeCckmAJdpKVIzTFMwbilEajqgtOSW['saveinfo']['infoLabels']['mpaa'],}
   XeCckmAJdpKVIzTFMwbilEajqgtODh='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(XeCckmAJdpKVIzTFMwbilEajqgtOGQ))
  XeCckmAJdpKVIzTFMwbilEajqgtOGW=xbmcgui.ListItem(label=XeCckmAJdpKVIzTFMwbilEajqgtOSW['saveinfo']['title'],path=XeCckmAJdpKVIzTFMwbilEajqgtODh)
  XeCckmAJdpKVIzTFMwbilEajqgtOGW.setArt(XeCckmAJdpKVIzTFMwbilEajqgtOSW['saveinfo']['thumbnail'])
  XeCckmAJdpKVIzTFMwbilEajqgtOGW.setInfo('Video',XeCckmAJdpKVIzTFMwbilEajqgtOSW['saveinfo']['infoLabels'])
  if XeCckmAJdpKVIzTFMwbilEajqgtOvo=='movie':
   XeCckmAJdpKVIzTFMwbilEajqgtOGW.setIsFolder(XeCckmAJdpKVIzTFMwbilEajqgtOuB)
   XeCckmAJdpKVIzTFMwbilEajqgtOGW.setProperty('IsPlayable','true')
  else:
   XeCckmAJdpKVIzTFMwbilEajqgtOGW.setIsFolder(XeCckmAJdpKVIzTFMwbilEajqgtOuS)
   XeCckmAJdpKVIzTFMwbilEajqgtOGW.setProperty('IsPlayable','false')
  XeCckmAJdpKVIzTFMwbilEajqgtOHN=xbmcgui.Dialog()
  XeCckmAJdpKVIzTFMwbilEajqgtOHN.info(XeCckmAJdpKVIzTFMwbilEajqgtOGW)
 def wavve_main(XeCckmAJdpKVIzTFMwbilEajqgtOHu):
  XeCckmAJdpKVIzTFMwbilEajqgtOuH=XeCckmAJdpKVIzTFMwbilEajqgtOHu.main_params.get('params')
  if XeCckmAJdpKVIzTFMwbilEajqgtOuH:
   XeCckmAJdpKVIzTFMwbilEajqgtOuG =base64.standard_b64decode(XeCckmAJdpKVIzTFMwbilEajqgtOuH).decode('utf-8')
   XeCckmAJdpKVIzTFMwbilEajqgtOuG =json.loads(XeCckmAJdpKVIzTFMwbilEajqgtOuG)
   XeCckmAJdpKVIzTFMwbilEajqgtOGf =XeCckmAJdpKVIzTFMwbilEajqgtOuG.get('mode')
   XeCckmAJdpKVIzTFMwbilEajqgtOuv =XeCckmAJdpKVIzTFMwbilEajqgtOuG.get('values')
  else:
   XeCckmAJdpKVIzTFMwbilEajqgtOGf=XeCckmAJdpKVIzTFMwbilEajqgtOHu.main_params.get('mode',XeCckmAJdpKVIzTFMwbilEajqgtOuy)
   XeCckmAJdpKVIzTFMwbilEajqgtOuv=XeCckmAJdpKVIzTFMwbilEajqgtOHu.main_params
  if XeCckmAJdpKVIzTFMwbilEajqgtOGf=='LOGOUT':
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.logout()
   return
  XeCckmAJdpKVIzTFMwbilEajqgtOHu.login_main()
  if XeCckmAJdpKVIzTFMwbilEajqgtOGf is XeCckmAJdpKVIzTFMwbilEajqgtOuy:
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.dp_Main_List()
  elif XeCckmAJdpKVIzTFMwbilEajqgtOGf in['LIVE','VOD','MOVIE','SPORTS']:
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.play_VIDEO(XeCckmAJdpKVIzTFMwbilEajqgtOuv)
  elif XeCckmAJdpKVIzTFMwbilEajqgtOGf=='LIVE_CATAGORY':
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.dp_LiveCatagory_List(XeCckmAJdpKVIzTFMwbilEajqgtOuv)
  elif XeCckmAJdpKVIzTFMwbilEajqgtOGf=='MAIN_CATAGORY':
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.dp_MainCatagory_List(XeCckmAJdpKVIzTFMwbilEajqgtOuv)
  elif XeCckmAJdpKVIzTFMwbilEajqgtOGf=='SUPERSECTION_LIST':
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.dp_SuperSection_List(XeCckmAJdpKVIzTFMwbilEajqgtOuv)
  elif XeCckmAJdpKVIzTFMwbilEajqgtOGf=='BANDLIVESECTION_LIST':
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.dp_BandLiveSection_List(XeCckmAJdpKVIzTFMwbilEajqgtOuv)
  elif XeCckmAJdpKVIzTFMwbilEajqgtOGf=='BAND2SECTION_LIST':
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.dp_Band2Section_List(XeCckmAJdpKVIzTFMwbilEajqgtOuv)
  elif XeCckmAJdpKVIzTFMwbilEajqgtOGf=='PROGRAM_LIST':
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.dp_Program_List(XeCckmAJdpKVIzTFMwbilEajqgtOuv)
  elif XeCckmAJdpKVIzTFMwbilEajqgtOGf=='SEASON_LIST':
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.dp_Season_List(XeCckmAJdpKVIzTFMwbilEajqgtOuv)
  elif XeCckmAJdpKVIzTFMwbilEajqgtOGf=='EPISODE_LIST':
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.dp_Episode_List(XeCckmAJdpKVIzTFMwbilEajqgtOuv)
  elif XeCckmAJdpKVIzTFMwbilEajqgtOGf=='MOVIE_LIST':
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.dp_Movie_List(XeCckmAJdpKVIzTFMwbilEajqgtOuv)
  elif XeCckmAJdpKVIzTFMwbilEajqgtOGf=='LIVE_LIST':
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.dp_LiveChannel_List(XeCckmAJdpKVIzTFMwbilEajqgtOuv)
  elif XeCckmAJdpKVIzTFMwbilEajqgtOGf=='ORDER_BY':
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.dp_setEpOrderby(XeCckmAJdpKVIzTFMwbilEajqgtOuv)
  elif XeCckmAJdpKVIzTFMwbilEajqgtOGf=='SEARCH_GROUP':
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.dp_Search_Group(XeCckmAJdpKVIzTFMwbilEajqgtOuv)
  elif XeCckmAJdpKVIzTFMwbilEajqgtOGf in['SEARCH_LIST','LOCAL_SEARCH']:
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.dp_Search_List(XeCckmAJdpKVIzTFMwbilEajqgtOuv)
  elif XeCckmAJdpKVIzTFMwbilEajqgtOGf=='WATCH_GROUP':
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.dp_Watch_Group(XeCckmAJdpKVIzTFMwbilEajqgtOuv)
  elif XeCckmAJdpKVIzTFMwbilEajqgtOGf=='WATCH_LIST':
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.dp_Watch_List(XeCckmAJdpKVIzTFMwbilEajqgtOuv)
  elif XeCckmAJdpKVIzTFMwbilEajqgtOGf=='SET_BOOKMARK':
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.dp_Set_Bookmark(XeCckmAJdpKVIzTFMwbilEajqgtOuv)
  elif XeCckmAJdpKVIzTFMwbilEajqgtOGf in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.dp_History_Remove(XeCckmAJdpKVIzTFMwbilEajqgtOuv)
  elif XeCckmAJdpKVIzTFMwbilEajqgtOGf in['TOTAL_SEARCH','TOTAL_HISTORY']:
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.dp_Global_Search(XeCckmAJdpKVIzTFMwbilEajqgtOuv)
  elif XeCckmAJdpKVIzTFMwbilEajqgtOGf=='SEARCH_HISTORY':
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.dp_Search_History(XeCckmAJdpKVIzTFMwbilEajqgtOuv)
  elif XeCckmAJdpKVIzTFMwbilEajqgtOGf=='MENU_BOOKMARK':
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.dp_Bookmark_Menu(XeCckmAJdpKVIzTFMwbilEajqgtOuv)
  elif XeCckmAJdpKVIzTFMwbilEajqgtOGf=='GAME_LIST':
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.dp_Sports_GameList(XeCckmAJdpKVIzTFMwbilEajqgtOuv)
  elif XeCckmAJdpKVIzTFMwbilEajqgtOGf=='VIEW_DETAIL':
   XeCckmAJdpKVIzTFMwbilEajqgtOHu.dp_View_Detail(XeCckmAJdpKVIzTFMwbilEajqgtOuv)
  else:
   XeCckmAJdpKVIzTFMwbilEajqgtOuy
# Created by pyminifier (https://github.com/liftoff/pyminifier)
