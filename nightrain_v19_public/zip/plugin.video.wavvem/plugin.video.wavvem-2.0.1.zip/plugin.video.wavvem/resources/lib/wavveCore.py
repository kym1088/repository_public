__author__="NightRain"
qFUdMDIzOpvreYgTjPysXBSHwGKxub=object
qFUdMDIzOpvreYgTjPysXBSHwGKxun=None
qFUdMDIzOpvreYgTjPysXBSHwGKxuf=False
qFUdMDIzOpvreYgTjPysXBSHwGKxuV=range
qFUdMDIzOpvreYgTjPysXBSHwGKxuC=str
qFUdMDIzOpvreYgTjPysXBSHwGKxuc=True
qFUdMDIzOpvreYgTjPysXBSHwGKxui=Exception
qFUdMDIzOpvreYgTjPysXBSHwGKxut=print
qFUdMDIzOpvreYgTjPysXBSHwGKxuR=len
qFUdMDIzOpvreYgTjPysXBSHwGKxuk=dict
qFUdMDIzOpvreYgTjPysXBSHwGKxuQ=int
import urllib
import http.cookiejar 
import re
import json
import sys
import requests
qFUdMDIzOpvreYgTjPysXBSHwGKxhb='Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'
class qFUdMDIzOpvreYgTjPysXBSHwGKxhE(qFUdMDIzOpvreYgTjPysXBSHwGKxub):
 def __init__(qFUdMDIzOpvreYgTjPysXBSHwGKxhn):
  qFUdMDIzOpvreYgTjPysXBSHwGKxhn.API_DOMAIN='https://apis.pooq.co.kr'
  qFUdMDIzOpvreYgTjPysXBSHwGKxhn.APIKEY='E5F3E0D30947AA5440556471321BB6D9'
  qFUdMDIzOpvreYgTjPysXBSHwGKxhn.CREDENTIAL='none'
  qFUdMDIzOpvreYgTjPysXBSHwGKxhn.DEVICE='pc'
  qFUdMDIzOpvreYgTjPysXBSHwGKxhn.DRM='wm'
  qFUdMDIzOpvreYgTjPysXBSHwGKxhn.PARTNER='pooq'
  qFUdMDIzOpvreYgTjPysXBSHwGKxhn.POOQZONE='none'
  qFUdMDIzOpvreYgTjPysXBSHwGKxhn.REGION='kor'
  qFUdMDIzOpvreYgTjPysXBSHwGKxhn.TARGETAGE ='all'
  qFUdMDIzOpvreYgTjPysXBSHwGKxhn.HTTPTAG='https://'
  qFUdMDIzOpvreYgTjPysXBSHwGKxhn.LIST_LIMIT=30 
  qFUdMDIzOpvreYgTjPysXBSHwGKxhn.EP_LIMIT=30 
  qFUdMDIzOpvreYgTjPysXBSHwGKxhn.MV_LIMIT=24 
  qFUdMDIzOpvreYgTjPysXBSHwGKxhn.guid='none' 
  qFUdMDIzOpvreYgTjPysXBSHwGKxhn.guidtimestamp='none' 
  qFUdMDIzOpvreYgTjPysXBSHwGKxhn.DEFAULT_HEADER={'user-agent':qFUdMDIzOpvreYgTjPysXBSHwGKxhb}
 def callRequestCookies(qFUdMDIzOpvreYgTjPysXBSHwGKxhn,jobtype,qFUdMDIzOpvreYgTjPysXBSHwGKxhc,payload=qFUdMDIzOpvreYgTjPysXBSHwGKxun,params=qFUdMDIzOpvreYgTjPysXBSHwGKxun,headers=qFUdMDIzOpvreYgTjPysXBSHwGKxun,cookies=qFUdMDIzOpvreYgTjPysXBSHwGKxun,redirects=qFUdMDIzOpvreYgTjPysXBSHwGKxuf):
  qFUdMDIzOpvreYgTjPysXBSHwGKxhu=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.DEFAULT_HEADER
  if headers:qFUdMDIzOpvreYgTjPysXBSHwGKxhu.update(headers)
  if jobtype=='Get':
   qFUdMDIzOpvreYgTjPysXBSHwGKxhf=requests.get(qFUdMDIzOpvreYgTjPysXBSHwGKxhc,params=params,headers=qFUdMDIzOpvreYgTjPysXBSHwGKxhu,cookies=cookies,allow_redirects=redirects)
  else:
   qFUdMDIzOpvreYgTjPysXBSHwGKxhf=requests.post(qFUdMDIzOpvreYgTjPysXBSHwGKxhc,data=payload,params=params,headers=qFUdMDIzOpvreYgTjPysXBSHwGKxhu,cookies=cookies,allow_redirects=redirects)
  return qFUdMDIzOpvreYgTjPysXBSHwGKxhf
 def SaveCredential(qFUdMDIzOpvreYgTjPysXBSHwGKxhn,qFUdMDIzOpvreYgTjPysXBSHwGKxhV):
  qFUdMDIzOpvreYgTjPysXBSHwGKxhn.CREDENTIAL=qFUdMDIzOpvreYgTjPysXBSHwGKxhV
 def LoadCredential(qFUdMDIzOpvreYgTjPysXBSHwGKxhn):
  return qFUdMDIzOpvreYgTjPysXBSHwGKxhn.CREDENTIAL
 def GetDefaultParams(qFUdMDIzOpvreYgTjPysXBSHwGKxhn):
  qFUdMDIzOpvreYgTjPysXBSHwGKxhC={'apikey':qFUdMDIzOpvreYgTjPysXBSHwGKxhn.APIKEY,'credential':qFUdMDIzOpvreYgTjPysXBSHwGKxhn.CREDENTIAL,'device':qFUdMDIzOpvreYgTjPysXBSHwGKxhn.DEVICE,'drm':qFUdMDIzOpvreYgTjPysXBSHwGKxhn.DRM,'partner':qFUdMDIzOpvreYgTjPysXBSHwGKxhn.PARTNER,'pooqzone':qFUdMDIzOpvreYgTjPysXBSHwGKxhn.POOQZONE,'region':qFUdMDIzOpvreYgTjPysXBSHwGKxhn.REGION,'targetage':qFUdMDIzOpvreYgTjPysXBSHwGKxhn.TARGETAGE}
  return qFUdMDIzOpvreYgTjPysXBSHwGKxhC
 def makeurl(qFUdMDIzOpvreYgTjPysXBSHwGKxhn,domain,path,query1=qFUdMDIzOpvreYgTjPysXBSHwGKxun,query2=qFUdMDIzOpvreYgTjPysXBSHwGKxun):
  qFUdMDIzOpvreYgTjPysXBSHwGKxhc=domain+path
  if query1:
   qFUdMDIzOpvreYgTjPysXBSHwGKxhc+='?%s'%urllib.parse.urlencode(query1)
  if query2:
   qFUdMDIzOpvreYgTjPysXBSHwGKxhc+='&%s'%urllib.parse.urlencode(query2)
  return qFUdMDIzOpvreYgTjPysXBSHwGKxhc
 def GetGUID(qFUdMDIzOpvreYgTjPysXBSHwGKxhn,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   from datetime import datetime
   qFUdMDIzOpvreYgTjPysXBSHwGKxhR=datetime.now().strftime('%Y%m%d%H%M%S')
   qFUdMDIzOpvreYgTjPysXBSHwGKxhk=GenerateRandomString(5)
   qFUdMDIzOpvreYgTjPysXBSHwGKxhQ=qFUdMDIzOpvreYgTjPysXBSHwGKxhk+media+qFUdMDIzOpvreYgTjPysXBSHwGKxhR
   return qFUdMDIzOpvreYgTjPysXBSHwGKxhQ
  def GenerateRandomString(num):
   from random import randint
   qFUdMDIzOpvreYgTjPysXBSHwGKxhl=""
   for i in qFUdMDIzOpvreYgTjPysXBSHwGKxuV(0,num):
    s=qFUdMDIzOpvreYgTjPysXBSHwGKxuC(randint(1,5))
    qFUdMDIzOpvreYgTjPysXBSHwGKxhl+=s
   return qFUdMDIzOpvreYgTjPysXBSHwGKxhl
  qFUdMDIzOpvreYgTjPysXBSHwGKxhQ=GenerateID(guid_str)
  qFUdMDIzOpvreYgTjPysXBSHwGKxhm=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.GetHash(qFUdMDIzOpvreYgTjPysXBSHwGKxhQ)
  if guidType==2:
   qFUdMDIzOpvreYgTjPysXBSHwGKxhm='%s-%s-%s-%s-%s'%(qFUdMDIzOpvreYgTjPysXBSHwGKxhm[:8],qFUdMDIzOpvreYgTjPysXBSHwGKxhm[8:12],qFUdMDIzOpvreYgTjPysXBSHwGKxhm[12:16],qFUdMDIzOpvreYgTjPysXBSHwGKxhm[16:20],qFUdMDIzOpvreYgTjPysXBSHwGKxhm[20:])
  return qFUdMDIzOpvreYgTjPysXBSHwGKxhm
 def GetHash(qFUdMDIzOpvreYgTjPysXBSHwGKxhn,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return qFUdMDIzOpvreYgTjPysXBSHwGKxuC(m.hexdigest())
 def CheckQuality(qFUdMDIzOpvreYgTjPysXBSHwGKxhn,sel_qt,qt_list):
  qFUdMDIzOpvreYgTjPysXBSHwGKxhJ=0
  for qFUdMDIzOpvreYgTjPysXBSHwGKxhA in qt_list:
   if sel_qt>=qFUdMDIzOpvreYgTjPysXBSHwGKxhA:return qFUdMDIzOpvreYgTjPysXBSHwGKxhA
   qFUdMDIzOpvreYgTjPysXBSHwGKxhJ=qFUdMDIzOpvreYgTjPysXBSHwGKxhA
  return qFUdMDIzOpvreYgTjPysXBSHwGKxhJ
 def GetCredential(qFUdMDIzOpvreYgTjPysXBSHwGKxhn,user_id,user_pw,user_pf):
  qFUdMDIzOpvreYgTjPysXBSHwGKxha=qFUdMDIzOpvreYgTjPysXBSHwGKxuf
  try:
   qFUdMDIzOpvreYgTjPysXBSHwGKxhW='/login'
   qFUdMDIzOpvreYgTjPysXBSHwGKxhC=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.GetDefaultParams()
   qFUdMDIzOpvreYgTjPysXBSHwGKxhN={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   qFUdMDIzOpvreYgTjPysXBSHwGKxhc=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.makeurl(qFUdMDIzOpvreYgTjPysXBSHwGKxhn.API_DOMAIN,qFUdMDIzOpvreYgTjPysXBSHwGKxhW)
   qFUdMDIzOpvreYgTjPysXBSHwGKxho=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.callRequestCookies('Post',qFUdMDIzOpvreYgTjPysXBSHwGKxhc,payload=qFUdMDIzOpvreYgTjPysXBSHwGKxhN,params=qFUdMDIzOpvreYgTjPysXBSHwGKxhC,headers=qFUdMDIzOpvreYgTjPysXBSHwGKxun,cookies=qFUdMDIzOpvreYgTjPysXBSHwGKxun)
   qFUdMDIzOpvreYgTjPysXBSHwGKxhL=json.loads(qFUdMDIzOpvreYgTjPysXBSHwGKxho.text)
   qFUdMDIzOpvreYgTjPysXBSHwGKxhV=qFUdMDIzOpvreYgTjPysXBSHwGKxhL['credential']
   if user_pf!=0:
    qFUdMDIzOpvreYgTjPysXBSHwGKxhN={'id':qFUdMDIzOpvreYgTjPysXBSHwGKxhV,'password':'','profile':qFUdMDIzOpvreYgTjPysXBSHwGKxuC(user_pf),'pushid':'','type':'credential'}
    qFUdMDIzOpvreYgTjPysXBSHwGKxhC['credential']=qFUdMDIzOpvreYgTjPysXBSHwGKxhV 
    qFUdMDIzOpvreYgTjPysXBSHwGKxho=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.callRequestCookies('Post',qFUdMDIzOpvreYgTjPysXBSHwGKxhc,payload=qFUdMDIzOpvreYgTjPysXBSHwGKxhN,params=qFUdMDIzOpvreYgTjPysXBSHwGKxhC,headers=qFUdMDIzOpvreYgTjPysXBSHwGKxun,cookies=qFUdMDIzOpvreYgTjPysXBSHwGKxun)
    qFUdMDIzOpvreYgTjPysXBSHwGKxhL=json.loads(qFUdMDIzOpvreYgTjPysXBSHwGKxho.text)
    qFUdMDIzOpvreYgTjPysXBSHwGKxhV=qFUdMDIzOpvreYgTjPysXBSHwGKxhL['credential']
   if qFUdMDIzOpvreYgTjPysXBSHwGKxhV:qFUdMDIzOpvreYgTjPysXBSHwGKxha=qFUdMDIzOpvreYgTjPysXBSHwGKxuc
  except qFUdMDIzOpvreYgTjPysXBSHwGKxui as exception:
   qFUdMDIzOpvreYgTjPysXBSHwGKxut(exception)
   qFUdMDIzOpvreYgTjPysXBSHwGKxhV='none' 
  qFUdMDIzOpvreYgTjPysXBSHwGKxhn.SaveCredential(qFUdMDIzOpvreYgTjPysXBSHwGKxhV)
  return qFUdMDIzOpvreYgTjPysXBSHwGKxha
 def GetIssue(qFUdMDIzOpvreYgTjPysXBSHwGKxhn):
  qFUdMDIzOpvreYgTjPysXBSHwGKxEh=qFUdMDIzOpvreYgTjPysXBSHwGKxuf
  try:
   qFUdMDIzOpvreYgTjPysXBSHwGKxhW='/guid/issue'
   qFUdMDIzOpvreYgTjPysXBSHwGKxhC=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.GetDefaultParams()
   qFUdMDIzOpvreYgTjPysXBSHwGKxhc=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.makeurl(qFUdMDIzOpvreYgTjPysXBSHwGKxhn.API_DOMAIN,qFUdMDIzOpvreYgTjPysXBSHwGKxhW)
   qFUdMDIzOpvreYgTjPysXBSHwGKxho=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.callRequestCookies('Get',qFUdMDIzOpvreYgTjPysXBSHwGKxhc,payload=qFUdMDIzOpvreYgTjPysXBSHwGKxun,params=qFUdMDIzOpvreYgTjPysXBSHwGKxhC,headers=qFUdMDIzOpvreYgTjPysXBSHwGKxun,cookies=qFUdMDIzOpvreYgTjPysXBSHwGKxun)
   qFUdMDIzOpvreYgTjPysXBSHwGKxhL=json.loads(qFUdMDIzOpvreYgTjPysXBSHwGKxho.text)
   qFUdMDIzOpvreYgTjPysXBSHwGKxEb=qFUdMDIzOpvreYgTjPysXBSHwGKxhL['guid']
   qFUdMDIzOpvreYgTjPysXBSHwGKxEn=qFUdMDIzOpvreYgTjPysXBSHwGKxhL['guidtimestamp']
   if qFUdMDIzOpvreYgTjPysXBSHwGKxEb:qFUdMDIzOpvreYgTjPysXBSHwGKxEh=qFUdMDIzOpvreYgTjPysXBSHwGKxuc
  except qFUdMDIzOpvreYgTjPysXBSHwGKxui as exception:
   qFUdMDIzOpvreYgTjPysXBSHwGKxut(exception)
   qFUdMDIzOpvreYgTjPysXBSHwGKxEb='none'
   qFUdMDIzOpvreYgTjPysXBSHwGKxEn='none' 
  qFUdMDIzOpvreYgTjPysXBSHwGKxhn.guid=qFUdMDIzOpvreYgTjPysXBSHwGKxEb
  qFUdMDIzOpvreYgTjPysXBSHwGKxhn.guidtimestamp=qFUdMDIzOpvreYgTjPysXBSHwGKxEn
  return qFUdMDIzOpvreYgTjPysXBSHwGKxEh
 def GetGnList(qFUdMDIzOpvreYgTjPysXBSHwGKxhn,gn_str):
  qFUdMDIzOpvreYgTjPysXBSHwGKxEu=[]
  try:
   qFUdMDIzOpvreYgTjPysXBSHwGKxhW='/cf/supermultisections/'+gn_str
   qFUdMDIzOpvreYgTjPysXBSHwGKxhC=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.GetDefaultParams()
   qFUdMDIzOpvreYgTjPysXBSHwGKxhc=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.makeurl(qFUdMDIzOpvreYgTjPysXBSHwGKxhn.API_DOMAIN,qFUdMDIzOpvreYgTjPysXBSHwGKxhW)
   qFUdMDIzOpvreYgTjPysXBSHwGKxho=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.callRequestCookies('Get',qFUdMDIzOpvreYgTjPysXBSHwGKxhc,payload=qFUdMDIzOpvreYgTjPysXBSHwGKxun,params=qFUdMDIzOpvreYgTjPysXBSHwGKxhC,headers=qFUdMDIzOpvreYgTjPysXBSHwGKxun,cookies=qFUdMDIzOpvreYgTjPysXBSHwGKxun)
   qFUdMDIzOpvreYgTjPysXBSHwGKxhL=json.loads(qFUdMDIzOpvreYgTjPysXBSHwGKxho.text)
   if not('multisectionlist' in qFUdMDIzOpvreYgTjPysXBSHwGKxhL):return qFUdMDIzOpvreYgTjPysXBSHwGKxun 
   qFUdMDIzOpvreYgTjPysXBSHwGKxEf=qFUdMDIzOpvreYgTjPysXBSHwGKxhL['multisectionlist']
   for qFUdMDIzOpvreYgTjPysXBSHwGKxEV in qFUdMDIzOpvreYgTjPysXBSHwGKxEf:
    qFUdMDIzOpvreYgTjPysXBSHwGKxEC=qFUdMDIzOpvreYgTjPysXBSHwGKxEV['title']
    if qFUdMDIzOpvreYgTjPysXBSHwGKxuR(qFUdMDIzOpvreYgTjPysXBSHwGKxEC)==0:continue
    if qFUdMDIzOpvreYgTjPysXBSHwGKxEC=='minor':continue 
    if re.search(u'베너',qFUdMDIzOpvreYgTjPysXBSHwGKxEC):continue
    qFUdMDIzOpvreYgTjPysXBSHwGKxEC=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',qFUdMDIzOpvreYgTjPysXBSHwGKxEC)
    qFUdMDIzOpvreYgTjPysXBSHwGKxEC=qFUdMDIzOpvreYgTjPysXBSHwGKxEC.lstrip('#')
    for qFUdMDIzOpvreYgTjPysXBSHwGKxEc in qFUdMDIzOpvreYgTjPysXBSHwGKxEV['eventlist'][0]['bodylist']:
     if re.search(r'uicode:',qFUdMDIzOpvreYgTjPysXBSHwGKxEc):
      qFUdMDIzOpvreYgTjPysXBSHwGKxEi={'title':qFUdMDIzOpvreYgTjPysXBSHwGKxEC,'uicode':re.sub(r'uicode:','',qFUdMDIzOpvreYgTjPysXBSHwGKxEc)}
      qFUdMDIzOpvreYgTjPysXBSHwGKxEu.append(qFUdMDIzOpvreYgTjPysXBSHwGKxEi)
      break
  except qFUdMDIzOpvreYgTjPysXBSHwGKxui as exception:
   qFUdMDIzOpvreYgTjPysXBSHwGKxut(exception)
  return qFUdMDIzOpvreYgTjPysXBSHwGKxEu
 def GetDeeplinkList(qFUdMDIzOpvreYgTjPysXBSHwGKxhn,gn_str,came_str,page_int,addinfoyn=qFUdMDIzOpvreYgTjPysXBSHwGKxuf):
  qFUdMDIzOpvreYgTjPysXBSHwGKxEt=[]
  qFUdMDIzOpvreYgTjPysXBSHwGKxER=qFUdMDIzOpvreYgTjPysXBSHwGKxbV=1
  qFUdMDIzOpvreYgTjPysXBSHwGKxEk='quick'
  qFUdMDIzOpvreYgTjPysXBSHwGKxEQ=qFUdMDIzOpvreYgTjPysXBSHwGKxbn=qFUdMDIzOpvreYgTjPysXBSHwGKxbu=''
  qFUdMDIzOpvreYgTjPysXBSHwGKxEl=qFUdMDIzOpvreYgTjPysXBSHwGKxuf
  qFUdMDIzOpvreYgTjPysXBSHwGKxEm={}
  try:
   qFUdMDIzOpvreYgTjPysXBSHwGKxhW='/cf/deeplink/'+gn_str
   qFUdMDIzOpvreYgTjPysXBSHwGKxhC=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.GetDefaultParams()
   qFUdMDIzOpvreYgTjPysXBSHwGKxhc=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.makeurl(qFUdMDIzOpvreYgTjPysXBSHwGKxhn.API_DOMAIN,qFUdMDIzOpvreYgTjPysXBSHwGKxhW)
   qFUdMDIzOpvreYgTjPysXBSHwGKxho=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.callRequestCookies('Get',qFUdMDIzOpvreYgTjPysXBSHwGKxhc,payload=qFUdMDIzOpvreYgTjPysXBSHwGKxun,params=qFUdMDIzOpvreYgTjPysXBSHwGKxhC,headers=qFUdMDIzOpvreYgTjPysXBSHwGKxun,cookies=qFUdMDIzOpvreYgTjPysXBSHwGKxun)
   qFUdMDIzOpvreYgTjPysXBSHwGKxhL=json.loads(qFUdMDIzOpvreYgTjPysXBSHwGKxho.text)
   if not('url' in qFUdMDIzOpvreYgTjPysXBSHwGKxhL):return qFUdMDIzOpvreYgTjPysXBSHwGKxun 
   qFUdMDIzOpvreYgTjPysXBSHwGKxEJ=qFUdMDIzOpvreYgTjPysXBSHwGKxhL['url']
   qFUdMDIzOpvreYgTjPysXBSHwGKxhW=urllib.parse.urlsplit(qFUdMDIzOpvreYgTjPysXBSHwGKxEJ).path
   qFUdMDIzOpvreYgTjPysXBSHwGKxEA=qFUdMDIzOpvreYgTjPysXBSHwGKxuk(urllib.parse.parse_qsl(urllib.parse.urlsplit(qFUdMDIzOpvreYgTjPysXBSHwGKxEJ).query))
   qFUdMDIzOpvreYgTjPysXBSHwGKxEA['came']=came_str 
   qFUdMDIzOpvreYgTjPysXBSHwGKxEA['limit']=qFUdMDIzOpvreYgTjPysXBSHwGKxuC(qFUdMDIzOpvreYgTjPysXBSHwGKxhn.LIST_LIMIT)
   if 'contenttype' in qFUdMDIzOpvreYgTjPysXBSHwGKxEA:qFUdMDIzOpvreYgTjPysXBSHwGKxEk=qFUdMDIzOpvreYgTjPysXBSHwGKxEA['contenttype']
   if came_str=='movie':qFUdMDIzOpvreYgTjPysXBSHwGKxEA['mtype']='svod'
   if page_int!=1:
    qFUdMDIzOpvreYgTjPysXBSHwGKxEA['offset']=qFUdMDIzOpvreYgTjPysXBSHwGKxuC((page_int-1)*qFUdMDIzOpvreYgTjPysXBSHwGKxhn.LIST_LIMIT)
    qFUdMDIzOpvreYgTjPysXBSHwGKxEA['page'] =qFUdMDIzOpvreYgTjPysXBSHwGKxuC(page_int)
   qFUdMDIzOpvreYgTjPysXBSHwGKxhc=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.HTTPTAG+qFUdMDIzOpvreYgTjPysXBSHwGKxhW
   qFUdMDIzOpvreYgTjPysXBSHwGKxEA.update(qFUdMDIzOpvreYgTjPysXBSHwGKxhC)
   qFUdMDIzOpvreYgTjPysXBSHwGKxho=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.callRequestCookies('Get',qFUdMDIzOpvreYgTjPysXBSHwGKxhc,payload=qFUdMDIzOpvreYgTjPysXBSHwGKxun,params=qFUdMDIzOpvreYgTjPysXBSHwGKxEA,headers=qFUdMDIzOpvreYgTjPysXBSHwGKxun,cookies=qFUdMDIzOpvreYgTjPysXBSHwGKxun)
   qFUdMDIzOpvreYgTjPysXBSHwGKxhL=json.loads(qFUdMDIzOpvreYgTjPysXBSHwGKxho.text)
   if not('celllist' in qFUdMDIzOpvreYgTjPysXBSHwGKxhL['cell_toplist']):return qFUdMDIzOpvreYgTjPysXBSHwGKxEt,qFUdMDIzOpvreYgTjPysXBSHwGKxEl 
   qFUdMDIzOpvreYgTjPysXBSHwGKxEa=qFUdMDIzOpvreYgTjPysXBSHwGKxhL['cell_toplist']['celllist']
   if(qFUdMDIzOpvreYgTjPysXBSHwGKxEk=='channel' and came_str=='live'):
    if('genre' in qFUdMDIzOpvreYgTjPysXBSHwGKxEA):
     qFUdMDIzOpvreYgTjPysXBSHwGKxEW=qFUdMDIzOpvreYgTjPysXBSHwGKxEA['genre']
    else:
     qFUdMDIzOpvreYgTjPysXBSHwGKxEW='all'
    qFUdMDIzOpvreYgTjPysXBSHwGKxut("*epgcall*")
    qFUdMDIzOpvreYgTjPysXBSHwGKxEm=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.GetEPGList(qFUdMDIzOpvreYgTjPysXBSHwGKxEW)
   for qFUdMDIzOpvreYgTjPysXBSHwGKxEV in qFUdMDIzOpvreYgTjPysXBSHwGKxEa:
    qFUdMDIzOpvreYgTjPysXBSHwGKxEN=qFUdMDIzOpvreYgTjPysXBSHwGKxEL=thumbnail=''
    qFUdMDIzOpvreYgTjPysXBSHwGKxEN=qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('title_list')[0].get('text')
    if(qFUdMDIzOpvreYgTjPysXBSHwGKxuR(qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('title_list'))>1):
     if(qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('title_list')[1].get('text').startswith('@')):
      for qFUdMDIzOpvreYgTjPysXBSHwGKxEo in qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('bottom_taglist'):
       if qFUdMDIzOpvreYgTjPysXBSHwGKxEo=='playy' or qFUdMDIzOpvreYgTjPysXBSHwGKxEo=='won':qFUdMDIzOpvreYgTjPysXBSHwGKxEL=qFUdMDIzOpvreYgTjPysXBSHwGKxEo
     else:
      qFUdMDIzOpvreYgTjPysXBSHwGKxEL=qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('title_list')[1].get('text')
      qFUdMDIzOpvreYgTjPysXBSHwGKxEL=re.sub(r'(\$O\$)|(\&[a-z]{2}\;)','',qFUdMDIzOpvreYgTjPysXBSHwGKxEL)
    if(qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('thumbnail')!=''):thumbnail='https://%s'%qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('thumbnail')
    qFUdMDIzOpvreYgTjPysXBSHwGKxbh=qFUdMDIzOpvreYgTjPysXBSHwGKxEV['event_list'][1].get('url')
    qFUdMDIzOpvreYgTjPysXBSHwGKxbE=qFUdMDIzOpvreYgTjPysXBSHwGKxuk(urllib.parse.parse_qsl(urllib.parse.urlsplit(qFUdMDIzOpvreYgTjPysXBSHwGKxbh).query))
    if re.search(u'programid=\&',qFUdMDIzOpvreYgTjPysXBSHwGKxbh)and('contentid' in qFUdMDIzOpvreYgTjPysXBSHwGKxbE):
     qFUdMDIzOpvreYgTjPysXBSHwGKxEQ=qFUdMDIzOpvreYgTjPysXBSHwGKxbE['contentid']
     qFUdMDIzOpvreYgTjPysXBSHwGKxbn='direct'
    elif('contentid' in qFUdMDIzOpvreYgTjPysXBSHwGKxbE):
     qFUdMDIzOpvreYgTjPysXBSHwGKxEQ=qFUdMDIzOpvreYgTjPysXBSHwGKxbE['contentid']
     qFUdMDIzOpvreYgTjPysXBSHwGKxbn='contentid'
    elif('programid' in qFUdMDIzOpvreYgTjPysXBSHwGKxbE):
     qFUdMDIzOpvreYgTjPysXBSHwGKxEQ=qFUdMDIzOpvreYgTjPysXBSHwGKxbE['programid']
     qFUdMDIzOpvreYgTjPysXBSHwGKxbn='programid'
     qFUdMDIzOpvreYgTjPysXBSHwGKxEk ='program' 
    elif('channelid' in qFUdMDIzOpvreYgTjPysXBSHwGKxbE):
     qFUdMDIzOpvreYgTjPysXBSHwGKxEQ=qFUdMDIzOpvreYgTjPysXBSHwGKxbE['channelid']
     qFUdMDIzOpvreYgTjPysXBSHwGKxbn='channelid'
     if qFUdMDIzOpvreYgTjPysXBSHwGKxEQ in qFUdMDIzOpvreYgTjPysXBSHwGKxEm:
      qFUdMDIzOpvreYgTjPysXBSHwGKxbu=qFUdMDIzOpvreYgTjPysXBSHwGKxEm[qFUdMDIzOpvreYgTjPysXBSHwGKxEQ]
     else:
      qFUdMDIzOpvreYgTjPysXBSHwGKxbu=''
    elif('movieid' in qFUdMDIzOpvreYgTjPysXBSHwGKxbE):
     qFUdMDIzOpvreYgTjPysXBSHwGKxEQ=qFUdMDIzOpvreYgTjPysXBSHwGKxbE['movieid']
     qFUdMDIzOpvreYgTjPysXBSHwGKxbn='movieid'
     qFUdMDIzOpvreYgTjPysXBSHwGKxEk='movie' 
    else:
     qFUdMDIzOpvreYgTjPysXBSHwGKxEQ ='-'
     qFUdMDIzOpvreYgTjPysXBSHwGKxbn='-'
    qFUdMDIzOpvreYgTjPysXBSHwGKxbf={}
    qFUdMDIzOpvreYgTjPysXBSHwGKxbf['mpaa'] =qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('age')
    try:
     if('channelid' in qFUdMDIzOpvreYgTjPysXBSHwGKxbE):
      qFUdMDIzOpvreYgTjPysXBSHwGKxbf['mediatype'] ='video'
      qFUdMDIzOpvreYgTjPysXBSHwGKxbf['title'] ='%s < %s >'%(qFUdMDIzOpvreYgTjPysXBSHwGKxEN,qFUdMDIzOpvreYgTjPysXBSHwGKxEL)
      qFUdMDIzOpvreYgTjPysXBSHwGKxbf['tvshowtitle']=qFUdMDIzOpvreYgTjPysXBSHwGKxEL
      qFUdMDIzOpvreYgTjPysXBSHwGKxbf['studio'] =qFUdMDIzOpvreYgTjPysXBSHwGKxEN
     elif('movieid' in qFUdMDIzOpvreYgTjPysXBSHwGKxbE):
      qFUdMDIzOpvreYgTjPysXBSHwGKxbf['mediatype'] ='movie'
      qFUdMDIzOpvreYgTjPysXBSHwGKxbf['title'] =title_list
     else:
      qFUdMDIzOpvreYgTjPysXBSHwGKxbf['mediatype'] ='episode'
      qFUdMDIzOpvreYgTjPysXBSHwGKxbf['title'] =title_list
    except:
     qFUdMDIzOpvreYgTjPysXBSHwGKxun
    qFUdMDIzOpvreYgTjPysXBSHwGKxEi={'title':qFUdMDIzOpvreYgTjPysXBSHwGKxEN,'subtitle':qFUdMDIzOpvreYgTjPysXBSHwGKxEL,'thumbnail':thumbnail,'uicode':qFUdMDIzOpvreYgTjPysXBSHwGKxEk,'contentid':qFUdMDIzOpvreYgTjPysXBSHwGKxEQ,'contentidType':qFUdMDIzOpvreYgTjPysXBSHwGKxbn,'viewage':qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('age'),'channelepg':qFUdMDIzOpvreYgTjPysXBSHwGKxbu,'info':qFUdMDIzOpvreYgTjPysXBSHwGKxbf}
    qFUdMDIzOpvreYgTjPysXBSHwGKxEt.append(qFUdMDIzOpvreYgTjPysXBSHwGKxEi)
   qFUdMDIzOpvreYgTjPysXBSHwGKxER=qFUdMDIzOpvreYgTjPysXBSHwGKxuQ(qFUdMDIzOpvreYgTjPysXBSHwGKxhL['cell_toplist']['pagecount'])
   if qFUdMDIzOpvreYgTjPysXBSHwGKxhL['cell_toplist']['count']:qFUdMDIzOpvreYgTjPysXBSHwGKxbV =qFUdMDIzOpvreYgTjPysXBSHwGKxuQ(qFUdMDIzOpvreYgTjPysXBSHwGKxhL['cell_toplist']['count'])
   else:qFUdMDIzOpvreYgTjPysXBSHwGKxbV=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.LIST_LIMIT
   qFUdMDIzOpvreYgTjPysXBSHwGKxEl=qFUdMDIzOpvreYgTjPysXBSHwGKxER>qFUdMDIzOpvreYgTjPysXBSHwGKxbV
  except qFUdMDIzOpvreYgTjPysXBSHwGKxui as exception:
   qFUdMDIzOpvreYgTjPysXBSHwGKxut(exception)
  try:
   if qFUdMDIzOpvreYgTjPysXBSHwGKxEt[0].get('contentidType')=='movieid' and addinfoyn==qFUdMDIzOpvreYgTjPysXBSHwGKxuc:
    qFUdMDIzOpvreYgTjPysXBSHwGKxbC=[]
    qFUdMDIzOpvreYgTjPysXBSHwGKxbc={}
    for qFUdMDIzOpvreYgTjPysXBSHwGKxbi in qFUdMDIzOpvreYgTjPysXBSHwGKxEt:qFUdMDIzOpvreYgTjPysXBSHwGKxbC.append(qFUdMDIzOpvreYgTjPysXBSHwGKxbi.get('contentid'))
    qFUdMDIzOpvreYgTjPysXBSHwGKxbc=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.GetMovieInfoList(qFUdMDIzOpvreYgTjPysXBSHwGKxbC)
    for i in qFUdMDIzOpvreYgTjPysXBSHwGKxuV(qFUdMDIzOpvreYgTjPysXBSHwGKxuR(qFUdMDIzOpvreYgTjPysXBSHwGKxEt)):
     qFUdMDIzOpvreYgTjPysXBSHwGKxEt[i]['info']=qFUdMDIzOpvreYgTjPysXBSHwGKxbc.get(qFUdMDIzOpvreYgTjPysXBSHwGKxEt[i]['contentid'])
  except:
   qFUdMDIzOpvreYgTjPysXBSHwGKxun
  return(qFUdMDIzOpvreYgTjPysXBSHwGKxEt,qFUdMDIzOpvreYgTjPysXBSHwGKxEl)
 def GetEpisodeList(qFUdMDIzOpvreYgTjPysXBSHwGKxhn,qFUdMDIzOpvreYgTjPysXBSHwGKxEQ,qFUdMDIzOpvreYgTjPysXBSHwGKxEk,qFUdMDIzOpvreYgTjPysXBSHwGKxbn,page_int,orderby='desc'):
  qFUdMDIzOpvreYgTjPysXBSHwGKxbt=[]
  qFUdMDIzOpvreYgTjPysXBSHwGKxER=qFUdMDIzOpvreYgTjPysXBSHwGKxbV=1
  qFUdMDIzOpvreYgTjPysXBSHwGKxEl=qFUdMDIzOpvreYgTjPysXBSHwGKxuf
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   qFUdMDIzOpvreYgTjPysXBSHwGKxhC=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.GetDefaultParams()
   if qFUdMDIzOpvreYgTjPysXBSHwGKxbn=='contentid':
    qFUdMDIzOpvreYgTjPysXBSHwGKxhW='/cf/vod/contents/'+qFUdMDIzOpvreYgTjPysXBSHwGKxEQ
    qFUdMDIzOpvreYgTjPysXBSHwGKxhc=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.makeurl(qFUdMDIzOpvreYgTjPysXBSHwGKxhn.API_DOMAIN,qFUdMDIzOpvreYgTjPysXBSHwGKxhW)
    qFUdMDIzOpvreYgTjPysXBSHwGKxho=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.callRequestCookies('Get',qFUdMDIzOpvreYgTjPysXBSHwGKxhc,payload=qFUdMDIzOpvreYgTjPysXBSHwGKxun,params=qFUdMDIzOpvreYgTjPysXBSHwGKxhC,headers=qFUdMDIzOpvreYgTjPysXBSHwGKxun,cookies=qFUdMDIzOpvreYgTjPysXBSHwGKxun)
    qFUdMDIzOpvreYgTjPysXBSHwGKxhL=json.loads(qFUdMDIzOpvreYgTjPysXBSHwGKxho.text)
    if not('programid' in qFUdMDIzOpvreYgTjPysXBSHwGKxhL):return qFUdMDIzOpvreYgTjPysXBSHwGKxun 
    qFUdMDIzOpvreYgTjPysXBSHwGKxbk=qFUdMDIzOpvreYgTjPysXBSHwGKxhL['programid']
   else:
    qFUdMDIzOpvreYgTjPysXBSHwGKxbk=qFUdMDIzOpvreYgTjPysXBSHwGKxEQ
   qFUdMDIzOpvreYgTjPysXBSHwGKxhW='/vod/programs-contents/'+qFUdMDIzOpvreYgTjPysXBSHwGKxbk
   qFUdMDIzOpvreYgTjPysXBSHwGKxEA={'limit':qFUdMDIzOpvreYgTjPysXBSHwGKxhn.EP_LIMIT,'offset':qFUdMDIzOpvreYgTjPysXBSHwGKxuC((page_int-1)*qFUdMDIzOpvreYgTjPysXBSHwGKxhn.EP_LIMIT),'orderby':orderby}
   qFUdMDIzOpvreYgTjPysXBSHwGKxhc=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.makeurl(qFUdMDIzOpvreYgTjPysXBSHwGKxhn.API_DOMAIN,qFUdMDIzOpvreYgTjPysXBSHwGKxhW)
   qFUdMDIzOpvreYgTjPysXBSHwGKxEA.update(qFUdMDIzOpvreYgTjPysXBSHwGKxhC)
   qFUdMDIzOpvreYgTjPysXBSHwGKxho=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.callRequestCookies('Get',qFUdMDIzOpvreYgTjPysXBSHwGKxhc,payload=qFUdMDIzOpvreYgTjPysXBSHwGKxun,params=qFUdMDIzOpvreYgTjPysXBSHwGKxEA,headers=qFUdMDIzOpvreYgTjPysXBSHwGKxun,cookies=qFUdMDIzOpvreYgTjPysXBSHwGKxun)
   qFUdMDIzOpvreYgTjPysXBSHwGKxhL=json.loads(qFUdMDIzOpvreYgTjPysXBSHwGKxho.text)
   if not('list' in qFUdMDIzOpvreYgTjPysXBSHwGKxhL):return qFUdMDIzOpvreYgTjPysXBSHwGKxun 
   qFUdMDIzOpvreYgTjPysXBSHwGKxbQ=qFUdMDIzOpvreYgTjPysXBSHwGKxhL['list']
   for qFUdMDIzOpvreYgTjPysXBSHwGKxEV in qFUdMDIzOpvreYgTjPysXBSHwGKxbQ:
    qFUdMDIzOpvreYgTjPysXBSHwGKxbl =qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('programtitle')
    qFUdMDIzOpvreYgTjPysXBSHwGKxbm ='%s회, %s(%s)'%(qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('episodenumber'),qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('releasedate'),qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('releaseweekday'))
    if(qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('image')!=''):tmp_thumbnail='https://%s'%qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('image')
    qFUdMDIzOpvreYgTjPysXBSHwGKxbJ=qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('synopsis')
    qFUdMDIzOpvreYgTjPysXBSHwGKxbJ=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',qFUdMDIzOpvreYgTjPysXBSHwGKxbJ)
    qFUdMDIzOpvreYgTjPysXBSHwGKxbf={}
    qFUdMDIzOpvreYgTjPysXBSHwGKxbf['title'] =qFUdMDIzOpvreYgTjPysXBSHwGKxbl
    qFUdMDIzOpvreYgTjPysXBSHwGKxbf['mediatype']='episode' 
    qFUdMDIzOpvreYgTjPysXBSHwGKxbf['mpaa'] =qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('targetage')
    try:
     if 'episodenumber' in qFUdMDIzOpvreYgTjPysXBSHwGKxEV:qFUdMDIzOpvreYgTjPysXBSHwGKxbf['episode'] =qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('episodenumber')
     if 'releasedate' in qFUdMDIzOpvreYgTjPysXBSHwGKxEV:qFUdMDIzOpvreYgTjPysXBSHwGKxbf['year'] =qFUdMDIzOpvreYgTjPysXBSHwGKxuQ(qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('releasedate')[:4])
     if 'releasedate' in qFUdMDIzOpvreYgTjPysXBSHwGKxEV:qFUdMDIzOpvreYgTjPysXBSHwGKxbf['aired'] =qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('releasedate')
     if 'playtime' in qFUdMDIzOpvreYgTjPysXBSHwGKxEV:qFUdMDIzOpvreYgTjPysXBSHwGKxbf['duration']=qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('playtime')
     if 'episodeactors' in qFUdMDIzOpvreYgTjPysXBSHwGKxEV:
      if qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('episodeactors')!='':qFUdMDIzOpvreYgTjPysXBSHwGKxbf['cast']=qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('episodeactors').split(',')
    except:
     qFUdMDIzOpvreYgTjPysXBSHwGKxun
    qFUdMDIzOpvreYgTjPysXBSHwGKxbA={'title':qFUdMDIzOpvreYgTjPysXBSHwGKxbl,'subtitle':qFUdMDIzOpvreYgTjPysXBSHwGKxbm,'thumbnail':tmp_thumbnail,'uicode':qFUdMDIzOpvreYgTjPysXBSHwGKxEk,'contentid':qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('contentid'),'programid':qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('programid'),'synopsis':qFUdMDIzOpvreYgTjPysXBSHwGKxbJ,'viewage':qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('targetage'),'info':qFUdMDIzOpvreYgTjPysXBSHwGKxbf}
    qFUdMDIzOpvreYgTjPysXBSHwGKxbt.append(qFUdMDIzOpvreYgTjPysXBSHwGKxbA)
   qFUdMDIzOpvreYgTjPysXBSHwGKxER=qFUdMDIzOpvreYgTjPysXBSHwGKxuQ(qFUdMDIzOpvreYgTjPysXBSHwGKxhL['pagecount'])
   if qFUdMDIzOpvreYgTjPysXBSHwGKxhL['count']:qFUdMDIzOpvreYgTjPysXBSHwGKxbV =qFUdMDIzOpvreYgTjPysXBSHwGKxuQ(qFUdMDIzOpvreYgTjPysXBSHwGKxhL['count'])
   else:qFUdMDIzOpvreYgTjPysXBSHwGKxbV=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.EP_LIMIT
   qFUdMDIzOpvreYgTjPysXBSHwGKxEl=qFUdMDIzOpvreYgTjPysXBSHwGKxER>qFUdMDIzOpvreYgTjPysXBSHwGKxbV
  except qFUdMDIzOpvreYgTjPysXBSHwGKxui as exception:
   qFUdMDIzOpvreYgTjPysXBSHwGKxut(exception)
  return(qFUdMDIzOpvreYgTjPysXBSHwGKxbt,qFUdMDIzOpvreYgTjPysXBSHwGKxEl)
 def GetMyviewList(qFUdMDIzOpvreYgTjPysXBSHwGKxhn,qFUdMDIzOpvreYgTjPysXBSHwGKxEk,page_int,addinfoyn=qFUdMDIzOpvreYgTjPysXBSHwGKxuf):
  qFUdMDIzOpvreYgTjPysXBSHwGKxba=[]
  qFUdMDIzOpvreYgTjPysXBSHwGKxER=qFUdMDIzOpvreYgTjPysXBSHwGKxbV=1
  qFUdMDIzOpvreYgTjPysXBSHwGKxEl=qFUdMDIzOpvreYgTjPysXBSHwGKxuf
  try:
   qFUdMDIzOpvreYgTjPysXBSHwGKxhC=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.GetDefaultParams()
   qFUdMDIzOpvreYgTjPysXBSHwGKxhW='/myview/contents'
   qFUdMDIzOpvreYgTjPysXBSHwGKxEA={'contenttype':qFUdMDIzOpvreYgTjPysXBSHwGKxEk,'limit':qFUdMDIzOpvreYgTjPysXBSHwGKxhn.MV_LIMIT,'offset':qFUdMDIzOpvreYgTjPysXBSHwGKxuC((page_int-1)*qFUdMDIzOpvreYgTjPysXBSHwGKxhn.MV_LIMIT),'orderby':'new'}
   qFUdMDIzOpvreYgTjPysXBSHwGKxhc=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.makeurl(qFUdMDIzOpvreYgTjPysXBSHwGKxhn.API_DOMAIN,qFUdMDIzOpvreYgTjPysXBSHwGKxhW)
   qFUdMDIzOpvreYgTjPysXBSHwGKxEA.update(qFUdMDIzOpvreYgTjPysXBSHwGKxhC)
   qFUdMDIzOpvreYgTjPysXBSHwGKxho=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.callRequestCookies('Get',qFUdMDIzOpvreYgTjPysXBSHwGKxhc,payload=qFUdMDIzOpvreYgTjPysXBSHwGKxun,params=qFUdMDIzOpvreYgTjPysXBSHwGKxEA,headers=qFUdMDIzOpvreYgTjPysXBSHwGKxun,cookies=qFUdMDIzOpvreYgTjPysXBSHwGKxun)
   qFUdMDIzOpvreYgTjPysXBSHwGKxhL=json.loads(qFUdMDIzOpvreYgTjPysXBSHwGKxho.text)
   if not('list' in qFUdMDIzOpvreYgTjPysXBSHwGKxhL[0]):return qFUdMDIzOpvreYgTjPysXBSHwGKxun 
   qFUdMDIzOpvreYgTjPysXBSHwGKxbW=qFUdMDIzOpvreYgTjPysXBSHwGKxhL[0]['list']
   for qFUdMDIzOpvreYgTjPysXBSHwGKxEV in qFUdMDIzOpvreYgTjPysXBSHwGKxbW:
    qFUdMDIzOpvreYgTjPysXBSHwGKxbf={}
    if qFUdMDIzOpvreYgTjPysXBSHwGKxEk=='vod':
     qFUdMDIzOpvreYgTjPysXBSHwGKxbl =qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('programtitle')
     qFUdMDIzOpvreYgTjPysXBSHwGKxbm='%s회, %s'%(qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('episodenumber'),qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('releasedate'))
     qFUdMDIzOpvreYgTjPysXBSHwGKxEQ=qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('contentid')
     qFUdMDIzOpvreYgTjPysXBSHwGKxbk=qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('programid')
     qFUdMDIzOpvreYgTjPysXBSHwGKxbf['title'] =qFUdMDIzOpvreYgTjPysXBSHwGKxbl
     qFUdMDIzOpvreYgTjPysXBSHwGKxbf['mediatype']='episode' 
     qFUdMDIzOpvreYgTjPysXBSHwGKxbf['mpaa'] =qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('targetage')
     try:
      qFUdMDIzOpvreYgTjPysXBSHwGKxbf['studio'] =qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('channelname')
     except:
      qFUdMDIzOpvreYgTjPysXBSHwGKxun
     try:
      if 'releasedate' in qFUdMDIzOpvreYgTjPysXBSHwGKxEV:qFUdMDIzOpvreYgTjPysXBSHwGKxbf['year'] =qFUdMDIzOpvreYgTjPysXBSHwGKxuQ(qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('releasedate')[:4])
      if 'releasedate' in qFUdMDIzOpvreYgTjPysXBSHwGKxEV:qFUdMDIzOpvreYgTjPysXBSHwGKxbf['aired'] =qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('releasedate')
     except:
      qFUdMDIzOpvreYgTjPysXBSHwGKxun
    else:
     qFUdMDIzOpvreYgTjPysXBSHwGKxbl =qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('title')
     qFUdMDIzOpvreYgTjPysXBSHwGKxbm='' 
     qFUdMDIzOpvreYgTjPysXBSHwGKxEQ=qFUdMDIzOpvreYgTjPysXBSHwGKxbk=qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('movieid')
     qFUdMDIzOpvreYgTjPysXBSHwGKxbf['title'] =qFUdMDIzOpvreYgTjPysXBSHwGKxbl
     qFUdMDIzOpvreYgTjPysXBSHwGKxbf['mediatype']='movie' 
     qFUdMDIzOpvreYgTjPysXBSHwGKxbf['mpaa'] =qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('targetage')
     try:
      if 'releasedate' in qFUdMDIzOpvreYgTjPysXBSHwGKxEV:qFUdMDIzOpvreYgTjPysXBSHwGKxbf['year'] =qFUdMDIzOpvreYgTjPysXBSHwGKxuQ(qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('releasedate')[:4])
      if 'releasedate' in qFUdMDIzOpvreYgTjPysXBSHwGKxEV:qFUdMDIzOpvreYgTjPysXBSHwGKxbf['aired'] =qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('releasedate')
     except:
      qFUdMDIzOpvreYgTjPysXBSHwGKxun
    if(qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('image')!=''):tmp_thumbnail='https://%s'%qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('image')
    qFUdMDIzOpvreYgTjPysXBSHwGKxbN={'title':qFUdMDIzOpvreYgTjPysXBSHwGKxbl,'subtitle':qFUdMDIzOpvreYgTjPysXBSHwGKxbm,'thumbnail':tmp_thumbnail,'uicode':qFUdMDIzOpvreYgTjPysXBSHwGKxEk,'contentid':qFUdMDIzOpvreYgTjPysXBSHwGKxEQ,'programid':qFUdMDIzOpvreYgTjPysXBSHwGKxbk,'viewage':qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('targetage'),'info':qFUdMDIzOpvreYgTjPysXBSHwGKxbf}
    qFUdMDIzOpvreYgTjPysXBSHwGKxba.append(qFUdMDIzOpvreYgTjPysXBSHwGKxbN)
   qFUdMDIzOpvreYgTjPysXBSHwGKxER=qFUdMDIzOpvreYgTjPysXBSHwGKxuQ(qFUdMDIzOpvreYgTjPysXBSHwGKxhL[0]['pagecount'])
   if qFUdMDIzOpvreYgTjPysXBSHwGKxhL[0]['count']:qFUdMDIzOpvreYgTjPysXBSHwGKxbV =qFUdMDIzOpvreYgTjPysXBSHwGKxuQ(qFUdMDIzOpvreYgTjPysXBSHwGKxhL[0]['count'])
   else:qFUdMDIzOpvreYgTjPysXBSHwGKxbV=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.MV_LIMIT
   qFUdMDIzOpvreYgTjPysXBSHwGKxEl=qFUdMDIzOpvreYgTjPysXBSHwGKxER>qFUdMDIzOpvreYgTjPysXBSHwGKxbV
  except qFUdMDIzOpvreYgTjPysXBSHwGKxui as exception:
   qFUdMDIzOpvreYgTjPysXBSHwGKxut(exception)
  try:
   if qFUdMDIzOpvreYgTjPysXBSHwGKxEk=='movie' and addinfoyn==qFUdMDIzOpvreYgTjPysXBSHwGKxuc:
    qFUdMDIzOpvreYgTjPysXBSHwGKxbC=[]
    qFUdMDIzOpvreYgTjPysXBSHwGKxbc={}
    for qFUdMDIzOpvreYgTjPysXBSHwGKxbi in qFUdMDIzOpvreYgTjPysXBSHwGKxba:qFUdMDIzOpvreYgTjPysXBSHwGKxbC.append(qFUdMDIzOpvreYgTjPysXBSHwGKxbi.get('contentid'))
    qFUdMDIzOpvreYgTjPysXBSHwGKxbc=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.GetMovieInfoList(qFUdMDIzOpvreYgTjPysXBSHwGKxbC)
    for i in qFUdMDIzOpvreYgTjPysXBSHwGKxuV(qFUdMDIzOpvreYgTjPysXBSHwGKxuR(qFUdMDIzOpvreYgTjPysXBSHwGKxba)):
     qFUdMDIzOpvreYgTjPysXBSHwGKxba[i]['info']=qFUdMDIzOpvreYgTjPysXBSHwGKxbc.get(qFUdMDIzOpvreYgTjPysXBSHwGKxba[i]['contentid'])
  except:
   qFUdMDIzOpvreYgTjPysXBSHwGKxun
  return qFUdMDIzOpvreYgTjPysXBSHwGKxba,qFUdMDIzOpvreYgTjPysXBSHwGKxEl
 def GetSearchList(qFUdMDIzOpvreYgTjPysXBSHwGKxhn,search_key,genre,page_int,exclusion21=qFUdMDIzOpvreYgTjPysXBSHwGKxuf,addinfoyn=qFUdMDIzOpvreYgTjPysXBSHwGKxuf):
  qFUdMDIzOpvreYgTjPysXBSHwGKxbo=[]
  qFUdMDIzOpvreYgTjPysXBSHwGKxER=qFUdMDIzOpvreYgTjPysXBSHwGKxbV=1
  qFUdMDIzOpvreYgTjPysXBSHwGKxEl=qFUdMDIzOpvreYgTjPysXBSHwGKxuf
  try:
   qFUdMDIzOpvreYgTjPysXBSHwGKxhC=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.GetDefaultParams()
   qFUdMDIzOpvreYgTjPysXBSHwGKxhW='/cf/search/list.js'
   qFUdMDIzOpvreYgTjPysXBSHwGKxEA={'type':'program' if genre=='vod' else 'movie','keyword':search_key,'offset':qFUdMDIzOpvreYgTjPysXBSHwGKxuC((page_int-1)*qFUdMDIzOpvreYgTjPysXBSHwGKxhn.LIST_LIMIT),'limit':qFUdMDIzOpvreYgTjPysXBSHwGKxhn.LIST_LIMIT,'orderby':'score','isplayymovie':'y'}
   qFUdMDIzOpvreYgTjPysXBSHwGKxhc=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.makeurl(qFUdMDIzOpvreYgTjPysXBSHwGKxhn.API_DOMAIN,qFUdMDIzOpvreYgTjPysXBSHwGKxhW)
   qFUdMDIzOpvreYgTjPysXBSHwGKxEA.update(qFUdMDIzOpvreYgTjPysXBSHwGKxhC)
   qFUdMDIzOpvreYgTjPysXBSHwGKxho=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.callRequestCookies('Get',qFUdMDIzOpvreYgTjPysXBSHwGKxhc,payload=qFUdMDIzOpvreYgTjPysXBSHwGKxun,params=qFUdMDIzOpvreYgTjPysXBSHwGKxEA,headers=qFUdMDIzOpvreYgTjPysXBSHwGKxun,cookies=qFUdMDIzOpvreYgTjPysXBSHwGKxun)
   qFUdMDIzOpvreYgTjPysXBSHwGKxhL=json.loads(qFUdMDIzOpvreYgTjPysXBSHwGKxho.text)
   if not('celllist' in qFUdMDIzOpvreYgTjPysXBSHwGKxhL['cell_toplist']):return qFUdMDIzOpvreYgTjPysXBSHwGKxbo,qFUdMDIzOpvreYgTjPysXBSHwGKxEl
   qFUdMDIzOpvreYgTjPysXBSHwGKxbL=qFUdMDIzOpvreYgTjPysXBSHwGKxhL['cell_toplist']['celllist']
   for qFUdMDIzOpvreYgTjPysXBSHwGKxEV in qFUdMDIzOpvreYgTjPysXBSHwGKxbL:
    qFUdMDIzOpvreYgTjPysXBSHwGKxbf={}
    qFUdMDIzOpvreYgTjPysXBSHwGKxbl =qFUdMDIzOpvreYgTjPysXBSHwGKxEV['title_list'][0]['text']
    if(qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('thumbnail')!=''):tmp_thumbnail='https://%s'%qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('thumbnail')
    for qFUdMDIzOpvreYgTjPysXBSHwGKxEc in qFUdMDIzOpvreYgTjPysXBSHwGKxEV['event_list'][0]['bodylist']:
     if re.search(r'uicode:',qFUdMDIzOpvreYgTjPysXBSHwGKxEc):
      if genre=='vod':
       qFUdMDIzOpvreYgTjPysXBSHwGKxEQ=''
       qFUdMDIzOpvreYgTjPysXBSHwGKxbk=re.sub(r'uicode:','',qFUdMDIzOpvreYgTjPysXBSHwGKxEc)
       qFUdMDIzOpvreYgTjPysXBSHwGKxbf['mediatype']='episode' 
      else:
       qFUdMDIzOpvreYgTjPysXBSHwGKxEQ=re.sub(r'uicode:','',qFUdMDIzOpvreYgTjPysXBSHwGKxEc)
       qFUdMDIzOpvreYgTjPysXBSHwGKxbk=''
       if qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('bottom_taglist')[0]=='playy':
        qFUdMDIzOpvreYgTjPysXBSHwGKxbl+=' [playy]'
       qFUdMDIzOpvreYgTjPysXBSHwGKxbf['mediatype']='movie' 
      qFUdMDIzOpvreYgTjPysXBSHwGKxbf['title'] =qFUdMDIzOpvreYgTjPysXBSHwGKxEV['title_list'][0]['text']
      qFUdMDIzOpvreYgTjPysXBSHwGKxbf['mpaa'] =qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('age')
      qFUdMDIzOpvreYgTjPysXBSHwGKxbN={'title':qFUdMDIzOpvreYgTjPysXBSHwGKxbl,'thumbnail':tmp_thumbnail,'uicode':genre,'contentid':qFUdMDIzOpvreYgTjPysXBSHwGKxEQ,'programid':qFUdMDIzOpvreYgTjPysXBSHwGKxbk,'viewage':qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('age'),'info':qFUdMDIzOpvreYgTjPysXBSHwGKxbf}
    if exclusion21==qFUdMDIzOpvreYgTjPysXBSHwGKxuf or qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('age')!='21':
     qFUdMDIzOpvreYgTjPysXBSHwGKxbo.append(qFUdMDIzOpvreYgTjPysXBSHwGKxbN)
   qFUdMDIzOpvreYgTjPysXBSHwGKxER=qFUdMDIzOpvreYgTjPysXBSHwGKxuQ(qFUdMDIzOpvreYgTjPysXBSHwGKxhL['cell_toplist']['pagecount'])
   if qFUdMDIzOpvreYgTjPysXBSHwGKxhL['cell_toplist']['count']:qFUdMDIzOpvreYgTjPysXBSHwGKxbV =qFUdMDIzOpvreYgTjPysXBSHwGKxuQ(qFUdMDIzOpvreYgTjPysXBSHwGKxhL['cell_toplist']['count'])
   else:qFUdMDIzOpvreYgTjPysXBSHwGKxbV=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.LIST_LIMIT
   qFUdMDIzOpvreYgTjPysXBSHwGKxEl=qFUdMDIzOpvreYgTjPysXBSHwGKxER>qFUdMDIzOpvreYgTjPysXBSHwGKxbV
  except qFUdMDIzOpvreYgTjPysXBSHwGKxui as exception:
   qFUdMDIzOpvreYgTjPysXBSHwGKxut(exception)
  try:
   if genre=='movie' and addinfoyn==qFUdMDIzOpvreYgTjPysXBSHwGKxuc:
    qFUdMDIzOpvreYgTjPysXBSHwGKxbC=[]
    qFUdMDIzOpvreYgTjPysXBSHwGKxbc={}
    for qFUdMDIzOpvreYgTjPysXBSHwGKxbi in qFUdMDIzOpvreYgTjPysXBSHwGKxbo:qFUdMDIzOpvreYgTjPysXBSHwGKxbC.append(qFUdMDIzOpvreYgTjPysXBSHwGKxbi.get('contentid'))
    qFUdMDIzOpvreYgTjPysXBSHwGKxbc=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.GetMovieInfoList(qFUdMDIzOpvreYgTjPysXBSHwGKxbC)
    for i in qFUdMDIzOpvreYgTjPysXBSHwGKxuV(qFUdMDIzOpvreYgTjPysXBSHwGKxuR(qFUdMDIzOpvreYgTjPysXBSHwGKxbo)):
     qFUdMDIzOpvreYgTjPysXBSHwGKxbo[i]['info']=qFUdMDIzOpvreYgTjPysXBSHwGKxbc.get(qFUdMDIzOpvreYgTjPysXBSHwGKxbo[i]['contentid'])
  except:
   qFUdMDIzOpvreYgTjPysXBSHwGKxun
  return qFUdMDIzOpvreYgTjPysXBSHwGKxbo,qFUdMDIzOpvreYgTjPysXBSHwGKxEl 
 def GetGenreGroup(qFUdMDIzOpvreYgTjPysXBSHwGKxhn,maintype,subtype,qFUdMDIzOpvreYgTjPysXBSHwGKxbR,ordernm,exclusion21=qFUdMDIzOpvreYgTjPysXBSHwGKxuf):
  qFUdMDIzOpvreYgTjPysXBSHwGKxnh=[]
  try:
   qFUdMDIzOpvreYgTjPysXBSHwGKxhC=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.GetDefaultParams()
   qFUdMDIzOpvreYgTjPysXBSHwGKxhW='/cf/filters'
   qFUdMDIzOpvreYgTjPysXBSHwGKxEA={'type':maintype}
   qFUdMDIzOpvreYgTjPysXBSHwGKxhc=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.makeurl(qFUdMDIzOpvreYgTjPysXBSHwGKxhn.API_DOMAIN,qFUdMDIzOpvreYgTjPysXBSHwGKxhW)
   qFUdMDIzOpvreYgTjPysXBSHwGKxEA.update(qFUdMDIzOpvreYgTjPysXBSHwGKxhC)
   qFUdMDIzOpvreYgTjPysXBSHwGKxho=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.callRequestCookies('Get',qFUdMDIzOpvreYgTjPysXBSHwGKxhc,payload=qFUdMDIzOpvreYgTjPysXBSHwGKxun,params=qFUdMDIzOpvreYgTjPysXBSHwGKxEA,headers=qFUdMDIzOpvreYgTjPysXBSHwGKxun,cookies=qFUdMDIzOpvreYgTjPysXBSHwGKxun)
   qFUdMDIzOpvreYgTjPysXBSHwGKxhL=json.loads(qFUdMDIzOpvreYgTjPysXBSHwGKxho.text)
   if not(maintype in qFUdMDIzOpvreYgTjPysXBSHwGKxhL):return qFUdMDIzOpvreYgTjPysXBSHwGKxun 
   qFUdMDIzOpvreYgTjPysXBSHwGKxnE=qFUdMDIzOpvreYgTjPysXBSHwGKxhL[maintype]
   if subtype=='-':
    for qFUdMDIzOpvreYgTjPysXBSHwGKxEV in qFUdMDIzOpvreYgTjPysXBSHwGKxnE:
     qFUdMDIzOpvreYgTjPysXBSHwGKxnb=qFUdMDIzOpvreYgTjPysXBSHwGKxuk(urllib.parse.parse_qsl(urllib.parse.urlsplit(qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('url')).query))
     qFUdMDIzOpvreYgTjPysXBSHwGKxbN={'title':qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('text'),'genre':qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('id'),'subgenre':'-','adult':qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('adult'),'broadcastid':qFUdMDIzOpvreYgTjPysXBSHwGKxnb.get('broadcastid'),'contenttype':qFUdMDIzOpvreYgTjPysXBSHwGKxnb.get('contenttype'),'uiparent':qFUdMDIzOpvreYgTjPysXBSHwGKxnb.get('uiparent'),'uirank':qFUdMDIzOpvreYgTjPysXBSHwGKxnb.get('uirank'),'uitype':qFUdMDIzOpvreYgTjPysXBSHwGKxnb.get('uitype'),'orderby':qFUdMDIzOpvreYgTjPysXBSHwGKxbR,'ordernm':ordernm}
     if exclusion21==qFUdMDIzOpvreYgTjPysXBSHwGKxuf or qFUdMDIzOpvreYgTjPysXBSHwGKxbN.get('adult')=='n':
      qFUdMDIzOpvreYgTjPysXBSHwGKxnh.append(qFUdMDIzOpvreYgTjPysXBSHwGKxbN)
   else:
    for qFUdMDIzOpvreYgTjPysXBSHwGKxEV in qFUdMDIzOpvreYgTjPysXBSHwGKxnE:
     if qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('id')==subtype:
      for tt in qFUdMDIzOpvreYgTjPysXBSHwGKxEV['sublist']:
       qFUdMDIzOpvreYgTjPysXBSHwGKxnb=qFUdMDIzOpvreYgTjPysXBSHwGKxuk(urlparse.parse_qsl(urlparse.urlsplit(tt.get('url')).query))
       qFUdMDIzOpvreYgTjPysXBSHwGKxbN={'title':tt.get('text'),'genre':subtype,'subgenre':tt.get('id'),'adult':tt.get('adult'),'broadcastid':qFUdMDIzOpvreYgTjPysXBSHwGKxnb.get('broadcastid'),'contenttype':qFUdMDIzOpvreYgTjPysXBSHwGKxnb.get('contenttype'),'uiparent':qFUdMDIzOpvreYgTjPysXBSHwGKxnb.get('uiparent'),'uirank':qFUdMDIzOpvreYgTjPysXBSHwGKxnb.get('uirank'),'uitype':qFUdMDIzOpvreYgTjPysXBSHwGKxnb.get('uitype'),'orderby':qFUdMDIzOpvreYgTjPysXBSHwGKxbR,'ordernm':ordernm}
       qFUdMDIzOpvreYgTjPysXBSHwGKxnh.append(qFUdMDIzOpvreYgTjPysXBSHwGKxbN)
      break
  except qFUdMDIzOpvreYgTjPysXBSHwGKxui as exception:
   qFUdMDIzOpvreYgTjPysXBSHwGKxut(exception)
  return qFUdMDIzOpvreYgTjPysXBSHwGKxnh
 def GetGenreGroup_sub(qFUdMDIzOpvreYgTjPysXBSHwGKxhn,in_params):
  qFUdMDIzOpvreYgTjPysXBSHwGKxnh=[]
  try:
   qFUdMDIzOpvreYgTjPysXBSHwGKxhC=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.GetDefaultParams()
   qFUdMDIzOpvreYgTjPysXBSHwGKxhW='/cf/vod/newcontents'
   qFUdMDIzOpvreYgTjPysXBSHwGKxEA={'WeekDay':'all','limit':'20','offset':'0','orderby':in_params.get('orderby'),'adult':in_params.get('adult'),'broadcastid':in_params.get('broadcastid'),'contenttype':in_params.get('contenttype'),'genre':in_params.get('genre'),'uiparent':in_params.get('uiparent'),'uirank':in_params.get('uirank'),'uitype':in_params.get('uitype')}
   qFUdMDIzOpvreYgTjPysXBSHwGKxhc=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.makeurl(qFUdMDIzOpvreYgTjPysXBSHwGKxhn.API_DOMAIN,qFUdMDIzOpvreYgTjPysXBSHwGKxhW)
   qFUdMDIzOpvreYgTjPysXBSHwGKxEA.update(qFUdMDIzOpvreYgTjPysXBSHwGKxhC)
   qFUdMDIzOpvreYgTjPysXBSHwGKxho=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.callRequestCookies('Get',qFUdMDIzOpvreYgTjPysXBSHwGKxhc,payload=qFUdMDIzOpvreYgTjPysXBSHwGKxun,params=qFUdMDIzOpvreYgTjPysXBSHwGKxEA,headers=qFUdMDIzOpvreYgTjPysXBSHwGKxun,cookies=qFUdMDIzOpvreYgTjPysXBSHwGKxun)
   qFUdMDIzOpvreYgTjPysXBSHwGKxhL=json.loads(qFUdMDIzOpvreYgTjPysXBSHwGKxho.text)
   if not('filter_item_list' in qFUdMDIzOpvreYgTjPysXBSHwGKxhL['filter']['filterlist'][1]):return qFUdMDIzOpvreYgTjPysXBSHwGKxun 
   qFUdMDIzOpvreYgTjPysXBSHwGKxnE=qFUdMDIzOpvreYgTjPysXBSHwGKxhL['filter']['filterlist'][1]['filter_item_list']
   for qFUdMDIzOpvreYgTjPysXBSHwGKxEV in qFUdMDIzOpvreYgTjPysXBSHwGKxnE:
    qFUdMDIzOpvreYgTjPysXBSHwGKxbN={'broadcastid':in_params.get('broadcastid'),'contenttype':in_params.get('contenttype'),'genre':in_params.get('genre'),'uiparent':in_params.get('uiparent'),'uirank':in_params.get('uirank'),'uitype':in_params.get('uitype'),'adult':qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('adult'),'title':qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('title'),'subgenre':qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('api_parameters')[qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('api_parameters').find('=')+1:],'orderby':in_params.get('orderby')}
    qFUdMDIzOpvreYgTjPysXBSHwGKxnh.append(qFUdMDIzOpvreYgTjPysXBSHwGKxbN)
  except qFUdMDIzOpvreYgTjPysXBSHwGKxui as exception:
   qFUdMDIzOpvreYgTjPysXBSHwGKxut(exception)
  return qFUdMDIzOpvreYgTjPysXBSHwGKxnh
 def GetGenreList(qFUdMDIzOpvreYgTjPysXBSHwGKxhn,genre,in_params,page_int,addinfoyn=qFUdMDIzOpvreYgTjPysXBSHwGKxuf):
  qFUdMDIzOpvreYgTjPysXBSHwGKxnh=[]
  qFUdMDIzOpvreYgTjPysXBSHwGKxER=qFUdMDIzOpvreYgTjPysXBSHwGKxbV=1
  qFUdMDIzOpvreYgTjPysXBSHwGKxEl=qFUdMDIzOpvreYgTjPysXBSHwGKxuf
  try:
   qFUdMDIzOpvreYgTjPysXBSHwGKxhC=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.GetDefaultParams()
   qFUdMDIzOpvreYgTjPysXBSHwGKxEA={'WeekDay':'all','adult':in_params.get('adult'),'broadcastid':in_params.get('broadcastid'),'contenttype':in_params.get('contenttype'),'genre':in_params.get('genre'),'orderby':in_params.get('orderby'),'uiparent':in_params.get('uiparent'),'uirank':in_params.get('uirank'),'uitype':in_params.get('uitype')}
   if genre=='vodgenre':
    qFUdMDIzOpvreYgTjPysXBSHwGKxhW='/cf/vod/newcontents'
    if in_params.get('subgenre')!='-':
     qFUdMDIzOpvreYgTjPysXBSHwGKxEA['subgenre']=in_params.get('subgenre')
   else:
    qFUdMDIzOpvreYgTjPysXBSHwGKxhW='/cf/movie/contents'
    qFUdMDIzOpvreYgTjPysXBSHwGKxEA['price'] ='all'
    qFUdMDIzOpvreYgTjPysXBSHwGKxEA['sptheme']='svod' 
   qFUdMDIzOpvreYgTjPysXBSHwGKxEA['limit']=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.LIST_LIMIT
   qFUdMDIzOpvreYgTjPysXBSHwGKxEA['offset']=qFUdMDIzOpvreYgTjPysXBSHwGKxuC((page_int-1)*qFUdMDIzOpvreYgTjPysXBSHwGKxhn.LIST_LIMIT)
   qFUdMDIzOpvreYgTjPysXBSHwGKxEA['page'] =qFUdMDIzOpvreYgTjPysXBSHwGKxuC(page_int)
   qFUdMDIzOpvreYgTjPysXBSHwGKxhc=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.makeurl(qFUdMDIzOpvreYgTjPysXBSHwGKxhn.API_DOMAIN,qFUdMDIzOpvreYgTjPysXBSHwGKxhW)
   qFUdMDIzOpvreYgTjPysXBSHwGKxEA.update(qFUdMDIzOpvreYgTjPysXBSHwGKxhC)
   qFUdMDIzOpvreYgTjPysXBSHwGKxho=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.callRequestCookies('Get',qFUdMDIzOpvreYgTjPysXBSHwGKxhc,payload=qFUdMDIzOpvreYgTjPysXBSHwGKxun,params=qFUdMDIzOpvreYgTjPysXBSHwGKxEA,headers=qFUdMDIzOpvreYgTjPysXBSHwGKxun,cookies=qFUdMDIzOpvreYgTjPysXBSHwGKxun)
   qFUdMDIzOpvreYgTjPysXBSHwGKxhL=json.loads(qFUdMDIzOpvreYgTjPysXBSHwGKxho.text)
   if not('celllist' in qFUdMDIzOpvreYgTjPysXBSHwGKxhL['cell_toplist']):return qFUdMDIzOpvreYgTjPysXBSHwGKxun 
   qFUdMDIzOpvreYgTjPysXBSHwGKxnE=qFUdMDIzOpvreYgTjPysXBSHwGKxhL['cell_toplist']['celllist']
   for qFUdMDIzOpvreYgTjPysXBSHwGKxEV in qFUdMDIzOpvreYgTjPysXBSHwGKxnE:
    qFUdMDIzOpvreYgTjPysXBSHwGKxbf={}
    qFUdMDIzOpvreYgTjPysXBSHwGKxbl=tmp_thumbnail=''
    qFUdMDIzOpvreYgTjPysXBSHwGKxbl =qFUdMDIzOpvreYgTjPysXBSHwGKxEV['title_list'][0]['text']
    if(qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('thumbnail')!=''):tmp_thumbnail='https://%s'%qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('thumbnail')
    for qFUdMDIzOpvreYgTjPysXBSHwGKxEc in qFUdMDIzOpvreYgTjPysXBSHwGKxEV['event_list'][0]['bodylist']:
     if re.search(r'uicode:',qFUdMDIzOpvreYgTjPysXBSHwGKxEc):
      qFUdMDIzOpvreYgTjPysXBSHwGKxbf['title'] =qFUdMDIzOpvreYgTjPysXBSHwGKxbl
      qFUdMDIzOpvreYgTjPysXBSHwGKxbf['mpaa'] =qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('age')
      if genre=='moviegenre_svod':
       qFUdMDIzOpvreYgTjPysXBSHwGKxbf['mediatype']='movie' 
      else:
       qFUdMDIzOpvreYgTjPysXBSHwGKxbf['mediatype']='episode' 
      qFUdMDIzOpvreYgTjPysXBSHwGKxbN={'title':qFUdMDIzOpvreYgTjPysXBSHwGKxbl,'uicode':re.sub(r'uicode:','',qFUdMDIzOpvreYgTjPysXBSHwGKxEc),'thumbnail':tmp_thumbnail,'viewage':qFUdMDIzOpvreYgTjPysXBSHwGKxEV.get('age'),'info':qFUdMDIzOpvreYgTjPysXBSHwGKxbf}
    qFUdMDIzOpvreYgTjPysXBSHwGKxnh.append(qFUdMDIzOpvreYgTjPysXBSHwGKxbN)
   qFUdMDIzOpvreYgTjPysXBSHwGKxER=qFUdMDIzOpvreYgTjPysXBSHwGKxuQ(qFUdMDIzOpvreYgTjPysXBSHwGKxhL['cell_toplist']['pagecount'])
   if qFUdMDIzOpvreYgTjPysXBSHwGKxhL['cell_toplist']['count']:qFUdMDIzOpvreYgTjPysXBSHwGKxbV =qFUdMDIzOpvreYgTjPysXBSHwGKxuQ(qFUdMDIzOpvreYgTjPysXBSHwGKxhL['cell_toplist']['count'])
   else:qFUdMDIzOpvreYgTjPysXBSHwGKxbV=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.LIST_LIMIT
   qFUdMDIzOpvreYgTjPysXBSHwGKxEl=qFUdMDIzOpvreYgTjPysXBSHwGKxER>qFUdMDIzOpvreYgTjPysXBSHwGKxbV
  except qFUdMDIzOpvreYgTjPysXBSHwGKxui as exception:
   qFUdMDIzOpvreYgTjPysXBSHwGKxut(exception)
  try:
   if genre=='moviegenre_svod' and addinfoyn==qFUdMDIzOpvreYgTjPysXBSHwGKxuc:
    qFUdMDIzOpvreYgTjPysXBSHwGKxbC=[]
    qFUdMDIzOpvreYgTjPysXBSHwGKxbc={}
    for qFUdMDIzOpvreYgTjPysXBSHwGKxbi in qFUdMDIzOpvreYgTjPysXBSHwGKxnh:qFUdMDIzOpvreYgTjPysXBSHwGKxbC.append(qFUdMDIzOpvreYgTjPysXBSHwGKxbi.get('uicode'))
    qFUdMDIzOpvreYgTjPysXBSHwGKxbc=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.GetMovieInfoList(qFUdMDIzOpvreYgTjPysXBSHwGKxbC)
    for i in qFUdMDIzOpvreYgTjPysXBSHwGKxuV(qFUdMDIzOpvreYgTjPysXBSHwGKxuR(qFUdMDIzOpvreYgTjPysXBSHwGKxnh)):
     qFUdMDIzOpvreYgTjPysXBSHwGKxnh[i]['info']=qFUdMDIzOpvreYgTjPysXBSHwGKxbc.get(qFUdMDIzOpvreYgTjPysXBSHwGKxnh[i]['uicode'])
  except:
   qFUdMDIzOpvreYgTjPysXBSHwGKxun
  return qFUdMDIzOpvreYgTjPysXBSHwGKxnh,qFUdMDIzOpvreYgTjPysXBSHwGKxEl
 def GetEPGList(qFUdMDIzOpvreYgTjPysXBSHwGKxhn,genre):
  qFUdMDIzOpvreYgTjPysXBSHwGKxnu={}
  try:
   import datetime
   qFUdMDIzOpvreYgTjPysXBSHwGKxnf=datetime.datetime.now()
   if genre=='all':
    qFUdMDIzOpvreYgTjPysXBSHwGKxnV =qFUdMDIzOpvreYgTjPysXBSHwGKxnf+datetime.timedelta(hours=2)
   else:
    qFUdMDIzOpvreYgTjPysXBSHwGKxnV =qFUdMDIzOpvreYgTjPysXBSHwGKxnf+datetime.timedelta(hours=3)
   qFUdMDIzOpvreYgTjPysXBSHwGKxhC=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.GetDefaultParams()
   qFUdMDIzOpvreYgTjPysXBSHwGKxEA={'limit':'100','offset':'0','genre':genre,'startdatetime':qFUdMDIzOpvreYgTjPysXBSHwGKxnf.strftime('%Y-%m-%d %H:%M'),'enddatetime':qFUdMDIzOpvreYgTjPysXBSHwGKxnV.strftime('%Y-%m-%d %H:%M')}
   qFUdMDIzOpvreYgTjPysXBSHwGKxhW='/live/epgs'
   qFUdMDIzOpvreYgTjPysXBSHwGKxhc=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.makeurl(qFUdMDIzOpvreYgTjPysXBSHwGKxhn.API_DOMAIN,qFUdMDIzOpvreYgTjPysXBSHwGKxhW)
   qFUdMDIzOpvreYgTjPysXBSHwGKxEA.update(qFUdMDIzOpvreYgTjPysXBSHwGKxhC)
   qFUdMDIzOpvreYgTjPysXBSHwGKxho=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.callRequestCookies('Get',qFUdMDIzOpvreYgTjPysXBSHwGKxhc,payload=qFUdMDIzOpvreYgTjPysXBSHwGKxun,params=qFUdMDIzOpvreYgTjPysXBSHwGKxEA,headers=qFUdMDIzOpvreYgTjPysXBSHwGKxun,cookies=qFUdMDIzOpvreYgTjPysXBSHwGKxun)
   qFUdMDIzOpvreYgTjPysXBSHwGKxhL=json.loads(qFUdMDIzOpvreYgTjPysXBSHwGKxho.text)
   qFUdMDIzOpvreYgTjPysXBSHwGKxnC=qFUdMDIzOpvreYgTjPysXBSHwGKxhL['list']
   for qFUdMDIzOpvreYgTjPysXBSHwGKxEV in qFUdMDIzOpvreYgTjPysXBSHwGKxnC:
    qFUdMDIzOpvreYgTjPysXBSHwGKxnc=''
    for qFUdMDIzOpvreYgTjPysXBSHwGKxni in qFUdMDIzOpvreYgTjPysXBSHwGKxEV['list']:
     if qFUdMDIzOpvreYgTjPysXBSHwGKxnc:qFUdMDIzOpvreYgTjPysXBSHwGKxnc+='\n'
     qFUdMDIzOpvreYgTjPysXBSHwGKxnc+=qFUdMDIzOpvreYgTjPysXBSHwGKxni['title']+'\n'
     qFUdMDIzOpvreYgTjPysXBSHwGKxnc+=' [%s ~ %s]'%(qFUdMDIzOpvreYgTjPysXBSHwGKxni['starttime'][-5:],qFUdMDIzOpvreYgTjPysXBSHwGKxni['endtime'][-5:])+'\n'
    qFUdMDIzOpvreYgTjPysXBSHwGKxnu[qFUdMDIzOpvreYgTjPysXBSHwGKxEV['channelid']]=qFUdMDIzOpvreYgTjPysXBSHwGKxnc
  except qFUdMDIzOpvreYgTjPysXBSHwGKxui as exception:
   qFUdMDIzOpvreYgTjPysXBSHwGKxut(exception)
  return qFUdMDIzOpvreYgTjPysXBSHwGKxnu
 def GetMovieInfoList(qFUdMDIzOpvreYgTjPysXBSHwGKxhn,movie_list):
  qFUdMDIzOpvreYgTjPysXBSHwGKxnt={}
  try:
   qFUdMDIzOpvreYgTjPysXBSHwGKxhC =qFUdMDIzOpvreYgTjPysXBSHwGKxhn.GetDefaultParams()
   qFUdMDIzOpvreYgTjPysXBSHwGKxhW=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.API_DOMAIN+'/movie/contents/'
   for qFUdMDIzOpvreYgTjPysXBSHwGKxbi in movie_list:
    qFUdMDIzOpvreYgTjPysXBSHwGKxhc=qFUdMDIzOpvreYgTjPysXBSHwGKxhW+qFUdMDIzOpvreYgTjPysXBSHwGKxbi
    qFUdMDIzOpvreYgTjPysXBSHwGKxho=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.callRequestCookies('Get',qFUdMDIzOpvreYgTjPysXBSHwGKxhc,payload=qFUdMDIzOpvreYgTjPysXBSHwGKxun,params=qFUdMDIzOpvreYgTjPysXBSHwGKxhC,headers=qFUdMDIzOpvreYgTjPysXBSHwGKxun,cookies=qFUdMDIzOpvreYgTjPysXBSHwGKxun)
    qFUdMDIzOpvreYgTjPysXBSHwGKxhL=json.loads(qFUdMDIzOpvreYgTjPysXBSHwGKxho.text)
    qFUdMDIzOpvreYgTjPysXBSHwGKxbf={}
    qFUdMDIzOpvreYgTjPysXBSHwGKxbf['mediatype']='movie'
    qFUdMDIzOpvreYgTjPysXBSHwGKxnR=[]
    for qFUdMDIzOpvreYgTjPysXBSHwGKxnk in qFUdMDIzOpvreYgTjPysXBSHwGKxhL['actors']['list']:qFUdMDIzOpvreYgTjPysXBSHwGKxnR.append(qFUdMDIzOpvreYgTjPysXBSHwGKxnk.get('text'))
    if qFUdMDIzOpvreYgTjPysXBSHwGKxnR[0]!='':qFUdMDIzOpvreYgTjPysXBSHwGKxbf['cast']=qFUdMDIzOpvreYgTjPysXBSHwGKxnR
    qFUdMDIzOpvreYgTjPysXBSHwGKxnQ=[]
    for qFUdMDIzOpvreYgTjPysXBSHwGKxnl in qFUdMDIzOpvreYgTjPysXBSHwGKxhL['directors']['list']:qFUdMDIzOpvreYgTjPysXBSHwGKxnQ.append(qFUdMDIzOpvreYgTjPysXBSHwGKxnl.get('text'))
    if qFUdMDIzOpvreYgTjPysXBSHwGKxnQ[0]!='':qFUdMDIzOpvreYgTjPysXBSHwGKxbf['director']=qFUdMDIzOpvreYgTjPysXBSHwGKxnQ
    qFUdMDIzOpvreYgTjPysXBSHwGKxnh=[]
    for qFUdMDIzOpvreYgTjPysXBSHwGKxnm in qFUdMDIzOpvreYgTjPysXBSHwGKxhL['genre']['list']:qFUdMDIzOpvreYgTjPysXBSHwGKxnh.append(qFUdMDIzOpvreYgTjPysXBSHwGKxnm.get('text'))
    if qFUdMDIzOpvreYgTjPysXBSHwGKxnh[0]!='':qFUdMDIzOpvreYgTjPysXBSHwGKxbf['genre']=qFUdMDIzOpvreYgTjPysXBSHwGKxnh
    if qFUdMDIzOpvreYgTjPysXBSHwGKxhL.get('releasedate')!='':
     qFUdMDIzOpvreYgTjPysXBSHwGKxbf['year'] =qFUdMDIzOpvreYgTjPysXBSHwGKxhL['releasedate'][:4]
     qFUdMDIzOpvreYgTjPysXBSHwGKxbf['aired'] =qFUdMDIzOpvreYgTjPysXBSHwGKxhL['releasedate']
    qFUdMDIzOpvreYgTjPysXBSHwGKxbf['country']=qFUdMDIzOpvreYgTjPysXBSHwGKxhL['country']
    qFUdMDIzOpvreYgTjPysXBSHwGKxbf['duration']=qFUdMDIzOpvreYgTjPysXBSHwGKxhL['playtime']
    qFUdMDIzOpvreYgTjPysXBSHwGKxbf['title'] =qFUdMDIzOpvreYgTjPysXBSHwGKxhL['title']
    qFUdMDIzOpvreYgTjPysXBSHwGKxbf['mpaa'] =qFUdMDIzOpvreYgTjPysXBSHwGKxhL['targetage']
    qFUdMDIzOpvreYgTjPysXBSHwGKxbf['plot'] =qFUdMDIzOpvreYgTjPysXBSHwGKxhL['synopsis']
    qFUdMDIzOpvreYgTjPysXBSHwGKxnt[qFUdMDIzOpvreYgTjPysXBSHwGKxbi]=qFUdMDIzOpvreYgTjPysXBSHwGKxbf
  except qFUdMDIzOpvreYgTjPysXBSHwGKxui as exception:
   return{}
  return qFUdMDIzOpvreYgTjPysXBSHwGKxnt
 def GetStreamingURL(qFUdMDIzOpvreYgTjPysXBSHwGKxhn,qFUdMDIzOpvreYgTjPysXBSHwGKxEQ,qFUdMDIzOpvreYgTjPysXBSHwGKxEk,quality_int):
  qFUdMDIzOpvreYgTjPysXBSHwGKxnJ=qFUdMDIzOpvreYgTjPysXBSHwGKxuh=qFUdMDIzOpvreYgTjPysXBSHwGKxuE=streaming_preview=''
  qFUdMDIzOpvreYgTjPysXBSHwGKxnA=[]
  try:
   if qFUdMDIzOpvreYgTjPysXBSHwGKxEk=='channel':
    qFUdMDIzOpvreYgTjPysXBSHwGKxhW='/live/channels/'+qFUdMDIzOpvreYgTjPysXBSHwGKxEQ
    qFUdMDIzOpvreYgTjPysXBSHwGKxna='live'
   elif qFUdMDIzOpvreYgTjPysXBSHwGKxEk=='movie':
    qFUdMDIzOpvreYgTjPysXBSHwGKxhW='/cf/movie/contents/'+qFUdMDIzOpvreYgTjPysXBSHwGKxEQ
    qFUdMDIzOpvreYgTjPysXBSHwGKxna='movie'
   else: 
    qFUdMDIzOpvreYgTjPysXBSHwGKxhW='/cf/vod/contents/'+qFUdMDIzOpvreYgTjPysXBSHwGKxEQ
    qFUdMDIzOpvreYgTjPysXBSHwGKxna='vod'
   qFUdMDIzOpvreYgTjPysXBSHwGKxhC=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.GetDefaultParams()
   qFUdMDIzOpvreYgTjPysXBSHwGKxhc=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.makeurl(qFUdMDIzOpvreYgTjPysXBSHwGKxhn.API_DOMAIN,qFUdMDIzOpvreYgTjPysXBSHwGKxhW)
   qFUdMDIzOpvreYgTjPysXBSHwGKxho=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.callRequestCookies('Get',qFUdMDIzOpvreYgTjPysXBSHwGKxhc,payload=qFUdMDIzOpvreYgTjPysXBSHwGKxun,params=qFUdMDIzOpvreYgTjPysXBSHwGKxhC,headers=qFUdMDIzOpvreYgTjPysXBSHwGKxun,cookies=qFUdMDIzOpvreYgTjPysXBSHwGKxun)
   qFUdMDIzOpvreYgTjPysXBSHwGKxhL=json.loads(qFUdMDIzOpvreYgTjPysXBSHwGKxho.text)
   qFUdMDIzOpvreYgTjPysXBSHwGKxnW=qFUdMDIzOpvreYgTjPysXBSHwGKxhL['qualities']['list']
   if qFUdMDIzOpvreYgTjPysXBSHwGKxnW==qFUdMDIzOpvreYgTjPysXBSHwGKxun:return(qFUdMDIzOpvreYgTjPysXBSHwGKxnJ,qFUdMDIzOpvreYgTjPysXBSHwGKxuh,qFUdMDIzOpvreYgTjPysXBSHwGKxuE,streaming_preview)
   qFUdMDIzOpvreYgTjPysXBSHwGKxnN='hls'
   if 'drms' in qFUdMDIzOpvreYgTjPysXBSHwGKxhL:
    if qFUdMDIzOpvreYgTjPysXBSHwGKxhL['drms']:
     qFUdMDIzOpvreYgTjPysXBSHwGKxnN='dash'
   if 'type' in qFUdMDIzOpvreYgTjPysXBSHwGKxhL:
    if qFUdMDIzOpvreYgTjPysXBSHwGKxhL['type']=='onair':
     qFUdMDIzOpvreYgTjPysXBSHwGKxna='onairvod'
   for qFUdMDIzOpvreYgTjPysXBSHwGKxno in qFUdMDIzOpvreYgTjPysXBSHwGKxnW:
    qFUdMDIzOpvreYgTjPysXBSHwGKxnA.append(qFUdMDIzOpvreYgTjPysXBSHwGKxuQ(qFUdMDIzOpvreYgTjPysXBSHwGKxno.get('id').rstrip('p')))
  except qFUdMDIzOpvreYgTjPysXBSHwGKxui as exception:
   return(qFUdMDIzOpvreYgTjPysXBSHwGKxnJ,qFUdMDIzOpvreYgTjPysXBSHwGKxuh,qFUdMDIzOpvreYgTjPysXBSHwGKxuE,streaming_preview)
  try:
   qFUdMDIzOpvreYgTjPysXBSHwGKxnL=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.CheckQuality(quality_int,qFUdMDIzOpvreYgTjPysXBSHwGKxnA)
   qFUdMDIzOpvreYgTjPysXBSHwGKxhW='/streaming'
   qFUdMDIzOpvreYgTjPysXBSHwGKxEA={'contentid':qFUdMDIzOpvreYgTjPysXBSHwGKxEQ,'contenttype':qFUdMDIzOpvreYgTjPysXBSHwGKxna,'action':qFUdMDIzOpvreYgTjPysXBSHwGKxnN,'quality':qFUdMDIzOpvreYgTjPysXBSHwGKxuC(qFUdMDIzOpvreYgTjPysXBSHwGKxnL)+'p','deviceModelId':'Windows 10','guid':qFUdMDIzOpvreYgTjPysXBSHwGKxhn.GetGUID(guidType=2),'lastplayid':qFUdMDIzOpvreYgTjPysXBSHwGKxhn.guid,'authtype':'cookie','isabr':'y','ishevc':'n'}
   qFUdMDIzOpvreYgTjPysXBSHwGKxhc=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.makeurl(qFUdMDIzOpvreYgTjPysXBSHwGKxhn.API_DOMAIN,qFUdMDIzOpvreYgTjPysXBSHwGKxhW)
   qFUdMDIzOpvreYgTjPysXBSHwGKxEA.update(qFUdMDIzOpvreYgTjPysXBSHwGKxhC)
   qFUdMDIzOpvreYgTjPysXBSHwGKxho=qFUdMDIzOpvreYgTjPysXBSHwGKxhn.callRequestCookies('Get',qFUdMDIzOpvreYgTjPysXBSHwGKxhc,payload=qFUdMDIzOpvreYgTjPysXBSHwGKxun,params=qFUdMDIzOpvreYgTjPysXBSHwGKxEA,headers=qFUdMDIzOpvreYgTjPysXBSHwGKxun,cookies=qFUdMDIzOpvreYgTjPysXBSHwGKxun)
   qFUdMDIzOpvreYgTjPysXBSHwGKxhL=json.loads(qFUdMDIzOpvreYgTjPysXBSHwGKxho.text)
   qFUdMDIzOpvreYgTjPysXBSHwGKxnJ=qFUdMDIzOpvreYgTjPysXBSHwGKxhL['playurl']
   if qFUdMDIzOpvreYgTjPysXBSHwGKxnJ==qFUdMDIzOpvreYgTjPysXBSHwGKxun:return qFUdMDIzOpvreYgTjPysXBSHwGKxun
   qFUdMDIzOpvreYgTjPysXBSHwGKxuh=qFUdMDIzOpvreYgTjPysXBSHwGKxhL['awscookie']
   qFUdMDIzOpvreYgTjPysXBSHwGKxuE =qFUdMDIzOpvreYgTjPysXBSHwGKxhL['drm']
   if 'previewmsg' in qFUdMDIzOpvreYgTjPysXBSHwGKxhL['preview']:streaming_preview=qFUdMDIzOpvreYgTjPysXBSHwGKxhL['preview']['previewmsg']
  except qFUdMDIzOpvreYgTjPysXBSHwGKxui as exception:
   qFUdMDIzOpvreYgTjPysXBSHwGKxut(exception)
  qFUdMDIzOpvreYgTjPysXBSHwGKxnJ=qFUdMDIzOpvreYgTjPysXBSHwGKxnJ.replace('pooq.co.kr','wavve.com')
  return(qFUdMDIzOpvreYgTjPysXBSHwGKxnJ,qFUdMDIzOpvreYgTjPysXBSHwGKxuh,qFUdMDIzOpvreYgTjPysXBSHwGKxuE,streaming_preview) 
# Created by pyminifier (https://github.com/liftoff/pyminifier)
