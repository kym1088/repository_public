__author__="NightRain"
JzGtOIjeyEABNqvsinoFTYuVQhMxrk=object
JzGtOIjeyEABNqvsinoFTYuVQhMxrc=None
JzGtOIjeyEABNqvsinoFTYuVQhMxrp=False
JzGtOIjeyEABNqvsinoFTYuVQhMxrS=int
JzGtOIjeyEABNqvsinoFTYuVQhMxrC=True
JzGtOIjeyEABNqvsinoFTYuVQhMxLD=len
JzGtOIjeyEABNqvsinoFTYuVQhMxLm=str
JzGtOIjeyEABNqvsinoFTYuVQhMxLb=dict
JzGtOIjeyEABNqvsinoFTYuVQhMxLK=open
JzGtOIjeyEABNqvsinoFTYuVQhMxLr=Exception
JzGtOIjeyEABNqvsinoFTYuVQhMxLX=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
JzGtOIjeyEABNqvsinoFTYuVQhMxDb=[{'title':'홈','uicode':'GN1','came':'home'},{'title':'LIVE 채널','uicode':'GN3','came':'live'},{'title':'VOD 방송','uicode':'GN2','came':'broadcast'},{'title':'영화(Movie)','uicode':'GN17','came':'movie'},{'title':'해외시리즈','uicode':'GN12','came':'global'},{'title':'분류별 - 방송(VOD) - 인기순','uicode':'GENRE','came':'vodgenre','orderby':'viewtime','ordernm':'인기순'},{'title':'분류별 - 방송(VOD) - 최신순','uicode':'GENRE','came':'vodgenre','orderby':'new','ordernm':'최신순'},{'title':'분류별 - 영화(Movie) - 인기순','uicode':'GENRE','came':'moviegenre_svod','orderby':'paid','ordernm':'인기순'},{'title':'분류별 - 영화(Movie) - 업데이트순','uicode':'GENRE','came':'moviegenre_svod','orderby':'displaystart','ordernm':'업데이트순'},{'title':'검색','uicode':'SEARCH','came':'-'},{'title':'Watched(시청목록)','uicode':'WATCH','came':'-'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmc.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
JzGtOIjeyEABNqvsinoFTYuVQhMxDK='Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'
JzGtOIjeyEABNqvsinoFTYuVQhMxDr=xbmc.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
from wavveCore import*
class JzGtOIjeyEABNqvsinoFTYuVQhMxDm(JzGtOIjeyEABNqvsinoFTYuVQhMxrk):
 def __init__(JzGtOIjeyEABNqvsinoFTYuVQhMxDL,JzGtOIjeyEABNqvsinoFTYuVQhMxDX,JzGtOIjeyEABNqvsinoFTYuVQhMxDw,JzGtOIjeyEABNqvsinoFTYuVQhMxDa):
  JzGtOIjeyEABNqvsinoFTYuVQhMxDL._addon_url =JzGtOIjeyEABNqvsinoFTYuVQhMxDX
  JzGtOIjeyEABNqvsinoFTYuVQhMxDL._addon_handle=JzGtOIjeyEABNqvsinoFTYuVQhMxDw
  JzGtOIjeyEABNqvsinoFTYuVQhMxDL.main_params =JzGtOIjeyEABNqvsinoFTYuVQhMxDa
  JzGtOIjeyEABNqvsinoFTYuVQhMxDL.WavveObj =qFUdMDIzOpvreYgTjPysXBSHwGKxhE() 
 def addon_noti(JzGtOIjeyEABNqvsinoFTYuVQhMxDL,sting):
  try:
   JzGtOIjeyEABNqvsinoFTYuVQhMxDg=xbmcgui.Dialog()
   JzGtOIjeyEABNqvsinoFTYuVQhMxDg.notification(__addonname__,sting)
  except:
   JzGtOIjeyEABNqvsinoFTYuVQhMxrc
 def addon_log(JzGtOIjeyEABNqvsinoFTYuVQhMxDL,string,isDebug=JzGtOIjeyEABNqvsinoFTYuVQhMxrp):
  try:
   JzGtOIjeyEABNqvsinoFTYuVQhMxDW=string.encode('utf-8','ignore')
  except:
   JzGtOIjeyEABNqvsinoFTYuVQhMxDW='addonException: addon_log'
  if isDebug:JzGtOIjeyEABNqvsinoFTYuVQhMxDH=xbmc.LOGDEBUG
  else:JzGtOIjeyEABNqvsinoFTYuVQhMxDH=xbmc.LOGNOTICE
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,JzGtOIjeyEABNqvsinoFTYuVQhMxDW),level=JzGtOIjeyEABNqvsinoFTYuVQhMxDH)
 def get_keyboard_input(JzGtOIjeyEABNqvsinoFTYuVQhMxDL,JzGtOIjeyEABNqvsinoFTYuVQhMxmK):
  JzGtOIjeyEABNqvsinoFTYuVQhMxDd=JzGtOIjeyEABNqvsinoFTYuVQhMxrc
  kb=xbmc.Keyboard()
  kb.setHeading(JzGtOIjeyEABNqvsinoFTYuVQhMxmK)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   JzGtOIjeyEABNqvsinoFTYuVQhMxDd=kb.getText()
  return JzGtOIjeyEABNqvsinoFTYuVQhMxDd
 def get_settings_login_info(JzGtOIjeyEABNqvsinoFTYuVQhMxDL):
  JzGtOIjeyEABNqvsinoFTYuVQhMxDl =__addon__.getSetting('id')
  JzGtOIjeyEABNqvsinoFTYuVQhMxDR =__addon__.getSetting('pw')
  JzGtOIjeyEABNqvsinoFTYuVQhMxDf=__addon__.getSetting('selected_profile')
  return(JzGtOIjeyEABNqvsinoFTYuVQhMxDl,JzGtOIjeyEABNqvsinoFTYuVQhMxDR,JzGtOIjeyEABNqvsinoFTYuVQhMxDf)
 def get_selQuality(JzGtOIjeyEABNqvsinoFTYuVQhMxDL):
  try:
   JzGtOIjeyEABNqvsinoFTYuVQhMxDP=[1080,720,480,360]
   JzGtOIjeyEABNqvsinoFTYuVQhMxDk=JzGtOIjeyEABNqvsinoFTYuVQhMxrS(__addon__.getSetting('selected_quality'))
   return JzGtOIjeyEABNqvsinoFTYuVQhMxDP[JzGtOIjeyEABNqvsinoFTYuVQhMxDk]
  except:
   JzGtOIjeyEABNqvsinoFTYuVQhMxrc
  return 1080 
 def get_settings_exclusion21(JzGtOIjeyEABNqvsinoFTYuVQhMxDL):
  JzGtOIjeyEABNqvsinoFTYuVQhMxDc =__addon__.getSetting('exclusion21')
  if JzGtOIjeyEABNqvsinoFTYuVQhMxDc=='false':
   return JzGtOIjeyEABNqvsinoFTYuVQhMxrp
  else:
   return JzGtOIjeyEABNqvsinoFTYuVQhMxrC
 def get_settings_direct_replay(JzGtOIjeyEABNqvsinoFTYuVQhMxDL):
  JzGtOIjeyEABNqvsinoFTYuVQhMxDp=JzGtOIjeyEABNqvsinoFTYuVQhMxrS(__addon__.getSetting('direct_replay'))
  if JzGtOIjeyEABNqvsinoFTYuVQhMxDp==0:
   return JzGtOIjeyEABNqvsinoFTYuVQhMxrp
  else:
   return JzGtOIjeyEABNqvsinoFTYuVQhMxrC
 def get_settings_addinfo(JzGtOIjeyEABNqvsinoFTYuVQhMxDL):
  JzGtOIjeyEABNqvsinoFTYuVQhMxDS =__addon__.getSetting('add_infoyn')
  if JzGtOIjeyEABNqvsinoFTYuVQhMxDS=='false':
   return JzGtOIjeyEABNqvsinoFTYuVQhMxrp
  else:
   return JzGtOIjeyEABNqvsinoFTYuVQhMxrC
 def get_settings_thumbnail_landyn(JzGtOIjeyEABNqvsinoFTYuVQhMxDL):
  JzGtOIjeyEABNqvsinoFTYuVQhMxDC =JzGtOIjeyEABNqvsinoFTYuVQhMxrS(__addon__.getSetting('thumbnail_way'))
  if JzGtOIjeyEABNqvsinoFTYuVQhMxDC==0:
   return JzGtOIjeyEABNqvsinoFTYuVQhMxrC
  else:
   return JzGtOIjeyEABNqvsinoFTYuVQhMxrp
 def set_winCredential(JzGtOIjeyEABNqvsinoFTYuVQhMxDL,credential):
  JzGtOIjeyEABNqvsinoFTYuVQhMxmD=xbmcgui.Window(10000)
  JzGtOIjeyEABNqvsinoFTYuVQhMxmD.setProperty('WAVVE_M_CREDENTIAL',credential)
  JzGtOIjeyEABNqvsinoFTYuVQhMxmD.setProperty('WAVVE_M_LOGINTIME',datetime.datetime.now().strftime('%Y-%m-%d'))
 def get_winCredential(JzGtOIjeyEABNqvsinoFTYuVQhMxDL):
  JzGtOIjeyEABNqvsinoFTYuVQhMxmD=xbmcgui.Window(10000)
  return JzGtOIjeyEABNqvsinoFTYuVQhMxmD.getProperty('WAVVE_M_CREDENTIAL')
 def set_winEpisodeOrderby(JzGtOIjeyEABNqvsinoFTYuVQhMxDL,JzGtOIjeyEABNqvsinoFTYuVQhMxmf):
  JzGtOIjeyEABNqvsinoFTYuVQhMxmD=xbmcgui.Window(10000)
  JzGtOIjeyEABNqvsinoFTYuVQhMxmD.setProperty('WAVVE_M_ORDERBY',JzGtOIjeyEABNqvsinoFTYuVQhMxmf)
 def get_winEpisodeOrderby(JzGtOIjeyEABNqvsinoFTYuVQhMxDL):
  JzGtOIjeyEABNqvsinoFTYuVQhMxmD=xbmcgui.Window(10000)
  return JzGtOIjeyEABNqvsinoFTYuVQhMxmD.getProperty('WAVVE_M_ORDERBY')
 def add_dir(JzGtOIjeyEABNqvsinoFTYuVQhMxDL,label,sublabel='',img='',infoLabels=JzGtOIjeyEABNqvsinoFTYuVQhMxrc,isFolder=JzGtOIjeyEABNqvsinoFTYuVQhMxrC,params=''):
  JzGtOIjeyEABNqvsinoFTYuVQhMxmb='%s?%s'%(JzGtOIjeyEABNqvsinoFTYuVQhMxDL._addon_url,urllib.parse.urlencode(params))
  if sublabel:JzGtOIjeyEABNqvsinoFTYuVQhMxmK='%s < %s >'%(label,sublabel)
  else: JzGtOIjeyEABNqvsinoFTYuVQhMxmK=label
  if not img:img='DefaultFolder.png'
  JzGtOIjeyEABNqvsinoFTYuVQhMxmr=xbmcgui.ListItem(JzGtOIjeyEABNqvsinoFTYuVQhMxmK)
  JzGtOIjeyEABNqvsinoFTYuVQhMxmr.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:JzGtOIjeyEABNqvsinoFTYuVQhMxmr.setInfo(type="video",infoLabels=infoLabels)
  if not isFolder:JzGtOIjeyEABNqvsinoFTYuVQhMxmr.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(JzGtOIjeyEABNqvsinoFTYuVQhMxDL._addon_handle,JzGtOIjeyEABNqvsinoFTYuVQhMxmb,JzGtOIjeyEABNqvsinoFTYuVQhMxmr,isFolder)
 def dp_Main_List(JzGtOIjeyEABNqvsinoFTYuVQhMxDL):
  for JzGtOIjeyEABNqvsinoFTYuVQhMxmL in JzGtOIjeyEABNqvsinoFTYuVQhMxDb:
   JzGtOIjeyEABNqvsinoFTYuVQhMxmK=JzGtOIjeyEABNqvsinoFTYuVQhMxmL.get('title')
   if JzGtOIjeyEABNqvsinoFTYuVQhMxmL.get('uicode')=='GENRE':
    JzGtOIjeyEABNqvsinoFTYuVQhMxmX={'mode':'GENRE','uicode':JzGtOIjeyEABNqvsinoFTYuVQhMxmL.get('came'),'genre':'-','subgenre':'-','orderby':JzGtOIjeyEABNqvsinoFTYuVQhMxmL.get('orderby'),'ordernm':JzGtOIjeyEABNqvsinoFTYuVQhMxmL.get('ordernm')}
   elif JzGtOIjeyEABNqvsinoFTYuVQhMxmL.get('uicode')=='WATCH':
    JzGtOIjeyEABNqvsinoFTYuVQhMxmX={'mode':'WATCH','genre':'-'}
   elif JzGtOIjeyEABNqvsinoFTYuVQhMxmL.get('uicode')=='SEARCH':
    JzGtOIjeyEABNqvsinoFTYuVQhMxmX={'mode':'SEARCH','genre':'-'}
   else:
    JzGtOIjeyEABNqvsinoFTYuVQhMxmX={'mode':'GNB_LIST','uicode':JzGtOIjeyEABNqvsinoFTYuVQhMxmL.get('uicode'),'came':JzGtOIjeyEABNqvsinoFTYuVQhMxmL.get('came')}
   JzGtOIjeyEABNqvsinoFTYuVQhMxmw=JzGtOIjeyEABNqvsinoFTYuVQhMxrC
   if JzGtOIjeyEABNqvsinoFTYuVQhMxmL.get('uicode')=='XXX':
    JzGtOIjeyEABNqvsinoFTYuVQhMxmX['mode']='XXX'
    JzGtOIjeyEABNqvsinoFTYuVQhMxmw=JzGtOIjeyEABNqvsinoFTYuVQhMxrp
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.add_dir(JzGtOIjeyEABNqvsinoFTYuVQhMxmK,sublabel='',img='',infoLabels=JzGtOIjeyEABNqvsinoFTYuVQhMxrc,isFolder=JzGtOIjeyEABNqvsinoFTYuVQhMxmw,params=JzGtOIjeyEABNqvsinoFTYuVQhMxmX)
  if JzGtOIjeyEABNqvsinoFTYuVQhMxLD(JzGtOIjeyEABNqvsinoFTYuVQhMxDb)>0:xbmcplugin.endOfDirectory(JzGtOIjeyEABNqvsinoFTYuVQhMxDL._addon_handle)
 def login_main(JzGtOIjeyEABNqvsinoFTYuVQhMxDL):
  (JzGtOIjeyEABNqvsinoFTYuVQhMxmU,JzGtOIjeyEABNqvsinoFTYuVQhMxmg,JzGtOIjeyEABNqvsinoFTYuVQhMxmW)=JzGtOIjeyEABNqvsinoFTYuVQhMxDL.get_settings_login_info()
  if not(JzGtOIjeyEABNqvsinoFTYuVQhMxmU and JzGtOIjeyEABNqvsinoFTYuVQhMxmg):
   JzGtOIjeyEABNqvsinoFTYuVQhMxDg=xbmcgui.Dialog()
   JzGtOIjeyEABNqvsinoFTYuVQhMxmH=JzGtOIjeyEABNqvsinoFTYuVQhMxDg.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if JzGtOIjeyEABNqvsinoFTYuVQhMxmH==JzGtOIjeyEABNqvsinoFTYuVQhMxrC:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if JzGtOIjeyEABNqvsinoFTYuVQhMxDL.get_winEpisodeOrderby()=='':
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.set_winEpisodeOrderby('desc')
  if JzGtOIjeyEABNqvsinoFTYuVQhMxDL.cookiefile_check():return
  JzGtOIjeyEABNqvsinoFTYuVQhMxmd =JzGtOIjeyEABNqvsinoFTYuVQhMxrS(datetime.datetime.now().strftime('%Y%m%d'))
  JzGtOIjeyEABNqvsinoFTYuVQhMxml=xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINTIME')
  if JzGtOIjeyEABNqvsinoFTYuVQhMxml==JzGtOIjeyEABNqvsinoFTYuVQhMxrc or JzGtOIjeyEABNqvsinoFTYuVQhMxml=='':JzGtOIjeyEABNqvsinoFTYuVQhMxml=JzGtOIjeyEABNqvsinoFTYuVQhMxrS('19000101')
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   JzGtOIjeyEABNqvsinoFTYuVQhMxmR=0
   while JzGtOIjeyEABNqvsinoFTYuVQhMxrC:
    JzGtOIjeyEABNqvsinoFTYuVQhMxmR+=1
    time.sleep(0.05)
    if JzGtOIjeyEABNqvsinoFTYuVQhMxml>=JzGtOIjeyEABNqvsinoFTYuVQhMxmd:return
    if JzGtOIjeyEABNqvsinoFTYuVQhMxmR>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  if JzGtOIjeyEABNqvsinoFTYuVQhMxml>=JzGtOIjeyEABNqvsinoFTYuVQhMxmd:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   return
  if not JzGtOIjeyEABNqvsinoFTYuVQhMxDL.WavveObj.GetCredential(JzGtOIjeyEABNqvsinoFTYuVQhMxmU,JzGtOIjeyEABNqvsinoFTYuVQhMxmg,JzGtOIjeyEABNqvsinoFTYuVQhMxmW):
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   sys.exit()
  JzGtOIjeyEABNqvsinoFTYuVQhMxDL.set_winCredential(JzGtOIjeyEABNqvsinoFTYuVQhMxDL.WavveObj.LoadCredential())
  JzGtOIjeyEABNqvsinoFTYuVQhMxDL.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
 def dp_setEpOrderby(JzGtOIjeyEABNqvsinoFTYuVQhMxDL,args):
  JzGtOIjeyEABNqvsinoFTYuVQhMxmf =args.get('orderby')
  JzGtOIjeyEABNqvsinoFTYuVQhMxDL.set_winEpisodeOrderby(JzGtOIjeyEABNqvsinoFTYuVQhMxmf)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Gnb_List(JzGtOIjeyEABNqvsinoFTYuVQhMxDL,args):
  JzGtOIjeyEABNqvsinoFTYuVQhMxDL.WavveObj.SaveCredential(JzGtOIjeyEABNqvsinoFTYuVQhMxDL.get_winCredential())
  JzGtOIjeyEABNqvsinoFTYuVQhMxmP=JzGtOIjeyEABNqvsinoFTYuVQhMxDL.WavveObj.GetGnList(args.get('uicode'))
  for JzGtOIjeyEABNqvsinoFTYuVQhMxmk in JzGtOIjeyEABNqvsinoFTYuVQhMxmP:
   JzGtOIjeyEABNqvsinoFTYuVQhMxmK=JzGtOIjeyEABNqvsinoFTYuVQhMxmk.get('title')
   JzGtOIjeyEABNqvsinoFTYuVQhMxmX={'mode':'GN_LIST' if JzGtOIjeyEABNqvsinoFTYuVQhMxmk.get('uicode')!='CY1' else 'GN_MYVIEW','uicode':JzGtOIjeyEABNqvsinoFTYuVQhMxmk.get('uicode'),'came':args.get('came'),'page':'1'}
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.add_dir(JzGtOIjeyEABNqvsinoFTYuVQhMxmK,sublabel='',img='',infoLabels=JzGtOIjeyEABNqvsinoFTYuVQhMxrc,isFolder=JzGtOIjeyEABNqvsinoFTYuVQhMxrC,params=JzGtOIjeyEABNqvsinoFTYuVQhMxmX)
  if JzGtOIjeyEABNqvsinoFTYuVQhMxLD(JzGtOIjeyEABNqvsinoFTYuVQhMxmP)>0:xbmcplugin.endOfDirectory(JzGtOIjeyEABNqvsinoFTYuVQhMxDL._addon_handle,cacheToDisc=JzGtOIjeyEABNqvsinoFTYuVQhMxrp)
 def dp_Myview_Group(JzGtOIjeyEABNqvsinoFTYuVQhMxDL,args):
  JzGtOIjeyEABNqvsinoFTYuVQhMxmK='VOD 시청내역'
  JzGtOIjeyEABNqvsinoFTYuVQhMxmX={'mode':'MYVIEW_LIST','uicode':'vod','page':'1'}
  JzGtOIjeyEABNqvsinoFTYuVQhMxDL.add_dir(JzGtOIjeyEABNqvsinoFTYuVQhMxmK,sublabel='',img='',infoLabels=JzGtOIjeyEABNqvsinoFTYuVQhMxrc,isFolder=JzGtOIjeyEABNqvsinoFTYuVQhMxrC,params=JzGtOIjeyEABNqvsinoFTYuVQhMxmX)
  JzGtOIjeyEABNqvsinoFTYuVQhMxmK='영화 시청내역'
  JzGtOIjeyEABNqvsinoFTYuVQhMxmX['uicode']='movie'
  JzGtOIjeyEABNqvsinoFTYuVQhMxDL.add_dir(JzGtOIjeyEABNqvsinoFTYuVQhMxmK,sublabel='',img='',infoLabels=JzGtOIjeyEABNqvsinoFTYuVQhMxrc,isFolder=JzGtOIjeyEABNqvsinoFTYuVQhMxrC,params=JzGtOIjeyEABNqvsinoFTYuVQhMxmX)
  xbmcplugin.endOfDirectory(JzGtOIjeyEABNqvsinoFTYuVQhMxDL._addon_handle)
 def dp_Myview_List(JzGtOIjeyEABNqvsinoFTYuVQhMxDL,args):
  JzGtOIjeyEABNqvsinoFTYuVQhMxDL.WavveObj.SaveCredential(JzGtOIjeyEABNqvsinoFTYuVQhMxDL.get_winCredential())
  JzGtOIjeyEABNqvsinoFTYuVQhMxmc =JzGtOIjeyEABNqvsinoFTYuVQhMxDL.get_settings_addinfo()
  JzGtOIjeyEABNqvsinoFTYuVQhMxmp=args.get('uicode')
  JzGtOIjeyEABNqvsinoFTYuVQhMxmS =JzGtOIjeyEABNqvsinoFTYuVQhMxrS(args.get('page'))
  JzGtOIjeyEABNqvsinoFTYuVQhMxmC,JzGtOIjeyEABNqvsinoFTYuVQhMxbD=JzGtOIjeyEABNqvsinoFTYuVQhMxDL.WavveObj.GetMyviewList(JzGtOIjeyEABNqvsinoFTYuVQhMxmp,JzGtOIjeyEABNqvsinoFTYuVQhMxmS,addinfoyn=JzGtOIjeyEABNqvsinoFTYuVQhMxmc)
  for JzGtOIjeyEABNqvsinoFTYuVQhMxbm in JzGtOIjeyEABNqvsinoFTYuVQhMxmC:
   JzGtOIjeyEABNqvsinoFTYuVQhMxmK =JzGtOIjeyEABNqvsinoFTYuVQhMxbm.get('title')
   JzGtOIjeyEABNqvsinoFTYuVQhMxbK =JzGtOIjeyEABNqvsinoFTYuVQhMxbm.get('subtitle')
   JzGtOIjeyEABNqvsinoFTYuVQhMxbr=JzGtOIjeyEABNqvsinoFTYuVQhMxbm.get('thumbnail')
   JzGtOIjeyEABNqvsinoFTYuVQhMxbL=JzGtOIjeyEABNqvsinoFTYuVQhMxbm.get('info')
   if JzGtOIjeyEABNqvsinoFTYuVQhMxmp=='movie' and JzGtOIjeyEABNqvsinoFTYuVQhMxmc==JzGtOIjeyEABNqvsinoFTYuVQhMxrC:
    JzGtOIjeyEABNqvsinoFTYuVQhMxmK='%s (%s)'%(JzGtOIjeyEABNqvsinoFTYuVQhMxmK,JzGtOIjeyEABNqvsinoFTYuVQhMxLm(JzGtOIjeyEABNqvsinoFTYuVQhMxbL.get('year')))
   else:
    JzGtOIjeyEABNqvsinoFTYuVQhMxbL['plot']=JzGtOIjeyEABNqvsinoFTYuVQhMxmK
   if JzGtOIjeyEABNqvsinoFTYuVQhMxmp=='vod':
    JzGtOIjeyEABNqvsinoFTYuVQhMxmX={'mode':'DEEP_LIST','contentid':JzGtOIjeyEABNqvsinoFTYuVQhMxbm.get('programid'),'contentidType':'programid','uicode':'vod','page':'1','title':JzGtOIjeyEABNqvsinoFTYuVQhMxmK,'subtitle':JzGtOIjeyEABNqvsinoFTYuVQhMxbK,'thumbnail':JzGtOIjeyEABNqvsinoFTYuVQhMxbr,'viewage':JzGtOIjeyEABNqvsinoFTYuVQhMxbm.get('viewage')}
    JzGtOIjeyEABNqvsinoFTYuVQhMxmw=JzGtOIjeyEABNqvsinoFTYuVQhMxrC
   else:
    JzGtOIjeyEABNqvsinoFTYuVQhMxmX={'mode':'MOVIE','contentid':JzGtOIjeyEABNqvsinoFTYuVQhMxbm.get('contentid'),'contentidType':'contentid','uicode':'movie','page':'1','title':JzGtOIjeyEABNqvsinoFTYuVQhMxmK,'subtitle':JzGtOIjeyEABNqvsinoFTYuVQhMxbK,'thumbnail':JzGtOIjeyEABNqvsinoFTYuVQhMxbr,'viewage':JzGtOIjeyEABNqvsinoFTYuVQhMxbm.get('viewage')}
    JzGtOIjeyEABNqvsinoFTYuVQhMxmw=JzGtOIjeyEABNqvsinoFTYuVQhMxrp
   if JzGtOIjeyEABNqvsinoFTYuVQhMxbm.get('viewage')=='21':JzGtOIjeyEABNqvsinoFTYuVQhMxbK+=' (%s)'%(JzGtOIjeyEABNqvsinoFTYuVQhMxbm.get('viewage'))
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.add_dir(JzGtOIjeyEABNqvsinoFTYuVQhMxmK,sublabel=JzGtOIjeyEABNqvsinoFTYuVQhMxbK,img=JzGtOIjeyEABNqvsinoFTYuVQhMxbr,infoLabels=JzGtOIjeyEABNqvsinoFTYuVQhMxbL,isFolder=JzGtOIjeyEABNqvsinoFTYuVQhMxmw,params=JzGtOIjeyEABNqvsinoFTYuVQhMxmX)
  if JzGtOIjeyEABNqvsinoFTYuVQhMxbD:
   JzGtOIjeyEABNqvsinoFTYuVQhMxmX['mode'] ='MYVIEW_LIST' 
   JzGtOIjeyEABNqvsinoFTYuVQhMxmX['uicode']=JzGtOIjeyEABNqvsinoFTYuVQhMxmp 
   JzGtOIjeyEABNqvsinoFTYuVQhMxmX['page'] =JzGtOIjeyEABNqvsinoFTYuVQhMxLm(JzGtOIjeyEABNqvsinoFTYuVQhMxmS+1)
   JzGtOIjeyEABNqvsinoFTYuVQhMxmK='[B]%s >>[/B]'%'다음 페이지'
   JzGtOIjeyEABNqvsinoFTYuVQhMxbK=JzGtOIjeyEABNqvsinoFTYuVQhMxLm(JzGtOIjeyEABNqvsinoFTYuVQhMxmS+1)
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.add_dir(JzGtOIjeyEABNqvsinoFTYuVQhMxmK,sublabel=JzGtOIjeyEABNqvsinoFTYuVQhMxbK,img='',infoLabels=JzGtOIjeyEABNqvsinoFTYuVQhMxrc,isFolder=JzGtOIjeyEABNqvsinoFTYuVQhMxrC,params=JzGtOIjeyEABNqvsinoFTYuVQhMxmX)
  if JzGtOIjeyEABNqvsinoFTYuVQhMxLD(JzGtOIjeyEABNqvsinoFTYuVQhMxmC)>0:xbmcplugin.endOfDirectory(JzGtOIjeyEABNqvsinoFTYuVQhMxDL._addon_handle,cacheToDisc=JzGtOIjeyEABNqvsinoFTYuVQhMxrp)
 def dp_Genre_Group(JzGtOIjeyEABNqvsinoFTYuVQhMxDL,args):
  JzGtOIjeyEABNqvsinoFTYuVQhMxDL.WavveObj.SaveCredential(JzGtOIjeyEABNqvsinoFTYuVQhMxDL.get_winCredential())
  JzGtOIjeyEABNqvsinoFTYuVQhMxbX =args.get('mode') 
  JzGtOIjeyEABNqvsinoFTYuVQhMxbw =args.get('uicode')
  JzGtOIjeyEABNqvsinoFTYuVQhMxba =args.get('genre') 
  JzGtOIjeyEABNqvsinoFTYuVQhMxbU=args.get('subgenre')
  JzGtOIjeyEABNqvsinoFTYuVQhMxmf =args.get('orderby')
  JzGtOIjeyEABNqvsinoFTYuVQhMxbg =args.get('ordernm')
  if JzGtOIjeyEABNqvsinoFTYuVQhMxba=='-':
   JzGtOIjeyEABNqvsinoFTYuVQhMxbW=JzGtOIjeyEABNqvsinoFTYuVQhMxDL.WavveObj.GetGenreGroup(JzGtOIjeyEABNqvsinoFTYuVQhMxbw,JzGtOIjeyEABNqvsinoFTYuVQhMxba,JzGtOIjeyEABNqvsinoFTYuVQhMxmf,JzGtOIjeyEABNqvsinoFTYuVQhMxbg,exclusion21=JzGtOIjeyEABNqvsinoFTYuVQhMxDL.get_settings_exclusion21())
  else:
   JzGtOIjeyEABNqvsinoFTYuVQhMxbH={'adult':args.get('adult'),'broadcastid':args.get('broadcastid'),'contenttype':args.get('contenttype'),'genre':args.get('genre'),'uiparent':args.get('uiparent'),'uirank':args.get('uirank'),'uitype':args.get('uitype'),'orderby':JzGtOIjeyEABNqvsinoFTYuVQhMxmf,'ordernm':JzGtOIjeyEABNqvsinoFTYuVQhMxbg}
   JzGtOIjeyEABNqvsinoFTYuVQhMxbW=JzGtOIjeyEABNqvsinoFTYuVQhMxDL.WavveObj.GetGenreGroup_sub(JzGtOIjeyEABNqvsinoFTYuVQhMxbH)
  for JzGtOIjeyEABNqvsinoFTYuVQhMxbd in JzGtOIjeyEABNqvsinoFTYuVQhMxbW:
   JzGtOIjeyEABNqvsinoFTYuVQhMxmK =JzGtOIjeyEABNqvsinoFTYuVQhMxbd.get('title')+'  ('+JzGtOIjeyEABNqvsinoFTYuVQhMxbg+')'
   JzGtOIjeyEABNqvsinoFTYuVQhMxmX={'mode':JzGtOIjeyEABNqvsinoFTYuVQhMxbX,'uicode':JzGtOIjeyEABNqvsinoFTYuVQhMxbw,'genre':JzGtOIjeyEABNqvsinoFTYuVQhMxbd.get('genre'),'subgenre':JzGtOIjeyEABNqvsinoFTYuVQhMxbd.get('subgenre'),'adult':JzGtOIjeyEABNqvsinoFTYuVQhMxbd.get('adult'),'page':'1','broadcastid':JzGtOIjeyEABNqvsinoFTYuVQhMxbd.get('broadcastid'),'contenttype':JzGtOIjeyEABNqvsinoFTYuVQhMxbd.get('contenttype'),'uiparent':JzGtOIjeyEABNqvsinoFTYuVQhMxbd.get('uiparent'),'uirank':JzGtOIjeyEABNqvsinoFTYuVQhMxbd.get('uirank'),'uitype':JzGtOIjeyEABNqvsinoFTYuVQhMxbd.get('uitype'),'orderby':JzGtOIjeyEABNqvsinoFTYuVQhMxmf,'ordernm':JzGtOIjeyEABNqvsinoFTYuVQhMxbg}
   if JzGtOIjeyEABNqvsinoFTYuVQhMxbw=='moviegenre' or JzGtOIjeyEABNqvsinoFTYuVQhMxbw=='moviegenre_svod' or JzGtOIjeyEABNqvsinoFTYuVQhMxbw=='moviegenre_ppv' or JzGtOIjeyEABNqvsinoFTYuVQhMxbd.get('subgenre')!='-':
    JzGtOIjeyEABNqvsinoFTYuVQhMxmX['mode'] ='GENRE_LIST'
   else:
    JzGtOIjeyEABNqvsinoFTYuVQhMxrc
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.add_dir(JzGtOIjeyEABNqvsinoFTYuVQhMxmK,sublabel='',img='',infoLabels=JzGtOIjeyEABNqvsinoFTYuVQhMxrc,isFolder=JzGtOIjeyEABNqvsinoFTYuVQhMxrC,params=JzGtOIjeyEABNqvsinoFTYuVQhMxmX)
  if JzGtOIjeyEABNqvsinoFTYuVQhMxLD(JzGtOIjeyEABNqvsinoFTYuVQhMxbW)>0:xbmcplugin.endOfDirectory(JzGtOIjeyEABNqvsinoFTYuVQhMxDL._addon_handle,cacheToDisc=JzGtOIjeyEABNqvsinoFTYuVQhMxrp)
 def dp_Genre_List(JzGtOIjeyEABNqvsinoFTYuVQhMxDL,args):
  JzGtOIjeyEABNqvsinoFTYuVQhMxDL.WavveObj.SaveCredential(JzGtOIjeyEABNqvsinoFTYuVQhMxDL.get_winCredential())
  JzGtOIjeyEABNqvsinoFTYuVQhMxmc=JzGtOIjeyEABNqvsinoFTYuVQhMxDL.get_settings_addinfo()
  JzGtOIjeyEABNqvsinoFTYuVQhMxbw =args.get('uicode')
  JzGtOIjeyEABNqvsinoFTYuVQhMxmS=JzGtOIjeyEABNqvsinoFTYuVQhMxrS(args.get('page'))
  JzGtOIjeyEABNqvsinoFTYuVQhMxmX={'adult':args.get('adult'),'broadcastid':args.get('broadcastid'),'contenttype':args.get('contenttype'),'genre':args.get('genre'),'subgenre':args.get('subgenre'),'uiparent':args.get('uiparent'),'uirank':args.get('uirank'),'uitype':args.get('uitype'),'orderby':args.get('orderby')}
  if args.get('genre')==args.get('subgenre'):
   JzGtOIjeyEABNqvsinoFTYuVQhMxmX['subgenre']='all'
  JzGtOIjeyEABNqvsinoFTYuVQhMxbW,JzGtOIjeyEABNqvsinoFTYuVQhMxbD=JzGtOIjeyEABNqvsinoFTYuVQhMxDL.WavveObj.GetGenreList(JzGtOIjeyEABNqvsinoFTYuVQhMxbw,JzGtOIjeyEABNqvsinoFTYuVQhMxmX,JzGtOIjeyEABNqvsinoFTYuVQhMxmS,addinfoyn=JzGtOIjeyEABNqvsinoFTYuVQhMxmc)
  for JzGtOIjeyEABNqvsinoFTYuVQhMxbd in JzGtOIjeyEABNqvsinoFTYuVQhMxbW:
   JzGtOIjeyEABNqvsinoFTYuVQhMxmK =JzGtOIjeyEABNqvsinoFTYuVQhMxbd.get('title')
   JzGtOIjeyEABNqvsinoFTYuVQhMxbr=JzGtOIjeyEABNqvsinoFTYuVQhMxbd.get('thumbnail')
   JzGtOIjeyEABNqvsinoFTYuVQhMxbL=JzGtOIjeyEABNqvsinoFTYuVQhMxbd.get('info')
   if JzGtOIjeyEABNqvsinoFTYuVQhMxbw=='moviegenre_svod' and JzGtOIjeyEABNqvsinoFTYuVQhMxmc==JzGtOIjeyEABNqvsinoFTYuVQhMxrC:
    JzGtOIjeyEABNqvsinoFTYuVQhMxmK='%s (%s)'%(JzGtOIjeyEABNqvsinoFTYuVQhMxmK,JzGtOIjeyEABNqvsinoFTYuVQhMxLm(JzGtOIjeyEABNqvsinoFTYuVQhMxbL.get('year')))
   else:
    JzGtOIjeyEABNqvsinoFTYuVQhMxbL['plot']=JzGtOIjeyEABNqvsinoFTYuVQhMxmK
   if JzGtOIjeyEABNqvsinoFTYuVQhMxbw=='vodgenre':
    JzGtOIjeyEABNqvsinoFTYuVQhMxbl={'mode':'DEEP_LIST','contentid':JzGtOIjeyEABNqvsinoFTYuVQhMxbd.get('uicode'),'contentidType':'contentid','uicode':'vod','page':'1','title':JzGtOIjeyEABNqvsinoFTYuVQhMxmK,'subtitle':'','thumbnail':JzGtOIjeyEABNqvsinoFTYuVQhMxbr,'viewage':JzGtOIjeyEABNqvsinoFTYuVQhMxbd.get('viewage')}
    JzGtOIjeyEABNqvsinoFTYuVQhMxmw=JzGtOIjeyEABNqvsinoFTYuVQhMxrC
   else:
    JzGtOIjeyEABNqvsinoFTYuVQhMxbl={'mode':'MOVIE','contentid':JzGtOIjeyEABNqvsinoFTYuVQhMxbd.get('uicode'),'contentidType':'contentid','uicode':'movie','page':'1','title':JzGtOIjeyEABNqvsinoFTYuVQhMxmK,'subtitle':'','thumbnail':JzGtOIjeyEABNqvsinoFTYuVQhMxbr,'viewage':JzGtOIjeyEABNqvsinoFTYuVQhMxbd.get('viewage')}
    JzGtOIjeyEABNqvsinoFTYuVQhMxmw=JzGtOIjeyEABNqvsinoFTYuVQhMxrp
   if JzGtOIjeyEABNqvsinoFTYuVQhMxbl.get('viewage')=='21':JzGtOIjeyEABNqvsinoFTYuVQhMxmK+=' (%s)'%(JzGtOIjeyEABNqvsinoFTYuVQhMxbl.get('viewage'))
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.add_dir(JzGtOIjeyEABNqvsinoFTYuVQhMxmK,sublabel='',img=JzGtOIjeyEABNqvsinoFTYuVQhMxbr,infoLabels=JzGtOIjeyEABNqvsinoFTYuVQhMxbL,isFolder=JzGtOIjeyEABNqvsinoFTYuVQhMxmw,params=JzGtOIjeyEABNqvsinoFTYuVQhMxbl)
  if JzGtOIjeyEABNqvsinoFTYuVQhMxbD:
   JzGtOIjeyEABNqvsinoFTYuVQhMxmX['mode'] ='GENRE_LIST' 
   JzGtOIjeyEABNqvsinoFTYuVQhMxmX['uicode']=JzGtOIjeyEABNqvsinoFTYuVQhMxbw 
   JzGtOIjeyEABNqvsinoFTYuVQhMxmX['page'] =JzGtOIjeyEABNqvsinoFTYuVQhMxLm(JzGtOIjeyEABNqvsinoFTYuVQhMxmS+1)
   JzGtOIjeyEABNqvsinoFTYuVQhMxmK='[B]%s >>[/B]'%'다음 페이지'
   JzGtOIjeyEABNqvsinoFTYuVQhMxbK=JzGtOIjeyEABNqvsinoFTYuVQhMxLm(JzGtOIjeyEABNqvsinoFTYuVQhMxmS+1)
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.add_dir(JzGtOIjeyEABNqvsinoFTYuVQhMxmK,sublabel=JzGtOIjeyEABNqvsinoFTYuVQhMxbK,img='',infoLabels=JzGtOIjeyEABNqvsinoFTYuVQhMxrc,isFolder=JzGtOIjeyEABNqvsinoFTYuVQhMxrC,params=JzGtOIjeyEABNqvsinoFTYuVQhMxmX)
  if JzGtOIjeyEABNqvsinoFTYuVQhMxLD(JzGtOIjeyEABNqvsinoFTYuVQhMxbW)>0:xbmcplugin.endOfDirectory(JzGtOIjeyEABNqvsinoFTYuVQhMxDL._addon_handle,cacheToDisc=JzGtOIjeyEABNqvsinoFTYuVQhMxrp)
 def dp_Deeplink_List(JzGtOIjeyEABNqvsinoFTYuVQhMxDL,args):
  JzGtOIjeyEABNqvsinoFTYuVQhMxDL.WavveObj.SaveCredential(JzGtOIjeyEABNqvsinoFTYuVQhMxDL.get_winCredential())
  JzGtOIjeyEABNqvsinoFTYuVQhMxmc=JzGtOIjeyEABNqvsinoFTYuVQhMxDL.get_settings_addinfo()
  JzGtOIjeyEABNqvsinoFTYuVQhMxbw =args.get('uicode')
  JzGtOIjeyEABNqvsinoFTYuVQhMxbR =args.get('came')
  JzGtOIjeyEABNqvsinoFTYuVQhMxmS=JzGtOIjeyEABNqvsinoFTYuVQhMxrS(args.get('page'))
  JzGtOIjeyEABNqvsinoFTYuVQhMxbf,JzGtOIjeyEABNqvsinoFTYuVQhMxbD=JzGtOIjeyEABNqvsinoFTYuVQhMxDL.WavveObj.GetDeeplinkList(JzGtOIjeyEABNqvsinoFTYuVQhMxbw,JzGtOIjeyEABNqvsinoFTYuVQhMxbR,JzGtOIjeyEABNqvsinoFTYuVQhMxmS,addinfoyn=JzGtOIjeyEABNqvsinoFTYuVQhMxmc)
  for JzGtOIjeyEABNqvsinoFTYuVQhMxbP in JzGtOIjeyEABNqvsinoFTYuVQhMxbf:
   JzGtOIjeyEABNqvsinoFTYuVQhMxmK =JzGtOIjeyEABNqvsinoFTYuVQhMxbP.get('title')
   JzGtOIjeyEABNqvsinoFTYuVQhMxbK =JzGtOIjeyEABNqvsinoFTYuVQhMxbP.get('subtitle')
   JzGtOIjeyEABNqvsinoFTYuVQhMxbr=JzGtOIjeyEABNqvsinoFTYuVQhMxbP.get('thumbnail')
   JzGtOIjeyEABNqvsinoFTYuVQhMxbk=JzGtOIjeyEABNqvsinoFTYuVQhMxbP.get('uicode')
   JzGtOIjeyEABNqvsinoFTYuVQhMxbc=JzGtOIjeyEABNqvsinoFTYuVQhMxbP.get('channelepg')
   JzGtOIjeyEABNqvsinoFTYuVQhMxmX={'uicode':JzGtOIjeyEABNqvsinoFTYuVQhMxbk,'came':JzGtOIjeyEABNqvsinoFTYuVQhMxbR,'contentid':JzGtOIjeyEABNqvsinoFTYuVQhMxbP.get('contentid'),'contentidType':JzGtOIjeyEABNqvsinoFTYuVQhMxbP.get('contentidType'),'page':'1','title':JzGtOIjeyEABNqvsinoFTYuVQhMxmK,'subtitle':JzGtOIjeyEABNqvsinoFTYuVQhMxbK,'thumbnail':JzGtOIjeyEABNqvsinoFTYuVQhMxbr,'viewage':JzGtOIjeyEABNqvsinoFTYuVQhMxbP.get('viewage')}
   if JzGtOIjeyEABNqvsinoFTYuVQhMxbk=='channel':
    JzGtOIjeyEABNqvsinoFTYuVQhMxmX['mode'] ='LIVE'
   elif JzGtOIjeyEABNqvsinoFTYuVQhMxbk=='movie':
    JzGtOIjeyEABNqvsinoFTYuVQhMxmX['mode'] ='MOVIE'
   else:
    JzGtOIjeyEABNqvsinoFTYuVQhMxmX['mode'] ='DEEP_LIST'
   JzGtOIjeyEABNqvsinoFTYuVQhMxbL=JzGtOIjeyEABNqvsinoFTYuVQhMxbP.get('info')
   if JzGtOIjeyEABNqvsinoFTYuVQhMxbc:
    JzGtOIjeyEABNqvsinoFTYuVQhMxbL['plot']='%s\n\n%s'%(JzGtOIjeyEABNqvsinoFTYuVQhMxmK,JzGtOIjeyEABNqvsinoFTYuVQhMxbc)
   elif JzGtOIjeyEABNqvsinoFTYuVQhMxbk=='movie' and JzGtOIjeyEABNqvsinoFTYuVQhMxmc==JzGtOIjeyEABNqvsinoFTYuVQhMxrC:
    JzGtOIjeyEABNqvsinoFTYuVQhMxmK='%s (%s)'%(JzGtOIjeyEABNqvsinoFTYuVQhMxmK,JzGtOIjeyEABNqvsinoFTYuVQhMxLm(JzGtOIjeyEABNqvsinoFTYuVQhMxbL.get('year')))
   else:
    JzGtOIjeyEABNqvsinoFTYuVQhMxbL['plot']='%s\n\n%s'%(JzGtOIjeyEABNqvsinoFTYuVQhMxmK,JzGtOIjeyEABNqvsinoFTYuVQhMxbK)
   if JzGtOIjeyEABNqvsinoFTYuVQhMxbP.get('viewage')=='21':JzGtOIjeyEABNqvsinoFTYuVQhMxbK+=' (%s)'%(JzGtOIjeyEABNqvsinoFTYuVQhMxbP.get('viewage'))
   if JzGtOIjeyEABNqvsinoFTYuVQhMxbk in['channel','movie']:
    JzGtOIjeyEABNqvsinoFTYuVQhMxmw=JzGtOIjeyEABNqvsinoFTYuVQhMxrp
   elif JzGtOIjeyEABNqvsinoFTYuVQhMxmX['contentidType']=='direct':
    JzGtOIjeyEABNqvsinoFTYuVQhMxmw=JzGtOIjeyEABNqvsinoFTYuVQhMxrp
    JzGtOIjeyEABNqvsinoFTYuVQhMxmX['mode']='VOD'
   else:
    JzGtOIjeyEABNqvsinoFTYuVQhMxmw=JzGtOIjeyEABNqvsinoFTYuVQhMxrC
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.add_dir(JzGtOIjeyEABNqvsinoFTYuVQhMxmK,sublabel=JzGtOIjeyEABNqvsinoFTYuVQhMxbK,img=JzGtOIjeyEABNqvsinoFTYuVQhMxbr,infoLabels=JzGtOIjeyEABNqvsinoFTYuVQhMxbL,isFolder=JzGtOIjeyEABNqvsinoFTYuVQhMxmw,params=JzGtOIjeyEABNqvsinoFTYuVQhMxmX)
  if JzGtOIjeyEABNqvsinoFTYuVQhMxbD:
   JzGtOIjeyEABNqvsinoFTYuVQhMxmX['mode'] ='GN_LIST' 
   JzGtOIjeyEABNqvsinoFTYuVQhMxmX['uicode']=JzGtOIjeyEABNqvsinoFTYuVQhMxbw 
   JzGtOIjeyEABNqvsinoFTYuVQhMxmX['page'] =JzGtOIjeyEABNqvsinoFTYuVQhMxLm(JzGtOIjeyEABNqvsinoFTYuVQhMxmS+1)
   JzGtOIjeyEABNqvsinoFTYuVQhMxmK='[B]%s >>[/B]'%'다음 페이지'
   JzGtOIjeyEABNqvsinoFTYuVQhMxbK=JzGtOIjeyEABNqvsinoFTYuVQhMxLm(JzGtOIjeyEABNqvsinoFTYuVQhMxmS+1)
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.add_dir(JzGtOIjeyEABNqvsinoFTYuVQhMxmK,sublabel=JzGtOIjeyEABNqvsinoFTYuVQhMxbK,img='',infoLabels=JzGtOIjeyEABNqvsinoFTYuVQhMxrc,isFolder=JzGtOIjeyEABNqvsinoFTYuVQhMxrC,params=JzGtOIjeyEABNqvsinoFTYuVQhMxmX)
  if JzGtOIjeyEABNqvsinoFTYuVQhMxLD(JzGtOIjeyEABNqvsinoFTYuVQhMxbf)>0:xbmcplugin.endOfDirectory(JzGtOIjeyEABNqvsinoFTYuVQhMxDL._addon_handle,cacheToDisc=JzGtOIjeyEABNqvsinoFTYuVQhMxrp)
 def dp_Episodelink_List(JzGtOIjeyEABNqvsinoFTYuVQhMxDL,args):
  JzGtOIjeyEABNqvsinoFTYuVQhMxDL.WavveObj.SaveCredential(JzGtOIjeyEABNqvsinoFTYuVQhMxDL.get_winCredential())
  JzGtOIjeyEABNqvsinoFTYuVQhMxbp =args.get('contentid')
  JzGtOIjeyEABNqvsinoFTYuVQhMxbS=args.get('contentidType')
  JzGtOIjeyEABNqvsinoFTYuVQhMxmp =args.get('uicode')
  JzGtOIjeyEABNqvsinoFTYuVQhMxmS =JzGtOIjeyEABNqvsinoFTYuVQhMxrS(args.get('page'))
  JzGtOIjeyEABNqvsinoFTYuVQhMxbC,JzGtOIjeyEABNqvsinoFTYuVQhMxbD=JzGtOIjeyEABNqvsinoFTYuVQhMxDL.WavveObj.GetEpisodeList(JzGtOIjeyEABNqvsinoFTYuVQhMxbp,JzGtOIjeyEABNqvsinoFTYuVQhMxmp,JzGtOIjeyEABNqvsinoFTYuVQhMxbS,JzGtOIjeyEABNqvsinoFTYuVQhMxmS,orderby=JzGtOIjeyEABNqvsinoFTYuVQhMxDL.get_winEpisodeOrderby())
  for JzGtOIjeyEABNqvsinoFTYuVQhMxKD in JzGtOIjeyEABNqvsinoFTYuVQhMxbC:
   JzGtOIjeyEABNqvsinoFTYuVQhMxmK =JzGtOIjeyEABNqvsinoFTYuVQhMxKD.get('title')
   JzGtOIjeyEABNqvsinoFTYuVQhMxbK =JzGtOIjeyEABNqvsinoFTYuVQhMxKD.get('subtitle')
   JzGtOIjeyEABNqvsinoFTYuVQhMxbr=JzGtOIjeyEABNqvsinoFTYuVQhMxKD.get('thumbnail')
   JzGtOIjeyEABNqvsinoFTYuVQhMxmX={'mode':'VOD','uicode':JzGtOIjeyEABNqvsinoFTYuVQhMxKD.get('uicode'),'contentid':JzGtOIjeyEABNqvsinoFTYuVQhMxKD.get('contentid'),'programid':JzGtOIjeyEABNqvsinoFTYuVQhMxKD.get('programid'),'title':JzGtOIjeyEABNqvsinoFTYuVQhMxmK,'subtitle':JzGtOIjeyEABNqvsinoFTYuVQhMxbK,'thumbnail':JzGtOIjeyEABNqvsinoFTYuVQhMxbr,'viewage':JzGtOIjeyEABNqvsinoFTYuVQhMxKD.get('viewage')}
   if JzGtOIjeyEABNqvsinoFTYuVQhMxKD.get('viewage')=='21':JzGtOIjeyEABNqvsinoFTYuVQhMxbK+=' (%s)'%(JzGtOIjeyEABNqvsinoFTYuVQhMxKD.get('viewage'))
   JzGtOIjeyEABNqvsinoFTYuVQhMxKm=JzGtOIjeyEABNqvsinoFTYuVQhMxKD.get('info')
   JzGtOIjeyEABNqvsinoFTYuVQhMxKm['plot']=JzGtOIjeyEABNqvsinoFTYuVQhMxKD.get('synopsis')
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.add_dir(JzGtOIjeyEABNqvsinoFTYuVQhMxmK,sublabel=JzGtOIjeyEABNqvsinoFTYuVQhMxbK,img=JzGtOIjeyEABNqvsinoFTYuVQhMxbr,infoLabels=JzGtOIjeyEABNqvsinoFTYuVQhMxKm,isFolder=JzGtOIjeyEABNqvsinoFTYuVQhMxrp,params=JzGtOIjeyEABNqvsinoFTYuVQhMxmX)
  if JzGtOIjeyEABNqvsinoFTYuVQhMxmS==1:
   JzGtOIjeyEABNqvsinoFTYuVQhMxbL={'plot':'정렬순서를 변경합니다.'}
   JzGtOIjeyEABNqvsinoFTYuVQhMxmX={}
   JzGtOIjeyEABNqvsinoFTYuVQhMxmX['mode'] ='ORDER_BY' 
   if JzGtOIjeyEABNqvsinoFTYuVQhMxDL.get_winEpisodeOrderby()=='desc':
    JzGtOIjeyEABNqvsinoFTYuVQhMxmK='정렬순서변경 : 최신화부터 -> 1회부터'
    JzGtOIjeyEABNqvsinoFTYuVQhMxmX['orderby']='asc'
   else:
    JzGtOIjeyEABNqvsinoFTYuVQhMxmK='정렬순서변경 : 1회부터 -> 최신화부터'
    JzGtOIjeyEABNqvsinoFTYuVQhMxmX['orderby']='desc'
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.add_dir(JzGtOIjeyEABNqvsinoFTYuVQhMxmK,sublabel='',img='',infoLabels=JzGtOIjeyEABNqvsinoFTYuVQhMxbL,isFolder=JzGtOIjeyEABNqvsinoFTYuVQhMxrp,params=JzGtOIjeyEABNqvsinoFTYuVQhMxmX)
  if JzGtOIjeyEABNqvsinoFTYuVQhMxbD:
   JzGtOIjeyEABNqvsinoFTYuVQhMxmX['mode'] ='DEEP_LIST' 
   JzGtOIjeyEABNqvsinoFTYuVQhMxmX['uicode'] =JzGtOIjeyEABNqvsinoFTYuVQhMxmp 
   JzGtOIjeyEABNqvsinoFTYuVQhMxmX['contentid'] =JzGtOIjeyEABNqvsinoFTYuVQhMxbp 
   JzGtOIjeyEABNqvsinoFTYuVQhMxmX['contentidType']=JzGtOIjeyEABNqvsinoFTYuVQhMxbS 
   JzGtOIjeyEABNqvsinoFTYuVQhMxmX['page'] =JzGtOIjeyEABNqvsinoFTYuVQhMxLm(JzGtOIjeyEABNqvsinoFTYuVQhMxmS+1)
   JzGtOIjeyEABNqvsinoFTYuVQhMxmK='[B]%s >>[/B]'%'다음 페이지'
   JzGtOIjeyEABNqvsinoFTYuVQhMxbK=JzGtOIjeyEABNqvsinoFTYuVQhMxLm(JzGtOIjeyEABNqvsinoFTYuVQhMxmS+1)
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.add_dir(JzGtOIjeyEABNqvsinoFTYuVQhMxmK,sublabel=JzGtOIjeyEABNqvsinoFTYuVQhMxbK,img='',infoLabels=JzGtOIjeyEABNqvsinoFTYuVQhMxrc,isFolder=JzGtOIjeyEABNqvsinoFTYuVQhMxrC,params=JzGtOIjeyEABNqvsinoFTYuVQhMxmX)
  if JzGtOIjeyEABNqvsinoFTYuVQhMxLD(JzGtOIjeyEABNqvsinoFTYuVQhMxbC)>0:xbmcplugin.endOfDirectory(JzGtOIjeyEABNqvsinoFTYuVQhMxDL._addon_handle,cacheToDisc=JzGtOIjeyEABNqvsinoFTYuVQhMxrC)
 def play_VIDEO(JzGtOIjeyEABNqvsinoFTYuVQhMxDL,args):
  JzGtOIjeyEABNqvsinoFTYuVQhMxDL.WavveObj.SaveCredential(JzGtOIjeyEABNqvsinoFTYuVQhMxDL.get_winCredential())
  JzGtOIjeyEABNqvsinoFTYuVQhMxbp =args.get('contentid')
  JzGtOIjeyEABNqvsinoFTYuVQhMxmp=args.get('uicode')
  JzGtOIjeyEABNqvsinoFTYuVQhMxKb=JzGtOIjeyEABNqvsinoFTYuVQhMxDL.get_selQuality()
  JzGtOIjeyEABNqvsinoFTYuVQhMxDL.addon_log(JzGtOIjeyEABNqvsinoFTYuVQhMxbp+' - '+JzGtOIjeyEABNqvsinoFTYuVQhMxmp,JzGtOIjeyEABNqvsinoFTYuVQhMxrp)
  JzGtOIjeyEABNqvsinoFTYuVQhMxKr,JzGtOIjeyEABNqvsinoFTYuVQhMxKL,JzGtOIjeyEABNqvsinoFTYuVQhMxKX,JzGtOIjeyEABNqvsinoFTYuVQhMxKw=JzGtOIjeyEABNqvsinoFTYuVQhMxDL.WavveObj.GetStreamingURL(JzGtOIjeyEABNqvsinoFTYuVQhMxbp,JzGtOIjeyEABNqvsinoFTYuVQhMxmp,JzGtOIjeyEABNqvsinoFTYuVQhMxKb)
  JzGtOIjeyEABNqvsinoFTYuVQhMxKa='%s|Cookie=%s'%(JzGtOIjeyEABNqvsinoFTYuVQhMxKr,JzGtOIjeyEABNqvsinoFTYuVQhMxKL)
  JzGtOIjeyEABNqvsinoFTYuVQhMxDL.addon_log(JzGtOIjeyEABNqvsinoFTYuVQhMxKa,JzGtOIjeyEABNqvsinoFTYuVQhMxrp)
  if JzGtOIjeyEABNqvsinoFTYuVQhMxKr=='':
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.addon_noti(__language__(30907).encode('utf8'))
   return
  JzGtOIjeyEABNqvsinoFTYuVQhMxKU=xbmcgui.ListItem(path=JzGtOIjeyEABNqvsinoFTYuVQhMxKa)
  if JzGtOIjeyEABNqvsinoFTYuVQhMxKX:
   JzGtOIjeyEABNqvsinoFTYuVQhMxKg=JzGtOIjeyEABNqvsinoFTYuVQhMxKX['customdata']
   JzGtOIjeyEABNqvsinoFTYuVQhMxKW =JzGtOIjeyEABNqvsinoFTYuVQhMxKX['drmhost']
   JzGtOIjeyEABNqvsinoFTYuVQhMxKH =inputstreamhelper.Helper('mpd',drm='widevine')
   if JzGtOIjeyEABNqvsinoFTYuVQhMxKH.check_inputstream():
    if JzGtOIjeyEABNqvsinoFTYuVQhMxmp=='movie':
     JzGtOIjeyEABNqvsinoFTYuVQhMxKd='https://www.wavve.com/player/movie?movieid=%s'%JzGtOIjeyEABNqvsinoFTYuVQhMxbp
    else:
     JzGtOIjeyEABNqvsinoFTYuVQhMxKd='https://www.wavve.com/player/vod?programid=%s&page=1'%JzGtOIjeyEABNqvsinoFTYuVQhMxbp
    JzGtOIjeyEABNqvsinoFTYuVQhMxKl={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':JzGtOIjeyEABNqvsinoFTYuVQhMxKg,'referer':JzGtOIjeyEABNqvsinoFTYuVQhMxKd,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':JzGtOIjeyEABNqvsinoFTYuVQhMxDK}
    JzGtOIjeyEABNqvsinoFTYuVQhMxKR=JzGtOIjeyEABNqvsinoFTYuVQhMxKW+'|'+urllib.parse.urlencode(JzGtOIjeyEABNqvsinoFTYuVQhMxKl)+'|R{SSM}|'
    JzGtOIjeyEABNqvsinoFTYuVQhMxKU.setProperty('inputstream',JzGtOIjeyEABNqvsinoFTYuVQhMxKH.inputstream_addon)
    JzGtOIjeyEABNqvsinoFTYuVQhMxKU.setProperty('inputstream.adaptive.manifest_type','mpd')
    JzGtOIjeyEABNqvsinoFTYuVQhMxKU.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    JzGtOIjeyEABNqvsinoFTYuVQhMxKU.setProperty('inputstream.adaptive.license_key',JzGtOIjeyEABNqvsinoFTYuVQhMxKR)
    JzGtOIjeyEABNqvsinoFTYuVQhMxKU.setProperty('inputstream.adaptive.stream_headers','user-agent=%s&Cookie=%s'%(JzGtOIjeyEABNqvsinoFTYuVQhMxDK,JzGtOIjeyEABNqvsinoFTYuVQhMxKL))
  xbmcplugin.setResolvedUrl(JzGtOIjeyEABNqvsinoFTYuVQhMxDL._addon_handle,JzGtOIjeyEABNqvsinoFTYuVQhMxrC,JzGtOIjeyEABNqvsinoFTYuVQhMxKU)
  if JzGtOIjeyEABNqvsinoFTYuVQhMxKw:
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.addon_noti(JzGtOIjeyEABNqvsinoFTYuVQhMxKw.encode('utf-8'))
  else:
   if '/preview.' in urllib.parse.urlsplit(JzGtOIjeyEABNqvsinoFTYuVQhMxKr).path:JzGtOIjeyEABNqvsinoFTYuVQhMxDL.addon_noti(__language__(30908).encode('utf8'))
  try:
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('viewage')!='21':
    JzGtOIjeyEABNqvsinoFTYuVQhMxmX={'code':args.get('programid')if args.get('mode')=='VOD' else args.get('contentid'),'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    JzGtOIjeyEABNqvsinoFTYuVQhMxDL.Save_Watched_List(args.get('mode').lower(),JzGtOIjeyEABNqvsinoFTYuVQhMxmX)
  except:
   JzGtOIjeyEABNqvsinoFTYuVQhMxrc
 def dp_Watch_List(JzGtOIjeyEABNqvsinoFTYuVQhMxDL,args):
  JzGtOIjeyEABNqvsinoFTYuVQhMxba =args.get('genre')
  JzGtOIjeyEABNqvsinoFTYuVQhMxDp=JzGtOIjeyEABNqvsinoFTYuVQhMxDL.get_settings_direct_replay()
  if JzGtOIjeyEABNqvsinoFTYuVQhMxba=='-':
   JzGtOIjeyEABNqvsinoFTYuVQhMxmK='VOD 시청내역'
   JzGtOIjeyEABNqvsinoFTYuVQhMxmX={'mode':'WATCH','genre':'vod'}
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.add_dir(JzGtOIjeyEABNqvsinoFTYuVQhMxmK,sublabel='',img='',infoLabels=JzGtOIjeyEABNqvsinoFTYuVQhMxrc,isFolder=JzGtOIjeyEABNqvsinoFTYuVQhMxrC,params=JzGtOIjeyEABNqvsinoFTYuVQhMxmX)
   JzGtOIjeyEABNqvsinoFTYuVQhMxmK='영화 시청내역'
   JzGtOIjeyEABNqvsinoFTYuVQhMxmX['genre']='movie'
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.add_dir(JzGtOIjeyEABNqvsinoFTYuVQhMxmK,sublabel='',img='',infoLabels=JzGtOIjeyEABNqvsinoFTYuVQhMxrc,isFolder=JzGtOIjeyEABNqvsinoFTYuVQhMxrC,params=JzGtOIjeyEABNqvsinoFTYuVQhMxmX)
   xbmcplugin.endOfDirectory(JzGtOIjeyEABNqvsinoFTYuVQhMxDL._addon_handle)
  else:
   JzGtOIjeyEABNqvsinoFTYuVQhMxKf=JzGtOIjeyEABNqvsinoFTYuVQhMxDL.Load_Watched_List(JzGtOIjeyEABNqvsinoFTYuVQhMxba)
   for JzGtOIjeyEABNqvsinoFTYuVQhMxKP in JzGtOIjeyEABNqvsinoFTYuVQhMxKf:
    JzGtOIjeyEABNqvsinoFTYuVQhMxKk=JzGtOIjeyEABNqvsinoFTYuVQhMxLb(urllib.parse.parse_qsl(JzGtOIjeyEABNqvsinoFTYuVQhMxKP))
    JzGtOIjeyEABNqvsinoFTYuVQhMxmK =JzGtOIjeyEABNqvsinoFTYuVQhMxKk.get('title').strip()
    JzGtOIjeyEABNqvsinoFTYuVQhMxbK =JzGtOIjeyEABNqvsinoFTYuVQhMxKk.get('subtitle').strip()
    if JzGtOIjeyEABNqvsinoFTYuVQhMxbK=='None':JzGtOIjeyEABNqvsinoFTYuVQhMxbK=''
    JzGtOIjeyEABNqvsinoFTYuVQhMxbr=JzGtOIjeyEABNqvsinoFTYuVQhMxKk.get('img')
    JzGtOIjeyEABNqvsinoFTYuVQhMxKc =JzGtOIjeyEABNqvsinoFTYuVQhMxKk.get('videoid')
    JzGtOIjeyEABNqvsinoFTYuVQhMxbL={}
    if JzGtOIjeyEABNqvsinoFTYuVQhMxba=='movie' and JzGtOIjeyEABNqvsinoFTYuVQhMxDL.get_settings_addinfo()==JzGtOIjeyEABNqvsinoFTYuVQhMxrC:
     JzGtOIjeyEABNqvsinoFTYuVQhMxKp=JzGtOIjeyEABNqvsinoFTYuVQhMxDL.WavveObj.GetMovieInfoList([JzGtOIjeyEABNqvsinoFTYuVQhMxKk.get('code')])
     JzGtOIjeyEABNqvsinoFTYuVQhMxbL=JzGtOIjeyEABNqvsinoFTYuVQhMxKp.get(JzGtOIjeyEABNqvsinoFTYuVQhMxKk.get('code'))
    else:
     JzGtOIjeyEABNqvsinoFTYuVQhMxbL['plot']='%s\n%s'%(JzGtOIjeyEABNqvsinoFTYuVQhMxmK,JzGtOIjeyEABNqvsinoFTYuVQhMxbK)
    if JzGtOIjeyEABNqvsinoFTYuVQhMxba=='vod':
     if JzGtOIjeyEABNqvsinoFTYuVQhMxDp==JzGtOIjeyEABNqvsinoFTYuVQhMxrp or JzGtOIjeyEABNqvsinoFTYuVQhMxKc==JzGtOIjeyEABNqvsinoFTYuVQhMxrc:
      JzGtOIjeyEABNqvsinoFTYuVQhMxmX={'mode':'DEEP_LIST','contentid':JzGtOIjeyEABNqvsinoFTYuVQhMxKk.get('code'),'contentidType':'programid','uicode':'vod','page':'1'}
      JzGtOIjeyEABNqvsinoFTYuVQhMxmw=JzGtOIjeyEABNqvsinoFTYuVQhMxrC
     else:
      JzGtOIjeyEABNqvsinoFTYuVQhMxmX={'mode':'VOD','contentid':JzGtOIjeyEABNqvsinoFTYuVQhMxKc,'contentidType':'contentid','programid':JzGtOIjeyEABNqvsinoFTYuVQhMxKk.get('code'),'uicode':'vod','title':JzGtOIjeyEABNqvsinoFTYuVQhMxmK,'subtitle':JzGtOIjeyEABNqvsinoFTYuVQhMxbK,'thumbnail':JzGtOIjeyEABNqvsinoFTYuVQhMxbr}
      JzGtOIjeyEABNqvsinoFTYuVQhMxmw=JzGtOIjeyEABNqvsinoFTYuVQhMxrp
    else:
     JzGtOIjeyEABNqvsinoFTYuVQhMxmX={'mode':'MOVIE','contentid':JzGtOIjeyEABNqvsinoFTYuVQhMxKk.get('code'),'contentidType':'contentid','uicode':'movie','title':JzGtOIjeyEABNqvsinoFTYuVQhMxmK,'thumbnail':JzGtOIjeyEABNqvsinoFTYuVQhMxbr}
     JzGtOIjeyEABNqvsinoFTYuVQhMxmw=JzGtOIjeyEABNqvsinoFTYuVQhMxrp
    JzGtOIjeyEABNqvsinoFTYuVQhMxDL.add_dir(JzGtOIjeyEABNqvsinoFTYuVQhMxmK,sublabel=JzGtOIjeyEABNqvsinoFTYuVQhMxbK,img=JzGtOIjeyEABNqvsinoFTYuVQhMxbr,infoLabels=JzGtOIjeyEABNqvsinoFTYuVQhMxbL,isFolder=JzGtOIjeyEABNqvsinoFTYuVQhMxmw,params=JzGtOIjeyEABNqvsinoFTYuVQhMxmX)
   JzGtOIjeyEABNqvsinoFTYuVQhMxbL={'plot':'시청목록을 삭제합니다.'}
   JzGtOIjeyEABNqvsinoFTYuVQhMxmK='*** 시청목록 삭제 ***'
   JzGtOIjeyEABNqvsinoFTYuVQhMxmX={'mode':'MYVIEW_REMOVE','genre':JzGtOIjeyEABNqvsinoFTYuVQhMxba}
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.add_dir(JzGtOIjeyEABNqvsinoFTYuVQhMxmK,sublabel='',img='',infoLabels=JzGtOIjeyEABNqvsinoFTYuVQhMxbL,isFolder=JzGtOIjeyEABNqvsinoFTYuVQhMxrp,params=JzGtOIjeyEABNqvsinoFTYuVQhMxmX)
   xbmcplugin.endOfDirectory(JzGtOIjeyEABNqvsinoFTYuVQhMxDL._addon_handle,cacheToDisc=JzGtOIjeyEABNqvsinoFTYuVQhMxrp)
 def dp_Search_Group(JzGtOIjeyEABNqvsinoFTYuVQhMxDL,args):
  JzGtOIjeyEABNqvsinoFTYuVQhMxmK='VOD 검색'
  JzGtOIjeyEABNqvsinoFTYuVQhMxmX={'mode':'SEARCH_LIST','genre':'vod','page':'1'}
  JzGtOIjeyEABNqvsinoFTYuVQhMxDL.add_dir(JzGtOIjeyEABNqvsinoFTYuVQhMxmK,sublabel='',img='',infoLabels=JzGtOIjeyEABNqvsinoFTYuVQhMxrc,isFolder=JzGtOIjeyEABNqvsinoFTYuVQhMxrC,params=JzGtOIjeyEABNqvsinoFTYuVQhMxmX)
  JzGtOIjeyEABNqvsinoFTYuVQhMxmK='영화 검색'
  JzGtOIjeyEABNqvsinoFTYuVQhMxmX['genre']='movie'
  JzGtOIjeyEABNqvsinoFTYuVQhMxDL.add_dir(JzGtOIjeyEABNqvsinoFTYuVQhMxmK,sublabel='',img='',infoLabels=JzGtOIjeyEABNqvsinoFTYuVQhMxrc,isFolder=JzGtOIjeyEABNqvsinoFTYuVQhMxrC,params=JzGtOIjeyEABNqvsinoFTYuVQhMxmX)
  xbmcplugin.endOfDirectory(JzGtOIjeyEABNqvsinoFTYuVQhMxDL._addon_handle)
 def dp_Search_List(JzGtOIjeyEABNqvsinoFTYuVQhMxDL,args):
  JzGtOIjeyEABNqvsinoFTYuVQhMxDL.WavveObj.SaveCredential(JzGtOIjeyEABNqvsinoFTYuVQhMxDL.get_winCredential())
  JzGtOIjeyEABNqvsinoFTYuVQhMxmc=JzGtOIjeyEABNqvsinoFTYuVQhMxDL.get_settings_addinfo()
  JzGtOIjeyEABNqvsinoFTYuVQhMxmp=args.get('genre')
  JzGtOIjeyEABNqvsinoFTYuVQhMxmS =JzGtOIjeyEABNqvsinoFTYuVQhMxrS(args.get('page'))
  if 'search_key' in args:
   JzGtOIjeyEABNqvsinoFTYuVQhMxKC=args.get('search_key')
  else:
   JzGtOIjeyEABNqvsinoFTYuVQhMxKC=JzGtOIjeyEABNqvsinoFTYuVQhMxDL.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not JzGtOIjeyEABNqvsinoFTYuVQhMxKC:return
  JzGtOIjeyEABNqvsinoFTYuVQhMxrD,JzGtOIjeyEABNqvsinoFTYuVQhMxbD=JzGtOIjeyEABNqvsinoFTYuVQhMxDL.WavveObj.GetSearchList(JzGtOIjeyEABNqvsinoFTYuVQhMxKC,JzGtOIjeyEABNqvsinoFTYuVQhMxmp,JzGtOIjeyEABNqvsinoFTYuVQhMxmS,exclusion21=JzGtOIjeyEABNqvsinoFTYuVQhMxDL.get_settings_exclusion21(),addinfoyn=JzGtOIjeyEABNqvsinoFTYuVQhMxmc)
  for JzGtOIjeyEABNqvsinoFTYuVQhMxrm in JzGtOIjeyEABNqvsinoFTYuVQhMxrD:
   JzGtOIjeyEABNqvsinoFTYuVQhMxmK =JzGtOIjeyEABNqvsinoFTYuVQhMxrm.get('title')
   JzGtOIjeyEABNqvsinoFTYuVQhMxbr=JzGtOIjeyEABNqvsinoFTYuVQhMxrm.get('thumbnail')
   JzGtOIjeyEABNqvsinoFTYuVQhMxbL=JzGtOIjeyEABNqvsinoFTYuVQhMxrm.get('info')
   if JzGtOIjeyEABNqvsinoFTYuVQhMxmp=='movie' and JzGtOIjeyEABNqvsinoFTYuVQhMxmc==JzGtOIjeyEABNqvsinoFTYuVQhMxrC:
    JzGtOIjeyEABNqvsinoFTYuVQhMxmK='%s (%s)'%(JzGtOIjeyEABNqvsinoFTYuVQhMxmK,JzGtOIjeyEABNqvsinoFTYuVQhMxLm(JzGtOIjeyEABNqvsinoFTYuVQhMxbL.get('year')))
   else:
    JzGtOIjeyEABNqvsinoFTYuVQhMxbL['plot']=JzGtOIjeyEABNqvsinoFTYuVQhMxmK
   if JzGtOIjeyEABNqvsinoFTYuVQhMxmp=='vod':
    JzGtOIjeyEABNqvsinoFTYuVQhMxmX={'mode':'DEEP_LIST','contentid':JzGtOIjeyEABNqvsinoFTYuVQhMxrm.get('programid'),'contentidType':'programid','uicode':'vod','page':'1','title':JzGtOIjeyEABNqvsinoFTYuVQhMxmK,'subtitle':'','thumbnail':JzGtOIjeyEABNqvsinoFTYuVQhMxbr,'viewage':JzGtOIjeyEABNqvsinoFTYuVQhMxrm.get('viewage')}
    JzGtOIjeyEABNqvsinoFTYuVQhMxmw=JzGtOIjeyEABNqvsinoFTYuVQhMxrC
   else:
    JzGtOIjeyEABNqvsinoFTYuVQhMxmX={'mode':'MOVIE','contentid':JzGtOIjeyEABNqvsinoFTYuVQhMxrm.get('contentid'),'contentidType':'contentid','uicode':'movie','page':'1','title':JzGtOIjeyEABNqvsinoFTYuVQhMxmK,'subtitle':'','thumbnail':JzGtOIjeyEABNqvsinoFTYuVQhMxbr,'viewage':JzGtOIjeyEABNqvsinoFTYuVQhMxrm.get('viewage')}
    JzGtOIjeyEABNqvsinoFTYuVQhMxmw=JzGtOIjeyEABNqvsinoFTYuVQhMxrp
   if JzGtOIjeyEABNqvsinoFTYuVQhMxmX.get('viewage')=='21':JzGtOIjeyEABNqvsinoFTYuVQhMxmK+=' (%s)'%(JzGtOIjeyEABNqvsinoFTYuVQhMxmX.get('viewage'))
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.add_dir(JzGtOIjeyEABNqvsinoFTYuVQhMxmK,sublabel='',img=JzGtOIjeyEABNqvsinoFTYuVQhMxbr,infoLabels=JzGtOIjeyEABNqvsinoFTYuVQhMxbL,isFolder=JzGtOIjeyEABNqvsinoFTYuVQhMxmw,params=JzGtOIjeyEABNqvsinoFTYuVQhMxmX)
  if JzGtOIjeyEABNqvsinoFTYuVQhMxbD:
   JzGtOIjeyEABNqvsinoFTYuVQhMxmX['mode'] ='SEARCH_LIST' 
   JzGtOIjeyEABNqvsinoFTYuVQhMxmX['genre']=JzGtOIjeyEABNqvsinoFTYuVQhMxmp 
   JzGtOIjeyEABNqvsinoFTYuVQhMxmX['page'] =JzGtOIjeyEABNqvsinoFTYuVQhMxLm(JzGtOIjeyEABNqvsinoFTYuVQhMxmS+1)
   JzGtOIjeyEABNqvsinoFTYuVQhMxmX['search_key']=JzGtOIjeyEABNqvsinoFTYuVQhMxKC
   JzGtOIjeyEABNqvsinoFTYuVQhMxmK='[B]%s >>[/B]'%'다음 페이지'
   JzGtOIjeyEABNqvsinoFTYuVQhMxbK=JzGtOIjeyEABNqvsinoFTYuVQhMxLm(JzGtOIjeyEABNqvsinoFTYuVQhMxmS+1)
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.add_dir(JzGtOIjeyEABNqvsinoFTYuVQhMxmK,sublabel=JzGtOIjeyEABNqvsinoFTYuVQhMxbK,img='',infoLabels=JzGtOIjeyEABNqvsinoFTYuVQhMxrc,isFolder=JzGtOIjeyEABNqvsinoFTYuVQhMxrC,params=JzGtOIjeyEABNqvsinoFTYuVQhMxmX)
  if JzGtOIjeyEABNqvsinoFTYuVQhMxLD(JzGtOIjeyEABNqvsinoFTYuVQhMxrD)>0:xbmcplugin.endOfDirectory(JzGtOIjeyEABNqvsinoFTYuVQhMxDL._addon_handle)
 def Load_Watched_List(JzGtOIjeyEABNqvsinoFTYuVQhMxDL,JzGtOIjeyEABNqvsinoFTYuVQhMxba):
  try:
   JzGtOIjeyEABNqvsinoFTYuVQhMxrb=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%JzGtOIjeyEABNqvsinoFTYuVQhMxba))
   with JzGtOIjeyEABNqvsinoFTYuVQhMxLK(JzGtOIjeyEABNqvsinoFTYuVQhMxrb,'r',-1,'utf-8')as fp:
    JzGtOIjeyEABNqvsinoFTYuVQhMxrK=fp.readlines()
  except:
   JzGtOIjeyEABNqvsinoFTYuVQhMxrK=[]
  return JzGtOIjeyEABNqvsinoFTYuVQhMxrK
 def Save_Watched_List(JzGtOIjeyEABNqvsinoFTYuVQhMxDL,JzGtOIjeyEABNqvsinoFTYuVQhMxba,JzGtOIjeyEABNqvsinoFTYuVQhMxDa):
  try:
   JzGtOIjeyEABNqvsinoFTYuVQhMxrb=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%JzGtOIjeyEABNqvsinoFTYuVQhMxba))
   JzGtOIjeyEABNqvsinoFTYuVQhMxrL=JzGtOIjeyEABNqvsinoFTYuVQhMxDL.Load_Watched_List(JzGtOIjeyEABNqvsinoFTYuVQhMxba) 
   with JzGtOIjeyEABNqvsinoFTYuVQhMxLK(JzGtOIjeyEABNqvsinoFTYuVQhMxrb,'w',-1,'utf-8')as fp:
    JzGtOIjeyEABNqvsinoFTYuVQhMxrX=urllib.parse.urlencode(JzGtOIjeyEABNqvsinoFTYuVQhMxDa)
    JzGtOIjeyEABNqvsinoFTYuVQhMxrX=JzGtOIjeyEABNqvsinoFTYuVQhMxrX+'\n'
    fp.write(JzGtOIjeyEABNqvsinoFTYuVQhMxrX)
    JzGtOIjeyEABNqvsinoFTYuVQhMxrw=0
    for JzGtOIjeyEABNqvsinoFTYuVQhMxra in JzGtOIjeyEABNqvsinoFTYuVQhMxrL:
     JzGtOIjeyEABNqvsinoFTYuVQhMxrU=JzGtOIjeyEABNqvsinoFTYuVQhMxLb(urllib.parse.parse_qsl(JzGtOIjeyEABNqvsinoFTYuVQhMxra))
     JzGtOIjeyEABNqvsinoFTYuVQhMxrg=JzGtOIjeyEABNqvsinoFTYuVQhMxDa.get('code')
     JzGtOIjeyEABNqvsinoFTYuVQhMxrW=JzGtOIjeyEABNqvsinoFTYuVQhMxrU.get('code')
     if JzGtOIjeyEABNqvsinoFTYuVQhMxba=='vod' and JzGtOIjeyEABNqvsinoFTYuVQhMxDL.get_settings_direct_replay()==JzGtOIjeyEABNqvsinoFTYuVQhMxrC:
      JzGtOIjeyEABNqvsinoFTYuVQhMxrg=JzGtOIjeyEABNqvsinoFTYuVQhMxDa.get('videoid')
      JzGtOIjeyEABNqvsinoFTYuVQhMxrW=JzGtOIjeyEABNqvsinoFTYuVQhMxrU.get('videoid')if JzGtOIjeyEABNqvsinoFTYuVQhMxrW!=JzGtOIjeyEABNqvsinoFTYuVQhMxrc else '-'
     if JzGtOIjeyEABNqvsinoFTYuVQhMxrg!=JzGtOIjeyEABNqvsinoFTYuVQhMxrW:
      fp.write(JzGtOIjeyEABNqvsinoFTYuVQhMxra)
      JzGtOIjeyEABNqvsinoFTYuVQhMxrw+=1
      if JzGtOIjeyEABNqvsinoFTYuVQhMxrw>=50:break
  except:
   JzGtOIjeyEABNqvsinoFTYuVQhMxrc
 def Delete_Watched_List(JzGtOIjeyEABNqvsinoFTYuVQhMxDL,JzGtOIjeyEABNqvsinoFTYuVQhMxba):
  try:
   JzGtOIjeyEABNqvsinoFTYuVQhMxrb=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%JzGtOIjeyEABNqvsinoFTYuVQhMxba))
   with JzGtOIjeyEABNqvsinoFTYuVQhMxLK(JzGtOIjeyEABNqvsinoFTYuVQhMxrb,'w',-1,'utf-8')as fp:
    fp.write('')
  except:
   JzGtOIjeyEABNqvsinoFTYuVQhMxrc
 def dp_WatchList_Delete(JzGtOIjeyEABNqvsinoFTYuVQhMxDL,args):
  JzGtOIjeyEABNqvsinoFTYuVQhMxba=args.get('genre')
  JzGtOIjeyEABNqvsinoFTYuVQhMxDg=xbmcgui.Dialog()
  JzGtOIjeyEABNqvsinoFTYuVQhMxmH=JzGtOIjeyEABNqvsinoFTYuVQhMxDg.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if JzGtOIjeyEABNqvsinoFTYuVQhMxmH==JzGtOIjeyEABNqvsinoFTYuVQhMxrp:sys.exit()
  JzGtOIjeyEABNqvsinoFTYuVQhMxDL.Delete_Watched_List(JzGtOIjeyEABNqvsinoFTYuVQhMxba)
  xbmc.executebuiltin("Container.Refresh")
 def logout(JzGtOIjeyEABNqvsinoFTYuVQhMxDL):
  JzGtOIjeyEABNqvsinoFTYuVQhMxDg=xbmcgui.Dialog()
  JzGtOIjeyEABNqvsinoFTYuVQhMxmH=JzGtOIjeyEABNqvsinoFTYuVQhMxDg.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if JzGtOIjeyEABNqvsinoFTYuVQhMxmH==JzGtOIjeyEABNqvsinoFTYuVQhMxrp:sys.exit()
  JzGtOIjeyEABNqvsinoFTYuVQhMxDL.wininfo_clear()
  if os.path.isfile(JzGtOIjeyEABNqvsinoFTYuVQhMxDr):os.remove(JzGtOIjeyEABNqvsinoFTYuVQhMxDr)
  JzGtOIjeyEABNqvsinoFTYuVQhMxDL.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(JzGtOIjeyEABNqvsinoFTYuVQhMxDL):
  JzGtOIjeyEABNqvsinoFTYuVQhMxmD=xbmcgui.Window(10000)
  JzGtOIjeyEABNqvsinoFTYuVQhMxmD.setProperty('WAVVE_M_CREDENTIAL','')
  JzGtOIjeyEABNqvsinoFTYuVQhMxmD.setProperty('WAVVE_M_LOGINTIME','')
 def cookiefile_save(JzGtOIjeyEABNqvsinoFTYuVQhMxDL):
  JzGtOIjeyEABNqvsinoFTYuVQhMxrH =datetime.datetime.now()
  JzGtOIjeyEABNqvsinoFTYuVQhMxrd=JzGtOIjeyEABNqvsinoFTYuVQhMxrH+datetime.timedelta(days=JzGtOIjeyEABNqvsinoFTYuVQhMxrS(__addon__.getSetting('cache_ttl')))
  JzGtOIjeyEABNqvsinoFTYuVQhMxmD=xbmcgui.Window(10000)
  JzGtOIjeyEABNqvsinoFTYuVQhMxrl={'wavve_token':JzGtOIjeyEABNqvsinoFTYuVQhMxmD.getProperty('WAVVE_M_CREDENTIAL'),'wavve_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'wavve_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'wavve_profile':__addon__.getSetting('selected_profile'),'wavve_limitdate':JzGtOIjeyEABNqvsinoFTYuVQhMxrd.strftime('%Y-%m-%d')}
  try: 
   with JzGtOIjeyEABNqvsinoFTYuVQhMxLK(JzGtOIjeyEABNqvsinoFTYuVQhMxDr,'w',-1,'utf-8')as fp:
    JzGtOIjeyEABNqvsinoFTYuVQhMxrR.dump(JzGtOIjeyEABNqvsinoFTYuVQhMxrl,fp)
  except JzGtOIjeyEABNqvsinoFTYuVQhMxLr as exception:
   JzGtOIjeyEABNqvsinoFTYuVQhMxLX(exception)
 def cookiefile_check(JzGtOIjeyEABNqvsinoFTYuVQhMxDL):
  JzGtOIjeyEABNqvsinoFTYuVQhMxrl={}
  try: 
   with JzGtOIjeyEABNqvsinoFTYuVQhMxLK(JzGtOIjeyEABNqvsinoFTYuVQhMxDr,'r',-1,'utf-8')as fp:
    JzGtOIjeyEABNqvsinoFTYuVQhMxrl= JzGtOIjeyEABNqvsinoFTYuVQhMxrR.load(fp)
  except JzGtOIjeyEABNqvsinoFTYuVQhMxLr as exception:
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.wininfo_clear()
   return JzGtOIjeyEABNqvsinoFTYuVQhMxrp
  JzGtOIjeyEABNqvsinoFTYuVQhMxmU =__addon__.getSetting('id')
  JzGtOIjeyEABNqvsinoFTYuVQhMxmg =__addon__.getSetting('pw')
  JzGtOIjeyEABNqvsinoFTYuVQhMxrf =__addon__.getSetting('selected_profile')
  JzGtOIjeyEABNqvsinoFTYuVQhMxrl['wavve_id']=base64.standard_b64decode(JzGtOIjeyEABNqvsinoFTYuVQhMxrl['wavve_id']).decode('utf-8')
  JzGtOIjeyEABNqvsinoFTYuVQhMxrl['wavve_pw']=base64.standard_b64decode(JzGtOIjeyEABNqvsinoFTYuVQhMxrl['wavve_pw']).decode('utf-8')
  if JzGtOIjeyEABNqvsinoFTYuVQhMxmU!=JzGtOIjeyEABNqvsinoFTYuVQhMxrl['wavve_id']or JzGtOIjeyEABNqvsinoFTYuVQhMxmg!=JzGtOIjeyEABNqvsinoFTYuVQhMxrl['wavve_pw']or JzGtOIjeyEABNqvsinoFTYuVQhMxrf!=JzGtOIjeyEABNqvsinoFTYuVQhMxrl['wavve_profile']:
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.wininfo_clear()
   return JzGtOIjeyEABNqvsinoFTYuVQhMxrp
  JzGtOIjeyEABNqvsinoFTYuVQhMxmd =JzGtOIjeyEABNqvsinoFTYuVQhMxrS(datetime.datetime.now().strftime('%Y%m%d'))
  JzGtOIjeyEABNqvsinoFTYuVQhMxrP=JzGtOIjeyEABNqvsinoFTYuVQhMxrl['wavve_limitdate']
  JzGtOIjeyEABNqvsinoFTYuVQhMxml =JzGtOIjeyEABNqvsinoFTYuVQhMxrS(re.sub('-','',JzGtOIjeyEABNqvsinoFTYuVQhMxrP))
  if JzGtOIjeyEABNqvsinoFTYuVQhMxml<JzGtOIjeyEABNqvsinoFTYuVQhMxmd:
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.wininfo_clear()
   return JzGtOIjeyEABNqvsinoFTYuVQhMxrp
  JzGtOIjeyEABNqvsinoFTYuVQhMxmD=xbmcgui.Window(10000)
  JzGtOIjeyEABNqvsinoFTYuVQhMxmD.setProperty('WAVVE_M_CREDENTIAL',JzGtOIjeyEABNqvsinoFTYuVQhMxrl['wavve_token'])
  JzGtOIjeyEABNqvsinoFTYuVQhMxmD.setProperty('WAVVE_M_LOGINTIME',JzGtOIjeyEABNqvsinoFTYuVQhMxrP)
  return JzGtOIjeyEABNqvsinoFTYuVQhMxrC
 def wavve_main(JzGtOIjeyEABNqvsinoFTYuVQhMxDL):
  JzGtOIjeyEABNqvsinoFTYuVQhMxbX=JzGtOIjeyEABNqvsinoFTYuVQhMxDL.main_params.get('mode',JzGtOIjeyEABNqvsinoFTYuVQhMxrc)
  JzGtOIjeyEABNqvsinoFTYuVQhMxDL.login_main()
  if JzGtOIjeyEABNqvsinoFTYuVQhMxbX is JzGtOIjeyEABNqvsinoFTYuVQhMxrc:
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.dp_Main_List()
  elif JzGtOIjeyEABNqvsinoFTYuVQhMxbX=='GNB_LIST':
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.dp_Gnb_List(JzGtOIjeyEABNqvsinoFTYuVQhMxDL.main_params)
  elif JzGtOIjeyEABNqvsinoFTYuVQhMxbX=='GN_LIST':
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.dp_Deeplink_List(JzGtOIjeyEABNqvsinoFTYuVQhMxDL.main_params)
  elif JzGtOIjeyEABNqvsinoFTYuVQhMxbX=='DEEP_LIST':
   JzGtOIjeyEABNqvsinoFTYuVQhMxmp=JzGtOIjeyEABNqvsinoFTYuVQhMxDL.main_params.get('uicode',JzGtOIjeyEABNqvsinoFTYuVQhMxrc)
   if JzGtOIjeyEABNqvsinoFTYuVQhMxmp in['quick','vod','program','x']:
    JzGtOIjeyEABNqvsinoFTYuVQhMxDL.dp_Episodelink_List(JzGtOIjeyEABNqvsinoFTYuVQhMxDL.main_params)
   else:JzGtOIjeyEABNqvsinoFTYuVQhMxrc
  elif JzGtOIjeyEABNqvsinoFTYuVQhMxbX in['LIVE','VOD','MOVIE']:
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.play_VIDEO(JzGtOIjeyEABNqvsinoFTYuVQhMxDL.main_params)
   time.sleep(0.1)
  elif JzGtOIjeyEABNqvsinoFTYuVQhMxbX=='GN_MYVIEW':
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.dp_Myview_Group(JzGtOIjeyEABNqvsinoFTYuVQhMxDL.main_params)
  elif JzGtOIjeyEABNqvsinoFTYuVQhMxbX=='MYVIEW_LIST':
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.dp_Myview_List(JzGtOIjeyEABNqvsinoFTYuVQhMxDL.main_params)
  elif JzGtOIjeyEABNqvsinoFTYuVQhMxbX=='GENRE':
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.dp_Genre_Group(JzGtOIjeyEABNqvsinoFTYuVQhMxDL.main_params)
  elif JzGtOIjeyEABNqvsinoFTYuVQhMxbX=='GENRE_LIST':
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.dp_Genre_List(JzGtOIjeyEABNqvsinoFTYuVQhMxDL.main_params)
  elif JzGtOIjeyEABNqvsinoFTYuVQhMxbX=='WATCH':
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.dp_Watch_List(JzGtOIjeyEABNqvsinoFTYuVQhMxDL.main_params)
  elif JzGtOIjeyEABNqvsinoFTYuVQhMxbX=='MYVIEW_REMOVE':
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.dp_WatchList_Delete(JzGtOIjeyEABNqvsinoFTYuVQhMxDL.main_params)
  elif JzGtOIjeyEABNqvsinoFTYuVQhMxbX=='SEARCH':
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.dp_Search_Group(JzGtOIjeyEABNqvsinoFTYuVQhMxDL.main_params)
  elif JzGtOIjeyEABNqvsinoFTYuVQhMxbX=='SEARCH_LIST':
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.dp_Search_List(JzGtOIjeyEABNqvsinoFTYuVQhMxDL.main_params)
  elif JzGtOIjeyEABNqvsinoFTYuVQhMxbX=='ORDER_BY':
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.dp_setEpOrderby(JzGtOIjeyEABNqvsinoFTYuVQhMxDL.main_params)
  elif JzGtOIjeyEABNqvsinoFTYuVQhMxbX=='LOGOUT':
   JzGtOIjeyEABNqvsinoFTYuVQhMxDL.logout()
  else:
   JzGtOIjeyEABNqvsinoFTYuVQhMxrc
# Created by pyminifier (https://github.com/liftoff/pyminifier)
