__author__="NightRain"
pohaugdxKbjkXeJyvNfGnBtrRUSQTw=object
pohaugdxKbjkXeJyvNfGnBtrRUSQTP=None
pohaugdxKbjkXeJyvNfGnBtrRUSQTF=False
pohaugdxKbjkXeJyvNfGnBtrRUSQTV=int
pohaugdxKbjkXeJyvNfGnBtrRUSQTi=True
pohaugdxKbjkXeJyvNfGnBtrRUSQmL=len
pohaugdxKbjkXeJyvNfGnBtrRUSQmM=str
pohaugdxKbjkXeJyvNfGnBtrRUSQmA=dict
pohaugdxKbjkXeJyvNfGnBtrRUSQmI=open
pohaugdxKbjkXeJyvNfGnBtrRUSQmT=Exception
pohaugdxKbjkXeJyvNfGnBtrRUSQms=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
pohaugdxKbjkXeJyvNfGnBtrRUSQLA=[{'title':'홈','uicode':'GN1','came':'home'},{'title':'LIVE 채널','uicode':'GN3','came':'live'},{'title':'VOD 방송','uicode':'GN2','came':'broadcast'},{'title':'영화(Movie)','uicode':'GN17','came':'movie'},{'title':'해외시리즈','uicode':'GN12','came':'global'},{'title':'분류별 - 방송(VOD) - 인기순','uicode':'GENRE','came':'vodgenre','orderby':'viewtime','ordernm':'인기순'},{'title':'분류별 - 방송(VOD) - 최신순','uicode':'GENRE','came':'vodgenre','orderby':'new','ordernm':'최신순'},{'title':'분류별 - 영화(Movie) - 인기순','uicode':'GENRE','came':'moviegenre_svod','orderby':'paid','ordernm':'인기순'},{'title':'분류별 - 영화(Movie) - 업데이트순','uicode':'GENRE','came':'moviegenre_svod','orderby':'displaystart','ordernm':'업데이트순'},{'title':'검색','uicode':'SEARCH','came':'-'},{'title':'Watched(시청목록)','uicode':'WATCH','came':'-'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmc.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
pohaugdxKbjkXeJyvNfGnBtrRUSQLI='Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'
pohaugdxKbjkXeJyvNfGnBtrRUSQLT=xbmc.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
from wavveCore import*
class pohaugdxKbjkXeJyvNfGnBtrRUSQLM(pohaugdxKbjkXeJyvNfGnBtrRUSQTw):
 def __init__(pohaugdxKbjkXeJyvNfGnBtrRUSQLm,pohaugdxKbjkXeJyvNfGnBtrRUSQLs,pohaugdxKbjkXeJyvNfGnBtrRUSQLD,pohaugdxKbjkXeJyvNfGnBtrRUSQLY):
  pohaugdxKbjkXeJyvNfGnBtrRUSQLm._addon_url =pohaugdxKbjkXeJyvNfGnBtrRUSQLs
  pohaugdxKbjkXeJyvNfGnBtrRUSQLm._addon_handle=pohaugdxKbjkXeJyvNfGnBtrRUSQLD
  pohaugdxKbjkXeJyvNfGnBtrRUSQLm.main_params =pohaugdxKbjkXeJyvNfGnBtrRUSQLY
  pohaugdxKbjkXeJyvNfGnBtrRUSQLm.WavveObj =bGcRpVuNUhOvxzlIrWPwdkjBsYHtCD() 
 def addon_noti(pohaugdxKbjkXeJyvNfGnBtrRUSQLm,sting):
  try:
   pohaugdxKbjkXeJyvNfGnBtrRUSQLW=xbmcgui.Dialog()
   pohaugdxKbjkXeJyvNfGnBtrRUSQLW.notification(__addonname__,sting)
  except:
   pohaugdxKbjkXeJyvNfGnBtrRUSQTP
 def addon_log(pohaugdxKbjkXeJyvNfGnBtrRUSQLm,string,isDebug=pohaugdxKbjkXeJyvNfGnBtrRUSQTF):
  try:
   pohaugdxKbjkXeJyvNfGnBtrRUSQLz=string.encode('utf-8','ignore')
  except:
   pohaugdxKbjkXeJyvNfGnBtrRUSQLz='addonException: addon_log'
  if isDebug:pohaugdxKbjkXeJyvNfGnBtrRUSQLl=xbmc.LOGDEBUG
  else:pohaugdxKbjkXeJyvNfGnBtrRUSQLl=xbmc.LOGNOTICE
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,pohaugdxKbjkXeJyvNfGnBtrRUSQLz),level=pohaugdxKbjkXeJyvNfGnBtrRUSQLl)
 def get_keyboard_input(pohaugdxKbjkXeJyvNfGnBtrRUSQLm,pohaugdxKbjkXeJyvNfGnBtrRUSQMI):
  pohaugdxKbjkXeJyvNfGnBtrRUSQLE=pohaugdxKbjkXeJyvNfGnBtrRUSQTP
  kb=xbmc.Keyboard()
  kb.setHeading(pohaugdxKbjkXeJyvNfGnBtrRUSQMI)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   pohaugdxKbjkXeJyvNfGnBtrRUSQLE=kb.getText()
  return pohaugdxKbjkXeJyvNfGnBtrRUSQLE
 def get_settings_login_info(pohaugdxKbjkXeJyvNfGnBtrRUSQLm):
  pohaugdxKbjkXeJyvNfGnBtrRUSQLq =__addon__.getSetting('id')
  pohaugdxKbjkXeJyvNfGnBtrRUSQLH =__addon__.getSetting('pw')
  pohaugdxKbjkXeJyvNfGnBtrRUSQLC=__addon__.getSetting('selected_profile')
  return(pohaugdxKbjkXeJyvNfGnBtrRUSQLq,pohaugdxKbjkXeJyvNfGnBtrRUSQLH,pohaugdxKbjkXeJyvNfGnBtrRUSQLC)
 def get_selQuality(pohaugdxKbjkXeJyvNfGnBtrRUSQLm):
  try:
   pohaugdxKbjkXeJyvNfGnBtrRUSQLc=[1080,720,480,360]
   pohaugdxKbjkXeJyvNfGnBtrRUSQLw=pohaugdxKbjkXeJyvNfGnBtrRUSQTV(__addon__.getSetting('selected_quality'))
   return pohaugdxKbjkXeJyvNfGnBtrRUSQLc[pohaugdxKbjkXeJyvNfGnBtrRUSQLw]
  except:
   pohaugdxKbjkXeJyvNfGnBtrRUSQTP
  return 1080 
 def get_settings_exclusion21(pohaugdxKbjkXeJyvNfGnBtrRUSQLm):
  pohaugdxKbjkXeJyvNfGnBtrRUSQLP =__addon__.getSetting('exclusion21')
  if pohaugdxKbjkXeJyvNfGnBtrRUSQLP=='false':
   return pohaugdxKbjkXeJyvNfGnBtrRUSQTF
  else:
   return pohaugdxKbjkXeJyvNfGnBtrRUSQTi
 def get_settings_direct_replay(pohaugdxKbjkXeJyvNfGnBtrRUSQLm):
  pohaugdxKbjkXeJyvNfGnBtrRUSQLF=pohaugdxKbjkXeJyvNfGnBtrRUSQTV(__addon__.getSetting('direct_replay'))
  if pohaugdxKbjkXeJyvNfGnBtrRUSQLF==0:
   return pohaugdxKbjkXeJyvNfGnBtrRUSQTF
  else:
   return pohaugdxKbjkXeJyvNfGnBtrRUSQTi
 def get_settings_addinfo(pohaugdxKbjkXeJyvNfGnBtrRUSQLm):
  pohaugdxKbjkXeJyvNfGnBtrRUSQLV =__addon__.getSetting('add_infoyn')
  if pohaugdxKbjkXeJyvNfGnBtrRUSQLV=='false':
   return pohaugdxKbjkXeJyvNfGnBtrRUSQTF
  else:
   return pohaugdxKbjkXeJyvNfGnBtrRUSQTi
 def get_settings_thumbnail_landyn(pohaugdxKbjkXeJyvNfGnBtrRUSQLm):
  pohaugdxKbjkXeJyvNfGnBtrRUSQLi =pohaugdxKbjkXeJyvNfGnBtrRUSQTV(__addon__.getSetting('thumbnail_way'))
  if pohaugdxKbjkXeJyvNfGnBtrRUSQLi==0:
   return pohaugdxKbjkXeJyvNfGnBtrRUSQTi
  else:
   return pohaugdxKbjkXeJyvNfGnBtrRUSQTF
 def set_winCredential(pohaugdxKbjkXeJyvNfGnBtrRUSQLm,credential):
  pohaugdxKbjkXeJyvNfGnBtrRUSQML=xbmcgui.Window(10000)
  pohaugdxKbjkXeJyvNfGnBtrRUSQML.setProperty('WAVVE_M_CREDENTIAL',credential)
  pohaugdxKbjkXeJyvNfGnBtrRUSQML.setProperty('WAVVE_M_LOGINTIME',pohaugdxKbjkXeJyvNfGnBtrRUSQLm.WavveObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(pohaugdxKbjkXeJyvNfGnBtrRUSQLm):
  pohaugdxKbjkXeJyvNfGnBtrRUSQML=xbmcgui.Window(10000)
  return pohaugdxKbjkXeJyvNfGnBtrRUSQML.getProperty('WAVVE_M_CREDENTIAL')
 def set_winEpisodeOrderby(pohaugdxKbjkXeJyvNfGnBtrRUSQLm,pohaugdxKbjkXeJyvNfGnBtrRUSQMC):
  pohaugdxKbjkXeJyvNfGnBtrRUSQML=xbmcgui.Window(10000)
  pohaugdxKbjkXeJyvNfGnBtrRUSQML.setProperty('WAVVE_M_ORDERBY',pohaugdxKbjkXeJyvNfGnBtrRUSQMC)
 def get_winEpisodeOrderby(pohaugdxKbjkXeJyvNfGnBtrRUSQLm):
  pohaugdxKbjkXeJyvNfGnBtrRUSQML=xbmcgui.Window(10000)
  return pohaugdxKbjkXeJyvNfGnBtrRUSQML.getProperty('WAVVE_M_ORDERBY')
 def add_dir(pohaugdxKbjkXeJyvNfGnBtrRUSQLm,label,sublabel='',img='',infoLabels=pohaugdxKbjkXeJyvNfGnBtrRUSQTP,isFolder=pohaugdxKbjkXeJyvNfGnBtrRUSQTi,params=''):
  pohaugdxKbjkXeJyvNfGnBtrRUSQMA='%s?%s'%(pohaugdxKbjkXeJyvNfGnBtrRUSQLm._addon_url,urllib.parse.urlencode(params))
  if sublabel:pohaugdxKbjkXeJyvNfGnBtrRUSQMI='%s < %s >'%(label,sublabel)
  else: pohaugdxKbjkXeJyvNfGnBtrRUSQMI=label
  if not img:img='DefaultFolder.png'
  pohaugdxKbjkXeJyvNfGnBtrRUSQMT=xbmcgui.ListItem(pohaugdxKbjkXeJyvNfGnBtrRUSQMI)
  pohaugdxKbjkXeJyvNfGnBtrRUSQMT.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:pohaugdxKbjkXeJyvNfGnBtrRUSQMT.setInfo(type="video",infoLabels=infoLabels)
  if not isFolder:pohaugdxKbjkXeJyvNfGnBtrRUSQMT.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(pohaugdxKbjkXeJyvNfGnBtrRUSQLm._addon_handle,pohaugdxKbjkXeJyvNfGnBtrRUSQMA,pohaugdxKbjkXeJyvNfGnBtrRUSQMT,isFolder)
 def dp_Main_List(pohaugdxKbjkXeJyvNfGnBtrRUSQLm):
  for pohaugdxKbjkXeJyvNfGnBtrRUSQMm in pohaugdxKbjkXeJyvNfGnBtrRUSQLA:
   pohaugdxKbjkXeJyvNfGnBtrRUSQMI=pohaugdxKbjkXeJyvNfGnBtrRUSQMm.get('title')
   if pohaugdxKbjkXeJyvNfGnBtrRUSQMm.get('uicode')=='GENRE':
    pohaugdxKbjkXeJyvNfGnBtrRUSQMs={'mode':'GENRE','uicode':pohaugdxKbjkXeJyvNfGnBtrRUSQMm.get('came'),'genre':'-','subgenre':'-','orderby':pohaugdxKbjkXeJyvNfGnBtrRUSQMm.get('orderby'),'ordernm':pohaugdxKbjkXeJyvNfGnBtrRUSQMm.get('ordernm')}
   elif pohaugdxKbjkXeJyvNfGnBtrRUSQMm.get('uicode')=='WATCH':
    pohaugdxKbjkXeJyvNfGnBtrRUSQMs={'mode':'WATCH','genre':'-'}
   elif pohaugdxKbjkXeJyvNfGnBtrRUSQMm.get('uicode')=='SEARCH':
    pohaugdxKbjkXeJyvNfGnBtrRUSQMs={'mode':'SEARCH','genre':'-'}
   else:
    pohaugdxKbjkXeJyvNfGnBtrRUSQMs={'mode':'GNB_LIST','uicode':pohaugdxKbjkXeJyvNfGnBtrRUSQMm.get('uicode'),'came':pohaugdxKbjkXeJyvNfGnBtrRUSQMm.get('came')}
   pohaugdxKbjkXeJyvNfGnBtrRUSQMD=pohaugdxKbjkXeJyvNfGnBtrRUSQTi
   if pohaugdxKbjkXeJyvNfGnBtrRUSQMm.get('uicode')=='XXX':
    pohaugdxKbjkXeJyvNfGnBtrRUSQMs['mode']='XXX'
    pohaugdxKbjkXeJyvNfGnBtrRUSQMD=pohaugdxKbjkXeJyvNfGnBtrRUSQTF
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.add_dir(pohaugdxKbjkXeJyvNfGnBtrRUSQMI,sublabel='',img='',infoLabels=pohaugdxKbjkXeJyvNfGnBtrRUSQTP,isFolder=pohaugdxKbjkXeJyvNfGnBtrRUSQMD,params=pohaugdxKbjkXeJyvNfGnBtrRUSQMs)
  if pohaugdxKbjkXeJyvNfGnBtrRUSQmL(pohaugdxKbjkXeJyvNfGnBtrRUSQLA)>0:xbmcplugin.endOfDirectory(pohaugdxKbjkXeJyvNfGnBtrRUSQLm._addon_handle)
 def login_main(pohaugdxKbjkXeJyvNfGnBtrRUSQLm):
  (pohaugdxKbjkXeJyvNfGnBtrRUSQMO,pohaugdxKbjkXeJyvNfGnBtrRUSQMW,pohaugdxKbjkXeJyvNfGnBtrRUSQMz)=pohaugdxKbjkXeJyvNfGnBtrRUSQLm.get_settings_login_info()
  if not(pohaugdxKbjkXeJyvNfGnBtrRUSQMO and pohaugdxKbjkXeJyvNfGnBtrRUSQMW):
   pohaugdxKbjkXeJyvNfGnBtrRUSQLW=xbmcgui.Dialog()
   pohaugdxKbjkXeJyvNfGnBtrRUSQMl=pohaugdxKbjkXeJyvNfGnBtrRUSQLW.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if pohaugdxKbjkXeJyvNfGnBtrRUSQMl==pohaugdxKbjkXeJyvNfGnBtrRUSQTi:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if pohaugdxKbjkXeJyvNfGnBtrRUSQLm.get_winEpisodeOrderby()=='':
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.set_winEpisodeOrderby('desc')
  if pohaugdxKbjkXeJyvNfGnBtrRUSQLm.cookiefile_check():return
  pohaugdxKbjkXeJyvNfGnBtrRUSQME =pohaugdxKbjkXeJyvNfGnBtrRUSQTV(pohaugdxKbjkXeJyvNfGnBtrRUSQLm.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  pohaugdxKbjkXeJyvNfGnBtrRUSQMq=xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINTIME')
  if pohaugdxKbjkXeJyvNfGnBtrRUSQMq==pohaugdxKbjkXeJyvNfGnBtrRUSQTP or pohaugdxKbjkXeJyvNfGnBtrRUSQMq=='':pohaugdxKbjkXeJyvNfGnBtrRUSQMq=pohaugdxKbjkXeJyvNfGnBtrRUSQTV('19000101')
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   pohaugdxKbjkXeJyvNfGnBtrRUSQMH=0
   while pohaugdxKbjkXeJyvNfGnBtrRUSQTi:
    pohaugdxKbjkXeJyvNfGnBtrRUSQMH+=1
    time.sleep(0.05)
    if pohaugdxKbjkXeJyvNfGnBtrRUSQMq>=pohaugdxKbjkXeJyvNfGnBtrRUSQME:return
    if pohaugdxKbjkXeJyvNfGnBtrRUSQMH>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  if pohaugdxKbjkXeJyvNfGnBtrRUSQMq>=pohaugdxKbjkXeJyvNfGnBtrRUSQME:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   return
  if not pohaugdxKbjkXeJyvNfGnBtrRUSQLm.WavveObj.GetCredential(pohaugdxKbjkXeJyvNfGnBtrRUSQMO,pohaugdxKbjkXeJyvNfGnBtrRUSQMW,pohaugdxKbjkXeJyvNfGnBtrRUSQMz):
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   sys.exit()
  pohaugdxKbjkXeJyvNfGnBtrRUSQLm.set_winCredential(pohaugdxKbjkXeJyvNfGnBtrRUSQLm.WavveObj.LoadCredential())
  pohaugdxKbjkXeJyvNfGnBtrRUSQLm.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
 def dp_setEpOrderby(pohaugdxKbjkXeJyvNfGnBtrRUSQLm,args):
  pohaugdxKbjkXeJyvNfGnBtrRUSQMC =args.get('orderby')
  pohaugdxKbjkXeJyvNfGnBtrRUSQLm.set_winEpisodeOrderby(pohaugdxKbjkXeJyvNfGnBtrRUSQMC)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Gnb_List(pohaugdxKbjkXeJyvNfGnBtrRUSQLm,args):
  pohaugdxKbjkXeJyvNfGnBtrRUSQLm.WavveObj.SaveCredential(pohaugdxKbjkXeJyvNfGnBtrRUSQLm.get_winCredential())
  pohaugdxKbjkXeJyvNfGnBtrRUSQMc=pohaugdxKbjkXeJyvNfGnBtrRUSQLm.WavveObj.GetGnList(args.get('uicode'))
  for pohaugdxKbjkXeJyvNfGnBtrRUSQMw in pohaugdxKbjkXeJyvNfGnBtrRUSQMc:
   pohaugdxKbjkXeJyvNfGnBtrRUSQMI=pohaugdxKbjkXeJyvNfGnBtrRUSQMw.get('title')
   pohaugdxKbjkXeJyvNfGnBtrRUSQMs={'mode':'GN_LIST' if pohaugdxKbjkXeJyvNfGnBtrRUSQMw.get('uicode')!='CY1' else 'GN_MYVIEW','uicode':pohaugdxKbjkXeJyvNfGnBtrRUSQMw.get('uicode'),'came':args.get('came'),'page':'1'}
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.add_dir(pohaugdxKbjkXeJyvNfGnBtrRUSQMI,sublabel='',img='',infoLabels=pohaugdxKbjkXeJyvNfGnBtrRUSQTP,isFolder=pohaugdxKbjkXeJyvNfGnBtrRUSQTi,params=pohaugdxKbjkXeJyvNfGnBtrRUSQMs)
  if pohaugdxKbjkXeJyvNfGnBtrRUSQmL(pohaugdxKbjkXeJyvNfGnBtrRUSQMc)>0:xbmcplugin.endOfDirectory(pohaugdxKbjkXeJyvNfGnBtrRUSQLm._addon_handle,cacheToDisc=pohaugdxKbjkXeJyvNfGnBtrRUSQTF)
 def dp_Myview_Group(pohaugdxKbjkXeJyvNfGnBtrRUSQLm,args):
  pohaugdxKbjkXeJyvNfGnBtrRUSQMI='VOD 시청내역'
  pohaugdxKbjkXeJyvNfGnBtrRUSQMs={'mode':'MYVIEW_LIST','uicode':'vod','page':'1'}
  pohaugdxKbjkXeJyvNfGnBtrRUSQLm.add_dir(pohaugdxKbjkXeJyvNfGnBtrRUSQMI,sublabel='',img='',infoLabels=pohaugdxKbjkXeJyvNfGnBtrRUSQTP,isFolder=pohaugdxKbjkXeJyvNfGnBtrRUSQTi,params=pohaugdxKbjkXeJyvNfGnBtrRUSQMs)
  pohaugdxKbjkXeJyvNfGnBtrRUSQMI='영화 시청내역'
  pohaugdxKbjkXeJyvNfGnBtrRUSQMs['uicode']='movie'
  pohaugdxKbjkXeJyvNfGnBtrRUSQLm.add_dir(pohaugdxKbjkXeJyvNfGnBtrRUSQMI,sublabel='',img='',infoLabels=pohaugdxKbjkXeJyvNfGnBtrRUSQTP,isFolder=pohaugdxKbjkXeJyvNfGnBtrRUSQTi,params=pohaugdxKbjkXeJyvNfGnBtrRUSQMs)
  xbmcplugin.endOfDirectory(pohaugdxKbjkXeJyvNfGnBtrRUSQLm._addon_handle)
 def dp_Myview_List(pohaugdxKbjkXeJyvNfGnBtrRUSQLm,args):
  pohaugdxKbjkXeJyvNfGnBtrRUSQLm.WavveObj.SaveCredential(pohaugdxKbjkXeJyvNfGnBtrRUSQLm.get_winCredential())
  pohaugdxKbjkXeJyvNfGnBtrRUSQMP =pohaugdxKbjkXeJyvNfGnBtrRUSQLm.get_settings_addinfo()
  pohaugdxKbjkXeJyvNfGnBtrRUSQMF=args.get('uicode')
  pohaugdxKbjkXeJyvNfGnBtrRUSQMV =pohaugdxKbjkXeJyvNfGnBtrRUSQTV(args.get('page'))
  pohaugdxKbjkXeJyvNfGnBtrRUSQMi,pohaugdxKbjkXeJyvNfGnBtrRUSQAL=pohaugdxKbjkXeJyvNfGnBtrRUSQLm.WavveObj.GetMyviewList(pohaugdxKbjkXeJyvNfGnBtrRUSQMF,pohaugdxKbjkXeJyvNfGnBtrRUSQMV,addinfoyn=pohaugdxKbjkXeJyvNfGnBtrRUSQMP)
  for pohaugdxKbjkXeJyvNfGnBtrRUSQAM in pohaugdxKbjkXeJyvNfGnBtrRUSQMi:
   pohaugdxKbjkXeJyvNfGnBtrRUSQMI =pohaugdxKbjkXeJyvNfGnBtrRUSQAM.get('title')
   pohaugdxKbjkXeJyvNfGnBtrRUSQAI =pohaugdxKbjkXeJyvNfGnBtrRUSQAM.get('subtitle')
   pohaugdxKbjkXeJyvNfGnBtrRUSQAT=pohaugdxKbjkXeJyvNfGnBtrRUSQAM.get('thumbnail')
   pohaugdxKbjkXeJyvNfGnBtrRUSQAm=pohaugdxKbjkXeJyvNfGnBtrRUSQAM.get('info')
   if pohaugdxKbjkXeJyvNfGnBtrRUSQMF=='movie' and pohaugdxKbjkXeJyvNfGnBtrRUSQMP==pohaugdxKbjkXeJyvNfGnBtrRUSQTi:
    pohaugdxKbjkXeJyvNfGnBtrRUSQMI='%s (%s)'%(pohaugdxKbjkXeJyvNfGnBtrRUSQMI,pohaugdxKbjkXeJyvNfGnBtrRUSQmM(pohaugdxKbjkXeJyvNfGnBtrRUSQAm.get('year')))
   else:
    pohaugdxKbjkXeJyvNfGnBtrRUSQAm['plot']=pohaugdxKbjkXeJyvNfGnBtrRUSQMI
   if pohaugdxKbjkXeJyvNfGnBtrRUSQMF=='vod':
    pohaugdxKbjkXeJyvNfGnBtrRUSQMs={'mode':'DEEP_LIST','contentid':pohaugdxKbjkXeJyvNfGnBtrRUSQAM.get('programid'),'contentidType':'programid','uicode':'vod','page':'1','title':pohaugdxKbjkXeJyvNfGnBtrRUSQMI,'subtitle':pohaugdxKbjkXeJyvNfGnBtrRUSQAI,'thumbnail':pohaugdxKbjkXeJyvNfGnBtrRUSQAT,'viewage':pohaugdxKbjkXeJyvNfGnBtrRUSQAM.get('viewage')}
    pohaugdxKbjkXeJyvNfGnBtrRUSQMD=pohaugdxKbjkXeJyvNfGnBtrRUSQTi
   else:
    pohaugdxKbjkXeJyvNfGnBtrRUSQMs={'mode':'MOVIE','contentid':pohaugdxKbjkXeJyvNfGnBtrRUSQAM.get('contentid'),'contentidType':'contentid','uicode':'movie','page':'1','title':pohaugdxKbjkXeJyvNfGnBtrRUSQMI,'subtitle':pohaugdxKbjkXeJyvNfGnBtrRUSQAI,'thumbnail':pohaugdxKbjkXeJyvNfGnBtrRUSQAT,'viewage':pohaugdxKbjkXeJyvNfGnBtrRUSQAM.get('viewage')}
    pohaugdxKbjkXeJyvNfGnBtrRUSQMD=pohaugdxKbjkXeJyvNfGnBtrRUSQTF
   if pohaugdxKbjkXeJyvNfGnBtrRUSQAM.get('viewage')=='21':pohaugdxKbjkXeJyvNfGnBtrRUSQAI+=' (%s)'%(pohaugdxKbjkXeJyvNfGnBtrRUSQAM.get('viewage'))
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.add_dir(pohaugdxKbjkXeJyvNfGnBtrRUSQMI,sublabel=pohaugdxKbjkXeJyvNfGnBtrRUSQAI,img=pohaugdxKbjkXeJyvNfGnBtrRUSQAT,infoLabels=pohaugdxKbjkXeJyvNfGnBtrRUSQAm,isFolder=pohaugdxKbjkXeJyvNfGnBtrRUSQMD,params=pohaugdxKbjkXeJyvNfGnBtrRUSQMs)
  if pohaugdxKbjkXeJyvNfGnBtrRUSQAL:
   pohaugdxKbjkXeJyvNfGnBtrRUSQMs['mode'] ='MYVIEW_LIST' 
   pohaugdxKbjkXeJyvNfGnBtrRUSQMs['uicode']=pohaugdxKbjkXeJyvNfGnBtrRUSQMF 
   pohaugdxKbjkXeJyvNfGnBtrRUSQMs['page'] =pohaugdxKbjkXeJyvNfGnBtrRUSQmM(pohaugdxKbjkXeJyvNfGnBtrRUSQMV+1)
   pohaugdxKbjkXeJyvNfGnBtrRUSQMI='[B]%s >>[/B]'%'다음 페이지'
   pohaugdxKbjkXeJyvNfGnBtrRUSQAI=pohaugdxKbjkXeJyvNfGnBtrRUSQmM(pohaugdxKbjkXeJyvNfGnBtrRUSQMV+1)
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.add_dir(pohaugdxKbjkXeJyvNfGnBtrRUSQMI,sublabel=pohaugdxKbjkXeJyvNfGnBtrRUSQAI,img='',infoLabels=pohaugdxKbjkXeJyvNfGnBtrRUSQTP,isFolder=pohaugdxKbjkXeJyvNfGnBtrRUSQTi,params=pohaugdxKbjkXeJyvNfGnBtrRUSQMs)
  if pohaugdxKbjkXeJyvNfGnBtrRUSQmL(pohaugdxKbjkXeJyvNfGnBtrRUSQMi)>0:xbmcplugin.endOfDirectory(pohaugdxKbjkXeJyvNfGnBtrRUSQLm._addon_handle,cacheToDisc=pohaugdxKbjkXeJyvNfGnBtrRUSQTF)
 def dp_Genre_Group(pohaugdxKbjkXeJyvNfGnBtrRUSQLm,args):
  pohaugdxKbjkXeJyvNfGnBtrRUSQLm.WavveObj.SaveCredential(pohaugdxKbjkXeJyvNfGnBtrRUSQLm.get_winCredential())
  pohaugdxKbjkXeJyvNfGnBtrRUSQAs =args.get('mode') 
  pohaugdxKbjkXeJyvNfGnBtrRUSQAD =args.get('uicode')
  pohaugdxKbjkXeJyvNfGnBtrRUSQAY =args.get('genre') 
  pohaugdxKbjkXeJyvNfGnBtrRUSQAO=args.get('subgenre')
  pohaugdxKbjkXeJyvNfGnBtrRUSQMC =args.get('orderby')
  pohaugdxKbjkXeJyvNfGnBtrRUSQAW =args.get('ordernm')
  if pohaugdxKbjkXeJyvNfGnBtrRUSQAY=='-':
   pohaugdxKbjkXeJyvNfGnBtrRUSQAz=pohaugdxKbjkXeJyvNfGnBtrRUSQLm.WavveObj.GetGenreGroup(pohaugdxKbjkXeJyvNfGnBtrRUSQAD,pohaugdxKbjkXeJyvNfGnBtrRUSQAY,pohaugdxKbjkXeJyvNfGnBtrRUSQMC,pohaugdxKbjkXeJyvNfGnBtrRUSQAW,exclusion21=pohaugdxKbjkXeJyvNfGnBtrRUSQLm.get_settings_exclusion21())
  else:
   pohaugdxKbjkXeJyvNfGnBtrRUSQAl={'adult':args.get('adult'),'broadcastid':args.get('broadcastid'),'contenttype':args.get('contenttype'),'genre':args.get('genre'),'uiparent':args.get('uiparent'),'uirank':args.get('uirank'),'uitype':args.get('uitype'),'orderby':pohaugdxKbjkXeJyvNfGnBtrRUSQMC,'ordernm':pohaugdxKbjkXeJyvNfGnBtrRUSQAW}
   pohaugdxKbjkXeJyvNfGnBtrRUSQAz=pohaugdxKbjkXeJyvNfGnBtrRUSQLm.WavveObj.GetGenreGroup_sub(pohaugdxKbjkXeJyvNfGnBtrRUSQAl)
  for pohaugdxKbjkXeJyvNfGnBtrRUSQAE in pohaugdxKbjkXeJyvNfGnBtrRUSQAz:
   pohaugdxKbjkXeJyvNfGnBtrRUSQMI =pohaugdxKbjkXeJyvNfGnBtrRUSQAE.get('title')+'  ('+pohaugdxKbjkXeJyvNfGnBtrRUSQAW+')'
   pohaugdxKbjkXeJyvNfGnBtrRUSQMs={'mode':pohaugdxKbjkXeJyvNfGnBtrRUSQAs,'uicode':pohaugdxKbjkXeJyvNfGnBtrRUSQAD,'genre':pohaugdxKbjkXeJyvNfGnBtrRUSQAE.get('genre'),'subgenre':pohaugdxKbjkXeJyvNfGnBtrRUSQAE.get('subgenre'),'adult':pohaugdxKbjkXeJyvNfGnBtrRUSQAE.get('adult'),'page':'1','broadcastid':pohaugdxKbjkXeJyvNfGnBtrRUSQAE.get('broadcastid'),'contenttype':pohaugdxKbjkXeJyvNfGnBtrRUSQAE.get('contenttype'),'uiparent':pohaugdxKbjkXeJyvNfGnBtrRUSQAE.get('uiparent'),'uirank':pohaugdxKbjkXeJyvNfGnBtrRUSQAE.get('uirank'),'uitype':pohaugdxKbjkXeJyvNfGnBtrRUSQAE.get('uitype'),'orderby':pohaugdxKbjkXeJyvNfGnBtrRUSQMC,'ordernm':pohaugdxKbjkXeJyvNfGnBtrRUSQAW}
   if pohaugdxKbjkXeJyvNfGnBtrRUSQAD=='moviegenre' or pohaugdxKbjkXeJyvNfGnBtrRUSQAD=='moviegenre_svod' or pohaugdxKbjkXeJyvNfGnBtrRUSQAD=='moviegenre_ppv' or pohaugdxKbjkXeJyvNfGnBtrRUSQAE.get('subgenre')!='-':
    pohaugdxKbjkXeJyvNfGnBtrRUSQMs['mode'] ='GENRE_LIST'
   else:
    pohaugdxKbjkXeJyvNfGnBtrRUSQTP
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.add_dir(pohaugdxKbjkXeJyvNfGnBtrRUSQMI,sublabel='',img='',infoLabels=pohaugdxKbjkXeJyvNfGnBtrRUSQTP,isFolder=pohaugdxKbjkXeJyvNfGnBtrRUSQTi,params=pohaugdxKbjkXeJyvNfGnBtrRUSQMs)
  if pohaugdxKbjkXeJyvNfGnBtrRUSQmL(pohaugdxKbjkXeJyvNfGnBtrRUSQAz)>0:xbmcplugin.endOfDirectory(pohaugdxKbjkXeJyvNfGnBtrRUSQLm._addon_handle,cacheToDisc=pohaugdxKbjkXeJyvNfGnBtrRUSQTF)
 def dp_Genre_List(pohaugdxKbjkXeJyvNfGnBtrRUSQLm,args):
  pohaugdxKbjkXeJyvNfGnBtrRUSQLm.WavveObj.SaveCredential(pohaugdxKbjkXeJyvNfGnBtrRUSQLm.get_winCredential())
  pohaugdxKbjkXeJyvNfGnBtrRUSQMP=pohaugdxKbjkXeJyvNfGnBtrRUSQLm.get_settings_addinfo()
  pohaugdxKbjkXeJyvNfGnBtrRUSQAD =args.get('uicode')
  pohaugdxKbjkXeJyvNfGnBtrRUSQMV=pohaugdxKbjkXeJyvNfGnBtrRUSQTV(args.get('page'))
  pohaugdxKbjkXeJyvNfGnBtrRUSQMs={'adult':args.get('adult'),'broadcastid':args.get('broadcastid'),'contenttype':args.get('contenttype'),'genre':args.get('genre'),'subgenre':args.get('subgenre'),'uiparent':args.get('uiparent'),'uirank':args.get('uirank'),'uitype':args.get('uitype'),'orderby':args.get('orderby')}
  if args.get('genre')==args.get('subgenre'):
   pohaugdxKbjkXeJyvNfGnBtrRUSQMs['subgenre']='all'
  pohaugdxKbjkXeJyvNfGnBtrRUSQAz,pohaugdxKbjkXeJyvNfGnBtrRUSQAL=pohaugdxKbjkXeJyvNfGnBtrRUSQLm.WavveObj.GetGenreList(pohaugdxKbjkXeJyvNfGnBtrRUSQAD,pohaugdxKbjkXeJyvNfGnBtrRUSQMs,pohaugdxKbjkXeJyvNfGnBtrRUSQMV,addinfoyn=pohaugdxKbjkXeJyvNfGnBtrRUSQMP)
  for pohaugdxKbjkXeJyvNfGnBtrRUSQAE in pohaugdxKbjkXeJyvNfGnBtrRUSQAz:
   pohaugdxKbjkXeJyvNfGnBtrRUSQMI =pohaugdxKbjkXeJyvNfGnBtrRUSQAE.get('title')
   pohaugdxKbjkXeJyvNfGnBtrRUSQAT=pohaugdxKbjkXeJyvNfGnBtrRUSQAE.get('thumbnail')
   pohaugdxKbjkXeJyvNfGnBtrRUSQAm=pohaugdxKbjkXeJyvNfGnBtrRUSQAE.get('info')
   if pohaugdxKbjkXeJyvNfGnBtrRUSQAD=='moviegenre_svod' and pohaugdxKbjkXeJyvNfGnBtrRUSQMP==pohaugdxKbjkXeJyvNfGnBtrRUSQTi:
    pohaugdxKbjkXeJyvNfGnBtrRUSQMI='%s (%s)'%(pohaugdxKbjkXeJyvNfGnBtrRUSQMI,pohaugdxKbjkXeJyvNfGnBtrRUSQmM(pohaugdxKbjkXeJyvNfGnBtrRUSQAm.get('year')))
   else:
    pohaugdxKbjkXeJyvNfGnBtrRUSQAm['plot']=pohaugdxKbjkXeJyvNfGnBtrRUSQMI
   if pohaugdxKbjkXeJyvNfGnBtrRUSQAD=='vodgenre':
    pohaugdxKbjkXeJyvNfGnBtrRUSQAq={'mode':'DEEP_LIST','contentid':pohaugdxKbjkXeJyvNfGnBtrRUSQAE.get('uicode'),'contentidType':'contentid','uicode':'vod','page':'1','title':pohaugdxKbjkXeJyvNfGnBtrRUSQMI,'subtitle':'','thumbnail':pohaugdxKbjkXeJyvNfGnBtrRUSQAT,'viewage':pohaugdxKbjkXeJyvNfGnBtrRUSQAE.get('viewage')}
    pohaugdxKbjkXeJyvNfGnBtrRUSQMD=pohaugdxKbjkXeJyvNfGnBtrRUSQTi
   else:
    pohaugdxKbjkXeJyvNfGnBtrRUSQAq={'mode':'MOVIE','contentid':pohaugdxKbjkXeJyvNfGnBtrRUSQAE.get('uicode'),'contentidType':'contentid','uicode':'movie','page':'1','title':pohaugdxKbjkXeJyvNfGnBtrRUSQMI,'subtitle':'','thumbnail':pohaugdxKbjkXeJyvNfGnBtrRUSQAT,'viewage':pohaugdxKbjkXeJyvNfGnBtrRUSQAE.get('viewage')}
    pohaugdxKbjkXeJyvNfGnBtrRUSQMD=pohaugdxKbjkXeJyvNfGnBtrRUSQTF
   if pohaugdxKbjkXeJyvNfGnBtrRUSQAq.get('viewage')=='21':pohaugdxKbjkXeJyvNfGnBtrRUSQMI+=' (%s)'%(pohaugdxKbjkXeJyvNfGnBtrRUSQAq.get('viewage'))
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.add_dir(pohaugdxKbjkXeJyvNfGnBtrRUSQMI,sublabel='',img=pohaugdxKbjkXeJyvNfGnBtrRUSQAT,infoLabels=pohaugdxKbjkXeJyvNfGnBtrRUSQAm,isFolder=pohaugdxKbjkXeJyvNfGnBtrRUSQMD,params=pohaugdxKbjkXeJyvNfGnBtrRUSQAq)
  if pohaugdxKbjkXeJyvNfGnBtrRUSQAL:
   pohaugdxKbjkXeJyvNfGnBtrRUSQMs['mode'] ='GENRE_LIST' 
   pohaugdxKbjkXeJyvNfGnBtrRUSQMs['uicode']=pohaugdxKbjkXeJyvNfGnBtrRUSQAD 
   pohaugdxKbjkXeJyvNfGnBtrRUSQMs['page'] =pohaugdxKbjkXeJyvNfGnBtrRUSQmM(pohaugdxKbjkXeJyvNfGnBtrRUSQMV+1)
   pohaugdxKbjkXeJyvNfGnBtrRUSQMI='[B]%s >>[/B]'%'다음 페이지'
   pohaugdxKbjkXeJyvNfGnBtrRUSQAI=pohaugdxKbjkXeJyvNfGnBtrRUSQmM(pohaugdxKbjkXeJyvNfGnBtrRUSQMV+1)
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.add_dir(pohaugdxKbjkXeJyvNfGnBtrRUSQMI,sublabel=pohaugdxKbjkXeJyvNfGnBtrRUSQAI,img='',infoLabels=pohaugdxKbjkXeJyvNfGnBtrRUSQTP,isFolder=pohaugdxKbjkXeJyvNfGnBtrRUSQTi,params=pohaugdxKbjkXeJyvNfGnBtrRUSQMs)
  if pohaugdxKbjkXeJyvNfGnBtrRUSQmL(pohaugdxKbjkXeJyvNfGnBtrRUSQAz)>0:xbmcplugin.endOfDirectory(pohaugdxKbjkXeJyvNfGnBtrRUSQLm._addon_handle,cacheToDisc=pohaugdxKbjkXeJyvNfGnBtrRUSQTF)
 def dp_Deeplink_List(pohaugdxKbjkXeJyvNfGnBtrRUSQLm,args):
  pohaugdxKbjkXeJyvNfGnBtrRUSQLm.WavveObj.SaveCredential(pohaugdxKbjkXeJyvNfGnBtrRUSQLm.get_winCredential())
  pohaugdxKbjkXeJyvNfGnBtrRUSQMP=pohaugdxKbjkXeJyvNfGnBtrRUSQLm.get_settings_addinfo()
  pohaugdxKbjkXeJyvNfGnBtrRUSQAD =args.get('uicode')
  pohaugdxKbjkXeJyvNfGnBtrRUSQAH =args.get('came')
  pohaugdxKbjkXeJyvNfGnBtrRUSQMV=pohaugdxKbjkXeJyvNfGnBtrRUSQTV(args.get('page'))
  pohaugdxKbjkXeJyvNfGnBtrRUSQAC,pohaugdxKbjkXeJyvNfGnBtrRUSQAL=pohaugdxKbjkXeJyvNfGnBtrRUSQLm.WavveObj.GetDeeplinkList(pohaugdxKbjkXeJyvNfGnBtrRUSQAD,pohaugdxKbjkXeJyvNfGnBtrRUSQAH,pohaugdxKbjkXeJyvNfGnBtrRUSQMV,addinfoyn=pohaugdxKbjkXeJyvNfGnBtrRUSQMP)
  for pohaugdxKbjkXeJyvNfGnBtrRUSQAc in pohaugdxKbjkXeJyvNfGnBtrRUSQAC:
   pohaugdxKbjkXeJyvNfGnBtrRUSQMI =pohaugdxKbjkXeJyvNfGnBtrRUSQAc.get('title')
   pohaugdxKbjkXeJyvNfGnBtrRUSQAI =pohaugdxKbjkXeJyvNfGnBtrRUSQAc.get('subtitle')
   pohaugdxKbjkXeJyvNfGnBtrRUSQAT=pohaugdxKbjkXeJyvNfGnBtrRUSQAc.get('thumbnail')
   pohaugdxKbjkXeJyvNfGnBtrRUSQAw=pohaugdxKbjkXeJyvNfGnBtrRUSQAc.get('uicode')
   pohaugdxKbjkXeJyvNfGnBtrRUSQAP=pohaugdxKbjkXeJyvNfGnBtrRUSQAc.get('channelepg')
   pohaugdxKbjkXeJyvNfGnBtrRUSQMs={'uicode':pohaugdxKbjkXeJyvNfGnBtrRUSQAw,'came':pohaugdxKbjkXeJyvNfGnBtrRUSQAH,'contentid':pohaugdxKbjkXeJyvNfGnBtrRUSQAc.get('contentid'),'contentidType':pohaugdxKbjkXeJyvNfGnBtrRUSQAc.get('contentidType'),'page':'1','title':pohaugdxKbjkXeJyvNfGnBtrRUSQMI,'subtitle':pohaugdxKbjkXeJyvNfGnBtrRUSQAI,'thumbnail':pohaugdxKbjkXeJyvNfGnBtrRUSQAT,'viewage':pohaugdxKbjkXeJyvNfGnBtrRUSQAc.get('viewage')}
   if pohaugdxKbjkXeJyvNfGnBtrRUSQAw=='channel':
    pohaugdxKbjkXeJyvNfGnBtrRUSQMs['mode'] ='LIVE'
   elif pohaugdxKbjkXeJyvNfGnBtrRUSQAw=='movie':
    pohaugdxKbjkXeJyvNfGnBtrRUSQMs['mode'] ='MOVIE'
   else:
    pohaugdxKbjkXeJyvNfGnBtrRUSQMs['mode'] ='DEEP_LIST'
   pohaugdxKbjkXeJyvNfGnBtrRUSQAm=pohaugdxKbjkXeJyvNfGnBtrRUSQAc.get('info')
   if pohaugdxKbjkXeJyvNfGnBtrRUSQAP:
    pohaugdxKbjkXeJyvNfGnBtrRUSQAm['plot']='%s\n\n%s'%(pohaugdxKbjkXeJyvNfGnBtrRUSQMI,pohaugdxKbjkXeJyvNfGnBtrRUSQAP)
   elif pohaugdxKbjkXeJyvNfGnBtrRUSQAw=='movie' and pohaugdxKbjkXeJyvNfGnBtrRUSQMP==pohaugdxKbjkXeJyvNfGnBtrRUSQTi:
    pohaugdxKbjkXeJyvNfGnBtrRUSQMI='%s (%s)'%(pohaugdxKbjkXeJyvNfGnBtrRUSQMI,pohaugdxKbjkXeJyvNfGnBtrRUSQmM(pohaugdxKbjkXeJyvNfGnBtrRUSQAm.get('year')))
   else:
    pohaugdxKbjkXeJyvNfGnBtrRUSQAm['plot']='%s\n\n%s'%(pohaugdxKbjkXeJyvNfGnBtrRUSQMI,pohaugdxKbjkXeJyvNfGnBtrRUSQAI)
   if pohaugdxKbjkXeJyvNfGnBtrRUSQAc.get('viewage')=='21':pohaugdxKbjkXeJyvNfGnBtrRUSQAI+=' (%s)'%(pohaugdxKbjkXeJyvNfGnBtrRUSQAc.get('viewage'))
   if pohaugdxKbjkXeJyvNfGnBtrRUSQAw in['channel','movie']:
    pohaugdxKbjkXeJyvNfGnBtrRUSQMD=pohaugdxKbjkXeJyvNfGnBtrRUSQTF
   elif pohaugdxKbjkXeJyvNfGnBtrRUSQMs['contentidType']=='direct':
    pohaugdxKbjkXeJyvNfGnBtrRUSQMD=pohaugdxKbjkXeJyvNfGnBtrRUSQTF
    pohaugdxKbjkXeJyvNfGnBtrRUSQMs['mode']='VOD'
   else:
    pohaugdxKbjkXeJyvNfGnBtrRUSQMD=pohaugdxKbjkXeJyvNfGnBtrRUSQTi
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.add_dir(pohaugdxKbjkXeJyvNfGnBtrRUSQMI,sublabel=pohaugdxKbjkXeJyvNfGnBtrRUSQAI,img=pohaugdxKbjkXeJyvNfGnBtrRUSQAT,infoLabels=pohaugdxKbjkXeJyvNfGnBtrRUSQAm,isFolder=pohaugdxKbjkXeJyvNfGnBtrRUSQMD,params=pohaugdxKbjkXeJyvNfGnBtrRUSQMs)
  if pohaugdxKbjkXeJyvNfGnBtrRUSQAL:
   pohaugdxKbjkXeJyvNfGnBtrRUSQMs['mode'] ='GN_LIST' 
   pohaugdxKbjkXeJyvNfGnBtrRUSQMs['uicode']=pohaugdxKbjkXeJyvNfGnBtrRUSQAD 
   pohaugdxKbjkXeJyvNfGnBtrRUSQMs['page'] =pohaugdxKbjkXeJyvNfGnBtrRUSQmM(pohaugdxKbjkXeJyvNfGnBtrRUSQMV+1)
   pohaugdxKbjkXeJyvNfGnBtrRUSQMI='[B]%s >>[/B]'%'다음 페이지'
   pohaugdxKbjkXeJyvNfGnBtrRUSQAI=pohaugdxKbjkXeJyvNfGnBtrRUSQmM(pohaugdxKbjkXeJyvNfGnBtrRUSQMV+1)
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.add_dir(pohaugdxKbjkXeJyvNfGnBtrRUSQMI,sublabel=pohaugdxKbjkXeJyvNfGnBtrRUSQAI,img='',infoLabels=pohaugdxKbjkXeJyvNfGnBtrRUSQTP,isFolder=pohaugdxKbjkXeJyvNfGnBtrRUSQTi,params=pohaugdxKbjkXeJyvNfGnBtrRUSQMs)
  if pohaugdxKbjkXeJyvNfGnBtrRUSQmL(pohaugdxKbjkXeJyvNfGnBtrRUSQAC)>0:xbmcplugin.endOfDirectory(pohaugdxKbjkXeJyvNfGnBtrRUSQLm._addon_handle,cacheToDisc=pohaugdxKbjkXeJyvNfGnBtrRUSQTF)
 def dp_Episodelink_List(pohaugdxKbjkXeJyvNfGnBtrRUSQLm,args):
  pohaugdxKbjkXeJyvNfGnBtrRUSQLm.WavveObj.SaveCredential(pohaugdxKbjkXeJyvNfGnBtrRUSQLm.get_winCredential())
  pohaugdxKbjkXeJyvNfGnBtrRUSQAF =args.get('contentid')
  pohaugdxKbjkXeJyvNfGnBtrRUSQAV=args.get('contentidType')
  pohaugdxKbjkXeJyvNfGnBtrRUSQMF =args.get('uicode')
  pohaugdxKbjkXeJyvNfGnBtrRUSQMV =pohaugdxKbjkXeJyvNfGnBtrRUSQTV(args.get('page'))
  pohaugdxKbjkXeJyvNfGnBtrRUSQAi,pohaugdxKbjkXeJyvNfGnBtrRUSQAL=pohaugdxKbjkXeJyvNfGnBtrRUSQLm.WavveObj.GetEpisodeList(pohaugdxKbjkXeJyvNfGnBtrRUSQAF,pohaugdxKbjkXeJyvNfGnBtrRUSQMF,pohaugdxKbjkXeJyvNfGnBtrRUSQAV,pohaugdxKbjkXeJyvNfGnBtrRUSQMV,orderby=pohaugdxKbjkXeJyvNfGnBtrRUSQLm.get_winEpisodeOrderby())
  for pohaugdxKbjkXeJyvNfGnBtrRUSQIL in pohaugdxKbjkXeJyvNfGnBtrRUSQAi:
   pohaugdxKbjkXeJyvNfGnBtrRUSQMI =pohaugdxKbjkXeJyvNfGnBtrRUSQIL.get('title')
   pohaugdxKbjkXeJyvNfGnBtrRUSQAI =pohaugdxKbjkXeJyvNfGnBtrRUSQIL.get('subtitle')
   pohaugdxKbjkXeJyvNfGnBtrRUSQAT=pohaugdxKbjkXeJyvNfGnBtrRUSQIL.get('thumbnail')
   pohaugdxKbjkXeJyvNfGnBtrRUSQMs={'mode':'VOD','uicode':pohaugdxKbjkXeJyvNfGnBtrRUSQIL.get('uicode'),'contentid':pohaugdxKbjkXeJyvNfGnBtrRUSQIL.get('contentid'),'programid':pohaugdxKbjkXeJyvNfGnBtrRUSQIL.get('programid'),'title':pohaugdxKbjkXeJyvNfGnBtrRUSQMI,'subtitle':pohaugdxKbjkXeJyvNfGnBtrRUSQAI,'thumbnail':pohaugdxKbjkXeJyvNfGnBtrRUSQAT,'viewage':pohaugdxKbjkXeJyvNfGnBtrRUSQIL.get('viewage')}
   if pohaugdxKbjkXeJyvNfGnBtrRUSQIL.get('viewage')=='21':pohaugdxKbjkXeJyvNfGnBtrRUSQAI+=' (%s)'%(pohaugdxKbjkXeJyvNfGnBtrRUSQIL.get('viewage'))
   pohaugdxKbjkXeJyvNfGnBtrRUSQIM=pohaugdxKbjkXeJyvNfGnBtrRUSQIL.get('info')
   pohaugdxKbjkXeJyvNfGnBtrRUSQIM['plot']=pohaugdxKbjkXeJyvNfGnBtrRUSQIL.get('synopsis')
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.add_dir(pohaugdxKbjkXeJyvNfGnBtrRUSQMI,sublabel=pohaugdxKbjkXeJyvNfGnBtrRUSQAI,img=pohaugdxKbjkXeJyvNfGnBtrRUSQAT,infoLabels=pohaugdxKbjkXeJyvNfGnBtrRUSQIM,isFolder=pohaugdxKbjkXeJyvNfGnBtrRUSQTF,params=pohaugdxKbjkXeJyvNfGnBtrRUSQMs)
  if pohaugdxKbjkXeJyvNfGnBtrRUSQMV==1:
   pohaugdxKbjkXeJyvNfGnBtrRUSQAm={'plot':'정렬순서를 변경합니다.'}
   pohaugdxKbjkXeJyvNfGnBtrRUSQMs={}
   pohaugdxKbjkXeJyvNfGnBtrRUSQMs['mode'] ='ORDER_BY' 
   if pohaugdxKbjkXeJyvNfGnBtrRUSQLm.get_winEpisodeOrderby()=='desc':
    pohaugdxKbjkXeJyvNfGnBtrRUSQMI='정렬순서변경 : 최신화부터 -> 1회부터'
    pohaugdxKbjkXeJyvNfGnBtrRUSQMs['orderby']='asc'
   else:
    pohaugdxKbjkXeJyvNfGnBtrRUSQMI='정렬순서변경 : 1회부터 -> 최신화부터'
    pohaugdxKbjkXeJyvNfGnBtrRUSQMs['orderby']='desc'
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.add_dir(pohaugdxKbjkXeJyvNfGnBtrRUSQMI,sublabel='',img='',infoLabels=pohaugdxKbjkXeJyvNfGnBtrRUSQAm,isFolder=pohaugdxKbjkXeJyvNfGnBtrRUSQTF,params=pohaugdxKbjkXeJyvNfGnBtrRUSQMs)
  if pohaugdxKbjkXeJyvNfGnBtrRUSQAL:
   pohaugdxKbjkXeJyvNfGnBtrRUSQMs['mode'] ='DEEP_LIST' 
   pohaugdxKbjkXeJyvNfGnBtrRUSQMs['uicode'] =pohaugdxKbjkXeJyvNfGnBtrRUSQMF 
   pohaugdxKbjkXeJyvNfGnBtrRUSQMs['contentid'] =pohaugdxKbjkXeJyvNfGnBtrRUSQAF 
   pohaugdxKbjkXeJyvNfGnBtrRUSQMs['contentidType']=pohaugdxKbjkXeJyvNfGnBtrRUSQAV 
   pohaugdxKbjkXeJyvNfGnBtrRUSQMs['page'] =pohaugdxKbjkXeJyvNfGnBtrRUSQmM(pohaugdxKbjkXeJyvNfGnBtrRUSQMV+1)
   pohaugdxKbjkXeJyvNfGnBtrRUSQMI='[B]%s >>[/B]'%'다음 페이지'
   pohaugdxKbjkXeJyvNfGnBtrRUSQAI=pohaugdxKbjkXeJyvNfGnBtrRUSQmM(pohaugdxKbjkXeJyvNfGnBtrRUSQMV+1)
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.add_dir(pohaugdxKbjkXeJyvNfGnBtrRUSQMI,sublabel=pohaugdxKbjkXeJyvNfGnBtrRUSQAI,img='',infoLabels=pohaugdxKbjkXeJyvNfGnBtrRUSQTP,isFolder=pohaugdxKbjkXeJyvNfGnBtrRUSQTi,params=pohaugdxKbjkXeJyvNfGnBtrRUSQMs)
  if pohaugdxKbjkXeJyvNfGnBtrRUSQmL(pohaugdxKbjkXeJyvNfGnBtrRUSQAi)>0:xbmcplugin.endOfDirectory(pohaugdxKbjkXeJyvNfGnBtrRUSQLm._addon_handle,cacheToDisc=pohaugdxKbjkXeJyvNfGnBtrRUSQTi)
 def play_VIDEO(pohaugdxKbjkXeJyvNfGnBtrRUSQLm,args):
  pohaugdxKbjkXeJyvNfGnBtrRUSQLm.WavveObj.SaveCredential(pohaugdxKbjkXeJyvNfGnBtrRUSQLm.get_winCredential())
  pohaugdxKbjkXeJyvNfGnBtrRUSQAF =args.get('contentid')
  pohaugdxKbjkXeJyvNfGnBtrRUSQMF=args.get('uicode')
  pohaugdxKbjkXeJyvNfGnBtrRUSQIA=pohaugdxKbjkXeJyvNfGnBtrRUSQLm.get_selQuality()
  pohaugdxKbjkXeJyvNfGnBtrRUSQLm.addon_log(pohaugdxKbjkXeJyvNfGnBtrRUSQAF+' - '+pohaugdxKbjkXeJyvNfGnBtrRUSQMF,pohaugdxKbjkXeJyvNfGnBtrRUSQTF)
  pohaugdxKbjkXeJyvNfGnBtrRUSQIT,pohaugdxKbjkXeJyvNfGnBtrRUSQIm,pohaugdxKbjkXeJyvNfGnBtrRUSQIs,pohaugdxKbjkXeJyvNfGnBtrRUSQID=pohaugdxKbjkXeJyvNfGnBtrRUSQLm.WavveObj.GetStreamingURL(pohaugdxKbjkXeJyvNfGnBtrRUSQAF,pohaugdxKbjkXeJyvNfGnBtrRUSQMF,pohaugdxKbjkXeJyvNfGnBtrRUSQIA)
  pohaugdxKbjkXeJyvNfGnBtrRUSQIY='%s|Cookie=%s'%(pohaugdxKbjkXeJyvNfGnBtrRUSQIT,pohaugdxKbjkXeJyvNfGnBtrRUSQIm)
  pohaugdxKbjkXeJyvNfGnBtrRUSQLm.addon_log(pohaugdxKbjkXeJyvNfGnBtrRUSQIY,pohaugdxKbjkXeJyvNfGnBtrRUSQTF)
  if pohaugdxKbjkXeJyvNfGnBtrRUSQIT=='':
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.addon_noti(__language__(30907).encode('utf8'))
   return
  pohaugdxKbjkXeJyvNfGnBtrRUSQIO=xbmcgui.ListItem(path=pohaugdxKbjkXeJyvNfGnBtrRUSQIY)
  if pohaugdxKbjkXeJyvNfGnBtrRUSQIs:
   pohaugdxKbjkXeJyvNfGnBtrRUSQIW=pohaugdxKbjkXeJyvNfGnBtrRUSQIs['customdata']
   pohaugdxKbjkXeJyvNfGnBtrRUSQIz =pohaugdxKbjkXeJyvNfGnBtrRUSQIs['drmhost']
   pohaugdxKbjkXeJyvNfGnBtrRUSQIl =inputstreamhelper.Helper('mpd',drm='widevine')
   if pohaugdxKbjkXeJyvNfGnBtrRUSQIl.check_inputstream():
    if pohaugdxKbjkXeJyvNfGnBtrRUSQMF=='movie':
     pohaugdxKbjkXeJyvNfGnBtrRUSQIE='https://www.wavve.com/player/movie?movieid=%s'%pohaugdxKbjkXeJyvNfGnBtrRUSQAF
    else:
     pohaugdxKbjkXeJyvNfGnBtrRUSQIE='https://www.wavve.com/player/vod?programid=%s&page=1'%pohaugdxKbjkXeJyvNfGnBtrRUSQAF
    pohaugdxKbjkXeJyvNfGnBtrRUSQIq={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':pohaugdxKbjkXeJyvNfGnBtrRUSQIW,'referer':pohaugdxKbjkXeJyvNfGnBtrRUSQIE,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':pohaugdxKbjkXeJyvNfGnBtrRUSQLI}
    pohaugdxKbjkXeJyvNfGnBtrRUSQIH=pohaugdxKbjkXeJyvNfGnBtrRUSQIz+'|'+urllib.parse.urlencode(pohaugdxKbjkXeJyvNfGnBtrRUSQIq)+'|R{SSM}|'
    pohaugdxKbjkXeJyvNfGnBtrRUSQIO.setProperty('inputstream',pohaugdxKbjkXeJyvNfGnBtrRUSQIl.inputstream_addon)
    pohaugdxKbjkXeJyvNfGnBtrRUSQIO.setProperty('inputstream.adaptive.manifest_type','mpd')
    pohaugdxKbjkXeJyvNfGnBtrRUSQIO.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    pohaugdxKbjkXeJyvNfGnBtrRUSQIO.setProperty('inputstream.adaptive.license_key',pohaugdxKbjkXeJyvNfGnBtrRUSQIH)
    pohaugdxKbjkXeJyvNfGnBtrRUSQIO.setProperty('inputstream.adaptive.stream_headers','user-agent=%s&Cookie=%s'%(pohaugdxKbjkXeJyvNfGnBtrRUSQLI,pohaugdxKbjkXeJyvNfGnBtrRUSQIm))
  xbmcplugin.setResolvedUrl(pohaugdxKbjkXeJyvNfGnBtrRUSQLm._addon_handle,pohaugdxKbjkXeJyvNfGnBtrRUSQTi,pohaugdxKbjkXeJyvNfGnBtrRUSQIO)
  if pohaugdxKbjkXeJyvNfGnBtrRUSQID:
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.addon_noti(pohaugdxKbjkXeJyvNfGnBtrRUSQID.encode('utf-8'))
  else:
   if '/preview.' in urllib.parse.urlsplit(pohaugdxKbjkXeJyvNfGnBtrRUSQIT).path:pohaugdxKbjkXeJyvNfGnBtrRUSQLm.addon_noti(__language__(30908).encode('utf8'))
  try:
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('viewage')!='21':
    pohaugdxKbjkXeJyvNfGnBtrRUSQMs={'code':args.get('programid')if args.get('mode')=='VOD' else args.get('contentid'),'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    pohaugdxKbjkXeJyvNfGnBtrRUSQLm.Save_Watched_List(args.get('mode').lower(),pohaugdxKbjkXeJyvNfGnBtrRUSQMs)
  except:
   pohaugdxKbjkXeJyvNfGnBtrRUSQTP
 def dp_Watch_List(pohaugdxKbjkXeJyvNfGnBtrRUSQLm,args):
  pohaugdxKbjkXeJyvNfGnBtrRUSQAY =args.get('genre')
  pohaugdxKbjkXeJyvNfGnBtrRUSQLF=pohaugdxKbjkXeJyvNfGnBtrRUSQLm.get_settings_direct_replay()
  if pohaugdxKbjkXeJyvNfGnBtrRUSQAY=='-':
   pohaugdxKbjkXeJyvNfGnBtrRUSQMI='VOD 시청내역'
   pohaugdxKbjkXeJyvNfGnBtrRUSQMs={'mode':'WATCH','genre':'vod'}
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.add_dir(pohaugdxKbjkXeJyvNfGnBtrRUSQMI,sublabel='',img='',infoLabels=pohaugdxKbjkXeJyvNfGnBtrRUSQTP,isFolder=pohaugdxKbjkXeJyvNfGnBtrRUSQTi,params=pohaugdxKbjkXeJyvNfGnBtrRUSQMs)
   pohaugdxKbjkXeJyvNfGnBtrRUSQMI='영화 시청내역'
   pohaugdxKbjkXeJyvNfGnBtrRUSQMs['genre']='movie'
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.add_dir(pohaugdxKbjkXeJyvNfGnBtrRUSQMI,sublabel='',img='',infoLabels=pohaugdxKbjkXeJyvNfGnBtrRUSQTP,isFolder=pohaugdxKbjkXeJyvNfGnBtrRUSQTi,params=pohaugdxKbjkXeJyvNfGnBtrRUSQMs)
   xbmcplugin.endOfDirectory(pohaugdxKbjkXeJyvNfGnBtrRUSQLm._addon_handle)
  else:
   pohaugdxKbjkXeJyvNfGnBtrRUSQIC=pohaugdxKbjkXeJyvNfGnBtrRUSQLm.Load_Watched_List(pohaugdxKbjkXeJyvNfGnBtrRUSQAY)
   for pohaugdxKbjkXeJyvNfGnBtrRUSQIc in pohaugdxKbjkXeJyvNfGnBtrRUSQIC:
    pohaugdxKbjkXeJyvNfGnBtrRUSQIw=pohaugdxKbjkXeJyvNfGnBtrRUSQmA(urllib.parse.parse_qsl(pohaugdxKbjkXeJyvNfGnBtrRUSQIc))
    pohaugdxKbjkXeJyvNfGnBtrRUSQMI =pohaugdxKbjkXeJyvNfGnBtrRUSQIw.get('title').strip()
    pohaugdxKbjkXeJyvNfGnBtrRUSQAI =pohaugdxKbjkXeJyvNfGnBtrRUSQIw.get('subtitle').strip()
    if pohaugdxKbjkXeJyvNfGnBtrRUSQAI=='None':pohaugdxKbjkXeJyvNfGnBtrRUSQAI=''
    pohaugdxKbjkXeJyvNfGnBtrRUSQAT=pohaugdxKbjkXeJyvNfGnBtrRUSQIw.get('img')
    pohaugdxKbjkXeJyvNfGnBtrRUSQIP =pohaugdxKbjkXeJyvNfGnBtrRUSQIw.get('videoid')
    pohaugdxKbjkXeJyvNfGnBtrRUSQAm={}
    if pohaugdxKbjkXeJyvNfGnBtrRUSQAY=='movie' and pohaugdxKbjkXeJyvNfGnBtrRUSQLm.get_settings_addinfo()==pohaugdxKbjkXeJyvNfGnBtrRUSQTi:
     pohaugdxKbjkXeJyvNfGnBtrRUSQIF=pohaugdxKbjkXeJyvNfGnBtrRUSQLm.WavveObj.GetMovieInfoList([pohaugdxKbjkXeJyvNfGnBtrRUSQIw.get('code')])
     pohaugdxKbjkXeJyvNfGnBtrRUSQAm=pohaugdxKbjkXeJyvNfGnBtrRUSQIF.get(pohaugdxKbjkXeJyvNfGnBtrRUSQIw.get('code'))
    else:
     pohaugdxKbjkXeJyvNfGnBtrRUSQAm['plot']='%s\n%s'%(pohaugdxKbjkXeJyvNfGnBtrRUSQMI,pohaugdxKbjkXeJyvNfGnBtrRUSQAI)
    if pohaugdxKbjkXeJyvNfGnBtrRUSQAY=='vod':
     if pohaugdxKbjkXeJyvNfGnBtrRUSQLF==pohaugdxKbjkXeJyvNfGnBtrRUSQTF or pohaugdxKbjkXeJyvNfGnBtrRUSQIP==pohaugdxKbjkXeJyvNfGnBtrRUSQTP:
      pohaugdxKbjkXeJyvNfGnBtrRUSQMs={'mode':'DEEP_LIST','contentid':pohaugdxKbjkXeJyvNfGnBtrRUSQIw.get('code'),'contentidType':'programid','uicode':'vod','page':'1'}
      pohaugdxKbjkXeJyvNfGnBtrRUSQMD=pohaugdxKbjkXeJyvNfGnBtrRUSQTi
     else:
      pohaugdxKbjkXeJyvNfGnBtrRUSQMs={'mode':'VOD','contentid':pohaugdxKbjkXeJyvNfGnBtrRUSQIP,'contentidType':'contentid','programid':pohaugdxKbjkXeJyvNfGnBtrRUSQIw.get('code'),'uicode':'vod','title':pohaugdxKbjkXeJyvNfGnBtrRUSQMI,'subtitle':pohaugdxKbjkXeJyvNfGnBtrRUSQAI,'thumbnail':pohaugdxKbjkXeJyvNfGnBtrRUSQAT}
      pohaugdxKbjkXeJyvNfGnBtrRUSQMD=pohaugdxKbjkXeJyvNfGnBtrRUSQTF
    else:
     pohaugdxKbjkXeJyvNfGnBtrRUSQMs={'mode':'MOVIE','contentid':pohaugdxKbjkXeJyvNfGnBtrRUSQIw.get('code'),'contentidType':'contentid','uicode':'movie','title':pohaugdxKbjkXeJyvNfGnBtrRUSQMI,'thumbnail':pohaugdxKbjkXeJyvNfGnBtrRUSQAT}
     pohaugdxKbjkXeJyvNfGnBtrRUSQMD=pohaugdxKbjkXeJyvNfGnBtrRUSQTF
    pohaugdxKbjkXeJyvNfGnBtrRUSQLm.add_dir(pohaugdxKbjkXeJyvNfGnBtrRUSQMI,sublabel=pohaugdxKbjkXeJyvNfGnBtrRUSQAI,img=pohaugdxKbjkXeJyvNfGnBtrRUSQAT,infoLabels=pohaugdxKbjkXeJyvNfGnBtrRUSQAm,isFolder=pohaugdxKbjkXeJyvNfGnBtrRUSQMD,params=pohaugdxKbjkXeJyvNfGnBtrRUSQMs)
   pohaugdxKbjkXeJyvNfGnBtrRUSQAm={'plot':'시청목록을 삭제합니다.'}
   pohaugdxKbjkXeJyvNfGnBtrRUSQMI='*** 시청목록 삭제 ***'
   pohaugdxKbjkXeJyvNfGnBtrRUSQMs={'mode':'MYVIEW_REMOVE','genre':pohaugdxKbjkXeJyvNfGnBtrRUSQAY}
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.add_dir(pohaugdxKbjkXeJyvNfGnBtrRUSQMI,sublabel='',img='',infoLabels=pohaugdxKbjkXeJyvNfGnBtrRUSQAm,isFolder=pohaugdxKbjkXeJyvNfGnBtrRUSQTF,params=pohaugdxKbjkXeJyvNfGnBtrRUSQMs)
   xbmcplugin.endOfDirectory(pohaugdxKbjkXeJyvNfGnBtrRUSQLm._addon_handle,cacheToDisc=pohaugdxKbjkXeJyvNfGnBtrRUSQTF)
 def dp_Search_Group(pohaugdxKbjkXeJyvNfGnBtrRUSQLm,args):
  pohaugdxKbjkXeJyvNfGnBtrRUSQMI='VOD 검색'
  pohaugdxKbjkXeJyvNfGnBtrRUSQMs={'mode':'SEARCH_LIST','genre':'vod','page':'1'}
  pohaugdxKbjkXeJyvNfGnBtrRUSQLm.add_dir(pohaugdxKbjkXeJyvNfGnBtrRUSQMI,sublabel='',img='',infoLabels=pohaugdxKbjkXeJyvNfGnBtrRUSQTP,isFolder=pohaugdxKbjkXeJyvNfGnBtrRUSQTi,params=pohaugdxKbjkXeJyvNfGnBtrRUSQMs)
  pohaugdxKbjkXeJyvNfGnBtrRUSQMI='영화 검색'
  pohaugdxKbjkXeJyvNfGnBtrRUSQMs['genre']='movie'
  pohaugdxKbjkXeJyvNfGnBtrRUSQLm.add_dir(pohaugdxKbjkXeJyvNfGnBtrRUSQMI,sublabel='',img='',infoLabels=pohaugdxKbjkXeJyvNfGnBtrRUSQTP,isFolder=pohaugdxKbjkXeJyvNfGnBtrRUSQTi,params=pohaugdxKbjkXeJyvNfGnBtrRUSQMs)
  xbmcplugin.endOfDirectory(pohaugdxKbjkXeJyvNfGnBtrRUSQLm._addon_handle)
 def dp_Search_List(pohaugdxKbjkXeJyvNfGnBtrRUSQLm,args):
  pohaugdxKbjkXeJyvNfGnBtrRUSQLm.WavveObj.SaveCredential(pohaugdxKbjkXeJyvNfGnBtrRUSQLm.get_winCredential())
  pohaugdxKbjkXeJyvNfGnBtrRUSQMP=pohaugdxKbjkXeJyvNfGnBtrRUSQLm.get_settings_addinfo()
  pohaugdxKbjkXeJyvNfGnBtrRUSQMF=args.get('genre')
  pohaugdxKbjkXeJyvNfGnBtrRUSQMV =pohaugdxKbjkXeJyvNfGnBtrRUSQTV(args.get('page'))
  if 'search_key' in args:
   pohaugdxKbjkXeJyvNfGnBtrRUSQIi=args.get('search_key')
  else:
   pohaugdxKbjkXeJyvNfGnBtrRUSQIi=pohaugdxKbjkXeJyvNfGnBtrRUSQLm.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not pohaugdxKbjkXeJyvNfGnBtrRUSQIi:return
  pohaugdxKbjkXeJyvNfGnBtrRUSQTL,pohaugdxKbjkXeJyvNfGnBtrRUSQAL=pohaugdxKbjkXeJyvNfGnBtrRUSQLm.WavveObj.GetSearchList(pohaugdxKbjkXeJyvNfGnBtrRUSQIi,pohaugdxKbjkXeJyvNfGnBtrRUSQMF,pohaugdxKbjkXeJyvNfGnBtrRUSQMV,exclusion21=pohaugdxKbjkXeJyvNfGnBtrRUSQLm.get_settings_exclusion21(),addinfoyn=pohaugdxKbjkXeJyvNfGnBtrRUSQMP)
  for pohaugdxKbjkXeJyvNfGnBtrRUSQTM in pohaugdxKbjkXeJyvNfGnBtrRUSQTL:
   pohaugdxKbjkXeJyvNfGnBtrRUSQMI =pohaugdxKbjkXeJyvNfGnBtrRUSQTM.get('title')
   pohaugdxKbjkXeJyvNfGnBtrRUSQAT=pohaugdxKbjkXeJyvNfGnBtrRUSQTM.get('thumbnail')
   pohaugdxKbjkXeJyvNfGnBtrRUSQAm=pohaugdxKbjkXeJyvNfGnBtrRUSQTM.get('info')
   if pohaugdxKbjkXeJyvNfGnBtrRUSQMF=='movie' and pohaugdxKbjkXeJyvNfGnBtrRUSQMP==pohaugdxKbjkXeJyvNfGnBtrRUSQTi:
    pohaugdxKbjkXeJyvNfGnBtrRUSQMI='%s (%s)'%(pohaugdxKbjkXeJyvNfGnBtrRUSQMI,pohaugdxKbjkXeJyvNfGnBtrRUSQmM(pohaugdxKbjkXeJyvNfGnBtrRUSQAm.get('year')))
   else:
    pohaugdxKbjkXeJyvNfGnBtrRUSQAm['plot']=pohaugdxKbjkXeJyvNfGnBtrRUSQMI
   if pohaugdxKbjkXeJyvNfGnBtrRUSQMF=='vod':
    pohaugdxKbjkXeJyvNfGnBtrRUSQMs={'mode':'DEEP_LIST','contentid':pohaugdxKbjkXeJyvNfGnBtrRUSQTM.get('programid'),'contentidType':'programid','uicode':'vod','page':'1','title':pohaugdxKbjkXeJyvNfGnBtrRUSQMI,'subtitle':'','thumbnail':pohaugdxKbjkXeJyvNfGnBtrRUSQAT,'viewage':pohaugdxKbjkXeJyvNfGnBtrRUSQTM.get('viewage')}
    pohaugdxKbjkXeJyvNfGnBtrRUSQMD=pohaugdxKbjkXeJyvNfGnBtrRUSQTi
   else:
    pohaugdxKbjkXeJyvNfGnBtrRUSQMs={'mode':'MOVIE','contentid':pohaugdxKbjkXeJyvNfGnBtrRUSQTM.get('contentid'),'contentidType':'contentid','uicode':'movie','page':'1','title':pohaugdxKbjkXeJyvNfGnBtrRUSQMI,'subtitle':'','thumbnail':pohaugdxKbjkXeJyvNfGnBtrRUSQAT,'viewage':pohaugdxKbjkXeJyvNfGnBtrRUSQTM.get('viewage')}
    pohaugdxKbjkXeJyvNfGnBtrRUSQMD=pohaugdxKbjkXeJyvNfGnBtrRUSQTF
   if pohaugdxKbjkXeJyvNfGnBtrRUSQMs.get('viewage')=='21':pohaugdxKbjkXeJyvNfGnBtrRUSQMI+=' (%s)'%(pohaugdxKbjkXeJyvNfGnBtrRUSQMs.get('viewage'))
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.add_dir(pohaugdxKbjkXeJyvNfGnBtrRUSQMI,sublabel='',img=pohaugdxKbjkXeJyvNfGnBtrRUSQAT,infoLabels=pohaugdxKbjkXeJyvNfGnBtrRUSQAm,isFolder=pohaugdxKbjkXeJyvNfGnBtrRUSQMD,params=pohaugdxKbjkXeJyvNfGnBtrRUSQMs)
  if pohaugdxKbjkXeJyvNfGnBtrRUSQAL:
   pohaugdxKbjkXeJyvNfGnBtrRUSQMs['mode'] ='SEARCH_LIST' 
   pohaugdxKbjkXeJyvNfGnBtrRUSQMs['genre']=pohaugdxKbjkXeJyvNfGnBtrRUSQMF 
   pohaugdxKbjkXeJyvNfGnBtrRUSQMs['page'] =pohaugdxKbjkXeJyvNfGnBtrRUSQmM(pohaugdxKbjkXeJyvNfGnBtrRUSQMV+1)
   pohaugdxKbjkXeJyvNfGnBtrRUSQMs['search_key']=pohaugdxKbjkXeJyvNfGnBtrRUSQIi
   pohaugdxKbjkXeJyvNfGnBtrRUSQMI='[B]%s >>[/B]'%'다음 페이지'
   pohaugdxKbjkXeJyvNfGnBtrRUSQAI=pohaugdxKbjkXeJyvNfGnBtrRUSQmM(pohaugdxKbjkXeJyvNfGnBtrRUSQMV+1)
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.add_dir(pohaugdxKbjkXeJyvNfGnBtrRUSQMI,sublabel=pohaugdxKbjkXeJyvNfGnBtrRUSQAI,img='',infoLabels=pohaugdxKbjkXeJyvNfGnBtrRUSQTP,isFolder=pohaugdxKbjkXeJyvNfGnBtrRUSQTi,params=pohaugdxKbjkXeJyvNfGnBtrRUSQMs)
  if pohaugdxKbjkXeJyvNfGnBtrRUSQmL(pohaugdxKbjkXeJyvNfGnBtrRUSQTL)>0:xbmcplugin.endOfDirectory(pohaugdxKbjkXeJyvNfGnBtrRUSQLm._addon_handle)
 def Load_Watched_List(pohaugdxKbjkXeJyvNfGnBtrRUSQLm,pohaugdxKbjkXeJyvNfGnBtrRUSQAY):
  try:
   pohaugdxKbjkXeJyvNfGnBtrRUSQTA=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%pohaugdxKbjkXeJyvNfGnBtrRUSQAY))
   with pohaugdxKbjkXeJyvNfGnBtrRUSQmI(pohaugdxKbjkXeJyvNfGnBtrRUSQTA,'r',-1,'utf-8')as fp:
    pohaugdxKbjkXeJyvNfGnBtrRUSQTI=fp.readlines()
  except:
   pohaugdxKbjkXeJyvNfGnBtrRUSQTI=[]
  return pohaugdxKbjkXeJyvNfGnBtrRUSQTI
 def Save_Watched_List(pohaugdxKbjkXeJyvNfGnBtrRUSQLm,pohaugdxKbjkXeJyvNfGnBtrRUSQAY,pohaugdxKbjkXeJyvNfGnBtrRUSQLY):
  try:
   pohaugdxKbjkXeJyvNfGnBtrRUSQTA=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%pohaugdxKbjkXeJyvNfGnBtrRUSQAY))
   pohaugdxKbjkXeJyvNfGnBtrRUSQTm=pohaugdxKbjkXeJyvNfGnBtrRUSQLm.Load_Watched_List(pohaugdxKbjkXeJyvNfGnBtrRUSQAY) 
   with pohaugdxKbjkXeJyvNfGnBtrRUSQmI(pohaugdxKbjkXeJyvNfGnBtrRUSQTA,'w',-1,'utf-8')as fp:
    pohaugdxKbjkXeJyvNfGnBtrRUSQTs=urllib.parse.urlencode(pohaugdxKbjkXeJyvNfGnBtrRUSQLY)
    pohaugdxKbjkXeJyvNfGnBtrRUSQTs=pohaugdxKbjkXeJyvNfGnBtrRUSQTs+'\n'
    fp.write(pohaugdxKbjkXeJyvNfGnBtrRUSQTs)
    pohaugdxKbjkXeJyvNfGnBtrRUSQTD=0
    for pohaugdxKbjkXeJyvNfGnBtrRUSQTY in pohaugdxKbjkXeJyvNfGnBtrRUSQTm:
     pohaugdxKbjkXeJyvNfGnBtrRUSQTO=pohaugdxKbjkXeJyvNfGnBtrRUSQmA(urllib.parse.parse_qsl(pohaugdxKbjkXeJyvNfGnBtrRUSQTY))
     pohaugdxKbjkXeJyvNfGnBtrRUSQTW=pohaugdxKbjkXeJyvNfGnBtrRUSQLY.get('code')
     pohaugdxKbjkXeJyvNfGnBtrRUSQTz=pohaugdxKbjkXeJyvNfGnBtrRUSQTO.get('code')
     if pohaugdxKbjkXeJyvNfGnBtrRUSQAY=='vod' and pohaugdxKbjkXeJyvNfGnBtrRUSQLm.get_settings_direct_replay()==pohaugdxKbjkXeJyvNfGnBtrRUSQTi:
      pohaugdxKbjkXeJyvNfGnBtrRUSQTW=pohaugdxKbjkXeJyvNfGnBtrRUSQLY.get('videoid')
      pohaugdxKbjkXeJyvNfGnBtrRUSQTz=pohaugdxKbjkXeJyvNfGnBtrRUSQTO.get('videoid')if pohaugdxKbjkXeJyvNfGnBtrRUSQTz!=pohaugdxKbjkXeJyvNfGnBtrRUSQTP else '-'
     if pohaugdxKbjkXeJyvNfGnBtrRUSQTW!=pohaugdxKbjkXeJyvNfGnBtrRUSQTz:
      fp.write(pohaugdxKbjkXeJyvNfGnBtrRUSQTY)
      pohaugdxKbjkXeJyvNfGnBtrRUSQTD+=1
      if pohaugdxKbjkXeJyvNfGnBtrRUSQTD>=50:break
  except:
   pohaugdxKbjkXeJyvNfGnBtrRUSQTP
 def Delete_Watched_List(pohaugdxKbjkXeJyvNfGnBtrRUSQLm,pohaugdxKbjkXeJyvNfGnBtrRUSQAY):
  try:
   pohaugdxKbjkXeJyvNfGnBtrRUSQTA=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%pohaugdxKbjkXeJyvNfGnBtrRUSQAY))
   with pohaugdxKbjkXeJyvNfGnBtrRUSQmI(pohaugdxKbjkXeJyvNfGnBtrRUSQTA,'w',-1,'utf-8')as fp:
    fp.write('')
  except:
   pohaugdxKbjkXeJyvNfGnBtrRUSQTP
 def dp_WatchList_Delete(pohaugdxKbjkXeJyvNfGnBtrRUSQLm,args):
  pohaugdxKbjkXeJyvNfGnBtrRUSQAY=args.get('genre')
  pohaugdxKbjkXeJyvNfGnBtrRUSQLW=xbmcgui.Dialog()
  pohaugdxKbjkXeJyvNfGnBtrRUSQMl=pohaugdxKbjkXeJyvNfGnBtrRUSQLW.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if pohaugdxKbjkXeJyvNfGnBtrRUSQMl==pohaugdxKbjkXeJyvNfGnBtrRUSQTF:sys.exit()
  pohaugdxKbjkXeJyvNfGnBtrRUSQLm.Delete_Watched_List(pohaugdxKbjkXeJyvNfGnBtrRUSQAY)
  xbmc.executebuiltin("Container.Refresh")
 def logout(pohaugdxKbjkXeJyvNfGnBtrRUSQLm):
  pohaugdxKbjkXeJyvNfGnBtrRUSQLW=xbmcgui.Dialog()
  pohaugdxKbjkXeJyvNfGnBtrRUSQMl=pohaugdxKbjkXeJyvNfGnBtrRUSQLW.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if pohaugdxKbjkXeJyvNfGnBtrRUSQMl==pohaugdxKbjkXeJyvNfGnBtrRUSQTF:sys.exit()
  pohaugdxKbjkXeJyvNfGnBtrRUSQLm.wininfo_clear()
  if os.path.isfile(pohaugdxKbjkXeJyvNfGnBtrRUSQLT):os.remove(pohaugdxKbjkXeJyvNfGnBtrRUSQLT)
  pohaugdxKbjkXeJyvNfGnBtrRUSQLm.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(pohaugdxKbjkXeJyvNfGnBtrRUSQLm):
  pohaugdxKbjkXeJyvNfGnBtrRUSQML=xbmcgui.Window(10000)
  pohaugdxKbjkXeJyvNfGnBtrRUSQML.setProperty('WAVVE_M_CREDENTIAL','')
  pohaugdxKbjkXeJyvNfGnBtrRUSQML.setProperty('WAVVE_M_LOGINTIME','')
 def cookiefile_save(pohaugdxKbjkXeJyvNfGnBtrRUSQLm):
  pohaugdxKbjkXeJyvNfGnBtrRUSQTl =pohaugdxKbjkXeJyvNfGnBtrRUSQLm.WavveObj.Get_Now_Datetime()
  pohaugdxKbjkXeJyvNfGnBtrRUSQTE=pohaugdxKbjkXeJyvNfGnBtrRUSQTl+datetime.timedelta(days=pohaugdxKbjkXeJyvNfGnBtrRUSQTV(__addon__.getSetting('cache_ttl')))
  pohaugdxKbjkXeJyvNfGnBtrRUSQML=xbmcgui.Window(10000)
  pohaugdxKbjkXeJyvNfGnBtrRUSQTq={'wavve_token':pohaugdxKbjkXeJyvNfGnBtrRUSQML.getProperty('WAVVE_M_CREDENTIAL'),'wavve_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'wavve_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'wavve_profile':__addon__.getSetting('selected_profile'),'wavve_limitdate':pohaugdxKbjkXeJyvNfGnBtrRUSQTE.strftime('%Y-%m-%d')}
  try: 
   with pohaugdxKbjkXeJyvNfGnBtrRUSQmI(pohaugdxKbjkXeJyvNfGnBtrRUSQLT,'w',-1,'utf-8')as fp:
    pohaugdxKbjkXeJyvNfGnBtrRUSQTH.dump(pohaugdxKbjkXeJyvNfGnBtrRUSQTq,fp)
  except pohaugdxKbjkXeJyvNfGnBtrRUSQmT as exception:
   pohaugdxKbjkXeJyvNfGnBtrRUSQms(exception)
 def cookiefile_check(pohaugdxKbjkXeJyvNfGnBtrRUSQLm):
  pohaugdxKbjkXeJyvNfGnBtrRUSQTq={}
  try: 
   with pohaugdxKbjkXeJyvNfGnBtrRUSQmI(pohaugdxKbjkXeJyvNfGnBtrRUSQLT,'r',-1,'utf-8')as fp:
    pohaugdxKbjkXeJyvNfGnBtrRUSQTq= pohaugdxKbjkXeJyvNfGnBtrRUSQTH.load(fp)
  except pohaugdxKbjkXeJyvNfGnBtrRUSQmT as exception:
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.wininfo_clear()
   return pohaugdxKbjkXeJyvNfGnBtrRUSQTF
  pohaugdxKbjkXeJyvNfGnBtrRUSQMO =__addon__.getSetting('id')
  pohaugdxKbjkXeJyvNfGnBtrRUSQMW =__addon__.getSetting('pw')
  pohaugdxKbjkXeJyvNfGnBtrRUSQTC =__addon__.getSetting('selected_profile')
  pohaugdxKbjkXeJyvNfGnBtrRUSQTq['wavve_id']=base64.standard_b64decode(pohaugdxKbjkXeJyvNfGnBtrRUSQTq['wavve_id']).decode('utf-8')
  pohaugdxKbjkXeJyvNfGnBtrRUSQTq['wavve_pw']=base64.standard_b64decode(pohaugdxKbjkXeJyvNfGnBtrRUSQTq['wavve_pw']).decode('utf-8')
  if pohaugdxKbjkXeJyvNfGnBtrRUSQMO!=pohaugdxKbjkXeJyvNfGnBtrRUSQTq['wavve_id']or pohaugdxKbjkXeJyvNfGnBtrRUSQMW!=pohaugdxKbjkXeJyvNfGnBtrRUSQTq['wavve_pw']or pohaugdxKbjkXeJyvNfGnBtrRUSQTC!=pohaugdxKbjkXeJyvNfGnBtrRUSQTq['wavve_profile']:
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.wininfo_clear()
   return pohaugdxKbjkXeJyvNfGnBtrRUSQTF
  pohaugdxKbjkXeJyvNfGnBtrRUSQME =pohaugdxKbjkXeJyvNfGnBtrRUSQTV(pohaugdxKbjkXeJyvNfGnBtrRUSQLm.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  pohaugdxKbjkXeJyvNfGnBtrRUSQTc=pohaugdxKbjkXeJyvNfGnBtrRUSQTq['wavve_limitdate']
  pohaugdxKbjkXeJyvNfGnBtrRUSQMq =pohaugdxKbjkXeJyvNfGnBtrRUSQTV(re.sub('-','',pohaugdxKbjkXeJyvNfGnBtrRUSQTc))
  if pohaugdxKbjkXeJyvNfGnBtrRUSQMq<pohaugdxKbjkXeJyvNfGnBtrRUSQME:
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.wininfo_clear()
   return pohaugdxKbjkXeJyvNfGnBtrRUSQTF
  pohaugdxKbjkXeJyvNfGnBtrRUSQML=xbmcgui.Window(10000)
  pohaugdxKbjkXeJyvNfGnBtrRUSQML.setProperty('WAVVE_M_CREDENTIAL',pohaugdxKbjkXeJyvNfGnBtrRUSQTq['wavve_token'])
  pohaugdxKbjkXeJyvNfGnBtrRUSQML.setProperty('WAVVE_M_LOGINTIME',pohaugdxKbjkXeJyvNfGnBtrRUSQTc)
  return pohaugdxKbjkXeJyvNfGnBtrRUSQTi
 def wavve_main(pohaugdxKbjkXeJyvNfGnBtrRUSQLm):
  pohaugdxKbjkXeJyvNfGnBtrRUSQAs=pohaugdxKbjkXeJyvNfGnBtrRUSQLm.main_params.get('mode',pohaugdxKbjkXeJyvNfGnBtrRUSQTP)
  pohaugdxKbjkXeJyvNfGnBtrRUSQLm.login_main()
  if pohaugdxKbjkXeJyvNfGnBtrRUSQAs is pohaugdxKbjkXeJyvNfGnBtrRUSQTP:
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.dp_Main_List()
  elif pohaugdxKbjkXeJyvNfGnBtrRUSQAs=='GNB_LIST':
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.dp_Gnb_List(pohaugdxKbjkXeJyvNfGnBtrRUSQLm.main_params)
  elif pohaugdxKbjkXeJyvNfGnBtrRUSQAs=='GN_LIST':
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.dp_Deeplink_List(pohaugdxKbjkXeJyvNfGnBtrRUSQLm.main_params)
  elif pohaugdxKbjkXeJyvNfGnBtrRUSQAs=='DEEP_LIST':
   pohaugdxKbjkXeJyvNfGnBtrRUSQMF=pohaugdxKbjkXeJyvNfGnBtrRUSQLm.main_params.get('uicode',pohaugdxKbjkXeJyvNfGnBtrRUSQTP)
   if pohaugdxKbjkXeJyvNfGnBtrRUSQMF in['quick','vod','program','x']:
    pohaugdxKbjkXeJyvNfGnBtrRUSQLm.dp_Episodelink_List(pohaugdxKbjkXeJyvNfGnBtrRUSQLm.main_params)
   else:pohaugdxKbjkXeJyvNfGnBtrRUSQTP
  elif pohaugdxKbjkXeJyvNfGnBtrRUSQAs in['LIVE','VOD','MOVIE']:
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.play_VIDEO(pohaugdxKbjkXeJyvNfGnBtrRUSQLm.main_params)
   time.sleep(0.1)
  elif pohaugdxKbjkXeJyvNfGnBtrRUSQAs=='GN_MYVIEW':
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.dp_Myview_Group(pohaugdxKbjkXeJyvNfGnBtrRUSQLm.main_params)
  elif pohaugdxKbjkXeJyvNfGnBtrRUSQAs=='MYVIEW_LIST':
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.dp_Myview_List(pohaugdxKbjkXeJyvNfGnBtrRUSQLm.main_params)
  elif pohaugdxKbjkXeJyvNfGnBtrRUSQAs=='GENRE':
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.dp_Genre_Group(pohaugdxKbjkXeJyvNfGnBtrRUSQLm.main_params)
  elif pohaugdxKbjkXeJyvNfGnBtrRUSQAs=='GENRE_LIST':
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.dp_Genre_List(pohaugdxKbjkXeJyvNfGnBtrRUSQLm.main_params)
  elif pohaugdxKbjkXeJyvNfGnBtrRUSQAs=='WATCH':
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.dp_Watch_List(pohaugdxKbjkXeJyvNfGnBtrRUSQLm.main_params)
  elif pohaugdxKbjkXeJyvNfGnBtrRUSQAs=='MYVIEW_REMOVE':
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.dp_WatchList_Delete(pohaugdxKbjkXeJyvNfGnBtrRUSQLm.main_params)
  elif pohaugdxKbjkXeJyvNfGnBtrRUSQAs=='SEARCH':
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.dp_Search_Group(pohaugdxKbjkXeJyvNfGnBtrRUSQLm.main_params)
  elif pohaugdxKbjkXeJyvNfGnBtrRUSQAs=='SEARCH_LIST':
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.dp_Search_List(pohaugdxKbjkXeJyvNfGnBtrRUSQLm.main_params)
  elif pohaugdxKbjkXeJyvNfGnBtrRUSQAs=='ORDER_BY':
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.dp_setEpOrderby(pohaugdxKbjkXeJyvNfGnBtrRUSQLm.main_params)
  elif pohaugdxKbjkXeJyvNfGnBtrRUSQAs=='LOGOUT':
   pohaugdxKbjkXeJyvNfGnBtrRUSQLm.logout()
  else:
   pohaugdxKbjkXeJyvNfGnBtrRUSQTP
# Created by pyminifier (https://github.com/liftoff/pyminifier)
