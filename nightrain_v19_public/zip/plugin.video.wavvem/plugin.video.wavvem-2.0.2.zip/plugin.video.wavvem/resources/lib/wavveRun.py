__author__="NightRain"
gcjqSkAGhVHztUwJrdQlFBePoWaNnm=object
gcjqSkAGhVHztUwJrdQlFBePoWaNnT=None
gcjqSkAGhVHztUwJrdQlFBePoWaNnu=False
gcjqSkAGhVHztUwJrdQlFBePoWaNnO=int
gcjqSkAGhVHztUwJrdQlFBePoWaNnX=True
gcjqSkAGhVHztUwJrdQlFBePoWaNfE=len
gcjqSkAGhVHztUwJrdQlFBePoWaNfK=str
gcjqSkAGhVHztUwJrdQlFBePoWaNfM=dict
gcjqSkAGhVHztUwJrdQlFBePoWaNfD=open
gcjqSkAGhVHztUwJrdQlFBePoWaNfn=Exception
gcjqSkAGhVHztUwJrdQlFBePoWaNfb=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
gcjqSkAGhVHztUwJrdQlFBePoWaNEM=[{'title':'홈','uicode':'GN1','came':'home'},{'title':'LIVE 채널','uicode':'GN3','came':'live'},{'title':'VOD 방송','uicode':'GN2','came':'broadcast'},{'title':'영화(Movie)','uicode':'GN17','came':'movie'},{'title':'해외시리즈','uicode':'GN12','came':'global'},{'title':'분류별 - 방송(VOD) - 인기순','uicode':'GENRE','came':'vodgenre','orderby':'viewtime','ordernm':'인기순'},{'title':'분류별 - 방송(VOD) - 최신순','uicode':'GENRE','came':'vodgenre','orderby':'new','ordernm':'최신순'},{'title':'분류별 - 영화(Movie) - 인기순','uicode':'GENRE','came':'moviegenre_svod','orderby':'paid','ordernm':'인기순'},{'title':'분류별 - 영화(Movie) - 업데이트순','uicode':'GENRE','came':'moviegenre_svod','orderby':'displaystart','ordernm':'업데이트순'},{'title':'검색','uicode':'SEARCH','came':'-'},{'title':'Watched(시청목록)','uicode':'WATCH','came':'-'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmc.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
gcjqSkAGhVHztUwJrdQlFBePoWaNED='Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'
gcjqSkAGhVHztUwJrdQlFBePoWaNEn=xbmc.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
from wavveCore import*
class gcjqSkAGhVHztUwJrdQlFBePoWaNEK(gcjqSkAGhVHztUwJrdQlFBePoWaNnm):
 def __init__(gcjqSkAGhVHztUwJrdQlFBePoWaNEf,gcjqSkAGhVHztUwJrdQlFBePoWaNEb,gcjqSkAGhVHztUwJrdQlFBePoWaNEv,gcjqSkAGhVHztUwJrdQlFBePoWaNER):
  gcjqSkAGhVHztUwJrdQlFBePoWaNEf._addon_url =gcjqSkAGhVHztUwJrdQlFBePoWaNEb
  gcjqSkAGhVHztUwJrdQlFBePoWaNEf._addon_handle=gcjqSkAGhVHztUwJrdQlFBePoWaNEv
  gcjqSkAGhVHztUwJrdQlFBePoWaNEf.main_params =gcjqSkAGhVHztUwJrdQlFBePoWaNER
  gcjqSkAGhVHztUwJrdQlFBePoWaNEf.WavveObj =mMQnSdiXKFNwHVuPhpTGYUWDgIsxlJ() 
 def addon_noti(gcjqSkAGhVHztUwJrdQlFBePoWaNEf,sting):
  try:
   gcjqSkAGhVHztUwJrdQlFBePoWaNEL=xbmcgui.Dialog()
   gcjqSkAGhVHztUwJrdQlFBePoWaNEL.notification(__addonname__,sting)
  except:
   gcjqSkAGhVHztUwJrdQlFBePoWaNnT
 def addon_log(gcjqSkAGhVHztUwJrdQlFBePoWaNEf,string,isDebug=gcjqSkAGhVHztUwJrdQlFBePoWaNnu):
  try:
   gcjqSkAGhVHztUwJrdQlFBePoWaNEs=string.encode('utf-8','ignore')
  except:
   gcjqSkAGhVHztUwJrdQlFBePoWaNEs='addonException: addon_log'
  if isDebug:gcjqSkAGhVHztUwJrdQlFBePoWaNEx=xbmc.LOGDEBUG
  else:gcjqSkAGhVHztUwJrdQlFBePoWaNEx=xbmc.LOGNOTICE
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,gcjqSkAGhVHztUwJrdQlFBePoWaNEs),level=gcjqSkAGhVHztUwJrdQlFBePoWaNEx)
 def get_keyboard_input(gcjqSkAGhVHztUwJrdQlFBePoWaNEf,gcjqSkAGhVHztUwJrdQlFBePoWaNKD):
  gcjqSkAGhVHztUwJrdQlFBePoWaNEp=gcjqSkAGhVHztUwJrdQlFBePoWaNnT
  kb=xbmc.Keyboard()
  kb.setHeading(gcjqSkAGhVHztUwJrdQlFBePoWaNKD)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   gcjqSkAGhVHztUwJrdQlFBePoWaNEp=kb.getText()
  return gcjqSkAGhVHztUwJrdQlFBePoWaNEp
 def get_settings_login_info(gcjqSkAGhVHztUwJrdQlFBePoWaNEf):
  gcjqSkAGhVHztUwJrdQlFBePoWaNEI =__addon__.getSetting('id')
  gcjqSkAGhVHztUwJrdQlFBePoWaNEC =__addon__.getSetting('pw')
  gcjqSkAGhVHztUwJrdQlFBePoWaNEy=__addon__.getSetting('selected_profile')
  return(gcjqSkAGhVHztUwJrdQlFBePoWaNEI,gcjqSkAGhVHztUwJrdQlFBePoWaNEC,gcjqSkAGhVHztUwJrdQlFBePoWaNEy)
 def get_selQuality(gcjqSkAGhVHztUwJrdQlFBePoWaNEf):
  try:
   gcjqSkAGhVHztUwJrdQlFBePoWaNEY=[1080,720,480,360]
   gcjqSkAGhVHztUwJrdQlFBePoWaNEm=gcjqSkAGhVHztUwJrdQlFBePoWaNnO(__addon__.getSetting('selected_quality'))
   return gcjqSkAGhVHztUwJrdQlFBePoWaNEY[gcjqSkAGhVHztUwJrdQlFBePoWaNEm]
  except:
   gcjqSkAGhVHztUwJrdQlFBePoWaNnT
  return 1080 
 def get_settings_exclusion21(gcjqSkAGhVHztUwJrdQlFBePoWaNEf):
  gcjqSkAGhVHztUwJrdQlFBePoWaNET =__addon__.getSetting('exclusion21')
  if gcjqSkAGhVHztUwJrdQlFBePoWaNET=='false':
   return gcjqSkAGhVHztUwJrdQlFBePoWaNnu
  else:
   return gcjqSkAGhVHztUwJrdQlFBePoWaNnX
 def get_settings_direct_replay(gcjqSkAGhVHztUwJrdQlFBePoWaNEf):
  gcjqSkAGhVHztUwJrdQlFBePoWaNEu=gcjqSkAGhVHztUwJrdQlFBePoWaNnO(__addon__.getSetting('direct_replay'))
  if gcjqSkAGhVHztUwJrdQlFBePoWaNEu==0:
   return gcjqSkAGhVHztUwJrdQlFBePoWaNnu
  else:
   return gcjqSkAGhVHztUwJrdQlFBePoWaNnX
 def get_settings_addinfo(gcjqSkAGhVHztUwJrdQlFBePoWaNEf):
  gcjqSkAGhVHztUwJrdQlFBePoWaNEO =__addon__.getSetting('add_infoyn')
  if gcjqSkAGhVHztUwJrdQlFBePoWaNEO=='false':
   return gcjqSkAGhVHztUwJrdQlFBePoWaNnu
  else:
   return gcjqSkAGhVHztUwJrdQlFBePoWaNnX
 def get_settings_thumbnail_landyn(gcjqSkAGhVHztUwJrdQlFBePoWaNEf):
  gcjqSkAGhVHztUwJrdQlFBePoWaNEX =gcjqSkAGhVHztUwJrdQlFBePoWaNnO(__addon__.getSetting('thumbnail_way'))
  if gcjqSkAGhVHztUwJrdQlFBePoWaNEX==0:
   return gcjqSkAGhVHztUwJrdQlFBePoWaNnX
  else:
   return gcjqSkAGhVHztUwJrdQlFBePoWaNnu
 def set_winCredential(gcjqSkAGhVHztUwJrdQlFBePoWaNEf,credential):
  gcjqSkAGhVHztUwJrdQlFBePoWaNKE=xbmcgui.Window(10000)
  gcjqSkAGhVHztUwJrdQlFBePoWaNKE.setProperty('WAVVE_M_CREDENTIAL',credential)
  gcjqSkAGhVHztUwJrdQlFBePoWaNKE.setProperty('WAVVE_M_LOGINTIME',gcjqSkAGhVHztUwJrdQlFBePoWaNEf.WavveObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(gcjqSkAGhVHztUwJrdQlFBePoWaNEf):
  gcjqSkAGhVHztUwJrdQlFBePoWaNKE=xbmcgui.Window(10000)
  return gcjqSkAGhVHztUwJrdQlFBePoWaNKE.getProperty('WAVVE_M_CREDENTIAL')
 def set_winEpisodeOrderby(gcjqSkAGhVHztUwJrdQlFBePoWaNEf,gcjqSkAGhVHztUwJrdQlFBePoWaNKy):
  gcjqSkAGhVHztUwJrdQlFBePoWaNKE=xbmcgui.Window(10000)
  gcjqSkAGhVHztUwJrdQlFBePoWaNKE.setProperty('WAVVE_M_ORDERBY',gcjqSkAGhVHztUwJrdQlFBePoWaNKy)
 def get_winEpisodeOrderby(gcjqSkAGhVHztUwJrdQlFBePoWaNEf):
  gcjqSkAGhVHztUwJrdQlFBePoWaNKE=xbmcgui.Window(10000)
  return gcjqSkAGhVHztUwJrdQlFBePoWaNKE.getProperty('WAVVE_M_ORDERBY')
 def add_dir(gcjqSkAGhVHztUwJrdQlFBePoWaNEf,label,sublabel='',img='',infoLabels=gcjqSkAGhVHztUwJrdQlFBePoWaNnT,isFolder=gcjqSkAGhVHztUwJrdQlFBePoWaNnX,params=''):
  gcjqSkAGhVHztUwJrdQlFBePoWaNKM='%s?%s'%(gcjqSkAGhVHztUwJrdQlFBePoWaNEf._addon_url,urllib.parse.urlencode(params))
  if sublabel:gcjqSkAGhVHztUwJrdQlFBePoWaNKD='%s < %s >'%(label,sublabel)
  else: gcjqSkAGhVHztUwJrdQlFBePoWaNKD=label
  if not img:img='DefaultFolder.png'
  gcjqSkAGhVHztUwJrdQlFBePoWaNKn=xbmcgui.ListItem(gcjqSkAGhVHztUwJrdQlFBePoWaNKD)
  gcjqSkAGhVHztUwJrdQlFBePoWaNKn.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:gcjqSkAGhVHztUwJrdQlFBePoWaNKn.setInfo(type="video",infoLabels=infoLabels)
  if not isFolder:gcjqSkAGhVHztUwJrdQlFBePoWaNKn.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(gcjqSkAGhVHztUwJrdQlFBePoWaNEf._addon_handle,gcjqSkAGhVHztUwJrdQlFBePoWaNKM,gcjqSkAGhVHztUwJrdQlFBePoWaNKn,isFolder)
 def dp_Main_List(gcjqSkAGhVHztUwJrdQlFBePoWaNEf):
  for gcjqSkAGhVHztUwJrdQlFBePoWaNKf in gcjqSkAGhVHztUwJrdQlFBePoWaNEM:
   gcjqSkAGhVHztUwJrdQlFBePoWaNKD=gcjqSkAGhVHztUwJrdQlFBePoWaNKf.get('title')
   if gcjqSkAGhVHztUwJrdQlFBePoWaNKf.get('uicode')=='GENRE':
    gcjqSkAGhVHztUwJrdQlFBePoWaNKb={'mode':'GENRE','uicode':gcjqSkAGhVHztUwJrdQlFBePoWaNKf.get('came'),'genre':'-','subgenre':'-','orderby':gcjqSkAGhVHztUwJrdQlFBePoWaNKf.get('orderby'),'ordernm':gcjqSkAGhVHztUwJrdQlFBePoWaNKf.get('ordernm')}
   elif gcjqSkAGhVHztUwJrdQlFBePoWaNKf.get('uicode')=='WATCH':
    gcjqSkAGhVHztUwJrdQlFBePoWaNKb={'mode':'WATCH','genre':'-'}
   elif gcjqSkAGhVHztUwJrdQlFBePoWaNKf.get('uicode')=='SEARCH':
    gcjqSkAGhVHztUwJrdQlFBePoWaNKb={'mode':'SEARCH','genre':'-'}
   else:
    gcjqSkAGhVHztUwJrdQlFBePoWaNKb={'mode':'GNB_LIST','uicode':gcjqSkAGhVHztUwJrdQlFBePoWaNKf.get('uicode'),'came':gcjqSkAGhVHztUwJrdQlFBePoWaNKf.get('came')}
   gcjqSkAGhVHztUwJrdQlFBePoWaNKv=gcjqSkAGhVHztUwJrdQlFBePoWaNnX
   if gcjqSkAGhVHztUwJrdQlFBePoWaNKf.get('uicode')=='XXX':
    gcjqSkAGhVHztUwJrdQlFBePoWaNKb['mode']='XXX'
    gcjqSkAGhVHztUwJrdQlFBePoWaNKv=gcjqSkAGhVHztUwJrdQlFBePoWaNnu
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.add_dir(gcjqSkAGhVHztUwJrdQlFBePoWaNKD,sublabel='',img='',infoLabels=gcjqSkAGhVHztUwJrdQlFBePoWaNnT,isFolder=gcjqSkAGhVHztUwJrdQlFBePoWaNKv,params=gcjqSkAGhVHztUwJrdQlFBePoWaNKb)
  if gcjqSkAGhVHztUwJrdQlFBePoWaNfE(gcjqSkAGhVHztUwJrdQlFBePoWaNEM)>0:xbmcplugin.endOfDirectory(gcjqSkAGhVHztUwJrdQlFBePoWaNEf._addon_handle)
 def login_main(gcjqSkAGhVHztUwJrdQlFBePoWaNEf):
  (gcjqSkAGhVHztUwJrdQlFBePoWaNKi,gcjqSkAGhVHztUwJrdQlFBePoWaNKL,gcjqSkAGhVHztUwJrdQlFBePoWaNKs)=gcjqSkAGhVHztUwJrdQlFBePoWaNEf.get_settings_login_info()
  if not(gcjqSkAGhVHztUwJrdQlFBePoWaNKi and gcjqSkAGhVHztUwJrdQlFBePoWaNKL):
   gcjqSkAGhVHztUwJrdQlFBePoWaNEL=xbmcgui.Dialog()
   gcjqSkAGhVHztUwJrdQlFBePoWaNKx=gcjqSkAGhVHztUwJrdQlFBePoWaNEL.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if gcjqSkAGhVHztUwJrdQlFBePoWaNKx==gcjqSkAGhVHztUwJrdQlFBePoWaNnX:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if gcjqSkAGhVHztUwJrdQlFBePoWaNEf.get_winEpisodeOrderby()=='':
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.set_winEpisodeOrderby('desc')
  if gcjqSkAGhVHztUwJrdQlFBePoWaNEf.cookiefile_check():return
  gcjqSkAGhVHztUwJrdQlFBePoWaNKp =gcjqSkAGhVHztUwJrdQlFBePoWaNnO(gcjqSkAGhVHztUwJrdQlFBePoWaNEf.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  gcjqSkAGhVHztUwJrdQlFBePoWaNKI=xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINTIME')
  if gcjqSkAGhVHztUwJrdQlFBePoWaNKI==gcjqSkAGhVHztUwJrdQlFBePoWaNnT or gcjqSkAGhVHztUwJrdQlFBePoWaNKI=='':gcjqSkAGhVHztUwJrdQlFBePoWaNKI=gcjqSkAGhVHztUwJrdQlFBePoWaNnO('19000101')
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   gcjqSkAGhVHztUwJrdQlFBePoWaNKC=0
   while gcjqSkAGhVHztUwJrdQlFBePoWaNnX:
    gcjqSkAGhVHztUwJrdQlFBePoWaNKC+=1
    time.sleep(0.05)
    if gcjqSkAGhVHztUwJrdQlFBePoWaNKI>=gcjqSkAGhVHztUwJrdQlFBePoWaNKp:return
    if gcjqSkAGhVHztUwJrdQlFBePoWaNKC>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  if gcjqSkAGhVHztUwJrdQlFBePoWaNKI>=gcjqSkAGhVHztUwJrdQlFBePoWaNKp:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   return
  if not gcjqSkAGhVHztUwJrdQlFBePoWaNEf.WavveObj.GetCredential(gcjqSkAGhVHztUwJrdQlFBePoWaNKi,gcjqSkAGhVHztUwJrdQlFBePoWaNKL,gcjqSkAGhVHztUwJrdQlFBePoWaNKs):
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   sys.exit()
  gcjqSkAGhVHztUwJrdQlFBePoWaNEf.set_winCredential(gcjqSkAGhVHztUwJrdQlFBePoWaNEf.WavveObj.LoadCredential())
  gcjqSkAGhVHztUwJrdQlFBePoWaNEf.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
 def dp_setEpOrderby(gcjqSkAGhVHztUwJrdQlFBePoWaNEf,args):
  gcjqSkAGhVHztUwJrdQlFBePoWaNKy =args.get('orderby')
  gcjqSkAGhVHztUwJrdQlFBePoWaNEf.set_winEpisodeOrderby(gcjqSkAGhVHztUwJrdQlFBePoWaNKy)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Gnb_List(gcjqSkAGhVHztUwJrdQlFBePoWaNEf,args):
  gcjqSkAGhVHztUwJrdQlFBePoWaNEf.WavveObj.SaveCredential(gcjqSkAGhVHztUwJrdQlFBePoWaNEf.get_winCredential())
  gcjqSkAGhVHztUwJrdQlFBePoWaNKY=gcjqSkAGhVHztUwJrdQlFBePoWaNEf.WavveObj.GetGnList(args.get('uicode'))
  for gcjqSkAGhVHztUwJrdQlFBePoWaNKm in gcjqSkAGhVHztUwJrdQlFBePoWaNKY:
   gcjqSkAGhVHztUwJrdQlFBePoWaNKD=gcjqSkAGhVHztUwJrdQlFBePoWaNKm.get('title')
   gcjqSkAGhVHztUwJrdQlFBePoWaNKb={'mode':'GN_LIST' if gcjqSkAGhVHztUwJrdQlFBePoWaNKm.get('uicode')!='CY1' else 'GN_MYVIEW','uicode':gcjqSkAGhVHztUwJrdQlFBePoWaNKm.get('uicode'),'came':args.get('came'),'page':'1'}
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.add_dir(gcjqSkAGhVHztUwJrdQlFBePoWaNKD,sublabel='',img='',infoLabels=gcjqSkAGhVHztUwJrdQlFBePoWaNnT,isFolder=gcjqSkAGhVHztUwJrdQlFBePoWaNnX,params=gcjqSkAGhVHztUwJrdQlFBePoWaNKb)
  if gcjqSkAGhVHztUwJrdQlFBePoWaNfE(gcjqSkAGhVHztUwJrdQlFBePoWaNKY)>0:xbmcplugin.endOfDirectory(gcjqSkAGhVHztUwJrdQlFBePoWaNEf._addon_handle,cacheToDisc=gcjqSkAGhVHztUwJrdQlFBePoWaNnu)
 def dp_Myview_Group(gcjqSkAGhVHztUwJrdQlFBePoWaNEf,args):
  gcjqSkAGhVHztUwJrdQlFBePoWaNKD='VOD 시청내역'
  gcjqSkAGhVHztUwJrdQlFBePoWaNKb={'mode':'MYVIEW_LIST','uicode':'vod','page':'1'}
  gcjqSkAGhVHztUwJrdQlFBePoWaNEf.add_dir(gcjqSkAGhVHztUwJrdQlFBePoWaNKD,sublabel='',img='',infoLabels=gcjqSkAGhVHztUwJrdQlFBePoWaNnT,isFolder=gcjqSkAGhVHztUwJrdQlFBePoWaNnX,params=gcjqSkAGhVHztUwJrdQlFBePoWaNKb)
  gcjqSkAGhVHztUwJrdQlFBePoWaNKD='영화 시청내역'
  gcjqSkAGhVHztUwJrdQlFBePoWaNKb['uicode']='movie'
  gcjqSkAGhVHztUwJrdQlFBePoWaNEf.add_dir(gcjqSkAGhVHztUwJrdQlFBePoWaNKD,sublabel='',img='',infoLabels=gcjqSkAGhVHztUwJrdQlFBePoWaNnT,isFolder=gcjqSkAGhVHztUwJrdQlFBePoWaNnX,params=gcjqSkAGhVHztUwJrdQlFBePoWaNKb)
  xbmcplugin.endOfDirectory(gcjqSkAGhVHztUwJrdQlFBePoWaNEf._addon_handle)
 def dp_Myview_List(gcjqSkAGhVHztUwJrdQlFBePoWaNEf,args):
  gcjqSkAGhVHztUwJrdQlFBePoWaNEf.WavveObj.SaveCredential(gcjqSkAGhVHztUwJrdQlFBePoWaNEf.get_winCredential())
  gcjqSkAGhVHztUwJrdQlFBePoWaNKT =gcjqSkAGhVHztUwJrdQlFBePoWaNEf.get_settings_addinfo()
  gcjqSkAGhVHztUwJrdQlFBePoWaNKu=args.get('uicode')
  gcjqSkAGhVHztUwJrdQlFBePoWaNKO =gcjqSkAGhVHztUwJrdQlFBePoWaNnO(args.get('page'))
  gcjqSkAGhVHztUwJrdQlFBePoWaNKX,gcjqSkAGhVHztUwJrdQlFBePoWaNME=gcjqSkAGhVHztUwJrdQlFBePoWaNEf.WavveObj.GetMyviewList(gcjqSkAGhVHztUwJrdQlFBePoWaNKu,gcjqSkAGhVHztUwJrdQlFBePoWaNKO,addinfoyn=gcjqSkAGhVHztUwJrdQlFBePoWaNKT)
  for gcjqSkAGhVHztUwJrdQlFBePoWaNMK in gcjqSkAGhVHztUwJrdQlFBePoWaNKX:
   gcjqSkAGhVHztUwJrdQlFBePoWaNKD =gcjqSkAGhVHztUwJrdQlFBePoWaNMK.get('title')
   gcjqSkAGhVHztUwJrdQlFBePoWaNMD =gcjqSkAGhVHztUwJrdQlFBePoWaNMK.get('subtitle')
   gcjqSkAGhVHztUwJrdQlFBePoWaNMn=gcjqSkAGhVHztUwJrdQlFBePoWaNMK.get('thumbnail')
   gcjqSkAGhVHztUwJrdQlFBePoWaNMf=gcjqSkAGhVHztUwJrdQlFBePoWaNMK.get('info')
   if gcjqSkAGhVHztUwJrdQlFBePoWaNKu=='movie' and gcjqSkAGhVHztUwJrdQlFBePoWaNKT==gcjqSkAGhVHztUwJrdQlFBePoWaNnX:
    gcjqSkAGhVHztUwJrdQlFBePoWaNKD='%s (%s)'%(gcjqSkAGhVHztUwJrdQlFBePoWaNKD,gcjqSkAGhVHztUwJrdQlFBePoWaNfK(gcjqSkAGhVHztUwJrdQlFBePoWaNMf.get('year')))
   else:
    gcjqSkAGhVHztUwJrdQlFBePoWaNMf['plot']=gcjqSkAGhVHztUwJrdQlFBePoWaNKD
   if gcjqSkAGhVHztUwJrdQlFBePoWaNKu=='vod':
    gcjqSkAGhVHztUwJrdQlFBePoWaNKb={'mode':'DEEP_LIST','contentid':gcjqSkAGhVHztUwJrdQlFBePoWaNMK.get('programid'),'contentidType':'programid','uicode':'vod','page':'1','title':gcjqSkAGhVHztUwJrdQlFBePoWaNKD,'subtitle':gcjqSkAGhVHztUwJrdQlFBePoWaNMD,'thumbnail':gcjqSkAGhVHztUwJrdQlFBePoWaNMn,'viewage':gcjqSkAGhVHztUwJrdQlFBePoWaNMK.get('viewage')}
    gcjqSkAGhVHztUwJrdQlFBePoWaNKv=gcjqSkAGhVHztUwJrdQlFBePoWaNnX
   else:
    gcjqSkAGhVHztUwJrdQlFBePoWaNKb={'mode':'MOVIE','contentid':gcjqSkAGhVHztUwJrdQlFBePoWaNMK.get('contentid'),'contentidType':'contentid','uicode':'movie','page':'1','title':gcjqSkAGhVHztUwJrdQlFBePoWaNKD,'subtitle':gcjqSkAGhVHztUwJrdQlFBePoWaNMD,'thumbnail':gcjqSkAGhVHztUwJrdQlFBePoWaNMn,'viewage':gcjqSkAGhVHztUwJrdQlFBePoWaNMK.get('viewage')}
    gcjqSkAGhVHztUwJrdQlFBePoWaNKv=gcjqSkAGhVHztUwJrdQlFBePoWaNnu
   if gcjqSkAGhVHztUwJrdQlFBePoWaNMK.get('viewage')=='21':gcjqSkAGhVHztUwJrdQlFBePoWaNMD+=' (%s)'%(gcjqSkAGhVHztUwJrdQlFBePoWaNMK.get('viewage'))
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.add_dir(gcjqSkAGhVHztUwJrdQlFBePoWaNKD,sublabel=gcjqSkAGhVHztUwJrdQlFBePoWaNMD,img=gcjqSkAGhVHztUwJrdQlFBePoWaNMn,infoLabels=gcjqSkAGhVHztUwJrdQlFBePoWaNMf,isFolder=gcjqSkAGhVHztUwJrdQlFBePoWaNKv,params=gcjqSkAGhVHztUwJrdQlFBePoWaNKb)
  if gcjqSkAGhVHztUwJrdQlFBePoWaNME:
   gcjqSkAGhVHztUwJrdQlFBePoWaNKb['mode'] ='MYVIEW_LIST' 
   gcjqSkAGhVHztUwJrdQlFBePoWaNKb['uicode']=gcjqSkAGhVHztUwJrdQlFBePoWaNKu 
   gcjqSkAGhVHztUwJrdQlFBePoWaNKb['page'] =gcjqSkAGhVHztUwJrdQlFBePoWaNfK(gcjqSkAGhVHztUwJrdQlFBePoWaNKO+1)
   gcjqSkAGhVHztUwJrdQlFBePoWaNKD='[B]%s >>[/B]'%'다음 페이지'
   gcjqSkAGhVHztUwJrdQlFBePoWaNMD=gcjqSkAGhVHztUwJrdQlFBePoWaNfK(gcjqSkAGhVHztUwJrdQlFBePoWaNKO+1)
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.add_dir(gcjqSkAGhVHztUwJrdQlFBePoWaNKD,sublabel=gcjqSkAGhVHztUwJrdQlFBePoWaNMD,img='',infoLabels=gcjqSkAGhVHztUwJrdQlFBePoWaNnT,isFolder=gcjqSkAGhVHztUwJrdQlFBePoWaNnX,params=gcjqSkAGhVHztUwJrdQlFBePoWaNKb)
  if gcjqSkAGhVHztUwJrdQlFBePoWaNfE(gcjqSkAGhVHztUwJrdQlFBePoWaNKX)>0:xbmcplugin.endOfDirectory(gcjqSkAGhVHztUwJrdQlFBePoWaNEf._addon_handle,cacheToDisc=gcjqSkAGhVHztUwJrdQlFBePoWaNnu)
 def dp_Genre_Group(gcjqSkAGhVHztUwJrdQlFBePoWaNEf,args):
  gcjqSkAGhVHztUwJrdQlFBePoWaNEf.WavveObj.SaveCredential(gcjqSkAGhVHztUwJrdQlFBePoWaNEf.get_winCredential())
  gcjqSkAGhVHztUwJrdQlFBePoWaNMb =args.get('mode') 
  gcjqSkAGhVHztUwJrdQlFBePoWaNMv =args.get('uicode')
  gcjqSkAGhVHztUwJrdQlFBePoWaNMR =args.get('genre') 
  gcjqSkAGhVHztUwJrdQlFBePoWaNMi=args.get('subgenre')
  gcjqSkAGhVHztUwJrdQlFBePoWaNKy =args.get('orderby')
  gcjqSkAGhVHztUwJrdQlFBePoWaNML =args.get('ordernm')
  if gcjqSkAGhVHztUwJrdQlFBePoWaNMR=='-':
   gcjqSkAGhVHztUwJrdQlFBePoWaNMs=gcjqSkAGhVHztUwJrdQlFBePoWaNEf.WavveObj.GetGenreGroup(gcjqSkAGhVHztUwJrdQlFBePoWaNMv,gcjqSkAGhVHztUwJrdQlFBePoWaNMR,gcjqSkAGhVHztUwJrdQlFBePoWaNKy,gcjqSkAGhVHztUwJrdQlFBePoWaNML,exclusion21=gcjqSkAGhVHztUwJrdQlFBePoWaNEf.get_settings_exclusion21())
  else:
   gcjqSkAGhVHztUwJrdQlFBePoWaNMx={'adult':args.get('adult'),'broadcastid':args.get('broadcastid'),'contenttype':args.get('contenttype'),'genre':args.get('genre'),'uiparent':args.get('uiparent'),'uirank':args.get('uirank'),'uitype':args.get('uitype'),'orderby':gcjqSkAGhVHztUwJrdQlFBePoWaNKy,'ordernm':gcjqSkAGhVHztUwJrdQlFBePoWaNML}
   gcjqSkAGhVHztUwJrdQlFBePoWaNMs=gcjqSkAGhVHztUwJrdQlFBePoWaNEf.WavveObj.GetGenreGroup_sub(gcjqSkAGhVHztUwJrdQlFBePoWaNMx)
  for gcjqSkAGhVHztUwJrdQlFBePoWaNMp in gcjqSkAGhVHztUwJrdQlFBePoWaNMs:
   gcjqSkAGhVHztUwJrdQlFBePoWaNKD =gcjqSkAGhVHztUwJrdQlFBePoWaNMp.get('title')+'  ('+gcjqSkAGhVHztUwJrdQlFBePoWaNML+')'
   gcjqSkAGhVHztUwJrdQlFBePoWaNKb={'mode':gcjqSkAGhVHztUwJrdQlFBePoWaNMb,'uicode':gcjqSkAGhVHztUwJrdQlFBePoWaNMv,'genre':gcjqSkAGhVHztUwJrdQlFBePoWaNMp.get('genre'),'subgenre':gcjqSkAGhVHztUwJrdQlFBePoWaNMp.get('subgenre'),'adult':gcjqSkAGhVHztUwJrdQlFBePoWaNMp.get('adult'),'page':'1','broadcastid':gcjqSkAGhVHztUwJrdQlFBePoWaNMp.get('broadcastid'),'contenttype':gcjqSkAGhVHztUwJrdQlFBePoWaNMp.get('contenttype'),'uiparent':gcjqSkAGhVHztUwJrdQlFBePoWaNMp.get('uiparent'),'uirank':gcjqSkAGhVHztUwJrdQlFBePoWaNMp.get('uirank'),'uitype':gcjqSkAGhVHztUwJrdQlFBePoWaNMp.get('uitype'),'orderby':gcjqSkAGhVHztUwJrdQlFBePoWaNKy,'ordernm':gcjqSkAGhVHztUwJrdQlFBePoWaNML}
   if gcjqSkAGhVHztUwJrdQlFBePoWaNMv=='moviegenre' or gcjqSkAGhVHztUwJrdQlFBePoWaNMv=='moviegenre_svod' or gcjqSkAGhVHztUwJrdQlFBePoWaNMv=='moviegenre_ppv' or gcjqSkAGhVHztUwJrdQlFBePoWaNMp.get('subgenre')!='-':
    gcjqSkAGhVHztUwJrdQlFBePoWaNKb['mode'] ='GENRE_LIST'
   else:
    gcjqSkAGhVHztUwJrdQlFBePoWaNnT
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.add_dir(gcjqSkAGhVHztUwJrdQlFBePoWaNKD,sublabel='',img='',infoLabels=gcjqSkAGhVHztUwJrdQlFBePoWaNnT,isFolder=gcjqSkAGhVHztUwJrdQlFBePoWaNnX,params=gcjqSkAGhVHztUwJrdQlFBePoWaNKb)
  if gcjqSkAGhVHztUwJrdQlFBePoWaNfE(gcjqSkAGhVHztUwJrdQlFBePoWaNMs)>0:xbmcplugin.endOfDirectory(gcjqSkAGhVHztUwJrdQlFBePoWaNEf._addon_handle,cacheToDisc=gcjqSkAGhVHztUwJrdQlFBePoWaNnu)
 def dp_Genre_List(gcjqSkAGhVHztUwJrdQlFBePoWaNEf,args):
  gcjqSkAGhVHztUwJrdQlFBePoWaNEf.WavveObj.SaveCredential(gcjqSkAGhVHztUwJrdQlFBePoWaNEf.get_winCredential())
  gcjqSkAGhVHztUwJrdQlFBePoWaNKT=gcjqSkAGhVHztUwJrdQlFBePoWaNEf.get_settings_addinfo()
  gcjqSkAGhVHztUwJrdQlFBePoWaNMv =args.get('uicode')
  gcjqSkAGhVHztUwJrdQlFBePoWaNKO=gcjqSkAGhVHztUwJrdQlFBePoWaNnO(args.get('page'))
  gcjqSkAGhVHztUwJrdQlFBePoWaNKb={'adult':args.get('adult'),'broadcastid':args.get('broadcastid'),'contenttype':args.get('contenttype'),'genre':args.get('genre'),'subgenre':args.get('subgenre'),'uiparent':args.get('uiparent'),'uirank':args.get('uirank'),'uitype':args.get('uitype'),'orderby':args.get('orderby')}
  if args.get('genre')==args.get('subgenre'):
   gcjqSkAGhVHztUwJrdQlFBePoWaNKb['subgenre']='all'
  gcjqSkAGhVHztUwJrdQlFBePoWaNMs,gcjqSkAGhVHztUwJrdQlFBePoWaNME=gcjqSkAGhVHztUwJrdQlFBePoWaNEf.WavveObj.GetGenreList(gcjqSkAGhVHztUwJrdQlFBePoWaNMv,gcjqSkAGhVHztUwJrdQlFBePoWaNKb,gcjqSkAGhVHztUwJrdQlFBePoWaNKO,addinfoyn=gcjqSkAGhVHztUwJrdQlFBePoWaNKT)
  for gcjqSkAGhVHztUwJrdQlFBePoWaNMp in gcjqSkAGhVHztUwJrdQlFBePoWaNMs:
   gcjqSkAGhVHztUwJrdQlFBePoWaNKD =gcjqSkAGhVHztUwJrdQlFBePoWaNMp.get('title')
   gcjqSkAGhVHztUwJrdQlFBePoWaNMn=gcjqSkAGhVHztUwJrdQlFBePoWaNMp.get('thumbnail')
   gcjqSkAGhVHztUwJrdQlFBePoWaNMf=gcjqSkAGhVHztUwJrdQlFBePoWaNMp.get('info')
   if gcjqSkAGhVHztUwJrdQlFBePoWaNMv=='moviegenre_svod' and gcjqSkAGhVHztUwJrdQlFBePoWaNKT==gcjqSkAGhVHztUwJrdQlFBePoWaNnX:
    gcjqSkAGhVHztUwJrdQlFBePoWaNKD='%s (%s)'%(gcjqSkAGhVHztUwJrdQlFBePoWaNKD,gcjqSkAGhVHztUwJrdQlFBePoWaNfK(gcjqSkAGhVHztUwJrdQlFBePoWaNMf.get('year')))
   else:
    gcjqSkAGhVHztUwJrdQlFBePoWaNMf['plot']=gcjqSkAGhVHztUwJrdQlFBePoWaNKD
   if gcjqSkAGhVHztUwJrdQlFBePoWaNMv=='vodgenre':
    gcjqSkAGhVHztUwJrdQlFBePoWaNMI={'mode':'DEEP_LIST','contentid':gcjqSkAGhVHztUwJrdQlFBePoWaNMp.get('uicode'),'contentidType':'contentid','uicode':'vod','page':'1','title':gcjqSkAGhVHztUwJrdQlFBePoWaNKD,'subtitle':'','thumbnail':gcjqSkAGhVHztUwJrdQlFBePoWaNMn,'viewage':gcjqSkAGhVHztUwJrdQlFBePoWaNMp.get('viewage')}
    gcjqSkAGhVHztUwJrdQlFBePoWaNKv=gcjqSkAGhVHztUwJrdQlFBePoWaNnX
   else:
    gcjqSkAGhVHztUwJrdQlFBePoWaNMI={'mode':'MOVIE','contentid':gcjqSkAGhVHztUwJrdQlFBePoWaNMp.get('uicode'),'contentidType':'contentid','uicode':'movie','page':'1','title':gcjqSkAGhVHztUwJrdQlFBePoWaNKD,'subtitle':'','thumbnail':gcjqSkAGhVHztUwJrdQlFBePoWaNMn,'viewage':gcjqSkAGhVHztUwJrdQlFBePoWaNMp.get('viewage')}
    gcjqSkAGhVHztUwJrdQlFBePoWaNKv=gcjqSkAGhVHztUwJrdQlFBePoWaNnu
   if gcjqSkAGhVHztUwJrdQlFBePoWaNMI.get('viewage')=='21':gcjqSkAGhVHztUwJrdQlFBePoWaNKD+=' (%s)'%(gcjqSkAGhVHztUwJrdQlFBePoWaNMI.get('viewage'))
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.add_dir(gcjqSkAGhVHztUwJrdQlFBePoWaNKD,sublabel='',img=gcjqSkAGhVHztUwJrdQlFBePoWaNMn,infoLabels=gcjqSkAGhVHztUwJrdQlFBePoWaNMf,isFolder=gcjqSkAGhVHztUwJrdQlFBePoWaNKv,params=gcjqSkAGhVHztUwJrdQlFBePoWaNMI)
  if gcjqSkAGhVHztUwJrdQlFBePoWaNME:
   gcjqSkAGhVHztUwJrdQlFBePoWaNKb['mode'] ='GENRE_LIST' 
   gcjqSkAGhVHztUwJrdQlFBePoWaNKb['uicode']=gcjqSkAGhVHztUwJrdQlFBePoWaNMv 
   gcjqSkAGhVHztUwJrdQlFBePoWaNKb['page'] =gcjqSkAGhVHztUwJrdQlFBePoWaNfK(gcjqSkAGhVHztUwJrdQlFBePoWaNKO+1)
   gcjqSkAGhVHztUwJrdQlFBePoWaNKD='[B]%s >>[/B]'%'다음 페이지'
   gcjqSkAGhVHztUwJrdQlFBePoWaNMD=gcjqSkAGhVHztUwJrdQlFBePoWaNfK(gcjqSkAGhVHztUwJrdQlFBePoWaNKO+1)
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.add_dir(gcjqSkAGhVHztUwJrdQlFBePoWaNKD,sublabel=gcjqSkAGhVHztUwJrdQlFBePoWaNMD,img='',infoLabels=gcjqSkAGhVHztUwJrdQlFBePoWaNnT,isFolder=gcjqSkAGhVHztUwJrdQlFBePoWaNnX,params=gcjqSkAGhVHztUwJrdQlFBePoWaNKb)
  if gcjqSkAGhVHztUwJrdQlFBePoWaNfE(gcjqSkAGhVHztUwJrdQlFBePoWaNMs)>0:xbmcplugin.endOfDirectory(gcjqSkAGhVHztUwJrdQlFBePoWaNEf._addon_handle,cacheToDisc=gcjqSkAGhVHztUwJrdQlFBePoWaNnu)
 def dp_Deeplink_List(gcjqSkAGhVHztUwJrdQlFBePoWaNEf,args):
  gcjqSkAGhVHztUwJrdQlFBePoWaNEf.WavveObj.SaveCredential(gcjqSkAGhVHztUwJrdQlFBePoWaNEf.get_winCredential())
  gcjqSkAGhVHztUwJrdQlFBePoWaNKT=gcjqSkAGhVHztUwJrdQlFBePoWaNEf.get_settings_addinfo()
  gcjqSkAGhVHztUwJrdQlFBePoWaNMv =args.get('uicode')
  gcjqSkAGhVHztUwJrdQlFBePoWaNMC =args.get('came')
  gcjqSkAGhVHztUwJrdQlFBePoWaNKO=gcjqSkAGhVHztUwJrdQlFBePoWaNnO(args.get('page'))
  gcjqSkAGhVHztUwJrdQlFBePoWaNMy,gcjqSkAGhVHztUwJrdQlFBePoWaNME=gcjqSkAGhVHztUwJrdQlFBePoWaNEf.WavveObj.GetDeeplinkList(gcjqSkAGhVHztUwJrdQlFBePoWaNMv,gcjqSkAGhVHztUwJrdQlFBePoWaNMC,gcjqSkAGhVHztUwJrdQlFBePoWaNKO,addinfoyn=gcjqSkAGhVHztUwJrdQlFBePoWaNKT)
  for gcjqSkAGhVHztUwJrdQlFBePoWaNMY in gcjqSkAGhVHztUwJrdQlFBePoWaNMy:
   gcjqSkAGhVHztUwJrdQlFBePoWaNKD =gcjqSkAGhVHztUwJrdQlFBePoWaNMY.get('title')
   gcjqSkAGhVHztUwJrdQlFBePoWaNMD =gcjqSkAGhVHztUwJrdQlFBePoWaNMY.get('subtitle')
   gcjqSkAGhVHztUwJrdQlFBePoWaNMn=gcjqSkAGhVHztUwJrdQlFBePoWaNMY.get('thumbnail')
   gcjqSkAGhVHztUwJrdQlFBePoWaNMm=gcjqSkAGhVHztUwJrdQlFBePoWaNMY.get('uicode')
   gcjqSkAGhVHztUwJrdQlFBePoWaNMT=gcjqSkAGhVHztUwJrdQlFBePoWaNMY.get('channelepg')
   gcjqSkAGhVHztUwJrdQlFBePoWaNKb={'uicode':gcjqSkAGhVHztUwJrdQlFBePoWaNMm,'came':gcjqSkAGhVHztUwJrdQlFBePoWaNMC,'contentid':gcjqSkAGhVHztUwJrdQlFBePoWaNMY.get('contentid'),'contentidType':gcjqSkAGhVHztUwJrdQlFBePoWaNMY.get('contentidType'),'page':'1','title':gcjqSkAGhVHztUwJrdQlFBePoWaNKD,'subtitle':gcjqSkAGhVHztUwJrdQlFBePoWaNMD,'thumbnail':gcjqSkAGhVHztUwJrdQlFBePoWaNMn,'viewage':gcjqSkAGhVHztUwJrdQlFBePoWaNMY.get('viewage')}
   if gcjqSkAGhVHztUwJrdQlFBePoWaNMm=='channel':
    gcjqSkAGhVHztUwJrdQlFBePoWaNKb['mode'] ='LIVE'
   elif gcjqSkAGhVHztUwJrdQlFBePoWaNMm=='movie':
    gcjqSkAGhVHztUwJrdQlFBePoWaNKb['mode'] ='MOVIE'
   else:
    gcjqSkAGhVHztUwJrdQlFBePoWaNKb['mode'] ='DEEP_LIST'
   gcjqSkAGhVHztUwJrdQlFBePoWaNMf=gcjqSkAGhVHztUwJrdQlFBePoWaNMY.get('info')
   if gcjqSkAGhVHztUwJrdQlFBePoWaNMT:
    gcjqSkAGhVHztUwJrdQlFBePoWaNMf['plot']='%s\n\n%s'%(gcjqSkAGhVHztUwJrdQlFBePoWaNKD,gcjqSkAGhVHztUwJrdQlFBePoWaNMT)
   elif gcjqSkAGhVHztUwJrdQlFBePoWaNMm=='movie' and gcjqSkAGhVHztUwJrdQlFBePoWaNKT==gcjqSkAGhVHztUwJrdQlFBePoWaNnX:
    gcjqSkAGhVHztUwJrdQlFBePoWaNKD='%s (%s)'%(gcjqSkAGhVHztUwJrdQlFBePoWaNKD,gcjqSkAGhVHztUwJrdQlFBePoWaNfK(gcjqSkAGhVHztUwJrdQlFBePoWaNMf.get('year')))
   else:
    gcjqSkAGhVHztUwJrdQlFBePoWaNMf['plot']='%s\n\n%s'%(gcjqSkAGhVHztUwJrdQlFBePoWaNKD,gcjqSkAGhVHztUwJrdQlFBePoWaNMD)
   if gcjqSkAGhVHztUwJrdQlFBePoWaNMY.get('viewage')=='21':gcjqSkAGhVHztUwJrdQlFBePoWaNMD+=' (%s)'%(gcjqSkAGhVHztUwJrdQlFBePoWaNMY.get('viewage'))
   if gcjqSkAGhVHztUwJrdQlFBePoWaNMm in['channel','movie']:
    gcjqSkAGhVHztUwJrdQlFBePoWaNKv=gcjqSkAGhVHztUwJrdQlFBePoWaNnu
   elif gcjqSkAGhVHztUwJrdQlFBePoWaNKb['contentidType']=='direct':
    gcjqSkAGhVHztUwJrdQlFBePoWaNKv=gcjqSkAGhVHztUwJrdQlFBePoWaNnu
    gcjqSkAGhVHztUwJrdQlFBePoWaNKb['mode']='VOD'
   else:
    gcjqSkAGhVHztUwJrdQlFBePoWaNKv=gcjqSkAGhVHztUwJrdQlFBePoWaNnX
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.add_dir(gcjqSkAGhVHztUwJrdQlFBePoWaNKD,sublabel=gcjqSkAGhVHztUwJrdQlFBePoWaNMD,img=gcjqSkAGhVHztUwJrdQlFBePoWaNMn,infoLabels=gcjqSkAGhVHztUwJrdQlFBePoWaNMf,isFolder=gcjqSkAGhVHztUwJrdQlFBePoWaNKv,params=gcjqSkAGhVHztUwJrdQlFBePoWaNKb)
  if gcjqSkAGhVHztUwJrdQlFBePoWaNME:
   gcjqSkAGhVHztUwJrdQlFBePoWaNKb['mode'] ='GN_LIST' 
   gcjqSkAGhVHztUwJrdQlFBePoWaNKb['uicode']=gcjqSkAGhVHztUwJrdQlFBePoWaNMv 
   gcjqSkAGhVHztUwJrdQlFBePoWaNKb['page'] =gcjqSkAGhVHztUwJrdQlFBePoWaNfK(gcjqSkAGhVHztUwJrdQlFBePoWaNKO+1)
   gcjqSkAGhVHztUwJrdQlFBePoWaNKD='[B]%s >>[/B]'%'다음 페이지'
   gcjqSkAGhVHztUwJrdQlFBePoWaNMD=gcjqSkAGhVHztUwJrdQlFBePoWaNfK(gcjqSkAGhVHztUwJrdQlFBePoWaNKO+1)
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.add_dir(gcjqSkAGhVHztUwJrdQlFBePoWaNKD,sublabel=gcjqSkAGhVHztUwJrdQlFBePoWaNMD,img='',infoLabels=gcjqSkAGhVHztUwJrdQlFBePoWaNnT,isFolder=gcjqSkAGhVHztUwJrdQlFBePoWaNnX,params=gcjqSkAGhVHztUwJrdQlFBePoWaNKb)
  if gcjqSkAGhVHztUwJrdQlFBePoWaNfE(gcjqSkAGhVHztUwJrdQlFBePoWaNMy)>0:xbmcplugin.endOfDirectory(gcjqSkAGhVHztUwJrdQlFBePoWaNEf._addon_handle,cacheToDisc=gcjqSkAGhVHztUwJrdQlFBePoWaNnu)
 def dp_Episodelink_List(gcjqSkAGhVHztUwJrdQlFBePoWaNEf,args):
  gcjqSkAGhVHztUwJrdQlFBePoWaNEf.WavveObj.SaveCredential(gcjqSkAGhVHztUwJrdQlFBePoWaNEf.get_winCredential())
  gcjqSkAGhVHztUwJrdQlFBePoWaNMu =args.get('contentid')
  gcjqSkAGhVHztUwJrdQlFBePoWaNMO=args.get('contentidType')
  gcjqSkAGhVHztUwJrdQlFBePoWaNKu =args.get('uicode')
  gcjqSkAGhVHztUwJrdQlFBePoWaNKO =gcjqSkAGhVHztUwJrdQlFBePoWaNnO(args.get('page'))
  gcjqSkAGhVHztUwJrdQlFBePoWaNMX,gcjqSkAGhVHztUwJrdQlFBePoWaNME=gcjqSkAGhVHztUwJrdQlFBePoWaNEf.WavveObj.GetEpisodeList(gcjqSkAGhVHztUwJrdQlFBePoWaNMu,gcjqSkAGhVHztUwJrdQlFBePoWaNKu,gcjqSkAGhVHztUwJrdQlFBePoWaNMO,gcjqSkAGhVHztUwJrdQlFBePoWaNKO,orderby=gcjqSkAGhVHztUwJrdQlFBePoWaNEf.get_winEpisodeOrderby())
  for gcjqSkAGhVHztUwJrdQlFBePoWaNDE in gcjqSkAGhVHztUwJrdQlFBePoWaNMX:
   gcjqSkAGhVHztUwJrdQlFBePoWaNKD =gcjqSkAGhVHztUwJrdQlFBePoWaNDE.get('title')
   gcjqSkAGhVHztUwJrdQlFBePoWaNMD =gcjqSkAGhVHztUwJrdQlFBePoWaNDE.get('subtitle')
   gcjqSkAGhVHztUwJrdQlFBePoWaNMn=gcjqSkAGhVHztUwJrdQlFBePoWaNDE.get('thumbnail')
   gcjqSkAGhVHztUwJrdQlFBePoWaNKb={'mode':'VOD','uicode':gcjqSkAGhVHztUwJrdQlFBePoWaNDE.get('uicode'),'contentid':gcjqSkAGhVHztUwJrdQlFBePoWaNDE.get('contentid'),'programid':gcjqSkAGhVHztUwJrdQlFBePoWaNDE.get('programid'),'title':gcjqSkAGhVHztUwJrdQlFBePoWaNKD,'subtitle':gcjqSkAGhVHztUwJrdQlFBePoWaNMD,'thumbnail':gcjqSkAGhVHztUwJrdQlFBePoWaNMn,'viewage':gcjqSkAGhVHztUwJrdQlFBePoWaNDE.get('viewage')}
   if gcjqSkAGhVHztUwJrdQlFBePoWaNDE.get('viewage')=='21':gcjqSkAGhVHztUwJrdQlFBePoWaNMD+=' (%s)'%(gcjqSkAGhVHztUwJrdQlFBePoWaNDE.get('viewage'))
   gcjqSkAGhVHztUwJrdQlFBePoWaNDK=gcjqSkAGhVHztUwJrdQlFBePoWaNDE.get('info')
   gcjqSkAGhVHztUwJrdQlFBePoWaNDK['plot']=gcjqSkAGhVHztUwJrdQlFBePoWaNDE.get('synopsis')
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.add_dir(gcjqSkAGhVHztUwJrdQlFBePoWaNKD,sublabel=gcjqSkAGhVHztUwJrdQlFBePoWaNMD,img=gcjqSkAGhVHztUwJrdQlFBePoWaNMn,infoLabels=gcjqSkAGhVHztUwJrdQlFBePoWaNDK,isFolder=gcjqSkAGhVHztUwJrdQlFBePoWaNnu,params=gcjqSkAGhVHztUwJrdQlFBePoWaNKb)
  if gcjqSkAGhVHztUwJrdQlFBePoWaNKO==1:
   gcjqSkAGhVHztUwJrdQlFBePoWaNMf={'plot':'정렬순서를 변경합니다.'}
   gcjqSkAGhVHztUwJrdQlFBePoWaNKb={}
   gcjqSkAGhVHztUwJrdQlFBePoWaNKb['mode'] ='ORDER_BY' 
   if gcjqSkAGhVHztUwJrdQlFBePoWaNEf.get_winEpisodeOrderby()=='desc':
    gcjqSkAGhVHztUwJrdQlFBePoWaNKD='정렬순서변경 : 최신화부터 -> 1회부터'
    gcjqSkAGhVHztUwJrdQlFBePoWaNKb['orderby']='asc'
   else:
    gcjqSkAGhVHztUwJrdQlFBePoWaNKD='정렬순서변경 : 1회부터 -> 최신화부터'
    gcjqSkAGhVHztUwJrdQlFBePoWaNKb['orderby']='desc'
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.add_dir(gcjqSkAGhVHztUwJrdQlFBePoWaNKD,sublabel='',img='',infoLabels=gcjqSkAGhVHztUwJrdQlFBePoWaNMf,isFolder=gcjqSkAGhVHztUwJrdQlFBePoWaNnu,params=gcjqSkAGhVHztUwJrdQlFBePoWaNKb)
  if gcjqSkAGhVHztUwJrdQlFBePoWaNME:
   gcjqSkAGhVHztUwJrdQlFBePoWaNKb['mode'] ='DEEP_LIST' 
   gcjqSkAGhVHztUwJrdQlFBePoWaNKb['uicode'] =gcjqSkAGhVHztUwJrdQlFBePoWaNKu 
   gcjqSkAGhVHztUwJrdQlFBePoWaNKb['contentid'] =gcjqSkAGhVHztUwJrdQlFBePoWaNMu 
   gcjqSkAGhVHztUwJrdQlFBePoWaNKb['contentidType']=gcjqSkAGhVHztUwJrdQlFBePoWaNMO 
   gcjqSkAGhVHztUwJrdQlFBePoWaNKb['page'] =gcjqSkAGhVHztUwJrdQlFBePoWaNfK(gcjqSkAGhVHztUwJrdQlFBePoWaNKO+1)
   gcjqSkAGhVHztUwJrdQlFBePoWaNKD='[B]%s >>[/B]'%'다음 페이지'
   gcjqSkAGhVHztUwJrdQlFBePoWaNMD=gcjqSkAGhVHztUwJrdQlFBePoWaNfK(gcjqSkAGhVHztUwJrdQlFBePoWaNKO+1)
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.add_dir(gcjqSkAGhVHztUwJrdQlFBePoWaNKD,sublabel=gcjqSkAGhVHztUwJrdQlFBePoWaNMD,img='',infoLabels=gcjqSkAGhVHztUwJrdQlFBePoWaNnT,isFolder=gcjqSkAGhVHztUwJrdQlFBePoWaNnX,params=gcjqSkAGhVHztUwJrdQlFBePoWaNKb)
  if gcjqSkAGhVHztUwJrdQlFBePoWaNfE(gcjqSkAGhVHztUwJrdQlFBePoWaNMX)>0:xbmcplugin.endOfDirectory(gcjqSkAGhVHztUwJrdQlFBePoWaNEf._addon_handle,cacheToDisc=gcjqSkAGhVHztUwJrdQlFBePoWaNnX)
 def play_VIDEO(gcjqSkAGhVHztUwJrdQlFBePoWaNEf,args):
  gcjqSkAGhVHztUwJrdQlFBePoWaNEf.WavveObj.SaveCredential(gcjqSkAGhVHztUwJrdQlFBePoWaNEf.get_winCredential())
  gcjqSkAGhVHztUwJrdQlFBePoWaNMu =args.get('contentid')
  gcjqSkAGhVHztUwJrdQlFBePoWaNKu=args.get('uicode')
  gcjqSkAGhVHztUwJrdQlFBePoWaNDM=gcjqSkAGhVHztUwJrdQlFBePoWaNEf.get_selQuality()
  gcjqSkAGhVHztUwJrdQlFBePoWaNEf.addon_log(gcjqSkAGhVHztUwJrdQlFBePoWaNMu+' - '+gcjqSkAGhVHztUwJrdQlFBePoWaNKu,gcjqSkAGhVHztUwJrdQlFBePoWaNnu)
  gcjqSkAGhVHztUwJrdQlFBePoWaNDn,gcjqSkAGhVHztUwJrdQlFBePoWaNDf,gcjqSkAGhVHztUwJrdQlFBePoWaNDb,gcjqSkAGhVHztUwJrdQlFBePoWaNDv=gcjqSkAGhVHztUwJrdQlFBePoWaNEf.WavveObj.GetStreamingURL(gcjqSkAGhVHztUwJrdQlFBePoWaNMu,gcjqSkAGhVHztUwJrdQlFBePoWaNKu,gcjqSkAGhVHztUwJrdQlFBePoWaNDM)
  gcjqSkAGhVHztUwJrdQlFBePoWaNDR='%s|Cookie=%s'%(gcjqSkAGhVHztUwJrdQlFBePoWaNDn,gcjqSkAGhVHztUwJrdQlFBePoWaNDf)
  gcjqSkAGhVHztUwJrdQlFBePoWaNEf.addon_log(gcjqSkAGhVHztUwJrdQlFBePoWaNDR,gcjqSkAGhVHztUwJrdQlFBePoWaNnu)
  if gcjqSkAGhVHztUwJrdQlFBePoWaNDn=='':
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.addon_noti(__language__(30907).encode('utf8'))
   return
  gcjqSkAGhVHztUwJrdQlFBePoWaNDi=xbmcgui.ListItem(path=gcjqSkAGhVHztUwJrdQlFBePoWaNDR)
  if gcjqSkAGhVHztUwJrdQlFBePoWaNDb:
   gcjqSkAGhVHztUwJrdQlFBePoWaNDL=gcjqSkAGhVHztUwJrdQlFBePoWaNDb['customdata']
   gcjqSkAGhVHztUwJrdQlFBePoWaNDs =gcjqSkAGhVHztUwJrdQlFBePoWaNDb['drmhost']
   gcjqSkAGhVHztUwJrdQlFBePoWaNDx =inputstreamhelper.Helper('mpd',drm='widevine')
   if gcjqSkAGhVHztUwJrdQlFBePoWaNDx.check_inputstream():
    if gcjqSkAGhVHztUwJrdQlFBePoWaNKu=='movie':
     gcjqSkAGhVHztUwJrdQlFBePoWaNDp='https://www.wavve.com/player/movie?movieid=%s'%gcjqSkAGhVHztUwJrdQlFBePoWaNMu
    else:
     gcjqSkAGhVHztUwJrdQlFBePoWaNDp='https://www.wavve.com/player/vod?programid=%s&page=1'%gcjqSkAGhVHztUwJrdQlFBePoWaNMu
    gcjqSkAGhVHztUwJrdQlFBePoWaNDI={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':gcjqSkAGhVHztUwJrdQlFBePoWaNDL,'referer':gcjqSkAGhVHztUwJrdQlFBePoWaNDp,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':gcjqSkAGhVHztUwJrdQlFBePoWaNED}
    gcjqSkAGhVHztUwJrdQlFBePoWaNDC=gcjqSkAGhVHztUwJrdQlFBePoWaNDs+'|'+urllib.parse.urlencode(gcjqSkAGhVHztUwJrdQlFBePoWaNDI)+'|R{SSM}|'
    gcjqSkAGhVHztUwJrdQlFBePoWaNDi.setProperty('inputstream',gcjqSkAGhVHztUwJrdQlFBePoWaNDx.inputstream_addon)
    gcjqSkAGhVHztUwJrdQlFBePoWaNDi.setProperty('inputstream.adaptive.manifest_type','mpd')
    gcjqSkAGhVHztUwJrdQlFBePoWaNDi.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    gcjqSkAGhVHztUwJrdQlFBePoWaNDi.setProperty('inputstream.adaptive.license_key',gcjqSkAGhVHztUwJrdQlFBePoWaNDC)
    gcjqSkAGhVHztUwJrdQlFBePoWaNDi.setProperty('inputstream.adaptive.stream_headers','user-agent=%s&Cookie=%s'%(gcjqSkAGhVHztUwJrdQlFBePoWaNED,gcjqSkAGhVHztUwJrdQlFBePoWaNDf))
  xbmcplugin.setResolvedUrl(gcjqSkAGhVHztUwJrdQlFBePoWaNEf._addon_handle,gcjqSkAGhVHztUwJrdQlFBePoWaNnX,gcjqSkAGhVHztUwJrdQlFBePoWaNDi)
  if gcjqSkAGhVHztUwJrdQlFBePoWaNDv:
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.addon_noti(gcjqSkAGhVHztUwJrdQlFBePoWaNDv.encode('utf-8'))
  else:
   if '/preview.' in urllib.parse.urlsplit(gcjqSkAGhVHztUwJrdQlFBePoWaNDn).path:gcjqSkAGhVHztUwJrdQlFBePoWaNEf.addon_noti(__language__(30908).encode('utf8'))
  try:
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('viewage')!='21':
    gcjqSkAGhVHztUwJrdQlFBePoWaNKb={'code':args.get('programid')if args.get('mode')=='VOD' else args.get('contentid'),'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    gcjqSkAGhVHztUwJrdQlFBePoWaNEf.Save_Watched_List(args.get('mode').lower(),gcjqSkAGhVHztUwJrdQlFBePoWaNKb)
  except:
   gcjqSkAGhVHztUwJrdQlFBePoWaNnT
 def dp_Watch_List(gcjqSkAGhVHztUwJrdQlFBePoWaNEf,args):
  gcjqSkAGhVHztUwJrdQlFBePoWaNMR =args.get('genre')
  gcjqSkAGhVHztUwJrdQlFBePoWaNEu=gcjqSkAGhVHztUwJrdQlFBePoWaNEf.get_settings_direct_replay()
  if gcjqSkAGhVHztUwJrdQlFBePoWaNMR=='-':
   gcjqSkAGhVHztUwJrdQlFBePoWaNKD='VOD 시청내역'
   gcjqSkAGhVHztUwJrdQlFBePoWaNKb={'mode':'WATCH','genre':'vod'}
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.add_dir(gcjqSkAGhVHztUwJrdQlFBePoWaNKD,sublabel='',img='',infoLabels=gcjqSkAGhVHztUwJrdQlFBePoWaNnT,isFolder=gcjqSkAGhVHztUwJrdQlFBePoWaNnX,params=gcjqSkAGhVHztUwJrdQlFBePoWaNKb)
   gcjqSkAGhVHztUwJrdQlFBePoWaNKD='영화 시청내역'
   gcjqSkAGhVHztUwJrdQlFBePoWaNKb['genre']='movie'
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.add_dir(gcjqSkAGhVHztUwJrdQlFBePoWaNKD,sublabel='',img='',infoLabels=gcjqSkAGhVHztUwJrdQlFBePoWaNnT,isFolder=gcjqSkAGhVHztUwJrdQlFBePoWaNnX,params=gcjqSkAGhVHztUwJrdQlFBePoWaNKb)
   xbmcplugin.endOfDirectory(gcjqSkAGhVHztUwJrdQlFBePoWaNEf._addon_handle)
  else:
   gcjqSkAGhVHztUwJrdQlFBePoWaNDy=gcjqSkAGhVHztUwJrdQlFBePoWaNEf.Load_Watched_List(gcjqSkAGhVHztUwJrdQlFBePoWaNMR)
   for gcjqSkAGhVHztUwJrdQlFBePoWaNDY in gcjqSkAGhVHztUwJrdQlFBePoWaNDy:
    gcjqSkAGhVHztUwJrdQlFBePoWaNDm=gcjqSkAGhVHztUwJrdQlFBePoWaNfM(urllib.parse.parse_qsl(gcjqSkAGhVHztUwJrdQlFBePoWaNDY))
    gcjqSkAGhVHztUwJrdQlFBePoWaNKD =gcjqSkAGhVHztUwJrdQlFBePoWaNDm.get('title').strip()
    gcjqSkAGhVHztUwJrdQlFBePoWaNMD =gcjqSkAGhVHztUwJrdQlFBePoWaNDm.get('subtitle').strip()
    if gcjqSkAGhVHztUwJrdQlFBePoWaNMD=='None':gcjqSkAGhVHztUwJrdQlFBePoWaNMD=''
    gcjqSkAGhVHztUwJrdQlFBePoWaNMn=gcjqSkAGhVHztUwJrdQlFBePoWaNDm.get('img')
    gcjqSkAGhVHztUwJrdQlFBePoWaNDT =gcjqSkAGhVHztUwJrdQlFBePoWaNDm.get('videoid')
    gcjqSkAGhVHztUwJrdQlFBePoWaNMf={}
    if gcjqSkAGhVHztUwJrdQlFBePoWaNMR=='movie' and gcjqSkAGhVHztUwJrdQlFBePoWaNEf.get_settings_addinfo()==gcjqSkAGhVHztUwJrdQlFBePoWaNnX:
     gcjqSkAGhVHztUwJrdQlFBePoWaNDu=gcjqSkAGhVHztUwJrdQlFBePoWaNEf.WavveObj.GetMovieInfoList([gcjqSkAGhVHztUwJrdQlFBePoWaNDm.get('code')])
     gcjqSkAGhVHztUwJrdQlFBePoWaNMf=gcjqSkAGhVHztUwJrdQlFBePoWaNDu.get(gcjqSkAGhVHztUwJrdQlFBePoWaNDm.get('code'))
    else:
     gcjqSkAGhVHztUwJrdQlFBePoWaNMf['plot']='%s\n%s'%(gcjqSkAGhVHztUwJrdQlFBePoWaNKD,gcjqSkAGhVHztUwJrdQlFBePoWaNMD)
    if gcjqSkAGhVHztUwJrdQlFBePoWaNMR=='vod':
     if gcjqSkAGhVHztUwJrdQlFBePoWaNEu==gcjqSkAGhVHztUwJrdQlFBePoWaNnu or gcjqSkAGhVHztUwJrdQlFBePoWaNDT==gcjqSkAGhVHztUwJrdQlFBePoWaNnT:
      gcjqSkAGhVHztUwJrdQlFBePoWaNKb={'mode':'DEEP_LIST','contentid':gcjqSkAGhVHztUwJrdQlFBePoWaNDm.get('code'),'contentidType':'programid','uicode':'vod','page':'1'}
      gcjqSkAGhVHztUwJrdQlFBePoWaNKv=gcjqSkAGhVHztUwJrdQlFBePoWaNnX
     else:
      gcjqSkAGhVHztUwJrdQlFBePoWaNKb={'mode':'VOD','contentid':gcjqSkAGhVHztUwJrdQlFBePoWaNDT,'contentidType':'contentid','programid':gcjqSkAGhVHztUwJrdQlFBePoWaNDm.get('code'),'uicode':'vod','title':gcjqSkAGhVHztUwJrdQlFBePoWaNKD,'subtitle':gcjqSkAGhVHztUwJrdQlFBePoWaNMD,'thumbnail':gcjqSkAGhVHztUwJrdQlFBePoWaNMn}
      gcjqSkAGhVHztUwJrdQlFBePoWaNKv=gcjqSkAGhVHztUwJrdQlFBePoWaNnu
    else:
     gcjqSkAGhVHztUwJrdQlFBePoWaNKb={'mode':'MOVIE','contentid':gcjqSkAGhVHztUwJrdQlFBePoWaNDm.get('code'),'contentidType':'contentid','uicode':'movie','title':gcjqSkAGhVHztUwJrdQlFBePoWaNKD,'thumbnail':gcjqSkAGhVHztUwJrdQlFBePoWaNMn}
     gcjqSkAGhVHztUwJrdQlFBePoWaNKv=gcjqSkAGhVHztUwJrdQlFBePoWaNnu
    gcjqSkAGhVHztUwJrdQlFBePoWaNEf.add_dir(gcjqSkAGhVHztUwJrdQlFBePoWaNKD,sublabel=gcjqSkAGhVHztUwJrdQlFBePoWaNMD,img=gcjqSkAGhVHztUwJrdQlFBePoWaNMn,infoLabels=gcjqSkAGhVHztUwJrdQlFBePoWaNMf,isFolder=gcjqSkAGhVHztUwJrdQlFBePoWaNKv,params=gcjqSkAGhVHztUwJrdQlFBePoWaNKb)
   gcjqSkAGhVHztUwJrdQlFBePoWaNMf={'plot':'시청목록을 삭제합니다.'}
   gcjqSkAGhVHztUwJrdQlFBePoWaNKD='*** 시청목록 삭제 ***'
   gcjqSkAGhVHztUwJrdQlFBePoWaNKb={'mode':'MYVIEW_REMOVE','genre':gcjqSkAGhVHztUwJrdQlFBePoWaNMR}
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.add_dir(gcjqSkAGhVHztUwJrdQlFBePoWaNKD,sublabel='',img='',infoLabels=gcjqSkAGhVHztUwJrdQlFBePoWaNMf,isFolder=gcjqSkAGhVHztUwJrdQlFBePoWaNnu,params=gcjqSkAGhVHztUwJrdQlFBePoWaNKb)
   xbmcplugin.endOfDirectory(gcjqSkAGhVHztUwJrdQlFBePoWaNEf._addon_handle,cacheToDisc=gcjqSkAGhVHztUwJrdQlFBePoWaNnu)
 def dp_Search_Group(gcjqSkAGhVHztUwJrdQlFBePoWaNEf,args):
  gcjqSkAGhVHztUwJrdQlFBePoWaNKD='VOD 검색'
  gcjqSkAGhVHztUwJrdQlFBePoWaNKb={'mode':'SEARCH_LIST','genre':'vod','page':'1'}
  gcjqSkAGhVHztUwJrdQlFBePoWaNEf.add_dir(gcjqSkAGhVHztUwJrdQlFBePoWaNKD,sublabel='',img='',infoLabels=gcjqSkAGhVHztUwJrdQlFBePoWaNnT,isFolder=gcjqSkAGhVHztUwJrdQlFBePoWaNnX,params=gcjqSkAGhVHztUwJrdQlFBePoWaNKb)
  gcjqSkAGhVHztUwJrdQlFBePoWaNKD='영화 검색'
  gcjqSkAGhVHztUwJrdQlFBePoWaNKb['genre']='movie'
  gcjqSkAGhVHztUwJrdQlFBePoWaNEf.add_dir(gcjqSkAGhVHztUwJrdQlFBePoWaNKD,sublabel='',img='',infoLabels=gcjqSkAGhVHztUwJrdQlFBePoWaNnT,isFolder=gcjqSkAGhVHztUwJrdQlFBePoWaNnX,params=gcjqSkAGhVHztUwJrdQlFBePoWaNKb)
  xbmcplugin.endOfDirectory(gcjqSkAGhVHztUwJrdQlFBePoWaNEf._addon_handle)
 def dp_Search_List(gcjqSkAGhVHztUwJrdQlFBePoWaNEf,args):
  gcjqSkAGhVHztUwJrdQlFBePoWaNEf.WavveObj.SaveCredential(gcjqSkAGhVHztUwJrdQlFBePoWaNEf.get_winCredential())
  gcjqSkAGhVHztUwJrdQlFBePoWaNKT=gcjqSkAGhVHztUwJrdQlFBePoWaNEf.get_settings_addinfo()
  gcjqSkAGhVHztUwJrdQlFBePoWaNKu=args.get('genre')
  gcjqSkAGhVHztUwJrdQlFBePoWaNKO =gcjqSkAGhVHztUwJrdQlFBePoWaNnO(args.get('page'))
  if 'search_key' in args:
   gcjqSkAGhVHztUwJrdQlFBePoWaNDX=args.get('search_key')
  else:
   gcjqSkAGhVHztUwJrdQlFBePoWaNDX=gcjqSkAGhVHztUwJrdQlFBePoWaNEf.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not gcjqSkAGhVHztUwJrdQlFBePoWaNDX:return
  gcjqSkAGhVHztUwJrdQlFBePoWaNnE,gcjqSkAGhVHztUwJrdQlFBePoWaNME=gcjqSkAGhVHztUwJrdQlFBePoWaNEf.WavveObj.GetSearchList(gcjqSkAGhVHztUwJrdQlFBePoWaNDX,gcjqSkAGhVHztUwJrdQlFBePoWaNKu,gcjqSkAGhVHztUwJrdQlFBePoWaNKO,exclusion21=gcjqSkAGhVHztUwJrdQlFBePoWaNEf.get_settings_exclusion21(),addinfoyn=gcjqSkAGhVHztUwJrdQlFBePoWaNKT)
  for gcjqSkAGhVHztUwJrdQlFBePoWaNnK in gcjqSkAGhVHztUwJrdQlFBePoWaNnE:
   gcjqSkAGhVHztUwJrdQlFBePoWaNKD =gcjqSkAGhVHztUwJrdQlFBePoWaNnK.get('title')
   gcjqSkAGhVHztUwJrdQlFBePoWaNMn=gcjqSkAGhVHztUwJrdQlFBePoWaNnK.get('thumbnail')
   gcjqSkAGhVHztUwJrdQlFBePoWaNMf=gcjqSkAGhVHztUwJrdQlFBePoWaNnK.get('info')
   if gcjqSkAGhVHztUwJrdQlFBePoWaNKu=='movie' and gcjqSkAGhVHztUwJrdQlFBePoWaNKT==gcjqSkAGhVHztUwJrdQlFBePoWaNnX:
    gcjqSkAGhVHztUwJrdQlFBePoWaNKD='%s (%s)'%(gcjqSkAGhVHztUwJrdQlFBePoWaNKD,gcjqSkAGhVHztUwJrdQlFBePoWaNfK(gcjqSkAGhVHztUwJrdQlFBePoWaNMf.get('year')))
   else:
    gcjqSkAGhVHztUwJrdQlFBePoWaNMf['plot']=gcjqSkAGhVHztUwJrdQlFBePoWaNKD
   if gcjqSkAGhVHztUwJrdQlFBePoWaNKu=='vod':
    gcjqSkAGhVHztUwJrdQlFBePoWaNKb={'mode':'DEEP_LIST','contentid':gcjqSkAGhVHztUwJrdQlFBePoWaNnK.get('programid'),'contentidType':'programid','uicode':'vod','page':'1','title':gcjqSkAGhVHztUwJrdQlFBePoWaNKD,'subtitle':'','thumbnail':gcjqSkAGhVHztUwJrdQlFBePoWaNMn,'viewage':gcjqSkAGhVHztUwJrdQlFBePoWaNnK.get('viewage')}
    gcjqSkAGhVHztUwJrdQlFBePoWaNKv=gcjqSkAGhVHztUwJrdQlFBePoWaNnX
   else:
    gcjqSkAGhVHztUwJrdQlFBePoWaNKb={'mode':'MOVIE','contentid':gcjqSkAGhVHztUwJrdQlFBePoWaNnK.get('contentid'),'contentidType':'contentid','uicode':'movie','page':'1','title':gcjqSkAGhVHztUwJrdQlFBePoWaNKD,'subtitle':'','thumbnail':gcjqSkAGhVHztUwJrdQlFBePoWaNMn,'viewage':gcjqSkAGhVHztUwJrdQlFBePoWaNnK.get('viewage')}
    gcjqSkAGhVHztUwJrdQlFBePoWaNKv=gcjqSkAGhVHztUwJrdQlFBePoWaNnu
   if gcjqSkAGhVHztUwJrdQlFBePoWaNKb.get('viewage')=='21':gcjqSkAGhVHztUwJrdQlFBePoWaNKD+=' (%s)'%(gcjqSkAGhVHztUwJrdQlFBePoWaNKb.get('viewage'))
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.add_dir(gcjqSkAGhVHztUwJrdQlFBePoWaNKD,sublabel='',img=gcjqSkAGhVHztUwJrdQlFBePoWaNMn,infoLabels=gcjqSkAGhVHztUwJrdQlFBePoWaNMf,isFolder=gcjqSkAGhVHztUwJrdQlFBePoWaNKv,params=gcjqSkAGhVHztUwJrdQlFBePoWaNKb)
  if gcjqSkAGhVHztUwJrdQlFBePoWaNME:
   gcjqSkAGhVHztUwJrdQlFBePoWaNKb['mode'] ='SEARCH_LIST' 
   gcjqSkAGhVHztUwJrdQlFBePoWaNKb['genre']=gcjqSkAGhVHztUwJrdQlFBePoWaNKu 
   gcjqSkAGhVHztUwJrdQlFBePoWaNKb['page'] =gcjqSkAGhVHztUwJrdQlFBePoWaNfK(gcjqSkAGhVHztUwJrdQlFBePoWaNKO+1)
   gcjqSkAGhVHztUwJrdQlFBePoWaNKb['search_key']=gcjqSkAGhVHztUwJrdQlFBePoWaNDX
   gcjqSkAGhVHztUwJrdQlFBePoWaNKD='[B]%s >>[/B]'%'다음 페이지'
   gcjqSkAGhVHztUwJrdQlFBePoWaNMD=gcjqSkAGhVHztUwJrdQlFBePoWaNfK(gcjqSkAGhVHztUwJrdQlFBePoWaNKO+1)
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.add_dir(gcjqSkAGhVHztUwJrdQlFBePoWaNKD,sublabel=gcjqSkAGhVHztUwJrdQlFBePoWaNMD,img='',infoLabels=gcjqSkAGhVHztUwJrdQlFBePoWaNnT,isFolder=gcjqSkAGhVHztUwJrdQlFBePoWaNnX,params=gcjqSkAGhVHztUwJrdQlFBePoWaNKb)
  if gcjqSkAGhVHztUwJrdQlFBePoWaNfE(gcjqSkAGhVHztUwJrdQlFBePoWaNnE)>0:xbmcplugin.endOfDirectory(gcjqSkAGhVHztUwJrdQlFBePoWaNEf._addon_handle)
 def Load_Watched_List(gcjqSkAGhVHztUwJrdQlFBePoWaNEf,gcjqSkAGhVHztUwJrdQlFBePoWaNMR):
  try:
   gcjqSkAGhVHztUwJrdQlFBePoWaNnM=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%gcjqSkAGhVHztUwJrdQlFBePoWaNMR))
   with gcjqSkAGhVHztUwJrdQlFBePoWaNfD(gcjqSkAGhVHztUwJrdQlFBePoWaNnM,'r',-1,'utf-8')as fp:
    gcjqSkAGhVHztUwJrdQlFBePoWaNnD=fp.readlines()
  except:
   gcjqSkAGhVHztUwJrdQlFBePoWaNnD=[]
  return gcjqSkAGhVHztUwJrdQlFBePoWaNnD
 def Save_Watched_List(gcjqSkAGhVHztUwJrdQlFBePoWaNEf,gcjqSkAGhVHztUwJrdQlFBePoWaNMR,gcjqSkAGhVHztUwJrdQlFBePoWaNER):
  try:
   gcjqSkAGhVHztUwJrdQlFBePoWaNnM=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%gcjqSkAGhVHztUwJrdQlFBePoWaNMR))
   gcjqSkAGhVHztUwJrdQlFBePoWaNnf=gcjqSkAGhVHztUwJrdQlFBePoWaNEf.Load_Watched_List(gcjqSkAGhVHztUwJrdQlFBePoWaNMR) 
   with gcjqSkAGhVHztUwJrdQlFBePoWaNfD(gcjqSkAGhVHztUwJrdQlFBePoWaNnM,'w',-1,'utf-8')as fp:
    gcjqSkAGhVHztUwJrdQlFBePoWaNnb=urllib.parse.urlencode(gcjqSkAGhVHztUwJrdQlFBePoWaNER)
    gcjqSkAGhVHztUwJrdQlFBePoWaNnb=gcjqSkAGhVHztUwJrdQlFBePoWaNnb+'\n'
    fp.write(gcjqSkAGhVHztUwJrdQlFBePoWaNnb)
    gcjqSkAGhVHztUwJrdQlFBePoWaNnv=0
    for gcjqSkAGhVHztUwJrdQlFBePoWaNnR in gcjqSkAGhVHztUwJrdQlFBePoWaNnf:
     gcjqSkAGhVHztUwJrdQlFBePoWaNni=gcjqSkAGhVHztUwJrdQlFBePoWaNfM(urllib.parse.parse_qsl(gcjqSkAGhVHztUwJrdQlFBePoWaNnR))
     gcjqSkAGhVHztUwJrdQlFBePoWaNnL=gcjqSkAGhVHztUwJrdQlFBePoWaNER.get('code')
     gcjqSkAGhVHztUwJrdQlFBePoWaNns=gcjqSkAGhVHztUwJrdQlFBePoWaNni.get('code')
     if gcjqSkAGhVHztUwJrdQlFBePoWaNMR=='vod' and gcjqSkAGhVHztUwJrdQlFBePoWaNEf.get_settings_direct_replay()==gcjqSkAGhVHztUwJrdQlFBePoWaNnX:
      gcjqSkAGhVHztUwJrdQlFBePoWaNnL=gcjqSkAGhVHztUwJrdQlFBePoWaNER.get('videoid')
      gcjqSkAGhVHztUwJrdQlFBePoWaNns=gcjqSkAGhVHztUwJrdQlFBePoWaNni.get('videoid')if gcjqSkAGhVHztUwJrdQlFBePoWaNns!=gcjqSkAGhVHztUwJrdQlFBePoWaNnT else '-'
     if gcjqSkAGhVHztUwJrdQlFBePoWaNnL!=gcjqSkAGhVHztUwJrdQlFBePoWaNns:
      fp.write(gcjqSkAGhVHztUwJrdQlFBePoWaNnR)
      gcjqSkAGhVHztUwJrdQlFBePoWaNnv+=1
      if gcjqSkAGhVHztUwJrdQlFBePoWaNnv>=50:break
  except:
   gcjqSkAGhVHztUwJrdQlFBePoWaNnT
 def Delete_Watched_List(gcjqSkAGhVHztUwJrdQlFBePoWaNEf,gcjqSkAGhVHztUwJrdQlFBePoWaNMR):
  try:
   gcjqSkAGhVHztUwJrdQlFBePoWaNnM=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%gcjqSkAGhVHztUwJrdQlFBePoWaNMR))
   with gcjqSkAGhVHztUwJrdQlFBePoWaNfD(gcjqSkAGhVHztUwJrdQlFBePoWaNnM,'w',-1,'utf-8')as fp:
    fp.write('')
  except:
   gcjqSkAGhVHztUwJrdQlFBePoWaNnT
 def dp_WatchList_Delete(gcjqSkAGhVHztUwJrdQlFBePoWaNEf,args):
  gcjqSkAGhVHztUwJrdQlFBePoWaNMR=args.get('genre')
  gcjqSkAGhVHztUwJrdQlFBePoWaNEL=xbmcgui.Dialog()
  gcjqSkAGhVHztUwJrdQlFBePoWaNKx=gcjqSkAGhVHztUwJrdQlFBePoWaNEL.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if gcjqSkAGhVHztUwJrdQlFBePoWaNKx==gcjqSkAGhVHztUwJrdQlFBePoWaNnu:sys.exit()
  gcjqSkAGhVHztUwJrdQlFBePoWaNEf.Delete_Watched_List(gcjqSkAGhVHztUwJrdQlFBePoWaNMR)
  xbmc.executebuiltin("Container.Refresh")
 def logout(gcjqSkAGhVHztUwJrdQlFBePoWaNEf):
  gcjqSkAGhVHztUwJrdQlFBePoWaNEL=xbmcgui.Dialog()
  gcjqSkAGhVHztUwJrdQlFBePoWaNKx=gcjqSkAGhVHztUwJrdQlFBePoWaNEL.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if gcjqSkAGhVHztUwJrdQlFBePoWaNKx==gcjqSkAGhVHztUwJrdQlFBePoWaNnu:sys.exit()
  gcjqSkAGhVHztUwJrdQlFBePoWaNEf.wininfo_clear()
  if os.path.isfile(gcjqSkAGhVHztUwJrdQlFBePoWaNEn):os.remove(gcjqSkAGhVHztUwJrdQlFBePoWaNEn)
  gcjqSkAGhVHztUwJrdQlFBePoWaNEf.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(gcjqSkAGhVHztUwJrdQlFBePoWaNEf):
  gcjqSkAGhVHztUwJrdQlFBePoWaNKE=xbmcgui.Window(10000)
  gcjqSkAGhVHztUwJrdQlFBePoWaNKE.setProperty('WAVVE_M_CREDENTIAL','')
  gcjqSkAGhVHztUwJrdQlFBePoWaNKE.setProperty('WAVVE_M_LOGINTIME','')
 def cookiefile_save(gcjqSkAGhVHztUwJrdQlFBePoWaNEf):
  gcjqSkAGhVHztUwJrdQlFBePoWaNnx =gcjqSkAGhVHztUwJrdQlFBePoWaNEf.WavveObj.Get_Now_Datetime()
  gcjqSkAGhVHztUwJrdQlFBePoWaNnp=gcjqSkAGhVHztUwJrdQlFBePoWaNnx+datetime.timedelta(days=gcjqSkAGhVHztUwJrdQlFBePoWaNnO(__addon__.getSetting('cache_ttl')))
  gcjqSkAGhVHztUwJrdQlFBePoWaNKE=xbmcgui.Window(10000)
  gcjqSkAGhVHztUwJrdQlFBePoWaNnI={'wavve_token':gcjqSkAGhVHztUwJrdQlFBePoWaNKE.getProperty('WAVVE_M_CREDENTIAL'),'wavve_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'wavve_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'wavve_profile':__addon__.getSetting('selected_profile'),'wavve_limitdate':gcjqSkAGhVHztUwJrdQlFBePoWaNnp.strftime('%Y-%m-%d')}
  try: 
   with gcjqSkAGhVHztUwJrdQlFBePoWaNfD(gcjqSkAGhVHztUwJrdQlFBePoWaNEn,'w',-1,'utf-8')as fp:
    gcjqSkAGhVHztUwJrdQlFBePoWaNnC.dump(gcjqSkAGhVHztUwJrdQlFBePoWaNnI,fp)
  except gcjqSkAGhVHztUwJrdQlFBePoWaNfn as exception:
   gcjqSkAGhVHztUwJrdQlFBePoWaNfb(exception)
 def cookiefile_check(gcjqSkAGhVHztUwJrdQlFBePoWaNEf):
  gcjqSkAGhVHztUwJrdQlFBePoWaNnI={}
  try: 
   with gcjqSkAGhVHztUwJrdQlFBePoWaNfD(gcjqSkAGhVHztUwJrdQlFBePoWaNEn,'r',-1,'utf-8')as fp:
    gcjqSkAGhVHztUwJrdQlFBePoWaNnI= gcjqSkAGhVHztUwJrdQlFBePoWaNnC.load(fp)
  except gcjqSkAGhVHztUwJrdQlFBePoWaNfn as exception:
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.wininfo_clear()
   return gcjqSkAGhVHztUwJrdQlFBePoWaNnu
  gcjqSkAGhVHztUwJrdQlFBePoWaNKi =__addon__.getSetting('id')
  gcjqSkAGhVHztUwJrdQlFBePoWaNKL =__addon__.getSetting('pw')
  gcjqSkAGhVHztUwJrdQlFBePoWaNny =__addon__.getSetting('selected_profile')
  gcjqSkAGhVHztUwJrdQlFBePoWaNnI['wavve_id']=base64.standard_b64decode(gcjqSkAGhVHztUwJrdQlFBePoWaNnI['wavve_id']).decode('utf-8')
  gcjqSkAGhVHztUwJrdQlFBePoWaNnI['wavve_pw']=base64.standard_b64decode(gcjqSkAGhVHztUwJrdQlFBePoWaNnI['wavve_pw']).decode('utf-8')
  if gcjqSkAGhVHztUwJrdQlFBePoWaNKi!=gcjqSkAGhVHztUwJrdQlFBePoWaNnI['wavve_id']or gcjqSkAGhVHztUwJrdQlFBePoWaNKL!=gcjqSkAGhVHztUwJrdQlFBePoWaNnI['wavve_pw']or gcjqSkAGhVHztUwJrdQlFBePoWaNny!=gcjqSkAGhVHztUwJrdQlFBePoWaNnI['wavve_profile']:
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.wininfo_clear()
   return gcjqSkAGhVHztUwJrdQlFBePoWaNnu
  gcjqSkAGhVHztUwJrdQlFBePoWaNKp =gcjqSkAGhVHztUwJrdQlFBePoWaNnO(gcjqSkAGhVHztUwJrdQlFBePoWaNEf.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  gcjqSkAGhVHztUwJrdQlFBePoWaNnY=gcjqSkAGhVHztUwJrdQlFBePoWaNnI['wavve_limitdate']
  gcjqSkAGhVHztUwJrdQlFBePoWaNKI =gcjqSkAGhVHztUwJrdQlFBePoWaNnO(re.sub('-','',gcjqSkAGhVHztUwJrdQlFBePoWaNnY))
  if gcjqSkAGhVHztUwJrdQlFBePoWaNKI<gcjqSkAGhVHztUwJrdQlFBePoWaNKp:
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.wininfo_clear()
   return gcjqSkAGhVHztUwJrdQlFBePoWaNnu
  gcjqSkAGhVHztUwJrdQlFBePoWaNKE=xbmcgui.Window(10000)
  gcjqSkAGhVHztUwJrdQlFBePoWaNKE.setProperty('WAVVE_M_CREDENTIAL',gcjqSkAGhVHztUwJrdQlFBePoWaNnI['wavve_token'])
  gcjqSkAGhVHztUwJrdQlFBePoWaNKE.setProperty('WAVVE_M_LOGINTIME',gcjqSkAGhVHztUwJrdQlFBePoWaNnY)
  return gcjqSkAGhVHztUwJrdQlFBePoWaNnX
 def wavve_main(gcjqSkAGhVHztUwJrdQlFBePoWaNEf):
  gcjqSkAGhVHztUwJrdQlFBePoWaNMb=gcjqSkAGhVHztUwJrdQlFBePoWaNEf.main_params.get('mode',gcjqSkAGhVHztUwJrdQlFBePoWaNnT)
  gcjqSkAGhVHztUwJrdQlFBePoWaNEf.login_main()
  if gcjqSkAGhVHztUwJrdQlFBePoWaNMb is gcjqSkAGhVHztUwJrdQlFBePoWaNnT:
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.dp_Main_List()
  elif gcjqSkAGhVHztUwJrdQlFBePoWaNMb=='GNB_LIST':
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.dp_Gnb_List(gcjqSkAGhVHztUwJrdQlFBePoWaNEf.main_params)
  elif gcjqSkAGhVHztUwJrdQlFBePoWaNMb=='GN_LIST':
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.dp_Deeplink_List(gcjqSkAGhVHztUwJrdQlFBePoWaNEf.main_params)
  elif gcjqSkAGhVHztUwJrdQlFBePoWaNMb=='DEEP_LIST':
   gcjqSkAGhVHztUwJrdQlFBePoWaNKu=gcjqSkAGhVHztUwJrdQlFBePoWaNEf.main_params.get('uicode',gcjqSkAGhVHztUwJrdQlFBePoWaNnT)
   if gcjqSkAGhVHztUwJrdQlFBePoWaNKu in['quick','vod','program','x']:
    gcjqSkAGhVHztUwJrdQlFBePoWaNEf.dp_Episodelink_List(gcjqSkAGhVHztUwJrdQlFBePoWaNEf.main_params)
   else:gcjqSkAGhVHztUwJrdQlFBePoWaNnT
  elif gcjqSkAGhVHztUwJrdQlFBePoWaNMb in['LIVE','VOD','MOVIE']:
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.play_VIDEO(gcjqSkAGhVHztUwJrdQlFBePoWaNEf.main_params)
   time.sleep(0.1)
  elif gcjqSkAGhVHztUwJrdQlFBePoWaNMb=='GN_MYVIEW':
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.dp_Myview_Group(gcjqSkAGhVHztUwJrdQlFBePoWaNEf.main_params)
  elif gcjqSkAGhVHztUwJrdQlFBePoWaNMb=='MYVIEW_LIST':
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.dp_Myview_List(gcjqSkAGhVHztUwJrdQlFBePoWaNEf.main_params)
  elif gcjqSkAGhVHztUwJrdQlFBePoWaNMb=='GENRE':
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.dp_Genre_Group(gcjqSkAGhVHztUwJrdQlFBePoWaNEf.main_params)
  elif gcjqSkAGhVHztUwJrdQlFBePoWaNMb=='GENRE_LIST':
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.dp_Genre_List(gcjqSkAGhVHztUwJrdQlFBePoWaNEf.main_params)
  elif gcjqSkAGhVHztUwJrdQlFBePoWaNMb=='WATCH':
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.dp_Watch_List(gcjqSkAGhVHztUwJrdQlFBePoWaNEf.main_params)
  elif gcjqSkAGhVHztUwJrdQlFBePoWaNMb=='MYVIEW_REMOVE':
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.dp_WatchList_Delete(gcjqSkAGhVHztUwJrdQlFBePoWaNEf.main_params)
  elif gcjqSkAGhVHztUwJrdQlFBePoWaNMb=='SEARCH':
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.dp_Search_Group(gcjqSkAGhVHztUwJrdQlFBePoWaNEf.main_params)
  elif gcjqSkAGhVHztUwJrdQlFBePoWaNMb=='SEARCH_LIST':
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.dp_Search_List(gcjqSkAGhVHztUwJrdQlFBePoWaNEf.main_params)
  elif gcjqSkAGhVHztUwJrdQlFBePoWaNMb=='ORDER_BY':
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.dp_setEpOrderby(gcjqSkAGhVHztUwJrdQlFBePoWaNEf.main_params)
  elif gcjqSkAGhVHztUwJrdQlFBePoWaNMb=='LOGOUT':
   gcjqSkAGhVHztUwJrdQlFBePoWaNEf.logout()
  else:
   gcjqSkAGhVHztUwJrdQlFBePoWaNnT
# Created by pyminifier (https://github.com/liftoff/pyminifier)
